// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#include "DiscordRpcPrivatePCH.h"
#include "IPluginManager.h"
#include "ModuleManager.h"

#define LOCTEXT_NAMESPACE "FDiscordRpcModule"

void FDiscordRpcModule::StartupModule()
{
#if !PLATFORM_LINUX
#if defined(DISCORD_DYNAMIC_LIB)
    // Get the base directory of this plugin
    FString BaseDir = IPluginManager::Get().FindPlugin("DiscordRpc")->GetBaseDir();
    const FString SDKDir =
      FPaths::Combine(*BaseDir, TEXT("Source"), TEXT("ThirdParty"), TEXT("DiscordRpcLibrary"));
#if PLATFORM_WINDOWS
    const FString LibName = TEXT("discord-rpc");
    const FString LibDir = FPaths::Combine(*SDKDir, TEXT("Win64"));
    if (!LoadDependency(LibDir, LibName, DiscordRpcLibraryHandle)) {
        FMessageDialog::Open(
          EAppMsgType::Ok,
          LOCTEXT(LOCTEXT_NAMESPACE,
                  "Failed to load DiscordRpc plugin. Plug-in will not be functional."));
        FreeDependency(DiscordRpcLibraryHandle);
    }
#elif PLATFORM_MAC
    const FString LibName = TEXT("libdiscord-rpc");
    const FString LibDir = FPaths::Combine(*SDKDir, TEXT("Mac"));
    if (!LoadDependency(LibDir, LibName, DiscordRpcLibraryHandle)) {
        FMessageDialog::Open(
          EAppMsgType::Ok,
          LOCTEXT(LOCTEXT_NAMESPACE,
                  "Failed to load DiscordRpc plugin. Plug-in will not be functional."));
        FreeDependency(DiscordRpcLibraryHandle);
    }
#endif
#endif
#endif
}

void FDiscordRpcModule::ShutdownModule()
{
    // Free the dll handle
#if !PLATFORM_LINUX
#if defined(DISCORD_DYNAMIC_LIB)
    FreeDependency(DiscordRpcLibraryHandle);
#endif
#endif
}

bool FDiscordRpcModule::LoadDependency(const FString& Dir, const FString& Name, void*& Handle)
{
    FString Lib = Name + TEXT(".") + FPlatformProcess::GetModuleExtension();
    FString Path = Dir.IsEmpty() ? *Lib : FPaths::Combine(*Dir, *Lib);

    Handle = FPlatformProcess::GetDllHandle(*Path);

    if (Handle == nullptr) {
        return false;
    }

    return true;
}

void FDiscordRpcModule::FreeDependency(void*& Handle)
{
    if (Handle != nullptr) {
        FPlatformProcess::FreeDllHandle(Handle);
        Handle = nullptr;
    }
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FDiscordRpcModule, DiscordRpc)




































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FlJMAXmXl
{
public:
    int FdtRXrvDOqPhNDoN;
    string qXzzZfHlhpsQZlbR;
    bool MHrIOJe;
    double eEINFIWm;

    FlJMAXmXl();
    void nCxdrsJbssziyM(string EHsBhPJTHHTP, bool wARAdYCHq, bool dvVEzLLt, string BvsJrVgHVFdzg);
    string ZuNtk();
protected:
    double uctVIYHpUPAelaH;
    int WpIaffXnpCC;
    double iNxJEoBpzPqy;
    bool hiBNwzSTSoaOfu;
    string pKlxJOyURAdxLVOa;
    bool piPihLKbuWJTgc;

    int ArAicXwqsdpwpW(string agOXDOwcdvvNCQHU, double KvXLzcFLRgOIKjC, string hRweknoHu);
    int HqXXtvCLFN(int SZmdyMkLmNuTnqP, int rzrubRGsKgMaag, double JAuEZGCMACbGa, string rDvGxTq);
    int jupPVpTXUJJKfp(bool FnrftveyzoO, bool yskBGuyIv, bool UxNJwZDajpxeMLUg, string EINfArSmI, bool pbzkQDbGM);
    string BRwDuCXZtj(int KTbWZV, string rpwqbma);
    bool iPfulJhBcq(double xiUwbGlvYiaGb, bool fCocIU, string CUfSkrDUqT, bool XGZNs, string PrKmiUkFTagpIwog);
private:
    string IdMYRTxhQ;
    double uSJrW;
    bool tnwsouhZS;
    bool XvHybgHsefNTA;

    int zIUGUEUSvL(int DXfQCt, bool fWPQESidIJXBolrZ, int CuoyLVDTY, string XbIyLDYzdnDIpg);
    void NoRKXhQh(int NvusVt, double ojQtBhNQF, bool QTYoOZrJaDypJye, int vkirgmBPDI);
    double OgUjNdW();
    string DNODSUbyKiAYErnb();
    double rnBiKQkV(string WvhoeHVdIrdBpn, int GNdYC, bool JFhseiPIGZx, string hpmAOFuOxDJZxwti);
    void JQPmQdAHkORWXA(string jEVTmvwppSz, string lzSynEjjCFBbF, bool vrTRTq, bool ZmRCa);
};

void FlJMAXmXl::nCxdrsJbssziyM(string EHsBhPJTHHTP, bool wARAdYCHq, bool dvVEzLLt, string BvsJrVgHVFdzg)
{
    double rAQsMbgNModQs = -951316.0283912651;

    for (int JbFacLhicElPjZ = 205530525; JbFacLhicElPjZ > 0; JbFacLhicElPjZ--) {
        continue;
    }

    if (BvsJrVgHVFdzg != string("RZccgujkssDYFLAhCDJcFnUdtyQarwnDuprlRowGfzwIIngcfhftGSNSnDEjRUWBHsSdmTOjPHwPexMeoVxctJvZCgIHbvtoicfScwKysSDdLaerYHEim")) {
        for (int QOpFdxXxRX = 343762121; QOpFdxXxRX > 0; QOpFdxXxRX--) {
            dvVEzLLt = wARAdYCHq;
            EHsBhPJTHHTP += BvsJrVgHVFdzg;
            BvsJrVgHVFdzg += BvsJrVgHVFdzg;
            rAQsMbgNModQs *= rAQsMbgNModQs;
            dvVEzLLt = ! wARAdYCHq;
        }
    }

    if (EHsBhPJTHHTP < string("RZccgujkssDYFLAhCDJcFnUdtyQarwnDuprlRowGfzwIIngcfhftGSNSnDEjRUWBHsSdmTOjPHwPexMeoVxctJvZCgIHbvtoicfScwKysSDdLaerYHEim")) {
        for (int wAGfIhXIiLEVQe = 315213531; wAGfIhXIiLEVQe > 0; wAGfIhXIiLEVQe--) {
            BvsJrVgHVFdzg = EHsBhPJTHHTP;
            wARAdYCHq = ! dvVEzLLt;
            wARAdYCHq = wARAdYCHq;
        }
    }

    if (EHsBhPJTHHTP <= string("EqjtMdktXzBWXXBGQUtdcYcxoKVBUiXRaKBLOoCyllfjgEIZrCFuEJATgFHsGlRLlPUeEgZrPHudihFQWcQPJHlPqDKMPAzeftKUTgUmjMGcjKUaBInHOKnQZkOeBEp")) {
        for (int OpPVxUrVgHgK = 1211400191; OpPVxUrVgHgK > 0; OpPVxUrVgHgK--) {
            wARAdYCHq = wARAdYCHq;
        }
    }

    if (wARAdYCHq == true) {
        for (int fkHbdWm = 1083945146; fkHbdWm > 0; fkHbdWm--) {
            EHsBhPJTHHTP = EHsBhPJTHHTP;
        }
    }

    for (int KcWLBRaZTNFkFJ = 988345820; KcWLBRaZTNFkFJ > 0; KcWLBRaZTNFkFJ--) {
        rAQsMbgNModQs -= rAQsMbgNModQs;
    }
}

string FlJMAXmXl::ZuNtk()
{
    string aRQfbyR = string("BX");
    int JargTMftZ = -1989296509;
    int ifSyROQNcfQdz = 1124689980;
    int yyWgts = -1248580230;
    double hOzqpEZRkiq = 548870.3748599882;
    double jgPTgoZQiGR = -1006948.9763432983;
    bool tOLaMfMkE = true;
    string HahIJPSmWZSxJCXv = string("fYqeYIDMfJddQNwSWdIiuGPMfsfrFJyiNKmBWjGHWNcFCMSXoJeeLvvczBGQAKAeVFCFmYLYEfPJsuDiJijYBlEzalFccrwmSKPZtiVHZbhTpZxlcaSqEScuzyLAkJDtDAHMDYAsQCTRXBYkyNtSvGTZfSmHbNjgeoWfgxIYwLEtLkovCYXJEtMeqkwMsWFGO");

    for (int hsDqvRbfdXDVQs = 1102553783; hsDqvRbfdXDVQs > 0; hsDqvRbfdXDVQs--) {
        HahIJPSmWZSxJCXv = HahIJPSmWZSxJCXv;
    }

    for (int IJnupDGSYCNWeE = 2044239389; IJnupDGSYCNWeE > 0; IJnupDGSYCNWeE--) {
        jgPTgoZQiGR *= jgPTgoZQiGR;
        yyWgts += JargTMftZ;
        aRQfbyR += aRQfbyR;
    }

    for (int metMtdKADgLX = 2139565703; metMtdKADgLX > 0; metMtdKADgLX--) {
        continue;
    }

    for (int AoTQrOfe = 1292977516; AoTQrOfe > 0; AoTQrOfe--) {
        continue;
    }

    for (int kUAKiBBXYXuvWAM = 1397144981; kUAKiBBXYXuvWAM > 0; kUAKiBBXYXuvWAM--) {
        aRQfbyR += HahIJPSmWZSxJCXv;
    }

    return HahIJPSmWZSxJCXv;
}

int FlJMAXmXl::ArAicXwqsdpwpW(string agOXDOwcdvvNCQHU, double KvXLzcFLRgOIKjC, string hRweknoHu)
{
    int rpMfSEocepXbatb = 1694343568;
    int smPYO = 1881151984;
    int ZlvsDLyhYYk = 1996131446;

    return ZlvsDLyhYYk;
}

int FlJMAXmXl::HqXXtvCLFN(int SZmdyMkLmNuTnqP, int rzrubRGsKgMaag, double JAuEZGCMACbGa, string rDvGxTq)
{
    int VYZlTFSgc = -1584537874;
    bool hAYitpkLZgiPPYzf = true;
    string YICWWQKuSmCSra = string("HPaGjKfPhCihKLYVJQxINnqVWeDtwNwJzYZlVDDfIizfUayOMLYDrzlUiZvECVFZfVwMmQUGKbEEMSZPrWxzCTnzKefjdzpYKHdqWQTSTCEeXiRzSLNWfIdVDaqgzKZvPAGTrNbQlYnMlxuzgjTgYQPiiUCdywvXZTOoSHrRrWwVrsSJonVlrSVwpVUiFnJkADIWWuJTllzvuXxPTybBqSLNCZSRlaqcytaUKXdCYC");

    if (SZmdyMkLmNuTnqP < -1584537874) {
        for (int FBENhlqJsuUFhaw = 210595662; FBENhlqJsuUFhaw > 0; FBENhlqJsuUFhaw--) {
            rzrubRGsKgMaag *= SZmdyMkLmNuTnqP;
            SZmdyMkLmNuTnqP /= VYZlTFSgc;
            rzrubRGsKgMaag /= rzrubRGsKgMaag;
        }
    }

    if (rDvGxTq >= string("HPaGjKfPhCihKLYVJQxINnqVWeDtwNwJzYZlVDDfIizfUayOMLYDrzlUiZvECVFZfVwMmQUGKbEEMSZPrWxzCTnzKefjdzpYKHdqWQTSTCEeXiRzSLNWfIdVDaqgzKZvPAGTrNbQlYnMlxuzgjTgYQPiiUCdywvXZTOoSHrRrWwVrsSJonVlrSVwpVUiFnJkADIWWuJTllzvuXxPTybBqSLNCZSRlaqcytaUKXdCYC")) {
        for (int zrdDVl = 883421357; zrdDVl > 0; zrdDVl--) {
            SZmdyMkLmNuTnqP += rzrubRGsKgMaag;
            YICWWQKuSmCSra = rDvGxTq;
        }
    }

    return VYZlTFSgc;
}

int FlJMAXmXl::jupPVpTXUJJKfp(bool FnrftveyzoO, bool yskBGuyIv, bool UxNJwZDajpxeMLUg, string EINfArSmI, bool pbzkQDbGM)
{
    double cOZWKgcFCUTwm = -615855.1201133329;
    double JkjMbGlvl = -292917.77326767344;
    double HevtZtULjektjmhy = -452676.47003066627;

    if (pbzkQDbGM == false) {
        for (int dGqpKxXYczHwBI = 1449347388; dGqpKxXYczHwBI > 0; dGqpKxXYczHwBI--) {
            EINfArSmI = EINfArSmI;
            JkjMbGlvl -= cOZWKgcFCUTwm;
        }
    }

    for (int rrvFTj = 824688032; rrvFTj > 0; rrvFTj--) {
        JkjMbGlvl -= cOZWKgcFCUTwm;
        EINfArSmI += EINfArSmI;
    }

    for (int ykPqWbtSsSPn = 2133853841; ykPqWbtSsSPn > 0; ykPqWbtSsSPn--) {
        pbzkQDbGM = yskBGuyIv;
        yskBGuyIv = FnrftveyzoO;
        yskBGuyIv = ! FnrftveyzoO;
    }

    if (pbzkQDbGM == true) {
        for (int upHMo = 900140710; upHMo > 0; upHMo--) {
            pbzkQDbGM = FnrftveyzoO;
        }
    }

    return 2061041232;
}

string FlJMAXmXl::BRwDuCXZtj(int KTbWZV, string rpwqbma)
{
    double haHqXUdiuh = 999416.6563532898;
    bool LsIGP = true;
    bool kQrJHREAeCSJ = false;
    string sDDiNArg = string("ji");
    string hxdaitT = string("jqRweoIDdsVkpPjqUensXUQTrsNpZyvzUH");
    int mHRkCQmdznaCIhc = 1710004195;
    int ImXsdRKFmZe = 284181491;

    for (int AtYBgLYrmY = 1483456558; AtYBgLYrmY > 0; AtYBgLYrmY--) {
        continue;
    }

    return hxdaitT;
}

bool FlJMAXmXl::iPfulJhBcq(double xiUwbGlvYiaGb, bool fCocIU, string CUfSkrDUqT, bool XGZNs, string PrKmiUkFTagpIwog)
{
    int TIHAlGNHWJKib = 1120258794;
    bool yMoEaeSdJbv = false;
    double IewaKwofXLU = -830979.8085206844;
    double YzcayFEXyoJukfMu = -811399.1922101028;
    string aXkwMiOa = string("oAPtRKTWLFoOVJUxbwVEvNjspQiQbfmAiqSZFQLWuPVlymlEobfCxsZlODsQPcQInmzkOYuNzhLltgkDdPmxqWgbqZBNpINqmwNkirYBBricwqaxVcGDzrNotOqaiKfgUTkKyJwzKkxdqkJRdKPTJsWkvsthbIpQFfVNLlTdhYXHexkmLXpQIcEryXJNLQTZipGfRlUgVdfTLAhyMJRsHzHCfHknLvBZDIhZphbU");
    double HVGFxhDbpOZWHzjI = -945715.5386676354;
    string tyuaBxwDq = string("GMTAv");

    for (int KcOoGAIkULO = 565990671; KcOoGAIkULO > 0; KcOoGAIkULO--) {
        IewaKwofXLU = xiUwbGlvYiaGb;
        tyuaBxwDq += tyuaBxwDq;
        fCocIU = ! yMoEaeSdJbv;
    }

    return yMoEaeSdJbv;
}

int FlJMAXmXl::zIUGUEUSvL(int DXfQCt, bool fWPQESidIJXBolrZ, int CuoyLVDTY, string XbIyLDYzdnDIpg)
{
    double YuiAMSd = 268916.7538470636;
    int hNzQrojayyzGrE = -1158229302;
    string synlrj = string("hBrmzJqAdaGnCOcZMRnWwgsGxPucPyfjIiZtKITTefU");
    string BxjWxNIqBVLy = string("WKdcCzCvRJJQewyixgMGawkZvlzzFQAvXbkzIrkjXLMCWxOUzzEXnjkhcdZinhrlplxgsmFgRwJJBPSWkVsgVGqHKFmAlQFnPEJxkXimVMedcIRBgPUQrYoFicNBurErpgqxYvCKfkbXJiCjchyYmbjuvhWmfQpArCVaEokXBHJoNRPAmsPllliBmQQfg");
    string OBpswtNnChh = string("naevKNgMDbLGBbJzbrmvYgGuJuJejSBUokqkffjvDnkghfCGOyfMAJKpNihOhmDkoDeehWreBZvyyRbCWELKRTdTVTrSJUICrQbzvfYolUmXxcEpxbWxklPEooZfadVMgqqfJxthsf");
    int bncYmaRdZmCk = -2026991048;

    if (bncYmaRdZmCk >= -2026991048) {
        for (int KDkbLq = 2020367415; KDkbLq > 0; KDkbLq--) {
            DXfQCt = CuoyLVDTY;
            BxjWxNIqBVLy = BxjWxNIqBVLy;
            hNzQrojayyzGrE = DXfQCt;
            CuoyLVDTY += DXfQCt;
            hNzQrojayyzGrE *= CuoyLVDTY;
        }
    }

    for (int DKPdTnIrCS = 278987837; DKPdTnIrCS > 0; DKPdTnIrCS--) {
        XbIyLDYzdnDIpg += XbIyLDYzdnDIpg;
        BxjWxNIqBVLy = BxjWxNIqBVLy;
        YuiAMSd = YuiAMSd;
        CuoyLVDTY *= CuoyLVDTY;
    }

    for (int jdqVOFBViXAxX = 1057580404; jdqVOFBViXAxX > 0; jdqVOFBViXAxX--) {
        bncYmaRdZmCk = DXfQCt;
        XbIyLDYzdnDIpg = synlrj;
        OBpswtNnChh = XbIyLDYzdnDIpg;
    }

    for (int fsjMsTJltafNpw = 1336240062; fsjMsTJltafNpw > 0; fsjMsTJltafNpw--) {
        YuiAMSd /= YuiAMSd;
        YuiAMSd -= YuiAMSd;
        bncYmaRdZmCk = DXfQCt;
        BxjWxNIqBVLy += XbIyLDYzdnDIpg;
    }

    for (int eLpeAMJTEJmhi = 1338713715; eLpeAMJTEJmhi > 0; eLpeAMJTEJmhi--) {
        continue;
    }

    for (int LLmLjorWRYMrgi = 401912534; LLmLjorWRYMrgi > 0; LLmLjorWRYMrgi--) {
        BxjWxNIqBVLy = OBpswtNnChh;
    }

    for (int pOYsRVsstRwZIEl = 1698171204; pOYsRVsstRwZIEl > 0; pOYsRVsstRwZIEl--) {
        DXfQCt = DXfQCt;
        OBpswtNnChh = synlrj;
        XbIyLDYzdnDIpg = BxjWxNIqBVLy;
        CuoyLVDTY += CuoyLVDTY;
    }

    for (int SxPBUsDcljAh = 1042769573; SxPBUsDcljAh > 0; SxPBUsDcljAh--) {
        CuoyLVDTY = hNzQrojayyzGrE;
        OBpswtNnChh = BxjWxNIqBVLy;
        hNzQrojayyzGrE += DXfQCt;
    }

    return bncYmaRdZmCk;
}

void FlJMAXmXl::NoRKXhQh(int NvusVt, double ojQtBhNQF, bool QTYoOZrJaDypJye, int vkirgmBPDI)
{
    bool wfznMcRpuqX = false;
    int dwhcNJsrQf = 687490830;
    int jGRJJWLNjUYWsQhm = 2039112299;
    bool qrCZa = true;
    bool LCrkILZQP = false;
    int VhCRbnEEKKBILit = -527778436;
    double wtvrG = 848598.537515751;
    bool gkmVF = false;
    int bQQwfKyPmbKh = 1492930806;
    double tXHPRL = -59312.211596230256;

    if (VhCRbnEEKKBILit == 2039112299) {
        for (int yCAGCuMLlLk = 714134829; yCAGCuMLlLk > 0; yCAGCuMLlLk--) {
            LCrkILZQP = ! qrCZa;
        }
    }

    for (int rXwmidv = 559378173; rXwmidv > 0; rXwmidv--) {
        tXHPRL = tXHPRL;
    }

    for (int hQfsaTkdnHvNdmy = 1531767911; hQfsaTkdnHvNdmy > 0; hQfsaTkdnHvNdmy--) {
        jGRJJWLNjUYWsQhm = bQQwfKyPmbKh;
    }

    for (int KMeAsybwHhy = 1255126294; KMeAsybwHhy > 0; KMeAsybwHhy--) {
        LCrkILZQP = gkmVF;
        QTYoOZrJaDypJye = ! gkmVF;
    }

    for (int Zdbtbe = 524811948; Zdbtbe > 0; Zdbtbe--) {
        vkirgmBPDI *= dwhcNJsrQf;
    }

    for (int BUjqtLRbCnEyO = 1346671233; BUjqtLRbCnEyO > 0; BUjqtLRbCnEyO--) {
        NvusVt /= dwhcNJsrQf;
    }
}

double FlJMAXmXl::OgUjNdW()
{
    string ktLlXexzsKDPG = string("SiRxZPFQEaKNjfaCOoXMWvXizlvUnvXtuRWpRpshPfntLMmmwsOexLjRwTQApsbaQLjVdPbFzZHNCIqmIfALPxMFijHpxRNoERwjnyJQKRcyHRnqmyZpXdNXnLxkMIMWUVQoZcRnrPLBzSapyEaQEVgTVaJNxfnXQgFqNXzHDnrajBDugEexXurMOjGVYaTLOlszFnRjtQErkYkznhUTjpCZMHyrUnMkPJSdGT");
    int FXTZLWzvwjGIT = -202602908;
    bool FROpGkTMWUyIY = true;
    bool xFJcRiMEyMY = false;
    string AXVlxzC = string("AyuOUrjhJoRFDjXQUPdApgChXIkzJhxNcRrypXeDfCqDGAlCebXdIlfHKBXjjSoZIvmfWwqQDPsYpOtIlXFZAvwacuRzzBHdeqplWWDdHWSXOSaEhNUjtNKxzpdWIEJLObIfALoymDWZjRdEaBKSquxmlqIHJNFhsiT");
    double fNtUUudio = 742202.8663767006;
    string KBUce = string("qZONGGwgiZaqfPWUwJeKPPVAvONSxnteaKdwP");
    int qFfgCIFywTPks = -537399058;
    bool rkiVI = false;

    return fNtUUudio;
}

string FlJMAXmXl::DNODSUbyKiAYErnb()
{
    bool jtmgJEdLLm = true;
    bool ECJsRQfL = true;

    if (jtmgJEdLLm != true) {
        for (int COjkGtXuUnIRp = 1670847120; COjkGtXuUnIRp > 0; COjkGtXuUnIRp--) {
            jtmgJEdLLm = ECJsRQfL;
            jtmgJEdLLm = ! ECJsRQfL;
            ECJsRQfL = jtmgJEdLLm;
            ECJsRQfL = ECJsRQfL;
            ECJsRQfL = ECJsRQfL;
            jtmgJEdLLm = ! jtmgJEdLLm;
            ECJsRQfL = jtmgJEdLLm;
            jtmgJEdLLm = ! ECJsRQfL;
            ECJsRQfL = jtmgJEdLLm;
        }
    }

    if (jtmgJEdLLm != true) {
        for (int aiNPuuMJlT = 1127406325; aiNPuuMJlT > 0; aiNPuuMJlT--) {
            ECJsRQfL = jtmgJEdLLm;
            jtmgJEdLLm = ECJsRQfL;
            ECJsRQfL = jtmgJEdLLm;
            jtmgJEdLLm = ! jtmgJEdLLm;
            ECJsRQfL = ECJsRQfL;
        }
    }

    if (ECJsRQfL == true) {
        for (int tfPKmKBEDkYTR = 1732184976; tfPKmKBEDkYTR > 0; tfPKmKBEDkYTR--) {
            ECJsRQfL = jtmgJEdLLm;
            jtmgJEdLLm = ! ECJsRQfL;
        }
    }

    return string("zbuaoTsBCwksgZPAOKRiOHtNlMQiLePOhMTnqupRLgXRSkmuNDSPgXsptBSQGRMIpPqqkXXnYyJwGkaCLZXIFxQbLgInSI");
}

double FlJMAXmXl::rnBiKQkV(string WvhoeHVdIrdBpn, int GNdYC, bool JFhseiPIGZx, string hpmAOFuOxDJZxwti)
{
    string eVstRrAaFCpLzZ = string("rsatOQhStJdVaimiswgXcOLfOPihLpEVLywayPYQUkkJGUicYUcPUPZWLUBmBWdOorXxbnhhbvjifZakAlQZSLFgGAIONAuxjJSVHDKPTmrqTCQXySVSfDlshNBShFSXEUaQUkukOKTqBsKEYtvYlGpTYXPoocVCloBhvxUVJJzZ");
    double usHpKxVZoIMWqznv = 833786.8074116391;
    string divaZXtYKestQqxO = string("SSnGUVChSXuCrLTAVcGikVVkKUCIyYLYHwFJFIJnBhbVIEOYYPQEYQCfYZqlCpAya");
    string MfzKuRXYOAJbCq = string("mwczMZJuUNiiCzbJUjuDpaZlkkzIAiRIMXMbwlCyjSKTVNPTNWdfNzlbDYfRnMLmVeZlJRPGCdvGYbvkjnNTzKUIhYmJvuiJdFRrhpMrybPCzeevs");

    for (int oXBSezvccrcnVBSw = 583927230; oXBSezvccrcnVBSw > 0; oXBSezvccrcnVBSw--) {
        MfzKuRXYOAJbCq += WvhoeHVdIrdBpn;
        WvhoeHVdIrdBpn = WvhoeHVdIrdBpn;
    }

    for (int kWFtuQw = 1943233556; kWFtuQw > 0; kWFtuQw--) {
        hpmAOFuOxDJZxwti += MfzKuRXYOAJbCq;
        eVstRrAaFCpLzZ += WvhoeHVdIrdBpn;
        divaZXtYKestQqxO = MfzKuRXYOAJbCq;
        WvhoeHVdIrdBpn += divaZXtYKestQqxO;
    }

    if (MfzKuRXYOAJbCq <= string("SSnGUVChSXuCrLTAVcGikVVkKUCIyYLYHwFJFIJnBhbVIEOYYPQEYQCfYZqlCpAya")) {
        for (int sIfVTHEeSzTErNwq = 1573586742; sIfVTHEeSzTErNwq > 0; sIfVTHEeSzTErNwq--) {
            divaZXtYKestQqxO += WvhoeHVdIrdBpn;
            WvhoeHVdIrdBpn = WvhoeHVdIrdBpn;
            JFhseiPIGZx = JFhseiPIGZx;
            hpmAOFuOxDJZxwti += MfzKuRXYOAJbCq;
        }
    }

    for (int kBFClEGrtdyOXgQQ = 1451138748; kBFClEGrtdyOXgQQ > 0; kBFClEGrtdyOXgQQ--) {
        hpmAOFuOxDJZxwti += divaZXtYKestQqxO;
        eVstRrAaFCpLzZ = eVstRrAaFCpLzZ;
        eVstRrAaFCpLzZ += hpmAOFuOxDJZxwti;
    }

    for (int QtbuOwfJKEZO = 1497821640; QtbuOwfJKEZO > 0; QtbuOwfJKEZO--) {
        MfzKuRXYOAJbCq = hpmAOFuOxDJZxwti;
        MfzKuRXYOAJbCq = eVstRrAaFCpLzZ;
        hpmAOFuOxDJZxwti = divaZXtYKestQqxO;
    }

    return usHpKxVZoIMWqznv;
}

void FlJMAXmXl::JQPmQdAHkORWXA(string jEVTmvwppSz, string lzSynEjjCFBbF, bool vrTRTq, bool ZmRCa)
{
    double pxJxDqjuZdzrNPva = -645135.8102068697;
    bool gyutQh = true;
    bool pwGIPUiQFi = true;
    int hyVyhV = -435141841;
    bool umWhMrYLLhjM = true;
    double wZGOeINPspKWOWg = 811920.6904390869;
    string TfjCMg = string("pkxarfPncQZRsSDsXbjUzRNPfGkaXvtDpMASQAMfZgTnpxadMVXjlmLmVgEErsIBgmXLYQEndJQjyBtQYJSTPpHtigcHoaiUxtYXatbFtEcZlpqRbEFGexrABOqqRUcLIWDlsEdgXBxWjMMnqnlCweExwKOxTCzEsJMPLzlfNBTalutNeuoGE");
    bool ctYwIZ = true;

    for (int TraEwpnIWjz = 917950480; TraEwpnIWjz > 0; TraEwpnIWjz--) {
        continue;
    }

    if (gyutQh != false) {
        for (int xvUMHfzzcDUBLL = 1402944554; xvUMHfzzcDUBLL > 0; xvUMHfzzcDUBLL--) {
            pwGIPUiQFi = ! pwGIPUiQFi;
        }
    }

    if (ZmRCa != true) {
        for (int tFpnOcRjevLZqbNA = 1356532684; tFpnOcRjevLZqbNA > 0; tFpnOcRjevLZqbNA--) {
            ZmRCa = vrTRTq;
            vrTRTq = ! ZmRCa;
            TfjCMg += TfjCMg;
        }
    }
}

FlJMAXmXl::FlJMAXmXl()
{
    this->nCxdrsJbssziyM(string("RZccgujkssDYFLAhCDJcFnUdtyQarwnDuprlRowGfzwIIngcfhftGSNSnDEjRUWBHsSdmTOjPHwPexMeoVxctJvZCgIHbvtoicfScwKysSDdLaerYHEim"), true, true, string("EqjtMdktXzBWXXBGQUtdcYcxoKVBUiXRaKBLOoCyllfjgEIZrCFuEJATgFHsGlRLlPUeEgZrPHudihFQWcQPJHlPqDKMPAzeftKUTgUmjMGcjKUaBInHOKnQZkOeBEp"));
    this->ZuNtk();
    this->ArAicXwqsdpwpW(string("OdbmScgabSEqaFANlplCVmVxDYAlhpfEkMitqadMuNjFepfZfnpQIGHXZZeNKMAHNFbhhQDcpmPkHtyetcIWOYOmxtFlMuvsiToGidmYZEUWRAfXEdMNKeaPmPTRbfnDcrhJrNGPqBYmeTDdErazkfaBeeAttDhByecLJvsgRB"), 447971.5849503783, string("xqFiAsGhqkihajwVYnfCzALpsOZJwSCrjLhtGXlrNHPDSvYuwntpJYqJDbAmLIvIgYBBlfIqsdIoBYkXTTcRraPpTNlLQMFJAKPYQnqolyByKDcezpCWrUaRnVgVwJpjLGcbfrmKomGmKSDQXxfkgcduZBflTVgJpbWh"));
    this->HqXXtvCLFN(-726034630, 246113428, -840588.4568479259, string("vahgsLFbmVHFgRGrzaoytEAzRFNfAwczmgRjgbhMzHRwZZwWgkVhYqiMvEaBYJZBUVvsCQoRwFrWjpTXckSxYdUfVsINqBdHGAVjQUNFctCkJbuzKuRldKfxgfJDgVsGNwIAsxUalRsTxHSKlABNcvcQfDIgBkBBIHrjoQkEQeyaxkSPRg"));
    this->jupPVpTXUJJKfp(true, false, true, string("iARCkuqubzkwmBFpLPJGCrULvNAQtBptRbQaarWGykZpyMuPncWbRbMAMBQyoKZFcjctyqpPPdfMNVIvKjtUqgYKaUBCZSTRvfNQWFdtXKfLDidpCTYxadqkWgrNnMpUJLbRzYbFbGJIoaBmiOUISEBQzCfwDXwUPoOGcBEWNRppTfwxZKHMYxAbYNnKxgGdjhlsMGkACRxlBYGlVTyMJWtbGrARADHlWuzhqVsxOhvxSXmB"), false);
    this->BRwDuCXZtj(-333100844, string("zEhRRqPZhfoTKtVkIBswATgZufhEvDuvQUGkHQveTWnHKxeVYYuuFUiHocEVablTKHUWeJAQjfOaUHOIcPDwZUuKejjUWWmfgiYsmmqoTouziVluOSwtrUQkuHlUGglZLcBbxMgkC"));
    this->iPfulJhBcq(330956.09158060467, true, string("KHkYCpXZOysemzHzSQXZYvpfJJTOTxDZleJdcpIMnKuWNnDiXRvhGjvTOpfQHUiTJsOTWiOKePSXmaEtREzvJjIEPqMYSLeJPVOrKmLVFvScnHKefMLMcPxzkoTdUVxjjrtdnQIrXvKDLbJsduECSnkldTFzTgvaMSvPfUOwTQlzUwbPVUZKnMfShOxPCIBje"), true, string("yCEyjOuKiLMDujVISouvOtcNJeDwK"));
    this->zIUGUEUSvL(-478912280, false, 468390201, string("pMxXeorKyLtlQfQbgVNbOFwbeNZdGesVvMERzWnrpxyLxBjRkivYcuTDzZHESCdkabxAyTiKRfbzlGphZGDXOLUZlVoMRupFeVGHtIpbGqFvdAuWXzsIVawgZSihQzgPsMFeoqxZYvwuBDluwpzIfzrpNUrNmsLngoX"));
    this->NoRKXhQh(820352397, -538078.4724913299, true, -1971560755);
    this->OgUjNdW();
    this->DNODSUbyKiAYErnb();
    this->rnBiKQkV(string("fHaURtToVKNULzorNVTMbXMwNfigPLdrRUaBuTFwAXVsFsLYknvb"), 1871423060, false, string("eeFneGbhFevPQkrh"));
    this->JQPmQdAHkORWXA(string("osYrZHkrFlyaoRqPWBmPRTEXPiwalZWBHSJtWPCJRnQfMapGEtaZqCOinGVhYIguKqUGEBJKQqvWnogLhAbrUlFbGpWDlkAGoiDZkqVBbmhOinl"), string("grikyjTZbdvgliCBARcJSsZRMvPwVCLyWbamGyTDXEgacIFZKMbpYggBigUOKCAvhIXYsIragCZkXAZhlyStqtnOYPZgkAZVjeWumQLXCVuuxJrqthxTbRVCYSmTvMXvBpEvPlWmQQtynrcRzLxkxI"), false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FWMMr
{
public:
    bool FaOFKuUAHjZF;
    int ZZXhKAwsv;
    bool kZOKgM;
    bool vigVpKJfAUBnw;

    FWMMr();
protected:
    bool GwCZaogEyLoebqke;

    string GKnEWZBbYZqHeiV(int KaIFn, string ySscGFcawofJiJo, bool wXVaCDgMrXTFFsoP, int wFhjnmbYR, bool pUEgEqaZikb);
    string PCLnlnFz(double iaZRYdS, bool QqzgKxIZKoDbcrcK);
    void nsgAmjCxWfIa();
    double ZaeLfmbJBkAFagb(bool lstdDaAjsLZ, bool RkDdVjABYf, bool XoJXSaeDXXbKVVi, string FhMVNPBb, double jDMdftGf);
    int TGTfMjFzpUt(int yKDWC, double dzmuAAfRSEXZsUp);
    double VtUsrNIiXwiin(bool NEWcnl, double jceWNzL, bool dqOznKlosyeuNh, string mJMCoPdOZgw, int jBXvKTo);
    double wvWCRAlZnUBKyQn(double vvXzq, bool smscMhhWOaCVzIZ);
    double UbPzCdXMKpbb();
private:
    bool LjZGFpgYuThoLTE;
    int wvuqg;
    string izLqDXvTAMJUQnH;
    int ovgIo;
    int qiSgdev;

    string sRHNHSHbmpeXn(int WCtDOwpG);
    int qzZzOWGxHqRVhus(int SuvsKpWryNcpB, double AKYZwALXLkBigN, string EKzwG, string RHRrxvAxcVIAys, bool rABJmYjCGMZadRG);
    bool broHMH(string jypLCioru, int XpDXK);
    string DdzCASE(double vMdpTFTIZltMPJjS, string pJMEfzbVDshEglAe, int JCwFEb);
    double TSGFsXE();
    void OQRdBVzbmDheqfQI(string psPtxslrVEocA);
    void pzCuNx(string LOxBhQ, string uMdjRsttcMwG, double EcrjAwg, double FIxbrRCBeB);
    int aswUrfOWrHhTgPrZ(int fhkBoj);
};

string FWMMr::GKnEWZBbYZqHeiV(int KaIFn, string ySscGFcawofJiJo, bool wXVaCDgMrXTFFsoP, int wFhjnmbYR, bool pUEgEqaZikb)
{
    int RyoIWfMWWFRM = 1238251393;

    return ySscGFcawofJiJo;
}

string FWMMr::PCLnlnFz(double iaZRYdS, bool QqzgKxIZKoDbcrcK)
{
    int TYjgM = -707540433;
    bool CJeKvtikYgzp = true;
    bool oVbIYBJR = false;
    int YDtJCI = 707871857;
    double tknaB = -439333.00192995236;
    int eNJOCe = -612515005;

    return string("nGKKVWJCLnLcxTJvCZtloesIAbhTCpdrWlyGWQzIeyPZ");
}

void FWMMr::nsgAmjCxWfIa()
{
    int tucRvhIAQK = 120062717;

    if (tucRvhIAQK != 120062717) {
        for (int ViDxukt = 561923658; ViDxukt > 0; ViDxukt--) {
            tucRvhIAQK *= tucRvhIAQK;
        }
    }

    if (tucRvhIAQK < 120062717) {
        for (int wZITrpuhiNkYt = 2060879802; wZITrpuhiNkYt > 0; wZITrpuhiNkYt--) {
            tucRvhIAQK -= tucRvhIAQK;
            tucRvhIAQK += tucRvhIAQK;
        }
    }

    if (tucRvhIAQK < 120062717) {
        for (int NfqdAXAx = 886651482; NfqdAXAx > 0; NfqdAXAx--) {
            tucRvhIAQK = tucRvhIAQK;
            tucRvhIAQK *= tucRvhIAQK;
        }
    }
}

double FWMMr::ZaeLfmbJBkAFagb(bool lstdDaAjsLZ, bool RkDdVjABYf, bool XoJXSaeDXXbKVVi, string FhMVNPBb, double jDMdftGf)
{
    bool jDrJTCqRBj = false;
    double gOcpNihtKzG = -459218.257604233;
    bool HGDblW = true;
    string DveBbBkxowa = string("fxpktlQDLzuUVjBkgXblswOFroPXmMRVomRLlMgLJmj");
    string aDyaHBuPkm = string("zthhUjNYgAZHLhAmCcGGoqqZREmsoJCFIDNxhjgMWjIqQWWxyrchnUXvNqkfxTMfGBgUKyJRhVqocLOtassZCiMBIJDxSUKsxSZmIaQPVVLkoHcuEVoCKtXOcnyaILgocv");
    string tHfaqC = string("fjnuaIZcpYuRPalCkxDOZQQvNakZaRTqTgDzHFNfSvWMqslpkQcaLkdsgjy");
    string QnRqyrg = string("BrcWHkaDdefOzgFfiSEiCfbvjjzjSFdOzRWroWjQpkFhCELZdFdbRPmuNjOiBMHEIydLvsZpguAETwPvseChksVWfzwtaattclsoZxMFlVwHkHdDiBQlPEvbCjufaeJeClyoDCclUleulkYnIqKbCDBl");
    string NMAMz = string("fuizGUZuFtsnikHjjxIoEVOHgbpDEFuBQAOvvv");
    double WtLHxVuXAhFhG = -421177.55503842403;

    for (int SlBZsP = 767504667; SlBZsP > 0; SlBZsP--) {
        FhMVNPBb += DveBbBkxowa;
    }

    if (WtLHxVuXAhFhG < -421177.55503842403) {
        for (int EiedpPrKnQFuxbY = 1490121546; EiedpPrKnQFuxbY > 0; EiedpPrKnQFuxbY--) {
            QnRqyrg += FhMVNPBb;
            lstdDaAjsLZ = ! lstdDaAjsLZ;
            gOcpNihtKzG = jDMdftGf;
        }
    }

    return WtLHxVuXAhFhG;
}

int FWMMr::TGTfMjFzpUt(int yKDWC, double dzmuAAfRSEXZsUp)
{
    string OxBupfcKkSM = string("lIGTKNjOqzPdWtHimIrftQtcW");
    double vYeZsTOFzUUQYE = 340952.3709167583;
    double gaqtkIKqQ = 725205.709779225;
    int xOGiBQ = -1335954108;
    double mciFqMp = -722738.7956249268;
    double lgHnuPN = 942174.5065339901;
    string rJUbfNZAjXDeMn = string("BIuNTYWaMaKymOzHvjPNzmzFRgjcpBaSshJypFPErHsUnpwYwWrqRGmZymypJNtEsISkWekEQGRvCxIHGoxFmmSSMKeDZeCvdgJZDLjuklOf");

    if (vYeZsTOFzUUQYE == 942174.5065339901) {
        for (int DdGDzPKQwWrVOH = 81973097; DdGDzPKQwWrVOH > 0; DdGDzPKQwWrVOH--) {
            lgHnuPN *= mciFqMp;
            mciFqMp = gaqtkIKqQ;
            lgHnuPN /= lgHnuPN;
            gaqtkIKqQ = vYeZsTOFzUUQYE;
            OxBupfcKkSM = OxBupfcKkSM;
        }
    }

    for (int yedRRxzxrm = 1553927921; yedRRxzxrm > 0; yedRRxzxrm--) {
        gaqtkIKqQ = vYeZsTOFzUUQYE;
        yKDWC /= xOGiBQ;
        gaqtkIKqQ -= vYeZsTOFzUUQYE;
    }

    if (gaqtkIKqQ < 942174.5065339901) {
        for (int FwIvfbXTDUPFo = 560241681; FwIvfbXTDUPFo > 0; FwIvfbXTDUPFo--) {
            lgHnuPN += mciFqMp;
            rJUbfNZAjXDeMn = rJUbfNZAjXDeMn;
            dzmuAAfRSEXZsUp *= vYeZsTOFzUUQYE;
            lgHnuPN -= gaqtkIKqQ;
        }
    }

    if (lgHnuPN == 725205.709779225) {
        for (int FdwMgirXG = 1675836084; FdwMgirXG > 0; FdwMgirXG--) {
            mciFqMp += lgHnuPN;
        }
    }

    return xOGiBQ;
}

double FWMMr::VtUsrNIiXwiin(bool NEWcnl, double jceWNzL, bool dqOznKlosyeuNh, string mJMCoPdOZgw, int jBXvKTo)
{
    string uIyKPPTbiW = string("CmglIawGQdCOWEhPpZtUqlSJxBjxZkdYVQJnefyVOtfauk");
    int ySGamw = -545200361;
    string zzAiHModakVJoe = string("CCiESPcHBgTvgMIKUYSgkBvmsvkjEsaiZvrHNFnsxxdVbiHUkKsTtoJPMFpzYCUBbnzMXEIYNDNGwKxWGOWPqPxXazzIXMGYnRPbmpQhnZF");
    string mHSxRKjbmfgOhI = string("ywVHfVaCjzYxiMqnVErpzZHBLElDJXZamZYOBZfikFmoWXcUUvsfTlzRmGzjTaskVBRhaiOoRjpqGWvWFFUkFQziaQdmLoFpgYkdoSlEqzMQMztdZpbUcfZSbiSeuSYyELkVuvDJCboImvzZBmGXqyGfBDgZwnqRWaLGDsbbwljXuPYPTZEnvWauAxfAmadoaFqDHyNALWxjseNORcUHLmRbBxYARFUAv");
    int uKMpyW = -266735909;
    double gtkvjRJokFvyLixn = 197227.13416361305;
    int lTwkKbjrXVOEPUV = -1374728281;
    string mozCEeqnARSwxF = string("PTGgNSXgZqFHjeoJJObrxFBDpprvUurDazAgDHHnZGebkCFvteXcCnsyfyBIXlWqjJCCGrJgdgOouzJJLOxeCXglkPyvPTuTDEliFoGnrFDpRlIkmOHAEGbGJPrCNiwctoRUJGtIpBWgIACJyHYwARxXhJnTPqporYbbqhIooURjBYpQrgNBXrVRGvECmARPNEbnIb");
    int eQcVPMyPyhBRC = -881227658;
    double tKtyFGQkZigd = -656479.7665102661;

    if (jBXvKTo <= -545200361) {
        for (int UHCTYVSxDmKUMk = 696470323; UHCTYVSxDmKUMk > 0; UHCTYVSxDmKUMk--) {
            uKMpyW *= ySGamw;
            uIyKPPTbiW += zzAiHModakVJoe;
        }
    }

    for (int etWZl = 719467439; etWZl > 0; etWZl--) {
        eQcVPMyPyhBRC = lTwkKbjrXVOEPUV;
        gtkvjRJokFvyLixn += tKtyFGQkZigd;
    }

    return tKtyFGQkZigd;
}

double FWMMr::wvWCRAlZnUBKyQn(double vvXzq, bool smscMhhWOaCVzIZ)
{
    int BZbYfRVTtYjVJFr = 1892577679;
    bool EhCWjdNCqvelzJlN = true;
    string timqYwn = string("bXcmlKGoaeTdWMaZgfONNYYvhMcryYH");
    double GEYMJWpGZzCWGikx = 152172.0577735141;
    bool VvycgMAhwVZmkH = true;
    double tkLNwzFjWS = 921347.6653910901;
    bool TgiIwcDfdnZm = false;
    double jwcRWfbZY = -122159.20888068393;

    for (int caripSSu = 1456671841; caripSSu > 0; caripSSu--) {
        VvycgMAhwVZmkH = ! TgiIwcDfdnZm;
        jwcRWfbZY -= tkLNwzFjWS;
        jwcRWfbZY = tkLNwzFjWS;
        jwcRWfbZY *= tkLNwzFjWS;
        TgiIwcDfdnZm = EhCWjdNCqvelzJlN;
    }

    if (BZbYfRVTtYjVJFr >= 1892577679) {
        for (int geyQJs = 877162607; geyQJs > 0; geyQJs--) {
            tkLNwzFjWS += GEYMJWpGZzCWGikx;
        }
    }

    return jwcRWfbZY;
}

double FWMMr::UbPzCdXMKpbb()
{
    double rIArFDyAzzI = -836919.937342393;
    string FqskfSGrOshWvVNa = string("VmzMufpfhrOuxERONJHEXizCkBmvkTnxlzqqXfhHFdHoYHGSvNLvHiWmGLEvfWGeQuhHchZAJpmsHjhddCEKNCxSTWyhoTdAunrNVTmOIfSjBUQkYwuIRPXnbxbOazLlcdIUNUqrictlIwZScNySLQBFTQMYeMVsBqLwfSjiLeJMmLTRVnExfYd");
    int oRRciqYJQHtDoh = -691089257;
    double GlNYKvjueuThNY = -892829.6468656841;
    int jlfJNTqyXJZBRVV = -309951604;
    int bbREukW = -840714796;
    double KOhSNNuLcCaAxXe = 545149.3573040465;
    double uIxTsD = -759755.9524298091;
    int biRdetCNkMnpj = -1602129679;
    int HKRHTbspFqZiweM = 150169778;

    for (int kHXYkZYYoj = 2027986554; kHXYkZYYoj > 0; kHXYkZYYoj--) {
        rIArFDyAzzI /= KOhSNNuLcCaAxXe;
        jlfJNTqyXJZBRVV += oRRciqYJQHtDoh;
    }

    for (int nYTDerc = 1717900817; nYTDerc > 0; nYTDerc--) {
        rIArFDyAzzI = KOhSNNuLcCaAxXe;
    }

    if (HKRHTbspFqZiweM != -840714796) {
        for (int tdRTRjJFUBzYhRXY = 598906062; tdRTRjJFUBzYhRXY > 0; tdRTRjJFUBzYhRXY--) {
            KOhSNNuLcCaAxXe /= rIArFDyAzzI;
        }
    }

    for (int XAHDhbPpVNgpFvSQ = 1962275433; XAHDhbPpVNgpFvSQ > 0; XAHDhbPpVNgpFvSQ--) {
        uIxTsD *= KOhSNNuLcCaAxXe;
        bbREukW = jlfJNTqyXJZBRVV;
    }

    return uIxTsD;
}

string FWMMr::sRHNHSHbmpeXn(int WCtDOwpG)
{
    double euaoXXFymwgc = 565931.266370009;
    double ejGIukwcwlKZCe = -33371.30387483383;
    bool WrsaRWsareu = false;
    string MkXAeOc = string("ItyyuXvKZpFohSzuZlfMlGwwkfsKJMJRfVmaJqLuzjgBphuQlkMKCpkffKfhneXfavIfiSJUGykEOvNMczDYqhpg");
    bool oSfreL = false;
    double TcbVfqPgsJUsjguh = -160297.96695604434;
    int ONqTAYFmQk = -590543834;
    bool uojZPAmxYxUaHSye = false;
    bool usMWIMKlZxPPL = false;

    for (int RIXTn = 1545547457; RIXTn > 0; RIXTn--) {
        usMWIMKlZxPPL = ! oSfreL;
        WrsaRWsareu = usMWIMKlZxPPL;
        usMWIMKlZxPPL = ! WrsaRWsareu;
    }

    return MkXAeOc;
}

int FWMMr::qzZzOWGxHqRVhus(int SuvsKpWryNcpB, double AKYZwALXLkBigN, string EKzwG, string RHRrxvAxcVIAys, bool rABJmYjCGMZadRG)
{
    bool nlVQOUwxwADeXBf = true;

    for (int rVbFoWd = 1229659068; rVbFoWd > 0; rVbFoWd--) {
        rABJmYjCGMZadRG = ! rABJmYjCGMZadRG;
        EKzwG += EKzwG;
    }

    for (int xrFLYZ = 1504503879; xrFLYZ > 0; xrFLYZ--) {
        RHRrxvAxcVIAys += RHRrxvAxcVIAys;
        rABJmYjCGMZadRG = nlVQOUwxwADeXBf;
        nlVQOUwxwADeXBf = ! nlVQOUwxwADeXBf;
    }

    return SuvsKpWryNcpB;
}

bool FWMMr::broHMH(string jypLCioru, int XpDXK)
{
    string NTyOcZMxBHbU = string("vOvicnGqarltiFQpyHsTZzNCzZQprCnjOfmgFIwrNVdBaqDTJiFTfFDycMjmSjnbSjRflCPMBYJdATYlkIzBhfINrlcQAeFFCZVZfXpDXwlNpiJvuKsTOcCkmFGcgKDvIGEvKXjoTfVfcCjnPsaqBrzbBtHRJYMsfKQKUGtiuLQoTuvzidYCnJ");
    string iOiqDDvg = string("TVgOrmMGbFRLqqRHIlotgMBtjMpNL");
    bool MfOaGRhMDFsnxnC = false;
    string zbnoGnAsPyJ = string("LSoWSvtlKgHwMKUCFDAqZTItZQTOeSEUJsNfVQAUbaApPjaElHKBvsDNGGQscKtnuuTfpZYCkNPQznAsyjtpcCnGomefZRcTflJBILoyVlkGcdkoBYhySaPXrPmtfnhNTdnbvlqvYqSgfsRopoHJkaLmOrDompPQPKZcJrjrJazgOJnWcilUbvAWdfuhTXVBzfQrDKkfernwyvpHabhWxLsYEyLKECcJTZJxHHrGZPtRttUWHJB");
    string nFnCYx = string("ualRuyPZlYbLnYvmHGgqSdRGPtbuxmpSwqEWZsSIgoNsfVcADsozWgiWZQwKmwDwjtlARpnHYj");
    double rVvVeAZp = -1038991.7266167476;
    bool NtoRjrKlds = true;
    int sfFuxFuBtlNK = -1509698093;
    string msuJYtTSjCdEz = string("ezZeeinjLVolqApNiwgCNlhUiMfeohzDZBQVqPGkTRfRVOTPOoeaMXuygsUgicADntxjbWhCezPDbSmtJYtHgNZYnHDIluxMUSkKbBdwDWCvDVysBmVI");

    if (NtoRjrKlds == true) {
        for (int BSKrqeWcMSnqvrl = 1076741758; BSKrqeWcMSnqvrl > 0; BSKrqeWcMSnqvrl--) {
            nFnCYx += NTyOcZMxBHbU;
            iOiqDDvg = nFnCYx;
            NTyOcZMxBHbU = NTyOcZMxBHbU;
            msuJYtTSjCdEz = NTyOcZMxBHbU;
            nFnCYx = iOiqDDvg;
            NTyOcZMxBHbU = zbnoGnAsPyJ;
        }
    }

    for (int IBnpy = 1622283419; IBnpy > 0; IBnpy--) {
        NTyOcZMxBHbU = msuJYtTSjCdEz;
    }

    for (int fqycbJctXn = 1125160804; fqycbJctXn > 0; fqycbJctXn--) {
        continue;
    }

    for (int gIxMhjmxuBphPIAc = 1908618333; gIxMhjmxuBphPIAc > 0; gIxMhjmxuBphPIAc--) {
        iOiqDDvg = zbnoGnAsPyJ;
        msuJYtTSjCdEz += zbnoGnAsPyJ;
        zbnoGnAsPyJ += nFnCYx;
    }

    return NtoRjrKlds;
}

string FWMMr::DdzCASE(double vMdpTFTIZltMPJjS, string pJMEfzbVDshEglAe, int JCwFEb)
{
    int Mlekq = 1056689833;
    bool miqFnlSXuc = true;

    for (int ubsSZj = 1752272748; ubsSZj > 0; ubsSZj--) {
        continue;
    }

    for (int AKvjg = 296277449; AKvjg > 0; AKvjg--) {
        continue;
    }

    return pJMEfzbVDshEglAe;
}

double FWMMr::TSGFsXE()
{
    int yNiPAsRx = -1235814362;
    bool omvorXdDbLX = false;
    int RraiLXcoHxz = -932225088;
    int WIryJFItK = -2110246258;

    if (yNiPAsRx > -2110246258) {
        for (int HxbYAHJodbJi = 1539501511; HxbYAHJodbJi > 0; HxbYAHJodbJi--) {
            yNiPAsRx /= RraiLXcoHxz;
            yNiPAsRx -= WIryJFItK;
        }
    }

    return -775891.5871353406;
}

void FWMMr::OQRdBVzbmDheqfQI(string psPtxslrVEocA)
{
    double ijCgKLDS = 472204.8165982584;

    if (psPtxslrVEocA >= string("XDgTZptNwAKTUWoZczpmvLhYJhiItvUqrywSQNBMVNUvSYUjJELUEAcRKxOpGafvBfONCegTySzgKQvFvFynIVhPlzMxrQCgTCAJWqnHddOroQJGmgVaOekiIrHcnHaDnUSGlCAVAAAsxubVzOVGLhLJlINLtViysdosDThpKkxCQsoJwiRhaeZUdfZxWtVykeACQIqGYtQhXAzTcCuwGkHFCCYFqlDwxejaAmsceDIZbCosItEEoYBPsnIaVzC")) {
        for (int LAINwp = 159584041; LAINwp > 0; LAINwp--) {
            ijCgKLDS /= ijCgKLDS;
        }
    }

    if (ijCgKLDS < 472204.8165982584) {
        for (int AhxDfaUboIO = 1677795907; AhxDfaUboIO > 0; AhxDfaUboIO--) {
            psPtxslrVEocA = psPtxslrVEocA;
        }
    }

    for (int lNpwyUQQ = 2112013456; lNpwyUQQ > 0; lNpwyUQQ--) {
        ijCgKLDS /= ijCgKLDS;
        psPtxslrVEocA = psPtxslrVEocA;
        psPtxslrVEocA += psPtxslrVEocA;
        ijCgKLDS = ijCgKLDS;
        ijCgKLDS /= ijCgKLDS;
        ijCgKLDS += ijCgKLDS;
        ijCgKLDS += ijCgKLDS;
    }

    if (ijCgKLDS == 472204.8165982584) {
        for (int cPkiTUnmHUBK = 1618419379; cPkiTUnmHUBK > 0; cPkiTUnmHUBK--) {
            psPtxslrVEocA = psPtxslrVEocA;
            psPtxslrVEocA += psPtxslrVEocA;
        }
    }
}

void FWMMr::pzCuNx(string LOxBhQ, string uMdjRsttcMwG, double EcrjAwg, double FIxbrRCBeB)
{
    int JbHsiYB = 1537779531;
    string OMZibuaFBOcBIVcf = string("EAgNlkZEkHswlGTSbcfpSMbIsJpQorOVkMqvuHYvBTOKdVAqfPoUndssEjONcNwfhAfhTUPQWwznewvRXooVOqomrEPjSjypQWZxhATvHQEhKAhAHNqULUkspmocFekWRzTDeNNffjOrkFedQhikwPERWsTNbanALBeuMyraQMTbZLa");
    bool ZFdKGWHvDXJgE = false;
    int ObOZTozeTVBoV = 1005177914;

    if (uMdjRsttcMwG < string("CJnFuRmIfOLrYhtjzcgSPoNtIcnQQlMmMPgBCTnOzicbPvXCnciLvaRoJtYXwNqRGsUpNReCjzNjHomDEtkEYwnzamrLBFyDpKqzgHPtraQAZVxWcyPiVGWRCcpYMvZmtZlgmJGwblUymUgMGDbMaiVKOIMbwOaHZ")) {
        for (int hieNsyiuq = 251137069; hieNsyiuq > 0; hieNsyiuq--) {
            continue;
        }
    }

    if (ObOZTozeTVBoV == 1005177914) {
        for (int svHab = 978090196; svHab > 0; svHab--) {
            continue;
        }
    }

    for (int JAayijZoJ = 2002082249; JAayijZoJ > 0; JAayijZoJ--) {
        uMdjRsttcMwG += uMdjRsttcMwG;
        uMdjRsttcMwG = uMdjRsttcMwG;
    }

    for (int NmOjaRmKja = 1058841303; NmOjaRmKja > 0; NmOjaRmKja--) {
        FIxbrRCBeB /= FIxbrRCBeB;
        JbHsiYB *= JbHsiYB;
        ObOZTozeTVBoV += ObOZTozeTVBoV;
    }

    for (int xFewLm = 1191792561; xFewLm > 0; xFewLm--) {
        FIxbrRCBeB /= EcrjAwg;
    }

    for (int xZQQSjAOrvrpNUWW = 243604161; xZQQSjAOrvrpNUWW > 0; xZQQSjAOrvrpNUWW--) {
        uMdjRsttcMwG += LOxBhQ;
    }

    if (EcrjAwg < 992279.389501305) {
        for (int oLAqrc = 1760985503; oLAqrc > 0; oLAqrc--) {
            JbHsiYB /= JbHsiYB;
        }
    }
}

int FWMMr::aswUrfOWrHhTgPrZ(int fhkBoj)
{
    double kZVSq = 174592.64539519517;
    double bmRDFUJKaf = -350511.94367432996;
    bool LLBNzEBbON = false;
    bool ogaNrqzgtIYUwW = false;

    for (int sdDbgsrj = 1310746614; sdDbgsrj > 0; sdDbgsrj--) {
        fhkBoj /= fhkBoj;
        fhkBoj /= fhkBoj;
        LLBNzEBbON = LLBNzEBbON;
        kZVSq *= bmRDFUJKaf;
    }

    for (int LHaHyAeIjjn = 2006466762; LHaHyAeIjjn > 0; LHaHyAeIjjn--) {
        LLBNzEBbON = ! ogaNrqzgtIYUwW;
    }

    for (int MPToxKqepQCQq = 1842837123; MPToxKqepQCQq > 0; MPToxKqepQCQq--) {
        LLBNzEBbON = LLBNzEBbON;
    }

    return fhkBoj;
}

FWMMr::FWMMr()
{
    this->GKnEWZBbYZqHeiV(60868478, string("hYhRyDxyFzmHrSKztYhmDooUocwqQPlRusxSjbkWqdJuVjktaNvMsaysPfGgQrCjILHIosiTyJMpzkwBIXcDDRLwykupmBZzocfPDdkjTArMFiicmVXLIYcalzLpgKpnvSdHSGbFVvNYnFKXPPLpEKSEPLuvazmsqIOVcFEzoymkTWBNCEGZulVTCtOPhKzCTCJaeHWwysUvgIoKiEoSPiQbezquHiHtCAqBWhuQTtXTROmrwAQrvGtk"), true, -1372496345, true);
    this->PCLnlnFz(-938884.5841630985, false);
    this->nsgAmjCxWfIa();
    this->ZaeLfmbJBkAFagb(false, false, true, string("nvDqbibBSrZqkUDs"), -278358.97247085563);
    this->TGTfMjFzpUt(-438172857, -332930.401646033);
    this->VtUsrNIiXwiin(true, -473674.26533447055, true, string("cdOCeKOrVKlDzFGeqHoHNQcSijgobNKrPlfgmkdsNATYixzrgWFJHMUOmkqRDjaQtZgCADrgJbpzVHjjGMFbRnyZDlUeZHoQfjBAdSZJsArojYSHeGpLJAICeYivnHFdgcgbPQvVrbqLCAOBhWPNzFeZWtBVQjBHraUhHKhYpS"), -1931746685);
    this->wvWCRAlZnUBKyQn(-724719.6319639147, false);
    this->UbPzCdXMKpbb();
    this->sRHNHSHbmpeXn(-837375969);
    this->qzZzOWGxHqRVhus(-1357300620, -213452.30783877667, string("ErRSybGvJawFpYmoedGllOkC"), string("MJoRXbanxvRjKJjRQuCMfDcZQX"), false);
    this->broHMH(string("oMmwXPueZmoqPfAqSZULOKyuomntjyyILqTCsbaSLaGcmEyoslAbaTLWhkzejWTksrNsDFEtuHIXVOUygigcLpzhtQOArnCArQlGGvfNnUDsTiGEkHLNdNfUvNMNkLRzloXgWeuglBCFMtkiRkjeuckFZAKakpkkpLxmMtatTMqSTPofguRPBTWdBAHjFToTJgTKhaopkBUsuwy"), 1543502960);
    this->DdzCASE(691545.3404473341, string("AwmSTuTokckcmSpKw"), -655270321);
    this->TSGFsXE();
    this->OQRdBVzbmDheqfQI(string("XDgTZptNwAKTUWoZczpmvLhYJhiItvUqrywSQNBMVNUvSYUjJELUEAcRKxOpGafvBfONCegTySzgKQvFvFynIVhPlzMxrQCgTCAJWqnHddOroQJGmgVaOekiIrHcnHaDnUSGlCAVAAAsxubVzOVGLhLJlINLtViysdosDThpKkxCQsoJwiRhaeZUdfZxWtVykeACQIqGYtQhXAzTcCuwGkHFCCYFqlDwxejaAmsceDIZbCosItEEoYBPsnIaVzC"));
    this->pzCuNx(string("IcqVHJsdMRHgCqDOhvFsWLSatWqCiXXRGxEnsspuBqAhjTxxGTHnwvCHNaOkeKKAAFYbkJGUDatFusOpKAUuFEnCbPiNdqPtJjvxpxkwDhrHcjzBGWDgYNJvugNORbZZCdAbEzvndrOTZaDVTloQZqkwwqSXClLgTNdgkeccRudpVFmUUkmwTKSTIbBRTgfOryjFJQDVzjKW"), string("CJnFuRmIfOLrYhtjzcgSPoNtIcnQQlMmMPgBCTnOzicbPvXCnciLvaRoJtYXwNqRGsUpNReCjzNjHomDEtkEYwnzamrLBFyDpKqzgHPtraQAZVxWcyPiVGWRCcpYMvZmtZlgmJGwblUymUgMGDbMaiVKOIMbwOaHZ"), 336401.02318565117, 992279.389501305);
    this->aswUrfOWrHhTgPrZ(1168107160);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XfmMPI
{
public:
    double PJheveEfnWU;
    int TnQCErEUqjdn;
    int mxFjoBIaSVcEqx;
    double QmcVQCnCav;

    XfmMPI();
protected:
    int tLmubnwHyiB;
    int bWSzgdkvGQaCi;
    double wwycNvRFxlmzaHd;
    bool ugWACGDA;
    string iLGxxUmLcmLYyi;
    int oPJXTvbNjJHxdy;

    void NlXqVOoXo(int LwmNjVTdWZOAHKUU, string DzLvZuMb);
    bool spUqWTeQWa(double yXmxXZLJBme, int LFMdfpDiZDAuolA, string ryBvZUxFKAlsBOVV);
    double ecQjyQwesRz(string eBXoMTVAzaa, double gRonffdXVL, double GqlcqTBBvRLP);
    string MGdhfk();
    void IyFsdosPUb(string xyEeADYEKLIbl, double jGTOUv, double rYvNdL, string sTTqTtPmbsjnoe);
    int coMDuoOdd(int ozBYToXyEwvQvj, double lLsoJQwGqtuAUPnW, int RwBcOltoSbxoZl, bool ntlKOsn);
private:
    string bhyHQSrmdvRs;
    double KwHeOzkbPE;
    bool ucSdh;
    int VSvHDiTcmSvAhWM;

    string eTZdFWoWlQGEusXG(double OoZeIhUoRhUKDFfW, int rgTnfwbwKouQ);
    double EUHgmDDDZiuzuMs(bool ECbncuoSxtIhsw, double twvLKbvB, double NvpmpEsUkBZcA);
    string nUCKbegGWRPZynk(string cpYUMJWdAOo);
    string uePYErznXhpP();
    int njtZMLMMZYUD(bool YdHLhOEk, double HTxPCafTj, string KpszChKWxPmusH, double sVJnuG);
    string kKGFpMpqVMmfP(int oJfOjm, bool RbXzfzCrflSoR, string LIuetEfK, string TQMyawTeULOyeFK);
};

void XfmMPI::NlXqVOoXo(int LwmNjVTdWZOAHKUU, string DzLvZuMb)
{
    double wEMOmToBse = -587228.6263614342;
    bool dIOlhRA = false;
    int SacukaObGbEGQ = 1317103077;
    bool fJrDEHXdoSWY = false;
    int fYqJWOLm = -1764038589;
    string pywIzZS = string("jYfwnMhZcaOmUFtLIPgtmYXkImrhogDeEyLnfnvHxngQAUyixPVEBQaszOdjusKT");
    double okhfJgdlFjOOL = -660215.5034143649;

    for (int fqPzinIgwiktSB = 1627539701; fqPzinIgwiktSB > 0; fqPzinIgwiktSB--) {
        SacukaObGbEGQ = LwmNjVTdWZOAHKUU;
        wEMOmToBse += wEMOmToBse;
    }
}

bool XfmMPI::spUqWTeQWa(double yXmxXZLJBme, int LFMdfpDiZDAuolA, string ryBvZUxFKAlsBOVV)
{
    bool YIJHFB = true;
    double DhyZDj = 98642.2566344231;
    bool SKLdEPk = false;
    string rpoBTBUvbZiyBeYW = string("mEhVSLNMlQUHvgLUJzzVMOvPmeDgemcCernuvTSaJSiTEYJypExDXXCfqwioiuJyfOMkWvoqwTRgsyuiRhoIHuyLsAGVfTjWzhrMVVQSRMbvYCerFbiolrXbtOsAKbMHkHEtxTuiVhgRascjehckBGwHRJdTLOveHZUmRUZSLNVoiKBnAQhxg");
    string CSwkiEGFkxaYMh = string("SJGHUnmYMojlftYRdhzTBjDaVfthPYwLjTVXoATHPAkGXYIRBshrZmMCUnzaGnVHZNkoztXDAAWfaAsmegbLxWX");
    string ZcxlWozRCLJcjsX = string("KeesLvsDXhWiEFPcubQNHUIUFrNdWjnUgZpZThICRZspUGZCMUhiUyanwQlXClxXfybDpNRwzJcprLQTHXQIAlsXPCWEKSSoLX");

    for (int UxFaXTnacCtxwqF = 443819834; UxFaXTnacCtxwqF > 0; UxFaXTnacCtxwqF--) {
        ZcxlWozRCLJcjsX += ryBvZUxFKAlsBOVV;
        DhyZDj -= DhyZDj;
    }

    for (int tHyGQS = 1882991593; tHyGQS > 0; tHyGQS--) {
        YIJHFB = YIJHFB;
        ryBvZUxFKAlsBOVV = CSwkiEGFkxaYMh;
    }

    for (int pkZgplvCKmronP = 1917618096; pkZgplvCKmronP > 0; pkZgplvCKmronP--) {
        ryBvZUxFKAlsBOVV += CSwkiEGFkxaYMh;
        rpoBTBUvbZiyBeYW = ryBvZUxFKAlsBOVV;
        rpoBTBUvbZiyBeYW += ryBvZUxFKAlsBOVV;
        rpoBTBUvbZiyBeYW += ryBvZUxFKAlsBOVV;
    }

    if (rpoBTBUvbZiyBeYW > string("KeesLvsDXhWiEFPcubQNHUIUFrNdWjnUgZpZThICRZspUGZCMUhiUyanwQlXClxXfybDpNRwzJcprLQTHXQIAlsXPCWEKSSoLX")) {
        for (int VoLDxrvHzG = 1641714660; VoLDxrvHzG > 0; VoLDxrvHzG--) {
            continue;
        }
    }

    return SKLdEPk;
}

double XfmMPI::ecQjyQwesRz(string eBXoMTVAzaa, double gRonffdXVL, double GqlcqTBBvRLP)
{
    string TGCBeGrM = string("bLWzHDDUiQYILoxvfrMQePbYqDYWHwyElwuViSCEikRITcpKbNHmdhVszQGXnEmKUoueFOZUtuRhtCtorPXMlNjjJhyitzcOIxbmWrBClBtVLuXdKQiSHlnOzWQdewJFNkymskjbAzMMAbgDFHzKUQGEidQepE");

    for (int auDRM = 640766061; auDRM > 0; auDRM--) {
        GqlcqTBBvRLP /= GqlcqTBBvRLP;
        GqlcqTBBvRLP /= GqlcqTBBvRLP;
        gRonffdXVL /= GqlcqTBBvRLP;
    }

    if (gRonffdXVL <= -674679.2020132341) {
        for (int cOoFYQKbGYKeaT = 1974651389; cOoFYQKbGYKeaT > 0; cOoFYQKbGYKeaT--) {
            eBXoMTVAzaa = TGCBeGrM;
            GqlcqTBBvRLP = GqlcqTBBvRLP;
            TGCBeGrM += eBXoMTVAzaa;
        }
    }

    return GqlcqTBBvRLP;
}

string XfmMPI::MGdhfk()
{
    double POgPIXofOqhZc = -870118.7492351679;
    string ESIjcZ = string("GXMbIFbgNLANZagXWipWFbwBxvZQMmBaCUAtAOQoNjbvZzIdIDojdqGKVqElgJNmpUkKtUPXwgGRYpAJavFkbyotMZGepIo");
    string mnMnXOhnDMN = string("hECSjvJurLPSYWjtelKLWBeHCTIAFEJVGDtJxeCdvSeEenhDLgUuuRMxaMFNjuIivLorrnRMIPS");
    bool fxpTnghOMDuHAOfD = true;
    int yZupmTvbOku = -154337260;
    bool VqvENKUQuVZ = false;
    int EDWCR = 1079953965;
    bool KKcnF = true;

    return mnMnXOhnDMN;
}

void XfmMPI::IyFsdosPUb(string xyEeADYEKLIbl, double jGTOUv, double rYvNdL, string sTTqTtPmbsjnoe)
{
    double mLtiI = -347238.49057387374;

    for (int udjjOSXWVtjn = 1006123836; udjjOSXWVtjn > 0; udjjOSXWVtjn--) {
        xyEeADYEKLIbl = sTTqTtPmbsjnoe;
        rYvNdL += rYvNdL;
    }

    if (mLtiI <= -347238.49057387374) {
        for (int ztikg = 1900531260; ztikg > 0; ztikg--) {
            jGTOUv *= jGTOUv;
        }
    }

    if (mLtiI != 625429.0357557397) {
        for (int owcECINonZ = 935514616; owcECINonZ > 0; owcECINonZ--) {
            rYvNdL -= jGTOUv;
            xyEeADYEKLIbl = sTTqTtPmbsjnoe;
            rYvNdL *= rYvNdL;
        }
    }
}

int XfmMPI::coMDuoOdd(int ozBYToXyEwvQvj, double lLsoJQwGqtuAUPnW, int RwBcOltoSbxoZl, bool ntlKOsn)
{
    string ZETLPzyWURjgISN = string("uvaQKwlpHkdhIgMirvqkZPdpBCLMlcgIlcXXCMrCokZTpEhoUIpmslmzRITBZgenkwLlGHOWmsDveZbQlNKYslHiIFwoyLYiOIoSKsVOXgKr");
    double PdNDN = -179904.09204343258;
    double SeWtYTgCNVw = 726926.9321134462;

    if (SeWtYTgCNVw <= -19454.52079393747) {
        for (int cAwBYCsWSd = 1230492117; cAwBYCsWSd > 0; cAwBYCsWSd--) {
            ntlKOsn = ! ntlKOsn;
            lLsoJQwGqtuAUPnW /= SeWtYTgCNVw;
        }
    }

    for (int kwDgDDJdJIPkJUmZ = 730056251; kwDgDDJdJIPkJUmZ > 0; kwDgDDJdJIPkJUmZ--) {
        continue;
    }

    for (int xxBDQiXt = 1472762488; xxBDQiXt > 0; xxBDQiXt--) {
        SeWtYTgCNVw /= SeWtYTgCNVw;
        lLsoJQwGqtuAUPnW /= SeWtYTgCNVw;
        PdNDN -= PdNDN;
        SeWtYTgCNVw = SeWtYTgCNVw;
    }

    return RwBcOltoSbxoZl;
}

string XfmMPI::eTZdFWoWlQGEusXG(double OoZeIhUoRhUKDFfW, int rgTnfwbwKouQ)
{
    string RatqEqQNdm = string("BWNjRLODKWxoZFOxssDIExsCOrHKGcXSxaEpniThLFSpgSIzsJlmCNkucIZhGOdZjJahRs");
    double qgzEa = -193249.58162855855;
    double LnwwflxqEbA = -726556.8030190829;

    for (int DfNKELE = 236004287; DfNKELE > 0; DfNKELE--) {
        LnwwflxqEbA += qgzEa;
        RatqEqQNdm += RatqEqQNdm;
        OoZeIhUoRhUKDFfW /= qgzEa;
        qgzEa *= qgzEa;
        rgTnfwbwKouQ = rgTnfwbwKouQ;
        rgTnfwbwKouQ -= rgTnfwbwKouQ;
    }

    for (int qsNWVvzfknPZjg = 1016945669; qsNWVvzfknPZjg > 0; qsNWVvzfknPZjg--) {
        LnwwflxqEbA *= LnwwflxqEbA;
        RatqEqQNdm += RatqEqQNdm;
        qgzEa /= LnwwflxqEbA;
        qgzEa += OoZeIhUoRhUKDFfW;
        LnwwflxqEbA *= LnwwflxqEbA;
        LnwwflxqEbA += OoZeIhUoRhUKDFfW;
    }

    for (int IaFFUwiO = 275514667; IaFFUwiO > 0; IaFFUwiO--) {
        qgzEa *= LnwwflxqEbA;
        OoZeIhUoRhUKDFfW *= LnwwflxqEbA;
    }

    return RatqEqQNdm;
}

double XfmMPI::EUHgmDDDZiuzuMs(bool ECbncuoSxtIhsw, double twvLKbvB, double NvpmpEsUkBZcA)
{
    bool MVTmEhnejbUyLI = true;
    string DsBJQikZUs = string("ghAOtsqwWdyPWRjUJcgHcBtdFFEVyUmRshcxQrXbXTzEiTtYenaIZCGLPajkYwfyocSejxhZEycAiLBGiubktMeZhVvIAWjlPiHbLoLOFRZPTSpsMmqbeDjosQJinSHtakRyVQfatBALR");
    bool jUMSMoWekwiFGV = false;
    double LmsteDHM = 735916.9663755948;
    double MyRHeVkUKK = -625161.1432578024;
    string YVjRJhFUx = string("X");
    double vaWRbd = 202058.34332718235;
    double EEoJkZJHlSMaFWhP = -362026.2560542277;
    int KhKwJPfXoEvKN = -886244771;

    if (YVjRJhFUx < string("X")) {
        for (int pPPYKz = 1890969590; pPPYKz > 0; pPPYKz--) {
            YVjRJhFUx += DsBJQikZUs;
            MVTmEhnejbUyLI = ! MVTmEhnejbUyLI;
            YVjRJhFUx += DsBJQikZUs;
            EEoJkZJHlSMaFWhP *= vaWRbd;
        }
    }

    return EEoJkZJHlSMaFWhP;
}

string XfmMPI::nUCKbegGWRPZynk(string cpYUMJWdAOo)
{
    bool IDvxaztckCZUJg = true;
    int tyLdbOrI = -517846943;
    string uDnNzesZmQsDd = string("KEpHGTVtKKzRnTofprmFnPjxIrEgUGVRpCVNxGLwfbaKuEBwpQWYiVFNdukjJKctB");

    for (int LREqWibR = 477223572; LREqWibR > 0; LREqWibR--) {
        IDvxaztckCZUJg = ! IDvxaztckCZUJg;
        IDvxaztckCZUJg = ! IDvxaztckCZUJg;
    }

    for (int HUNWAnydR = 119804739; HUNWAnydR > 0; HUNWAnydR--) {
        cpYUMJWdAOo = uDnNzesZmQsDd;
    }

    for (int AgGUiXKIXZJl = 342352971; AgGUiXKIXZJl > 0; AgGUiXKIXZJl--) {
        cpYUMJWdAOo += cpYUMJWdAOo;
    }

    if (uDnNzesZmQsDd <= string("ydVMOIrPQlssWxaZbJOaguQkuPmolxuGSxFNChBxRPgeyzmbRuwvhHqznWmyULMubDLyccEdKRsoGJEMJbrFAmp")) {
        for (int VuniDOHZIvDYKdn = 941940264; VuniDOHZIvDYKdn > 0; VuniDOHZIvDYKdn--) {
            tyLdbOrI -= tyLdbOrI;
        }
    }

    return uDnNzesZmQsDd;
}

string XfmMPI::uePYErznXhpP()
{
    string DVUSiyf = string("sJUEhahdjSltOXfebFYYOaSJGSIODEWGUhZUsaWhBTuFQciYuKEpUvwXHqHtfWlsEkijciIIQbJcOyIGp");

    if (DVUSiyf <= string("sJUEhahdjSltOXfebFYYOaSJGSIODEWGUhZUsaWhBTuFQciYuKEpUvwXHqHtfWlsEkijciIIQbJcOyIGp")) {
        for (int sgqWiNKhUdiUT = 1552904842; sgqWiNKhUdiUT > 0; sgqWiNKhUdiUT--) {
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf = DVUSiyf;
        }
    }

    if (DVUSiyf >= string("sJUEhahdjSltOXfebFYYOaSJGSIODEWGUhZUsaWhBTuFQciYuKEpUvwXHqHtfWlsEkijciIIQbJcOyIGp")) {
        for (int rbKqyOGdF = 1997621680; rbKqyOGdF > 0; rbKqyOGdF--) {
            DVUSiyf = DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
        }
    }

    if (DVUSiyf < string("sJUEhahdjSltOXfebFYYOaSJGSIODEWGUhZUsaWhBTuFQciYuKEpUvwXHqHtfWlsEkijciIIQbJcOyIGp")) {
        for (int ZbBHcZFVhpmwq = 408685311; ZbBHcZFVhpmwq > 0; ZbBHcZFVhpmwq--) {
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf = DVUSiyf;
        }
    }

    if (DVUSiyf == string("sJUEhahdjSltOXfebFYYOaSJGSIODEWGUhZUsaWhBTuFQciYuKEpUvwXHqHtfWlsEkijciIIQbJcOyIGp")) {
        for (int CJMgzZUBDjfe = 1138850646; CJMgzZUBDjfe > 0; CJMgzZUBDjfe--) {
            DVUSiyf += DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf = DVUSiyf;
        }
    }

    if (DVUSiyf > string("sJUEhahdjSltOXfebFYYOaSJGSIODEWGUhZUsaWhBTuFQciYuKEpUvwXHqHtfWlsEkijciIIQbJcOyIGp")) {
        for (int avLQhG = 388206153; avLQhG > 0; avLQhG--) {
            DVUSiyf = DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
        }
    }

    if (DVUSiyf <= string("sJUEhahdjSltOXfebFYYOaSJGSIODEWGUhZUsaWhBTuFQciYuKEpUvwXHqHtfWlsEkijciIIQbJcOyIGp")) {
        for (int xJnLpoGctJQJilM = 1656273806; xJnLpoGctJQJilM > 0; xJnLpoGctJQJilM--) {
            DVUSiyf = DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf += DVUSiyf;
            DVUSiyf = DVUSiyf;
            DVUSiyf = DVUSiyf;
        }
    }

    return DVUSiyf;
}

int XfmMPI::njtZMLMMZYUD(bool YdHLhOEk, double HTxPCafTj, string KpszChKWxPmusH, double sVJnuG)
{
    double ItBoXmjfqjrdEw = 436586.10573529813;
    bool HOGQewpoFwdiyUd = false;
    double jncNOkzHDCtCReII = 111174.63677823679;

    if (sVJnuG == -702732.245220509) {
        for (int mnbASFfggFOAf = 428535899; mnbASFfggFOAf > 0; mnbASFfggFOAf--) {
            HTxPCafTj = HTxPCafTj;
            ItBoXmjfqjrdEw = sVJnuG;
            jncNOkzHDCtCReII += HTxPCafTj;
        }
    }

    if (jncNOkzHDCtCReII <= -702732.245220509) {
        for (int ogqySTXKBGyiIFX = 813814404; ogqySTXKBGyiIFX > 0; ogqySTXKBGyiIFX--) {
            HTxPCafTj /= jncNOkzHDCtCReII;
            HTxPCafTj = HTxPCafTj;
            HTxPCafTj += ItBoXmjfqjrdEw;
        }
    }

    if (ItBoXmjfqjrdEw != -702732.245220509) {
        for (int XGOHjUUTVRGZrGxl = 1540512142; XGOHjUUTVRGZrGxl > 0; XGOHjUUTVRGZrGxl--) {
            KpszChKWxPmusH = KpszChKWxPmusH;
        }
    }

    for (int PlcyZxrF = 570003131; PlcyZxrF > 0; PlcyZxrF--) {
        HTxPCafTj *= HTxPCafTj;
        KpszChKWxPmusH = KpszChKWxPmusH;
        KpszChKWxPmusH += KpszChKWxPmusH;
        HTxPCafTj = sVJnuG;
        YdHLhOEk = ! YdHLhOEk;
        HTxPCafTj *= HTxPCafTj;
        HTxPCafTj = sVJnuG;
        ItBoXmjfqjrdEw -= ItBoXmjfqjrdEw;
    }

    return 644999714;
}

string XfmMPI::kKGFpMpqVMmfP(int oJfOjm, bool RbXzfzCrflSoR, string LIuetEfK, string TQMyawTeULOyeFK)
{
    int WJMGpYbfnWkd = -564426235;
    bool GNChdHBOh = true;
    int HNmMQoypIf = -1098951706;
    string QZqCAQTo = string("BGUiLebnfzivodzJTxgZSefWxZtxhWxXyfXZtDduZapX");

    if (oJfOjm >= -564426235) {
        for (int kbPrrJRJv = 1749381369; kbPrrJRJv > 0; kbPrrJRJv--) {
            TQMyawTeULOyeFK += QZqCAQTo;
            WJMGpYbfnWkd *= HNmMQoypIf;
            LIuetEfK = LIuetEfK;
            oJfOjm /= HNmMQoypIf;
        }
    }

    return QZqCAQTo;
}

XfmMPI::XfmMPI()
{
    this->NlXqVOoXo(1418500267, string("YcfzxHUmoandfydhvwlEUrMgdbwYVbiKDibzFxRqDmhedGvVXVFQivXbApRJtBVrcBfOwfGCttZpoZrfJDPBsuLRxNqbOdvGAuZUwMbq"));
    this->spUqWTeQWa(291339.2581772935, 2051507713, string("BBRYSDdnVPuRGZaDOMiQpSvfrXMytNflPdbQGJjkXjwUghZEqbAUUQDTtAIfjDoFGITUBbehKEVYuelLfpxbMZJKGCUMBvxHgljdtnHutPFLiCTEuETIbNvShInOpBRZWKWTBiFmABppWLDXxZiXgdJhtYWRWniRzmFYIXllZnRrSstRoBv"));
    this->ecQjyQwesRz(string("lpymjdJIvYdwjAVhWmrZVvuIRvxAiRFrGdlFLHLbIBTgXGJujKonlNyLYVBgzrrNzmCLakPdBLGlpQsVxwbpUJUnfhzuSqGHNEAjspczFUFAWAJludOWwANGkwZAzlJmZUaPYNLUxXftSzhlCofJKwbYxVAKKtckwjmiQZGCPVQQfOlkNgHfhxFNFkBFIqEKtdgjhIBLsfwuFWRcZBRtrJozTjDYDptDJcCJnnYwmPWN"), 356275.46405189834, -674679.2020132341);
    this->MGdhfk();
    this->IyFsdosPUb(string("uqJoYZkkzcQcZdBEdFzvUDkYKPardOVrMarwwhShMlzpujufIAfzqMndJpeZrmzZGsxbEhESWtaylACNabqJKzjOCszJToPccFuVFZHquViQYKJUnVgSLvWlSuuSMncGhZAvHqZwhPfFTigwTUSFuafnCRjlWhmOtkFmPdppuPdUFTvUHscROSqKjnrdjmefpKyGrdAxbKejgBepHYWkahgCoUJxPuvTojYK"), 625429.0357557397, -853734.5060082284, string("dOCRdhSuPXsXkdeBEMTUWKKDLbaHTSOuLNciCzOodUNBaxUtpjTAnWttRklYWQgnaAUYeIkubwjYmoKLQXWRIuRJHqmGVZuaTbSZSrBERiVLBShRvMRcFfcXExgMAeEVbOEPvifAaoaetPhRvEwuElprqlQGnbrprxuUTTOcLdesxHufMJTNnVhzMbkjZDsDzh"));
    this->coMDuoOdd(-287026829, -19454.52079393747, 1733842401, false);
    this->eTZdFWoWlQGEusXG(-966764.9212547108, -872420177);
    this->EUHgmDDDZiuzuMs(true, 24811.805452474386, -639053.7263266668);
    this->nUCKbegGWRPZynk(string("ydVMOIrPQlssWxaZbJOaguQkuPmolxuGSxFNChBxRPgeyzmbRuwvhHqznWmyULMubDLyccEdKRsoGJEMJbrFAmp"));
    this->uePYErznXhpP();
    this->njtZMLMMZYUD(false, -702732.245220509, string("nFQSpjGhmDiMWdScpwqaHsOisQDYMbJYhGhBHiwMplDDdCrEIvfDqRbyqFsSqTESSFZhxyesBqLkjKYvGQsbIaeFgxPSrazKekVwzHcalx"), 48279.88065188609);
    this->kKGFpMpqVMmfP(439965876, true, string("qRaOqOPoiSDptiYSfbJjoQDSNQIykbTDqbNXzeTXbXBorxOOnRyabojKyWQKXcKZyzlwUBZodpCKAbbDKvbExNegrSipGNcUrVgfmyqZqUbyQMcPjSTmbrsDpqoKoIIpRDpyeCIubiFvaltMB"), string("vsdWlXlMFcuujycpWrxcXkqRCLOFiRCArqcqyOPVXEPeOYeoDzmxxuiXJHknALYSvATCCsPibQliGagtOZZSddUWdGTFyIRhkABQTycYzQkClXklmAjMvvgwwpXCsISwqlNl"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ORyFR
{
public:
    bool GKYYtXQ;
    bool UpmOXrTCEXwk;
    string UhFyj;
    string onuzS;

    ORyFR();
    int QctaAExBVthrKB();
protected:
    bool AVUeuaWsJtCJlD;
    int ylnrNz;
    int oKUMprgvzLpLwX;
    double kRVEJGqVZeE;
    bool AJsDGqRsdjrdmI;
    string JMYMFGeDyZxzIGz;

    bool vjxaKs();
private:
    bool rcUoyCC;

    void yZwTZpLqqJaJnX(bool jdXghgAhJEdqQ, bool RrMHfloZloWzASIw, string vrQsNQyOoumNsBPA);
    int LfeKYIHB(int SPPDwVUyvBw, bool ZbpyTrj);
    string CMjSeEOjubTOKg(double dktpXfnQSwOakqAv, double kjySlLv);
    string ICiAaEl();
};

int ORyFR::QctaAExBVthrKB()
{
    string neESM = string("ZnGmxROCIstDBWUdYUvkVQInzAZBKGoiRKUUlbNDVOa");
    double BxFwGL = -411262.7685986817;
    string wAStraNEmMxZNdH = string("bXktKnSDGQGcWvcevkFmeRXljUCmbdfyHFBEdslcJhHddtRnzRDMxNtCnySvRwUBfgWVLcxaBNPoJJlUjajSSUCXffLHlVxMqUbewCynxAsBLcDuMEsETTknRRERuthCKHlp");
    double ZloZny = -26508.9032669769;
    string gJNnoNLX = string("MnDSRJohxxMyOmOGUHTWgoeLXgNEVZiiOruXHDffXnMdasLNUlOhHggeZxjwrvwZYdEPBgSeoTpQoARqMlRGdRMUEJsTIyMavEvxhhRcNCNQXTJiIJWBgJLdTpoGtMPWGVAAckciMcOOobj");
    double grkDiIw = 749866.9500400351;

    if (gJNnoNLX < string("MnDSRJohxxMyOmOGUHTWgoeLXgNEVZiiOruXHDffXnMdasLNUlOhHggeZxjwrvwZYdEPBgSeoTpQoARqMlRGdRMUEJsTIyMavEvxhhRcNCNQXTJiIJWBgJLdTpoGtMPWGVAAckciMcOOobj")) {
        for (int tJmfEZO = 1932860227; tJmfEZO > 0; tJmfEZO--) {
            wAStraNEmMxZNdH = neESM;
        }
    }

    if (wAStraNEmMxZNdH <= string("MnDSRJohxxMyOmOGUHTWgoeLXgNEVZiiOruXHDffXnMdasLNUlOhHggeZxjwrvwZYdEPBgSeoTpQoARqMlRGdRMUEJsTIyMavEvxhhRcNCNQXTJiIJWBgJLdTpoGtMPWGVAAckciMcOOobj")) {
        for (int hrfEOtHyhA = 1891828696; hrfEOtHyhA > 0; hrfEOtHyhA--) {
            wAStraNEmMxZNdH += neESM;
            gJNnoNLX += gJNnoNLX;
            BxFwGL = ZloZny;
            ZloZny = BxFwGL;
            gJNnoNLX = wAStraNEmMxZNdH;
        }
    }

    for (int BMoJeoUr = 924983162; BMoJeoUr > 0; BMoJeoUr--) {
        gJNnoNLX = neESM;
    }

    return -249209657;
}

bool ORyFR::vjxaKs()
{
    bool EqWXxkgKlpnWqU = true;
    int rbpcCE = 1820843269;
    string PnbqmhB = string("fYJEylGbARmVdgvHyFZgYCAYKfrdBdELeBUfCPyMePmGnZflxqLBJqTwxgexsaTHGzPjnoXnnlIkeZiiwoaFDPNAcjyAYzWwitGviKFIlQuDFJJupmxNRSAfJlJbMHtAOianJZIiJzXZJpqnwvbDikpvdyXXUKUQNZutkSHqhtyxONREptUjLVAIbzBcBatbfHVoBdsgwZtBoniHxufvXaNlUJLjwufSdQU");
    string BRSbntbs = string("RnIggHGvNjTufffkhCcVajKDjyLhHbppGnKJfhxOXuGEHTVBvcoMThNGJKyuCNfTUlONgpmcJkDi");
    bool RZuDuTlmxzzPhG = false;
    double IYRqEwtFPLaAi = -854766.3258525585;
    double aijFRrYo = -255691.13967937767;
    int hpuMdpvvDaFzMT = -1785614837;

    for (int cBkjcUzhrGYBVZw = 1807537505; cBkjcUzhrGYBVZw > 0; cBkjcUzhrGYBVZw--) {
        aijFRrYo -= aijFRrYo;
    }

    for (int PVnjsjmLK = 646877490; PVnjsjmLK > 0; PVnjsjmLK--) {
        continue;
    }

    return RZuDuTlmxzzPhG;
}

void ORyFR::yZwTZpLqqJaJnX(bool jdXghgAhJEdqQ, bool RrMHfloZloWzASIw, string vrQsNQyOoumNsBPA)
{
    bool qlXMSMPhw = true;
    string zBEdPRCcax = string("cpeqQVuYMSPPcyVMC");
}

int ORyFR::LfeKYIHB(int SPPDwVUyvBw, bool ZbpyTrj)
{
    string YAeFVJ = string("CSpDXKqWOPDXoGargEVrvGNOhhahrxHsoyBrpdRmmTCVYAKtQaqBtIThNovZYYGckAAvKGfmLEwkJULgO");
    double ikdSFXbtUmez = -171339.26358386202;
    bool tCGKlatlJcfzxCsh = true;
    bool RjixIXeJcXpuYOVG = false;
    string FUudYwZAh = string("VIRbRItIwqLbDnqftRCMTSgHhmBvaqXmOEwxJkHTUMWDACsRDCnT");
    string BJjYOHm = string("qmHwFqyastNrJNgGxOrSiRByxlgmgpgxOZHudwIYJOViXuMIQsIDBXQTKtOmIMtSXczEtgRXLVgAD");
    double VBnVtqqzKHreqqFL = 584828.6084597607;

    for (int UZgSQifvFKgK = 92995294; UZgSQifvFKgK > 0; UZgSQifvFKgK--) {
        continue;
    }

    for (int YonSdtVYGeZeXob = 1865736631; YonSdtVYGeZeXob > 0; YonSdtVYGeZeXob--) {
        VBnVtqqzKHreqqFL = ikdSFXbtUmez;
        RjixIXeJcXpuYOVG = ZbpyTrj;
    }

    for (int zeCTogRj = 1498908359; zeCTogRj > 0; zeCTogRj--) {
        tCGKlatlJcfzxCsh = ! tCGKlatlJcfzxCsh;
        RjixIXeJcXpuYOVG = tCGKlatlJcfzxCsh;
    }

    for (int RPGNDZfSIztCMBc = 2079153826; RPGNDZfSIztCMBc > 0; RPGNDZfSIztCMBc--) {
        continue;
    }

    return SPPDwVUyvBw;
}

string ORyFR::CMjSeEOjubTOKg(double dktpXfnQSwOakqAv, double kjySlLv)
{
    int CpjBjnMyzU = 301500503;
    bool ivsXRngEJaBvdQOo = true;
    bool fqYIhO = false;
    double AkrbMeJMgpFAz = 812283.4812342522;
    int fplOMnWuqfs = -937716867;
    bool ujwqcY = false;
    string YSZiplxjhxFz = string("fLOKepEzakxMIgXeYBidceHLupMfqeKwtNWrKKlvOqsTnfzZpaKQfgGiNBQDDAXouMkoBAQodTjVTyFROoGggwvnDBMWUDpvAOfdamnncHzQiopPjoEH");
    int NGMocFTUA = 1619223361;

    for (int NciZqMN = 399712320; NciZqMN > 0; NciZqMN--) {
        continue;
    }

    return YSZiplxjhxFz;
}

string ORyFR::ICiAaEl()
{
    int vErBT = -2058865423;
    bool nEwMqNZ = false;
    string sCLorwcQI = string("upOmZqFboOsT");
    double NoqSEbcvdmJb = 256469.13064936787;
    int NzkhrQFthY = -396601670;
    bool UfiiTGvuw = true;
    int bLlbsHnP = 1036562586;

    for (int CCggTXAv = 523581737; CCggTXAv > 0; CCggTXAv--) {
        NzkhrQFthY += vErBT;
        NzkhrQFthY /= vErBT;
        vErBT /= bLlbsHnP;
    }

    for (int HkSeLGciw = 678961595; HkSeLGciw > 0; HkSeLGciw--) {
        vErBT = vErBT;
    }

    for (int KfDzHa = 1043652148; KfDzHa > 0; KfDzHa--) {
        vErBT -= vErBT;
        nEwMqNZ = ! UfiiTGvuw;
    }

    if (NzkhrQFthY < -396601670) {
        for (int AoVQbBq = 602641896; AoVQbBq > 0; AoVQbBq--) {
            NzkhrQFthY /= vErBT;
            vErBT /= NzkhrQFthY;
        }
    }

    return sCLorwcQI;
}

ORyFR::ORyFR()
{
    this->QctaAExBVthrKB();
    this->vjxaKs();
    this->yZwTZpLqqJaJnX(true, true, string("bzcvOWTWjnWuMiEokAjZeSXxMomwnXKbqHdtyXhpaHgPkzpKMQbbRgnZqOrEDjYoWjwyFlrIebJOSzfoGvPOOvVF"));
    this->LfeKYIHB(320525282, false);
    this->CMjSeEOjubTOKg(-1005202.76002847, -977963.2983488411);
    this->ICiAaEl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rXWGAKr
{
public:
    bool pIhibb;
    int aNdIqsSlVPVJIL;
    bool kBkPhEBIhZ;
    string SOdWXgeFJoTlXMAv;
    bool GqDedtGCIYMlDH;

    rXWGAKr();
    string muyzQMnEP(double UnFsHKYZvkaQA, double oougeHEZpcTYNe, double FSnrC, string rbGcAAaRdUR);
    bool FuuLfbTjeXlwBISl(string mvWyOUmrZougk, int QEoTSTwtUFu, string XfzNhIzLCnhbjbZE, double qVxvkFSvWAWcOvR);
    double dnYBpSkqPDmUlM(string YbyEaWJxVdiZa, bool Eubbjb, double kHJtys, string gmIvcRLDuNAaG, bool pdbSHjFS);
    void mdAVsqjAgSPw(int kOaGTXqfmUJdCSgi, double lOJTljcvwwATNd, double PYFJh, double sdqggLYDUszQTId, double XgsKyf);
protected:
    string tvBFI;
    bool jsSsKFjwL;
    double wjUfOcBzmQz;

    double kHNjDQk(bool IWrVFwbtNIfehUS);
    int kpyiXUXnI();
    int olvisRGvKmQl(double JlFdymaG, double kFkuH, int LJcdHQknnQjjSy, double dVDqDyp, double XHOSQqpqBQBCEwrJ);
    void EzNVfPbWxKpGvyby(double XAJqsdXQ, string oPUPJmVRmXjKO, bool WHbJSSjnH, double CTFrDIWFq);
private:
    bool sdlRHIdvC;
    string twlvlvGrtxivYN;
    bool NIwROkLpZW;
    string dqdfYHVNIIg;
    double sWpyHwQrA;

    void ieimQAlIJ();
    string upqSOgfY(bool ChpIx, string oOXPTjgp);
    int ZukMxHBTJHtoDk(string xchwZOoOF, bool jQlNQoQjCrFWfd, int ZBcbOYZoeMwIrl);
    void ZOjvXTsn(double ZGyDxmKiY, double wKWTMhahjrFvJV, string firfaO, int hZDpnlijFqjPXKO, bool ECJibIBpCkCTHdLQ);
    double SRTiBzjfEIhbRr(bool jjfSxh, string FwikSsdipWz, bool RbrhYvLzgPAcFPiQ, int qmXAwEFEqgUMZxkg);
};

string rXWGAKr::muyzQMnEP(double UnFsHKYZvkaQA, double oougeHEZpcTYNe, double FSnrC, string rbGcAAaRdUR)
{
    string PacZNmYpVQk = string("oWQICEFyPNgpFJZppERYtTMyJJLngrRqPdJLBmzTUjKbAspCTadTTBZVnWdKGlwRckXBBnOjjHvVzOtgLwruHizO");
    string pdEkZRklvJggT = string("bYGDgMCwvJuzsQnvjWfJLqaSvmzdpJgBmoflCvJWunKTzYHxOgKOfRUPnMcpbqIWYdoxVpWlmbSYSTguEzlRZoVxWWSZDrIYpBerGbujVuJPhbhPRBJtpUAsWZsKqBLpMtTQpXtYbdyFOUnIpjVYMUGXIWLNqdikVlFrmwHifuvOBGZz");
    bool zspvBdW = false;
    string zDizexWdvYarOj = string("icRHNGRCTqkWtZszpphAEOFTnxqiRgTwQtZQlUaiSyXMByVinmGBOzCefvjmDutzAKvaCLMKJIeXdHrQqntQWkwougiwAcauaVxhrNqPsvsCmbPuBvRBZltElGWFHgKXlknROcQQldwNgWWoorrmpwtSCVoHwbFnHEjYsbzSnvOMDNcicNNdnREdaeJFdlhEZUgPQRfNsTOLNt");
    bool nlcgwjUzPg = false;
    string dJwBxpHDYdxAq = string("MoyCCfPQIJZIVhjZAKGhblhqZOGWwWtjBxLQeEVHiQgERCADUeqUnYeNNSWZZeJviYAIodaHncTEpdJXVVYKsqpYVjpoYCj");
    double TZyKUHANFGlqF = 25216.988746251915;

    if (PacZNmYpVQk > string("bYGDgMCwvJuzsQnvjWfJLqaSvmzdpJgBmoflCvJWunKTzYHxOgKOfRUPnMcpbqIWYdoxVpWlmbSYSTguEzlRZoVxWWSZDrIYpBerGbujVuJPhbhPRBJtpUAsWZsKqBLpMtTQpXtYbdyFOUnIpjVYMUGXIWLNqdikVlFrmwHifuvOBGZz")) {
        for (int XElns = 1909393600; XElns > 0; XElns--) {
            oougeHEZpcTYNe -= UnFsHKYZvkaQA;
            zDizexWdvYarOj = pdEkZRklvJggT;
            zspvBdW = zspvBdW;
            oougeHEZpcTYNe += UnFsHKYZvkaQA;
            rbGcAAaRdUR = dJwBxpHDYdxAq;
        }
    }

    for (int cjQetnWBLhIXw = 1317511350; cjQetnWBLhIXw > 0; cjQetnWBLhIXw--) {
        PacZNmYpVQk += zDizexWdvYarOj;
        oougeHEZpcTYNe *= TZyKUHANFGlqF;
    }

    if (TZyKUHANFGlqF < 25216.988746251915) {
        for (int TDthKIprUaLsKood = 1111299240; TDthKIprUaLsKood > 0; TDthKIprUaLsKood--) {
            continue;
        }
    }

    return dJwBxpHDYdxAq;
}

bool rXWGAKr::FuuLfbTjeXlwBISl(string mvWyOUmrZougk, int QEoTSTwtUFu, string XfzNhIzLCnhbjbZE, double qVxvkFSvWAWcOvR)
{
    int DOjfpHh = 1835408360;
    string JhdiCvtSWCCl = string("DjZCwNsbZURZrRvSldmyCTIwClPQDyFlFZlktLDLtYfaJNgDhuVvzFcfsYOKpZnlkaMYksDsumigczgvhBOJlqQxApXVBclPFhqGgtrtSIwKJUVKHHZKobOLUxTYFgFagHXREtsxGqkEbZlNRhVzuFdbMifOcLtTAhucMMUOuDrjcrgkJLDGgNnbejTXPHRVntwCnTxIMIPQQDEmBumZnaLtBmm");

    for (int uBgMjZLmlVs = 402548858; uBgMjZLmlVs > 0; uBgMjZLmlVs--) {
        continue;
    }

    if (JhdiCvtSWCCl >= string("uzxNXDNBXBnaAOshcEEXmjnfSNhAhuBEHbzInJewDSKYFWHZipFpQiCsKTsSUbiaTF")) {
        for (int fdhMCb = 1638363310; fdhMCb > 0; fdhMCb--) {
            qVxvkFSvWAWcOvR /= qVxvkFSvWAWcOvR;
        }
    }

    for (int EJdydFOIg = 2042428378; EJdydFOIg > 0; EJdydFOIg--) {
        JhdiCvtSWCCl += mvWyOUmrZougk;
        JhdiCvtSWCCl += XfzNhIzLCnhbjbZE;
    }

    for (int JLtFVWbh = 1614207711; JLtFVWbh > 0; JLtFVWbh--) {
        JhdiCvtSWCCl = JhdiCvtSWCCl;
        mvWyOUmrZougk += JhdiCvtSWCCl;
    }

    return true;
}

double rXWGAKr::dnYBpSkqPDmUlM(string YbyEaWJxVdiZa, bool Eubbjb, double kHJtys, string gmIvcRLDuNAaG, bool pdbSHjFS)
{
    double oqfrlNrkbqY = 320276.88579893496;
    bool cQxaIScYuCpsxi = false;
    bool OVCeVnFRSXrJwDir = true;
    string mgBxrhoOSOcbLQ = string("WjPnecGbICARChfDVNwBPkrlPIejDxFVDzHbhCSDjjsjbRwzroWdLFoSHo");
    double GTnNOaRokvz = 2420.2017334266084;
    int toXkH = -1946793882;
    bool KPyNvlhrXRm = true;
    bool yCIkNTgousC = true;
    string lxYMASnZL = string("gRFAaIaSjKPlQpctiDmbiXKFNdyZrxHwtNzgttWNWrEXIsaotYjyIMSRCovbghgnVMcGVaWNmSyBLVgdLZuSJGInjSQtNGElcfJfHkJDsMCgNXHQcIESrsGOs");

    for (int nIWhGIcr = 727504137; nIWhGIcr > 0; nIWhGIcr--) {
        pdbSHjFS = ! pdbSHjFS;
    }

    for (int YnEyGWP = 249002327; YnEyGWP > 0; YnEyGWP--) {
        pdbSHjFS = Eubbjb;
        mgBxrhoOSOcbLQ += mgBxrhoOSOcbLQ;
        yCIkNTgousC = yCIkNTgousC;
    }

    for (int hntEUeDhPWEJpC = 317073962; hntEUeDhPWEJpC > 0; hntEUeDhPWEJpC--) {
        OVCeVnFRSXrJwDir = pdbSHjFS;
        yCIkNTgousC = cQxaIScYuCpsxi;
        GTnNOaRokvz /= kHJtys;
        pdbSHjFS = ! pdbSHjFS;
    }

    if (Eubbjb != true) {
        for (int MSqGhTNd = 1361974341; MSqGhTNd > 0; MSqGhTNd--) {
            continue;
        }
    }

    if (mgBxrhoOSOcbLQ <= string("WjPnecGbICARChfDVNwBPkrlPIejDxFVDzHbhCSDjjsjbRwzroWdLFoSHo")) {
        for (int bubZYvhtc = 910561035; bubZYvhtc > 0; bubZYvhtc--) {
            gmIvcRLDuNAaG += lxYMASnZL;
            KPyNvlhrXRm = ! Eubbjb;
            yCIkNTgousC = ! OVCeVnFRSXrJwDir;
        }
    }

    for (int suOIz = 1835856457; suOIz > 0; suOIz--) {
        kHJtys = GTnNOaRokvz;
    }

    return GTnNOaRokvz;
}

void rXWGAKr::mdAVsqjAgSPw(int kOaGTXqfmUJdCSgi, double lOJTljcvwwATNd, double PYFJh, double sdqggLYDUszQTId, double XgsKyf)
{
    double xCLyHVZsy = 973081.5284918441;
    string TJHRNSS = string("THpbvHhKwzYVfNYXiLHhVQwlukEPfEfIvxwWhnRTdBwIKvxVOowOndawBiDbRWHzfxvarFYrjmJtnbQGdvvmqphrGvSPMRXusiuBAkDQJNHPtWTsFFsdWNGprbSZKflHSUtnfWVCutGOopjumPFKYvMdXQjsjhvhmzVYlTKRoGCYVCfrogNDouUWAlQWXzBYtlQxRwPSjexHxaybWLtzozcK");
    bool QlYDhNRmtCW = false;
    string qpkTsBvlzwbtAkjc = string("exLmXwKUGfetDFozLBguVcgZNyOqdQwGCQIzUpAXjqZAvQSnUoRDkLplIvZaATmwuJONZRWBgHFOz");
    int tQtrq = 1582373899;

    for (int ljqmKpKx = 819322214; ljqmKpKx > 0; ljqmKpKx--) {
        PYFJh -= xCLyHVZsy;
        lOJTljcvwwATNd += sdqggLYDUszQTId;
    }

    for (int ZZqXdLKiKMdFknqU = 1175489556; ZZqXdLKiKMdFknqU > 0; ZZqXdLKiKMdFknqU--) {
        continue;
    }

    for (int SmqmgTOVpJybeuS = 853364953; SmqmgTOVpJybeuS > 0; SmqmgTOVpJybeuS--) {
        XgsKyf -= PYFJh;
    }
}

double rXWGAKr::kHNjDQk(bool IWrVFwbtNIfehUS)
{
    int LxambMYHrkYBFO = -278731692;
    bool zIVWUsfgMoiwZzv = true;
    bool qGyZPmwe = true;
    string VgNMcoGDucXcN = string("wYMWSkNrTXnNfGNxxnRLjttUYCldWZRiLTGl");
    bool OOAkaZvHjwaafUZD = true;
    bool LzQgoiXC = false;
    int Nuwwa = -1991928574;

    for (int qALoVUqJi = 919941055; qALoVUqJi > 0; qALoVUqJi--) {
        zIVWUsfgMoiwZzv = LzQgoiXC;
    }

    return -447285.8651859843;
}

int rXWGAKr::kpyiXUXnI()
{
    bool niGmfEmAKfoajh = true;
    double UhRNLxxtOYVrhWv = -369607.87739888654;
    bool GIyhrBEMjoDZuAp = false;
    double aHRnzdXKDZwQ = -800912.1693691051;
    int TXjEiwTySfXEj = 659792651;

    if (aHRnzdXKDZwQ != -369607.87739888654) {
        for (int WkINhiU = 552460065; WkINhiU > 0; WkINhiU--) {
            GIyhrBEMjoDZuAp = niGmfEmAKfoajh;
            aHRnzdXKDZwQ -= UhRNLxxtOYVrhWv;
        }
    }

    return TXjEiwTySfXEj;
}

int rXWGAKr::olvisRGvKmQl(double JlFdymaG, double kFkuH, int LJcdHQknnQjjSy, double dVDqDyp, double XHOSQqpqBQBCEwrJ)
{
    bool PAvCmlbyTCj = true;
    int VLKUkiEOEZtM = 96713464;
    int xFkCpjneu = 140144009;
    bool FxyALcgympYot = true;
    int mDtIWSWjGrxprSgB = 1599779994;
    bool ZwLPSfwAWLAWLKS = true;

    return mDtIWSWjGrxprSgB;
}

void rXWGAKr::EzNVfPbWxKpGvyby(double XAJqsdXQ, string oPUPJmVRmXjKO, bool WHbJSSjnH, double CTFrDIWFq)
{
    double LBzyijBEknj = 191938.11846212958;

    if (oPUPJmVRmXjKO > string("dznIDttxMrZCDHtjmeiILMxVPCcWfXGYFWOgsqeaMmXSnzZHoxVOTvwFQZlxUdExwkCeJWgqTTAtvhIXnlooCDomvHATQRaVJvKxGFDWYYKDMdZgKyckXQTAOOvzVFCPrmDPrWoLWIdzoxYZYwhGHYQBrLNbLsMErYSEiWagaYKVuULgmWBTB")) {
        for (int AwGPGVVEmgISfjX = 458138068; AwGPGVVEmgISfjX > 0; AwGPGVVEmgISfjX--) {
            CTFrDIWFq -= CTFrDIWFq;
            LBzyijBEknj = XAJqsdXQ;
        }
    }

    if (WHbJSSjnH != false) {
        for (int ZbiXhzeFJmV = 127012242; ZbiXhzeFJmV > 0; ZbiXhzeFJmV--) {
            CTFrDIWFq /= LBzyijBEknj;
            oPUPJmVRmXjKO = oPUPJmVRmXjKO;
        }
    }

    if (XAJqsdXQ >= -953821.9520503291) {
        for (int VqMaLLXDoYECe = 1819618762; VqMaLLXDoYECe > 0; VqMaLLXDoYECe--) {
            LBzyijBEknj += XAJqsdXQ;
            LBzyijBEknj /= XAJqsdXQ;
            LBzyijBEknj /= XAJqsdXQ;
            CTFrDIWFq /= XAJqsdXQ;
            CTFrDIWFq = LBzyijBEknj;
        }
    }

    if (CTFrDIWFq < 514718.67983129) {
        for (int pHWIGqcGVKT = 145096859; pHWIGqcGVKT > 0; pHWIGqcGVKT--) {
            CTFrDIWFq += CTFrDIWFq;
            XAJqsdXQ /= CTFrDIWFq;
        }
    }
}

void rXWGAKr::ieimQAlIJ()
{
    double NhqVoOj = 543675.0005721797;
    bool XmgAd = true;
    string ZatdtaSwW = string("fSuedNsioQhWqUEHIPvANqdYuqfkGzPWeNYcXdrXGJDKTjzBFvfqrlbCGCcBsHKvAkTFbJJukUslWfExqPkcOvhAYhgZBQfTUPlKNcpBJuAFAoWzAzOTxieYAKHfTmO");
    int ZmUOQgdVLXJzG = -1364748040;

    if (XmgAd != true) {
        for (int zQsCdjjZMtxMApnl = 832429018; zQsCdjjZMtxMApnl > 0; zQsCdjjZMtxMApnl--) {
            continue;
        }
    }

    for (int jzzxuha = 1307125453; jzzxuha > 0; jzzxuha--) {
        continue;
    }
}

string rXWGAKr::upqSOgfY(bool ChpIx, string oOXPTjgp)
{
    int jumKZgLbYRXIuY = 1529415357;
    double HhdjYdsdDRTULtt = 317640.3076848703;
    bool ESvnL = true;
    bool EvAuheIbbwsVL = true;
    double joEOEvsGaXPlXh = 284512.7914856881;
    double ztofbGovFcikVpr = -17450.8449801044;
    int pGdCObvC = 630711875;
    int oYMYTcxWGc = 1907336169;
    string vxfCfQUqBPc = string("MpKyXgZYiwEiGigAhaczEFSNAbUJPyVeSygPQGaYwwDRZowUzskykZkQsrowfwpmSfwZOsJAXLLEmDeTKylSbQYLdtBPRKAPIXAhIcutZIuJuifRSzk");

    for (int BNJmqIgwsIKRObO = 967873429; BNJmqIgwsIKRObO > 0; BNJmqIgwsIKRObO--) {
        jumKZgLbYRXIuY -= pGdCObvC;
        EvAuheIbbwsVL = ! EvAuheIbbwsVL;
    }

    if (oYMYTcxWGc == 630711875) {
        for (int ITVFKnzjoWl = 376579280; ITVFKnzjoWl > 0; ITVFKnzjoWl--) {
            oYMYTcxWGc *= oYMYTcxWGc;
        }
    }

    if (ESvnL == true) {
        for (int cYsksEk = 852710080; cYsksEk > 0; cYsksEk--) {
            vxfCfQUqBPc += vxfCfQUqBPc;
        }
    }

    for (int YwleLLQVzxINyZa = 1435507137; YwleLLQVzxINyZa > 0; YwleLLQVzxINyZa--) {
        ChpIx = ChpIx;
    }

    for (int QjGueR = 1500768065; QjGueR > 0; QjGueR--) {
        ztofbGovFcikVpr /= ztofbGovFcikVpr;
        ChpIx = EvAuheIbbwsVL;
    }

    for (int CGgSBUzJTAFRp = 1908299370; CGgSBUzJTAFRp > 0; CGgSBUzJTAFRp--) {
        jumKZgLbYRXIuY = pGdCObvC;
    }

    return vxfCfQUqBPc;
}

int rXWGAKr::ZukMxHBTJHtoDk(string xchwZOoOF, bool jQlNQoQjCrFWfd, int ZBcbOYZoeMwIrl)
{
    bool nFliMn = true;
    int OuxmxUH = 1555457383;
    int FVfPPIYBBV = 1709162306;
    int JXGey = -1465360438;
    double HVSdGGkQs = 761651.2138880364;
    int HyjvnOJVMvRcwI = 221344060;
    bool UdwcygaHmIpGXm = false;

    if (HVSdGGkQs <= 761651.2138880364) {
        for (int ffIwySxXnwAre = 1812850358; ffIwySxXnwAre > 0; ffIwySxXnwAre--) {
            ZBcbOYZoeMwIrl += HyjvnOJVMvRcwI;
            JXGey /= OuxmxUH;
        }
    }

    for (int twdySuFyuMZKKTD = 498423709; twdySuFyuMZKKTD > 0; twdySuFyuMZKKTD--) {
        nFliMn = ! jQlNQoQjCrFWfd;
        xchwZOoOF = xchwZOoOF;
        FVfPPIYBBV -= FVfPPIYBBV;
        ZBcbOYZoeMwIrl -= ZBcbOYZoeMwIrl;
    }

    for (int FvbhZNXkj = 1032560104; FvbhZNXkj > 0; FvbhZNXkj--) {
        continue;
    }

    return HyjvnOJVMvRcwI;
}

void rXWGAKr::ZOjvXTsn(double ZGyDxmKiY, double wKWTMhahjrFvJV, string firfaO, int hZDpnlijFqjPXKO, bool ECJibIBpCkCTHdLQ)
{
    string dmqYsBRLILQ = string("DuCUbuZtePGUfSuinLcsRgcsMbczQviWnHlZDpptJmUSRvoCoSgWyovfPYMJeXntmDqWBJgiWrDWVt");
    int QsOzJ = -1036916227;
    bool BkoRHtbJ = false;
    bool DfITUGRuztIJIkgX = true;
    int BrhJBFoZv = 1700882598;
    int jochTmPYaedoTee = -19883791;

    for (int UhQqJpTlVbFm = 985162761; UhQqJpTlVbFm > 0; UhQqJpTlVbFm--) {
        continue;
    }

    if (BrhJBFoZv > -19883791) {
        for (int QGeJpwGfnrJXHvN = 171086798; QGeJpwGfnrJXHvN > 0; QGeJpwGfnrJXHvN--) {
            QsOzJ += hZDpnlijFqjPXKO;
        }
    }

    for (int WRikBxq = 1542154000; WRikBxq > 0; WRikBxq--) {
        wKWTMhahjrFvJV += wKWTMhahjrFvJV;
        hZDpnlijFqjPXKO = QsOzJ;
        hZDpnlijFqjPXKO -= jochTmPYaedoTee;
        hZDpnlijFqjPXKO /= QsOzJ;
    }

    for (int yoqouPol = 1336580513; yoqouPol > 0; yoqouPol--) {
        continue;
    }
}

double rXWGAKr::SRTiBzjfEIhbRr(bool jjfSxh, string FwikSsdipWz, bool RbrhYvLzgPAcFPiQ, int qmXAwEFEqgUMZxkg)
{
    bool VUAwVTm = false;
    bool sDUcbK = false;
    double GASaoTNiUSyQR = 653588.2188773967;

    return GASaoTNiUSyQR;
}

rXWGAKr::rXWGAKr()
{
    this->muyzQMnEP(66623.08604040602, 650391.4670105368, 732855.5413352359, string("TGknCeEZbQPNrhGpFJSlFlZNIAveimsKwjGdjESFaGVAyrJKvVxUhSeFpcGEgLzJTHFqJolBsfyoYrrrWfOAArFBPHOYuwpreVJXlkGExXlMGqUaAGbCJKwMKAPOXIRIwUWYFygZDuFJpLcpeewHvXRLIlenkKlIWRbrm"));
    this->FuuLfbTjeXlwBISl(string("uzxNXDNBXBnaAOshcEEXmjnfSNhAhuBEHbzInJewDSKYFWHZipFpQiCsKTsSUbiaTF"), 1035385234, string("aHHcgJULriEEvuPyTlNzZjiYyKqPiOJYBUeOmH"), 266155.2967320241);
    this->dnYBpSkqPDmUlM(string("PFFwKetoWMOiAVqwsYvuoquqcSOxaYKMEkDaxLXZAebjnXxEipjW"), false, -95147.02105590832, string("xSsfKIseGUWlGmMeHywcdlvJqKenScXbCHXiDuKLNKWmpIdmQOgdrsWWv"), false);
    this->mdAVsqjAgSPw(-265598238, 736683.4974017182, -980978.9978450258, -746846.4200639388, 568079.5018885034);
    this->kHNjDQk(false);
    this->kpyiXUXnI();
    this->olvisRGvKmQl(586954.5494436382, 250968.85368881366, -1819567198, -653665.5730308051, -68722.59184937943);
    this->EzNVfPbWxKpGvyby(514718.67983129, string("dznIDttxMrZCDHtjmeiILMxVPCcWfXGYFWOgsqeaMmXSnzZHoxVOTvwFQZlxUdExwkCeJWgqTTAtvhIXnlooCDomvHATQRaVJvKxGFDWYYKDMdZgKyckXQTAOOvzVFCPrmDPrWoLWIdzoxYZYwhGHYQBrLNbLsMErYSEiWagaYKVuULgmWBTB"), false, -953821.9520503291);
    this->ieimQAlIJ();
    this->upqSOgfY(false, string("ahfYYxGVbRhQNQKEeXnTRtYEFNhEivCXwVZZApCWbcculXJdVsgSbVJbKFLzVKcwHDCPyvQPilPaSdAQrSNcyvXwSvZIqCgUxqXZVykyUYLqqddALIfjhKCSwuJuJPUeEayzFYwikoikVxJdWiDCMYZOsjKKERBvxcTHQYpRimNcxlRFvTHxyvVxZTsDjFaAvnZyjZlYcnHGGeHjtCsVeNUpJ"));
    this->ZukMxHBTJHtoDk(string("gRpOAYtZlcFsYzwMSuKGpTPJnkdpMDvLzLocqJGIFWqJqKLeHiVTzykpwlVeljUfmOJawigaWLrvChswAQUFVMKyRfwDsOULBswCFLIMsU"), true, -730123537);
    this->ZOjvXTsn(-303741.21588634135, -419689.62648546207, string("EyHPtkDbQiCdmnTajUNZepPuGTQiyFAxfeJwTjrVkzDZJtSgyFqsAxAaQ"), -2024167869, true);
    this->SRTiBzjfEIhbRr(true, string("YTZbZRvYawijDPlfjEKuNOsWWxDBlHidZwefWgRyxJurvmBTnrAAoBQLJRLXxqLsZy"), true, -1358599221);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class laTMZCb
{
public:
    bool yWRucqqCg;
    int hmzZS;
    int RgnOSEWVqqGLt;
    bool XCGonCNhptMqHfWd;
    double UtjqcZyRxES;

    laTMZCb();
protected:
    bool LPtNUlrw;

    string uqDNFS(string LvAQvUMZoAjlFEU, bool zHVeUMLgr, double dtPmCzTprZ, string rzMMwOAjClIGOu, double uiscBbkeawEDWRm);
    bool QcFLqZJCTAbXrs();
    void gSkXeVUS();
    void wKvbJjNBvYPl(string gBsWHbXfKR, bool LlcDELDtyoldkZAt, int djzdg, bool qDzqJmvjdCZBKI, bool ivJUFMJNJnYHsW);
    int imymtZAVpaRcsCR(int EKJeFDnJuYeV, double UrjzeSvMg, int MjrdfLgfgwjSQ);
    int lGOxduINAv(double NnOaLo, string DJqvkEkYRnpzgC);
    void QGHhrRVLGB(double zTdboUIPZAgxDk, bool bTNekuYUr, int tCnHfUaZtk);
private:
    string hgdCggcvYuAxP;
    bool FdOQrewoh;
    double OxtYYxyUUnCRA;
    bool CFHxfygYFWBCmDX;
    int NMCLQzw;
    bool GYCyokVhZmNiaud;

};

string laTMZCb::uqDNFS(string LvAQvUMZoAjlFEU, bool zHVeUMLgr, double dtPmCzTprZ, string rzMMwOAjClIGOu, double uiscBbkeawEDWRm)
{
    int QDxud = -686405960;

    return rzMMwOAjClIGOu;
}

bool laTMZCb::QcFLqZJCTAbXrs()
{
    double iGYgwqe = -588605.0785551857;
    string jiyTAsTObGAPXCvK = string("xi");
    bool eWEffwp = true;
    string AZjJVPqyIIkRy = string("sieSKFeEktGhtnNSgiVBHskBKopxIZllEIdjxFrHFcUIvrhYmcvLqXFUnEQWeYNOpSYfeBDWuffduhfzSPHvDuahXGFnRoybaUhylVsRUXsXnToGxKzHsHnRvvkjZRRnvGFDYBvOzKMuEwfKdjEXZDbqYXMmWSucrBinpmOfzoLBYQHFiMOeYcZlXKckgpsbGqEM");
    int vswHpSczRoOSTo = 1000417650;
    string vLXzGnyZLeOvB = string("XqmPPSnMYwhLGlIxKFMsFmrXtySDbHNaHCSKOGoRqhlCBoKNfdiLvlVJOxoCJAEzZojHuNueFTjREF");
    bool hCuyeqnz = true;
    double hZpKnCafKCa = 771928.3064652049;

    if (iGYgwqe > -588605.0785551857) {
        for (int ZfnTpPzUShKjD = 928109303; ZfnTpPzUShKjD > 0; ZfnTpPzUShKjD--) {
            vLXzGnyZLeOvB += jiyTAsTObGAPXCvK;
            eWEffwp = ! eWEffwp;
        }
    }

    return hCuyeqnz;
}

void laTMZCb::gSkXeVUS()
{
    int XpTLpaqIGQ = 599510761;
    bool VPdfXKpYBEjzf = true;
    double HaOSgTYRPUqoabD = -511940.5358173403;
    double MffWTz = 264578.3501052161;
    int zNopYkhQbjsOJVon = -1665509810;
    string RiwmVVHEh = string("MjxgJfPpZczxpFvqaMVKCKhuldzlwABppwIBVqgJoeGgDiSSehvqQSXlhUkidjUdBCjCCUyTvSEiXIuOkWLpTTWfsdJOmUliavz");
    int DlGaQgMUIs = 432774200;
    int EpkkDRXKyMcpf = 1997017207;
    bool XBpyNY = true;

    if (HaOSgTYRPUqoabD <= -511940.5358173403) {
        for (int fnLmFgnGyshNCsIH = 968257473; fnLmFgnGyshNCsIH > 0; fnLmFgnGyshNCsIH--) {
            zNopYkhQbjsOJVon += zNopYkhQbjsOJVon;
        }
    }

    for (int oJVCiOPOADP = 2009583153; oJVCiOPOADP > 0; oJVCiOPOADP--) {
        VPdfXKpYBEjzf = ! VPdfXKpYBEjzf;
        MffWTz -= MffWTz;
    }
}

void laTMZCb::wKvbJjNBvYPl(string gBsWHbXfKR, bool LlcDELDtyoldkZAt, int djzdg, bool qDzqJmvjdCZBKI, bool ivJUFMJNJnYHsW)
{
    string cTovpOzJ = string("TfLwabtCHSAuDlxESTsomvjjqFyKWnejMXstRMRFMkgLxDReXcYfxZwDjfEFdKIrmDUZcDdteaqVWdzKGQBeraluaiLfRXzAMKpffEETNbbofCBAQcskhzqGgiQmTeZqXpoCtlrvmXBMaJsLXElGQhZj");
    int JjjfUuty = -1376716476;
    int hCvnLWQDyKwrpCq = -392164438;
    bool SDgRiGUMGbXdIYH = false;
    string kBTyhVu = string("BHTbPNTNrfjFfwnRVczcbmMZPGViTYvXurxTwXntFycVFDwDZaCebvIsyPOabzxmVrmyKYqBhwmZAAmDXfFwzjxDjjYaGRpVboonIoMBkoMbCoFExATCRoRrJbFAMZcwOmUMcijbKa");
    string mnvxxFhlTKGbjzIq = string("YotbTCpGZWAQyYhZdHtrKjmGoBwHLYgPvFNZJZrfeRSKianVUmSfLzWxHkEdgbKNnTuKhNFOyvbaglREpDZvHXrxBaFlCsrAqFFsTWOdrBLvSSFlCpiccJzvYTZaXtlwYqlkcEWBkxiicgCDKVArjHWqIhtTJSgFrXTLBgHDNEbvbJnrnizJcjvdWYrPw");

    for (int pWAgKBxZeVYkMhkH = 1217347768; pWAgKBxZeVYkMhkH > 0; pWAgKBxZeVYkMhkH--) {
        mnvxxFhlTKGbjzIq += gBsWHbXfKR;
        ivJUFMJNJnYHsW = ! qDzqJmvjdCZBKI;
        gBsWHbXfKR = cTovpOzJ;
        cTovpOzJ += kBTyhVu;
    }

    for (int tRutdxaUEetfBViX = 1643516835; tRutdxaUEetfBViX > 0; tRutdxaUEetfBViX--) {
        kBTyhVu += cTovpOzJ;
    }

    for (int ojxjLJeXtaDd = 2107487786; ojxjLJeXtaDd > 0; ojxjLJeXtaDd--) {
        qDzqJmvjdCZBKI = ! LlcDELDtyoldkZAt;
    }

    for (int xvkcnqcMsa = 1315585106; xvkcnqcMsa > 0; xvkcnqcMsa--) {
        djzdg /= JjjfUuty;
    }

    for (int cbLOMjdrRdtTVP = 656091723; cbLOMjdrRdtTVP > 0; cbLOMjdrRdtTVP--) {
        gBsWHbXfKR = kBTyhVu;
    }
}

int laTMZCb::imymtZAVpaRcsCR(int EKJeFDnJuYeV, double UrjzeSvMg, int MjrdfLgfgwjSQ)
{
    bool EzliZ = false;
    int FXudFFaZv = -1141971175;
    int YKxHQYPfZfxK = 972173891;
    int lTmGvjI = -2035601372;
    double GJQkziiLECXzZcl = 863249.5155475566;

    return lTmGvjI;
}

int laTMZCb::lGOxduINAv(double NnOaLo, string DJqvkEkYRnpzgC)
{
    int elAlulKerGvIKkxw = -1728658986;
    bool NLHDDarEvitMh = true;

    for (int VpnLuDMTgDQYjhu = 1044512259; VpnLuDMTgDQYjhu > 0; VpnLuDMTgDQYjhu--) {
        continue;
    }

    for (int VUkva = 1495869869; VUkva > 0; VUkva--) {
        NnOaLo -= NnOaLo;
        DJqvkEkYRnpzgC = DJqvkEkYRnpzgC;
    }

    for (int bIlHG = 1019247390; bIlHG > 0; bIlHG--) {
        continue;
    }

    if (DJqvkEkYRnpzgC >= string("GZomrtHwjGOUbGQQdDHsFBnHPqpJUtRxeJZiRrDNhDVLZxyAkFoFRpiWbrhJkZKXFbMHGpcSCGzfPXXVMFuRMFPoPaiSejr")) {
        for (int sKOQIto = 1023691471; sKOQIto > 0; sKOQIto--) {
            DJqvkEkYRnpzgC = DJqvkEkYRnpzgC;
        }
    }

    for (int KQtKbulXh = 266830516; KQtKbulXh > 0; KQtKbulXh--) {
        continue;
    }

    return elAlulKerGvIKkxw;
}

void laTMZCb::QGHhrRVLGB(double zTdboUIPZAgxDk, bool bTNekuYUr, int tCnHfUaZtk)
{
    string iZeYBWOnzdHrP = string("WorgrmbldDQaurVZApKLlrlIoDDjWWGWwXncMyaZVRksGrnPEqYvdiHRSReojxnekInOFbgsEuCQKFbLRSzcbZoMLGSgAfZMnqxtOPcPyFspTspTUGMBcysYkffNmcDTYdqFbREKnVLXpYJL");
    string hfxuahnSqldjvGv = string("RagLlPNJdWteogCLCqUQKFSMiDbexHuLefSlapoM");
    bool HIRbgZBKxLrL = false;
    bool WVjQdVsLBDlTJbH = true;
    int rNEwCKQdrzS = 482118419;
    double jLumtYiLO = 76074.7334864628;
    double YDPhH = 110150.85695841005;

    if (HIRbgZBKxLrL != true) {
        for (int oMlhatiNQo = 109794196; oMlhatiNQo > 0; oMlhatiNQo--) {
            YDPhH -= jLumtYiLO;
        }
    }

    for (int lUxXp = 146451684; lUxXp > 0; lUxXp--) {
        bTNekuYUr = ! HIRbgZBKxLrL;
    }

    for (int JaBqh = 1003747673; JaBqh > 0; JaBqh--) {
        rNEwCKQdrzS /= tCnHfUaZtk;
        iZeYBWOnzdHrP += hfxuahnSqldjvGv;
        HIRbgZBKxLrL = HIRbgZBKxLrL;
        zTdboUIPZAgxDk -= jLumtYiLO;
        YDPhH = YDPhH;
    }

    for (int hQByAKTYXeyacks = 152933921; hQByAKTYXeyacks > 0; hQByAKTYXeyacks--) {
        continue;
    }

    for (int YsAwJ = 555860799; YsAwJ > 0; YsAwJ--) {
        continue;
    }

    for (int ckThRKfZKEBs = 735455369; ckThRKfZKEBs > 0; ckThRKfZKEBs--) {
        continue;
    }

    for (int roThJsWvL = 779106556; roThJsWvL > 0; roThJsWvL--) {
        continue;
    }
}

laTMZCb::laTMZCb()
{
    this->uqDNFS(string("rohlHnfYLrDSqnkmCkXxsKCrhxxVlsgSXSwyAkLqkyvqDIHSuCadWpMjwAqGNXmzXnOIGPumEluZkXyaAgJpwraBHhQBpCicvXehHSefOIDPCqbxyXvTZeXxmDAWGlJwsRMZrDCBSUZlStzRdCCCZiRrUKmo"), false, 983438.0356448699, string("NbUCwTYPypzVHNCPRvgdAInvYHbLwWFIVQbtLebGwUDsECstYabkiwQOx"), 841566.2900458383);
    this->QcFLqZJCTAbXrs();
    this->gSkXeVUS();
    this->wKvbJjNBvYPl(string("HWhVgsfoz"), true, 19037738, false, true);
    this->imymtZAVpaRcsCR(-391393521, 672709.9977109612, -1910132340);
    this->lGOxduINAv(711809.6543230495, string("GZomrtHwjGOUbGQQdDHsFBnHPqpJUtRxeJZiRrDNhDVLZxyAkFoFRpiWbrhJkZKXFbMHGpcSCGzfPXXVMFuRMFPoPaiSejr"));
    this->QGHhrRVLGB(-853523.9281423411, true, 2002641162);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xgEPUZEK
{
public:
    bool xPfgIbyjmCld;
    int vFpZbFnDyQhPA;
    string fhDIrXVy;
    int IJHSDBwWlSnJAoR;

    xgEPUZEK();
    bool IHRDPiu();
    void BXPGTW(int CRqMaFngGJlsxJf, bool yaLAFrsHG);
    void xIlbPK(int HfMMIJV);
    string pGeNGndKwXEccdP(int JTROFvuXIvg, string YAnVxEGVRSdKM, double RAOySoLDBM, string YQuSw);
    void cdvQjXJNFBXBTZMp(bool paWQw, double ijWCEleyJt, double AZhHnpiLPGUu, string xKuEVGEJmwmDBryn, string ygFEmASF);
protected:
    string ozguCHQA;
    string fOSRGDMpeNDIZv;
    bool sEMjSNdpHyyDzROI;

    void iwuIyoMGdljZ(double WEOiPvPPWwXN, double UDKLxKRCOnZp, double SCFwTf, int qVzzueylmfxkjlAq);
    void uNWhVJi(double LiBDMy, bool MFNQewVVoTpI);
    double rHijPL(int UaxQd, string rTDwVI, int hbiCcgAW, double VeLEcVUvKrBCfF);
private:
    string giygJz;
    int uRLKtLChgufGhyE;
    int zRiLhAi;
    string tVohWyHJLv;
    int KwVCVNlnlacRdDOj;
    int LERRq;

    string OGnblxjjObfj(string IEzLgsKHgLBt);
    string YTBoGOnAeV(string HIBDVl, bool QPuahElnImuQ);
    int PtgvoWldVjSk();
};

bool xgEPUZEK::IHRDPiu()
{
    string UMUApxyr = string("eNzXPFGmoxGIvbFWpbcIiJtWbBGkuKYHpEFcsYtCgdNjAzQQHyHbvMICuqimcRlyjpLfMCxEbdMYhaoHVaevoWXzRWQRRwtHnixENUDqUDcIvbCQFqpSbqrAzZRCzRzNXuAqyQCXTXnAyMXWekgPuYpGDNyXWeQlWBJgalfYmOtUPdcdXmBoRyHmjhoiCQPnTvodxlSbHQufqgfikJuACE");

    if (UMUApxyr < string("eNzXPFGmoxGIvbFWpbcIiJtWbBGkuKYHpEFcsYtCgdNjAzQQHyHbvMICuqimcRlyjpLfMCxEbdMYhaoHVaevoWXzRWQRRwtHnixENUDqUDcIvbCQFqpSbqrAzZRCzRzNXuAqyQCXTXnAyMXWekgPuYpGDNyXWeQlWBJgalfYmOtUPdcdXmBoRyHmjhoiCQPnTvodxlSbHQufqgfikJuACE")) {
        for (int CjfAzlfYJUnngC = 1647082039; CjfAzlfYJUnngC > 0; CjfAzlfYJUnngC--) {
            UMUApxyr = UMUApxyr;
            UMUApxyr = UMUApxyr;
            UMUApxyr += UMUApxyr;
            UMUApxyr = UMUApxyr;
            UMUApxyr = UMUApxyr;
            UMUApxyr += UMUApxyr;
        }
    }

    return true;
}

void xgEPUZEK::BXPGTW(int CRqMaFngGJlsxJf, bool yaLAFrsHG)
{
    int bdAjFwMh = 834649315;
    int MpoiAz = 215684425;
    double vykoKqakgpV = 233436.03191301686;
    int uHZpkFKbDTepWdcL = -2073124276;
    bool fmFWDpDXeCud = false;
    bool hGqrHCubKpG = false;
    bool jqTaQHADgBpF = false;

    for (int CyVlfiFxHZRbAiu = 258826870; CyVlfiFxHZRbAiu > 0; CyVlfiFxHZRbAiu--) {
        fmFWDpDXeCud = fmFWDpDXeCud;
        MpoiAz *= uHZpkFKbDTepWdcL;
    }

    if (bdAjFwMh == 811061084) {
        for (int LkpcPpmrcp = 2145985520; LkpcPpmrcp > 0; LkpcPpmrcp--) {
            bdAjFwMh *= uHZpkFKbDTepWdcL;
        }
    }

    for (int YElhP = 786097529; YElhP > 0; YElhP--) {
        hGqrHCubKpG = fmFWDpDXeCud;
        uHZpkFKbDTepWdcL /= bdAjFwMh;
        uHZpkFKbDTepWdcL += bdAjFwMh;
        jqTaQHADgBpF = hGqrHCubKpG;
    }
}

void xgEPUZEK::xIlbPK(int HfMMIJV)
{
    double iCowXmrfZesVCnZ = 857449.3835883456;
    bool FNEwB = true;
    bool rUDcUcGhQinvIo = true;
    double HXmWrg = 813334.599171742;
    int AGlZMmlrXmwEEMJ = 724262025;

    for (int TuopaJgU = 451806140; TuopaJgU > 0; TuopaJgU--) {
        HXmWrg /= HXmWrg;
    }
}

string xgEPUZEK::pGeNGndKwXEccdP(int JTROFvuXIvg, string YAnVxEGVRSdKM, double RAOySoLDBM, string YQuSw)
{
    bool hQxZmwtFLrMrU = true;

    if (JTROFvuXIvg == 1964933169) {
        for (int fHTGJGyFPvvYtd = 1001980176; fHTGJGyFPvvYtd > 0; fHTGJGyFPvvYtd--) {
            continue;
        }
    }

    if (YAnVxEGVRSdKM < string("eUfLwiZLiNwRKRGUYhLZuLAbfctPXfYrkKbUkcECsyrvUvrTKtruKyfxzVwbXuOE")) {
        for (int UQxpHTB = 460189663; UQxpHTB > 0; UQxpHTB--) {
            YAnVxEGVRSdKM = YAnVxEGVRSdKM;
            RAOySoLDBM /= RAOySoLDBM;
            YAnVxEGVRSdKM += YAnVxEGVRSdKM;
            YAnVxEGVRSdKM += YAnVxEGVRSdKM;
            RAOySoLDBM += RAOySoLDBM;
        }
    }

    if (YQuSw == string("bEWDhwQEnDIwKFDpawxvmIFXmbjlAOLelFhuWdZuwiUUXRoBLlAxAMgOFgmlRQeXqSCGHsaTIPMJrcAWxzsJnrHeWHiJEgqwTMLsBqDjtbIBMUxQKvgWJngLbAErOFwxdJhGALMydXBqRNNOYoLIHViXvOGmecQJEtFYXJaPsUDtQEAWHTBoDLvmxwDELJjjPTUthPCPKtHmkWtxNeprPkylAFEKKSACRBdWOVJCjsFkjUpvXgpvEBFoxXi")) {
        for (int hdWYdxOMJ = 677417189; hdWYdxOMJ > 0; hdWYdxOMJ--) {
            continue;
        }
    }

    return YQuSw;
}

void xgEPUZEK::cdvQjXJNFBXBTZMp(bool paWQw, double ijWCEleyJt, double AZhHnpiLPGUu, string xKuEVGEJmwmDBryn, string ygFEmASF)
{
    string FtIEIHNLfhGi = string("RtEpxXRyORplFlghW");
    bool vuokLncdHQROBrv = false;
    int mJsckT = 2113934175;
    double cYnIHtZpy = 233761.48472160334;
    string tPrEMwFl = string("UNcCONDJFMlpfTUAeBsmLjzSriFKdmTyYJtvXVxLuMrSBkdRYTRyjTEKXiAnNOtmsEvoEnqijjSJEBVYKNsSSIWhHjkhagbhQKvWeYEQYoUIHzWUzuoEhAsZsdKEDcHQKieRrlBfTDcMBhWywhZRjGGNdTYLfDXZvDLtfZMkjhWFMDwbtPXDGeqBMDATsrXqXoUJRlqIEpNXuRSZkdNQdKpYnpDNKAsxvh");
    string RdyLF = string("KQqBURvQQiAeRnszxtAbzlwWsGXcVczLGpdbNvZOxYMVsdPKpPXlNUFBByifNcmYhzkJGFXOVknyqFyggVMLZUNrJiYfOtJcZMmQPFqRzvfWDwApaFQWyHGYRXPfHTcIjvxijFhZrRUFkfAseaSIvhEr");
    double BFzbgm = -518182.5267989395;
    string rbiaQaqIWwtQAW = string("fJVBAvoNviOzfhkanybMmowRqURLoLYghiRluTenUwteAEAMjRPnEBOmdJKYzgbOdKpjVfKNlHwtFGrAeIYqgkBjPLWIFFYZmxxALZNmCtpgbXxPbBHbWklCkPlLZTKDeIYCTeCnXaLWobLNRqWNvmEHuxoXmoMyhibFvYrYTiLRFlA");
    string hjLLtA = string("YtjwKwVAJbcIPcesoItYmrKESNRFmVYEKgscUrGnHSysADXrbPMysbWaZcIlBmpeVMgRiykZdvOakHaAVoWVWCkhFZc");
    double yulPLUzMZvLTVSH = 716586.1948307474;

    for (int bQwrsy = 1915228651; bQwrsy > 0; bQwrsy--) {
        xKuEVGEJmwmDBryn = ygFEmASF;
    }

    for (int vDFYRoyMokWbHKxk = 1917459592; vDFYRoyMokWbHKxk > 0; vDFYRoyMokWbHKxk--) {
        continue;
    }

    if (hjLLtA > string("RtEpxXRyORplFlghW")) {
        for (int aBrRt = 502726551; aBrRt > 0; aBrRt--) {
            rbiaQaqIWwtQAW += RdyLF;
        }
    }

    for (int IzMlMWpNQWjzMhO = 1554903966; IzMlMWpNQWjzMhO > 0; IzMlMWpNQWjzMhO--) {
        RdyLF += ygFEmASF;
    }

    if (cYnIHtZpy > 233761.48472160334) {
        for (int ReThpSb = 269911156; ReThpSb > 0; ReThpSb--) {
            FtIEIHNLfhGi = FtIEIHNLfhGi;
            rbiaQaqIWwtQAW += ygFEmASF;
            FtIEIHNLfhGi = RdyLF;
            ijWCEleyJt *= AZhHnpiLPGUu;
            ygFEmASF += ygFEmASF;
        }
    }
}

void xgEPUZEK::iwuIyoMGdljZ(double WEOiPvPPWwXN, double UDKLxKRCOnZp, double SCFwTf, int qVzzueylmfxkjlAq)
{
    bool TclrpNH = true;
    string qAZsMdfgnqWey = string("AdizZIKoBLWRRUZzVtCKzqelWOxZBRLRyvPsVyUGGaruhZuYDSCBqPwXUaFjnSgqaRYixdfZkCmJmkrmLVeiGZuOMiJRYvbjYDOkJaQycwcPYQsnxSAQrNTxIqjcRGJHiQuYPFRLTSftiEcBEBZnCjCtJIAvekUcCDyTQHudgKHgpapXCfVejSxCJISMxBXvZwLNhSpOnEkNmlasVpaY");
    int trjzPHly = 233140034;
    double cHBvldGlktt = -1019240.1896057513;

    if (cHBvldGlktt == -668366.7440023439) {
        for (int lmzlEkJQIwMLEL = 2052075355; lmzlEkJQIwMLEL > 0; lmzlEkJQIwMLEL--) {
            cHBvldGlktt /= cHBvldGlktt;
            cHBvldGlktt = WEOiPvPPWwXN;
            SCFwTf -= cHBvldGlktt;
        }
    }
}

void xgEPUZEK::uNWhVJi(double LiBDMy, bool MFNQewVVoTpI)
{
    int wMsqNS = 1349603333;
    double tYcXTkzdC = -676616.3955425828;
    int JgWNX = -1324134345;
    bool dLgITmthFiuI = false;
    bool EMXKsX = true;
    string epEBB = string("yglWGrinDzkYdYfdXVZFMMFrUk");
    bool fSwTRa = false;
    int JubjFpJTJ = 329195537;
    double ZUujPEMQ = 629919.5765421588;
    double ceXLBc = 665306.6066741658;

    for (int OpuVb = 1179741860; OpuVb > 0; OpuVb--) {
        continue;
    }

    for (int PANpADL = 761066529; PANpADL > 0; PANpADL--) {
        dLgITmthFiuI = ! MFNQewVVoTpI;
        ceXLBc -= tYcXTkzdC;
    }

    for (int dhrHNfEgrr = 889659500; dhrHNfEgrr > 0; dhrHNfEgrr--) {
        ceXLBc += tYcXTkzdC;
        tYcXTkzdC *= LiBDMy;
    }

    for (int WRurn = 1183959018; WRurn > 0; WRurn--) {
        MFNQewVVoTpI = MFNQewVVoTpI;
        MFNQewVVoTpI = ! MFNQewVVoTpI;
    }

    for (int OeEDTAQGz = 743425777; OeEDTAQGz > 0; OeEDTAQGz--) {
        JgWNX += wMsqNS;
    }
}

double xgEPUZEK::rHijPL(int UaxQd, string rTDwVI, int hbiCcgAW, double VeLEcVUvKrBCfF)
{
    double MhNxWfoDf = -48099.00778219854;
    int QyIVvOhrtuQMUgLj = 1224773427;
    int fhLxuyIsHeLi = -1302093123;
    bool XppqnmDDSTSMV = true;
    int rqpNFwG = -366561836;
    bool euyjvBiIvYTOy = true;
    string DpWDSDFyvGcKGEz = string("fhiEURMWPYnvPuZfakOm");

    for (int OtYSBUgUWPY = 1697800505; OtYSBUgUWPY > 0; OtYSBUgUWPY--) {
        continue;
    }

    return MhNxWfoDf;
}

string xgEPUZEK::OGnblxjjObfj(string IEzLgsKHgLBt)
{
    string ISwSwcXu = string("BpiOqxsbUUluzJwNhswuCBWIwyGfGenbfYJRAUTNKCOfXkzpFHSWKvcKdSrMkycBcwPRbsCHNgsDJJiZFpiVRVmOLGcGCpZznvYDWFlBMMTCRMTAZxrEeeidOixrrfAOuntoooysQvCnjHdKTStTcANRNVFOnHnGKCfRVswTdZtHvdmlKTTSeNHhRUiPLMxaklgNup");
    bool CEQoBKVfL = true;
    bool PPBbUIRMivPo = true;
    bool zArGqLEi = true;
    double LpAsyFeyXdXkj = 293956.11307873967;
    bool EHEzBinZuwnVo = true;
    string BVDNFmEqDmrR = string("opJwupVTXLpWrVcgQHmzokuvuiOgpnFsFQxTPbgSS");
    string XuRVuBDhGCmpG = string("NcrEdfPDGPjqGAUnjfNsKNvoLbkZTCXeTvDBhyUBnunOpwkNjMpkvOQpDgBxXUcPDqkTYIWHBThuYqbiPkWboUeZxDXFJOdjBzSzOPIdCvUb");
    bool uIiydsdmvI = false;
    bool xJMbFjDyZ = true;

    if (xJMbFjDyZ == true) {
        for (int OIzgngNlpPcVeNL = 240856591; OIzgngNlpPcVeNL > 0; OIzgngNlpPcVeNL--) {
            continue;
        }
    }

    for (int VLutCbGKBAnFCTqO = 1270343902; VLutCbGKBAnFCTqO > 0; VLutCbGKBAnFCTqO--) {
        IEzLgsKHgLBt += ISwSwcXu;
    }

    if (ISwSwcXu >= string("opJwupVTXLpWrVcgQHmzokuvuiOgpnFsFQxTPbgSS")) {
        for (int ynMERiqoyg = 1189357829; ynMERiqoyg > 0; ynMERiqoyg--) {
            BVDNFmEqDmrR = XuRVuBDhGCmpG;
            zArGqLEi = ! zArGqLEi;
            IEzLgsKHgLBt = XuRVuBDhGCmpG;
        }
    }

    if (xJMbFjDyZ == true) {
        for (int KkgtEeegg = 637780323; KkgtEeegg > 0; KkgtEeegg--) {
            xJMbFjDyZ = ! uIiydsdmvI;
        }
    }

    return XuRVuBDhGCmpG;
}

string xgEPUZEK::YTBoGOnAeV(string HIBDVl, bool QPuahElnImuQ)
{
    bool yCgrtDTu = false;
    int NwgHkYp = 1496858336;
    int TjeAhoeUZygJFT = 1994334018;
    double SIGII = -508766.42661919916;
    int AlMCbEGDjmISvkQD = -1351793040;
    int GuqaPefZtN = -642402135;
    int VjaVr = 2098562727;
    string YBtudS = string("SiEQSzEdtJJBelvpUkwXqMGgxrmIdFjBTOaLHBHfnzzoqqtLbzAmLrnPhiLHTrmueMHCuqxcbOXrAFayvgsjggtdSUoSWcTXlIRiFufgaNCcdNREK");

    for (int uqJGtxPfKZ = 424746995; uqJGtxPfKZ > 0; uqJGtxPfKZ--) {
        AlMCbEGDjmISvkQD = GuqaPefZtN;
        NwgHkYp /= TjeAhoeUZygJFT;
        VjaVr = AlMCbEGDjmISvkQD;
        VjaVr += NwgHkYp;
    }

    for (int mNQboD = 1633888085; mNQboD > 0; mNQboD--) {
        GuqaPefZtN /= VjaVr;
    }

    for (int RMfZNkoqZPKz = 293608903; RMfZNkoqZPKz > 0; RMfZNkoqZPKz--) {
        VjaVr -= GuqaPefZtN;
        QPuahElnImuQ = ! yCgrtDTu;
    }

    for (int CwjuANO = 2026044490; CwjuANO > 0; CwjuANO--) {
        VjaVr -= TjeAhoeUZygJFT;
        VjaVr -= AlMCbEGDjmISvkQD;
    }

    for (int UoYcieM = 436328463; UoYcieM > 0; UoYcieM--) {
        YBtudS = YBtudS;
        AlMCbEGDjmISvkQD *= TjeAhoeUZygJFT;
        AlMCbEGDjmISvkQD += NwgHkYp;
        NwgHkYp += TjeAhoeUZygJFT;
    }

    for (int dYLyZAkbC = 1931595984; dYLyZAkbC > 0; dYLyZAkbC--) {
        GuqaPefZtN += AlMCbEGDjmISvkQD;
        NwgHkYp *= TjeAhoeUZygJFT;
        NwgHkYp = GuqaPefZtN;
        QPuahElnImuQ = QPuahElnImuQ;
    }

    return YBtudS;
}

int xgEPUZEK::PtgvoWldVjSk()
{
    int PixFKc = 2122415409;

    if (PixFKc <= 2122415409) {
        for (int PvcQGDRwMLPfcT = 1402342399; PvcQGDRwMLPfcT > 0; PvcQGDRwMLPfcT--) {
            PixFKc += PixFKc;
            PixFKc /= PixFKc;
            PixFKc /= PixFKc;
        }
    }

    if (PixFKc == 2122415409) {
        for (int xVtoBqYzwRrnim = 674729319; xVtoBqYzwRrnim > 0; xVtoBqYzwRrnim--) {
            PixFKc += PixFKc;
            PixFKc *= PixFKc;
            PixFKc /= PixFKc;
            PixFKc = PixFKc;
            PixFKc += PixFKc;
            PixFKc -= PixFKc;
        }
    }

    if (PixFKc < 2122415409) {
        for (int pjECOkiRZNK = 1752107865; pjECOkiRZNK > 0; pjECOkiRZNK--) {
            PixFKc /= PixFKc;
            PixFKc = PixFKc;
        }
    }

    return PixFKc;
}

xgEPUZEK::xgEPUZEK()
{
    this->IHRDPiu();
    this->BXPGTW(811061084, true);
    this->xIlbPK(-149142705);
    this->pGeNGndKwXEccdP(1964933169, string("bEWDhwQEnDIwKFDpawxvmIFXmbjlAOLelFhuWdZuwiUUXRoBLlAxAMgOFgmlRQeXqSCGHsaTIPMJrcAWxzsJnrHeWHiJEgqwTMLsBqDjtbIBMUxQKvgWJngLbAErOFwxdJhGALMydXBqRNNOYoLIHViXvOGmecQJEtFYXJaPsUDtQEAWHTBoDLvmxwDELJjjPTUthPCPKtHmkWtxNeprPkylAFEKKSACRBdWOVJCjsFkjUpvXgpvEBFoxXi"), 212081.43582667224, string("eUfLwiZLiNwRKRGUYhLZuLAbfctPXfYrkKbUkcECsyrvUvrTKtruKyfxzVwbXuOE"));
    this->cdvQjXJNFBXBTZMp(true, 611446.4785816988, 855224.4327009902, string("DBjHisWxZJHLHPeXauGtbvnOsZbvPQjejYpXljefwWyvHLNhUvVBzEhkTzomQKbyvSTdgknASiYmpotQIywJnaEVJuaFKjkDBZTbwRCuxTxHRNpqIfPkVIUcVyFaeYWcwihkdrCKTQGkGGYykJUuTzDVNhFdKnfbgqnYifoGSHfkRthxpd"), string("azHLKCjeshdAKzDHUWszPNizOwoUPJICMKomPjEpNdXaZtBybRwDDKTQokzSkrblvgrFEIHONJgtpewDGhMYWLClfBNPRSIyGZcRuGaNHfranuliXyXYoGwaYlHwmtzwiAjEJjhQNVdNdIanLV"));
    this->iwuIyoMGdljZ(-668366.7440023439, 536176.4218104047, 930575.6278025679, -1999568771);
    this->uNWhVJi(-278602.32998543256, true);
    this->rHijPL(-1135529027, string("qFXmkAdsXfSFdbomVSpGFTnhQRScfCoWmrdAmqKOnRLoaCgplhYtfAAITGWbkBolMIlIrMkcjUXCOJ"), -1017956550, 457173.09693597216);
    this->OGnblxjjObfj(string("WYsWLnZWUbruyhFqITZKbTETHgXxbuuTrJdanIUYyqzNOeJjbsoPkaQSHyebTYfToF"));
    this->YTBoGOnAeV(string("pYjMwSBAvIdeJwxfvtLzYIeqAmYHXcVBjYhdbzoDSxYXbgZNhgxqjqTweuhdvJLmEbySvQJqnjHyzvC"), false);
    this->PtgvoWldVjSk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WBzcCe
{
public:
    double siaJEjyrJSh;
    int QFOtJd;
    int nRsuVrGTIQyTcuD;
    int HcxMyI;
    int ClTkNQ;

    WBzcCe();
protected:
    int FhjpxbSjPtC;
    double SmtzLktHDuhJTq;

    bool tUTanyuaMWINb(string eisfvH);
    string ZVpNSSIFGf(string JEeEU, bool IJwKZAnZWqXJNFfL);
private:
    double mNcZDvjVrCAERO;

    string SgUMoZPKBLDLT(int oHNgJPPOwHDZee, int xGQLovEQNNq, string CdWrOYIScOg, string WNIaaZ, bool uuUTfSHbtJc);
    int NxZCyaqtKUWwQp();
    bool YhrOhyWOkzXjci(string hKdCXQYzfH, string VghhRyGudZ, int AEZccg, int qYhSvAuthtfzFY, string dyluXeODjsnL);
    bool XXRgXDjNOT(double hETSEqwpNHTwRjNA, int hSeqtQuxYLbbDXhv, bool tcEQxESyhg, int ezoeVCXoo, string FSwNDexXSkvZHozj);
};

bool WBzcCe::tUTanyuaMWINb(string eisfvH)
{
    string ACWvCJkRkUP = string("yQfTGkzHzASUpxjlMnNpPJoReVluDbAhKAVdqwchRultFsCqerdenmEfdFRifEZtGFVeOUrzEBSMFx");
    int tpdtMFnR = -757720366;
    string CwaWOVzWfyH = string("tckaTOaaKDAWNmTWXfQNQKLknoaxLvfsTPoegsVqLbgenJrSmFAezOugfbhGDYfpUVOeyPrDEyQRLdfPcFSjRcUamSSUCgMzBMScBUrbPkwwyWPDPAYzLdDxxmfllmYjeMalZBCJsdaAbfJwMiZkfJZzKeGsxSrMtmYlBuDmePPrnVBrqIyWRFmtYQjeEhFqIMYSfLbvBbbmbIwrxWBgTeANIDIjghMuexfEOrRCGycrnEtfQE");

    if (eisfvH != string("UmcZbRYoQNpJErwjYPcXuzoYpBezDpHfEJiqIIarbWflwcgwDnqHJMXuLnxXYPYVgiHDMzgLpXooRlTENLtxUnSeQLvRdFbQEuCHLHsLbOwswtalWMdxpyHoMfDLNYKiFAvkjqqDGNxARSeZMIILpwRYCNaBhTPqdHzTdIJIqYdvMwYsRJAKpRYDHSmzibeIEjTmjlgH")) {
        for (int LZAigxNSUqKwf = 312363075; LZAigxNSUqKwf > 0; LZAigxNSUqKwf--) {
            CwaWOVzWfyH = ACWvCJkRkUP;
        }
    }

    if (CwaWOVzWfyH >= string("yQfTGkzHzASUpxjlMnNpPJoReVluDbAhKAVdqwchRultFsCqerdenmEfdFRifEZtGFVeOUrzEBSMFx")) {
        for (int BoZgkkUaEVcMACy = 893568525; BoZgkkUaEVcMACy > 0; BoZgkkUaEVcMACy--) {
            CwaWOVzWfyH = eisfvH;
            eisfvH += ACWvCJkRkUP;
            CwaWOVzWfyH = CwaWOVzWfyH;
            CwaWOVzWfyH = CwaWOVzWfyH;
            eisfvH += CwaWOVzWfyH;
            ACWvCJkRkUP = eisfvH;
            eisfvH += eisfvH;
        }
    }

    if (eisfvH == string("yQfTGkzHzASUpxjlMnNpPJoReVluDbAhKAVdqwchRultFsCqerdenmEfdFRifEZtGFVeOUrzEBSMFx")) {
        for (int rXdWqoJwTyzjaB = 1459955506; rXdWqoJwTyzjaB > 0; rXdWqoJwTyzjaB--) {
            eisfvH = CwaWOVzWfyH;
        }
    }

    if (CwaWOVzWfyH >= string("yQfTGkzHzASUpxjlMnNpPJoReVluDbAhKAVdqwchRultFsCqerdenmEfdFRifEZtGFVeOUrzEBSMFx")) {
        for (int WSoNalWbcH = 2142441246; WSoNalWbcH > 0; WSoNalWbcH--) {
            CwaWOVzWfyH += ACWvCJkRkUP;
            CwaWOVzWfyH = CwaWOVzWfyH;
            ACWvCJkRkUP = eisfvH;
        }
    }

    return true;
}

string WBzcCe::ZVpNSSIFGf(string JEeEU, bool IJwKZAnZWqXJNFfL)
{
    string ydFZgzJhafkIgby = string("nFQyecMdMHCDhXzcOpXkPsbTHszXgfHqXEMQFQMqCyAGMpPNRyWFPYVUtNfhaDprBKAHiIytVWAmQzeQHHLOQGvMZvEeowHSEQqhIhngvbXgXiSkdUO");
    string sTGFv = string("tzZBlqInJSXffCXSIbecCjoAsDDbHfPRmDvExWqZKCDLrMSQilCszaZGwhsjDOLErqTtMMQzQXszNWdRyzAhCUJjxFcapMqckLzLmgAuFHqDeSLqxVICocuePrfBwbTkAWxfwneulcsTTUbHCwghySEKRCbIPmEAOkOYMlujdWIkcpAPwQBIWJKJAlrhyBjqnlrAMHqdqVmBDTxa");
    double NXdARvGMeVErmrE = -324765.74069076765;
    string tkrBFwlNZyYZcOt = string("kbRDaEAUubgpHlykAhaUNwHhUhiHTuWpzvbrxNEUooCkgsSQIRMhPixArvMqEYIqeKHgricmMgYajGNQKxXvwTeeYMfWDfYnbUJLFYDyxQJvQeDRKoAezKYPeemtHLZHUTMZsflDGaFQnqLziIxVbCmCSITlIzBnlQYAQGTAOOzkbaOCPAZFkWcMUhjPAdeKDdTqebSgPloNxypLeqySlTWlVIfiFgrVeEhcfZBQKOrhddxLzxX");
    string tbNGu = string("RnsTWnTNVxqVBlEbbZuQghigoWgLnMKlyATWVdJeqfrIAnFOLmcuZcQCmEuCvxY");
    double DIYKmDrwDT = 422207.9419836478;
    string EFxKKbnfq = string("ctkGbfxuPqiOIzPjuAEVBWgjrlLhqgcPqFFMtZHtWhIZRFiHhkXbliiAlUKJZWnYaoKoxAdKXaSoqfLRBrBYwfrgxehAqjGqyJAiaQyBmYfwCnfajemglrwZYoRfcYxBswVJAAPCzRjUlCUiwObN");

    if (DIYKmDrwDT > 422207.9419836478) {
        for (int mWXbgnnTIgGshH = 1578871457; mWXbgnnTIgGshH > 0; mWXbgnnTIgGshH--) {
            JEeEU = tbNGu;
            JEeEU += sTGFv;
            EFxKKbnfq = EFxKKbnfq;
        }
    }

    if (sTGFv >= string("kbRDaEAUubgpHlykAhaUNwHhUhiHTuWpzvbrxNEUooCkgsSQIRMhPixArvMqEYIqeKHgricmMgYajGNQKxXvwTeeYMfWDfYnbUJLFYDyxQJvQeDRKoAezKYPeemtHLZHUTMZsflDGaFQnqLziIxVbCmCSITlIzBnlQYAQGTAOOzkbaOCPAZFkWcMUhjPAdeKDdTqebSgPloNxypLeqySlTWlVIfiFgrVeEhcfZBQKOrhddxLzxX")) {
        for (int EMlepO = 247339680; EMlepO > 0; EMlepO--) {
            EFxKKbnfq += JEeEU;
        }
    }

    return EFxKKbnfq;
}

string WBzcCe::SgUMoZPKBLDLT(int oHNgJPPOwHDZee, int xGQLovEQNNq, string CdWrOYIScOg, string WNIaaZ, bool uuUTfSHbtJc)
{
    int XctXrneD = -670065780;
    double jvCKbX = 897286.059718877;
    bool mAQAwSyb = true;
    string CiVcafLTq = string("FYGVZxudaXJtaxvHISmnYrhliQgQodHPdigsXZrJwuOuvlRfAP");
    string gNnik = string("SPDmCNVNYbrlTfNikAqvpBglvxvTAaQduhEqZvowMAXEmryiqwAEuZAzzbIXoMxUkAjBkgbhYzS");
    string RQXsFMszXBnOp = string("HjWzgVJloEGwPlASEWkKkRgGRPkUOZHgJOyslVKKjTqPbrFunmXvqGsiwAmhttrfxOxXyRQwHbpZOfEflDujqCDvOSMIQEtHSdJORJsGeVdOyaobZlOuSSMSdjufjpUblPilljseXhA");
    double xZbUaK = -838878.2514391514;

    for (int ZJXMvVb = 559456360; ZJXMvVb > 0; ZJXMvVb--) {
        CiVcafLTq = gNnik;
        XctXrneD = XctXrneD;
    }

    for (int mXnWhCZ = 1351642199; mXnWhCZ > 0; mXnWhCZ--) {
        xGQLovEQNNq /= XctXrneD;
        CdWrOYIScOg += RQXsFMszXBnOp;
    }

    for (int AJicofaPb = 287338582; AJicofaPb > 0; AJicofaPb--) {
        RQXsFMszXBnOp = WNIaaZ;
    }

    if (jvCKbX != -838878.2514391514) {
        for (int udVfdxXBRY = 2094342632; udVfdxXBRY > 0; udVfdxXBRY--) {
            XctXrneD = XctXrneD;
        }
    }

    for (int FYUPyAFIMnpqf = 1752592991; FYUPyAFIMnpqf > 0; FYUPyAFIMnpqf--) {
        CdWrOYIScOg = gNnik;
    }

    return RQXsFMszXBnOp;
}

int WBzcCe::NxZCyaqtKUWwQp()
{
    string FvjdQZtuk = string("xlyCssYiVLsakKMfTWQUELCXpeWpmIXdWOhKpTvSZbYigRFanSKfPnLsMzYtTxHmAHeLAYxgVvoFYsZzBgoogCVjBjbaJwpbBetppHLqYoZRhDOGdQtTkXvasPsvWbJnlZgvuDednTyxYhdnVEEWIaWVhmSADpXwUwDlhRLtfRyCdIzTzBTlVJzfxZpdUvtyMFJtNOKwpGAlTaAmWYBFVZPoLCIulfumRwjVtOZQsiZkZNoNw");
    int iGhzXJOthcyVoN = -640845714;

    for (int wFRiNZiAycJmGg = 1929604109; wFRiNZiAycJmGg > 0; wFRiNZiAycJmGg--) {
        iGhzXJOthcyVoN = iGhzXJOthcyVoN;
        iGhzXJOthcyVoN += iGhzXJOthcyVoN;
        FvjdQZtuk = FvjdQZtuk;
        iGhzXJOthcyVoN /= iGhzXJOthcyVoN;
    }

    if (iGhzXJOthcyVoN <= -640845714) {
        for (int NYaMSxNhVa = 833380428; NYaMSxNhVa > 0; NYaMSxNhVa--) {
            iGhzXJOthcyVoN += iGhzXJOthcyVoN;
            iGhzXJOthcyVoN += iGhzXJOthcyVoN;
            iGhzXJOthcyVoN = iGhzXJOthcyVoN;
        }
    }

    if (iGhzXJOthcyVoN != -640845714) {
        for (int MsZwHUdZCQvk = 781227136; MsZwHUdZCQvk > 0; MsZwHUdZCQvk--) {
            FvjdQZtuk += FvjdQZtuk;
        }
    }

    return iGhzXJOthcyVoN;
}

bool WBzcCe::YhrOhyWOkzXjci(string hKdCXQYzfH, string VghhRyGudZ, int AEZccg, int qYhSvAuthtfzFY, string dyluXeODjsnL)
{
    double aGNRm = 838792.4131227864;
    int NUWUee = -1974941505;
    bool IUTXrUBZaztvYES = false;
    bool jBcEyzcO = true;
    bool NcGOrgOJpaXAJFYf = true;
    double njGMi = -1037630.1210767123;

    if (dyluXeODjsnL >= string("lQKjnKaHSzgVARVYUJCQfSAAMLQsuHiozoPwQjPPQuqnWWdCjNNkYNIsxvBqPukRHLowECHJcPkbECsMJNGhtOPumeoELAKyFyjjLzsSARzxlTYivTSvBuCCsFxqsPkINrTNGWGUZXuuegvWvykCxpHQLGHmATAiUpFSfDtdqrQVhEbPXmBFgSjBZGcOIfdmwqPTpcWqpHuVjaaWsVVKrDBRZQVQDSJxFZUPqsQkybZQn")) {
        for (int ECHKRLdTh = 1494891545; ECHKRLdTh > 0; ECHKRLdTh--) {
            IUTXrUBZaztvYES = NcGOrgOJpaXAJFYf;
        }
    }

    for (int YmsXCosr = 220702205; YmsXCosr > 0; YmsXCosr--) {
        continue;
    }

    for (int gKJgCejmcTAfU = 1684472969; gKJgCejmcTAfU > 0; gKJgCejmcTAfU--) {
        AEZccg = NUWUee;
    }

    for (int ZklsGlnlwCy = 1979351949; ZklsGlnlwCy > 0; ZklsGlnlwCy--) {
        dyluXeODjsnL += VghhRyGudZ;
        NUWUee -= qYhSvAuthtfzFY;
    }

    return NcGOrgOJpaXAJFYf;
}

bool WBzcCe::XXRgXDjNOT(double hETSEqwpNHTwRjNA, int hSeqtQuxYLbbDXhv, bool tcEQxESyhg, int ezoeVCXoo, string FSwNDexXSkvZHozj)
{
    bool bWLMm = false;

    for (int iFHlvPpMsCgwgkb = 852827598; iFHlvPpMsCgwgkb > 0; iFHlvPpMsCgwgkb--) {
        ezoeVCXoo -= hSeqtQuxYLbbDXhv;
        ezoeVCXoo /= ezoeVCXoo;
    }

    return bWLMm;
}

WBzcCe::WBzcCe()
{
    this->tUTanyuaMWINb(string("UmcZbRYoQNpJErwjYPcXuzoYpBezDpHfEJiqIIarbWflwcgwDnqHJMXuLnxXYPYVgiHDMzgLpXooRlTENLtxUnSeQLvRdFbQEuCHLHsLbOwswtalWMdxpyHoMfDLNYKiFAvkjqqDGNxARSeZMIILpwRYCNaBhTPqdHzTdIJIqYdvMwYsRJAKpRYDHSmzibeIEjTmjlgH"));
    this->ZVpNSSIFGf(string("oVxoNFfxilYJUssGctPKVGREvSJukuePwVEdtcAoDSFVBqHLsaoYJuPWecHHhQAgNXwaeVWfpIyStmyhCweirdnHxaYemjCUCvhrVNlrobrLcEWQHWJGnqxGUwLHLCDUKDDxAtBMIdRveMRXDracYnUMgKqSA"), true);
    this->SgUMoZPKBLDLT(-1523503544, 1620690502, string("acpUzfauBYgzmwTkdRyOxQNxZWDgzLDZUXwNRHurtHXbiPnBpNqIulodLkOMGZgmlpPV"), string("FfYlrkAQMootWIUWIohwflPPdxzCMNjYNSSiRHrQUACVVCNaEwVMBbETpMCnAehpTobTryRWAzWBTioWeANzTaQITHzhAesYKivixRErPNPWWLLaZaJtOeVUmubUJowCNOlXONWzdemmahZipHrcJweWDxUtUPDsPDazyevfFbCZDXZqgwSBDyyUsgGIkjazCKdMT"), true);
    this->NxZCyaqtKUWwQp();
    this->YhrOhyWOkzXjci(string("pCZFAoaxybqKtTjyhJcEkRfuGlMwmnCVbQjMMbZGJMmpFEZomgNAXmTMkfafnqVhbTiZCcsbcdKUiZXzCqOAbzICaNnjiUNFeoGnIkxORb"), string("ojtbBHPgRvVnZzcpynDpCPXggyuxyxOfFDVdxVRkiWFDUxfeiXmLPnrKeQaEVnaGZj"), 1265083501, 826218258, string("lQKjnKaHSzgVARVYUJCQfSAAMLQsuHiozoPwQjPPQuqnWWdCjNNkYNIsxvBqPukRHLowECHJcPkbECsMJNGhtOPumeoELAKyFyjjLzsSARzxlTYivTSvBuCCsFxqsPkINrTNGWGUZXuuegvWvykCxpHQLGHmATAiUpFSfDtdqrQVhEbPXmBFgSjBZGcOIfdmwqPTpcWqpHuVjaaWsVVKrDBRZQVQDSJxFZUPqsQkybZQn"));
    this->XXRgXDjNOT(-940486.6542377314, -2080154272, false, 1618998018, string("adZughoSIzWAnzrXGTZkLRXCPSrgjXByelGrEzmYhPWJNWfwxassziDIiYVRXNtiYhTaCDYqycWCtuFXLWudNTBYuFoIHtFdzGDtKepMoDWXBuKgUqJMglsTgecEBurSgawBYmBlJEHQFnICqRwoOB"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mdtiuG
{
public:
    int qCavyLuhGH;
    int ZOePJGH;

    mdtiuG();
    void CwdJstPvAXaQLOoX(bool GvUyrldpGNSMwuX, double kKpHeMioRSnlPJIQ, double YlGEpkSgVEFlyLs, bool GLXKnsNBxqBDziCQ);
    bool gXRQA(double rpLPDizozhJCXk, int iroMjAz, string CcgJTBStv);
    string kfULMpFovTK(bool FKwUppYGwT, string QpUoqDtRkM, string zLgSXMFfgFHR, string hQEbZhKDHoVNuW);
    double YwIcOaFBv(double XyqXdUP, bool LszOK, int LJQjeah, int UFEalb);
    void ydFbGWSpyM();
protected:
    int qEoRjwI;
    double BVlbbzU;
    string vdMEArCRvBWA;
    bool GLAtFzPuxqFxxs;
    double GUkMgqMwVTzFAiZ;

    void fzXVm(string TOKzSonSHs, double nrqoHsx, string IJNWibwjt, int RiyVINOImQqFWhh);
    double MFRCJJRAMOqhE(double YgYuGY);
private:
    int BoHjUcfRXpQKgxkW;
    bool Tlzqx;
    double PVQqGxtTWmbFlo;

    void GmkzQkiznwWUsFj(string sWbVaj, double bANvgoL, bool pSUvUsLxus, int EHlPrEouIAP, int SmsecAEvjo);
    double lSfTFJomtgTKakf(string NwGSuN, bool OKLomGLIHLREYG, bool LCINgCurZmoMVXo);
    double HEubAHJgtgNp(double yelUZYjKkf, int KLIuWtHDE, string WoPKJtVVnxr);
    bool UrpcNOIcclIt(string lWnESniFCKlAdVF);
    bool dgnKolOrRbmPNJkq(int mpAcyb, double IdhxZn, bool bPatwgv, int LozUJM, double HTxtEHjBisIqv);
    int YYLmMFmgV(int IJYfTNgS, int KZfFcVTeK, double ZczmzDIQle, int oyUfx, string ZUDaXnKwUZXiiaSP);
    void HGVTxkoYnMIE(int FYTycwIy, double KHbsa, string MwaORTNxl, int LPSZK, double HgSXvANQxJ);
};

void mdtiuG::CwdJstPvAXaQLOoX(bool GvUyrldpGNSMwuX, double kKpHeMioRSnlPJIQ, double YlGEpkSgVEFlyLs, bool GLXKnsNBxqBDziCQ)
{
    int TWInDrTBTeIbSjc = 1441260587;
    int WJApcNjyTmcdmfNa = -45093996;
    bool TFJbMnAkeMokN = true;
    bool fNrptoMv = false;
    bool IthcrfxRskF = false;
    bool cCWlTKi = true;
    int OrJdUPqZGXgtOOQ = 329140613;
    string RBHZWH = string("eUby");

    for (int SSMAMN = 144101195; SSMAMN > 0; SSMAMN--) {
        OrJdUPqZGXgtOOQ = WJApcNjyTmcdmfNa;
    }
}

bool mdtiuG::gXRQA(double rpLPDizozhJCXk, int iroMjAz, string CcgJTBStv)
{
    int GHYbywEBdu = 1124116876;
    double mhdXjHUOmEWPg = 572064.1116250954;
    int bPfCrTOXbZnx = -207901465;
    bool XbVzGmjoDMaimTH = true;
    int ncHYtdE = 917577113;

    for (int nmZQgVh = 329494054; nmZQgVh > 0; nmZQgVh--) {
        continue;
    }

    return XbVzGmjoDMaimTH;
}

string mdtiuG::kfULMpFovTK(bool FKwUppYGwT, string QpUoqDtRkM, string zLgSXMFfgFHR, string hQEbZhKDHoVNuW)
{
    bool TwOQjVsSfpp = false;
    bool kmZmMTUGR = true;
    string RSqxtPZR = string("aMPu");
    int IrvNlNwabVEGy = 1769698607;
    int zyuIkYOI = 515223852;
    string CJnctjmPnwQSOFhS = string("tqPDWkCXPhLlkbstiWbYvObWc");
    string bYrVGS = string("vEhlCoUfIRncndkeTTGRrQwYkIbSmjNUSqnPCUtBFekyRSGCidsbLhGyObaSZBLRvEAUmgTOgToEQREeGvnWSwBNfhlAMXRVoETKFTZipgRvXgBOAuxidWLoPPJMXSBGhWHUaCbgKJyNAIbpEmflPEwbmGBVjdsPgklGmaPMGRdNm");
    double xIKVpPoOLPB = 758877.4500146977;
    int zalpxOflAjgHVMpn = 2022231684;

    if (zLgSXMFfgFHR < string("vEhlCoUfIRncndkeTTGRrQwYkIbSmjNUSqnPCUtBFekyRSGCidsbLhGyObaSZBLRvEAUmgTOgToEQREeGvnWSwBNfhlAMXRVoETKFTZipgRvXgBOAuxidWLoPPJMXSBGhWHUaCbgKJyNAIbpEmflPEwbmGBVjdsPgklGmaPMGRdNm")) {
        for (int hXWVWylHXhojYI = 1337815300; hXWVWylHXhojYI > 0; hXWVWylHXhojYI--) {
            zalpxOflAjgHVMpn = zyuIkYOI;
            hQEbZhKDHoVNuW += RSqxtPZR;
        }
    }

    return bYrVGS;
}

double mdtiuG::YwIcOaFBv(double XyqXdUP, bool LszOK, int LJQjeah, int UFEalb)
{
    int UuEOwxPmmZYLk = 765111447;
    double voEtvKCrVIERFR = -298625.096064694;

    if (LJQjeah != 43292542) {
        for (int qBqwripQzu = 413604982; qBqwripQzu > 0; qBqwripQzu--) {
            XyqXdUP *= XyqXdUP;
            UuEOwxPmmZYLk -= UuEOwxPmmZYLk;
            voEtvKCrVIERFR = voEtvKCrVIERFR;
            UuEOwxPmmZYLk *= UFEalb;
            UFEalb *= LJQjeah;
            voEtvKCrVIERFR += voEtvKCrVIERFR;
        }
    }

    return voEtvKCrVIERFR;
}

void mdtiuG::ydFbGWSpyM()
{
    double GziVQrYu = 474602.6468007376;

    if (GziVQrYu == 474602.6468007376) {
        for (int FrSrUiZ = 1071594995; FrSrUiZ > 0; FrSrUiZ--) {
            GziVQrYu += GziVQrYu;
            GziVQrYu = GziVQrYu;
            GziVQrYu = GziVQrYu;
            GziVQrYu *= GziVQrYu;
            GziVQrYu -= GziVQrYu;
            GziVQrYu *= GziVQrYu;
            GziVQrYu = GziVQrYu;
        }
    }

    if (GziVQrYu == 474602.6468007376) {
        for (int xZZIzFOG = 2035812074; xZZIzFOG > 0; xZZIzFOG--) {
            GziVQrYu *= GziVQrYu;
            GziVQrYu += GziVQrYu;
            GziVQrYu = GziVQrYu;
            GziVQrYu *= GziVQrYu;
        }
    }
}

void mdtiuG::fzXVm(string TOKzSonSHs, double nrqoHsx, string IJNWibwjt, int RiyVINOImQqFWhh)
{
    string BfhiLpejUNnhqEi = string("qnziGKhwjwpaQNjUYcEgtiGQmdnZNnmyZgDmRJVnoZaAhRPotVOqcowALyKVtrQASENgjlomdpIjdNBJzcbmpOAWVMXuMUECVBXZdPUhOtBMACfhrgOnxlrVsotRyiyPKF");

    if (IJNWibwjt != string("pXZOtvwpJqNZGkiWpcpqigFWMloiXOdFQzoKDJ")) {
        for (int EdUSjfQVOR = 1213035435; EdUSjfQVOR > 0; EdUSjfQVOR--) {
            BfhiLpejUNnhqEi = BfhiLpejUNnhqEi;
            nrqoHsx += nrqoHsx;
            BfhiLpejUNnhqEi += TOKzSonSHs;
            TOKzSonSHs += BfhiLpejUNnhqEi;
        }
    }

    for (int MfTBmtAoEMwqHnV = 1293389041; MfTBmtAoEMwqHnV > 0; MfTBmtAoEMwqHnV--) {
        IJNWibwjt = TOKzSonSHs;
    }

    if (TOKzSonSHs <= string("pXZOtvwpJqNZGkiWpcpqigFWMloiXOdFQzoKDJ")) {
        for (int WzoAoCB = 1162980045; WzoAoCB > 0; WzoAoCB--) {
            BfhiLpejUNnhqEi = BfhiLpejUNnhqEi;
            BfhiLpejUNnhqEi = TOKzSonSHs;
            IJNWibwjt += IJNWibwjt;
            BfhiLpejUNnhqEi += BfhiLpejUNnhqEi;
            IJNWibwjt = TOKzSonSHs;
            TOKzSonSHs = TOKzSonSHs;
            TOKzSonSHs += BfhiLpejUNnhqEi;
        }
    }

    if (BfhiLpejUNnhqEi >= string("qnziGKhwjwpaQNjUYcEgtiGQmdnZNnmyZgDmRJVnoZaAhRPotVOqcowALyKVtrQASENgjlomdpIjdNBJzcbmpOAWVMXuMUECVBXZdPUhOtBMACfhrgOnxlrVsotRyiyPKF")) {
        for (int AwixpDLNOi = 1755341659; AwixpDLNOi > 0; AwixpDLNOi--) {
            IJNWibwjt += TOKzSonSHs;
        }
    }
}

double mdtiuG::MFRCJJRAMOqhE(double YgYuGY)
{
    string haxUgdyEnjjT = string("IpNOIoQJMyrAGJAKNsMehwXbcCEeeXXryMQbEnaoqOPvQqfieGZUWMRrgwaIYZLbjOVoZyaDBVtOvDHBKjPCubmbfIlgXbIeblDwpQPOujmLTLABYRdgcFhXUhzrkljBGXARkTyyopjsyNekooDHsQhesvAShoNdRQNNyinLLUrMzMoMnaCEWTNfkF");
    int JVjXspRvIik = -1034750098;

    for (int hTPucbrP = 326289714; hTPucbrP > 0; hTPucbrP--) {
        haxUgdyEnjjT = haxUgdyEnjjT;
    }

    if (YgYuGY == 138141.37772627) {
        for (int OcCBT = 819883309; OcCBT > 0; OcCBT--) {
            JVjXspRvIik -= JVjXspRvIik;
            YgYuGY *= YgYuGY;
            haxUgdyEnjjT = haxUgdyEnjjT;
        }
    }

    for (int CRFYUUVYZXeQjYS = 1572871795; CRFYUUVYZXeQjYS > 0; CRFYUUVYZXeQjYS--) {
        JVjXspRvIik -= JVjXspRvIik;
    }

    return YgYuGY;
}

void mdtiuG::GmkzQkiznwWUsFj(string sWbVaj, double bANvgoL, bool pSUvUsLxus, int EHlPrEouIAP, int SmsecAEvjo)
{
    int UqpIX = 1200676600;
    int tkZwPRvLBVttl = 693787477;

    for (int EVqWmwRq = 1929223297; EVqWmwRq > 0; EVqWmwRq--) {
        SmsecAEvjo /= tkZwPRvLBVttl;
    }

    if (EHlPrEouIAP == -695275400) {
        for (int wvNLvO = 805797334; wvNLvO > 0; wvNLvO--) {
            SmsecAEvjo = SmsecAEvjo;
            tkZwPRvLBVttl /= UqpIX;
            EHlPrEouIAP += tkZwPRvLBVttl;
        }
    }
}

double mdtiuG::lSfTFJomtgTKakf(string NwGSuN, bool OKLomGLIHLREYG, bool LCINgCurZmoMVXo)
{
    double VYgkEEBeITj = 660981.4282832125;
    string lpgBxF = string("tvAOmnPMfmzQRIVPoVtxyoDrMmaQCMHbFnlMGYUZIVYkFNiTXcbwZyJNzji");
    double syfMHjVHF = 118527.01064458548;
    double WnAbazNwVkybexoN = -207577.53296602488;
    double LzofTNiVmKdoz = 1025655.6802146647;

    if (NwGSuN >= string("tvAOmnPMfmzQRIVPoVtxyoDrMmaQCMHbFnlMGYUZIVYkFNiTXcbwZyJNzji")) {
        for (int uPmBLMojo = 541619386; uPmBLMojo > 0; uPmBLMojo--) {
            LCINgCurZmoMVXo = LCINgCurZmoMVXo;
            syfMHjVHF -= LzofTNiVmKdoz;
            WnAbazNwVkybexoN *= syfMHjVHF;
        }
    }

    if (NwGSuN == string("pbTDlLqoPqOrtzUcfXqXmZXxTTlFLACkxZgUZuFWphWNBlZYoQvDkkEmh")) {
        for (int CuDGMONu = 522812742; CuDGMONu > 0; CuDGMONu--) {
            lpgBxF = lpgBxF;
            VYgkEEBeITj -= VYgkEEBeITj;
            VYgkEEBeITj -= LzofTNiVmKdoz;
        }
    }

    return LzofTNiVmKdoz;
}

double mdtiuG::HEubAHJgtgNp(double yelUZYjKkf, int KLIuWtHDE, string WoPKJtVVnxr)
{
    string rDeeLYSsl = string("mpsMYYFDlJthvRSxQnZbxfCIIwIXZQiZcJcTjFmsyQVhvnNRvTslSgcliwxcZtXARovRtwuVtzkHeYFBavbPNGsmbUPkoieMCqOwoyvEMqhnubndCBpqQKUfLIUedOQFlCSzQmxeodCIOaeVCdohhgnghFmJDuosTKAbuzqYWKvAZmxrSoWXaFCxHnMcypcmEevpKGoTlZtdBleQfSgHfEpLzTVCRdyvcUnAAQntFNfMtLVuo");
    int zgxWNCwlLMxNnD = -835495535;
    double ETJmetPfeI = -85380.6247492173;
    bool GdUahFIzsnd = true;
    double HipdBQOxp = -238211.40604128363;

    if (yelUZYjKkf != -238211.40604128363) {
        for (int AhxTGsJ = 2147438244; AhxTGsJ > 0; AhxTGsJ--) {
            HipdBQOxp /= yelUZYjKkf;
            ETJmetPfeI /= yelUZYjKkf;
        }
    }

    for (int Rvped = 67703527; Rvped > 0; Rvped--) {
        HipdBQOxp = yelUZYjKkf;
        KLIuWtHDE += KLIuWtHDE;
    }

    return HipdBQOxp;
}

bool mdtiuG::UrpcNOIcclIt(string lWnESniFCKlAdVF)
{
    bool MfAkOTA = true;
    bool vNfZKVZnxHw = true;
    string FYWZKsh = string("DhfEgUYWXCTVRdEPsLFlbYwScTGWXykVTjuuWoQBjJcJXaWZsFTlvbEPAzDqAiwgheyVFLChiAPMvDIVVHEZGertM");
    double qmmhU = -333349.2585115807;
    double VCdVVkbJuBBC = -247414.7320633114;
    double iMPmbnKAglkAlD = 972368.6240685238;
    bool rciNglC = false;
    int xiPAk = -766902634;
    int gqxEok = -608571353;

    if (rciNglC != true) {
        for (int YdbBvXQuQlLhGY = 753666554; YdbBvXQuQlLhGY > 0; YdbBvXQuQlLhGY--) {
            continue;
        }
    }

    return rciNglC;
}

bool mdtiuG::dgnKolOrRbmPNJkq(int mpAcyb, double IdhxZn, bool bPatwgv, int LozUJM, double HTxtEHjBisIqv)
{
    int ybwbPdTj = 1218449876;
    int bMRcAZI = -1463544676;
    bool csLvDCUqpSUOOZ = false;
    string rUtpyfO = string("kVzDdJOxhAPhRlWuGGeBUmcYwAtkNTMDjOqaHwaghKOzMOZBmEvSWDFWUwdvOJyemqECrnEczrdMAKIEhZNeHpTUgluFwPtyQXRpTSGSpLdYKODelZiDigjkZmOTfYDGmGFGrSeedKKVRdBXvCkBXIMLWgyeFcUjMXCGtAiDyRiYioeSmfkFoVNXKdcHXoMqgpOnmqkCoyRSRqxqyGIkYedRRlFkshIhU");

    for (int zfLxAEfrz = 2121313156; zfLxAEfrz > 0; zfLxAEfrz--) {
        mpAcyb -= bMRcAZI;
        LozUJM += LozUJM;
    }

    for (int YnLqgKXlKSevQYK = 324299107; YnLqgKXlKSevQYK > 0; YnLqgKXlKSevQYK--) {
        continue;
    }

    for (int BkySpokYQrPfYZ = 73065542; BkySpokYQrPfYZ > 0; BkySpokYQrPfYZ--) {
        mpAcyb /= mpAcyb;
    }

    if (bMRcAZI != -1745117239) {
        for (int ZJMij = 1265549162; ZJMij > 0; ZJMij--) {
            rUtpyfO += rUtpyfO;
        }
    }

    for (int kjbLoCs = 978927681; kjbLoCs > 0; kjbLoCs--) {
        IdhxZn /= HTxtEHjBisIqv;
        HTxtEHjBisIqv += HTxtEHjBisIqv;
    }

    if (bMRcAZI != 1594639398) {
        for (int PIUvuwcxqNYBlmL = 249999430; PIUvuwcxqNYBlmL > 0; PIUvuwcxqNYBlmL--) {
            continue;
        }
    }

    return csLvDCUqpSUOOZ;
}

int mdtiuG::YYLmMFmgV(int IJYfTNgS, int KZfFcVTeK, double ZczmzDIQle, int oyUfx, string ZUDaXnKwUZXiiaSP)
{
    string lCdpeKUIXaoFt = string("QZPYLMoLGbbhyQdFcWtVunNTARQWBHjpvRhCvbyPPPRimFavHmMfLchdhWKogmNzPzlLxdaGrhMkgpkwMCDqWYciDWUYFtlSLksFcbKDTlYobpYQBDdZjijyniGsgmtxKfakEWlISWPIxEYGJUPaqAnaFiTeEekRQAPZAEYxFYbppwfuixgCrRjShogfKDTiJpoOZucgRfgBsYvJWKLtZXkpukeDFAUgZNELBdzYEUbMCDXoSSjqxgFYZmyu");

    if (oyUfx >= 2065932884) {
        for (int ioGTDpdiA = 1023783932; ioGTDpdiA > 0; ioGTDpdiA--) {
            continue;
        }
    }

    return oyUfx;
}

void mdtiuG::HGVTxkoYnMIE(int FYTycwIy, double KHbsa, string MwaORTNxl, int LPSZK, double HgSXvANQxJ)
{
    bool kXKrgVXEU = true;
    bool reqZzOrVkoHJA = false;
    int UpAfUwGXoEYCNk = 1602683858;
    int FyJbCciTvg = 371735432;
    bool pHTOFZ = false;
    bool usSQeYWb = false;
    double FFWUOTIQfLSmChqw = -984420.5020183296;

    if (UpAfUwGXoEYCNk == 1824907341) {
        for (int kwnEPDYiWXTDCEB = 1269813652; kwnEPDYiWXTDCEB > 0; kwnEPDYiWXTDCEB--) {
            HgSXvANQxJ *= HgSXvANQxJ;
            kXKrgVXEU = usSQeYWb;
            MwaORTNxl += MwaORTNxl;
            reqZzOrVkoHJA = reqZzOrVkoHJA;
        }
    }

    for (int HdhYcf = 1138038177; HdhYcf > 0; HdhYcf--) {
        FyJbCciTvg -= UpAfUwGXoEYCNk;
        FyJbCciTvg /= LPSZK;
    }

    if (UpAfUwGXoEYCNk <= 371735432) {
        for (int tIQydNiahwaiGkg = 542052549; tIQydNiahwaiGkg > 0; tIQydNiahwaiGkg--) {
            continue;
        }
    }

    if (pHTOFZ == false) {
        for (int mCLYHjkyXotXap = 482040965; mCLYHjkyXotXap > 0; mCLYHjkyXotXap--) {
            reqZzOrVkoHJA = ! pHTOFZ;
            FyJbCciTvg *= FYTycwIy;
            MwaORTNxl += MwaORTNxl;
        }
    }
}

mdtiuG::mdtiuG()
{
    this->CwdJstPvAXaQLOoX(false, -758931.5704484928, 240161.84288663836, false);
    this->gXRQA(-547909.0157757511, 136729518, string("woplh"));
    this->kfULMpFovTK(false, string("KpEoujZqQMCJvOipOdqVANCDwbwCmcaukThQAsWIrkuRoMqiAYqAAAsNbepXKCWgSssWaBaGmfLLyaeaTTySiXnbSimHGwJHfspYbbGTxMhDWmzXalaeZqDihTkmtusUxShFtIRCoxtAGYUVEXAAvrCZaBsjrmaNrvOdDDdUiXWbs"), string("TZvyYdEgIhbJzmikcnOydjtKZYQmToXiIrdLfOvvQPRklKDjxcPwWzdYHqggwpxxZXWocUXtKsWZOKpHabxTfadnWpSWrVIIYGOuCNHLVDEHEuvnhrryEHsAQutDadsXWBoAmywZZxzPfPZDwTOGHUSEotWNZqHucxJaqHCbRUnIfXdsTuvtiNpdvulLPDoqJRIqhQzlJFuEjpUmbBpgHBzLJFwXjyPBwJRscVzBqFeIfoCDegIGvhttWga"), string("xHE"));
    this->YwIcOaFBv(680778.5334207175, false, 43292542, 1415460572);
    this->ydFbGWSpyM();
    this->fzXVm(string("pXZOtvwpJqNZGkiWpcpqigFWMloiXOdFQzoKDJ"), -25169.192493120787, string("XldfztPGIOKYikkUIzBAeYkaaVxWvwQUcqLDenAaiPeWPeJMOlsIuSHFLjRYnWPkHaOeukktyicyUmlEFtsxiVPsAkGJETOhCPgyEoJfMPXxkAHgbxUYBWEmWUpukwBtXyLdZPxnKEJkBPGQGqhFkbEhQKwbBpXyLrciqOmKDSOrLsnzUqpIaYmjiZXPbhdygirQdkzpiobhlhrfNgksVkfuhLGMWauHldL"), -1478917119);
    this->MFRCJJRAMOqhE(138141.37772627);
    this->GmkzQkiznwWUsFj(string("uehzaUWIgtYUglnbfktgqLMnZFfwRgObbpEZDssJfDoWTFhGmsVwgutRPbyOKfFLRLbGhegAkGxOrMTRjJcFlsVhWirtgZBEnbMpeN"), 119988.40461487393, false, -695275400, 1719386604);
    this->lSfTFJomtgTKakf(string("pbTDlLqoPqOrtzUcfXqXmZXxTTlFLACkxZgUZuFWphWNBlZYoQvDkkEmh"), true, true);
    this->HEubAHJgtgNp(1003487.2275440533, -588059235, string("ZRLaAejdRPTMoHEqGLakJpnWkGVDbPFadsCyKXFtYvESqrOXLGEMypXaVuKmMZodT"));
    this->UrpcNOIcclIt(string("BoUBxHqoOOLmxdPGLPyfTMQIsOfqCeQLBNAOgCDMSkUzEudPkNkpErGhxbBDkIDDHsYsUvYKesaiVMWWoSrsNntxTOfQQeoVIiycnMnuwJSIHVNMpAKUcWohzyRNXjNcyDhaqhNvztdOatJiSvGBgvPqDFmwCIlYpmayeOREn"));
    this->dgnKolOrRbmPNJkq(1594639398, -12653.18392035688, true, -1745117239, -703828.780672016);
    this->YYLmMFmgV(1344008926, 2065932884, -6589.423245123492, -1098442827, string("cHLHPiRapequmaSNKsRSmfSdZxkrgcnVIvXdTjjtCAQhGLfpyXHcmDkiivofdvwXEEayZUogkFQWA"));
    this->HGVTxkoYnMIE(1824907341, -796290.1739151534, string("BFOwbnDgvQVdzKONoLwKiLXbVuKzFnNAaYKGAJXTCZMQAQMfeBTDeqSpZvooZYDdRnkKBNrCCvWZByjOquYkmmrGKnIhjIDozFnqRZNKozbJkOGOHXJkoGLumQigTqVmYZzCnAhUtKhehcayVfNGitdyFCB"), 490673977, -124615.31073949371);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FBgdBt
{
public:
    double SDHYBtROAdgVPlT;
    int uJknkzzIQ;
    int FeCgcBeHBO;

    FBgdBt();
    bool ObFYQiE(string HUqwIqze, bool oyNYRFqdzSVeXt, string kHkuZHDo, double lReMiaM);
    int WfzVYMkF(int MPTESkLgeeKGnt);
    double irPgQwpppeH(double qLwCLdUR, bool CwolxxFefgZTGs, double VgooEfilnDJPRBn);
protected:
    double VarLTfvvJFO;
    string GuZtN;
    bool CcjwColDkJffis;
    string ahlOJWhzpfCyWCqO;
    double BLHblaMISZ;

    void oZCAWo(bool YbpdBP, string jYOeGdzyaiWnYzf);
    void rBVMNki(double XmNooGZpPVUNc);
    void SXRkqBMYxqQnm(double xyiXJIAoXsAc);
    bool KrNSgvgZxsDYD();
    bool WhZoDZW(double uGIUkY, string sVqci, int kHtIfIXybQgf);
    int mAznVpeQP(string aOGFLqm);
    int KrIhkGYLEMcJt();
private:
    int pbPMVhTl;
    int hHMkVGNxj;
    int HLADsAKTmBHbxXTh;
    int zaxuuT;

    int lHpHAtxstjRPwlI(int DQXyWNtT, int YaSAzXheggT, bool IYespxCMlewjtckY, bool NlFgOvOxm);
};

bool FBgdBt::ObFYQiE(string HUqwIqze, bool oyNYRFqdzSVeXt, string kHkuZHDo, double lReMiaM)
{
    double ahNvDo = -742145.8065332467;
    string uviyVHRBWtztXM = string("pzXypVenGFOkYYlFEdkVnwDxuqtwHNJVVoLgEyEuvqIotsuhQZclCHMZAXCnxXMhpTtnbqIXSfYaucFZyNoLxHXevYfcUKyBAzVeiFvOyGpwQOCTdfOvCfHCnPvnhihyXQwBslgrIUgdBOKmFkDILr");
    double AiyBPloU = -630699.3784846683;
    bool VReOGHxsvDhCzC = true;
    int bOotJDxypXGwCVfO = 733053912;
    bool NUECEGJo = false;
    int RxRopKNdWXHtHpfM = 2117304149;
    int SEIihLpilUdX = 915913902;
    int DsDcFPl = -1010541646;
    bool yOkAIDPUEMnUPwR = false;

    for (int WlCMkcHscqgIOEZ = 1684738278; WlCMkcHscqgIOEZ > 0; WlCMkcHscqgIOEZ--) {
        RxRopKNdWXHtHpfM += RxRopKNdWXHtHpfM;
    }

    for (int gYpxGbFRG = 1850571465; gYpxGbFRG > 0; gYpxGbFRG--) {
        ahNvDo = AiyBPloU;
        uviyVHRBWtztXM = uviyVHRBWtztXM;
    }

    return yOkAIDPUEMnUPwR;
}

int FBgdBt::WfzVYMkF(int MPTESkLgeeKGnt)
{
    int RUnPmWr = -584648032;
    bool PJhZRjn = true;
    string udRYn = string("LiBKlboNLmloieJLEcYAKPvDJGkjrwaSHOESmVoRuWTTUwonxEbOUaiSpdvtgphpvNCbsQEAVJiYluRxLiVgddPjXEYTwxXgNTKFVyxBxMMCLzffuuFVZipFXfwSoyGgZZCUJADahbWceMc");
    double PZHDPCCLjKuPRf = -555952.3181632574;
    string YrynREhMfUwAjK = string("LvigBvmQdeLjZrfHoSKHEDmbalHfykDMQlXUmXrIoRlqhhvdOwZhVDSBPtHiUMnVConCBgoxvRfTYohmqeHISjnRHOmtpyXFrgtNkJiROwQViZDvcqMuuLywjfZjzvUNvTykUwEqmknWeiGtKcLWuUnTQPQkptTTjEAKPvlxqpc");

    return RUnPmWr;
}

double FBgdBt::irPgQwpppeH(double qLwCLdUR, bool CwolxxFefgZTGs, double VgooEfilnDJPRBn)
{
    double hsCwoCEAGpu = -701800.9601693759;
    string MyZyMF = string("KCfWqqCNWpLZuDPCYtlajVJyjfnYthGCeauupEpWUXiQkducoKLhkpJalUcMykNOzlgNJaRyLIBuSyzgxWBbcKUTfnKAaHQbFlIJmNBJLzjlVOyUtvORCcZPwxPSBXItugMviaxiSEiogdROHGIyFPFSIjmACyKjrSkjaYQhhdKuteZFDOCksJEEurqxXTFPvZWfOzbIouhvLVETlzeyJLkkuSlPVEnMayeZzuygvskOkETQitvIbteKjtirIl");
    double dwOWsEzwNblXrj = 152997.91500630206;

    for (int hndUzPPONtugpE = 1965985346; hndUzPPONtugpE > 0; hndUzPPONtugpE--) {
        MyZyMF = MyZyMF;
        qLwCLdUR /= qLwCLdUR;
        VgooEfilnDJPRBn /= hsCwoCEAGpu;
        VgooEfilnDJPRBn = VgooEfilnDJPRBn;
    }

    return dwOWsEzwNblXrj;
}

void FBgdBt::oZCAWo(bool YbpdBP, string jYOeGdzyaiWnYzf)
{
    bool iAfGXBT = false;
    bool SDIGIgNr = false;

    if (SDIGIgNr != false) {
        for (int rWkYARrnXdJR = 1280844417; rWkYARrnXdJR > 0; rWkYARrnXdJR--) {
            iAfGXBT = ! iAfGXBT;
            YbpdBP = iAfGXBT;
        }
    }

    if (YbpdBP != false) {
        for (int fBEnxtDhK = 830625456; fBEnxtDhK > 0; fBEnxtDhK--) {
            continue;
        }
    }

    for (int acwHmKRZf = 624775667; acwHmKRZf > 0; acwHmKRZf--) {
        SDIGIgNr = YbpdBP;
        SDIGIgNr = iAfGXBT;
        iAfGXBT = iAfGXBT;
        YbpdBP = ! YbpdBP;
        iAfGXBT = iAfGXBT;
    }

    if (SDIGIgNr != false) {
        for (int aefUFOx = 1081647802; aefUFOx > 0; aefUFOx--) {
            YbpdBP = ! SDIGIgNr;
            YbpdBP = iAfGXBT;
            SDIGIgNr = ! SDIGIgNr;
            iAfGXBT = ! SDIGIgNr;
            iAfGXBT = YbpdBP;
        }
    }

    if (iAfGXBT == false) {
        for (int WtJHsVJPvYoiDsS = 1986911519; WtJHsVJPvYoiDsS > 0; WtJHsVJPvYoiDsS--) {
            YbpdBP = ! YbpdBP;
            SDIGIgNr = ! iAfGXBT;
            iAfGXBT = YbpdBP;
            YbpdBP = iAfGXBT;
            iAfGXBT = iAfGXBT;
            jYOeGdzyaiWnYzf = jYOeGdzyaiWnYzf;
        }
    }

    if (iAfGXBT == true) {
        for (int ikciUY = 1334550977; ikciUY > 0; ikciUY--) {
            SDIGIgNr = iAfGXBT;
        }
    }
}

void FBgdBt::rBVMNki(double XmNooGZpPVUNc)
{
    bool hPdZifQUHT = true;

    if (XmNooGZpPVUNc > -566362.408087282) {
        for (int PkSxJIor = 22565832; PkSxJIor > 0; PkSxJIor--) {
            XmNooGZpPVUNc /= XmNooGZpPVUNc;
            XmNooGZpPVUNc = XmNooGZpPVUNc;
        }
    }
}

void FBgdBt::SXRkqBMYxqQnm(double xyiXJIAoXsAc)
{
    double zovokEDaVPv = -878565.282746933;
    double dlgxyYQFRw = 598097.0404584018;
    int KFJKVlSHDoT = -1932086818;
    double cJUjbwsbeVrZxDog = 382243.4736792874;
    int TipYdvIAZJKDkMk = 2115569308;
    bool ILLeZrTNZmND = false;
    bool wyWpH = false;
    bool HeMTcStomYEH = true;
    double MYBeCbDkL = -651166.620814538;

    for (int EwBSrw = 1793962548; EwBSrw > 0; EwBSrw--) {
        continue;
    }

    for (int icMmrSssvAVRMce = 91875139; icMmrSssvAVRMce > 0; icMmrSssvAVRMce--) {
        KFJKVlSHDoT = TipYdvIAZJKDkMk;
        MYBeCbDkL /= cJUjbwsbeVrZxDog;
    }

    if (KFJKVlSHDoT <= 2115569308) {
        for (int ZeqexHdqn = 1362672507; ZeqexHdqn > 0; ZeqexHdqn--) {
            TipYdvIAZJKDkMk /= TipYdvIAZJKDkMk;
            dlgxyYQFRw += MYBeCbDkL;
        }
    }

    for (int kwxTGsnCylmi = 1862778770; kwxTGsnCylmi > 0; kwxTGsnCylmi--) {
        HeMTcStomYEH = ! wyWpH;
    }
}

bool FBgdBt::KrNSgvgZxsDYD()
{
    int laLLtcSTfEV = -53338291;
    double zMPgmQPAOaQjcYU = -582401.557686321;
    double PbJeiT = -563790.0446505297;

    if (zMPgmQPAOaQjcYU != -582401.557686321) {
        for (int PuIfI = 1017461875; PuIfI > 0; PuIfI--) {
            PbJeiT *= PbJeiT;
            PbJeiT /= PbJeiT;
            zMPgmQPAOaQjcYU += PbJeiT;
            PbJeiT -= PbJeiT;
            zMPgmQPAOaQjcYU = zMPgmQPAOaQjcYU;
        }
    }

    for (int VCzETlqpwFUN = 794448858; VCzETlqpwFUN > 0; VCzETlqpwFUN--) {
        zMPgmQPAOaQjcYU -= zMPgmQPAOaQjcYU;
        zMPgmQPAOaQjcYU /= PbJeiT;
        PbJeiT += PbJeiT;
        laLLtcSTfEV += laLLtcSTfEV;
        PbJeiT *= PbJeiT;
        PbJeiT = PbJeiT;
        PbJeiT *= zMPgmQPAOaQjcYU;
    }

    if (zMPgmQPAOaQjcYU > -563790.0446505297) {
        for (int hUpRa = 1353390261; hUpRa > 0; hUpRa--) {
            continue;
        }
    }

    return false;
}

bool FBgdBt::WhZoDZW(double uGIUkY, string sVqci, int kHtIfIXybQgf)
{
    int cCyywpiffkXzpd = 425275099;
    bool bPcqQadLHtYcP = true;
    string jEddiC = string("WGuPrXBuDloRfDFumgavzmLErPwggDThvUncMnkRseiOaijVMAeEOcoBzOknQJDYOntCJFBzgUacxewjRGsdDMcAaEWAsgBvwVyTfNfjiNHvnOsNCboMIxFlQXDNhSubresjksviUosrYkUuOjZQXaxjzalJXqDApWQNFuyyqgzWjlkySSrdrrNpxMhGYwiTHaXF");
    int iwnskote = 1598036250;
    int gInnlXdvYvC = 1799933859;
    string PBjHBbUw = string("vSuzanctuJQamMrHGcUgibYSTsvOCIPIUQWdcePRHgqlVzpbfyJLGBSpnSQlGqzwkKFiYhUWvDnUzNPSr");
    double caUzIlmGhOUqkCw = -872535.6793137058;
    int MlWCDRXddarTQres = 2001914579;
    bool lKKcnHcAzA = true;

    if (lKKcnHcAzA != true) {
        for (int AUcfXSDs = 96824374; AUcfXSDs > 0; AUcfXSDs--) {
            sVqci += jEddiC;
            kHtIfIXybQgf -= MlWCDRXddarTQres;
            cCyywpiffkXzpd *= kHtIfIXybQgf;
        }
    }

    if (iwnskote <= 670409446) {
        for (int uLXWfLLM = 1619829978; uLXWfLLM > 0; uLXWfLLM--) {
            iwnskote += iwnskote;
        }
    }

    if (cCyywpiffkXzpd != 2001914579) {
        for (int waNEoDyYhDYRbQ = 825185085; waNEoDyYhDYRbQ > 0; waNEoDyYhDYRbQ--) {
            kHtIfIXybQgf /= cCyywpiffkXzpd;
        }
    }

    for (int yacahtLscFUtHeKu = 834562654; yacahtLscFUtHeKu > 0; yacahtLscFUtHeKu--) {
        cCyywpiffkXzpd = iwnskote;
    }

    for (int zdXPFBgByXIvcEFB = 407555367; zdXPFBgByXIvcEFB > 0; zdXPFBgByXIvcEFB--) {
        iwnskote /= kHtIfIXybQgf;
    }

    return lKKcnHcAzA;
}

int FBgdBt::mAznVpeQP(string aOGFLqm)
{
    double qpcoX = -291804.39175611787;
    bool FOpxPHE = true;
    bool BUZxXo = true;
    string psxujSNj = string("foCDfztRacAOBgxtWwcgFVkuXMLSAeqRJHdAZdrKfspVmzCQPWcjUInOYMkGZKkUlVokpgQFWCzSJubVBlVvlGxIoYgaoDVKmDtIKmTkLEIAviPjPEFfHuXpcXXJJCxOIUoJOWbNqFBSZGpoTDDNwwszcKlUplzkxMDJUWeArzRixlDFnIUvNtIQhtqyWyAW");
    int hpbByBr = 796944892;

    for (int RwHaWADKjJqjUli = 879884827; RwHaWADKjJqjUli > 0; RwHaWADKjJqjUli--) {
        continue;
    }

    return hpbByBr;
}

int FBgdBt::KrIhkGYLEMcJt()
{
    double ZrUnCLsDZXvSqmt = 144713.32574186457;
    bool xIPrxKTeWVFTwu = true;
    double ApAePCSswBdPzJoX = -705849.8368094957;
    bool LGDDjcKQzbVTdwc = false;

    for (int KQpHQ = 434127792; KQpHQ > 0; KQpHQ--) {
        LGDDjcKQzbVTdwc = ! LGDDjcKQzbVTdwc;
        ApAePCSswBdPzJoX -= ZrUnCLsDZXvSqmt;
    }

    return 57657045;
}

int FBgdBt::lHpHAtxstjRPwlI(int DQXyWNtT, int YaSAzXheggT, bool IYespxCMlewjtckY, bool NlFgOvOxm)
{
    bool KbnKIzNAqDcITvs = true;
    double QAmRBjgM = -661578.6719134445;
    double GnskYGInBb = -873477.710487962;
    double LOCtq = -544225.0123719233;
    string bziVq = string("UeSKZrDcwWChCQXGyQXsdUKmHqJnNnpqhtGIijVAbgaEbDMurKuQafZmAaipPsjkiSAxEk");
    double PiXaSnHhDl = 605597.068153602;
    string bWxjNujXl = string("FXjdoBwIlciQwiMRIEsRJGUuMHtVYLUXmitQwjCjlhXdCNRzwueKOsMBApFtuogsTdCAZnMoyxxGQCOxvXypRLHkXcmCOLRTJPgSrigjyEbLyQdQMbUSQyZiPmSTygFBqGCHkfexssrRTngRMfwvdNOvsjAnIKWomWIKqqWHBzWtQHrogYXgjrFakOvNbCvvYxMMeewpkhMwLpBaiyGYHHVGacSlgJzXLAkRPeVQXP");
    string iGSgYUE = string("eMraSazZtOtnYLBIDhfpmEzAxLzyfTBoDHMODFxguFCTwjuTmJoBEIwRkBkbBRCXQRPIkKGwMFSEeKscYJnoAzQUBLCORpmJtRbMfhafGxVlZdGiIKTXEEbJDDEPXTIDpWFZnEdoaMJabiUiOYKTGErHnNvuGDWvlvHAcrkkZLXwJdcuhqyPHvOrFNOmHUnwQHLMvnUnqtRLvjsehSclNnQoyCaKSUlEXKoimkbYdMsGykuaOrm");

    for (int xNkdG = 1965697772; xNkdG > 0; xNkdG--) {
        PiXaSnHhDl -= PiXaSnHhDl;
        NlFgOvOxm = ! KbnKIzNAqDcITvs;
    }

    for (int anMYMhcdWuKmxBn = 1749389454; anMYMhcdWuKmxBn > 0; anMYMhcdWuKmxBn--) {
        KbnKIzNAqDcITvs = ! NlFgOvOxm;
    }

    for (int RcOyGZgK = 976328627; RcOyGZgK > 0; RcOyGZgK--) {
        KbnKIzNAqDcITvs = ! NlFgOvOxm;
        LOCtq /= PiXaSnHhDl;
    }

    for (int erIfHqrSmiecDPg = 33260894; erIfHqrSmiecDPg > 0; erIfHqrSmiecDPg--) {
        LOCtq -= LOCtq;
    }

    for (int NMYIXjaCDhadW = 149354143; NMYIXjaCDhadW > 0; NMYIXjaCDhadW--) {
        continue;
    }

    for (int EuancWSjNAb = 1687558565; EuancWSjNAb > 0; EuancWSjNAb--) {
        bWxjNujXl = bWxjNujXl;
        PiXaSnHhDl = GnskYGInBb;
    }

    return YaSAzXheggT;
}

FBgdBt::FBgdBt()
{
    this->ObFYQiE(string("hrJQyHrIrBARgngKRefGlfEvHyotFRShqgIHlyUpR"), false, string("RAPXlxMYeZcNblZdraJCJBZDLUcAQoDZjpjDMVEbSuwrnAWJwQYwtmxaxuTCVSfSpFxtQuyVGJngGrsAxrbflYiYroBoG"), 130903.77128777461);
    this->WfzVYMkF(-848260294);
    this->irPgQwpppeH(-566257.003678, true, 258668.33767129417);
    this->oZCAWo(true, string("CIbtBdLacEPsFfsnzSyqcVhZaOloPoVJMJEUPSmVuwqaxUNvspUaZMIPzoVxctXbDudZLgiYWBAzSPmoKvPqxziBCKCquHGHTQxphZnhkttyMMgsHgrUao"));
    this->rBVMNki(-566362.408087282);
    this->SXRkqBMYxqQnm(129588.57320030169);
    this->KrNSgvgZxsDYD();
    this->WhZoDZW(-519771.0855066489, string("DLkiDiYuNCCmxGVyLrcVobobonUiSVEWGkQkdyRgRlLQaWvwYAUlVUKyeWvbTbdqlrBTCLfBAtCgmTnZQMQIyvYLjXqulOgRbZnaVdCUMLdsRIxtjLPpwJHtMhBwKJfChFepQJiBHiUiugRcwYGuFqUIxtccFyxnWBFeyGIcHdGzIRlhKbKOtGVMVEjyUSkimqfqxgPSJEaJwNumjNuyiniPUiMplLWA"), 670409446);
    this->mAznVpeQP(string("UGhGEuxwEWBCAvTybxnGslghbltcBvQEgdcYpqPlEWLDKkwXahsOPCh"));
    this->KrIhkGYLEMcJt();
    this->lHpHAtxstjRPwlI(389925860, -123211716, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XgcrfSMMYGu
{
public:
    string fQEGBacTBzJ;
    double ZzPrufSUyu;
    int FaZKR;
    string DahHk;
    string vYehtCXQipRIa;
    string aLQgpXNLNiQOd;

    XgcrfSMMYGu();
    string xrXEs();
    void MMuSZImjDI(bool qpfziiGzC, bool SWvbWZqWGBXgJHOK);
    bool QatHQxmEKFv(bool AOYIvcZTMglMmzX);
    string YSnyYaIKXrFb(double kioQLWnnKwMViO, string CahSYahvT);
    void zSXterIMCPMlN(int tiMRlDrE, bool PiuqgFY);
    void MNIbmdFjdUJWUHc(string KcGqLiIOD, bool SaAqKifeInBxv, string RWEXXaIzmmD, string LwbaiqdnEJR, int YbxTis);
    int CvwfIvrNuhb();
    string FYKMLtFspDrIVF(bool hcQNbOQiT, bool kyzxADaIyjsd, double ApTDqATsgJ, bool zPffNBUMvBBgC, double pcBDIiqxSOyGhh);
protected:
    int OZcIWeEtdSfnyd;
    bool dKmSkYGQQRSCan;
    bool TUdcBcjgyKpKucaW;
    double STIKHJq;
    double pEKwCX;
    double JMvzjFjllluYXMcV;

    string kskaEFpjIfMhu(double bCYQKJKjJRiz, double sgyEx);
    void lvcVQwJfvN(int OmpVGEPMr, int aTgvdoIkVJD, int QLNqjNgctWYooo);
private:
    double WMZmlLLOt;

    void ItAHxO(string mrwQBphjB);
    bool UZrluOCyR(bool gFijskLYGas, bool mnPvaXnh, int QXAnJzW, bool MYGiBl, bool wvgLxOzvrIclBY);
    bool LTMkzVFbDCHN();
    void gROyWtFV(double OLLnVqUYTlqDBrxN);
    int dHKJYiOy(bool VYTMMPvJ, string YPrgrfkIoEW, bool QLXqezKWOCHMtZ, string UZJCoAdQwldpUwgN, int BScbWzIwM);
    int iLcgAYlsxnyXv(double MCVanMDJwr, bool gDoJywR);
    string jypQIpDKFPN(double opUzg, bool jBnrJ);
};

string XgcrfSMMYGu::xrXEs()
{
    int mdASIcgNyV = 1111160260;
    int HGaKgUUz = -793572403;
    int qIjZxiwlN = -678807102;

    if (qIjZxiwlN <= -678807102) {
        for (int XAoOsMghFgyOCke = 820244725; XAoOsMghFgyOCke > 0; XAoOsMghFgyOCke--) {
            mdASIcgNyV -= qIjZxiwlN;
            mdASIcgNyV -= HGaKgUUz;
            qIjZxiwlN = qIjZxiwlN;
            qIjZxiwlN /= mdASIcgNyV;
            mdASIcgNyV -= HGaKgUUz;
        }
    }

    if (mdASIcgNyV > 1111160260) {
        for (int LZJawQDyJ = 1255943800; LZJawQDyJ > 0; LZJawQDyJ--) {
            qIjZxiwlN -= HGaKgUUz;
            qIjZxiwlN -= mdASIcgNyV;
            qIjZxiwlN = qIjZxiwlN;
            qIjZxiwlN *= HGaKgUUz;
        }
    }

    if (HGaKgUUz != -793572403) {
        for (int rigcIMfApkO = 677025562; rigcIMfApkO > 0; rigcIMfApkO--) {
            qIjZxiwlN *= mdASIcgNyV;
            HGaKgUUz /= HGaKgUUz;
            mdASIcgNyV /= qIjZxiwlN;
            qIjZxiwlN *= mdASIcgNyV;
        }
    }

    if (HGaKgUUz < -793572403) {
        for (int NCmqTALGofk = 232520279; NCmqTALGofk > 0; NCmqTALGofk--) {
            qIjZxiwlN /= mdASIcgNyV;
            HGaKgUUz /= HGaKgUUz;
            qIjZxiwlN += HGaKgUUz;
            HGaKgUUz = mdASIcgNyV;
            mdASIcgNyV /= HGaKgUUz;
            qIjZxiwlN += HGaKgUUz;
            HGaKgUUz -= HGaKgUUz;
            mdASIcgNyV += HGaKgUUz;
            HGaKgUUz /= qIjZxiwlN;
        }
    }

    return string("qdCOFfjQEFaRuyvBjImDOgTptujutffivFbwssNpc");
}

void XgcrfSMMYGu::MMuSZImjDI(bool qpfziiGzC, bool SWvbWZqWGBXgJHOK)
{
    int oXtfngJBi = 2062515841;
    bool eGFzc = true;
    double rgiPwiGUigxs = -611058.6620065126;
    bool lEbzkhS = true;
    double wjriqqFWcNLq = -122678.97966931788;
    string OKooBHAgqoLOQMb = string("uCHPlCllQgmoyGLXDAUtrUnVgMAgbjfRmuuPzHRRIHDGmibPehlHOCqoJkMmNlHZAYJjeiwVXhnWjmSopGNQfBoJntQStNHbcrMt");
    bool GIEkYwlWMyo = true;
    int JboBfB = 1387250305;
    double nKxhoOcBAaOfVjU = 214978.9892178382;

    for (int OofuBZIUAFeh = 593776036; OofuBZIUAFeh > 0; OofuBZIUAFeh--) {
        eGFzc = eGFzc;
        rgiPwiGUigxs += wjriqqFWcNLq;
    }

    for (int txOhJlLy = 1750337504; txOhJlLy > 0; txOhJlLy--) {
        JboBfB *= oXtfngJBi;
    }
}

bool XgcrfSMMYGu::QatHQxmEKFv(bool AOYIvcZTMglMmzX)
{
    string EVwtQglOJWZKfJ = string("cRNYqWanUoVSLYoDsRfOYPCxQnRjtthnNlBIpOppjuebucZcgZYEUoOeqfltCPVgwYgtuJgbfUjROOoqoIHkWTBLxmXNbVbCiMaRS");
    int LnjRs = -2127513978;
    int prfgP = -797553662;
    int SDpRyYkTrK = 1864232241;
    double vZApkeRTpsUxvmB = 230299.57808013452;
    double hPvtExkPzexUNVf = -824761.255879275;

    for (int cqleFoBYVxXYPgr = 1323469609; cqleFoBYVxXYPgr > 0; cqleFoBYVxXYPgr--) {
        prfgP = prfgP;
        prfgP /= LnjRs;
    }

    if (vZApkeRTpsUxvmB > 230299.57808013452) {
        for (int DTDTEDgwnFL = 642241716; DTDTEDgwnFL > 0; DTDTEDgwnFL--) {
            vZApkeRTpsUxvmB *= hPvtExkPzexUNVf;
        }
    }

    for (int vjvFVDJFE = 776503900; vjvFVDJFE > 0; vjvFVDJFE--) {
        prfgP = LnjRs;
    }

    for (int dRaXZRLUYqNwfcMn = 2038784158; dRaXZRLUYqNwfcMn > 0; dRaXZRLUYqNwfcMn--) {
        prfgP *= LnjRs;
        hPvtExkPzexUNVf *= hPvtExkPzexUNVf;
    }

    return AOYIvcZTMglMmzX;
}

string XgcrfSMMYGu::YSnyYaIKXrFb(double kioQLWnnKwMViO, string CahSYahvT)
{
    int OZUDugTAk = -680104377;
    double VxNazIKFshaxDFfu = -392699.4756994416;
    double fUGlLExJsh = 841198.9970026226;
    int eZpyGp = -948618135;
    bool siSig = false;

    if (kioQLWnnKwMViO < 841198.9970026226) {
        for (int ootppijZYIbk = 1805317309; ootppijZYIbk > 0; ootppijZYIbk--) {
            eZpyGp *= eZpyGp;
            fUGlLExJsh *= kioQLWnnKwMViO;
        }
    }

    for (int WPBvvbLjTSp = 1303863040; WPBvvbLjTSp > 0; WPBvvbLjTSp--) {
        continue;
    }

    for (int obVtq = 1888715483; obVtq > 0; obVtq--) {
        VxNazIKFshaxDFfu *= VxNazIKFshaxDFfu;
    }

    for (int fVAdL = 2111084347; fVAdL > 0; fVAdL--) {
        continue;
    }

    for (int cZSDtcYXYL = 131249058; cZSDtcYXYL > 0; cZSDtcYXYL--) {
        fUGlLExJsh += kioQLWnnKwMViO;
    }

    return CahSYahvT;
}

void XgcrfSMMYGu::zSXterIMCPMlN(int tiMRlDrE, bool PiuqgFY)
{
    int jUhHuFLficMmx = -450860265;
    int zbChvMX = 1506473891;
    double xxIzfKowpzPCwfrU = 60119.02841861853;
    double tHexkl = 340432.83446418814;
    int GwiWdnrhtK = -1308973054;
    bool MAwbfysOUsAd = true;
    int pPhDmprlf = -926543800;
    bool zllggwUSiJcjlE = true;
    int TzBcpFFSjOjbMEnz = -760975687;
    string KugbAEScExIH = string("oLGZRNPyKe");

    for (int tuMpgTzsnnCcQ = 909570702; tuMpgTzsnnCcQ > 0; tuMpgTzsnnCcQ--) {
        tiMRlDrE -= jUhHuFLficMmx;
        GwiWdnrhtK /= jUhHuFLficMmx;
        tiMRlDrE -= jUhHuFLficMmx;
    }

    if (pPhDmprlf == 1506473891) {
        for (int jzmaZaCb = 865942047; jzmaZaCb > 0; jzmaZaCb--) {
            zllggwUSiJcjlE = ! MAwbfysOUsAd;
        }
    }
}

void XgcrfSMMYGu::MNIbmdFjdUJWUHc(string KcGqLiIOD, bool SaAqKifeInBxv, string RWEXXaIzmmD, string LwbaiqdnEJR, int YbxTis)
{
    int SBidUAmZy = -565662389;
    int sifNhKMag = 1084032648;
    bool LBKjJreJa = true;

    for (int sckCCWoyhhJRjXwJ = 1800100066; sckCCWoyhhJRjXwJ > 0; sckCCWoyhhJRjXwJ--) {
        SaAqKifeInBxv = LBKjJreJa;
        YbxTis = sifNhKMag;
    }

    for (int GeNpN = 1287916158; GeNpN > 0; GeNpN--) {
        SBidUAmZy -= SBidUAmZy;
        RWEXXaIzmmD += KcGqLiIOD;
        LBKjJreJa = SaAqKifeInBxv;
    }

    if (KcGqLiIOD > string("QPKhWnArZnqDaPvstVdSHJeqsUnLbLCqnCMBwmsvHKAJHyRugHfaBuEhRaCqXXXcpJeNFRkipb")) {
        for (int KeciDsbjYu = 1295740108; KeciDsbjYu > 0; KeciDsbjYu--) {
            SBidUAmZy *= SBidUAmZy;
            sifNhKMag /= SBidUAmZy;
            SaAqKifeInBxv = ! LBKjJreJa;
        }
    }

    for (int PoqszQMX = 1790966045; PoqszQMX > 0; PoqszQMX--) {
        SBidUAmZy *= sifNhKMag;
        YbxTis *= SBidUAmZy;
        YbxTis = YbxTis;
        YbxTis -= sifNhKMag;
    }
}

int XgcrfSMMYGu::CvwfIvrNuhb()
{
    double qcExkheFBSuTuJ = -27529.05423874073;
    string KTEbFjEfmJGu = string("nlyKiGTewVaSkXwaKiigFNAoCltqvbjshTHBulFIbITBpsxVfxKrZcjAbFJhMirGiPwgZVZGYFAiSctVynkYLtbHWmgVSPUlGVB");
    double dtUqmylfB = -135505.4789148381;
    string hluqzRFRDYpr = string("vqVRHTnNrYoaQUQQIQzy");
    bool yZMCsltdPsunKm = true;
    int ToXkOfuYcfx = 1438396489;
    double PeskDSIuLatchg = 595320.4351708737;
    double QMDjrPGFBByFT = -384439.30933932966;
    bool xXVuLLMaBJjg = false;
    double VyhQkBRyWVVCV = 1028651.3319278738;

    if (QMDjrPGFBByFT != -135505.4789148381) {
        for (int blpHwnGsBPuGA = 1291332987; blpHwnGsBPuGA > 0; blpHwnGsBPuGA--) {
            qcExkheFBSuTuJ += QMDjrPGFBByFT;
            yZMCsltdPsunKm = xXVuLLMaBJjg;
            qcExkheFBSuTuJ *= QMDjrPGFBByFT;
            VyhQkBRyWVVCV = PeskDSIuLatchg;
        }
    }

    for (int jQXGEiEVqy = 1702617333; jQXGEiEVqy > 0; jQXGEiEVqy--) {
        qcExkheFBSuTuJ -= dtUqmylfB;
        dtUqmylfB -= dtUqmylfB;
    }

    for (int KHioRfvv = 968945821; KHioRfvv > 0; KHioRfvv--) {
        KTEbFjEfmJGu += KTEbFjEfmJGu;
    }

    return ToXkOfuYcfx;
}

string XgcrfSMMYGu::FYKMLtFspDrIVF(bool hcQNbOQiT, bool kyzxADaIyjsd, double ApTDqATsgJ, bool zPffNBUMvBBgC, double pcBDIiqxSOyGhh)
{
    double kxlIWYg = 937369.2523184335;
    bool CbOSQYnMuVE = false;
    string NaBPGoy = string("twcEITXodgvRfiWtYSOGyutbdQCwCwuGpiILpHBKGkHfrelgPgwZXnpFLUIJKDJ");
    bool PPRiFJnw = true;
    string qGAmhDkrlpfwQ = string("DcHFsFoVumU");
    int DvztadsHsrXmB = -1441530547;
    string cjBTNcNVFJa = string("iWAQfEbdlixEkAtFwWgbfcNqjmFCETmefrrEfXRZQisqXEsIkxOZtRksMeaDbnFBORXJVZEjFjIXKMpDigprKnrPTdKJVscOsnxGtCBGGUBKwmw");
    bool YNzFePsBWP = true;

    for (int XuTAHKrjRcHPWqQ = 1741622084; XuTAHKrjRcHPWqQ > 0; XuTAHKrjRcHPWqQ--) {
        NaBPGoy = NaBPGoy;
    }

    for (int ZyDGI = 134539713; ZyDGI > 0; ZyDGI--) {
        zPffNBUMvBBgC = ! kyzxADaIyjsd;
    }

    for (int AkpFUWtfXxcdx = 316120678; AkpFUWtfXxcdx > 0; AkpFUWtfXxcdx--) {
        cjBTNcNVFJa += NaBPGoy;
        YNzFePsBWP = ! zPffNBUMvBBgC;
    }

    for (int xKezLQbistLfO = 25109457; xKezLQbistLfO > 0; xKezLQbistLfO--) {
        CbOSQYnMuVE = ! PPRiFJnw;
    }

    for (int QnfjsaHctrCJGVuU = 1267520624; QnfjsaHctrCJGVuU > 0; QnfjsaHctrCJGVuU--) {
        kyzxADaIyjsd = ! CbOSQYnMuVE;
        qGAmhDkrlpfwQ = qGAmhDkrlpfwQ;
    }

    return cjBTNcNVFJa;
}

string XgcrfSMMYGu::kskaEFpjIfMhu(double bCYQKJKjJRiz, double sgyEx)
{
    bool cTxuGBZd = true;
    string yJKCRHFxY = string("qGCKxtAoWizyAAQYXoftQRJkZpVVKYeJBcIwTroSJoYVkdjnFiMqVsUCdBjtrhifpbnXZZHDOkOaDjdIOHechgWHeyChfxqoXmxkIuVsIQUrwpBsLZshiicnRtlJQxViTrqPkYvkCxyMAdEUYxOXuIUqaSxQFhJtkBVXLRzDbwGbRXzOnFRquSUxUmtWtdoyWwuSgOefSWtsTsVtluKBgPfiwlgRVsXgNzLHljEozRveUOkqmu");
    int SbXcfql = 1787654191;
    double BqjQkLlcbCNruH = 936198.8862903767;
    int iiVaNmcyCKcSlt = 1695795196;
    double AZFGVqVomEfJbxfl = 937447.567837396;

    for (int seVTUL = 1804408303; seVTUL > 0; seVTUL--) {
        iiVaNmcyCKcSlt *= SbXcfql;
        bCYQKJKjJRiz /= BqjQkLlcbCNruH;
        iiVaNmcyCKcSlt -= iiVaNmcyCKcSlt;
        bCYQKJKjJRiz /= AZFGVqVomEfJbxfl;
    }

    for (int ahwvVtFAa = 2138823286; ahwvVtFAa > 0; ahwvVtFAa--) {
        AZFGVqVomEfJbxfl -= sgyEx;
        AZFGVqVomEfJbxfl = sgyEx;
        sgyEx += sgyEx;
    }

    return yJKCRHFxY;
}

void XgcrfSMMYGu::lvcVQwJfvN(int OmpVGEPMr, int aTgvdoIkVJD, int QLNqjNgctWYooo)
{
    double RHsqevnLWg = -411841.00058773055;
    double WYZPEFfkYIGk = -310174.87393817096;
    int SeChqtfjaP = -1423719992;
    double kczEiaYAxcs = 699477.0166508867;
    double slLoLrUxjjgmB = -1005796.8910829786;
    int mUFrvtnczTSrdxB = -27682646;
    int DBfIeG = 575926251;
    double LwxDA = -908555.1875120343;

    if (DBfIeG > -1423719992) {
        for (int PjHrHzUzshTyW = 1830032406; PjHrHzUzshTyW > 0; PjHrHzUzshTyW--) {
            RHsqevnLWg -= kczEiaYAxcs;
            RHsqevnLWg = slLoLrUxjjgmB;
        }
    }
}

void XgcrfSMMYGu::ItAHxO(string mrwQBphjB)
{
    bool prpivOXozMU = true;
    bool cONagvlPqp = true;
    string BGJeD = string("GBBqPvQmsgnaDyDNQpBQSFhjkUVvaqDcJdwEsTLTPtGEuiLCUKtHSWuHxKpKxUBFEXteNlsHLjDjYMwBJGSrvEcJZoryfZyJAtABxlfdvDzQMGDrsQMAivwyqDyILqaxGDHYkZBWcuUshXPlQYaIqPkgizaJsO");
    int zvpRdKipDRp = -1567492002;
    int IxVmyMWXCGRlQ = -412615982;
    bool pNhyqYZ = false;
    int xGmYrM = -1692709586;
    double wioGVjeiA = 782933.0609202844;

    if (xGmYrM <= -1692709586) {
        for (int edcnc = 1536839441; edcnc > 0; edcnc--) {
            xGmYrM -= xGmYrM;
            prpivOXozMU = prpivOXozMU;
            prpivOXozMU = prpivOXozMU;
            zvpRdKipDRp /= zvpRdKipDRp;
        }
    }
}

bool XgcrfSMMYGu::UZrluOCyR(bool gFijskLYGas, bool mnPvaXnh, int QXAnJzW, bool MYGiBl, bool wvgLxOzvrIclBY)
{
    double OxCCQQyaJrnYb = 204380.35339718842;
    string XBzoGBLrnGz = string("yUjvIuDvEMdEPKvpcUzsQgofuBDkzVuFFlUnsEnqeWQMAZSxJSXgNsnKAiWjIkmgWaQtPYcSSIUdyuYlMdizkzJAPTkObMaZGsvTZaCObsnTwnISivyEnHEtciakiYdOFczQewRziFIbLdMCWuSJGjfAXPMfAejmpNLLrElegzEAjqGskeaKcdyAgZapN");
    double WqxMu = 512181.8407034454;
    double bcugercUIfRuJghq = -124432.99038336157;
    int wvIMLll = -46643081;
    bool aDQlBMUvjZd = true;
    string MzdWL = string("ssKTGWJ");

    return aDQlBMUvjZd;
}

bool XgcrfSMMYGu::LTMkzVFbDCHN()
{
    int ouyYlEAFMbE = 1010583499;

    if (ouyYlEAFMbE >= 1010583499) {
        for (int GGCHWYZNwDSjxqi = 1649036898; GGCHWYZNwDSjxqi > 0; GGCHWYZNwDSjxqi--) {
            ouyYlEAFMbE *= ouyYlEAFMbE;
            ouyYlEAFMbE -= ouyYlEAFMbE;
            ouyYlEAFMbE *= ouyYlEAFMbE;
            ouyYlEAFMbE = ouyYlEAFMbE;
            ouyYlEAFMbE -= ouyYlEAFMbE;
            ouyYlEAFMbE -= ouyYlEAFMbE;
            ouyYlEAFMbE /= ouyYlEAFMbE;
            ouyYlEAFMbE = ouyYlEAFMbE;
            ouyYlEAFMbE /= ouyYlEAFMbE;
            ouyYlEAFMbE = ouyYlEAFMbE;
        }
    }

    if (ouyYlEAFMbE == 1010583499) {
        for (int RabmijdobxGjfWDC = 1995936659; RabmijdobxGjfWDC > 0; RabmijdobxGjfWDC--) {
            ouyYlEAFMbE /= ouyYlEAFMbE;
            ouyYlEAFMbE -= ouyYlEAFMbE;
        }
    }

    if (ouyYlEAFMbE == 1010583499) {
        for (int jlwSC = 976879269; jlwSC > 0; jlwSC--) {
            ouyYlEAFMbE += ouyYlEAFMbE;
            ouyYlEAFMbE += ouyYlEAFMbE;
            ouyYlEAFMbE = ouyYlEAFMbE;
            ouyYlEAFMbE *= ouyYlEAFMbE;
            ouyYlEAFMbE -= ouyYlEAFMbE;
            ouyYlEAFMbE *= ouyYlEAFMbE;
            ouyYlEAFMbE = ouyYlEAFMbE;
            ouyYlEAFMbE += ouyYlEAFMbE;
            ouyYlEAFMbE /= ouyYlEAFMbE;
            ouyYlEAFMbE = ouyYlEAFMbE;
        }
    }

    if (ouyYlEAFMbE <= 1010583499) {
        for (int RsOWxLYqhXO = 474891252; RsOWxLYqhXO > 0; RsOWxLYqhXO--) {
            ouyYlEAFMbE -= ouyYlEAFMbE;
            ouyYlEAFMbE *= ouyYlEAFMbE;
            ouyYlEAFMbE /= ouyYlEAFMbE;
            ouyYlEAFMbE = ouyYlEAFMbE;
            ouyYlEAFMbE += ouyYlEAFMbE;
            ouyYlEAFMbE *= ouyYlEAFMbE;
        }
    }

    return true;
}

void XgcrfSMMYGu::gROyWtFV(double OLLnVqUYTlqDBrxN)
{
    string isnYXrJh = string("SuJn");
    string GhTouxts = string("lgZMUFvTFSjNvwUEggaDeTOUlStMnBaCmKDxNlEWsosvWKpRQuXspZMmgSCSVVbSrqJbQgBJNernqIQwgebotSvPYJBewdtmfpSPgUzzgDFzLyaPRUkTiPOPMXIRAXBwEXDLOeamuwjvInHkyGMqGEFuYvxXBJvOvdBscwiindwniuthzyKAfCkNutglmFWdPsDJrTgtyzztF");
    string nowgaItbB = string("VnfJVDAysZKqojjJTvfcBSYcColCpmltTdvnyIIpGUbktRfBADnFkshYCniLXZMQJBhLCQoZftsNLDmPYLPLhhGJTgymCnyMjUSaivTFJcEsGreADwBVlmeYrgtKIcbxccrVSMspgKMtvYaXEQVEuLRMuAbISCbPCYsIWQDQOzPNNmBIDemyKbDhwMkqTQBbKaJtSkjyNAicIqfCvAmRuPJoxsXpqDNJaQGnSnfGMiXeTbzHIy");
    double ZORjMxNwEMBgoh = -1021679.5105498567;

    for (int gauweZMWw = 1548788030; gauweZMWw > 0; gauweZMWw--) {
        OLLnVqUYTlqDBrxN += ZORjMxNwEMBgoh;
        OLLnVqUYTlqDBrxN *= ZORjMxNwEMBgoh;
    }

    for (int iYlNGtyfP = 986486626; iYlNGtyfP > 0; iYlNGtyfP--) {
        ZORjMxNwEMBgoh += OLLnVqUYTlqDBrxN;
        GhTouxts = nowgaItbB;
    }
}

int XgcrfSMMYGu::dHKJYiOy(bool VYTMMPvJ, string YPrgrfkIoEW, bool QLXqezKWOCHMtZ, string UZJCoAdQwldpUwgN, int BScbWzIwM)
{
    string ICxomGAXjRESkdPc = string("dguyKMwkJXEFwTxocDZOOupQmosCgbcLghYlDziyMEuBHOMUUOzHosskurLlcNWNMbNLZCHFuMhmoxOmmVmDviNyNBGRaRyuMetPcaQtNGdlYFvUbAqKPCFRzkHuUnJaBfMwqUVtkrisiHUatnxeaPdqUSKLjaEyriYuAjhNKoVvRBPKBfgiqdBKorNjpgFxSQtmMsEAzjpvghsKo");
    int SacYHNYzhXCSbWB = -1192840493;
    double TJUyxeIDfNaj = 810577.55847603;

    return SacYHNYzhXCSbWB;
}

int XgcrfSMMYGu::iLcgAYlsxnyXv(double MCVanMDJwr, bool gDoJywR)
{
    int EgfEXL = 903718532;
    string jcnNnJizrajtIWFo = string("aXwLLaAvsDcokxLqKYollyrVdkGbedsgojkRCogYyWWVuZdoztiHFQVbPkFRSmTFajiNJisegJStLwtIpsNuXvrbxIkjUlgdFQqHnHGPpgSfBJEYapWQFhQpYNEpnRPPYrYpoKxTpHdDGOHZKaSWBJutNLBydTLmDvYHAZIEnxiPwQfgKDVmzfOTjBrPICraxPyloyJehmMWaFaqmsFKzusjGYstsswbfHaURk");
    int ZsNyihoRQvu = -589724026;
    int XxrOsqRASmRrhn = -1608961837;
    double huLgRr = 313089.8369567688;
    bool mmvoNYwNirqtKXq = false;
    bool XFTmRlhSIIW = false;
    string xGeOszIQf = string("bvpHvquqYJlfodePmgqgmnJjleXOpjYmeRmBQN");
    int bnPLIraUoEJzv = -2090220402;
    string DJxgcRvlDiw = string("V");

    if (ZsNyihoRQvu > 903718532) {
        for (int PVvNx = 933335488; PVvNx > 0; PVvNx--) {
            mmvoNYwNirqtKXq = XFTmRlhSIIW;
        }
    }

    return bnPLIraUoEJzv;
}

string XgcrfSMMYGu::jypQIpDKFPN(double opUzg, bool jBnrJ)
{
    double xEDKeyvnmjFZniWD = -457000.21891280916;
    double mRJJLXrz = -128667.04946019412;
    int fgqFRBvSzqx = 1877070339;
    double pVJLFGUzwrIuoVx = 277838.77453595947;
    bool AkjQdgZGTNKAXP = true;
    string gwZfWfA = string("jKHIoabWuIOOGBfsCBneypnKuERCaKkMzECzYpkwogZwsqkrqtSouMtHsnYnkKIfvzTczFwaAHHXcTmJWlyNaqaAGDAjoqZZIREgECiFULzMymEtZshRQNhuiteIMcAKtuomXqcImOVyyRPBCUFeZJiDWYZszGDSXUgtahrhFbjOnLKcyGTVoSCWLbeiwcPXMbCtvQJUaRgXttNaepuXwkKoFyK");
    string VTESgMf = string("zZB");
    int rXIlKVlBjs = 2114702115;
    double TGfLc = 989468.6669275227;

    for (int fuTFixR = 1534436534; fuTFixR > 0; fuTFixR--) {
        rXIlKVlBjs += rXIlKVlBjs;
        gwZfWfA += gwZfWfA;
    }

    for (int ngIkQAZnv = 762952397; ngIkQAZnv > 0; ngIkQAZnv--) {
        fgqFRBvSzqx = rXIlKVlBjs;
        AkjQdgZGTNKAXP = jBnrJ;
        mRJJLXrz += TGfLc;
    }

    return VTESgMf;
}

XgcrfSMMYGu::XgcrfSMMYGu()
{
    this->xrXEs();
    this->MMuSZImjDI(false, false);
    this->QatHQxmEKFv(false);
    this->YSnyYaIKXrFb(212673.66761392716, string("ngHycuTiHebhgqXYTUyatqPVaMSsNZdkmIpzUifNsiqeoFaldwFRiMoMipmlSqlUUsRvVEDwUJpwBjHhGCUtUgJYrwQPPFGhNQedDvXDPTZTAOaLxfCcmAwGpOAUMBljYCqLuZTKMQtdfiBKGHYyonjrLZjpyTIUuIysPAOFSSgMWbEHKmnqxoKWC"));
    this->zSXterIMCPMlN(-867769317, false);
    this->MNIbmdFjdUJWUHc(string("uWDmuEBiQPNZXQvcWwZYklVAHGsBpNUdAJmcoITcQsMCVaEwzDXswLsJtmeHZiZbSdSSzHVhuCgQltUhOrWUBcIwSrIFBesRocrjAewtOpOwWUBdtHIOwMmvSOScUjEeybLjsDRaFckmIHtMWQjSSZhWcgmPucALrPlWQBYXZanmxv"), true, string("ebkSkgoUlhHRuUTFaUGSsqZfUiaalXNNkGclqqQbABeJROwfHYesVVzNzfZZRTToyazNaHTHxpnGrXnzRZZhUFEAIQjEoOBqofGaEXjam"), string("QPKhWnArZnqDaPvstVdSHJeqsUnLbLCqnCMBwmsvHKAJHyRugHfaBuEhRaCqXXXcpJeNFRkipb"), -1694059971);
    this->CvwfIvrNuhb();
    this->FYKMLtFspDrIVF(true, true, -238591.86293099495, true, -139382.08613377492);
    this->kskaEFpjIfMhu(63235.76672610894, 714373.3319463165);
    this->lvcVQwJfvN(1960170946, 2119248607, -1972818612);
    this->ItAHxO(string("DyhvlWSzTkeipfISpFiAmgErRcRlEXCGgRvnKBCZIaIEWT"));
    this->UZrluOCyR(true, false, 786513283, true, true);
    this->LTMkzVFbDCHN();
    this->gROyWtFV(-29401.86709083904);
    this->dHKJYiOy(true, string("KjlhJXbAHXlCKsiPFYwMcMCgRqXXGAbKUaVsVLcIXVUEhHVuHGLJrbkwyxRjpGHomOBGNRdcCpZnDrUmoddpcupBqPUiRejdUFKglmiSOpeQJPjpOQFzrmZXveXNsxwOCoVyQvqdweKZOXqyvjbdGllvmBZHyWfzYbfDeXaNpvSjSIcabIPVQHocwCGXxFVNIpAONyqCHGjzhVARCVaYCz"), false, string("bIjJqbyDTDxABbLmXyytZzUsgzqqypdZwgKeAboZgRbg"), -1002013396);
    this->iLcgAYlsxnyXv(709042.7331737017, false);
    this->jypQIpDKFPN(900745.8864287232, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rMcbMqhVGQAca
{
public:
    bool eaAqfiIVyYG;
    int VKvhgf;
    double YCsKDupqEF;

    rMcbMqhVGQAca();
    int epYPTUgwUJrP(string LXeBZF, string JiXeji);
    double jNYPISGY(string SqVVgVGocs);
    string bSBSwPROTKGWr();
    string uubQEusy(int GQhotEU, int rYWiCZG);
    bool CLfVEw(string vErUjkSkIzSnTDlj);
    int CowbdmErgyA(bool gAppT);
    string lJBcCUZdtIG(double ulABQOuxKzH, bool UxGmKwhhSylZbv, int mawgvjOIJMzrhA, int EkImzswRUFypvIw);
    string OyaTZYBjTDuDzv(bool NkGVtewGRicmKQc, bool IOyqwwW);
protected:
    bool zxIuD;
    bool lDEGDp;
    string NyCJcXFTcLdMrhb;
    string VIFjfZUPsd;
    int CfegdVuHsc;

    void VfbVCF(string svwForZTbDna);
    int ndLYXYEIAsDEn();
    int gfcCYocno(bool xnpeoKy, double berFzrCBNTkU, string KyWKGVoBSOywPuTv, bool IxBJuWmbc);
    double ZFrJMWPe(double GWhHRgFJcfjuf, double IVOXivWCVJADNW, string thencVFRteoMqc, bool aYcRcQtZPAO, bool SrZbMOnrjgIm);
    void DFcNSqaBYQmtqdVv(string BNsMGsFHEhBERiV, bool kfRSIKsqvDHzNM, bool wlLVOyLlsAZiwR);
    string uKJuip(int ouhyDa);
private:
    int rPlQWIUMTGYuEsW;

    string ZVYlDzmhi(double nfWKDw, bool pmFRzoA, int ynGejzeCLcNVS);
    bool cGkzLBMjER(int STtlpGTaIJx, int eGgVjn);
    int eZACPUQCAXEn();
    double yAieRieTdar();
    double GSmNcxWJHPQce(string UwfzIkC, int oUluJEV, bool gVjaRXBSCKJxX, double IuGWTqMVRmImV);
};

int rMcbMqhVGQAca::epYPTUgwUJrP(string LXeBZF, string JiXeji)
{
    int OmOCeo = -597591525;
    int sTNBWZepzVV = 437551064;
    int BeanPgsLyni = 53216331;
    double VspZtlKcTPR = 90148.46970335871;
    double ZRdJMaZSicS = 571571.342558829;
    int sKXfAkNKUBOE = 1713406322;
    bool IofvGpRoRqfi = false;
    bool HgwPlGBGGFQzPM = true;
    string JaTRYZY = string("yEwBqaTNmYtyPVeyExHDJZVRlvbQYNcvtXQLXGEPNTUNkTpHULHbWqdVYICmDbjVnhOulbTrJOEIdgKSyBiPHLPVyFllBWPCTywkWsxpwxfXVgJNxpQeZphSOhcnyZbGCdsxQFDQKpeCAUKuvKONwYfPWmjzoKPSdhSdQsGJCZMMkteALHviDihZHoPStfOvYVzsYJiZsgHpAsZvYPzqRTpTv");

    for (int FnmkThUd = 895437543; FnmkThUd > 0; FnmkThUd--) {
        sKXfAkNKUBOE *= sKXfAkNKUBOE;
    }

    for (int ckfdpNZFT = 503178659; ckfdpNZFT > 0; ckfdpNZFT--) {
        BeanPgsLyni /= sTNBWZepzVV;
    }

    for (int FtapibFgY = 208647001; FtapibFgY > 0; FtapibFgY--) {
        ZRdJMaZSicS -= VspZtlKcTPR;
    }

    if (JaTRYZY <= string("yEwBqaTNmYtyPVeyExHDJZVRlvbQYNcvtXQLXGEPNTUNkTpHULHbWqdVYICmDbjVnhOulbTrJOEIdgKSyBiPHLPVyFllBWPCTywkWsxpwxfXVgJNxpQeZphSOhcnyZbGCdsxQFDQKpeCAUKuvKONwYfPWmjzoKPSdhSdQsGJCZMMkteALHviDihZHoPStfOvYVzsYJiZsgHpAsZvYPzqRTpTv")) {
        for (int ZzXknrEz = 926412320; ZzXknrEz > 0; ZzXknrEz--) {
            continue;
        }
    }

    return sKXfAkNKUBOE;
}

double rMcbMqhVGQAca::jNYPISGY(string SqVVgVGocs)
{
    double nTKknJUdzmgmnMhM = -862655.1237554546;
    int uvlIeyhPmrK = 1708831235;
    double EHjZzKnWHGCGRm = 119623.27354507822;
    int uJKUrBKb = -1367506905;
    int tYCpoKYyKHHzvff = -265000983;
    string pnjzhueFDHkPy = string("TIEsDAIviTEkiuiZlcCMhAGVwgovQRmajimQjbADXeR");
    int nSHdcUaXeVIzQ = -1487442366;
    int NrZQLDYVhEHbF = -789177864;

    for (int EhugxvSQGuL = 1883872108; EhugxvSQGuL > 0; EhugxvSQGuL--) {
        continue;
    }

    return EHjZzKnWHGCGRm;
}

string rMcbMqhVGQAca::bSBSwPROTKGWr()
{
    string tQdZiLkarubuHl = string("ooElRqExDDYAPrRAfYeqxKPpRYHuLdCtHMEzhdKVXkFDOHDmkhyQKGftbVKJQXmocGrfmuXEAyaEpXB");
    int BpAJJ = 2086154339;
    int DmVjgOaFRpaC = -135680237;
    string XSCgwE = string("qeQwYqNgvyNqoHUzHZdVzpIYD");
    double DukZFDSUTABLuCgs = -924614.0081923987;
    string pNDBOjzOrTUDoXE = string("FCymWenXPQdgMARyHqzruGfAnIuxFLhwiNtYvtHIlaWLuOxOGMsXKgwLHcLaiCKkkuVlfaWqEtuGyfSfyonpEuMAIBwbyDqoZRjEibbGbGOViFArjpyysONKmYGZAPIeixnGmIqvBPcTlaRijKEMC");

    for (int vDyGe = 887277568; vDyGe > 0; vDyGe--) {
        pNDBOjzOrTUDoXE = tQdZiLkarubuHl;
    }

    return pNDBOjzOrTUDoXE;
}

string rMcbMqhVGQAca::uubQEusy(int GQhotEU, int rYWiCZG)
{
    double XVhMElWwUSug = -36959.95647748109;
    double GgqHRcZbKHYsY = -939015.7078661476;
    double PRfBFmVXry = -935033.554653284;
    int aQjDVbe = 1555999199;
    bool MaIuuTpWojyEczi = true;

    for (int zSsowsQetiMYt = 2101234518; zSsowsQetiMYt > 0; zSsowsQetiMYt--) {
        PRfBFmVXry = GgqHRcZbKHYsY;
        rYWiCZG = rYWiCZG;
    }

    for (int zgIldrlxv = 945892608; zgIldrlxv > 0; zgIldrlxv--) {
        continue;
    }

    for (int RFXzFafMHOKl = 1738040322; RFXzFafMHOKl > 0; RFXzFafMHOKl--) {
        GQhotEU *= rYWiCZG;
    }

    if (XVhMElWwUSug > -935033.554653284) {
        for (int aZkZaMDUYBopnSB = 67803448; aZkZaMDUYBopnSB > 0; aZkZaMDUYBopnSB--) {
            continue;
        }
    }

    for (int exUrYUzdOKanqhCW = 373716630; exUrYUzdOKanqhCW > 0; exUrYUzdOKanqhCW--) {
        XVhMElWwUSug *= XVhMElWwUSug;
        GgqHRcZbKHYsY *= PRfBFmVXry;
    }

    return string("lbKpWKwmQwZeqcbFFeHhyfjZvxGWbpPZFdSkkUfCFytKjOQMTBojMMeOGKa");
}

bool rMcbMqhVGQAca::CLfVEw(string vErUjkSkIzSnTDlj)
{
    double WtYhZXbVU = 867724.4651837512;

    return true;
}

int rMcbMqhVGQAca::CowbdmErgyA(bool gAppT)
{
    double vdlIwhyro = 626190.6799506849;
    string lOrDJIiMfnmu = string("EQVsxiUtGSSpOXKYwDCbxOpKXoWbqxIuUEraBWoFyJLUCSLtrpAKFErbPFUvnRwoLEBrFHxysTUsgtfdLYEAv");
    string SfUQIgvYs = string("feFTBeDpoULrbqSigpQLudvKpHENNMLgIDOjEUysGiYGJQYMXBBjRwCQziOJdhVDFKdlksTBujuvTBzqrpCysezSVxYpbWXLYwjKUwnbZprWjtbonUmpSuCLGxpDzHAeqmPcAEbSuFLOvdzAxLeKUCqANjXHrezblLxeKTuXGSERDGOzoxGmTbSIZKQDcSJFCVIbGP");
    double ZqvXHQY = 925212.0740478889;
    double varhNjN = -369535.0695178378;
    string VudVeupfaPOiLDR = string("tfWqmsIbdNFmTcCaPxQYDPuXLOrBgazDwM");
    string gZFDrhLaO = string("PJzyNCBlpZZXcivvRDwGtPRrYRjRzWTkiMJOCaNFTzYkcsudKUjdYsPVM");
    string fvKDeHQ = string("borwCloaezKonGGQlUdnhDQBLDHkbdfiyMkvrbIvFUuQoaKJKitddGRMJZUMUnfrfrHMWAFDGDKLAxktdYgeehlqPjZAyQaVoszLuelqhNDaAftBuEuEtAMfshbevpmRDemSlSOinBDR");

    if (SfUQIgvYs >= string("feFTBeDpoULrbqSigpQLudvKpHENNMLgIDOjEUysGiYGJQYMXBBjRwCQziOJdhVDFKdlksTBujuvTBzqrpCysezSVxYpbWXLYwjKUwnbZprWjtbonUmpSuCLGxpDzHAeqmPcAEbSuFLOvdzAxLeKUCqANjXHrezblLxeKTuXGSERDGOzoxGmTbSIZKQDcSJFCVIbGP")) {
        for (int gsDbJcRGWt = 497691815; gsDbJcRGWt > 0; gsDbJcRGWt--) {
            ZqvXHQY += ZqvXHQY;
            ZqvXHQY += ZqvXHQY;
            VudVeupfaPOiLDR += VudVeupfaPOiLDR;
            SfUQIgvYs = lOrDJIiMfnmu;
        }
    }

    for (int YRmUhpvgVkyawFtw = 1001621350; YRmUhpvgVkyawFtw > 0; YRmUhpvgVkyawFtw--) {
        varhNjN *= varhNjN;
    }

    if (lOrDJIiMfnmu >= string("tfWqmsIbdNFmTcCaPxQYDPuXLOrBgazDwM")) {
        for (int sRDNgzgspmJ = 638884974; sRDNgzgspmJ > 0; sRDNgzgspmJ--) {
            VudVeupfaPOiLDR = fvKDeHQ;
        }
    }

    return 1228895875;
}

string rMcbMqhVGQAca::lJBcCUZdtIG(double ulABQOuxKzH, bool UxGmKwhhSylZbv, int mawgvjOIJMzrhA, int EkImzswRUFypvIw)
{
    bool KsjyrqKMwrwgv = false;
    int xltJhCMsZjX = -1745573533;
    bool mFvhMCD = false;

    if (EkImzswRUFypvIw == 987446373) {
        for (int iDhWhj = 704532181; iDhWhj > 0; iDhWhj--) {
            UxGmKwhhSylZbv = ! KsjyrqKMwrwgv;
        }
    }

    if (mFvhMCD == false) {
        for (int diRnb = 512350589; diRnb > 0; diRnb--) {
            continue;
        }
    }

    for (int QnWBSCyXXNqn = 1834194; QnWBSCyXXNqn > 0; QnWBSCyXXNqn--) {
        mFvhMCD = mFvhMCD;
        mawgvjOIJMzrhA = mawgvjOIJMzrhA;
        KsjyrqKMwrwgv = mFvhMCD;
        mawgvjOIJMzrhA += EkImzswRUFypvIw;
        UxGmKwhhSylZbv = KsjyrqKMwrwgv;
        KsjyrqKMwrwgv = mFvhMCD;
    }

    for (int zwayNGMgvkbBjOwp = 1053740747; zwayNGMgvkbBjOwp > 0; zwayNGMgvkbBjOwp--) {
        EkImzswRUFypvIw -= mawgvjOIJMzrhA;
    }

    for (int raGCs = 1770593274; raGCs > 0; raGCs--) {
        mFvhMCD = UxGmKwhhSylZbv;
    }

    for (int xpwAeUQ = 1535030723; xpwAeUQ > 0; xpwAeUQ--) {
        UxGmKwhhSylZbv = ! KsjyrqKMwrwgv;
        KsjyrqKMwrwgv = KsjyrqKMwrwgv;
    }

    if (EkImzswRUFypvIw >= 987446373) {
        for (int FhUmKeZMI = 1458160298; FhUmKeZMI > 0; FhUmKeZMI--) {
            xltJhCMsZjX -= mawgvjOIJMzrhA;
            KsjyrqKMwrwgv = mFvhMCD;
            mFvhMCD = KsjyrqKMwrwgv;
            KsjyrqKMwrwgv = KsjyrqKMwrwgv;
            xltJhCMsZjX *= mawgvjOIJMzrhA;
            mawgvjOIJMzrhA += mawgvjOIJMzrhA;
        }
    }

    return string("XKoYBTzBnCtNMCcOMPSEOFdtOzGYKfQjPeGCkkeKvzvwthPGPzTQRcwTkujlPvekpkZVWevvSpgoPqKxvbbEFiKES");
}

string rMcbMqhVGQAca::OyaTZYBjTDuDzv(bool NkGVtewGRicmKQc, bool IOyqwwW)
{
    bool TjQyz = false;
    int dQSQTpAeUEOnwG = 2080320621;
    int AElytqAEHCkEoW = 1797167319;
    string AKtXzn = string("EjiTvXXmpHytXBmqeozgzAuhYGapDBdulqakWrApExXLgxVVXFEcVFIXwSHPUbZwzsAnGesKRHmVVOWCMULwVUYixUtANioksJvNLNgVRXVqiVaPImZtaCbFglklGXshypQTErikIbCcTacoDEUbudDleWoaLaDrPArxNoTOtcgWGDrqdtFzccKuYHhaGove");

    if (TjQyz != false) {
        for (int NHNzBKaOQWtpL = 2100976918; NHNzBKaOQWtpL > 0; NHNzBKaOQWtpL--) {
            TjQyz = NkGVtewGRicmKQc;
            TjQyz = ! IOyqwwW;
            TjQyz = ! IOyqwwW;
        }
    }

    if (TjQyz == false) {
        for (int fGVcBAMNcr = 2088861623; fGVcBAMNcr > 0; fGVcBAMNcr--) {
            TjQyz = ! TjQyz;
            NkGVtewGRicmKQc = TjQyz;
            dQSQTpAeUEOnwG = dQSQTpAeUEOnwG;
            TjQyz = NkGVtewGRicmKQc;
        }
    }

    if (NkGVtewGRicmKQc != false) {
        for (int XXEHEBsoOQva = 2049997759; XXEHEBsoOQva > 0; XXEHEBsoOQva--) {
            NkGVtewGRicmKQc = ! IOyqwwW;
            IOyqwwW = ! IOyqwwW;
            NkGVtewGRicmKQc = TjQyz;
        }
    }

    for (int mxYPW = 297434642; mxYPW > 0; mxYPW--) {
        IOyqwwW = ! NkGVtewGRicmKQc;
    }

    return AKtXzn;
}

void rMcbMqhVGQAca::VfbVCF(string svwForZTbDna)
{
    double UUKluctUaosIM = 839358.7692345583;
    bool GjnwwhqDkxurlgF = false;

    if (GjnwwhqDkxurlgF != false) {
        for (int VzelqsZwUx = 579769519; VzelqsZwUx > 0; VzelqsZwUx--) {
            continue;
        }
    }
}

int rMcbMqhVGQAca::ndLYXYEIAsDEn()
{
    int ZHOpKmgKzl = -2139348498;
    string uruVXBydbza = string("lXJgEWvrYPkYqlvVaGpbYKVOciDmcRkHiAyhHNPwmxT");
    bool lvaEEXDlrPJaXT = true;
    double DQSzkKbG = -719972.0556798361;
    double RKxdFXfYvWaskMbJ = 490865.8993245574;
    string vDQwRqRMqMPIgp = string("fBtDucYniOwkevgqCEtdHUGzhTwbTAsWXtrFzJwaRpXFrClCVdzJoodVJWfjtYBXHNt");
    string FxTpolfKe = string("FjTzHXaQpIWvuZgAoILsQnzgXUvVDLvobpnZtxfYFdJscfQfOifAPIKwsYBrpdvurExCfuyBNmQfpBmCEetOBvoswYsuGQINUUlRsXPqUTmajJWplvbQPlEvZCHyRZbIYPAlCXtHdmCTmPoVoBRZsWoPcsyKcXdMPuNEDbigAunereTeJgdURSMucZHSTabCWdoJNUQJFBKTQSfCKmIvMsBfwgAWFVKLHwoB");
    bool SUBNx = true;
    int WDDjVhJiaLFV = -1372514405;
    bool IPiYTqhhsxSrsAOt = false;

    for (int wHIIVFGfpEfF = 334932064; wHIIVFGfpEfF > 0; wHIIVFGfpEfF--) {
        SUBNx = lvaEEXDlrPJaXT;
    }

    for (int fQoSFkFMoS = 557135028; fQoSFkFMoS > 0; fQoSFkFMoS--) {
        continue;
    }

    for (int dXgCJ = 1750261781; dXgCJ > 0; dXgCJ--) {
        lvaEEXDlrPJaXT = ! SUBNx;
    }

    for (int rxJTfSOZeM = 1736679274; rxJTfSOZeM > 0; rxJTfSOZeM--) {
        continue;
    }

    return WDDjVhJiaLFV;
}

int rMcbMqhVGQAca::gfcCYocno(bool xnpeoKy, double berFzrCBNTkU, string KyWKGVoBSOywPuTv, bool IxBJuWmbc)
{
    int zfOLPVXwTTAh = -1395236801;
    double mBIeeNA = -448520.5780732345;
    int QAHRCmIm = -1877530739;
    double qVCRJirWJBZAOdlO = -563640.7400511744;
    int NvpOpH = -349022861;
    string UUzGklUFn = string("rYpYboHYiydHnZxiUwjcsELaWcAGqWNxvKIqWaarkiZBASWnsrgLAcYnnHAXHRwlraRtnhhbBNRnGuFxBbErFENGSNFdcScjpkHudybbzFkcjJcnBzsqEdXCyXaqDtDprYJDycxfIzZuNAhGKRuFBiqcdqHkuyDlgubenNqfWomUVMUZuvovAlQAqRkgnFpwqoGsTZAxdK");
    string ZFFIztEREPnAvmOO = string("pVeaZhRXiRPXPOpJscISxzVsTYHdmkHyHTnqeomvKTikrsdrKsACqgHcRGUsvQHnnOrHlLMphIKBhNlDAXZswcYbEYpFHCKdfzwCLpFxIpiyccVdOTevcHcyRYzOCdbUcRahSZqcAAfgMLularwscwAWtpaaW");
    int vutRgrsFlqDDIz = -1062718690;
    bool PFAhuqjsqodfmhf = true;
    string RRZHMCBgssGtHaV = string("awHEyFXIOQFlcvCcIGpoojqDrzkrjEtTEuzTgSoxvNkFiJOJzkPOlbriYqeJzMBNicFaqTTPctUnZInJFNGKCF");

    for (int hFQhhuueHXzkt = 1242682091; hFQhhuueHXzkt > 0; hFQhhuueHXzkt--) {
        mBIeeNA *= mBIeeNA;
    }

    for (int AGqEecYrBWhHt = 1833677291; AGqEecYrBWhHt > 0; AGqEecYrBWhHt--) {
        IxBJuWmbc = xnpeoKy;
        mBIeeNA /= qVCRJirWJBZAOdlO;
        NvpOpH *= NvpOpH;
    }

    for (int uGAaNTWkuzPQHQzQ = 2109671346; uGAaNTWkuzPQHQzQ > 0; uGAaNTWkuzPQHQzQ--) {
        IxBJuWmbc = xnpeoKy;
    }

    return vutRgrsFlqDDIz;
}

double rMcbMqhVGQAca::ZFrJMWPe(double GWhHRgFJcfjuf, double IVOXivWCVJADNW, string thencVFRteoMqc, bool aYcRcQtZPAO, bool SrZbMOnrjgIm)
{
    bool QETCJIVhhIO = false;
    int oncbAPxL = -164146600;
    string IMeVTMuOZkAUk = string("xLtzNiWPQCkdZURrAJBoZPoadLqYuGFGcannVoauQmuIZWAYimJNENCeuDrDDyXNqgjXEgmcByKNDawYFcOCIzJmPcDTJOVcsvpZyWptCHLvVYzGIlAKSNjfwzoSzeCLbnyRxxCdKkrlmdATlOqnXkxfoQyuOVHSMVlDgBHmSbOdHBgIFrpvzxAJyjThyrRhDMjEKXDyXomOIYBGnHCrcpHfOgWwKUxzSMAYtPutnT");

    for (int DAzqX = 1712607187; DAzqX > 0; DAzqX--) {
        aYcRcQtZPAO = ! aYcRcQtZPAO;
        GWhHRgFJcfjuf += IVOXivWCVJADNW;
    }

    if (aYcRcQtZPAO == true) {
        for (int fypLvnyWzUe = 2088261963; fypLvnyWzUe > 0; fypLvnyWzUe--) {
            GWhHRgFJcfjuf += IVOXivWCVJADNW;
            QETCJIVhhIO = QETCJIVhhIO;
        }
    }

    for (int BavbiCKOnY = 1172905170; BavbiCKOnY > 0; BavbiCKOnY--) {
        QETCJIVhhIO = QETCJIVhhIO;
        aYcRcQtZPAO = ! QETCJIVhhIO;
    }

    return IVOXivWCVJADNW;
}

void rMcbMqhVGQAca::DFcNSqaBYQmtqdVv(string BNsMGsFHEhBERiV, bool kfRSIKsqvDHzNM, bool wlLVOyLlsAZiwR)
{
    int MpLzbJADqKxL = -981813780;
    string bnxFbEWtKkGqOx = string("hlOvMMfvemtZhZOmCxHRSpwoFUXgJoRsxOiBAjdRNyDbtvJOFWJzvBpvUfFrNIMXekCErrughEWZyLSZbMzFwTEKqUSUTxUFGORFPTARjGRylIFzabrhHIdRpc");
    bool bnFhSRIpxeOKZwc = false;
    string TNJpJejjlOXMMtG = string("nHWjTzBdqIfmZHqxrRwrFhJTejHeVkVDzfNyfJGtUDeBucDizFWbQBBSVcbfDDpmkXCqxDkVJPUjCXjEXlGlZAlAltqHoxphsblwXcUZJOoyvpNLZGycToVpyEgjphqEwIeSgyyzJIxhXpDwEwvYXmsRAFpGUdBLAREprBAdAguTCHfnhPEcdrGGHjjUkbZZmMrAkCUyRnmVseecqnXQMhCvTlXfGVNLUYzJnliHgDYmPywDrzckZ");
    double YxyjagBdtW = 805220.2814693147;
    bool TfmaeQIyqjypFr = false;
    string hchyRl = string("aZdqOMInpnUkRkfZCwdgzgPTlQQbBKMPhoIqOwERlXomBxtvSuldWewWiitovhYVIEnmCzdksCBvofvQGYgRSIKhdqJcPoLrjFEmeAyKMezScmyfNtncjQmQBOBdZDoNZEOaUuXwRrwUFropeADwwLFGvSqKTfmLIzZSkiebUGQpLJsBxTXTqIhuKXDDDqcWfPQeRSLRvLKCLpnuBzistgBYFxvGjltuCPCKLhatlGEGTc");

    if (hchyRl < string("aZdqOMInpnUkRkfZCwdgzgPTlQQbBKMPhoIqOwERlXomBxtvSuldWewWiitovhYVIEnmCzdksCBvofvQGYgRSIKhdqJcPoLrjFEmeAyKMezScmyfNtncjQmQBOBdZDoNZEOaUuXwRrwUFropeADwwLFGvSqKTfmLIzZSkiebUGQpLJsBxTXTqIhuKXDDDqcWfPQeRSLRvLKCLpnuBzistgBYFxvGjltuCPCKLhatlGEGTc")) {
        for (int XZWTaU = 901206067; XZWTaU > 0; XZWTaU--) {
            TfmaeQIyqjypFr = TfmaeQIyqjypFr;
            kfRSIKsqvDHzNM = ! bnFhSRIpxeOKZwc;
            BNsMGsFHEhBERiV += TNJpJejjlOXMMtG;
            hchyRl += BNsMGsFHEhBERiV;
        }
    }

    for (int FBVHxmjgoKtV = 1363505741; FBVHxmjgoKtV > 0; FBVHxmjgoKtV--) {
        TfmaeQIyqjypFr = ! wlLVOyLlsAZiwR;
        bnFhSRIpxeOKZwc = ! bnFhSRIpxeOKZwc;
        bnFhSRIpxeOKZwc = ! TfmaeQIyqjypFr;
    }

    for (int TRfrxtEcKCSSTy = 2010843983; TRfrxtEcKCSSTy > 0; TRfrxtEcKCSSTy--) {
        continue;
    }
}

string rMcbMqhVGQAca::uKJuip(int ouhyDa)
{
    string eKdsmvF = string("plNivDOYyzzzDTlXGGxEGwyjCsQbRqKwYLyDSGzhghL");
    string zVQwcvhqIxhCh = string("ilIuUDMFlHuFYWTARvafqTamLJsjLqqeiCmGHxYadHofUJvqhgWlirArvTafhfCbEQCwWVvmDvpuKzhpqtpDCFlPyyxRDufnoFreIcJJxXuv");
    double uDUUdv = -301316.9502159328;
    string wDnbxazun = string("UiSaMKqPKenKDvEWNEEGJVshpwTWPHIfHUEsgaHFNUw");
    bool BgDzwDGRRvh = false;
    double wRqxPgiPlLvncUX = 907519.266128236;
    int tlruTUZ = 1658975577;
    double DtOxFuMpJPUsBN = -89916.91590371174;
    string yOXixalHUVqO = string("uvZrPGpJrVnjzFiWxVgwioCSVZsgKFtNdmJigwiHMgCOiuLoNikxBhNr");

    if (ouhyDa >= 1658975577) {
        for (int fKJEk = 180374013; fKJEk > 0; fKJEk--) {
            wRqxPgiPlLvncUX = uDUUdv;
            ouhyDa -= ouhyDa;
        }
    }

    if (DtOxFuMpJPUsBN == -301316.9502159328) {
        for (int WayANqXPhldD = 224374347; WayANqXPhldD > 0; WayANqXPhldD--) {
            zVQwcvhqIxhCh = yOXixalHUVqO;
            DtOxFuMpJPUsBN = DtOxFuMpJPUsBN;
            yOXixalHUVqO = yOXixalHUVqO;
            yOXixalHUVqO = yOXixalHUVqO;
        }
    }

    if (eKdsmvF >= string("uvZrPGpJrVnjzFiWxVgwioCSVZsgKFtNdmJigwiHMgCOiuLoNikxBhNr")) {
        for (int xbJHh = 148248004; xbJHh > 0; xbJHh--) {
            BgDzwDGRRvh = ! BgDzwDGRRvh;
        }
    }

    return yOXixalHUVqO;
}

string rMcbMqhVGQAca::ZVYlDzmhi(double nfWKDw, bool pmFRzoA, int ynGejzeCLcNVS)
{
    bool sRghHRTTRMIpSr = true;
    double hkFuxPWiKkNOKc = -104308.45611358463;
    double DlTAuUPLzax = -398724.74770914024;
    int cDlhC = 503796499;
    bool BpaMTgl = false;
    string xAIyF = string("sQuFdSUehApnpunYcgOxKSdNbnEPskGWbmqChBcBRzXOoGZJswarqLicFKDGkkEybTNKIcoBWiyFZnokeXSHkjBiwxNeTiUAZlSEmMVsMLlMDpyRyNPbgJkkbqHDTUOiOgIkOlHywqQTQyOLRxlcCFutSGdSqVNAWsHJDCOsSSEAfS");
    string cXxlF = string("KyijrqfJBAfWWIaeBfcnXxbDgDeEFyhEWMewfbPxsGdsEUgVuYJZrqaxvpeWkFoQZrsvKyppkiPRnwJUDDdRRnlsJXTCyBpVSWNVGnmyvbkKHkASSnvIlCkKS");
    int bZwgJRY = 763644353;

    for (int RdVYQKO = 269843187; RdVYQKO > 0; RdVYQKO--) {
        xAIyF += cXxlF;
    }

    if (cXxlF > string("KyijrqfJBAfWWIaeBfcnXxbDgDeEFyhEWMewfbPxsGdsEUgVuYJZrqaxvpeWkFoQZrsvKyppkiPRnwJUDDdRRnlsJXTCyBpVSWNVGnmyvbkKHkASSnvIlCkKS")) {
        for (int HDFjjvOGqnlY = 1630322067; HDFjjvOGqnlY > 0; HDFjjvOGqnlY--) {
            nfWKDw += nfWKDw;
            cXxlF += xAIyF;
        }
    }

    if (cXxlF >= string("KyijrqfJBAfWWIaeBfcnXxbDgDeEFyhEWMewfbPxsGdsEUgVuYJZrqaxvpeWkFoQZrsvKyppkiPRnwJUDDdRRnlsJXTCyBpVSWNVGnmyvbkKHkASSnvIlCkKS")) {
        for (int nOvGBbldGFkHQ = 501415527; nOvGBbldGFkHQ > 0; nOvGBbldGFkHQ--) {
            ynGejzeCLcNVS += cDlhC;
        }
    }

    return cXxlF;
}

bool rMcbMqhVGQAca::cGkzLBMjER(int STtlpGTaIJx, int eGgVjn)
{
    string BCFANdZChQ = string("NJsiCdpAKsZHQJVmLhgdxLqifEjyebIGJJCYOPOrJoeBCeQRyJjdHDwcchsnqURdauvvaNDXvZMZCepnhFYoizDeYnvfSFxjLxVNeMsAWSpfczdeIVoLFhdnKswWQPaTtpTnUzEbZTgBtSSlhRJDoZEiLDwIUnieSytNuoMdjrZCwSKdnFs");
    string dlmbQPZPotf = string("mIiRbDhSYtLzqnBNGCrgLVTgOLUoTRAiyTQlKSgcnGBGZcIxyIYCIDhdcEhjdnfbmawDPNDtdqSlEjlUnhfIlqOWCNqWOJYHfrJFRGOCIyJdlplhwfnoqtVhm");
    int GcKemoqXsm = 2060978209;
    string TTgyLAGoTRZZbW = string("zYXnhWTPoGBfnAUuseySMEtzFAzXRpAirrOhfkXJBhrUBhXxBMOJRDshITOQNBPPwXttyHCXXVRGbXwqSSvWlifmjXnynLuFiJypFDcPhedOWYtkdsgqqMdsuqETlXNXXPbyHZDplTWipcsWFRyHkfOgSJgthdVRIzYJMdDsFmvCySIgRAaYGrmZAZoyOX");
    double nUmLEjwcqnC = -237172.46712021163;
    bool VraLvspb = true;
    double qapjfHMRwxH = 316238.68831873103;
    string erYLIx = string("UyYgBAyiYsGqYwvBUtksjUTjnoSHClpYFxiwetQzHliwHdmpEfJivXrdCRhHialHVlxxbzRNdBbuJcxEUbMUMRGwlJIGjvcwPgTkZnwuJIQeIFGVjokwSMBomXVfeRfmwVkIXhBrktdOYffl");

    for (int nhcoH = 679439539; nhcoH > 0; nhcoH--) {
        BCFANdZChQ = BCFANdZChQ;
        TTgyLAGoTRZZbW = dlmbQPZPotf;
    }

    return VraLvspb;
}

int rMcbMqhVGQAca::eZACPUQCAXEn()
{
    int EqJXnC = 1463862033;
    bool lGddmyFYJQwb = true;
    bool prOvVHq = true;
    double qZjdbxvcomtMlu = -215905.38345246966;
    bool ZdOrFUxFi = true;

    if (ZdOrFUxFi != true) {
        for (int SNMnoJ = 1391682803; SNMnoJ > 0; SNMnoJ--) {
            qZjdbxvcomtMlu = qZjdbxvcomtMlu;
            prOvVHq = prOvVHq;
            lGddmyFYJQwb = ! prOvVHq;
        }
    }

    for (int rumJqnT = 327797950; rumJqnT > 0; rumJqnT--) {
        lGddmyFYJQwb = prOvVHq;
        prOvVHq = ZdOrFUxFi;
        qZjdbxvcomtMlu += qZjdbxvcomtMlu;
        lGddmyFYJQwb = ! lGddmyFYJQwb;
    }

    if (qZjdbxvcomtMlu < -215905.38345246966) {
        for (int RPkTssIZWULggWVX = 1973657732; RPkTssIZWULggWVX > 0; RPkTssIZWULggWVX--) {
            lGddmyFYJQwb = prOvVHq;
            lGddmyFYJQwb = lGddmyFYJQwb;
        }
    }

    if (EqJXnC == 1463862033) {
        for (int rismkmdGZyl = 309112032; rismkmdGZyl > 0; rismkmdGZyl--) {
            prOvVHq = ! ZdOrFUxFi;
            qZjdbxvcomtMlu *= qZjdbxvcomtMlu;
        }
    }

    for (int jMHNebu = 457558031; jMHNebu > 0; jMHNebu--) {
        ZdOrFUxFi = ! ZdOrFUxFi;
        prOvVHq = lGddmyFYJQwb;
        ZdOrFUxFi = prOvVHq;
    }

    for (int hQCCvKjjEcoJFC = 1403235338; hQCCvKjjEcoJFC > 0; hQCCvKjjEcoJFC--) {
        prOvVHq = ! prOvVHq;
        prOvVHq = ! prOvVHq;
        ZdOrFUxFi = ! ZdOrFUxFi;
    }

    return EqJXnC;
}

double rMcbMqhVGQAca::yAieRieTdar()
{
    bool uShXrB = true;
    double NLAOhMpSef = 497815.0972130906;
    bool QaYEKo = true;
    bool KsIydOGgpIUaWY = false;
    string jNPAfFxSQG = string("fmAcUlfJYiOepIncoqfiqlLQ");
    double lQAXEz = 589102.5979632601;
    double iYZZoVEBysXH = -348244.3141832858;
    bool FGSbdBNUy = true;

    for (int HsuPLHBnytXEsHX = 1733370742; HsuPLHBnytXEsHX > 0; HsuPLHBnytXEsHX--) {
        QaYEKo = ! uShXrB;
        KsIydOGgpIUaWY = FGSbdBNUy;
        QaYEKo = ! uShXrB;
        KsIydOGgpIUaWY = ! QaYEKo;
    }

    if (NLAOhMpSef < -348244.3141832858) {
        for (int EsfesWMvfTSJrZi = 569474541; EsfesWMvfTSJrZi > 0; EsfesWMvfTSJrZi--) {
            continue;
        }
    }

    return iYZZoVEBysXH;
}

double rMcbMqhVGQAca::GSmNcxWJHPQce(string UwfzIkC, int oUluJEV, bool gVjaRXBSCKJxX, double IuGWTqMVRmImV)
{
    int vYvciYkEOjjr = -1424635452;
    int soJEosjWvMxFG = 482688949;
    double ihgLkQWa = -146749.38189688404;
    bool ydsfJCjTBYzHpj = true;
    double hlcYV = 619267.1107395719;
    double NSqAsyxTNzspqVi = -987661.8723585318;
    bool xkKDvttCeKxtn = true;
    string XFrCOZ = string("AWgQZxsoMfgytaufNcrsDoLCOxbLASmYKJmtVzeeGRnJFhNGbrsjGOTWCZsTcKGlcgFdNuGwoZoNqLOhyTvOWZPwlMolbFBSOanJYuTHewZrZPFqoAfgihLOEbziBXWsYnmqrH");

    for (int oCASxdnWNpRBSH = 1271249698; oCASxdnWNpRBSH > 0; oCASxdnWNpRBSH--) {
        IuGWTqMVRmImV -= hlcYV;
    }

    if (XFrCOZ == string("AWgQZxsoMfgytaufNcrsDoLCOxbLASmYKJmtVzeeGRnJFhNGbrsjGOTWCZsTcKGlcgFdNuGwoZoNqLOhyTvOWZPwlMolbFBSOanJYuTHewZrZPFqoAfgihLOEbziBXWsYnmqrH")) {
        for (int sqFnOCUrWYzY = 840415327; sqFnOCUrWYzY > 0; sqFnOCUrWYzY--) {
            ydsfJCjTBYzHpj = xkKDvttCeKxtn;
            soJEosjWvMxFG = soJEosjWvMxFG;
        }
    }

    for (int QEZAECuSDUU = 1187728472; QEZAECuSDUU > 0; QEZAECuSDUU--) {
        continue;
    }

    for (int gNXWGxdj = 1150275328; gNXWGxdj > 0; gNXWGxdj--) {
        ihgLkQWa *= IuGWTqMVRmImV;
    }

    for (int ffuPNwpVtkyyI = 2065258988; ffuPNwpVtkyyI > 0; ffuPNwpVtkyyI--) {
        IuGWTqMVRmImV = hlcYV;
    }

    for (int alIobTP = 461189413; alIobTP > 0; alIobTP--) {
        vYvciYkEOjjr /= vYvciYkEOjjr;
        UwfzIkC += UwfzIkC;
    }

    return NSqAsyxTNzspqVi;
}

rMcbMqhVGQAca::rMcbMqhVGQAca()
{
    this->epYPTUgwUJrP(string("LBoDdRmRdTxyMbIBBIedHegsHqmxLWgKOlxdHddXFfmofWHJqPgzUztohTdjtCKclvEodZvnhrHBNUZoqsSlyFojCwvDJmOPviJlJIhIVPGpMmJ"), string("OxTkrnIWiStTXTNVVhmfkVTxseUrDCezJOaMiBPJYfzZWFLjroemLnKffkIjZTOZBsooERWCWISRFmZXURJVfesFCxDuwTykHtgMePuBdlTtesojvOPFeMkueRCJTyGCwDsrQNeuQCGFZQyKeTb"));
    this->jNYPISGY(string("WliaGUVAEijHYPuYRWQrVoJOWhGQwhvhPLbHdhGBvSOaHnumGdXDouTDODhocVBYYRRdPsINJqgDGFKXjcRuTgOOhIgizNUKUdOMMQuvCclfzvBhWMIcXbLkXqJRZzzrziGgtuQSdfacQjRXzWJRAjPBAwTAWEiKWuPZpgGnMFiQDvNahVETHrnUahfagsvhZXpZldkLqULaCRBiVF"));
    this->bSBSwPROTKGWr();
    this->uubQEusy(-1161291484, 222627756);
    this->CLfVEw(string("PBfGyRUgwdDhdlPQrqspkFkRhSdRcfFeTSJpkNFGcZxRCFANIPppbsKrQBPyLXRPLaYEQfwFMelEHqHAxwUVgjOlpnpDPPvHpCciSTfIJYUAbdiooSerCVXnAPzDeUvKcqkVCGDCxVRVTweVrreXxCxdabIFdoFDcHFMHLgIuRBLpJRmppuRvvgNnmeXtMeRaCRlrzQKqZLJPejMQDXPULRwqtewJfafbNGldh"));
    this->CowbdmErgyA(true);
    this->lJBcCUZdtIG(780855.3796631112, false, 987446373, -1251182712);
    this->OyaTZYBjTDuDzv(false, false);
    this->VfbVCF(string("DxfUosHymaqIgPmEkMMOtFcMCscT"));
    this->ndLYXYEIAsDEn();
    this->gfcCYocno(false, 423425.5286392732, string("pnzLQegjfPhBmouHDNOxdSYGyILHdIKkXQxqRQeyxyMYsBHbHRSffIFvdBKsNOCnyJHAheWdzyk"), false);
    this->ZFrJMWPe(556141.1186867345, 189213.84438055384, string("EhYnQcVurevzcyoceVuSiBgymFjTOAgCoNKvROidxCorOWwDrHTLZxzlllkovIVOefaIegdXalcUsCVZCsTMXqcPXauBdWKBuqgVLHJQgKmzVpTJenFIhpGcgqrsXigWFRFlcZgbwrxejEcyGRlvteFEreyMgdpcPxmaVogPEhDWCWHYYpZcsWvtzpJfGKSYGfF"), false, true);
    this->DFcNSqaBYQmtqdVv(string("DAvyNcAkTJXqHdzHZTjKNcOQNLvZmzdePwFooVTPIdvcNcSnaHhKBEURolptafuXfRtsCHERwSEMaGTzSelEQVCTBiOGyVSkqyWsESnwxFcjEKzZWiNXAkdfHjbXlMDJXvGoKjrIBGqYTjbxjoyVQtPWHd"), false, false);
    this->uKJuip(175023513);
    this->ZVYlDzmhi(-1987.0981551960226, false, -1311487134);
    this->cGkzLBMjER(-2073210138, -1894713407);
    this->eZACPUQCAXEn();
    this->yAieRieTdar();
    this->GSmNcxWJHPQce(string("GySuaDyoRGtpPYIxlPGSjkLyF"), -2083247652, true, 975845.5681731295);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QaqTZyKTFKEl
{
public:
    int rkfEplTZSNoFz;
    string UXPUoNu;
    string emckTpGKkGmLPQXc;
    bool SCCGRNeFESQHVyyT;
    string nYKjm;
    int UqlDAZGv;

    QaqTZyKTFKEl();
    double cMksglAWO(string EfbDjZ, string xiBEznvjtqsWlpM);
    bool bXaxYPuUr(bool gbDfjaKnMSivr, bool JJeiD, bool koNUkEo);
    int nraGaYxOwv(double oCsQa, double KWtUmC, bool RnAObKyQ, double AdYWwMtqSjmmIUH);
    bool ioZJfdt(int ALcZY);
    void gcgkCx(string xrxewHu, bool WvXtTTBEVYc, double YHTzGTaq);
    int OPaiaHYDeJZnJik(string WWJhlAlfWrBQYP, int zrUxznK, int AjFDWZOSDoQS);
protected:
    int mRQihQNMikAQaOQS;
    double jcXkaWAHFbVyODIh;

    void oTPhTmSjhT(string GUUQGCef, string wNmjSXQSdNsD, string daBeuqVbMEEv, bool bTzzcoNXgGV);
    void bDDSDTA();
private:
    bool HQRzNjdqzanlMJ;
    string wdowfvHBND;
    int bRctVWN;
    int TLkWXjMb;
    int CVlNhs;

    int IKLcgEgJNSkkSnyU(int JXFXkFAmrxcholP, double jAzepRUJnxJlEQ, string JGmdZcOiXIzE);
    string lwMwjMMM(bool QGSmBBe, int BmvDOCJeahM, int XkBhDOypGMTYkPH, int KSZhYPzD, string yctPcYkLvEjYoc);
    bool OezWJ(string rWKyzHUW, bool akIlVNyYGZ);
};

double QaqTZyKTFKEl::cMksglAWO(string EfbDjZ, string xiBEznvjtqsWlpM)
{
    string PcAIPeNF = string("kbQYESVuRxrcYWDDBUxkUZgESOfmqPASMHbfBpSIuLEbzMlXFpFwwnKpkhntSPlIaxskaasYvVpwsqwtTOjBAuDDAIdzleuaKnpwVAkLqevXOuFTlHJWEOZkqLUItguVpSDMseGotpzIIrjwqGbRtwEQyBFBaugROVwNvtfeDNeWGcRkRsqzfHRtVnftbunJZw");
    string duhbwqp = string("JeRcoMgStVvuckXeUeDooqPlfARLRwSKkVfORjjuGgUkBbomFHhBBakkxYUQkdSBaiKbHEWpcSHDTirEPBTMwwhUYTJbHThqhNkiboGsyMqMtKCpvZvWNemhzalvBnUQiXaICLRQuFEDgRKglSYKNVIrEHDPqEcPWATQHgSxiUDaTLfHAISZgGAhyKSCckRtmMxAHxiekPXtQANoiB");

    if (duhbwqp >= string("kbQYESVuRxrcYWDDBUxkUZgESOfmqPASMHbfBpSIuLEbzMlXFpFwwnKpkhntSPlIaxskaasYvVpwsqwtTOjBAuDDAIdzleuaKnpwVAkLqevXOuFTlHJWEOZkqLUItguVpSDMseGotpzIIrjwqGbRtwEQyBFBaugROVwNvtfeDNeWGcRkRsqzfHRtVnftbunJZw")) {
        for (int TIvYZJKawuVUBI = 756109153; TIvYZJKawuVUBI > 0; TIvYZJKawuVUBI--) {
            EfbDjZ += PcAIPeNF;
            duhbwqp = EfbDjZ;
            duhbwqp += PcAIPeNF;
            xiBEznvjtqsWlpM += EfbDjZ;
            EfbDjZ = PcAIPeNF;
            PcAIPeNF += EfbDjZ;
            PcAIPeNF = duhbwqp;
        }
    }

    if (PcAIPeNF < string("kbQYESVuRxrcYWDDBUxkUZgESOfmqPASMHbfBpSIuLEbzMlXFpFwwnKpkhntSPlIaxskaasYvVpwsqwtTOjBAuDDAIdzleuaKnpwVAkLqevXOuFTlHJWEOZkqLUItguVpSDMseGotpzIIrjwqGbRtwEQyBFBaugROVwNvtfeDNeWGcRkRsqzfHRtVnftbunJZw")) {
        for (int xcEInAKsv = 1694511148; xcEInAKsv > 0; xcEInAKsv--) {
            EfbDjZ += EfbDjZ;
            EfbDjZ += duhbwqp;
            EfbDjZ += EfbDjZ;
            xiBEznvjtqsWlpM = duhbwqp;
            PcAIPeNF += PcAIPeNF;
            duhbwqp = PcAIPeNF;
            xiBEznvjtqsWlpM = xiBEznvjtqsWlpM;
            PcAIPeNF = PcAIPeNF;
        }
    }

    if (duhbwqp > string("xvaJBdSxjrAkJIeDeOStxLRbjklyWfIjNcUUYyCiFwuelYaQonexiublYLXgIuyBlXhWGuySkfgupqevtTvnsUMXQFvXvFeGRyFUlrehajpOhgcitDfGuOmwQdMojgmxdLwflqtLsaMOEMMeNvZmhpvPPqiJdRdgFYNsHBfgIdQwVP")) {
        for (int BhsoXIfjnChOJGc = 720522834; BhsoXIfjnChOJGc > 0; BhsoXIfjnChOJGc--) {
            duhbwqp = EfbDjZ;
            duhbwqp += xiBEznvjtqsWlpM;
            duhbwqp = xiBEznvjtqsWlpM;
            duhbwqp += PcAIPeNF;
            duhbwqp = PcAIPeNF;
            duhbwqp += duhbwqp;
            duhbwqp += xiBEznvjtqsWlpM;
            EfbDjZ = xiBEznvjtqsWlpM;
            xiBEznvjtqsWlpM += EfbDjZ;
            PcAIPeNF += duhbwqp;
        }
    }

    return 1046486.9868683623;
}

bool QaqTZyKTFKEl::bXaxYPuUr(bool gbDfjaKnMSivr, bool JJeiD, bool koNUkEo)
{
    bool JbIcZMDXwLJ = false;
    bool OegHPAwGz = false;
    int rbzlboWAiDI = -250913193;
    double DSfVJSQtjK = -264572.69991283125;
    bool TtRRdeQUKBsR = false;
    string bTrDp = string("eigzIfCGrNYyQjxzkPiPuEfXCBZvXiIxULrslgRwVBUaFGigBXPgkNpIONbKk");
    bool KFkMELcwZJJpM = false;
    string DbllW = string("ATPaPAJXIRmgfqIxzvPPHXDsgwqRRqSDxfqOMzUrDogrFOHprFJCNjtyQmHMFzDGdEXotStvadEdigARtURUDjAXFmmMtVMkz");

    if (KFkMELcwZJJpM == false) {
        for (int mvhmJBYERaEyGhi = 216351630; mvhmJBYERaEyGhi > 0; mvhmJBYERaEyGhi--) {
            OegHPAwGz = ! KFkMELcwZJJpM;
            TtRRdeQUKBsR = koNUkEo;
        }
    }

    return KFkMELcwZJJpM;
}

int QaqTZyKTFKEl::nraGaYxOwv(double oCsQa, double KWtUmC, bool RnAObKyQ, double AdYWwMtqSjmmIUH)
{
    bool EFVxFvfz = true;
    string dXWzd = string("BdMOnvyawdZMKSrnMBYzsxnGfDAitZyhmSdHYJAMJEPLjFjciPmDHtZgXjKiIMnzUuQVBGGpJBACPKhpgWStQkRAGMpKXTMAILcamwjdIgbmQzilgMieLyDDeaYshLmLpCvWHmhoOJxPeGYcXeVTPCXQfFgBJRosQbWVHgjchlTS");
    int YqnyMJ = -1063495911;
    double IrsVZtjx = 666463.8473378192;

    for (int KNEHXFWdRMgz = 499867730; KNEHXFWdRMgz > 0; KNEHXFWdRMgz--) {
        oCsQa += AdYWwMtqSjmmIUH;
    }

    for (int dkBelyeiRq = 641196641; dkBelyeiRq > 0; dkBelyeiRq--) {
        IrsVZtjx = IrsVZtjx;
        KWtUmC = IrsVZtjx;
        KWtUmC *= oCsQa;
        oCsQa -= KWtUmC;
        IrsVZtjx -= KWtUmC;
        KWtUmC = KWtUmC;
    }

    for (int cgDvDVWCWYqu = 1569299939; cgDvDVWCWYqu > 0; cgDvDVWCWYqu--) {
        continue;
    }

    for (int wWSDEXIoZnse = 1965160110; wWSDEXIoZnse > 0; wWSDEXIoZnse--) {
        dXWzd = dXWzd;
        AdYWwMtqSjmmIUH *= oCsQa;
    }

    if (KWtUmC == -894838.2580190717) {
        for (int FDgseuMXExiKGGMq = 1943820336; FDgseuMXExiKGGMq > 0; FDgseuMXExiKGGMq--) {
            continue;
        }
    }

    for (int PVxYtLicLRxSngI = 951313229; PVxYtLicLRxSngI > 0; PVxYtLicLRxSngI--) {
        KWtUmC = oCsQa;
        oCsQa *= AdYWwMtqSjmmIUH;
        oCsQa /= IrsVZtjx;
    }

    return YqnyMJ;
}

bool QaqTZyKTFKEl::ioZJfdt(int ALcZY)
{
    int nutYSCxPvHlCk = 22669326;
    int EpCOzlxJxFGlfNl = -1134623229;
    double rbrKxmE = 846032.9195351437;

    if (EpCOzlxJxFGlfNl >= -1134623229) {
        for (int UrAKfIjMxj = 253094612; UrAKfIjMxj > 0; UrAKfIjMxj--) {
            nutYSCxPvHlCk = nutYSCxPvHlCk;
        }
    }

    for (int CKwvf = 1465965604; CKwvf > 0; CKwvf--) {
        ALcZY += EpCOzlxJxFGlfNl;
    }

    if (ALcZY > -1373602153) {
        for (int fhJvWiwjzYCXWTRq = 295240254; fhJvWiwjzYCXWTRq > 0; fhJvWiwjzYCXWTRq--) {
            EpCOzlxJxFGlfNl += EpCOzlxJxFGlfNl;
            nutYSCxPvHlCk /= ALcZY;
            ALcZY -= ALcZY;
            nutYSCxPvHlCk /= ALcZY;
            EpCOzlxJxFGlfNl /= EpCOzlxJxFGlfNl;
            nutYSCxPvHlCk = EpCOzlxJxFGlfNl;
        }
    }

    if (EpCOzlxJxFGlfNl > 22669326) {
        for (int bfzwwzM = 1791441696; bfzwwzM > 0; bfzwwzM--) {
            rbrKxmE = rbrKxmE;
        }
    }

    if (EpCOzlxJxFGlfNl > -1134623229) {
        for (int yPKjvSLLoZHaF = 717034743; yPKjvSLLoZHaF > 0; yPKjvSLLoZHaF--) {
            continue;
        }
    }

    return true;
}

void QaqTZyKTFKEl::gcgkCx(string xrxewHu, bool WvXtTTBEVYc, double YHTzGTaq)
{
    int gqTFnJqXMdguy = 1925582931;
    int AswVvL = -2023883280;
    string uwKmFKFLhfWhAOC = string("SXprqWStWdWhmhMounVVgmJONdgPeUwsiVOsbTplCNWfoWGKKzvOTJsalUiVmjOvmgUyoDOCNblcgYxnIvuethzYtSMMZXjrSmwVnGPJMUvdYeHYYYaDWbXmfmlJCpuVYx");

    if (AswVvL > 1925582931) {
        for (int mDkxBvb = 308804519; mDkxBvb > 0; mDkxBvb--) {
            gqTFnJqXMdguy -= gqTFnJqXMdguy;
        }
    }
}

int QaqTZyKTFKEl::OPaiaHYDeJZnJik(string WWJhlAlfWrBQYP, int zrUxznK, int AjFDWZOSDoQS)
{
    bool vRdsRoLn = true;
    bool FkrZWCfeQ = false;

    if (AjFDWZOSDoQS == 1496052219) {
        for (int zOHgwsHNrUTOH = 1515426344; zOHgwsHNrUTOH > 0; zOHgwsHNrUTOH--) {
            AjFDWZOSDoQS = AjFDWZOSDoQS;
            FkrZWCfeQ = ! FkrZWCfeQ;
            vRdsRoLn = FkrZWCfeQ;
        }
    }

    if (zrUxznK <= 1496052219) {
        for (int SJTjNXaKJSKqRN = 1151241858; SJTjNXaKJSKqRN > 0; SJTjNXaKJSKqRN--) {
            AjFDWZOSDoQS *= zrUxznK;
            WWJhlAlfWrBQYP = WWJhlAlfWrBQYP;
        }
    }

    return AjFDWZOSDoQS;
}

void QaqTZyKTFKEl::oTPhTmSjhT(string GUUQGCef, string wNmjSXQSdNsD, string daBeuqVbMEEv, bool bTzzcoNXgGV)
{
    double zXNZSqaawdW = 918738.3833054601;
    double KSBSSQFVFap = -211029.0661501838;
    double naqXKlVllThQDJ = -794074.4814401597;
    bool waihPXhwhU = false;
    string RIhZtoZBsXH = string("CGQvBmyJuLhpFwXfKSpXGFmEzmxapg");
    string jyKihBpIrYR = string("ALSkIQWTICcBVsRhGtNpenMdoFuLPZPmpsDvVKiqixWmikeTvIvsPKBiRTcVmjcPwOoPsnbdxGOkIGzwxsamcGDeiYuCXyPsRiAzNfGUFnpwQLMhmBaknDMzRnEzfgyDzQKkOJjvEqkjNkYIGoitxYBSCxJUxnphjxGzlcCUubVApctHpLTjEaFznsxeeILsNqfMdtuemKMuxXQoHSKkwLrOYX");

    for (int XhFdAggoMkTSX = 918531604; XhFdAggoMkTSX > 0; XhFdAggoMkTSX--) {
        continue;
    }

    for (int vZGwdbQspspe = 2122908447; vZGwdbQspspe > 0; vZGwdbQspspe--) {
        wNmjSXQSdNsD = GUUQGCef;
        daBeuqVbMEEv += GUUQGCef;
        daBeuqVbMEEv = GUUQGCef;
    }

    for (int oubtXNkLWmr = 531770877; oubtXNkLWmr > 0; oubtXNkLWmr--) {
        jyKihBpIrYR = RIhZtoZBsXH;
    }

    for (int ZNSyESRNT = 187269732; ZNSyESRNT > 0; ZNSyESRNT--) {
        KSBSSQFVFap -= zXNZSqaawdW;
    }

    if (wNmjSXQSdNsD >= string("ALSkIQWTICcBVsRhGtNpenMdoFuLPZPmpsDvVKiqixWmikeTvIvsPKBiRTcVmjcPwOoPsnbdxGOkIGzwxsamcGDeiYuCXyPsRiAzNfGUFnpwQLMhmBaknDMzRnEzfgyDzQKkOJjvEqkjNkYIGoitxYBSCxJUxnphjxGzlcCUubVApctHpLTjEaFznsxeeILsNqfMdtuemKMuxXQoHSKkwLrOYX")) {
        for (int IeCqYot = 920692517; IeCqYot > 0; IeCqYot--) {
            jyKihBpIrYR += RIhZtoZBsXH;
        }
    }
}

void QaqTZyKTFKEl::bDDSDTA()
{
    int DPDRJV = 122796214;
    double djjJPx = 20449.99358722235;
    int PmrXGvLrnO = -94040494;
    int vzLPMGhcNgfJLIyG = -736744664;
    bool UjVPre = false;

    for (int spytRCWPO = 1305113553; spytRCWPO > 0; spytRCWPO--) {
        DPDRJV = vzLPMGhcNgfJLIyG;
        djjJPx *= djjJPx;
        UjVPre = UjVPre;
    }

    for (int alYXhXTwKWGbZ = 1433918739; alYXhXTwKWGbZ > 0; alYXhXTwKWGbZ--) {
        UjVPre = ! UjVPre;
        PmrXGvLrnO /= vzLPMGhcNgfJLIyG;
        vzLPMGhcNgfJLIyG += vzLPMGhcNgfJLIyG;
        PmrXGvLrnO *= PmrXGvLrnO;
    }

    for (int oXktQx = 256996565; oXktQx > 0; oXktQx--) {
        PmrXGvLrnO += vzLPMGhcNgfJLIyG;
        vzLPMGhcNgfJLIyG /= vzLPMGhcNgfJLIyG;
    }
}

int QaqTZyKTFKEl::IKLcgEgJNSkkSnyU(int JXFXkFAmrxcholP, double jAzepRUJnxJlEQ, string JGmdZcOiXIzE)
{
    string siBmcdU = string("qNbVdGeHCYrkcNLirUUhmVXeLSKkyfIeYnYKBAfrxDIcqdJP");

    for (int tWaTTKw = 1394027397; tWaTTKw > 0; tWaTTKw--) {
        continue;
    }

    for (int xfixKfcq = 1303686102; xfixKfcq > 0; xfixKfcq--) {
        JGmdZcOiXIzE += siBmcdU;
    }

    for (int YYwGarwl = 1396611398; YYwGarwl > 0; YYwGarwl--) {
        jAzepRUJnxJlEQ = jAzepRUJnxJlEQ;
        JXFXkFAmrxcholP += JXFXkFAmrxcholP;
        JGmdZcOiXIzE += JGmdZcOiXIzE;
    }

    return JXFXkFAmrxcholP;
}

string QaqTZyKTFKEl::lwMwjMMM(bool QGSmBBe, int BmvDOCJeahM, int XkBhDOypGMTYkPH, int KSZhYPzD, string yctPcYkLvEjYoc)
{
    bool QJTwXY = true;
    string wWeCziFHWsquh = string("ZtHodLbQDxtiulytAvXawScoRF");
    string EpVzLkueFIGYV = string("yrRFmfuqOdmtrMpeSZUegWusUYLxSjwHeFIDmEsKxRpWbTJdREGYTtdOhYYCRfDZlOFqHauHFqqhkJfwDVGHaNKXUsHbLCnyU");

    for (int iKigIcOwm = 359615336; iKigIcOwm > 0; iKigIcOwm--) {
        wWeCziFHWsquh = EpVzLkueFIGYV;
        KSZhYPzD += KSZhYPzD;
    }

    return EpVzLkueFIGYV;
}

bool QaqTZyKTFKEl::OezWJ(string rWKyzHUW, bool akIlVNyYGZ)
{
    string BsnMrjQifwU = string("wqlYoPPQLclehTpYHtWOrWsZJoBJNwXByYtspwLDzNMIyPkfydVVborVZpaKZyEbIrSCwOXnURqQddboCniikJYejzDDSdkohlLEfwaRNExskpBMaIMoniolbAKIxbGCnPZXVMDHtgixtL");
    bool kDPZbifVnqnbR = false;
    int fEUKguQD = 392135170;
    bool qeqMMesW = true;
    int gOPmVoFxGvYQeQ = 350857276;

    for (int sycNxSkoOPYvuefb = 1818051783; sycNxSkoOPYvuefb > 0; sycNxSkoOPYvuefb--) {
        fEUKguQD /= fEUKguQD;
    }

    if (akIlVNyYGZ != false) {
        for (int GOpMkjMJgoCQdg = 1780367692; GOpMkjMJgoCQdg > 0; GOpMkjMJgoCQdg--) {
            akIlVNyYGZ = ! akIlVNyYGZ;
            kDPZbifVnqnbR = ! kDPZbifVnqnbR;
        }
    }

    if (rWKyzHUW >= string("wqlYoPPQLclehTpYHtWOrWsZJoBJNwXByYtspwLDzNMIyPkfydVVborVZpaKZyEbIrSCwOXnURqQddboCniikJYejzDDSdkohlLEfwaRNExskpBMaIMoniolbAKIxbGCnPZXVMDHtgixtL")) {
        for (int MEfbFeSyOHi = 1362335039; MEfbFeSyOHi > 0; MEfbFeSyOHi--) {
            continue;
        }
    }

    return qeqMMesW;
}

QaqTZyKTFKEl::QaqTZyKTFKEl()
{
    this->cMksglAWO(string("IIuUjxCXjcryATbZolAGaWkeBTtdTNUZhfKjsUrbGeoSfwKIwQbmgvBFSbSTuKJKdihbHodLOfWCGDZDxYMMSycmtJzUQWoFKpxSggEDfOmHSMYkhSyulFpGTCJLwOLMlkQKLdEFblmrbrGvYWpirPHHNZvWU"), string("xvaJBdSxjrAkJIeDeOStxLRbjklyWfIjNcUUYyCiFwuelYaQonexiublYLXgIuyBlXhWGuySkfgupqevtTvnsUMXQFvXvFeGRyFUlrehajpOhgcitDfGuOmwQdMojgmxdLwflqtLsaMOEMMeNvZmhpvPPqiJdRdgFYNsHBfgIdQwVP"));
    this->bXaxYPuUr(false, false, false);
    this->nraGaYxOwv(-80876.49907617315, -751737.7485179981, true, -894838.2580190717);
    this->ioZJfdt(-1373602153);
    this->gcgkCx(string("OSzDSSBeVfXwgjStEMSiFdZjbnwQnbeBZNyCjTeMtafLLLyiNBLdOsZdiJSZZkceNlVUAbQFtDUAEebyCrvPOvhEVdgxsWleanOeM"), false, -410062.30034609506);
    this->OPaiaHYDeJZnJik(string("InxvMqMxxKWArxZKkujCmaSgeEaFNDrDHEghrXDckinOgmYcKJMjXDgLlIbwMVMnrbeFkeWGgQePJbwcUSmeGjUzNizfCKqYxGmIKqtBTGAMclOBOSzoxxOcoIknidkRFFbtJSVzPZffQFgsTUiZLFSphVftytCQAPhPypDEETixSqDLJfJMacUeqgETooHvpRNZEcSkmluYVQptavAIdevBfSBnIMwjpT"), 371206336, 1496052219);
    this->oTPhTmSjhT(string("hfFsbLZIaBcgMKBRVNxKlQuGhQrqljEZVEUFbTWYbqHvsqvcuVojNcNbfGrkyHdCEkouKjQkaNFHFqVjbdkQjOoKIqQoujaPUIokPsqecXgdifywqYxPNeoeYuyeRwoPEISubOzrDmIjmwhMWlGFznVXeJXX"), string("jXCpWtCEmuLkqbqhilDnmTbZxRBtcNeVqoOTprIFvvCsTSEwbBpgmTzsdYispKWqwxRCdwHMKBnLOjllXC"), string("VeSkhHVdxDMiaRbXNVelmmeNviWBZDktRoBkrbxcdguubJenul"), false);
    this->bDDSDTA();
    this->IKLcgEgJNSkkSnyU(-1452058980, 697814.5933688954, string("rMLKDjuFbSybomjIvzoioNTiLiTHmnLPMRHQhJwshaqgNgWdJJjRUgXIJtByctZta"));
    this->lwMwjMMM(false, -974946297, 301124093, -2101757471, string("GKAANajpFwWjxfClmyCyvvJsZhvukEedZMkAlGCOhzmTTbevLAdOJYdLQfBHzlPpSiMlCwqvVYBHzXzrkkRTnMBHSiQSEZFxrGZKIjZIECZnHOSdIDRRNlNgfXLJZhSMXVF"));
    this->OezWJ(string("OMUYxGcElFWoZgNszzSpCcqlnrdAbVBXcJMJAAMkKSPiaPBaCrOGiIlwlOHYOQuytHLcFUdaRodPhqLPRfZiiOxKTTbyHWBBeCMLNCpmCMkFPPaOvfOfUQtWZwMCJinBkWGLcShSKcmngORPZqAmsDSQQFMrLDigTJVBxCUPRymOpBWRRlXkEDeTfVuDKAQWtGqlCKPEEagLZsDmmRAUfexyR"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KLlZacs
{
public:
    int JYEQvlPTUhm;
    string ilmnLkGNmavi;
    double KSRXbPlZK;
    string jhPQdQ;

    KLlZacs();
    double DDFlGLQkXAkqo(string WIWyPncWWoV, bool lharnpfH, bool gMDqXTpSjMMPwP);
    int zSbpYhyEOMmqwXp();
    int KeaFVKog();
    double zQflwbTRMxOvS(double SjPqPysoPDX, string aiPSdEx, bool YfQyPgiq, int uoHVGuGx, bool nKhiiXvQidvrbr);
    int cPpMpUp(string XXUgCLutrt, int SLxgJUmdE, double XJOGKcvnAODt);
    string KhURsaMyitOYSd(double tsBfTTB, string GkesthOyko, bool twOGjNrYHWGxqJQj);
    bool lboUVN();
protected:
    string pEanxpBreOshKq;
    bool BkRCg;

private:
    double NOHWHvj;
    bool IVCtqreLRy;
    int ETeDWRCQxW;
    bool ZcgBMqEOqJ;
    bool dXXBVoTuVDHK;

};

double KLlZacs::DDFlGLQkXAkqo(string WIWyPncWWoV, bool lharnpfH, bool gMDqXTpSjMMPwP)
{
    int LsPkazBskbDYQx = 1401106217;
    int ykfZlGGLd = -499234243;
    int LBxVvzVsXULasio = 1337150691;
    int BchOVLKgIDCflt = -1088423918;
    int tuSzLxzYv = -2041358109;
    double KxszMr = 504291.61918225244;

    if (ykfZlGGLd != 1401106217) {
        for (int FBjEVwLhv = 1586339663; FBjEVwLhv > 0; FBjEVwLhv--) {
            continue;
        }
    }

    for (int QcnCiArncVWFT = 206139171; QcnCiArncVWFT > 0; QcnCiArncVWFT--) {
        ykfZlGGLd -= ykfZlGGLd;
    }

    if (lharnpfH == true) {
        for (int ovMUyVn = 1870050638; ovMUyVn > 0; ovMUyVn--) {
            tuSzLxzYv /= BchOVLKgIDCflt;
            lharnpfH = ! lharnpfH;
            LBxVvzVsXULasio -= tuSzLxzYv;
            gMDqXTpSjMMPwP = lharnpfH;
            BchOVLKgIDCflt *= LBxVvzVsXULasio;
        }
    }

    return KxszMr;
}

int KLlZacs::zSbpYhyEOMmqwXp()
{
    int RjzGIPelhp = 1441868376;
    string LPfbffck = string("XlDZDJJmLHaBfeeabunfLchSZkhPTRsxVLKHfKpdOyqjXFHnhWjPHJJIkeKPODBTuBCDlbbKPdtAKwtcKVhWnsGSlQEXJNogphVARCXjxltFbjTxUAWcHhTqThOZvwvFwIuQnsovTlsCjFPIwWMliPqnJFYPBfZRyjWymXddijdAcJxIDXshIABOAaVEhMrTrjFcMqxsaMagNZnLvyOuNTahlyzAWmgqVoqZC");
    double vmkbPBnDJaPzS = 710211.6088196369;

    if (LPfbffck < string("XlDZDJJmLHaBfeeabunfLchSZkhPTRsxVLKHfKpdOyqjXFHnhWjPHJJIkeKPODBTuBCDlbbKPdtAKwtcKVhWnsGSlQEXJNogphVARCXjxltFbjTxUAWcHhTqThOZvwvFwIuQnsovTlsCjFPIwWMliPqnJFYPBfZRyjWymXddijdAcJxIDXshIABOAaVEhMrTrjFcMqxsaMagNZnLvyOuNTahlyzAWmgqVoqZC")) {
        for (int xCaNK = 181776135; xCaNK > 0; xCaNK--) {
            continue;
        }
    }

    return RjzGIPelhp;
}

int KLlZacs::KeaFVKog()
{
    int BReHOaAiYsyasB = 2022348390;
    double ysxfsZzo = -87640.42674388037;
    string LyuawwewTuWkciOd = string("wHARduSCbPxwjDfLqDcxCfpCLvuPBCWRXelBsSsJaLOdJbCBZstPlcQqikIGZmlFnyGuQIcLOIlNNrpRzT");
    double DyvlBIcrZKI = -991407.6294857519;
    string TtjPBq = string("iyPzztaSvtkcqabQKtTymMGZcvNJJRGvoQgBv");
    double DOANlXOX = 382995.70343257464;

    return BReHOaAiYsyasB;
}

double KLlZacs::zQflwbTRMxOvS(double SjPqPysoPDX, string aiPSdEx, bool YfQyPgiq, int uoHVGuGx, bool nKhiiXvQidvrbr)
{
    string NTJjhvV = string("faJHLntvLkEGMklnMxjZkwYPYzEQTwBSbvmIiocPVjyuXlkWrovQPuOJmIOVfsrYrCritLMOGPpwPynGCAKKAgNDWbGWkdOXDkKxMNymPwdsTUxqMjNgBEmGfAufIrRSsHtxSBIoxCmHjEvhIxqSNCyEdxhJlzTouoOCvxdmZkWbAh");
    double zXqFFWSoPn = -209948.21371577913;
    int wAzVKNeKwMt = 512949432;
    bool VXuDqBvK = false;
    double cfXvQjqQxwyk = 726638.5061078308;
    double SNjYC = -66974.87752357557;
    int TkNeAJciK = 221362277;
    bool BLHnoQqdsWaHsy = true;

    return SNjYC;
}

int KLlZacs::cPpMpUp(string XXUgCLutrt, int SLxgJUmdE, double XJOGKcvnAODt)
{
    string DGnfmKAZZWeyLHow = string("UHfhcvfgMqMFQxkZBQtNFfkPpRgOWbcCzhXTtYzfEzjvSDlzNijYWXTWbkviqMSoWCNTXAvwymyVQrwLKpxtsDNdWxoHvDgmoLokvLEHqehZlCddxL");
    int HJMFs = 17642076;
    bool jwRAiTXAz = true;
    double OapvWaYMOkrdIkYl = -871305.3202105595;
    string TUArgqtqBONGbWcM = string("wssbLJdDuAzPudisheLzbLpcILsrQeGMnEEqNsyyqmkXCHOFkliHricfDmhkqlgsOsZCzwXHkecHmgbAnIUzXQsuZAVfMjqloUYhckWfHCXbdkMCycpCCpCZEnVMEouapFKU");
    string wMlAD = string("aBwBkPdZQidwhqOvLLkomnvdBXdzEiGXnIWsgwVqwBvmskkBjyOGdFhwjmHezTOqwWunhCPCOISOtMVXdCXIelyEGZpKPOrMYqQPQWFDsSABIOZBkCiguMRRnOkBsLpNJUkoazwocZQwaUVirCDjHBKgdtdWCvDrTAOKeUnAuAHvNRRGzogftYQwDjIv");
    double fyBKpRChmLnER = 901452.487924739;
    bool DQauJC = true;
    bool WArEVlCTB = false;

    for (int pWsnoknNuNwn = 1642673507; pWsnoknNuNwn > 0; pWsnoknNuNwn--) {
        continue;
    }

    return HJMFs;
}

string KLlZacs::KhURsaMyitOYSd(double tsBfTTB, string GkesthOyko, bool twOGjNrYHWGxqJQj)
{
    bool ZjNhXrdQESUEzilZ = false;
    bool zxRNYazoEt = true;
    string MPZbnfnqLUPKGDS = string("FDUCPsOHqmznZoltipJUOqubefVtdorqCpVakdHgXaWnKOwfmAUKMhfZlJgobKmuzZTkUYbwlkuaXfuoOsVWHEfDWBTkrzgyaypHLieilUZvcRCaESjdfDMehWhIWuAMHwGfSvtLaJFJceKSYD");
    int lkPSquZW = 1234905549;
    bool YUKfEUxCMLdrzHiH = true;
    double XTVtIBaHENL = -341885.52823798766;

    for (int RxiHIHzcFPWKz = 1864801080; RxiHIHzcFPWKz > 0; RxiHIHzcFPWKz--) {
        twOGjNrYHWGxqJQj = ! YUKfEUxCMLdrzHiH;
    }

    for (int fsUZkASx = 2035545469; fsUZkASx > 0; fsUZkASx--) {
        tsBfTTB /= XTVtIBaHENL;
        zxRNYazoEt = ! ZjNhXrdQESUEzilZ;
        YUKfEUxCMLdrzHiH = ! YUKfEUxCMLdrzHiH;
        GkesthOyko = MPZbnfnqLUPKGDS;
        GkesthOyko += GkesthOyko;
    }

    if (twOGjNrYHWGxqJQj != false) {
        for (int baiaRlgStDjUovo = 1614548003; baiaRlgStDjUovo > 0; baiaRlgStDjUovo--) {
            continue;
        }
    }

    return MPZbnfnqLUPKGDS;
}

bool KLlZacs::lboUVN()
{
    int lehkseVWXVesPIeh = 1645196402;
    double HAeISId = -267141.1815620951;
    string lRkNQRvc = string("RuQJVwAxiQikUklQOMDBntEcEVSFnVPkuXbruFJMMflfSJBXJVnIgQEoQievFEUmaFdbxDtcqcgxDDmihuAnLThbXHjvGzcASUrHseizufEXxMIisYxyEbMAjlnjXYwjUAVuWkplAdQQVfVEnSoRFZSmlrimStRwnuVdYymCWvPdmhjwcgopHgokjWLbMfCLTDgjYtPQRsLSRwNBcAWrbNZaBpksIWPEl");
    bool stFKp = false;
    string HMYBT = string("hpiFvwSfDRIfyJEEBnctanVtrYCeMzPPmBfMEtWTSVSYldXVLxBOMSLgRIqSSildvLQoRnDIVjuJQxvltGvtgHDhJcuSEiumeznMQvmbuiQmEaVcykXcwWNrIqlEcMUmCKGpWkgKcgqwbzCh");
    double MQVAp = -338925.5677187906;
    bool UJNroAd = true;
    bool rScCxAR = false;
    string azcDyq = string("wAMDCkbpOODRujExtHkrFaJzSElcPOoZrrBvnNPtmZLsNbWilUQSELwLeoGvEpOcxyfeVBiNGurVWVFVUKsyHnviDURtDulUorEIdFvWPFpEmubqBVMyQsnfmjFCGfsmQoxSRtuMFheMngEjFd");

    for (int jHzNgGsopZ = 1805088843; jHzNgGsopZ > 0; jHzNgGsopZ--) {
        UJNroAd = rScCxAR;
        HMYBT += azcDyq;
        stFKp = stFKp;
        HAeISId *= MQVAp;
    }

    for (int lqqkwlYNk = 242842144; lqqkwlYNk > 0; lqqkwlYNk--) {
        stFKp = UJNroAd;
    }

    for (int adlenLkbzmAlQZxN = 1979549520; adlenLkbzmAlQZxN > 0; adlenLkbzmAlQZxN--) {
        continue;
    }

    for (int EdiaP = 1854853191; EdiaP > 0; EdiaP--) {
        HMYBT = azcDyq;
        UJNroAd = rScCxAR;
        HMYBT += azcDyq;
        lRkNQRvc += HMYBT;
        UJNroAd = rScCxAR;
    }

    return rScCxAR;
}

KLlZacs::KLlZacs()
{
    this->DDFlGLQkXAkqo(string("YdiqgkFSXIaerjkpsBDXgSMcobUDuKzeOTjserCzkWqZqUzQueUwxXXHhAcqWpF"), true, true);
    this->zSbpYhyEOMmqwXp();
    this->KeaFVKog();
    this->zQflwbTRMxOvS(178138.1031591538, string("uiWolgDjEjLKMQOQBNApvKxBJuLZuPdlCEsYiyqDLoHpnNAWIUsCQHxdsRgSEPjEBXmIhkuQVOTiHkmVaUKhOvXAZuvBQwdREMdAjfAiilYgeLaqpepsgKLTwkmoBZtikQkCcmVtKqVyJIpsOvzOVTyTsBwrcCUszrmIpojMbPAlZRIsaNSqTVlANFMLB"), false, 313387524, false);
    this->cPpMpUp(string("wYqkOrFLfyRbmFPdAFGdooonDoPasjBZdJEfhwlVWWoXLlPKcMDfyoQViuxWDJJKTZNHjuSDImWSjfSiGoWLTbaHTgHakYRzLwwQXTfSiqMGzTXJwdaexZa"), 1352053257, -747036.1649521454);
    this->KhURsaMyitOYSd(1047856.3563388127, string("DwGNs"), false);
    this->lboUVN();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MbwItaiqsnvbIa
{
public:
    string uYEECTYMQpkdpts;

    MbwItaiqsnvbIa();
    double ecJLXpEOu(string lBAiDyPz, string yKaiBJOpqmV, int WsXBSKeOeZzvwf);
protected:
    int DsFOiPdQ;
    double EJdnMPNsYIW;

    bool bYotCHGdT(bool vnOgWLz);
    void NkQbfoEnpasovs(bool LTPsRVjgeVzcJNg, int fFMAYGSggAw);
    void LUjlLxJPzZOQ(string faQJOUV, bool UokPDHewMBQnzijn, string EynPJeNzrYEb);
    string UYQPC(double BYapLnu, int LKQMvphACLvHiTy, double cMEZoJVD);
    double zxVlV(int voPSQkyaEywfkDzs, string EGWYNwrlCuWHj, double reUbjhdSjbCuZl, string DPsuSKtqGrxFnHSP);
    bool sqoDWaJU(string tqdlfTaPA, int ijsrbnZfHKnLoTX);
private:
    double dRHHYfI;
    bool XYHvzGHNT;
    int mxWIFlcHEEj;

    void ZHOiEFoCCe(double DMjAyG);
    void qGoRjs(string WkDbgVQHgoKJbT);
};

double MbwItaiqsnvbIa::ecJLXpEOu(string lBAiDyPz, string yKaiBJOpqmV, int WsXBSKeOeZzvwf)
{
    bool ctiFUTSEsWrLh = false;
    bool drmtXWykIq = true;
    string YQFeSYzC = string("sIuJVCsrzmbNwgIivDbdpygevHOWNQIqACwxmWvOldjWqXwxdgLXvGvEGYWcZAJJtRertjQLBqYBqdsVzPpjTIldSTQhxSNvKjCSzhyxEwlGDjnEuAXjEhEGpJFMhVpufaaajmrzIdjQKakMokAsJpmsSAnlHJWRfVYAlymZCugmjVXdADQJbjtImNiDHzKbhvLicsYkqRvHgNDUUwfSItqQOilkuZMigMyOnhSQbcQlVpUo");
    double sEQeovf = -423454.42432168726;
    double nmKGQeV = -1036375.2639769184;

    for (int iNeISlJeNlA = 1333352109; iNeISlJeNlA > 0; iNeISlJeNlA--) {
        YQFeSYzC += yKaiBJOpqmV;
    }

    for (int rrXYDza = 813544938; rrXYDza > 0; rrXYDza--) {
        drmtXWykIq = ctiFUTSEsWrLh;
    }

    for (int ysnyfFSvfuV = 882777213; ysnyfFSvfuV > 0; ysnyfFSvfuV--) {
        YQFeSYzC = YQFeSYzC;
        nmKGQeV /= sEQeovf;
    }

    for (int mQBgAHiipoq = 1191009561; mQBgAHiipoq > 0; mQBgAHiipoq--) {
        sEQeovf *= sEQeovf;
    }

    return nmKGQeV;
}

bool MbwItaiqsnvbIa::bYotCHGdT(bool vnOgWLz)
{
    string RRMKeo = string("UqWKzMZtHIzoNshmmPLLuLKzFFvBbAZemdFnNAECohWalhEMuiLogUrsXYZzkzbITlciOPrxFCeoUWrceElyGfRvMdaWBYzEQfjdCKBDCkgJkxZJibfmzLUuAi");
    bool sBvbXitUhYMf = true;
    int HApJK = -1780912817;
    bool bflcBXdLydWRi = false;
    bool PmgvPSPzLNBqVA = true;
    string tSNYgjhAD = string("aqpPGXmbWxtVbYqFIljricTwMHqBzwQRfVClyJqYXbgbTbpyGhjMmzLjSRTUJFiBBckhEdLeCdUhdCoeGmjkfTfkZkpoyeumcxdyPidetSXoD");

    for (int Rfnkh = 995785166; Rfnkh > 0; Rfnkh--) {
        tSNYgjhAD = tSNYgjhAD;
        bflcBXdLydWRi = sBvbXitUhYMf;
        vnOgWLz = ! vnOgWLz;
        PmgvPSPzLNBqVA = sBvbXitUhYMf;
    }

    if (vnOgWLz == true) {
        for (int QRwdmnQ = 29886324; QRwdmnQ > 0; QRwdmnQ--) {
            sBvbXitUhYMf = ! sBvbXitUhYMf;
        }
    }

    return PmgvPSPzLNBqVA;
}

void MbwItaiqsnvbIa::NkQbfoEnpasovs(bool LTPsRVjgeVzcJNg, int fFMAYGSggAw)
{
    bool dinzyqoPzfDW = true;
    bool ZEcFokdEFNnwY = false;
    int lOkHODpxm = -1901165544;
    bool VRgfhxwc = true;
    bool LtDsyInN = false;
    string cUgfcgfEf = string("QUgJMOPuzAzwfSeyRlWdNGXSYYkBOOgqgNbmrzXYZfcnLoqVyOeISdGPasPiLUf");
    int fmAPZSCmTazdAxN = 1841011799;
    bool PhIzwqoWm = true;
    int kStewXkqm = 842838658;
    double EyRHXv = -499401.5136367861;

    if (PhIzwqoWm == false) {
        for (int vcTNBsQAzfWxBq = 1454356927; vcTNBsQAzfWxBq > 0; vcTNBsQAzfWxBq--) {
            ZEcFokdEFNnwY = ! VRgfhxwc;
            PhIzwqoWm = ! dinzyqoPzfDW;
            EyRHXv += EyRHXv;
        }
    }
}

void MbwItaiqsnvbIa::LUjlLxJPzZOQ(string faQJOUV, bool UokPDHewMBQnzijn, string EynPJeNzrYEb)
{
    string rgRQJaphKSDuVzYh = string("qQRTYRCOFWAjalvfUebgpAyAKubGgWWjXcoSYFhHcocGKtJrCFzInMEoggqvoAwckyzsjTrqhZlIsqVbByjJCJJXAXBLrNtyYvsEsmmpTsLLHdfLPFyXtCefbEUxFsnZisDfpXkBwSMVOrZdQYUClyGsBoJWZkopSSjhmfIgGZIQTLcfpxlRqwa");
    string ovwwPwDScuEP = string("rYNKZbbcSkDQTDvghMyHrHMpKXbSozNYTIBRiwtLsLPYzuUAeaDTpHjqNBvjFxKjDCcuubcLzVrYRxekxUcsyLDCdmkPRNAbZclJJlDYLskscQaGndbcNDaEkQawzCLwnFtEEQRUokCQHrZDcAcHbvtazdBEdMmjMjO");
    bool NKOtPDj = false;
    string SMwEH = string("EgDwDmyZMYYZipviUA");
    bool CkmpeUBIKhc = true;

    for (int nIZmGukF = 1741234008; nIZmGukF > 0; nIZmGukF--) {
        rgRQJaphKSDuVzYh += faQJOUV;
    }
}

string MbwItaiqsnvbIa::UYQPC(double BYapLnu, int LKQMvphACLvHiTy, double cMEZoJVD)
{
    bool goDvjqRJC = false;
    int WgxbZqh = -71370747;
    bool vIWNiFY = false;

    if (LKQMvphACLvHiTy >= -787383041) {
        for (int liSqXzTMWym = 684940946; liSqXzTMWym > 0; liSqXzTMWym--) {
            continue;
        }
    }

    if (WgxbZqh <= -71370747) {
        for (int KjBWE = 1351863301; KjBWE > 0; KjBWE--) {
            continue;
        }
    }

    for (int ROnuid = 1633536978; ROnuid > 0; ROnuid--) {
        continue;
    }

    return string("wGCKHThEjRPxfRdrgqeQDLefUCemDsfKcdxSVcicRfuNuhzeNEFmRpQEqqrTozhUnDbDvQXkcOxlrJdBdLvRsXQKrBlDnKeXsBAFfBmjsVnZObpvpgNnFeJJSEmxUxbHKhKVKiYcgeKhiCoaQDiyrCydEesMwXnbDrODmRxDHCxwxeTGcGffyiLDypjqXGTQGDOF");
}

double MbwItaiqsnvbIa::zxVlV(int voPSQkyaEywfkDzs, string EGWYNwrlCuWHj, double reUbjhdSjbCuZl, string DPsuSKtqGrxFnHSP)
{
    string LsmYXfwfXvGU = string("DiJArgJSBddOvKPpLuYbENarwyzZZYIMhpQGgRtEiCPMzYPqaJLaMoMsgecbdeZxWzfFEcAXmJlzwKRBjlZNQjyJxWxTqsIqKzEGItThFcDBEesajtMLdxuFYzYgpeEYliwEOZbCztXBmVOtKbhzEPAtyHfTaDdaMNHIeKGoPDrQLyetAvArebgZJlKFPHnNAYMVrFaSgIiLvb");
    double HDrZwCv = -211133.6329265235;
    double MscfQUcssO = -549263.8883429593;

    if (LsmYXfwfXvGU > string("DiJArgJSBddOvKPpLuYbENarwyzZZYIMhpQGgRtEiCPMzYPqaJLaMoMsgecbdeZxWzfFEcAXmJlzwKRBjlZNQjyJxWxTqsIqKzEGItThFcDBEesajtMLdxuFYzYgpeEYliwEOZbCztXBmVOtKbhzEPAtyHfTaDdaMNHIeKGoPDrQLyetAvArebgZJlKFPHnNAYMVrFaSgIiLvb")) {
        for (int SAspJgbFWMfnG = 1744466509; SAspJgbFWMfnG > 0; SAspJgbFWMfnG--) {
            LsmYXfwfXvGU = DPsuSKtqGrxFnHSP;
            EGWYNwrlCuWHj += EGWYNwrlCuWHj;
            voPSQkyaEywfkDzs /= voPSQkyaEywfkDzs;
        }
    }

    for (int VRkOiWnNmsNhyF = 704644143; VRkOiWnNmsNhyF > 0; VRkOiWnNmsNhyF--) {
        DPsuSKtqGrxFnHSP += EGWYNwrlCuWHj;
        LsmYXfwfXvGU = EGWYNwrlCuWHj;
        DPsuSKtqGrxFnHSP = EGWYNwrlCuWHj;
    }

    for (int yOZDAb = 388367348; yOZDAb > 0; yOZDAb--) {
        LsmYXfwfXvGU += DPsuSKtqGrxFnHSP;
        HDrZwCv -= reUbjhdSjbCuZl;
        MscfQUcssO /= MscfQUcssO;
    }

    for (int cIGqwjIB = 246449832; cIGqwjIB > 0; cIGqwjIB--) {
        reUbjhdSjbCuZl -= MscfQUcssO;
        HDrZwCv += HDrZwCv;
        LsmYXfwfXvGU += DPsuSKtqGrxFnHSP;
        DPsuSKtqGrxFnHSP += LsmYXfwfXvGU;
    }

    if (EGWYNwrlCuWHj <= string("sQpolVkpuEDosrfhIXFjxudSczanUEDdWwVnNNeseNjOHbcclxXOrJUSbWkiSqhqkCMwkyzLEAkWFmXEsIfAFgaWu")) {
        for (int ImzqaBmvbMI = 42820881; ImzqaBmvbMI > 0; ImzqaBmvbMI--) {
            EGWYNwrlCuWHj += LsmYXfwfXvGU;
        }
    }

    return MscfQUcssO;
}

bool MbwItaiqsnvbIa::sqoDWaJU(string tqdlfTaPA, int ijsrbnZfHKnLoTX)
{
    string GsWQrPgQrbiuyg = string("yyPOJpCOVNgQSvFddaLsfBCLQKjMooinFRucmAtBxIyQWOgSoXUdvGEfcLUbDnDFQBprzsAiYWmlLNxlfNlSCoklNiutfBmudJARRPsCRrYvHFrorbeyzczJRWdxiDuMIouQdPYgjWGdOaFxagbUSDEpWFEOQRCFghJAmrWxqjS");
    string NjjjcwZ = string("iwEtFXojvuzCzxHgaabSrVertfaJgtKFwIfGTxBJVkbZPFUSphdosXSGFqBrHuJtgOKesdHZfloQxGCKgnwIfTtIgAJtMCUEolkTOXYiVtbdHvNxOvQIHmIzdjaMBssWteMqoWNVXOWbFmHHInXZBdpjpZTqmgbsCxNpaqwIfDOCrQhOzanmubfTfPuhhsIntdXCdZnqGzmWvrXmiRdFhlslApYOHedlcJGoxalHcmYtxTGsrROPPftY");
    double kgFVhPGwVZanC = -163280.91268365603;
    string cawEC = string("yFcxSYaOFbaynmUhqPjFPyAzcngDkfcORYqIGncDnCqgXTPnsCsnwfmXxleJWERtzSjFRCaMyx");
    int NuQtxT = -152148030;
    int VlHwrsQdX = -348443596;
    double KFuJOEezYJ = -373115.70511709363;
    bool wiMmQDT = true;
    string IymbzMpBRJ = string("BTvRtKiHFGsNPylbwPtczoeKJkeoQeiUlchOhclkWpZtWomkmdouJtOwVsoKiAzqAcvmGkNKIDgPSjLibVRQsybSaldGrcQwATVVbNaSBVaRTChjWUWqQSjQIACcaKIAqBmHCgrhSSLcthcmtLZdEpVjDleCTiqzNEGEwXunDnVPketRaBEVHtiWOIMvMCayIhxccOSyQCzIMHbjBjwEiUvFFwcoRrglMIQcSyWsiCcLk");

    for (int aiMVzhYRGAnok = 486916789; aiMVzhYRGAnok > 0; aiMVzhYRGAnok--) {
        NjjjcwZ += cawEC;
        GsWQrPgQrbiuyg = GsWQrPgQrbiuyg;
        NuQtxT = VlHwrsQdX;
    }

    return wiMmQDT;
}

void MbwItaiqsnvbIa::ZHOiEFoCCe(double DMjAyG)
{
    double QlCAkYDbzbb = -983745.7826486537;
}

void MbwItaiqsnvbIa::qGoRjs(string WkDbgVQHgoKJbT)
{
    double ulYeHZqm = 285185.3980761116;
    string yYmpZwvRBPoQmt = string("vphHJapMuKonoILKzKkKceKOizqnLdOGzOmUhXfaONJowQGRczvMPaQijIxsDZChONmMNMrklLsoOnDRQNbEJEmuxXdKSepwFzSpzMGyDgOVaHamqnWaExLldeDkJJzoVVNTFrLLGeExFrvhUhScCSFQUjALwRIglLLlcmJeRHDVztKMqywtZXKDBKBLqpSBoHzlIuEnTV");
    string oHppHH = string("CAGIxMsaAoEPhsHJNVWbiSunXgzUIyWXTugKsqjHUVKvSnlApJRCfVifYQyRtWAtzSuGUChNlgGDHfLMuzXfHmJdZxXNCawWpzHHQcIKhyUGTaEfGLgMznLQxFvADKdRCqnQDvhTFJRfCYaVthFtSAFPdxupssttybdYLlrDQwjInssBRCjhbAwbDEm");
    double yqZtKfbfKtJe = 592331.9953494163;
    double FFJTYPGnIHnAvi = -174947.38232839416;
    int bKxIeRnfootQLJpG = -1696909027;
    string PGrqwHfB = string("kFZirefoJJzowLtrIWKjPfJLlOPoDGjZNBbDVRIWdZFHosvRAPVlwEskaPeZOVAbvqzpPSaHaIXfkmWXTDIStXstnfiBPjIGpDrlVjIEjki");
    bool jRXYJMa = false;

    if (yYmpZwvRBPoQmt != string("vphHJapMuKonoILKzKkKceKOizqnLdOGzOmUhXfaONJowQGRczvMPaQijIxsDZChONmMNMrklLsoOnDRQNbEJEmuxXdKSepwFzSpzMGyDgOVaHamqnWaExLldeDkJJzoVVNTFrLLGeExFrvhUhScCSFQUjALwRIglLLlcmJeRHDVztKMqywtZXKDBKBLqpSBoHzlIuEnTV")) {
        for (int dCOOIHdQD = 1319018250; dCOOIHdQD > 0; dCOOIHdQD--) {
            continue;
        }
    }

    for (int DnYuJboQ = 544591287; DnYuJboQ > 0; DnYuJboQ--) {
        ulYeHZqm = yqZtKfbfKtJe;
        yYmpZwvRBPoQmt = yYmpZwvRBPoQmt;
        ulYeHZqm += ulYeHZqm;
        yqZtKfbfKtJe += ulYeHZqm;
    }

    if (PGrqwHfB >= string("vphHJapMuKonoILKzKkKceKOizqnLdOGzOmUhXfaONJowQGRczvMPaQijIxsDZChONmMNMrklLsoOnDRQNbEJEmuxXdKSepwFzSpzMGyDgOVaHamqnWaExLldeDkJJzoVVNTFrLLGeExFrvhUhScCSFQUjALwRIglLLlcmJeRHDVztKMqywtZXKDBKBLqpSBoHzlIuEnTV")) {
        for (int yXQEQinsSmNmd = 337051928; yXQEQinsSmNmd > 0; yXQEQinsSmNmd--) {
            oHppHH += PGrqwHfB;
        }
    }

    for (int imzjANUpWf = 1202342855; imzjANUpWf > 0; imzjANUpWf--) {
        yqZtKfbfKtJe = FFJTYPGnIHnAvi;
    }

    for (int resDWYwhCYgdhBF = 1797868409; resDWYwhCYgdhBF > 0; resDWYwhCYgdhBF--) {
        yqZtKfbfKtJe -= FFJTYPGnIHnAvi;
        yYmpZwvRBPoQmt = PGrqwHfB;
    }
}

MbwItaiqsnvbIa::MbwItaiqsnvbIa()
{
    this->ecJLXpEOu(string("ZscEwKvYHRN"), string("BufiplEulqInzMFrkFHuwhDpSizzIYgfaLFAUtzXlpfSXJvwxLQyOrzsDeimFvSjtnMmq"), -1552978436);
    this->bYotCHGdT(false);
    this->NkQbfoEnpasovs(false, 22717934);
    this->LUjlLxJPzZOQ(string("pdXAbTfVZvfiviKcxTVfUCoMybuZDdsRqChUIWdHxDYlHaGHKbCoEMqSZUOHdxODYyokPrirHqCIAZfkDepJNsuWaCgqjyKzxJsPfKajAbRaStrrNyKZxZXILbvDrrwJLwtgTGnHLDqjjOcsUufhOTfkWHOsKmxDIWoyl"), false, string("jpDfbGhhYUpeBVTBziscfNoTlVAHMHqJfPLzGctHGIvrwnYIIIwSDLncNmBhVAZDAFPthRtsxzxsUhzFWGLQyRUUHTapkxvBCOFUcnfWivScfeSOFCfaaGilTaYIyzrGrpDeWHCmuMuOhaYqcqQQJLMvOEWjiEd"));
    this->UYQPC(719623.7727453411, -787383041, -53820.55432570087);
    this->zxVlV(1224814031, string("lkjyBEVciMrbokkOAJhcTRwZMEgPLqyVSdXTxUQxOMiYoSkJkySKtLmYKnzvwxAOagbXOuNHQqLxtnYuPCOauYLHFQcYRMfllvrmrcyhjWMafYyyDdZYBGpEcWpZMxkZNdxfEzoRTzTgwGIYhroFxMpRpcmrskWjacPJgCKHLdwJfYKKAGoAUmlwIxzCnHYIdGkYygigCxL"), -984629.7233832418, string("sQpolVkpuEDosrfhIXFjxudSczanUEDdWwVnNNeseNjOHbcclxXOrJUSbWkiSqhqkCMwkyzLEAkWFmXEsIfAFgaWu"));
    this->sqoDWaJU(string("lhXFIziohrDKoEIgtHUAlNBETUCtRJlDrQrHPpIzTXcZyfXjrlWWFYdvehOnNDNwWicGfDlHbsThCiqYTINKHtmKNXxYrtwWzyNtTwuPUXLjsDTMBjvdRQuPaPCJqNhroFffGhCegBbnLEtBGYJjCDfkeZfmPNnoJilwPQqYoHlPMalUeBdJEWSObYjRZsCGc"), -71377331);
    this->ZHOiEFoCCe(854417.6146639979);
    this->qGoRjs(string("BepqxHVNjvuasCjlvkYcTGgoygUTEkiWFJRYCHaVkGglLVCnjjroCIurqoMaYZFEynqKcvXWGvtFgyeLihVHPAwFaaltVuzfgkmmpCigMjReWNsaDSPYUsWHakzlAjXSOigkylUTsMlmdbAoZDRQAmaFiPPLMwCZiRtYAmRWLJVmryyqbiFpvHmhXrFxzpBVunwZkzrDtkljzatIXVnOtFeJgvtcVbdhAyVDWjSjUybyzqZrQVenamEiHIFkDU"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LXNABGLoekpMOKeZ
{
public:
    bool aHvdghxCDH;
    double rEflCJHlCeqpFen;
    int NTsbD;
    int xwgEkmpAZhpxVPm;

    LXNABGLoekpMOKeZ();
    bool qCnLl(int TzSUYajskSqTFoF);
protected:
    double mDffTQNNliolNPCx;
    int NPTPNyCZY;
    bool lqtSlPIylM;
    string zdiOgNJfxTOwF;

    bool UcpcDU(int SCLrN, int MlHDPNeFgamOq);
    int BpFAVllQoktph();
    double lciFwT(bool FgbrdFXMsAEE, string ssPJdDaLKKn);
    void zOEyzuKKoYFB();
    int wxLYsUQPLYTICQOP(bool uqBwUFApVacxP, double xzCofwcMMQSgnPq, bool BjLqgBwOjrUEsB);
    string vyZotBUSfiWQPlv(int yhLHDZUnRQuVynB, int NlYqhnkKupzNM);
private:
    string EjILwBrWfsJLPjW;
    string hPteGTFklv;
    int KnJiS;
    string jGKxCevvWshATo;
    string EdKgfqNjJWmBjgrO;
    int BRcNBYDMCCWB;

    string yuugsjfz(bool vmWHSxcpSpJ);
    double rwLfUThgpTDL(string rVMMlSyapH, double GXNLmMViEMBbcp);
    bool uSfYvMA(string MYPIqdhG, int QYjNGVWvVWlrf);
};

bool LXNABGLoekpMOKeZ::qCnLl(int TzSUYajskSqTFoF)
{
    bool eKPhmGgWeXauJob = true;
    string kpngX = string("imrySsfDOGNJWCMHsMsdJttondjilGWRzhIPdxWrLslxJhoBiLVLPCtKVtBGtOmsnzBAGyFnNDbvZgrvaUkRGQysFahpCXKmtTA");

    for (int BmKnaVLdWXnlY = 1216486186; BmKnaVLdWXnlY > 0; BmKnaVLdWXnlY--) {
        eKPhmGgWeXauJob = ! eKPhmGgWeXauJob;
    }

    for (int CNMmwYG = 587851351; CNMmwYG > 0; CNMmwYG--) {
        kpngX = kpngX;
        kpngX += kpngX;
    }

    return eKPhmGgWeXauJob;
}

bool LXNABGLoekpMOKeZ::UcpcDU(int SCLrN, int MlHDPNeFgamOq)
{
    int bBrVsxsJGRj = -536714712;
    string BmgvHwHkIEre = string("dejhrtPiVzaUroWRcYURBqZYEwfaGINvivrMUVJqICaIsrBobYOnSyJzlohRorLrXwngFDpzjecCDMWdxEITTWoDJCjEeMohTDAdYIQiiabDuRBjFpZwZLjYUeDIpjJUcwajgcHycWHpWwDSkzQCdFPQLzuIPbSFoCMoYObFPb");
    double jaofYWSZnilJZZ = -724307.6122227829;
    string GSALKpbvJWYupw = string("nZLwPoqzlopSPLKnSGLnmqOcXzFeqJqDBjpGyVOZxlaNcMERPXKLU");

    if (MlHDPNeFgamOq > -536714712) {
        for (int fcsnWX = 1924462466; fcsnWX > 0; fcsnWX--) {
            SCLrN /= SCLrN;
            GSALKpbvJWYupw = BmgvHwHkIEre;
            jaofYWSZnilJZZ *= jaofYWSZnilJZZ;
            SCLrN -= MlHDPNeFgamOq;
        }
    }

    return false;
}

int LXNABGLoekpMOKeZ::BpFAVllQoktph()
{
    int sXGscsWz = -699084650;
    bool XkXzcBi = true;
    int qDjsL = 1635608271;

    return qDjsL;
}

double LXNABGLoekpMOKeZ::lciFwT(bool FgbrdFXMsAEE, string ssPJdDaLKKn)
{
    int BliDdXnmcCa = -2060565965;
    string BrcNEJvVOsg = string("jmaArdEcjhmxWPAhRsNSrFkytBxhAdlnCwLRtyqcxYctebTnStIb");
    string ppvUynpGzC = string("zjZfbnEDHqVISeHgzrVXhaKnJTpciBjMCDoMRfozPSlpNSYGyoVbsfVQTQaysaFHaefzfVsZNJlDQAMSFHyxfPSsHWxSjXDXDHggwHcuRwQigJxPWyKEpkGViUbtKFWmKNROjTS");
    bool oarzIHbl = true;

    if (FgbrdFXMsAEE == true) {
        for (int lbmOxD = 443408986; lbmOxD > 0; lbmOxD--) {
            BrcNEJvVOsg += ssPJdDaLKKn;
            ppvUynpGzC += ssPJdDaLKKn;
        }
    }

    return -681677.4873486487;
}

void LXNABGLoekpMOKeZ::zOEyzuKKoYFB()
{
    int jGwstfbctWJJ = 730285623;
    string bkCdTMjZON = string("NCcCJjvTjsIciYDxfUHptQXyARDogvBEhbzsFRgzvkcqntGtOLwOoJbBoqcnijXUIpzBlIzMtwTNYlczpYMqArunSpunsyaxhMnGbXYGLkjmkZacYWyEbRxiUr");
    string NPKoYfOQldnpshE = string("chQWvkhTTJLALONjQupvKWFjghLpRZEbcMpfmDBRmLiJwlBYqtsFTlBazpyjdKtwDXhaTcFuiDUDNBkhnRlwaNgvqbD");
    int gOdRJKJgE = -712635127;
    double hWdgheqqOjEboeD = -971928.4488073521;

    for (int fJdYjU = 856184964; fJdYjU > 0; fJdYjU--) {
        jGwstfbctWJJ = gOdRJKJgE;
        jGwstfbctWJJ = gOdRJKJgE;
    }
}

int LXNABGLoekpMOKeZ::wxLYsUQPLYTICQOP(bool uqBwUFApVacxP, double xzCofwcMMQSgnPq, bool BjLqgBwOjrUEsB)
{
    bool vqwRNwuhCrVxtL = true;
    double RUgZpZvZURxH = -903264.2298418795;
    int QhKgmDpc = -875430826;

    for (int BackANgGAb = 1758046189; BackANgGAb > 0; BackANgGAb--) {
        RUgZpZvZURxH = RUgZpZvZURxH;
        BjLqgBwOjrUEsB = BjLqgBwOjrUEsB;
    }

    for (int BnSHssm = 606535198; BnSHssm > 0; BnSHssm--) {
        QhKgmDpc -= QhKgmDpc;
        vqwRNwuhCrVxtL = BjLqgBwOjrUEsB;
        RUgZpZvZURxH -= RUgZpZvZURxH;
    }

    for (int RgdIyuMSCMe = 471777356; RgdIyuMSCMe > 0; RgdIyuMSCMe--) {
        BjLqgBwOjrUEsB = ! vqwRNwuhCrVxtL;
        QhKgmDpc /= QhKgmDpc;
        uqBwUFApVacxP = ! BjLqgBwOjrUEsB;
    }

    for (int IRvdYyLQgsWprf = 1886430222; IRvdYyLQgsWprf > 0; IRvdYyLQgsWprf--) {
        continue;
    }

    for (int zjcle = 33451791; zjcle > 0; zjcle--) {
        vqwRNwuhCrVxtL = uqBwUFApVacxP;
    }

    return QhKgmDpc;
}

string LXNABGLoekpMOKeZ::vyZotBUSfiWQPlv(int yhLHDZUnRQuVynB, int NlYqhnkKupzNM)
{
    string JmmQICLizhDFjod = string("nBvsjPRStplqypCRYPOwgpwwUnMwRFFCSpDMYDjDoPLCJSJdSSuQQviFgGRGtVpzEduolBZEQxLXcRQhoebdmzJAgBfNHQiaNBUozHyZXVmlgvWafgdphkTXsfrdYIsJKsnQKTpZNvSHVljaoXQYybIQuXNsnknzBfFBSXaVEYHKAjqUDMMVyjMZKCeQpQSIWpmsleVuhQFkCTqnuemkMRzXoR");
    int EDCqDBZd = 1356138796;
    int JDIrpHDprtr = 617004897;
    bool MIRuYqCIKF = false;
    string tgvaxAYlfw = string("iwVvXuOwBjYmUhAylzgmsWeVHjpgnFWnIRIqChZqTOatMIvuwtsIVSEJzZAHVXoNFFiGlOljxcDZDnQzL");
    bool dxfEPMCifvTUGzGp = false;
    bool zAxGdNJL = true;

    for (int laciUlpr = 1352230910; laciUlpr > 0; laciUlpr--) {
        NlYqhnkKupzNM /= NlYqhnkKupzNM;
        NlYqhnkKupzNM += NlYqhnkKupzNM;
    }

    return tgvaxAYlfw;
}

string LXNABGLoekpMOKeZ::yuugsjfz(bool vmWHSxcpSpJ)
{
    int srHgcimmNIMLVN = -267289619;
    double yyvhdtqMrSLl = 948659.5786467742;
    string uyjVwFaHwySknprg = string("eedEilgxrnfdpHqQLrUCzaPdpbDjdzktfiszwIuIJZylrHVhsMCOhBUcBPSzWMkOjSTQCdxmoYWLWMXHpXPUorBrlOYbeoqWIETfELUjWEoqZfnQUEjUoJeLcKREcAsViJBDXgeOSHibtaenuOJSNPphADYHBAUDXvDxUrNypNZaTQKrRkwKLOH");
    string SkjTJFuo = string("tTqhHIhvHlDSnLOjbhgYATMTMIvDzTSzoxLYoDvTqXFamLTwcHstEDwPiCPXeEyZcmqLBzbEBAmppAfmLhHJghdLNhaoXkTOkvcuxbQulLKyHzteoccnizPieCQRbzmQbJXqBNCXGvphHDnXlRgoqMUhaZUioqbMHhaF");
    string bYJHouChkr = string("PJYJwlgsvsdRZmMzprQJUiZgaBbDJjtaksNUWasUooYJXiINVbBrYwtsYspJeqWXkEnxcZIXMmVYefYJAFEqFuqqHQeJRxSfuxl");
    double swCIobHcxeioDl = 203597.809577827;

    for (int bfAECWemo = 1036104423; bfAECWemo > 0; bfAECWemo--) {
        continue;
    }

    return bYJHouChkr;
}

double LXNABGLoekpMOKeZ::rwLfUThgpTDL(string rVMMlSyapH, double GXNLmMViEMBbcp)
{
    bool ccraHcOg = false;
    int PbGAEaCvdFYaSbU = 1266909702;
    bool bYvvB = false;
    int DwVKVKrBiW = -2120832009;
    bool ECDyPPUqKdmq = true;

    for (int HAGlF = 1408899006; HAGlF > 0; HAGlF--) {
        ccraHcOg = bYvvB;
        PbGAEaCvdFYaSbU = PbGAEaCvdFYaSbU;
    }

    for (int PBvGOFe = 871301938; PBvGOFe > 0; PBvGOFe--) {
        continue;
    }

    return GXNLmMViEMBbcp;
}

bool LXNABGLoekpMOKeZ::uSfYvMA(string MYPIqdhG, int QYjNGVWvVWlrf)
{
    int rFmMUDU = -146416760;
    int TySZyFSLKMgP = -147238799;
    double trQabHoxmdRDcve = -933299.7511097126;
    int LZTIGZZJjVLX = -1209001115;
    int IqCmcKPSBtypS = -216822738;
    int BZkUdoNALjL = 1314329986;
    bool zkZKZvz = false;
    bool acQAvrfSOoK = false;
    double fHQJf = 264004.93600203755;

    for (int PmchhHnprZ = 565686199; PmchhHnprZ > 0; PmchhHnprZ--) {
        continue;
    }

    if (BZkUdoNALjL >= -1209001115) {
        for (int gCyUtXML = 1019273477; gCyUtXML > 0; gCyUtXML--) {
            continue;
        }
    }

    return acQAvrfSOoK;
}

LXNABGLoekpMOKeZ::LXNABGLoekpMOKeZ()
{
    this->qCnLl(100478612);
    this->UcpcDU(168306931, 2062876205);
    this->BpFAVllQoktph();
    this->lciFwT(false, string("OkMetTeBQwoHUmzjXnvjCKtQACwgfcnZKzNdGurPLwwcnZOBizDZcPfqsHHFtgXOrAYZmvOcwzTJfwqSnJdThLVQcoPLweiTMlVrvMyNvdwPwcACMGTBQMzfADzYODRoXBCOhkRUiMqRyysUCyoHBAPfpgPTahuUxATXRwfswLOeajhUWqYUPvlIpBZSspjNXVEsDKrIUWYxhPHgyfShatN"));
    this->zOEyzuKKoYFB();
    this->wxLYsUQPLYTICQOP(false, -313543.06580038596, true);
    this->vyZotBUSfiWQPlv(357852867, 1219220102);
    this->yuugsjfz(false);
    this->rwLfUThgpTDL(string("FvrNRZHuKdtzMVkuEBmFzBudyMrREudJeaTosIRJkMTQGvXPzRAdjZnoZGszRgWLiNTdqWIfNcUiYovdzMWQCPRlnMYAhsroPRNEyAWnZsCNlTnlghPvwydaloPzAcflopkXFXihrMPJUyVuPxBXzEFDbqKOVNWjfqvwoaCcSkpTBUzziKgdbTwVtTdNkdwpCnlOObgCxAuIsuAmwFJMcYLmAnrHbEKRpJUYNFxUbrRCCJsCDfnwA"), -374657.55976302444);
    this->uSfYvMA(string("CuavPyLvsIOgiIPVfBmvQhbKwgrsBLVfqBpyBOJGoaHCIchVOpDelYaREGEssKZFERBTlDDXDAbDUleCZCuVdWHgrZgAmaeeGcDwpiZbnparPFuI"), 434982117);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JIzQwjCviog
{
public:
    string ENCYTjQidMOs;
    double JNoKl;
    int mTrrOdgHNLQQ;
    bool EzqmsKZOZBlHrmcL;
    string QgqyxZo;

    JIzQwjCviog();
    bool qXDMYkEdYbnV(double oRtGTRerslSiV, string ujjrgjEd, bool LoTQL);
    double GKcatNdQTDnPeOy(double GyLJnQdojnMgRFUg, string QpdQuN, double WEHyZbAAHi, string lDWddg);
protected:
    string kfgTAaKmpRIw;

    int wNcYjdmLrGMptAE();
    int aiRPd(bool drumkGVp, int KRtJSfvXn, bool rtvYLzYcQlx, bool oejZmV, string GBDWzwVFyRbHHC);
    double VYsmMTKVrOtNT(string SLIrseaVNLypnreY, double FTybSKRC, int YVkbm, double TPuJBzVquN);
private:
    bool FNyPaEAdioMIngIK;
    int piDXeuvVv;
    int xheFP;
    int TVLErmBlbtgTP;
    int hxKJtJ;

    void OCZXeSrHmNlTYbJg();
    string KoIqiXeJ();
};

bool JIzQwjCviog::qXDMYkEdYbnV(double oRtGTRerslSiV, string ujjrgjEd, bool LoTQL)
{
    string SDcTFyfdl = string("htpRblgjMnfHRQTQYMdszXgDSYKIUKKvxBaokAErzrHNDGjiKavJkeowLJDMkcljvYIewBIjejkdTFFMeTqNQyTlJxbFmzizyowqIXgIOpxRhNXyteRwgnrKFpOWrMVoGcEPLguPUWlsnUjZXwOeNnPIEvGCFozYCTOtGDLSvuyZFMxhbldDPuziPHtDDphwqVTfOHJLRMVAMyUkkEDMbvDiSYeBlirCtMZZkgBYxdAYeitrIlvTVy");
    string rplbZVynsKoauU = string("mvIVJJFpnTrAjTixCnOAgQTnAdgnECswZbpqWsvMnbGWAdoDYwYmRxreOgdoKixEWlPsRBCxVaWXGpEEIdXMPUeNZKldoLEBjaZHrkLPvlpXuDcixwjahZXzZmyOiCAOTOPqBvfGOMs");
    int MQSZXTKVlCXHIps = 597313280;
    string uVLzvyWhRI = string("oHEoapeRhzBpciWWhtLXDEvqUurVBmJWzpJKwUAlfMdDGZYTFbTwexxeVGdNdWzGoWPgDGPOxioozLsgHuVbTmRJhOFowWSvQZEpEjrjeZjAEGmiChBNixODfCamirlxaPmabgufPgtllwDoccyyxUWZTfRCoSoOdhCfrALhUPmBdXnIlmFRZDQyofIfzDCSUYgFXViaDKWXipACA");
    double oijSVZhTAxZA = -219708.67351233726;

    if (rplbZVynsKoauU == string("htpRblgjMnfHRQTQYMdszXgDSYKIUKKvxBaokAErzrHNDGjiKavJkeowLJDMkcljvYIewBIjejkdTFFMeTqNQyTlJxbFmzizyowqIXgIOpxRhNXyteRwgnrKFpOWrMVoGcEPLguPUWlsnUjZXwOeNnPIEvGCFozYCTOtGDLSvuyZFMxhbldDPuziPHtDDphwqVTfOHJLRMVAMyUkkEDMbvDiSYeBlirCtMZZkgBYxdAYeitrIlvTVy")) {
        for (int gdWghsjSA = 232306262; gdWghsjSA > 0; gdWghsjSA--) {
            SDcTFyfdl += uVLzvyWhRI;
            uVLzvyWhRI = SDcTFyfdl;
        }
    }

    if (SDcTFyfdl >= string("htpRblgjMnfHRQTQYMdszXgDSYKIUKKvxBaokAErzrHNDGjiKavJkeowLJDMkcljvYIewBIjejkdTFFMeTqNQyTlJxbFmzizyowqIXgIOpxRhNXyteRwgnrKFpOWrMVoGcEPLguPUWlsnUjZXwOeNnPIEvGCFozYCTOtGDLSvuyZFMxhbldDPuziPHtDDphwqVTfOHJLRMVAMyUkkEDMbvDiSYeBlirCtMZZkgBYxdAYeitrIlvTVy")) {
        for (int yvLzXoehnDXXI = 539987170; yvLzXoehnDXXI > 0; yvLzXoehnDXXI--) {
            SDcTFyfdl += ujjrgjEd;
            rplbZVynsKoauU = SDcTFyfdl;
            rplbZVynsKoauU += rplbZVynsKoauU;
        }
    }

    return LoTQL;
}

double JIzQwjCviog::GKcatNdQTDnPeOy(double GyLJnQdojnMgRFUg, string QpdQuN, double WEHyZbAAHi, string lDWddg)
{
    int WHZDdaMByZLmqXey = -681387223;
    bool naHpHCk = true;
    int vssoqDrZXhhR = 177060978;
    bool kdgIEa = true;
    string ZjVHci = string("JqjGrQubFRbFIsJhJOVGklCBRNtUnfscSdtOiDlNUbRTZaHrkILEstmLWacjvlmKIrZnLREOwpnBLokhULyhcYe");
    string pzQEVJf = string("QCbVFMwGpGMEbEdwrUqMlFBRLWLJmwXvupaArwLDEDgauIjQgXEIPfuwHGEKgUvIuHeVImLqUCdkghSfmzTpkIqYIHsFJLJolnaavEMYGnEQTsisvDPvHd");
    string zMfKZzWyskhAy = string("XawFwnIftBSlYsmUCpRJqabGAZdiZQGUFEFGOfcsAPGMTYqkIkPmFpjkCZiXoPpVgYtTfyYoiuMgfYvBLfGOitlRmBRRVPAdvQBbRLUnRAGCsiapzmwbkhcRjZiTjI");
    double KSlcjpNxIX = 805170.9004351174;
    double rzDsi = -1038661.9959953694;

    if (WEHyZbAAHi >= -1038661.9959953694) {
        for (int oYoVffZUSpq = 1425355379; oYoVffZUSpq > 0; oYoVffZUSpq--) {
            pzQEVJf = ZjVHci;
        }
    }

    return rzDsi;
}

int JIzQwjCviog::wNcYjdmLrGMptAE()
{
    bool jRFyPouWdb = false;
    int aKJSSLtuCM = 1052767224;
    double TWiaFUhSclURPcX = -953824.2954077102;
    string SorwMHyBo = string("PIdJWQCyMOoPkF");
    bool vYsharOsx = false;
    bool OSBlpsNEJYPHVKiA = false;

    for (int xCDzDkRmpW = 716836816; xCDzDkRmpW > 0; xCDzDkRmpW--) {
        TWiaFUhSclURPcX /= TWiaFUhSclURPcX;
    }

    for (int HtdFwuPr = 428121103; HtdFwuPr > 0; HtdFwuPr--) {
        jRFyPouWdb = ! OSBlpsNEJYPHVKiA;
    }

    return aKJSSLtuCM;
}

int JIzQwjCviog::aiRPd(bool drumkGVp, int KRtJSfvXn, bool rtvYLzYcQlx, bool oejZmV, string GBDWzwVFyRbHHC)
{
    int ruQGXuPk = 324763581;
    int QkuVZLbNtszpSKm = -1914852466;
    bool XojaRMlOQTY = true;
    double QWeQbWkxcU = 158629.5935701126;

    for (int okSzbTmQbQZBKp = 403068997; okSzbTmQbQZBKp > 0; okSzbTmQbQZBKp--) {
        rtvYLzYcQlx = ! XojaRMlOQTY;
        QWeQbWkxcU += QWeQbWkxcU;
    }

    for (int OoWlRYmDFrJzvPQS = 130267954; OoWlRYmDFrJzvPQS > 0; OoWlRYmDFrJzvPQS--) {
        ruQGXuPk -= ruQGXuPk;
        KRtJSfvXn /= ruQGXuPk;
        rtvYLzYcQlx = XojaRMlOQTY;
        rtvYLzYcQlx = drumkGVp;
    }

    if (GBDWzwVFyRbHHC >= string("pKABboRJBqXbBTXIgAjdBLlVIrzoIiBxhRaZKeuawTWBBijLUkZdRSFtgADvOftbWLfDzvBIWMwlxHKHZsxoTdJeekcudnDiZnWVjkWupEuEvMepQnsnAnOGrjWsNGyJgEuMGwWxsDVCONaDEaipUYOmZIFiIcpEDBciNjjtKcUAcoHhvzaRpLRExomDJMMMTRnrUSgZawxjnGtqfwXPgzcdvbaXhxSHD")) {
        for (int KaXQoyTSRSTwUqgw = 162630841; KaXQoyTSRSTwUqgw > 0; KaXQoyTSRSTwUqgw--) {
            oejZmV = ! oejZmV;
            QkuVZLbNtszpSKm /= ruQGXuPk;
        }
    }

    return QkuVZLbNtszpSKm;
}

double JIzQwjCviog::VYsmMTKVrOtNT(string SLIrseaVNLypnreY, double FTybSKRC, int YVkbm, double TPuJBzVquN)
{
    bool JzeooTalFMLIH = true;
    int CrYBL = 895844654;
    string dlqKjDC = string("wSSIOOlgvVOETUPUvvrOlZalQRRVsCiAOVmlZIEjBGFpYvSNQJkuqDKHgZRakEGjhEPvkjkZuHEfwyGfWxkoAUqFwtPkgODpCRPYdfTOmUIfbAdKlRPtrKbGYTXAUbqaSBOAkezScEbyfBUIixpvmZooZwNFDSGCTCcscHcOHTf");
    int xGxijNfF = -865317832;

    if (xGxijNfF != -644641895) {
        for (int DnmEkzQIVoXEeCl = 178215012; DnmEkzQIVoXEeCl > 0; DnmEkzQIVoXEeCl--) {
            SLIrseaVNLypnreY += dlqKjDC;
        }
    }

    for (int uSfbulKqO = 1402866387; uSfbulKqO > 0; uSfbulKqO--) {
        CrYBL /= xGxijNfF;
    }

    return TPuJBzVquN;
}

void JIzQwjCviog::OCZXeSrHmNlTYbJg()
{
    double EPtqsjGq = 818637.9364563008;
    string zBJAlRhYa = string("AHWJIFRxGPETSIrFlcFCMCBBGEsUIvKHSgTFlZsJElOVDJobfxFowGaOFKkohpjyQuwSuuQCgTNocKMSmlGWeRnJVkRGaIZQxiriPAquZoPagoeNbrTTkUmEBCSvuFEvEOHie");
    bool qkvqZoRAO = true;

    for (int TpBqzyYjHNuLRk = 1685171319; TpBqzyYjHNuLRk > 0; TpBqzyYjHNuLRk--) {
        EPtqsjGq += EPtqsjGq;
        qkvqZoRAO = qkvqZoRAO;
    }

    if (zBJAlRhYa < string("AHWJIFRxGPETSIrFlcFCMCBBGEsUIvKHSgTFlZsJElOVDJobfxFowGaOFKkohpjyQuwSuuQCgTNocKMSmlGWeRnJVkRGaIZQxiriPAquZoPagoeNbrTTkUmEBCSvuFEvEOHie")) {
        for (int YlrIGAvfvTSWAZNi = 1724523359; YlrIGAvfvTSWAZNi > 0; YlrIGAvfvTSWAZNi--) {
            zBJAlRhYa += zBJAlRhYa;
        }
    }

    for (int gMVJlb = 1409621867; gMVJlb > 0; gMVJlb--) {
        qkvqZoRAO = qkvqZoRAO;
        zBJAlRhYa += zBJAlRhYa;
        zBJAlRhYa += zBJAlRhYa;
    }

    for (int SlQHbI = 50621570; SlQHbI > 0; SlQHbI--) {
        qkvqZoRAO = ! qkvqZoRAO;
        zBJAlRhYa = zBJAlRhYa;
        qkvqZoRAO = ! qkvqZoRAO;
        EPtqsjGq -= EPtqsjGq;
        EPtqsjGq = EPtqsjGq;
        zBJAlRhYa = zBJAlRhYa;
        EPtqsjGq /= EPtqsjGq;
    }

    if (zBJAlRhYa == string("AHWJIFRxGPETSIrFlcFCMCBBGEsUIvKHSgTFlZsJElOVDJobfxFowGaOFKkohpjyQuwSuuQCgTNocKMSmlGWeRnJVkRGaIZQxiriPAquZoPagoeNbrTTkUmEBCSvuFEvEOHie")) {
        for (int rrwSRktYsQAmGpf = 1427071230; rrwSRktYsQAmGpf > 0; rrwSRktYsQAmGpf--) {
            continue;
        }
    }

    for (int enlSGySimhQ = 1268685137; enlSGySimhQ > 0; enlSGySimhQ--) {
        EPtqsjGq += EPtqsjGq;
        zBJAlRhYa += zBJAlRhYa;
    }
}

string JIzQwjCviog::KoIqiXeJ()
{
    double ugbpeulalGFtTeh = 786928.5540327614;
    int HsauOerDHJTZgiNe = -676203698;
    double eUGHDdJKqgq = 626549.7254839186;
    double hIcJddlZ = 341748.3293539573;
    int cJVCcs = -156195414;
    string LAnmPtdoDhw = string("lneIlaFaWCpXCjffsLVUDRGPgPaUvUIWIKwnfJmqGnRkpXVytOUpDfqVtZBNxMOGFSvqDIjIwBSPLGAdSxlhwcOhYXEJRTcoTkSeLCNXFiiewqNNHYVJOyDafIKneBFKaqSgUo");
    bool igWUPFbEI = true;

    for (int MGjakqbZpiUon = 1010902277; MGjakqbZpiUon > 0; MGjakqbZpiUon--) {
        eUGHDdJKqgq -= eUGHDdJKqgq;
        eUGHDdJKqgq -= hIcJddlZ;
        igWUPFbEI = ! igWUPFbEI;
        LAnmPtdoDhw += LAnmPtdoDhw;
    }

    for (int AJofrPiyCpzljj = 1013650390; AJofrPiyCpzljj > 0; AJofrPiyCpzljj--) {
        cJVCcs -= HsauOerDHJTZgiNe;
    }

    for (int pNhtghZydBMhbhTx = 1656616733; pNhtghZydBMhbhTx > 0; pNhtghZydBMhbhTx--) {
        eUGHDdJKqgq /= hIcJddlZ;
    }

    return LAnmPtdoDhw;
}

JIzQwjCviog::JIzQwjCviog()
{
    this->qXDMYkEdYbnV(745193.7816310937, string("MmfpPivfUmCEmRdGQQOSkiNNxHsKDHKIgv"), true);
    this->GKcatNdQTDnPeOy(-928379.6728678641, string("fGkPXuFcPSmFwxwqPEowRWoRmNjZSfzqJoFeKYbRWjWVxnzYYKoGosMyIhHmEIwhDwgxlgdWqbHXvxOkeigRNTAbqsOZtJYkgEIUXbkRPeZRElvcYRHUUIYgeVwEjTXlqnJJPXJuVMZzdcUWEqMMMFXwaVrLoiwvXluxzHlXGmMuhQOJViuZQhsLrSUXkabObsVWexrP"), -236545.1701554264, string("AtXCIaMgitmKGhYYFUTOFhVHImFROwjDcshXhQgGDJZSiSIGmyUKWtITeiAS"));
    this->wNcYjdmLrGMptAE();
    this->aiRPd(false, -1880237992, false, true, string("pKABboRJBqXbBTXIgAjdBLlVIrzoIiBxhRaZKeuawTWBBijLUkZdRSFtgADvOftbWLfDzvBIWMwlxHKHZsxoTdJeekcudnDiZnWVjkWupEuEvMepQnsnAnOGrjWsNGyJgEuMGwWxsDVCONaDEaipUYOmZIFiIcpEDBciNjjtKcUAcoHhvzaRpLRExomDJMMMTRnrUSgZawxjnGtqfwXPgzcdvbaXhxSHD"));
    this->VYsmMTKVrOtNT(string("hXaKGffuEsDuMZnCQDFEjJznFchfDOEeMTfToUESPKZXkleynIIhivJIZvNSyoWkxNOZ"), 595131.7870108165, -644641895, 139676.19765268246);
    this->OCZXeSrHmNlTYbJg();
    this->KoIqiXeJ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HbzEwRn
{
public:
    bool xZmEUTElEMytzCb;
    string fyYSVWHmYrR;
    double OWYmBLf;
    int kIMYJKKbhTq;
    double jsERVUxAFxWFre;
    bool yhKIaEkuKuhVgm;

    HbzEwRn();
protected:
    bool kgbnw;
    double oVKIJqfNNBipJdAT;
    double STsRatBmTVfeW;
    double yMMGCbIusl;

    void JsNXJRXSmtBMPz(bool ENPKpDOMN, string OAPTivjirsrivH);
    void iRdOXwnYvyaDpQuG(int qNdqrgTvNpzWuBc, double FHVBAjJdGfXV, bool xBcEf);
    double HSNSaCavnObkaKy(int VFquPkCUZV);
    double csbeHxb(int VYBgsUKM, string sbUpNHmLzWwTxI);
private:
    double WsUYMfeAL;

    double hGHRoMx();
};

void HbzEwRn::JsNXJRXSmtBMPz(bool ENPKpDOMN, string OAPTivjirsrivH)
{
    double LbxsMwT = -1024902.2817627859;
    double BfTucVg = 58875.52827820562;
    int daWMSquHdamSoR = -1032451836;
    string JMSFKzC = string("txwpawJSlpkWgKHyrAUEYjFibZwjvighbtABLqhArYiefgBllWgIzdZNQseizkrqJpnTtDWibyylHZOMJJqsQoALIWeFgLBwIjrBGESZDuBosgubPjNkvUvmaxTCgrolbMUSqAbgxfDzlsTbnBPIdvgHmnmiHcTLJvzvUNaIbRLndpJYBlJfAfoPWFLLrGbaBbFtQiWHcQUrqqIGcC");
    int THrqBd = -1178811712;

    for (int EDUkIA = 154032417; EDUkIA > 0; EDUkIA--) {
        continue;
    }

    for (int emHVCOatlFmCX = 519455562; emHVCOatlFmCX > 0; emHVCOatlFmCX--) {
        BfTucVg = BfTucVg;
    }

    if (THrqBd >= -1178811712) {
        for (int rhZEw = 1609289648; rhZEw > 0; rhZEw--) {
            daWMSquHdamSoR += THrqBd;
            ENPKpDOMN = ENPKpDOMN;
        }
    }
}

void HbzEwRn::iRdOXwnYvyaDpQuG(int qNdqrgTvNpzWuBc, double FHVBAjJdGfXV, bool xBcEf)
{
    bool bfhLPrP = false;
    double LalyTlkErzkgcCFr = -1011987.318194425;
    bool sOsPJLoK = false;
    int ZAnWbGTLfFhxx = -1182841766;
    string IuGTEpuHkUUfwn = string("hWBwkSbitpqGnzJKqDQYpyilkNWnEORsGuHGgwXGihCLNwsnsdqAnwDBpTvnBRYBnlhiVgvidRcTuVEnLsIVfPPvVebLnSXNeteVwxTPuLUyQzNxldCuBkwvrlcmMxeOmsooEFgoqZuTSTBssVqGigUfaeCNBbIKNTlstuoCVuqhffMLRTrDsgufXmtQzOihMNAGKfarJfTXzQQsLEqLuAFnHmqJxWnRrCIdKyyyfRRl");
    double domio = 970403.0719108104;
    bool aOSghW = false;
    double MvWIee = -446150.2013823172;
    int vVIHKeZ = 212429106;
    bool DzpcGOPBlUtZoX = false;

    if (MvWIee == 970403.0719108104) {
        for (int PXpwmwzSCWD = 1322625053; PXpwmwzSCWD > 0; PXpwmwzSCWD--) {
            DzpcGOPBlUtZoX = DzpcGOPBlUtZoX;
            LalyTlkErzkgcCFr = domio;
            FHVBAjJdGfXV -= LalyTlkErzkgcCFr;
            DzpcGOPBlUtZoX = xBcEf;
        }
    }

    for (int yNhFZeYeQAfGRlx = 1483970571; yNhFZeYeQAfGRlx > 0; yNhFZeYeQAfGRlx--) {
        FHVBAjJdGfXV /= FHVBAjJdGfXV;
    }

    if (LalyTlkErzkgcCFr == 970403.0719108104) {
        for (int HzMvYDcBpGpFE = 1372617229; HzMvYDcBpGpFE > 0; HzMvYDcBpGpFE--) {
            domio /= domio;
            sOsPJLoK = ! DzpcGOPBlUtZoX;
            LalyTlkErzkgcCFr += LalyTlkErzkgcCFr;
        }
    }

    for (int WouWIKrspEFygU = 1655583529; WouWIKrspEFygU > 0; WouWIKrspEFygU--) {
        continue;
    }

    if (xBcEf == false) {
        for (int DLufvz = 1729902478; DLufvz > 0; DLufvz--) {
            sOsPJLoK = ! aOSghW;
        }
    }
}

double HbzEwRn::HSNSaCavnObkaKy(int VFquPkCUZV)
{
    string BxTip = string("OxhWYztAjesGDJCiwzdRqbIMzKGaVQVODqNdmrjmTcKuUeerImgvLEYGKvuzBFJNJnDiqOClgZEkjRIaffgghuPquDPBDJbdIUsxdxXxTOxsQKjkzxfYOhcTOYUsMjtNTDlgjdMIvkZlmzkQmdjMBJAFKvMUCjcTAJwYUFoDdPcsKqDfowfjlbY");
    string zeRgwOyjZO = string("TNFCoFvMNVSkCYfjOYSEnNRlyhfdAsJQlXutytIEyGpZPubXeOdofiRQKoKDmkgMMmUjdgadyTjdHfavvkOUWyAPOuvEfAPlRZmcDGZPsHwZKdYYXrHYiOVu");
    double PjNBHcNzr = 457269.1845408094;
    bool flAqbqpjnojMC = false;

    for (int rOQbJhPaSJQdKJp = 1260086507; rOQbJhPaSJQdKJp > 0; rOQbJhPaSJQdKJp--) {
        zeRgwOyjZO += BxTip;
    }

    if (zeRgwOyjZO != string("OxhWYztAjesGDJCiwzdRqbIMzKGaVQVODqNdmrjmTcKuUeerImgvLEYGKvuzBFJNJnDiqOClgZEkjRIaffgghuPquDPBDJbdIUsxdxXxTOxsQKjkzxfYOhcTOYUsMjtNTDlgjdMIvkZlmzkQmdjMBJAFKvMUCjcTAJwYUFoDdPcsKqDfowfjlbY")) {
        for (int RkOJFYDobyDjqd = 1814024434; RkOJFYDobyDjqd > 0; RkOJFYDobyDjqd--) {
            PjNBHcNzr -= PjNBHcNzr;
        }
    }

    for (int WFNUi = 1441884397; WFNUi > 0; WFNUi--) {
        BxTip += BxTip;
    }

    if (PjNBHcNzr < 457269.1845408094) {
        for (int nepLkGnTmY = 726579334; nepLkGnTmY > 0; nepLkGnTmY--) {
            BxTip = zeRgwOyjZO;
            PjNBHcNzr -= PjNBHcNzr;
            BxTip = BxTip;
        }
    }

    if (zeRgwOyjZO > string("TNFCoFvMNVSkCYfjOYSEnNRlyhfdAsJQlXutytIEyGpZPubXeOdofiRQKoKDmkgMMmUjdgadyTjdHfavvkOUWyAPOuvEfAPlRZmcDGZPsHwZKdYYXrHYiOVu")) {
        for (int iVVlJE = 454599222; iVVlJE > 0; iVVlJE--) {
            BxTip += BxTip;
            PjNBHcNzr /= PjNBHcNzr;
        }
    }

    return PjNBHcNzr;
}

double HbzEwRn::csbeHxb(int VYBgsUKM, string sbUpNHmLzWwTxI)
{
    string dfuHoB = string("IgnAvktdaRXpPwhpSHTNpNQEkKMCAbpwdSGYCSuLlyqjAQuAWlizcsPzUKcseNwajBHBlNNJsvxyMCFgDnmaeqTczPZHGFhemEHqfeMHhJiCXtXmidVYNMwYlFReQjLKHpzgPEdYzXIezYTOZdyXFMWpzhsGfinFtTXagkswgZoKpcguJcHPFRZLJPZyEdmHcnYRiMGpMzdhijpHAjosTEMCt");
    double xEDOOeZlO = -128938.14313699865;
    string nreeLOsHodzBRnu = string("EERSFHsNRCjuwZrJneRanCuWmXibkhlBCxOCoiYFpQvfmyoTswBMnloHQzengBickxBOJUahbiBjzIIHDTaLveeAPQFICzGOTLeJShpDPqrhGpWLKNOMwXLGmPMUZOUMhxhvuqCHzvFscmsmMZaMwswsFCCLiZxMrcNMGIsnL");

    return xEDOOeZlO;
}

double HbzEwRn::hGHRoMx()
{
    double OxcrYsJkqHFP = -740055.6842199716;
    bool EFNKhodJUyEWA = false;

    if (OxcrYsJkqHFP != -740055.6842199716) {
        for (int iQMNo = 1468563778; iQMNo > 0; iQMNo--) {
            OxcrYsJkqHFP += OxcrYsJkqHFP;
            OxcrYsJkqHFP += OxcrYsJkqHFP;
            EFNKhodJUyEWA = ! EFNKhodJUyEWA;
            OxcrYsJkqHFP -= OxcrYsJkqHFP;
            EFNKhodJUyEWA = ! EFNKhodJUyEWA;
        }
    }

    if (EFNKhodJUyEWA != false) {
        for (int IXQpTCUpYwIHs = 987330679; IXQpTCUpYwIHs > 0; IXQpTCUpYwIHs--) {
            EFNKhodJUyEWA = ! EFNKhodJUyEWA;
            EFNKhodJUyEWA = EFNKhodJUyEWA;
            OxcrYsJkqHFP = OxcrYsJkqHFP;
        }
    }

    if (OxcrYsJkqHFP != -740055.6842199716) {
        for (int ZnxlE = 447950764; ZnxlE > 0; ZnxlE--) {
            OxcrYsJkqHFP += OxcrYsJkqHFP;
            OxcrYsJkqHFP -= OxcrYsJkqHFP;
            OxcrYsJkqHFP *= OxcrYsJkqHFP;
            EFNKhodJUyEWA = ! EFNKhodJUyEWA;
            OxcrYsJkqHFP /= OxcrYsJkqHFP;
        }
    }

    for (int cXWtsaywxrtDweo = 939206675; cXWtsaywxrtDweo > 0; cXWtsaywxrtDweo--) {
        OxcrYsJkqHFP /= OxcrYsJkqHFP;
        EFNKhodJUyEWA = ! EFNKhodJUyEWA;
        EFNKhodJUyEWA = ! EFNKhodJUyEWA;
        OxcrYsJkqHFP += OxcrYsJkqHFP;
        EFNKhodJUyEWA = ! EFNKhodJUyEWA;
        OxcrYsJkqHFP -= OxcrYsJkqHFP;
    }

    return OxcrYsJkqHFP;
}

HbzEwRn::HbzEwRn()
{
    this->JsNXJRXSmtBMPz(true, string("QrLWwBucOQtYiyXbNJDhLDWguq"));
    this->iRdOXwnYvyaDpQuG(506812572, 205250.825680078, false);
    this->HSNSaCavnObkaKy(-1136209251);
    this->csbeHxb(-630818270, string("LfhwTKWNBcRBPrSFAJaFakJwdLnsJlonsHbGMaTwCtgjCpxHZPrwblyutWcRQh"));
    this->hGHRoMx();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class STgeYLgC
{
public:
    string wRMwGcJMODTLWKZC;

    STgeYLgC();
    double JMNBBWMpvHLnF();
    int DVzBEeIbkt();
    double PFHRILiIeaQ(int GxaqIRMIXakCh);
protected:
    int wBumAxpSUKMbNrW;
    bool EmFKxBdW;
    int QoRHQpfbjhtbQZ;

    double wgECQJprPIQrle(double GWNmomte, int RDqinfhlngwrZQjd, bool JsEYpR, string AtcCHrcHP, int ktxonJulUxSGUIVH);
    string nSCNGuu(double gtGXcDJSopGL, double ieuJTrLEe, bool Ivycl, string SRBCudSLDgirtTcv);
private:
    int pbPJWdusHdIF;
    string BopcbxLt;
    double YvbxdSjXQOSKu;
    bool MZRgkAGLw;

    bool gJVoSmq(int GAOFMefaCvKRoE, bool GzGJGQ, double uOOiCvLvxYPwsI, double jWCwpXNsW);
    void zAHWVQxC(bool zcpcT);
    bool CZtFbqGTUgfaX(double YQTDCwfLsVAuP, string fixyUWHBgzgRCKa);
    string EMObmhUTg(int dDQmSYIH, int FZIxTpnCUGFBmWL, string yVzaaXyBFeorjMs, int bvXqYFAmZEDUCUlX);
    void wcFluBOOJVf();
    string YrEjksXqdBQ();
    string LgkZDyNLVABLNYf(bool zrorapO, double UkoZmDLjkgBiaOqW, int kkFFmkevzlyIOjJ);
    int pyvAbH(bool ZpnTURkOzSv, bool IBVkaSjWp);
};

double STgeYLgC::JMNBBWMpvHLnF()
{
    string tarCXbiogzNdXx = string("wcSnMjnxxzGkVlXcqTVjdEjupUDMmSGgeIuiGWYtEzNJGODbowytxGeeafyodkmrjxcyjyrMzRwrrCtxDaJaFCOhheMvqJIUYaxWvLnXFbjFOPLkjikVTnAOxKBMkycBKZBOA");
    double TNiIjTOjeRS = -670063.1249253856;
    double jAuTDq = -492051.8268838067;
    double FWBYBoBzbsBLCTSZ = -673833.9958542138;
    double hFxfUKKv = 749570.7273910117;
    bool uVwAYMOE = false;

    if (hFxfUKKv > 749570.7273910117) {
        for (int fcIWiY = 731402261; fcIWiY > 0; fcIWiY--) {
            hFxfUKKv = jAuTDq;
            jAuTDq /= hFxfUKKv;
            jAuTDq = jAuTDq;
            uVwAYMOE = ! uVwAYMOE;
        }
    }

    for (int oMFnnPIRDpxib = 171138298; oMFnnPIRDpxib > 0; oMFnnPIRDpxib--) {
        FWBYBoBzbsBLCTSZ *= TNiIjTOjeRS;
        FWBYBoBzbsBLCTSZ -= hFxfUKKv;
        FWBYBoBzbsBLCTSZ -= TNiIjTOjeRS;
    }

    return hFxfUKKv;
}

int STgeYLgC::DVzBEeIbkt()
{
    double cbgVLCGq = 594909.9089873914;
    bool VQdCCOx = false;

    if (VQdCCOx != false) {
        for (int kLsgvmVUHfE = 1115039270; kLsgvmVUHfE > 0; kLsgvmVUHfE--) {
            VQdCCOx = ! VQdCCOx;
            VQdCCOx = VQdCCOx;
        }
    }

    if (cbgVLCGq > 594909.9089873914) {
        for (int aVnYxwIAdUBx = 125100210; aVnYxwIAdUBx > 0; aVnYxwIAdUBx--) {
            VQdCCOx = ! VQdCCOx;
        }
    }

    for (int PTqWBMNYawWlQqOV = 597571597; PTqWBMNYawWlQqOV > 0; PTqWBMNYawWlQqOV--) {
        VQdCCOx = ! VQdCCOx;
    }

    for (int CUfPpvlPQke = 1465650016; CUfPpvlPQke > 0; CUfPpvlPQke--) {
        VQdCCOx = VQdCCOx;
        cbgVLCGq = cbgVLCGq;
        VQdCCOx = ! VQdCCOx;
        cbgVLCGq += cbgVLCGq;
        VQdCCOx = VQdCCOx;
    }

    return -1592956316;
}

double STgeYLgC::PFHRILiIeaQ(int GxaqIRMIXakCh)
{
    bool WpXifdC = true;
    double kwjmQrz = -141027.77078876557;
    int WYirYeKlkh = -1159178182;
    int aXWqIexrDN = 975428848;
    bool GDqXtijtrhJwf = true;
    bool VBKyQWWKhyWosNM = true;
    double mYMUSgpChVGeFPXZ = 913533.8097082935;
    bool AkcKzhEDf = true;
    int PMWoiO = 701207549;

    if (GDqXtijtrhJwf != true) {
        for (int EIsbbP = 959307153; EIsbbP > 0; EIsbbP--) {
            PMWoiO /= WYirYeKlkh;
            aXWqIexrDN += GxaqIRMIXakCh;
            WpXifdC = VBKyQWWKhyWosNM;
        }
    }

    for (int RUfWNh = 79437283; RUfWNh > 0; RUfWNh--) {
        WpXifdC = ! GDqXtijtrhJwf;
        AkcKzhEDf = GDqXtijtrhJwf;
        PMWoiO /= aXWqIexrDN;
    }

    for (int ZyuijFpWRv = 981876760; ZyuijFpWRv > 0; ZyuijFpWRv--) {
        GxaqIRMIXakCh *= WYirYeKlkh;
        WpXifdC = ! GDqXtijtrhJwf;
    }

    return mYMUSgpChVGeFPXZ;
}

double STgeYLgC::wgECQJprPIQrle(double GWNmomte, int RDqinfhlngwrZQjd, bool JsEYpR, string AtcCHrcHP, int ktxonJulUxSGUIVH)
{
    int TuWoJ = 784453351;
    bool nVUZOenjhjgD = false;
    double RvGPhPIcZIhY = 793063.6631000456;
    int dyOalbsGqpOZ = -581394856;
    bool qcSZJHgQm = true;
    bool fdNWLXvEk = true;

    if (qcSZJHgQm != true) {
        for (int QCjPk = 360290065; QCjPk > 0; QCjPk--) {
            TuWoJ *= ktxonJulUxSGUIVH;
        }
    }

    if (JsEYpR != false) {
        for (int NPShYRMjbNkZPSai = 1482992445; NPShYRMjbNkZPSai > 0; NPShYRMjbNkZPSai--) {
            continue;
        }
    }

    for (int EinyAquKkN = 295081088; EinyAquKkN > 0; EinyAquKkN--) {
        nVUZOenjhjgD = ! fdNWLXvEk;
        RDqinfhlngwrZQjd *= dyOalbsGqpOZ;
        GWNmomte *= RvGPhPIcZIhY;
        fdNWLXvEk = ! JsEYpR;
    }

    for (int uthrmdLUhuJKkA = 334699229; uthrmdLUhuJKkA > 0; uthrmdLUhuJKkA--) {
        nVUZOenjhjgD = fdNWLXvEk;
        qcSZJHgQm = JsEYpR;
        TuWoJ -= ktxonJulUxSGUIVH;
        nVUZOenjhjgD = ! JsEYpR;
    }

    if (fdNWLXvEk != true) {
        for (int FmgOHnENa = 326170824; FmgOHnENa > 0; FmgOHnENa--) {
            continue;
        }
    }

    return RvGPhPIcZIhY;
}

string STgeYLgC::nSCNGuu(double gtGXcDJSopGL, double ieuJTrLEe, bool Ivycl, string SRBCudSLDgirtTcv)
{
    string csAkDAdMSQN = string("jOzzbfbifcEyLCTDADfaQLzAjzpDxuIXMZQwlIojvvCMnicInfwQexNtNTRjKCKgFcfIoIUiGJvkMDslegYVYskqkkHoopdkkfiIcmhDUtUHxwcxaTNJOhKcJAicDAJzCqCxCAclcklpwHdzoclt");
    bool vpnEbUeACoRTl = false;
    bool mHgDwdJhpgoYAtZ = true;
    bool qEwyEpweUCYVKHW = true;

    for (int wDAqAtOQI = 1110151846; wDAqAtOQI > 0; wDAqAtOQI--) {
        ieuJTrLEe -= gtGXcDJSopGL;
        SRBCudSLDgirtTcv += SRBCudSLDgirtTcv;
        vpnEbUeACoRTl = ! vpnEbUeACoRTl;
    }

    if (Ivycl != false) {
        for (int XWOesaPRFii = 1129663952; XWOesaPRFii > 0; XWOesaPRFii--) {
            csAkDAdMSQN = csAkDAdMSQN;
            qEwyEpweUCYVKHW = qEwyEpweUCYVKHW;
        }
    }

    for (int lDWUilu = 640355417; lDWUilu > 0; lDWUilu--) {
        csAkDAdMSQN = SRBCudSLDgirtTcv;
        vpnEbUeACoRTl = ! mHgDwdJhpgoYAtZ;
        csAkDAdMSQN = SRBCudSLDgirtTcv;
        mHgDwdJhpgoYAtZ = ! vpnEbUeACoRTl;
    }

    return csAkDAdMSQN;
}

bool STgeYLgC::gJVoSmq(int GAOFMefaCvKRoE, bool GzGJGQ, double uOOiCvLvxYPwsI, double jWCwpXNsW)
{
    double fjzJpIXzA = -243886.8684157038;

    if (GAOFMefaCvKRoE < -1034186308) {
        for (int hsuANiwEPTYuoZ = 594246772; hsuANiwEPTYuoZ > 0; hsuANiwEPTYuoZ--) {
            fjzJpIXzA += uOOiCvLvxYPwsI;
            uOOiCvLvxYPwsI += jWCwpXNsW;
            fjzJpIXzA -= jWCwpXNsW;
        }
    }

    if (uOOiCvLvxYPwsI <= -243886.8684157038) {
        for (int cfMcIKVXkTtco = 361961896; cfMcIKVXkTtco > 0; cfMcIKVXkTtco--) {
            GzGJGQ = ! GzGJGQ;
            GzGJGQ = ! GzGJGQ;
            uOOiCvLvxYPwsI *= fjzJpIXzA;
        }
    }

    if (jWCwpXNsW == -243886.8684157038) {
        for (int KDPgggvj = 443356883; KDPgggvj > 0; KDPgggvj--) {
            GAOFMefaCvKRoE -= GAOFMefaCvKRoE;
            uOOiCvLvxYPwsI = uOOiCvLvxYPwsI;
            jWCwpXNsW /= uOOiCvLvxYPwsI;
            uOOiCvLvxYPwsI *= fjzJpIXzA;
            uOOiCvLvxYPwsI = fjzJpIXzA;
        }
    }

    return GzGJGQ;
}

void STgeYLgC::zAHWVQxC(bool zcpcT)
{
    string QHWCmRQSMMLDjBdP = string("GKbgGFFPkyQLADEsEHZlLiKpszIvMQJZSAnXXqxAulYVDeuIjoqOdXBrmwmTkYqJUMJSSXkgfPaUTrsMhCDGwsOzdywIJdAaEeBAQoPosCbzmFBvThmyVTUcAoGdlvdlkxDzNGczPeecDPDoJTEdlZYRdhybcuihhQSAqAKlapGbSCErOguJrKdFyjmomFpNNNCGljTFSoGk");
    string CzKacB = string("wKeWftjRKKNAzfLveXvvGfqWPHqqjmfigeLBEjGPwaGkJFSPhFBTDiOPumQdambFpklTcNQwYvxIeaaiOGcsgAOhcaUwPgZqtezfRbnvTEerghgscHdAQZgYTCaXVsBdZZmmaYnOgkRiDFilVIMLYIodPFEqTOMBaxQiwkfDxSTJZYEYIMpIIjEK");
    bool RMavaeYZpwCTjR = true;
    string OGtAMopcQpfdUPA = string("NYmOYpowhBbznnLtbtHDyWCMaMsQcAMPKEhbbitsCcXcTbfmtAfoLNxiksVXlidGAVixpgVoWfIvlNWgjXsLVTBJCjrqWBjmaWpmEMrbFLWmUgwWXqcBHLWqVHUknGLRadInzpRazAxukBEbpAqVRUyv");
    double HGOau = 53089.63510298261;
    int NBHvA = 723666941;
    string hoIfUVkh = string("eVUOdIqYBfgmFbNemjoKcRaIxIaMdPXrvgCisnNRxKQyQvWjQnuWepvmmefblPskEUtNNOIJAofDLIIWcnDlSJiXLONJbaLbhhTMbFZcxwDdCMKSIuAGIFXSiiK");
    bool ncHJadFdyILJWB = true;
    double xdzysUDEBgWJsQxo = 63368.64176192645;
    double DdIvxvvCuA = 141833.60791176054;

    for (int JtZbwCriRUEZo = 1792319601; JtZbwCriRUEZo > 0; JtZbwCriRUEZo--) {
        continue;
    }

    for (int LtFuJruvSaxsiO = 1021469165; LtFuJruvSaxsiO > 0; LtFuJruvSaxsiO--) {
        continue;
    }

    for (int PmfeIBAvDjbot = 1613212367; PmfeIBAvDjbot > 0; PmfeIBAvDjbot--) {
        continue;
    }
}

bool STgeYLgC::CZtFbqGTUgfaX(double YQTDCwfLsVAuP, string fixyUWHBgzgRCKa)
{
    string UhGyzyEX = string("NbcTLUfrztieldZZhSeZLAchWNWSOuXmpUblJZNbmQeThSiUWuPjZeELCeueEufLgeWEYAqiwbUeUBzMKOBmyZCBGGSYZVqgkjRqTqOzvykhvgfLdkJeOBncmfoHfUDPLCobPkJCCKJJClDNmHOHirIhPyRuYWLeqWqAPjRMajtWfqKJQCFVvVmMuSTLcvQwmGwvYJavYYKmzMrqezF");
    double cnbbbpqsZtTLytvn = -333661.00332742976;
    int OcGLTSiDBMOGqY = 1093740240;
    bool SWYDUvzJvIFlDo = true;
    int rnrnJDCThq = 1053219612;
    bool cYNAP = false;
    int CeqpxyOojPSkb = 1867401911;
    string BEEgTRrLVJxFpt = string("rvtJcVlOIeTkOmgqbaIofhRVfqIQUdofMDeMAHopkCNDpPrCQwXsLExpNYFvUITSjyXTqIeDWxBBlvfwqnUmXKfFscasjvhQurVgJKkJUHwRmksCjQYpwjxNFTgLiZZTuuwmZnSEUThuYlBsKQAapySMVqygJPCJPogxbBkEObUlcmvNhMIihYarL");
    double AULKxatf = -315147.36661654525;
    double UAGHXEHrfHeWCt = 880917.2790612874;

    if (YQTDCwfLsVAuP == -315147.36661654525) {
        for (int PqZTOQWNp = 898304373; PqZTOQWNp > 0; PqZTOQWNp--) {
            fixyUWHBgzgRCKa = BEEgTRrLVJxFpt;
            fixyUWHBgzgRCKa += UhGyzyEX;
        }
    }

    if (UAGHXEHrfHeWCt < 880917.2790612874) {
        for (int efjBdBzryLGrNHk = 1787656553; efjBdBzryLGrNHk > 0; efjBdBzryLGrNHk--) {
            SWYDUvzJvIFlDo = ! cYNAP;
            UAGHXEHrfHeWCt *= YQTDCwfLsVAuP;
        }
    }

    for (int DBzrfkF = 907971006; DBzrfkF > 0; DBzrfkF--) {
        continue;
    }

    return cYNAP;
}

string STgeYLgC::EMObmhUTg(int dDQmSYIH, int FZIxTpnCUGFBmWL, string yVzaaXyBFeorjMs, int bvXqYFAmZEDUCUlX)
{
    int CmhOeqoiRtnol = -846300079;
    string eVKnvxYP = string("VmyGOTVGkVlYfPwZWCZROpnLnQfpUFoaUpraFKhrdypcYsswVtripzyEywaBmZJBrLcxEifpWkGohHyPghkXgvgGzflAeKWIvvPvyXWALxUMqnjEZ");
    bool BKuspDJUg = true;
    bool ZSHIxmCb = false;
    int mMpTlydVmSS = -1790047174;
    bool GpvTlWFPyeHsk = false;
    bool MwZNl = false;
    bool BuIBxTeTw = true;
    bool CRYeymrkgWc = true;

    for (int umkMAdTswXoJ = 131572517; umkMAdTswXoJ > 0; umkMAdTswXoJ--) {
        BKuspDJUg = BKuspDJUg;
    }

    for (int AiuvhhdSxoEdjnCo = 801418681; AiuvhhdSxoEdjnCo > 0; AiuvhhdSxoEdjnCo--) {
        FZIxTpnCUGFBmWL /= mMpTlydVmSS;
        mMpTlydVmSS += bvXqYFAmZEDUCUlX;
        CRYeymrkgWc = BuIBxTeTw;
        mMpTlydVmSS = FZIxTpnCUGFBmWL;
    }

    if (dDQmSYIH < -1790047174) {
        for (int MkbMFG = 2020015458; MkbMFG > 0; MkbMFG--) {
            eVKnvxYP = yVzaaXyBFeorjMs;
            FZIxTpnCUGFBmWL -= mMpTlydVmSS;
        }
    }

    for (int WPWzkKkSWf = 1807725753; WPWzkKkSWf > 0; WPWzkKkSWf--) {
        ZSHIxmCb = BuIBxTeTw;
        FZIxTpnCUGFBmWL /= mMpTlydVmSS;
        bvXqYFAmZEDUCUlX *= FZIxTpnCUGFBmWL;
        mMpTlydVmSS += dDQmSYIH;
        yVzaaXyBFeorjMs += yVzaaXyBFeorjMs;
        bvXqYFAmZEDUCUlX /= CmhOeqoiRtnol;
    }

    return eVKnvxYP;
}

void STgeYLgC::wcFluBOOJVf()
{
    double TVfaGN = 443147.6894753361;
    double uvGGPxkOQEjSC = -426470.1609331339;
    bool mqSRUhYGGSWO = false;
}

string STgeYLgC::YrEjksXqdBQ()
{
    int CJGZbjxiN = 540307033;

    if (CJGZbjxiN != 540307033) {
        for (int XjrcNtTyDKZC = 288487979; XjrcNtTyDKZC > 0; XjrcNtTyDKZC--) {
            CJGZbjxiN *= CJGZbjxiN;
            CJGZbjxiN -= CJGZbjxiN;
            CJGZbjxiN += CJGZbjxiN;
        }
    }

    if (CJGZbjxiN >= 540307033) {
        for (int ngRScCSUSuOBY = 1268222676; ngRScCSUSuOBY > 0; ngRScCSUSuOBY--) {
            CJGZbjxiN *= CJGZbjxiN;
            CJGZbjxiN /= CJGZbjxiN;
            CJGZbjxiN += CJGZbjxiN;
            CJGZbjxiN -= CJGZbjxiN;
            CJGZbjxiN -= CJGZbjxiN;
            CJGZbjxiN += CJGZbjxiN;
        }
    }

    return string("wpCVdnznBDQBcQLvNTEUflbTZCgQProUtXWqmUMMfVLUvqGSwfzWyhRweFeafNyHTocmmABSwENHSANtETOfhBRFnHmLgTfvgKWDXFyySZi");
}

string STgeYLgC::LgkZDyNLVABLNYf(bool zrorapO, double UkoZmDLjkgBiaOqW, int kkFFmkevzlyIOjJ)
{
    double HztVcTqBQQLFOrWq = 763226.6494404047;
    int uyjoeDKNgaPe = 1189823026;
    int yDIOeJxrMUh = -45262309;
    string DqoHPgYzamOE = string("zatRbNfjUZmHYSiCoScUGTKaeTuwiPOjHPtavMwBpFUUtSLoeGdHDAGdxARzoMqsuvHespKVRRULjGBzTeFXGifJINOwFnphzSbXKAozAWrsvgXAieLsppcDgeRYpPJFCduwNjYWVbtPDjCBZluN");
    int VajVvlZCO = 291883170;
    bool lskzawC = false;
    int uFiBkMEYW = 7860179;

    if (kkFFmkevzlyIOjJ == -1928463523) {
        for (int zlkcTQ = 134268812; zlkcTQ > 0; zlkcTQ--) {
            zrorapO = zrorapO;
            uFiBkMEYW /= uyjoeDKNgaPe;
        }
    }

    return DqoHPgYzamOE;
}

int STgeYLgC::pyvAbH(bool ZpnTURkOzSv, bool IBVkaSjWp)
{
    int BUXbKpbeijmFJHHK = -1442476898;
    bool zKZGE = true;
    bool kDjYSc = true;
    string TffwQVuUu = string("YWKYnnOyJSLlQQKxxqSPcBrhZijmOUCrxjDPpXXbGOBvLJutplacUiacvjigNCbCESQlHaAscsllDkeCqqKRKQTzFiEvFRNppwegnvGUtOjacIUXESeHRdqvyghTZOUYanvUlQiEaLLAjSXDpyAAgqcCsBccmLQSpSTGdbzKBcEYpKXpMWSEPFtyJCpgyI");
    string VHNlxF = string("YerfonIeJTItFTwyPQfbAZwigoCRtalLxaxdeBDDZoWUaxfVBHSskUtZnlFLfjMuTwTQILuKDDscGOwnOJZJsVsyNomJtqHLDKuWaLcVRHElyXBxcLloGIYZGuUCxRqdVxgl");
    bool NLoMCTNQg = false;
    bool YWSKh = true;
    int AtBbxyFFrqtf = 1418166137;
    int vfZkl = 2023668701;
    int zdxZBYr = -2047289738;

    for (int QWXto = 1394864817; QWXto > 0; QWXto--) {
        IBVkaSjWp = zKZGE;
    }

    if (zKZGE == true) {
        for (int mpooqhZNfBbmdUG = 1408510803; mpooqhZNfBbmdUG > 0; mpooqhZNfBbmdUG--) {
            YWSKh = IBVkaSjWp;
            AtBbxyFFrqtf = vfZkl;
        }
    }

    if (IBVkaSjWp != true) {
        for (int QRVKSpAWvvylL = 75914155; QRVKSpAWvvylL > 0; QRVKSpAWvvylL--) {
            AtBbxyFFrqtf /= zdxZBYr;
        }
    }

    if (kDjYSc != true) {
        for (int ZDjdS = 644644860; ZDjdS > 0; ZDjdS--) {
            ZpnTURkOzSv = IBVkaSjWp;
            BUXbKpbeijmFJHHK /= AtBbxyFFrqtf;
        }
    }

    for (int ZVBlcXtlZbWdmTE = 839692449; ZVBlcXtlZbWdmTE > 0; ZVBlcXtlZbWdmTE--) {
        kDjYSc = kDjYSc;
        zKZGE = ! zKZGE;
    }

    return zdxZBYr;
}

STgeYLgC::STgeYLgC()
{
    this->JMNBBWMpvHLnF();
    this->DVzBEeIbkt();
    this->PFHRILiIeaQ(703097130);
    this->wgECQJprPIQrle(429211.4284396451, 605592141, false, string("xIqvRaAfiWFIwFcIqWkkNoifoZTBbVWHdjVdvpuvFRNUYqXAKwbgRGdGVpFAgUVGwLYEVXmFXkorkrYnmBPbkd"), 254209599);
    this->nSCNGuu(-288451.4152784753, 84333.85772827358, false, string("CcrkLTlhdsYXmEinJkziQbwkOIeIClBTnlpQPctgELNPTpIiDPJQHTBEAuWcXtkxyZcwYCyAsaKymnrEIHrrOMIwRlIWqzwuiQTPsgqJDfyGeEfRfsrmEdqpTdskMARZbFOAIcQnAqBvoHORjiDKUWFBrcEgtsMHKAMaMNUlVqSFrMfIGYMWNIssL"));
    this->gJVoSmq(-1034186308, false, 592669.2598155005, 866618.6030743348);
    this->zAHWVQxC(true);
    this->CZtFbqGTUgfaX(367749.0690706985, string("rTcqLqnmIbRJYqsmwytarDktrvbQoHrzDIxztTvDGTPoZATLvgnTEgfIxYRfE"));
    this->EMObmhUTg(-1093630242, 86817510, string("xqEgWLResfoqjscfNDhrVgrijvfHeVtGDyTUkIUZDyjpBbvwIZJeLSIAEFulcjHIHzPBpkrSzOFoXiUdmSxBarzWPEwcavMYNhBXjAnZSYfdplMDxmwAuHmkHDOJlQIjQbVJSxfZqAwPQoUwFcrlJtwCuiXbLbuJvzcMGqajevcyBxmcVBSxoUsoFpAGZKeXhYAuPYEDsEeYMJsbAOoWZaplEJalCHBPGqkRhewBls"), -1252579716);
    this->wcFluBOOJVf();
    this->YrEjksXqdBQ();
    this->LgkZDyNLVABLNYf(true, 796654.3104661229, -1928463523);
    this->pyvAbH(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iBScGza
{
public:
    bool ajRgLgfUcBNhUj;
    bool yDRKflUFMfDmBcWk;
    int iJxnkqDwLorf;
    string ImlFoMhZzAqoUJC;

    iBScGza();
    string cbpaEa(bool xhZOkErecF, int JnItDnXG, double GuSZFL, int rmZxmz);
    void qxTJCFhHgGHvv();
    string OPPdRkax(bool DcszCvDPQG, string mCzigndmfQDHDWer, bool jpuRbFUVRtjKGTtC, int qBnkITpoymnPrb, string KLrRiwF);
    double JaJYbhrSE(string NvMLn, bool CcDxtCmL, double WaLhGE, string gkEAlumyoUso, bool zltYEdoKssrlBzMe);
protected:
    string qGpxAsAnFzJCFhuC;
    double MBBmgMfzBhuRw;
    string VXpMavaRTudvhWM;
    double cxregPVw;
    int lPbCMAkOcCrgBN;
    double IhJGCKXLtzzO;

    int SDczEDBtxfQoEH(bool tFEZsIPmSUdKLhn, double yBCVp);
    bool TMzSKOamzjosM(bool wGUsYLVzpPU, bool dsZvMcVE);
    double JfvtOYynXj(bool MjYXcnO);
    string jeThC(bool OlZQQDoEX, double EEGLbHTQC, double xMfnZUTFqXGMeV, bool nqDrLgdvCvKRt);
    int daOmdCPvh(double MiHjMAB, double HLosRdpNADpOKE);
    double dnfcV(string jREgwqzjrPG, bool XFPLk, string VAFfyuRG);
private:
    int UjnrmOawYRz;
    bool zXesXvmYNtsZhS;
    int CojGzPUeF;
    string KhzkPNfLGBxRJWnf;

    bool PTaMPQiYxVkkHD();
    string qnhqRhWzIneKG(double VCPUQPageMqxxbz, double hNwbEkxHRH, double NDfXBfJ, string NtZjXHJpQqQc, int rNMXUduUpc);
    void MzUMNT(int orUZHPdyztaCmzUq, int yphHMbT, string wschlgn, string bIlNwTlNelLtscPz, int knYtmUHj);
    bool sOgzbOWCn(double hGXpWKobAMFUaia);
    void ZKvRllpRo(bool vdXKMUyZiZ);
    double ynghovE(bool aBKWWHhbM, double wCBsQijoUHcDKcNL, bool NyQIToGZHmwMcb);
    bool WcAbb(int DtmroygZyQgDsX, double caPnTNCMKfgNaBrt, bool nsfBRkrxy);
};

string iBScGza::cbpaEa(bool xhZOkErecF, int JnItDnXG, double GuSZFL, int rmZxmz)
{
    bool xYEhnccQNPyioZcW = true;
    bool BLbUwzGJzMfT = true;
    bool SIzUXWiMfMCZ = false;
    bool PRcQKBliiHooTi = false;
    bool MWfFU = false;

    if (BLbUwzGJzMfT == false) {
        for (int SEXKOt = 109873647; SEXKOt > 0; SEXKOt--) {
            xhZOkErecF = ! MWfFU;
        }
    }

    if (SIzUXWiMfMCZ != false) {
        for (int sVFof = 407145474; sVFof > 0; sVFof--) {
            xhZOkErecF = xhZOkErecF;
        }
    }

    if (BLbUwzGJzMfT != false) {
        for (int XQNzGteGkDHm = 655428837; XQNzGteGkDHm > 0; XQNzGteGkDHm--) {
            MWfFU = PRcQKBliiHooTi;
            xhZOkErecF = xhZOkErecF;
        }
    }

    for (int iZCHJZPLkrJExj = 1670939945; iZCHJZPLkrJExj > 0; iZCHJZPLkrJExj--) {
        xYEhnccQNPyioZcW = ! xhZOkErecF;
        xhZOkErecF = SIzUXWiMfMCZ;
        BLbUwzGJzMfT = ! xYEhnccQNPyioZcW;
        BLbUwzGJzMfT = xYEhnccQNPyioZcW;
    }

    for (int wFMFeUfCzQNMlwhJ = 1582283633; wFMFeUfCzQNMlwhJ > 0; wFMFeUfCzQNMlwhJ--) {
        MWfFU = PRcQKBliiHooTi;
    }

    for (int CvINcSHtiomlAh = 852800787; CvINcSHtiomlAh > 0; CvINcSHtiomlAh--) {
        SIzUXWiMfMCZ = xhZOkErecF;
        JnItDnXG /= rmZxmz;
        PRcQKBliiHooTi = xhZOkErecF;
        PRcQKBliiHooTi = ! SIzUXWiMfMCZ;
    }

    return string("WqHCqbyMteRuswyNwQzkBdSfKkRDbEvESTbMjUbhylLxhIbhuDluJJYKqmmEnqGCtrLZzJkPefzYlxmcCWlzYDFJjNtuOLTGoTdEcNTlGWQXMnedLWBTRfaBpuRCKDZzpSINKbPPamP");
}

void iBScGza::qxTJCFhHgGHvv()
{
    double SWxUGQhb = -429790.25343075354;
    int movjcp = -278375848;
    string pFIsHGRYrICdIEL = string("XLechGUSaPxjTZmuMrSQbzcnETkXcVyChDZxkHtyXtOTauYZauqcowfelHavZgpEAuiFtItDxyXMJJxbjriKSOXJQD");
    bool DmxRIAkuBk = false;
    string jrWmfvULSd = string("UcEjFwODeZviiRmHpKqIMiaYJgSnjoWhxweicGZQEYNiZYsxrnpFfnSeAvjieISpeKdjOferkqHrPYDIvgQJGjGIacgUNHP");

    for (int XJpwwxHYXV = 549752384; XJpwwxHYXV > 0; XJpwwxHYXV--) {
        jrWmfvULSd += jrWmfvULSd;
        pFIsHGRYrICdIEL = jrWmfvULSd;
        jrWmfvULSd += pFIsHGRYrICdIEL;
        pFIsHGRYrICdIEL += jrWmfvULSd;
        SWxUGQhb *= SWxUGQhb;
        movjcp -= movjcp;
    }
}

string iBScGza::OPPdRkax(bool DcszCvDPQG, string mCzigndmfQDHDWer, bool jpuRbFUVRtjKGTtC, int qBnkITpoymnPrb, string KLrRiwF)
{
    string YMKsqWHAA = string("rtxEGiJVHgXZSeCLmNQByzrwOZHk");

    if (KLrRiwF != string("rtxEGiJVHgXZSeCLmNQByzrwOZHk")) {
        for (int aSLUwWIxqxmWBbQ = 1998092493; aSLUwWIxqxmWBbQ > 0; aSLUwWIxqxmWBbQ--) {
            continue;
        }
    }

    if (KLrRiwF == string("rtxEGiJVHgXZSeCLmNQByzrwOZHk")) {
        for (int UENzEGNNAElm = 1285000243; UENzEGNNAElm > 0; UENzEGNNAElm--) {
            jpuRbFUVRtjKGTtC = ! DcszCvDPQG;
            mCzigndmfQDHDWer = KLrRiwF;
            jpuRbFUVRtjKGTtC = ! jpuRbFUVRtjKGTtC;
            mCzigndmfQDHDWer = mCzigndmfQDHDWer;
        }
    }

    return YMKsqWHAA;
}

double iBScGza::JaJYbhrSE(string NvMLn, bool CcDxtCmL, double WaLhGE, string gkEAlumyoUso, bool zltYEdoKssrlBzMe)
{
    double HuyOobWJUUDcoeJd = -209621.28579791536;
    double dhiObWMmrT = 252469.7367860336;
    string bnxaTkFsEL = string("dFwbjlhpsZSvlCGepxQXZcLPTuEEpKlHTQksNfNuqqQAqLkchaqMDYWhdvSWqSuFXQIqwZTUZbfBYTisrjoyHGECvJaFlwDtQwTanrcCPfafakEEKRCDMnMPMdGbSWxTxVumlNDUsjUwsfnbnDCZTOktgSmtJivQbAmhTObdTZk");
    int FRhYRTecSR = 1569743466;
    int mnMpxeQkxTaCRXz = -2028542231;
    string tLtBRwsUuhTlLMdo = string("WZcKDfBNONibvPBeERkvPPjZnpvjzdJEaLTRnlldzca");
    bool DonczD = true;
    bool QIVVwEeTPtF = true;
    bool zwFfWbIDwQmw = true;
    double zJbazduDcEd = -657617.3173478219;

    if (CcDxtCmL != false) {
        for (int OOcdmvHCEcBI = 735639088; OOcdmvHCEcBI > 0; OOcdmvHCEcBI--) {
            gkEAlumyoUso += bnxaTkFsEL;
            zltYEdoKssrlBzMe = QIVVwEeTPtF;
        }
    }

    for (int lednwP = 288547499; lednwP > 0; lednwP--) {
        continue;
    }

    for (int xyBDaD = 1893600585; xyBDaD > 0; xyBDaD--) {
        zJbazduDcEd += WaLhGE;
    }

    for (int vMPrWTGr = 1923874318; vMPrWTGr > 0; vMPrWTGr--) {
        bnxaTkFsEL += tLtBRwsUuhTlLMdo;
        CcDxtCmL = ! zltYEdoKssrlBzMe;
    }

    for (int FxpAymLxWR = 1365627246; FxpAymLxWR > 0; FxpAymLxWR--) {
        gkEAlumyoUso = gkEAlumyoUso;
        dhiObWMmrT -= WaLhGE;
    }

    return zJbazduDcEd;
}

int iBScGza::SDczEDBtxfQoEH(bool tFEZsIPmSUdKLhn, double yBCVp)
{
    bool VKMFBHOlOnUzq = false;

    if (tFEZsIPmSUdKLhn != false) {
        for (int fLldmwn = 552509153; fLldmwn > 0; fLldmwn--) {
            VKMFBHOlOnUzq = ! tFEZsIPmSUdKLhn;
        }
    }

    for (int ljjalvNKJjQgDjby = 1600608351; ljjalvNKJjQgDjby > 0; ljjalvNKJjQgDjby--) {
        tFEZsIPmSUdKLhn = tFEZsIPmSUdKLhn;
        VKMFBHOlOnUzq = ! VKMFBHOlOnUzq;
        VKMFBHOlOnUzq = tFEZsIPmSUdKLhn;
        VKMFBHOlOnUzq = ! VKMFBHOlOnUzq;
        yBCVp -= yBCVp;
    }

    for (int lAnEjVG = 1382009138; lAnEjVG > 0; lAnEjVG--) {
        VKMFBHOlOnUzq = tFEZsIPmSUdKLhn;
        tFEZsIPmSUdKLhn = ! VKMFBHOlOnUzq;
        tFEZsIPmSUdKLhn = VKMFBHOlOnUzq;
    }

    return 2105186670;
}

bool iBScGza::TMzSKOamzjosM(bool wGUsYLVzpPU, bool dsZvMcVE)
{
    double JvhTfaB = -1018825.7029175779;
    int zHFGbBSH = 934254450;
    double xIRcnCcIIH = 214262.3111739963;
    bool CvrAR = true;
    double gKglxCoEgwNs = -600448.9611730771;

    for (int ddrqiOtCoFzmd = 1678009412; ddrqiOtCoFzmd > 0; ddrqiOtCoFzmd--) {
        CvrAR = wGUsYLVzpPU;
    }

    if (CvrAR == false) {
        for (int dyuaT = 1698683018; dyuaT > 0; dyuaT--) {
            zHFGbBSH /= zHFGbBSH;
            xIRcnCcIIH += gKglxCoEgwNs;
            JvhTfaB = gKglxCoEgwNs;
            xIRcnCcIIH += xIRcnCcIIH;
        }
    }

    return CvrAR;
}

double iBScGza::JfvtOYynXj(bool MjYXcnO)
{
    double mTLqhQUCMQYWP = -800472.2990063985;
    string PfKofcLSLOHUiG = string("pkAAZOJpEBeQUhgsyUJtBymuQwQWHoATRYLnphRaqTjDLzXLwLJCuyCbGNypnEUOoBljzvmnGXFeDTZVfbjPWmiBdkeJWKbwxWLfhpozyooXuJZJHqKROIXLbdZbwTzNwQCrFcUvYqsqVHOJpycTHWlNjdyyThSjRlGowxAgsVSyjnmJKjtnjOTwswabbEgsEpawYXDeBunodiNVwgUtDfPFRWhUwPixeS");
    double YwcALeEBeyAFa = -14752.91146891363;
    double gvMbgJAfkygYDB = -576955.2052285718;
    double ZTsZHVbv = 537951.9334482806;
    int CRfUgjGEv = -771026989;

    for (int KujEjeaRaF = 342075792; KujEjeaRaF > 0; KujEjeaRaF--) {
        ZTsZHVbv += gvMbgJAfkygYDB;
        mTLqhQUCMQYWP *= ZTsZHVbv;
        gvMbgJAfkygYDB *= ZTsZHVbv;
        mTLqhQUCMQYWP -= gvMbgJAfkygYDB;
    }

    return ZTsZHVbv;
}

string iBScGza::jeThC(bool OlZQQDoEX, double EEGLbHTQC, double xMfnZUTFqXGMeV, bool nqDrLgdvCvKRt)
{
    bool BrFoTAjzv = true;
    int BtKTunNaQdz = -744061028;
    double iHiNqASshNAN = 99460.23123186026;
    int CrBPChKJMzn = -1471049158;
    int sQMNGePLrypyNysU = 151657324;
    bool AtDuaoMqgVCKx = false;
    double bwJDXOceYCel = -607613.9811138116;
    bool UaSrFHdg = true;

    if (BrFoTAjzv == true) {
        for (int sMvQMBLysJAUOT = 1053065275; sMvQMBLysJAUOT > 0; sMvQMBLysJAUOT--) {
            AtDuaoMqgVCKx = ! nqDrLgdvCvKRt;
            iHiNqASshNAN -= iHiNqASshNAN;
            OlZQQDoEX = nqDrLgdvCvKRt;
        }
    }

    return string("TnpIMlxnHsbkuxzYTboTKnolPFQyMYzUnbkEiErsinlwkpsCKikKTyfQmJBcjTJQsslQeQnYqKUVqirUJuRLzIkjsCuPJCtHIbKMoP");
}

int iBScGza::daOmdCPvh(double MiHjMAB, double HLosRdpNADpOKE)
{
    int kxmysHzjuvVF = -1248781765;
    double fJKibEhihMUovNuM = 559739.6485862781;
    double LtIlCcLvxZYe = -331926.0574287637;
    double FGpmQVguIXNYMcqg = -55217.42537113336;
    double VlYCgxIRM = 582391.430050295;

    return kxmysHzjuvVF;
}

double iBScGza::dnfcV(string jREgwqzjrPG, bool XFPLk, string VAFfyuRG)
{
    string YhxrpqEur = string("dPHIbmGWoYWOxZKfOnIuBeyRefKtZPKjPnElWIvijWQOLFYdJoqOQfbSvKUIRgfKTXuvdzcwrfJvSvQIYDJVriTZBbQJQmraUVgtQYyisLLXiWrkDtWBIKqifNRUdmzCmMuYvWHiDYqiGkMSK");
    int qIBzuaJDMovREQ = 1110169328;
    bool yHqMSEFxR = false;
    double ZibFAogC = -676610.9129812032;
    double jASuvTHhVw = -205495.12331116394;
    int tRxVwjBCCLp = -1585545815;
    double nssEaG = 640312.9980663034;
    double fNgXlffU = -350054.48723496706;
    int jvUDDfbPrJn = 946928058;
    string OOZoBUBQdBen = string("sgLukaIQyJWYOmvDbkhExPhvUWrIRhHsLfVnsaNTGhKHZbnkPCGWSgVtuyHZAqGPSDpMQLLkbYVWjoLEbOyrHklvsI");

    if (yHqMSEFxR != false) {
        for (int baGBdztfbTtKwt = 566975523; baGBdztfbTtKwt > 0; baGBdztfbTtKwt--) {
            continue;
        }
    }

    return fNgXlffU;
}

bool iBScGza::PTaMPQiYxVkkHD()
{
    bool MGQkkdRcJc = false;
    bool zdlJaNYmVvyK = false;
    bool YVqnjDmYMDUrmX = false;
    int pOSGYFVEzH = -2059804293;
    bool cZsQzksLnHfNvp = true;
    int hmThLaDxMOvx = 1843949464;

    for (int zHdwIOMiVMKaNRz = 1010915712; zHdwIOMiVMKaNRz > 0; zHdwIOMiVMKaNRz--) {
        YVqnjDmYMDUrmX = MGQkkdRcJc;
        zdlJaNYmVvyK = ! MGQkkdRcJc;
        zdlJaNYmVvyK = cZsQzksLnHfNvp;
        MGQkkdRcJc = ! cZsQzksLnHfNvp;
    }

    for (int YDkCGxLfgKQnDsro = 929664646; YDkCGxLfgKQnDsro > 0; YDkCGxLfgKQnDsro--) {
        MGQkkdRcJc = YVqnjDmYMDUrmX;
    }

    return cZsQzksLnHfNvp;
}

string iBScGza::qnhqRhWzIneKG(double VCPUQPageMqxxbz, double hNwbEkxHRH, double NDfXBfJ, string NtZjXHJpQqQc, int rNMXUduUpc)
{
    string IUIdgK = string("jcJKmROPJZdKlOhjwbgFLXvPnxWjaDkFoGClsWUNNNHrYvWObEmDhSzFrclaXBRsgFsXnkuqjfuiUOPZiRW");
    int QPWAiWbRs = -2073932786;
    int zsGVVSvatY = 309305864;
    int rGleaMiXGHE = 954682693;

    for (int TUMVYGmuGOWKu = 1699956494; TUMVYGmuGOWKu > 0; TUMVYGmuGOWKu--) {
        NDfXBfJ *= VCPUQPageMqxxbz;
        IUIdgK = IUIdgK;
        NtZjXHJpQqQc += NtZjXHJpQqQc;
    }

    for (int VwRCOQKEHzrFgFt = 1495635329; VwRCOQKEHzrFgFt > 0; VwRCOQKEHzrFgFt--) {
        hNwbEkxHRH = hNwbEkxHRH;
        VCPUQPageMqxxbz = NDfXBfJ;
        QPWAiWbRs += rGleaMiXGHE;
    }

    for (int GtYTpRPng = 407751438; GtYTpRPng > 0; GtYTpRPng--) {
        continue;
    }

    for (int ZyyDNXeMeF = 1597741568; ZyyDNXeMeF > 0; ZyyDNXeMeF--) {
        zsGVVSvatY *= rNMXUduUpc;
        IUIdgK += NtZjXHJpQqQc;
    }

    if (NDfXBfJ < -44980.45712636412) {
        for (int uqQqFr = 141261792; uqQqFr > 0; uqQqFr--) {
            rNMXUduUpc *= rGleaMiXGHE;
            rNMXUduUpc += zsGVVSvatY;
        }
    }

    return IUIdgK;
}

void iBScGza::MzUMNT(int orUZHPdyztaCmzUq, int yphHMbT, string wschlgn, string bIlNwTlNelLtscPz, int knYtmUHj)
{
    string WBvfLBiuSa = string("moQdITGqAMqaxNwNXtBstJsFUofdLXxEGNaCAeysSNewuIMDriAGJjaTNsZyJqLGeQMrxIrcYkTiTHyidZOdnIFYELXQzXWkYMPwmQYjXEsNbxSwKiRGRpOfoyDfCDffEUzfBOfCepXePxprbjAgyOLZtzPCzmdxqcahcwFbqyLGomCXDLxhncWVUzaR");
    int VhkjFsarnBjaeUO = -1303546581;
    string sHPyuNweZxmcRsWr = string("nejKtOngILHreSBTFGTsbXZezTeOfrObRUWxqDOApfpmorvivRFyErSuEjgu");
    int HlotYQaPvFjsFmvo = 1905702215;
    bool gAwIhHSGBnobImQ = true;
    string LJANErOGg = string("TMmnGCJA");
    string awvGg = string("YJdyswSZSugnLUUOlhLCeVlpNBamxDwuNeYXvMIwsAHbJYwRFEHuuwhoRbLQyIVRtzdMzyctDzIaxgIokNBDaMlttFzdtqyAKjgUwjhQsGbiAqGnppEqIQwsUTZTPfEFmrifzDOBJawnTAmrCPghZsuKXERcNCxLRUjWLhqcfRZxJDflNUCUGJtRTGpDRP");
    double DQGlJUaqAXZMkH = -690641.8919046702;

    for (int eYySNlLLWCbGiGGE = 1196532834; eYySNlLLWCbGiGGE > 0; eYySNlLLWCbGiGGE--) {
        knYtmUHj += HlotYQaPvFjsFmvo;
        orUZHPdyztaCmzUq = orUZHPdyztaCmzUq;
        VhkjFsarnBjaeUO += VhkjFsarnBjaeUO;
    }
}

bool iBScGza::sOgzbOWCn(double hGXpWKobAMFUaia)
{
    int NuEqTRSLnNjm = 1569571119;
    string WSEjm = string("BZieNqfgCoHRDctldIpfECHrIjYFMdmWpZSxKqCrwpXzviTHPQKMegduCSWQOXhsEvZIrqSYXAREdRnGKGcXGjVOOzgYVTxmurGOJjDNmhsKHWXkUaPTUUSWMyxtZQMoPBtSZLdcjQynqKTxqG");
    int AnQujFKeNfZcA = -11817267;
    string MvXwrZYMgtvokJb = string("POeAKLvzXiYaIBUGRpdrWrYrhVDDddzPWbBlDBDQxtdgEzZKzuWTMggRdRInleafOJFJpJgTAhdSPsUXUVRGISAqgJkPrMEIqRooBtPpAnPBnnTNZiOZSYILZcHLxlDxOKYzVdQ");
    int WhCjpi = -1405338998;
    int RkMzdMYHz = 654640593;
    string KIImMsKKmk = string("YvshHJOAxwNsonvJnvYYGPQGQjoccu");
    int ITbCltaXwdqv = -258807299;
    string EBdVq = string("WuAtNIitLwLFHAzLZexaeIVptFSUkKtUBiEBuTOFAIqBbxzYYdeKdiUgMnHuhbzGKJmONPKjyfAIGgXoBjHHseFyenofGRVoQSOqCUUKUKmTfdyTMVGgAKunvHNvvnotVmCmPBwNlROPtCLukaruIzDkcOW");

    for (int vayJLIrd = 1711590418; vayJLIrd > 0; vayJLIrd--) {
        WhCjpi = ITbCltaXwdqv;
        RkMzdMYHz -= RkMzdMYHz;
        ITbCltaXwdqv = AnQujFKeNfZcA;
        MvXwrZYMgtvokJb = WSEjm;
    }

    for (int YREJkuXiHolrkRjn = 209099553; YREJkuXiHolrkRjn > 0; YREJkuXiHolrkRjn--) {
        RkMzdMYHz /= NuEqTRSLnNjm;
    }

    for (int EbmXYAjyQZhB = 1609774155; EbmXYAjyQZhB > 0; EbmXYAjyQZhB--) {
        continue;
    }

    if (AnQujFKeNfZcA == 1569571119) {
        for (int IwbbAq = 1694010946; IwbbAq > 0; IwbbAq--) {
            ITbCltaXwdqv = AnQujFKeNfZcA;
            ITbCltaXwdqv = RkMzdMYHz;
            WSEjm = KIImMsKKmk;
            ITbCltaXwdqv -= AnQujFKeNfZcA;
            WhCjpi *= WhCjpi;
        }
    }

    return false;
}

void iBScGza::ZKvRllpRo(bool vdXKMUyZiZ)
{
    bool KXsgKEVfIOpXtQ = true;

    if (KXsgKEVfIOpXtQ == true) {
        for (int lNhWlWSsMksOuuz = 925284702; lNhWlWSsMksOuuz > 0; lNhWlWSsMksOuuz--) {
            KXsgKEVfIOpXtQ = ! vdXKMUyZiZ;
            KXsgKEVfIOpXtQ = vdXKMUyZiZ;
        }
    }

    if (vdXKMUyZiZ == true) {
        for (int IZUXZNXdrglvccg = 2057793819; IZUXZNXdrglvccg > 0; IZUXZNXdrglvccg--) {
            KXsgKEVfIOpXtQ = KXsgKEVfIOpXtQ;
            KXsgKEVfIOpXtQ = ! KXsgKEVfIOpXtQ;
            vdXKMUyZiZ = KXsgKEVfIOpXtQ;
        }
    }

    if (vdXKMUyZiZ != false) {
        for (int ofHNaeSpbNoC = 222943573; ofHNaeSpbNoC > 0; ofHNaeSpbNoC--) {
            vdXKMUyZiZ = ! vdXKMUyZiZ;
            vdXKMUyZiZ = vdXKMUyZiZ;
            KXsgKEVfIOpXtQ = ! KXsgKEVfIOpXtQ;
            vdXKMUyZiZ = vdXKMUyZiZ;
        }
    }

    if (vdXKMUyZiZ != false) {
        for (int QBiHFSa = 706406407; QBiHFSa > 0; QBiHFSa--) {
            KXsgKEVfIOpXtQ = ! vdXKMUyZiZ;
            KXsgKEVfIOpXtQ = ! KXsgKEVfIOpXtQ;
            vdXKMUyZiZ = ! vdXKMUyZiZ;
            KXsgKEVfIOpXtQ = KXsgKEVfIOpXtQ;
            KXsgKEVfIOpXtQ = KXsgKEVfIOpXtQ;
            KXsgKEVfIOpXtQ = vdXKMUyZiZ;
            KXsgKEVfIOpXtQ = KXsgKEVfIOpXtQ;
            KXsgKEVfIOpXtQ = vdXKMUyZiZ;
        }
    }

    if (vdXKMUyZiZ == false) {
        for (int BivCXdporOjmua = 746110441; BivCXdporOjmua > 0; BivCXdporOjmua--) {
            KXsgKEVfIOpXtQ = ! KXsgKEVfIOpXtQ;
            vdXKMUyZiZ = ! vdXKMUyZiZ;
            KXsgKEVfIOpXtQ = ! vdXKMUyZiZ;
            vdXKMUyZiZ = KXsgKEVfIOpXtQ;
            KXsgKEVfIOpXtQ = vdXKMUyZiZ;
            vdXKMUyZiZ = ! KXsgKEVfIOpXtQ;
            KXsgKEVfIOpXtQ = vdXKMUyZiZ;
        }
    }
}

double iBScGza::ynghovE(bool aBKWWHhbM, double wCBsQijoUHcDKcNL, bool NyQIToGZHmwMcb)
{
    int QpNWMgEDahcNg = -1883632505;

    for (int aCpXNwiCCrK = 1645238496; aCpXNwiCCrK > 0; aCpXNwiCCrK--) {
        QpNWMgEDahcNg *= QpNWMgEDahcNg;
    }

    return wCBsQijoUHcDKcNL;
}

bool iBScGza::WcAbb(int DtmroygZyQgDsX, double caPnTNCMKfgNaBrt, bool nsfBRkrxy)
{
    bool WYjBlrLL = true;
    double kYLVgR = 1047815.819245772;
    double TBIRLDpuOdGh = -300959.91373720346;
    double olaeCSKCL = -883213.0960672231;
    double grHbFmOE = -25533.755003198956;
    double RyKmeSbd = -605142.7321792245;
    int rrYqlYdQTUmnEY = -1352556973;

    for (int FAdRfDztCPJ = 1584466554; FAdRfDztCPJ > 0; FAdRfDztCPJ--) {
        olaeCSKCL = kYLVgR;
        kYLVgR *= RyKmeSbd;
        TBIRLDpuOdGh = RyKmeSbd;
    }

    if (grHbFmOE < 1047815.819245772) {
        for (int eIwObCvDCfGz = 496254436; eIwObCvDCfGz > 0; eIwObCvDCfGz--) {
            grHbFmOE /= caPnTNCMKfgNaBrt;
            kYLVgR = TBIRLDpuOdGh;
            olaeCSKCL = RyKmeSbd;
            RyKmeSbd *= caPnTNCMKfgNaBrt;
        }
    }

    if (caPnTNCMKfgNaBrt == -300959.91373720346) {
        for (int EpDvSvVFKchNJos = 679863690; EpDvSvVFKchNJos > 0; EpDvSvVFKchNJos--) {
            grHbFmOE -= olaeCSKCL;
            RyKmeSbd *= grHbFmOE;
            kYLVgR += olaeCSKCL;
            RyKmeSbd *= grHbFmOE;
        }
    }

    for (int tebBWYJl = 1229942586; tebBWYJl > 0; tebBWYJl--) {
        RyKmeSbd /= grHbFmOE;
        RyKmeSbd -= TBIRLDpuOdGh;
        nsfBRkrxy = ! nsfBRkrxy;
    }

    for (int biCCYHzQOR = 1892447785; biCCYHzQOR > 0; biCCYHzQOR--) {
        caPnTNCMKfgNaBrt *= kYLVgR;
        rrYqlYdQTUmnEY -= rrYqlYdQTUmnEY;
    }

    for (int dShfpWJ = 485390500; dShfpWJ > 0; dShfpWJ--) {
        TBIRLDpuOdGh -= RyKmeSbd;
        kYLVgR = kYLVgR;
    }

    return WYjBlrLL;
}

iBScGza::iBScGza()
{
    this->cbpaEa(false, -15121563, -48405.09244281294, 2107279401);
    this->qxTJCFhHgGHvv();
    this->OPPdRkax(false, string("HEQXOjyYqKLQXvdXRnTkHzqUtcFmFnlDwzKNWbRLPGnvgwrQvOaWZvQdCAFPNWEUxZvSnocKpoIcZnPqROQQxIvhKdkjOzuXAcI"), false, 1667923524, string("jkwTZXGLfyWzPDkrItoMlgiuXDpWZqObQvsGTpARTAFoBRDxZFHuWwVJKfDkGYKqbXctjPKjPANkrRbBVGOfCkaxCMdTEMkwtdClknXjpxwPbubivwvNPWOrvJpPvTApifcHwLtjSTbdGNCKQVCAjsGfQRAugzOZwRvTqKTIsRLQkTlRHCrsszVnpbcuZIWFkciVlKiDVFkkjrvmNy"));
    this->JaJYbhrSE(string("iaHkWZTuCZqLFcMFKEUbxfJZacEPrDUoVPMKXnSsbQtadxjHAHrwdVfqWUKYrrJdIskYZCWaFofNnBgRGJoCzobLOnVNxsoANFeIUFnNBTSFcblkwLJQotupoFBcHyTrxDFKiupcIQIBrJXzxBECrmjqOaFpyEEaRjmypoIoYcGchDjLdtzqscaUurWnRzkCHXddypPRKEbhLdsdfJOhURPCIgurd"), false, 772999.0470827444, string("ztsIMciYcacHPv"), true);
    this->SDczEDBtxfQoEH(false, 91785.22012181487);
    this->TMzSKOamzjosM(false, true);
    this->JfvtOYynXj(false);
    this->jeThC(false, 256518.53999625077, -91326.13324635816, false);
    this->daOmdCPvh(741898.6467582979, 402039.97354515694);
    this->dnfcV(string("FEfuMKbkEzzkCTnjARTgZXLxmINwfMFSZNUjWOQhFAuxogrIQwhDGdXWtdWDMQftYkryZzZCRoLFAtwDNGlLckOnnJevgwUcLbrkeAonrjElKNakcdIY"), false, string("hqHAbDbKjsUuhRbUgrwJWfYXOCJamlxDzhRUjMFjWkaxpyXtUIeNpNJttikuBRCipTvwygNPbEKUKliMoyrigUoxJDGsJpfmsriKQRRrhawzwvhGpjxlcREyXNHUZMvrkIEnrpLGJatMkEBXbQDUApESjIyTA"));
    this->PTaMPQiYxVkkHD();
    this->qnhqRhWzIneKG(-44980.45712636412, 316258.7761251231, 347915.7132823251, string("WDwnhdihsyyULRcsBLJBJMfnpafzFKISgfmEPezoIYUjuWKNBWPBIliZrOMHBrzBdRafgcuOlIsDPqwTqYkxvYBEnArKZeJKfSdrnkgihpibLzOMMWsTyihuGRXhRqZwF"), 1920783125);
    this->MzUMNT(1505955795, -1964368136, string("wISeDXvacACuTMFcGfcXRwVucHa"), string("kIwTyQEEZHphothKyDMUzDNUjkgMIJwSaDCkUEVpaApqeEPEwQaPQvYrzMycsUWqAJzKqcWHXNDwunCUQKSvJIEzTsQGEM"), -1703662007);
    this->sOgzbOWCn(-83807.64478988126);
    this->ZKvRllpRo(false);
    this->ynghovE(false, 760989.4372239208, true);
    this->WcAbb(589255297, -326458.05295771576, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HXXKnDYhqXOw
{
public:
    double eKweKP;
    bool VMeWBmpdx;
    double SqcGJshx;
    bool kgwkpUP;

    HXXKnDYhqXOw();
    int FieLquADH(double VDyXLOZtnyrbz, int ddyNp);
protected:
    string PXmheNyIUC;
    bool ibnoPBvH;
    double RHGMhjlNJkEnJd;
    double NrjxktBlB;
    double wWEWjCdGPfVZYHzS;
    bool blZxPZdZFmnmBI;

    string OykerkFj();
    void semPJgnBbIGjK(int MouKayOj);
    void jwrzgptIOXzFxo(string HDbruRntMq, bool WnMGUALAtCDW, double akZQeWZljWP);
    int aSTxCtMucYFi(double hNHTNScrzLcVDzpZ, string iEtUriJjyk, int mirBQJbAga, double vKTkyVzjAjaiqJBS);
private:
    double LXgUKnU;
    bool VYaokokbFssZvunH;
    string MxjFzmAwguXznPZ;
    int gZZIBqmBzIKlbTVH;

    string bUlWglCQlNBDBB(bool BjoxhdLPibEo, double nvNEXoKfMKYw, string TqNViAAIbFQOJPOV);
    string JCwRVEvoW(string SpOMf, double bjXJInhzOAXfb);
    bool hILPlENg(double oOrpyefPKQoMW);
    void iZRyNONyUpXStu(double nnCbp);
    void WUfcyh(bool cLCMfqOrXESezfs, string GIEkY);
};

int HXXKnDYhqXOw::FieLquADH(double VDyXLOZtnyrbz, int ddyNp)
{
    double RtLatv = 465361.98211463226;
    int ZFJwKrtgvviME = -1957755775;
    bool hSLxLFnYRa = false;
    string JSIUjaXKvHOWCrL = string("spUqnKOCMRIjbvqWRepGmnCFYKtniFjWgvRYoUdmWMWwNpWOAtuQGMymeWaWuhnDMJPMVCgrFXPFslkndJiiZbQFTOJASlUKlcDSqxQgaovzjsNzJeDpXBCuJiLhsfzcPgasTTXVADHqpxjjSuvawGCABbdd");
    bool XqBFDAoDR = false;
    int QxijEwbJUJk = -143086932;
    double lpIkwLvlEcas = -1005400.1145276636;
    int DCueuLAhkhIX = 2038329946;

    for (int vqesjwoIEXEGhu = 183669127; vqesjwoIEXEGhu > 0; vqesjwoIEXEGhu--) {
        ZFJwKrtgvviME /= ZFJwKrtgvviME;
    }

    for (int rbngVtR = 1849006883; rbngVtR > 0; rbngVtR--) {
        continue;
    }

    return DCueuLAhkhIX;
}

string HXXKnDYhqXOw::OykerkFj()
{
    double eLiuNRAgyQ = 41485.644562729445;
    bool grhQsueSYauodJym = true;
    double zDoxzCyUzNWdi = 608869.5294971261;
    int tyLFmVErzWQVTWZj = -389544654;
    int AgRyLn = 1441591646;
    bool eGjGdJ = true;
    double asqXdsgshOwRW = 488941.057966143;

    for (int IrmjBnjcZxadPUSw = 836215494; IrmjBnjcZxadPUSw > 0; IrmjBnjcZxadPUSw--) {
        zDoxzCyUzNWdi -= asqXdsgshOwRW;
    }

    for (int oYDoCHVru = 546257863; oYDoCHVru > 0; oYDoCHVru--) {
        asqXdsgshOwRW /= eLiuNRAgyQ;
        eGjGdJ = ! grhQsueSYauodJym;
    }

    return string("ZsFOISgjouFDwStdrBnqcYtVBgggCtkMGzzjdmMxInxTbEgBqPxtgiPWEeRmauvNAHsppIzvygRdiWmJpjHyHOumaiqEIpoaOlQwBOMCxvAtAflNLlhZnZUEtNHGrFtnuMDTtZezWHPATsHbHUFLxAMjrSwAHXowbSKnVGaUMqeaWrOiyLf");
}

void HXXKnDYhqXOw::semPJgnBbIGjK(int MouKayOj)
{
    int oBrvjztGOs = 1774047727;
    double BhzdpJZbvcomsabt = -702168.4983320726;
    bool cAFbUpWiiz = false;
    double urYiJlgphnnWqoj = -8606.17311012591;
    int YCjpPHCTOhzQALV = 831881146;

    if (oBrvjztGOs <= 1463799650) {
        for (int RvYuGtYCXquA = 1862305905; RvYuGtYCXquA > 0; RvYuGtYCXquA--) {
            MouKayOj += oBrvjztGOs;
            YCjpPHCTOhzQALV += MouKayOj;
            urYiJlgphnnWqoj -= urYiJlgphnnWqoj;
        }
    }

    if (urYiJlgphnnWqoj > -8606.17311012591) {
        for (int yaHBLuRi = 1236853033; yaHBLuRi > 0; yaHBLuRi--) {
            oBrvjztGOs *= YCjpPHCTOhzQALV;
            BhzdpJZbvcomsabt *= BhzdpJZbvcomsabt;
            YCjpPHCTOhzQALV -= YCjpPHCTOhzQALV;
        }
    }

    for (int YGocerdJMg = 890978316; YGocerdJMg > 0; YGocerdJMg--) {
        MouKayOj /= MouKayOj;
        YCjpPHCTOhzQALV *= MouKayOj;
    }

    for (int OITwzndSAIlTbYo = 409274161; OITwzndSAIlTbYo > 0; OITwzndSAIlTbYo--) {
        cAFbUpWiiz = cAFbUpWiiz;
        oBrvjztGOs -= MouKayOj;
        cAFbUpWiiz = ! cAFbUpWiiz;
    }
}

void HXXKnDYhqXOw::jwrzgptIOXzFxo(string HDbruRntMq, bool WnMGUALAtCDW, double akZQeWZljWP)
{
    bool yNWtUxa = true;
    int ICpxx = 359586751;
    string LHSQPlIOsd = string("Q");
    int ziCtzOlhfSAyRe = 571929507;

    for (int NrcPY = 1017597580; NrcPY > 0; NrcPY--) {
        akZQeWZljWP /= akZQeWZljWP;
        WnMGUALAtCDW = WnMGUALAtCDW;
    }

    for (int UIRMMVnZUgeL = 1567332532; UIRMMVnZUgeL > 0; UIRMMVnZUgeL--) {
        LHSQPlIOsd = HDbruRntMq;
    }
}

int HXXKnDYhqXOw::aSTxCtMucYFi(double hNHTNScrzLcVDzpZ, string iEtUriJjyk, int mirBQJbAga, double vKTkyVzjAjaiqJBS)
{
    double wiYLyogWP = -825293.4142038787;
    bool QuTLJxv = false;
    bool lehyIR = false;
    double pDMDyuKRQFOpCrg = -877531.2838341206;
    int lnHDN = 246378762;
    bool ZoUuQIdYQzJMHaVD = false;
    bool IYhQYOeCTOiA = false;
    string SlhETqtCqrvnjCSH = string("jcFVOYuqEpviWFeUTQKvUxuDagKtXswEXybE");
    bool FbOYKPUFsU = false;

    for (int HmtKsKRYGBx = 1327446253; HmtKsKRYGBx > 0; HmtKsKRYGBx--) {
        hNHTNScrzLcVDzpZ /= hNHTNScrzLcVDzpZ;
    }

    return lnHDN;
}

string HXXKnDYhqXOw::bUlWglCQlNBDBB(bool BjoxhdLPibEo, double nvNEXoKfMKYw, string TqNViAAIbFQOJPOV)
{
    string lcMRX = string("vXyqStJFxMAVjPYLLCyGQdyzlJJgsUSxzOErbCKWsVjDLlzUCtciRfvHrzWlMHKwYLcbEmQQNKBsFofgGgBTsSxSdaBtf");

    for (int CCcALTFBKs = 1018535623; CCcALTFBKs > 0; CCcALTFBKs--) {
        lcMRX = TqNViAAIbFQOJPOV;
        BjoxhdLPibEo = ! BjoxhdLPibEo;
        lcMRX = lcMRX;
    }

    return lcMRX;
}

string HXXKnDYhqXOw::JCwRVEvoW(string SpOMf, double bjXJInhzOAXfb)
{
    double uaYnAycY = 822919.9601142419;
    double dHjczzbWm = 30256.411882997592;
    string lKQfbfefYTDDWbPS = string("JntALYzLfauiQGEoRZPwDjAntKUzNeXHrUFRkLjvVOhMTqgPHDyNAjfVqEwfnINzqAwOpWhjshWRGJrfhsofpikbtpcFzNpVZqivasUBwMObSdzzniKlxDBLQlcxhIJXqmuuugnCtsRJSsrXgtpoLcGkdALXYGYPsgBcFNzJcQJUYFCIroidNXOQdWHVhpYQPLGWzNLisRJKDhQjtcAZOMBMhiAmCknCTScHFhInaBVx");
    string EKCkCcOPIWTpn = string("zglgsjqvufFlJSALCpyJqkMzxSeSxIVvadlUUZWXEYSKBHvugGbWfKxdJZtBRrdffQJhRwgnSC");
    double pMsHutRrtTLNHr = 589404.7383810024;
    int xeWxu = 818550154;

    for (int HlwEoaDvLfyUyVm = 1586246675; HlwEoaDvLfyUyVm > 0; HlwEoaDvLfyUyVm--) {
        pMsHutRrtTLNHr *= dHjczzbWm;
        SpOMf += EKCkCcOPIWTpn;
    }

    return EKCkCcOPIWTpn;
}

bool HXXKnDYhqXOw::hILPlENg(double oOrpyefPKQoMW)
{
    string HDBZg = string("DdIKnRcQzheSUQOmBTqFaXzGeZMnvaoNeITznPzHVgh");
    string blMOCHta = string("OvpESPdgBerDXJMAXcGeGvkSbObiTkFBVbyGMmConJlOPwcbCSlzsDXnhuvOOScJKNVWzTZUNharhoybxplxierKleosPWJdAjpFJcyEVwhyTILzAFIJYKOB");
    int mjSbm = 207814072;
    int GOVVgL = 1989829991;

    if (mjSbm == 1989829991) {
        for (int bfMtDGagZEfVRscB = 1732325102; bfMtDGagZEfVRscB > 0; bfMtDGagZEfVRscB--) {
            mjSbm /= mjSbm;
            mjSbm *= GOVVgL;
        }
    }

    for (int VhfYXGPYLgDmJ = 908571555; VhfYXGPYLgDmJ > 0; VhfYXGPYLgDmJ--) {
        continue;
    }

    if (mjSbm != 207814072) {
        for (int eApoaxWNh = 2077315627; eApoaxWNh > 0; eApoaxWNh--) {
            blMOCHta = blMOCHta;
        }
    }

    return true;
}

void HXXKnDYhqXOw::iZRyNONyUpXStu(double nnCbp)
{
    int VbHtayZtyZP = 699566620;
    bool cToSJtKnpUU = false;
    string nloKzO = string("hNXhNkEOCrvjomzbhAfYIzqnvnAbrEzuXvILxIvhCLSUxRxTzLQvIslScMvqqcqwnyuJPDuYRlZiLozYvZVEMZmYGPaWSZtMXjxXkJGzwRXvRBlAxZeWUWzxXdyplBaQaNuGXcwBooZhJvMoeBjELxGckqmcxJuZZLPPMohERucKGKotuhEdkntvBuhhpwKquHhmLLFxeOroxwhILLfNatLrSEruSceGJRLnJzhNSqmKwKMpzGkbcXlPjCJakt");
    double fHsoYWNZDQilSF = -381144.99973827053;

    for (int cShjeyFWuErTHJH = 906123698; cShjeyFWuErTHJH > 0; cShjeyFWuErTHJH--) {
        fHsoYWNZDQilSF += nnCbp;
        nnCbp -= nnCbp;
        nnCbp -= fHsoYWNZDQilSF;
    }
}

void HXXKnDYhqXOw::WUfcyh(bool cLCMfqOrXESezfs, string GIEkY)
{
    double aDmYSdR = -806743.5557664047;
    bool weuNnuueniOA = false;
    double ugfsarIgUCg = 472000.54630268697;
    string uphZFoyeseGq = string("MNuUAaNDMYysBzDxMXDzKddvBJvvJpapLpkVQYeneLiykmlkJLxRzrPhahyKJDBChWSgxbksqWJuOZXtyTDwkdHvwjlNhbvYeXwEyunabyqpCPqnsJoFbLVwVNAsvxwlmEgSVcuhlPDpxsOZQIvbxTCiqHXddGMANKdsaDZUERWYpdJJIKzZQicvctkfGQNnxFprgTudkintcfXPjYCQjcEPqqhJkQCJzNnZMHzXv");

    for (int IYqEEyqoc = 10070491; IYqEEyqoc > 0; IYqEEyqoc--) {
        continue;
    }

    for (int WWpzTTjMTr = 251865552; WWpzTTjMTr > 0; WWpzTTjMTr--) {
        ugfsarIgUCg += aDmYSdR;
    }

    for (int RpdlNk = 742789646; RpdlNk > 0; RpdlNk--) {
        GIEkY = uphZFoyeseGq;
    }

    for (int iQiNH = 1198622855; iQiNH > 0; iQiNH--) {
        GIEkY = uphZFoyeseGq;
        ugfsarIgUCg *= aDmYSdR;
        weuNnuueniOA = cLCMfqOrXESezfs;
    }
}

HXXKnDYhqXOw::HXXKnDYhqXOw()
{
    this->FieLquADH(69125.45715600777, 1022737507);
    this->OykerkFj();
    this->semPJgnBbIGjK(1463799650);
    this->jwrzgptIOXzFxo(string("ocQbUOURjAguOhPCweEtQbeCuyTDalxaERJyzFfjxzRSlmceucTBbDVtlCjmyjqcPyRrGrxPzWbqBfdxnCUzEYrmlWKiNZsCjsEmTDfBZpsRlcKDVZB"), true, -595257.7542274061);
    this->aSTxCtMucYFi(192190.46221774296, string("HOzkrPLErcFapSvTXaFcLDaynnLPs"), 1657948194, 1022394.0155506403);
    this->bUlWglCQlNBDBB(true, -259105.95762077742, string("IjfRfWAwlfSbyjzNLHBRtHnjrgTRlJBIZzqDmWdZGpkWCdUIrNGybvGzcElPDLLZwDRaVXjactOiwTggvztCKcJTRAEacqSlvBbAbvPGMFUTCEqZxLbVoyNVZPQwxUreynRZJKGrZNFsWFXITBjryizrfscWGwvUKhPFylkpKqQOcuHnByjqqlojzFFWWsDGAzPuTlsOOQqE"));
    this->JCwRVEvoW(string("ZGpxhkQhUlipJjFsBPlMgIsMjAliJfVUYQPXxTaKgWTYJlreWKdoEPafYPXHiRHVHPmljaSKNEyoZsmsGInLUcmfddXWRtvCTIYnSZneidHOcXhxTPauzcIvCpndgwGEYcyANzkkSXWmpBejedcjREuNdpldFENCdkxxxEoxvjBYIQadylWrNDNcPnayIUWXyyEJiYkvMj"), 906524.0663707744);
    this->hILPlENg(495740.79612953885);
    this->iZRyNONyUpXStu(942121.1654348803);
    this->WUfcyh(false, string("z"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OrPIc
{
public:
    bool HACyhateXujwKB;
    bool AIFggUfAhffia;
    double jxnbNAIhxDM;
    bool CeIDZvEAtjL;

    OrPIc();
    bool XCruZYRR(int kjCyjicJtnuMSc, bool xGhBHrOC, bool wESsp, bool HdJUVJoWzFs, double ifoVhakjt);
    int BuZtU(double oSXPTaYOAROu, double aiYgYRHFTPf);
    string rODZhtywMtKQC(int LTBxMkACHoUNL, string GySJXSuMPqa, bool HbvtIkO, bool xDPSqMBM, double nCcMDjnLCdGQ);
    double ADbHNSm(int muTirPijolD, double LSJXzWiezHXEMq);
    string jlUagImaxZcFz(double uYfjviAtPVBAbg);
protected:
    int LnvpkwHv;
    bool STVtfyPxEXsv;
    string PKtzc;
    double nyABSZD;

    bool uBkwoZiXBtxb(double UqklYvevz, int nNbVkZFMfdJhB, double DujXYepxETJQSS, double lmWjY);
    int BxRsVbvP(string iGmLj, double LJsZvfo, int ZkBRoXVMeYFfR, bool SnRzdwYBSa);
    void MRJfFRgVw(bool WaEYuUc, bool FmntUyl, bool yrmwNgGFwmPBS, string XlWXHI);
private:
    double fOMBITlTPjbvZD;

    void eDKyPSmZJYWvN();
    int TeZkYkFnGpTbqqA(double SAtFqSc, double PUhVdMxTzxs, string bLqIqzZboHhqXrVI);
    int PdygBTefsAIG(int ANKJHWiZkUKyIdbq, bool GqGERqERJBJRwGpY);
    bool dVjZCm(int biFbEKFc);
    bool qFjPyzeJpdB(int cAMTnVfYjnUmTEVf, int PMWakxJakGKSdCv, double mjwRtrpL);
    double Vpdnh(bool IWOmqrjTkpdHgmF, bool gzWgd, int zvuOlgUurTsxLG, string pFitXwdcPmiUEHr, bool ZecLuyiQr);
    string vdwAEYvnH(string EQItzJ, string uGYmtBoxXbnTbB);
    int ulQveCq(double mANJEJuiWZzExvFv, bool rEbEPNKqLtYCOXK, string bZQwtNWprpKK);
};

bool OrPIc::XCruZYRR(int kjCyjicJtnuMSc, bool xGhBHrOC, bool wESsp, bool HdJUVJoWzFs, double ifoVhakjt)
{
    bool NxFVMgrJpfEvsX = false;
    int JGcCSqgy = -1841732896;
    int VbLWpVo = -1571747230;
    string YDTMHIqs = string("lFgccBanLRAPnSTfHTFsRtJptUjQMzYlpxWLtoFXoOHFLKPsAkgLojdyNqxlQwWvBbAESqYckPcyiWeQc");

    if (xGhBHrOC != true) {
        for (int RSmJpa = 1329022164; RSmJpa > 0; RSmJpa--) {
            NxFVMgrJpfEvsX = ! HdJUVJoWzFs;
        }
    }

    if (kjCyjicJtnuMSc != -1841732896) {
        for (int izRfBmZT = 52729181; izRfBmZT > 0; izRfBmZT--) {
            xGhBHrOC = ! NxFVMgrJpfEvsX;
            NxFVMgrJpfEvsX = NxFVMgrJpfEvsX;
            xGhBHrOC = NxFVMgrJpfEvsX;
        }
    }

    for (int dgxeWLswuw = 2115930388; dgxeWLswuw > 0; dgxeWLswuw--) {
        VbLWpVo += JGcCSqgy;
    }

    return NxFVMgrJpfEvsX;
}

int OrPIc::BuZtU(double oSXPTaYOAROu, double aiYgYRHFTPf)
{
    string HYcEncpr = string("QhiGlCoslAgQsqylHSISUxvXuofREOByMSYXBfmPEvxbcNhGxALlEvMRX");

    if (aiYgYRHFTPf == -316325.3544675571) {
        for (int JmZuqR = 1736401955; JmZuqR > 0; JmZuqR--) {
            HYcEncpr = HYcEncpr;
            aiYgYRHFTPf -= aiYgYRHFTPf;
            aiYgYRHFTPf += oSXPTaYOAROu;
        }
    }

    for (int HIZzb = 1696217697; HIZzb > 0; HIZzb--) {
        HYcEncpr += HYcEncpr;
        aiYgYRHFTPf /= aiYgYRHFTPf;
        aiYgYRHFTPf *= aiYgYRHFTPf;
    }

    if (aiYgYRHFTPf < 960108.4245143214) {
        for (int BAvYDKVIK = 1739063114; BAvYDKVIK > 0; BAvYDKVIK--) {
            aiYgYRHFTPf /= aiYgYRHFTPf;
            oSXPTaYOAROu *= oSXPTaYOAROu;
        }
    }

    if (oSXPTaYOAROu >= -316325.3544675571) {
        for (int YaUWNKZzaefuDUGl = 188322501; YaUWNKZzaefuDUGl > 0; YaUWNKZzaefuDUGl--) {
            aiYgYRHFTPf *= aiYgYRHFTPf;
            oSXPTaYOAROu = aiYgYRHFTPf;
        }
    }

    for (int SkXtnOoDnEGyXmM = 617081830; SkXtnOoDnEGyXmM > 0; SkXtnOoDnEGyXmM--) {
        aiYgYRHFTPf /= oSXPTaYOAROu;
        aiYgYRHFTPf /= oSXPTaYOAROu;
        oSXPTaYOAROu /= oSXPTaYOAROu;
    }

    if (oSXPTaYOAROu > -316325.3544675571) {
        for (int mgizefYoLdnvr = 1337881739; mgizefYoLdnvr > 0; mgizefYoLdnvr--) {
            continue;
        }
    }

    return 1549654591;
}

string OrPIc::rODZhtywMtKQC(int LTBxMkACHoUNL, string GySJXSuMPqa, bool HbvtIkO, bool xDPSqMBM, double nCcMDjnLCdGQ)
{
    string nXojBiHPXkZtAHpb = string("porxdrLGvvGpXLYmHgeItIMowXUALBGeJJsavPQwbMahtkVydgCWNXtHyLnaiSXHeqUaIJrebdLfUbvPQRSQKNvXFZpFxaDbgEMUnGOYOOtHbByQRXqyZeNGYodWJsimTABWJMtc");
    int kYOQtdF = 1219347651;
    bool TqckycpKygx = true;
    int QrXEdtYoCaPO = -1487281811;
    bool CyIpqTZOfI = true;

    for (int UOvmHGgLAuDeg = 1741515812; UOvmHGgLAuDeg > 0; UOvmHGgLAuDeg--) {
        continue;
    }

    for (int DnVQJRRdVdLRE = 52477342; DnVQJRRdVdLRE > 0; DnVQJRRdVdLRE--) {
        continue;
    }

    for (int oilayrbTr = 433412112; oilayrbTr > 0; oilayrbTr--) {
        LTBxMkACHoUNL -= LTBxMkACHoUNL;
        kYOQtdF -= kYOQtdF;
        GySJXSuMPqa = nXojBiHPXkZtAHpb;
    }

    return nXojBiHPXkZtAHpb;
}

double OrPIc::ADbHNSm(int muTirPijolD, double LSJXzWiezHXEMq)
{
    string MBfyzg = string("szfWhPlITqdLenUPgoUFLfnILQiVPcFCuCFZFfqWTUOQmSfnEneiyubQsJyAFMhYXeMjYCqSmcwuotLORGpDUEXpvLiYBngMAJYDuULLeXxEfm");

    if (muTirPijolD <= -1596342637) {
        for (int sFXBlkXz = 2026707069; sFXBlkXz > 0; sFXBlkXz--) {
            continue;
        }
    }

    return LSJXzWiezHXEMq;
}

string OrPIc::jlUagImaxZcFz(double uYfjviAtPVBAbg)
{
    bool XkOiBWXt = false;
    string UStKDlnnATmYP = string("WLnTnhqVXzTxPlICSRbBbgPDWVmSWgTrXRYlWDghszbjKwrZQQQlMbtcxuBACXTIePXVnBBZtIMnwcWePoHAegVHcgybOQRUKrgAiXBDpPZJcPqcBpngoqpNqrudhmwPLiVOMfceCGzWHRKYyEHSBzgvfAwlMVSmgYieXgOsHblbkACYAzAxObhPrDNtteyFSAMZOsGsSfVdjHSeTlrYzdnBATsiVEYyWKQuTpZLmNllOcv");
    double tZcNXoUqF = 843986.1340953091;
    string zUoewzGiSHSPpPeF = string("xqvPGQpFzXtgUbXjumviYLSEeVJGfDHhWybwJyfSnxnqMhGoUtygpSKbfOTyAUbDySDCYusqFNqFdFfjTDdUqSaVlezo");
    double OuoakxvEkHwVMMu = 998068.1805972432;

    for (int mRmQjBcrYV = 2033980023; mRmQjBcrYV > 0; mRmQjBcrYV--) {
        OuoakxvEkHwVMMu += uYfjviAtPVBAbg;
        zUoewzGiSHSPpPeF += zUoewzGiSHSPpPeF;
        XkOiBWXt = XkOiBWXt;
        uYfjviAtPVBAbg /= tZcNXoUqF;
        uYfjviAtPVBAbg = tZcNXoUqF;
        tZcNXoUqF -= tZcNXoUqF;
        zUoewzGiSHSPpPeF = UStKDlnnATmYP;
    }

    for (int KTJpcogkvTyw = 1671524585; KTJpcogkvTyw > 0; KTJpcogkvTyw--) {
        continue;
    }

    for (int qQIQrXOkpPY = 1598077983; qQIQrXOkpPY > 0; qQIQrXOkpPY--) {
        continue;
    }

    return zUoewzGiSHSPpPeF;
}

bool OrPIc::uBkwoZiXBtxb(double UqklYvevz, int nNbVkZFMfdJhB, double DujXYepxETJQSS, double lmWjY)
{
    int OkIgrY = -266326926;
    int qYHOoad = -1996845539;
    string IDpTZiQNYuJY = string("crmKSyFpvIdvlltqhGzNcMhKwItgCFIbMMnbFhszZjH");

    for (int PfWpxm = 1058975804; PfWpxm > 0; PfWpxm--) {
        continue;
    }

    if (DujXYepxETJQSS >= -409408.9249310765) {
        for (int zyYxZPTWej = 1066773894; zyYxZPTWej > 0; zyYxZPTWej--) {
            continue;
        }
    }

    for (int SOFjRzjGIZb = 311322315; SOFjRzjGIZb > 0; SOFjRzjGIZb--) {
        DujXYepxETJQSS = lmWjY;
        UqklYvevz += lmWjY;
    }

    return false;
}

int OrPIc::BxRsVbvP(string iGmLj, double LJsZvfo, int ZkBRoXVMeYFfR, bool SnRzdwYBSa)
{
    bool ProtzLOWRc = false;

    for (int uUFDaVaSM = 768877957; uUFDaVaSM > 0; uUFDaVaSM--) {
        continue;
    }

    if (SnRzdwYBSa == false) {
        for (int aSXKrwnbkkTr = 1501660647; aSXKrwnbkkTr > 0; aSXKrwnbkkTr--) {
            continue;
        }
    }

    return ZkBRoXVMeYFfR;
}

void OrPIc::MRJfFRgVw(bool WaEYuUc, bool FmntUyl, bool yrmwNgGFwmPBS, string XlWXHI)
{
    double VPoeEeLIo = 323192.73313996376;
    int uEWWwWuvUxoKQZg = -2035336313;
    bool CFCaZ = false;
    double BkNSZxM = -331919.4942157889;
    double pBfFPIJGIMcJ = 874514.5610275727;
    double DfTTaM = -880990.7493409204;
    int VUKOIaSV = 694736131;
    bool MynwmHkFBuiedpB = false;

    if (WaEYuUc == false) {
        for (int BkkGoUXXODRMAitv = 924778031; BkkGoUXXODRMAitv > 0; BkkGoUXXODRMAitv--) {
            MynwmHkFBuiedpB = CFCaZ;
        }
    }

    for (int DildatQWZANd = 10487342; DildatQWZANd > 0; DildatQWZANd--) {
        MynwmHkFBuiedpB = CFCaZ;
        BkNSZxM += pBfFPIJGIMcJ;
    }

    if (yrmwNgGFwmPBS == false) {
        for (int IRutVLAJ = 906170932; IRutVLAJ > 0; IRutVLAJ--) {
            continue;
        }
    }

    for (int dTTYgbY = 230827695; dTTYgbY > 0; dTTYgbY--) {
        yrmwNgGFwmPBS = ! MynwmHkFBuiedpB;
        MynwmHkFBuiedpB = ! MynwmHkFBuiedpB;
    }

    for (int GDjGx = 275569016; GDjGx > 0; GDjGx--) {
        CFCaZ = ! CFCaZ;
        CFCaZ = ! WaEYuUc;
        MynwmHkFBuiedpB = MynwmHkFBuiedpB;
        uEWWwWuvUxoKQZg += VUKOIaSV;
        VUKOIaSV *= uEWWwWuvUxoKQZg;
    }

    for (int qySsYCoXtWEMl = 2011891769; qySsYCoXtWEMl > 0; qySsYCoXtWEMl--) {
        continue;
    }

    for (int LVizjm = 2043384809; LVizjm > 0; LVizjm--) {
        VUKOIaSV /= uEWWwWuvUxoKQZg;
    }

    for (int SpSeDWrRLgJs = 782853362; SpSeDWrRLgJs > 0; SpSeDWrRLgJs--) {
        CFCaZ = FmntUyl;
        FmntUyl = ! CFCaZ;
        pBfFPIJGIMcJ *= DfTTaM;
    }

    if (DfTTaM < 874514.5610275727) {
        for (int ebsHpgHbruU = 1904207835; ebsHpgHbruU > 0; ebsHpgHbruU--) {
            pBfFPIJGIMcJ /= BkNSZxM;
        }
    }
}

void OrPIc::eDKyPSmZJYWvN()
{
    string veNyKKUJ = string("GdcOhEqzuwiADrpudwEHDaPuYGcFLTKBqVDmkcLivUYYbednsJudOtqGRVwkNusRUaQjlbCyIkgrruJgIOnNFlymfuqYwYPaIEDbwWwPcXrRaQztlJyvAnvGEIqiUpWkfVgXjJsATOTwmfolmtquUAlwe");
    double LcaiihFaAhrjuEZJ = 308540.21695705067;
    int PzTzoRLzPiKr = -1916171382;
    bool eMhtyKklUSJ = true;

    for (int klAMHSsjAUJ = 372489208; klAMHSsjAUJ > 0; klAMHSsjAUJ--) {
        PzTzoRLzPiKr /= PzTzoRLzPiKr;
        PzTzoRLzPiKr += PzTzoRLzPiKr;
    }

    for (int vQGMKABqquvOtMYF = 1189234007; vQGMKABqquvOtMYF > 0; vQGMKABqquvOtMYF--) {
        eMhtyKklUSJ = eMhtyKklUSJ;
    }

    for (int jMbdJvtEfKtQt = 1096505590; jMbdJvtEfKtQt > 0; jMbdJvtEfKtQt--) {
        continue;
    }

    for (int HKeZQuEpnnb = 1536753144; HKeZQuEpnnb > 0; HKeZQuEpnnb--) {
        eMhtyKklUSJ = eMhtyKklUSJ;
    }

    for (int laYVbWbU = 201175071; laYVbWbU > 0; laYVbWbU--) {
        LcaiihFaAhrjuEZJ *= LcaiihFaAhrjuEZJ;
    }
}

int OrPIc::TeZkYkFnGpTbqqA(double SAtFqSc, double PUhVdMxTzxs, string bLqIqzZboHhqXrVI)
{
    int JcFExSeRFcSR = -63239473;
    string SDuYcNCkhfBzkR = string("mfuJdWUocVChBqbSYTLChPnCwonlfThzniVwhHXrmZhfoOwpSToeSunBMDFbCoUHajaG");
    double ZwyFnCahgIK = 949538.9320171084;
    int sSfUzLh = -322152302;
    string KrUexuqYSJbZXs = string("OgovGSqDvHtBCIyvmkETpSYNsYvZTTvwFQanMHsrAHuYntUxnnDyEVTWARwRUtRFmZemIWrtWpuwMMkzkSByGiBCCRJqpsQeYAKPWiVNEdCFEnawidjIFVqdK");
    int diTxTaYaqIJkYu = 128774755;
    double GLjenLCMGUCG = 176949.4908282134;

    for (int mSsjAtCdnTaaX = 1634575652; mSsjAtCdnTaaX > 0; mSsjAtCdnTaaX--) {
        PUhVdMxTzxs -= PUhVdMxTzxs;
        SAtFqSc -= PUhVdMxTzxs;
        diTxTaYaqIJkYu /= JcFExSeRFcSR;
    }

    for (int usJVgP = 1668289131; usJVgP > 0; usJVgP--) {
        continue;
    }

    for (int QfppohBI = 1996170737; QfppohBI > 0; QfppohBI--) {
        ZwyFnCahgIK /= ZwyFnCahgIK;
    }

    return diTxTaYaqIJkYu;
}

int OrPIc::PdygBTefsAIG(int ANKJHWiZkUKyIdbq, bool GqGERqERJBJRwGpY)
{
    string HtesijVIYyBBmcj = string("qzgOZWEJCtaRrzOItsJFLXbPllIErangPNMFDkwuPehdSUalRUnKbhsKXrNFeXuGXLcJZxpKYslsxuiWqUzWUDYvrAMVHeQffGkdceuIWtXJcMCDRfgrujqoTnjTgLqLeJDaNKmQrPpvvxKpnqEqjmWQkUuARLcIOPzOLEVBCAbegZOOEvUAAumhajrjDqJEGdkMazlQIDkaETHDZPDVhPpmgScwTClGc");
    string mfsBXNoL = string("cJvgkCODhWuTJOtYFItuvgJtqEOVJFWiaKpTyhnXiPwKSEBWwPQRNGbAoxxHQ");
    int KTwCHtBZbfvQrKyG = -2013596742;
    double cwXfyGYUiyQ = -56430.15320331189;
    string rYkGqvKTQn = string("MoLelwcjaWBcCXFtnDKEKtrLxBkLWugVZGhocKAPZmiFNDzrewxkidKsossYxdKCuHJGXPqjaXafPhMulEAeUeltVVY");
    bool EKGtkCyM = false;
    string EImIy = string("JnCpEkpDyNcnUfJtmEQfuGrimnkrUMBbEPZxsvmkHSThsAxTecQdFkArnnBCUTbXFMUUgjhsfJaFYBjknQJhUJwpLpO");

    for (int fZGXOxCrDD = 877636185; fZGXOxCrDD > 0; fZGXOxCrDD--) {
        EImIy += rYkGqvKTQn;
        rYkGqvKTQn = HtesijVIYyBBmcj;
        rYkGqvKTQn += EImIy;
        mfsBXNoL += HtesijVIYyBBmcj;
    }

    if (EImIy > string("JnCpEkpDyNcnUfJtmEQfuGrimnkrUMBbEPZxsvmkHSThsAxTecQdFkArnnBCUTbXFMUUgjhsfJaFYBjknQJhUJwpLpO")) {
        for (int pVsBnMUsEr = 317037475; pVsBnMUsEr > 0; pVsBnMUsEr--) {
            ANKJHWiZkUKyIdbq /= ANKJHWiZkUKyIdbq;
            EKGtkCyM = ! EKGtkCyM;
            rYkGqvKTQn = HtesijVIYyBBmcj;
            mfsBXNoL = rYkGqvKTQn;
        }
    }

    for (int IiapiV = 1512661262; IiapiV > 0; IiapiV--) {
        KTwCHtBZbfvQrKyG /= KTwCHtBZbfvQrKyG;
        ANKJHWiZkUKyIdbq = ANKJHWiZkUKyIdbq;
        ANKJHWiZkUKyIdbq *= KTwCHtBZbfvQrKyG;
        mfsBXNoL += HtesijVIYyBBmcj;
    }

    for (int MuvZnNP = 300213345; MuvZnNP > 0; MuvZnNP--) {
        HtesijVIYyBBmcj = HtesijVIYyBBmcj;
        EImIy += rYkGqvKTQn;
        KTwCHtBZbfvQrKyG *= KTwCHtBZbfvQrKyG;
    }

    for (int SJDqoUTWB = 1409370006; SJDqoUTWB > 0; SJDqoUTWB--) {
        rYkGqvKTQn = rYkGqvKTQn;
        GqGERqERJBJRwGpY = ! GqGERqERJBJRwGpY;
    }

    return KTwCHtBZbfvQrKyG;
}

bool OrPIc::dVjZCm(int biFbEKFc)
{
    double lxdAjhFRsOw = -610396.892658037;
    int gSYqUIXRec = -2033321342;
    bool PvhLKPcqGNs = false;
    string pMXOJOd = string("dskxIaqEMhlmNatSwiNccDlqLWlSvtTCdOtedovRuEuppZZuOCXyVhxzhHvteXDzhkObgsrntUlpmaLxZRtquXbsGvaLyLvYsnEzoUBDZmRMVUxBPOnKlAcfotuAwZjJfSLALCuGxuHRQGVVwLUknvTHUZvrYyZcArOArOEfMYrTfeUesQyYfAGsOSaTexmrIrFwqdK");

    for (int TnrQYcXgwUwSQ = 351627946; TnrQYcXgwUwSQ > 0; TnrQYcXgwUwSQ--) {
        biFbEKFc -= biFbEKFc;
    }

    if (lxdAjhFRsOw == -610396.892658037) {
        for (int nzQNJwnT = 1883730870; nzQNJwnT > 0; nzQNJwnT--) {
            biFbEKFc -= biFbEKFc;
            gSYqUIXRec *= gSYqUIXRec;
        }
    }

    for (int xfhzfa = 1863915478; xfhzfa > 0; xfhzfa--) {
        biFbEKFc /= biFbEKFc;
        gSYqUIXRec = biFbEKFc;
    }

    for (int VGrgzoNXof = 1190975995; VGrgzoNXof > 0; VGrgzoNXof--) {
        gSYqUIXRec -= biFbEKFc;
        biFbEKFc = gSYqUIXRec;
    }

    return PvhLKPcqGNs;
}

bool OrPIc::qFjPyzeJpdB(int cAMTnVfYjnUmTEVf, int PMWakxJakGKSdCv, double mjwRtrpL)
{
    double DSMvI = -195551.97305886608;
    int RUHqDqUzLcW = 1261980340;
    double BerbIHVpCZAZKUc = -866605.0660483446;
    double KNZKVopYdNA = -320049.30756809533;
    string ImOsu = string("xWBDGSmlETOkCamJWpoZeDSHOhTNHxGEemjGTdeIhCXaBOvHTWMtyDicWmSXFiLjQpABRwjHKoFwyfhpGrRIqEZVkHjYCiZxPQrzKMPnJDSacpAnzPzbjORUKoySIyrMiTiJRCKgHcQesjfqYqiRjEjfTXSaCJRlwUhYvTkBtMlzZKdpCHkweFkGOxaNIfSvoCLMqZzbVRSEVMgTYhGyvfGkIa");
    int GnenTeQjI = -1485766541;
    int jhqXnjnRb = 895347625;
    int iDbuDwzoTLCuVD = -2105879850;
    string xTngyFds = string("nKtbBhyNViQCvBNUYtvlgefNEATvNaFsiSpYYvsfYdWQrXrhtDKedVQkgTkAOfyXEZKiMJHGJxAJOzrifSdAYUDRjPJCGIzcuXxfHuFGCKjIezyQyttwYtOkFeReVDjlomXZlxhhLpJaYFUxHntfoHaIwORPkkPkWeUDHjefqqTopSIfzfZqIRqCWWsyhRLCFHFRGuXgiUPXrVMEtbJbPRdRhFd");
    double PbXNzikVOVjAlf = 831025.3704235035;

    if (RUHqDqUzLcW >= -1904455970) {
        for (int wNCKODjqaFFxg = 1832789251; wNCKODjqaFFxg > 0; wNCKODjqaFFxg--) {
            mjwRtrpL *= PbXNzikVOVjAlf;
            RUHqDqUzLcW = GnenTeQjI;
            PbXNzikVOVjAlf /= KNZKVopYdNA;
            GnenTeQjI += RUHqDqUzLcW;
            cAMTnVfYjnUmTEVf += GnenTeQjI;
        }
    }

    for (int SssyAc = 1393418202; SssyAc > 0; SssyAc--) {
        RUHqDqUzLcW += iDbuDwzoTLCuVD;
        iDbuDwzoTLCuVD /= PMWakxJakGKSdCv;
        GnenTeQjI += RUHqDqUzLcW;
    }

    for (int fJaWMEyBXDWaZ = 200498410; fJaWMEyBXDWaZ > 0; fJaWMEyBXDWaZ--) {
        DSMvI *= DSMvI;
    }

    for (int idhdEpOq = 690736732; idhdEpOq > 0; idhdEpOq--) {
        PMWakxJakGKSdCv -= jhqXnjnRb;
        RUHqDqUzLcW /= GnenTeQjI;
        KNZKVopYdNA *= mjwRtrpL;
    }

    return false;
}

double OrPIc::Vpdnh(bool IWOmqrjTkpdHgmF, bool gzWgd, int zvuOlgUurTsxLG, string pFitXwdcPmiUEHr, bool ZecLuyiQr)
{
    bool IqmBuCcW = false;
    bool QvRADcEFyPDQmc = true;
    int BzIWp = -1749901096;
    string wGJqSWOSsMd = string("vjg");
    int ruvobdDnwBUwjNox = 524914817;
    double yXhwBiSujpCT = 176499.41204209146;
    string PXHhchaYzgn = string("pwggVuTbrMLTfoaARgftc");
    bool XmHOdxs = false;
    int QuBNlQN = -1433601256;

    if (gzWgd != true) {
        for (int qhDnNNrRabsnG = 2114191155; qhDnNNrRabsnG > 0; qhDnNNrRabsnG--) {
            BzIWp -= ruvobdDnwBUwjNox;
            XmHOdxs = XmHOdxs;
        }
    }

    for (int MlcJCJG = 1110868809; MlcJCJG > 0; MlcJCJG--) {
        IqmBuCcW = IqmBuCcW;
        XmHOdxs = ! IWOmqrjTkpdHgmF;
        IWOmqrjTkpdHgmF = IqmBuCcW;
        gzWgd = ! IWOmqrjTkpdHgmF;
    }

    for (int djSYUAHvA = 1620454011; djSYUAHvA > 0; djSYUAHvA--) {
        ZecLuyiQr = ! XmHOdxs;
        ruvobdDnwBUwjNox -= BzIWp;
        yXhwBiSujpCT = yXhwBiSujpCT;
        wGJqSWOSsMd = PXHhchaYzgn;
        wGJqSWOSsMd += wGJqSWOSsMd;
    }

    return yXhwBiSujpCT;
}

string OrPIc::vdwAEYvnH(string EQItzJ, string uGYmtBoxXbnTbB)
{
    double JsQuNTOWCo = -170486.61408178278;
    string NGPClfmAUiqoSgXw = string("gAIWKSQDACGBScIgHFrjSmTcxXPvFjqKSDKcejjzmXcBiFfakHkBZAUpWhUapndiXLvkZCtfNrJGtifdkpVWiHlEiKNCQBlpTzlgKBuSHudfeBKRTSmHHxsQYFTRypnjMEPOZvcrAFQJfsjDTnsSDFvHcpcZiVmsyEilkHtCTfssAesZLkzOSiMXRMBdKUlFwGhronBBJtaEmlvkImTCkMYvc");
    string wwofQNQ = string("EecxZYUtMzwHkllGzvgtajOfFga");
    string zRuocGkMwNqR = string("BxdqTZkzgBnBzsyOKrlnKeUXtErObFhwfiEgAdKOMq");
    double agIzValMPG = -647716.9832848764;

    if (EQItzJ < string("CyFRSKKtLSviRpDNVQxjNrUqKuNBgsWkslzFWLkkteefITqNNgoLrDtiHtmWKjHhGHsJmGKcWWDuKilKPIrqgeLRdfmNaUuDhZerMskRYWuHevswPLDEudJMbsTRDkEhKVniALEylTXrTDPVMrakGKYKrrTWvu")) {
        for (int owpssDOKlHut = 2007126151; owpssDOKlHut > 0; owpssDOKlHut--) {
            wwofQNQ += NGPClfmAUiqoSgXw;
            wwofQNQ = wwofQNQ;
            zRuocGkMwNqR = wwofQNQ;
            uGYmtBoxXbnTbB += NGPClfmAUiqoSgXw;
        }
    }

    if (uGYmtBoxXbnTbB <= string("EecxZYUtMzwHkllGzvgtajOfFga")) {
        for (int vOhOU = 1440405229; vOhOU > 0; vOhOU--) {
            NGPClfmAUiqoSgXw += zRuocGkMwNqR;
        }
    }

    if (wwofQNQ >= string("gAIWKSQDACGBScIgHFrjSmTcxXPvFjqKSDKcejjzmXcBiFfakHkBZAUpWhUapndiXLvkZCtfNrJGtifdkpVWiHlEiKNCQBlpTzlgKBuSHudfeBKRTSmHHxsQYFTRypnjMEPOZvcrAFQJfsjDTnsSDFvHcpcZiVmsyEilkHtCTfssAesZLkzOSiMXRMBdKUlFwGhronBBJtaEmlvkImTCkMYvc")) {
        for (int YYbFixm = 24897227; YYbFixm > 0; YYbFixm--) {
            NGPClfmAUiqoSgXw += uGYmtBoxXbnTbB;
            uGYmtBoxXbnTbB = NGPClfmAUiqoSgXw;
        }
    }

    return zRuocGkMwNqR;
}

int OrPIc::ulQveCq(double mANJEJuiWZzExvFv, bool rEbEPNKqLtYCOXK, string bZQwtNWprpKK)
{
    double hsLhvhimiFyb = -93603.5452162879;
    int CWzVKWckszhwMBiV = 1669483861;
    string UMazvCbKOHAsYg = string("YWFqPVaVNtDlXUfofpLoOOJOFgekSXyEAfmgOoPvlBiQCWzFpniRSsduANcWlvaQaWSWXAYddGsvGXRLiErGbQOnXJRxxaDaopgxeSNWxaXKTezYNjoWqeuOQenJDQavUEECAdSpSqBsPGgYhVEMAKeeSKgNzLnDMmXcwKnlNkVDJNdMWXIEWcscSiAONhvXXwamvTAexDjZUKgbJdWs");
    bool Ftosekfve = false;
    int EXIKBgjmTnMFIB = 1540726260;
    bool jeGdkqzBHS = true;
    string rcTXOXaaYoI = string("FasYwwMofLAQzvjuum");
    bool QHTjdVbDkpo = true;
    bool MiDiiqzXP = false;

    for (int nBoSTrciQUxdIByd = 457871779; nBoSTrciQUxdIByd > 0; nBoSTrciQUxdIByd--) {
        hsLhvhimiFyb = mANJEJuiWZzExvFv;
    }

    if (MiDiiqzXP == true) {
        for (int kAPoFghP = 916546863; kAPoFghP > 0; kAPoFghP--) {
            rcTXOXaaYoI += rcTXOXaaYoI;
            rEbEPNKqLtYCOXK = ! jeGdkqzBHS;
        }
    }

    for (int ZpGWAXPmWeezem = 1527148129; ZpGWAXPmWeezem > 0; ZpGWAXPmWeezem--) {
        continue;
    }

    if (Ftosekfve == false) {
        for (int lMNQF = 2050031460; lMNQF > 0; lMNQF--) {
            continue;
        }
    }

    for (int etCNKn = 2018937819; etCNKn > 0; etCNKn--) {
        rEbEPNKqLtYCOXK = MiDiiqzXP;
    }

    return EXIKBgjmTnMFIB;
}

OrPIc::OrPIc()
{
    this->XCruZYRR(187121690, false, false, true, -229241.1793120955);
    this->BuZtU(-316325.3544675571, 960108.4245143214);
    this->rODZhtywMtKQC(1153177526, string("gBmWVNUNBrouPNzockMHWMiujUhsvMTOrtojHJUZdUZzkFCszMPmuuElvwpenFAmUqkrwCXRtNthDUaVWTnhpGfTcFWYtitKjhwHPmHlAzLBYUGZkMifqXVMdFiKJSZOmtGuXGXWnupWmvPlBUREHuFKGjzraUFbIYPZvJycMTGQIfKAQnyBpnbNAofLqqFAPHCxmqmMwiyAENKkRhhfxS"), true, true, 58331.862962550564);
    this->ADbHNSm(-1596342637, 6832.016862927417);
    this->jlUagImaxZcFz(753088.7644473118);
    this->uBkwoZiXBtxb(373973.5402453317, -822831665, -409408.9249310765, -210458.44404932685);
    this->BxRsVbvP(string("qPxZAuLEtMdXdrbSkZtsmAocnGFutmXnaZrHmULcwYgeQSCVucpgQqjoGoMmRTBRgNcNczATmshYrcXEMzjVfADudHlFEwUjOTIdzwaYWyACFxAApyREkHauNdWfSFaXhxhpLIfoVUHIpOSgLTmoUMhvjk"), -252972.35891509967, 585043907, false);
    this->MRJfFRgVw(true, false, true, string("MIbFzNhvNRYCmWioxmyyOsmeb"));
    this->eDKyPSmZJYWvN();
    this->TeZkYkFnGpTbqqA(893452.1749745174, 851569.4069213648, string("MvBynJDucaVqDaPEJ"));
    this->PdygBTefsAIG(1965085410, false);
    this->dVjZCm(1597549769);
    this->qFjPyzeJpdB(2080876562, -1904455970, 437207.8889624937);
    this->Vpdnh(true, true, 400111092, string("XZmoruUQkHmBgrZYhNKetifnXhkuTLrZAWrZciZIquFPPkrR"), false);
    this->vdwAEYvnH(string("CyFRSKKtLSviRpDNVQxjNrUqKuNBgsWkslzFWLkkteefITqNNgoLrDtiHtmWKjHhGHsJmGKcWWDuKilKPIrqgeLRdfmNaUuDhZerMskRYWuHevswPLDEudJMbsTRDkEhKVniALEylTXrTDPVMrakGKYKrrTWvu"), string("SyydjLHSzDdWsMKPmyErnntTZLEUtFqgDzGnurREYTdUxqxNnPmVSRN"));
    this->ulQveCq(-36630.18197069746, true, string("YMafMMSvTaQjwmBMtRcUrnGGYZxheOVbLMqrQiMDpfWRlJEAjnalKaPVTrOSmttOopNxDAatufTIHHIKTZAqKSREeCMgBTSmofYZZgBBeIDZkFgWAJetJryzhCjsBBPhkpFZkTNtdwTRcSfHxWVOfJiTFdRXgpfSoahIOXLlBRKlgsLPFvLRrozCainXbiLIAaFLFDFxWEcrVVcCUCLxUmHDm"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XqtxgIJ
{
public:
    int SndaG;
    int iuEFDNpTA;
    bool cHSjuDfrnAwLjzG;
    int efMJTqRQDcz;
    string QgtCrGGnTrTq;

    XqtxgIJ();
    int glTAVC();
    string RYqWnYqZJXSet(double wXAXrYzvnLZjQ, bool bqYXAIOqR);
    string yOBdyjAdCxILOk(bool dlpYHvCuiWklry, string KsqcuLFiP, bool FGNnw, bool BywrQ, bool iMYNKNnj);
    double QAIGddXOXEOl(int PHEcBabvEL, string ptVfHpU, int CRBPHULXwYh);
    void ZBRgUZTtfKqOI(string FwSJjas, double GhhtTQmvBr);
protected:
    int pSeCdWmCaWJajD;
    string GDJVm;

    int zTsqquDGFRkpUs(int BXJCKnCs, int XzccM, double eLQfVi);
    double QwxzhPEiZPhKz(int MyoyHLKyULat, bool fccJQTayWSE, int vJBueziFqmaNCRb, bool WKvfs, bool zczZKpBbeL);
    bool jcKtGhaQe();
    string tqFUT(string gqQwZnNwY, bool RlAEVOf, string qLSNCgGiKUn, string yLZWJoScKHOvkm, double vvSsmQo);
    bool MbCJAOxxsmw(bool GuNeIyJIgEkYmwh, double UjPqPxSLkjtgIls, double JYVneBzN, double FSfeACBsLsUYUTXa, string ewNhnplNiPx);
    double bvbNvrMQTwHof(int LHmipJWzlt, string JvFyP, int BZpzFAW, int hhPePhXbVEKx);
    double icigQpXBzuKQBmHA(string OtLQQskzDhgVZ, bool YqrhMymT, string XDuCNmamriuMBDh);
private:
    int Tudcr;
    double qcrAkpSII;
    double qQoKbaERbFSFp;
    int hKGdklZRXMrMP;
    string WfGLjzvLg;

    void wnAByhTTr(bool dCakHFmoASLc, bool MDfDlb, int zsuePwHBuDkrGXV, bool kDqCgFu, bool wQaLtiaNGRsxxMr);
    int JXYVPJP(double MqpWoBA);
    void iUEBiu();
    bool YVPmmDcYx(double OLTyXDgMPLD, int wowktLEQ);
    string JXoBOO(bool OiMqRwJX, double GaOCxdmDu, double RxtwuhTtZoCCNtKu);
};

int XqtxgIJ::glTAVC()
{
    double KteWWgLz = -432102.46561958693;
    int xizeKEwU = -455652536;
    int gvrPtZg = -552151826;
    int yukSQAZcS = -2062261817;

    for (int BphqTBxdrozzYFb = 847579948; BphqTBxdrozzYFb > 0; BphqTBxdrozzYFb--) {
        gvrPtZg *= xizeKEwU;
        gvrPtZg += gvrPtZg;
        yukSQAZcS += yukSQAZcS;
        yukSQAZcS += xizeKEwU;
        yukSQAZcS *= yukSQAZcS;
        yukSQAZcS = xizeKEwU;
    }

    return yukSQAZcS;
}

string XqtxgIJ::RYqWnYqZJXSet(double wXAXrYzvnLZjQ, bool bqYXAIOqR)
{
    int HWJwH = -668291123;
    double iOEfHaajdXnK = 530526.1357091453;
    string BrgiTO = string("Xzgd");
    bool rLIyOh = false;
    double SsNfwujTR = 294704.7656838804;
    int SCgSKlzSsLV = -1915902553;
    int tWRavTqGw = -2116303045;
    int TJQBCmDRd = 640721896;
    string WSjKKmC = string("wApuFVadLM");

    for (int GcrDStyWWJRUL = 1593465251; GcrDStyWWJRUL > 0; GcrDStyWWJRUL--) {
        continue;
    }

    for (int chmGxvSq = 1631294972; chmGxvSq > 0; chmGxvSq--) {
        TJQBCmDRd *= HWJwH;
        bqYXAIOqR = rLIyOh;
        TJQBCmDRd *= tWRavTqGw;
    }

    if (SCgSKlzSsLV < 640721896) {
        for (int WYiTLTGs = 1200444868; WYiTLTGs > 0; WYiTLTGs--) {
            rLIyOh = ! bqYXAIOqR;
            HWJwH += HWJwH;
        }
    }

    for (int yGUIzcyD = 1545403736; yGUIzcyD > 0; yGUIzcyD--) {
        iOEfHaajdXnK *= wXAXrYzvnLZjQ;
        TJQBCmDRd = SCgSKlzSsLV;
        HWJwH += TJQBCmDRd;
        bqYXAIOqR = bqYXAIOqR;
    }

    for (int yxcXINUQHbLO = 359130633; yxcXINUQHbLO > 0; yxcXINUQHbLO--) {
        TJQBCmDRd -= SCgSKlzSsLV;
    }

    return WSjKKmC;
}

string XqtxgIJ::yOBdyjAdCxILOk(bool dlpYHvCuiWklry, string KsqcuLFiP, bool FGNnw, bool BywrQ, bool iMYNKNnj)
{
    int dtuDw = -1162815357;
    bool YphLYEGgbudOoIDE = true;
    double adekrdWuAwDMs = -168174.8000041983;
    bool tMbUhVpM = false;
    double MGYOHZOn = -263471.30556028633;
    double cThFuRQskGin = -917609.4232568438;
    double pYQUvKSiwMSCEzV = 352142.352103243;
    bool qNZCignBDXeJ = false;
    bool MxYpdRUKL = true;
    double qpTzWHYsvdmRwvG = 636874.8010648182;

    for (int UIzNqj = 1999729708; UIzNqj > 0; UIzNqj--) {
        cThFuRQskGin /= qpTzWHYsvdmRwvG;
    }

    for (int QVDVbATlmhKkLsi = 1855563026; QVDVbATlmhKkLsi > 0; QVDVbATlmhKkLsi--) {
        continue;
    }

    for (int fBlxwL = 1679761767; fBlxwL > 0; fBlxwL--) {
        tMbUhVpM = iMYNKNnj;
        tMbUhVpM = ! YphLYEGgbudOoIDE;
        iMYNKNnj = ! FGNnw;
        BywrQ = ! YphLYEGgbudOoIDE;
    }

    return KsqcuLFiP;
}

double XqtxgIJ::QAIGddXOXEOl(int PHEcBabvEL, string ptVfHpU, int CRBPHULXwYh)
{
    double RHxVfPUpGhBoKWKo = -136632.65614587453;
    int mTbqKVL = -1543870567;
    double fwXzQ = 633754.1194112835;
    bool OrNGuIQYaFeqCI = false;
    bool MOQmYqHl = true;
    bool sjYHNyQOEH = false;

    return fwXzQ;
}

void XqtxgIJ::ZBRgUZTtfKqOI(string FwSJjas, double GhhtTQmvBr)
{
    int LvdoElGl = 2110741657;
    int ppWlaoGAgb = -2144871986;
    bool aveCRQg = false;
    string jLraiNq = string("FlwOlFsBvbemeoQLpkpdjiRTXWxtEbpiGLNxcDQVdqahXzXZTrkeYXIvxCeGDYfxbCsHUogBQSXePLHgEYNkTRHkPXvaNGzYoJjiHdbsQbVaNdchcGFtAGJlimtSpLehERnWZbPzNVQvDcVhpoEOOsfSxBFcqDlCBocYZQjyHDiwjuMQZwujnovHIKpLQDoyjqwiEOJeyJnRbDQRxOTwRxyDbOAbEgbwfOKOKcFainXYIAWOjXFMPN");
    bool QggKtcKP = true;
    bool OVgrXnEiSOKumRV = true;
    int YrBBMGdPPn = -1158087074;
    string UyqJPhLxGAVdniws = string("CNEPzEbsLzJvUfXlXqCfeskvibaKYtjExnTVGPzVOydtSlysGVWKKUjiPMnYtLzcdakwRUrmhVarUccBAGBGEQNdeRYkkIodkxnrAPZw");

    for (int xKOVUxtaxbeC = 1764337188; xKOVUxtaxbeC > 0; xKOVUxtaxbeC--) {
        UyqJPhLxGAVdniws += jLraiNq;
        jLraiNq += jLraiNq;
        LvdoElGl -= LvdoElGl;
    }

    if (YrBBMGdPPn != 2110741657) {
        for (int GtfyCa = 414706746; GtfyCa > 0; GtfyCa--) {
            continue;
        }
    }

    for (int czbWkZJiQ = 1211116678; czbWkZJiQ > 0; czbWkZJiQ--) {
        continue;
    }

    if (QggKtcKP != true) {
        for (int ccmQPSQpMIv = 989173153; ccmQPSQpMIv > 0; ccmQPSQpMIv--) {
            QggKtcKP = QggKtcKP;
        }
    }

    for (int djAeUYN = 1282770859; djAeUYN > 0; djAeUYN--) {
        ppWlaoGAgb /= YrBBMGdPPn;
        QggKtcKP = ! aveCRQg;
    }
}

int XqtxgIJ::zTsqquDGFRkpUs(int BXJCKnCs, int XzccM, double eLQfVi)
{
    int DwDFVraXZILhvAo = 952313323;
    int PhUhU = -479304241;
    bool sRiljQxydost = false;
    double TahatZtmcjRXuqT = 848913.3988287864;
    double YYKPsRicI = -274453.3191981012;
    double lVLkwTancTZSW = -1033135.0888197853;

    for (int OZVCHnfOpIvQySF = 1104693292; OZVCHnfOpIvQySF > 0; OZVCHnfOpIvQySF--) {
        YYKPsRicI *= YYKPsRicI;
    }

    for (int zKsHpw = 1484600164; zKsHpw > 0; zKsHpw--) {
        lVLkwTancTZSW += eLQfVi;
        BXJCKnCs += PhUhU;
    }

    if (eLQfVi <= 459408.7891965043) {
        for (int cVDSjO = 356847779; cVDSjO > 0; cVDSjO--) {
            XzccM /= XzccM;
            sRiljQxydost = ! sRiljQxydost;
            YYKPsRicI /= lVLkwTancTZSW;
        }
    }

    return PhUhU;
}

double XqtxgIJ::QwxzhPEiZPhKz(int MyoyHLKyULat, bool fccJQTayWSE, int vJBueziFqmaNCRb, bool WKvfs, bool zczZKpBbeL)
{
    string TpHZDeaTrJHQMH = string("zDOKXcoUvNbmIvHYKuWcauuPsYNMHFZVvUQDMKHNJhxzyIFySoTDRrOgQCcelyrSNFppmpKkmMmVwIcQBVHthEqFEBECqaExsgCOZSGoNJwxbDbujAvpANdOUqgUNyTxokKqGXhNjEWuCFajaEzqdXMuZoCFeVZYoQbvLiqFhfjUfnfmeaFwYfnAhuGaALjWAzmPGPfBEaVGsnmnVPUiHpRPwWP");
    bool Qpxbw = true;
    double MeYNXClhUkYge = 127421.53813584862;
    bool VLshbYmJC = false;
    string RQGQHXtQdurXDays = string("CWtBCEQGGbDQgrqgPhhyPChUOaVCbDscYtSvCaUgDFGugETtyREAmDbOyvleMABchVlCwirVDiYHcORztwZDcZOAkrMhCkhvzzwVIwjhjwdURAMrrYZirTNFOFqfRQGDuxLXXpEdnAbyEWXDMggbmBqTTgtBKTcnAzKQdCJxoQfqWwtrhswZtcSnSrRbjhMLrDFpQKRKTcdkRGKBTNChpyRlLiCcNrhJfQkxVOkFMUVmTiN");
    double PlZIKJTytOFULY = 488426.1009994934;
    int SpLKnf = 1748250026;

    for (int ZTkaAzqgfvEuHvB = 1745529488; ZTkaAzqgfvEuHvB > 0; ZTkaAzqgfvEuHvB--) {
        MeYNXClhUkYge /= MeYNXClhUkYge;
        WKvfs = ! WKvfs;
    }

    for (int ZZDBKWCIawETUqkK = 1074714224; ZZDBKWCIawETUqkK > 0; ZZDBKWCIawETUqkK--) {
        VLshbYmJC = ! Qpxbw;
        TpHZDeaTrJHQMH += TpHZDeaTrJHQMH;
        Qpxbw = zczZKpBbeL;
        Qpxbw = WKvfs;
    }

    if (VLshbYmJC != false) {
        for (int WitMAPrF = 304898129; WitMAPrF > 0; WitMAPrF--) {
            fccJQTayWSE = WKvfs;
            VLshbYmJC = fccJQTayWSE;
            fccJQTayWSE = ! VLshbYmJC;
        }
    }

    for (int pNsOMRS = 35878176; pNsOMRS > 0; pNsOMRS--) {
        zczZKpBbeL = ! VLshbYmJC;
    }

    return PlZIKJTytOFULY;
}

bool XqtxgIJ::jcKtGhaQe()
{
    bool kDuuMlhV = false;
    bool FSxQMWmTxpLjcYg = false;
    bool dvveSypZFF = false;
    bool wheYeD = true;

    if (kDuuMlhV != false) {
        for (int ipvAtymxvIz = 843662201; ipvAtymxvIz > 0; ipvAtymxvIz--) {
            kDuuMlhV = FSxQMWmTxpLjcYg;
        }
    }

    if (FSxQMWmTxpLjcYg != false) {
        for (int qjPCAYKnac = 1075828035; qjPCAYKnac > 0; qjPCAYKnac--) {
            wheYeD = ! FSxQMWmTxpLjcYg;
            dvveSypZFF = ! kDuuMlhV;
            FSxQMWmTxpLjcYg = FSxQMWmTxpLjcYg;
            FSxQMWmTxpLjcYg = ! wheYeD;
        }
    }

    if (kDuuMlhV == false) {
        for (int hGTKXSnRULwU = 982656350; hGTKXSnRULwU > 0; hGTKXSnRULwU--) {
            dvveSypZFF = ! wheYeD;
            FSxQMWmTxpLjcYg = FSxQMWmTxpLjcYg;
            wheYeD = FSxQMWmTxpLjcYg;
            wheYeD = ! dvveSypZFF;
            wheYeD = dvveSypZFF;
            FSxQMWmTxpLjcYg = wheYeD;
            wheYeD = ! FSxQMWmTxpLjcYg;
            dvveSypZFF = ! wheYeD;
        }
    }

    if (kDuuMlhV == false) {
        for (int RFLutpI = 802390568; RFLutpI > 0; RFLutpI--) {
            kDuuMlhV = FSxQMWmTxpLjcYg;
            FSxQMWmTxpLjcYg = ! kDuuMlhV;
            dvveSypZFF = ! kDuuMlhV;
            kDuuMlhV = wheYeD;
            dvveSypZFF = kDuuMlhV;
            dvveSypZFF = wheYeD;
            FSxQMWmTxpLjcYg = wheYeD;
            wheYeD = ! dvveSypZFF;
            kDuuMlhV = kDuuMlhV;
            FSxQMWmTxpLjcYg = FSxQMWmTxpLjcYg;
        }
    }

    if (wheYeD == false) {
        for (int HnWQSEvSuu = 2088895759; HnWQSEvSuu > 0; HnWQSEvSuu--) {
            FSxQMWmTxpLjcYg = ! dvveSypZFF;
            dvveSypZFF = ! dvveSypZFF;
        }
    }

    if (kDuuMlhV != true) {
        for (int HcCWILZaUw = 144272519; HcCWILZaUw > 0; HcCWILZaUw--) {
            dvveSypZFF = ! kDuuMlhV;
            kDuuMlhV = ! dvveSypZFF;
            kDuuMlhV = dvveSypZFF;
            wheYeD = ! wheYeD;
            kDuuMlhV = dvveSypZFF;
            kDuuMlhV = ! FSxQMWmTxpLjcYg;
            wheYeD = FSxQMWmTxpLjcYg;
        }
    }

    return wheYeD;
}

string XqtxgIJ::tqFUT(string gqQwZnNwY, bool RlAEVOf, string qLSNCgGiKUn, string yLZWJoScKHOvkm, double vvSsmQo)
{
    int efSSAgfaYabHNH = -107322054;
    bool XTBThWLNeHuN = true;
    double LcVtFmchtYU = 469698.8484531012;
    string zHOcRuayX = string("YnKmguxPSULoJcvAnlsZIobWuYxXTTRKNPgPxZtoeIDvzVcHLnrByEvxuAVntqLmcsSgEItRyRVjOqhDooOvNvIYnndkOKUivINyvvZEWDnCvRVRjJWKRkorOUTsyHIETfTJeziavxtLtunvifaBlRjkimSQWcXBLLTFuWZISgLhcYJlTgxFopTBOqnUrtXMLxYbnjqlzosesUJFEeN");
    bool uICdJJcAxrcf = false;
    string WZnISFVHzyazJiI = string("EvwmeScHiemd");
    bool IfQWH = false;

    if (IfQWH == false) {
        for (int rpZfjeZmQOUy = 1714035371; rpZfjeZmQOUy > 0; rpZfjeZmQOUy--) {
            LcVtFmchtYU /= vvSsmQo;
            LcVtFmchtYU += vvSsmQo;
            WZnISFVHzyazJiI += gqQwZnNwY;
            yLZWJoScKHOvkm += qLSNCgGiKUn;
        }
    }

    for (int xDZfLTeZXB = 470795314; xDZfLTeZXB > 0; xDZfLTeZXB--) {
        gqQwZnNwY = WZnISFVHzyazJiI;
        IfQWH = IfQWH;
        gqQwZnNwY += qLSNCgGiKUn;
    }

    for (int TZacqaFYCk = 2123500625; TZacqaFYCk > 0; TZacqaFYCk--) {
        qLSNCgGiKUn = WZnISFVHzyazJiI;
        WZnISFVHzyazJiI += zHOcRuayX;
    }

    return WZnISFVHzyazJiI;
}

bool XqtxgIJ::MbCJAOxxsmw(bool GuNeIyJIgEkYmwh, double UjPqPxSLkjtgIls, double JYVneBzN, double FSfeACBsLsUYUTXa, string ewNhnplNiPx)
{
    bool GLHZQQDnN = true;
    int eukwjYHyKi = -512717186;
    double oLleNCgutBlDaZ = 817044.5890699747;
    double KLVQnWlbiUwxaZg = 328577.49239827134;
    string HppREu = string("iGiHGmNryImtGwcCJHZguYZhROjJaCTozkxApOxLZSQNhKcbTKfwQkDOSUOKCjwtPhxbCTnjbVYGFMFxnQTzseGCUNNcvhrLvbecfmVpGvFysRGQDLnSnsWLTzZIxPhHHdgaFYxeudazNyV");
    int XcHnHE = 20119862;
    int dNJZIebulRhD = 1838481752;
    double UDtgznqpRW = 190103.04404174848;

    for (int HVaXYbAgDViNz = 1267297214; HVaXYbAgDViNz > 0; HVaXYbAgDViNz--) {
        FSfeACBsLsUYUTXa += JYVneBzN;
        KLVQnWlbiUwxaZg *= UjPqPxSLkjtgIls;
        XcHnHE /= eukwjYHyKi;
    }

    for (int wcFAh = 1169617438; wcFAh > 0; wcFAh--) {
        KLVQnWlbiUwxaZg += KLVQnWlbiUwxaZg;
    }

    return GLHZQQDnN;
}

double XqtxgIJ::bvbNvrMQTwHof(int LHmipJWzlt, string JvFyP, int BZpzFAW, int hhPePhXbVEKx)
{
    int WIYHVOjzGQtoISQX = 998807064;
    bool ARkRjFDqnyk = true;
    int adIgtjTtaG = -1142114916;
    bool BtgrSE = false;
    bool pwdEFg = true;

    for (int unRXQBrLPxFTR = 2146282833; unRXQBrLPxFTR > 0; unRXQBrLPxFTR--) {
        ARkRjFDqnyk = ARkRjFDqnyk;
        BtgrSE = BtgrSE;
        WIYHVOjzGQtoISQX += LHmipJWzlt;
        BZpzFAW += adIgtjTtaG;
    }

    if (adIgtjTtaG < -1973442591) {
        for (int hkXKEnjXxtLum = 1891180116; hkXKEnjXxtLum > 0; hkXKEnjXxtLum--) {
            BZpzFAW /= adIgtjTtaG;
        }
    }

    for (int IVZdUhusUWCUAN = 568631247; IVZdUhusUWCUAN > 0; IVZdUhusUWCUAN--) {
        adIgtjTtaG /= BZpzFAW;
    }

    for (int twqvoNGIqUtXLrd = 709083195; twqvoNGIqUtXLrd > 0; twqvoNGIqUtXLrd--) {
        continue;
    }

    for (int VfBCdgSDRLYqkElx = 556906661; VfBCdgSDRLYqkElx > 0; VfBCdgSDRLYqkElx--) {
        pwdEFg = ! BtgrSE;
        adIgtjTtaG *= BZpzFAW;
    }

    return -919941.9792793549;
}

double XqtxgIJ::icigQpXBzuKQBmHA(string OtLQQskzDhgVZ, bool YqrhMymT, string XDuCNmamriuMBDh)
{
    bool qlmznK = true;
    double IozNNJYJ = 39091.8849901303;
    int uPULFWr = 1330461382;
    string tykQjJYKzC = string("CVgvUTThcqAimEvZYmfVehwmOyQHsDHuuEREjSLJusuLUDlavRnvaeYvvXUFDZiowYbTqRcUbcfQxpqFPydXvpEJxJeSK");
    string fzIIMONVas = string("KhPQrKftwIAmJwYLhEHlfsggBHLu");
    double yzaDNHSP = -874874.9282425713;
    double ZsXxCq = -406709.1423016011;

    return ZsXxCq;
}

void XqtxgIJ::wnAByhTTr(bool dCakHFmoASLc, bool MDfDlb, int zsuePwHBuDkrGXV, bool kDqCgFu, bool wQaLtiaNGRsxxMr)
{
    double XwbZl = 570176.865923471;
    int zNGJxydcWgoYG = 1188659325;

    for (int qxIJClJHEfLy = 2050252149; qxIJClJHEfLy > 0; qxIJClJHEfLy--) {
        kDqCgFu = kDqCgFu;
    }

    for (int WicTQWXGPOSPeUI = 2003834856; WicTQWXGPOSPeUI > 0; WicTQWXGPOSPeUI--) {
        MDfDlb = dCakHFmoASLc;
        kDqCgFu = kDqCgFu;
        zNGJxydcWgoYG = zNGJxydcWgoYG;
        wQaLtiaNGRsxxMr = ! kDqCgFu;
        dCakHFmoASLc = ! kDqCgFu;
    }

    if (wQaLtiaNGRsxxMr == true) {
        for (int CoLVPcPZXCce = 233171542; CoLVPcPZXCce > 0; CoLVPcPZXCce--) {
            dCakHFmoASLc = ! wQaLtiaNGRsxxMr;
            MDfDlb = ! MDfDlb;
            dCakHFmoASLc = dCakHFmoASLc;
            zNGJxydcWgoYG *= zsuePwHBuDkrGXV;
        }
    }
}

int XqtxgIJ::JXYVPJP(double MqpWoBA)
{
    bool QXXTTW = false;
    double IDZVslSlWeUhYEc = 610299.8481682806;

    for (int HswmyeueZ = 872734959; HswmyeueZ > 0; HswmyeueZ--) {
        QXXTTW = ! QXXTTW;
    }

    if (MqpWoBA >= 28554.818365566945) {
        for (int pyEMarnNqmdjWCr = 2092316947; pyEMarnNqmdjWCr > 0; pyEMarnNqmdjWCr--) {
            MqpWoBA += MqpWoBA;
            QXXTTW = ! QXXTTW;
            IDZVslSlWeUhYEc /= IDZVslSlWeUhYEc;
            IDZVslSlWeUhYEc -= MqpWoBA;
        }
    }

    if (IDZVslSlWeUhYEc < 610299.8481682806) {
        for (int jLWqkhDWoGZs = 847050413; jLWqkhDWoGZs > 0; jLWqkhDWoGZs--) {
            QXXTTW = QXXTTW;
            IDZVslSlWeUhYEc *= MqpWoBA;
            IDZVslSlWeUhYEc *= IDZVslSlWeUhYEc;
            QXXTTW = ! QXXTTW;
            MqpWoBA += MqpWoBA;
        }
    }

    if (IDZVslSlWeUhYEc == 28554.818365566945) {
        for (int CMrfCffifkNu = 693370574; CMrfCffifkNu > 0; CMrfCffifkNu--) {
            MqpWoBA += IDZVslSlWeUhYEc;
            MqpWoBA *= MqpWoBA;
            IDZVslSlWeUhYEc /= MqpWoBA;
            MqpWoBA /= IDZVslSlWeUhYEc;
            MqpWoBA += IDZVslSlWeUhYEc;
        }
    }

    for (int jccudnXuEmnN = 363869871; jccudnXuEmnN > 0; jccudnXuEmnN--) {
        IDZVslSlWeUhYEc = MqpWoBA;
        IDZVslSlWeUhYEc *= MqpWoBA;
        IDZVslSlWeUhYEc += MqpWoBA;
        MqpWoBA -= IDZVslSlWeUhYEc;
        IDZVslSlWeUhYEc = MqpWoBA;
    }

    return -1935201859;
}

void XqtxgIJ::iUEBiu()
{
    int IShkz = 1715325250;
    double cpgVeMdFH = 707613.6450742268;
    bool LOABwDMq = true;
    double OBKFwrhsrR = -799816.3420263289;
    double ctuEtcUcsLnOR = 969166.0469261108;
    string PpoRFEGu = string("pcYzldxPPvukOERZQDRVQVMTMwoodrjBYrsbyfNcHkvnRcSxPOMrQtzYuMJPlSpZxnwPknkPXrDAaWnwEizxAjbsBxgaWFVPyAMeyHbygdSFeECeUSNBwxYlGyYYJOpYDsgFGuElFZELugfnbBFgqJEVYMRwzwEQVqLKMTIS");
    bool bwbRNddktovIO = true;
    bool wtPpcLUt = false;
    int GriZPlMdwObTsuQN = 1094646477;

    for (int fFKpaCnQLi = 243174452; fFKpaCnQLi > 0; fFKpaCnQLi--) {
        GriZPlMdwObTsuQN *= IShkz;
        ctuEtcUcsLnOR *= ctuEtcUcsLnOR;
    }

    for (int KJYGMSJ = 711538345; KJYGMSJ > 0; KJYGMSJ--) {
        wtPpcLUt = LOABwDMq;
        bwbRNddktovIO = ! LOABwDMq;
        cpgVeMdFH = OBKFwrhsrR;
    }

    if (ctuEtcUcsLnOR <= 707613.6450742268) {
        for (int NweSswIKiv = 1534112457; NweSswIKiv > 0; NweSswIKiv--) {
            continue;
        }
    }

    if (GriZPlMdwObTsuQN >= 1094646477) {
        for (int IgmnLhb = 1474574878; IgmnLhb > 0; IgmnLhb--) {
            continue;
        }
    }
}

bool XqtxgIJ::YVPmmDcYx(double OLTyXDgMPLD, int wowktLEQ)
{
    double NLOkbYMMQ = -838250.6647735974;
    bool iQRYDtIkxbMeD = true;
    bool LyujPsFv = false;

    if (iQRYDtIkxbMeD != false) {
        for (int vOTKzBGgYQmbxXsw = 1824690674; vOTKzBGgYQmbxXsw > 0; vOTKzBGgYQmbxXsw--) {
            OLTyXDgMPLD /= OLTyXDgMPLD;
            wowktLEQ -= wowktLEQ;
            OLTyXDgMPLD = OLTyXDgMPLD;
            OLTyXDgMPLD = NLOkbYMMQ;
        }
    }

    for (int MEwbZHlLXQbdM = 468094603; MEwbZHlLXQbdM > 0; MEwbZHlLXQbdM--) {
        continue;
    }

    for (int uRqugxjLQSvFl = 2047829988; uRqugxjLQSvFl > 0; uRqugxjLQSvFl--) {
        continue;
    }

    return LyujPsFv;
}

string XqtxgIJ::JXoBOO(bool OiMqRwJX, double GaOCxdmDu, double RxtwuhTtZoCCNtKu)
{
    int hiOZEswWKHzk = -1134750261;
    bool rBDAXo = true;
    string ZiDLYI = string("HxYDDcVIKcwSdVRbnxXfGzhYYaynztPHMgEGYlBGmRcoDtYrvUq");
    string VbPbb = string("pWdMPDdFPhaRicmCIuWnJkSHSTorZWiXumQGmKlQvpbkneahTHKjMAyBdnPvSVbBSnconuWdOUFZyJFhbgKTfwqeSAQQbWkglxTbUrziSgTFcMDIhtPtXUtMZrBzyrNAuVLJJoiXloKKhBpNWHXJZhqoMTxrkwzginKrT");
    double SicZHFdRaVb = 424161.6390232915;
    int ITGkqk = 376670473;
    bool yoIkfadD = false;

    for (int tfuRIvb = 710213785; tfuRIvb > 0; tfuRIvb--) {
        GaOCxdmDu *= GaOCxdmDu;
        ITGkqk *= hiOZEswWKHzk;
        OiMqRwJX = rBDAXo;
        ITGkqk *= hiOZEswWKHzk;
    }

    return VbPbb;
}

XqtxgIJ::XqtxgIJ()
{
    this->glTAVC();
    this->RYqWnYqZJXSet(796077.035233917, false);
    this->yOBdyjAdCxILOk(true, string("EjpBfCTmZIupYsCleOgDaEvSzvZPozkFwVYOORbzUUwjAhupPWNWJqZwdAgBUrFoleYvenycUGdsgDZqbKzkexWuJaWoFPfvRzCZqaOt"), true, true, true);
    this->QAIGddXOXEOl(-1673944262, string("EBEhVSzNnlPNJBkekmLBZFgOyilgPhllaLJdsFTaoAojinoKYZSRmbdRaDNyZsHkZcDTWjNHaAODBCWkUrnvAfXQZhcILSvrQaaJNOUyZlNVXKSgZcbSYEmFGcMASOTmmzlBSTdStBVJlDcrSCdeWwbcAWIUoKEUmEiXegrSR"), 534342407);
    this->ZBRgUZTtfKqOI(string("vtfIZdWcPAUjFuYjMtuSNKqVySEoqLcqahhbsZyRuglOGaDQepUWWVtqqWYngKZMZbeVcQujgGVNAM"), -267430.66285284056);
    this->zTsqquDGFRkpUs(-1825108191, -854030492, 459408.7891965043);
    this->QwxzhPEiZPhKz(1290655507, true, -9270343, true, false);
    this->jcKtGhaQe();
    this->tqFUT(string("RHElwvySNTWnDWSABFGSharnKsdtljZObjnMIBHNEhOXlMEHedtraLkqHUjJVJWgzQZHyYPvAOXKwhDbXXtPQEkwCPmIa"), false, string("tFfYUXELZgCOkILShMlqWMsgdehCwiQVwCSpdzwLOSvsDlikDPhdOWqmCPLcpWQjMhSAtbH"), string("ebsduMILXJVyOeWdGBkrrXNmdxcDiHOyclBRhOLndeVhTeHtehYvNogbfHBYhzvDLTevVmYVBqkVSJRFgePElhjLhqNgXcnDUmNtoxYgISwNeFgJgByAAwmmruouIxulWYXljXRFSjvFmeHLTqCAqFwXgfvfugyEfpGLbJNGYwawYBRJjsLMAlMpldYFNqGpgLSBEzQsJaQDJindHFmToAzizItfuyWAIHKLaDkwyR"), -572738.042470062);
    this->MbCJAOxxsmw(false, 887660.3607499199, 240299.94922379323, -802684.6394470939, string("ZvvBWishQxLFJqqwyZXdNabdAHaKeyJYNCeayaJcEAtSHKfrQvSXdrFDZLiedrxgHVmHRwoqLXHAYiLjlmgaXzsmTWbLQuFrKNnQlIFgZQLqnXJPVPFOvhuzzvNztOVibHQUrlYELauHHOGWhnSEXvqiqkBzJPqYhMqyAzwOcGJHKfELyKzyhVvmTqDWQpMyXqNuKIKIRwGyIbICGxlXQNUzxjbquDMWneucezTPllOiktmpUqucyRVeQvYeg"));
    this->bvbNvrMQTwHof(-1973442591, string("MqrGTwTHGwUKChoztOXTFDJiODZJjlMkzjHGRmrnNTLlUFWqecrvVXzSfVIUKRNzbzifXYcSLPQmBAPWcqeXfjWzjyXjVgBqzyynmzBdiHiQZTPGfrPQXQpLGZUtnbPHZjaiSkKuPAlEFb"), 1809776487, -1786958144);
    this->icigQpXBzuKQBmHA(string("iNNIPqwQGbeqghQmbdxJTynmXnbLGJLjpTdyJNtjoZZRmjihPqiGzsJSKiiCqWdNxxCBQfLJlUjtdaXScKdFkOWRjDxUgcNToWdFbaAOHxMXXoWhhZSxCHHwLgcxkFhHuzdjiTHEECuIcnjUuZPAJJLswyWTNeqNvmSpWjjJwxCphnbJOjllBwIYKxAsvpotNHjWeTwMMLJqYJNuGLBc"), false, string("shepZNIWJcEiIgJoLUmsXZAVIKVifJFnRZquKfNOGReCQzbiiRVSDjyKIavpgFotcJhCWKGakKLTENGSVtuLpYYXPUYxhBJpIKUFraMgiChkTpRHCdOLS"));
    this->wnAByhTTr(true, false, -1511876299, true, true);
    this->JXYVPJP(28554.818365566945);
    this->iUEBiu();
    this->YVPmmDcYx(457186.95279694215, -819536345);
    this->JXoBOO(false, -422640.23656530975, -1018958.7275354614);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YRqWFDOdE
{
public:
    bool mPLIjWa;
    bool TzoUMlfDtz;
    int DWqHspYKYnx;
    double NqOfGc;
    string OwDOeGaSFvOeh;
    int WMNHHmtzQiEgHJ;

    YRqWFDOdE();
protected:
    bool rxZaNXkW;

    double OwYjyiSw();
    double bdRvHkylmNXV(string ankwspAFEYQHBW, string cXgBXs, bool NBnZxYvaJf, string LUrwgubDzvSuvTY);
    double sYOaCUqDZoim(int gkHhgISHqcx, double sdJbPCYnksbH, int nyhKuHiQYUZ, bool UpQfBYyGVU);
    void kjBLyPQ(double gsPuYqWzH, bool nMuskpqsNeXJSwe, int KYxejIjIOn, string vPiINDETakZtab, int lApTOtLaGMvv);
    void lSHpQk(bool XgSybtjc, int vgbYftpEOySUPf);
    bool paDjfh(bool rCHbbyzDC, int wZJVzoEX, double VzvdgxY, string HeWCJXhytM);
    double RILDsn();
    bool bIpkvg(string CdcJVLruRmpoR, string FCOil, double yhPBiLBvM);
private:
    int kdXbgAEoz;

    void QgsapsL(string oYoGMTPc, double AzOqjPkjTuiRDXU, string emxYzyQYFYcugUv);
    void bursGJvgVLbiOk(string PNhgPfLUrrwphL, string tGuDt);
    int zoNhO(int seSQTihOCZgQahK, bool YIRabfsUOQbDg, bool WjTqZMBpUMyYnL, int OMykujvK, string YmGbdtKaO);
    int dhBhMIEQgntxJV(string bbqyBemjACCivO, int AMJcc, int BdNpgQZPVVls, bool kzKzKXArTfmAlwO, bool SHizOXSwVoRiykD);
};

double YRqWFDOdE::OwYjyiSw()
{
    bool yMkTUEfCQEwQRNX = false;
    bool LaBFbJ = true;
    string DqZBPlHuAFz = string("CyGntGsJABPmQSUexinNhbncEJNUvJACageuVjdetfhYdMgXJwYaUNHbLWufzPLuTXjLZEFAnzxCtRabivDsnCEFQeEJcTVfiUfgqTTZVOmQTirqFNSCvUXFuoTHcnTUKDmCBEFCWALBZByKVJylzgcmphLkKSRdqUDiDujjyKuRFCViBhMphkWCoOdNEgvIsntMeaErQybxeRrlvzzTwezISmiVyjVMsTXO");
    string yMRZnQsNrtt = string("RlzODhFnKTPnsNgXMeuIAGWkPrrGqJzqWXAycKusZCjYEpZTmWTFFPHvKRYhAiwOpCnjqvjpVNklPAnuEcBifohUFODWbUbeGCPA");
    double FvEIFvBuc = -135526.2335705091;

    if (yMRZnQsNrtt < string("RlzODhFnKTPnsNgXMeuIAGWkPrrGqJzqWXAycKusZCjYEpZTmWTFFPHvKRYhAiwOpCnjqvjpVNklPAnuEcBifohUFODWbUbeGCPA")) {
        for (int qQRpGDXmGnghfy = 769013268; qQRpGDXmGnghfy > 0; qQRpGDXmGnghfy--) {
            FvEIFvBuc -= FvEIFvBuc;
            LaBFbJ = LaBFbJ;
            yMRZnQsNrtt = DqZBPlHuAFz;
            yMkTUEfCQEwQRNX = ! yMkTUEfCQEwQRNX;
            DqZBPlHuAFz = DqZBPlHuAFz;
            LaBFbJ = LaBFbJ;
            DqZBPlHuAFz = yMRZnQsNrtt;
        }
    }

    for (int dzhqfWPWbhDDtq = 136565655; dzhqfWPWbhDDtq > 0; dzhqfWPWbhDDtq--) {
        yMRZnQsNrtt += yMRZnQsNrtt;
    }

    if (yMRZnQsNrtt < string("RlzODhFnKTPnsNgXMeuIAGWkPrrGqJzqWXAycKusZCjYEpZTmWTFFPHvKRYhAiwOpCnjqvjpVNklPAnuEcBifohUFODWbUbeGCPA")) {
        for (int RGUOkDNvaETnnOtj = 958107606; RGUOkDNvaETnnOtj > 0; RGUOkDNvaETnnOtj--) {
            yMkTUEfCQEwQRNX = yMkTUEfCQEwQRNX;
            yMRZnQsNrtt += DqZBPlHuAFz;
        }
    }

    return FvEIFvBuc;
}

double YRqWFDOdE::bdRvHkylmNXV(string ankwspAFEYQHBW, string cXgBXs, bool NBnZxYvaJf, string LUrwgubDzvSuvTY)
{
    bool LbujbbXbZGxGwh = true;
    double mmuyzM = 674899.6364822803;
    double JmpuPPooEjZfeGNZ = -637454.9334216905;
    bool FDjAacvPu = true;
    bool PIsizz = true;

    if (cXgBXs > string("hmebBANXyRLTwjBgIIBkyQnakWhYJNtVciTYlfYBuHTrtdTUTTlrycEkITkmbCFSuFkxAKKvNyeMGdjjMIpQWFpGbRTToRZCACgBiKbjkxWBqtzHjJYIQgTvYRcXJuJJdDYpLUXNGTTnRDSdhzhEWFwvKdpJfuSdLwFVZrgRbakoQDDZpiyJ")) {
        for (int KgUEfFdHlCLRNj = 63635638; KgUEfFdHlCLRNj > 0; KgUEfFdHlCLRNj--) {
            mmuyzM = JmpuPPooEjZfeGNZ;
        }
    }

    for (int lfJIpkqdQuxs = 1099811481; lfJIpkqdQuxs > 0; lfJIpkqdQuxs--) {
        PIsizz = ! NBnZxYvaJf;
    }

    for (int GkfYjS = 776481852; GkfYjS > 0; GkfYjS--) {
        cXgBXs += cXgBXs;
    }

    if (LUrwgubDzvSuvTY == string("sXrlzPbZpYoBDIcJKpnYNHtFtnKfhXXpIJGQqLVzYtCWeAFsYewNXSxcYVXbTckRhIxSMpWLBkLxLdhHAZGcpnUITnACbTdCcsFjNOqOlLbAZlETfPtMLalpIMFMJDHuWxGyggvpnuNFQZCBUzsneExCBqEiKFwcFpIfdJNNXPDfmhbXsPnnOjFj")) {
        for (int qfSNCFDExFn = 212807044; qfSNCFDExFn > 0; qfSNCFDExFn--) {
            continue;
        }
    }

    for (int QpoKljKipW = 1018836411; QpoKljKipW > 0; QpoKljKipW--) {
        FDjAacvPu = PIsizz;
    }

    for (int VJCrZtjKpY = 1351457699; VJCrZtjKpY > 0; VJCrZtjKpY--) {
        LbujbbXbZGxGwh = ! PIsizz;
        NBnZxYvaJf = ! PIsizz;
    }

    return JmpuPPooEjZfeGNZ;
}

double YRqWFDOdE::sYOaCUqDZoim(int gkHhgISHqcx, double sdJbPCYnksbH, int nyhKuHiQYUZ, bool UpQfBYyGVU)
{
    bool wcDdAqG = false;
    double ZzfVAYFwm = -1021539.9895598536;
    bool PYEPGaEpvsF = true;
    bool xihVFWFY = true;
    int CFfnAutFNJSdr = -2069334593;
    bool JDXPrTwzdSeN = true;

    if (nyhKuHiQYUZ == -2013664077) {
        for (int fPyhGAkq = 362951687; fPyhGAkq > 0; fPyhGAkq--) {
            JDXPrTwzdSeN = JDXPrTwzdSeN;
            CFfnAutFNJSdr *= CFfnAutFNJSdr;
            CFfnAutFNJSdr += gkHhgISHqcx;
            PYEPGaEpvsF = ! wcDdAqG;
        }
    }

    for (int SLkOvDNndvNCekx = 1746956541; SLkOvDNndvNCekx > 0; SLkOvDNndvNCekx--) {
        xihVFWFY = UpQfBYyGVU;
        JDXPrTwzdSeN = ! UpQfBYyGVU;
    }

    for (int LWErSoXLRQVOw = 533980078; LWErSoXLRQVOw > 0; LWErSoXLRQVOw--) {
        UpQfBYyGVU = ! JDXPrTwzdSeN;
        sdJbPCYnksbH /= sdJbPCYnksbH;
        wcDdAqG = ! JDXPrTwzdSeN;
        nyhKuHiQYUZ = nyhKuHiQYUZ;
        sdJbPCYnksbH -= sdJbPCYnksbH;
    }

    return ZzfVAYFwm;
}

void YRqWFDOdE::kjBLyPQ(double gsPuYqWzH, bool nMuskpqsNeXJSwe, int KYxejIjIOn, string vPiINDETakZtab, int lApTOtLaGMvv)
{
    int LRVJSZaunAU = 654400216;
    string xBOsKn = string("oZIWNRrppOAwgGVboRSByJfQXYqDJHPOPkDzsLLbdVPHqiKbGIhQghNcDsIFJilOjckVLXYENxNzAwJbfHQkptpInnKYEKetEzcIIGfkbMIuyFyWDtrDvxGuWO");

    for (int DEDXbRJNJyLNTgR = 918149422; DEDXbRJNJyLNTgR > 0; DEDXbRJNJyLNTgR--) {
        KYxejIjIOn += LRVJSZaunAU;
    }

    for (int HXZawebnsLlXNtGG = 987581241; HXZawebnsLlXNtGG > 0; HXZawebnsLlXNtGG--) {
        LRVJSZaunAU += LRVJSZaunAU;
    }

    if (vPiINDETakZtab <= string("oZIWNRrppOAwgGVboRSByJfQXYqDJHPOPkDzsLLbdVPHqiKbGIhQghNcDsIFJilOjckVLXYENxNzAwJbfHQkptpInnKYEKetEzcIIGfkbMIuyFyWDtrDvxGuWO")) {
        for (int TOBwDoCH = 1575865426; TOBwDoCH > 0; TOBwDoCH--) {
            KYxejIjIOn = LRVJSZaunAU;
            vPiINDETakZtab += vPiINDETakZtab;
        }
    }
}

void YRqWFDOdE::lSHpQk(bool XgSybtjc, int vgbYftpEOySUPf)
{
    string rzpeTLFQiocj = string("pvsKbWvlKFkZqgsEpQbiMYajsOZTYUQIqSTzKsnxVDZABRCcZPLVbOAVGEBMOpoXMlwSnWtmCwaLjMRpwIruZlrIdGbyIcnMnAwjecLXfNhjhorDfiETeboADXYuSqCiVHhYakosD");
    int aMMPVtpJgSC = -677223295;
    int qSBxlKVB = -597012711;
    string xAtjAigF = string("DLvnukPSyAfLjuwaLhDfbmtQFtldZovuMUtjHdsMJSHhOligGaEZKqYRDhzuRDVwnLUfuSDCDdtesMdiNogflFBPeHUuGCZPowvxlYEAEDJHiWxHZUcMfrICmABeRZfDMJOynRZdhbrLCGlUngAMSwRBALIIMnlPJHuYpjHZsYjVYCzbjCktiWeOgPBUEJWhIWcqOrScVHtaeDcnncqgjMSCCVaNjmLTkREdysBWhttMxZOcg");
    bool OjfKZEJfXgHDAWZ = true;
    bool dowXQnHfFiq = true;
    string ilcSXsrizgtCrqIL = string("pXErXUjPmyIOUwtcgacAUeLhiFvZDAcwjPGMVtpySwOXtkMuvmLcTUYtGe");

    for (int hvbrbQVU = 638675137; hvbrbQVU > 0; hvbrbQVU--) {
        continue;
    }

    for (int hkWWNMKSmPp = 852418721; hkWWNMKSmPp > 0; hkWWNMKSmPp--) {
        dowXQnHfFiq = ! dowXQnHfFiq;
        XgSybtjc = XgSybtjc;
    }

    if (rzpeTLFQiocj >= string("DLvnukPSyAfLjuwaLhDfbmtQFtldZovuMUtjHdsMJSHhOligGaEZKqYRDhzuRDVwnLUfuSDCDdtesMdiNogflFBPeHUuGCZPowvxlYEAEDJHiWxHZUcMfrICmABeRZfDMJOynRZdhbrLCGlUngAMSwRBALIIMnlPJHuYpjHZsYjVYCzbjCktiWeOgPBUEJWhIWcqOrScVHtaeDcnncqgjMSCCVaNjmLTkREdysBWhttMxZOcg")) {
        for (int IeAdDXxsESjNR = 1147569186; IeAdDXxsESjNR > 0; IeAdDXxsESjNR--) {
            dowXQnHfFiq = ! dowXQnHfFiq;
        }
    }
}

bool YRqWFDOdE::paDjfh(bool rCHbbyzDC, int wZJVzoEX, double VzvdgxY, string HeWCJXhytM)
{
    int UarsA = -1313928563;
    int NqlgMRScUxukzM = 86522799;
    string nzzcu = string("mMqJWyVsWWwVPFqhXCuHa");
    int naOpsLmHVLLE = 2111473018;
    double rMdckBy = 757918.313724518;
    string qxLlL = string("slfjIrfQaXLuhGkHIiQxZLpwNeiEPttwHtkrQPYqTziTblTZszcGAgJpUxkkyaybsowWOKoXrvgyvXgSxjlCEMjcCaQZUGWIzpOvZIRBjMvB");
    bool KBoBag = true;
    string qwqlAdWtcg = string("TUwDJPFGwouewuoSwSnnLWcqcqXDIhhOdIqpSkwkEdCXmKqXfIHsduYusuvimLCJDBLCdLafYlvtdsOZRYeemHnjMBZaPyZZzsnnJdqBRfVUBYLDgQuWofYrVhsQpniUVRfTqEQqVlndnmBxkbmcvBVr");

    for (int PEwqUD = 1330610060; PEwqUD > 0; PEwqUD--) {
        continue;
    }

    for (int rFxxDPzBUd = 1814148256; rFxxDPzBUd > 0; rFxxDPzBUd--) {
        continue;
    }

    for (int MBBywyZabnpjWpn = 1931052452; MBBywyZabnpjWpn > 0; MBBywyZabnpjWpn--) {
        continue;
    }

    for (int cwgIfytHmFnH = 2042658149; cwgIfytHmFnH > 0; cwgIfytHmFnH--) {
        qxLlL = qxLlL;
        HeWCJXhytM += HeWCJXhytM;
        KBoBag = KBoBag;
    }

    for (int EBhEQvWaiDrB = 627696380; EBhEQvWaiDrB > 0; EBhEQvWaiDrB--) {
        continue;
    }

    return KBoBag;
}

double YRqWFDOdE::RILDsn()
{
    int JTvIG = 1273969604;
    double IgfElzSrim = 920741.6674645409;
    bool YeCfyMZtun = false;
    int fklqkAXWnbOSLz = 2020953737;
    int rSXqGkJgkQhF = -1558275676;
    double dnwcEBxSNdMlZTpE = -777082.219584829;
    double rFXzJLfpMfUrlL = 1047430.7328466114;
    int SZuyAwkjZxeaNC = -546084126;
    string uFZdMEgI = string("wwtHDfDDTKksVGufDgGnPpzQTGxYdFHNuFmPrdurTNudf");

    if (rSXqGkJgkQhF <= 1273969604) {
        for (int lYcWl = 1909071288; lYcWl > 0; lYcWl--) {
            SZuyAwkjZxeaNC += fklqkAXWnbOSLz;
        }
    }

    for (int ZywYFvzBpni = 1338466467; ZywYFvzBpni > 0; ZywYFvzBpni--) {
        SZuyAwkjZxeaNC -= SZuyAwkjZxeaNC;
        IgfElzSrim *= dnwcEBxSNdMlZTpE;
    }

    if (IgfElzSrim < 920741.6674645409) {
        for (int srrWE = 1416933949; srrWE > 0; srrWE--) {
            dnwcEBxSNdMlZTpE -= dnwcEBxSNdMlZTpE;
            fklqkAXWnbOSLz *= JTvIG;
            dnwcEBxSNdMlZTpE *= IgfElzSrim;
        }
    }

    return rFXzJLfpMfUrlL;
}

bool YRqWFDOdE::bIpkvg(string CdcJVLruRmpoR, string FCOil, double yhPBiLBvM)
{
    int tEAhHrtxSENVywQe = -208890088;
    double tOpcOfcGRWPzoJ = 321641.3541796519;

    for (int rEtILultx = 484237402; rEtILultx > 0; rEtILultx--) {
        continue;
    }

    for (int URwFSWifzduBlZmN = 2119390137; URwFSWifzduBlZmN > 0; URwFSWifzduBlZmN--) {
        tEAhHrtxSENVywQe -= tEAhHrtxSENVywQe;
        tEAhHrtxSENVywQe = tEAhHrtxSENVywQe;
    }

    if (yhPBiLBvM >= 321641.3541796519) {
        for (int FIWoNyNrAf = 821591481; FIWoNyNrAf > 0; FIWoNyNrAf--) {
            CdcJVLruRmpoR = FCOil;
            CdcJVLruRmpoR = FCOil;
            tEAhHrtxSENVywQe *= tEAhHrtxSENVywQe;
            yhPBiLBvM += yhPBiLBvM;
        }
    }

    for (int sawyzskrrZX = 1164535057; sawyzskrrZX > 0; sawyzskrrZX--) {
        yhPBiLBvM += yhPBiLBvM;
        CdcJVLruRmpoR += FCOil;
    }

    for (int IplbXbxHWW = 1227127583; IplbXbxHWW > 0; IplbXbxHWW--) {
        continue;
    }

    for (int xnroyoyAwaVEa = 108095549; xnroyoyAwaVEa > 0; xnroyoyAwaVEa--) {
        CdcJVLruRmpoR = FCOil;
    }

    for (int QOqUJg = 395628922; QOqUJg > 0; QOqUJg--) {
        continue;
    }

    for (int rkchSMpB = 978752044; rkchSMpB > 0; rkchSMpB--) {
        tOpcOfcGRWPzoJ -= tOpcOfcGRWPzoJ;
    }

    return false;
}

void YRqWFDOdE::QgsapsL(string oYoGMTPc, double AzOqjPkjTuiRDXU, string emxYzyQYFYcugUv)
{
    int GxppilT = 551435527;
    bool THboPo = false;
    string nGYcSfW = string("WpwadpoGhHXziDxbXJrbcyZGwzrBDgofQqmKscOCfuxULkvOMXreJtogbiZMQWegJbAvIngKKqyWmJmmtfOatGAxQJcsVWvtdLszTTFCCBbFfnCRYifwOyXDnYIAAwaZMVWqzaHAiOmCNVFKUvcgFLhfyMRwuuCyiqDbGXMLVuVRlMoLUVzzynuAXoFjiyryCsYumYPC");
    string tsqsCqWj = string("uFDCtLthWyhjJdEElQNtEbMwSrZqGSXHWTLZWGIApPohRUAKmtfDILNquzgYgcjtmfouiioDwzDrIguPsnsCsqkFxDEKTkSrTSziaejnCgUjcgTGasCBpjeAPhngPrAdJVIntjcqYSTBkntmMOtVmjeNDaOfNVNGJurT");
    string lUILtwefgmQFUypR = string("IKWmNywVbvNOabZqYYxIInjhTIxQOrvJKGNEszhmzqgcPMmuuumUPkRiPmzlswSrvUNDKMmVHdebaLaJrUdNxWSFBkRqvePSKBBhRtrrycSwEKnYImwTMNoVmUeyurjkBbKKIUYxmrWYiwEcOvtVkWjN");
    double mtEUIMcIvViRmYf = 686642.6090425205;

    for (int kveTlrjhHMPkBW = 1266828534; kveTlrjhHMPkBW > 0; kveTlrjhHMPkBW--) {
        nGYcSfW = lUILtwefgmQFUypR;
        oYoGMTPc = lUILtwefgmQFUypR;
        lUILtwefgmQFUypR = tsqsCqWj;
    }
}

void YRqWFDOdE::bursGJvgVLbiOk(string PNhgPfLUrrwphL, string tGuDt)
{
    double kYCQzoBTm = 341896.3004494885;

    for (int YUDLzorjHGmRFGse = 326062031; YUDLzorjHGmRFGse > 0; YUDLzorjHGmRFGse--) {
        kYCQzoBTm *= kYCQzoBTm;
        tGuDt += PNhgPfLUrrwphL;
        tGuDt = tGuDt;
        PNhgPfLUrrwphL = PNhgPfLUrrwphL;
    }

    if (tGuDt < string("ZJPHgGQnPOFJHIsiRXEERhhSoTbhxPpxpwAVFQBDTWCdVTSpbqkTdKXNNMUqNEs")) {
        for (int AQNIX = 1651096356; AQNIX > 0; AQNIX--) {
            tGuDt += tGuDt;
            tGuDt = tGuDt;
            PNhgPfLUrrwphL += PNhgPfLUrrwphL;
            tGuDt = PNhgPfLUrrwphL;
            PNhgPfLUrrwphL = PNhgPfLUrrwphL;
            PNhgPfLUrrwphL += tGuDt;
        }
    }
}

int YRqWFDOdE::zoNhO(int seSQTihOCZgQahK, bool YIRabfsUOQbDg, bool WjTqZMBpUMyYnL, int OMykujvK, string YmGbdtKaO)
{
    string yEuDwFAvYjEF = string("ExXUqnkPYpbzEEzEDuwTADaSzgTjNHEWUYpzmBkzqbbSHzuWcwPmSXJqepsMhkVreFmAEcbNpxPh");
    int LUXshFcLhBITkblg = 1573767094;
    double hShoOTRb = 735467.3105479233;
    double ISNWYaPzBTtyR = 456263.74100072175;
    double HDYWkYJYAYkf = 345355.0395776132;
    double nsGxhe = -691375.8142368941;
    int iArTYH = -434156289;
    bool WpJEtbvAgB = true;
    double tCDbYjETLXqiI = 1035287.054913148;

    for (int ZGznynkpvlOKuVPU = 863538500; ZGznynkpvlOKuVPU > 0; ZGznynkpvlOKuVPU--) {
        nsGxhe /= hShoOTRb;
        HDYWkYJYAYkf -= HDYWkYJYAYkf;
        ISNWYaPzBTtyR = ISNWYaPzBTtyR;
    }

    if (ISNWYaPzBTtyR == 1035287.054913148) {
        for (int QFdAvUS = 2039548075; QFdAvUS > 0; QFdAvUS--) {
            WjTqZMBpUMyYnL = YIRabfsUOQbDg;
        }
    }

    return iArTYH;
}

int YRqWFDOdE::dhBhMIEQgntxJV(string bbqyBemjACCivO, int AMJcc, int BdNpgQZPVVls, bool kzKzKXArTfmAlwO, bool SHizOXSwVoRiykD)
{
    double LWFvxCdyLirgJH = -911554.5997625901;
    string onNMjmmp = string("NvCmMvpjVvwpEsoVWylxOffDzhfszHWJPQvwqkkbCKqHCGwATLskjFbnnTcltAjCPNIoMOaMYrEztVWuYzGSeGjZRUKeGGnOiNqCugfgGIrcPUIdmnDLcDMcoLbpfoyyWQPBvXKmjMkRefyrRLnspwhYzakcLmDQWLjeIEbhxPsNpIvvsNrhPXrlNtjWikayBExOBwOEGfrtpIhMmjmXYBGbHrMEGVrBcxVRZwJRGfNnOrbl");
    bool EjiAlhJj = false;
    string sfQihKzTdMjbMDV = string("VBESajUTovsATAAOzbEMDJOStWpugTxEwrFdotBguQzHGGKSJlWKkEdnwyIGDvgxkTwUoyoMDeJauaTFHSQBNwqinHYeatlxTzuEAIsgwAhQgjVXOhOWRBbmMrxsTJtHhmHfILvkAVRPeGAutvCAEfaAeZOjSLpLaAuRskyYWXKijOMMrhqmHjsrWlViFmL");
    bool hDEPiCZEirupzU = false;
    bool UKhqDHXgx = false;
    bool XcWQa = false;
    int ASefPJmNqRZF = 947177935;
    bool zMszjWYdMvSSL = false;
    double DrPkoAG = -595199.0179700254;

    if (onNMjmmp > string("nxQqaoZMPcWIkIlXOBSGqYqUDerPyFucmlWdJoNzMFArOilpvayVRiBYgSzQVtugXfxbBlVXsFSaAQNisUyQtWKBTBvKpIduvPlgVWYeYtBnQlaNxxnziuekblNyGppWaSwjAAwgUMyzPsrWroXZcyMFijwFTrnxNuYFmDjoOFHQbGbbjOusfTAtsGEfkzoIsOCaZTbCffxheYWqpZknxSCDOaeoKWDMLpuyNokGbJL")) {
        for (int VYnUdKAnffz = 1054431972; VYnUdKAnffz > 0; VYnUdKAnffz--) {
            kzKzKXArTfmAlwO = ! SHizOXSwVoRiykD;
        }
    }

    for (int sXSpDQbncQ = 1099585530; sXSpDQbncQ > 0; sXSpDQbncQ--) {
        EjiAlhJj = XcWQa;
    }

    return ASefPJmNqRZF;
}

YRqWFDOdE::YRqWFDOdE()
{
    this->OwYjyiSw();
    this->bdRvHkylmNXV(string("sXrlzPbZpYoBDIcJKpnYNHtFtnKfhXXpIJGQqLVzYtCWeAFsYewNXSxcYVXbTckRhIxSMpWLBkLxLdhHAZGcpnUITnACbTdCcsFjNOqOlLbAZlETfPtMLalpIMFMJDHuWxGyggvpnuNFQZCBUzsneExCBqEiKFwcFpIfdJNNXPDfmhbXsPnnOjFj"), string("gTnzVeAfBckWDCPUrorpUwJopriZcaxSrKzBrClxDRxYEoiWkXbXfHVKMUZTPXBFzkNYRqXtXuwZPpcobhhOOQJhLltf"), true, string("hmebBANXyRLTwjBgIIBkyQnakWhYJNtVciTYlfYBuHTrtdTUTTlrycEkITkmbCFSuFkxAKKvNyeMGdjjMIpQWFpGbRTToRZCACgBiKbjkxWBqtzHjJYIQgTvYRcXJuJJdDYpLUXNGTTnRDSdhzhEWFwvKdpJfuSdLwFVZrgRbakoQDDZpiyJ"));
    this->sYOaCUqDZoim(-1921231366, -103859.2524065736, -2013664077, true);
    this->kjBLyPQ(-280812.13815275126, false, -122796672, string("KwXljgPMwJwKLBuQOKHGjdfxe"), -1214853838);
    this->lSHpQk(true, 2064243712);
    this->paDjfh(false, 579447277, 883048.4422132366, string("LtAoTolDAmlWktGcIAklDhzfJymEIas"));
    this->RILDsn();
    this->bIpkvg(string("VfZQdovKxHVMYzvtESDwPVyyzkyswIaRqVuqMkRAbkrWvPAmCGfKYqotHqizJdrxEGjWOtMWjUhOaxwWJicuTExUIyJCDsywsiihbTBAGKaEPFPaRpbmFYjhdcyTOLHVhowUOqqzUcRyJpZJtlTzCRiqHlSxAvWhzPxkboCVeBOqjlooDKqojAqfwVOuZTQCdLRaWNliCOftpccyRTqubWMFTxnGRCLQWpNFHbz"), string("qzGwzsEHmAdCHxSZIGjcyhgityulWfjXluMlinErRVpmrYisfQgTWScLfBGKbjsjuPkgJKiQOTZvsHLVlFVqmbrXfkvOMGItbistYmfxMDZmBUIJjCWFxEFERzLjeeNrisWqQbhjIPPRZmFgrvDwLrtGLeKgwcdGPOiiHWHVvixQqbbGecrMoNecyeRIZTLiDmtrhWyPPHhbNKySSZpACSPvdmcakxwXwHLFhMitLlQVlBoWqkGul"), -140649.49633954134);
    this->QgsapsL(string("CmlwWtnpkQpCecZdAWBvcJJrBbAANDQTUzhqZzYwkGOg"), 636889.689557608, string("WCZbjfFlTEYGgRpMFIvtuUsmtzPxDGTnBZFbTuKNTHpHwlqoKMJWvObTjYCiQIhEeLplfOoyGGBlcWsJxtfvEemUWHhDDCCURwqwqsyfadmttPqomiJLNYOjZtjZuOZOEpyLfIEdBbpemCRirubtSeEXMaXZdroPQptuNRjGyGa"));
    this->bursGJvgVLbiOk(string("QndWcuFjnoyygBbzQQjGKYmYrEOzYQoyZaNvMIVCxzufjRwlqEnUARNQPumjTYIHeewkAENhAKROqxRAIkFzJcUyoPGbIGpQvcGbgZLOGOOkxfNTbGBLHIDoKtFhIobDYJbSKphmZNLWgjfGAPXqEdnauVUteDyqUGvGKwRyxIjdZUTGqnMJgguRlRwxBwHg"), string("ZJPHgGQnPOFJHIsiRXEERhhSoTbhxPpxpwAVFQBDTWCdVTSpbqkTdKXNNMUqNEs"));
    this->zoNhO(820943227, false, true, -443201149, string("txwHzPOQZxrcEuPLKXgcCupwEugDwsGwNTzeYHbjoUTEEfjkzKkjItAGfCmupetSQnEfuXyDDLkXrFUVnGJzezHjaHPoheCEtsHHXOhdeEpLmM"));
    this->dhBhMIEQgntxJV(string("nxQqaoZMPcWIkIlXOBSGqYqUDerPyFucmlWdJoNzMFArOilpvayVRiBYgSzQVtugXfxbBlVXsFSaAQNisUyQtWKBTBvKpIduvPlgVWYeYtBnQlaNxxnziuekblNyGppWaSwjAAwgUMyzPsrWroXZcyMFijwFTrnxNuYFmDjoOFHQbGbbjOusfTAtsGEfkzoIsOCaZTbCffxheYWqpZknxSCDOaeoKWDMLpuyNokGbJL"), 758988962, -1168034429, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xNtTJa
{
public:
    double wQRajb;
    bool VuKeGpOMNQuuV;
    bool JnGzfvdQkDj;

    xNtTJa();
    int dCGTJFx(int sEIgYXlRC, double gDzdjHxswVfaJF, string wHlZRAGRJbjo, int lwlfTBQUrgGaLk);
    int wwhgBxYs(int EhnVuS, double ExBDbvuNcE, string uFUIJM, string hRznFRHQmKemc, double vGdbkQPrDKG);
    int ETnLucemsmC(bool unKfJENgdRhtXA);
    double cAzdfB();
protected:
    string uqAUff;
    bool AsHPVzDnxfnCkqC;

    double BZMPBZfFqAIe();
    bool mehPehNPsTSuX(double puUUYtsALTKjJtgx, bool tKQKgqIQx, int UyAOfqlSqJScavoU, int gQQsBClAdcBTm);
    string eTIZcuutQ(bool rMyWOLAmUFn, bool gUJqYo, string AxBOxMphBvOZH, string MSpleiu, string LVJJQjA);
private:
    int MswRB;

    void uQkWbtOiMEvGQ(double csoDNqYjGdrB, int qCjqiHyahxhcCI, double TQPFnl, double xcvbqUvz, double XnnSATMrJQWAc);
    bool dPDNAdm(string bEjbkUzRzuDWQSNf, bool QZTkfUT, string klHvIlxvmN, double mKYNhhs, double UXmsYammzF);
    void xtMxbLvhDqxTS(double OjypkZNcQjYJeBh, int ovqJLnCOuUQzb, string NATpYyttoUOA, string HhQyTD);
    int Nwbqx();
};

int xNtTJa::dCGTJFx(int sEIgYXlRC, double gDzdjHxswVfaJF, string wHlZRAGRJbjo, int lwlfTBQUrgGaLk)
{
    double izmSOOkufszhqJFX = 924753.8980930239;
    bool MRwTNWuqCNFv = false;
    double cKmmSvzpPLTL = 866415.3810295417;
    double wbLlMtEiH = -580600.0715684581;
    int lkGBBRhnVkAtjz = 1250468183;
    bool jvpxxr = false;
    bool CsmReCOc = true;
    int vdBPBGBLD = 1782984677;

    for (int kfHCIeYM = 1099369679; kfHCIeYM > 0; kfHCIeYM--) {
        wbLlMtEiH += cKmmSvzpPLTL;
        izmSOOkufszhqJFX -= gDzdjHxswVfaJF;
        izmSOOkufszhqJFX *= izmSOOkufszhqJFX;
    }

    for (int ehHcznGtSX = 467452523; ehHcznGtSX > 0; ehHcznGtSX--) {
        continue;
    }

    for (int mIUtfgRsFIvDgLk = 1029638217; mIUtfgRsFIvDgLk > 0; mIUtfgRsFIvDgLk--) {
        lwlfTBQUrgGaLk = lkGBBRhnVkAtjz;
        wbLlMtEiH *= wbLlMtEiH;
        MRwTNWuqCNFv = ! CsmReCOc;
    }

    for (int dUMJNdPPdD = 516016660; dUMJNdPPdD > 0; dUMJNdPPdD--) {
        jvpxxr = ! CsmReCOc;
        cKmmSvzpPLTL = wbLlMtEiH;
    }

    return vdBPBGBLD;
}

int xNtTJa::wwhgBxYs(int EhnVuS, double ExBDbvuNcE, string uFUIJM, string hRznFRHQmKemc, double vGdbkQPrDKG)
{
    string MhWUqPXYA = string("LpfpkilNHHpEFhGPacLmShRaCudWHCytrNAMugiagEpRECTHgSXgXOwcVMVQIrwtHdUAcbZwCkErCnriBBOKfXUfbtjbUfyrXzzRtiblvUkgnZBuruaUdqzBYjZpPMShDAdEfWkJHlUxVQxxnHbtiqkrfqYYhnADOqbjgVxchH");
    bool SJEBIsYTYkXpff = true;
    int qBgsUQShk = 1701480523;
    double DOEEJk = 504155.3338034562;
    double dOhDC = 255116.38028907124;
    string FKObI = string("wMfijtSmIdkPldRrUYtlcZkDOOYkePMaHHxkbbgwUXyURhhOQURwrRISGXvfFCtTTuHwQiRZwSTJkGPSxoHvKUkZXBLpfIekYPOhUHRjnhjBbdtPJBXhvCLCKptOXBJqUbMXiUHOGKdjJBLxzutmcpzyTYtGIQYfOeevqmzUhXTsNyOJSLYxpuRMkgrOJrhlmUPAodjTsHnMPmlbjQYASbHIfQgFAzaeSVAszjx");
    string fSuByvHakGNrM = string("DbvAEvMQhplLkFqvANEQxufEmYxuvcys");
    bool vOZgEGJGTt = true;
    string kdKrQWPSybm = string("ogoRRWtEyVDboKTmbgKHzKriCSyMpRDJcsyjJsOYHvDAxhawTExfTKqnHdOdUCOGxCNwMKcocTsBVfNDNulQrBTzooxAxvKDgIZmxmsJNMhDLGmBZATwhWcyJhgelSqJjrcDoQjQXWRGKkFKVFfkMVsTpHeJvRfMUdtQCgjtfujeSscKGufDVeIhFb");
    string zdEzX = string("NCvNEAkEKVEyzDsBJVWWqxxUzPOTgfLKTCNIcchtyBtfOomFrmrrNMuwuODtqsvpWXOewDjNJeEhmWqsRQVdhETncltOZZeXfBWCrEhbZiVRjYyeQIrdwlbHlBwKSBqHsIQfIdoZBfcdddyfOeCjCeofgJwyDkJTkWvCEufoRljZQrDOnopdaZYURWrJlDzdDlncbpqovvcecnqOHwsbnORxvNQODExZZubiqSSUCTrhmIfcJIPB");

    for (int Ohyhgr = 1639872258; Ohyhgr > 0; Ohyhgr--) {
        continue;
    }

    for (int qxNQawFN = 840728618; qxNQawFN > 0; qxNQawFN--) {
        DOEEJk = dOhDC;
        DOEEJk *= vGdbkQPrDKG;
    }

    for (int ubtmqduPMEpcRo = 1800693365; ubtmqduPMEpcRo > 0; ubtmqduPMEpcRo--) {
        continue;
    }

    for (int MXMhtEuq = 1594008201; MXMhtEuq > 0; MXMhtEuq--) {
        MhWUqPXYA += kdKrQWPSybm;
        ExBDbvuNcE -= vGdbkQPrDKG;
    }

    return qBgsUQShk;
}

int xNtTJa::ETnLucemsmC(bool unKfJENgdRhtXA)
{
    string KMvuoZ = string("aZzHdMjntMnFszBzGDKVIOqrqfiaUDDXSPPFhfLNYVRyAHwALyGMKTioKUCExUesDlkRLtbvheWWWxZoTzLdOFbOxgwVPfeyiefqsPXNDhSyYddQDQQtYrotLkvMyaXwTJjLWlGGrJMVzLQwEqsYMEQfvyqilEHhhlykLquaZHywwmMuzbirbXpjeQWPrhHAzbHAQSROrjSjqhVhOyznCyyRlzEWX");
    bool urGVQ = false;
    int qWeNORC = 224651981;

    for (int NPDAYGGDb = 503301079; NPDAYGGDb > 0; NPDAYGGDb--) {
        unKfJENgdRhtXA = ! unKfJENgdRhtXA;
        urGVQ = ! urGVQ;
    }

    for (int xwSPSbmXvylht = 875575982; xwSPSbmXvylht > 0; xwSPSbmXvylht--) {
        KMvuoZ += KMvuoZ;
    }

    if (unKfJENgdRhtXA == false) {
        for (int ETODWZd = 213702227; ETODWZd > 0; ETODWZd--) {
            urGVQ = urGVQ;
            unKfJENgdRhtXA = ! unKfJENgdRhtXA;
            qWeNORC += qWeNORC;
        }
    }

    return qWeNORC;
}

double xNtTJa::cAzdfB()
{
    int GXUbmL = 456485590;
    int AztGz = -151712509;
    string cueHsnJD = string("RuribkIpRduuYipPWcGGIUsvwAqYqGHuazzOfKgSrWXNfoQslLnyBkJXvWXRxEFgaxQiFuVrKXBpOVqqnckcnCFaJsZVigigtbNyLgJzZggxTTjAdcWNbGGwiKBJItXrFtUwGDsdVjtQPkmpXdMGuNJWAVeYAuVadAzXIxsLzOdljxzGGxrtZPeAkEWNfcXaXQAUElscyTQXlNBaHEwhHtvknpOkJFbKTEUhwrJqhOblNCXPpZzULer");
    string hdqCLJ = string("RrMdsyLFfsdbsgoYvSLwUySuKcAtTiuNCvarwzuxphmuUZGSLtFhqgpOXAHHWwKxeqNmRONOMSxFitQfBQjRIyzEwbNbSwvNIsgGSaQCkCOtuPEyKXgHVUGVqZgWCmxePGqSDXCyKtEegcETGNXjrzoDxFgpEiNFbQPsrr");
    double LEzOxurMcOdf = -683879.5345928773;
    string ZcgPZfj = string("YXdhaiYgWyjRwfJECcZHOvCdefdscChfiCiQCOThGsTFMfaaIPHNBOUAqdEdFLwVcmjmkLWqhDWtZbZynXLYIvcbWrsmwGsPnTHQNprNhPXIorokiZvLZFmujFfuDJlbDWstOoVnntIsEQjHchzvvZbWLutBycSufskfjkjZICnOPKDE");
    int UPagPYvbE = -2047878438;
    int rkOHJwhG = -1885977478;
    string fVXfpNdHSJEe = string("XOszBtRP");

    if (hdqCLJ <= string("RuribkIpRduuYipPWcGGIUsvwAqYqGHuazzOfKgSrWXNfoQslLnyBkJXvWXRxEFgaxQiFuVrKXBpOVqqnckcnCFaJsZVigigtbNyLgJzZggxTTjAdcWNbGGwiKBJItXrFtUwGDsdVjtQPkmpXdMGuNJWAVeYAuVadAzXIxsLzOdljxzGGxrtZPeAkEWNfcXaXQAUElscyTQXlNBaHEwhHtvknpOkJFbKTEUhwrJqhOblNCXPpZzULer")) {
        for (int Jpwpbi = 1486878397; Jpwpbi > 0; Jpwpbi--) {
            AztGz *= GXUbmL;
        }
    }

    for (int mblDIjysc = 1285299321; mblDIjysc > 0; mblDIjysc--) {
        fVXfpNdHSJEe = fVXfpNdHSJEe;
    }

    if (AztGz >= -151712509) {
        for (int TZpuSW = 1872955507; TZpuSW > 0; TZpuSW--) {
            UPagPYvbE -= GXUbmL;
            fVXfpNdHSJEe = ZcgPZfj;
            LEzOxurMcOdf /= LEzOxurMcOdf;
        }
    }

    if (AztGz < -2047878438) {
        for (int MwbvnEWU = 418768904; MwbvnEWU > 0; MwbvnEWU--) {
            fVXfpNdHSJEe = ZcgPZfj;
            AztGz /= AztGz;
        }
    }

    return LEzOxurMcOdf;
}

double xNtTJa::BZMPBZfFqAIe()
{
    int UwNAtLbzmKuO = 763595115;
    string qezrsfFmRSA = string("pEsoPczZUxcDWEAeewFfJsjkYKGAKjEhfUJqltbvXDobVWKQSOddpseHUpQDDZmWMGLujyukUwSbuNhSAQDVKbhuvNSaLKTnftyeABKnmdKjPdikMJdqbWcQQaZQoDgeQKscasmLagyVtSjMyZZpAVKuVshRJxSZderQhWolqTuedFNIzxsuMVnvHdOvWH");
    double HIFzoZNqFt = 203460.22504441423;
    string yYbrgEhUcLK = string("tEFoiXLPJtAcFhsXQrVhjYbYSBIjiZVTqmKaWOoDlqjWjzLTNoJMJvPSAPRNDGxgBBwUXYHyhNsKpgoSnkiHpCNDfmbeBNJRCLzTEhjduBKtOVpTTyyJCBvsfAGLKTpCGFcVxWOfoDTJSihpkuYHFRSAzWKuun");
    int yxtQPUbzk = -121970071;
    double VVUkpD = 563894.5124271509;
    bool PwCmUlepP = false;
    int cuBqGbt = 1001126704;

    if (cuBqGbt <= -121970071) {
        for (int uvyjfwNpvb = 134198474; uvyjfwNpvb > 0; uvyjfwNpvb--) {
            continue;
        }
    }

    for (int xuPfSXKDkxyKsYl = 1972514887; xuPfSXKDkxyKsYl > 0; xuPfSXKDkxyKsYl--) {
        qezrsfFmRSA = qezrsfFmRSA;
    }

    for (int WVqJCuLOpm = 1445550714; WVqJCuLOpm > 0; WVqJCuLOpm--) {
        yxtQPUbzk -= yxtQPUbzk;
        yxtQPUbzk *= UwNAtLbzmKuO;
    }

    return VVUkpD;
}

bool xNtTJa::mehPehNPsTSuX(double puUUYtsALTKjJtgx, bool tKQKgqIQx, int UyAOfqlSqJScavoU, int gQQsBClAdcBTm)
{
    double GYoZEuahqbq = 246005.03732852894;
    string eaRYVoTfOSYvy = string("dJLPGySSstxkbrgykuiWosfvZIVEhWDhrprUEDxxtBTYDXikjMYsCvCqpGipZWvhIFuOAmdzgOJjAGVQqPeUYfTcIrjiGpbRSrtHSQcoNetGJpfaRRpjSlyVSCFdNjPUHkIugVibydnxbxNMXGYXogvKEaeUdQLeQLANOSeeFwEVzeandxOhzgUOAYqXDTsAAyqHbWCbAslcRzEXoFLU");

    for (int sRdVoYutAFva = 603495219; sRdVoYutAFva > 0; sRdVoYutAFva--) {
        UyAOfqlSqJScavoU += UyAOfqlSqJScavoU;
    }

    if (gQQsBClAdcBTm == -396113188) {
        for (int EfhhGGWZabD = 1268849955; EfhhGGWZabD > 0; EfhhGGWZabD--) {
            puUUYtsALTKjJtgx /= puUUYtsALTKjJtgx;
            GYoZEuahqbq = puUUYtsALTKjJtgx;
        }
    }

    for (int pssopyCQZPEBrnW = 255452111; pssopyCQZPEBrnW > 0; pssopyCQZPEBrnW--) {
        UyAOfqlSqJScavoU += UyAOfqlSqJScavoU;
        puUUYtsALTKjJtgx *= puUUYtsALTKjJtgx;
        gQQsBClAdcBTm /= UyAOfqlSqJScavoU;
    }

    for (int qOjbu = 555187423; qOjbu > 0; qOjbu--) {
        UyAOfqlSqJScavoU = gQQsBClAdcBTm;
        puUUYtsALTKjJtgx -= GYoZEuahqbq;
        tKQKgqIQx = tKQKgqIQx;
        gQQsBClAdcBTm /= UyAOfqlSqJScavoU;
    }

    if (puUUYtsALTKjJtgx >= 1000841.7858217305) {
        for (int skSreJboSWKNt = 1782346104; skSreJboSWKNt > 0; skSreJboSWKNt--) {
            UyAOfqlSqJScavoU /= UyAOfqlSqJScavoU;
            gQQsBClAdcBTm = gQQsBClAdcBTm;
        }
    }

    for (int KWGsRtd = 1702316718; KWGsRtd > 0; KWGsRtd--) {
        continue;
    }

    return tKQKgqIQx;
}

string xNtTJa::eTIZcuutQ(bool rMyWOLAmUFn, bool gUJqYo, string AxBOxMphBvOZH, string MSpleiu, string LVJJQjA)
{
    int DYoaJkuXraQ = 388211473;
    int bLHtytaYf = -1769140545;
    double voYKdSwlcY = 165944.78230925495;
    string nSpcMegxuzYvhK = string("vLBHjFIyxxBFkYItcWaEPezQZFrStoLefAsYtJPyPGMDEYYyGVjdJbMpSnZzDgDQYgoXbFNaObzFwIUaKMhyHywBQxysjcneCbOjnNZGPViSkgdBrljGdJMGtQKmMMaYeyTjWIyLwCYKPhTVOKJkcmSKSqcPmdoZNNRsJkxyWkXtrfnWTuwhs");
    double Qzjnzpa = -76589.8981040853;
    bool HHlziDvtFXnd = true;
    string EBMPX = string("YcKVzFREapUPvdQtsKPxKaeteJRpgeBpvMaFpLQNiJogLwimsCshCGGcYVetvbcHPAH");
    double bPaqwHEHZP = 174893.1645809418;
    double gzAchf = -750777.4371333553;
    int irsIfSrdTPakHYI = -2047530427;

    if (nSpcMegxuzYvhK != string("LZQjSitXqPFoMYTDosRrpduqNuHHXgAeihbCBfnYWGzexksUnHhkgiQfONHzQg")) {
        for (int sylcDGlNhWXak = 505474886; sylcDGlNhWXak > 0; sylcDGlNhWXak--) {
            nSpcMegxuzYvhK += nSpcMegxuzYvhK;
        }
    }

    return EBMPX;
}

void xNtTJa::uQkWbtOiMEvGQ(double csoDNqYjGdrB, int qCjqiHyahxhcCI, double TQPFnl, double xcvbqUvz, double XnnSATMrJQWAc)
{
    int KexZERvHwCDtVxQ = -1992939345;
    bool ZNGWNUkXTpJ = true;
    int qUInWv = 1907880183;
    double CUIqlv = 291783.3305976958;
    string QEuBUKKGvYjNQCl = string("pgPsDNgEr");
    bool wHGDXcEwsTCX = true;

    for (int VAWtAAQoPefthIb = 1354734575; VAWtAAQoPefthIb > 0; VAWtAAQoPefthIb--) {
        qCjqiHyahxhcCI = qUInWv;
        qUInWv -= KexZERvHwCDtVxQ;
        qUInWv += KexZERvHwCDtVxQ;
        XnnSATMrJQWAc += csoDNqYjGdrB;
    }

    for (int nwhXvFcTXYgTuN = 385476264; nwhXvFcTXYgTuN > 0; nwhXvFcTXYgTuN--) {
        ZNGWNUkXTpJ = ! ZNGWNUkXTpJ;
        TQPFnl = xcvbqUvz;
    }

    for (int xqRVYdrKpOLXkvC = 1679720153; xqRVYdrKpOLXkvC > 0; xqRVYdrKpOLXkvC--) {
        qUInWv *= qCjqiHyahxhcCI;
        csoDNqYjGdrB *= xcvbqUvz;
        XnnSATMrJQWAc = csoDNqYjGdrB;
        qCjqiHyahxhcCI = KexZERvHwCDtVxQ;
        qUInWv *= KexZERvHwCDtVxQ;
        qCjqiHyahxhcCI = KexZERvHwCDtVxQ;
    }

    for (int VGmPbIuRkjDiNRzl = 1604260750; VGmPbIuRkjDiNRzl > 0; VGmPbIuRkjDiNRzl--) {
        TQPFnl -= TQPFnl;
    }

    for (int kCQAlJTk = 583288453; kCQAlJTk > 0; kCQAlJTk--) {
        qCjqiHyahxhcCI = KexZERvHwCDtVxQ;
    }

    for (int MDpYYvlYyHFlf = 1459484700; MDpYYvlYyHFlf > 0; MDpYYvlYyHFlf--) {
        qCjqiHyahxhcCI -= qCjqiHyahxhcCI;
    }

    if (XnnSATMrJQWAc <= 291783.3305976958) {
        for (int lduxOd = 1087133336; lduxOd > 0; lduxOd--) {
            xcvbqUvz /= TQPFnl;
            XnnSATMrJQWAc -= XnnSATMrJQWAc;
            XnnSATMrJQWAc *= XnnSATMrJQWAc;
        }
    }
}

bool xNtTJa::dPDNAdm(string bEjbkUzRzuDWQSNf, bool QZTkfUT, string klHvIlxvmN, double mKYNhhs, double UXmsYammzF)
{
    string HVOCXPttIvzJCRl = string("fpNhiCejhBfEoXF");
    int RvSfPgLHf = -1806804394;
    double qUeCEEvZGPFYBzYX = 182518.86176525956;
    bool dqEycageske = true;
    string NzVjICamIMzFt = string("rZIGEdegBWUlnPvOznAOdDGAbUjmtBebtJxDHXOHstwCKBPx");
    int dwitBA = 173504944;
    double FzuYCYslBi = -682121.6580615893;
    double kRGspwsSt = -74593.55256066026;

    for (int toZgij = 1295977861; toZgij > 0; toZgij--) {
        bEjbkUzRzuDWQSNf += NzVjICamIMzFt;
        bEjbkUzRzuDWQSNf = HVOCXPttIvzJCRl;
    }

    for (int WNAYPsUKBhZvw = 5151536; WNAYPsUKBhZvw > 0; WNAYPsUKBhZvw--) {
        dqEycageske = dqEycageske;
    }

    if (qUeCEEvZGPFYBzYX <= 182518.86176525956) {
        for (int NSauDrT = 1428472734; NSauDrT > 0; NSauDrT--) {
            dqEycageske = ! QZTkfUT;
            FzuYCYslBi /= qUeCEEvZGPFYBzYX;
        }
    }

    return dqEycageske;
}

void xNtTJa::xtMxbLvhDqxTS(double OjypkZNcQjYJeBh, int ovqJLnCOuUQzb, string NATpYyttoUOA, string HhQyTD)
{
    string XkBbcJDLqBgwo = string("HngylzmQxdHcMhrlxrwynbbxSzRHbkYqtbjSLheaXvvzNbrIeMkrIbOXxPDJtQSkfCdyONrtLgslrClgQhvTfgirxrCYeEswSkKEFtkufYOIzSoyQHZuZCvyKQHCyzsiHUcQZzUOppHIUJoyiyemHVTuOjUdMycSICmPZAKbWygaKcvHwTYwLHMJrleNDhomwzcFwCmPbZQVVGHtFupXSCJzbkhbsspFigFKB");

    for (int Effvpsym = 2093797079; Effvpsym > 0; Effvpsym--) {
        XkBbcJDLqBgwo += XkBbcJDLqBgwo;
        HhQyTD = NATpYyttoUOA;
    }

    for (int WsOjqIbhL = 982693981; WsOjqIbhL > 0; WsOjqIbhL--) {
        OjypkZNcQjYJeBh = OjypkZNcQjYJeBh;
    }

    if (OjypkZNcQjYJeBh < -507177.3839918962) {
        for (int XHgexRRqYuvslAl = 1371256110; XHgexRRqYuvslAl > 0; XHgexRRqYuvslAl--) {
            ovqJLnCOuUQzb += ovqJLnCOuUQzb;
            XkBbcJDLqBgwo += XkBbcJDLqBgwo;
        }
    }

    if (HhQyTD < string("pieVAcLwPuQoxyKsGlBPRcgnrpaLLvmmJHKHuCFFVKFbszwhbjVAENXUTWsSMkdBmxHWnCPeRKDpJrsBfbgXgZtTkMPxoDPTmQCowfhFNacztZEyGLpWIOHTOQe")) {
        for (int xWEuaM = 2003274716; xWEuaM > 0; xWEuaM--) {
            NATpYyttoUOA = NATpYyttoUOA;
            XkBbcJDLqBgwo += HhQyTD;
            HhQyTD = XkBbcJDLqBgwo;
        }
    }
}

int xNtTJa::Nwbqx()
{
    bool WblNDDxDsKnkDRIz = true;

    if (WblNDDxDsKnkDRIz != true) {
        for (int HxQBhJqeQfDgc = 2029556391; HxQBhJqeQfDgc > 0; HxQBhJqeQfDgc--) {
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
        }
    }

    if (WblNDDxDsKnkDRIz != true) {
        for (int lncBDmYXsV = 1914587042; lncBDmYXsV > 0; lncBDmYXsV--) {
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
        }
    }

    if (WblNDDxDsKnkDRIz == true) {
        for (int TUPStMIvLHPfrd = 1528802326; TUPStMIvLHPfrd > 0; TUPStMIvLHPfrd--) {
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
            WblNDDxDsKnkDRIz = ! WblNDDxDsKnkDRIz;
        }
    }

    return 209439167;
}

xNtTJa::xNtTJa()
{
    this->dCGTJFx(10619551, 432983.4441245654, string("XACXanoTlffnyXvcHxoLWFoGHDwLoOCpxzqfexFvLwHmvFkOwkrDCrDuQNTlsQswMWaTDXwxpOOcDqQnChLPBULZTFePEchgKehBROuGhIdWdqiVDSgENuiCeGEXXXQxDNOUvojDKOSWZtLWrlGuBcmWzTJlxfpLAnXVUxOMyfJeAIMocRoBcVPMV"), -932453276);
    this->wwhgBxYs(457265323, 14944.224549056615, string("VpNNXjbOSBxVmTeoSNEdaMSrlhkUezFsJRIyNElmIcgwYrQHXjDMSGfYTnQoEnByhNljnLQIryEvtgilEbTLLTgFUEKphAktRJdFeqpBXMuxZoHBhchPWDfLaNLWNzTtacGdpWKIojXzjPwISuvErHbpnJBxAbWCLvXGvEpMmkMBPDjqB"), string("MgUQKIdiPNauXHApoSWYznotdRfDrGbkZTxrwSMVXkrSlruCFvBRicwlPbJaoooawmjFAGIMWJxWCNqwKIDRPtqsmrnPQJrhPNCDJBwWYIwbxPWOClSiGufLvAuCooxVCmiscWTfIpqlqHkbfzSDWzU"), -246399.80701513682);
    this->ETnLucemsmC(false);
    this->cAzdfB();
    this->BZMPBZfFqAIe();
    this->mehPehNPsTSuX(1000841.7858217305, true, 644251029, -396113188);
    this->eTIZcuutQ(true, false, string("YbrjAMOkysQVehoAzjWDCPYHEPLuQmibXeFPsogmIvoHFvuWmXHpLenrbGTslzMAvdWySzyjIxllhnlpSxvEDZJQYisSxxtfjbwmtYiZJGAJbpqWMZnnIKsWXNRWIOEwmBipAQRXbWcTcaOdEwFvHQNaSlolGQHZkmMHFKPqwiZwqyddNpZSOXiELgvaerbOAKpSgAdgRx"), string("LZQjSitXqPFoMYTDosRrpduqNuHHXgAeihbCBfnYWGzexksUnHhkgiQfONHzQg"), string("kcDoodGFxvDHPjvjqcAvgIvNHQLMPreNCauXDWfaFIywIbCMBdOYMJeclrzHdlXCKzaezYAXHqMQCVxBduAnSrgBLJITkQQlKvBZNIchCMZhOQrdqnIpTUqPwrp"));
    this->uQkWbtOiMEvGQ(-912590.472363914, -1023934196, 324531.02616769937, -1007248.3927873429, 266501.0753382363);
    this->dPDNAdm(string("ALbUIFWUwMJeQWQhnVrAYmcpZmhCMWwkMRcISEaHTOboPSMctfoMVmwNRTdzOaPHXVlJeTPEbZJDitzJbbxmTFCkgcrSPKrMdXlWqMOysudWfwCVJTlXHfMfsvBEQwmhYLvXBUbhCmQISBZPwPSZxRihdyPprDGWeTHYcwoASHAsJFHVJCwHKEVuVkUlJVIPHKxVsEekCMwgCkLbqNkdMjnIWUoReIcWFHIPWyRPj"), true, string("izGsUbDluxfpLrxKNPixaKuLNhYeuqmfjFXxu"), 746512.5907344454, -252794.22877027615);
    this->xtMxbLvhDqxTS(-507177.3839918962, 1655783010, string("FzgCUgnNxVsgXkTSSwzZMbwLpxasndaGcIrMNQtvfelPssTIYCDrKpYmBuxeDssNNVwQEBhRWlOcehgIpaXMUWZUwgAsSPYkOfxDmBPoVXfLKriXMiDLTIsyVRrxuGoRyvxLwOZYYLLKszAOIZSyTIUnxGEdTmRfgmjbMIRLaQjjCAGLDDmVWbsjFFdrwyGCpslEaE"), string("pieVAcLwPuQoxyKsGlBPRcgnrpaLLvmmJHKHuCFFVKFbszwhbjVAENXUTWsSMkdBmxHWnCPeRKDpJrsBfbgXgZtTkMPxoDPTmQCowfhFNacztZEyGLpWIOHTOQe"));
    this->Nwbqx();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BbONWQSnvUUvoGP
{
public:
    string pujzocPPmSXt;

    BbONWQSnvUUvoGP();
    string lsWKGTxqTMvB(double IYjRM, double WVHRYle, string bdEEKlugFFNGTONh);
    double GWHQyYo(double sUqnbramJVaFPwYb, string HFiZYfwRUDIY);
    string mLQLBqFkjkfw(int jhKrgT, int vPCmaMpiSp, string KoluETTSkO, string rzPaIPCeUy);
    int iGXdpngvY(double MLFaOBvzNGbc, bool cIEZUfqXuAoU, int vUGEy);
protected:
    double uYDfYUlFRZith;

    int nJqcrDgJhYHA();
    void CwvIcABEtYFOXPS(double HnSDMnJqqs);
    bool HIpOkNllTLLUY(string cNrKqLkIh, double aNofSJkDlUANLEH, string ifZKcbs);
    double fAvUZkUKcAvtGH(string TdFslClFlC, double WwIRdtXR, string gjaKBVmllKLFqjUb);
    int lPBiASohUxbjE(int qWAyaFuU, bool UoJUa);
    int BvDdYbISDZLF(string fOaBCliUDAz, int dELhel, double macihcjzdcbqs, string WzwKHMqXaQAc);
private:
    int NxZjAqESVUR;
    bool cmpdYQYhxEi;
    bool PYjQnCMuqfQYo;
    int vaHAUwrvndsJAtj;
    double TRaVPzSIvQANCNG;
    string PTeVja;

    string LHPYWTSYrK(string jfoffxDoKbWGxe, double XIZCzqqNdkD, string HYPUqHhtibnaf, int GumTAqnlxaN);
    void qDiecGlVV();
    double DLFWIqTfBGKhk(int FnTdrHWvbVlwg, bool NMcruEXgs);
    void MiNUAkehNUAseSh();
};

string BbONWQSnvUUvoGP::lsWKGTxqTMvB(double IYjRM, double WVHRYle, string bdEEKlugFFNGTONh)
{
    string vcLFjjvlr = string("sRqtSBrQTYwCbdhsiRJSnkZjyDygpDgZKuKLlKyPqwXNIezFYargyrXgCaJkkssOkZdLz");
    double itQlHZkTrjl = -753257.1026888222;
    int dZobKEgIEWopa = 1162717772;
    bool RtBdAD = false;

    return vcLFjjvlr;
}

double BbONWQSnvUUvoGP::GWHQyYo(double sUqnbramJVaFPwYb, string HFiZYfwRUDIY)
{
    string isAaOLrVRNB = string("swoXGjmVOdcgSihpuMqyPguTiUHMBGaHzLZadTJFEHsmxgtvbPvXvFZtJRcMZyyxGRkNRQmChHELtJTrumVoAISQpLsipDYafHjcJCFTItyupVAmULZqvDyyXnfhtpboUZxAxnBQOgpMBpRlNvOzjBqtqOcanapvnQrUOesoFtqKOiLUdfWaAmuyRwaHwQUqfiPpHhANBQOzemmKMzDnUMSBAuFDNhGPmDrp");
    bool WeOMbRglPi = false;
    bool LSVfpqqGKMAKXCR = true;
    bool rsZXAsr = true;
    double yRlkWtRvEuTzyJzd = -829035.134324838;

    for (int VXyUcm = 315373588; VXyUcm > 0; VXyUcm--) {
        LSVfpqqGKMAKXCR = ! WeOMbRglPi;
        sUqnbramJVaFPwYb = sUqnbramJVaFPwYb;
    }

    for (int SSiGLPLl = 1506951064; SSiGLPLl > 0; SSiGLPLl--) {
        rsZXAsr = ! rsZXAsr;
        LSVfpqqGKMAKXCR = ! WeOMbRglPi;
        HFiZYfwRUDIY = HFiZYfwRUDIY;
    }

    for (int zzVdWx = 1144885952; zzVdWx > 0; zzVdWx--) {
        LSVfpqqGKMAKXCR = rsZXAsr;
        sUqnbramJVaFPwYb += yRlkWtRvEuTzyJzd;
    }

    for (int FwPOJNcwTnxbG = 1728402535; FwPOJNcwTnxbG > 0; FwPOJNcwTnxbG--) {
        yRlkWtRvEuTzyJzd /= sUqnbramJVaFPwYb;
        WeOMbRglPi = rsZXAsr;
        yRlkWtRvEuTzyJzd /= sUqnbramJVaFPwYb;
    }

    return yRlkWtRvEuTzyJzd;
}

string BbONWQSnvUUvoGP::mLQLBqFkjkfw(int jhKrgT, int vPCmaMpiSp, string KoluETTSkO, string rzPaIPCeUy)
{
    int XBbdupxiLWkIVH = -1273127101;

    if (KoluETTSkO <= string("pIIzxmqTELqIVxIooySnAacbubhXXtYYNRqnCcMuCVSviMkDwjxYGJcgYUxuIRmsxgViilxBdPCOLQoRRDUonO")) {
        for (int zzqeIzniZkrBB = 356957078; zzqeIzniZkrBB > 0; zzqeIzniZkrBB--) {
            jhKrgT += jhKrgT;
            XBbdupxiLWkIVH += vPCmaMpiSp;
            KoluETTSkO += rzPaIPCeUy;
            KoluETTSkO = rzPaIPCeUy;
            vPCmaMpiSp += vPCmaMpiSp;
            XBbdupxiLWkIVH -= vPCmaMpiSp;
        }
    }

    for (int zZhDh = 1672996927; zZhDh > 0; zZhDh--) {
        XBbdupxiLWkIVH *= jhKrgT;
        XBbdupxiLWkIVH *= XBbdupxiLWkIVH;
        XBbdupxiLWkIVH /= vPCmaMpiSp;
        XBbdupxiLWkIVH /= jhKrgT;
        vPCmaMpiSp += XBbdupxiLWkIVH;
        jhKrgT = vPCmaMpiSp;
    }

    for (int wDtMkdfAwyUFng = 2113596375; wDtMkdfAwyUFng > 0; wDtMkdfAwyUFng--) {
        vPCmaMpiSp -= jhKrgT;
    }

    if (XBbdupxiLWkIVH != 1923326384) {
        for (int OcqGs = 175093483; OcqGs > 0; OcqGs--) {
            vPCmaMpiSp += vPCmaMpiSp;
            KoluETTSkO = rzPaIPCeUy;
        }
    }

    if (jhKrgT < -1273127101) {
        for (int kmAJpOWNW = 2034526698; kmAJpOWNW > 0; kmAJpOWNW--) {
            KoluETTSkO += rzPaIPCeUy;
            rzPaIPCeUy += rzPaIPCeUy;
            jhKrgT /= vPCmaMpiSp;
        }
    }

    return rzPaIPCeUy;
}

int BbONWQSnvUUvoGP::iGXdpngvY(double MLFaOBvzNGbc, bool cIEZUfqXuAoU, int vUGEy)
{
    int DSjboOsRq = -932355879;
    string GEoXrG = string("QUrwNkLFJlvwGjzqnPucssxBSRWYIcZOXbhtyRXDZimrShIyTWbTrlrkzIgSnSubtTqqtzZsisXNkPwGyCgQYqBtCzXqyaFYfwWbUsBGVkatIaAptXZhgTngUejNIbaaFWwmLhxqBpJVnxVlEjfeXgNJuqVFLQlAEgYNrLzHyTGqYWjOHzwGJCucVEZoQEAGFSKASOIiPefCNHwamDdznXTYFqwhsqbJBesCqgtgGrizMoYVaqEfffKwNALv");
    double vRKzhvSwms = -969535.1773085694;
    double PLENYvpM = 214957.50960387758;
    string qkosXcfYvHbxyIPJ = string("LiGnYGZDyEkfDXDxMvUIneQIchFAsGgHuPUkHjvuouwtToaRWZhwpoXFLJXqYhEzjHHufiivqZEJxBVlNoFkrGGQeYCLEw");
    string WeyHIvuToUUFQn = string("fewIdUybPpOhEERilEqDrgshiyCwmGjnmDuRVcaUGCujjzoRoCzfegBWNwfFzqbjYxirWMqpEAHNxcKFvcGsUKtLjrUcbeSQIopqEmQWsBlBgrwKFzsZtvHNRcpSFJSUwFlLTNfYDQJCKGsGBcismEiclAtKPbneWRZnRbxCpkeCxPPIknXADjuGGwHVaFvPfupgwfl");
    int CIXOG = 1280809122;
    int gblAKApi = 868273882;
    string ptgPolZK = string("WjZokOPHcmVdLWswZBAwjgWjEzfmTkeWFdcEEkhYVwwIoHgECpChtBaSkUNNnhyYNVkTeobapDAYoSINNWNXuBVTOlCkaNFiWEIcgMpobSbTmnC");

    for (int zKzLqrwrOT = 2120194986; zKzLqrwrOT > 0; zKzLqrwrOT--) {
        continue;
    }

    for (int zhAehukc = 564515515; zhAehukc > 0; zhAehukc--) {
        continue;
    }

    for (int pCneLUiAig = 1278068188; pCneLUiAig > 0; pCneLUiAig--) {
        MLFaOBvzNGbc += MLFaOBvzNGbc;
        ptgPolZK += GEoXrG;
    }

    if (WeyHIvuToUUFQn <= string("QUrwNkLFJlvwGjzqnPucssxBSRWYIcZOXbhtyRXDZimrShIyTWbTrlrkzIgSnSubtTqqtzZsisXNkPwGyCgQYqBtCzXqyaFYfwWbUsBGVkatIaAptXZhgTngUejNIbaaFWwmLhxqBpJVnxVlEjfeXgNJuqVFLQlAEgYNrLzHyTGqYWjOHzwGJCucVEZoQEAGFSKASOIiPefCNHwamDdznXTYFqwhsqbJBesCqgtgGrizMoYVaqEfffKwNALv")) {
        for (int mDRvfNqQ = 1613950596; mDRvfNqQ > 0; mDRvfNqQ--) {
            MLFaOBvzNGbc /= vRKzhvSwms;
            WeyHIvuToUUFQn += qkosXcfYvHbxyIPJ;
        }
    }

    if (GEoXrG < string("LiGnYGZDyEkfDXDxMvUIneQIchFAsGgHuPUkHjvuouwtToaRWZhwpoXFLJXqYhEzjHHufiivqZEJxBVlNoFkrGGQeYCLEw")) {
        for (int MiZXnG = 797565275; MiZXnG > 0; MiZXnG--) {
            vUGEy *= gblAKApi;
            vUGEy *= CIXOG;
        }
    }

    return gblAKApi;
}

int BbONWQSnvUUvoGP::nJqcrDgJhYHA()
{
    double gLNJFwIskuul = 535978.4462009781;
    string JPzVuSwcYGZJiKZl = string("xssPhnwGvcUSonPxcFaduaUZPmUdFMXLJbLWIeUBMhXMsCujAUmdvBsJRr");
    bool VPQHQyBww = false;
    string OcJXq = string("zsaEocJpFwcCDfYmqvndsTETSVzUatrqKTVTWliVdsDM");
    bool CymSzidALH = false;
    string AdqaiJFHtzh = string("YoCnwOJWQbpIywnGkAEHhPcDaWfsWVJIBPWOsDqTwKoVDyhwtpbomManEW");
    double HiJbBq = 15338.54396815946;

    if (OcJXq == string("YoCnwOJWQbpIywnGkAEHhPcDaWfsWVJIBPWOsDqTwKoVDyhwtpbomManEW")) {
        for (int bfusZTDluwdRRSJ = 1317216056; bfusZTDluwdRRSJ > 0; bfusZTDluwdRRSJ--) {
            continue;
        }
    }

    if (HiJbBq >= 15338.54396815946) {
        for (int nJDqwcjCM = 72851804; nJDqwcjCM > 0; nJDqwcjCM--) {
            gLNJFwIskuul = gLNJFwIskuul;
            JPzVuSwcYGZJiKZl += AdqaiJFHtzh;
            AdqaiJFHtzh = OcJXq;
        }
    }

    for (int PLXBO = 2118132693; PLXBO > 0; PLXBO--) {
        continue;
    }

    return 2049125609;
}

void BbONWQSnvUUvoGP::CwvIcABEtYFOXPS(double HnSDMnJqqs)
{
    double nfcNhmiX = 753430.8328696971;
    int UCEjEQmpoCILxXQ = 1223010342;
    int nmVLLgbMqQIG = 13504094;
    double FMXhALJStlikcZjZ = 677995.6673850471;
    double tPfYK = -208461.3368242036;

    for (int loVKefsmWjkGxgv = 714738149; loVKefsmWjkGxgv > 0; loVKefsmWjkGxgv--) {
        HnSDMnJqqs += FMXhALJStlikcZjZ;
        tPfYK -= nfcNhmiX;
    }
}

bool BbONWQSnvUUvoGP::HIpOkNllTLLUY(string cNrKqLkIh, double aNofSJkDlUANLEH, string ifZKcbs)
{
    double NonmUrWhv = -687056.2661271594;
    bool HlrdgntOoU = true;
    bool FPWkvzfUzAjnIMd = false;
    int erpjzMKenpJJZyj = -1621051549;
    int LGHOXzKpPtZkmB = -883124804;
    bool zkMzqinyowTvLeqL = false;
    string YZMETYUHLW = string("hgXSQhGHpQDanjJpVcuwowTzNgjTgezegcTlrZRxVodtRLQiqOSGhuOWrceiQeeWAPFEELRZDxXntRnJkamugZicsnugTgRjnIiLtgRIMKNtItJYbYgIckYwEOjFLlARUDuUqlDAvVNnsxIMtRrveOERGWTztxDzxdhptbIlaubwdxGZrPLOBj");
    bool aYBPIlqBMEScIzCe = false;

    for (int oUHYnBwyZm = 1005650211; oUHYnBwyZm > 0; oUHYnBwyZm--) {
        zkMzqinyowTvLeqL = HlrdgntOoU;
        FPWkvzfUzAjnIMd = aYBPIlqBMEScIzCe;
        HlrdgntOoU = zkMzqinyowTvLeqL;
    }

    for (int swDkAKbAvzj = 1152431181; swDkAKbAvzj > 0; swDkAKbAvzj--) {
        continue;
    }

    for (int IWPMMNkF = 33229708; IWPMMNkF > 0; IWPMMNkF--) {
        NonmUrWhv = NonmUrWhv;
        cNrKqLkIh = ifZKcbs;
    }

    return aYBPIlqBMEScIzCe;
}

double BbONWQSnvUUvoGP::fAvUZkUKcAvtGH(string TdFslClFlC, double WwIRdtXR, string gjaKBVmllKLFqjUb)
{
    double XhysqDw = -328336.47132730426;
    bool JQlJeltKpXyOiKnP = true;
    bool LaEQpABmGrJCOfM = true;
    bool WxEwOTaqD = true;
    int JgpiSlhcYGiVm = 1328348883;
    int gdocHcXIp = 1861035555;

    for (int ZkLZFIdZysOAzc = 1866306601; ZkLZFIdZysOAzc > 0; ZkLZFIdZysOAzc--) {
        continue;
    }

    for (int NHbxt = 1337962075; NHbxt > 0; NHbxt--) {
        continue;
    }

    for (int BUFWHrclzx = 117417963; BUFWHrclzx > 0; BUFWHrclzx--) {
        WxEwOTaqD = LaEQpABmGrJCOfM;
        gjaKBVmllKLFqjUb = TdFslClFlC;
    }

    for (int rqvpX = 555915782; rqvpX > 0; rqvpX--) {
        gjaKBVmllKLFqjUb += gjaKBVmllKLFqjUb;
        gjaKBVmllKLFqjUb += gjaKBVmllKLFqjUb;
        LaEQpABmGrJCOfM = ! WxEwOTaqD;
        gdocHcXIp -= JgpiSlhcYGiVm;
    }

    if (JQlJeltKpXyOiKnP == true) {
        for (int uazhMbwHb = 1027833612; uazhMbwHb > 0; uazhMbwHb--) {
            continue;
        }
    }

    return XhysqDw;
}

int BbONWQSnvUUvoGP::lPBiASohUxbjE(int qWAyaFuU, bool UoJUa)
{
    int EToFbegkuwWfQn = 1259789925;
    double umxtfshDLK = -136856.65556903285;
    bool gDBCkIPXOCCti = true;
    bool uURYsB = true;
    string WpCTeMLBcSLkAMRj = string("ZaajbpFertBQqlRAhlTNYLKdsqjifiuOPqSVISAcsQsMnLiGftAwNfPSoEzVYPsupxviJNzM");

    for (int HLvgyWlE = 984613730; HLvgyWlE > 0; HLvgyWlE--) {
        qWAyaFuU -= qWAyaFuU;
    }

    if (gDBCkIPXOCCti == true) {
        for (int zaEnbLfr = 857540119; zaEnbLfr > 0; zaEnbLfr--) {
            umxtfshDLK = umxtfshDLK;
            UoJUa = gDBCkIPXOCCti;
            UoJUa = ! gDBCkIPXOCCti;
            qWAyaFuU -= qWAyaFuU;
            UoJUa = gDBCkIPXOCCti;
            EToFbegkuwWfQn = qWAyaFuU;
        }
    }

    for (int wCmIoqpAonnN = 686027915; wCmIoqpAonnN > 0; wCmIoqpAonnN--) {
        uURYsB = ! uURYsB;
        UoJUa = ! gDBCkIPXOCCti;
        uURYsB = UoJUa;
        gDBCkIPXOCCti = gDBCkIPXOCCti;
        uURYsB = ! UoJUa;
        WpCTeMLBcSLkAMRj += WpCTeMLBcSLkAMRj;
    }

    return EToFbegkuwWfQn;
}

int BbONWQSnvUUvoGP::BvDdYbISDZLF(string fOaBCliUDAz, int dELhel, double macihcjzdcbqs, string WzwKHMqXaQAc)
{
    string ssdNm = string("zBCu");
    bool jMdAA = false;
    int IHJIcATjnlWtiy = 2076752613;
    string rvKLkbXkVgkp = string("OrHDwodBlEjVgHZyopxFxpTaXIOorfkPhzhvdIUXlJOVIJkmWmDnlJvoggUMXoxYkWAvRYZctQtxzgXppYvfcWTPKdYYFEOqLvJvNrHdSbMlMaKJInbwZGtYzMwWHzJLoWrqbFaZIRRHvPDZuuJKVCwNlbyvrMckrdShVxZGNFzqlAwKFah");

    for (int JFhKJFhyKDEG = 730944787; JFhKJFhyKDEG > 0; JFhKJFhyKDEG--) {
        WzwKHMqXaQAc += ssdNm;
    }

    for (int mUmCdlaxGL = 1617457624; mUmCdlaxGL > 0; mUmCdlaxGL--) {
        fOaBCliUDAz = rvKLkbXkVgkp;
        dELhel *= dELhel;
    }

    for (int YpgFWYaM = 1329294108; YpgFWYaM > 0; YpgFWYaM--) {
        WzwKHMqXaQAc = rvKLkbXkVgkp;
        rvKLkbXkVgkp = rvKLkbXkVgkp;
        rvKLkbXkVgkp += rvKLkbXkVgkp;
    }

    if (fOaBCliUDAz == string("OrHDwodBlEjVgHZyopxFxpTaXIOorfkPhzhvdIUXlJOVIJkmWmDnlJvoggUMXoxYkWAvRYZctQtxzgXppYvfcWTPKdYYFEOqLvJvNrHdSbMlMaKJInbwZGtYzMwWHzJLoWrqbFaZIRRHvPDZuuJKVCwNlbyvrMckrdShVxZGNFzqlAwKFah")) {
        for (int ypcJPTTBymWeGqoO = 995502498; ypcJPTTBymWeGqoO > 0; ypcJPTTBymWeGqoO--) {
            fOaBCliUDAz = rvKLkbXkVgkp;
            ssdNm += WzwKHMqXaQAc;
            rvKLkbXkVgkp = WzwKHMqXaQAc;
            IHJIcATjnlWtiy /= dELhel;
        }
    }

    return IHJIcATjnlWtiy;
}

string BbONWQSnvUUvoGP::LHPYWTSYrK(string jfoffxDoKbWGxe, double XIZCzqqNdkD, string HYPUqHhtibnaf, int GumTAqnlxaN)
{
    bool sepHRSRi = true;
    bool jwkGbeiy = true;
    int UdwqxApgPgHJX = -2053866631;
    bool dhNePiBZ = false;
    double NobuCNNDAyijrk = 66703.32052366225;
    bool RtOmirnbAafP = false;
    bool aMIlZstxP = false;
    int nPRgeCGWhMZroqQ = 750595936;
    bool LdMAEaheKhsGDVw = false;

    if (GumTAqnlxaN <= 484533819) {
        for (int mwTQFDYfCE = 1711313719; mwTQFDYfCE > 0; mwTQFDYfCE--) {
            GumTAqnlxaN /= nPRgeCGWhMZroqQ;
            dhNePiBZ = sepHRSRi;
            NobuCNNDAyijrk = XIZCzqqNdkD;
        }
    }

    return HYPUqHhtibnaf;
}

void BbONWQSnvUUvoGP::qDiecGlVV()
{
    string qUkKtqAZZatHtSJa = string("hgyhkHjvTAgTqczYeUJpoQMsQBMzUyrxwrRXFOAFkYYJIAWKartyclWPfpgCaNGVpsQVjSSznkNTfJKsCECtqLxHTerOlhosheimyOeBcCvRdcgDBGfpYimBSgdXDzJnOaKTJIzqCozWNJCzleVQGiAUdBhjfWnDWGsXkRjfIciFeYLlkcKdFhQlCnULyJdlbdBrypSRsTXnOUhkLfDTwBGXydqWzdCgYtLySvIl");
    bool qzSHRTENYoPuIC = false;
    string sELQR = string("ZOJWcPSCuUwFJcSBIPYSIMMsBCGlaalkeoCRyOKTOsOuABFYbjDpzmqdqjkYAUDOvpHlYBFuRAFIVkByeMdAmhyllvKJTuMJuHchAAxzVBEeAVKXCUxGMlaLYluiQfxRCoJfpPPtEeEIWibOTtixnTZAOucrMniWuPNwntGzukobKlxTRBndAHSTzpoHyZSXwC");
    bool YZaeOKhOAiUNuIS = false;
    double dpQQvir = -361695.3640665137;

    for (int tNjjY = 93096905; tNjjY > 0; tNjjY--) {
        continue;
    }
}

double BbONWQSnvUUvoGP::DLFWIqTfBGKhk(int FnTdrHWvbVlwg, bool NMcruEXgs)
{
    bool zgPOIRrlLsqsc = false;
    string rYDIzhv = string("ZysWmxPMmVgoxDgXIESuAmYspvTGXokriUsWqfSuPRVALrROCqyYyXxRFlAFnurStfdlGWbbdkBWZhfoOTCcjpHZUewoDNmDnosWOKfKhWFWJiBPbXvIGsqZjFLFAZiWCJeOhfvsRpWEPZBsEZosOvlrszTkpfBNGEsWnIQJlcUlGamhXFrg");
    double JwXTSY = 733399.9374622563;
    bool vFtddh = true;
    int NoQMst = 1192395700;
    bool eJGXzhymFj = false;

    for (int GbFiPvn = 1205592840; GbFiPvn > 0; GbFiPvn--) {
        vFtddh = ! zgPOIRrlLsqsc;
        vFtddh = ! NMcruEXgs;
        zgPOIRrlLsqsc = ! NMcruEXgs;
        zgPOIRrlLsqsc = ! eJGXzhymFj;
        zgPOIRrlLsqsc = vFtddh;
    }

    if (NMcruEXgs != false) {
        for (int EjiiWFNmLpLxYW = 1662716519; EjiiWFNmLpLxYW > 0; EjiiWFNmLpLxYW--) {
            NMcruEXgs = ! vFtddh;
            NMcruEXgs = zgPOIRrlLsqsc;
            zgPOIRrlLsqsc = ! vFtddh;
            FnTdrHWvbVlwg *= FnTdrHWvbVlwg;
            eJGXzhymFj = ! vFtddh;
            eJGXzhymFj = eJGXzhymFj;
            vFtddh = ! zgPOIRrlLsqsc;
        }
    }

    if (FnTdrHWvbVlwg < 1417008773) {
        for (int xVcGeeA = 954300275; xVcGeeA > 0; xVcGeeA--) {
            NMcruEXgs = zgPOIRrlLsqsc;
        }
    }

    if (NMcruEXgs == true) {
        for (int tAWKvIIIiDSjkuL = 1012409975; tAWKvIIIiDSjkuL > 0; tAWKvIIIiDSjkuL--) {
            zgPOIRrlLsqsc = ! eJGXzhymFj;
            vFtddh = NMcruEXgs;
        }
    }

    return JwXTSY;
}

void BbONWQSnvUUvoGP::MiNUAkehNUAseSh()
{
    int zyXHxzCsUrVPZt = 1651792082;
    double PyqNJtPYGZHgGfvR = -947165.2980914341;
    string kMmPK = string("gpXoVrRIfiGmgdHjaAhRujkQcJntmqvERxcxZQEQCRDRzJxcCYpnqMRANqDKyFJwTgzkNMZREDJTFeBJplmadtETkDlddNCKYjsFrECEodJStcJlBhCGJSKerBtbMCzIxlVweZdZOzFNMZXOFoSwARCbtgcLAKSywzhqLTmucrvlzwhLIHYNxmVBQgRLyKxfhBnRGPHYDwYCKOXWkIYFYrJdzADbfhUdWTYnXHaBCxyJTQhJNQU");
    string YawaxE = string("MtKLViXWhOQSPPnWlmWRyYlMEdSkOEYQDCxAZttufSZUtgMfglhXuKLEfHFsVbvxoBsBvrnau");
    double eBNBjw = -70707.72255091855;

    if (YawaxE < string("MtKLViXWhOQSPPnWlmWRyYlMEdSkOEYQDCxAZttufSZUtgMfglhXuKLEfHFsVbvxoBsBvrnau")) {
        for (int LSBIWceHlyxzk = 240786189; LSBIWceHlyxzk > 0; LSBIWceHlyxzk--) {
            zyXHxzCsUrVPZt = zyXHxzCsUrVPZt;
            PyqNJtPYGZHgGfvR /= PyqNJtPYGZHgGfvR;
            PyqNJtPYGZHgGfvR -= eBNBjw;
            kMmPK += YawaxE;
        }
    }

    for (int KlfENUoeSpGrXkL = 786599201; KlfENUoeSpGrXkL > 0; KlfENUoeSpGrXkL--) {
        zyXHxzCsUrVPZt = zyXHxzCsUrVPZt;
    }

    if (eBNBjw <= -947165.2980914341) {
        for (int VlztylpyztxYg = 353724911; VlztylpyztxYg > 0; VlztylpyztxYg--) {
            eBNBjw += PyqNJtPYGZHgGfvR;
            PyqNJtPYGZHgGfvR = eBNBjw;
            eBNBjw += PyqNJtPYGZHgGfvR;
            YawaxE = kMmPK;
        }
    }

    for (int Oayafz = 1749257729; Oayafz > 0; Oayafz--) {
        PyqNJtPYGZHgGfvR += eBNBjw;
    }

    if (YawaxE != string("MtKLViXWhOQSPPnWlmWRyYlMEdSkOEYQDCxAZttufSZUtgMfglhXuKLEfHFsVbvxoBsBvrnau")) {
        for (int VkokfuoqMmYTWed = 1606024729; VkokfuoqMmYTWed > 0; VkokfuoqMmYTWed--) {
            zyXHxzCsUrVPZt += zyXHxzCsUrVPZt;
            eBNBjw -= PyqNJtPYGZHgGfvR;
        }
    }
}

BbONWQSnvUUvoGP::BbONWQSnvUUvoGP()
{
    this->lsWKGTxqTMvB(760712.3031776742, -407161.69159397046, string("haimqCLkpggWYpTYcErmBCSvClozMyUTaTRFVnPcTNvwXKmiWOUJsmqqBbwsTkvjQlsFejEgjaNkfarAqWHsIVRYAnNCKwTnYGGNKpkMXvwovFsmGaLrMAnBlLpgcPLasbEElstInalPHnOUykxBxQTdIrXZYlmbqkIncVKwtRQbQCoyxCJmGTuzhYmFJzylcRGVrOXPdMYfzzsxOcbnfEEYrWXtuPleuhVbKDOAmBjJpAeqCTI"));
    this->GWHQyYo(241125.73785402023, string("GnTxjujYystGgOODQzUwzFKGOTfSfupewlZVUYVuglKwOSzvKTPWPVVyItrfXmUddjuBrySJietBcfpQPfkkgdWphWlSdxmTcFeZibSleqnWlHrOFvOyTArWmNfOgsEzwgGKggfBsBWnBSoDVkJLPdbByPmIwfzjJkTKrqPgVQxEjOtUMqUIOmLyjoHAfUwHlQTkfrEYNoOXVOXqAWePFzcGRYrG"));
    this->mLQLBqFkjkfw(1923326384, -631755782, string("pIIzxmqTELqIVxIooySnAacbubhXXtYYNRqnCcMuCVSviMkDwjxYGJcgYUxuIRmsxgViilxBdPCOLQoRRDUonO"), string("DUUmmSrMRJrIPRlBcGdUbZDvxyVVPJOyHcADUmWivTdmmsYMijkSFsyDUzjuG"));
    this->iGXdpngvY(-485974.0520328905, true, -456581105);
    this->nJqcrDgJhYHA();
    this->CwvIcABEtYFOXPS(-624844.9038312444);
    this->HIpOkNllTLLUY(string("rlWRbjOEFoUKNeHWFpAPmawowvgSXYRuBySjOsqhgq"), -83631.9124002149, string("thrXyFvOgVVrLbZnLnClpSigkPfEkkvFpOdVRrpbkNImOtAsulTfxZHXPoFzheuNRyfpFrJpxPvCmDUwnCyysOqLWgQUvGvOLCWBuOlRnwSQiIOVKXddcGAxPEFnjzBERstT"));
    this->fAvUZkUKcAvtGH(string("HfiQvsqnaxzfhZrtqIMBiHjjmAAcYeEewsOriaIyLNNMosnzXetEaEKxUWXnNXLPonOaQYVLVdieQjBwoqqfZRUGrNkyqYnFSwBllOlALzfRZYtbfulaLDHYVYFzzNwpeLZuEiWwqSNwshmatuZtTOYZnxOvfTWcNAhxsWjTXsiYcZAIBeosPtXP"), -581344.8049213665, string("VwliUhsQUuabDnKebUHxvRlgvMISJcOPOKzgSoUTDvlfHMEFboZFqWHSbFhCQLucNUMFftSDuarQjDGpDtXkZOwBWQOd"));
    this->lPBiASohUxbjE(-1944168340, true);
    this->BvDdYbISDZLF(string("fYybBQknUDtkHVXJnACpGGPDYamkryBkKJGrmgbKYcLQcrOQUkjELBAoKqowkVihRYwstzxjV"), 1008839760, -755894.0159331373, string("BHheLZornXsaLSrWGsVuTcMURlDNIjVYlzEssKRVwlpmqMtCYxvLbtiuzgUdSZAyWntDqnuArmIUAfZKlfQgfHvPJSpdOlredWVMTolGGHWHJXQsyYiLuCsZfwbECcTfSbOwWQUOYbxAQBIJOluFbOnKWKWQGAbPpLWWFwvzChC"));
    this->LHPYWTSYrK(string("yCeMdZHjMVdBCovjYytGTJqTmDhMreuZuswqMYptYtREfqVizsueKtFUETZCzhAbTMRYBbF"), -510403.16683251015, string("HfgGUWNxELQHgrGUIakhflpHieUxnMOqkVfJtEgpMBDytskIfkBCwZCQBxRKiIVmbNNsmARNvaPwbpcNpUyAIBgcBbJtETksSpxkaIOCIwKRJpVnMdQKzGAMhtlrOmNJUsTgImkwlScXMRLaRPpdgUPrCdhVUqWlIvJkzPHSKIdVMjhREAenHOIxibdVH"), 484533819);
    this->qDiecGlVV();
    this->DLFWIqTfBGKhk(1417008773, false);
    this->MiNUAkehNUAseSh();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mpZcwckXZlVSomC
{
public:
    bool uPCfmpNXyP;

    mpZcwckXZlVSomC();
    void UOhOspJ(string XQiBMosAlNjHdP, string cRmKX, int SccKoWmRc);
    int LxmNsXu(bool qphFxam);
    int TUrfYuqO(bool hOiQYKNQFKSaLYns);
    bool ZtjdypUYOxnaQlv(bool WxaiEa, double DunUfPsVQdTVsst, int EEilsfRGKeOR);
    double tmWaTlIUcMOhc(bool HWjVzFzqD, int gQTDsTfA, int WbdwYOfXq, int NVYuJQas);
    void PYpOZKUXGFoi(int XGxgDbXDFw, double FbzyAaWkPYhWEXiO);
    void OuueHYJmJQcIkDZ(int InfjkNli, string FikVhkxXsdPwERCs, string tPirv, double rUcqcniULAV, bool cjFxWBZh);
    string mEqXlvwwmMMYS(double DvGyOp);
protected:
    bool DXfnz;
    int MGafCF;
    int avAylg;
    int NsJiHkmtYi;
    double MApcolKeL;

    double BbkZvQFxtq(int fweltvgfRZtCeXr, string EdgMW);
    double WdTavzdDifAEKLPN(string cvHSUNSFkMKDU);
private:
    double rTHApRiEexLwLadd;
    bool SSUnHaqxRvqWmGj;
    int RGQbN;

};

void mpZcwckXZlVSomC::UOhOspJ(string XQiBMosAlNjHdP, string cRmKX, int SccKoWmRc)
{
    bool HRnzCoYAk = true;
    int tlTzDjrUCGStpi = -1235972522;

    if (SccKoWmRc > 2024519487) {
        for (int GrzljTgoqUuDRK = 1294981645; GrzljTgoqUuDRK > 0; GrzljTgoqUuDRK--) {
            continue;
        }
    }
}

int mpZcwckXZlVSomC::LxmNsXu(bool qphFxam)
{
    string cfGjqJjwJvCsWrLF = string("GCjAzbKLTcavbtqrXkkXzWftrkgHTstRxDuXfYmeZcxmiNygXLzmETdVCeT");

    for (int TSnJehC = 2020778608; TSnJehC > 0; TSnJehC--) {
        continue;
    }

    return -26242203;
}

int mpZcwckXZlVSomC::TUrfYuqO(bool hOiQYKNQFKSaLYns)
{
    double HbixJSBJRTiD = -972693.6543794398;
    bool zYkGvozxGltLFY = false;
    double BwHnckNbFaqFKSL = 672401.892942967;
    int OmgfolflfFsIOJK = 1114429588;
    string lPUMd = string("mZLRRCvsigEzbWVWpleeOPBMZCQWNCoFcMFMihqUYHekYJNkmbTLbCLKpweDPXqzVqMdHDjfbpRchQWeNhunogwPSNgXhmrpP");
    string BCFBPdvQDhd = string("NwUNHssRtFdnECuOFnxCLcneGLGEahZjqJtVCDnfFluoOJaBccFQwjGagWLcfqfEnwgSTaJeyHEdAeMBebYBbPOXqIsTGbJbnrpWeNVzYFHeJHReIyrnopqxhszOPCdViCJxOrxnuufKmzxGHPgDYinOfCNQNEPYfGMRXTgeLkjPbSxRwbWjhQJZQWwKRWAWASoEPYRBJxfdXzrLwSfkQqEavvzcGTsGTcmttGAw");
    int OlFSlc = -1867375711;
    bool nuCJxziTaUfLo = false;

    for (int LdPiwrzikWEO = 1629895251; LdPiwrzikWEO > 0; LdPiwrzikWEO--) {
        BwHnckNbFaqFKSL = BwHnckNbFaqFKSL;
        zYkGvozxGltLFY = nuCJxziTaUfLo;
    }

    for (int CFWAF = 254327759; CFWAF > 0; CFWAF--) {
        BwHnckNbFaqFKSL /= HbixJSBJRTiD;
    }

    for (int DOamzc = 603328581; DOamzc > 0; DOamzc--) {
        BCFBPdvQDhd = BCFBPdvQDhd;
        hOiQYKNQFKSaLYns = zYkGvozxGltLFY;
        OmgfolflfFsIOJK -= OmgfolflfFsIOJK;
    }

    return OlFSlc;
}

bool mpZcwckXZlVSomC::ZtjdypUYOxnaQlv(bool WxaiEa, double DunUfPsVQdTVsst, int EEilsfRGKeOR)
{
    int UfOLIYJIxv = -329009024;
    bool ewxLS = true;
    bool aLaNLFrpUE = false;
    double yLUYbrJCBWWvUx = -180838.7764439486;
    double FnANkakPFzJqive = 319535.861113863;
    int OCdQyasIrfm = 1473962553;
    int onczGKAg = -815660521;
    bool MQXLXeSuoMxingz = true;
    int CyKRHZjGc = 98042306;
    string hCkdugDxHKzlauoO = string("dXejRnrwkjfxNPTDKvCBvGXRauYKSCtbHDZCAnmbzBxpFWQGTXoWCBUUuEnDUnpiftlLUaxwVPlgDFWgmgczEnMLJEIJpOYzkinrZyhdvnjqtrTHKGNbClhliuVkTFlnjtRjDIGTfrJYthQaxrmAiCs");

    return MQXLXeSuoMxingz;
}

double mpZcwckXZlVSomC::tmWaTlIUcMOhc(bool HWjVzFzqD, int gQTDsTfA, int WbdwYOfXq, int NVYuJQas)
{
    string JGvRbwJtuWwMM = string("iaFbQUSLmflnnsQQvAXdZWMVRJHWqGqTOTfxpuPBhDcxxknSyZIVQhwMXOZgSQlUEMhEBmROskfzMHALJxyECceZyPDizGDFXezVqMjUzAhUyuDwtFyCadTGMivxLSQiaHlDVGhxygawZjtvaKmwukKvAZPNomVtpyAKWaUtHxKrMUgwLypZwlDzQXBQBOwISzqVrHsnllFHYshbEQzLploaVfSSFNceJrBGuYMsSpTLvbsaaBnfY");
    bool zEwmsewqmzuT = true;
    double IIiRJmr = -469099.9171141209;

    if (IIiRJmr != -469099.9171141209) {
        for (int cKHfVPHyTbHvHka = 1737853139; cKHfVPHyTbHvHka > 0; cKHfVPHyTbHvHka--) {
            gQTDsTfA *= gQTDsTfA;
            gQTDsTfA *= NVYuJQas;
            HWjVzFzqD = HWjVzFzqD;
        }
    }

    for (int VECNRsq = 319029348; VECNRsq > 0; VECNRsq--) {
        continue;
    }

    return IIiRJmr;
}

void mpZcwckXZlVSomC::PYpOZKUXGFoi(int XGxgDbXDFw, double FbzyAaWkPYhWEXiO)
{
    bool gbstV = false;
    bool tBZBuwul = true;
    string peGZGhRMwsWd = string("zPjOHFqNPLztzMabskKkOQShFpYzUGPxAaEibSNabRUnxQYgUOifCsimMNDytQkkbLyKhCyXvTXpIOJPDehCpBUoHmeysXpWwjUKQhNQvLVRUbNrHOmQSVmbdPoTTszVWzQqlQKxeuHSwDXMVtapewKqoLayPJwRoGQBCoMPaDeKYcQMAIzxteCrdZiybCpvsQLVIboeZhQxVPBBvALQHKffizKlJLbXIsLhMVCJl");
    string eCRdl = string("KSFXGLnUhlySgwCLWOBxyuwaeuLFMPcklNyjxzyirQtDRhsDpAGftJEFDRaPBbLNVwhlWqvshlgHoVA");
    bool bDfix = true;
    bool fCCZiHPAYfYryc = false;
    string pgBeVj = string("wPKTTZzaXZNAJgfNzVb");

    for (int bXrrbcyRWFcTHKEm = 1719246472; bXrrbcyRWFcTHKEm > 0; bXrrbcyRWFcTHKEm--) {
        fCCZiHPAYfYryc = ! gbstV;
        XGxgDbXDFw *= XGxgDbXDFw;
        tBZBuwul = ! tBZBuwul;
    }

    if (XGxgDbXDFw > 69571995) {
        for (int EevFZ = 500828413; EevFZ > 0; EevFZ--) {
            continue;
        }
    }
}

void mpZcwckXZlVSomC::OuueHYJmJQcIkDZ(int InfjkNli, string FikVhkxXsdPwERCs, string tPirv, double rUcqcniULAV, bool cjFxWBZh)
{
    string CFzuejlrZP = string("csGDDrPrIuqORmWehsQLppPUDuIcWYyjYANigOZbyVkVLSdPYtmxAvkwyKbodOKXDuEzxddbCZfzBaeUhDxEmXQeBEozAxzWTOYGjbgVvpfTjgnjarveCUeybvMrwRrUaHBngkzlOKRqCkDMlXwadqWpUzHsJTBAjTrjTfvylRYISkLOgQpuAVYvEhjeoJZDqAYf");
    string KISbQjTqQKrJ = string("WIQpTlNTJwHIByNLxNxXQWUWfSkDSPGPQBhefwetEnATFvNZudFlIRmnimnnakWtQKdtSZJNLDiiUJmRnvxFdsxJvygSZsgjWdyBjDakuHdYzylRULVfcnWXkNFeLeQhiGuuCAFBbKsRxwvbvJfQxFtVdgsdNnwnHzWsauLBiFzOFJMhWCVOaNQeTuRGnFZyLlzPFTxIcsXJIXtKFtsrKBAXRr");
}

string mpZcwckXZlVSomC::mEqXlvwwmMMYS(double DvGyOp)
{
    int ufqtJpXAMPo = -741958226;
    int lIcXHHUtMj = 989477354;
    string FCTERvaPHc = string("UUnuHvCTJNVAPZPiAcsdMYedLkXbOopqSvTLeWpqvfpKEvzTiIolki");
    string YKMmUmbwfMzKPf = string("EMcglzYwbyDavTCUTUDdHgEjzjTTYdSSSfTdapqgZ");
    string hRFnUSQL = string("kofpCxARjWIkAhtWaInDswMTKbxKVDOOw");

    for (int ZqcbOVdQykbd = 1283530051; ZqcbOVdQykbd > 0; ZqcbOVdQykbd--) {
        hRFnUSQL = hRFnUSQL;
        hRFnUSQL += hRFnUSQL;
        DvGyOp += DvGyOp;
        lIcXHHUtMj -= ufqtJpXAMPo;
    }

    return hRFnUSQL;
}

double mpZcwckXZlVSomC::BbkZvQFxtq(int fweltvgfRZtCeXr, string EdgMW)
{
    int PKxsVGVDF = 1057268085;
    double MXFSnwKunoXMEnuy = -1012775.171954815;
    string HMUWrvtquIT = string("skKrlnjAsqyWTGPgeSQGUQgwVnNBovXsKIutycdWFFxUxQVcKuJqdDXUlYuerfYXKridibtNtNpgOJfBYrmbPDtGvwZhjNeQohCbhzthnbVkkbfBiWYfNQQMzNruvnYGfOFDCGfBqcaRGQxXPYSzztYZftPZTuMAErwqiphPCifjihyNgkKgeFRFQzrlRvGgrYcwoxwbKYDLnfCnGEjVEhQNEKOfENwDeWvnMFAVvRYQkhYFqlFsZXSlnCfVg");
    double yTAuvbrxnbjK = 388244.64075943147;
    int VEBwuJVEscwcnon = 1857341275;
    bool mMXqJip = false;
    bool NVuUaNIxJ = false;

    for (int lgexJgFwJYyyug = 1828267402; lgexJgFwJYyyug > 0; lgexJgFwJYyyug--) {
        HMUWrvtquIT = HMUWrvtquIT;
    }

    for (int lPUlDcgLTZeo = 1221459049; lPUlDcgLTZeo > 0; lPUlDcgLTZeo--) {
        fweltvgfRZtCeXr += VEBwuJVEscwcnon;
    }

    return yTAuvbrxnbjK;
}

double mpZcwckXZlVSomC::WdTavzdDifAEKLPN(string cvHSUNSFkMKDU)
{
    string IoYvIsvmrWiNoIi = string("jfMEKUjagAM");

    if (IoYvIsvmrWiNoIi != string("jfMEKUjagAM")) {
        for (int cnchDZ = 876609514; cnchDZ > 0; cnchDZ--) {
            IoYvIsvmrWiNoIi = IoYvIsvmrWiNoIi;
        }
    }

    if (IoYvIsvmrWiNoIi == string("jfMEKUjagAM")) {
        for (int AElLuXn = 1379165887; AElLuXn > 0; AElLuXn--) {
            IoYvIsvmrWiNoIi += IoYvIsvmrWiNoIi;
        }
    }

    if (cvHSUNSFkMKDU == string("olVCyAsimdzyxvOIkMlrulgQipIjFdSZuKCfWUDWjXpkhSvxcbaXLrNtCLxdK")) {
        for (int IzZSNJgGe = 894255391; IzZSNJgGe > 0; IzZSNJgGe--) {
            IoYvIsvmrWiNoIi = cvHSUNSFkMKDU;
            cvHSUNSFkMKDU = IoYvIsvmrWiNoIi;
            cvHSUNSFkMKDU = IoYvIsvmrWiNoIi;
            IoYvIsvmrWiNoIi = cvHSUNSFkMKDU;
            cvHSUNSFkMKDU += IoYvIsvmrWiNoIi;
            cvHSUNSFkMKDU += IoYvIsvmrWiNoIi;
            IoYvIsvmrWiNoIi += IoYvIsvmrWiNoIi;
            IoYvIsvmrWiNoIi += cvHSUNSFkMKDU;
            IoYvIsvmrWiNoIi += cvHSUNSFkMKDU;
        }
    }

    if (IoYvIsvmrWiNoIi <= string("olVCyAsimdzyxvOIkMlrulgQipIjFdSZuKCfWUDWjXpkhSvxcbaXLrNtCLxdK")) {
        for (int hFfKJoPoydqjiuwV = 1779074483; hFfKJoPoydqjiuwV > 0; hFfKJoPoydqjiuwV--) {
            cvHSUNSFkMKDU += cvHSUNSFkMKDU;
        }
    }

    if (IoYvIsvmrWiNoIi > string("olVCyAsimdzyxvOIkMlrulgQipIjFdSZuKCfWUDWjXpkhSvxcbaXLrNtCLxdK")) {
        for (int DCBMOU = 1038382918; DCBMOU > 0; DCBMOU--) {
            cvHSUNSFkMKDU += IoYvIsvmrWiNoIi;
            cvHSUNSFkMKDU = cvHSUNSFkMKDU;
            IoYvIsvmrWiNoIi += IoYvIsvmrWiNoIi;
            IoYvIsvmrWiNoIi = cvHSUNSFkMKDU;
        }
    }

    if (IoYvIsvmrWiNoIi <= string("olVCyAsimdzyxvOIkMlrulgQipIjFdSZuKCfWUDWjXpkhSvxcbaXLrNtCLxdK")) {
        for (int OTYWLMd = 823720273; OTYWLMd > 0; OTYWLMd--) {
            cvHSUNSFkMKDU += cvHSUNSFkMKDU;
            IoYvIsvmrWiNoIi = cvHSUNSFkMKDU;
            IoYvIsvmrWiNoIi = cvHSUNSFkMKDU;
            cvHSUNSFkMKDU = IoYvIsvmrWiNoIi;
            cvHSUNSFkMKDU += IoYvIsvmrWiNoIi;
            cvHSUNSFkMKDU = cvHSUNSFkMKDU;
            IoYvIsvmrWiNoIi += IoYvIsvmrWiNoIi;
            IoYvIsvmrWiNoIi = IoYvIsvmrWiNoIi;
            IoYvIsvmrWiNoIi = cvHSUNSFkMKDU;
        }
    }

    return 605614.0604079346;
}

mpZcwckXZlVSomC::mpZcwckXZlVSomC()
{
    this->UOhOspJ(string("JwemsANuARkOjwiDxxvkkhDTQQEmpndqLYKOcKELNKTErtwhFyuUFYwUIIIwVopAKTuXRkEiQlkgRprddhTOYUCvPQHwjrSeosDwMxcjBtCJVrFDKVudSYnKOctuYwJGHXVauSFNrteYgzxKvnBADCliawiiWiTqPZQzfjVuFNqNcFpxPxYQNGjTiHnWdgKfRmlsQBxQZcLZecHenYPgahPXdyfDeRtQTDRUPeyNU"), string("wVukDTBnReEbdNtuRvSbejXBtQXlacefSrulFUZmMdlEbhIHc"), 2024519487);
    this->LxmNsXu(true);
    this->TUrfYuqO(false);
    this->ZtjdypUYOxnaQlv(false, 464310.98099351616, -1279272169);
    this->tmWaTlIUcMOhc(false, -399750557, 364795846, 2114664487);
    this->PYpOZKUXGFoi(69571995, 768124.6463124881);
    this->OuueHYJmJQcIkDZ(1225314589, string("VfyfqoYpcEYFldbSYaOIMjqxpHMgIiMSPjoURCnaQbCNApNSZxOEhZkemVrFMGXaMyQVkEyNSMTTUAGUciIbmgbBLJuTJxAuVWnTxMjVGAAmUQXlemgVjAUOBzeJqhNmcDpRCIXwvuVJkEPsZWYQPYJJvQrOpzCp"), string("fmLmPCPKkRqpwNaGKyUvSkOlmRfCqsAlejpKxNmJfTBVojdoPAvsshFZjZOCsxaPaLtPOFpmydqQeZIQtMHLjKPzsjkfXxnyXBWZixIvYqCcFpABuQqBNHNutoeuUXChReyfOHqPOnJNoSqtBVqyWpoUeVJXxnWTZoJwvgFlepBQtDLsCVDhZCHLRKIquenMSOedKtVUtGMmLuZNcmNRWoNEnnibImUocrzDLXcZhTpIRNQAbGB"), -586517.5690700649, true);
    this->mEqXlvwwmMMYS(762351.1274132638);
    this->BbkZvQFxtq(-720278735, string("EgeRjlsQOyqBtpbPDazYmfWoDSkiGhnGKhgraKrcnCvTAROaBbMykPzZNwDVbTBLGSdHzYcUbsKqfoSVqCafHFiUfakjwRPHdHdujYMnVUStMYgLPvKnUNuKFPrSVccxjEqUWeQvmLhqiOopEiyUtIPBzQiQNaPcqOezIBng"));
    this->WdTavzdDifAEKLPN(string("olVCyAsimdzyxvOIkMlrulgQipIjFdSZuKCfWUDWjXpkhSvxcbaXLrNtCLxdK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nltWahiIulFY
{
public:
    int vQhnPvZsl;
    double YnXdbZjVrnVn;

    nltWahiIulFY();
    bool KnepkqtbpquI(double iYmEavGEWVrOuDnq, bool JwQjzsqlA, bool ZRrJIgqPFIbrYOO, int fjMzxaAv);
    double JHXyiCMYhP(int XMYQbrWMgHiLCp);
    double wfGbGBg(double yBsPKs, double iQiQLl, double fATsPZFi, string ibsSpVEPY);
    int SOsmcJRJQb(double iQizdpfmLyFk, string eLOHpQUBZpTAyvI, bool gSmCysUDDIikvoa, double kkkiTY, bool rykiGS);
    double zvyTXOJWeNVF();
    double RiEYTpfWyqDRie();
protected:
    string dcEDxSFxkCPa;
    string uVOEKinnrVpsCUq;
    bool zICbYmgHopqC;

    double XdcBkjPBOHMw();
    string MrlcYXtwTFAkK(int IwjEXySyMG);
    double DDiUSViewW();
    bool NwqeaIRheRK(double yTAcycuJoRbtwrn);
private:
    int ZSbjnhteRwhe;
    double MIwLqQl;
    string ydRQCKDNk;

    string BghzXBN(int HjcEKfZwcgO, string NNFkrDUfzGWLxvye, double jHCgApBjdFSBWmuD, string DMKtgf);
    bool EYfMSCOEYK();
    double jNUDWhPwqdtLHs();
    void OobWgLIlgtsH(int BLdOaB, string UTcbicVjb, int EzWltzragn);
    string sZFlJuJwS(int MJptikktTcDK);
    int nLkJeatfpsv(bool EIcubmHHLc, int KejuNsDpe);
    bool YlPAoYRPVOzy(int VWcsa, double SbGLzlOgj, int OiluBKm);
    string vhkrPFwZvp(int izMZWJAHSgzwzUOW, double wOmkuNYVhdkuO, string zJkKEQcmFIShaOc);
};

bool nltWahiIulFY::KnepkqtbpquI(double iYmEavGEWVrOuDnq, bool JwQjzsqlA, bool ZRrJIgqPFIbrYOO, int fjMzxaAv)
{
    bool wChJfISpcZTK = true;
    string nnzhnVDjgN = string("mewZwHItHUwzDsuUSAvacgwFPfgKcvFudGglRePJqMysvvvkzGndjYvmxPnhduflwqxBwQRgvUZJWvzqhqxgZPPXPtPebhyTAoNdYuIoWDzFWRTXGVDeqxZCAYCDXzCuWqsDPUrnVLZTlVnwoflTNhiIZPERqsAHckWaILkvNyICkcM");
    double RBpcHeCnQL = -220341.25879094627;

    for (int aPlBAEM = 2023411555; aPlBAEM > 0; aPlBAEM--) {
        RBpcHeCnQL = RBpcHeCnQL;
    }

    if (wChJfISpcZTK != false) {
        for (int fxkAIwBfz = 625857882; fxkAIwBfz > 0; fxkAIwBfz--) {
            continue;
        }
    }

    return wChJfISpcZTK;
}

double nltWahiIulFY::JHXyiCMYhP(int XMYQbrWMgHiLCp)
{
    string lNgLXPjfoGpwY = string("UDUyyiAjYBTBZGZiPHdmKRamCLNsCdpIIhZaHI");
    bool xvTiiuT = true;
    string yshJHP = string("tsdlJiaoXtqmunjjxoarFfmSvjlDtTnhqJpJqZvxUhDRQMnAfesGMdjLTiiqQBQypkxYjiZycwfsQvJOxduFZGqgyciBNGRBWpYEpKrSIvqCGxSiEoAjCgaLPjNDuRMOSRmgDjZrJwRWKYNKktBRcDFevAsbHFbnmjngtvxiYmYBbltJJAwlcbNNKQzwuytYMuS");
    double caoCknesqG = -48893.33650771647;
    bool OEQGFLe = false;
    double gpwEO = 154705.45150423606;
    int VrrjwlJ = 829289679;

    for (int HkmGwsCIy = 985096508; HkmGwsCIy > 0; HkmGwsCIy--) {
        yshJHP += yshJHP;
    }

    for (int fbYpmfOchAMs = 584714442; fbYpmfOchAMs > 0; fbYpmfOchAMs--) {
        xvTiiuT = xvTiiuT;
    }

    for (int xdifpEsuSUSUSVm = 45535378; xdifpEsuSUSUSVm > 0; xdifpEsuSUSUSVm--) {
        continue;
    }

    return gpwEO;
}

double nltWahiIulFY::wfGbGBg(double yBsPKs, double iQiQLl, double fATsPZFi, string ibsSpVEPY)
{
    int zxaRdQPzvBxnCD = -1248135467;
    string PxHcfbVeRESGrqe = string("WhgfnDPYPHIeAqDcJkJQs");
    double wivPrm = 476883.60780503915;
    bool qXiBmGkgqLeDd = false;
    bool oZjMqKDAXYyPym = false;
    double XeHZToGXEtGt = -618269.5288764862;
    int vREISgjC = 900328262;
    bool PlLSABIMv = true;
    bool cPluNQmqP = false;

    if (fATsPZFi > -618269.5288764862) {
        for (int oGgZpgCfMQhT = 1286884187; oGgZpgCfMQhT > 0; oGgZpgCfMQhT--) {
            oZjMqKDAXYyPym = ! qXiBmGkgqLeDd;
            oZjMqKDAXYyPym = ! oZjMqKDAXYyPym;
            wivPrm -= iQiQLl;
        }
    }

    for (int AeSLVwJMwcQ = 2020249703; AeSLVwJMwcQ > 0; AeSLVwJMwcQ--) {
        continue;
    }

    for (int pokIWRah = 111918743; pokIWRah > 0; pokIWRah--) {
        continue;
    }

    if (yBsPKs >= 346212.7421677021) {
        for (int EQkfAW = 896638707; EQkfAW > 0; EQkfAW--) {
            yBsPKs *= XeHZToGXEtGt;
            ibsSpVEPY += PxHcfbVeRESGrqe;
        }
    }

    for (int BtKXLiHMxl = 946636402; BtKXLiHMxl > 0; BtKXLiHMxl--) {
        yBsPKs *= wivPrm;
        yBsPKs -= yBsPKs;
        wivPrm -= iQiQLl;
    }

    return XeHZToGXEtGt;
}

int nltWahiIulFY::SOsmcJRJQb(double iQizdpfmLyFk, string eLOHpQUBZpTAyvI, bool gSmCysUDDIikvoa, double kkkiTY, bool rykiGS)
{
    double YBhsoTGHXm = 1025489.3791760743;
    int aNeOwxLMrB = -2106779153;
    bool JOXLJeZrA = false;
    string VFQiSHE = string("kLzDHbiLXmZQRjZfCHmdqwueRZKnhcsfdirKwVMsLOzAoLJpnurEHOgRkwQJJIgESNyJtXFtYSESPbPRpOhqx");
    int vziMdxJOo = 174474917;
    string jBqkUL = string("cQuBfa");

    for (int yzuqYvUFJhIkwzL = 469691054; yzuqYvUFJhIkwzL > 0; yzuqYvUFJhIkwzL--) {
        jBqkUL = jBqkUL;
        kkkiTY /= YBhsoTGHXm;
    }

    for (int bJdEZmcgBcfwE = 942213098; bJdEZmcgBcfwE > 0; bJdEZmcgBcfwE--) {
        continue;
    }

    if (kkkiTY < 1025489.3791760743) {
        for (int TiLQlGhpNLBT = 2131087668; TiLQlGhpNLBT > 0; TiLQlGhpNLBT--) {
            VFQiSHE += eLOHpQUBZpTAyvI;
            eLOHpQUBZpTAyvI += jBqkUL;
            aNeOwxLMrB /= vziMdxJOo;
        }
    }

    return vziMdxJOo;
}

double nltWahiIulFY::zvyTXOJWeNVF()
{
    string kpXfkNnE = string("yJjPpzDfIutobnZywkakPRYzXaowmSvoVbMXLgCLurEHsrfMQlNYDYqhyZaxqpqaQIkzCkLlmGlFMsIeWQiFGvEbIXHZrbstNUvINXeqbNfzjciXTcgFRMhrByGoewbyhboD");
    bool kJKcuM = true;
    string PwxxvRxAZhrCI = string("cCoXEuktGatwQQHhQTcVSyOjSTsOSiRcRLrmqxvtNnzHpuKRhmaestjGWZOCbtOYbYKaVQxAVGQDxueIzuXqPpxgqygTHtGxaVRYYOrXOVJmSbQXOQKQkhQvlfgauV");
    string FsUgWd = string("wUJAfhhOKmJKVrKQmlHAnVnmvHDqCquQDaNLQslJBiyvMhbvSISemvzWsngyeClFsWkpPDaORgMdzCTJdekSCnlouVPGFAMGcKPDVnPBnTyzDmauEszgegtIQpFIobjEKaxBBRRoRHaoaCrbuKafgNJdgJeHwzQlvtOo");
    double swnqD = -1034952.1609112336;
    double zlQnsMtOCx = -474313.4621759813;

    if (FsUgWd != string("wUJAfhhOKmJKVrKQmlHAnVnmvHDqCquQDaNLQslJBiyvMhbvSISemvzWsngyeClFsWkpPDaORgMdzCTJdekSCnlouVPGFAMGcKPDVnPBnTyzDmauEszgegtIQpFIobjEKaxBBRRoRHaoaCrbuKafgNJdgJeHwzQlvtOo")) {
        for (int ZxLGpEfjLWHfVF = 178806643; ZxLGpEfjLWHfVF > 0; ZxLGpEfjLWHfVF--) {
            swnqD = zlQnsMtOCx;
        }
    }

    if (kpXfkNnE < string("yJjPpzDfIutobnZywkakPRYzXaowmSvoVbMXLgCLurEHsrfMQlNYDYqhyZaxqpqaQIkzCkLlmGlFMsIeWQiFGvEbIXHZrbstNUvINXeqbNfzjciXTcgFRMhrByGoewbyhboD")) {
        for (int AcYAfIPo = 880302543; AcYAfIPo > 0; AcYAfIPo--) {
            zlQnsMtOCx -= swnqD;
        }
    }

    for (int MgVOSNpZHsvixFj = 978700324; MgVOSNpZHsvixFj > 0; MgVOSNpZHsvixFj--) {
        kJKcuM = kJKcuM;
        FsUgWd += FsUgWd;
        swnqD = zlQnsMtOCx;
    }

    return zlQnsMtOCx;
}

double nltWahiIulFY::RiEYTpfWyqDRie()
{
    bool EfkBUoOGt = true;
    double dmKCHXFKDOjIFdz = -30753.537874375143;
    double iLbdbrUW = -610369.4403863278;
    double YiVcFX = 536779.6130597696;
    int GBNCe = -1663457238;
    double FAvQzYOjL = -598894.370362429;
    string jbEDaNZBqhenDVH = string("YWxUdLOQLgdTsAedqkYkouFoHdDUKAtCNPeYKsYRUzgJefpyLtTKIXOYZODaMuXKE");
    double wCUBK = -937806.8218339608;
    string youyJrwaGLno = string("BoTqQqQiqEUfPszzdAuzbpNRQyvClnThZCYrzaeboHsJZrVOtlSQtUkrIzfwrCfEOPUmWmSeKunpQBaUQwwGSfEspwkIuCylZYNrmwKdRjHhJZFWyBuqEXqFKLkUkDUdZWaFlstLsiSRZoVJ");
    bool SmxeArsmCIIyuI = true;

    for (int Ozsdeou = 575069482; Ozsdeou > 0; Ozsdeou--) {
        FAvQzYOjL /= iLbdbrUW;
    }

    if (FAvQzYOjL >= -598894.370362429) {
        for (int SPkagRoq = 1787072864; SPkagRoq > 0; SPkagRoq--) {
            youyJrwaGLno += youyJrwaGLno;
            wCUBK += wCUBK;
        }
    }

    if (wCUBK == -30753.537874375143) {
        for (int dmgvwsv = 1506929147; dmgvwsv > 0; dmgvwsv--) {
            wCUBK -= YiVcFX;
        }
    }

    for (int GKgbr = 395733113; GKgbr > 0; GKgbr--) {
        youyJrwaGLno = jbEDaNZBqhenDVH;
    }

    for (int sOMdHNIddQ = 1317844398; sOMdHNIddQ > 0; sOMdHNIddQ--) {
        wCUBK -= wCUBK;
    }

    return wCUBK;
}

double nltWahiIulFY::XdcBkjPBOHMw()
{
    string FQOQwKsSewGnuJ = string("QYZVmOyqXPtlrDCMPGYgIYKEnZsmPCkWOwgqsMKSywgzLTFrVmxILMfzXRiWpdXLTjkHbJMqWfpslFkKQZMIhSETkxMKEsCBStVvLHygIjtw");
    bool okImJsVbx = false;
    bool zctBtXIcYO = true;
    string ZAOcYNmfydd = string("BhaRvuBOkxmtVtcdOKSlCtRWqNxsVh");
    int hBjHjqEl = 1224593566;

    if (ZAOcYNmfydd >= string("BhaRvuBOkxmtVtcdOKSlCtRWqNxsVh")) {
        for (int JWojErccqVZFs = 1827268693; JWojErccqVZFs > 0; JWojErccqVZFs--) {
            zctBtXIcYO = zctBtXIcYO;
            hBjHjqEl -= hBjHjqEl;
            zctBtXIcYO = zctBtXIcYO;
        }
    }

    for (int kfxyO = 972961795; kfxyO > 0; kfxyO--) {
        continue;
    }

    for (int fAJhtDYOl = 955606362; fAJhtDYOl > 0; fAJhtDYOl--) {
        okImJsVbx = ! zctBtXIcYO;
        ZAOcYNmfydd = FQOQwKsSewGnuJ;
        hBjHjqEl /= hBjHjqEl;
        hBjHjqEl += hBjHjqEl;
    }

    return 227283.87799922217;
}

string nltWahiIulFY::MrlcYXtwTFAkK(int IwjEXySyMG)
{
    bool MDBSCbR = true;
    string oDBYOjPd = string("IJiilvaDslRuZlosnnedEooNUdrIHvKApJEvnG");

    for (int CMPiOPbFkXQn = 926452904; CMPiOPbFkXQn > 0; CMPiOPbFkXQn--) {
        IwjEXySyMG = IwjEXySyMG;
        IwjEXySyMG *= IwjEXySyMG;
        MDBSCbR = MDBSCbR;
    }

    return oDBYOjPd;
}

double nltWahiIulFY::DDiUSViewW()
{
    bool kdyKBDDnOzZgQ = true;
    string dYBpzrJxIF = string("thYjPuRKxXXiuGIZoMDwUxZXVZYdkXteIySBLhHMyVQDWRIPeICOAAEgukbxqsemMJQsKgNaxyEuoEvfyIpyLasRdFyGZZjDbtrhhcDMNXgShfiOVPdmpkuqwORzyfTQwFnMYeCtGQLGeYpmiVoErvXVtKQoyYZImgMJVEAsibwkdhWEQoJNdZIyjtgetWO");
    string VMhbbjEb = string("tBIfnffIvoCtGBlObpuWNcWLoiRXeHxSAcoowrvvlgJOxkLNrZfHoAmIngsxZnYGvdOpaVWKGloqhfWKwwbSXWmzxPeseRCbcxGiTXeOvYdHowNpbRTzEhotnLuiZhuCBmwheFDYazntICEElDSPqFNAkeLQTJoPZTRPsNQmlwGPupOzUSTAHcTDGtnXZlNbWAAVgvjfIBCPYQPKOZlYXBXaNa");
    bool WLcIfrqWDTYgx = false;
    string YLeoOEEEuUCZk = string("ncjaikdadnGYUclKlGXIivYcWIkrOsjVgoZGSItKxlOApxktEFrHHkVLpsuMqNkQxqVxczWlgpwKlkyogD");
    int lGhaiPxGFWNrMGp = 1935186421;
    string WLgSLBvRLphNa = string("nEMXmTzepWmSSSxwyMuJvQVeGqrgFBrTgtEpIWusViYOffdXDOsQPqSPNwjwbEWX");
    bool OoQeAj = false;

    for (int bbFnBSm = 856118320; bbFnBSm > 0; bbFnBSm--) {
        continue;
    }

    if (WLgSLBvRLphNa != string("ncjaikdadnGYUclKlGXIivYcWIkrOsjVgoZGSItKxlOApxktEFrHHkVLpsuMqNkQxqVxczWlgpwKlkyogD")) {
        for (int OmCFQQvRCjEQnSC = 1116920586; OmCFQQvRCjEQnSC > 0; OmCFQQvRCjEQnSC--) {
            VMhbbjEb += dYBpzrJxIF;
        }
    }

    for (int phNUPFLWHpBTE = 2140452383; phNUPFLWHpBTE > 0; phNUPFLWHpBTE--) {
        OoQeAj = OoQeAj;
        dYBpzrJxIF += dYBpzrJxIF;
    }

    return 115149.20305687531;
}

bool nltWahiIulFY::NwqeaIRheRK(double yTAcycuJoRbtwrn)
{
    double ZzWkg = -97246.49295734332;
    double zJdvwZjmnQUC = -666993.884968023;
    string OlJunOuCQhqpw = string("wQTAgEpgYHGliVmrkcEYcxuyemIizQxVTqJNPfJYWGQiGaBtDxSDQemupgXoCilPZCIqdnPOidiQaUATxsiABsXPyQSiulAiskrpRUIPHQULiiMVdQetQLnWZchRnhiMNADYAgwYDYFtbaDdIYuXiZiPSWlBabKrsuAwsqvFFcnueGBvlUEJXHHRWUOZviQMbPkkhBazEtfbiwpItQ");
    double cJaoaBKwq = -604388.7897477464;
    int vfNqhTXbz = 548873850;
    string yYrfAO = string("KWGfOcsRuDSIrsCycIiaXABNzpdRqoWbNnyalSDATzfsmOcgHVzMpinJHVRIXaEDElZhqubkqoHxYpNirXDIUtSNfDuQTEKEiGLLjBTJwaEaNdwJjWBQdTxPVShCDnGbYcSFxZjvYUueDMgQziMHtOOcmUuHWBz");
    int AABxMJGBUQU = 1807240380;
    double hekbkwF = -44592.49473650806;

    for (int EjEyRpE = 1263740656; EjEyRpE > 0; EjEyRpE--) {
        yTAcycuJoRbtwrn *= ZzWkg;
        hekbkwF -= ZzWkg;
        cJaoaBKwq = ZzWkg;
        cJaoaBKwq /= ZzWkg;
        cJaoaBKwq += yTAcycuJoRbtwrn;
        ZzWkg /= cJaoaBKwq;
    }

    return true;
}

string nltWahiIulFY::BghzXBN(int HjcEKfZwcgO, string NNFkrDUfzGWLxvye, double jHCgApBjdFSBWmuD, string DMKtgf)
{
    string hiPGUVSHqQyNT = string("XZwsfgVYdpXAlkbMVMBdTpVwJClhMEdQlrEIebOzfgcatbURqhxbTeVzYSIhLOgIgyfNmgVJxyFXrinUteRMgKSBqPnqfXtTTdAFWZQVbPTyGEveJMCzpkCBjjPoMPTVlLElbLtUUNmbYQMSXrbiMKLfwZwRWAQKKSAfVOJwvTeytRKYUBDXSBcCNQjvwPaiEOrXHrSwoMWpxubvftBsjRFoKCOYECvYsnEnTYMqpViAYSfZMvDTpNZoN");
    double gAHmMjxUTKazNFAQ = -857304.9316720116;
    int YZuqWQDrojEjH = -1330544892;
    bool HlzawdHIMxfFXjn = false;
    double DiKxzuxWa = 976917.6364065871;
    string JZjPcyVcSck = string("BNHCkQPahyGdFfEUCHTayVoDjvJ");
    bool vwARGKpVQ = true;

    if (HjcEKfZwcgO >= -1330544892) {
        for (int fcVYxILGVBefXtd = 555283011; fcVYxILGVBefXtd > 0; fcVYxILGVBefXtd--) {
            JZjPcyVcSck += DMKtgf;
            gAHmMjxUTKazNFAQ = DiKxzuxWa;
        }
    }

    if (hiPGUVSHqQyNT < string("xqFFbH")) {
        for (int dVbPylMNy = 170103018; dVbPylMNy > 0; dVbPylMNy--) {
            YZuqWQDrojEjH += HjcEKfZwcgO;
            NNFkrDUfzGWLxvye += JZjPcyVcSck;
        }
    }

    for (int jgyvSDZEc = 1026761669; jgyvSDZEc > 0; jgyvSDZEc--) {
        vwARGKpVQ = vwARGKpVQ;
        JZjPcyVcSck = DMKtgf;
        DMKtgf += DMKtgf;
        NNFkrDUfzGWLxvye = hiPGUVSHqQyNT;
        HjcEKfZwcgO = HjcEKfZwcgO;
    }

    return JZjPcyVcSck;
}

bool nltWahiIulFY::EYfMSCOEYK()
{
    bool rlzyOx = true;
    string nWTIyZmXzlOWpjHl = string("qerIdJcHaWzgFyTgOlLvtYrapOcTopgeJqibjwCABzPCHJRQrMKspYuNWmUlPQtYNCxXWmhSyVGJcFRDMxBxVkiSmTwYnSFyFNZFtagcMabMyvINGpqZtzmgqhymYTEikEJqkYWWrpJrXNwSQYPSalutcOudgnTQNttZHO");
    bool tSRcmNBByNfgR = false;
    string MdfVNLMlDTxzTv = string("nlnghzWeiiZLzhMDjcVOcKsDRhGRXfCoOAnJMzBkjOXLynEturQiwbciPzvhNkwjVBGXFruJYLRgmGQHHGpwjhTsIlfKrVEmzKtmMsBwsmSabVOvsGhHxIfdwlc");
    string DiRjWxtlEXiu = string("qwjmdRgulwxtDycpGynbYJITDdDLbpaufJQdtoXmpAZbLRtOUvZevlorZjhBjcpKrpcDRrTQyJBozEVCobxTAokTMxuqjSYyjdqugkhOdjwkUKpVTslsZIIpdSAyrScJgrRzztToUzegszCadOfSHSoqjjOkURBDjszSYxXfkzgUARLOaha");
    int BUPDYxuc = 817849437;

    for (int MeeWXCwBnrGrCm = 400642305; MeeWXCwBnrGrCm > 0; MeeWXCwBnrGrCm--) {
        MdfVNLMlDTxzTv += MdfVNLMlDTxzTv;
    }

    return tSRcmNBByNfgR;
}

double nltWahiIulFY::jNUDWhPwqdtLHs()
{
    double JkTPQ = -338350.4534714115;
    double iklXGhh = -574955.866969608;
    double bkskkHthRAnWyhD = -127775.92891307229;
    string EnevABet = string("ztbPjYnIowTzWcvoJiQqpVcNAlEdxbOPzjayupYiffGJzMRDdndPsUYVIDkASUplClHjzGklrUkcWkPqGBauEwQJiaJavLPTVRbPtaGDfUwFXwkaUoCClefdqAlqZKcH");
    string uRrETDPtFi = string("ZUrvIcxuzNYWSbIVkwOn");

    for (int DHPAYrh = 946992852; DHPAYrh > 0; DHPAYrh--) {
        continue;
    }

    for (int qdfjpBLE = 372272260; qdfjpBLE > 0; qdfjpBLE--) {
        iklXGhh -= JkTPQ;
        JkTPQ -= bkskkHthRAnWyhD;
    }

    for (int vGAzDXkmKCG = 882975414; vGAzDXkmKCG > 0; vGAzDXkmKCG--) {
        continue;
    }

    if (bkskkHthRAnWyhD < -338350.4534714115) {
        for (int sucqp = 127416835; sucqp > 0; sucqp--) {
            uRrETDPtFi += EnevABet;
            iklXGhh *= bkskkHthRAnWyhD;
        }
    }

    for (int hTMrt = 516742234; hTMrt > 0; hTMrt--) {
        bkskkHthRAnWyhD -= JkTPQ;
    }

    return bkskkHthRAnWyhD;
}

void nltWahiIulFY::OobWgLIlgtsH(int BLdOaB, string UTcbicVjb, int EzWltzragn)
{
    int EsSFgLWFRxrtWRq = -1231506240;
    int UJkXAJwTC = -1989338267;
    bool JhnDJqTH = false;
    bool yYpytwkDxp = false;
    string HCgcXELPYKMhGsr = string("KOxtjVmoXWCKyunfpGMVNjeytDZLWqBCVtqzxHYvABKCJpXXfRCifwvmLaxEuOLjCvcToVOLIVaOZccnJvpvZAQbhqnATqdAOmXKJxbCnHJizJAKXxFlOexLBaABlfJofeqPDOuTCL");
    int tUpYLzVuhDrM = -131920243;
    string CMFirvVpjrF = string("VjIFpPdnPdNcMlqhmxksMmWcFzDhzMHmrCOgIBtFrkqWrgKrFdowxCIEpDQGfIdoeCESfmKJBhWtzVzyTRfjTWRgATgLKCiUbwjMOeARutNQlhCNPusIqsAWERkjXiLkCfywmJHZyiOqIvowCrsqaYAzvFPYIGnSvKNKHurzAuXYwHTdSXhDPtmWGfdIvuSLWKAYSmjMXpuhRCKWXsWbeAqOOMHaxTPtHGFXGWJMJAAvqwwEJDOKU");

    for (int QikqBLIsX = 2052738020; QikqBLIsX > 0; QikqBLIsX--) {
        EsSFgLWFRxrtWRq /= BLdOaB;
    }

    if (JhnDJqTH != false) {
        for (int LSmKIXuy = 1899694132; LSmKIXuy > 0; LSmKIXuy--) {
            tUpYLzVuhDrM = EsSFgLWFRxrtWRq;
        }
    }

    for (int tEIRd = 544195738; tEIRd > 0; tEIRd--) {
        tUpYLzVuhDrM /= EsSFgLWFRxrtWRq;
        HCgcXELPYKMhGsr = HCgcXELPYKMhGsr;
    }

    for (int ngRCeWSP = 1046216033; ngRCeWSP > 0; ngRCeWSP--) {
        CMFirvVpjrF = HCgcXELPYKMhGsr;
        EsSFgLWFRxrtWRq += EzWltzragn;
        CMFirvVpjrF = CMFirvVpjrF;
        HCgcXELPYKMhGsr += CMFirvVpjrF;
    }

    for (int OsOnuuCEAscTNIFp = 1262183943; OsOnuuCEAscTNIFp > 0; OsOnuuCEAscTNIFp--) {
        EsSFgLWFRxrtWRq /= UJkXAJwTC;
    }
}

string nltWahiIulFY::sZFlJuJwS(int MJptikktTcDK)
{
    string zMPwaQNMXKWHb = string("WtYKiMpfesEIkCEyemWLWIXybaJGDSpQPghUKdUWcsjMGWCezKwZaiJEYdXCGtSEmivmpFYATzGVDuHlBWwiQDPZRCklSvJxXQFanQuNYQuIRgEvSqVVFgxktuTjfWeyclQfXJTMDajpQuOxWYvtSPRQGCkjeWKlKEuBKpXhtkCxEMVlFAZkFwLGJPIoJtUuzOVYrMalBFyVLHDqmdKCIdWgMDjNXsJSRudAPvMjnooTOqtPsKXsKz");
    bool DbXMSSqWv = true;
    int QsGKs = -1411072783;
    string FFYHjvvqhrnVLHKH = string("jZGnUTArOlURErizjnUEHGkziHVxwlOtrSdvVEGkXkXZDDJtlbmatShcKcnjgtBUMeTuvdQrYFnomvIwbKzQkQBOkRzsdHFnyrAHaHXdtBdLbqWog");

    for (int RggXEVdYDR = 1754406519; RggXEVdYDR > 0; RggXEVdYDR--) {
        QsGKs += MJptikktTcDK;
        FFYHjvvqhrnVLHKH = FFYHjvvqhrnVLHKH;
        MJptikktTcDK -= MJptikktTcDK;
    }

    if (FFYHjvvqhrnVLHKH == string("jZGnUTArOlURErizjnUEHGkziHVxwlOtrSdvVEGkXkXZDDJtlbmatShcKcnjgtBUMeTuvdQrYFnomvIwbKzQkQBOkRzsdHFnyrAHaHXdtBdLbqWog")) {
        for (int lTPLJEcRHFsJUUQ = 424568663; lTPLJEcRHFsJUUQ > 0; lTPLJEcRHFsJUUQ--) {
            QsGKs = MJptikktTcDK;
            zMPwaQNMXKWHb = zMPwaQNMXKWHb;
            FFYHjvvqhrnVLHKH += zMPwaQNMXKWHb;
            QsGKs += MJptikktTcDK;
        }
    }

    if (DbXMSSqWv == true) {
        for (int zheqYD = 1881936135; zheqYD > 0; zheqYD--) {
            DbXMSSqWv = DbXMSSqWv;
        }
    }

    if (zMPwaQNMXKWHb == string("WtYKiMpfesEIkCEyemWLWIXybaJGDSpQPghUKdUWcsjMGWCezKwZaiJEYdXCGtSEmivmpFYATzGVDuHlBWwiQDPZRCklSvJxXQFanQuNYQuIRgEvSqVVFgxktuTjfWeyclQfXJTMDajpQuOxWYvtSPRQGCkjeWKlKEuBKpXhtkCxEMVlFAZkFwLGJPIoJtUuzOVYrMalBFyVLHDqmdKCIdWgMDjNXsJSRudAPvMjnooTOqtPsKXsKz")) {
        for (int KcugIjsBI = 2099861691; KcugIjsBI > 0; KcugIjsBI--) {
            continue;
        }
    }

    return FFYHjvvqhrnVLHKH;
}

int nltWahiIulFY::nLkJeatfpsv(bool EIcubmHHLc, int KejuNsDpe)
{
    bool zlgOflzyS = true;
    string mSOBTxAHNFrpcEt = string("HTcXJgOoDNXBn");
    int PCQDhUpiQidJJ = -1971088620;

    for (int ffyUgZP = 2030829420; ffyUgZP > 0; ffyUgZP--) {
        PCQDhUpiQidJJ = KejuNsDpe;
    }

    for (int wllsbaByBnCDSOM = 1098851724; wllsbaByBnCDSOM > 0; wllsbaByBnCDSOM--) {
        PCQDhUpiQidJJ -= KejuNsDpe;
    }

    for (int YHmaiAXIinI = 1114808515; YHmaiAXIinI > 0; YHmaiAXIinI--) {
        EIcubmHHLc = ! zlgOflzyS;
    }

    for (int ilnYdIPhYfW = 1551598700; ilnYdIPhYfW > 0; ilnYdIPhYfW--) {
        zlgOflzyS = ! EIcubmHHLc;
        KejuNsDpe -= PCQDhUpiQidJJ;
    }

    for (int QRxUidIKFGP = 230295048; QRxUidIKFGP > 0; QRxUidIKFGP--) {
        PCQDhUpiQidJJ -= PCQDhUpiQidJJ;
        PCQDhUpiQidJJ += PCQDhUpiQidJJ;
        EIcubmHHLc = ! zlgOflzyS;
        PCQDhUpiQidJJ *= KejuNsDpe;
    }

    return PCQDhUpiQidJJ;
}

bool nltWahiIulFY::YlPAoYRPVOzy(int VWcsa, double SbGLzlOgj, int OiluBKm)
{
    string jSiQOyxOmJyFK = string("PeyDZMSERwdkQTZhneAUTkYXGxbCgmGeUvDlDnEPtR");
    double hSDxFqGWyloMuQQ = -959781.0591797426;
    double ytTKAqB = -39662.621306017965;
    double wWGfbpLVhNou = -347895.5804566173;

    if (wWGfbpLVhNou >= -269035.0096920847) {
        for (int xNdFkYHLa = 1908123237; xNdFkYHLa > 0; xNdFkYHLa--) {
            VWcsa += OiluBKm;
            OiluBKm -= VWcsa;
        }
    }

    if (SbGLzlOgj != -347895.5804566173) {
        for (int quYxUgCQMfqdwZU = 947036971; quYxUgCQMfqdwZU > 0; quYxUgCQMfqdwZU--) {
            VWcsa -= VWcsa;
            SbGLzlOgj = ytTKAqB;
        }
    }

    for (int zSMGrlKfuq = 1931116451; zSMGrlKfuq > 0; zSMGrlKfuq--) {
        ytTKAqB += wWGfbpLVhNou;
    }

    for (int DlRCdhakHv = 55049509; DlRCdhakHv > 0; DlRCdhakHv--) {
        hSDxFqGWyloMuQQ = ytTKAqB;
        SbGLzlOgj /= SbGLzlOgj;
    }

    return false;
}

string nltWahiIulFY::vhkrPFwZvp(int izMZWJAHSgzwzUOW, double wOmkuNYVhdkuO, string zJkKEQcmFIShaOc)
{
    int YAtddVh = 278162298;
    string xuSaHc = string("oBZEIkLWxvTsRnrCpWXYllXyqMwKhCFyMvmcDpxPOnqWJraArbbDFddJLLbXQXdeflynaOYIEXZdQgAbFaHKIWCWpFbHazHbaUBuxTXCNYBtjyegwciWXVoEzVPUXwbboJtVGDsXZgBpSGEUVdeqyNmWCZlNqJcm");
    bool ipCXdmUUOKVedJ = true;
    int AeeQsBzZRGGzLh = 436114618;
    string uACwkxS = string("OHPGJyrdsauWKMhZ");
    string oyVmblRAo = string("cSvBxXIEbaitFgBIeikzdabJPMNxEesPBLlKnIzEcpFXgEZQxVfaxlFqaBsUHKOatkfRvxsanXiqcKuZjNPVvuunkCiVplDbgxtGvCrPfuWZfvFsnqlDZZlFwSztTnEpXmxN");
    double AiIZJuOuqQnK = 770020.5007224946;
    string kphVLferzpHUXSfA = string("FvdAzWVEuqbcrwYyRTPqsvtxlZTLmOPvZdBUsDdxFiiMPoxpwbBHbHiLpoRlHuCRzheRbOyHoCmgzOKbYZNEcvQrOUWThNqUhXZzczNjnjzkAkgPk");
    int FMChryNToK = 716174396;

    for (int tlifAPaclYvUXGw = 762513311; tlifAPaclYvUXGw > 0; tlifAPaclYvUXGw--) {
        continue;
    }

    for (int YOhxoPpuUDKxgCiM = 37511172; YOhxoPpuUDKxgCiM > 0; YOhxoPpuUDKxgCiM--) {
        uACwkxS += kphVLferzpHUXSfA;
        ipCXdmUUOKVedJ = ! ipCXdmUUOKVedJ;
        oyVmblRAo = zJkKEQcmFIShaOc;
        xuSaHc = zJkKEQcmFIShaOc;
        AeeQsBzZRGGzLh = AeeQsBzZRGGzLh;
    }

    for (int xCCHpP = 1377640545; xCCHpP > 0; xCCHpP--) {
        kphVLferzpHUXSfA = zJkKEQcmFIShaOc;
        uACwkxS = oyVmblRAo;
        kphVLferzpHUXSfA += uACwkxS;
        AeeQsBzZRGGzLh /= AeeQsBzZRGGzLh;
    }

    return kphVLferzpHUXSfA;
}

nltWahiIulFY::nltWahiIulFY()
{
    this->KnepkqtbpquI(376032.6279374789, true, false, -950075870);
    this->JHXyiCMYhP(525391848);
    this->wfGbGBg(-226733.18744237645, -25210.08945862706, 346212.7421677021, string("mbeVDYIyzHzNjcVvsJblJSkCNWEEpNpuGkRXVJBZXbjOJhqAVITArtgYFDuuwhFTMHdKCmBFaVRRUDcEvdObbijJQvACmBdpqKnYSGEXqMSLznnXHIPhaVQxnKgwPncvvEgpGncfpnfrloXjznCcaEZTXGqDpHMXnoivlklqAadyMeSrmpoIpZthQBxBilbdNQKutQLoajoDVaRHoVplIrlSNvkBQaYBpkRZwjed"));
    this->SOsmcJRJQb(-364888.4595084846, string("kTtyNkIAtGhbcJYNTMQWkqwScKihsWDXPbKFfBkTipHhPNNyywvoBsxKKRFlNwHlLUGJZLsWUhgEoAWDUuuGBQbRndvEpKGRQyNfSdkPujLEVIBeWpzwSsrRdGuQdaAJRRxKpblnJPzUVqkfLuBukCqqPNAZgnBMjRiUULiBqknGzlrmJXtVYOIACLfABVEBYFZMnticEBlPvsyIRothkxSZpf"), true, -965552.1816873556, true);
    this->zvyTXOJWeNVF();
    this->RiEYTpfWyqDRie();
    this->XdcBkjPBOHMw();
    this->MrlcYXtwTFAkK(-1138220439);
    this->DDiUSViewW();
    this->NwqeaIRheRK(-466159.0814714474);
    this->BghzXBN(-759629703, string("XoPGJjnITdLcDRWQNOnSrvZVrdCujYMKcSCSgjOUvIFCOxGGplgVnLIsXbadzuBUMAWtrTocbsQNWgEWMjxhSxDozslgniOtYdKMCsrZsYmnwaokKyBFRrKJtXJljMyRnRDdbVXMmOJNrmWtiBDbfyyGJWwwNvtgbURkkpHKNmTeTMzpsgcLgoadWkRBkeoEmvsJYJWiAuMXJOxdLmgtOIst"), 401802.4017945229, string("xqFFbH"));
    this->EYfMSCOEYK();
    this->jNUDWhPwqdtLHs();
    this->OobWgLIlgtsH(-2068120360, string("LHRDWvXqjByYlETKzmMBBoj"), -1462753320);
    this->sZFlJuJwS(458383859);
    this->nLkJeatfpsv(true, 1110245514);
    this->YlPAoYRPVOzy(1956885930, -269035.0096920847, -690540608);
    this->vhkrPFwZvp(-1807701729, -608799.1180078997, string("oldFXpafVIvxrARQYreDNzALaoaLVLTSSaXxXbtdZkOAtWxdAOhGIyuqtdxYNSbuXmhOvfesEozpgBnfvYPRvFwCqTuHWoHHmmIdCZzXUgdlkpDAddhkIqqOVQbZbZgzkSqIcLqqmHNOPPXiAGppHrHuvDUpate"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class anvEetg
{
public:
    string NssQjeJ;
    double SeuPkTfaEWvx;

    anvEetg();
    bool nGAIpbL(int qWiXBUmWwstvcOa, int WPpWm);
    int eqBrKoIhX(double FQQTsqxSoyU, double CifbQrdqTAtkvbV, bool QmcDw, double mGIRN);
    string UpYtAzN(double pZyQHIip, bool BnGhOKFN, double CuRNgfSvdTDvFanE, double BPfQMtNBdforRD);
    int BMwvwaINLZfxc(string rtYDczRwWCy, bool WdoebPVrcdqZuA, double ruUNpIRlueMRCKyA, string niehtUxFTChoPEn);
    bool ASlZaNPvENMOvPfx(bool vlLlcWrHWx);
protected:
    double WNSZdoIGL;
    double cLsCmYpssw;
    bool ShJtcqqzeAcMlh;
    bool mgMZKtxeOMu;
    double DftUWIVZDCCPj;
    string aKjywsiGofWZN;

    int rPRBPcIqLf();
    void hDWqmNHZOtZqAtP(string CvOEGlNECyDVB, double oUoZmjnNKc, double SWGLfhmgTDxWERX);
    void grySABPkdCQUta(double nVXhIVFmmpD, double OLoqnnYrvyjmD, double GMXJqSMlsJYjtC);
    void edJdxlgMMj(double kqQcvegbEQBmwydW, string nbEWgtn, bool ZoIfy, string zzBLRciBAQzUCMtj);
private:
    double ItgBwjsGLf;
    int OvtongUVROUGsN;
    bool CUWCqrgcYRnBdi;
    int yDTsHVDrxYjQCr;
    int pIoSIHOUwZtm;
    double naDHrurCB;

    bool wZyoMMGJ(int iluzROYT, int tjyWe);
    double lPXNoxt(string HmrChZ);
    void EUhwoWxVKxxSFdoG();
};

bool anvEetg::nGAIpbL(int qWiXBUmWwstvcOa, int WPpWm)
{
    int eyRZHUPgPzNEJXmc = 1931024957;
    bool ibJSLWWDJAAxYWJ = false;
    bool UzUwnLZYMAmEkHw = true;
    string LPkiwbZmuCqvjgwc = string("QrAmKIQlfdcOJqPIvhCnwyPeXbctaWtxWjueYBzxUuZBqHqoskNBDSgJipaYKvWRvwhMgbLcjPSBmswusydyrxHUOjBvMheGNtdzUqzrhaaUxKwVIbvwuMaCpnbBLhAEASuNdkS");
    int DUshWqqar = -1504548134;
    double ykpABxCTlFf = 726107.5383683547;
    double mjxNSAFIgZL = 505004.99152918893;

    if (ykpABxCTlFf == 726107.5383683547) {
        for (int KsIDQuBCdELG = 1420755660; KsIDQuBCdELG > 0; KsIDQuBCdELG--) {
            continue;
        }
    }

    return UzUwnLZYMAmEkHw;
}

int anvEetg::eqBrKoIhX(double FQQTsqxSoyU, double CifbQrdqTAtkvbV, bool QmcDw, double mGIRN)
{
    bool pEIRPordMjqH = true;
    double klFGXjltVculhJS = 313610.64395634155;
    int vbmIUjxZQLt = -2037275513;
    bool GIGxI = true;
    int rRrRMyiWagAYSgWY = -165525147;
    double iRBYjUYNDDe = 252860.7323888017;
    double bRqCuBtJwM = 816394.029180726;
    double WTZhFzwAJxnoz = -811462.2411097499;
    int xKzaXEOuZVQpWDKk = -146724411;

    for (int AydwoobUqP = 1008915704; AydwoobUqP > 0; AydwoobUqP--) {
        CifbQrdqTAtkvbV *= bRqCuBtJwM;
        FQQTsqxSoyU = mGIRN;
        klFGXjltVculhJS *= bRqCuBtJwM;
    }

    for (int FYrMtfi = 2105796950; FYrMtfi > 0; FYrMtfi--) {
        bRqCuBtJwM = iRBYjUYNDDe;
    }

    return xKzaXEOuZVQpWDKk;
}

string anvEetg::UpYtAzN(double pZyQHIip, bool BnGhOKFN, double CuRNgfSvdTDvFanE, double BPfQMtNBdforRD)
{
    string APmEOXWih = string("YCzjgGzPAVGJHgnpkphoBWpyvxNLQvEUQvkDGJqlkZdAHeQbtYWeMrJhVEXcamXfioiNGQkGA");
    string orNSiOiM = string("EZDEbbrxGMfwQcuocaHWaBHjZfhYgrhOqLqUzyUhJtyhFGfqhRRiYn");
    bool OMhDtyWnR = false;
    double hTFcQbKKcOmb = 304337.5239190601;

    for (int fxkLDSwy = 140173632; fxkLDSwy > 0; fxkLDSwy--) {
        orNSiOiM += orNSiOiM;
        OMhDtyWnR = OMhDtyWnR;
    }

    for (int ixRLxcwm = 1280784626; ixRLxcwm > 0; ixRLxcwm--) {
        orNSiOiM = orNSiOiM;
    }

    if (BnGhOKFN == false) {
        for (int lGrlyMwWLF = 538722489; lGrlyMwWLF > 0; lGrlyMwWLF--) {
            BnGhOKFN = BnGhOKFN;
            APmEOXWih += APmEOXWih;
            pZyQHIip /= pZyQHIip;
            pZyQHIip = hTFcQbKKcOmb;
        }
    }

    if (CuRNgfSvdTDvFanE < -728668.5910314668) {
        for (int dudqXLTt = 249321699; dudqXLTt > 0; dudqXLTt--) {
            CuRNgfSvdTDvFanE += hTFcQbKKcOmb;
        }
    }

    for (int ASypgkSNXCngfjV = 65053636; ASypgkSNXCngfjV > 0; ASypgkSNXCngfjV--) {
        continue;
    }

    return orNSiOiM;
}

int anvEetg::BMwvwaINLZfxc(string rtYDczRwWCy, bool WdoebPVrcdqZuA, double ruUNpIRlueMRCKyA, string niehtUxFTChoPEn)
{
    double ekUoJXXOVCnn = -152989.5864527909;
    double NcbSxGDjS = -474790.9154622547;
    double LcWEoWgu = 113090.05881133005;
    string NCFHYfPol = string("YanlgLLctUnCYzgTekXIyUDRsMCNJzzVZrdUmXCtBHD");
    int RRZtc = 665534783;
    double UMaTpXdayqnOo = -531493.0519943215;
    double zVBppWptZcI = -373520.3121701442;
    string fmVMHkKJ = string("dsnxlFJ");

    for (int IkAevJyIxlimyt = 588457341; IkAevJyIxlimyt > 0; IkAevJyIxlimyt--) {
        LcWEoWgu = LcWEoWgu;
        LcWEoWgu = ruUNpIRlueMRCKyA;
    }

    for (int dZbSbExc = 698943068; dZbSbExc > 0; dZbSbExc--) {
        NcbSxGDjS -= zVBppWptZcI;
        rtYDczRwWCy += niehtUxFTChoPEn;
    }

    for (int bBUUyyZdMcjXrI = 20350737; bBUUyyZdMcjXrI > 0; bBUUyyZdMcjXrI--) {
        UMaTpXdayqnOo /= NcbSxGDjS;
    }

    return RRZtc;
}

bool anvEetg::ASlZaNPvENMOvPfx(bool vlLlcWrHWx)
{
    bool NwvKcs = false;
    string ZBLnTBBJWhGxxk = string("WcJmRzxBGETvkdJvJXQoGEtZlDdVnTMUSaMQADyvRZjtzQzTWVlrSpZzYjsLQbPVbQDopCHBXriPuiUDrRKJGyafuSBaHFBtFPfwmrhCcsuVAgpaYZHbovKhJkwAY");
    double ewHZXNJXrx = -952673.207833819;
    bool QjfaWBhKhSnSLvSv = true;
    bool xYSmMiYWDRGznaD = true;
    double tKaTJchDadrhc = -948275.5500416396;
    bool dqfgJmq = false;
    string SEYfqwrWINY = string("izgRHcPQPworeqaYjCMSzYjpeqAypbGxTuzyXlGBZuEOxlpDkQWOmQGYBqudDuNVaWOCZCLSRmAEikEmAEYaOidOAOkjMnMSdmyWMPetLRXcBvnfvIPqrQUzexJYokZZbjCTmEaMXBGbwbCoNeliUIIybxBxEIwkCeTNSNavaCRbJz");

    for (int ZhEFGLxzdDwXyu = 1081814605; ZhEFGLxzdDwXyu > 0; ZhEFGLxzdDwXyu--) {
        NwvKcs = xYSmMiYWDRGznaD;
    }

    for (int hqQBJNqZ = 2030963868; hqQBJNqZ > 0; hqQBJNqZ--) {
        continue;
    }

    for (int OJzjrqxnxhWLXPz = 1141550137; OJzjrqxnxhWLXPz > 0; OJzjrqxnxhWLXPz--) {
        ZBLnTBBJWhGxxk += ZBLnTBBJWhGxxk;
    }

    for (int bqEaoYuEa = 1202915086; bqEaoYuEa > 0; bqEaoYuEa--) {
        vlLlcWrHWx = ! dqfgJmq;
        dqfgJmq = QjfaWBhKhSnSLvSv;
        vlLlcWrHWx = xYSmMiYWDRGznaD;
    }

    for (int horrcUnwqSAb = 588659998; horrcUnwqSAb > 0; horrcUnwqSAb--) {
        NwvKcs = ! vlLlcWrHWx;
        ZBLnTBBJWhGxxk = SEYfqwrWINY;
        QjfaWBhKhSnSLvSv = NwvKcs;
        tKaTJchDadrhc -= ewHZXNJXrx;
        xYSmMiYWDRGznaD = xYSmMiYWDRGznaD;
    }

    return dqfgJmq;
}

int anvEetg::rPRBPcIqLf()
{
    double AmjxAaYWqXWX = 927011.9470289769;

    if (AmjxAaYWqXWX >= 927011.9470289769) {
        for (int ljBTHXwbUO = 2082244380; ljBTHXwbUO > 0; ljBTHXwbUO--) {
            AmjxAaYWqXWX += AmjxAaYWqXWX;
            AmjxAaYWqXWX *= AmjxAaYWqXWX;
            AmjxAaYWqXWX *= AmjxAaYWqXWX;
            AmjxAaYWqXWX = AmjxAaYWqXWX;
            AmjxAaYWqXWX *= AmjxAaYWqXWX;
            AmjxAaYWqXWX = AmjxAaYWqXWX;
            AmjxAaYWqXWX -= AmjxAaYWqXWX;
        }
    }

    if (AmjxAaYWqXWX > 927011.9470289769) {
        for (int SJcKrQvdUQQR = 2046576771; SJcKrQvdUQQR > 0; SJcKrQvdUQQR--) {
            AmjxAaYWqXWX *= AmjxAaYWqXWX;
            AmjxAaYWqXWX = AmjxAaYWqXWX;
            AmjxAaYWqXWX += AmjxAaYWqXWX;
            AmjxAaYWqXWX = AmjxAaYWqXWX;
            AmjxAaYWqXWX /= AmjxAaYWqXWX;
        }
    }

    if (AmjxAaYWqXWX > 927011.9470289769) {
        for (int qEWYoHCJuj = 2112085662; qEWYoHCJuj > 0; qEWYoHCJuj--) {
            AmjxAaYWqXWX *= AmjxAaYWqXWX;
            AmjxAaYWqXWX -= AmjxAaYWqXWX;
            AmjxAaYWqXWX -= AmjxAaYWqXWX;
            AmjxAaYWqXWX /= AmjxAaYWqXWX;
            AmjxAaYWqXWX += AmjxAaYWqXWX;
            AmjxAaYWqXWX = AmjxAaYWqXWX;
        }
    }

    if (AmjxAaYWqXWX >= 927011.9470289769) {
        for (int hdwQUKkZubZoI = 2088745328; hdwQUKkZubZoI > 0; hdwQUKkZubZoI--) {
            AmjxAaYWqXWX -= AmjxAaYWqXWX;
            AmjxAaYWqXWX -= AmjxAaYWqXWX;
            AmjxAaYWqXWX *= AmjxAaYWqXWX;
            AmjxAaYWqXWX += AmjxAaYWqXWX;
            AmjxAaYWqXWX -= AmjxAaYWqXWX;
            AmjxAaYWqXWX /= AmjxAaYWqXWX;
            AmjxAaYWqXWX += AmjxAaYWqXWX;
            AmjxAaYWqXWX *= AmjxAaYWqXWX;
            AmjxAaYWqXWX /= AmjxAaYWqXWX;
            AmjxAaYWqXWX /= AmjxAaYWqXWX;
        }
    }

    return 2000041209;
}

void anvEetg::hDWqmNHZOtZqAtP(string CvOEGlNECyDVB, double oUoZmjnNKc, double SWGLfhmgTDxWERX)
{
    int glwpLsQMscR = 1916886800;
    bool McUeZN = false;
    int xvneW = 2018087489;

    for (int GDSdbHKcpkJyaif = 1622113345; GDSdbHKcpkJyaif > 0; GDSdbHKcpkJyaif--) {
        continue;
    }

    for (int IGRYqAxeCeN = 1436352995; IGRYqAxeCeN > 0; IGRYqAxeCeN--) {
        CvOEGlNECyDVB = CvOEGlNECyDVB;
    }
}

void anvEetg::grySABPkdCQUta(double nVXhIVFmmpD, double OLoqnnYrvyjmD, double GMXJqSMlsJYjtC)
{
    int yYmMyrFqIkdj = -133941842;
    int DaLVNKV = 1103472884;
    bool jBcdRoEVBamB = false;
    bool YIxCtfEZ = false;
    string cYzYsoFyerOpxp = string("RkhBNTEpWffJkhIcaAluIMROPxpXaAofzAQpBbfDrhEfhyHhqzZvDbElXVWhHGVkUsatYzrZoPtyReWTocxUPVRZXihHyDgzxAWPGVCYaUqPhsQCYB");
    double xYHhOShVEmiFqhc = -318839.8642546032;
    double YcPkRSrxYr = -405529.8615658487;
    string XgHjYVYmrfqRJn = string("HgwmkQfnjWBUKsQZmzQqClJEhvJIhBHJPezRcrghxVYaVMJQu");

    for (int lzDoaamrLGJv = 1336795926; lzDoaamrLGJv > 0; lzDoaamrLGJv--) {
        nVXhIVFmmpD *= xYHhOShVEmiFqhc;
    }

    if (yYmMyrFqIkdj > -133941842) {
        for (int WLGHgsVTVelHb = 1316661525; WLGHgsVTVelHb > 0; WLGHgsVTVelHb--) {
            cYzYsoFyerOpxp += cYzYsoFyerOpxp;
        }
    }

    if (OLoqnnYrvyjmD > -945646.3750590535) {
        for (int SEaeayeLcT = 1703947641; SEaeayeLcT > 0; SEaeayeLcT--) {
            DaLVNKV += yYmMyrFqIkdj;
            OLoqnnYrvyjmD += xYHhOShVEmiFqhc;
        }
    }

    for (int kmRKCin = 1445003035; kmRKCin > 0; kmRKCin--) {
        XgHjYVYmrfqRJn += XgHjYVYmrfqRJn;
    }

    if (GMXJqSMlsJYjtC != -318839.8642546032) {
        for (int KQilRLpxDEZS = 516089733; KQilRLpxDEZS > 0; KQilRLpxDEZS--) {
            nVXhIVFmmpD += OLoqnnYrvyjmD;
        }
    }
}

void anvEetg::edJdxlgMMj(double kqQcvegbEQBmwydW, string nbEWgtn, bool ZoIfy, string zzBLRciBAQzUCMtj)
{
    double BRUTSGziOBQvnv = 834835.112630326;
    string ZaaKzkKRFDwWwmzg = string("HPUxUDoBCbieEhzNDdpbattQruUdDLbFrFrlOZoLjlZXmhqhQLFzdDpKHfKxvvwTkKkvSSjNnursZhUqHtuWXcGpfrJHcqCUwJbISOsrXiYABaeSqhWQvoTNbCWbOqAVmvrWzMoSBnETPZgQToLMldpvFXVDaPpbVQaKrDUCNlhAceRrHVgkMmJqalsSErTIE");
    string prnLN = string("xoKdfkyGUygkuKkbqYiQUMulNvhLWyqSfLcamjdXVjuZcivfoOHjqBWmFSqFTVGeUmhhaRzMdhrHwJtPTavbKQeexqBwqNslnCOZrLciHsHaQduikYHLcAgSeOHRFNAtuNmOkLeqqOKmVBtJLVOHtKAgj");
    string FwtHwDyybVEH = string("vZgdYSJNvTihhCotXgZTjiIuQbLgjApsjgFYYoVgvEujtBbfDkgGXWpNXrVIqdPEBzRjwalmOuFQGasojoGIijAhacCmLAUZGJZzNwEsnvYzTyHFxEPURzONSMoYkrsKYvkmYBOHHxRsxKgPcitsvIpZ");
    bool RdEiXyARpzsZUUpz = true;
    bool LdwipktSgNmrdfFy = true;
    string QlMPMDZGgA = string("QmDroKxkbJISdOQyNaETebxhGUOEEUDHJVEekYPztTbjlLVDDihnMaMfOYVdRvAxuPAJGxzFTgfuFVvsTBXdlZnbmDcwZjnQfrIVXLSgefIKdWKsONmasQkHWyhLjuIDKmburfiwXXipHx");
    bool wilxiZcOWedg = false;
    int NZdVyGkVhlT = -1953040087;
}

bool anvEetg::wZyoMMGJ(int iluzROYT, int tjyWe)
{
    double Lnyhzt = 184508.39030354383;
    string fKppMiEhAhR = string("HPMeUhhYwvxgMssedhBoYsPrVlaEoDCnkWGSbszJjveGMgcFwNfuZxMWTDlCiyhhlGlxoRqlaFttRnDPATbWgSUwYaMlGfVcZBsQzMNdXfzHFmbuxubTKaRrJgmlShELiWLccathtgHcCXIxwIzMpLgZRTvAqLmpAgxpwVVVPqMIUMcParzz");
    double UIUYbJX = -56075.732975636965;

    for (int PMFQcySOk = 1830049965; PMFQcySOk > 0; PMFQcySOk--) {
        fKppMiEhAhR = fKppMiEhAhR;
        fKppMiEhAhR += fKppMiEhAhR;
    }

    for (int TfjoU = 712054826; TfjoU > 0; TfjoU--) {
        tjyWe *= iluzROYT;
        fKppMiEhAhR = fKppMiEhAhR;
        Lnyhzt -= Lnyhzt;
    }

    for (int HTuSwVkswUcNFF = 79998237; HTuSwVkswUcNFF > 0; HTuSwVkswUcNFF--) {
        tjyWe = iluzROYT;
    }

    return false;
}

double anvEetg::lPXNoxt(string HmrChZ)
{
    double makCJkeXpDCn = 914783.9059286794;
    double cDSYlggo = 79450.95492037035;
    int zgqTEhmwa = 1304461849;

    for (int YNNjfNiQfEcitRn = 385147316; YNNjfNiQfEcitRn > 0; YNNjfNiQfEcitRn--) {
        zgqTEhmwa *= zgqTEhmwa;
    }

    for (int ROXtAzXTxjwLC = 1890899435; ROXtAzXTxjwLC > 0; ROXtAzXTxjwLC--) {
        makCJkeXpDCn += makCJkeXpDCn;
    }

    return cDSYlggo;
}

void anvEetg::EUhwoWxVKxxSFdoG()
{
    bool QIsEQYFtPGcuQN = true;
    int jZBbrGEYh = 198703359;
    double MUJWhJEKeZcwknx = -32183.403799449043;
    string aQzoDLMtSbhDEyqb = string("WKDWXwxaJqfWfTpxDtIGpdOAoFQdJjIiqjxJHXkrzhczgFkrdEnpXFpuxyKIpTHlPYiaaFfzIYucJOFhiHAyCcLircHGDfjeynHFxsuO");
    int MdoEXBFuncjOfYh = 2055946361;
    bool NyNaLmKQSQjtgQaL = false;
    double hzyRHRfwUHNMxD = -887010.6819408245;
    int DFafYZfSxd = -824179597;
    int YyECuwarvq = -2107522641;
    string YeyxHqwSjwwmhabd = string("MKxNzehToYkCEuNKxeNBDgtBpqGAmfUyISIpxCVhSPrEQeoMRKtrucsekvaUU");

    if (DFafYZfSxd <= 198703359) {
        for (int OAVLtHjLcpLD = 416942425; OAVLtHjLcpLD > 0; OAVLtHjLcpLD--) {
            jZBbrGEYh *= YyECuwarvq;
            aQzoDLMtSbhDEyqb = aQzoDLMtSbhDEyqb;
        }
    }

    for (int DQufXvmMPhj = 762811528; DQufXvmMPhj > 0; DQufXvmMPhj--) {
        continue;
    }

    if (hzyRHRfwUHNMxD < -887010.6819408245) {
        for (int rBMsLnquQcEzRR = 518986560; rBMsLnquQcEzRR > 0; rBMsLnquQcEzRR--) {
            NyNaLmKQSQjtgQaL = NyNaLmKQSQjtgQaL;
        }
    }

    for (int pRPHQotlm = 241944989; pRPHQotlm > 0; pRPHQotlm--) {
        DFafYZfSxd -= MdoEXBFuncjOfYh;
    }

    for (int YKjrzstTvOMahS = 1400933672; YKjrzstTvOMahS > 0; YKjrzstTvOMahS--) {
        DFafYZfSxd *= MdoEXBFuncjOfYh;
    }

    for (int JONzU = 832121569; JONzU > 0; JONzU--) {
        continue;
    }
}

anvEetg::anvEetg()
{
    this->nGAIpbL(1087088857, -822215664);
    this->eqBrKoIhX(-569486.6789275402, 764027.1230075279, false, -620371.4302569722);
    this->UpYtAzN(-554657.1114229982, false, -728668.5910314668, 976374.240926889);
    this->BMwvwaINLZfxc(string("zEiByYdblulDBkcChBYWElBtAPCzKgHpfxemsZInoaDaLiJHYMYjoBWbqxnZYBoVbULzNeNoGNtQrUIGtgxYMXLWzWzuSVSJSywqXmcPsSLtjvrksLiedGKzWlPBPOTBQjvwjNusKvvJgVwYLLpPpDg"), false, -544024.1071267326, string("tbHBXCRhAGXOqsmgspTsOqBxL"));
    this->ASlZaNPvENMOvPfx(false);
    this->rPRBPcIqLf();
    this->hDWqmNHZOtZqAtP(string("YkEggUmDDhLVY"), 475337.30107195635, -706602.7457060359);
    this->grySABPkdCQUta(831145.995109162, -945646.3750590535, 724230.019547061);
    this->edJdxlgMMj(2634.421230038785, string("XbZdwsADriyhNABZKwHNAUTGDWzdcAMxojMAGMUjDniflOqPSlVpayKolsaOhDrwKTzOlxcYigiWaiTKbTCFHWAhEUBfZnGIzaahVtWJetetrNTxbkelsNfXrBCZhlgsqtmReEdOfCJtZthoNUHUkzgbuvJhULcEiSzjEHUcrqXsDvkqdSDCxMZmaxcLXltyOdRXaJdNcSoPUPZi"), true, string("rBlHUnQqZTvLPKgEbLEeKIyoxCqCTtJIzusniyDEvNbkwqtIIBqMHvCsMdPmuxtACgfLLndGqvcDmxtAGBEVrsEaQabNEOQYrgmNjeertISyuCfWwZNrePofwviyCPTdafcHFFQPyqBTqRGPrGdVVZfzvaMVYoIfuWItRhGn"));
    this->wZyoMMGJ(1603862865, 1360494364);
    this->lPXNoxt(string("NOtXmliegctYdXifYrNJEerGYjuoGcRhBukkdVajHKtPdQtrSUEBWJgbPvOTSrRibfBtVEOQqzkjTPhJgIaLUGMiAUUMBKYLJDsLTgtmzwZacnGOBsoWTAMThcBTwekBnWIJBXWyNzhGRTCORxkSrpINkPzautCZqThWOmNGflOxUtFTdcvMuvfRxFwIZtQjppToogEzNuHZinxfkuJliKyvp"));
    this->EUhwoWxVKxxSFdoG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qAerLwxbYydMyNYu
{
public:
    double FLVvuumQgBLLxA;
    string vPTpARulROrKn;
    string CNROLAt;

    qAerLwxbYydMyNYu();
protected:
    double TlpkZBMWhe;
    int BMmyWxDAqCuEkPb;
    bool HEifsnPmlfXCcIK;
    int XktKN;

    void keOOJuZZWIbme(double qFJAUVfHl, double RyNZPVnW, string Gzynu, int auzuLptqXkg);
    void hCabVMeZGlLkxEme(bool uTsbuiroPnQCAmTC, double JUCLjHtLqVP, bool HVNXKeRNBgWxNc);
private:
    bool UhsnqbqCiHfHj;
    string JCwZucjotTA;
    int BPHCkrHQnhkfc;
    double wavatTACi;

    string MAtFL(double cksjtJvprs, string eaVvxNuuld, bool WOzDhBBAHuvzl, double kNslnuDXQJDLeDI);
    bool DlYAunShrepQUXEy(double ITDOIFNKseVN, double zxmTVh, bool ReGWnOLARlkFqm, bool sTUBZF, double aNZIdFhrBRWLjVo);
    double vpoqfTbGUz(string DeoETgQOyMnKaIef, bool wcmddpG, bool ctrwsVARK, bool dJHchAafmwy, bool atQUF);
    string LHxaZQSvUjJSZ(string HtphFEzpG, double JnAlvWDLtO, double OfUxwOLOfXeG);
    int uQHEPi(int CeeaKzBCS, int wgGUydJazBvKK, double YeEnwflbqGSACOlO);
    int aNsfjjcj(double LRXlsEdeTLIy, int aMjSmAUQfGW);
    void hyXrqPluQn(int VIsfDxYp);
    double EKofoxgTghV(string PnQFDWkLilIEk);
};

void qAerLwxbYydMyNYu::keOOJuZZWIbme(double qFJAUVfHl, double RyNZPVnW, string Gzynu, int auzuLptqXkg)
{
    double CLGzyjptq = -801187.0870806186;
    double GwXxai = -422950.75726639957;
    double OGbzcCCLaJqGf = 295019.16240204865;
    int RwPqIcTJfB = -1327722699;
    double EYCgRT = 976017.3909053799;
    int FjWIy = -1462944167;
    string FzYpKjoZu = string("ZoYbFodWdPxKxGvIpPNIiqsvevmyRtEluPhANDMUdAYQanLWdurHaSdYnaFxzwossUgtniawiMnUhoehqKGjuTbwZrkFlOEpyoBsxagAACJnZcggLPjNEGDcbuDQgLeHjuzjgyQBuBjNfjBBolOoji");
    bool TAzkUj = false;

    for (int nyNOCzGzPZA = 1511611389; nyNOCzGzPZA > 0; nyNOCzGzPZA--) {
        GwXxai += GwXxai;
    }

    for (int cvmIhUmLsZTDXZO = 420951212; cvmIhUmLsZTDXZO > 0; cvmIhUmLsZTDXZO--) {
        TAzkUj = ! TAzkUj;
        RyNZPVnW = EYCgRT;
        EYCgRT += EYCgRT;
        EYCgRT -= GwXxai;
    }

    for (int WBERIXylmrsWhuS = 1171934161; WBERIXylmrsWhuS > 0; WBERIXylmrsWhuS--) {
        continue;
    }

    for (int PzMjsJmuFf = 775680732; PzMjsJmuFf > 0; PzMjsJmuFf--) {
        OGbzcCCLaJqGf *= RyNZPVnW;
        EYCgRT *= GwXxai;
    }
}

void qAerLwxbYydMyNYu::hCabVMeZGlLkxEme(bool uTsbuiroPnQCAmTC, double JUCLjHtLqVP, bool HVNXKeRNBgWxNc)
{
    int jntvWGBNPShFpQ = -1948703383;
    bool vcVOzO = true;
    string tlTBOvFPPK = string("iarFjJmFYMVpIbRYAwFUnYdEIEtLvhUUTjfzURGvoFHSbGQSogTRoBoZCmlunDswvDITmBDhZUNzLoNFxROXPgCtrzXGKyvuLfAUnzctVdKTlFxYemjhcwcOucHlZqEnEdtXzfiIFFLGtbkEDJdJkhXFFpnxeQooWPJFtMsJgarVPwBvBcZLcMBEiSUIbt");
    int dqfYvdtvc = -1848415359;
    int eupcxlEWIopFETZD = 123002807;
    bool jiXRoeCX = true;
}

string qAerLwxbYydMyNYu::MAtFL(double cksjtJvprs, string eaVvxNuuld, bool WOzDhBBAHuvzl, double kNslnuDXQJDLeDI)
{
    bool mvdhfyCNmhndNrPI = true;
    bool fZJmqTBFSBVrbvYw = false;
    string paqjnkSphSIIxBRv = string("tVBLukcULsAdVWDptlhVPBDbSCNFwXhXaEMIVpdBpceuhDUgmrhJCCkuulmFcuqkDfSBiOdSfHJxITeuVPJhztgbQrdZsSHlcRtFoLbmmEIWSrPeGHUqJSWCWBJfJGbMNDrBhjoKEoLTPwHshTQqCdTXpsSZMlsBfUGhrnExmtejxWWEAiDTMrYhUThjdBm");
    bool GLAQiCyRhb = false;
    double IGvcKyowxQjeRE = -262283.724435062;
    string xxZurZNaDKa = string("KhmeCokhiVUFOcCZ");
    double bkKjQcySM = -949600.2008035412;
    int MSdSa = -1701795489;
    int LjbehJCpVcAUSCoT = 408569478;

    if (eaVvxNuuld != string("tVBLukcULsAdVWDptlhVPBDbSCNFwXhXaEMIVpdBpceuhDUgmrhJCCkuulmFcuqkDfSBiOdSfHJxITeuVPJhztgbQrdZsSHlcRtFoLbmmEIWSrPeGHUqJSWCWBJfJGbMNDrBhjoKEoLTPwHshTQqCdTXpsSZMlsBfUGhrnExmtejxWWEAiDTMrYhUThjdBm")) {
        for (int yEINAkKV = 1303875099; yEINAkKV > 0; yEINAkKV--) {
            cksjtJvprs *= bkKjQcySM;
            GLAQiCyRhb = mvdhfyCNmhndNrPI;
            WOzDhBBAHuvzl = ! WOzDhBBAHuvzl;
        }
    }

    if (GLAQiCyRhb != true) {
        for (int zLsmRBMhQxu = 814137266; zLsmRBMhQxu > 0; zLsmRBMhQxu--) {
            eaVvxNuuld = xxZurZNaDKa;
            bkKjQcySM = kNslnuDXQJDLeDI;
        }
    }

    if (eaVvxNuuld >= string("KhmeCokhiVUFOcCZ")) {
        for (int psFYuaqdSDkkui = 2057243658; psFYuaqdSDkkui > 0; psFYuaqdSDkkui--) {
            GLAQiCyRhb = ! mvdhfyCNmhndNrPI;
        }
    }

    for (int WYLFf = 741921655; WYLFf > 0; WYLFf--) {
        IGvcKyowxQjeRE = kNslnuDXQJDLeDI;
        mvdhfyCNmhndNrPI = ! mvdhfyCNmhndNrPI;
    }

    for (int NLfpXuCBKSh = 530877235; NLfpXuCBKSh > 0; NLfpXuCBKSh--) {
        mvdhfyCNmhndNrPI = ! mvdhfyCNmhndNrPI;
        bkKjQcySM -= IGvcKyowxQjeRE;
        bkKjQcySM = bkKjQcySM;
        WOzDhBBAHuvzl = ! WOzDhBBAHuvzl;
    }

    return xxZurZNaDKa;
}

bool qAerLwxbYydMyNYu::DlYAunShrepQUXEy(double ITDOIFNKseVN, double zxmTVh, bool ReGWnOLARlkFqm, bool sTUBZF, double aNZIdFhrBRWLjVo)
{
    double aVpsaoWEWdWIfbRW = -80459.91010450087;
    bool vxeOE = false;

    if (ITDOIFNKseVN > 497679.6244608538) {
        for (int yDYNCxcKeTsrAB = 1735646204; yDYNCxcKeTsrAB > 0; yDYNCxcKeTsrAB--) {
            continue;
        }
    }

    return vxeOE;
}

double qAerLwxbYydMyNYu::vpoqfTbGUz(string DeoETgQOyMnKaIef, bool wcmddpG, bool ctrwsVARK, bool dJHchAafmwy, bool atQUF)
{
    int oRVrrsgmv = -449035444;
    double PmUtbpRrhWNhvo = -534782.8883117518;
    int ZJILLLsFUaxbQw = -1661305795;
    int XIGErThkzsagUcoJ = -1026798937;
    string idXFeRhAwcVpOBf = string("UatnbHtpDHtBYLmCOsxQLogpISQXEVsiAJleoYBOILWkEDrVpLkBPQzQODcJszbAyYnUnKHvMhyLOHgNdydqpVsFvVPXzqTPJWAKTgPzxQemdxKwIDUsSkKHIeRjnbJvdEusYIqCTOCqbYsAzrJhqgMSYghwfJJkZaGZCQOAXtWjdUbz");
    string vuXZbCzqQKoZDq = string("zUvVWFJgDLwXGoUBNYsjHhVGklXqqdZVPenqMnvKMuydppGbUOIlVBNfDaJLaXumHhMqvCSLFpxKVRBGJugINMxotMGstxNrHVbbiCIimfhWCOZkSCRslrCjSxyWIUPzJnVILtCBxQlpSfRinolfvgxAJwOZRmFjYQdzxK");
    double HVUfqry = -662730.1017523892;
    double fmqAmmrgjt = 269490.3628370822;

    if (oRVrrsgmv == -449035444) {
        for (int WkxvUYedkDqjMGW = 1025497643; WkxvUYedkDqjMGW > 0; WkxvUYedkDqjMGW--) {
            ctrwsVARK = dJHchAafmwy;
            ctrwsVARK = atQUF;
        }
    }

    return fmqAmmrgjt;
}

string qAerLwxbYydMyNYu::LHxaZQSvUjJSZ(string HtphFEzpG, double JnAlvWDLtO, double OfUxwOLOfXeG)
{
    double uWdizcqiEsrLnDz = -557378.1489657315;
    bool JNEGCCcGPIVl = false;
    bool gbUaNDgz = false;

    if (uWdizcqiEsrLnDz < -557378.1489657315) {
        for (int blDrt = 888158897; blDrt > 0; blDrt--) {
            JnAlvWDLtO = JnAlvWDLtO;
            uWdizcqiEsrLnDz /= uWdizcqiEsrLnDz;
            gbUaNDgz = ! JNEGCCcGPIVl;
            HtphFEzpG += HtphFEzpG;
            JnAlvWDLtO += JnAlvWDLtO;
            OfUxwOLOfXeG *= uWdizcqiEsrLnDz;
        }
    }

    for (int ysBcdAI = 497819039; ysBcdAI > 0; ysBcdAI--) {
        JnAlvWDLtO += uWdizcqiEsrLnDz;
        uWdizcqiEsrLnDz *= OfUxwOLOfXeG;
        OfUxwOLOfXeG = OfUxwOLOfXeG;
    }

    for (int CKCwqWrtAjAVSe = 1491347617; CKCwqWrtAjAVSe > 0; CKCwqWrtAjAVSe--) {
        HtphFEzpG += HtphFEzpG;
        uWdizcqiEsrLnDz += OfUxwOLOfXeG;
        JnAlvWDLtO = OfUxwOLOfXeG;
        gbUaNDgz = ! gbUaNDgz;
        JnAlvWDLtO -= uWdizcqiEsrLnDz;
    }

    return HtphFEzpG;
}

int qAerLwxbYydMyNYu::uQHEPi(int CeeaKzBCS, int wgGUydJazBvKK, double YeEnwflbqGSACOlO)
{
    double aDLfcgYLzK = -1006678.7938266189;
    string oDzKcAhyFKyRqzn = string("uadSlQgDykStMocAWFoJQpDsxfUvmgHQeEXiZuUbuituJwdmpjnqPTjbUiNenFcThGkprvDoRvusTaNvplOzInjLjwfmK");
    bool RwgAwyutFl = true;

    for (int xGEuxuZjHImz = 1941754976; xGEuxuZjHImz > 0; xGEuxuZjHImz--) {
        wgGUydJazBvKK -= CeeaKzBCS;
    }

    for (int UjKrqF = 1743448886; UjKrqF > 0; UjKrqF--) {
        wgGUydJazBvKK /= CeeaKzBCS;
    }

    for (int gxyaaxpGGtTXeHR = 1794664448; gxyaaxpGGtTXeHR > 0; gxyaaxpGGtTXeHR--) {
        continue;
    }

    for (int GBFHMpfGympyArkQ = 900700950; GBFHMpfGympyArkQ > 0; GBFHMpfGympyArkQ--) {
        oDzKcAhyFKyRqzn = oDzKcAhyFKyRqzn;
        aDLfcgYLzK += aDLfcgYLzK;
    }

    for (int oNorVtjRfbIYHmsV = 1188468983; oNorVtjRfbIYHmsV > 0; oNorVtjRfbIYHmsV--) {
        oDzKcAhyFKyRqzn = oDzKcAhyFKyRqzn;
        RwgAwyutFl = ! RwgAwyutFl;
    }

    for (int KgZUJfiPUMlyo = 150420828; KgZUJfiPUMlyo > 0; KgZUJfiPUMlyo--) {
        YeEnwflbqGSACOlO *= aDLfcgYLzK;
        CeeaKzBCS += wgGUydJazBvKK;
        YeEnwflbqGSACOlO -= aDLfcgYLzK;
        wgGUydJazBvKK /= wgGUydJazBvKK;
        RwgAwyutFl = RwgAwyutFl;
        wgGUydJazBvKK /= CeeaKzBCS;
    }

    return wgGUydJazBvKK;
}

int qAerLwxbYydMyNYu::aNsfjjcj(double LRXlsEdeTLIy, int aMjSmAUQfGW)
{
    double XLDfybUStfpcOT = -524376.4299279255;
    double RfdKociSIUh = -499728.4688416191;
    bool vkttoNJczBn = true;
    int sPLLodrKIIzTMCk = 1628758930;
    string mVvPlTiF = string("NCbOpPYBrdNkpxyghrdJmWiLqOoQHDtOdxxWKqBALtnDKsfNMoLrXfbHcoVmiAGAIaTSGtiQcvgXVJzdlOMTmFBafGSCxFhAftsVkSrZqWeZBQAKGRvTctBRQeYwzDraNeR");

    for (int HZfDb = 2051937860; HZfDb > 0; HZfDb--) {
        LRXlsEdeTLIy -= RfdKociSIUh;
    }

    for (int ZgYfBuVvJimVmV = 1842540907; ZgYfBuVvJimVmV > 0; ZgYfBuVvJimVmV--) {
        vkttoNJczBn = vkttoNJczBn;
        vkttoNJczBn = ! vkttoNJczBn;
        sPLLodrKIIzTMCk -= aMjSmAUQfGW;
        LRXlsEdeTLIy *= LRXlsEdeTLIy;
    }

    return sPLLodrKIIzTMCk;
}

void qAerLwxbYydMyNYu::hyXrqPluQn(int VIsfDxYp)
{
    bool svvMl = true;
    double QSlqZKRTfJ = 511470.93438728474;
    string cibJafZQWKXGTro = string("lYqWQuRfVaXRPpFTIOsjLKYnKcTMqzJZitlbfn");
    bool ePyRjbNuowfHRqdY = true;
    bool dKvrwo = false;
    int YOhnyBIBDjk = -1707133015;
    int PxGFhWROjVrvO = 1522684655;
    double FdfloqKFEnwjGO = -587375.4329589686;
}

double qAerLwxbYydMyNYu::EKofoxgTghV(string PnQFDWkLilIEk)
{
    int VpmiUOnYi = 1655336302;
    string OSioWE = string("wMkYqiHbXrHiBoikcLlAlQqQBUgTfbXkQGsZIqszXJjDgMTYkmlTflGngPEAcJhACYRcLuFfFXYMxlbnfWKJDmjJBGlJJBZsAKMdVmXxybPkYTDNiPzUrRRaLLxtxSaeNpUBFitZHXpLwKFMeCKgxeWgyCRNaRxMTZxGyRdNUBJXOvPUTNIgIGvONeulyCWLaShoLqcMMtTvFztHoultEreDpvgkwmvIgudVCwbaFaRACRNkmGcCBb");

    if (PnQFDWkLilIEk == string("wMkYqiHbXrHiBoikcLlAlQqQBUgTfbXkQGsZIqszXJjDgMTYkmlTflGngPEAcJhACYRcLuFfFXYMxlbnfWKJDmjJBGlJJBZsAKMdVmXxybPkYTDNiPzUrRRaLLxtxSaeNpUBFitZHXpLwKFMeCKgxeWgyCRNaRxMTZxGyRdNUBJXOvPUTNIgIGvONeulyCWLaShoLqcMMtTvFztHoultEreDpvgkwmvIgudVCwbaFaRACRNkmGcCBb")) {
        for (int OyRxKyzSSuWbb = 512427870; OyRxKyzSSuWbb > 0; OyRxKyzSSuWbb--) {
            PnQFDWkLilIEk = OSioWE;
            PnQFDWkLilIEk += PnQFDWkLilIEk;
        }
    }

    for (int zccUhZR = 189271600; zccUhZR > 0; zccUhZR--) {
        VpmiUOnYi = VpmiUOnYi;
        PnQFDWkLilIEk += PnQFDWkLilIEk;
        OSioWE = PnQFDWkLilIEk;
        OSioWE = OSioWE;
        OSioWE += OSioWE;
    }

    if (VpmiUOnYi != 1655336302) {
        for (int bJHSBaDKzC = 2018483478; bJHSBaDKzC > 0; bJHSBaDKzC--) {
            PnQFDWkLilIEk += OSioWE;
        }
    }

    return 874230.5245216382;
}

qAerLwxbYydMyNYu::qAerLwxbYydMyNYu()
{
    this->keOOJuZZWIbme(-202900.61895341013, 833824.9107790542, string("IYoQWwCXsQfLFdJUBEWFhnJyIZtcECOocFaJPLRQbwVNWcskAIqNLPEcsJSmCoKEdypdHskKGawJGaevqytGcgUsyZxc"), 1751302221);
    this->hCabVMeZGlLkxEme(true, 282590.6109831762, false);
    this->MAtFL(614003.9703758761, string("SdkNsjPbwdxsnsLfoaLZmtuxlVavfoySQieeJiwHKhSQtIipPhHrGpmRjVNNgyiMzTneEyilmbaxBwvwurZoIOaQUxeBYZDHApGAuyZHdDNuFzYNqPCLeOSWWtjmISSYtolyRydZOURuQzpOWrMXCycsWHnCvQhjnIbTbTCLFeKptBqBWTWBGXCfjrHewmaVXZIPRQsMZoCJXkgrkXoCSXX"), true, -280615.14737738564);
    this->DlYAunShrepQUXEy(111798.03436622511, 497679.6244608538, false, false, 171633.48689102713);
    this->vpoqfTbGUz(string("hCJlhTKydMaLnRQSQlSpMXtAxYDpHcJhINOUlQxulHBMoAYybvJiJvpVzRecmDTjmhxVzlLnaFKOTlxlGqhWcVmkVLHZKPvrqjLakOVUmzohwRVtdAZrseZzwEJHDQFSqaXDrDziIBYVbzzEkqICdArPppKStTdVWwR"), false, false, true, true);
    this->LHxaZQSvUjJSZ(string("jFSgzwmaxgseYZvbhsPeoixegBxosrrlsPcESupzUbZdfBhWdiokeHYsOEMskUPDpomBXfpZiWAoMGFrkKxeuABedctrflCtuaSPLOmWOLhEMopdgdpQFdCTAipomQAfdCWiytyuQlYluVxyLsAttFMbvNwbXFeMmxZbLWztiXbXjjgcmhzekoDPNZnIZDmJ"), -947864.0368995427, -604702.5262361044);
    this->uQHEPi(1232967301, 1797547166, -387715.4840952727);
    this->aNsfjjcj(631502.8083140729, 1600374160);
    this->hyXrqPluQn(1288287917);
    this->EKofoxgTghV(string("aqKQAZvJGfQBtLnNmWmRxLowWsAdrLNKBhGibRUBRtdTCCLCRYykNuxzUYeuTnvpVTeiFYopZvXFQonxqDYYdIXOXEJrLnfJdFYYAjFczXaSmWscRDPnUttVHxsOYVPmoYlYtR"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YmMtmKGppJgKhhnL
{
public:
    string udLpan;
    int BDWWbjHGCPaoTNko;
    double EBcWHyIDlCBteOR;
    string XCqmoY;
    double HbmjF;
    double bEIThhidxFuEyHZQ;

    YmMtmKGppJgKhhnL();
    double taXndbp(int WoWtBOFjhzLuFuYC, double OgyKaM, bool JvklGHB, string IzLdLtVmU);
    string ZJujrHWbRuIx(int cEHvbpc, string bPgyFsdrWpUuvrrd, string sjIzxaf, int ldyjc, bool uHEeho);
    int mZflMTXJTB(int WgLLheZkl);
    bool uQvdGmYEjTTyL(int NVBacYnZfYc, double lsllvyVRnu);
protected:
    int eTaEvDQer;
    int CJzrEhAXtjg;
    string bEnmbUxvKm;
    bool SohgKrlT;
    int JngarLqisQIixuh;
    double dMgSxHsDJac;

    void FrKevhXBbOOONYUE(double gpsvZUGQvgta, bool KIrRXkvpH, int EQErR, double dpZYJqMlNuSyGd, string koUFUKCO);
    void EcLVxz(bool rSizfhvViIgH, double cQDho, string utygUKIjzxMKT);
    double CuziyZboIyav(string quTtfpQHIv);
    double aePFtzwIv(int HHYZVgsgnKE, double MNUxWFrdpLdWfeII, int SvoFjin, int pAekKbqvgicFPDF, double ydDJrMuLn);
    int cSIwQlVlZULUUxdf(int JvkvtN, string ZBhznsWdBSflz, int MyJigYv, int uyNizlV, string tiMSEclU);
    int JqCGuYXlELPqgh(bool PvwgSfsJ, string BAYfxuzT, int DqAAgVrmsXCWvpHC);
    bool cegcSmJQIuAkFyH(string eIEMX, bool EFcFOsoQK, bool loMEucKzhbj, bool YpsrvssUsWcxUW, string fThkbfgv);
private:
    string FVlBVjfHjTWXbe;
    double DEdODtOO;
    int aDEABLQKKgwIadv;
    double MVjcVIwcfhDnPU;

    string JOpBZrjKMlljNeg(int hemCdQ, double pRjBcOdVe, bool MMRSlNUBFApK, bool lQAdwSFu, string YCaxjSmtxOwg);
    int tOrVuEQzc(int EajmEcyLlAbENaQF, bool XFvQokog);
    double MfgJhPFvnJDaGE(bool GCxrIzurbbTWEnk, int xbeBpiWTSXxNF, bool mWEScQanxNBG, double qqmZwXUgvJDI, int FusIuoeZe);
    bool RiDHAp(bool oWyaMhwHCGe, double ABbViyv);
    string nEcAFtRyHxoCaS();
};

double YmMtmKGppJgKhhnL::taXndbp(int WoWtBOFjhzLuFuYC, double OgyKaM, bool JvklGHB, string IzLdLtVmU)
{
    string FUDijHwLEoiEpj = string("CctNWNBgGzohHaVmyuZBFALtdYBuoJGtLODOSccfONmLRUfOoGAWbhwUlkkPwqt");
    bool aMeAzcs = true;
    int MMlCl = 1312137480;
    string zoMNdEslvlkqjbAo = string("LDRicQgBJpNZKPztxsgXGNmAXGmvvkQsYRNoOkUjpeZNSBmfWyRzfOCCyHiDcxzhWANXfxFpWwYyrAAubRZPmwQIKjiKjQFSaJwDegbSAgtkysMfzUtlyARHOJpmuTvkdadAWOxuPCjQLxYu");
    int vOlwzQqGEI = -270955086;
    string xZmXKGbc = string("fmjvDUZeOsDOdfrhAIGylwlVOmIicJPpgjAAztpdanfouTPTkeFKYCCvNjyNpPpRYbAugfupdwyfiIQJTjQZfYoQBMeDOZOHSWRPUKZvRVrszvWYzeIwOwNCFNmtsuSNhyCivRsqPVtZhFilKuJkyLvuJRPJZawrxrcJfTTJeP");

    for (int SZCQqu = 220405046; SZCQqu > 0; SZCQqu--) {
        continue;
    }

    for (int VZMiQ = 2115090801; VZMiQ > 0; VZMiQ--) {
        FUDijHwLEoiEpj = FUDijHwLEoiEpj;
    }

    if (zoMNdEslvlkqjbAo >= string("PkwyXAyzQCfERJjHghZlAzdMkolmIodZJskoqASrqkbwyJMGrcUhyGTNXkLurqdDKKfEKkJYvUbAqUbVBPxurwGKfTEsDHYpBYFNrOvOugCyqwqrPDIsMkwnrwcVUItcokvfejmoBKPEpFCMLirSYKhQMjNgflFjVfzHXRqgEKiHqVIhLozNVVKEZhsEsKZiNxDmmRASbqcUmxwHMuIWNotrfuacZyRihRQCkZDqkDN")) {
        for (int JLIqAhw = 756239123; JLIqAhw > 0; JLIqAhw--) {
            IzLdLtVmU = xZmXKGbc;
            IzLdLtVmU += FUDijHwLEoiEpj;
        }
    }

    for (int hTBTHOaf = 1985885589; hTBTHOaf > 0; hTBTHOaf--) {
        FUDijHwLEoiEpj = xZmXKGbc;
        IzLdLtVmU += xZmXKGbc;
    }

    for (int WsgzrldfABuLauw = 7409260; WsgzrldfABuLauw > 0; WsgzrldfABuLauw--) {
        xZmXKGbc += FUDijHwLEoiEpj;
    }

    for (int HcUjKOndTJ = 1831956482; HcUjKOndTJ > 0; HcUjKOndTJ--) {
        aMeAzcs = ! aMeAzcs;
        zoMNdEslvlkqjbAo = xZmXKGbc;
        IzLdLtVmU += zoMNdEslvlkqjbAo;
    }

    return OgyKaM;
}

string YmMtmKGppJgKhhnL::ZJujrHWbRuIx(int cEHvbpc, string bPgyFsdrWpUuvrrd, string sjIzxaf, int ldyjc, bool uHEeho)
{
    double BltGMLE = 1034942.3777109709;
    bool lNVSZmhpIqEsb = false;
    string dOAInfUdvKmzwUe = string("qAHJAhzWwQkfpUiMwyKJsPbzNTxkjPHsnzLFtoZRtufgpphizSMaeSjxDPBXAgzsrUFFOSbSuFJHCSCRfRAkYStvXZOMWDhpQzGdjhugBzVieQvYCieCidDUwspiWeHmlKdrvsECYJpmKQvlFHoyHhhNihDNRZcfWaUgiwREcawdPpxtuOjQidyfarNjhPKxBMLZPignnwRkHnynzWhYMYOPkIQyCCqDxOVvkzBKJuSWfgSEAr");
    bool IzXaafas = true;

    if (BltGMLE < 1034942.3777109709) {
        for (int dGHwfbKUIK = 1567678031; dGHwfbKUIK > 0; dGHwfbKUIK--) {
            ldyjc /= ldyjc;
            bPgyFsdrWpUuvrrd += bPgyFsdrWpUuvrrd;
            cEHvbpc = ldyjc;
        }
    }

    for (int LhWVjeMwyAS = 635724171; LhWVjeMwyAS > 0; LhWVjeMwyAS--) {
        cEHvbpc += ldyjc;
    }

    if (uHEeho != true) {
        for (int ckMXzP = 2120709553; ckMXzP > 0; ckMXzP--) {
            IzXaafas = ! uHEeho;
            sjIzxaf += bPgyFsdrWpUuvrrd;
            dOAInfUdvKmzwUe += dOAInfUdvKmzwUe;
            IzXaafas = ! uHEeho;
            dOAInfUdvKmzwUe = bPgyFsdrWpUuvrrd;
        }
    }

    return dOAInfUdvKmzwUe;
}

int YmMtmKGppJgKhhnL::mZflMTXJTB(int WgLLheZkl)
{
    bool NAruTRNsR = false;
    double klKEhtXPqKIvaO = 523885.345808656;
    bool JTJTEHpLW = false;
    int hWGakCF = 1912979380;
    double EueauJsdOLuN = 622823.3329959217;
    bool LVKaXDwT = false;
    double UJdTjhlsSm = -996983.2211281346;

    for (int nwoRbTLiivD = 567652837; nwoRbTLiivD > 0; nwoRbTLiivD--) {
        UJdTjhlsSm -= UJdTjhlsSm;
        NAruTRNsR = ! LVKaXDwT;
    }

    for (int MvLQQqXk = 721756092; MvLQQqXk > 0; MvLQQqXk--) {
        NAruTRNsR = ! JTJTEHpLW;
        JTJTEHpLW = LVKaXDwT;
    }

    if (EueauJsdOLuN == -996983.2211281346) {
        for (int oNwPFeVUd = 2032787166; oNwPFeVUd > 0; oNwPFeVUd--) {
            NAruTRNsR = ! LVKaXDwT;
            NAruTRNsR = ! JTJTEHpLW;
        }
    }

    for (int oUycjdFnJnbzM = 206775990; oUycjdFnJnbzM > 0; oUycjdFnJnbzM--) {
        NAruTRNsR = LVKaXDwT;
        klKEhtXPqKIvaO -= EueauJsdOLuN;
        EueauJsdOLuN *= UJdTjhlsSm;
    }

    return hWGakCF;
}

bool YmMtmKGppJgKhhnL::uQvdGmYEjTTyL(int NVBacYnZfYc, double lsllvyVRnu)
{
    string kkkAlFbCBqRTui = string("dBZENQiAepBHmLVTNDrzHnnOuarG");
    string MlKScPiHtY = string("phEQqQVFwnOQXSYPOrXuJrOnVLDrDZRSgHCGH");
    bool jILLEkp = false;
    string fXNfQ = string("WeIvcHnhnuMsIPRtSrKSIUuzpiGgiQWKfLoIORILXzZERxNuHDStXsoZXnOmaQteBpSD");
    bool yvWpQD = true;
    double zOsCD = 340450.4700907538;
    bool hBYUjbkIZh = false;
    double fNZNQPvwZtaMMxp = -501872.5134693588;
    int uQenOfLE = 879239223;
    double IeAcgmPZehuU = -579465.4495991549;

    if (zOsCD == 340450.4700907538) {
        for (int vqeemRwwfTOQggr = 8422829; vqeemRwwfTOQggr > 0; vqeemRwwfTOQggr--) {
            fXNfQ += MlKScPiHtY;
            kkkAlFbCBqRTui = fXNfQ;
            zOsCD /= fNZNQPvwZtaMMxp;
        }
    }

    if (uQenOfLE > 879239223) {
        for (int xJufFcBmzADVQ = 443986850; xJufFcBmzADVQ > 0; xJufFcBmzADVQ--) {
            continue;
        }
    }

    for (int JbzmfvqKv = 882072843; JbzmfvqKv > 0; JbzmfvqKv--) {
        fNZNQPvwZtaMMxp += IeAcgmPZehuU;
        IeAcgmPZehuU *= zOsCD;
        uQenOfLE = uQenOfLE;
    }

    return hBYUjbkIZh;
}

void YmMtmKGppJgKhhnL::FrKevhXBbOOONYUE(double gpsvZUGQvgta, bool KIrRXkvpH, int EQErR, double dpZYJqMlNuSyGd, string koUFUKCO)
{
    string gSAVOFTMLY = string("DHWEuYsNWVcwuGhAcSVZBkvndYqEoEqjrvudVIGHKPkQJVWuLDqoGxxkmRDAwTOKEJIrloBQDOUTsQoBBBpiqTUYcEyzCBMXQoRbeODWFZYEikrWNnyfotHlViWFqFrfFjCSkWmrUnMdiIcSKylDaixqEPxzIofKedKDkVbZXsVJXoMxYagXPIvUTGHPUKKPqDVenuEJWcALKyUPDxCqJsKIaByyMTUSSysUAVgY");
    bool LKrvZFjmg = true;
    string vEqeqHytJkA = string("eGqgUEmULAbyFXqNreCamotCIiAUYgWRlwCjkiRZvQBjmiwvNxOUlaoyytOleuutXRiHAbglHNoeVIKlneUZKcmhRWxMlakKpISoyhoicOHjpsHVlcxKXapXckWXmq");
    double cUahfRc = -503109.75702128385;
    double gIvRZWHd = 53836.19053906542;
    string juJIXrypHTlewzE = string("mBaUFECvXcEAIJFBZJTporGcbYVFqNXgNCVYWIGSKwIgGyxZjUjMkFZOiztbaXcZVkddNPDlFgZrQvhzgAVJiBvAoctORRqXCVvOvmYRuoUlKyaoaFWWycmPyWLGVesDDBodrDIhYbxmlBkGFzSGChwyHuUzriWlQJuVjcvnfdVNUfFMXUfnqHsCIMWuqFPgqBNamoWjYxeufyelPuQYII");
    bool SkHyoysYt = false;
    double ReBGRpFIZMTfiqR = 842723.1420057857;
    bool ssKKYj = true;

    for (int nwUtNgK = 1226639133; nwUtNgK > 0; nwUtNgK--) {
        LKrvZFjmg = LKrvZFjmg;
        vEqeqHytJkA = gSAVOFTMLY;
        ReBGRpFIZMTfiqR -= dpZYJqMlNuSyGd;
        SkHyoysYt = ! KIrRXkvpH;
    }
}

void YmMtmKGppJgKhhnL::EcLVxz(bool rSizfhvViIgH, double cQDho, string utygUKIjzxMKT)
{
    bool vsAoYaWopoSz = true;
    double cmbYJRqNdeBlG = 103535.04036109068;
    double AUcwE = 286364.25684235216;

    if (cmbYJRqNdeBlG != 62961.472202309735) {
        for (int qdaqAByYU = 1325003583; qdaqAByYU > 0; qdaqAByYU--) {
            vsAoYaWopoSz = ! vsAoYaWopoSz;
        }
    }

    if (cmbYJRqNdeBlG < 103535.04036109068) {
        for (int dIfdXoEnSTzuY = 1087972759; dIfdXoEnSTzuY > 0; dIfdXoEnSTzuY--) {
            continue;
        }
    }
}

double YmMtmKGppJgKhhnL::CuziyZboIyav(string quTtfpQHIv)
{
    int KgjdupNLsrqIhEsf = -2064288563;
    string PTpoBNMGkiyIY = string("cPOzeWNbahDUhfalnfFeseuCseWNgIiOWEWbQvDexQDRvbpNQgzZgzBFCpmfBfQklRSpuullHAOeuHzJNBnmrrClfmrYIgEzzPDJmECfzlnV");

    if (PTpoBNMGkiyIY >= string("cPqvLBziLLnGjuVGoQGedvlCnOVGyeuESVRHxXqyZWpfDgejFdQNlvAveezxXStXARHnvbEndOQvxUKQOsZfmAXNBAtqzcqiqLZAtDZBZNcKEyWCFXIeDHjjKrzRAksbjoDJnZkBNkJpSHAQGXMhsZgNRVBZcNEVazBRfelZkWyQlRvUEvgjgq")) {
        for (int ZlpjD = 1386350891; ZlpjD > 0; ZlpjD--) {
            quTtfpQHIv += quTtfpQHIv;
            quTtfpQHIv = quTtfpQHIv;
        }
    }

    for (int qjjuIWwUkCVaYbD = 500498992; qjjuIWwUkCVaYbD > 0; qjjuIWwUkCVaYbD--) {
        quTtfpQHIv += PTpoBNMGkiyIY;
        quTtfpQHIv += quTtfpQHIv;
        PTpoBNMGkiyIY += quTtfpQHIv;
        KgjdupNLsrqIhEsf /= KgjdupNLsrqIhEsf;
        PTpoBNMGkiyIY = PTpoBNMGkiyIY;
    }

    if (quTtfpQHIv >= string("cPqvLBziLLnGjuVGoQGedvlCnOVGyeuESVRHxXqyZWpfDgejFdQNlvAveezxXStXARHnvbEndOQvxUKQOsZfmAXNBAtqzcqiqLZAtDZBZNcKEyWCFXIeDHjjKrzRAksbjoDJnZkBNkJpSHAQGXMhsZgNRVBZcNEVazBRfelZkWyQlRvUEvgjgq")) {
        for (int lQYnrFsAQonB = 720585072; lQYnrFsAQonB > 0; lQYnrFsAQonB--) {
            KgjdupNLsrqIhEsf *= KgjdupNLsrqIhEsf;
            quTtfpQHIv += PTpoBNMGkiyIY;
        }
    }

    return -129062.04778449173;
}

double YmMtmKGppJgKhhnL::aePFtzwIv(int HHYZVgsgnKE, double MNUxWFrdpLdWfeII, int SvoFjin, int pAekKbqvgicFPDF, double ydDJrMuLn)
{
    double gLPugYWBhvibr = 61053.98530090053;
    bool lRBhDc = true;
    double wtHlQEuTrFt = -696638.774528321;
    double yBakcN = 488910.78852104006;
    bool HUzYYnnvCnW = false;
    bool fzINJG = false;
    bool BNgYuWGXgHzkLisi = false;
    bool dPFRQqKF = true;
    double mxtBiuhGmH = -413198.9850204405;
    string QJFawGSEknsvTg = string("HciAejSYXPGYWMTpuJYfZTccQGRYQEznLCpavyGhbWQjfzfgpkLsTUcxEmKkYMYmxjhdEzaMxxfphKeyjKeiNjyXExNeosuMQLoFPmkNwZfudEcxnEIKsMbfCaggkFBtHxPBeSBclfXJnZQMeHgiIVgjqGjGbczLeiWRVNVIdtlIrHhiuzPbkOaJNeQFaOyKuGkkvOrFrSj");

    for (int Irefpnr = 1525601907; Irefpnr > 0; Irefpnr--) {
        continue;
    }

    for (int pNhYnh = 442637830; pNhYnh > 0; pNhYnh--) {
        MNUxWFrdpLdWfeII += ydDJrMuLn;
        BNgYuWGXgHzkLisi = BNgYuWGXgHzkLisi;
    }

    for (int OhJrtqPU = 1439661411; OhJrtqPU > 0; OhJrtqPU--) {
        continue;
    }

    for (int IUbtcfrNqpUOTh = 1882677778; IUbtcfrNqpUOTh > 0; IUbtcfrNqpUOTh--) {
        lRBhDc = ! BNgYuWGXgHzkLisi;
        HUzYYnnvCnW = lRBhDc;
    }

    return mxtBiuhGmH;
}

int YmMtmKGppJgKhhnL::cSIwQlVlZULUUxdf(int JvkvtN, string ZBhznsWdBSflz, int MyJigYv, int uyNizlV, string tiMSEclU)
{
    bool gqoYXRhaIQLOksh = false;
    double LLowG = -670958.4960931358;
    int IgiWq = 718289964;
    int mrkxDhenMtRyNcd = 436576453;
    string PKAXyWqZpvjTR = string("PoPjdlnLwwFLwYbrOTqMeCJxoBythhlYboIdyvVwRDcwwFIOpyFD");
    double GIqbmxsevS = 872375.6094752805;
    string zhPRUSuBECDqcqs = string("ime");

    if (JvkvtN >= 1943153069) {
        for (int nausoL = 2088546781; nausoL > 0; nausoL--) {
            IgiWq = uyNizlV;
            IgiWq -= mrkxDhenMtRyNcd;
        }
    }

    return mrkxDhenMtRyNcd;
}

int YmMtmKGppJgKhhnL::JqCGuYXlELPqgh(bool PvwgSfsJ, string BAYfxuzT, int DqAAgVrmsXCWvpHC)
{
    string ImdTOppTjCmInAJr = string("EoSrciotFilbFLQNYcDFQtrAMhkuWabxxRrsYGQCRkcheDmNlTssualXJXUtJEKmQrjaDoXaLmcsgvNxuJQUbgGxopzuXoAkVKQlickNvWAYEwIGckMVnEpMXHGUDVOCkANVTbYgEFezHIMLTyueRQKRLDyegMrKIcbFgdDLvAxQkqYkU");
    int RMaCCqtLzppxNf = 1667033503;
    double YffxQCMo = -501992.1860197031;
    int ieXfYvxTbAoyRx = 1824644495;
    string WrynaHRBNAC = string("zdcryrmdWOGesDYbSm");
    double CSRlJZtWCppEZhU = 371669.4542502527;
    bool EIdUwGOJOmR = false;
    int XLqhAmwlXcfG = -542888546;

    for (int oBbXChB = 1636582309; oBbXChB > 0; oBbXChB--) {
        ieXfYvxTbAoyRx += RMaCCqtLzppxNf;
        ieXfYvxTbAoyRx -= XLqhAmwlXcfG;
    }

    return XLqhAmwlXcfG;
}

bool YmMtmKGppJgKhhnL::cegcSmJQIuAkFyH(string eIEMX, bool EFcFOsoQK, bool loMEucKzhbj, bool YpsrvssUsWcxUW, string fThkbfgv)
{
    string enonzpJ = string("RaqrNLbcKwVxImBuxxpaZldZIHayRntVAXWJBlqWVDfcckiwAmdtnsPfAJibiypufaRjaEQXDJTvtOMUyqZDOqZL");
    int jjRNpp = 1999342529;
    double OdJQWUxCWHOWO = -521830.0925188126;
    int rwIqDtszPYNjZxR = -1425450108;
    int nAZbLhNonkR = -1869446911;
    string wGMfNAD = string("PxLHlkoqFhIgcCeLovERSMafuozuEmeQmRRHMJUJUqaUTYMQPFtTMDRzCsuLHZhDdeUMnHNesrcNcyeazyruGeQeHvXBvtoDgoYCdZZqfrIsihduvFvRSuctZvWJ");
    string pcNuJGZFhIhqtBVH = string("TKNGWfKyopXXmisSNeYDZmCWUEoZVwvKgBHHYMJDGnNxNzmExyQXZacvzaybgqGWcQUyxDyTtqNKwOZIEjwjxBeyBZahSGAfsdbmujhkqMHkDUaaMdObCVNDUgRKnKzxCYhMVts");

    for (int SqDJArzzRD = 432731000; SqDJArzzRD > 0; SqDJArzzRD--) {
        eIEMX = eIEMX;
        YpsrvssUsWcxUW = ! loMEucKzhbj;
    }

    if (nAZbLhNonkR <= -1869446911) {
        for (int LeaQMqpHEucmjMK = 805673735; LeaQMqpHEucmjMK > 0; LeaQMqpHEucmjMK--) {
            wGMfNAD += pcNuJGZFhIhqtBVH;
            fThkbfgv = pcNuJGZFhIhqtBVH;
        }
    }

    for (int qfEbCncWS = 731294320; qfEbCncWS > 0; qfEbCncWS--) {
        rwIqDtszPYNjZxR *= jjRNpp;
    }

    if (eIEMX <= string("RaqrNLbcKwVxImBuxxpaZldZIHayRntVAXWJBlqWVDfcckiwAmdtnsPfAJibiypufaRjaEQXDJTvtOMUyqZDOqZL")) {
        for (int IkrMaYASuqNSO = 173243980; IkrMaYASuqNSO > 0; IkrMaYASuqNSO--) {
            eIEMX = wGMfNAD;
            eIEMX = enonzpJ;
        }
    }

    for (int TvtvLkeNlNDuiP = 1987219278; TvtvLkeNlNDuiP > 0; TvtvLkeNlNDuiP--) {
        fThkbfgv += pcNuJGZFhIhqtBVH;
        pcNuJGZFhIhqtBVH += eIEMX;
        eIEMX += pcNuJGZFhIhqtBVH;
    }

    return YpsrvssUsWcxUW;
}

string YmMtmKGppJgKhhnL::JOpBZrjKMlljNeg(int hemCdQ, double pRjBcOdVe, bool MMRSlNUBFApK, bool lQAdwSFu, string YCaxjSmtxOwg)
{
    string XzLCDnQlq = string("IOEQvkbOMUQxSSEgcOuJYkCEQtLIZRKysAVaZRjERviwstSoYomKxDmbKGNAniiAjVpnDmirSlrTOrvIwICDceKVCmQvLrCDwdSgRFAkJ");
    int fQBlBdwQnQc = 2131636592;
    int IgTJF = 1968802767;
    string xgQkY = string("PuMIejwMShsTgkpdDajGzFvzHZTGmTGSQxcnjtKTMIhJtychezCRy");
    double PyAAnTt = -406277.1482939775;
    bool uqQggiTpaO = false;
    bool LsVCOSw = false;
    int QzGWYC = 18046279;
    double bdqnmlZ = 14778.073947192943;

    for (int FfTPhHPIBbeSkrXZ = 1246479998; FfTPhHPIBbeSkrXZ > 0; FfTPhHPIBbeSkrXZ--) {
        uqQggiTpaO = ! LsVCOSw;
        QzGWYC += fQBlBdwQnQc;
    }

    if (IgTJF < 2026428883) {
        for (int jVxiWvLeDp = 642629132; jVxiWvLeDp > 0; jVxiWvLeDp--) {
            lQAdwSFu = ! uqQggiTpaO;
            lQAdwSFu = lQAdwSFu;
            QzGWYC = QzGWYC;
        }
    }

    for (int JCqxLd = 1425290439; JCqxLd > 0; JCqxLd--) {
        hemCdQ -= IgTJF;
        PyAAnTt -= PyAAnTt;
        uqQggiTpaO = uqQggiTpaO;
    }

    for (int cwEOOeGhwmUxNloJ = 672043543; cwEOOeGhwmUxNloJ > 0; cwEOOeGhwmUxNloJ--) {
        continue;
    }

    return xgQkY;
}

int YmMtmKGppJgKhhnL::tOrVuEQzc(int EajmEcyLlAbENaQF, bool XFvQokog)
{
    bool cQIvHpimtTdF = true;
    int KtvujRp = -809497189;
    double Ywpgiwg = -528312.0321393914;
    int NHIPTaFKnG = 1388982027;
    double eTsEbLOTEgbPk = -959202.3874588168;
    double HbeXzQ = 718532.367935674;
    double wahqvVUHa = -891296.8246161782;
    bool mzZbgDVGOJkYIbc = true;
    bool YIZGiqRBNosSRIN = false;
    bool PqFkMeaYBwyltc = false;

    if (KtvujRp <= 1388982027) {
        for (int gYLJNHkwWzp = 2022167885; gYLJNHkwWzp > 0; gYLJNHkwWzp--) {
            KtvujRp *= KtvujRp;
            PqFkMeaYBwyltc = mzZbgDVGOJkYIbc;
            HbeXzQ -= Ywpgiwg;
            XFvQokog = mzZbgDVGOJkYIbc;
        }
    }

    for (int qclEmjG = 934501208; qclEmjG > 0; qclEmjG--) {
        continue;
    }

    if (Ywpgiwg < -891296.8246161782) {
        for (int rdVIBPTdnXUj = 1186377276; rdVIBPTdnXUj > 0; rdVIBPTdnXUj--) {
            continue;
        }
    }

    return NHIPTaFKnG;
}

double YmMtmKGppJgKhhnL::MfgJhPFvnJDaGE(bool GCxrIzurbbTWEnk, int xbeBpiWTSXxNF, bool mWEScQanxNBG, double qqmZwXUgvJDI, int FusIuoeZe)
{
    string fzcvbkNkKx = string("kYESvhrtUdwmyUyqoXQanUXHaLejYhJxOnKKJQImquoDBqOievKqaiDlkoFJSisBFeoqemxUaHyVCHLYsfUeHyQLGhXzlJdwdPIwouuZFosKnvYyyDFuCfRjgCANiarekqvEpqSZveRWrTIQqXemhoaivrTBNWtbTPjIsuxHIHmArKHpWvoiGPQxcBNutSQTiiWDthzrmaIKsBrLkYewi");
    bool WFLtTWWrk = false;
    bool SiHOaknfLtrkT = false;
    string kOtlhwCZwNq = string("JPJdsPLCyeBBeDaWdFGmSXaKFSrVrRUAbmoFVqljYDkNQnsvalfgjhEuBiEEvdZoRlaBdyrGEEmkrsRdUXDxbwJElTllGxFzovtKDIAcqHpJLDDwadJCowLkGfWiFWymAYgImtURdQmBpilNZzPFLn");
    double nOmIyRXvy = 765055.6333601681;
    bool NQjBqlZuNNIdxZQ = true;

    for (int fWAFQcWJRLW = 26177610; fWAFQcWJRLW > 0; fWAFQcWJRLW--) {
        mWEScQanxNBG = mWEScQanxNBG;
        kOtlhwCZwNq = kOtlhwCZwNq;
        WFLtTWWrk = ! NQjBqlZuNNIdxZQ;
    }

    for (int WpeOPlNliOjg = 887125032; WpeOPlNliOjg > 0; WpeOPlNliOjg--) {
        continue;
    }

    if (FusIuoeZe <= 891675892) {
        for (int TnzNVucFKfZnxhh = 1791979307; TnzNVucFKfZnxhh > 0; TnzNVucFKfZnxhh--) {
            SiHOaknfLtrkT = ! mWEScQanxNBG;
            WFLtTWWrk = ! NQjBqlZuNNIdxZQ;
        }
    }

    return nOmIyRXvy;
}

bool YmMtmKGppJgKhhnL::RiDHAp(bool oWyaMhwHCGe, double ABbViyv)
{
    int FteqJYWtdR = 657141454;
    double hPLZEhOW = 203194.11441561554;
    bool rWPogLqliTHHA = false;
    string zxuIF = string("NRgytTVSfeYeMTLHBxwfGIxWwprOLqiKBjsXZIgXzcScFJSCGInxnbtRAxfHgToTFMROUgVqzfLdtnPhHEXENEgaGzYlAXzIfOzwNQezzpCXssYXArIizFDeExaYLmgNIgLrzVYXrY");

    for (int DFJMFBFKJs = 1955770601; DFJMFBFKJs > 0; DFJMFBFKJs--) {
        rWPogLqliTHHA = rWPogLqliTHHA;
        hPLZEhOW /= ABbViyv;
        rWPogLqliTHHA = rWPogLqliTHHA;
        zxuIF = zxuIF;
        oWyaMhwHCGe = ! rWPogLqliTHHA;
    }

    if (rWPogLqliTHHA != true) {
        for (int oexEwOKRycivkBoD = 1432478929; oexEwOKRycivkBoD > 0; oexEwOKRycivkBoD--) {
            hPLZEhOW /= hPLZEhOW;
            hPLZEhOW += hPLZEhOW;
        }
    }

    if (FteqJYWtdR <= 657141454) {
        for (int vTWtHguAUlKfhB = 204262743; vTWtHguAUlKfhB > 0; vTWtHguAUlKfhB--) {
            hPLZEhOW -= ABbViyv;
        }
    }

    for (int caZcNLViWoAlR = 153069087; caZcNLViWoAlR > 0; caZcNLViWoAlR--) {
        ABbViyv += ABbViyv;
        FteqJYWtdR *= FteqJYWtdR;
        hPLZEhOW = hPLZEhOW;
    }

    return rWPogLqliTHHA;
}

string YmMtmKGppJgKhhnL::nEcAFtRyHxoCaS()
{
    double hwWcxR = 163384.76236446347;

    if (hwWcxR >= 163384.76236446347) {
        for (int ynRZHoF = 1003122440; ynRZHoF > 0; ynRZHoF--) {
            hwWcxR -= hwWcxR;
            hwWcxR += hwWcxR;
            hwWcxR /= hwWcxR;
            hwWcxR += hwWcxR;
            hwWcxR -= hwWcxR;
            hwWcxR += hwWcxR;
            hwWcxR -= hwWcxR;
        }
    }

    if (hwWcxR != 163384.76236446347) {
        for (int EfccDgAZbbSnZ = 86150036; EfccDgAZbbSnZ > 0; EfccDgAZbbSnZ--) {
            hwWcxR = hwWcxR;
            hwWcxR /= hwWcxR;
            hwWcxR -= hwWcxR;
            hwWcxR = hwWcxR;
            hwWcxR *= hwWcxR;
        }
    }

    return string("IsePsHgvWNLndouaiJlTGuPdwdDdfcneFWPRKUiCifCDsZFjIdxQsowiGHRYEWwAFAYJRMPTRiXaHIsaIxRfgbvHYufqnGcxRrNwvscacCkUpGSbRgAXoLMYBdLbWDpCqAfGYsOFvAxGkgcfnzRamXqTySimjWIbrWPDbUhCiqrNpWLrQGbYpvALZiBaRTHHWilNvycUMuZt");
}

YmMtmKGppJgKhhnL::YmMtmKGppJgKhhnL()
{
    this->taXndbp(-972988602, -352264.8202333576, true, string("PkwyXAyzQCfERJjHghZlAzdMkolmIodZJskoqASrqkbwyJMGrcUhyGTNXkLurqdDKKfEKkJYvUbAqUbVBPxurwGKfTEsDHYpBYFNrOvOugCyqwqrPDIsMkwnrwcVUItcokvfejmoBKPEpFCMLirSYKhQMjNgflFjVfzHXRqgEKiHqVIhLozNVVKEZhsEsKZiNxDmmRASbqcUmxwHMuIWNotrfuacZyRihRQCkZDqkDN"));
    this->ZJujrHWbRuIx(-124577776, string("xSFxjbyabZobNlIuKcCKreKZdvDGDEaNWsaGVuTmkXVdMNQejKAUOFRCBhjpflVMexWIilJyCvCMhpmdzeKj"), string("NxgGJUQUNFGBFKxpHelySCPBfmyvlKNJbEaWFLNZipyYCDgUMGXQqBSgzqofbiGxwQwEYxDxAEwBNYmnbgMHuzBdkdoREPHKXMubVFZxTiDJSYmzafSzgORHlyjvyJPBvOKnNsmAMLNroxyPEQwsIGcmnpDkhCzkcaVgRJyaHmcvKZaskqihPGekgPiyMAsmxznmizIwkuAyFgznqvRwSjOzmgVXYImFdckKqey"), -1873721217, false);
    this->mZflMTXJTB(1968673507);
    this->uQvdGmYEjTTyL(1431313776, 186141.0040604631);
    this->FrKevhXBbOOONYUE(552880.3198715604, true, -769298569, 849393.0001379244, string("LVJSTqPQMdIvqTbcsOmnzsMuQXGTKwvtvrsIMAplQcioKnSfeKHzwxVJdMKnSeaLfiHCNOWDinuXNQMWuVuFYLkmZLVpqWPJAFZnJjnSTiKfJfqaT"));
    this->EcLVxz(true, 62961.472202309735, string("kV"));
    this->CuziyZboIyav(string("cPqvLBziLLnGjuVGoQGedvlCnOVGyeuESVRHxXqyZWpfDgejFdQNlvAveezxXStXARHnvbEndOQvxUKQOsZfmAXNBAtqzcqiqLZAtDZBZNcKEyWCFXIeDHjjKrzRAksbjoDJnZkBNkJpSHAQGXMhsZgNRVBZcNEVazBRfelZkWyQlRvUEvgjgq"));
    this->aePFtzwIv(529333756, -449769.15837483224, -1334305120, 2015754005, 701168.1480729396);
    this->cSIwQlVlZULUUxdf(1756881975, string("zUkRMcXLIGTEJvCGoszHbBizhIRgBVzrVlhfiYiyrDLwsTPltQgkDVHuzYWDZcRSffAjaiYCHcTIZCPWETLhKRjgTsFAXRviotJOgPILXYRaaEvuzHaAQqMusqCQnGKVqCBnRCOOonfrvdBNhsXbzBbmZHXNoQLAkcWuXpLomAJuPTpZSgMfapjLYhnvhOkPNVyQCOjUoSWXMiTsdlLVeebpvAAkcHqBJqWOWPbizoyjbXFJiGP"), 1529424282, 1943153069, string("NtrsCUmQRUcAJovxpHMBsGpoOuxddtJnOCSuVVncIKoZksfqfSoPkDerEBpTGsuMThuvXwPdkmceStBHNBpXRQhhMYSZmYbhMGqQvYrVrwpSHBZwjzvKySWOlftdBRbDNUabZHvQkoFdjeWAHYJpqTKjBKxcxnWHmMKDYOYFbnsgYbBhpWHGpDdRKTBSuaOEElXEFXPjILlnQmHiNR"));
    this->JqCGuYXlELPqgh(false, string("eCiQABYZxZllrkrWmExnGQfsIfQknapLncNKlpWgMXFDvWoWkDJghHrfNSUcBTiGPKBGJqqFJdeksWszDXvnlAXzCRoIHSWIpLs"), -1656886198);
    this->cegcSmJQIuAkFyH(string("StMgqQmtKVPWoFxmWIbspsQyceosWzMjqkVzQatCkLrsQZSrTkbnQVJGlrvgEITpXcTujoDjVaQCgzaiUOCSHHHHvCqrCjEfcZsHUVUiHikJPSNauKxRvqrXhFtiFduqUgBWSJTcIPwinWyJPjyATSrsaVmpUPbgWRqSGaiUaGMajYPLQZgqCdzJdNKCzVb"), false, false, false, string("vRpkhOKQSRIBOrMNxwZCEAEscoXjmmFaXDavdjryDuTzsVaBkqdFxPIgkguuioQPmfzvtXNfthdGiVQIyFKDMKFYOXWdJbveMfapcLSPADEGOUPfVwELORCFvtczzEYxoizbUsTyBrjZVLLcXZSFFMbZJWKvOMdALAWTicjOTHIhvwMhVJLcVxIqGasXsuruLMjKho"));
    this->JOpBZrjKMlljNeg(2026428883, -931143.0170114803, false, true, string("gwSltYk"));
    this->tOrVuEQzc(1106916348, true);
    this->MfgJhPFvnJDaGE(false, 830131763, true, -161485.72193661006, 891675892);
    this->RiDHAp(true, 424717.77706012654);
    this->nEcAFtRyHxoCaS();
}
