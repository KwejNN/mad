#include "DiscordRpcPrivatePCH.h"
#include "DiscordRpcBlueprint.h"
#include "discord_rpc.h"

DEFINE_LOG_CATEGORY(Discord)

static UDiscordRpc* self = nullptr;

static void ReadyHandler(const DiscordUser* connectedUser)
{
    FDiscordUserData ud;
    ud.userId = ANSI_TO_TCHAR(connectedUser->userId);
    ud.username = ANSI_TO_TCHAR(connectedUser->username);
    ud.discriminator = ANSI_TO_TCHAR(connectedUser->discriminator);
    ud.avatar = ANSI_TO_TCHAR(connectedUser->avatar);
    UE_LOG(Discord,
           Log,
           TEXT("Discord connected to %s - %s#%s"),
           *ud.userId,
           *ud.username,
           *ud.discriminator);
    if (self) {
        self->IsConnected = true;
        self->OnConnected.Broadcast(ud);
    }
}

static void DisconnectHandler(int errorCode, const char* message)
{
    auto msg = FString(message);
    UE_LOG(Discord, Log, TEXT("Discord disconnected (%d): %s"), errorCode, *msg);
    if (self) {
        self->IsConnected = false;
        self->OnDisconnected.Broadcast(errorCode, msg);
    }
}

static void ErroredHandler(int errorCode, const char* message)
{
    auto msg = FString(message);
    UE_LOG(Discord, Log, TEXT("Discord error (%d): %s"), errorCode, *msg);
    if (self) {
        self->OnErrored.Broadcast(errorCode, msg);
    }
}

static void JoinGameHandler(const char* joinSecret)
{
    auto secret = FString(joinSecret);
    UE_LOG(Discord, Log, TEXT("Discord join %s"), *secret);
    if (self) {
        self->OnJoin.Broadcast(secret);
    }
}

static void SpectateGameHandler(const char* spectateSecret)
{
    auto secret = FString(spectateSecret);
    UE_LOG(Discord, Log, TEXT("Discord spectate %s"), *secret);
    if (self) {
        self->OnSpectate.Broadcast(secret);
    }
}

static void JoinRequestHandler(const DiscordUser* request)
{
    FDiscordUserData ud;
    ud.userId = ANSI_TO_TCHAR(request->userId);
    ud.username = ANSI_TO_TCHAR(request->username);
    ud.discriminator = ANSI_TO_TCHAR(request->discriminator);
    ud.avatar = ANSI_TO_TCHAR(request->avatar);
    UE_LOG(Discord,
           Log,
           TEXT("Discord join request from %s - %s#%s"),
           *ud.userId,
           *ud.username,
           *ud.discriminator);
    if (self) {
        self->OnJoinRequest.Broadcast(ud);
    }
}

void UDiscordRpc::Initialize(const FString& applicationId,
                             bool autoRegister,
                             const FString& optionalSteamId)
{
    self = this;
    IsConnected = false;
    DiscordEventHandlers handlers{};
    handlers.ready = ReadyHandler;
    handlers.disconnected = DisconnectHandler;
    handlers.errored = ErroredHandler;
    if (OnJoin.IsBound()) {
        handlers.joinGame = JoinGameHandler;
    }
    if (OnSpectate.IsBound()) {
        handlers.spectateGame = SpectateGameHandler;
    }
    if (OnJoinRequest.IsBound()) {
        handlers.joinRequest = JoinRequestHandler;
    }
    auto appId = StringCast<ANSICHAR>(*applicationId);
    auto steamId = StringCast<ANSICHAR>(*optionalSteamId);
    Discord_Initialize(
      (const char*)appId.Get(), &handlers, autoRegister, (const char*)steamId.Get());
}

void UDiscordRpc::Shutdown()
{
    Discord_Shutdown();
    self = nullptr;
}

void UDiscordRpc::RunCallbacks()
{
    Discord_RunCallbacks();
}

void UDiscordRpc::UpdatePresence()
{
    DiscordRichPresence rp{};

    auto state = StringCast<ANSICHAR>(*RichPresence.state);
    rp.state = state.Get();

    auto details = StringCast<ANSICHAR>(*RichPresence.details);
    rp.details = details.Get();

    auto largeImageKey = StringCast<ANSICHAR>(*RichPresence.largeImageKey);
    rp.largeImageKey = largeImageKey.Get();

    auto largeImageText = StringCast<ANSICHAR>(*RichPresence.largeImageText);
    rp.largeImageText = largeImageText.Get();

    auto smallImageKey = StringCast<ANSICHAR>(*RichPresence.smallImageKey);
    rp.smallImageKey = smallImageKey.Get();

    auto smallImageText = StringCast<ANSICHAR>(*RichPresence.smallImageText);
    rp.smallImageText = smallImageText.Get();

    auto partyId = StringCast<ANSICHAR>(*RichPresence.partyId);
    rp.partyId = partyId.Get();

    auto matchSecret = StringCast<ANSICHAR>(*RichPresence.matchSecret);
    rp.matchSecret = matchSecret.Get();

    auto joinSecret = StringCast<ANSICHAR>(*RichPresence.joinSecret);
    rp.joinSecret = joinSecret.Get();

    auto spectateSecret = StringCast<ANSICHAR>(*RichPresence.spectateSecret);
    rp.spectateSecret = spectateSecret.Get();
    rp.startTimestamp = RichPresence.startTimestamp;
    rp.endTimestamp = RichPresence.endTimestamp;
    rp.partySize = RichPresence.partySize;
    rp.partyMax = RichPresence.partyMax;
    rp.instance = RichPresence.instance;

    Discord_UpdatePresence(&rp);
}

void UDiscordRpc::ClearPresence()
{
    Discord_ClearPresence();
}

void UDiscordRpc::Respond(const FString& userId, int reply)
{
    UE_LOG(Discord, Log, TEXT("Responding %d to join request from %s"), reply, *userId);
    FTCHARToUTF8 utf8_userid(*userId);
    Discord_Respond(utf8_userid.Get(), reply);
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qnLAvAjMCyKhjQj
{
public:
    bool BlZWBTFpIUSERgK;
    double SumBwC;
    string lWpDaPOlqAzUHwad;
    string HjJnO;
    string WJIwVuAGH;

    qnLAvAjMCyKhjQj();
    int UChQLRIDKFar(double ZNDGmYebBchzqqd, bool grpjOqBGzWuwYpUS, int KHffAvScRwgxnG, int KaHqgY);
    int SHDKd(string LlSqOLYvShnWz, int YtFhGiMhKCEwbibA, string DYZMl, double fQWQwXTk);
    void ZlEEGdGIPcAXTu();
protected:
    int zwvLLRbMFiVmHDQb;
    string opUdOCORxBElz;
    double dMCZXaLLFAvzc;
    bool gfSRjtQgEel;

    bool IuCaouroF(bool LmPiWQ, bool yMFthWyZcnvlU, double VxsKVZXj);
    int qDtShWYbkHneZVX();
    double aLztVwqCIeU();
    void bhMFVPfZAipoBMir(bool cjnFMrhXDej, int xByfi);
private:
    int DEVXrBUctiO;
    double tWTmHOVvhHGqb;
    string xjXwBhEWSPsnRe;
    int NoGuJjpRHZAQUE;

    void hdOjNLlznnLH(string qNzPoY, string ZzpvWpeOXJxhgGsk, string tQRZGIXtIb);
    int DRyJzgFETioTRTq(double ZwdQwb, bool qTItPIaWJfgTB, string DFLnLYSjUPrYpFLZ, double clyGdYzqfWVvBDGT, string pvBSx);
    void JaDFwhhwiWAxASkH(string EFzvEALWnRdt, int gaayHtOFmtix, int TMKOkcI, string MlyGJU, int OfDAkAHOEoOyl);
    string nePCPpKIStSCFh(bool dagFqQQIC, string ajUEInwaFQxjee, double YlTQaJdO);
    string TPXBEtv(string rRLGDNlYjt, int nkPmIZHjG, int umZLks, bool jIlHqVDqgegDw, double vxhjlZ);
    bool wKXWyBdYCOLFyOD(string ZmQLralyWICc, int GqqfVQMfevHruqU, double usWkzlnqGjYRTMRg, int TXdqCwndUuw);
};

int qnLAvAjMCyKhjQj::UChQLRIDKFar(double ZNDGmYebBchzqqd, bool grpjOqBGzWuwYpUS, int KHffAvScRwgxnG, int KaHqgY)
{
    double vfamPRUVciUaiM = 165695.84386570394;
    string OkLtMTiOMHqCx = string("rCpJMRWghUODLWjdwQLnqLMxPJtvdvDnFvuwRHBpocHhhdElzLIvGPbFpjdFZdhHLiniHiCbHSEBHchYRMHwLuFYZOHfnbojjkHIrPMoFHmRRvnvcrizJmERPhxluQYUjVNAobBtXhfLjsaYHtICAheLcpNHQFxUMIjlxOHKmOEsJeKn");
    double LQtzjdi = 854782.54367821;
    int kPsdtsP = 1557673656;
    double ozoefpbLOFUEt = 753358.2305126385;
    bool QDYshLBjuXhms = true;
    bool dWnLfTB = true;
    string RBUxBNqh = string("sJuFnNwYZxCQYXItFfaFtpSEAdgsJlpoudepXkRzHCpPfVgLzYwNGKcXLRJKePnszgfTPGWeRcfQWAagTjtAgMndUhxWAgKHpzqBgvMizyKUnNlntsKRjsHXdXecqllh");

    for (int zrdaQhnRHTPhQwPp = 667078202; zrdaQhnRHTPhQwPp > 0; zrdaQhnRHTPhQwPp--) {
        continue;
    }

    return kPsdtsP;
}

int qnLAvAjMCyKhjQj::SHDKd(string LlSqOLYvShnWz, int YtFhGiMhKCEwbibA, string DYZMl, double fQWQwXTk)
{
    string fLBqlpu = string("VGPsVbzplMnyvrZdNOsVjusDKBrAYdmQkZQbScZYVHjvJAbHCvgtebgMjb");
    double wpdhWJPrtoZ = -18769.007688249156;
    int SJdVS = -2004487259;
    string TKyZhFiEGpCrw = string("gnlmvsjoKVVdVBkLMJrsPwXBBibhdYkPkgHSUyPweURZEF");
    int jzQpNyqgZLJo = -1945536312;
    bool WEtncL = false;

    for (int LyrFG = 1479786291; LyrFG > 0; LyrFG--) {
        LlSqOLYvShnWz = LlSqOLYvShnWz;
        YtFhGiMhKCEwbibA -= SJdVS;
        TKyZhFiEGpCrw = TKyZhFiEGpCrw;
        DYZMl += DYZMl;
    }

    return jzQpNyqgZLJo;
}

void qnLAvAjMCyKhjQj::ZlEEGdGIPcAXTu()
{
    bool njcAKNIiOcwMcZ = false;
    double YgvsPKUJvVoRG = -605059.2624569925;
    double sOKJlqftsMoMbs = 786573.1700025981;
}

bool qnLAvAjMCyKhjQj::IuCaouroF(bool LmPiWQ, bool yMFthWyZcnvlU, double VxsKVZXj)
{
    int nWqKmZiK = -654030716;
    int NHcEzBIndOLqPd = -686800067;
    double VznANN = -658728.8725702842;
    bool SUaUJEgrTBRjjj = true;
    double EFlJjRNOhpRUSNo = 206176.84455664034;
    bool DCanmvnZbX = true;

    for (int lLrMU = 80269960; lLrMU > 0; lLrMU--) {
        VznANN *= VxsKVZXj;
    }

    for (int KVcqAR = 1932684687; KVcqAR > 0; KVcqAR--) {
        SUaUJEgrTBRjjj = ! yMFthWyZcnvlU;
    }

    for (int AVOvOMgl = 1349761603; AVOvOMgl > 0; AVOvOMgl--) {
        yMFthWyZcnvlU = LmPiWQ;
        LmPiWQ = yMFthWyZcnvlU;
        nWqKmZiK += NHcEzBIndOLqPd;
        VxsKVZXj -= VznANN;
        yMFthWyZcnvlU = LmPiWQ;
    }

    if (EFlJjRNOhpRUSNo > -183685.40948095513) {
        for (int AiJFNdLjuSoYi = 2067379208; AiJFNdLjuSoYi > 0; AiJFNdLjuSoYi--) {
            nWqKmZiK /= NHcEzBIndOLqPd;
        }
    }

    return DCanmvnZbX;
}

int qnLAvAjMCyKhjQj::qDtShWYbkHneZVX()
{
    int aMbGrKWWEffAPvnU = 237475840;
    bool OCJXjXyZ = false;
    double ZVHaCe = -218600.55855052927;
    double POkBFkhuE = 876690.9578266128;
    double PxblaxBzoeAFRCGW = -111931.89698934546;
    string nsGVLvcROhG = string("PGxePZffFTcXNEkdLDaLnJnCkiScEKfpXyyeJnOrnLbBcnstAmHvSLvSIxuwDUwVRRLtMHKajgEXjNPuGTjSRiOzvxLnfEtHdzCmfIWIbLopwVjtosKsCWvZGNZaSvgYAhhCNxpHphHSEbaUqyqvVOgRawMbGhNMjYGnXsfrCZYyXfqXVWzXqdlphyzYeuxnipVVHgCVwIXhpNwiJDwnXsOhhXiOabHySjUvSynPW");
    bool SdVhw = true;
    int HKUKGIeMPpg = -1184038140;

    return HKUKGIeMPpg;
}

double qnLAvAjMCyKhjQj::aLztVwqCIeU()
{
    string mwbgQIGix = string("kdnSvqLZHiNtZgFMypWhythvCusCOcjZtK");
    double XPfTDlYYJvFPAJA = 942120.1633581509;

    for (int VhKhWFxhucQfJq = 2042452639; VhKhWFxhucQfJq > 0; VhKhWFxhucQfJq--) {
        mwbgQIGix += mwbgQIGix;
        mwbgQIGix += mwbgQIGix;
        XPfTDlYYJvFPAJA = XPfTDlYYJvFPAJA;
    }

    if (mwbgQIGix == string("kdnSvqLZHiNtZgFMypWhythvCusCOcjZtK")) {
        for (int LJFomIH = 653080831; LJFomIH > 0; LJFomIH--) {
            XPfTDlYYJvFPAJA -= XPfTDlYYJvFPAJA;
        }
    }

    if (mwbgQIGix <= string("kdnSvqLZHiNtZgFMypWhythvCusCOcjZtK")) {
        for (int iuHFfLcRr = 953374647; iuHFfLcRr > 0; iuHFfLcRr--) {
            XPfTDlYYJvFPAJA *= XPfTDlYYJvFPAJA;
            mwbgQIGix = mwbgQIGix;
            XPfTDlYYJvFPAJA -= XPfTDlYYJvFPAJA;
            mwbgQIGix = mwbgQIGix;
            mwbgQIGix = mwbgQIGix;
        }
    }

    if (XPfTDlYYJvFPAJA <= 942120.1633581509) {
        for (int SYXkEylw = 362769526; SYXkEylw > 0; SYXkEylw--) {
            XPfTDlYYJvFPAJA += XPfTDlYYJvFPAJA;
            mwbgQIGix += mwbgQIGix;
        }
    }

    for (int KjzcVBEjX = 1109170709; KjzcVBEjX > 0; KjzcVBEjX--) {
        XPfTDlYYJvFPAJA *= XPfTDlYYJvFPAJA;
        mwbgQIGix = mwbgQIGix;
    }

    for (int rZsEjBjXjoli = 920817989; rZsEjBjXjoli > 0; rZsEjBjXjoli--) {
        XPfTDlYYJvFPAJA += XPfTDlYYJvFPAJA;
        XPfTDlYYJvFPAJA /= XPfTDlYYJvFPAJA;
        XPfTDlYYJvFPAJA -= XPfTDlYYJvFPAJA;
        mwbgQIGix = mwbgQIGix;
        mwbgQIGix = mwbgQIGix;
        mwbgQIGix = mwbgQIGix;
    }

    return XPfTDlYYJvFPAJA;
}

void qnLAvAjMCyKhjQj::bhMFVPfZAipoBMir(bool cjnFMrhXDej, int xByfi)
{
    double wxViEzaPwmCd = -401307.93145579175;
    string llfgpiXkOUxal = string("pJSOeETsofrsTmryynzqUIctzggXqwybujSgUxQPkikjyILMFUMJiuthHdRRwtVYNSFJxcfwxWvqNHoaCSXIWZpbIItZFOgawfcGTlL");
    int vvcmRKmUWqf = -1034018753;
    string uOPQaiOvuBdMDH = string("WFhYIJaaOPNHgXyPEtyyhMuIBmzggVvlbnZsDPpyasrkxyAGPCwKnUXBUxctRnWkSzrQWzDHoxdPtusrfbzRWHRuAzmUtmTYAKdPSvpGZcGJzuqmT");
    bool ckMnS = false;
    bool VhZGYzkhTWCdk = true;

    for (int ZkmtdHRUJblPChAW = 1122202960; ZkmtdHRUJblPChAW > 0; ZkmtdHRUJblPChAW--) {
        uOPQaiOvuBdMDH += llfgpiXkOUxal;
        xByfi = xByfi;
    }

    for (int vzQCIGhMfCmXk = 1946088808; vzQCIGhMfCmXk > 0; vzQCIGhMfCmXk--) {
        vvcmRKmUWqf /= vvcmRKmUWqf;
        ckMnS = ckMnS;
    }

    for (int wtUnBeIoaec = 465136387; wtUnBeIoaec > 0; wtUnBeIoaec--) {
        wxViEzaPwmCd *= wxViEzaPwmCd;
        xByfi -= xByfi;
        cjnFMrhXDej = VhZGYzkhTWCdk;
        VhZGYzkhTWCdk = ckMnS;
        ckMnS = ! ckMnS;
    }

    if (wxViEzaPwmCd != -401307.93145579175) {
        for (int zqdVYOdsXq = 369745571; zqdVYOdsXq > 0; zqdVYOdsXq--) {
            vvcmRKmUWqf *= xByfi;
            uOPQaiOvuBdMDH = llfgpiXkOUxal;
            wxViEzaPwmCd *= wxViEzaPwmCd;
        }
    }

    for (int UFLhWfFLmEP = 41245843; UFLhWfFLmEP > 0; UFLhWfFLmEP--) {
        cjnFMrhXDej = ckMnS;
        cjnFMrhXDej = cjnFMrhXDej;
    }
}

void qnLAvAjMCyKhjQj::hdOjNLlznnLH(string qNzPoY, string ZzpvWpeOXJxhgGsk, string tQRZGIXtIb)
{
    double YsHmpWXoLUJLQFqp = 19577.87082420893;
}

int qnLAvAjMCyKhjQj::DRyJzgFETioTRTq(double ZwdQwb, bool qTItPIaWJfgTB, string DFLnLYSjUPrYpFLZ, double clyGdYzqfWVvBDGT, string pvBSx)
{
    string nLbSondbr = string("UtKvmcQyDGrmFczjdfOYwksHAbjlBvJPXebrNsZzFNLcoKCHItTxsDdgCKrGJhGBtnEMyieSlqQBzBXdVdUfYsYScKxuzdenAvfSmRoNPPbrDrxflxjBfhjVuxlLapkwyMCkrbIXJIxLZtNAiIYKwGgMOliPgvzDod");
    bool UVNJsMrlAE = true;
    int vqXsj = -1824565644;
    string pxANCC = string("yJGwETRrCgeLJMeFnVjNbgVxodzuGVVHCrvDWWUTlZzHmnNfKLJalKtyXJozNWGgkvcNxpqFTdQUxGjdEMHduoGkSmHGeaLcFEQDVyIylEcJARBEaBmntfKVXRffWSlthJODSYAAKgPXuxvlpfChNyGmtRLRaOifwLtqIZkYfGPPOTdvibmxhPsILHuOfxzMRJdTYFBQMbRLNHZIgdrsG");
    bool Gytzuifz = true;
    bool gxrQcLKMttK = true;

    for (int OadRgmxDdOhWNZfk = 1128245651; OadRgmxDdOhWNZfk > 0; OadRgmxDdOhWNZfk--) {
        pvBSx = pvBSx;
        DFLnLYSjUPrYpFLZ += pxANCC;
    }

    if (Gytzuifz != true) {
        for (int gOKOLaCzUOtL = 2113719197; gOKOLaCzUOtL > 0; gOKOLaCzUOtL--) {
            DFLnLYSjUPrYpFLZ += pvBSx;
        }
    }

    for (int FsmGmOfS = 1899660089; FsmGmOfS > 0; FsmGmOfS--) {
        Gytzuifz = qTItPIaWJfgTB;
        gxrQcLKMttK = Gytzuifz;
        pxANCC = DFLnLYSjUPrYpFLZ;
    }

    for (int QyapXGVt = 1285595585; QyapXGVt > 0; QyapXGVt--) {
        gxrQcLKMttK = ! Gytzuifz;
        nLbSondbr += pxANCC;
        Gytzuifz = Gytzuifz;
        nLbSondbr += pxANCC;
    }

    for (int ddFVlBgyy = 1077628422; ddFVlBgyy > 0; ddFVlBgyy--) {
        gxrQcLKMttK = ! UVNJsMrlAE;
    }

    return vqXsj;
}

void qnLAvAjMCyKhjQj::JaDFwhhwiWAxASkH(string EFzvEALWnRdt, int gaayHtOFmtix, int TMKOkcI, string MlyGJU, int OfDAkAHOEoOyl)
{
    int HHrSEpU = 1871213083;
    string hZEJFGcFPTiVB = string("xtnDgijvgLFkzohWwKzjZeNvYNxGSMUosqQaYdsvKdDRmDUJfDXUTmbVI");
    double igYOfq = -935474.6139426404;
}

string qnLAvAjMCyKhjQj::nePCPpKIStSCFh(bool dagFqQQIC, string ajUEInwaFQxjee, double YlTQaJdO)
{
    string RPAhbRQipEtb = string("aQCEhqMcuyKSvVsCBIAqXrOgeFuTFyPogJQNVUzJ");
    bool LaSJeNvrQMRYhimc = true;
    bool VCJkfVEqS = true;
    bool JdmQkMDZsUJIXbgW = false;
    string BiRmLjWydRdrLXNw = string("BPctJJtbkdIBVgbFTptjkZfDMJnfNKLQCBlXAGzFMHecKRAddluRrFjHNIVmTjJBzrvXWOkcUdLFdbAXaJhKcVnfSpgNqPBbEdgQtEzaPrMrANMLlILaaKKRVnCxaEYeyRuGtxrglDSjaWIuyLYnkmtHfloUDezsVetMMLNPXpihVTrKek");

    if (ajUEInwaFQxjee == string("aQCEhqMcuyKSvVsCBIAqXrOgeFuTFyPogJQNVUzJ")) {
        for (int eTSyrFmJys = 2067982059; eTSyrFmJys > 0; eTSyrFmJys--) {
            VCJkfVEqS = ! VCJkfVEqS;
            BiRmLjWydRdrLXNw = RPAhbRQipEtb;
            LaSJeNvrQMRYhimc = ! dagFqQQIC;
        }
    }

    for (int oUsqyNrexlHvtz = 1611823419; oUsqyNrexlHvtz > 0; oUsqyNrexlHvtz--) {
        ajUEInwaFQxjee += RPAhbRQipEtb;
        JdmQkMDZsUJIXbgW = dagFqQQIC;
        dagFqQQIC = ! dagFqQQIC;
    }

    for (int GiUgyUQjcHJSczX = 245247167; GiUgyUQjcHJSczX > 0; GiUgyUQjcHJSczX--) {
        VCJkfVEqS = ! JdmQkMDZsUJIXbgW;
        LaSJeNvrQMRYhimc = ! JdmQkMDZsUJIXbgW;
    }

    if (LaSJeNvrQMRYhimc != false) {
        for (int qjuBzZcXsNhYz = 1825215056; qjuBzZcXsNhYz > 0; qjuBzZcXsNhYz--) {
            JdmQkMDZsUJIXbgW = ! JdmQkMDZsUJIXbgW;
        }
    }

    for (int emhhMXQ = 97219776; emhhMXQ > 0; emhhMXQ--) {
        LaSJeNvrQMRYhimc = dagFqQQIC;
        JdmQkMDZsUJIXbgW = dagFqQQIC;
        ajUEInwaFQxjee = BiRmLjWydRdrLXNw;
        LaSJeNvrQMRYhimc = LaSJeNvrQMRYhimc;
    }

    if (ajUEInwaFQxjee < string("aQCEhqMcuyKSvVsCBIAqXrOgeFuTFyPogJQNVUzJ")) {
        for (int MrLuXzIRw = 65486373; MrLuXzIRw > 0; MrLuXzIRw--) {
            continue;
        }
    }

    return BiRmLjWydRdrLXNw;
}

string qnLAvAjMCyKhjQj::TPXBEtv(string rRLGDNlYjt, int nkPmIZHjG, int umZLks, bool jIlHqVDqgegDw, double vxhjlZ)
{
    int fCfzhZQZpBxa = -1732159204;
    bool IyrTyWyGUCMN = true;
    bool yuMqLBthm = false;
    double TBxviF = -900587.9959304568;
    string ZMKRgHlE = string("hOxGpqOooTRIlgOYNzmXoBAJZVqEfxOfIaRgRPvZozJITdKdhhmOSmNuEDnncymQrgXBQUUBAhgYKRDSJAHoqOSOCVbLqgKynbGnceTTbEZyYNXKfOlWeDgUexecBbtahCMbgsRozYHfJNBFOqFOhpPqnuRvHfbZkvEdsvwPbOkzuEwHADMzKHJnyScEYUhBHrbcAOnyGrBuLICdmDipmofAGXDlof");
    string jYvbrCwGtD = string("QexfDFZUtXyWCuzuZVrZSyptrtQKZAcNmLZxpjsIyQqsYHQycEyirkgWDvjjcimldbUBpTJNBBJoPcFXFKhgIZjOoYTZBQENVGb");

    return jYvbrCwGtD;
}

bool qnLAvAjMCyKhjQj::wKXWyBdYCOLFyOD(string ZmQLralyWICc, int GqqfVQMfevHruqU, double usWkzlnqGjYRTMRg, int TXdqCwndUuw)
{
    double CGIrHOZoffiCH = -431417.95764587703;
    string VfNdMxbPBGs = string("mNtmLSYGIRydDlxgUdtdjsZJawcuYsnBqcdEvtpSPWumSlzcOIMMokLIzCeiUSyfjxLAHCQJKqPnArNAcwmzJoICIKoAEllJYGhtttzXZBYEPWIDbAKpnhVrilNUoFdxUFgrLAAeDKOIGyrpBwGBxEsfZYhNDvPPklvwwdhNByXWzDNGJFgUlYICXVlIGpgxwqSzIumVdRNQcCHqEMPAobSWpzXDVYCqSGF");
    double SuQnzDMF = -521989.6802555052;
    bool aSOjOuWPpVfSEBF = false;
    string jfLnwUgJDCuRLG = string("pPBAXqhdJGkqGqxWogKrmyggokPGUIdELgj");

    if (usWkzlnqGjYRTMRg >= -521989.6802555052) {
        for (int zQlDWhKZgnRE = 184562798; zQlDWhKZgnRE > 0; zQlDWhKZgnRE--) {
            jfLnwUgJDCuRLG += VfNdMxbPBGs;
        }
    }

    for (int lEzpMAVFSfPSR = 974020464; lEzpMAVFSfPSR > 0; lEzpMAVFSfPSR--) {
        SuQnzDMF += CGIrHOZoffiCH;
        usWkzlnqGjYRTMRg /= CGIrHOZoffiCH;
        jfLnwUgJDCuRLG += ZmQLralyWICc;
    }

    for (int looyyBiV = 1382476665; looyyBiV > 0; looyyBiV--) {
        continue;
    }

    for (int reaXpUyzAZfQC = 863689274; reaXpUyzAZfQC > 0; reaXpUyzAZfQC--) {
        jfLnwUgJDCuRLG = jfLnwUgJDCuRLG;
    }

    for (int aHuaqzJAbBRzItdo = 926791791; aHuaqzJAbBRzItdo > 0; aHuaqzJAbBRzItdo--) {
        SuQnzDMF = SuQnzDMF;
        SuQnzDMF /= CGIrHOZoffiCH;
    }

    for (int OcvwVAryGwnmbH = 1015102141; OcvwVAryGwnmbH > 0; OcvwVAryGwnmbH--) {
        GqqfVQMfevHruqU *= TXdqCwndUuw;
        ZmQLralyWICc += ZmQLralyWICc;
    }

    return aSOjOuWPpVfSEBF;
}

qnLAvAjMCyKhjQj::qnLAvAjMCyKhjQj()
{
    this->UChQLRIDKFar(651662.6337041463, false, -127278857, -1229312627);
    this->SHDKd(string("JptUZMaqBzUwufCyGXayElWlqzPXvppyfBRfZNVbKWbitncPyPYASVaSqMtFficSdwEmxKAllDmsWoRpYrDPfTHhHwMvlvBHNrnvNKGoKvRQryau"), 208796991, string("DQpTcXCRyQDWDdFTjx"), 737922.9016160949);
    this->ZlEEGdGIPcAXTu();
    this->IuCaouroF(true, false, -183685.40948095513);
    this->qDtShWYbkHneZVX();
    this->aLztVwqCIeU();
    this->bhMFVPfZAipoBMir(false, -703477192);
    this->hdOjNLlznnLH(string("wKqwQNJydCAZeQRbqlcBiZlXPEZFjFcjJtsRoxAsOstAUOsTXbLnqjZahLzXPAEqflbhMIBChEBeZYQNaiOAuOjtlvBTDxPfAZpodmcsASXdOFLNXYnZoHBeVpmSDrzKtRXzOyYBOHtGuLPgcWYGlosEXEHeFzRXVuj"), string("sUMRoePpO"), string("TgJRGVTwAgzuhaYzUyArNGuTrhvjhZHDIgCPLaAWeDmsJeDqIGLnaHcOafeTfuyhEVERyKyoQJRwKrOODjrZKBqUVxjXcvmFQyZdvlxeCiQkNTwbngGtvyctMpoRilOBppDUjrmPdDxnQfJ"));
    this->DRyJzgFETioTRTq(50532.89534780464, true, string("atxhAqEnTCitMaoEUkkluTqcTRvTtTTTaZcwoigRnTpTysaWKUbjyMkZxkOoCcFigSqxkwyDrGAOPLXgRDaKfpVuPdFBsedRdNLXRsFBCdBuqvCHxbdevYlpcGOmiKVpPaSZfGqedocDGJmnATFEdwpbWrkjBnJKQofrZsYPIWizWbKRWzdHXsQuMzUFrkuoKFwAYHfUfJlbGinJUkVLxtqvmmCLRjmSWdXxEsxSuSQQBoxO"), 587961.6690795564, string("iqdWLpuauDJDfShXPihGGMkFkIjypzhHPffeJfCFNQDknmtXGpVOBJRlZGDFOwmoSjFoWeQL"));
    this->JaDFwhhwiWAxASkH(string("LLK"), -1708660722, -88506533, string("PxSNP"), -1151064544);
    this->nePCPpKIStSCFh(false, string("vDOJiGqFhtzMpbWPKhTciQPnYvrzUElFoDAsSiTYyfjkzKAWQSUfvKBQaQwgVVNSTsiCgMTbCtJUHXTUMPAuZWVExNLCkZfaXxgmMFfTIUYZuULQmKhFZPQoxJSjiMPBSMndUoUWUvokMVpthHJInBGIRstMqUUWLGTpMhoxehTroLRIMcydcDGitFZuOqMwVaZSSEVUMhkMLixEktHMtMyEdJCP"), 252754.842249616);
    this->TPXBEtv(string("GCHLxItqDrHnhSGpvWlCPuKrmiEHMLPGNvrqJYwuvSpGsiEqFsdmHmiAltpsXhAwBtleXjnrDdKQNLXFSwbDUBTCqBICLJYGhAKjNwcebGtHMwUMCmVMssietlbATZGrCzhXLLgIzWXtGJxwDWgwWLoAwVypcCYIGskxIBChKjSu"), 1976724333, -1300378431, true, -836410.2770198635);
    this->wKXWyBdYCOLFyOD(string("wojOirYfAJDAUqRpkdCVZtOEpSvahgqupEnHZVNdPNsEotfbNJJeLrWrbygUPrvBrrdqLOvPxLuqNPKYwiOqnNCSxcRuvDwogwmaLKQBBKRiADRrudjpfTmlnnChiANitJMvlVBKqHLoLNfxEWMXPnuWcJbQgxUdDFsPPZKLbzzZWTbobNgDGRoooSVisrvDCXmDpzuyNLSQMIuhoxzxrZdRsaRqgSTCdWyNwdrWxPIaivXzSSLx"), 1218992473, -638117.1704961379, 2114609737);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ciQsiWrvzOIf
{
public:
    int crdBmig;
    int QxObkuqxtYGy;
    bool IWRJQAsv;

    ciQsiWrvzOIf();
    bool GWjTPsFz(double TwIGWDiMeTlkEUKR, int HINmQBVSaC, bool ZfDGVehqFtjX, double vodVcdyhZZVGkSY, double kAJAtzogkpW);
    string WTrkXgntjJEhAPk(bool QTgozjkWGOnm);
    bool YfAFEushiVG(string nkqtT);
    int YlePcDMobIMy();
    double ZXhbXBLo(double tHxjzs, int QDiRpfuJwQOp, double XSCZRFfVgGi, string zBLXeGbhhsfkPQA);
    void AKNxTdxIangOY();
protected:
    int rmTytAjvRkOjs;

    int YEPZd(int wdLJsDghXgEHtAo, bool KVFSHkJteoEbtrQ);
    double rRBcoTrWf();
    int WbqaEmLqwoDzv(int tyBGbsM);
    void wTwWTL(string kNdilZddhxnQ, bool FAVHKCJaKsLsiSAe, double zhVqCVrxtlG, bool hRWFb);
    int HjkiBnZ(string LTSWv, int UJbjlleauEPGgDae, bool thBPriGoSrcTC, bool HDGgy, double milZtERTdHUvLNt);
private:
    string TtzHzYFIvE;
    double zYfMufdKFKJ;
    double wjlJfFr;
    int huWMSdfOYyT;
    bool MHNenLZbNj;
    int sIXzhSNSrOzNYGP;

};

bool ciQsiWrvzOIf::GWjTPsFz(double TwIGWDiMeTlkEUKR, int HINmQBVSaC, bool ZfDGVehqFtjX, double vodVcdyhZZVGkSY, double kAJAtzogkpW)
{
    bool OISEPmaHXnVqB = true;
    int SOrkQDrAh = 176996721;
    string zdWNgHwjJbk = string("LEiFAeQFwXzHIaqgmYPhaytwIZKdDMHkKKOWDovTNNtrHaeGcHpvnZg");
    int CNZOoHPUEA = -903476970;
    string XibezPiUUXNP = string("tGVkbVLfyMOrsNqxnrMJPLzrDWgzxDumiKEKAxRFGsiFPcWDUpscKHaQALxYTNsljcqzyshcXpHUPcpkFXyyHIYLmYJy");
    bool UliVvJoHy = false;

    for (int WRkCPZkrxaSZf = 548027613; WRkCPZkrxaSZf > 0; WRkCPZkrxaSZf--) {
        continue;
    }

    if (ZfDGVehqFtjX != true) {
        for (int KLxMWILL = 1640722697; KLxMWILL > 0; KLxMWILL--) {
            XibezPiUUXNP = XibezPiUUXNP;
        }
    }

    for (int WDDcKHfDrYdsa = 1853106841; WDDcKHfDrYdsa > 0; WDDcKHfDrYdsa--) {
        continue;
    }

    if (kAJAtzogkpW != 924592.1651433576) {
        for (int TOIHhtwj = 299982154; TOIHhtwj > 0; TOIHhtwj--) {
            zdWNgHwjJbk = zdWNgHwjJbk;
        }
    }

    for (int wzyHEl = 1548329041; wzyHEl > 0; wzyHEl--) {
        TwIGWDiMeTlkEUKR /= kAJAtzogkpW;
        ZfDGVehqFtjX = UliVvJoHy;
        ZfDGVehqFtjX = ! OISEPmaHXnVqB;
    }

    return UliVvJoHy;
}

string ciQsiWrvzOIf::WTrkXgntjJEhAPk(bool QTgozjkWGOnm)
{
    int RkxCx = -539019175;
    int PWWbYCcyrJQX = -1035003819;
    int iPbuSkauOPP = -1610708904;
    bool SJKDkzjNYcOAbKl = false;
    string UoUXqgN = string("UtYyxTIDoUPmaadVBxhLJYtyotijZvEvTSPcWxVNYAYIYQahmqxYYeXVbFYiBtsEqYNNKrZd");
    int MoMWrFhkzpuYbGJ = 772236891;

    if (PWWbYCcyrJQX > -1035003819) {
        for (int ayCFaXKyTosSpqwQ = 1850783811; ayCFaXKyTosSpqwQ > 0; ayCFaXKyTosSpqwQ--) {
            PWWbYCcyrJQX = iPbuSkauOPP;
            RkxCx += MoMWrFhkzpuYbGJ;
        }
    }

    if (UoUXqgN != string("UtYyxTIDoUPmaadVBxhLJYtyotijZvEvTSPcWxVNYAYIYQahmqxYYeXVbFYiBtsEqYNNKrZd")) {
        for (int lhVEFrJCIP = 79054963; lhVEFrJCIP > 0; lhVEFrJCIP--) {
            MoMWrFhkzpuYbGJ = PWWbYCcyrJQX;
        }
    }

    return UoUXqgN;
}

bool ciQsiWrvzOIf::YfAFEushiVG(string nkqtT)
{
    double JtmAN = 939442.7661763697;

    for (int kOlFvK = 110134064; kOlFvK > 0; kOlFvK--) {
        nkqtT = nkqtT;
        JtmAN -= JtmAN;
        JtmAN += JtmAN;
        nkqtT += nkqtT;
    }

    return false;
}

int ciQsiWrvzOIf::YlePcDMobIMy()
{
    string lnZxXjU = string("ultUnQJjTYSpBXLXyLuus");
    int sKvls = 1363935286;
    double uefRyfNAFhPqwG = 386778.2179884575;
    double WuJtdShLhvg = 300169.52330329764;
    string AoUMjW = string("RElyrnuAcFesKRLIGcDspWGqCPJBPyWHqOdPMWOXakPcaFbudViKCgFyMYPWWCJUuPYTaHgloNpvFxtvxIFwgIGYbLQwXcOFot");
    double ytSjVkqvmOPMimg = 804954.5273501044;
    bool iGGhlCsKyKOHXw = false;

    for (int eBIqbRVZDRbt = 102792129; eBIqbRVZDRbt > 0; eBIqbRVZDRbt--) {
        uefRyfNAFhPqwG /= ytSjVkqvmOPMimg;
        ytSjVkqvmOPMimg += ytSjVkqvmOPMimg;
    }

    for (int NtCPEvIN = 522811648; NtCPEvIN > 0; NtCPEvIN--) {
        continue;
    }

    for (int EmCEm = 560985647; EmCEm > 0; EmCEm--) {
        iGGhlCsKyKOHXw = iGGhlCsKyKOHXw;
        AoUMjW = AoUMjW;
        uefRyfNAFhPqwG /= ytSjVkqvmOPMimg;
        iGGhlCsKyKOHXw = ! iGGhlCsKyKOHXw;
    }

    if (ytSjVkqvmOPMimg >= 386778.2179884575) {
        for (int XnTpDTwWvwl = 1276663421; XnTpDTwWvwl > 0; XnTpDTwWvwl--) {
            iGGhlCsKyKOHXw = iGGhlCsKyKOHXw;
            WuJtdShLhvg /= uefRyfNAFhPqwG;
        }
    }

    return sKvls;
}

double ciQsiWrvzOIf::ZXhbXBLo(double tHxjzs, int QDiRpfuJwQOp, double XSCZRFfVgGi, string zBLXeGbhhsfkPQA)
{
    int QXvIC = -776878579;
    int nmUWiLH = 1552232149;
    int WkbEpGlRBZ = 257811936;
    string zGiCorLVQJ = string("DTHlNmemQM");
    bool rWhrWrYVtAACmSVR = true;
    bool EbyYuBrwNR = false;
    bool LuYGouipUb = true;
    int zXkcmtojqVAjqclB = 915515402;

    for (int nGWDzEMvzgDTF = 1783038990; nGWDzEMvzgDTF > 0; nGWDzEMvzgDTF--) {
        nmUWiLH += QDiRpfuJwQOp;
        zXkcmtojqVAjqclB -= WkbEpGlRBZ;
        WkbEpGlRBZ += QDiRpfuJwQOp;
        QXvIC *= QDiRpfuJwQOp;
        rWhrWrYVtAACmSVR = EbyYuBrwNR;
    }

    return XSCZRFfVgGi;
}

void ciQsiWrvzOIf::AKNxTdxIangOY()
{
    int InfMiSvlxKjkxbw = -1250594095;
    double yRMTLrCWWcONI = -86563.50034678107;
    bool SwNbHpIkurubNjl = true;
    string BkZfMOn = string("TVwZRBYUqebVPReBVSQyokAPprAYXVdwLTiSqQKSsAPShjDowqOkAYGcArqtaSaztTcsHVdjrLkLOFDJGDeUwlzrFXZZJIVEXrderjsHFCESOKmdgSnffPZMtmCsDGxLIJpvOvvqFnJkYKGEqeQOtANSOAieySXuAuuIxkUrNrmHdTpADGfkoWgAXmPVzgSHCkfvxCmaTHRpskKDnwbJRgdhYHgiGOEQCpgayxHzYP");
    int lCzsr = 1787821262;
    bool sRfbleIV = false;
    int AFIUMrBuIPr = -540165548;
    bool MUqtFX = true;

    if (SwNbHpIkurubNjl == true) {
        for (int pYZqICziqubBInX = 1106025454; pYZqICziqubBInX > 0; pYZqICziqubBInX--) {
            continue;
        }
    }

    if (lCzsr < -1250594095) {
        for (int WYJJoN = 459871672; WYJJoN > 0; WYJJoN--) {
            continue;
        }
    }
}

int ciQsiWrvzOIf::YEPZd(int wdLJsDghXgEHtAo, bool KVFSHkJteoEbtrQ)
{
    bool XyYBg = false;
    double xbdFQhWbbm = 28468.265491939037;
    double gvLMkBDVkDxve = 412523.043165872;
    double Qlnsqme = -796242.0039855645;
    int ohtyleIivxyzwSv = -630161028;

    for (int ucGbhXZQrecN = 2137111679; ucGbhXZQrecN > 0; ucGbhXZQrecN--) {
        ohtyleIivxyzwSv -= wdLJsDghXgEHtAo;
    }

    for (int myTOWojqXGE = 1806240967; myTOWojqXGE > 0; myTOWojqXGE--) {
        ohtyleIivxyzwSv = wdLJsDghXgEHtAo;
        wdLJsDghXgEHtAo -= wdLJsDghXgEHtAo;
    }

    return ohtyleIivxyzwSv;
}

double ciQsiWrvzOIf::rRBcoTrWf()
{
    int zOZjBBJlV = 137386027;
    string OWaVDYy = string("hQkmevlWxEPdKOlbDEfyBtydIiTVXjDysEmYrPzWtjyTyIqPdsMiusNMcZzrpvRgJZILYzvvUosQkHvbSxNHKLjeRoocIacChdTCVqhjLLouOfhWIzppEQpwjRPbajmvXyNicUdNvtEAMxZXdERVqnspXbzUyOxmkzIpPMquhqX");
    bool sgqxRsEEJcU = false;
    string jgXbsUmIdXTX = string("WUnTVwqpViJZLBSQGTrFKoyMtRVlbKcNtMpIGOlOCfSSrVgpJTGdgdepJokSMKCqQhYdmQBNNxRgCEvYyiaFHrqJRexySDOMBZkCeInhqXWIgKfCu");

    if (jgXbsUmIdXTX != string("hQkmevlWxEPdKOlbDEfyBtydIiTVXjDysEmYrPzWtjyTyIqPdsMiusNMcZzrpvRgJZILYzvvUosQkHvbSxNHKLjeRoocIacChdTCVqhjLLouOfhWIzppEQpwjRPbajmvXyNicUdNvtEAMxZXdERVqnspXbzUyOxmkzIpPMquhqX")) {
        for (int VJFVRd = 530354067; VJFVRd > 0; VJFVRd--) {
            sgqxRsEEJcU = sgqxRsEEJcU;
            zOZjBBJlV *= zOZjBBJlV;
        }
    }

    return -454618.878299508;
}

int ciQsiWrvzOIf::WbqaEmLqwoDzv(int tyBGbsM)
{
    double LBlqBuKQAMNPNsEp = -504872.04603290634;
    bool TwlcpSkHhPEto = true;
    bool raieldR = false;
    double dRXBU = 602811.0320177731;
    int KeCCsZWswCxCmu = 596710557;
    double ICXCr = -785450.7159886344;
    string aziOOCLODV = string("HZTDyUMnekntYXxMUThJnBHEaBjmNbKkokfiWYrZIpspaaWPdXfYOXUDIbaFDHzIOAQyRUpWuNkRmlGVMmtUNpVMpBzkNVHknZypvHH");

    for (int jvvKQYoiZbhHiXDT = 1517511659; jvvKQYoiZbhHiXDT > 0; jvvKQYoiZbhHiXDT--) {
        LBlqBuKQAMNPNsEp -= dRXBU;
        LBlqBuKQAMNPNsEp = ICXCr;
    }

    return KeCCsZWswCxCmu;
}

void ciQsiWrvzOIf::wTwWTL(string kNdilZddhxnQ, bool FAVHKCJaKsLsiSAe, double zhVqCVrxtlG, bool hRWFb)
{
    double HnfoTNtNLjofS = 865750.3595553745;
    string JMFAAallKk = string("lXWDcRLCeJuidRTiFGTLcYULqZOYFBrJlGdyyFyALCjwSiLQucPHnVnOrHeLcFdodmpaWInzTtLUKnWrMXqUOZboGYBtSZKViGYSuEgdfNEjVBAqgPmgDwCIvTCUCAUnwLP");
    int kKWIg = 75747529;
    bool xPqnt = true;
    string ZsQlC = string("tuVLwrNPzOBKCGloWMmZjeoNzENikHZSDshHt");
    bool cDqAyfohVJNCPBQ = false;

    if (FAVHKCJaKsLsiSAe != true) {
        for (int Rrayx = 403994142; Rrayx > 0; Rrayx--) {
            cDqAyfohVJNCPBQ = cDqAyfohVJNCPBQ;
            xPqnt = ! xPqnt;
            ZsQlC += kNdilZddhxnQ;
            hRWFb = ! hRWFb;
        }
    }

    for (int pJIUfFHOGA = 1785415359; pJIUfFHOGA > 0; pJIUfFHOGA--) {
        cDqAyfohVJNCPBQ = cDqAyfohVJNCPBQ;
        FAVHKCJaKsLsiSAe = xPqnt;
        FAVHKCJaKsLsiSAe = hRWFb;
    }

    for (int chsxJmBjp = 1025651404; chsxJmBjp > 0; chsxJmBjp--) {
        hRWFb = cDqAyfohVJNCPBQ;
        kNdilZddhxnQ = kNdilZddhxnQ;
        FAVHKCJaKsLsiSAe = ! xPqnt;
    }

    if (xPqnt != true) {
        for (int mFutFz = 1600833790; mFutFz > 0; mFutFz--) {
            kNdilZddhxnQ += kNdilZddhxnQ;
            ZsQlC += ZsQlC;
        }
    }
}

int ciQsiWrvzOIf::HjkiBnZ(string LTSWv, int UJbjlleauEPGgDae, bool thBPriGoSrcTC, bool HDGgy, double milZtERTdHUvLNt)
{
    double mGQIf = 864206.2830541384;
    int jaQkzOpFNGmRZTqQ = 952965323;
    string ebXBlNXKTTRt = string("U");
    string rCUccbFKCvSjHGF = string("xMXBuOfSsiFkfspMIfmHAUpxXdumHSmmBFhNaAxJGsyAMCIoyRuoPuQfNEurICAlxUmuUZcbuCSQeZMFqFGvIfHIZSfFFFMYhsnhwSNmHaHqmdKoiAVyZCRGzvrrnfGsuiCtDvMQuzxwPHqQeCPrYihqSOFFlTHItcsRrSscpLmPPJUPAUNOcQddRM");

    for (int dueypHzBysb = 2032955911; dueypHzBysb > 0; dueypHzBysb--) {
        jaQkzOpFNGmRZTqQ += UJbjlleauEPGgDae;
        ebXBlNXKTTRt += LTSWv;
    }

    for (int GAUpmzzIV = 178673472; GAUpmzzIV > 0; GAUpmzzIV--) {
        UJbjlleauEPGgDae *= UJbjlleauEPGgDae;
        mGQIf *= mGQIf;
    }

    for (int mYJrp = 1655296719; mYJrp > 0; mYJrp--) {
        rCUccbFKCvSjHGF += rCUccbFKCvSjHGF;
        HDGgy = thBPriGoSrcTC;
        UJbjlleauEPGgDae += jaQkzOpFNGmRZTqQ;
    }

    return jaQkzOpFNGmRZTqQ;
}

ciQsiWrvzOIf::ciQsiWrvzOIf()
{
    this->GWjTPsFz(924592.1651433576, 1375191448, true, 970487.5834047878, -904314.5540326089);
    this->WTrkXgntjJEhAPk(false);
    this->YfAFEushiVG(string("ukdjDZobKxMyUqSiKyXEygmWvjnNPRbfSJGDPdkvzbzxrqlWRxpDyxBMnigXQvGJaNucQeE"));
    this->YlePcDMobIMy();
    this->ZXhbXBLo(830409.8059293263, 1538875282, -596971.4849164251, string("sONJfJxxBtUrlZjePGkBxIXWEMVuMQOPmXEHiXhsLRogSWeJEciPvEwxnFxhCwrevYrHXHGDjgoPqmSMPsoIcoDeOGqxCbbVOnECHJCvoHNSxazplFlMrtecKBbqcZWQLegAeVdESyuncfAcEdVjejeCmLWUKdGMsgnPH"));
    this->AKNxTdxIangOY();
    this->YEPZd(156974378, true);
    this->rRBcoTrWf();
    this->WbqaEmLqwoDzv(-528960146);
    this->wTwWTL(string("vScfIrpxUNjOYqgjvGNbKnEAiMYYdtsCHmCznJUOgYRDmUNAyhRtYhgRjOaLjWBiGNMBQktuBOuAEQRMhfXZwVfLnDveRuOdqvxeMgkvLwBVZqmDYOedxETlJUaBDaQEUyyUthIofBIHvMtwLvHSFZijBGUekmZewTokywqsqVCHtTmvyOIstiKUAQgZrybzCEDHJOAfiJkumfS"), true, -992797.0487506948, true);
    this->HjkiBnZ(string("TEkLvCzsWKWodzWSJCoyCsJjuPoKxXMQcExATSFYKyYSToUyDsdVWgiMnJGyAymcChlNsLefZpDqfEpQzbYnfjthxSCWzRTzfkaVIuPjvMfUJhZKBpYxXsDbnMVhwUdsP"), -699800522, false, false, 557404.949516873);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bmxfKgZbJyjtPxL
{
public:
    string qwEaaFQuaGk;
    bool jwfZPreoSfY;
    double eEyqOFqukkqxOYw;
    int OGfnKxrSSxJufP;
    double NhmKiY;

    bmxfKgZbJyjtPxL();
    bool XHiNelEjrxgXmvJE();
    int nFWmETYu();
    bool othIzLnsSuSWkce();
    int RKdxZEbr();
    bool ZbbSrSbwOcYcq();
    double UIrYzHZLNAgx(int ueagRGBHiavc, string cKbpeHcuUAxgC);
    bool rxWXRYXCJIEcGz(double VjKiCzYHinlqy, double NgKoLOYHVxGdmV, double mLjYSxbq, string fqoPPtWt);
    bool xaBagHkHEvJbTAAa();
protected:
    int FPuBTUHp;
    int SRRBjwCZ;
    string ZsBZbwuKaUKstUMu;
    int QBgdIQd;
    double ODXjFSYMWVlsCLFb;
    bool lAjeJixyPnksGXdW;

    int qUvicbT(int HCqNkN);
    int kuFcLTfyKklsvmzC(double uBNzFK, string OJXkXOC, int AEKHOSzIxMv, double WPrDekLtTTqoS, bool JmTuxMTJOQsYT);
private:
    int pYpMlmecjPfvx;

    string hRueiedOZvtQsjM(bool NCbrHKYlEEl, string nMDQUS);
    string WYUzegVZ(int iBlkXQokAdPmdij, int fIzBEZAcBWuPrT, double KpDnwUiol, double YXvUzvbJP);
    void nAZLSg(double CgWCD, int fZDGUJnmUFh, string swTHsvbgVTrPZ, int vZxoIhgxGyLCua, double gNSznJsOOSAgoDi);
};

bool bmxfKgZbJyjtPxL::XHiNelEjrxgXmvJE()
{
    string aOFesqepfThCkJB = string("VbNOVwZFmCUgLQErQRxprVcqAKepdcQwoDXeKburhBbmbEYlYljsyMtuveYOEmfNZLCoChcywSZSeHQCKeXLVYBiAgJIYZbOb");
    int cemzLDLgkb = 2040419510;
    int HPKrnGnixgI = 1749244437;
    bool nMLyzuxVmeWNOU = false;

    if (aOFesqepfThCkJB <= string("VbNOVwZFmCUgLQErQRxprVcqAKepdcQwoDXeKburhBbmbEYlYljsyMtuveYOEmfNZLCoChcywSZSeHQCKeXLVYBiAgJIYZbOb")) {
        for (int MyzgZ = 22023336; MyzgZ > 0; MyzgZ--) {
            HPKrnGnixgI *= HPKrnGnixgI;
        }
    }

    return nMLyzuxVmeWNOU;
}

int bmxfKgZbJyjtPxL::nFWmETYu()
{
    string akFVZGgHVm = string("gmUGuretudtCynHwMJeMUTvqetlyWtqSBgQuTSXbRbgfosNVORsnevCiztJvpLoDxNGrlfNCYLpEvVZrjrEVnaccgybWqsaUGDgYpwWcihZmWTNYFSWoaPNwdFjRpKksUtBXZcrFwuXgRZUSPIAEKrGEINFoMlQrOTpPNiZPowgTfoPDiSMrlabVPbZJmuVxIbqeuQLxDLLVMipKDuJKkPTPcUsRdsHC");
    int puTNwK = -278330491;
    int eeDVdoBkmaFljydV = -972320472;
    bool KyGwkHx = false;
    double EdHkrdtVMcyUwo = -769604.4292733799;
    string eQdCqEoLZnFU = string("rqxFHcsINfKdzogoSMjNVmwJSWhhpTfBdWhOBUOfilbznenaJujNZpiLjwRgoZQKdomiPoIeTgKslEKgqliXfMhvDcDfNIuOUWHlOGOebYhNIpyeYZUQgDzqhRKsNGHZKVvbkBnarcKGuOTjSfuuYFBUASvEZkMaNIXhKFggsQdDlbuAMSHaDcMPteSTVScfqwLwYxSZgAZvBuXOiNNYmuUj");

    return eeDVdoBkmaFljydV;
}

bool bmxfKgZbJyjtPxL::othIzLnsSuSWkce()
{
    string rEXNUzHyR = string("bXuCrFZlDfIUdqkIMsZUQtlLRTvJMHgLokvePmUCCzvlFNbBlDGBHBJoMXZFbwUkXtDlTuXvVvcIjBPydUQEjUIHZlQYYJTNNOdjLtin");
    int beUteNjsuHaaR = -1285186382;
    double XlOniRusuKxmwqm = -641263.9882967101;
    double CJEqNaPQcLj = -250679.76639833045;
    double OsEiGpuRvKz = -473048.6223472317;
    double gVeHfl = -352051.7655979804;
    string XqgpbSB = string("hoNcSfamdotfLdtImdyYjiSHmtssUQujzAyugueKyQbRhurgWUHabtntnBcqVNgDrAriwUFlwbLrZPAzoadGfAiZFflTbtgPnmScIfgFLLVhFlMrZwMEcZqjjXELDhNOvQotgfhHpSFXZdHQphleAFzIlCgjapsclBkmSfUIoUuBwCkzaSTLtRJuwYtaIEmERMpmncSalioRSAXDbDzPbN");
    string ydoqlgCxgsNf = string("ekMeCUyBlkLywwpLIUyAQhHqbgFsYEdTnyIWaGZXPzUWRARXZzrYdckabKlbSPSwqDAXgRdRBHyWjoKxetQkIrOxEjsNSXlzCSWtBidbYemCXXOyIlyxfxvOVePhQEEymeGOulKcUncjvbvAQSrQfHkQtyyKeXkuTwGYv");

    if (CJEqNaPQcLj <= -250679.76639833045) {
        for (int cVAbxUESgX = 1762650667; cVAbxUESgX > 0; cVAbxUESgX--) {
            OsEiGpuRvKz += CJEqNaPQcLj;
        }
    }

    return true;
}

int bmxfKgZbJyjtPxL::RKdxZEbr()
{
    int BTOOHYRdvW = 332544800;
    double PGMNuIlIfUn = -178193.87506158493;
    string gAUZtku = string("TMlYjkfShHdFDknunqqpGtGJl");
    string lZEHdidL = string("RmdZKPnmMGYRqhztIcWlKmCCIqEpYkPlufWfdJKSceByebIkAnOOedFKNB");
    int LDnQOKdD = 811333151;
    int SDUzypwmGHPcY = 1023289797;

    if (LDnQOKdD == 1023289797) {
        for (int imcxqSxIN = 1508518891; imcxqSxIN > 0; imcxqSxIN--) {
            continue;
        }
    }

    return SDUzypwmGHPcY;
}

bool bmxfKgZbJyjtPxL::ZbbSrSbwOcYcq()
{
    double SLTJf = 558586.1795911873;

    if (SLTJf == 558586.1795911873) {
        for (int BDlroKGBsrrmtD = 1109862089; BDlroKGBsrrmtD > 0; BDlroKGBsrrmtD--) {
            SLTJf *= SLTJf;
            SLTJf -= SLTJf;
            SLTJf *= SLTJf;
        }
    }

    if (SLTJf >= 558586.1795911873) {
        for (int DCyXoAWnMYBQQPV = 975596810; DCyXoAWnMYBQQPV > 0; DCyXoAWnMYBQQPV--) {
            SLTJf = SLTJf;
            SLTJf *= SLTJf;
            SLTJf /= SLTJf;
            SLTJf += SLTJf;
            SLTJf /= SLTJf;
        }
    }

    return false;
}

double bmxfKgZbJyjtPxL::UIrYzHZLNAgx(int ueagRGBHiavc, string cKbpeHcuUAxgC)
{
    int dOwJNaprbGGwwL = 797414696;
    double YwfuN = -933259.8874303397;
    string VfGkyGz = string("xPNKuSBpaIJDEQZhCoVGVWCaofZTHrsBCOKVTIvAueRmXtFWenSWhxISHRGZOQzfQdJvtqAWqbZZnEwMacjdUYxVisoOpNszhDuJYlqSkPOUoGn");
    string SNGQEDsa = string("HWIadYzyTQTEPZJHdCEQfrfJVIyKEVzOiMkKSIEyrlpdqjUsLdTDsRtlUGWUjAoONqmcRwFxWbNnKjNgVvGHACeIzWMPbQSjkwOlNIsANgwjvObRGVH");
    bool LEnfdh = true;
    string yqbyfFKOsRnlhNZR = string("LfLAJyWWVGJLLqdNlZeWBuKYFtEuLpSROpRbnrWPJlvlQjjUDpwYgrCmlVizqkIEODGXlYJKsuXRjhOMONEPbjdZWUyDpOBvzDWRQVQPDzBWgxNdQDwDtDOYvOrOEdpBGBOOBNbYhpHiRgnponzRNtYMeZOVVmNuPisCyhqTUdkUlNETvgCSfSbOyLuSRhjAWHsbVRyDVnqZywRwKdjDtv");
    bool pfoyzdrxpLY = true;

    for (int RdClxwvjydzNJN = 992054272; RdClxwvjydzNJN > 0; RdClxwvjydzNJN--) {
        dOwJNaprbGGwwL += dOwJNaprbGGwwL;
        dOwJNaprbGGwwL /= ueagRGBHiavc;
        cKbpeHcuUAxgC = cKbpeHcuUAxgC;
    }

    for (int LvCrRsqfTG = 943786863; LvCrRsqfTG > 0; LvCrRsqfTG--) {
        VfGkyGz = cKbpeHcuUAxgC;
        SNGQEDsa = VfGkyGz;
        LEnfdh = ! pfoyzdrxpLY;
    }

    for (int TugyC = 1539011763; TugyC > 0; TugyC--) {
        cKbpeHcuUAxgC = yqbyfFKOsRnlhNZR;
    }

    return YwfuN;
}

bool bmxfKgZbJyjtPxL::rxWXRYXCJIEcGz(double VjKiCzYHinlqy, double NgKoLOYHVxGdmV, double mLjYSxbq, string fqoPPtWt)
{
    int djGyBypDV = -1692338500;
    bool dzERlchEhhNGgIr = false;
    double rBhmngGggBUVVxI = 333352.8220977581;
    int YfwooiClvL = 957160614;
    double RsskKlka = 143273.23915353607;
    double gvswbM = 415421.2800097457;
    string SHvkXtTaz = string("oZDxgLcvLhMGPUqjUXgQmLhCltEqrpTgpnmWwiWKjnhXVvTLUuQomgAcxIvSJsvhvMkKbFieFIXlkmejtcvPUeEChmSAXIJS");
    string jbzOYC = string("LoWZCneguoloRcpYFqkfgyuQuBULQaaFXDzCGEaQDqFKccNppNxbyEfoTSKRObxapuVKOXQhJyIgEWqZyTMOSaaZQdhYPofuXOyBqeGByaenSlJCzwhDGHosyVPEqRlXnBRrxpOooJaUAbWZVGPccVQwAPuplBPFeslEuUOOSVopSfhsILwqchYBmkfhKZRRdbVBHmKWuIChPNAszgXQHeuxAVNjjT");
    double qizbXAtPeBazeL = 546523.6327376704;
    int pANiIRY = 186875849;

    for (int gUItgvBuy = 372722459; gUItgvBuy > 0; gUItgvBuy--) {
        continue;
    }

    for (int XuRbvANQ = 1795946111; XuRbvANQ > 0; XuRbvANQ--) {
        VjKiCzYHinlqy -= qizbXAtPeBazeL;
    }

    for (int cNTafcN = 940128275; cNTafcN > 0; cNTafcN--) {
        NgKoLOYHVxGdmV -= NgKoLOYHVxGdmV;
        NgKoLOYHVxGdmV += mLjYSxbq;
        rBhmngGggBUVVxI *= gvswbM;
        rBhmngGggBUVVxI -= NgKoLOYHVxGdmV;
    }

    for (int ysWSanZCUmMM = 914789944; ysWSanZCUmMM > 0; ysWSanZCUmMM--) {
        mLjYSxbq += mLjYSxbq;
        NgKoLOYHVxGdmV = NgKoLOYHVxGdmV;
    }

    return dzERlchEhhNGgIr;
}

bool bmxfKgZbJyjtPxL::xaBagHkHEvJbTAAa()
{
    int RknOfqyJlgZF = -623375132;
    double xxnLpgufNkP = -1040869.4009359283;
    double UVqidfmKJbvMubo = 386103.46777533175;

    if (UVqidfmKJbvMubo < 386103.46777533175) {
        for (int TkaWnnXeMH = 1376426471; TkaWnnXeMH > 0; TkaWnnXeMH--) {
            RknOfqyJlgZF += RknOfqyJlgZF;
            RknOfqyJlgZF = RknOfqyJlgZF;
            UVqidfmKJbvMubo = xxnLpgufNkP;
        }
    }

    for (int gEHgg = 2067690370; gEHgg > 0; gEHgg--) {
        UVqidfmKJbvMubo = xxnLpgufNkP;
        RknOfqyJlgZF *= RknOfqyJlgZF;
        xxnLpgufNkP -= UVqidfmKJbvMubo;
    }

    for (int XancLEJ = 1478281907; XancLEJ > 0; XancLEJ--) {
        continue;
    }

    for (int FJCijqbJmv = 1370749469; FJCijqbJmv > 0; FJCijqbJmv--) {
        RknOfqyJlgZF = RknOfqyJlgZF;
        UVqidfmKJbvMubo /= UVqidfmKJbvMubo;
        UVqidfmKJbvMubo /= UVqidfmKJbvMubo;
    }

    for (int czjvRxECH = 1112953425; czjvRxECH > 0; czjvRxECH--) {
        UVqidfmKJbvMubo = xxnLpgufNkP;
        xxnLpgufNkP += xxnLpgufNkP;
        UVqidfmKJbvMubo *= xxnLpgufNkP;
        xxnLpgufNkP *= xxnLpgufNkP;
    }

    for (int BsdZYVcvN = 1416988395; BsdZYVcvN > 0; BsdZYVcvN--) {
        xxnLpgufNkP = UVqidfmKJbvMubo;
        xxnLpgufNkP -= UVqidfmKJbvMubo;
        xxnLpgufNkP = xxnLpgufNkP;
        xxnLpgufNkP *= UVqidfmKJbvMubo;
        UVqidfmKJbvMubo += xxnLpgufNkP;
    }

    return true;
}

int bmxfKgZbJyjtPxL::qUvicbT(int HCqNkN)
{
    bool LsiOedjeIObnKhla = false;
    bool kGRDjqty = false;
    bool Pttlal = true;
    int VuyHPAgl = -1783549640;

    for (int FLIhjJZt = 1695805905; FLIhjJZt > 0; FLIhjJZt--) {
        kGRDjqty = ! LsiOedjeIObnKhla;
    }

    for (int fSAQaKWBmHBaUv = 627549547; fSAQaKWBmHBaUv > 0; fSAQaKWBmHBaUv--) {
        LsiOedjeIObnKhla = ! LsiOedjeIObnKhla;
        kGRDjqty = ! LsiOedjeIObnKhla;
        VuyHPAgl *= HCqNkN;
        HCqNkN += VuyHPAgl;
    }

    for (int rbjfQkK = 1413668416; rbjfQkK > 0; rbjfQkK--) {
        continue;
    }

    for (int KHbla = 480022531; KHbla > 0; KHbla--) {
        kGRDjqty = LsiOedjeIObnKhla;
        VuyHPAgl *= HCqNkN;
        LsiOedjeIObnKhla = ! Pttlal;
        LsiOedjeIObnKhla = Pttlal;
    }

    for (int UsjUHboBbbrAzQSg = 1327276672; UsjUHboBbbrAzQSg > 0; UsjUHboBbbrAzQSg--) {
        Pttlal = ! kGRDjqty;
        kGRDjqty = kGRDjqty;
    }

    return VuyHPAgl;
}

int bmxfKgZbJyjtPxL::kuFcLTfyKklsvmzC(double uBNzFK, string OJXkXOC, int AEKHOSzIxMv, double WPrDekLtTTqoS, bool JmTuxMTJOQsYT)
{
    bool ZnDIUa = false;
    int CPgmlbzcNwSf = -877608983;
    double hDMajS = 244995.1111963492;
    string YsMuYVqLKd = string("irTMfPqnOvfGPHOEjXpSwkRNhtpmthIQWBgGwuFNyfVIifXeNNydEAlpdoygu");
    double JqBYDaSYphKBuR = -71814.8894853971;
    string hewUOabLE = string("ZHbSPHlneUCDSeEWLvXrUqMHzyhQLYPMMTWfniGIgZQShwufTmvzihamaWeploKFturtldKtKCDqBtXnvXuOVkqRgVxkkHxfgDaZbhGZqPcUxvmDZNStStJCokclqJoMGCjLQCnbXcJVFTtznnKszmUoqNTCeVSKNaOiWYCLLZsZhpVXjTILlAfksRHHhsuoyUuHhlRkgePQVDLpAzrQEqxa");
    string sTjrWiCk = string("tcImXmVDURmLSQWRvAksvkKQMnruDRUDIROJsZGXHeWrOGLniiSiQpAZaoMWLo");
    string nIuoaTVAm = string("EizFkJvdDEsxgdXYWEbwfmNHcREEtEAHqChHXeXuWwBwpmXGujUrfCtfcCXxeWT");
    string VXkPRtbzFIUd = string("DyBLUKaLEwZmaazyJvohpLNoauUYzOwjWlVkqYIrcvITfUTkLAeICnvuah");
    string zEQtGOwcyK = string("ItdKtRHazGvXjeMUzChSMRZzuUaRhoIuEqeurNSRbsIaWsgAwBplVRUpBgiVYLAdpWKwDKoLDCPvMQEEQYQPHaJdSEaCSqdfuCPOPBtcteujJPDZcPXTrbcdmRtxkISMupTOeOYSFJtgDIXyKubMHKHlPXYgAkPUUHmlceiUNZGDiTwDKNLzJXgqAXtbYuPfyoDEAgygnPrOOfKkazdicCDEfFbOlggsbdsMdqYBEBP");

    for (int jLcGFXlxrsAnQh = 1044257463; jLcGFXlxrsAnQh > 0; jLcGFXlxrsAnQh--) {
        VXkPRtbzFIUd = OJXkXOC;
        YsMuYVqLKd += YsMuYVqLKd;
        sTjrWiCk += sTjrWiCk;
    }

    for (int CWGKiQphGzm = 1723675082; CWGKiQphGzm > 0; CWGKiQphGzm--) {
        YsMuYVqLKd = YsMuYVqLKd;
        nIuoaTVAm += hewUOabLE;
        uBNzFK = uBNzFK;
    }

    for (int wAVlmcOp = 298061304; wAVlmcOp > 0; wAVlmcOp--) {
        OJXkXOC += zEQtGOwcyK;
        zEQtGOwcyK = YsMuYVqLKd;
    }

    for (int TShQhzE = 742232129; TShQhzE > 0; TShQhzE--) {
        YsMuYVqLKd += hewUOabLE;
        VXkPRtbzFIUd = sTjrWiCk;
        VXkPRtbzFIUd += zEQtGOwcyK;
        hewUOabLE = OJXkXOC;
    }

    if (nIuoaTVAm != string("ItdKtRHazGvXjeMUzChSMRZzuUaRhoIuEqeurNSRbsIaWsgAwBplVRUpBgiVYLAdpWKwDKoLDCPvMQEEQYQPHaJdSEaCSqdfuCPOPBtcteujJPDZcPXTrbcdmRtxkISMupTOeOYSFJtgDIXyKubMHKHlPXYgAkPUUHmlceiUNZGDiTwDKNLzJXgqAXtbYuPfyoDEAgygnPrOOfKkazdicCDEfFbOlggsbdsMdqYBEBP")) {
        for (int NBAhbnQRVBbDs = 693042722; NBAhbnQRVBbDs > 0; NBAhbnQRVBbDs--) {
            sTjrWiCk = VXkPRtbzFIUd;
        }
    }

    return CPgmlbzcNwSf;
}

string bmxfKgZbJyjtPxL::hRueiedOZvtQsjM(bool NCbrHKYlEEl, string nMDQUS)
{
    bool ZdtoffCNXIalrLcy = true;
    string MhZQMqijcsOljT = string("PIWygDvrSLQiUGifeCmsuTKinjUdsoYPBAuwmOrzOJToZvIyKRpUeCiPHDblLMmNsxmmaFpnumWQUnzFPsbbgxEtayIdigNPUUYIaAdbuvYVlgTgsLuotQTcZyypRfeWMKoqBVpZeunOpqpZxXQIhcNJIeU");
    int zVTwqWtjBdyS = -372093602;
    bool fahiCayTaUy = true;
    int ePPoDLHgGKoR = 1460469214;
    double RFRNuqkLay = 858150.1961133279;

    for (int ekUUTSzsQ = 597668736; ekUUTSzsQ > 0; ekUUTSzsQ--) {
        MhZQMqijcsOljT = nMDQUS;
    }

    return MhZQMqijcsOljT;
}

string bmxfKgZbJyjtPxL::WYUzegVZ(int iBlkXQokAdPmdij, int fIzBEZAcBWuPrT, double KpDnwUiol, double YXvUzvbJP)
{
    double XlUQEW = -821575.8994263124;
    int DmGjYjQJwp = -1299967568;
    double dDBPDmOatpvpaHM = 360560.98142317095;

    if (YXvUzvbJP < 1026643.0569065594) {
        for (int UzlNuRmjojrDHy = 1218161105; UzlNuRmjojrDHy > 0; UzlNuRmjojrDHy--) {
            KpDnwUiol += YXvUzvbJP;
            XlUQEW /= dDBPDmOatpvpaHM;
        }
    }

    if (dDBPDmOatpvpaHM < 360560.98142317095) {
        for (int szxEes = 914760352; szxEes > 0; szxEes--) {
            fIzBEZAcBWuPrT *= iBlkXQokAdPmdij;
            KpDnwUiol *= dDBPDmOatpvpaHM;
            dDBPDmOatpvpaHM -= dDBPDmOatpvpaHM;
        }
    }

    return string("hawcfGnDdEcvxKIw");
}

void bmxfKgZbJyjtPxL::nAZLSg(double CgWCD, int fZDGUJnmUFh, string swTHsvbgVTrPZ, int vZxoIhgxGyLCua, double gNSznJsOOSAgoDi)
{
    double QIYRLjBEFeTWZi = 70031.93103279131;
    int NVFbWu = -842458343;
    double JzWEmNUMh = -772506.1099972634;
    int lNrabicCqIl = -161767047;
    int BuRGMsHNmlNYASo = -924042989;
    int FbenoqjPGg = 1326477088;
    int ZfgJqLIoMTiDMR = -1765871222;
    string GbWluCRvMk = string("FfpVoBhallmMenrMaXrDcafLnMFdu");
    bool bIDXdU = false;

    for (int gQVHGvDlnFz = 2030313567; gQVHGvDlnFz > 0; gQVHGvDlnFz--) {
        BuRGMsHNmlNYASo += NVFbWu;
    }

    for (int xlBYf = 1535900909; xlBYf > 0; xlBYf--) {
        vZxoIhgxGyLCua = lNrabicCqIl;
        CgWCD -= CgWCD;
    }

    for (int rTmHcuT = 1559918585; rTmHcuT > 0; rTmHcuT--) {
        NVFbWu /= ZfgJqLIoMTiDMR;
        lNrabicCqIl *= FbenoqjPGg;
        ZfgJqLIoMTiDMR += lNrabicCqIl;
        fZDGUJnmUFh = fZDGUJnmUFh;
        FbenoqjPGg = BuRGMsHNmlNYASo;
    }

    for (int TYZVtzdmQQ = 926118187; TYZVtzdmQQ > 0; TYZVtzdmQQ--) {
        bIDXdU = bIDXdU;
        NVFbWu /= fZDGUJnmUFh;
        vZxoIhgxGyLCua /= NVFbWu;
        ZfgJqLIoMTiDMR -= fZDGUJnmUFh;
    }

    for (int McJDK = 1091162943; McJDK > 0; McJDK--) {
        fZDGUJnmUFh += fZDGUJnmUFh;
    }
}

bmxfKgZbJyjtPxL::bmxfKgZbJyjtPxL()
{
    this->XHiNelEjrxgXmvJE();
    this->nFWmETYu();
    this->othIzLnsSuSWkce();
    this->RKdxZEbr();
    this->ZbbSrSbwOcYcq();
    this->UIrYzHZLNAgx(-753482975, string("IGlrXzfKeUfbMkqLyzsKuerhYCsEvOTsFcsGemMyXoYMTUEQxEJgRSeakDusdJSLAhMiuReNbpbrwESlISHvaQuLyzoaxJUrkUZENnGeriDleHMsOVRvvkDCLCNVZpRKadgFTlAeJfJnhMYuncPSqozGZwMpxwCKJezLAHYtDGWnMHsAPwdUMFIcKjiFinlamIgVSX"));
    this->rxWXRYXCJIEcGz(-702131.2985810969, 55315.19970566507, -975428.6036150297, string("TGma"));
    this->xaBagHkHEvJbTAAa();
    this->qUvicbT(924024863);
    this->kuFcLTfyKklsvmzC(-214510.67495998603, string("wJKkFMXEZKpXgFNoXfmUhXNeVgyQoDwfIRdkpkOUNBanMpdAZSpKeFyoCDLKmTpwSpaxUXMyRximbLpXgAzzOgzuhfHetvIxtDuYoTtuwWhokzGKPsUrItsjPxKSxUMbZjY"), 2098689334, -802017.627144289, false);
    this->hRueiedOZvtQsjM(false, string("etNcZIQacOFjsFeblbYzXWmMmHiAqMlYoNZaRqkNwvAubUhDnUoXWIGMrvuvyWgcIabDznZvCCPrQuWehIQLlgpDPvgBNvikAAWFnaKylVkMDnUAraiOvTMfz"));
    this->WYUzegVZ(1289099818, -227516226, -605479.9427334723, 1026643.0569065594);
    this->nAZLSg(-3168.9498186438327, 326231688, string("VmLdEMsrNfMSCwrKVlAqEYeFMHpaTsFQpziwiDadCWsHYHkxEppltIlDWxoxOMNBxMEHDaNQCSJoXPmaQLpPLPUCMNszdpHXIenXwiVKvvQZelNRMEfYhZFKBbEZgrKmxdiPWXoRPupKFrHiAzSzeXDVHuvjJlKfuSQRDuucUpi"), 1085793056, -507090.618810263);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class snCEnqrYLAbUBB
{
public:
    string gikNaRm;
    bool lqTNNZZheanm;
    int KNZRmMuhO;

    snCEnqrYLAbUBB();
    bool qxEIwZSOfpnQq(int pCcCiDgGltR, bool rvkpuKMT, double SvaziR);
protected:
    double OFzqPMcqJAop;

    void OgolfZbfRFn(double tfrghwF, int YiVuW);
    double nGqGeXz(int YfoIbSz, bool MIZPDBEdJG, bool ISHIcXduVSsvObuE);
    string mWjePSrpztWwrVKw(string zbHsKPSoxkUgrvKX, string eDzvdzgEvY);
    int gWAEDPvZbeTf();
    string VrlrCxQitnvsrJG();
    int QSDlojxuEgYjZhq(double BQuTm, int OyVkP, int EvfDBKMagTToGPlf, double wbQmJUyve);
    bool zndcBQGse(string nvAkcODFNGG, double GlNatZpzHRkw, bool RrSJHBzXuzlmmeu);
private:
    string gWZlepOsc;
    string stybd;
    int TKGwYmfVlBYOMtyX;
    double KZPfEcarBNQM;
    double bWpuHyErZ;
    bool BEapEQbzbBCWYP;

    void uDkmEvRUbE(int HIAnazyW);
    string BlSdueDiDxE(bool jfvWDmOVr);
    void qaYuGJaO(int iuLQgA);
    string HnOoQCNJz(string ULXfcW, double VaVfGVcmUFcC, int daWjAIaIRen, int qsjhhrHTQ, int EsXSzyNuJQkkICsi);
    int HfKiSAd();
};

bool snCEnqrYLAbUBB::qxEIwZSOfpnQq(int pCcCiDgGltR, bool rvkpuKMT, double SvaziR)
{
    int OVrTgCNvuvyoXK = 1398021786;

    if (OVrTgCNvuvyoXK != 1398021786) {
        for (int YWJjMwabgiMUAVC = 1735933491; YWJjMwabgiMUAVC > 0; YWJjMwabgiMUAVC--) {
            SvaziR += SvaziR;
            SvaziR /= SvaziR;
        }
    }

    return rvkpuKMT;
}

void snCEnqrYLAbUBB::OgolfZbfRFn(double tfrghwF, int YiVuW)
{
    string NaqjdaOs = string("hjPeBFXJcVIEyUewwXqMQBBpzLhBdAINrtaUVCQkzMJj");
    int MLPiyWa = -1831053320;
    bool ivoNqueWlMkTKHmp = false;
    bool psromDDWMlSi = false;
    int veXwRvZaSwimjZxg = 1604553639;
    int jOvRCkIi = 1877543611;
    double DDVuMeGQRBWsJ = 600767.3041196148;
    bool xzpIgFpWuLhsCsj = true;

    for (int ElrNCiQOg = 1075114229; ElrNCiQOg > 0; ElrNCiQOg--) {
        continue;
    }
}

double snCEnqrYLAbUBB::nGqGeXz(int YfoIbSz, bool MIZPDBEdJG, bool ISHIcXduVSsvObuE)
{
    bool irLJitLurbrg = true;
    int stzrDRbSNKVm = -1510763585;
    int BgDdmLVlcRGUa = -1871149547;
    double VLEnguCw = -822564.2736565401;
    double zDkzrcTlo = 456384.35547015525;
    bool VLSAdCDseeW = true;
    double EnOPbINTfNZ = -903886.5052592169;
    int SdMUVKFnppjvn = -14497605;
    double XREhubBJNxNxYQMS = 231767.40280235728;

    return XREhubBJNxNxYQMS;
}

string snCEnqrYLAbUBB::mWjePSrpztWwrVKw(string zbHsKPSoxkUgrvKX, string eDzvdzgEvY)
{
    bool RoFuaGEvK = true;
    double UJwGu = 1009810.4381028083;
    int YRbJwPRw = -2036393644;
    bool xezwJQFg = false;

    for (int Idrttth = 911437796; Idrttth > 0; Idrttth--) {
        continue;
    }

    return eDzvdzgEvY;
}

int snCEnqrYLAbUBB::gWAEDPvZbeTf()
{
    string FXCgScDwvC = string("MjWEfxBodGJwtLinaADTdYOiIyZSUoPbkXbnJNBaZsK");
    string FQBvheOQRw = string("CssuLViKawtBBCKXCElpheLAgXumxaIHxKpSupsmwKVYvnQmYkcfUadWtcGlDTzAthKbNNKFVHMIbWbuyPQffmIuNipWHGUyutoylckmNcRFMYDTgAwBVJYkqbNekTbeekyUpzXDzICeLONMWFqxhWPhuzzvjxRSUqefijHOGocCFeGzmwLNfIgnYejbcTFJgZYtnveEsZUAkZWszRycsDOkatCgHxWtBuIelbhkajWC");
    int MOpJXLbXhWczXPmc = 1163284518;
    bool prBiLTpc = true;

    for (int QNZDWGd = 1373939105; QNZDWGd > 0; QNZDWGd--) {
        MOpJXLbXhWczXPmc += MOpJXLbXhWczXPmc;
    }

    return MOpJXLbXhWczXPmc;
}

string snCEnqrYLAbUBB::VrlrCxQitnvsrJG()
{
    double jPiUnQPYcYGJf = 737540.0973707652;
    bool tGWoTm = false;

    for (int AGHOZNZC = 953084535; AGHOZNZC > 0; AGHOZNZC--) {
        jPiUnQPYcYGJf -= jPiUnQPYcYGJf;
        tGWoTm = ! tGWoTm;
    }

    for (int PgYmR = 1855856695; PgYmR > 0; PgYmR--) {
        tGWoTm = ! tGWoTm;
    }

    return string("MmsKxrKtDaQZFMsIFuvuAQXhQCuBbELjlrZIbDHASrqMLtpRwyyIlEEEFWwElgCTkwwUISz");
}

int snCEnqrYLAbUBB::QSDlojxuEgYjZhq(double BQuTm, int OyVkP, int EvfDBKMagTToGPlf, double wbQmJUyve)
{
    int FXGVbHSR = -108201696;
    bool LSkVkWYWRend = false;
    double JWnouNcJaU = 684127.580405634;
    double iJwDuHnnIbPjbDqb = 408241.1508654702;
    string iqBrEPsJDXgE = string("GhKlzQTeIMGIYxkfRrIRyOdNztTZuXYmIEyvLHmQFWcfKJpwylQkMYauJxSsysgMIWyzDEWDqeQDQucJtKqIzodAolEBIzLBKSepJPHMSauoxRdoYqUKzkiqiPoExdEKhwNCvtqJkWFSivHuIGnXVyZLBrMvWnLLmALRrqsNzSgiHxatcCpCWZVLHNmjYZTQQjTYABrwntDaIrRCkeOEdsrqHBhGMmjwSB");
    bool WnJMwEzTAYwd = true;
    double ngdjWcZrJrmb = 473494.4769969176;
    int oIYXJ = -982130351;
    int uGnbfHQQ = 806977754;
    bool OxNNUir = false;

    if (wbQmJUyve >= 964620.4242845157) {
        for (int xalANgkucskfx = 440509424; xalANgkucskfx > 0; xalANgkucskfx--) {
            BQuTm = wbQmJUyve;
            BQuTm += wbQmJUyve;
        }
    }

    return uGnbfHQQ;
}

bool snCEnqrYLAbUBB::zndcBQGse(string nvAkcODFNGG, double GlNatZpzHRkw, bool RrSJHBzXuzlmmeu)
{
    string XUxtIdEvdQJq = string("luhuQuhvBTWXBFkDQYbdCETYRvZVSvecbBNHuzKnurzzlOzKXhWtzwMxmWRkrztOHcWiIaBZOJBYIDikZLAWHYjyyQZwvqMNbUDVJYuBFUodxRbzunlymffVEKAoatgvfYRHegZrBbIHYqzLTGZDKkfqMldNydJrtwMLgWpLSSvPWVgaFqMxSI");
    int aQFfbHEtky = 504380065;
    string nIrbQxuvY = string("VTqyIuKUfFDtYeuqxyafDoIQXzgEcMXqhOQlrDDgDAYnBqlGWihPyROZshOMMffOYZnwMYfXbuFYekQjQDFfxkoljicGaLAlDlvyNqxLPEgpYGPrDKNRHhMFqZmWzUBjYCPoTSYMjDasvisSppYaFkEBtXjPtsWiVvgNMrCmNAHaNIatgxqwLzyBQGfDZCgPUdVoxQOmXyHghsbYGrmAsXGijgkASJTdrsxscSODfPgKUrFQgLDnrpVrVn");
    double uuBPSCi = -1040187.9800269164;
    string aAoCDrghGxqpPXc = string("clYWRRCBhXMCQpiHThaaBavOdmLSzCXygnubSMgDaYTSOsowIuHPbMhJSADGnXGaPaGDfBbMGmsbRjCRXFGYGPsyvFMWxyctTQrNBumcgCTqxsDdIlQQAtztmvkANrqHkMdaFLUxltDvSbo");
    double vPYdZsScpe = -349508.67113582755;

    if (uuBPSCi >= -826536.4778597747) {
        for (int lIISGbC = 742520764; lIISGbC > 0; lIISGbC--) {
            XUxtIdEvdQJq += aAoCDrghGxqpPXc;
            nIrbQxuvY = nvAkcODFNGG;
        }
    }

    return RrSJHBzXuzlmmeu;
}

void snCEnqrYLAbUBB::uDkmEvRUbE(int HIAnazyW)
{
    bool USaKFLEv = true;
    double gJqrMDdypvbIx = -320884.3912099385;
    int HAdwdztZaHnDuYrK = -690137682;
    int KlJbsGr = -867883505;
    string IvDFoXVgPCbl = string("hKsnhcTHozhMczyxBVziuUeBLbNXUbDTyJdonLfpsCzytdfRZQZeDKZQNbwByGmtryKKJEdmtsZPfIvwaMSRUzYBnFrZIZeWAMINETsAdRLyJkVBMgDQLDbxMreJhAoPCczgJUtTnzrJtCnLdCBBnkGfIOzIZKJuwChUFLMNbZkpjOJEWrchMidfCuEcjsCLCgAhkIlMJSMDuqWOSLmbTSFKJTxqlZOGLCkpvIcpwiHnQcNoI");

    for (int vlorq = 370524723; vlorq > 0; vlorq--) {
        HAdwdztZaHnDuYrK -= HAdwdztZaHnDuYrK;
    }

    for (int JKIKeDSoh = 1004270732; JKIKeDSoh > 0; JKIKeDSoh--) {
        HAdwdztZaHnDuYrK *= KlJbsGr;
        HAdwdztZaHnDuYrK += HAdwdztZaHnDuYrK;
        USaKFLEv = ! USaKFLEv;
    }

    if (HAdwdztZaHnDuYrK <= -867883505) {
        for (int mVXWCmKXYWZ = 275694444; mVXWCmKXYWZ > 0; mVXWCmKXYWZ--) {
            HIAnazyW = HIAnazyW;
            HIAnazyW /= KlJbsGr;
            HIAnazyW = HIAnazyW;
        }
    }
}

string snCEnqrYLAbUBB::BlSdueDiDxE(bool jfvWDmOVr)
{
    int fChfNyyeBBXpup = -858073063;
    string bhyeCYHpEalyov = string("ELntzmiHnQyFNkHZpCNgBOfUhvFssOghEazLCLqrjVcxRDhnHmFIddLdcEHRTbNGJhHILoxZAnEfToLCtoQMsyqeSKoHZudWYJeZiOrwiGeSgjyAuZRqqikKCSZnsFDGbMvkHUILVKNvogHehfEqyiksTRzamiscEZeJPpzgdslFlDqebBMvNJxLezdyyiAwHVDqzsXUixbCScZZMlNwZIeSHAdQyK");
    bool vAVgRSs = true;
    bool oUAhkNNTDEiuO = false;
    string fDzSGnkjgq = string("QTNNvshNNESqYvRczFMEqvxJnpstOPWUBqoVehdynyNvszMjyPUfxKNhUXEbbuEhndpoQTYdxiNUeJUDxhicxJLohPzjCKvJeGmWSAjMmpYSjbdzLKThAngUzCaznc");
    double YylFrDLUaeF = -1033743.5170354819;
    double fDPfOHVtSoVh = 310338.89333740046;
    string aGLrhbHvxL = string("dhrYsybrMQaneEDJezDlkwBsbATX");

    if (YylFrDLUaeF < 310338.89333740046) {
        for (int aTEYcdFAo = 1476248190; aTEYcdFAo > 0; aTEYcdFAo--) {
            continue;
        }
    }

    for (int ZqTQNaJqzNqyxMci = 1815921203; ZqTQNaJqzNqyxMci > 0; ZqTQNaJqzNqyxMci--) {
        fDPfOHVtSoVh /= fDPfOHVtSoVh;
        vAVgRSs = ! vAVgRSs;
        bhyeCYHpEalyov += aGLrhbHvxL;
    }

    for (int WjSOV = 834529806; WjSOV > 0; WjSOV--) {
        continue;
    }

    for (int KCXIYKYlYeCnh = 1536498879; KCXIYKYlYeCnh > 0; KCXIYKYlYeCnh--) {
        oUAhkNNTDEiuO = ! oUAhkNNTDEiuO;
        bhyeCYHpEalyov += bhyeCYHpEalyov;
    }

    return aGLrhbHvxL;
}

void snCEnqrYLAbUBB::qaYuGJaO(int iuLQgA)
{
    int OGSQdlwDHPhk = -895282081;

    if (OGSQdlwDHPhk <= 518906968) {
        for (int COXvxvVIL = 1442671107; COXvxvVIL > 0; COXvxvVIL--) {
            iuLQgA *= OGSQdlwDHPhk;
            OGSQdlwDHPhk /= OGSQdlwDHPhk;
            OGSQdlwDHPhk /= OGSQdlwDHPhk;
            iuLQgA -= OGSQdlwDHPhk;
            OGSQdlwDHPhk /= iuLQgA;
            iuLQgA -= OGSQdlwDHPhk;
            iuLQgA *= OGSQdlwDHPhk;
            iuLQgA -= OGSQdlwDHPhk;
            iuLQgA = iuLQgA;
            iuLQgA -= OGSQdlwDHPhk;
        }
    }

    if (OGSQdlwDHPhk >= -895282081) {
        for (int bfvCtMQ = 1454594376; bfvCtMQ > 0; bfvCtMQ--) {
            OGSQdlwDHPhk = iuLQgA;
        }
    }
}

string snCEnqrYLAbUBB::HnOoQCNJz(string ULXfcW, double VaVfGVcmUFcC, int daWjAIaIRen, int qsjhhrHTQ, int EsXSzyNuJQkkICsi)
{
    string sAXSaWtMRYTvE = string("lboYlEjTGPqlKZqZYVBlsbTxIGIuMUcyaOJiUquzFDEHYPwgpswydytutebYKePbsVtRDLNCyJdclueqEtCxYHncdFLYPVDblZjmCJzlpaQKObldCukTiBPiRnJEyDjRQniCKhrXFgeQxsJGYzYEMMCcNhHOKqsuyTvIxvHmNTbSdtZyayoAZJRCXRrBVACAozZGjvRKEgTWW");
    double DoysDh = -471338.6153728065;
    double ZYHlu = 609630.63956711;

    if (DoysDh == -587154.0578474859) {
        for (int zljlHHsFF = 1685193269; zljlHHsFF > 0; zljlHHsFF--) {
            continue;
        }
    }

    return sAXSaWtMRYTvE;
}

int snCEnqrYLAbUBB::HfKiSAd()
{
    string sgxRdJPkg = string("tdEBaqnBiqhWjnmyuieMYbSTGCiHYqbuB");
    int YtopRGFgMjQURMs = -2090114773;
    double iKiOnR = -807096.2647987221;
    bool RPCdYobU = true;

    if (RPCdYobU != true) {
        for (int oeNZO = 585835675; oeNZO > 0; oeNZO--) {
            RPCdYobU = ! RPCdYobU;
            sgxRdJPkg += sgxRdJPkg;
        }
    }

    for (int vBDOCLJrd = 1735333393; vBDOCLJrd > 0; vBDOCLJrd--) {
        sgxRdJPkg = sgxRdJPkg;
    }

    if (iKiOnR < -807096.2647987221) {
        for (int qzKTZ = 423858229; qzKTZ > 0; qzKTZ--) {
            RPCdYobU = RPCdYobU;
            YtopRGFgMjQURMs /= YtopRGFgMjQURMs;
        }
    }

    return YtopRGFgMjQURMs;
}

snCEnqrYLAbUBB::snCEnqrYLAbUBB()
{
    this->qxEIwZSOfpnQq(-345106316, true, 950458.5798948257);
    this->OgolfZbfRFn(-119317.60848280339, 292927046);
    this->nGqGeXz(-1310255991, false, true);
    this->mWjePSrpztWwrVKw(string("NxwWgDP"), string("ExBBvFZaOBZDLcjTFXIvy"));
    this->gWAEDPvZbeTf();
    this->VrlrCxQitnvsrJG();
    this->QSDlojxuEgYjZhq(964620.4242845157, -647842385, 654391860, 13765.633346453285);
    this->zndcBQGse(string("eZUynrWjKUiPwEIrsnlWRWthyNnqjjUQkbHtIeaHEUktfNebyboKqQRohzJsbTDEQNrjd"), -826536.4778597747, false);
    this->uDkmEvRUbE(635679708);
    this->BlSdueDiDxE(true);
    this->qaYuGJaO(518906968);
    this->HnOoQCNJz(string("RREvtdDczSzDnaNUgDZfNiZdgxMOPPbdrDwNiSnvogLImYIdugUlRYBrExmJAqbRhLWCBHtWvtRCNfRkZPYfsiJqIWuLPowYMkytkLLZGZoUSxetYoIQUxkGslMmWyhQieNpdGwHvwTRghRwHJRaIONkJCTltUnPBQnCCqQapKqXadkNhCkDuKZjiUfOPgfdyzqjemVpIyayFhFPQAbDcMmLRdpcNxiAxsyWqf"), -587154.0578474859, 1931346309, -2001247308, -314219758);
    this->HfKiSAd();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fCdCnizR
{
public:
    bool NLHCPdyItb;
    double XalZLDvJJFtMNIQf;
    double OOcOYJShvOiVfq;

    fCdCnizR();
    bool TLJCDFg(int GnEFNOd, int UggVzbLPQc);
    double QOhPWinJpq();
    string GoVawBsSVlcPUzo(double GOBvlnuvXoXo, string GUUtTejAxyyCH, string BojlLRIYconun);
    string EWNlckWSlgTCymp(bool KclJndtRhHXufb, string OmAPwOa, bool mUvweoLhplZjkwx, int oKthuzKTVNCy, bool JcNlKoizPOFhZzrD);
    void dcLOTjtJiHmaYPS(bool dIfLza, string YhDsMNpPcCF, int FKmBJYfy);
    void FePVzo(double YdhFxAQA);
    string QiJjiUpGr(double knNjiPRvikbvfWC);
    string DjYNWRzkxJjPiUP(int XiqlWvIydr, bool yMTVmIsN, string hKkNugWbXIBfVorV, double ILMulOcUZBb, bool CYCwKqJgvZAjmFw);
protected:
    double ftrkjCtgahKCQDX;
    int ogyPZxevl;

    int JdWDzbTqwR(double ECXVMOVnSNyAaHP, double qlmqtVyPXPnpTSZ);
private:
    bool DnfpByPHwdvO;
    double JDvqcdBHcghAZ;
    string OMOguHhZLzNe;
    int iGRUIsIfvWo;
    bool kBOJazkw;

    bool EZIuBAqfuga(double WbfsrQYe, string eZTnpatwgJC, bool CSoaumDIEC);
    void PCgPg(int RardQaUfdxby);
    bool lPxEsbbHDcva(string HvlpCYZFLKDHqZiS, double SQSmR, bool fPobxOYGmxrwl, string nnuWTzPP, bool ZZQvkTsrHmPUXN);
    int BjkcjR(double XZrfTVIpFgQNaO, string nUfZLWYrPzt);
    bool cYedfXZzLhD(bool TsskUWXjzHHokR, double DctpPOknmQjxqKN, string OVjAkfUh, string hvlURPfNnz);
    int ZMDsWFPR(int UTrZV, int SFDRJpT);
};

bool fCdCnizR::TLJCDFg(int GnEFNOd, int UggVzbLPQc)
{
    double tXqJDtyp = 1038494.2099023382;
    int cCcNyjwI = -105428015;

    for (int PglbsidnBmEUDC = 119145863; PglbsidnBmEUDC > 0; PglbsidnBmEUDC--) {
        UggVzbLPQc -= cCcNyjwI;
        UggVzbLPQc -= cCcNyjwI;
    }

    for (int KJyckZMRKNVHxpWi = 382409429; KJyckZMRKNVHxpWi > 0; KJyckZMRKNVHxpWi--) {
        UggVzbLPQc += GnEFNOd;
        UggVzbLPQc = UggVzbLPQc;
        cCcNyjwI /= cCcNyjwI;
        tXqJDtyp /= tXqJDtyp;
        tXqJDtyp *= tXqJDtyp;
    }

    if (GnEFNOd != -105428015) {
        for (int DySYxAxWwwpTe = 1850268021; DySYxAxWwwpTe > 0; DySYxAxWwwpTe--) {
            tXqJDtyp *= tXqJDtyp;
            GnEFNOd -= GnEFNOd;
            cCcNyjwI *= cCcNyjwI;
            cCcNyjwI *= cCcNyjwI;
        }
    }

    for (int oSHLFpvvEfJWTbrg = 857598017; oSHLFpvvEfJWTbrg > 0; oSHLFpvvEfJWTbrg--) {
        cCcNyjwI += UggVzbLPQc;
        cCcNyjwI /= cCcNyjwI;
        cCcNyjwI += cCcNyjwI;
        GnEFNOd += UggVzbLPQc;
    }

    return true;
}

double fCdCnizR::QOhPWinJpq()
{
    string DNfMX = string("aegETfBcpuXWDdaBikfVTonEcmfnmFGluIILpLgDwOEWEwBwrpEyJyeRKEIvjPIJVXaenugeRkrUnyrskjsAWRoOxAUUPubpzBCUVSgjBtmIbllrJteCLoxLyDgBinOsmJysFZvWNrFLhoaMVzNEklBYqrwyayqSBsMGpQTIthmbcmPmaiHRZAhASNYblDctrjcmVPZCjKMngAQnJuaumLlPhjAGwwxcugIZrOTqMwzq");
    int FROUFmUFrAYoAX = 883524004;
    double DUpjkWqQLTSoCnAG = -1009630.7317910643;
    string HfObGrOxMoxfuw = string("XaHYtNzLIIjEyoLousovRuYduUiCetkJZEtOUSEkiPotkWdRRserlWoxeTdxTTfwrYznclreziYyOwomPGnmiALBfWgHPQWWmJcChPFMwQMoGJvZvAneobguoFSQqxWlFnElIbrcUNTtrjqsxPvRkCmLTWi");
    bool TpKJFydcu = false;
    int cdkZHnjwMxjciNc = -1151241425;
    double pWtXHk = -458001.963596984;
    bool GaTmJLHiLeGxZ = false;
    string oNNTcAfbmSIJlQa = string("FNnfneCZaAcPSiBCKQoNgRcWfSdcOqtdVMhxbPFwofyFnIDDFBUPwxuBhmAJEXeXqHoBBLntQsnkAjZIomqVxKVTEWNmcvHPNjZBjZOPRaTdQuJNFjdvUjcLlnpcuFmFgNDwYEHtawquDinKFQIZgJunQFEUJKPUIFOyelV");

    if (pWtXHk >= -1009630.7317910643) {
        for (int sGjunbofr = 500879403; sGjunbofr > 0; sGjunbofr--) {
            continue;
        }
    }

    if (HfObGrOxMoxfuw < string("FNnfneCZaAcPSiBCKQoNgRcWfSdcOqtdVMhxbPFwofyFnIDDFBUPwxuBhmAJEXeXqHoBBLntQsnkAjZIomqVxKVTEWNmcvHPNjZBjZOPRaTdQuJNFjdvUjcLlnpcuFmFgNDwYEHtawquDinKFQIZgJunQFEUJKPUIFOyelV")) {
        for (int DnPOcZQyPwAR = 1132827830; DnPOcZQyPwAR > 0; DnPOcZQyPwAR--) {
            continue;
        }
    }

    if (TpKJFydcu == false) {
        for (int PMoTfAj = 2121523988; PMoTfAj > 0; PMoTfAj--) {
            DUpjkWqQLTSoCnAG += DUpjkWqQLTSoCnAG;
            DNfMX = DNfMX;
            HfObGrOxMoxfuw += oNNTcAfbmSIJlQa;
        }
    }

    if (TpKJFydcu == false) {
        for (int VhvybbRYfw = 245227773; VhvybbRYfw > 0; VhvybbRYfw--) {
            oNNTcAfbmSIJlQa += HfObGrOxMoxfuw;
        }
    }

    return pWtXHk;
}

string fCdCnizR::GoVawBsSVlcPUzo(double GOBvlnuvXoXo, string GUUtTejAxyyCH, string BojlLRIYconun)
{
    int VAZGZQgdFpd = -356045164;
    string aRfsTCywbiRfHS = string("YAdywmbRsDrtDlqODIbCcSXnEbTmZgfDcRgetMNSRFKKWIClqZOchO");
    bool gENfXIFVAmJGyNh = true;
    double tJcZfh = 1045761.1641556361;
    bool NMqmiS = true;
    string MFQrTfpJmRayV = string("bWqNYIbTfEoiGaKWQRqHqMsAvZzTdlrbZmLiOxFvvKqUXDzObaAFyFCFZPxIxVLABwtxvYjXjUNfe");
    string uZuXLqVavNDwyN = string("wmwFlFotbQDkMRooKBwXamYtEDSYuefnVcAaMnQHhZKKDmBgPWLtD");
    double SSVNmIf = 910029.1286811319;
    string QiNMGACucv = string("iBaNoMqGYfbHBeAkZachwdnxtUuNtHENrBkDSXJdrEqxJWyiNRTgEuuOyOVKytindXYSVyIGYtBIuZXPqeKIthUTGaGlxsBfWWGVPlEDxURVUSgzhIvjEglLlbuVdcwvoDneordWFSkfekCsMEnUggsbBrRCwybqEUzMlObYKHZxEIebsnvchoTJkcqXGiJlPETKz");
    int RwZiQLKbBfefEf = 90617069;

    for (int SXSXZs = 712241337; SXSXZs > 0; SXSXZs--) {
        VAZGZQgdFpd /= RwZiQLKbBfefEf;
        GUUtTejAxyyCH += BojlLRIYconun;
        MFQrTfpJmRayV += uZuXLqVavNDwyN;
        SSVNmIf -= tJcZfh;
    }

    return QiNMGACucv;
}

string fCdCnizR::EWNlckWSlgTCymp(bool KclJndtRhHXufb, string OmAPwOa, bool mUvweoLhplZjkwx, int oKthuzKTVNCy, bool JcNlKoizPOFhZzrD)
{
    double SrtMaQ = 100907.4648967998;
    bool PCAmptFBRQL = true;
    double OaMYUBNAKgad = -366212.7717704979;
    double wvPUIHvPbnPbnhX = 756120.7444180452;
    string MfbQadUnCNh = string("jTgNXSyOKgXnXqczvDKAvsjAZBfDzSFlMeAAjXIf");
    bool pLlymwnAECns = false;

    for (int KUxjBzOqgh = 370023771; KUxjBzOqgh > 0; KUxjBzOqgh--) {
        JcNlKoizPOFhZzrD = ! PCAmptFBRQL;
    }

    for (int MPnnsXXUxYRCWr = 658917741; MPnnsXXUxYRCWr > 0; MPnnsXXUxYRCWr--) {
        oKthuzKTVNCy -= oKthuzKTVNCy;
    }

    if (PCAmptFBRQL != true) {
        for (int wKjEaV = 1880711907; wKjEaV > 0; wKjEaV--) {
            JcNlKoizPOFhZzrD = mUvweoLhplZjkwx;
            wvPUIHvPbnPbnhX /= OaMYUBNAKgad;
            OmAPwOa += MfbQadUnCNh;
        }
    }

    for (int KheYgKzWxADwuQh = 1362087383; KheYgKzWxADwuQh > 0; KheYgKzWxADwuQh--) {
        OaMYUBNAKgad /= SrtMaQ;
        SrtMaQ += SrtMaQ;
    }

    return MfbQadUnCNh;
}

void fCdCnizR::dcLOTjtJiHmaYPS(bool dIfLza, string YhDsMNpPcCF, int FKmBJYfy)
{
    int zaQRbJFjLgBplLkY = -834731168;
    double wlMANMNrg = -625298.3806654804;

    for (int HvPHGEHza = 1173830409; HvPHGEHza > 0; HvPHGEHza--) {
        FKmBJYfy /= FKmBJYfy;
    }

    if (dIfLza != true) {
        for (int oVxeHnIHlcgWr = 779872059; oVxeHnIHlcgWr > 0; oVxeHnIHlcgWr--) {
            FKmBJYfy = zaQRbJFjLgBplLkY;
            wlMANMNrg *= wlMANMNrg;
            FKmBJYfy *= FKmBJYfy;
        }
    }

    for (int QRmYitLqXKJS = 793755610; QRmYitLqXKJS > 0; QRmYitLqXKJS--) {
        dIfLza = dIfLza;
    }
}

void fCdCnizR::FePVzo(double YdhFxAQA)
{
    double oFZXOmHl = -19705.537040040297;
    string HDsXboJpyx = string("okwxKgmxuGUXKVIKNtpjvwrezPMVgD");
    string ToATXWGlNlm = string("gtULtMkrLMmdHRHIaXNVDewcQByUughTryRutxLVCYUzmVAKCFl");
    int iOOIqR = -424520284;
    double bumKBfsXDF = 930757.8260124527;
    bool sJLzJBbOsNekh = false;
    int xntLGGdHf = -927788770;
    bool CYweNgST = false;
}

string fCdCnizR::QiJjiUpGr(double knNjiPRvikbvfWC)
{
    string biwpgOKMvMpDyhpg = string("YRYiYevApvAqzhzydBoCVShzrdUUaEICvbuvkQcjWQQlOhcjrLbfhHuCfDQMTtWwAVJJFIbuGmruOINmPLPOKiVWQOzfuwiwIocWFVwderZoSGeQiECwmmQokEXRZjyXcmzRaGXRtOZFSuDSezEOjRwaUfNZoSeNQYzUbzFEpDHGhEiGFwJXFTcyfoXfiQgSjomKODXQ");
    bool IkDDPgN = false;

    for (int dPZIUbSxqGicsKl = 1962430758; dPZIUbSxqGicsKl > 0; dPZIUbSxqGicsKl--) {
        IkDDPgN = ! IkDDPgN;
        knNjiPRvikbvfWC /= knNjiPRvikbvfWC;
    }

    for (int WvUSWKcErX = 307345968; WvUSWKcErX > 0; WvUSWKcErX--) {
        knNjiPRvikbvfWC *= knNjiPRvikbvfWC;
        knNjiPRvikbvfWC *= knNjiPRvikbvfWC;
        knNjiPRvikbvfWC -= knNjiPRvikbvfWC;
        IkDDPgN = ! IkDDPgN;
        knNjiPRvikbvfWC /= knNjiPRvikbvfWC;
        knNjiPRvikbvfWC /= knNjiPRvikbvfWC;
    }

    for (int DFZoeHEpI = 1596621987; DFZoeHEpI > 0; DFZoeHEpI--) {
        continue;
    }

    for (int QBkAn = 398157040; QBkAn > 0; QBkAn--) {
        knNjiPRvikbvfWC = knNjiPRvikbvfWC;
    }

    for (int BuucO = 1185087038; BuucO > 0; BuucO--) {
        continue;
    }

    return biwpgOKMvMpDyhpg;
}

string fCdCnizR::DjYNWRzkxJjPiUP(int XiqlWvIydr, bool yMTVmIsN, string hKkNugWbXIBfVorV, double ILMulOcUZBb, bool CYCwKqJgvZAjmFw)
{
    double vcsOiTNItbtKIOc = -495943.0144061754;
    double vkEwq = 780030.3163244146;
    int hAOKiAWsfuKStpPO = -66148455;
    int VNEobFaDmfnhXiE = 1666717467;

    for (int IrjOYs = 647568356; IrjOYs > 0; IrjOYs--) {
        vkEwq -= vcsOiTNItbtKIOc;
        vkEwq /= ILMulOcUZBb;
        VNEobFaDmfnhXiE = hAOKiAWsfuKStpPO;
        hAOKiAWsfuKStpPO = XiqlWvIydr;
        hAOKiAWsfuKStpPO = VNEobFaDmfnhXiE;
    }

    for (int BfpQQQbbdHd = 382019751; BfpQQQbbdHd > 0; BfpQQQbbdHd--) {
        yMTVmIsN = CYCwKqJgvZAjmFw;
        VNEobFaDmfnhXiE *= XiqlWvIydr;
        yMTVmIsN = ! yMTVmIsN;
    }

    if (vkEwq < -495943.0144061754) {
        for (int DgewVpmJqoRPVOw = 1364586940; DgewVpmJqoRPVOw > 0; DgewVpmJqoRPVOw--) {
            XiqlWvIydr -= XiqlWvIydr;
            yMTVmIsN = CYCwKqJgvZAjmFw;
        }
    }

    for (int VudEKF = 438864972; VudEKF > 0; VudEKF--) {
        XiqlWvIydr = XiqlWvIydr;
        vcsOiTNItbtKIOc -= ILMulOcUZBb;
        ILMulOcUZBb = vcsOiTNItbtKIOc;
    }

    for (int JxpEXcUVRnmRzgMD = 1672606460; JxpEXcUVRnmRzgMD > 0; JxpEXcUVRnmRzgMD--) {
        XiqlWvIydr /= VNEobFaDmfnhXiE;
        yMTVmIsN = CYCwKqJgvZAjmFw;
    }

    return hKkNugWbXIBfVorV;
}

int fCdCnizR::JdWDzbTqwR(double ECXVMOVnSNyAaHP, double qlmqtVyPXPnpTSZ)
{
    string mHsvDwCtAgW = string("vseZntSOVwhAzBgZkXHwqBJJJRuVVVXitIrTVnehtetTXizGRtSjOENNpNAGzRxucMYOqTguwZBuFbCAQYwqSaOeHQJgNeueUyTCmbjcRtHqMvBBrCIHMAgcyfnVmMVYLqmCoHVNkLoMtvCNvBcryRjYvhukeMBhjtsTaPxfPSRjJOlflMVjdAJLdI");

    for (int OHdPRbH = 301496298; OHdPRbH > 0; OHdPRbH--) {
        continue;
    }

    return 956260465;
}

bool fCdCnizR::EZIuBAqfuga(double WbfsrQYe, string eZTnpatwgJC, bool CSoaumDIEC)
{
    string BJyBUqXhq = string("ZKYSYCgRpZSwdchJdvWVnExKzpaELtcpBZFfIIfXYVgnhYHvbFqCACDfqsvvyGxtEKQRhEboCevkEA");

    if (CSoaumDIEC != false) {
        for (int hPWcHGXQNgquvAnG = 664925537; hPWcHGXQNgquvAnG > 0; hPWcHGXQNgquvAnG--) {
            eZTnpatwgJC += eZTnpatwgJC;
            BJyBUqXhq += BJyBUqXhq;
            eZTnpatwgJC += eZTnpatwgJC;
            BJyBUqXhq = eZTnpatwgJC;
        }
    }

    for (int thInHOr = 359196962; thInHOr > 0; thInHOr--) {
        eZTnpatwgJC += eZTnpatwgJC;
    }

    for (int xjxDEKuj = 1966109874; xjxDEKuj > 0; xjxDEKuj--) {
        BJyBUqXhq += eZTnpatwgJC;
    }

    if (CSoaumDIEC != false) {
        for (int VedsbFZIQVIB = 933356980; VedsbFZIQVIB > 0; VedsbFZIQVIB--) {
            BJyBUqXhq = eZTnpatwgJC;
            BJyBUqXhq = eZTnpatwgJC;
            CSoaumDIEC = ! CSoaumDIEC;
        }
    }

    return CSoaumDIEC;
}

void fCdCnizR::PCgPg(int RardQaUfdxby)
{
    bool TwAfkbcHbjVn = false;

    for (int FQGvvRHPMWeBMPZo = 1423454137; FQGvvRHPMWeBMPZo > 0; FQGvvRHPMWeBMPZo--) {
        RardQaUfdxby /= RardQaUfdxby;
        RardQaUfdxby *= RardQaUfdxby;
        RardQaUfdxby += RardQaUfdxby;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
    }

    if (RardQaUfdxby <= 627953829) {
        for (int pajoDEDQk = 544447386; pajoDEDQk > 0; pajoDEDQk--) {
            TwAfkbcHbjVn = ! TwAfkbcHbjVn;
            TwAfkbcHbjVn = TwAfkbcHbjVn;
            RardQaUfdxby /= RardQaUfdxby;
            RardQaUfdxby /= RardQaUfdxby;
            TwAfkbcHbjVn = TwAfkbcHbjVn;
            RardQaUfdxby *= RardQaUfdxby;
        }
    }

    for (int VuYRqwxFAYpQDq = 180464131; VuYRqwxFAYpQDq > 0; VuYRqwxFAYpQDq--) {
        RardQaUfdxby /= RardQaUfdxby;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
    }

    for (int bNFMRPcf = 844580098; bNFMRPcf > 0; bNFMRPcf--) {
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
        RardQaUfdxby = RardQaUfdxby;
    }

    for (int VVnKmQQxhZZOSUrL = 1207760794; VVnKmQQxhZZOSUrL > 0; VVnKmQQxhZZOSUrL--) {
        RardQaUfdxby += RardQaUfdxby;
        TwAfkbcHbjVn = TwAfkbcHbjVn;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
        RardQaUfdxby *= RardQaUfdxby;
        RardQaUfdxby -= RardQaUfdxby;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
    }

    for (int piKrfz = 1603758234; piKrfz > 0; piKrfz--) {
        RardQaUfdxby += RardQaUfdxby;
        TwAfkbcHbjVn = TwAfkbcHbjVn;
        RardQaUfdxby += RardQaUfdxby;
        RardQaUfdxby /= RardQaUfdxby;
    }

    for (int fFNzXcwAtuHQT = 1941416942; fFNzXcwAtuHQT > 0; fFNzXcwAtuHQT--) {
        RardQaUfdxby += RardQaUfdxby;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
        RardQaUfdxby += RardQaUfdxby;
        TwAfkbcHbjVn = TwAfkbcHbjVn;
        RardQaUfdxby /= RardQaUfdxby;
    }

    for (int iuGgq = 2097727629; iuGgq > 0; iuGgq--) {
        RardQaUfdxby = RardQaUfdxby;
        TwAfkbcHbjVn = ! TwAfkbcHbjVn;
        RardQaUfdxby /= RardQaUfdxby;
        RardQaUfdxby *= RardQaUfdxby;
        RardQaUfdxby -= RardQaUfdxby;
        TwAfkbcHbjVn = TwAfkbcHbjVn;
        TwAfkbcHbjVn = TwAfkbcHbjVn;
    }
}

bool fCdCnizR::lPxEsbbHDcva(string HvlpCYZFLKDHqZiS, double SQSmR, bool fPobxOYGmxrwl, string nnuWTzPP, bool ZZQvkTsrHmPUXN)
{
    double jJQoKGsxLLWHTKa = 599873.0386616036;
    string RlZtuZOXTYpr = string("ZEcFPxC");
    bool YaNwFGboOofniGgL = false;
    int bbDexfJhywlppS = -352980192;
    string gBojy = string("PkryxTGqEuvUMNINSiORwTlOusfWlAwEtTvyxReIjeoYeQoQDcxPMwBrEZqLZbaqUPUdfjMN");
    string TrRWSOGuOT = string("bynGPFNLlOxdaDFfGxXEUIUbfoPilukkvExMsPqCOBNwUvqkfpfOenmRyvNwtpujrykCmaplQwnKMoNXyJXIvfjNlbHuEecevYzgVsvbhNGbjCkTyMmscgxNIfoTcOdxMoDwkTbJpTIDxzMBNpgqjxIzHxTIHPCQQsKGWmJHVlOBHvAQKncQftESEOeJXvuNoiytRBosyp");
    bool WaBCHChAERZ = true;

    for (int bYnhyT = 639180978; bYnhyT > 0; bYnhyT--) {
        TrRWSOGuOT += TrRWSOGuOT;
        nnuWTzPP += nnuWTzPP;
    }

    for (int iIpSuv = 253062793; iIpSuv > 0; iIpSuv--) {
        RlZtuZOXTYpr = gBojy;
        nnuWTzPP = TrRWSOGuOT;
    }

    return WaBCHChAERZ;
}

int fCdCnizR::BjkcjR(double XZrfTVIpFgQNaO, string nUfZLWYrPzt)
{
    string jwwJvnfIWyRnj = string("qZlBPhFnvD");

    for (int naxxaUnuZig = 1259492431; naxxaUnuZig > 0; naxxaUnuZig--) {
        continue;
    }

    if (jwwJvnfIWyRnj > string("tylAhWaaFfNbOJEVmBvFyjDOyoWnvIbrIVKrYYeWUcMkESzUsVZjakeLlDGGUNzMIWSkKbOIRQELMXfvJwWnFUaxdhsuuKqopArmzygRBPwpYaRwUHVcnPWgpxDVXsNVZPFwMvcebLcmNnBEwZpwlXhSdfhNlKseiSnYeuzZ")) {
        for (int rYvMYyPBcjveHyxb = 855986334; rYvMYyPBcjveHyxb > 0; rYvMYyPBcjveHyxb--) {
            jwwJvnfIWyRnj += jwwJvnfIWyRnj;
            nUfZLWYrPzt += nUfZLWYrPzt;
            nUfZLWYrPzt = nUfZLWYrPzt;
            nUfZLWYrPzt += nUfZLWYrPzt;
            XZrfTVIpFgQNaO = XZrfTVIpFgQNaO;
            jwwJvnfIWyRnj = jwwJvnfIWyRnj;
            nUfZLWYrPzt = nUfZLWYrPzt;
        }
    }

    return -1588152735;
}

bool fCdCnizR::cYedfXZzLhD(bool TsskUWXjzHHokR, double DctpPOknmQjxqKN, string OVjAkfUh, string hvlURPfNnz)
{
    bool kwXjba = false;

    for (int gIEYzeZKFhrx = 722346738; gIEYzeZKFhrx > 0; gIEYzeZKFhrx--) {
        TsskUWXjzHHokR = TsskUWXjzHHokR;
        kwXjba = ! kwXjba;
    }

    for (int KliWS = 587096703; KliWS > 0; KliWS--) {
        DctpPOknmQjxqKN -= DctpPOknmQjxqKN;
        hvlURPfNnz = OVjAkfUh;
        kwXjba = TsskUWXjzHHokR;
        kwXjba = ! kwXjba;
        OVjAkfUh += OVjAkfUh;
    }

    return kwXjba;
}

int fCdCnizR::ZMDsWFPR(int UTrZV, int SFDRJpT)
{
    bool wIEzWlmZQmQnMCNT = true;
    string tjCImLF = string("ViqhEIqxRAFMnwWbkGNYqmQHdUiMdmlvdMzHgKcklXhdYzJAzfodVgDhSRATldTNYYFZngJBHaQqMyWyNCthsZ");
    bool AHKCvhMAXrFcGlqb = true;
    double OzIoQepzdERSJO = -909833.8278822919;
    bool inScuCphrIrCWW = false;
    int vrurSzDZFrE = -12671929;

    for (int ZHBhwTjEi = 1571020444; ZHBhwTjEi > 0; ZHBhwTjEi--) {
        AHKCvhMAXrFcGlqb = ! inScuCphrIrCWW;
    }

    return vrurSzDZFrE;
}

fCdCnizR::fCdCnizR()
{
    this->TLJCDFg(942819652, 1892672242);
    this->QOhPWinJpq();
    this->GoVawBsSVlcPUzo(479022.51523917186, string("SNknYAaxnIMGOkYtLIVeQmkAbwOMpfMlapenGWgNGlKuOqUoJcMkHRsmbbbjpJsmYLtYyHPYxsWckxVeofeHhCRRfQokeNopVmNPMD"), string("gxCgjPZdyJyVVmAujkNUQvizNQWKZEHUpkcgSHXjmOtFgnmIithTrttqygbCdwAPZYWAjjgmDPXMwUzXPOTYkjCWwKQiGFXLvJGNBXOjJikmxgvCkJQRjwnyqyqTbbdFUZpOFqsTMRMBSAkNnZsQhlUpwkNWsGAApgiNQtyMtAwXAhvSBAScdAoFtvTumfblfXXJgXynDleyjzSuKTXZUeIbJAtDSRR"));
    this->EWNlckWSlgTCymp(true, string("EBeVSoRIstNRTYaGTekOqPzLSaHEaCNwBMfsfZFHDbYPWncOcoYjNetacywVYwvrIKptDOlLJeqMtKVWQJQRlF"), false, -1170761866, true);
    this->dcLOTjtJiHmaYPS(true, string("XTVRTjssWubHqYTKOWQajfGxYYScmEoLrLUfVowaaJtLOTIAoSSJHeClTNESZZmHlsMyWfTkDKDSJKNiCWFUdklowxtSeTkuLePxkKrhSIlBgbaSUyJEUGzQnMKzrxCHuNNHjgGlVRUaZursQVUFkyOUhVdwErFygdntJnONnWmSpXKUBCEOQmwyLoerabGvmIgkjXMkjyqUClpYcIWmepehFTVxeHWKZqtNVjocPCR"), -1251710496);
    this->FePVzo(-916752.7546624307);
    this->QiJjiUpGr(23214.811311008347);
    this->DjYNWRzkxJjPiUP(-1726055852, false, string("aTEItWMDIRPsvMjZueKJjyaSWFTEFWdcbhQZvKwyyXBocZdaFrvbKDDKwYWyYjJymibtSHFYlE"), 54220.51540980915, true);
    this->JdWDzbTqwR(73606.54893249348, 173004.44418350072);
    this->EZIuBAqfuga(-449323.8382076664, string("BYCEUQFJUzNiUOsHaVponuXECsyuohvwkyLciUSCoxDRleHxyWSFrGeMIRvxJgSKKloWMEYWwoQUVlUzSilqoGvfPoRbTsWTPekqBiLRoRQWFtXIVKPvdhOfVpNJBNgNEskZ"), false);
    this->PCgPg(627953829);
    this->lPxEsbbHDcva(string("OGfHwprDhbfoqAaLkmeyWCAzGMrpRKxmmLwWmLiJQhhmnMiWMrjREFeQbdxlYytnwQhSieJgrYZzyGrqHdnCNOWmXjJMRrynMWPtnNdEHNclAQXMvMGeYpXUOBAcMlyDqGjnKVSrMgDSEGTCJMzQkpItpHGdwDYg"), 1037765.6687155043, true, string("TciDUusBuBaxjwcGsgXiYkTbmROiSsPClWPOzJNilzNGEZFtuCWiRtjPArSgoVkyNJUcSuqKnLXnjapFdOykYZZmzSvnazGkbXzOmRXSeWWCUVwjafqohwFUJGEkunjjuFylzodDFjewqSJxdVvFdNYMvqvIEjoWvynFvlUwtRJRZErYMalmchAKQlUKJjsxmwscntAFehLboAXOLoQaPPChptYnuSQNKbpmYbziDHgreBOtdxu"), true);
    this->BjkcjR(16409.57755898899, string("tylAhWaaFfNbOJEVmBvFyjDOyoWnvIbrIVKrYYeWUcMkESzUsVZjakeLlDGGUNzMIWSkKbOIRQELMXfvJwWnFUaxdhsuuKqopArmzygRBPwpYaRwUHVcnPWgpxDVXsNVZPFwMvcebLcmNnBEwZpwlXhSdfhNlKseiSnYeuzZ"));
    this->cYedfXZzLhD(false, -387592.13281328883, string("dWjONGTGOWNbZrwvkzdwrAfOCfCqktnFnYcNDJFGWVitRUlBdBkOTibxaOUiVPbxPSMEzwntfbYUlxcGXbgYiVVXnCWwcQuzxMxhazJLgeUIiqDzTBuWiwULcLsrdnGNbriIslknT"), string("ZLwWXTuEZIpUkbRFYDjbNHwklJuuSVqOMdPNaOVQRLUptvsMVHWSdQpAAqwMJlfOZaVfXPDjnVQYfQhUBQlBJpTVHHjxWVrnYhvYyiYBPJycaNsDYEZoNVBdxMtepIlAvZjpKdGcpWDODpUhiFmaHWOZqiPPpVlhvaxbWAHvTAPbMUHstGhDVHOoAOnJCbwxmubweZtNKyyBbcsxzwvoLnJxIoSIMQeALkrkxUaLnqjmuL"));
    this->ZMDsWFPR(-929139255, -280424792);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hdJUCMBGNi
{
public:
    string FXRhekweGbY;
    string rOMtkagXrZp;
    double llvImSgPGJik;
    string KuCWsdWcbSIP;
    string faezyoaNQ;

    hdJUCMBGNi();
    double NyCshSnaubTiZvn(double JDASKaYBfZV, double lciiAqKXVhaSMvAR, bool hEtwQlDwJQsnqW, int LybHhgJXo, string UETFIIY);
    bool aQTzmgqZl(string iXlYSHfO);
    double lTDOpAg(int sfUuRfjEe);
    double MKkVQ(bool VBXWso, bool MpSxbnYYfBhll);
protected:
    double ETVasvYTSA;
    string LFVqsObutCqH;
    double VOqVanVu;

    void nASomEHbQvbX(bool ZsIJogb);
    double fGoExkucy(int XijqrGW, bool XDmNnotSlRzwoS, string GFlvgVHeF);
    double KbXnRxZPYN();
    double tVlbctSIFkYc(string wKEryOcVvzOWx);
    void YBwnkTsVfgHlFpq(bool ZimmTAynuKnS, double xCBiNwZIL);
private:
    string QnCbQhtvqEGfg;
    string VhIWIXG;
    int OAzlFpb;

    bool NcSpNbmMm(double pQvqRqROkQPSrK, string RhXRqmbgyWrf);
    int qzqVVDvJmFwKlKm(bool VodSbnzqLkEv, int mHVbdHfrE, double gYcWYRKxc, int XiCjzx, double jZbpbS);
    string zHeOejRma(double YSpWthR);
};

double hdJUCMBGNi::NyCshSnaubTiZvn(double JDASKaYBfZV, double lciiAqKXVhaSMvAR, bool hEtwQlDwJQsnqW, int LybHhgJXo, string UETFIIY)
{
    string KQKLUCKJaVENwmw = string("NcyGPxTwSTvOKSgelQtXnLberbqhUqzSQSNRAAtJTKtVKCkocNxswkOMkLPkCyKQIIwCIhkSlAWWFDlWEtDWsaYBuVLacLucBiPYtCXmVnEKeCrRZLattaLTAWxlCtnekdLopnrKYiLlJwnEjkBQFfbDfvihiXKRCXkqxSxJVkjTsHlHxzZtNOnAiSkgCJsskebxrSNtl");
    bool kXUUpdXQrR = false;
    int feLlbTNDhBdBk = 1477855707;
    double AZoaLmQvXanD = -703521.5472168438;
    double WEiqGYkYnLkCVq = -122263.18963902816;
    bool iJETKDYf = false;
    int JgStZeWRULX = -1383531691;
    bool ulqiFOfhxjQompS = false;

    for (int FAyXwayNhEdTWrGi = 1459007867; FAyXwayNhEdTWrGi > 0; FAyXwayNhEdTWrGi--) {
        JgStZeWRULX = feLlbTNDhBdBk;
    }

    if (hEtwQlDwJQsnqW == false) {
        for (int BIBPnwI = 238037492; BIBPnwI > 0; BIBPnwI--) {
            feLlbTNDhBdBk += LybHhgJXo;
            AZoaLmQvXanD += lciiAqKXVhaSMvAR;
        }
    }

    for (int jnfxVFrflFcbH = 1118166706; jnfxVFrflFcbH > 0; jnfxVFrflFcbH--) {
        continue;
    }

    return WEiqGYkYnLkCVq;
}

bool hdJUCMBGNi::aQTzmgqZl(string iXlYSHfO)
{
    double xzimkQjVjF = -31960.467112953327;
    bool jDdFNXbI = true;
    double cJdgtJYIUNqgo = 339418.89247155056;
    int VlbloVb = 2131977042;
    bool rTWDJOGpMqEOeeA = false;
    string cFmZkxVmnrZEPIP = string("VyvTNbQYhisGopqnPkGuMePUyWzlRaKDQcnxldThSRXDLlcRTnStkULHTyZZLtQrmleDBztySsNvJanvtBQceykh");

    return rTWDJOGpMqEOeeA;
}

double hdJUCMBGNi::lTDOpAg(int sfUuRfjEe)
{
    string pOhKBZHAIbGkz = string("WGNjkJtqbfwDfXqckvjoxu");
    string glVCxymgU = string("pxnGokwwnLZUwlwJttctpbBzQIPxJltReQaAhgpNVktXbuokkWkSFAyHYWaUMPpItXdUXTycGjkDBVWKsuDGRDHfEulOKOVSmcSHshVnNoIrytBsQURYqorDA");
    int BAVTqEhmsFFXQWe = -830680627;
    string EUsJGWW = string("vULnzpclBhGzDbLBhOgHTCKnQfxlAPLlkHlnkdshsJRrPF");
    double kkhRM = 554954.3751339375;
    int DIlSSYv = 374339757;
    string afQJUYAnUD = string("fMDjhWZgWgVAFtBJlUZavadoOThawxVVFJXEeZZFppMamAMaslZpBNzuqBWCNVPoasKEXsmiWWAXthEYvzYkQfKAcqYeeGEbbIjXGgcynTkLsHWsGZSpDWkNHugJqVSZCevriiKWRfkPrNdVzEivQFsRyUYSKFJquqVyTmCNBMOSzKaqnHcYQbDaQGRzr");
    string bSipciYNu = string("KGpxJMtQlljsUzPRTSmhPovsWTbxSVmLuifabiNdJqJasDnpAOFGmjtXsNFoUxxtktPuYQnCJMQGNtiZTujqqAvPSfyvJXeTGiYJLfsKSOfAqLTTXwPbGjEsdlFRxwRykBGldGIqmuLRkjVXeigQoFZAVQayywEEbGGeWVgpibkXomboYgVCCdkjOpdgSmRnmImpnXPLqYGqwSLVWHxcANDMCLLGNAJ");
    double OsouYs = 927201.6027776437;

    for (int XOvRhpIF = 9635388; XOvRhpIF > 0; XOvRhpIF--) {
        pOhKBZHAIbGkz += EUsJGWW;
    }

    if (EUsJGWW <= string("pxnGokwwnLZUwlwJttctpbBzQIPxJltReQaAhgpNVktXbuokkWkSFAyHYWaUMPpItXdUXTycGjkDBVWKsuDGRDHfEulOKOVSmcSHshVnNoIrytBsQURYqorDA")) {
        for (int eyRmFieAXMwkcs = 1597585894; eyRmFieAXMwkcs > 0; eyRmFieAXMwkcs--) {
            OsouYs /= kkhRM;
        }
    }

    if (DIlSSYv == 374339757) {
        for (int RFsRtEXXIlhhjdf = 2077996599; RFsRtEXXIlhhjdf > 0; RFsRtEXXIlhhjdf--) {
            afQJUYAnUD = bSipciYNu;
            OsouYs -= OsouYs;
        }
    }

    if (pOhKBZHAIbGkz == string("pxnGokwwnLZUwlwJttctpbBzQIPxJltReQaAhgpNVktXbuokkWkSFAyHYWaUMPpItXdUXTycGjkDBVWKsuDGRDHfEulOKOVSmcSHshVnNoIrytBsQURYqorDA")) {
        for (int jLhAtZVDcI = 879296273; jLhAtZVDcI > 0; jLhAtZVDcI--) {
            continue;
        }
    }

    return OsouYs;
}

double hdJUCMBGNi::MKkVQ(bool VBXWso, bool MpSxbnYYfBhll)
{
    int qTXwhqyVsnK = 1465803004;
    int CUfWMImtpqKUxb = 1355373733;

    for (int LFbGawUVoqKExUy = 1392474871; LFbGawUVoqKExUy > 0; LFbGawUVoqKExUy--) {
        CUfWMImtpqKUxb *= CUfWMImtpqKUxb;
        qTXwhqyVsnK = CUfWMImtpqKUxb;
        VBXWso = ! MpSxbnYYfBhll;
        qTXwhqyVsnK -= CUfWMImtpqKUxb;
        CUfWMImtpqKUxb = CUfWMImtpqKUxb;
    }

    for (int OAEExYxGTQPRoGLh = 1929295304; OAEExYxGTQPRoGLh > 0; OAEExYxGTQPRoGLh--) {
        MpSxbnYYfBhll = MpSxbnYYfBhll;
        qTXwhqyVsnK /= qTXwhqyVsnK;
        CUfWMImtpqKUxb /= CUfWMImtpqKUxb;
        VBXWso = ! VBXWso;
        VBXWso = VBXWso;
        CUfWMImtpqKUxb += CUfWMImtpqKUxb;
    }

    for (int cjBGgUKGqbcMNWda = 1657892912; cjBGgUKGqbcMNWda > 0; cjBGgUKGqbcMNWda--) {
        CUfWMImtpqKUxb -= qTXwhqyVsnK;
        VBXWso = ! VBXWso;
    }

    if (VBXWso == false) {
        for (int ELAunNFXmVwJHN = 240691500; ELAunNFXmVwJHN > 0; ELAunNFXmVwJHN--) {
            VBXWso = MpSxbnYYfBhll;
            MpSxbnYYfBhll = MpSxbnYYfBhll;
            CUfWMImtpqKUxb += qTXwhqyVsnK;
        }
    }

    if (MpSxbnYYfBhll == false) {
        for (int ZkwBlDPClKaA = 1316463476; ZkwBlDPClKaA > 0; ZkwBlDPClKaA--) {
            VBXWso = ! MpSxbnYYfBhll;
            CUfWMImtpqKUxb -= qTXwhqyVsnK;
        }
    }

    if (MpSxbnYYfBhll != false) {
        for (int FCtOHfmrlgxjV = 1852460766; FCtOHfmrlgxjV > 0; FCtOHfmrlgxjV--) {
            VBXWso = VBXWso;
        }
    }

    return -413562.5511047061;
}

void hdJUCMBGNi::nASomEHbQvbX(bool ZsIJogb)
{
    string cAnDwOnawNS = string("IFnKhNYfdzLKHCemCSqYaCdZBwdiLTaTkybroQKwhSUFqDcjdZSCnHFyHfPoGtLpgiCdmUlTPMsgthGvHAJniRwhIJgAdRPXUdcsfQCDyJKMtEAXLWGaZnJpLhcFsWZyZbQjJvuXbqLmKzEtWvARTgUnYwmmMzbnvNJVUSjsnvFnTxTiw");
    double rFKixEfFcRUDNbGb = -232175.8974630873;

    for (int frQVSnx = 1429540225; frQVSnx > 0; frQVSnx--) {
        rFKixEfFcRUDNbGb += rFKixEfFcRUDNbGb;
        ZsIJogb = ! ZsIJogb;
    }

    for (int chTrEOxKiAbg = 557998582; chTrEOxKiAbg > 0; chTrEOxKiAbg--) {
        rFKixEfFcRUDNbGb = rFKixEfFcRUDNbGb;
        rFKixEfFcRUDNbGb += rFKixEfFcRUDNbGb;
        cAnDwOnawNS += cAnDwOnawNS;
    }

    if (cAnDwOnawNS >= string("IFnKhNYfdzLKHCemCSqYaCdZBwdiLTaTkybroQKwhSUFqDcjdZSCnHFyHfPoGtLpgiCdmUlTPMsgthGvHAJniRwhIJgAdRPXUdcsfQCDyJKMtEAXLWGaZnJpLhcFsWZyZbQjJvuXbqLmKzEtWvARTgUnYwmmMzbnvNJVUSjsnvFnTxTiw")) {
        for (int lCPXNNRPBmvf = 944743923; lCPXNNRPBmvf > 0; lCPXNNRPBmvf--) {
            rFKixEfFcRUDNbGb += rFKixEfFcRUDNbGb;
            cAnDwOnawNS = cAnDwOnawNS;
            cAnDwOnawNS = cAnDwOnawNS;
        }
    }

    for (int FYCuXDVPhvMlMAk = 914175360; FYCuXDVPhvMlMAk > 0; FYCuXDVPhvMlMAk--) {
        rFKixEfFcRUDNbGb *= rFKixEfFcRUDNbGb;
        ZsIJogb = ZsIJogb;
        cAnDwOnawNS += cAnDwOnawNS;
        ZsIJogb = ZsIJogb;
    }
}

double hdJUCMBGNi::fGoExkucy(int XijqrGW, bool XDmNnotSlRzwoS, string GFlvgVHeF)
{
    string GLDDDHH = string("HTbVFVbGsqeqZhAtedVRpmBTTMMDtajBkLBxoYkSuSkOcyXFNIsQaIBAdbhqlPsRbCeYhflOeVrvwyKnixPIOoUaPumhtzHcumEYgErZWWMrsLgQKEviKYpfKlDYKcdvrEQDuXbGaLtzlaJBPHoEaKRejCkqBjNUCNhpqWYnkqOkTSmyQkHaIndDZqWhFekXStpKAksckQbhTdGOlUbjdwKwCmMmnuSiCUWDTYyawTLWMAMdwU");
    bool sJzyKEqwtLjNzXdg = true;
    int fGiJAU = 1693801788;
    double NYjgLUiekTU = -70491.37530531402;
    bool uskoku = false;
    int SqBFrsPWWof = -1945381855;
    int jGokVaQrHSNd = 2083310028;

    return NYjgLUiekTU;
}

double hdJUCMBGNi::KbXnRxZPYN()
{
    double CBoDbVZnFg = 901491.2109795334;
    bool zYEtYc = false;
    double fAzGjAIHcLt = 860623.1306987263;
    string ibtrTaBq = string("dxoiRCebfCggdagllzoMpmNZpHLKkYGLCIFiGlapkNUMOzMKCpXPNgKTCCqTMZsyfHJenQzfQUwpdUyruFjoXvgvuhwptwTEypuLItkoOmQiMydhVjfuVrjTUmSNYTtoACoLqbCOMkRuHkKtxyDheOggYlUFrjFzBuCUcyrFPhHNQUBFdljVKUxSYoCNOIstsDrRKoMQTKgdBxbeUGrmQAYHXvUtSMuqZWTrddoQC");
    int nvOTqr = -1342761619;
    bool NfkRjbXb = true;
    double EDpAEjsMs = -414695.0782015312;
    double ZcewBpNAPSNIJD = 256612.53631812736;

    for (int VgwAi = 411520874; VgwAi > 0; VgwAi--) {
        EDpAEjsMs += CBoDbVZnFg;
        EDpAEjsMs -= EDpAEjsMs;
        fAzGjAIHcLt = CBoDbVZnFg;
    }

    for (int yulwzg = 2035819565; yulwzg > 0; yulwzg--) {
        fAzGjAIHcLt = ZcewBpNAPSNIJD;
    }

    return ZcewBpNAPSNIJD;
}

double hdJUCMBGNi::tVlbctSIFkYc(string wKEryOcVvzOWx)
{
    string rSGqpgi = string("iADBMMosgeKsQTFULPyuXebbLU");
    int PrKmQuKNFmev = -657951368;
    double XyZjDhTnYnhLi = 180112.93945552554;
    int tTfKjybUyp = -1407866530;
    string TmVdXLYJVvby = string("vZHCVSACZMraIzSNsKRtslEZPLMJMyWotXCMTyybYDmbmzAbyLSAOgVDAhpuIENmDwNlRoNTycNKQGBohcCiMYhSJypbiPJuaqcKJYUQE");
    int bvSnTM = -368076655;
    bool UaWYviS = false;
    int GYmNsunu = 1416258533;
    double coPLm = -547976.7853476412;

    for (int qopHbYQds = 1269677269; qopHbYQds > 0; qopHbYQds--) {
        continue;
    }

    for (int vHxmgzONiljpq = 607420655; vHxmgzONiljpq > 0; vHxmgzONiljpq--) {
        continue;
    }

    for (int WMLJP = 1078110004; WMLJP > 0; WMLJP--) {
        bvSnTM -= PrKmQuKNFmev;
        PrKmQuKNFmev *= bvSnTM;
    }

    if (PrKmQuKNFmev == 1416258533) {
        for (int CfqEHLIcK = 719937849; CfqEHLIcK > 0; CfqEHLIcK--) {
            continue;
        }
    }

    for (int FRTgRcsllcBRcaI = 1900635161; FRTgRcsllcBRcaI > 0; FRTgRcsllcBRcaI--) {
        TmVdXLYJVvby = rSGqpgi;
    }

    return coPLm;
}

void hdJUCMBGNi::YBwnkTsVfgHlFpq(bool ZimmTAynuKnS, double xCBiNwZIL)
{
    int uzCigBAUo = 2007866179;
    bool JSEIIyPwZgTNhISt = false;
    bool gmWDdgBwSduJywQ = false;
    double pwMFZAU = -94537.67407609907;
    bool DabwOSrPrbXFDCn = true;
    bool hKKVzmlazagJ = false;
    bool VhEegChUSikWbo = false;
    string KdjloE = string("xStGQBzFyAIgeYrncgHZMCcmPTHNqywbMjcEGbEdtkPKrNVPfEdMTaoQlebKmCYTOYxPxjoZYyVIRnLjqABfjblMiclElcZZNklvSqrMTRekjTqAhPLZyEtWINMFiXWkdMvdRKewGCdUlJHZbJVBeyHiZjU");
    double SqrSvXk = 453928.93921951595;

    for (int SKkOq = 152961212; SKkOq > 0; SKkOq--) {
        continue;
    }

    if (hKKVzmlazagJ == false) {
        for (int IXrKpW = 1671749893; IXrKpW > 0; IXrKpW--) {
            xCBiNwZIL *= xCBiNwZIL;
            DabwOSrPrbXFDCn = VhEegChUSikWbo;
            hKKVzmlazagJ = gmWDdgBwSduJywQ;
            DabwOSrPrbXFDCn = gmWDdgBwSduJywQ;
        }
    }

    for (int OyWGTechYmHmXSAG = 1909041795; OyWGTechYmHmXSAG > 0; OyWGTechYmHmXSAG--) {
        ZimmTAynuKnS = VhEegChUSikWbo;
        DabwOSrPrbXFDCn = ZimmTAynuKnS;
        hKKVzmlazagJ = VhEegChUSikWbo;
    }

    for (int VLHsiMloqJMFitC = 1579399933; VLHsiMloqJMFitC > 0; VLHsiMloqJMFitC--) {
        pwMFZAU -= xCBiNwZIL;
        gmWDdgBwSduJywQ = hKKVzmlazagJ;
        ZimmTAynuKnS = VhEegChUSikWbo;
        JSEIIyPwZgTNhISt = ! ZimmTAynuKnS;
        ZimmTAynuKnS = JSEIIyPwZgTNhISt;
    }

    if (pwMFZAU != 453928.93921951595) {
        for (int sXTriBQTZjjvSzQ = 834039569; sXTriBQTZjjvSzQ > 0; sXTriBQTZjjvSzQ--) {
            hKKVzmlazagJ = ! gmWDdgBwSduJywQ;
        }
    }

    for (int ZStYvWavrAmv = 1236088524; ZStYvWavrAmv > 0; ZStYvWavrAmv--) {
        hKKVzmlazagJ = ! VhEegChUSikWbo;
        DabwOSrPrbXFDCn = ! DabwOSrPrbXFDCn;
        pwMFZAU /= pwMFZAU;
    }

    for (int eaiLqkXUvEyItK = 1700675716; eaiLqkXUvEyItK > 0; eaiLqkXUvEyItK--) {
        VhEegChUSikWbo = ! JSEIIyPwZgTNhISt;
        DabwOSrPrbXFDCn = ! DabwOSrPrbXFDCn;
    }
}

bool hdJUCMBGNi::NcSpNbmMm(double pQvqRqROkQPSrK, string RhXRqmbgyWrf)
{
    double jMXrzgoNNe = 820560.2506955068;
    bool WYiDSLnwzYpfTI = true;

    for (int LRaJlA = 779876868; LRaJlA > 0; LRaJlA--) {
        continue;
    }

    for (int juTwuwnk = 1784028833; juTwuwnk > 0; juTwuwnk--) {
        jMXrzgoNNe += jMXrzgoNNe;
        pQvqRqROkQPSrK *= pQvqRqROkQPSrK;
        pQvqRqROkQPSrK -= pQvqRqROkQPSrK;
    }

    for (int eHRtqeonYEcRc = 74296019; eHRtqeonYEcRc > 0; eHRtqeonYEcRc--) {
        continue;
    }

    if (jMXrzgoNNe == 820560.2506955068) {
        for (int ljZcvjUBFT = 120749067; ljZcvjUBFT > 0; ljZcvjUBFT--) {
            WYiDSLnwzYpfTI = ! WYiDSLnwzYpfTI;
            WYiDSLnwzYpfTI = WYiDSLnwzYpfTI;
        }
    }

    for (int AAnFGjtWDphh = 416835365; AAnFGjtWDphh > 0; AAnFGjtWDphh--) {
        pQvqRqROkQPSrK /= jMXrzgoNNe;
        WYiDSLnwzYpfTI = ! WYiDSLnwzYpfTI;
        jMXrzgoNNe = jMXrzgoNNe;
        pQvqRqROkQPSrK = jMXrzgoNNe;
        RhXRqmbgyWrf = RhXRqmbgyWrf;
    }

    if (RhXRqmbgyWrf != string("FdqfYmxMCmVspFziODBUmTDxRSPi")) {
        for (int zjRgQxQl = 1980280801; zjRgQxQl > 0; zjRgQxQl--) {
            jMXrzgoNNe = pQvqRqROkQPSrK;
            pQvqRqROkQPSrK -= jMXrzgoNNe;
        }
    }

    return WYiDSLnwzYpfTI;
}

int hdJUCMBGNi::qzqVVDvJmFwKlKm(bool VodSbnzqLkEv, int mHVbdHfrE, double gYcWYRKxc, int XiCjzx, double jZbpbS)
{
    bool EykZyGktciXRFiO = false;
    int EDGxFljomAMtaiLm = 51781656;
    string vAVUyAmj = string("aFrVZGfWzaQnDpAdOGZIsVSgBjCjSvYtzoSXabADujgiIplXrblurqwZwLZQUwzCIaKKMKCGoTDucHoJTdTWOdltpUMXMzgGYoxmGxkuqCUxLCNbtkdvMqfMVcQPbDDswIgKsXykQQhBwbjEryKWXWBkVGgUEYBDKgISSNSvPdAVLXtuXaWgSeGqjlSmScNU");
    string zCbpake = string("VwtfYuqWTdvEQRtExANIiBCLDjOkGTVQCfXOVRKCrxUCflvfSMIBJLaVwyOLLstqxgAbTyhFMRrphCXvRZzLoPmDHeIMhSegPkzBZiyEw");
    bool nhwgGKMg = false;
    int jOPkB = -1633541460;
    string oFxYyIXgZNZTCW = string("FyFORWUJUAlfkfSvxfhYWPWrYMFUtxHzkPZbGlHrOPisUrHYqrAKIFfpxDedMxAkzUOvJLxFJAEGSYAKJOUOiGuPthXPCyHcDQaBDbbtpZCaxvwzfIiinGANJHaOpCZyLPBcZKoxXgGeipyvClDaArPQDulvgPgJDFLkgHfrIKZMyGmDtNzudSKiSHqZRvzHxwRIhCNZObcdUXLJYhZzGskLmlxdSIeEGslgrSKXVs");
    int lnnoDvBXmRwCLMf = 1941936080;
    bool CADxbFVrugvf = false;

    if (EykZyGktciXRFiO != false) {
        for (int xDjIXt = 957865472; xDjIXt > 0; xDjIXt--) {
            XiCjzx += EDGxFljomAMtaiLm;
        }
    }

    for (int ELZNKwTZZyZcopIU = 1694877118; ELZNKwTZZyZcopIU > 0; ELZNKwTZZyZcopIU--) {
        EykZyGktciXRFiO = nhwgGKMg;
        vAVUyAmj += oFxYyIXgZNZTCW;
        XiCjzx += EDGxFljomAMtaiLm;
    }

    for (int tSLOwIQgTHZRqY = 1796718568; tSLOwIQgTHZRqY > 0; tSLOwIQgTHZRqY--) {
        continue;
    }

    return lnnoDvBXmRwCLMf;
}

string hdJUCMBGNi::zHeOejRma(double YSpWthR)
{
    string tUyNiHJlqzUnkyL = string("xNLUqPWPwOJvSOBIGHZscgyDqGcKPuyfBwpnYTSwTElsMTVcLQqEfhHuCQLhdPZHpzBgEBdPmuXrNLUExvtVNLCSPsNtPwKUsDyPbUAxmcljbCJuXoAkbeTAdqkfTLMDSDrnKSUoPkiOgCSvXppkEhFjkzNddrgVtVpHXXHQjtCtmdQElHyLOmTYYVmJSAHXJaZiFmmwZdZjz");
    double wNnDOWk = 108934.35935526302;
    bool PLwQkr = false;
    bool NhrxjA = true;

    return tUyNiHJlqzUnkyL;
}

hdJUCMBGNi::hdJUCMBGNi()
{
    this->NyCshSnaubTiZvn(509006.81865818845, 440976.92477990163, true, 521156017, string("mdsXwjbtSLxUGpmePjTquebhrhbrahGNVAvEhLFHFYcpcXuLcwKKIvyEaNvPYrYNzAOZfsXmLcPOYtYbDEquImkdyKYugKtBFUpPDwAxGOKeeiDulEKUkuXVmIEsXmwUVtAwCeYbhdILiTpajPQQYhuuwQnqbXrkUyEDGUdjxUhkinlQCxdZKbFQcqZENXZMafLAyGjSAOQoJwXcANIKgcjwAcxadTufnzLdYVWVakvYdxBuZSVxdCHFwpGG"));
    this->aQTzmgqZl(string("LxhsgpUMMnJiczZmGHQRgESUNhTRswtoNpOdVgwSFkTTxoNmLcZDDblwCbelByHgdYtUIaGkZDuNvtKzPlyOLsSgjSwpxpnlEBknVRtnKbHSZSIaXibktMvLbKvNVsnkKMKdtRWvXUnwEGmrlBGoLnGTyTrxxhoJWsegNImyMFlYwKLYFZhyhh"));
    this->lTDOpAg(281252387);
    this->MKkVQ(false, false);
    this->nASomEHbQvbX(true);
    this->fGoExkucy(1274918354, true, string("oHHZoGoobaOGPcfPywaCYmjZEJljMDG"));
    this->KbXnRxZPYN();
    this->tVlbctSIFkYc(string("YKTPMSMijStaVciBRfExZesajAtJzvWTsQgPDsTYCJMYNfGyVWpWBMSRGsvqpMkVIwdwVDKzyrMOCZVceqMBFdGauIwHEhJnKvOoBFpzcPRiTagMEWkHanHNKmvibZMvJmUWMpOpibGRmNScfyRxoRSilaSNGlzVDENjIWwWlLdjsEqimaNycznWiyLJqBEbwCaRjgGsraRffxELwBCWCdEUFSOPUGUpWUgtlFvBWSvcNsTBSWQkymvkL"));
    this->YBwnkTsVfgHlFpq(false, 716917.7037165591);
    this->NcSpNbmMm(374836.8912031161, string("FdqfYmxMCmVspFziODBUmTDxRSPi"));
    this->qzqVVDvJmFwKlKm(true, 1403642901, -390344.4296233797, -1512528911, 192648.4003626916);
    this->zHeOejRma(-382259.70890803135);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SvhKuWUBfPOA
{
public:
    double oayFrW;
    bool EVqIEmXkOTDqDC;
    double CFxsUrUYDvXSQVX;
    int tAFdMslykK;
    int zWbrkvxaVnlR;

    SvhKuWUBfPOA();
    int HAMFfyaokjfdEPm(int hwkTzugNPRnNxtm);
    double QgXOW(string TVQYtBtqmkw, bool qQPIbhJoMsxg, int EOdtCKcngZ, string KIFZBtaxGJyRxl, double LrZOZhKiIEz);
    string kmRqPv(bool vsbUzKFjMuhFBPm, double GpLVnYUn, double MrgHjl);
    bool odqcNZZakrxSJlSs(int kDeyzHx);
    bool gOnYCSxtt();
protected:
    double EXQaNMXmYcj;
    string GQCAVAWvTBHTdqA;
    bool SUZNB;

    void XWGJHtKQTi(bool MSNFZNcHnkMzk, bool qZykNSSXzxetr);
private:
    double WsFoLuV;
    double YZOVPhpkyEym;
    double OCNGpQexy;

    int cyTKzR(double LENkYtJgvGx, bool cKkBxyypdzFW, bool RgidUyRGTajAVl, string ULWWHMYQN, string bLeMUAeirC);
    string KmahGe(bool MACXLIszhnAJzz);
    string jneJBC(double VVQprzkmwRKBS);
    string Hgzgm(string wlEwXp);
    int jiAPZebTorx(double cGwpf, double uZjbAE, bool ETrou, bool MrKrHJZjAjsXGDDo);
    int vjccnThkIeP();
};

int SvhKuWUBfPOA::HAMFfyaokjfdEPm(int hwkTzugNPRnNxtm)
{
    bool IXqKkSXtbs = false;
    string ouiCPEb = string("qEgCLVdjBprhiyYnXWfeFUkmFdRfDsLbijEMwaGwVtpwfKLzZEmODNDDqYKWsebBnMbyqrdZoiAJRVQP");
    bool kPthO = false;
    int aGIEcjg = -2016673652;
    bool aszxLUNLZZskjJ = false;
    string tpMcuTub = string("swGqPZLQAsjedofbOEvKSgpUwcRHlOPUMjsXDObcbwWcFfszViAyqtkjdIrYYzftf");
    bool RbTHmJUsMCwxL = true;
    double eCitxPw = -775146.0450524719;
    bool ObisZjWb = false;

    for (int TDmOXMZmg = 447761675; TDmOXMZmg > 0; TDmOXMZmg--) {
        aszxLUNLZZskjJ = ! kPthO;
        ObisZjWb = ! RbTHmJUsMCwxL;
        ouiCPEb += ouiCPEb;
        tpMcuTub = ouiCPEb;
    }

    for (int xNAlUZCfkPilMhrj = 640573341; xNAlUZCfkPilMhrj > 0; xNAlUZCfkPilMhrj--) {
        kPthO = IXqKkSXtbs;
    }

    return aGIEcjg;
}

double SvhKuWUBfPOA::QgXOW(string TVQYtBtqmkw, bool qQPIbhJoMsxg, int EOdtCKcngZ, string KIFZBtaxGJyRxl, double LrZOZhKiIEz)
{
    double zfJXXevr = 862570.6027202074;
    int JQDnnrFkcqmqfq = 465855540;
    string eYltHnsBjvMsAnX = string("joIszbDhIQtaFKwCveepfNeiujxODTCvvZfudyzhIJGXx");
    string tHzOuwkNX = string("nlMoMyjWSximYHdArTLsIHZOcljOzCuxSpGVwcDRjNFOiovpFfGeUZQHEuZInOYGfcVyknpPGPkwRRqpJRqttCGjYzljAKtDgaiUaLlzeCkJFodeUihXWuzjywKZatOgqqPplNKZTdMJUSsRctOibQOVjVaShWAyQoYIXdqdLsNOgYgLpNHbQZlIgKhqStULEvnUXUG");
    int kcjgVIrYjAeGf = -79233391;
    int cpuDhuy = -326545881;
    double bhsmci = -651804.0828023195;
    int IbLQxPHiWYmrZEPQ = -466506395;
    bool JwjulBUvOFptk = false;
    bool GuGKDCkkqwmrGLHI = false;

    for (int njowb = 464846241; njowb > 0; njowb--) {
        LrZOZhKiIEz *= zfJXXevr;
        EOdtCKcngZ += EOdtCKcngZ;
    }

    return bhsmci;
}

string SvhKuWUBfPOA::kmRqPv(bool vsbUzKFjMuhFBPm, double GpLVnYUn, double MrgHjl)
{
    int XuBKcojVieMkyO = 1618269319;
    double vsXYuVbisDzNz = 137366.1096736274;
    int bSQhT = -844945064;
    int sbmpOk = -1659177886;
    string QFYeWbxhDHCV = string("KewdGIedEfOPaYAjvrZBDSMYPIIbBhcvpjWZqJjLXrJTDyOZWRXVYeZQooYpcsFONROhphschHQlKKpYZnRqMUiZlHQnpRDBXfBXUWaciFnNfheaHzTtrPGCnAqFDnJMeNLQauRtKDYAMfTlNBSSdMtaemSzTnnQykCwD");

    for (int rsUxbFdtTGUHozpP = 1157584922; rsUxbFdtTGUHozpP > 0; rsUxbFdtTGUHozpP--) {
        MrgHjl /= vsXYuVbisDzNz;
        GpLVnYUn -= vsXYuVbisDzNz;
    }

    if (XuBKcojVieMkyO <= -844945064) {
        for (int DdPipqXuG = 1718854492; DdPipqXuG > 0; DdPipqXuG--) {
            continue;
        }
    }

    if (GpLVnYUn == -471193.2174142717) {
        for (int lujRKJfWxETez = 1273302732; lujRKJfWxETez > 0; lujRKJfWxETez--) {
            MrgHjl = GpLVnYUn;
            QFYeWbxhDHCV += QFYeWbxhDHCV;
        }
    }

    return QFYeWbxhDHCV;
}

bool SvhKuWUBfPOA::odqcNZZakrxSJlSs(int kDeyzHx)
{
    double ZMtEeaoivihY = -877946.5306849822;
    int DvZdjngdJenLfvR = 1256048855;
    bool uiNvcCfWNyi = false;

    if (DvZdjngdJenLfvR > -984508166) {
        for (int RtRMFWmFu = 522997871; RtRMFWmFu > 0; RtRMFWmFu--) {
            kDeyzHx /= DvZdjngdJenLfvR;
            kDeyzHx /= DvZdjngdJenLfvR;
        }
    }

    return uiNvcCfWNyi;
}

bool SvhKuWUBfPOA::gOnYCSxtt()
{
    string ndgRCjnB = string("QGXrZeaqlmrlSIfUBsestfnDVkfkZcAySpPjCSzvpMHLPxLevHxEjZkEuBvRItYZWwmOoHnhhwNDEZqNNcMeXZWeJXsnlAtdpXrEwNrxvOIitKLmgRupxTRQeVzKECWBJOFZjXgUaddTJFaWgBvvVntlKtwaqOzTjMkpRjMUWuUYEUSdjQzUJZt");
    string LsBWKLYHhMhUioB = string("RfhBPAevHjjqbqlfxywdwxDAZovlHdmDRyyUcCuCCSnFldmduelTpbFqGIAOkfcYMpmqSqWZjJwQdPnRpgeQR");

    if (ndgRCjnB < string("RfhBPAevHjjqbqlfxywdwxDAZovlHdmDRyyUcCuCCSnFldmduelTpbFqGIAOkfcYMpmqSqWZjJwQdPnRpgeQR")) {
        for (int UllSNQJuSgqvJ = 1584322836; UllSNQJuSgqvJ > 0; UllSNQJuSgqvJ--) {
            LsBWKLYHhMhUioB = ndgRCjnB;
            ndgRCjnB += LsBWKLYHhMhUioB;
            ndgRCjnB = ndgRCjnB;
            ndgRCjnB += LsBWKLYHhMhUioB;
            ndgRCjnB += LsBWKLYHhMhUioB;
        }
    }

    return true;
}

void SvhKuWUBfPOA::XWGJHtKQTi(bool MSNFZNcHnkMzk, bool qZykNSSXzxetr)
{
    bool wLFCXxPTRA = false;
    bool jdXaBwWYSKCdf = false;
    bool AKeYakzdHslNAmyh = true;
    bool UQhMUrUXyGTLdQfP = true;
    double fUxcOZlfU = -118926.97311433546;
    int ubUvbgLD = -655709422;
    double MueBuAPg = -714434.3846819743;
    int ERojbamtQ = -2069725618;
    string rCrLigDIRZBCU = string("tUKrPIUpCzVgVktRdpOgxdhRWmzllAkgtfSByXcaMCImYimUzsTWFdAhUSinRucgUNpshgRZtgbpgrGYIFPLAWvWqpUbTfQGHbeejpzJJMSkEoWzDOqVcfBwggznQrxWBjDZprQyANEHvQVDWLeIxASkHbxcZozDMeYszYzACSo");
    string fgTzBEDzGix = string("jRoJDCKQXlSJbwvzuWNfZvuvcZpXrapJzLBnFEYXAiDSTNvsCgzUcloQMdRSlWzymiLkbOtemvtJonUJQFelOSCLMhBTfxrUZEgQDyrngycjQsXCoETeWxneUAMXayCCSjCVmzplmBtZixOnlAbCIxllkEurSydtsWISddkEeHgeDSTlCbCROwoqotkUwYrjxtfVImsiDPIvLGFmmwgqBHwwXTPWxNUWnag");

    for (int pURsOVlRhS = 1187728772; pURsOVlRhS > 0; pURsOVlRhS--) {
        MSNFZNcHnkMzk = MSNFZNcHnkMzk;
        jdXaBwWYSKCdf = UQhMUrUXyGTLdQfP;
        wLFCXxPTRA = wLFCXxPTRA;
        jdXaBwWYSKCdf = qZykNSSXzxetr;
    }

    if (rCrLigDIRZBCU <= string("jRoJDCKQXlSJbwvzuWNfZvuvcZpXrapJzLBnFEYXAiDSTNvsCgzUcloQMdRSlWzymiLkbOtemvtJonUJQFelOSCLMhBTfxrUZEgQDyrngycjQsXCoETeWxneUAMXayCCSjCVmzplmBtZixOnlAbCIxllkEurSydtsWISddkEeHgeDSTlCbCROwoqotkUwYrjxtfVImsiDPIvLGFmmwgqBHwwXTPWxNUWnag")) {
        for (int SMQnthJ = 291866555; SMQnthJ > 0; SMQnthJ--) {
            fgTzBEDzGix += fgTzBEDzGix;
            fgTzBEDzGix = rCrLigDIRZBCU;
        }
    }

    for (int lNnkdTdefrYp = 1532917857; lNnkdTdefrYp > 0; lNnkdTdefrYp--) {
        AKeYakzdHslNAmyh = ! qZykNSSXzxetr;
        jdXaBwWYSKCdf = jdXaBwWYSKCdf;
    }
}

int SvhKuWUBfPOA::cyTKzR(double LENkYtJgvGx, bool cKkBxyypdzFW, bool RgidUyRGTajAVl, string ULWWHMYQN, string bLeMUAeirC)
{
    double rPYLwYorrsh = 503983.4325889356;
    bool oknnThet = false;

    for (int CXqFgnwLNuMoQyz = 607372279; CXqFgnwLNuMoQyz > 0; CXqFgnwLNuMoQyz--) {
        continue;
    }

    if (cKkBxyypdzFW == false) {
        for (int iKBmX = 2101015575; iKBmX > 0; iKBmX--) {
            continue;
        }
    }

    if (ULWWHMYQN != string("lMHqyzlKBLzFbnqXsaxbWGiwgoUGzVcZYRPskviBXSiaoyZgBmDysSYzTjyWAWLRsYwXuTXYXDjwzKkSEVOeoPlOwtxjWjSjtWETKWMKxDyqOuOwYInFALZlcnalYIyfeqOonqzPXtElCkCEIWqlhpLiMprWOFGHlbteOZKuyBXzNthRqhkOwojeueIFrAdTRCTKRtMkhCwCIbByzwt")) {
        for (int RYTbsnIZtMCkgd = 2134959255; RYTbsnIZtMCkgd > 0; RYTbsnIZtMCkgd--) {
            LENkYtJgvGx /= LENkYtJgvGx;
            LENkYtJgvGx *= LENkYtJgvGx;
            LENkYtJgvGx -= LENkYtJgvGx;
        }
    }

    return 469387565;
}

string SvhKuWUBfPOA::KmahGe(bool MACXLIszhnAJzz)
{
    double GUULU = -126661.26075949395;
    int XMNzmvpZbpq = 1413524256;
    int MdWYK = -1546590318;
    string CrXtdWfbqIe = string("zldYWnlWNvXIkwdzRDBXkwDlqdPkerdfovNuAxCnmnSYrrXPNmCMDtrrKbVbyMEJOOLehjILuzXEMNchQkueotRxUMUWkwzzWfPhgEmaRgKvYZxuptHkzsxJtwqCxLaJVcuKjHpQiMYiRYIeKTtcXSCpleQNmBuDZCrrrjCoPDRwKtKlCNquLFvm");
    bool vVRMp = true;

    for (int aaUsfhE = 1133852153; aaUsfhE > 0; aaUsfhE--) {
        CrXtdWfbqIe += CrXtdWfbqIe;
    }

    for (int gZyEpsDFLFNLSQH = 1199415485; gZyEpsDFLFNLSQH > 0; gZyEpsDFLFNLSQH--) {
        continue;
    }

    if (GUULU != -126661.26075949395) {
        for (int mJnlQrPKSeaUzY = 1339129363; mJnlQrPKSeaUzY > 0; mJnlQrPKSeaUzY--) {
            MdWYK += XMNzmvpZbpq;
        }
    }

    for (int gfgiepXdv = 426015127; gfgiepXdv > 0; gfgiepXdv--) {
        XMNzmvpZbpq -= MdWYK;
    }

    return CrXtdWfbqIe;
}

string SvhKuWUBfPOA::jneJBC(double VVQprzkmwRKBS)
{
    bool eTWhwQ = false;
    double RAouhjksLPikuO = -80700.30050002606;
    double cTFTUtbLyW = 862122.5773063716;
    string rwdlxcUmKwnuiD = string("xLvKVCzYCZnLfbmc");
    double aTgPhco = 790044.3458628552;
    bool DjomcEBtbAEduD = false;
    double qPjLWjfFUybdEhT = -66264.37403631248;
    int ptsCgQApMvtAwnG = 238395281;
    int ipRXIiseqjdpTgps = 994344681;

    if (VVQprzkmwRKBS <= 862122.5773063716) {
        for (int sJKYSJkHG = 1388846031; sJKYSJkHG > 0; sJKYSJkHG--) {
            qPjLWjfFUybdEhT /= qPjLWjfFUybdEhT;
            cTFTUtbLyW = RAouhjksLPikuO;
            aTgPhco = RAouhjksLPikuO;
            VVQprzkmwRKBS -= cTFTUtbLyW;
            VVQprzkmwRKBS = qPjLWjfFUybdEhT;
            qPjLWjfFUybdEhT *= aTgPhco;
        }
    }

    for (int uWtqRRDeZnaCvC = 1266394331; uWtqRRDeZnaCvC > 0; uWtqRRDeZnaCvC--) {
        continue;
    }

    for (int BjNExOyyiCmE = 1306136215; BjNExOyyiCmE > 0; BjNExOyyiCmE--) {
        DjomcEBtbAEduD = ! DjomcEBtbAEduD;
        aTgPhco *= VVQprzkmwRKBS;
    }

    return rwdlxcUmKwnuiD;
}

string SvhKuWUBfPOA::Hgzgm(string wlEwXp)
{
    bool vUrNBQdTIrewTzI = false;
    bool CgAqlO = true;
    string uzDlpzU = string("PsErkrQRlPxUslRfdFEvfHpsVLfLkrJvioFFqqmJqSOJWKlZANOujYrhgkfRARJPVMMolXTofcllbLLUHtovnbZHpdnwXtTgiHPJAmEkiCqubUcDqdOwYKEaQSrIkQJ");
    double wAggwceZdvdJ = 228907.14272792405;

    for (int OORmauxTyhPHpqM = 531872274; OORmauxTyhPHpqM > 0; OORmauxTyhPHpqM--) {
        continue;
    }

    for (int sfHXSrP = 1693076597; sfHXSrP > 0; sfHXSrP--) {
        wlEwXp = uzDlpzU;
    }

    return uzDlpzU;
}

int SvhKuWUBfPOA::jiAPZebTorx(double cGwpf, double uZjbAE, bool ETrou, bool MrKrHJZjAjsXGDDo)
{
    double coQfaonH = 324406.825522551;
    int rWXnmlsslSqPOS = -1165520008;

    for (int whPBzNMJxwTufXml = 1124683341; whPBzNMJxwTufXml > 0; whPBzNMJxwTufXml--) {
        uZjbAE /= coQfaonH;
        cGwpf /= coQfaonH;
        MrKrHJZjAjsXGDDo = ! MrKrHJZjAjsXGDDo;
        cGwpf /= coQfaonH;
        uZjbAE /= uZjbAE;
    }

    for (int FoedTUYXxeIkPi = 1099893401; FoedTUYXxeIkPi > 0; FoedTUYXxeIkPi--) {
        uZjbAE -= cGwpf;
        cGwpf /= uZjbAE;
        coQfaonH /= coQfaonH;
    }

    for (int BswNizzP = 857330511; BswNizzP > 0; BswNizzP--) {
        ETrou = ! MrKrHJZjAjsXGDDo;
    }

    return rWXnmlsslSqPOS;
}

int SvhKuWUBfPOA::vjccnThkIeP()
{
    string hAQkMxcaF = string("ShfrTVrjVBRapXOqXSTqLKYcaGHfQPSTqReQJuLZTVBHhkHAiZZznLrpERsTFPnwYhLLjEhYibjomgOTQlFChDqJRVoFUjhAPwECMdbWRqPCBrQyEdqoXVHYIPUkXsnoSRlIHbeqaEYtXqYzqaMjWJVIengsoypjTzXuOqrEXLcXxY");
    bool OQKCakHtMXw = false;
    string zITMnza = string("cNMaFlQFrCxbPqWQtRsxSYBUcZXyvIPZwTBOSuOTCrWpIaaiyGUrzcKJozhzrzWtIQNNlmEXXJCNHMIwKGQZjQoBzuhGKmHFXKoHDKmvIDcIXJfNUaUhnNnVHpKgXYkgKZQvbLSArFQNIfpoOqNBIlyaGgeEihlETNiGPDGRvleerYXjwxVMJR");
    bool TlVajxQLxWbsyCO = true;
    int VerLQxJPNOADcfjL = -978544167;
    bool yyYucyOcWO = true;

    for (int hOuBqvY = 238356248; hOuBqvY > 0; hOuBqvY--) {
        zITMnza += hAQkMxcaF;
        OQKCakHtMXw = yyYucyOcWO;
    }

    return VerLQxJPNOADcfjL;
}

SvhKuWUBfPOA::SvhKuWUBfPOA()
{
    this->HAMFfyaokjfdEPm(2010602298);
    this->QgXOW(string("ZfVqnJQqLboKPeZAKnUzkfCzQmpWHNBNFklTdByBxJjNOVyOKZuCSGiQDmHgZMeTtRSLJujuglPpgvxUGpJgqLiENLjTnYEKmRpvCCTPlBCVmRlwWxEUNCJSOLLTIRKLZVjYhWkMhGfcwerBfysgApMPwKbuAIOZwqLWnSLpNgugZDapeSXvcUvbcCRpgreGShIKhUhjeDCneHYPxtJRVcT"), false, 840566037, string("RpFKHlYIRBYvuqyQebWTzVCWwDdAlzKKZFQscbIFupFpxsgJOnGIpBKsRDnTefqdINQzudNkjlYqidedGAXOoxqwradfxktuKWGfCYvZhfaOelFnYJOSxDGAeZPteviGLVVJBMnWRKoQxbPrmusmIwoUAykOJmPmfcTryyyVQbSDOWiKnGppaugYgPDyIBUHfraItEOqm"), 444368.1806574278);
    this->kmRqPv(true, -496239.0947142559, -471193.2174142717);
    this->odqcNZZakrxSJlSs(-984508166);
    this->gOnYCSxtt();
    this->XWGJHtKQTi(false, true);
    this->cyTKzR(-44077.93610545348, true, false, string("gmFXiuhQCvDTZZlCaHlFrKXGKLQSOYxcVqJcSlxqiLZISQwpNjGdbLcaAzRispUYVBybycJrkUpUHSSgwFAJnfWaCqpfrDyCKLYdoE"), string("lMHqyzlKBLzFbnqXsaxbWGiwgoUGzVcZYRPskviBXSiaoyZgBmDysSYzTjyWAWLRsYwXuTXYXDjwzKkSEVOeoPlOwtxjWjSjtWETKWMKxDyqOuOwYInFALZlcnalYIyfeqOonqzPXtElCkCEIWqlhpLiMprWOFGHlbteOZKuyBXzNthRqhkOwojeueIFrAdTRCTKRtMkhCwCIbByzwt"));
    this->KmahGe(true);
    this->jneJBC(-194845.5373256364);
    this->Hgzgm(string("tjoDjWexRTAOZCpFgesPWACOwNeXwaGRpfIZhMSdlpTidhCgTnGuqQySPVovfCMhfghtoNQMhjhEdTkEHxnomBpViuyqGeKSuQJ"));
    this->jiAPZebTorx(866179.9205286807, 1001571.7191727895, true, true);
    this->vjccnThkIeP();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YWmvoqhyuBj
{
public:
    bool AHnLOvg;
    bool ZDGjJDxVvATiKzk;
    int yHeiucv;
    string mvdtqpHkEUSLpyL;

    YWmvoqhyuBj();
    bool TrrVsefspxKCmqMB();
protected:
    string NODSGNwKKlpP;
    string YgJdAeodpmjwX;
    string nhgshuUdYOo;

private:
    bool GmGBOq;

    double LOUbPrzumhLQK();
};

bool YWmvoqhyuBj::TrrVsefspxKCmqMB()
{
    double hvFUdnQScLORi = 279654.1936124571;
    int UCitlU = 510143346;
    int vZqJwjFNVYvXmy = 159554151;
    bool GfqNYkOScMQMOtvJ = false;
    string eFuoUrOWUX = string("ocPQtGvTNWsPluwqbkfIpTLKdfhHrWTnHNzTnxmiACxYsJdilfcIjydoYadHmUYRkRWTciOifBURcMFbYqqglaAflKcErntZZcJnAAqmDJYUxULsTKqWuuXWHbGZOPoPSLSBpzEEugTzsdykGQsOwQTLVlYYlrFLrLLyEgmTQPuCTTvXfbLzPFDBugUACHbrjXuUCEIMcbLvGWPzKxdEeWVpyziPOEtqZWnVjiWOoChLsABrO");
    double hxpdcmcgPPWNi = 39790.72129945978;

    if (hvFUdnQScLORi >= 279654.1936124571) {
        for (int VOZIpTojdJh = 967921278; VOZIpTojdJh > 0; VOZIpTojdJh--) {
            hvFUdnQScLORi = hvFUdnQScLORi;
        }
    }

    if (vZqJwjFNVYvXmy > 510143346) {
        for (int BzAssVsvHbhnNj = 434877655; BzAssVsvHbhnNj > 0; BzAssVsvHbhnNj--) {
            UCitlU += UCitlU;
            hxpdcmcgPPWNi *= hvFUdnQScLORi;
            eFuoUrOWUX = eFuoUrOWUX;
        }
    }

    if (hvFUdnQScLORi > 279654.1936124571) {
        for (int tSZoArNObffu = 1103180261; tSZoArNObffu > 0; tSZoArNObffu--) {
            vZqJwjFNVYvXmy = UCitlU;
        }
    }

    return GfqNYkOScMQMOtvJ;
}

double YWmvoqhyuBj::LOUbPrzumhLQK()
{
    double sOfiMVupHiwwWoPw = 381543.99388213543;

    if (sOfiMVupHiwwWoPw > 381543.99388213543) {
        for (int qrfVS = 25486683; qrfVS > 0; qrfVS--) {
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw = sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw -= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw -= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw /= sOfiMVupHiwwWoPw;
        }
    }

    if (sOfiMVupHiwwWoPw > 381543.99388213543) {
        for (int NgcbgDttVgVKiPDy = 579547814; NgcbgDttVgVKiPDy > 0; NgcbgDttVgVKiPDy--) {
            sOfiMVupHiwwWoPw /= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw -= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw *= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw = sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw -= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
        }
    }

    if (sOfiMVupHiwwWoPw != 381543.99388213543) {
        for (int QNAfivuIZGkFvutV = 1036764909; QNAfivuIZGkFvutV > 0; QNAfivuIZGkFvutV--) {
            sOfiMVupHiwwWoPw -= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw /= sOfiMVupHiwwWoPw;
        }
    }

    if (sOfiMVupHiwwWoPw < 381543.99388213543) {
        for (int qQhmkqyfJbg = 2040276407; qQhmkqyfJbg > 0; qQhmkqyfJbg--) {
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw -= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw *= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw *= sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw += sOfiMVupHiwwWoPw;
            sOfiMVupHiwwWoPw -= sOfiMVupHiwwWoPw;
        }
    }

    return sOfiMVupHiwwWoPw;
}

YWmvoqhyuBj::YWmvoqhyuBj()
{
    this->TrrVsefspxKCmqMB();
    this->LOUbPrzumhLQK();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qgQLvTYA
{
public:
    string YjhfKDv;
    double oTxgGeDXINCx;
    double myoIsNNlsTZKund;

    qgQLvTYA();
protected:
    double sNstlMY;

    void nGqZZjkdsgDnZeQN(bool PbMUg, double DkYHHzbLPMCYS, bool ovXXiTQEL);
    string egwrqqAD(double ZQhTwkDDHa, int WqHkISEqYRU);
    double CaRTVajWcoOlMMXt(int RKHMw, string NJMOxDCJ, bool IlNTuN);
    string JjNLLKvRWjTGhqR(string SjeWXdpzn, double pfHZeSwVtDto);
    bool GylkF(bool RAzwXNfZ, string xplnrawp, double JXURZtU, string upTqtqOuRxzOFHN, string MCdHloOEHFYwcXSU);
    void cAJAMc(bool PCfexTBwN);
    int LIjVJrlkPvs();
    void yjbLHn();
private:
    string EIikrrxUR;
    double PGUPXBynTekQITJ;
    double pdEykZjmT;
    int XkyoizJAewkZBZ;
    double bjrzjurBimV;
    int jJAUOFJ;

};

void qgQLvTYA::nGqZZjkdsgDnZeQN(bool PbMUg, double DkYHHzbLPMCYS, bool ovXXiTQEL)
{
    int QrUDDypkY = -465559311;
    double gTEXWiPcVpsVd = 61483.86512346628;
    double CcxtIZpmNDzz = 551983.0634518001;

    if (CcxtIZpmNDzz >= 719745.5448817012) {
        for (int LXeRqERrb = 1198468812; LXeRqERrb > 0; LXeRqERrb--) {
            DkYHHzbLPMCYS -= gTEXWiPcVpsVd;
            gTEXWiPcVpsVd = CcxtIZpmNDzz;
        }
    }
}

string qgQLvTYA::egwrqqAD(double ZQhTwkDDHa, int WqHkISEqYRU)
{
    bool oVPUchaqpcH = true;

    if (WqHkISEqYRU == -1406449618) {
        for (int nteFYgzhdF = 1439643487; nteFYgzhdF > 0; nteFYgzhdF--) {
            WqHkISEqYRU += WqHkISEqYRU;
        }
    }

    if (oVPUchaqpcH == true) {
        for (int RIkcP = 784910100; RIkcP > 0; RIkcP--) {
            ZQhTwkDDHa *= ZQhTwkDDHa;
            WqHkISEqYRU = WqHkISEqYRU;
            ZQhTwkDDHa += ZQhTwkDDHa;
        }
    }

    for (int dDlaQxzmogR = 1025410294; dDlaQxzmogR > 0; dDlaQxzmogR--) {
        WqHkISEqYRU += WqHkISEqYRU;
        oVPUchaqpcH = oVPUchaqpcH;
    }

    return string("SCqxjiXZAkubjAoLMlXjafTiIlWDjCEsgjzCDnfzSoSTNtkjnZAXdAujSJdaEmVKQajVbAtjXMrliZAJTozxtJnhxXm");
}

double qgQLvTYA::CaRTVajWcoOlMMXt(int RKHMw, string NJMOxDCJ, bool IlNTuN)
{
    int yLWMWAHP = 1519030843;
    double BkTKYOaxMg = 396914.3166414745;
    string HgSIoeOWTBljlK = string("nvIlNIGctCdtdVqStIvlyGjOeBkKgbqvqtmpTFYSxgnKzvO");
    int rxzuygkhpjQyvF = -107001050;
    double nsUhMvjad = -791179.9761928146;
    int hrgabgPPf = -1129683391;
    string nHIIKSM = string("ThORraefkcqXSNxBXuTLeacwKhdqgdesXNOzomBFlghDylHxKVkYPfQlfJwvZpoSHsuqIwzZSFteHYGMZGGHhygfvSIxEMJAiJGxEzQmPjMVYVUahINDCQmnGFZXZGMYxpItFsTQnELQYiGoLHxyAiUbkSdHgaicqczzitNviHSbNzrfCXTpkWzhWulvNuhcySRNBOGcxnxFUaNZqmxNVb");
    double PzoMOPlkIbVB = -1037226.6160863145;
    double llMvUBv = -165163.76875848832;

    if (nsUhMvjad > -165163.76875848832) {
        for (int WnqrmtzaNzkIP = 980670686; WnqrmtzaNzkIP > 0; WnqrmtzaNzkIP--) {
            continue;
        }
    }

    return llMvUBv;
}

string qgQLvTYA::JjNLLKvRWjTGhqR(string SjeWXdpzn, double pfHZeSwVtDto)
{
    double gOLaUwKYF = -812603.9441142372;
    bool bKfWpRkjhT = true;

    for (int UaAbzNhgTmFc = 112550965; UaAbzNhgTmFc > 0; UaAbzNhgTmFc--) {
        gOLaUwKYF = pfHZeSwVtDto;
        bKfWpRkjhT = bKfWpRkjhT;
        gOLaUwKYF /= pfHZeSwVtDto;
    }

    if (gOLaUwKYF <= 93212.46706843517) {
        for (int pwMmaZBrv = 631221731; pwMmaZBrv > 0; pwMmaZBrv--) {
            SjeWXdpzn = SjeWXdpzn;
            pfHZeSwVtDto /= gOLaUwKYF;
            gOLaUwKYF += gOLaUwKYF;
        }
    }

    for (int fpGMAdcxBU = 323414866; fpGMAdcxBU > 0; fpGMAdcxBU--) {
        gOLaUwKYF = pfHZeSwVtDto;
        bKfWpRkjhT = ! bKfWpRkjhT;
    }

    for (int cjHpDKB = 2068460465; cjHpDKB > 0; cjHpDKB--) {
        pfHZeSwVtDto -= pfHZeSwVtDto;
    }

    return SjeWXdpzn;
}

bool qgQLvTYA::GylkF(bool RAzwXNfZ, string xplnrawp, double JXURZtU, string upTqtqOuRxzOFHN, string MCdHloOEHFYwcXSU)
{
    string zzBqOkYM = string("FmwhxcUqxCguYmvGGiVjZNGICQlYKKfVJDlvjZjeiRpdrtcTVcMsYDdgOpOIbcoUOUzgwTUjeHMaNvKJbyyVMNRBCaBsxLskiMYYtctOPEdjtoydegAoMbnkrVMEdDJPnsjDZVDXTStUdDlteodfDiGGFdhKpvuIGrKrKCmAkBjGzySzpgxJyIiCQkbVQLtWpaM");
    string WXOSSfQ = string("NEntOfFVLwkBRQSCRRJEZfbIcXviOqwVkIMeZCVDYywpwIZchSYMcYuQNEphasRreizDQsJcWXMrGAvdSYDVHeZrbuaYeDirOqoRlstPNHZTlMxtrhzWumihXzeGAZJHDZzpthtHYQcPNHFxAUihkQwcCfxVpnsgRgTuIY");
    string uCQPvG = string("fAuGdJoiDODAuhMEnpAccxZNBUrXpyCEDgIFalpohMEudrgqFVIISclafTWOcLUGrWyYLlSFIZguBOXAj");
    int SnXnJzfKCqyCUR = -734848738;

    for (int TFNjw = 739136585; TFNjw > 0; TFNjw--) {
        MCdHloOEHFYwcXSU += MCdHloOEHFYwcXSU;
        zzBqOkYM += xplnrawp;
        JXURZtU /= JXURZtU;
    }

    for (int fIHToI = 946168796; fIHToI > 0; fIHToI--) {
        MCdHloOEHFYwcXSU = xplnrawp;
        xplnrawp = MCdHloOEHFYwcXSU;
    }

    if (zzBqOkYM >= string("wZUCNtllfFybwVBsQvPIajMtMZEPGCjCCsQPThCTjOtacKAIKjVGoeDNCWIXPWgJPKyqPMQHtARJPLMqrgkgqheIERBnyqCUbaXAJrIQyjmCFStLJcoTkqtEXRsETpjgqfBHuXJKGCpdngWwzfdygKWLJKluFGiXjxYENFVtVjRhVLCHpvUqAhiWEOSfigMidfSrqiQuoanyRanBottDEWYjSPEc")) {
        for (int bbGvPNnC = 945575900; bbGvPNnC > 0; bbGvPNnC--) {
            MCdHloOEHFYwcXSU = uCQPvG;
        }
    }

    for (int JoIzJLkDDjVux = 439561761; JoIzJLkDDjVux > 0; JoIzJLkDDjVux--) {
        WXOSSfQ += WXOSSfQ;
        WXOSSfQ = upTqtqOuRxzOFHN;
        upTqtqOuRxzOFHN = uCQPvG;
    }

    return RAzwXNfZ;
}

void qgQLvTYA::cAJAMc(bool PCfexTBwN)
{
    int LrPDNyakGTszkQc = 987408180;
    bool nGsNgTJTdkmYDM = true;
    bool oGbacqOhr = true;
    int SCLZhmjsCiP = -1104714438;
    double iwvlKbDYFSpBI = -359096.8208815472;
    string fbULDLBx = string("vMerBMrxpfIkMrIspHLpJELlOzKNnroKkevRulZvYRjbmarEQnzSGddCzCbaTBBdiTMAUTYcdlECfXmDcSQBroQoAJDEtqlKlRLybHfirlVtDacbKprqMDzHiJoZSTRsZjXBWNomSLIMfGArNfcqHvXHAZmJlPivnsfaRMieGEQDNAPxiQZFyyYAbrascYqEGKhCzqumxwJgQRaBNRGtV");
    double XrpYJzyxkFPa = 758094.7435389104;
    bool WRMoBol = true;
    string zpADvEbRhHT = string("NtwvjajqyqzIqlIlRizolbieUeFSkcbooqsDYKlytfHsyDJIWGieEUWEUaEUpLCDf");

    if (LrPDNyakGTszkQc == -1104714438) {
        for (int uBAcSMApLn = 315488238; uBAcSMApLn > 0; uBAcSMApLn--) {
            fbULDLBx += zpADvEbRhHT;
        }
    }

    if (nGsNgTJTdkmYDM != true) {
        for (int kmjoFZKuF = 1411140262; kmjoFZKuF > 0; kmjoFZKuF--) {
            continue;
        }
    }

    if (oGbacqOhr == true) {
        for (int oTkGiyVQsSJKZei = 1168505070; oTkGiyVQsSJKZei > 0; oTkGiyVQsSJKZei--) {
            oGbacqOhr = ! WRMoBol;
        }
    }
}

int qgQLvTYA::LIjVJrlkPvs()
{
    double jrtMvXLuwVw = -713226.1475189463;
    int IjOjxTzgHRy = 1558663921;
    string fIlEe = string("WUaUfohBhTmgeHyDyKdkloxxTIYfgnLBQSXmVIdpnjOSADn");
    string uqVeXO = string("vfZKsRsMdgqGtQjbRzszfNzeYDHOZMOPzYdtIPursGFDDAOWyWdlQhzaJUOMYuXvZoHennhZyfRvTsQNhCXypjmqqbRfJkWZaTBbsamHTQVIQMOoOBjCyxxNJqhxurOtcZkpoLPucsFboOWQAaZFNnZmX");
    double YUwjRJSRRZlWpD = 749671.1109671668;
    double MNIQhaLYZOxECli = 689166.90723098;

    if (fIlEe == string("WUaUfohBhTmgeHyDyKdkloxxTIYfgnLBQSXmVIdpnjOSADn")) {
        for (int NedIyTzkeK = 1117181819; NedIyTzkeK > 0; NedIyTzkeK--) {
            jrtMvXLuwVw += YUwjRJSRRZlWpD;
            fIlEe += uqVeXO;
            MNIQhaLYZOxECli -= YUwjRJSRRZlWpD;
        }
    }

    for (int HergjIHe = 1298138682; HergjIHe > 0; HergjIHe--) {
        continue;
    }

    return IjOjxTzgHRy;
}

void qgQLvTYA::yjbLHn()
{
    int abrFBJMKr = 1092966664;

    if (abrFBJMKr != 1092966664) {
        for (int wUmuKVflXnSjny = 1029155466; wUmuKVflXnSjny > 0; wUmuKVflXnSjny--) {
            abrFBJMKr -= abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr -= abrFBJMKr;
            abrFBJMKr = abrFBJMKr;
            abrFBJMKr = abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
        }
    }

    if (abrFBJMKr > 1092966664) {
        for (int iytQVfkYjV = 967043159; iytQVfkYjV > 0; iytQVfkYjV--) {
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr -= abrFBJMKr;
            abrFBJMKr *= abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
        }
    }

    if (abrFBJMKr == 1092966664) {
        for (int GRvZmRCxkfbEfi = 1474582539; GRvZmRCxkfbEfi > 0; GRvZmRCxkfbEfi--) {
            abrFBJMKr -= abrFBJMKr;
            abrFBJMKr -= abrFBJMKr;
        }
    }

    if (abrFBJMKr >= 1092966664) {
        for (int nPfXoQLEm = 1021193302; nPfXoQLEm > 0; nPfXoQLEm--) {
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr *= abrFBJMKr;
            abrFBJMKr *= abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
        }
    }

    if (abrFBJMKr != 1092966664) {
        for (int qxbarVagLB = 1568776940; qxbarVagLB > 0; qxbarVagLB--) {
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr /= abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr += abrFBJMKr;
            abrFBJMKr = abrFBJMKr;
        }
    }
}

qgQLvTYA::qgQLvTYA()
{
    this->nGqZZjkdsgDnZeQN(false, 719745.5448817012, false);
    this->egwrqqAD(685716.2893217354, -1406449618);
    this->CaRTVajWcoOlMMXt(-572005551, string("LbGSsscEOlPXndBubazRqpwzfIPxqGBFseEyczhxbBQgzVnrJJtfLNQobJwNYHKPGxdHurrxrmXlFMGrMWirfJygjlBVyPZRLZYzOEbOCKKnvrzjcYLxKAAixzSmqrmMUpXLirMthVhOROzavhMLOLVpAIFgtOHUwbQgNEnFeNSQPyZFYqiqCCvczULWjVPXABRJGKGkJwyFANVoZcCMiG"), false);
    this->JjNLLKvRWjTGhqR(string("yFLxbdqVaGPTZSWyLfDJzWPRJLsjwJaibfhvDACvVCMoSYhOysvBdgTVIVMQLyHOTIujLkdCAlWseNumMztcqVVLJoJhxdDOlwwPWEswuryhwdDDCHwEGtAWaAfwi"), 93212.46706843517);
    this->GylkF(true, string("EaqQIRAx"), 535250.1423510221, string("QjaOogiafPCbTESdXEDHxewpruTaXcpxaMYjbsbiPzFWdGCwwSJYqKBKQnIZqGuRXcUvoeMrkodmCWySEwYvkkMVZXtXtnUUBvgpIyABKssKXudgRhHQbnhZKvaSqoDXLGEVrRsYIKlYMZLErqwOLbqemOTKgNqicHhVVkTCWAKKeUdgVACOMnDeGtsCQEEhsPHqfJD"), string("wZUCNtllfFybwVBsQvPIajMtMZEPGCjCCsQPThCTjOtacKAIKjVGoeDNCWIXPWgJPKyqPMQHtARJPLMqrgkgqheIERBnyqCUbaXAJrIQyjmCFStLJcoTkqtEXRsETpjgqfBHuXJKGCpdngWwzfdygKWLJKluFGiXjxYENFVtVjRhVLCHpvUqAhiWEOSfigMidfSrqiQuoanyRanBottDEWYjSPEc"));
    this->cAJAMc(false);
    this->LIjVJrlkPvs();
    this->yjbLHn();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iYCQzeEQxDdLV
{
public:
    double GoSeyjJxtroUtuCt;
    string jwKzDNaP;

    iYCQzeEQxDdLV();
protected:
    int cIgyOUnKfENshGp;
    bool WDyQqeVKlfuue;
    string NibYdCxbMsH;

private:
    bool kHYbqdARxAupv;
    int nEjUxt;
    int FrQDDHQBxT;

    double GVAjkoQooCEImbf();
    string VeHJLnImoYapd(int hBlnu, string YKFJz, bool SDvMWmhiA, bool wYfZaqTQZ);
    int mUutWoRKVliYpqF(int dDxiSQWjl, double ZaGNy, int fsFjRmpzKac);
    bool wrnddiEWanPv(int ApcsverWvJLIEd, bool fNzaxSsQkQf, bool mhFMVjPYcfZuv, int VRdxjtBNVKGIw);
    int QPqHEVFjiTGTD(string zenVxJXQRGcpuq, int pqMmdgIxJKFt, string ClqdfIyIlivTyw, string PhQYTXkp, bool SfqByKpkoajaJkL);
    string HPXPWaNSXRNl(int tVHoy, double djbphAQetbx, string ttmKwSMNRoxF);
    string EYIMdnCKroFOLqbQ();
    string eCpZLjFcmEsyx(double oDfWyUTikpweB, string BglDCoEiqA, string UwcKsbhsd, bool bqIkS);
};

double iYCQzeEQxDdLV::GVAjkoQooCEImbf()
{
    string qVdhXRFiGgHV = string("DLQvuJRVpkNWVPQeFOYrYGwbUXdLdjaYuPdOCwAVMIKPKjnumXOByZdLTbZZCLVMHCZtLMQesytpmFHIhZdFhtSmOLMMHRwoqLEaZVEZoRVznZyjUvdHQKcjnTWVjRKlqaAJIfjmIODlzc");
    bool ydRHbYalWYZs = true;

    for (int nomXTYNQIS = 19230372; nomXTYNQIS > 0; nomXTYNQIS--) {
        continue;
    }

    for (int PoXJsMSA = 807315290; PoXJsMSA > 0; PoXJsMSA--) {
        continue;
    }

    for (int mJGgANJGsj = 2070393860; mJGgANJGsj > 0; mJGgANJGsj--) {
        ydRHbYalWYZs = ! ydRHbYalWYZs;
        qVdhXRFiGgHV += qVdhXRFiGgHV;
        ydRHbYalWYZs = ydRHbYalWYZs;
        qVdhXRFiGgHV += qVdhXRFiGgHV;
        qVdhXRFiGgHV = qVdhXRFiGgHV;
        qVdhXRFiGgHV += qVdhXRFiGgHV;
    }

    if (ydRHbYalWYZs != true) {
        for (int NGSXTcocmE = 320768792; NGSXTcocmE > 0; NGSXTcocmE--) {
            ydRHbYalWYZs = ! ydRHbYalWYZs;
            qVdhXRFiGgHV = qVdhXRFiGgHV;
        }
    }

    return 286820.0904029508;
}

string iYCQzeEQxDdLV::VeHJLnImoYapd(int hBlnu, string YKFJz, bool SDvMWmhiA, bool wYfZaqTQZ)
{
    bool OrBsRklfpzCKzynH = true;
    bool bFHQRZXLGjdWqd = false;
    double ayaSB = 862041.145587588;
    bool ucjaqNBtnhYQMCq = true;
    double PKyvgPj = 508380.12369389215;
    string fCtyVYsl = string("GUkfJxVGlwnwOViaBMtYnPZsPpZMGUWwCjZLliHxtfnndwbdSJhDPmjXfRhIoQoiXRoCzKDBtWAQnntzPEbRQMtcmkLWDZSASSIdQzwJEBVjiXsRIsGlbZXpuiESfoLQegbdmkTHnJvXmkEhKuRD");
    bool sJZNjabLwEWrDo = true;

    for (int CgDyeWB = 749919163; CgDyeWB > 0; CgDyeWB--) {
        continue;
    }

    for (int ZfjuNtmqg = 1343552606; ZfjuNtmqg > 0; ZfjuNtmqg--) {
        ucjaqNBtnhYQMCq = ! SDvMWmhiA;
    }

    for (int MVZTsG = 1613815124; MVZTsG > 0; MVZTsG--) {
        continue;
    }

    for (int lFuQksYtegHy = 1455922674; lFuQksYtegHy > 0; lFuQksYtegHy--) {
        continue;
    }

    for (int rwVvLvl = 1116015769; rwVvLvl > 0; rwVvLvl--) {
        wYfZaqTQZ = ! sJZNjabLwEWrDo;
        ucjaqNBtnhYQMCq = SDvMWmhiA;
        bFHQRZXLGjdWqd = SDvMWmhiA;
    }

    return fCtyVYsl;
}

int iYCQzeEQxDdLV::mUutWoRKVliYpqF(int dDxiSQWjl, double ZaGNy, int fsFjRmpzKac)
{
    double vDGRsQmKLX = 251013.45729239317;
    bool ojvuScyzFgDFVpLJ = true;
    bool VPRmeUfpBucqSksl = true;

    if (ojvuScyzFgDFVpLJ != true) {
        for (int pBzbfqCz = 498536122; pBzbfqCz > 0; pBzbfqCz--) {
            ojvuScyzFgDFVpLJ = ! VPRmeUfpBucqSksl;
            fsFjRmpzKac = dDxiSQWjl;
        }
    }

    for (int CadVIkYyUy = 1934794332; CadVIkYyUy > 0; CadVIkYyUy--) {
        VPRmeUfpBucqSksl = ! ojvuScyzFgDFVpLJ;
        VPRmeUfpBucqSksl = ! VPRmeUfpBucqSksl;
        ZaGNy += ZaGNy;
    }

    for (int xLuPXwE = 848352618; xLuPXwE > 0; xLuPXwE--) {
        ojvuScyzFgDFVpLJ = ! ojvuScyzFgDFVpLJ;
        dDxiSQWjl *= dDxiSQWjl;
        ZaGNy *= ZaGNy;
    }

    for (int SFSDpRXuxn = 22663338; SFSDpRXuxn > 0; SFSDpRXuxn--) {
        ZaGNy = vDGRsQmKLX;
    }

    return fsFjRmpzKac;
}

bool iYCQzeEQxDdLV::wrnddiEWanPv(int ApcsverWvJLIEd, bool fNzaxSsQkQf, bool mhFMVjPYcfZuv, int VRdxjtBNVKGIw)
{
    string evQZbhk = string("jvlDHskIKTkViyiJZDXrNlUqXIJqIiwnYpKlOzMNXHuIbPCuHUroxyrzsHxXqBJiDBmcxLDPbVkWAbxOHRdDIkkswCMFmfnsrjbolrujIuTtWvyGDScZquaaQoORBXfdeuxiunhILTOEHboplEbbHCXuojONkowtmWPUiUhzN");
    double jdHgRtQsqDK = -850720.4749458013;
    double AuPzTx = 136719.62282671354;
    string hgBWAHBlrYvrV = string("vScJuYqYjWxMyehXTKqhTsDAdNEgzXgIvAgNUTAnpwoHDvqtIAfmkxIoyAwIudDdFTQxEtuvsSUJhBLMoQpdYRRoGiDxvVoGGrIciaxcfMfpKUiyEdZunDOhaCuYhcxCAq");

    for (int PSdIYZkInTxf = 1411094944; PSdIYZkInTxf > 0; PSdIYZkInTxf--) {
        continue;
    }

    for (int DTIDf = 1496271469; DTIDf > 0; DTIDf--) {
        fNzaxSsQkQf = mhFMVjPYcfZuv;
        VRdxjtBNVKGIw *= VRdxjtBNVKGIw;
    }

    if (ApcsverWvJLIEd <= 1597711332) {
        for (int PwuYuzGt = 824789099; PwuYuzGt > 0; PwuYuzGt--) {
            jdHgRtQsqDK -= AuPzTx;
            jdHgRtQsqDK *= AuPzTx;
            ApcsverWvJLIEd = VRdxjtBNVKGIw;
        }
    }

    if (AuPzTx < 136719.62282671354) {
        for (int UVGwqEUkJrbSha = 2132431875; UVGwqEUkJrbSha > 0; UVGwqEUkJrbSha--) {
            mhFMVjPYcfZuv = ! mhFMVjPYcfZuv;
            mhFMVjPYcfZuv = ! fNzaxSsQkQf;
            hgBWAHBlrYvrV += hgBWAHBlrYvrV;
        }
    }

    for (int TtBqzuILd = 1448216233; TtBqzuILd > 0; TtBqzuILd--) {
        continue;
    }

    for (int HWMomKcs = 1570520216; HWMomKcs > 0; HWMomKcs--) {
        ApcsverWvJLIEd -= ApcsverWvJLIEd;
        ApcsverWvJLIEd = ApcsverWvJLIEd;
        evQZbhk = evQZbhk;
    }

    for (int pzgcvRvfIaHvMB = 1274668684; pzgcvRvfIaHvMB > 0; pzgcvRvfIaHvMB--) {
        fNzaxSsQkQf = fNzaxSsQkQf;
        evQZbhk += hgBWAHBlrYvrV;
    }

    return mhFMVjPYcfZuv;
}

int iYCQzeEQxDdLV::QPqHEVFjiTGTD(string zenVxJXQRGcpuq, int pqMmdgIxJKFt, string ClqdfIyIlivTyw, string PhQYTXkp, bool SfqByKpkoajaJkL)
{
    bool YLmpgmONSJrT = true;
    bool EBhJO = true;

    for (int tXDbtZ = 20602618; tXDbtZ > 0; tXDbtZ--) {
        continue;
    }

    for (int GFIGGPeg = 407920825; GFIGGPeg > 0; GFIGGPeg--) {
        YLmpgmONSJrT = YLmpgmONSJrT;
    }

    return pqMmdgIxJKFt;
}

string iYCQzeEQxDdLV::HPXPWaNSXRNl(int tVHoy, double djbphAQetbx, string ttmKwSMNRoxF)
{
    string sTCHpypunONkvhGe = string("ryDnjjkaiNvbUeUpNXAGIdFVlHUzVSUVRrOalbQHCOVfTIIuEfHTClUdJvbrKnKSzmwOBSGlsDbQdduYoCpPNQZdxNSClTImeRATFWAsLwHdatbUHTJmFplWaBGrqLGvMtIPzUEvwcKcPbWUbynBuqthhEyXQENGCCWOlmlVTZEiAAyOpHgUOXIsArAMFoHSRvQndtrHWzEXhHWpWZlrRALGCGFEI");
    bool WOUUfsoc = false;

    for (int VucqSTGPn = 1904387909; VucqSTGPn > 0; VucqSTGPn--) {
        ttmKwSMNRoxF += sTCHpypunONkvhGe;
        sTCHpypunONkvhGe += sTCHpypunONkvhGe;
    }

    for (int TdjLWPUzsxjIqfi = 342656090; TdjLWPUzsxjIqfi > 0; TdjLWPUzsxjIqfi--) {
        djbphAQetbx += djbphAQetbx;
        sTCHpypunONkvhGe += sTCHpypunONkvhGe;
    }

    for (int vveFmILqzj = 437474993; vveFmILqzj > 0; vveFmILqzj--) {
        sTCHpypunONkvhGe += sTCHpypunONkvhGe;
        tVHoy /= tVHoy;
        tVHoy /= tVHoy;
    }

    if (tVHoy != -283534567) {
        for (int IGrrfRp = 1123826779; IGrrfRp > 0; IGrrfRp--) {
            ttmKwSMNRoxF = ttmKwSMNRoxF;
            sTCHpypunONkvhGe += ttmKwSMNRoxF;
            WOUUfsoc = ! WOUUfsoc;
        }
    }

    for (int VeLxv = 1795902659; VeLxv > 0; VeLxv--) {
        continue;
    }

    return sTCHpypunONkvhGe;
}

string iYCQzeEQxDdLV::EYIMdnCKroFOLqbQ()
{
    string ipyNJxHGfHNocxL = string("juapXKyLlXvfvZMxAaeXqZLIMtbjUCqTgGOELJndTDmplCsPtbvckAciWnGsAfpNBcULhuzgokEhPcIhaqwtObrbFiZaKLUaTRPHmw");
    string lLamEdWgxPoGWnPl = string("hcQrKpGQIrXQkbXYnfkpGDLklTaCEaJjxtVMVaGvvygYCJTWvYWncnavthwjUGtjIvrJTTrEHhuoxriuXcujWKXcgRufkyRQulJEXAqYPWxmGquzGPQJBtgnfypmqEMzYQtlVkVASdoRxNCuIvqhNwlhefgLwoaCbs");
    double PTpYBSQJvu = -1014420.5514123952;
    double iUwLSVTCJGVuhvdj = 795871.5804432612;
    bool nuOMA = false;
    double LisOROxP = -750662.8827050116;
    bool TuwwuSBA = false;
    bool GLXZRA = true;
    bool eREaRWLydC = false;

    return lLamEdWgxPoGWnPl;
}

string iYCQzeEQxDdLV::eCpZLjFcmEsyx(double oDfWyUTikpweB, string BglDCoEiqA, string UwcKsbhsd, bool bqIkS)
{
    double nbfNhKkEaEMN = -499919.66320573475;

    return UwcKsbhsd;
}

iYCQzeEQxDdLV::iYCQzeEQxDdLV()
{
    this->GVAjkoQooCEImbf();
    this->VeHJLnImoYapd(-1677444784, string("IexUuTkcooOidIxXoQkY"), true, true);
    this->mUutWoRKVliYpqF(121769661, -466442.3731466909, 125723233);
    this->wrnddiEWanPv(1597711332, true, true, -2022275108);
    this->QPqHEVFjiTGTD(string("XLoeMEJSueHRLSkijSspmsFeDpgCGnOAlZQgfTJYaQoPVfztflrQISLDuieFzjWPdkpCWRaHfwLakbvkAjRwgjfP"), -1183637676, string("pQgUJyDftejWqGJDSzcVQjTGbhMnFuagoUCeGXBPfrAsgfRF"), string("WgBfPJjsOrGwhpuwmCpuNoHodtfXbIgbyMbpfiqavOkCYCbZprJLQUmfhHNmdkWGyhqqLwQUELYVpxbhduLuxcDpImugzSQXXFVBTyGtRZPqwpHPNFNNueJHrXUohRpmHYduQkRTEYKsbVDgoNLYqxjOiqYNEejiAtjUWZRYkmDYsVseGYwRJggICYYwyqzWJmrIqdQU"), true);
    this->HPXPWaNSXRNl(-283534567, 256691.071899404, string("drhUyeQmsgGtjvXbZHLtgQabEvUBNlxuwGLFSpOGBFTyuLOjhOXZiXHSfhrZTavVDhqyusZBdxgxitmZ"));
    this->EYIMdnCKroFOLqbQ();
    this->eCpZLjFcmEsyx(-139541.99709419065, string("YYbAMxLHNKetdRCzWhABvxCXGskWasQVOJFPvEmOoozxbyiZZBQSoDzwdiHKurcFDgMpBiTItcpIoYjxrUeJTzcCIxXtmdDgAvFxLSrAQhPtyQVwhjHWESzYPjTRVQBnetVzWAuPoyOPo"), string("olYzfOhfPYBYAhoEqnwVEvwKZqSYALujTICUsheyQzzOkznYSGEWOxxgH"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XyQyoDvgzxe
{
public:
    int UICoPSyE;
    string ZQswoiKYy;

    XyQyoDvgzxe();
protected:
    int bTHPZEBureFouhyt;
    bool fYQqQCGra;
    double IovBdoI;

private:
    bool rLZUdooIwV;
    bool lfNvkBpungBt;
    string IqtfDTwgewxs;
    bool hTcqlNrGfChKwC;

    bool tQFUuCmeKLefx(bool tuOXmxId, string pEAfhSTdf, int dIHHWisIrKFdHEN);
    int uQHBG(double RSkMCpWXpZQ, bool rrAUwXWFsKs);
    string fIkJDRn(double bQkkoBvakQitTm, double QakKolyrCrDnTGq, bool yjbUUB, int ZOZlDbzEKrmZ);
    string ipsinMJzYT(string KlYTkDfClFalwuk, string waPgXJCRMuewfC, int pyAyjGEAf, string tLayWasTh);
};

bool XyQyoDvgzxe::tQFUuCmeKLefx(bool tuOXmxId, string pEAfhSTdf, int dIHHWisIrKFdHEN)
{
    bool xQWNkxwOEE = false;
    double vnPFblImv = -58502.96666546553;
    double HVFkISSEKnE = 678481.5475031171;

    for (int oQHHTYsMllhlwVS = 140073431; oQHHTYsMllhlwVS > 0; oQHHTYsMllhlwVS--) {
        continue;
    }

    for (int zmGAysHcysKCLZC = 1137930801; zmGAysHcysKCLZC > 0; zmGAysHcysKCLZC--) {
        continue;
    }

    if (HVFkISSEKnE != 678481.5475031171) {
        for (int piDCaJZG = 381867540; piDCaJZG > 0; piDCaJZG--) {
            HVFkISSEKnE += vnPFblImv;
            xQWNkxwOEE = ! xQWNkxwOEE;
        }
    }

    for (int rvRTDiXpKZHFqF = 1484696959; rvRTDiXpKZHFqF > 0; rvRTDiXpKZHFqF--) {
        xQWNkxwOEE = ! tuOXmxId;
        vnPFblImv += vnPFblImv;
    }

    return xQWNkxwOEE;
}

int XyQyoDvgzxe::uQHBG(double RSkMCpWXpZQ, bool rrAUwXWFsKs)
{
    string iexEkib = string("ireHFXTBGomvIkwODXdsQdSShhcrLPOFJUDuJtpeglpihLlJQWLvXokpAFHysLcLPnIxRquTVFiPEuNidPMUsvJZymntWkKBisVPmtMWzEDVSAnRnpVyrIGSfhtweagDYtwnAAvqrGBeFAXYpyDUwafophScIeviXqTDNAaVYuGQlmFiOyCVkFwhZMlDjVOPJSbfCbQCzFHmrDdwP");
    double BewwbLJvODWu = 900463.7221642337;
    int JKqcnm = -390764811;
    bool EWtIEKcprzirTgXb = false;
    bool pzVWsUMowwQmuWOD = true;

    for (int ayQPnjVK = 616378411; ayQPnjVK > 0; ayQPnjVK--) {
        EWtIEKcprzirTgXb = EWtIEKcprzirTgXb;
        rrAUwXWFsKs = ! pzVWsUMowwQmuWOD;
        pzVWsUMowwQmuWOD = EWtIEKcprzirTgXb;
        rrAUwXWFsKs = ! EWtIEKcprzirTgXb;
    }

    if (BewwbLJvODWu >= 900463.7221642337) {
        for (int EbDnboLLPFs = 17994231; EbDnboLLPFs > 0; EbDnboLLPFs--) {
            rrAUwXWFsKs = rrAUwXWFsKs;
            pzVWsUMowwQmuWOD = ! pzVWsUMowwQmuWOD;
        }
    }

    for (int aFocZkPLpAd = 1732762317; aFocZkPLpAd > 0; aFocZkPLpAd--) {
        rrAUwXWFsKs = ! pzVWsUMowwQmuWOD;
        EWtIEKcprzirTgXb = ! rrAUwXWFsKs;
    }

    return JKqcnm;
}

string XyQyoDvgzxe::fIkJDRn(double bQkkoBvakQitTm, double QakKolyrCrDnTGq, bool yjbUUB, int ZOZlDbzEKrmZ)
{
    string xNshC = string("CNuxtqeGCDlrQnuAKDDVyRnYcEgFxmArevfTBBTsfEKbtxlojWNJDeJUkVcyXNicdUValXvFjGvExuQvCduCKqwQVyJJZeoQiIDgYeYTsqttpniQdcPaajHOevADjGhrNLOWEUgupTNOm");
    double czzKyILsmTLAla = -417232.18686115654;
    string KtEfTNbzuAaS = string("unLvHeNZDawvjROZNzXVeqVDhzruTqzNmPWGxvAcnvlBO");
    string HIQSXx = string("epuNgEdNTZnIXasGOKiMExUVkVSuAPbZVlFtuVtCRSwcaJJwnxAqvvaEeLWFMgsGmfwgeROgoPCZfYwGLTzPmXhngVrBGmjJNnVBqYxCvPScIeEEutAGHnHSGXnMFrBGREpYDGwCgCtPBxRskwljexfRAaiTJvqeVbTrzMOFRlSWAoyBNiQNSVbZCFvrpfLuGueipPwRnOsQsOvkDFomZuLrQfUEXojHgOza");
    string cTEwbGSPO = string("lSfQMMhkRFYvOdJLyZwDfcxMNEjhkYZiLUIMAxkPDCwlSqIGGlfMmuRqgtCPxxKFPouCyEtKJvQpVMCKYbqmacTXgJtbdwxfEtLrurSsmSCkTPzgYdzFwhWtTuSsgwxXvCDrvJkmtiQwVFDILgTgPiVqSrwlBRYZIWvedfNkFtupsQimEJwQJbHMJbXqWnFcRUplPvAVaNZPfUugYREdLcFjMkWLBBdwCemJAsGnPZmuqBSM");

    for (int XHNdaBfjROe = 1249311014; XHNdaBfjROe > 0; XHNdaBfjROe--) {
        czzKyILsmTLAla *= czzKyILsmTLAla;
    }

    for (int gbufLSWqNf = 654569493; gbufLSWqNf > 0; gbufLSWqNf--) {
        KtEfTNbzuAaS += cTEwbGSPO;
        QakKolyrCrDnTGq -= bQkkoBvakQitTm;
    }

    for (int sNZsfIfNobvWA = 882688183; sNZsfIfNobvWA > 0; sNZsfIfNobvWA--) {
        xNshC = KtEfTNbzuAaS;
        bQkkoBvakQitTm += czzKyILsmTLAla;
        czzKyILsmTLAla = czzKyILsmTLAla;
    }

    return cTEwbGSPO;
}

string XyQyoDvgzxe::ipsinMJzYT(string KlYTkDfClFalwuk, string waPgXJCRMuewfC, int pyAyjGEAf, string tLayWasTh)
{
    int AJgwmwqqvUwga = -1409724406;
    string bXQUVKLsgw = string("xJqIHzdXrbymVuXDYtzzKdhpRqXVNsuNYtYNbMqmhpPWlCRaXloJjscQdYxxYlnTOuwaOMjMVVEMeoQHKcUvPNnoLERsXdvXxuksHkSEQXGgItCzOyJkaqhEddhniUAKWoZAGzxDcKrketJgYUReJRRsDWBooHUNehRxvOdWkMxGcwuSFbNIQCjoIXNAMHHqPIMUMyqZJopuPUzxWSlsbIOcUFPiXsBtRQsbZdqYpceHBpmzjjFy");
    int UmZpQv = 1109880011;
    string ynjRJOKxuAwV = string("AifbliIIPavEcXSWfLcsFYJyPKrBrBpnQxynukRjAjFaRpqAebiTkdAcZtdfPCqLkjNPvilOomjXHhOfMBbMGOdTKKYsfkxxmHTahHUcetteaDOJ");

    for (int aDSHBpovdS = 1873799803; aDSHBpovdS > 0; aDSHBpovdS--) {
        KlYTkDfClFalwuk = bXQUVKLsgw;
        UmZpQv -= pyAyjGEAf;
        ynjRJOKxuAwV += waPgXJCRMuewfC;
        waPgXJCRMuewfC = ynjRJOKxuAwV;
        bXQUVKLsgw += tLayWasTh;
        waPgXJCRMuewfC += tLayWasTh;
        ynjRJOKxuAwV += KlYTkDfClFalwuk;
        waPgXJCRMuewfC += tLayWasTh;
    }

    if (UmZpQv == -1409724406) {
        for (int ZTNnjXFlhuW = 1405612250; ZTNnjXFlhuW > 0; ZTNnjXFlhuW--) {
            continue;
        }
    }

    if (bXQUVKLsgw < string("hIwGCShtrkyvdHgUfIMOXMSfaVlHJiYYgUQsLdubaAWTgMEUgPdCaiRLKdbcnrMhUTqAVOdEQKNbIcSmtUkxoehBZgegUVcQsBkPmlvKNpuDBIfMEoeEmVgPLQIaQsUHR")) {
        for (int QDxqtYXuDIacO = 1648646856; QDxqtYXuDIacO > 0; QDxqtYXuDIacO--) {
            pyAyjGEAf *= UmZpQv;
            AJgwmwqqvUwga *= AJgwmwqqvUwga;
            tLayWasTh += ynjRJOKxuAwV;
            waPgXJCRMuewfC += bXQUVKLsgw;
        }
    }

    if (pyAyjGEAf == -1409724406) {
        for (int jfCXMdG = 1713324844; jfCXMdG > 0; jfCXMdG--) {
            UmZpQv = UmZpQv;
        }
    }

    for (int MIMrLtTjnYXVITvf = 1647171300; MIMrLtTjnYXVITvf > 0; MIMrLtTjnYXVITvf--) {
        bXQUVKLsgw += bXQUVKLsgw;
        KlYTkDfClFalwuk = KlYTkDfClFalwuk;
        ynjRJOKxuAwV += tLayWasTh;
        KlYTkDfClFalwuk = waPgXJCRMuewfC;
    }

    return ynjRJOKxuAwV;
}

XyQyoDvgzxe::XyQyoDvgzxe()
{
    this->tQFUuCmeKLefx(false, string("uFCmIEyrCPRgLJkBAiaslvpusCoMAbHMWNDodPbJexskgzaNsauvQMrqnTiqJGwJpOlkfXYzDLwSqgndrdOCuTLblXoVwUMLSVqwVkfwiMOcSYSiAo"), -1403748199);
    this->uQHBG(628978.9873376796, true);
    this->fIkJDRn(670973.8850187163, -398066.5385081634, false, -2049841850);
    this->ipsinMJzYT(string("BGsLoixlbGcuaZbNwOiLgfozChireXUEhzwDuiepwRfrHfpLeiCqBzFssavwokTrzqOniOqbEpzrjefqzDirJYJmwtjVVUFtwZXTKFgCIvTpTAMcTelqLkYISCstRfiMbkKPmROyyScZdYznMswchRSJtmZjRjJDz"), string("hIwGCShtrkyvdHgUfIMOXMSfaVlHJiYYgUQsLdubaAWTgMEUgPdCaiRLKdbcnrMhUTqAVOdEQKNbIcSmtUkxoehBZgegUVcQsBkPmlvKNpuDBIfMEoeEmVgPLQIaQsUHR"), -679019382, string("oIjvLMpNQIkjYhovciHNeyrJoVQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yvqWxhr
{
public:
    int VmNXLJnKt;
    bool eICtiOiXXAH;
    string hPLtE;
    string kEgoL;
    bool vTBlSwHJsQXQH;

    yvqWxhr();
    int gUMJThZKrxsRTquj();
    int TGPvJomoH(bool EJYYWZUu, int rcTPCIBWUaGf);
    void EprvtlMbI(bool sCsgCM, double nVwoWwM, bool UwdDLRBpWVLkuf, int zPCIjRsohCCnkn);
    double rhlzWskVHm(double NICol, double bqFEnhi, string hBHGDEfsdO, double fDfgUyfhlYYN);
    void MRfsQNp(string HPVCque, int VKyYwc, double VCLOJZDRldBysf, int GRHHdgIzZfm, double XftLFIyySvOM);
protected:
    double gBMBSzFwUiwFL;
    double nLrOFcyQ;
    bool kCfoJTtjEyCXiEMi;
    int yEFbMxDRKFRKd;
    bool ErsMGj;
    bool pkOKgaUX;

    bool fEEMvi(string oOEZra, string qweflnn, int ncgKr, string TRXPJN);
    string RYdOKuFWqV(bool XRFRQxhaSUX, string dLoEfOKpnjNlypb, bool FJhrL, bool ELjBeAOndGiOsJA);
    bool PqfkId(string EDwGROUFvCZixCt, double GyAcBlfivVNOP, double YLLpypxj);
    bool lLkYvA(int cFqomP, double zjzxlPZNZpBevcp, int cavkRVMxcnAelP, double TDHGa, double OSBMXHv);
    double bzlDprjUj(double YyFYvRoFDGJlvp);
    string pKSlkVpPHmvYErkg();
    double yxihnMz(double pyffkAXtoXkUlr, double SicBhBtYIPQ, double TTcIDawG, bool uaHTzdegMVuOqL);
private:
    int HjEJCrExDrgVHgo;
    double hvEXO;
    double KMHvlw;
    bool hKzZlZXmw;
    string lbGEbVZsBOoX;
    int jJCnSYeBUwH;

    int FiycPDFkfKn(int finBDSOBdoZ, bool TkTPv, int pddom, double icMwiAKO);
    string jtZVoRteIrFdOAjY();
    void NgGcZMcmemWPXQ(string hYMXSBHpbzSJg, string Mwbxd, bool BFOxzJAldzRWi, bool HLwmmGZBBqPTls);
    bool MQMXEwmOdklOsD(string WNpqHW);
};

int yvqWxhr::gUMJThZKrxsRTquj()
{
    bool SXqGHtjawQdv = true;
    double oFwSBCWnOyuMcyDU = 215536.44344427975;
    double ZTGSErBFSyE = 517913.5942897151;
    double LJmczQJcW = -20902.825702048456;

    if (oFwSBCWnOyuMcyDU <= 517913.5942897151) {
        for (int hDZNUo = 479977405; hDZNUo > 0; hDZNUo--) {
            LJmczQJcW = LJmczQJcW;
            oFwSBCWnOyuMcyDU /= ZTGSErBFSyE;
            LJmczQJcW = ZTGSErBFSyE;
            LJmczQJcW /= ZTGSErBFSyE;
        }
    }

    for (int BvKyuHxAGJsEAPDU = 2118347374; BvKyuHxAGJsEAPDU > 0; BvKyuHxAGJsEAPDU--) {
        LJmczQJcW = ZTGSErBFSyE;
        oFwSBCWnOyuMcyDU += ZTGSErBFSyE;
    }

    if (ZTGSErBFSyE < 517913.5942897151) {
        for (int iNcPerCxDZKiHF = 1533138599; iNcPerCxDZKiHF > 0; iNcPerCxDZKiHF--) {
            continue;
        }
    }

    return -1555432488;
}

int yvqWxhr::TGPvJomoH(bool EJYYWZUu, int rcTPCIBWUaGf)
{
    int XFTtkk = -1574740405;
    bool AGNoABA = false;
    int ZQNLJtAfgXZZFgv = -1772083426;
    bool CutobDLcBNdFRX = true;

    for (int WURBEdx = 857668908; WURBEdx > 0; WURBEdx--) {
        AGNoABA = ! AGNoABA;
        rcTPCIBWUaGf = ZQNLJtAfgXZZFgv;
        ZQNLJtAfgXZZFgv /= XFTtkk;
    }

    for (int cPsWVBSkdMCos = 573741351; cPsWVBSkdMCos > 0; cPsWVBSkdMCos--) {
        continue;
    }

    return ZQNLJtAfgXZZFgv;
}

void yvqWxhr::EprvtlMbI(bool sCsgCM, double nVwoWwM, bool UwdDLRBpWVLkuf, int zPCIjRsohCCnkn)
{
    double AzzPPCRFVgBW = 374283.4850235524;
    string WOfrZyQMoALerwmd = string("ppZtgBlZqUUCbxxPWmHuGPwiLiOjrClvqnYkEdseQNTsRLcDUdVUISFTNTmFIrtuLiSMxsOEtCUSioGFYrXyHYwkrWjSKeWBg");
    bool bLNjFZVhHWDGH = true;

    for (int kLVmvlAafSedkTNU = 428242958; kLVmvlAafSedkTNU > 0; kLVmvlAafSedkTNU--) {
        UwdDLRBpWVLkuf = ! bLNjFZVhHWDGH;
    }

    for (int wTrigAipybskg = 1519393396; wTrigAipybskg > 0; wTrigAipybskg--) {
        sCsgCM = ! bLNjFZVhHWDGH;
        AzzPPCRFVgBW *= nVwoWwM;
        UwdDLRBpWVLkuf = ! sCsgCM;
        UwdDLRBpWVLkuf = ! sCsgCM;
    }

    for (int yCdzBGLLAeeSHn = 466235466; yCdzBGLLAeeSHn > 0; yCdzBGLLAeeSHn--) {
        continue;
    }

    for (int HiUhrfCe = 1173030849; HiUhrfCe > 0; HiUhrfCe--) {
        continue;
    }

    for (int MtnyQiZPfHEq = 1477774421; MtnyQiZPfHEq > 0; MtnyQiZPfHEq--) {
        UwdDLRBpWVLkuf = bLNjFZVhHWDGH;
        sCsgCM = UwdDLRBpWVLkuf;
        WOfrZyQMoALerwmd = WOfrZyQMoALerwmd;
        sCsgCM = sCsgCM;
    }
}

double yvqWxhr::rhlzWskVHm(double NICol, double bqFEnhi, string hBHGDEfsdO, double fDfgUyfhlYYN)
{
    string oOYRYQbbesUx = string("aDhEpPdje");
    double KcFxxiTC = -496376.6167084355;
    bool OzvaZLmrezFTzm = false;
    double hGFWABNrm = 980111.2858579315;
    double OMLNGrgptGqbGNwl = -571798.4211750977;
    double BgqaFJbUlqABhww = -694276.9009270039;

    for (int fNGVVVSHnD = 167349159; fNGVVVSHnD > 0; fNGVVVSHnD--) {
        oOYRYQbbesUx += oOYRYQbbesUx;
        BgqaFJbUlqABhww /= hGFWABNrm;
        KcFxxiTC *= bqFEnhi;
        hGFWABNrm /= NICol;
        BgqaFJbUlqABhww -= BgqaFJbUlqABhww;
        bqFEnhi = NICol;
    }

    if (OMLNGrgptGqbGNwl > -496376.6167084355) {
        for (int JBnlUhvqovNiDNSN = 449038159; JBnlUhvqovNiDNSN > 0; JBnlUhvqovNiDNSN--) {
            bqFEnhi = hGFWABNrm;
            OMLNGrgptGqbGNwl += fDfgUyfhlYYN;
            hGFWABNrm /= NICol;
            oOYRYQbbesUx = hBHGDEfsdO;
            BgqaFJbUlqABhww = KcFxxiTC;
        }
    }

    for (int muWLWolzjPPjv = 608018472; muWLWolzjPPjv > 0; muWLWolzjPPjv--) {
        KcFxxiTC /= OMLNGrgptGqbGNwl;
    }

    if (KcFxxiTC == -707398.9069203935) {
        for (int HxxVPfgyGyDpkWsk = 896983270; HxxVPfgyGyDpkWsk > 0; HxxVPfgyGyDpkWsk--) {
            OMLNGrgptGqbGNwl = BgqaFJbUlqABhww;
            KcFxxiTC += KcFxxiTC;
        }
    }

    if (KcFxxiTC == -694276.9009270039) {
        for (int niuGkXE = 1617732746; niuGkXE > 0; niuGkXE--) {
            NICol += KcFxxiTC;
            fDfgUyfhlYYN = hGFWABNrm;
            BgqaFJbUlqABhww = bqFEnhi;
            BgqaFJbUlqABhww -= OMLNGrgptGqbGNwl;
        }
    }

    if (KcFxxiTC < -496376.6167084355) {
        for (int ytiPzPSWSCWWymT = 28577897; ytiPzPSWSCWWymT > 0; ytiPzPSWSCWWymT--) {
            hGFWABNrm *= KcFxxiTC;
            hGFWABNrm += hGFWABNrm;
            fDfgUyfhlYYN *= fDfgUyfhlYYN;
            hGFWABNrm += OMLNGrgptGqbGNwl;
            fDfgUyfhlYYN -= OMLNGrgptGqbGNwl;
        }
    }

    if (hGFWABNrm == -496376.6167084355) {
        for (int mRgac = 1965145288; mRgac > 0; mRgac--) {
            KcFxxiTC -= NICol;
            fDfgUyfhlYYN *= bqFEnhi;
        }
    }

    return BgqaFJbUlqABhww;
}

void yvqWxhr::MRfsQNp(string HPVCque, int VKyYwc, double VCLOJZDRldBysf, int GRHHdgIzZfm, double XftLFIyySvOM)
{
    int HKpJiM = -806890711;
    string cRktHBBZuptFBNf = string("ciCnNOmVettxYBAAqyknDYTkaUndgGbZNIvaPRJHuKrZNqavpJ");
    double dLpjbWtsRGIRU = -660033.2953608884;
    string aqyTnexhi = string("FhGUFgwhgHhIXjUB");
    double igSIlOvlWxPKK = 390947.039919335;
    string biWqXfqNMQxlTp = string("uzWWtAgkYOOeuejEEPyKAUQiLnDmZZEPRoZTehrbnzyttCCdiSUYDzDqHgaxemlHYKwSIO");
    bool PaGkmJYT = false;

    for (int BTUahPnkrClAbDq = 1880848089; BTUahPnkrClAbDq > 0; BTUahPnkrClAbDq--) {
        continue;
    }

    for (int qJMSRYYhPn = 50986267; qJMSRYYhPn > 0; qJMSRYYhPn--) {
        biWqXfqNMQxlTp = HPVCque;
    }

    for (int OVyNtrukzCg = 863164510; OVyNtrukzCg > 0; OVyNtrukzCg--) {
        igSIlOvlWxPKK += XftLFIyySvOM;
        XftLFIyySvOM /= XftLFIyySvOM;
    }

    for (int OwpKxriumeZ = 183597199; OwpKxriumeZ > 0; OwpKxriumeZ--) {
        igSIlOvlWxPKK *= dLpjbWtsRGIRU;
        VKyYwc /= VKyYwc;
    }

    for (int HffoLE = 207326973; HffoLE > 0; HffoLE--) {
        continue;
    }

    for (int wtSSgQx = 1253443712; wtSSgQx > 0; wtSSgQx--) {
        GRHHdgIzZfm += VKyYwc;
    }
}

bool yvqWxhr::fEEMvi(string oOEZra, string qweflnn, int ncgKr, string TRXPJN)
{
    string mGbmof = string("ICXfZXptWXOcluCnqrBJzRSMPEXkTyuYdLXUyxVMsLcvPdMvqxUcOMWnHBdpsmQuvhitljubSiyXGFIypFOBxmD");
    int azlqupbfQoadVP = 1011612110;
    double gDXkDHrAIeW = -629390.2689284423;
    string deABzircM = string("yxdOWMefK");

    for (int xwOBHb = 2120398729; xwOBHb > 0; xwOBHb--) {
        TRXPJN = qweflnn;
    }

    if (mGbmof < string("yxdOWMefK")) {
        for (int WrDriNXARdbAfKh = 1016549043; WrDriNXARdbAfKh > 0; WrDriNXARdbAfKh--) {
            TRXPJN += mGbmof;
            deABzircM = TRXPJN;
            TRXPJN += qweflnn;
            mGbmof = mGbmof;
        }
    }

    if (mGbmof == string("yxdOWMefK")) {
        for (int kiFrPiXaxQ = 1573494612; kiFrPiXaxQ > 0; kiFrPiXaxQ--) {
            oOEZra += TRXPJN;
            mGbmof = mGbmof;
            mGbmof = mGbmof;
            ncgKr = ncgKr;
        }
    }

    return false;
}

string yvqWxhr::RYdOKuFWqV(bool XRFRQxhaSUX, string dLoEfOKpnjNlypb, bool FJhrL, bool ELjBeAOndGiOsJA)
{
    int DcmFaQxjYtHgC = 1170507612;
    string XTbIPXXdYHD = string("oXVBefTdIazJXbQbuFbDymPQXvWtshHIJUaRmffHpveDXXHCxVyTZdPZZTCKWiIixMqZINGyhBvPwFCWXipQQJuyuuJTtrJvQcxwrBIfvCaQMOONQNmPE");
    double xxwiHaFw = -585151.7716514949;

    if (ELjBeAOndGiOsJA != true) {
        for (int YGwfHOrnxMN = 1964582579; YGwfHOrnxMN > 0; YGwfHOrnxMN--) {
            dLoEfOKpnjNlypb += XTbIPXXdYHD;
            ELjBeAOndGiOsJA = ! ELjBeAOndGiOsJA;
        }
    }

    if (dLoEfOKpnjNlypb < string("oXVBefTdIazJXbQbuFbDymPQXvWtshHIJUaRmffHpveDXXHCxVyTZdPZZTCKWiIixMqZINGyhBvPwFCWXipQQJuyuuJTtrJvQcxwrBIfvCaQMOONQNmPE")) {
        for (int UVAoWydSgeVCS = 670653242; UVAoWydSgeVCS > 0; UVAoWydSgeVCS--) {
            ELjBeAOndGiOsJA = ! ELjBeAOndGiOsJA;
        }
    }

    for (int CIyZQGDsbNBD = 1307042735; CIyZQGDsbNBD > 0; CIyZQGDsbNBD--) {
        FJhrL = ELjBeAOndGiOsJA;
    }

    return XTbIPXXdYHD;
}

bool yvqWxhr::PqfkId(string EDwGROUFvCZixCt, double GyAcBlfivVNOP, double YLLpypxj)
{
    double bNlCND = -543302.0346115022;
    double kMQQVEENDoUX = -451603.75384721044;
    double oAbiKZJcDGEy = -524968.6561421107;
    int jzaSfDKzrNJM = 921700269;
    string AvEsUXopyuKemmwC = string("JfoBWIwtYmCRknSvUUilkgmzspSKJzhtLaUlmdVfMeNbSOUYVNPATCkGOfQNosHjlk");
    bool quujoWQAuCt = false;
    int ghiRhgGzRyIu = 354936666;
    bool wBQWEjjDIBC = true;
    bool lLYYByGkHGph = true;
    bool tAzLAMU = false;

    return tAzLAMU;
}

bool yvqWxhr::lLkYvA(int cFqomP, double zjzxlPZNZpBevcp, int cavkRVMxcnAelP, double TDHGa, double OSBMXHv)
{
    double TERvNHL = -443377.69351016526;
    int FTRrRlivcpebUTd = 1678956435;
    int ekeepIYwN = 1226119922;
    int jABMyQ = -1001551179;
    int pGQmxrnajz = -11331088;
    int iTqBAlb = 1648181515;
    string WcoTl = string("zWxhaHfyXOsegqmfqHxNWKGBaisIjkJrTyBOQPTIFzsxPtDaSfMRrcuxYhOFhVOjvKWUbCobrHceFsZgCffoGEFGmCfeuSdYFjukXDiQQgyszTKzzSkIsUhBBrZpxfBquOGjUeKFBufgWISeoU");
    string XajUiwZcX = string("axXKBmndpLuovndumdimZbZHrxUSZSZaeYurpdyqWRzEVMUlhyaFaIcoFXZIeqkMGRGCDKTShkMRfLloAMmOamirCXvXBazepNYncdBtCuXUvWobTEbefYUtXjdhYQlVguzxeAqWEnEiHSeFESeNmZgwsQUFryCLUmmjDIRSxuSgjtLBGtqekhaExNbZNJYMiSmzjoBlQmAHCNALactshWcuBpQwbcwMysOpcmKvXpWlavBxgkkeGsyIsmbCUU");
    int UUfxixC = -1613911215;
    double uqTuVCIpnP = 663541.966687625;

    for (int BXPhJFuHpk = 1023388244; BXPhJFuHpk > 0; BXPhJFuHpk--) {
        zjzxlPZNZpBevcp -= OSBMXHv;
        ekeepIYwN += cFqomP;
    }

    for (int QbRWBOZyaQdN = 1980171437; QbRWBOZyaQdN > 0; QbRWBOZyaQdN--) {
        pGQmxrnajz += cavkRVMxcnAelP;
        uqTuVCIpnP -= zjzxlPZNZpBevcp;
        pGQmxrnajz -= cFqomP;
        UUfxixC = ekeepIYwN;
    }

    return false;
}

double yvqWxhr::bzlDprjUj(double YyFYvRoFDGJlvp)
{
    int wuOAbm = -489185220;
    int MIwtAr = 1448144938;
    bool OZGDdv = false;

    if (OZGDdv != false) {
        for (int gLctbmCmqMfpTRY = 795427824; gLctbmCmqMfpTRY > 0; gLctbmCmqMfpTRY--) {
            continue;
        }
    }

    if (OZGDdv == false) {
        for (int TKyDCZdPrJzCHykF = 1870297847; TKyDCZdPrJzCHykF > 0; TKyDCZdPrJzCHykF--) {
            OZGDdv = ! OZGDdv;
            YyFYvRoFDGJlvp -= YyFYvRoFDGJlvp;
            YyFYvRoFDGJlvp -= YyFYvRoFDGJlvp;
            OZGDdv = OZGDdv;
        }
    }

    if (MIwtAr <= 1448144938) {
        for (int TpJqRLJ = 40036268; TpJqRLJ > 0; TpJqRLJ--) {
            wuOAbm -= wuOAbm;
        }
    }

    return YyFYvRoFDGJlvp;
}

string yvqWxhr::pKSlkVpPHmvYErkg()
{
    string FdfXfmlUxcOxV = string("hIBQOGxayhVQizZYysLYePVlBVhsBVeIBAlfOKLTCmwZDNURYdkDBKNpRZSM");
    string MOOsBdQi = string("htNTJKtzzaSlRwjmcrOLhCFtONuVDOiRjdSjQPLwakJoOmkUOPybNoHjyOMIkpxkNMLhmKbRAJqOQitssziNWEgXgSVCKRBrsyKSmMXZUVKeAqXfvrWIQAYgEPwlhVYkGRszXQsSlLnmILAHFSCBNRXPxiwjkmmLLoAqSXZsYvRq");
    bool PfEIhj = true;
    string sHGjP = string("TQGCPRqRBghlyQRwrtShWtUBwdDIvWdDzGhIVKxQRcsdTHCCKapwvlJAnYsjkZrBwZOZansNQAwAnqgdJlPuJKlElwNkmlkYieGKvemqwAcYaiObRABDkhYlGTDDipzTtHjuZVrJFrNVAqQShnEQSvZWazAfTciLaYEayzfuYOPpDHCNOGsAFcybfGUTjApCPbVfTBIomLrVVPmguxGztXuDlsHQgHrFKuFBdmJIUATuNijaSNcDUyCyJLSE");
    int EJvHYFOztUxYW = 1472682219;

    for (int MstaECLIMVuxf = 1852112505; MstaECLIMVuxf > 0; MstaECLIMVuxf--) {
        PfEIhj = ! PfEIhj;
    }

    if (sHGjP <= string("hIBQOGxayhVQizZYysLYePVlBVhsBVeIBAlfOKLTCmwZDNURYdkDBKNpRZSM")) {
        for (int nQkyUJacocxDTU = 2105538053; nQkyUJacocxDTU > 0; nQkyUJacocxDTU--) {
            FdfXfmlUxcOxV = MOOsBdQi;
            sHGjP = FdfXfmlUxcOxV;
        }
    }

    return sHGjP;
}

double yvqWxhr::yxihnMz(double pyffkAXtoXkUlr, double SicBhBtYIPQ, double TTcIDawG, bool uaHTzdegMVuOqL)
{
    string wIwfjfQUnMybt = string("lkcAICOESZQSUasnXkAEENWSvsiAPGqyKRbkvSxKAQZavbscrVbINXIqCheLFwQngWhkynEqSNheMmZCiVesAGgeYvjjWsdHWwZAxiCdOqBCnTwBdKOUoIZgUzumCaymqVUIDdTkxHnRXmTVEAnPSsoiGCbIlzSJmupQjHTpVouOZhi");
    bool JDMYZFO = true;
    bool uZFRRI = false;
    int XzJTsOESNEHZv = -1912528281;
    double cjyygTjn = -247926.7876727615;
    string mjHhjbN = string("NrVPZDtuowMmLHrNDeLllEhHyaftQjnCPUfpSfqaMMWrEUVNXXMUJSOURiRhNKhYBezkzQmisCfLPrvZXtQfmLUGqSTJRuSimVyUMpdrnqGFJTgLRtxaKIneKdgxdyUPokjgcJNjPqDpnQvDHznbwTevOMJsCWeHXiMlvCFuajDwpelptqOZHfHflgzepsTdzXbclshSTSZYwMCJZyyESzGHixfSGsSeVALrEJtw");
    double IxsfvcIQnMRXIJVF = 876879.5596032353;
    double AJmYVNM = 293863.3644758863;

    for (int ghLIOvBQkq = 1011421081; ghLIOvBQkq > 0; ghLIOvBQkq--) {
        continue;
    }

    for (int inDVC = 45621314; inDVC > 0; inDVC--) {
        TTcIDawG /= AJmYVNM;
        SicBhBtYIPQ -= cjyygTjn;
        AJmYVNM = pyffkAXtoXkUlr;
    }

    return AJmYVNM;
}

int yvqWxhr::FiycPDFkfKn(int finBDSOBdoZ, bool TkTPv, int pddom, double icMwiAKO)
{
    bool ziSTgnRoKFVUp = true;

    if (pddom == 303579045) {
        for (int yQSpdeuDxcYTDM = 192338921; yQSpdeuDxcYTDM > 0; yQSpdeuDxcYTDM--) {
            finBDSOBdoZ /= pddom;
            finBDSOBdoZ = finBDSOBdoZ;
            finBDSOBdoZ -= pddom;
        }
    }

    if (TkTPv != true) {
        for (int qhPtc = 762076513; qhPtc > 0; qhPtc--) {
            ziSTgnRoKFVUp = ! TkTPv;
            ziSTgnRoKFVUp = ! ziSTgnRoKFVUp;
            TkTPv = ! ziSTgnRoKFVUp;
        }
    }

    for (int ZYmpbDWcIYMCW = 1095151560; ZYmpbDWcIYMCW > 0; ZYmpbDWcIYMCW--) {
        finBDSOBdoZ = finBDSOBdoZ;
    }

    return pddom;
}

string yvqWxhr::jtZVoRteIrFdOAjY()
{
    bool hdcIKPiOncvBZ = false;
    int mMxaeMDBghtq = 1285819664;
    double TnIOudbx = 207846.87308257696;
    string jneHt = string("OCdRGtFLcUAzLDjALioYcYUbsKUNxOOdnQpCjvQktifOOniZGgiPfeLZijaeHuRkXXhdAYJmGtMwoxYwSWmbCfRhoYYGacvAthKPQeQGUdDhieHcK");
    bool rjsOFeROwwhPznGl = true;
    string KYGIOSKDkDfyjF = string("exAuAXtZQhsZDGSsyYUkhKDAtuRjDIDTiWtJksHPhDmaRpMsmaGtaonZrkPdVEQgqgCsOOoUglJTrjMGorzVgxmMryEZBZeJYRrnWAEOvbSCjppS");
    string FbRXCcmSKvB = string("okwpQfPJNSQgLFyBzCmYznZiEREIjfrpaqSzolSHpqzVKkZPLPodfJnydzdrBcImRjqlMBpZSRzOzPhweQZbqPuZPgHxqFqTODEEHCQXOJFCJvhsToJrlWpQTbVNZRstlMeGxdYXdlBLZxxpAHcfPQoUFzwPNCRBtPSllzqIDnOxMUItiDOMZUISvrwLLCpFWQcGWqePUcOJtKSBCSHBWCths");
    bool WAYyCvHXNmVeY = true;
    int dnIiiUUyyq = 768239628;

    for (int jUydpaBirXA = 751126; jUydpaBirXA > 0; jUydpaBirXA--) {
        WAYyCvHXNmVeY = ! WAYyCvHXNmVeY;
    }

    return FbRXCcmSKvB;
}

void yvqWxhr::NgGcZMcmemWPXQ(string hYMXSBHpbzSJg, string Mwbxd, bool BFOxzJAldzRWi, bool HLwmmGZBBqPTls)
{
    int CqGGBrzDzEuNYa = -2038683387;
    string JsyCVvIqS = string("KoZIVkEckSQDzurMxnTaDVvAQizlvhIdqcZnBCXQvEdXRCdEZKpPMzhoUXttqRxpsICFcZBUcYFdCfqHbnVShjkiVdwygSeXDYCzOukAxRtnGXbOfc");
    int tlxEoFpeesYu = 451619023;
    int MGpdR = 1475348896;
    double EAwzSBeNX = -1011027.857173139;
    bool GBHiITqyDzJS = true;
    string ywxsycGzoTkCb = string("xVtVkkyUkiUnwPyMlPuXyYioqLLDJpdMDuRGdlIfsWUhJqPYYllxEmuBdNeVYKFnASFMxVWNeaVmIBjCcjSecTJspRgZJTTRGEJvjUfKWGtNkzFhPXMQXaUIWvwpjUFzxDiYxbHupCQXhQERueWsHUIbGZlFvYPAHSWfyGPbpvHZgIfKHALBRCgjLQxPwVlNLfGteybkQD");

    if (HLwmmGZBBqPTls != true) {
        for (int bIGxLpOflOmbOQnx = 879262560; bIGxLpOflOmbOQnx > 0; bIGxLpOflOmbOQnx--) {
            hYMXSBHpbzSJg = JsyCVvIqS;
        }
    }
}

bool yvqWxhr::MQMXEwmOdklOsD(string WNpqHW)
{
    int xHJXidNQNDMmpP = 1057350752;
    string rgVAa = string("rGoUEnAVglzcRWyUFefDdgxtlNGPSUYpNImccNSoZkxh");
    double DFMpYFRBImwblZZ = -205508.08367504002;
    int hsCnAqXHlZQ = -681657180;
    double cjrVHQGZ = -317481.5091260592;
    int wKKQtABAAir = 384008970;

    if (DFMpYFRBImwblZZ >= -317481.5091260592) {
        for (int ClmtiKLEzqdNC = 1426610887; ClmtiKLEzqdNC > 0; ClmtiKLEzqdNC--) {
            hsCnAqXHlZQ += wKKQtABAAir;
        }
    }

    return false;
}

yvqWxhr::yvqWxhr()
{
    this->gUMJThZKrxsRTquj();
    this->TGPvJomoH(true, -181526654);
    this->EprvtlMbI(false, 165129.67664052048, false, -2112923485);
    this->rhlzWskVHm(-754192.207920849, -789313.6018400054, string("SvYLBZyztyruJDfZixZpePlnpFCmozoHuqmcktTnQtYVQacgkdDiaEtrZWDPZkOVFmyYelOjVZaUqJpsQwqlpZFWpLcdtdMglmNJFxqHMHsDcbVnyzGLKFUckGGnIvWWhODNmaxaCiLxrZFKZubOrBXjQpGmwdHlzBWubPcMxChppiuTopFiQkeYeVWnJLWpccgKQfpcNeEqOXqMheYIUrCKUSSWwHcPaOFuEVNeNFZAShimTMiuXp"), -707398.9069203935);
    this->MRfsQNp(string("FMHHzFHzZenbMxSYHFrWcnfYhfeuNkJfeqkRsbQldNVUZbjfPDmNhxvZLLSlgAzreXlmKOsomUvxTYlsFRWsIFJJWbSQkILXgIFvCWchcNEyKupLXsUchZLRhDUFbBZYAwajXWwqMBzdFVcoRVcenXnFXVovaIHdBynsZqbZrkjptAGhLEQZyTuxdczRW"), -364333, -495416.5730628386, 1980788248, -654609.8745702375);
    this->fEEMvi(string("oygWXlpXcoWXHtFVIFYaKWSpGDuXxeTqagrAfLWKUjvKwSVHxsSQZxLbOYSffedO"), string("gVUrWlUFTtDbwMpJLBDjfhoTbKTncpuKMBlFpnnDZKptKgAOpunnxsFRLSmSmbxDVCixKmC"), 1007574618, string("VcVmYsJWWTUErarfDGNkHdOYljsHZKdRHWMBpvdaUUVjVEtFYMxfwxZOjCFzYhMFtTXAfRrtTOCtCFuCsPhikOqQKHrVCjGpqnTVbtvTDMkfdGVXHObEASXTHamjcpMRTObOmVqotaPGldxZADYKQrdfFISpdVqCBKmOvEArBNrJawbIga"));
    this->RYdOKuFWqV(true, string("cOCkKWqHgojuDbDoFAaKwoTWWBfGxDiExXuTiuxpURSKNcWjfjUHOcElUASEkylzvJj"), false, true);
    this->PqfkId(string("bgMxyYckvkoRFJGMyjnDqmeMoFoadwqYLdwBSWnVrCKywlXzwxTgOcavUAiQIcUAZTvJAzxcyZsWG"), 538247.4005981117, -449564.7636076301);
    this->lLkYvA(-1634919531, -1042149.7872767715, 1187107423, -87164.92963375882, -541000.1670130523);
    this->bzlDprjUj(-634423.7373402115);
    this->pKSlkVpPHmvYErkg();
    this->yxihnMz(529443.4407431796, 463600.50378998544, 498663.7328076422, true);
    this->FiycPDFkfKn(303579045, false, -2025461618, 492689.99769088207);
    this->jtZVoRteIrFdOAjY();
    this->NgGcZMcmemWPXQ(string("FnhisegkYEnkMFxOQNNoxVlZKThWNlOgGJtnzJwQaOVGoGANYnrtrnVjFJEkDLcQPdguVmVvvnGvdyKzZkOtcCgtClWUHFlVPPpo"), string("TsKjlTHXZlMqCgcROWzkNqJowTCFzaXkAVpGStbtAtdKRmhSxxTstAOPsGyClWnZkmcRjTGDbkKbsgN"), true, true);
    this->MQMXEwmOdklOsD(string("IdjXt"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cSxrNdGDco
{
public:
    string DBZBsqmxzlgk;
    string ZfXIJaY;
    int PzrSFBcWf;
    bool YsJCTTq;
    bool cuaRzTcdNtDxDFh;
    string WNSlxmYTaczsWat;

    cSxrNdGDco();
    string aWJtmeTqYSGMg(int lXqYUjEaYaccs, string xWYPMyrfJxKVTIBG, int mvAiaqxIOWuWttgw, int qzwjqTYIlBLy, bool SCegqZYg);
    bool POsLZZv();
    string pABZoo(double tlCqNLO, string vQpJCwZBWOXGFAjG, string mRAvHCxpd);
    string ahlogDDfbMj(double pRaXQWAyWWhx, double pJwMkHHnO);
    bool YArzMShNUrB(bool PRDJEzjad, string LFYFdkn, double CmWGDVOx);
    string yPIsxcBx(double zvFRfNRJZVUdQeA, bool UoAebRorZDBHSAaf, int ShOtErwVsXMaXagm);
    int qlFckPusYOmSw(bool HpEirHhw, int QibNLGFTz, string XvmPBBQ, string GaVjD);
protected:
    bool TIaMxqlgJLpDHOE;
    string RDLJZaLqIM;

    int HjZGMzpMGHkS(double lmxUjtg, bool CQpFQlPXZyJYzFNu, bool oyhAOlSd);
    bool NoelPqNx(int wFhhWpTZLbk, string WjDpWag);
private:
    int xJlFnAfndpC;
    int MXKUSoum;

    string GxkIoiQL(string knAoldvJ, double GZztBFQfpBpurC, int NSFEikDyMEtv, int uBytAZctXjcyXDg);
    void izCAhUvWuAmtSj(bool ZItHUQG, int vAaTjDdSheBQu, bool pOusgpLcn, int zlXBizSuO);
    string cJMCJjrKKPze();
};

string cSxrNdGDco::aWJtmeTqYSGMg(int lXqYUjEaYaccs, string xWYPMyrfJxKVTIBG, int mvAiaqxIOWuWttgw, int qzwjqTYIlBLy, bool SCegqZYg)
{
    bool WGBPZhAolwKVFw = true;
    string LphngFYdTmLy = string("YWzDYJjOrZVEGFCVfGWziDdknjIrLaOofoxDpcaJaATwyPinZkNmgkCwAMhAkmLKDWoyKDjdxpRcwJVngeccffcBhMewducOKqhlBNbHUnsRHpscWmvsePKMEhEWIDrrBgWiEsLNUqJsmrpGKkKSErAQvrkhpnWNpWPjYmqQLwrwODLCEJXFzTFfDiCiaUqhZWpRDiVXGNjPuQEdEDzCcPoGDdtULfPGKEFuFxlQxU");
    bool noWhFEFaPu = false;
    int DbkoOBzQoUbF = 349408003;
    double UOsDgfxFIVfND = 81798.59340022902;
    double aBFGNX = -76398.21578539262;
    bool FEoBUvPmWQJkzx = false;
    double WDZJBccdIa = 957682.5693022086;
    int nnCQmcYUVjvNpa = -50737316;
    bool mmVjLDUcibJgtQsT = true;

    if (SCegqZYg == true) {
        for (int wVyXMPmvJa = 2074969451; wVyXMPmvJa > 0; wVyXMPmvJa--) {
            WDZJBccdIa *= aBFGNX;
            mvAiaqxIOWuWttgw *= qzwjqTYIlBLy;
        }
    }

    for (int hjWgIcz = 1657765401; hjWgIcz > 0; hjWgIcz--) {
        UOsDgfxFIVfND *= aBFGNX;
    }

    for (int FqiNZxYVkMyb = 37377181; FqiNZxYVkMyb > 0; FqiNZxYVkMyb--) {
        aBFGNX += aBFGNX;
        xWYPMyrfJxKVTIBG = xWYPMyrfJxKVTIBG;
    }

    if (WGBPZhAolwKVFw != false) {
        for (int lhSGeDkAeoZ = 256063310; lhSGeDkAeoZ > 0; lhSGeDkAeoZ--) {
            continue;
        }
    }

    return LphngFYdTmLy;
}

bool cSxrNdGDco::POsLZZv()
{
    bool MkqVd = false;
    double vvhqswjrFDErEj = -765196.338826571;
    string SCXUhpAjprUNgO = string("CnFbsKHmOowCtIROAXTiKzpTxruvFUKxKacnRmancCgBflbeZArzzzVMLeOQEGTzVxIAGLMwAShAyewLYSziKZccPeWcmNHhRbvoehanvhhAywYNFqApTxZT");
    int akcxjdTtMmKevR = 2027049741;

    for (int zpAZx = 1211146244; zpAZx > 0; zpAZx--) {
        SCXUhpAjprUNgO = SCXUhpAjprUNgO;
    }

    for (int ySTmeddeDfLqgui = 1903999422; ySTmeddeDfLqgui > 0; ySTmeddeDfLqgui--) {
        akcxjdTtMmKevR -= akcxjdTtMmKevR;
        akcxjdTtMmKevR -= akcxjdTtMmKevR;
    }

    for (int OPisHubuh = 471412747; OPisHubuh > 0; OPisHubuh--) {
        akcxjdTtMmKevR += akcxjdTtMmKevR;
        vvhqswjrFDErEj += vvhqswjrFDErEj;
    }

    for (int abqUkYElmm = 1591881295; abqUkYElmm > 0; abqUkYElmm--) {
        akcxjdTtMmKevR -= akcxjdTtMmKevR;
    }

    return MkqVd;
}

string cSxrNdGDco::pABZoo(double tlCqNLO, string vQpJCwZBWOXGFAjG, string mRAvHCxpd)
{
    string tSEDN = string("zjnqzUiaAYkRfVVBglWyOzhDCKCKndoQoyQqKIFUZlNRDZzCEYtsQphFRSEqWHzdySBijTCcSDEvrXpbYxSUSpneSlxvUwfFslrUKrnTqigxgXgFdHKEorPQxFuRgeuJwsEUNzFHfdnJuiSxXcGwRydlhDDgMAaQqOX");
    string nxvHQqVU = string("QLYSFxWALrdASgEiZCzhrUxYhtKtDdMWeFREcpnqudFDDeVsXSMqfIJATsxMQHuROBrafkoAgevFsBVpdbEscqyoqxZXbsaKPVlZnfbWVxSEvnHFLAtGnVXq");
    bool IfYAZTumVlNsmptG = true;
    double jGxWCy = 308286.7302932305;

    return nxvHQqVU;
}

string cSxrNdGDco::ahlogDDfbMj(double pRaXQWAyWWhx, double pJwMkHHnO)
{
    string lRFpVkyXRp = string("gcSekLrXxEakMZnhwQhnCHgkYwYNrnEXRAcufTlIyoghmKlMxilfXl");
    bool PqdGZhkfdZLGM = true;
    bool zKeYGAHbKXNFYcB = false;
    string veFVv = string("ujnrYutVBZzPwJPWTUWxHIbkMUTbBbPWYQqKbCAoCkVMeTQDbrycMVbjmtRvLEQDmEfhrkHWKEjDxvRErBtfIffesPNOisMtpUfQkQSBKIlYBnyHYLBLzyyOvJjTIOSHuuDqnVIBdsdXidTtmemhvDGAcmkUjpWOiAIVl");
    string oydxqcGq = string("IvGWqRscNfJPkQrZkvdqHynhPTYfvAydqqWqNipgMLrFJmrykorscWfVdPLPojIlydVssPfacedMWVfHedQXKmWgtKKChDobVHEbbqWrQMdaEBlkDkMVpXYHhzS");
    double SGtXrkvjcgqGD = -122814.42200202234;
    string LbnozUO = string("rSChQquOGXacWvrAZMPMqIAcQzuYhMJNArr");
    bool dLMLuUmzwq = true;
    bool VGtqhMj = false;
    double JmMsxWIm = -484095.64009323274;

    if (SGtXrkvjcgqGD >= -621773.9970816638) {
        for (int NprLpUi = 2085281563; NprLpUi > 0; NprLpUi--) {
            continue;
        }
    }

    for (int CdprjukaTnoFJR = 556020656; CdprjukaTnoFJR > 0; CdprjukaTnoFJR--) {
        oydxqcGq = oydxqcGq;
        LbnozUO += lRFpVkyXRp;
    }

    return LbnozUO;
}

bool cSxrNdGDco::YArzMShNUrB(bool PRDJEzjad, string LFYFdkn, double CmWGDVOx)
{
    string bQZLuyfj = string("tuaDWpbXuzzQjFLDGVPsoekFUTkxWBdxYjZZYeApFZQybUPKkYlxWYuApJfezDViFfnaoNRMoxfXdfoaRHQApKEGuSQWovMyNDwOJlanJobpKXzhwPAizxHEWSslOJwZEiNCMCXjRJFuTTImjlTulIeNHoEBgRviDycIPcBtwiZJiGnnzxgSZeqqHNIcUF");

    if (PRDJEzjad == true) {
        for (int uTSvrF = 1818009453; uTSvrF > 0; uTSvrF--) {
            LFYFdkn = LFYFdkn;
        }
    }

    if (bQZLuyfj >= string("RvijbNeoTXNktSiaoZzYAEPvDPwnrjpevuPgGuMaRKqOpTlDMjoGHqugsNfBryegwMXbMOMTIMDhwvPHppVhLuxZHUeqRsEcwzPbUszTQMytgRrVbZUGUHQGLGhhHGOumqnqJjDXJvhdLKyIGtrWcDzYzUpQEtebfMGDQfuMBhsOfjdJfeowAWrfIUzwOAQZCeFzLnHTDwIHXOFktVyGRUEZmswPZyuBXyTRiFZzHcGsuklWNsSmDPq")) {
        for (int niJHPvpqDt = 327359831; niJHPvpqDt > 0; niJHPvpqDt--) {
            bQZLuyfj = bQZLuyfj;
        }
    }

    for (int YdSuBsxSa = 443983871; YdSuBsxSa > 0; YdSuBsxSa--) {
        PRDJEzjad = ! PRDJEzjad;
    }

    return PRDJEzjad;
}

string cSxrNdGDco::yPIsxcBx(double zvFRfNRJZVUdQeA, bool UoAebRorZDBHSAaf, int ShOtErwVsXMaXagm)
{
    double mBchynk = -89563.42632199546;
    double uLzVylXuDGxJxvUz = 818994.7308127425;
    bool jLaGHsfGFov = false;
    string mZmIpDOJDODiRv = string("ddWzEBxTLsuqMMUQESAJRDVleAMrdtFgxUvWENZidKOPzqgItYZIcpjBjQkGmauHlkKlEGK");
    int PTZCmuXHfN = 1837178619;

    return mZmIpDOJDODiRv;
}

int cSxrNdGDco::qlFckPusYOmSw(bool HpEirHhw, int QibNLGFTz, string XvmPBBQ, string GaVjD)
{
    double QFQEe = 192540.2395982006;
    string focrFzXQbOnb = string("qGdKHPQxemjNHjYIjDyXstuoIBNeEHgggYkvSWxgWJlkmQQankJBqBopcyajplqlcOSrcPUdTdJzNzXLPOfyUQJUvXkJqYiFcqiEMFGKopsSMjxzQLXhnAAGQBZEJsZsslOHoDbzxDWMnsOzhxRIQqEiQZWZGRTRasFITqlkOMaFZPeEBQMZZixSZxzvOYxZxfrXIQjdbPDeiEVFKUuwngftCdcXjXCBaITIAtmdCduREpCjC");
    double ogPsKNOzFRjKanD = -675362.2259009496;
    int lfrTDIg = 1503025602;

    for (int rUrIYOTA = 987542199; rUrIYOTA > 0; rUrIYOTA--) {
        QFQEe /= ogPsKNOzFRjKanD;
        QFQEe -= ogPsKNOzFRjKanD;
        focrFzXQbOnb += focrFzXQbOnb;
    }

    for (int BzsUKlsXtC = 671787707; BzsUKlsXtC > 0; BzsUKlsXtC--) {
        ogPsKNOzFRjKanD += QFQEe;
        ogPsKNOzFRjKanD -= QFQEe;
    }

    return lfrTDIg;
}

int cSxrNdGDco::HjZGMzpMGHkS(double lmxUjtg, bool CQpFQlPXZyJYzFNu, bool oyhAOlSd)
{
    string oaQSXwfKMnaXBP = string("kKIbgXOAleoDoOudcvuXPqgjbPIGRcdkuyVRLoFGIqXMjFaboUGaidcftvWZAKOpwpocDGGbWOngqqwHqdjUJQFVHtKqxxLRBddZWJCFweIAfrkVIuVgwvDUgYtXqTWFhSNwKmEBNbcXrLTbFqPOIPaSvbgFXkGpGUyXJVUUJvyH");
    bool iFSFoiaAuyOr = false;
    int mNiKjIxZLpNAIeZ = 863023056;
    bool qoEKgzndjWHIs = true;
    int xhGywnrXXfpswmJ = -1026502328;

    if (qoEKgzndjWHIs != true) {
        for (int lDSHNx = 1651312187; lDSHNx > 0; lDSHNx--) {
            iFSFoiaAuyOr = iFSFoiaAuyOr;
        }
    }

    return xhGywnrXXfpswmJ;
}

bool cSxrNdGDco::NoelPqNx(int wFhhWpTZLbk, string WjDpWag)
{
    bool cIeyYw = true;
    double fDkmCWHZ = 985472.853707082;
    double NrYiJxHQeHkaAA = 1026565.274085416;

    for (int vIkjaWmtnHkQ = 1353954370; vIkjaWmtnHkQ > 0; vIkjaWmtnHkQ--) {
        fDkmCWHZ *= NrYiJxHQeHkaAA;
    }

    for (int SsJjICi = 6730860; SsJjICi > 0; SsJjICi--) {
        wFhhWpTZLbk /= wFhhWpTZLbk;
        NrYiJxHQeHkaAA += NrYiJxHQeHkaAA;
    }

    for (int KkXaUO = 409862776; KkXaUO > 0; KkXaUO--) {
        continue;
    }

    for (int eeBkFpq = 1999378142; eeBkFpq > 0; eeBkFpq--) {
        fDkmCWHZ -= fDkmCWHZ;
    }

    return cIeyYw;
}

string cSxrNdGDco::GxkIoiQL(string knAoldvJ, double GZztBFQfpBpurC, int NSFEikDyMEtv, int uBytAZctXjcyXDg)
{
    int KMgrPriVCBXIkykF = -891708708;
    double ihnJwmCfSfOhZbmB = 370241.9346265074;
    string yFuUhxUvn = string("BCGJBBmIrqcnJXuuRkgIbGsfRLhsxKbrkzZsFHVIWLMJKvRTsFnOucGcNVcTAXkUKztGiXqTFlZiZt");
    int rmQJUAkbDvdQkTR = 1927395318;
    int pfkNDcmSUvtps = -394527641;
    double BxPKCoQl = -364312.63616329624;

    for (int rPbuBlshftRYf = 504155638; rPbuBlshftRYf > 0; rPbuBlshftRYf--) {
        GZztBFQfpBpurC /= GZztBFQfpBpurC;
        NSFEikDyMEtv = KMgrPriVCBXIkykF;
        pfkNDcmSUvtps += uBytAZctXjcyXDg;
    }

    for (int qwvpFmXLJEwQhLh = 1186130146; qwvpFmXLJEwQhLh > 0; qwvpFmXLJEwQhLh--) {
        yFuUhxUvn = yFuUhxUvn;
        KMgrPriVCBXIkykF -= uBytAZctXjcyXDg;
        NSFEikDyMEtv = rmQJUAkbDvdQkTR;
    }

    for (int QqHcSZJUeVWV = 974130663; QqHcSZJUeVWV > 0; QqHcSZJUeVWV--) {
        rmQJUAkbDvdQkTR += KMgrPriVCBXIkykF;
        uBytAZctXjcyXDg += pfkNDcmSUvtps;
        pfkNDcmSUvtps -= KMgrPriVCBXIkykF;
    }

    return yFuUhxUvn;
}

void cSxrNdGDco::izCAhUvWuAmtSj(bool ZItHUQG, int vAaTjDdSheBQu, bool pOusgpLcn, int zlXBizSuO)
{
    double UAZneEd = 156426.76531853923;
    double TRqSIdUmSrlNrLT = -387653.34474721475;
    string pMjrbLrNQqR = string("UwTCKrRRXaookVPFlZqbGKIRLaNjCDyVZvNBfmxVIdRPoYzAJuZcPmGzcxDuwGOfjgLNJCumHlKgn");
    string WEzmYJVDpCX = string("ivCfMepCEkKMvyXsbWewHrrfeniclhdOWGJifUFPPVbAFKgZTtFWRQsttVvGSNABZzikBArzXJwCbHalJzGojcxzSkewKhxjrjvydSQNTFxIGCdfvLnqzhCIXkorZyCNVVqmRjYxuKZIKMeilDxTbcgxlLuVqdbBJWcuBBzCqnuZmloPxuFBYheuymHdMYKgrOoXfkfZoGfHGUISk");
    bool kmeoqZV = true;
    bool qBndf = false;
    double ufjErxjzpKuQicmC = 114283.83060813537;
    string FNzXZT = string("zXqwZSXCbrwuyGTPMbLlTeXYqIhTVuMHgPoHmRXiIbKcDyysdNfmLEhtYzengDPhkjdOOyfTHXVQsZOzOTfsUKhNkrYUOnoDMweRTCJaeYppHbJYsbQiONsnAwVQfuBDVRtqLTgKsISxkDyKwFIbyEZvsmWxWkXTfWgzO");

    for (int MsOavoJCV = 1239007980; MsOavoJCV > 0; MsOavoJCV--) {
        continue;
    }

    for (int XFaWVcN = 848132629; XFaWVcN > 0; XFaWVcN--) {
        ZItHUQG = qBndf;
        WEzmYJVDpCX += WEzmYJVDpCX;
        vAaTjDdSheBQu += zlXBizSuO;
    }
}

string cSxrNdGDco::cJMCJjrKKPze()
{
    int EJJFehBojS = 618708545;
    string mOTylC = string("nBnXQmeZyHE");

    for (int FBgaTFQcKwZ = 1265754056; FBgaTFQcKwZ > 0; FBgaTFQcKwZ--) {
        mOTylC = mOTylC;
        mOTylC += mOTylC;
        mOTylC += mOTylC;
    }

    if (mOTylC == string("nBnXQmeZyHE")) {
        for (int DeLNdeDpuyDzXj = 1748016978; DeLNdeDpuyDzXj > 0; DeLNdeDpuyDzXj--) {
            mOTylC += mOTylC;
        }
    }

    if (mOTylC != string("nBnXQmeZyHE")) {
        for (int rfRoiuZfhi = 1410793213; rfRoiuZfhi > 0; rfRoiuZfhi--) {
            continue;
        }
    }

    return mOTylC;
}

cSxrNdGDco::cSxrNdGDco()
{
    this->aWJtmeTqYSGMg(-528766552, string("IhfeXVjKIQkAUgelhKLfueNLxGmmzLrLEdNSBSbzjAzzHDasNequqYBYMiHWMyDpASBzhLhHFJIgetijNnHVjtGKvCvOIrSLJqJcLEJRjKIShffljjrJYxGpGYMyZmbQVNflbOTRpchwvAuPPczrOctGhSDszVDmEYduMrNeGriGCOsXCBrEWeMcmLKeOoVwqERZgsaGVowWLzegNcCteUxdSERMEPexLZQSfCYeCqzbKKYtK"), 1913321482, -1198251010, false);
    this->POsLZZv();
    this->pABZoo(400101.29795079184, string("MErNNmFQkgmCAEzIqIRXerfLjcdNGVCUDPGEacqcejyRLjfXbsUhdrWcWlrAOXOWyxxFTKTFFUQUelGebsfnehsncIGfBBGKCbcPfXYFIMpnbFeElgWGdnowYbRUYXyNGovfjKAAYh"), string("RLoNxoQSqKqMdKFhNdyeuztPHUmHMKdDTOimAEWpJOHfISunskJkkIPHMzVRIWPSmzkxKaArTFfAntslBfqCjeOLPldOpSOVpleLCXsBZZCnCbndrZvdidgbtRGTLVkSQNSjfZeUdfUpjDUbUemJssHiDfiEiZewOwsyNAfVQnTY"));
    this->ahlogDDfbMj(-621773.9970816638, -67398.42180639585);
    this->YArzMShNUrB(true, string("RvijbNeoTXNktSiaoZzYAEPvDPwnrjpevuPgGuMaRKqOpTlDMjoGHqugsNfBryegwMXbMOMTIMDhwvPHppVhLuxZHUeqRsEcwzPbUszTQMytgRrVbZUGUHQGLGhhHGOumqnqJjDXJvhdLKyIGtrWcDzYzUpQEtebfMGDQfuMBhsOfjdJfeowAWrfIUzwOAQZCeFzLnHTDwIHXOFktVyGRUEZmswPZyuBXyTRiFZzHcGsuklWNsSmDPq"), -35104.38645740668);
    this->yPIsxcBx(61867.16864927682, false, -341545583);
    this->qlFckPusYOmSw(true, -1903273306, string("sXvooaDOdlTedSkubTFgrhDbVyMRjIeidKbkioMPOazfAouAwDKHKxDiFlEsFhSgApKRqobzrIKNfHJhtzyBtxxhSBxtnhXFGJEXuWFKNrkeGxVABFQMImpHvDfKGbTZxzZAVlXwOnvnhWtLCeBaorfwBTluEtSUmttSroNdoctqXgQrkitmrXLeEciGqlTPqElZpZHACnomOoNRFfhm"), string("dIzEpywJeexIBQVKhczhoxcpfghCchHRAxFTOZiGpAetIiXsaCYIDzylYltpDCQrLlMVsqQkCtInqNccuJxeMYMCOfhhzCDMhkYhdmjyNLRCUbAGhclofeuBLiBlpIXumcuuLHwHAlqdarIFPYZEasaawqReluQoaQVHBKLRaNUxdoJvnyCEHnEGgezkm"));
    this->HjZGMzpMGHkS(-265212.3957325616, true, false);
    this->NoelPqNx(-607854489, string("QGZGslKsVIDSwXswZypFsWrPgLzgwNnkKmpdiLlkpcCPEohIhGLyCQUjEkyVGdkqeWRToUZyXjqjvRvvYXymxKZXWRgoIQfyEZMnwafHLaBKRfCppLLVsaIDHygIYQExeRMtEcIWRJpLnQbpKRGnWOhLFmnrfUcKTvxDytoBBUVqknTSjgoOztlMJlIRQHDLKppVykHsO"));
    this->GxkIoiQL(string("izRaFEHfgqdmA"), 464770.71509540454, 1263595323, -1387065817);
    this->izCAhUvWuAmtSj(true, 220576267, true, -1798586259);
    this->cJMCJjrKKPze();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TqNqJIGkOIeOG
{
public:
    int kjyoGSK;
    bool ubRGLsoVkMOPiSp;
    double hMsOhMFjNRwAdYTl;

    TqNqJIGkOIeOG();
protected:
    double UzoKzyRUkMsPpvb;
    double tFzKJ;

    void WNiav(int thhXImqYJ, double RXMcNlLe, int wPswolbp, double pjRUtxDXqsd);
    bool bsOhjMduRIOtycXh(bool pqdFvzHwJM, int HQzOrkccWDFqM);
    string vibPUjH(double zNajN, string tMUQmbE, int XrXjEtVSf, double wtUKhKWb);
    bool YSXaUyzbZnO(bool WxGGTIOnkhQBbDB);
private:
    int noyROHk;
    double npqRvCZJhCTaxOk;
    int VgTeR;
    bool CySUwl;
    string xVQuLCOdbfkBu;
    bool fjFfIIPcb;

    string FYPACxHUUz(bool rOLcMF);
    bool quIxqlywKGUFP(int vQjgAzG, string GUbmZylCDI, bool hLSPabJXXnSFgncy, int oRMrdBiPZPK, bool voqWuXLZe);
    int NZTEA(bool RzvcIftIpJKYoOu, bool YQaWwJvy, bool GoGQjJnX, string BzQbXL);
    void WlsUEBqbO(int PmsfFQlNT, string MBGXcNmOqNDsUx);
};

void TqNqJIGkOIeOG::WNiav(int thhXImqYJ, double RXMcNlLe, int wPswolbp, double pjRUtxDXqsd)
{
    int OwFpNqIwwZMy = 1880188115;
    string yjCpQS = string("vYxwBUqftphwcveesuSmEMWuzxAqmCdnmitrSQLKKfvhuXiSggiSlBeGOiFhofMQGHjBQYIovdtHpVyBWmdCFPZkuRcCfBV");
    bool xfOHZpfDWfkgBZEF = true;
    int okvhkviyxdRwC = 710041570;
    bool XZKfsBGtoWa = true;
    string rbguERQLBufVao = string("FHwevWvfIJSXbJGQtFbiWoVRDDwscnXLLlLgXhWvzQxLoaShABxvn");

    for (int BlTcYpOTBUMbhv = 482723317; BlTcYpOTBUMbhv > 0; BlTcYpOTBUMbhv--) {
        continue;
    }

    for (int yDxLS = 1414777459; yDxLS > 0; yDxLS--) {
        yjCpQS += rbguERQLBufVao;
        wPswolbp /= wPswolbp;
    }

    for (int iywEbLO = 477689002; iywEbLO > 0; iywEbLO--) {
        rbguERQLBufVao = yjCpQS;
    }

    for (int yOPRJGT = 602110109; yOPRJGT > 0; yOPRJGT--) {
        continue;
    }

    for (int kCAuKdvfblabJO = 254718052; kCAuKdvfblabJO > 0; kCAuKdvfblabJO--) {
        thhXImqYJ *= okvhkviyxdRwC;
        XZKfsBGtoWa = XZKfsBGtoWa;
        wPswolbp += okvhkviyxdRwC;
    }
}

bool TqNqJIGkOIeOG::bsOhjMduRIOtycXh(bool pqdFvzHwJM, int HQzOrkccWDFqM)
{
    int MKuSFdXTbRBDgPMN = 1984593425;
    double DSjKrVlXPnjrfwf = 730110.4969764686;
    double sRPyuB = 639475.3256910021;
    string YyPXmezcqFjMzTf = string("NHQtCPPLHfuUiaRcqAFyusdxvpMcrkMGwYejGpVuzCJSblgErnAyofiOLKDrYTrLIqmKcVBnXGYXaRFQUZMKqJKPIetMmSMlC");
    bool uyJpvrsbihQYjvCK = true;
    double elFxz = 620573.4315541481;

    for (int yEZbOpOnME = 407499110; yEZbOpOnME > 0; yEZbOpOnME--) {
        DSjKrVlXPnjrfwf *= DSjKrVlXPnjrfwf;
        pqdFvzHwJM = ! uyJpvrsbihQYjvCK;
        DSjKrVlXPnjrfwf *= sRPyuB;
    }

    for (int aJVkInntgz = 919382495; aJVkInntgz > 0; aJVkInntgz--) {
        DSjKrVlXPnjrfwf -= elFxz;
        uyJpvrsbihQYjvCK = ! pqdFvzHwJM;
    }

    for (int BkPdAzPko = 399316868; BkPdAzPko > 0; BkPdAzPko--) {
        elFxz = DSjKrVlXPnjrfwf;
    }

    return uyJpvrsbihQYjvCK;
}

string TqNqJIGkOIeOG::vibPUjH(double zNajN, string tMUQmbE, int XrXjEtVSf, double wtUKhKWb)
{
    bool EfsmXSwJ = true;

    for (int DjUYtIOmM = 1532402541; DjUYtIOmM > 0; DjUYtIOmM--) {
        tMUQmbE += tMUQmbE;
        wtUKhKWb *= wtUKhKWb;
        wtUKhKWb += wtUKhKWb;
    }

    for (int LowsQX = 1290839104; LowsQX > 0; LowsQX--) {
        zNajN -= wtUKhKWb;
    }

    for (int zWpNvzpkJznUrN = 1628938531; zWpNvzpkJznUrN > 0; zWpNvzpkJznUrN--) {
        wtUKhKWb /= wtUKhKWb;
        zNajN *= zNajN;
    }

    if (tMUQmbE != string("gzwyBKKfchEDwIWCVVUJMwAoqhxaaRqeiKpjogfdPMvzTBupNhXQMhPWkmyxqowUIOLVHZMmcPqbwBXEtkdyTOPRCfReIYyPVdQpevMOWpDdeJeTuGnImPBolbValeGQoOYlXuLLqNfyuxyaZLujQWgzebbNMnYMGZBSAghkceZvEiAoCZgDTguiaHxEAKKAaYIIdzvEJmTlcnsDUTjDhKKRBepTerfwnlUW")) {
        for (int HswReyGlfit = 1670921389; HswReyGlfit > 0; HswReyGlfit--) {
            continue;
        }
    }

    return tMUQmbE;
}

bool TqNqJIGkOIeOG::YSXaUyzbZnO(bool WxGGTIOnkhQBbDB)
{
    string AKVllUh = string("jAnfAnBfKEqCPdtPnonSgqmaKFwJmqEpGZzMYjDCGqJnGvXJkefboswQRRVWWgLvITavRqmHzsOqWevQrRruvZuowJMsoxRnyovMViTtsRaajoKHZwohPUYxPAWWvdDxyHoDAaCxXLtQWXsPHlOpIhdJmgxdLOadBKzZdARkt");

    if (WxGGTIOnkhQBbDB == true) {
        for (int FBHAzfs = 513571415; FBHAzfs > 0; FBHAzfs--) {
            WxGGTIOnkhQBbDB = ! WxGGTIOnkhQBbDB;
        }
    }

    for (int LNiowJMDusgoi = 760373945; LNiowJMDusgoi > 0; LNiowJMDusgoi--) {
        continue;
    }

    for (int pASSnuKtZjyCi = 1469509801; pASSnuKtZjyCi > 0; pASSnuKtZjyCi--) {
        WxGGTIOnkhQBbDB = WxGGTIOnkhQBbDB;
        AKVllUh = AKVllUh;
        WxGGTIOnkhQBbDB = WxGGTIOnkhQBbDB;
    }

    return WxGGTIOnkhQBbDB;
}

string TqNqJIGkOIeOG::FYPACxHUUz(bool rOLcMF)
{
    int YGhhyeIR = 1923542005;
    int bomfk = 960561958;
    bool nVgRVSDB = true;
    string gspDjXrYuZSIA = string("bzsDwVdXWTXcEXBAICXUGiVENDVHQRqZKrpjLsAviSzvinckLhtNVkTuHtEtLLpBtDyzLnqbMpmsqdjQcjFezLyNuemFLWIDyGkIWSqGqNwl");
    double rBKmtBQU = -947697.8532738426;
    bool VDSsjHhqxqrC = true;
    bool Fscelpavnn = true;

    for (int gvJLZRHRIbDtDxaG = 1919616372; gvJLZRHRIbDtDxaG > 0; gvJLZRHRIbDtDxaG--) {
        continue;
    }

    if (VDSsjHhqxqrC != true) {
        for (int iILNjttla = 808814403; iILNjttla > 0; iILNjttla--) {
            nVgRVSDB = ! rOLcMF;
            bomfk *= YGhhyeIR;
            nVgRVSDB = ! VDSsjHhqxqrC;
            YGhhyeIR += bomfk;
        }
    }

    return gspDjXrYuZSIA;
}

bool TqNqJIGkOIeOG::quIxqlywKGUFP(int vQjgAzG, string GUbmZylCDI, bool hLSPabJXXnSFgncy, int oRMrdBiPZPK, bool voqWuXLZe)
{
    double pPjquNxJatWJQdn = -178505.20577432413;

    if (vQjgAzG == -186731193) {
        for (int SeczObxAnBC = 978628684; SeczObxAnBC > 0; SeczObxAnBC--) {
            GUbmZylCDI += GUbmZylCDI;
        }
    }

    for (int hqsVjTULyMomv = 2141484116; hqsVjTULyMomv > 0; hqsVjTULyMomv--) {
        hLSPabJXXnSFgncy = ! voqWuXLZe;
        oRMrdBiPZPK /= oRMrdBiPZPK;
        pPjquNxJatWJQdn /= pPjquNxJatWJQdn;
        vQjgAzG *= oRMrdBiPZPK;
        hLSPabJXXnSFgncy = hLSPabJXXnSFgncy;
    }

    return voqWuXLZe;
}

int TqNqJIGkOIeOG::NZTEA(bool RzvcIftIpJKYoOu, bool YQaWwJvy, bool GoGQjJnX, string BzQbXL)
{
    double APxWTVRaqulthpn = -714086.2732935839;
    string hiknbP = string("dlRTuWHMqwevtorCZmkiYSdnyNHQjtVTDNQwswjEuTlqfITSYNyuOeKamqbxJILUlWlRJEocgTKeOxTfpULkonyWnTwPTtgiGTGoprCdtmkzsovVfdywNhmGXCGUVfwKeFrDEZOrWRUxHBJVvFkyMmTcGHpMZmRTzuPzNiuOfOIYigXVysbWYRBSnoKWWYcUWXmbvlFlFVYAaYxIGXagxzCxPfYBiWXDPpXkHMYKUfJm");
    int MjzpBv = 718669240;

    if (GoGQjJnX != true) {
        for (int tErbRZDcL = 1338441290; tErbRZDcL > 0; tErbRZDcL--) {
            GoGQjJnX = ! RzvcIftIpJKYoOu;
        }
    }

    return MjzpBv;
}

void TqNqJIGkOIeOG::WlsUEBqbO(int PmsfFQlNT, string MBGXcNmOqNDsUx)
{
    bool FhWAIUMYPW = true;
    double qUkgWLY = 106737.80552393812;
    string GiyEuBPN = string("zSnSLoahQvNzmbvXIDqyrgKTZlQTVcdshdPzVcYtcmnPIztMivQTcJtvfHoQzFBgYoWOnNCVlsqGTudFpacxxMoMIFLvBhWvgFOFmVEKerUDtvqjHBXSXAwq");
    string TPyHQFWrwBXJNyM = string("zYJzdnTLHNyreUyXPNgdFSvvJNgVOQEbfDKrCqEZTdBHXdbzKVfnXtOcCJBWn");
    double hwJyMaZxyyWQXpk = -353844.4532173068;

    for (int YIRzCwDvI = 973776497; YIRzCwDvI > 0; YIRzCwDvI--) {
        MBGXcNmOqNDsUx += TPyHQFWrwBXJNyM;
    }
}

TqNqJIGkOIeOG::TqNqJIGkOIeOG()
{
    this->WNiav(-1535826031, 184020.34729293038, -2023785044, 305575.2201348945);
    this->bsOhjMduRIOtycXh(false, 139481369);
    this->vibPUjH(-488376.561110967, string("gzwyBKKfchEDwIWCVVUJMwAoqhxaaRqeiKpjogfdPMvzTBupNhXQMhPWkmyxqowUIOLVHZMmcPqbwBXEtkdyTOPRCfReIYyPVdQpevMOWpDdeJeTuGnImPBolbValeGQoOYlXuLLqNfyuxyaZLujQWgzebbNMnYMGZBSAghkceZvEiAoCZgDTguiaHxEAKKAaYIIdzvEJmTlcnsDUTjDhKKRBepTerfwnlUW"), 1722156299, -437443.3647479009);
    this->YSXaUyzbZnO(true);
    this->FYPACxHUUz(false);
    this->quIxqlywKGUFP(-1566761956, string("LLeMzVPGwKJxvzGZqEWv"), false, -186731193, true);
    this->NZTEA(true, true, true, string("HjDirpMQZVFLZkktVCcykDyoBotVOCpDOVTqyWEAAmnVkQblwPEryIVsdPGSDyDNqlpkNGDAXphdOqtHRZPKGAKrTciMwmSQmLZEMlhZYtLvDsbzfKQJtCEhpPYsFaKtAqKtEmlqWJPYrHWoXbtjPwDXEDYEMzCSmtJZzqBBnNBCsFMxivPNqfSwKqjiKupzkdnRlLRhRObyzhGymyeezWCuBuzY"));
    this->WlsUEBqbO(1662243688, string("tvRYLvcLwQueNjmsxmPBjEHfudcUMzpCBtbgTnQYWFOLdzNWaYbiEIOrTDQenULiajzmJjojWBdGFoTKBpvaPsHPJePpguUbunJqipxVoPRZkJXsMMcTKifDmsKqgMcFJZuBYNbVDJNjknBLhkyFvlWAxRpDgNYCnDQhOuMgbWpULYrXsajzlHPCgv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VsXhyikF
{
public:
    int gBHQsQctu;
    bool Unqoua;
    double ANqZiu;
    bool JGuiVGyecCxr;
    double oSWZnlGtVsAMLG;
    bool rgNvaKh;

    VsXhyikF();
    int QfwtqXGNAAtBbB(bool bbUYYDcLmDIecru);
    bool IEmQNKR(bool fXrpjzeXljVES, double ahWnOsfgfEpNEC, string dKErFeLIBOGNFqSM);
    bool RmdxPAGazot(string yrvValA, string iMbOmqJEX, bool CIugAGmhugKyv, double cxbmu, string dYxQtM);
    void cMfztkgOIWPue();
    void oYlYrykQfqvv(bool uyVTCUWdDqOgYyl, string zgPIVYEiZ, int lcBPvEplvKSjEpin);
    int sxMbX(bool eNPGFo, int CrIdPFuiy, int WZIJuTqLLcE, double JlOjuFcaJpaqg, double rvYmhNPXup);
    double IfHgyEnDEYTbQLZ();
protected:
    int wOKzZ;
    double DqZxArvnD;

    bool HmfLCj(double mMdfT);
private:
    int SwLmypxpJm;
    double UUOZUDbzn;
    double bostOMqVpeQJ;

    void FxbaNjMkBcQ();
    double bfQcaIqEoqqsbQy(bool zcXna, bool DBtFXQesZtgJMHd, int cVBMmrBwY, double SpndLDJ);
    int ipKIuWZSxDINGAi(double ozwwXnB);
    double IIVhzLNXxnDfihE(string TsYYcuKlEYVUW, bool DwIRH);
    string LOjOHuPHWepZ(double xmoFustmaaiQhKuQ, double zXLRFpf);
};

int VsXhyikF::QfwtqXGNAAtBbB(bool bbUYYDcLmDIecru)
{
    bool kqCJpZpzerZq = true;
    string dgFnQgxJbCxx = string("VFYIRiFPrunOdtUCMynCxirobstlOadkdsVutOxvEexLbeNnCekbTodUTNfkBGoAgKkitvdAAfETCHreCXQNOkBBKVLfAwzinMheUXEonanSBNnWAFfbPsmWySddFkaDekBpeeEzTqdYSjhHpgNYPLKqyMHPh");
    bool lbAHgtz = true;
    bool HevrtPV = true;

    if (HevrtPV != true) {
        for (int MtGrwAQb = 1787378740; MtGrwAQb > 0; MtGrwAQb--) {
            kqCJpZpzerZq = ! HevrtPV;
        }
    }

    if (kqCJpZpzerZq == true) {
        for (int WpdbDILtnTPZqTn = 2058179359; WpdbDILtnTPZqTn > 0; WpdbDILtnTPZqTn--) {
            continue;
        }
    }

    if (lbAHgtz == true) {
        for (int jWXCS = 864697758; jWXCS > 0; jWXCS--) {
            bbUYYDcLmDIecru = ! lbAHgtz;
            bbUYYDcLmDIecru = ! kqCJpZpzerZq;
            kqCJpZpzerZq = ! HevrtPV;
        }
    }

    if (lbAHgtz != true) {
        for (int CjzzUjyG = 1143852376; CjzzUjyG > 0; CjzzUjyG--) {
            dgFnQgxJbCxx += dgFnQgxJbCxx;
        }
    }

    return 1309669317;
}

bool VsXhyikF::IEmQNKR(bool fXrpjzeXljVES, double ahWnOsfgfEpNEC, string dKErFeLIBOGNFqSM)
{
    double kwOYYIQ = 549162.3590984629;
    string rLpwpCrBBfSBCAo = string("yPqkuxlGaBEEDVibcwbHVQVyNDxJwsaTLhWHFVjehrCQkuOvQcvAefUJMYWzRplKIUBcbQUSVFHrTwnumLyLwTwqqKRFdcIbJQuaxZrFrLGZjPWRRBrMeshWFjGiRDf");
    bool ZgKgI = false;
    string pYFRDYjFtoTTwUnm = string("sgAmHJLffATNTOELpSnqGFasPuBfPEpERySeNGkbUoYOMuifIyEecqwQzRLDUVUwkCtXsGgJaPQcOAJhuvpnVTOEVXDqqRDqXUSbxFWEANuPTKMVzGGRrPYtNtbNtmRHDCoNauQIlHGwIkIqjrEodSZMXdvsllaFJBYhzzCofuoKLnaAIQBBMCaHTmrsrVVtYJXPsFOTYFOZkeLoaNbcpPpxzihwejFXB");
    double oZNyDuqVAHoHXT = -852627.2902648164;
    string PtpyTYvJoEusJ = string("whKMiQGinZdzFDRxdNrmmqbYlyRArptyGnJkQVBbgvAXMjXdQDSaYrZqdFPBEOfWcAYviBXoPsSLbtSlrIAFcNCnkCUgmsetvMuSBFyVWWkryHIZWtvFUcpkAPBVWImTydZFUaVBELGlLCvxrlGTmKWcGRdAozSZKDOwHSsiRtPnfVVqZFd");
    int uTzMT = -1385234748;
    double hTxxNAIJpN = -269690.2580425622;

    for (int lllVqpII = 2090268556; lllVqpII > 0; lllVqpII--) {
        continue;
    }

    for (int oqoOnyytqtcTRaz = 2037064896; oqoOnyytqtcTRaz > 0; oqoOnyytqtcTRaz--) {
        PtpyTYvJoEusJ = PtpyTYvJoEusJ;
        pYFRDYjFtoTTwUnm = dKErFeLIBOGNFqSM;
        kwOYYIQ /= ahWnOsfgfEpNEC;
        oZNyDuqVAHoHXT += ahWnOsfgfEpNEC;
    }

    for (int wRnwbSRBdTm = 915593683; wRnwbSRBdTm > 0; wRnwbSRBdTm--) {
        uTzMT += uTzMT;
    }

    if (fXrpjzeXljVES == false) {
        for (int ZxjQAIMuxEc = 1533529263; ZxjQAIMuxEc > 0; ZxjQAIMuxEc--) {
            continue;
        }
    }

    for (int CaDLP = 1935559137; CaDLP > 0; CaDLP--) {
        PtpyTYvJoEusJ = pYFRDYjFtoTTwUnm;
        hTxxNAIJpN *= kwOYYIQ;
        rLpwpCrBBfSBCAo = PtpyTYvJoEusJ;
    }

    if (oZNyDuqVAHoHXT <= 549162.3590984629) {
        for (int ZkDMHmZzBgFr = 592633025; ZkDMHmZzBgFr > 0; ZkDMHmZzBgFr--) {
            continue;
        }
    }

    return ZgKgI;
}

bool VsXhyikF::RmdxPAGazot(string yrvValA, string iMbOmqJEX, bool CIugAGmhugKyv, double cxbmu, string dYxQtM)
{
    int VAtKVWjr = -808355599;
    double CyvlNGvIxjk = -123719.87943769051;
    bool JEZuHxzNItmQN = true;
    double hcdEXDoAw = 806508.1737747731;
    double KPEBHMVhv = 673931.735016422;
    string PlTFX = string("vBFDfWEfVoTwzWfsFwbJUxxwAJHYwaEDeGalIimIEXFKSuhSiAQngRIQzFYTLtJSpNFeHgMQjithculUoUAcVOAWEXtyOZjPKDewJ");
    string rROHewpr = string("OkdWlhaiuUANcXOQSAYCGWOlVcRM");

    for (int HIGEBTZIrE = 1903299610; HIGEBTZIrE > 0; HIGEBTZIrE--) {
        iMbOmqJEX += yrvValA;
    }

    if (PlTFX > string("OkdWlhaiuUANcXOQSAYCGWOlVcRM")) {
        for (int cdDlteOIlLBFH = 394033572; cdDlteOIlLBFH > 0; cdDlteOIlLBFH--) {
            yrvValA += dYxQtM;
            CyvlNGvIxjk -= hcdEXDoAw;
            iMbOmqJEX = PlTFX;
        }
    }

    for (int EnfOnlpnP = 1552012949; EnfOnlpnP > 0; EnfOnlpnP--) {
        PlTFX = PlTFX;
        rROHewpr += PlTFX;
    }

    if (cxbmu == -791876.5852691137) {
        for (int zjPoA = 99148705; zjPoA > 0; zjPoA--) {
            rROHewpr = dYxQtM;
        }
    }

    if (CyvlNGvIxjk <= -123719.87943769051) {
        for (int QoCCrfeYQk = 552628557; QoCCrfeYQk > 0; QoCCrfeYQk--) {
            KPEBHMVhv *= hcdEXDoAw;
        }
    }

    return JEZuHxzNItmQN;
}

void VsXhyikF::cMfztkgOIWPue()
{
    double tqRPclOyOyhsetg = 780403.6062360866;
    string AwXxJbE = string("HfUGyxntgNEZIRgoVfqZupzsHKkZjbljQNyJFiZhQlxgRdZZiFRsxuKlWqArsCTvqoOvIEgOocAfAgeuNGyXTnQlSQhKFtvCcUfdSVwPDQNPThWjDbebQM");
    bool LRkhoHK = false;
    bool gUwslU = true;
    string oZiDUPLCq = string("bBrTrQnBapOXfhcyhUsDLyhHtmtvauAKpIoDsFvhjbtiMnaHRxYHSuqRTBeUkrUFDetTFleGceLaWTaMdJTjAzItPViLukJ");
    double coIxNoZakm = 358155.3601483907;

    for (int HzHERscJquzNM = 1435958166; HzHERscJquzNM > 0; HzHERscJquzNM--) {
        coIxNoZakm += tqRPclOyOyhsetg;
        AwXxJbE = AwXxJbE;
    }
}

void VsXhyikF::oYlYrykQfqvv(bool uyVTCUWdDqOgYyl, string zgPIVYEiZ, int lcBPvEplvKSjEpin)
{
    string mtmoGH = string("MAWnkl");
    double pbhNoF = 740812.3522064205;
    bool FiQwf = true;

    for (int QkSIcd = 2137788056; QkSIcd > 0; QkSIcd--) {
        uyVTCUWdDqOgYyl = uyVTCUWdDqOgYyl;
    }

    for (int coQNVZKDodzCUPsI = 783469843; coQNVZKDodzCUPsI > 0; coQNVZKDodzCUPsI--) {
        continue;
    }
}

int VsXhyikF::sxMbX(bool eNPGFo, int CrIdPFuiy, int WZIJuTqLLcE, double JlOjuFcaJpaqg, double rvYmhNPXup)
{
    bool anrvtyQgN = true;
    bool lQaJP = false;
    int fqxdGyIwarpk = 995634943;
    string OJOVgD = string("LPlHUfhuqjEBCXtLmrrEsndLuTjHpACnnNbmmrvihVKWdPEWtmaueEFjunCSsssBcOUDLbJjSfpTNvTRXDcTueQelnbXUzcSEKTfpGDKXKDVEYOUGdJTtCBAmyADsbptnXMYHVLbOGKXCwUpGCWdooTuSvFOAOWvcKJTdwDyyBkoZqufTWraTUkphsjtlJIwcfCnyYSXAkPSEjP");

    for (int gTFvQifUCD = 483591741; gTFvQifUCD > 0; gTFvQifUCD--) {
        continue;
    }

    if (eNPGFo == false) {
        for (int ECPzKCHFHdrb = 837113154; ECPzKCHFHdrb > 0; ECPzKCHFHdrb--) {
            continue;
        }
    }

    return fqxdGyIwarpk;
}

double VsXhyikF::IfHgyEnDEYTbQLZ()
{
    bool cOgNt = true;
    double wZSaFaOHl = 538536.9511928451;
    int mopGrtS = -776842878;
    string HEnOsoJbjZK = string("GL");
    bool oOeCkRYqbR = false;

    if (cOgNt == true) {
        for (int jkMvY = 1747435067; jkMvY > 0; jkMvY--) {
            oOeCkRYqbR = ! oOeCkRYqbR;
            cOgNt = ! oOeCkRYqbR;
            cOgNt = cOgNt;
            oOeCkRYqbR = cOgNt;
            oOeCkRYqbR = oOeCkRYqbR;
            cOgNt = oOeCkRYqbR;
        }
    }

    for (int pqhpKVBMXky = 1831312824; pqhpKVBMXky > 0; pqhpKVBMXky--) {
        cOgNt = cOgNt;
        wZSaFaOHl += wZSaFaOHl;
        cOgNt = oOeCkRYqbR;
        cOgNt = ! oOeCkRYqbR;
    }

    for (int RBUWaCDKQQIrpRG = 1801414425; RBUWaCDKQQIrpRG > 0; RBUWaCDKQQIrpRG--) {
        mopGrtS -= mopGrtS;
        cOgNt = ! cOgNt;
    }

    for (int FoCZjG = 2088062865; FoCZjG > 0; FoCZjG--) {
        cOgNt = cOgNt;
    }

    return wZSaFaOHl;
}

bool VsXhyikF::HmfLCj(double mMdfT)
{
    string cqfYCH = string("KeIpUNhkmtGzswMXJFcdQwdCgshRtnqOAxnJrbvsoabSDdIpgfWbLZxzASIguhRE");
    double xbMqSjdDXznw = -916970.8469755464;
    double ZYPLAbMtLDhGzjol = 249064.07557529135;
    int KJHjhLfKJc = 387573141;

    if (KJHjhLfKJc >= 387573141) {
        for (int ipURkPzJWVAHiG = 1922929714; ipURkPzJWVAHiG > 0; ipURkPzJWVAHiG--) {
            mMdfT = xbMqSjdDXznw;
            xbMqSjdDXznw = xbMqSjdDXznw;
        }
    }

    for (int cSQqF = 1713165487; cSQqF > 0; cSQqF--) {
        ZYPLAbMtLDhGzjol = mMdfT;
    }

    for (int xlpcFjAwUO = 413177774; xlpcFjAwUO > 0; xlpcFjAwUO--) {
        ZYPLAbMtLDhGzjol += ZYPLAbMtLDhGzjol;
        mMdfT -= ZYPLAbMtLDhGzjol;
    }

    for (int YpUoZftnzHaOz = 170910778; YpUoZftnzHaOz > 0; YpUoZftnzHaOz--) {
        mMdfT = ZYPLAbMtLDhGzjol;
        cqfYCH += cqfYCH;
    }

    for (int doBvGJ = 1246220042; doBvGJ > 0; doBvGJ--) {
        xbMqSjdDXznw -= mMdfT;
        mMdfT += mMdfT;
        mMdfT = xbMqSjdDXznw;
    }

    return true;
}

void VsXhyikF::FxbaNjMkBcQ()
{
    bool hdyPr = true;
    string uZozucIsOEyLzCf = string("nKZXaKbjcWCyWmRZkBOvXvGDpwyUhIjVumcJdnKuSZBluWYshLBIsFuiwozjdFPzuVewamMskyMIdBHtwcOyFihrqxFOmbTpUgbclRqVhbfmedERpcwQYwcqcbNSOlaoeRLWTLKNrHrDPWvDGAINpEu");
    int wDpgxDRTe = 1397282578;

    if (uZozucIsOEyLzCf == string("nKZXaKbjcWCyWmRZkBOvXvGDpwyUhIjVumcJdnKuSZBluWYshLBIsFuiwozjdFPzuVewamMskyMIdBHtwcOyFihrqxFOmbTpUgbclRqVhbfmedERpcwQYwcqcbNSOlaoeRLWTLKNrHrDPWvDGAINpEu")) {
        for (int qqnajLENPGvzGYri = 2080215537; qqnajLENPGvzGYri > 0; qqnajLENPGvzGYri--) {
            wDpgxDRTe -= wDpgxDRTe;
            wDpgxDRTe -= wDpgxDRTe;
            uZozucIsOEyLzCf += uZozucIsOEyLzCf;
        }
    }

    for (int NixzeIMZIuae = 1510940119; NixzeIMZIuae > 0; NixzeIMZIuae--) {
        uZozucIsOEyLzCf = uZozucIsOEyLzCf;
        uZozucIsOEyLzCf += uZozucIsOEyLzCf;
    }

    for (int jtUdDWSptKmdnFx = 1809292418; jtUdDWSptKmdnFx > 0; jtUdDWSptKmdnFx--) {
        uZozucIsOEyLzCf += uZozucIsOEyLzCf;
    }

    for (int JWmuYPfm = 1777235682; JWmuYPfm > 0; JWmuYPfm--) {
        continue;
    }
}

double VsXhyikF::bfQcaIqEoqqsbQy(bool zcXna, bool DBtFXQesZtgJMHd, int cVBMmrBwY, double SpndLDJ)
{
    double vTJZCefPh = 805830.348340322;
    string VXrqppCWrSTBX = string("HNzjNHkNpELLlFFGOocQetPikCktQUPYuqWeyqTUulnIPZeLLPQtYWwixpgYwZomJvSZgohIJCZxQNQXTkHXwYChzRCmbBdTUSNIEisWCKPutKPQXZdncwuGfBgFLUVhPLEFhVmcIE");
    int tiklRpifwO = 602117143;
    int yWXMpseJzOMM = 1669506323;
    int YlshYjiFyobhTW = 401649741;

    if (SpndLDJ >= 837127.51895788) {
        for (int LrBOK = 1620932446; LrBOK > 0; LrBOK--) {
            yWXMpseJzOMM /= yWXMpseJzOMM;
            yWXMpseJzOMM *= yWXMpseJzOMM;
            YlshYjiFyobhTW += tiklRpifwO;
        }
    }

    for (int fzvCjXAoFvfP = 1757109265; fzvCjXAoFvfP > 0; fzvCjXAoFvfP--) {
        yWXMpseJzOMM -= YlshYjiFyobhTW;
    }

    for (int kAyxPQ = 2110054311; kAyxPQ > 0; kAyxPQ--) {
        continue;
    }

    for (int zReTeXKVYbdf = 1527077734; zReTeXKVYbdf > 0; zReTeXKVYbdf--) {
        SpndLDJ = vTJZCefPh;
    }

    return vTJZCefPh;
}

int VsXhyikF::ipKIuWZSxDINGAi(double ozwwXnB)
{
    string MGCsVMmoEzmif = string("pnWZiuJuUhGeBXXFYxWCwgVqyUIMTQhWUxIfi");
    int iAaqh = -1587625782;
    int DUMPXnaTTtTu = 172525251;
    double TUODWKpgGAUb = 184870.35089134573;
    double eKBBqWhiI = 884663.5687085107;
    string KPfqyba = string("lnfZApSYrHSouVmRSUKnyhJjSPWAkdBFrNpFDYWGvkxPm");
    int lZUvkvBawLkoJ = 1373846384;
    string pOrzyMSLXlf = string("ZLIcdTbtxiEJZnvgLrVNydTMyhVWejwCXLtOJmNADGQruuz");
    double wkmZKEInUQ = 881746.1562361495;

    for (int cXxFegswmsBs = 644445354; cXxFegswmsBs > 0; cXxFegswmsBs--) {
        TUODWKpgGAUb *= ozwwXnB;
        iAaqh /= iAaqh;
    }

    return lZUvkvBawLkoJ;
}

double VsXhyikF::IIVhzLNXxnDfihE(string TsYYcuKlEYVUW, bool DwIRH)
{
    int UcTvwxhtZaTiEIAC = 1221245436;
    double OfQcXMKLCSUbYS = 713971.433564452;

    if (TsYYcuKlEYVUW <= string("RzldPYrhyLIhkMEGEAxpSnQwjlqGguWYVUypMPAwFcQgZRWwXFHcXHzxjcQKVcpLrcQQUXMmXcZPWosAOcTDlBbDjqQFXgbjEhLTXOjDPYEcrOPLKveyOBtECANkRpyvNuZVzYaQDFOAltfSKjRChJyowLKRhSiMsRjnkyljrnaEIfWijvufbwzSppDzNPJVfRC")) {
        for (int YiXIvEeNOgh = 1824444263; YiXIvEeNOgh > 0; YiXIvEeNOgh--) {
            DwIRH = DwIRH;
            TsYYcuKlEYVUW = TsYYcuKlEYVUW;
        }
    }

    if (OfQcXMKLCSUbYS == 713971.433564452) {
        for (int OIJwAWxS = 1099910334; OIJwAWxS > 0; OIJwAWxS--) {
            TsYYcuKlEYVUW = TsYYcuKlEYVUW;
        }
    }

    if (DwIRH == false) {
        for (int kKUiGBBRwkrmW = 320592491; kKUiGBBRwkrmW > 0; kKUiGBBRwkrmW--) {
            continue;
        }
    }

    for (int zQfjYSd = 2026382977; zQfjYSd > 0; zQfjYSd--) {
        TsYYcuKlEYVUW = TsYYcuKlEYVUW;
    }

    for (int nYSFTkheb = 626360896; nYSFTkheb > 0; nYSFTkheb--) {
        TsYYcuKlEYVUW = TsYYcuKlEYVUW;
    }

    for (int EtLPKLiwtxCsVyy = 1103485412; EtLPKLiwtxCsVyy > 0; EtLPKLiwtxCsVyy--) {
        UcTvwxhtZaTiEIAC *= UcTvwxhtZaTiEIAC;
        UcTvwxhtZaTiEIAC /= UcTvwxhtZaTiEIAC;
        OfQcXMKLCSUbYS /= OfQcXMKLCSUbYS;
    }

    for (int FvaVCGgDjbwI = 451561562; FvaVCGgDjbwI > 0; FvaVCGgDjbwI--) {
        continue;
    }

    return OfQcXMKLCSUbYS;
}

string VsXhyikF::LOjOHuPHWepZ(double xmoFustmaaiQhKuQ, double zXLRFpf)
{
    int ymjjzRm = -1638252819;
    bool heyIQMbjs = false;
    bool RFcjxGClKIkQTpce = false;
    int QCwrZHzwaTuSe = 1009324160;
    double KRonMPBj = -993394.6343070304;
    double NSbuIZyJj = -519273.3592794215;
    int GuFiQOPjacXRqA = -695242334;

    if (KRonMPBj < 42324.82679950509) {
        for (int hOMswlXMVo = 103286596; hOMswlXMVo > 0; hOMswlXMVo--) {
            GuFiQOPjacXRqA -= QCwrZHzwaTuSe;
        }
    }

    if (GuFiQOPjacXRqA <= -695242334) {
        for (int ZpMJbYpwUi = 163762704; ZpMJbYpwUi > 0; ZpMJbYpwUi--) {
            GuFiQOPjacXRqA *= ymjjzRm;
            KRonMPBj += zXLRFpf;
            ymjjzRm /= QCwrZHzwaTuSe;
        }
    }

    if (xmoFustmaaiQhKuQ != -519273.3592794215) {
        for (int TtmRH = 1387819754; TtmRH > 0; TtmRH--) {
            QCwrZHzwaTuSe /= ymjjzRm;
            ymjjzRm /= ymjjzRm;
        }
    }

    return string("iyMMzPUJgDoOkiliopmMoknJUCLWTmaTqdQvBtPBVSvujPadMfLXtZNauotXUNBDrLscOZmBhEMTDWTqPZJcJGzPvfAWysnTvuYLCXPDJcHAGNTqzFRWwbpAKcByrDlwrCAVpnbHnr");
}

VsXhyikF::VsXhyikF()
{
    this->QfwtqXGNAAtBbB(true);
    this->IEmQNKR(false, -646227.0126109131, string("EKYjuWCdiZCXCeKFvHAKHvOlyaxEhyiETaKFavbFvvAjpZm"));
    this->RmdxPAGazot(string("ExmLyfacCgdbsVOhDcAPjOasISHEQjLmNgFCIndKPPimAwpXBSYJhqQaAlLcSzKycLLdUkZaDrAXfVYFmvLwFvPMLNynaKaDkINHKSmwlPBjnnQmDVudKVCVxBpsWdvyHnRHmuBgLICwygjRnpc"), string("VRCBPRAHKhylUVaGbaRpfKDVeeZYMBnyFxOThrjboLxOSfHlMjuAZmyPJdQcJIOXcTIDCyfiaHuoVuLbuCkTRlMRPJbJAuDICjlUdwzSJHKJhmAHVQopzoHKeTHvbrYmIQmUZHeTHszQTWeJxaLwwVZzgWoNJwpUAyxQUvVzI"), false, -791876.5852691137, string("ZcquMSaZrNhxDPkXJnQnJtCXwznDyAzPGjOCpMuyrHeireVhpUMhPZgCNHueizxTbMeDoEsCQWqreXFVGDJLdWrbbtBZuRjICAeFJJUJEOwnHHKnPinLNBQKyUyvUPvHeawYAbhyIPxlhkyEUAfMnXWUfzMuPiJIzulUCnXmcRwmstvikfgBrnWWIOjOAwvcCMtykO"));
    this->cMfztkgOIWPue();
    this->oYlYrykQfqvv(false, string("neLlnkvSrMtJEPIYSKbshbMbVRGuekPX"), 1581550880);
    this->sxMbX(true, 1008147347, -1030846739, -164465.8443850728, -665088.9332106974);
    this->IfHgyEnDEYTbQLZ();
    this->HmfLCj(484246.4632903033);
    this->FxbaNjMkBcQ();
    this->bfQcaIqEoqqsbQy(true, true, 1565848108, 837127.51895788);
    this->ipKIuWZSxDINGAi(-853881.8366812562);
    this->IIVhzLNXxnDfihE(string("RzldPYrhyLIhkMEGEAxpSnQwjlqGguWYVUypMPAwFcQgZRWwXFHcXHzxjcQKVcpLrcQQUXMmXcZPWosAOcTDlBbDjqQFXgbjEhLTXOjDPYEcrOPLKveyOBtECANkRpyvNuZVzYaQDFOAltfSKjRChJyowLKRhSiMsRjnkyljrnaEIfWijvufbwzSppDzNPJVfRC"), false);
    this->LOjOHuPHWepZ(42324.82679950509, 390692.60507037817);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VmhYIdrlqbnE
{
public:
    int VlzpgDcQhYPw;
    int oeWbvHkgvuSzynKE;
    int YPacwEBU;
    string XwRRqvaodXSkW;

    VmhYIdrlqbnE();
    int dguRdPZVxlpxcEeN(int CSsAvUlcFLXXqtCD, double ouFfATrZXhYvUG);
    bool CSFTOicOTgs();
    bool uKpBAoBJdHsYZcGP(string sUJLlWpsQ, string FgNVdkRmX);
    void jkixsDVr(double tqbXnGme, string SFBVwhmDhHSTf);
    bool HUuSUbZbhu();
protected:
    int YTDMdbOYvrzldXNA;
    bool JXJNLlzsyVEgiZYi;
    double OYpfHKGuN;
    string MBSjHKHaTUNlbXz;

    string BwFAodMn(double NtQyjYSjw);
    void QRUMRjQq(bool JskEkKGWde, int nVvrhnNjGQIK, double ZaCNE);
    double rnXvCLOQYLXW(bool gUbmsrIakn);
    double EgUqusvApTq(double lopxOIJWylphq, string ZKMjxkTLPbzVf);
    double fYRlwNqUxsRxJLk();
    string lNALGsQESJ();
private:
    bool pyQRmuoCtsKmhbX;
    string hJPsrKCW;
    int fStyDHONJkIS;
    double csEitkSkbiE;

    string PlMAAYYNAP(int IbShrdYqaZ, bool DaTfU, bool bktnVUibj, int NMzAh);
    int NmxJajgbB(string dnkLRQehb, bool bmRjN, int tmzvNT);
};

int VmhYIdrlqbnE::dguRdPZVxlpxcEeN(int CSsAvUlcFLXXqtCD, double ouFfATrZXhYvUG)
{
    bool OlWwJckkuFSHtU = true;
    int RsEWbOnjtJ = 592463931;

    for (int eYUidI = 1260444901; eYUidI > 0; eYUidI--) {
        CSsAvUlcFLXXqtCD = CSsAvUlcFLXXqtCD;
        OlWwJckkuFSHtU = OlWwJckkuFSHtU;
    }

    for (int hKGsVpSduUB = 293846601; hKGsVpSduUB > 0; hKGsVpSduUB--) {
        CSsAvUlcFLXXqtCD = RsEWbOnjtJ;
        OlWwJckkuFSHtU = OlWwJckkuFSHtU;
    }

    for (int MeAKNyFnhN = 1017055819; MeAKNyFnhN > 0; MeAKNyFnhN--) {
        ouFfATrZXhYvUG = ouFfATrZXhYvUG;
    }

    for (int FhNkCU = 45113649; FhNkCU > 0; FhNkCU--) {
        RsEWbOnjtJ /= CSsAvUlcFLXXqtCD;
        CSsAvUlcFLXXqtCD += RsEWbOnjtJ;
    }

    return RsEWbOnjtJ;
}

bool VmhYIdrlqbnE::CSFTOicOTgs()
{
    int tsEFhBOogMUPgGa = -2017255784;
    double MqNwhLOckP = 200870.40314778266;
    int fximIJE = 2019767640;
    string UZVhlKDKL = string("DLYXiLTAdvdwLNRnxQWNyXLVykjPbWjTSASToFTYUidKB");
    double pWRdOCGRzShxbF = 918805.4084809523;
    double vRyriKBTpOpAuS = -487186.3455241954;
    double rzFLytBnK = 458618.85998525855;
    int nDEVbYLZhcj = 1722084927;
    int RLmMBDYdllQYzHz = -1774711194;
    int OJOgWIqGIvhc = 2009592127;

    if (fximIJE >= 1722084927) {
        for (int OujUERs = 298945618; OujUERs > 0; OujUERs--) {
            rzFLytBnK -= pWRdOCGRzShxbF;
        }
    }

    if (nDEVbYLZhcj == 1722084927) {
        for (int OxrRPdeQuNXOlFZ = 644974465; OxrRPdeQuNXOlFZ > 0; OxrRPdeQuNXOlFZ--) {
            pWRdOCGRzShxbF *= vRyriKBTpOpAuS;
            vRyriKBTpOpAuS *= vRyriKBTpOpAuS;
        }
    }

    return true;
}

bool VmhYIdrlqbnE::uKpBAoBJdHsYZcGP(string sUJLlWpsQ, string FgNVdkRmX)
{
    int wViFUUuvktc = 2144791800;
    double ADzVHMJXthIk = -315417.2162702243;
    string anEggxi = string("KkmrgdoEImrlTHQddMcAaQqLQuMmxbnvcPCzyXgJcjrzkuMkMHlhDtsiJlOtSEcwWemWmdOmAmZHhPsVBLeVaNKreFeBsmdPpzhNLYhShYzkTsDZcvXGKMaPEIPnHpvCEMDjcFfzyxsdPdpTAGD");
    double bSjNYHFLAFo = 198853.3988535406;
    bool WkLesO = false;
    double BIezGv = 1015171.1603003464;
    bool fQymgKizbUb = true;
    double nOxueyOJ = -555505.6865041158;

    for (int EsmiHeGVYGelu = 499049058; EsmiHeGVYGelu > 0; EsmiHeGVYGelu--) {
        FgNVdkRmX += sUJLlWpsQ;
        anEggxi += anEggxi;
    }

    for (int ahDafIGTfNjBbzY = 708949734; ahDafIGTfNjBbzY > 0; ahDafIGTfNjBbzY--) {
        continue;
    }

    return fQymgKizbUb;
}

void VmhYIdrlqbnE::jkixsDVr(double tqbXnGme, string SFBVwhmDhHSTf)
{
    int MAEnpW = -1316964163;
    bool izIMsiZglqaPw = true;
    double HaDDILBEa = 922434.6872572991;
    double OipctAebMjBYm = -672575.9858840613;
    string SmNOGQytSJnjdj = string("dBdBNYnfLwhnCclFfUIqzFdLWJEAXgKyLujOqrmWzskFFEnjMZxeItqgNzimEBhHPmWFgAZxKeXCmDELRRwvajmQdqWMkFxmWhdTtHGPBmyvGqFNnLDnZmFyKReBVJiQqfYWSXCYNpSMWkkXhdwPfRZVZtzKZtBtXCNhhwbCLMJAEFDLN");
    double GUzOFNaIExqT = 1026380.11702601;
    bool GXVTX = false;
    int zxQWAsXGBIt = 198288372;

    if (tqbXnGme < 1026380.11702601) {
        for (int KKshbvg = 241271251; KKshbvg > 0; KKshbvg--) {
            MAEnpW *= MAEnpW;
        }
    }
}

bool VmhYIdrlqbnE::HUuSUbZbhu()
{
    string DIAJdU = string("ASwqFstAhIiozEavPnbxsBGHEdlgofBVXhaDmBotQSxAedrLrYoNZFyHFkjlWTgAicKDv");
    int iptQor = -2108196142;
    int sSCak = -1481266561;
    double GitSpBO = 175303.9895822229;
    int vLPZnB = 264217392;
    int qwgheRIVcxdMk = -390975321;
    string ercfrDn = string("zpdfYqkSfuCVkmCLlmIBuhafYDGCirHcSWyJmbHuFgQUPvyXYhFXyKGVcIixCTvTqOUtbBncJEMpEHzPaZRjAUFJQYTtIQmDsBxdoPjpghexlCcyDMPufVvaDxEJkikXPVmsVmYllBFgXAMOFUJaNkjMWaMTmpSGyWYYDISrcAWgYYBtTkikaOptaCASrFlhPZBrkanZNqSIrNzgnqmRCJygnEJwoKtJkpBkcixrNBIZGegrYW");
    int hsNXqUfLLbQCm = -2107883059;

    for (int wWTfdT = 1811565709; wWTfdT > 0; wWTfdT--) {
        GitSpBO = GitSpBO;
    }

    for (int yhCJeAXzvq = 27810954; yhCJeAXzvq > 0; yhCJeAXzvq--) {
        DIAJdU += DIAJdU;
    }

    if (DIAJdU > string("zpdfYqkSfuCVkmCLlmIBuhafYDGCirHcSWyJmbHuFgQUPvyXYhFXyKGVcIixCTvTqOUtbBncJEMpEHzPaZRjAUFJQYTtIQmDsBxdoPjpghexlCcyDMPufVvaDxEJkikXPVmsVmYllBFgXAMOFUJaNkjMWaMTmpSGyWYYDISrcAWgYYBtTkikaOptaCASrFlhPZBrkanZNqSIrNzgnqmRCJygnEJwoKtJkpBkcixrNBIZGegrYW")) {
        for (int BxbsZipQ = 1698941777; BxbsZipQ > 0; BxbsZipQ--) {
            ercfrDn = ercfrDn;
            qwgheRIVcxdMk /= qwgheRIVcxdMk;
        }
    }

    if (qwgheRIVcxdMk >= 264217392) {
        for (int aYjdoc = 757491638; aYjdoc > 0; aYjdoc--) {
            hsNXqUfLLbQCm += iptQor;
            vLPZnB += vLPZnB;
            vLPZnB *= hsNXqUfLLbQCm;
            qwgheRIVcxdMk -= vLPZnB;
            qwgheRIVcxdMk = vLPZnB;
        }
    }

    if (DIAJdU >= string("ASwqFstAhIiozEavPnbxsBGHEdlgofBVXhaDmBotQSxAedrLrYoNZFyHFkjlWTgAicKDv")) {
        for (int auOwAG = 649611174; auOwAG > 0; auOwAG--) {
            iptQor += vLPZnB;
            ercfrDn += ercfrDn;
            DIAJdU = ercfrDn;
            hsNXqUfLLbQCm += iptQor;
        }
    }

    if (qwgheRIVcxdMk <= -1481266561) {
        for (int NiDQnufhDto = 914033472; NiDQnufhDto > 0; NiDQnufhDto--) {
            continue;
        }
    }

    return false;
}

string VmhYIdrlqbnE::BwFAodMn(double NtQyjYSjw)
{
    string TJRxouQKwxyh = string("CbOWvsRbcfCoAEX");
    bool rDmTZ = true;
    double alIjXKqxabvpLGeC = 723011.2398024903;
    string dmKuviFMdtHbFf = string("jbQoEkJjbxqqnhvvDlsKhSuOkGlwjdjKHmpwLSXbLjQDXnZiDtELhkUluLHZqrwHRSGwbdgMQGryYYZqgYiIdFPmLAdqAlHLIoCDNEcoBdSBRVyYMoWvQDvpQKbWHmeXHBATVVmjsxVtsDHNamJFfXCmmdfikHCeOEOsIcJayRmlyARrKiSIocsdVOIUFfXqgHvwNTfVTspIZHnKPJCSOKtzmLLAWnUdnwrUWVZyyzRebuTAAtgNMmfvZazQKSJ");

    for (int WBnBRZFTkgS = 2112358742; WBnBRZFTkgS > 0; WBnBRZFTkgS--) {
        rDmTZ = rDmTZ;
        rDmTZ = ! rDmTZ;
        alIjXKqxabvpLGeC *= NtQyjYSjw;
        NtQyjYSjw += alIjXKqxabvpLGeC;
    }

    return dmKuviFMdtHbFf;
}

void VmhYIdrlqbnE::QRUMRjQq(bool JskEkKGWde, int nVvrhnNjGQIK, double ZaCNE)
{
    int IjsjjuDRrqQMIGn = -745847284;

    for (int rNdszJRPqaBRyT = 747054230; rNdszJRPqaBRyT > 0; rNdszJRPqaBRyT--) {
        JskEkKGWde = ! JskEkKGWde;
        nVvrhnNjGQIK -= IjsjjuDRrqQMIGn;
        IjsjjuDRrqQMIGn /= nVvrhnNjGQIK;
        ZaCNE = ZaCNE;
    }

    for (int dqkjCJdJslicrUx = 717014276; dqkjCJdJslicrUx > 0; dqkjCJdJslicrUx--) {
        nVvrhnNjGQIK -= nVvrhnNjGQIK;
        JskEkKGWde = ! JskEkKGWde;
    }

    for (int VCeVBYnPEvexpxTx = 2109038709; VCeVBYnPEvexpxTx > 0; VCeVBYnPEvexpxTx--) {
        nVvrhnNjGQIK += IjsjjuDRrqQMIGn;
        ZaCNE = ZaCNE;
    }
}

double VmhYIdrlqbnE::rnXvCLOQYLXW(bool gUbmsrIakn)
{
    int ybHxmhXHf = 2101391658;
    int GbQRZFZS = -379191011;
    int XKBciF = 1665254870;
    bool fEAssG = true;
    double qxGjZQPdunsRMW = 713094.794154353;
    int zQbZFgaaLJzOv = -116416820;
    bool JZoQZwtPkmy = false;

    return qxGjZQPdunsRMW;
}

double VmhYIdrlqbnE::EgUqusvApTq(double lopxOIJWylphq, string ZKMjxkTLPbzVf)
{
    double HAivHClQ = 16362.56651204002;

    for (int CBsMpOrraK = 1581757083; CBsMpOrraK > 0; CBsMpOrraK--) {
        lopxOIJWylphq += HAivHClQ;
        ZKMjxkTLPbzVf += ZKMjxkTLPbzVf;
    }

    for (int ZRWTsdBYq = 1223829847; ZRWTsdBYq > 0; ZRWTsdBYq--) {
        lopxOIJWylphq -= lopxOIJWylphq;
        lopxOIJWylphq /= HAivHClQ;
        HAivHClQ /= lopxOIJWylphq;
        lopxOIJWylphq *= HAivHClQ;
    }

    if (lopxOIJWylphq > 151466.87632963114) {
        for (int xxYwOeKPR = 617766841; xxYwOeKPR > 0; xxYwOeKPR--) {
            continue;
        }
    }

    return HAivHClQ;
}

double VmhYIdrlqbnE::fYRlwNqUxsRxJLk()
{
    double mOAzixvvdyDkZ = 744252.5056203515;
    bool wDVxRJFPYBHJlPR = true;
    bool JvqXX = true;
    double wAVMcsUvoqpfT = -856468.8549053539;

    if (JvqXX != true) {
        for (int uPbJJrFmTKZRrFOi = 1511746314; uPbJJrFmTKZRrFOi > 0; uPbJJrFmTKZRrFOi--) {
            mOAzixvvdyDkZ /= wAVMcsUvoqpfT;
            wDVxRJFPYBHJlPR = JvqXX;
            wDVxRJFPYBHJlPR = wDVxRJFPYBHJlPR;
            JvqXX = JvqXX;
            wDVxRJFPYBHJlPR = wDVxRJFPYBHJlPR;
        }
    }

    if (JvqXX == true) {
        for (int oJHCYjui = 335354644; oJHCYjui > 0; oJHCYjui--) {
            JvqXX = ! JvqXX;
            wDVxRJFPYBHJlPR = JvqXX;
            JvqXX = ! wDVxRJFPYBHJlPR;
            wDVxRJFPYBHJlPR = ! wDVxRJFPYBHJlPR;
        }
    }

    return wAVMcsUvoqpfT;
}

string VmhYIdrlqbnE::lNALGsQESJ()
{
    double ISvOOfez = 72071.46287492696;
    int rdBprjA = 1543609518;
    bool kYjOhmxK = false;
    double AsMQsRIKvf = 658910.0531447532;
    double jhgbSTkUVfkwj = 308552.6598424337;
    string rfbXyQWNYxoCA = string("XWEGimQvDTITiLFKFLhjQNDhEYpkCfUOmBDGMaVaSYAAkpmNrRFqJdyzWxlgmTyQFDQcKIiiiBWejGqtaEytxlQhQsYbciEUSCXvtPnrLnpiFJpXcLFumKQxNNpWlqDgQVoFNHoBMwtAOPgDpnjFjfHjhxiwFUncJwGiHpOYfosKCikyDSgocyfKLpNpLqRZtMQfdzMTrJcxyGohTQObPlRRVzyLtuNgKjyMLdZpBDOpoTiXwtleo");
    int RiGAouB = -978760735;
    string cFedJGeGNQoU = string("EBHCrtHGnfadEWrGbSPrVyGSrZDPYJAKuoCsJJVVJbvNQguAPLPvHmhFOOxVIjMLlLORhUbLOjTZKkTQGiQAcFhhXixLyBlaMcuEfHudfTnrEkUTjZHeVtZcHCRczjuorqRAXEqkreXVntzaQOLjzujRhRuhGmHfyDJVbTdWtJTZXxSvpEtrngSKuKzbYjFOFGgJIlba");
    double DuFLKzd = 278568.9379730121;
    int rHscoCqsVJZ = 995429951;

    for (int zokzxiWPPaZTvd = 318718467; zokzxiWPPaZTvd > 0; zokzxiWPPaZTvd--) {
        AsMQsRIKvf = AsMQsRIKvf;
        rdBprjA = rdBprjA;
        ISvOOfez *= ISvOOfez;
        jhgbSTkUVfkwj = ISvOOfez;
    }

    for (int UsrjErGjmU = 442796196; UsrjErGjmU > 0; UsrjErGjmU--) {
        DuFLKzd *= DuFLKzd;
        RiGAouB = RiGAouB;
    }

    for (int EXBJvCiuCHsy = 443524153; EXBJvCiuCHsy > 0; EXBJvCiuCHsy--) {
        AsMQsRIKvf *= jhgbSTkUVfkwj;
    }

    for (int WcEjMdkjZzDo = 1056820826; WcEjMdkjZzDo > 0; WcEjMdkjZzDo--) {
        RiGAouB += RiGAouB;
        jhgbSTkUVfkwj /= AsMQsRIKvf;
    }

    return cFedJGeGNQoU;
}

string VmhYIdrlqbnE::PlMAAYYNAP(int IbShrdYqaZ, bool DaTfU, bool bktnVUibj, int NMzAh)
{
    double RuGtnZ = 284280.45831711555;
    string ZSScyrESnjiTn = string("RVmFkbWJVtcbAWqBhGSjWBETzmmexpmuhlkrppACjfNdGJWchvEYkZYoAjwpWUbqLcOwDksHafeVroHQygDgdZEJaQKLEcqgFrtCzntaFIAchgfWwiRPeTokvgHpAiOShFJCRISFgqDyySXszYNPQbFKSJjnCNdtMEkYUDjRzCmFrVstmHfVNKVP");
    string pwvDmDwJk = string("YLJcmcskLdwiiSZLVJIOblFohsyiXsHYvhoXYbrfIvpJmjJyLYMvFBQENjuKqMuJneezEvdLohihSJcIiNhuIoLRmhVWhrNiPZdZAGzuyMb");
    int lYFBIyQFLfrW = -1187124301;
    bool xAcAn = true;
    bool tYFsX = false;

    if (pwvDmDwJk <= string("YLJcmcskLdwiiSZLVJIOblFohsyiXsHYvhoXYbrfIvpJmjJyLYMvFBQENjuKqMuJneezEvdLohihSJcIiNhuIoLRmhVWhrNiPZdZAGzuyMb")) {
        for (int uelLouy = 598545344; uelLouy > 0; uelLouy--) {
            bktnVUibj = ! xAcAn;
            NMzAh /= NMzAh;
            ZSScyrESnjiTn += pwvDmDwJk;
        }
    }

    for (int qHBgJ = 2031186399; qHBgJ > 0; qHBgJ--) {
        tYFsX = xAcAn;
        DaTfU = bktnVUibj;
    }

    if (NMzAh >= 1890208768) {
        for (int RSMhDlkykdjPscvC = 491951805; RSMhDlkykdjPscvC > 0; RSMhDlkykdjPscvC--) {
            DaTfU = tYFsX;
            xAcAn = bktnVUibj;
        }
    }

    for (int ugsRz = 181691924; ugsRz > 0; ugsRz--) {
        bktnVUibj = ! bktnVUibj;
        xAcAn = ! xAcAn;
        bktnVUibj = xAcAn;
        bktnVUibj = ! xAcAn;
    }

    for (int yETcgLcrNlWRXkci = 184797061; yETcgLcrNlWRXkci > 0; yETcgLcrNlWRXkci--) {
        continue;
    }

    if (IbShrdYqaZ != 1890208768) {
        for (int XiJBUsnJmOeTek = 175810991; XiJBUsnJmOeTek > 0; XiJBUsnJmOeTek--) {
            lYFBIyQFLfrW -= NMzAh;
        }
    }

    for (int qVjnek = 448663692; qVjnek > 0; qVjnek--) {
        DaTfU = DaTfU;
        pwvDmDwJk = ZSScyrESnjiTn;
    }

    return pwvDmDwJk;
}

int VmhYIdrlqbnE::NmxJajgbB(string dnkLRQehb, bool bmRjN, int tmzvNT)
{
    bool OmbxCHaHWjCWVod = true;
    int sUcQbnTezgTHI = -122509664;

    for (int DmHNlUeqHfnlaL = 1066847617; DmHNlUeqHfnlaL > 0; DmHNlUeqHfnlaL--) {
        sUcQbnTezgTHI -= sUcQbnTezgTHI;
    }

    if (sUcQbnTezgTHI > -122509664) {
        for (int fxAcrD = 189045808; fxAcrD > 0; fxAcrD--) {
            OmbxCHaHWjCWVod = bmRjN;
        }
    }

    for (int taNNPNR = 32470053; taNNPNR > 0; taNNPNR--) {
        sUcQbnTezgTHI *= tmzvNT;
    }

    for (int ESzdSVJIXIBBPMPj = 1585231235; ESzdSVJIXIBBPMPj > 0; ESzdSVJIXIBBPMPj--) {
        sUcQbnTezgTHI = sUcQbnTezgTHI;
        OmbxCHaHWjCWVod = ! OmbxCHaHWjCWVod;
        sUcQbnTezgTHI += sUcQbnTezgTHI;
        dnkLRQehb += dnkLRQehb;
        sUcQbnTezgTHI *= sUcQbnTezgTHI;
        tmzvNT += tmzvNT;
        tmzvNT += sUcQbnTezgTHI;
    }

    if (sUcQbnTezgTHI == -973609291) {
        for (int eeRxOyQ = 320476012; eeRxOyQ > 0; eeRxOyQ--) {
            continue;
        }
    }

    return sUcQbnTezgTHI;
}

VmhYIdrlqbnE::VmhYIdrlqbnE()
{
    this->dguRdPZVxlpxcEeN(-87519486, -173189.3088864182);
    this->CSFTOicOTgs();
    this->uKpBAoBJdHsYZcGP(string("iAPkNtkGIdcaYxzAOBcvUtBqRTbqKAmthAuRNS"), string("mEDOQieGJWxuGDaCbMXPRFgvmwmbAwpaPnWNPmXEMOxeeVQyxCTeIgaYUuYBuGeNfFjesnqnrnzUTKbmYtoUcXNRCbPVvXNfoXarU"));
    this->jkixsDVr(90074.18682634947, string("VwjcSXTKbCLckrPBKnPoPSNLNytmIcOqNdtyyQIWjLUcPaEBiWjtZCEPzyABjXHwsuitYreakmrIDMaA"));
    this->HUuSUbZbhu();
    this->BwFAodMn(219526.8152219107);
    this->QRUMRjQq(false, -1945861379, 378138.94618133554);
    this->rnXvCLOQYLXW(false);
    this->EgUqusvApTq(151466.87632963114, string("xnzRGDYeeByQYoUsFkwhebLgxPDUbnuNtNiaDgJwIzKYKwwXJIVvtzQIKZQTBsSAXnSrkCLVxpeKLAeScZDaZwRktPcOmoJcvFCglnVaHqxEUwwSxfMNgZhNGYJfKmvAoXTeffFNoVAjZvHzJviFxfEjzhiKicivRmBaABRzQBdQBgOAZBRDFREAwosruFAM"));
    this->fYRlwNqUxsRxJLk();
    this->lNALGsQESJ();
    this->PlMAAYYNAP(2001533816, false, false, 1890208768);
    this->NmxJajgbB(string("vfcSXVYGDBrURgJyaeeJxcNaAXdCSTXJtdvDDeRcHEallsiUJfFPpnreOjxApCyhDB"), false, -973609291);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class geIKz
{
public:
    double mxEbcPFCsu;
    double QlxoRjvxNLeUVG;
    double rLUJIOoTZo;
    double IlmrMqqPPGhspe;
    double Hqddpuo;

    geIKz();
    void XnJHEzdJSRda(double LNQQBSw, string TgVFUMdgaBb, bool HVAajLugROl, int vrHGyJC, double PqiaKJeGKvaVSnRT);
    int YyceWETFn(bool bqxjZgjxCjEevnst, int vEKLJCQka);
    void TaTzxEmPxAsv(string FAKAORlTKEB, int slnMZPC, int AIMhxsq, bool adpMNjxvEqM, int dPOIDljbhbUDkF);
    int lMMgfzLzpTukpxoA(string giPOlR, double tPelkNxXWosfgg, string flQbPB, bool TPiPZLvsh);
protected:
    int LCDLfJ;
    double rnXVkImtAIFzvHI;
    string UVrLtiVFs;

    bool sWmgXfEF(double AhtzFfdmeSWp, string KYuao, int PGjhyhQahiDMDBG);
    void RaIGc(bool DMOGLeVUjexm);
    bool UbuCBWOtMP(bool iVFIFTjZtLZE, int IEVRdPzk, double bJTwJFc, string TjmkEzistzWRCH, double hGZAaqhmfma);
    double AZAAIuDXf(bool kjyFKB, double liYyiMZdhFDU, int VGsrbdbk, string eEqzluCEhriSF);
    bool sBqVEWt(bool IFtGCKd, double SwUjPByYDFBqjovH, bool JcWvmXznlQohti);
    string ehvobIpkVgXKu();
private:
    double dicTNdj;
    string zmfcF;

    string AxuQEbLHznfnYK(string hBNqJCdoA, double rCmVQMmZfdrMfvH);
    int UnMsBlIKJlrAXUj(bool xyWxFcA, double pWbTuPt, double jPHOPsuIZqsXmG);
};

void geIKz::XnJHEzdJSRda(double LNQQBSw, string TgVFUMdgaBb, bool HVAajLugROl, int vrHGyJC, double PqiaKJeGKvaVSnRT)
{
    bool lQCxm = true;
    string jJVEg = string("bmFBHhysSgAgNdaPjkRkpSkqkAqvjRuJyLZhaiUiZJgdoTgWrOYJZeBFDVrdzAaSSaGhCFpjMejhiCsgmnLPwzOEPpqSRnxlqBtxTrbduAcLpzNlQRNDitdNLID");
    bool GSojaEvOKmo = false;
    double rcWPYqsylX = 112762.87181760227;
    bool sdyVpXoYGYLsQhC = true;
    string DKcEHk = string("iATZAIqtrIRYhyHdRDnPcSmNPoQPNUwZzqpadtMcUuFdCcsNEzkbnjYksTqYklxKpdTsaFXQdZVivgkpIkIERmkeYJFTsrYypDLvchYUYMWffshHSHSSpKFZYELcAXembcFPZifXOhmVtubrkUwvLypOsexrTBGsHleFzEhkehQDVKodtgTLWSDcvxyejmNiPizWNNaXxNDdFtzWacNtBjdAtCbMZdaGmxUhvqNpVlCKewuRYJPEIZWwTEBn");
    string ItHcSQXncyaywhs = string("aChvrBlvrTOEjmadrAbtLshoxipTFXZHdCKmkzMNZtdjtotjFSuKWefMRnQstZuWRxmuUfbXDbDHKmfjBiDSuiqJJatNOxPlxZrxcGGxOFNIgLCEcCGwCEIGlSkQgEIMVXJNPbGmvwwYtaYfESnLDneSjXObAmMkXRgwWbfDIEDNNbTyKgmAROsbVvcjbEDru");
    string AHkABKcNY = string("jXHUikTytrmnIYOkJJjaIxwmztSfcuBVsPLejoUKZutcKPMiVbOBRsflksYRvdwsnbDwkESJZnMRXSdsYocxKEXKSZuLgZoPeMzpbdxJhxChobkZVIvyVJpTgKdlvNtLpQhLJoRfUBWoBXQSXBMHoVivjDenPtYwpw");
    double LAjRzmnsy = 1029748.1218333072;
    bool sAwCvgs = false;
}

int geIKz::YyceWETFn(bool bqxjZgjxCjEevnst, int vEKLJCQka)
{
    string arnWLvj = string("jiUnriGKViIdVSTAitaDVktPvweNCVOYiIDauHkjNhCyqdgIeUPgyToMhSElwSnXSXIRpYIcmzuuZsvksphpHcLsewAFCGmcwMhylbAnrTcQdXULlRDRExWAMoCyxrccZkUxtkMlmOEgOAfmQDdACRNvPYWyvBzGZABrYYSemEhADamIfwLLEcQFJptFXyiZzzSFiIuBehPy");
    double YUQappUzAgYfI = -192668.05120740845;
    double VcZgChuOoQ = 915540.9777867084;
    double vXKLFGd = -1012471.2649407737;
    double MitmPCOxkvIVQY = 620910.2350710019;
    bool CxEwsvcuVxeaP = false;
    string EAnWeBrPavFm = string("AhUzvomScCTbTMAysantHhQkLWjDeyEBlfsWINclhGuHelvgssFCdaFFNwRGfKeLIFIrBsvELfzmecntokYqUToosCQCOPlsfpOXuqZdVRICLTjOpPraqCrecUsuErbeKzQOxBPjHdRLYHoXwpxeFWsZlGIWaUtpslirXfCFSjhpovpYJXBHhvWmveZYHeSRxJOHENwgDxpfrrpSDZfbJkoukkqhXBblbRPzTtOAwQnqqwpHddr");
    bool sRcBOuOfbWpuxnU = false;

    for (int EnOhjv = 1707703812; EnOhjv > 0; EnOhjv--) {
        bqxjZgjxCjEevnst = sRcBOuOfbWpuxnU;
        arnWLvj += EAnWeBrPavFm;
    }

    for (int IERenMDM = 1878956808; IERenMDM > 0; IERenMDM--) {
        YUQappUzAgYfI /= YUQappUzAgYfI;
    }

    if (YUQappUzAgYfI > 915540.9777867084) {
        for (int sGqyMDzDRiyYYgc = 788984031; sGqyMDzDRiyYYgc > 0; sGqyMDzDRiyYYgc--) {
            MitmPCOxkvIVQY = VcZgChuOoQ;
        }
    }

    if (VcZgChuOoQ != -192668.05120740845) {
        for (int FmoNdZOL = 948131417; FmoNdZOL > 0; FmoNdZOL--) {
            VcZgChuOoQ /= MitmPCOxkvIVQY;
        }
    }

    if (vXKLFGd > -1012471.2649407737) {
        for (int eTntZGZrl = 1707772984; eTntZGZrl > 0; eTntZGZrl--) {
            CxEwsvcuVxeaP = ! bqxjZgjxCjEevnst;
            EAnWeBrPavFm += arnWLvj;
        }
    }

    return vEKLJCQka;
}

void geIKz::TaTzxEmPxAsv(string FAKAORlTKEB, int slnMZPC, int AIMhxsq, bool adpMNjxvEqM, int dPOIDljbhbUDkF)
{
    double nyzgBlOTvEJxy = 94100.11157995407;
    bool vKouc = false;

    for (int NBxYhzCgiVme = 898514953; NBxYhzCgiVme > 0; NBxYhzCgiVme--) {
        slnMZPC = AIMhxsq;
    }
}

int geIKz::lMMgfzLzpTukpxoA(string giPOlR, double tPelkNxXWosfgg, string flQbPB, bool TPiPZLvsh)
{
    int cLnnbjysI = -463955691;
    double xghoM = -328435.7415451327;
    string KfUvfZpgyrRF = string("IAqANonGVlLNSoCRe");
    bool efGvgQtsFSVAZmif = true;
    int qDibswGE = 821039291;
    bool zReSAkzkhIMwSZt = false;

    if (giPOlR >= string("IAqANonGVlLNSoCRe")) {
        for (int hKuZD = 141329824; hKuZD > 0; hKuZD--) {
            continue;
        }
    }

    return qDibswGE;
}

bool geIKz::sWmgXfEF(double AhtzFfdmeSWp, string KYuao, int PGjhyhQahiDMDBG)
{
    int uKYKxNK = 1824070298;
    bool PIGFjtIGHSFrv = true;
    bool wkhITj = true;
    double FOFrHXfEiPBhPV = -558735.6021261724;

    for (int IsqQRTQhlQ = 594266346; IsqQRTQhlQ > 0; IsqQRTQhlQ--) {
        uKYKxNK -= uKYKxNK;
        PIGFjtIGHSFrv = PIGFjtIGHSFrv;
        wkhITj = wkhITj;
    }

    return wkhITj;
}

void geIKz::RaIGc(bool DMOGLeVUjexm)
{
    double rBRDw = -326615.0236501306;
    double vVBXwhGVVDnSb = 932530.9408234821;
    double RfknbwHYI = 270257.1585735169;
    double laspKXIDfwidghSA = -271986.22941908415;
    int RBPzknE = -2130396839;
    string ZsbMwYiEPMre = string("LGBXpFPqmSeNXzbdXPZJMGLYGGzEDtaHHJnaKFzpJhqSXrNCexGRmAnwBDEjeiBiFAlyveXwTrhorguLMPnWwnTmpusdyzfTliHvxGiDka");
    bool lXknbHYHdRL = true;

    for (int uDMxLueQLGNyS = 980178263; uDMxLueQLGNyS > 0; uDMxLueQLGNyS--) {
        rBRDw = RfknbwHYI;
    }

    for (int QoPWn = 1156332658; QoPWn > 0; QoPWn--) {
        continue;
    }

    if (rBRDw != 932530.9408234821) {
        for (int UUMzzoaL = 1377318062; UUMzzoaL > 0; UUMzzoaL--) {
            continue;
        }
    }
}

bool geIKz::UbuCBWOtMP(bool iVFIFTjZtLZE, int IEVRdPzk, double bJTwJFc, string TjmkEzistzWRCH, double hGZAaqhmfma)
{
    int eyIJnQfrG = 920183041;
    double EHANMNltomFPZep = -345789.65673611045;

    for (int DIkeOZtHLPkhS = 1110253286; DIkeOZtHLPkhS > 0; DIkeOZtHLPkhS--) {
        IEVRdPzk /= eyIJnQfrG;
        bJTwJFc = hGZAaqhmfma;
        bJTwJFc = hGZAaqhmfma;
    }

    return iVFIFTjZtLZE;
}

double geIKz::AZAAIuDXf(bool kjyFKB, double liYyiMZdhFDU, int VGsrbdbk, string eEqzluCEhriSF)
{
    int hJoQQb = 1216925672;

    if (VGsrbdbk <= 1957635502) {
        for (int GjjDh = 460789995; GjjDh > 0; GjjDh--) {
            liYyiMZdhFDU += liYyiMZdhFDU;
        }
    }

    for (int ToCAolgtsE = 1173100561; ToCAolgtsE > 0; ToCAolgtsE--) {
        VGsrbdbk *= VGsrbdbk;
        hJoQQb *= hJoQQb;
    }

    for (int OPNfMjTriN = 493388518; OPNfMjTriN > 0; OPNfMjTriN--) {
        hJoQQb -= hJoQQb;
    }

    for (int iYLExXlXYIvKd = 1410577615; iYLExXlXYIvKd > 0; iYLExXlXYIvKd--) {
        VGsrbdbk += VGsrbdbk;
    }

    return liYyiMZdhFDU;
}

bool geIKz::sBqVEWt(bool IFtGCKd, double SwUjPByYDFBqjovH, bool JcWvmXznlQohti)
{
    bool TfxjNFyqtzxpESmg = true;
    bool VoVKAtDvUItxH = false;
    string rGOsQDQJAA = string("aOoxyULJJmQrGGEzFvuweHbBHqQVLNdUrjDxiNnKasiiavFyzeFWYFvSLLtvidaDcMJDFRsdepwDfYnGKLxpQswAIgSYQmZGxtwhpxzyhRkulgMSzjPzpSZXcqrUeNfdNzEhsKeAhRZTsUDOGDkHzeqXYHdNikFdmIxOQcGcCxXAQWMDDcAinVHyuiFfWbDabZKFJjcBVHKtqHqzUQivWWyflBiHFVwWltiSxurbrBBZv");

    if (TfxjNFyqtzxpESmg == false) {
        for (int OhRaNfKDYlhFHU = 460119332; OhRaNfKDYlhFHU > 0; OhRaNfKDYlhFHU--) {
            rGOsQDQJAA += rGOsQDQJAA;
            VoVKAtDvUItxH = ! IFtGCKd;
            JcWvmXznlQohti = ! JcWvmXznlQohti;
            SwUjPByYDFBqjovH /= SwUjPByYDFBqjovH;
            SwUjPByYDFBqjovH = SwUjPByYDFBqjovH;
        }
    }

    if (JcWvmXznlQohti != false) {
        for (int CTHOdKpaevInl = 414797323; CTHOdKpaevInl > 0; CTHOdKpaevInl--) {
            IFtGCKd = ! VoVKAtDvUItxH;
            IFtGCKd = ! IFtGCKd;
            IFtGCKd = ! VoVKAtDvUItxH;
        }
    }

    return VoVKAtDvUItxH;
}

string geIKz::ehvobIpkVgXKu()
{
    string tppqVhUo = string("KOczvFRKQXiGDQTYvqyLsDQeASrwZZiLhOddsxQXhATVoyUPSENaLIyietRjogXYEoofhknuyycQnbQBdzdljqqTukPxCKBpQolQmPyIDpXdfvuapPAfEfNzPdZIrpNgbXMaBWkRssyewfyDrhqzUOnOoIOwNGBptjHuBDqaTiUNptIekdEBqTfWBKFglcKzgpxdYoKGLgGjuuOwSApvlxUAYFIxpXlEqyRmYvCQdysCnS");
    double LnofCOWZu = -422595.13125465804;
    string EMyApNo = string("uQuvcyVPLecQkQsoFhvQlNhdgVku");
    bool VAeJECNiMYbrld = false;
    double nReHfxzcAlN = -833537.6379614292;

    for (int UWXySkXHC = 1079054538; UWXySkXHC > 0; UWXySkXHC--) {
        continue;
    }

    if (LnofCOWZu == -833537.6379614292) {
        for (int DGUUuqw = 1515339957; DGUUuqw > 0; DGUUuqw--) {
            LnofCOWZu *= LnofCOWZu;
            nReHfxzcAlN = nReHfxzcAlN;
            VAeJECNiMYbrld = ! VAeJECNiMYbrld;
        }
    }

    if (EMyApNo <= string("uQuvcyVPLecQkQsoFhvQlNhdgVku")) {
        for (int ZgucRAEQXbo = 1647672462; ZgucRAEQXbo > 0; ZgucRAEQXbo--) {
            LnofCOWZu += LnofCOWZu;
            nReHfxzcAlN *= LnofCOWZu;
            nReHfxzcAlN /= nReHfxzcAlN;
        }
    }

    for (int BuIqTzmpKtUkizH = 103757173; BuIqTzmpKtUkizH > 0; BuIqTzmpKtUkizH--) {
        VAeJECNiMYbrld = VAeJECNiMYbrld;
        EMyApNo = tppqVhUo;
        tppqVhUo = EMyApNo;
        EMyApNo = tppqVhUo;
        nReHfxzcAlN += nReHfxzcAlN;
        LnofCOWZu -= LnofCOWZu;
    }

    return EMyApNo;
}

string geIKz::AxuQEbLHznfnYK(string hBNqJCdoA, double rCmVQMmZfdrMfvH)
{
    int rZGfCYocElZBTSQi = -108828978;
    double UsHlSccAgTCaG = 598543.5518778822;
    bool ZdKNVOnIyqim = false;
    double MUmQjGOcfDorZJhx = 751567.1110100729;
    string uqsPbuVa = string("UqPZNexYDIDbb");
    string jGwvnlRCwPtIMVY = string("mdvCiJIVwfVSXLeeFvXBsQUeanVykHQjRthZmCtrfETYsSGWnTlMnPv");
    int AOAtVvwgnV = 10427007;
    int FBDJreWgKihq = 997312026;
    string HdBczobSe = string("fgBtpZZxMjfMaK");
    double QpErSbUbUQzxWSa = 398649.9342126784;

    if (HdBczobSe < string("UEHDYSlmcZotQJKWkqkcQGuEZwGXqhVMryGMiQbeVcyZJkwzHaSnZSwYGFESCqOUCvUfJLKlqJGAMXoMVVvhABkfhmXSrDwLIkCvTrTOlFoRHvGTOJzoXoraSgJnSsrupSJUEwntQEqgCFZOJkwFpLVSKzBvXUtttgsBAgLtj")) {
        for (int zgtygW = 221586820; zgtygW > 0; zgtygW--) {
            QpErSbUbUQzxWSa += UsHlSccAgTCaG;
        }
    }

    for (int zsRXbNsO = 846424092; zsRXbNsO > 0; zsRXbNsO--) {
        UsHlSccAgTCaG = QpErSbUbUQzxWSa;
        FBDJreWgKihq *= AOAtVvwgnV;
    }

    for (int TGjrsxolILxw = 1277335334; TGjrsxolILxw > 0; TGjrsxolILxw--) {
        AOAtVvwgnV -= rZGfCYocElZBTSQi;
        QpErSbUbUQzxWSa /= rCmVQMmZfdrMfvH;
        rZGfCYocElZBTSQi *= rZGfCYocElZBTSQi;
    }

    for (int YEsqnsiPDE = 1007216351; YEsqnsiPDE > 0; YEsqnsiPDE--) {
        continue;
    }

    return HdBczobSe;
}

int geIKz::UnMsBlIKJlrAXUj(bool xyWxFcA, double pWbTuPt, double jPHOPsuIZqsXmG)
{
    string mKhllQqHIwoAnG = string("fpAVUlhaAtxnNsbHdZQibISCLkaITubkOCRIumveDwTTQTAqPctxfeRWZTWZKTgvxOaYkObqYZVaAWtEpVAG");
    string vjZPYUjWbwbtCz = string("iKQxYyxiAX");
    string ogchCJDI = string("HxbjYcBedrVKaZMSpZduufVQYknAPPNFJnHDQtvvdkZKgNgMxoVWslslEdaXKrcBbRqUJIapLudTNUqRFdteUANEGgyaKNBbLfUIxxJtQmRmfdShfEtsViauJPtngagshdhoZrqJNJQZZLOzyMKKLfEzIEZMmcbbzumdFRQQTBtIisnSIpgIEzXGCLjPDiLucVSROynPJrNLQVhTWCuLJGWGgGhBFlsVlxjBBBAeFbg");
    bool HYiDwdGDfiNWR = false;
    int pITKrxchKvhYe = 1386509905;
    double YqqUIRMjOUrEV = -293411.4670811151;
    double fGhEmxnQF = -743717.3893548772;
    double NTnukPTwiRMImqZ = -851800.7281387912;
    string zsJZaDSLg = string("Wax");
    bool cGXEfDZnfncckFX = false;

    if (pWbTuPt <= -1034228.660156113) {
        for (int cosKUITzCZcBWjkH = 329277931; cosKUITzCZcBWjkH > 0; cosKUITzCZcBWjkH--) {
            jPHOPsuIZqsXmG -= YqqUIRMjOUrEV;
            YqqUIRMjOUrEV -= NTnukPTwiRMImqZ;
            NTnukPTwiRMImqZ /= jPHOPsuIZqsXmG;
        }
    }

    if (xyWxFcA != false) {
        for (int gdIEJl = 1352265320; gdIEJl > 0; gdIEJl--) {
            YqqUIRMjOUrEV *= fGhEmxnQF;
            NTnukPTwiRMImqZ /= jPHOPsuIZqsXmG;
            pITKrxchKvhYe /= pITKrxchKvhYe;
            ogchCJDI = zsJZaDSLg;
        }
    }

    if (HYiDwdGDfiNWR == false) {
        for (int RZWzTFCLuwWt = 25562771; RZWzTFCLuwWt > 0; RZWzTFCLuwWt--) {
            ogchCJDI = mKhllQqHIwoAnG;
        }
    }

    for (int fKUYCuEOEmzfEt = 478349623; fKUYCuEOEmzfEt > 0; fKUYCuEOEmzfEt--) {
        vjZPYUjWbwbtCz += mKhllQqHIwoAnG;
        zsJZaDSLg = vjZPYUjWbwbtCz;
        HYiDwdGDfiNWR = HYiDwdGDfiNWR;
        YqqUIRMjOUrEV /= YqqUIRMjOUrEV;
    }

    for (int GGiVBq = 592617157; GGiVBq > 0; GGiVBq--) {
        fGhEmxnQF *= pWbTuPt;
        cGXEfDZnfncckFX = cGXEfDZnfncckFX;
        NTnukPTwiRMImqZ = jPHOPsuIZqsXmG;
        zsJZaDSLg = mKhllQqHIwoAnG;
    }

    return pITKrxchKvhYe;
}

geIKz::geIKz()
{
    this->XnJHEzdJSRda(-165358.62141585074, string("PmLTFOElPjzxjkFgpzkcgmbQTUxKCqLfaBczjJWplWjyioZQdVoUQjZxKzwuFaWOnLrnSbwWuFBClFWKnfrCItleeSyoulYLcuEHnJRiOgCwakaHAVlOSuJzH"), true, 2047843511, -439771.2990676886);
    this->YyceWETFn(false, -1512039019);
    this->TaTzxEmPxAsv(string("ywulVmPQEoVcpypFejorjinICzDqddKBxxXWWshusEjLgdzqrQacKTYmAXzxWEjNKGXBkblXjVzakrhHrqNTvLfbNilbzugtwlMMOxBLSKFrDOSPsTovEMYfHzzubDOvyvgZmodtLpIMUxPUAbnnSuKoAjXAHvCOlSKGNBStNtpYomxTLsyIlmaQhulZFrLklgQQC"), 273173956, 1989377863, false, 486670273);
    this->lMMgfzLzpTukpxoA(string("xYFDsoGtvuyXjKwtOphfWlrLzhEZOwrjaiVfocqCnFIUEckmhOOxYNJJxXaXZmaVWubZgWDZTkzcJxnJazhigxLgYhZYZXzZNvpDxvKKJnCLmlrGpfrJuNyQuYKAWSzUIxJlfwBZtPjkUTdTIVxGLfsvXvRJfoylUpTCkpGKnGWXjtoJcjNwsxhohQLsIBwhloscuIXpNyyUmpjbkAkYvYckwOcnqvFEZZcJJK"), 566320.6049221543, string("BxfItRPfGBZLggEtQnljyzbpuljJIqtyVAwimIpUGUJYAfIbloaKrYeBMdIasiNcoPZzRbKsvGqbwuQtEMUgdKJlKGtWZmxbiVnvqBLaIBHtAJqZAiAtlIUFSupThJHkrHYRhVrnJsCMnZDpBWNRfoLISyTPPBhqGuQGEJSxpSYbOSwjirYgNZcNNllMaXwcSLHCbIYXUPcXuGLGTDBrGOVHMvGPJGqIqqzehfGVadMUTqByyYya"), false);
    this->sWmgXfEF(-491813.17163859983, string("qDcKwuHxnypdpJkfEHmJQYOmyHYlXRrSSwhUgwrWoMRXTYsnXHdcMUgTLGmnPWyTjfUgGBZzikQoPTUSQLZjWqvlAQVyYsBLDxUuUgwEtaTmqEJScIOqjIRuUAMVRJdeodKqMZtNoiBXiiKJhNJUOiVapwcpqvxbpBivTIsnwCeNOasbdZUeVYmLI"), 1097577038);
    this->RaIGc(false);
    this->UbuCBWOtMP(false, 540513007, -705259.2511321533, string("ocJBfrvJlzYqqLjztciPJdLnZBGFRdhkVapVAuHiyZaBhmDUnFyIiHWeTITAfZgNupWJSOmcbfSBxoCPKJwmVkpkmfGdgfeFLdQNcyoaajzlJzKAjrbOKtOebHOawzhxHHqdZuABZoovvMcxvoWRPbvdgfIbzxfDtGRfUNK"), 666607.1858018717);
    this->AZAAIuDXf(true, -780301.8670587364, 1957635502, string("qpTPwVrNivDbUYtKLMTxZtvwMxWcviBXtnuwXurHIgOPXkdGbUIbRHgiBSRhntlKRpsDhgxGIQByo"));
    this->sBqVEWt(false, 948278.2132202408, true);
    this->ehvobIpkVgXKu();
    this->AxuQEbLHznfnYK(string("UEHDYSlmcZotQJKWkqkcQGuEZwGXqhVMryGMiQbeVcyZJkwzHaSnZSwYGFESCqOUCvUfJLKlqJGAMXoMVVvhABkfhmXSrDwLIkCvTrTOlFoRHvGTOJzoXoraSgJnSsrupSJUEwntQEqgCFZOJkwFpLVSKzBvXUtttgsBAgLtj"), 594119.1093836759);
    this->UnMsBlIKJlrAXUj(false, -1015795.9413573041, -1034228.660156113);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZztGPHS
{
public:
    int fmOYO;

    ZztGPHS();
protected:
    bool qFkxXMXaKwB;
    string VJRtwrXizxkbY;
    bool osSkGvbzkBPBwAYB;
    double zMHVlvPJYk;
    int iWMnR;

    void XXNXcozbIW(bool IKloybuZtmJ, string oYtbQUhpOcLAWZ);
private:
    bool DBwLHhoFsSONN;
    string XUvkQjEU;
    string RXKgHiQp;
    bool wgDRRhkV;
    bool UjVNsIrcrIv;

    void OoPwjdVgsvrAJYbI(double yVrzjYVYjjYNNSjP, int jEQsJWWGB, string RjGzboc);
    double iOaYGhIAg(double TkzeroyecBfcn);
    int JXkoW(double OdtpXrd, double FAVdhbfyAUXfSeRS, string mqhrO, double lSWUoHFPhmsxxx);
    void llhAKC(int ajodDEBoZpKcpjpF, double RLymTTrWqECrF, int NHbnUgDoCtB);
    void fBhzuXfFRHZjJzzo(int NSoQloSA, string NnArN, string NxvhFUA);
    bool RyYgAZfNzw(double VQymHFwrdtURpyl, bool SZjyj, int OncWCnbz);
};

void ZztGPHS::XXNXcozbIW(bool IKloybuZtmJ, string oYtbQUhpOcLAWZ)
{
    string JKugEyicmRbLgAc = string("aHyxPpEqMbqhQKKYQqrzalAAQcCQFGGHCyjHvPdcrvIgLbNlBAe");
    bool ijuddalqCQSxUdzb = false;

    for (int AGZjhFKD = 650193393; AGZjhFKD > 0; AGZjhFKD--) {
        JKugEyicmRbLgAc = JKugEyicmRbLgAc;
        oYtbQUhpOcLAWZ = oYtbQUhpOcLAWZ;
        ijuddalqCQSxUdzb = ! ijuddalqCQSxUdzb;
    }

    for (int aGrdtoKmB = 770278104; aGrdtoKmB > 0; aGrdtoKmB--) {
        JKugEyicmRbLgAc = oYtbQUhpOcLAWZ;
        ijuddalqCQSxUdzb = ! IKloybuZtmJ;
    }
}

void ZztGPHS::OoPwjdVgsvrAJYbI(double yVrzjYVYjjYNNSjP, int jEQsJWWGB, string RjGzboc)
{
    string uSHeJdXehVO = string("PYZCJOaBHSDDyLYwnZYqXHzgNMABiuwHApAFVxeOaXOaCqpqXRhzpdlnwEBpRMGwnTNJypxcUjuKSBaeanmTwhFSUCkOvjxNdORNiitBVkfsmdYceQKBsVADrhsvXxkMBHvEeOYuKsxXyUejLsOlLtcVgdjnlCo");
    bool XrvGXiDXPQZoHNSb = false;
    bool xahZqRz = false;
    bool KGSmgmzILNzs = false;
    bool ibNXDLfpEIlBKRKt = false;
    int hDpovAgcqqcl = -2107966590;
    bool lfjSpgRNWNczquOg = false;
    double krhIsHeOGub = 397598.7386936119;
    int SDFpQ = 78598870;

    if (xahZqRz != false) {
        for (int zBphx = 1679480300; zBphx > 0; zBphx--) {
            lfjSpgRNWNczquOg = ! KGSmgmzILNzs;
            krhIsHeOGub -= krhIsHeOGub;
        }
    }

    for (int BiKrILHxCYthDCb = 2025537292; BiKrILHxCYthDCb > 0; BiKrILHxCYthDCb--) {
        XrvGXiDXPQZoHNSb = ! ibNXDLfpEIlBKRKt;
    }
}

double ZztGPHS::iOaYGhIAg(double TkzeroyecBfcn)
{
    bool yoQJroL = true;

    if (TkzeroyecBfcn >= -1028432.9218836458) {
        for (int GEwHxfTmmongsf = 1858252021; GEwHxfTmmongsf > 0; GEwHxfTmmongsf--) {
            yoQJroL = yoQJroL;
        }
    }

    if (yoQJroL == true) {
        for (int tpnWazrybaPrzVW = 1896287186; tpnWazrybaPrzVW > 0; tpnWazrybaPrzVW--) {
            yoQJroL = yoQJroL;
            TkzeroyecBfcn = TkzeroyecBfcn;
            yoQJroL = yoQJroL;
            TkzeroyecBfcn /= TkzeroyecBfcn;
        }
    }

    if (TkzeroyecBfcn != -1028432.9218836458) {
        for (int XoUgA = 1637547847; XoUgA > 0; XoUgA--) {
            TkzeroyecBfcn += TkzeroyecBfcn;
            TkzeroyecBfcn /= TkzeroyecBfcn;
            TkzeroyecBfcn /= TkzeroyecBfcn;
            TkzeroyecBfcn /= TkzeroyecBfcn;
            yoQJroL = ! yoQJroL;
            TkzeroyecBfcn = TkzeroyecBfcn;
        }
    }

    return TkzeroyecBfcn;
}

int ZztGPHS::JXkoW(double OdtpXrd, double FAVdhbfyAUXfSeRS, string mqhrO, double lSWUoHFPhmsxxx)
{
    int OMYiYit = 1266315116;
    int VAqKHB = -1583602461;
    bool euKLsYNNbvjJOS = false;
    int lbvTutOYLnaO = 6783370;
    int LpYeumfZEKa = -111590076;
    string cSndsWJbAxyljX = string("hXZmhnuTLzFqKMNSbPoHDXHQbwjGiRSPgHsOxuSyjGuDMLiVjbYGxbUTFElLBsSdErOyJTsHpABAnebMQ");
    double eHDAoMEzvLk = 266566.99742044305;
    bool UGkgDNNa = true;
    string JzTodFQTFQGs = string("ULhTUYrDnErpEzNpMouLJoGUYFBhZUVnzVzysKSOedgsOkDIdqnmyTbTfblabWiYjPOUTEchmpYytXziSMOYfDGBhxANwcSUxZjEjMAnjRvgMLQOFZGQCtopwNQmexVrFFyVcaZDBZykXbJGOnCfBAMAuOidkWmrNzLYOkSojSKGbvgnHWxoYSTVKclHHq");
    string MhuvOeRRtmVck = string("GYOtQZPAWLOKNsFqwhiFPMWRBeafLOCcKzIYlQiUVYyPRjprHJQsmpxPUdSUDyUVSaFFCKZKnTABLYwTnKTcxDHvQcZqGcOQqRgwavBBznZeOytYSErkqYfWKLmwghEEIkJRowBswVYLUfJPLNwnlpHEDKPRaSWPJEwrCCxCONPCRIvAhGdhXKhRyrtxGshQOFEMvvcYgXLwaFqNnNhaVnyBwPRofeSvM");

    return LpYeumfZEKa;
}

void ZztGPHS::llhAKC(int ajodDEBoZpKcpjpF, double RLymTTrWqECrF, int NHbnUgDoCtB)
{
    int vaHiMLZ = -1782802692;
    bool gAqNJUWXCwr = true;
    double evwLslartybwC = 160700.48687691177;
    int RFBhqoXBoKvcP = -1562995448;
    string BHftCAEHBgL = string("IEnNFckpiVEumYUoBOIUjwZAtMMtUmWVaJwbbTtySgTKGrfwPvMHBYDadFqaVKhZfhrJkxUGRHtqRoQPXhTiJWrhMI");
    double cxwIBKglgxG = -101642.0315727015;
    double UkhqOqpGABcJN = -533710.7721450885;
    int DNByroFrzbVGf = 1787221931;
    double PloHW = -665205.5450398176;

    for (int gTIDhSHODiwBSMR = 2105925802; gTIDhSHODiwBSMR > 0; gTIDhSHODiwBSMR--) {
        gAqNJUWXCwr = ! gAqNJUWXCwr;
        evwLslartybwC = evwLslartybwC;
        UkhqOqpGABcJN *= UkhqOqpGABcJN;
    }

    for (int WHlgVESrHlzlVBlt = 1670781116; WHlgVESrHlzlVBlt > 0; WHlgVESrHlzlVBlt--) {
        gAqNJUWXCwr = ! gAqNJUWXCwr;
        NHbnUgDoCtB += vaHiMLZ;
    }

    for (int QvPWPD = 17940336; QvPWPD > 0; QvPWPD--) {
        NHbnUgDoCtB = DNByroFrzbVGf;
        cxwIBKglgxG -= RLymTTrWqECrF;
    }

    if (RLymTTrWqECrF != -665205.5450398176) {
        for (int iAcQlvwsKx = 2079650047; iAcQlvwsKx > 0; iAcQlvwsKx--) {
            gAqNJUWXCwr = gAqNJUWXCwr;
        }
    }

    for (int mBtZB = 459509064; mBtZB > 0; mBtZB--) {
        continue;
    }

    if (DNByroFrzbVGf <= 1787221931) {
        for (int EPPhrUcx = 1177302011; EPPhrUcx > 0; EPPhrUcx--) {
            gAqNJUWXCwr = gAqNJUWXCwr;
            NHbnUgDoCtB = NHbnUgDoCtB;
        }
    }
}

void ZztGPHS::fBhzuXfFRHZjJzzo(int NSoQloSA, string NnArN, string NxvhFUA)
{
    string ykJygQjtEh = string("tRiPceKnZiansLvetOFhIVmwOawjyuBdxRQmYjfPVJazQiboGoWJSqFJgSptUBxjTUgZUMmnrmcDUlCBrnNawwpZTLyOnaLDOOGWQJrfPWkOlFTZwRlIkJUSiFymmsfuqgovjFUtVDEuTgTdQMxiyYkKBJgLkdxciwZasvoAcuFgcaJfQnqrGaIDsEaYRMwYtEjrJDyNClruai");
    bool rhYbMpfWg = true;
    bool GZgXDQUN = false;
    bool aRYOfxeQGKEaR = true;
    double aVygBXygumF = 848828.8026331442;
    bool nRdGJMDV = false;

    for (int WSkKRFnQT = 896349861; WSkKRFnQT > 0; WSkKRFnQT--) {
        ykJygQjtEh = NxvhFUA;
        GZgXDQUN = ! nRdGJMDV;
        NxvhFUA += ykJygQjtEh;
    }

    for (int HkIqwS = 399222776; HkIqwS > 0; HkIqwS--) {
        nRdGJMDV = nRdGJMDV;
        GZgXDQUN = GZgXDQUN;
        GZgXDQUN = ! aRYOfxeQGKEaR;
    }

    for (int wuhpZCPgNEKIZwfB = 1842301694; wuhpZCPgNEKIZwfB > 0; wuhpZCPgNEKIZwfB--) {
        NnArN += NxvhFUA;
    }

    if (aRYOfxeQGKEaR == true) {
        for (int bDVCppZ = 1199781428; bDVCppZ > 0; bDVCppZ--) {
            GZgXDQUN = GZgXDQUN;
        }
    }
}

bool ZztGPHS::RyYgAZfNzw(double VQymHFwrdtURpyl, bool SZjyj, int OncWCnbz)
{
    int JNozAmB = -1225994029;
    bool PGRlulDwhub = true;
    double GSZyMnZVwXMR = 482793.24596815585;
    bool wbrOi = true;
    string XVrKLYifKwYen = string("IGbQUdsgvqMVCnlJxfLozbPBdDQshCdXVRDeLjimyFpuTZrREDlNtEklGBcMqmaCFFwlbdhOwrjvhoXBqPyLOCxjzdynRNakMbM");
    double BsFov = -291391.9396966534;
    bool MxCAfoqkcyZiLcC = true;
    bool uPaBAo = true;
    double JcCgl = -525355.9553831269;

    if (GSZyMnZVwXMR > -291391.9396966534) {
        for (int wgHVAgJ = 165302650; wgHVAgJ > 0; wgHVAgJ--) {
            JcCgl += JcCgl;
        }
    }

    for (int vfQmtpJRCZ = 116234534; vfQmtpJRCZ > 0; vfQmtpJRCZ--) {
        wbrOi = MxCAfoqkcyZiLcC;
        uPaBAo = uPaBAo;
        PGRlulDwhub = ! wbrOi;
    }

    return uPaBAo;
}

ZztGPHS::ZztGPHS()
{
    this->XXNXcozbIW(false, string("oEyhmlrsqEnyaujmuyasYHmNHSdaPxPSWLCNOWpjezbkkiACeRLeBwoDRDXLtWoongcXsoSikpixzuHzuhRmXEZEjTKhJAxwbeLzsykKUPQQtkDuSrdJIOfBRNlYjFgYzgKlkDYtVcNvusDJVVKtggYOxTZWrJXhYzCEPHfigUqEAwcnzJcQXjnpukckUwaiWLRALsiyRQvWsPTYcunuOGgDIWGAoumYalJQPlyccqkjQNHsVjhofSjFczlovE"));
    this->OoPwjdVgsvrAJYbI(363352.1783953192, 1149753801, string("ErqvqeYTCNOxVyKBgZrkYGVGxHuLujNBklZrsspyRaOLlHhOvwHHsRMkzqQcHBBpPAJqRnGLgwPuuouzbdfeFtyPcNmqpaRbZOFszeutjShIsClMuYvTjEmCCTjeFLOXxSqThQSUWqQ"));
    this->iOaYGhIAg(-1028432.9218836458);
    this->JXkoW(87538.09477439472, 652001.3591983791, string("RolQjczgtkKoouclYTBRtzFYHpPnUjXXrvOTNTxORQjecviGdloRQlkpLHkzDFgMHdNEXbGfPCEeMWtEtPkmspzSEwFbjCnwLdpBLNYtSvDlriNqvlFiFgAhnegtlOvxZUGUayJdcqUAZylTRSpbdlXKnoHkRdryGoxBivpPYfIQrXdVo"), -264708.72498467244);
    this->llhAKC(656108100, -340850.40974813956, -368282481);
    this->fBhzuXfFRHZjJzzo(1717258196, string("UbCfdawwtZGOefrgBnESItHWpuSYlsspDVonepmMhSNpUHSFxCxLimGOCjmklaSAFfOESVNjFbzqBLkxxKBYDcRzKxdmQGtccKzYvhRcjKqFQENcFjaQSJSgkgkRqeGoiLObTYBnlLYnT"), string("zyZneIbwRbQIHZrvGxPaOwkgYfbauDiSTPojJWLIXhpkwgqWoUhmwok"));
    this->RyYgAZfNzw(-769079.3414556466, false, -1710894557);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tmTUkdSTUx
{
public:
    int NMyCRu;
    bool jnbQwmUqLjEAn;
    double GhinWpCdsBxGSwM;
    bool jcgdJZGFpoG;

    tmTUkdSTUx();
protected:
    string seXNxgObzN;
    bool jqIGKfWSRSyNwpXH;
    bool bmQnlbGtaydwWeZ;
    int kWOmPK;
    string LscYhQNfxOaJb;

    string MZJHvRCfVP(string zeuPm, bool aYGMPinVu);
    void rOGPVvfulkvlmp(bool oJHltoJuOYQTcsOF, string PSenCdDEJWmNQLCY, int ZIjeLjeuOTgeJMg, bool lBETmtzW);
private:
    double SPsDCDvT;
    string gjCttvWC;

    int sLYIE(double EfLVcOItpjCNn, string MhZKKjwiuwLXP, string xTNWQH, double DYgzgaOOsbQdszrx);
    int liFmKoyQPYpLka(string fQAmOIqDv, bool xmFqYcEJG, double lImotJrfgnpWiRxO, bool iHiIOdWjaAgEfE, bool IQmgaDzWJMG);
    int rnLTuLljNabtrCSV(bool VhTqLAmuNpIGXy);
    string RSHmQKRCLaf(bool kbjUHMa, double SIKrYuux);
    string iSAQMIFDrohpjeAZ(string vxWtRfxBL, string PpkdNnEOH);
    int TczrRVCj(double GifBmuRCuubpk, double tUCHiFmGMe, string tzssJnzkhoeOQl, string eKsAUVYDNWYPG, double bbFXcXjUt);
    int LyCSDdGERcAScL(string JIPwn, string qtzPBMG, int pIUvDTnBfof);
    double Mbrxq(string kPjyTDqLLGWWqPcj, int rFeUSyI, string XefBocNOEF);
};

string tmTUkdSTUx::MZJHvRCfVP(string zeuPm, bool aYGMPinVu)
{
    double ZFgVcYwdwdaSS = 329431.17543811945;
    bool qUAnKGxoPo = false;
    string UDgutXTZoiaC = string("immlVFUnkFbpGAqHXChfwPyqHnqkDfYoHDrMGRZCpuJHltLWGpzBIdzFqRfIOjOvEdbjwAeeHuFQYttspBNZfYzZYjHhhdEyfBrgAsLsqtiOPqyYKHFVGnvmoJyFrSODQvgJibzRLZwQg");
    string UEYHytZzMTSi = string("znfcyREFwxjcGhlLGtYRKDXJdnZuigTQgNVYSPNTnrayDiSQzXLiEBJbzBuqZxcjPlTqBqrHdIXQMkKKAUFohliNucrUAbXrzacyUNqZkIdZKgOzQeZGtqEBkCnurnQaCDfOAOkUbPmhcHvPpkjmUW");
    double AFaTDTeD = -709976.0051970129;
    double ymQFjXVIJ = -978622.2332503136;

    for (int QMkinSecYMsNLB = 699887073; QMkinSecYMsNLB > 0; QMkinSecYMsNLB--) {
        qUAnKGxoPo = ! aYGMPinVu;
    }

    return UEYHytZzMTSi;
}

void tmTUkdSTUx::rOGPVvfulkvlmp(bool oJHltoJuOYQTcsOF, string PSenCdDEJWmNQLCY, int ZIjeLjeuOTgeJMg, bool lBETmtzW)
{
    bool pqssmHQiIcPc = true;
    string xXpbUHHqZJYXyfUI = string("sKUDPkhDAwUfOEHJWkMcNhrMRZlQouAmohUFEdeSIWWltBWKaKDBeNELHvTPTlCETSjRqEmFEqZCbUJqmQRhGQMBWEIyOTaumRmtCTfzIgQVJcobdSoGEzXDAJiVykpHfAHXIYArdaRtiIIpSiWJGQ");
    bool IxCrUUBCfwplm = true;
    string qGWOcatV = string("fBlRsbaUTwJOkyngzMwZnWhvxYZmDZMSWPtEkzzayftjUEYgomLYigUfzlZDbJyPwnyhTYEHmYcgwgSzglTQnFpDDRjxSEJnSZDUIIxCEgYjhfSqVrbFCLhkzUqOBfpLczPgs");
    bool NUTYP = true;
    bool bHLEwVFvKW = false;
    int JGPaHOIAjHImg = 1377981686;

    if (NUTYP == false) {
        for (int rowvoGMW = 387327726; rowvoGMW > 0; rowvoGMW--) {
            PSenCdDEJWmNQLCY = qGWOcatV;
            lBETmtzW = ! lBETmtzW;
            bHLEwVFvKW = ! NUTYP;
            bHLEwVFvKW = ! pqssmHQiIcPc;
        }
    }

    for (int FGgawgneXXOOY = 1807782365; FGgawgneXXOOY > 0; FGgawgneXXOOY--) {
        bHLEwVFvKW = NUTYP;
        IxCrUUBCfwplm = IxCrUUBCfwplm;
        oJHltoJuOYQTcsOF = NUTYP;
    }

    if (NUTYP != true) {
        for (int yIZXr = 386576420; yIZXr > 0; yIZXr--) {
            pqssmHQiIcPc = ! lBETmtzW;
            NUTYP = ! NUTYP;
            PSenCdDEJWmNQLCY = PSenCdDEJWmNQLCY;
        }
    }

    if (qGWOcatV > string("sKUDPkhDAwUfOEHJWkMcNhrMRZlQouAmohUFEdeSIWWltBWKaKDBeNELHvTPTlCETSjRqEmFEqZCbUJqmQRhGQMBWEIyOTaumRmtCTfzIgQVJcobdSoGEzXDAJiVykpHfAHXIYArdaRtiIIpSiWJGQ")) {
        for (int RjlcULiqXiE = 628613144; RjlcULiqXiE > 0; RjlcULiqXiE--) {
            oJHltoJuOYQTcsOF = ! bHLEwVFvKW;
            NUTYP = ! IxCrUUBCfwplm;
            NUTYP = bHLEwVFvKW;
        }
    }

    for (int zEMip = 503843618; zEMip > 0; zEMip--) {
        lBETmtzW = ! oJHltoJuOYQTcsOF;
    }

    if (bHLEwVFvKW != false) {
        for (int eHEpnfj = 261396269; eHEpnfj > 0; eHEpnfj--) {
            qGWOcatV += xXpbUHHqZJYXyfUI;
        }
    }
}

int tmTUkdSTUx::sLYIE(double EfLVcOItpjCNn, string MhZKKjwiuwLXP, string xTNWQH, double DYgzgaOOsbQdszrx)
{
    bool tKdbkuI = false;
    int JzzOOlLZNahPWGH = -1082196935;
    int EenDKYiCYXFe = -457575765;
    double jgEiQaSSnTMsftTc = 854496.7123524343;
    bool qnwezzmeY = true;
    bool dVNjfMaRZdbG = true;
    int lTbEeIKPUaPMvyTI = 1901876037;
    bool UsyoPDAPN = true;
    int ryBSRcMDSZM = 501744927;

    if (qnwezzmeY != false) {
        for (int SHMcHaXGyuQTY = 2112210630; SHMcHaXGyuQTY > 0; SHMcHaXGyuQTY--) {
            continue;
        }
    }

    for (int iZLXokkwyYJ = 980032856; iZLXokkwyYJ > 0; iZLXokkwyYJ--) {
        continue;
    }

    return ryBSRcMDSZM;
}

int tmTUkdSTUx::liFmKoyQPYpLka(string fQAmOIqDv, bool xmFqYcEJG, double lImotJrfgnpWiRxO, bool iHiIOdWjaAgEfE, bool IQmgaDzWJMG)
{
    int QBlwQWFjByWgaMkQ = -346551504;
    int OBPtZbkFutn = -502013307;
    int kFbBLjHZYi = 971526485;
    int zFfHzufUfWO = 1215010046;
    bool YSUGEWVAf = false;

    for (int wyTuS = 269265480; wyTuS > 0; wyTuS--) {
        iHiIOdWjaAgEfE = ! IQmgaDzWJMG;
    }

    return zFfHzufUfWO;
}

int tmTUkdSTUx::rnLTuLljNabtrCSV(bool VhTqLAmuNpIGXy)
{
    double dhevXr = -646804.0597894557;
    int TRcto = 1109974807;

    for (int DFGCDamyRaGfmGn = 1429175474; DFGCDamyRaGfmGn > 0; DFGCDamyRaGfmGn--) {
        TRcto *= TRcto;
        TRcto *= TRcto;
        dhevXr *= dhevXr;
    }

    if (VhTqLAmuNpIGXy == true) {
        for (int NWFgCMQWXfUrpff = 1143849436; NWFgCMQWXfUrpff > 0; NWFgCMQWXfUrpff--) {
            TRcto -= TRcto;
            TRcto -= TRcto;
            TRcto -= TRcto;
        }
    }

    return TRcto;
}

string tmTUkdSTUx::RSHmQKRCLaf(bool kbjUHMa, double SIKrYuux)
{
    string unYPApJIH = string("QRITTKOtUQAMiOeBvyMvuhWRsCoomBrmPegQHZbIpxKRyrpDGFiZPstEXVXldcoxQzUyRLFpxCZsTByYntVmXTawhmqoNxGseXx");
    int FuuBClyDzhsAHGlD = -341837233;
    string majPUSWCOrVXZ = string("jzNWJJWeQLJSktLipviIsrvUWLBTPpvMxKCtXfEwpeRzUzyzIHyIifhvNJADhgaLyfanSmGlqOTeTOrwqAaGochzSKmSBSueyoTSxaALhjWEKtOwlZGRzpnvKSAQWMSfmSAhbxULLnkPD");

    for (int OOzPChPtEzeQ = 64533088; OOzPChPtEzeQ > 0; OOzPChPtEzeQ--) {
        unYPApJIH += majPUSWCOrVXZ;
    }

    for (int XKGxe = 566248990; XKGxe > 0; XKGxe--) {
        kbjUHMa = ! kbjUHMa;
    }

    for (int uchCvcnZJepZ = 2028880256; uchCvcnZJepZ > 0; uchCvcnZJepZ--) {
        majPUSWCOrVXZ += majPUSWCOrVXZ;
    }

    return majPUSWCOrVXZ;
}

string tmTUkdSTUx::iSAQMIFDrohpjeAZ(string vxWtRfxBL, string PpkdNnEOH)
{
    double VXxVnmHr = 356228.7210080964;
    bool vwxHxwgMdZGLQT = true;
    double TMMMrPddHj = -677916.0769401835;
    bool oDjSoRbFJFhG = false;
    string vtyCyAcW = string("UOovkNElAVaMdIXWyOpoENdomwps");

    if (vtyCyAcW < string("HYLnOpRYdifkZFiLSdteRrcOfnYgEhWfpPlTBHNwYNKtZCXERFIDIVYGrDublCjkUychmWYJirMiOfYciMgPAGagSuPmzfVbCEPZFVEOESKupWvakNVUzbhRdFZiPFMmPXUiLpUPGDyOItRIeCpuMLIqQFDAbURGRzMEbnMDnQjhRuqUcnhhkjuvphJPXgshSSFDbeSvQNFQoUDFpqdMaC")) {
        for (int RmtvkCE = 1087853607; RmtvkCE > 0; RmtvkCE--) {
            continue;
        }
    }

    for (int WsoUQWg = 507932456; WsoUQWg > 0; WsoUQWg--) {
        vwxHxwgMdZGLQT = oDjSoRbFJFhG;
        TMMMrPddHj += VXxVnmHr;
        vxWtRfxBL = vtyCyAcW;
        vtyCyAcW = PpkdNnEOH;
    }

    for (int pOUpTfcADYJvq = 683445327; pOUpTfcADYJvq > 0; pOUpTfcADYJvq--) {
        continue;
    }

    for (int HhYsLVNKPiz = 1054389746; HhYsLVNKPiz > 0; HhYsLVNKPiz--) {
        TMMMrPddHj *= VXxVnmHr;
        TMMMrPddHj *= VXxVnmHr;
    }

    for (int oIQvnCOiINcK = 727714967; oIQvnCOiINcK > 0; oIQvnCOiINcK--) {
        oDjSoRbFJFhG = oDjSoRbFJFhG;
        vtyCyAcW += vxWtRfxBL;
    }

    for (int ddRaBCfWaeqe = 612128549; ddRaBCfWaeqe > 0; ddRaBCfWaeqe--) {
        PpkdNnEOH = vxWtRfxBL;
        vxWtRfxBL = PpkdNnEOH;
        PpkdNnEOH += PpkdNnEOH;
        vxWtRfxBL += PpkdNnEOH;
    }

    return vtyCyAcW;
}

int tmTUkdSTUx::TczrRVCj(double GifBmuRCuubpk, double tUCHiFmGMe, string tzssJnzkhoeOQl, string eKsAUVYDNWYPG, double bbFXcXjUt)
{
    string RwkyOCOrDiOmpijA = string("LZscgsmGJYmxuOlomWLIymjOaPlWxQXAochmTxbdXpORJWTNPfFdA");
    string KZtYTBSq = string("gXJfdPNDdHjRbZsYMZeXhBV");
    int WLQwFXEMjQNUhm = 971348359;
    double hTfJOWYJ = -753840.7779024746;
    bool ZSHyEgpAiYB = true;
    bool zRJhPnFkuUzUE = false;
    double tsvCunsx = -660127.0056611965;
    int YjkeQjS = -214880385;
    double JKovcXlyR = 38713.39879753767;
    bool byOGkxlZ = true;

    if (eKsAUVYDNWYPG > string("LZscgsmGJYmxuOlomWLIymjOaPlWxQXAochmTxbdXpORJWTNPfFdA")) {
        for (int TcNEzccuziLtXo = 129814374; TcNEzccuziLtXo > 0; TcNEzccuziLtXo--) {
            eKsAUVYDNWYPG = tzssJnzkhoeOQl;
            tUCHiFmGMe += hTfJOWYJ;
        }
    }

    for (int EltDPbdt = 316450817; EltDPbdt > 0; EltDPbdt--) {
        KZtYTBSq = tzssJnzkhoeOQl;
    }

    return YjkeQjS;
}

int tmTUkdSTUx::LyCSDdGERcAScL(string JIPwn, string qtzPBMG, int pIUvDTnBfof)
{
    bool lpJRjhPSqhR = false;
    bool mkTHjRUp = true;
    bool mUomvysSExaYX = false;
    int nsOtGOQTwFgjr = 2111418595;
    bool PUHJSAsw = true;
    bool erlTSquKQXSjTWiN = false;
    double jaZbRrwGeOEoJMm = -445157.8235215093;
    string LdOKbtIfTS = string("pmLozYoVAqnwXXRVUiqkaLuBpNUaSxfYiVTXIBBAVqUkqNtWHwLpqgLsmEsihaIQNCtYfuBapKHXlWzpuuGGVeKA");
    int BUmJMh = 1580473249;
    double nOTMKa = -443516.5655371258;

    for (int mCgbCCbU = 829020357; mCgbCCbU > 0; mCgbCCbU--) {
        mUomvysSExaYX = PUHJSAsw;
        jaZbRrwGeOEoJMm += jaZbRrwGeOEoJMm;
    }

    if (mUomvysSExaYX != false) {
        for (int oWUqojghNgZ = 363152872; oWUqojghNgZ > 0; oWUqojghNgZ--) {
            BUmJMh = nsOtGOQTwFgjr;
        }
    }

    if (PUHJSAsw != false) {
        for (int IUnZcGbQ = 232623841; IUnZcGbQ > 0; IUnZcGbQ--) {
            mkTHjRUp = PUHJSAsw;
            lpJRjhPSqhR = ! PUHJSAsw;
            jaZbRrwGeOEoJMm *= jaZbRrwGeOEoJMm;
        }
    }

    return BUmJMh;
}

double tmTUkdSTUx::Mbrxq(string kPjyTDqLLGWWqPcj, int rFeUSyI, string XefBocNOEF)
{
    bool OlsHUm = true;
    bool qHWrdhitcdj = false;
    bool bXCisXi = false;
    string BoxRidmtWdN = string("PPinsGPHMScqzCEFEzxjrjHqQwnleNDlrpNpErhHiFlsmJmApqpsGBbqtUlIASQpGtlOHRvMjNFpwncvDcmagGavEspPhxavBOpHOgZDBCkfcUXpSCzOnZJHSXMdLSxrKudnlQxTvDKnwHeZcKPkYQXZAatqxFGqnaB");
    bool vmtIs = false;
    double jycpgietVHKd = -12657.862550267213;

    if (bXCisXi == false) {
        for (int CQGdWisIxnuK = 399005335; CQGdWisIxnuK > 0; CQGdWisIxnuK--) {
            qHWrdhitcdj = ! OlsHUm;
            vmtIs = bXCisXi;
        }
    }

    if (qHWrdhitcdj == false) {
        for (int MqanE = 391234490; MqanE > 0; MqanE--) {
            continue;
        }
    }

    for (int UgOGNT = 580833220; UgOGNT > 0; UgOGNT--) {
        continue;
    }

    return jycpgietVHKd;
}

tmTUkdSTUx::tmTUkdSTUx()
{
    this->MZJHvRCfVP(string("OUErGrtmpSwamqBrnuIRwBLmpSujmUdYQJoptnUyYxasIKGDoudyMuKrAHvLQzZieRXgEEDuguKazLrktlVZjTbuUtVdvXTijSPXRqZFklxekmkhMssnDIUxsDEgLUxjAUbXZEkXkthclQTVIGggfPnXKlkYpzNRCppFqZZxEbqfWhmEeoqIAjpAvL"), true);
    this->rOGPVvfulkvlmp(false, string("MyGPyscqneftSHXmWvZrLAZx"), 617741693, true);
    this->sLYIE(909900.0860896275, string("gqJMRjMxhoIITAmcirIMiyoGOGXnP"), string("iiGOdOFDUkyJuQqi"), 586993.134271754);
    this->liFmKoyQPYpLka(string("VOqNyvqJvlTrxlulxZZQtcLVtySZuNtbMLHAaAHXqnARWqZfDCztzInkvuStTLREIMAUCeMhxhtnMHUIjMtkQHgPGToSBIsynHCaREgCQhCBhBwWTnDEphlJLuvcySJtEBQgmAuopqUelvsQzrbVWCLKLNrCNHYiUzqPqFJWQCzLMrpcefnMBPZATIRMKVRTfHubwGyokT"), true, 789418.3727276798, false, false);
    this->rnLTuLljNabtrCSV(true);
    this->RSHmQKRCLaf(true, 17613.99437850083);
    this->iSAQMIFDrohpjeAZ(string("oVaLNWWGfYBGhUXgfJDIMwyUNaVWPOhuJfLvyNRUCqDKsAGvQEIZZdOJZvYrZUpcStUFAnvdCLkGdrUaNxQcbtofzzaEskxxPXXGXibxovVRtHfemSIRrXJUWScsaMcVNJvOVcMyFpPyJefamiPuaqJruHVzIpzXbYbULvmotVOETBkTtYdVDVAgwiCQZPjsGLXEPApTvfZlCwLKXFohc"), string("HYLnOpRYdifkZFiLSdteRrcOfnYgEhWfpPlTBHNwYNKtZCXERFIDIVYGrDublCjkUychmWYJirMiOfYciMgPAGagSuPmzfVbCEPZFVEOESKupWvakNVUzbhRdFZiPFMmPXUiLpUPGDyOItRIeCpuMLIqQFDAbURGRzMEbnMDnQjhRuqUcnhhkjuvphJPXgshSSFDbeSvQNFQoUDFpqdMaC"));
    this->TczrRVCj(-81289.90687556131, -797808.3140287729, string("dAHMNiBaqYCAcVtSSvHqTXasdXXOUZLTxVSePcnmGxfwTUTYvcfaUDtjBrAOQvkURsnh"), string("XYOSeAZxoZBUuYXcGuhQtiPLcJDomScqafTWcwtqxzVnbpNViuqyfWWhIhULmNSBSsGHslTbAHeFaKNdLCElppTnsMbKpuWfasWlhgnUIssIQlScrZwvFUNSBPMCAuEXXfxPadKOpwTNFiFMijoLBQYCUBSrsPuagYTQQMTkAGljxletPOXIBiFwtmImN"), -1009206.4787151853);
    this->LyCSDdGERcAScL(string("rxbOHDXCoMLLLvCQVWnggnHrBYLWIDSFYbVuhxPPSSCFEMmljbWXTXAyDonusfCRmnhhCpbEENKYlXAULnNneMuCtCCHjWRPzijaQLMZeQQRGqcWkVFcYRQKuDxKVZwamSrAjbSujXGXvQfjouKdoIbmucEpzZdHmcJkNWpHCwePbiejvJJsTRWNOjooIRwhqXLcXsqPhfmdIHsGGPPVGJdomjTxrHEDrDzxaHAfpUvfEjkaTErzgwVWzLxt"), string("HXdqqeMFzoYFcWTiesVSNhwHAgyURTWRNAWwaFrvRahEAQaaJYJmuNQjTUpnRBcrbVVTBJmwaSCNMwQYOEwPenAXQLbVPNvcgIYcuXNZlXbJqpamoywMBiqqihFVpWzYkTBtXnrgRciJVpUOxBXaEDYMPZnXLgQPzYjGZXyyJKKRfFPsyjPGALQgTahqLgQWBArcErVEtZFPKW"), 211872397);
    this->Mbrxq(string("RGAVKASFqEFiuFRXpxHQvMgnoUIwaCVTOqXdYuKcGQakJMedLeMNbJYkETKFnlmVOu"), -69165089, string("CtFEQDkzOJFZomLdjOlAeDLGuXfpSRAWhMcgvPXOGhjc"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GdiLsZYGeF
{
public:
    string tvUjXAfSnquZSij;
    bool MqpZwYVmesIDQn;
    int EyEmxWUGPJwZhvaf;
    double TKPKK;
    bool juWduutXNGhV;
    double wonWIIHNQPM;

    GdiLsZYGeF();
    int tzcwWfifPfnb(bool bAiGFvqZjqQx, int fwoVBifFVqfS, double RyJLxfjafklQ);
    void rxSRYvgVSElEz(double QMGUG, bool aAaoTR);
    double nxcClCwHKSlyWH(bool kNBvAGxSGZle, string Qlcsh, int RyVPqEhBB, int AKtpexaWhKQPAcNQ, string ayJqqTMj);
    void MiVMCr(int swRaKLGhF, double ikqcAthXcIJW);
    bool xGOKUY(int REnEVBXX, int QhzZYQsCVTsZnm, int KNpEcGYBufCUDV, bool hVbuRpSaEFiBkLDp);
    string NVAfZCRYSstfJNtt(double zTqOQLnl, int WrywqTQK, double HXJAeXS, int auYwBtcQ, int ScZaCAFB);
protected:
    int KVdAAeaAXuYnle;
    int WCVWoYmLHCqLSlt;

    void qXultwCKRXOo();
    double fEnPt(double APMVBhJNNkzjWvsa, double xquMcLeqlUcCLHc, int WWFzCWYEHHZOzJBO, int QlPXoaZh);
    void Nxsqd(bool VjZkAUmBFRlPWC, int faVMJ);
private:
    bool wYEKopWAJKKpT;
    int FZrHPTQMzzDMTz;
    bool kBSttRlTCGfoNTv;
    int tGpjJz;
    int bhsnsj;

    int tUCUXiNiJcVgS();
    string jkjmeoClJOOR(double QOwFHNnQtxdIn, string LrzwbSn, double umGgTt, double EHjLxeeVGJkQy, double ArYaJR);
};

int GdiLsZYGeF::tzcwWfifPfnb(bool bAiGFvqZjqQx, int fwoVBifFVqfS, double RyJLxfjafklQ)
{
    double boMqZNFrVpgtHEb = -666381.9450123055;
    int yIcuv = -202022697;
    string xJHBjDP = string("btOGaYjIIStMliYyclNLcwxWRVJVGoVeIuqYiAYJEEhPBGNqxUiLriNNLDjEDfnpehOSXWZBDTCWenMZeSaR");
    int wMDJfKGzJJb = -528732160;
    int RgSlWYyXtXTIZ = -1559654306;

    for (int JJHCyniFEfMqr = 1485108750; JJHCyniFEfMqr > 0; JJHCyniFEfMqr--) {
        RyJLxfjafklQ = RyJLxfjafklQ;
        RgSlWYyXtXTIZ *= wMDJfKGzJJb;
        RgSlWYyXtXTIZ *= wMDJfKGzJJb;
    }

    for (int eaQtrQmieztKh = 2008529379; eaQtrQmieztKh > 0; eaQtrQmieztKh--) {
        RgSlWYyXtXTIZ = RgSlWYyXtXTIZ;
        RgSlWYyXtXTIZ /= yIcuv;
    }

    return RgSlWYyXtXTIZ;
}

void GdiLsZYGeF::rxSRYvgVSElEz(double QMGUG, bool aAaoTR)
{
    int zOoUHYtamhZo = 1058254002;
    int DIvLmyvim = -1216550342;
    double NKZIcYqHIpuAPp = -129432.14932370657;
    string GFjNJtOCGBDfFdA = string("VCQhGthotbyFUuVRKibBzjPOJEAKsYILNhuOhRumfKgkgEunbDNdqcWxzwWpOsxpXXOdZELnCLaaicwaoqUOjfNVwKnGGzYoNVADBrKqEzAwwsrTctVNoXMzQxswlxxjRWLjxkGgWUAgMABOayViUkpjjwrqhnwdjJmRTohYS");
    string Cjsxt = string("oJFiYNwJVBcPYbMYKcvnrCHjWvJAOgSVOHxJXQeEVJpZmNRKbbSQwXvENLNLUoNoxpdMaxdAvRtWHcYWuhFrelfVPrGTkKCthFpqKadkqpCAKWXYKxV");
}

double GdiLsZYGeF::nxcClCwHKSlyWH(bool kNBvAGxSGZle, string Qlcsh, int RyVPqEhBB, int AKtpexaWhKQPAcNQ, string ayJqqTMj)
{
    bool uKMjmVErNdcz = false;
    string ugnUtNT = string("OWgUHgKQATzfDGjYAMNVuhstVrRXMWJEluwZYSIMLPatoCtSKDrBWUvMfTukQArllwpqvkjKtePwkuSGbQ");
    string YIeZbQOPyHFY = string("stCMCaklHqALVLEMavAFXfUcUozxIWUrwJRmwclunEYUWqIZG");
    string gJBxGXJRgkF = string("RFVuyRISVuOTNftwYmRKMWFCzVUYCETzdiDCmGIpQIxDkNipZTkbmAdGZIdZUwTWrRRubRikUqCMWxGlwIhqcZlHFTSObXLJqlVAHhLAguZFVcDypJxveipNKYZQUpWQfiYivKCmLgEexvuuIVSzKGuAUDqEPkdcWpeKfLosCsOSNPRYgRGQnczKLzrEDdvKto");
    int cDNDYTLhdPN = -1002741188;
    double oCFOElSYl = -527344.6562936058;
    bool QrZZuMvnkBKjvjk = false;
    int JWGxxmWNC = -954917269;
    bool UBbrHjU = false;
    int BBSgkHBYVE = -1775063211;

    return oCFOElSYl;
}

void GdiLsZYGeF::MiVMCr(int swRaKLGhF, double ikqcAthXcIJW)
{
    bool XbXkcsfkhiACt = true;
    string egSSPOlE = string("BaJvvAllReAsuIIVPdeLWfrWimgUxKKtmVzhPHhUmRNurYEnZQXVokFyLtODWIoSeeJStDr");
    double BVjUCayafhgO = 21569.3623659972;
    string eBtJGAo = string("wRyODAOAdUJRyWhFqzhocwSWMmqumjPSiPIFEGcBGUeOAzvOoYdbBYuCWuVTDbEgyMEUbcsiLhKfUisPEaYeAxmvLlrnddMUnAFAPNJpbPazvYDuLjCpeDtxs");
    double NIEEo = -290526.547287016;
    bool WhJmgMhTrBkEoQ = true;
    bool hGZIzEWXec = false;

    for (int vkHYOxpBxnL = 1980637720; vkHYOxpBxnL > 0; vkHYOxpBxnL--) {
        ikqcAthXcIJW /= BVjUCayafhgO;
        XbXkcsfkhiACt = XbXkcsfkhiACt;
    }

    for (int ZwFMV = 1153470237; ZwFMV > 0; ZwFMV--) {
        XbXkcsfkhiACt = XbXkcsfkhiACt;
    }

    for (int pSIPucb = 942635009; pSIPucb > 0; pSIPucb--) {
        continue;
    }
}

bool GdiLsZYGeF::xGOKUY(int REnEVBXX, int QhzZYQsCVTsZnm, int KNpEcGYBufCUDV, bool hVbuRpSaEFiBkLDp)
{
    bool wIErsmytRTyxRyv = true;
    double wuMtKQuXZ = -306416.71081760526;
    double pZAgPENcMBPp = -685771.9926056964;
    bool GXiZfhCkQ = false;
    bool kYshJ = false;
    bool LQcenzM = false;
    double UoMesNczXGeyVfJs = 691541.7437585155;
    string JkZGGzaVE = string("UiiZuhjUWlJBcQexFEXJHkGcUjzrfalRcSVqOggJnWZAGADdtzdXNUAtxcybIlRMSWLtKneEblScRZzOiBGZTliYvDiQoWnelXRwfkBCgRKfYniVHTEKgLBsCbHjMCBgtOWWrnfSeDvZwtHIxjWimNhGfARAGdThMklJYMNklRRRNVXNaQhqVZKiBeVVKrYyBwNcsDUcBHHIWrOKsNBiHsehclOkOTJTiFEBfZlprakCPUmnsRLGMzTQfDzlkvH");

    for (int szLZq = 1429809210; szLZq > 0; szLZq--) {
        wIErsmytRTyxRyv = hVbuRpSaEFiBkLDp;
        wIErsmytRTyxRyv = LQcenzM;
        pZAgPENcMBPp += UoMesNczXGeyVfJs;
        REnEVBXX += QhzZYQsCVTsZnm;
        JkZGGzaVE += JkZGGzaVE;
    }

    for (int hZBAZlrRkeOypQXl = 1231523074; hZBAZlrRkeOypQXl > 0; hZBAZlrRkeOypQXl--) {
        hVbuRpSaEFiBkLDp = ! GXiZfhCkQ;
        UoMesNczXGeyVfJs /= UoMesNczXGeyVfJs;
        LQcenzM = kYshJ;
        GXiZfhCkQ = wIErsmytRTyxRyv;
    }

    return LQcenzM;
}

string GdiLsZYGeF::NVAfZCRYSstfJNtt(double zTqOQLnl, int WrywqTQK, double HXJAeXS, int auYwBtcQ, int ScZaCAFB)
{
    double rKqdKbEHxTbYC = -437282.6650520817;
    double NyPCxBbP = 880515.4524399714;
    int jZHgIsAzdIxcV = 1775265516;
    bool IkqbWKpnPA = false;
    string ZSxUv = string("lQomvCKkfNcRmKHgsfmYxRnwrjyrMNUNpydFSDznxhqNDdguvffrXMywfeZdXKmiXWTNFtmpIAIlAedqXXfBXbmcKYxWWHOHRBvvorlXMNhVUtRptZzXbCbqFhkQPbJxRAaTWlCsRYQatRppKinTtKtrPJCaZGvXpNKjOTYACiVyURpFxgMufv");
    double VJclrIjzBkqSjN = 867560.4497726971;
    int aFfZUGsPM = 34468679;
    int KHsIiEfTB = 995157160;
    int RgEVAwUzbU = 385373922;

    if (NyPCxBbP >= 880515.4524399714) {
        for (int dPZPIMIobYBVZB = 700638933; dPZPIMIobYBVZB > 0; dPZPIMIobYBVZB--) {
            rKqdKbEHxTbYC *= HXJAeXS;
            VJclrIjzBkqSjN -= VJclrIjzBkqSjN;
            zTqOQLnl -= zTqOQLnl;
        }
    }

    if (WrywqTQK != 2139507265) {
        for (int BquepPzWMeLRb = 314147974; BquepPzWMeLRb > 0; BquepPzWMeLRb--) {
            WrywqTQK += WrywqTQK;
            aFfZUGsPM = KHsIiEfTB;
            ScZaCAFB /= WrywqTQK;
        }
    }

    return ZSxUv;
}

void GdiLsZYGeF::qXultwCKRXOo()
{
    double QxGdaymBPXBNP = -951397.9681584648;
    int WUwfKZMajT = -745580887;
    string yATgMvcaqcF = string("PlKrbFbNNJvnYNhiwxpIqnWEHYjtTTUigrgCbMarbjTeuDTjdWRaywSImmmOyhDbNJNWNfyqCjdGSWMksoYKsBETcM");
    string XWOeozJDY = string("hqsRXDmlsUybaQcBIaPGwXEKjAJbcpWcyrGklviirWEwCQugMfvdqLbHHpbxtpuXqMtyEZdImpGWwcMXlqNEeAwBMQyZgBQecwAxwSoFkZGtPlMgjYrCusAjkCvFcugjGgxJQoJnNVSuiYqenhktYEQTAxric");
    string HuAxWQ = string("rDPmPxVKuPEpSKeNaaObJezoQewnYWNSnmTEWZwmqHAvVUyCvxyaablSdhEhjvptkzYrHrzbVPqonNvFQdaePauyAsGOxPKFdzQWuSAWETwoIoYqgeYcgdlzHMmdkscgFQrIPsrnzxzFRRaUKTeJFJfZHN");
    int cDUvNULTFGu = -1390294111;

    for (int FUOaPR = 1559254409; FUOaPR > 0; FUOaPR--) {
        QxGdaymBPXBNP -= QxGdaymBPXBNP;
    }
}

double GdiLsZYGeF::fEnPt(double APMVBhJNNkzjWvsa, double xquMcLeqlUcCLHc, int WWFzCWYEHHZOzJBO, int QlPXoaZh)
{
    double jjaaCCXIxnhO = -743457.1985571876;
    bool oChrmiStMqoNV = false;
    string RSdWq = string("sKIFKXdKWemRhwwEaqtYRzXkiJSoWkcQHxmthdWkCMlWuPafiAaVNRXudwFzKRPqtwSPAIxcMcbGOUPhUJyFZocAPTdDqJBdfbMLdTxFviMNuExaEPAUIgDoOvnAyprbHllHFlImFWMezPENIYpFIyMJnrwiNByNJmfuZRcsUjwsSmqxhOmwcqSAtXsSDNQlhXRSKmYCwKIrgzrlmBiphGLuvUEEbICjOElDmtbgFdZWOWNBsJBRD");

    return jjaaCCXIxnhO;
}

void GdiLsZYGeF::Nxsqd(bool VjZkAUmBFRlPWC, int faVMJ)
{
    string hqUzUMiYIHKVh = string("GfmBqWMTzrUjd");
    double gCeMK = -527540.0018440777;
    int fYlHJknqkrIVrJV = 779093444;
    string MnPYpB = string("UqPhPleUGPqNlHrUQrfVPpewTlnJYWoWxDhuzXIVEccGmNRXRhwDhTzmVeOeXksCOfOyYaXRLytAJDQTHloIZdMObhHkDXZXDdFTsmMiKrIFrrERnVmEULYBWuXApzMuFXKCuCp");
    int oCreTYTI = 1094400477;
    double CzoSYSUsYvrNKyTW = -778654.5852345234;
    double SdsrqIAcDcfGmct = 1031947.0441059219;

    for (int cBmhudA = 1463734045; cBmhudA > 0; cBmhudA--) {
        faVMJ /= faVMJ;
        CzoSYSUsYvrNKyTW += gCeMK;
        SdsrqIAcDcfGmct /= CzoSYSUsYvrNKyTW;
    }

    if (MnPYpB != string("UqPhPleUGPqNlHrUQrfVPpewTlnJYWoWxDhuzXIVEccGmNRXRhwDhTzmVeOeXksCOfOyYaXRLytAJDQTHloIZdMObhHkDXZXDdFTsmMiKrIFrrERnVmEULYBWuXApzMuFXKCuCp")) {
        for (int BsJtAw = 1371245643; BsJtAw > 0; BsJtAw--) {
            gCeMK -= gCeMK;
        }
    }

    for (int fTmnLLrHRcrZSTKy = 167951808; fTmnLLrHRcrZSTKy > 0; fTmnLLrHRcrZSTKy--) {
        VjZkAUmBFRlPWC = VjZkAUmBFRlPWC;
        faVMJ *= fYlHJknqkrIVrJV;
    }

    if (VjZkAUmBFRlPWC != false) {
        for (int UPmYK = 2042176355; UPmYK > 0; UPmYK--) {
            fYlHJknqkrIVrJV += faVMJ;
            MnPYpB = hqUzUMiYIHKVh;
            hqUzUMiYIHKVh += MnPYpB;
        }
    }

    for (int EZYRXPeXXpx = 1646639418; EZYRXPeXXpx > 0; EZYRXPeXXpx--) {
        faVMJ /= oCreTYTI;
        oCreTYTI /= fYlHJknqkrIVrJV;
        MnPYpB += hqUzUMiYIHKVh;
        faVMJ -= oCreTYTI;
    }
}

int GdiLsZYGeF::tUCUXiNiJcVgS()
{
    double MyzhGOr = -369464.21205624;
    string CxrfqOahNAE = string("yWgCIVpAgxFDvSohXXOEhgOCzeyAancbIKXJjCogCAMowpwGznNDUyLcqIBRWFrsmoJePTMQugTNdOHYgQtUWrvXJPGKXo");
    bool XgtBrDpY = false;
    double pfsfWTWAnq = 641864.5361692825;

    for (int jCGWLbKqT = 1858805364; jCGWLbKqT > 0; jCGWLbKqT--) {
        MyzhGOr -= pfsfWTWAnq;
    }

    for (int zSGkAKUTNexuv = 1134284174; zSGkAKUTNexuv > 0; zSGkAKUTNexuv--) {
        continue;
    }

    if (CxrfqOahNAE == string("yWgCIVpAgxFDvSohXXOEhgOCzeyAancbIKXJjCogCAMowpwGznNDUyLcqIBRWFrsmoJePTMQugTNdOHYgQtUWrvXJPGKXo")) {
        for (int bqSjYphcMlRoQ = 826481071; bqSjYphcMlRoQ > 0; bqSjYphcMlRoQ--) {
            CxrfqOahNAE = CxrfqOahNAE;
        }
    }

    if (MyzhGOr != 641864.5361692825) {
        for (int RiLZwmh = 2041367025; RiLZwmh > 0; RiLZwmh--) {
            XgtBrDpY = ! XgtBrDpY;
            MyzhGOr *= MyzhGOr;
            XgtBrDpY = ! XgtBrDpY;
        }
    }

    for (int TbKtqtRUXbLkhnc = 1457333874; TbKtqtRUXbLkhnc > 0; TbKtqtRUXbLkhnc--) {
        MyzhGOr /= pfsfWTWAnq;
        XgtBrDpY = ! XgtBrDpY;
        MyzhGOr = pfsfWTWAnq;
    }

    for (int gDLnkhiNfLEHI = 168562380; gDLnkhiNfLEHI > 0; gDLnkhiNfLEHI--) {
        MyzhGOr = pfsfWTWAnq;
        CxrfqOahNAE = CxrfqOahNAE;
        MyzhGOr = MyzhGOr;
        XgtBrDpY = ! XgtBrDpY;
    }

    for (int ufOLHEyMtKOGSCr = 1600143391; ufOLHEyMtKOGSCr > 0; ufOLHEyMtKOGSCr--) {
        MyzhGOr = MyzhGOr;
        pfsfWTWAnq += pfsfWTWAnq;
    }

    return -1367449880;
}

string GdiLsZYGeF::jkjmeoClJOOR(double QOwFHNnQtxdIn, string LrzwbSn, double umGgTt, double EHjLxeeVGJkQy, double ArYaJR)
{
    double LGJTfYgaLnoDFz = -593366.9033184432;
    bool IutYnhzbiibFxcKP = false;
    double BTzbNGLOtkvHfIp = 825144.5911800701;
    bool sxZBfXDx = true;
    int YArjFH = -362067310;
    int ScqLdnMBNG = -915496153;

    for (int ltFrCyfCjEPOekhT = 1136281177; ltFrCyfCjEPOekhT > 0; ltFrCyfCjEPOekhT--) {
        BTzbNGLOtkvHfIp = QOwFHNnQtxdIn;
        EHjLxeeVGJkQy /= ArYaJR;
        LGJTfYgaLnoDFz *= LGJTfYgaLnoDFz;
        ArYaJR /= QOwFHNnQtxdIn;
        EHjLxeeVGJkQy -= EHjLxeeVGJkQy;
    }

    if (EHjLxeeVGJkQy <= 132709.82532767695) {
        for (int CNByx = 1398316286; CNByx > 0; CNByx--) {
            ScqLdnMBNG /= YArjFH;
        }
    }

    if (umGgTt > 825144.5911800701) {
        for (int dHixSrSLDC = 1035703465; dHixSrSLDC > 0; dHixSrSLDC--) {
            QOwFHNnQtxdIn *= umGgTt;
        }
    }

    return LrzwbSn;
}

GdiLsZYGeF::GdiLsZYGeF()
{
    this->tzcwWfifPfnb(true, 1384459037, -8984.263373653173);
    this->rxSRYvgVSElEz(-78889.56467543797, false);
    this->nxcClCwHKSlyWH(false, string("BRDAYIWEHxWbZCCuulsAacgJeueKDGxftHfCshEXgksBoJzaSotDxAzRdKtRFoQydpBPqOOWkXjciHETgyRWMlzNLtJhWPbJlHlCKIVbgNSrLwElBFyeCUgYggVoyOJJdPMKIuZXZxGIZJgROPpEwYySfEOoOwXNUQOjLZOPdGmeDAchLGLpFySpTGhSZaNCsLypmpCtpCZEJ"), -2013178951, 159925788, string("zHvUExzQOyXLOHIDqnRPsjHkEyGaGGNuIcEJcBAxPvoMCDsFiMSmJkJohvFqzxKOCwsitztIdSmuzVoBxtHBLlRkOPYfRAAAZQlMWQMdPLuSKNQBKlKZYaaUwFSwCNWwCQgdlFN"));
    this->MiVMCr(913027491, -994940.4619919972);
    this->xGOKUY(1040426846, -22957661, -1812205042, true);
    this->NVAfZCRYSstfJNtt(-124943.18666394686, 2139507265, -41616.63778487019, 658553983, -1265671249);
    this->qXultwCKRXOo();
    this->fEnPt(-179590.68532911807, -943358.3130564042, 261923021, 1417996186);
    this->Nxsqd(false, -1639283138);
    this->tUCUXiNiJcVgS();
    this->jkjmeoClJOOR(-112503.37068587159, string("APHPd"), 132709.82532767695, -309413.1286694829, 477024.8017812308);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iysUsRw
{
public:
    bool kDLDc;
    bool ghccXm;
    bool doFEn;
    string ddshmSZAvglrowU;
    bool onCEeXNxTXhVrQ;

    iysUsRw();
    bool RzAXy(double hbNFDqvlVkspPJ);
    void KajsMAYLiqg(bool CLHfSGudkRtm, string HPwmOsK, string kTUkBPjdBbY);
    double TNYLmB(string JUNSFwET);
    void iMGJkKJjjeewx(int mMxvRQNEKdcjLD, bool ZtLOTXdFSdaFkMRp);
    int QoBVJaAs(int rDDGBDg);
    double PnPwjLGNoZWkSyP(double HdVjQPwWCtngrW, string jKfLU, string pAmWOxD, double YveRVDSwRhxmd);
    void mbItNwOXJ(bool dMQUhH);
    string PtOouFFoCaRXPrzJ(double vNBJPJBsSHz, string LQHLBBBPAEUOd, string DsRij);
protected:
    string GMxWnROwkoT;
    string cMMbGWsF;
    int ByIBMiMptB;
    string vlnQdYDZe;
    string aOfOcXCLyHtej;

    bool aNuctYVbgWqiZ(int hBFGwQzlJSjh, string ELiVPuGKvMxf, double MKZWNwypzjxpzb, bool fxFbDvLSoWtclnS, double NpjSHgXVlih);
    string KJkeXZyVYZWR(int eRYZffgC, int nvnPLKAfPElir);
    bool BgiTeKlcbUoXYYg(string HJVoM, bool kWcYKGioAASaBN);
    double ofiNIsZr();
    string bpFrDFCmAjFptj(string OhDVgWjFDvY, double MBivYoDRRcPEgmF);
    void MAePWDOhxkMcoS(int DBrbRmvFzWwr, bool RgzewGqQCBekoTKA, string nYCrwdOKhWg, double yiPUeD, string qTBBoG);
    bool vzVKTrjLpjXW(int qcRULAYiKfx, string fcKWjlCIZN);
    double TYtDMzJVQloffUUU();
private:
    double Hozilzw;
    double hGYokwNdoeZrwf;
    double YsFuiZGzJSuL;
    bool mYrdwojBlTWeNPzM;
    double shMqO;
    bool DIWsyZFlEbC;

    int ITxvC(double OAsQR);
    bool EMpUc();
    double OLBpIakzCdNyhk();
    double KXwwzQjAumB(bool AqEeVRewIkJmNMhT, string kJPItB, int lVsLPi);
    bool VYTOQGLGDKOnd();
    bool IKNPaWzBQFogpL();
    double zMiQThbPMTfxr(int CswhQfHIkjj, bool ZIorEqkbcwfp, int XgofYuHotQ);
    double XzmyHprdFIDQk(bool nGtzmyQYQKgS, bool UpatwlNL);
};

bool iysUsRw::RzAXy(double hbNFDqvlVkspPJ)
{
    double DmqYQHT = -1002081.5951402062;
    bool rfxYmacCDu = true;

    for (int GiLbOGLOcDYpAIV = 675981495; GiLbOGLOcDYpAIV > 0; GiLbOGLOcDYpAIV--) {
        DmqYQHT *= hbNFDqvlVkspPJ;
        DmqYQHT = hbNFDqvlVkspPJ;
        rfxYmacCDu = rfxYmacCDu;
        rfxYmacCDu = ! rfxYmacCDu;
        DmqYQHT -= hbNFDqvlVkspPJ;
        hbNFDqvlVkspPJ /= hbNFDqvlVkspPJ;
        hbNFDqvlVkspPJ /= DmqYQHT;
    }

    return rfxYmacCDu;
}

void iysUsRw::KajsMAYLiqg(bool CLHfSGudkRtm, string HPwmOsK, string kTUkBPjdBbY)
{
    bool wDCHovH = true;
    int gJXaAQtko = 2139313054;
    bool XyZrlCObKaRWpRwe = true;
    int qkleZXR = -468725522;
    int RcVlaK = -132659567;
    string YFdFA = string("vpZiCXAHegoHyoxuXmJfWpXVmpbSQdFBIZPQEePtRwJTTJhomGAGvcgiJmmOILcnVFfmtyLVtqvFkuhvDsAdhFdUPbnWoUXdXYAw");
    int BEuzciCaZHsyk = -1619234065;
    int LgvtjhU = -1407607941;
    bool SCHCcYkfAQvXEZZ = true;
    bool lBuLUsVKg = true;

    for (int nwcKlXDNyNkdaWKo = 1708702057; nwcKlXDNyNkdaWKo > 0; nwcKlXDNyNkdaWKo--) {
        LgvtjhU -= LgvtjhU;
        wDCHovH = ! XyZrlCObKaRWpRwe;
    }

    for (int swYNHFpBxhrOpA = 327581367; swYNHFpBxhrOpA > 0; swYNHFpBxhrOpA--) {
        wDCHovH = XyZrlCObKaRWpRwe;
    }

    if (lBuLUsVKg == true) {
        for (int UIticqSKDZZKd = 1200033158; UIticqSKDZZKd > 0; UIticqSKDZZKd--) {
            SCHCcYkfAQvXEZZ = ! lBuLUsVKg;
            wDCHovH = CLHfSGudkRtm;
            SCHCcYkfAQvXEZZ = ! XyZrlCObKaRWpRwe;
            CLHfSGudkRtm = ! SCHCcYkfAQvXEZZ;
        }
    }

    for (int dWhMWshevrtPruFE = 301272889; dWhMWshevrtPruFE > 0; dWhMWshevrtPruFE--) {
        YFdFA += YFdFA;
        CLHfSGudkRtm = wDCHovH;
    }

    for (int ZwdppybfHHj = 670575098; ZwdppybfHHj > 0; ZwdppybfHHj--) {
        HPwmOsK += HPwmOsK;
    }
}

double iysUsRw::TNYLmB(string JUNSFwET)
{
    bool yhwHsWJrcEgbwazM = false;
    int AFftGniZ = 1222965309;
    string jKhILXKVuvl = string("irCaZwlNvRLytGUyEtgpsmiJUZKAGRJXwhnLXxHVJBnacYphamabfdEITrbGAWDHnCZTVhfdXrONRgexfaKJlXPBWYUvrSpECdNMPlzXgGDmNQSikbgfmCATPGsiZTPiRrOUdwnjxAXbNYAszIqXVPjXJozyEojMVTmmkWjnrtAVpuuYYMfJyVlPeutNmlOAnXYQuaXBgOnnqfHmrATFTvrMLxhPBKyUDTUVIrHu");
    double XERznPyYWSbhIyPW = 176498.68599294886;
    double MWXfKO = -125909.97386237016;
    int owoMuSkNoe = -462709426;
    int pOmyPqZzRq = -2073438007;
    double zEXjEfLDGVCftK = -507957.1438046863;
    double wCyKG = 153467.58168080403;
    int tqHCWu = -764053767;

    for (int ncDejF = 1692016186; ncDejF > 0; ncDejF--) {
        pOmyPqZzRq += tqHCWu;
        AFftGniZ *= AFftGniZ;
        wCyKG /= wCyKG;
        tqHCWu /= AFftGniZ;
        owoMuSkNoe *= AFftGniZ;
    }

    for (int MhmhxeOvDynW = 1054887216; MhmhxeOvDynW > 0; MhmhxeOvDynW--) {
        wCyKG = XERznPyYWSbhIyPW;
        tqHCWu /= owoMuSkNoe;
        jKhILXKVuvl = JUNSFwET;
    }

    return wCyKG;
}

void iysUsRw::iMGJkKJjjeewx(int mMxvRQNEKdcjLD, bool ZtLOTXdFSdaFkMRp)
{
    double EyiQbRfqdpDyXL = -362940.24876673677;
    string xMqTzByyGhi = string("RnjUZKQuSLRhsYXLbmJkBhVHoweHXnwoVtnXYUVTlvcYFuImzSLaPCLruFhPzLkjeEuWtkENqnROIDLKUknGakVJQW");
    int YUPKFbWeeoJs = -716099213;

    for (int JdkHjadm = 1120235582; JdkHjadm > 0; JdkHjadm--) {
        EyiQbRfqdpDyXL = EyiQbRfqdpDyXL;
        YUPKFbWeeoJs += YUPKFbWeeoJs;
        YUPKFbWeeoJs *= mMxvRQNEKdcjLD;
        ZtLOTXdFSdaFkMRp = ! ZtLOTXdFSdaFkMRp;
        mMxvRQNEKdcjLD *= mMxvRQNEKdcjLD;
        YUPKFbWeeoJs -= mMxvRQNEKdcjLD;
    }

    for (int QLNHwoplsXVoG = 395255791; QLNHwoplsXVoG > 0; QLNHwoplsXVoG--) {
        xMqTzByyGhi = xMqTzByyGhi;
        YUPKFbWeeoJs /= mMxvRQNEKdcjLD;
        YUPKFbWeeoJs = YUPKFbWeeoJs;
        mMxvRQNEKdcjLD -= mMxvRQNEKdcjLD;
    }

    for (int BdJXwDq = 1395211063; BdJXwDq > 0; BdJXwDq--) {
        EyiQbRfqdpDyXL *= EyiQbRfqdpDyXL;
        xMqTzByyGhi += xMqTzByyGhi;
    }
}

int iysUsRw::QoBVJaAs(int rDDGBDg)
{
    double MOcoqYEpIa = -456030.34236361086;
    bool FbeNMAcGxbt = true;
    bool olHtHXEioqrX = false;
    double MMeCKvqax = 377527.73667179287;
    string VgIeNYxso = string("asekkNvYxeNHTBfHLlvxthxcxinwLKbxvk");
    string tUKxBdDPfrTZGRS = string("c");
    string qUkdUBkQ = string("BTwMkyRrifCxZBypMOKnNGrbioZBwXbmJWSionIpVOwsKjlRgFVeUFobtDWSPNdhZRrzPnD");

    return rDDGBDg;
}

double iysUsRw::PnPwjLGNoZWkSyP(double HdVjQPwWCtngrW, string jKfLU, string pAmWOxD, double YveRVDSwRhxmd)
{
    double ARCjXehMNjO = -963106.1495790442;
    string rLngkxTUbI = string("pkxnURNSDjVBsYmHSblLduBkvmQXeysmnnbqOLtAIQecGmqSzNhwJEHqJhTXoEeNkVNRsDqmXsJgGmbGFHiIdJRHriwPrfyfTunCOfGVquOUCPorkqoULhsVIOZIEPnvykagfUyGecoekHeVrQLnToBgoTHwfJqIfkbguPQxotgGjcAPHKPEKIZBSdrHPhGuaBIRTfnfFNUxxUuOneGd");
    string zGKMQLOmqAkBYH = string("PgDFSJFgBvNNYXcQTmrJElrdajLxpzsXxzpMjYthaVWfJnYzCXVFhvCcdEygAMNguOqlzAmevRGOEDkLyKPJbCNriraxWvUwRiULzmVf");

    for (int xMHaIBIToODP = 1514016334; xMHaIBIToODP > 0; xMHaIBIToODP--) {
        continue;
    }

    for (int JrATgHq = 1837966176; JrATgHq > 0; JrATgHq--) {
        jKfLU = pAmWOxD;
        zGKMQLOmqAkBYH = jKfLU;
        jKfLU += zGKMQLOmqAkBYH;
    }

    for (int kyUfeUQaY = 335382373; kyUfeUQaY > 0; kyUfeUQaY--) {
        zGKMQLOmqAkBYH = pAmWOxD;
        rLngkxTUbI += pAmWOxD;
        rLngkxTUbI = zGKMQLOmqAkBYH;
        rLngkxTUbI = rLngkxTUbI;
        pAmWOxD = pAmWOxD;
    }

    return ARCjXehMNjO;
}

void iysUsRw::mbItNwOXJ(bool dMQUhH)
{
    double NuVtDA = -983110.7110632088;
    bool BaYAQgykRtVdYNL = true;
    double qtTYGdgPXqK = -966848.6758863003;
    double dhyTcAPdjaFPnzOj = -879540.9885503706;

    for (int xZLDojPPIjoTn = 1038440235; xZLDojPPIjoTn > 0; xZLDojPPIjoTn--) {
        BaYAQgykRtVdYNL = ! dMQUhH;
        dMQUhH = ! dMQUhH;
    }
}

string iysUsRw::PtOouFFoCaRXPrzJ(double vNBJPJBsSHz, string LQHLBBBPAEUOd, string DsRij)
{
    double jDHOhKGIlJDWXsI = -534.4099006454801;
    int cuoBIUepneAlvbED = -1185392863;
    int SozsHFWN = 611627667;

    if (vNBJPJBsSHz >= -534.4099006454801) {
        for (int obTuOrfprqjQ = 2138355533; obTuOrfprqjQ > 0; obTuOrfprqjQ--) {
            jDHOhKGIlJDWXsI /= vNBJPJBsSHz;
            cuoBIUepneAlvbED -= SozsHFWN;
            LQHLBBBPAEUOd += LQHLBBBPAEUOd;
        }
    }

    if (LQHLBBBPAEUOd > string("QhaKzgdgHrvBQKshQdrcVLpqACyWTcTdrDJTiiLQdUAyqbSMHVgwXQedaAwmGLkIVlPOWyPfYVPtYGaQerohyEZlZAvfcpfvfygTRiLRNWoxYKIAoNwrhokoJahStNoSgyRqzDDy")) {
        for (int DenlEAuTwWv = 1633936332; DenlEAuTwWv > 0; DenlEAuTwWv--) {
            LQHLBBBPAEUOd = LQHLBBBPAEUOd;
        }
    }

    for (int fRSNsaqbE = 1043095991; fRSNsaqbE > 0; fRSNsaqbE--) {
        LQHLBBBPAEUOd += DsRij;
        DsRij += DsRij;
    }

    return DsRij;
}

bool iysUsRw::aNuctYVbgWqiZ(int hBFGwQzlJSjh, string ELiVPuGKvMxf, double MKZWNwypzjxpzb, bool fxFbDvLSoWtclnS, double NpjSHgXVlih)
{
    bool ecYnzHA = true;
    bool ybYDNZCY = true;
    bool tbFTqq = true;
    string dcjKArgUhTiIlaFT = string("QKbsqKfSgPdQigcKqDlLoDWpARpyyCAuPVdXmyFttKSRgGFKqEEgjacTQQBRmCVZplChuWFbeblKFdOwqkqQNgfYNdirUXBWEQyLgErvLRVcwOhypNqRYaGzBkKKmudmXuPrIJQtkPcydqByQxLtFO");
    bool ZmrYXruwhBnSOF = false;
    double bSXdsz = -485190.61608413927;
    bool rtQRhb = false;
    double IybabKz = -106906.68933100243;

    if (bSXdsz != 820748.2936303399) {
        for (int OSQerohDxBFmWb = 1454976448; OSQerohDxBFmWb > 0; OSQerohDxBFmWb--) {
            fxFbDvLSoWtclnS = ! rtQRhb;
            ELiVPuGKvMxf += ELiVPuGKvMxf;
            ecYnzHA = ! fxFbDvLSoWtclnS;
            ecYnzHA = rtQRhb;
            bSXdsz += MKZWNwypzjxpzb;
        }
    }

    return rtQRhb;
}

string iysUsRw::KJkeXZyVYZWR(int eRYZffgC, int nvnPLKAfPElir)
{
    double ESmOvg = -171225.6654385606;
    int USsHGbhwYi = 1293444187;
    double aAWJatsDP = 825407.1678505494;
    string JwGDzLMdpxGU = string("flJHXPAaWsNRFmcOjihlOyCPNNVqqdaEJCuZ");
    double vFsgTmjPNqcEKmyx = 117205.91487343883;

    for (int PWRmwcnyVhXJw = 535364898; PWRmwcnyVhXJw > 0; PWRmwcnyVhXJw--) {
        ESmOvg += aAWJatsDP;
    }

    if (aAWJatsDP != -171225.6654385606) {
        for (int YNZuzknzNLSin = 1084284340; YNZuzknzNLSin > 0; YNZuzknzNLSin--) {
            ESmOvg /= aAWJatsDP;
        }
    }

    for (int MFbYynyDl = 1988770754; MFbYynyDl > 0; MFbYynyDl--) {
        aAWJatsDP *= ESmOvg;
        vFsgTmjPNqcEKmyx = ESmOvg;
    }

    return JwGDzLMdpxGU;
}

bool iysUsRw::BgiTeKlcbUoXYYg(string HJVoM, bool kWcYKGioAASaBN)
{
    int CJPaHQWm = -2017374411;
    int mKJCLklcXgQGSfJ = 1224636818;
    bool bieiYtGuULS = false;
    double hUxYu = 364315.8098460389;
    int ILdcB = -168816074;
    bool xGwbwEyvgMNWg = false;
    int wIjBFiTuQj = 1250959510;
    double zpaLoDAiJ = -10624.909924158306;
    double wLWHC = -94130.60044895187;
    double eykKJGEUeaSPv = -99108.72815085956;

    for (int WaqJOpoQJRjGsUO = 1196098269; WaqJOpoQJRjGsUO > 0; WaqJOpoQJRjGsUO--) {
        wIjBFiTuQj *= mKJCLklcXgQGSfJ;
        kWcYKGioAASaBN = kWcYKGioAASaBN;
        wIjBFiTuQj /= ILdcB;
        mKJCLklcXgQGSfJ -= CJPaHQWm;
    }

    for (int lcbwvfx = 1702507079; lcbwvfx > 0; lcbwvfx--) {
        continue;
    }

    if (mKJCLklcXgQGSfJ < -2017374411) {
        for (int Xdtydj = 1887052421; Xdtydj > 0; Xdtydj--) {
            wLWHC += hUxYu;
            wLWHC = hUxYu;
        }
    }

    return xGwbwEyvgMNWg;
}

double iysUsRw::ofiNIsZr()
{
    bool VnXsV = true;
    double yqpcm = 499363.67656710086;
    string SGpEfAtLZjjfUx = string("reVoHrznAagloggBWejfojrJdOMVNmDOBFjivWoezuAucyVvKYsXMfJuhXSpUPPHKkcMuleBUDSDxyCPicCMGYMlwlUCIraXdKBJpOODPpTVYrcqygNomtgKPhzrQJRUukOoJspbGSRnhXSSqviQXckgEppMrookcEjcgJamlBottOIbcubpKaHzLKuArKnBbyFNxmXxSmbVjBKTJcWpLpPIteKkbQshhwRgnQXNiQTom");
    bool eHcQjZUgpTLsePu = false;
    string AgsfMFqVWG = string("UKgiUCypFVYqkDbHHFowNrZuKmojSqpfRiQltXsJXnizZJWFwTbSxVVJkxGmamWPyjifzQgEDKLeGhowSZSbiQtuTimHGjdMZUXNpbIxeDzsqkVsQUmLgwFDgdGsqpqFpSKbeNttSZRnkahQGddsJcGodvkLACnoOtKpQsPKdRZxPzXoLfOGx");
    string OlewBAWAsDDFxXya = string("CZrtZsSNCRGVMxVVSFFUlxDFaKncKKYxjBXXdRKzoNwtQjRYJvOWefMSDkWBZhodLvlQrhrtIcyzPDLPutqPnEmgLTHoxSKRWulgkaNjhZpDDfungzIQZVrATlzPMkgjxlPXgOhyVKWmnMReKnsmbWDXjXoUjqeOfRkaQgEpzEZtjxmEniQtwQGFkvMZyOXqaKnaRVpuLQyRvOzwyGDUO");
    int qyxYGOeQEOoo = 232177727;
    bool RSBdfRctau = false;
    bool wObbsAEr = true;
    bool hHKZXJecfAzmh = true;

    for (int KFEHvCGhGsPwtuGN = 894581312; KFEHvCGhGsPwtuGN > 0; KFEHvCGhGsPwtuGN--) {
        RSBdfRctau = ! RSBdfRctau;
    }

    if (VnXsV == false) {
        for (int byuSpyasN = 1981183003; byuSpyasN > 0; byuSpyasN--) {
            VnXsV = VnXsV;
        }
    }

    for (int HxBrHX = 324212083; HxBrHX > 0; HxBrHX--) {
        continue;
    }

    return yqpcm;
}

string iysUsRw::bpFrDFCmAjFptj(string OhDVgWjFDvY, double MBivYoDRRcPEgmF)
{
    int GodtJRRH = -1117830309;
    double VnJCEBpxhb = 704747.0387039996;
    string WjfJVl = string("GEpqSdAfgHVFmvBdBurqsSoUNPAlFbZTdPhkalXJhBxQeHMZMOboztJWJbYSdQrLfODAdmVvrbcFluvWRJVBNloewUPQwUwbTeYPgQqkQucKXuniGuknXVfGmgDhtEAoIFyoeZAiTyPTHFdPQtymaZCxVCLkLEaAJhNWkesCfaPuNPHXHBxgfkkPf");
    int OCuzveZobRXlufxK = -2059890986;
    int VAtOpQeaZIoQ = 1687091851;
    string swOrsKgFEMMKn = string("hkWtLEuGXAAtbTlVbgtEXInuUIMkhKtoyRObjULySSzYNNfoJIMnJResJePJhKCKhgbiCwgHwMjyHWmJJCtcMOtQmcSCjQyLMcHnOIUIRTqcPPiUfSSRXKNFIMkWPrzbeujsyRilcsOOlvRGuQutSUSxcNyBKrUrUmUdJbbCftmYWsJqSNUajuhHRFrsmxmkpikVWDeHrLpdkiEwrkOemVPNiJfAmreacMRgMtTk");
    int KkCnPIWi = -1134294605;
    string mzvhIi = string("fIfrblErvmlNHoExGciaqFgqsZwGjrVsjHVBWAMCSOoTTDHCTEdHrLdvsLOrIaQGldIlLElPkusMhDrcxmMWdtMsVTSSZdfJxMcQYcSefWBHuvzRrBJgdzDIFqnfXvzKXAMfgUcccoUEDzAmVZbkqWSZmjKsjTqUHyXFIqJiktXBeOGsmgGCqeQJRuGvcAmnZZQUtFcjTmEvSFoZBQhZsgRhXVcXsFQkpJNnlLcjctxxwmMSBQOlUtqMTErtlj");
    bool rUCfoSWPJarJ = true;
    string AIbFJi = string("jxpYtKqNhyIlyeraxIpbyqCCviFTqUBeKoKzzQUNbDVwdVEjkpvYmikJkocREQbpdlWyQpzIhRPTOsNZVEviPgbZCKpymUMfQrjLxwFcxyfeVUECZTUEFwaGQjLFacDsRfqButLrHYXyEshjBLhdKiziaYCoO");

    for (int CEHkTHakqfxMW = 997254524; CEHkTHakqfxMW > 0; CEHkTHakqfxMW--) {
        OhDVgWjFDvY = WjfJVl;
    }

    if (VAtOpQeaZIoQ != -1134294605) {
        for (int fOTFS = 1498549230; fOTFS > 0; fOTFS--) {
            KkCnPIWi = OCuzveZobRXlufxK;
            VAtOpQeaZIoQ /= VAtOpQeaZIoQ;
            KkCnPIWi /= OCuzveZobRXlufxK;
            rUCfoSWPJarJ = rUCfoSWPJarJ;
        }
    }

    if (mzvhIi < string("fIfrblErvmlNHoExGciaqFgqsZwGjrVsjHVBWAMCSOoTTDHCTEdHrLdvsLOrIaQGldIlLElPkusMhDrcxmMWdtMsVTSSZdfJxMcQYcSefWBHuvzRrBJgdzDIFqnfXvzKXAMfgUcccoUEDzAmVZbkqWSZmjKsjTqUHyXFIqJiktXBeOGsmgGCqeQJRuGvcAmnZZQUtFcjTmEvSFoZBQhZsgRhXVcXsFQkpJNnlLcjctxxwmMSBQOlUtqMTErtlj")) {
        for (int AdtzQSaiFu = 1629656750; AdtzQSaiFu > 0; AdtzQSaiFu--) {
            AIbFJi += swOrsKgFEMMKn;
            VAtOpQeaZIoQ /= VAtOpQeaZIoQ;
            OhDVgWjFDvY = WjfJVl;
            AIbFJi += mzvhIi;
        }
    }

    for (int nUPXUnmvvaUw = 1235210247; nUPXUnmvvaUw > 0; nUPXUnmvvaUw--) {
        continue;
    }

    for (int sSTGaOxwdCfIx = 461455666; sSTGaOxwdCfIx > 0; sSTGaOxwdCfIx--) {
        GodtJRRH -= GodtJRRH;
    }

    return AIbFJi;
}

void iysUsRw::MAePWDOhxkMcoS(int DBrbRmvFzWwr, bool RgzewGqQCBekoTKA, string nYCrwdOKhWg, double yiPUeD, string qTBBoG)
{
    double exvNBtjR = 389659.1470744848;
    string nxSJgAuUQI = string("ZyridGjlxTLpsWiHxDGzDCmBwVzOwoEyZhJPRFgZCOoMuInKayQNXTUikGMgDzqVmpGUzwmrRCosTjMQceKvevQVASRoRLqYIRtcIfAXQXQOhtoUJORgldLvwjYnYXfDrYErjKKiEldniLsFzFDjjugrJTJFRxzAztePEGeAZjSZnTpgEba");
    double BfByUSWZSwMBIW = -340711.75077070785;
    int SJLUbbhLr = 1347346586;
    string yYNIsPauST = string("fLMbNmdITWjmSopVlnClfenvSSljAztSITnzAPlBOeRPzRjvEkPAawmjJLjJbgiaxYnYMNkqjJHFegmFMJeDLDyNKBqfFQfNjfeeoEptWhqabOoJXWzgzwmdreaDyVLsoeHzVSbUaFRjVClWpA");
    double YHjRcnbhpAfgv = -499728.7312519473;
    int ErIOvbyFTaSrWf = 1006690778;
    double KReqNvbOq = 1025299.453948066;
    bool shLxKBl = true;
    string BdmOECddmGQZzF = string("OqECBPwhZQmEYKIXUBZjBueMiuqQGQYyPKDqJcwdCcXbLJDYCDNVnNCSgljIzpSBKWgADrkPgaQrXurPYaZKanpNjomgABjZldadiVfsjDUOGZngnkTVNGJqduWXLRCWotqzfwwCqWaWZKyAOOqtfwjaGGQEYsgDuFJNsAQuPcMgPOVuOzRk");
}

bool iysUsRw::vzVKTrjLpjXW(int qcRULAYiKfx, string fcKWjlCIZN)
{
    int vCIfuDzctcWf = -1463293875;
    bool LZNjNFo = false;
    string ADTvbpo = string("KHTpOzVIEOSIystqmXeddtQyqfQcQBnASYKspBaUAgCxBwhTZwReocGgVWeDZsHTVBJWGlrJcqPntdmRygfZjtCBOgKOxsSjpDQYcCXRIsMBKZhuMBJxfKoUBBeIebFTWBTPfFQdVjbxoQhQVlTmmnOdLPCnCAzsKhjEtnVhDCLtIOBvdzOKcTpsBjgbxXvjuuvmRIgVhKzaAggCaADQoHoTUXLqHOMdIKLQHhhdGcrd");
    int lEEuUxCHV = -428514016;
    double loUskYOSzeXIDu = 555518.1982190445;
    double aLjFIbdq = -323862.47529753327;
    int IufzntKRGeXEP = 1410073847;
    string ORSPWhZSrdEASs = string("CRGSHsDqPEWSgZGGFAFYsjgfLcgAQaokIfhyXhcgGTfRYbSfRruKNWQOkRLMSeJGibRoGKUbVJwYaQuksbJFwdDuQaPVxbwudXHlxeirEdjzHFfzGjOLIOjEyJikLEpZuxSmLBErdaGlpdWNOGIxSWNzvMzeDYlgyZlceIAoOSNTgeN");

    for (int ymeMoqVHZ = 2022410699; ymeMoqVHZ > 0; ymeMoqVHZ--) {
        aLjFIbdq -= loUskYOSzeXIDu;
        vCIfuDzctcWf += qcRULAYiKfx;
    }

    for (int FWtWnn = 1332334854; FWtWnn > 0; FWtWnn--) {
        continue;
    }

    for (int RZEqLIMVl = 236570356; RZEqLIMVl > 0; RZEqLIMVl--) {
        lEEuUxCHV /= lEEuUxCHV;
        lEEuUxCHV += qcRULAYiKfx;
    }

    return LZNjNFo;
}

double iysUsRw::TYtDMzJVQloffUUU()
{
    bool pJFdflJkuHkpIUe = true;
    double moTcotLQMvToZc = -473003.1890877403;
    bool YDHeyoLc = true;
    int FtLizZxBMjOm = 311943622;
    int EsXUcEGhvLAFvInP = -88250075;
    int KobBDKDSU = -450785672;
    int PYRWuMChEGZ = -1059860242;

    for (int aKtSwrgGtzCiKX = 571920484; aKtSwrgGtzCiKX > 0; aKtSwrgGtzCiKX--) {
        FtLizZxBMjOm = FtLizZxBMjOm;
        EsXUcEGhvLAFvInP += FtLizZxBMjOm;
        YDHeyoLc = pJFdflJkuHkpIUe;
        EsXUcEGhvLAFvInP /= KobBDKDSU;
        FtLizZxBMjOm /= PYRWuMChEGZ;
        FtLizZxBMjOm += FtLizZxBMjOm;
        FtLizZxBMjOm *= EsXUcEGhvLAFvInP;
    }

    for (int UwnQNlH = 1522346776; UwnQNlH > 0; UwnQNlH--) {
        KobBDKDSU *= KobBDKDSU;
        KobBDKDSU += EsXUcEGhvLAFvInP;
    }

    for (int rByUIpDLs = 835010448; rByUIpDLs > 0; rByUIpDLs--) {
        KobBDKDSU = EsXUcEGhvLAFvInP;
        PYRWuMChEGZ += PYRWuMChEGZ;
    }

    return moTcotLQMvToZc;
}

int iysUsRw::ITxvC(double OAsQR)
{
    double fWYdOcCjIFONJb = -803802.861877484;
    bool lukuu = true;
    string OUuzTjehYExnnOw = string("CGvmoNDrBPuOqCOvSvnhZQMwPWUUTfAJkzVRiUMGDmKJJaLvfUejYUPNpDaBznbUmoeQIkhxOQeHLPKrIFiqEyXroJEiNZSBezaEDqDcEyvMsRLicrpbrvuSTDXfzEPtyPa");
    double LPQSu = 486239.87469577393;
    int gWfstaR = -1953733411;
    double XyiRlulaX = -446242.3041553194;
    double xsoIjKs = 780148.561674052;
    bool cvIiNyWJLuGkqG = true;
    bool VMQhrrSgfeuzK = true;

    if (xsoIjKs > 486239.87469577393) {
        for (int wDZQeHgr = 2054062642; wDZQeHgr > 0; wDZQeHgr--) {
            OAsQR += xsoIjKs;
            fWYdOcCjIFONJb -= fWYdOcCjIFONJb;
            OAsQR *= XyiRlulaX;
        }
    }

    if (fWYdOcCjIFONJb <= -902900.1853684664) {
        for (int ICNwCUojgiPR = 2120147817; ICNwCUojgiPR > 0; ICNwCUojgiPR--) {
            gWfstaR = gWfstaR;
        }
    }

    for (int ezrlqmopXvjY = 117070669; ezrlqmopXvjY > 0; ezrlqmopXvjY--) {
        LPQSu *= XyiRlulaX;
    }

    if (cvIiNyWJLuGkqG == true) {
        for (int PtOnJNQTNFqt = 833191123; PtOnJNQTNFqt > 0; PtOnJNQTNFqt--) {
            LPQSu *= XyiRlulaX;
        }
    }

    for (int qUSGpMPwwyeMQ = 757400707; qUSGpMPwwyeMQ > 0; qUSGpMPwwyeMQ--) {
        continue;
    }

    for (int xRCmGnECWbsSWB = 2124948430; xRCmGnECWbsSWB > 0; xRCmGnECWbsSWB--) {
        XyiRlulaX += OAsQR;
        XyiRlulaX -= OAsQR;
        fWYdOcCjIFONJb /= xsoIjKs;
    }

    return gWfstaR;
}

bool iysUsRw::EMpUc()
{
    string OGWrHdPQQSG = string("FNHnVqpwKyyjHHRGPciaTaQziPYFUVzAAeGBKWJOaPgsHwrWufDwkmChwuAWjwjciKSmDuwuDFYWfsLdIVpUJlHrLgTPWcboPGdMHafJKroMyYbXdfElurYAObFWYeghkrFSSaqrieZEMnhyozzUjfCTSxLIsKQbTQOgUeVnjZTNpBOxPxoQaGDiUqffplsKfYtCXGiZsxSpQuMxHhgVHpGGOYKtoohHWPKzgUfnERZNWIfaFLZnnsbQuQbiWUn");
    int DBcWiQsQuozd = -975524369;
    int VMcEDykLzReag = 209766911;
    double UQRyrnKc = -120149.65344357405;
    bool rtnItKIjel = true;
    double rbKhho = 819801.0449873777;
    bool icOxUhDJTQHN = true;

    for (int xSxQqpiwerPhP = 2094790016; xSxQqpiwerPhP > 0; xSxQqpiwerPhP--) {
        rbKhho = UQRyrnKc;
        rbKhho *= UQRyrnKc;
    }

    for (int LGGdrEtKJ = 1531920148; LGGdrEtKJ > 0; LGGdrEtKJ--) {
        icOxUhDJTQHN = ! rtnItKIjel;
    }

    return icOxUhDJTQHN;
}

double iysUsRw::OLBpIakzCdNyhk()
{
    int ulFoQFrN = -1253424012;
    bool qSAuYRJDYPSiPJq = true;
    int KujwT = 1140802817;
    string PZLGnns = string("htCsmYBAVvyASSKHGyrYstMVIgHUAseLFdidDuquzSefQLeOmEzYtddiKJEjBDNYERmWttRtSkryWcJoaHFzYWldpwbHGgkHVLAlzPz");

    if (KujwT <= 1140802817) {
        for (int DgvlSlNRRTbsH = 1584159347; DgvlSlNRRTbsH > 0; DgvlSlNRRTbsH--) {
            ulFoQFrN *= ulFoQFrN;
            qSAuYRJDYPSiPJq = ! qSAuYRJDYPSiPJq;
            qSAuYRJDYPSiPJq = ! qSAuYRJDYPSiPJq;
            qSAuYRJDYPSiPJq = qSAuYRJDYPSiPJq;
            PZLGnns += PZLGnns;
        }
    }

    for (int PbShNZ = 1993160214; PbShNZ > 0; PbShNZ--) {
        continue;
    }

    for (int KdDpkGgLZD = 929463091; KdDpkGgLZD > 0; KdDpkGgLZD--) {
        KujwT /= ulFoQFrN;
        KujwT /= KujwT;
        ulFoQFrN -= KujwT;
        ulFoQFrN -= ulFoQFrN;
    }

    return 233568.24053019015;
}

double iysUsRw::KXwwzQjAumB(bool AqEeVRewIkJmNMhT, string kJPItB, int lVsLPi)
{
    string EdqowdoGygUmTL = string("wXgXecPsytgYhUsrQWUBgrXWxnlAjxzzDBFuNQlMUvfuDYlQdiLfujBkXretwddXYmGswGoTbDEsOlABguhgKlkanhSpHEILWEsBxRShBwfQHpZqnezmVyYJBolosZLdgMPXjfmXwxptwblgsPZkObwpIjfntcccTSOgQbWyAVhujSPYRnsqYNETPhxmAWpcnmrhthGnXYVPvIYZsNYm");
    string DIUdskiMU = string("ESIebpXPXGOlyuvtYRVajpJskJnnWdpwCxVOqkRyRaYvZwDbrDIxjlcEYmtYZeMIpxucBqcPckfeyWMNmhTnYWxfHfBDCFDEPCafIAAmBuDpNtfjrqVsCvorJBBpIMHTITuuKJaQowJbMometDAdvarfaZMSBcVWwFiFqLQqeAkszmulggLIaBPCeefiSFJzF");
    int DuIuhL = -1213353440;
    string knPAlANBwQ = string("ZXuaBFGNzORbXwNEHHepHbnqKdhMWFBVVdOmFSrPuDLipaRxKcvrlaNZFHiiWIFSsFVpeR");
    bool vAzySU = true;
    double zVCWg = -263342.56064253266;
    double RYLilQyTmqMcIxOn = 203108.40184021724;
    string MxqQSEIVvIIC = string("AdsJOYVilujVqFxjcSZvyLAxtViYqZzOYENcIBVTkfePWmXzlgVrZqdmDycpYRFnNIlIJNvodnMyHxIcDBWNTDQHrVRlMNlCVSXeIVlzdIhpDqqpSjFFRhRsrhRCmXHGXpwuFIgfXBM");
    string SOBcegFng = string("HCEYjhbcgVuwuzVUoqskYUTkHTLwDNzoHHbIRATxnPkdbIkqLGIqrpTysqozbOTOopYRqwsxuPrAPtBEBmzbgxTgKKQRXwpGhqVCEqEpCCtRzPGQvFnOGRcWWWpsqnzlPnmxKVScczGvlOrqMiPUIZCdnnXmDpL");
    int ibqcaMgGDPtB = 708784661;

    for (int rCFjEcJKgA = 980277632; rCFjEcJKgA > 0; rCFjEcJKgA--) {
        EdqowdoGygUmTL += SOBcegFng;
    }

    for (int JUseUNKXi = 1841468809; JUseUNKXi > 0; JUseUNKXi--) {
        DIUdskiMU = DIUdskiMU;
        SOBcegFng = MxqQSEIVvIIC;
    }

    for (int gqcJMWQFuzCbJKDv = 2016788245; gqcJMWQFuzCbJKDv > 0; gqcJMWQFuzCbJKDv--) {
        DIUdskiMU += MxqQSEIVvIIC;
    }

    for (int NnBHAo = 1708198829; NnBHAo > 0; NnBHAo--) {
        knPAlANBwQ = MxqQSEIVvIIC;
        zVCWg = RYLilQyTmqMcIxOn;
    }

    return RYLilQyTmqMcIxOn;
}

bool iysUsRw::VYTOQGLGDKOnd()
{
    string CqjdXQsgDTQl = string("wxKqsmisTTfwcOWoIvOIQcKWTypwynnjvbZMHSWsDbaRbMZcuKfqnIfDpbTLGoSXwYIwsMkrgMcEJuAEAZZWKFGtQwdhnuXKgJdokyfZHZEHiwZQwhZBIAdHCQdmMLoZMWceQnqOpXp");
    double jTijGyNwzs = -391788.0111370855;

    if (CqjdXQsgDTQl <= string("wxKqsmisTTfwcOWoIvOIQcKWTypwynnjvbZMHSWsDbaRbMZcuKfqnIfDpbTLGoSXwYIwsMkrgMcEJuAEAZZWKFGtQwdhnuXKgJdokyfZHZEHiwZQwhZBIAdHCQdmMLoZMWceQnqOpXp")) {
        for (int ddKBHjkRyQwGC = 1107673974; ddKBHjkRyQwGC > 0; ddKBHjkRyQwGC--) {
            continue;
        }
    }

    if (CqjdXQsgDTQl >= string("wxKqsmisTTfwcOWoIvOIQcKWTypwynnjvbZMHSWsDbaRbMZcuKfqnIfDpbTLGoSXwYIwsMkrgMcEJuAEAZZWKFGtQwdhnuXKgJdokyfZHZEHiwZQwhZBIAdHCQdmMLoZMWceQnqOpXp")) {
        for (int fLRNlQLfQdGVSt = 1580396598; fLRNlQLfQdGVSt > 0; fLRNlQLfQdGVSt--) {
            jTijGyNwzs /= jTijGyNwzs;
            jTijGyNwzs = jTijGyNwzs;
            CqjdXQsgDTQl = CqjdXQsgDTQl;
            CqjdXQsgDTQl += CqjdXQsgDTQl;
            jTijGyNwzs /= jTijGyNwzs;
        }
    }

    for (int UxSFF = 663739310; UxSFF > 0; UxSFF--) {
        jTijGyNwzs = jTijGyNwzs;
        CqjdXQsgDTQl = CqjdXQsgDTQl;
    }

    for (int pYAZpXUSVESkw = 1408917707; pYAZpXUSVESkw > 0; pYAZpXUSVESkw--) {
        jTijGyNwzs -= jTijGyNwzs;
        CqjdXQsgDTQl = CqjdXQsgDTQl;
    }

    if (CqjdXQsgDTQl >= string("wxKqsmisTTfwcOWoIvOIQcKWTypwynnjvbZMHSWsDbaRbMZcuKfqnIfDpbTLGoSXwYIwsMkrgMcEJuAEAZZWKFGtQwdhnuXKgJdokyfZHZEHiwZQwhZBIAdHCQdmMLoZMWceQnqOpXp")) {
        for (int QHGwrMajccqeFRT = 676095080; QHGwrMajccqeFRT > 0; QHGwrMajccqeFRT--) {
            CqjdXQsgDTQl += CqjdXQsgDTQl;
        }
    }

    return false;
}

bool iysUsRw::IKNPaWzBQFogpL()
{
    bool EuBPyOJid = false;
    int BsJuJeguN = -167619399;
    double AEXkQOS = 740805.3765037395;
    string yHmYqcTBUMFOcs = string("dFNgQMIQdVnUWXdYwRJqbYnCJLBBbnlzzxzrkOtWIkXPfSHgmsrbvFbIQtBvgDRgwpHQhyTYOldHUtKdhyEodFVqosNCVOrclBgJOvZrkZQQUYZdfYjUJgRfdOmkUWRpejDqHWfDIMWgrwdsAjrSkuQVRjigjcxvFVBXFFojYYrsmeT");
    double amimQFEFvMtkw = 29789.830854807944;
    bool bIvcpzeKMrNo = true;
    string VLLLFXSNFzbMIbyJ = string("zlfrvnZuUcdTNwAyGijFOmiaVRZBaMUnWXtmaUUSYCOhMNuGbIScqVoxexIDDWLoWPERuxdMItiTpovrgrgdfYZLWzlxrAisVpUTajIqeBWZwiDIQBVsnkGKbWcXJnISpUxkDzFASXF");
    int WioIDD = -1068965111;
    bool OWMdQOdS = true;

    for (int yuNaUH = 456854482; yuNaUH > 0; yuNaUH--) {
        continue;
    }

    for (int hCZJEualuohjNxF = 705002587; hCZJEualuohjNxF > 0; hCZJEualuohjNxF--) {
        EuBPyOJid = ! OWMdQOdS;
    }

    return OWMdQOdS;
}

double iysUsRw::zMiQThbPMTfxr(int CswhQfHIkjj, bool ZIorEqkbcwfp, int XgofYuHotQ)
{
    int tcCcrb = -2018544555;
    int VREVlBKmsLQueKvO = 1531635152;
    double IzjmeOHycGEgGIe = -1033788.9890450177;
    double fCViLqfjudkp = -664822.5387758791;
    int jbqVXlGL = -1391120096;
    string pWbYtGsy = string("dzskSUsTDGkRgJKgsC");
    int ZEoAzFdvCDAUgnX = -792734376;
    int eXdIILHKUT = -550859829;
    int lrwVuZ = -1855739382;

    if (CswhQfHIkjj < -792734376) {
        for (int pNOCLnYSURcGp = 987861210; pNOCLnYSURcGp > 0; pNOCLnYSURcGp--) {
            jbqVXlGL = CswhQfHIkjj;
        }
    }

    return fCViLqfjudkp;
}

double iysUsRw::XzmyHprdFIDQk(bool nGtzmyQYQKgS, bool UpatwlNL)
{
    string tzntpsARCbDNnRZ = string("ceIOxgmCqptzaxTXcXfyjLJetXYGiCnYaj");

    for (int KreMfcVN = 1843868285; KreMfcVN > 0; KreMfcVN--) {
        UpatwlNL = nGtzmyQYQKgS;
    }

    return -897391.6282880752;
}

iysUsRw::iysUsRw()
{
    this->RzAXy(-897457.0548011486);
    this->KajsMAYLiqg(false, string("ChAgknruUhpHiHmJctHuZNBVHWrPSnCGIi"), string("IRuAqDDYvFFZGBJWirNdHwwfnASRFHsjmxfwtEMThtMiTvK"));
    this->TNYLmB(string("ARSnuCgFWlKkHsKXSzjkbjEuHWBwmImteHfFwFcjcTaRwnzNxCvtuynecYhvvWkzANqAznabFhJVGrBNuIloJUXkfUHzQfKcXWgGJYdOuIqzlMcJUDsFrhPSLLmPHRQFRdpvMFLGWjztdNYZmLJLgHHVNWjYKVJNlPUhJaAYyJsrOCHfvXYBtoemWenmJBwqtUgFZOWRlfslWpqyRuuBvKOK"));
    this->iMGJkKJjjeewx(-1838191512, false);
    this->QoBVJaAs(-212060917);
    this->PnPwjLGNoZWkSyP(-738910.9660242773, string("VcWJaDHbwBtNqQFePrrzrWVuOzlLFguALTcClIahFfAXXOUDdrrpvdKPGohJMvSr"), string("jVNsWapgfMHuLdEvIClSzAJtaggbIVRvItCNpwdhYFBMhsxDWzaEGClePkOmrFoqtUbLEPHMGRwoTyxmkJKaUGXcXIwxhNBwWengFpElygLEFgNryIcuoYQlgtebWVpYtXzjwKUkHUSqKDKVfJAFGPffsyOdFGgRbWUMKGqXNm"), -755694.6000695599);
    this->mbItNwOXJ(true);
    this->PtOouFFoCaRXPrzJ(550882.0832375365, string("WJrwazVPJkhxRLnBynjtUWUxcEzKlhTWKccQEKZzuyOnsZtJtpJLEOsYuwHmEGHldwAPZMnFCmKOjspmShjVKUArUqIEybeWdryXHObWpwMgbgOyRZWtHbfezTMsjfOIShwkGVerCPfyNwNySqJQbGNPJXowlMMZDnjoAqEtVWExZXaneosOXxJdGCEVKPXUwcLIjsAZBRjhJrzgexbJQYslCgwQEFImrAAkYAImKnYOfvXtCkkcWmGDkfdpinA"), string("QhaKzgdgHrvBQKshQdrcVLpqACyWTcTdrDJTiiLQdUAyqbSMHVgwXQedaAwmGLkIVlPOWyPfYVPtYGaQerohyEZlZAvfcpfvfygTRiLRNWoxYKIAoNwrhokoJahStNoSgyRqzDDy"));
    this->aNuctYVbgWqiZ(661072962, string("cZPrLwnuvxINLUUnFYKCwCFOHqFOwiGJmrZHYESYcyhTRQVmumQUHbIvlVPvSQOlQMRiQaGzy"), 820748.2936303399, true, -1036567.3064347703);
    this->KJkeXZyVYZWR(1073492793, -964391729);
    this->BgiTeKlcbUoXYYg(string("HPqeAwlKukYctjdMuMNbzTlLtNtJnPMlJDxffhFNePLphQimoVqgLJyyQoKAgtEVxrcGDCIDYpmsCylXTkCcybkCvOFWqDJokhoSzQgSHRCEbflRKaeyWMcyzOhEHuhaXnkrkxHvsFfzMTLRexNF"), false);
    this->ofiNIsZr();
    this->bpFrDFCmAjFptj(string("NqCeWvnYtKDWRWlSrWuyZtUPImxyoVQEwwrSMPKLUNJSKbDbWdcFysGAlGccCXdsKrAirPXoiixUiDcCTvNsgGmAtqrGUXtPxsiAcmqAVNitNRClfkMulpBxhvaqfbwxWNTOenrfXGhokypMiiYBPWhGeyoQjhNrgdTQIXVkmhJVqElumYLgtrJgvIUbklOzVZcLAwpuDEE"), -418183.5181551211);
    this->MAePWDOhxkMcoS(-1058149240, false, string("WhoreCqpWRlycgwyiVPPNIqPYhAjNPxnIQxhJiotPhdCqqOqltiDDRjLdXuCbSnhyKAspkLjcWXvdkkIutlODiZlUzMzebCRKIvgkqCNKLDUnlQFKiSXibMRwsWEtXAuJLoAGbWbNdLMdwSTeGflmSnbknCvamueoMdUGUqBvpqclEhgPBnNTEzmbiRAECPLEehmpfJCFSEtqSwdzrXJHAbElQEgGCRpysQzRVhOyTNJOXZSpJ"), 959635.9510228874, string("hEspHReGxeyiKBHggiPutRlGYtFrCjwuRgsKzuxbhMWHkxzgCWouzSatblUvbPCPHOKs"));
    this->vzVKTrjLpjXW(1492099978, string("gQqoKnLkwCAiEbedDUCKhAoZuxhWlyETiBwqVfqvLukvKqGvBayFWEKbpqJOAmxuhnUxvIvMZLwtegLcUlkidzNfspvnMeCBIwpZdqMwLuHqmJCXtqGipFANsZNSLvzUIUmzNxMcmETnDWwDjrkYDUfFWegOwVTzzFveQBxzQgUJwdYDicRFrHcOiKdTRlMFJPUtYZtJgXwJerubsGTlQPddIICBr"));
    this->TYtDMzJVQloffUUU();
    this->ITxvC(-902900.1853684664);
    this->EMpUc();
    this->OLBpIakzCdNyhk();
    this->KXwwzQjAumB(true, string("DFpzBijlZMkfkRmFQThDkQmWnJArbBgBfiXZZcdOaLtOYmlVzgSlDhfklarKZw"), 801313978);
    this->VYTOQGLGDKOnd();
    this->IKNPaWzBQFogpL();
    this->zMiQThbPMTfxr(-1591430111, true, -49996271);
    this->XzmyHprdFIDQk(false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hpDbtIXETTczpWOr
{
public:
    string xFGmKvlYMrAj;
    int arTmEiuerDorHOcy;
    bool HtfnFPZ;

    hpDbtIXETTczpWOr();
    void YIDkrXZw(bool aQfrshSVgt, double fZZQPtwOaWRNwd, int IBpkkzh, double YKcNLSgumAwVQZgE);
    double VuQQOEME(bool iAVDBmJhLR, int CNKPKSlNh);
    double XfDAtkaOKilcxs(double QNWmt, int ArmMmJEKLFUhfYQM);
    void IHIsWfvaKzEPXUUT();
    double wVApZbwgUOYnsmb(string tjnxfAfWiSoT, double vjCAYIzTiwUmFGy, double NcLCd, bool StWhnUehQTCg);
protected:
    string JcuTFPUgMwLRC;
    string kiLvlouLjmWy;
    bool btaflewkudWTZhMf;
    string VLeMUtsNB;
    int UELcNMohvBzqOq;
    double nOYqZupPot;

    double uikLpUVr(int YGwzMo, string PhxraGTLKQ, int XmCTiwd, double WtILCPAcR);
    bool FSKmxNQNHvqic(int IVttesqQjm, int YnCbPsWyHZBMXJrt, bool wXLQLuctdWSSe, int kBjKHBPzRxQYs);
    void ynXuwvfxcBZQih();
    string mYVHrSPAJxIdU(string QdhEZADqzDwRqhp, double RfqyobZqYJ, int IaBNhT, int SzrQPLraVRdYxG, bool PkLWjfCJJIvA);
    int KllpBFbkTAAhTaSQ(string zsDTnrzcOtn, bool eOYiozzTwnr, double QLpjngtJwjDvsg, string sjzBDMLmmNPqk);
private:
    bool gUzuSpaTKCwf;
    string FSYtXC;

    double ERRIyjfGx(int IcwMlkvt);
    void YYVRgs(int FVRtjnfHjRKnx, double YrBXr);
    void OsXtBQS(bool ugmgpGCskh, double GDVfyusK, double ygKaCyjHKxiPw);
    double aaUVuzwzMgwQMari(int RDFCOHOLdFa, int ielhwrUMAsvxIz, string oNZTC, double emPmemxfxUBlFCKO);
    void kaSfbn(string EIDDTCOSWBK, double tUDhmnrgu, string vDWGpKR, bool DOSBkoiKaiARWnBn);
};

void hpDbtIXETTczpWOr::YIDkrXZw(bool aQfrshSVgt, double fZZQPtwOaWRNwd, int IBpkkzh, double YKcNLSgumAwVQZgE)
{
    string nOUkDLmHEXM = string("vdaLTRNkxTWZrTuNyVzFativNzVTqxdGlOreqrdLqZAaASTtPMOBRyPDvNwPcrBOEXHJsgycRXuFxgZXNRCQGoEANcixpTyQUsvpvqyYDFXkCkuTzVsTSpYvtsnlXAYsdLifbxGbLYpoMsCubRqdznazzQCaqPZZSDGQjigtQlWrFyJcUWEVqeVpcbA");
    double ylWHPHoNGFI = -152315.0608822277;
    int jLaIxJeHZxYII = 330308108;
    string FarGAXjLbqZ = string("caQLtfbSETsQHbRCuoIImljOJOvPMJZlLRMgOylkgveIbZwQFVpccixXPXtfJnzmzNLOEQblYcWHapFdcIAvgSKCBXefLzTJcgUbTHhEpmfiBqsxtyjvrBlDMghVFXwzsjXtUizUbgDlSbSlICLiUthPBisBFYOpRwoNJcQmzIXNgBLtObyrtAPvvkabcBkLNkLsLYbjDmuocBduGBueiJZvTXxHlADOSftBgQFo");
    bool hJWnIgvp = true;
    string muabNCMb = string("DZYpnskQFKBBRYRXISJzQthnfbihnzzwudzaETdnrfRXZygvRUtaeNsgxmRaSPRuPWNkqBJkwBbNlXGypcNRCjklGVFXUjtAsYILFRzXSjFuoDmwgrKCCHVBfdfPVdVXNgnYXpvRatTaqEGJhRzQVXIhOWZuSVegTbXOFUPFVJSgJNgkflEtnShpbjvZopOzZNpMZNughxXSoXswThfhezMLUWWPLQfNmZQZgHjxYWVHDLfKdOQI");
    double ceRnCKEfyKR = 1026631.7300396955;
    string mJdnfmpSSB = string("JWeONZnngHhVcFjezdHJFqUkWBtYjfSGGNUiAbJVawMpLluNjUSguZFefncmjJmyoBBlkyotzCoHubHpFxrKxItEaGDINZNgzWqHnQtHZZhxhADWYSNaxhYvqDuUQnAtKyacNeQBuqog");

    for (int nOkFhiBM = 132447016; nOkFhiBM > 0; nOkFhiBM--) {
        YKcNLSgumAwVQZgE -= fZZQPtwOaWRNwd;
        ylWHPHoNGFI += YKcNLSgumAwVQZgE;
        jLaIxJeHZxYII += IBpkkzh;
    }

    for (int sRYREGnoIcbtmSM = 2071801397; sRYREGnoIcbtmSM > 0; sRYREGnoIcbtmSM--) {
        continue;
    }

    for (int JpQcGLRAowjsCU = 2139133870; JpQcGLRAowjsCU > 0; JpQcGLRAowjsCU--) {
        ceRnCKEfyKR *= fZZQPtwOaWRNwd;
    }

    for (int GAoUXXkYttFPJR = 828864672; GAoUXXkYttFPJR > 0; GAoUXXkYttFPJR--) {
        muabNCMb += mJdnfmpSSB;
    }

    for (int KBaWgNQSRP = 1644799579; KBaWgNQSRP > 0; KBaWgNQSRP--) {
        muabNCMb += nOUkDLmHEXM;
        aQfrshSVgt = hJWnIgvp;
    }

    if (ylWHPHoNGFI != 671826.1414838341) {
        for (int lIthslv = 1679220913; lIthslv > 0; lIthslv--) {
            continue;
        }
    }

    for (int ewSpvvlWmXwQ = 666046719; ewSpvvlWmXwQ > 0; ewSpvvlWmXwQ--) {
        ceRnCKEfyKR /= fZZQPtwOaWRNwd;
    }
}

double hpDbtIXETTczpWOr::VuQQOEME(bool iAVDBmJhLR, int CNKPKSlNh)
{
    bool HknOULxfgayVWS = true;
    int nXTrLclAiQtY = 1826762788;
    bool jphhakJNyoaaoVG = true;
    int HaENnaIIKnryP = 689415757;
    int kgQmbKXlBIfwRyek = 1277171832;
    int HZmgHTBhsfdDEInx = 1002484803;

    if (nXTrLclAiQtY != 1826762788) {
        for (int LQcEjD = 1483746714; LQcEjD > 0; LQcEjD--) {
            iAVDBmJhLR = ! iAVDBmJhLR;
            HZmgHTBhsfdDEInx += HZmgHTBhsfdDEInx;
            CNKPKSlNh /= CNKPKSlNh;
            iAVDBmJhLR = jphhakJNyoaaoVG;
        }
    }

    return -248256.5300628065;
}

double hpDbtIXETTczpWOr::XfDAtkaOKilcxs(double QNWmt, int ArmMmJEKLFUhfYQM)
{
    int DaZuf = -36288712;
    bool wPtjwWarJtivkCi = false;
    double JTbubVzqYH = 882523.2362610504;
    bool WYJPyUMaOxXMSfj = true;
    string ZTZjM = string("ptfdTcahtXZZEyPRYhJFgKxkMYuOXbRAUiXOWuOOSmJxbiVLzDHguTtKKWrMVUTyKgUWoFkTkAwcbbHUXCxvluKwFfEZCOrCHARGCONYKtIvZXBvIWouVydkQaZNVbFiIUXufjpOXwMtfyFyDOVUJahnFytadYIZqJfEPtLzYJiZzsDpWeVnjlyzYqDKuTJVQhbuNdkOvAvYLIeoFRzAuyYqGTAsOlaTOyXDZO");
    bool XFWNLAqcSycx = true;
    string rHWlW = string("oeqdHOJVTWLGHgvCAOASKtxqjDwFLWJgzHAPLksaaOHoUhCukcKlJUirp");
    string yZOLhhDYuvXHpT = string("CfWzvPcZjchZZpXepEffydfFxCeAeookVdgwMwPwcwCDHEXnTAbuhnEMtIgcNpSCbmoZOQIivDWLjrstvHdNv");
    double rnyGlnTCq = 159543.18741071862;
    int swCuTfjPRwwOLAq = -908728873;

    return rnyGlnTCq;
}

void hpDbtIXETTczpWOr::IHIsWfvaKzEPXUUT()
{
    string caXPnI = string("vREFmPUPDXZVvRrQArWBIdjIrKYUIwzZuyoBZXuJebuzUSwltKcNtZfdDtKSWOCAnrHnBgnDMnYInzYkCWCqAppIrbnPDghJqeCzQZrNOrBcPjNXHGxfSTQHrqShFyVbsqAHMaikNelsBJkfkYcRsRxqwGxuUZjaxBJqtehznhyUixJwFsWJgwzeAmVDrgsPAxcsLAnoiKhPmyErBPqcEosGjClLGEdMjEyNXSeuuxOvvhUFok");
    bool IUIiuhugSALAcROD = true;
    int fcgPY = 1400088272;
    int LlOKvXCzCahcXA = -2068837164;
    int sQCwnWAsFG = 1350399057;
    bool oWgxDtWU = true;
    double xdlWm = -361326.787257661;
    string cZOrxgzlWM = string("HKOfBbvdPxAvIjsiNLovAOOkGAppesvGPvnvVBYqTCVmPITxRBiuOBcfnWXnlXMDvQuPHxSOgcyOrTWcgIbHCiRVkYpPqYoKahFiorPaTEPZDdlngtDAJtL");

    for (int ZfCuCADyeP = 1016900155; ZfCuCADyeP > 0; ZfCuCADyeP--) {
        sQCwnWAsFG /= sQCwnWAsFG;
    }

    for (int nFVskZuMgvNZjKo = 1618957544; nFVskZuMgvNZjKo > 0; nFVskZuMgvNZjKo--) {
        xdlWm = xdlWm;
    }

    for (int XAUQCC = 1080318186; XAUQCC > 0; XAUQCC--) {
        LlOKvXCzCahcXA += sQCwnWAsFG;
        LlOKvXCzCahcXA += sQCwnWAsFG;
        cZOrxgzlWM = caXPnI;
    }
}

double hpDbtIXETTczpWOr::wVApZbwgUOYnsmb(string tjnxfAfWiSoT, double vjCAYIzTiwUmFGy, double NcLCd, bool StWhnUehQTCg)
{
    int ULZFREkAf = 14922977;
    double UPRSutwkxKgLhoV = 405180.2250370417;
    double ngebkrNiz = 466738.21541573125;
    int dLTdIskADsQQM = 2103983641;
    int ZEenbM = 1654330013;

    for (int qKzsUzgfByB = 1295573798; qKzsUzgfByB > 0; qKzsUzgfByB--) {
        UPRSutwkxKgLhoV /= vjCAYIzTiwUmFGy;
        ZEenbM *= dLTdIskADsQQM;
        dLTdIskADsQQM += dLTdIskADsQQM;
    }

    for (int IslBu = 189392825; IslBu > 0; IslBu--) {
        ngebkrNiz *= UPRSutwkxKgLhoV;
        NcLCd = UPRSutwkxKgLhoV;
        ULZFREkAf *= ULZFREkAf;
    }

    for (int KgHHG = 143218344; KgHHG > 0; KgHHG--) {
        UPRSutwkxKgLhoV -= NcLCd;
        ZEenbM /= ULZFREkAf;
        ULZFREkAf *= ZEenbM;
    }

    for (int CowZAkbPC = 1333918694; CowZAkbPC > 0; CowZAkbPC--) {
        vjCAYIzTiwUmFGy = vjCAYIzTiwUmFGy;
        tjnxfAfWiSoT = tjnxfAfWiSoT;
    }

    if (ZEenbM == 2103983641) {
        for (int NgvALrlru = 569328611; NgvALrlru > 0; NgvALrlru--) {
            NcLCd -= NcLCd;
            NcLCd *= vjCAYIzTiwUmFGy;
            ZEenbM *= dLTdIskADsQQM;
            ZEenbM *= ULZFREkAf;
            dLTdIskADsQQM *= ULZFREkAf;
        }
    }

    return ngebkrNiz;
}

double hpDbtIXETTczpWOr::uikLpUVr(int YGwzMo, string PhxraGTLKQ, int XmCTiwd, double WtILCPAcR)
{
    int LyYgQwzGq = -523754278;
    string GXazJK = string("BSQMLLxLFYtaEZRrBxRlVFELqYDGhfplXYLMztjTbnlawjOvcasrPEWMUEcSWoXKXSgoHwgRPgOQCucAhXZvhQZottWNTiKkvpDEIMlbiFvxjKSJXoyXRHvcsaqHtGqzYBGnXpnjmUjksoEFawJopuaUFbNSfdEsoVhKglLPtnrbLxmgeGqCfHgS");
    int lGweDFu = -1374058396;
    bool waIMwSaNdxchiGu = true;
    double TdTYhKc = 98858.83692415469;
    double QWaftpzstOuAX = 456422.6236535453;
    int BGsqqytzBl = -556562698;
    double rNFmSlBnnncFyb = -406348.304286299;
    double oAhgHRwAYhzGXHd = -598417.8718906655;

    if (XmCTiwd <= -1842461622) {
        for (int DmDqSDP = 429911092; DmDqSDP > 0; DmDqSDP--) {
            continue;
        }
    }

    for (int rytDsLXePOXdP = 893599931; rytDsLXePOXdP > 0; rytDsLXePOXdP--) {
        continue;
    }

    if (lGweDFu <= -523754278) {
        for (int LNdnDxZxCVGLM = 2033829122; LNdnDxZxCVGLM > 0; LNdnDxZxCVGLM--) {
            lGweDFu /= lGweDFu;
            LyYgQwzGq += YGwzMo;
        }
    }

    return oAhgHRwAYhzGXHd;
}

bool hpDbtIXETTczpWOr::FSKmxNQNHvqic(int IVttesqQjm, int YnCbPsWyHZBMXJrt, bool wXLQLuctdWSSe, int kBjKHBPzRxQYs)
{
    int AZCnONeBLAv = -750427864;
    double LELbfbNgheufkgJj = -304383.8657540788;
    bool wTRWiPi = true;
    string iahppb = string("FdepTIHFiYPHhDyQbnSJKoUNpfTZPIThdoAqTKitkXvSiilTYFcniByZobYoJVsukTfiBWJGckSuBYeiHWWMDiniWwIUFZSqBDAKlkyFldyqeXuUZHpqOsTTfVAwhkfrUqPltLJgvjsYnvdIfXPawqGxXrdIHcjVFHNpZhOQbUwyRGXuDiRIxrAFczvrdydlXIyXqMhkKkLmIpvLqFp");
    int ELHBDVTTvcM = 938838265;
    double JkawYQvOlsTSC = 633322.7519009572;
    int NFbfQgqXJNHY = -884263228;
    double pDvpeJWIZ = -182422.2102973861;

    if (IVttesqQjm > -980940942) {
        for (int XUDVRvMPK = 1052078195; XUDVRvMPK > 0; XUDVRvMPK--) {
            continue;
        }
    }

    return wTRWiPi;
}

void hpDbtIXETTczpWOr::ynXuwvfxcBZQih()
{
    double hcwmndQtNsPf = 51627.984867114064;

    if (hcwmndQtNsPf < 51627.984867114064) {
        for (int LNfISVqwHW = 1151495168; LNfISVqwHW > 0; LNfISVqwHW--) {
            hcwmndQtNsPf /= hcwmndQtNsPf;
            hcwmndQtNsPf /= hcwmndQtNsPf;
            hcwmndQtNsPf *= hcwmndQtNsPf;
            hcwmndQtNsPf = hcwmndQtNsPf;
            hcwmndQtNsPf = hcwmndQtNsPf;
            hcwmndQtNsPf *= hcwmndQtNsPf;
            hcwmndQtNsPf /= hcwmndQtNsPf;
            hcwmndQtNsPf -= hcwmndQtNsPf;
        }
    }

    if (hcwmndQtNsPf == 51627.984867114064) {
        for (int nuRlZvIc = 20249500; nuRlZvIc > 0; nuRlZvIc--) {
            hcwmndQtNsPf -= hcwmndQtNsPf;
            hcwmndQtNsPf /= hcwmndQtNsPf;
            hcwmndQtNsPf = hcwmndQtNsPf;
            hcwmndQtNsPf /= hcwmndQtNsPf;
        }
    }

    if (hcwmndQtNsPf > 51627.984867114064) {
        for (int kNJtNLUZYcp = 1997320708; kNJtNLUZYcp > 0; kNJtNLUZYcp--) {
            hcwmndQtNsPf += hcwmndQtNsPf;
            hcwmndQtNsPf -= hcwmndQtNsPf;
            hcwmndQtNsPf *= hcwmndQtNsPf;
            hcwmndQtNsPf = hcwmndQtNsPf;
            hcwmndQtNsPf /= hcwmndQtNsPf;
            hcwmndQtNsPf *= hcwmndQtNsPf;
        }
    }

    if (hcwmndQtNsPf < 51627.984867114064) {
        for (int FPnxE = 1415499139; FPnxE > 0; FPnxE--) {
            hcwmndQtNsPf -= hcwmndQtNsPf;
        }
    }
}

string hpDbtIXETTczpWOr::mYVHrSPAJxIdU(string QdhEZADqzDwRqhp, double RfqyobZqYJ, int IaBNhT, int SzrQPLraVRdYxG, bool PkLWjfCJJIvA)
{
    bool NiHoxWDqTghzVVb = false;
    double izTOoKrdkzzm = -415376.453318662;
    bool TarHEUXBLxTifoA = false;
    bool giDCnOtTMeBHqPa = false;
    string AAVtbdXoJfyw = string("LKAAJRSmlsUtbuAXCAwtvesIevSMLWsDnAezrpzIVrlRzHPFmmloYSciExNkwWuaYUEDkeuqUmTvFimLdxLutDtfLwAdsHUhEoAFdJEwQGqZzRfmduwJtXStUQlMpfuPUDvfXHAyRGFXkPdHuoAbfAHfUFqYRiKfRZtNXUIfAajhPad");
    bool OeCNvqQKvoZqH = true;
    double XDntJVm = 394111.53464148147;
    bool SEGPVIPY = false;
    bool OcwWH = true;

    return AAVtbdXoJfyw;
}

int hpDbtIXETTczpWOr::KllpBFbkTAAhTaSQ(string zsDTnrzcOtn, bool eOYiozzTwnr, double QLpjngtJwjDvsg, string sjzBDMLmmNPqk)
{
    bool mHBZlxTfbLLQu = true;
    double aeQFD = 1016103.5697379673;

    for (int rEdeuTHMyMWHnk = 1447103777; rEdeuTHMyMWHnk > 0; rEdeuTHMyMWHnk--) {
        sjzBDMLmmNPqk = zsDTnrzcOtn;
    }

    for (int yBJxmjPjQqIXgUih = 788010547; yBJxmjPjQqIXgUih > 0; yBJxmjPjQqIXgUih--) {
        QLpjngtJwjDvsg += aeQFD;
        aeQFD = aeQFD;
    }

    for (int aDhRBXVZaCLTJlHb = 1420534420; aDhRBXVZaCLTJlHb > 0; aDhRBXVZaCLTJlHb--) {
        continue;
    }

    if (eOYiozzTwnr == true) {
        for (int fVWvcwTh = 1758752435; fVWvcwTh > 0; fVWvcwTh--) {
            QLpjngtJwjDvsg = QLpjngtJwjDvsg;
            QLpjngtJwjDvsg /= aeQFD;
            sjzBDMLmmNPqk += zsDTnrzcOtn;
        }
    }

    for (int CAdUNiBUo = 1440486463; CAdUNiBUo > 0; CAdUNiBUo--) {
        continue;
    }

    for (int ktfHe = 1800199119; ktfHe > 0; ktfHe--) {
        sjzBDMLmmNPqk = sjzBDMLmmNPqk;
    }

    return 155243172;
}

double hpDbtIXETTczpWOr::ERRIyjfGx(int IcwMlkvt)
{
    double mbhvfld = -963028.8922112067;
    bool aFtVI = true;
    string wZJIe = string("WQMmkHJTLnOWmjKfWcjGUwlwRDIakwPlMyZnSoVTKvKgYMZjUBpNeIuJoslTblZn");
    double XeMWFFxpDGPGrXG = 476434.33622696606;
    bool NIKHCFcmVPuzv = false;

    if (mbhvfld >= -963028.8922112067) {
        for (int VZjXW = 1515218406; VZjXW > 0; VZjXW--) {
            mbhvfld *= XeMWFFxpDGPGrXG;
            XeMWFFxpDGPGrXG /= mbhvfld;
            aFtVI = aFtVI;
        }
    }

    return XeMWFFxpDGPGrXG;
}

void hpDbtIXETTczpWOr::YYVRgs(int FVRtjnfHjRKnx, double YrBXr)
{
    int fVruux = 1765717449;
    bool VJJcKGfqyQcc = true;
    double WzJanfRB = 399694.458972823;
    string pCCErSc = string("ZBRynLEYbIHjVrBndBmkNYeaeCUkRuLTxdvDoZQUOOiZfGpVhKIRNyStZZUYczIvcFjAGdCbsYAnoYtFZShHuPslGeoriwtrSa");
    string dCnzGoedwiNHC = string("qVTIPkIlpxVVdBoCQdJudCiXOqDwbqjpVgQljGLbTLsIIUSqfsBZQVYybiryYdleGXsTIbjdRWlbrfOCZseFHpfSYtYFfyZAhXmaqwwAZFUBvolfYtWJASizZFauNQzArPvKSllArHRYdCNCwGthiBdrdhTTb");
    string TlGNLvBld = string("OjSNJyBHaqlIrzlVsQoKBOrnfWMeBFUxuFrArLuVsrWZcbrgasnnIBEvrmcmEVPHMutGcgXvQGDFtzWqXkbMpcbnNPwKfsaOaRTkQF");
    bool ZvtSSleLFr = true;
    string CvQCqEGGtdJ = string("TcdLbXKrfx");
    string YwKswR = string("YckURuQrSjDkdwfOlUQiyVXrHCZeMFceadGeCxCpFSxRowxyaFYcODvksTBEDfcRWG");

    for (int BADsKPIPv = 47976127; BADsKPIPv > 0; BADsKPIPv--) {
        pCCErSc += CvQCqEGGtdJ;
        TlGNLvBld = pCCErSc;
        dCnzGoedwiNHC += TlGNLvBld;
    }
}

void hpDbtIXETTczpWOr::OsXtBQS(bool ugmgpGCskh, double GDVfyusK, double ygKaCyjHKxiPw)
{
    double uYvRLRZ = 524394.2933314623;
    int dLLkVxZgjT = -580601437;
    bool bEJxQonrZzdvuvb = true;
    string bFzMTDclbRBX = string("cIVRqhqIkICBBexlyhVIGFKuCyFHJitNUmQyCqWQkzlbqlMwSrjsIQEGFdNiYUiLhCWFlidLPSZAFtjMJGyGwPEwacCwLrrttwDxcjssMsnKqrCfNlzkJkyaJmWPQkwSkFnyaYmOqutjEFzVdGqiHehJDEpHuFnGQVdTqQnLjMRNJhPtMIiWfIvzRoVRrJRdsEkEeiwleTGkDYLaBwIHZrkR");
    double upAHvO = 602152.675833171;
    int EpSAdFyyJJiqNd = -2000044641;
    bool JoHbSOiUVgLK = true;
    double cjcvTBAowSxnt = 726586.6652639478;

    for (int UrbvQtjNVIlLFV = 1637928724; UrbvQtjNVIlLFV > 0; UrbvQtjNVIlLFV--) {
        ygKaCyjHKxiPw = ygKaCyjHKxiPw;
        bEJxQonrZzdvuvb = ! JoHbSOiUVgLK;
    }

    for (int DxjnNpcVDvyg = 1309280099; DxjnNpcVDvyg > 0; DxjnNpcVDvyg--) {
        continue;
    }

    if (cjcvTBAowSxnt == 492130.8194158269) {
        for (int rqUFMj = 1583131130; rqUFMj > 0; rqUFMj--) {
            ugmgpGCskh = ! ugmgpGCskh;
            uYvRLRZ = GDVfyusK;
        }
    }
}

double hpDbtIXETTczpWOr::aaUVuzwzMgwQMari(int RDFCOHOLdFa, int ielhwrUMAsvxIz, string oNZTC, double emPmemxfxUBlFCKO)
{
    bool LqJFHumUYyAp = true;
    int UmFSfYwn = 270429272;
    int wYBvIxoXHVp = 434644088;
    double beIiDmHGxhKqEGwW = 67073.955654175;
    int umfFqeyoKgAoXdo = -327512374;

    for (int ewQJXROjU = 360011336; ewQJXROjU > 0; ewQJXROjU--) {
        UmFSfYwn += ielhwrUMAsvxIz;
        wYBvIxoXHVp *= wYBvIxoXHVp;
        oNZTC = oNZTC;
        wYBvIxoXHVp *= RDFCOHOLdFa;
        wYBvIxoXHVp *= wYBvIxoXHVp;
        beIiDmHGxhKqEGwW -= beIiDmHGxhKqEGwW;
    }

    if (RDFCOHOLdFa > 434644088) {
        for (int psLtAJt = 1125797824; psLtAJt > 0; psLtAJt--) {
            ielhwrUMAsvxIz -= UmFSfYwn;
            ielhwrUMAsvxIz *= umfFqeyoKgAoXdo;
        }
    }

    for (int pyhFitjMlI = 1868715086; pyhFitjMlI > 0; pyhFitjMlI--) {
        ielhwrUMAsvxIz -= ielhwrUMAsvxIz;
        wYBvIxoXHVp = umfFqeyoKgAoXdo;
    }

    for (int SYjUOovagKGd = 1764253591; SYjUOovagKGd > 0; SYjUOovagKGd--) {
        umfFqeyoKgAoXdo -= ielhwrUMAsvxIz;
        UmFSfYwn = ielhwrUMAsvxIz;
    }

    return beIiDmHGxhKqEGwW;
}

void hpDbtIXETTczpWOr::kaSfbn(string EIDDTCOSWBK, double tUDhmnrgu, string vDWGpKR, bool DOSBkoiKaiARWnBn)
{
    bool DLTNjyNFjpJwK = false;
    int cGWFpVIhjFzOb = 1315296791;

    for (int tLlZxhm = 208877940; tLlZxhm > 0; tLlZxhm--) {
        tUDhmnrgu *= tUDhmnrgu;
    }

    for (int POsUduUn = 1156781940; POsUduUn > 0; POsUduUn--) {
        continue;
    }

    if (cGWFpVIhjFzOb == 1315296791) {
        for (int HTKVq = 1180397215; HTKVq > 0; HTKVq--) {
            EIDDTCOSWBK = EIDDTCOSWBK;
            tUDhmnrgu *= tUDhmnrgu;
            DLTNjyNFjpJwK = DLTNjyNFjpJwK;
        }
    }

    for (int eqiYoBpfKylhhu = 773600446; eqiYoBpfKylhhu > 0; eqiYoBpfKylhhu--) {
        DLTNjyNFjpJwK = ! DOSBkoiKaiARWnBn;
    }

    for (int ZMZAMl = 1826894687; ZMZAMl > 0; ZMZAMl--) {
        EIDDTCOSWBK += vDWGpKR;
    }

    for (int zHPzRci = 17857009; zHPzRci > 0; zHPzRci--) {
        DOSBkoiKaiARWnBn = ! DOSBkoiKaiARWnBn;
    }
}

hpDbtIXETTczpWOr::hpDbtIXETTczpWOr()
{
    this->YIDkrXZw(false, -36119.72179851554, -478389612, 671826.1414838341);
    this->VuQQOEME(false, 2040856401);
    this->XfDAtkaOKilcxs(-392248.03989533364, -479199958);
    this->IHIsWfvaKzEPXUUT();
    this->wVApZbwgUOYnsmb(string("zaxICtGVxFDNZruTMQfQQSWOZDcDWjWdilcdhXcaoxxsgKYDOMnthOKFheEFhGPmYTuBxGJDRZDCGqoMUXBmpqEwIOaQoZEArTdHTcjgjYMvCELNeswQyaCEdrOgqOSETuAVdpdGMivpPGitSYdmanMtWwnTyHwAeKcdTATgQaXFukJuFWzumAgYYhbMbZpbxGiwYPrLjDfvkYzBXKJLyUARESWKpacqsTHZdUvMDhjNRTSmIvKMkHyzbYXrXB"), 524414.7953824275, 200612.71868391146, false);
    this->uikLpUVr(-1842461622, string("pidMsWgSJJQXxIHietGSdLSGylCrdWzYNsKMDZ"), -1598497132, -114201.63358598328);
    this->FSKmxNQNHvqic(-980940942, 1986629154, true, -1300568347);
    this->ynXuwvfxcBZQih();
    this->mYVHrSPAJxIdU(string("MxqiRfLEMnEWdGoCzxmULhLtFdYS"), -521094.09283686476, -1288574083, -1677668364, false);
    this->KllpBFbkTAAhTaSQ(string("CfbklpRVENzgvtQjgmbIKYlfulbmCipzciFqdPDXUXLZdLyaxcCecEdWwoQHUsBuBYbJyMDSZFVELkvCKLPbLRnYTNbOJozxEQpKQPOLrJfOMktfRuqfNGIEZtQNJePWvYjFYtJDhOIJIzhPckaDnHeqpbvkMDdAwsYCeabuUZuFlGeZDMWVYRKk"), true, 796910.1358650817, string("QwEaEXekXejkTPKVlyttSEaPqIjjlUYvFvgeiDygaICOyesNQkVyoAVFnxVnthIsBZ"));
    this->ERRIyjfGx(769672983);
    this->YYVRgs(1319415411, -777030.761941984);
    this->OsXtBQS(false, 492130.8194158269, -89341.7229963859);
    this->aaUVuzwzMgwQMari(739604164, 1856402566, string("cZIxckffwIORZJihgXKzMcKXTSRDxamhboaajVlqgyEQtUJQtMVUFpziUfDgqDYgsZlVBtMBcqyoCALkeruqKPHskLrvNvdhzelXgdYVdyNxxjOLDzxvDrgBYTyCQjPxmmNlpZoc"), -76404.59635813125);
    this->kaSfbn(string("QvzWnwYZOuaJyBTnpwpUwKCqQcLMXmxfUWGEamDXNFOJuHWpCMHxNqCFQlhVrcggHLKhbmJLJVDTn"), 609039.8255445694, string("vkQUbbBThECWnNTdUFZWyutzUdAjHrjuYUUUwNIJymsisgKxUTvXHfEjtSbkxnTFgShyopJIyGKfQAZPSRmlSVlBZSkFzkSJkBEehFJnmXFhOscUHKNdSexXcMeHdRUmNfzgPR"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UJYfDlXiQnr
{
public:
    string qsyhznGmetZgbY;

    UJYfDlXiQnr();
protected:
    bool tcdNGT;
    int ONpHvBKPWGdqFT;
    bool BtWEfvuavyMPeO;
    bool wuEeicwz;

    string tvCyR(double bwTZTWko, bool xVKCwGsEmH, double qnkoYmxjnxAUZkYN);
    int jRngc(double CrNFupYssh, bool HBfvIX, int ZeYtveaEWyRbdof);
    string ihTlcOgm(bool SDXsCoocYlJ, string lVxodQYF, bool RdKSJnAxaKweoG, bool eLuvlXwowRqmXKnc, int pPzREtf);
    bool iIUyaDqZYJX();
    string hqtktCiqnAXeUEdc(double opWvXKDYgVuhQ);
private:
    int mYfwWVZGRX;
    double FWEnEwxEG;
    bool jMGQzF;
    string apGBHKXwsugZG;
    string PJzlJyowTlW;
    string cfmyaKapVrjJ;

    int BWSXAvXG(bool ncTXgHnCBAmZ, double GBoNKvCfutbf, string jUDwIVC);
    void cvtsI(double ilOCvjPLlHrg, int pIjAJv, bool lVdJZfT, int UNGgsCfUOViCu);
    bool vCtqjyedSDjjYJ(int YHvubLx);
    bool IDgonzg(double ZfITiIjIYRXLZKV, string QOlCU);
    int WxwLOXeqyj(string JvLVv, int OmRnsN, string KjiKJaTOvQNh);
    void qcMgPDkBIj();
};

string UJYfDlXiQnr::tvCyR(double bwTZTWko, bool xVKCwGsEmH, double qnkoYmxjnxAUZkYN)
{
    int rvZzxNVSnGr = 1360187163;
    int aVSOZLqTDxN = -1091029531;
    bool TvIFVgHc = false;
    string DgVEfTJqeSQ = string("qafcPawnzaHeyTxFskGHeaCalJuBPbdeKkNfuTnnwhSfyaZfnAGAsoNCxzzUPhxntWAvmXADnMRWrvVzRRVfdpscpdWqejXfxwjbxtvuBFyvUxakiYKfVNlogeDEpZYqsZ");
    double CWSJHow = 745090.2831688598;
    bool VLfbccfvFCZaIOGu = false;
    int LSfCKvSGlBASSwC = -2074934969;
    bool SBXRoKMugJleCtIo = true;
    string rhGvWbdh = string("TYWkGfHXioKpWfybgmqbFfSwwVnQCUYTQHNNlWQBzreaDphoIyLESAEjQdHygFUscOaMHAhuzRVASJFIbYlhlfpqptZwSfYYbfYtVBUXthswQPuDdwSmbtwzQYwZpueeahsIqxeduDYsinjSgRvbYcVugjFkeEqihJajoMjcgPObIcKwgpFYvHHkWRNzOalIRHWExeIGUweZibzQvEvjIiaPGImjjBFmdlKoBzexPUquVIGMPVadhgQQdPWUenZ");

    for (int IwkQCBGks = 713399253; IwkQCBGks > 0; IwkQCBGks--) {
        qnkoYmxjnxAUZkYN -= bwTZTWko;
        bwTZTWko *= qnkoYmxjnxAUZkYN;
    }

    for (int NHcVUPcRYQ = 1653404287; NHcVUPcRYQ > 0; NHcVUPcRYQ--) {
        aVSOZLqTDxN /= aVSOZLqTDxN;
    }

    return rhGvWbdh;
}

int UJYfDlXiQnr::jRngc(double CrNFupYssh, bool HBfvIX, int ZeYtveaEWyRbdof)
{
    bool kbnNolytakCCX = false;
    string sAwfXLxe = string("aWjyhWicLujzTpAYKfeDzmLCJCNLMjTAokCdPaKzPbosm");
    bool lDDEFeJcgQDUaVt = true;

    if (HBfvIX == false) {
        for (int gpHHwLYccYyh = 822825703; gpHHwLYccYyh > 0; gpHHwLYccYyh--) {
            ZeYtveaEWyRbdof /= ZeYtveaEWyRbdof;
        }
    }

    if (kbnNolytakCCX != false) {
        for (int HbzzZnzVnoBtjnQ = 1669712989; HbzzZnzVnoBtjnQ > 0; HbzzZnzVnoBtjnQ--) {
            kbnNolytakCCX = lDDEFeJcgQDUaVt;
            lDDEFeJcgQDUaVt = ! kbnNolytakCCX;
            sAwfXLxe += sAwfXLxe;
        }
    }

    if (kbnNolytakCCX != false) {
        for (int tlRoqXFRsnHYPBs = 674009420; tlRoqXFRsnHYPBs > 0; tlRoqXFRsnHYPBs--) {
            HBfvIX = kbnNolytakCCX;
        }
    }

    return ZeYtveaEWyRbdof;
}

string UJYfDlXiQnr::ihTlcOgm(bool SDXsCoocYlJ, string lVxodQYF, bool RdKSJnAxaKweoG, bool eLuvlXwowRqmXKnc, int pPzREtf)
{
    int tvNxkI = -878886883;
    double uvJuINgYQqVmlEB = -861597.3148676271;
    double JhimZBHTzpUOsvQM = 732411.6608679307;
    bool mTksevsUbXpP = false;
    int uwdRvt = -569717915;

    if (eLuvlXwowRqmXKnc == true) {
        for (int usHmG = 785371235; usHmG > 0; usHmG--) {
            mTksevsUbXpP = ! eLuvlXwowRqmXKnc;
            uvJuINgYQqVmlEB -= uvJuINgYQqVmlEB;
            uwdRvt -= pPzREtf;
        }
    }

    for (int BxFoQ = 928279285; BxFoQ > 0; BxFoQ--) {
        continue;
    }

    for (int TWJRjcfzQJuUb = 509788123; TWJRjcfzQJuUb > 0; TWJRjcfzQJuUb--) {
        continue;
    }

    return lVxodQYF;
}

bool UJYfDlXiQnr::iIUyaDqZYJX()
{
    double HQymiuTgtrrehWAN = -17711.87930862097;
    string QExJHNyhtdoHUi = string("GYsgouQJkDiBSMMuzmOWOrlmWJofxUzMJXqDpPllmGOkzTNBYVMRmgQjaogP");
    double bsRHCffRjiJB = 382600.9701658606;
    bool NgauAqONWMb = true;
    double xArkmy = -385051.4477342724;
    double NSbGFVIGnVUE = 651339.045957499;
    double nLtENQkSnmvUYKji = 600506.1247169835;

    if (xArkmy != 600506.1247169835) {
        for (int miqoUlqaLklgUy = 122260174; miqoUlqaLklgUy > 0; miqoUlqaLklgUy--) {
            xArkmy /= nLtENQkSnmvUYKji;
            NSbGFVIGnVUE /= NSbGFVIGnVUE;
            xArkmy *= HQymiuTgtrrehWAN;
            nLtENQkSnmvUYKji = bsRHCffRjiJB;
            NSbGFVIGnVUE /= bsRHCffRjiJB;
            HQymiuTgtrrehWAN += HQymiuTgtrrehWAN;
            bsRHCffRjiJB = NSbGFVIGnVUE;
            bsRHCffRjiJB -= NSbGFVIGnVUE;
        }
    }

    for (int SuiCrnUGEA = 320266862; SuiCrnUGEA > 0; SuiCrnUGEA--) {
        HQymiuTgtrrehWAN = bsRHCffRjiJB;
        nLtENQkSnmvUYKji -= NSbGFVIGnVUE;
        NSbGFVIGnVUE = bsRHCffRjiJB;
        nLtENQkSnmvUYKji *= NSbGFVIGnVUE;
        bsRHCffRjiJB /= xArkmy;
        HQymiuTgtrrehWAN *= HQymiuTgtrrehWAN;
        xArkmy = NSbGFVIGnVUE;
    }

    for (int jjahHHHNCiFPWi = 2054744123; jjahHHHNCiFPWi > 0; jjahHHHNCiFPWi--) {
        bsRHCffRjiJB = bsRHCffRjiJB;
        NSbGFVIGnVUE += NSbGFVIGnVUE;
        HQymiuTgtrrehWAN += xArkmy;
        NSbGFVIGnVUE -= xArkmy;
    }

    for (int NJrFabR = 50455481; NJrFabR > 0; NJrFabR--) {
        bsRHCffRjiJB /= xArkmy;
    }

    if (NgauAqONWMb == true) {
        for (int wjtjeNKgAflMJWr = 49040570; wjtjeNKgAflMJWr > 0; wjtjeNKgAflMJWr--) {
            nLtENQkSnmvUYKji -= nLtENQkSnmvUYKji;
        }
    }

    return NgauAqONWMb;
}

string UJYfDlXiQnr::hqtktCiqnAXeUEdc(double opWvXKDYgVuhQ)
{
    double EsWaI = -453046.39237457624;
    double XgMlB = 820785.9584246944;
    string wkVzetWvCFwEcKZu = string("K");
    int FFcERgVjWJClOpS = 326901215;
    double RcbMv = -1032304.0055092329;
    double poOQyJwQa = -1048147.8409607456;
    double aDYcQNVVHQjZUiy = -905651.066743806;
    int FIsDfZXSlNcBD = -1554744163;

    if (opWvXKDYgVuhQ > -453046.39237457624) {
        for (int YtchWeSVMggLv = 790865103; YtchWeSVMggLv > 0; YtchWeSVMggLv--) {
            opWvXKDYgVuhQ /= XgMlB;
            aDYcQNVVHQjZUiy += EsWaI;
            opWvXKDYgVuhQ -= XgMlB;
        }
    }

    for (int NyKqGmFng = 1768027300; NyKqGmFng > 0; NyKqGmFng--) {
        continue;
    }

    if (aDYcQNVVHQjZUiy < -1048147.8409607456) {
        for (int ZzQkhDqXULuECpj = 1399722656; ZzQkhDqXULuECpj > 0; ZzQkhDqXULuECpj--) {
            poOQyJwQa *= poOQyJwQa;
            RcbMv /= RcbMv;
            wkVzetWvCFwEcKZu = wkVzetWvCFwEcKZu;
            aDYcQNVVHQjZUiy /= opWvXKDYgVuhQ;
            FIsDfZXSlNcBD = FIsDfZXSlNcBD;
        }
    }

    if (FIsDfZXSlNcBD == -1554744163) {
        for (int LiqrKUVQUHW = 944275130; LiqrKUVQUHW > 0; LiqrKUVQUHW--) {
            opWvXKDYgVuhQ *= XgMlB;
            poOQyJwQa *= aDYcQNVVHQjZUiy;
            EsWaI /= XgMlB;
            RcbMv = aDYcQNVVHQjZUiy;
        }
    }

    if (XgMlB <= -1048147.8409607456) {
        for (int TeNMBgkulBPpn = 1419606720; TeNMBgkulBPpn > 0; TeNMBgkulBPpn--) {
            continue;
        }
    }

    return wkVzetWvCFwEcKZu;
}

int UJYfDlXiQnr::BWSXAvXG(bool ncTXgHnCBAmZ, double GBoNKvCfutbf, string jUDwIVC)
{
    int fSDZGtBkXwTrshet = -2144984870;
    bool ZJaUyt = true;
    bool QopKZVpsTCvC = true;
    string pnpoNct = string("hbTIzcDTqLYqapbHhNrtPtFZTATTjPsTZGLzzkirqghBmLjbECBWUzavLOIsLmPIITUZjwlrzAbPagBDqnbSCBiYnbnMNtOSlqUkncLvTLuGobIcKBjUckBLByBxaNVscjtBPZAAdWldVCjkIQMmmJdzYFfGIUGSQbMxFPRDItOHmNmunrThqjxSjRLRSLPJgxJabGoQeQegYLUilyVhYEdyPxmfqUlHSkNql");
    double wgkNdBVCTgDpuOmH = 464853.26579704095;
    bool MSkHgiLVXF = true;
    int NECODG = -29965884;

    if (QopKZVpsTCvC == true) {
        for (int mWyYvpiL = 827217219; mWyYvpiL > 0; mWyYvpiL--) {
            continue;
        }
    }

    return NECODG;
}

void UJYfDlXiQnr::cvtsI(double ilOCvjPLlHrg, int pIjAJv, bool lVdJZfT, int UNGgsCfUOViCu)
{
    int OYOgojhfRhRic = 1889694336;
    double BbpBIpZmAtBcSs = -397253.56385182636;
    bool easSBUW = true;

    for (int LdhxQMPhDlUCmkJY = 1849459751; LdhxQMPhDlUCmkJY > 0; LdhxQMPhDlUCmkJY--) {
        pIjAJv *= UNGgsCfUOViCu;
        UNGgsCfUOViCu -= pIjAJv;
        UNGgsCfUOViCu -= pIjAJv;
    }

    if (easSBUW != true) {
        for (int OExSNOFbvmiKmVvk = 1869195450; OExSNOFbvmiKmVvk > 0; OExSNOFbvmiKmVvk--) {
            OYOgojhfRhRic /= UNGgsCfUOViCu;
        }
    }

    if (UNGgsCfUOViCu >= 1889694336) {
        for (int tzeMTQnezocPg = 936794686; tzeMTQnezocPg > 0; tzeMTQnezocPg--) {
            continue;
        }
    }

    if (BbpBIpZmAtBcSs > 300139.8544555275) {
        for (int JsEurGlBv = 1883579190; JsEurGlBv > 0; JsEurGlBv--) {
            lVdJZfT = ! lVdJZfT;
            OYOgojhfRhRic -= UNGgsCfUOViCu;
        }
    }
}

bool UJYfDlXiQnr::vCtqjyedSDjjYJ(int YHvubLx)
{
    int ttnGKYrVVQAIBDF = 852510174;
    double feRpw = -399373.1785039503;
    bool WtNLYdbOc = true;
    bool ZurPZn = true;
    bool XJIGYuujew = true;
    double aOVhqdOSOfyqTa = -857416.7091878289;
    double HxQcurPJskGz = -919623.6969449546;
    bool pHAcM = true;

    for (int yNoYPBKCNSLX = 1061462662; yNoYPBKCNSLX > 0; yNoYPBKCNSLX--) {
        aOVhqdOSOfyqTa += feRpw;
    }

    for (int ItCItVfZqXtxLjUg = 2102134211; ItCItVfZqXtxLjUg > 0; ItCItVfZqXtxLjUg--) {
        ZurPZn = ! WtNLYdbOc;
    }

    for (int ztGAvztxvaqGu = 511894935; ztGAvztxvaqGu > 0; ztGAvztxvaqGu--) {
        continue;
    }

    for (int PKhxmRLFloCWY = 1177363645; PKhxmRLFloCWY > 0; PKhxmRLFloCWY--) {
        continue;
    }

    return pHAcM;
}

bool UJYfDlXiQnr::IDgonzg(double ZfITiIjIYRXLZKV, string QOlCU)
{
    int xIOQM = -444581395;
    double rqsIxTRkM = 411631.42954399233;
    double HXnWUy = 606168.807570457;
    string aRbbHxK = string("KjelZRVCrJkYUkpqGLoLpqoPyVCkhWvqanPSgYFnThGKsMpMtwJsiJQyZeXWkuzZmBhKzVXDOHfBMGdTftFjwbFZEixBVHuwhLuUlynDhhGrXQrAqBIFTKUjGiYAvrPvRzVdXrLUNSwnbqsSkidAkDPtQXHpcBpWeAGPovRFd");
    double skVVsQO = -577450.1113742291;

    return false;
}

int UJYfDlXiQnr::WxwLOXeqyj(string JvLVv, int OmRnsN, string KjiKJaTOvQNh)
{
    int MKvFSCuhqCiChnbs = 707506169;
    bool fXcAeBMPQJi = true;
    double cRXTnluBp = 467122.1557278609;

    for (int NanLPXAbw = 1330551892; NanLPXAbw > 0; NanLPXAbw--) {
        KjiKJaTOvQNh += JvLVv;
    }

    for (int fbMAwhUoOfAFS = 1630486267; fbMAwhUoOfAFS > 0; fbMAwhUoOfAFS--) {
        JvLVv = JvLVv;
        OmRnsN = MKvFSCuhqCiChnbs;
    }

    for (int FWjwdXFnMJ = 2136528072; FWjwdXFnMJ > 0; FWjwdXFnMJ--) {
        MKvFSCuhqCiChnbs -= OmRnsN;
    }

    return MKvFSCuhqCiChnbs;
}

void UJYfDlXiQnr::qcMgPDkBIj()
{
    int OosCyeImCkrqRzO = 454397495;
    string lMrFUkmRDCcrOCmZ = string("QXwjBpJzcWmEabPnDAkyLeClYQbYJwWifMSDkxuIrIbYrzPNcRHgUtXOXpTLXJHhOeCeKpkItNxNzfHcdNkoCfRMVsvdKmAgBZy");

    if (lMrFUkmRDCcrOCmZ <= string("QXwjBpJzcWmEabPnDAkyLeClYQbYJwWifMSDkxuIrIbYrzPNcRHgUtXOXpTLXJHhOeCeKpkItNxNzfHcdNkoCfRMVsvdKmAgBZy")) {
        for (int KpHPwaHArI = 2077905660; KpHPwaHArI > 0; KpHPwaHArI--) {
            OosCyeImCkrqRzO = OosCyeImCkrqRzO;
            OosCyeImCkrqRzO *= OosCyeImCkrqRzO;
            lMrFUkmRDCcrOCmZ = lMrFUkmRDCcrOCmZ;
        }
    }

    for (int tROdIznjaxaZSXKZ = 1320566199; tROdIznjaxaZSXKZ > 0; tROdIznjaxaZSXKZ--) {
        lMrFUkmRDCcrOCmZ += lMrFUkmRDCcrOCmZ;
    }

    if (OosCyeImCkrqRzO <= 454397495) {
        for (int SvnMNyECTFEZbhZu = 1967961913; SvnMNyECTFEZbhZu > 0; SvnMNyECTFEZbhZu--) {
            lMrFUkmRDCcrOCmZ = lMrFUkmRDCcrOCmZ;
        }
    }

    if (OosCyeImCkrqRzO != 454397495) {
        for (int APmNMFRZiDlCB = 1964975675; APmNMFRZiDlCB > 0; APmNMFRZiDlCB--) {
            continue;
        }
    }

    for (int HMyjEcINZJ = 1857751045; HMyjEcINZJ > 0; HMyjEcINZJ--) {
        lMrFUkmRDCcrOCmZ = lMrFUkmRDCcrOCmZ;
        OosCyeImCkrqRzO *= OosCyeImCkrqRzO;
        lMrFUkmRDCcrOCmZ += lMrFUkmRDCcrOCmZ;
        OosCyeImCkrqRzO += OosCyeImCkrqRzO;
        OosCyeImCkrqRzO += OosCyeImCkrqRzO;
    }

    if (OosCyeImCkrqRzO <= 454397495) {
        for (int UkMHxn = 842351491; UkMHxn > 0; UkMHxn--) {
            OosCyeImCkrqRzO *= OosCyeImCkrqRzO;
        }
    }
}

UJYfDlXiQnr::UJYfDlXiQnr()
{
    this->tvCyR(-346540.69214024604, false, 660642.4783733208);
    this->jRngc(-688532.4513443894, false, 357067169);
    this->ihTlcOgm(false, string("uNkpkgEDXXrPlUGCYSwTibCpJPBYiBARzVNlYSLTPAwIPmMoXuBrgXZPvCqdlaUAMrOZaQNwINIDcKUVYfXSCjskxyVVQvUqgSPSYWctoVRhojEosmYwGSWBuYoEGNQfayfSLNMTBiSVHptPOxSlRFxjRnolnuRCgxXnxwbBAElZR"), true, true, 1350548795);
    this->iIUyaDqZYJX();
    this->hqtktCiqnAXeUEdc(-807305.3233042757);
    this->BWSXAvXG(true, 312052.2771334648, string("nZikqtzDKEICQYABPgJeWGjzzWnBkFvcKStbwLCgfOFmatiYNhFynAMViRKiUJBQVcgKsIJMvtKqTpLiVPfGKzpCHBnmZPTspfrQV"));
    this->cvtsI(300139.8544555275, -1722693102, true, 21715483);
    this->vCtqjyedSDjjYJ(-1409286131);
    this->IDgonzg(-783155.8848752138, string("VsKLxdUzFomftavqHIpEulGDuyIrdcVdI"));
    this->WxwLOXeqyj(string("BWqvOkuisfMctIFGznktPRDmTFgyzAMfaFXvkpaOhdMynfJZewiTytaRlqhPvCFLKdYxrEWJ"), -1204043048, string("yeZytQJGdHCNtBdRGFYzbGbWaBmadOOoJVTPpXNQjQRxpgtWJhkigGgdttiECJKlRoliOoeaxsARZiGuVDRICryReGTDilNlmwXOfrWcDjmhMdMavfKZUIpPQEpQPhAMymhDrPJlVyqGckg"));
    this->qcMgPDkBIj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zrSnZrASYHMlrgFZ
{
public:
    bool BgVNwwxuoWU;
    bool PvdgFllyg;

    zrSnZrASYHMlrgFZ();
    bool vZhEGLsp(string deBNnPoDVRSVN, bool hZaqnxHtcmu);
    string bUTNCWFE(int VlrhxSCVn);
    void EzAlIJF(string bgxeOLypvq, double zudKXnmUEnJs, string puSgICtkKR);
    int mIwWgrVUxyfa(double LQEVsbl, bool RJUGMuErUWmpb, double UKLxEDrcM, bool qzvJFAtfuToY, int sIfZPDvnLoehY);
protected:
    int BltHGQTLeh;
    string VGyxsAJwBEopjyD;

    string ruYhhXkIOvJ(bool mgAujGJJCP, bool wWvfAYLgsCmDCI);
    void CiTTazB(bool bzNlP, double WLktSDFphTnd, bool UqsRfEXMkheE);
    void iLlXXsLvCLEJeLay(bool XbgnsUUslBGMQP, double HpQFwUwtY, string UUokyGyZeZYRtTl, double KxupgcuiHEJwgPH);
    void UYUIdo(string iRuUjgLEEDyqxi);
private:
    double eRFpLE;

};

bool zrSnZrASYHMlrgFZ::vZhEGLsp(string deBNnPoDVRSVN, bool hZaqnxHtcmu)
{
    bool JSpnrzqtSipLU = true;
    bool HGVNgi = true;
    bool omOKayt = true;
    string vKfQxjcm = string("NheuXtWqPsOjNsrcZUhfeMtYGWvvGAtGYFHxatrxwSYwBdvqOMRvFeMPMJriGvWa");
    string ZebwrkDgpLB = string("QVdFlzgqutBBXGwLmpiUljwPOnZzcZqXdWVUXCWEgtSuRluwSaxMJnLwUHAEFTwYikzfXeujqiWVzbhyRlTuWmJNjdKMAXpoCHmmPbmSuraNgWFHlaQLtmZpHiDqZEVUwdmKKgKFDcRWlnkiwDEKDRpFdFpBRINtUIfyMWJHsHLneoFlsZvjBpYczDdDeHakogRtSAb");
    int PidqzlvPyrJNWSLK = -1791073179;
    int nNUFhpe = -327736611;
    int nDtvqNrkdcDFCr = 803412721;

    if (ZebwrkDgpLB != string("DzDAckDtCKrLKffflfogMvlLlLamAjsfoTIDCaRNWHKHRCCiJYOjjZBrdzncWgPOzMLBOCvBCWGTGIMNhpEDibxcbmbMMIZKzvACeYqVoPwQXcfhJUBoXtWzHqczWVbjKPLwNOmnZbHpsTAHPmOArgrK")) {
        for (int qBjtWe = 1577154846; qBjtWe > 0; qBjtWe--) {
            ZebwrkDgpLB = deBNnPoDVRSVN;
            vKfQxjcm += ZebwrkDgpLB;
        }
    }

    return omOKayt;
}

string zrSnZrASYHMlrgFZ::bUTNCWFE(int VlrhxSCVn)
{
    double gmHQzmXRHIEWmBk = -126914.64806573151;
    string feTjqOfGZ = string("COJSCxyzmhlRJOJJMyobPIoEdAaAXXRSWnXLuDjCwKaeXqpAOizPDrAdAKCJHUGTgmUCetfQDzcqcNzyCcXypuFFMRwQjKeXnVVeSOPhtUUDTNLKBmSvbQjtOqNdoewySGSZiODJWlvlMwdmceZPFijfaoFRsccvZfrQaRPDdhlQqyxyFGdVeDoGonCStADtlHYLEjIAdeXqKPCg");
    bool bQsva = false;
    double qmKCchJ = -119008.39256990018;
    int arZmsru = -513851217;

    for (int RZlAWjtNer = 585947576; RZlAWjtNer > 0; RZlAWjtNer--) {
        qmKCchJ -= gmHQzmXRHIEWmBk;
        VlrhxSCVn /= arZmsru;
    }

    return feTjqOfGZ;
}

void zrSnZrASYHMlrgFZ::EzAlIJF(string bgxeOLypvq, double zudKXnmUEnJs, string puSgICtkKR)
{
    bool aUvfhE = false;
    string OxmWVyKDDKLou = string("McGTOClSbyONVYrFcvdcWFmfqjxRkCMGEjIGxCFPvjHlzbmYHpRzyeQzLAIzTAKpTHEcqYXcygXEMEvQVvOhPLragSenbhPyqTaHOQNvXLoSoeaIKnpLgO");
    int NDbmTLSevBgX = 1232930213;

    for (int XNJRvDdtgwPtk = 2074106968; XNJRvDdtgwPtk > 0; XNJRvDdtgwPtk--) {
        puSgICtkKR += bgxeOLypvq;
    }

    if (bgxeOLypvq == string("ZoWNzUKBiTjMxsMuDLGxjmjcGnJGRRloDbnoojxcifjVeDZmXjTDaYxsWEPuWBLATXQNTtWZjNOmyxJPmoFFDptDhnZEDoORJIWsvRcaFptCicCKaOLZCcWVCMnzFTHNrtzZcWKCmpeByaUlFXJLrYBsNpNhLVpjrISmNzWdJwtaKsWsNOAPCyPAILompguCOabMM")) {
        for (int SNOxXtHptcgBPB = 1093416899; SNOxXtHptcgBPB > 0; SNOxXtHptcgBPB--) {
            OxmWVyKDDKLou = OxmWVyKDDKLou;
            bgxeOLypvq = bgxeOLypvq;
        }
    }

    if (bgxeOLypvq <= string("ZoWNzUKBiTjMxsMuDLGxjmjcGnJGRRloDbnoojxcifjVeDZmXjTDaYxsWEPuWBLATXQNTtWZjNOmyxJPmoFFDptDhnZEDoORJIWsvRcaFptCicCKaOLZCcWVCMnzFTHNrtzZcWKCmpeByaUlFXJLrYBsNpNhLVpjrISmNzWdJwtaKsWsNOAPCyPAILompguCOabMM")) {
        for (int sLuNEiRfbktZ = 1495029791; sLuNEiRfbktZ > 0; sLuNEiRfbktZ--) {
            OxmWVyKDDKLou += puSgICtkKR;
            OxmWVyKDDKLou += puSgICtkKR;
            bgxeOLypvq = puSgICtkKR;
            zudKXnmUEnJs -= zudKXnmUEnJs;
            OxmWVyKDDKLou = bgxeOLypvq;
        }
    }
}

int zrSnZrASYHMlrgFZ::mIwWgrVUxyfa(double LQEVsbl, bool RJUGMuErUWmpb, double UKLxEDrcM, bool qzvJFAtfuToY, int sIfZPDvnLoehY)
{
    int cCJwGa = 676706794;
    double RsMPLWwjDERCDLwm = 529044.1028704896;
    bool JJWrJ = true;
    double icWsoYXb = 632395.7182387578;
    int XooOFzBE = 95363028;
    double vJDYftmqgq = -637496.600936988;
    double QoWSBKWYOsmKSTMr = -483761.7861645892;
    double qbFBS = 857509.0820234788;

    for (int kwhAVJnJka = 1930499959; kwhAVJnJka > 0; kwhAVJnJka--) {
        icWsoYXb /= qbFBS;
        RsMPLWwjDERCDLwm -= icWsoYXb;
    }

    for (int WmjiXfDwjsajh = 605495173; WmjiXfDwjsajh > 0; WmjiXfDwjsajh--) {
        QoWSBKWYOsmKSTMr += UKLxEDrcM;
    }

    for (int tEjsBGAQdrYeuhC = 810862804; tEjsBGAQdrYeuhC > 0; tEjsBGAQdrYeuhC--) {
        qbFBS *= RsMPLWwjDERCDLwm;
        QoWSBKWYOsmKSTMr = LQEVsbl;
        vJDYftmqgq -= LQEVsbl;
        UKLxEDrcM *= LQEVsbl;
        vJDYftmqgq = qbFBS;
    }

    return XooOFzBE;
}

string zrSnZrASYHMlrgFZ::ruYhhXkIOvJ(bool mgAujGJJCP, bool wWvfAYLgsCmDCI)
{
    double uJFfE = 633683.1558702092;
    int uXxFk = 1428499649;
    bool wXAkiY = true;
    double xBKlKHMneKRzRMb = -806070.372900165;

    for (int FVeVBeLmxC = 1061182603; FVeVBeLmxC > 0; FVeVBeLmxC--) {
        continue;
    }

    for (int tuTbCSmlKlQ = 2030200577; tuTbCSmlKlQ > 0; tuTbCSmlKlQ--) {
        mgAujGJJCP = wWvfAYLgsCmDCI;
        wXAkiY = mgAujGJJCP;
        uXxFk -= uXxFk;
        wWvfAYLgsCmDCI = ! wWvfAYLgsCmDCI;
        wWvfAYLgsCmDCI = ! mgAujGJJCP;
    }

    if (wWvfAYLgsCmDCI != true) {
        for (int FewlqKCFncs = 1315720116; FewlqKCFncs > 0; FewlqKCFncs--) {
            uXxFk -= uXxFk;
            wXAkiY = wXAkiY;
        }
    }

    return string("ekzEqpDjgwypJZpVKKWUAFNuOrScfWuXUodPbKuPCgTSCsmhPuEiLuiwzzyVgSVsfmPbdOXcOIKbxoVysCuozBJBAqGGThvwFXoqpOYzCPxdBJJpXInWPymLGLzAULOJwHmBYtLeriVINFvFERRxKSNruSXwFjubwXnxDlXgXpephrQcEafPQesDvaELoOEbNYliSofCDqoAruAROahEXKCiEupqRMmkWVx");
}

void zrSnZrASYHMlrgFZ::CiTTazB(bool bzNlP, double WLktSDFphTnd, bool UqsRfEXMkheE)
{
    string xQSFFX = string("OAfYuQxaMwmaNMkcnLAPtBADQynXfsgXIrQjhLdGBLngIFfPFxBAuRCa");
    double hBWmJsbZerPEHe = -841202.1853588653;
    string lajsnDq = string("oLFNAuffiocxPaNVaOFzidzvqqliDucxvGEveInzYPNBXYVYQbyUSbeWuBtkbensRHUmHHOSqADHYYMcPcRGmSMMZLNnxgpxewSSMnBmtPUSjrGdMEbAwDmLrMgLGoParsfgaKZWnpDGEuoIuOWqLxVCkCOoxLGLOaYuzUfKqPXNfuzNKJduguUILckMMXTlMcJKvKkzkCUPutQlwJoPbiSqptVsnBuOizurKpmLiGIjYjwVzjqfamSOdf");

    for (int FUbspcbgxFhk = 1028821697; FUbspcbgxFhk > 0; FUbspcbgxFhk--) {
        continue;
    }

    for (int cVzuHHoKUWaBv = 432058007; cVzuHHoKUWaBv > 0; cVzuHHoKUWaBv--) {
        xQSFFX = xQSFFX;
        UqsRfEXMkheE = UqsRfEXMkheE;
    }
}

void zrSnZrASYHMlrgFZ::iLlXXsLvCLEJeLay(bool XbgnsUUslBGMQP, double HpQFwUwtY, string UUokyGyZeZYRtTl, double KxupgcuiHEJwgPH)
{
    bool SbQqoNvLBzLA = true;

    if (UUokyGyZeZYRtTl <= string("yEPNBOAIpOYyoHyOSdIuKrhLiKHCJvlEoxBhznrawINiQZWhYCEnCFTmAneHxpZeWHiXNLDFjHaLhVuqwJQLegkFOHxWIknXHFMfTcfUOHSCayEQBABjiUIREwsrFlUCkUCDmjMcgkqyAtprvTDjBXsxRmjWkNODJdhogqKGwTFMpCTUzPmVyPUQxZuHqDvWM")) {
        for (int QDSOmXPwqsINy = 1964050840; QDSOmXPwqsINy > 0; QDSOmXPwqsINy--) {
            KxupgcuiHEJwgPH /= KxupgcuiHEJwgPH;
            SbQqoNvLBzLA = ! SbQqoNvLBzLA;
            KxupgcuiHEJwgPH += KxupgcuiHEJwgPH;
        }
    }

    for (int bXJuVWJtWebmVswT = 783843057; bXJuVWJtWebmVswT > 0; bXJuVWJtWebmVswT--) {
        continue;
    }
}

void zrSnZrASYHMlrgFZ::UYUIdo(string iRuUjgLEEDyqxi)
{
    string HDVUswEwTrojX = string("hbGOJdGjbaoHhQzwusXsGEYDahXyXacWAVjWykhvNFsaDCsduErGjyGmBzMPYWqDZcFTzxSzCOlfwoBLWZRuDTynOuLOjmCtLJoWhQVYiLjQBUGkikFJpYTyyEUhnSTnXAVpFXfgKkJnkrgLgVMhRASpjhMPxUIEbQZuoLLmCgcfREJdjoHIeZQaSGSaVEOOQmCbWPEuUJmzsllcleBumLSvdlKwGMwOrQUNsQWZQVJFdtQwwvYipbfBzmNALY");

    if (HDVUswEwTrojX < string("cyaEwUNddmSnZgADIIxoAQLJJMBglZEppoXyCnHsNbVjxGXFenpwMCJcHYiRgUiitvnqmRkcScFqWOHKeIRRYsxUAJAPIXsprdYWfYyqSsUwgzwScZKKVBIMzbvcOjgKpGCeemTvnNsRERYWecoWEMzLgLbFgfIOTYruhlguCTebgaQbvDywnkrPJnaWbqAhMhGJvBBXFqo")) {
        for (int SknDkkqoeoLhX = 1167666007; SknDkkqoeoLhX > 0; SknDkkqoeoLhX--) {
            HDVUswEwTrojX = iRuUjgLEEDyqxi;
            HDVUswEwTrojX = HDVUswEwTrojX;
            HDVUswEwTrojX = iRuUjgLEEDyqxi;
            iRuUjgLEEDyqxi = HDVUswEwTrojX;
            HDVUswEwTrojX += iRuUjgLEEDyqxi;
            HDVUswEwTrojX = HDVUswEwTrojX;
            iRuUjgLEEDyqxi += HDVUswEwTrojX;
            HDVUswEwTrojX += HDVUswEwTrojX;
        }
    }
}

zrSnZrASYHMlrgFZ::zrSnZrASYHMlrgFZ()
{
    this->vZhEGLsp(string("DzDAckDtCKrLKffflfogMvlLlLamAjsfoTIDCaRNWHKHRCCiJYOjjZBrdzncWgPOzMLBOCvBCWGTGIMNhpEDibxcbmbMMIZKzvACeYqVoPwQXcfhJUBoXtWzHqczWVbjKPLwNOmnZbHpsTAHPmOArgrK"), false);
    this->bUTNCWFE(2123953299);
    this->EzAlIJF(string("fpBLVdhixgQsmsJPhObpNCJReSNGDTxtfkjhImTmyjenULfqOEzBZWNDsUCSWeSzvdLfNrxkSxzhhKB"), 64493.263991011445, string("ZoWNzUKBiTjMxsMuDLGxjmjcGnJGRRloDbnoojxcifjVeDZmXjTDaYxsWEPuWBLATXQNTtWZjNOmyxJPmoFFDptDhnZEDoORJIWsvRcaFptCicCKaOLZCcWVCMnzFTHNrtzZcWKCmpeByaUlFXJLrYBsNpNhLVpjrISmNzWdJwtaKsWsNOAPCyPAILompguCOabMM"));
    this->mIwWgrVUxyfa(405118.9882950882, false, 830751.6768773535, true, 796983610);
    this->ruYhhXkIOvJ(true, true);
    this->CiTTazB(false, 162465.55917956363, true);
    this->iLlXXsLvCLEJeLay(true, -651770.4132586322, string("yEPNBOAIpOYyoHyOSdIuKrhLiKHCJvlEoxBhznrawINiQZWhYCEnCFTmAneHxpZeWHiXNLDFjHaLhVuqwJQLegkFOHxWIknXHFMfTcfUOHSCayEQBABjiUIREwsrFlUCkUCDmjMcgkqyAtprvTDjBXsxRmjWkNODJdhogqKGwTFMpCTUzPmVyPUQxZuHqDvWM"), 250294.6129980057);
    this->UYUIdo(string("cyaEwUNddmSnZgADIIxoAQLJJMBglZEppoXyCnHsNbVjxGXFenpwMCJcHYiRgUiitvnqmRkcScFqWOHKeIRRYsxUAJAPIXsprdYWfYyqSsUwgzwScZKKVBIMzbvcOjgKpGCeemTvnNsRERYWecoWEMzLgLbFgfIOTYruhlguCTebgaQbvDywnkrPJnaWbqAhMhGJvBBXFqo"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cjKWaTyMZU
{
public:
    double MZntfXxEaMZubCbe;
    int VCKJAgeWtwgz;
    double YRHtH;
    double GreUklAB;
    double IpGcC;
    int jgKlKGzATZehz;

    cjKWaTyMZU();
    int zjYpTmbrvKR(string ReRqSWeRxYW, double jpJIgJICL, double UbwyfV, bool zaSCmQlzTYiBisQ);
    string bGVisKqQhmILmLPK(string RFzsEHGuxyUFfJw, double yFsCZXtpO);
    void DgpbW(int ByTNKC, string qGepKElBZtkBo, int repULoXMAnU);
    int VQjBiIaUsZ(string IAAiiWruUqGTUX, double fBFEcCM, double AbknypAmo, bool grfriGhdRuBlgvZQ, double IstirMjbVBLwws);
    double SfxPwwOaUUoh();
    int MngrQFVVg(bool RMRqlRqjS, double FffJPX, bool ebbyRePsunQ);
protected:
    double xfuRaXoElZkn;

    void Fnwuu();
    double OxOqHwnkeIhNwlg(double bRpFTywC, string mxfVElQdOK);
    string KpTwZhecSuYnQpYt();
    bool LTPrRlNvWs(bool cQYdpmZhiLlPjD, bool TPUvdSPv, string QyTeKg);
    bool BHoHuiy(double nBnbtjGhVaNxaQ, bool ZQNrnSpGTJeN, bool KdfnslsqbD, int adEjRsRS);
private:
    bool UGbezpq;
    double VFcdAVE;
    string IcwqLegUeG;
    double kUtMijrrzqAB;
    int AIwYrQKUf;
    double kTtjMflirbEe;

    double xeyRcjHncyVoUNQu(string mFKVhnDmNm, bool djLOw);
    double wmTyVTeJDpjP(double EsdYoXSXHiTkfBbk, int uruZhwX, int DZudak, bool pUrCUZUzBhk);
    void JibyhJtt(string ygTZV, string XZYfFzbYTl, double HHdHwScqspuS);
    void usiRJECqGr(double KKwygnLa, int utCpZGoZR, double OnImoS, string WKPGop);
    string hfefzKPddeNyNiUT(double HIwPPCseEOUcTp, double mkHlsnoqNd, bool QNsHGVzzSpzU);
    bool hhWFuTKRW(bool XmGXulPNhqVY, bool luTdARtLY, double EoVkUHVlKVd, string XymaWaN, int afEIhiBSazhyE);
};

int cjKWaTyMZU::zjYpTmbrvKR(string ReRqSWeRxYW, double jpJIgJICL, double UbwyfV, bool zaSCmQlzTYiBisQ)
{
    int CBlynoGV = -1708789063;

    for (int gvepQsfKEZV = 1028104152; gvepQsfKEZV > 0; gvepQsfKEZV--) {
        jpJIgJICL += jpJIgJICL;
        jpJIgJICL /= jpJIgJICL;
    }

    for (int kytiGwCmh = 913351722; kytiGwCmh > 0; kytiGwCmh--) {
        jpJIgJICL += UbwyfV;
        ReRqSWeRxYW = ReRqSWeRxYW;
        jpJIgJICL -= jpJIgJICL;
    }

    for (int gfdGs = 1399139496; gfdGs > 0; gfdGs--) {
        UbwyfV *= UbwyfV;
        UbwyfV *= jpJIgJICL;
    }

    return CBlynoGV;
}

string cjKWaTyMZU::bGVisKqQhmILmLPK(string RFzsEHGuxyUFfJw, double yFsCZXtpO)
{
    bool wqZYAH = false;

    for (int JfIbxQoIU = 2056881533; JfIbxQoIU > 0; JfIbxQoIU--) {
        continue;
    }

    for (int fLAslwhMMSdk = 1748330881; fLAslwhMMSdk > 0; fLAslwhMMSdk--) {
        wqZYAH = wqZYAH;
        RFzsEHGuxyUFfJw = RFzsEHGuxyUFfJw;
        yFsCZXtpO -= yFsCZXtpO;
    }

    for (int GyxkUCnhNqeiDJKg = 1887453314; GyxkUCnhNqeiDJKg > 0; GyxkUCnhNqeiDJKg--) {
        yFsCZXtpO = yFsCZXtpO;
    }

    for (int dEmaQM = 502397607; dEmaQM > 0; dEmaQM--) {
        continue;
    }

    return RFzsEHGuxyUFfJw;
}

void cjKWaTyMZU::DgpbW(int ByTNKC, string qGepKElBZtkBo, int repULoXMAnU)
{
    bool WBJBzFByKW = false;
    double uTLptrxCXeh = 100337.82591471107;
    double axdsYIBIsfa = -36675.33162378436;
    bool eCbzBH = false;
    int YSwcZjx = 494977740;
    int cfNcuCxia = -1430090489;

    if (YSwcZjx <= -2011536866) {
        for (int iqxCXCtVIridt = 409257629; iqxCXCtVIridt > 0; iqxCXCtVIridt--) {
            continue;
        }
    }

    for (int cEjERpl = 1026598191; cEjERpl > 0; cEjERpl--) {
        eCbzBH = eCbzBH;
        ByTNKC += YSwcZjx;
    }

    if (eCbzBH == false) {
        for (int HLjDURZic = 2059261810; HLjDURZic > 0; HLjDURZic--) {
            YSwcZjx /= ByTNKC;
        }
    }

    if (WBJBzFByKW != false) {
        for (int vIrbAnpNUTtdq = 1033265047; vIrbAnpNUTtdq > 0; vIrbAnpNUTtdq--) {
            continue;
        }
    }

    for (int eRqDmiJqk = 1158043817; eRqDmiJqk > 0; eRqDmiJqk--) {
        continue;
    }
}

int cjKWaTyMZU::VQjBiIaUsZ(string IAAiiWruUqGTUX, double fBFEcCM, double AbknypAmo, bool grfriGhdRuBlgvZQ, double IstirMjbVBLwws)
{
    string lIzZkSieISTVEw = string("XZwAjrSmCHlCMqOpRzlFvbgzCmuztWSFIwPZTNWLifNBkQp");
    bool zvsCbxb = false;
    string rzvcB = string("srnpePvCsKvMsyvAkfPWRXwdAhktleeNEyvVeWCoxEkiyRzejmrAgMBPJOtBZrgMGNyxymMNfKlawJuSFGNmXRcjeJMDvGeVhmWrLbTRQPoEbwPHrDgoaVKboYFoOtZNBqxBeRHbCnEpMfXWZvJHspMDSjFOBwXCNirwsJxsFHDbLmIHMwofnARpSLjMwadJdo");
    string SBoRrOdLiavz = string("gYBMEygfyKKrqBcrljvZCuMkOJDtZiUfnixoGdIqqzfkyFfHQjMndslKtyuIwWlqgQICEhbNCctprKifLQaRiBFbAXCkBetHXYnnsvDDxhfRIEwFyzrbTkGiHmwDGCIRzQYJzIYlyBIvxQMiVpujVDoAygXHlnAoERVeDQsDAzkncqYDOPPsoaAHrErHkjrtPMxfCdwpqUpQncgAvNWUa");
    bool XBfkSxMWoSHKyaws = false;
    string ARVJETDvi = string("uUtXbqZrUxNTYjBIBFuhfCPxdArIimQAxmmyvyMmVytUIqLTudAvoByRBMidPgljvxQoXFxJmPHEb");
    double EiogjgnpmVlZD = 1020233.9719012626;
    double dMOfUpOMQhEualPU = 127363.15626247783;
    string zmjWkuioxK = string("IXDMTMHCDBJWlmbVPtcNnMtWBnqizbUgcvlMGhtVuStyXKdXUbHozcAZVkWJtpCfftaQZXZ");

    for (int IwmsOiE = 1811605255; IwmsOiE > 0; IwmsOiE--) {
        ARVJETDvi = ARVJETDvi;
        dMOfUpOMQhEualPU = IstirMjbVBLwws;
        AbknypAmo *= IstirMjbVBLwws;
    }

    for (int wAdSWlbmWgZzaL = 635116416; wAdSWlbmWgZzaL > 0; wAdSWlbmWgZzaL--) {
        rzvcB = zmjWkuioxK;
        EiogjgnpmVlZD *= IstirMjbVBLwws;
    }

    for (int JpTjUqxEvDtBdC = 1507985725; JpTjUqxEvDtBdC > 0; JpTjUqxEvDtBdC--) {
        zmjWkuioxK += IAAiiWruUqGTUX;
    }

    for (int uXEPnpWFs = 2081410544; uXEPnpWFs > 0; uXEPnpWFs--) {
        continue;
    }

    return 826521223;
}

double cjKWaTyMZU::SfxPwwOaUUoh()
{
    int DrgXiEfm = 2135112170;
    int GcXZLySh = -1174289296;
    int LhUWeenu = 1875194496;
    int QurHCiNvRk = 1806713321;
    int JgNzuQgnOlb = -339644794;

    if (JgNzuQgnOlb >= 1875194496) {
        for (int qLSyLbwqN = 2137035868; qLSyLbwqN > 0; qLSyLbwqN--) {
            QurHCiNvRk /= JgNzuQgnOlb;
            JgNzuQgnOlb -= QurHCiNvRk;
        }
    }

    if (DrgXiEfm == 2135112170) {
        for (int tjjUDDiOKpuieX = 424409792; tjjUDDiOKpuieX > 0; tjjUDDiOKpuieX--) {
            JgNzuQgnOlb *= JgNzuQgnOlb;
            JgNzuQgnOlb -= QurHCiNvRk;
            GcXZLySh -= QurHCiNvRk;
            DrgXiEfm -= GcXZLySh;
            DrgXiEfm /= LhUWeenu;
            DrgXiEfm += JgNzuQgnOlb;
            JgNzuQgnOlb -= JgNzuQgnOlb;
            GcXZLySh *= LhUWeenu;
        }
    }

    if (JgNzuQgnOlb >= -1174289296) {
        for (int gJenpjESTTOcacxy = 1699666141; gJenpjESTTOcacxy > 0; gJenpjESTTOcacxy--) {
            GcXZLySh += GcXZLySh;
            QurHCiNvRk = JgNzuQgnOlb;
            DrgXiEfm /= JgNzuQgnOlb;
            LhUWeenu += QurHCiNvRk;
            GcXZLySh = DrgXiEfm;
            DrgXiEfm /= JgNzuQgnOlb;
            JgNzuQgnOlb /= LhUWeenu;
            DrgXiEfm /= JgNzuQgnOlb;
            DrgXiEfm *= JgNzuQgnOlb;
        }
    }

    if (LhUWeenu == 2135112170) {
        for (int ydRKLgGygUnu = 2146039479; ydRKLgGygUnu > 0; ydRKLgGygUnu--) {
            JgNzuQgnOlb /= DrgXiEfm;
            QurHCiNvRk += GcXZLySh;
            LhUWeenu += GcXZLySh;
        }
    }

    return -46140.020424129885;
}

int cjKWaTyMZU::MngrQFVVg(bool RMRqlRqjS, double FffJPX, bool ebbyRePsunQ)
{
    string ZIjPyTWwLS = string("bScbQqpmBFddjNsLfwVXlfDawLCDBJTpjeHfqqBcgZCblPjuaeZOOytjo");
    bool wVVYeCfqdzNwhzJn = true;
    int JYyTFO = -1270859280;
    string QmaLacVLgA = string("sQkfCnedUKLDENLKXPZNDcoSmCiCQtrifhSrqqwpCcFlKzNDxxfRasZRdUjyYuiBMQjXDqJSAILjkzWABeTZQWHFDAYvBBTEsYdIEfJzWxtkQITrTowilhQPzPdHWitDtHXrKjaNNoJIBvEUCJTfOoRHbupUncDStzGVPdzXFtfMvAEohUeQJbPensBlsxQhlFbcUceBeScpTmrYPysBYwREIdtHdqmILsBbFKUDIkwoqgjNKnlAQoIcAkxxY");

    for (int jhoNuAqLqxrTUnr = 1945253481; jhoNuAqLqxrTUnr > 0; jhoNuAqLqxrTUnr--) {
        JYyTFO -= JYyTFO;
        ZIjPyTWwLS = QmaLacVLgA;
    }

    for (int DDFuLyBcEQz = 1390234125; DDFuLyBcEQz > 0; DDFuLyBcEQz--) {
        QmaLacVLgA = ZIjPyTWwLS;
        RMRqlRqjS = RMRqlRqjS;
        RMRqlRqjS = ! RMRqlRqjS;
    }

    if (RMRqlRqjS != true) {
        for (int FqpxMa = 166576333; FqpxMa > 0; FqpxMa--) {
            JYyTFO += JYyTFO;
            RMRqlRqjS = RMRqlRqjS;
            wVVYeCfqdzNwhzJn = ! wVVYeCfqdzNwhzJn;
            ZIjPyTWwLS += QmaLacVLgA;
            ebbyRePsunQ = ! wVVYeCfqdzNwhzJn;
        }
    }

    for (int GlXlX = 182606275; GlXlX > 0; GlXlX--) {
        RMRqlRqjS = ! wVVYeCfqdzNwhzJn;
    }

    return JYyTFO;
}

void cjKWaTyMZU::Fnwuu()
{
    string qSMnyRsLpjNY = string("lHoeEMbbutktPUaClJEYYSpdWKwKUPumEulRIiyximZNBxzQKoEdlHAsArEmdHUzhnwKvVODHInUhGcDMyipjzYNYdlxRiBnOczzxDuqRaJMNBtVXVXJcPYyZKRmYmVfoYYhvvaMNDQyLABmtEjQEpTiLwBpGROkzRYJxSaHUxJzMamSwKCpUWmwtVOqEqTkVvWTaK");
    bool qjjNx = false;
    double VDkHeHXmOomMo = -938842.8660708066;
    string SuCqZF = string("ioAupQGlmBBYvfpCgSXLUvrfJeXbFNtPVHsQdqlLITiKFbfXEUSLWhqXQrkAgolBJGEvqmJSrHROIgUhBibckkiAKlzpoSxryurlMBoxTbnOvQgKKyGniDNRSvDUorXXyGnCybijEbyUfrWnvKOPeyhhYMrEwJZ");
    bool GnrsPqbK = true;

    for (int KQktCvdNXMEygeFA = 803053763; KQktCvdNXMEygeFA > 0; KQktCvdNXMEygeFA--) {
        SuCqZF += qSMnyRsLpjNY;
        GnrsPqbK = qjjNx;
    }

    for (int ebVewTHXfxR = 973330452; ebVewTHXfxR > 0; ebVewTHXfxR--) {
        qjjNx = qjjNx;
        qjjNx = qjjNx;
        GnrsPqbK = ! GnrsPqbK;
        qSMnyRsLpjNY += SuCqZF;
    }

    if (SuCqZF == string("lHoeEMbbutktPUaClJEYYSpdWKwKUPumEulRIiyximZNBxzQKoEdlHAsArEmdHUzhnwKvVODHInUhGcDMyipjzYNYdlxRiBnOczzxDuqRaJMNBtVXVXJcPYyZKRmYmVfoYYhvvaMNDQyLABmtEjQEpTiLwBpGROkzRYJxSaHUxJzMamSwKCpUWmwtVOqEqTkVvWTaK")) {
        for (int mUoHxksbC = 175344593; mUoHxksbC > 0; mUoHxksbC--) {
            continue;
        }
    }

    for (int tNQTvhX = 1034803569; tNQTvhX > 0; tNQTvhX--) {
        GnrsPqbK = qjjNx;
        SuCqZF = qSMnyRsLpjNY;
        GnrsPqbK = ! GnrsPqbK;
        qjjNx = qjjNx;
    }

    for (int gwuFB = 1848405796; gwuFB > 0; gwuFB--) {
        VDkHeHXmOomMo = VDkHeHXmOomMo;
    }

    for (int YUGHasJuqibuRq = 908483965; YUGHasJuqibuRq > 0; YUGHasJuqibuRq--) {
        GnrsPqbK = ! GnrsPqbK;
    }
}

double cjKWaTyMZU::OxOqHwnkeIhNwlg(double bRpFTywC, string mxfVElQdOK)
{
    string ngGaS = string("KGvpZxomlHiTnScGPlmpWRpCoPKrgfkALKUfpQhEgA");
    string vNNCZWJGsHZgzV = string("yQVinpkrfOjnhFRZbxpcMToGmeqcLoOrOnoxHDiGvHxYBKzYCYkeOmGBBkKyPYzzHqwwZQTchvvLBsxapTlRYeYSVRtockWRsUUMHbtQQRBBjpWyFtGVPZymWrypHcdVkegQwGCfvdoBTugHrFYEKyluAZDTWfNDRqWnwynwouFKGRCrEEFZFaU");
    int ctuDxHIYCfvUaJ = 746220646;
    bool seryOXlc = false;
    double nxZOCHblnnRnpxhV = 429253.81432308326;
    string HYucL = string("WWOAAHNjXHfyuGtWqGcoDakOacvSNnTBtVesMNecRxQIefGiDFSQedmqptaOFPMfjiglppOACpvhxRzHKPTJadAaxdhTKAycINtTGSHKTmUeCbAYzsXLHrnI");
    string SAXKcgTE = string("nMThLQXXNRLfzDcmlfIvYJznlulGRWdpHWXeqxQsbeoInPihK");
    string vOWblYiAKtCEFhj = string("SdKetxldbDHQqItRpZoFnbeXoMIVQpdTxiZRwQnZeebQsiXTuJAXzQEQWflsitBpyYsonGDwhGmHVLZoudRzXMIAOEhGoelYRGjFIbiSeCFpThotvzzrcrjqyXuVMbteUAmEkOw");
    string IiDrbPzevRQBHH = string("WbtwarGWsQFIkTdLlBjDDjGJLffxdSsJKdNlclQqwoOafyiDdsvpLLUpoEYcGOarbSwCsPmZAFMxVTwOzYaZRPUtoW");

    for (int zwqhYUIdxwHrDMR = 1944997373; zwqhYUIdxwHrDMR > 0; zwqhYUIdxwHrDMR--) {
        ngGaS = IiDrbPzevRQBHH;
    }

    if (IiDrbPzevRQBHH == string("WWOAAHNjXHfyuGtWqGcoDakOacvSNnTBtVesMNecRxQIefGiDFSQedmqptaOFPMfjiglppOACpvhxRzHKPTJadAaxdhTKAycINtTGSHKTmUeCbAYzsXLHrnI")) {
        for (int mwjussYLr = 1274024107; mwjussYLr > 0; mwjussYLr--) {
            IiDrbPzevRQBHH += ngGaS;
        }
    }

    return nxZOCHblnnRnpxhV;
}

string cjKWaTyMZU::KpTwZhecSuYnQpYt()
{
    string owjPggp = string("fezWQGevYkVbDMg");

    if (owjPggp == string("fezWQGevYkVbDMg")) {
        for (int fNGqW = 955407673; fNGqW > 0; fNGqW--) {
            owjPggp += owjPggp;
            owjPggp = owjPggp;
            owjPggp += owjPggp;
            owjPggp += owjPggp;
            owjPggp = owjPggp;
            owjPggp += owjPggp;
            owjPggp = owjPggp;
            owjPggp = owjPggp;
        }
    }

    if (owjPggp > string("fezWQGevYkVbDMg")) {
        for (int mKjDl = 581762539; mKjDl > 0; mKjDl--) {
            owjPggp += owjPggp;
            owjPggp = owjPggp;
            owjPggp = owjPggp;
        }
    }

    if (owjPggp > string("fezWQGevYkVbDMg")) {
        for (int yIReqjWpEEub = 320267253; yIReqjWpEEub > 0; yIReqjWpEEub--) {
            owjPggp += owjPggp;
            owjPggp += owjPggp;
            owjPggp += owjPggp;
            owjPggp = owjPggp;
            owjPggp = owjPggp;
            owjPggp += owjPggp;
            owjPggp = owjPggp;
            owjPggp += owjPggp;
        }
    }

    return owjPggp;
}

bool cjKWaTyMZU::LTPrRlNvWs(bool cQYdpmZhiLlPjD, bool TPUvdSPv, string QyTeKg)
{
    double htQAnSPuoj = 641945.6644689627;
    bool gMFfTrmKvZd = false;
    bool xiSmXyunyLSe = true;
    int MdNLllHS = 237456984;
    int SfevfPLFR = -1691918963;
    int eCzpl = -882038230;
    bool JMLagFeOlwbbpx = true;
    string VYcoPO = string("rRjZiXtmUbqTyZJlIUqNwGwvvIIUqcxPIfXQHLGjAdzmgbhXFdQPKwAAiRLBXYQRfKkAThLGOetRBIJqGQbfqUSknBRArKiXziDTBPbvgbYXpNHUMIDmOwBZVMf");
    double RAKsnOVYhe = -1025866.3577046575;
    double BWNoKr = -40547.26633066059;

    for (int haPjoizsJFqgfIv = 1412622738; haPjoizsJFqgfIv > 0; haPjoizsJFqgfIv--) {
        continue;
    }

    for (int sOpaawrGdwmtmEm = 1237132812; sOpaawrGdwmtmEm > 0; sOpaawrGdwmtmEm--) {
        continue;
    }

    return JMLagFeOlwbbpx;
}

bool cjKWaTyMZU::BHoHuiy(double nBnbtjGhVaNxaQ, bool ZQNrnSpGTJeN, bool KdfnslsqbD, int adEjRsRS)
{
    double rYTPFIAjfmOHg = 538113.3813224542;
    bool cImnJjs = true;

    for (int HYvew = 224604793; HYvew > 0; HYvew--) {
        continue;
    }

    for (int WQWChUfDpN = 47288663; WQWChUfDpN > 0; WQWChUfDpN--) {
        continue;
    }

    for (int kOoJtANJ = 1169836959; kOoJtANJ > 0; kOoJtANJ--) {
        ZQNrnSpGTJeN = ! KdfnslsqbD;
        rYTPFIAjfmOHg /= nBnbtjGhVaNxaQ;
        KdfnslsqbD = KdfnslsqbD;
        KdfnslsqbD = cImnJjs;
    }

    if (nBnbtjGhVaNxaQ <= 538113.3813224542) {
        for (int LibLi = 354635188; LibLi > 0; LibLi--) {
            ZQNrnSpGTJeN = ! cImnJjs;
        }
    }

    return cImnJjs;
}

double cjKWaTyMZU::xeyRcjHncyVoUNQu(string mFKVhnDmNm, bool djLOw)
{
    int yXlbYOHlediMb = -1619698419;
    string JZtLNyAkpNaoqovl = string("CjNsXnwJXyCHBURHLVyQzUhxaHloOIOQXdtaqiwxcJzXaZbCdKCUqFVlnnAqiscxbAvejFpBFlQltZGSQyJGNfvSSzNmwEowxPdAAAJeeiL");
    double sLzYiryqwYkpsZap = 743990.9896040268;
    bool nbNohUIu = true;
    double WSgmeSW = -564556.695542928;
    string hilSNWa = string("SQXcaKhQNbXOMmUEVCRdbDQPM");
    int OntlopWuUVUxyMuw = 1605225047;
    int NUxptRGmEnaTwoI = -978073123;
    int SvXnjWoAzvSm = 339558373;
    string WCUDrMF = string("MaCLKAZUdVkRMtOnVXpryOUIPjmdBLqhUtbgXJAXqmWvbnWRkTmPcAYSztPhOwJheHlODhcvWBirrDOVBbJmSdMvjoujLpXrttbOrfkCPiriWAEQdEsmCxXIyXCeXFKVTbwpAZScvojwwFjduiXzzRElGOICLJSKbCZeYNaYEP");

    if (WCUDrMF <= string("MaCLKAZUdVkRMtOnVXpryOUIPjmdBLqhUtbgXJAXqmWvbnWRkTmPcAYSztPhOwJheHlODhcvWBirrDOVBbJmSdMvjoujLpXrttbOrfkCPiriWAEQdEsmCxXIyXCeXFKVTbwpAZScvojwwFjduiXzzRElGOICLJSKbCZeYNaYEP")) {
        for (int tSzliMi = 1091346652; tSzliMi > 0; tSzliMi--) {
            NUxptRGmEnaTwoI /= OntlopWuUVUxyMuw;
        }
    }

    if (mFKVhnDmNm > string("CjNsXnwJXyCHBURHLVyQzUhxaHloOIOQXdtaqiwxcJzXaZbCdKCUqFVlnnAqiscxbAvejFpBFlQltZGSQyJGNfvSSzNmwEowxPdAAAJeeiL")) {
        for (int dXdofpJcqGpVFv = 456452076; dXdofpJcqGpVFv > 0; dXdofpJcqGpVFv--) {
            continue;
        }
    }

    for (int VlaWzstkZH = 1510473029; VlaWzstkZH > 0; VlaWzstkZH--) {
        mFKVhnDmNm += JZtLNyAkpNaoqovl;
        OntlopWuUVUxyMuw /= NUxptRGmEnaTwoI;
        WSgmeSW *= sLzYiryqwYkpsZap;
        yXlbYOHlediMb /= yXlbYOHlediMb;
    }

    if (hilSNWa != string("SQXcaKhQNbXOMmUEVCRdbDQPM")) {
        for (int NbJCIufkB = 417371048; NbJCIufkB > 0; NbJCIufkB--) {
            OntlopWuUVUxyMuw *= NUxptRGmEnaTwoI;
        }
    }

    return WSgmeSW;
}

double cjKWaTyMZU::wmTyVTeJDpjP(double EsdYoXSXHiTkfBbk, int uruZhwX, int DZudak, bool pUrCUZUzBhk)
{
    string pnTRoMafYex = string("YvzNMhmkiiyHWESKEIlrTNYxgiPGqBSLGbxSGIxpKAkWYDJiBjVIsunbKuBPkcTZpduaeGEkaPxFJnouEoOmcCrltLukPKmBQfJnVPrXXIjbUrBOpAeJDMRecZuoepACckTLRdtaDmgmOQSkiEyZvpEWpFmyYOmNxURZB");
    double afUwmgpuYO = 585197.1658876869;
    int LWvluffCmpxf = -935773837;
    double lNDUAgoMFFo = 961584.5188495235;
    bool fBfUhLVINTRAT = true;
    bool wpwggAUcgyP = true;
    string KtsimpV = string("sPlEYzGVcbrvQJcknGWChKOXHirHOLIwBKztxzcSHXzFKIhfEermGqkQLUbxRoglHOKXQwMgkBVHRtIRHYLLmTeaWaIQWITaKLlzonqoLGEOHaNGsZplewSm");
    double WchBCOB = -522980.5371893258;
    int xaPUMOKSKkykRF = 1005050903;

    return WchBCOB;
}

void cjKWaTyMZU::JibyhJtt(string ygTZV, string XZYfFzbYTl, double HHdHwScqspuS)
{
    double GsCLeHDE = 946629.5999731448;
    string vfeOClyUZBH = string("wIqUIsETMyXSWRdmdvHHKiXOkeepFlSHAQZPZsSbfqjUKSEMvkjVtMtSSMPypEDrNAxHQtFiDnat");
    double ZpqWGagM = 669462.5369788674;
    string UvXCLkxiy = string("BAgvmQiMfIHmyyRPYCsnrDugsWSaJynRcZXnhvjFPoqylgyUZqnGyEceqDQpnLQgzMSwfKMyZXDHvVonhliIjaBSVYeGuvaKUJRbpdGhjTCCzfSwaRsuoxrOKVxOqfVPrEjlKieHVyZEDRmmkhSiYHOmkmXGzDpiBQBbrBWQuAAuBIQoHJhIOwJFZpwdciR");
    bool EeJwAQwclsGcVNX = false;
    bool cVPcgr = true;
    bool zIQQGqGwuwcs = false;

    for (int lXVBIUMASXxK = 1848063543; lXVBIUMASXxK > 0; lXVBIUMASXxK--) {
        EeJwAQwclsGcVNX = ! EeJwAQwclsGcVNX;
        cVPcgr = zIQQGqGwuwcs;
        XZYfFzbYTl += ygTZV;
        UvXCLkxiy += vfeOClyUZBH;
        cVPcgr = ! EeJwAQwclsGcVNX;
    }

    for (int LzzwtX = 1073698019; LzzwtX > 0; LzzwtX--) {
        XZYfFzbYTl = XZYfFzbYTl;
        cVPcgr = EeJwAQwclsGcVNX;
    }

    if (XZYfFzbYTl < string("gWzqPVNDVuqngsMRgPKWEJPcKEuFpKfZQxXmKasPPvBWghgdhCxlqZqQeRMrUzdgvEUArQpWODDjtUtxWfkzlQCAignhuQZMOkhjvruZzoQXXwntCOGEWbDbmHBndaUAOTgmkxMZDYjemZipfVCyxrDCDSearSDMsSnPEdvXMwhXgiNfcWWXDtWCRtEjfXboioHKlsnQrNZqbqiyOaizslYeHnjRSIfBRbDMgKM")) {
        for (int XjXWhmJbyyqwlhU = 5685453; XjXWhmJbyyqwlhU > 0; XjXWhmJbyyqwlhU--) {
            zIQQGqGwuwcs = ! cVPcgr;
        }
    }

    for (int eoDpigNhTjl = 397724125; eoDpigNhTjl > 0; eoDpigNhTjl--) {
        UvXCLkxiy = vfeOClyUZBH;
        zIQQGqGwuwcs = EeJwAQwclsGcVNX;
        cVPcgr = ! zIQQGqGwuwcs;
    }

    for (int oQiconwxcvQJ = 1895490126; oQiconwxcvQJ > 0; oQiconwxcvQJ--) {
        cVPcgr = ! cVPcgr;
        GsCLeHDE /= HHdHwScqspuS;
        ygTZV += XZYfFzbYTl;
        XZYfFzbYTl += XZYfFzbYTl;
    }

    if (vfeOClyUZBH > string("BAgvmQiMfIHmyyRPYCsnrDugsWSaJynRcZXnhvjFPoqylgyUZqnGyEceqDQpnLQgzMSwfKMyZXDHvVonhliIjaBSVYeGuvaKUJRbpdGhjTCCzfSwaRsuoxrOKVxOqfVPrEjlKieHVyZEDRmmkhSiYHOmkmXGzDpiBQBbrBWQuAAuBIQoHJhIOwJFZpwdciR")) {
        for (int kIUaoXvoVTGFGKxV = 9575484; kIUaoXvoVTGFGKxV > 0; kIUaoXvoVTGFGKxV--) {
            HHdHwScqspuS = HHdHwScqspuS;
            cVPcgr = ! cVPcgr;
        }
    }
}

void cjKWaTyMZU::usiRJECqGr(double KKwygnLa, int utCpZGoZR, double OnImoS, string WKPGop)
{
    bool TnmHjoaGynrrfz = true;
    bool aFdXQaArb = false;
    string FiBpenOGpanwHhHt = string("qcXYMWBNMxuWMrNXBwWIdXWWxIpbsfchTUzxrGjeNzGawlOLFHfJoHNtRBltzWALppwDafgpIS");

    if (WKPGop <= string("RsPnTrOukPhZQpejobVVdUYf")) {
        for (int IaewInYzCx = 549562764; IaewInYzCx > 0; IaewInYzCx--) {
            continue;
        }
    }

    for (int bkzSozeEnrBLmgC = 2061847266; bkzSozeEnrBLmgC > 0; bkzSozeEnrBLmgC--) {
        OnImoS -= OnImoS;
        TnmHjoaGynrrfz = ! aFdXQaArb;
        FiBpenOGpanwHhHt = WKPGop;
        WKPGop += FiBpenOGpanwHhHt;
    }

    for (int pqzeoJRFMTAKjPaK = 1003320412; pqzeoJRFMTAKjPaK > 0; pqzeoJRFMTAKjPaK--) {
        OnImoS /= KKwygnLa;
        aFdXQaArb = ! aFdXQaArb;
    }
}

string cjKWaTyMZU::hfefzKPddeNyNiUT(double HIwPPCseEOUcTp, double mkHlsnoqNd, bool QNsHGVzzSpzU)
{
    int fjmqlccHbYB = -1543382267;
    string gcolfcGsjqwOqH = string("EHzlJiRqqWyjgTj");
    string IafagKAywonttq = string("WNbzOPMriACxeNAymmpEVaAdBvzT");
    bool jcnBHpjJIOnK = true;
    int FbsSLmcjodtS = -1754463755;
    bool jHrzrt = false;
    bool OditPIdqqVAeeH = false;
    string uDbnGjnFMrGSAW = string("qqRoUPgqoBlvWuJTgXSUfVrhancvFPidIajrlRtZEKSXubBOTtHGQZocvrhJPArhLaNLncDCYqRkjvyNqpIYKPlOESUXIXldmmYgliOHhjXEzyMoSGXdcWSQuNEtKYXUbclHDgJLuNbGKcuKgwAkERLhxjNHwncugDEbAPtaNbfPFwAIfQKDpEgGLFbzNLBIkxNDqPcWhAwiiFhLMAcRblAVfrSRVwAaUjUhLCfYtuLXFHYoSlMuWD");
    double UcqOaTO = -697542.7882328219;
    double lvitbJNqwIQeCKHH = -969507.1398077793;

    for (int FvBCtjQO = 192886472; FvBCtjQO > 0; FvBCtjQO--) {
        OditPIdqqVAeeH = OditPIdqqVAeeH;
        lvitbJNqwIQeCKHH = HIwPPCseEOUcTp;
    }

    for (int GGePjjZAFKsWkB = 1798317445; GGePjjZAFKsWkB > 0; GGePjjZAFKsWkB--) {
        HIwPPCseEOUcTp = HIwPPCseEOUcTp;
        lvitbJNqwIQeCKHH -= lvitbJNqwIQeCKHH;
    }

    for (int HjHKPXnzKPmXNBg = 1804209964; HjHKPXnzKPmXNBg > 0; HjHKPXnzKPmXNBg--) {
        mkHlsnoqNd *= HIwPPCseEOUcTp;
        gcolfcGsjqwOqH += IafagKAywonttq;
    }

    for (int FgBuVGyqXzaOvlD = 128293512; FgBuVGyqXzaOvlD > 0; FgBuVGyqXzaOvlD--) {
        jcnBHpjJIOnK = jHrzrt;
        jHrzrt = ! jcnBHpjJIOnK;
    }

    return uDbnGjnFMrGSAW;
}

bool cjKWaTyMZU::hhWFuTKRW(bool XmGXulPNhqVY, bool luTdARtLY, double EoVkUHVlKVd, string XymaWaN, int afEIhiBSazhyE)
{
    double ZXivAMhfeBkflUt = -352856.05892309133;
    int fYVsvlpihXWRlDw = 2065663039;

    if (fYVsvlpihXWRlDw < 2065663039) {
        for (int UlGjQrk = 716827243; UlGjQrk > 0; UlGjQrk--) {
            continue;
        }
    }

    return luTdARtLY;
}

cjKWaTyMZU::cjKWaTyMZU()
{
    this->zjYpTmbrvKR(string("bozIFFoTlNuaAYnKIWAcizbikPQhkCIuejOUruGbnywmDUvAajFaFBVdrbqWTvWfQUziBwYeGPxLPCUrcisGXrJyBOuSeasBzgQafCcvVUukNzk"), -592319.8036514156, 882597.4835844111, false);
    this->bGVisKqQhmILmLPK(string("sRISYjkJXInEMYASkESOmBEfREWRYlatsfVDFAuSbNsagvySNousNhJeflhJUdckXNMHPHnzcLbSzuooBWKWYSFzKndtIRjuwWNJavSQGubglyPWhNrGOpIOrjNpX"), -394501.2865391657);
    this->DgpbW(178474683, string("TQbgEvhwtDzzqdUyEVohvAfbaOmXQmLMuRLGKpFdlZihFkrasbBWPugIBZgpIMSKXSZjFimrNSDSHUdTTqDRCyHVnifjviOqnHtpzCsjXrVpUWsidtcngAVEhjAVhjwDceLdwMBmKBhZrAOCMxqZkNItkSRtxnctNuFikEGpoYDzFgGExgYXWOOscQGQTiDgEBfMB"), -2011536866);
    this->VQjBiIaUsZ(string("GkUISYAmPegprbPGgUkVmeDbGAiwFlxVwnRiLMQYOjLLcIkwsgkrhUzHVHtdYhrlXpdbgZQQVrpbzvpflhfIwYSiYRwqioPsflXfyNIhiYVPBcXeHQSvcrcufiuwfKPKjQiTkkcEjCUnqroFcPmZvtCwGFlPn"), 808347.4819586781, -187530.92538267394, false, 24162.8147908154);
    this->SfxPwwOaUUoh();
    this->MngrQFVVg(false, 197290.748551083, false);
    this->Fnwuu();
    this->OxOqHwnkeIhNwlg(-634098.4466683944, string("sexsTuSnoXArbgNUbBmqUYYxxYjaKuJWEWhnvrHToULtzscxppzkSThCZFiToBNUUCWnvQIwNfQYQmexgfbYTacwflADjNuXXpfcgniONinBbFSESFSxHKhDJqqdVMCnVLEbGg"));
    this->KpTwZhecSuYnQpYt();
    this->LTPrRlNvWs(true, true, string("yQoPaetRqOvgmmxFwXPTMTIaNSlfdWJxaajxtxQRDaCBEaEZrNoClmXuJPNhTNwkSMJmrozrpqvmvBlmVyvKulRWJJWWKUYJGLFDSnmvycrbvIxesBu"));
    this->BHoHuiy(143512.0925335296, true, false, 542948910);
    this->xeyRcjHncyVoUNQu(string("BuUJIgavfiLuvGuufLvNDLwbJcoqOFDZOirQXtHhbaMeHrOKtlqDngphXpjKfKNnvWjPaUxkEFo"), false);
    this->wmTyVTeJDpjP(447051.0317268426, 1589972619, -852564119, true);
    this->JibyhJtt(string("TIcXwAmJShcjNLPkSWawyniazcIKUsTpveGdZZzTASwaMfFuIiUALMLmjeLeMpeOOTKLHORKuWAfdoaHpjqHQwELXTVJdunIvDnqMJtuVeRzsCgGEmcqQPIGbuyCmQjDXFSCMOStrXdfyJxKxkMcTQZkQnfRQyitvbvKZwvbeakcQYMkvkDdtSHrBkKcOeScRKDebxvNNYaoJBmb"), string("gWzqPVNDVuqngsMRgPKWEJPcKEuFpKfZQxXmKasPPvBWghgdhCxlqZqQeRMrUzdgvEUArQpWODDjtUtxWfkzlQCAignhuQZMOkhjvruZzoQXXwntCOGEWbDbmHBndaUAOTgmkxMZDYjemZipfVCyxrDCDSearSDMsSnPEdvXMwhXgiNfcWWXDtWCRtEjfXboioHKlsnQrNZqbqiyOaizslYeHnjRSIfBRbDMgKM"), 718493.9965986153);
    this->usiRJECqGr(-440751.65358776954, 1025177079, 381706.3023838548, string("RsPnTrOukPhZQpejobVVdUYf"));
    this->hfefzKPddeNyNiUT(911881.3637821871, 481830.635570474, true);
    this->hhWFuTKRW(true, true, -408122.53244890185, string("TKqYdQvVRZvAshbwbUDPxRckqnVTtaWScmIAqcuIBFpA"), -1887060);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EWDEUGCwgUKEQOjY
{
public:
    int vTRSBFLdpsBfQb;
    string ByiaVNFxhQ;
    double waxJmVrG;
    int pNdJQdj;

    EWDEUGCwgUKEQOjY();
    string JWmTYIRqCBxgC(string dTCJARTMzGDOw, string pEtbfDjmml);
    int KsjwgO(string KKezaVEtcCxMFH, int fdZuVmmCUJnyS, double tdxOrexHKblu, string CYpWH, bool aywpDHNcg);
protected:
    int SSSwoWKi;
    string nDrvnmUYSdAhZSnf;
    int SdBdxelokHFbFc;

    string hHmVhwNHqz(double lHclvcGrkTiSiqw, bool TFiyCO, double sGfByIqRZkfyhez);
    bool kxkDbWdfmz(bool Fyaij);
    int zMhvfHwyCPC();
private:
    double nSbpQkiqWUqffa;
    double lOFxc;
    double RZVYO;
    bool OlVSlkrWlbI;
    int tTGWyqbWoYl;
    string dHYIhdyT;

    bool JMAkVzdEXUAcOof(string kuwGxwWNTeeWlhxW, int yuKgo);
    int OMPYneHzYi();
    int wLScjCzhjCGyIU(bool srUmdmfiGfWZlDJ, int dRklhLAaiT, int zpbqjUleLuT);
    bool ovHHUfTXTMUr();
    double UGxPfxErkyIw(bool hPvSyOzngPYwZGpF, double wXGdmpNhRLXCfK, string nVpQLHKStVjfczsx, double CQXgwakY, int ABkhlpA);
    bool JFNIiPdF(string iQQAkerAbReiCs, string UZrWCboTHQXkX, double XtCMKFIKwJWvoKP);
    bool LyTbgwgrQGMrh(double vYXBkvJMZeP);
    string SrSMuKaprSZGpa(bool zcKNHnNAFWBSjFk, double QRiUhiKqXvMX, bool XEwCBkXfXwoAQK, int NDOrDHp);
};

string EWDEUGCwgUKEQOjY::JWmTYIRqCBxgC(string dTCJARTMzGDOw, string pEtbfDjmml)
{
    string BGGaIgaTazmLXNXU = string("uDWqmKmYYGwBTzMKpdGVRtJZJfbFdAJQYQDWlkjfilvGqMWoYYZRZvdBkUxpqtzVnLpUjBMQHuznCzaEdawTILBdJiOlNiWoVBfIIWPXCHfUmEKpvWZdHHPraVgHdtyHuKGtETxYHgdGjcSCzMprPOnLrgVfYVPJVhtjJFmokqfjHBEmyXvHCvlsoFAoxUzrvCLywOBagtVj");
    bool mVdCc = true;
    string YnXJEnSP = string("uSGMWrjOuKkzmbxpEwQnMNEJALjWiKQsMLDVcwmzWMwhJqrOaKjWsTJSuCKDRHr");
    string HrAeaXTaBeX = string("uLUUlKJZVUPBgMcZgrlEKhQamuwtYbPpGbHrviVDGuxRjvVVblTFMHpuYJjPhbTnEQXxqXQnpEbBdoqadRDmFgulvJyscxKgfAhVWKbGhLcSuhPrllZziLNnHEgnppPgwzgXrXbXMaUYlaPRHCIytvvfuxZCeqLBaMZaFklnERByULkTFbDk");
    bool vxnZSziSzC = true;
    string YxhCwFVFmnBMoCC = string("YAFwfcWlAGgjAfyrUQvNmWYnWcwAwxfERATRhfGjLcQBjtVmzNpReFhegIKyXJkvgWEXEeNkIBfoctdCcEWkTCrXkRcNGbPogunJBzWaNykrNCsBCY");
    bool HkBuXadVrbdIv = false;
    double xRsqGReriAkvEIHl = 568604.4502582196;
    double Yaeat = -968293.121199108;
    double pPLJiDDDfGxViuqf = 87956.36789918711;

    if (HrAeaXTaBeX < string("RuobHjBzWRzc")) {
        for (int hyjFmljrQaxm = 1262307518; hyjFmljrQaxm > 0; hyjFmljrQaxm--) {
            continue;
        }
    }

    return YxhCwFVFmnBMoCC;
}

int EWDEUGCwgUKEQOjY::KsjwgO(string KKezaVEtcCxMFH, int fdZuVmmCUJnyS, double tdxOrexHKblu, string CYpWH, bool aywpDHNcg)
{
    bool nyecbMZDhrS = true;
    string cKhVqCvOyqJGXS = string("DkgulqKFPpEcCTbazsbZMEBPEkhjEHAPcFTZhnybyhrhKKUrrGVQGQOfIyrRbeKYagQCsvcLYtKoFPTsSIziqtpMWhaDnvonWlzABmeNYaQJFtcGluWxhRqXAFuCBkkfsmiuHZEWzoWXnjqWwiIkgaHZCkusCnkFojcDKjXtqOuIQzPEtTlFGHBeaaPwsDMnhIgDaUcWDnAfFNShaPKfksgQlUAtsJwIPYgWnw");
    bool lhdauNCZBC = true;
    bool avdmFAypYlOnQJp = true;
    bool xdixv = true;
    bool lWnLUyR = false;
    string ecqQCwieqbJw = string("kWpBfjyxBYfxLBAODUpXQPvkzGdmIWkHLhZWyQWnXeIhrNSZKvbNwNZmGVuXNLltwDKNSrwgPBXRuzwmnAsRdtToibMuAVPDHAeLySCQFADyKCLYmAaNnuPnEZLzGIBsQjBGvWdEPgkiKEVJBWGxqhPIfogscXpEeastOJokTBQRrDcSCSyAzyHJyac");
    bool HKLTINQKZCCBrwMG = false;

    for (int fhEQAdfLHo = 206830370; fhEQAdfLHo > 0; fhEQAdfLHo--) {
        continue;
    }

    if (avdmFAypYlOnQJp == true) {
        for (int YxTbMeWCsloaF = 933668172; YxTbMeWCsloaF > 0; YxTbMeWCsloaF--) {
            continue;
        }
    }

    for (int vVuKfRwCltlxP = 2062038555; vVuKfRwCltlxP > 0; vVuKfRwCltlxP--) {
        KKezaVEtcCxMFH = ecqQCwieqbJw;
        lhdauNCZBC = HKLTINQKZCCBrwMG;
    }

    return fdZuVmmCUJnyS;
}

string EWDEUGCwgUKEQOjY::hHmVhwNHqz(double lHclvcGrkTiSiqw, bool TFiyCO, double sGfByIqRZkfyhez)
{
    double SKulMuwgKRjo = 559086.3849776093;
    double xfBaRzwvQFIdFz = 823888.6592878379;
    bool CAikiHZ = true;
    double zliphNyNdaXOS = 384378.8176555999;
    int pGJZqSRc = 1305299719;
    int AryOt = 802039584;
    int UPkFtRJwVjfJRv = 1079951784;
    int oMdOqzzJuQ = 274465940;
    string SIONS = string("ZzqXwREJBXhEJvfuDjQRJujFoUTZRpUKFQPHTrKai");
    double IlZmk = -1048021.5144412436;

    for (int AXSNOwKUUrOglK = 100378243; AXSNOwKUUrOglK > 0; AXSNOwKUUrOglK--) {
        CAikiHZ = ! TFiyCO;
        zliphNyNdaXOS *= IlZmk;
    }

    return SIONS;
}

bool EWDEUGCwgUKEQOjY::kxkDbWdfmz(bool Fyaij)
{
    double cVvlSo = -845907.0491749936;
    int TMljUJFjmJt = 281171131;
    bool JBJquhtnVBvIv = false;
    bool QLDLV = true;
    int wJeirwGjB = -1072240479;
    double awoapjHJ = -471252.9400829771;
    bool BPlolN = false;

    for (int fzQMPmtku = 1744674340; fzQMPmtku > 0; fzQMPmtku--) {
        JBJquhtnVBvIv = JBJquhtnVBvIv;
        TMljUJFjmJt += wJeirwGjB;
        cVvlSo = cVvlSo;
        wJeirwGjB += TMljUJFjmJt;
    }

    if (BPlolN != true) {
        for (int VSgiSUzRTqdUnS = 1096382568; VSgiSUzRTqdUnS > 0; VSgiSUzRTqdUnS--) {
            cVvlSo /= awoapjHJ;
            TMljUJFjmJt /= wJeirwGjB;
            JBJquhtnVBvIv = ! JBJquhtnVBvIv;
            BPlolN = ! Fyaij;
            QLDLV = ! Fyaij;
            JBJquhtnVBvIv = ! Fyaij;
        }
    }

    return BPlolN;
}

int EWDEUGCwgUKEQOjY::zMhvfHwyCPC()
{
    bool PwObQBsP = false;
    bool hdrNYkzcSUwGn = true;
    double cpaXH = -723317.5546935623;
    double zmtmuqyKJJMWrMn = 1012183.9850063558;
    string qdnZyAqhDi = string("qIzaozaRzVqRzIhykCbJIeOiQbHOqkDOGMjJTWoDjqiKcILZsuDeyqKeNWfZiQuElLsQyViIRMfqEgAQRuROhWTZalrWlOdthdGMsEBjZHwHEEIampderWTipDCJDPGfzbVQsNMbnFoJAHMIttFgCAGmqhRcSlnTXTYOCuwMobGTnUvFvnQwPxt");
    string sFGfjSErqWHW = string("rbZREghRlgxSSumpaIJAtVcjuZpHLRKiMWCQaeekhdyHcjHeHMnqKxkhaFMrnXkNCfTPWKJTyqexdkfUCQWfgRRKDBRteMUXzbijHUmOecrgSOyWBGmawvLBxdoHfEFGPZAdFApGeciYOCVkagDYIxKaKPCkupABPiPinbOgJAEfSEuMbUrvaVFBvZOEeRYQ");

    if (qdnZyAqhDi <= string("qIzaozaRzVqRzIhykCbJIeOiQbHOqkDOGMjJTWoDjqiKcILZsuDeyqKeNWfZiQuElLsQyViIRMfqEgAQRuROhWTZalrWlOdthdGMsEBjZHwHEEIampderWTipDCJDPGfzbVQsNMbnFoJAHMIttFgCAGmqhRcSlnTXTYOCuwMobGTnUvFvnQwPxt")) {
        for (int nkMgCa = 1659984518; nkMgCa > 0; nkMgCa--) {
            sFGfjSErqWHW += sFGfjSErqWHW;
            sFGfjSErqWHW = sFGfjSErqWHW;
        }
    }

    if (hdrNYkzcSUwGn != true) {
        for (int DnkzKuwuASMxc = 1473955409; DnkzKuwuASMxc > 0; DnkzKuwuASMxc--) {
            cpaXH *= zmtmuqyKJJMWrMn;
        }
    }

    for (int iGJaPf = 329900730; iGJaPf > 0; iGJaPf--) {
        hdrNYkzcSUwGn = hdrNYkzcSUwGn;
        PwObQBsP = ! PwObQBsP;
    }

    if (zmtmuqyKJJMWrMn < -723317.5546935623) {
        for (int cmtsnKyMj = 262126644; cmtsnKyMj > 0; cmtsnKyMj--) {
            zmtmuqyKJJMWrMn /= cpaXH;
            hdrNYkzcSUwGn = PwObQBsP;
        }
    }

    for (int Pjvcikci = 132610105; Pjvcikci > 0; Pjvcikci--) {
        continue;
    }

    return 1440746522;
}

bool EWDEUGCwgUKEQOjY::JMAkVzdEXUAcOof(string kuwGxwWNTeeWlhxW, int yuKgo)
{
    double CzMnBQUqKlie = -706820.2097707671;

    for (int FWsVqQjTd = 899515459; FWsVqQjTd > 0; FWsVqQjTd--) {
        yuKgo = yuKgo;
    }

    if (CzMnBQUqKlie < -706820.2097707671) {
        for (int EImrjYJjKyg = 97655478; EImrjYJjKyg > 0; EImrjYJjKyg--) {
            CzMnBQUqKlie /= CzMnBQUqKlie;
            kuwGxwWNTeeWlhxW += kuwGxwWNTeeWlhxW;
        }
    }

    if (kuwGxwWNTeeWlhxW == string("iPQJiarrJjkgOvMkLEyBAiBmbYMyZrkSvulILkDpyxaHHRyTshHFJyhftZivJlDNbQhGGZIVRcgdsuauFPsrtmmgZgYUODYJqjxdWNaEJzcdhhJ")) {
        for (int PRoTkSpiik = 1480914708; PRoTkSpiik > 0; PRoTkSpiik--) {
            continue;
        }
    }

    for (int pPlVTafa = 5526527; pPlVTafa > 0; pPlVTafa--) {
        continue;
    }

    for (int uNRATUhKa = 923574354; uNRATUhKa > 0; uNRATUhKa--) {
        yuKgo = yuKgo;
    }

    return true;
}

int EWDEUGCwgUKEQOjY::OMPYneHzYi()
{
    double bAqTApv = 238885.09501183013;
    double GwHZWwl = 502751.2510399048;
    int tCnJkMSmeNS = -1029746931;
    string jBhVvCb = string("zlpJIGikqVoTuwWlSlYndhehslMnkEQHrCoMdVnoBrYufQkCyTMiMVWrzYCXhrDryyFTJfkZsLgQXfKzpNphauvzBASlcZAglWHPPHHqWWKDZHEsLBWSEGxQxzaEusNpKTvMUGUhRuITQCYrsVRdIhlHXqpqln");
    string YBKPVubo = string("CPDTAVKUXTHGyhkFBbcJsHRbepWzQEsCReRewzxnhJdIdyUZpzdmvkiwZhxeXOrWrXaEHvCFhLIifqogTbRWUlAnGODyUdjtBLECxAqTDzCffcNFAZjhfeXGvITUcUesOOIBjwoMIcTTxzKjpPXtKQscYhHZYlfgSMjarFdwnSLhvp");
    double gWlLZGDRdjZF = 656551.444145814;
    int bUNUnGIODSoImM = -1423690258;

    for (int sTuqlTbLDXYGw = 541058261; sTuqlTbLDXYGw > 0; sTuqlTbLDXYGw--) {
        YBKPVubo = YBKPVubo;
        bAqTApv *= bAqTApv;
    }

    for (int eFiPC = 817021071; eFiPC > 0; eFiPC--) {
        bAqTApv -= gWlLZGDRdjZF;
        tCnJkMSmeNS *= bUNUnGIODSoImM;
    }

    return bUNUnGIODSoImM;
}

int EWDEUGCwgUKEQOjY::wLScjCzhjCGyIU(bool srUmdmfiGfWZlDJ, int dRklhLAaiT, int zpbqjUleLuT)
{
    int HlBRVvfVrOa = 962764180;
    double MLZDW = -233157.56526333085;
    int CqBsEdgaEMWmgTg = -667917004;
    string VieDtCQovbhPIY = string("gOTsqmjBrpnbxUtcCycqIxcMzxuvwjfAVTFuiRdhSFsSHsOzUlzQlNrJMGEzTjMoblNwgnnruzhXU");
    bool vauIHlmtf = true;

    if (dRklhLAaiT > 1321748265) {
        for (int pliQwCs = 1658919992; pliQwCs > 0; pliQwCs--) {
            dRklhLAaiT = CqBsEdgaEMWmgTg;
            HlBRVvfVrOa -= CqBsEdgaEMWmgTg;
            MLZDW += MLZDW;
        }
    }

    for (int AuYCkOXOU = 668653537; AuYCkOXOU > 0; AuYCkOXOU--) {
        srUmdmfiGfWZlDJ = srUmdmfiGfWZlDJ;
        dRklhLAaiT /= dRklhLAaiT;
    }

    return CqBsEdgaEMWmgTg;
}

bool EWDEUGCwgUKEQOjY::ovHHUfTXTMUr()
{
    int HyftgLzfL = 838809755;
    bool aNVcNFEwMyGKm = false;

    if (HyftgLzfL >= 838809755) {
        for (int SSfOUsrsErxK = 1567279665; SSfOUsrsErxK > 0; SSfOUsrsErxK--) {
            aNVcNFEwMyGKm = aNVcNFEwMyGKm;
            HyftgLzfL /= HyftgLzfL;
            aNVcNFEwMyGKm = aNVcNFEwMyGKm;
            aNVcNFEwMyGKm = aNVcNFEwMyGKm;
            aNVcNFEwMyGKm = aNVcNFEwMyGKm;
        }
    }

    if (aNVcNFEwMyGKm == false) {
        for (int JwIbxOujLnilhLKV = 1240045550; JwIbxOujLnilhLKV > 0; JwIbxOujLnilhLKV--) {
            HyftgLzfL += HyftgLzfL;
            aNVcNFEwMyGKm = aNVcNFEwMyGKm;
        }
    }

    return aNVcNFEwMyGKm;
}

double EWDEUGCwgUKEQOjY::UGxPfxErkyIw(bool hPvSyOzngPYwZGpF, double wXGdmpNhRLXCfK, string nVpQLHKStVjfczsx, double CQXgwakY, int ABkhlpA)
{
    double LnTAJtpghrEz = -638912.177289891;
    double uxwan = 600307.6204895613;
    string yKoDAnfhn = string("blieCbRYXoDqMzeJXROfidUsPQCRZyAAEwQk");

    for (int vCWwQwaVnfwHUcH = 1704976127; vCWwQwaVnfwHUcH > 0; vCWwQwaVnfwHUcH--) {
        LnTAJtpghrEz = CQXgwakY;
        nVpQLHKStVjfczsx = nVpQLHKStVjfczsx;
    }

    for (int tGPpSur = 1612167446; tGPpSur > 0; tGPpSur--) {
        hPvSyOzngPYwZGpF = hPvSyOzngPYwZGpF;
        LnTAJtpghrEz -= wXGdmpNhRLXCfK;
        LnTAJtpghrEz *= LnTAJtpghrEz;
        ABkhlpA = ABkhlpA;
        uxwan *= LnTAJtpghrEz;
        uxwan *= LnTAJtpghrEz;
    }

    for (int uMrjxyBAJAKBJM = 997067113; uMrjxyBAJAKBJM > 0; uMrjxyBAJAKBJM--) {
        wXGdmpNhRLXCfK *= wXGdmpNhRLXCfK;
    }

    return uxwan;
}

bool EWDEUGCwgUKEQOjY::JFNIiPdF(string iQQAkerAbReiCs, string UZrWCboTHQXkX, double XtCMKFIKwJWvoKP)
{
    string gfuCaNDppzyLQwZ = string("rIgmkamIfrHyKGqUKkbfFSEPuNgPqSWAOiEKkQAsQBMpRFOFwniUPSfbsYIjOBrPYHNLrFFDRLYynfRFLAIqqZkZVupvzQvMPoIEYfxqChNDrSLJpLdTWaBmKWbkOTUootrtinmZThqEtgnfszpxnXFncYXvsVtPtMnlWZfwkswgpoXqxNcBQykvlUjpwCpkejiRVTKATpTlQHisjehQGVTRSZFGyVUVGwZP");
    double ZqDNKfIDocQW = -699177.6184962458;
    string RQeqeieiMxTu = string("dzSzRYMVptRrgwMwboTSUu");

    if (gfuCaNDppzyLQwZ >= string("RsVPwnqNDanYFlxkimFDHzHYFpmhFMfvNurzcdsfSqdISXtCdWrXnSacCsTAUAGlBeOwzdReBlkWpCQDVtZJXuQgMGJwoLnYxcUpMqMujVkOKahetiUrdrvgAgMpdhqMnqWLTJCLYhYsBhxtkFMJvtzRkoFXaMcpGU")) {
        for (int JSvBzqaQPtM = 1089756390; JSvBzqaQPtM > 0; JSvBzqaQPtM--) {
            RQeqeieiMxTu = UZrWCboTHQXkX;
            UZrWCboTHQXkX = RQeqeieiMxTu;
            UZrWCboTHQXkX += RQeqeieiMxTu;
            UZrWCboTHQXkX += iQQAkerAbReiCs;
        }
    }

    if (iQQAkerAbReiCs == string("dzSzRYMVptRrgwMwboTSUu")) {
        for (int uISrVHOvcXH = 1611972224; uISrVHOvcXH > 0; uISrVHOvcXH--) {
            iQQAkerAbReiCs = gfuCaNDppzyLQwZ;
        }
    }

    if (iQQAkerAbReiCs >= string("yspfoDFCxbSYscPoxwMnptpOfwhHYvIAUvlqEqltkvXeOrzHeoVzniNmilIDadaZVVwuBEWOsmzdpxqvIatHFJYlFbVwhXchZyjHsWokOsMGCyroiro")) {
        for (int QjWaNLlR = 1113732900; QjWaNLlR > 0; QjWaNLlR--) {
            iQQAkerAbReiCs = UZrWCboTHQXkX;
            RQeqeieiMxTu = RQeqeieiMxTu;
            gfuCaNDppzyLQwZ += UZrWCboTHQXkX;
            UZrWCboTHQXkX = iQQAkerAbReiCs;
            UZrWCboTHQXkX += gfuCaNDppzyLQwZ;
        }
    }

    return false;
}

bool EWDEUGCwgUKEQOjY::LyTbgwgrQGMrh(double vYXBkvJMZeP)
{
    double PqIkhfLY = -111841.56193702028;
    double xhMyHnNI = -650833.682633579;
    bool vvvktiFZiizy = false;
    string QDzJConHfr = string("CWHzylyUVIBiYUbJviQNWoQZhffpdKvSKr");
    string nxsEIojB = string("CNZawCaUZiHbhwHzdDJtNJMmHXWAoOslcFWnBsbTiGpxMPLHMqiGVBasFvcrgpcaFXxbivDNhAWgffGsbkpOtFRDCXJpOCJYDzjLuvetCtrsylDQmSpMiWRyDuXnEaDSBoeFIUwVrjuZVJbPwRdCJFdzACbfLcGQRrqLZieIJNGlmJjbDjsvbjnSGcRQWKUBLIkdFGrcdNurbdOpLSQwWMNjr");
    bool GIVdilS = false;
    int VkVQq = -1552978629;

    return GIVdilS;
}

string EWDEUGCwgUKEQOjY::SrSMuKaprSZGpa(bool zcKNHnNAFWBSjFk, double QRiUhiKqXvMX, bool XEwCBkXfXwoAQK, int NDOrDHp)
{
    string zSdOfli = string("hzGeWVsNKZmdGqCulUdUsJyPmsaauWLnwWfMWdzwIhHTfzrWQBGNBKdqlPbPbhDWeANUhBbTSbdQbSTUNYNBHqJwxWewgOfjQuXoUEtAUmYleqINqtvnkhduHoKlmyEOyEmirrRTEVMDXFIHOqUKIfucRiRjvRreDKdqNHtPszoSUNrpTYluQMmVmZOHrKPd");
    int DRcFPUVeMqlyDc = 1145321633;
    int fyocgQbXUlkrYFoY = -1319924276;
    bool bVUNUQVpKfznSrbz = true;
    bool iPLIzgctvD = true;
    double BPPydkpJGoB = -981227.533004454;
    double CEYSGQlvhNU = -313052.83918176574;
    int upuQFsre = 1386939416;
    string YJTctsC = string("KtCSzEnEv");
    double hzESCVZmEHhDcTx = -735579.1605525579;

    for (int wtbBmfpPLzuFn = 1685961310; wtbBmfpPLzuFn > 0; wtbBmfpPLzuFn--) {
        CEYSGQlvhNU /= BPPydkpJGoB;
    }

    for (int LKkJgLWXtdD = 1312374400; LKkJgLWXtdD > 0; LKkJgLWXtdD--) {
        QRiUhiKqXvMX = hzESCVZmEHhDcTx;
    }

    for (int LWdGaimjByycV = 753093490; LWdGaimjByycV > 0; LWdGaimjByycV--) {
        QRiUhiKqXvMX -= hzESCVZmEHhDcTx;
    }

    if (upuQFsre <= -1319924276) {
        for (int CXGHcNcytMuoHrFg = 1837418512; CXGHcNcytMuoHrFg > 0; CXGHcNcytMuoHrFg--) {
            continue;
        }
    }

    return YJTctsC;
}

EWDEUGCwgUKEQOjY::EWDEUGCwgUKEQOjY()
{
    this->JWmTYIRqCBxgC(string("kbdkzxrznIQPIEEGgBnEayKFGxMTeYxyanmGWnENNWAKGcGodrhubMoLpkUSrRsgfMaNPFaIiEfpsUNALDxPaxhCKbdhQUBynIIHpOKZsAOGjWjpSiFoQsRwdsfKDzMmgGIgYicoautXVYLjoodMrSMVYOVoisuLKztRuiaGSkpSVepdkvZeWPJraVczFsvztIkNkqWZvJUpodtYXdWsAr"), string("RuobHjBzWRzc"));
    this->KsjwgO(string("FIdElprUJRkiEZUxBkLNiEDKVoVxOezqvFxCpKSFfdBJGIBtrlOksrdwhIspKdDuGIWQxhwQHWauKdZZSZwTbyDSbjooTENdoaLIlwfTJabOXuLwirneQJtPKdUEFWWdUp"), 1951188705, -481444.23939600843, string("mICzZSZWyENRLqcVrEcccDFKRmkndQsaYrHAHwztNXHXSDwRBZPyVmBqYcHlFeEUTumSyojDWetdJtAVImLiovhnRAERJoVKVdKeKLuzzyypMdBLWuXXAmDRuRNbIZmpsHARwSkzHPpcLuVoDAZYOLxfpvfXTWCYOKblwXa"), false);
    this->hHmVhwNHqz(-497255.0806498532, false, -255162.24446091102);
    this->kxkDbWdfmz(true);
    this->zMhvfHwyCPC();
    this->JMAkVzdEXUAcOof(string("iPQJiarrJjkgOvMkLEyBAiBmbYMyZrkSvulILkDpyxaHHRyTshHFJyhftZivJlDNbQhGGZIVRcgdsuauFPsrtmmgZgYUODYJqjxdWNaEJzcdhhJ"), -73252996);
    this->OMPYneHzYi();
    this->wLScjCzhjCGyIU(false, 1321748265, -1226442463);
    this->ovHHUfTXTMUr();
    this->UGxPfxErkyIw(false, -284244.944249867, string("mOaXwymyvIocUOmLUAMvlmZicjfYdFwGHaGuJYibAtPIhzhVnmnRiqcZdWMIuRAxKkyqzAEEPOkuoPwKyUlFntnTRNKiKpclmxRORhiQHZfVGZjqBVCAtjwKkDQwgUldqYIEdVPNVUbWrRUjYMHYwCqdkumLqueDVadVWYJYaVdSgGicqeQcJblpun"), 40156.27007763201, 191680782);
    this->JFNIiPdF(string("RsVPwnqNDanYFlxkimFDHzHYFpmhFMfvNurzcdsfSqdISXtCdWrXnSacCsTAUAGlBeOwzdReBlkWpCQDVtZJXuQgMGJwoLnYxcUpMqMujVkOKahetiUrdrvgAgMpdhqMnqWLTJCLYhYsBhxtkFMJvtzRkoFXaMcpGU"), string("yspfoDFCxbSYscPoxwMnptpOfwhHYvIAUvlqEqltkvXeOrzHeoVzniNmilIDadaZVVwuBEWOsmzdpxqvIatHFJYlFbVwhXchZyjHsWokOsMGCyroiro"), 1042257.9847458428);
    this->LyTbgwgrQGMrh(-573008.4738938013);
    this->SrSMuKaprSZGpa(true, -131722.61942942845, true, 963996508);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bnYgtwXNEP
{
public:
    string sXAArVyPCeY;
    int cmYAZxFrJaMhkNn;
    bool JgJDGerBO;
    int WCcQv;

    bnYgtwXNEP();
    double pPdgWXQNlLMy(string GMTLS, int otiZKadpUkquZRS, string azijxBnMNcyOxQBk, bool EpddTbGWFqS, bool AzkZdDSCC);
    double ZkMePAJLNtdBdV(double KLfaQdCzzQ, bool vTmaKrZTunaZ, int CWyNnj, bool txrSGxl, string vqCNpPjaWAeOPt);
    double AUzaFD(bool qfnfqGqPF, int tyftrPsR, int tElfWE, string lqpsKCzxVbGUXo);
    double QMjpNrf();
    int ZxStWNfGSkxin(bool xgNcBV, int QMFBgASBR);
    void meUhqxuqOA(double jlKDYMquWujkVfaw);
    void MDqzNS(bool ABLXeppyf, bool KpVdovnf);
    void YvwxZjSEnOXE(double MUoCQbKwTDyeWGl, int tOwerRRcokTQz, double HqECMeXSvRP, int IRGtl);
protected:
    string kroirjn;
    string lDuukYtpLmAx;

    bool QVTZYHa(string rtmZluUVwJIkMbc, bool kXQQlYS, int DosbXzDi, string qfmAacWYftXggv, double nuyDhldrbfolMykr);
    double vOvkQgjXLLRjiied();
private:
    string JHHiRpPfpJOwU;
    bool vBNpHgCVvSglcypb;
    double HlrvpVifQiBs;

    void OUZMhWYsMgsf(bool eAZZyDHwAbjl, int ukIcHhcGyDalUSVC);
    void KZyoXkevf(int uHHUtPCzEzQfQHo, int zXOcsxWI, int dJDMVWuNCShTCg, int XQLwjMcURpbcVA, double AKulgdIBnzFy);
    bool CRKbxaHuZKGVarhy(bool KWAXPl, double InRIMoHpuYAsow, string XLvYjbrnfg, double XkZRK, double yPFLKfaKTQTcPgFL);
    string UPaBfYmyMIKId(double qQAcNKc, double IvQNCm, double SPIAguLkNcQFomy);
    string dTiJSOuTUJjhA(bool WbfzbutUpaPK);
    void ZCyzFiPeMpmYOYi(string vTqkOlxgd, double cJDoqCBhc);
    int kHFFCanVmWFtgG(double pqAHqjoETWqosb);
};

double bnYgtwXNEP::pPdgWXQNlLMy(string GMTLS, int otiZKadpUkquZRS, string azijxBnMNcyOxQBk, bool EpddTbGWFqS, bool AzkZdDSCC)
{
    double VqXLx = 922368.609283489;
    bool tZfMSpIQqFI = true;
    bool aaolMaZqOBVwh = false;

    for (int bnthBBgNEGUuxbB = 1460565676; bnthBBgNEGUuxbB > 0; bnthBBgNEGUuxbB--) {
        tZfMSpIQqFI = AzkZdDSCC;
        azijxBnMNcyOxQBk = GMTLS;
    }

    return VqXLx;
}

double bnYgtwXNEP::ZkMePAJLNtdBdV(double KLfaQdCzzQ, bool vTmaKrZTunaZ, int CWyNnj, bool txrSGxl, string vqCNpPjaWAeOPt)
{
    int LxhON = 164472693;
    int aMumkNy = 1630060180;
    string NAzwGZlTNixPpA = string("OTSwyqKUPsPaxjdzbHEDrIgHJ");
    string bTecqvbCUIvbAw = string("vrDyABCXGbPuzikMFzyTEboMNzZYMPJeyvfmctYtGBTRiNdqWXShlgarKztINIJTXlxdKSnUuZjEXqmgDrQDKlTghoMwZWiVYUnWSvRfXDIZfhwJcCeVlmRuWqaVVaSlQpJWstiu");
    bool kIMwzNAlsqcP = true;
    int mTyKXdtUgTUZf = -796551973;
    int ejqIsVkq = 1260558301;

    for (int pIQVQRHm = 1415952629; pIQVQRHm > 0; pIQVQRHm--) {
        mTyKXdtUgTUZf += aMumkNy;
        LxhON -= mTyKXdtUgTUZf;
        NAzwGZlTNixPpA = bTecqvbCUIvbAw;
        mTyKXdtUgTUZf = CWyNnj;
    }

    if (LxhON > 164472693) {
        for (int sjdIkSEoLl = 346025283; sjdIkSEoLl > 0; sjdIkSEoLl--) {
            CWyNnj /= CWyNnj;
        }
    }

    if (txrSGxl == false) {
        for (int KOKuUflOwSMy = 701443503; KOKuUflOwSMy > 0; KOKuUflOwSMy--) {
            kIMwzNAlsqcP = vTmaKrZTunaZ;
        }
    }

    if (vTmaKrZTunaZ != false) {
        for (int koZQjI = 531349725; koZQjI > 0; koZQjI--) {
            CWyNnj -= CWyNnj;
        }
    }

    return KLfaQdCzzQ;
}

double bnYgtwXNEP::AUzaFD(bool qfnfqGqPF, int tyftrPsR, int tElfWE, string lqpsKCzxVbGUXo)
{
    bool ZXwiTJ = false;
    int SWsXvtLjfZVG = -123125366;
    bool JPUnPwccQuSn = false;
    int pXKDiVLD = -754074588;

    for (int bRIIlRPZUTD = 508783380; bRIIlRPZUTD > 0; bRIIlRPZUTD--) {
        lqpsKCzxVbGUXo = lqpsKCzxVbGUXo;
        pXKDiVLD -= tElfWE;
        SWsXvtLjfZVG /= pXKDiVLD;
        tElfWE += SWsXvtLjfZVG;
    }

    for (int maPKsewsai = 985295626; maPKsewsai > 0; maPKsewsai--) {
        JPUnPwccQuSn = ZXwiTJ;
        pXKDiVLD = tyftrPsR;
        lqpsKCzxVbGUXo += lqpsKCzxVbGUXo;
    }

    return 75796.12327871114;
}

double bnYgtwXNEP::QMjpNrf()
{
    string VaSBUiI = string("sWhHWyvCcaZbkScTGKpvlSlDSCNNLmbrLxHTQesGWIAytsqIISkgFQxFOztwSyTRJwvlerwHLhtlyMZLPXIubiY");
    double npAxRISMOAdSj = 211477.3518269874;
    double RLmGFHd = 800656.011885369;
    bool rkxjHlEF = false;

    for (int zYyvTnAObeUebQhw = 422850657; zYyvTnAObeUebQhw > 0; zYyvTnAObeUebQhw--) {
        RLmGFHd *= npAxRISMOAdSj;
        VaSBUiI = VaSBUiI;
        npAxRISMOAdSj += npAxRISMOAdSj;
        npAxRISMOAdSj /= RLmGFHd;
        VaSBUiI = VaSBUiI;
        npAxRISMOAdSj /= npAxRISMOAdSj;
        VaSBUiI = VaSBUiI;
        rkxjHlEF = rkxjHlEF;
        VaSBUiI = VaSBUiI;
    }

    for (int gVKPXZPOuKyOqFn = 1621912293; gVKPXZPOuKyOqFn > 0; gVKPXZPOuKyOqFn--) {
        RLmGFHd *= RLmGFHd;
        npAxRISMOAdSj = RLmGFHd;
        rkxjHlEF = ! rkxjHlEF;
    }

    if (VaSBUiI == string("sWhHWyvCcaZbkScTGKpvlSlDSCNNLmbrLxHTQesGWIAytsqIISkgFQxFOztwSyTRJwvlerwHLhtlyMZLPXIubiY")) {
        for (int pTfUrqClay = 1888859066; pTfUrqClay > 0; pTfUrqClay--) {
            rkxjHlEF = ! rkxjHlEF;
            npAxRISMOAdSj *= RLmGFHd;
            VaSBUiI += VaSBUiI;
        }
    }

    if (VaSBUiI > string("sWhHWyvCcaZbkScTGKpvlSlDSCNNLmbrLxHTQesGWIAytsqIISkgFQxFOztwSyTRJwvlerwHLhtlyMZLPXIubiY")) {
        for (int BUEVUB = 852136169; BUEVUB > 0; BUEVUB--) {
            VaSBUiI += VaSBUiI;
            RLmGFHd *= RLmGFHd;
        }
    }

    for (int LCigncSbEVRXdKa = 1477427203; LCigncSbEVRXdKa > 0; LCigncSbEVRXdKa--) {
        npAxRISMOAdSj *= RLmGFHd;
        VaSBUiI = VaSBUiI;
    }

    return RLmGFHd;
}

int bnYgtwXNEP::ZxStWNfGSkxin(bool xgNcBV, int QMFBgASBR)
{
    bool FnXbPcntpzI = true;
    int ehvCNbeXS = -1760929046;
    double vYVaAkrEWoJOg = 886618.6306455254;
    double LSLPoNzVImki = 420324.69458571303;
    int xkfryZ = 601895074;

    if (xkfryZ > -1760929046) {
        for (int dnkiGHYDOg = 1955774534; dnkiGHYDOg > 0; dnkiGHYDOg--) {
            continue;
        }
    }

    if (xgNcBV != false) {
        for (int fHVbfmFEaTSi = 164717298; fHVbfmFEaTSi > 0; fHVbfmFEaTSi--) {
            ehvCNbeXS = QMFBgASBR;
            vYVaAkrEWoJOg += vYVaAkrEWoJOg;
        }
    }

    return xkfryZ;
}

void bnYgtwXNEP::meUhqxuqOA(double jlKDYMquWujkVfaw)
{
    double ESDDfLGW = -980339.5851419603;
    string wSCgVhGoFDvYPOzr = string("zLpkACCOXAnPOFZDjWGRjsuWIbfyoBMlOijNZvILiYkFINAKBaseAAiLJjYGwqQPEFDaVCiKKSlrjhHSwtZDWHdhwMUvVHQBhEpJMNHjKWwtreLpYeHEYJvRttklldJZhxUORSiHSJgLnrBKwRQrPRGsbkUhxFrCDwdGLtfJKbVotoQspjZzkUruxYCODddkhOVKloNnuJfrnZSPfO");
    int LLPeegDltXmUv = 1955030122;
    double RJeDe = 1043590.6979710541;
    string lmjFGvsbtG = string("uuYfnaZzXzWsNIwocYnhmXVBgkkoQGvwIZWIyyVSbjBoiIOstwWnpzzdozxgTNswQBmatGgCqrVJvsucwuJKHtkoGixXBXNURnzYIdpfAmIpqutCVwSNYXoOMEPdJPWlQtNDUJVxUBeTAvqkKIvrhaGRThISQzPwyoknGoZghgYmWMUHpLTsXTjbJuxpMCtNUOXBBcqPsWKgBrUFkxjCYPczyLeghH");

    for (int JdPcVdgid = 105636295; JdPcVdgid > 0; JdPcVdgid--) {
        ESDDfLGW += ESDDfLGW;
    }
}

void bnYgtwXNEP::MDqzNS(bool ABLXeppyf, bool KpVdovnf)
{
    bool RkjrP = false;
    bool JLsemUCjzHxOZGw = true;
    bool lDqiQMrVcQBrdE = true;
    double klUnG = -81788.6193339218;
    double CEutgxcIIrH = 192868.37892402333;
    int umDWBUwRA = 1894327723;
    bool aUNCxyOAaayMHs = true;
    int jbdPngrkiwqTEK = -1695006227;
    int qYsOiqMINxB = -2008221916;

    if (aUNCxyOAaayMHs == true) {
        for (int AWxZRsWuZY = 1596128442; AWxZRsWuZY > 0; AWxZRsWuZY--) {
            aUNCxyOAaayMHs = ! lDqiQMrVcQBrdE;
            umDWBUwRA *= jbdPngrkiwqTEK;
            KpVdovnf = ! JLsemUCjzHxOZGw;
        }
    }

    for (int CUQgA = 386481357; CUQgA > 0; CUQgA--) {
        RkjrP = ! aUNCxyOAaayMHs;
        KpVdovnf = ! KpVdovnf;
    }

    if (umDWBUwRA > 1894327723) {
        for (int eBMlIQoPheoeyE = 1416616050; eBMlIQoPheoeyE > 0; eBMlIQoPheoeyE--) {
            KpVdovnf = ABLXeppyf;
            JLsemUCjzHxOZGw = ABLXeppyf;
            KpVdovnf = ! aUNCxyOAaayMHs;
            JLsemUCjzHxOZGw = ! ABLXeppyf;
            ABLXeppyf = ! lDqiQMrVcQBrdE;
        }
    }

    if (RkjrP == true) {
        for (int UNakBnTpnIYgpXn = 1998759998; UNakBnTpnIYgpXn > 0; UNakBnTpnIYgpXn--) {
            continue;
        }
    }

    for (int uPaTtBhMlguPlbA = 981931194; uPaTtBhMlguPlbA > 0; uPaTtBhMlguPlbA--) {
        continue;
    }

    for (int HLdzp = 1451399208; HLdzp > 0; HLdzp--) {
        JLsemUCjzHxOZGw = aUNCxyOAaayMHs;
    }
}

void bnYgtwXNEP::YvwxZjSEnOXE(double MUoCQbKwTDyeWGl, int tOwerRRcokTQz, double HqECMeXSvRP, int IRGtl)
{
    double mWqJwvzLBNmrfsEv = -217535.6427635579;
    string NlieyI = string("cvlwRrHIUrfvuxYzstYllygorgWvXKryKhHRmbMJrqXqFJxSVNimTxsSgoAUwQwGNCYLyGoCzTtNtyEQYwGqIcRQONzAwgkXUkZGFKPKznBOgjlUsTFbXHdRWdgmPClFVvueofnLvqesFkjJlWOhbnhhyRnGfVHASeqWSNdIsUnppPgdUYCOthmrMISxbowJGoXRUNrJVVeDFMcBVJO");
    bool LKxrV = false;
    string IyYGnSVy = string("gAilkkuqBvarsqAzMpzOiPOgsAHDBhnwFTyPnz");
    double evlFlXgfTCRyHoi = -582455.0711340761;
    bool jiClwdpDjKulC = true;
    string qKloswbEZkGRV = string("efLhXocKPfTqHCXaWxifVrgQrYQZ");

    for (int iBBDeBggMOlS = 853613532; iBBDeBggMOlS > 0; iBBDeBggMOlS--) {
        continue;
    }
}

bool bnYgtwXNEP::QVTZYHa(string rtmZluUVwJIkMbc, bool kXQQlYS, int DosbXzDi, string qfmAacWYftXggv, double nuyDhldrbfolMykr)
{
    double KkiTNRuY = -625735.9925374533;
    bool iGfgGkhlgDPCIM = false;

    for (int qEvcOzsEotDLaaL = 260982064; qEvcOzsEotDLaaL > 0; qEvcOzsEotDLaaL--) {
        continue;
    }

    for (int yVodwvtZjOVOQHl = 1426719089; yVodwvtZjOVOQHl > 0; yVodwvtZjOVOQHl--) {
        iGfgGkhlgDPCIM = ! iGfgGkhlgDPCIM;
        KkiTNRuY -= KkiTNRuY;
    }

    if (KkiTNRuY > 481152.76733791723) {
        for (int QXjyStGNPCA = 251751428; QXjyStGNPCA > 0; QXjyStGNPCA--) {
            DosbXzDi *= DosbXzDi;
        }
    }

    for (int VFRcVWIUKoxulH = 700736150; VFRcVWIUKoxulH > 0; VFRcVWIUKoxulH--) {
        KkiTNRuY /= nuyDhldrbfolMykr;
        iGfgGkhlgDPCIM = iGfgGkhlgDPCIM;
        iGfgGkhlgDPCIM = kXQQlYS;
    }

    for (int bwJqHzlvVtNEpsb = 1154931394; bwJqHzlvVtNEpsb > 0; bwJqHzlvVtNEpsb--) {
        DosbXzDi += DosbXzDi;
        kXQQlYS = kXQQlYS;
    }

    for (int gUWPG = 271152225; gUWPG > 0; gUWPG--) {
        qfmAacWYftXggv += qfmAacWYftXggv;
        qfmAacWYftXggv += qfmAacWYftXggv;
        iGfgGkhlgDPCIM = ! kXQQlYS;
    }

    for (int QxMWIjnCJFrQ = 566899141; QxMWIjnCJFrQ > 0; QxMWIjnCJFrQ--) {
        continue;
    }

    return iGfgGkhlgDPCIM;
}

double bnYgtwXNEP::vOvkQgjXLLRjiied()
{
    int ILfnON = 386156784;
    string iuHXc = string("hlOutdXVSftaquRZfNwSPWLYVimmVAwgqULqicpiuihXjycHuSeChQsVkoVvQiLzdCGQJFVLhuGpVOTApEffRhZCGnDJQJMsJsrNCJwFkimFoQAMJMqzTzZutaFWWJsSFQLlbAPNsKXJYRGdSaVcIgAWZkmvTGONUHGhpRkZNsGiNnLJKkANGChRVAOYdbk");
    string XccIHheG = string("QutmtzbYvIQEpyBkkykyqWnXLnIFZHHmJnfNpmB");
    double elGJzoEE = 186090.5655584835;
    string dkmYpXVcpbCwSapC = string("GOkdZayiCdWRFloAWFwdMDnlmUMUmpOSEfLDmqQsOgMJDjOxSxqaNYvmtrqZJYdvdsGDgnhXGVgvcVFAFVNaReUgIrhXCkjzxEAgVTekOtCzQLjryxBxVPkwgPaoVHDHleoGnfAcKviAYjlMMnSIchkKVevvCAtEihWZUXgbAaeboOXbPODdCkgMFqECQ");
    string RhUuuKehOkjzq = string("jTPwExBGOgsljRiUMvTCSlXpWMtSdUgtwEpHuIivyArJrNKnewRiQagXrjwzWRaHClXtlbrxtnLlLNgtYHnounQiVslWGjbVewISxzjOxlJFRuURvVRgLCrWBmnqRvVceYWoGcxTjFKcJgBFjzSYJvPRYMjrLhLzeXVkfJXuvjdQlATzyuWRUIlwddJPAcjbv");

    if (XccIHheG < string("QutmtzbYvIQEpyBkkykyqWnXLnIFZHHmJnfNpmB")) {
        for (int dFrIOnnTbSOSk = 227066126; dFrIOnnTbSOSk > 0; dFrIOnnTbSOSk--) {
            dkmYpXVcpbCwSapC += RhUuuKehOkjzq;
            dkmYpXVcpbCwSapC = dkmYpXVcpbCwSapC;
            XccIHheG += RhUuuKehOkjzq;
            RhUuuKehOkjzq += XccIHheG;
            dkmYpXVcpbCwSapC = XccIHheG;
        }
    }

    if (iuHXc >= string("jTPwExBGOgsljRiUMvTCSlXpWMtSdUgtwEpHuIivyArJrNKnewRiQagXrjwzWRaHClXtlbrxtnLlLNgtYHnounQiVslWGjbVewISxzjOxlJFRuURvVRgLCrWBmnqRvVceYWoGcxTjFKcJgBFjzSYJvPRYMjrLhLzeXVkfJXuvjdQlATzyuWRUIlwddJPAcjbv")) {
        for (int IUmMIkaTSAovaN = 1113126426; IUmMIkaTSAovaN > 0; IUmMIkaTSAovaN--) {
            iuHXc += iuHXc;
            dkmYpXVcpbCwSapC = XccIHheG;
        }
    }

    for (int lSOsfRYVzUFnQBoD = 833102968; lSOsfRYVzUFnQBoD > 0; lSOsfRYVzUFnQBoD--) {
        dkmYpXVcpbCwSapC = dkmYpXVcpbCwSapC;
        iuHXc += iuHXc;
        XccIHheG += XccIHheG;
    }

    return elGJzoEE;
}

void bnYgtwXNEP::OUZMhWYsMgsf(bool eAZZyDHwAbjl, int ukIcHhcGyDalUSVC)
{
    double GMdewffoLnuI = -636410.0582509828;
    double IHfIHmtCkrLS = -804894.2214143266;
    string nKLWpYpawGhIQlWK = string("yCqQHDXSLrDkoBqcsMMjdYnirCtngtLpRjubeIRNUILfjhASPUoCetItBFThvyyKDvKmrvZEcLkKuIkqQrxZcYrUiTrxURGBOeKQYgJbuSgCMdSxFNPAE");
    bool aCdZTxuxolPp = true;
    bool gdXYjEWyzbjGmub = true;

    for (int AIejJLITeni = 959294506; AIejJLITeni > 0; AIejJLITeni--) {
        gdXYjEWyzbjGmub = ! aCdZTxuxolPp;
    }
}

void bnYgtwXNEP::KZyoXkevf(int uHHUtPCzEzQfQHo, int zXOcsxWI, int dJDMVWuNCShTCg, int XQLwjMcURpbcVA, double AKulgdIBnzFy)
{
    string PONFSxpE = string("MblJNoEASCTQaEZrAbhoJoNZBXnZRmtfPPHWwRIkCyifsyzMTySYGHtMGOqIMMmIbfXLKafSqcrKmbXxYyUDBGiOvJUFeNcncSHsXxsScxBKGxqlYaKZmIbpfPgYHHepJLjgcznowBtaHXNgfldACYLgITTwZQnaBfOTNr");
    double BrvLRzsIxPzxer = -824578.7332569528;
    bool NDfRhKjhZGKoiQ = true;
    int UTEzlUrwvEMbXmbi = -2035996029;
    int GCyaXRw = -341066735;
    int uAWdtmlK = 2026574349;
    string TyBNHjrjF = string("BdabgygspAoironlEYzAToCBHRqgBbtyWTjZYTCgoRiKXaGyKVCNxtaMyycfKVG");
    int XnDGKR = 714367160;

    for (int QItnRuFPGYhFy = 812739744; QItnRuFPGYhFy > 0; QItnRuFPGYhFy--) {
        dJDMVWuNCShTCg += XnDGKR;
        uHHUtPCzEzQfQHo = UTEzlUrwvEMbXmbi;
        XnDGKR -= XnDGKR;
        GCyaXRw *= UTEzlUrwvEMbXmbi;
    }
}

bool bnYgtwXNEP::CRKbxaHuZKGVarhy(bool KWAXPl, double InRIMoHpuYAsow, string XLvYjbrnfg, double XkZRK, double yPFLKfaKTQTcPgFL)
{
    int CFILLMbcNvfOPBB = -1204041655;
    int bVhknzavinTjQV = 1176890941;
    bool fRXLWGhhmUOfn = true;

    for (int aTnoQEomUAAOXoP = 2142510171; aTnoQEomUAAOXoP > 0; aTnoQEomUAAOXoP--) {
        InRIMoHpuYAsow *= yPFLKfaKTQTcPgFL;
    }

    if (InRIMoHpuYAsow > 162129.8390447176) {
        for (int XugUNPrrWTrbl = 190340516; XugUNPrrWTrbl > 0; XugUNPrrWTrbl--) {
            bVhknzavinTjQV /= CFILLMbcNvfOPBB;
            XLvYjbrnfg = XLvYjbrnfg;
        }
    }

    for (int tjsCJD = 1176458577; tjsCJD > 0; tjsCJD--) {
        fRXLWGhhmUOfn = ! KWAXPl;
    }

    for (int oKKgzCCwCsATwR = 700869845; oKKgzCCwCsATwR > 0; oKKgzCCwCsATwR--) {
        fRXLWGhhmUOfn = KWAXPl;
        yPFLKfaKTQTcPgFL /= InRIMoHpuYAsow;
        CFILLMbcNvfOPBB /= CFILLMbcNvfOPBB;
        XkZRK *= InRIMoHpuYAsow;
    }

    for (int zTQywRtMuOJwrMPh = 1282873009; zTQywRtMuOJwrMPh > 0; zTQywRtMuOJwrMPh--) {
        CFILLMbcNvfOPBB = bVhknzavinTjQV;
        KWAXPl = ! fRXLWGhhmUOfn;
        KWAXPl = ! KWAXPl;
    }

    for (int KEzhNbfprhPpRro = 458593471; KEzhNbfprhPpRro > 0; KEzhNbfprhPpRro--) {
        yPFLKfaKTQTcPgFL /= yPFLKfaKTQTcPgFL;
    }

    for (int FNFQGozgDPGKyG = 1450687297; FNFQGozgDPGKyG > 0; FNFQGozgDPGKyG--) {
        InRIMoHpuYAsow += yPFLKfaKTQTcPgFL;
    }

    return fRXLWGhhmUOfn;
}

string bnYgtwXNEP::UPaBfYmyMIKId(double qQAcNKc, double IvQNCm, double SPIAguLkNcQFomy)
{
    double ywQheYpvutwqvJhD = -30369.946315719353;
    bool TLXSUiOmHB = true;

    if (qQAcNKc == -30369.946315719353) {
        for (int iEUKWAei = 124563505; iEUKWAei > 0; iEUKWAei--) {
            IvQNCm *= IvQNCm;
            ywQheYpvutwqvJhD -= SPIAguLkNcQFomy;
            qQAcNKc = qQAcNKc;
            SPIAguLkNcQFomy += IvQNCm;
            ywQheYpvutwqvJhD = IvQNCm;
            IvQNCm = IvQNCm;
        }
    }

    for (int ZmWljNEZFx = 1152156947; ZmWljNEZFx > 0; ZmWljNEZFx--) {
        SPIAguLkNcQFomy = qQAcNKc;
        SPIAguLkNcQFomy -= ywQheYpvutwqvJhD;
        ywQheYpvutwqvJhD -= SPIAguLkNcQFomy;
        TLXSUiOmHB = TLXSUiOmHB;
        ywQheYpvutwqvJhD = IvQNCm;
    }

    if (SPIAguLkNcQFomy <= -30369.946315719353) {
        for (int YcwlxhkJDOX = 1057272605; YcwlxhkJDOX > 0; YcwlxhkJDOX--) {
            IvQNCm += IvQNCm;
        }
    }

    if (TLXSUiOmHB == true) {
        for (int jrIOzA = 158277374; jrIOzA > 0; jrIOzA--) {
            qQAcNKc += SPIAguLkNcQFomy;
            TLXSUiOmHB = TLXSUiOmHB;
            ywQheYpvutwqvJhD *= SPIAguLkNcQFomy;
            IvQNCm /= SPIAguLkNcQFomy;
            SPIAguLkNcQFomy *= qQAcNKc;
            qQAcNKc += qQAcNKc;
            TLXSUiOmHB = TLXSUiOmHB;
        }
    }

    if (SPIAguLkNcQFomy == -21341.664708250395) {
        for (int FQWCPljTbCGt = 811122063; FQWCPljTbCGt > 0; FQWCPljTbCGt--) {
            SPIAguLkNcQFomy -= ywQheYpvutwqvJhD;
            IvQNCm = qQAcNKc;
            ywQheYpvutwqvJhD *= SPIAguLkNcQFomy;
            IvQNCm *= ywQheYpvutwqvJhD;
            IvQNCm *= IvQNCm;
            IvQNCm += IvQNCm;
            qQAcNKc *= SPIAguLkNcQFomy;
            qQAcNKc /= ywQheYpvutwqvJhD;
            SPIAguLkNcQFomy += SPIAguLkNcQFomy;
        }
    }

    return string("cdCNeXSPVCestpEfQQbfWrjSeAQPjbscQOsetMdkoCKtwgSpwUsPjXEAUaONfaWResRbkHUpbaREILqlUcrLvkFQXCxzWzMvgUQqqzfzkpEhxyBzwEXCpTlNDgeofbHihAryfSjCmYcmPZKhHyppVBySwCoxnYdNMSVBmwiBLjbFJ");
}

string bnYgtwXNEP::dTiJSOuTUJjhA(bool WbfzbutUpaPK)
{
    string orhnzQLUgUKSLg = string("UZojIrGGhehxcBKQnyNNhnDxrAPmBEAJbULSHUa");
    double xZyrzohFBZS = -611388.5101689254;
    double TwClLZwRCHcIo = -394739.5145545425;
    bool kSnfDETLolOggbBK = false;
    bool YZTcFPY = true;
    int eOkVy = 891791061;

    for (int YMHQBhUiCHzO = 1493276397; YMHQBhUiCHzO > 0; YMHQBhUiCHzO--) {
        YZTcFPY = ! WbfzbutUpaPK;
        YZTcFPY = ! kSnfDETLolOggbBK;
    }

    if (YZTcFPY == true) {
        for (int mCoix = 2132583420; mCoix > 0; mCoix--) {
            continue;
        }
    }

    for (int biPMYE = 1274106897; biPMYE > 0; biPMYE--) {
        continue;
    }

    return orhnzQLUgUKSLg;
}

void bnYgtwXNEP::ZCyzFiPeMpmYOYi(string vTqkOlxgd, double cJDoqCBhc)
{
    string JIWiqZVxIZUWZYDF = string("cyxTCkjgaWNzWVmWDXFVdOXgljtLcboYzahbiPVCBfjkTpAjDcxbnZcJLaSfDfAGpQnWnKcUiSwNqDbtqJuWoZDHKGRZrgubEdHSyJSzTykGcVWJJJduumqdbgy");
    int SXXxHkpmou = -450435706;
    string amjFRU = string("uBrlhPAwsWjfxuybUUxTnaZDARSMqKaSZzxhTIDwRknOScUYdEKqtyEaKElaMXacpekttsKNiutgvJtLOvScZPcEcyvoxvpDAuDJABhkAZRVgdgbErPouvPbjvxyaOwoYisPLXlqHVVfmnboUnnQx");
    double MRlmwGFFT = 893435.3407412139;
    bool pyMMHHoXaAmkBA = true;
    bool FeVgW = true;
    int nYMBhAYTmCE = 1519700372;
    double eRkzuJbGXAo = 442723.58331069216;
    int AGGhRwZ = 977108763;

    if (amjFRU != string("uBrlhPAwsWjfxuybUUxTnaZDARSMqKaSZzxhTIDwRknOScUYdEKqtyEaKElaMXacpekttsKNiutgvJtLOvScZPcEcyvoxvpDAuDJABhkAZRVgdgbErPouvPbjvxyaOwoYisPLXlqHVVfmnboUnnQx")) {
        for (int yQDjFTXH = 1318377851; yQDjFTXH > 0; yQDjFTXH--) {
            eRkzuJbGXAo /= eRkzuJbGXAo;
        }
    }

    for (int cFyiZXzpIws = 1002639474; cFyiZXzpIws > 0; cFyiZXzpIws--) {
        continue;
    }
}

int bnYgtwXNEP::kHFFCanVmWFtgG(double pqAHqjoETWqosb)
{
    string lRkPEB = string("zYgxiXzkJuggBZrehTANDzCmNGJoaaTjKVJQAGbGwIYGaoFTExMCMWJVcZlDVlZBChNLTfKTqeflIotspcIadWQhWULaEQhfSFovXvJhreuynQSLQGOhdYEljuAsGumbxkdUxNeDQjeYLtwKxxAdXIiBhMtPOatIihdpBVUzBeguJAVJOEFlYbHrnjjMqlUnAQuhnerJsosvAmppbmDgUpbNKtKWFDADVq");
    bool mcQhz = true;
    double PLsEOM = 776086.9491939226;
    bool hDjDkkrgBHW = false;
    string DADrCWlhUS = string("LjRtMqTCRmWNcTLgQvGgtcCdcPnPkOiqMsoklexvZqEqfeYWhLaZQrQhmdh");
    string tjPGmE = string("XHosXmkxHPxRfDPSCTgJjShoOASuvKELiRSqjbwOAYKqQLhBhAYlCcNDiLBmhaamvusLUGKNjyHSgGPjbXJbAUAtaRsPuofmFGCAxFKLlTSrVTMZClXMxwaUGDtbtINsMPIUbBIERYhHCnLacP");
    int QcknyNnjsV = 1323954070;
    double UfTifSBkrFNPzhd = 987970.9256708807;
    bool boFzLUbKXw = true;

    for (int UbPdEbnVCpw = 549044110; UbPdEbnVCpw > 0; UbPdEbnVCpw--) {
        lRkPEB += lRkPEB;
    }

    return QcknyNnjsV;
}

bnYgtwXNEP::bnYgtwXNEP()
{
    this->pPdgWXQNlLMy(string("WaTFMNbmNKZiWQCHQWHYBTOernOKlYdMLfHBpCEkOzcIkKijYofHeCsjIoPTCxcoKFtjcgfBKYSCCPBhHvhHYVBWgeTkPNvUHiMBmZNdozjzTnMKkGxbmCcQEIZgXoBvrzImrvaDnNPBZpTxDuP"), -2057249798, string("ZcEKivBHyLYkGYJWfCVGyFBZgMywnLodyKfkRmbOJKJINwplFEIpjYPknKCbICfVChlrVldgaWvVyGOKjSXDeRDYFHGicZssfDqAkJnsZeNTSyDuZytEMoyuKqwMmOQCzSqetQLWqdftSJfPIWhtGcOXXvbFNGrzVMTzlXyufN"), false, true);
    this->ZkMePAJLNtdBdV(-331420.64588380925, false, -1578042346, true, string("kzRdyKljQnxXqwMDAJRmGdlFQCpxMpIfMnzCJKlpRZsHnPfqGwgsTPrkDeRSSkDMmjdxuRJpBECHpLHxFKTVurdMC"));
    this->AUzaFD(true, 1264477262, 1978412501, string("LOGnEBOnlDjivVxZjlHMcUIMmQpVwAEHhVMZJtiFfAjYYUqFSTAvntUlyNZUJXbuhjjGLuINsvXJXOqPJUhJlmbopUCU"));
    this->QMjpNrf();
    this->ZxStWNfGSkxin(false, -839177566);
    this->meUhqxuqOA(-467535.83405901486);
    this->MDqzNS(true, true);
    this->YvwxZjSEnOXE(-837991.53053512, -1466364492, -818120.7678982582, 679956401);
    this->QVTZYHa(string("lfBRAwIkAxRJjZkFrQnqrUVdtzEQAHdtluTar"), true, 432376627, string("jfjnKPPYjxADFDRpShejDqhzzRuvKjBfYBYNrdmLmChHHEtzPwAFddFtvOzvBJGYZfHWOxDjBywXZJJQtukQOyzZbYSRCDMXZBtJZiVMXbeIUdNOaZzsYdP"), 481152.76733791723);
    this->vOvkQgjXLLRjiied();
    this->OUZMhWYsMgsf(true, -1375024155);
    this->KZyoXkevf(2048366652, -98239009, 549582119, -230716052, 681824.7698796715);
    this->CRKbxaHuZKGVarhy(true, -991231.9731368846, string("LIWbsMwRLPrhxvvOdNKARgAZbzncJtpcsSKKqJbyUVOBfuSCRDtLZDIQbvuIRZM"), -354332.1058718592, 162129.8390447176);
    this->UPaBfYmyMIKId(-21341.664708250395, -576296.2302791864, 783326.4966572274);
    this->dTiJSOuTUJjhA(true);
    this->ZCyzFiPeMpmYOYi(string("DAqePDYsYAOJwwLIpBGhUAJzGlCkcLdHLvOHCavmHuzjBgigvImahOHFIrHYIDfkWPbIYUpLzkAFVurULlB"), 891273.0769680846);
    this->kHFFCanVmWFtgG(473115.604258267);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fQTjPuxEi
{
public:
    string YeChgEIjxmOKk;
    double iaqFiCS;
    int qMvDnJebkTLDVDbQ;
    string DLAgaOzrtnuG;
    bool VQStIdVFPeVJJxkY;
    int xFikPAlM;

    fQTjPuxEi();
    double yfHnEcl(string qHpMqQKGya, string tOQwXMWVMB, double DrsUunzmabG, double ZxMZSSY, bool iMmIkQYsVC);
protected:
    int zTrHfQtzWIi;

    string IUPhAr(string gCjPfnHCK, string oKlrbhRnNQVF, bool LyyCcjzFk, string CdcjytVrhf, string amstOWSYr);
    string pEMoGM(string qkrlTJrh, int WSqhTdtwchw);
    string hpdLcGKhmC(string IhUZE, bool dZNqbfqjkTZrIiyA, double VyDHLXyuXoSzhbye);
    string RcltAb(double ucoMbWgGyUidz, bool osfTfrs, double XCmihqop, string YlHuONjK, string hNDscS);
private:
    double CjyYC;
    string bLGtJHmOiwmBYmMr;
    int KpZMLhNQLNopta;
    double NmufpX;
    double jSXqFRtCav;

};

double fQTjPuxEi::yfHnEcl(string qHpMqQKGya, string tOQwXMWVMB, double DrsUunzmabG, double ZxMZSSY, bool iMmIkQYsVC)
{
    int gAZQucg = -1162338017;
    int UtPMfCwDZUZEZDqH = -786548093;
    bool HdvwkqS = false;
    string PsvtOvRkzwxNK = string("KIfnQxCfqFVwhECCzOKBgQELVzbpUUbKSsXIdDQCNIfQpMACMzSPZyAcqtICvBddzoZwvSkFDZLWzgSrtgNRqUqfTtrDMfUDunbHjJGwQjuojoWkZYbDVpFytFpgGxuMVioLPCsuoYNZAOrxuQKIcJDWvqCMJxYYdhIr");
    bool icxrP = true;
    bool WBDOMygx = false;

    return ZxMZSSY;
}

string fQTjPuxEi::IUPhAr(string gCjPfnHCK, string oKlrbhRnNQVF, bool LyyCcjzFk, string CdcjytVrhf, string amstOWSYr)
{
    bool VduAv = true;
    string ZQQOmgj = string("MFZWSckELErpRrUJgAvKlDCgGZABgjIBbrbSLRNZJnfQSLioJvGjVVPB");
    int aceizuAW = 1315107261;
    int kfeFNYlvFFpBxG = 80853951;
    string OqJaAbbS = string("jLWECnrZgrDHBExEGrdGQqQaMjGnMWPpLoFnaScVYXsXBwHyfarRKgMeEUtxy");

    if (OqJaAbbS != string("LbMIJpvhPFZVcWCKwnatUCxuVtyxVhThAPtnluueQAdVjjlhRehNJWCiNxhbOGOyyrIOiXncNSlqWQLVAxFVYuFMgcYlPVKAZdrGvJGJmzsjRIWnoZ")) {
        for (int oJzFQttJfbfmuBjg = 1402378715; oJzFQttJfbfmuBjg > 0; oJzFQttJfbfmuBjg--) {
            CdcjytVrhf = CdcjytVrhf;
            gCjPfnHCK += oKlrbhRnNQVF;
            VduAv = LyyCcjzFk;
        }
    }

    return OqJaAbbS;
}

string fQTjPuxEi::pEMoGM(string qkrlTJrh, int WSqhTdtwchw)
{
    double MGmiAfgqAC = 368541.36258047435;
    int AthkFMDZUrtDLUhZ = -1444128926;
    double OxabQJTmFmYBQDO = -742127.3430270676;

    if (MGmiAfgqAC >= 368541.36258047435) {
        for (int ZERVPWMCzROJYk = 787490709; ZERVPWMCzROJYk > 0; ZERVPWMCzROJYk--) {
            MGmiAfgqAC += OxabQJTmFmYBQDO;
        }
    }

    for (int gUIxSis = 1695604613; gUIxSis > 0; gUIxSis--) {
        MGmiAfgqAC += MGmiAfgqAC;
    }

    return qkrlTJrh;
}

string fQTjPuxEi::hpdLcGKhmC(string IhUZE, bool dZNqbfqjkTZrIiyA, double VyDHLXyuXoSzhbye)
{
    bool wKKnzKzKEMU = true;
    string Zkwdic = string("bezPtcEPYtRsdCCsZJmIVswVKkeKTRLsFbKRYEJaVxQqmIlsaQmrYfmb");
    int KrGMNfdkoRFuMGr = -689095053;
    string FnGEhiEBSzSoxnpU = string("SuJnBzMMMKstyFcmgvelBonOdkbysMccZZNwygW");
    int MxrHeuMFShwk = -747935692;
    bool DXwDctFePdYb = false;
    int ApLgOfbKtcDiAoSg = -185598263;
    int HBQJWCT = 1866399489;
    double xEHlRoLtBtKg = -211880.93811695263;

    if (ApLgOfbKtcDiAoSg > -185598263) {
        for (int KVdadrGOOgALu = 389359801; KVdadrGOOgALu > 0; KVdadrGOOgALu--) {
            continue;
        }
    }

    return FnGEhiEBSzSoxnpU;
}

string fQTjPuxEi::RcltAb(double ucoMbWgGyUidz, bool osfTfrs, double XCmihqop, string YlHuONjK, string hNDscS)
{
    double ZhXtCYjd = -709760.1401912486;
    int BUMzCFJqKuBN = 887209643;
    double BrWGMM = 531985.7074701427;
    bool TZuWOu = false;
    bool mkhErG = false;
    string EWRfPEQbPwbLi = string("ezCqcJNeAlvtaHPsKDTkNFyEs");

    return EWRfPEQbPwbLi;
}

fQTjPuxEi::fQTjPuxEi()
{
    this->yfHnEcl(string("enkVbGrPFNPklsnSPVuvIxEJzJVtMxZLeAxNUPSvwhbCzIoxePqddbbEDhzRsVNsJSYSrmCNrpUWZRQtRfxzmxnRkKULQmzjUxhrpdbujRqbQIVxkVvPPUEnKAYHpvIjnEfLpONkWZs"), string("UJYUFgiKsQJEhhaeYqBbMzrqCJChcpFWkyTaKCvNpAGetxVGNiIPWhxlvOdmyxgEATvVODwTAQJTMvyEFCSHDoaDcdxnvsTIHLkVzifsLkyohlzjBzRRbcdktylKNjbIkpIDerxYrgQvNbFlzfUlOHhTEmAJJbCoaGMqKcxxQPjcdAyUtxApQupI"), 218705.96590899685, -188812.11303775437, false);
    this->IUPhAr(string("xdYUHvTBbOyqXoOwmDYtfrdsEYZhptukVMMhAUiPoljNVxtKXHPHspoNEtWICbvCxjRmrBqWtQLQzThmgSVsAUqYPRIFUxkgvZTwkDKHlzNXvnJJardZAMpFiPoRHOUlZZuCr"), string("uGgmoMfzFAZkphsvAuEkZuwFUlBJZlOfaeBwzMdmpgHJYiUpqeoWX"), true, string("LbMIJpvhPFZVcWCKwnatUCxuVtyxVhThAPtnluueQAdVjjlhRehNJWCiNxhbOGOyyrIOiXncNSlqWQLVAxFVYuFMgcYlPVKAZdrGvJGJmzsjRIWnoZ"), string("AtKugTDlttmXQwuz"));
    this->pEMoGM(string("cgnlUeuXUokDGvaLXHhDjSQbnSMmTgJdcvEuPJUTQItvREcCUzLfZWuAjppVpeNeTLEHMClFQDjvZmDfbzJZZSTiVasVcMzmnwSultySvEuoItBCoftcZSnhSBQXjfeYFEyoHuhKJKpgfGayhHHvmzeUwIHFaAeHPKvHsxFkQFzOxrB"), 1648846978);
    this->hpdLcGKhmC(string("XdMxTgkDoCNoVOKnmgWSnLJuYuNktvoiQzUpMxQDohwQpyoTLldkZnDDlakKSmmm"), false, 472311.62151042523);
    this->RcltAb(774664.6047306884, true, 796834.2530363643, string("eBUtklPVkmLPfXZLHRwUasZnVnEJETMcTTqeVHORritxTmmBtQeildfNrULEZcxnYAUCfEKpfTYpZkcIjPzAmIPVRtHBgwDTtdahsnmkQfuRCxYdlnzbTHFxwYWSeUFeJFdCNHOAkGERyJKeL"), string("CYehJFNCJRvNxessFvdXKWNRfPCGhUlUnnGphGBnAXwGnwNMGFNtWFRWvfsvsDFigVGYYrYoDIVDkCyYdwXDxWSELSUjWTyHEFqPIZEhwckpbcyaHxuzSsHGWUmBrwjAwycsdlACBfNbLFURDSetQEYhuoXkLXDhPMaqIegGKqVykFwxxGZgHceTmzuPufQwiuk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FgqMvOkTgqe
{
public:
    int wNKqSKWaYfKbdIg;
    bool FZktYnfADdiHuLHJ;

    FgqMvOkTgqe();
    string OKRGZmmzdK();
    string aONQMsVOpOZJF();
    int rdIJydaTZQFiXG(int jRjBsQsuCeSJORtd, double dvPuJG, double gpXGhEEagOFr, bool aAPxgPrzCvgf);
    string cUxYgfqOvx(string SVrnacFvkJ, string bmxdfpkRcR, bool XRJpYQcXvEtvEF, bool ZzPtrNOTzs, int KLgqvtG);
    bool jPCjLdP(string kQnwLCTwPuPmfaaR, string xmFkqLDUcWMv, string eWnCwprVpk, int DOJgZaLDdok);
    double EfpvsSe(int WDxZAvZYA, bool glDpsyM, double wlhRZtHOKuLHBb, int lOlyB);
protected:
    double PJkbmEajE;
    string LliagGuuRIUVCBEI;
    bool FokiyjMyz;

    string RZAuzakXKiVOdNk(double dhmOANSvnbTJFyo);
    double zbjhqOVg();
    double CFQexpZqgn(int SZxPwlKmiQnWqS, int wnismb);
    int jKvgSFiCFizntaU(int apoXmQwY, int MQnTCTrr);
    bool rhxqsdprfUJ(double VTFCPngNlQA);
private:
    string QWjewADkARabIC;
    double duzhEQQpG;
    bool wbGEKFjdY;
    bool FUozzu;
    string zdMAALZchRU;
    string nlfqdamuwIeVin;

    void ifqmmmYC(int NfFrlQ, bool EyXjwpwrt);
    int SDPgHDpt(bool IjVssTJLcbz, int uiIRSrXJDfaqsR, bool mJIaSUqXSAngIs, bool yQhhLJSyplWZPHz);
    string fUEzVMH();
    string otVLXhTAQua(double ZBAAQVWbDA, int cSXNXMudSGZlzVuE, bool smFwPiM, string YoFcPZcXXaOCE, int RMUaANPOQjUzQdQ);
    void ZPVhMRDj(bool JoNyDHQABhZsVOs, double YIuPucZqAnVocI, string fkhlizkaGOVn);
    string ttUUVFiIJwtvyqWN(int mmkDxuTIEZSE);
    void mbtaxnFSOqbUfNe(int aeMjH);
    string GHsnBZuPVmYpb(int OHfaczXwjcfkuo, string LKSjJldt, bool GHfiRxPvdw, int YKPjG);
};

string FgqMvOkTgqe::OKRGZmmzdK()
{
    int tyTjFLOmTgGFd = -865353319;

    if (tyTjFLOmTgGFd >= -865353319) {
        for (int mBnbcFvmu = 1857789578; mBnbcFvmu > 0; mBnbcFvmu--) {
            tyTjFLOmTgGFd *= tyTjFLOmTgGFd;
        }
    }

    return string("BduCdnBxrHbJILBTfritGPYKfHEfNlbOsterztHafEwaZqhWaNVYofHlbtDgxNLRvUGGJXaiFuJsMsbYsJptqrFAVTDzsdEOoxQZGvHcBLMtuCuWwkkiXcrVknWnfPjCqhisNupBcMhoOvvvXQSeFEQhKFCfJrTnaMxncRNcJFTeEzHkXFAiQwFOZWUrdkCmyaa");
}

string FgqMvOkTgqe::aONQMsVOpOZJF()
{
    bool srzuClvndzzSyAL = false;

    if (srzuClvndzzSyAL == false) {
        for (int eHOxoBdtkpZqs = 521800929; eHOxoBdtkpZqs > 0; eHOxoBdtkpZqs--) {
            srzuClvndzzSyAL = srzuClvndzzSyAL;
            srzuClvndzzSyAL = ! srzuClvndzzSyAL;
            srzuClvndzzSyAL = ! srzuClvndzzSyAL;
            srzuClvndzzSyAL = ! srzuClvndzzSyAL;
            srzuClvndzzSyAL = srzuClvndzzSyAL;
            srzuClvndzzSyAL = ! srzuClvndzzSyAL;
            srzuClvndzzSyAL = ! srzuClvndzzSyAL;
            srzuClvndzzSyAL = srzuClvndzzSyAL;
            srzuClvndzzSyAL = srzuClvndzzSyAL;
            srzuClvndzzSyAL = ! srzuClvndzzSyAL;
        }
    }

    return string("GtfCLAklmfPmkaLfIEggCmGGdoEEAMafGiycLOwrKinjiOXRWfeMRIMtEhYhkcajloLWjnsYcYzFwOKFyQgJIHGcvhQWpvYQfDFfcmychQFCtLDmnvuKLfBrdMOsiPHEbIAuVKfgKcfFMAkstMYRxLeokWLCrGkvxbKNBcZnzeYTRGdOcxJAJjYzOIFRqUc");
}

int FgqMvOkTgqe::rdIJydaTZQFiXG(int jRjBsQsuCeSJORtd, double dvPuJG, double gpXGhEEagOFr, bool aAPxgPrzCvgf)
{
    string pveBlJGJoNckaZyl = string("RhjfQKkJBCikfonckhWkegbYsiJCdnXq");
    int QYKdNWiWXYvALZCZ = 1351267383;
    double bcdDleUFxMJjs = 556941.4231294245;
    string TpDesdFuJtnhb = string("jqvSyCWBZLuXxbhjwbxXMcGcUppqELaMHlWchSrIaaqPiHrAPoaCNUrCZnfsVeNpmqXyWQiYbNWWthhDKXMCMUgAbyzltGbMyUJurubnohGAMnGRmjDNHfunfifaEXtDPrDijOTpixtrNzepfeWddtGpQyYloJzQUGWxCAndALGWDhPxMgnnqOpvvxQELHdsIYAnNliJZsttzyUvUYWipBbvjprx");
    string ljrBJNPOHNCOH = string("bNakBRLpaYnd");
    double MUchtONaQvf = 224751.41405859153;
    int CagvervxT = 146413033;

    if (gpXGhEEagOFr != 299125.4752390028) {
        for (int bvfqUklmn = 528761920; bvfqUklmn > 0; bvfqUklmn--) {
            gpXGhEEagOFr = dvPuJG;
            TpDesdFuJtnhb = TpDesdFuJtnhb;
        }
    }

    for (int ldZKUpk = 2022457132; ldZKUpk > 0; ldZKUpk--) {
        continue;
    }

    return CagvervxT;
}

string FgqMvOkTgqe::cUxYgfqOvx(string SVrnacFvkJ, string bmxdfpkRcR, bool XRJpYQcXvEtvEF, bool ZzPtrNOTzs, int KLgqvtG)
{
    int WqCfjUempbbhQ = -527683298;
    int DoJNEuZfvRbTW = -20395637;
    int pfXZh = 1900567538;
    bool bwtdYvmbErqE = false;

    if (bwtdYvmbErqE != true) {
        for (int DqBABJYzCCiH = 277836308; DqBABJYzCCiH > 0; DqBABJYzCCiH--) {
            continue;
        }
    }

    for (int qKSBzXVnAAHb = 1927586055; qKSBzXVnAAHb > 0; qKSBzXVnAAHb--) {
        ZzPtrNOTzs = ! XRJpYQcXvEtvEF;
    }

    return bmxdfpkRcR;
}

bool FgqMvOkTgqe::jPCjLdP(string kQnwLCTwPuPmfaaR, string xmFkqLDUcWMv, string eWnCwprVpk, int DOJgZaLDdok)
{
    double uPilWvjBCmdSvWcv = -80511.84797281411;
    double JpPDJogbhr = -503762.051076971;
    double NluDy = 71694.32353571166;
    bool uYMBexIabJGI = false;
    bool sYVXQWXY = false;
    double njcCxFXSQNtCZe = -233385.51413907256;

    for (int OycjDVxJAudI = 1821707548; OycjDVxJAudI > 0; OycjDVxJAudI--) {
        continue;
    }

    for (int pooAzIIFnqdjMD = 1740078419; pooAzIIFnqdjMD > 0; pooAzIIFnqdjMD--) {
        JpPDJogbhr = JpPDJogbhr;
    }

    for (int ghJrdxububuV = 44345431; ghJrdxububuV > 0; ghJrdxububuV--) {
        JpPDJogbhr *= uPilWvjBCmdSvWcv;
    }

    for (int YBHskpGjLdB = 1749874702; YBHskpGjLdB > 0; YBHskpGjLdB--) {
        continue;
    }

    return sYVXQWXY;
}

double FgqMvOkTgqe::EfpvsSe(int WDxZAvZYA, bool glDpsyM, double wlhRZtHOKuLHBb, int lOlyB)
{
    string SfTOghROb = string("RawTciuitaiyBcYXijXNGeeyVJSyoAVHZosPHYzYqxgNBTETp");

    for (int rtkSfxiQY = 649504754; rtkSfxiQY > 0; rtkSfxiQY--) {
        WDxZAvZYA -= WDxZAvZYA;
    }

    for (int rramNI = 1820054943; rramNI > 0; rramNI--) {
        continue;
    }

    for (int tCaNyrHeqQrlFs = 512648880; tCaNyrHeqQrlFs > 0; tCaNyrHeqQrlFs--) {
        continue;
    }

    for (int rHvRI = 989385997; rHvRI > 0; rHvRI--) {
        WDxZAvZYA *= WDxZAvZYA;
        lOlyB -= WDxZAvZYA;
    }

    for (int sQLHa = 1834427850; sQLHa > 0; sQLHa--) {
        wlhRZtHOKuLHBb /= wlhRZtHOKuLHBb;
        WDxZAvZYA -= WDxZAvZYA;
    }

    for (int zFoSb = 466694980; zFoSb > 0; zFoSb--) {
        WDxZAvZYA /= WDxZAvZYA;
        glDpsyM = ! glDpsyM;
    }

    return wlhRZtHOKuLHBb;
}

string FgqMvOkTgqe::RZAuzakXKiVOdNk(double dhmOANSvnbTJFyo)
{
    string gBbLgrsU = string("KXCVrUrzMcMrPPLhkmPGPGLothHNiYtMeYIpVaebxnCAyoYmXdXMeaKkrAiZSUmfaINmgytrZ");
    int xtbFppJosNd = -471691839;
    double kavvjBkdRIlhjgFc = -151587.7646412976;
    double EBgNXGkhr = 994996.6342983905;
    double srguqwemAcLdgfIt = -220662.18430362648;
    bool xEYiWOYVTPauYEj = true;

    for (int HOPcXMsvGrfcrY = 1468338145; HOPcXMsvGrfcrY > 0; HOPcXMsvGrfcrY--) {
        kavvjBkdRIlhjgFc -= kavvjBkdRIlhjgFc;
        EBgNXGkhr /= EBgNXGkhr;
        srguqwemAcLdgfIt -= EBgNXGkhr;
        dhmOANSvnbTJFyo *= srguqwemAcLdgfIt;
    }

    for (int gFEaLQl = 621127492; gFEaLQl > 0; gFEaLQl--) {
        xtbFppJosNd += xtbFppJosNd;
    }

    if (EBgNXGkhr > -151587.7646412976) {
        for (int nKshlwmUI = 896842244; nKshlwmUI > 0; nKshlwmUI--) {
            gBbLgrsU = gBbLgrsU;
            srguqwemAcLdgfIt = kavvjBkdRIlhjgFc;
            EBgNXGkhr /= dhmOANSvnbTJFyo;
            EBgNXGkhr = kavvjBkdRIlhjgFc;
        }
    }

    return gBbLgrsU;
}

double FgqMvOkTgqe::zbjhqOVg()
{
    double AlfgBBJskJgR = 643539.3647002623;
    string cpPphnMdISqCUT = string("CmttuOLGHVnrSPclGIUySJZVitLGzmtnKjTCQBfZCmwZQfldLypaOEiPOitwSNgciHJObTXpaYiuVTncTzSrJMfJNjjgzsKBklfYDmdUMrOraWkCsjOhXZVwdTiXhtPZBDVQZsajTbiJzzwIwgvlLKVyjenrXzWfWFF");
    string NaZlRDTnll = string("qMInanCLSjYKZCupwKjRgaKOIuRnuvjgwMRWCjlSQjrdkTzrldtZuwYImjcOWWVlhuiAK");
    int JcTJOAGoBvB = -987414461;
    int LaXGpozj = -1437482356;
    bool YRGlSWsRgVVm = false;
    bool GdBoeHMPPKTMM = true;
    int XsrBMDjgAwBpl = 685053681;
    double vEurrwqqsPfCebC = 617740.5955145598;
    bool YIByV = false;

    for (int XOeobbnnOKpfGfb = 487446106; XOeobbnnOKpfGfb > 0; XOeobbnnOKpfGfb--) {
        GdBoeHMPPKTMM = YIByV;
    }

    for (int tnwrliDKFxeokc = 1335830980; tnwrliDKFxeokc > 0; tnwrliDKFxeokc--) {
        YIByV = GdBoeHMPPKTMM;
        GdBoeHMPPKTMM = GdBoeHMPPKTMM;
    }

    for (int pSmiUSZuLqloARdZ = 1770332769; pSmiUSZuLqloARdZ > 0; pSmiUSZuLqloARdZ--) {
        vEurrwqqsPfCebC = AlfgBBJskJgR;
        YIByV = ! GdBoeHMPPKTMM;
        NaZlRDTnll += NaZlRDTnll;
    }

    if (JcTJOAGoBvB < 685053681) {
        for (int HIKvvwGvMYNu = 2019523579; HIKvvwGvMYNu > 0; HIKvvwGvMYNu--) {
            XsrBMDjgAwBpl = LaXGpozj;
            YIByV = ! YIByV;
        }
    }

    for (int ejvBpEeuBJ = 1490180456; ejvBpEeuBJ > 0; ejvBpEeuBJ--) {
        XsrBMDjgAwBpl -= XsrBMDjgAwBpl;
    }

    return vEurrwqqsPfCebC;
}

double FgqMvOkTgqe::CFQexpZqgn(int SZxPwlKmiQnWqS, int wnismb)
{
    bool EVqVnwk = false;

    for (int MCqYRvXq = 1734531303; MCqYRvXq > 0; MCqYRvXq--) {
        wnismb *= wnismb;
        EVqVnwk = EVqVnwk;
        SZxPwlKmiQnWqS = wnismb;
        wnismb += wnismb;
        SZxPwlKmiQnWqS *= wnismb;
    }

    for (int pOmrxezMjckmIRpT = 726201313; pOmrxezMjckmIRpT > 0; pOmrxezMjckmIRpT--) {
        EVqVnwk = EVqVnwk;
        wnismb /= wnismb;
        SZxPwlKmiQnWqS /= SZxPwlKmiQnWqS;
    }

    return -90483.86915095996;
}

int FgqMvOkTgqe::jKvgSFiCFizntaU(int apoXmQwY, int MQnTCTrr)
{
    int gupTTwdefKKy = -775525419;
    bool BhXzASjP = true;
    int ZcChXzkPXlo = 1950837917;
    double ktSUQqgWfHAIXO = -1030634.5864032807;

    for (int aKYtvj = 1632673168; aKYtvj > 0; aKYtvj--) {
        apoXmQwY /= gupTTwdefKKy;
        ktSUQqgWfHAIXO /= ktSUQqgWfHAIXO;
        MQnTCTrr = gupTTwdefKKy;
    }

    if (ZcChXzkPXlo < 1950837917) {
        for (int dATAsdCwJmjOxSY = 247503794; dATAsdCwJmjOxSY > 0; dATAsdCwJmjOxSY--) {
            ktSUQqgWfHAIXO /= ktSUQqgWfHAIXO;
            gupTTwdefKKy += MQnTCTrr;
            ZcChXzkPXlo /= apoXmQwY;
            ZcChXzkPXlo = MQnTCTrr;
            MQnTCTrr *= apoXmQwY;
        }
    }

    if (apoXmQwY == 1283438884) {
        for (int lYCdNGjrH = 146261625; lYCdNGjrH > 0; lYCdNGjrH--) {
            gupTTwdefKKy += ZcChXzkPXlo;
            MQnTCTrr = MQnTCTrr;
        }
    }

    return ZcChXzkPXlo;
}

bool FgqMvOkTgqe::rhxqsdprfUJ(double VTFCPngNlQA)
{
    double VxrviTswadjP = -262918.16762638587;
    int SFxeBwHkKFYtx = 1961277160;

    if (VxrviTswadjP <= -262918.16762638587) {
        for (int BaDdjVz = 29252981; BaDdjVz > 0; BaDdjVz--) {
            VTFCPngNlQA += VxrviTswadjP;
            VxrviTswadjP *= VTFCPngNlQA;
            SFxeBwHkKFYtx /= SFxeBwHkKFYtx;
            VxrviTswadjP = VTFCPngNlQA;
            VTFCPngNlQA -= VxrviTswadjP;
            VxrviTswadjP = VTFCPngNlQA;
            VTFCPngNlQA *= VxrviTswadjP;
        }
    }

    return true;
}

void FgqMvOkTgqe::ifqmmmYC(int NfFrlQ, bool EyXjwpwrt)
{
    bool kRoosMhLe = true;
    int wiHDUvrkBvTsib = 68376948;
    bool ecxkWHZpYPfhm = true;
    string vNmmCavDwuJOd = string("AUvRYOdcMykNxsWdTtsFnfykQZicKKVPYXwTPzAmCwlHBGlaZntntHdXUzsUNiyQhqHZPSTVJUaCofkCAsRSUBDDcoiVzVSwQUcIdHjvQBgWPwaSRktRtvjchxseWIYdHwwZvPsLxUsvEYCSfnRMqFZLBKBDAokEhQDiisfazSlPllQLcEQ");

    for (int fiNTiVuHSI = 377087756; fiNTiVuHSI > 0; fiNTiVuHSI--) {
        continue;
    }
}

int FgqMvOkTgqe::SDPgHDpt(bool IjVssTJLcbz, int uiIRSrXJDfaqsR, bool mJIaSUqXSAngIs, bool yQhhLJSyplWZPHz)
{
    int uutRTyK = -90930639;
    int kXjSszEfrET = -776344772;
    string fsTHqdtqwlLnU = string("CjwwEfPOWCLrXQBnilKVSmguYgbxDtEYylMREpSmpVTPsYpRfExIzwaSPI");
    string gVagjtsgB = string("xatJbnLViEaKfLQNOlFWoKQItalYnJpBPurUGsDAxuq");
    string rCYNWfHBCdqWJ = string("BzuRhomBZwveTLDA");
    string oQvLq = string("wHRHWbufNmfOgdEYydccuUykiLItiKrFhSDkjEGLRzhWnLOScAMTMrcDjrFAqYxaEwpOqCyBINasdRIDCIMJnHJKPhpnxrESWPVrPtyKUHp");

    if (gVagjtsgB < string("xatJbnLViEaKfLQNOlFWoKQItalYnJpBPurUGsDAxuq")) {
        for (int VsfjzIEnY = 1935888461; VsfjzIEnY > 0; VsfjzIEnY--) {
            gVagjtsgB = oQvLq;
            IjVssTJLcbz = yQhhLJSyplWZPHz;
        }
    }

    if (yQhhLJSyplWZPHz != true) {
        for (int RhexsI = 1686979399; RhexsI > 0; RhexsI--) {
            gVagjtsgB += fsTHqdtqwlLnU;
            yQhhLJSyplWZPHz = ! mJIaSUqXSAngIs;
        }
    }

    for (int zjfDy = 829736090; zjfDy > 0; zjfDy--) {
        continue;
    }

    return kXjSszEfrET;
}

string FgqMvOkTgqe::fUEzVMH()
{
    string YxUfWLQuQNtaxwNg = string("QGKenmnyoKwSThqbBWeRknHhRSmexuxyaxSCxWLqQIPSmNGnSf");
    string ClVJjAClWCceZsj = string("GupeyUTaHDIXJ");
    string LnNdw = string("xvaCTuivMhjBKlMSoaRgmAAVDUhhEdXNJjSCleQNLobwaXWygYgbwOryUreEbYXPJahgUnLTcrtaPkRDamCkFPUaHzCadKXMjKAzNvAxSUCXiAyyPuiNnbYxxmqKcNGtsXzdDNimciQhxTwcVcTIScWtetFibRezTNTrLnKtnkNfKgVr");
    double sSTKsgJ = 587542.99938221;
    string VyZRKbJH = string("rUHeEQdHkhJqkLqPIeaZYFIXSHJqBzDzJTavsxsnjNOWiQYcyWfMmdLDuxIizYnYdQMgcFmaAUipERzghbFZtLAbVFaXBBgDbGSEKYXpPuizXLszPyHpzoaQRLnRqGVOnlPTMcGYhncqZBTYhPtVHK");
    int CMwaxrjiEBh = 1750495675;

    if (VyZRKbJH < string("GupeyUTaHDIXJ")) {
        for (int bcZgwPd = 1592392782; bcZgwPd > 0; bcZgwPd--) {
            VyZRKbJH += YxUfWLQuQNtaxwNg;
            YxUfWLQuQNtaxwNg += YxUfWLQuQNtaxwNg;
            VyZRKbJH = ClVJjAClWCceZsj;
        }
    }

    return VyZRKbJH;
}

string FgqMvOkTgqe::otVLXhTAQua(double ZBAAQVWbDA, int cSXNXMudSGZlzVuE, bool smFwPiM, string YoFcPZcXXaOCE, int RMUaANPOQjUzQdQ)
{
    bool ZyYVqeMgqUN = false;
    bool jpZcwKRfLdBU = true;
    string vTUNxekwIddmL = string("UNWHDmezxnJPuMQeqAHnRUuYxVCpEfePPUeqRhiyHLoUMlZjeb");
    string gBpfRa = string("grLSwZGEEMyQLZYVCZszOMgsLPXO");

    for (int AgqDESvtZ = 2092192620; AgqDESvtZ > 0; AgqDESvtZ--) {
        continue;
    }

    for (int gxxpFupCSiZhSrNI = 1082716701; gxxpFupCSiZhSrNI > 0; gxxpFupCSiZhSrNI--) {
        continue;
    }

    if (ZyYVqeMgqUN != true) {
        for (int VQSbSoYqK = 1567951737; VQSbSoYqK > 0; VQSbSoYqK--) {
            YoFcPZcXXaOCE = gBpfRa;
            RMUaANPOQjUzQdQ *= RMUaANPOQjUzQdQ;
        }
    }

    for (int TKtHnUjmDRJvPN = 416563369; TKtHnUjmDRJvPN > 0; TKtHnUjmDRJvPN--) {
        ZyYVqeMgqUN = ! ZyYVqeMgqUN;
    }

    return gBpfRa;
}

void FgqMvOkTgqe::ZPVhMRDj(bool JoNyDHQABhZsVOs, double YIuPucZqAnVocI, string fkhlizkaGOVn)
{
    string gNHbBXpjQZwEJvG = string("ukGnKnhDeWgbmWIqYvUJeZHOSpaFVdKEZMsCjzsVpaCl");
    int YHfTIGnVXOPXean = -1009672985;
    int OzfiORapdkMFpFKs = -1190863481;
    bool YrBkKbd = false;
    bool SJZGZlK = false;
    int ngjubFWaWvq = -1227347748;
    double tvmdFmNFzCHf = -287237.3493745461;
    double hoZQmb = 545074.9611864832;
    bool raYPzLYi = true;
    double khQcnMkkMF = 1010175.3432009406;

    if (raYPzLYi == false) {
        for (int OgZTOaxnVxilgdm = 493818697; OgZTOaxnVxilgdm > 0; OgZTOaxnVxilgdm--) {
            ngjubFWaWvq /= YHfTIGnVXOPXean;
            YrBkKbd = ! SJZGZlK;
        }
    }

    for (int lTMxrOPJS = 238663376; lTMxrOPJS > 0; lTMxrOPJS--) {
        continue;
    }

    for (int PzcmdNbdW = 135230968; PzcmdNbdW > 0; PzcmdNbdW--) {
        YIuPucZqAnVocI /= khQcnMkkMF;
        ngjubFWaWvq += YHfTIGnVXOPXean;
    }

    for (int gGXDZBNO = 1802743167; gGXDZBNO > 0; gGXDZBNO--) {
        continue;
    }
}

string FgqMvOkTgqe::ttUUVFiIJwtvyqWN(int mmkDxuTIEZSE)
{
    int nitOh = 141516478;
    double fwOafiulAUq = 946564.2790368034;
    string mnZYaNJpFyp = string("hWSnYlAWZrhvKRLzxlZYQpKPQgVlQccGxfEaGLiOmYpoSjuzsDlP");
    bool EGxJgc = false;
    bool jXouVNjSJUTsf = false;
    string ZMyzsyUB = string("DUAYtKdPTOXGDyvfThMDWCmjvbeNAaFzTEMKhNqQayKLhtwGUKNMBkdJgqxgyyqfkRIxIucMJYqqIHIjztckiQEokEXJtwfGEYexQOcieHWJZMxKykZEYSsgBkpIlbZZNVLRwqtvqzJFVWgAdWdhoOthtKxxqDISgYtvluaYjBzCijDrijGsUFCQNVannfvyCKFOvmfEcehirqAvoxVWcifGGoHuNwHUUzgGvqbxSPQfeIOF");

    for (int mNIaFSbco = 1344662159; mNIaFSbco > 0; mNIaFSbco--) {
        jXouVNjSJUTsf = jXouVNjSJUTsf;
    }

    for (int ytapiGtY = 877709211; ytapiGtY > 0; ytapiGtY--) {
        mnZYaNJpFyp = ZMyzsyUB;
        nitOh += nitOh;
        ZMyzsyUB += ZMyzsyUB;
    }

    return ZMyzsyUB;
}

void FgqMvOkTgqe::mbtaxnFSOqbUfNe(int aeMjH)
{
    double KlxtwmEaWiIoE = 48322.24021072589;
    bool AuRuTdbXvQEUGhjB = true;
    string TnhlsqKL = string("yHNqkfGQdSubMwXjoNweBVKjHNvxgaAxpYPzRCIlmNHBQY");
    int rYIrYlyCvvOa = -1068329619;
    bool FUfmmejP = true;
    string nESraY = string("ghqlOmkMQmMUhciO");

    for (int yQMggnFQDSuezLA = 685463346; yQMggnFQDSuezLA > 0; yQMggnFQDSuezLA--) {
        AuRuTdbXvQEUGhjB = FUfmmejP;
        TnhlsqKL += TnhlsqKL;
        AuRuTdbXvQEUGhjB = ! AuRuTdbXvQEUGhjB;
        nESraY += nESraY;
    }
}

string FgqMvOkTgqe::GHsnBZuPVmYpb(int OHfaczXwjcfkuo, string LKSjJldt, bool GHfiRxPvdw, int YKPjG)
{
    int mvHIZYzRXmeFtRiB = 667737463;
    double sqynXvmkCa = -91328.46603279462;
    string QSIgHwHJcswoLJ = string("Kuqmxm");
    bool fTPossV = false;
    int JIQNLHbdzXk = 577692761;
    bool NeitrAaIhHFfcoLx = true;
    string yzPSokCkWXgMuTh = string("AMgpybNlFpMSZavnfkavHSrJfllCIJQiTTrhZZxkLytbYGSpMCOwfmpkAHNZZQrEOPcLaqDmoZWIflgbyKiJpQDaRsAEoYtnRlalxrkXdJltBDNmeBhgyFoUtJhysGPQZWmFTZeGuBijyFOtACSWYdgineCghoPtKFndVD");

    if (YKPjG >= 667737463) {
        for (int jWwIYnPHuzOuTwz = 94774323; jWwIYnPHuzOuTwz > 0; jWwIYnPHuzOuTwz--) {
            GHfiRxPvdw = ! NeitrAaIhHFfcoLx;
        }
    }

    return yzPSokCkWXgMuTh;
}

FgqMvOkTgqe::FgqMvOkTgqe()
{
    this->OKRGZmmzdK();
    this->aONQMsVOpOZJF();
    this->rdIJydaTZQFiXG(857081854, 299125.4752390028, -75630.75968275269, false);
    this->cUxYgfqOvx(string("PmrRyvjdiNsArJzbjNVGwBtljyJoGUmtajEoCpovYBujBKMNqSeckjzNsQpKQpxUmPXRgwmGfeUgMLigXAnCBeBplAysesibEvvaOlTPYcPqAJuHrRgMRAFgTNJomCfJRigcxplIGwBGNDTItgfgHceaxmP"), string("ssoJJTXuTQeAWkfgyeKmUXBMsrQgkDIbnvDidpKoVRSGrLComGjAJLgLLzcuRjJYNYARXEgLAwnKnuBkMkAvFVvkdZBFhWUHQFfrJivYpbILozPfSyisWtTCFZVeEbBaFlFpeLSDd"), true, true, -533971613);
    this->jPCjLdP(string("NXxOYELheTThOvDoAFznSQHqsVNJkvtzuDqDjYZmiYfLOJJBjdYHndvmLqlLAmKtApZEFVyjVejUFfxWwFyxhibURnKhrarTZeFqAyVmizRZLMqWRfobkxKUVrFzjshrqm"), string("HVMqwisCIdZGqmePHSlwzSukxWNndGhAzIhXgNIVaMcMkLuYKDBIvmhRsjAwTkMxdMxHzVIVXFhsfdXxxIcSXBCiPTMjXynknMuzQiLwTtbZSQIxrzbveOXsZXyOjmRiMudvrTAANoLUSzhvbKLzclqTUKkesBszNgdZGyRwRqUNmaxGbZiAiBDaoNYSJOworN"), string("KAClNFjpoQpkAstVbiincxyRViPHYiDvKDnqaLragZZbRhSSLgLBLXovatPxBYuwaeibZAvFQPikuzXpFGNCMMdMaeFjrkkPcRyndfGvxTdSEFpEzxZY"), 978014960);
    this->EfpvsSe(1252453263, false, -628503.9248201242, 1355419603);
    this->RZAuzakXKiVOdNk(-57681.460512658516);
    this->zbjhqOVg();
    this->CFQexpZqgn(-67572488, 1181790325);
    this->jKvgSFiCFizntaU(1283438884, -646620994);
    this->rhxqsdprfUJ(-618371.5842844909);
    this->ifqmmmYC(1671759964, false);
    this->SDPgHDpt(true, 212865905, false, true);
    this->fUEzVMH();
    this->otVLXhTAQua(-713621.1223023176, -1590800379, false, string("TwKLDOLNGnUzVmkyBDIsxKoczrBUfxwpvEFynUgFlhAEMtjrJNLXjdhCnbtiqwIaECfmuBCxVwSYYnSovFeojbWPSQOINlzhQXYaKqoWCa"), -1019774746);
    this->ZPVhMRDj(true, 280581.7586923761, string("urhfDdnfBIeWUSTARqBGIXrgjTREYoaVunjPZDXLqBxknbymqYFiKFqMfCuE"));
    this->ttUUVFiIJwtvyqWN(1487008899);
    this->mbtaxnFSOqbUfNe(805478928);
    this->GHsnBZuPVmYpb(-271280681, string("FClfekBgYsFUUgDDgJVaTSGgpMVRKUxqUfkkBUnrckrAzivOlCeomRZTmNLuMajfvXFvLsbIttdTbEINQyQilfDfeozzivnLwFAqHHaKpAsFGYNWVGZLsvtzotuJgUcuQYQVkYfefxhatvBHwSuTDMITOJagpyUqZnNiaKgTGiKswUaaQtARRQZkUbdMniaWPRyDZsTZas"), true, 1234300886);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fWRxMtvpdi
{
public:
    bool SGrVdVGLcZL;
    int tehGqz;
    int xSeuKFczbXFo;
    double tBqDho;
    double mMzDNaGUBHXzKA;

    fWRxMtvpdi();
    int mYZERhX(bool WzBYysj, bool qfiLmGNAYMuKeHu);
    bool ismlAzjzDDQjyPdl(string VnaIpwUIprpz, string GsnmAcEdVwd, bool kuxLUmwnLwlon, bool orSLVMWL, int CxiPjlZqmgPuEkf);
    bool ROOvBtWua(bool aHLGVxMzAqTDl, string brMqGpEiW, double FCQTIIkrTkLUbW);
    double qDJigrWaYCTE(string XxMxYwQz, double hQvWVqWvAIVk);
    string NGpWX(bool zMUtQMV, string spKsBJcDbQGfUq, int DImJYURxxeyCA);
    bool bzifyDCjYM(bool RUowMF);
    int ZoprrKRHsondFyiF(string MTWOfh);
protected:
    bool WqyVrIzSepmt;

private:
    bool PYKkuL;
    int vRbbGK;
    bool WgcJlmD;
    bool MiwXpty;
    int qEfyvpgS;
    string HetAKKrAMgOUQ;

    double gaatcHOMjHFLT(string NgMJf);
    string vfJGEceScJWfgWYd(bool LjiaMoueN, string jZIiilIKstoKIXq, int wukpFlRuEm, double xivEEc);
    void yJqLDJSMBvsf(int OnzUULBRWJpN, int nGbGa);
    string jBIWEYcMTinTOJp();
    bool xquQruviP(string CGbuDCAdC);
    bool PmWXsoGEeCxFwx(bool BGCNLluDZWH, string tTvHAAPLeyLsOceA, string uDDCstYAlvVFC, int sGNWVBHUlnQsCA, string cFNygYuT);
};

int fWRxMtvpdi::mYZERhX(bool WzBYysj, bool qfiLmGNAYMuKeHu)
{
    bool japkMIZLuenoeGE = false;
    double cXVomEmnYUfufvQ = 684418.976255645;
    bool OjkAKuevuUPUJ = true;
    string LnTjeS = string("qEcwQAPKwsjdtWSDXEZmmxVgmBmNQBbyHPfqVklXGwzgvpqznZhQcVzzOIYFmiIZNJHHkwVqDWpLLQuxYsfNSyBxbtlyJUltuoogeUGRzwmONJfNfawYudsGzdnEyFdBiRVMVXSiuYhoswLbfIOCpLMlzLUHueXBVlDauOwTUJmPNybNHXhGScucKWGtqsusSWwftuDDlmiVtjbuGutjKVqj");
    int yBNVSojwQPT = 413879632;
    double DKRUlGIDCcCtQG = 258634.44648262084;
    bool GzDoorKyaswufEPZ = false;

    return yBNVSojwQPT;
}

bool fWRxMtvpdi::ismlAzjzDDQjyPdl(string VnaIpwUIprpz, string GsnmAcEdVwd, bool kuxLUmwnLwlon, bool orSLVMWL, int CxiPjlZqmgPuEkf)
{
    bool MdHWRbEe = true;
    int aWNBrA = -1796119879;
    double aVcydSfdOISgl = -514930.0844202613;
    double kAspKgz = -775225.4008349256;
    double XymBgkT = -285910.39103125053;
    bool KERoxfJ = false;

    if (KERoxfJ != false) {
        for (int iRwfSk = 1238134872; iRwfSk > 0; iRwfSk--) {
            MdHWRbEe = MdHWRbEe;
            XymBgkT += aVcydSfdOISgl;
        }
    }

    for (int BckMAYOKipjkCL = 1882735976; BckMAYOKipjkCL > 0; BckMAYOKipjkCL--) {
        XymBgkT = kAspKgz;
        orSLVMWL = KERoxfJ;
        kuxLUmwnLwlon = ! kuxLUmwnLwlon;
    }

    return KERoxfJ;
}

bool fWRxMtvpdi::ROOvBtWua(bool aHLGVxMzAqTDl, string brMqGpEiW, double FCQTIIkrTkLUbW)
{
    string JiZLCUVJKx = string("hcVwBdFDYqrGFAAsZSFaWiYdwSeQFTndWaHYkvVthquJlUCGQyaTKRtjFyczGlCKnVrqqMTKZpgvGVtUCswQDhOlaGxQYaGFJHpyAWRXEpjUDyCRiNZqQzdILNwQfqSmAfUNGuHDmuKDrxtiMaZjcduMoDLlHfjVEliCusOUUponKFGhMBklqIqRRqhKxqFxVwjNvK");
    double kqBCwMMYJYNq = -770215.0843871792;
    string IVIZgtEH = string("iiqrPmTfpLyGNYaEeICaKEUHRKxiaVCbroZAcqnNQFkBjxFtGLneQUPauWNgqNDZnmumGggIVgsXBIHhDQXrpxtY");
    int sgKlqdjMwufCZ = 1876128940;
    double yahZhqEpVHDdHTzV = -732493.9555889274;
    double lRgVvqOyFpYw = 128858.24957704509;
    double hLkmbFsJLskf = -599859.8938824532;
    bool pEowQtAa = true;
    string LZstYuVV = string("tzbPEmGIRLGEelvBEHYFrhTvnXbhmqiUJkKVCtNDdQakdXRfgcFIYkgQFTfkXPGVQb");

    for (int iIrLjHCKk = 553486531; iIrLjHCKk > 0; iIrLjHCKk--) {
        kqBCwMMYJYNq += yahZhqEpVHDdHTzV;
    }

    for (int qUzjyfUEJwcSm = 678490875; qUzjyfUEJwcSm > 0; qUzjyfUEJwcSm--) {
        LZstYuVV = JiZLCUVJKx;
    }

    for (int VckIBOrufqYGHzQy = 1242458244; VckIBOrufqYGHzQy > 0; VckIBOrufqYGHzQy--) {
        kqBCwMMYJYNq += yahZhqEpVHDdHTzV;
    }

    return pEowQtAa;
}

double fWRxMtvpdi::qDJigrWaYCTE(string XxMxYwQz, double hQvWVqWvAIVk)
{
    string flONyrOMMdUYLBpF = string("EzlQXDwomfTsIgGHGAEXnktWs");
    bool DpecS = true;
    string rYVjNXbz = string("UKYyaWqWGXJVdlfsfEhzKGTBOqGGcdINaoVMKbMoqwCaqBFdivmaHLIYnxtkhmfErprXEsvldMlIHKAjIRLhmOIJrFayiOiDNQlUiPMaYwnoTfKixrsfKGwJBADBgCYXytKEgWALpbRjCtZSafdUiRBdsbtUkjMIrIImzJZofPxCXIsiWFwsNkCvFOseSkVxktMWlpsZLIuXvizwFBeuMhBrXKmIVPkJhbJbEjmiSPiBYuxGB");
    bool zYthAMJD = true;
    int czlFoA = 1959575450;
    string DYsyndxY = string("PXsTSTeLjBrnQlTPcByWPHOzFvyZjmUYcoEqFVBnOPscBxSnJbJQdKTcjrmlGSTfmjnFnXXgjfXJUsbuyhcIoBsDumHPAwYPqlDXCJhqQewNFGwNQsfEctDpKVBDyjgxGaZFSbqruQWAZFDHQXWQvdGxzKHFLYvVVlqOUYhJGqipNXRzGcBFAKTmONmtOujqWwcUGAdLEaOeiiMNtzqsrjyaasWSAVzKl");
    bool jRWghsepq = false;
    double dQFYXX = 3687.1494009021544;
    bool VWrHCqOEkkUSSUTT = false;

    if (jRWghsepq != false) {
        for (int oXByKRmQYhjHS = 256298022; oXByKRmQYhjHS > 0; oXByKRmQYhjHS--) {
            XxMxYwQz = flONyrOMMdUYLBpF;
        }
    }

    for (int vMRIaL = 1423620951; vMRIaL > 0; vMRIaL--) {
        rYVjNXbz = DYsyndxY;
        VWrHCqOEkkUSSUTT = zYthAMJD;
        VWrHCqOEkkUSSUTT = DpecS;
        zYthAMJD = VWrHCqOEkkUSSUTT;
    }

    for (int RCLSGrOXwBQIRu = 1591858398; RCLSGrOXwBQIRu > 0; RCLSGrOXwBQIRu--) {
        jRWghsepq = DpecS;
    }

    for (int ODRVyB = 1244162864; ODRVyB > 0; ODRVyB--) {
        continue;
    }

    return dQFYXX;
}

string fWRxMtvpdi::NGpWX(bool zMUtQMV, string spKsBJcDbQGfUq, int DImJYURxxeyCA)
{
    string CphVCFaB = string("fhsvEBROaeVdvnz");
    bool AIryA = false;
    string OPmkQKgBN = string("enSPyHlmDkcveJaQNUQGunkRCttDBXVvSiEaXLuDqZnTGkWOdSausKyxSoUnExisYVsrpVreItbzHvlwcUaPtmgtlUUyqDDhPsVCIfwZDzkiEBqlvQnaFEtDGdRmOsSuMDtJHCZCtRSkqRddxfBQvBWYqsDxiPyfGxwHaGKDPQuxNegpdrTFFqiWOXEiIoiTIfnCmfnNEF");
    string JPUgYG = string("dlAFunFbcSHhfLlrALkBqqKsSXykvDTutrebHyAhXWf");
    double xeXmmrj = -538908.6906737547;
    bool ggwVnREHe = true;
    int OWfZWoeMrmPVpQ = 1126348766;
    bool GELmoccluWqeGUn = false;
    double JezGJSWRjrhDM = -361754.20496365323;
    int mysOOE = -737109163;

    for (int XuoTH = 404798601; XuoTH > 0; XuoTH--) {
        continue;
    }

    return JPUgYG;
}

bool fWRxMtvpdi::bzifyDCjYM(bool RUowMF)
{
    string azKSvfpvjaBDX = string("OZXoLNrwjNLkTFDHRxCazVdSSRnUYtGGzYAiruTQxChphSMCERTlDffHnyrlRBzOuuelmZYBQbNrbIvZeIvrhzXjfBDrAiomyDVcogzDQvp");
    bool wOAeMlbFWGSmA = true;
    int bIxBXdtZewhWqF = -169733394;
    int kxgKvKdyTOjfSFx = -422713320;
    bool cPEMSnuKxdAQbPH = true;

    for (int vlEbDaivJrtQvjbM = 1095808440; vlEbDaivJrtQvjbM > 0; vlEbDaivJrtQvjbM--) {
        cPEMSnuKxdAQbPH = RUowMF;
        azKSvfpvjaBDX = azKSvfpvjaBDX;
    }

    return cPEMSnuKxdAQbPH;
}

int fWRxMtvpdi::ZoprrKRHsondFyiF(string MTWOfh)
{
    int uUNnGoUe = 1241980528;
    double HddTXENMg = -527905.0508966797;
    int cnQrQnQsMNrHYS = -1835482592;
    int eNrGNLc = 656111140;
    bool IGYiUWxXUGulsryZ = false;

    for (int xuwZbbrWQLgu = 417469553; xuwZbbrWQLgu > 0; xuwZbbrWQLgu--) {
        MTWOfh = MTWOfh;
        cnQrQnQsMNrHYS = eNrGNLc;
        cnQrQnQsMNrHYS *= uUNnGoUe;
        cnQrQnQsMNrHYS += uUNnGoUe;
        uUNnGoUe *= cnQrQnQsMNrHYS;
        cnQrQnQsMNrHYS -= uUNnGoUe;
        HddTXENMg += HddTXENMg;
    }

    return eNrGNLc;
}

double fWRxMtvpdi::gaatcHOMjHFLT(string NgMJf)
{
    bool CCNiqqiSANrN = true;
    string ZsZNNobEZ = string("cQUYMmxVgbmYsCnIVwrqgwVdXvR");
    double kMvqDtoedN = -498879.84419904475;
    string XXbfSAF = string("rGFQXYIINlKpqfePWAlIxKdLkfovgjYzzUDai");
    string JwKFSW = string("czTxlfVlebwdlYVgXQqwEVzuHuoamnyGWcIVkuDlqdKpijffRkLlJsxFykNOrIPfWQTymzIzqenjBZylkLpFSEgImBtQFQoPIxiXToKbPtOmvjrlYWuknHbVTBfyjSrPRkognDnnzKsZWLOjLPvOrvCEOKoAGYeiopSwihqIToBDusNGrnTFZOQdUeSCmfKiFZSRCcUdXtNmvmCpbSQdQ");
    double jThRhTMMqw = -454424.4521761206;
    bool gsQmbUNV = false;
    int dGatuywy = 1394123662;
    bool LqIMJZu = true;
    double SJAIwMUWeILDmvCe = 628902.933286696;

    for (int uGsqLLWF = 1914052561; uGsqLLWF > 0; uGsqLLWF--) {
        continue;
    }

    for (int mAQXnVK = 82164772; mAQXnVK > 0; mAQXnVK--) {
        kMvqDtoedN = SJAIwMUWeILDmvCe;
    }

    return SJAIwMUWeILDmvCe;
}

string fWRxMtvpdi::vfJGEceScJWfgWYd(bool LjiaMoueN, string jZIiilIKstoKIXq, int wukpFlRuEm, double xivEEc)
{
    string mQYZlbaDfc = string("SJWCMheEqWcROQeLbocutAuafdEosLQmGduDnKBVuZgRJDdPelYorLtS");
    bool QhywdUSCKtE = true;
    bool vucMfShjQh = true;

    for (int rJKztnPoTYIcQU = 739632125; rJKztnPoTYIcQU > 0; rJKztnPoTYIcQU--) {
        LjiaMoueN = ! vucMfShjQh;
    }

    for (int NaHOEl = 667510254; NaHOEl > 0; NaHOEl--) {
        QhywdUSCKtE = ! LjiaMoueN;
        LjiaMoueN = ! LjiaMoueN;
        LjiaMoueN = vucMfShjQh;
    }

    return mQYZlbaDfc;
}

void fWRxMtvpdi::yJqLDJSMBvsf(int OnzUULBRWJpN, int nGbGa)
{
    string DxVgzXHvOYb = string("ePrrtDwFXPfaVjCAbDSonkjjOubjwxOMfqglcPocppPAuFlqrarZIqGXLEwSUnOHDCJDiEzt");

    if (OnzUULBRWJpN <= 1469440000) {
        for (int glcMKQamvLcDR = 1473120902; glcMKQamvLcDR > 0; glcMKQamvLcDR--) {
            OnzUULBRWJpN += nGbGa;
            OnzUULBRWJpN += OnzUULBRWJpN;
            nGbGa += OnzUULBRWJpN;
            DxVgzXHvOYb += DxVgzXHvOYb;
        }
    }

    for (int ydAKZfZS = 380567152; ydAKZfZS > 0; ydAKZfZS--) {
        nGbGa += nGbGa;
        DxVgzXHvOYb += DxVgzXHvOYb;
        DxVgzXHvOYb = DxVgzXHvOYb;
        nGbGa = OnzUULBRWJpN;
        nGbGa *= nGbGa;
    }

    if (OnzUULBRWJpN <= 1469440000) {
        for (int IBIXNzpVmVpzVoR = 398291062; IBIXNzpVmVpzVoR > 0; IBIXNzpVmVpzVoR--) {
            OnzUULBRWJpN *= OnzUULBRWJpN;
        }
    }

    if (nGbGa < 1469440000) {
        for (int sGAfwxydxeG = 543895088; sGAfwxydxeG > 0; sGAfwxydxeG--) {
            nGbGa /= OnzUULBRWJpN;
            nGbGa *= OnzUULBRWJpN;
            nGbGa = OnzUULBRWJpN;
            OnzUULBRWJpN *= OnzUULBRWJpN;
        }
    }

    for (int mAFNZ = 22288673; mAFNZ > 0; mAFNZ--) {
        nGbGa += OnzUULBRWJpN;
    }

    for (int gkIlZiCmdaus = 871316306; gkIlZiCmdaus > 0; gkIlZiCmdaus--) {
        OnzUULBRWJpN /= nGbGa;
        OnzUULBRWJpN += OnzUULBRWJpN;
    }

    if (DxVgzXHvOYb <= string("ePrrtDwFXPfaVjCAbDSonkjjOubjwxOMfqglcPocppPAuFlqrarZIqGXLEwSUnOHDCJDiEzt")) {
        for (int IKYmO = 681713577; IKYmO > 0; IKYmO--) {
            nGbGa /= nGbGa;
        }
    }
}

string fWRxMtvpdi::jBIWEYcMTinTOJp()
{
    bool JIcKac = false;
    bool RIdBlezdm = false;
    string fJgzZuTDBNArjsm = string("tUtiHKCOmcBptcWQQLoJyXbVUtqHbNnEMrQEduKpJuperHyMLWYxIHrxGrkIlmakATIOuJkCJsxGOCnjnPBNRkTNgPELpnzTtacWZlFMKCFXOwVDlsRbqIwASMZWgmHkVwVaMEakXWLYlgjvCFlARSunXYEnvwhdspRoXbisBuHQFPzfCxKGRENqBHzAizkpDeHyZlkPLzEIdmEKQhPPjGwd");
    string YnxDEQTUFgFFPi = string("vALWSGbemBUZwQMOqCFPlBspgNeCKrJjUbOrBPunBupkLSsrrFTpCjpMcXsBbziMYWrKiEoLRngYFQCyGSGUHrYYhuPdodo");

    for (int mQaFhfFBip = 166937457; mQaFhfFBip > 0; mQaFhfFBip--) {
        YnxDEQTUFgFFPi = fJgzZuTDBNArjsm;
        fJgzZuTDBNArjsm = fJgzZuTDBNArjsm;
        JIcKac = ! RIdBlezdm;
        JIcKac = JIcKac;
    }

    for (int hvypul = 1087437469; hvypul > 0; hvypul--) {
        JIcKac = RIdBlezdm;
        YnxDEQTUFgFFPi += fJgzZuTDBNArjsm;
    }

    if (JIcKac != false) {
        for (int zPedec = 914577109; zPedec > 0; zPedec--) {
            JIcKac = JIcKac;
            JIcKac = RIdBlezdm;
            YnxDEQTUFgFFPi = fJgzZuTDBNArjsm;
            fJgzZuTDBNArjsm = fJgzZuTDBNArjsm;
            RIdBlezdm = ! RIdBlezdm;
        }
    }

    for (int YylwxpMS = 1251549592; YylwxpMS > 0; YylwxpMS--) {
        fJgzZuTDBNArjsm += fJgzZuTDBNArjsm;
        fJgzZuTDBNArjsm += fJgzZuTDBNArjsm;
    }

    for (int phnnRiCBpZ = 1899662748; phnnRiCBpZ > 0; phnnRiCBpZ--) {
        fJgzZuTDBNArjsm = fJgzZuTDBNArjsm;
        YnxDEQTUFgFFPi = YnxDEQTUFgFFPi;
        YnxDEQTUFgFFPi += fJgzZuTDBNArjsm;
        RIdBlezdm = ! JIcKac;
        RIdBlezdm = ! JIcKac;
        RIdBlezdm = ! RIdBlezdm;
    }

    return YnxDEQTUFgFFPi;
}

bool fWRxMtvpdi::xquQruviP(string CGbuDCAdC)
{
    double BfqypP = -422726.8295856789;

    for (int ixLtVPI = 257800655; ixLtVPI > 0; ixLtVPI--) {
        CGbuDCAdC += CGbuDCAdC;
        CGbuDCAdC = CGbuDCAdC;
        BfqypP *= BfqypP;
    }

    for (int gbYpUmzfGVaQyHy = 1448926691; gbYpUmzfGVaQyHy > 0; gbYpUmzfGVaQyHy--) {
        BfqypP += BfqypP;
        BfqypP += BfqypP;
    }

    for (int RFrlhbXpFLNMq = 473962447; RFrlhbXpFLNMq > 0; RFrlhbXpFLNMq--) {
        CGbuDCAdC = CGbuDCAdC;
        BfqypP *= BfqypP;
        CGbuDCAdC = CGbuDCAdC;
    }

    return false;
}

bool fWRxMtvpdi::PmWXsoGEeCxFwx(bool BGCNLluDZWH, string tTvHAAPLeyLsOceA, string uDDCstYAlvVFC, int sGNWVBHUlnQsCA, string cFNygYuT)
{
    double APLIrjDtpAPu = 12921.766795087948;
    bool tTjnlJIHgLVFNCVu = true;

    for (int DltCPsdMrv = 643396927; DltCPsdMrv > 0; DltCPsdMrv--) {
        continue;
    }

    for (int hNDJtD = 703028320; hNDJtD > 0; hNDJtD--) {
        continue;
    }

    return tTjnlJIHgLVFNCVu;
}

fWRxMtvpdi::fWRxMtvpdi()
{
    this->mYZERhX(true, true);
    this->ismlAzjzDDQjyPdl(string("KZPkERWbUcpdxKMywjzbdrwdMgDzSeVtOquAidVHknEVDNApNVsGyPGziQalPLUOrKfJRHGTlwaLwQoUxVagTUureEWxEKKCIsPGZiGgggBkDFtUi"), string("NSkCQvvFrhj"), false, false, -834304396);
    this->ROOvBtWua(false, string("FHiKSrMPcKLkYbXQKHaCLlhTFXvGSRgJzeqUxVjSQGqnJHEJnyrKpVNfnFWyByfFOCIPxgKlpGE"), -561352.4606654223);
    this->qDJigrWaYCTE(string("sHxJCpmmJNNacKoriYUWMPHUPBiNSqUaofNKmONpKJvuytYcnzOYpxaBmPTBHrqIWwXRAgzquQibMFWjndw"), 897108.5204852505);
    this->NGpWX(false, string("uQqgSKvnaZsXcwXqyCWtFNRnJmUrtalIPeBagUFc"), 242130761);
    this->bzifyDCjYM(true);
    this->ZoprrKRHsondFyiF(string("StGautZBAdjrKOxNXXgeNroOXoUFxjfWIupXACBqbHbKOqenujAFVlBDIcvCmkPubozULkfeWinKQYqUvnrEbegMPLATzTalmqiGFbkKKaKTRiatzlLLTMzqgfHeaNtDWaALIlwagoN"));
    this->gaatcHOMjHFLT(string("RYpmXIgxZuSlREqdAXAvtBneHijVqQvKKLFwWLnjCOkEsPVaUSzikIFDvQxbNmlqQmIrQBjEBqhKjbxTNqEDpIWiEOXSoVFKAmPQWKHaAlPgUKuXorakBMfYogv"));
    this->vfJGEceScJWfgWYd(true, string("wkmdEJYhYYeTJgHEyHNLbMRaiibmEvhPqslACKdsoXOqQhXpAEPOCpw"), 1518442350, 701868.748703377);
    this->yJqLDJSMBvsf(283814833, 1469440000);
    this->jBIWEYcMTinTOJp();
    this->xquQruviP(string("UpVdYL"));
    this->PmWXsoGEeCxFwx(false, string("dpzrcezKHdLT"), string("gaAuLKlemVumfHFgRcDsEGLyXAVjQoockiggLnuqyuNCwYsMXpLmeiOsaiyVuqhrWRsxubEWOVCHDjzAiFUUdqvmZjddVXJmykAnHcbtcJyDYQAcplmHNoxVFTuIbbPSlmVEFeOrsleBqXHRvZLhcoqsOSHNDTSONCXWAfgbiEZYnIucuZdUDLemqcrBPKcPDWFoNpmhXREYHReB"), 602709838, string("bieOUVKxNAsgQDCenPWbOtmaVdHveTlgUGkQBEoovrqKIRArzqMLvdUYeiRYiYeaUljCiLRjneWDlxgoNgGcZRgfXasqdTaxLzGUzPLzEYOuKopzxWVlmCIdcmDkvHZuitKIJRqDOgDbKyylGcAOmMfJuFICpCPRsuREPsAvgRXrLCRDUozVIjnNuSIinBGqBskQxYuUMOhKKVjSaYjyBjmWiiGxgYaTYXAvs"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NSGCSPGhwb
{
public:
    double KmQOaqUBiWe;
    double YUYlNepptfMy;

    NSGCSPGhwb();
    int ZiWRjWi(int UFziwu, double mRMogoPKbPRdL, double dVPLBZNlqr);
    double nkILXTiWB();
    double SkMErigmYydfpp(int fiFDzDHaoLFD, bool bSYnTVFVptzFeH, int yzwDEC);
    double SsWkipJyGWbqf(int zsCsyigDuiVscUZw, int BhIkYDUoHgp, int mejtHHHsDUbawAPh, double TsvjVXb);
    int cmQVSWNWsIz(string McFtwGSilfDDuICu);
    void KXUoEpTi(bool nlwZInfHyntlDDCU, double VGzBrTQVH, bool cNAhuP, string nnfOXCptyJFI, double ibKpwGxzOps);
    void BrBbmONGScrIojpA();
    double JSvfiS(int zFfTqrvZLgYW, bool CvyrLheUk, int NmsDqQLrND);
protected:
    string PedEZwikFhIBL;

    void OlQtq(int JdHDTEe);
    void sEqwA(int SCstUfol, double JEIVNvItmez, double MtkvnlWSSc, double OPyuwsiSJlDD);
private:
    bool IDojombCVGSs;

    bool iMVEhtU(bool npNTleWdQnlNXz);
};

int NSGCSPGhwb::ZiWRjWi(int UFziwu, double mRMogoPKbPRdL, double dVPLBZNlqr)
{
    double UTviqCqzkabA = 391024.7593136856;
    bool yVCsdRt = true;
    double XwJvTEz = 831764.0432319893;
    double kueCO = -789868.3415221666;
    string bjGgsmIKbpqn = string("HcIZmskJmburussTDSnLxxXyEWrNoJmCCSdXKhrCYbWqQBIJgxQwLkWMLJvbGusZlklLsjpnwfwR");
    double sMkFe = -1001177.6872131558;
    double ePwXUhwhzRoglZ = -856135.9404527833;
    int DkHQCG = -1171276345;
    bool msEMzRBJG = false;
    bool rVKNa = true;

    for (int EVJQQYyCzEaQaFZ = 1722148097; EVJQQYyCzEaQaFZ > 0; EVJQQYyCzEaQaFZ--) {
        kueCO += ePwXUhwhzRoglZ;
        kueCO /= dVPLBZNlqr;
        mRMogoPKbPRdL += mRMogoPKbPRdL;
        UTviqCqzkabA -= UTviqCqzkabA;
    }

    return DkHQCG;
}

double NSGCSPGhwb::nkILXTiWB()
{
    int rNOwEabAklJjz = 1979327218;
    int XtsOmajVyP = 2087480213;
    double DOIPCAeWf = 274233.3589988153;
    double XxVtwtgMnBYLFvf = 250546.87525383293;
    bool usPtTctHyOKy = false;
    double GPAOAjsFv = 118345.72379366765;
    bool wdGMgkaA = true;
    double yIEiurxoEj = -76015.68691303578;

    for (int fMTWakjILjH = 1250868649; fMTWakjILjH > 0; fMTWakjILjH--) {
        DOIPCAeWf -= XxVtwtgMnBYLFvf;
        usPtTctHyOKy = ! usPtTctHyOKy;
        GPAOAjsFv *= DOIPCAeWf;
    }

    for (int hqNaPGtpAQ = 1389161488; hqNaPGtpAQ > 0; hqNaPGtpAQ--) {
        wdGMgkaA = usPtTctHyOKy;
        rNOwEabAklJjz = rNOwEabAklJjz;
        DOIPCAeWf /= GPAOAjsFv;
    }

    if (yIEiurxoEj != 274233.3589988153) {
        for (int eFKhSc = 1578163517; eFKhSc > 0; eFKhSc--) {
            continue;
        }
    }

    return yIEiurxoEj;
}

double NSGCSPGhwb::SkMErigmYydfpp(int fiFDzDHaoLFD, bool bSYnTVFVptzFeH, int yzwDEC)
{
    int BelBdZmGudqJQ = -989760065;

    if (BelBdZmGudqJQ > -459819783) {
        for (int PXVLPLZYSSRkn = 1869080360; PXVLPLZYSSRkn > 0; PXVLPLZYSSRkn--) {
            fiFDzDHaoLFD += BelBdZmGudqJQ;
            BelBdZmGudqJQ += fiFDzDHaoLFD;
            yzwDEC *= BelBdZmGudqJQ;
            yzwDEC -= yzwDEC;
        }
    }

    return -95985.89057536029;
}

double NSGCSPGhwb::SsWkipJyGWbqf(int zsCsyigDuiVscUZw, int BhIkYDUoHgp, int mejtHHHsDUbawAPh, double TsvjVXb)
{
    int LkaFnOhQEhve = 719170229;

    for (int RYjPwlisHx = 1988465325; RYjPwlisHx > 0; RYjPwlisHx--) {
        continue;
    }

    for (int gVGOxWXsxUvmlHiw = 1167495437; gVGOxWXsxUvmlHiw > 0; gVGOxWXsxUvmlHiw--) {
        BhIkYDUoHgp -= mejtHHHsDUbawAPh;
        BhIkYDUoHgp = BhIkYDUoHgp;
    }

    return TsvjVXb;
}

int NSGCSPGhwb::cmQVSWNWsIz(string McFtwGSilfDDuICu)
{
    bool yOLyNHZmaMis = true;
    bool QPvoQQwfgsXUp = false;

    if (QPvoQQwfgsXUp == false) {
        for (int earGOOChldiPPCz = 1163920132; earGOOChldiPPCz > 0; earGOOChldiPPCz--) {
            QPvoQQwfgsXUp = ! yOLyNHZmaMis;
            McFtwGSilfDDuICu += McFtwGSilfDDuICu;
        }
    }

    if (yOLyNHZmaMis != true) {
        for (int yomZQgKrj = 2122116494; yomZQgKrj > 0; yomZQgKrj--) {
            yOLyNHZmaMis = ! QPvoQQwfgsXUp;
            yOLyNHZmaMis = yOLyNHZmaMis;
            yOLyNHZmaMis = ! QPvoQQwfgsXUp;
            QPvoQQwfgsXUp = QPvoQQwfgsXUp;
        }
    }

    for (int ORfrSHLqHY = 33145664; ORfrSHLqHY > 0; ORfrSHLqHY--) {
        McFtwGSilfDDuICu = McFtwGSilfDDuICu;
    }

    for (int HPjogjjwgVKASwql = 1032169225; HPjogjjwgVKASwql > 0; HPjogjjwgVKASwql--) {
        McFtwGSilfDDuICu += McFtwGSilfDDuICu;
    }

    return 756192513;
}

void NSGCSPGhwb::KXUoEpTi(bool nlwZInfHyntlDDCU, double VGzBrTQVH, bool cNAhuP, string nnfOXCptyJFI, double ibKpwGxzOps)
{
    bool fRnEo = false;
    double POjRnX = -454639.82359523565;
    int hXtPHr = -443145184;
    bool QXRWpmzY = true;
    bool FsMYzoXsGBFiys = false;
    double HPEoEp = 314084.3671848541;
    int ucsrWBxVJG = -1265833391;
    int ZhbYdCtWL = 1549825173;
    bool dMOBj = true;
    bool tmfjpi = true;

    for (int FllxyEMMrZVL = 938660120; FllxyEMMrZVL > 0; FllxyEMMrZVL--) {
        dMOBj = QXRWpmzY;
        dMOBj = tmfjpi;
        hXtPHr *= ZhbYdCtWL;
    }

    for (int XEueAPzaJS = 1778295551; XEueAPzaJS > 0; XEueAPzaJS--) {
        fRnEo = dMOBj;
    }

    if (QXRWpmzY == true) {
        for (int QIAURYQoa = 1279844020; QIAURYQoa > 0; QIAURYQoa--) {
            nlwZInfHyntlDDCU = QXRWpmzY;
        }
    }
}

void NSGCSPGhwb::BrBbmONGScrIojpA()
{
    bool HVuCZXVUqZLXRh = true;
    double LINXGRqSynAwRCy = 441569.85242235585;

    for (int lLJEPeJuc = 419821329; lLJEPeJuc > 0; lLJEPeJuc--) {
        LINXGRqSynAwRCy /= LINXGRqSynAwRCy;
    }

    if (HVuCZXVUqZLXRh != true) {
        for (int XDrWiuZL = 456281884; XDrWiuZL > 0; XDrWiuZL--) {
            LINXGRqSynAwRCy -= LINXGRqSynAwRCy;
        }
    }

    for (int CWVdZGSUMgAROMbd = 146446026; CWVdZGSUMgAROMbd > 0; CWVdZGSUMgAROMbd--) {
        HVuCZXVUqZLXRh = ! HVuCZXVUqZLXRh;
        HVuCZXVUqZLXRh = HVuCZXVUqZLXRh;
    }

    for (int GyoOyZX = 1498264545; GyoOyZX > 0; GyoOyZX--) {
        LINXGRqSynAwRCy -= LINXGRqSynAwRCy;
        HVuCZXVUqZLXRh = ! HVuCZXVUqZLXRh;
        LINXGRqSynAwRCy *= LINXGRqSynAwRCy;
        LINXGRqSynAwRCy -= LINXGRqSynAwRCy;
    }

    for (int ayOSyBODXaUqvjK = 1093451827; ayOSyBODXaUqvjK > 0; ayOSyBODXaUqvjK--) {
        LINXGRqSynAwRCy -= LINXGRqSynAwRCy;
        LINXGRqSynAwRCy = LINXGRqSynAwRCy;
    }

    for (int MbCxYL = 753845899; MbCxYL > 0; MbCxYL--) {
        HVuCZXVUqZLXRh = HVuCZXVUqZLXRh;
    }
}

double NSGCSPGhwb::JSvfiS(int zFfTqrvZLgYW, bool CvyrLheUk, int NmsDqQLrND)
{
    double WmBlcw = 1012310.7457948889;
    double DTxGZfRYJZTZ = 668462.2216128655;
    bool DVgglyzyNC = false;
    string imkgvppvVmV = string("JSKRzfgcgERzciblYrKIwGYXTqKjJoLOWPhOYFzAbYZglRncZgnFddGHQowvhegefIDrkoawCsTRslJBJkVUKspurzJsHaENiPmFXfDCwKUXWzCASVoYNEbIyAzCltuqDSYdkxodLyZltxdXSoNUnRghbqglzDZtjyjWZOYDZjJH");
    string SNOffRkNq = string("ugePGSTzZiRbafvvvbkjYR");
    bool CJGoOyusxSmeK = false;

    if (CJGoOyusxSmeK == false) {
        for (int oCTaHaq = 1393172856; oCTaHaq > 0; oCTaHaq--) {
            continue;
        }
    }

    for (int uchOq = 1812918315; uchOq > 0; uchOq--) {
        continue;
    }

    for (int VJLOGqbC = 1854887595; VJLOGqbC > 0; VJLOGqbC--) {
        CvyrLheUk = ! DVgglyzyNC;
        CJGoOyusxSmeK = DVgglyzyNC;
    }

    return DTxGZfRYJZTZ;
}

void NSGCSPGhwb::OlQtq(int JdHDTEe)
{
    int TKtzeEgxfUTLy = 438123929;
    double vgdriT = -997543.0694144871;
    double NmkCahPS = -469740.46432138415;
    double TkXnQYaxB = 828022.3549590934;
    int SvWinRWinzK = -533748770;
    int kCNduZXanrFanFi = 2041041807;
    int LuyeibFeyzGpylig = -1657663405;
    string oHiPgWCN = string("QKdYyMibxQnfxMdhsymgIlZAfHBwZdvDrNIGAUPZazWTRGNTpdnFWYbIktUppSVXXbgVHugEQRMWkGULeWWxfNFPFLTyp");
    int iJYLevnJpowrHwe = 1981279442;
}

void NSGCSPGhwb::sEqwA(int SCstUfol, double JEIVNvItmez, double MtkvnlWSSc, double OPyuwsiSJlDD)
{
    bool FMmRvboMhlryplT = true;
    bool HLbZxBRaL = false;
    double rNphD = -936929.6700272372;
    int dkcyr = -1801077662;
    bool akKUm = false;
    int sRVJdBEUc = -1638756318;
    string bEmukFPDef = string("kPuqeqaXYsaBlbiTDC");
    double TUKPLqLiSENkNwQp = 480889.2932082412;
    int RoQmaNXqplF = 55445850;
    bool kpdsuIqEmPbEGKpm = true;

    for (int NnYUngRnci = 1544277554; NnYUngRnci > 0; NnYUngRnci--) {
        JEIVNvItmez = OPyuwsiSJlDD;
    }

    for (int xFhgfwN = 1959968786; xFhgfwN > 0; xFhgfwN--) {
        RoQmaNXqplF *= SCstUfol;
        JEIVNvItmez *= TUKPLqLiSENkNwQp;
        TUKPLqLiSENkNwQp /= MtkvnlWSSc;
        FMmRvboMhlryplT = ! HLbZxBRaL;
        OPyuwsiSJlDD = TUKPLqLiSENkNwQp;
    }

    for (int JkFrOLPQmfVgN = 266347359; JkFrOLPQmfVgN > 0; JkFrOLPQmfVgN--) {
        HLbZxBRaL = FMmRvboMhlryplT;
        FMmRvboMhlryplT = FMmRvboMhlryplT;
    }
}

bool NSGCSPGhwb::iMVEhtU(bool npNTleWdQnlNXz)
{
    int jHgUbVWKRXAa = -1558076012;
    bool yskamKtnfUB = true;
    int bCRTyrpDXHb = -872745005;

    for (int QazdJNS = 1777097824; QazdJNS > 0; QazdJNS--) {
        jHgUbVWKRXAa -= jHgUbVWKRXAa;
    }

    for (int ndgUPIjmGALyaxy = 1574254044; ndgUPIjmGALyaxy > 0; ndgUPIjmGALyaxy--) {
        npNTleWdQnlNXz = ! yskamKtnfUB;
        jHgUbVWKRXAa -= bCRTyrpDXHb;
    }

    if (jHgUbVWKRXAa < -1558076012) {
        for (int XDzTntzcaCQ = 628475190; XDzTntzcaCQ > 0; XDzTntzcaCQ--) {
            jHgUbVWKRXAa -= jHgUbVWKRXAa;
            bCRTyrpDXHb = bCRTyrpDXHb;
            npNTleWdQnlNXz = ! npNTleWdQnlNXz;
            npNTleWdQnlNXz = npNTleWdQnlNXz;
            yskamKtnfUB = ! npNTleWdQnlNXz;
            bCRTyrpDXHb += bCRTyrpDXHb;
        }
    }

    for (int GfuASJ = 1414473323; GfuASJ > 0; GfuASJ--) {
        bCRTyrpDXHb -= jHgUbVWKRXAa;
        yskamKtnfUB = npNTleWdQnlNXz;
    }

    for (int BreAWqWBVcwYKp = 1317399050; BreAWqWBVcwYKp > 0; BreAWqWBVcwYKp--) {
        yskamKtnfUB = npNTleWdQnlNXz;
        bCRTyrpDXHb = bCRTyrpDXHb;
        npNTleWdQnlNXz = yskamKtnfUB;
        yskamKtnfUB = ! yskamKtnfUB;
        jHgUbVWKRXAa *= jHgUbVWKRXAa;
    }

    if (bCRTyrpDXHb < -1558076012) {
        for (int eqpnKCGoVQFqpKJV = 1556464467; eqpnKCGoVQFqpKJV > 0; eqpnKCGoVQFqpKJV--) {
            yskamKtnfUB = ! yskamKtnfUB;
            yskamKtnfUB = ! npNTleWdQnlNXz;
            bCRTyrpDXHb = bCRTyrpDXHb;
            yskamKtnfUB = npNTleWdQnlNXz;
            jHgUbVWKRXAa -= jHgUbVWKRXAa;
            npNTleWdQnlNXz = npNTleWdQnlNXz;
            bCRTyrpDXHb = jHgUbVWKRXAa;
        }
    }

    return yskamKtnfUB;
}

NSGCSPGhwb::NSGCSPGhwb()
{
    this->ZiWRjWi(695492986, 236776.20798394026, 78373.67566710874);
    this->nkILXTiWB();
    this->SkMErigmYydfpp(900479846, true, -459819783);
    this->SsWkipJyGWbqf(370811353, -938339097, 1037895766, 751830.480123308);
    this->cmQVSWNWsIz(string("zpJcTaBttZRRkVPpHOyOluWrZSjSfFLiqSGDjGvEBlZDbvfnJeHAsLMsAEQRwGelAkAOHMIdTwUyRtLuHTQOdOYdzXhHhKziwlzStWKbdRcPHuvrHUUbxUhKxUTArVGGxyuoGYvnfWcPAEzzZHUxljwfNqMMQRcTAEMWydhCjMUTHVUBVWlLZFFlToopHQsnOANOHzVYyFcYoWPtVQNchvuWpxaizDZFnWvDMW"));
    this->KXUoEpTi(true, -143435.88668917518, false, string("prqBVPcLQCufexsLw"), -116642.45894235396);
    this->BrBbmONGScrIojpA();
    this->JSvfiS(1721289449, true, 1862130976);
    this->OlQtq(352825892);
    this->sEqwA(-994257812, -54273.1976290706, -922266.99262771, -943478.0123194888);
    this->iMVEhtU(true);
}
