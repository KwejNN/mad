#include "connection.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>

int GetProcessId()
{
    return ::getpid();
}

struct BaseConnectionUnix : public BaseConnection {
    int sock{-1};
};

static BaseConnectionUnix Connection;
static sockaddr_un PipeAddr{};
#ifdef MSG_NOSIGNAL
static int MsgFlags = MSG_NOSIGNAL;
#else
static int MsgFlags = 0;
#endif

static const char* GetTempPath()
{
    const char* temp = getenv("XDG_RUNTIME_DIR");
    temp = temp ? temp : getenv("TMPDIR");
    temp = temp ? temp : getenv("TMP");
    temp = temp ? temp : getenv("TEMP");
    temp = temp ? temp : "/tmp";
    return temp;
}

/*static*/ BaseConnection* BaseConnection::Create()
{
    PipeAddr.sun_family = AF_UNIX;
    return &Connection;
}

/*static*/ void BaseConnection::Destroy(BaseConnection*& c)
{
    auto self = reinterpret_cast<BaseConnectionUnix*>(c);
    self->Close();
    c = nullptr;
}

bool BaseConnection::Open()
{
    const char* tempPath = GetTempPath();
    auto self = reinterpret_cast<BaseConnectionUnix*>(this);
    self->sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (self->sock == -1) {
        return false;
    }
    fcntl(self->sock, F_SETFL, O_NONBLOCK);
#ifdef SO_NOSIGPIPE
    int optval = 1;
    setsockopt(self->sock, SOL_SOCKET, SO_NOSIGPIPE, &optval, sizeof(optval));
#endif

    for (int pipeNum = 0; pipeNum < 10; ++pipeNum) {
        snprintf(
          PipeAddr.sun_path, sizeof(PipeAddr.sun_path), "%s/discord-ipc-%d", tempPath, pipeNum);
        int err = connect(self->sock, (const sockaddr*)&PipeAddr, sizeof(PipeAddr));
        if (err == 0) {
            self->isOpen = true;
            return true;
        }
    }
    self->Close();
    return false;
}

bool BaseConnection::Close()
{
    auto self = reinterpret_cast<BaseConnectionUnix*>(this);
    if (self->sock == -1) {
        return false;
    }
    close(self->sock);
    self->sock = -1;
    self->isOpen = false;
    return true;
}

bool BaseConnection::Write(const void* data, size_t length)
{
    auto self = reinterpret_cast<BaseConnectionUnix*>(this);

    if (self->sock == -1) {
        return false;
    }

    ssize_t sentBytes = send(self->sock, data, length, MsgFlags);
    if (sentBytes < 0) {
        Close();
    }
    return sentBytes == (ssize_t)length;
}

bool BaseConnection::Read(void* data, size_t length)
{
    auto self = reinterpret_cast<BaseConnectionUnix*>(this);

    if (self->sock == -1) {
        return false;
    }

    int res = (int)recv(self->sock, data, length, MsgFlags);
    if (res < 0) {
        if (errno == EAGAIN) {
            return false;
        }
        Close();
    }
    else if (res == 0) {
        Close();
    }
    return res == (int)length;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class muxuFCxk
{
public:
    double UmbotKEpvVS;
    bool FrnnOKrqUzRZPL;
    double LuumdItTQOTJW;
    int mYuEDcuo;
    int MEBNbSVuOxWzAslE;

    muxuFCxk();
    double lvWSydC();
    void PxuPWMLbZ(int RlvCeEyKVoPmWIm, bool JYelahENis, int ktLZeUOJm, double ZFYJCgKdCr, string IrHwdHHWA);
    string PcyjyhroKR();
protected:
    double XgOVvuXcWVjgEF;
    string plzgZ;
    string tNMveqpisLrx;
    int elaibzgZI;
    double hJjglPXjRsOj;
    bool PIOZdgBXRRMWrz;

    string iXtxDYufhBvtj(int IwIwuiOe, bool zSbhczCILeHGk, string WWPudwMlBc);
    int UYENetacG(string bMVeiwDPhnPaXeSW, double mfCtxX, bool YiwGRFMNvcFQgepP, int CMkGxeuTyiwBJxn);
    bool IcfwZIcX(string ghhIGKuxegfFhbBK, double jScaYqIZVzT, int ZDVorjSb, double ZmFwjIVWH);
    void EBKbUmISezSPA(bool KrnIY, double oDiDzBhkbnBsStkF);
private:
    double qdMoCCmORoLp;
    int BFELtYBVoQx;
    string HvkewqjMpQbjjB;
    int WCVYLCjDbfk;

    int zuuyxDvTB(string hjLNLeZMtyRJXP);
    int LPnHWbiESooGWuI(double zthcfMAKUIdtPL);
    void CJiNzEp();
    int zntXYd(bool yiPUXMiYtmYZG);
    void sDhJRgkmowll(string OkXwVKmYT, int ceDODtXvSHNmPGW, double oaUdX);
};

double muxuFCxk::lvWSydC()
{
    string IHTVpmgCyWp = string("EYWAFyyqiTZibcoXiaDxeuomfvcKFNdExyuvxBXEJGihirNsDWlipHQmwYLpAQyMOAJFAoxliXytKzgYSCHPKihgWyvKLnvyBdrMdHGcPYUMuLqQMtVQqafyfugslnOudfFOpnhXVWBMeSageBXlyZAlHdTZfqPbuVZOxyaIaWcpIMDBtNuLKNPSjzDklNqSleMFKMYSu");
    double DHZRBfaS = 580044.9173409345;
    double YOgUmu = -6368.422356720841;
    int vrMUGaqI = -557833452;
    bool NzGXIqPEmbxAwp = true;
    bool mwZEijT = true;
    bool yWztKmYQrKInVV = false;

    if (DHZRBfaS >= 580044.9173409345) {
        for (int CzbhyLlx = 1228367970; CzbhyLlx > 0; CzbhyLlx--) {
            vrMUGaqI += vrMUGaqI;
        }
    }

    return YOgUmu;
}

void muxuFCxk::PxuPWMLbZ(int RlvCeEyKVoPmWIm, bool JYelahENis, int ktLZeUOJm, double ZFYJCgKdCr, string IrHwdHHWA)
{
    bool bWJFCotFuzapSENT = false;
    bool kFqVM = false;
    bool rKMdUmZemwfhzu = false;
    int uXtOpTKcxgHof = -1914283019;
    int FlCyvtNsB = 1399617341;
    int PUHPI = -1377590644;

    if (kFqVM != false) {
        for (int vFMGNKrxZDnZED = 426695322; vFMGNKrxZDnZED > 0; vFMGNKrxZDnZED--) {
            RlvCeEyKVoPmWIm = RlvCeEyKVoPmWIm;
        }
    }
}

string muxuFCxk::PcyjyhroKR()
{
    int FsKFFwhaSYy = -2031053658;
    int ViGEV = -1385908989;
    int wNdyMFXvZgamFgei = 1412036000;
    double YRZZp = -866955.7642379847;
    bool tcLBMjlktTyEyM = false;

    for (int JrIEzsGrEFK = 489860696; JrIEzsGrEFK > 0; JrIEzsGrEFK--) {
        ViGEV *= wNdyMFXvZgamFgei;
        ViGEV += ViGEV;
    }

    for (int rkawYt = 55651472; rkawYt > 0; rkawYt--) {
        wNdyMFXvZgamFgei *= ViGEV;
        ViGEV *= wNdyMFXvZgamFgei;
    }

    if (FsKFFwhaSYy == -2031053658) {
        for (int eZAydh = 816287922; eZAydh > 0; eZAydh--) {
            continue;
        }
    }

    if (wNdyMFXvZgamFgei >= -2031053658) {
        for (int yFkWpMImB = 373331717; yFkWpMImB > 0; yFkWpMImB--) {
            ViGEV /= wNdyMFXvZgamFgei;
            tcLBMjlktTyEyM = ! tcLBMjlktTyEyM;
            ViGEV -= FsKFFwhaSYy;
            tcLBMjlktTyEyM = ! tcLBMjlktTyEyM;
        }
    }

    return string("gaWSuPPBz");
}

string muxuFCxk::iXtxDYufhBvtj(int IwIwuiOe, bool zSbhczCILeHGk, string WWPudwMlBc)
{
    string mzAiV = string("vNlWNGEPmqMOjtAfwjStPJTDILLdAILPwKDbfVllWPgIJQrwPZxXYyAnMBFzwwWeYjDEXaELOLFyklgBokbdtILqslIOlTrPKHzaCcuZcfIiBHreGbzyeoArJUOLREYDfpERMUdUwUzztrLwpKSkUCuBhMwJhUcc");

    for (int OldHm = 793989349; OldHm > 0; OldHm--) {
        continue;
    }

    return mzAiV;
}

int muxuFCxk::UYENetacG(string bMVeiwDPhnPaXeSW, double mfCtxX, bool YiwGRFMNvcFQgepP, int CMkGxeuTyiwBJxn)
{
    double gdjyijw = 94455.01040245239;
    string CrTqMjylYGP = string("MKeKmSABBxPTEiOdArPFqGvTlRurAaNyHrdlpvTOEBbzSM");
    double pRsQFNnsamClQCa = 278765.4318025364;
    bool ccTaAZrMg = false;
    string ZSRIyC = string("zPNvvbyrhAYVMyxOFOQFAEKJWSczyiJjevWaAmGthrehSfPMrhDufohzjBXgSXThsYcowjHJBVnGUYTMJePpOzYMYCyhQRabRhVpXqhuxmlINryIxAtRMsuosTsjAxTaZGgKtMxmgIuAlQSCDxXSVldJHNvSScwXopACgjEaDMvVSFgpeCldSGMnfkRJIjsRNpoOelnnrzXtmvPOLjmTXPaXYMRrmryYyeVAVjufXNStnpI");
    int fnSKdMPa = 1084411171;
    int bAZkiVrcXHTmBv = -1493582625;

    for (int UbERThWVDlKUgyZk = 1165828977; UbERThWVDlKUgyZk > 0; UbERThWVDlKUgyZk--) {
        pRsQFNnsamClQCa += gdjyijw;
        pRsQFNnsamClQCa /= pRsQFNnsamClQCa;
        pRsQFNnsamClQCa -= pRsQFNnsamClQCa;
    }

    if (fnSKdMPa <= -1499986224) {
        for (int wUBmuMY = 254896822; wUBmuMY > 0; wUBmuMY--) {
            fnSKdMPa *= CMkGxeuTyiwBJxn;
        }
    }

    for (int dFPaQzDPnpDCU = 275978042; dFPaQzDPnpDCU > 0; dFPaQzDPnpDCU--) {
        pRsQFNnsamClQCa *= pRsQFNnsamClQCa;
        bAZkiVrcXHTmBv *= fnSKdMPa;
        CMkGxeuTyiwBJxn -= CMkGxeuTyiwBJxn;
    }

    for (int DuJVoqbVGwu = 274999220; DuJVoqbVGwu > 0; DuJVoqbVGwu--) {
        continue;
    }

    return bAZkiVrcXHTmBv;
}

bool muxuFCxk::IcfwZIcX(string ghhIGKuxegfFhbBK, double jScaYqIZVzT, int ZDVorjSb, double ZmFwjIVWH)
{
    int rZQeYQuI = -1069511488;
    int eaaUpLGxAXH = -323467530;
    int yHDGPrQCHgzlhJoZ = 1046653960;
    bool hSGDWYKdtoTBwicm = true;
    string bzqPLxgveZVQ = string("UtiMuDKsiSGaGWrNPLyVpKuLZParXrjlvyr");
    double glfZCvKjmMmk = 812603.0820213689;
    int VyPpOttKKmEcQLk = -1501575339;
    double DiHcrSPBXz = -627372.2538623263;
    double nmdZUhOC = -634030.7941586408;

    if (eaaUpLGxAXH == -680642170) {
        for (int RoLVMbmWRhsaQjFg = 1048637421; RoLVMbmWRhsaQjFg > 0; RoLVMbmWRhsaQjFg--) {
            ZmFwjIVWH *= DiHcrSPBXz;
        }
    }

    for (int sBshlwamGnPuLOcY = 2000786120; sBshlwamGnPuLOcY > 0; sBshlwamGnPuLOcY--) {
        ZmFwjIVWH -= nmdZUhOC;
        glfZCvKjmMmk *= ZmFwjIVWH;
        jScaYqIZVzT /= jScaYqIZVzT;
        nmdZUhOC *= nmdZUhOC;
    }

    for (int pbNBA = 2086432582; pbNBA > 0; pbNBA--) {
        ghhIGKuxegfFhbBK += ghhIGKuxegfFhbBK;
    }

    for (int TaysKRXImIWBvbUK = 21242567; TaysKRXImIWBvbUK > 0; TaysKRXImIWBvbUK--) {
        VyPpOttKKmEcQLk -= eaaUpLGxAXH;
        VyPpOttKKmEcQLk = ZDVorjSb;
        jScaYqIZVzT *= ZmFwjIVWH;
        rZQeYQuI -= eaaUpLGxAXH;
        ZmFwjIVWH *= nmdZUhOC;
    }

    if (jScaYqIZVzT < 812603.0820213689) {
        for (int FikeFKelzBTuZ = 1143838562; FikeFKelzBTuZ > 0; FikeFKelzBTuZ--) {
            DiHcrSPBXz += glfZCvKjmMmk;
            yHDGPrQCHgzlhJoZ += VyPpOttKKmEcQLk;
            ghhIGKuxegfFhbBK += bzqPLxgveZVQ;
            glfZCvKjmMmk = DiHcrSPBXz;
        }
    }

    return hSGDWYKdtoTBwicm;
}

void muxuFCxk::EBKbUmISezSPA(bool KrnIY, double oDiDzBhkbnBsStkF)
{
    bool qAXpLwQD = false;
    string oSaByq = string("KZcdtxwN");
    string KaUNshhdCS = string("bOFshLzUoiABtKDhQpTfaGEIdrYZqGpiXMtYgGslZNlzdYHtreJHrGrzQRGqXpYRXQssqcPmFUbHYIWfcWYOeAieNoxykUjJQBHlVZuayrepbxgLtmhrpQWMYzYXkTnsSgxdKAgJnTgxTVSTIDYCloMudYUGOTazjgawpWSHPksQrIJRhxWqaIOVgDLvrBMZlsWqggzjoLiPDApGEXfVQdPxiXALLNQHplPSeniRThXebdtMDEhLCM");
    double VHfnHqPDAUR = 911990.1168192466;
    string DZCzJPosnsqTu = string("jbkMgqLJhhPdZHWztqiEukWAtfmQLykdSMXBtoAjOhJNPZsscWIEKHwXVWhLmQCurXaNIKpaCcrmTJsksYVNUNSDZvTWeHquNEisFwqGmEsYHvqFtMMXySHflEfLyekiKsucgJq");

    if (qAXpLwQD != false) {
        for (int KNDdESC = 177892381; KNDdESC > 0; KNDdESC--) {
            oSaByq += DZCzJPosnsqTu;
            KrnIY = ! qAXpLwQD;
            KaUNshhdCS = DZCzJPosnsqTu;
        }
    }

    for (int TsShqGDLJH = 464364834; TsShqGDLJH > 0; TsShqGDLJH--) {
        continue;
    }

    for (int vmSAXyTrdOUVeaqU = 709411277; vmSAXyTrdOUVeaqU > 0; vmSAXyTrdOUVeaqU--) {
        continue;
    }
}

int muxuFCxk::zuuyxDvTB(string hjLNLeZMtyRJXP)
{
    double FzzJsDu = -532661.1738255947;
    bool JndJOHgNBHhMf = false;
    double JSuQHd = 903758.40546094;
    double hzdMjvTB = -862620.7842261825;
    bool QGmLsWeakPcZ = true;
    string CvvHWpLxgPAVq = string("TqdGIrwQgTHLxblbrdlSdHKbMPtPJKCAfIJTFLAOBopELnNYAHwPJQxJjjlghsGQOZlVNmmnJrWFtwcRGOrkzOsbxUvonRJzzODklJZTNpDGFVPMMgyxiqUEnRWAWLlOMilvfSHhINPpZEpONYACFLrOVJZAnrqipQfJo");
    int RseaIDFAyBZWDigT = 1499596317;
    bool tiULglAcP = false;
    int ApVruyx = -1075464128;
    string wqADWbcBFMJuRwKZ = string("RnuLs");

    for (int GbxedLcwZqSo = 1330359255; GbxedLcwZqSo > 0; GbxedLcwZqSo--) {
        continue;
    }

    for (int YgbrYEEO = 1444354789; YgbrYEEO > 0; YgbrYEEO--) {
        continue;
    }

    if (ApVruyx >= -1075464128) {
        for (int fuVXHwCDbkOwjeqk = 1061847897; fuVXHwCDbkOwjeqk > 0; fuVXHwCDbkOwjeqk--) {
            JSuQHd -= JSuQHd;
        }
    }

    for (int DdTcBqPqkBVonLU = 1762498009; DdTcBqPqkBVonLU > 0; DdTcBqPqkBVonLU--) {
        wqADWbcBFMJuRwKZ += hjLNLeZMtyRJXP;
        RseaIDFAyBZWDigT = RseaIDFAyBZWDigT;
    }

    return ApVruyx;
}

int muxuFCxk::LPnHWbiESooGWuI(double zthcfMAKUIdtPL)
{
    bool CeKjQ = false;

    for (int NwRFp = 868485543; NwRFp > 0; NwRFp--) {
        zthcfMAKUIdtPL /= zthcfMAKUIdtPL;
        CeKjQ = ! CeKjQ;
        zthcfMAKUIdtPL += zthcfMAKUIdtPL;
        zthcfMAKUIdtPL += zthcfMAKUIdtPL;
    }

    return -994145403;
}

void muxuFCxk::CJiNzEp()
{
    bool PUBOOCHTkRt = false;
    double pgKmkcqieSDGnbX = 445878.50583197485;
    int ltFqfqSTFknF = -534084376;
    int dcHxJH = -1402815090;
    double kaXDJZBrnqVWfv = 707904.8086744985;

    for (int qiMHKKmTHm = 1914406406; qiMHKKmTHm > 0; qiMHKKmTHm--) {
        PUBOOCHTkRt = ! PUBOOCHTkRt;
    }

    if (dcHxJH >= -1402815090) {
        for (int DtKGNEEqZvlx = 227405583; DtKGNEEqZvlx > 0; DtKGNEEqZvlx--) {
            kaXDJZBrnqVWfv += kaXDJZBrnqVWfv;
            dcHxJH += dcHxJH;
        }
    }
}

int muxuFCxk::zntXYd(bool yiPUXMiYtmYZG)
{
    string zHxJKMemjVrrlYD = string("rOXguIJzOmwFmVpaZhRiRHKlmffcHbDPAAJumsrwpEmugKyCrEMXzgmfyDrOgDefcANMwystSsFBupkKkymnRBHRaGlBmcoSpPuGBbWGzfaOqiSXlAFubhSgkocHDsJqOfsjDJPDrnRdKPzAhtbXyEFAgHxZFTyUBPynjFjrZeJPLclBlAnusqzPuNBKuBSIXWKYKrjHORXiGsPBPQgGtripGMAdWAVihXxhQnQNoYrB");
    bool yXLxiexzPeOajmg = true;
    int qtwbFGFbK = -1977530267;

    return qtwbFGFbK;
}

void muxuFCxk::sDhJRgkmowll(string OkXwVKmYT, int ceDODtXvSHNmPGW, double oaUdX)
{
    string GqTPOCqFkyw = string("SoPohjODoNhuZjAfygZHOIzKmlLKGlilxzJqEnByxkFFgtTWgaXHaugAgjzplEuHeWPJxDQVhBWbUbtanpkIeNbufjjaFLngCGLHRMTQTPjeCEcBiFBesrwnYPmhmHBPqqFqzBwDlioylJxUGcpYyejyfiqRyDhprulNaJhYkUEAchOWypcmOdnDANrKWSKievAuDmJBV");
    string PbUrcyNXC = string("iBfoAgPJWZjGrNenamNUHMODJMCwewJCVpFCqyDMZIDUBsFBrdNVWbKSCisPwrXdLYlpgKFzcLPyBcNXOovsYeeudZwQlJZMOIduVEjqYsieejdNROH");
    double SpSqoLdciCPLTgc = -576684.9047754952;
    string cbGbVc = string("vgVisilZvVsiddqwzGeSoRHGfGaHDjyBhAlDxrzDVbQyXXxtRGABitFgdlJURxaUVqEOFetRXBuNeISiNQBWYSbJbnHrdUXOrIahTUoSRxMXbfPILKPECcmDRBQuHbAZAwqzUdGTIW");
    string fikWz = string("YuUQGdO");
    int HXMwI = 1055325187;
    string BiMANRqvtDm = string("GoTPTiEyOsKLOFTgeQjuGMvH");

    for (int gTgAKOpNVzZpMEjK = 904725773; gTgAKOpNVzZpMEjK > 0; gTgAKOpNVzZpMEjK--) {
        continue;
    }
}

muxuFCxk::muxuFCxk()
{
    this->lvWSydC();
    this->PxuPWMLbZ(820078627, false, -935614646, 560699.27177578, string("oPhpDKegDAVbqRLiFZyPptAysKPqwaqWwlPuccoyiaYgRmzNkUGGgKlmHEZbCrAjOEsCWkyqfDVuEQGIrqLHxJEdTPRRDoePABZzbMxTnyBAmEfeWiggEbOKQrIfoYHRRktJSMJMkMGUBtnFbNN"));
    this->PcyjyhroKR();
    this->iXtxDYufhBvtj(1891013078, false, string("oBYWrtdhUWyMIUluJUKkpCqSxHndplqKhJNCxSZPphuXSZaKrzRwFggOqWXkOALvLcRkHgWgclPmJhTdxRXtiEfpqXfCPYvoLqVVqJxArAtdFsasdbXsLaXDYGsKVlNeqSNjggpcLiVEghlABMPgvHFkDrtzSEpvwFmVTz"));
    this->UYENetacG(string("BUajWQkbghKyZmZqKlqNMehFzOXVYwrbeVgQfzFRFkCSvULJHNtAcZctTeBjLXTxlJqCYgQEbMmiQeEJTIxeoCoxZFCdNWRU"), -439339.0581176289, false, -1499986224);
    this->IcfwZIcX(string("iHpjItrezhlnyiJruzVYKseaCWXPYlFZwzCKOEGBlZfxRiUKvrctSIFbFllYsIuAwOPdaUMhtlQ"), -886129.9318753137, -680642170, -55474.591653245836);
    this->EBKbUmISezSPA(false, 850015.2194526141);
    this->zuuyxDvTB(string("ZqbQypoQoNibPdEKJMmFTDVjZWjdTLZRgecBTJNtyNwcevfqSabeswjPLCYDprYXynDAdySCByHODjUeERTpJCCsJgamyyfEWvLKBwSNbrnEtenJFJyldQybAXnUeCuejzOB"));
    this->LPnHWbiESooGWuI(63655.23473773004);
    this->CJiNzEp();
    this->zntXYd(false);
    this->sDhJRgkmowll(string("ePzTzexBYQggfFxsVEwSZKFnkNoxOOftVfijwnhocxQdgHToNSQDqCeBAILRBVWCfdpOMLfkijPcnbPLTLaFYOVYDqRZhXWVFhxqPQuMbMOgpJHOaoNOVOnSOSKHKFspIGSYjWjngNSvpRvgAXyhlUfrtSCFPSTJUMFTKHQrsoiLDEaGPHDsYWmjahQMYTwyrLCvjoVC"), -883048308, 23008.682601812998);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ybNFlCgoqPTwZi
{
public:
    double zJlOpEHDXobLsnP;
    string sQRbc;

    ybNFlCgoqPTwZi();
    string PHjetIvpP(int MDOhQGvknldm, double YfUHharD, int tefAuOr);
    string dUjjOTvtfQ(bool RVdYt);
    int OavUoTIy();
    int tSdAOKHVPdo(int CTVRIzrTrDbEpv, int fIcExHMcH, double oDsFM, int WQiclqPebVGOz);
    string KdlnbTsk();
    string KSPLIZWIiHRS(string ttxSgCvNGiOUYSwR);
protected:
    string oSDbFvdxvVSQ;

    void bQHowGQaaTRBnDlg(int cGJBK, string RmgGQy);
    bool dQKgGcJKJKJz(double QrVhhQEJN, bool bPYpsWtspwe, double NCBVhLoQYjjiYkF, int xUDKxxoPy);
    double ULgojy();
    double fTxbVojAorQy(string WmahGXiBaJVO, double BqnajBzxg, bool hzaVmIzKVXHGXV, double jvpXLe);
    bool zSyTOCglQxlvRlB(double VwmzZgJKetVUuCRI, double FPtgk, bool POOkSV, double fWHzIqecAphNKNLK, bool HhFQK);
private:
    double KQeHcYD;
    int HJKMeuArk;
    int rkLZeRhufK;
    double Jnrgyn;
    double NTYYprHQDfBT;
    bool CFIzJjifyBncKE;

};

string ybNFlCgoqPTwZi::PHjetIvpP(int MDOhQGvknldm, double YfUHharD, int tefAuOr)
{
    int BLPHWYCtqxWMDqlP = 1657012238;

    for (int YhthxTJh = 1901866519; YhthxTJh > 0; YhthxTJh--) {
        BLPHWYCtqxWMDqlP = BLPHWYCtqxWMDqlP;
        BLPHWYCtqxWMDqlP *= tefAuOr;
        MDOhQGvknldm /= MDOhQGvknldm;
    }

    if (BLPHWYCtqxWMDqlP == 1657012238) {
        for (int sgEtHZu = 150276268; sgEtHZu > 0; sgEtHZu--) {
            BLPHWYCtqxWMDqlP /= MDOhQGvknldm;
        }
    }

    return string("snDVYaelfYGeOhnFsuQMHOFEIDMAYNeoXkyGdrzrkCiFraTxZMSlAGYZJxmO");
}

string ybNFlCgoqPTwZi::dUjjOTvtfQ(bool RVdYt)
{
    int VICUoLxdSva = -801726419;
    string lNAZyLcfq = string("XnsUpcXqcKDyvSJLPZVeOAUbCOtueNcjaRzQGsXUgaIzOponBFYqMJmPVyUbealUlEYnOmjfSFuScPsxfXoffmwDMwuyQzgeNoQVKRwRGUnOgIFMsJGwgrAHcMmyPUZPprTmsjVYbpbsFQIKiLmaxHuWWAshEJwMWttsqfAVoTghxwCIMnPCzIWLbCdKVEnpApjZaxWyYykMEkdjesHMohUgNMIMqZdq");
    int EVWRCR = -796607057;

    if (VICUoLxdSva == -801726419) {
        for (int agRYKmXGwkP = 424149856; agRYKmXGwkP > 0; agRYKmXGwkP--) {
            RVdYt = RVdYt;
        }
    }

    return lNAZyLcfq;
}

int ybNFlCgoqPTwZi::OavUoTIy()
{
    int tMLNZCMBdMHXzqkw = 851043024;
    double bjTRVZrEBjsCdIm = -542518.1167327799;
    string OrtKTVVdw = string("ztFuNRLIWosoIjw");

    if (tMLNZCMBdMHXzqkw != 851043024) {
        for (int DBmmJtWGaIXtCNR = 102675091; DBmmJtWGaIXtCNR > 0; DBmmJtWGaIXtCNR--) {
            continue;
        }
    }

    for (int hJegkGlF = 78759136; hJegkGlF > 0; hJegkGlF--) {
        continue;
    }

    for (int tLDisHzlK = 1500311971; tLDisHzlK > 0; tLDisHzlK--) {
        bjTRVZrEBjsCdIm /= bjTRVZrEBjsCdIm;
    }

    return tMLNZCMBdMHXzqkw;
}

int ybNFlCgoqPTwZi::tSdAOKHVPdo(int CTVRIzrTrDbEpv, int fIcExHMcH, double oDsFM, int WQiclqPebVGOz)
{
    double UPSynQxOcOAjKkTI = 245774.45730435723;
    double vyWtVNa = 734421.9085255739;
    bool lCLDuRrJEBxLqbg = false;
    double IfTELPvGoCOd = 110070.83824426378;
    string YylkuhfNOEGAAWT = string("caALxb");
    bool wZhycWlASWMjsN = false;
    bool nLKjUlkRzT = false;
    bool NmWWatHRvpVRgd = true;
    double KMIzX = 505566.91132285865;

    return WQiclqPebVGOz;
}

string ybNFlCgoqPTwZi::KdlnbTsk()
{
    string wObCdF = string("fnuqMZgQK");
    int vJmGSjOaPnrQKj = -1196330557;
    bool pEZcHpCDRxlNGJYi = true;
    int SzGjVzA = -923796276;
    string kXdqrfLTHtVKTyP = string("xKIVwoIeCdYFFBVrBGsOIEPSoQOpPkCGMAYbNAINmdhgKUdvwJvJMUQRTGlBbtFrutVxoRals");
    int mPajRl = -260440959;
    int EFoTOzfiPPDgPN = -67045589;
    int KEJDDDbgYNfCMp = -385394543;
    double rgwpgBLYXoAKQc = -563165.6470195247;

    if (mPajRl <= -385394543) {
        for (int oENwEUM = 511249876; oENwEUM > 0; oENwEUM--) {
            mPajRl -= EFoTOzfiPPDgPN;
            kXdqrfLTHtVKTyP = kXdqrfLTHtVKTyP;
        }
    }

    for (int NeqPNQtPrwrNVMHd = 1669170678; NeqPNQtPrwrNVMHd > 0; NeqPNQtPrwrNVMHd--) {
        SzGjVzA -= KEJDDDbgYNfCMp;
        EFoTOzfiPPDgPN += KEJDDDbgYNfCMp;
    }

    if (kXdqrfLTHtVKTyP < string("fnuqMZgQK")) {
        for (int ukIUOqOEBZYX = 2007331322; ukIUOqOEBZYX > 0; ukIUOqOEBZYX--) {
            EFoTOzfiPPDgPN = SzGjVzA;
            mPajRl -= vJmGSjOaPnrQKj;
            SzGjVzA /= SzGjVzA;
            vJmGSjOaPnrQKj /= EFoTOzfiPPDgPN;
        }
    }

    for (int pGOwbKsBafIouQ = 368593873; pGOwbKsBafIouQ > 0; pGOwbKsBafIouQ--) {
        vJmGSjOaPnrQKj -= mPajRl;
        SzGjVzA += EFoTOzfiPPDgPN;
        EFoTOzfiPPDgPN -= KEJDDDbgYNfCMp;
    }

    return kXdqrfLTHtVKTyP;
}

string ybNFlCgoqPTwZi::KSPLIZWIiHRS(string ttxSgCvNGiOUYSwR)
{
    bool CbyMDEQlI = false;
    int QpuXcanUuPSsu = 1316100882;
    bool IYcOXcJH = false;
    bool dVhrtbXdnGbR = false;
    int ABypFCNeZLs = 240269664;
    bool bpplU = true;
    bool WYMTdmcVuXuFNVB = false;

    if (QpuXcanUuPSsu < 1316100882) {
        for (int OaXZpWacBdaByG = 72673368; OaXZpWacBdaByG > 0; OaXZpWacBdaByG--) {
            bpplU = dVhrtbXdnGbR;
            CbyMDEQlI = bpplU;
            CbyMDEQlI = bpplU;
            CbyMDEQlI = CbyMDEQlI;
            bpplU = dVhrtbXdnGbR;
            ttxSgCvNGiOUYSwR += ttxSgCvNGiOUYSwR;
            ABypFCNeZLs = QpuXcanUuPSsu;
            ABypFCNeZLs /= QpuXcanUuPSsu;
        }
    }

    return ttxSgCvNGiOUYSwR;
}

void ybNFlCgoqPTwZi::bQHowGQaaTRBnDlg(int cGJBK, string RmgGQy)
{
    int TKRbdiDRuxTMjCN = 1821917870;
    string aDKnQNWdaECBs = string("RQMqIYYFMfAjaUpNwOofxSfHcbFNksZMLfFvVcHaXDvYvSOlUmLLKbEIQoVGPDlmEqvtRrSTtKEZnuexerhygfUxgftVFpBzMaSQlpJiQKIkDaUIgHRfnmRPpFUjOLELRmdkxdtErVaOPXonWyKYpaQWTnLhP");
    string TLqwUCOUC = string("DEEdIJfKDdYTVOBufiUnriJOuWXTDtJUqveXJlPhvoOKsUHzCDKeaUZuQBPuHYbagquMjrvCNBesZudPGbHdEtfQyVfDjOB");
}

bool ybNFlCgoqPTwZi::dQKgGcJKJKJz(double QrVhhQEJN, bool bPYpsWtspwe, double NCBVhLoQYjjiYkF, int xUDKxxoPy)
{
    bool fLOWyTQWjqoi = false;
    string hUsAMGqc = string("sQATUTxnUyrwdcoDXVfQPDKMYeqOnccYTUQyilvpxbGuwyZbCAZLfMgxntvBMczhRMukNndfIwCJchwgttUBlSKGsMkzPRvzzJJveAgHLoyjnqgDiagsJoboBGDEAcBIaScdZGIvHB");
    double ziiKQ = 747974.8777315533;
    int IVHpH = 141246336;

    return fLOWyTQWjqoi;
}

double ybNFlCgoqPTwZi::ULgojy()
{
    string RxLbQAHWEz = string("ddLjSqzZFdSPIUmiuEVQINTASuQPUfTzOyKHExbPKcaiFBYdiLEbJtMlGCmgqpAEFDWJsskUgiQqtOoRLahPVmVkCTPYVjAKoQXcJnJJUVRFBszwPaOgVhKVkhlMhoABamhYJiBpLshSKOfKSJfGtwOuiPfAiPGzDMrZuAfLqbWgAGFVgEtRwuHEQSVYowGcaMMQoqOsmjkoDrEjx");
    double zQgRhjOQSGLPwv = -742570.5444721975;
    double yLEgSgG = 457409.90745065094;
    string HbhNcZIvMkEO = string("QuaOfELGuTqaarlBFFUjptVrPDyXnWpGncNMnOfbIjtadjbPPEpuyMUKVNNSFyyoZaEhhQanJWyMYozUg");
    int hBwICNNySQLccX = -531188904;
    double CYdeZsMKN = 503623.64467003586;
    string wuKiV = string("CgWSNnsvhBIIXNIGOYxhqTomjRqcdBoHARXGNhGtJeBezlKKo");
    string AsGtxoBioLFT = string("kSGT");
    string KkzOKgInAwxMpHq = string("AfpacjZzsPaxzPDZfKsIkwBeghIhYojHksIgpPzYPGaPYqQTYOXUKCewnrKWfIjBScOtBxogVWXPvGBuRWuqFTOXSgofqlGbSEWmWHXjpqEgN");

    return CYdeZsMKN;
}

double ybNFlCgoqPTwZi::fTxbVojAorQy(string WmahGXiBaJVO, double BqnajBzxg, bool hzaVmIzKVXHGXV, double jvpXLe)
{
    string dbVXRUwNLHnfkMw = string("PeGZMkYxSbJIZegrBegFvACTldfeXzuabWt");
    bool cXnlPanqE = true;
    int upXdUJGXSvmWMqQ = 837833504;
    double DLtebfLDGNnZD = -264337.73624239216;
    string nJPORWIPDJyoZz = string("SlyRzccpbqqsuaFHqPesKRTUEmgbyleuAtVLIDSTFeiagtMYnjeQhJFegpheYOvMzcaLmhPSe");
    int uYMUYMR = 1605134802;
    bool tpDTAHEfowvOo = true;
    string WUYCBPEcilcnEm = string("imXmKCgQNbngFZiDkWlRzbaqYxaZkewxHkdPYQYcrazoJBzxObebOaODfJtWrzwlwmBETyQukeGoEoObQxMXQBtCqSuCHsNycSnuuUBmdDlzFvVipiSQpOvpRSzbAxqCIAHi");
    string RxYYzUb = string("YgJAfVNXbvhJjkoynKLIOgmBMOIwlyjIwAnhJqAUSKnhvDBTHtSrUhqeZpjLrHyJRDUyIwpdTcaDVdyDNfvitVEpZpmnmtAwJHPrqRdzLMPIjRVuimUwdAfVmtpngD");

    for (int fqIcFUHkoHlyzn = 1411175864; fqIcFUHkoHlyzn > 0; fqIcFUHkoHlyzn--) {
        BqnajBzxg *= BqnajBzxg;
    }

    if (uYMUYMR < 837833504) {
        for (int hUfelGMb = 288399152; hUfelGMb > 0; hUfelGMb--) {
            continue;
        }
    }

    return DLtebfLDGNnZD;
}

bool ybNFlCgoqPTwZi::zSyTOCglQxlvRlB(double VwmzZgJKetVUuCRI, double FPtgk, bool POOkSV, double fWHzIqecAphNKNLK, bool HhFQK)
{
    bool xbgSdJSFekOMB = false;
    double plLODMINZbnchelE = -229359.86700604405;

    if (xbgSdJSFekOMB == true) {
        for (int XCxYEGDEExU = 991783919; XCxYEGDEExU > 0; XCxYEGDEExU--) {
            plLODMINZbnchelE *= FPtgk;
            plLODMINZbnchelE -= VwmzZgJKetVUuCRI;
            VwmzZgJKetVUuCRI -= FPtgk;
            POOkSV = ! xbgSdJSFekOMB;
            xbgSdJSFekOMB = HhFQK;
        }
    }

    for (int YbjYrHIVNzJUIDn = 601656093; YbjYrHIVNzJUIDn > 0; YbjYrHIVNzJUIDn--) {
        continue;
    }

    return xbgSdJSFekOMB;
}

ybNFlCgoqPTwZi::ybNFlCgoqPTwZi()
{
    this->PHjetIvpP(1194308568, 255827.55333891854, 413451882);
    this->dUjjOTvtfQ(false);
    this->OavUoTIy();
    this->tSdAOKHVPdo(922167110, 766863000, -215142.8635489671, 1438744998);
    this->KdlnbTsk();
    this->KSPLIZWIiHRS(string("OeOGKSYbDJJBcwuQCsiPrLHrtpdMXJWMJqmRNN"));
    this->bQHowGQaaTRBnDlg(1673788633, string("rUjgIgMhiqLVLwQLIcqMdjsRJnfHYRAwrmSGePbzbErzZcwjXoYxLwUWrpXcSTOsdsPiWfCNoYoWsoXXyLzUEvuCjmWXafMDEOAncMxzxRDJCOBOMqjXKzjtmoKDHRkKoEICjHEvxVyuJfTED"));
    this->dQKgGcJKJKJz(420914.21698545635, true, -217485.2696288107, -717705197);
    this->ULgojy();
    this->fTxbVojAorQy(string("PpRgQoDvhiNUwkfWDycppfZKXOzAlMtbFvRCFSqMburqmFRlLYcOWUUQKipLdcVzDlonzzekaGStNFoOpogNTIQpecDqUBKKCsezOcRfIvHzVuOVdHBomoDaknwFTOmPkrCCtPlyYsieFtOiAjbEkEZqdchDTtGuQVHncVmZLilCfKIHAZPiHVCcxqjLYUoEEmbRSXGBoyqtUvBvV"), -922079.6032709501, false, 689868.5965006027);
    this->zSyTOCglQxlvRlB(423448.0049764062, 895973.0710905168, true, 675524.654673716, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YCcvlaVKhkRWfVK
{
public:
    bool bSWeWgyWUXVaqz;
    int rSlwwjKfg;
    bool vJSSptBccjU;
    string OgmyxiHd;
    double IKoPt;

    YCcvlaVKhkRWfVK();
    double jamipAsvkuV(double WJRFILlLs, int lPBCvNmTohVF, double iGeYnQ, int WimiuxbSTIHpQ);
    bool WSFlbCdihvbL(int hhXGQr, double LChrOayhKdvZp, bool ZwevkSu, string smNGwYtNSO);
    int QJroxtGeYfDrk(string oRTpDvQF, string ALXkDTpYRBl, double MjKxwIi, bool VcYgzylQobqVl, int YtKySkCIIXNhDEHD);
protected:
    int qaqrYrfp;

    int NTTAaOlu();
    bool tzcsCMX();
    string FHvtgsYA(double jUUIE);
    bool jtTQPFEV(bool IKbOH, int rFkqPqTnt, bool ECJOE, int kiZUbL, double rJRWvHKbMzkZkD);
    int AYYzLLaF(double SiHakZhc);
    bool yBkPJYkdgDJP();
private:
    int OmytTvznRKrEOPe;
    int MMEzcVmuzByRH;
    int icaPDMybFq;
    string OclWpsIx;
    int sUxMxP;

    void MONeXWncar();
    int zWUdvBW(int EVGNwCWbhtb, string ZjTrjomJV);
    double YpUgkhfLed(string AaaKhMPVrFe, int wkNWjgWazRYAJMDR);
    void pDZCbcSwerwwGe(bool CbPrlLVKZaRqMqVx, bool SnsXWOJQUHxkESc, int ltdpvOybXBZ, string GYhHxDEtLjItM, double WafzoImcrnbfhddk);
    bool LYkmOXZ(int oEmbn, bool QNwtnZHelkOQ, string EuuScmgBNGDK, bool bZbxMqCNZ);
};

double YCcvlaVKhkRWfVK::jamipAsvkuV(double WJRFILlLs, int lPBCvNmTohVF, double iGeYnQ, int WimiuxbSTIHpQ)
{
    double SeXluQyJwook = -80258.05918783169;
    double QFnrYOYyGxe = -85734.23108840773;
    string JZXADkkYJCq = string("FesbyAYqybDkFAgREMvolPQqwktYIriFwcnuFHyRbvuMbplJbCDqIGRGmTqiCqxffwvoGpSqSntDUbklWEmLbRDkwsgKcAZYypVcBOWgnnieWBUrfTZKtSKLmkVTEGKVvjxpzPiHpbMlGaCebDfKMwUGmaWXNxovchQIsizXJxiSwsEYznhrBpErXKaEhZinGDNQsdDFliQdJcYLW");
    int EtSVKfDpdqnc = 2145364293;
    bool mrlewB = false;
    int BqtAELDddETLSgyK = 1716397046;
    string OfCfxsxapCCoRP = string("sUFIqxvIZBebEINyGUndHOmYlYBRvMYcFCjYGLZbpwpFDUSRMffebSWlGtWrLXLtnVddiMQvSSzmHqfLahJJeXiCaPQBduRfADrVgAWPuALhwmSTTMSxIkxmaCqFREtHBSYkaAaJBrXRdPdVfBqqKXzFLoewrVWQCsqHr");
    int FkabqPKs = -1569161596;

    if (FkabqPKs >= -1569161596) {
        for (int YiVoNpzT = 1344396783; YiVoNpzT > 0; YiVoNpzT--) {
            JZXADkkYJCq += OfCfxsxapCCoRP;
        }
    }

    if (iGeYnQ == -80258.05918783169) {
        for (int kIfiiUs = 130403657; kIfiiUs > 0; kIfiiUs--) {
            continue;
        }
    }

    for (int MFIWiEpwZMQNhZK = 2101837711; MFIWiEpwZMQNhZK > 0; MFIWiEpwZMQNhZK--) {
        FkabqPKs -= lPBCvNmTohVF;
        WJRFILlLs = iGeYnQ;
    }

    for (int EXHzyGTitJzcK = 542374267; EXHzyGTitJzcK > 0; EXHzyGTitJzcK--) {
        OfCfxsxapCCoRP = JZXADkkYJCq;
        lPBCvNmTohVF += WimiuxbSTIHpQ;
        JZXADkkYJCq = OfCfxsxapCCoRP;
    }

    return QFnrYOYyGxe;
}

bool YCcvlaVKhkRWfVK::WSFlbCdihvbL(int hhXGQr, double LChrOayhKdvZp, bool ZwevkSu, string smNGwYtNSO)
{
    bool QRYHWo = false;
    bool uWvDEuGPl = false;
    double BHiyzDd = 294485.0502347869;

    for (int xbbGjcmG = 2128728190; xbbGjcmG > 0; xbbGjcmG--) {
        continue;
    }

    for (int kUDrXNWNFOxtf = 1736947095; kUDrXNWNFOxtf > 0; kUDrXNWNFOxtf--) {
        continue;
    }

    if (BHiyzDd > 379227.18927963846) {
        for (int tQvdvQHrwpkDP = 2025174512; tQvdvQHrwpkDP > 0; tQvdvQHrwpkDP--) {
            smNGwYtNSO += smNGwYtNSO;
            ZwevkSu = ! uWvDEuGPl;
            uWvDEuGPl = uWvDEuGPl;
        }
    }

    for (int NvrrDCGIoKANbPJC = 1674739123; NvrrDCGIoKANbPJC > 0; NvrrDCGIoKANbPJC--) {
        QRYHWo = ! uWvDEuGPl;
    }

    for (int XqUREyxlOXxzuX = 1319623423; XqUREyxlOXxzuX > 0; XqUREyxlOXxzuX--) {
        ZwevkSu = ZwevkSu;
        LChrOayhKdvZp -= BHiyzDd;
    }

    for (int kOOgOSXSA = 1534455115; kOOgOSXSA > 0; kOOgOSXSA--) {
        continue;
    }

    for (int WTbaH = 1516103550; WTbaH > 0; WTbaH--) {
        BHiyzDd = BHiyzDd;
        ZwevkSu = ! QRYHWo;
    }

    return uWvDEuGPl;
}

int YCcvlaVKhkRWfVK::QJroxtGeYfDrk(string oRTpDvQF, string ALXkDTpYRBl, double MjKxwIi, bool VcYgzylQobqVl, int YtKySkCIIXNhDEHD)
{
    double vaVhDoXb = -554774.892842446;
    bool IsJuHHtmGZxTf = true;
    bool NYaRX = false;

    for (int dFMrXrAoDN = 1108640388; dFMrXrAoDN > 0; dFMrXrAoDN--) {
        continue;
    }

    for (int UsgddWEWOvZJEs = 999580420; UsgddWEWOvZJEs > 0; UsgddWEWOvZJEs--) {
        IsJuHHtmGZxTf = IsJuHHtmGZxTf;
        VcYgzylQobqVl = NYaRX;
    }

    for (int uopETpMdMQI = 440369022; uopETpMdMQI > 0; uopETpMdMQI--) {
        oRTpDvQF = ALXkDTpYRBl;
        NYaRX = ! NYaRX;
    }

    for (int uXowsDXQpXxOwiXY = 1583148698; uXowsDXQpXxOwiXY > 0; uXowsDXQpXxOwiXY--) {
        continue;
    }

    if (VcYgzylQobqVl != true) {
        for (int UQrFEwK = 1946288753; UQrFEwK > 0; UQrFEwK--) {
            NYaRX = NYaRX;
        }
    }

    if (IsJuHHtmGZxTf != true) {
        for (int sYwnl = 1160263759; sYwnl > 0; sYwnl--) {
            continue;
        }
    }

    return YtKySkCIIXNhDEHD;
}

int YCcvlaVKhkRWfVK::NTTAaOlu()
{
    int nVSRCU = -1306737349;
    bool zKCPa = true;
    int meuintllGqfZAYRM = -605998753;
    string OHFyyWdYU = string("mOaOoFgUiRXKWoNjdUvfqldgP");
    double NdLsTzUZQWfJxR = -285028.2380932799;
    double UieWIBq = 249788.54760775028;

    for (int yodKpYegea = 763363133; yodKpYegea > 0; yodKpYegea--) {
        NdLsTzUZQWfJxR = NdLsTzUZQWfJxR;
    }

    for (int RbRcueKm = 882032838; RbRcueKm > 0; RbRcueKm--) {
        continue;
    }

    if (nVSRCU >= -1306737349) {
        for (int VVMjdcyVMK = 1829008641; VVMjdcyVMK > 0; VVMjdcyVMK--) {
            continue;
        }
    }

    for (int RjCxlVfeR = 713253659; RjCxlVfeR > 0; RjCxlVfeR--) {
        NdLsTzUZQWfJxR *= UieWIBq;
        NdLsTzUZQWfJxR -= UieWIBq;
        NdLsTzUZQWfJxR -= UieWIBq;
        nVSRCU = nVSRCU;
    }

    for (int dXcivnlfxVHidoU = 979861378; dXcivnlfxVHidoU > 0; dXcivnlfxVHidoU--) {
        nVSRCU *= meuintllGqfZAYRM;
        meuintllGqfZAYRM += meuintllGqfZAYRM;
        NdLsTzUZQWfJxR -= UieWIBq;
    }

    for (int VzyDoEf = 230592739; VzyDoEf > 0; VzyDoEf--) {
        zKCPa = ! zKCPa;
        NdLsTzUZQWfJxR -= UieWIBq;
    }

    return meuintllGqfZAYRM;
}

bool YCcvlaVKhkRWfVK::tzcsCMX()
{
    double TcbOExbviOGLNDh = -143247.66887334653;
    string KXzzue = string("cSgwnRvjCiYeZXaPiIvZXguvDUtfNfNTHvsSJJjZhXihKklJaqEActihedNRYcQmWGBfJwdPCjeAtGDnSqHaTNukLhIvVGQaRwPeDzsMajkohrjPShNtJZFTiILTdDLouZfmIqgxivLuBTBAcyqUgbQXzOfSbzxwrMiwpSvJCKdUhctjEsCcJYPRjpWBMptSEGDRyIcDaWbjdHcMrmPvMKBduXlGMFAboSGaJiKa");
    double ykeslcfZshrv = -817289.5551918298;
    bool uNVMhgeukbcpdTx = false;
    int lcWXHkERl = 1709324870;
    double lPGSPiVvR = -391513.4647961173;
    string eLBuYBe = string("jftnfHWxgtIhhfizeGkVLngIliCnaOIPdTygVOdqnbWlYiOfUhbRNeJcHRWLVVXErncvJuxgrenvZeWMEaBXzMNsbQiprMJuMhScLlZuGXezfXNARRyOrfLtLXdUsmzDYPunhvuTBSYGmWCIuPnpsnLmWCPhSowuOiipeUNzCUhxXBSBhLAvKVTDpOFRrlgiMfYloRyceEMxuIMnJonrTJQBcdNYAnXUDGugZBrxInKtZFdQNh");
    double qvAKvfLLJKvgyY = 775482.7421756405;
    string BzMghUwvbUT = string("vTreSorNZbuCNMNKgoFfKMmpWSakCuofCkABTnJantFAKzDPgQlwPSziGwEgNPaTlRDNssfFKkCfXGIusVzMVIqugnXjytMrLCOaZndAKREiF");

    for (int xTDiR = 762284173; xTDiR > 0; xTDiR--) {
        BzMghUwvbUT += KXzzue;
        lPGSPiVvR = ykeslcfZshrv;
        BzMghUwvbUT += BzMghUwvbUT;
    }

    if (uNVMhgeukbcpdTx != false) {
        for (int HwwnfQtRf = 860076587; HwwnfQtRf > 0; HwwnfQtRf--) {
            continue;
        }
    }

    for (int QsWqMkg = 202812563; QsWqMkg > 0; QsWqMkg--) {
        lcWXHkERl = lcWXHkERl;
        TcbOExbviOGLNDh /= TcbOExbviOGLNDh;
        TcbOExbviOGLNDh += lPGSPiVvR;
    }

    for (int WONyxLlDvhQJOME = 571598496; WONyxLlDvhQJOME > 0; WONyxLlDvhQJOME--) {
        continue;
    }

    for (int jgckvnmxwfhdWU = 2018247746; jgckvnmxwfhdWU > 0; jgckvnmxwfhdWU--) {
        uNVMhgeukbcpdTx = ! uNVMhgeukbcpdTx;
        uNVMhgeukbcpdTx = ! uNVMhgeukbcpdTx;
    }

    return uNVMhgeukbcpdTx;
}

string YCcvlaVKhkRWfVK::FHvtgsYA(double jUUIE)
{
    int iogsKouXyboPwOq = -267870584;
    string cIUqibRp = string("tulwXBbkRTLZWMpSwzNGZlmCTYbopnGJRGyiGZWHXnkRLWGUgqxsmWkSbhkEAXwfbhacREDKNsbAGcQjAPLUEMkSNCzytjvEVmJjhYHQLZRBZgAVUmHRChyJKixlxpXENVLRbDXKPaAhTNMIknDVhznIJHngTnVrcTuTevsHYRbOzOmVKVickbjCMoLWwhdmeRftsgqPKAfBKqWcdToTUIAQLCvmFPnFjHStXzQWsbAfQmxQjdIGi");
    string iPHWKEKNsyuCa = string("YRssSDFuspxvFuYXGiMEcuxSoGIVjnHwEStdZbynFwKZHWAEteNRmZqzDKbhyogUPNsPwKafdsEgzzbRQVfndnINwvEdRmUqtTGLctYPkgARlObMDjflJtZcQNfoEZCRqVv");
    bool PpnJeqP = true;
    double AhDGDbHTmugwFr = 744254.7453703088;
    double wUhttxIgIdRIGGk = -445969.37852751015;
    double oHkvN = -341942.4964126248;

    for (int OgkLVDxAWkM = 1037417126; OgkLVDxAWkM > 0; OgkLVDxAWkM--) {
        AhDGDbHTmugwFr = jUUIE;
    }

    return iPHWKEKNsyuCa;
}

bool YCcvlaVKhkRWfVK::jtTQPFEV(bool IKbOH, int rFkqPqTnt, bool ECJOE, int kiZUbL, double rJRWvHKbMzkZkD)
{
    bool ncZoxgd = false;
    int bKqHlgKpTp = 1393224448;
    int LLptw = -981071542;
    int hWTJiAqKAwu = 2025715881;
    bool fiKUMGblsZgu = true;
    bool JAanh = false;
    double DrCZobHSbKRgU = 187958.32306337473;
    string lfsHHJUuCJHErHH = string("OuboNdPqnyCeGaPQeiyCVkxPRtrzJHFUsGvAJzLZWlrmADxLDKtNMhGhdJeUroNxxcpBe");

    for (int nXDllYgxAUVQmQ = 1835876042; nXDllYgxAUVQmQ > 0; nXDllYgxAUVQmQ--) {
        rFkqPqTnt += rFkqPqTnt;
        DrCZobHSbKRgU = rJRWvHKbMzkZkD;
    }

    for (int uSpNvflTGbiErlB = 898051863; uSpNvflTGbiErlB > 0; uSpNvflTGbiErlB--) {
        hWTJiAqKAwu *= kiZUbL;
    }

    return JAanh;
}

int YCcvlaVKhkRWfVK::AYYzLLaF(double SiHakZhc)
{
    string paYiRDsKT = string("fuyaEYHwaaBvpQLadRlStLiuazHwXlcLtwQVaDhixKWEdrdgEjCyQQnZtSLUORgljmahsAPYarivFdPwHfSihprSuYhEgH");
    int lkrgpRYEnTbU = -1885681624;
    bool oNotAFYtYPi = true;
    string LPiZYlzQWT = string("cgBmIOpvWDIBrnIAaGHlqekqocmvNQPNznBTQIIeLZorNGCflmEExCpBohIBsTyupAtSyxLKxpOfGUIcfOEyrAKTLNvzguOGBPIkSoaEnKvOHpSzwcDeWAqmAJZQvvHLtbrMXvMoavRRHkdvsQApukPoGcwLhErtbaZyijBDeVeadUMYWhJvUHbPykCwuMUNkvBACvWLnhUjmvtNGeptAIFamztPhwatGQywDJyhfbpyFntAMYAeAIggmeTWi");
    double KFrcMrMdBUVglP = -231948.66040682295;
    string dpDEzPZAeeGCJRI = string("HYRSFjxOfOcBpmiWXSrLgoJIAxtTcbRlqqgfGTeITrekSiCVsjlCEpphJyUbHQSpRJVZZqSbauKteFwSLXXTroOlfNFBIJjLXYVwabWBUHueVXImwailGwKqIdgzgEyoPqLVUUtNSRKALlBJFlLOgxbNnCbdxrYogYvoVgqbDvmYFHwCelxidbHeRIUyoHslmjeiFoNOfJKZrDUpRTFKvWBDQvIEmArJOSTAmsroZrxiQrezugKuddSlnjYdglK");
    int TQjHq = -25345255;
    int slDpGvzlDSNGl = 817932477;

    for (int yYSOHR = 536309999; yYSOHR > 0; yYSOHR--) {
        paYiRDsKT += dpDEzPZAeeGCJRI;
    }

    for (int XlssGl = 1523311843; XlssGl > 0; XlssGl--) {
        continue;
    }

    if (lkrgpRYEnTbU != -25345255) {
        for (int oTfUUj = 993267111; oTfUUj > 0; oTfUUj--) {
            LPiZYlzQWT += dpDEzPZAeeGCJRI;
            lkrgpRYEnTbU /= slDpGvzlDSNGl;
            slDpGvzlDSNGl = slDpGvzlDSNGl;
        }
    }

    if (slDpGvzlDSNGl != -1885681624) {
        for (int XEuTaJDeEjF = 177431935; XEuTaJDeEjF > 0; XEuTaJDeEjF--) {
            continue;
        }
    }

    return slDpGvzlDSNGl;
}

bool YCcvlaVKhkRWfVK::yBkPJYkdgDJP()
{
    string EmttKQ = string("YNoXWynIZWoSxQVLVdkqdsDniACvDbzUXuSpEpUFAvtiHDXTKstKXhzHAxHWTCEwjNQeEYSEAbsZOFwyhtnSgWwgKjXWgEvCHNxnLyMkqqozVpPYTXFFigkpKTrBkWIflKqEPzorIfHyyOYdEMRDljtffDkgHNMdDCtCebFcmRbLKuKSfAUjUCULoULuuYlKJBJPkGtRihBmrytBRQIjULyZcStIuwdpORIQVXqpQHGDhTxFkHWcFwD");
    double bzoWDjAPJVgWZVuA = 893422.0861946942;
    double hlXmD = 381266.55899752496;
    bool hYKIKsIho = false;
    bool qSbnBXfWeUOC = false;
    string NJejzA = string("WuYPnRXSZgSmaSyDPoIgWWVpQuDFgeoYyKQMzeQIUSSeMqdUFOOlBXwbxCJMWOWMwkqVjqPACIGEnFsIoPGvglSeAQyEwxHwRLEdamYChgYLXJZtSBAhNNsUVWbeJxUFCrBfbdmVoMYeIjmnzmkHwsBpomrSwhLWJgvZxEgJdeHKrGKzNFjNjlLBcTsdIBFkG");
    bool EYqWIPnd = false;
    bool gsNlgMINrEyHDeV = true;
    int RwTTWMZgdncRuPys = 81399783;
    bool CjmLIDcHvUvnhvpf = false;

    for (int GWylZtCc = 793596486; GWylZtCc > 0; GWylZtCc--) {
        gsNlgMINrEyHDeV = CjmLIDcHvUvnhvpf;
        NJejzA = NJejzA;
    }

    if (hYKIKsIho == false) {
        for (int kSlAgw = 420609040; kSlAgw > 0; kSlAgw--) {
            CjmLIDcHvUvnhvpf = ! hYKIKsIho;
            EmttKQ += NJejzA;
            CjmLIDcHvUvnhvpf = ! CjmLIDcHvUvnhvpf;
        }
    }

    for (int LTamejdpbIymDm = 33824559; LTamejdpbIymDm > 0; LTamejdpbIymDm--) {
        qSbnBXfWeUOC = EYqWIPnd;
    }

    return CjmLIDcHvUvnhvpf;
}

void YCcvlaVKhkRWfVK::MONeXWncar()
{
    int eQTzJl = 1119153691;
    string pKaHREAs = string("fVPYBXZXGDqGWUNcAiaKfQPaZlkcGJcbxPDVaCPxJwuiqKMuQEtPpbFUqRDpqpOjjUYBcYuaanxclCHUxGUMhVafdbMzMtkPrcRkzuRjYpHHTXydskKVZnpWxqYPVCJYflkLXSKUgndEnNTazYOtlopJkKYHzJNAAnlNCcsaouIZK");
    double ZkmYto = -695561.6541254355;
    string PcSEAH = string("pSdeHudnOstbSwXRsGliFqOwxlcLmIbsgebuZGZpbmoCMRpZnfyRJaqSXGcvZKPqEnkCJygMPLTzaNjexZiPDuSJmyqnizpAHwaDcywoBpOUhphKnapcVdPNkYNTOJWRzVGzNIBRWiwewhMpuZpekdoUoYNQwMXNDkibmwYKpkxPAGGPZCviifBNeATHoQdVWjEKkivdJlhZtncmFNkxoiqxWTJhVHSEFfTjH");
    bool hgfbpYz = false;
    int uVzGTKAmSwyPvxsJ = 1560682659;
    string aPtoIt = string("QiUiDLhgnwhdCEgDnoxdOtssXUqeYxMYpbRnYUalilibdPkzWcsoipsQmNMhJvkMUwdLLmPNNIHTisjGbOdioQUeutZykFNnTdGQGTNbSJbNqamuILeAVAKJPYgoY");
    bool DVPURzJPTWfCx = true;

    for (int MXcbiBdDHNinMkT = 690829724; MXcbiBdDHNinMkT > 0; MXcbiBdDHNinMkT--) {
        continue;
    }
}

int YCcvlaVKhkRWfVK::zWUdvBW(int EVGNwCWbhtb, string ZjTrjomJV)
{
    int HrGbP = 477161700;
    int AGAGCXTY = 1546432017;
    int lejey = -1417718465;
    double TORGjywd = -372273.92293015425;
    bool TLCRdrLSKUj = false;
    string atKwZFyGaI = string("LDnOcXuwttbGOUuSxIXILIKnMXPgVydGNgqUHiDgceKRcFtGNkLUQgKvkZsjINRlObunIUjLqhNnhcEJNUHWVZrKlPdEpMlELXPXkIaepGzOtkVnQntCsyHqFkDihEnPLGMURnO");

    for (int ggvjuRW = 1919747199; ggvjuRW > 0; ggvjuRW--) {
        lejey /= lejey;
        TORGjywd /= TORGjywd;
        EVGNwCWbhtb *= lejey;
    }

    return lejey;
}

double YCcvlaVKhkRWfVK::YpUgkhfLed(string AaaKhMPVrFe, int wkNWjgWazRYAJMDR)
{
    double QJrzlio = 414016.8194436354;
    bool qKQcAgnT = true;
    int VYOVsiwDqqmWjx = 1160801259;
    double hqYjTkVUeMDuXUO = -183529.8024736554;
    double NavsUGkybN = 241837.15788021893;
    bool KjCHSv = true;

    if (KjCHSv == true) {
        for (int DDRqP = 2096649979; DDRqP > 0; DDRqP--) {
            QJrzlio -= hqYjTkVUeMDuXUO;
        }
    }

    return NavsUGkybN;
}

void YCcvlaVKhkRWfVK::pDZCbcSwerwwGe(bool CbPrlLVKZaRqMqVx, bool SnsXWOJQUHxkESc, int ltdpvOybXBZ, string GYhHxDEtLjItM, double WafzoImcrnbfhddk)
{
    bool CqaxrysZz = true;
    string NZGjY = string("igYzTJNDOKmyDUllaDTJAFNPllpZJHQfo");
    string mPTgewb = string("uQoWetMmndgzmMEgAWQQgfEZKrJVBgiDeYPEmeWmtNeYKbmRrVrTTpGwoXSJiQoBGTPZJyaARzDfBhiyzQFjEibDSBYafIhMAudAwiJLkPuFfswOQSmIUgtHTWDkyWcutzHaILxrzxhluVmHwJZVzvOtpYovsuftWeKcaKcNnpBiYJcHVHQoHZQdTshJAYVPZyxcyebYCeeyxzpOhUMaXdPrUtPJVBYtudKxRYXNlOajWIzSDKSPaxdZuFkp");
    bool kwPbTQXo = false;
    double XOWzHM = 547064.851326577;
    string mIXtwHRTrvGacdb = string("bQtJDkfsxettFgzLeHwQvgapixNuyfIlwXg");
    double rybbr = 940123.0060913247;

    for (int snrXwvEkp = 1466645939; snrXwvEkp > 0; snrXwvEkp--) {
        GYhHxDEtLjItM += mIXtwHRTrvGacdb;
        ltdpvOybXBZ += ltdpvOybXBZ;
        SnsXWOJQUHxkESc = ! CbPrlLVKZaRqMqVx;
    }

    if (mPTgewb > string("igYzTJNDOKmyDUllaDTJAFNPllpZJHQfo")) {
        for (int vcYYdJJLTyBGX = 931783190; vcYYdJJLTyBGX > 0; vcYYdJJLTyBGX--) {
            mIXtwHRTrvGacdb = GYhHxDEtLjItM;
            SnsXWOJQUHxkESc = ! SnsXWOJQUHxkESc;
            kwPbTQXo = ! CqaxrysZz;
            NZGjY = mIXtwHRTrvGacdb;
        }
    }

    for (int SFTNDyFMxmvhuhva = 631902583; SFTNDyFMxmvhuhva > 0; SFTNDyFMxmvhuhva--) {
        kwPbTQXo = CbPrlLVKZaRqMqVx;
        mIXtwHRTrvGacdb += mPTgewb;
        CbPrlLVKZaRqMqVx = CbPrlLVKZaRqMqVx;
    }

    for (int aGHEz = 62294067; aGHEz > 0; aGHEz--) {
        continue;
    }
}

bool YCcvlaVKhkRWfVK::LYkmOXZ(int oEmbn, bool QNwtnZHelkOQ, string EuuScmgBNGDK, bool bZbxMqCNZ)
{
    int XPBqLi = 1368426794;
    double rkZwaCInB = -538627.895383285;
    double UQvqxaaEhCmI = -632136.1950834804;
    int lGBTOBLOkfjUU = -1123905946;
    string vMixFNNGFI = string("jDXwFysNwoJxwbEZieUvyPKybiSttkSoFbhEqzQTQonrb");
    string HYHbICd = string("GAbAnEPmZBjWiMowWqXSliMNytyluvekgyjKZoTKqgrTUrBLGeniqOatOHmRYuhvwOjVmsSAkKBaDonVDAXOYBKfwrnmuPxXXfaANevWvXkuNRQLNkJUnvVzcvvlvnpcyc");
    int uiBUUqRRWFvAf = 32425402;
    double IRIXBiZFJa = 323583.8552508297;

    if (bZbxMqCNZ == false) {
        for (int llHAthtUziZqu = 1396271439; llHAthtUziZqu > 0; llHAthtUziZqu--) {
            continue;
        }
    }

    for (int ORkSCn = 709625797; ORkSCn > 0; ORkSCn--) {
        XPBqLi /= lGBTOBLOkfjUU;
        EuuScmgBNGDK = EuuScmgBNGDK;
        HYHbICd += EuuScmgBNGDK;
    }

    for (int XXVnNSAepYMUBtg = 1048663247; XXVnNSAepYMUBtg > 0; XXVnNSAepYMUBtg--) {
        EuuScmgBNGDK += EuuScmgBNGDK;
    }

    for (int CNuFaTlfJB = 1080697000; CNuFaTlfJB > 0; CNuFaTlfJB--) {
        oEmbn *= lGBTOBLOkfjUU;
        bZbxMqCNZ = ! bZbxMqCNZ;
        EuuScmgBNGDK += HYHbICd;
    }

    for (int rbAYdv = 1123061534; rbAYdv > 0; rbAYdv--) {
        vMixFNNGFI = HYHbICd;
        oEmbn = oEmbn;
        IRIXBiZFJa -= rkZwaCInB;
    }

    for (int sGyRbDgjBR = 1455875457; sGyRbDgjBR > 0; sGyRbDgjBR--) {
        IRIXBiZFJa /= UQvqxaaEhCmI;
        IRIXBiZFJa = rkZwaCInB;
        oEmbn -= lGBTOBLOkfjUU;
    }

    return bZbxMqCNZ;
}

YCcvlaVKhkRWfVK::YCcvlaVKhkRWfVK()
{
    this->jamipAsvkuV(-140098.76597859606, -2124251468, -301747.62349853356, -1525931280);
    this->WSFlbCdihvbL(1358494818, 379227.18927963846, false, string("EhkhuNBsaYJZBXwRiDiqrEWFmCoJGxcfnHUEwJJLAwTCYCWGWVJIkDUSbpSSmECgWVkhfSPHnCMRLLptFeDYaDydbCXLHPenZnbIoOIKYKhJodJqJDcWJzjPSwAEVieIuyOqgkHxpIoimWsXUWLCKOnxOnCrpvbueIcwsbdWPWjJNBnPwVHojdNYrerFaCLCPBBNzHyBlhvznbNKBoOqvPFRrnjuJQClotQWWSQwqQbFAdaOEjcHDrR"));
    this->QJroxtGeYfDrk(string("qMlvYWpNzBfhkVwClvWCWhuYoLzBcOUWsTolWFKxqSrHvkbsX"), string("sikZScfktAChTBbUoDxdGnyAI"), 56816.79565353, true, -326193806);
    this->NTTAaOlu();
    this->tzcsCMX();
    this->FHvtgsYA(-812533.5468849585);
    this->jtTQPFEV(false, -1730760565, true, -1244602736, 850689.2167695008);
    this->AYYzLLaF(583761.1977208843);
    this->yBkPJYkdgDJP();
    this->MONeXWncar();
    this->zWUdvBW(1728764903, string("WfALygHlrQhVoYaHQKtNfMdYGlOZMwPXtNNmocFZQmYLxAWGHcEkdpdUGWHqrKraYPcBiTaoUYfMTzXG"));
    this->YpUgkhfLed(string("AcHvJoSHZQyyjYOLPHJYrDqTKWLtWgKPetbWJLbxRSrbOGpmqeFLdQLSfWrPJKaJWudwSBQwGNMUEBRjYDZjbfzanqxxTYrnqFpInTaKdDQbvjNOOTnaJWhjmKxSDreEvpvYYZpdnMYuwjMLjrwvNzRKuPUwVmmlBJtvloJpOibVLYMfOEYJbHKwljuiXisgBDZOtgjjhetzxJYmAORbIeubibivKYkUJHLMGrByhKt"), -635098989);
    this->pDZCbcSwerwwGe(true, false, -287853629, string("P"), -246260.64158622286);
    this->LYkmOXZ(1322355467, false, string("YpWNmjncPeNdZeuzGQdPcRAkmUSjijIUOftzDwsCWpAPOYRXiajewEXjAkWWrCzpHzqqDuqIKxAbqFpMMKHCcLBkKHGXpMxrGVBEECbVTfOjCArmlhePATLzszLGHSUofElBqMjXrLLQSjndxstSbDmbGrVSSCujndeoEWwDLEOVZFvHiDGYXZIDwlQGCjequhncsUUdrQEeXxzaohaXmqZH"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nHwWJHsQNmHI
{
public:
    int nQpXx;
    int fWCGkAAlfL;

    nHwWJHsQNmHI();
protected:
    int ilVIFUzxNgMJSGS;
    double UCmJnkRoihu;
    int smYxtYOyzHoWIn;
    double cdKtHvqbsNprKLP;
    int nxaaoUqKSueSfoFl;

    string iOWKkHIbgBGcbY(double ZTFdY, int dXHhIxj, bool CRNcRm, bool XumxalFETlr);
    void aGJbKYI(string ymwHveQOUYIzVp, double bsZevEexsw, int NdWkAkdkTwdrLaSZ);
    double MWIyeL(string EUReg, string lIzeUsQTFJKhAVg);
    double SARRysWtbjjhYe(int FpvWy, string TBGdQeNwbJLBdcJ, double JrYpmwGsnfu, bool ZujVPfPgralFfnur);
    double FJFJUjobJxg(double RengImxXtcK, string khZNAvdccL, double WqboSosgyJoJQ, string ylTqhKUs, bool ZNKUGaPAIiiVi);
private:
    double dXiUQYRl;
    int ujEBfsA;
    int WTWLBuPsscN;
    int GKGep;
    string OyihV;

    int XGEgA(int xrpOS, string eMxbtFEUyTa, bool lZFOaVfUYiI, bool kezgESXotdn);
    bool FIchcX(string bXunCKjRHqE);
    void JSRcEfwRWZd(bool XbCAbMlgQvp, double BuEUcKha, string gEbcuzHctK);
};

string nHwWJHsQNmHI::iOWKkHIbgBGcbY(double ZTFdY, int dXHhIxj, bool CRNcRm, bool XumxalFETlr)
{
    int ivlePTDLWa = 279607472;
    string IgclNs = string("RHhPvhgwZxhWUltGDfEwMpJNUJdJuAibPXRagLcrXhKgQodFSvdIDPcmBEzgdpxrvEqPtzmVKcXgLQsFBUJByIJqZOkwcHwbdyEGTEhTrItExhWJnxljeQDjhWzKFjyIdOjmwNQYyEtMTZTXBvTuxwwJsCrxMDjeohnAsCXIVlWeLfSbRanlCfxpPeUDtqbJjbzvpbYiRAIRHxP");
    int OTRNytUIYQyiqh = -1786513981;
    int JYQJKmEkdmYY = 295005340;
    int gIZDUDOkc = -1562152195;

    if (ivlePTDLWa >= -1562152195) {
        for (int BNSsoRJhvbPWf = 750829327; BNSsoRJhvbPWf > 0; BNSsoRJhvbPWf--) {
            JYQJKmEkdmYY *= JYQJKmEkdmYY;
            dXHhIxj += OTRNytUIYQyiqh;
            CRNcRm = ! CRNcRm;
        }
    }

    if (CRNcRm != false) {
        for (int bzyzHsg = 1907873864; bzyzHsg > 0; bzyzHsg--) {
            ZTFdY *= ZTFdY;
        }
    }

    for (int UxyiT = 1832701936; UxyiT > 0; UxyiT--) {
        continue;
    }

    for (int EbjjwqNGfzTuUCzH = 1646630922; EbjjwqNGfzTuUCzH > 0; EbjjwqNGfzTuUCzH--) {
        JYQJKmEkdmYY -= gIZDUDOkc;
        ZTFdY /= ZTFdY;
    }

    for (int jVPbpBZRpka = 1273230596; jVPbpBZRpka > 0; jVPbpBZRpka--) {
        JYQJKmEkdmYY /= JYQJKmEkdmYY;
        ZTFdY += ZTFdY;
    }

    return IgclNs;
}

void nHwWJHsQNmHI::aGJbKYI(string ymwHveQOUYIzVp, double bsZevEexsw, int NdWkAkdkTwdrLaSZ)
{
    string UTOgwAonodtKS = string("eiorZhkCiiJzCMFDeDeyuijsCawaeEbJrjxQvwmfR");
    bool OzAEFxMVNatb = false;
    double aoxxSVJcP = -376454.1039982761;
    bool cDdNNOrrmiynmO = false;

    if (bsZevEexsw <= -301851.1240666233) {
        for (int CzWEdBnYuxhraW = 422099050; CzWEdBnYuxhraW > 0; CzWEdBnYuxhraW--) {
            ymwHveQOUYIzVp = ymwHveQOUYIzVp;
            ymwHveQOUYIzVp += UTOgwAonodtKS;
            bsZevEexsw -= bsZevEexsw;
            bsZevEexsw -= aoxxSVJcP;
        }
    }

    if (OzAEFxMVNatb != false) {
        for (int gZLnKnkyYPUByFS = 2096545321; gZLnKnkyYPUByFS > 0; gZLnKnkyYPUByFS--) {
            ymwHveQOUYIzVp = UTOgwAonodtKS;
            UTOgwAonodtKS = UTOgwAonodtKS;
            UTOgwAonodtKS = UTOgwAonodtKS;
        }
    }
}

double nHwWJHsQNmHI::MWIyeL(string EUReg, string lIzeUsQTFJKhAVg)
{
    string wIerlRhuWovLsNG = string("lJWQyUiatTtfHemUYCWwkFilrsBBslKtQvpheXejpVoBTVGJCbsfozAlBTjSFVBRzHGEizPqhUjngIlsEqFnBKilGrzlXEYtpcEYzYCCOFIeQqwVqUstysUPtPXwHvSygnLtOlGnvbWCLzEoYHsewZZHqWWnE");
    double VJljonagqoZG = -535507.5054622467;
    int lLgxdRKEpAftvfe = 861690328;
    string jhLNwBfXThA = string("gnxuBLSgiWvojLnImuElBPnSpudNFKIwWTPqyQXOtJzKfgCqyOEcaZlLxhdkUZJVGAMKoYIXzCJSMVZYKTSRSysMQGdmUnHTFgJiAVQYLSIqRpReqDbdxLjTLhoTJEVHxKlfAsDCAmsgnGMGlSmJzelchgQYYPiyKnQMuqsXiBZQGsliMAMADyMpcmJkWeTtlmtiMKSuvajYYEEpjRyoxeUAWpsIFQHmAGlzAawiMsweXbpsUurRGNnPFJ");
    string zUNkJIUmdfBacASO = string("BygONNIQotWVyiNgQWPHHEdYdGCVcEeaeISRKuKuxgTvdQMEoCrXHTyWTaYLFHHfNjjfJYaKXHCRJBSbEsOuegjQhUEYOXULWsiNkrQqbwchEuejS");
    int IqeZBENQr = -1503164575;
    bool XRFesdB = true;

    for (int kKrinXgcF = 226725239; kKrinXgcF > 0; kKrinXgcF--) {
        IqeZBENQr = lLgxdRKEpAftvfe;
        lLgxdRKEpAftvfe /= lLgxdRKEpAftvfe;
    }

    if (lIzeUsQTFJKhAVg <= string("EISjORpgLkUSGxajEgMGpJfbhGZXRUAmbgQFqenuNkAVZbyfcNZtEGHsAlNstqMxFepmQwMMKMgMhmjMmTpTBa")) {
        for (int vrMHyAe = 1500021275; vrMHyAe > 0; vrMHyAe--) {
            jhLNwBfXThA += jhLNwBfXThA;
            EUReg = jhLNwBfXThA;
            EUReg += lIzeUsQTFJKhAVg;
        }
    }

    return VJljonagqoZG;
}

double nHwWJHsQNmHI::SARRysWtbjjhYe(int FpvWy, string TBGdQeNwbJLBdcJ, double JrYpmwGsnfu, bool ZujVPfPgralFfnur)
{
    bool jhBoTQJPR = false;
    bool PiuwfqtpGsm = true;
    int stffrUS = 337605722;
    bool XdWKmadEIgBDeM = true;
    int sivtwgrajV = 1498066664;
    double YwBXgDyvkBels = -21831.50779829817;
    bool AZrKkB = true;
    int GYklX = 1459405895;
    bool MLmtlrKcDzsEPt = false;
    bool JkgAi = true;

    if (MLmtlrKcDzsEPt == true) {
        for (int diEVdgNBgaDrLS = 1338464843; diEVdgNBgaDrLS > 0; diEVdgNBgaDrLS--) {
            TBGdQeNwbJLBdcJ = TBGdQeNwbJLBdcJ;
            ZujVPfPgralFfnur = ! jhBoTQJPR;
            JkgAi = JkgAi;
            JkgAi = ! PiuwfqtpGsm;
        }
    }

    if (XdWKmadEIgBDeM != true) {
        for (int ogNAPlDTuSnSv = 1840937178; ogNAPlDTuSnSv > 0; ogNAPlDTuSnSv--) {
            continue;
        }
    }

    for (int etbKA = 2139914104; etbKA > 0; etbKA--) {
        continue;
    }

    for (int TWoUjynusdti = 1378063121; TWoUjynusdti > 0; TWoUjynusdti--) {
        XdWKmadEIgBDeM = ! JkgAi;
    }

    if (JkgAi != true) {
        for (int eViVaCW = 1989066880; eViVaCW > 0; eViVaCW--) {
            continue;
        }
    }

    if (XdWKmadEIgBDeM != true) {
        for (int kEFDjGsspglOI = 907034512; kEFDjGsspglOI > 0; kEFDjGsspglOI--) {
            XdWKmadEIgBDeM = AZrKkB;
        }
    }

    if (MLmtlrKcDzsEPt == true) {
        for (int qInhrrKvvnITqq = 542024125; qInhrrKvvnITqq > 0; qInhrrKvvnITqq--) {
            ZujVPfPgralFfnur = ! AZrKkB;
        }
    }

    return YwBXgDyvkBels;
}

double nHwWJHsQNmHI::FJFJUjobJxg(double RengImxXtcK, string khZNAvdccL, double WqboSosgyJoJQ, string ylTqhKUs, bool ZNKUGaPAIiiVi)
{
    string NePQxlAFJpJcv = string("AwFMAUAJgJUslYGelxYkuGuJLcLYiAqCmZdUQKUOzYEpHgYTZewwSGsPjhLEivCyMdSzPKejOtqagQONJvmXAxAxUGhxGbZpMjdSfSIJiXDzKBYCiNgmYgOrQtwvuuUfNHBbXMItWJqgJRIPPEmcbDezWYKamkVtqumJpDXhbebVzmqfnmrkgdRwbinAVInexgYbmydKbuyUYXZCsVYlYpZWvjRpXKFYsiTrqcHwFCwniy");
    double vNqNGeNU = -151828.7507475942;
    double STwsniv = -832479.4972909384;
    int WlhvZYzNolDeGKIg = 1448947655;
    bool qAgvcb = false;
    bool KDXvrKPR = true;
    string mABrPZG = string("gHrUQmAimmAYpKzumEQGtjOIbBLBCwqwKezvwFBZVpDPGmBHunWRpylSCcvZEwDfhBpMEKfpZcBhCXZVBSZDkwHDXAVujzvQyEkBscVBKzkQgMSicOOjNzEKImLxpwkpzIqOtMonRizHoQHYdecUjspgTigEPMeRpzXxflpSwYsAsiwUpejqNDfkHDHSbRsdmgWWuVcOcLw");
    int wdveFCrzYrCSPyO = -1671139949;

    for (int lunENSiRJLxd = 1619979358; lunENSiRJLxd > 0; lunENSiRJLxd--) {
        ylTqhKUs += mABrPZG;
        RengImxXtcK /= RengImxXtcK;
    }

    if (NePQxlAFJpJcv == string("AwFMAUAJgJUslYGelxYkuGuJLcLYiAqCmZdUQKUOzYEpHgYTZewwSGsPjhLEivCyMdSzPKejOtqagQONJvmXAxAxUGhxGbZpMjdSfSIJiXDzKBYCiNgmYgOrQtwvuuUfNHBbXMItWJqgJRIPPEmcbDezWYKamkVtqumJpDXhbebVzmqfnmrkgdRwbinAVInexgYbmydKbuyUYXZCsVYlYpZWvjRpXKFYsiTrqcHwFCwniy")) {
        for (int OJMWzFjYQKrNZKn = 442515302; OJMWzFjYQKrNZKn > 0; OJMWzFjYQKrNZKn--) {
            continue;
        }
    }

    return STwsniv;
}

int nHwWJHsQNmHI::XGEgA(int xrpOS, string eMxbtFEUyTa, bool lZFOaVfUYiI, bool kezgESXotdn)
{
    string fEyAZrNAlPd = string("COibjdswtjuoheWujcucxFbiLyiHcnpiLZqbWnGwhsxioaOxoqLNRQlBfeFuXyfNWkovPezZRpAGwVFmXvUbtZXveZWkEabOYaJtSUnSxMeravjxpEYBkvEiDkTgSBukelCjSzdkGhgESiGNOqLkmKyRUMCFiPzgkChpQV");
    int KbKfrWmh = -92419064;
    int bpXkxNuYaK = 112074148;
    bool RndaFcehdzMnFy = true;
    double YnlirvUuv = -655549.6875665586;
    double MFFLIt = 921240.3033085763;
    int KMncRinVoPFp = 1099005279;
    bool pDdgYUJcxSpGiC = false;
    int uPNcZpWidpUYH = -2136015305;
    int kFsfGwRJnyz = -1351531596;

    for (int dmUWMbxnVd = 1243330221; dmUWMbxnVd > 0; dmUWMbxnVd--) {
        KbKfrWmh += KMncRinVoPFp;
    }

    for (int imYomLpp = 1596506331; imYomLpp > 0; imYomLpp--) {
        KbKfrWmh -= xrpOS;
        kezgESXotdn = ! RndaFcehdzMnFy;
    }

    if (pDdgYUJcxSpGiC == true) {
        for (int HUDzgVrdEEUTb = 2111506353; HUDzgVrdEEUTb > 0; HUDzgVrdEEUTb--) {
            continue;
        }
    }

    return kFsfGwRJnyz;
}

bool nHwWJHsQNmHI::FIchcX(string bXunCKjRHqE)
{
    string vHWlRCQQNe = string("qphfioRTtgHdhcTXGgsdIqLKNXDEtX");
    string zLdGdcXD = string("pWRkdGSWvnEzFuhlXpUFC");
    bool ONpkSQUTfSMWlQz = true;
    string hsSKbCtOWcPnT = string("eLQNEyXNVSMIHQGMTyuFDnldcpBuYFZvkIjIDJMzSnhtPEVeJhzeufqDEiXLDQOkAXZkKfgtpnZGCfdjxNbSJzzqLOBVccnmaGsGOJiMspMmTJOcyyXZPPnojARXyyTgukjRASTcCxAUxMuyDuXcOlmLWeUfUGGsVnwDibtMGLPVvuFpVBVfdaFMzlsvhRYMXMUtXNsLwpikaGASdpVhUR");
    string piMPZfYnK = string("kQMiMyzEuehnIXrWMxbwGmxUsbTdvZeDCAGnKYTQNMTKMWnvZfjWsiElbzyjnPBhucvbaiUBBjhSKHjqsWKCXOVcJZGdDZkydGDjHkihqaSgCZbVOergfgsqFUOCKKDZMiLVfpnAYoYBPIqFRqQBLlJIRHWrWheaqFPvCcFKVoRskYhbCCmbWIJEoB");
    double mAsCSKFcaUC = 956498.7269294302;

    for (int eEwvrxeSWbdXM = 1271820830; eEwvrxeSWbdXM > 0; eEwvrxeSWbdXM--) {
        hsSKbCtOWcPnT += piMPZfYnK;
        vHWlRCQQNe += bXunCKjRHqE;
        piMPZfYnK = zLdGdcXD;
    }

    for (int uvESUyVaeCs = 1580844294; uvESUyVaeCs > 0; uvESUyVaeCs--) {
        vHWlRCQQNe += vHWlRCQQNe;
        vHWlRCQQNe += zLdGdcXD;
        vHWlRCQQNe += vHWlRCQQNe;
        piMPZfYnK = zLdGdcXD;
        bXunCKjRHqE += zLdGdcXD;
        bXunCKjRHqE = vHWlRCQQNe;
        bXunCKjRHqE += bXunCKjRHqE;
    }

    return ONpkSQUTfSMWlQz;
}

void nHwWJHsQNmHI::JSRcEfwRWZd(bool XbCAbMlgQvp, double BuEUcKha, string gEbcuzHctK)
{
    bool eZMOLaJqDBGfE = false;
    int tcJmc = 959443989;
    double bktRhxqOnhArHigP = -321619.0700013796;
    string DMJzckjiBc = string("MGIiXnXIXkBgNGTszLaYPlqhdMvsWvpaUvFbhEINuxlGWQkpQSUkyHVGnQVxuozgockCRdpAuqjxwf");
    double gIAqLyZ = 792089.9290543054;
    string ZwYTyyrnca = string("cfLXLkVewzQKGAxnnGkXBEpwOhWxmdgURHTEdbOWMTdvjMPAPsINVgjusEhSmgprscWfnAidLUtJQxAdOztmCrgSgb");
    double RWiYrkMtLCAuuP = 879731.7884595868;
    string NKaZtOVTj = string("KtlAvfyPZWrXoEXyHqbBvlpakbYRJKc");
    string LnctuJLdeClnWSoG = string("qldiorufhICWisMozMmGAKmJUxZLQOaFqWzBYHzpmXBgNrsehJaLJblsQvmWPrQeYUqEhCqqXiYNLOThRedfgTYAOEXpVMlpDhsMEvaNSRInrupkrQSiEURMrbDUAgHhpUJWZOKfpVlejlHBrcyTSiqAngwPqlRFkPNKqSBEGHprgucYEyYjoPoFhziQHBdYehqS");

    for (int dNcrm = 1717392449; dNcrm > 0; dNcrm--) {
        ZwYTyyrnca += DMJzckjiBc;
        gIAqLyZ /= gIAqLyZ;
        NKaZtOVTj = gEbcuzHctK;
        gIAqLyZ = gIAqLyZ;
        LnctuJLdeClnWSoG = ZwYTyyrnca;
    }

    for (int rkJumNRSgf = 753120555; rkJumNRSgf > 0; rkJumNRSgf--) {
        continue;
    }
}

nHwWJHsQNmHI::nHwWJHsQNmHI()
{
    this->iOWKkHIbgBGcbY(1035103.5847274105, -394300535, false, false);
    this->aGJbKYI(string("TWq"), -301851.1240666233, 1307914647);
    this->MWIyeL(string("EISjORpgLkUSGxajEgMGpJfbhGZXRUAmbgQFqenuNkAVZbyfcNZtEGHsAlNstqMxFepmQwMMKMgMhmjMmTpTBa"), string("hVptrigyPTWIWDxvguxfPsDpwrBWqWzodRuqVVVSLZBiUVlxXjOIcSZHdJUQvFGc"));
    this->SARRysWtbjjhYe(681189847, string("WiZovhhpchVfHEsMbVmVcYfVZNPDRyXYQKexVnwDOCqiSTslEmXgIfquuzgPSzBOGmbGUAGFdHSxvDzvCFHJMcYOjnGInCSoiMvMaQtNrDTiYsUMKOKMXTgnrAHuYjtDhONgFvdKWkUkpGNrFknCVKmeqIZysgdbVcOpcpOZNNMCYXxtXVszEpWpiwanKIGDwhelsUOZKrdogdJXnofQDkLDPscnmNFsYqQuVdTVnpPzKsYHyyWkjxZhmu"), -543712.9194895637, false);
    this->FJFJUjobJxg(-912759.2303071707, string("QjPdhNkVUQIhOGTEwPBhbRUsRpzR"), 250377.3161381271, string("zMUdRKJuzvlNoSoWLfwolzjaySWgZWddYjtNzlgcgQnrEDxfhExVmVlQagqEHsgtistbuGhTiadozqliEGAloFwOCHFenngMrNVdilmYRcBAWquvVLwctwJOZnhjxDXWCjiTbtILbRFEgDgjbgmxcsNgQIclQxXBtgMDdBTTDWPfsFjfdOndNtwIiEtnmgQnvQDInvgHBqVmVOemnfFvOVlIojcbqIsmIwtBVsnQer"), false);
    this->XGEgA(951156934, string("wCErKxkDEbmjpfhEEdlVrwolOYhRmPLZsJyywGCkRGppJRnxFydeAiGOizqRtbrHmWAhtnSnmuxTTgxBuCSArQCVpfBJLCUmCQhvwxuHUSczESrKFKTmTpRDlVqYTYyDrXszeOaMKHiJYrKLjIqmerP"), true, true);
    this->FIchcX(string("InAigwhICqUbTdJBddjggEcVpsmqmcfSGZFyEp"));
    this->JSRcEfwRWZd(true, 565578.6989619834, string("MagVlUmTgRkdEQPupHAgInxgVThDCyhgyifQYWjTKElBTUBMIvEPwLrpKlFwMneLlRKBZPcLcYqfbSqudLnXyIFJITVZHIWehbMrfIBmgtxLUZelhwEQPf"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BIzCtUoPgeyVbnKU
{
public:
    bool ICkfRbX;
    bool OEhiLyjLpGuRTKqH;
    string StfYW;
    int RkhQiJONeg;
    int hpnjR;

    BIzCtUoPgeyVbnKU();
    bool dkawrQ(string IbARXJjtZrsgLx);
    void dcktWFSleesqg();
    double SQtdoBQSjNEngndi(bool iUWDxEy, double xmZbt, int mAciilRCJR, int UeBOxeSamgW, bool qMFokeZiEdR);
    int YSsGRaPOWREVZ(int ZtChKMKvTEF);
    bool snrYHd(double dQuTv);
protected:
    int YSCLKKvZUCW;
    double seyeM;
    double uTUaBrXY;
    int yMiLhYnzEUiP;

private:
    bool UQbGO;
    int BYsmxkQAVHOZl;
    string fslvDfRGSpio;
    double wkPkbqhx;
    int zMPor;
    double UBxFfOVkYLccD;

    int hoZDBpIDuLE(int KNAoseMwIwM);
    void GtnqTdNIAjDDo(int OtgWFmYje, double wVPOMtBTuZghEGM, int QlGSK);
    void PFiUIlaasd(int OcHUj);
    int cqhAyO(int haKdkSDBHLwoGsk, bool ZlwYTaOHrfgUWW, int jvZWSBTsGrkjVr);
    void BghIjBLQ(double NoHmgHbPWN, int bMrcaYLKwCu, int lqjJAyCVyBxQ, string BfGimUCXMthlcPYH, double nbjdZYLMGj);
    int CgPnZkpJD(double QkpKjybakyEZSa, int PAFyaUmNIl, string IooxQYZGWoRwdB, bool fAGwbA);
    void eSJCFnYUehhXmJ(string gGZdJ, int COXTSRIOxJjUnw, double JJLCneXWMDCOqRKE, bool yOOjQkUV, string EnXjMpefqw);
};

bool BIzCtUoPgeyVbnKU::dkawrQ(string IbARXJjtZrsgLx)
{
    bool KvIRnZGShOh = false;
    double rmkeXIITHpHkb = -692089.6922597766;
    bool ZXZSnyo = true;
    string maVafqP = string("RjzgdMXeYGZexylBFYuoxvUtEpGkQajdDDipXOPeXCqKOzvQAQFyUkGesdXUeRRBTKotwWWUcvhRzdpfiuiwEWFaJeyBUMnYOQsAWaONDjzUIVFRoceZAsyoGfEtgLDXuNdWFFmidApxfEREneqHIimPVMlPUQVBgsuBfcKMPvtdcGsnRLajmDkFKZQcEtrgMZJTFcADuUVxsMBKmuHuAcyzPFsVMrSUpaGRQQ");
    double WqeQB = -900510.133610044;
    string yqKELLPLImPA = string("YmGWKmTVpNmDGHHuBzMUbtkutlZBxSjXOGGzsPHEYmzSGbQvmJFnyiahAqzlhKhAlvPWcBrPRZGZBSIIDrhSlKUSbsNGrlWELGhKbOJVOv");
    bool mRyCaJuqzZVc = true;
    double OlJBgZfllpRqi = -319870.07932374923;
    bool vtGFBAEeJgcA = false;
    bool zTMcUFT = true;

    for (int IsbLvNICH = 2072230948; IsbLvNICH > 0; IsbLvNICH--) {
        maVafqP = maVafqP;
    }

    for (int kcwpHWVoj = 993454805; kcwpHWVoj > 0; kcwpHWVoj--) {
        mRyCaJuqzZVc = ! mRyCaJuqzZVc;
        rmkeXIITHpHkb += OlJBgZfllpRqi;
    }

    return zTMcUFT;
}

void BIzCtUoPgeyVbnKU::dcktWFSleesqg()
{
    bool bjIMTrVensaroR = false;
    string ySznqkfxLNh = string("sQfmgedqIVjIILdoJBslLKgReJTULhlrUSNckOMrZoGlqfTnNWjsbIASWkVhXxludjYoJHvhFaTTOBiBxUSzeUhtCfQtrTomQUenoODGVSXeAzorXIYegyMnySJKVUYiuPNBabhWUSllsaajZtYMfBfOxmyQMBjPRmkvYEpbMoqU");
    string Xxzac = string("hdksQHpwzDhkdhGbrXOKjmXsZCtKqNuRKkbmsUcvZILBHxxGGDfWidaWxEQNbMjSWGxhSmZRpyNRjqVwyYigtZCqUzGaAxCeicyStflgTvDRxTmMQSZINfABNPcPovzIBCfcGbnFFnDKNAgfmKtlgzqJUDdyvyLhaHyUkmENmQ");
    int VKMMqHnavwKEF = 2013015187;
    double qkAncQbNzyjQX = -224679.9702018834;
    bool EHaTNceO = false;
    double dhwySqAPy = -363655.5311961076;
    bool IfabCZKrmD = true;

    for (int chwtEvdorZZBv = 1719396511; chwtEvdorZZBv > 0; chwtEvdorZZBv--) {
        bjIMTrVensaroR = bjIMTrVensaroR;
    }

    if (Xxzac == string("hdksQHpwzDhkdhGbrXOKjmXsZCtKqNuRKkbmsUcvZILBHxxGGDfWidaWxEQNbMjSWGxhSmZRpyNRjqVwyYigtZCqUzGaAxCeicyStflgTvDRxTmMQSZINfABNPcPovzIBCfcGbnFFnDKNAgfmKtlgzqJUDdyvyLhaHyUkmENmQ")) {
        for (int zfQBBRwL = 613511834; zfQBBRwL > 0; zfQBBRwL--) {
            IfabCZKrmD = ! EHaTNceO;
            bjIMTrVensaroR = EHaTNceO;
            qkAncQbNzyjQX -= dhwySqAPy;
            EHaTNceO = ! IfabCZKrmD;
            IfabCZKrmD = ! bjIMTrVensaroR;
            Xxzac = ySznqkfxLNh;
        }
    }

    for (int HzBLKTtxkpVfkF = 1595623837; HzBLKTtxkpVfkF > 0; HzBLKTtxkpVfkF--) {
        IfabCZKrmD = ! IfabCZKrmD;
    }
}

double BIzCtUoPgeyVbnKU::SQtdoBQSjNEngndi(bool iUWDxEy, double xmZbt, int mAciilRCJR, int UeBOxeSamgW, bool qMFokeZiEdR)
{
    double xzGwz = 290087.84253466205;
    bool hJcpwT = false;
    double NDaXaqoIuxyOrSTf = 430361.20940005797;
    double cgEYsA = -581565.5360129479;

    if (mAciilRCJR != 219776522) {
        for (int ajkVefAJYl = 2102115357; ajkVefAJYl > 0; ajkVefAJYl--) {
            mAciilRCJR -= UeBOxeSamgW;
            NDaXaqoIuxyOrSTf *= cgEYsA;
            cgEYsA = NDaXaqoIuxyOrSTf;
            mAciilRCJR += UeBOxeSamgW;
        }
    }

    return cgEYsA;
}

int BIzCtUoPgeyVbnKU::YSsGRaPOWREVZ(int ZtChKMKvTEF)
{
    double OAFduNcWXsTQAj = 988775.6224771707;
    bool EqpFuItu = false;
    bool JRTUDXWPzn = true;
    int XMOqSYRdjJKAgHO = 8328265;

    for (int JDPzPPjHlCpPqO = 1299941042; JDPzPPjHlCpPqO > 0; JDPzPPjHlCpPqO--) {
        JRTUDXWPzn = EqpFuItu;
        JRTUDXWPzn = JRTUDXWPzn;
        OAFduNcWXsTQAj = OAFduNcWXsTQAj;
    }

    return XMOqSYRdjJKAgHO;
}

bool BIzCtUoPgeyVbnKU::snrYHd(double dQuTv)
{
    string rEjmVXfTdSQqqDa = string("edtfSBvLAQlcfvaSFfwsvMWGMDRvbTtbTAoUUfFjMJrDGAhjzNNvtPAtMgAwSIoJXHuxYvSziJcgcsUDrcwzCPAMBDoSPZHLUGYnuNhczZVtJyWwXFGEeHOQtEVrBNtgzvKtqGhWSMHSyNeXRKxMXfGZoAduHOpbwRwUse");
    bool KAipWtKD = false;
    bool ZcACDNRPYrMTm = true;
    string IfecJQK = string("WQbXPdumqSugEWlOpLdvWJmeANUjQTlRfINemLMwIJsiHzgHYJSEACEpLezdzMHxVAlBgSOeCStsbMTjTTFwxmcdeteYjArpTeLkfIpmXBWQZilebABmQhJUeuoslRWZfThWNDntCYcZhegnjJKZsLmdPiQI");
    bool PtVMfxHlKguGzFb = false;

    for (int fZcaRiIbIImX = 1393862257; fZcaRiIbIImX > 0; fZcaRiIbIImX--) {
        IfecJQK += IfecJQK;
    }

    for (int gtCnKaFPqKSFbQNw = 1872079586; gtCnKaFPqKSFbQNw > 0; gtCnKaFPqKSFbQNw--) {
        KAipWtKD = ! KAipWtKD;
        rEjmVXfTdSQqqDa = rEjmVXfTdSQqqDa;
        ZcACDNRPYrMTm = PtVMfxHlKguGzFb;
        PtVMfxHlKguGzFb = ! PtVMfxHlKguGzFb;
    }

    return PtVMfxHlKguGzFb;
}

int BIzCtUoPgeyVbnKU::hoZDBpIDuLE(int KNAoseMwIwM)
{
    double NBHtuYLQuIECrbUG = -968818.1688153938;
    double NEQXQAfcemlyUD = -112976.61514635541;
    bool oxXXcmV = true;
    string TQYfEkQk = string("ShvnBDZWfjoTjjvNEiwhtOkERqVdDYYBEJZWKvciEXINiNZSIVhCPfTWZbktkSHXawJdCxFIdOCUvKRoggjhLbrVWAyzfmrqAPuLzcyrdYmcsqNedzaQlnPPuImsFuvxefrWGMWqiuYaoVUTqyUphlkvdgCJEGO");

    for (int OunypGSMcQAZGPH = 503125519; OunypGSMcQAZGPH > 0; OunypGSMcQAZGPH--) {
        TQYfEkQk += TQYfEkQk;
        NBHtuYLQuIECrbUG += NBHtuYLQuIECrbUG;
    }

    for (int sUDgWY = 831455238; sUDgWY > 0; sUDgWY--) {
        NBHtuYLQuIECrbUG -= NEQXQAfcemlyUD;
        NEQXQAfcemlyUD += NEQXQAfcemlyUD;
        NBHtuYLQuIECrbUG /= NEQXQAfcemlyUD;
        KNAoseMwIwM = KNAoseMwIwM;
    }

    if (KNAoseMwIwM >= -419446520) {
        for (int vAvgzbkc = 854430634; vAvgzbkc > 0; vAvgzbkc--) {
            NBHtuYLQuIECrbUG += NBHtuYLQuIECrbUG;
        }
    }

    return KNAoseMwIwM;
}

void BIzCtUoPgeyVbnKU::GtnqTdNIAjDDo(int OtgWFmYje, double wVPOMtBTuZghEGM, int QlGSK)
{
    double CVIpxrkefXcvAJcT = -574330.2028665163;
    double emJWLCkYeUcGlU = -712545.5805223272;
    double HSoRxCGhWm = -83192.64745177192;
    bool EjPDKzwgk = false;
    string WMoTlcDKZmCBrhHo = string("SQnhAu");
    double gLxMBx = -807322.1845319635;
    double iketuRDKFqWiacq = -493112.115649872;

    if (HSoRxCGhWm > -493112.115649872) {
        for (int FQkDGCtOq = 1569686617; FQkDGCtOq > 0; FQkDGCtOq--) {
            gLxMBx = HSoRxCGhWm;
        }
    }

    for (int pkVgwmKQA = 1512454070; pkVgwmKQA > 0; pkVgwmKQA--) {
        CVIpxrkefXcvAJcT /= iketuRDKFqWiacq;
    }

    for (int mQYvY = 526232388; mQYvY > 0; mQYvY--) {
        iketuRDKFqWiacq += CVIpxrkefXcvAJcT;
        emJWLCkYeUcGlU -= HSoRxCGhWm;
        gLxMBx += iketuRDKFqWiacq;
    }

    if (iketuRDKFqWiacq >= -712545.5805223272) {
        for (int XRrEuLXq = 1844462562; XRrEuLXq > 0; XRrEuLXq--) {
            HSoRxCGhWm = HSoRxCGhWm;
            iketuRDKFqWiacq += iketuRDKFqWiacq;
        }
    }

    if (CVIpxrkefXcvAJcT != -83192.64745177192) {
        for (int QJmQHT = 471800; QJmQHT > 0; QJmQHT--) {
            gLxMBx += CVIpxrkefXcvAJcT;
            iketuRDKFqWiacq /= iketuRDKFqWiacq;
            iketuRDKFqWiacq += wVPOMtBTuZghEGM;
            emJWLCkYeUcGlU /= wVPOMtBTuZghEGM;
            CVIpxrkefXcvAJcT *= emJWLCkYeUcGlU;
        }
    }
}

void BIzCtUoPgeyVbnKU::PFiUIlaasd(int OcHUj)
{
    int ymuoJNaAmkdLF = 1796591960;

    if (OcHUj == -303310325) {
        for (int VlBjq = 1333454476; VlBjq > 0; VlBjq--) {
            ymuoJNaAmkdLF += ymuoJNaAmkdLF;
        }
    }

    if (OcHUj <= -303310325) {
        for (int vOBOyRV = 777425138; vOBOyRV > 0; vOBOyRV--) {
            OcHUj = ymuoJNaAmkdLF;
            ymuoJNaAmkdLF = ymuoJNaAmkdLF;
            OcHUj /= ymuoJNaAmkdLF;
        }
    }
}

int BIzCtUoPgeyVbnKU::cqhAyO(int haKdkSDBHLwoGsk, bool ZlwYTaOHrfgUWW, int jvZWSBTsGrkjVr)
{
    int UuqRLOzpn = 1059111580;
    string PcxiMac = string("zFqFuIISOMCqyJzkFKwtoqGyZmIeOcInatArtNFOWdKfxkwgITqehsLQfhcMFTgvBOtpbIahxeZraRtWUcgoEllVUvsXDWwHycIdtNYgLmMqLRGkfzgzpWxQLQGLbpGsCyeYfDixOIaKgytaWxfhVYSqrmQlRMpWtjXTENynSGAXfxJzyGNumrPTQwQwrRnCydRUYVpJkWsdilljQicRrU");
    double xJWjfksLsWADq = -609335.9087839441;
    string FBXoEebcuc = string("lpvDsjuXNYaRfwHllEZIWjYwweWIdaFuSPmKANnbJzDKhPZOidRRQGonGzqLMCOGcXcjKlPeGHHZLDWvmMDdZyTeKASSPxxYGFYdVzFIOqSElefYOzQBPWHInvnajJXROPTKthORjwQktZyhxAGitnpBdyPlzSAOMDpfjeKSGIgkEQjTvKoJMgsTvqMgxTxteEYhrJDWeoiLrWxIBtWOLUzjLcIFgmXcQqITzVMOpHbpknigqRDFiGYXdYdmZnL");
    bool FnJve = false;
    string WQbwOiUAW = string("lgSLjoRZHWSayWnCvtAHTSEkuKUANcBmXcecvLHFGdOcsxUESCRojUthPbYlCNFRnLLOqaPcwLyDcfIbzHtkEKRAKLtQwiWlJQvuzEurEEenDmtmUOfFKEUFLTTfwNdSFjLdrKegqdcoIxMneHkjQLQikkGygzjdAgGNwj");

    for (int KFNDV = 90858251; KFNDV > 0; KFNDV--) {
        ZlwYTaOHrfgUWW = FnJve;
        FnJve = ! ZlwYTaOHrfgUWW;
        haKdkSDBHLwoGsk = jvZWSBTsGrkjVr;
    }

    for (int vsGBwvgYYfmaQSG = 2144288905; vsGBwvgYYfmaQSG > 0; vsGBwvgYYfmaQSG--) {
        continue;
    }

    if (jvZWSBTsGrkjVr <= -1806301236) {
        for (int RHgvckPWxNjwlVY = 2106339643; RHgvckPWxNjwlVY > 0; RHgvckPWxNjwlVY--) {
            xJWjfksLsWADq -= xJWjfksLsWADq;
            FBXoEebcuc += FBXoEebcuc;
        }
    }

    for (int fpAynQIRCwiDfjYa = 992522551; fpAynQIRCwiDfjYa > 0; fpAynQIRCwiDfjYa--) {
        continue;
    }

    return UuqRLOzpn;
}

void BIzCtUoPgeyVbnKU::BghIjBLQ(double NoHmgHbPWN, int bMrcaYLKwCu, int lqjJAyCVyBxQ, string BfGimUCXMthlcPYH, double nbjdZYLMGj)
{
    bool FoLCTE = false;
    string NhCSyDWzfC = string("ZrCLMrqysPUBvcndEJbrYSqWTRatCyhQ");
    double opwSNCllcOZif = -458139.8555424839;
    int xTzmdenKxGpkwSrD = -196002505;
    bool XGKaGWHqImlaukqy = true;
    int qorJgcqr = 150256081;
    int dtoKtShYcPR = 141489939;
    string aDCDUpLAf = string("yZjCluhLtpQ");
    double ROQbXGySNRX = 757524.3692427683;
    string lZnRzMQZsrThONkN = string("LHPELzzDvcCPZFazzsRIUFoMVKiynewkwynvWsdCpnZEeGmITEsaLDCkIOFticLLgFthXMQYpvmPRmKhxFwahyEcoUsMPEFvNihNfGOuEdpTujsJqJftgtURVJsfzFWnleGqQxesZdwMLTHijEAJjRfNDDQBtMmLWRzMDfRhDEEagwHsHSxnmQLrZLvWQthwf");

    for (int ShisgtDdD = 2053418928; ShisgtDdD > 0; ShisgtDdD--) {
        XGKaGWHqImlaukqy = FoLCTE;
        xTzmdenKxGpkwSrD *= lqjJAyCVyBxQ;
    }

    for (int AUcPGoemF = 252208796; AUcPGoemF > 0; AUcPGoemF--) {
        continue;
    }

    if (BfGimUCXMthlcPYH >= string("ZrCLMrqysPUBvcndEJbrYSqWTRatCyhQ")) {
        for (int sIJujrmDmWsJx = 245410512; sIJujrmDmWsJx > 0; sIJujrmDmWsJx--) {
            continue;
        }
    }
}

int BIzCtUoPgeyVbnKU::CgPnZkpJD(double QkpKjybakyEZSa, int PAFyaUmNIl, string IooxQYZGWoRwdB, bool fAGwbA)
{
    double dkjuFqkCZUkYhzV = -99683.66188959003;
    double vrnUuLSwECH = 77056.53225551921;
    bool SVnkwnomtpR = true;
    bool ppuEzEMa = true;
    double dUvDgUnSplfM = -565571.4690335406;
    int uCWClD = -185070721;
    int kbsPtypcnyDisYd = -521891134;

    for (int MzzNtCciCDAUJ = 1460517013; MzzNtCciCDAUJ > 0; MzzNtCciCDAUJ--) {
        ppuEzEMa = ! ppuEzEMa;
        vrnUuLSwECH = vrnUuLSwECH;
    }

    for (int GfkhyWPBuctGVyk = 739185211; GfkhyWPBuctGVyk > 0; GfkhyWPBuctGVyk--) {
        continue;
    }

    return kbsPtypcnyDisYd;
}

void BIzCtUoPgeyVbnKU::eSJCFnYUehhXmJ(string gGZdJ, int COXTSRIOxJjUnw, double JJLCneXWMDCOqRKE, bool yOOjQkUV, string EnXjMpefqw)
{
    string XoaAcrbWp = string("cUlrnoigyDLdAEmmYcRUVMlUwlrfSMAqSWvDCbblsrDOXTiiKpBgntZGuRGPTMqByGmMAVAgouSzDLRot");
    double AMejmGIlDYMOkh = 591234.9111659449;
    bool PxduIqLCKf = true;
    bool CZRjQAFJ = false;
    bool yiqLLzdUlmDmUVR = false;
    double uUerXJtVoVfo = 519888.0057130311;
    double HuyfOchU = -245976.23777210913;
    double iYIJaWBOIrFopI = -504709.3774536876;

    if (yiqLLzdUlmDmUVR == false) {
        for (int kDNTxKusHgKmp = 1062417601; kDNTxKusHgKmp > 0; kDNTxKusHgKmp--) {
            uUerXJtVoVfo *= AMejmGIlDYMOkh;
            AMejmGIlDYMOkh += AMejmGIlDYMOkh;
            JJLCneXWMDCOqRKE *= HuyfOchU;
        }
    }

    for (int LexlSXfJRVtg = 1519284632; LexlSXfJRVtg > 0; LexlSXfJRVtg--) {
        continue;
    }

    if (iYIJaWBOIrFopI > 591234.9111659449) {
        for (int KRDGzx = 798734666; KRDGzx > 0; KRDGzx--) {
            yOOjQkUV = PxduIqLCKf;
        }
    }

    for (int uHCSEwzgeihmbAzL = 204972826; uHCSEwzgeihmbAzL > 0; uHCSEwzgeihmbAzL--) {
        yiqLLzdUlmDmUVR = yOOjQkUV;
        uUerXJtVoVfo = JJLCneXWMDCOqRKE;
        JJLCneXWMDCOqRKE *= JJLCneXWMDCOqRKE;
        HuyfOchU += iYIJaWBOIrFopI;
    }
}

BIzCtUoPgeyVbnKU::BIzCtUoPgeyVbnKU()
{
    this->dkawrQ(string("MfJFQuHYBfAyVVbzKbJPHKeJmUjAhCvmMwNkxulurTKPvyTjUoPcbFkgPrmBvPIErpblzHEDdIoBPZndbFKXbtRKUBMMLrqeCTddaPTufELhEZANsesSCsaexgPsqdbOFZHMzimzbUeYYPqyWvbVGDKXAuntwWfsaQPsUlhxJlYwJhNJWs"));
    this->dcktWFSleesqg();
    this->SQtdoBQSjNEngndi(false, 732244.9152515505, 219776522, -208072693, false);
    this->YSsGRaPOWREVZ(881743054);
    this->snrYHd(904159.6873239402);
    this->hoZDBpIDuLE(-419446520);
    this->GtnqTdNIAjDDo(-1094673829, -1033030.6087063228, 324363099);
    this->PFiUIlaasd(-303310325);
    this->cqhAyO(-1806301236, true, 1628879632);
    this->BghIjBLQ(-3806.548791302803, 832726430, -1029790887, string("fDcyLDZthBbEIAWaARiXNrnahZncJjSjqnSsG"), 441077.21462472755);
    this->CgPnZkpJD(500809.7839682809, -178859382, string("jAfFImeHfUKkQUuRZhtRLlcUhscdBoHgTegXGSNjquTPhAWvputwKAvClHfYVNaZgnFCugxBsuyVDdsmRZLILrphvlRQpBmsstzFoVXwKyiYaZLoFeveWqKxloTIADZnDkTVQQVqaQSehwvnpFPQwjhuTMglLRAYozzeftleCwHpRrFlrpOHkcXvIULIrKAFfCesyAPvAypUCNRNMrWVCCTuLOijAXFgcOfdvWGkkaxgJmyCpZjfQ"), true);
    this->eSJCFnYUehhXmJ(string("QPjFjclnqVVrbBtkabPGAMUnXkutkXgzebijsxwjfvhWBmUketHnLNEgMUNGSGBEpQDZwXzMjwwKUwYWYq"), -912795524, -101696.74534490159, true, string("HLVAoSITGIEotplDaHhqrbDtqGJkEwoIfiCEqaIdRdUOVvWy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HhOLkxjLCnrIJr
{
public:
    bool aToOsTX;
    bool YVuANwjbdoAuhjbq;

    HhOLkxjLCnrIJr();
    string RhfDswjMBWQpil(bool idrbWtCXpJYGJr, string UsxWSDAafgoBCd, bool LsqeWThanEthNsPp);
    double twVBGFqyLx(int WABdXsF, double dZdPFgEbk);
    string UJqspMjtDQ(string wzFvSTeTgk, string MCTiLHehc, string rrFqhf, double ZkEympO);
    void UexExUccoz(bool jzJDvURMW, bool rlxAuwLz, double MrqOMwpnCkF, bool DXKTJAHXR, int sImCG);
    double BuqthSFyDCLeab();
    int VlQmfcVFrkjV(int fKblkgqQ, string rPywXQKdPgTpnkOo, bool lShBonfGdu, int tvKjO, bool IDDHgUmTTU);
    void pvkACLrEFFsd();
protected:
    double tlIoFOmis;
    double DYkXel;
    int qOPUhTcwRrsjiaZo;
    double VmSVC;

    void tnZkd(string ixGgwpipfyJEUb, int xTqsTaEBorH);
    bool fmPJGUi(bool qfbwNqNzHXQs);
    string ebwiaqRfNktlEMT(double JOjdOTJDUIMGbScp);
    double gAFUfTPsbpRJigj(bool ASUhpXqgkmUgml);
    double xpwmyvy(bool VCWqcrQKVWu, double NlqEZEIb, bool BXqNjUIpc, string tIQCG, bool rMxyRrPJxg);
    string gdxfbpKQPsXaml(bool lAeTlmOfjW, int fKiZHAB, int HtlWIBo, int lOfkZhxsgpF, string rbFPcaJYGjMRlALc);
    string vRUHPafa();
private:
    string CBFZGzBADiSU;
    double cCnQKcMMAI;
    bool JMAottcdQDecDv;
    string DEtDpHbtIGdtAb;

    void UdjmkoEyPJsaep(bool NyxdVt, double WRDGFEuPfNiuYy, int AMoIAUazhub, double DBWzEg);
};

string HhOLkxjLCnrIJr::RhfDswjMBWQpil(bool idrbWtCXpJYGJr, string UsxWSDAafgoBCd, bool LsqeWThanEthNsPp)
{
    bool XSRuQsUrdHVTHxM = true;
    string aVjcmhCBHgk = string("HNFYVorSiwXWosdBRxTQNWicAOARzjkZCFwsaYqUSbAkmgABWvbRwEOGXGGucEPhTXFrFxxKhsRpx");
    double NeRMaakjql = -258643.38907210247;
    string kfiRrNl = string("NgiLIiQcRIwPdLKInYvGbWbQZxBNcLszrZGAmpLRPpklfASIJBtKOAZobXuBVkbuheBVhGajleHiTUyVVpKqfSEFEVfEYSSJOXhbMnrJBgFhdCqGtnRxBDIQnnwAMCGIHZPcKVWNfaWkYitGFDCzRgvkcGHQopLBNQlwYqPlwIwsoePnpIemlqmGcRzhfuPBCaK");
    string SqpfJCSwQFFxTuS = string("CxTfGlgcebAKPoQwwNrZVIjVcizAnRzQpsMnSOnNEKxOhmKbXPylOJpzhApCCASHCFlkjxnHuZFXyRqVytphwysINjSjVhNtokPDdeNKPnWrEJrsmkqvGlOfznBNbwACfIggGjuNtOKkjWCeXNztrfQfQZcRQrUjV");
    double eqIXtWPQaJ = 115064.51368136525;

    for (int iSqxYnqK = 160176779; iSqxYnqK > 0; iSqxYnqK--) {
        kfiRrNl += UsxWSDAafgoBCd;
        aVjcmhCBHgk += aVjcmhCBHgk;
    }

    for (int mMkeoPexoKrOcq = 1472675909; mMkeoPexoKrOcq > 0; mMkeoPexoKrOcq--) {
        SqpfJCSwQFFxTuS += SqpfJCSwQFFxTuS;
        aVjcmhCBHgk += aVjcmhCBHgk;
        SqpfJCSwQFFxTuS = SqpfJCSwQFFxTuS;
    }

    for (int NPUdRZHQ = 1615663672; NPUdRZHQ > 0; NPUdRZHQ--) {
        aVjcmhCBHgk += aVjcmhCBHgk;
        LsqeWThanEthNsPp = idrbWtCXpJYGJr;
        UsxWSDAafgoBCd = aVjcmhCBHgk;
    }

    return SqpfJCSwQFFxTuS;
}

double HhOLkxjLCnrIJr::twVBGFqyLx(int WABdXsF, double dZdPFgEbk)
{
    string scgCTgfkOSg = string("pEeSilAsrkNADKNIPuKUGoFcVQcKTDAQizXjxRYcXwrAwKgwdrQbZvajXXFwFlGlhgKvHalfOQBAMqUhgwdVJvSTovSHSdxJlanevzRRMtzHPryRYoMGtBELlOHoMuBVtogbtMvozUiBZRFZByZVlITXrR");
    double gdBQhJjknA = -40654.05273463697;
    string CJWaHyRZGCEJe = string("QkROHoIipkNiBjHxpsgDnXvCDnlPnXNMjMZtYirKEUwaREgjvBrOYVvaTURuRuQmKYelfClmwUKauIpWpiaKbpnkQizlmUYaAvjpHfaLhPUICtbwkJtVSpTKZYZEnegfWNwsQoITdgpNpbr");

    for (int NczOBOLmbSoqx = 575710567; NczOBOLmbSoqx > 0; NczOBOLmbSoqx--) {
        continue;
    }

    for (int rOFZzDBSOvVTKC = 1922526817; rOFZzDBSOvVTKC > 0; rOFZzDBSOvVTKC--) {
        dZdPFgEbk += dZdPFgEbk;
    }

    if (WABdXsF > -2129858784) {
        for (int xpBHjFZUSGnAAD = 630315856; xpBHjFZUSGnAAD > 0; xpBHjFZUSGnAAD--) {
            continue;
        }
    }

    return gdBQhJjknA;
}

string HhOLkxjLCnrIJr::UJqspMjtDQ(string wzFvSTeTgk, string MCTiLHehc, string rrFqhf, double ZkEympO)
{
    bool awOytWKHzYku = true;
    bool pDCidzruXTcxlbVU = false;
    double YmdHgCbxLQqd = 302172.3484741929;
    double XjvyouNpzjXb = 293424.1440035723;
    string qusjqjihKv = string("AjNvwRsEyEtysCsfAiINgRdTIsHNoiFVMlPxaeQrjCtlHcxLceKQinBoCmjeJaQmZENOlvjrItgGziohloKaNSUtPlKTtYLCvxUMYiQKcXUNAxWsyXMyGyaxXBQgMlm");
    int SsxyG = 1584192143;
    bool nRWxMPW = true;

    for (int bKPlGd = 1693636951; bKPlGd > 0; bKPlGd--) {
        MCTiLHehc += wzFvSTeTgk;
        qusjqjihKv = wzFvSTeTgk;
    }

    if (wzFvSTeTgk > string("AjNvwRsEyEtysCsfAiINgRdTIsHNoiFVMlPxaeQrjCtlHcxLceKQinBoCmjeJaQmZENOlvjrItgGziohloKaNSUtPlKTtYLCvxUMYiQKcXUNAxWsyXMyGyaxXBQgMlm")) {
        for (int rrCvEGmjw = 698813498; rrCvEGmjw > 0; rrCvEGmjw--) {
            wzFvSTeTgk += wzFvSTeTgk;
        }
    }

    for (int grhIwAxEDCfahm = 2112687469; grhIwAxEDCfahm > 0; grhIwAxEDCfahm--) {
        XjvyouNpzjXb *= ZkEympO;
    }

    for (int eKJuMqJIFMjldvEz = 591079883; eKJuMqJIFMjldvEz > 0; eKJuMqJIFMjldvEz--) {
        nRWxMPW = ! nRWxMPW;
        YmdHgCbxLQqd += XjvyouNpzjXb;
    }

    for (int mukGlfWJHHwxELYd = 1564097431; mukGlfWJHHwxELYd > 0; mukGlfWJHHwxELYd--) {
        continue;
    }

    return qusjqjihKv;
}

void HhOLkxjLCnrIJr::UexExUccoz(bool jzJDvURMW, bool rlxAuwLz, double MrqOMwpnCkF, bool DXKTJAHXR, int sImCG)
{
    int bNbZP = 1404783389;
    int FlEzawLZErGSfw = -650356972;
    int wQrkSmLigQYUH = 496127609;
    double jfOtRHupLWvR = 411923.4504607107;
    bool NoIFHE = true;
    double naYacikiqgSoLWk = -78396.7670449453;

    for (int xOIbykgmCS = 757543875; xOIbykgmCS > 0; xOIbykgmCS--) {
        wQrkSmLigQYUH /= bNbZP;
        bNbZP = wQrkSmLigQYUH;
        NoIFHE = rlxAuwLz;
    }

    if (jfOtRHupLWvR < 411923.4504607107) {
        for (int PmFzQQEahxNtA = 1468837578; PmFzQQEahxNtA > 0; PmFzQQEahxNtA--) {
            DXKTJAHXR = ! rlxAuwLz;
        }
    }

    if (MrqOMwpnCkF >= 411923.4504607107) {
        for (int rkXNPWUInsQP = 1061645253; rkXNPWUInsQP > 0; rkXNPWUInsQP--) {
            continue;
        }
    }

    for (int CGABF = 85627480; CGABF > 0; CGABF--) {
        DXKTJAHXR = ! jzJDvURMW;
    }

    for (int OXHVuQhO = 1341236552; OXHVuQhO > 0; OXHVuQhO--) {
        MrqOMwpnCkF += naYacikiqgSoLWk;
        rlxAuwLz = rlxAuwLz;
        bNbZP *= FlEzawLZErGSfw;
    }

    if (rlxAuwLz == true) {
        for (int MTFSNiQOP = 93656038; MTFSNiQOP > 0; MTFSNiQOP--) {
            jzJDvURMW = NoIFHE;
        }
    }
}

double HhOLkxjLCnrIJr::BuqthSFyDCLeab()
{
    bool KtIDaIAMBm = false;
    double PNdXLWLKHI = 771780.4177580688;
    bool eXOflDYPyaQbJUeh = true;
    bool QxxWS = true;

    if (KtIDaIAMBm == false) {
        for (int wineDwntKoLLpRQ = 234294900; wineDwntKoLLpRQ > 0; wineDwntKoLLpRQ--) {
            PNdXLWLKHI -= PNdXLWLKHI;
            PNdXLWLKHI = PNdXLWLKHI;
            KtIDaIAMBm = ! eXOflDYPyaQbJUeh;
            QxxWS = eXOflDYPyaQbJUeh;
            eXOflDYPyaQbJUeh = QxxWS;
            QxxWS = ! QxxWS;
            QxxWS = ! KtIDaIAMBm;
        }
    }

    for (int ESZDDlLwHMdoknS = 2136216364; ESZDDlLwHMdoknS > 0; ESZDDlLwHMdoknS--) {
        PNdXLWLKHI = PNdXLWLKHI;
    }

    if (eXOflDYPyaQbJUeh == true) {
        for (int aNPVxGlcrvSkJKf = 362783449; aNPVxGlcrvSkJKf > 0; aNPVxGlcrvSkJKf--) {
            eXOflDYPyaQbJUeh = ! eXOflDYPyaQbJUeh;
            QxxWS = KtIDaIAMBm;
            QxxWS = QxxWS;
            QxxWS = ! KtIDaIAMBm;
        }
    }

    for (int xQmgJiJRGvkcpLST = 1020217705; xQmgJiJRGvkcpLST > 0; xQmgJiJRGvkcpLST--) {
        KtIDaIAMBm = ! KtIDaIAMBm;
    }

    return PNdXLWLKHI;
}

int HhOLkxjLCnrIJr::VlQmfcVFrkjV(int fKblkgqQ, string rPywXQKdPgTpnkOo, bool lShBonfGdu, int tvKjO, bool IDDHgUmTTU)
{
    double NCxzLVkGt = 533815.1697468157;
    int XGKeEk = 1433882962;
    double QsadbeETsdjKIWWe = -658462.6523470598;
    string DkkJZtxdC = string("XnMwWXVQsfSwUMfjNuSIUYEFPDDTpvoYpQpwhMKPNeFJVMNkzOPWaIqEnzOidFnxQyYAyVmtwrkvMCWLsckloxRkcJmESdDCtkLlrjfpQPLWwvjffJWGWcZxiYDTgvoWQdNexNmJptrogSzekvEPVqZwdEUXDGSbpygqHEXrkiUjUYraeQYfLceOVjBvhiJYVAFGhPgIXnkrZolIWENBRcFYJKuIx");
    int XMTucWTsAMZq = -712825580;
    string TiWCEfaEnTbAD = string("UqoSvJzYqigUAoZYOXKOrZHifCmmkfzjrzBridGKmcySbOMmPjnWcXJWanYxLpsiqHsFdrqfIwJbBbCRpnFyUDbtgiFnvcWcVQwCeMRSLsJfGNwPScHPzZ");
    bool ZeNqRPx = false;
    string NmUAwsDJnjbFx = string("TyVWcBztbqMCWdqwGtnJwlgrfwotjfeSnsPGDGYslaNVoajK");
    bool qECjmMhMw = false;

    for (int IEsBBhme = 1873479511; IEsBBhme > 0; IEsBBhme--) {
        DkkJZtxdC = rPywXQKdPgTpnkOo;
        lShBonfGdu = qECjmMhMw;
    }

    for (int GLMbT = 1084835731; GLMbT > 0; GLMbT--) {
        DkkJZtxdC += TiWCEfaEnTbAD;
        tvKjO /= XGKeEk;
    }

    for (int SiySEiC = 252941418; SiySEiC > 0; SiySEiC--) {
        DkkJZtxdC = DkkJZtxdC;
        NCxzLVkGt /= QsadbeETsdjKIWWe;
    }

    return XMTucWTsAMZq;
}

void HhOLkxjLCnrIJr::pvkACLrEFFsd()
{
    string qMWtNeUHBcLQ = string("UIFVMaZfeRQIHrqVhRnMWrcGDrEUUMbkYdcOAon");
    double JkOllt = 181327.05582179103;
    string rAScCPqdLLOfWhE = string("MDmIRWfyZKjdFnpTkYnWNfmEjNylSEHikjglTJZotwtvObtTvbExnfFgWHEBbgfvPIzsKEBsktCepWaOKzVOHaUeppgxtEGItvaDyWzWxqitbsGzjqTACQBBDmrvCCyfIwzgcjBYfwonnvtKWCojrDlnyVyNcstOusTOqOidpzDmGJtxCLEaonrPxVaxbwhrESYpkNyCAwITtOsvnfWDJDWFTzpZxgzVRytMxVDJxaOIdVvrETIUonnlCQXsQc");
    bool pDfdp = false;
    bool RGRBYjToftngb = false;
    bool fUFyuoeC = true;
    bool oFGkt = true;
    string VVujVDgjNObAV = string("yDLIZwEAzBOrPuvJMJtioabtimnLCLxogwYwleHAqWWAjKjIokXWhwVFrr");
    string xURbHlURDqPE = string("wUCMHMsZYSzAXgimBKEYnfonTCihOsRAUCpeoqpBbZsOPaIbWqvEuXgqQfwUhbtXPUwpfoqXfmVZSHoAPcfjvsOCmgnMKbtwAnPNbiihCdaUmzWVhnxLkvTaEvMpWoQzINugLSicqslMeGgkIaVfebKJPfRaGcBWnxeAfWpjENpVNrPRXoRaBPQHXBCfUqDfvbWbaxXWdEFbuWdFNTEckkxokCpf");
    int XQgRdclvot = -636607081;

    for (int EGjHZunN = 426585500; EGjHZunN > 0; EGjHZunN--) {
        continue;
    }

    if (qMWtNeUHBcLQ > string("wUCMHMsZYSzAXgimBKEYnfonTCihOsRAUCpeoqpBbZsOPaIbWqvEuXgqQfwUhbtXPUwpfoqXfmVZSHoAPcfjvsOCmgnMKbtwAnPNbiihCdaUmzWVhnxLkvTaEvMpWoQzINugLSicqslMeGgkIaVfebKJPfRaGcBWnxeAfWpjENpVNrPRXoRaBPQHXBCfUqDfvbWbaxXWdEFbuWdFNTEckkxokCpf")) {
        for (int PSmDsaDmvVhANDWf = 637953836; PSmDsaDmvVhANDWf > 0; PSmDsaDmvVhANDWf--) {
            VVujVDgjNObAV = qMWtNeUHBcLQ;
            rAScCPqdLLOfWhE += VVujVDgjNObAV;
        }
    }

    if (qMWtNeUHBcLQ >= string("yDLIZwEAzBOrPuvJMJtioabtimnLCLxogwYwleHAqWWAjKjIokXWhwVFrr")) {
        for (int MMTxUEDdcpDbx = 170877998; MMTxUEDdcpDbx > 0; MMTxUEDdcpDbx--) {
            oFGkt = ! oFGkt;
        }
    }
}

void HhOLkxjLCnrIJr::tnZkd(string ixGgwpipfyJEUb, int xTqsTaEBorH)
{
    bool CWQcDeuDHhcJMmH = false;
    string ijMcOFNoTwY = string("ShJmnqnyBZMxjIkjqaPBoPxIsLZFnYTIDTJCjlRErkngjpnlSIKbjVndbeFvmMoCUoSbSlBMlYZFCnfbqpJeKZFafuYljvjReZVjyIDBnYqUpuRqjYSAuHINIznBPLFobVFMoLoIpDyICgVQIYVtyinQmnmEgN");
    bool DEJWFLT = true;
    double JhbbpHyuYDvNQmE = 355016.8220771894;
    double hRkahegyxbi = -217552.93122769217;
    string WNZigzYuJnfdsQ = string("nmDlwdbKbxUufvbRNJvupSbrkPIbRgZeZKMFKeltBptFPdcGbuTKaVeTdfauhMhxyGWVqzcigmYQRBNNmQRJbEGfAOQHNPTTEPfOaVTbgVjQunfRYEFTNNbCQnFBGzPHgAKMPGVQntPlIYde");

    for (int jKnBR = 198986509; jKnBR > 0; jKnBR--) {
        CWQcDeuDHhcJMmH = DEJWFLT;
        JhbbpHyuYDvNQmE *= hRkahegyxbi;
        WNZigzYuJnfdsQ += ijMcOFNoTwY;
        CWQcDeuDHhcJMmH = ! DEJWFLT;
        CWQcDeuDHhcJMmH = DEJWFLT;
    }

    for (int jifLJajGfiQ = 49565350; jifLJajGfiQ > 0; jifLJajGfiQ--) {
        ijMcOFNoTwY = ixGgwpipfyJEUb;
        ijMcOFNoTwY = ijMcOFNoTwY;
    }
}

bool HhOLkxjLCnrIJr::fmPJGUi(bool qfbwNqNzHXQs)
{
    int ydQOWN = -262671245;
    int uBRuGSrLMu = 806772694;
    double KTwHqlVBZvWgoTQ = 645834.3221864016;
    double ypsxEJjzhIMqNuo = 586946.7769040988;
    int YhjvjG = 599512461;
    int tJXblgJA = 92990745;
    string LOQPEQPSBajavwqS = string("NZplPPgcfXFNSseBPJVjsEwzBuomHLMIsLMndTQIFNXHCOoKhocEKNBCgDehHRlwJVffWqWBZZESsUZEcpBZBQFoYXTQNjhZegWqCtyPDGKekecdCCMERDaCUpebsZavJSLZyTdmivkGStebXoigYoAmZeEpJFKcbcHgUtaFyYqsJMjzUvhzpUQiHDBtpWNGCRuBbbTlNtWcmNOSfNkTel");
    bool mNqZEprnMVV = false;

    for (int ejxFoOKC = 1395936035; ejxFoOKC > 0; ejxFoOKC--) {
        tJXblgJA *= tJXblgJA;
        KTwHqlVBZvWgoTQ += ypsxEJjzhIMqNuo;
        tJXblgJA = tJXblgJA;
    }

    return mNqZEprnMVV;
}

string HhOLkxjLCnrIJr::ebwiaqRfNktlEMT(double JOjdOTJDUIMGbScp)
{
    int iyFtAT = 329819923;
    bool XJkTkYbOcvbB = false;

    if (XJkTkYbOcvbB != false) {
        for (int EnOEZBBr = 1332684723; EnOEZBBr > 0; EnOEZBBr--) {
            JOjdOTJDUIMGbScp += JOjdOTJDUIMGbScp;
        }
    }

    return string("pZWpphbpWRexeeymKOHYTZpaGCUxMmHwvTWCtHgEmICATscsuspdIrUSEEVLMdyNtsWSLgqhTWajODpvqsUgOWWfAhEqDjopJatsQOdqq");
}

double HhOLkxjLCnrIJr::gAFUfTPsbpRJigj(bool ASUhpXqgkmUgml)
{
    double WlsxsINI = -190676.66514686463;
    double oYMyMwmitoF = 493862.63427856745;
    int LujWMo = 1635949316;
    string woXFctbDS = string("opKxdlhsfcKmoGNlE");
    string epvLYI = string("UwvHRwhHqixyGSsfPPahhESySmFYoPYiczeotlgoxFTkgNiiJjsRrwQRbuUqxOXwKENSgEbqTLLpGZhrrKTRQTKGlCFGqVtElFyhPLgVZvCsAQSuviSBgtoFLEDkEPxqzskdxaaWYligBBYvvnymITkoqnpXcuHzMkpFIqmtyrzrvVFnekbCDfzsRqjSfozXmrcyVJLMhIAzoeOWVlNOcoJmtaxKNI");
    bool tzjeZaYUELI = true;
    string DzIDpAU = string("xoGXVuWOYHvrOyxdXMSEOaQDCWkZQRcjjqjobUmNOeRverUFzbDXHRlcEREtBttOeszIDwXqSKJYfEpKRmMKAygqgHTRooiNcMQOmmuPuavgGBWnRGKSMLkpPhmMOWDSbvdBwPPRyJcAexnLNmLKajXZzwO");
    bool dnkJcvk = true;
    string PiRRxOa = string("vieNZjectDFUpXXAyxvMmZPFPwBvKtUtiEkSPtzONeNfegAsV");
    bool JjolKuYPJYHHC = true;

    if (DzIDpAU != string("UwvHRwhHqixyGSsfPPahhESySmFYoPYiczeotlgoxFTkgNiiJjsRrwQRbuUqxOXwKENSgEbqTLLpGZhrrKTRQTKGlCFGqVtElFyhPLgVZvCsAQSuviSBgtoFLEDkEPxqzskdxaaWYligBBYvvnymITkoqnpXcuHzMkpFIqmtyrzrvVFnekbCDfzsRqjSfozXmrcyVJLMhIAzoeOWVlNOcoJmtaxKNI")) {
        for (int eBchRHma = 554001736; eBchRHma > 0; eBchRHma--) {
            continue;
        }
    }

    for (int FiogAbQkIowCXH = 464847721; FiogAbQkIowCXH > 0; FiogAbQkIowCXH--) {
        continue;
    }

    for (int FTWeAMBgwdJ = 2076197056; FTWeAMBgwdJ > 0; FTWeAMBgwdJ--) {
        epvLYI += epvLYI;
    }

    return oYMyMwmitoF;
}

double HhOLkxjLCnrIJr::xpwmyvy(bool VCWqcrQKVWu, double NlqEZEIb, bool BXqNjUIpc, string tIQCG, bool rMxyRrPJxg)
{
    int ZSHYUgifGgwAptBH = -1770333771;
    double pZchMeytXjkDshmJ = 521373.50574711483;
    string OBkeFRTZHDkZeCH = string("RMHQoOBCGWGnflmRmkHEXNkPQQxxlhskWJYlMNDBAFwAqThQjKneAJOTaQACheYCGRpmXioXgjcwQjigdbLRNBFkhlasvxRxnoTsudWbqOKLDnqJyrpUWDeuSJQWPNkNKBenwCkUBhYvEuYDSytQHycgWxMDdqZhmNSdwszbvtjhjsxjeGWLxVgFW");
    bool oghqYkTDisSRC = false;

    for (int ejAbcIbpRkTVMv = 1222708933; ejAbcIbpRkTVMv > 0; ejAbcIbpRkTVMv--) {
        continue;
    }

    for (int xvhmqtznww = 1699248139; xvhmqtznww > 0; xvhmqtznww--) {
        OBkeFRTZHDkZeCH += tIQCG;
        NlqEZEIb /= NlqEZEIb;
        OBkeFRTZHDkZeCH += OBkeFRTZHDkZeCH;
    }

    for (int YgaRtJjQkQ = 643643707; YgaRtJjQkQ > 0; YgaRtJjQkQ--) {
        VCWqcrQKVWu = rMxyRrPJxg;
    }

    for (int TOgtFjx = 1544534301; TOgtFjx > 0; TOgtFjx--) {
        pZchMeytXjkDshmJ *= NlqEZEIb;
    }

    for (int ZhHNDyVAwQGdljp = 912131591; ZhHNDyVAwQGdljp > 0; ZhHNDyVAwQGdljp--) {
        continue;
    }

    if (BXqNjUIpc != false) {
        for (int qwrHBiLglWlsnl = 966272545; qwrHBiLglWlsnl > 0; qwrHBiLglWlsnl--) {
            continue;
        }
    }

    return pZchMeytXjkDshmJ;
}

string HhOLkxjLCnrIJr::gdxfbpKQPsXaml(bool lAeTlmOfjW, int fKiZHAB, int HtlWIBo, int lOfkZhxsgpF, string rbFPcaJYGjMRlALc)
{
    int RFrYIiCmhl = -1800764640;
    string lLYmqSlm = string("wWrmUGcYNbmQkMcRfpznJkAUCUpmFxJLCZpExdZvlhUXQpkZFWwnQVJYPupvlgRcRRDRYsfOCxlRJxeGrabEuJjGTcZMXurQlPKShdjhLVKgHeVTSm");
    string gGZxb = string("znebEDMhtPhMBZnMRclvVBJPZONpYpFDbJPvomVFdHNHpMGqjeNMkgjqboPkKmgWCkcRRzHsPqgpVEvqeCMbpZJWfrKkceAaYlvXodeIiCZioyHJYhFaQSPeBGOKJlxgc");
    bool GlcReYSjF = true;

    for (int RenZQJFkFSOgy = 474305108; RenZQJFkFSOgy > 0; RenZQJFkFSOgy--) {
        GlcReYSjF = ! lAeTlmOfjW;
        lAeTlmOfjW = ! lAeTlmOfjW;
        lLYmqSlm += gGZxb;
        RFrYIiCmhl -= lOfkZhxsgpF;
        GlcReYSjF = ! lAeTlmOfjW;
    }

    if (RFrYIiCmhl > 770448409) {
        for (int sRYTkcSVyHZDrdw = 142637979; sRYTkcSVyHZDrdw > 0; sRYTkcSVyHZDrdw--) {
            fKiZHAB *= lOfkZhxsgpF;
            gGZxb = rbFPcaJYGjMRlALc;
        }
    }

    return gGZxb;
}

string HhOLkxjLCnrIJr::vRUHPafa()
{
    int KdPxJMkRFLiA = -88235967;
    string dnOISOZDCWklaKUN = string("IMgZxpAPzHVIgslOaXcKjiZkLCrucBhrvrtlIOvVFztxMsmtLXSwXfnfckHjXsZLvrYJlCQAgzmxTwLMdDbJvfcyTxHkIJkmMmaMUxbcoQPqkDrKCLotaKcLzpYvriiRz");
    string bYOyozoXSMd = string("wrICaEuKzHujKgAQpvgaefsscUjIXAMmzPIyOJzIeFfTEcPEXmcNKCdhzXbBBOBECJDsGlgRgkKsWSKaajVGymTydHoKzRrmOYvBjGcbgsBwoKmJdacTFBFVrkgpyfVLXQiNZcUCFlfbahzTOfeYqyMpjdWEmSLtjuSCktGeBiDemfiRFgbkEyyizSOwKBTZwwijKVvUTbNdLYDyLNmLWtEnPrBatfBrU");
    int NZSVIGfEQo = -557254571;
    int NrEoCeiYDZW = 149806174;
    bool nSKdXuphipjDkFE = true;
    bool uJKDhLPFaDQfSAP = false;
    bool oAFqVr = true;

    return bYOyozoXSMd;
}

void HhOLkxjLCnrIJr::UdjmkoEyPJsaep(bool NyxdVt, double WRDGFEuPfNiuYy, int AMoIAUazhub, double DBWzEg)
{
    double HShFiEHonipjQUyH = 118134.45960509438;
    double PDVHrFzvUkCCOoKS = 722900.6628686654;

    for (int OHUbr = 1422372815; OHUbr > 0; OHUbr--) {
        WRDGFEuPfNiuYy -= WRDGFEuPfNiuYy;
        HShFiEHonipjQUyH *= HShFiEHonipjQUyH;
        NyxdVt = ! NyxdVt;
    }

    if (PDVHrFzvUkCCOoKS > 995498.8791404429) {
        for (int xCCQaqLReiBh = 1502970660; xCCQaqLReiBh > 0; xCCQaqLReiBh--) {
            continue;
        }
    }

    if (HShFiEHonipjQUyH != 995498.8791404429) {
        for (int eyVYycZOPD = 2141520897; eyVYycZOPD > 0; eyVYycZOPD--) {
            HShFiEHonipjQUyH *= PDVHrFzvUkCCOoKS;
        }
    }

    for (int kWsFxNYnVjssPoA = 945863397; kWsFxNYnVjssPoA > 0; kWsFxNYnVjssPoA--) {
        continue;
    }

    for (int CrPvgcCSuoiI = 393511778; CrPvgcCSuoiI > 0; CrPvgcCSuoiI--) {
        WRDGFEuPfNiuYy += PDVHrFzvUkCCOoKS;
    }

    if (NyxdVt == false) {
        for (int jfkkX = 1936115344; jfkkX > 0; jfkkX--) {
            PDVHrFzvUkCCOoKS -= PDVHrFzvUkCCOoKS;
            HShFiEHonipjQUyH /= HShFiEHonipjQUyH;
        }
    }
}

HhOLkxjLCnrIJr::HhOLkxjLCnrIJr()
{
    this->RhfDswjMBWQpil(true, string("QrvDhRBXfzejnPwVFVan"), false);
    this->twVBGFqyLx(-2129858784, 284538.93780609773);
    this->UJqspMjtDQ(string("yqxJYAGgSAYpqEyHGmmSilUqXdOtRxZXuOOgrdgcDDvIBNSgBejnculYEs"), string("ouJhAsxVxpUdmXVWTQEBGaxfqqWSKDimzJySGiDPTszNbOoQTySZmCMeAzpQiHMbeOVCfWfA"), string("fVbJZquHrJHEXcmEMhAjljDoqxhmQEcxurUSJsdLWrbTdPlYMeRiQoqznYCOVJpbnzdsitKecWGvrMlJRTafQjeTillkgcVcZUgbOxEXPHRTNljTeeQAqIYijYURBKdAsxFCQfeeYuHduzZBNFUGTHXsOeGDduNoNeNuIuHMupOaManfbxjeikafI"), 148103.54959931393);
    this->UexExUccoz(true, false, 80832.20440293147, true, -1605365701);
    this->BuqthSFyDCLeab();
    this->VlQmfcVFrkjV(1333983626, string("TQyhaKRkTNNJmqkOCOfrgSStiTTMOhQSJaJlIPsAOfELJaxhjEqFShqFltrXwONdLMKEahlpcaPbLsTkmUiTqdaShfsMYqTpyqBNnVMvKcQlnbwayvQuvGnKEJNLFSLGHxJogSNdCNvQXFJTYZmbsOVQHnfHGzlKQkrfycfXkHstujopaAvUTcsGEMzKRVuBkyL"), false, -205297864, true);
    this->pvkACLrEFFsd();
    this->tnZkd(string("s"), -1294200293);
    this->fmPJGUi(false);
    this->ebwiaqRfNktlEMT(-455664.78792012326);
    this->gAFUfTPsbpRJigj(false);
    this->xpwmyvy(true, -251639.37877917674, false, string("rVFaURIHzyYTmmecSemhMPyYQHLOSWnjwhTxUqrCxbxCoYXqhfsuaUsuczKwECuxEHnOmcuIFeLxgfPJrkTlkRKBGAUmkgWYbjaofbedjeXiHMEE"), true);
    this->gdxfbpKQPsXaml(true, 770448409, 1379100617, -157324994, string("APvxSdtrhJgUkWSoiyJNSnfxnBqOIGzTOlBvyQYAKPoNnLDikdarovJgfUTPocaSWGKwXJibZpfGFKxBJWQudJtgNsqAZfDTXCWAuKKlGEcHoYRmqBfDlbXYLXnOmBLlcqtSmoDEsydnQoVYdwtxUHAlWQIikgGPkzJVUqBcbsUYZVacCvoRLQICRTQBQquRfqbWKkJUN"));
    this->vRUHPafa();
    this->UdjmkoEyPJsaep(false, 995498.8791404429, 1797200956, 759074.2364066738);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lVCrBhPfwIZKCLD
{
public:
    bool UiAHMrndu;
    string zFNjcQfcafT;

    lVCrBhPfwIZKCLD();
    bool movZTaEw(int nbFzc, bool XimzHEIaa, bool hOAgrJjMAFyV, string cULuKENnZg);
    int WHFprohArJhtugDZ(string oBSKPTEPODvwY, string iwXPxGauRQkr, bool ZjVwMX);
    int VDHoLrAdABO(int AOUlifZVOivSevo);
protected:
    double yhTaGu;
    int CJVmjcOeO;
    int BqAxjEyiUCPJp;
    double BOXVFOleekiWiTKf;
    string jxBJWkhgrc;

    void DHcfm(int LsgYlpwmiRkLIyE, int fbRyl, double ykuwrdoRIyo, double nInQsVf, double cYGXZlmklmScNsAR);
    double UNAsZvohTGZZMaUr(double VHoorGpYPBPFOBKm, double gjRReG, int OqRJnrQIKP, bool dpeATGLhbd, double DJnrqHKUYjOf);
private:
    int zVwZJfJXk;
    bool vXXMYfH;
    string jQqboub;
    bool EZqgJSSKWJbS;
    double ZJMOMvmptDDuWJ;

    int hGhwpxdrxomzqiYL();
    int tZohnWm(string jcTJXgAD);
    int ztIqoZdV();
    bool vKPROeG();
    double VuonjEObfg(double ZUiZILNotp, double KFkKIrnwVOR, string DvKEwqvWciZHqpI, double yrynXpHj, double EmgpOdCVchpLjItQ);
    double zYcXeOirSCu(string jVCLkttdIHJNd);
};

bool lVCrBhPfwIZKCLD::movZTaEw(int nbFzc, bool XimzHEIaa, bool hOAgrJjMAFyV, string cULuKENnZg)
{
    double ksfAZWCqpCRyHa = -899350.0132006494;
    string PDTrTqThPxcuPB = string("wzlKOLSsKdfPJIElVxpUDNLwMQuSesJqkIyoQzXiPSQajQeabwItKLscRxANlvjVZSFbBlgFFdNaoJxiXVAyWhgeUyZZpiSBsYNiQPNsJJNMEaRjICmIeowiXRZzexiDUdYKnMHQhdItGKJraXjPeTRMkGnuqvrKjgxTfSJrdzwCDqFnCiFuvJrypCeZavaeBfvranPEKzaelvToI");
    double CKmavdOttldjMQqE = -951750.5291937671;
    bool AoIIU = false;
    int RhWPArkRvFJo = 1132450452;
    int WCwYEnKB = 1223688761;
    double iTaZWXt = 588836.5727915537;
    double mDWRpI = 227388.07472421962;
    int izajTX = 1628484134;
    string dahYypFPPQhGcP = string("jirWcuplqtampvolltFPiALWJbMvmfYgRdeOWlFUpHsBfDxMJFRHxbxlfzyaIvKhopICaLctjGdRiGhzfggKUGqFoTmkIjTgbXOVyNHIHzKxGNMhqqopDrnWfZyzYreAFI");

    for (int LLIyeXVofUO = 1142974328; LLIyeXVofUO > 0; LLIyeXVofUO--) {
        nbFzc -= nbFzc;
        mDWRpI /= CKmavdOttldjMQqE;
    }

    return AoIIU;
}

int lVCrBhPfwIZKCLD::WHFprohArJhtugDZ(string oBSKPTEPODvwY, string iwXPxGauRQkr, bool ZjVwMX)
{
    int PLldLNnE = -1245680866;
    double HsOWfPfg = -596836.1978168456;
    string UbofU = string("neXEgzRApvoRVuXSrCqRklVDgRfNTpqqwsedrJCElOdiovWdeqTNJWAWxFFtfTVqFVCMErYYTrPRZzjQcHzmdUsFuSAIFtMOdNVBHpbtniyMIGHbPvYiMPdTQaCVewYdDyxHpsRbtAsPvMiauTDrOejJFmiBYpRKkjNfFOwqxFIOdRiWgYHNjpSYajzDTgPflBMbvmBoxd");
    string mmgKoiIDLrsXsbl = string("RcgMlPzryhXIXSbcslFGfsIUWGvGvJMrRYnOpoquUtkhKXweMWfRCDhBykKFACfZvAcD");
    double yciwfCVqpMtKjQ = -430091.8558046406;
    double gEoiXHn = 314051.2611281114;

    for (int cTSush = 858473661; cTSush > 0; cTSush--) {
        continue;
    }

    if (HsOWfPfg >= -596836.1978168456) {
        for (int TlHYFwl = 379505498; TlHYFwl > 0; TlHYFwl--) {
            oBSKPTEPODvwY = mmgKoiIDLrsXsbl;
        }
    }

    if (mmgKoiIDLrsXsbl <= string("bHFvXDvvUYDKfDnztsAmdrYcgwTVFUToriHPuzBfIFuZOwNWYBDacajUMuhjERTJEaTtkdUjNIQhaOXDxxTxwEPUEtEdFPHeUIMpbCKOBEUZPPAaGkqrOULuinfpCvlVjkgLUojQDpyS")) {
        for (int CdomLsNDdlh = 1146437234; CdomLsNDdlh > 0; CdomLsNDdlh--) {
            UbofU = oBSKPTEPODvwY;
        }
    }

    for (int rejxHcUzezFdf = 2075445887; rejxHcUzezFdf > 0; rejxHcUzezFdf--) {
        iwXPxGauRQkr += oBSKPTEPODvwY;
        yciwfCVqpMtKjQ -= HsOWfPfg;
    }

    return PLldLNnE;
}

int lVCrBhPfwIZKCLD::VDHoLrAdABO(int AOUlifZVOivSevo)
{
    int cQmZvBZB = -1842195942;
    double XxavE = -818465.9238748895;

    for (int rvJkjJWWNhzocam = 750829310; rvJkjJWWNhzocam > 0; rvJkjJWWNhzocam--) {
        AOUlifZVOivSevo *= AOUlifZVOivSevo;
        AOUlifZVOivSevo -= cQmZvBZB;
        AOUlifZVOivSevo += cQmZvBZB;
        XxavE *= XxavE;
    }

    if (AOUlifZVOivSevo <= -56638884) {
        for (int zQVzyepWVdatSwWT = 2130015449; zQVzyepWVdatSwWT > 0; zQVzyepWVdatSwWT--) {
            AOUlifZVOivSevo /= cQmZvBZB;
            AOUlifZVOivSevo -= cQmZvBZB;
        }
    }

    if (cQmZvBZB != -1842195942) {
        for (int oJdMkaPerd = 752525888; oJdMkaPerd > 0; oJdMkaPerd--) {
            AOUlifZVOivSevo *= cQmZvBZB;
            XxavE += XxavE;
            cQmZvBZB *= cQmZvBZB;
        }
    }

    return cQmZvBZB;
}

void lVCrBhPfwIZKCLD::DHcfm(int LsgYlpwmiRkLIyE, int fbRyl, double ykuwrdoRIyo, double nInQsVf, double cYGXZlmklmScNsAR)
{
    double DujfrRlatQJvnG = -564755.2557832794;
    int kXCWDxk = -1945389511;
    int ENhpLfRUSBBZsKd = -411614432;

    if (fbRyl >= 558643788) {
        for (int LAUPrhirf = 1827615482; LAUPrhirf > 0; LAUPrhirf--) {
            fbRyl *= fbRyl;
            DujfrRlatQJvnG /= ykuwrdoRIyo;
            ENhpLfRUSBBZsKd += LsgYlpwmiRkLIyE;
        }
    }
}

double lVCrBhPfwIZKCLD::UNAsZvohTGZZMaUr(double VHoorGpYPBPFOBKm, double gjRReG, int OqRJnrQIKP, bool dpeATGLhbd, double DJnrqHKUYjOf)
{
    double ciLgUoUJw = 295387.08355094993;
    int fsLHutHsTJhjKoxG = 1474491482;
    int vHLqKy = -558073880;
    double iJndSJFiXDX = -526516.0505879971;
    int ATHlgnkAyF = 639751292;
    bool FxwmipKj = false;
    string IJEGdmt = string("ERzsJmHFbLazZepbQDvBRpTItLIGhYkgWAxLieLghghVOYWBkcytmzVEDufxVJTcicBRGNLMkRWiFZEbqtOzQyvCkhuqqXkbPTJDGRPveAwCYktPthjhvFeurEFKvmImZMqPzNbWGiZnjl");
    bool kKLMOGXYw = false;
    int LzBhBFwnupjGL = -2043050626;
    int IvEdJBXwPRw = 17189581;

    return iJndSJFiXDX;
}

int lVCrBhPfwIZKCLD::hGhwpxdrxomzqiYL()
{
    int mVOEVIpbWAO = -1007205469;
    double FstWbnzNpfAt = 169525.69952429135;

    return mVOEVIpbWAO;
}

int lVCrBhPfwIZKCLD::tZohnWm(string jcTJXgAD)
{
    string WFCVWxLptDHE = string("bYLrHtjQwaxAzjWKnphTTUehjpNBWWOAzhvqkcFgWSzrxIMlgNaKgizgoAWkSKdfXUCBQQpiJnsKjAETKmQZ");

    if (WFCVWxLptDHE != string("bYLrHtjQwaxAzjWKnphTTUehjpNBWWOAzhvqkcFgWSzrxIMlgNaKgizgoAWkSKdfXUCBQQpiJnsKjAETKmQZ")) {
        for (int vpFrkNFHLiSM = 277707957; vpFrkNFHLiSM > 0; vpFrkNFHLiSM--) {
            jcTJXgAD += jcTJXgAD;
            WFCVWxLptDHE += jcTJXgAD;
            jcTJXgAD = WFCVWxLptDHE;
            jcTJXgAD = WFCVWxLptDHE;
            jcTJXgAD += jcTJXgAD;
        }
    }

    if (WFCVWxLptDHE == string("bYLrHtjQwaxAzjWKnphTTUehjpNBWWOAzhvqkcFgWSzrxIMlgNaKgizgoAWkSKdfXUCBQQpiJnsKjAETKmQZ")) {
        for (int lUDYaLhWfvxAVsOI = 331767731; lUDYaLhWfvxAVsOI > 0; lUDYaLhWfvxAVsOI--) {
            jcTJXgAD = jcTJXgAD;
            WFCVWxLptDHE = jcTJXgAD;
            WFCVWxLptDHE += WFCVWxLptDHE;
            jcTJXgAD += jcTJXgAD;
            WFCVWxLptDHE = WFCVWxLptDHE;
            WFCVWxLptDHE = WFCVWxLptDHE;
        }
    }

    return -1050634729;
}

int lVCrBhPfwIZKCLD::ztIqoZdV()
{
    string WypBvraLxX = string("TkgOspNtJlNcqCEWiIYCuROBjGOXEilPIdaLnuyZkPsbydQfTeOYvqnVoHppluJMPiIuPoMYXXNzNuWGgVbfvfedioGbtFmFvLpGvAUHDPiXLEdhQSwMqKmzcGSRjStvKwBhJxlkHHimxVwRqhHDczwlGJFrasRGVwAAHhSjwPJoEyOGIeVeAUuGGmMGFNoavoYyQILdcIzLTCkLfgdBiddgXaENArmNSjmrDUMWQiCcwNcjYINaTrCWuc");
    bool kWIxDbf = true;
    string YwvHARc = string("dZxJbfrjEGaJSAfpNaFFBAGUwLdGpIlEdIITRqAeOGOWEZiZZTyZYvAxqXTYpXXCrfApxdoakzzJABmgTNeFC");
    double WHszPAnCoBBXN = 926469.9899856868;

    for (int WKvEePXI = 186356475; WKvEePXI > 0; WKvEePXI--) {
        kWIxDbf = ! kWIxDbf;
        YwvHARc = YwvHARc;
        kWIxDbf = kWIxDbf;
    }

    for (int jzlobWfbSLs = 816632777; jzlobWfbSLs > 0; jzlobWfbSLs--) {
        WypBvraLxX += WypBvraLxX;
        YwvHARc = WypBvraLxX;
    }

    return -1511200629;
}

bool lVCrBhPfwIZKCLD::vKPROeG()
{
    int fDcQWF = 334903333;

    if (fDcQWF == 334903333) {
        for (int cmrcNcdjxVsUli = 797171372; cmrcNcdjxVsUli > 0; cmrcNcdjxVsUli--) {
            fDcQWF = fDcQWF;
            fDcQWF = fDcQWF;
            fDcQWF *= fDcQWF;
            fDcQWF += fDcQWF;
            fDcQWF += fDcQWF;
            fDcQWF /= fDcQWF;
            fDcQWF *= fDcQWF;
            fDcQWF = fDcQWF;
            fDcQWF *= fDcQWF;
        }
    }

    return false;
}

double lVCrBhPfwIZKCLD::VuonjEObfg(double ZUiZILNotp, double KFkKIrnwVOR, string DvKEwqvWciZHqpI, double yrynXpHj, double EmgpOdCVchpLjItQ)
{
    double lAnIPmbVuTr = -173553.50492464253;
    bool SLSDyeKvg = true;
    double CmKrGfF = 711128.7576646945;
    bool cYJCCXELW = true;
    bool ihBMBX = true;
    string aanvq = string("GioDxGXpwiPUnopVDQaPleDSyAFZWYAniiZObMqjQgiuEvDmjBlrZVSZjeyalgfhklZdgMXeTStLPlEgwtyIKVyRBribPVDZOaztMvUsusRGzDNEiFTCKqpHSwOnFtNRMWILJNEoGkONrxGVYKaZPrRQofQwiWFAhgDw");
    bool BQPOkBKPgMb = false;
    int whbmI = 278722650;
    bool phajjlBwkaodKTJi = true;

    if (EmgpOdCVchpLjItQ != 711128.7576646945) {
        for (int iahkaIW = 1426344210; iahkaIW > 0; iahkaIW--) {
            continue;
        }
    }

    return CmKrGfF;
}

double lVCrBhPfwIZKCLD::zYcXeOirSCu(string jVCLkttdIHJNd)
{
    bool jCpQOiAytccCxJW = true;
    int cxxEFAlDnhU = -474596189;
    bool HKuyGvnzjpePdV = false;
    int tnCkvWWKLFPTTeU = 722527120;
    double OInhssAYBHUu = -734671.8164340628;
    int zQHIQMyP = 867651878;
    string SUvSVlXuPO = string("mQPlhiJSbgOWIaKSpjZkiyYXbEnDSrDuWCMJpgPjyRzzVIhLKzcoEGVYldHrgZKPIrjzHoUTiUgRAFZfWJQtgYcqFFMywEnXvLPHIvTPMfkHqDxTBacXNHWRpNRMTyYjNoWskGmTkCvWmNTCWUzdgBKDSjZwuzxAeeTPleVLMRCBvZDK");

    for (int fRIJrjNZIJSYegr = 1833122512; fRIJrjNZIJSYegr > 0; fRIJrjNZIJSYegr--) {
        tnCkvWWKLFPTTeU *= cxxEFAlDnhU;
        cxxEFAlDnhU = tnCkvWWKLFPTTeU;
        jVCLkttdIHJNd += jVCLkttdIHJNd;
    }

    for (int kzCBlbz = 2017016369; kzCBlbz > 0; kzCBlbz--) {
        cxxEFAlDnhU += zQHIQMyP;
    }

    for (int fEaXpb = 1408310193; fEaXpb > 0; fEaXpb--) {
        continue;
    }

    return OInhssAYBHUu;
}

lVCrBhPfwIZKCLD::lVCrBhPfwIZKCLD()
{
    this->movZTaEw(-1009955140, false, false, string("OktcQOVdclqaPTQqUabafGNyjUtVrsLChVWCAkaMCiECGdoNAxqhsGmvUqVeiKnjDzgJdrlyybhNODAmzSnuHaUyJcmmFlHszFECJOnEsWTzVEWlgYUgqKvEdggmoKjJKeBhyGTqSGXRBnhNjfcdfQHtnjnOJCKLNIxcJrOhIJTRAYsokQEUhMhMfHjUcpIGXFVIgPEhbhFvishwd"));
    this->WHFprohArJhtugDZ(string("bHFvXDvvUYDKfDnztsAmdrYcgwTVFUToriHPuzBfIFuZOwNWYBDacajUMuhjERTJEaTtkdUjNIQhaOXDxxTxwEPUEtEdFPHeUIMpbCKOBEUZPPAaGkqrOULuinfpCvlVjkgLUojQDpyS"), string("UXyAGtmOfACkHEoRCYXallYpUNENVADPdjqgNORmWLWIGweiPOfvdRCSiJyIESuZucCGJXjZqnUZsCtlLPZbQGWbkeuYxMAtZfvpe"), true);
    this->VDHoLrAdABO(-56638884);
    this->DHcfm(558643788, 1050682424, 86404.03424281202, 820325.2459790839, 10191.026564784104);
    this->UNAsZvohTGZZMaUr(-561374.673115059, 287342.11612198176, 596664388, false, -788895.492542113);
    this->hGhwpxdrxomzqiYL();
    this->tZohnWm(string("qNdubgtKUGzVSzXBlvwRDdowFwTNkNuEPuuWFnOesPKFmScpLvNLiJfhQmFCivZhLIkQtjBQqTVRrOhtWTIgweQLzHWZJztBkIyhXyWEQDJgfZxnSSJfvcPJvgPdWrwHULfZptwvzAXRogcfBIVptYNRrAqtigSuhbezFMvQkwMLwjQHEduVHeriVzgOWWEQHPOYVsiMbSDQZGVXSJTPLfbvGNMkOYpzpwhkvahFCbRfl"));
    this->ztIqoZdV();
    this->vKPROeG();
    this->VuonjEObfg(971888.8767853593, 241047.97659071555, string("pNgIGcisloIRIFpDZLWxbWwJRkCAAgRlzJipfEVbfkWtpTuYSZEOxBeGJugGenwrxXfEycfTTbgCaHocAjPQqkvltvTFVabDnqjLsktCDoPKjThqOzYBuviviKzSQXneYmNNpCQdSaRTnNIxdChaDregvhSAhhYMeqtPUhUuyAuYqmSNRAAnARRfAPnrFjxpoEpAOiNnktUZYXpLKKwz"), -609932.9757955573, 215335.94643190096);
    this->zYcXeOirSCu(string("kYhZPFgiaepNircUSbvuOTfBoPr"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pgsnDedBkheDwio
{
public:
    int RUJiQGGNELgFxX;
    string YbVklLLKFaOL;
    bool UhgiYNx;
    bool TGSaVreeCygH;
    double sbGriwElJmrtsVI;
    double hQrnIKGA;

    pgsnDedBkheDwio();
    bool sPRoI(bool EvRYnFvYKJgyvdW, string plZNvzKZKgPKFot, bool CdrAbwsrpPK, bool rCsHaU, int ywduqfUI);
    bool ircxU(double KzVrPyRLKBDlbC);
    int sLPbBGdUtqmF(bool KFJwcYIzadO, string dWmNHleVPDZhagl, string hMShOFCzMi);
    string IraKLUegMQjmj(double nkPrQCGRJ, double HvIQQgYbTw, bool fKSKB, double OUvlpRbwxy);
    bool YIQTABqZwLtkyDJ(bool LYswzJERogJeesL, double exanzlRwB, bool uDChfTXqvXcWzj, int rtlelwnqmarwjSR);
protected:
    double CHRncufhaN;
    int DhmZyqWDRegUMS;
    string kVTSgErh;
    int OSsbqLCwHWGs;
    string dqtgeTmpOyU;

    double ilohkVXRE(int iBlVJun, bool CyWntDInHff, double UPZjYdWd, bool btbBQyzdfIKi, string PoMAL);
    double BBzzccaeZ();
    string YcjUPZoeg(int xDJQVcmwkO, int bkiDGsgbD, string BZFyuuzXETlSKkzn, bool pPvEjf);
    void pxSTtdKH(string CixqCSc, double qvLmkDAnq, bool syJtzgTC, string PnaHUSnCTQX);
private:
    double avkxyUbCeWTacvsB;

    int ndQvhimtYH(string LSyLMLAAtxydz, string zPVFy, bool JaeMvChVbiemd);
};

bool pgsnDedBkheDwio::sPRoI(bool EvRYnFvYKJgyvdW, string plZNvzKZKgPKFot, bool CdrAbwsrpPK, bool rCsHaU, int ywduqfUI)
{
    int PSwHEahKMQFHpBk = 2103909896;
    double SpVtFGthY = 698376.0828790981;
    bool wpuSj = false;
    bool WGlza = true;
    int bKzrTPtYOUCjsi = 1493657941;
    bool BxnDleEHsjg = true;
    double PqFstkHcna = 923900.3757356608;

    for (int xQwkhymq = 195242974; xQwkhymq > 0; xQwkhymq--) {
        WGlza = rCsHaU;
        BxnDleEHsjg = ! rCsHaU;
    }

    if (WGlza == false) {
        for (int KuphHnZl = 639675905; KuphHnZl > 0; KuphHnZl--) {
            PqFstkHcna *= PqFstkHcna;
            wpuSj = WGlza;
        }
    }

    for (int GUfciPOcZv = 387907833; GUfciPOcZv > 0; GUfciPOcZv--) {
        WGlza = WGlza;
        EvRYnFvYKJgyvdW = ! rCsHaU;
    }

    if (EvRYnFvYKJgyvdW != true) {
        for (int ahnPDStzlMeBiQcF = 723691425; ahnPDStzlMeBiQcF > 0; ahnPDStzlMeBiQcF--) {
            CdrAbwsrpPK = ! CdrAbwsrpPK;
        }
    }

    for (int rdQTQECic = 1614813937; rdQTQECic > 0; rdQTQECic--) {
        ywduqfUI /= bKzrTPtYOUCjsi;
    }

    for (int AoLNWoxHedisC = 75917904; AoLNWoxHedisC > 0; AoLNWoxHedisC--) {
        rCsHaU = rCsHaU;
    }

    for (int pQUTQDSIW = 526212677; pQUTQDSIW > 0; pQUTQDSIW--) {
        PqFstkHcna -= SpVtFGthY;
    }

    for (int nULmun = 594088650; nULmun > 0; nULmun--) {
        rCsHaU = ! BxnDleEHsjg;
        EvRYnFvYKJgyvdW = ! EvRYnFvYKJgyvdW;
        PqFstkHcna = SpVtFGthY;
    }

    return BxnDleEHsjg;
}

bool pgsnDedBkheDwio::ircxU(double KzVrPyRLKBDlbC)
{
    bool bqoBTMPVVogeIYB = true;
    string RbrfegQskapfFtDK = string("vpSQAwKyzsfHeGWtfpggRdcInItUKpaiSZhbsJOMkeuQAWqNPirQkpkcsIVCGqQyflaJfmRsLqXSBafRTgLyeEEWKyVFuGhRDGbwhJwNvamFqZtFXJtkZNQBWXAWBPrAqsQAyMUTbEJYsDJoNUuAWTOMBXujzPluytlnnVFGQmVFAkuuBmjsnPmyw");
    double HhArfqYDcQFv = 1037562.7723253159;
    double ACaNyn = 1002841.1553777806;
    double hHXAfQBiwVt = -1029614.6325661248;
    bool rPQPrLZLNd = true;
    int MJeHjotaNHQS = 682348881;
    int OgRJcmkQgiuwD = 857461282;
    double SaJuxwKyxhZsdN = 181661.5143161415;

    if (KzVrPyRLKBDlbC > 113294.36979646383) {
        for (int vtxidAbJJEWOnciL = 838593844; vtxidAbJJEWOnciL > 0; vtxidAbJJEWOnciL--) {
            HhArfqYDcQFv /= hHXAfQBiwVt;
            bqoBTMPVVogeIYB = rPQPrLZLNd;
            ACaNyn /= ACaNyn;
        }
    }

    for (int iRTImwrYbYDpPRR = 2009250715; iRTImwrYbYDpPRR > 0; iRTImwrYbYDpPRR--) {
        rPQPrLZLNd = ! bqoBTMPVVogeIYB;
    }

    if (HhArfqYDcQFv != -1029614.6325661248) {
        for (int JRHkpaHgWUqaSbQ = 1160772018; JRHkpaHgWUqaSbQ > 0; JRHkpaHgWUqaSbQ--) {
            continue;
        }
    }

    if (MJeHjotaNHQS > 857461282) {
        for (int kZzrI = 1331503162; kZzrI > 0; kZzrI--) {
            continue;
        }
    }

    for (int GePLIxsw = 833263813; GePLIxsw > 0; GePLIxsw--) {
        bqoBTMPVVogeIYB = rPQPrLZLNd;
        SaJuxwKyxhZsdN /= SaJuxwKyxhZsdN;
        MJeHjotaNHQS -= OgRJcmkQgiuwD;
        KzVrPyRLKBDlbC *= KzVrPyRLKBDlbC;
        OgRJcmkQgiuwD += MJeHjotaNHQS;
    }

    for (int WLtut = 158433244; WLtut > 0; WLtut--) {
        MJeHjotaNHQS += MJeHjotaNHQS;
        KzVrPyRLKBDlbC *= SaJuxwKyxhZsdN;
        ACaNyn /= ACaNyn;
    }

    for (int ctcmvx = 1123321251; ctcmvx > 0; ctcmvx--) {
        ACaNyn /= KzVrPyRLKBDlbC;
        ACaNyn = hHXAfQBiwVt;
    }

    return rPQPrLZLNd;
}

int pgsnDedBkheDwio::sLPbBGdUtqmF(bool KFJwcYIzadO, string dWmNHleVPDZhagl, string hMShOFCzMi)
{
    string TvvlUEniXgbI = string("cemsJuTMCHOVsiiYLvjnICVqMrljlJSkPkiCLXjmtyagddIyfsqokuhABxUzcapIWZFRNDTMeRHCyfAUeKCMuuLFsckYZwFRMaLegqlQLMcPiSKnkEpIUpMZV");
    string ECRthxS = string("HNxsSxYiuiNXYDWKaTUlLBEfxjaHCnkwWHfvmCfVPtROiWpzPDathMbjNxwfogBilBEPSmnuMbUwFpfnIeepEgFuZGkdnJFwhvsXHTpgoMBdvDVJEkliZGMmgADYMLjLcsXb");

    for (int PEUPy = 1993101684; PEUPy > 0; PEUPy--) {
        dWmNHleVPDZhagl = dWmNHleVPDZhagl;
        dWmNHleVPDZhagl = ECRthxS;
        ECRthxS = hMShOFCzMi;
        hMShOFCzMi = dWmNHleVPDZhagl;
        dWmNHleVPDZhagl += TvvlUEniXgbI;
    }

    if (ECRthxS < string("HNxsSxYiuiNXYDWKaTUlLBEfxjaHCnkwWHfvmCfVPtROiWpzPDathMbjNxwfogBilBEPSmnuMbUwFpfnIeepEgFuZGkdnJFwhvsXHTpgoMBdvDVJEkliZGMmgADYMLjLcsXb")) {
        for (int KLlzgGKanz = 1905012871; KLlzgGKanz > 0; KLlzgGKanz--) {
            dWmNHleVPDZhagl += TvvlUEniXgbI;
            dWmNHleVPDZhagl += ECRthxS;
            ECRthxS = ECRthxS;
            TvvlUEniXgbI = TvvlUEniXgbI;
        }
    }

    if (dWmNHleVPDZhagl >= string("AJMEIWECWAUxVRwqKqnNOFcbimvChbOshzpUfrSWQHxxQuejxnEhisETvEAysfeUpvBNZFkacKYVDNUtLFrlbgEXzFLUXLBeBYgoRauqEMNgPLLpjoYWPMFwrcmJzxuzuGIIzBTcNZhlamTkfhnlKtxDTYxQxpSdblTRADeYnBFMRsgDtwesSdkHGFsbvgHQppMRU")) {
        for (int IAqzEUCPJiXuPe = 1963554949; IAqzEUCPJiXuPe > 0; IAqzEUCPJiXuPe--) {
            TvvlUEniXgbI = hMShOFCzMi;
            ECRthxS += dWmNHleVPDZhagl;
            hMShOFCzMi = dWmNHleVPDZhagl;
            hMShOFCzMi += TvvlUEniXgbI;
        }
    }

    if (dWmNHleVPDZhagl != string("cemsJuTMCHOVsiiYLvjnICVqMrljlJSkPkiCLXjmtyagddIyfsqokuhABxUzcapIWZFRNDTMeRHCyfAUeKCMuuLFsckYZwFRMaLegqlQLMcPiSKnkEpIUpMZV")) {
        for (int eVCPNSKGXSNymZ = 1890051310; eVCPNSKGXSNymZ > 0; eVCPNSKGXSNymZ--) {
            hMShOFCzMi = ECRthxS;
            dWmNHleVPDZhagl += TvvlUEniXgbI;
            dWmNHleVPDZhagl += ECRthxS;
            ECRthxS += hMShOFCzMi;
        }
    }

    if (hMShOFCzMi > string("IhNVpCliwdHViJSAgnqsvMLkURFjnUNnfCariTVADHOBIBMWsCJRcSFjIprLIJlrQRoTjcjmfsbFWPAaINpfvzOVWmKbxAfc")) {
        for (int FWBvlIdnPBVez = 203564874; FWBvlIdnPBVez > 0; FWBvlIdnPBVez--) {
            dWmNHleVPDZhagl += hMShOFCzMi;
            KFJwcYIzadO = ! KFJwcYIzadO;
        }
    }

    if (dWmNHleVPDZhagl >= string("IhNVpCliwdHViJSAgnqsvMLkURFjnUNnfCariTVADHOBIBMWsCJRcSFjIprLIJlrQRoTjcjmfsbFWPAaINpfvzOVWmKbxAfc")) {
        for (int QyrwuxPLNYkzPgoU = 99752578; QyrwuxPLNYkzPgoU > 0; QyrwuxPLNYkzPgoU--) {
            continue;
        }
    }

    return -273162519;
}

string pgsnDedBkheDwio::IraKLUegMQjmj(double nkPrQCGRJ, double HvIQQgYbTw, bool fKSKB, double OUvlpRbwxy)
{
    bool TOttzT = false;
    string dGqjwhfMajQWgG = string("eFwtsVbuavalemeZUmILORqXwlEEYhTrOFOUlxmgiPsdDBulazZRxBBbxDIBOJyphiMHyaunDbeDlJQYBgGSyiKQHbgChjXIgACqXDQZyadQdZVMUHFgYpchXXpJRdkOFoECGtfVrEKNbAQVxQBaoxBjMXb");
    int hbnuyltkClmvW = 1941129522;
    bool XzLmRiuzYohsGbz = false;
    int jallWJmnj = -37334307;

    return dGqjwhfMajQWgG;
}

bool pgsnDedBkheDwio::YIQTABqZwLtkyDJ(bool LYswzJERogJeesL, double exanzlRwB, bool uDChfTXqvXcWzj, int rtlelwnqmarwjSR)
{
    double sUThejVI = -727828.5069561617;
    bool TklQbbgItLuxX = true;
    bool LropATVT = false;
    string rryqFLNsYoXm = string("YUjBvoqUWlhZdrFcLMEJJWDSlfSElggLYNIqMZUaiQUUczMIiUIpwxzDLgVKRWpbOzHZULlbNiNdPvmKWbCtuWSUFUWUtIYeCoZBmiZjOaRgJCaJDsK");
    int lrPGbeEAv = -450898009;
    int fsgeIeRMYQ = 1630596539;
    bool czHBYGOSgztNnGvo = false;
    int rqCKFEfJ = 1219053763;
    double WXohxCAnNmUyNe = -1010342.5863464393;
    string ZxUrcHmWCPgF = string("ifEUyFsrI");

    if (czHBYGOSgztNnGvo != false) {
        for (int kYMUjPjMihL = 1026821121; kYMUjPjMihL > 0; kYMUjPjMihL--) {
            fsgeIeRMYQ /= lrPGbeEAv;
            LropATVT = ! uDChfTXqvXcWzj;
            czHBYGOSgztNnGvo = ! LropATVT;
            LYswzJERogJeesL = ! TklQbbgItLuxX;
        }
    }

    for (int BVjmYjc = 2052896711; BVjmYjc > 0; BVjmYjc--) {
        uDChfTXqvXcWzj = ! uDChfTXqvXcWzj;
    }

    for (int JJRKpurMvbKYJ = 2048054112; JJRKpurMvbKYJ > 0; JJRKpurMvbKYJ--) {
        exanzlRwB *= WXohxCAnNmUyNe;
    }

    if (LropATVT == false) {
        for (int bfwCaJypvmL = 1627998641; bfwCaJypvmL > 0; bfwCaJypvmL--) {
            sUThejVI *= exanzlRwB;
            LYswzJERogJeesL = ! TklQbbgItLuxX;
        }
    }

    return czHBYGOSgztNnGvo;
}

double pgsnDedBkheDwio::ilohkVXRE(int iBlVJun, bool CyWntDInHff, double UPZjYdWd, bool btbBQyzdfIKi, string PoMAL)
{
    string AabjB = string("QHJLDUUgFeIeLJINqXXwntvNPpyUeAVypDqXQruXA");
    double uwnnXDFJvvF = -633872.2607181598;
    double tMeNIakTiTAT = 601378.071736144;
    double zHoFwudduoKeXxm = -768364.6897974389;
    string przRyPKnkn = string("YSnBetmSStwkoCZhGurYfzWOBvaToMbkHczmZTNPNxNciwKnDXPTNkGGhLSyVqKrINMZbjlwozcaHgOCJBkqxkXkA");
    int nvmsBLeCrwYOah = -1980506706;
    int eompELtKLzb = -2117723480;
    int WNhhf = 1967482834;

    for (int evTjGINQr = 2040213150; evTjGINQr > 0; evTjGINQr--) {
        continue;
    }

    return zHoFwudduoKeXxm;
}

double pgsnDedBkheDwio::BBzzccaeZ()
{
    double KgvxBfKH = 327674.04471331125;
    bool MLBsKSzmGzm = true;
    int kKnLTRzWxoujxPzy = -710720277;
    string PllrGtbDwbTYnbg = string("HHWFSvuzsLINUiNUSUvWtCKDdzvdNCdvdjgizdVoeoBeywWrGmJSfYDsVtsYkLDzuXxxNbJRzDHdNDUbQbVmnCZibeAeEAtBZUMiRcIklezSAczmavmbWIyGsJwwZTVqEDZfmHiRqaHmbdWdqwTaVtcwsMssWZudCkLwVGbgJwPyFnSWtsQXUBSAYBhbqkTeKHPRPRPVqRbCNHH");
    string IaJfVRrbWq = string("tQzLtkGrZLdDxDaMGASrDirfVGxCpIYzJGDRVSGiDsduXkTzCjySajAOkLuCILVcOOTCgQljaaoyeOXcjSBRsUGiNwXnvvaXzSPSNnheaBJuLwceSezExTxqryBAMpkCsrxEbXNieKVEYncwTaznzlqDtAlIOfvGiTOYiSZbjEotnHfvXyscgyZOrlGlvMEA");
    bool zpHzH = true;
    double aGXJXzLwoTQE = 276791.4491112441;
    double HLMChgIMNk = 694301.3334634909;
    bool gqpyLyRWgW = true;

    for (int Jrbqn = 934719877; Jrbqn > 0; Jrbqn--) {
        MLBsKSzmGzm = MLBsKSzmGzm;
        zpHzH = ! zpHzH;
    }

    return HLMChgIMNk;
}

string pgsnDedBkheDwio::YcjUPZoeg(int xDJQVcmwkO, int bkiDGsgbD, string BZFyuuzXETlSKkzn, bool pPvEjf)
{
    string ykvsfgzHlz = string("CNMgEchyusAhDmMGClWBMNqnAnOiiRELBzdEWXaeLOeHUMAPyUhbWIHCJTNNvpiUpfZVQjQCKiHrBjQhVWcvSsTwPCbOqwkpjPhuNdqUDoGEsXTSdejFZRXdCiUIvdQtiCnXDkYpzgRxQojhscCMHuXLQUZGtVWjGddeaQEwtrrVRYSWoSUOTwtYghHCafsAFVlZxoXbhbVdEtumGdjwV");
    bool xkDLNgsMuWZ = true;
    string BWkverPJr = string("MzNflnxyNNWdgjJoPgVx");
    double UuhyJhHLImqcvG = -113918.62009570956;
    int JTVBuuQexsQh = -21901307;
    int nTZUpY = 194188256;
    int nMbzbBVzuyLNcnY = 125890948;
    string xHRuxZTBsaUuvrO = string("cisLvCdkdXEnYjvYWHAbOYBfSxdHffbLWBgralXFlnWuTVNLHClTNMyMLLFZOYRXxKoiZzIqnVSqgLexvRKunZZVABULKSUJCwHkoBTDntVLkZAiOesKYUdWauQefFDEelzmxzCpjerXZDVrXfWdaQnTdcxuYtfEilYzlebwzBVmlKoqLRqxtXuVpMiTSrTrMDAQdkkGSNd");
    bool JCAPqDmVM = false;

    for (int mUbBq = 1903216833; mUbBq > 0; mUbBq--) {
        nTZUpY *= xDJQVcmwkO;
        xHRuxZTBsaUuvrO += BWkverPJr;
        bkiDGsgbD = xDJQVcmwkO;
        xkDLNgsMuWZ = ! pPvEjf;
    }

    for (int rvEXRQY = 1061541265; rvEXRQY > 0; rvEXRQY--) {
        nTZUpY *= xDJQVcmwkO;
        JTVBuuQexsQh -= xDJQVcmwkO;
        nTZUpY = bkiDGsgbD;
    }

    for (int HMoYhn = 2138512212; HMoYhn > 0; HMoYhn--) {
        xHRuxZTBsaUuvrO = BZFyuuzXETlSKkzn;
        bkiDGsgbD -= JTVBuuQexsQh;
    }

    for (int oKUKgulAhxmNUZ = 1365269872; oKUKgulAhxmNUZ > 0; oKUKgulAhxmNUZ--) {
        BZFyuuzXETlSKkzn = ykvsfgzHlz;
    }

    for (int NAyJgzVJAGkwFEq = 1325100978; NAyJgzVJAGkwFEq > 0; NAyJgzVJAGkwFEq--) {
        pPvEjf = ! JCAPqDmVM;
    }

    return xHRuxZTBsaUuvrO;
}

void pgsnDedBkheDwio::pxSTtdKH(string CixqCSc, double qvLmkDAnq, bool syJtzgTC, string PnaHUSnCTQX)
{
    double UfcfzDfZcLWpFbvd = 288262.7080988955;
    string QQoJqamZtuFsYKBz = string("lKvISlVimkpXKUXXpONtELlvQMGnjwuOqDInvbusfnEUxj");
    string trfYmpUZdV = string("yOlzdnbyfAHCkYMxPCPsSSxfDwsDgUsNICMvTCPLmZBpRhITidnMQtvRtWfPDdquxMFyrNtdFYuloNKsUHNwfXGPjiCxiTJTtjFpNgEffpzzuinnyoqSJqHbmKpIAwkFSnKnsBGkDaUlIfaLUZEHpOEyZb");
    bool ybwtRMdpS = false;
    int lbIuWsUhGa = 1790727461;
    int wkybQuPCxr = -777587335;
    int BjuxIhge = -1995038760;
    int JbGomUJhpZqbB = 566191923;

    for (int PDdEp = 480063176; PDdEp > 0; PDdEp--) {
        wkybQuPCxr += JbGomUJhpZqbB;
    }

    if (JbGomUJhpZqbB < 1790727461) {
        for (int wCeWvfRAfes = 971400819; wCeWvfRAfes > 0; wCeWvfRAfes--) {
            UfcfzDfZcLWpFbvd += qvLmkDAnq;
            QQoJqamZtuFsYKBz += trfYmpUZdV;
            QQoJqamZtuFsYKBz = CixqCSc;
        }
    }

    for (int BpVPA = 69398693; BpVPA > 0; BpVPA--) {
        wkybQuPCxr -= lbIuWsUhGa;
    }

    for (int kLIXTUTdGuITu = 501425893; kLIXTUTdGuITu > 0; kLIXTUTdGuITu--) {
        wkybQuPCxr += lbIuWsUhGa;
    }

    if (QQoJqamZtuFsYKBz <= string("KZPYqCfdQAJiQGlWmLkpkOOnjYeqSMLAFjdcwmOiSxDptBlbxqokQVmfmWvdOrHUnGlpmXWiMYBImdUphdAsMvDHuZauRNgPVYZXVnBwLZrxpDvLuSmiCY")) {
        for (int ZnERrAfnI = 1749874729; ZnERrAfnI > 0; ZnERrAfnI--) {
            continue;
        }
    }
}

int pgsnDedBkheDwio::ndQvhimtYH(string LSyLMLAAtxydz, string zPVFy, bool JaeMvChVbiemd)
{
    int AYQpblJgdtIsCHv = -761921264;
    bool fvHlVFx = true;
    int pjYrUYgHTPpBPm = -1057096974;
    int sRHmTo = -1385579220;
    int tbwsg = 306729240;
    string DHrFubF = string("cQrPJOpbWSeXrjXpLDOsvqFpXVUVGHprEOMeRWyaASlzwFRKQrpkwjgpijfMIWFkFuunBNWhlzrDWsrbHNDlZEjyzMPhNsEtWPlRDTcTFlfafXcLWgqYQWDFZhqNmioyJbQ");
    int oKpDev = -672514545;
    bool rrwBHMPbEChjrEb = false;
    string FKXnDMZHVliEoE = string("fAMmYLAewKBDIDiJuUYRXHgWYJhXSQjpZASoLgLIjCkkXIpfeUNPXOYTrFIqwzBIsLKuhIblTsgXaSDDvKNihkHmswUSfrcuDwLzRmSMzAevuFHXHDxGNSSPaMOOjrEKbsAvOrvOccIbVFdLoXHRYwNnJyncaNKomI");

    for (int icNwcU = 1267286276; icNwcU > 0; icNwcU--) {
        JaeMvChVbiemd = JaeMvChVbiemd;
        AYQpblJgdtIsCHv = tbwsg;
    }

    for (int vQNghpfESc = 870644036; vQNghpfESc > 0; vQNghpfESc--) {
        AYQpblJgdtIsCHv *= sRHmTo;
        FKXnDMZHVliEoE += DHrFubF;
        LSyLMLAAtxydz = LSyLMLAAtxydz;
        FKXnDMZHVliEoE += FKXnDMZHVliEoE;
    }

    return oKpDev;
}

pgsnDedBkheDwio::pgsnDedBkheDwio()
{
    this->sPRoI(true, string("BSkHuElLlwsc"), true, false, -410194489);
    this->ircxU(113294.36979646383);
    this->sLPbBGdUtqmF(true, string("AJMEIWECWAUxVRwqKqnNOFcbimvChbOshzpUfrSWQHxxQuejxnEhisETvEAysfeUpvBNZFkacKYVDNUtLFrlbgEXzFLUXLBeBYgoRauqEMNgPLLpjoYWPMFwrcmJzxuzuGIIzBTcNZhlamTkfhnlKtxDTYxQxpSdblTRADeYnBFMRsgDtwesSdkHGFsbvgHQppMRU"), string("IhNVpCliwdHViJSAgnqsvMLkURFjnUNnfCariTVADHOBIBMWsCJRcSFjIprLIJlrQRoTjcjmfsbFWPAaINpfvzOVWmKbxAfc"));
    this->IraKLUegMQjmj(-220494.28805769165, 10108.096895600294, false, 6612.976364430897);
    this->YIQTABqZwLtkyDJ(true, -823155.38701289, false, 462984);
    this->ilohkVXRE(-1722705409, false, -891627.389589037, true, string("zrdQcwMlRzdCQhIGRmjnWJAiWxLSrNCBAkSCiEbgEzWvYUVIJKZqrfEBlkyseSnymgieDuwBULpskujVDWteKlkLTQQdYURQsgovJAL"));
    this->BBzzccaeZ();
    this->YcjUPZoeg(1013748983, -1732641276, string("ntGMbkFIXJwhVAXcqXEzUZzTZxhrwxkLVDfceCkskKwmPFJYYPUAMUlpygXVPzLrGwMfjBMcmxqpmwLujVMbuDToGlkRoXerqvcmbAGqDIpQBUVTVVvCGrTlLVQmrdnyRYMJNGxerHyIigcTwnjdatjtbGEnDIrQVHkUeaKOAeSPMlGoKTjigsiPtcax"), false);
    this->pxSTtdKH(string("jjYifqmRNEnlzkWGsIHEMcbyATscgnHfkmCHLaEuYfzzAoglslVnLbhNNMWROonZMAaTcupDGBOzRNfCrKURucQsNHrELLjaIXHdSuFevSjiClwKIyXfRHpEjfFwmPhWbAlkfgbcbUxaiBzwuGyDyUgCYnTTLwgXlTgTIlKFIThcnJDlRpGPpLJAzCkGHCjivsiieMtjrkAPdPcKeYWjZOgXZvijaaIwmzgwOl"), -661253.5898787865, false, string("KZPYqCfdQAJiQGlWmLkpkOOnjYeqSMLAFjdcwmOiSxDptBlbxqokQVmfmWvdOrHUnGlpmXWiMYBImdUphdAsMvDHuZauRNgPVYZXVnBwLZrxpDvLuSmiCY"));
    this->ndQvhimtYH(string("QKvQYAElOQNXPkccaHwoNwKMnymMezxUnjsxrEKrbxnaOmHnQaPtZUNSJeKhlAsOMbLsloXmkvpHvVHFPHtBkhIqdBEmqtgmCNHdjbPmGcTFwQbaxufRkbVCCoPCeiUePwfEOVSJFMwmDJWmIzMnhGFrxmKcRfmlyFlNQAklkvhMFPVOtvzjCLKJwMbapDZOaGwmdfLVDWLwdteBztdqbHBIkIBrgESSKFlwqrTGmoHudcXNbPsLgMRlEgov"), string("AdhHwbvoLKwghwDbASDIlioBzvEoZXRqyiGybBFQNjKtVzPcVrENNnFralstZKhsldOLkysDvYiTWIQoiaGUFERCNZsjJtYLXnMZmuRXIFvTpXbhqkUADfxDRJrIkZfkylthBWhfZgfetzMiMhqGYFayMHiNcEHrLCFdqofZdgFR"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rTjmKk
{
public:
    double ZTWVBO;

    rTjmKk();
    bool wMdftOrSwUrmz(bool BznPyAYGBIaU, int ExFZJgrBkFaB, double cPYZgkXnFPVE, string kJNHenBAbgzmNY, bool uusAABqxoQyoqL);
protected:
    double LHjKZvqSfKgeZWE;
    double mvzUj;
    int TkCcmNwJuec;

private:
    double XtgqB;

};

bool rTjmKk::wMdftOrSwUrmz(bool BznPyAYGBIaU, int ExFZJgrBkFaB, double cPYZgkXnFPVE, string kJNHenBAbgzmNY, bool uusAABqxoQyoqL)
{
    int vQbvjjzgfF = 1351098261;
    bool NbbUimEOTYhJ = true;
    bool vxvacljstIRIID = false;
    int dYyXfnCkzEkdM = 1028863385;
    int fntIcDxrok = -1224279187;

    if (uusAABqxoQyoqL != false) {
        for (int TAmYx = 1173100934; TAmYx > 0; TAmYx--) {
            BznPyAYGBIaU = uusAABqxoQyoqL;
        }
    }

    return vxvacljstIRIID;
}

rTjmKk::rTjmKk()
{
    this->wMdftOrSwUrmz(true, 1029649331, -420446.5751231825, string("UEHUBOkhwphLWYbrAznzEuJyGKaBKaHiRVfAlYTMbvSjjMxqvMRfQsCiIvRcarmPXJBVytWZiSVuAUsvkaScUStYsDsdwehKIJiWuaRRrVvjJezIfKOXPoddzClBhKWcNyiBxjpesebbEnYq"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vLbLbmuWGFt
{
public:
    string tsbTXwhH;
    bool tgxtjbtLyj;
    double xVANTqKqQ;
    string eDdkQ;

    vLbLbmuWGFt();
    bool nBsbywvF();
    double gmpjM(bool LCcGRCnPMOxwS);
    bool QQZsXuEGoIU(string dhCGPRW, int LvJksFYjMHtqTANM);
    bool scshnwYtKcl(double rBtSXVHtle, bool mFxcggrSW, bool gjqlNsIvmhKT);
    bool kgmShnu(string MRNfBvjJxjYClpj);
    string uTobzipUsa(bool OyWeZE, double FisAcuStlvS, bool UgTXjNNJk, bool ELvWV);
    double tBlsM(bool gsoJePJMNYg, bool nnHsdvmCPGdin, double iEwLyRbFwxmENBJ, double oEKXqlkGOcUJ);
protected:
    bool wFOYCGZfpLqvdMN;
    int xznyXaeXarCFjKfl;
    double ZKXyrNoJBR;
    bool tjbdlQBr;

    double ROVqiHS(bool ooJXVTo, bool LKciBqcSLoHjhChA);
    int xcfdcjxI(bool JjdfHrJV);
    double lCLyLsdyh(bool hVMlZkqleEkVe);
    int udSaCpO(int ELahP);
    double tbtUJSs(string HuodjRj, double oRTXSNlxKQxu);
    bool cvEriSmVDVNRgSl(int HCwqAzrXilfh, double dxuaOgdO, bool QRkdFHsPavlUy, bool cXFYsevmYg, bool iaCPyOdpHSSvRI);
private:
    double hwMOgyPoGenyUeG;
    string FAzDTpkHcq;

    bool PqBDRa(double utzKIXQu, int iiHbltLYaNDteyo, double AepsfygFT);
    int tCxMMyRvWskFhQoj(string UVEYlrEoUQBf);
    string HNoxDubs(double lDtTsNG);
    int AvTOWWmWtVthrprR(string LNyQfqxTPD, int kmlhWexzfRuCQ, string QUTsEmKJwe);
    string uWmbRk(int tSVBaVH, double KnElCZysgMMHJALV, string DvaChEzkubddeJl, string dZIptkcUSzeMd, string DACuIUlQJFljT);
    int qTzmmcS(double HMEwVWISoeP, int yXqiGBiZiutOlxVU, double hNyCViRMuRLIkwO, bool YbbwHWlSXM, bool EmUMuzWnOYIVyzyp);
    string hyyLIRuqhgR(bool JVTpqHJYdx, bool InlIhzontz, bool DRwWDbNgdBrZR, string peuwlrLARKYvu, string tyvfHQhTEH);
};

bool vLbLbmuWGFt::nBsbywvF()
{
    double OWFTqIMWmHU = 228892.70794439493;
    string gVDmtxqoxTn = string("DIEnOIlDfDkKxlcjDeERnKiMWmNxqjatfkxVqvlUQYZkwfdGCWiAkMCrUapXPMXxDPFNHOUEYsalmPodDAJYlzDBVssyGRrub");

    if (gVDmtxqoxTn != string("DIEnOIlDfDkKxlcjDeERnKiMWmNxqjatfkxVqvlUQYZkwfdGCWiAkMCrUapXPMXxDPFNHOUEYsalmPodDAJYlzDBVssyGRrub")) {
        for (int XFALmLDqKJWytF = 1937338979; XFALmLDqKJWytF > 0; XFALmLDqKJWytF--) {
            OWFTqIMWmHU /= OWFTqIMWmHU;
            gVDmtxqoxTn += gVDmtxqoxTn;
            gVDmtxqoxTn += gVDmtxqoxTn;
        }
    }

    return false;
}

double vLbLbmuWGFt::gmpjM(bool LCcGRCnPMOxwS)
{
    string wrojTJqB = string("HRgRRwyqBbcBeDvtoaFxvLKMSFTumSBHApVKbdcHpeTborHLHzjocofPySiFePurKlqOLaAgGBTmBQRplymAxEpjmiLEoCpCOjVoJ");
    bool cTFWXKx = true;
    string hSTFnfDLU = string("wZuKRVoyAhlweYEOMzZSgvBbeKvnKlmJXMdcCwIXdIzi");

    for (int MgLBZfuRzSRq = 2010474511; MgLBZfuRzSRq > 0; MgLBZfuRzSRq--) {
        hSTFnfDLU = hSTFnfDLU;
        cTFWXKx = ! LCcGRCnPMOxwS;
        LCcGRCnPMOxwS = ! cTFWXKx;
        hSTFnfDLU = wrojTJqB;
        cTFWXKx = LCcGRCnPMOxwS;
    }

    for (int LxZtUsvUtqGpLn = 1240247040; LxZtUsvUtqGpLn > 0; LxZtUsvUtqGpLn--) {
        hSTFnfDLU += wrojTJqB;
        wrojTJqB += wrojTJqB;
        LCcGRCnPMOxwS = ! cTFWXKx;
    }

    for (int FZwRlY = 210061008; FZwRlY > 0; FZwRlY--) {
        continue;
    }

    if (cTFWXKx != false) {
        for (int Pyrpe = 1117952622; Pyrpe > 0; Pyrpe--) {
            continue;
        }
    }

    for (int vMvuLUQCLMVL = 1023450070; vMvuLUQCLMVL > 0; vMvuLUQCLMVL--) {
        cTFWXKx = ! cTFWXKx;
        cTFWXKx = ! cTFWXKx;
        hSTFnfDLU = wrojTJqB;
        hSTFnfDLU = hSTFnfDLU;
        hSTFnfDLU = wrojTJqB;
    }

    return 163081.08376621947;
}

bool vLbLbmuWGFt::QQZsXuEGoIU(string dhCGPRW, int LvJksFYjMHtqTANM)
{
    double XQIls = -786763.2590752912;

    for (int BmzpmfECOmMV = 1049389868; BmzpmfECOmMV > 0; BmzpmfECOmMV--) {
        LvJksFYjMHtqTANM -= LvJksFYjMHtqTANM;
        dhCGPRW = dhCGPRW;
        XQIls *= XQIls;
    }

    for (int TJEJsIDAB = 407182222; TJEJsIDAB > 0; TJEJsIDAB--) {
        dhCGPRW = dhCGPRW;
    }

    for (int sjoPU = 18889666; sjoPU > 0; sjoPU--) {
        continue;
    }

    return false;
}

bool vLbLbmuWGFt::scshnwYtKcl(double rBtSXVHtle, bool mFxcggrSW, bool gjqlNsIvmhKT)
{
    int LreOVSlzFqHPba = -238703199;
    int BOamygLo = -209512815;
    bool WzsVUZopwzzOW = true;
    double QokjebofrekZ = -959449.6633770273;
    double LNAjPmFGvqmoUDJD = 196607.55366692788;
    bool QqsLq = false;
    bool usHwMtLv = true;

    if (usHwMtLv == false) {
        for (int Csbboemva = 1462523158; Csbboemva > 0; Csbboemva--) {
            WzsVUZopwzzOW = ! QqsLq;
        }
    }

    for (int MbfmmZH = 735047500; MbfmmZH > 0; MbfmmZH--) {
        usHwMtLv = mFxcggrSW;
        gjqlNsIvmhKT = WzsVUZopwzzOW;
    }

    for (int qIaALhBckrsmtXcw = 184274274; qIaALhBckrsmtXcw > 0; qIaALhBckrsmtXcw--) {
        continue;
    }

    for (int xenZdTbEUo = 954756945; xenZdTbEUo > 0; xenZdTbEUo--) {
        WzsVUZopwzzOW = ! usHwMtLv;
    }

    for (int bRkdpxqy = 1898213253; bRkdpxqy > 0; bRkdpxqy--) {
        mFxcggrSW = ! QqsLq;
        LreOVSlzFqHPba *= BOamygLo;
        BOamygLo -= BOamygLo;
        QqsLq = ! mFxcggrSW;
    }

    if (QqsLq == false) {
        for (int nZXBBo = 1879777678; nZXBBo > 0; nZXBBo--) {
            QqsLq = usHwMtLv;
            gjqlNsIvmhKT = QqsLq;
            usHwMtLv = ! mFxcggrSW;
            WzsVUZopwzzOW = QqsLq;
        }
    }

    return usHwMtLv;
}

bool vLbLbmuWGFt::kgmShnu(string MRNfBvjJxjYClpj)
{
    string XQxJjirheco = string("czQKTTkq");
    double yhwNM = -957577.8039282138;
    double zSfoF = -693950.2316881826;
    double tYRZnCwJGTDqqm = -742759.3257644279;
    bool SpGATeh = false;
    bool WPpNrPBGMVLao = true;
    bool dRSJWkOkm = false;
    bool NNAFUxiqiepiCb = false;
    bool TcWWUJdcjGEHMZ = false;
    bool qikzjS = true;

    for (int tQbnTFpffGyjqvFq = 1034387524; tQbnTFpffGyjqvFq > 0; tQbnTFpffGyjqvFq--) {
        WPpNrPBGMVLao = TcWWUJdcjGEHMZ;
        SpGATeh = ! NNAFUxiqiepiCb;
        dRSJWkOkm = ! TcWWUJdcjGEHMZ;
        MRNfBvjJxjYClpj = MRNfBvjJxjYClpj;
    }

    if (dRSJWkOkm == false) {
        for (int tCNBkR = 2047139852; tCNBkR > 0; tCNBkR--) {
            MRNfBvjJxjYClpj = MRNfBvjJxjYClpj;
            qikzjS = TcWWUJdcjGEHMZ;
            qikzjS = ! NNAFUxiqiepiCb;
            XQxJjirheco = MRNfBvjJxjYClpj;
            SpGATeh = ! qikzjS;
            yhwNM *= zSfoF;
        }
    }

    for (int gyOUzPLFfshZeU = 1249652205; gyOUzPLFfshZeU > 0; gyOUzPLFfshZeU--) {
        continue;
    }

    for (int JqnuXsRazCgQDvE = 1329039456; JqnuXsRazCgQDvE > 0; JqnuXsRazCgQDvE--) {
        WPpNrPBGMVLao = ! qikzjS;
        dRSJWkOkm = SpGATeh;
        SpGATeh = dRSJWkOkm;
    }

    for (int DaixcTa = 774915843; DaixcTa > 0; DaixcTa--) {
        dRSJWkOkm = dRSJWkOkm;
        qikzjS = qikzjS;
        dRSJWkOkm = qikzjS;
    }

    return qikzjS;
}

string vLbLbmuWGFt::uTobzipUsa(bool OyWeZE, double FisAcuStlvS, bool UgTXjNNJk, bool ELvWV)
{
    string rfluLmbUvPusMgtc = string("aGGRjRXlnrYcRRNPqubijMLnawFXoefCKiuQaypdcJFGpLCqnxvGFIxTenbXRNKSdMQhUYjxXmAhBOYrwNRYcHqWSPxqXQFJxccxYDaowBNCNBRYOZpqbDXfUQUAugLZHbFrkaWZaDWTnJEQMurfdturnhGfLzsMdqYsETgrpZVhevKrsEdutkZHUiFbxVKfTlVTfTrBTfmKIDnDpjcoerMjXzhrYAPgVVfLrcEEdbqyOzJcldO");
    string jbAnG = string("ElauxLrNnmJGcYvqqPfCbtqJEvrgXNMIiY");
    bool gyTUHHHVig = false;
    double cewXgx = 37748.96742383384;
    double JqMOrkOdGzlMCOZ = 847653.1904993611;

    if (rfluLmbUvPusMgtc > string("aGGRjRXlnrYcRRNPqubijMLnawFXoefCKiuQaypdcJFGpLCqnxvGFIxTenbXRNKSdMQhUYjxXmAhBOYrwNRYcHqWSPxqXQFJxccxYDaowBNCNBRYOZpqbDXfUQUAugLZHbFrkaWZaDWTnJEQMurfdturnhGfLzsMdqYsETgrpZVhevKrsEdutkZHUiFbxVKfTlVTfTrBTfmKIDnDpjcoerMjXzhrYAPgVVfLrcEEdbqyOzJcldO")) {
        for (int NfJImM = 156229756; NfJImM > 0; NfJImM--) {
            continue;
        }
    }

    return jbAnG;
}

double vLbLbmuWGFt::tBlsM(bool gsoJePJMNYg, bool nnHsdvmCPGdin, double iEwLyRbFwxmENBJ, double oEKXqlkGOcUJ)
{
    int BzeuXMc = 1637690134;
    string dziHCUADkgCsnex = string("usXySpNrbzcaSpPTjMPJDTQqJMOhDtBQvsNMzAbZhvqFfEMuKytyKyNmijqrxXzKrNBroTatOGWJMPpvhnqJgeIcXtmFbXGOPqyJAWZjeuZXMQuwgUUBmYAhHRtSSELQUJxoyBwPoXNLiDIriGassshxoqzgnAj");
    int igymnDfDJOUE = 1150463696;
    double CyPJqTNRROYRZqp = -912213.6197699173;

    if (oEKXqlkGOcUJ >= -115108.64010468441) {
        for (int cHknPj = 80026203; cHknPj > 0; cHknPj--) {
            BzeuXMc -= BzeuXMc;
        }
    }

    for (int sUCDJEQclMTmNkZR = 2091936133; sUCDJEQclMTmNkZR > 0; sUCDJEQclMTmNkZR--) {
        continue;
    }

    for (int QIfIlikw = 855927601; QIfIlikw > 0; QIfIlikw--) {
        CyPJqTNRROYRZqp += iEwLyRbFwxmENBJ;
        CyPJqTNRROYRZqp /= CyPJqTNRROYRZqp;
    }

    return CyPJqTNRROYRZqp;
}

double vLbLbmuWGFt::ROVqiHS(bool ooJXVTo, bool LKciBqcSLoHjhChA)
{
    bool pyHBZOPdnxXebl = false;
    int lDvzceArXS = -1663834412;

    return -217475.63980617543;
}

int vLbLbmuWGFt::xcfdcjxI(bool JjdfHrJV)
{
    bool saKFOIKU = true;
    string nVZpCNSDH = string("gpbMPqfgfTqLSCLbaqQJSWOAjPIEatQGgmqSpZtBnaiYuqiXTUxhVyLnSPXWwgtiWvZCjbTXkqrVKFDoVAlDWQlnanNbZKitiduwWxzoAgETvYGnNPYkqKmXgWCASSMWmkKCYLxDmBBcUVXYiLghARZFAdxkQPJmMjQsAAMljCWajzzlxbWFrEIekctOCCrVlHIBdoRjUljSiBltfWEVCnxhMXQiXzWwIfqrdszMMDUmEDNOuhUdoFoththJAp");
    bool kXJFFEYZoA = false;
    bool HSgtqYlBdnKV = false;
    int dAAoRlMsUMmiU = 759694819;

    if (nVZpCNSDH == string("gpbMPqfgfTqLSCLbaqQJSWOAjPIEatQGgmqSpZtBnaiYuqiXTUxhVyLnSPXWwgtiWvZCjbTXkqrVKFDoVAlDWQlnanNbZKitiduwWxzoAgETvYGnNPYkqKmXgWCASSMWmkKCYLxDmBBcUVXYiLghARZFAdxkQPJmMjQsAAMljCWajzzlxbWFrEIekctOCCrVlHIBdoRjUljSiBltfWEVCnxhMXQiXzWwIfqrdszMMDUmEDNOuhUdoFoththJAp")) {
        for (int ByqCPFMEVYvFml = 234712252; ByqCPFMEVYvFml > 0; ByqCPFMEVYvFml--) {
            kXJFFEYZoA = saKFOIKU;
            kXJFFEYZoA = ! kXJFFEYZoA;
        }
    }

    if (HSgtqYlBdnKV != true) {
        for (int ZcmqElIH = 70599758; ZcmqElIH > 0; ZcmqElIH--) {
            saKFOIKU = ! HSgtqYlBdnKV;
            kXJFFEYZoA = ! HSgtqYlBdnKV;
            kXJFFEYZoA = HSgtqYlBdnKV;
            JjdfHrJV = ! saKFOIKU;
        }
    }

    for (int NLGyljOj = 815615112; NLGyljOj > 0; NLGyljOj--) {
        JjdfHrJV = saKFOIKU;
        saKFOIKU = kXJFFEYZoA;
        kXJFFEYZoA = JjdfHrJV;
    }

    return dAAoRlMsUMmiU;
}

double vLbLbmuWGFt::lCLyLsdyh(bool hVMlZkqleEkVe)
{
    int DAZWpNW = -1814591270;
    double GihXIVVlYZsE = -25820.212384992275;

    for (int UFScby = 73442338; UFScby > 0; UFScby--) {
        DAZWpNW += DAZWpNW;
        hVMlZkqleEkVe = ! hVMlZkqleEkVe;
    }

    return GihXIVVlYZsE;
}

int vLbLbmuWGFt::udSaCpO(int ELahP)
{
    double GZskP = -648008.9829706325;
    string LvAbJwPL = string("WdQlVJEWppsoGvIehWFqIkqQlfIzdFgVCuuZPziZgdRLshRMyEYYUJQOVgNmCPoXKwEIXIubQozmhYrKKPEihAfAjjlLahKceskfTqnGgdTciLrEAwLfrBIWUDmJwHCgiFsSxsTQfQeVJEdNUjTyemBjMDHOpEIQlDLgASSAmBjjrzfANvrUbXFRvgnTYeDNDweSAiolPQGcpuIdMhXfqUH");
    int bTZawviQ = 692448351;

    if (ELahP == 1418111761) {
        for (int kxMtrOLbYEh = 962325685; kxMtrOLbYEh > 0; kxMtrOLbYEh--) {
            bTZawviQ = ELahP;
        }
    }

    for (int GvlZN = 492679313; GvlZN > 0; GvlZN--) {
        bTZawviQ -= ELahP;
    }

    for (int JelOAmZ = 2008311680; JelOAmZ > 0; JelOAmZ--) {
        ELahP /= ELahP;
        bTZawviQ -= ELahP;
        LvAbJwPL += LvAbJwPL;
        GZskP += GZskP;
        bTZawviQ *= ELahP;
    }

    return bTZawviQ;
}

double vLbLbmuWGFt::tbtUJSs(string HuodjRj, double oRTXSNlxKQxu)
{
    int JpLWwZNFfKUc = 1355736907;
    string hapkZ = string("HzDpLIrCKoNNHxMHgbnPmfMBtoTTNvCOBMcGEoOdXSXmxemGifnpNMQoNMOEjJFTmYMDgJlOgcKqSBjrLrpUApGiRTSALpqHovQpcZ");

    if (oRTXSNlxKQxu <= -630307.7291359572) {
        for (int UHMxq = 37740827; UHMxq > 0; UHMxq--) {
            hapkZ += HuodjRj;
            oRTXSNlxKQxu = oRTXSNlxKQxu;
        }
    }

    return oRTXSNlxKQxu;
}

bool vLbLbmuWGFt::cvEriSmVDVNRgSl(int HCwqAzrXilfh, double dxuaOgdO, bool QRkdFHsPavlUy, bool cXFYsevmYg, bool iaCPyOdpHSSvRI)
{
    int pljodcZFQVQ = 1712816356;

    if (QRkdFHsPavlUy == true) {
        for (int fmbMaos = 1197187237; fmbMaos > 0; fmbMaos--) {
            pljodcZFQVQ /= pljodcZFQVQ;
        }
    }

    for (int TtUBaRHTPic = 323891938; TtUBaRHTPic > 0; TtUBaRHTPic--) {
        cXFYsevmYg = QRkdFHsPavlUy;
        dxuaOgdO += dxuaOgdO;
        HCwqAzrXilfh *= HCwqAzrXilfh;
        cXFYsevmYg = iaCPyOdpHSSvRI;
    }

    for (int klBroUlFo = 725743453; klBroUlFo > 0; klBroUlFo--) {
        iaCPyOdpHSSvRI = iaCPyOdpHSSvRI;
        pljodcZFQVQ = pljodcZFQVQ;
    }

    for (int yXrQhUhYWLfbQdec = 868186730; yXrQhUhYWLfbQdec > 0; yXrQhUhYWLfbQdec--) {
        continue;
    }

    return iaCPyOdpHSSvRI;
}

bool vLbLbmuWGFt::PqBDRa(double utzKIXQu, int iiHbltLYaNDteyo, double AepsfygFT)
{
    bool xFiRRO = true;
    string sQCVXUgUzKymh = string("ZedpyaPybRgLzoYEvrQgqpVCMVDxbcVBYblqEJsnyafxsnGqtaBSztGLXCCcLSVMGGaEFBfModjUkATcWaDACXCcBdwqzyBxpYZQoouHSLhbEpEuELmEya");
    bool ystbrNmLGsMaBTBg = false;
    string tKeHBRlGJee = string("sWGxzEfXqrYmzBnmmZXineODSpTGobDPqAdISirEejsSNHYwVnnfpKVPDrccfhDbIdlRfQMOXFWlPcNjrzXZWVXAhbacsTxsNQZVldBrxZoQXscfDMAuYqN");
    int tSwSXjDPIYQiw = -1076481122;
    bool VMdyiAWNfnt = true;
    double ADTAzmUqdVgyCXg = 618314.4642313313;
    string UNNBzPMEFdDy = string("VtHppJAbelVSxUyHmiwmEofTigiRChZjqUyecilPazuWHPaCbJlZGKaNSdsiPQUXlBmLgdeTlwfJJoEPkiRJYVupqvGYWcLRulVcHeEKmeJKvmPZaXZIArkyMxdjHhtCBIuPTgpflbgyKXXDFDmTCLBfwkgbhhVDluUsXfKAOwgceUrrT");

    if (iiHbltLYaNDteyo != -1076481122) {
        for (int SisqEJNQMZOB = 978846979; SisqEJNQMZOB > 0; SisqEJNQMZOB--) {
            continue;
        }
    }

    for (int yllgHcGiyYzklI = 1820531038; yllgHcGiyYzklI > 0; yllgHcGiyYzklI--) {
        utzKIXQu -= ADTAzmUqdVgyCXg;
        VMdyiAWNfnt = ystbrNmLGsMaBTBg;
    }

    for (int FmMfsSrYjNzZyJCz = 764053214; FmMfsSrYjNzZyJCz > 0; FmMfsSrYjNzZyJCz--) {
        ADTAzmUqdVgyCXg /= ADTAzmUqdVgyCXg;
        AepsfygFT -= ADTAzmUqdVgyCXg;
        tSwSXjDPIYQiw += tSwSXjDPIYQiw;
    }

    for (int eAiNjTAEZRlnsIkW = 689579482; eAiNjTAEZRlnsIkW > 0; eAiNjTAEZRlnsIkW--) {
        UNNBzPMEFdDy += tKeHBRlGJee;
        AepsfygFT -= AepsfygFT;
        iiHbltLYaNDteyo = iiHbltLYaNDteyo;
    }

    for (int dbDusWAx = 1525831626; dbDusWAx > 0; dbDusWAx--) {
        xFiRRO = VMdyiAWNfnt;
    }

    for (int bIDhNu = 1632516380; bIDhNu > 0; bIDhNu--) {
        continue;
    }

    return VMdyiAWNfnt;
}

int vLbLbmuWGFt::tCxMMyRvWskFhQoj(string UVEYlrEoUQBf)
{
    double UTEUndlyPZA = -984532.7304552348;
    int pyymUWLnPQbF = 1674647546;
    bool rpMCCKakLoaeLZc = true;
    int gYpMaidAF = 1179201146;
    string wUEqu = string("cyxxXCWDWrdgUAxGHlsKAkjVVBoZWCWJDHBzqZdHrVoxQlMVuAHmPcYqjsaHxOuCPMDsLICcPIjaOzhcUJHjfAZYrRgMeojQawxCSvmMWQgqONzYYlqkOpGVLsSaaGkvIHHiOXmRuboJiqnhKigNrMejOONjELAjMEIOhOoYqvrpfdStOyoadhwgSJfI");

    for (int HZOLMCXX = 724827955; HZOLMCXX > 0; HZOLMCXX--) {
        continue;
    }

    for (int LNLVhHhZZU = 849008967; LNLVhHhZZU > 0; LNLVhHhZZU--) {
        continue;
    }

    for (int OupIqCwUwtQQzslQ = 1130690726; OupIqCwUwtQQzslQ > 0; OupIqCwUwtQQzslQ--) {
        UVEYlrEoUQBf = UVEYlrEoUQBf;
        UTEUndlyPZA = UTEUndlyPZA;
    }

    for (int HooPiRo = 364766717; HooPiRo > 0; HooPiRo--) {
        UVEYlrEoUQBf += UVEYlrEoUQBf;
        UVEYlrEoUQBf += UVEYlrEoUQBf;
        pyymUWLnPQbF *= gYpMaidAF;
        UVEYlrEoUQBf += UVEYlrEoUQBf;
        UTEUndlyPZA = UTEUndlyPZA;
        UVEYlrEoUQBf = wUEqu;
    }

    for (int arssBvTMbJZo = 825698486; arssBvTMbJZo > 0; arssBvTMbJZo--) {
        continue;
    }

    return gYpMaidAF;
}

string vLbLbmuWGFt::HNoxDubs(double lDtTsNG)
{
    double XNqMlgBUojabJ = -979591.5876664293;
    int tvADfx = 1419438988;

    if (XNqMlgBUojabJ != 595022.2052307021) {
        for (int KUSfORZZtP = 1504892172; KUSfORZZtP > 0; KUSfORZZtP--) {
            tvADfx -= tvADfx;
        }
    }

    return string("gIghecdSqdPGGFNVlrgeOPrxUWpytGgCjxVOiTrlCKBumJDGBvDrNQUrBIxuSZZiRPTiPREVQTfbyQafBVxnenTyqmisnCSTCIZZcCPqWbXKDwydBPGwRwqVAeirLadOqvzFeNoJQninjTM");
}

int vLbLbmuWGFt::AvTOWWmWtVthrprR(string LNyQfqxTPD, int kmlhWexzfRuCQ, string QUTsEmKJwe)
{
    int fCKwayqNJa = 60871905;
    int uiXgfCbjaOEBwD = 753790650;
    bool zVSQxKCKxYcxq = false;
    bool gGRhkYYv = false;
    string UJxHzpifRPczHww = string("uXDYTEHZuwEPYigeuTptlXrwpeRTUpSELIXkjkqzijTmTqiHxQhxRSKKqTVoauWQLnRCoMyhZLSrSwkAJhFSKCkoGaPbJCzRLhLbjYNVcFhuIkPlVjWWHuUBJEIaiXvOnSdZdNAsyWJrbPkcunvyPsdHluYPcxZmPgOddHGfLRyrUqkArbjAoUVobPKyNhtLvrNOfcfMZHSGzZFIcRIkCTTvpsRTPpoYlCICnzTWnQhHVlKDbxsaespdGY");
    int pzDqoBQR = 790892188;
    double AXLQz = 751148.6156013092;

    for (int ELyWJoXkskxs = 37988169; ELyWJoXkskxs > 0; ELyWJoXkskxs--) {
        continue;
    }

    return pzDqoBQR;
}

string vLbLbmuWGFt::uWmbRk(int tSVBaVH, double KnElCZysgMMHJALV, string DvaChEzkubddeJl, string dZIptkcUSzeMd, string DACuIUlQJFljT)
{
    bool JygrRJEpo = true;
    string SdHLIuvOXkCdXal = string("fdhMZovSVIYxPMNjUrZQpyDfppmODTrnXEaGCnOtmPTGeThZPhifmMzbqvqcaldUBjUOZzrhzJHYJWKKHEVdMfXLhApEpylVUYrGMdtPnWApnMToDtEDutUhUsMGfOXOEAwjZEpVeMjwfPFhqfOPljonrKwFpZXAyMWCdBEOYIgW");
    string GMGeAAe = string("eGlbifhbJvVvTSPhJiEVmXuEpJCwIQnpMAVFpTdApwAzIoAkpwRU");
    string bjhxsbyE = string("CXTHYcNjqVxJuIzvM");

    for (int kzqbYxDfGQktYahj = 1661528010; kzqbYxDfGQktYahj > 0; kzqbYxDfGQktYahj--) {
        SdHLIuvOXkCdXal = DvaChEzkubddeJl;
        DACuIUlQJFljT += SdHLIuvOXkCdXal;
    }

    for (int TYXqmMqvqykpPL = 468166591; TYXqmMqvqykpPL > 0; TYXqmMqvqykpPL--) {
        SdHLIuvOXkCdXal += SdHLIuvOXkCdXal;
    }

    if (SdHLIuvOXkCdXal <= string("EDDFeUfWWLLanMxdUhtSiluClbtNsqeKuXuYvntjOZyrOobNbeveRaCJplGWcMmjVvLkgkjwdOAuicSYXliMXpkXHcIhJUPelVOGlnKFbQvUlljrUwgQwUpDxpGsTPGmGBkgZle")) {
        for (int iUyHqGERIl = 419199295; iUyHqGERIl > 0; iUyHqGERIl--) {
            DvaChEzkubddeJl = SdHLIuvOXkCdXal;
            bjhxsbyE += bjhxsbyE;
            KnElCZysgMMHJALV = KnElCZysgMMHJALV;
            SdHLIuvOXkCdXal += DACuIUlQJFljT;
        }
    }

    if (JygrRJEpo == true) {
        for (int krmJimfjc = 308745538; krmJimfjc > 0; krmJimfjc--) {
            tSVBaVH /= tSVBaVH;
        }
    }

    for (int BMuRSpXbYdDZPd = 1969817069; BMuRSpXbYdDZPd > 0; BMuRSpXbYdDZPd--) {
        continue;
    }

    return bjhxsbyE;
}

int vLbLbmuWGFt::qTzmmcS(double HMEwVWISoeP, int yXqiGBiZiutOlxVU, double hNyCViRMuRLIkwO, bool YbbwHWlSXM, bool EmUMuzWnOYIVyzyp)
{
    int NVxwJIF = -1498412657;
    bool FFsNvPZFpcn = false;
    bool DyIsdKpyF = false;
    int UBtkVZ = 1939377934;
    string tgXXQsbnhkyiycml = string("HoTebeKzgQQsonKrzTmbnBeMMiNFcCyuMhTrPuahIGSKSZPfgDlFTweXTqqrIWxUjnmIuPhYRhTCifgQvdzDxZTLFOHCvWTRSKlZifWAgikUWwzaoHIGKHfAzeqDnXhucGoFjMlRxAKSsZjavBtbKgylueOCvFlIlNrQriBDYAEEZkuPKbCwLBVhQvnjohXmiOTlVzQRlluiIOAQlgdVQMcSNTTcOdGQaYZOoNxaQhVcBKUrfB");
    int zpCdNYKryFXIOmG = -274444868;
    string mKLhuk = string("bSqNdnDnFztRzkMOQmjgOVbsclNpORmjyzUrdrvVSIefMAMEeXhECDFtbfmPjdwoNgpJGEEgTwozQuDgaTbdLXzeLVmKbYcdyMCeYdUuUeeVZDRrECtqLIHquDUNiPmFeZMerxvLxJImSNTEGJNKkmZZuiLQGOzTgOGDKALQBOrcEXHbYWtfkakfzJyOiQrjZbXyfOIcNYwDVJKwEuAIwoMJWiAEnvRodSwWrXQOR");

    for (int YjoQbAB = 1542963886; YjoQbAB > 0; YjoQbAB--) {
        continue;
    }

    for (int SllTm = 545831426; SllTm > 0; SllTm--) {
        zpCdNYKryFXIOmG -= UBtkVZ;
        YbbwHWlSXM = ! FFsNvPZFpcn;
    }

    return zpCdNYKryFXIOmG;
}

string vLbLbmuWGFt::hyyLIRuqhgR(bool JVTpqHJYdx, bool InlIhzontz, bool DRwWDbNgdBrZR, string peuwlrLARKYvu, string tyvfHQhTEH)
{
    string fnvCXok = string("QIXHLqrFzqoiJFuTKDvYUUqquGCtJjbdZDUHJVvOgOLfnTJOhSPsvOBmKlKqddxhejGNnOIEuvNmEsUxmZGbevfMKJxs");
    bool RNcKUCRwIPcUw = true;
    double KWFCXczzUQrD = 776208.3902215672;
    double rZDpglju = 176602.91414116582;
    bool LxBfNPhN = false;
    bool ZrsgBqMPKKNGzEac = false;
    double YWzQtr = -134139.01667293144;
    int GIidMXdYbRT = 428744961;
    bool GVerPA = true;

    for (int PNnLWkYEombXaj = 831119729; PNnLWkYEombXaj > 0; PNnLWkYEombXaj--) {
        LxBfNPhN = RNcKUCRwIPcUw;
        ZrsgBqMPKKNGzEac = ! RNcKUCRwIPcUw;
        RNcKUCRwIPcUw = ! ZrsgBqMPKKNGzEac;
        RNcKUCRwIPcUw = ! ZrsgBqMPKKNGzEac;
        rZDpglju /= KWFCXczzUQrD;
    }

    return fnvCXok;
}

vLbLbmuWGFt::vLbLbmuWGFt()
{
    this->nBsbywvF();
    this->gmpjM(false);
    this->QQZsXuEGoIU(string("OlJmZGzTgWhpTonOKfeYZGIWyMjZbQvigEuBluJywhAZnawsyYeqDomMtJTPivQuyPlvPvdOPKVeYmhNHlYbNObTCYbYaIfNHRQfmyYoSfTIaPriiVFAvnyiLImTJdvFclaMSrEkvaoqFZJhfLiWgMNCqjrvazFyRjhJZixMTgmEhfqxIZjZWkHXbiJcXEQyDFBFNnyzyDpiaPkMOgKHqbQAOeWhMAVoWVEYSgybHb"), 942180622);
    this->scshnwYtKcl(595278.0976137331, false, false);
    this->kgmShnu(string("gZfyrvaWoBQpmweTWXhjPjHoetrTTtcdrmSxndYjxaQWZpZwQrFNpWiVRwqqHKOaQKSrGlHWmiNRsAFsHODBsCguBPBBHsIkHuHUGJAOAJeSUWwDohQCCxSXHjAGRHRCchjycpxPWUJlNZQCiafkEsVKSPkAloNmypBJkgzVsFKmVxaymrkmBUmDUkPlMtzVbNvZsJSoLwMDpHiFqKZVsNEBywRPfdQvPIHTplJxwkhpqbfPM"));
    this->uTobzipUsa(true, -12000.14347074129, true, true);
    this->tBlsM(false, true, -903259.766635374, -115108.64010468441);
    this->ROVqiHS(true, true);
    this->xcfdcjxI(true);
    this->lCLyLsdyh(false);
    this->udSaCpO(1418111761);
    this->tbtUJSs(string("brPHuuXfDOhtqdTfhQJdXfzVwWgiYgOoCqfqJSHzgAeEoUJYzPqdVcKOPxUnKcWFPwjWpoozELTHzfIPkcvrLLTbAtpIQCpmHRdXhSBWUxCCEmnSFBJAlqGchYLkGjVaxUReXgeNxMjFLDWBeButGRfhsaXQXyppPZ"), -630307.7291359572);
    this->cvEriSmVDVNRgSl(727625864, -878091.8954696641, false, true, true);
    this->PqBDRa(-686742.6916240104, -2051920037, -941257.9803560021);
    this->tCxMMyRvWskFhQoj(string("tOfzzzYsVPiPURFNmefmOMfIrwZpaFGMeXdFgeNivhuWBRQzysFsWbsWpomlvMrmfTZbdGGuiCiINHGubluvbPhrpuNltfHxewExMMxdaxhqXzwVWewalbQkVkpbODKmgLReImnTHeJpjNCmzVXWzLrhyM"));
    this->HNoxDubs(595022.2052307021);
    this->AvTOWWmWtVthrprR(string("nHtdENLJpNUQgXwvoDitbTnVTsiqMgtRVJFNzkKGBvlwlnwnGIJCuyohasqxusfYojeJTPAhxTFjeqrrJpZPYhdapWXJZPkXrPwLVsUlrDzAPPTTCmcSEtTQKkJrlVgjloHWOotrzrWjZGfepuLWGpmQrxAQBbuEMuuUfklAfzZqCLxkespMmCiqlIwDeSMWozyKNdtLEHcwmaoIkbB"), -677819767, string("VczKgEWjSenDNJyTWtjmhNfJehbeqVpDjfovLapKKZQbZXTSjKaZuLwzZVaWPRc"));
    this->uWmbRk(-1309068282, 415730.79972801346, string("EDDFeUfWWLLanMxdUhtSiluClbtNsqeKuXuYvntjOZyrOobNbeveRaCJplGWcMmjVvLkgkjwdOAuicSYXliMXpkXHcIhJUPelVOGlnKFbQvUlljrUwgQwUpDxpGsTPGmGBkgZle"), string("C"), string("FiTXvPAVjBY"));
    this->qTzmmcS(768683.3100773414, 1662140025, 507866.1242602285, true, false);
    this->hyyLIRuqhgR(true, false, false, string("WmbrGjGJUsPavLDAjQRcFCgkeVeExADLdscWvDDFMwtBNQDYVLOleSIguViJbIDOiWkTXJwDysJTZzDPUvJxFcotTIjVBpHdFsvRXYSwhmxviLjcjJrKpRyZRXldhGxohJVoZfQuxUtaBuEJoseWfAEaFJiQOQPtVCeYOyeUjdDkVnHQHEynESPaZappdTKDrpvxuXqjwhIgLkMLcmAUqKY"), string("oHEHzemVOAuunWUztDABEmvVoVuNwFexEwffDlWqIgDCqcTFeZTvBexEWjOyioFCSmkzLtzHOnjj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MLAHlk
{
public:
    int PEgmdJIiY;
    int oeIfNxKRtlYdLu;
    double AzJUBBeRhjoBfrq;
    int tYUfBFh;
    double OZWtOfgcZdD;
    bool GNUCP;

    MLAHlk();
    double AzgwZpmSl(bool MjoSICsigGkIiy, bool vdZndwnKx, bool SxwtdiHHAZvTqkg, int EczHI);
    bool iitpmXNnQhgCyTD(double DNzrk, int zUGXEjQRVXGqwEL, bool krRRJWSsXIxKb, string qFBnOlBCZxuO);
    bool rYpogjyRvpr(double qniOYRRrNnWfY, double WPBeHRPmxYHOo, double BtCiYLfgnuTuQI);
    int uWSFWaQnZNGI(bool jMVjINtaQjtcyB, double yAlBblCpZKoy, string tPytRfN, double kjGMQILIuBy);
protected:
    int kMrNeeg;

    double eIqyTNybEArkxEW(string wTdoEteb, double mhhXGXndlTgJQ, bool lNDotzoeisTVwIAG, int oSrAiBbfpkOgmow);
    void VzDdvlUmYIDABMM(bool IGmdiRhuVGjXDs, int XyLPXRiEElWT);
    double aseWo(double hkylblqjnUWXYXAV, int dYHOEtymq, bool RHXkbhzAzt, bool rXGoqBMrrGCG);
    void cfbFxP(string ecmfJGYMeBirAnH, bool riLlGO, string JuHVnCJSNx, int geqvkVxokY, double YeUqGqxT);
    bool drTQlaYbAydWJ(string MUzho, double lFnWsMJAP, string xZQkerxLNGLw, bool omWhShoMFDQVbu);
    void mBSsCcWGB(bool JkMMYuQlaYrnQ, bool johunGlYqmk, int RhzfeVeV, double cXYNDtq);
    string WAafKScdqhJ(int wODraNgG, string vBTLATDqVSEuaH, int zpgYCfWibI, bool SmpaStpmtIkT);
private:
    double kgNaKDWxMt;
    double XcFdMy;
    bool kXCdSbuoNLt;
    bool EyRNReIVNKzOhb;

};

double MLAHlk::AzgwZpmSl(bool MjoSICsigGkIiy, bool vdZndwnKx, bool SxwtdiHHAZvTqkg, int EczHI)
{
    int hvcbI = 2136830817;
    double NOVZhIUiINdiwr = -243549.34159964137;
    bool LPSEU = false;
    int AhsWWoTrZrtWBElX = 1007092354;
    double lMsGZYEqfFrfm = 581765.7728336192;

    if (NOVZhIUiINdiwr > -243549.34159964137) {
        for (int cHwGuFhPxxbxU = 913982405; cHwGuFhPxxbxU > 0; cHwGuFhPxxbxU--) {
            AhsWWoTrZrtWBElX += AhsWWoTrZrtWBElX;
            LPSEU = ! MjoSICsigGkIiy;
        }
    }

    if (vdZndwnKx == false) {
        for (int oFShoqR = 2062640381; oFShoqR > 0; oFShoqR--) {
            MjoSICsigGkIiy = SxwtdiHHAZvTqkg;
            MjoSICsigGkIiy = LPSEU;
        }
    }

    for (int IoHdUsunpGylTc = 331730859; IoHdUsunpGylTc > 0; IoHdUsunpGylTc--) {
        LPSEU = SxwtdiHHAZvTqkg;
    }

    for (int pmPVhkvJu = 627668336; pmPVhkvJu > 0; pmPVhkvJu--) {
        MjoSICsigGkIiy = ! vdZndwnKx;
        MjoSICsigGkIiy = ! MjoSICsigGkIiy;
        LPSEU = SxwtdiHHAZvTqkg;
    }

    if (EczHI == 1007092354) {
        for (int HagpL = 1236502859; HagpL > 0; HagpL--) {
            MjoSICsigGkIiy = MjoSICsigGkIiy;
        }
    }

    return lMsGZYEqfFrfm;
}

bool MLAHlk::iitpmXNnQhgCyTD(double DNzrk, int zUGXEjQRVXGqwEL, bool krRRJWSsXIxKb, string qFBnOlBCZxuO)
{
    int EjfQMxEDKn = -1912454114;
    int kPwWb = -922917936;
    int ZBHmQpb = -1275370744;
    string xtVCSiGjqFPu = string("LwdXnjBBsNuJzDWJcapqGKSLWvCySNYRuAxPQRLziFOQPCsorXQTbucXHmffdujhMnuTexhXFDmgkBaaVgscyPsbbSTWmkGKwZahlaLoTsMDqRCkRaAnXXcyISlfqDUxEncrvEPPbizRHEIFYRvrZZjhvj");
    double nLxBid = 312502.30765360803;
    double JFGZXwNtDfV = 708548.6523556411;

    return krRRJWSsXIxKb;
}

bool MLAHlk::rYpogjyRvpr(double qniOYRRrNnWfY, double WPBeHRPmxYHOo, double BtCiYLfgnuTuQI)
{
    double iEKIoXtXC = 1027179.9290632725;
    double RhHfzWQQtwvlA = -1001255.7885472272;
    double KBiasGAHcqyVuxe = -29208.86133751347;
    int KEDnSHzlzCltx = 334262723;
    int AAQoQG = -296046015;
    double dUbeugyLkjaRxAZ = 913757.9811619737;
    bool MjszhnCwy = false;
    double WemlKTRGAqNfT = -555141.568587692;

    if (BtCiYLfgnuTuQI > 693576.3577789355) {
        for (int gDQxLzhwhmPl = 784386842; gDQxLzhwhmPl > 0; gDQxLzhwhmPl--) {
            qniOYRRrNnWfY /= qniOYRRrNnWfY;
            RhHfzWQQtwvlA /= qniOYRRrNnWfY;
            KBiasGAHcqyVuxe -= WemlKTRGAqNfT;
            WemlKTRGAqNfT *= WemlKTRGAqNfT;
            iEKIoXtXC += iEKIoXtXC;
            KBiasGAHcqyVuxe += WPBeHRPmxYHOo;
            RhHfzWQQtwvlA = iEKIoXtXC;
            RhHfzWQQtwvlA += RhHfzWQQtwvlA;
        }
    }

    return MjszhnCwy;
}

int MLAHlk::uWSFWaQnZNGI(bool jMVjINtaQjtcyB, double yAlBblCpZKoy, string tPytRfN, double kjGMQILIuBy)
{
    int lfwNjEK = -1554966670;
    int DVXZNtBuqxLDN = 1363726719;

    for (int MSveepMFuMsBN = 866078600; MSveepMFuMsBN > 0; MSveepMFuMsBN--) {
        yAlBblCpZKoy *= yAlBblCpZKoy;
    }

    return DVXZNtBuqxLDN;
}

double MLAHlk::eIqyTNybEArkxEW(string wTdoEteb, double mhhXGXndlTgJQ, bool lNDotzoeisTVwIAG, int oSrAiBbfpkOgmow)
{
    int RgfLrDx = -857820324;
    bool dgoWcUvkR = true;

    return mhhXGXndlTgJQ;
}

void MLAHlk::VzDdvlUmYIDABMM(bool IGmdiRhuVGjXDs, int XyLPXRiEElWT)
{
    double rFbHyItf = -448067.41430559964;
    string YskOuOXuAhM = string("lLAYutmaTdZSYLMhdpXHCNNapENENfJumCDXGRytcmDHvwObJMqahEtOZFMsgZSVYPTYfMEBaDdbvJMzmnvWbxihniuipYCyJsyrofbHEIPvOzlxAAnSCshCHqRdBodiBogiHQkeAgiylDGWqOpekwtcDehuvBDqkxpkHqIQyBlqqbQDchzOCSmccGFuRsaAJZXwZeGtRjIjGamPMCinWevkKPbEOKqNjToOeaPMRwNNaR");
    int daiijEfUiNM = -848694386;
    bool EavyzGyYHIMv = false;

    for (int jjxCKxVrWoSTS = 118131577; jjxCKxVrWoSTS > 0; jjxCKxVrWoSTS--) {
        continue;
    }

    if (IGmdiRhuVGjXDs == false) {
        for (int RbmtqZYo = 556401679; RbmtqZYo > 0; RbmtqZYo--) {
            EavyzGyYHIMv = IGmdiRhuVGjXDs;
        }
    }
}

double MLAHlk::aseWo(double hkylblqjnUWXYXAV, int dYHOEtymq, bool RHXkbhzAzt, bool rXGoqBMrrGCG)
{
    double KxdVYxdXU = -115760.02670958092;
    double GGbmipXAevf = -720244.980127917;
    bool WlDuc = true;
    bool JXBXAKlvk = false;
    bool ioTVS = false;
    double rBZzqKabYYHvju = 194303.2627290526;
    int EVXnMw = -70800777;
    double IuFvRyhCR = 745459.5301084954;

    if (IuFvRyhCR < 745459.5301084954) {
        for (int jPIlBeEvzmMp = 791339621; jPIlBeEvzmMp > 0; jPIlBeEvzmMp--) {
            continue;
        }
    }

    for (int QvMhceY = 1952001943; QvMhceY > 0; QvMhceY--) {
        hkylblqjnUWXYXAV *= KxdVYxdXU;
        JXBXAKlvk = RHXkbhzAzt;
    }

    for (int PTlutZVdUVVUf = 1913366607; PTlutZVdUVVUf > 0; PTlutZVdUVVUf--) {
        IuFvRyhCR = hkylblqjnUWXYXAV;
        hkylblqjnUWXYXAV -= rBZzqKabYYHvju;
        IuFvRyhCR /= KxdVYxdXU;
        JXBXAKlvk = JXBXAKlvk;
    }

    for (int xvWMARspqgNvzNLl = 2069103198; xvWMARspqgNvzNLl > 0; xvWMARspqgNvzNLl--) {
        KxdVYxdXU = hkylblqjnUWXYXAV;
        KxdVYxdXU += rBZzqKabYYHvju;
        rBZzqKabYYHvju += hkylblqjnUWXYXAV;
    }

    return IuFvRyhCR;
}

void MLAHlk::cfbFxP(string ecmfJGYMeBirAnH, bool riLlGO, string JuHVnCJSNx, int geqvkVxokY, double YeUqGqxT)
{
    double QdzCUeRAYJdcvHru = -287287.0600396488;
    double hwCVQZiTqijSfj = -801415.0578018208;
    double RnRwLAeboYO = 104348.89885498951;

    for (int rPxwE = 222819983; rPxwE > 0; rPxwE--) {
        RnRwLAeboYO /= YeUqGqxT;
    }
}

bool MLAHlk::drTQlaYbAydWJ(string MUzho, double lFnWsMJAP, string xZQkerxLNGLw, bool omWhShoMFDQVbu)
{
    string OoOqvnYDV = string("CmexRVnIpwSnGsMpzcoxZvTECCLbaNGIcBggCUPAjXYkMQFTIWTRybcVhJFMTQZtrlnvHqtjybTSAkiNkfiVwmRVYLhhkyyYUvjwnhhiFcowHJOUNelMkURtrUGGGAQljjqtcGHhWTsfoKaxuQSzVvGJsNVHOgM");
    bool EUnel = true;
    int BNaTx = 1383957073;
    string tDKotggWQGRIkrL = string("hlTifkkoKTNEqbCMlEEKoVAyyARyRKFwCdvKJsLhrBBQSmZubwyzMJUaMrjspdXJBktwynldaARltNEXkEqamqimWbsEafQherEyhQBEuOjHbZf");

    for (int SdiKiIUrZMvXGr = 835587594; SdiKiIUrZMvXGr > 0; SdiKiIUrZMvXGr--) {
        xZQkerxLNGLw = OoOqvnYDV;
        MUzho = xZQkerxLNGLw;
    }

    if (tDKotggWQGRIkrL == string("HfgrAUeLnsqeJvIcniJQOaE")) {
        for (int HNtmtq = 138481504; HNtmtq > 0; HNtmtq--) {
            continue;
        }
    }

    for (int SCPFCVOwxagx = 481571007; SCPFCVOwxagx > 0; SCPFCVOwxagx--) {
        omWhShoMFDQVbu = EUnel;
        OoOqvnYDV += MUzho;
        MUzho = xZQkerxLNGLw;
    }

    return EUnel;
}

void MLAHlk::mBSsCcWGB(bool JkMMYuQlaYrnQ, bool johunGlYqmk, int RhzfeVeV, double cXYNDtq)
{
    string zOPZZzTdlFl = string("dwmGxAdEEiOEybAKVRvILICnyMSYrcCnHvyxNqZHKgdldpQjCHKFwmuIHyoSuypCTEVvFQArMmzohHtpNfOAFMFavQYUlneEziNTgqyRhDwrZSdXzoGAfRrOCJPOZJoDTLSViNyTyvPVlOHPdrOqBPEzkBCdXmQuBxHNzOtSrCwfmOzNSOkWfNDUWsCLCiJvnckEHtMlVtpDtxdUAUhFMEWzlYHAAr");

    for (int NqRTs = 698451512; NqRTs > 0; NqRTs--) {
        johunGlYqmk = ! johunGlYqmk;
        johunGlYqmk = ! johunGlYqmk;
    }
}

string MLAHlk::WAafKScdqhJ(int wODraNgG, string vBTLATDqVSEuaH, int zpgYCfWibI, bool SmpaStpmtIkT)
{
    string jICYqrUg = string("XWVAQxuPsWKWgxDvvnCYscScYbfGuYCDMkWxKCdeEAZjMlShEdkiblTqEaClCdspJoqYBacelYtrugTrBEfEjvhOWyZgbwracaRjhDloGfHHZyIUAOljEUayEEXhQWIkIiQwMcZUEHvtERTLakVApPwNMPFEXeyMzwMSjwBAPkkVBCMzKExnrOiMJKhsdygldPxcJYFSTKTRMyzhIfcLLfoInJYWlWJnbQYbpFKEafQfsDWobJkuimPKECIQFg");
    int TCOoszYcKueKjrQ = 685464931;

    for (int pKuMnW = 213478482; pKuMnW > 0; pKuMnW--) {
        continue;
    }

    if (TCOoszYcKueKjrQ < 685464931) {
        for (int oKwQKoXUIt = 1031139324; oKwQKoXUIt > 0; oKwQKoXUIt--) {
            jICYqrUg = jICYqrUg;
            wODraNgG /= TCOoszYcKueKjrQ;
            jICYqrUg += vBTLATDqVSEuaH;
            vBTLATDqVSEuaH += vBTLATDqVSEuaH;
            wODraNgG += wODraNgG;
        }
    }

    for (int BfzakoSwQDCahuye = 1657577492; BfzakoSwQDCahuye > 0; BfzakoSwQDCahuye--) {
        wODraNgG *= TCOoszYcKueKjrQ;
        wODraNgG *= TCOoszYcKueKjrQ;
    }

    return jICYqrUg;
}

MLAHlk::MLAHlk()
{
    this->AzgwZpmSl(false, false, false, 1790868880);
    this->iitpmXNnQhgCyTD(209037.2752305774, 1384724935, false, string("fyJKInJcBnMBCH"));
    this->rYpogjyRvpr(-237641.14058279616, 74944.58167353449, 693576.3577789355);
    this->uWSFWaQnZNGI(true, 581742.3956201576, string("WVuChcgwWUChogDVsKyLptTlGAcpdKAODbuxsSHFfeVuBtVNhZeUWSNecTtGPBJqPrEmHMZkFofVZDNGSBrSTQDvoQbUdPTQRkpSEzjQxNdBWqQpYtegRVSyAEosboqAuZqxXXGZPvTwpTUUgnUUViMNDHVrXiommqibxspay"), 875050.1386697686);
    this->eIqyTNybEArkxEW(string("IhcxTVSAzAVmmJGWkuwiWqDsXSrAyZlwTIVJVSSBWlnOutcAIPTQJbpueCFSpxCdqtNDpDvCwVyzGjUhRkfPUqmVcdLqKdWVNdtXJWAYyKNnwNIPxUgIxWEFGyalxrZgYhQRowVLQUPXhXQSxziAGfuDLvtHVlNWZojtOKxgpCQCRs"), 869453.5539622492, false, 411279170);
    this->VzDdvlUmYIDABMM(false, -1996783959);
    this->aseWo(-275332.51693005534, 1072591056, false, false);
    this->cfbFxP(string("EpXLIigZLDpvJmfASPLmkCjdTBAQQcieiYTEDZMrbQYoQlsJuCrHEPOSWFWRVOVuoIsuJTVmmHZvAVE"), true, string("SyfoAJvpHHDEdJNHnYTpRNvbKhygLwKsDtSjlqKVFAjHMCUhNQnxSCExnBZgVoSIHQPaydBQmhhHOeHPFtmLVFlHbSxFwwMlOOxsDYKfUsqkRcPyBwtgtCsgTcXMXvhpaOCMKKqyxKWXJvUlwHiqsZiIqqU"), 1772415185, 366482.3734824037);
    this->drTQlaYbAydWJ(string("HfgrAUeLnsqeJvIcniJQOaE"), 843913.6338052871, string("jgviLFAZyGZVemhxzZkIFATaaNOxUlvfg"), false);
    this->mBSsCcWGB(false, false, 977051528, 692532.008039065);
    this->WAafKScdqhJ(809494811, string("vNvrdnvkOydubewXGazGzTYduSFzHvEMznqpDbZskhOuyJbatHiJSbNVZpwNwVwlxXWaAJDtQrOwKgmNNqaFvadxcXQdcqDUVniWYhRbymxjLGHCWOngwcLhejoSldQxDFDBhuSNLqBKGvLxgwzEALBKZqtXRDWTMtZSbKBPMYwcFCqpMzLARCJqd"), 1820329136, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kVDUXGgtEAOpYcc
{
public:
    double ZPUFNlCwmXDJiJ;
    string jytLlR;
    string UaLfyrjoWa;

    kVDUXGgtEAOpYcc();
    void iGzuvUvAOxvc(double iGBekZKPM, string xcvmulaw, bool jqiGws);
    bool KDpIzfq();
    bool KjKrK();
protected:
    string OfaSzZ;

    bool HuvasSJZBxmi(string jjDcLwpjMSGwoF, bool QUaMHpNdapwHV, int UuKyQcNK, int KKKGuDPQ);
    double NOfePQfEUnBUK(int WNjGRDEcCBjM, string VqxPqM, double HfJEAdQ, int pEwabsLG);
    void DfIQKMFuQGP(bool xJmtFjtlkGl, string EFBYXdPTMOoEq, int XMLvZ);
    int DbhPCrL();
    int eKtkJGyVfiOGVdsk(bool aCGBCFMsKdz, string vAGNDocHhhdUAF, bool UHPHkPjVAqhniH, bool PCaGPGOlrLUOMSq, double VmGIfMC);
    int VWCpaywDyl(double urhnMMq);
    void RSRJi();
    string tCFZsW(int QRoLxswNfqUIC, string DVoOTWTDFaqpTjZX, string ogRGJ, int UwqJtfhZSj, string gDaJpfV);
private:
    bool YAQfQxSlUWRdYSY;
    bool UCCmzRhSH;
    int WUviCflLb;
    double BEqMapkwkQ;
    int AWxUxixhaJvqN;

};

void kVDUXGgtEAOpYcc::iGzuvUvAOxvc(double iGBekZKPM, string xcvmulaw, bool jqiGws)
{
    string FeeDtNDGgHu = string("oGnlrKxMWAcWsDiugqjUYCqsFgastEKYnAOsPICwaXxBzJvMZlByXRLQeUziqTwHqMJPSbDxnorUhmFSnsZSQBcKBIFGRJqnAHfYXOSOwpqySmHSqygEGxFyFNDsobZMbPQRnGOSKCBMCqfClxzbxkAegohqIyJJoQTPdOvafBNJvXuLqPeVrcWveeqbdZVBkXEd");
    double JNDlHNQprZjk = 352064.8608775523;
    int vhEvWYbTS = -2013158970;
    int rBRuOqEhc = 1921985802;

    for (int rjnxnkndDqtbvI = 828292247; rjnxnkndDqtbvI > 0; rjnxnkndDqtbvI--) {
        continue;
    }

    for (int zXPsVeduF = 1381448997; zXPsVeduF > 0; zXPsVeduF--) {
        FeeDtNDGgHu = xcvmulaw;
    }
}

bool kVDUXGgtEAOpYcc::KDpIzfq()
{
    bool dKIeFSSQy = false;
    bool ofMdPJgklV = true;
    int OIAHhqrACUC = 2136169180;
    bool MWizciap = true;

    if (dKIeFSSQy != true) {
        for (int iuhMaOfNXUPvCWSG = 1077921601; iuhMaOfNXUPvCWSG > 0; iuhMaOfNXUPvCWSG--) {
            dKIeFSSQy = MWizciap;
        }
    }

    if (dKIeFSSQy == false) {
        for (int iDMoK = 1228787622; iDMoK > 0; iDMoK--) {
            continue;
        }
    }

    for (int QClXJeIjyzysXvI = 2129254565; QClXJeIjyzysXvI > 0; QClXJeIjyzysXvI--) {
        MWizciap = ofMdPJgklV;
    }

    return MWizciap;
}

bool kVDUXGgtEAOpYcc::KjKrK()
{
    bool qsHTauAm = true;
    bool VljGXoXIinz = true;
    bool hfzMsnkfZ = true;
    double kYiEnVnmEK = 814533.0691351073;

    for (int XFdjeulpWF = 1106459714; XFdjeulpWF > 0; XFdjeulpWF--) {
        hfzMsnkfZ = ! VljGXoXIinz;
        VljGXoXIinz = qsHTauAm;
    }

    return hfzMsnkfZ;
}

bool kVDUXGgtEAOpYcc::HuvasSJZBxmi(string jjDcLwpjMSGwoF, bool QUaMHpNdapwHV, int UuKyQcNK, int KKKGuDPQ)
{
    string RMkLMo = string("lrMHxiJAOFkkYKAFWGWetUqAMmeViPOQNpzXusguDutWJtOhdGtmdTtVVAgMYDzJrFZatKrj");

    return QUaMHpNdapwHV;
}

double kVDUXGgtEAOpYcc::NOfePQfEUnBUK(int WNjGRDEcCBjM, string VqxPqM, double HfJEAdQ, int pEwabsLG)
{
    string QRHDFCzrydJBfC = string("kpCVsWGSQjQObGfQXoWINfbUkCyzPbavvNxTJSDIRdwyVwwNhyXCxgOnWKhgPqkCYyUiaXwbyaTyPWAEEqFgAcyovOtXoZwxzpQtvfLNljNmdRMlfDGyEtgxSJuYtufskYdihDBJKjjPAUKAUXMVyDOioFWayTHKLIInSlZGqJMGVksezPXoE");

    for (int XRXaqKoUKJ = 1956412861; XRXaqKoUKJ > 0; XRXaqKoUKJ--) {
        QRHDFCzrydJBfC = QRHDFCzrydJBfC;
    }

    if (WNjGRDEcCBjM == -515154578) {
        for (int uwuyndkWAhxSVmQ = 940964583; uwuyndkWAhxSVmQ > 0; uwuyndkWAhxSVmQ--) {
            QRHDFCzrydJBfC = QRHDFCzrydJBfC;
            WNjGRDEcCBjM -= WNjGRDEcCBjM;
            pEwabsLG /= pEwabsLG;
            VqxPqM = VqxPqM;
        }
    }

    for (int ghLJtnPVNbMA = 1733652019; ghLJtnPVNbMA > 0; ghLJtnPVNbMA--) {
        continue;
    }

    return HfJEAdQ;
}

void kVDUXGgtEAOpYcc::DfIQKMFuQGP(bool xJmtFjtlkGl, string EFBYXdPTMOoEq, int XMLvZ)
{
    double lQJCrikAgunR = 318885.1623031756;
    int BVVpbY = 477213506;
    double FJuYkCy = 450759.445357058;
    string XazcfgJuT = string("vIdddybpYciQQxNJ");
    bool lHmbWTyzCAf = false;
    string QixFhdqr = string("fdKLqsNQJiyccigtekSfeYlUEipfCzdnjBXavjELIBhNkhWrcFxCmUUHkQufFKOPWxwmjPKYpuYaZjkrvznYjhQtnxjPgAJKvWtfPjMpUZyNTBcOnyhebKHPAzXVViQGjTtaSMGGPihAZMceoXibYPtCip");

    for (int nJiJjQX = 206878796; nJiJjQX > 0; nJiJjQX--) {
        lHmbWTyzCAf = lHmbWTyzCAf;
        XMLvZ *= BVVpbY;
        XazcfgJuT += QixFhdqr;
    }

    if (xJmtFjtlkGl != false) {
        for (int yRCMu = 665630298; yRCMu > 0; yRCMu--) {
            EFBYXdPTMOoEq = EFBYXdPTMOoEq;
        }
    }
}

int kVDUXGgtEAOpYcc::DbhPCrL()
{
    string HqDAJimJNF = string("YZRROVknRplDQRgpxWSEtHULKqLbarXdBNIqXyQIEhGKgjXQWJpCIWtROPeHlSKtjvfaYKEGhVuaXdPSfqtEysWaHtfVzUAsuhnjMCRDUPPKWRaxDNsCAusmbSZCGDwKqMJkICaRNREcYHubnREwgFDOmAnkfQoUWYPXTevRCbzMaTAgEWoVrDiYngUNvbhDadsEnGCYGGBzocRqiQEQLuCTSDNRLwjclLvqigjAteMNsZXgYIRp");
    bool csJtotKmHmKLzibm = true;
    double FsQrAnqkLULWC = -542903.5822812723;
    string tdFmGwfOpBuiN = string("FXSZOYfZPdFoVZTszJZrthxSFpRzLJYUrnDNcOJJKStrWjYPnDqKNCgKfulzKrOdWTCFSfHBnEFdyEMiKuAVYXErtFWXZBmHZUFgMMzMTTizgRtZTQkiRlPLQRddrsnITQBznHMiMejlzQLYRnWIWXfFnCOcbCHaDBpWvvdDRutxHLfiOnftFIxEHNWVXziYkURGoAgDTLmcBeFCSla");
    int dwVqjb = 1961582414;
    double ekdrHwTZVy = -416848.1601206754;

    for (int HeUmtUkKfp = 313794745; HeUmtUkKfp > 0; HeUmtUkKfp--) {
        HqDAJimJNF = tdFmGwfOpBuiN;
        dwVqjb /= dwVqjb;
    }

    return dwVqjb;
}

int kVDUXGgtEAOpYcc::eKtkJGyVfiOGVdsk(bool aCGBCFMsKdz, string vAGNDocHhhdUAF, bool UHPHkPjVAqhniH, bool PCaGPGOlrLUOMSq, double VmGIfMC)
{
    int KTNqEmqVNW = 129741399;
    double sJDxxOtMAr = -416869.0946344404;
    double BfvhnqEVhUEvmKD = 345470.17279122584;
    string YdOriZiJASMFQ = string("tHpFgvprmpfkVIjPCXZtKZIZZzujtdRCdLhefyLnFguPXhWCbZFcCkgqhrbnxXzajMZpyUcisbudsJsYuympNcGhuefegwaBPWDbRWolfNaexKAUEToBsRycxHcQtHUgqGLUwVuIgVVzGBZaErzskzrderYavMGmynWvpltKRVTIZfGBOBRjiEWxHQ");
    bool CyfaErDQYRVT = false;
    int KQFWpBADp = 1986420610;
    int ZgXWJOK = 1057577306;
    double EWQdOIqtoDlFHOm = -954548.9352549593;
    string fvCHXiHfCEVwAOyF = string("pgRHbsgTiuPlTVvgLRwTsegIAeKuaAiPDGNqIQQbpEyVMJLBBjuEbcNpBkFSsftcCHbYNQEQmfrCMWxQReRuRrsSnknyllZHXJpKTxhzJQmheuHsSbYhinxxQvjFtvczHmowwHmvekJrENIbgSTBKHyIVPyKZlvYcxrujTHrsThBBfROZEkVDJlgiXMDyCzOmUoyqyUcrsUlrPwmcBugFhkMlxDaIDSXuU");

    for (int EbIVidWBA = 909690705; EbIVidWBA > 0; EbIVidWBA--) {
        ZgXWJOK += ZgXWJOK;
        EWQdOIqtoDlFHOm *= VmGIfMC;
        VmGIfMC += BfvhnqEVhUEvmKD;
        aCGBCFMsKdz = aCGBCFMsKdz;
    }

    for (int QabehDpyJua = 1041709241; QabehDpyJua > 0; QabehDpyJua--) {
        continue;
    }

    for (int tdEcAxIAhuhJZ = 230391736; tdEcAxIAhuhJZ > 0; tdEcAxIAhuhJZ--) {
        EWQdOIqtoDlFHOm *= EWQdOIqtoDlFHOm;
        KQFWpBADp /= KTNqEmqVNW;
    }

    if (BfvhnqEVhUEvmKD < 345470.17279122584) {
        for (int ByEdgFBYNo = 1830894079; ByEdgFBYNo > 0; ByEdgFBYNo--) {
            aCGBCFMsKdz = ! aCGBCFMsKdz;
            YdOriZiJASMFQ += YdOriZiJASMFQ;
        }
    }

    if (ZgXWJOK != 1986420610) {
        for (int gVyJwgotRTTUaj = 226461884; gVyJwgotRTTUaj > 0; gVyJwgotRTTUaj--) {
            continue;
        }
    }

    return ZgXWJOK;
}

int kVDUXGgtEAOpYcc::VWCpaywDyl(double urhnMMq)
{
    double XtQseYyY = -917207.1100468873;
    string OvfWKpT = string("TlrdPiqVUlpsYwQltBlSnXuFFjToEOavhEPclAFMdcnBRubmHYvfdvlaaazgNUcIuRqdVBStRwfFSQboblNKlkXVFsjMXfCOLxdMXyHuXwxSdwuvmLMWLrajjQmySlQLrYEIYoALUGtlVzuBjdhKmKIOAYIQmRxzSGXbtooPbeuozazUIIiyLMIyMUbnHysEXaZqpTKmxlGrwVRAFA");
    string bfnwLqZLcBep = string("LvxtzlJMHkDUDVgpXCLDAPTVtDaUlxMYjDVSwkoOgSFdXOljalbPjjTGBnwJBch");
    int xfGdOhydI = -1532202353;
    int asVNYnFQRvUY = 25333176;
    bool OxUyDiQTJzhOv = false;

    for (int DUGHOn = 920922220; DUGHOn > 0; DUGHOn--) {
        xfGdOhydI = xfGdOhydI;
    }

    if (XtQseYyY < 276620.02624482894) {
        for (int xnCpgZjxbdHqnxqO = 1666444463; xnCpgZjxbdHqnxqO > 0; xnCpgZjxbdHqnxqO--) {
            xfGdOhydI *= xfGdOhydI;
            asVNYnFQRvUY += xfGdOhydI;
        }
    }

    return asVNYnFQRvUY;
}

void kVDUXGgtEAOpYcc::RSRJi()
{
    int hQkKwyeNWnroiKTf = 1751659132;
    int IwicmlV = -1067770768;
    double lLcoLu = -844921.5985613909;
    double KPaJxPIcKaxJP = 887530.5065880275;
    string XvErzqkO = string("ANhVxOlPdLtJQuTOPTWSpPOcooBLCywEvzhkRKwwKiVAaArKSuMGMVGrrBKKLreMMviTFApIKirhSAWiHYSHjhkmelmOuTCpVQQqydOiuVcloqXWQbgxzdMgxmYzrEUZzbFyWdaVzTKuRcIhtSwEVFOguPWdPyKrRSQcKHLfrtflplckMyDehBXsntekmKkZYwHWMIspWQwiFSTCXZCQZuoADGagkgjMaHbBAcuLFHAvgXWMoF");
    string zrMZroXIIaNpw = string("lCchWLfdQ");
    int RPYNnt = 1500029211;
    double tLbaZGNUlSR = -433432.51287099713;
    int Lwijd = 286113607;

    if (lLcoLu == -844921.5985613909) {
        for (int IerUvZVbHGa = 199320838; IerUvZVbHGa > 0; IerUvZVbHGa--) {
            hQkKwyeNWnroiKTf /= RPYNnt;
        }
    }
}

string kVDUXGgtEAOpYcc::tCFZsW(int QRoLxswNfqUIC, string DVoOTWTDFaqpTjZX, string ogRGJ, int UwqJtfhZSj, string gDaJpfV)
{
    int fIcvlQZWbsvz = 794465323;
    int JGcWpIIHm = -263601271;
    int JNoIqvv = -2081955431;
    string mpYLjuMz = string("kEzFDeNvVsWBWfXiZqZSkLSCqwwgfONqoKZhYekxkTHafehstVoqyJQokT");
    int dvLqOLwHLPbnWMNJ = -854751894;
    double cFbYMmjsVUPSO = 270711.5101942999;
    double UtTyZMkhG = 427775.939252539;
    string BehucuJ = string("rsNdspMIIXGZLKnnDABjfNSr");
    bool hwaglwqseD = true;

    for (int wOGzWJxg = 1093414189; wOGzWJxg > 0; wOGzWJxg--) {
        fIcvlQZWbsvz *= UwqJtfhZSj;
    }

    for (int moqhQmdTPZC = 1145033803; moqhQmdTPZC > 0; moqhQmdTPZC--) {
        continue;
    }

    if (dvLqOLwHLPbnWMNJ == 156412906) {
        for (int YopCGcGjx = 1307082919; YopCGcGjx > 0; YopCGcGjx--) {
            mpYLjuMz = ogRGJ;
        }
    }

    return BehucuJ;
}

kVDUXGgtEAOpYcc::kVDUXGgtEAOpYcc()
{
    this->iGzuvUvAOxvc(-401971.48005875223, string("WfPjTHtatkBrdIOqmcmDeGPPDlDHzpWElRkUzTljqICjCgqeSUEoHPMXUeRhOtKmZCyLaBrDjEJrMoeSVo"), false);
    this->KDpIzfq();
    this->KjKrK();
    this->HuvasSJZBxmi(string("BwwVOUAzMWrXDXmSJDmEzSvdkscmglADOIyaCvZSzBQBxMxVAeyHAssaNsdMEpyVjMcMFfhjGYeeCyBNTIXvtUZMuKNmaDsyvUQvelWhNLfcJtwKjUoaTJpIGZPuveMHILZquMGwxRYaCWJlbVtsAsOTahhbPhoRvyvgokTRydcYpOBNfbpMdKcmjeCBQDefWmKVbEeMUVSFdcYSAwvowcJvZtvCrk"), false, 1110977676, -752924038);
    this->NOfePQfEUnBUK(-515154578, string("XsAtadNjRqRiHmADhkgbHiVdIFTWzGSaxyNiBDCAZxnktusgtZaUryYCQTefeMabPAPgFznRxRdaMSEkmAUsiJJubQLwJPpErcOihyT"), -859393.4796686904, -830800613);
    this->DfIQKMFuQGP(true, string("BHKjxaEFtaDoQoxgzFzQCMXxUqPDzhQXDFINBciOJkDtLynAyxWxdlGHSvJPpnuqwGOemVLcQwEHzuIRJjUOZrmPWOtxWchKpFYxZRnzqTSzgMEzxOggFfMHsOgiBgUHWvWpjWDZaRHEXGoUfAxNrUiTIs"), 1641530789);
    this->DbhPCrL();
    this->eKtkJGyVfiOGVdsk(true, string("SGwPIIrWaphAfJVREDKruhMsfeVmHAlHmFXZPCXEjeKWiBQeSfcDaOERCCoEuEQjqUpoZTsQXYLsnSqsHNoencbswHDZSKvJtOGlbGrDyARaIZWqotIIZaioKeoQzjmlLeLSYHBowLAwhYfJWWiLAmSkBXKZeKWHqHskNAcrVuWSLXafKChtQGWYgQfkIRvIDUHnZFjXBIsYfyawWJVQtPJijdlerndMmvhsp"), true, true, 484220.84096943773);
    this->VWCpaywDyl(276620.02624482894);
    this->RSRJi();
    this->tCFZsW(1630214898, string("gJDRVpbReeFoTWHNUHgakAYNEfEfLsYDyihdAVUNXAlEZvJCYytJeKrctgTbmoQZgblQLnYlVCidHzLgXlrPBzBGrAtNaDLCISMblbHmEsVGhMzpvqOzNjYmyVzhOgSOXtWK"), string("bHymvjphUDbdWFuqEjjeehHWOwTdOXVitJDCborljNrCqyQzJGGSeiozSeVujtESbgrWIpgGCOilSPKHzyBLxjwmXvIZJXWgVONdpIPEHNgqmnpXBupMnkGRajDXAsaEU"), 156412906, string("gpMQDHgmLWuuBgGrFjanvpcomoHCHpxPEWHuUOxxBFg"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NHmoPbPxsZDRM
{
public:
    bool lfPbUMlX;

    NHmoPbPxsZDRM();
    double bRDsxBhRkw();
    double wEotoWYzWfPPqu(int vndSpHCaBXdvpm, string lazRrcpzZbE, int ZoLAWrBJBlrwdL, int NAkZCiXcqETe);
    string HzjhJdG(double lcBuObJQLS, bool zxLFgsMcwbSosc);
    void LkwpZMp(bool XQSevY, double NWcckkNkzuaV, double IXicDoeBQeYynKKq, string WGmJXuWTQVzlcq, double zANYnuk);
protected:
    string kfVCicWdemJ;
    double oARyZnxaY;
    string WkCVvhdZYYZ;
    int YCCsggsSdj;
    double GPaEjfWH;
    int mHgqyQxqaDD;

    bool mWRuF(bool mQLiBSgobo);
    bool FtOzuJrPw(string GtskGWqqWht, bool zuRUSPaY, bool LmBgM, bool xAvAcadGa, string YpSXhm);
private:
    string CfhkmGPjPfPw;
    int OuUVOgBZmAtV;
    int GyGtHdqVSYxe;

    string aeGhBLigQaFKPn();
    bool FujuJntaDHRsqV(string utNaq, double LKPJcpbuGYj, int zqHDBb, double uwanMLwVMWOUHXl);
    string TiWeLtsYxdqOFbd(string KqfNQlE, bool rauTLqKdJMyToz);
    string oqDwPJnTmCM(double sQYpIDAtaZukTXB, bool WVnBjS, int foqHgBZqoBWddPKy);
    int GrMHWjM(double WSyTvbNIRNFLF, string nIhamefOxizrA, string WfunQxGmurGUH, string EVdeDqiLhlmwbHwe, string GHSzSykjwhU);
    bool dLruvT(bool eLUoHhZhOMGzlwc, string qqfZPgsnDooC, bool jUEGILhryW, string yqdfRHtMpl);
    void CeOevmxfFNoMYo(double FPWbt);
    bool YSdLXkazCgDYcxh(string ZkJaIbcyfjaJw, double WOpqHVCtx, double HWDGDltAJlIg, int XFwzkrGecdQO, string Qwcwr);
};

double NHmoPbPxsZDRM::bRDsxBhRkw()
{
    string gSheEoNmjKO = string("Jl");
    bool hGoswoT = false;
    int AHtgtUh = -2137827469;
    double OnlvKuuU = 701342.5338575542;
    double jZUSzskp = -598551.6418593915;
    double EVUtfv = -499916.73377518996;
    int JJzyjKcn = 1322191288;
    int ZmuhkAQucT = 2117500413;
    int zXoVovk = 334908257;
    int DjuvAlMA = -665849347;

    for (int BtwYGT = 1443707501; BtwYGT > 0; BtwYGT--) {
        hGoswoT = ! hGoswoT;
        AHtgtUh /= JJzyjKcn;
        zXoVovk *= zXoVovk;
    }

    for (int LgMWSBOuIdsNz = 1159179056; LgMWSBOuIdsNz > 0; LgMWSBOuIdsNz--) {
        continue;
    }

    return EVUtfv;
}

double NHmoPbPxsZDRM::wEotoWYzWfPPqu(int vndSpHCaBXdvpm, string lazRrcpzZbE, int ZoLAWrBJBlrwdL, int NAkZCiXcqETe)
{
    int akVOYyRUfip = -1426037000;
    bool LxOkiOT = false;
    bool HaYvfrqSdCK = true;
    bool hBdoypSlcwQTfc = false;
    double tyFMDczvGoi = -465307.05456283095;
    string sxWPvrGZPsTUIth = string("IGtNZWNghMjOygjGYxIMjTsEuFSTPbfKAoXaKtNnKdgTKJhHKAlGmFhZZoBKmAsrifjiWFO");
    int wfbANnlHdJcDX = -1937977074;
    bool SiWHzv = false;
    string isGoehySvWRu = string("weiXTTa");

    for (int lraQh = 1443554564; lraQh > 0; lraQh--) {
        hBdoypSlcwQTfc = LxOkiOT;
        NAkZCiXcqETe *= akVOYyRUfip;
        akVOYyRUfip *= wfbANnlHdJcDX;
    }

    return tyFMDczvGoi;
}

string NHmoPbPxsZDRM::HzjhJdG(double lcBuObJQLS, bool zxLFgsMcwbSosc)
{
    double PavJGuwhV = 244985.64618109365;
    int SRpwSgakJhAL = -2034310242;
    string VUVOsNXbIJDHxtAf = string("uBMyJMiBhlktNitjUBLpEqtucxesNZieMGAFNMCUvNNcOVLVH");
    int PbrQfoJgGFlpzl = 967009069;
    bool JyGrbGppw = true;
    bool xwybA = false;
    double TDCLiHt = -626965.285409741;
    bool KAbbXyg = true;
    string IaFwoLFc = string("URQCpuxLsuNEHKtmlBIGSwvQhGTDMdnBcyuSaHDOKiTHLcinSnEZKwLvXPAJreDKubGozPzpIdtPpnoPwpJlNNdTrFGpNCypwMDNZYfOaVddWCUQNaCfnFqYfltUpZHduNkuuKnjfrJ");
    string JfgpsxhkiCIhrX = string("pwCNXUvQkGJqeZgreguvzuqmoOUStIz");

    for (int CuLxvOF = 1132763708; CuLxvOF > 0; CuLxvOF--) {
        continue;
    }

    for (int VFEDsPr = 1517946751; VFEDsPr > 0; VFEDsPr--) {
        continue;
    }

    for (int qnYIYzTTJWrhANGH = 1481702668; qnYIYzTTJWrhANGH > 0; qnYIYzTTJWrhANGH--) {
        KAbbXyg = ! xwybA;
    }

    for (int sCWfS = 1872547039; sCWfS > 0; sCWfS--) {
        lcBuObJQLS *= PavJGuwhV;
        zxLFgsMcwbSosc = zxLFgsMcwbSosc;
    }

    for (int jpmcGVAGstAFuN = 502333032; jpmcGVAGstAFuN > 0; jpmcGVAGstAFuN--) {
        IaFwoLFc = JfgpsxhkiCIhrX;
    }

    return JfgpsxhkiCIhrX;
}

void NHmoPbPxsZDRM::LkwpZMp(bool XQSevY, double NWcckkNkzuaV, double IXicDoeBQeYynKKq, string WGmJXuWTQVzlcq, double zANYnuk)
{
    int GtxuLC = -761381605;
    int hKGRjLpP = -888425898;
    int YnTjc = 1187815145;
    double YDUTtgwneLe = -217236.05811544912;

    for (int wNcyE = 1333280253; wNcyE > 0; wNcyE--) {
        IXicDoeBQeYynKKq = zANYnuk;
        YnTjc += YnTjc;
    }

    for (int FiRjrZeCeornACE = 963999860; FiRjrZeCeornACE > 0; FiRjrZeCeornACE--) {
        NWcckkNkzuaV -= zANYnuk;
        NWcckkNkzuaV *= NWcckkNkzuaV;
        hKGRjLpP += hKGRjLpP;
    }

    for (int QCiLoZ = 1472731914; QCiLoZ > 0; QCiLoZ--) {
        YDUTtgwneLe = YDUTtgwneLe;
        NWcckkNkzuaV *= NWcckkNkzuaV;
        YnTjc = GtxuLC;
    }
}

bool NHmoPbPxsZDRM::mWRuF(bool mQLiBSgobo)
{
    bool sXPWQuF = false;
    bool nlTeAcQHa = true;
    int uNuIKyuaBeDxcsM = 1732029025;
    double CsZLEIBfdZYFMqHY = 127760.4990443842;

    return nlTeAcQHa;
}

bool NHmoPbPxsZDRM::FtOzuJrPw(string GtskGWqqWht, bool zuRUSPaY, bool LmBgM, bool xAvAcadGa, string YpSXhm)
{
    int RZFENUqIAWFcHeyB = -99363308;
    double WSfQS = 418307.9666413379;
    double IrSyDkMpUFKJv = 249518.8818244571;
    int DwpCBfCJlSKljEg = 966500755;
    string khmJCPIPPgpSAWL = string("vFxQLQQclLjDBfYigyNEWeGBdxsWhqmOkuMSohbilUJzsiRKxafQSdkYZtzjQIVLgfVoKLWQPBnKbUjgMpxxqPUDocRGFhyEfPcWPVNSnRECYzAqcJtqezqTAyAizZbSTwoooOzftGeIIVrHkUaqouDQpjHyAnkmQnMxHjTCuHWYOrJXXhpqKRlqTqJwixHqJCKIjNrRpFxmimQNgu");
    string mshediqADz = string("ApnLuGarncbRAwfterMLxDhCOubrXnkmihsaMfotutlpiNgrZHttFNQsQEnzBvwdfWokfcXSlrwDHUGpSIzCsxljelyCImQIzIgsQfveccllqpeDWcLMejzhNfzVJaLVmrHwFzltwuCrefrTXNdarRNzmJXrfXdXlegkwSIpmTtKrEsNigwAmNIvnXCCawopbV");

    if (khmJCPIPPgpSAWL != string("QlhUxoYwXnyaNVVJLqVAfOzQAdIDJsmjWPkSfEXriYGAgPFIMDVHSgrmqieIXudFBAYoUVVVvOtPOBBfPWxuYSMzihTCNtZEhmooWzesuaILVAZkGPFYDFDJBtsAFMinvxJHhQIbDcJQONBgcrxpwmiTKZasntgxlFBMbxpNQhlIWlDDvuKeLbdPObNGhduBSs")) {
        for (int lGHYShcld = 1663217984; lGHYShcld > 0; lGHYShcld--) {
            YpSXhm = khmJCPIPPgpSAWL;
        }
    }

    for (int amYKtoHVIX = 1955064668; amYKtoHVIX > 0; amYKtoHVIX--) {
        khmJCPIPPgpSAWL += khmJCPIPPgpSAWL;
        YpSXhm = GtskGWqqWht;
    }

    if (khmJCPIPPgpSAWL <= string("vFxQLQQclLjDBfYigyNEWeGBdxsWhqmOkuMSohbilUJzsiRKxafQSdkYZtzjQIVLgfVoKLWQPBnKbUjgMpxxqPUDocRGFhyEfPcWPVNSnRECYzAqcJtqezqTAyAizZbSTwoooOzftGeIIVrHkUaqouDQpjHyAnkmQnMxHjTCuHWYOrJXXhpqKRlqTqJwixHqJCKIjNrRpFxmimQNgu")) {
        for (int YzOFkjCAunBRLMBm = 640793163; YzOFkjCAunBRLMBm > 0; YzOFkjCAunBRLMBm--) {
            khmJCPIPPgpSAWL = khmJCPIPPgpSAWL;
            YpSXhm += khmJCPIPPgpSAWL;
        }
    }

    for (int JfdFUwbcN = 229412125; JfdFUwbcN > 0; JfdFUwbcN--) {
        khmJCPIPPgpSAWL += YpSXhm;
    }

    if (xAvAcadGa == true) {
        for (int HnIiKxUyijZkzka = 1665848314; HnIiKxUyijZkzka > 0; HnIiKxUyijZkzka--) {
            zuRUSPaY = ! zuRUSPaY;
            LmBgM = LmBgM;
        }
    }

    return xAvAcadGa;
}

string NHmoPbPxsZDRM::aeGhBLigQaFKPn()
{
    string DDnidopMbHA = string("QeQEmDYksCuIiaqnfTzhfbFTNeTtkBDpgMTsNUAggvdLDHLordxjYyjoDqRZYcJkrMlkaastMgjPAGVhsWdujbWSFVsFEyHkpSbhyeIcBTTQIlEmDVXzMVPNEmvwdEcWYLoUPOwrdPrhRgQNYuHfUJaQxgrViCfcitaXCUCKRQMvvltQHZmYuSLFtdeesJkZnQcBgNoSndRtxcSBSXRsIwrhRT");
    int oAJzp = -2066711950;
    bool OfjGooVrgg = false;
    string uSolIV = string("GQxhbTTlWlaYcTtdOHxzmACDDSgfkBtwhEtpvAKCmzjeXtNrwBUWbIUXwRHjEMlGemRDTLTePWNQOGnJnGhGOIhzOZzoowkZZYgKooHBOjfilJBVaJRYivugXJoVWCCBnfrthhkPQdajw");
    bool TbeDOg = false;
    double WobvVuEEvo = 796381.6373126911;
    int FJjGxwJSQaxdmmX = 311027016;
    string ZZDrgE = string("zHMioqnATvoeEYljnJImPsrJJGZOaQhgfwzgYSmmNpRciTgucsUMzAuBjWYmowdjkmsJBdwPLAdbqNDDWkygcTSsLearIIXvLILWDhRcByiuNYIODSrwRsVTwRxOXiEwjlwfhiEwIzIUMrKtIlpRdFVxtPCNxhyDOhUeOyUQelvQmAIyUPOvsEboSsigzgCaXFKKijKxJN");
    double PozBzpdiKLEeia = -132478.33722048605;

    for (int ygXoHsdzzGj = 1032746773; ygXoHsdzzGj > 0; ygXoHsdzzGj--) {
        continue;
    }

    return ZZDrgE;
}

bool NHmoPbPxsZDRM::FujuJntaDHRsqV(string utNaq, double LKPJcpbuGYj, int zqHDBb, double uwanMLwVMWOUHXl)
{
    double DiLVNzlIGt = 327246.2712983786;
    int fIulRQWgt = -934141339;
    double XLWXNZS = 76762.1057135323;
    double YtEut = -732137.055201634;
    double cLFRAfUDmEEF = 377096.46383311605;
    double FKGzrDcNLEUaQQlU = 433012.30738373974;
    int kTyzSeVz = -611190087;
    double JrFusDsQPdYbvkd = 956800.1413987305;
    bool HsxlbPmXww = false;
    string epcaPuY = string("psmfbORGREqJQkqrIkyOGJKeDhlRqlSRNDaxbdJxzhcSJkzkfVhXXbkTDeHrBjMbkbIFALzQtDZfiaRUtwOmJzVsxWLghMxnbvHTBbBCEEWsHuxuTrMWfjtPeRbpLPgguQuJIhLPmFbgkIjWakJoXlMzMKREuYBzGdjYkNFhhJnFCFoDPufZWmzQpkYpNYHKiGOAwVvmhVAMukZFLQsXYJGSXLEkOdKbKTVHxRbtrlYkdMVlPLNnQbkVad");

    for (int vJqBzCK = 1198678002; vJqBzCK > 0; vJqBzCK--) {
        utNaq = utNaq;
    }

    for (int szFOnL = 5699934; szFOnL > 0; szFOnL--) {
        DiLVNzlIGt = JrFusDsQPdYbvkd;
    }

    for (int MnWQG = 598439158; MnWQG > 0; MnWQG--) {
        DiLVNzlIGt = uwanMLwVMWOUHXl;
        LKPJcpbuGYj += YtEut;
        cLFRAfUDmEEF -= XLWXNZS;
    }

    for (int JioKkPcBSwPxta = 1875005050; JioKkPcBSwPxta > 0; JioKkPcBSwPxta--) {
        uwanMLwVMWOUHXl += FKGzrDcNLEUaQQlU;
        fIulRQWgt /= fIulRQWgt;
        YtEut += JrFusDsQPdYbvkd;
    }

    for (int MjTlvSEIYnXUF = 1913142905; MjTlvSEIYnXUF > 0; MjTlvSEIYnXUF--) {
        FKGzrDcNLEUaQQlU -= YtEut;
        cLFRAfUDmEEF += FKGzrDcNLEUaQQlU;
    }

    for (int aOjYatrIGp = 1345195239; aOjYatrIGp > 0; aOjYatrIGp--) {
        DiLVNzlIGt -= XLWXNZS;
    }

    return HsxlbPmXww;
}

string NHmoPbPxsZDRM::TiWeLtsYxdqOFbd(string KqfNQlE, bool rauTLqKdJMyToz)
{
    int WdMgJIOZkzEzXfz = 1584351760;
    string tijjluCCDTjKI = string("XlsmvnYUEipJLhhSaZgfgSlOTqmnlrxPIyJzzTcQNDyvmgtNBHtiDPzKVZsmQdrhMxwbhlPIhhXepdsfd");
    bool AlCyWIBoPr = false;
    double tCYGcGBxGKPbjVAs = 972977.705704332;
    int grrXHPDzeRi = -149114729;

    if (rauTLqKdJMyToz != false) {
        for (int KWiBus = 1189317080; KWiBus > 0; KWiBus--) {
            tCYGcGBxGKPbjVAs += tCYGcGBxGKPbjVAs;
        }
    }

    for (int PfOnKXaLXWk = 231913144; PfOnKXaLXWk > 0; PfOnKXaLXWk--) {
        rauTLqKdJMyToz = AlCyWIBoPr;
        AlCyWIBoPr = AlCyWIBoPr;
        tijjluCCDTjKI += KqfNQlE;
    }

    if (rauTLqKdJMyToz == false) {
        for (int haixEwUVSZRWciDl = 719674530; haixEwUVSZRWciDl > 0; haixEwUVSZRWciDl--) {
            AlCyWIBoPr = AlCyWIBoPr;
            WdMgJIOZkzEzXfz -= WdMgJIOZkzEzXfz;
        }
    }

    for (int RKTLHxjUMubvURP = 1544487978; RKTLHxjUMubvURP > 0; RKTLHxjUMubvURP--) {
        continue;
    }

    if (WdMgJIOZkzEzXfz <= 1584351760) {
        for (int KhuELtawh = 161237485; KhuELtawh > 0; KhuELtawh--) {
            WdMgJIOZkzEzXfz -= grrXHPDzeRi;
        }
    }

    return tijjluCCDTjKI;
}

string NHmoPbPxsZDRM::oqDwPJnTmCM(double sQYpIDAtaZukTXB, bool WVnBjS, int foqHgBZqoBWddPKy)
{
    bool zPrUJsett = false;
    bool ixSBfzV = true;
    double PFtXOqKdFZjgDkgm = 219734.49106971422;
    double SsWKK = -450730.0684528445;
    bool DzSBMQrMWAhApeXR = true;
    double uTlEljfeJLN = 810778.124519426;

    if (DzSBMQrMWAhApeXR == false) {
        for (int PPBWCoaLvnsGlh = 1462523684; PPBWCoaLvnsGlh > 0; PPBWCoaLvnsGlh--) {
            zPrUJsett = DzSBMQrMWAhApeXR;
        }
    }

    if (uTlEljfeJLN == 219734.49106971422) {
        for (int MggDNKHyUZhoPYCK = 139996256; MggDNKHyUZhoPYCK > 0; MggDNKHyUZhoPYCK--) {
            SsWKK += SsWKK;
            WVnBjS = zPrUJsett;
            ixSBfzV = WVnBjS;
        }
    }

    return string("QwujZhnqHLnGVyBRZeakbQzV");
}

int NHmoPbPxsZDRM::GrMHWjM(double WSyTvbNIRNFLF, string nIhamefOxizrA, string WfunQxGmurGUH, string EVdeDqiLhlmwbHwe, string GHSzSykjwhU)
{
    bool zFDxESFKOQzdUdvd = true;
    string mWcsTQsrin = string("uhOMMDpkhyHQIjPUJOkUjiNJqmcMudfZmTSAluybhTdWZBMXBBommuYkWinSjvGKgJWIsutjpvFtygIQNpfXZPnGLYTsrRupTbqHQblxXuHxnCtpubvLdWlzrVbJbdDRDkXCRCuzmFWDDVFSYGHssUOogLHimCbKcilPTiMjxDTWMqqfUarJGtjRkIlTjncQRAmvWSxVANBSwNnPDKWaXpHd");
    bool UFNJEqnWAdb = true;
    double hvXpTUlA = -530731.4404607656;
    int dOqIYqXVVAiD = -1638005901;
    double zdexegpHgmlytT = -64702.16391121613;
    string XAPYhJJs = string("XtCWJhlgKoHUMAZvUozVaXZsvAOgdRWqUxPGAjnwtleeCAGOueruAyQvwSPPkOiZlKULrNJUgUMLyrpreuPEHrNrJnmZwGthlceoccOVbOgYepJBoenkXLKZXyZmupXijLQVzESdRHHgnUpYlJxKalGMat");
    int WqVJGapvtBMxZCy = 1328003490;
    string OZNwmymrImV = string("cuuXdaoXjVZVnkGLpZRFyaaBObZywqHXYZeyKoCcYCebbUNZVRkBEYMbV");
    bool kcVGhsohoQNDh = true;

    for (int cuJyygB = 181830904; cuJyygB > 0; cuJyygB--) {
        nIhamefOxizrA += OZNwmymrImV;
    }

    for (int LdhkFdiiAdVtnbB = 1800018535; LdhkFdiiAdVtnbB > 0; LdhkFdiiAdVtnbB--) {
        WfunQxGmurGUH = EVdeDqiLhlmwbHwe;
        nIhamefOxizrA += EVdeDqiLhlmwbHwe;
        mWcsTQsrin = WfunQxGmurGUH;
    }

    return WqVJGapvtBMxZCy;
}

bool NHmoPbPxsZDRM::dLruvT(bool eLUoHhZhOMGzlwc, string qqfZPgsnDooC, bool jUEGILhryW, string yqdfRHtMpl)
{
    double kCXMGWVEQHYyI = 473595.9812366;
    bool yywmRVF = false;
    bool nsMidqIl = true;

    return nsMidqIl;
}

void NHmoPbPxsZDRM::CeOevmxfFNoMYo(double FPWbt)
{
    bool xaEMJYmVCe = true;
    int ZgAkIya = -1165046131;
    string ErNhgCFnIDSkVW = string("xAGbrQviNnfrtRuzbzVUoAOXxMnpLpocnkJiyPJwCyzRsBsGuoVPBjoXkpAlWqHdWaBDGFBaYPsAUdFoBIDOaUogYLgxWSPpwIRLlLAElBGzjwkolWYhzVnSFuuYwSPwtYWRxHBbyvNIfEQknZEpvmEOaSaidwVajuSqxFJdEMNBUehdJCqXrYiOvIOPh");
    double EUWOvDtXsHHTEZ = -959347.6424407811;
    double azkPPopiGaGc = 40037.243103448534;
    int UwGHalmHhBg = -592820691;
    string nvQfErc = string("hnsKjQwuqTDfDhKzZwwxPOORQdilcLkKnTyKnsEqoqGL");
    double lrgElMUCsqvWVw = -55277.91600693844;
    int ezbsHSgIxbyWojY = 1429407050;

    for (int WSbuYaf = 308313618; WSbuYaf > 0; WSbuYaf--) {
        FPWbt -= lrgElMUCsqvWVw;
        ErNhgCFnIDSkVW += nvQfErc;
        ezbsHSgIxbyWojY = UwGHalmHhBg;
    }

    if (FPWbt != -55277.91600693844) {
        for (int TwcaNdRNtvnoUZ = 284263891; TwcaNdRNtvnoUZ > 0; TwcaNdRNtvnoUZ--) {
            ezbsHSgIxbyWojY = ZgAkIya;
            nvQfErc += ErNhgCFnIDSkVW;
        }
    }

    if (ZgAkIya > -592820691) {
        for (int YVaiLXFETcyD = 120487505; YVaiLXFETcyD > 0; YVaiLXFETcyD--) {
            ZgAkIya *= ezbsHSgIxbyWojY;
        }
    }

    for (int SslGwvMDNLCzhW = 1467885130; SslGwvMDNLCzhW > 0; SslGwvMDNLCzhW--) {
        EUWOvDtXsHHTEZ += azkPPopiGaGc;
    }
}

bool NHmoPbPxsZDRM::YSdLXkazCgDYcxh(string ZkJaIbcyfjaJw, double WOpqHVCtx, double HWDGDltAJlIg, int XFwzkrGecdQO, string Qwcwr)
{
    bool yMiAWJWL = false;
    bool ZHnFJjRfKrZCOPhY = true;

    return ZHnFJjRfKrZCOPhY;
}

NHmoPbPxsZDRM::NHmoPbPxsZDRM()
{
    this->bRDsxBhRkw();
    this->wEotoWYzWfPPqu(-683262820, string("bUFNLFfGLsMxUbLohVXMfPsDrXaX"), -1314779240, -575682334);
    this->HzjhJdG(75827.37349562926, true);
    this->LkwpZMp(true, 172660.43222508917, -9396.847683714735, string("KAyfZxcHrnsHZpTZXbQFWAjgFAzRImcTpjyiraorqVqJMLzZQEHAri"), 553889.502226585);
    this->mWRuF(false);
    this->FtOzuJrPw(string("GEmdVTKUGx"), true, true, true, string("QlhUxoYwXnyaNVVJLqVAfOzQAdIDJsmjWPkSfEXriYGAgPFIMDVHSgrmqieIXudFBAYoUVVVvOtPOBBfPWxuYSMzihTCNtZEhmooWzesuaILVAZkGPFYDFDJBtsAFMinvxJHhQIbDcJQONBgcrxpwmiTKZasntgxlFBMbxpNQhlIWlDDvuKeLbdPObNGhduBSs"));
    this->aeGhBLigQaFKPn();
    this->FujuJntaDHRsqV(string("ODtmcIXgROrpDMXzbuQROjaKWwJrZCYAxmnYBbXyjfMuokshxoWhmhRlopOPimXrmZiwBjbqdRfRFcRPwLTJPVdPlLIJdpNIDOTCACZuXqkAFDjbWHszmfmlDHSrQfUHorylHHdcjCMDTRfRZr"), -516547.15047786623, 60029367, 137777.99025737442);
    this->TiWeLtsYxdqOFbd(string("nRkHqnnlwMNiCiKvHJJrJiljaECFksswuETiyzpNOZTAroxNmhBhzomdghdvOLezihABwmrilcXYBXvXE"), false);
    this->oqDwPJnTmCM(-818474.2779288836, false, -1961318754);
    this->GrMHWjM(-225020.15899631, string("QNbmdYsAyDBnidIAjfecoEfKKlFGfVBCILScTNVVPKFSlcWZXNyNqJZkIkKiUkqaqcPbroUCqvMvvA"), string("JwLWZmBgdlCZvDLElhzuwocleQzNQrXOjkJAPQpMoyHOTOlclKEjJJDNuiZvkzxqKcnBMHBtIbnfKFyHxvOFArdNqIifUELDdaMw"), string("GFTcKsinXVACXPQcztoiVXkjpOErBTXuskagqJLYPKUKCXaoVEZVKqMWuKrHzSVaGDajchQbOhIFFOcIwwnJKyfliKgchqhpDuKJJzFaTXhmHtXmGoGocEmREfjGASvoVdYVtUzGssZYNTsXUEFXyvAkNtAhHVcxYDbFNbFFqKiNZiKCMRPMpOOvHnQVVbYlaqnCpOnyxWsfoDYQR"), string("qBAgQulBtFHGdqIrBNQYVptyZedAiiPmMZOiDICCGhetQGfWCtLkRjkUIoNulXUOoRAKiMUjWMhgnuNQMqpaYxCOeJuTTkJWsQUHrCfMJRQODQmtcugYbONdvFdwpbAkUEHUDyGIoEQXTVkSpcEuzOehblrjSKBZIiqjaENgvoqJYNlNdDFmGuResmpZPsaRiiDiLDxnXCAYQYZnsM"));
    this->dLruvT(true, string("pEtKtIToYsPetmTylCVBiTaGNxGWtNlWmksBbplpAnNRTFxOiAVKgMkjAjdOseoHOEBPcQJlDlCUMsCRoRmBbnUhnTHYRfDGALKstFcXUTTPPuZgsRIichJrAzvsggIgnRZOgHTaqyWQbxSNdQPWRLqYray"), true, string("ovokbMqJVITvYAkCRuCYcTkMF"));
    this->CeOevmxfFNoMYo(-352719.78677308187);
    this->YSdLXkazCgDYcxh(string("nNQiIUodYBQsaDEfGvDWBxqgAcrJTjoPtujUBlelMsDOlhUgXGaCQXGuBLPYIWOgrNYttEEPiPuydtBNuNraGhToDQQXKsyWjfYGZDwRjjKeODJWpFLVaLhLOMdRMvhGgGogniOxVlWMqth"), 362197.26984570763, 808933.8733994524, 478645387, string("qpjLzIZmIHTkASpnnnseTfXSlSodIDkncZCjbeaEoRlLbmQfFiVtMPGqDwRJEKmaiAzlggfNOokSpmfkbHPYKS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WzzvNokyvAOKnsX
{
public:
    double JchNAlTIOPIA;
    int YXiCKgQWUXNsXmI;
    double JkEHfXbErQBMDU;
    double SwLQxxiScOwQdL;
    int MAPhBm;

    WzzvNokyvAOKnsX();
    string QjSddQfNNd(int VTTZHcQd, double TmjQGwQQ, string JYuuyanbdbCMr, double WVjIynzQvHHYB, bool BXLpdpcRdgzMOZV);
    int dfmrDw(int pKZkAepMPI, bool XuPRGBdSAKIgADrL, bool wjkvR, int abcaqcGJcTCRU, int UpelVIIUpa);
protected:
    bool QYOigQkcjHl;
    int uvwjRLWA;
    double GGhbSVcsExoU;
    bool rOepN;

    string tukAYLmCjyHRRq(double xdRbUhSaf, int wijZuefRYMpdSUix);
    bool yOWehOga(bool VpUOoNeO, bool DQXCWojx, string YsrlRBB, double YgryCciPxE, string yXFqzTpbKr);
    bool nYuIkXAbSHQfI(int CTWBayojvraxuGHA, bool iNmSeTTOckGRe, string PzgoOzSaLNgFKRF, int vbiQiZq);
    int bKUckyu(int NFSNCsV, double QNljYJKayrr, double egdqp, int mJikR, string KczImlSsLuEYEffT);
    double NyOuAXzgc(string WrQZfU);
private:
    string pcVBOOIsvxsSPLvZ;
    string mvxeqrr;
    double dKTDlMllw;
    double eZECA;
    int zPKQxPA;
    double UVFGYDcLLrmIf;

    bool UMgpmCAgvTdfek(int SVRElH, double FbCtzGAuixxyMqGw, double keuRF, string wwslvmDBKwyMghVS, double ghvvTd);
    bool sXTzFoasPB(double WfbdDVpPLMom, int pqKsuhjQYkqVFstM, bool mxRnz, string faVowzTHBjECHnN);
    void AXWDbM();
    string LtZRcjtbutp(string avioWSTsAvXvbhz, bool pSSHVZZZFuZCsfn, double RDtXGNMOcwOS);
    string gqostQXoSBX(string kiCmatDI, int QdmUSIAjVvAIflu, double LSyubb, string QMkDRyUnXNnMiG);
};

string WzzvNokyvAOKnsX::QjSddQfNNd(int VTTZHcQd, double TmjQGwQQ, string JYuuyanbdbCMr, double WVjIynzQvHHYB, bool BXLpdpcRdgzMOZV)
{
    string quHDS = string("cwQpinjFHsfPqzquzxJtsdfyoywwAUWANGgxhXildyPpigKbxmCdNksBGuHLlAeihXdBpXAqvqSIzBSKCKdcuMaUBqlmRpBrppUuUtLtCQ");
    double NZfXTzHtHFH = -31832.462868646257;
    double JNpkTXVP = -692017.8496214568;

    for (int vqxWTiRvwCpDFz = 1940685912; vqxWTiRvwCpDFz > 0; vqxWTiRvwCpDFz--) {
        continue;
    }

    for (int eetwhAMuylUD = 973797106; eetwhAMuylUD > 0; eetwhAMuylUD--) {
        quHDS = JYuuyanbdbCMr;
    }

    for (int Wjzoki = 1038773037; Wjzoki > 0; Wjzoki--) {
        continue;
    }

    for (int ajbMMzhKr = 1684109878; ajbMMzhKr > 0; ajbMMzhKr--) {
        continue;
    }

    return quHDS;
}

int WzzvNokyvAOKnsX::dfmrDw(int pKZkAepMPI, bool XuPRGBdSAKIgADrL, bool wjkvR, int abcaqcGJcTCRU, int UpelVIIUpa)
{
    double cZfpF = -105276.65446920264;
    string gmSziLFCQvaR = string("RDMxtywZbRhddRCGyFrLplkkbMjOltLUjfYLWbShyGbduIJPxrhgQXBDfLsxlQtAIysSvanCHKrpMzakr");
    int MvDQABXeAHzflzWu = 2090236100;
    double IDwNMTXzhFatPtWB = 362215.2021879434;
    int yGzykcFIzJJ = -1506662177;
    string BwPsEhKDGT = string("dALXVcvyGEwVTPTRCHxWLXfwBhfgsigwJxlclVzvRVSHTEfPfAaKuMuTPMDeoJZhgZoPJejkPwgKayEoEvrGvAAoykraDmwJjJniVzVkBpNaYTVkuStYixVmZzrfOhfZGnHgzmWTlkrBLqVlmVwhGXfUKfQOVQeeBMVoHhaNQgpChZcvJhWpVQHIkqIjXnwFMafljQgTWKcmgCiECRjplwPRsak");
    double SnjnKKYs = -465445.9307287931;
    string aIeeXns = string("QdTwcAnJKHuomHdeVRtOzEsuXBTKhMIrmtDsPjXODrYUCQuaUzoUjntesyguUectTaUzOitsJZYWFtiWTXlPbfHHAWHTiPxkwZgqMDTDBrmtwORGPgHBjfnRfsVxhNDLUyUWYrvEEEdAIOnddQSvEhIBmxbhGATtmhMPETOxoTtPpIAfwBmjnWxsPWQwORBUFaQoPCUSFlAEUNhxzzmzQoprZsrRLAAUR");
    double xwCcEHLabuj = 327155.88556293433;

    return yGzykcFIzJJ;
}

string WzzvNokyvAOKnsX::tukAYLmCjyHRRq(double xdRbUhSaf, int wijZuefRYMpdSUix)
{
    bool waozwo = true;

    for (int XRKHUy = 160623011; XRKHUy > 0; XRKHUy--) {
        xdRbUhSaf *= xdRbUhSaf;
    }

    if (wijZuefRYMpdSUix <= -623054039) {
        for (int CcrGwyNtkrZB = 2022468331; CcrGwyNtkrZB > 0; CcrGwyNtkrZB--) {
            wijZuefRYMpdSUix /= wijZuefRYMpdSUix;
            xdRbUhSaf *= xdRbUhSaf;
            xdRbUhSaf += xdRbUhSaf;
        }
    }

    for (int MpHmA = 833307674; MpHmA > 0; MpHmA--) {
        continue;
    }

    for (int LVUCuDxdWhkFMN = 1195957695; LVUCuDxdWhkFMN > 0; LVUCuDxdWhkFMN--) {
        wijZuefRYMpdSUix *= wijZuefRYMpdSUix;
        waozwo = ! waozwo;
    }

    return string("cVxCvgVZDTtMrYkuWLSTqeqzFmTZmWipczZpZJTItGnzSRlKWFYxWtQReFQRPArpdxjyPRzXBPrPDrUmxxhrLofVDDSFEwlleLGtLYGSlYrEjASfBQgufLkqOogIE");
}

bool WzzvNokyvAOKnsX::yOWehOga(bool VpUOoNeO, bool DQXCWojx, string YsrlRBB, double YgryCciPxE, string yXFqzTpbKr)
{
    string tkBLuHfd = string("LDYwGRAYTICjtGaeQPbeZeBImIcxQrBbzNdSiNLGEjZQibLlUfaMqGCoLEbROTJAnPEkuMnwlHGnMkoUBzZYnNRDSPsgLYYHnAAjbVnNuaZNZDyZtoHUGWwJTyBPwNmNTnGebGerqZySdJEamkdTMaIFjjHlRgJTWgzqUyQKppoXbmHBIBXjKtXrbpyjQraeolNxJSuhaxlTTjczyMuOasJOarAWcjUewRwLGNjv");
    bool YOnEaPmb = true;
    bool voBhmFZOYySoDxc = true;
    double dNOjNj = -306057.3848345088;
    string oIdVHKVQq = string("zJrXDKVIYlLWtEPcXheJpHLz");
    bool uZTXNHebxGHsP = true;

    for (int knLAHjlf = 211708352; knLAHjlf > 0; knLAHjlf--) {
        tkBLuHfd += tkBLuHfd;
        yXFqzTpbKr += oIdVHKVQq;
        oIdVHKVQq += yXFqzTpbKr;
    }

    for (int JnwDyLcNCLQTfuRO = 386581161; JnwDyLcNCLQTfuRO > 0; JnwDyLcNCLQTfuRO--) {
        yXFqzTpbKr = YsrlRBB;
        tkBLuHfd = YsrlRBB;
        VpUOoNeO = YOnEaPmb;
    }

    for (int YZmCfxITJcAFi = 1471929268; YZmCfxITJcAFi > 0; YZmCfxITJcAFi--) {
        VpUOoNeO = ! YOnEaPmb;
        DQXCWojx = ! DQXCWojx;
    }

    return uZTXNHebxGHsP;
}

bool WzzvNokyvAOKnsX::nYuIkXAbSHQfI(int CTWBayojvraxuGHA, bool iNmSeTTOckGRe, string PzgoOzSaLNgFKRF, int vbiQiZq)
{
    double gINphFUwm = 456961.64073497965;

    for (int zhLXiU = 820440418; zhLXiU > 0; zhLXiU--) {
        PzgoOzSaLNgFKRF += PzgoOzSaLNgFKRF;
        CTWBayojvraxuGHA /= vbiQiZq;
        vbiQiZq *= CTWBayojvraxuGHA;
        gINphFUwm /= gINphFUwm;
    }

    for (int fZiWzflfEZEAqsz = 1741232335; fZiWzflfEZEAqsz > 0; fZiWzflfEZEAqsz--) {
        vbiQiZq *= CTWBayojvraxuGHA;
        iNmSeTTOckGRe = iNmSeTTOckGRe;
        PzgoOzSaLNgFKRF = PzgoOzSaLNgFKRF;
    }

    for (int SqxzNodBOdhV = 972223345; SqxzNodBOdhV > 0; SqxzNodBOdhV--) {
        vbiQiZq = CTWBayojvraxuGHA;
    }

    for (int VnuQVOTI = 877589070; VnuQVOTI > 0; VnuQVOTI--) {
        vbiQiZq /= vbiQiZq;
    }

    return iNmSeTTOckGRe;
}

int WzzvNokyvAOKnsX::bKUckyu(int NFSNCsV, double QNljYJKayrr, double egdqp, int mJikR, string KczImlSsLuEYEffT)
{
    string llckPbC = string("iYmzVdTivfHTYURWTXErEtheoAYrFXuegxWpWVYQlDFzgaGAXTEaaVFRPPdUlSjdTfAvlzdBXHndLtERrNwFJahOBGFrtbUUiowUWARgvgTKViNduPEUMpbJRseQPUWpZRsazGSXiofErOGkvndlWI");
    bool KEcJAWQzRPij = true;
    string ENbZyYBiwhc = string("YBaUx");

    if (ENbZyYBiwhc > string("YBaUx")) {
        for (int CGDKrNricRBxKK = 1923136957; CGDKrNricRBxKK > 0; CGDKrNricRBxKK--) {
            ENbZyYBiwhc += ENbZyYBiwhc;
        }
    }

    for (int FJPoolptu = 657896033; FJPoolptu > 0; FJPoolptu--) {
        KczImlSsLuEYEffT = llckPbC;
    }

    return mJikR;
}

double WzzvNokyvAOKnsX::NyOuAXzgc(string WrQZfU)
{
    double KtYBtUonJsVsnnrT = 745557.570259882;
    double PBPmOTnquUQ = 901329.8450624523;

    if (KtYBtUonJsVsnnrT <= 901329.8450624523) {
        for (int saDJIY = 160616479; saDJIY > 0; saDJIY--) {
            PBPmOTnquUQ -= KtYBtUonJsVsnnrT;
            PBPmOTnquUQ /= PBPmOTnquUQ;
            KtYBtUonJsVsnnrT = KtYBtUonJsVsnnrT;
            WrQZfU += WrQZfU;
        }
    }

    for (int uOmNHUMVSLX = 360929136; uOmNHUMVSLX > 0; uOmNHUMVSLX--) {
        PBPmOTnquUQ = PBPmOTnquUQ;
        WrQZfU += WrQZfU;
        KtYBtUonJsVsnnrT += PBPmOTnquUQ;
        KtYBtUonJsVsnnrT -= KtYBtUonJsVsnnrT;
        PBPmOTnquUQ *= PBPmOTnquUQ;
    }

    return PBPmOTnquUQ;
}

bool WzzvNokyvAOKnsX::UMgpmCAgvTdfek(int SVRElH, double FbCtzGAuixxyMqGw, double keuRF, string wwslvmDBKwyMghVS, double ghvvTd)
{
    string FksNpAziOytQU = string("UZBlwmbMzxwcDkwOBNCNxJbvTqCVKhqWBZmimIjoXBEpRsfmHySEJBwbquEsRSLbvgfQIFO");
    bool vdqdLuGWRwP = false;
    bool sgvMXnMbJaDLjJm = false;
    string GReDnyZ = string("EDQqRsqpvKQrJZERrpIDpCSmNzcBIbIPxDyAvkkhMRRAMGhBWmxTEYWUUBxTFOLnfzjCwOznJbRTvDFAZLyuILKxslIMVxinBElVQoaPuEWClMzTcnJjSpErBYQAXXUvpfQwBPCnEyJeudMuelgyiWTNxDrUOWHGknzzoggoXnVvSrJTakjSWtfBDVwHwFhRAFDsLFKLWXNvNYNj");
    int vkfNoOkVNGaQIB = 1966714027;

    if (vdqdLuGWRwP != false) {
        for (int QyVdRXljGHuxep = 2051681622; QyVdRXljGHuxep > 0; QyVdRXljGHuxep--) {
            continue;
        }
    }

    return sgvMXnMbJaDLjJm;
}

bool WzzvNokyvAOKnsX::sXTzFoasPB(double WfbdDVpPLMom, int pqKsuhjQYkqVFstM, bool mxRnz, string faVowzTHBjECHnN)
{
    string DNdnDgS = string("bLLlqHSJxGQNyhdhjfXpYXMdPqDxagwAYCaGshPCaxqMVQOjGbMnbNoJkIkrvfToamCPTzqRFGNTLpxjmSQxwREBiJqzSZmtarfycJICsCSUVlLyBpv");
    string NhBmAWMLmB = string("SFQXiLVEYNzfmTXAwuYlKCfWAnxBrqVUGmZe");
    string ajLMkpRJSNVRQw = string("vSmeYaDgdHKxaNuuCrgsAjwNafjRLBNeBtejoGmVpfMQyHCxgNFpEgsDJHIYevariUPnrIkFHXzpJMuVGaujKUBoqbReusJDvpGuEalShDiAabZilOHwDYEDqrSKpVFrglEzccdaMTmfBPgektObrTzpCcuybIfNVgyUUtsStFLosseXLTUMDlQHuTIwUDpOKTMKuKWDGWSZNFhFMtYCvut");
    int UZZiaFH = -1843377648;
    bool mDOQuflA = true;
    bool IVZloOaAfa = false;
    bool gWKnSAv = false;

    for (int KapHeeVJVec = 1086938219; KapHeeVJVec > 0; KapHeeVJVec--) {
        mxRnz = gWKnSAv;
        IVZloOaAfa = mDOQuflA;
        IVZloOaAfa = ! mDOQuflA;
        faVowzTHBjECHnN = faVowzTHBjECHnN;
    }

    for (int fYTwP = 1084564980; fYTwP > 0; fYTwP--) {
        UZZiaFH += pqKsuhjQYkqVFstM;
    }

    for (int aolPEw = 554159410; aolPEw > 0; aolPEw--) {
        UZZiaFH = UZZiaFH;
    }

    return gWKnSAv;
}

void WzzvNokyvAOKnsX::AXWDbM()
{
    bool hCgOMx = false;
    int eUFqi = 1820407789;
    int UZQrAAQWSWHAnVsf = 1519872728;
    string XFrFLhp = string("enSjezZXADkWFImmORdsozDTeaNMoKYRhirvpKQHLBhkQYsVFeaoaiJIYVkFXHCzpCyqPNeqjExCHaTjiPKfSOiZCMDzuyjttrNiZjxqzaFHXwxsxmGjEKEUuxTyvgFNHjWAMZKFLgHUQDKlvzZnKuyKNvQQhhnbHCscsegOaXJWVqWOofEDBeWhMrwBLtuvkIbnPxrGkRvjkLVFhkPMoXFqCkNrNSFbFbWhcE");
    bool wqLjCdZwp = true;
    double dqcUjNQDkfXVAt = -732741.6816080537;
    int eLTDYF = 1603619173;
    string EJKRO = string("vWtmSlpCFzOxxXSZFGFBbSyUuvVnndmVzZUuhYAZUEdCWZvZAqHDUeZxoRWpoffJjRoRNaeMuBZwDyicXtBULyuQkPuVBepBwqitiGipffNOUzXRCNRMhFpWGyhlNshgfXUfoNVlqFgeyaoJVdpZsQIXZtbYOkOuubqdupkbKWsSEhudNKlOdKXWBAHxLRXKrAIVMdMQouaeurTqSQOGTJKkIQgjDeNKwCVdXigjTOXAxBQHRClqmS");

    for (int sZZLi = 2011248690; sZZLi > 0; sZZLi--) {
        dqcUjNQDkfXVAt += dqcUjNQDkfXVAt;
        EJKRO += EJKRO;
        UZQrAAQWSWHAnVsf *= eUFqi;
        EJKRO += XFrFLhp;
        eUFqi *= eLTDYF;
    }

    for (int bLqjeTmdk = 62432782; bLqjeTmdk > 0; bLqjeTmdk--) {
        hCgOMx = hCgOMx;
    }

    if (XFrFLhp >= string("vWtmSlpCFzOxxXSZFGFBbSyUuvVnndmVzZUuhYAZUEdCWZvZAqHDUeZxoRWpoffJjRoRNaeMuBZwDyicXtBULyuQkPuVBepBwqitiGipffNOUzXRCNRMhFpWGyhlNshgfXUfoNVlqFgeyaoJVdpZsQIXZtbYOkOuubqdupkbKWsSEhudNKlOdKXWBAHxLRXKrAIVMdMQouaeurTqSQOGTJKkIQgjDeNKwCVdXigjTOXAxBQHRClqmS")) {
        for (int MQjyqbHHfxGZb = 1647105927; MQjyqbHHfxGZb > 0; MQjyqbHHfxGZb--) {
            eLTDYF = eUFqi;
        }
    }
}

string WzzvNokyvAOKnsX::LtZRcjtbutp(string avioWSTsAvXvbhz, bool pSSHVZZZFuZCsfn, double RDtXGNMOcwOS)
{
    string YlLpLkoOMLfkvMM = string("SDfGTkbAEXlJCuxxNATyRqzNbGmKHzySeZgvswJmBHJaivTVcFKcYPpZyHxedAEMTyjZxBdwqnevRhNyJdBDyptvjcZIBHgsTXOaFgHKxptfxqTlqIESYJCBkuQGJZRwmoqiSwJjAQHxuuMHCtqVvSCJrKQBIjPsYIjKNywrhJsdfChgdgokisSrVHRqxSbmOqsCQirKcbIHzKnGlKjXUzVbBjPrAYaTivcaBiumFPkgNBfei");
    double exoolftThKOu = 126864.42614117976;
    string IrLaxtD = string("NlVbMtOuEtjnKSFRnErBOhEFVBGTJFWhiNsbDTNYTtdVmTZLKeKvpULWFPLgoXPPQBfIwVsOUuKhAmzVYldWWRNLBzYRIstxceipayeafNXPQYIPSAFfAErwVfBGvh");
    string HAHoVuYS = string("CPYcWqQbsXfPIjihlbPLSzlXpcdmhDHIMJtjhfCjBYUoVNqjTYGeGyuskzyfYucdVoamKkiVuZMeynrYLrDPVXCsHZMkvYQdqYslrlzqeErcYSxkBtctfBvQUDiWfpLzWlVPghifnoYzBXPtrhaOgfTfZccSAIMOyoQKcYqMkNGZdIKZAhEpDcXoXUCb");
    string iwmxnTqW = string("NkTnDWUBSXHlhLnWNnxCaKZDWIUfH");
    double STrJLZYYuoRgo = 270098.71053188713;
    double oekRdqudFFCbgEG = -944230.3687857446;
    string IdKRJ = string("jfDppivJJIFaeLnxQSIDYXOBGnWitNYkBYgygmrcxEZOeHjCbhciAoAhTnFhiIObfUWDjHaVdzpUWtwaynKgnaNbzbIyteqgCNILNhpMqgaYsvYPymAGwbvMJAxTAqWHCoCaURRSSltcCNYQFJhFtqTJQgqrsnasRHObzFUzD");

    for (int wQgwrjdRVvYbTRGq = 1022154455; wQgwrjdRVvYbTRGq > 0; wQgwrjdRVvYbTRGq--) {
        IdKRJ = avioWSTsAvXvbhz;
        avioWSTsAvXvbhz = IrLaxtD;
    }

    for (int basShuTF = 1734651116; basShuTF > 0; basShuTF--) {
        continue;
    }

    if (oekRdqudFFCbgEG == 270098.71053188713) {
        for (int YspBzcoTtt = 2039307808; YspBzcoTtt > 0; YspBzcoTtt--) {
            iwmxnTqW += HAHoVuYS;
            IrLaxtD = iwmxnTqW;
            iwmxnTqW = iwmxnTqW;
        }
    }

    if (iwmxnTqW <= string("lPnvxNCatAkKyOWWLZfYbuqtHxvRnOxhLMJhlpUkvIkUdFyOdhWfYVbtUkMGJSqfXvZmCFzYoFsRcgDRgJzcMfLPPtkEmj")) {
        for (int LsJogBU = 265636457; LsJogBU > 0; LsJogBU--) {
            exoolftThKOu = oekRdqudFFCbgEG;
        }
    }

    return IdKRJ;
}

string WzzvNokyvAOKnsX::gqostQXoSBX(string kiCmatDI, int QdmUSIAjVvAIflu, double LSyubb, string QMkDRyUnXNnMiG)
{
    int vBckLGftyGMOWRoX = 2112427976;
    string GzkelWpOMHxOp = string("JLWAmlQEavEoAUGTvNfdIPAULFVwUhiFLAtXizwkDlAHbLjQd");
    string AaVrTuWoDPUa = string("wycADmBWLHezQNHdjvMcbOxXuZDyUiwUORrYmNVcYj");
    double XsmwPYRUBGqPejj = -32230.899977435634;
    bool BuDrlyGqPsZWN = false;
    int mjCNvBvRxzZ = 1062165773;
    double zATsvXiRh = -350976.7863350131;

    return AaVrTuWoDPUa;
}

WzzvNokyvAOKnsX::WzzvNokyvAOKnsX()
{
    this->QjSddQfNNd(-608588683, 731509.2190974231, string("lqwhRBzoogpmnufCgfiQkwlOYtxKqxLlZaiueWPzBmOvhIlsIMDAndGJoFTgtRdBADZAYKrAgZkgIhtCeRSiJUVAmvAysDcxDrzjETQqwEfFsmQTrAthxesxAnVFySypAjNQVfjMUPRkmdVkVqgGpXEpegXCOcWmUtVdpHHWXssxNpYuqvgDLEGrpnjIiFuChLxwzLJeTUGZoJHghqWfRUhIpMlbevNMdgitPKXVYXNZkkdbppDGwUBQEJ"), -36531.96070000832, true);
    this->dfmrDw(993084080, false, false, -464058650, -1522739589);
    this->tukAYLmCjyHRRq(-57047.93287342619, -623054039);
    this->yOWehOga(true, false, string("PNqDqHwujjjJxlYnPEmwPjgHlodjVPLdcYEQJcBwplitLljyryVJMWdIZZWWJ"), 711734.8176690324, string("MXXqZssagGYVpofbVWdYaEREIkrumXPGklfmMsRWKmcxwxTxpjYzgepoAkgaAKuAKDF"));
    this->nYuIkXAbSHQfI(1698729156, false, string("SeaSrJJusQpWVXmJLawcHYTpMTfvIwwwbquRxzhDcramtzpGwYwooeCmLSNaqXCLGoPkRGrDbulVYERouwyHTTNsmOckqVBuSQ"), -954987995);
    this->bKUckyu(1893168302, -267944.6556914675, 904783.5202277147, -1736151831, string("GooqmebwQspUrLHanKJxNnHPAKPOElfeMrZLjSeARyLLLqSFzpuJxJyBkHUQqGaBOSVDTHrffrJovqNOiAHEagDgkXJVOnxdGfggcEsRNBhNoSOfBThxDBRIwERgPkFQUNYpTCvbLOeugEPazMnvoilRHQnlhYqGTQpQerLwUubumacYhUwswyTdcwZSMtxKNvpImDyftrMrQJbgLCKPUBldlxlOkLbOCmYztNrxhibqgjnJTIVWojxqse"));
    this->NyOuAXzgc(string("bdqemNzdbshpEXaWkuHULQZzJoIkDjbGhYLZPdIRbJYd"));
    this->UMgpmCAgvTdfek(486089681, 565719.3104749171, -459381.8367920385, string("wMfNhEuRBjQLCmVXTqKMIYmOsineCOhJGWAqEEZQPeNTaoWUeMOKvTnYbBNsSDbcNNxPRCAGRNbkspPHzXHKylgCirgkbxcGxxgfLnqnyeUXsr"), 468175.2046507412);
    this->sXTzFoasPB(-1016754.3587161045, -229709744, false, string("yXrwbRfBEcnyylXVQPNMniklsazRFAzyYptiujrXTsMLzZewiGzHqLhBBPmhrEACdTjseDgddQkHSwjmdDbcWKfcoggcqtgwrtqIpFqikvXCwLDhGPRvkJuGcCAccDUJKKbEUKFcgCTyZjzhqvnjuuMIKVMAhFzyGcxxgxTHSvxbScwDlyGAFrzHysvzBnKZYRWAGKh"));
    this->AXWDbM();
    this->LtZRcjtbutp(string("lPnvxNCatAkKyOWWLZfYbuqtHxvRnOxhLMJhlpUkvIkUdFyOdhWfYVbtUkMGJSqfXvZmCFzYoFsRcgDRgJzcMfLPPtkEmj"), false, 416086.4898642552);
    this->gqostQXoSBX(string("udsLqtwpYRefADJQvTStXktvFHJGnEQLDuppvEutFadUpjAFRZJCRBxxEnNtJPusuyHPBxPyhlSMEJpadmiPHeFGpHignRPoxJaHQznccvtTjgVAjKiQtQaiqdEBIBkWvvUqTwLELqFUzEpd"), 788350000, 145662.29083167118, string("FgfewCVcuGpXwTeqIgbMIjFUyyqYyGjuwpphtZCndaeWbsoNJlhlgzhtOevCHDKPTlaJMXVDjeCitorJkdliZnLtvbYNEVrjRePFgOZPGVAhnTMOipaZRZYvnHlaDlscJzXZFhvGFwesXquiopHGvTVCVuzTpsRorbVDBVBtKPHsMobkyggaaZMNwkfjGaPgljCNAUVsXyXhqQANRDqBakKlAchHaRcMgRFswucpVAoGfwQbOqDxTLx"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ghyUgZVbqcrQ
{
public:
    bool GOVqMQytRgRNK;
    double TpaaVuKEOGFIbIGh;

    ghyUgZVbqcrQ();
    string sTDorRK(string kEiBiL);
    void FiIwnLqW(string vqyzIbMylLATI, double rvLXbELpWgPGyOvP, int IdivbYryi, string ujIIvcJTdz);
    string gulVouExanEFuIJ(bool fTRBAEpgDBDq, bool MdKFqlOWmmmkML);
    bool sbFUoEK(string naDRsEVQqhFaVRGM, bool IMauYUtxCeNu, bool pjSAZtTaJIB);
    string beyfJwdIgkFCtfqi(double ZOVdpHmnNl);
protected:
    bool GYezw;
    int fGtJyeqh;

    string uuUilQfRehoeL(int XcrMLgR, int uTOuRMMFwXIYwUW, string bRvWA, double fViIMJfp);
    bool DuUPRAHoB(string uAgRJO);
    double HhnezlgGITzXI(string zKEitTsFoqHqMkM, double HzeZjJJap, int hLqpaP, int FQbQjueqgce);
private:
    double gxRdQhYJQw;
    double ktWWrgrJX;
    double atpomXhDwuQbf;

    int gSuJRYR(int lDUxMSNlfy, bool yXdLM, double vwrQmWVoK);
    bool cjeipnvNpjg(double LpldX, int QvYxNzWEUzp);
    string vGhPsMJCEpHH(double DPNon, double xYZblUbNkXCITtwu, string RmCOlhSGOeBilbmo, int wqWfwkpt);
    double hzsNFxdQLTYDVagy();
};

string ghyUgZVbqcrQ::sTDorRK(string kEiBiL)
{
    string IfThMFURvyecouo = string("OGuhtjFcDBQIBfacsDYexbYgwrrtIUYPVOHRCCjoNghVyXGMWlkQBUBmtckaPUAKDdzToEqdNCZMieYAiQyJddItakRaKAgYmKQYsJznMIxAhdXTwWXXAEeYuzSeEgT");
    bool jnrgt = false;
    string syuGKQWGsKva = string("HdtexdHwlpJHCesXTZqzefwUamUCVFjvTltlOUJJpRxJWjoCICooGvNQBvSIwYhZGOvtuLJEtEeseNjcoyKkAFNGklyfjuLSOGDUBaGeJGuruNzwJXXxcRRLMGEsLVvHSUSYNYMLldOWlcWayZTVLfwtxPHAFGFNeKomkKclpnTLqXkTwBiuUznaNkljJTEKEVaixnroZDsJJFxCIQkWLBMuduOlrkBOCdXxt");
    string NODjxoTiNvmcvL = string("UcUeplwjpUWdccsVdeceFUbSETFLAwIsHZtSNUMfGmuUAXFVzQJSLUHVdZigwaFMvlUSkKHVQkJyzigWbDoGUOtjthZrQqqmXhfxSiAlHrvrYVSszYkceKtpasgeYxyLeOlLOvbKaEpjnwTbkfXtsslrgEjyYmpoZEWLbvmnAEKnzHxgEBUybztqReBYlVnLxH");
    string gQnfiVRzCc = string("etlaenCBhFIuGphLHBFSCvtUfhQWiEyXvlfkFzLOsDPQAKHgDqBCulAkOXMidbrxKmpGqncJKCpiHGhzVMvyeswtzPNqExYSdXvrVcOKaxWYkbCyjjZIXfwQSISOkQDzfPQmSKifLNyVrwrzLEQHXDnLhHVpefpQOijSJuXXKacShFkvqTRzynzmGfmPNkPauuXYQmbfsjATLtcSxfZIhgpowOELxUYQXPjTMzbGgMHEYQHovZsPrcv");
    int bRUKpp = 994924052;
    int IxZLG = 1242733494;
    int UUokiVriozN = 2143180205;
    string FFMqoCCG = string("MmAUrPvrfSvHiPspzAGtrAwdYPskGDpqagqkkPdQsFMiLsfMsbgfFwzWPOLeWjjRKyOCzevrBmwtAzrxjiDsecnUYPsPnFPICsWvcRCSBOpbGpegamCyDxBBmlBLoumorScn");
    bool EFGucdIIJxWZwP = false;

    for (int AgEsDf = 580200480; AgEsDf > 0; AgEsDf--) {
        jnrgt = jnrgt;
        syuGKQWGsKva = gQnfiVRzCc;
    }

    for (int cLwvGScbX = 1325159193; cLwvGScbX > 0; cLwvGScbX--) {
        FFMqoCCG += NODjxoTiNvmcvL;
    }

    if (gQnfiVRzCc < string("etlaenCBhFIuGphLHBFSCvtUfhQWiEyXvlfkFzLOsDPQAKHgDqBCulAkOXMidbrxKmpGqncJKCpiHGhzVMvyeswtzPNqExYSdXvrVcOKaxWYkbCyjjZIXfwQSISOkQDzfPQmSKifLNyVrwrzLEQHXDnLhHVpefpQOijSJuXXKacShFkvqTRzynzmGfmPNkPauuXYQmbfsjATLtcSxfZIhgpowOELxUYQXPjTMzbGgMHEYQHovZsPrcv")) {
        for (int JGkHF = 1791321951; JGkHF > 0; JGkHF--) {
            bRUKpp = bRUKpp;
        }
    }

    for (int lUorlzfi = 538619794; lUorlzfi > 0; lUorlzfi--) {
        gQnfiVRzCc = kEiBiL;
        IxZLG -= UUokiVriozN;
    }

    return FFMqoCCG;
}

void ghyUgZVbqcrQ::FiIwnLqW(string vqyzIbMylLATI, double rvLXbELpWgPGyOvP, int IdivbYryi, string ujIIvcJTdz)
{
    bool JFLOILJozjwJx = false;
    bool dwFpjl = true;
    bool jbqVCMwUdiZvQjo = false;
    int AuErWbzjHBYcgt = -519830733;
    int QdqdfdIgFOibfi = 1581532091;
    int kqUAFEbEHzwhVBT = 718075347;
    int EcPWks = 79608516;

    if (dwFpjl != false) {
        for (int JPqckHgsVnYI = 1999586467; JPqckHgsVnYI > 0; JPqckHgsVnYI--) {
            rvLXbELpWgPGyOvP -= rvLXbELpWgPGyOvP;
            AuErWbzjHBYcgt = IdivbYryi;
        }
    }

    for (int mUKYsgZgMxgKfE = 1147917940; mUKYsgZgMxgKfE > 0; mUKYsgZgMxgKfE--) {
        jbqVCMwUdiZvQjo = ! JFLOILJozjwJx;
        IdivbYryi = QdqdfdIgFOibfi;
        vqyzIbMylLATI = ujIIvcJTdz;
        EcPWks /= kqUAFEbEHzwhVBT;
        IdivbYryi *= EcPWks;
        EcPWks *= QdqdfdIgFOibfi;
    }

    for (int UwgsJZ = 622003601; UwgsJZ > 0; UwgsJZ--) {
        ujIIvcJTdz = ujIIvcJTdz;
        jbqVCMwUdiZvQjo = JFLOILJozjwJx;
        QdqdfdIgFOibfi *= kqUAFEbEHzwhVBT;
    }
}

string ghyUgZVbqcrQ::gulVouExanEFuIJ(bool fTRBAEpgDBDq, bool MdKFqlOWmmmkML)
{
    double CLJIUPBaieXCJFS = 945716.9905114928;
    string hdsZgPwuUPQ = string("UJUoDzWuJkMHQUmRNPOxACPOwZWCYynZsGAGucfVgSGtHqGyjQGKRYcGKJzfaLxaCcZFMTmpxdiWlMQwmUPFxQOLEUVGKdHEBHMIPROmRDmTeGNMDAhkCiogqFApCsglEEmrMlgNRhXFPYFdkehxOdVHlhMjYbDGsXCiTHjmZICnjbxjvnQOcZBHeMPbQSrnFhwapEIQtkgwsNUuBWNrmVxtCjhiRrxNBvktyWWugR");
    int LSdlsVMunDCoFnh = 1681913250;
    int dyGJb = -2010399840;
    int emVJvhQF = 1577131535;
    bool ukKbqsPkis = true;
    int kIlzPz = 670539643;
    int ZuGiWq = -687687073;
    bool qALekQaC = true;

    for (int XwWWbaXauzuUoUu = 1301633168; XwWWbaXauzuUoUu > 0; XwWWbaXauzuUoUu--) {
        kIlzPz *= emVJvhQF;
        hdsZgPwuUPQ = hdsZgPwuUPQ;
    }

    for (int XrlnViyqAgyCiPQ = 782254090; XrlnViyqAgyCiPQ > 0; XrlnViyqAgyCiPQ--) {
        ZuGiWq = dyGJb;
        LSdlsVMunDCoFnh -= dyGJb;
        qALekQaC = MdKFqlOWmmmkML;
        emVJvhQF /= emVJvhQF;
    }

    for (int yWqLHsHsHlBxp = 1053135995; yWqLHsHsHlBxp > 0; yWqLHsHsHlBxp--) {
        dyGJb = dyGJb;
    }

    if (MdKFqlOWmmmkML != true) {
        for (int RPYNuoSWn = 1311782431; RPYNuoSWn > 0; RPYNuoSWn--) {
            ZuGiWq = emVJvhQF;
            qALekQaC = ! fTRBAEpgDBDq;
            qALekQaC = ! qALekQaC;
            fTRBAEpgDBDq = fTRBAEpgDBDq;
        }
    }

    for (int LivQIBRNhRY = 162994933; LivQIBRNhRY > 0; LivQIBRNhRY--) {
        kIlzPz += kIlzPz;
    }

    return hdsZgPwuUPQ;
}

bool ghyUgZVbqcrQ::sbFUoEK(string naDRsEVQqhFaVRGM, bool IMauYUtxCeNu, bool pjSAZtTaJIB)
{
    bool kOIysH = true;
    string uRnYrhJSjqO = string("QAnoGYEFrVfODLRatXCrguJNMNsVeHdRejrufPGsjJ");
    bool thnsxfceV = false;
    string vqlTlxQdOnnc = string("umgEIJJuxDbJVIbbEzqaodybSPZhfyQrDSRnln");

    for (int xpxvehhGqXJgkdsI = 1727774338; xpxvehhGqXJgkdsI > 0; xpxvehhGqXJgkdsI--) {
        vqlTlxQdOnnc += uRnYrhJSjqO;
        pjSAZtTaJIB = ! IMauYUtxCeNu;
    }

    if (thnsxfceV != false) {
        for (int kErAHkypM = 1346149311; kErAHkypM > 0; kErAHkypM--) {
            naDRsEVQqhFaVRGM += naDRsEVQqhFaVRGM;
            IMauYUtxCeNu = ! kOIysH;
            uRnYrhJSjqO += uRnYrhJSjqO;
            pjSAZtTaJIB = IMauYUtxCeNu;
            thnsxfceV = ! thnsxfceV;
            pjSAZtTaJIB = ! IMauYUtxCeNu;
            naDRsEVQqhFaVRGM += naDRsEVQqhFaVRGM;
        }
    }

    for (int ctvcGap = 541488909; ctvcGap > 0; ctvcGap--) {
        thnsxfceV = ! thnsxfceV;
        kOIysH = ! IMauYUtxCeNu;
        vqlTlxQdOnnc = uRnYrhJSjqO;
        thnsxfceV = ! thnsxfceV;
        kOIysH = IMauYUtxCeNu;
        vqlTlxQdOnnc += uRnYrhJSjqO;
    }

    for (int psfQPqEAq = 1901405605; psfQPqEAq > 0; psfQPqEAq--) {
        vqlTlxQdOnnc = naDRsEVQqhFaVRGM;
        kOIysH = pjSAZtTaJIB;
    }

    for (int XreTknSG = 146575225; XreTknSG > 0; XreTknSG--) {
        naDRsEVQqhFaVRGM += uRnYrhJSjqO;
        vqlTlxQdOnnc += uRnYrhJSjqO;
    }

    for (int xiKdGgB = 1955918423; xiKdGgB > 0; xiKdGgB--) {
        uRnYrhJSjqO = uRnYrhJSjqO;
        IMauYUtxCeNu = thnsxfceV;
        naDRsEVQqhFaVRGM += vqlTlxQdOnnc;
        pjSAZtTaJIB = thnsxfceV;
    }

    return thnsxfceV;
}

string ghyUgZVbqcrQ::beyfJwdIgkFCtfqi(double ZOVdpHmnNl)
{
    string FBSJRAoFXLgRnZ = string("iDRfKsNcEmqzfqEYoeNPjvvZLDrOrDcrAiLKBcXklNkPKZPQUpEnHxZVmxqphNyFJFlmfMVaOOqFDGeAeGSEHcThpRhulbWERLZHmbMAmrUsWQMeblUsbTnUAOormczJbKPSUwMRScmFZVaDIlgPwMFKmNHbuyvzAodr");
    int JqhWKxFuidDsiYp = 1659461862;
    bool RRfnNE = false;
    bool rGMtuNkbGV = false;
    double SrSlhF = -196247.05171769144;
    string QFMzGVTYkqJtOvC = string("JrpvgQGriZLpweeOnGhlVTYzNJqovFoKWb");
    int YiGCXUuP = 981655691;
    bool UrynvnGe = true;
    double KwYIIOgNtlyWTCm = -354470.89885199117;

    for (int pmCYhn = 656912231; pmCYhn > 0; pmCYhn--) {
        ZOVdpHmnNl /= SrSlhF;
    }

    for (int OLLFCNc = 1502964949; OLLFCNc > 0; OLLFCNc--) {
        KwYIIOgNtlyWTCm *= KwYIIOgNtlyWTCm;
        KwYIIOgNtlyWTCm = ZOVdpHmnNl;
        ZOVdpHmnNl *= ZOVdpHmnNl;
    }

    for (int VSdkmqftr = 484711448; VSdkmqftr > 0; VSdkmqftr--) {
        continue;
    }

    for (int fVGWq = 769888812; fVGWq > 0; fVGWq--) {
        KwYIIOgNtlyWTCm /= ZOVdpHmnNl;
    }

    if (RRfnNE != false) {
        for (int LCyWKhVsmeusoj = 1379704113; LCyWKhVsmeusoj > 0; LCyWKhVsmeusoj--) {
            continue;
        }
    }

    return QFMzGVTYkqJtOvC;
}

string ghyUgZVbqcrQ::uuUilQfRehoeL(int XcrMLgR, int uTOuRMMFwXIYwUW, string bRvWA, double fViIMJfp)
{
    double WeUDO = -281268.51274200494;
    string pJgWLttxadgl = string("MBiSBcIMvNUaIqBKqlfNrzuCPmMKJDHFaRUEzyPxKVzQsIdnxaFTNuuwTjVxChxUhIUMfWpgKJPcWihYiDFrpzIEbyOzOvnbCbNBnjWsvjIL");
    int qcGmEqrWIJTGSnTY = -2054995587;
    string vlltrVpoxxsTlDC = string("viPwXHXLIvaQkZnWQnqPvNKJINRKqaOngfFpIOmGrHqrFsQnxExQkYaQCmsBqkiYxNxodciqVGAyhKvHiZPVYAKlKoAvTHNZAhqoywWcilPHtsomiqHWEtTYRYKDSUMAiytoClYCUPgnDTdsrIYmVaNvZKmzGMmrYksuaWIcixvRxWBLsgMJmnEyALGdpjFiBzHRNrkTxkunPoR");
    double GxUdlkjrjzVUqe = 987902.5531959577;
    double yDtNHVAp = -320529.5576517407;
    bool CCSiuunhQH = false;

    for (int UEemaFVxZSvFl = 116559144; UEemaFVxZSvFl > 0; UEemaFVxZSvFl--) {
        yDtNHVAp /= yDtNHVAp;
        vlltrVpoxxsTlDC = bRvWA;
        WeUDO += fViIMJfp;
    }

    for (int AjKrWoIrpkwmRxM = 1909840398; AjKrWoIrpkwmRxM > 0; AjKrWoIrpkwmRxM--) {
        XcrMLgR /= qcGmEqrWIJTGSnTY;
        bRvWA += pJgWLttxadgl;
        WeUDO *= GxUdlkjrjzVUqe;
    }

    if (fViIMJfp < 987902.5531959577) {
        for (int GVIQwYpIPcVPHl = 1848139151; GVIQwYpIPcVPHl > 0; GVIQwYpIPcVPHl--) {
            yDtNHVAp = GxUdlkjrjzVUqe;
            fViIMJfp /= fViIMJfp;
            pJgWLttxadgl += vlltrVpoxxsTlDC;
        }
    }

    if (fViIMJfp == -281268.51274200494) {
        for (int DAyoabsadQ = 1522934516; DAyoabsadQ > 0; DAyoabsadQ--) {
            fViIMJfp += GxUdlkjrjzVUqe;
            WeUDO *= WeUDO;
            bRvWA = pJgWLttxadgl;
        }
    }

    for (int lMlfMCqJ = 286266433; lMlfMCqJ > 0; lMlfMCqJ--) {
        continue;
    }

    for (int BJVSlUhZoQ = 1385294618; BJVSlUhZoQ > 0; BJVSlUhZoQ--) {
        fViIMJfp = GxUdlkjrjzVUqe;
        XcrMLgR -= uTOuRMMFwXIYwUW;
        uTOuRMMFwXIYwUW = XcrMLgR;
    }

    return vlltrVpoxxsTlDC;
}

bool ghyUgZVbqcrQ::DuUPRAHoB(string uAgRJO)
{
    int eaOLephJ = 1133011426;
    double iCORTTipyOmd = 833113.5148171509;
    double FxddKeo = 388211.0070867599;
    int BqtYowmHthGkFy = 43286478;
    double cNiKUwUODj = -195280.40685425894;
    double DTxtl = -178741.58813988767;

    if (cNiKUwUODj <= -178741.58813988767) {
        for (int cmaqIIsPGOPB = 1613222884; cmaqIIsPGOPB > 0; cmaqIIsPGOPB--) {
            iCORTTipyOmd = iCORTTipyOmd;
            DTxtl *= iCORTTipyOmd;
            iCORTTipyOmd /= FxddKeo;
        }
    }

    if (BqtYowmHthGkFy != 1133011426) {
        for (int STYMV = 1707692282; STYMV > 0; STYMV--) {
            DTxtl /= iCORTTipyOmd;
            FxddKeo *= DTxtl;
            cNiKUwUODj -= FxddKeo;
            eaOLephJ /= eaOLephJ;
        }
    }

    for (int YVfGleEhjqZHrGe = 1935366998; YVfGleEhjqZHrGe > 0; YVfGleEhjqZHrGe--) {
        iCORTTipyOmd = cNiKUwUODj;
        uAgRJO += uAgRJO;
    }

    for (int sXasSJHbO = 1076960726; sXasSJHbO > 0; sXasSJHbO--) {
        BqtYowmHthGkFy += BqtYowmHthGkFy;
    }

    return true;
}

double ghyUgZVbqcrQ::HhnezlgGITzXI(string zKEitTsFoqHqMkM, double HzeZjJJap, int hLqpaP, int FQbQjueqgce)
{
    int BjNDZp = -1568061392;
    double cjEzdhAzzFRb = 594887.3666072498;
    int hJBuzxWhnMpTDGxV = -119847101;

    for (int zxivQORKc = 774785979; zxivQORKc > 0; zxivQORKc--) {
        continue;
    }

    for (int naTVQmibmqIqOkrY = 558313932; naTVQmibmqIqOkrY > 0; naTVQmibmqIqOkrY--) {
        FQbQjueqgce = FQbQjueqgce;
        cjEzdhAzzFRb *= cjEzdhAzzFRb;
        hLqpaP = hLqpaP;
    }

    for (int JOLrIifuMkuSY = 1479526744; JOLrIifuMkuSY > 0; JOLrIifuMkuSY--) {
        BjNDZp += BjNDZp;
        hLqpaP -= BjNDZp;
        hLqpaP *= FQbQjueqgce;
        hJBuzxWhnMpTDGxV *= hJBuzxWhnMpTDGxV;
    }

    return cjEzdhAzzFRb;
}

int ghyUgZVbqcrQ::gSuJRYR(int lDUxMSNlfy, bool yXdLM, double vwrQmWVoK)
{
    string AYjyf = string("AWiQIzlgqtSNormzqPowliZKdJgaafkFgwdtYAqfclZAzvqMIyokwjxsr");
    bool XkAAqUQAIXJWMOXL = true;
    string ReHWzzUB = string("wujNIwmRoBeCapAoLwPkQQeKMEFNqfhcaukPDFQuQQrxdSsmVLKFnqxMQyMPnjwlIIFFSMFCgwVTZOPiSFPfJqnuurAGrLZLlGvHjibcSdkMVnbjaaziKLJmVfvwObQmhyebDRYceMsIJaJRrPGhodtbBkoPGMjpOTSMKZiWsuPeNXkgLDUbyJzgLiBBoDcHrwClidWKCZbRSVGdtsIaDuXcEufyA");
    double JSMHFrqCVtk = 532580.9835674015;
    int YCEipMigekznhHr = -1446146512;
    int qGqQOG = -460344955;
    double JwkcknoVb = -628082.5526801407;
    string oQDZgVGQQw = string("UurJiQpvuEcvwTfxhAdfrGjyOQvfDeeXXYRExUGPAhImmhylEufRQk");
    double LLGcCBdSkoYHFL = 78778.93605833821;

    for (int OHouSPyEsUDUQ = 633804858; OHouSPyEsUDUQ > 0; OHouSPyEsUDUQ--) {
        JSMHFrqCVtk = JSMHFrqCVtk;
    }

    for (int LiyzCSGMvhITt = 1047074211; LiyzCSGMvhITt > 0; LiyzCSGMvhITt--) {
        yXdLM = yXdLM;
        LLGcCBdSkoYHFL -= JSMHFrqCVtk;
        AYjyf += AYjyf;
        ReHWzzUB = ReHWzzUB;
        YCEipMigekznhHr = qGqQOG;
        lDUxMSNlfy = YCEipMigekznhHr;
    }

    return qGqQOG;
}

bool ghyUgZVbqcrQ::cjeipnvNpjg(double LpldX, int QvYxNzWEUzp)
{
    bool EzgSKPRPIx = true;
    string jqfcZNIvRs = string("lzYnYitSxXJUaNhPgCTcIRzJDUFRfagVDsBWMxiVIQcZuioZrtlTYtsziHxqGwAARsbuxZFMLsUMWsTWYrpYBcDzaSdUflYbOKQjpTBmAoNBrXBHvLSqUZxpsDClfGzkqXRXYoOTZVZswAxSwtmFpQbfCodsKMSoYYHVEiFSkfrFlFdKIqURdqazVVseOsRgS");
    bool reEeSjMrKSC = true;
    string RLZUsXYhhqcDokQs = string("DFjwcIqqvOHDGtxVWTcRVAgkqHpcXwRYebhsEqMJDFWZIzDbrCoglTUvvjfPRoErctHtjktMMcgzPDgWpDJLTcyOmzzdxIYYGxfEWpHvbtJZXUxUOcsaqSswCCuzjCBngGkOrctYRPlJD");
    int zoFjTYWuxOGjUIMn = -351314347;
    int aKyxIaGDTmAkgu = 2094374177;

    if (reEeSjMrKSC == true) {
        for (int ttzyslBDX = 1430539319; ttzyslBDX > 0; ttzyslBDX--) {
            continue;
        }
    }

    for (int zIJUHfj = 881526243; zIJUHfj > 0; zIJUHfj--) {
        QvYxNzWEUzp += zoFjTYWuxOGjUIMn;
    }

    for (int lAXxNbQQQPz = 602712271; lAXxNbQQQPz > 0; lAXxNbQQQPz--) {
        continue;
    }

    return reEeSjMrKSC;
}

string ghyUgZVbqcrQ::vGhPsMJCEpHH(double DPNon, double xYZblUbNkXCITtwu, string RmCOlhSGOeBilbmo, int wqWfwkpt)
{
    int HmnqnjuPUWz = 686325537;
    int EKDdfj = -947412583;
    double busiWIHGvtj = 439066.8832654324;
    double GWGLFId = -650687.9382567281;
    double KEnCLqZvtjFnB = 255837.48602736043;
    bool RsCmkSewV = false;
    bool AcsbBsr = false;
    string UoOHXqvoQlbhRhY = string("NZbPQmNBbDZOvUsrHYqtfwTGrYTlsVHMJpEYaDuwTBAxpuoDwmHymsDyQvIxiJIcQSZUCiCmxAhGvYBRnySIrAZBfiABzJrQhZPCcCzeXBgxDkdrJUGkaENZsRgtkfULvAqiXZBScNfTmKYZODxCYJpAHHYaAniwsdLNJykxUyDPFMJadXJifQxlWrKmeADBunhqvOQXbqSPqhp");
    double emTtavfOe = -1001838.4511235666;

    for (int VLqHO = 1987417392; VLqHO > 0; VLqHO--) {
        xYZblUbNkXCITtwu /= busiWIHGvtj;
        emTtavfOe += xYZblUbNkXCITtwu;
    }

    if (KEnCLqZvtjFnB <= -1001838.4511235666) {
        for (int IbmlhKwTOivj = 891303929; IbmlhKwTOivj > 0; IbmlhKwTOivj--) {
            KEnCLqZvtjFnB -= xYZblUbNkXCITtwu;
            busiWIHGvtj = DPNon;
        }
    }

    for (int NsstNQre = 250003187; NsstNQre > 0; NsstNQre--) {
        busiWIHGvtj += xYZblUbNkXCITtwu;
    }

    for (int ybERvFRInFUJg = 785473555; ybERvFRInFUJg > 0; ybERvFRInFUJg--) {
        busiWIHGvtj = DPNon;
    }

    if (GWGLFId == 439066.8832654324) {
        for (int hEXfpWx = 67723156; hEXfpWx > 0; hEXfpWx--) {
            continue;
        }
    }

    for (int sUoVxaNDLRZuAP = 667046550; sUoVxaNDLRZuAP > 0; sUoVxaNDLRZuAP--) {
        emTtavfOe += DPNon;
    }

    return UoOHXqvoQlbhRhY;
}

double ghyUgZVbqcrQ::hzsNFxdQLTYDVagy()
{
    double hdunitmFp = -555256.7436587809;
    double fSZuDtDM = 26746.637254776742;
    string ZSJnGbOWvlUvKptW = string("gIFsBIVwjmMEybRbLCPQXEXEbTKaSUHFrQGrQdQJGqOiWnfgVqEiOeswvgboaGpEOCAhENskUbcquSXXcovpeiniklChVBEoyUMZXvTeeFrDyRCnYZbBOHDxRsogxRWGdmjbjwteysXJAoeejRmOrtAmTIHJAEmYuwpUqCxgvvIGydy");
    bool PmcPEpdWDgG = false;
    double PoNWuhQEV = -475279.6757456833;
    int HBBCkgOCu = -708496061;
    bool xgdzXgJQVkl = true;
    bool vphDhysmBTIb = true;
    double yFXqsU = -96475.79671767766;
    bool IpeIj = true;

    for (int DvJHeMaWL = 503858237; DvJHeMaWL > 0; DvJHeMaWL--) {
        PmcPEpdWDgG = vphDhysmBTIb;
    }

    if (yFXqsU != -555256.7436587809) {
        for (int bFNCOMGKxNg = 649378195; bFNCOMGKxNg > 0; bFNCOMGKxNg--) {
            fSZuDtDM /= yFXqsU;
            IpeIj = IpeIj;
            IpeIj = vphDhysmBTIb;
        }
    }

    if (HBBCkgOCu <= -708496061) {
        for (int gNqrtXowB = 1718257545; gNqrtXowB > 0; gNqrtXowB--) {
            xgdzXgJQVkl = ! IpeIj;
        }
    }

    for (int yAbcLSNLMA = 89634243; yAbcLSNLMA > 0; yAbcLSNLMA--) {
        IpeIj = IpeIj;
        fSZuDtDM *= PoNWuhQEV;
    }

    for (int qMKQzXiDCUHPSLNe = 1008659126; qMKQzXiDCUHPSLNe > 0; qMKQzXiDCUHPSLNe--) {
        PoNWuhQEV = fSZuDtDM;
    }

    return yFXqsU;
}

ghyUgZVbqcrQ::ghyUgZVbqcrQ()
{
    this->sTDorRK(string("vBgNFAWrQvsUynDCyywVDKjSuuEXcwLoogjfsLtaEUdBOgEJvtXYHfSngMyYCmTBaAlKUizdfIwPeyVBJaxXHnLEuGbVcdBrOrVtjVXPNhiuLOZfFpqyBxxlEJoFKdyXVIwovKUdrCNbSnXbKMjSBCgMES"));
    this->FiIwnLqW(string("AAcGOmpVCotrfrY"), -990344.2464286959, -1349523852, string("OOGDbZCdXeKpCOLztGWfwzBrJcmrzAfoIFKQztIPSunOzarIgMEuNDlTyQwJioOPpBhmNXcXTOlRHEhFXkaJyIeCzkgYVFNNwhGNvvRniQkqYPYpyqYIyvuivghQlxNVHfoSjqAzHOlsLDYlVwgbHoBfNlTRJHDgAqxiJsnctbLEtcFBDbvMizLaTmbZcZKRGgQj"));
    this->gulVouExanEFuIJ(false, true);
    this->sbFUoEK(string("irgeYOHxcrKGISnzTIjfSIuThiEbyjvBdeuaXBHqdhhepgICRCghukylWbUptyXVGYvYxAsZFPrkQGJXXPYGPiKVevAjsDNRLYPudHXGzUYgULIkpESnMVjwwKRbJXrbydElz"), true, true);
    this->beyfJwdIgkFCtfqi(-449606.27453484037);
    this->uuUilQfRehoeL(1447689789, -1893180682, string("PGJDWnQxXEQZWsLrDOwFzAiVRxvFudVidDwBlcodhRvZIMJgBmBjHYvwNPICiKQxQTvTYtAsmGpCZQWbsquRpLAwNXOXVQGQmuPBtzfBNaGVWKACliwiHQzQyPjUqrgrKKyNcnEyaDuxMIhhclIyBKbzwAYYExawIy"), 809238.9525128297);
    this->DuUPRAHoB(string("klNABKLQjYyjewOxXUVkcbivxACXIWjVhTTgTgcyvbXKcZfCZLTWWNroPZVMlpGVfosltEqLsvZwzMOSlNBOOeGacNJTNbvBCqIHPgbnEQJyRiEXOUFPWCNQc"));
    this->HhnezlgGITzXI(string("WmAnSDBaqvZXAjhErfwgKuDeEoPUuNzYYdiRYxBTmZuTGADAtKzXGqrCBWvredavszxWYnQGntgodayUQIYOrmESXqHxqoEArPHdpuOIoAkoupUSlrCMnTijgxnmMhAqtEXFotgwMvawhrHQAdFeWYDhcesyHSTLQjaDVvXQcvBvwNlSGbThFVhIqEeUPszibCQtdOVYCygrz"), -160349.26117175515, -130536684, -1634211331);
    this->gSuJRYR(-280446224, false, -696591.7300331972);
    this->cjeipnvNpjg(-524625.2832454157, 1478360038);
    this->vGhPsMJCEpHH(-260360.87411101308, 676148.880672408, string("fAJDKPcpSdiUwLpuJdXySYVEXEAaXtLURmyqoQwKJmQnXiAYJBjZ"), -284376493);
    this->hzsNFxdQLTYDVagy();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YsmfhQNTautQl
{
public:
    int QodYZAVJLvHR;
    int CjNBLat;
    int DgOiS;
    bool NeeWRsFxShGgE;

    YsmfhQNTautQl();
    string VAOiHrpu(int dGyHbNGoIGnPE);
    bool SYAEcASpbCJ(bool PUGLlqM, bool FWonTLOBfx);
    double mYTumdnqDJW(bool nhrQshPJoa, int gmSqbFkGOqkVBWo, bool aoPxOTqMOPAfnX, int JQYjGVbovQ);
    string AAiZUAJ(int WlCgKjjdDYyYoV, double daMhrOjnxSlcD, bool aYPmXIwIeiqLLAi, int seIBhJeHN);
    bool EYyObgn(double kFOSEACpvDPu, double NntfAobkLZ, bool Yakuk, string JeoQecYW);
    int LpmJUXLfChVlZ(string HJIzeXFzaA, int lcsKyoLTM, double ZklIhdLNxexXL, double mdfvFltsIexiOJ);
    bool IQtbGFuayylEL(double tGHsqVoMtrqiWLp, bool zRbsDBJomcX, double szlVFYAHwM);
protected:
    double GvNquRKoyjxi;
    double OysPDUosPrMM;
    int lbTkXhPN;
    string VduQVzFvIRuCXVPy;
    int tkRAd;

    double JERTYuXvccFGfy(bool RdTcdAeIIsJOiH, double LcVFKl, string TnUSMnjCnbJVDzk);
    double QnwSZXed(bool NqpGlKxESC, bool PHooZvGASxfQVHip, string iMDZZFW);
    bool ljImCngjivyM(int vsobI);
private:
    int YpyhfjnIL;
    int bdWlfGQFrVHXnte;
    bool xskQridS;
    int oztuVonSixsqgDjT;
    int tjxgs;
    string nosaqoIbm;

    string AreNOFqiqiQeEa(int rDjTreGxLDVx, int VCKao, int LNicv);
    string knjmoZcJgakMTWQ(string zsQnOwpnqOPi, bool aQCQykJs);
    int BKWEwnZCvk(bool aJgydZUb, string MiyUNTWIqyuZUdJw);
};

string YsmfhQNTautQl::VAOiHrpu(int dGyHbNGoIGnPE)
{
    double lRjZwMdGKlckTW = 983283.8672621208;
    double fzetiAXUH = 592335.662258189;
    double FzXrtBk = -201661.44299794888;
    string oShayqIXwpWa = string("KSBlmICojRdzuXyLhlaoTeuamxSXsCnyHWEJNfvbTfYcatASnRtYfrbZbiiOYNiXimDBJbPnAPXRTStDilzPAcdyhjsqpTFbViIJUjOiDHtKyylmNhcYwmjKIjkKYObPIPzQAmbZMmmqDksmAPNuYdL");
    int fBXRdqRUKEqgjY = -403105720;
    bool fiGZJyGcmitOu = true;
    int ummsfBMi = 310602069;
    double TCHJwS = 28939.916053596036;
    string ACLvP = string("PdKPqDABXBN");

    return ACLvP;
}

bool YsmfhQNTautQl::SYAEcASpbCJ(bool PUGLlqM, bool FWonTLOBfx)
{
    bool uBgspGnsNyfdJW = false;
    int JoPUArTpStrolrpV = 202097165;
    string ZimzbepZeY = string("uOcnaHJYlQBvZLfDzSLffOIvJVRURIRAwTivYMIqIMcAXXvHTzNJXWwFmqsIwlhkzkJJJHoDLnaXDOlyptuirgDonFsBtHOKTDGIbqeUYLXXrLkWlTjqIOlrDQHymlRFEMqsmOtLMUInGXXeSlgYPRGJHdCnhVZZYDTWHvlPnUOiypIXgUtTuaMukPjxbvNDIJLfZJRQJtiKkUyCyrxRgTlmgnWVOjU");
    string QTJAfGP = string("WSpTdJUsckznCtWkCAUVrQbDOWTAVHwZJHezpmQjWYDotjrVBkTYPbupsomqErRUQfEWoGvxRkJyoHzRhUFlhZRUUNGcOXRTmyeFYzXIfAQbbkyfaz");
    string waFBtiJozniOiA = string("gLZLuSkzELGmsEIsKBwTBDiGsEIjlFXRvzcvCrLVezqxIojOaWWLExCSdFL");
    bool FFrzPfdWbxE = true;
    string iXliBeWrWnytbkd = string("oFsRrloOfpKBTJrrbwnihXEBosQquDDTpSUiVnDgDCfmTFAEMmsBmxehkTHeiEqmHEOUrxeRbdpnTDEteDHKToTPQEQQjMhcIfmENPKoZWogiBNMMtmzyQnZUURsymTJFfeQQqOswZrFRjQObgVrkCXMxijeiJnKAvsKpNJwNEzMrfGKmnGCaYYquUUoOwYYUVJNJCrRMiEFstZSENxWoGYtZCwICxuhXnQCeWNIWzvh");
    double zuuWxxIkatZAzK = -625394.9602848525;
    bool LzOpbkR = false;

    if (ZimzbepZeY == string("uOcnaHJYlQBvZLfDzSLffOIvJVRURIRAwTivYMIqIMcAXXvHTzNJXWwFmqsIwlhkzkJJJHoDLnaXDOlyptuirgDonFsBtHOKTDGIbqeUYLXXrLkWlTjqIOlrDQHymlRFEMqsmOtLMUInGXXeSlgYPRGJHdCnhVZZYDTWHvlPnUOiypIXgUtTuaMukPjxbvNDIJLfZJRQJtiKkUyCyrxRgTlmgnWVOjU")) {
        for (int nmcepS = 920874140; nmcepS > 0; nmcepS--) {
            FFrzPfdWbxE = PUGLlqM;
        }
    }

    for (int ThgmEkuiDGJKG = 956870806; ThgmEkuiDGJKG > 0; ThgmEkuiDGJKG--) {
        continue;
    }

    for (int tQBciKMBAjR = 1799551288; tQBciKMBAjR > 0; tQBciKMBAjR--) {
        QTJAfGP += waFBtiJozniOiA;
        LzOpbkR = FFrzPfdWbxE;
        LzOpbkR = FWonTLOBfx;
    }

    return LzOpbkR;
}

double YsmfhQNTautQl::mYTumdnqDJW(bool nhrQshPJoa, int gmSqbFkGOqkVBWo, bool aoPxOTqMOPAfnX, int JQYjGVbovQ)
{
    bool gyFPvlOrY = false;
    string gAhZhhUcKpUXaUA = string("JjynvhmebCOfdShkWFyCFeVVgatCsYsAMecCwtHbokFyMH");
    string czIdHPQzIKNn = string("mRKkhKxGfjsDyGBPTxGvsvmWwbJAgjCYRoNgaLggoAFjAGcoQzpGNYGcYnNblDhvmRdLNUErxENcLqkfNEfzLWetwrvXrEkiweukxWRZJzCdWmDKgJbEHfcYRllPAKVLhAirWEdjV");
    double dOSctOzJ = 591388.9741289383;

    for (int RVYGYfFvH = 1603495896; RVYGYfFvH > 0; RVYGYfFvH--) {
        continue;
    }

    for (int XfecMZQX = 606151010; XfecMZQX > 0; XfecMZQX--) {
        gAhZhhUcKpUXaUA += gAhZhhUcKpUXaUA;
    }

    for (int kbbCpeKP = 973318947; kbbCpeKP > 0; kbbCpeKP--) {
        aoPxOTqMOPAfnX = ! nhrQshPJoa;
        nhrQshPJoa = aoPxOTqMOPAfnX;
        aoPxOTqMOPAfnX = ! nhrQshPJoa;
    }

    return dOSctOzJ;
}

string YsmfhQNTautQl::AAiZUAJ(int WlCgKjjdDYyYoV, double daMhrOjnxSlcD, bool aYPmXIwIeiqLLAi, int seIBhJeHN)
{
    int aqczpQYBFDczliy = 1401158479;
    bool XMUrJAtMCqY = true;

    if (aqczpQYBFDczliy != -296438803) {
        for (int ghmyPeTlGwEJylRG = 197213663; ghmyPeTlGwEJylRG > 0; ghmyPeTlGwEJylRG--) {
            seIBhJeHN -= WlCgKjjdDYyYoV;
        }
    }

    for (int ioBRJXmHszqT = 278685900; ioBRJXmHszqT > 0; ioBRJXmHszqT--) {
        continue;
    }

    for (int OBIoYBgelSDmGn = 1770632846; OBIoYBgelSDmGn > 0; OBIoYBgelSDmGn--) {
        XMUrJAtMCqY = aYPmXIwIeiqLLAi;
        WlCgKjjdDYyYoV -= seIBhJeHN;
        WlCgKjjdDYyYoV = aqczpQYBFDczliy;
    }

    return string("jmelvGXOTVBSAnblUnEjUAvXOSKIwKTKlTzEMKkSPqmMCPenkmMEUjOYxMdEuvkedwswvsKwIDmEKRgORokvUTDAGPHqxv");
}

bool YsmfhQNTautQl::EYyObgn(double kFOSEACpvDPu, double NntfAobkLZ, bool Yakuk, string JeoQecYW)
{
    bool UgAAPCv = false;
    double NiAWguqe = -456677.6675080231;

    for (int cpTINQRcVOV = 551133646; cpTINQRcVOV > 0; cpTINQRcVOV--) {
        NiAWguqe *= NntfAobkLZ;
        NiAWguqe += NiAWguqe;
        NiAWguqe /= NiAWguqe;
    }

    for (int aoVUEHHmk = 1028641158; aoVUEHHmk > 0; aoVUEHHmk--) {
        JeoQecYW += JeoQecYW;
        kFOSEACpvDPu += NntfAobkLZ;
        NiAWguqe += NiAWguqe;
    }

    for (int IRjVwvpOetaFfgG = 99279546; IRjVwvpOetaFfgG > 0; IRjVwvpOetaFfgG--) {
        Yakuk = ! UgAAPCv;
    }

    return UgAAPCv;
}

int YsmfhQNTautQl::LpmJUXLfChVlZ(string HJIzeXFzaA, int lcsKyoLTM, double ZklIhdLNxexXL, double mdfvFltsIexiOJ)
{
    double OUsueaHRSd = 184030.92177597908;
    string JatCloubAOV = string("BftqZumVyxURDHVVQk");
    string HCYkMIAtLaVvnv = string("lNhbusjuhUolccmXqXqscnBHESwRHczEzWMoixXEFvHPDxdwtNwpGhrBtxjfuJvCgBruQmnSWHzSDgxhDoOUfeiXXPHNtjSqrggtvaYPUReWhnddJlfZBoenUEJRZ");
    double DEqatz = -231013.24692546675;
    bool HDuEIMsmoxcGEyo = true;
    string szhzsBnPpSzclk = string("jVTzvXecLdZLKddzxTgpzArdZzMQDuDTrXBBVYbjmylmtpnNDakTqItEzobWdXWZZqNnoGsQaYAyEYjeERGf");

    for (int xxosyepxxuhY = 2053083815; xxosyepxxuhY > 0; xxosyepxxuhY--) {
        mdfvFltsIexiOJ -= mdfvFltsIexiOJ;
        HJIzeXFzaA = JatCloubAOV;
    }

    if (ZklIhdLNxexXL < 515435.988722283) {
        for (int CoYaYzzFecVLcJ = 731351024; CoYaYzzFecVLcJ > 0; CoYaYzzFecVLcJ--) {
            OUsueaHRSd /= OUsueaHRSd;
            JatCloubAOV += szhzsBnPpSzclk;
        }
    }

    return lcsKyoLTM;
}

bool YsmfhQNTautQl::IQtbGFuayylEL(double tGHsqVoMtrqiWLp, bool zRbsDBJomcX, double szlVFYAHwM)
{
    bool HJRguxixAWja = false;
    int OWkWnjZPtbDzi = 1131712065;
    double gfTCT = -358837.8900567979;
    string ClfzXHmIyeTfKcTl = string("gmwAZUvPEKCrRSkGerKGDBMVybCmMxQnCGjYaJsHhSnvvJJBsnhVXhHJNTYaQHHpNcjgYbkPCUtTGYOwOLsPONXm");
    bool jvtrUivIja = false;
    string pKoSOUMlhjC = string("wPIWBymClVtPYyzhgzGoSFHcbKQuAQIDFLNjrsWEUfHxQqpwwxdyNZGGFfsuQgOLlWv");
    int nYkuy = -2038224702;
    double yNeKh = -599206.0158442798;
    double AFKQhzLs = 853398.9685213015;
    string XjxJMHillhVd = string("aJoItEsRDVZbuYTMkuWKhktZjXyOwdJUYvWMVkDCCUUTGRFJbHVTxZHrAdLAuFXGjBfepRlutij");

    if (jvtrUivIja == false) {
        for (int rfebZBmoXBP = 647805479; rfebZBmoXBP > 0; rfebZBmoXBP--) {
            szlVFYAHwM /= AFKQhzLs;
        }
    }

    if (zRbsDBJomcX == false) {
        for (int YthaxTNEm = 932686442; YthaxTNEm > 0; YthaxTNEm--) {
            yNeKh -= szlVFYAHwM;
        }
    }

    for (int OgEPYHZMjFe = 1615110462; OgEPYHZMjFe > 0; OgEPYHZMjFe--) {
        yNeKh -= szlVFYAHwM;
    }

    return jvtrUivIja;
}

double YsmfhQNTautQl::JERTYuXvccFGfy(bool RdTcdAeIIsJOiH, double LcVFKl, string TnUSMnjCnbJVDzk)
{
    bool tVkcS = true;
    int WCfpPubAKWorXjD = 1771578915;

    return LcVFKl;
}

double YsmfhQNTautQl::QnwSZXed(bool NqpGlKxESC, bool PHooZvGASxfQVHip, string iMDZZFW)
{
    bool wIXEruGPwmSzXrj = true;
    double NJuBdgCuLifNg = 299730.95645851496;

    for (int ATLzYdorypjIkIE = 58459579; ATLzYdorypjIkIE > 0; ATLzYdorypjIkIE--) {
        NqpGlKxESC = wIXEruGPwmSzXrj;
    }

    for (int wdWFOJ = 2086350471; wdWFOJ > 0; wdWFOJ--) {
        continue;
    }

    for (int tCAIUSnki = 477504130; tCAIUSnki > 0; tCAIUSnki--) {
        wIXEruGPwmSzXrj = ! NqpGlKxESC;
        NJuBdgCuLifNg = NJuBdgCuLifNg;
        PHooZvGASxfQVHip = ! NqpGlKxESC;
        PHooZvGASxfQVHip = ! wIXEruGPwmSzXrj;
        wIXEruGPwmSzXrj = ! PHooZvGASxfQVHip;
    }

    return NJuBdgCuLifNg;
}

bool YsmfhQNTautQl::ljImCngjivyM(int vsobI)
{
    string zhZdiZtILvPPhfVX = string("uZDruXyiTTbgwVrxMfpDqAPWkDNzooEdpwGKMkQKqIcZgAgLkvHxtoXewBxxsweTYIRSHRFLVCiZCtahFJmqpgoyQzYZpjlIRKzGSUaruDyKuwilqvMKsWUKULiiOYJJbSgOscwarJjYb");
    string xioshSDppkkUSiQE = string("orkAAeaFlxdQqktrhNzjBgGLTFCBAvVOtaSQjfFqUFvnlDfatMBdomrCyKmLVGRRlPUizQVgWXkvdTyYjoUQZocCcVjsXWFkbEtqyQtartlKcSWWfkUeEEeAXLvkIkqxvQWILxcQiSwIpfwyneJvZSfHHDRoNJtFSpwarGnFgTOCVbgvkjecblxXaBFoURKkeSrjMckfoXeHMFmjXWUNUImQslSEKtTSikIHIfEwUfgeydfHUGFtPYpHeta");
    int XOlLTUUc = -123001091;
    string zUakdVvMg = string("WwYRrYEGMRtLVqtfAppSmpolskQWZJJozMMlpClnTrpgNyCKQhgKWMPzBK");
    int kjKTcSafTyVFZV = 202362132;
    double IltTxKuLMVplH = 749097.4825951271;
    bool RtkRVSPajlazK = true;

    for (int qlpPtQiQavX = 1598766064; qlpPtQiQavX > 0; qlpPtQiQavX--) {
        continue;
    }

    for (int prLUFYII = 101073484; prLUFYII > 0; prLUFYII--) {
        continue;
    }

    return RtkRVSPajlazK;
}

string YsmfhQNTautQl::AreNOFqiqiQeEa(int rDjTreGxLDVx, int VCKao, int LNicv)
{
    bool AXjzNKYBeidcF = true;
    bool vCljzX = false;

    for (int FGPwDegZ = 1323996458; FGPwDegZ > 0; FGPwDegZ--) {
        VCKao += VCKao;
        vCljzX = ! vCljzX;
        VCKao *= LNicv;
        LNicv *= rDjTreGxLDVx;
    }

    for (int XvtncEgs = 237668158; XvtncEgs > 0; XvtncEgs--) {
        rDjTreGxLDVx /= rDjTreGxLDVx;
    }

    if (rDjTreGxLDVx < -1468733293) {
        for (int SArJtgwGv = 4867362; SArJtgwGv > 0; SArJtgwGv--) {
            LNicv = VCKao;
            rDjTreGxLDVx /= rDjTreGxLDVx;
            VCKao -= rDjTreGxLDVx;
            AXjzNKYBeidcF = AXjzNKYBeidcF;
            AXjzNKYBeidcF = vCljzX;
        }
    }

    for (int AxqDMvNIPo = 359815277; AxqDMvNIPo > 0; AxqDMvNIPo--) {
        vCljzX = vCljzX;
        rDjTreGxLDVx *= rDjTreGxLDVx;
        LNicv -= LNicv;
    }

    if (VCKao >= -1873715197) {
        for (int yXzKvId = 1585578325; yXzKvId > 0; yXzKvId--) {
            VCKao = VCKao;
            LNicv = rDjTreGxLDVx;
        }
    }

    if (LNicv >= -1873715197) {
        for (int JXsWjzMJlKOtHKn = 1472953554; JXsWjzMJlKOtHKn > 0; JXsWjzMJlKOtHKn--) {
            LNicv /= VCKao;
            rDjTreGxLDVx -= rDjTreGxLDVx;
            rDjTreGxLDVx /= VCKao;
            VCKao -= VCKao;
            rDjTreGxLDVx /= VCKao;
            LNicv += rDjTreGxLDVx;
        }
    }

    for (int RTpKVCGP = 1987114289; RTpKVCGP > 0; RTpKVCGP--) {
        vCljzX = AXjzNKYBeidcF;
        LNicv *= LNicv;
    }

    if (LNicv < -1873715197) {
        for (int WblyNZLotVjzKBK = 835847436; WblyNZLotVjzKBK > 0; WblyNZLotVjzKBK--) {
            VCKao /= VCKao;
            VCKao *= VCKao;
            AXjzNKYBeidcF = ! AXjzNKYBeidcF;
        }
    }

    return string("KFASmsEEVQoOIacyuUHHqkRbXgfeoODcroblfnWnhbWejGdqwWGZqXHdluOhJiHpeHvdlCNVBWotyoLswjBIRcSbmSvLrvtuHFiOhyY");
}

string YsmfhQNTautQl::knjmoZcJgakMTWQ(string zsQnOwpnqOPi, bool aQCQykJs)
{
    int eleGacZ = -1705488545;
    double rnkiQPvbDkeG = -574292.8248718302;
    string UhejfgSPXNTHpH = string("pATLGYNyFumBcgLPJNeSsHZUobgZjIQRZZgadficZUmDZIsuidpwaqbaSsRHMLsRcYUnbFKGlAPuuNyXFrXITUvSvtFKHLPdybSPSbBsQSSqBBVNZgRgBJnSmPveDtizIdIZRyKJDOIdqhMRafiO");
    bool aGxBXVnwWEDCWO = false;
    int HNBtokwl = 63781102;

    for (int rvRzh = 1463703077; rvRzh > 0; rvRzh--) {
        continue;
    }

    for (int jYREEnLrMtFSkS = 1985556513; jYREEnLrMtFSkS > 0; jYREEnLrMtFSkS--) {
        UhejfgSPXNTHpH = UhejfgSPXNTHpH;
        rnkiQPvbDkeG /= rnkiQPvbDkeG;
    }

    return UhejfgSPXNTHpH;
}

int YsmfhQNTautQl::BKWEwnZCvk(bool aJgydZUb, string MiyUNTWIqyuZUdJw)
{
    int zPIIkvMQEagaHvJ = 652703712;
    string nbAxKTAwJRoo = string("jinZPCKgSncz");
    bool ylVjwVEN = false;
    string zqBdHNJ = string("fabZQlPtGYWJd");
    bool RPNIJwr = true;
    bool GqlujdGLj = false;
    bool UUlUKKNMP = false;
    double ytkmz = -129069.60529024196;
    bool JPyyvGfFnPigg = true;

    if (aJgydZUb == false) {
        for (int AaIOu = 1080081951; AaIOu > 0; AaIOu--) {
            ylVjwVEN = ! UUlUKKNMP;
        }
    }

    for (int YnIibeFmgolvyAX = 884842394; YnIibeFmgolvyAX > 0; YnIibeFmgolvyAX--) {
        continue;
    }

    for (int iLNHL = 1004873035; iLNHL > 0; iLNHL--) {
        GqlujdGLj = UUlUKKNMP;
        ylVjwVEN = ! GqlujdGLj;
        nbAxKTAwJRoo += zqBdHNJ;
    }

    for (int TuHyjhUfN = 934211758; TuHyjhUfN > 0; TuHyjhUfN--) {
        continue;
    }

    return zPIIkvMQEagaHvJ;
}

YsmfhQNTautQl::YsmfhQNTautQl()
{
    this->VAOiHrpu(-1935431332);
    this->SYAEcASpbCJ(false, false);
    this->mYTumdnqDJW(true, 1703432593, false, -1445188409);
    this->AAiZUAJ(-296438803, 896047.2214949016, true, 1520288317);
    this->EYyObgn(487412.22629408946, -421253.6998330971, false, string("pUUOCkYIPuaDnlcZqrOTOlgrgkOLLwRQGIpQapflFZGqiJwizUZrOxJelqORdeNKlVpwVKkGVwhDyziDjBJjUQQrRvDHwIftsWYoiwomYPyiQtLPtnMoFTUPLMfgOIODSEPVBFKJjNvZoZUvYMDEWufuQJxZxsnkQZNvTVGWJGliNjgRRSiYruiTEnXiaCwspiODjHBfvmVhPnXTZpCmrkZSwJezUHWkBKwRCKzxBeFduDK"));
    this->LpmJUXLfChVlZ(string("qhVHPvGzvUsBrIcldNMsWMCX"), -371197538, 515435.988722283, -801668.9662568287);
    this->IQtbGFuayylEL(-552137.2076083628, true, -215907.02405698074);
    this->JERTYuXvccFGfy(false, 219174.50228334978, string("KTWaZljoKDxqwQKFNzraufSxdSAWqUVyCUaybuaIPgsNeRlUrlJCXZMAMzQBOwGsqojmEhbPtjTepTiFFnngJAucxSBihRxWCbCwdvHbVZLaQpPhUqhITBupMfUwHxsDZnBngHWeKbnoCQmRTUZZRFiWwH"));
    this->QnwSZXed(true, true, string("TkvIjpodcYivVMJxilgpEGKgXFVRcZZoShsNkONuFenluBwCVhQodKVgAaqRnvYRMQbZmdFiLDpNZcogXgNWrvEESyGiEMgaTMtSslwSbQgoYsYge"));
    this->ljImCngjivyM(-740569807);
    this->AreNOFqiqiQeEa(1727865041, -1468733293, -1873715197);
    this->knjmoZcJgakMTWQ(string("ZFqdvvfjLRXUBqBNEcxDmZCZnrEjgPpUhRktHeXrpVrCasOBjXqRbPqFdysNgKHAZSaeCuXAlAtlrsqRWHXFIIUxLSuaRkcPxWUkgGjrHWTucNCQlFNCpDjKaddpwnuIfrQgaPbecaeBDPgPyRlpwDNrIQJtITqdzKztlVXmoCTegLdjLTGbqMRfrYXQYIlPOdLWKnaDncBoHNeXNRVRnrNqCKifllqhQeEBNiGXevOl"), true);
    this->BKWEwnZCvk(true, string("OsBXqDhybviJSMYWOFSNnyRKstqXdxqmqKrJDCgbYRpxXRMWyHfkjauZTrfV"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GEYciQohvsykWJm
{
public:
    string ZSNyCBEb;

    GEYciQohvsykWJm();
    double gijgvqBoSu();
    int ISOMDzVuunE();
    string xwgBNHtSG();
    void eJzjeCKijHSFl(int cHDSWETtO, int EJuDn, double XvhUL, string kYRjHdfFfWihxsEo);
    string GxjUEpt(double PFIVdGTWKQolb, string WXkgjLQomYmf);
    void jzWhOSz(string BLKtmNdUfMcS, double EovSuIj, double hDohdyWfxCvWq, bool lewYwGM, string cppyFsx);
    bool kGFDuclcoQATTMAi(string ZLyuFZ, int JtWkuMandHwTs, bool ufVICXoQGvGCTae, string aNFXrPSWdDyTUo);
protected:
    int wNeWfKtzrgU;
    string DclxckkUSvHL;
    double sEvIbMdv;
    double oLBvOZoGsvKfp;
    double JLdAZPvkWfYyd;
    int HmGtTS;

private:
    int UrdpoKRPCTwi;
    bool mBpDieFO;
    string ixRzXA;
    double EUsqFHabgOEIEIb;
    int YVVia;

    void rVYgTJtQdjzIhBs(bool aiLYppq, int rjYMQQmQ, int CXCjUKuof);
    string CBkkw(bool WKcMHdZZDAAY, string ycOsv, string AWxoKs, int jjzPAdQDQDryQaOd);
    void TRiBb(int mqfvmb, bool yJGHBJcEBYDxRPc);
    double NKbLBCwVYWd();
};

double GEYciQohvsykWJm::gijgvqBoSu()
{
    string XISgNVRhp = string("QSJMauUnZfAuRiqVmVZfOsOXsJqI");
    bool ZOhMGxBpWjXEYnF = false;
    bool TDikLBtUCng = true;
    double YThHOaJS = -49537.08296464059;
    double jCckPnhNOX = 445443.4663084907;
    double mFsYlBRPUFxfnmMR = -974691.6803532387;
    int tDLXrQNf = 1280670046;
    string esOExAGirnSW = string("kYcgJsGXoNPbOjZdEUritAR");

    for (int itvUmxmx = 198050846; itvUmxmx > 0; itvUmxmx--) {
        continue;
    }

    return mFsYlBRPUFxfnmMR;
}

int GEYciQohvsykWJm::ISOMDzVuunE()
{
    bool gzDWIJPRDrIBzY = false;

    if (gzDWIJPRDrIBzY == false) {
        for (int ZUoljmTUJafLNHT = 350856352; ZUoljmTUJafLNHT > 0; ZUoljmTUJafLNHT--) {
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
        }
    }

    if (gzDWIJPRDrIBzY != false) {
        for (int LXViCcQ = 1765349347; LXViCcQ > 0; LXViCcQ--) {
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = ! gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = ! gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = ! gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
        }
    }

    if (gzDWIJPRDrIBzY == false) {
        for (int kyOlBGyf = 968899907; kyOlBGyf > 0; kyOlBGyf--) {
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = ! gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = ! gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = ! gzDWIJPRDrIBzY;
            gzDWIJPRDrIBzY = gzDWIJPRDrIBzY;
        }
    }

    return 1482781722;
}

string GEYciQohvsykWJm::xwgBNHtSG()
{
    int ATeMozmd = 652178244;

    if (ATeMozmd == 652178244) {
        for (int qnwCNIfAwitTQmn = 246267716; qnwCNIfAwitTQmn > 0; qnwCNIfAwitTQmn--) {
            ATeMozmd = ATeMozmd;
            ATeMozmd /= ATeMozmd;
            ATeMozmd -= ATeMozmd;
            ATeMozmd -= ATeMozmd;
        }
    }

    if (ATeMozmd != 652178244) {
        for (int ehZQeUG = 2037312782; ehZQeUG > 0; ehZQeUG--) {
            ATeMozmd -= ATeMozmd;
            ATeMozmd -= ATeMozmd;
            ATeMozmd += ATeMozmd;
            ATeMozmd -= ATeMozmd;
            ATeMozmd -= ATeMozmd;
            ATeMozmd -= ATeMozmd;
            ATeMozmd *= ATeMozmd;
            ATeMozmd -= ATeMozmd;
            ATeMozmd += ATeMozmd;
        }
    }

    if (ATeMozmd != 652178244) {
        for (int bBYoZvX = 815252184; bBYoZvX > 0; bBYoZvX--) {
            ATeMozmd /= ATeMozmd;
            ATeMozmd /= ATeMozmd;
            ATeMozmd *= ATeMozmd;
            ATeMozmd -= ATeMozmd;
            ATeMozmd *= ATeMozmd;
            ATeMozmd *= ATeMozmd;
        }
    }

    if (ATeMozmd >= 652178244) {
        for (int AqohHWbWjkHrW = 1388182868; AqohHWbWjkHrW > 0; AqohHWbWjkHrW--) {
            ATeMozmd *= ATeMozmd;
            ATeMozmd += ATeMozmd;
            ATeMozmd /= ATeMozmd;
            ATeMozmd /= ATeMozmd;
        }
    }

    return string("fitiSRJdSAHFuvTLKAXlLFQbyqzQeDGEeSZEYQHDojKZlMKFJoHBrMbXNTwUCloyvTAguvfywsKVeeepBxdQjpifYxmwnJlezIG");
}

void GEYciQohvsykWJm::eJzjeCKijHSFl(int cHDSWETtO, int EJuDn, double XvhUL, string kYRjHdfFfWihxsEo)
{
    double ZncsKIxH = -997459.908281933;
    string QgWzrCjGVAVi = string("yGQzgDJmB");
    double flcWmdeaGBFUV = 485341.78895557695;
    double YgggCxZ = -310510.59339813894;
    bool QpAFfw = true;
    bool qcQqDeWWc = true;
    string PozjGuLfXaJkH = string("KVPlVWPinmbtSwHGYhSCBbWDMOBsrwMVCaZQONya");
    double LSKQFQGriok = 230226.22692398133;
    string dluwVGoVWp = string("qYEjONwtZmRmZgTJCqCJsOVZVJCHEBwtqGGkuWDIwvYhGnLtSntDTSFowrymnGdNQiPEFryjZROiPrhNkxKHzjPj");

    if (YgggCxZ < -310510.59339813894) {
        for (int gdHjnsAwFCEZZE = 1403639322; gdHjnsAwFCEZZE > 0; gdHjnsAwFCEZZE--) {
            continue;
        }
    }

    if (QpAFfw != true) {
        for (int fhlElhEp = 1417579795; fhlElhEp > 0; fhlElhEp--) {
            continue;
        }
    }

    if (EJuDn >= -1119861039) {
        for (int ecZFtbcybnYaqbk = 166730153; ecZFtbcybnYaqbk > 0; ecZFtbcybnYaqbk--) {
            continue;
        }
    }

    for (int edOaroXFdJwvG = 690055033; edOaroXFdJwvG > 0; edOaroXFdJwvG--) {
        continue;
    }

    for (int fjMlMBQQ = 1039312024; fjMlMBQQ > 0; fjMlMBQQ--) {
        LSKQFQGriok += XvhUL;
    }

    for (int PAzvx = 618905402; PAzvx > 0; PAzvx--) {
        ZncsKIxH *= LSKQFQGriok;
        kYRjHdfFfWihxsEo += QgWzrCjGVAVi;
        LSKQFQGriok -= YgggCxZ;
        EJuDn /= cHDSWETtO;
    }

    for (int swUwMtiOqcGNamSN = 2011008793; swUwMtiOqcGNamSN > 0; swUwMtiOqcGNamSN--) {
        XvhUL += LSKQFQGriok;
        QgWzrCjGVAVi = QgWzrCjGVAVi;
        kYRjHdfFfWihxsEo = kYRjHdfFfWihxsEo;
        flcWmdeaGBFUV *= YgggCxZ;
    }
}

string GEYciQohvsykWJm::GxjUEpt(double PFIVdGTWKQolb, string WXkgjLQomYmf)
{
    string anmKDrb = string("aWcIzqCwawkREZIFQnvKDUvDftkeBUwugLliFcHydsqzkebxJCVCbWMWhGZSiHfyzljDiTedHCgCwgoNWXnyoLbAqZCFJbYlYcrHGKViCVRiknTimJjjhdDGDBXdsbiLnInXFJIOTEr");
    int giNDaRCedp = 209755812;
    double qndydeVMuFbmeu = -102217.93441453454;
    double QAStTVC = 440516.98446631274;
    string tiFnARb = string("hizOzqfrPlBkFptyigaPyaTHHwTKUizAlGOQVUywbBuBHDDgGPJRvCsWChLTdrsCMImENdlrDEHArrfELgMckWYgMRbXdQJfUwhlycmqBxUWIETRDWzYLUEpqRDzvdMLwzOVzssnEfgvzwfOYyPWMhSAzcsNeVRjozdekmyuZMgEcizaPKwrsaVlpkGTGexHHCZnLuetyi");
    string crkxNo = string("oQZozAeSkvGTzjWZkdlNlIgUnFfMKilXfPPwwWOXdgYxJMUtgzPXCPMZWwxiUDknWDFvnxjZmYArHfHanuAGYRkOHODEkusLCsoTlIyPINWbxTEeMEqdALrZiCdVLcJgxZQFcCFOTwWrjxIKfQwRFezUHErcnEJDofDtCLtNrrIfgcWgTHbQdsaQQlO");
    int zPmGm = -1649017025;
    double DuRvdGSGZ = -230368.7621811698;
    bool bAAEmCehrxeqz = false;

    for (int MROeF = 1479548363; MROeF > 0; MROeF--) {
        crkxNo = WXkgjLQomYmf;
        QAStTVC = PFIVdGTWKQolb;
    }

    return crkxNo;
}

void GEYciQohvsykWJm::jzWhOSz(string BLKtmNdUfMcS, double EovSuIj, double hDohdyWfxCvWq, bool lewYwGM, string cppyFsx)
{
    int PGncpLHaZXNLOh = 608908074;
    string sIqOjIILurff = string("wEbJNzeUXKjMnCGoqGgxvMzzoLYOvyvoWBAjHEZfyVsCvDFdzrlikRnEBKhOnayFFkcWYRTfpOLBWdZAtMgWZLlktjswdbsQQj");
    string UmTBu = string("dRHqQfMxXWdvSjnIkoIUnCWpXbOgePWrprFhZpRBVeHNUzekJiZrxBEKJhvpfdkRYuYZBcfhfBlhmnjBcNvrpwrZyFnLadRalDXhPfFIypspUdzOYrcmnYLMKTwwILLyYOvUwXZzAPCTEHmviASYLgvcWRvVuSVnmCasOqDDccP");
    double TGoMFjbIfvN = -717442.8669193549;
    string oWqvWKg = string("jChwixNFTEJaShPJMzEZqBzefMyfayYncSPgxrZkspXRWzDtxaJnARxRYkNTBRGBpFOheeUpiUTysuMmxUbrGqUNsjzfXTkczCiNrsdFGcBZDlxsgwcCMJyjFtTuirCnoACHYsgtnlocxUprdBHZnDCeSvtTRYZawtWOGFsZIMkaXGMNilImNZgep");
    string vmomd = string("hCndsIReNSnQTvlbObfCxeHGaIKtMqzSoKQuBmrxkPpfetjMHWzCTVIRWCglmDDrUXKAhtszRFspKdVXSOdksgrdTgPqZoOKucjnqhSbesBovJaVTTADDTbtcpGRuQGMbzbGOZbmKaRGPCFuZZjtmYvvkGupIquXoOHGFSVdBBmetTrVNHVFbDT");
    string RqkCfqttgo = string("xqgtRnyPgdTgouxiyxVRWKKYxUKCqXXxkqlXvIxswZGcAezJltlLuihrQPFtxnxRcfVqZRmeIQXgUdBbARFDzXvKVROpVFzlmgAdVLoIYoPxocoftzmiJenKUNkDerRCDeLqkPidmKPCYrlsYnHzbEWfjeZjvSxLEvLbDlQWuNYrfPTKIlEqcjKxeGuAb");
    bool IpZlv = false;
    bool HrdaPkEqPVd = true;
    int FUWjE = -759624646;
}

bool GEYciQohvsykWJm::kGFDuclcoQATTMAi(string ZLyuFZ, int JtWkuMandHwTs, bool ufVICXoQGvGCTae, string aNFXrPSWdDyTUo)
{
    string ryQvczTHvgJSCmky = string("xHrHohYtB");

    for (int jSxhoXfqphZ = 403338614; jSxhoXfqphZ > 0; jSxhoXfqphZ--) {
        ZLyuFZ += ryQvczTHvgJSCmky;
        ZLyuFZ += ZLyuFZ;
    }

    if (ufVICXoQGvGCTae != true) {
        for (int hIkpfmNvf = 849403502; hIkpfmNvf > 0; hIkpfmNvf--) {
            ZLyuFZ += ZLyuFZ;
            JtWkuMandHwTs += JtWkuMandHwTs;
        }
    }

    if (ryQvczTHvgJSCmky != string("xHrHohYtB")) {
        for (int KqQAs = 962643424; KqQAs > 0; KqQAs--) {
            ryQvczTHvgJSCmky = aNFXrPSWdDyTUo;
        }
    }

    for (int BUXcuHPcg = 2134309216; BUXcuHPcg > 0; BUXcuHPcg--) {
        aNFXrPSWdDyTUo = ryQvczTHvgJSCmky;
        aNFXrPSWdDyTUo = ZLyuFZ;
    }

    if (ryQvczTHvgJSCmky <= string("ARGZDtNtEEBVzumwqdicqpDULKfahfSvaKBwwsiOvNlWWLpQeYhcyyNfqXjRKNtkScVbWMyJaywxLEvBeUWBNskcQodRjASEUCPFVkquTsAbAeaGHFLhEMWgPtVyaGjJQFLHKdlKDGclfRRQkfUBIyomoycpifeYctydFBVrNmtdjqv")) {
        for (int JnxlQh = 160248284; JnxlQh > 0; JnxlQh--) {
            ufVICXoQGvGCTae = ufVICXoQGvGCTae;
            ryQvczTHvgJSCmky = aNFXrPSWdDyTUo;
            ZLyuFZ = ryQvczTHvgJSCmky;
        }
    }

    return ufVICXoQGvGCTae;
}

void GEYciQohvsykWJm::rVYgTJtQdjzIhBs(bool aiLYppq, int rjYMQQmQ, int CXCjUKuof)
{
    double CctydtkgVO = 755490.8879895072;
    int fjvoVVxOtIago = -438416722;
    int lMwcGOMC = 1513657334;
    int kuQicG = 1634335508;
    string hpcxRUEhldeNP = string("ArhbHIoBsuhpaqpyfwoRs");
    bool VrAXq = false;
    bool kOHCGyb = true;
    bool orcsGDWjoVg = false;
    double qVnemBgTYbwrU = -596032.6399230096;
    int zppdCOkzVLYMpD = -1985274261;

    for (int efcXjsTJ = 1001523927; efcXjsTJ > 0; efcXjsTJ--) {
        continue;
    }
}

string GEYciQohvsykWJm::CBkkw(bool WKcMHdZZDAAY, string ycOsv, string AWxoKs, int jjzPAdQDQDryQaOd)
{
    bool qIYNMMNFlR = false;
    double iJoyasiwHj = 1022176.3235593985;
    bool UsTlYSeTreczkKj = false;
    int PWjuI = 1099076408;
    int XWFPLvO = 1043732714;
    int BqdsYSFoEuKb = 1175148399;
    double fykVp = 356525.3477287256;

    for (int sSrjSErI = 1302718762; sSrjSErI > 0; sSrjSErI--) {
        ycOsv = AWxoKs;
    }

    for (int qEgSPtwQqdjF = 148755913; qEgSPtwQqdjF > 0; qEgSPtwQqdjF--) {
        BqdsYSFoEuKb = XWFPLvO;
    }

    for (int wipyU = 1207667994; wipyU > 0; wipyU--) {
        jjzPAdQDQDryQaOd -= PWjuI;
    }

    return AWxoKs;
}

void GEYciQohvsykWJm::TRiBb(int mqfvmb, bool yJGHBJcEBYDxRPc)
{
    bool qaOyC = false;
    double OvNwJtPVrmHby = 176153.95966166246;
    int rlSADklRyBKSAkm = -619596829;
    string TDaYCb = string("XLqKJoYBHlaFSsIywLQzskArIFMBMpnWZcImDRGroranjxUoDzRvFNBUDNyjpzVJDSTZQsZUvnZvdBgqPuAO");
    int rUzdWdqh = -1368043224;

    for (int eoarZzs = 738940773; eoarZzs > 0; eoarZzs--) {
        continue;
    }
}

double GEYciQohvsykWJm::NKbLBCwVYWd()
{
    string pHyeQihsmM = string("VOusSQUYdsrorecoDcSDEFiMVDvHnMBUcgrGXZEtjgrBlzsiNoTRXmVizQUiRtKQmsfnCDHFEaMLFmtfyUAwBUPSuTgEaZKenjvigETcOMCKiEVqMCExOibS");
    string IjbFaazxJPb = string("XYgcWGCpNoVQGqUaaKDHGliFyIRXxRguMELPqdDZjWhiwsCJOfGdrnGmXfoNTBpUlcIDpiWPuRvIZCEELmbdDlxcUilnRoKnodQnvOxArZVMorQTOIxmWZdhJiXhluKuKCzlmnxPFfHvcHRRyWXCyZsZcyMOSAGheUGCtNmSFZkbktdiqOxNQvjLbeQwjdyDboYadmRtoUaCJQZZvBFNLUfsUpDmGIfeiOsibcfKTgynLNXCrIxDOmqtNnClU");
    string QuwgGunWCQMGQLo = string("iBgLZKnV");
    string xmylTMKsGKGMKe = string("zJVFLuBWZqfntmLTQfbzLiMXBAGtwjmTpIUjDazDiDmCHAWAb");
    int WcixwRNHRa = -1127260355;
    string nadWqeIkEBhOXO = string("wMztqhyIweMNKFAjKVbzJjUPqpbgHjuSIIgRAGrkoBQOHwqFGjcsOkZfmgMyHbmMcDDjRKstGVsceOIlqRqwldteoKsHgXswpSLnsQnDGMcFRXjPNHFnjFRmsJYvFDSTOBFXtzzXmdNjYDimpcKDSikADsjLlGMChPzMWYeRxFKAGITPtGGvaEWLXrbgqBJBIMFeeuArKeNvWtUkxqrVAUJbkTIykrmkdcSmhyDmWXUmjJQi");
    int BmhhlGBI = 835098499;
    double UTgxWZVdqMtuYc = 204052.23552126918;

    if (xmylTMKsGKGMKe > string("VOusSQUYdsrorecoDcSDEFiMVDvHnMBUcgrGXZEtjgrBlzsiNoTRXmVizQUiRtKQmsfnCDHFEaMLFmtfyUAwBUPSuTgEaZKenjvigETcOMCKiEVqMCExOibS")) {
        for (int nRzup = 2140795238; nRzup > 0; nRzup--) {
            QuwgGunWCQMGQLo = IjbFaazxJPb;
            WcixwRNHRa += WcixwRNHRa;
        }
    }

    if (xmylTMKsGKGMKe != string("zJVFLuBWZqfntmLTQfbzLiMXBAGtwjmTpIUjDazDiDmCHAWAb")) {
        for (int HdJsnaE = 752367450; HdJsnaE > 0; HdJsnaE--) {
            pHyeQihsmM = nadWqeIkEBhOXO;
            IjbFaazxJPb += QuwgGunWCQMGQLo;
        }
    }

    for (int fwndgQIw = 526434853; fwndgQIw > 0; fwndgQIw--) {
        IjbFaazxJPb += xmylTMKsGKGMKe;
    }

    for (int UxdsmvCkxa = 177221504; UxdsmvCkxa > 0; UxdsmvCkxa--) {
        pHyeQihsmM += pHyeQihsmM;
        BmhhlGBI /= BmhhlGBI;
        IjbFaazxJPb += IjbFaazxJPb;
    }

    if (QuwgGunWCQMGQLo >= string("zJVFLuBWZqfntmLTQfbzLiMXBAGtwjmTpIUjDazDiDmCHAWAb")) {
        for (int ChNwGUSCmkXX = 2037982333; ChNwGUSCmkXX > 0; ChNwGUSCmkXX--) {
            QuwgGunWCQMGQLo = nadWqeIkEBhOXO;
            nadWqeIkEBhOXO = pHyeQihsmM;
        }
    }

    return UTgxWZVdqMtuYc;
}

GEYciQohvsykWJm::GEYciQohvsykWJm()
{
    this->gijgvqBoSu();
    this->ISOMDzVuunE();
    this->xwgBNHtSG();
    this->eJzjeCKijHSFl(-1497922822, -1119861039, 456955.234531829, string("EyuzaSOLUfRPUpJkKVttwpUpaPkSfQbkemfSOYIepUWugGfTDnkoAlvtkCvOMizMUgTHdlxiAkkMhWrYvYVqjZwYdcUKJcMeGGmoCqxrYtqrJIZNhnBhgEKKibjdqHdykBcencNiADillPSfnSLweDkOUqyzBybclTByxoaFLpmEMwJIgRtaNtLpCyA"));
    this->GxjUEpt(-609972.0283236094, string("MxhxUVvaodbyoWVOJBqDPqeYcztpntXMXpAOSSZhsCHSsOfnVLVUlpvprHfhHaivDfKvcybMxoniKhkHCUfYWfMlXqJdzFdxcZuBrgtQYUSzOOZFljSABYiqYIvPfyTeEFowVXiubOyvfGfJIgKZyEuyfEq"));
    this->jzWhOSz(string("ffTEBcMGaKHMoNBxlCbSOVsYefSCiKsQYTrruUimIxlHGGZIgcfFjAYgBXDNftGuAkPKTIvQYsdgjTlnISfGsJltwQcFfoMmBBdVhioAcWmVlBTcvjtTOQUDCzxjLtgohHgEfwxTmXKdWRaufsBDbJgDBqeMAeYXSBuIMaQWkxrtxchzevNOeZjzqIkeCvPzeybNDCfpmoTwOB"), 324257.7892035049, 536932.1150173675, false, string("HhGYtfDWQvZUcRkvDgXQRuUtZjUDXAld"));
    this->kGFDuclcoQATTMAi(string("avvZIMoAKbzIxRLEriGSeFNmjVjetEHfpJIOqUpUybCDogYlajhWeIsOJMUfrtWzrVUtJOxnHhGqgDYaRSNEojtsnrfTihZBVYjEfXAhZcclYVfchsCOdWDKXYBAWkZEMgBFNpQJIaZOvxOTWXXRoFKWkkwkatdmWqeFyNzlcMMXbZjJprFpUXFAOtWgIaSqS"), -259839314, true, string("ARGZDtNtEEBVzumwqdicqpDULKfahfSvaKBwwsiOvNlWWLpQeYhcyyNfqXjRKNtkScVbWMyJaywxLEvBeUWBNskcQodRjASEUCPFVkquTsAbAeaGHFLhEMWgPtVyaGjJQFLHKdlKDGclfRRQkfUBIyomoycpifeYctydFBVrNmtdjqv"));
    this->rVYgTJtQdjzIhBs(true, -1702358344, 1438651020);
    this->CBkkw(false, string("LLXYhXmiAsfastqovvshMBGhGCTxo"), string("BDdTghKAraVvDbjTAepzpfkaJtQQMWltlkwvgtbXdsdIGajFjXCYcpskfXECiaSkkYJdWTINgixxQDeRapvyprRgmxxipFlRxhEXwLOrcVbJiKSmSRhuGssvdisMIRuifHZUQRJDJmfkMfetVBjVWWzYtlDVhnYIbEejGkYoFbIAKGdABVaYobFTRpGOxvyrdLLyYlfnhcsyIffOPrLWuc"), -1801120347);
    this->TRiBb(-696796100, true);
    this->NKbLBCwVYWd();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WLyTfZS
{
public:
    int UyFvrvkSA;
    double eufYDlWpgaIzyOfu;
    int OaJQZQ;
    double LZXchOQm;
    string RXSiw;
    int wSnfbXxksSecl;

    WLyTfZS();
    bool xfgIAF();
    int vtosw(bool FeegfJGUsThsGpT, int bgxyni, int qvcNyyAqt, double fKBFrZt);
    double GJZjyEbDASPZ(string unoMGJRzzf, double EMufoAtyGtXRd, int BvUzzZ, bool kWYSYMrvkmGgvyUH);
protected:
    double TabPmNURkAm;

    string aAdTAIaD(int ICkmMdXZgLIbH, double cqGNfZJQnYkJDJVP, int SpaaGTK);
    string AIhtLNgjeWhvGd(string LaiVSUI, int zlTTopkdQMz, bool jlmnpTAmsEjapTJ, int RmlLYsZH);
    double DrNajfvNEjNCHY(double eFqdmBbl, bool ExEEdpGQRhzFkK);
    int trHdbJKJbuWgEe(string AOtnnp, string rcwCU);
    double clrlhMRptP();
    void HXeWCyjw(string YefMthonOCQ, int QisZBHdoMSLF, bool MwotiHUqpEG, string zvJwndMW, double BjYECQqGpZnJrAos);
private:
    double iaZuIdt;
    int SwkhqF;
    int turjrej;
    bool dPAXdulnDh;
    double FmBPYb;
    double CxosiWofiR;

    bool zgWLhAoyAERbGu(string tzMZvcdKBswH, double QhAJXz, int wSHUlaYaUbg, int qrQVGlyQZFSDms);
    string gqzWu(string YveYDpw, string HQTdeYRLK, double hkIRZGtXePtuQGN, string ISnsMlixhuzH);
    bool LmuWwfvBf(double nUhSVWjO, double zPnuBwx, string vgffZEViRJut, double KcXZEHwhjc, string ospzzeFPitpG);
};

bool WLyTfZS::xfgIAF()
{
    double kzTrfjmFg = 805429.1105552622;
    double dKyqzM = -322550.2209975339;
    string fXABcW = string("pJDAsJrTDIkZhiJpDwbRPdlJhplcjtwEswpKwO");
    bool raOfnjJfY = true;
    double sajvikHTTWXnH = -649919.303911736;
    int EbrFxYgSzlT = -2095519367;
    string WabnHBb = string("rNIeVOgpFRrxBVhRPvEujWbXTIPuJpyUwMQvjIGvOjIxnEaegfMmDCLGIBlesErlAvTkXdSrmSIJXtotjUsjKtmNPLUkYzlvtBkAxuKBTFVdmRkMlyzpRXjOWoWtmyMJOguVIfjZbBBtRYVqHQWFYviqOwyaBfvazFnDjrxFSTzDAsTHCDjSVnVuZDOYuRfVQcYjNFRMJdExUXStPPtodbSuQhYwMAd");

    if (dKyqzM > 805429.1105552622) {
        for (int FKNrSHYNcLKVM = 42449989; FKNrSHYNcLKVM > 0; FKNrSHYNcLKVM--) {
            raOfnjJfY = raOfnjJfY;
            sajvikHTTWXnH /= sajvikHTTWXnH;
            WabnHBb += WabnHBb;
        }
    }

    return raOfnjJfY;
}

int WLyTfZS::vtosw(bool FeegfJGUsThsGpT, int bgxyni, int qvcNyyAqt, double fKBFrZt)
{
    int eLPdpUnaIXKxg = 2137516530;
    string ZznWNmprCbtviq = string("arFrCkutBVloXEQFmXQnjHzaanprJWdAxKFeWkjzaIHVXIxXgfgTZPlGWDzebbWNmdEktASZgDThXxTWkESrnYHgLBgSmaPSPuXBMUzZTEjjHJPGRfUiqVEZpCMgKbvuqMZBYavVZLWHpEUvIFtKaoBMNsPcekllgkiayPat");
    string SHrgDqvsiqE = string("eeZfjNauSUjcBCZCubtPfAzgeDDZUFgOgKwWMieThPblP");
    string ESROeEUibpDy = string("YspaRjuxYZAcLnxwlguWPVMwMGiwYaGQgKiYIoWvsLwZdRIvQtLtdwhDSeaamLNtkwrgxjCKTxCgJMlLugtkPkTuTgIswjcUiuGAdyOfYJEwORgRaLSmuTSvtVsiecnCYKbjJkoqPJUceVmhwydXZWWysnhNzSHZqFdAvOXnRTLondyykHuUzzbESGzkuxzBBPDMDPjbfhflZAwFnQIXQzMMtGdprABkjkPgbfjkSoFOZPwvNrjxXZXYsXF");
    int cswQhtxUnqBffVg = -2055362795;
    string zgxSAPDpIziAVSk = string("YzqUbSfTRYoFTbsSgJFxZclAZNVjBrIuEtQEwLMvkqiNHDKORveuBlPnjFgSYHcqBBZlAFZbqTDqDlJonhwvirsJZZUutCEXRrFGvBKFodlxkRbbUyHpfOtAQzwWhtpeoSpodIeVvMXfDjSwcYRAnbTfMcXhmFVqajIbMGnsimlrDxNhZsgtEluojSAzLJUWiMoGGzwKLiaDtpSNizzYpaIFDYuxrIQwzFJnBuOajScxqJaLfDOxXmzfY");
    double iqzjUBOpQq = -1021660.590736488;
    int zodKknvHww = 1910335519;

    return zodKknvHww;
}

double WLyTfZS::GJZjyEbDASPZ(string unoMGJRzzf, double EMufoAtyGtXRd, int BvUzzZ, bool kWYSYMrvkmGgvyUH)
{
    int ZkKNKHVEkvtU = -741993543;
    double AIcRpSkLOTQYJDU = 851207.9436685031;
    double zXkdDToKHzBUeWxr = 619476.4879044059;
    double gXnkjEeQEkv = 1016290.9743532486;
    int cKcEjuyMzx = -222265263;

    if (zXkdDToKHzBUeWxr > 1016290.9743532486) {
        for (int rhKZMPHBMKxsxsFK = 1055897887; rhKZMPHBMKxsxsFK > 0; rhKZMPHBMKxsxsFK--) {
            zXkdDToKHzBUeWxr -= AIcRpSkLOTQYJDU;
            AIcRpSkLOTQYJDU /= EMufoAtyGtXRd;
        }
    }

    return gXnkjEeQEkv;
}

string WLyTfZS::aAdTAIaD(int ICkmMdXZgLIbH, double cqGNfZJQnYkJDJVP, int SpaaGTK)
{
    bool ipCNZScpMilY = true;
    bool jdlGlACPDtlyoI = false;
    double eHFojQD = 716137.2672177079;
    int CJzxHtNueThc = -1763693814;
    string jnWGrDQIzUvBV = string("BZQOFOWzbmzXqWYyZdPSSCiqUaqZobXFYMWZooobAfqVwgEQbHtkWpzBvyPkRHYKIPyNFvcHxUGENgvsvrXkFEmFjqjqcSLmzZgDpGrZkRGdvEarLUBjzMoMyWuTKfohhnACZrnBEEVYlLRPMKykaVTdCMGAsdzWlsEKaazRvxLCXYWOYJlzWjbhIMQUKbpxahbbEtzIBNtLNYkrEAlcl");
    int ofbanzxeAZpqfqV = -967861417;
    string yyVLcKxi = string("bMZelxiYyRCKCRrNjzGK");
    double lAJrX = 416254.1133547991;
    string tdmbXs = string("pdaFqEWrUaVpViZrKWDMFKwJgbCjuYppKbsqxbqbteymdBlgPhwuGFxhtfwHvgiaWRAZhUgnkFGtbFWNaMilZVjtGLrxabwsauabrSVvORVgPRVQcKALMWEKwuwzvpvNeRIAZgODPBrqgQasrKOZdXoqKtrJWxEPJmsXMhrOynTNYaZOLtWCOYBsLqJtdrSzslfWzDVJTDieIVsDDXNlrBYQAnyktEhtOuPzarHHsVuqPmRwQ");
    double EBSyNVUcm = 672190.4104856381;

    if (lAJrX <= 416254.1133547991) {
        for (int KNExmboymjYD = 1286047166; KNExmboymjYD > 0; KNExmboymjYD--) {
            continue;
        }
    }

    for (int QDSxZLsVFNmMVWXM = 705037211; QDSxZLsVFNmMVWXM > 0; QDSxZLsVFNmMVWXM--) {
        continue;
    }

    for (int gjPPhLrlopjgN = 574915980; gjPPhLrlopjgN > 0; gjPPhLrlopjgN--) {
        continue;
    }

    return tdmbXs;
}

string WLyTfZS::AIhtLNgjeWhvGd(string LaiVSUI, int zlTTopkdQMz, bool jlmnpTAmsEjapTJ, int RmlLYsZH)
{
    bool utuUFeBuKcyXd = false;
    double eYVemGBCTrFC = -966333.3544323482;
    double SkukdTSvcVZog = 626637.3122269511;

    for (int NDaXMmQoSs = 1507766719; NDaXMmQoSs > 0; NDaXMmQoSs--) {
        SkukdTSvcVZog *= eYVemGBCTrFC;
        jlmnpTAmsEjapTJ = ! utuUFeBuKcyXd;
    }

    for (int tXdqrYyLlDHVcpd = 1139887616; tXdqrYyLlDHVcpd > 0; tXdqrYyLlDHVcpd--) {
        SkukdTSvcVZog = eYVemGBCTrFC;
    }

    for (int TaXQjszHCKmdzQR = 1723115211; TaXQjszHCKmdzQR > 0; TaXQjszHCKmdzQR--) {
        SkukdTSvcVZog = eYVemGBCTrFC;
        RmlLYsZH *= RmlLYsZH;
    }

    return LaiVSUI;
}

double WLyTfZS::DrNajfvNEjNCHY(double eFqdmBbl, bool ExEEdpGQRhzFkK)
{
    double zGxTZKAz = -297682.6427163101;
    string mEgkZQcriJxH = string("TQhMIGnAHqzNwLUzDpVTkPlokzmd");
    double CnmDRHONHxT = 291712.71872923867;
    int axicDjvUArLCPyE = 474722841;
    bool GhuJhSQayPeiA = true;
    bool jayKRI = false;
    double LlgaJKVToJnsS = 519092.7854724047;
    double gcWklWb = -700511.6101347301;
    int HyNRCkKS = -1613497439;

    if (zGxTZKAz == -700511.6101347301) {
        for (int bJsNEP = 709797347; bJsNEP > 0; bJsNEP--) {
            continue;
        }
    }

    for (int QVODmamoO = 524516614; QVODmamoO > 0; QVODmamoO--) {
        gcWklWb = LlgaJKVToJnsS;
        HyNRCkKS *= axicDjvUArLCPyE;
        GhuJhSQayPeiA = GhuJhSQayPeiA;
    }

    for (int oAGiOrkYAtAJjUrG = 190449219; oAGiOrkYAtAJjUrG > 0; oAGiOrkYAtAJjUrG--) {
        gcWklWb *= gcWklWb;
        jayKRI = ! jayKRI;
        GhuJhSQayPeiA = ! jayKRI;
    }

    if (axicDjvUArLCPyE == 474722841) {
        for (int BxVKAeSDSTnb = 929946409; BxVKAeSDSTnb > 0; BxVKAeSDSTnb--) {
            LlgaJKVToJnsS -= zGxTZKAz;
            zGxTZKAz /= gcWklWb;
        }
    }

    for (int dbVUHETwCVXGxh = 711958052; dbVUHETwCVXGxh > 0; dbVUHETwCVXGxh--) {
        continue;
    }

    return gcWklWb;
}

int WLyTfZS::trHdbJKJbuWgEe(string AOtnnp, string rcwCU)
{
    int aUscMcwsbnkNzXb = -1358759733;
    int iYFWCsJr = 1004958791;
    bool HIBcnj = false;
    double WirKllhHVMwKu = 943926.0584883401;
    double mdCXGvltR = -957570.588254294;

    if (AOtnnp != string("WhvDQewWwWzKZVtzWxyspnmSIhiZFzBnbVSZiaXBiZlQfthuiAsfguZsEYWWgqlNjJcMNDOSvDEGnjDrzQdAHqgDURPpVdKirpFKWqboZqyueXWnsMNGocTxrctlMHHytkMOjJRIRAogpZliLSdbhCQyEvLQtIaprEQQrBxtufZglaunUrVuRNrkTyaafQsZJXmfIFhFfuxRNyYiBOymIqWikuuGix")) {
        for (int MwHRArkjugyipN = 1512901862; MwHRArkjugyipN > 0; MwHRArkjugyipN--) {
            continue;
        }
    }

    for (int CONvzs = 398139279; CONvzs > 0; CONvzs--) {
        iYFWCsJr /= iYFWCsJr;
    }

    if (aUscMcwsbnkNzXb > 1004958791) {
        for (int FXemD = 1953504117; FXemD > 0; FXemD--) {
            continue;
        }
    }

    if (WirKllhHVMwKu > -957570.588254294) {
        for (int REXNi = 588436931; REXNi > 0; REXNi--) {
            HIBcnj = HIBcnj;
            WirKllhHVMwKu -= WirKllhHVMwKu;
        }
    }

    for (int qqzMsoTHOzZd = 703416895; qqzMsoTHOzZd > 0; qqzMsoTHOzZd--) {
        mdCXGvltR -= WirKllhHVMwKu;
    }

    for (int BSAXctyvtBgujEeQ = 377976898; BSAXctyvtBgujEeQ > 0; BSAXctyvtBgujEeQ--) {
        rcwCU = AOtnnp;
        AOtnnp += AOtnnp;
        AOtnnp = rcwCU;
        aUscMcwsbnkNzXb = aUscMcwsbnkNzXb;
    }

    return iYFWCsJr;
}

double WLyTfZS::clrlhMRptP()
{
    bool JFdzgcLvTwZZZ = true;
    string yIgbUtFrjf = string("uWCmwwuKPhqNSeN");
    double ASaOm = 950297.8607212676;
    int GZdaAz = -1869189180;
    int iMWlvKRZn = -2002597462;
    bool oSpNHjhPD = false;
    double IFqelGxyxem = 795058.5050456368;
    int SlUQKiqgVjsXQr = 764330750;
    string BcldAgpMcdC = string("MBnSsTSGJwlBCehxvBTtyJoAVeDxJjIkMPVWJGuTSLAKZEYyMyBZBjaYrmjVMHjFkqKovu");

    return IFqelGxyxem;
}

void WLyTfZS::HXeWCyjw(string YefMthonOCQ, int QisZBHdoMSLF, bool MwotiHUqpEG, string zvJwndMW, double BjYECQqGpZnJrAos)
{
    string ScaYCbcIT = string("PexnIycEAykNfRegEIJMzSMEYzjnuwwtLOHKOIFQeRhLgPsRRLQSjIRCKLHVPhoTtSSxEfHWpAAPGAxRrlZugFmlsZOnfNlqkTSHnhXZqYrHxYLFuaVntXqZrpgOZnmyBrauqrpozaDBHUtEJEiwZfQwwZOdGCJYvSVidoxhdcUONyTkjZImCGbUlkyLmXCWpoApHkX");
    int wbHOMNbVAPTVmfV = -824259871;
    string jFuqUXXMSChwAN = string("JszGDbdQvgzRIoUuIvSmlmxafsyJOfCXJiezrVLtOlCNJjVctjUHbgfFZyTRWLEebBmulfTsO");
    string dKRlkpj = string("oKZAIdDejNiLCPqwSdikPicJEVYzZatMaKjxINSPgdPOFszWzWOSQPmuOLJKunYVQKuJMqSrgxeLAsfEoKnejsW");
    double xCpGBzevRaPTfJb = 227095.17733093855;
    bool YfkBMnhIJWNuxFTC = true;
    string GkQrbSW = string("DpiKFqIoztlDGnaNVdmdfWGlwOrHRjsTaLjUrDnozrXwDlhrgSzmPEZQIzsVeCCGASBkeloFkppiwiYJoQeATBWGgqUVlXBUyLdFXLpuZJEjtwCQyaKwJcyetqYfJLrWIrMHJBByzGAKqtNsrxluVHcQJOKOxplCqAzfrfnqxHQsvbSMLBSjCYqBIbqwoo");
    int qEJzVwavD = 100632153;
    double RbqNDzx = 372890.5112930244;
    double NiOzzMXq = -568510.5372481376;

    for (int ZsuOSBbVKvFcFVAt = 973129466; ZsuOSBbVKvFcFVAt > 0; ZsuOSBbVKvFcFVAt--) {
        continue;
    }
}

bool WLyTfZS::zgWLhAoyAERbGu(string tzMZvcdKBswH, double QhAJXz, int wSHUlaYaUbg, int qrQVGlyQZFSDms)
{
    bool HSLnnEMlIo = true;
    double GLOtrIvUbhuTjv = -25783.73397884739;
    double TMmNdei = 144163.84877684354;
    int yOHxPOTQMNBP = -733131146;
    string pTZMHSUyFfHhsyXr = string("EUXbgkDycNtgINhJfTHQtKdoJygixmwsMKFeKxvuMZcXbZtXTFmqSYZQHvgWVIAtUWbPbrJegMxEZkJEVRbXeCXuEpRWoQZvJvgtbrVLGFPPNpJfQuCHhejGwaNkvdwLfCdoyFbqSWaygonTIWpeGsukOqKkifeESkwnmwMVIRJSWyJvBfJmWCithBSAwWv");
    bool oXNPWzhbMbwpd = false;
    bool bAwFibbm = false;
    string IdxzHaJNNaq = string("iZehWZISnTVmVlygCWasiWJEaqojJHYFlwHplcHXHrxFdAXGUsLlcMThLsdrUuAWGIoRzdDjfgDmNngmIVBzHRkGpCmytCZqghwufIYpbZcPZqjsMJzZKDhzizbRUfEuqKfaPcVwKjvzDmzMwhvTldAJrbiQGQCnVtLTJLUjBppfbIUjPLwMZcBOSBhXrgQKotGdADxwwfgGnyDYStIOeamYDCmajHtPiyXcbBl");
    int iXUxAn = -109036085;

    for (int APtVHjJpOrUxlC = 1397356253; APtVHjJpOrUxlC > 0; APtVHjJpOrUxlC--) {
        yOHxPOTQMNBP -= yOHxPOTQMNBP;
    }

    for (int wtnFCxAKuIoy = 61793895; wtnFCxAKuIoy > 0; wtnFCxAKuIoy--) {
        continue;
    }

    if (qrQVGlyQZFSDms > -2107861155) {
        for (int TQvFYN = 882315144; TQvFYN > 0; TQvFYN--) {
            continue;
        }
    }

    if (bAwFibbm == true) {
        for (int xHpuAlSUx = 268123764; xHpuAlSUx > 0; xHpuAlSUx--) {
            continue;
        }
    }

    return bAwFibbm;
}

string WLyTfZS::gqzWu(string YveYDpw, string HQTdeYRLK, double hkIRZGtXePtuQGN, string ISnsMlixhuzH)
{
    bool HtJOaoWHi = false;
    int nBzYSBeFkSoQO = 861214863;
    int ANELaXDRgwzhkCz = 761680428;
    string fTfnaNXCWFPFmmy = string("LDOxwulbVpEgaosysYLiNiUWxDWHNoOSSiWyHPQhBHHzzwvoFmFNfbqdRBQoBBfYoWucSjMiBNuTvptqPHbyzCVNnfbvilJxNbyhzgoMiXmUoXjhXUKDFNMKhAgXlIBQgkfyqoNlNdW");
    bool mkqjBJmH = false;

    if (mkqjBJmH == false) {
        for (int DkWCAcCLkWJIPmY = 47634871; DkWCAcCLkWJIPmY > 0; DkWCAcCLkWJIPmY--) {
            continue;
        }
    }

    for (int fultNThT = 1305206632; fultNThT > 0; fultNThT--) {
        ANELaXDRgwzhkCz *= nBzYSBeFkSoQO;
        fTfnaNXCWFPFmmy = HQTdeYRLK;
        HQTdeYRLK += fTfnaNXCWFPFmmy;
    }

    for (int TgMQbsPtZNDXUdOE = 925098616; TgMQbsPtZNDXUdOE > 0; TgMQbsPtZNDXUdOE--) {
        HQTdeYRLK += HQTdeYRLK;
    }

    for (int pqpqQ = 220239116; pqpqQ > 0; pqpqQ--) {
        continue;
    }

    return fTfnaNXCWFPFmmy;
}

bool WLyTfZS::LmuWwfvBf(double nUhSVWjO, double zPnuBwx, string vgffZEViRJut, double KcXZEHwhjc, string ospzzeFPitpG)
{
    double YcmtwUvR = -65741.38448756235;
    int tZyenFZLjibWguyp = -265219516;
    string TyIUGITMQCRVgJ = string("ZlJTfyhlcYirWjCXOjIxFmVKClUbZNsLlufSppcAfhBVxfASMWQFGjGtxULyTKnyuZLHWozSIhPoGpLjqjfvIiMmoGXXqlYea");
    double IMNFNyh = 59055.46673947856;
    string DkxkK = string("cUmUnRJPgtphbMKztoZDMgHoKkldhLCQCUleUKJDJVMvfhEKQaRzaHhitWurJiXaiCgGzPugDslJmljskmwJiBQmnDRgEHyjRwnkVbAIyAfxjUmpfMkLHbioadbOEskQukZNsNHRbwxCqPFWjtJGYvJMLSHQvPcbegwYobdcsxPMsvLcYBACvFqlGffEhCvnmOgEyJUFGMtRAtAJOQYb");
    double Zwvgj = -163534.39464543428;
    string wOGnNcLcFyuM = string("DCjMhhbgOXBVKT");
    string LljPeVIb = string("yFRrknpkaeoUNYmYwTehIovpOjYKjNMtMEpWemtYoqxmfpLsPiKVpBrYAcpeCUtAzUhYYarhUFaxjkzdFejeykcmiZNlNMchUQtrbuywAWtqcvgTiSzDNkaGCgfZYQjplaVzlBwMQxUuhZGituoWuVByxwYfCZlYCuIfXQSkzXXdtgHDaIeUdRCm");
    int Jfjcbu = 67436069;

    return true;
}

WLyTfZS::WLyTfZS()
{
    this->xfgIAF();
    this->vtosw(false, 2661172, 475356562, 213697.67404927406);
    this->GJZjyEbDASPZ(string("VnxqbojjlwAKxWeuuqkZISqfopttCanUodTnVPhdabnJQwndChKLhQuBBxrkdWozkccyWsoIzjprDstlOXXYBQSHigkdGscTreZglwEVnIRvGPPEqfwYFoNViGOdQbkIGyvIJEDbvOqHyxZnuqOhMvJQzCOiP"), 901960.1749460782, -593291950, false);
    this->aAdTAIaD(2013474902, -332010.58881025977, -1318320228);
    this->AIhtLNgjeWhvGd(string("sNKuehpkWPFDMyyQgxfsGLpRmmXSDRnqgjACudDKumkILINKlPktldbCWAeKPehNoqvJvqOxXQaalDTpIniLMkljMjBevHQIOWubpJLb"), -388348124, true, -198996959);
    this->DrNajfvNEjNCHY(687364.3117156033, true);
    this->trHdbJKJbuWgEe(string("WhvDQewWwWzKZVtzWxyspnmSIhiZFzBnbVSZiaXBiZlQfthuiAsfguZsEYWWgqlNjJcMNDOSvDEGnjDrzQdAHqgDURPpVdKirpFKWqboZqyueXWnsMNGocTxrctlMHHytkMOjJRIRAogpZliLSdbhCQyEvLQtIaprEQQrBxtufZglaunUrVuRNrkTyaafQsZJXmfIFhFfuxRNyYiBOymIqWikuuGix"), string("PZkJUFmErCNujPyiWDdbXlXSgAZaQgNjAGWNPTNenErRnsNiSUYGWkWbgVvorj"));
    this->clrlhMRptP();
    this->HXeWCyjw(string("fSTSLTBMkIxxSM"), 481744594, true, string("iScExADaUJlWvDtCMyMsFCeeSNlzIksEPnBMZropONoXmECMWjGdMGTftjpOufYpegmOLqepIVVJykVASwYQUiHWSlmYxTDvtRTUltHFsXJmOJXJlvOSCauYkXTcWYsQZtjCaEWPJRHfOZQyzAQDDcDXnSpJaSzGarNRCHkIpjVHDTaIfYxzuuxn"), -241805.7338595386);
    this->zgWLhAoyAERbGu(string("awWqOwnPrQyYbevlXRqZVHNtlwVuBSrXTdkPpSibockwfPkUAZcyzmCluFYpktTBMiHpBDLcVbIjtEiactSWRygwGyKgWzRQMWyEzpoposqdlKkfcIBNK"), -226806.3446933606, -2107861155, 1607879382);
    this->gqzWu(string("OUr"), string("wQeFEkONhvSMSUoHAKbhqSrFYkIuvkpzHJZrHLfJenXVdDSjAgQKaTScQZVYMffjTmszCqTSgWbIaDGosNgmHkWnkDeqFIVZLjCUVpBZnScXskXHtBVVDJ"), -66672.27804559356, string("yxEYiGfujuqHjyobdxBfLkdbujXbVKJbWdFOZalwqTCNYICEZEHcuZFebdLbOoHsPbHkHflrxsEhveysdIdryCusoIuMBjXwAzLMhdNjsaFBipzYGTMhBMkyfTwaxrxYEpGsQDpMSZFYtdpztkTkPihHKkPWYiuHqLulcllZTGJpLrYbITgoLpMqZTtbHZKrjDxZHYzxrXTNHYSUOmLrypOsjKwrknNpZQizbIqbGmq"));
    this->LmuWwfvBf(317162.0605751237, -785931.833894838, string("xgwwEFnWjiniXuCveAeAICVqNCrjEsDTCyIIsrdcfBoIiAHAJQPuQuERiMvHYdWQCFIBvXXeMUVnSsBTBsuahcuHTJbxangkvVacNWWaLhczvjjkMjdUqpdRvHuKAlCmhVNYcGbFTAzJmPmEIWbFjNjTJX"), -934521.8947474263, string("KJDZCbTsqXhotQJIvXEYMPNkQpsLsKpG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hxVLEFD
{
public:
    double TkUZunkBtJvPz;
    bool YqCprDFajjsOXGL;
    bool HOMTwligZ;
    int QLwLpSJXq;
    double JWUcgEBg;

    hxVLEFD();
    void YtEmg(string GekxWoUdlCJYCQc, int UlmgiGgYo, double qApXbNeuEHCuCA, double ubdWEslukFubyOnX, double BzLCfH);
    int gowWCFIOOefKYqg(double hpktrskpnuVSnhNr, string VeMVrZrC, double oxQJNahtGs, double QzVBXIicgTPfIgAS, string OHnfKGPSFbUD);
protected:
    string VReUJA;
    bool qaZDGvAdN;
    bool avrEdcSjIKKqmdO;
    double resmh;

    void tUzYjRAKPFq(double SMxYuwWSTAIxIqm, string tgSyRuqxS);
    void OFpsEU(int lOKToUdgoWNzEbU, double unZjJZAakl, int AsiNEIdUYkiWM, string GKwLWrphpPiVPAXV, string zeCkom);
    double RmwicOclJkg(bool GfhOelqmgWED, int iDLVQuKKCdyCfSJR, int iRmCCGYLpJeKj, double zXEjUQfFtqjwFhy, double SOdCNrm);
    double RjuRzMGOZLi(double VXtZMVZsgRg, string EIvbj);
    double rCsGlwufJ(string iesYDVENkYdHP, string iSraXgZNtre, double ZjtIT, int ZugAZSYs);
    double OrJvbZbSzLoBbxEI(string qpOihRvweTBRXJEL, double kEYNJNAnvhhxg);
    int iJbzeZgQnlYNuw();
    double fPaFkLkPiQjBbS();
private:
    bool IwKuQBOwJcykri;
    double WItjur;
    bool QQKXbMngBLyjUqRI;

    int thsOwbhh(int nfydQKvIU);
    double nSxUTQa(bool lSnjii);
    bool svBXHHqSlRzeuLNS(bool afGnKOPGORFTwTV, string ctvBgLnynNhuoHZF, double KLPCWwdEywb, string lHnoUaENNIf, bool nBreJmynQDUhN);
    int kNGZXxhw(bool qvnxtiT, double HGfweeLmN, bool RTbLhULqoNwBjGj);
    string qbevNlqmiHjzo(bool VvNTYgBwR, string bilDyypqxAQgyW, string TxHpefygszx);
    int vVrSmPHVvPgMV(int fkFjqY, int DBLPsqfLNi, double PnGhUbinakPLay, int lgHRT);
    double HMTJrA();
    double CxcYN(bool bTguRwQtQOtNAfg, int tEvRkdJUkZ, string kyvqFYNIIrvrx, string DoUYcRiYEeDShv);
};

void hxVLEFD::YtEmg(string GekxWoUdlCJYCQc, int UlmgiGgYo, double qApXbNeuEHCuCA, double ubdWEslukFubyOnX, double BzLCfH)
{
    bool cYHJZrqBa = true;
    string gzUSFysPkuqH = string("uKFlQYdupeGbEpwTEafeMFzFjzUPGxFihClzVmRsfbYIaDasAqdCnNwLGAOKPHDOYQdkSyZwCAfUKWcwMaCauUWvGHjnMnEiq");

    for (int CGnnEtVECBtJor = 160623689; CGnnEtVECBtJor > 0; CGnnEtVECBtJor--) {
        continue;
    }

    for (int aqLmrPbfvh = 1114808822; aqLmrPbfvh > 0; aqLmrPbfvh--) {
        qApXbNeuEHCuCA *= ubdWEslukFubyOnX;
        qApXbNeuEHCuCA -= qApXbNeuEHCuCA;
        gzUSFysPkuqH += GekxWoUdlCJYCQc;
    }

    if (BzLCfH == -166197.9995973113) {
        for (int EfvTEiCjMJ = 2095405100; EfvTEiCjMJ > 0; EfvTEiCjMJ--) {
            gzUSFysPkuqH = gzUSFysPkuqH;
            GekxWoUdlCJYCQc = GekxWoUdlCJYCQc;
            ubdWEslukFubyOnX *= BzLCfH;
            BzLCfH = BzLCfH;
        }
    }

    for (int HLDdOHwIWJ = 1200177058; HLDdOHwIWJ > 0; HLDdOHwIWJ--) {
        GekxWoUdlCJYCQc = gzUSFysPkuqH;
        qApXbNeuEHCuCA = qApXbNeuEHCuCA;
        ubdWEslukFubyOnX *= ubdWEslukFubyOnX;
    }

    for (int YYUVdounUyJW = 967196712; YYUVdounUyJW > 0; YYUVdounUyJW--) {
        continue;
    }
}

int hxVLEFD::gowWCFIOOefKYqg(double hpktrskpnuVSnhNr, string VeMVrZrC, double oxQJNahtGs, double QzVBXIicgTPfIgAS, string OHnfKGPSFbUD)
{
    bool YaZQWsYqCSs = true;
    bool MnxBrrBKVy = true;
    string tRFwigfLfjrPjlX = string("mBpJRDzCuiiLxbbmfulICevBRHoRYZXeGRKhjzguAoiSjEYprzdeSSgThZvaJDhzoAosmCEKHoVTFIrRDYWMIyOZvZqlNurdMysfItFfmQcNWtXvitLUFMHbwQGEVNSYmwYwsLvglWQrTuzWDGLFvgnBCyIiLytiqPRAtqMXz");
    int LoEjhYtZTSZt = 575627245;

    for (int UnsFpibLC = 756910663; UnsFpibLC > 0; UnsFpibLC--) {
        OHnfKGPSFbUD = VeMVrZrC;
        tRFwigfLfjrPjlX += tRFwigfLfjrPjlX;
    }

    for (int dncqj = 931958622; dncqj > 0; dncqj--) {
        YaZQWsYqCSs = ! YaZQWsYqCSs;
        hpktrskpnuVSnhNr += QzVBXIicgTPfIgAS;
        YaZQWsYqCSs = MnxBrrBKVy;
        tRFwigfLfjrPjlX = VeMVrZrC;
    }

    return LoEjhYtZTSZt;
}

void hxVLEFD::tUzYjRAKPFq(double SMxYuwWSTAIxIqm, string tgSyRuqxS)
{
    string mozHhbjX = string("USWvkVNNrtlAEltHuVsTRxZIJFxeqbjwrvgFlRfBOUKQqkIoKwqCWVHgGfdQxyswnpgAHGKZDNZbLarZAJTLkITyRVxGquVuqjyuXlEYxgBmlnzNJcBhsGJPBdjMtwBfVikYrMFMpXrTCzWfJzVTFExEjPMYZhAiwNgVcVWCcbYMQYMUsKToIKGAMiweDFikAOifAALIYDDMeETFYsALu");
    string RoDHvBneKFIbYp = string("vNYUhuZSMgASVBjjOOTSfjRTXEtSjbCKEWKZCkKHDHVKIMVcKNCZIYGgqmKtOKgztJUTnzqb");
    int HzgbZvzMOlzN = -1285621372;
    double MWawtJHPGAsyBN = 259711.93719546116;
    bool cyTBmNBolmceUfO = true;
    bool lwXNHolGpNutW = false;
    double zidemqiRbGN = 662844.8488276758;
    bool jwzmYuLNIkCcoeq = true;

    for (int EJrOkVO = 764989340; EJrOkVO > 0; EJrOkVO--) {
        lwXNHolGpNutW = ! cyTBmNBolmceUfO;
        cyTBmNBolmceUfO = ! jwzmYuLNIkCcoeq;
        zidemqiRbGN *= MWawtJHPGAsyBN;
    }

    if (HzgbZvzMOlzN <= -1285621372) {
        for (int ENBqKRX = 257920043; ENBqKRX > 0; ENBqKRX--) {
            tgSyRuqxS = mozHhbjX;
            cyTBmNBolmceUfO = ! jwzmYuLNIkCcoeq;
        }
    }

    for (int NCziDINvwOvOEid = 468853780; NCziDINvwOvOEid > 0; NCziDINvwOvOEid--) {
        jwzmYuLNIkCcoeq = ! cyTBmNBolmceUfO;
        RoDHvBneKFIbYp = tgSyRuqxS;
    }

    if (mozHhbjX >= string("UmBkowuZWUlCemFMEDVHThGosFUPKuRmrcuLNlEPanSryMNtCOtlSEPhkWEDYlcdyXKbJiecHJhhJMzAgXsdbQdznrLbeVFwSNDieEtMPlOAHAVsyndOmpZGWzxOxWmnM")) {
        for (int LaqlXQvfa = 430903944; LaqlXQvfa > 0; LaqlXQvfa--) {
            lwXNHolGpNutW = jwzmYuLNIkCcoeq;
            cyTBmNBolmceUfO = ! jwzmYuLNIkCcoeq;
            tgSyRuqxS += RoDHvBneKFIbYp;
            mozHhbjX += tgSyRuqxS;
        }
    }
}

void hxVLEFD::OFpsEU(int lOKToUdgoWNzEbU, double unZjJZAakl, int AsiNEIdUYkiWM, string GKwLWrphpPiVPAXV, string zeCkom)
{
    double nNjzFjguQCZE = -625716.0921491942;
    string JysBcu = string("aMOmVunFeQnezRSuVjwvqOgCXtRTirdHumgmqpWtKoXyWhHZRAgoLGbOTuGuUCAqyfHIyNivlTMBpdQjfGGSLMwgPGNKqdZLUyAfHnyvhLHQHodwzucjqcpghWANvBAhLPdLkrwWdDmokuDQPjVxRbUtMqrziLSuMKpOmxEbeNrPYNehtwUwzP");
    bool rbheqcYSUc = false;
    int WSuNswrYQfFvDrTK = -554114329;
    int sezllhi = 202527994;

    for (int ggnzujoNlgUHY = 1577784023; ggnzujoNlgUHY > 0; ggnzujoNlgUHY--) {
        GKwLWrphpPiVPAXV += zeCkom;
    }
}

double hxVLEFD::RmwicOclJkg(bool GfhOelqmgWED, int iDLVQuKKCdyCfSJR, int iRmCCGYLpJeKj, double zXEjUQfFtqjwFhy, double SOdCNrm)
{
    bool LekZoWTQ = true;
    bool pCNEkpAULyG = true;
    double VSBWpZBitRyeH = -471643.8951155867;
    bool IzCTdRBVO = false;
    string lpCqswi = string("oGvBwRXiCWffsetwhPKEnyShjJYOXhaluCOyRDurvhvkURCpjMFStufuztEMpVbzvWXxieqAwdFFKCPGzQLnsLhIJBVNMtyDstFKMIEUtlPLpGTHuBcMOdzUlpXXQAaexOkvDyCQyRggJhIYNjwJdDZBqzThIOvJpFpOZgmdhVOdPawTNdXeAcXvuqsxGiXkpzXHJOagZNlQEEOjFEVWrZyhRfujFMHiBLYcpEnKrX");
    bool mRZksNDdlDbU = true;
    bool gitGBWvXD = false;
    double PApys = 978833.0111871964;
    bool VCjokGeuARAI = true;

    if (pCNEkpAULyG != true) {
        for (int UOCnrGmEt = 11954536; UOCnrGmEt > 0; UOCnrGmEt--) {
            pCNEkpAULyG = GfhOelqmgWED;
            GfhOelqmgWED = LekZoWTQ;
        }
    }

    for (int NFgOX = 250216238; NFgOX > 0; NFgOX--) {
        VSBWpZBitRyeH += PApys;
    }

    return PApys;
}

double hxVLEFD::RjuRzMGOZLi(double VXtZMVZsgRg, string EIvbj)
{
    int hSkYmPeBVgzlIE = -514084930;
    bool kMuLqhVCc = true;
    int DqKXpJxuP = -94580056;
    double SwGsimzEJ = 860701.2037570921;
    int kUaQAIeZ = -134194131;
    double WuYLonkWC = 324361.85177330574;

    for (int bxvnGRKMGTCk = 1486824999; bxvnGRKMGTCk > 0; bxvnGRKMGTCk--) {
        hSkYmPeBVgzlIE += hSkYmPeBVgzlIE;
        WuYLonkWC += SwGsimzEJ;
        VXtZMVZsgRg /= WuYLonkWC;
    }

    for (int QwNDVlgvitRyBRcm = 1157616579; QwNDVlgvitRyBRcm > 0; QwNDVlgvitRyBRcm--) {
        SwGsimzEJ = VXtZMVZsgRg;
        VXtZMVZsgRg = SwGsimzEJ;
    }

    if (DqKXpJxuP > -94580056) {
        for (int jFKCLfLSzNmr = 1729154745; jFKCLfLSzNmr > 0; jFKCLfLSzNmr--) {
            WuYLonkWC *= VXtZMVZsgRg;
        }
    }

    return WuYLonkWC;
}

double hxVLEFD::rCsGlwufJ(string iesYDVENkYdHP, string iSraXgZNtre, double ZjtIT, int ZugAZSYs)
{
    bool NkaoEJFXOkEBh = false;
    string VqDLeNafzHFWK = string("PaJPnuUdJuojHuujEJjnAtyRBRccuqmpGmbHmQpxYSrzYkmQZiTIJQugDNCsniINnSOaVTicHEGjZItpjEKSZmooGyRBvEFevJnqxLlxPUaChkrpMuvKvGzrTOJOGWSfOCpSDopSawRJBzBZseNaMwWiRzm");
    bool DCztBCWIK = false;
    double jeFBppRHck = -188512.1428990084;
    bool hGLXnxeWBQejO = false;
    double XFUYVDv = -390414.08595036936;
    bool glhbBqYsG = true;
    bool vxSUmeHgtEJr = true;
    int pBRoWLuEjy = 1776027387;

    for (int vXMqvuTVEeIHXKW = 1679072349; vXMqvuTVEeIHXKW > 0; vXMqvuTVEeIHXKW--) {
        glhbBqYsG = NkaoEJFXOkEBh;
        XFUYVDv += XFUYVDv;
    }

    return XFUYVDv;
}

double hxVLEFD::OrJvbZbSzLoBbxEI(string qpOihRvweTBRXJEL, double kEYNJNAnvhhxg)
{
    int rryWL = 1841645343;
    int qgWiEzSL = -275147653;

    for (int idjtGLyGALWPSSh = 2125369056; idjtGLyGALWPSSh > 0; idjtGLyGALWPSSh--) {
        rryWL -= rryWL;
        kEYNJNAnvhhxg = kEYNJNAnvhhxg;
        rryWL /= rryWL;
    }

    return kEYNJNAnvhhxg;
}

int hxVLEFD::iJbzeZgQnlYNuw()
{
    bool WibChpRBkH = false;
    bool waIslBOo = false;
    int ksZliyhmNmBpFLLn = 1315590402;
    int gtyxoEJdu = -34254547;
    bool eZafAsiAlKm = false;
    bool YBIjiCpotQ = false;
    double BNwhcdUvNwnhw = 196058.05359881133;
    double zNNyaljYwKicDY = 22710.03263369633;
    string SzcRofCLlDzo = string("NWgCCNoGBcVqCTtMEBcFhUtpmHIcRblYrdJHoRiAPmYrWixWDGIGrYKnufeXCBUbqGUmtWQVkrDuKUghJxLkEYBur");
    double nVXPUJxTWOvhX = -606361.7020971888;

    for (int PJshnxkidnfxSQ = 27826666; PJshnxkidnfxSQ > 0; PJshnxkidnfxSQ--) {
        continue;
    }

    for (int SJMBHPDFTxEAyZUP = 107100250; SJMBHPDFTxEAyZUP > 0; SJMBHPDFTxEAyZUP--) {
        WibChpRBkH = ! WibChpRBkH;
    }

    return gtyxoEJdu;
}

double hxVLEFD::fPaFkLkPiQjBbS()
{
    string XAbiNhJFJnl = string("tSQPGgLDNklcPPXqITlqvTeRWyOvSZlUVGOzQWEqthTzvodPabYwcltDZITRrMbKsPjVblMVwDoNCzDsJSwaGmhntmBpVqXiJBQxmEKSiKWqhwfXTfeTShWAaUNEQWKvdxWhAvtROLfXirwCPyawjqkDOVZKkgLXCULuQcNWeRPYeGwxDBVhDCGWcQaSjEJFnSEVKTGyvNVJiXVHgugbKllSBADmBMYVQxRZaNo");
    bool qrRnMw = false;

    if (XAbiNhJFJnl >= string("tSQPGgLDNklcPPXqITlqvTeRWyOvSZlUVGOzQWEqthTzvodPabYwcltDZITRrMbKsPjVblMVwDoNCzDsJSwaGmhntmBpVqXiJBQxmEKSiKWqhwfXTfeTShWAaUNEQWKvdxWhAvtROLfXirwCPyawjqkDOVZKkgLXCULuQcNWeRPYeGwxDBVhDCGWcQaSjEJFnSEVKTGyvNVJiXVHgugbKllSBADmBMYVQxRZaNo")) {
        for (int aXMAWZMDbdjPzw = 1304524471; aXMAWZMDbdjPzw > 0; aXMAWZMDbdjPzw--) {
            qrRnMw = qrRnMw;
            XAbiNhJFJnl = XAbiNhJFJnl;
            qrRnMw = qrRnMw;
            XAbiNhJFJnl += XAbiNhJFJnl;
            XAbiNhJFJnl += XAbiNhJFJnl;
        }
    }

    for (int LVsTwURa = 860613786; LVsTwURa > 0; LVsTwURa--) {
        qrRnMw = ! qrRnMw;
        qrRnMw = qrRnMw;
    }

    for (int aCZTNlLAM = 1556248796; aCZTNlLAM > 0; aCZTNlLAM--) {
        qrRnMw = qrRnMw;
        qrRnMw = qrRnMw;
    }

    if (qrRnMw == false) {
        for (int iTBStjZBdHm = 582639045; iTBStjZBdHm > 0; iTBStjZBdHm--) {
            qrRnMw = qrRnMw;
            qrRnMw = ! qrRnMw;
            XAbiNhJFJnl += XAbiNhJFJnl;
            qrRnMw = ! qrRnMw;
        }
    }

    for (int YZbZY = 407350342; YZbZY > 0; YZbZY--) {
        XAbiNhJFJnl = XAbiNhJFJnl;
        qrRnMw = ! qrRnMw;
        XAbiNhJFJnl = XAbiNhJFJnl;
    }

    return 579860.235754485;
}

int hxVLEFD::thsOwbhh(int nfydQKvIU)
{
    bool QIqSK = false;
    bool vMLpQw = true;
    int kFSTaqOxJpwhtPbv = 1962392509;
    double iejnHA = -900134.5957532916;

    return kFSTaqOxJpwhtPbv;
}

double hxVLEFD::nSxUTQa(bool lSnjii)
{
    int XcQEjxRWcvje = 1049247363;
    bool ctajx = false;
    string ZUjKO = string("fdzxHylSyZNtnQQSNzYAmaHzmZvfeusWRDCAlpYRtaARvjMNBVesBGowuehgeKJAJdyUDwHFzFiLQRYfghpjtdYiPfzHofXPgwDtEIfKRNGyzOJbFxQptrXUOkUJLCOTtKOQvudZzBoubSlATyJbbdefymRwJFAcDTgfwokORsCAuFFwHkIFyWevz");

    if (ctajx != true) {
        for (int LvvwRDb = 261082413; LvvwRDb > 0; LvvwRDb--) {
            ZUjKO = ZUjKO;
            ctajx = lSnjii;
            ctajx = ! ctajx;
        }
    }

    if (ctajx != false) {
        for (int lFXkErasyHDoaMp = 894779493; lFXkErasyHDoaMp > 0; lFXkErasyHDoaMp--) {
            lSnjii = lSnjii;
            XcQEjxRWcvje += XcQEjxRWcvje;
            ZUjKO += ZUjKO;
            lSnjii = ctajx;
        }
    }

    for (int DDEUpLeBm = 411109573; DDEUpLeBm > 0; DDEUpLeBm--) {
        continue;
    }

    if (lSnjii != true) {
        for (int xPyqjBEktL = 743133415; xPyqjBEktL > 0; xPyqjBEktL--) {
            lSnjii = ! ctajx;
            lSnjii = ! ctajx;
            ZUjKO = ZUjKO;
            ctajx = ctajx;
        }
    }

    if (lSnjii == false) {
        for (int ICpykTnycZxXVR = 1036331965; ICpykTnycZxXVR > 0; ICpykTnycZxXVR--) {
            ZUjKO += ZUjKO;
        }
    }

    for (int geosI = 1097043327; geosI > 0; geosI--) {
        lSnjii = ! ctajx;
    }

    return -524036.7023144924;
}

bool hxVLEFD::svBXHHqSlRzeuLNS(bool afGnKOPGORFTwTV, string ctvBgLnynNhuoHZF, double KLPCWwdEywb, string lHnoUaENNIf, bool nBreJmynQDUhN)
{
    int BbvsQqRn = -1363668117;
    int VKjLfrbyYiQvDYR = -78575664;
    int oeUhvhmwqzYgP = -617935816;
    double UWQmiqokiwbals = -774866.2886900896;
    int CepwkRyateRjmPwD = -1024918122;
    double aIEfUj = 455241.0961676562;
    double zqHBKXwMxDMsa = 385262.52675743564;
    bool fdQmkVxwYOe = false;
    int tEHDhxtCZ = 81142338;

    for (int IcUieRN = 1112219341; IcUieRN > 0; IcUieRN--) {
        fdQmkVxwYOe = afGnKOPGORFTwTV;
        tEHDhxtCZ = oeUhvhmwqzYgP;
        UWQmiqokiwbals = aIEfUj;
        UWQmiqokiwbals += aIEfUj;
    }

    for (int BbRWbRDRFvjxr = 165299994; BbRWbRDRFvjxr > 0; BbRWbRDRFvjxr--) {
        continue;
    }

    if (nBreJmynQDUhN == false) {
        for (int dpjOOfng = 1025219581; dpjOOfng > 0; dpjOOfng--) {
            continue;
        }
    }

    for (int BoxsIqLMhSVeZcLs = 212452665; BoxsIqLMhSVeZcLs > 0; BoxsIqLMhSVeZcLs--) {
        BbvsQqRn = CepwkRyateRjmPwD;
    }

    for (int bzzavatGXt = 1606243947; bzzavatGXt > 0; bzzavatGXt--) {
        continue;
    }

    return fdQmkVxwYOe;
}

int hxVLEFD::kNGZXxhw(bool qvnxtiT, double HGfweeLmN, bool RTbLhULqoNwBjGj)
{
    double CWiIDdI = -750345.8426651969;
    double zVfRefTSzA = -454875.9016851134;
    double MKWzPHTEqId = -394033.2679116521;
    string VAQTVul = string("YwMDRUuwprYRvRWdXBXMkKxJronELqyugKmgqcm");
    bool OJnKvGvXfg = true;
    int snJiqePNb = -799491432;
    double RmIEG = 1040143.3186912672;

    if (CWiIDdI != -394033.2679116521) {
        for (int RMATQfzAnRPM = 1872762436; RMATQfzAnRPM > 0; RMATQfzAnRPM--) {
            RTbLhULqoNwBjGj = ! RTbLhULqoNwBjGj;
            CWiIDdI = MKWzPHTEqId;
        }
    }

    for (int RvZQBkTwz = 1444834522; RvZQBkTwz > 0; RvZQBkTwz--) {
        continue;
    }

    for (int ntwPRzJXW = 1848111205; ntwPRzJXW > 0; ntwPRzJXW--) {
        RTbLhULqoNwBjGj = ! RTbLhULqoNwBjGj;
        OJnKvGvXfg = ! OJnKvGvXfg;
        CWiIDdI = HGfweeLmN;
        MKWzPHTEqId += CWiIDdI;
    }

    for (int BjAXXom = 2078884919; BjAXXom > 0; BjAXXom--) {
        RmIEG *= HGfweeLmN;
    }

    for (int jrMclxmv = 379186759; jrMclxmv > 0; jrMclxmv--) {
        MKWzPHTEqId -= CWiIDdI;
        snJiqePNb /= snJiqePNb;
    }

    return snJiqePNb;
}

string hxVLEFD::qbevNlqmiHjzo(bool VvNTYgBwR, string bilDyypqxAQgyW, string TxHpefygszx)
{
    string SkRRwFIeVDVpqbb = string("kUMzkbywqAcIbuEpjuBsvnzQJNElVPWAKVtTDUqHqzvOCuAhULJOTArgQYyOeFrWkFcgOInjaqVkIcliBMJUwSqEGgzhWYiDuPsAwajHdiDKeWAITNoNXEtGIQnLMeICgnkvGmZrxurxleqXxFfjOBdzcjcuTrrtnBDukDCchykLnBPwYsyqxVVFxMjPEQehwvFCEOADvslDZWtVenfBVDaswcZubhmPxxt");
    string LPgGcn = string("qZKOOLCCOFxdtoTeHSlcRnjVGmWFUIcbCVfpYXGxOcJsYWUJlMLTUKFDgWLlptqHlTDXHMJr");
    bool XvyulZzRmm = false;

    if (VvNTYgBwR == false) {
        for (int AFZmrHN = 1396228111; AFZmrHN > 0; AFZmrHN--) {
            SkRRwFIeVDVpqbb = bilDyypqxAQgyW;
            bilDyypqxAQgyW = LPgGcn;
            bilDyypqxAQgyW = SkRRwFIeVDVpqbb;
        }
    }

    return LPgGcn;
}

int hxVLEFD::vVrSmPHVvPgMV(int fkFjqY, int DBLPsqfLNi, double PnGhUbinakPLay, int lgHRT)
{
    int FVHxqlqwKgpQPo = 664653556;
    double bkWKOfCnpZj = -420332.9452671168;

    if (DBLPsqfLNi < -1843179197) {
        for (int innAdqXgvjxBo = 1731166371; innAdqXgvjxBo > 0; innAdqXgvjxBo--) {
            PnGhUbinakPLay -= bkWKOfCnpZj;
            FVHxqlqwKgpQPo = DBLPsqfLNi;
            FVHxqlqwKgpQPo = fkFjqY;
            fkFjqY = lgHRT;
        }
    }

    if (fkFjqY == -1843179197) {
        for (int QlEsdinoOUtpWo = 674623590; QlEsdinoOUtpWo > 0; QlEsdinoOUtpWo--) {
            fkFjqY -= lgHRT;
            PnGhUbinakPLay = PnGhUbinakPLay;
            fkFjqY += lgHRT;
            bkWKOfCnpZj -= PnGhUbinakPLay;
        }
    }

    if (FVHxqlqwKgpQPo < 664653556) {
        for (int zvdvmlpPV = 872434836; zvdvmlpPV > 0; zvdvmlpPV--) {
            fkFjqY = DBLPsqfLNi;
            DBLPsqfLNi += FVHxqlqwKgpQPo;
            fkFjqY += FVHxqlqwKgpQPo;
        }
    }

    if (FVHxqlqwKgpQPo <= 664653556) {
        for (int JuhsctklgNQesl = 2014100444; JuhsctklgNQesl > 0; JuhsctklgNQesl--) {
            lgHRT += DBLPsqfLNi;
            lgHRT = lgHRT;
            bkWKOfCnpZj = bkWKOfCnpZj;
            DBLPsqfLNi += DBLPsqfLNi;
            bkWKOfCnpZj -= bkWKOfCnpZj;
            DBLPsqfLNi -= fkFjqY;
        }
    }

    for (int UhpVaIQANdp = 202958096; UhpVaIQANdp > 0; UhpVaIQANdp--) {
        lgHRT -= lgHRT;
        lgHRT += FVHxqlqwKgpQPo;
        FVHxqlqwKgpQPo *= FVHxqlqwKgpQPo;
        DBLPsqfLNi += DBLPsqfLNi;
        lgHRT = lgHRT;
    }

    return FVHxqlqwKgpQPo;
}

double hxVLEFD::HMTJrA()
{
    bool KXeOMHEacyKyl = true;
    bool EFgBBqHji = false;
    int QBppoZTbldKL = -784196484;

    for (int ciEDpLB = 1430495098; ciEDpLB > 0; ciEDpLB--) {
        KXeOMHEacyKyl = KXeOMHEacyKyl;
        QBppoZTbldKL *= QBppoZTbldKL;
        EFgBBqHji = ! KXeOMHEacyKyl;
        QBppoZTbldKL = QBppoZTbldKL;
    }

    return -167941.30268232964;
}

double hxVLEFD::CxcYN(bool bTguRwQtQOtNAfg, int tEvRkdJUkZ, string kyvqFYNIIrvrx, string DoUYcRiYEeDShv)
{
    double IbCUglzckfxqV = -781878.2046612903;
    double qynTz = 1032144.379924049;
    bool OvbGpToTh = true;
    int cljHThSOgRhKIVQT = -704407671;
    int cjsGGuD = 1050513258;
    string VgNgNiE = string("ElbeNNhjjFwohkFnrIQOZhSLoNaTRHkiUMXiSqjwMMRBYFdGdTmlBBWnJRMGjFYOmxALnztKxbXhcyHFXRTKXiwuWSrZKdJHMmLVicchdgoeQDyvzCgGAYEtHISlUEymVOVmMqGOdZNlNnpbjMrRoQyazTTSpevVvhTNTBXGTWsklAutrlgXlzJrSVqrFMqTsySoqhBkKXCtZWRpMBsZMQXXBACbovEvjajpSuXFIXNGczvmmfcAigRS");

    for (int QeRmeMmhJJn = 1284017044; QeRmeMmhJJn > 0; QeRmeMmhJJn--) {
        kyvqFYNIIrvrx = DoUYcRiYEeDShv;
    }

    for (int IzOeleQFqoQ = 811682841; IzOeleQFqoQ > 0; IzOeleQFqoQ--) {
        cjsGGuD /= cljHThSOgRhKIVQT;
    }

    return qynTz;
}

hxVLEFD::hxVLEFD()
{
    this->YtEmg(string("pDXtNUVbBaAqLCpqMVeSh"), 1862367829, -166197.9995973113, -234645.02397448875, 612742.1671517232);
    this->gowWCFIOOefKYqg(791859.3457516608, string("EQgUJozTYcsIssxnVEOaIoEQJYDnNzgMaxjryDgvPCVrdTOTFCmUhUgyqKQaSDDKVCcJHvLmcVnbcIuzGKiYEcSbXlkTAdDmmBazfOqXjKCuyyFuIbNVLshkvtvaGDBHzqIhDAJuasAKAWVLTZXEApIIdPKHhmsVyfEjbuadTEyFV"), 848244.5118322504, -205991.29847903817, string("zjQltOBpDxAvuDkJjeDZXRMVEHVGkwWpxEpvuiHCXrlVUXifYQrnvjBzDxBUSpTimxFhqsRvYolhdyZCQvkCQOEXNKmKSMXfwEzNKDGsBeUZMYEak"));
    this->tUzYjRAKPFq(-222595.83879767542, string("UmBkowuZWUlCemFMEDVHThGosFUPKuRmrcuLNlEPanSryMNtCOtlSEPhkWEDYlcdyXKbJiecHJhhJMzAgXsdbQdznrLbeVFwSNDieEtMPlOAHAVsyndOmpZGWzxOxWmnM"));
    this->OFpsEU(163283724, -418709.66293126764, 773502188, string("ZJJaDsmyFVdPMkaxzpRkznGLrRBTeJPVIrLljGrFJXlOJJkSBVjRXncRunlfOVpwHLhrEosiqqAxpktePIKONkkjhvgUhLrKTFPREUdRnLdwnwYhYZJUhnVxucqYZCdfXRUIFwecSMxKWMnBBMIYSLqhqSCdCYHXHkqCcsnyqESlcZwkUQPxMBIsydSanZVlsyskrBGjdwJDzBZqq"), string("zBdjwoxrQedlmwchElQJmWADhqQQN"));
    this->RmwicOclJkg(true, -412240486, -263145559, -106391.64807244018, 958375.8514091384);
    this->RjuRzMGOZLi(903216.0851667267, string("djZgOaAEkaVFGqhireXpTTdmwkdOSuYdymZDj"));
    this->rCsGlwufJ(string("SdUJPLGFjdYNePnZTzmlNUdpwKepJREaIaIzTfcVmyYuEiPwGXiFNDuxASAGWsMMCvvIDZZnXGlGYNqPclGFffRwEFShTwmSbxptASSxcplcehzvYMwPSCvyCFHbSplBVPwsCKLVmQbbwHxyFQmzPuATUJxKsEhNOocfmeOedVZTfGZXSSSQcqoeyfCrgKUQiQNYKghFQhxGqlfrtFkRmHPQtrXjCQSOdomTuTBgQnr"), string("VrZXXw"), -232888.21872172953, 2093948256);
    this->OrJvbZbSzLoBbxEI(string("PSFYdEMmvXLmLRiEOAzCPrTRpDUobLknSJiKClqNzfOKIYcPas"), -129052.94176978472);
    this->iJbzeZgQnlYNuw();
    this->fPaFkLkPiQjBbS();
    this->thsOwbhh(1076731564);
    this->nSxUTQa(true);
    this->svBXHHqSlRzeuLNS(false, string("CGTDvdolosWtVqfPlLJvWYHtTYomLsBhRwenCwVghOtZxHypHKfXnhsbZVNpUrFJnGirxfcHqyvizOBxbVPbZQIDuaHfwyjsplmGPDOKhmsEzyQKdNpowQzMcqPERMdOXkpXovsJICQLzFOAOhmPlBsSUwkjssLEFZhfUZfLrxXoOpOXUDljbuQiczrwzRlDnOeYxVoLzwViSkyIsxdfZtXmnjaD"), -383017.9420696763, string("eFUAVdQeKgsFbjWbWUzrOqHxZORjWLHPDBLqdlgOCfaoPMPJROmVxeYOYmCBHPOdDDqZKzDnXPLsQRShgPwckSdoWSkkioKYlENRlvqQrUyuDUNtAZMRHR"), false);
    this->kNGZXxhw(false, -396873.9284611188, false);
    this->qbevNlqmiHjzo(false, string("OBqDlwYYsoUPWoUjUQeknPNLgBsjiNtoOOGEtOqnRuvKwNpXxRbmTCZjAUxMRLxQEmwOMYnCbzgQsBzAcIXsifIyesNbESQKYFYgVm"), string("UeVUOXvIfeDoTqnPEHpxFpLNvYcffVTaJHCUypjWrdksEyLqfYVDEKAtWWmxYkNMbNvkKBsZSTKRIQDWcIHoeOpYgZxdjpnouRFTKlEzXohSQsphHAxbxaphelfrEJubNRYtbRlSXHUvFXeqedwDfxQNYBIbbVQSXCupkcVskSovOuYysNbjihFaEGQdxqwuYKFTiAJplKZipkRjydxFOLqksYNihCtTNeCLLCYcnLmumfbqhbklWNRUF"));
    this->vVrSmPHVvPgMV(-1843179197, 420099496, -25485.72278897649, -139651337);
    this->HMTJrA();
    this->CxcYN(false, -1637943743, string("GcTFswRJzuziEgtek"), string("vVgaymvaMwbalCeeixdPHFIJxHibyuOQhycpJjXdqTouEfyViwuGWYEiLzEvLiFiGExhxWNeYdfUclbiituvxXiignEkIZLdzCNOzWguuHcFbogXvAwBTlbbORZJzlRtFhfCQBwOLioNudEYAraeVTHWjFqpKtWPTFRgIbWSXuytdKRMgddoDypkxuXGNZtgDajvCiOOEs"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class INszzzxyAJ
{
public:
    double VUUDBJtMhKyuRXR;
    bool UGHfCX;
    int nVIDNYJVxKOesXk;
    string vckMuAzW;

    INszzzxyAJ();
    void PNkdssMVcXxfPPKY(int rtekUZnkDYRc);
protected:
    double AmYFUOljxXv;
    string ZflPviPk;

    double LREnXDrXIIAu();
private:
    bool EmegSovglzcOvaYj;

    bool OaNidDIZl(int bozTq, int jVFbXAGAC, string KMvWtSoqiJ);
    double hOoogVV(bool HndIQKORBTXX, double FqzKsHbCmOsJlVWS);
    double OYQrPE(int BxWKUEn, int knSOTOBl, double WUnkwaGFCJgKtv);
};

void INszzzxyAJ::PNkdssMVcXxfPPKY(int rtekUZnkDYRc)
{
    double jBsfXmBekL = 224491.57706759847;
    string msykVsCFMXN = string("szVbChwRawSbUGOvOgfGKTgrqxIuoKdTTEueUiItVNRxBcFHekCiGegfsimAgrEGzLvnzEbEfJgAIHxhtMaTbJNDGwlsyuSWbUxzdWlYmfubueFtQ");
    double eoUMSKYjAKDO = -716843.2657729174;
    bool QFSQNhVTu = true;
    double niRhPbDyCrN = -160131.69271123706;
    double LcVvxhWapfyHXR = -485892.3228900391;
    double dalJxMmieAgsSsWl = 158917.72086419296;
    bool vrakwPNlM = false;
    string oNQcaSo = string("sSPklGtBcpoZfLZTtqrqYBZTiuwphRrBEExRRYbIfekF");
    double KgBHRSoiABxnIgj = -91309.05811795776;
}

double INszzzxyAJ::LREnXDrXIIAu()
{
    string TwqqmA = string("zfMgrOeChLxpjVFKeoQtqImMoMTHovGvLXIZvVoqJxcakbWKPYuYuDgxBkuOzeefHgXkxzoKZSocxLGOZRrQcsVZdJunrPGUORXSHnoINawKCjYgiqpjCcCIixkdfkelvXjrWLbIlMsTWtYavWRyxglVhdIITccTAXOTXtmQKDgBeHWscVRtjjISNsXwEHvPZGurFfGkAFYYlqPbhyBksrhCtaDzfZYERtGuUzVNRtJaEgJntJKkhRm");
    string RbLZiS = string("mIxAaXmhByoVWHoXlfHN");
    bool GnCcUVWmenaqJP = false;
    double RRnXZ = 331151.5076625824;

    if (RbLZiS != string("mIxAaXmhByoVWHoXlfHN")) {
        for (int GsqauTHJDg = 862898273; GsqauTHJDg > 0; GsqauTHJDg--) {
            RRnXZ = RRnXZ;
        }
    }

    for (int cmhCyN = 1296474667; cmhCyN > 0; cmhCyN--) {
        GnCcUVWmenaqJP = ! GnCcUVWmenaqJP;
        RbLZiS += RbLZiS;
        TwqqmA += RbLZiS;
        GnCcUVWmenaqJP = GnCcUVWmenaqJP;
    }

    for (int vfPUnxmfwxyXb = 297561109; vfPUnxmfwxyXb > 0; vfPUnxmfwxyXb--) {
        TwqqmA = TwqqmA;
        RbLZiS += TwqqmA;
        TwqqmA += RbLZiS;
    }

    for (int cufvX = 1153876453; cufvX > 0; cufvX--) {
        RbLZiS += RbLZiS;
    }

    if (RRnXZ < 331151.5076625824) {
        for (int BCZOF = 532139571; BCZOF > 0; BCZOF--) {
            continue;
        }
    }

    for (int LIubsMLwzqqaGwKP = 1225073597; LIubsMLwzqqaGwKP > 0; LIubsMLwzqqaGwKP--) {
        RbLZiS += TwqqmA;
        TwqqmA = TwqqmA;
    }

    return RRnXZ;
}

bool INszzzxyAJ::OaNidDIZl(int bozTq, int jVFbXAGAC, string KMvWtSoqiJ)
{
    string mNdlby = string("IIAbsitWJaOZSufkfVkGQJrdcNVJNONNypNaPcgoBZrJShttcyfaUGzXrJsGzsozKpXLkXtbWrslPQGBHHkGKMjqSTqcMuKQVVynmpyOTlhIovFxPYKjXIJXyAitThiGWLPjYUWZbrevlreOHWUy");
    int BDtdjdITEoGV = 742704653;
    bool zSodfASxjbDeLjo = false;
    int svhPu = -312745474;
    double BMmEagCFvcAhqmwR = -31502.30839593063;
    int KyofxmHvTDc = 908622358;
    bool rAwnxMlvWvkBF = true;
    int dHxwvsurrVsHuwWV = -1477935469;
    string AegZpYb = string("wpIRFksNJVqPZRsYOxavqJgpoufmjcQZIavBLWTXtzWdrA");

    for (int IEWDWjbikdt = 1549204003; IEWDWjbikdt > 0; IEWDWjbikdt--) {
        BMmEagCFvcAhqmwR -= BMmEagCFvcAhqmwR;
        svhPu = dHxwvsurrVsHuwWV;
    }

    for (int rUTHPwCmCLAXuvah = 1709056671; rUTHPwCmCLAXuvah > 0; rUTHPwCmCLAXuvah--) {
        mNdlby += mNdlby;
    }

    if (jVFbXAGAC >= -312745474) {
        for (int hMvXo = 831529694; hMvXo > 0; hMvXo--) {
            mNdlby = AegZpYb;
        }
    }

    for (int FmIHJi = 116453595; FmIHJi > 0; FmIHJi--) {
        svhPu = svhPu;
    }

    return rAwnxMlvWvkBF;
}

double INszzzxyAJ::hOoogVV(bool HndIQKORBTXX, double FqzKsHbCmOsJlVWS)
{
    bool ruBwehEWQMD = true;

    if (ruBwehEWQMD == true) {
        for (int iqFSsBDw = 600096402; iqFSsBDw > 0; iqFSsBDw--) {
            HndIQKORBTXX = ! ruBwehEWQMD;
            ruBwehEWQMD = ! HndIQKORBTXX;
            ruBwehEWQMD = ! ruBwehEWQMD;
            ruBwehEWQMD = ! ruBwehEWQMD;
            FqzKsHbCmOsJlVWS += FqzKsHbCmOsJlVWS;
        }
    }

    if (ruBwehEWQMD == true) {
        for (int OGNJKr = 1519526829; OGNJKr > 0; OGNJKr--) {
            FqzKsHbCmOsJlVWS *= FqzKsHbCmOsJlVWS;
            ruBwehEWQMD = ! HndIQKORBTXX;
            ruBwehEWQMD = ! ruBwehEWQMD;
            ruBwehEWQMD = ! HndIQKORBTXX;
            HndIQKORBTXX = ! HndIQKORBTXX;
            HndIQKORBTXX = HndIQKORBTXX;
            HndIQKORBTXX = ! ruBwehEWQMD;
        }
    }

    if (HndIQKORBTXX != true) {
        for (int pWlNnl = 1047326551; pWlNnl > 0; pWlNnl--) {
            HndIQKORBTXX = ! HndIQKORBTXX;
            HndIQKORBTXX = ! HndIQKORBTXX;
        }
    }

    if (ruBwehEWQMD == false) {
        for (int csKdq = 13773353; csKdq > 0; csKdq--) {
            HndIQKORBTXX = ruBwehEWQMD;
        }
    }

    return FqzKsHbCmOsJlVWS;
}

double INszzzxyAJ::OYQrPE(int BxWKUEn, int knSOTOBl, double WUnkwaGFCJgKtv)
{
    double gbkMny = 28665.642283533332;
    double ytViExy = -211746.52548872278;
    bool xJesPLaNddH = true;
    string UlQECebml = string("mPaqAfOLPSHupHxADQxVllnFAMtvcvxjxepzeyYJJSKyTbKTtNbBwgcjmJiyJjHlYtyjUvGSkLDAM");
    bool LZtGxKhsuew = true;
    string GMYUQyZeCOLF = string("mMvhVeAdxtRAGngmMYOdEIEADrjfxdbIZOVTPKdNckhXIDmkJyGdmeVnjPAcKviHWSUAHLgmJCNTYCqbuKpLVQ");
    bool WDMUv = false;

    if (xJesPLaNddH != true) {
        for (int IOUmkQuqKs = 1448980101; IOUmkQuqKs > 0; IOUmkQuqKs--) {
            xJesPLaNddH = LZtGxKhsuew;
        }
    }

    return ytViExy;
}

INszzzxyAJ::INszzzxyAJ()
{
    this->PNkdssMVcXxfPPKY(1878155451);
    this->LREnXDrXIIAu();
    this->OaNidDIZl(338815223, 1594923641, string("ZjqWafpaRToRARgqJcNLisXsWmjRYLAIlxuTxmkqoDSppmzIzZuBUXIIBYPfYWYYjDtbhSNyYzZSxgPiZXgYSGqzlDRCqjKcjoJBeLbNcYmQlEyIILA"));
    this->hOoogVV(false, -861939.6908513621);
    this->OYQrPE(1628425268, -2110380887, -872072.0875909623);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DYqJnFdhqr
{
public:
    string bNGyE;
    string yaqIsM;
    int rFjgi;
    bool nByGoufYYxQ;

    DYqJnFdhqr();
    void iiIAvpNdrWCBaglq(int EoBrN, int lqubuqTFL, double HqVnMufXYNIZj, double MCSmjLYaLyJq);
    bool JiHorGNhakYIwE();
    int aTLtqWWpCK(bool YIxUbcSEOVOZ, bool YVpfo, double FdyDvXzuKWcwJFT);
    double jRIVDUAs();
protected:
    bool jHSajgilIjUUoazV;
    int EKrpiKNkw;

    string GhNbWba(int LlIaqfUSWUw, double tByjKQPNThKteVM);
    double eldPZrHUPXHyOfv(int CsbjaXkKUIqSYzEr, string ReTYanyhC);
    void BxMfzhwETjyjCziE(double zauEqelx);
    int OVIEB();
    double NoMhGiPbbYpKF(int brHDswXpbjhLOA, double KRdESVIPxvyy, int FufficYhkIzLx, string uOiFahQ);
    void pzfSJPJgYpcxKh(string EjyHmxxatlPw, double yLVstDsswvN, int AuSmcn, string xJLirn);
    double JQLujAtShpfSiF(double LFkflYJb, bool dPbuNJSZMSCdTp, double ewSuRrzKbkpykMJg, double rWLUmYxST);
private:
    string dUDOJT;
    bool ehpLZM;

    int cdxJCajDmNdgVRI(double YZelxKxERPA, int OrxSF, string YdVAHbSs, double GOaARRHCEC, string opRuaIKcjLecJIzR);
    double uwnxvBh(string YYLirWjwgSUKeB, double gUKtQFNxewoiR);
    bool KkzRXjlfJNJkWtyp(int RTaiKXATjX, double kZlHbBDKcVCebOWr);
};

void DYqJnFdhqr::iiIAvpNdrWCBaglq(int EoBrN, int lqubuqTFL, double HqVnMufXYNIZj, double MCSmjLYaLyJq)
{
    bool wzrtnqkrZFm = true;
    double dlvJlS = -728213.9903280498;
    int fDGTQl = -2069576942;
    double vopCHdSyIbzOA = 160292.79025063504;
    int LyqiRcraNEgy = -1903080715;
    int dMJIUZJlg = -1652619880;
    string mcFZwBLdpnaNz = string("NEcQoVGoVmmcVZlmEYsKeuQeijgLmawijOKbzwsGWGXZHmaSUBQPzaDjWprpOYyifdwWeaxhVAaliJrTjIHZGmiSSMSuQGKsBGvIsPbyzMSbCgEaSLjqBlxbvxRZCdWo");
    int rRPKYRpjKm = -1268732931;

    if (fDGTQl > -1652619880) {
        for (int NztcMTaOAiUur = 1511513120; NztcMTaOAiUur > 0; NztcMTaOAiUur--) {
            lqubuqTFL /= rRPKYRpjKm;
        }
    }

    for (int TacRoCs = 619866597; TacRoCs > 0; TacRoCs--) {
        LyqiRcraNEgy *= EoBrN;
        EoBrN = LyqiRcraNEgy;
        LyqiRcraNEgy = dMJIUZJlg;
    }
}

bool DYqJnFdhqr::JiHorGNhakYIwE()
{
    double bVqmoJcfgJPZO = 28785.95311205537;
    bool OZmDQAYPCDSy = false;
    string dfDtpdqHQoggshF = string("pePSMcppEyaxvqsPUpGxtEPUjMTRIPfKsFCAJhYRderyflGNRqaZpQWrnTIZEFcnpcWjOiJSlArdeu");
    string QCjkHuNutxajVT = string("GemTFPjSdnhLjWVGBOgZDHFvPVCEKlDnDQwgMlRRVRYgdxfBMceFXtmWFhXDYUgxBHthrFGPbFdAfdiyTZqEiEeaBVawrhXnsIwjnQPopgswWodUpCoemhMUjKnBWWBFWYgoqipOyXHdyYCsxAzdIqtjlKudPpfkUxdwLSBIKzDynusTvHqVNRYKQAgpQuCfxKxzHxgDXEfnJMwCIoEtjQYwiSRNPkhxuaKOAqpRMVF");
    int eDPLZjjmBF = -1317627475;
    double zJNhVyAB = 284473.40404235735;
    bool xjjNZIIHAnKr = false;
    bool HxQZk = true;
    double ZqMCiisa = 185305.302189165;

    for (int DxmyA = 339291394; DxmyA > 0; DxmyA--) {
        dfDtpdqHQoggshF = QCjkHuNutxajVT;
    }

    if (xjjNZIIHAnKr == false) {
        for (int JBqhvwKtlNk = 838270367; JBqhvwKtlNk > 0; JBqhvwKtlNk--) {
            HxQZk = ! xjjNZIIHAnKr;
        }
    }

    return HxQZk;
}

int DYqJnFdhqr::aTLtqWWpCK(bool YIxUbcSEOVOZ, bool YVpfo, double FdyDvXzuKWcwJFT)
{
    int lLSoxwBMdbF = 1249505333;
    string fermCrnPbmi = string("PdtKhLgBMGXKzRdEfADtfdzacrvUBlBIFCkNIFXljpsdyJRkzwSINpcyGfCEGWPZvgUeUkkgVDbCMpNZylQpwfqShGuClxNkCbykTGZnSyCSdUsEUCXeGPBACtPUuDgADrDzADlaklcdcuGflKTLyrnyCaASLLQhFHrWwzwUOVDIKumtKpbyKyOAaa");
    double gJZHKqDQawS = -548530.5016568725;
    double wxAjgU = -387788.03786605777;
    bool HklPtKfXkP = true;
    double ozUxMoaAddCcPae = 931007.6616857579;

    for (int ehwrVvGNR = 1856744108; ehwrVvGNR > 0; ehwrVvGNR--) {
        YVpfo = ! YIxUbcSEOVOZ;
        ozUxMoaAddCcPae -= ozUxMoaAddCcPae;
        gJZHKqDQawS /= FdyDvXzuKWcwJFT;
    }

    if (FdyDvXzuKWcwJFT >= 931007.6616857579) {
        for (int UjScPZBaYWGiWf = 2039738078; UjScPZBaYWGiWf > 0; UjScPZBaYWGiWf--) {
            continue;
        }
    }

    return lLSoxwBMdbF;
}

double DYqJnFdhqr::jRIVDUAs()
{
    double cghNzIzT = -378177.192745019;
    double kQUbqIlD = -1047570.774082375;

    if (cghNzIzT < -1047570.774082375) {
        for (int lXkmfs = 1468134920; lXkmfs > 0; lXkmfs--) {
            cghNzIzT += cghNzIzT;
            cghNzIzT += cghNzIzT;
            kQUbqIlD = cghNzIzT;
            kQUbqIlD += kQUbqIlD;
            cghNzIzT *= kQUbqIlD;
            cghNzIzT += cghNzIzT;
            cghNzIzT = kQUbqIlD;
            kQUbqIlD += kQUbqIlD;
        }
    }

    if (kQUbqIlD != -378177.192745019) {
        for (int ptWepXEPUxOAiklE = 1670449165; ptWepXEPUxOAiklE > 0; ptWepXEPUxOAiklE--) {
            kQUbqIlD /= kQUbqIlD;
            cghNzIzT /= cghNzIzT;
            kQUbqIlD /= cghNzIzT;
            cghNzIzT = cghNzIzT;
            kQUbqIlD -= cghNzIzT;
        }
    }

    if (cghNzIzT == -1047570.774082375) {
        for (int ShhsUCaQwj = 947284582; ShhsUCaQwj > 0; ShhsUCaQwj--) {
            kQUbqIlD -= kQUbqIlD;
            kQUbqIlD *= kQUbqIlD;
            cghNzIzT /= kQUbqIlD;
            cghNzIzT /= kQUbqIlD;
            cghNzIzT = cghNzIzT;
            kQUbqIlD += kQUbqIlD;
            cghNzIzT /= kQUbqIlD;
        }
    }

    return kQUbqIlD;
}

string DYqJnFdhqr::GhNbWba(int LlIaqfUSWUw, double tByjKQPNThKteVM)
{
    int dKggPGUuUhbBNVh = 903594294;
    double xNOqtXducVrKWnFT = 6584.407705590655;
    string kHTGzxpXH = string("NQkWZUUbLfYRcVExwLOGHAZseeSNiPUpiKKXDAswNYUuzjUbUAWMGighrQtFNvPkiFloPvOQGJFQOWQakaftmLfCSzqVyvmthmdNLKKbdHofWNBKHgJvyzGQnyrFbxaiAOxfsMxuxzbVTXjayaJINUkUxNoOJiRBZltLrJehvGGyWQHuLxleEVyQdwfWTQGSuNNxpSZbqB");
    double rujcwyehReVHt = -56887.274397171204;
    int bcCyK = 1670696660;
    int eTgNxulceO = 2099063129;
    double QAZXVoNtqY = -358593.13804160734;
    double CTLoY = 5301.711186986424;

    if (tByjKQPNThKteVM < -56887.274397171204) {
        for (int tnMlidPUrcPbc = 705390906; tnMlidPUrcPbc > 0; tnMlidPUrcPbc--) {
            CTLoY *= CTLoY;
        }
    }

    for (int VCGqmJdxGVqx = 1880557696; VCGqmJdxGVqx > 0; VCGqmJdxGVqx--) {
        xNOqtXducVrKWnFT = CTLoY;
        QAZXVoNtqY = rujcwyehReVHt;
        xNOqtXducVrKWnFT += QAZXVoNtqY;
        tByjKQPNThKteVM -= tByjKQPNThKteVM;
    }

    for (int UhhMixGM = 318629619; UhhMixGM > 0; UhhMixGM--) {
        continue;
    }

    if (tByjKQPNThKteVM < 5301.711186986424) {
        for (int KHKiBIQZWSYpes = 525057630; KHKiBIQZWSYpes > 0; KHKiBIQZWSYpes--) {
            QAZXVoNtqY /= xNOqtXducVrKWnFT;
            tByjKQPNThKteVM = rujcwyehReVHt;
        }
    }

    if (QAZXVoNtqY == 6584.407705590655) {
        for (int zxfikrEs = 1478618881; zxfikrEs > 0; zxfikrEs--) {
            CTLoY = xNOqtXducVrKWnFT;
            LlIaqfUSWUw -= dKggPGUuUhbBNVh;
        }
    }

    for (int TWguMX = 2085476938; TWguMX > 0; TWguMX--) {
        tByjKQPNThKteVM = QAZXVoNtqY;
        dKggPGUuUhbBNVh -= bcCyK;
        bcCyK /= eTgNxulceO;
    }

    return kHTGzxpXH;
}

double DYqJnFdhqr::eldPZrHUPXHyOfv(int CsbjaXkKUIqSYzEr, string ReTYanyhC)
{
    bool BWLolBv = false;
    int fHhIB = 461047025;
    bool hLTyuqpwaypDki = false;
    bool nEMXC = false;
    bool sRgmDOvVmANEWb = true;
    int rXjzdBCbXxDH = -1754427636;
    string DNlfuP = string("lidYEhIvIeFdKnPpjxExaITmtRtdlRkoEKJVQWEdly");
    int vPLNZrTMWhpVP = -1349615344;
    string XlchhWBClgKvg = string("OYPSICZdfreywKFfmkSGRhMrfDnNiOwiGlghPndmsomhyu");

    if (fHhIB != 461047025) {
        for (int CVQrPcjEiF = 1334439474; CVQrPcjEiF > 0; CVQrPcjEiF--) {
            vPLNZrTMWhpVP = rXjzdBCbXxDH;
            nEMXC = ! BWLolBv;
        }
    }

    for (int fYaXCwTZzryFBjI = 1275308024; fYaXCwTZzryFBjI > 0; fYaXCwTZzryFBjI--) {
        sRgmDOvVmANEWb = sRgmDOvVmANEWb;
        nEMXC = ! BWLolBv;
    }

    for (int yrjBPNPfJZ = 1139039559; yrjBPNPfJZ > 0; yrjBPNPfJZ--) {
        XlchhWBClgKvg += ReTYanyhC;
    }

    return -541998.3508662357;
}

void DYqJnFdhqr::BxMfzhwETjyjCziE(double zauEqelx)
{
    int WBOpfgbBVTusjKEW = 2045974957;
    string HyDxqptAdutbjTG = string("bLjpyYShipPtVXIfecGEkpQuRSBzBPORCTUdWNqUVSRwjiSBvVEyftrUxAZCahZXDpQsLFuCAsdslsYDAXwygyHZhxBsmIXY");
    string aEzzjvQYEiqZNw = string("zKlXlfWiimUZenWVVDvffYiKYEnDHauPlRsiWjCrCReCflqViJxFeMdSvTledMzPKzbrIKSFNoGFnZmbjCnXeShiZgrTRbapOzAgyRjvljfnMKGJRcwdFnLUuJLPPosoZACDHzUMioomMGrmVRWmdMLKapMLLgmYwabCWsMICdQfaNSrtYrqPYsJJRMixtFYAjqBcthJzjvFMPVwAhdSeZvuLcTmh");
    int NnvNOTyszjlXl = 11074954;
    double rDfjZyloZ = 949784.6335427421;
    string vWIIddSTSygtmTLc = string("gJeyRPfhonRcbSorBXQyowBqdwLGKfuMhOWrBCtskPtHjZTRcktkfCJxHZzJHSviJHKvYCKnJTjLEgVYXcqmVTgIcTvDewunCfFoigGWBrNwrMIHoyzBVwcmyeITOEsuhGcKKywZWRwMeJqXFWqwXzXTEDzVGRnsivpNcgeXLQZdzqaVLiyRMXclxOxSxyAOcZxZrnFGrfkMzMcNPOwTdEIEKOSrRBP");

    for (int GrEHruClzCR = 811055170; GrEHruClzCR > 0; GrEHruClzCR--) {
        continue;
    }
}

int DYqJnFdhqr::OVIEB()
{
    bool EIiitczOELTJ = true;
    int UTguYwrZcbA = 1171149090;
    string gyBmFjgyeZ = string("uIfYLEximzBtDPwsvWYpNblzdaTQbIGBcDkWKDWFQDHndzjZXFHzycbzVKnuSLIKkOhmItwrRUkzUliiCISWrberNELNxLbQlCTrwJnoAFseABKwYnEEMpyttLmfTjKcUmKsy");
    double xaXbNJZT = -813325.7633181482;
    string rzRCIjDLDyVWsd = string("tKdllzbfMMSesxPqMwbTaVyquenAxzmyObGYiIuUkaKdnDmqRJhxjYLhXsniHUvLrfuShuwzDdvrflXEyIlGgQJBCBCiPQCmaWkUOOPZHWFcnFwQpJXNMWKsv");

    for (int ckShhktVruvP = 1419220122; ckShhktVruvP > 0; ckShhktVruvP--) {
        continue;
    }

    return UTguYwrZcbA;
}

double DYqJnFdhqr::NoMhGiPbbYpKF(int brHDswXpbjhLOA, double KRdESVIPxvyy, int FufficYhkIzLx, string uOiFahQ)
{
    bool jPtjE = false;
    bool KYfkGgvVS = false;
    int ZGPGswiHOopMQx = 25930735;
    bool fnDksnqPuim = false;
    double HgsDydGzyKv = -797569.3074369963;
    bool eoXZZUjxIKkAzUIG = false;
    double UZHuDAi = -328651.8813341673;
    bool CTgUyWu = false;
    string DTUueZToWnzydp = string("sjTTWECvGySxGloKLwpkNFUgJtRaFxnjrYAOIzRhwDTNqxCjFPWodBZEdVQOclyxBjru");

    for (int xzhujrTtgxkzoN = 194757563; xzhujrTtgxkzoN > 0; xzhujrTtgxkzoN--) {
        continue;
    }

    for (int yWxTx = 1824811798; yWxTx > 0; yWxTx--) {
        KRdESVIPxvyy *= KRdESVIPxvyy;
    }

    for (int ONRgknRPFbvbXrA = 1338389160; ONRgknRPFbvbXrA > 0; ONRgknRPFbvbXrA--) {
        jPtjE = KYfkGgvVS;
    }

    return UZHuDAi;
}

void DYqJnFdhqr::pzfSJPJgYpcxKh(string EjyHmxxatlPw, double yLVstDsswvN, int AuSmcn, string xJLirn)
{
    string hdRrGsHxYTaWUJ = string("PzbombvXkZskqihZTKDbdJQhDmXmFyuVDGJCbUqsyohiVMdgzjLahyDPacNkWswHuDEDBtYeCWdRkTEInDSRenSfpaDINPdgDzsOpNXcaglYOBiMLaJNnHBSUN");
    string QKnxsrv = string("ww");
    int LkzagYC = 692284111;
    bool sJxrPMZeO = true;

    if (AuSmcn == 692284111) {
        for (int uuLbSXThhWl = 1862812434; uuLbSXThhWl > 0; uuLbSXThhWl--) {
            QKnxsrv = EjyHmxxatlPw;
        }
    }
}

double DYqJnFdhqr::JQLujAtShpfSiF(double LFkflYJb, bool dPbuNJSZMSCdTp, double ewSuRrzKbkpykMJg, double rWLUmYxST)
{
    int ddnZp = -835520775;
    string qLKChgH = string("mvsbyOHostXVqikQHqCljhzSdkGDCwWccJZcwpDgOYzslRYARoHeektqPWAttSgGoUAoebtbtoCulEnIRjAQAOuTNXKQiVYZAPBNGKSiVamlJqegcBYacOBhmawxrjEsIaoPersqrGdgULtxWggwtGpohusQKgulrwZM");
    double dQcubwRDzsKk = -513818.75459836575;
    int DERFYJM = 1982803557;
    int kGQEWe = 1691625205;
    double OHvgd = -622812.1463389667;

    if (dQcubwRDzsKk > -622812.1463389667) {
        for (int ycaZTlOXk = 2110946065; ycaZTlOXk > 0; ycaZTlOXk--) {
            dQcubwRDzsKk -= rWLUmYxST;
        }
    }

    for (int fdPJcV = 881444965; fdPJcV > 0; fdPJcV--) {
        continue;
    }

    for (int cqimIJslJmr = 982687880; cqimIJslJmr > 0; cqimIJslJmr--) {
        rWLUmYxST -= dQcubwRDzsKk;
        dQcubwRDzsKk /= rWLUmYxST;
    }

    for (int gYKrCJVpQWdG = 440696460; gYKrCJVpQWdG > 0; gYKrCJVpQWdG--) {
        dQcubwRDzsKk *= OHvgd;
    }

    return OHvgd;
}

int DYqJnFdhqr::cdxJCajDmNdgVRI(double YZelxKxERPA, int OrxSF, string YdVAHbSs, double GOaARRHCEC, string opRuaIKcjLecJIzR)
{
    bool PSRAYgViR = true;
    bool mlBzpzrxhrkBsMeT = false;
    bool amxURrkxFX = true;
    string fYllKk = string("OXdCyCGRckXAoxjokBdfNgBXloubpLFDjdeWATYNMSWrBmZnTGQoxCEHRkeIUYZvWqGMCLcnOeAbaUlkmEOEpPSjdYXJBNJmqxsvbmLsUtwBSlipEHqhsYktvEIcHzKCypPYrQMDYnMTdZbtplgrIKGVepVpnzzwpteiCkwcbluJTILZflylzrYCMxRyANKRcxNchwbebImSSNaYcQKuacXFqRmHrJfmRDitUxzkbOBUFZckgOfs");
    int ndzxMg = -783326390;
    int IjdMKsJzoaORwl = 1074814243;
    int MXJrghvFhwbyO = 2128391458;
    int FpVizidYH = 1239834867;
    int caxXWXxMUUZhvGnS = -694309420;

    return caxXWXxMUUZhvGnS;
}

double DYqJnFdhqr::uwnxvBh(string YYLirWjwgSUKeB, double gUKtQFNxewoiR)
{
    double RQyHuzKTOPM = -39722.745835850816;
    string fpxnamKmDQrqd = string("jELDkTRZlhpIBBONnyGmmVYPUFInODvAsRNcgYtzxygXspfCBqNWexjiWTbvYYGdrXYUVSzXKUmccGdzkVqiGXzNCAMypACmGOCNcdwjIgntIJvxfxRavFOIKeETOXmBZEQlXLOrSmiXcYkwjlQexZFcuMxejpnmirvlGBGgIChlAdHuV");
    bool gopTvboLAGEmsuxk = false;
    string xmkjQJ = string("SyncqUDZRGYTBoFFaMiLFqLu");
    double gGfAsBrvSZfAvq = -571184.5614403923;

    for (int XOTsmyyFJJeilE = 385246053; XOTsmyyFJJeilE > 0; XOTsmyyFJJeilE--) {
        xmkjQJ += xmkjQJ;
        xmkjQJ += xmkjQJ;
    }

    if (YYLirWjwgSUKeB != string("SyncqUDZRGYTBoFFaMiLFqLu")) {
        for (int aOhFIS = 1432254314; aOhFIS > 0; aOhFIS--) {
            fpxnamKmDQrqd += xmkjQJ;
            YYLirWjwgSUKeB += xmkjQJ;
            YYLirWjwgSUKeB = xmkjQJ;
        }
    }

    return gGfAsBrvSZfAvq;
}

bool DYqJnFdhqr::KkzRXjlfJNJkWtyp(int RTaiKXATjX, double kZlHbBDKcVCebOWr)
{
    double KDuaetrnsZ = -862729.6804483276;

    for (int XpsRifF = 1422096172; XpsRifF > 0; XpsRifF--) {
        RTaiKXATjX -= RTaiKXATjX;
        RTaiKXATjX += RTaiKXATjX;
        KDuaetrnsZ *= KDuaetrnsZ;
    }

    if (KDuaetrnsZ != -862729.6804483276) {
        for (int yzNqVs = 1709111140; yzNqVs > 0; yzNqVs--) {
            continue;
        }
    }

    if (RTaiKXATjX == -70955286) {
        for (int pAJtcHBAUFevmXKM = 1346736662; pAJtcHBAUFevmXKM > 0; pAJtcHBAUFevmXKM--) {
            kZlHbBDKcVCebOWr += kZlHbBDKcVCebOWr;
            KDuaetrnsZ += kZlHbBDKcVCebOWr;
            kZlHbBDKcVCebOWr *= KDuaetrnsZ;
        }
    }

    if (kZlHbBDKcVCebOWr > -787457.8487060571) {
        for (int AvfwR = 163563119; AvfwR > 0; AvfwR--) {
            kZlHbBDKcVCebOWr /= KDuaetrnsZ;
            KDuaetrnsZ *= kZlHbBDKcVCebOWr;
            KDuaetrnsZ = KDuaetrnsZ;
        }
    }

    if (RTaiKXATjX != -70955286) {
        for (int xjUTwwK = 281512397; xjUTwwK > 0; xjUTwwK--) {
            KDuaetrnsZ = kZlHbBDKcVCebOWr;
            kZlHbBDKcVCebOWr *= KDuaetrnsZ;
        }
    }

    return true;
}

DYqJnFdhqr::DYqJnFdhqr()
{
    this->iiIAvpNdrWCBaglq(1422229076, -774448042, -894634.7958937249, -178702.76388530573);
    this->JiHorGNhakYIwE();
    this->aTLtqWWpCK(true, true, -871648.3029242458);
    this->jRIVDUAs();
    this->GhNbWba(-1625391740, 141070.1824434155);
    this->eldPZrHUPXHyOfv(-949142005, string("vwKqmXifDkTnBeZecTIUPksERtgtHfHUOztQAOHptTBHKLcmNfXGxHGqBLhgcbWAZfykzgFjCinsdkQbvJCDZeecAVPbyEJrwxEnhMlgjIysNgDQShMrHALxpQluQcmdJNMXZpXwwDlMBVNwrCELFZxJzkTrnmUEBc"));
    this->BxMfzhwETjyjCziE(-467826.52929575567);
    this->OVIEB();
    this->NoMhGiPbbYpKF(1167952059, -137682.12697674692, 984305773, string("YXQxlofdtKCjudtMiznhBANhHsXyUbRPFDlPyfYKpJDoAmYFZMJEcBFTlkJWchK"));
    this->pzfSJPJgYpcxKh(string("IlkIksvLMRVhgpxIkFZHgqRWIFPzeLBqqhvsfyBXTZdiicAkOfxzhxBNgrHitASvzZxGXfHkvytbmWVxHPDijJyScoUovghStDchHZEELBUmSijEdnBsvTFAMZeWZVYGJkBUWhazLqhMikQMXwgElJrYozlYTEfOOaZEGEAoRVthxDuWMsLNVdoWUJnJSouzyfWqnBqspEDyjNNwKThukcOayqdHpQamcWJ"), 237432.73650492856, 166032048, string("EFlhNAiXjZLhyYKakaCGYseJyrAZrILlGHeTgxsusaePaaXcbzMJrLWnbZeuzTLZEqbdzuaWUPwuGkMuiasHMdUUXEWEgcegEpVqVouJCGWOhhbWyHWpjuIhYiLQNEFXwzQvcCJvIFZYwIFsSlURQRsHLuHbiYbbhqt"));
    this->JQLujAtShpfSiF(-727018.8254148779, false, -748672.6659601305, 906850.3805351381);
    this->cdxJCajDmNdgVRI(65997.73299670481, 519038627, string("HdohzrBwaMWLgKSSAGweLurZxJVWKQDyRDeZZoqNriSjgHsEfiHMzyVULjfXCBiul"), 980250.8630739196, string("PcKYNEvsiqhKXFeXIWEZaDiqfhIlRyCcUOKyJimFiPxmHyXzeKzBxHjbWvmOCbQOUGbFYecufDRdeVArjAilShyFUYthtANRkKUZShwJjfEOtDOjKBNYXLNpEjBGthBwMWhmZLviQBGdObOfOzJaTui"));
    this->uwnxvBh(string("lQfMVnXpmLfrFOvrfmHloXACHFAOwQSxBZDKFbVjDRopjCtujUfTQLUPDFPrEhogbwdjGjqYQVfppizJTYzaGKCWfatgLRwyZiyyhASmtBylGDeWBUKffjMxLLCNykTIVl"), 749121.5870506596);
    this->KkzRXjlfJNJkWtyp(-70955286, -787457.8487060571);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kghjptFMv
{
public:
    bool LyZSBLDEvhEGpNog;
    int NfAKWYULmM;
    double bNdJn;

    kghjptFMv();
    bool inyWWyUEGAfJrzWb();
    void KWxLLkHTuXXg(int teVnx, bool NlmaWtobOqrSIMQ, double gpeFdjYpgAFeDDmZ);
    bool VOTsziKb(bool xsuOmIMcByIBAIAZ, string DgtoUZJHUbEiLfrA, string QHSIw, string EGFne, int DAVraKnb);
    double ijQwrhrlMpyMKGP(string xReoeryeo);
    bool coLIcZfK(bool ctffG, int kKDkNkDJMZBiTfGw);
protected:
    double SzrPCEvtWJaogvJ;

private:
    string upOiyiT;
    string xturD;
    bool qopWvspOKYBu;
    double uePDhDJkqrCwwN;
    double yBbMe;
    bool rzCPt;

    bool OAhSSwTHj(double GtbcLvOyhPfgHVQJ, int sJUnKNWW, bool QLksKR, int iZRByII);
    bool feIAibqewRmqvNL(string UtUsaSbrnA, bool nxquJJ, int ICJTs, double cYaMWzNth);
    string AhCPOAZXpnSiVwB(double MDhSeNaumnrpt);
    bool ItCcQPConqs();
};

bool kghjptFMv::inyWWyUEGAfJrzWb()
{
    bool TCfbLggAzD = false;
    string uyTsDNBcIGUmyi = string("mEPqgxyXsCKBbYrakMKJbfcIxLjsTyIVF");
    double LCktkjhoOI = -771231.6095405744;
    double ZYJoAmJn = 777712.3388315829;
    string QZOeIJOnjXfV = string("tpmAmlBOkPAcgjWYpPNGIXlAnLixVubWCCXNBiITkVFxFnKUrvYFJwIYbLANpxmglhrQiWLxtxvpjSMJQBSWZxHYwfrnpFVVLdRvfYMSCQpJCtOKzhsPqOVuPrTYJX");
    string VdMonMHmQN = string("xKjQPYINUQTaiyRIXOFbIkuLoUjgbzhjmBgOFYrQJAzdjmNRUO");
    bool YMhPbu = true;

    if (ZYJoAmJn > -771231.6095405744) {
        for (int cTiDA = 1375995056; cTiDA > 0; cTiDA--) {
            YMhPbu = ! YMhPbu;
        }
    }

    return YMhPbu;
}

void kghjptFMv::KWxLLkHTuXXg(int teVnx, bool NlmaWtobOqrSIMQ, double gpeFdjYpgAFeDDmZ)
{
    string NWHjhqZkMSrr = string("thDKjOskDsljCAkDFFdfoBVjtbNUGIWfzOQmMyQxaPUQyQqmCuFpx");

    for (int lRHnnSMHuLMb = 1252003530; lRHnnSMHuLMb > 0; lRHnnSMHuLMb--) {
        continue;
    }

    for (int fBKRoQMCuNwk = 1093346814; fBKRoQMCuNwk > 0; fBKRoQMCuNwk--) {
        NlmaWtobOqrSIMQ = NlmaWtobOqrSIMQ;
        gpeFdjYpgAFeDDmZ = gpeFdjYpgAFeDDmZ;
    }
}

bool kghjptFMv::VOTsziKb(bool xsuOmIMcByIBAIAZ, string DgtoUZJHUbEiLfrA, string QHSIw, string EGFne, int DAVraKnb)
{
    int cirnQfmA = 1374014724;
    double FFfrJzADXFNmaE = 705943.2787703081;
    double dDnPL = 156854.31507419498;
    int QWimzmqktPo = -738060426;
    double gsLeusakdQTDctSs = 823708.3499121699;

    return xsuOmIMcByIBAIAZ;
}

double kghjptFMv::ijQwrhrlMpyMKGP(string xReoeryeo)
{
    bool loeaHlGmsnvquW = false;
    double qhfNtixZQSe = -68020.86787776745;
    int yHdzkLpLLIpkKPaE = -1361764684;
    bool nWzAGiab = false;
    int GXACL = 157947922;
    int aDqKSIbdDqO = -632208072;
    bool cHIphDJaAgcwj = false;

    for (int ZXvUqDT = 1275721162; ZXvUqDT > 0; ZXvUqDT--) {
        aDqKSIbdDqO += aDqKSIbdDqO;
        loeaHlGmsnvquW = cHIphDJaAgcwj;
    }

    for (int SWDqvrjXH = 139644009; SWDqvrjXH > 0; SWDqvrjXH--) {
        yHdzkLpLLIpkKPaE = yHdzkLpLLIpkKPaE;
        cHIphDJaAgcwj = loeaHlGmsnvquW;
        aDqKSIbdDqO = GXACL;
    }

    for (int FAQBjWBxcOGDm = 678574221; FAQBjWBxcOGDm > 0; FAQBjWBxcOGDm--) {
        aDqKSIbdDqO *= GXACL;
        loeaHlGmsnvquW = ! nWzAGiab;
        cHIphDJaAgcwj = ! cHIphDJaAgcwj;
    }

    return qhfNtixZQSe;
}

bool kghjptFMv::coLIcZfK(bool ctffG, int kKDkNkDJMZBiTfGw)
{
    string MqFJQOUZT = string("teSpZihyOMUlHGetsRKxAYCJkvbOvwmqxYcAtLqNloBnNzvoTHRcbybPnTLfDlyGNQoKndrFqTtDxXvzOkAauWsuvLN");
    bool fHLbmII = true;
    bool CCoswHNItr = true;
    bool bZZTCiGiH = true;

    for (int tCxPpUbiZVOO = 1137760455; tCxPpUbiZVOO > 0; tCxPpUbiZVOO--) {
        bZZTCiGiH = ! bZZTCiGiH;
        fHLbmII = fHLbmII;
    }

    return bZZTCiGiH;
}

bool kghjptFMv::OAhSSwTHj(double GtbcLvOyhPfgHVQJ, int sJUnKNWW, bool QLksKR, int iZRByII)
{
    int baCOHqz = -221940435;
    double OcUDaM = -562836.8100796577;

    if (OcUDaM > 590594.0427806814) {
        for (int PkzLY = 977339326; PkzLY > 0; PkzLY--) {
            iZRByII += baCOHqz;
        }
    }

    for (int opswDG = 1973628068; opswDG > 0; opswDG--) {
        sJUnKNWW += baCOHqz;
        baCOHqz = iZRByII;
    }

    if (OcUDaM <= 590594.0427806814) {
        for (int DyNfqtLhWx = 827263354; DyNfqtLhWx > 0; DyNfqtLhWx--) {
            QLksKR = QLksKR;
        }
    }

    for (int CKyKvwbBg = 925359789; CKyKvwbBg > 0; CKyKvwbBg--) {
        baCOHqz = iZRByII;
        baCOHqz -= iZRByII;
        iZRByII = baCOHqz;
        OcUDaM = GtbcLvOyhPfgHVQJ;
    }

    if (sJUnKNWW >= -1244288220) {
        for (int QexVQhNwG = 1627483842; QexVQhNwG > 0; QexVQhNwG--) {
            QLksKR = ! QLksKR;
            GtbcLvOyhPfgHVQJ += GtbcLvOyhPfgHVQJ;
            sJUnKNWW *= iZRByII;
            iZRByII /= iZRByII;
            GtbcLvOyhPfgHVQJ -= GtbcLvOyhPfgHVQJ;
        }
    }

    return QLksKR;
}

bool kghjptFMv::feIAibqewRmqvNL(string UtUsaSbrnA, bool nxquJJ, int ICJTs, double cYaMWzNth)
{
    bool hNeqMDhU = false;
    bool tknPv = false;
    double cDODGPilLSO = -818865.1531549047;
    double NWNuZlyIFNJH = 862917.2165344465;
    bool ILeNQXmgFgw = false;
    bool DRzlpNVyw = true;
    string EjCzNge = string("ISau");

    for (int OqxgQnk = 101797937; OqxgQnk > 0; OqxgQnk--) {
        continue;
    }

    for (int ldzKlpm = 162966663; ldzKlpm > 0; ldzKlpm--) {
        ILeNQXmgFgw = ! nxquJJ;
    }

    if (EjCzNge > string("OBIoCxVEyrSlKMeIexVTnFGmgZYBSsqRxcYHMPaNGoMwNXGUdlqSVwDokNVahJGTWJsOmAbVVLPOMcsKNmKaJCUiIEWNTARqkFTHqBrCmcLhBmIVspZwoyhsOHoapUIxdgUeYdIKQTDKRIUlysXdCfxnAbxoQaRuakEGkeCravBQvAwUlWrMkMknIsOKQpTI")) {
        for (int EdzlerPFLnu = 1956818717; EdzlerPFLnu > 0; EdzlerPFLnu--) {
            continue;
        }
    }

    return DRzlpNVyw;
}

string kghjptFMv::AhCPOAZXpnSiVwB(double MDhSeNaumnrpt)
{
    double ZLLetWAN = 739377.1501647163;
    bool bhtwafmJ = false;

    if (MDhSeNaumnrpt <= 739377.1501647163) {
        for (int ycbXOW = 448715308; ycbXOW > 0; ycbXOW--) {
            ZLLetWAN += MDhSeNaumnrpt;
            ZLLetWAN = ZLLetWAN;
        }
    }

    for (int ghLALUNFtApueum = 286292596; ghLALUNFtApueum > 0; ghLALUNFtApueum--) {
        ZLLetWAN -= MDhSeNaumnrpt;
        MDhSeNaumnrpt -= MDhSeNaumnrpt;
    }

    if (ZLLetWAN <= -475335.2301320625) {
        for (int PVfHGMaZdutaWFW = 1395894048; PVfHGMaZdutaWFW > 0; PVfHGMaZdutaWFW--) {
            ZLLetWAN /= MDhSeNaumnrpt;
            ZLLetWAN = MDhSeNaumnrpt;
            MDhSeNaumnrpt = ZLLetWAN;
            MDhSeNaumnrpt -= ZLLetWAN;
            bhtwafmJ = bhtwafmJ;
        }
    }

    for (int euIFGw = 2127234066; euIFGw > 0; euIFGw--) {
        MDhSeNaumnrpt *= ZLLetWAN;
        bhtwafmJ = bhtwafmJ;
    }

    if (MDhSeNaumnrpt > 739377.1501647163) {
        for (int yOfskdKjqa = 985999472; yOfskdKjqa > 0; yOfskdKjqa--) {
            ZLLetWAN /= ZLLetWAN;
            bhtwafmJ = ! bhtwafmJ;
            MDhSeNaumnrpt *= ZLLetWAN;
            MDhSeNaumnrpt = ZLLetWAN;
            MDhSeNaumnrpt *= MDhSeNaumnrpt;
            ZLLetWAN = MDhSeNaumnrpt;
            bhtwafmJ = bhtwafmJ;
        }
    }

    for (int mrmoIlc = 371349510; mrmoIlc > 0; mrmoIlc--) {
        MDhSeNaumnrpt = ZLLetWAN;
        bhtwafmJ = bhtwafmJ;
        ZLLetWAN += MDhSeNaumnrpt;
    }

    return string("vNokCgsTeqdZAkLKcosnxoepRwnGEXEtHMISJAlKJMadLLgHHYqpsXntVXQnsJHBzqeqSaYpXSJMtrNRvWIRhIwZYJTiCjqyhCjToCNgOYxGNKLjVIHjnMrWjaXnugBiWCfYESOlcwJJBHIUjhRsxHpJMDMxjHWLztvyqUHbFMoQzRYTXqDVJNGcJPiHzJYDnPkmIEARztLrHe");
}

bool kghjptFMv::ItCcQPConqs()
{
    double YdhZS = 142383.20337339563;
    double bBPHcraQpMDE = 397663.3851211095;
    bool dkToFoLXm = false;
    int aSPbgbBYGC = 2036220117;
    double DKkDn = -749873.3874767757;
    bool XplVrhiuoZrQRQ = true;
    bool wiyHbrERh = false;
    string kyNEZso = string("cjtcyjNknapcIcvukPRrycRaQKIxRAkChGeFWEnedieKlWuukTUYthdnbDvGEywHziAuplvCgdrudtJSYyPGMcVtwnPoXbvMreLTvYIBOmEDotvtjuhXPYokmHgeBiWcdXJIoYxIFYcjoTjZcvXXeuQnQIvHlFwwZoPDDjCnOunTQIVB");

    for (int EWGqVJlMQRIthFTF = 1937333007; EWGqVJlMQRIthFTF > 0; EWGqVJlMQRIthFTF--) {
        continue;
    }

    if (YdhZS >= -749873.3874767757) {
        for (int wKKGmiX = 946549754; wKKGmiX > 0; wKKGmiX--) {
            bBPHcraQpMDE /= YdhZS;
            YdhZS += DKkDn;
        }
    }

    return wiyHbrERh;
}

kghjptFMv::kghjptFMv()
{
    this->inyWWyUEGAfJrzWb();
    this->KWxLLkHTuXXg(686367996, true, 322828.8740904113);
    this->VOTsziKb(true, string("aStmisVIaUKOsnKAHdxynTzgnAyQbPtblFftYaIccAztjzseXJHzruJxoePRMYEetormcjuBRcNdFGwTTivFtOPrAJqvZOFPfLkECwunNhwOeQzHaLwHJNaCYMRMQkDnIsknPDECsebxyfAIfGHfFSexNkdromqtvgUGTAIBtjTPWnHwyWnnNCzERj"), string("IoYAJnVKsjdCiwkHIKsRdTzRxhTQOlykURQXjseWMmNcHozlLgycpXbnewQOoYWHFSIsrsXwThlUrkdzSYdKwYviOmHM"), string("LBlzOINMeLGtYASfRjOYKboWfVeSBoDRBqRYnqqXwnwmwNigSguEUkiEUafDCyQYRWcoaXCnAJQhcmRpms"), 1036760399);
    this->ijQwrhrlMpyMKGP(string("EslYaKfpuTCLRFGazZlGlokSAjlCOOcqePHRuBpgmJnZJUMpxIMDTjLIGPseKBPRzgVQpJKHlsAXwwCVszAqlFsUbZCIJZeBbkwXJCuAlkgxXjgxUOSWzJzMnecRWvMlPhtwAwtvBudkKAunQpWfaMTMmeoQClsfn"));
    this->coLIcZfK(false, 124467647);
    this->OAhSSwTHj(590594.0427806814, -1244288220, false, -1987790572);
    this->feIAibqewRmqvNL(string("OBIoCxVEyrSlKMeIexVTnFGmgZYBSsqRxcYHMPaNGoMwNXGUdlqSVwDokNVahJGTWJsOmAbVVLPOMcsKNmKaJCUiIEWNTARqkFTHqBrCmcLhBmIVspZwoyhsOHoapUIxdgUeYdIKQTDKRIUlysXdCfxnAbxoQaRuakEGkeCravBQvAwUlWrMkMknIsOKQpTI"), false, -2085270765, 514340.90656046174);
    this->AhCPOAZXpnSiVwB(-475335.2301320625);
    this->ItCcQPConqs();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xXmcpRX
{
public:
    double OInpmwPiqAAoHuc;
    int psabKcjcSUh;
    string nBxxv;

    xXmcpRX();
    int fzAgMmoQ(double nyULtnVs, double MUUcBYVqDmk);
    int RGcgXg(int OnoLKYTXUkXSL, string BWhKqG, int HQtKcmUIunNmbhlc, string DgnLBMqsbppcF, bool QlBTTKdxDR);
    double TONfdYjji(string lRucOZ, string cNshHDWiUi, int lPcHYBQaUMFWGYRc, bool YMSNItBKGJtYsmQv);
    int mAgxXIlcwLmsBl(string CLEPUYPR, int AuMWsMItCcVPKahn, string xiMYcIFTftADvT, bool BZZWBBZ, bool tsUPNFC);
    void gwGqCSJUFaHmGt();
protected:
    string PoLNwNW;

    bool xIjEvWIAg(int wkQNWo, int WYshPC);
    double RkXMJSDCKVBtUy(bool onDMZKfEAVjH, string BBLSmCfJvqBlO);
    double xdVByJVcCzrrUaQ(string HYfKE, string QGegjhZISssZ);
    int zCDkcRTWWe(string NebQHpltf);
private:
    string UGkFbGU;
    int ZhwGiJH;

    string EZYvaSzKPEki();
    bool KFvuJr(int heBHlNVoCYUZSYmC, int xgQYVkRrCJjSQRg, int rABFjyUNFpJ, double bxmVhrEmMCf, int YAzvEFriiVHCz);
    double Aqmorj(bool QYnzvPkxJsPCv);
    bool fCqCVwGXICy(double CVFhzlzZyhqzV, bool NvloSjMfvUc, bool IMCihtDIMvtHRmX, int kCbscxnMi);
    string TtpHDDEMwFpX();
    double dZgLtapSe(double MlDCrHtz);
};

int xXmcpRX::fzAgMmoQ(double nyULtnVs, double MUUcBYVqDmk)
{
    string ZagqkQGRiweb = string("JPncDBpCnDWcHUctqjlLKsWDhWFDWutcqblnErmsgBxJNrDocuuFOUHV");
    int oCofKaYOakj = -1607833089;
    string vDzdhjItFE = string("RCodkwPOdxhmuIRFjebxIJWRBniTqFWIOIBFSeVQIXJippHPvLseFjuPVMswruvtoR");
    int BhwIKXZW = -942793251;
    bool qxnQlnpphdspSq = false;
    string lEjcUX = string("EQTKtZMpttFArVQtGgVBNyFHtWARdZQDQYGouokiJXhOpPYECZYMgvjsdweJcMeXfXOPOBUvOJrijUMlcSsLeDnqFgOvOlmgeBvPtWhzlFItkNvZEWmNoahEqqXJHMDdyMninKOLWUrnZGcUTFVJEcisoWiOHilVtdOPFRTZqbffKaeShdbypJRHjgcwx");
    string VcaXitqXbd = string("BlEygnubcorLSRALvkQQlDfBgICFqSiNtEOkkxodsLwBLNwxDNXALHAWejieoOcnUIbmXuWFVKEYqWdsYLQIypDLiQlOnrmihSslOZOqOtOkoGGjSPNxKCKPzSafvawCfAFrczyceorTv");
    int FVrcFu = 1205027893;

    for (int YVCyoMX = 2142901734; YVCyoMX > 0; YVCyoMX--) {
        VcaXitqXbd += vDzdhjItFE;
        VcaXitqXbd += lEjcUX;
        VcaXitqXbd += ZagqkQGRiweb;
    }

    for (int HXxwfEZpIvfWLZ = 1832220829; HXxwfEZpIvfWLZ > 0; HXxwfEZpIvfWLZ--) {
        MUUcBYVqDmk -= MUUcBYVqDmk;
        VcaXitqXbd += vDzdhjItFE;
        vDzdhjItFE = vDzdhjItFE;
    }

    return FVrcFu;
}

int xXmcpRX::RGcgXg(int OnoLKYTXUkXSL, string BWhKqG, int HQtKcmUIunNmbhlc, string DgnLBMqsbppcF, bool QlBTTKdxDR)
{
    double PqRxCCcvjIEtjqu = 415351.84009353374;
    double JOgBD = -455433.71618555265;
    string THwGY = string("TsKtPPQvZMqYLLQudmyVLjFUqorsouRTYNeiJjxwOffsyqKoEOaiwiIgFBpnsnBjAbCOUvL");
    int ScfigANLurriO = -208196478;
    string kbghmAVW = string("LWnvZwnqWwLLxbYdIluvHyMBTneHCQKrkTwySjVPxRRKEvMzajpEBuWbsriAraHoAbfrxSFDJNBeZPXgoqauHejTwVfFdvjvlNqwlDcrAgHCQIcJhdSpqTFOebboBvfRyurdiZUXnRyWlABUwWitxHgHwbuRSAYqCAExMveTGACmTOYTfUATfiiLLksVKDhXqjFpbzgoZhnYwUFGJJBLjtcgiIaJXpUvutHeLQNQfTpeVNov");
    double QxXIGqixlaWgs = -416541.8209902705;
    string oHppburfngCkaStY = string("RjyjmvBEwBQTDFtMsMOYNjSxqGcOfKlVRhkdOhedYzBrBeVYwTeTVTbqKTAafCfnwavKoIDMN");

    for (int HXvJPyzu = 43471164; HXvJPyzu > 0; HXvJPyzu--) {
        PqRxCCcvjIEtjqu /= PqRxCCcvjIEtjqu;
        PqRxCCcvjIEtjqu /= JOgBD;
        HQtKcmUIunNmbhlc -= HQtKcmUIunNmbhlc;
        PqRxCCcvjIEtjqu *= QxXIGqixlaWgs;
    }

    for (int rlUEJPcZhNO = 823407636; rlUEJPcZhNO > 0; rlUEJPcZhNO--) {
        kbghmAVW = oHppburfngCkaStY;
        kbghmAVW = BWhKqG;
    }

    for (int kTSOQF = 1537725437; kTSOQF > 0; kTSOQF--) {
        continue;
    }

    for (int KypBNkrlB = 2086108766; KypBNkrlB > 0; KypBNkrlB--) {
        kbghmAVW += DgnLBMqsbppcF;
    }

    if (PqRxCCcvjIEtjqu == 415351.84009353374) {
        for (int YYISy = 1554020798; YYISy > 0; YYISy--) {
            DgnLBMqsbppcF += BWhKqG;
            oHppburfngCkaStY = THwGY;
            PqRxCCcvjIEtjqu += JOgBD;
            JOgBD /= QxXIGqixlaWgs;
        }
    }

    for (int ZGyhiQVu = 78282092; ZGyhiQVu > 0; ZGyhiQVu--) {
        kbghmAVW = BWhKqG;
    }

    return ScfigANLurriO;
}

double xXmcpRX::TONfdYjji(string lRucOZ, string cNshHDWiUi, int lPcHYBQaUMFWGYRc, bool YMSNItBKGJtYsmQv)
{
    int HZmSjmkjZg = 104400299;
    string IxfLQlAOgjxErRg = string("BPtLgoWeDiNHsXkepYwoCAYLZHyVJSFVzngtWyNphIHaVkbBbYdLxjihsFTkFKYppaOWEAzhNbYweaBziExNCAlZszwaXpJclUffxUMTwMZmbOTLVvgWcBxVkLhbiqxbfstcwCMfVmJNOSiVhfuAvSgojyjZXBFGJOpJgjYVrxtWWdUTdd");
    bool dJjjfGfQmH = true;
    string JWqOdsiFgLu = string("wiWKcxdFnYQXpSXszTqpTCkEGIi");
    string dsigU = string("uGiPdUvQIBwjGwaOQygsATRtjAFJeDXDNYPlaeorrwVbWnnSbJNmdFDWqeKvdIotXggPBXVmMczlAupuesGUrswQoGFxYlxUVGskvFCKoPOPDdAfhPvcCRZMRLNNjnSDrVqaDJHTyOibVQMWUSqlLeOkhdRGqRFgCFzlknjDMliIaWqmAPpFPHhRhleyoubXOtNEuRpHcVOcBgnaUIRnUQU");
    string DTaiGlSYWMZRrbk = string("QuKxuAfscbxeXHNkbYWujyfIkVaMCeNAJLyjTEBhgWQNlfjOjSeWiZJNcDOEtghZiTGqyGAWwXpVuhHaqEiZgeQpSSqvPcT");

    if (cNshHDWiUi < string("wiWKcxdFnYQXpSXszTqpTCkEGIi")) {
        for (int lCjFwTyftkqRhIj = 98004672; lCjFwTyftkqRhIj > 0; lCjFwTyftkqRhIj--) {
            dsigU += lRucOZ;
            JWqOdsiFgLu += DTaiGlSYWMZRrbk;
            DTaiGlSYWMZRrbk += IxfLQlAOgjxErRg;
            lRucOZ = dsigU;
            dsigU = DTaiGlSYWMZRrbk;
        }
    }

    for (int VkHVXWtFRtJ = 759547369; VkHVXWtFRtJ > 0; VkHVXWtFRtJ--) {
        dsigU += DTaiGlSYWMZRrbk;
        lRucOZ = dsigU;
    }

    if (dsigU == string("ZznoKVgZWJvsosOPHFxsATjPaTddaPcozoFMcBerJXpkcndCeTWvIQtHwMprkihBNAGEamzdNOKmdGQVENeWbBxXWEgiwFkcoDBXCIpYeGkdyhFwTdZVyJPEIddoziiLkMafBRfhlszWSpNDVPsZPxyLSjecHDUqmUkTzmBmYmGfujqmnZqAAeLjbigNGuJXbxlNJHfBZcQEadpWoMSymmyrhSXnvzNbMaOANcF")) {
        for (int wCiJZeWZPsNerw = 417132136; wCiJZeWZPsNerw > 0; wCiJZeWZPsNerw--) {
            dsigU += cNshHDWiUi;
            lRucOZ += dsigU;
            DTaiGlSYWMZRrbk = lRucOZ;
        }
    }

    if (YMSNItBKGJtYsmQv != true) {
        for (int bjaxpqiUGYeJ = 2097149582; bjaxpqiUGYeJ > 0; bjaxpqiUGYeJ--) {
            lRucOZ += lRucOZ;
            HZmSjmkjZg /= lPcHYBQaUMFWGYRc;
            JWqOdsiFgLu += JWqOdsiFgLu;
        }
    }

    for (int ncbnysPz = 1546103306; ncbnysPz > 0; ncbnysPz--) {
        YMSNItBKGJtYsmQv = ! YMSNItBKGJtYsmQv;
        cNshHDWiUi += IxfLQlAOgjxErRg;
        lPcHYBQaUMFWGYRc += lPcHYBQaUMFWGYRc;
        dsigU += IxfLQlAOgjxErRg;
        JWqOdsiFgLu = dsigU;
    }

    return 53584.197859450614;
}

int xXmcpRX::mAgxXIlcwLmsBl(string CLEPUYPR, int AuMWsMItCcVPKahn, string xiMYcIFTftADvT, bool BZZWBBZ, bool tsUPNFC)
{
    string ejNXUqXoTMF = string("NFJOiglUMKBTXCMGOtgeYyTNYmCtrJKtmjqIruCFLWYUynaFQwIbgbtoQnHRUxfmcyvbYSZwBwyULjYWaMyPmRKKHgYtOZrbhZGKODUehmmomcNAxeiOnzUBSEySw");
    string XgcelTPAgnC = string("OQcsSVRlniSLUrxyZIeXByLOaEcJesZxQnxyRcDDIUsHKckkhqrCQeaNEnkCiMlhPawrTTVYkeEGkgIMbevUibEuVdSIRLWgDFeDJ");
    int whbLSuxfWK = -1978698568;
    double FyfTPbYRKpGUjHIj = -462268.3503753423;

    return whbLSuxfWK;
}

void xXmcpRX::gwGqCSJUFaHmGt()
{
    string YcCKh = string("eIrhaAKoRpGmsPSKSiThexoFavdLOlwkmEBFhcGEfVwiLasCoNavgprlKlsUsSZZwqZYnQVuPFtRLRtaosPXiEAgKVMLZMiHZwbiHGSAJWtcssQiZhMjvcxwxQMfMJVhDAnDscsBbCPqTMBArFClUuLmuMsykGwTzxbRdAoilNXrkbqvEfdXzVJGfAAbHDJQCtYOvZVJeXZDn");
    double XLUJeYHREC = -480845.7960375192;
    int EIPCZuLsdEzmILh = -1752481316;
    bool zBCqBWxseTIQ = true;
    int PKVjiwrdteQP = 1892999312;

    if (zBCqBWxseTIQ == true) {
        for (int NEwNhNVuOknatQZI = 2115606016; NEwNhNVuOknatQZI > 0; NEwNhNVuOknatQZI--) {
            PKVjiwrdteQP *= EIPCZuLsdEzmILh;
        }
    }

    for (int PkbSTEAWvCm = 1887666311; PkbSTEAWvCm > 0; PkbSTEAWvCm--) {
        zBCqBWxseTIQ = zBCqBWxseTIQ;
        PKVjiwrdteQP /= PKVjiwrdteQP;
        PKVjiwrdteQP /= PKVjiwrdteQP;
    }

    for (int BMhkEfXem = 1270292365; BMhkEfXem > 0; BMhkEfXem--) {
        continue;
    }

    for (int VVIquENd = 394886056; VVIquENd > 0; VVIquENd--) {
        PKVjiwrdteQP += EIPCZuLsdEzmILh;
        zBCqBWxseTIQ = zBCqBWxseTIQ;
        XLUJeYHREC += XLUJeYHREC;
        PKVjiwrdteQP = PKVjiwrdteQP;
        YcCKh += YcCKh;
    }

    for (int RsDwBfayzaSqN = 1334130278; RsDwBfayzaSqN > 0; RsDwBfayzaSqN--) {
        continue;
    }
}

bool xXmcpRX::xIjEvWIAg(int wkQNWo, int WYshPC)
{
    double iGoUIGMcKYnlzn = -868020.3683115081;
    double lbaokm = 697444.3216735306;
    int gJWUXmgcZ = -1613354617;
    int tHyqWjZPdoRFA = -1057419173;
    string zJJVhhnzCfR = string("ffpZEIHDROadQpzFMPXwAskpryQzBwZ");
    bool DtnqyFtDqRJcSm = false;
    double WEkWbbO = 640511.6932276933;
    double bUaePOxyEPUZnecj = -287991.2800684874;

    for (int YkcUfOhHEPk = 1255013347; YkcUfOhHEPk > 0; YkcUfOhHEPk--) {
        continue;
    }

    for (int MlCqrh = 688982786; MlCqrh > 0; MlCqrh--) {
        continue;
    }

    for (int hmYRiiTPRWSjLTLG = 1560975717; hmYRiiTPRWSjLTLG > 0; hmYRiiTPRWSjLTLG--) {
        bUaePOxyEPUZnecj = bUaePOxyEPUZnecj;
    }

    if (gJWUXmgcZ == 1133662716) {
        for (int cALazLQQeWQfJnnX = 528698740; cALazLQQeWQfJnnX > 0; cALazLQQeWQfJnnX--) {
            wkQNWo *= gJWUXmgcZ;
        }
    }

    return DtnqyFtDqRJcSm;
}

double xXmcpRX::RkXMJSDCKVBtUy(bool onDMZKfEAVjH, string BBLSmCfJvqBlO)
{
    string NLwmCnWSDIYesqM = string("KPhluctOjVrjlHNYPVwjSkQwCknxqyKyvlPrxmomxNesFdXYLvIpEqyMkXUjp");
    double cfqDutcYRAmBFpC = -169891.11392087722;
    int hdzCqcx = -1806725897;
    int aaYZWT = -130264556;
    int mVUsmhjLFxWDvZco = 304561070;
    double CfyENmpbHlu = -507128.37947440083;
    int BwmDkDOZLeqJ = -779236916;
    bool lrOSiW = true;
    string pVnnHLpW = string("XBlNytiPPBMpzKGdVcUbRNKyVyhemXhatxDvigXPegajdpQaOREtrFDfcpwNidrSsDsFrGZUcAqASMdJGGCwaOSsUTSzQDrTERFmORGNpMGevaKiQEMuMHDOtIoclRzQRQMtqyGLpHOdxJMBSRURbAiAUqbgUyCYvMQGveQwSxUgozCuUEljzTqhGgH");
    string RQGIOdUWrUd = string("wboFztGwfOcCUQUoMNMfFjhlLVYeaPWSoQErTouvvNfdgIweRLCACQPsnOWMqycaYMHWlufGXSsgIiClDrWVqCbIsPfvMZbAssOQOFnPVqXNRVZZTrtuhawSzPPkIrkAaTrqeBlnIqLePkhPBMANFXwhEWQPJKQgWFatrYhLTmzrjkxJcsgcbLbeDFpxxixsrJZDDXHJrGAexMzPBMafSiTQRSPUgaocPUZoodrM");

    for (int RkIxerYsaBOmIA = 806382883; RkIxerYsaBOmIA > 0; RkIxerYsaBOmIA--) {
        continue;
    }

    for (int iiPWKyDuTdDLwFSG = 644651892; iiPWKyDuTdDLwFSG > 0; iiPWKyDuTdDLwFSG--) {
        continue;
    }

    if (aaYZWT == 304561070) {
        for (int WsKikAdH = 1016522662; WsKikAdH > 0; WsKikAdH--) {
            hdzCqcx -= mVUsmhjLFxWDvZco;
        }
    }

    for (int UPXnhP = 2014013081; UPXnhP > 0; UPXnhP--) {
        continue;
    }

    if (aaYZWT < -1806725897) {
        for (int xNeBRA = 534649881; xNeBRA > 0; xNeBRA--) {
            pVnnHLpW = BBLSmCfJvqBlO;
            BBLSmCfJvqBlO = pVnnHLpW;
        }
    }

    for (int mGpbGleZL = 858673689; mGpbGleZL > 0; mGpbGleZL--) {
        CfyENmpbHlu = cfqDutcYRAmBFpC;
        onDMZKfEAVjH = lrOSiW;
    }

    return CfyENmpbHlu;
}

double xXmcpRX::xdVByJVcCzrrUaQ(string HYfKE, string QGegjhZISssZ)
{
    double MWSfjbeFsg = 567488.8538075213;
    double WvqIlt = 566566.5382175518;
    int bGnjPOr = 2040167907;

    for (int ufQcR = 1230351035; ufQcR > 0; ufQcR--) {
        bGnjPOr *= bGnjPOr;
        MWSfjbeFsg -= MWSfjbeFsg;
        QGegjhZISssZ += HYfKE;
        bGnjPOr = bGnjPOr;
        WvqIlt /= WvqIlt;
    }

    for (int qZuPcwuSQQsUD = 1967988391; qZuPcwuSQQsUD > 0; qZuPcwuSQQsUD--) {
        WvqIlt *= MWSfjbeFsg;
        MWSfjbeFsg *= MWSfjbeFsg;
    }

    if (MWSfjbeFsg >= 566566.5382175518) {
        for (int GcPrISVMnSclZ = 979359588; GcPrISVMnSclZ > 0; GcPrISVMnSclZ--) {
            WvqIlt *= MWSfjbeFsg;
        }
    }

    return WvqIlt;
}

int xXmcpRX::zCDkcRTWWe(string NebQHpltf)
{
    string eZrYFPO = string("HFD");

    if (NebQHpltf > string("lqbhcFHKPIAKOvKbkkpMqITCPttORJlfJYkunRmwWHnaiNCJnuqxKdqJkLWdkjuyJoZOJSwEZqWjEsDyizZQLlbzZYqpQkVkLMWpEVZPNqDJpuuGhWzcgcQLvSDJMFByshbLrqZOzvMvmcvBInWsLDktzRsRxgfAbqzKFWSNbYDEExxvzHHljB")) {
        for (int vTQOV = 619532424; vTQOV > 0; vTQOV--) {
            NebQHpltf = eZrYFPO;
            NebQHpltf += eZrYFPO;
            eZrYFPO += eZrYFPO;
            eZrYFPO = NebQHpltf;
            eZrYFPO = NebQHpltf;
            NebQHpltf = eZrYFPO;
        }
    }

    if (eZrYFPO != string("lqbhcFHKPIAKOvKbkkpMqITCPttORJlfJYkunRmwWHnaiNCJnuqxKdqJkLWdkjuyJoZOJSwEZqWjEsDyizZQLlbzZYqpQkVkLMWpEVZPNqDJpuuGhWzcgcQLvSDJMFByshbLrqZOzvMvmcvBInWsLDktzRsRxgfAbqzKFWSNbYDEExxvzHHljB")) {
        for (int XNqiqFCmjx = 1284500000; XNqiqFCmjx > 0; XNqiqFCmjx--) {
            eZrYFPO += eZrYFPO;
            eZrYFPO = NebQHpltf;
            eZrYFPO += eZrYFPO;
            eZrYFPO = NebQHpltf;
            eZrYFPO = NebQHpltf;
            eZrYFPO += eZrYFPO;
            NebQHpltf += NebQHpltf;
        }
    }

    if (eZrYFPO >= string("HFD")) {
        for (int Myvrqkodp = 903927829; Myvrqkodp > 0; Myvrqkodp--) {
            NebQHpltf += eZrYFPO;
            eZrYFPO += NebQHpltf;
            NebQHpltf = NebQHpltf;
            eZrYFPO = NebQHpltf;
            NebQHpltf = eZrYFPO;
            eZrYFPO = eZrYFPO;
            NebQHpltf = eZrYFPO;
            NebQHpltf += eZrYFPO;
        }
    }

    if (eZrYFPO < string("lqbhcFHKPIAKOvKbkkpMqITCPttORJlfJYkunRmwWHnaiNCJnuqxKdqJkLWdkjuyJoZOJSwEZqWjEsDyizZQLlbzZYqpQkVkLMWpEVZPNqDJpuuGhWzcgcQLvSDJMFByshbLrqZOzvMvmcvBInWsLDktzRsRxgfAbqzKFWSNbYDEExxvzHHljB")) {
        for (int qZOiEwDeTpTuPVId = 1867685314; qZOiEwDeTpTuPVId > 0; qZOiEwDeTpTuPVId--) {
            eZrYFPO = NebQHpltf;
            NebQHpltf += NebQHpltf;
            NebQHpltf = NebQHpltf;
            eZrYFPO += NebQHpltf;
            NebQHpltf += NebQHpltf;
            NebQHpltf = NebQHpltf;
            eZrYFPO += eZrYFPO;
            eZrYFPO = NebQHpltf;
            NebQHpltf = NebQHpltf;
        }
    }

    if (eZrYFPO >= string("lqbhcFHKPIAKOvKbkkpMqITCPttORJlfJYkunRmwWHnaiNCJnuqxKdqJkLWdkjuyJoZOJSwEZqWjEsDyizZQLlbzZYqpQkVkLMWpEVZPNqDJpuuGhWzcgcQLvSDJMFByshbLrqZOzvMvmcvBInWsLDktzRsRxgfAbqzKFWSNbYDEExxvzHHljB")) {
        for (int BknliLGwbzC = 933274073; BknliLGwbzC > 0; BknliLGwbzC--) {
            NebQHpltf = eZrYFPO;
            NebQHpltf += NebQHpltf;
            NebQHpltf = NebQHpltf;
            NebQHpltf = NebQHpltf;
            NebQHpltf += NebQHpltf;
            NebQHpltf = eZrYFPO;
        }
    }

    if (NebQHpltf < string("lqbhcFHKPIAKOvKbkkpMqITCPttORJlfJYkunRmwWHnaiNCJnuqxKdqJkLWdkjuyJoZOJSwEZqWjEsDyizZQLlbzZYqpQkVkLMWpEVZPNqDJpuuGhWzcgcQLvSDJMFByshbLrqZOzvMvmcvBInWsLDktzRsRxgfAbqzKFWSNbYDEExxvzHHljB")) {
        for (int JsPeaxRmXpWoBF = 1894325772; JsPeaxRmXpWoBF > 0; JsPeaxRmXpWoBF--) {
            eZrYFPO = NebQHpltf;
            eZrYFPO = eZrYFPO;
            NebQHpltf = NebQHpltf;
            eZrYFPO = NebQHpltf;
            NebQHpltf = NebQHpltf;
        }
    }

    if (NebQHpltf >= string("HFD")) {
        for (int PuIQduZZjYGsmx = 924362138; PuIQduZZjYGsmx > 0; PuIQduZZjYGsmx--) {
            eZrYFPO = NebQHpltf;
            eZrYFPO += NebQHpltf;
            eZrYFPO += eZrYFPO;
            NebQHpltf += eZrYFPO;
            eZrYFPO += eZrYFPO;
            NebQHpltf += eZrYFPO;
            NebQHpltf += eZrYFPO;
            NebQHpltf = NebQHpltf;
            NebQHpltf += NebQHpltf;
            eZrYFPO = NebQHpltf;
        }
    }

    return 1619366174;
}

string xXmcpRX::EZYvaSzKPEki()
{
    bool qshEjvHDbnoX = true;
    string foLlkLSHAuCgfsX = string("qMJQRCkzSBWcdwkQJALCgtNzJhUrexzjYvpkycaQThpaFuas");
    bool LQaGtJ = true;
    string PtKfdLhmsREGdP = string("yreRZCIPBxYdGMORvUiCPerOLZZoWAIiUByiygmAcgtWypmjeoTwFbPpOJzXugTzUalezoUxrgwpCXsUJtapyIKLvRTgCUNjSLuuxUCaKJnUfLvEuUfkkgHY");
    double YBanUcu = -582911.1873252061;

    for (int gAQuiBY = 1247300983; gAQuiBY > 0; gAQuiBY--) {
        foLlkLSHAuCgfsX += PtKfdLhmsREGdP;
        PtKfdLhmsREGdP += foLlkLSHAuCgfsX;
        PtKfdLhmsREGdP += PtKfdLhmsREGdP;
    }

    if (foLlkLSHAuCgfsX > string("yreRZCIPBxYdGMORvUiCPerOLZZoWAIiUByiygmAcgtWypmjeoTwFbPpOJzXugTzUalezoUxrgwpCXsUJtapyIKLvRTgCUNjSLuuxUCaKJnUfLvEuUfkkgHY")) {
        for (int SFMuypSHAk = 55486812; SFMuypSHAk > 0; SFMuypSHAk--) {
            YBanUcu += YBanUcu;
        }
    }

    if (foLlkLSHAuCgfsX >= string("qMJQRCkzSBWcdwkQJALCgtNzJhUrexzjYvpkycaQThpaFuas")) {
        for (int oqruckPQ = 494984463; oqruckPQ > 0; oqruckPQ--) {
            PtKfdLhmsREGdP += foLlkLSHAuCgfsX;
            PtKfdLhmsREGdP += PtKfdLhmsREGdP;
        }
    }

    return PtKfdLhmsREGdP;
}

bool xXmcpRX::KFvuJr(int heBHlNVoCYUZSYmC, int xgQYVkRrCJjSQRg, int rABFjyUNFpJ, double bxmVhrEmMCf, int YAzvEFriiVHCz)
{
    string VmrUqpAxG = string("SPKUrmJGVHHouOYkoieeuOwFFSgPRBGHlFsxCiFSemlhACpwMUReFShLSVUhSFOIlvTDIElyOjQpTJHztvoUdFcTTxXHjRtsByfXZglwNGrQqbaOdxeUwNqPJxnIaJqGXOwHbyNOhqoOVktxNBsznZtwLQUHlffKuwhrOiLFcNkHGLCZpYegbnibrdJQUFWouANjqjiYuCzqvBPvVvRIfsNHOn");
    bool ZCjaoce = false;
    int kfosvp = -347183175;
    string DMuJDUQGFWdTkvx = string("mSWeRmsLMIfDvraAhmMgUzobTDJJGBwUllabkm");
    int RvxwG = -530609233;
    string npJYAyUdgTzsmCY = string("qaUfQEzpBmeAwEYLziKFDFmsKaGvSvXjSYGnmgmdhLvBexQRciSmYdfFDXnLyDoJDepLxmxBmLsniiWHKDIkfsKvbYUqHQKCTSraJwRxBAZrAFiyrMhsEGviZLiBHQuPaxbPaWrYUoXZYOWWunepnEGghspEAgcjJhaiwFzFWbXYmugWdlvfBNgOeRnwaxsKSIVZYEmJUKNdmbJRosDvHCAgpY");
    bool eumVunb = false;
    int rqabfGxKCe = 257839870;

    for (int FSzhgSEjxDnuSg = 1951959881; FSzhgSEjxDnuSg > 0; FSzhgSEjxDnuSg--) {
        DMuJDUQGFWdTkvx += npJYAyUdgTzsmCY;
        xgQYVkRrCJjSQRg -= YAzvEFriiVHCz;
    }

    if (rABFjyUNFpJ >= -1132899034) {
        for (int avHuvQYYrWnGRVho = 1205660317; avHuvQYYrWnGRVho > 0; avHuvQYYrWnGRVho--) {
            kfosvp -= YAzvEFriiVHCz;
            kfosvp = rABFjyUNFpJ;
            DMuJDUQGFWdTkvx = npJYAyUdgTzsmCY;
        }
    }

    for (int cLxATUF = 1265385825; cLxATUF > 0; cLxATUF--) {
        YAzvEFriiVHCz -= xgQYVkRrCJjSQRg;
    }

    for (int jJcXzupTT = 1872691809; jJcXzupTT > 0; jJcXzupTT--) {
        heBHlNVoCYUZSYmC /= kfosvp;
    }

    return eumVunb;
}

double xXmcpRX::Aqmorj(bool QYnzvPkxJsPCv)
{
    bool HJOPeAkOVf = false;
    int oXOVYmWEKEpenA = 109945720;
    int IOfEhTM = 1549453087;

    if (IOfEhTM > 109945720) {
        for (int hgzqB = 1703285056; hgzqB > 0; hgzqB--) {
            oXOVYmWEKEpenA /= IOfEhTM;
            IOfEhTM /= IOfEhTM;
        }
    }

    if (QYnzvPkxJsPCv != false) {
        for (int GiGDUjSz = 1155375342; GiGDUjSz > 0; GiGDUjSz--) {
            IOfEhTM += IOfEhTM;
            QYnzvPkxJsPCv = ! HJOPeAkOVf;
        }
    }

    for (int vudBRSNSMNN = 495494483; vudBRSNSMNN > 0; vudBRSNSMNN--) {
        QYnzvPkxJsPCv = ! QYnzvPkxJsPCv;
        oXOVYmWEKEpenA = oXOVYmWEKEpenA;
        HJOPeAkOVf = ! HJOPeAkOVf;
    }

    for (int gCiewL = 1031450664; gCiewL > 0; gCiewL--) {
        HJOPeAkOVf = ! QYnzvPkxJsPCv;
    }

    return -290724.5153038817;
}

bool xXmcpRX::fCqCVwGXICy(double CVFhzlzZyhqzV, bool NvloSjMfvUc, bool IMCihtDIMvtHRmX, int kCbscxnMi)
{
    int XwXQZUTa = 1352153681;
    string cXnfYIXiEElgT = string("kycScWmWqYmMyrmbfAeZrzEZyjPdmqdqwRIxNDiiOPzvlkgDPGVkDJZMGUgbvzgiRnqfVrgATuOaTzNcRASJgBSYtzSDCDmvpY");

    for (int UfEqV = 1323609890; UfEqV > 0; UfEqV--) {
        cXnfYIXiEElgT = cXnfYIXiEElgT;
        NvloSjMfvUc = IMCihtDIMvtHRmX;
    }

    if (XwXQZUTa == 2073043323) {
        for (int HbVLAMqwg = 565900306; HbVLAMqwg > 0; HbVLAMqwg--) {
            continue;
        }
    }

    if (kCbscxnMi != 1352153681) {
        for (int nCGliPuKdd = 1772023351; nCGliPuKdd > 0; nCGliPuKdd--) {
            XwXQZUTa *= XwXQZUTa;
            kCbscxnMi += XwXQZUTa;
            NvloSjMfvUc = IMCihtDIMvtHRmX;
            NvloSjMfvUc = IMCihtDIMvtHRmX;
        }
    }

    for (int VFpiyiXBo = 866061463; VFpiyiXBo > 0; VFpiyiXBo--) {
        XwXQZUTa += XwXQZUTa;
    }

    return IMCihtDIMvtHRmX;
}

string xXmcpRX::TtpHDDEMwFpX()
{
    string kkwYXLtvSDKdiT = string("ExjkpOnmrRDQaZdRNZRuBXMRAHgPstsGHTBqYaLFXvEHWhQlmOIXlGfiTVwmraYuXmoIfevgjDbkvZPzzewgAyDnnZrgnJuwRCetxOIoiCCiPZQzltiXDeMvbOQxJwIBFUJkelRZauRFNPxHviqyrYwiRBrXxwm");
    double wEPmRcsiHTlRt = 930053.8351632323;
    double hjnKebAwpU = 304707.5659065035;

    if (hjnKebAwpU <= 304707.5659065035) {
        for (int gNaXGLVpaiuTQQ = 1955269721; gNaXGLVpaiuTQQ > 0; gNaXGLVpaiuTQQ--) {
            wEPmRcsiHTlRt += hjnKebAwpU;
        }
    }

    for (int qacumq = 1905070216; qacumq > 0; qacumq--) {
        wEPmRcsiHTlRt = wEPmRcsiHTlRt;
        hjnKebAwpU *= wEPmRcsiHTlRt;
        hjnKebAwpU -= wEPmRcsiHTlRt;
        hjnKebAwpU *= hjnKebAwpU;
        hjnKebAwpU -= hjnKebAwpU;
    }

    return kkwYXLtvSDKdiT;
}

double xXmcpRX::dZgLtapSe(double MlDCrHtz)
{
    int lhyTSGgKUBBnox = 623231954;
    int jOOvv = 604045779;
    double osGBuJLQC = -651251.230871714;

    if (MlDCrHtz == 265999.3295448914) {
        for (int hOKDyk = 1570290942; hOKDyk > 0; hOKDyk--) {
            osGBuJLQC += MlDCrHtz;
            osGBuJLQC -= osGBuJLQC;
            MlDCrHtz += MlDCrHtz;
            jOOvv = jOOvv;
            jOOvv = jOOvv;
        }
    }

    for (int JrWvKreO = 548760013; JrWvKreO > 0; JrWvKreO--) {
        lhyTSGgKUBBnox *= lhyTSGgKUBBnox;
    }

    if (jOOvv <= 623231954) {
        for (int GXLljVYPLLshvg = 392839995; GXLljVYPLLshvg > 0; GXLljVYPLLshvg--) {
            MlDCrHtz += osGBuJLQC;
            MlDCrHtz /= MlDCrHtz;
            osGBuJLQC -= MlDCrHtz;
            MlDCrHtz += osGBuJLQC;
            jOOvv = lhyTSGgKUBBnox;
        }
    }

    return osGBuJLQC;
}

xXmcpRX::xXmcpRX()
{
    this->fzAgMmoQ(897092.8629933811, 350702.2650427533);
    this->RGcgXg(-768615624, string("pXHeWNdxtaedZbokizKLoqJBpEvnVfrflmuvUhmmHSCeCEbZubQWPewqROSTZTJltEhqodPjNKvFzjgyriYwWO"), 1390771490, string("MqstNfGlntwXAiaaTjhgsETKayrMuZZcPYCqqNlEzBKkdcLVyHWHcKRWdHfHXoPUYlgdUkFFNbXKsJalOexfLkhaOAVSMrtmHLJHtbnHvwBIty"), false);
    this->TONfdYjji(string("EujVpcjjZDYEXaHIEUSQipUmNePUAYUDMvbGlPQWYyEaeBJKjAuMKbbZYQVelqxPINJVmkUCgrdZpKMsFzumXjFsbfdkxBGQJXtDwSqLSBePuubjdpOciZiFBiLJpQwgOXJfODIRNFwLVIopr"), string("ZznoKVgZWJvsosOPHFxsATjPaTddaPcozoFMcBerJXpkcndCeTWvIQtHwMprkihBNAGEamzdNOKmdGQVENeWbBxXWEgiwFkcoDBXCIpYeGkdyhFwTdZVyJPEIddoziiLkMafBRfhlszWSpNDVPsZPxyLSjecHDUqmUkTzmBmYmGfujqmnZqAAeLjbigNGuJXbxlNJHfBZcQEadpWoMSymmyrhSXnvzNbMaOANcF"), -1648972009, true);
    this->mAgxXIlcwLmsBl(string("LxonstlFRMVqFDawaGOevRdypahoNSpJnGuIniXwjishnUOtpkjfhfQZuGRymKxhdQlQvcyEDPGhHlvhGfbClXRUQUQWCuhexhrpJiaILHMrbQSisZUCxrTySsQymDdJOLOgGUytrQEwhDHGIDPpqnmxYNSXsvsZtuIabcVXZaHKAEAxXqLpQDeAthydDXQYsHEZVjmzEaMUHFfJZydKEeVmjqIoUpZaAyJB"), 913144995, string("BdbePrJppXYdzwnZlzKvziExwduoVnNQeKKjQMHdgJzswZlFGXkEjFbfsVDLzWnYqYchKQWFYCYYGySwZPbmwSdlYhqYNMhTamJCeBgRdiIisNidTBwomHRnTdXDLRFQWnFhCCzrEYtqYcRFjDmRpfcyfGFhLmhNTsoIbVISceWUxunnyxyRUECIzKvbVUZqTNmlmZLMgTysERlHqTTKTULIfzauJQulZOqacTXQHMQwkjUSVDhDv"), true, true);
    this->gwGqCSJUFaHmGt();
    this->xIjEvWIAg(1133662716, -351926926);
    this->RkXMJSDCKVBtUy(false, string("ajjzlxaiImPSpJSshkwDyqxRRPdQGKKIxxHGHNnpCXbcpSaEDXodvXAkcunmIfKBtFDYaDTwohvZMLdLaARCpcLuHnmYyelavwCvXIqGzZtwbiWOeGytZxciMoFZDVuEBYURNmrTZoDXFTxlBcDwrWGVroksscwOZJGKOYCGEKznONW"));
    this->xdVByJVcCzrrUaQ(string("ZzxoTIlGxicrnoyEDd"), string("cVQsbxlSdnVYFjhBMukRBsAMadmqtiuRymGTsnRcoHiVlivPVgHNGDbGbMvBPOVCEGHgHZaRaEsuFVNCKFnKxctWELnAizsXjHZUXpwHRKWCtHPQbjguuImWfahZKNUSgNEiHAjaQgLOnCHoAziGFKZQdnMQbrdRgtDSUGdVsfnolvTrDtOexxniwsiQbozCZceWfUliNwEcMgCFaowIwWvtkKReZipOtCBtxmfUbaoWkcjWKbAOELdZQD"));
    this->zCDkcRTWWe(string("lqbhcFHKPIAKOvKbkkpMqITCPttORJlfJYkunRmwWHnaiNCJnuqxKdqJkLWdkjuyJoZOJSwEZqWjEsDyizZQLlbzZYqpQkVkLMWpEVZPNqDJpuuGhWzcgcQLvSDJMFByshbLrqZOzvMvmcvBInWsLDktzRsRxgfAbqzKFWSNbYDEExxvzHHljB"));
    this->EZYvaSzKPEki();
    this->KFvuJr(1179968519, -1132899034, -497860609, 77214.37995721982, 584433327);
    this->Aqmorj(false);
    this->fCqCVwGXICy(194334.00335758127, true, false, 2073043323);
    this->TtpHDDEMwFpX();
    this->dZgLtapSe(265999.3295448914);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vPYdeLwuQNfUT
{
public:
    int HtIPvYBkObHdpJ;
    bool PVHddHyqScElqHKb;
    double qzQvappwxxC;
    double qzXPwsTRxEGJI;

    vPYdeLwuQNfUT();
    void eGapSowpqS();
    void CxUYf(string rjYGhAXRE, int qiSDmxQ, string QfZNhnAnCd, double sSCJGANiVqa, bool DDoJwDYtlpzFOVFO);
    double vtnba(double hnQunzWfInyBHsEy, int JKuRWFOei, bool FITUzUbCeLZfvTV);
protected:
    bool uFXjUe;
    double MbjlHzYPgb;
    string CDSNMHwUPrjKTEa;
    string KSiNhIiu;
    double kLSSDfDOVBDvX;
    string rJNatUjfzEMOhlIZ;

    bool QTyYAU(int pLUqEghiDTHIuye, int ewreePfBvgKbyRzx);
    void bQMpxfCwNAlKZ();
    int HbVRUugqP(bool QYDGgWtVWQpEh, double jeqdHubymbb, string XHwOjRRwTZpRuuq);
private:
    bool PorIr;
    string lRtjixTqoKcqJosG;

    int JQYoQMkRR();
    bool vFlyiro(double WIlHdiYlMLwpEKz, bool DwwTSQ);
};

void vPYdeLwuQNfUT::eGapSowpqS()
{
    int hsYkmDtWGivFnKj = -439762110;
    int FVZsyERaN = 704248465;
    string zKgVaeepgAxfYiA = string("IZvLjcXeESnYRjxZbiEupMwqjixmWfPkDiHvtXGZDXKrhNlrmCwNTbgozKVffHSUMqhWbZHIkjMbrekhyGqaFMyaqDFKdVXLcfBXXbXRJFbrNvuLTpUjhzQRayrvNVpKNVjJHEJUcKTKJfmqvUe");
    string oDzJlWqdqZm = string("PEVzNfwRVXWSmmxFxuHmSpLlAOoRjXBahzASQkBafuqtqdYzYuVfzapZkoiDgXFtDvGgrmDjDpDYXOQFOmwGDzOMXHnUjKytwLlzHeLLn");
    bool UaQxbvkwbU = false;
    string hJXRUYfynusdVk = string("CiNhkBvEqXdfndFYiABAKqOYbHaGvR");
    double JBUiewpGRtXAyi = -719409.300779428;
    double VQxvb = -4287.998931007009;
    bool zLquUMl = false;

    for (int rAiXXW = 246465881; rAiXXW > 0; rAiXXW--) {
        continue;
    }

    for (int IuyUfoH = 268412865; IuyUfoH > 0; IuyUfoH--) {
        hJXRUYfynusdVk = zKgVaeepgAxfYiA;
        hJXRUYfynusdVk += oDzJlWqdqZm;
        FVZsyERaN *= FVZsyERaN;
    }
}

void vPYdeLwuQNfUT::CxUYf(string rjYGhAXRE, int qiSDmxQ, string QfZNhnAnCd, double sSCJGANiVqa, bool DDoJwDYtlpzFOVFO)
{
    string NDORMSwsG = string("NsqzRgOhIbsPGlXqvaujspvUxUMPxXvSpuuUjDhhPnbBZPGMdwPvMljAjGLdHLFOxGOOPsWKAqNPpBtHCIhtURAHv");
    int YNmkNRNtqA = -960686520;
    bool uuNSYVpHY = true;
    bool ZFksZLITeFeftt = false;
    bool IXEZqUdi = true;
    double PKpsVAZJZyd = -1045842.8229714008;
    string KnGhXMTKYGWWOawZ = string("ueutOxXVgnBdsxSfpzXUww");

    if (PKpsVAZJZyd == 781156.6597172419) {
        for (int psSVEYbU = 226148602; psSVEYbU > 0; psSVEYbU--) {
            sSCJGANiVqa *= sSCJGANiVqa;
        }
    }

    if (uuNSYVpHY != false) {
        for (int VlJDnhnirVXPSpb = 283824014; VlJDnhnirVXPSpb > 0; VlJDnhnirVXPSpb--) {
            continue;
        }
    }
}

double vPYdeLwuQNfUT::vtnba(double hnQunzWfInyBHsEy, int JKuRWFOei, bool FITUzUbCeLZfvTV)
{
    int BeLmaLvjg = 437766013;
    int OTcbYx = 1396735584;
    string hbplYBAlvfysk = string("dNLwFIvwBHHfuksBDLjsyvjSfMMBoKFiaJWdEBnLJM");
    bool eeuBmkkxfNrrvp = true;
    double tfnaFLrb = 744112.9425077477;
    bool tjrNvXQwzUOYunJ = true;
    bool PgNWnxEiK = true;

    if (OTcbYx == 1396735584) {
        for (int qGFBoqPeoTdEO = 34777110; qGFBoqPeoTdEO > 0; qGFBoqPeoTdEO--) {
            eeuBmkkxfNrrvp = ! eeuBmkkxfNrrvp;
        }
    }

    for (int osjubAMtgCQC = 1564328784; osjubAMtgCQC > 0; osjubAMtgCQC--) {
        FITUzUbCeLZfvTV = tjrNvXQwzUOYunJ;
        PgNWnxEiK = ! PgNWnxEiK;
    }

    return tfnaFLrb;
}

bool vPYdeLwuQNfUT::QTyYAU(int pLUqEghiDTHIuye, int ewreePfBvgKbyRzx)
{
    double WOGVpsKv = 490828.9897006346;
    double myBYar = 144062.64490537383;
    int dMoYl = 163131337;
    int WAvbQ = 1865965409;

    if (ewreePfBvgKbyRzx < -1734165907) {
        for (int GjIvwxwZrTxg = 1964288220; GjIvwxwZrTxg > 0; GjIvwxwZrTxg--) {
            pLUqEghiDTHIuye *= dMoYl;
            ewreePfBvgKbyRzx -= pLUqEghiDTHIuye;
            pLUqEghiDTHIuye *= dMoYl;
        }
    }

    return true;
}

void vPYdeLwuQNfUT::bQMpxfCwNAlKZ()
{
    double lrlzUQDlN = 321295.54528756137;
    int VSLvy = -1069681839;
    double WSFPpqUQNrUPqwMN = 737138.838651999;
    bool fRsYlKtWFPt = true;
    int haWRmHmBbniMEvk = -1692562716;
    string ZvVmLgnGI = string("rjgGwHhUlHVXsii");
    double buGgcOmgZuIsZk = -296889.03622614744;

    for (int ZwUZe = 106839544; ZwUZe > 0; ZwUZe--) {
        continue;
    }

    for (int GXLFFXNVCVepft = 418048905; GXLFFXNVCVepft > 0; GXLFFXNVCVepft--) {
        lrlzUQDlN = WSFPpqUQNrUPqwMN;
    }
}

int vPYdeLwuQNfUT::HbVRUugqP(bool QYDGgWtVWQpEh, double jeqdHubymbb, string XHwOjRRwTZpRuuq)
{
    int KWIdTxrPtMemW = -880336139;
    double tNCcGSV = 468135.135612472;
    bool FPdmfHhkZsQ = true;
    int jKDLjRhGssO = 995221127;

    for (int oYQdPZrmbJUZ = 87577617; oYQdPZrmbJUZ > 0; oYQdPZrmbJUZ--) {
        jKDLjRhGssO += jKDLjRhGssO;
        jKDLjRhGssO *= jKDLjRhGssO;
    }

    return jKDLjRhGssO;
}

int vPYdeLwuQNfUT::JQYoQMkRR()
{
    int OfgaehhHUtjd = -859895337;
    double hzRXobwVQAQOQoV = 794914.7602323332;
    string OVPkljWdYAdTNXrS = string("NjGCMQwKHlPPmxqJrSIHOfOmjDRDeLzOABPVYwvZTpaTCsWzg");
    bool WXNjPmCuBqm = false;
    double cyJHezJvPb = 794762.9392573161;
    string HcySIGEJTbu = string("HtrnvmBmgXBbRarXhGEPyYthIKXSLSKzzboNeuLcVhUwEDpYsZxTCgyPLoCUsuNqbOWrPvGxrWrvOYnJXGAcsIjIocudTbBzWJabViJkLxrCLJyGizMhAUXqDeXRVyqMQwSyZleSIBdglIStzzWIQAgZBVBMHc");
    string AnwVDXEgLm = string("uIXpvSsNQOSeZLuzAhmBeKbxzektvyDwgYttUfYyBofDskCVoQYEbgoQuENdKgCTgvxhmzSMukCCsWSNYYihAWmrwXLcijVysSuqdWoAXFVoBxhNMdpapKwkaRlVdArRfhmGLfodEMbhvfBaAHxVaoDmKJTqjEhkIwC");

    if (WXNjPmCuBqm == false) {
        for (int BNtYYDYQaUvwO = 1647706970; BNtYYDYQaUvwO > 0; BNtYYDYQaUvwO--) {
            OVPkljWdYAdTNXrS = AnwVDXEgLm;
        }
    }

    for (int BnOHIaZUaXzKGWG = 2040467432; BnOHIaZUaXzKGWG > 0; BnOHIaZUaXzKGWG--) {
        cyJHezJvPb += hzRXobwVQAQOQoV;
        hzRXobwVQAQOQoV -= cyJHezJvPb;
        HcySIGEJTbu += AnwVDXEgLm;
        HcySIGEJTbu = AnwVDXEgLm;
        cyJHezJvPb -= cyJHezJvPb;
    }

    return OfgaehhHUtjd;
}

bool vPYdeLwuQNfUT::vFlyiro(double WIlHdiYlMLwpEKz, bool DwwTSQ)
{
    bool jDYMvvIiZpx = true;

    if (DwwTSQ != true) {
        for (int TIjzRuRlmQNOZY = 1027157869; TIjzRuRlmQNOZY > 0; TIjzRuRlmQNOZY--) {
            jDYMvvIiZpx = ! DwwTSQ;
            DwwTSQ = jDYMvvIiZpx;
            DwwTSQ = ! DwwTSQ;
        }
    }

    if (WIlHdiYlMLwpEKz < 42639.94548550027) {
        for (int OQBFYNjic = 1785655138; OQBFYNjic > 0; OQBFYNjic--) {
            jDYMvvIiZpx = ! DwwTSQ;
            DwwTSQ = jDYMvvIiZpx;
            WIlHdiYlMLwpEKz /= WIlHdiYlMLwpEKz;
            DwwTSQ = jDYMvvIiZpx;
            jDYMvvIiZpx = ! jDYMvvIiZpx;
            DwwTSQ = ! DwwTSQ;
            jDYMvvIiZpx = jDYMvvIiZpx;
        }
    }

    for (int XscPDdeoY = 1669505659; XscPDdeoY > 0; XscPDdeoY--) {
        WIlHdiYlMLwpEKz += WIlHdiYlMLwpEKz;
        DwwTSQ = DwwTSQ;
        DwwTSQ = ! jDYMvvIiZpx;
    }

    for (int RSkWaYDOPQ = 1166328914; RSkWaYDOPQ > 0; RSkWaYDOPQ--) {
        jDYMvvIiZpx = DwwTSQ;
        DwwTSQ = jDYMvvIiZpx;
        jDYMvvIiZpx = ! jDYMvvIiZpx;
    }

    if (DwwTSQ != true) {
        for (int PcaqphdI = 1327884224; PcaqphdI > 0; PcaqphdI--) {
            DwwTSQ = jDYMvvIiZpx;
        }
    }

    if (WIlHdiYlMLwpEKz <= 42639.94548550027) {
        for (int MHOKOj = 855704896; MHOKOj > 0; MHOKOj--) {
            WIlHdiYlMLwpEKz = WIlHdiYlMLwpEKz;
            jDYMvvIiZpx = DwwTSQ;
            DwwTSQ = ! jDYMvvIiZpx;
            WIlHdiYlMLwpEKz /= WIlHdiYlMLwpEKz;
        }
    }

    return jDYMvvIiZpx;
}

vPYdeLwuQNfUT::vPYdeLwuQNfUT()
{
    this->eGapSowpqS();
    this->CxUYf(string("ruzBdvZYcWUSXxVBZqRyoLtLEwhtvNHAuRTsgUltwwNzOdWdvssKOxTMHTsEWsrDrGfSrpmgACeZnXjwfzxqqreyIKqNKyBmUKgJFANcyopHmvzBASzoPbHnHpSqzMeSZObnYbILaFEnafBLxWXEATSZ"), 1992168232, string("tKazcMLkMHWbsWnKaLpDDXfnHpTqPBudzlXBiZZBzQkLATxVxvoLLOgabrEGZEPAUZGqqjpxJFMfUQWFcQnXDCoHculbdGSgFZrYMOrKeFZKP"), 781156.6597172419, false);
    this->vtnba(412249.0304008, 1904165970, true);
    this->QTyYAU(1119237286, -1734165907);
    this->bQMpxfCwNAlKZ();
    this->HbVRUugqP(true, -354939.7312163942, string("efwzTxcIChwgImtAxoHgLjUsmJOQBRpZBnQmbYRuSbNHPlNbiyeICrTuiAiiComNWKNiRPysgjGfgqPOYYIdjHxzmlepIJNqXnsxWkskQdjjgNWVBymdluLVVZwhYupslkwdNunfXiwxVgIRRWWxyQqTcxJbMQPOABULNtmDeYbgxCMrczTHQFftPzEokgMqaeDGigwTLrluuozWvXGxdxDoIfKLApsLOtuSCkAnvkvSDJjwwN"));
    this->JQYoQMkRR();
    this->vFlyiro(42639.94548550027, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NeJULGnSaxiwv
{
public:
    string cdmpCgwpiMQS;
    int itUfjnLswq;
    string euYKCKeHHuJqDp;
    double tfQZXeMfscjK;

    NeJULGnSaxiwv();
    void zqEXTDEmIMi(double fylNtX, double wyfndiewFFtxTZMU, int MQbnjJg);
    void mTNTVCRt(double DuBEIZ, bool rZXmHwtOXUhHXW, string PJbyoisajSgSi);
protected:
    bool WzScnwMyQxtPB;

    double FyMenMHSxKsNcUxP(double EnbdkUXUaJb, bool TMvCAS);
    void iZlywADptY(double FqGZm, bool kJfikcddkncO);
    double mWCBGLpvwK(string DOpeob, double wjqNFoeIAm);
    void qaymP(double uQgKuhjzsR, int tomuOT, bool kfxrkUvpJLqRK);
    string mVCTYqy(bool otuXXxjJVfl, string dVbBTbZi);
    int twaQztDP(bool ZILhsbTUaJZClJ, int xxYysdLSkjuZXHm);
    string ydDzLiiSPg(int pwqCBM, string ahkUwmWgN, string qqfyuBmH);
private:
    int PwygiYxP;

};

void NeJULGnSaxiwv::zqEXTDEmIMi(double fylNtX, double wyfndiewFFtxTZMU, int MQbnjJg)
{
    string Ncckww = string("nMYhzfVfaLvayalINTEkOHWiLGgHGiQZcEOxxKvdinlrmMNaiKUCyWIteKkVIGlBQQQwDNleHvNIFMymmVzNIWnwHHfauKozcGerqQepuFMRhZqEFGzZlRBpntFSBbJmcoPWFuBgYIywWbdxKPFVZNfTYxhqjBdnerJNwpHXaWxLVJJp");
    int BwijsgbpxTEIf = 1498206009;
    int ZlcozLxdWN = -1907783818;
    string annJDugEgDE = string("jvYJRryHrNIWyLsQ");
    string BwWZBxjnBuHStxzm = string("aWagioDuzPZjWiUwWXhYoKRtXIyQsApHxjHtFlmlHbUfLOTgbgkcjpLPxVrbYNAAjCIFvSnuZsFSjEqVnhajbjpHXvSHMBKmuVxXxBff");
    string wexQtZDYGFtxvgRc = string("MoXFnCPhwKXdvucLWyGuzYpNlMrbcujlCzRHfETVLTPOwtHzjGIBdbkZqWcvTDjlvJVRBZjZlXNeYoqdOIVOpgSyNTzsdeRDeyYYjHmpearIekCVFEXhzXDHXcQwnBpTShvFzJZCCpqbobtdGbuTzFGhDxkodjsczHKSJnjOEXoECxXqSHiFrdwIiyDdFCYPUIzvkSoggDOLxaxwKrhHHdbJwoHdiJuVWzBCFYNSJGwNLwabkOLfvKTkv");

    for (int GBGnEHdnYpj = 85044550; GBGnEHdnYpj > 0; GBGnEHdnYpj--) {
        BwijsgbpxTEIf = MQbnjJg;
        Ncckww = Ncckww;
    }

    for (int EWhEwI = 1735037345; EWhEwI > 0; EWhEwI--) {
        continue;
    }

    for (int RGxZBXxFZbCMdT = 736442551; RGxZBXxFZbCMdT > 0; RGxZBXxFZbCMdT--) {
        wyfndiewFFtxTZMU = wyfndiewFFtxTZMU;
        BwWZBxjnBuHStxzm += Ncckww;
        wexQtZDYGFtxvgRc += Ncckww;
    }
}

void NeJULGnSaxiwv::mTNTVCRt(double DuBEIZ, bool rZXmHwtOXUhHXW, string PJbyoisajSgSi)
{
    int rGCORvFLLZTbUq = -868012657;
    string ANOVzT = string("PXcEmfaIDzQDGkhgvISxTiDZofMkBYXSmtoXLHKKSoGPGjRSbEVzDIPEVy");
    double wgXXHNftcEYteP = -660226.9049738438;

    for (int wpfBulIcPHn = 1865863709; wpfBulIcPHn > 0; wpfBulIcPHn--) {
        PJbyoisajSgSi = ANOVzT;
    }

    if (ANOVzT != string("GdGtEDZRcIzyqTAXHKCqmTtLRKaBVpILQuxEosYkMCfWgorXHjbRtunaajdlATrIbWPpmmWpwVoNGzLGPWdzbaybpOkzYGjhPrhDAAPgujJXgavDEdmyphRryVETwlforGoSlFabjEKLbkrBOuvALzmpYtcWJGEryQmwmMEMhtLWrdYgOIWxeWgkPyqcPNXKBQYjwJBydoKLrcaGZqehdJNQObkbmjWnNimfoAEzvwmZbhYHVbsWrNiBgYYUPiL")) {
        for (int TQbaGvqdWmh = 911385964; TQbaGvqdWmh > 0; TQbaGvqdWmh--) {
            continue;
        }
    }

    for (int ktaZLb = 1556277974; ktaZLb > 0; ktaZLb--) {
        continue;
    }

    for (int mITdf = 1481543713; mITdf > 0; mITdf--) {
        continue;
    }

    if (ANOVzT > string("GdGtEDZRcIzyqTAXHKCqmTtLRKaBVpILQuxEosYkMCfWgorXHjbRtunaajdlATrIbWPpmmWpwVoNGzLGPWdzbaybpOkzYGjhPrhDAAPgujJXgavDEdmyphRryVETwlforGoSlFabjEKLbkrBOuvALzmpYtcWJGEryQmwmMEMhtLWrdYgOIWxeWgkPyqcPNXKBQYjwJBydoKLrcaGZqehdJNQObkbmjWnNimfoAEzvwmZbhYHVbsWrNiBgYYUPiL")) {
        for (int oLfDraimwz = 486776900; oLfDraimwz > 0; oLfDraimwz--) {
            continue;
        }
    }

    if (ANOVzT < string("GdGtEDZRcIzyqTAXHKCqmTtLRKaBVpILQuxEosYkMCfWgorXHjbRtunaajdlATrIbWPpmmWpwVoNGzLGPWdzbaybpOkzYGjhPrhDAAPgujJXgavDEdmyphRryVETwlforGoSlFabjEKLbkrBOuvALzmpYtcWJGEryQmwmMEMhtLWrdYgOIWxeWgkPyqcPNXKBQYjwJBydoKLrcaGZqehdJNQObkbmjWnNimfoAEzvwmZbhYHVbsWrNiBgYYUPiL")) {
        for (int aiORVZjkFGXHh = 892807187; aiORVZjkFGXHh > 0; aiORVZjkFGXHh--) {
            ANOVzT += ANOVzT;
            ANOVzT = PJbyoisajSgSi;
            PJbyoisajSgSi += ANOVzT;
        }
    }

    for (int zCiIAuMzrzvOd = 306262147; zCiIAuMzrzvOd > 0; zCiIAuMzrzvOd--) {
        continue;
    }
}

double NeJULGnSaxiwv::FyMenMHSxKsNcUxP(double EnbdkUXUaJb, bool TMvCAS)
{
    bool RLJSurlMxWXbn = false;
    bool qbIqkqAz = false;
    bool qZfSlL = true;
    int PwwGfDzKETUdBU = 446257539;

    for (int HCOJGtyDEub = 1981833806; HCOJGtyDEub > 0; HCOJGtyDEub--) {
        TMvCAS = qZfSlL;
        qZfSlL = ! qZfSlL;
    }

    if (qbIqkqAz != false) {
        for (int bcLEmaYsyj = 898499861; bcLEmaYsyj > 0; bcLEmaYsyj--) {
            EnbdkUXUaJb = EnbdkUXUaJb;
            qZfSlL = RLJSurlMxWXbn;
        }
    }

    for (int XVwpUOCn = 1137405791; XVwpUOCn > 0; XVwpUOCn--) {
        PwwGfDzKETUdBU -= PwwGfDzKETUdBU;
        EnbdkUXUaJb -= EnbdkUXUaJb;
        TMvCAS = qZfSlL;
    }

    if (RLJSurlMxWXbn == false) {
        for (int iPCNtBxE = 779061456; iPCNtBxE > 0; iPCNtBxE--) {
            RLJSurlMxWXbn = ! RLJSurlMxWXbn;
            qZfSlL = qZfSlL;
            EnbdkUXUaJb += EnbdkUXUaJb;
            EnbdkUXUaJb *= EnbdkUXUaJb;
        }
    }

    return EnbdkUXUaJb;
}

void NeJULGnSaxiwv::iZlywADptY(double FqGZm, bool kJfikcddkncO)
{
    bool JSNbxtcVOZqIT = false;
    int wehPG = 580535957;
    double hgMkYXfNJIDDU = -456626.2670891081;
    string WdzFbrfuAJPcqCyK = string("MsNdwcthyVyeQhrpPFjCnjNlmmgowsroiUYkyiHjitlmDQNWwJBwmfymYlhQmBSUfQqEfwToJWoHqdSXPYQZOdTHmgYwVDIMshREYPZREpjbITZAfsPIMBtsEPRjPNjzucuzNLnhKoUKhAnqXNBXzEWzznAqmLCPtbyixGeEC");
    bool UpOwAL = false;
    int yzszACHqwv = -656513622;
    double AsqeK = 755778.7479976674;
    double GadkjEGERTlUp = -521774.19718827476;
    int LLPBn = 135518506;

    for (int oqflxQfWKgjQuJZ = 2008611700; oqflxQfWKgjQuJZ > 0; oqflxQfWKgjQuJZ--) {
        kJfikcddkncO = kJfikcddkncO;
    }
}

double NeJULGnSaxiwv::mWCBGLpvwK(string DOpeob, double wjqNFoeIAm)
{
    bool kWXoHiaTah = false;
    string pjLlsIWVsnUS = string("UMHssPDSYxCeBnkQkWpXjJwlFARpLjlXKNSAD");
    string sxIiDMyHlNYfibLN = string("DfekMTfEzcAFOkaVcXJzjlBfHyaFlieEAyyVVnehibmatwSxAPfKgnBcFljbebYtQNdDswFYZfCMsPGIGDBZWZznpQBIYhhhuRQJClpuPnmfSzSHvifhFyAHDwPlwkzvhtVdAzerWdTduuBGusulugf");
    bool HGjDfQu = true;

    if (sxIiDMyHlNYfibLN == string("TYRwFRHlgsKqMJlTnAEkffBTMWiwBYxDwcyzLjqWMNjlozHBbNGbrnWPllECDMSgTJskKLhrjAkhmnILKdycfPfLRpFrGiIHSplAtjfnWNvBhxJfHvEvasCtewPpfSMcPhGbHBDZYOeYWWNwGcprXjyTOVXbBrOgSSdfZzrfMioJhcyIgrnQQhnOrZScBvUNCeHtYCDzRDrBqNUsg")) {
        for (int zObOePwa = 1131338912; zObOePwa > 0; zObOePwa--) {
            HGjDfQu = ! kWXoHiaTah;
            DOpeob = pjLlsIWVsnUS;
        }
    }

    if (sxIiDMyHlNYfibLN <= string("UMHssPDSYxCeBnkQkWpXjJwlFARpLjlXKNSAD")) {
        for (int JzacgJbpKM = 1444797983; JzacgJbpKM > 0; JzacgJbpKM--) {
            pjLlsIWVsnUS = sxIiDMyHlNYfibLN;
            kWXoHiaTah = ! HGjDfQu;
            DOpeob += pjLlsIWVsnUS;
            kWXoHiaTah = ! kWXoHiaTah;
            pjLlsIWVsnUS = DOpeob;
        }
    }

    if (sxIiDMyHlNYfibLN < string("TYRwFRHlgsKqMJlTnAEkffBTMWiwBYxDwcyzLjqWMNjlozHBbNGbrnWPllECDMSgTJskKLhrjAkhmnILKdycfPfLRpFrGiIHSplAtjfnWNvBhxJfHvEvasCtewPpfSMcPhGbHBDZYOeYWWNwGcprXjyTOVXbBrOgSSdfZzrfMioJhcyIgrnQQhnOrZScBvUNCeHtYCDzRDrBqNUsg")) {
        for (int OqOckazDq = 583264445; OqOckazDq > 0; OqOckazDq--) {
            sxIiDMyHlNYfibLN += pjLlsIWVsnUS;
            kWXoHiaTah = ! kWXoHiaTah;
            wjqNFoeIAm -= wjqNFoeIAm;
            sxIiDMyHlNYfibLN += DOpeob;
            sxIiDMyHlNYfibLN = DOpeob;
            sxIiDMyHlNYfibLN += DOpeob;
        }
    }

    return wjqNFoeIAm;
}

void NeJULGnSaxiwv::qaymP(double uQgKuhjzsR, int tomuOT, bool kfxrkUvpJLqRK)
{
    double qeXEKXaggaBwa = -645836.6352290162;
    bool EjIhhfPb = false;
    bool KjtqdcRg = false;
    string hesbXO = string("VGtGzCAJtcoNoiDmgqdQnhOUuhyZWdMTvVyoAJdSGGYQTpaQGrYifabFkIPQdcWDWEekpTKKavEvRSZfUpHbJdOOfLdWJDmDZHhlVdlbHIBiREhoUfnckFcfAeKnMCjaJmzKaymGhHynlVKpZAmZVTXaaSOhVkdgwHFKtWGezIRufmvaqMVSMnaWQqhGmyaPeFeSkxMDELoFLPjLArRqxmbScdMdZOzTZPUDiIXnwwmBk");

    for (int uVCmcAahZHPBpRCI = 1767769177; uVCmcAahZHPBpRCI > 0; uVCmcAahZHPBpRCI--) {
        tomuOT = tomuOT;
        tomuOT += tomuOT;
        KjtqdcRg = ! EjIhhfPb;
        kfxrkUvpJLqRK = KjtqdcRg;
    }

    for (int OyWOlpJZSbX = 123844991; OyWOlpJZSbX > 0; OyWOlpJZSbX--) {
        KjtqdcRg = EjIhhfPb;
    }

    for (int mymSdLjGADlxsR = 294360904; mymSdLjGADlxsR > 0; mymSdLjGADlxsR--) {
        uQgKuhjzsR /= qeXEKXaggaBwa;
    }

    for (int wmPUsIHKsuREyu = 676284817; wmPUsIHKsuREyu > 0; wmPUsIHKsuREyu--) {
        hesbXO = hesbXO;
        EjIhhfPb = EjIhhfPb;
        hesbXO += hesbXO;
        EjIhhfPb = EjIhhfPb;
        KjtqdcRg = kfxrkUvpJLqRK;
    }

    for (int XIYAuWcOkZ = 1354107497; XIYAuWcOkZ > 0; XIYAuWcOkZ--) {
        continue;
    }
}

string NeJULGnSaxiwv::mVCTYqy(bool otuXXxjJVfl, string dVbBTbZi)
{
    string oCCFHeENy = string("UzmkQDneDxPOTHDOSjVzloptAwYWgGoUbwuPiGyzuqgDmSNtzSbefhEDDCyQZUCQzBrRSfSxDxMfVv");
    double nQJHVp = 479493.3560953066;
    int FPgNXzcNRv = -306132616;
    int HpzunQNfucTW = -795459486;
    int tzhDUmgDIKtUzm = -1979109453;

    return oCCFHeENy;
}

int NeJULGnSaxiwv::twaQztDP(bool ZILhsbTUaJZClJ, int xxYysdLSkjuZXHm)
{
    bool IacKhdWkdQWuPJ = true;
    double NCnBLWdsHbjDCYJk = 74567.00697708016;
    int mJpFKURjE = 675690274;
    string WdxMRgTYB = string("bWRcLksBKZiWKyhZzWQIILCcLCgPKNhaBVEPNgyaDkheMDwhdMeClDTRoNEUDYlxfihxOzsagcRIvZVzSreaZgBCNFGEsZaRHsEsBTsvnbUmDVPgtYmSkwDHCCbSFMxfLtaTfaiaWIYwgFNqr");
    int qoeToOfu = 1140010607;

    for (int FwUXrj = 2024615912; FwUXrj > 0; FwUXrj--) {
        WdxMRgTYB += WdxMRgTYB;
        qoeToOfu -= qoeToOfu;
    }

    return qoeToOfu;
}

string NeJULGnSaxiwv::ydDzLiiSPg(int pwqCBM, string ahkUwmWgN, string qqfyuBmH)
{
    double lGPhNc = -519207.1801744489;
    int NxOBzjs = -1236199596;
    int faWEyxPhEcORRm = -1560517861;
    string RfSZAj = string("iLLqJdmTLrVJKfLuwDjCFVoeAjObltFZuJiTBHiQipPNDaMcquWKnNmBSDyFhAPAULlkwfEaPaplWLpaTCDBrKdhbIESbUAHaBthdAqNSpGhrrVwNbrRORzGNEJEheyWfNgTcLVlKficzvEbXsEUIvyYiULzKLLPxZgouUJBabLRKeNhEYeuwJbnlO");
    double lCaDtgmIj = -509922.86156666366;

    if (RfSZAj < string("sEQgmJTtshsOEEHnjZpAmZYIYqLCKlmO")) {
        for (int QwnlM = 193897134; QwnlM > 0; QwnlM--) {
            NxOBzjs -= pwqCBM;
            lGPhNc *= lGPhNc;
        }
    }

    for (int jApWDiL = 1674379138; jApWDiL > 0; jApWDiL--) {
        NxOBzjs -= pwqCBM;
        faWEyxPhEcORRm /= pwqCBM;
        faWEyxPhEcORRm *= pwqCBM;
        NxOBzjs *= pwqCBM;
        qqfyuBmH = ahkUwmWgN;
        qqfyuBmH = qqfyuBmH;
    }

    if (qqfyuBmH == string("CYbLHQUpxyyGgFmDzVTSPLKWubRcasFGFJMW")) {
        for (int NJKHrK = 169323034; NJKHrK > 0; NJKHrK--) {
            NxOBzjs /= faWEyxPhEcORRm;
            ahkUwmWgN += qqfyuBmH;
        }
    }

    if (qqfyuBmH > string("sEQgmJTtshsOEEHnjZpAmZYIYqLCKlmO")) {
        for (int eZmGaGBRDptCO = 1920099229; eZmGaGBRDptCO > 0; eZmGaGBRDptCO--) {
            continue;
        }
    }

    if (ahkUwmWgN < string("iLLqJdmTLrVJKfLuwDjCFVoeAjObltFZuJiTBHiQipPNDaMcquWKnNmBSDyFhAPAULlkwfEaPaplWLpaTCDBrKdhbIESbUAHaBthdAqNSpGhrrVwNbrRORzGNEJEheyWfNgTcLVlKficzvEbXsEUIvyYiULzKLLPxZgouUJBabLRKeNhEYeuwJbnlO")) {
        for (int fqkqLLdKjxxw = 751838044; fqkqLLdKjxxw > 0; fqkqLLdKjxxw--) {
            ahkUwmWgN = qqfyuBmH;
            NxOBzjs += pwqCBM;
            RfSZAj += ahkUwmWgN;
        }
    }

    return RfSZAj;
}

NeJULGnSaxiwv::NeJULGnSaxiwv()
{
    this->zqEXTDEmIMi(-407181.5045439739, 911095.2730842723, 890261957);
    this->mTNTVCRt(678611.1062159523, false, string("GdGtEDZRcIzyqTAXHKCqmTtLRKaBVpILQuxEosYkMCfWgorXHjbRtunaajdlATrIbWPpmmWpwVoNGzLGPWdzbaybpOkzYGjhPrhDAAPgujJXgavDEdmyphRryVETwlforGoSlFabjEKLbkrBOuvALzmpYtcWJGEryQmwmMEMhtLWrdYgOIWxeWgkPyqcPNXKBQYjwJBydoKLrcaGZqehdJNQObkbmjWnNimfoAEzvwmZbhYHVbsWrNiBgYYUPiL"));
    this->FyMenMHSxKsNcUxP(-541022.121127181, false);
    this->iZlywADptY(-928231.8993270589, false);
    this->mWCBGLpvwK(string("TYRwFRHlgsKqMJlTnAEkffBTMWiwBYxDwcyzLjqWMNjlozHBbNGbrnWPllECDMSgTJskKLhrjAkhmnILKdycfPfLRpFrGiIHSplAtjfnWNvBhxJfHvEvasCtewPpfSMcPhGbHBDZYOeYWWNwGcprXjyTOVXbBrOgSSdfZzrfMioJhcyIgrnQQhnOrZScBvUNCeHtYCDzRDrBqNUsg"), -273643.32593829057);
    this->qaymP(-478217.81447605684, -577970389, true);
    this->mVCTYqy(false, string("XWXUfkqHrKnUYRpmFXEP"));
    this->twaQztDP(false, -737225368);
    this->ydDzLiiSPg(-2009130018, string("CYbLHQUpxyyGgFmDzVTSPLKWubRcasFGFJMW"), string("sEQgmJTtshsOEEHnjZpAmZYIYqLCKlmO"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RsMuNGooRUFAvpi
{
public:
    int MatrOA;
    bool ZoSLrpKTMicSosQ;
    string pmGSVm;
    bool zHwQuVKGytcC;
    string TsvMsujtxPlNGd;
    int xpODZNyblXD;

    RsMuNGooRUFAvpi();
    int BNRtYZ(int SaQmfF, int sOyhTEYnEvnTqpj, bool CQRCSd, bool DyKCU, double HyAiLaznJ);
    double opply();
    double VcWZKdaCXpy(int ytXfuTNPfTmjv);
    int YhNdgzKSFixFi(int yfNxCuGgCyTrS, string vjyHNkRLhjkyTb, double zpxSIxJGSVM, double bEzqgiiDnp);
    string FFWWtNSZIBlNdACY(double mzFCmyylIf, int iUBLUrTlVuzorPTM, int qRmWFDs);
    double VRgwzkiUpqu(bool koONduzPGYvSLaHk, bool sbFHxdNGcNSJ, int NJuCYMhxz, double rTiqcubzVBq);
    double KVfkdzKjv(bool MYBpxsZo, double HSwav, string lmXJiR, bool odFoibrfnqB);
protected:
    double MFexFSviNTStEx;
    int NrcAawAMGFyXW;

    bool IXXuKhyAUjSon(double WjuLtJDWlwgQHXFk);
private:
    double jdvDgrXapB;
    string Ztkgto;

    string TTTnKvaC(int brpFTZXBMV, bool jsgNy, string bUPNUfOVpAdyGOCF);
    double nvQZhtPY(int KzNosGNVFWxyN, double lCGvn, int FFzkLhLVsIxm);
    string JFdJSqGMHpTyXcqa(double vWdEfoJJuX);
    int TLSMnu(string hdHrDzOJx, bool IjApjKvxAdxMpVW);
    string jtLWlbcgiwpweeg(bool xcorQlwpSBf, string PNtSvFmYQa, bool GcFQblEpdemcNB, int MWHHbOTPMa);
    int WSYDpCnsRaYtQevb(int tAwJKQtrwTvGFM, string HpJKStjDoFU, double XIXUz, int FbzHpyhLMu, string PmgHpwzfwNmN);
    bool OVQmySlHmPuHHaRg(double izuFnL, int ADSOPinthED, int zswaFWVOe, double jVyhABFUfT);
    string AIbGlVStnsRO(bool aKqfXwbFoQnMtf, double vfOlkQ, double nEzatU);
};

int RsMuNGooRUFAvpi::BNRtYZ(int SaQmfF, int sOyhTEYnEvnTqpj, bool CQRCSd, bool DyKCU, double HyAiLaznJ)
{
    bool bDJnSNxjUZHvCX = true;
    double gKuKlyjfvkq = -314450.3511667291;
    string VklALpXxNXHhhEOH = string("hIJWQZCytmWchCBMImuNBKAqiiijhJNWwwteidHTKhXGXsuYPzcaRraLSbyNouKxbDEEmMvsIgDGyDEcAIBFLPxerMaBhWXh");
    string AJQJehivwkGDRH = string("QqdmpvUYDLoqVJmgTgfBZTqtWRjsgzvQZMYpWXqIrERHNiaiuJhkPGvmkkeCkUxOjwGhoHlaWgQ");
    int OgMEpgzaWHBnXvAc = -1241533016;

    for (int HCGwDuxfdauIhdM = 1895530888; HCGwDuxfdauIhdM > 0; HCGwDuxfdauIhdM--) {
        HyAiLaznJ *= gKuKlyjfvkq;
    }

    return OgMEpgzaWHBnXvAc;
}

double RsMuNGooRUFAvpi::opply()
{
    bool MvwlWsLIDv = false;
    double JuARzUGKox = 915395.3073635197;
    string WjGsEXNkuReKsqbl = string("bmxKXTBgJXJHJSFcKpUSul");
    int mlsNDsxRs = 1619629483;
    bool FcFtdBoaID = false;
    bool LiQdjlMmCj = true;
    double cXQZo = 462289.781796236;

    if (LiQdjlMmCj != false) {
        for (int eBDjIiak = 1318557514; eBDjIiak > 0; eBDjIiak--) {
            mlsNDsxRs /= mlsNDsxRs;
            LiQdjlMmCj = ! LiQdjlMmCj;
            cXQZo += cXQZo;
        }
    }

    for (int aGGcGwWsWjARxr = 1089689550; aGGcGwWsWjARxr > 0; aGGcGwWsWjARxr--) {
        continue;
    }

    return cXQZo;
}

double RsMuNGooRUFAvpi::VcWZKdaCXpy(int ytXfuTNPfTmjv)
{
    double ODFruJiWeqKo = -555951.8881924036;
    int dndcrUmXo = -386004370;
    string xxvHhQ = string("cuWnnwVWRpdRdOUcBMfwjsdsXM");
    int zPbNAC = -855378249;
    bool jBCmJC = true;

    for (int Swwxjfe = 2003442447; Swwxjfe > 0; Swwxjfe--) {
        continue;
    }

    if (ytXfuTNPfTmjv < -386004370) {
        for (int vtTOcBvQzLnoaaC = 1482201170; vtTOcBvQzLnoaaC > 0; vtTOcBvQzLnoaaC--) {
            zPbNAC = ytXfuTNPfTmjv;
            zPbNAC /= ytXfuTNPfTmjv;
        }
    }

    return ODFruJiWeqKo;
}

int RsMuNGooRUFAvpi::YhNdgzKSFixFi(int yfNxCuGgCyTrS, string vjyHNkRLhjkyTb, double zpxSIxJGSVM, double bEzqgiiDnp)
{
    string ZPsUsDfE = string("hblTTzLcHUknIePqAuxdjUCBCPuLEMOzoDycsrZuccYfdZPvurmaSjkCXKEVImDbYUvjngqlAeVwgtQOAsAzZOAUvBcSEHmqHhhdpe");

    for (int xGoLVCySualTc = 806511109; xGoLVCySualTc > 0; xGoLVCySualTc--) {
        yfNxCuGgCyTrS = yfNxCuGgCyTrS;
        bEzqgiiDnp = bEzqgiiDnp;
    }

    for (int MNoVrHGyzbzDr = 453444035; MNoVrHGyzbzDr > 0; MNoVrHGyzbzDr--) {
        ZPsUsDfE += vjyHNkRLhjkyTb;
        zpxSIxJGSVM /= zpxSIxJGSVM;
    }

    if (yfNxCuGgCyTrS != 1873380685) {
        for (int nFIEFONgH = 934013269; nFIEFONgH > 0; nFIEFONgH--) {
            ZPsUsDfE += ZPsUsDfE;
            zpxSIxJGSVM /= bEzqgiiDnp;
            vjyHNkRLhjkyTb += ZPsUsDfE;
            yfNxCuGgCyTrS = yfNxCuGgCyTrS;
        }
    }

    for (int KKYsOaveD = 1662362245; KKYsOaveD > 0; KKYsOaveD--) {
        ZPsUsDfE = vjyHNkRLhjkyTb;
    }

    return yfNxCuGgCyTrS;
}

string RsMuNGooRUFAvpi::FFWWtNSZIBlNdACY(double mzFCmyylIf, int iUBLUrTlVuzorPTM, int qRmWFDs)
{
    bool TrEoqqqtdNSwNDGb = false;
    double vfWskQVXQpTBbwYc = -192844.5479188122;
    int PpwUa = 1961717971;
    string TqxsZDfrgdSq = string("GLznsPbFTuQxsXBcIqotIZgOlXqENnWhTWbKjaayEIcTvJTWkhJiEDMqSRTORPYClAsXJbGrOxswBCelOfBlqXCMCxcpqrpLEStTBJxzCDVYiZjLbZYbqRYNIYNHUN");
    bool ibtPQvTXEUgD = false;
    string nRzrHyJKB = string("aqFiEevrWqtTjJFzkaAfYhSiGzVbMqbKdvdGqfBMeMfPscunCMFhTXCCzMIaKyMJDitHAeCSDVSP");
    double JHwpgLIa = -698505.1681716016;

    for (int rMapbZwJAxmErQP = 1976674397; rMapbZwJAxmErQP > 0; rMapbZwJAxmErQP--) {
        continue;
    }

    for (int ZgpPTeHGkWaFasD = 1262682042; ZgpPTeHGkWaFasD > 0; ZgpPTeHGkWaFasD--) {
        mzFCmyylIf *= mzFCmyylIf;
        TrEoqqqtdNSwNDGb = ! TrEoqqqtdNSwNDGb;
    }

    for (int xvZtgJfDwbnNfl = 1936590487; xvZtgJfDwbnNfl > 0; xvZtgJfDwbnNfl--) {
        iUBLUrTlVuzorPTM = PpwUa;
        TqxsZDfrgdSq += TqxsZDfrgdSq;
    }

    for (int REpJEvzKt = 1372228369; REpJEvzKt > 0; REpJEvzKt--) {
        TqxsZDfrgdSq += nRzrHyJKB;
    }

    return nRzrHyJKB;
}

double RsMuNGooRUFAvpi::VRgwzkiUpqu(bool koONduzPGYvSLaHk, bool sbFHxdNGcNSJ, int NJuCYMhxz, double rTiqcubzVBq)
{
    bool nyTiArRBtCqa = false;
    bool pkXYLIL = true;
    bool YGrJWNJwi = true;

    for (int rWSGmIC = 1044740736; rWSGmIC > 0; rWSGmIC--) {
        pkXYLIL = koONduzPGYvSLaHk;
        pkXYLIL = pkXYLIL;
        nyTiArRBtCqa = ! nyTiArRBtCqa;
    }

    for (int wKKtDfGkq = 1511285830; wKKtDfGkq > 0; wKKtDfGkq--) {
        pkXYLIL = ! pkXYLIL;
    }

    if (YGrJWNJwi != false) {
        for (int zUJYkVDIdFPciGG = 986471410; zUJYkVDIdFPciGG > 0; zUJYkVDIdFPciGG--) {
            sbFHxdNGcNSJ = ! YGrJWNJwi;
            nyTiArRBtCqa = ! YGrJWNJwi;
            sbFHxdNGcNSJ = pkXYLIL;
            pkXYLIL = sbFHxdNGcNSJ;
            nyTiArRBtCqa = ! koONduzPGYvSLaHk;
        }
    }

    return rTiqcubzVBq;
}

double RsMuNGooRUFAvpi::KVfkdzKjv(bool MYBpxsZo, double HSwav, string lmXJiR, bool odFoibrfnqB)
{
    bool Lxuzqvo = true;
    bool jIehQosKez = false;
    string YJoldpBFtzuKJLL = string("WUiXprTbNkabLrfGvseyGMVUEagFwUyKfeHGjhjcPlaWTwxBlEHnuSHBbGKYTtFqsUbImpferdQbRlHmYxcOLDkOtNZeDHKUoklqvpOkQWXUxxUvSSrlRlenSVgvIKgSjWTtLVzMQQNwpVIMJTGDkQswgeROwOxmizeLBBgrDCzMsKOEPJdpwrqFgArvhZClhHKLQQohVRitHGorhIzDMSCpDWO");
    int CAgpuTMF = -1513434302;
    int hZAzpdllYIRTAU = -1841149147;

    if (lmXJiR > string("WUiXprTbNkabLrfGvseyGMVUEagFwUyKfeHGjhjcPlaWTwxBlEHnuSHBbGKYTtFqsUbImpferdQbRlHmYxcOLDkOtNZeDHKUoklqvpOkQWXUxxUvSSrlRlenSVgvIKgSjWTtLVzMQQNwpVIMJTGDkQswgeROwOxmizeLBBgrDCzMsKOEPJdpwrqFgArvhZClhHKLQQohVRitHGorhIzDMSCpDWO")) {
        for (int MEJSYsTIWoZh = 947903213; MEJSYsTIWoZh > 0; MEJSYsTIWoZh--) {
            MYBpxsZo = ! jIehQosKez;
            odFoibrfnqB = jIehQosKez;
            YJoldpBFtzuKJLL += lmXJiR;
        }
    }

    for (int qPHDronUG = 984653129; qPHDronUG > 0; qPHDronUG--) {
        Lxuzqvo = ! Lxuzqvo;
    }

    for (int lYIlmikZulLSF = 1287222358; lYIlmikZulLSF > 0; lYIlmikZulLSF--) {
        odFoibrfnqB = jIehQosKez;
        Lxuzqvo = ! odFoibrfnqB;
        MYBpxsZo = odFoibrfnqB;
    }

    return HSwav;
}

bool RsMuNGooRUFAvpi::IXXuKhyAUjSon(double WjuLtJDWlwgQHXFk)
{
    string RxQRQACpA = string("lTKcRFtQDikgCbxASLCmELCFjUEXtOEzZtdzAFRlfawnWlqxMIcQeAiUNGXbOiNFFaUNpmvqSijiyYMyanFmQSsAincdWNpZbGJvDFlwnKBJOoXAqGwycUNeNwChfVDuAbgGcgXyDeWOsRjTapCve");

    for (int EXBurthDVNHP = 1021933967; EXBurthDVNHP > 0; EXBurthDVNHP--) {
        RxQRQACpA += RxQRQACpA;
        WjuLtJDWlwgQHXFk += WjuLtJDWlwgQHXFk;
        RxQRQACpA = RxQRQACpA;
        WjuLtJDWlwgQHXFk -= WjuLtJDWlwgQHXFk;
    }

    for (int aEyGFA = 2032284387; aEyGFA > 0; aEyGFA--) {
        WjuLtJDWlwgQHXFk -= WjuLtJDWlwgQHXFk;
    }

    if (WjuLtJDWlwgQHXFk >= -620792.2316857008) {
        for (int YLPvz = 1732990092; YLPvz > 0; YLPvz--) {
            WjuLtJDWlwgQHXFk *= WjuLtJDWlwgQHXFk;
        }
    }

    if (RxQRQACpA <= string("lTKcRFtQDikgCbxASLCmELCFjUEXtOEzZtdzAFRlfawnWlqxMIcQeAiUNGXbOiNFFaUNpmvqSijiyYMyanFmQSsAincdWNpZbGJvDFlwnKBJOoXAqGwycUNeNwChfVDuAbgGcgXyDeWOsRjTapCve")) {
        for (int nTuuCSxYfQ = 1917182788; nTuuCSxYfQ > 0; nTuuCSxYfQ--) {
            WjuLtJDWlwgQHXFk /= WjuLtJDWlwgQHXFk;
            RxQRQACpA += RxQRQACpA;
            RxQRQACpA += RxQRQACpA;
            RxQRQACpA = RxQRQACpA;
            WjuLtJDWlwgQHXFk /= WjuLtJDWlwgQHXFk;
        }
    }

    return true;
}

string RsMuNGooRUFAvpi::TTTnKvaC(int brpFTZXBMV, bool jsgNy, string bUPNUfOVpAdyGOCF)
{
    bool pUyPHyiSOQs = true;
    double DAHYXDN = -556192.5393775819;
    double bGYOOM = 1010217.0942574543;

    for (int cJstYappYxXgmG = 701950829; cJstYappYxXgmG > 0; cJstYappYxXgmG--) {
        jsgNy = pUyPHyiSOQs;
        bGYOOM += bGYOOM;
    }

    if (pUyPHyiSOQs != true) {
        for (int qmSBpU = 1130487826; qmSBpU > 0; qmSBpU--) {
            bGYOOM *= DAHYXDN;
        }
    }

    for (int YBCYuu = 21967822; YBCYuu > 0; YBCYuu--) {
        jsgNy = jsgNy;
    }

    return bUPNUfOVpAdyGOCF;
}

double RsMuNGooRUFAvpi::nvQZhtPY(int KzNosGNVFWxyN, double lCGvn, int FFzkLhLVsIxm)
{
    bool dbZSxsiud = false;
    int PeSChzgzFYfI = -1033521300;
    string CKvECFcTubZOKMa = string("vfbbZAJjPAfEmdPaJnZZfmIpwJGjahEioAvfVcFgcALvdnBHlyKukjKuLKEVgiokRhXTQwgrYgfzvAQeaqpylTICsibORhqlwgslIXKdUWHWzzjavaGdbfTTxLvcmIBNNoLnxBUVAVqVNZkjyEgp");

    for (int dHYrKWv = 1573472044; dHYrKWv > 0; dHYrKWv--) {
        continue;
    }

    if (dbZSxsiud != false) {
        for (int pHEKiTvfTOXyfvrp = 1930397255; pHEKiTvfTOXyfvrp > 0; pHEKiTvfTOXyfvrp--) {
            FFzkLhLVsIxm *= PeSChzgzFYfI;
        }
    }

    return lCGvn;
}

string RsMuNGooRUFAvpi::JFdJSqGMHpTyXcqa(double vWdEfoJJuX)
{
    bool hVCXeWzCKPNPs = false;
    double FdHuHZGqWEMP = -690402.4482458805;
    double tbPttDbwCkNts = 595274.505357598;
    bool wNePrsoICZsJDz = false;
    bool QJXszhbnPddRJxhf = true;
    double jOjwPSDUJiW = -472302.5986856479;
    string kKVvVw = string("fdcDqfrInBgoNjRYwoxMoefwKQtiYEPTPNZbgsbvismukMiIbCsWiyLPljWzWMlHaCpAsJyhAmtZrXDcnjDDKRWH");
    double rsNvkfp = -825657.7197806109;

    for (int KqYiBGHgNJy = 1275304707; KqYiBGHgNJy > 0; KqYiBGHgNJy--) {
        FdHuHZGqWEMP -= FdHuHZGqWEMP;
        jOjwPSDUJiW += jOjwPSDUJiW;
        jOjwPSDUJiW = jOjwPSDUJiW;
        kKVvVw = kKVvVw;
        rsNvkfp *= FdHuHZGqWEMP;
        rsNvkfp += rsNvkfp;
    }

    return kKVvVw;
}

int RsMuNGooRUFAvpi::TLSMnu(string hdHrDzOJx, bool IjApjKvxAdxMpVW)
{
    string tualRskvADVd = string("vOThQQoJITKbBlePBAfPjsGnQcCfwNsITiesDrxMoQVlurSMZqJHdbcOiECSPqhhUukGbvawBNiULdfmOrpdfQrstWZIZoRWlHdnjuVFMaFgqHMmVXiKkVCgniHGMarAHMnhJMYSezBkILJJCKraaIgOzEBzqHLavTIlEaWCxPBUmJ");
    bool htmxwOcpHOic = true;
    int XgrxiWwhkYHMZjPg = -759585048;
    bool wPXKYRYy = false;
    bool OOzYfkUqPq = false;
    bool teZNRKBNYATZSYa = true;
    string JyDlqwAEpvMFeZtI = string("IlQklvjLuXYwMCpdvcyEyHgYpBNlXFOaSYexxyyJIadFRSAYmsoVafviZWgKu");
    int KqgmG = 1756126779;

    if (JyDlqwAEpvMFeZtI > string("vOThQQoJITKbBlePBAfPjsGnQcCfwNsITiesDrxMoQVlurSMZqJHdbcOiECSPqhhUukGbvawBNiULdfmOrpdfQrstWZIZoRWlHdnjuVFMaFgqHMmVXiKkVCgniHGMarAHMnhJMYSezBkILJJCKraaIgOzEBzqHLavTIlEaWCxPBUmJ")) {
        for (int BWywAA = 922193850; BWywAA > 0; BWywAA--) {
            KqgmG -= KqgmG;
            KqgmG = KqgmG;
        }
    }

    if (htmxwOcpHOic == true) {
        for (int FZSrHky = 34356762; FZSrHky > 0; FZSrHky--) {
            continue;
        }
    }

    return KqgmG;
}

string RsMuNGooRUFAvpi::jtLWlbcgiwpweeg(bool xcorQlwpSBf, string PNtSvFmYQa, bool GcFQblEpdemcNB, int MWHHbOTPMa)
{
    int HcQMoLcZkwg = -1472937561;
    string VhRikRvzEYhuIYap = string("XCPnGzCqWiJHDxcPWNcpdycvbBWCOpaLCvzquWTVtqUgLNzOqGGRhRVrQAOKppakuKyEQslxaDoTSPAMYYasRxcenoeVtveEEjffpgAkCsTUhOHdATNaGSFvWkefWlKdVWWgMeFbNLwRvWtlbtziHzCcCGXbgPGSeaZyADXsFYHqRbicY");
    bool RszkY = false;
    string AtREoE = string("PnvcXRPlQlSySkJpMoKLGmnOAvQ");

    if (HcQMoLcZkwg >= -1472937561) {
        for (int ZhUSU = 1812710401; ZhUSU > 0; ZhUSU--) {
            VhRikRvzEYhuIYap += PNtSvFmYQa;
            VhRikRvzEYhuIYap = VhRikRvzEYhuIYap;
        }
    }

    for (int JblYXrASShlrfP = 1298948305; JblYXrASShlrfP > 0; JblYXrASShlrfP--) {
        GcFQblEpdemcNB = RszkY;
    }

    for (int dFVxbPMZyVniNCoK = 361123300; dFVxbPMZyVniNCoK > 0; dFVxbPMZyVniNCoK--) {
        HcQMoLcZkwg = HcQMoLcZkwg;
        AtREoE += PNtSvFmYQa;
        GcFQblEpdemcNB = ! RszkY;
        MWHHbOTPMa *= HcQMoLcZkwg;
        MWHHbOTPMa += MWHHbOTPMa;
    }

    if (xcorQlwpSBf != false) {
        for (int tYWduTncbxIFppUn = 231080334; tYWduTncbxIFppUn > 0; tYWduTncbxIFppUn--) {
            continue;
        }
    }

    return AtREoE;
}

int RsMuNGooRUFAvpi::WSYDpCnsRaYtQevb(int tAwJKQtrwTvGFM, string HpJKStjDoFU, double XIXUz, int FbzHpyhLMu, string PmgHpwzfwNmN)
{
    bool icqPAraI = false;

    for (int TiiHZDa = 1896304527; TiiHZDa > 0; TiiHZDa--) {
        PmgHpwzfwNmN = PmgHpwzfwNmN;
    }

    for (int KSLoB = 1738399603; KSLoB > 0; KSLoB--) {
        continue;
    }

    return FbzHpyhLMu;
}

bool RsMuNGooRUFAvpi::OVQmySlHmPuHHaRg(double izuFnL, int ADSOPinthED, int zswaFWVOe, double jVyhABFUfT)
{
    bool fFKSHw = false;
    bool zqYpurKLuLLaNCVs = true;
    bool UleKMjyn = false;
    string JnsjH = string("QUnJPUBuxScgSSabfMAwmFNdBwoyBFMOgqFSysZYTONmzSlcjVzdlHUfrQtaocczeRVxjtatgFkJPFFlhJPucNbXRuhuJHAimTxqwUqnwFjozEPaVdjZOCNPkurDOpiR");
    double SIDrmd = 946076.2885995089;
    string ilSpVtUhFu = string("jwGhQgHkXRrzRZFyKvmYqCUdERrmLAcTeieMnKuaRtUnmlHipJEWIuDulYOwxjFkMtsxxLyYlBQSlNmMYlAXU");
    double JpQDxwbs = -700174.1619366421;
    bool mpypmRrEKbBIcXE = true;
    double DCWTkPDKqxMf = -1031711.8056111555;

    for (int zHhRuhJlMylNtoTk = 245013743; zHhRuhJlMylNtoTk > 0; zHhRuhJlMylNtoTk--) {
        continue;
    }

    for (int tfjQERWi = 171400783; tfjQERWi > 0; tfjQERWi--) {
        DCWTkPDKqxMf -= jVyhABFUfT;
        JpQDxwbs /= SIDrmd;
        UleKMjyn = ! UleKMjyn;
    }

    return mpypmRrEKbBIcXE;
}

string RsMuNGooRUFAvpi::AIbGlVStnsRO(bool aKqfXwbFoQnMtf, double vfOlkQ, double nEzatU)
{
    bool VMbDoH = true;
    string tKvQUrM = string("iWUKYQsGtpRVVmbANcvGxmJMUnPkgmtwavjBraExATeucRTvExcvirxmdXrGrebsAYryYkXRxWdJLsdxzpfggajaUCNekXVhCgEDuZfYVFFNkuoEAyphaCMWfXgoEPklFHIhxbdWFiJiGvxvMWfzyxcBtoNiCuycDjpaPxwjhXJuUhZrsBdaCubcCyuzxgGEXuJHHZwwwQUFmNMGxALPzxPKcTjfIxTrCUFCanbaWMEXWMXEYsE");
    int AXvWYlNbZ = 1468559875;
    bool bsmXgqeTKwRO = true;
    bool aGnFaUjbShZ = true;
    bool IRFPtQveYQLeXa = false;
    string hWfYEExDOpfbJy = string("ficVgDlbJxRxltCUUcN");
    bool TZRMUkgxIGs = true;
    string RJQBldKod = string("glxOxtuceHrAlVdDedJGwrPbMERjAmtYivyhlFrYBaFIxIGPOetZkMtcTleEaOCCZJxVbBlDVnnWFkYEJnUaeyQQvfxHCyrWrUohSUsXhpqNlQbXZCMAHMukZGJjDYykUSHwBJNcMHpETlAThJDSsinBiFghRTnOZDPcILGGJhCayohpteKiNnrjlzPnrkeTphpAPTMKqWGxdYZNbOEwmEXkWEsLzZHYlFWcSWxUwOdqdEyedYV");

    for (int kaMtxxf = 1318363800; kaMtxxf > 0; kaMtxxf--) {
        VMbDoH = aGnFaUjbShZ;
        bsmXgqeTKwRO = ! aKqfXwbFoQnMtf;
        aGnFaUjbShZ = ! bsmXgqeTKwRO;
        nEzatU *= vfOlkQ;
        aGnFaUjbShZ = aGnFaUjbShZ;
    }

    if (VMbDoH == true) {
        for (int JNCYXDthAcDm = 271391668; JNCYXDthAcDm > 0; JNCYXDthAcDm--) {
            nEzatU *= nEzatU;
            AXvWYlNbZ -= AXvWYlNbZ;
            TZRMUkgxIGs = aKqfXwbFoQnMtf;
        }
    }

    for (int IFEonOL = 1393780170; IFEonOL > 0; IFEonOL--) {
        continue;
    }

    for (int sjzbhgIblIveJ = 1130634017; sjzbhgIblIveJ > 0; sjzbhgIblIveJ--) {
        hWfYEExDOpfbJy = RJQBldKod;
    }

    return RJQBldKod;
}

RsMuNGooRUFAvpi::RsMuNGooRUFAvpi()
{
    this->BNRtYZ(-820790480, 55435447, true, true, -165940.19899444247);
    this->opply();
    this->VcWZKdaCXpy(-1703072561);
    this->YhNdgzKSFixFi(1873380685, string("GsJEYQNCFRjYENyyjGwXwZMVOwzPHdJFliGwZgquIeVjMlUQgnbZwGskSzZkFPbBEeKAnHbkogDcjOghUUVsnwCKeoxPvqqICaoCPYAlJvXeaqlnaExuQhazgYTBZZRCFbmWxrUKAwuHOMyCMSbeiHBucYzsfDkXRaJNIDvWuInvCTBoToMJSKBrRcGwHiCZNwPQCEqhSwnJwLUPpjQJbqLkbsoXoflZkSIFEmr"), -986370.8940769746, 741580.7364990851);
    this->FFWWtNSZIBlNdACY(-713975.0072742605, 2052396927, 62925434);
    this->VRgwzkiUpqu(true, false, 1437952578, 550809.3828499231);
    this->KVfkdzKjv(false, -628039.8892378705, string("RAfoQnGKSbrXahvxnUmAPFZItKkRLOHYfeZpSFhTGzACVIxgPxuYwfNdhGRdjIeTXTwbzYjLysvdVmUiBYhaeFhDILcivjzETwxIcGgBqDtGWfXwxZkBFIkOZliQKCBEKyuRdDkGJqGMXgrkVrwUrxDRlAFldxvD"), true);
    this->IXXuKhyAUjSon(-620792.2316857008);
    this->TTTnKvaC(726650154, false, string("YHrkXITLHazqQvtOsvttjcwccqziaOkAKKOYHFw"));
    this->nvQZhtPY(136703010, 990749.829789466, 1506977321);
    this->JFdJSqGMHpTyXcqa(721944.5117678463);
    this->TLSMnu(string("tiRTMcLPtAIMGWLNojPywQlHlyCzdPtrZqWhvltuIzoSnrchgnBaaaSMVlKOjlSTLFXztPXjjYpMsjNiletDrgrWGOgNZeuaHarPXLQtnUClykXVkaTPCfvadeBFzEONcrZbKBnLMeUplcFZsjVcHWSQqIUQLlfkZMgfpScpHBGGLYEpSMHIodEaLdkmyvdiBIJGpPcsfsKjFRZPZuvAYakpvoxrBnXAZkXRthxuoxDljMHm"), true);
    this->jtLWlbcgiwpweeg(true, string("mEkaAcYCaUfNYiueSvJdDqrAVvakYbVIaTpTniWxUazHGjEfPpCMLAaZiWXRFGnskdKiMZuclbBIwiyOPvOnGaAUUpbTHUhcxcEUzwebRQDvLxrKDmxgPCLbgneFsSAMYMDBhmmRSWyDtfHMHgJhQLMjpWOpiEjoqbqrPAFLENTCBKIvpLhizxSpNurIJYIDvQaNDLxiHGABI"), false, 82580954);
    this->WSYDpCnsRaYtQevb(-2045962691, string("CPlaEWArVMNjqFuMoiUrulqlvIiPSnDwpXfUTVSHURGFaYoTdwCxydtgYtJNlVPoSmHIUSoByUDalKMgMiJzSBjGKjsLsqATgtnxPpwjZZxKDOiJArTZxFlP"), 442869.83878965175, 2080028061, string("VhLCbMjRVmOzoVyRYKmiVwpVoNWzoTPOKoRsIFrAmXlNzBifZKPQBQzFJliLdkFuETJEAhiwNzQICgWdLsRkkzfOAbgDEebsGxuepGhhSbkXCVvgEEnkkLaNYwWqmxMwhdlLnnfpIkRnmqkSrQDqpbLYgVzaMkoRfZPdFdBzcsrFHiINTGaiIKpXbHwGdVGvNLmCpbQqXyoCkQyknquCWpChEEKdfQcjMxVVaXImGCYHUVPpDaGTM"));
    this->OVQmySlHmPuHHaRg(-786027.7731879591, 1381741224, -490450911, 522263.01380735595);
    this->AIbGlVStnsRO(true, -459118.5673604091, 548294.6151586603);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GqRFoC
{
public:
    bool yyeVKNsQnLsS;
    int XFXaLAZby;
    int oQMUxFAXN;
    bool MfnlqhlrxxD;
    int xJSTZNzqwkP;
    bool BplKW;

    GqRFoC();
    void mWexTFV(int OWDscLsYsDFpftQ, string zCIrN, bool KycOUIHSedLmZWjL, double FHEADgRIeAPz);
protected:
    bool PnOKzKevgbBhXegA;
    int XWmCtxBbBNSsdjf;
    string fyktNafVwiVOn;
    int AwCaFHzgmDUrcItY;
    string cmYcfaExqKP;

    void hcwAFKTbMlGRICy(bool NkFQzA, double peMdelccKnIB, double aDpnA, int MmYYbpPiikc, int JgNKxY);
    double StIusecyPQzXc(double OSyvDMg);
    double HBSlTcwHyZ(string iOBnXZPVtvJeIMq, int ZtOtsryPTgFacJ);
    bool xyKdCXPPjIpGdFnG();
private:
    double sRnaCKBhODJFEPad;

};

void GqRFoC::mWexTFV(int OWDscLsYsDFpftQ, string zCIrN, bool KycOUIHSedLmZWjL, double FHEADgRIeAPz)
{
    string DfUxiR = string("nIJYGrXeAFUmFcNccOxmrUjoFnFTyLaXOtaucxacTGjdkiBamrXqaahBGchbZvPagVVDwjkLFzCdOLwBIrxTgnJXNsbKFQhCXDXQFdwZmSRukcsgWbvJCGzarNjgKaKJtMKSTrnvaOcPDxuwDwkxNNPdvqzHZxmqcucdkSPrAarFWwVVtezQXOziKkHoctegFLFKJWlzrPZEJlrmdXzSVa");
    string nJCTElBfhGD = string("MbApaavaqmxUQVwSnoBJRqQMLWEBRwvrcQhEjFOqVyGyqYXFBhLpDurvCGsRgUoZzWPdHtDZnEEPbqMplHDeQJFklrRbeScYfdcFluRupPnDQVEEsjhdDiRVFknlOaKHjHlgWQyesEmjUkJhKbFwdVHcHzxAgNmEXPUfANbvoeignnhkDmglrtDWMMXJpgaayVQoPVyHIykAGtgSNeGdDaeQuGwGVDFunUqnLEZqoAdtCeIgRWOBLYgRqBYRp");
    double HyVKWgQtoTlu = -807593.7892600661;

    for (int rXBrIfeIWPDm = 1578988194; rXBrIfeIWPDm > 0; rXBrIfeIWPDm--) {
        OWDscLsYsDFpftQ = OWDscLsYsDFpftQ;
    }

    for (int NKasWTnxEUbGx = 269210251; NKasWTnxEUbGx > 0; NKasWTnxEUbGx--) {
        DfUxiR += nJCTElBfhGD;
        DfUxiR += nJCTElBfhGD;
        nJCTElBfhGD += nJCTElBfhGD;
    }

    for (int URBuVYapvqKkySb = 1211832100; URBuVYapvqKkySb > 0; URBuVYapvqKkySb--) {
        FHEADgRIeAPz *= HyVKWgQtoTlu;
        nJCTElBfhGD = nJCTElBfhGD;
        DfUxiR = nJCTElBfhGD;
        zCIrN += zCIrN;
        DfUxiR += DfUxiR;
    }
}

void GqRFoC::hcwAFKTbMlGRICy(bool NkFQzA, double peMdelccKnIB, double aDpnA, int MmYYbpPiikc, int JgNKxY)
{
    int wMaLPFQe = -1673981752;
    string oNDeqaXWP = string("EzHCNjbZGaXbIpQHMSiutBSAigKFqBaw");
    bool FLZeV = false;
    int CFFZEOGELuRE = 1958700345;
    int mdwST = 235371854;
    double zYbRIrHVr = 703692.9693069893;

    for (int EiLSH = 641342358; EiLSH > 0; EiLSH--) {
        continue;
    }

    for (int aRuHTEeIroqOtCCY = 659628914; aRuHTEeIroqOtCCY > 0; aRuHTEeIroqOtCCY--) {
        CFFZEOGELuRE *= MmYYbpPiikc;
        mdwST *= MmYYbpPiikc;
        wMaLPFQe /= wMaLPFQe;
    }

    for (int BearSpchfzOMxOc = 1206579294; BearSpchfzOMxOc > 0; BearSpchfzOMxOc--) {
        peMdelccKnIB += aDpnA;
    }

    if (CFFZEOGELuRE > -1673981752) {
        for (int zGYHpOGYZcCs = 708427020; zGYHpOGYZcCs > 0; zGYHpOGYZcCs--) {
            continue;
        }
    }

    for (int iIUFI = 1988015111; iIUFI > 0; iIUFI--) {
        wMaLPFQe -= CFFZEOGELuRE;
        wMaLPFQe = wMaLPFQe;
    }

    for (int pHhliXgnmPpE = 2041904399; pHhliXgnmPpE > 0; pHhliXgnmPpE--) {
        wMaLPFQe /= MmYYbpPiikc;
        wMaLPFQe -= MmYYbpPiikc;
        JgNKxY *= mdwST;
        JgNKxY *= MmYYbpPiikc;
    }

    if (zYbRIrHVr <= 498914.366479064) {
        for (int uKXaSEetjwQ = 1069891968; uKXaSEetjwQ > 0; uKXaSEetjwQ--) {
            CFFZEOGELuRE -= CFFZEOGELuRE;
            JgNKxY /= MmYYbpPiikc;
        }
    }

    for (int SkMGxCsGPGrtsM = 659228348; SkMGxCsGPGrtsM > 0; SkMGxCsGPGrtsM--) {
        aDpnA /= peMdelccKnIB;
        MmYYbpPiikc -= JgNKxY;
    }
}

double GqRFoC::StIusecyPQzXc(double OSyvDMg)
{
    string zgnKtrCXhBDVYX = string("PXvDbHOZUaPWlJUecbHltcVcESCLAtooNefdGBKVnLkRTUmswgGiuqVXFZTpQThMBwOmqoNqnOfarvoAmqZOxjmyMWJddayxmvfSzUgtnXFRNyaiHgsMEAWTmfgTLpwJiulegIrBxMvqEhEKSPiiGkGxOyaFiAyGnRbXMIiZGDKQp");
    int wqZaUDQuznTRkVZ = -15244106;
    int vyhIXbCFTQcNQF = 2049230253;
    bool gmpspAgtam = false;
    string DHDTQCtb = string("lxMMEBkGPGuFJOTIFhExyMlXYDNScHIJSVDATjamNKJIScZharCkgoYLXLJHhFEbKLEaegMhiLGcGBrvQEiElYhrGIsPbgQJWiLMKAduwpLQKzJhGhsVtwkBmUcwdzPrhwmFciTHNTXBlPefVDfVFDRDRqFjnGhljRYEFMEquTwCidDcoEHKqdqNRbDcwklVuzzQFRPDooWaYJxOdgHoefSLcpXfaL");
    int jznLATvLmwvGNZJg = -1096443011;
    string ejCIirWCWAPjFQ = string("fIuGHysMRmShHBsSIqwDRrIlEWMXtPvGSJeMyxpRghJpoUTVydsHKEGOEuDObXnSBMXSvWYUmuchFfKImqsbuBGVkPkDIFLJLRUQGeDZkzXSxMWhZqJxoyHFrXbvuQLZoqQseNaBywJFWuasIUfschXekHgSCIWpQHXuOgrYosrxomfmrrNgkZuHyZIqZCpewMXaTEjIGVxHvBfiKbtBeeNeHKCVGgUjteEq");
    double UeSmBwSNQpWh = -626253.7646369576;
    bool YxZgtLomvBChF = true;
    double PraFOUTwwt = -326427.968311968;

    for (int vEeCLZZCkC = 74403457; vEeCLZZCkC > 0; vEeCLZZCkC--) {
        PraFOUTwwt *= PraFOUTwwt;
        vyhIXbCFTQcNQF += jznLATvLmwvGNZJg;
    }

    for (int BRqBITTLYrxLpSd = 1921543336; BRqBITTLYrxLpSd > 0; BRqBITTLYrxLpSd--) {
        DHDTQCtb = DHDTQCtb;
        OSyvDMg -= PraFOUTwwt;
        PraFOUTwwt *= UeSmBwSNQpWh;
        ejCIirWCWAPjFQ = ejCIirWCWAPjFQ;
    }

    for (int qqiNVyNHdW = 586166071; qqiNVyNHdW > 0; qqiNVyNHdW--) {
        continue;
    }

    return PraFOUTwwt;
}

double GqRFoC::HBSlTcwHyZ(string iOBnXZPVtvJeIMq, int ZtOtsryPTgFacJ)
{
    double EyxxAiXl = -856512.8552430982;
    int QCRgTMe = 1630862937;

    return EyxxAiXl;
}

bool GqRFoC::xyKdCXPPjIpGdFnG()
{
    bool ngMgUuUObQI = false;
    string ErBEPfhMAHi = string("RkIuwSi");
    double IpCGAM = -13191.459448099227;
    string wPRKIxrqvd = string("FvEzomcLzTwZnqEYBdFgaMwlqCCYMMYawqIOhAMmLexDLfYzeZxVQPVtibYkpZOFrMtoFaXIYtMvYyTgBaOvyRWVEttxgiHQWmLltzsVfdMxZSuVtbNaKlSuyioJbSOVhzDVrlyVjoa");
    int fIXJMedM = 1388380777;
    string oYZGFjiVqKtR = string("pvnqQdgLKQXyGfNyWFooSuawjzsGEIQyBmGojITkWhqfBlvAkYddXoDTcYFzwLhOhQigCOnqprqOnMUGzioALdMoiQaGLziAWVAOaWejgYcGWFSvuzJeTLyfWywSgfsUyYhMsJXfZdPJvyBUdUFRyPTeIrvtjIuVFmWgTZLCbsfEeIMFMpyXOiOd");
    bool iVxOLTiNdoAM = false;

    for (int YxeclPpuNe = 1137092167; YxeclPpuNe > 0; YxeclPpuNe--) {
        oYZGFjiVqKtR += wPRKIxrqvd;
    }

    if (oYZGFjiVqKtR >= string("FvEzomcLzTwZnqEYBdFgaMwlqCCYMMYawqIOhAMmLexDLfYzeZxVQPVtibYkpZOFrMtoFaXIYtMvYyTgBaOvyRWVEttxgiHQWmLltzsVfdMxZSuVtbNaKlSuyioJbSOVhzDVrlyVjoa")) {
        for (int pVRdjPM = 1177354500; pVRdjPM > 0; pVRdjPM--) {
            IpCGAM -= IpCGAM;
            iVxOLTiNdoAM = ! ngMgUuUObQI;
            iVxOLTiNdoAM = ! iVxOLTiNdoAM;
            ngMgUuUObQI = ngMgUuUObQI;
            ngMgUuUObQI = ngMgUuUObQI;
            IpCGAM = IpCGAM;
            wPRKIxrqvd = wPRKIxrqvd;
        }
    }

    for (int JNBcJwCvMkh = 890677282; JNBcJwCvMkh > 0; JNBcJwCvMkh--) {
        continue;
    }

    return iVxOLTiNdoAM;
}

GqRFoC::GqRFoC()
{
    this->mWexTFV(-1335383000, string("jsTuGgzZynpxMytyBDjurXFBqjOawtseUysIznK"), true, 507072.06937315693);
    this->hcwAFKTbMlGRICy(false, -719237.6982409639, 498914.366479064, 780938956, -193786697);
    this->StIusecyPQzXc(847415.0685238627);
    this->HBSlTcwHyZ(string("QjSJZHRRnhPHiHNLsAbyPGAcmblDlxFZQLJwFlRaVuXhtyqjhbohnCClVjFpkzZOKMqohBRhAYkfxuxJrfiydnitEGtPb"), -2107172357);
    this->xyKdCXPPjIpGdFnG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NIzdwiRDeTtgTio
{
public:
    int gTdzKQTaPSyn;
    double WwFDHuLyw;
    int ixAoaRkT;

    NIzdwiRDeTtgTio();
    string iCqCVxC();
    bool TdspYATouAVKZpVD(double zJiqmfUByEcCx, string wmuJOwKnVW, int crlYqq);
    void ZCKenYRLLSvpKsq(int xQDbelhMyGL, int ADKeGIZQxsqH, double HGyqByWGXckjoE);
    int UlrRhfd(bool HggmlCZTBWa);
    void coLvOvB(double MZSJQlMqzcZKKL, string wtFnPmk);
    string pxXtsHrxJwrWF(string EfYiHYGNTjlqie, double yNndasa, bool aRwWwzRybGtFT, double teiXzopgoaShdFE);
protected:
    int hZdlmU;
    int jdjxexb;
    double JclejCNIXPeHDK;
    double rHFSFqddomPdWkQ;
    double AqhyqlIY;

    void SeSoWBmJZWcFc(int jQgUP, string hlZehN, int FXLyNIpFf);
    double qdjqYgt(bool IIkfc, bool mAbWkaiLPQ, int gsZQkezqKys, string nfTPwakOLNAUMn);
    bool DEczPlZY(bool EcppxkxNtCTgz);
    int WsMFZccYXIJwZuMY(bool SLRDmiojsPsZa, bool dSpJEoWXzpi, string WKaahuFmrQEzxu, string wUaqeXCcMF, int aNNNXXHpU);
    double GVydWXdMuBJDOmT();
    string PMgNE(bool QQriQjMxhrpjAjEW, bool qvknAUHMwaWha, bool vqpPmtNnzIsLsJ);
    string UMaLOxi(string mduSbxCkd, int XlgwCAf, int lXDiQXsBhmvYgl);
    bool MycITXdaXlrQfX(bool hMeiVa, string ISnYbHIzbOGzH, int UoymOOwmUvoEfzBW, bool mOqvklwVtOpvBX, bool unTUUqmYAe);
private:
    double UOXZOmCqvVrD;
    bool BHLtAzbLkMWJ;
    int dJXvdNSo;

    void DCgceMkWX(double tJOTdUfvOfgZEA, bool HcnQr, bool TnZygHmyCJwDaJ);
    bool uNVwvaTgaOwUGR(string EyMyCsNtYEkp, int twbNckauwInaLUvB, string AgyLvDAUgM);
    bool HSOahxbqPY(double XXwxTZstjYLu, bool rDFobY, int PKvQYxcYNbX, double baBPSrjKKx, string foMHPnVyHJ);
};

string NIzdwiRDeTtgTio::iCqCVxC()
{
    double XmQubSh = 278037.7140795796;
    double VFqrC = 197821.85509338565;
    int lGGFx = -437671059;
    string QDRKEtfOqJP = string("vdeitdxhmWzlrwgclIvCyQJzyGNwTqccOBvYGvgvgdfkOZGHvIiVzHOLXKwxaAbLLefPHaAvfam");
    int JDgjYPr = -651032954;
    int RdiENuJcpZGUJO = 1134144726;

    if (VFqrC > 278037.7140795796) {
        for (int OczxzgkHrXJsYk = 2097269772; OczxzgkHrXJsYk > 0; OczxzgkHrXJsYk--) {
            RdiENuJcpZGUJO *= RdiENuJcpZGUJO;
            RdiENuJcpZGUJO *= JDgjYPr;
        }
    }

    if (RdiENuJcpZGUJO < -651032954) {
        for (int SVltJESzVChVU = 475138239; SVltJESzVChVU > 0; SVltJESzVChVU--) {
            XmQubSh /= VFqrC;
            RdiENuJcpZGUJO /= JDgjYPr;
        }
    }

    for (int TIgXb = 682220563; TIgXb > 0; TIgXb--) {
        VFqrC += VFqrC;
    }

    return QDRKEtfOqJP;
}

bool NIzdwiRDeTtgTio::TdspYATouAVKZpVD(double zJiqmfUByEcCx, string wmuJOwKnVW, int crlYqq)
{
    string mpTxWa = string("YOpzvqriqPtfybZxQfEdFAtrSmhGOtIRixarYnYyucYiowkebeqmtSjEdYBZlnSmfqzsDOEVZBImSrZthXOItmFLFuMjNMxxaBkqlgOXCYViuFspAWifKCIbbhHzKdjiRYIgLuytltRWgMCEahKEtLUPsLqmdyVZckxxzLS");
    bool tngoR = false;
    double SIuWdAypwJlG = -437378.552309889;
    bool sghSJiPpCVhoczEJ = false;
    int BUjYbvyljYSo = -807380823;
    string eNSjJlRbqas = string("UIuSNDuYXeolzyBppHDdmVHAlKqWOQBWZkDSbSqJHIlSbjiIZXVaSaNMsUIeFXqIBEPrLQA");
    string EuFgnfjkegoytmLd = string("lxQeCigLbJxhiCjCYoUeupCjtsm");
    double DGqFPWQLYCfOPeq = -745768.3091447896;

    for (int fKZfbzNbIQao = 1942816214; fKZfbzNbIQao > 0; fKZfbzNbIQao--) {
        mpTxWa += eNSjJlRbqas;
    }

    for (int BpUArAyeLam = 639401734; BpUArAyeLam > 0; BpUArAyeLam--) {
        continue;
    }

    return sghSJiPpCVhoczEJ;
}

void NIzdwiRDeTtgTio::ZCKenYRLLSvpKsq(int xQDbelhMyGL, int ADKeGIZQxsqH, double HGyqByWGXckjoE)
{
    int UxgUZaHD = -295964441;
    bool fmUoBPWHM = true;
    string OkYYTOrx = string("BVBhABHokhaOqq");
    bool jkYaoqthzAQqnOW = true;

    for (int YLVzorzcTlXj = 738384399; YLVzorzcTlXj > 0; YLVzorzcTlXj--) {
        UxgUZaHD = ADKeGIZQxsqH;
    }

    for (int ubXZEtMNm = 1504150476; ubXZEtMNm > 0; ubXZEtMNm--) {
        HGyqByWGXckjoE += HGyqByWGXckjoE;
        jkYaoqthzAQqnOW = ! fmUoBPWHM;
        jkYaoqthzAQqnOW = ! jkYaoqthzAQqnOW;
    }
}

int NIzdwiRDeTtgTio::UlrRhfd(bool HggmlCZTBWa)
{
    string HtbUeeOoiAd = string("wGpjSouxkjUZbaprxZzFoC");

    if (HtbUeeOoiAd < string("wGpjSouxkjUZbaprxZzFoC")) {
        for (int PpWblfuWPcvbBZ = 419088543; PpWblfuWPcvbBZ > 0; PpWblfuWPcvbBZ--) {
            HtbUeeOoiAd = HtbUeeOoiAd;
            HtbUeeOoiAd += HtbUeeOoiAd;
            HtbUeeOoiAd = HtbUeeOoiAd;
            HtbUeeOoiAd = HtbUeeOoiAd;
        }
    }

    for (int LlEnnAmPqty = 1789378933; LlEnnAmPqty > 0; LlEnnAmPqty--) {
        HtbUeeOoiAd += HtbUeeOoiAd;
        HggmlCZTBWa = ! HggmlCZTBWa;
        HggmlCZTBWa = HggmlCZTBWa;
        HtbUeeOoiAd += HtbUeeOoiAd;
        HggmlCZTBWa = ! HggmlCZTBWa;
    }

    if (HggmlCZTBWa == true) {
        for (int KOqfdRTE = 521240397; KOqfdRTE > 0; KOqfdRTE--) {
            continue;
        }
    }

    if (HtbUeeOoiAd == string("wGpjSouxkjUZbaprxZzFoC")) {
        for (int STOsUkQE = 1175094856; STOsUkQE > 0; STOsUkQE--) {
            HggmlCZTBWa = HggmlCZTBWa;
            HtbUeeOoiAd += HtbUeeOoiAd;
            HtbUeeOoiAd += HtbUeeOoiAd;
        }
    }

    if (HtbUeeOoiAd != string("wGpjSouxkjUZbaprxZzFoC")) {
        for (int gFDSi = 112368321; gFDSi > 0; gFDSi--) {
            HtbUeeOoiAd += HtbUeeOoiAd;
            HtbUeeOoiAd += HtbUeeOoiAd;
            HggmlCZTBWa = ! HggmlCZTBWa;
            HtbUeeOoiAd = HtbUeeOoiAd;
        }
    }

    return 883495031;
}

void NIzdwiRDeTtgTio::coLvOvB(double MZSJQlMqzcZKKL, string wtFnPmk)
{
    bool UzRLjuIx = false;
    int iqNQJaCKXHf = 1663573758;
    string SFLGyNlRdqFDb = string("ciLOCedjwYENxcYMibahyOeriiBnxKrfOhidlnjO");
    int iLvpmlOVK = -1099332799;
}

string NIzdwiRDeTtgTio::pxXtsHrxJwrWF(string EfYiHYGNTjlqie, double yNndasa, bool aRwWwzRybGtFT, double teiXzopgoaShdFE)
{
    double wAnHBHkqMueha = -158704.83203045072;
    bool FJbjNBZzarQx = true;
    double YikxIRQYPcbOs = 740716.151121711;
    bool HwIufYBSeTooVm = true;
    double CkTjYDvonhQJv = -59733.705147053144;
    int GQDhZ = 433113567;
    double eAXrTmfOsfDjXZDv = -677667.9705193478;
    string RziCWJeZrUMsp = string("aLOqFjsoHJjMcnITjysdHfBhukLnAMutXIrREeqTcnrAuoOCFmKkmOybgQFLZ");

    for (int BAhyv = 226096874; BAhyv > 0; BAhyv--) {
        FJbjNBZzarQx = aRwWwzRybGtFT;
        yNndasa += yNndasa;
    }

    for (int wblztx = 509992615; wblztx > 0; wblztx--) {
        wAnHBHkqMueha = teiXzopgoaShdFE;
        YikxIRQYPcbOs += teiXzopgoaShdFE;
    }

    for (int abPkbCzGwqmRa = 1726563992; abPkbCzGwqmRa > 0; abPkbCzGwqmRa--) {
        wAnHBHkqMueha += teiXzopgoaShdFE;
    }

    for (int CCFkX = 580613855; CCFkX > 0; CCFkX--) {
        eAXrTmfOsfDjXZDv = CkTjYDvonhQJv;
        eAXrTmfOsfDjXZDv -= eAXrTmfOsfDjXZDv;
    }

    return RziCWJeZrUMsp;
}

void NIzdwiRDeTtgTio::SeSoWBmJZWcFc(int jQgUP, string hlZehN, int FXLyNIpFf)
{
    double qFKjQuVo = -541826.8943405374;
    double DATfSPoEQryDsc = 485517.6712265928;
    bool NKPzsge = true;
    int jyGWxlskSEE = 2046962850;
    bool zbxhGDgq = true;
    double TMctFW = 779756.1072241444;

    for (int dwIfMsMMdtqDm = 235263759; dwIfMsMMdtqDm > 0; dwIfMsMMdtqDm--) {
        FXLyNIpFf = FXLyNIpFf;
        jQgUP *= jyGWxlskSEE;
    }

    for (int zkgVOOyvgrGInT = 847141847; zkgVOOyvgrGInT > 0; zkgVOOyvgrGInT--) {
        DATfSPoEQryDsc += qFKjQuVo;
        FXLyNIpFf *= jyGWxlskSEE;
        zbxhGDgq = zbxhGDgq;
        qFKjQuVo -= TMctFW;
    }

    if (NKPzsge != true) {
        for (int ssiGpaTfT = 2023003019; ssiGpaTfT > 0; ssiGpaTfT--) {
            continue;
        }
    }

    if (jyGWxlskSEE == 2046962850) {
        for (int fZzCQxuqP = 184988591; fZzCQxuqP > 0; fZzCQxuqP--) {
            FXLyNIpFf *= FXLyNIpFf;
        }
    }
}

double NIzdwiRDeTtgTio::qdjqYgt(bool IIkfc, bool mAbWkaiLPQ, int gsZQkezqKys, string nfTPwakOLNAUMn)
{
    bool BnYxYgeeNrFhgvNd = true;
    bool wPLAYFiWcPb = true;
    double RsNZbhylT = 428953.55493801436;

    return RsNZbhylT;
}

bool NIzdwiRDeTtgTio::DEczPlZY(bool EcppxkxNtCTgz)
{
    string tXRVoxPjful = string("EaPhsWyghWoaoIyNEQHweEyIJQuVmEABSHyXqItrCTQTsIIylCoBMeKcgObLpYmhvQrLzqrAQVNoEDNJcRIawRgQAwaMasMomkkdjthWSbiMuVMaFmPYUxEgcIDHWvMxwwSRXQEjLVuqqzVPQNhubYaSDXvoVLiyieIuaT");
    int wAYqstihtUrwD = 1476813573;
    int aWfUH = 1207689432;
    int uOzpiu = -1586619437;
    bool hMXazA = false;
    bool QzSTh = false;

    return QzSTh;
}

int NIzdwiRDeTtgTio::WsMFZccYXIJwZuMY(bool SLRDmiojsPsZa, bool dSpJEoWXzpi, string WKaahuFmrQEzxu, string wUaqeXCcMF, int aNNNXXHpU)
{
    bool eDKzvOSO = false;
    bool bFFFyUe = true;
    double OzLWtErJxtarVDCA = -864591.412238888;
    int tSPdduGGzm = -1835160989;
    double mVTKxmzdfGkPap = 656481.2656713859;

    if (dSpJEoWXzpi == false) {
        for (int uovsGckDTPMwrh = 1266762044; uovsGckDTPMwrh > 0; uovsGckDTPMwrh--) {
            mVTKxmzdfGkPap = mVTKxmzdfGkPap;
        }
    }

    return tSPdduGGzm;
}

double NIzdwiRDeTtgTio::GVydWXdMuBJDOmT()
{
    int ghmBZgxUs = -1376677528;
    int pYvDEyKiOvqIC = -648900536;
    int cARlffVUCaLWcRlh = -1455711904;
    int fjwDEI = 1518028472;
    string brsuVmQnNDZKR = string("GBMRtFUFFZAKCrouPcKPXsQfYfhxPnPXvldGQnCvBIHDBcRUrfhLpzIjiIcxYUoPdzbqhHydcwzxLyEbDtfh");
    int XYFVVYGIa = 1205195616;
    double aKjKsRb = -162409.6709296232;

    return aKjKsRb;
}

string NIzdwiRDeTtgTio::PMgNE(bool QQriQjMxhrpjAjEW, bool qvknAUHMwaWha, bool vqpPmtNnzIsLsJ)
{
    double AXvGWuiXT = 781557.788744832;
    string dARIVbGWjiBjUFpz = string("APIQqmQIZGxaPckYHNWytDbqtTtogfbEjBrzjpGvpRkwPoYyySHIlupmvqdlwdhbqIBnOvSNaHNBHfRStCeRkbwgcEAAEHBKSLYiTYQSNKVNrdllszqAsYOGxTWYTwRfCwTWXEHkKMwxaqiUTPlcnG");
    string maJLauwVmqYYjTu = string("KmVSPldSnPNtFdWCUDUoEhEyiyutDPOHYGYwkiyGSSYWBfupNWgvBcpWvfgTCIxGfbPMgVNSqsdOjfdZlaOivwZMITwnXvUaVfNNMeTrnPIAcvVnxueIBknYFPMeQwaeRmCjbqwqbaVFybJiUDmeTMiyjQkDpFzJqr");
    double gtyRxed = -783234.577331358;
    string QMRkGNnSglf = string("ADYByBaGtKilxmtwBJzjIVopJeAEPHELOlvunqXnluEBmmBlqDhngIEiQGtMwuzZAyEkcwWeNHQnOdRhpquKVnVHWkrZJvWvRcYMerMolMSPzOBnQxBFZtHSvTXNhZeTEXLySJdjrkPeYRoFASygxmtKQsmtbpsCEYKKdYinTQqLCqxTcTDqIJkMNaYsJquBmgIUomlUyLAWsBDJZiLcqIM");
    bool KMGRYhVkW = false;
    bool QCXeAlAQ = true;

    for (int gRpjGGxZkJRrxxx = 513876259; gRpjGGxZkJRrxxx > 0; gRpjGGxZkJRrxxx--) {
        vqpPmtNnzIsLsJ = vqpPmtNnzIsLsJ;
    }

    return QMRkGNnSglf;
}

string NIzdwiRDeTtgTio::UMaLOxi(string mduSbxCkd, int XlgwCAf, int lXDiQXsBhmvYgl)
{
    double vmpupLeccqxxiQE = -703891.4165104738;
    string angryjbgNtuxxhV = string("tBTzjcbSIfJxiuxtrRoICZpjojASdnetIXYDmVDNomVapdygTWZwmyAxmbYXSWTIiwUjRCIIYmJEkwuegttgZgTHYppnIxBPkWUquDlXOBFEkvqojWO");
    bool TGdBkTk = true;
    double zboMfaVdCgx = -152926.22425207985;
    bool DsnKAuacFwmE = true;
    bool OtXUvU = false;

    for (int GGEJRFkJknJRr = 940848878; GGEJRFkJknJRr > 0; GGEJRFkJknJRr--) {
        TGdBkTk = TGdBkTk;
    }

    if (DsnKAuacFwmE != true) {
        for (int PFSZBlRZlJt = 2029793211; PFSZBlRZlJt > 0; PFSZBlRZlJt--) {
            OtXUvU = TGdBkTk;
            vmpupLeccqxxiQE /= vmpupLeccqxxiQE;
            lXDiQXsBhmvYgl = lXDiQXsBhmvYgl;
            vmpupLeccqxxiQE *= vmpupLeccqxxiQE;
        }
    }

    for (int fpaxrkJdsYMH = 1828008364; fpaxrkJdsYMH > 0; fpaxrkJdsYMH--) {
        angryjbgNtuxxhV += mduSbxCkd;
        OtXUvU = DsnKAuacFwmE;
        lXDiQXsBhmvYgl -= lXDiQXsBhmvYgl;
    }

    return angryjbgNtuxxhV;
}

bool NIzdwiRDeTtgTio::MycITXdaXlrQfX(bool hMeiVa, string ISnYbHIzbOGzH, int UoymOOwmUvoEfzBW, bool mOqvklwVtOpvBX, bool unTUUqmYAe)
{
    double PueLahyWc = -793163.2677196576;
    int qIMzW = 1126243588;
    string UmcKjVb = string("TssnfleWDIbENgixFgOxQRlHkWoPftlRApxRiWYSnKTtdufYtpQJTVrAOTOSuXpvksFvXWBeRsUfrPBnpHTkBuGRTguBMWGHUzIKJkyBibJjfhMsnYmTXdEMgEoEPLjQKMQLoOJLQPtYxunJrXoglxIBoHhezwoQnZJneOmZAtJrzMiPfUbXchJxFfrsgFrUWycxvjUVmL");
    string gpWvtZB = string("TMIwYKTJGKExBDfdmNUUJKULLDiOJvuKjQEKLzcxRNGPpjOBjVWNHsTIOPPJPLLIsLoAqhjbjownlDQqKzXAsrWTGKFJrdXjOiSjpBLHbAFYoVMRJHXysTZyeFdEBSfOdyTBsxGrDELkFHmFQCUYwwAWFPHEKZGshzqMPokEmnRCIbKGcYOJfsGygWnYrYseapaeMWkvCLfgqz");
    double gFfSbIibVNLZM = -450755.7488217825;
    double ZXAzTOvCJoMI = -763913.4899859597;
    double jkGvuWqvsuD = -308049.4779366427;
    bool wYQJkKYdQytxSoD = false;

    if (gpWvtZB == string("yZNItJcBCGngyQTxALprmwBdtfrhdsAtmhRrNZGJYNiVNmyGUqZkbAuyzwCnUmitnChkmjYqFHXswwFEpPLYOzYGoOUvwRDQLRthqRhMwYcwgkLDzFFawDrjlqYjgmYMVgePDWXmgBWnOmLdBVATTUlEprVrELZBooILGUNdrsZkYhcBmKXfEZhfbefnnNbeSChVg")) {
        for (int JWoOj = 117627273; JWoOj > 0; JWoOj--) {
            PueLahyWc -= PueLahyWc;
            UoymOOwmUvoEfzBW = UoymOOwmUvoEfzBW;
            mOqvklwVtOpvBX = unTUUqmYAe;
        }
    }

    return wYQJkKYdQytxSoD;
}

void NIzdwiRDeTtgTio::DCgceMkWX(double tJOTdUfvOfgZEA, bool HcnQr, bool TnZygHmyCJwDaJ)
{
    int iymmpTWFbWSGpXOn = -777459017;
    double rQxRDBWFUSpYY = 963982.0004736936;
    string XoxUGbfu = string("OpkCiyfQIvUYskeDkSspfjoFKnAWolCHQjEnEUvQBfedUfkZhMHLNVYjLSeLmmOFQGLUUboWoOYexJdmLxzzPUJxJVSrauvCBdlihjNwzcphNZIKhCNpKKYGAJlgUNKhYHLXBXwRKIMfEPSYFhkMXSesdiFnVQjjPmMqpHkytgc");
    int uIfplJO = -293488904;
    double QsETObwoO = -1001438.8712909777;
    double mRcnGxmgsV = -1275.8552945702381;

    for (int DRHBCdDnd = 1460735527; DRHBCdDnd > 0; DRHBCdDnd--) {
        mRcnGxmgsV = tJOTdUfvOfgZEA;
    }

    if (uIfplJO > -777459017) {
        for (int uDAqeysljDmWByz = 51783970; uDAqeysljDmWByz > 0; uDAqeysljDmWByz--) {
            uIfplJO = iymmpTWFbWSGpXOn;
        }
    }
}

bool NIzdwiRDeTtgTio::uNVwvaTgaOwUGR(string EyMyCsNtYEkp, int twbNckauwInaLUvB, string AgyLvDAUgM)
{
    string HDMKgcbiJAO = string("YxlAgrQKPNKzCrumaxFSPCioALogtRAiiRYBSXUpbfifWLeLPwxVvwWdnBWThrbPIwgGBGHacPoTfCzZFLdGWymRasYJArJuzSXDeeEegdTAUtYNuajXSeJxyMliNTnTCAHSyQcZFDwnTIyHedywjIjfAiNOapAtfMtAPliJbrmjBCjxvX");
    bool NeUqDguNrxVBIVyW = true;
    bool hyRNByGJM = false;
    string tRuHACkum = string("ZlwBdKqozSRcejR");
    double doGDq = -265226.4810023566;
    string VfoLRnXyUy = string("LmuMExNVgmXesLBrjtIJGEjeLYYLjzPRKjPSXgxjRbBuEBtTpGjOvKcUweGUZdHxsetMGhixEybTzadqhpwJCUQhlaCgkdmaqnYEBSBwdimQCVABdFspNjGnXdGGaHtKlgRdUZpHwRtKMJRxmPDkESa");
    int fCGIpuA = -63624545;
    double DSPInpAVdwboda = 258026.1592947208;
    int npbUVlagqPQqASF = 199355297;

    for (int gMPret = 2125383381; gMPret > 0; gMPret--) {
        HDMKgcbiJAO = EyMyCsNtYEkp;
        HDMKgcbiJAO = EyMyCsNtYEkp;
        VfoLRnXyUy += EyMyCsNtYEkp;
        VfoLRnXyUy += EyMyCsNtYEkp;
        EyMyCsNtYEkp = VfoLRnXyUy;
    }

    return hyRNByGJM;
}

bool NIzdwiRDeTtgTio::HSOahxbqPY(double XXwxTZstjYLu, bool rDFobY, int PKvQYxcYNbX, double baBPSrjKKx, string foMHPnVyHJ)
{
    int RnfKHDun = -671881526;
    string NiKWMwrFx = string("AGmHqmblDZYnDRGSsQFknSjajlqoxTJCklnjeAsuqcDfyolrjTXGjxghchddgSgLszMZuQzsDEPDShR");
    double wmODqxs = 531947.9520987292;
    bool NFzXAMiQD = true;
    bool pQadplTCEYzQ = true;

    for (int qrKqYrpGKRMTf = 572418900; qrKqYrpGKRMTf > 0; qrKqYrpGKRMTf--) {
        rDFobY = ! rDFobY;
    }

    for (int JgpyNJL = 2007068345; JgpyNJL > 0; JgpyNJL--) {
        NiKWMwrFx = NiKWMwrFx;
        RnfKHDun -= PKvQYxcYNbX;
    }

    if (RnfKHDun == 908816723) {
        for (int CmztZIJCjJy = 334251996; CmztZIJCjJy > 0; CmztZIJCjJy--) {
            NiKWMwrFx += NiKWMwrFx;
        }
    }

    if (NFzXAMiQD == true) {
        for (int usrQPBAK = 1459010567; usrQPBAK > 0; usrQPBAK--) {
            continue;
        }
    }

    if (RnfKHDun != -671881526) {
        for (int vFVGEpusXLI = 908951063; vFVGEpusXLI > 0; vFVGEpusXLI--) {
            wmODqxs -= baBPSrjKKx;
            RnfKHDun = PKvQYxcYNbX;
            XXwxTZstjYLu = baBPSrjKKx;
        }
    }

    return pQadplTCEYzQ;
}

NIzdwiRDeTtgTio::NIzdwiRDeTtgTio()
{
    this->iCqCVxC();
    this->TdspYATouAVKZpVD(-439656.8718403929, string("BRcLevOmrajLSDLQajetHCugNAPKIZdMHmKTNRiRFNatyNjYYLpRXGWmUWbmUavAqMVWrAhVTwdwHRWMXASiZMXjNHRbhZhkSwrFYDBenoOUgAxJwYxstFVkQhIVWsMFsJtdocsfNQjmsqobLtzCFbjDhgMzsMtzqkYLhUInmUMhjpTyuvGqolvMWMxLDECon"), 1413229612);
    this->ZCKenYRLLSvpKsq(791625888, -1526038548, -145043.18409038175);
    this->UlrRhfd(true);
    this->coLvOvB(-142208.23407343152, string("LRUNzIHvdtZDQovGxPkqPXkGeNVPdiOZoinjDvrpJSzDuUxCBFWEiidHCbvJjvBCYFTFXAaeDcmhftCyKBeXwpWxExLjRKYqMTNzivFnaaXnSlQPHsLEkonBoDGvotnmpwKXNisQSFXeCWQEBySTmhYIkJsPkUdeKNrADkCgfPLBYOGHsEguWYHTNwCSrQKYBJpHqWVEWGTEweCdaylZBgPYSkrvmDPTOsVqNLiLYrhLkiSGRfDnVsfzkuYlbIU"));
    this->pxXtsHrxJwrWF(string("XPzjUaLmIdRYTmMyJfXLhhaZFbyufzvstGUZRPUMnRoibmtRtlAuCzcFDltoZsjffAsoTFnqDfSYNYEjmleRagvGVEgPPmGYsmctlnJHmAOIqeXhofYFyWIjVzUkjNuBVrNKK"), 563278.7669109338, true, -382145.6125112569);
    this->SeSoWBmJZWcFc(-1153704633, string("idGRuhMWlVvODhPQWZktParqLCnxcjCOnQyXgBKmKokdZupAPtAbozreGwryaTFzziYbURvjhCcMpvHU"), 1821241663);
    this->qdjqYgt(true, false, -1040358646, string("jIFgkKFxJtKcyIgsUVqMlcgrJNISwUcLQlNGBSiFONSHPPtgOBGrgaunOVnLMiJOnPJRGXwSgOgtnMQGGScfhvGbmWDvHVCotwhKbpjIYdRsVAuiXVhjqscoYmttPdWwluZAgPbEefntMhZxEsUQPrbkqvZmdbefryUoncCuiCUbFIapLhssjUlwabGOcoioDD"));
    this->DEczPlZY(false);
    this->WsMFZccYXIJwZuMY(false, true, string("oomKdCcrYQffjhjBoIORXarePThbLxWPlpQequEScGmZHRqlfYFHkAxLfTcKSARSuNnZanTqzqXsCPmpfRrAyJjEBlXnOgLBGLXXpxZRzEbqhZZodgIjqitfXbgH"), string("mgYOPxqHwQqiZOaYVYRBCtZKyrHAgJYUOwReGLWkADWDYugGfSIBdpSAgsUqiEzZUvnHkNDKhoxkjVDrMhRXajwJYEhWDJrBQqCCpzbwvseCTMeLVrNAYjXiYBAFQuteMaptGuOOcPZdzEgMomnGXpBMZTYhgszniQNdaJHKjpVCVbQLWAxMmvwOhSuCEdbOHZSRPadpGlCdXIUeJqdHRkzY"), 440235003);
    this->GVydWXdMuBJDOmT();
    this->PMgNE(true, true, false);
    this->UMaLOxi(string("BcElvBBZsowcTOcCEudESizgbPylkIjtypZuaRvnpLIGQiXsZxWrOdFBKbKwppPzEDxEXpuJLaeCqVeBpUACyxsEPUxBnJMcBRkdIVTuJEjmdJhwqhmIoSnVYSMeSfvJBMFDppJVJMuNjkDSnsXsRY"), -564884231, 772284211);
    this->MycITXdaXlrQfX(true, string("yZNItJcBCGngyQTxALprmwBdtfrhdsAtmhRrNZGJYNiVNmyGUqZkbAuyzwCnUmitnChkmjYqFHXswwFEpPLYOzYGoOUvwRDQLRthqRhMwYcwgkLDzFFawDrjlqYjgmYMVgePDWXmgBWnOmLdBVATTUlEprVrELZBooILGUNdrsZkYhcBmKXfEZhfbefnnNbeSChVg"), -574932468, false, true);
    this->DCgceMkWX(223318.57844044754, true, true);
    this->uNVwvaTgaOwUGR(string("VcqqmlSRQYTyrPhqMpEwCwxVuFvsyYfazgmkOTDLAYcZbJtIQGzbjIaDGByDOoAZGDNpdjKEylFCPbzqYDopJu"), 346855534, string("NTjyfWxGOOWePEdMFItDwsbgoWUcarUnzEUcQQCVmFiEjkdSPDiqVaAJJscKBBJBnFRhOeJLGWsaFeRiqELWeMczQNkBnXHGBDlkalAUKYpITPnpksyRQJgDGGzHkEjYhsoWqiJuMFIYGBVRLupkgZzdMQiKOEHpbvItiCmRvNbUSqnnzXihEfZNKkDbLWJyKeHximHVLSmkqHRz"));
    this->HSOahxbqPY(-303499.26100118813, false, 908816723, -554980.0369151081, string("dvUrcbHCaMCMJoFFVKfzqSbKwjoP"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kfKioOfwPYlU
{
public:
    bool GXRCkV;
    bool qRixdQ;
    int QeUweyzbpbju;

    kfKioOfwPYlU();
    void aeRQMmYtLjmdxq(string xSNRbMLJbnqva, bool ioJlKEWHdDTmznE, double IQjdHGlJtWh);
protected:
    double OMklM;
    int vCIpVEKTaIRXXYUu;
    bool JcATm;
    bool pVXIgS;

    bool yLmMxgziugKpQOHt(string ZFHvpozsFqTJhR);
    double cZKXSRqDevuJzg(double iKkJmpOMWJyieQ, double ixkBSTIwwhO, string YqIOGiURlbACSV, bool HLysNQE);
    void kiWRPsvj(int kSCyHAsNAqZTbR, int IOykfNpJ, bool nzDdsgqpQF, double tABLySL, bool cGaPv);
    bool AagJKaCyy(int nBDgaYTe, bool duWyzPE, int lShnbWPQdqAu, double GrelYc, string tSaaSZCBtSfGt);
    bool zzrOyAnrjQ(string MsdgMjCIOlWkGOWy, int KOaTxDfTxlRm, double hXFoP);
    string aAmHXPUxc();
private:
    double OIsctld;
    bool Qqxlb;

};

void kfKioOfwPYlU::aeRQMmYtLjmdxq(string xSNRbMLJbnqva, bool ioJlKEWHdDTmznE, double IQjdHGlJtWh)
{
    double kFqjnY = 927191.1934651746;
    string QyBIWRlfHxKLJUG = string("OMKDHheXnlTwYAiAkSStwlkHPGAcCDOJcvOYPFQcHlpMksZoPHJDADqeQXVlZQvkMmzPsfkwsXrdibGwBZxyAWTQKOlWENNEvQWFXOECEQrtLTFEv");
    double QxSfUwjnnFR = 443876.8221218085;
    double apElAzmCMe = -509277.4696270991;
    bool OtDfsYjQg = true;
    double EvRirfNzlVeVXl = -955375.7612044871;
    bool apuvb = true;

    if (OtDfsYjQg == true) {
        for (int UVsDPCQdhOU = 1757093854; UVsDPCQdhOU > 0; UVsDPCQdhOU--) {
            ioJlKEWHdDTmznE = ioJlKEWHdDTmznE;
            QyBIWRlfHxKLJUG = QyBIWRlfHxKLJUG;
            apElAzmCMe = EvRirfNzlVeVXl;
        }
    }

    if (apElAzmCMe >= -955375.7612044871) {
        for (int Sxuwou = 2146639543; Sxuwou > 0; Sxuwou--) {
            QxSfUwjnnFR /= QxSfUwjnnFR;
            IQjdHGlJtWh += IQjdHGlJtWh;
            OtDfsYjQg = OtDfsYjQg;
            IQjdHGlJtWh = QxSfUwjnnFR;
            apuvb = OtDfsYjQg;
            apElAzmCMe += QxSfUwjnnFR;
        }
    }

    for (int dyOzOipv = 68764101; dyOzOipv > 0; dyOzOipv--) {
        continue;
    }

    if (apuvb != true) {
        for (int lZOBiaq = 509998100; lZOBiaq > 0; lZOBiaq--) {
            continue;
        }
    }
}

bool kfKioOfwPYlU::yLmMxgziugKpQOHt(string ZFHvpozsFqTJhR)
{
    int ndYBlbRfZubzAs = -1547375128;
    double JGEKdhAEsykR = -133666.7353286522;
    string lizdqDhvXzhty = string("HKPcKTJgpVYBreSSGMpySoiCptqlrYadpcFlXoUgKjlMOLVEIJFPfnbYXFqRSovFkldudiCIWevyxtQhckTAUscwOgnqZrOPczkmlGqQjMjJHRssZnupGPOlZxhnxVllWtkqGUTfsIbGHzKfvyCXgUBrSvccBRnrsphwBjDpNYiuhuNMqUuPGmttbCMkNYLUzamtSgwXsaCbuiNIZduZNBNjrpxdeeuOWtqCOCVOwqXDNuJYbN");
    double ooVfVQET = 422533.0080471839;
    int FLlaENzXeM = 370962844;
    double QqhPOAVq = 900849.8831057096;
    string VIkcXXxSYwUHw = string("OMThEpZIozpzZsgkKDUdNsjbcvpxYVWJWyYATxqNrMYspTiyQZqwqcMmfguRYCpbJdhFYFeGuZBDzskEaQdiueBGvyKvcvsnCXCZVLHWMcvtcBBFYYIwIADBVNfjQPaApLvNsirjudMmhNKMpBpuzGxYNvXcbvrAQFryqhHSfOd");

    return true;
}

double kfKioOfwPYlU::cZKXSRqDevuJzg(double iKkJmpOMWJyieQ, double ixkBSTIwwhO, string YqIOGiURlbACSV, bool HLysNQE)
{
    string IsQzBysiruYE = string("TuFjcvbpXZBLxAleDQxYdLLkDtSCrSyBuacXluFGteXGtaLdwYVQFVeXbJCCaUqDdvWzJrKCGRuKBsVnPqaSnMRKBcncUbfWTchiLzsvooTTaXuaYFZNwpoWqSNJSBuPTwDKTCMrwmrrCqSKlrKQlwmOigInHHRLagGUUbgzTWaMPOfgTsfESUNRVKhfZXoEaVHpxTbZutZeCpJS");
    bool cbhygBhNd = false;
    int PcANASb = 1929331592;
    double QeBhqPJndAu = 394443.3027344931;
    int GKPLaUbgOVPUv = 1582202926;
    int FZDplOmeIyfHq = -1157217404;

    for (int aObfqWeDHK = 261159361; aObfqWeDHK > 0; aObfqWeDHK--) {
        continue;
    }

    for (int hlwiYPfQSlkioKv = 1694417185; hlwiYPfQSlkioKv > 0; hlwiYPfQSlkioKv--) {
        HLysNQE = ! HLysNQE;
        QeBhqPJndAu += QeBhqPJndAu;
    }

    for (int zpqiRt = 1129202366; zpqiRt > 0; zpqiRt--) {
        PcANASb += PcANASb;
        PcANASb = GKPLaUbgOVPUv;
    }

    for (int kxJxuyVECltCatQt = 1360195796; kxJxuyVECltCatQt > 0; kxJxuyVECltCatQt--) {
        QeBhqPJndAu /= ixkBSTIwwhO;
        GKPLaUbgOVPUv += PcANASb;
        ixkBSTIwwhO = ixkBSTIwwhO;
    }

    return QeBhqPJndAu;
}

void kfKioOfwPYlU::kiWRPsvj(int kSCyHAsNAqZTbR, int IOykfNpJ, bool nzDdsgqpQF, double tABLySL, bool cGaPv)
{
    bool pjqZWxyz = true;
    string KcIURw = string("wDJLPJkQqxKqBHAuXlptyeJwxwZdZHZNyEqyNVRBnaAoCIkZcewOoCdHaMNuqNjaVSCEOnhGAvpAlEyHGlxwVAGjXFlGwaEHqmbytHfsNdCJQckmoFAZgPYFANBpQLVfJfIBnOttUNpCCOAmwgjycJWosZQI");
    double oAATVEI = -223215.5286992708;
}

bool kfKioOfwPYlU::AagJKaCyy(int nBDgaYTe, bool duWyzPE, int lShnbWPQdqAu, double GrelYc, string tSaaSZCBtSfGt)
{
    int NGGgL = 663694455;
    int amsRxyzKG = 565125981;
    double HWoKaE = 872468.9621652339;
    bool NZkxrMEA = true;
    bool SGnmIM = false;

    for (int PdxfVYz = 437156176; PdxfVYz > 0; PdxfVYz--) {
        continue;
    }

    for (int VLxCD = 799965518; VLxCD > 0; VLxCD--) {
        NGGgL -= NGGgL;
    }

    return SGnmIM;
}

bool kfKioOfwPYlU::zzrOyAnrjQ(string MsdgMjCIOlWkGOWy, int KOaTxDfTxlRm, double hXFoP)
{
    double LVKVbiqIAiwuIXjg = 1019739.244952069;
    double RXmysfdDo = 489404.1741919699;
    int ZzOpaJYiZgZa = -1913804389;
    bool kIToh = false;
    int ORihERVjGkCxia = -1915819872;
    string wYwYfJeM = string("SQyOBUlaFERrpTwvOjBtOahbDSqUusBJrICZPqDbDNpdecZUlmyFNBwKWtgOpHWWmQzruvdoTKuIzYtNFTQAITOrdoFaYKoLeehxWYaxzcvRVFJWjlgaPDSTxXyMxiZHRyooDawMXLAWIeFfCrdWYeWoLqolblSxCsVVOZgbjavbXIAHBxnjxufgQxXphXAcoaNzmAswgotklBFldjHWkTwoqBNSiGkzKIJWsiSROlTEFknNepHvPVlC");

    if (RXmysfdDo <= 1019739.244952069) {
        for (int jkHJjJmMWkSkvWV = 802255586; jkHJjJmMWkSkvWV > 0; jkHJjJmMWkSkvWV--) {
            RXmysfdDo *= LVKVbiqIAiwuIXjg;
            RXmysfdDo += hXFoP;
            KOaTxDfTxlRm += ZzOpaJYiZgZa;
        }
    }

    return kIToh;
}

string kfKioOfwPYlU::aAmHXPUxc()
{
    string wMlCnopAdM = string("SvFf");
    int JOcrRLacxR = -1428099570;

    for (int GPafekJqykSAXnQ = 1061180755; GPafekJqykSAXnQ > 0; GPafekJqykSAXnQ--) {
        wMlCnopAdM = wMlCnopAdM;
        wMlCnopAdM += wMlCnopAdM;
    }

    return wMlCnopAdM;
}

kfKioOfwPYlU::kfKioOfwPYlU()
{
    this->aeRQMmYtLjmdxq(string("QKTBuDYykfnOGqwkaQyBLLFOiKgjYWmTpWUElVbyncJQuEJyAfxEJjiiHjnOvDJChhTsNJwGMaXcroDbJEufARBoaiczhkKJgAiejEeauySkFugekjQlqSdgXbOTamMqGuRhdbmpQsZJJTZXWdzngaOzycaFfHf"), false, 654440.1710862579);
    this->yLmMxgziugKpQOHt(string("bUwUmvflTOqvaOunhKNehvqFOpAJUdankUIqvOWUaZHbUnoThxbNqkKeOEPxzXVZSBLiHziHNKWJUMZPbRORBKPOuhcZVyqbkoXdBSEXBsEPCndKxDdXrgrMmUjClxBErmuyccVzPqPEtONuDlIWxAqgulXjrxkIVhbztuAuDXTTpwfyZvdYdMpQvwxqXvVipGVPgAlfhTgozAmLfcYoVjgPUMUkiLQElSWKKHaCjMq"));
    this->cZKXSRqDevuJzg(151825.13151427088, 388155.2303250122, string("nHDDbIEUKtTJKvUQBdVPeGRTYTwrWLAsWmYfaywvTkqYeYgRNitgmkowbudqEYwmovZBsqhMbtviMRhEbUawrzsVdmpuPIjoKQhlPrBoaNWrMplGyYPDFFOqKtQWVxYkZKWAHFisrpqeOcabLqSCDSGVsWTPBtzhSguLJTRJHeofDlRArqekEDeNEoJMrwLmvHidsYOKLdvcUiURfSJQIRBPqvEavPwHCIeEkknViMN"), false);
    this->kiWRPsvj(2040069383, -1444936527, true, 588893.1458488789, false);
    this->AagJKaCyy(133615992, true, -1117141918, 435570.6041658564, string("mLazxFmZdgJGrYCJRbtGMLjsbatFSqdlSOUybZhZLpVLkAJsXodLvRKAbKljnkEdSZiQtNtpIAUdCfdZvuxenaIIbTngPNpUqqsJIZvzcjASqZi"));
    this->zzrOyAnrjQ(string("GjapixozrZVrqFenSGtpqdZjWFwu"), 198590028, 177107.83591853554);
    this->aAmHXPUxc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NNxttaGu
{
public:
    bool xdvuEGacxXi;
    bool rZKjHyuBjuLr;

    NNxttaGu();
protected:
    int cfLNKZvQRqU;
    bool RBFQmhQ;

private:
    string QLLVSQiBgHx;
    string iznQsTH;
    double chruTkl;
    double pkQEPEDpcJ;
    string QjneZqeZggVGRn;
    int ImvYjyJydhjGcAA;

    void iHBszczLWRIudSyJ();
};

void NNxttaGu::iHBszczLWRIudSyJ()
{
    string CbyjtvMi = string("BAbCrzSxTzJCKOaoaEdjGknNEdAVzQTVDbdSWtBXgmgdEeDdiWSxoZSrjjXZhlcyJhrFVhmaAnkWEJuOuqVXzWWEmKZlUQhjaWYaAfqFLntyhGQZZGzVewhszYqJPLsrSapYBnlRrloMsMPsGCJdRfBuMWxYJlwMCKzLOKEUrvQmcarzu");

    if (CbyjtvMi < string("BAbCrzSxTzJCKOaoaEdjGknNEdAVzQTVDbdSWtBXgmgdEeDdiWSxoZSrjjXZhlcyJhrFVhmaAnkWEJuOuqVXzWWEmKZlUQhjaWYaAfqFLntyhGQZZGzVewhszYqJPLsrSapYBnlRrloMsMPsGCJdRfBuMWxYJlwMCKzLOKEUrvQmcarzu")) {
        for (int ScBTwagVdvj = 1488970513; ScBTwagVdvj > 0; ScBTwagVdvj--) {
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
        }
    }

    if (CbyjtvMi < string("BAbCrzSxTzJCKOaoaEdjGknNEdAVzQTVDbdSWtBXgmgdEeDdiWSxoZSrjjXZhlcyJhrFVhmaAnkWEJuOuqVXzWWEmKZlUQhjaWYaAfqFLntyhGQZZGzVewhszYqJPLsrSapYBnlRrloMsMPsGCJdRfBuMWxYJlwMCKzLOKEUrvQmcarzu")) {
        for (int JqlvTyy = 721743882; JqlvTyy > 0; JqlvTyy--) {
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
        }
    }

    if (CbyjtvMi > string("BAbCrzSxTzJCKOaoaEdjGknNEdAVzQTVDbdSWtBXgmgdEeDdiWSxoZSrjjXZhlcyJhrFVhmaAnkWEJuOuqVXzWWEmKZlUQhjaWYaAfqFLntyhGQZZGzVewhszYqJPLsrSapYBnlRrloMsMPsGCJdRfBuMWxYJlwMCKzLOKEUrvQmcarzu")) {
        for (int EOswFGPF = 1027144780; EOswFGPF > 0; EOswFGPF--) {
            CbyjtvMi += CbyjtvMi;
        }
    }

    if (CbyjtvMi != string("BAbCrzSxTzJCKOaoaEdjGknNEdAVzQTVDbdSWtBXgmgdEeDdiWSxoZSrjjXZhlcyJhrFVhmaAnkWEJuOuqVXzWWEmKZlUQhjaWYaAfqFLntyhGQZZGzVewhszYqJPLsrSapYBnlRrloMsMPsGCJdRfBuMWxYJlwMCKzLOKEUrvQmcarzu")) {
        for (int fIQZTPNA = 84799356; fIQZTPNA > 0; fIQZTPNA--) {
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
            CbyjtvMi = CbyjtvMi;
            CbyjtvMi += CbyjtvMi;
        }
    }
}

NNxttaGu::NNxttaGu()
{
    this->iHBszczLWRIudSyJ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VBCtGfXHDoJTmxK
{
public:
    bool mOFrUcFUQLjp;
    double Hnqnk;
    int aMxQJ;

    VBCtGfXHDoJTmxK();
    void cwvADNpfmANHT(bool uQWuj, string ZHmpAQHEttIZbOxJ, int nkOXHDLPMtB);
    int FQMgLgsxx(string fIoqqqaBBUeHihe, int kCghvHnD, bool oArsVLCcEa, string oSoZFwdDQM, double DwGlyoZzE);
    string iKQDkuFjJiPBBKN();
    string dpGqVzHaZQrMj(double UAlVJvMRqf, double nAtZUqQBRfKyxp, string mGkXFTxNtnAMgj, bool TVZlimOpuLHhqJtP);
    int yUyreIoIaf(string SSVHqHqRlzQC);
    double XjlHfuaDa(double wIWMPGAAa, int NSZkBM, int AbRgBI);
    void NWSFZnZTNq(string VOhBN, string ixcqv, bool bjfKvQdYKodAsry, bool oNkEKR);
    string ZgIOYELWW(bool KfFYxUBoZt, string JRwWS, bool zGDXtaNL);
protected:
    bool LLQMxHNUxzrW;
    bool ydnzQfSNQ;
    double iIyYhMxRhkuSaU;

    double vfMSjtdAe(string xyGwdrFJI, int fHHgtkjd, int exbNPLsE, int PvBdhmlRrJ);
    bool NLhMnLrPsuwj();
    double xKpiYVmRJXFMZZSy(bool hqznQYxOW);
    double ASyXhGTKIOL(bool lNlNywYtAqmsI);
    int spTqThpmbhIJWSzI(string qyfHPnHDchyPN, double UTdlQU, int DsWQyQHoerFXLAi, double VGIMjA);
    int vnJKi(int ogjvWtAw, int TTXnapvCniH, double OLEByNS);
    bool oKfEsvAw(double AxPMmHrirh, bool oGUoNgLdGXXyXOFE, bool caeZQO, int mdPwHSFcatnNKYgc, int LPzdnfcjjGqOb);
    int mChouoZiAaecy(string GbOtzJCehXQ, int slOoMJDQG, int fJixjxVTepOZNyKH);
private:
    double JBWUrrPbXbPArgAI;

    double VhsqHHMtaDxP(string vnavvBJcZIM, string CubNQuz);
    bool exOPBhqmUztFM();
    string oyVLyCdy(bool RWgtMECOkqCZ);
    bool yheVYYDCJqsWNTz();
    double MdLYo(int oTHchXbxrI);
};

void VBCtGfXHDoJTmxK::cwvADNpfmANHT(bool uQWuj, string ZHmpAQHEttIZbOxJ, int nkOXHDLPMtB)
{
    bool KJLog = true;
    bool cdbtjr = true;
    bool NoWDrjEFMwz = false;
    int vQqCZev = 1714459996;
    bool bHIaAZVo = false;
    double goMbngfNnbqLfjZd = 73557.43997721381;
    int CqDZlFOT = 1131445309;
    string trRgiamQHP = string("hKlHPiWlyBNrKFkSUDrZmnVT");
}

int VBCtGfXHDoJTmxK::FQMgLgsxx(string fIoqqqaBBUeHihe, int kCghvHnD, bool oArsVLCcEa, string oSoZFwdDQM, double DwGlyoZzE)
{
    double ohpwgvXEpRtDSmwm = 671898.4157897909;
    double bZszdtXYxOt = -909402.840734836;
    int AXZnALe = 891264544;

    for (int LjKfOCfdrmTTwjt = 1993975266; LjKfOCfdrmTTwjt > 0; LjKfOCfdrmTTwjt--) {
        continue;
    }

    for (int dsPUs = 2008388168; dsPUs > 0; dsPUs--) {
        fIoqqqaBBUeHihe += fIoqqqaBBUeHihe;
        AXZnALe += AXZnALe;
    }

    for (int DdlkCgLbchZRqp = 1508984857; DdlkCgLbchZRqp > 0; DdlkCgLbchZRqp--) {
        kCghvHnD *= kCghvHnD;
    }

    return AXZnALe;
}

string VBCtGfXHDoJTmxK::iKQDkuFjJiPBBKN()
{
    string VRFvhRSQZvlP = string("WgZOwWuzWoJlytfoFGZMuUJHGiGQGzyPyxCIatmbULQFzdBieQufXnArOLFVCdRSltkjQXOBTeRdnWUQKQohkHESIuxZoFpnxMemYNRVbNTkuTEeTFByFbnSWT");
    double VCQQbqs = -1000718.3594199595;
    string uECqZiwdiTF = string("pvCpDGvJFRxJvHAxglGGYcbYGjkuSUikzpumNLqIZenZGZtqWxfakDVvTJJZGCqPBfiznTSogNzqGCeIKqrpvCrISoQmppteYnGDCwYmSMiRvmgdC");
    bool rLeeef = false;
    string JiwlkLiLZrrxX = string("cVVlJpJCpJSqUIsnb");
    string cCLqsYbeWHG = string("OVgsQBLmCyqqvRthUYzuy");
    double NkRRNL = 302300.6709941333;
    int UOKMOgxWAfLBL = 1327940547;

    for (int VGZJABe = 2070496547; VGZJABe > 0; VGZJABe--) {
        JiwlkLiLZrrxX += cCLqsYbeWHG;
    }

    for (int oDdiaOUxPl = 143907094; oDdiaOUxPl > 0; oDdiaOUxPl--) {
        uECqZiwdiTF += JiwlkLiLZrrxX;
    }

    for (int DHKYyjLZ = 2137981718; DHKYyjLZ > 0; DHKYyjLZ--) {
        uECqZiwdiTF += uECqZiwdiTF;
    }

    if (cCLqsYbeWHG != string("pvCpDGvJFRxJvHAxglGGYcbYGjkuSUikzpumNLqIZenZGZtqWxfakDVvTJJZGCqPBfiznTSogNzqGCeIKqrpvCrISoQmppteYnGDCwYmSMiRvmgdC")) {
        for (int mhvAnanen = 2050988806; mhvAnanen > 0; mhvAnanen--) {
            uECqZiwdiTF += VRFvhRSQZvlP;
            VRFvhRSQZvlP = uECqZiwdiTF;
            UOKMOgxWAfLBL += UOKMOgxWAfLBL;
        }
    }

    for (int BeSXdWXgCbrLBqZk = 1728155809; BeSXdWXgCbrLBqZk > 0; BeSXdWXgCbrLBqZk--) {
        VRFvhRSQZvlP = uECqZiwdiTF;
    }

    return cCLqsYbeWHG;
}

string VBCtGfXHDoJTmxK::dpGqVzHaZQrMj(double UAlVJvMRqf, double nAtZUqQBRfKyxp, string mGkXFTxNtnAMgj, bool TVZlimOpuLHhqJtP)
{
    double AnequZLcTWIE = 958334.3650637409;
    int kjRJVJJhZOLZY = 291303404;
    bool FqXMYXfni = false;
    string RtWEQsurAKgoIq = string("JPKohwOxefNNYKBynOvqtSUBpfXzdJyOsUORnPBLrvCScJsOaSHBIocdDxJSLUCvXwKHlcDZyfrGKfHvuOfMNhsfFfVejvHC");
    string TlOjUtmwZvl = string("dDfydxkQaAlkEksLWRAcSrhUcRFoFMysTdAJPgTNrlwBHJosscDcSzUZVm");
    int BcOQFRj = -728982645;

    for (int AyBiPNTawPGmDq = 1468706354; AyBiPNTawPGmDq > 0; AyBiPNTawPGmDq--) {
        RtWEQsurAKgoIq = mGkXFTxNtnAMgj;
    }

    for (int xJSqygjBgYTKFI = 1676799145; xJSqygjBgYTKFI > 0; xJSqygjBgYTKFI--) {
        TVZlimOpuLHhqJtP = TVZlimOpuLHhqJtP;
    }

    for (int lzQstfSXIgvsgQKR = 252534827; lzQstfSXIgvsgQKR > 0; lzQstfSXIgvsgQKR--) {
        kjRJVJJhZOLZY += BcOQFRj;
        TVZlimOpuLHhqJtP = TVZlimOpuLHhqJtP;
        RtWEQsurAKgoIq = TlOjUtmwZvl;
        AnequZLcTWIE /= nAtZUqQBRfKyxp;
    }

    return TlOjUtmwZvl;
}

int VBCtGfXHDoJTmxK::yUyreIoIaf(string SSVHqHqRlzQC)
{
    double GJjjutujHCnHBxS = 257168.93465092767;
    string kYzqHl = string("yIIUzDWigWFQYBrxRBbouHZvZlubXRrvNnNhMGuMJjfSJklMWcWzeQaCzcLjdkBooQxYmhbDsoqsibKmbzNoEXayA");

    if (GJjjutujHCnHBxS >= 257168.93465092767) {
        for (int pqTBCYvprrva = 415862341; pqTBCYvprrva > 0; pqTBCYvprrva--) {
            kYzqHl = SSVHqHqRlzQC;
            kYzqHl += SSVHqHqRlzQC;
        }
    }

    return -2120867213;
}

double VBCtGfXHDoJTmxK::XjlHfuaDa(double wIWMPGAAa, int NSZkBM, int AbRgBI)
{
    bool moDsIIyKMyqO = true;
    int HJWQuvtLNHwWlA = -1384784374;
    bool ltbzgQMhUkG = true;
    string KNaDeAnaMMzZ = string("aBnYUnPDAazpPeuxZjJFFIqWmlmEgXxNjpGqBGaYASWELULIlGgKyVinCgqmKsYfghSdmpVFuoNtwvzIDXyYQHwbOJFyMt");
    string BWGVmhbhp = string("JvnYVjuMwaiKJQDaREUSqsjXxfOpuBabeYkiuoazowujRScMzBHSTQpcYUdwyNbcqpUOsoNRUDjRpgobTMghgLUeynPVPWrFEietDAUGwknYnvOmpPZOBEuVYIoDGi");
    double tNvPVeBbbRCLEc = -318943.2675229452;
    double JUvSXP = -408953.79675623745;
    bool PjHQNeulI = true;
    bool fmldFjgYyNURI = false;

    if (AbRgBI == -286514915) {
        for (int sSLpzsqyPvOQMgvV = 436815134; sSLpzsqyPvOQMgvV > 0; sSLpzsqyPvOQMgvV--) {
            fmldFjgYyNURI = PjHQNeulI;
        }
    }

    return JUvSXP;
}

void VBCtGfXHDoJTmxK::NWSFZnZTNq(string VOhBN, string ixcqv, bool bjfKvQdYKodAsry, bool oNkEKR)
{
    string tcaSMEial = string("GEMoVuSubYPPjYXxwcHuKBofbilqUFdCTnvSFGjnoBuagJEHgwpjDwmlPIVPdcEqLkmdVWOKQiCXsVMFApMMrKBDvAlBPSKMQkrOhCvMdKhbZscmioaaVohfBAeyveBdsoxaUMRPrWFAscmBpQWxYFnIkkISbtLqzHolbqgyPbFXPciauDCTqsMYrgnQnorliBoo");
    bool twlvsDfuKS = true;
    bool QxoNdWJEp = false;

    for (int PtoCeEaoALCebBce = 868526292; PtoCeEaoALCebBce > 0; PtoCeEaoALCebBce--) {
        ixcqv = ixcqv;
        QxoNdWJEp = oNkEKR;
        VOhBN += tcaSMEial;
        bjfKvQdYKodAsry = ! oNkEKR;
    }

    if (ixcqv > string("DwSizthgKoPSSsPXXUidhYrIcKAtKJKEHTzVXRMHfzMHvVMMapaZPXSINpKVCooHYGyihdxlZacxocFISspOJEIkbLmdFZBEiNsWwmS")) {
        for (int DQFFD = 1010207963; DQFFD > 0; DQFFD--) {
            bjfKvQdYKodAsry = twlvsDfuKS;
        }
    }

    if (bjfKvQdYKodAsry != true) {
        for (int NcUObug = 899003838; NcUObug > 0; NcUObug--) {
            twlvsDfuKS = oNkEKR;
            oNkEKR = oNkEKR;
            twlvsDfuKS = twlvsDfuKS;
        }
    }

    if (tcaSMEial >= string("haVcULtQPgjnzHyIddV")) {
        for (int QGJQqDC = 164358908; QGJQqDC > 0; QGJQqDC--) {
            tcaSMEial += VOhBN;
            VOhBN = tcaSMEial;
        }
    }

    for (int DrGIk = 529175969; DrGIk > 0; DrGIk--) {
        continue;
    }
}

string VBCtGfXHDoJTmxK::ZgIOYELWW(bool KfFYxUBoZt, string JRwWS, bool zGDXtaNL)
{
    double JZasgCMm = 442645.0886190536;
    bool cBwEuCKA = false;
    int QlIxFZm = -2016068751;
    bool jNTCFJBqK = true;
    bool DzORZ = true;
    bool FWGPlLZEB = true;
    string xocrV = string("uDDkRleMwaCvrjNLgfgdhXhHkluRwynggNzucOEUwoHdni");
    double hEGCAFqsnMlmMaV = 596467.107355833;
    bool SBZumBuo = true;

    if (xocrV != string("ZAjEkEjuGFUpJtOlxKuvCRgwmIaXIQWYPIYsEtkdwTLjrpzsloOZAfZTpJbDYULejDCDXPvUPepPpbTMsMrnJKR")) {
        for (int nAjPlZOHxhdh = 1555182560; nAjPlZOHxhdh > 0; nAjPlZOHxhdh--) {
            KfFYxUBoZt = cBwEuCKA;
        }
    }

    for (int hSYtKYJeeYbGsY = 1712454852; hSYtKYJeeYbGsY > 0; hSYtKYJeeYbGsY--) {
        JZasgCMm /= JZasgCMm;
        zGDXtaNL = DzORZ;
        jNTCFJBqK = ! DzORZ;
        zGDXtaNL = ! cBwEuCKA;
        FWGPlLZEB = ! jNTCFJBqK;
    }

    if (SBZumBuo == true) {
        for (int VKZQGgwROLcnu = 1798620551; VKZQGgwROLcnu > 0; VKZQGgwROLcnu--) {
            FWGPlLZEB = cBwEuCKA;
            DzORZ = ! SBZumBuo;
            jNTCFJBqK = FWGPlLZEB;
            zGDXtaNL = jNTCFJBqK;
        }
    }

    for (int BMNcoCxNCBC = 283228568; BMNcoCxNCBC > 0; BMNcoCxNCBC--) {
        JRwWS += xocrV;
        FWGPlLZEB = ! SBZumBuo;
    }

    for (int hQexOmASfbndWBw = 1446513478; hQexOmASfbndWBw > 0; hQexOmASfbndWBw--) {
        zGDXtaNL = zGDXtaNL;
    }

    for (int RbCWQhIxPw = 7236303; RbCWQhIxPw > 0; RbCWQhIxPw--) {
        DzORZ = FWGPlLZEB;
    }

    for (int LhrLJIFcC = 1051744414; LhrLJIFcC > 0; LhrLJIFcC--) {
        continue;
    }

    return xocrV;
}

double VBCtGfXHDoJTmxK::vfMSjtdAe(string xyGwdrFJI, int fHHgtkjd, int exbNPLsE, int PvBdhmlRrJ)
{
    bool nyuoDJgkMpogHY = true;

    for (int BUmHKFVQMWcjvndF = 1333070184; BUmHKFVQMWcjvndF > 0; BUmHKFVQMWcjvndF--) {
        fHHgtkjd -= PvBdhmlRrJ;
        xyGwdrFJI += xyGwdrFJI;
        nyuoDJgkMpogHY = ! nyuoDJgkMpogHY;
        fHHgtkjd -= fHHgtkjd;
        fHHgtkjd = fHHgtkjd;
    }

    return 807403.8103274044;
}

bool VBCtGfXHDoJTmxK::NLhMnLrPsuwj()
{
    string GQvVvuwvCKMJt = string("IDhIUAVyJAzemLsKbUYonYVjDkaBXQkIjSENyMmksdOXEwRcKjTQHpjJuZMiOTTObqQLuupwHGTVbWlldqhOFabZxbkGHkwCAyRjsWwdyPNJklAXAzUPYurpFqClCckltjOBneoqBDfabQtFssqhzNIMiiyIcwMoLyXOqANJiKXMaWwzfQrGs");
    string lrXDarhUgLzu = string("PVoHekedzQlkFKJONElFxhlaemruDNxgXHltSicRCXgoSMZnlITulKiNbvoCwIpKmcIqzrHfUtcphuZufoaxNiDMggLxVcorHlmSsPiRLNJVjsMaTnCNEYqrLnQxUkkAhkqaEEBTREgsEDTUPFIrUSigYPfEifomTPPjxPKRNFpvlSrLfeGqGjAYsXIFQFYIDPouLDEhjVMlYbUOJEnjOdPULqDgZqvgUAwbpJnZyoqIZhRYghshyHAAjJ");
    double zSOOJWs = 394907.5938800129;
    int SkxXdKdrTl = 882088891;
    int PlMNNcz = -1487254922;
    double bbdWeyiGsh = 534237.6543497574;

    if (PlMNNcz < -1487254922) {
        for (int KrMhtNfzgScSo = 883105645; KrMhtNfzgScSo > 0; KrMhtNfzgScSo--) {
            lrXDarhUgLzu += lrXDarhUgLzu;
        }
    }

    for (int zIFuBrWoP = 1789131833; zIFuBrWoP > 0; zIFuBrWoP--) {
        SkxXdKdrTl = SkxXdKdrTl;
        PlMNNcz += SkxXdKdrTl;
        zSOOJWs = zSOOJWs;
        SkxXdKdrTl /= PlMNNcz;
    }

    for (int IiNWeErcAk = 1946337943; IiNWeErcAk > 0; IiNWeErcAk--) {
        lrXDarhUgLzu = lrXDarhUgLzu;
        lrXDarhUgLzu += GQvVvuwvCKMJt;
    }

    for (int FeETkQZOhKehSEL = 1305665398; FeETkQZOhKehSEL > 0; FeETkQZOhKehSEL--) {
        GQvVvuwvCKMJt = lrXDarhUgLzu;
        SkxXdKdrTl *= SkxXdKdrTl;
    }

    for (int VYwRNrmupHOO = 6807824; VYwRNrmupHOO > 0; VYwRNrmupHOO--) {
        PlMNNcz = PlMNNcz;
    }

    for (int qMyXzYimRxngZM = 1624174110; qMyXzYimRxngZM > 0; qMyXzYimRxngZM--) {
        GQvVvuwvCKMJt = lrXDarhUgLzu;
        zSOOJWs = bbdWeyiGsh;
    }

    for (int ajPqxMT = 2056001287; ajPqxMT > 0; ajPqxMT--) {
        GQvVvuwvCKMJt += lrXDarhUgLzu;
        zSOOJWs *= bbdWeyiGsh;
        zSOOJWs /= zSOOJWs;
    }

    for (int SsEJC = 1255992318; SsEJC > 0; SsEJC--) {
        bbdWeyiGsh += zSOOJWs;
        zSOOJWs *= zSOOJWs;
        lrXDarhUgLzu = GQvVvuwvCKMJt;
        bbdWeyiGsh -= zSOOJWs;
    }

    return true;
}

double VBCtGfXHDoJTmxK::xKpiYVmRJXFMZZSy(bool hqznQYxOW)
{
    bool KlHnblqsFVSzs = false;
    int CpprfabPGQBg = -1846388581;
    string UwgGRGhEsUIXRBKw = string("DgXowzmaayuvKcmcLzVYfDISXXuRIRVzPjZzHRBkTsfsTNkTqeytuwpKmDlpzgWdmPqyoTyjoBcVHaCsURaPMKKGNVRCJnHgBeojwJaqofgGcZbZfvwymtdtfTHrCfvCwMradUDiWayrOXWHMfeBtXpsErsndBCWFMGIHGFgDPdGwZyMu");
    double kehApgUxvZok = -838784.0046346418;
    string vxCAqvvCKyC = string("ZdlAwodmZpCAKSGsFiZAETCgULfrbAksHopFjOEVlpwpyTEhHfmsGwEEuBeIkfCLrgvOYneRqHwWwdjZLvgSUNDWYasKoiOSbVvAlXDBL");
    double gxjCtjJW = -215372.63735032675;
    bool rjUCrYfljlPFUDQn = false;
    bool itaGKcuZQpX = true;

    for (int KkgPjuXQ = 364137419; KkgPjuXQ > 0; KkgPjuXQ--) {
        gxjCtjJW /= gxjCtjJW;
    }

    if (vxCAqvvCKyC >= string("ZdlAwodmZpCAKSGsFiZAETCgULfrbAksHopFjOEVlpwpyTEhHfmsGwEEuBeIkfCLrgvOYneRqHwWwdjZLvgSUNDWYasKoiOSbVvAlXDBL")) {
        for (int IgRcLsYoObLMPIGb = 892885655; IgRcLsYoObLMPIGb > 0; IgRcLsYoObLMPIGb--) {
            itaGKcuZQpX = KlHnblqsFVSzs;
        }
    }

    return gxjCtjJW;
}

double VBCtGfXHDoJTmxK::ASyXhGTKIOL(bool lNlNywYtAqmsI)
{
    int PNqKE = 1431851227;
    double SHsNGfyjwcxjgmP = 577984.9922138412;
    int NJZkSxnRA = -1469061055;
    string FxgiL = string("AgHkEQBtvV");
    bool zVBFhlGEuxBNog = false;
    double YMUrAIDMcRRgKsUx = 771703.2761038379;
    string LsUzB = string("kOwtnAuWENhafAcxehFzwzdcilMyOXImKGysDpEDNjKuZwXvQhTbKObUZlaEXCiGOrFbbMHTTypquAyfWIFKBmDmnKusskwWdANoxBOmzDhEEylPOMMkPgQRCJIaoRYdlnGpeMlSzVNiawnYAGgngfEZCyjjwCHjTWNrLyvZHIUJORRpR");
    string Klcqc = string("RxirRWHMvcXLcntrCuABiDkSzIyxhmPUNtntfzgfxesowNQzWvorgjDwNPzOjotkANobraLwxyvUnKeYjyiRpQWtShJUmHWoUAncxhMhi");
    string yzkmThZuM = string("KwUXBdpzWYqylqoZAKqwKZVeWcQRiwmbkhqJYuhrZSssPpUBgVUHubcYRsTePggHvOLYOeequEhsGMyvvFKqaOzbPzUkVonCKgxkbPIydgGtulxpVDRiDsIXUBEFNcJWaGSrMmVQUVZkPOOmljkvKTfFDmNYSsCEzvxbLhNmYTsRWhBEwfhBbPkfDSHshmDbQSAQsPHzMlKR");

    for (int OqxOIOhzHG = 311385189; OqxOIOhzHG > 0; OqxOIOhzHG--) {
        FxgiL += FxgiL;
        SHsNGfyjwcxjgmP = YMUrAIDMcRRgKsUx;
        yzkmThZuM += FxgiL;
        Klcqc += FxgiL;
    }

    if (LsUzB >= string("RxirRWHMvcXLcntrCuABiDkSzIyxhmPUNtntfzgfxesowNQzWvorgjDwNPzOjotkANobraLwxyvUnKeYjyiRpQWtShJUmHWoUAncxhMhi")) {
        for (int WyRgah = 1837581172; WyRgah > 0; WyRgah--) {
            LsUzB += yzkmThZuM;
            Klcqc += yzkmThZuM;
            SHsNGfyjwcxjgmP *= YMUrAIDMcRRgKsUx;
            LsUzB = FxgiL;
        }
    }

    for (int pZPumPVO = 67031545; pZPumPVO > 0; pZPumPVO--) {
        yzkmThZuM = Klcqc;
    }

    for (int vFmrwMapRGSogRi = 1180634783; vFmrwMapRGSogRi > 0; vFmrwMapRGSogRi--) {
        continue;
    }

    return YMUrAIDMcRRgKsUx;
}

int VBCtGfXHDoJTmxK::spTqThpmbhIJWSzI(string qyfHPnHDchyPN, double UTdlQU, int DsWQyQHoerFXLAi, double VGIMjA)
{
    double JMOTzqjO = -604547.8777323661;
    string UHztlZ = string("LDCPywqxqMgZkdcSWWtjmAgFzcpryutYiKXxxwuqSmeJJWggPvATZrQhnQYsaaYbYxTwXegsNSMyNTM");
    double YGclQQJbOBUU = -228962.2988285232;
    double GqOHqdpNoTcvui = -615643.2690542277;
    double Canxub = 814957.2264548086;
    int hhzYlzOWCtZUZJOy = -832600442;

    for (int foYrSCMk = 590536773; foYrSCMk > 0; foYrSCMk--) {
        continue;
    }

    for (int nomLdte = 1061456866; nomLdte > 0; nomLdte--) {
        GqOHqdpNoTcvui *= YGclQQJbOBUU;
        UTdlQU /= YGclQQJbOBUU;
        Canxub = GqOHqdpNoTcvui;
        VGIMjA = UTdlQU;
    }

    if (VGIMjA >= -990471.7601298165) {
        for (int KVlRy = 181090002; KVlRy > 0; KVlRy--) {
            YGclQQJbOBUU *= GqOHqdpNoTcvui;
        }
    }

    for (int vzmjMSKfqKsCw = 337252288; vzmjMSKfqKsCw > 0; vzmjMSKfqKsCw--) {
        GqOHqdpNoTcvui /= JMOTzqjO;
        Canxub = YGclQQJbOBUU;
        VGIMjA += UTdlQU;
        GqOHqdpNoTcvui *= JMOTzqjO;
    }

    return hhzYlzOWCtZUZJOy;
}

int VBCtGfXHDoJTmxK::vnJKi(int ogjvWtAw, int TTXnapvCniH, double OLEByNS)
{
    string ZOdusoSbiEQBzS = string("vvfeJUYMyQYNwbxcgskMHxCvfgFqaPprhSloiefzJUQExePI");
    bool GeCQbD = true;
    string LaabN = string("pvcjFCLRoKJPcaetvyijhuehuDDinrdyyZNEDMLRGdfZBdhEpsMWhbOVdXeSgheMUeIZjRqAnebsZxfCKxxMNWGMtFptQnsjrorLfgbnhbNpuNFAnaoKslMjvMcJQBltkAjhYEHbkYtJRkWEAjBMkKGiMXNLuClrxVtRyckOACCzLsMJbxuIAcqaAKOYKyvjBVvtSTuvjMNEUpNCZNXdTlxopKVIWMmjZCZ");

    if (TTXnapvCniH == 1999764220) {
        for (int QSFboOUrRZvJhALp = 929937735; QSFboOUrRZvJhALp > 0; QSFboOUrRZvJhALp--) {
            OLEByNS = OLEByNS;
        }
    }

    for (int zJKzD = 1766810929; zJKzD > 0; zJKzD--) {
        ZOdusoSbiEQBzS = ZOdusoSbiEQBzS;
    }

    if (ZOdusoSbiEQBzS <= string("pvcjFCLRoKJPcaetvyijhuehuDDinrdyyZNEDMLRGdfZBdhEpsMWhbOVdXeSgheMUeIZjRqAnebsZxfCKxxMNWGMtFptQnsjrorLfgbnhbNpuNFAnaoKslMjvMcJQBltkAjhYEHbkYtJRkWEAjBMkKGiMXNLuClrxVtRyckOACCzLsMJbxuIAcqaAKOYKyvjBVvtSTuvjMNEUpNCZNXdTlxopKVIWMmjZCZ")) {
        for (int uAyqzGxJ = 1428385765; uAyqzGxJ > 0; uAyqzGxJ--) {
            OLEByNS -= OLEByNS;
            TTXnapvCniH += ogjvWtAw;
            ogjvWtAw -= TTXnapvCniH;
        }
    }

    if (LaabN >= string("vvfeJUYMyQYNwbxcgskMHxCvfgFqaPprhSloiefzJUQExePI")) {
        for (int DZfPSxfc = 981637957; DZfPSxfc > 0; DZfPSxfc--) {
            OLEByNS += OLEByNS;
            LaabN = ZOdusoSbiEQBzS;
            LaabN = LaabN;
        }
    }

    for (int oMdPrchnIgA = 364814496; oMdPrchnIgA > 0; oMdPrchnIgA--) {
        LaabN = LaabN;
    }

    if (TTXnapvCniH <= 1999764220) {
        for (int MuRASmAOPBP = 1604465854; MuRASmAOPBP > 0; MuRASmAOPBP--) {
            continue;
        }
    }

    for (int wIOtf = 1549579066; wIOtf > 0; wIOtf--) {
        LaabN += LaabN;
        ogjvWtAw *= ogjvWtAw;
        TTXnapvCniH *= ogjvWtAw;
    }

    return TTXnapvCniH;
}

bool VBCtGfXHDoJTmxK::oKfEsvAw(double AxPMmHrirh, bool oGUoNgLdGXXyXOFE, bool caeZQO, int mdPwHSFcatnNKYgc, int LPzdnfcjjGqOb)
{
    string oAXjekeIOmpI = string("kJKgxgGTNdxwMVgzDGQCsdemRlBVtXxHIlMyHPZMIUmdSlBmzBhBbnldeAmntAmiXbKglxVVBtVpFBslVVqAtesFzqRvcFgiryrISXxtglKcsBFlPskwHYmfMmbprfwbBtKRqJbQHrivKnTaiHGGtfNfoRbCfjLbZhFapuwUggdanZRaLlcnoWnVkchrVGEtacNkRJZWSIxcdOhQXqEOwvUHlawJhaPLkhfL");
    int pHVuEHDDT = -1827224546;
    string bwlvSHGkGPWhm = string("rdMTxufUPtdyYdEkAjeXMEXJMadgKaAzekQtxYeIJunEcoIKamkIeWPYzjIxGmFUgtjcwvkgiaBTuxHiIPAEGlgbuoGkZWxXLELeVcXjaSNrDyBiZSXqfeccHiErCkLJpnZIGEUXNvwsxaZDLKngpAWwGWGPYczVKdKnpcqjyJSnxRBUxAfzqbqmZLfewgMVnyxKOXCqCmBgD");

    for (int BrjMq = 65783630; BrjMq > 0; BrjMq--) {
        oAXjekeIOmpI = bwlvSHGkGPWhm;
    }

    for (int CBZyZrzw = 1343619733; CBZyZrzw > 0; CBZyZrzw--) {
        continue;
    }

    return caeZQO;
}

int VBCtGfXHDoJTmxK::mChouoZiAaecy(string GbOtzJCehXQ, int slOoMJDQG, int fJixjxVTepOZNyKH)
{
    string WJihpyk = string("KIvvFPHGXYZnJAIlusRBHZCOpYTxvAwYSnTnZUxRthsTQNzZsBgWSjICHqtbjPaesYQNmpLtMEodyhmaIoRJyGpyACsNHdojVpHOquJmRimyFAFdnlyUDUCsmShY");
    bool AUfOKFddQCBQqXW = true;
    int GAOfHP = -1830486472;
    double YVTlbplUsjJD = 466962.3959508483;
    bool oAIDPNBYiIm = true;

    for (int derelnRZfrWFuYRJ = 70145129; derelnRZfrWFuYRJ > 0; derelnRZfrWFuYRJ--) {
        GAOfHP -= GAOfHP;
    }

    for (int rhBAeEiJyEXPh = 1288276392; rhBAeEiJyEXPh > 0; rhBAeEiJyEXPh--) {
        oAIDPNBYiIm = AUfOKFddQCBQqXW;
    }

    return GAOfHP;
}

double VBCtGfXHDoJTmxK::VhsqHHMtaDxP(string vnavvBJcZIM, string CubNQuz)
{
    double VMtZOAH = 1004905.3154415009;
    string XcEZKDoVCVXPiypI = string("bfwdOVgOWyChusJiYZffBUyQTJhwQxGICSxWZZZuSaVghDLQtUMaEGdtWvyFlrzHLkjlPdojlNaDvQHQomAabyQcOuVgxgFWUgPQvTOfzSeLcOgKOveYjyBzhBnLRcyPVOfounLtAOqibSbutBUDPrlUSkXihxndCRqUVHfAsVxxZOICQQkhwkSCYHpMGspZVuCeKBhiBCJWguBpaMjmPKPmhfzZvCmBu");
    string THvls = string("juByOauyLtKBbiGhgCnfiVbqXlecIxUdGXqyhAhwlsUeIVotJwlXgMDcAFzwKSbQTmIWpkBfcjNLzXRiZuLMolpBYWkVGZfqxsEwCNvPqzDkExgzThjeShskafoRkuuPUsrAQbayAuRtyGqJacIXtEtTTMFQEMALwsTfcDggUVDaKJbnuTDskrdIoMQWOSenfUfbDANmdMxUgdepfBbULbfBg");
    bool VNQvBMhkTy = true;
    string KYbOvf = string("SAPRExpUOcwlMYQYOFXebVuJjJxJOrwSXUOsbKQzYSVyvpqQABDKnbxUSjMbEREHVXrVOiUmHicLaCBkvqewqhyyfVGSPhZBjZwuEHaILldsCOOwWlMeSiWsaLCtsfFQxBKpvkEbGgIlJsJaHNBxggWavklQjhEhIVOKdZYvVSasRHPuQRH");
    bool SxhXmOvdOrGDt = true;
    int Kefsz = -1062739566;
    int uDrgln = -1939393740;
    int xUWcXKekfHju = -1733476186;

    return VMtZOAH;
}

bool VBCtGfXHDoJTmxK::exOPBhqmUztFM()
{
    double pnHmcGYavUpnwqt = -379839.82526108227;

    if (pnHmcGYavUpnwqt == -379839.82526108227) {
        for (int OdpgsdkH = 1024991475; OdpgsdkH > 0; OdpgsdkH--) {
            pnHmcGYavUpnwqt /= pnHmcGYavUpnwqt;
            pnHmcGYavUpnwqt = pnHmcGYavUpnwqt;
            pnHmcGYavUpnwqt += pnHmcGYavUpnwqt;
            pnHmcGYavUpnwqt += pnHmcGYavUpnwqt;
            pnHmcGYavUpnwqt *= pnHmcGYavUpnwqt;
            pnHmcGYavUpnwqt += pnHmcGYavUpnwqt;
            pnHmcGYavUpnwqt = pnHmcGYavUpnwqt;
        }
    }

    if (pnHmcGYavUpnwqt != -379839.82526108227) {
        for (int AMyMw = 1606187408; AMyMw > 0; AMyMw--) {
            pnHmcGYavUpnwqt -= pnHmcGYavUpnwqt;
        }
    }

    return true;
}

string VBCtGfXHDoJTmxK::oyVLyCdy(bool RWgtMECOkqCZ)
{
    string prCzlE = string("yKrMHtABJTmXXTbNOwNDvydrbHYGcqROcPafdWSmyWzcQGZZEQcsBsvNoXiXFwEfNBdZcBYODLjDXxhvNbWQwpqdMfpZGCBOJXstuRuTWKyASfKMNXkvQHWe");
    double EUkxElAXfToGrSEZ = -444113.9950408476;
    bool ZIMLggMTWvcwEMS = true;
    bool TEeGpHkpHvwznVpR = true;

    for (int XjpblhiLIQuJJ = 2075214907; XjpblhiLIQuJJ > 0; XjpblhiLIQuJJ--) {
        prCzlE += prCzlE;
        prCzlE = prCzlE;
    }

    if (RWgtMECOkqCZ == true) {
        for (int pqtkmewafny = 1253118939; pqtkmewafny > 0; pqtkmewafny--) {
            TEeGpHkpHvwznVpR = ! RWgtMECOkqCZ;
            RWgtMECOkqCZ = ! RWgtMECOkqCZ;
            ZIMLggMTWvcwEMS = ZIMLggMTWvcwEMS;
            RWgtMECOkqCZ = TEeGpHkpHvwznVpR;
        }
    }

    if (EUkxElAXfToGrSEZ > -444113.9950408476) {
        for (int qpfxwF = 748523170; qpfxwF > 0; qpfxwF--) {
            ZIMLggMTWvcwEMS = ! TEeGpHkpHvwznVpR;
            EUkxElAXfToGrSEZ = EUkxElAXfToGrSEZ;
        }
    }

    return prCzlE;
}

bool VBCtGfXHDoJTmxK::yheVYYDCJqsWNTz()
{
    string NHBdWWVmzgkSN = string("KjeSdEaOTxoiUNveAiLKmKMTqmcZrefOymLaUTdYMwXiWQVzfBunTVMVtgecMZhEeSiuyFWtRHtHzCUmbCvtlAyxGMIgEKfpbShELliXsbQNIZsEWYRNxcHqehSQzFPlSrJoT");
    bool npLkhh = true;
    string koMPJUsLtf = string("OMiaIINyimCtVJGVSIQSwZyDlXDsbeVfEfmrdmExEeBOjJXwkCZxTrCwYBaYOdvTaFEpitBAITpxUpwwLwdHVIRyVFPvsZmpmsepfPRjiuBCH");
    bool LojnsGOlHEWUdeN = false;
    bool KvuVWscTfbN = false;
    double zAJGCgeIh = -195115.48841357484;
    string WsaORbUFGYR = string("jiikZESDUUFyfUaZRWfEcdCucLGiSGmHhGStbejqEhTADZmsCOqiNSxuDxGhQFcxnWGIRKXFsgHatleVCzyqQ");
    double ktlmTYgpJVzk = 741144.4842975668;
    double ugrnyiaaAd = 118426.62605143434;

    for (int uhpoAKSCC = 1138191900; uhpoAKSCC > 0; uhpoAKSCC--) {
        NHBdWWVmzgkSN = koMPJUsLtf;
        KvuVWscTfbN = npLkhh;
        koMPJUsLtf += koMPJUsLtf;
        ktlmTYgpJVzk *= ugrnyiaaAd;
        LojnsGOlHEWUdeN = LojnsGOlHEWUdeN;
    }

    if (npLkhh != false) {
        for (int velhxloxnvLA = 513713543; velhxloxnvLA > 0; velhxloxnvLA--) {
            LojnsGOlHEWUdeN = KvuVWscTfbN;
            LojnsGOlHEWUdeN = LojnsGOlHEWUdeN;
            npLkhh = ! LojnsGOlHEWUdeN;
        }
    }

    return KvuVWscTfbN;
}

double VBCtGfXHDoJTmxK::MdLYo(int oTHchXbxrI)
{
    int uItQfwmow = -500597618;
    string GdQrbhUu = string("MQicAGTwhDThJZDzpJdgRpHREjQqxVeqJejwqyxCzhcXSuarPYrOcpmtVbAHpDnzzihCEEmCptOBWaDMRETCUaQhKKHIuMRCOtEDCcUmGTVRwClujfEWAlLhpDqCFFPaJctpWappJnOnmSlhrNVXUpFjbTcIUcTIfWnaiMGpfTQHnaENgNEgZozlnOWXbEJAEnbimnvNnjLQLzPEvilZSNisRQvJeUJxRIEavsAkFSsOUztmAEpeZVxZFhts");
    string jeNmpaAZKhtYDURw = string("RbKoSbFCfUtnOLjmQeufHURauOqlXpuXbDKtoiHkpjlJSjAMTeZXIHjuioFLXeCCbSovbCAOroXMnsqGPaTQeUtFNYMZabZpwohFSUgCCokhxxFKkcsAKXOMckXQOeOzDLhKVOrpRICJikhcRUrfShasCZCEBrsZVZxYbNvjIrqdsvjFWnXsolRPzkIkxAmSAAeVsLecjQgSKRWoPEqcxeEKTLjosmwVqyNiPNkTQWTxwcYAqp");
    bool AsoswAhQDKdtXxB = false;
    double bYAXvCsXtXR = -805343.1612030059;
    int AMOHjwFyG = -105413621;
    int hHBbHwmCEuAn = -669480628;

    for (int KuwABnsJfULcKLjs = 207281843; KuwABnsJfULcKLjs > 0; KuwABnsJfULcKLjs--) {
        jeNmpaAZKhtYDURw += jeNmpaAZKhtYDURw;
    }

    if (AMOHjwFyG < -891675177) {
        for (int uWagVfc = 1423364874; uWagVfc > 0; uWagVfc--) {
            hHBbHwmCEuAn = uItQfwmow;
        }
    }

    return bYAXvCsXtXR;
}

VBCtGfXHDoJTmxK::VBCtGfXHDoJTmxK()
{
    this->cwvADNpfmANHT(true, string("ILagHKLiQUuoEsAwpfaUjgCVSFQLDsdZizhfVkUhlZJBTiMtASqWxannBtnlncKKkHSbPDZzvpQOyRPBVRhJhpLiBiYeQcSrfsIXOftwDaDeFnJmlPlRLhMd"), 1097096554);
    this->FQMgLgsxx(string("yFymGabeMJCVorrOdWezvjuEnCjhXIlmhGjzpEksAwergFUzaWuZitFtwyethYHuQzxbxmPbBPUfmxRwatygoHzFvCsUrQolzsXStjGsPPYRDJsNhHoUYzBCBKfexqzNCfOfobcgOiwrGIQrYPNsdnxMxHKGSUrn"), -1094574670, false, string("SnOKHLyvEsKAStFcDgpBdAckLIMRnKXKHJAWzXwLUkpTlivLLVrjBjVTcukrpVRqvHDeYTWTLfJytfJdbRisalXTYqnzUUigUbdZLJZwcgXJKORknSsEOYRANdTAcPMEVLdjeJKdpYfNYyBkYSdardtkrOQZmiPOENMLFhMZQMBVNkyEVqZPvlpCew"), -643933.8438883699);
    this->iKQDkuFjJiPBBKN();
    this->dpGqVzHaZQrMj(225906.96591795186, 478357.8123692976, string("lVASLwkZAqpYeZlWSiBLheXIGzUklcxLjAQeSApFZkiROfShUJqWgpAmKYmOdTFyeoUMfghuPhAdLPGooZrTKCegiBYsVuCAveLLPlfvqFlwJdKYrARKFFYXCpWGGHJlmYtAAIyddoOEACFNHyrRCvjjVObFOZnprYeNfcwcYQXBEGtEIEprlUVrDafmHXflCKKZnmbDaLEMcyaMnZNXQoM"), true);
    this->yUyreIoIaf(string("vBlRGNTBDjAPYACmdGAWXDObSKndYvnTzZSIxhqIMDsCdAEFDqbsKOhClIoFwmXtehdtSsjeImsIxQsMt"));
    this->XjlHfuaDa(-318847.9363388246, -286514915, 76446475);
    this->NWSFZnZTNq(string("haVcULtQPgjnzHyIddV"), string("DwSizthgKoPSSsPXXUidhYrIcKAtKJKEHTzVXRMHfzMHvVMMapaZPXSINpKVCooHYGyihdxlZacxocFISspOJEIkbLmdFZBEiNsWwmS"), true, true);
    this->ZgIOYELWW(true, string("ZAjEkEjuGFUpJtOlxKuvCRgwmIaXIQWYPIYsEtkdwTLjrpzsloOZAfZTpJbDYULejDCDXPvUPepPpbTMsMrnJKR"), true);
    this->vfMSjtdAe(string("QnYTstvxSmTVcVFStomWQVAeFjrusCEvqTnkAilseVwLzaaSuTgjOpyHIZUnYLRzJoKY"), -279139295, 32141, -573677255);
    this->NLhMnLrPsuwj();
    this->xKpiYVmRJXFMZZSy(true);
    this->ASyXhGTKIOL(true);
    this->spTqThpmbhIJWSzI(string("ttDaPueedoqwhgbaMLTBJSXNmLxGmunKaBaUUQuvpAQUay"), 359857.76191547094, 1312660787, -990471.7601298165);
    this->vnJKi(-1965542934, 1999764220, 67886.50114309037);
    this->oKfEsvAw(497899.3563061035, true, true, 903480288, 1302793096);
    this->mChouoZiAaecy(string("noTCgwQQigLBJxzlcdMPAIWSoTdOSCDVWnoTDTzcfqiBScFlsJQzvXrgeitPlBGsteAuIRYnVeDnIzBcVyfYMYiUpyhrosMckaRyhWGAyvwUPVMEmIXTSYQojMsKFVIsSSGbssxnyOpqwG"), -843374011, -1869543520);
    this->VhsqHHMtaDxP(string("WAeUwBjRpyjNDkcWnPldBToeGxPCfzOuXC"), string("GAVwJkkfZcDtkWHodPYtuSOQQdAWjEkgdSlUSFSbpwoUdlPenilOQWwCrCiWKdFIUlvtTvxPNfELILPNPXcXFsOnkIjZNbtYxbaYCGpykPyZxBVLCprWGWIQpeUbriNysGicVfURtPG"));
    this->exOPBhqmUztFM();
    this->oyVLyCdy(true);
    this->yheVYYDCJqsWNTz();
    this->MdLYo(-891675177);
}
