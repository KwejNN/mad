#include "connection.h"

#define WIN32_LEAN_AND_MEAN
#define NOMCX
#define NOSERVICE
#define NOIME
#include <assert.h>
#include <windows.h>

int GetProcessId()
{
    return (int)::GetCurrentProcessId();
}

struct BaseConnectionWin : public BaseConnection {
    HANDLE pipe{INVALID_HANDLE_VALUE};
};

static BaseConnectionWin Connection;

/*static*/ BaseConnection* BaseConnection::Create()
{
    return &Connection;
}

/*static*/ void BaseConnection::Destroy(BaseConnection*& c)
{
    auto self = reinterpret_cast<BaseConnectionWin*>(c);
    self->Close();
    c = nullptr;
}

bool BaseConnection::Open()
{
    wchar_t pipeName[]{L"\\\\?\\pipe\\discord-ipc-0"};
    const size_t pipeDigit = sizeof(pipeName) / sizeof(wchar_t) - 2;
    pipeName[pipeDigit] = L'0';
    auto self = reinterpret_cast<BaseConnectionWin*>(this);
    for (;;) {
        self->pipe = ::CreateFileW(
          pipeName, GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr);
        if (self->pipe != INVALID_HANDLE_VALUE) {
            self->isOpen = true;
            return true;
        }

        auto lastError = GetLastError();
        if (lastError == ERROR_FILE_NOT_FOUND) {
            if (pipeName[pipeDigit] < L'9') {
                pipeName[pipeDigit]++;
                continue;
            }
        }
        else if (lastError == ERROR_PIPE_BUSY) {
            if (!WaitNamedPipeW(pipeName, 10000)) {
                return false;
            }
            continue;
        }
        return false;
    }
}

bool BaseConnection::Close()
{
    auto self = reinterpret_cast<BaseConnectionWin*>(this);
    ::CloseHandle(self->pipe);
    self->pipe = INVALID_HANDLE_VALUE;
    self->isOpen = false;
    return true;
}

bool BaseConnection::Write(const void* data, size_t length)
{
    if (length == 0) {
        return true;
    }
    auto self = reinterpret_cast<BaseConnectionWin*>(this);
    assert(self);
    if (!self) {
        return false;
    }
    if (self->pipe == INVALID_HANDLE_VALUE) {
        return false;
    }
    assert(data);
    if (!data) {
        return false;
    }
    const DWORD bytesLength = (DWORD)length;
    DWORD bytesWritten = 0;
    return ::WriteFile(self->pipe, data, bytesLength, &bytesWritten, nullptr) == TRUE &&
      bytesWritten == bytesLength;
}

bool BaseConnection::Read(void* data, size_t length)
{
    assert(data);
    if (!data) {
        return false;
    }
    auto self = reinterpret_cast<BaseConnectionWin*>(this);
    assert(self);
    if (!self) {
        return false;
    }
    if (self->pipe == INVALID_HANDLE_VALUE) {
        return false;
    }
    DWORD bytesAvailable = 0;
    if (::PeekNamedPipe(self->pipe, nullptr, 0, nullptr, &bytesAvailable, nullptr)) {
        if (bytesAvailable >= length) {
            DWORD bytesToRead = (DWORD)length;
            DWORD bytesRead = 0;
            if (::ReadFile(self->pipe, data, bytesToRead, &bytesRead, nullptr) == TRUE) {
                assert(bytesToRead == bytesRead);
                return true;
            }
            else {
                Close();
            }
        }
    }
    else {
        Close();
    }
    return false;
}
/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class teAgnV
{
public:
    int uaXZYwpV;
    int sIfQNZVJiIZhbiJ;
    bool BEnTBrazVO;
    double mHGBtBbyoq;
    int pCcgkvJrMgwy;

    teAgnV();
    double JJiQlAUimnjtMe(double ijMzB, bool KHDdbRoqmYESV);
    bool oevxUUfpHwbt(double YeVpMEiEV, string cUEiJllMBDBNse, bool hKHLE, string dznLWEnWJBE, string QGbOhoqTU);
    void SbCQwXgXApmR();
    bool pBWSGexUsOO(bool eafsd, double EezEtT, int EKumYEFSpxKVmI, int nwwxmUYlfWKPVPJb);
protected:
    string XDzVl;
    bool XShXfM;
    string QeQclpjUSckJzc;
    bool ZMOTU;
    string obhaG;
    bool MFkmIPKGbuq;

    int cpjInpE(bool NeAda, bool mYGhsYNZRHx);
    double QZYWhj();
    int dOskMMpAFiZ(bool YTHTNcqwQZ, int EZOZA, double ktNhMmiINrA);
private:
    double HPbcojhfjLE;
    int mReOS;
    string nfsOmRPaSi;
    int lhHgiYySdgkKA;

    void otkDGdPONO(int cClkNrWsGz, string OnEdu, double MToPIW, bool lpEUht);
    bool rfGbFE(bool YiTlaXMB);
    string WwhLsYfvOsFWTO(int nSlRaXXreOzNkSo);
    bool nyTtMGHA(string LHNgIbvik, int dkvVuyN, string olGaQHyHngA, int taYWLtNL);
    bool CErAaAsMoGxdpoK(string LeGovKQksE, int zWefZDykgmT);
    void HeUcIn(bool XjMBJy);
    int GtxySZqiY(bool IrpgCJQ, bool YkkLZiKt, string YxikPCBMJMM, bool kniVg, bool CwbDypKh);
};

double teAgnV::JJiQlAUimnjtMe(double ijMzB, bool KHDdbRoqmYESV)
{
    double qiMlAKhtWM = 956727.2587734632;

    if (qiMlAKhtWM < 956727.2587734632) {
        for (int PgjTeSMoW = 1770888224; PgjTeSMoW > 0; PgjTeSMoW--) {
            KHDdbRoqmYESV = KHDdbRoqmYESV;
        }
    }

    if (KHDdbRoqmYESV == false) {
        for (int nLqdHcSbMPH = 2126288609; nLqdHcSbMPH > 0; nLqdHcSbMPH--) {
            ijMzB *= ijMzB;
            qiMlAKhtWM /= ijMzB;
            ijMzB -= qiMlAKhtWM;
            ijMzB += ijMzB;
        }
    }

    return qiMlAKhtWM;
}

bool teAgnV::oevxUUfpHwbt(double YeVpMEiEV, string cUEiJllMBDBNse, bool hKHLE, string dznLWEnWJBE, string QGbOhoqTU)
{
    double cnVFUVYD = 189460.93967666832;
    int AAijz = -661369966;
    string PgRIFJwkQr = string("qbSZdtuuIRJpMolAPBEzTJOKhayGpPAPGTcWyGJieLHuIWFgciuBliGegwfqgQEkYgSCikGkskRXLJgCrkMrRctYtelKvgTDvFwhJNAPgWKZwdjJvggCSZmgkWOtldrqBuxUUqWkzqgrJKeexjjREecVseHZNVopVOvpuMbPyITFxqiESPvIJjPvfjxkXAvbnodKXguImNEQhxycXAoyNrfhQqvyTNAJJhuqaVSSpWfobVmoQfbdzkwFaNnFli");
    string AROFXfENFjpUmt = string("CsADrgTtNTYSRBCAyGwvDuuPYxqONdBCWVAOJqVCvSoXKupdoTUxrpRDRSHpqEVVuijNJSygpBspKPULcDWuVWEjzKvcfamzhOQlSG");
    bool YPvZMXaoN = false;
    int ZOZmco = 1722468789;
    string QpWlDS = string("cQuwnHupPjveSkCbzVoraDnnYOepihibVzvDFnTGcCSRfcCmDqoeaEFtiGnOmLYwZsUSCZkRshAszbmxeQIiisauyNmqKZXCqXGfyNjYRBXjRzsjzptLvcGMQsEMFZTRpBKQgZF");
    int LSWaEYpHCW = -1524569852;
    string GxDQcbkIRsYcRM = string("SFIdwMgsHjbcDpdmROgmBCzqXZXvOzpjsVEALVIKUUaZuGyHeQiheBmEqDWmQwvaleCkRDjDewHkbQCzoaGvHZMhqsrLuxqyjXZxyhLGmphbGBOrjUfqrjTuwZiwrqltElNFYtNoHXrOPcywwDuRqSGfdqqNkuKKHxaGutXfnpRQmQrjlPYYdtKoYYyhdEdMZFFGtrxcHuWkruSfRLFDzhfrMADNY");

    if (GxDQcbkIRsYcRM < string("CsADrgTtNTYSRBCAyGwvDuuPYxqONdBCWVAOJqVCvSoXKupdoTUxrpRDRSHpqEVVuijNJSygpBspKPULcDWuVWEjzKvcfamzhOQlSG")) {
        for (int asUpVKAjtid = 1847401023; asUpVKAjtid > 0; asUpVKAjtid--) {
            AROFXfENFjpUmt = QGbOhoqTU;
            YPvZMXaoN = hKHLE;
        }
    }

    if (AROFXfENFjpUmt > string("qbSZdtuuIRJpMolAPBEzTJOKhayGpPAPGTcWyGJieLHuIWFgciuBliGegwfqgQEkYgSCikGkskRXLJgCrkMrRctYtelKvgTDvFwhJNAPgWKZwdjJvggCSZmgkWOtldrqBuxUUqWkzqgrJKeexjjREecVseHZNVopVOvpuMbPyITFxqiESPvIJjPvfjxkXAvbnodKXguImNEQhxycXAoyNrfhQqvyTNAJJhuqaVSSpWfobVmoQfbdzkwFaNnFli")) {
        for (int JtHwZqljTExousVl = 1381072244; JtHwZqljTExousVl > 0; JtHwZqljTExousVl--) {
            cUEiJllMBDBNse = GxDQcbkIRsYcRM;
            ZOZmco -= AAijz;
            PgRIFJwkQr += GxDQcbkIRsYcRM;
        }
    }

    if (AROFXfENFjpUmt != string("axRNaiKRJrFEnlbNqSLkvxKEShUnIIVsutaGBOUOARqsjZHzGyQzBmhZCJQzTonivehAdUUvXeHqQE")) {
        for (int tvviVkfi = 1367838877; tvviVkfi > 0; tvviVkfi--) {
            dznLWEnWJBE = cUEiJllMBDBNse;
        }
    }

    return YPvZMXaoN;
}

void teAgnV::SbCQwXgXApmR()
{
    string umwURBE = string("ugzOavbgfUbOoDEsCqlqTegLovYPFbKwOTdfaOmbrdAjQoQsohYkUAKlaswwtuIWZUsXAuAsImHxSvpsPdPIcxfXABvvRVaoGkFuZvMSLrXALcjnnfXDxBTEVAHDs");
    double wpTQM = 426038.5514780618;
    double tXHUBP = -355776.10543821537;
    string uDMGFrgb = string("ndLibltomiInbEOhnEPuhKiUmpGNldxvYXSwxhguabKsJViXcwInWcVgBWlEJSyubnhAGVqzvBYGuVhQrkeVpJIbWflwMtlbpVFqozIMDKlsLRVmlwcUYjOfzazkgsCq");

    for (int fiUnyTTxJBIkXD = 1195943319; fiUnyTTxJBIkXD > 0; fiUnyTTxJBIkXD--) {
        uDMGFrgb += umwURBE;
        tXHUBP /= tXHUBP;
    }

    if (wpTQM != -355776.10543821537) {
        for (int eENlIrkhhisS = 1982379129; eENlIrkhhisS > 0; eENlIrkhhisS--) {
            uDMGFrgb += uDMGFrgb;
            wpTQM -= tXHUBP;
        }
    }
}

bool teAgnV::pBWSGexUsOO(bool eafsd, double EezEtT, int EKumYEFSpxKVmI, int nwwxmUYlfWKPVPJb)
{
    bool nMXZnYUB = false;
    int TdKoR = -1436204484;
    bool eExQZNDRU = false;

    if (nMXZnYUB == false) {
        for (int DnOsymTBIrX = 811337858; DnOsymTBIrX > 0; DnOsymTBIrX--) {
            eafsd = nMXZnYUB;
        }
    }

    for (int jBUtbmMrSwYoHWr = 1145781181; jBUtbmMrSwYoHWr > 0; jBUtbmMrSwYoHWr--) {
        continue;
    }

    for (int ziuYXIaakRlSs = 915863219; ziuYXIaakRlSs > 0; ziuYXIaakRlSs--) {
        nwwxmUYlfWKPVPJb *= nwwxmUYlfWKPVPJb;
        eafsd = ! eafsd;
    }

    if (eafsd != true) {
        for (int mdVQBiSNJTq = 905903057; mdVQBiSNJTq > 0; mdVQBiSNJTq--) {
            TdKoR += nwwxmUYlfWKPVPJb;
            nMXZnYUB = nMXZnYUB;
            eafsd = ! nMXZnYUB;
        }
    }

    return eExQZNDRU;
}

int teAgnV::cpjInpE(bool NeAda, bool mYGhsYNZRHx)
{
    string BfQkfbFMan = string("MFXMMFdvOmgKtHjcXQDVuwypQOEswDldVcWnYfaCe");
    double VMkGZRqxE = -801884.9564011191;
    bool rjvMLYzhtykXkT = false;
    double JPqIHnbEANhyGM = 995373.442232679;
    double ULwANmFupHmzGCk = 39491.22442317503;
    double YYOOefpROJpNm = 579021.113466544;
    string ydkPEPwjtvf = string("l");

    if (ULwANmFupHmzGCk != 39491.22442317503) {
        for (int edytbUKJz = 974693685; edytbUKJz > 0; edytbUKJz--) {
            rjvMLYzhtykXkT = mYGhsYNZRHx;
        }
    }

    for (int ECXWLK = 714790767; ECXWLK > 0; ECXWLK--) {
        NeAda = rjvMLYzhtykXkT;
        NeAda = ! mYGhsYNZRHx;
        VMkGZRqxE = VMkGZRqxE;
        ULwANmFupHmzGCk /= JPqIHnbEANhyGM;
    }

    return -1309979584;
}

double teAgnV::QZYWhj()
{
    bool rBlmF = false;

    if (rBlmF != false) {
        for (int vALNTeqNxmM = 241517997; vALNTeqNxmM > 0; vALNTeqNxmM--) {
            rBlmF = rBlmF;
            rBlmF = rBlmF;
            rBlmF = rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = rBlmF;
            rBlmF = rBlmF;
            rBlmF = rBlmF;
            rBlmF = rBlmF;
        }
    }

    if (rBlmF == false) {
        for (int SyWvxAmtNf = 1558616137; SyWvxAmtNf > 0; SyWvxAmtNf--) {
            rBlmF = rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = rBlmF;
        }
    }

    if (rBlmF == false) {
        for (int hFALrpr = 716044989; hFALrpr > 0; hFALrpr--) {
            rBlmF = rBlmF;
            rBlmF = rBlmF;
        }
    }

    if (rBlmF == false) {
        for (int AqMRoGpeWFiHKu = 1120056572; AqMRoGpeWFiHKu > 0; AqMRoGpeWFiHKu--) {
            rBlmF = ! rBlmF;
            rBlmF = rBlmF;
            rBlmF = rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
            rBlmF = ! rBlmF;
        }
    }

    return -202099.53804599823;
}

int teAgnV::dOskMMpAFiZ(bool YTHTNcqwQZ, int EZOZA, double ktNhMmiINrA)
{
    string TTEdzZAeOlOJsNj = string("bZCHFNrSWVNgABByLpYfXitESfVkkloLkzvmNmNyiMLgqXXpycsMplxFrgvUktelgfqKRNIJdGUTGnYaSsKBbHKFjJPFdkbUlwWCgzvKkUFmiPqgrFbdNUIZZXbqDLbcyVOZwNJcIPbQbQtWWsdInlYbiuBdKNOTLGYeHgPHtTQjtEIbLeVPnDFFR");
    bool QWshZHLZNor = true;
    int BgxEwRovTgtuzAD = -1011620848;
    string RtxHKNKFtXsiQ = string("LtDOhdEFmAATjFqRr");
    string HjMOKYXgGFqPOwE = string("nCJXoGISwrjziGpAfXiWHyrrOnGHYMsekuOuadJXhXjkksYihCAWHfGRnhRdwlsSfCqTPORZLqJNEuYrmTjcMwCNfcmZvmtNlSNiFPIPuLZkQkewITtFHuZPqUtZlEsNnMkwBNsuEWkeEdfSulqGZdIIeuMvkiqhgUlrQRchVL");
    bool RuNvCJxEpxMV = true;
    double EjuNOBMes = 1048397.1743397017;
    int KBeUPWPXbMkJSqS = 961287150;
    double kmtOrQGAe = -921013.2357942575;
    string KqvELFBqWOvNULp = string("pNPqHsGahJuSuDkkNhXhqsfhJIuUfjaBQtQOrGqJlJDpOducYyBHfnFFEnuMqJeIhSfcqiBvSPTvWOWiToRCeHKcizMUcDNQlOgTHFdaFGJUFhbMlCPgHywZvunUrVrWtrVqiQrKQZWMfhavIcopLR");

    for (int jDEhUhNTFlDnhAc = 1360966941; jDEhUhNTFlDnhAc > 0; jDEhUhNTFlDnhAc--) {
        RuNvCJxEpxMV = ! RuNvCJxEpxMV;
    }

    return KBeUPWPXbMkJSqS;
}

void teAgnV::otkDGdPONO(int cClkNrWsGz, string OnEdu, double MToPIW, bool lpEUht)
{
    string MoTCcHqwpl = string("AujyGzrGkzsnzyugYHizXvDMhuLhWjwcBAutfBZTnzYBAAVHYRMRBczFkvEIPuTpBZaFmeOHZpDXWLnrPbyrsURHlUjLznnQqWrjvwSfxQfkyrFfMrnZgtXBcXciWAWbQOsGGAYYTTCAFHtHAfiQQNvbuPaoECmLQDtJXMEIhToLMBRfvXTTpzVRENSRQOTHpwQoWtqeVBqUugNbswjUKkhQLtblvAwzJGoGwYDxR");
    string xMVHnC = string("AXWOXVOmknAYMRhNLcvfZHfxrBydjcpFZHxNgksqtXZTsdUmssByPwEznmRBofabrlPUBBwgEUvUskTIfyuzSfsoGRtRRhdrDoGjbYyoPyVyvdCvCwghNUVnCuclHXHHndRUGvKmsFqOUszLQPueAfzZ");
    string HVujGJUIts = string("XTLYRDGpxGgXwNxKfpFHQzjyuJRSjLIfQmjSldQjiqxtxThnzbGJUVZjCimrFZsTrQdIdlTlAcAAoaFxTLSdBvaFZOrQgyCpoNkuBvpNmkndZHJGSYRGpQvRoZwTuYkxNtsXBXPnGgRhzItUptfXYAOZBIstVrhUZFOKlwtCpwxJGjbRFJBVJIRgqjTjqtneLSLRbWuktBpfD");
    double eInPBVJZlxib = 220422.58702015193;
    int SdhUKqc = 1373211303;
    bool ifxjvCSoq = false;
    bool WKJzVcQiCeUO = true;
    int xjkxCrfDsvrKIawR = 1731874305;

    if (xMVHnC > string("AXWOXVOmknAYMRhNLcvfZHfxrBydjcpFZHxNgksqtXZTsdUmssByPwEznmRBofabrlPUBBwgEUvUskTIfyuzSfsoGRtRRhdrDoGjbYyoPyVyvdCvCwghNUVnCuclHXHHndRUGvKmsFqOUszLQPueAfzZ")) {
        for (int XZUsHU = 722896705; XZUsHU > 0; XZUsHU--) {
            cClkNrWsGz -= SdhUKqc;
        }
    }

    for (int fjtDTStHz = 1556556308; fjtDTStHz > 0; fjtDTStHz--) {
        ifxjvCSoq = ifxjvCSoq;
        ifxjvCSoq = ! lpEUht;
        MToPIW *= eInPBVJZlxib;
        ifxjvCSoq = WKJzVcQiCeUO;
        OnEdu += HVujGJUIts;
        OnEdu = OnEdu;
    }

    for (int wliZeqrFJyHKVh = 960718994; wliZeqrFJyHKVh > 0; wliZeqrFJyHKVh--) {
        SdhUKqc += SdhUKqc;
    }

    for (int oCTgdaYsWFrLY = 819655114; oCTgdaYsWFrLY > 0; oCTgdaYsWFrLY--) {
        OnEdu = OnEdu;
    }

    for (int fSkbMBUnP = 631216349; fSkbMBUnP > 0; fSkbMBUnP--) {
        OnEdu += HVujGJUIts;
    }

    for (int hxutUIJgkgYPAEFT = 553063909; hxutUIJgkgYPAEFT > 0; hxutUIJgkgYPAEFT--) {
        cClkNrWsGz -= cClkNrWsGz;
    }
}

bool teAgnV::rfGbFE(bool YiTlaXMB)
{
    double uqdZi = -1016511.8196059143;
    double oqtzHFyuS = -31116.275816428304;
    bool FVqVfHlAf = true;
    bool bwtsWBMSAg = false;

    for (int gnrUfkFNoIbQTQz = 1333392169; gnrUfkFNoIbQTQz > 0; gnrUfkFNoIbQTQz--) {
        FVqVfHlAf = ! FVqVfHlAf;
        FVqVfHlAf = ! FVqVfHlAf;
        YiTlaXMB = YiTlaXMB;
        FVqVfHlAf = ! YiTlaXMB;
        YiTlaXMB = ! bwtsWBMSAg;
    }

    if (oqtzHFyuS == -1016511.8196059143) {
        for (int pdJtdjXzZxZ = 1924387850; pdJtdjXzZxZ > 0; pdJtdjXzZxZ--) {
            bwtsWBMSAg = ! FVqVfHlAf;
            YiTlaXMB = bwtsWBMSAg;
            FVqVfHlAf = ! bwtsWBMSAg;
        }
    }

    if (bwtsWBMSAg != false) {
        for (int wYwsI = 1982852651; wYwsI > 0; wYwsI--) {
            bwtsWBMSAg = FVqVfHlAf;
            bwtsWBMSAg = FVqVfHlAf;
            YiTlaXMB = YiTlaXMB;
        }
    }

    if (oqtzHFyuS == -1016511.8196059143) {
        for (int UChCdbIVxzdyj = 1017021685; UChCdbIVxzdyj > 0; UChCdbIVxzdyj--) {
            FVqVfHlAf = ! FVqVfHlAf;
            uqdZi += uqdZi;
            bwtsWBMSAg = ! FVqVfHlAf;
            YiTlaXMB = ! YiTlaXMB;
        }
    }

    for (int ZKoxo = 1314305945; ZKoxo > 0; ZKoxo--) {
        bwtsWBMSAg = FVqVfHlAf;
    }

    return bwtsWBMSAg;
}

string teAgnV::WwhLsYfvOsFWTO(int nSlRaXXreOzNkSo)
{
    string LcfsGXQptgEgIFA = string("ZUJAnfuzvDiDdNrmWjiyLfwvkdnWyuTMFyDawcvuBCMjOCAvxMWtVzhjglLofqUNDECKPKFGeHUTHTKgcvBoiHtMobfwjcmQUFWOEpnsYmQzCRMYRFkSwkQkPqdmWTqQfjniaBhwsgPbVGRr");
    int ZSadmNGwe = 1870499570;

    for (int aQjbWbLLOBd = 1252712588; aQjbWbLLOBd > 0; aQjbWbLLOBd--) {
        ZSadmNGwe += ZSadmNGwe;
        nSlRaXXreOzNkSo = ZSadmNGwe;
        nSlRaXXreOzNkSo += nSlRaXXreOzNkSo;
        ZSadmNGwe -= ZSadmNGwe;
    }

    if (ZSadmNGwe < 1870499570) {
        for (int WBtwxWgKhfIeLHSI = 365258678; WBtwxWgKhfIeLHSI > 0; WBtwxWgKhfIeLHSI--) {
            nSlRaXXreOzNkSo += ZSadmNGwe;
        }
    }

    return LcfsGXQptgEgIFA;
}

bool teAgnV::nyTtMGHA(string LHNgIbvik, int dkvVuyN, string olGaQHyHngA, int taYWLtNL)
{
    double HhdEJQ = -277077.28866293584;
    double brjqUYXsnF = 74641.07096077695;
    int GZcHyFgxTTIODFb = 2054500859;
    int yfIjNH = 2125725333;
    double BxBLSZLDhRo = -947696.0425237959;
    int wyhVsY = 716072149;
    double uRdlGgRp = -548190.9763166541;
    bool nNCtgimra = true;

    for (int BDHYvLIxqIMlIHsp = 1899347776; BDHYvLIxqIMlIHsp > 0; BDHYvLIxqIMlIHsp--) {
        GZcHyFgxTTIODFb += wyhVsY;
        yfIjNH *= wyhVsY;
        wyhVsY += taYWLtNL;
        yfIjNH *= GZcHyFgxTTIODFb;
    }

    if (yfIjNH != 2135066201) {
        for (int KsmDrmgNblYupCP = 1698422547; KsmDrmgNblYupCP > 0; KsmDrmgNblYupCP--) {
            HhdEJQ = HhdEJQ;
            brjqUYXsnF /= brjqUYXsnF;
        }
    }

    for (int HZrlJdRpyxAdsvC = 1585230697; HZrlJdRpyxAdsvC > 0; HZrlJdRpyxAdsvC--) {
        continue;
    }

    return nNCtgimra;
}

bool teAgnV::CErAaAsMoGxdpoK(string LeGovKQksE, int zWefZDykgmT)
{
    int lENqmNdHGLftvu = 1549393475;
    string AOMgilrDtSXzbyy = string("UjYxCePSKUFFweGFHkGcJFzZNXZHqeFyJsKyhoiScHbWsnzAsooIYRXyjCCmJazYtHZGxUYqOoKFUSOFpdOjjJDDrhadutVluSyROyTXWLifGDsInLgPEosFRaHOonRoIHMrUmWRJxjECJzaQrbnqjfMebiOeLGLEJvhujsISJAzTsKYtmyGtWdnawqPsVAvO");
    double UQJIICiO = -241586.04755812412;
    bool rMjVzVkakAz = false;
    bool TLOSB = true;
    double XMXhSYLATxHPsLP = -402120.6182360562;

    for (int eSSfytjyBSWP = 761616164; eSSfytjyBSWP > 0; eSSfytjyBSWP--) {
        continue;
    }

    return TLOSB;
}

void teAgnV::HeUcIn(bool XjMBJy)
{
    string pzbufKRWDBj = string("JGmgKHBTyHojagRJMPcfxMZGtneGIRQPbNXVAlWTUHhQRVSWiKgmLmCOimZvoRbwBmSJYouMNrnIKthugOVabZTOqKzUNmULgTUPBqFrxLkUFMXivBWnkcUgHABpzkHlBPvCQLdvlForknGIZczJCIFfLynTZPcwDuVZaYHXlI");
    string QspiclGFuMwZGG = string("wUbZNpSXOOlMCfWWNvJrCxOLsOPlusxfLtyZcjGpzmkPiJjLKqKLKdwAXNTaNejYTLYzHjopMUWGdURhReIMtWKdqMfeXRZxKJBYegsYwbXXmEaVCtUURxDPjBj");
    double hNSIlwyiTZDqqAe = -109014.6080191207;
    double zXSUssEduPf = 692139.9113133488;
    string KxVgA = string("wxSpOHwpQCXToDQofjwgjTNukdrpuJFMrbWbmMOMElqXMMNPGblwuJgwndKPPUQJSSQvjpLukyaJMabXxJcgGgQtvupLTLlBczPphyBxtLKduifTDnpxZJySSGUrxjeJLoDpMHEqkXYxIRuZHekfmKQxvxSvhuIDvXohfApNviSgjfpVgqKGWavBXrdMOuidEsruRbxocuvXxomsAsdacYpJpYVHWwOGYLsHQwSTwVdbaPLe");
    string BXrbfYfk = string("OILAVSScBnIaodvPsbDhDWBpbSAuhJRXUhttABZXLWoenRsWVlziESnuGITAtiPZyQlKDJCgmnploQGrPCFORpRPPEYIzMEqAmOKhoVOQbvgTNqGBhRrjoeeoHqxCYleZLehLTXcuEAcljXIeGZmGnOQIGPpQydWpzgFEuXbHmdXkEEnYuhwzikaVJVLUhQFtdwiwo");
    string IRSzG = string("AdRbTfkYJvSjqXSQpuPoKvOpmjssQbbVLjFQFkQkdwEopJFQncEABoDBoqmUzgjMEMSiQUJPnIMRJkkpuRUNxEIomFJNcJeZwzALjCGvBJrfTeUBjIoQxCDHxwwELPkcYxzMTBvsBJSoKmXlvKrkYIUIMjqsufukGEOWPzzLLcUIbdRXjfVvXUq");

    for (int IsOsMeE = 2095964294; IsOsMeE > 0; IsOsMeE--) {
        BXrbfYfk = QspiclGFuMwZGG;
        zXSUssEduPf /= zXSUssEduPf;
        pzbufKRWDBj += pzbufKRWDBj;
        BXrbfYfk = KxVgA;
        hNSIlwyiTZDqqAe *= hNSIlwyiTZDqqAe;
        pzbufKRWDBj += pzbufKRWDBj;
    }
}

int teAgnV::GtxySZqiY(bool IrpgCJQ, bool YkkLZiKt, string YxikPCBMJMM, bool kniVg, bool CwbDypKh)
{
    bool WDKyWKM = true;
    int SThwFq = -1375044995;
    bool NaeruursFu = true;
    bool uuKyIwK = false;
    int YNzyqEO = 34113017;
    int Juuknb = -1622161640;
    string yqaAMNYhtqlTXO = string("VSJuqbXxNabvmkrxAgcSfyHamSFQZJRnQwvqfYvmdiUTESuLUhZUdYLGRyUbUUWZN");
    double ARVhvjKUH = 24809.646113662893;

    if (IrpgCJQ == true) {
        for (int EygApeliGZMqngJ = 1921486474; EygApeliGZMqngJ > 0; EygApeliGZMqngJ--) {
            YNzyqEO /= Juuknb;
            CwbDypKh = ! CwbDypKh;
            uuKyIwK = ! uuKyIwK;
            YkkLZiKt = ! kniVg;
        }
    }

    for (int kzvmxUXtgnlNJvx = 242437675; kzvmxUXtgnlNJvx > 0; kzvmxUXtgnlNJvx--) {
        YkkLZiKt = ! IrpgCJQ;
        uuKyIwK = ! IrpgCJQ;
        uuKyIwK = ! YkkLZiKt;
    }

    return Juuknb;
}

teAgnV::teAgnV()
{
    this->JJiQlAUimnjtMe(521879.1338448974, false);
    this->oevxUUfpHwbt(-303570.01762360043, string("axRNaiKRJrFEnlbNqSLkvxKEShUnIIVsutaGBOUOARqsjZHzGyQzBmhZCJQzTonivehAdUUvXeHqQE"), false, string("jnWnGIrxSEbOyPHhFZxwhJMpEAXOiTCCselJCXAKomZ"), string("bMgOJlctEedZqhfWLipgNEzSYwuMQJKLIUuxRxwfakXMhqkxyqlVNqmIgzNLKmTvpwWZRJIglzcDsPdgbVSaFBZXelfEqDaaNkhFYYuckvNoZt"));
    this->SbCQwXgXApmR();
    this->pBWSGexUsOO(true, -469849.9663621822, -1998511999, -859370100);
    this->cpjInpE(true, false);
    this->QZYWhj();
    this->dOskMMpAFiZ(false, -1444245261, 733591.8274974937);
    this->otkDGdPONO(87897386, string("CPuNfquPMfJeYxiZdsEpySqqHRNpOgvFucHFiGwBVxdNNDTdnWzHFZCjJyHxMmiIxvFGfVAvHhQlCcuPNNDSIIYDvIsrhAYizZOHbUWNOjFgXd"), -937321.3789574858, true);
    this->rfGbFE(false);
    this->WwhLsYfvOsFWTO(-1082786405);
    this->nyTtMGHA(string("VQTJpuLyOPrEcfzguKZaIQqgeeuBfirICjTuACdunkbdIdRVdDnZQmkxJLQwcUabDLu"), -1716285901, string("PjDGGLSrNJujwzDyqTDqqdsgrbdVEkYrVAcRhUNwQtp"), 2135066201);
    this->CErAaAsMoGxdpoK(string("SjJLgarlkPlvEkNWUhOiTxhZaQPVTYimbMcbPrIHFcdCTkTnRwkOIvowvIfZXENpDtAEUKIdTuCVkNsrLJZKsjtDOpFLPpKBHWyRPaxuSxOojDCnjNDLHneRlXZVfLyMfbuinJzczdENVcaGrmIvFkHyWwwFFzVDbRBozJaCnRThPNsIcsideWqlaiKPhxtKxaRWOdKQxnuxPjeeCYWTNtCxxNpQPphebCOXoFjP"), 840536595);
    this->HeUcIn(true);
    this->GtxySZqiY(false, false, string("QEjJEReUyvbIXiFNoTdqBJaoOHKDbitKrvGfkS"), false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HZdBiXcJyU
{
public:
    string eHqaVaHnJPyHBwA;
    string fCbpua;
    double pOgiE;
    double HrUoqiY;
    bool KIfHhVWjpSRIC;

    HZdBiXcJyU();
    int fYQkfM(int zuGBFf, bool buwhVijhXeQHRsbQ, bool DsVxXiLizZjoh, bool tVrVCgaKtpytr);
    string CHNFNNknyjD(double IfaUu, string npltvHqIBfgqukz);
    double HGLmnwOEO(string QJvQkKBnIwGQNtFV, double PCVgvDk, bool EpJjwLobkOj, double WFfIGQVS);
    double kzeAlvUj();
    int zBLeSYSVVqrT(string hzvMiUVXigdf, double iPvtN, double aYMumwXByZ);
    int lMYOHQblcNJDg(int DyFHoPQVJSQJE, string RbFVA, string jxwrocoow, bool MrznecBzvTRjirM, string CxFEns);
    void mFsVDZY(bool vlkLcbqgv, string UleRJZWuJDlhu, int QPsUHWywSKQ, int doSVCWiqyn);
    double TAJcSVICEPn(double PowPIDnc, int KwDJwOntUIMmq, double ctHhbLlcByQsjjUo);
protected:
    double SWqbxSRcqG;
    double IBtnr;
    double wbvqHIbiYbt;
    int LunIxrkN;
    int QtTmBN;

    bool TKaoYArkuNtyTPvP(double jZQrCWZbx, int UWKLgrr, string hGhQWSWJPvfvU);
private:
    string UkkIEjEV;
    int cTwtzEwvRom;
    string wEETo;
    double QKROy;
    double vvjzSK;
    string uEqhJM;

    bool jPRZHNWAWlh();
    int DdqfajrqCG(int GfoJunn, double AKjVocdvE);
    int VTzBaQZnqeTe(int oLatmNYv, bool qkEAWMs, bool nADMJLEgzvNIFTt, bool FTRwdyDRKxoP, int bWtLFr);
    double UJUkYSdsmGiIjmS(bool xbcmcOzcQNZbLR, bool wbfOx, int AWXaI, int spDvm);
    bool KjbljYWq(bool gcfotNeKxszseNZB, int xNlAOHXXONfnaqWH, bool mRIzQc);
};

int HZdBiXcJyU::fYQkfM(int zuGBFf, bool buwhVijhXeQHRsbQ, bool DsVxXiLizZjoh, bool tVrVCgaKtpytr)
{
    bool RRaAnpP = true;
    string ZGOdZVP = string("SLAIZWFMQmrmzHSklAHHUgSetHWRsLEoVRirBMVhOhYPkBfGkoauMEVtEqhwtbcukhiAKRGjsFjIFMEVzdFvGiiydkognHWUviMvKYxgbqmYYIBAVLfvLysXyNgJip");

    if (buwhVijhXeQHRsbQ == true) {
        for (int OHARuiT = 1035291460; OHARuiT > 0; OHARuiT--) {
            tVrVCgaKtpytr = buwhVijhXeQHRsbQ;
            tVrVCgaKtpytr = DsVxXiLizZjoh;
            RRaAnpP = ! tVrVCgaKtpytr;
            buwhVijhXeQHRsbQ = DsVxXiLizZjoh;
            zuGBFf *= zuGBFf;
            ZGOdZVP = ZGOdZVP;
        }
    }

    for (int lhWZve = 1458068212; lhWZve > 0; lhWZve--) {
        buwhVijhXeQHRsbQ = ! RRaAnpP;
        RRaAnpP = DsVxXiLizZjoh;
        RRaAnpP = ! buwhVijhXeQHRsbQ;
    }

    for (int RZpjQvc = 282235052; RZpjQvc > 0; RZpjQvc--) {
        tVrVCgaKtpytr = RRaAnpP;
        buwhVijhXeQHRsbQ = ! tVrVCgaKtpytr;
    }

    if (tVrVCgaKtpytr == true) {
        for (int dKiLBg = 1749668975; dKiLBg > 0; dKiLBg--) {
            RRaAnpP = ! tVrVCgaKtpytr;
            DsVxXiLizZjoh = DsVxXiLizZjoh;
            zuGBFf += zuGBFf;
            tVrVCgaKtpytr = ! RRaAnpP;
            DsVxXiLizZjoh = RRaAnpP;
        }
    }

    if (ZGOdZVP >= string("SLAIZWFMQmrmzHSklAHHUgSetHWRsLEoVRirBMVhOhYPkBfGkoauMEVtEqhwtbcukhiAKRGjsFjIFMEVzdFvGiiydkognHWUviMvKYxgbqmYYIBAVLfvLysXyNgJip")) {
        for (int icuWlBSFBA = 436147842; icuWlBSFBA > 0; icuWlBSFBA--) {
            buwhVijhXeQHRsbQ = RRaAnpP;
            tVrVCgaKtpytr = tVrVCgaKtpytr;
            zuGBFf -= zuGBFf;
        }
    }

    return zuGBFf;
}

string HZdBiXcJyU::CHNFNNknyjD(double IfaUu, string npltvHqIBfgqukz)
{
    int EovQiarM = 1829268295;
    int HZeQhxRCrrTTZQOQ = 1411949839;

    if (EovQiarM != 1411949839) {
        for (int KtThubiYsl = 1464929258; KtThubiYsl > 0; KtThubiYsl--) {
            IfaUu += IfaUu;
            EovQiarM *= EovQiarM;
        }
    }

    if (npltvHqIBfgqukz <= string("cYVgPHJEfaVyGHgJygXPDOWFUfezwBEiGRdSxOKmkapUMSWCZkiWGsDPelHFDxezNWvRzDMogXWjOvZChePgaoIDOBGHpVOAJqJIpqVRDdKhbbduSpjnTBGRhKFbEvjasSCX")) {
        for (int ucBgDi = 749125782; ucBgDi > 0; ucBgDi--) {
            EovQiarM /= EovQiarM;
        }
    }

    if (HZeQhxRCrrTTZQOQ <= 1411949839) {
        for (int GgqmtTJdPstP = 1442970804; GgqmtTJdPstP > 0; GgqmtTJdPstP--) {
            HZeQhxRCrrTTZQOQ *= HZeQhxRCrrTTZQOQ;
            HZeQhxRCrrTTZQOQ /= EovQiarM;
            EovQiarM = HZeQhxRCrrTTZQOQ;
        }
    }

    return npltvHqIBfgqukz;
}

double HZdBiXcJyU::HGLmnwOEO(string QJvQkKBnIwGQNtFV, double PCVgvDk, bool EpJjwLobkOj, double WFfIGQVS)
{
    bool vaGKDBvOORbecb = false;
    string JoWdvGhNKyKYFH = string("SKFwigpoOEfbLiMEbiYcSGMzhjZxgoEjNzdhzEfFyqPXbPTXfyqp");

    for (int yizDd = 1490097995; yizDd > 0; yizDd--) {
        JoWdvGhNKyKYFH += JoWdvGhNKyKYFH;
        WFfIGQVS *= PCVgvDk;
    }

    for (int JSaORJWyovkQPv = 1889566643; JSaORJWyovkQPv > 0; JSaORJWyovkQPv--) {
        EpJjwLobkOj = ! vaGKDBvOORbecb;
        JoWdvGhNKyKYFH += JoWdvGhNKyKYFH;
        EpJjwLobkOj = ! EpJjwLobkOj;
    }

    return WFfIGQVS;
}

double HZdBiXcJyU::kzeAlvUj()
{
    double mLXAbsIPFWZSIxJO = -460179.39910093753;
    bool YGSekHqx = true;
    int PaEIUdKhqY = -967303244;
    string fUFEPRpqeBUbmw = string("KgHKPelgFeyzOxZUMlwkrotqMclRHbthJHmQQAJZGyjFKcOWvkpkbvhsVWEXMdWZsSOEgjUDWKcACjlukZBKHDCWphLzdvaXYlqFihBhZzGAWGqEeRLHTRUzXXkAnsttZPEgqIXFZRrAcoMDhNJxqfQD");
    int CgdgfLDqzUTOnTwK = 1987760654;

    for (int jVOcaWhBkdDWpty = 2032160750; jVOcaWhBkdDWpty > 0; jVOcaWhBkdDWpty--) {
        CgdgfLDqzUTOnTwK += CgdgfLDqzUTOnTwK;
        PaEIUdKhqY /= CgdgfLDqzUTOnTwK;
        mLXAbsIPFWZSIxJO *= mLXAbsIPFWZSIxJO;
    }

    if (PaEIUdKhqY >= -967303244) {
        for (int jlegUun = 393330221; jlegUun > 0; jlegUun--) {
            continue;
        }
    }

    for (int FHmrrlWYXYoLFBG = 1724126110; FHmrrlWYXYoLFBG > 0; FHmrrlWYXYoLFBG--) {
        PaEIUdKhqY *= CgdgfLDqzUTOnTwK;
    }

    if (CgdgfLDqzUTOnTwK > -967303244) {
        for (int JdVtu = 207538390; JdVtu > 0; JdVtu--) {
            YGSekHqx = YGSekHqx;
            fUFEPRpqeBUbmw += fUFEPRpqeBUbmw;
        }
    }

    return mLXAbsIPFWZSIxJO;
}

int HZdBiXcJyU::zBLeSYSVVqrT(string hzvMiUVXigdf, double iPvtN, double aYMumwXByZ)
{
    string EPWtzRVfCR = string("cALtuYKhvCLvCQVyBGdeStgWRfWDzzJqeQMVOXadGZNWHmtLvBqwrdHdpVsIdejisYjAJdyUxXGZkzINeXNmanymaOSntCCveylR");
    int oopPBDiHxFwsED = -116340830;
    string SZJUW = string("fscECzRQJOEdYTGplaZwKUpXQVWCNHMiHFZptipbObXjjmTZykjOrEnrgVmKAvPqDzhvABkiDomnMlNggecktzgdfhZJkzpnGhbJwApQEuJKUGRSV");
    bool oyvfgfEjNva = true;
    double MXkOYIPpYAhk = -218670.16873911294;
    int MzcJboiTnRyOU = 124763120;
    int dzeVv = 1878698242;
    int YlxJIsj = -1752347127;
    bool knWkBBRGzd = true;
    double aqcOeGomMMKXOEEW = -1027132.8736487741;

    if (iPvtN == -1027132.8736487741) {
        for (int qeNUDqVB = 1891917415; qeNUDqVB > 0; qeNUDqVB--) {
            oopPBDiHxFwsED /= YlxJIsj;
        }
    }

    for (int GOxSKF = 744668876; GOxSKF > 0; GOxSKF--) {
        YlxJIsj += YlxJIsj;
    }

    return YlxJIsj;
}

int HZdBiXcJyU::lMYOHQblcNJDg(int DyFHoPQVJSQJE, string RbFVA, string jxwrocoow, bool MrznecBzvTRjirM, string CxFEns)
{
    string LXOVDWf = string("KUOlkmOZtbDmQtEwLkFXgXyTgpQJUmIqRWOzbKUoRqHWLiXhzHEIinyCbCcARdomJlFbdzidbtyuCITuCfCWsVLukttaNAXYLmtAEIJYWvpjbwiVQDauyEiYMRXwJvsNLYc");
    string cBgZltxLMVdROrw = string("AHrbzuokRbhtkyDEXejXrVkLVviNuckRQKKfapFnAOpEkjYACBMcmYwXMFBajtucrUaziHunPICQQnBaPTrlMmsvFZylzlUTEvSxnFOqraiVSHjVbwuKesNRCRengmJqpuVGWZvjSTWLxIxAWPtUhNme");
    double piXUKWSk = 345819.1359730597;
    double sKfvejfVfCBQLK = 897475.3967604379;
    string ajoVheJqTKmcbaKQ = string("LdbTaIWWVpCfILblAVampjeUeRrXUdsJRfEpCMYquOvPOEBIFstgAyczjkOEAKsspnC");
    int yijtHAJjyKGzCKO = -123248855;

    for (int KwqIDYIGrFxNn = 769205519; KwqIDYIGrFxNn > 0; KwqIDYIGrFxNn--) {
        jxwrocoow += cBgZltxLMVdROrw;
        LXOVDWf += LXOVDWf;
        ajoVheJqTKmcbaKQ = LXOVDWf;
    }

    return yijtHAJjyKGzCKO;
}

void HZdBiXcJyU::mFsVDZY(bool vlkLcbqgv, string UleRJZWuJDlhu, int QPsUHWywSKQ, int doSVCWiqyn)
{
    bool dvWyOOi = false;
    string iYFkbc = string("oxbMxFFtNIpTfietpLvMYYXNfJGEmusqTCcsnRkKuAtRgwWPmpvGqKZxOKLPZFeyCOUpWEcAErRJLFvjeRgnHaTwrRIKfNeVvAKmJaotKjFKmHkThiriBuTvML");

    for (int qvYYESTPMO = 915312573; qvYYESTPMO > 0; qvYYESTPMO--) {
        continue;
    }

    for (int nmLIKnr = 998745672; nmLIKnr > 0; nmLIKnr--) {
        continue;
    }
}

double HZdBiXcJyU::TAJcSVICEPn(double PowPIDnc, int KwDJwOntUIMmq, double ctHhbLlcByQsjjUo)
{
    string wBdHXbzUSrxLBpk = string("cAPfSMxaDlk");
    bool UlWvlhpj = false;
    bool FXrbIReChME = true;
    bool yVFBo = true;
    int ucuCXA = 887195779;
    string lviYd = string("ekVrXwAspayfuQGgFScFIfwhXbovRCkAfPNhQCZSxTWYmLhSNysXEkXvnrQEMGelD");
    string XonqvpbYzUp = string("GbhWcGyKvcRReMkoBFfeFszfwIwDYFrPXkwNBvBXSztIrdBEaLyuBmTcvWeXiPrIesJFFeKFsjyvyQJcpumlfBQdBsDlSanXPyOooOXPBBYhmDPNnjkZiEZKnnHrcMHyZSfGlBzfqXsksDTkTVvjOrHjYzphVOCqDLyWawgAhkDqnjJrOUIyNfYEkeIllcyxRTpTL");

    if (PowPIDnc == 372963.2734522025) {
        for (int zPOrKBUXpsyW = 1011589283; zPOrKBUXpsyW > 0; zPOrKBUXpsyW--) {
            continue;
        }
    }

    for (int GxPgMxxXSqd = 838024919; GxPgMxxXSqd > 0; GxPgMxxXSqd--) {
        yVFBo = UlWvlhpj;
    }

    return ctHhbLlcByQsjjUo;
}

bool HZdBiXcJyU::TKaoYArkuNtyTPvP(double jZQrCWZbx, int UWKLgrr, string hGhQWSWJPvfvU)
{
    string VLcPoh = string("mSNIdOFXViFZSYlLPGeanpWxzCYIsArKtIEGxVgbwMiUvoMKpKFpNnyQaofbJyRbAsarZzKAclMTyzFnIzSmflGOfsXZrpWFdDmLOaRlvDZnvNDGizfjwTiYhWpbLrOVnGkDfPckqzhOUOpmxgyvvTzqYPzwzqJWhkaBzSsxBBoyIOVLdLbKpkDTBFWYfraME");
    bool yzBISQG = false;
    int eUFSr = 1883811942;
    bool LsMBIQMdyD = true;
    string xxEgeubqKmADgD = string("oxAxlGwDMfIZScKdcRlgPZBoMsxUZtBuBytpLuZopfxYFIUNTYtvsWkdCoBniKRJgLusjZswlyzwnAaUzNPhqdIqewPrxFtvJVcJPapeQZKSPvqivdgxsYfUliRcSLIxwHinVnugzvYfGxxMActneaLzpWgXDlNLVKpUeVgtKbNHIvVNBszUbGBkNDIbONwfvARXoggH");

    for (int fVdwGRXb = 1482541928; fVdwGRXb > 0; fVdwGRXb--) {
        hGhQWSWJPvfvU += xxEgeubqKmADgD;
    }

    for (int VbDABOH = 122617069; VbDABOH > 0; VbDABOH--) {
        jZQrCWZbx = jZQrCWZbx;
        yzBISQG = LsMBIQMdyD;
        LsMBIQMdyD = ! yzBISQG;
    }

    for (int oppHVjYobiD = 1070844700; oppHVjYobiD > 0; oppHVjYobiD--) {
        LsMBIQMdyD = ! LsMBIQMdyD;
        LsMBIQMdyD = ! LsMBIQMdyD;
        VLcPoh += VLcPoh;
    }

    for (int dVpRfzVm = 786740604; dVpRfzVm > 0; dVpRfzVm--) {
        UWKLgrr += eUFSr;
    }

    for (int mYiHdmDao = 640887311; mYiHdmDao > 0; mYiHdmDao--) {
        VLcPoh += VLcPoh;
        eUFSr = UWKLgrr;
        eUFSr = eUFSr;
        VLcPoh = VLcPoh;
        hGhQWSWJPvfvU += xxEgeubqKmADgD;
    }

    for (int ZRqxmFeubGGDKTF = 403144445; ZRqxmFeubGGDKTF > 0; ZRqxmFeubGGDKTF--) {
        eUFSr *= UWKLgrr;
        hGhQWSWJPvfvU = VLcPoh;
    }

    for (int sLUBzxFwrYvufyk = 1096934503; sLUBzxFwrYvufyk > 0; sLUBzxFwrYvufyk--) {
        eUFSr *= UWKLgrr;
        hGhQWSWJPvfvU = hGhQWSWJPvfvU;
        jZQrCWZbx += jZQrCWZbx;
        eUFSr += eUFSr;
    }

    return LsMBIQMdyD;
}

bool HZdBiXcJyU::jPRZHNWAWlh()
{
    bool NSRuC = false;
    int ukFjQKnpiIbuRz = -657873716;
    string sgSHFKUZGIujW = string("GZnLWGBuSoqUNsCoKMcVPAHWqXnCFRRuXkmlQNVKQlMQQLvgXbvvpCpKyNAm");
    int jDgUoKEyzzG = 1228254465;
    string AEaqtQXj = string("EVNuhHzTMySLCpbeLWfpjDKTMNKtpaKcTXLnJgaXkWvqvQARIcLUeiZuTkvswOrBLoFTkXPDizFDNlLQczsKsyfaAVNTnlybwlahrMELtGVfiZdhZdSlGqHCKhBUANCDcRgepvQhQTzGawOrtTzLAoDXtrkVQPlhLYKuZSckLUwDYKfkgVIlopbKlNsnansfHGmhVQChScNfSegEtnTPSfyIRyid");

    for (int rEpemxqqaXDuGX = 369512754; rEpemxqqaXDuGX > 0; rEpemxqqaXDuGX--) {
        sgSHFKUZGIujW = sgSHFKUZGIujW;
        jDgUoKEyzzG -= ukFjQKnpiIbuRz;
        AEaqtQXj += AEaqtQXj;
    }

    for (int kgswe = 328822713; kgswe > 0; kgswe--) {
        sgSHFKUZGIujW = AEaqtQXj;
        AEaqtQXj = AEaqtQXj;
    }

    return NSRuC;
}

int HZdBiXcJyU::DdqfajrqCG(int GfoJunn, double AKjVocdvE)
{
    int UROYCjqqJUmcFCL = 968377538;
    bool fJdXqTU = false;
    double RvBDxiLXSdHY = 285170.76963736746;
    int GSPWMIJ = 929218186;
    bool HhXOVzVknGmrKfv = true;
    string apOIFzVNElUjWn = string("aocNlgbjzfQJzCsJZTgmNnBOEsazARovvbzadQuHdarRtvDlYIQctNXyqGxZdcAXSwYrDhVknjUBgGwJooqppt");
    int JaGtFyKIfpdxy = 118301363;
    bool DkWYrimP = false;
    int JHZSBgrEyl = 1976432870;
    int GDyBFyPNDHmOnl = -1595699782;

    for (int fkjFmGZyPFEZdVU = 1872345087; fkjFmGZyPFEZdVU > 0; fkjFmGZyPFEZdVU--) {
        continue;
    }

    for (int EwOpyNIidr = 952082677; EwOpyNIidr > 0; EwOpyNIidr--) {
        continue;
    }

    return GDyBFyPNDHmOnl;
}

int HZdBiXcJyU::VTzBaQZnqeTe(int oLatmNYv, bool qkEAWMs, bool nADMJLEgzvNIFTt, bool FTRwdyDRKxoP, int bWtLFr)
{
    double HQKVQwsSHEGTiYOd = -848131.0752940286;
    int BUeTmbsTXyzcarT = 385788351;
    double SfRGgnGXAhPRptvE = -757389.2023629912;
    string jkLRPf = string("ZfZzaXUXOyBhCrrjEyxSipYwRwXOOzHbULyVjmBvpINXjcBHOidkOmWfuCMjAURWCFAAKNVvMqILxfXMLMWwuYOEmZOSyBDRcvDJTAVBOTjANsfQkgKaOHXHyIpwkKephAgdPLFSWpuzraAcOmapBDtSKtMBLixGolthtMQiliFRtteeVUachoxoSKOyCGOGwHqgAuGOkalwTae");
    bool GedPaHyPsBbnnHuo = false;
    double KwOZXBQWBMNvEeeU = -738725.0436518705;
    int avLIHweq = 1904043214;
    int sFHIyetEKtJ = 1211551996;
    double rKXfKFSkdcLE = 211066.9110111277;
    double FHttJMY = -544102.1721382677;

    if (BUeTmbsTXyzcarT != 1211551996) {
        for (int yWkJQabCrmVEtC = 1339098006; yWkJQabCrmVEtC > 0; yWkJQabCrmVEtC--) {
            continue;
        }
    }

    for (int EOVRZebuCaizryqN = 1799991068; EOVRZebuCaizryqN > 0; EOVRZebuCaizryqN--) {
        oLatmNYv /= avLIHweq;
        rKXfKFSkdcLE -= FHttJMY;
        qkEAWMs = ! FTRwdyDRKxoP;
        FHttJMY -= rKXfKFSkdcLE;
        HQKVQwsSHEGTiYOd /= FHttJMY;
    }

    if (FTRwdyDRKxoP != true) {
        for (int PuDQrhmhQSxksoV = 1305682162; PuDQrhmhQSxksoV > 0; PuDQrhmhQSxksoV--) {
            continue;
        }
    }

    for (int TfbzrQYTQf = 381397292; TfbzrQYTQf > 0; TfbzrQYTQf--) {
        HQKVQwsSHEGTiYOd *= FHttJMY;
        KwOZXBQWBMNvEeeU /= KwOZXBQWBMNvEeeU;
        BUeTmbsTXyzcarT = bWtLFr;
        GedPaHyPsBbnnHuo = GedPaHyPsBbnnHuo;
    }

    for (int RfxFj = 434456709; RfxFj > 0; RfxFj--) {
        continue;
    }

    if (SfRGgnGXAhPRptvE >= -738725.0436518705) {
        for (int XwSxvBvzUPJz = 1725147192; XwSxvBvzUPJz > 0; XwSxvBvzUPJz--) {
            continue;
        }
    }

    return sFHIyetEKtJ;
}

double HZdBiXcJyU::UJUkYSdsmGiIjmS(bool xbcmcOzcQNZbLR, bool wbfOx, int AWXaI, int spDvm)
{
    double XHbIZ = 533053.5358153388;

    if (spDvm == -528340508) {
        for (int uXekXK = 1312553639; uXekXK > 0; uXekXK--) {
            wbfOx = ! xbcmcOzcQNZbLR;
            XHbIZ = XHbIZ;
            wbfOx = ! wbfOx;
            XHbIZ -= XHbIZ;
        }
    }

    for (int EjtgK = 1568986332; EjtgK > 0; EjtgK--) {
        xbcmcOzcQNZbLR = xbcmcOzcQNZbLR;
    }

    for (int tVMVdfpaDdOHhPjx = 140879019; tVMVdfpaDdOHhPjx > 0; tVMVdfpaDdOHhPjx--) {
        spDvm *= AWXaI;
        wbfOx = ! wbfOx;
    }

    for (int lrJDRmJNyzxL = 671105350; lrJDRmJNyzxL > 0; lrJDRmJNyzxL--) {
        xbcmcOzcQNZbLR = ! xbcmcOzcQNZbLR;
    }

    return XHbIZ;
}

bool HZdBiXcJyU::KjbljYWq(bool gcfotNeKxszseNZB, int xNlAOHXXONfnaqWH, bool mRIzQc)
{
    string szlmgKWVkV = string("N");
    bool BTbmCKigTvlVEpp = false;
    string hUJYNSEajAtlV = string("SrtWYgqRiCByUILCxxhqnadwtYNurYKfNIVxZgBaktVwYrdDNseyTDeVZTPiLgAcrOrfntPYUdhNwuorWInfvuhHDRJdAZGiTorHKFxNhMPTDDdxpJ");
    double FozvClYflXq = -751837.5709543776;
    string bngQpWQ = string("OcuTezcIkbbvVybTsOiIsLFhqMXHqgquFzpSqnndXMgxvMxgFeRvKefdAEFxQjDGhvGKNAlrzJsPNPijmvJjCHMJtKpruzQzncVHqpoTSqJvTgOBKfWYvZiIhGaKhCHhmvPeQezZZIshJeORigwUPGQwMKoceSbEdHvbQFZstQFXWBOVUNyAjRHAppOZbfzpIbdqcxMVyqayEzQhvGvcAbLYhkZKimucbqrrnTZyNxQwMwNZfnFvIvcxKlqRu");
    double eqegxIw = 462311.7492013659;
    int AGJoBUYBmK = -1110155744;
    bool EZEvLVAwvIB = true;
    bool tWEzBgpwUfjHTeaD = true;

    for (int YJGmenY = 1674687710; YJGmenY > 0; YJGmenY--) {
        hUJYNSEajAtlV += szlmgKWVkV;
        bngQpWQ += bngQpWQ;
        gcfotNeKxszseNZB = ! tWEzBgpwUfjHTeaD;
        tWEzBgpwUfjHTeaD = ! gcfotNeKxszseNZB;
        EZEvLVAwvIB = ! EZEvLVAwvIB;
    }

    for (int LfOZi = 453735954; LfOZi > 0; LfOZi--) {
        gcfotNeKxszseNZB = mRIzQc;
    }

    if (mRIzQc != false) {
        for (int SbUJaznf = 302468795; SbUJaznf > 0; SbUJaznf--) {
            EZEvLVAwvIB = tWEzBgpwUfjHTeaD;
        }
    }

    for (int NKIoq = 486052644; NKIoq > 0; NKIoq--) {
        EZEvLVAwvIB = ! gcfotNeKxszseNZB;
        mRIzQc = ! gcfotNeKxszseNZB;
    }

    if (tWEzBgpwUfjHTeaD != true) {
        for (int cdOHPCkSdancNyW = 927215319; cdOHPCkSdancNyW > 0; cdOHPCkSdancNyW--) {
            continue;
        }
    }

    return tWEzBgpwUfjHTeaD;
}

HZdBiXcJyU::HZdBiXcJyU()
{
    this->fYQkfM(299177081, false, true, true);
    this->CHNFNNknyjD(-808960.4120959078, string("cYVgPHJEfaVyGHgJygXPDOWFUfezwBEiGRdSxOKmkapUMSWCZkiWGsDPelHFDxezNWvRzDMogXWjOvZChePgaoIDOBGHpVOAJqJIpqVRDdKhbbduSpjnTBGRhKFbEvjasSCX"));
    this->HGLmnwOEO(string("TuAMEZuYCLdwOYXfOkvlnqeMQ"), 398350.1731923872, false, 373389.7820765914);
    this->kzeAlvUj();
    this->zBLeSYSVVqrT(string("FLIAGPMFGpDQvdvofcKFaXjijQXHiSsSxzqraCmiSuxDVIEFJwczA"), -536612.2424002247, 864328.0091250328);
    this->lMYOHQblcNJDg(553255662, string("ZykRdakXMjuNgJUTdocVpupMapLXBQQxbCoeGzdSvXQSIsUGLaFNNnIVcILMXYffNWrpVjZRwXphDTrEGoGDQznDEjHaqIeERExBtHTuUHAINPaXzXvfFkjlGrNVCqYviAckgROrlTcZLGErKkUwjzEyMIXkRaACFECrkajIxcVeBGJIRDHGALt"), string("NoRpjycQczbwnxPHJSPzCofYNyGibSUFkQNTnKYlyHMTBeswJsunoHDgEKVBJxrfIZZrjhpspCKjQkoSjoYAbSRpcktlYEqgguiCKxDUudYDArtFVSzVqjiArWPWWDEHVXbaYvNTYD"), false, string("ciVeVTgtXGNMhCudpvKoFjiFmTSLV"));
    this->mFsVDZY(true, string("iAeECkAvCUvuCzVUtctRRrbECYrEBmxCscVFfUMpTdmhMPvXtmZkQBvEqHDQokuQttLEHRSSNBCyHKcMfeAkEbIvgjKAmeZZzHaXPZofhWuAoPbDFmaofkAllftuoxLzmmJEtixOgsBwMVLGlkfbjooEixPuKe"), 1152014985, -1533852882);
    this->TAJcSVICEPn(372963.2734522025, 1861777306, 383009.1246754047);
    this->TKaoYArkuNtyTPvP(-331503.67884528363, -1115170497, string("dbgNQKFAwuJGvcbRysxsLRXCHedvKwmRAabQpoXQZtCOKTxgNWaYolGSBADSZdeKygXifEvXTsHVNqvUZZHXYLCamtjcUScmdnQhhjJtjVYQcgZifWWglhQDaXUxjanzAwHBQCSCcJcfMEijfUKVIFGaxXGwqjrEvYZhANCfEGFeGhLyjZPpYAacXExmMddNbdTDqghEUdXGWMquCspnBSmnvwsoiuAowzMaYxqrXfXyPjzqBdEJorcCOMk"));
    this->jPRZHNWAWlh();
    this->DdqfajrqCG(-176424286, -629386.5142624928);
    this->VTzBaQZnqeTe(1623935572, false, false, true, 1736236327);
    this->UJUkYSdsmGiIjmS(true, false, -528340508, -532749083);
    this->KjbljYWq(false, 1284505956, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TDVwwJBn
{
public:
    bool bKKzvxrjcmIdfZmU;
    bool jDiAxafn;
    bool NhVnQZCRZNCwBh;
    int PmLjaCJAm;
    bool HLjxuTglhPome;

    TDVwwJBn();
    bool cUcrX(int dZgAKwAuEhFTCkqr, double yJMjTujrdgqvL, bool agliApMJEykW, int tAjzRzpluVodAn, double ySwMGETIlShPiE);
    void QulwkyU(double UTpsmwIVrWCdMr, double KcQsFzVTp, string VWMCGCPnYOEUzcNb, string Dqxew, bool hkEYqkGZMUQJ);
    double xPUCvwArsQANh(bool SpPsL, double wCJEXe, string eqQHnIqQDMtzMg, double ryKwSQsOayl);
    string BfQNkSUFAyZRNeDK(string XEKctBLJtJRN);
    string GEDMsMIgqi(int IYlXwuYdeuLiMDkj, bool kxiikbih, string cZStQe);
    string OuZPEZDczWF(string BurzQ, double WqOyTkUOqzdCU, bool ijqEFQYtuKRgno);
protected:
    int NutPohHv;
    int ThjlGpOXyyxKrsFO;
    bool vrxcYKNZiidPnASv;

    bool WKmmIFjkuJkbs(int nzLySGQqJ);
private:
    bool BCVaDyCtrBZe;
    double eaBJhTGvfVI;
    string luGFXokeFIV;
    bool qHCIqwcY;

    bool oxylCwaArAWT();
};

bool TDVwwJBn::cUcrX(int dZgAKwAuEhFTCkqr, double yJMjTujrdgqvL, bool agliApMJEykW, int tAjzRzpluVodAn, double ySwMGETIlShPiE)
{
    double SNqxbg = -246008.07971837968;
    string GrKBbDtKTNfwKsso = string("egSnMOtCYWxTjPIIeVujwLWZNpQGjWIFkt");
    bool tUYsuhAgApzE = true;
    string aSovJWtwuoEAqYLK = string("UzLLjBvsypWcYQGAACYAztBmjieuZTqFMVwSYOsLVhJonIlxMtQUbLHW");
    string jewEomcdaojtMF = string("bDvdogVhTnsNmhwvIoorudlWlbauBrbVZOQnxOVknnrqJxXdiuCRThwvfJnueGrPdpSrvDrJqfFGTAfSeWnAwgBJwOpvheIFRDziXcQMGvLIeOofTmVvyaSIRsgoGdwPjKEXWLvETtbiQLPMfSEmyulKxBBPuzIYOjCPWzXBgUOyicBLjXuespcSjYlTAGaykUSNMHIBSqtXDjSUbTrcVWHyalpWLXmVZpAaBACKhBkCpnDrYael");
    bool ayjYqrqHkcW = true;

    for (int hbBkqtcfKZUuqRo = 579082068; hbBkqtcfKZUuqRo > 0; hbBkqtcfKZUuqRo--) {
        continue;
    }

    if (tAjzRzpluVodAn >= -197613728) {
        for (int rnyXMwCkNHCqZ = 126370933; rnyXMwCkNHCqZ > 0; rnyXMwCkNHCqZ--) {
            tAjzRzpluVodAn = tAjzRzpluVodAn;
        }
    }

    for (int tWKauPfChkiVfw = 445425769; tWKauPfChkiVfw > 0; tWKauPfChkiVfw--) {
        ySwMGETIlShPiE *= yJMjTujrdgqvL;
        tUYsuhAgApzE = ! tUYsuhAgApzE;
        tUYsuhAgApzE = ! agliApMJEykW;
        GrKBbDtKTNfwKsso += jewEomcdaojtMF;
    }

    return ayjYqrqHkcW;
}

void TDVwwJBn::QulwkyU(double UTpsmwIVrWCdMr, double KcQsFzVTp, string VWMCGCPnYOEUzcNb, string Dqxew, bool hkEYqkGZMUQJ)
{
    double oBqgJQzQIih = 275787.09158872475;
    double yQtBFPDAFpAB = 918244.7327664318;
    bool XYBwxE = true;
    double tnnMQCpnJIhpUjE = -674814.8927566868;
    string TQvtgK = string("HgrqKrFncCpfqQMRYZbmdXDwlKWvwCUSNcKPoloOTmeMXISgxjXzacaBZlQKFsKnouIVvzRWokoaslLLWBlSBDjCUeCphINYuiMogYepvlR");
    double MlBdodxXQNsNw = -444909.9708360653;
    string dJpKwJ = string("WaVGeVqAgsOJTafpOmhqTjnIYIduHohU");

    for (int EsYIDXNXClNq = 1921348622; EsYIDXNXClNq > 0; EsYIDXNXClNq--) {
        oBqgJQzQIih /= MlBdodxXQNsNw;
        Dqxew += TQvtgK;
        oBqgJQzQIih /= UTpsmwIVrWCdMr;
        VWMCGCPnYOEUzcNb += VWMCGCPnYOEUzcNb;
    }

    for (int XSKFtaQYDvMS = 1389053448; XSKFtaQYDvMS > 0; XSKFtaQYDvMS--) {
        oBqgJQzQIih = oBqgJQzQIih;
        MlBdodxXQNsNw *= yQtBFPDAFpAB;
        MlBdodxXQNsNw /= yQtBFPDAFpAB;
    }

    for (int qFPoag = 1242133372; qFPoag > 0; qFPoag--) {
        UTpsmwIVrWCdMr /= tnnMQCpnJIhpUjE;
        UTpsmwIVrWCdMr /= tnnMQCpnJIhpUjE;
    }

    for (int XeDYaYBjdKZrSA = 1257938579; XeDYaYBjdKZrSA > 0; XeDYaYBjdKZrSA--) {
        yQtBFPDAFpAB -= tnnMQCpnJIhpUjE;
    }
}

double TDVwwJBn::xPUCvwArsQANh(bool SpPsL, double wCJEXe, string eqQHnIqQDMtzMg, double ryKwSQsOayl)
{
    string RVXQhhqjQqwWJErX = string("HEWBvcMLTWvKPsovrLFgdUzwpAYQbcCwpnEwWEqLOqhUgPPKteXtIrgvgmkyhFzZQiowpQxFKSKHDclXlwUokGyCYEnawfFtdcnlRSDjwaLnOZZFsoIKhoeWCfRvExqWdRVerNaZfEeQeTpUcqUtImXOsAFxdYGpFtDANbGvZfflzhoDRswPbifRylWuAVtJmSonPAA");
    bool TibLpVcsWJ = true;
    double iDjfLaDh = -447201.614582819;

    if (eqQHnIqQDMtzMg <= string("cmrpAbmzHaGmYOAIjxmnqbcelbGTlPYaGvvztrxcMAZRbyZDPnWjcTuoWyLOeIeTgrhOKAArcVIp")) {
        for (int KvObK = 1810055134; KvObK > 0; KvObK--) {
            TibLpVcsWJ = ! TibLpVcsWJ;
        }
    }

    for (int VshVsg = 1619983433; VshVsg > 0; VshVsg--) {
        TibLpVcsWJ = ! TibLpVcsWJ;
        ryKwSQsOayl /= wCJEXe;
        iDjfLaDh = iDjfLaDh;
    }

    for (int SMXmrH = 673378365; SMXmrH > 0; SMXmrH--) {
        continue;
    }

    return iDjfLaDh;
}

string TDVwwJBn::BfQNkSUFAyZRNeDK(string XEKctBLJtJRN)
{
    bool vMpIHOUKhrPFA = false;
    string sFDRzZzRacOnTX = string("lcWDnGEhkJDjwYbDtLBnjAsbjaLqksbQMWgPnHhWMrAUA");
    int NuEehJocxV = -1427112966;
    string zQHUiWEEL = string("hbBGabCpnSfCEylAHMesGAmuCBSmufODTWfzMkuWhbvzEcTHZEGrhmbiNwTwRMTwnfYNoJSfjBjQrNqIsBvjCOuNLtKKZUEZAeVGHmxjxTrKfBuSxiSvZxTlMlFxUdlMoMKmBrWznKIKvLRjnBHwoCgRbEtpOlKSQIfCpGNqpcJlOfyibzHSqsCnawmqtOtngCbnOAhRC");
    string PhBzqXYBTcJl = string("YbcNReCBMBfttQcuqOyXEdCpiPBTlMjbQGwHFTPCYRekiSGjsyEAHHRregrePijANRSPxIxbSgbsFsarZRPsBzZFhzSSYljcDShWsmaQMNvCcVoJGExGQntXhnsEnIvInBEvhpvLTIomIbTblBnXOpiegnqgKRZrWZJzUJFTfrniagOsmEagniFiOzZhVfjLvrRbKqwoiOOSxLiAgaPVull");
    string ZkQIkGnCvZx = string("pDAkcRsdtKyvcrjgMOOzVQqrAtvzfXZjWZeRXoeMxvhgTLmSxqjaGHJkPpcAQqNUXTTzMFaLKBpnfvNOlbkPcemPMhcHmeGMhsmVORThLqFAfjKkmkwZVjMRihDBoUMlNdbPDaMsZrwMlSGmCAGrcANZBLwekGqJRRbUHPUpHwopqsCWwTHdCZIOGDXxYQKsgUwxpqodIxQrduoAIqrejgcvwujIOwLpoeFSYtbbmghtapVvqyBj");
    bool LeucPNrpF = false;
    bool LuuBVZErD = true;

    if (LeucPNrpF != false) {
        for (int TIUtiTg = 1628125610; TIUtiTg > 0; TIUtiTg--) {
            zQHUiWEEL += sFDRzZzRacOnTX;
            sFDRzZzRacOnTX = PhBzqXYBTcJl;
        }
    }

    if (XEKctBLJtJRN >= string("pDAkcRsdtKyvcrjgMOOzVQqrAtvzfXZjWZeRXoeMxvhgTLmSxqjaGHJkPpcAQqNUXTTzMFaLKBpnfvNOlbkPcemPMhcHmeGMhsmVORThLqFAfjKkmkwZVjMRihDBoUMlNdbPDaMsZrwMlSGmCAGrcANZBLwekGqJRRbUHPUpHwopqsCWwTHdCZIOGDXxYQKsgUwxpqodIxQrduoAIqrejgcvwujIOwLpoeFSYtbbmghtapVvqyBj")) {
        for (int PkIKDAE = 229975611; PkIKDAE > 0; PkIKDAE--) {
            ZkQIkGnCvZx += PhBzqXYBTcJl;
        }
    }

    for (int owThihZCFD = 1216624255; owThihZCFD > 0; owThihZCFD--) {
        PhBzqXYBTcJl = XEKctBLJtJRN;
        PhBzqXYBTcJl += ZkQIkGnCvZx;
        sFDRzZzRacOnTX += PhBzqXYBTcJl;
        vMpIHOUKhrPFA = ! vMpIHOUKhrPFA;
        vMpIHOUKhrPFA = ! vMpIHOUKhrPFA;
    }

    if (XEKctBLJtJRN != string("pDAkcRsdtKyvcrjgMOOzVQqrAtvzfXZjWZeRXoeMxvhgTLmSxqjaGHJkPpcAQqNUXTTzMFaLKBpnfvNOlbkPcemPMhcHmeGMhsmVORThLqFAfjKkmkwZVjMRihDBoUMlNdbPDaMsZrwMlSGmCAGrcANZBLwekGqJRRbUHPUpHwopqsCWwTHdCZIOGDXxYQKsgUwxpqodIxQrduoAIqrejgcvwujIOwLpoeFSYtbbmghtapVvqyBj")) {
        for (int TsrEmpqraOTIQeO = 32163609; TsrEmpqraOTIQeO > 0; TsrEmpqraOTIQeO--) {
            continue;
        }
    }

    if (ZkQIkGnCvZx > string("fNo")) {
        for (int rNUqiRdJ = 1339186620; rNUqiRdJ > 0; rNUqiRdJ--) {
            continue;
        }
    }

    return ZkQIkGnCvZx;
}

string TDVwwJBn::GEDMsMIgqi(int IYlXwuYdeuLiMDkj, bool kxiikbih, string cZStQe)
{
    int qWqEdMRWgmqEwpP = -811533816;
    double JtWWMnRpSXCRvxM = 934752.6390883292;
    int ATKVVxEQCb = -2024824456;
    string JcJIXxieem = string("CZefwQcAZXVBYaiBuHirIDHupDZYPZdXJvhrZMyspuVXGfCLsuoaSIHSosanAPoUTzNTrFXhvJhNwmxCxcDbKaCQprCukEPrQzvXlXBEk");
    bool rLznwnd = false;
    string juldZxN = string("LobBxNJBxfrnRFGJxPilQSvaKfxglAsxhhNAImlohbDfvOdAlohspWnlvFkYlGDPecUZlbmLsFoSNBgOBWoChDgSWUchHVsXHqSSoyIOZYejOcKrjdzCdnxuRKKAxRHJeFSGBAXQNpkGPAZhszQazDLhKlMAzJLNJIQPeCLGWBMrodOeiiRKXsfgakDzdHxVwCsvaFquEZCBEcCtlLqGkw");
    int CZgZibnHwpKqmbk = 79189014;
    bool LGcaWTWqyTVzwPEJ = false;

    if (CZgZibnHwpKqmbk != -2024824456) {
        for (int VnzLDqbb = 1245470590; VnzLDqbb > 0; VnzLDqbb--) {
            CZgZibnHwpKqmbk = ATKVVxEQCb;
            kxiikbih = ! rLznwnd;
            qWqEdMRWgmqEwpP -= ATKVVxEQCb;
        }
    }

    for (int oLfCZnmeutg = 1895212619; oLfCZnmeutg > 0; oLfCZnmeutg--) {
        continue;
    }

    for (int YcFOiQDENvKAORnF = 1448878877; YcFOiQDENvKAORnF > 0; YcFOiQDENvKAORnF--) {
        rLznwnd = rLznwnd;
        LGcaWTWqyTVzwPEJ = rLznwnd;
    }

    for (int cnbHmFRdJqN = 1685051907; cnbHmFRdJqN > 0; cnbHmFRdJqN--) {
        continue;
    }

    for (int zBYMoAIisF = 601853633; zBYMoAIisF > 0; zBYMoAIisF--) {
        juldZxN += juldZxN;
        cZStQe += juldZxN;
    }

    return juldZxN;
}

string TDVwwJBn::OuZPEZDczWF(string BurzQ, double WqOyTkUOqzdCU, bool ijqEFQYtuKRgno)
{
    string boXVENaf = string("oeLpLGPnIInfqzqhNUCVCTqop");
    int uJXHYGgpavukAso = 653297452;

    if (BurzQ > string("WyNvvGQzpKwzboVNOqIExMgKKoatPQmPhQxeGKfZZNLZd")) {
        for (int xRdDxrwM = 540286541; xRdDxrwM > 0; xRdDxrwM--) {
            WqOyTkUOqzdCU -= WqOyTkUOqzdCU;
        }
    }

    for (int zCAwXwLyUjYpOjav = 1413139100; zCAwXwLyUjYpOjav > 0; zCAwXwLyUjYpOjav--) {
        BurzQ += BurzQ;
    }

    for (int LQjETQlcEe = 906815907; LQjETQlcEe > 0; LQjETQlcEe--) {
        BurzQ = boXVENaf;
        boXVENaf += BurzQ;
        WqOyTkUOqzdCU += WqOyTkUOqzdCU;
    }

    for (int nIIGcRHELv = 1798325158; nIIGcRHELv > 0; nIIGcRHELv--) {
        uJXHYGgpavukAso = uJXHYGgpavukAso;
    }

    for (int fpIzNqgX = 1115316918; fpIzNqgX > 0; fpIzNqgX--) {
        continue;
    }

    for (int RsTBcfjmga = 1026405445; RsTBcfjmga > 0; RsTBcfjmga--) {
        BurzQ = BurzQ;
        boXVENaf = boXVENaf;
        BurzQ = boXVENaf;
        boXVENaf += boXVENaf;
    }

    return boXVENaf;
}

bool TDVwwJBn::WKmmIFjkuJkbs(int nzLySGQqJ)
{
    string bEoPqbdpQmD = string("XNtznbutvYRmmItyssSMUJePqPFjEZFUyiqAXRNJksBWFriQjdOFxrwgWCiciJpubqVrZuhNupfTNQQCwGCsuZZmsnOALTiChqPzbhnONZBDqcZMBzYKWBVgTcmLeqYHOCMMgOBDmQcQWtMkFxdSpdGBYIoRCMcOrgAKsoPEuGzAILVIWVFyWySxDIQwEXAoAgrqLsSNdISfVpVscV");
    string jaTnIEAjSoMfRKEb = string("eyaxfobHARAmwkkGPKyflyHNnktzBtWciIisTBBryGJBNTbQpqMzbqjKMQJEZpvaMbdzIsTGdHltgMQJriYVCOQkXAxsJHLfprwpkmmOMhMeCmARwcWsMeVuLDNPMkywzGTGcnNSrQOCYiqZatndKHXt");
    bool oYPeKEhwJFPJXKUl = false;
    string rVcfejE = string("fEQQEOIiSzdHUQKoVsdfZVLcNSEweKzfcqPLvSddCbYzSq");
    int xTqKNJid = 533121848;
    double gTjLwJtUHKrJ = -687415.8425083208;
    bool vMOSK = true;
    string lBlSGwwreAiTU = string("DHQlliVzJQcVlBOdsTKdNFeNHFUydDlmMefDzjZNVcKioApBtwAEvDwaqzSYuDPYJqTlaHYJhzxtYygNPSxvIxXLSHuVnhKjBmo");

    if (rVcfejE != string("fEQQEOIiSzdHUQKoVsdfZVLcNSEweKzfcqPLvSddCbYzSq")) {
        for (int WlkgytcfBa = 1835488009; WlkgytcfBa > 0; WlkgytcfBa--) {
            gTjLwJtUHKrJ /= gTjLwJtUHKrJ;
            rVcfejE = lBlSGwwreAiTU;
            bEoPqbdpQmD += rVcfejE;
            rVcfejE += rVcfejE;
        }
    }

    for (int xJZwiVBekGlP = 1848824037; xJZwiVBekGlP > 0; xJZwiVBekGlP--) {
        jaTnIEAjSoMfRKEb += rVcfejE;
        lBlSGwwreAiTU = lBlSGwwreAiTU;
    }

    for (int OhBsBDyQAdtLdoRm = 1917648783; OhBsBDyQAdtLdoRm > 0; OhBsBDyQAdtLdoRm--) {
        continue;
    }

    if (lBlSGwwreAiTU < string("eyaxfobHARAmwkkGPKyflyHNnktzBtWciIisTBBryGJBNTbQpqMzbqjKMQJEZpvaMbdzIsTGdHltgMQJriYVCOQkXAxsJHLfprwpkmmOMhMeCmARwcWsMeVuLDNPMkywzGTGcnNSrQOCYiqZatndKHXt")) {
        for (int ThpVnqf = 2038085553; ThpVnqf > 0; ThpVnqf--) {
            jaTnIEAjSoMfRKEb += bEoPqbdpQmD;
            rVcfejE += jaTnIEAjSoMfRKEb;
            oYPeKEhwJFPJXKUl = ! vMOSK;
        }
    }

    if (rVcfejE < string("fEQQEOIiSzdHUQKoVsdfZVLcNSEweKzfcqPLvSddCbYzSq")) {
        for (int wtSXEX = 1021271638; wtSXEX > 0; wtSXEX--) {
            continue;
        }
    }

    for (int QDVuziD = 1788440050; QDVuziD > 0; QDVuziD--) {
        nzLySGQqJ += nzLySGQqJ;
        jaTnIEAjSoMfRKEb += bEoPqbdpQmD;
        jaTnIEAjSoMfRKEb = rVcfejE;
    }

    for (int RoUxCvmpSr = 1127073184; RoUxCvmpSr > 0; RoUxCvmpSr--) {
        gTjLwJtUHKrJ *= gTjLwJtUHKrJ;
        rVcfejE = bEoPqbdpQmD;
    }

    return vMOSK;
}

bool TDVwwJBn::oxylCwaArAWT()
{
    string aPfQGZQmwXbO = string("YtductqlonPWnTQdnokZUxKUYzaiuVZzdQoCdZDuLQrqjJVMzGiUmgSxJVuBWiBzEOmOGKBgiJhqhfWEyVyRZIHHwHDUe");
    int udtsjqOMcnRtGQ = -1627821232;
    int eGZsairQzmBbL = -917996587;
    int qADfmWrjbxfzNgU = -1553337288;
    bool OkpuNMri = false;
    int ipiLEhupoR = 1932267798;
    double LrCDgmPm = 37522.08193181264;

    for (int hNOYAXmboUl = 1921052297; hNOYAXmboUl > 0; hNOYAXmboUl--) {
        eGZsairQzmBbL *= udtsjqOMcnRtGQ;
        qADfmWrjbxfzNgU *= eGZsairQzmBbL;
        eGZsairQzmBbL -= qADfmWrjbxfzNgU;
        qADfmWrjbxfzNgU /= udtsjqOMcnRtGQ;
    }

    for (int bYIqqeqnEa = 761693521; bYIqqeqnEa > 0; bYIqqeqnEa--) {
        udtsjqOMcnRtGQ += qADfmWrjbxfzNgU;
    }

    return OkpuNMri;
}

TDVwwJBn::TDVwwJBn()
{
    this->cUcrX(-197613728, 391584.83127705514, true, 320324712, 931372.0755355108);
    this->QulwkyU(-318962.23586070887, -226657.4983248032, string("fXOazqcgLxVwgYkyJVCMxcMBroCEzxVdKXNDbaYLSvZQxYGJFIlvzuokeqWHgcCrZzoAwyJ"), string("FtzlCvAgCVuKsokWGgTVBACmoHbNRLIEHINmjfhxigtryrpjjKMQYtOZiLLKGmwxoTJZZAUjpkCYANpIsciBsiLNBrBzNrxhEqTnKcrBcTtoEqlXKfPSCzXCWFQkkVfYhmfAPGwRiILYiLlXadLEoLBXDkevIRAWetBbjfsXYLJUSLrMyXBplAboHKMlHWHBJYvovQkDjmQsVKsUVAJDSq"), false);
    this->xPUCvwArsQANh(false, 61470.020443557856, string("cmrpAbmzHaGmYOAIjxmnqbcelbGTlPYaGvvztrxcMAZRbyZDPnWjcTuoWyLOeIeTgrhOKAArcVIp"), 165791.56116847554);
    this->BfQNkSUFAyZRNeDK(string("fNo"));
    this->GEDMsMIgqi(294909927, false, string("qsYPSDQlrpzgBHoyuoHPdUcakOpXnXOGUaYgkftRVAnXHuaeyeNDYqSZDZ"));
    this->OuZPEZDczWF(string("WyNvvGQzpKwzboVNOqIExMgKKoatPQmPhQxeGKfZZNLZd"), -415884.0489075312, false);
    this->WKmmIFjkuJkbs(-1199050339);
    this->oxylCwaArAWT();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zJZAgrgqHuyddtB
{
public:
    string ZIzdrJOlJzidivR;
    int aupJsQAzJYoaIp;
    int SaBpUVwzsK;
    bool LffNuhKa;
    double kiOjIytGzLAN;
    double atzLlIZuvWeQ;

    zJZAgrgqHuyddtB();
    int aaDbLsHXRJz(double trYQseMVkZcn, int CmdlSiVLjLX, int POpFVkXiqI);
protected:
    string TzsXJeebaeURF;
    bool appbkCrmYKpHcmg;
    string WOwoQdEgt;
    double qHUifVSbXoPXDOfM;
    int ZRCTwAgNhkF;
    int JrUiQFdtGFalvcpJ;

    int mBEAdJfxLlSRvuxa(int pUygjC, double PqJtNrSvBjjCbD, string NYjqHCrxhNUuDIV, string qmVTVEK);
    string TBtqFBLkNxk(bool TAgUNbrekpwBusCS, bool PzlsvADRADF, int SUhQJuFYVqP, bool uPfxmSrGFoZy);
    double TekKKZZNMtWoRL();
    int JKxQstoaX(double DqdtIixugzpI, string RGYTyEigfiWgc, bool HuQUDUTmOhvbysR, int iUpPwBkxqwkVyYmX, bool xGBpKdB);
    void PdKczrsKbWc(int dlcmSjrCbVVHA, int zjTKNXWsvpBVaPJ);
    int artZtzDqoa(int UkXJp, int ObzdZwAISdhHRgEb, bool tLkMffTwf);
private:
    int lYAlk;
    int ymtoXY;
    int GnXKGSwpKAHbdw;
    string ZRWKh;
    bool cuzktbPCoYfeRg;
    double nAwjdzqZK;

    string BqjveKozyt(int JyWHFm, bool GZNvrgD);
    string pTWzqPZr();
    double rniucPyccohe(double DewobzguVCpGjQTR, string ZcwtpDsuo, string JkluUrJEeRzAhyUy, double tNBkCu, bool hMgtsdXBeGB);
    void IHdKyxkC(string rNysYVpqjkQs, double rNFNxyqdKbmTnzW);
    string YnevJxlLCFTURi(int lkWNOjAcQIzzN, string XPugH);
};

int zJZAgrgqHuyddtB::aaDbLsHXRJz(double trYQseMVkZcn, int CmdlSiVLjLX, int POpFVkXiqI)
{
    string bqjfmwCevOBCIm = string("pyPvQTtwrbwvDTbBxdtxrdRiJeCcnrKArQZLpvEUQgBqrqqlcBMFrdEJKEmqemnDeWLTCqvBRPAOafxBinZnkikskpRAQruURIqCAcLXKzKIrovTBWhgdaigFzQgcLjOiqtcqqfMBUrujMRPxlHvHrYMAzwDlJXZkKnRy");
    int AKOku = 2048986107;
    int JjeSCGf = 2104782438;
    string jqpgtFgS = string("QxTjXAPfvGwujspAMBGAooyuRYsUXumdnjWsJJs");
    string uxhOpYVCNTKOQjB = string("CJeUtjyhRSSbbiuBsoAdyDLsWAdMfuhYgCJdDNsmqOZBAEsEanlbZghqWinZOUvFDEBBFMIriTEomLInsizoiyjeSyNnLrXkJIzykvqjSMHNtFlbwmPBSpdrCcvfyIShBTxQSBmHvGlZuDwmamnokZQVLGnvHmEjboPDOsRvNTEewvISXRivVNDlEDCoixILyJWswFvcfCfAtxAeeCtFhq");
    int gqMVXJRUOXMPyFPE = -295712982;
    string HRKcZqRqQtrhRyT = string("ZwUPmmFdQvbDIWmNDlmCHiCyNbpeoZurHpZIoezyzSzWwACVswVyjcRqcTiNNtXAWlUMfmnzDqhrnrwWoEigjvOClWqdTuVmqxbsQefTbezFcOUsgNwRxEEYwwwbafTpBRfpBUzoxdWyjekFqKOHsgtuerKgwuTvQQIsmPZOXupiQUuFkvoBzhVuAqmhvziXPDGHq");
    double OlvCinXqzwkK = 653965.1901264094;
    int jYjbLqusjwPzZjl = -827108928;
    double oBYcLghJhuS = 397277.7640929948;

    for (int rrsFiLyYAsQQCwvc = 598396892; rrsFiLyYAsQQCwvc > 0; rrsFiLyYAsQQCwvc--) {
        POpFVkXiqI *= gqMVXJRUOXMPyFPE;
        AKOku /= POpFVkXiqI;
        trYQseMVkZcn = trYQseMVkZcn;
    }

    for (int kyAgvAMXwr = 202967344; kyAgvAMXwr > 0; kyAgvAMXwr--) {
        JjeSCGf *= CmdlSiVLjLX;
        CmdlSiVLjLX += JjeSCGf;
    }

    return jYjbLqusjwPzZjl;
}

int zJZAgrgqHuyddtB::mBEAdJfxLlSRvuxa(int pUygjC, double PqJtNrSvBjjCbD, string NYjqHCrxhNUuDIV, string qmVTVEK)
{
    string FxZsBkhc = string("wYMXeBASyptARXTZGXnpJPilRykHGdpcpUMlozrAlSNMaoVTXOjSIpqaeNNIegsJAtSuGdeJIscboXftojtoShVjVegCgYcPDngRYcYaFdWpECtdvDGJGzZRxpjglkgfqvBlYOzVQCPeHpMkjegQpzKtkJBmwjlSjDoRsOgBLSnAIHfDRPOVKJSRPpUsAplNct");
    double SBCURcen = 61470.69213346202;
    int YnpwDFmhSG = 664117793;
    string vwxJeVkoRjuZSz = string("mrNKaNzuApMjBIDWPoJiJdjTJcMvdtlbIBdhQpShDHlXnotIYDXousPGIHxXDBpKoIFVtkYMHTEPlCTnWSKIdPuAGUDptMWrqaEzVMRfPlsYpeIMKTfaDPHLGdbnStkOuuQMoelHgMfKadKQidNSgquMQzSqlqeOnQPWLsPfmFRd");
    bool xVGcllNfIAjs = true;

    for (int uGvAXEJxhj = 189755841; uGvAXEJxhj > 0; uGvAXEJxhj--) {
        qmVTVEK += NYjqHCrxhNUuDIV;
        pUygjC += pUygjC;
        qmVTVEK = vwxJeVkoRjuZSz;
        YnpwDFmhSG = pUygjC;
        FxZsBkhc += FxZsBkhc;
    }

    return YnpwDFmhSG;
}

string zJZAgrgqHuyddtB::TBtqFBLkNxk(bool TAgUNbrekpwBusCS, bool PzlsvADRADF, int SUhQJuFYVqP, bool uPfxmSrGFoZy)
{
    int hESGNhwCLectBJ = -336261291;
    bool IGejMYQtdiC = false;
    string XUBCeYW = string("wqdjUdcxkGBGtneCogwEuNztrRAKSnElMlrjjEQrHgffOEjtBKbhfcGodsZCXR");
    int jpWZvIgmxWLu = -270682014;
    double GJKBxUpbQIb = -61762.65642783949;
    double qyrqtZchsl = 221443.4215306412;
    int dxxmZf = 1207294357;
    int VEKnNiMgI = -721284776;
    bool NsRQCYrCw = true;

    return XUBCeYW;
}

double zJZAgrgqHuyddtB::TekKKZZNMtWoRL()
{
    string KLJCx = string("dQyHTnwDPzLxqaFXrzrHwctWpGnDstcWBgTuqhKmOuWBRRCmXRXksQHVsFTkrZDMLMrDRKdYCAlPwQzJptMDgsZhCIvwpqhTAEQSMudxoOBsAbKiZJumlUPhieQffdTMMxdCSs");
    int oTInRRMgXMYV = -278430913;
    string DFtqyhrXW = string("uFGutseQdzGMDeGGIyZMJNnfaLfzcALzeFCFJsLMgJdRKtOVhYPAWCKhVpNVUZQdIkXlnstyUaLzXRsGicepzqQLgkMzrLjliYEKCJnZtthgWeWSGemQHqWYjwujYNiyoRoPVRcTWwpRmyDdWmUIKXGWciFAXLZbKODeZlHoqsZWpjAKMfdYAucXneJaLzrGAlvYMvTmDUCuNXjzMpVps");
    bool iUJqaLJuVsmYBx = false;
    string ZSfsOwuzTMDHJOG = string("VfXcAhwpaTVdYbYpzZBtGUJXBbBsNymHjLdZMCwcYjWKSsYoRcQkGxUUDEpobtCNTaPezuVAhtMGQYnBRzNCCpECXXLSysVVWkdSjAvLzxbdVwnHFliDrKGFfTmVEXVYPSqaatJGEUHiPucQocpGFbzuLIBvnSINMKspdSnHkjLsoIsJvBmX");
    string KTWEihqnvzNI = string("iIREagODMFeqdSaYPXGavlxxyYYhWDWkpTadlEouvfiQHeriQFvJrtKXclPFWqmUiVimuEBuHfEWwaIhAQKMhdiBY");
    double gEPIPVOvannyNkd = -351243.6647527811;

    for (int CMKItJIOV = 1134978376; CMKItJIOV > 0; CMKItJIOV--) {
        KLJCx += KTWEihqnvzNI;
    }

    for (int rAvhPaKTFDoeqw = 2070876811; rAvhPaKTFDoeqw > 0; rAvhPaKTFDoeqw--) {
        ZSfsOwuzTMDHJOG = KTWEihqnvzNI;
        iUJqaLJuVsmYBx = iUJqaLJuVsmYBx;
        DFtqyhrXW = ZSfsOwuzTMDHJOG;
    }

    return gEPIPVOvannyNkd;
}

int zJZAgrgqHuyddtB::JKxQstoaX(double DqdtIixugzpI, string RGYTyEigfiWgc, bool HuQUDUTmOhvbysR, int iUpPwBkxqwkVyYmX, bool xGBpKdB)
{
    string ZFtcCmSRnfyZRf = string("iHtkAGBkjAKyawWAKMGcMgWzffdTmvSauHmOxRrbmMcXpWEnLzSvWpioZvNi");
    string UKufYHgxnRCAYan = string("bxgtf");
    string rEynrYGqmmTrJcHj = string("laGJCtrpuiMowFXDpNubAEpfbZoHnDcGPKDPIrEjqYTfXKRbGjnTxTuZzaYfebjSHHEzAPjXoa");
    int XMnnlziq = 1343569734;
    double pCYwRokLOtyG = -978132.389482364;

    for (int CphaCLorMKZW = 1750925039; CphaCLorMKZW > 0; CphaCLorMKZW--) {
        continue;
    }

    return XMnnlziq;
}

void zJZAgrgqHuyddtB::PdKczrsKbWc(int dlcmSjrCbVVHA, int zjTKNXWsvpBVaPJ)
{
    string hEMpIPIrWQFlEl = string("eYbGqSrzxMkXbaCyZBoTIWMsOQRULbzFznPfHecyRuVQTRVqvNhBNwIhHXSdYPQeboAEDOvZXbXQGEObiR");
    double fbemfvtxYCyJi = -216707.21079769204;
    double vlXKKdno = 798189.1408023112;

    for (int OwPfpeOVoYrG = 422533770; OwPfpeOVoYrG > 0; OwPfpeOVoYrG--) {
        continue;
    }

    for (int LKtrK = 488480493; LKtrK > 0; LKtrK--) {
        vlXKKdno -= vlXKKdno;
        zjTKNXWsvpBVaPJ /= zjTKNXWsvpBVaPJ;
        fbemfvtxYCyJi = fbemfvtxYCyJi;
        fbemfvtxYCyJi -= fbemfvtxYCyJi;
        hEMpIPIrWQFlEl += hEMpIPIrWQFlEl;
    }

    for (int bBiqRRssjz = 818986935; bBiqRRssjz > 0; bBiqRRssjz--) {
        vlXKKdno += vlXKKdno;
        dlcmSjrCbVVHA -= zjTKNXWsvpBVaPJ;
    }
}

int zJZAgrgqHuyddtB::artZtzDqoa(int UkXJp, int ObzdZwAISdhHRgEb, bool tLkMffTwf)
{
    bool mPyGIvBjJmEC = false;
    double URiZYCnWHJFD = -134462.49133466117;
    int ONFxcFtxYRqpGj = 974166968;
    bool mUOGMUNiADYwttV = true;
    int VvHdCBAVC = -1356386425;
    string cuSJgLhligpMORR = string("KcwobobRltDDUbMjbkMVzAhUmvtNsuqJMsAVjRFMMIQSZdY");

    for (int TaNMxFBituoCYORy = 496126078; TaNMxFBituoCYORy > 0; TaNMxFBituoCYORy--) {
        ONFxcFtxYRqpGj -= ObzdZwAISdhHRgEb;
    }

    for (int cpjzgegFQMyQf = 1706938062; cpjzgegFQMyQf > 0; cpjzgegFQMyQf--) {
        ONFxcFtxYRqpGj += UkXJp;
        UkXJp /= UkXJp;
    }

    for (int TYgjE = 344259236; TYgjE > 0; TYgjE--) {
        ONFxcFtxYRqpGj -= ObzdZwAISdhHRgEb;
        UkXJp *= UkXJp;
        ONFxcFtxYRqpGj = VvHdCBAVC;
        mUOGMUNiADYwttV = ! tLkMffTwf;
    }

    return VvHdCBAVC;
}

string zJZAgrgqHuyddtB::BqjveKozyt(int JyWHFm, bool GZNvrgD)
{
    bool CrtKxERQZnzIe = false;

    if (CrtKxERQZnzIe == true) {
        for (int wNKvgQFboW = 1737245532; wNKvgQFboW > 0; wNKvgQFboW--) {
            GZNvrgD = GZNvrgD;
            CrtKxERQZnzIe = ! GZNvrgD;
        }
    }

    return string("EfmgoQzEwOwQvqBnXKXRbxPTpnkYOhNftWFpWSoMQaXSEuSLSoNxJQyBeAESqTevRIiySermfPHAduFobjlOFvMEmXRVWvUokWRjAX");
}

string zJZAgrgqHuyddtB::pTWzqPZr()
{
    double yCZLEyX = -223938.31000994897;
    string zKxHGrmdFGSKyJjN = string("uRWSDutnhXaABUIWgrVNnmuBJssKCpjlpfVmXslfTPcLMsmKAVbAWqExDYqoxrSqKDIfHIczqSgfkrldFPRwNAtKctjNOJbMhy");
    double RyfWwKTgjU = -532602.270527509;
    string HaSZtA = string("rejdqvbNEVnYNZyAI");

    if (HaSZtA == string("uRWSDutnhXaABUIWgrVNnmuBJssKCpjlpfVmXslfTPcLMsmKAVbAWqExDYqoxrSqKDIfHIczqSgfkrldFPRwNAtKctjNOJbMhy")) {
        for (int ksbjkPiSTdgWsLM = 71333544; ksbjkPiSTdgWsLM > 0; ksbjkPiSTdgWsLM--) {
            continue;
        }
    }

    for (int uBMsBnhyFfWH = 1025176390; uBMsBnhyFfWH > 0; uBMsBnhyFfWH--) {
        yCZLEyX -= yCZLEyX;
    }

    if (yCZLEyX < -532602.270527509) {
        for (int ZAAcugtTYVisBu = 1913617163; ZAAcugtTYVisBu > 0; ZAAcugtTYVisBu--) {
            zKxHGrmdFGSKyJjN = zKxHGrmdFGSKyJjN;
            HaSZtA += zKxHGrmdFGSKyJjN;
            HaSZtA += HaSZtA;
        }
    }

    for (int RRqNqTkOaJfJqSv = 449871799; RRqNqTkOaJfJqSv > 0; RRqNqTkOaJfJqSv--) {
        zKxHGrmdFGSKyJjN = HaSZtA;
        yCZLEyX -= yCZLEyX;
        HaSZtA += zKxHGrmdFGSKyJjN;
        zKxHGrmdFGSKyJjN += zKxHGrmdFGSKyJjN;
        yCZLEyX = RyfWwKTgjU;
    }

    for (int CclhQFznhsrZgot = 783813979; CclhQFznhsrZgot > 0; CclhQFznhsrZgot--) {
        zKxHGrmdFGSKyJjN = zKxHGrmdFGSKyJjN;
    }

    return HaSZtA;
}

double zJZAgrgqHuyddtB::rniucPyccohe(double DewobzguVCpGjQTR, string ZcwtpDsuo, string JkluUrJEeRzAhyUy, double tNBkCu, bool hMgtsdXBeGB)
{
    int QffrXOBuz = -80197652;
    int DntsxiRITN = 1795173227;
    double RBnOGSdDnvTtGs = -567122.9767758492;
    bool LzFHKA = false;
    string SUrVOMuv = string("IWqyBFxRfSPqurdHbMymGNSlgjbDWQdzQMuScmGwBXVzUoVSwivwkqCcZCOzpURnTkkdSBGhAwJUaCuxvzfRADWWHitQSFrXjdXABqHAcwbUSZYchisTrbzlhqQgZdChJyRvghpmcLHFcfhmhdwSPwiWoacNnHLCeHddJGMFklbozivQtSkyUswcKRqIZPkETQJRqjIlVAXLZiMAFPvyGVNJBJmATu");

    for (int ReYzAW = 453273850; ReYzAW > 0; ReYzAW--) {
        RBnOGSdDnvTtGs -= RBnOGSdDnvTtGs;
        tNBkCu = tNBkCu;
        tNBkCu *= RBnOGSdDnvTtGs;
        SUrVOMuv = ZcwtpDsuo;
    }

    for (int VmETOMjSzpua = 325254369; VmETOMjSzpua > 0; VmETOMjSzpua--) {
        RBnOGSdDnvTtGs *= RBnOGSdDnvTtGs;
    }

    for (int GAdJQFtUmnzkkSI = 1086309665; GAdJQFtUmnzkkSI > 0; GAdJQFtUmnzkkSI--) {
        hMgtsdXBeGB = ! hMgtsdXBeGB;
        DewobzguVCpGjQTR *= DewobzguVCpGjQTR;
        QffrXOBuz -= QffrXOBuz;
    }

    for (int mHMGNIxXk = 2034279829; mHMGNIxXk > 0; mHMGNIxXk--) {
        continue;
    }

    for (int SqLiR = 670373915; SqLiR > 0; SqLiR--) {
        RBnOGSdDnvTtGs *= DewobzguVCpGjQTR;
        tNBkCu = tNBkCu;
    }

    return RBnOGSdDnvTtGs;
}

void zJZAgrgqHuyddtB::IHdKyxkC(string rNysYVpqjkQs, double rNFNxyqdKbmTnzW)
{
    string xHUUkIyosanPPuA = string("tonzeyxWXFZPJbeHwbShipxwohpEWGdNMyxTOpKkdZfXMJgAAVkKaTgfRTglzeifHMYadsIPhQqqqtAqgUfdqVILAilhAInifEimUBOCAnlYNVYmoitQvvzSYSXtAcnOIKftycoLdGsKuFqYkKyqLteNWyBpPANsQagOkOSNDdFOdVysDFMtWkqTHOpwlYBBcRkdPfnDEXaJhYBVSjbEDDJnrVdY");

    if (xHUUkIyosanPPuA != string("VZhPGcVZfPrLACGjUKGUZIFgcJpcewdgeURmDsFsqjMzauLKhxfTNXbrWSiLmQSWBjwokGuukvbOZPsPhCSxMmrWHlLARveoNVvMUfGHBqoEnQiuxElCLHMlVvChKlswEBfeqFBISZkxUQNdletlBpgpLPmcuzLclXDGLDozHtwYZOpVuCSgoUwXvcdYzRaEgdhyhFcPfwXUiyzPKFkikKlxECoMChNdlvfbECrpzXFkFsObKIok")) {
        for (int ESEhgfAy = 822014213; ESEhgfAy > 0; ESEhgfAy--) {
            continue;
        }
    }

    for (int YijoRdqaVSeFIdG = 601116205; YijoRdqaVSeFIdG > 0; YijoRdqaVSeFIdG--) {
        rNFNxyqdKbmTnzW = rNFNxyqdKbmTnzW;
        rNFNxyqdKbmTnzW -= rNFNxyqdKbmTnzW;
        rNFNxyqdKbmTnzW += rNFNxyqdKbmTnzW;
        xHUUkIyosanPPuA = rNysYVpqjkQs;
        xHUUkIyosanPPuA = xHUUkIyosanPPuA;
    }
}

string zJZAgrgqHuyddtB::YnevJxlLCFTURi(int lkWNOjAcQIzzN, string XPugH)
{
    bool mQBQMaOf = true;
    double lOQfEwCgnP = -476356.39377228275;
    bool SslsVJTaN = true;
    int hxOFyfJpkeMhlXg = 790141631;
    string gktnFBBICGJUxPH = string("skmBjlSphUUiBHbVzVyNPDJMehxZgucazsDuMEEGtaAbWZjsrWzByVuasXtWcqvdLiVnmGZTqDZOtfwQlJcEQKhckNadLhwJQDUhCiMTVtogOwblhYlttPJAkojXzwZZvyLqLwpwRzFmXqiZNLgiafoLJrvXjkDSOhzBdwDzggeQPvYSJXGkAXmKQERfRGluNPskCXUnDTbtLPmfjMAbczQxNEfgrezeryPkFyBjKeJE");
    double Vyrvi = -255124.70982209794;
    double OsEJLXtVNLJZDAZ = -865007.0870917935;

    for (int LrAvZ = 375775703; LrAvZ > 0; LrAvZ--) {
        Vyrvi = lOQfEwCgnP;
    }

    for (int crlfg = 333278284; crlfg > 0; crlfg--) {
        Vyrvi += lOQfEwCgnP;
        Vyrvi += Vyrvi;
    }

    if (gktnFBBICGJUxPH < string("skmBjlSphUUiBHbVzVyNPDJMehxZgucazsDuMEEGtaAbWZjsrWzByVuasXtWcqvdLiVnmGZTqDZOtfwQlJcEQKhckNadLhwJQDUhCiMTVtogOwblhYlttPJAkojXzwZZvyLqLwpwRzFmXqiZNLgiafoLJrvXjkDSOhzBdwDzggeQPvYSJXGkAXmKQERfRGluNPskCXUnDTbtLPmfjMAbczQxNEfgrezeryPkFyBjKeJE")) {
        for (int bhQiUatDBw = 838724073; bhQiUatDBw > 0; bhQiUatDBw--) {
            XPugH += XPugH;
            Vyrvi *= Vyrvi;
        }
    }

    for (int kgyXvvn = 1808271608; kgyXvvn > 0; kgyXvvn--) {
        XPugH = gktnFBBICGJUxPH;
        Vyrvi -= Vyrvi;
    }

    return gktnFBBICGJUxPH;
}

zJZAgrgqHuyddtB::zJZAgrgqHuyddtB()
{
    this->aaDbLsHXRJz(-441185.3137749395, -1160836099, -169965286);
    this->mBEAdJfxLlSRvuxa(-1472515116, -485038.5147572353, string("vcTFwAnKIIBsuUbSDUGpfMThvbgYdItxOGpRmMOACBRkvZtPEVTcrhbwQKaqwxCjkAUtXtrRbWwgAtKDlfvesxicxscMrnMUfGISfBZjhBEBnLRbSRUpFqzQhaAZUVkSzFEQufNTvlQWyXdGQQFjYPnGCdmIaiakwFaapCahWErPDADTohAhwdeVrQFfGGCjnegdmFylwybasUmEwQxJBQhkwftCaJWRGqnwpqROlMDmzqIx"), string("bDQLsoErIDTeWEBhyehEFtWAJOoGvfvZMOLkVDUXfurQIJfABwgQQTGokaAJVgUGYtELLCqHxxgglkaCKMrkbgWOBMCkmsfsfSkJJsllHufBATqGVnxQTorwLnjGRoMYQpBkyZESxYSfuXkIBOEGJgskonbvmOCmAnCtovnHXJdyVPujdetOsZEISRAmWgfDRryyLDawAHqrKYIUWEWUApXWLUZFMTybJnVCRkQBfjLzo"));
    this->TBtqFBLkNxk(true, true, -1237265089, true);
    this->TekKKZZNMtWoRL();
    this->JKxQstoaX(-491260.52968722006, string("NHgDhQStoCOcQJQXNtfWFrlVyMKcGJLUEAZssTdJVcCHkrmvFqDkFUiASQTvvUgnokaNoWeCxKRusBaPjYwNSSGNhyIZvmfDbzDOpjeSBXVeJrJg"), true, 1807813888, true);
    this->PdKczrsKbWc(-268492491, 181990061);
    this->artZtzDqoa(1372559790, -1569417216, true);
    this->BqjveKozyt(785134055, true);
    this->pTWzqPZr();
    this->rniucPyccohe(-368625.9758547976, string("tMdGiDJXarkKffZmZsaeBWHNFuwptKueWQuepllMSRGQkRVkkuFFiGZfvJrjecEiGKUdDyKZXGSoAJbLTGXJrDhSfzunefUvmIPwcBNihOMKztJwtHItvrwBzXNTGFWg"), string("zqezfnkgPmZNIYWBLPTsTHQSKQvdYgXxEW"), 561649.1882402011, false);
    this->IHdKyxkC(string("VZhPGcVZfPrLACGjUKGUZIFgcJpcewdgeURmDsFsqjMzauLKhxfTNXbrWSiLmQSWBjwokGuukvbOZPsPhCSxMmrWHlLARveoNVvMUfGHBqoEnQiuxElCLHMlVvChKlswEBfeqFBISZkxUQNdletlBpgpLPmcuzLclXDGLDozHtwYZOpVuCSgoUwXvcdYzRaEgdhyhFcPfwXUiyzPKFkikKlxECoMChNdlvfbECrpzXFkFsObKIok"), 454829.2591186476);
    this->YnevJxlLCFTURi(2093020154, string("HunhxmQTZMyEwayXkenuPBjhnSSQsVxsFIwFffGnvajWvGZteVwWLMIICVixCSXGicRadE"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JMpXzeij
{
public:
    int YMyxbZhZqOABhZxf;
    int afOZVMDxZ;
    string iouQOHYk;
    bool GSuQa;
    double TSVVQeEEVR;

    JMpXzeij();
protected:
    double JBUCmQqcRFBZNj;

    bool BZSumdPhXeXW(double ZVtBfjYU, bool ZhQRYzcJtupVdhz, int CPKLlHkPNSyokuQN, double cOKpk);
    bool klOvnlaNOa(double AZTgUeJ, string InAke, bool pjaAXgTqsKXY);
    void JQjgbffs(string mQLEGLAcEViz);
    bool ERbeSnRXgZKZRz(int FrSMIuzILVj);
    void JMLTgpypHxRaWr(int uSLRjVOeFbmRKP, string lXIsOIyUmvP);
    double hgXOX(double cSmkcjabspccJFo, bool iNyQQLt);
    int OxqMDMnfXkUeS(string HzcyhWNJBR, double YPyhHFKjUD);
    string IIKppQ(bool SYPrDzVcdwFMjg, double dKVAKgMkpWW);
private:
    int CExBthQU;
    string iijmBkaNDO;

};

bool JMpXzeij::BZSumdPhXeXW(double ZVtBfjYU, bool ZhQRYzcJtupVdhz, int CPKLlHkPNSyokuQN, double cOKpk)
{
    double bxbMoaG = -329099.021765116;
    string RkrSwpikUNnkE = string("EfztYiYclxMTSJVezhefgZhWHMBtrthjnHrkRbyvHBZZUwiMcWNUHjJOMbgItUANSEcRnSUcMXWgcfPjVOQVXhdrpRleNBNJrxQcmzUVmfnOBHgjAtsCuBDCzeVyrvuZrkGwXxDQiVCNyYYVmszsumytwC");
    double KEAKUghiWXO = -42974.10952614645;
    string SqzLcRWZOVOz = string("APQrHYGqDfTVGZHHDVjUbGUzMjjNEsERyfTqALnZdHTPvwvbBXJRjPKDdLyGbZnyGjPsqCwrVZHZCmLzpRnOathTdZIoOoEaAsrbVgfEEenWCcLHTVvyNrQXkfDyyCuPjzGuctpeXjRQsXxzurhzIUtNmFNOoVzSHtcwWMqybthPlIxLUXcYewGxNEpsRSBAjzpmXJuIURHkeMckpipeeKojlhUjnqRAGtecKzFCDGN");
    double korXqljLcvONuRc = 696536.763098399;
    string EWgUPjlnXfgWHw = string("xjmFplIHcPgjbLVbqUFVuStQipspEYNfjqVyzeHfWvPxzPiBbrnYk");
    bool sWCRmsPUloSa = true;
    int lRNtzriAguJZ = -1970451848;
    double bwywFhU = 713551.7237231944;

    for (int jGMYGSJQAlegWrc = 1526887447; jGMYGSJQAlegWrc > 0; jGMYGSJQAlegWrc--) {
        bwywFhU -= KEAKUghiWXO;
        KEAKUghiWXO /= ZVtBfjYU;
    }

    for (int PSUIQzUGLtVEPvv = 1173058348; PSUIQzUGLtVEPvv > 0; PSUIQzUGLtVEPvv--) {
        bwywFhU -= bxbMoaG;
    }

    if (cOKpk == -42974.10952614645) {
        for (int bnzirJmHkFuhgb = 1662872499; bnzirJmHkFuhgb > 0; bnzirJmHkFuhgb--) {
            CPKLlHkPNSyokuQN += lRNtzriAguJZ;
            bwywFhU /= bwywFhU;
        }
    }

    return sWCRmsPUloSa;
}

bool JMpXzeij::klOvnlaNOa(double AZTgUeJ, string InAke, bool pjaAXgTqsKXY)
{
    bool YGdWUS = true;
    int iTbskisuul = 598179733;
    bool mKLFFXKaxTt = true;
    int qhiDlKMpQjDcPYU = -1169115423;
    double ZAFvf = 580227.2603333765;
    bool lOMYlBOqoItpr = false;
    string zcDdWFj = string("rknyvqFdMcPkfOXBzuVihnWmtXTSLqWFMIygmbWgEebcgNIfeHYirFUyAMUyKNOsYQxGAVjZGlhYIbFkzXnPXhxluZCelMznZlQslSlhWlfbyeULjbjRtbURvUqYubOsfjmWERiSdNSdoDjyGPUDCVuwx");

    if (pjaAXgTqsKXY != true) {
        for (int JSdWeDpsX = 1264720461; JSdWeDpsX > 0; JSdWeDpsX--) {
            lOMYlBOqoItpr = ! pjaAXgTqsKXY;
        }
    }

    if (zcDdWFj == string("rknyvqFdMcPkfOXBzuVihnWmtXTSLqWFMIygmbWgEebcgNIfeHYirFUyAMUyKNOsYQxGAVjZGlhYIbFkzXnPXhxluZCelMznZlQslSlhWlfbyeULjbjRtbURvUqYubOsfjmWERiSdNSdoDjyGPUDCVuwx")) {
        for (int AkKicAdIdlr = 1311474238; AkKicAdIdlr > 0; AkKicAdIdlr--) {
            InAke = zcDdWFj;
            InAke += InAke;
        }
    }

    return lOMYlBOqoItpr;
}

void JMpXzeij::JQjgbffs(string mQLEGLAcEViz)
{
    int DrzpPNswg = -48011487;
    bool NYjfmhMNRs = true;
    int HVMMW = -1925738411;
    bool hgfEIcVPJBjGT = false;

    for (int crjVUYFjNPTgmPl = 1449653465; crjVUYFjNPTgmPl > 0; crjVUYFjNPTgmPl--) {
        NYjfmhMNRs = hgfEIcVPJBjGT;
        DrzpPNswg /= DrzpPNswg;
    }

    for (int qGRIQnBhkXPwvRe = 390837885; qGRIQnBhkXPwvRe > 0; qGRIQnBhkXPwvRe--) {
        HVMMW *= HVMMW;
        NYjfmhMNRs = NYjfmhMNRs;
        hgfEIcVPJBjGT = NYjfmhMNRs;
        hgfEIcVPJBjGT = hgfEIcVPJBjGT;
    }

    for (int FPHUsgMpfDNjJ = 1038843008; FPHUsgMpfDNjJ > 0; FPHUsgMpfDNjJ--) {
        DrzpPNswg /= DrzpPNswg;
        mQLEGLAcEViz += mQLEGLAcEViz;
    }
}

bool JMpXzeij::ERbeSnRXgZKZRz(int FrSMIuzILVj)
{
    bool GydQiT = false;
    int CdNdB = 1178537453;
    double AebGz = -722489.4623303459;
    double nyqwXRoP = 773865.5052936249;
    double oLSOAYcdHLeCrZ = -10320.533832100777;
    double YpNhJjbL = -880585.3037863834;
    bool SKkkBRtIzteTUD = true;
    double aSUnRMyNO = 690951.2442278797;

    for (int YRLwnIvNeprAj = 672032877; YRLwnIvNeprAj > 0; YRLwnIvNeprAj--) {
        AebGz *= oLSOAYcdHLeCrZ;
        YpNhJjbL -= oLSOAYcdHLeCrZ;
    }

    for (int GypmuwjB = 1150120098; GypmuwjB > 0; GypmuwjB--) {
        nyqwXRoP *= aSUnRMyNO;
    }

    return SKkkBRtIzteTUD;
}

void JMpXzeij::JMLTgpypHxRaWr(int uSLRjVOeFbmRKP, string lXIsOIyUmvP)
{
    double iqwFnmjGxMufJiOj = -445311.84217114176;
    int qGsXdRRwBOOZaMO = 1089910810;
    bool FGWTlt = false;
    bool byZFVO = true;
    string BDbwXpafu = string("BbuwAfFPKiSVOsGKPCVdwogcsvCgcaPKpKGgifFPyOIqaBlWqMNfoyRjAIPxrSHICkyKxPljEMPUJnKNegOGVCgaTNaVNSceiwvxGtcGZvIgsyCfeRWvlnqfhMTwWXuoGLgSJLErAlstuCzQuTbdmfKxpGudibBKxtldPq");
    string VCrZVXAFWhDc = string("YsyiSBagfYCGvOovnBFoYJgSAwkIMMfpIjWCiOOQVWiUwaFIymnGzOJqaAFnHBgSmuotmQqMHXPJjwobwWWUnhbYHYAZxVx");

    for (int iJnaBfCof = 1907759103; iJnaBfCof > 0; iJnaBfCof--) {
        continue;
    }
}

double JMpXzeij::hgXOX(double cSmkcjabspccJFo, bool iNyQQLt)
{
    double HyRKVt = 61702.29000263976;
    string HvuudaSeZ = string("szxJorUKXcBmVmRmqWPlsnaPiiGAnbqqkvisqdYRLNyBxFTdANBFLAXmXecSXMyRoVEqgiFIyuUQcWbDFobSaQwnrngQiIeLYsvRCKCOFIxyuopIthhRJKhRNtSsmBMvXsleyhXPCRcdxKsjWltbmhRtUyCuqszBeumFic");

    if (iNyQQLt == true) {
        for (int JHNyeRwevm = 1454138958; JHNyeRwevm > 0; JHNyeRwevm--) {
            HyRKVt /= cSmkcjabspccJFo;
            cSmkcjabspccJFo *= HyRKVt;
            cSmkcjabspccJFo += HyRKVt;
        }
    }

    for (int DKEUHbPPEIQmrllo = 1868768522; DKEUHbPPEIQmrllo > 0; DKEUHbPPEIQmrllo--) {
        cSmkcjabspccJFo -= cSmkcjabspccJFo;
        HyRKVt /= cSmkcjabspccJFo;
        iNyQQLt = iNyQQLt;
        cSmkcjabspccJFo = HyRKVt;
        cSmkcjabspccJFo = cSmkcjabspccJFo;
    }

    if (cSmkcjabspccJFo < 61702.29000263976) {
        for (int uEsyygbpUrtVtZ = 404701184; uEsyygbpUrtVtZ > 0; uEsyygbpUrtVtZ--) {
            continue;
        }
    }

    for (int uzayFCxi = 2116565283; uzayFCxi > 0; uzayFCxi--) {
        iNyQQLt = iNyQQLt;
        cSmkcjabspccJFo += HyRKVt;
        cSmkcjabspccJFo += cSmkcjabspccJFo;
    }

    for (int jttIVBbJx = 2014393683; jttIVBbJx > 0; jttIVBbJx--) {
        HyRKVt /= cSmkcjabspccJFo;
        HyRKVt = HyRKVt;
        iNyQQLt = iNyQQLt;
        HyRKVt /= cSmkcjabspccJFo;
    }

    for (int awROjLfbIKv = 1968618650; awROjLfbIKv > 0; awROjLfbIKv--) {
        continue;
    }

    return HyRKVt;
}

int JMpXzeij::OxqMDMnfXkUeS(string HzcyhWNJBR, double YPyhHFKjUD)
{
    double STSEklTsA = 317851.09397622576;
    int CorZW = -306341615;
    bool HuowBtfYInPdCbr = true;
    int QCrXpGzzuvdpgen = -1724877312;
    bool AylTaap = true;
    int haXBkc = 723296565;
    bool lDUySDMUN = true;
    int igucWkZdbDVx = -1931175144;

    if (CorZW <= -306341615) {
        for (int FEkcr = 1016791681; FEkcr > 0; FEkcr--) {
            igucWkZdbDVx /= QCrXpGzzuvdpgen;
        }
    }

    for (int UYBPYEcmqYrfInI = 214514918; UYBPYEcmqYrfInI > 0; UYBPYEcmqYrfInI--) {
        YPyhHFKjUD = STSEklTsA;
    }

    for (int PEXavuIJyI = 83544634; PEXavuIJyI > 0; PEXavuIJyI--) {
        igucWkZdbDVx *= haXBkc;
        CorZW /= igucWkZdbDVx;
    }

    for (int BWYmsvIfqxOCGtkC = 1748909201; BWYmsvIfqxOCGtkC > 0; BWYmsvIfqxOCGtkC--) {
        YPyhHFKjUD = STSEklTsA;
        haXBkc *= CorZW;
    }

    if (haXBkc <= -306341615) {
        for (int UQKNYmVXoxas = 962434094; UQKNYmVXoxas > 0; UQKNYmVXoxas--) {
            AylTaap = AylTaap;
        }
    }

    if (QCrXpGzzuvdpgen < 723296565) {
        for (int mCFUjyZHmfHyks = 1298386799; mCFUjyZHmfHyks > 0; mCFUjyZHmfHyks--) {
            haXBkc /= QCrXpGzzuvdpgen;
            STSEklTsA *= YPyhHFKjUD;
            lDUySDMUN = ! HuowBtfYInPdCbr;
        }
    }

    for (int fWpGN = 1325564797; fWpGN > 0; fWpGN--) {
        HuowBtfYInPdCbr = ! lDUySDMUN;
        CorZW = igucWkZdbDVx;
        igucWkZdbDVx /= igucWkZdbDVx;
    }

    return igucWkZdbDVx;
}

string JMpXzeij::IIKppQ(bool SYPrDzVcdwFMjg, double dKVAKgMkpWW)
{
    string jAkkMYGFXnSA = string("fMgAsbXZMYRFYwupRmswKSywvtbAepEnUybtXruolnwPOVbogQRNHHkPApDELbGOsgBqvVzCWLiToRMeetTnmIGritfNAbQQVO");
    bool pcJhHUL = false;
    int GTAyG = -1435926902;
    double ETeUGkPAB = -528033.7460737824;
    bool SQrArHLvgZ = false;
    int cTPSAbhYpMuwv = 1863957775;
    int SVlFhgLK = -1009936182;
    string zgeJGy = string("gjgqAqUAhYRUIaWnmxhHQiPXAQNMNjJPfeJUHeowTlSCEJgpyfRBHnVzYWPGycEppCTZazGCCpaGxFy");

    for (int WtestFGB = 2109298690; WtestFGB > 0; WtestFGB--) {
        GTAyG = cTPSAbhYpMuwv;
        GTAyG *= cTPSAbhYpMuwv;
    }

    for (int XLRam = 721410567; XLRam > 0; XLRam--) {
        SYPrDzVcdwFMjg = ! SQrArHLvgZ;
        pcJhHUL = ! SYPrDzVcdwFMjg;
        GTAyG *= GTAyG;
    }

    return zgeJGy;
}

JMpXzeij::JMpXzeij()
{
    this->BZSumdPhXeXW(-757140.0601109469, true, -733543592, -213330.46984445993);
    this->klOvnlaNOa(-339869.62909153075, string("SIeVjWfNIaswjcYbLkVliCLquGedYQCfPDMCGYGkKvgwgXUToxoEfSkYWrajattSiLXzQUMQkxwKdLkrnCCtiwumkjGaIGQwddCYembBxzXGQHCPkpHHGpXKpUKlzSgfgGAcVhBKtcrSwvFgpVErVwTObGvbVDugrfFsXUwvQFmsiuxnFBSdoENwiXQLhyhpesbnnkdFSk"), false);
    this->JQjgbffs(string("WLPUGOcTakntgurcEuTiioeCesePSIsQJcPJQUbHUpPXEGYwjsWtqkamJHsgkZylXFzfQoTMYWnoFmXPeuSeJrWlACzmyeldXIQLOCyatzBWtNKhrzVbTVYvBIWZNngETIPdlKYlTmafnGgXKGOyMBOoIyzfbuFblPQtiRserxgGmLEqGxmOuTHzrgIsxTmeGpBpqbKmbBoAxOsfAGFSOZOCNmYXrP"));
    this->ERbeSnRXgZKZRz(640818518);
    this->JMLTgpypHxRaWr(1346015868, string("LMySWaxuWMCrHYmSqgfzlHSrGjRnEXZxglxSHqOIwOjjtNBfiYJSpTCBYNdcbMvfqBlFamTwEzFWnkqEMcojQIxLxcUDokNzYTiQWFtyVjcWlbzphdScNmXxXOPNLEcigViLYmxKsoDmeooqnVjAsyffpQjPZYEkxQhsryPlAvbDHUTIHPHrdvaYZJrSe"));
    this->hgXOX(37307.592884589205, true);
    this->OxqMDMnfXkUeS(string("NFycTCcLY"), -940362.6942075088);
    this->IIKppQ(true, -741903.8148548756);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PLFXJ
{
public:
    string cAvwKjUSYYpVF;
    string FNnhO;
    bool cMxtOe;
    double akZtVaPPjQqj;
    int bmmfpNyhBq;

    PLFXJ();
    string DBqdcGL();
    bool UCPgxLSTVoAi(int FNvVqzKUZXsN, int hAFszoxyGrbyEK, int JuWXKyLmVjYpigH);
    void MwIlJRXhLodhxzDB(int zDBWTkDqmKK);
    int dXIGXDujlSQuUH(double TIKlTch, string NVnwrBHPyXg, int aYtxHaxTjt);
    int EqsgxoyFgoXuFrS(string aZpUpdTWyjcnzGN, string rksCEArpDFPaG, double xsjleBtySMqMA, int NueGXzZnaxDZthv);
    int aXOTlrTygWiF(string zYDOGMGLthQwd, int PlgjXbaLaUxxC);
    int YKCzXH(string IatHCGjBbgT, string gHWbBMvit, string jVCXhCeMQFWqH, double zBsmYgldquBIv);
protected:
    double qhkQiaOGppBmq;

    bool YnyvtG(bool WmDrSflHnM, string PWvzls, string BRqtCmUkinWC);
    void bmusbIeFYif(int sehiUsmbxvqLWdU, double RlNLIJybN, string yhfUb);
private:
    int AChPl;

    string XrobKFAxQqmCtAP(string qWCGbLMwTShWoeN, string OrgPs);
    bool CTjokOHmHimY(string lFKGLDbQqhdzy, bool oIWHhlCL, string UWQyS);
    double GYuLAnWLetkX();
};

string PLFXJ::DBqdcGL()
{
    bool oyhCYPuPh = true;
    int uUoUrSYg = -912564801;
    bool lWgQhxDWBxLK = false;

    if (lWgQhxDWBxLK == true) {
        for (int UDdHUrJqYYUwCvj = 2038717452; UDdHUrJqYYUwCvj > 0; UDdHUrJqYYUwCvj--) {
            lWgQhxDWBxLK = ! lWgQhxDWBxLK;
        }
    }

    for (int UMPhUXqiTjSu = 1155824634; UMPhUXqiTjSu > 0; UMPhUXqiTjSu--) {
        oyhCYPuPh = ! lWgQhxDWBxLK;
        lWgQhxDWBxLK = ! lWgQhxDWBxLK;
        oyhCYPuPh = ! lWgQhxDWBxLK;
        lWgQhxDWBxLK = ! lWgQhxDWBxLK;
        uUoUrSYg = uUoUrSYg;
        uUoUrSYg += uUoUrSYg;
    }

    if (lWgQhxDWBxLK == true) {
        for (int fUTMLSCEaT = 1451379946; fUTMLSCEaT > 0; fUTMLSCEaT--) {
            lWgQhxDWBxLK = oyhCYPuPh;
            uUoUrSYg += uUoUrSYg;
        }
    }

    if (oyhCYPuPh != false) {
        for (int RWnGtHzsklRjTrU = 2114255132; RWnGtHzsklRjTrU > 0; RWnGtHzsklRjTrU--) {
            uUoUrSYg -= uUoUrSYg;
        }
    }

    return string("KlsEZNfUPQmWhRtYtNAtEWEtlaTHevaMVVFTqJsTXIHXJzMarGubKuI");
}

bool PLFXJ::UCPgxLSTVoAi(int FNvVqzKUZXsN, int hAFszoxyGrbyEK, int JuWXKyLmVjYpigH)
{
    int OZfXugEQMMeINU = 267562963;
    double lFylPDv = -593659.2100242118;
    bool XyiXBI = false;
    bool MDbQyodhk = true;
    string kARikMFbyqZCfQ = string("beLeNyLmLhQOvCHpRjTlcoijPvWaMcvfFAwPhEeMTuZzcgkfODwGmCygPyAPQ");
    bool GjHSBDC = true;
    double Qnteey = -38775.40157587545;

    if (XyiXBI == true) {
        for (int ZZYQbaZyZDf = 1877740514; ZZYQbaZyZDf > 0; ZZYQbaZyZDf--) {
            XyiXBI = ! MDbQyodhk;
        }
    }

    for (int XmfWfuRPd = 857414692; XmfWfuRPd > 0; XmfWfuRPd--) {
        FNvVqzKUZXsN /= FNvVqzKUZXsN;
    }

    return GjHSBDC;
}

void PLFXJ::MwIlJRXhLodhxzDB(int zDBWTkDqmKK)
{
    double YOTlMdlgwIzL = -777047.2372389535;
    double zCqZZrbiLssk = -77531.68795370677;
    double khSbSStmT = 161462.75371116283;
    double vsEtj = -876260.0162441623;
    bool aNQBwbreLMtoFlCZ = false;
    int VZNVYbqw = -1239522370;
    string MfEkIn = string("XRCcHzXtWswIMbCiMEApDwrlgzBIxMliGAUVARgJwvwrCQeIQkrGwmYHKLqngzXXNXpNWrjZvcLWIMeDqmsGNyZRyQpjLjKmZBxyQCiHjNFuyvVfxkgSxmxpjwrVHjFschFtWpOxVFRcrvjefEis");
    double EkpMSmQmlYVy = 620730.8329957698;
    bool KNlWbDrzknacE = false;
}

int PLFXJ::dXIGXDujlSQuUH(double TIKlTch, string NVnwrBHPyXg, int aYtxHaxTjt)
{
    string TvZQfJe = string("qNMjgrEBHUBpGWEOTGLeJanKgxkMVnGDbGyvMDrCVrbNvTuVextfyGapfUQfjYafqwKsnPNjTwnzUFqYqigvMrDDfkddWbwOdaUlrJfBIAdVNoTEbdTxdpTYWmhowqSUTDnoHBGaoLfUuEdqAqIePTI");
    string TPOfdUmCxnxb = string("yWJVurwrgtmPLUxyKAmqjzznGYFsqLfbrpVKOuClLNcVySyLcFtZF");
    int quGQscXZk = -1809222823;
    double dGKNRw = -399184.4152483183;
    string SdvlXDcOxXv = string("YSYsxWVKlKgpTepnCaYrqFOlULfYpUYfKmfikMWJvTgqRMGQEfUBhqHaFsdVeBkFTEcUrXCnUuVxhnNRWCeqCUjBVdZNHqSHiFKJpUPcqgTyQrqxuAkZfZIsxsIJ");
    bool oxNAHm = true;
    string FsWum = string("sYegFhrSLhCvVqNhEXnUOaxBejNyaLpsedZJWbkJvukkbmnpzmNenmSzAwNLTOCOEzYOYYkzBebdqdRrJnRAADpikAoQhoelFKrtlBpPSjtHYWoGdgEAxpojcjXgszjGDNohZMnOgDatVPmTNELgcUNTIEhRJkPdSIbPwvSlbIYlFnPAaaOjxeeQdXoFQrJLtMvLDBYinFwJsYGqBTtPJAtqXmzuqPGdCLYSSCYtTGQUwKhCJkih");

    for (int ZEzzJWTqoyV = 1229378460; ZEzzJWTqoyV > 0; ZEzzJWTqoyV--) {
        TvZQfJe = TvZQfJe;
        NVnwrBHPyXg += SdvlXDcOxXv;
    }

    return quGQscXZk;
}

int PLFXJ::EqsgxoyFgoXuFrS(string aZpUpdTWyjcnzGN, string rksCEArpDFPaG, double xsjleBtySMqMA, int NueGXzZnaxDZthv)
{
    string GVKvDPNJQ = string("fnaHJaugXejPBhkdWZrgKLTiwOoBsRGBzqrDDPYXFbCsuZVLZCfupPrMvRflAdzJjVXOAqkjyFFGjuNQBWaMBkcWEN");
    double CPwkDmvd = -268835.5346940342;
    double YDdmkWQrzIYd = -328386.2812624383;
    string KHIONWI = string("UgkUxCaOqlWxZVZhLslBIxxrXBApDWoBemjIQaYZCGgupjYGFGlauUBTXMBsqFkALwTtnLsKeHxRFjoqreKbRhpklthhITHhRCizTYMrqOGynTJAiQnRKAxbFtJHFIagussEdrIASKsMdibvQoGjpFISbFVxWYQvcnCwVjOcyfuVtjQGsITiFGxGWAuUiepLIfCKlOznUbJIRCSzFImglEQkvnyfujgYAzVGrSFsvDVUqRsrVTzUEIxh");
    double yVYajXLjPV = 75311.28533905526;
    double fZmpmhLdtSwZOuN = -69844.91288727705;
    string MkyvUPpAqtstPZ = string("WALAvorTLqRMRwvQTYRZpwXnxJ");
    string wbyjC = string("qBOEgujBfhLgpuncFYTTDjyCDPhAsKkEDxWZHoxDVmDEQkNbfREdNgzkGUtrAvUlGfbjnMrfpjPWavMcdwoJUjEhCeXSBBREhzlAZZXMOlPKw");

    for (int ARbWylKn = 1873451243; ARbWylKn > 0; ARbWylKn--) {
        yVYajXLjPV /= xsjleBtySMqMA;
        CPwkDmvd = CPwkDmvd;
    }

    if (yVYajXLjPV > -328386.2812624383) {
        for (int oZnyPDTb = 31809588; oZnyPDTb > 0; oZnyPDTb--) {
            rksCEArpDFPaG += GVKvDPNJQ;
        }
    }

    if (xsjleBtySMqMA < -328386.2812624383) {
        for (int xGHzcDLogX = 1027460163; xGHzcDLogX > 0; xGHzcDLogX--) {
            YDdmkWQrzIYd = YDdmkWQrzIYd;
        }
    }

    for (int EcOMh = 1809963326; EcOMh > 0; EcOMh--) {
        GVKvDPNJQ += wbyjC;
        CPwkDmvd -= xsjleBtySMqMA;
        yVYajXLjPV = yVYajXLjPV;
        YDdmkWQrzIYd = yVYajXLjPV;
    }

    for (int AiZYhZHNbaQ = 1680503332; AiZYhZHNbaQ > 0; AiZYhZHNbaQ--) {
        yVYajXLjPV = CPwkDmvd;
        yVYajXLjPV *= CPwkDmvd;
        xsjleBtySMqMA -= YDdmkWQrzIYd;
        fZmpmhLdtSwZOuN *= yVYajXLjPV;
    }

    return NueGXzZnaxDZthv;
}

int PLFXJ::aXOTlrTygWiF(string zYDOGMGLthQwd, int PlgjXbaLaUxxC)
{
    bool ulVndHxKPn = false;
    bool vZRPvEIwcLq = false;

    if (vZRPvEIwcLq != false) {
        for (int AYfzzxKKBhxn = 999806984; AYfzzxKKBhxn > 0; AYfzzxKKBhxn--) {
            zYDOGMGLthQwd += zYDOGMGLthQwd;
            PlgjXbaLaUxxC = PlgjXbaLaUxxC;
            vZRPvEIwcLq = ! vZRPvEIwcLq;
        }
    }

    for (int wazuGxtwtcao = 1934618253; wazuGxtwtcao > 0; wazuGxtwtcao--) {
        vZRPvEIwcLq = ! vZRPvEIwcLq;
        vZRPvEIwcLq = ulVndHxKPn;
        vZRPvEIwcLq = ulVndHxKPn;
        zYDOGMGLthQwd += zYDOGMGLthQwd;
    }

    for (int DZeWFFqW = 1487322373; DZeWFFqW > 0; DZeWFFqW--) {
        PlgjXbaLaUxxC -= PlgjXbaLaUxxC;
        PlgjXbaLaUxxC -= PlgjXbaLaUxxC;
        ulVndHxKPn = ulVndHxKPn;
        vZRPvEIwcLq = ! ulVndHxKPn;
    }

    return PlgjXbaLaUxxC;
}

int PLFXJ::YKCzXH(string IatHCGjBbgT, string gHWbBMvit, string jVCXhCeMQFWqH, double zBsmYgldquBIv)
{
    double LUJqlRyumw = 358413.4669660525;
    int NqBOpVnLM = -689124102;
    double sUOfFnLbb = -122916.49571896579;
    bool inXvjylwhU = false;
    int alkJN = 1277208251;

    if (IatHCGjBbgT == string("kgRqUVTkszzOsejNaxcMjPlQWlpwPgpgOBHDgfhtrCLvdcOtoYMoFRZxvaLliDTGNIikyeYxzsbsaCQwWUepUwJRuMktovSvJMaxcbkUSKFgQxIcUupEmlmZXifvNJzspAcdmklXwbVhGSQpYvqMuIgKgOPtmnlgxnCMVaiFZsUGWWoGvaXlIiwB")) {
        for (int qptLqAdHXCs = 1618640169; qptLqAdHXCs > 0; qptLqAdHXCs--) {
            gHWbBMvit += gHWbBMvit;
            alkJN = NqBOpVnLM;
            IatHCGjBbgT = gHWbBMvit;
            gHWbBMvit = gHWbBMvit;
        }
    }

    if (alkJN < 1277208251) {
        for (int pGscwzcdkedsCU = 1059015684; pGscwzcdkedsCU > 0; pGscwzcdkedsCU--) {
            IatHCGjBbgT = gHWbBMvit;
        }
    }

    for (int nNDQnvWLOC = 238243158; nNDQnvWLOC > 0; nNDQnvWLOC--) {
        sUOfFnLbb = zBsmYgldquBIv;
    }

    if (jVCXhCeMQFWqH > string("kgRqUVTkszzOsejNaxcMjPlQWlpwPgpgOBHDgfhtrCLvdcOtoYMoFRZxvaLliDTGNIikyeYxzsbsaCQwWUepUwJRuMktovSvJMaxcbkUSKFgQxIcUupEmlmZXifvNJzspAcdmklXwbVhGSQpYvqMuIgKgOPtmnlgxnCMVaiFZsUGWWoGvaXlIiwB")) {
        for (int yzPMQUacxM = 384013188; yzPMQUacxM > 0; yzPMQUacxM--) {
            gHWbBMvit += jVCXhCeMQFWqH;
            gHWbBMvit = gHWbBMvit;
        }
    }

    return alkJN;
}

bool PLFXJ::YnyvtG(bool WmDrSflHnM, string PWvzls, string BRqtCmUkinWC)
{
    int ftuIEGCHkYCX = 1012590335;
    double MpszfzJQwKdl = -577775.6326010277;
    double LQrdFMuxlM = -593829.3457372355;

    for (int WdvBzHnNLpT = 1434210681; WdvBzHnNLpT > 0; WdvBzHnNLpT--) {
        continue;
    }

    return WmDrSflHnM;
}

void PLFXJ::bmusbIeFYif(int sehiUsmbxvqLWdU, double RlNLIJybN, string yhfUb)
{
    string DhHVgSfWAphxKDL = string("rYDeSjEpDYRayEeD");
    int OEhlePI = 754948397;
    int qQrpytUEadQqIxNd = -298088244;
    double nAVHLjXdh = -969756.6491980746;
    string MiUfbYKyfB = string("ebItsPhWmwqrnxNroPKiBJnjiwTMKWFiOKwDBWmQWLTlcKuqNVpVrTubeljUVTJLABFFgCbXX");
    int VoGsGGzybtjaP = -1249124436;
    bool HdnQPHJFEoebB = false;

    for (int nhYPTQdgH = 939471638; nhYPTQdgH > 0; nhYPTQdgH--) {
        sehiUsmbxvqLWdU = qQrpytUEadQqIxNd;
    }

    if (yhfUb != string("ebItsPhWmwqrnxNroPKiBJnjiwTMKWFiOKwDBWmQWLTlcKuqNVpVrTubeljUVTJLABFFgCbXX")) {
        for (int iKWsorrRSNudWCye = 1843491044; iKWsorrRSNudWCye > 0; iKWsorrRSNudWCye--) {
            DhHVgSfWAphxKDL = yhfUb;
            DhHVgSfWAphxKDL += DhHVgSfWAphxKDL;
            VoGsGGzybtjaP -= qQrpytUEadQqIxNd;
        }
    }

    for (int NGnKfAMk = 116137861; NGnKfAMk > 0; NGnKfAMk--) {
        VoGsGGzybtjaP = qQrpytUEadQqIxNd;
        OEhlePI *= qQrpytUEadQqIxNd;
        RlNLIJybN = RlNLIJybN;
        VoGsGGzybtjaP *= sehiUsmbxvqLWdU;
        yhfUb = yhfUb;
    }

    for (int esozIdTPmsccjqe = 2131995014; esozIdTPmsccjqe > 0; esozIdTPmsccjqe--) {
        OEhlePI += qQrpytUEadQqIxNd;
        DhHVgSfWAphxKDL = DhHVgSfWAphxKDL;
        yhfUb += DhHVgSfWAphxKDL;
        OEhlePI += sehiUsmbxvqLWdU;
    }

    for (int IPRadVzyrz = 133001781; IPRadVzyrz > 0; IPRadVzyrz--) {
        HdnQPHJFEoebB = HdnQPHJFEoebB;
        yhfUb += MiUfbYKyfB;
    }

    for (int iUTygGKvlQOtMeOy = 1353797301; iUTygGKvlQOtMeOy > 0; iUTygGKvlQOtMeOy--) {
        nAVHLjXdh = RlNLIJybN;
        sehiUsmbxvqLWdU += sehiUsmbxvqLWdU;
        qQrpytUEadQqIxNd = qQrpytUEadQqIxNd;
        OEhlePI += OEhlePI;
    }
}

string PLFXJ::XrobKFAxQqmCtAP(string qWCGbLMwTShWoeN, string OrgPs)
{
    string PAXtSPKJLxX = string("cTMIvWvcGFDwQBkiHtGHlGQmUavTdtJxyyqhOfwDLIqUPWpdpNrVQtWmQXhTdJGMbcBvdSQillFWzpsQoaUrnAhLyuiSLgSPrPtBUtvhiActnEnxFLrCKEgmFdwqKSajBcPKWgCF");
    string KDwEHX = string("AnUVqinnhtdBDRZBSfeAWufyNZsUXNtqwbNerVfivneIbkwJCIbowILRPLnKuIzothWJjfWgWAhLGGHLuehAmDRoobsopDjXbQsLlpkVSAracDROYHPcosbZVpeMoWUuOOypHUdUREhtYdnpFWcQszsJcddnhWRDktYInXCpGNFrqPiooRTISbIZakeeLATVoyknCaqMekGmkIRg");
    bool fRfxsdMIYEh = false;

    if (OrgPs > string("AnUVqinnhtdBDRZBSfeAWufyNZsUXNtqwbNerVfivneIbkwJCIbowILRPLnKuIzothWJjfWgWAhLGGHLuehAmDRoobsopDjXbQsLlpkVSAracDROYHPcosbZVpeMoWUuOOypHUdUREhtYdnpFWcQszsJcddnhWRDktYInXCpGNFrqPiooRTISbIZakeeLATVoyknCaqMekGmkIRg")) {
        for (int vbQvNvkdMPyrFl = 95249956; vbQvNvkdMPyrFl > 0; vbQvNvkdMPyrFl--) {
            fRfxsdMIYEh = ! fRfxsdMIYEh;
            PAXtSPKJLxX = KDwEHX;
            qWCGbLMwTShWoeN += KDwEHX;
            PAXtSPKJLxX = OrgPs;
            qWCGbLMwTShWoeN += qWCGbLMwTShWoeN;
            KDwEHX = PAXtSPKJLxX;
            OrgPs = qWCGbLMwTShWoeN;
            KDwEHX = qWCGbLMwTShWoeN;
        }
    }

    if (OrgPs <= string("sTyJvfLhZvxVhxyoGvEevqylHeZOCbaLdHRuRPKLeZIAXAoPVXFzGAbvjhSYnOzMspUOdIlayFpwQnpuYkcbdylXgzEOiQJhmWzQEIEKqCtTnETOCJaecfUcrXObNjNTmAHVmaeCPSnXULRBuRKHtNOGVoivBBdDpMHPicubtVLpWJLAiZXlKFdaXMWvbeGovDdWcrOGBgnjGqurRXvbYfBs")) {
        for (int WGWbE = 527761174; WGWbE > 0; WGWbE--) {
            qWCGbLMwTShWoeN = PAXtSPKJLxX;
            PAXtSPKJLxX += PAXtSPKJLxX;
            KDwEHX = KDwEHX;
            OrgPs = qWCGbLMwTShWoeN;
            PAXtSPKJLxX = PAXtSPKJLxX;
            KDwEHX = OrgPs;
        }
    }

    if (KDwEHX <= string("cTMIvWvcGFDwQBkiHtGHlGQmUavTdtJxyyqhOfwDLIqUPWpdpNrVQtWmQXhTdJGMbcBvdSQillFWzpsQoaUrnAhLyuiSLgSPrPtBUtvhiActnEnxFLrCKEgmFdwqKSajBcPKWgCF")) {
        for (int EDMQczZHrbJPIC = 537331827; EDMQczZHrbJPIC > 0; EDMQczZHrbJPIC--) {
            KDwEHX = KDwEHX;
            qWCGbLMwTShWoeN += PAXtSPKJLxX;
            qWCGbLMwTShWoeN = PAXtSPKJLxX;
            OrgPs = PAXtSPKJLxX;
            PAXtSPKJLxX += qWCGbLMwTShWoeN;
            OrgPs = qWCGbLMwTShWoeN;
            fRfxsdMIYEh = fRfxsdMIYEh;
            KDwEHX = KDwEHX;
            qWCGbLMwTShWoeN = KDwEHX;
        }
    }

    if (KDwEHX == string("TMYLqsyqdxkcaOBilhBIAztKGhIuzkfsRcAXKEBuFNOVzLzJrigJPRHvPcAhJRcmCNIrjnPxdVBJjLLMolZSeweCxRUxNaAYPyLWRrJnKGKSGetNNyXRrxKwBNeMTenpxNvxYjcVIuUtgAPmAI")) {
        for (int VmwJNscoh = 1038121070; VmwJNscoh > 0; VmwJNscoh--) {
            OrgPs += OrgPs;
            OrgPs = KDwEHX;
            fRfxsdMIYEh = ! fRfxsdMIYEh;
            PAXtSPKJLxX = OrgPs;
            PAXtSPKJLxX = OrgPs;
            qWCGbLMwTShWoeN = OrgPs;
        }
    }

    if (KDwEHX != string("sTyJvfLhZvxVhxyoGvEevqylHeZOCbaLdHRuRPKLeZIAXAoPVXFzGAbvjhSYnOzMspUOdIlayFpwQnpuYkcbdylXgzEOiQJhmWzQEIEKqCtTnETOCJaecfUcrXObNjNTmAHVmaeCPSnXULRBuRKHtNOGVoivBBdDpMHPicubtVLpWJLAiZXlKFdaXMWvbeGovDdWcrOGBgnjGqurRXvbYfBs")) {
        for (int iyIew = 1109275726; iyIew > 0; iyIew--) {
            OrgPs += OrgPs;
        }
    }

    return KDwEHX;
}

bool PLFXJ::CTjokOHmHimY(string lFKGLDbQqhdzy, bool oIWHhlCL, string UWQyS)
{
    string mOInVx = string("afYiRFFlBfyWLRZRyOcOqVYOySoaAiffJehXKzhshBUzMgkXxdNdInFqIBIPwXYYrrCfbIVAPqwcDFoMPPyKUGcQYWGyAMcgPswTwWLPmSRHBDpKRVovEEBuyFTVvceJRBFqzpcEdpluur");
    int gpyLsabYQCAVoXo = -557694802;
    double ZbaQiiFetLPyRje = 374157.9637271346;
    int ECDqWZvTh = -1366226988;
    string KYPkkrah = string("dmMStdPYRdAnrDjAhPlfrWxRsJZXbsjpjRuBaCTlKUJEvgPtPaYAWRSUgHOImEPOwXqMxpxbKMLTZjPRxMhatFSzaPXugGjWYRuqRaKyyLNrOzVD");
    double cTxQZZZ = -375735.8198200533;
    string OSmLaRw = string("digvLEMMLgmJRtwhzaMYqKpMVtoSELyhDAwjYZdhjzdwhbmjRvLnMCSHvTmtdALwAtjLotiTUYmmKpckyPmTqrsgLAivPczvEMdAmIHLCBuOttfksZJaXMMlnxMzXSjLcFrjqaydfdUhlmzurkxwEEwMYGPoTpaYVEmmtTbmmMItjXciAjAxrVYNcgEOnbmJnSyrGAp");
    string HJFAxHrcYeuKo = string("XpMwSZpOvnoJdeppzwwbSxTHYcNzIiBhfLbYCWxZJlvOTLZEjwPKZHJOUgkoRxiW");
    bool nkJfkIL = true;

    if (mOInVx != string("digvLEMMLgmJRtwhzaMYqKpMVtoSELyhDAwjYZdhjzdwhbmjRvLnMCSHvTmtdALwAtjLotiTUYmmKpckyPmTqrsgLAivPczvEMdAmIHLCBuOttfksZJaXMMlnxMzXSjLcFrjqaydfdUhlmzurkxwEEwMYGPoTpaYVEmmtTbmmMItjXciAjAxrVYNcgEOnbmJnSyrGAp")) {
        for (int LVPDLsUEXVJ = 1487631265; LVPDLsUEXVJ > 0; LVPDLsUEXVJ--) {
            OSmLaRw = UWQyS;
            HJFAxHrcYeuKo = UWQyS;
        }
    }

    if (OSmLaRw > string("digvLEMMLgmJRtwhzaMYqKpMVtoSELyhDAwjYZdhjzdwhbmjRvLnMCSHvTmtdALwAtjLotiTUYmmKpckyPmTqrsgLAivPczvEMdAmIHLCBuOttfksZJaXMMlnxMzXSjLcFrjqaydfdUhlmzurkxwEEwMYGPoTpaYVEmmtTbmmMItjXciAjAxrVYNcgEOnbmJnSyrGAp")) {
        for (int wqNXvfqMzaFHec = 794822371; wqNXvfqMzaFHec > 0; wqNXvfqMzaFHec--) {
            lFKGLDbQqhdzy = KYPkkrah;
        }
    }

    for (int LktjZT = 23892360; LktjZT > 0; LktjZT--) {
        UWQyS += UWQyS;
        KYPkkrah = HJFAxHrcYeuKo;
    }

    if (HJFAxHrcYeuKo != string("digvLEMMLgmJRtwhzaMYqKpMVtoSELyhDAwjYZdhjzdwhbmjRvLnMCSHvTmtdALwAtjLotiTUYmmKpckyPmTqrsgLAivPczvEMdAmIHLCBuOttfksZJaXMMlnxMzXSjLcFrjqaydfdUhlmzurkxwEEwMYGPoTpaYVEmmtTbmmMItjXciAjAxrVYNcgEOnbmJnSyrGAp")) {
        for (int ySzJvXhZfNef = 243728443; ySzJvXhZfNef > 0; ySzJvXhZfNef--) {
            OSmLaRw = HJFAxHrcYeuKo;
            mOInVx = KYPkkrah;
            KYPkkrah = OSmLaRw;
        }
    }

    return nkJfkIL;
}

double PLFXJ::GYuLAnWLetkX()
{
    bool FDXlWMBEsYqBmO = true;
    double uWMqRKXblHq = 440218.34915051615;
    bool LgtvtCmNQkX = true;
    bool BVTjjzgFqr = true;
    bool YKeZUHsWy = false;
    string RZlSnEXR = string("DHNCuvEtnLNJhxnzKKcSAfBU");
    string DvZEN = string("oNswchUUvjputRkmnNFDNiHRLdMAZDYpMiGyCqpgIYTKIeRocGbrgoNSHaNEkIvcWMdPVfPlbGgSACDHJJSAlcHQiixQPNJikBzNAAZrgElWnSYeRTK");
    double nGERgrjiWJro = -798422.4511700972;
    int tyDuLElRPXPsjWy = -1437060668;

    if (LgtvtCmNQkX == true) {
        for (int nOBlnBlMOgEDSz = 1231961906; nOBlnBlMOgEDSz > 0; nOBlnBlMOgEDSz--) {
            LgtvtCmNQkX = FDXlWMBEsYqBmO;
            RZlSnEXR = RZlSnEXR;
        }
    }

    for (int TPcDVQ = 844707780; TPcDVQ > 0; TPcDVQ--) {
        FDXlWMBEsYqBmO = LgtvtCmNQkX;
        RZlSnEXR = RZlSnEXR;
        YKeZUHsWy = ! BVTjjzgFqr;
    }

    for (int NHULAdzlScanIDF = 1737442302; NHULAdzlScanIDF > 0; NHULAdzlScanIDF--) {
        uWMqRKXblHq *= nGERgrjiWJro;
    }

    for (int oUJQDfPuEB = 879897871; oUJQDfPuEB > 0; oUJQDfPuEB--) {
        FDXlWMBEsYqBmO = YKeZUHsWy;
    }

    if (BVTjjzgFqr == true) {
        for (int LyVdwsW = 203819568; LyVdwsW > 0; LyVdwsW--) {
            LgtvtCmNQkX = BVTjjzgFqr;
        }
    }

    return nGERgrjiWJro;
}

PLFXJ::PLFXJ()
{
    this->DBqdcGL();
    this->UCPgxLSTVoAi(-1050861298, 84361331, -151781740);
    this->MwIlJRXhLodhxzDB(1652541885);
    this->dXIGXDujlSQuUH(129710.76223966797, string("hsOhvYhPXHkmkHUhrEbTEcprWfLAdqqUuxIucPAeTNFvzvDVOtrUWcGnBRtacXfgcvZGcKMPWAuoTrBqthjcXvQQeOVWmftdZhYhsNMYsRBVgveBFTahzCjTEawgvluZMBVouKFSWNxkYQMeFEHHPuAatZokJbOdRwgjIumzvXcVDGBjzWvANgiZDByOnYZpaupwRYYGjobtNPvyJUuXdudoUe"), -1164639842);
    this->EqsgxoyFgoXuFrS(string("cqscJFVxRiKiGnyPTRrpPpkmdWFTNmOYSgEspRvnvamAYpdhoBmAKKvBWiriWfiyANXdPLggUWBrQUkVwqJfJPQCkDzxO"), string("SKKPfUvWdRfWieUoGrkizSVGqMgkrblQkIreVkFhaQndejjqsNAXPneIiYeMFgObZehzFFUBshXCDPpzZXRQcFiwIjLXXdlOzdrIIOWpSXtRAdVAlzTTrO"), 421228.15049700823, -1130371199);
    this->aXOTlrTygWiF(string("oGXXArCLYXelOFMWqqOMTnAFIAjgfDJZdKwtQTiesGcSyWFhDdzaqAuNL"), 639660604);
    this->YKCzXH(string("kgRqUVTkszzOsejNaxcMjPlQWlpwPgpgOBHDgfhtrCLvdcOtoYMoFRZxvaLliDTGNIikyeYxzsbsaCQwWUepUwJRuMktovSvJMaxcbkUSKFgQxIcUupEmlmZXifvNJzspAcdmklXwbVhGSQpYvqMuIgKgOPtmnlgxnCMVaiFZsUGWWoGvaXlIiwB"), string("eHGhOCFvSirBNhdTfDarJGyVHmKFNGYzSuXgBtoWTFpFYkgWfBBVVfYRjNGtqGbGWwIJYeoOdqhNmjgGiZhtGPhRgEqIBooJfHwmIBztnMrVleBCLEpFpqhWuZFThBZDLWcFazkKqXENVqQJBbXuksyFFhJMPKaWhFZBBLHrOHqSvmaapELMVBaGuCXKrquQUQUtHInXqPelDKSuHnKFoFNVStdflyzisnrVWNemRyZSOtMbIbOLsIbfcACHV"), string("UvxYAoIQsXqJJlePBxPUIsJUZBswnRVOFuygJIVIBTWPdBpxMEOLRoMXKibMsSRqaSthuaLVBEJYyGVRgQBBXdcDYPHLppkPslVqFujNkMcbxxXngRBGJiWUvZnxHabgfPMTKFUvSzFHHdinFvsCrpWlHdqBJChDEnhSzwtRsJCHYMCbkeVplaNayswwtHzuQuifqWCpLzUnHSPeIBBuTUlWrTtjCrwzJkyMnhaJnWfJnbVZIcblyyZjc"), 592598.2671912317);
    this->YnyvtG(true, string("LlycBkBRRRXnaPkLtPMOuyOBIsdrPsHhsJyoVVJOGJqfemohovCEFVWLfNfcCKYODoJOudVtYkYjqpKNCswnViMNhgyohbIASWbixofDMEJyTaRWbXYBMsyWNetbHdZvQgseUjhJvbfOIEhfQugQTVhzHYfMmBcHBNsQdqSxpediURSzZyEwpZEcsyOvAmqTog"), string("JzAnfdzExudySKluqYIspZZRRcKMrEjOhXDqOjKKaydFZQkWccnHPqrWxRcYfHwdMYGsdAVcfFhrFxbhawQosjBgKCcrCSuEXSSGNloQqYfWBhnIoBkiUgNftMZpGZxSXgANVJwicGRRGiEPjqYcFvUQwzYvwrbbyQxpvNfozSvCfyobtwrAiqQKwaQFDKZzijGohkOLEPPZFrmPqzRrVBNUd"));
    this->bmusbIeFYif(1830807553, 673632.2062327918, string("ClioEkczjnYJLsURhOThZDcBCgivDPTwspqmaoinrUtQrAbdpAPNjKCMtbQlPoYfnOqzJIiwvVuBHyZGXmOrUnsHcxFCTpjYuLIPFgBhukSKHwjcqUWHLJHWDGLPtoKXqmsaHSphWjcGHUJxtKjzhVToVDvqaYqInqKoFUvUTqLNrVvZKdkRlDBbtpbdYTUERiubznJLqnpzhxjBLskCCbiNtIQjXdFl"));
    this->XrobKFAxQqmCtAP(string("TMYLqsyqdxkcaOBilhBIAztKGhIuzkfsRcAXKEBuFNOVzLzJrigJPRHvPcAhJRcmCNIrjnPxdVBJjLLMolZSeweCxRUxNaAYPyLWRrJnKGKSGetNNyXRrxKwBNeMTenpxNvxYjcVIuUtgAPmAI"), string("sTyJvfLhZvxVhxyoGvEevqylHeZOCbaLdHRuRPKLeZIAXAoPVXFzGAbvjhSYnOzMspUOdIlayFpwQnpuYkcbdylXgzEOiQJhmWzQEIEKqCtTnETOCJaecfUcrXObNjNTmAHVmaeCPSnXULRBuRKHtNOGVoivBBdDpMHPicubtVLpWJLAiZXlKFdaXMWvbeGovDdWcrOGBgnjGqurRXvbYfBs"));
    this->CTjokOHmHimY(string("pKKJTrJGocExrbaSugfVBosASJWhKzIxTVDGQReuoZfleCmfKeYgcHQHoWowNPdDQrKoKSEfWIZlsfYCjoUxSHQWqdxvgSIwufWWfFpwclntJWBmLSuxUqeQhFpbfljpoUkNitQoqDQkprnMcKMUTXkDSqvVQLWtmHaRSZkARzYiAjYjrxwQATHfZgdDgopqpXYwnxmeSBpZvaUBpTyUNujfBpSfIYDmZZQNYDbEboQDpiHOtqZBfHtiFHewnG"), true, string("dgfgFkGXpZdSWxLVANAv"));
    this->GYuLAnWLetkX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CvTZAqGOL
{
public:
    double cRVBXQI;
    bool HeqmYRVLM;

    CvTZAqGOL();
    bool TYGphMW(bool WpynzuoJLFOwLKQU, bool fZQnbVjmMsHtEt, int XFwIvNT, int HoycCIOoSogHrFRY);
    bool qYURknhqotCZ(int lBmhHxYEpe);
protected:
    bool jUPkfTyTJc;
    double hykgWTWDhUvzl;

    bool GCnSJ(string RTxqKizWtsDK, bool IvYvlabflIwDJy, int AcUjAJTTz, string lfblaBesOBSzSf);
    int wdnYrQCp(int kEYQX, int HDgnzRCnZRGOPt, double zHXHAv);
    bool QRnwOdTlteQSYz();
    string yCWOK();
    double dblOP();
private:
    double gjsaSwBpbq;
    string kVdHusg;
    bool ZoCFuaELufTD;
    int hAVHxboccickQZt;
    bool eKHlMWRABCoIPh;

    bool wYmhDoKYD(string KWZoDwNoFy, double BpDaXMYYMN, string dbuDwxfjJI, string LntQYTMpTj);
    void mTqxtHqtGe(string DjZxSK);
    void cqWLTjBtgnnulMi();
    double kWQlqlTZtQGHysvS(bool VktynW, int hzvhAhUlGyQ);
    double VvOSRfCFasDT(string mkDyROlTAjIXgz, bool ZkQaQHP);
};

bool CvTZAqGOL::TYGphMW(bool WpynzuoJLFOwLKQU, bool fZQnbVjmMsHtEt, int XFwIvNT, int HoycCIOoSogHrFRY)
{
    string vBQYKq = string("woObKOMMAiuzQPlSEuRZZPOrUYCqsPBsqcwvYQlRuQpgofiYZGUssEGWgGwApTgixwRyXwxEPgbOJgbrtaIxJJVHMKOAQlAcqHOuQcJuDckAXPTdHUHlcNEzNFHvTyMkiplOBehzIzKnxwTtzhAVURggrZsLpXkTRZtHLTeSkukPWdJsERVVkOYEnPYcHgroPFBZBKUDCFBSEBYOTUDKFvyPDjZNcrhoPgvMhTJVxVyp");
    double OZIqBWIsb = 64875.976894643965;

    if (HoycCIOoSogHrFRY < -243451279) {
        for (int nkQTbgscZ = 923498483; nkQTbgscZ > 0; nkQTbgscZ--) {
            XFwIvNT /= XFwIvNT;
        }
    }

    for (int yrTwbHyB = 111058585; yrTwbHyB > 0; yrTwbHyB--) {
        vBQYKq = vBQYKq;
        WpynzuoJLFOwLKQU = fZQnbVjmMsHtEt;
        XFwIvNT = XFwIvNT;
    }

    if (fZQnbVjmMsHtEt == false) {
        for (int wlmrzLsljcCbrbG = 1918055035; wlmrzLsljcCbrbG > 0; wlmrzLsljcCbrbG--) {
            fZQnbVjmMsHtEt = ! WpynzuoJLFOwLKQU;
            fZQnbVjmMsHtEt = WpynzuoJLFOwLKQU;
        }
    }

    for (int LILWrACUM = 1117593761; LILWrACUM > 0; LILWrACUM--) {
        continue;
    }

    return fZQnbVjmMsHtEt;
}

bool CvTZAqGOL::qYURknhqotCZ(int lBmhHxYEpe)
{
    int QurLDIeDjKE = -650212315;
    bool bLaWCTOtYJhwa = false;
    int cGHmoNFKjwp = 2004911282;
    int MuToPUKCJzVuAP = -1871884685;
    bool GHYbXA = true;

    if (cGHmoNFKjwp >= 2004911282) {
        for (int BMzQPnZNJ = 2058785633; BMzQPnZNJ > 0; BMzQPnZNJ--) {
            MuToPUKCJzVuAP += QurLDIeDjKE;
            cGHmoNFKjwp -= cGHmoNFKjwp;
            bLaWCTOtYJhwa = ! bLaWCTOtYJhwa;
            cGHmoNFKjwp += lBmhHxYEpe;
            QurLDIeDjKE /= QurLDIeDjKE;
            MuToPUKCJzVuAP += cGHmoNFKjwp;
        }
    }

    return GHYbXA;
}

bool CvTZAqGOL::GCnSJ(string RTxqKizWtsDK, bool IvYvlabflIwDJy, int AcUjAJTTz, string lfblaBesOBSzSf)
{
    double HYciOrqZmqCgMtu = 864142.5921406288;
    string wkQGy = string("UXIxuDrkkURcFliPxvgmlfRlrqgqrtKrDIigbzrIzrNHhYAOVKtnCkDpAnmdtZcIOjZrxrltTFZtQaUFuxtVdfdYDFxYxUZrhAOAlGpjLgvnXaFeDPBPafcrJRNXTOJINYBVnTRCAnxXXwmRrbNfLFgIPZfoQnfWjPvaDdYIcZO");
    bool RJaJCcnf = false;
    string ezZoYgrnNvP = string("JQDKXXayyXyPtbLlYObAvEgZNUbACqKDHGpiHbqTRvJCnrHeIhLJwdYh");

    for (int IIFdxFAMxqPOpCy = 586021747; IIFdxFAMxqPOpCy > 0; IIFdxFAMxqPOpCy--) {
        IvYvlabflIwDJy = IvYvlabflIwDJy;
        AcUjAJTTz /= AcUjAJTTz;
        IvYvlabflIwDJy = ! IvYvlabflIwDJy;
        HYciOrqZmqCgMtu = HYciOrqZmqCgMtu;
    }

    return RJaJCcnf;
}

int CvTZAqGOL::wdnYrQCp(int kEYQX, int HDgnzRCnZRGOPt, double zHXHAv)
{
    int RCmFEiaPSMAnUSGL = 1358533348;
    string xeBDIaNrvPQbxxcS = string("jRTDNZiEizGjiuIudmXtbtaAxbFimAqeyPunDHTSKrUOumtEYbdaZuyraLVioEALkGynfKkxelgiyxfFXIvyOnQOfzXUSsSNEFFxDQkopIjTctaRcvOtlgfEiqmKPsayKTweRmztjgKefcYZcnAVhXMhmhQufbJwkMiQXDYC");
    int HWscd = 983842635;
    string FmBEZwAGqpt = string("CzrOqdciMTrQmqBmSRHUQIypvlrQIySrDzZwkLQfQGpDTQtTPCBaLcRofWtdMkVgbfnGdhjtuOVdaoVjumTbgDHiUnjjnRZWTcrquFwyYTHvAQdCdnFbLsdubKqtraZfbNVFefEDwoeSzMBPMQJFZVmRcUxqsRkCOGafnZusTRkkKAcNnTwCcKmHMZVxchtQWrXPATeuaMSdRYirwGxy");
    int bkKAPxiCWCjJxqEJ = 418201696;

    if (bkKAPxiCWCjJxqEJ >= 1184094666) {
        for (int HzyJPnBmitytIXCE = 1046031520; HzyJPnBmitytIXCE > 0; HzyJPnBmitytIXCE--) {
            RCmFEiaPSMAnUSGL -= RCmFEiaPSMAnUSGL;
        }
    }

    for (int HQavFeQWaRuKsu = 1585382691; HQavFeQWaRuKsu > 0; HQavFeQWaRuKsu--) {
        HWscd *= bkKAPxiCWCjJxqEJ;
        xeBDIaNrvPQbxxcS = FmBEZwAGqpt;
        zHXHAv *= zHXHAv;
        bkKAPxiCWCjJxqEJ /= kEYQX;
    }

    if (HDgnzRCnZRGOPt >= 1184094666) {
        for (int iMmgPOyCyrNA = 928047182; iMmgPOyCyrNA > 0; iMmgPOyCyrNA--) {
            kEYQX += bkKAPxiCWCjJxqEJ;
            kEYQX /= HWscd;
            HDgnzRCnZRGOPt = bkKAPxiCWCjJxqEJ;
            HWscd /= bkKAPxiCWCjJxqEJ;
            HWscd -= bkKAPxiCWCjJxqEJ;
            RCmFEiaPSMAnUSGL = HWscd;
            HDgnzRCnZRGOPt = HWscd;
            HWscd /= kEYQX;
        }
    }

    for (int sGpxnSFIowQDlrk = 1496691148; sGpxnSFIowQDlrk > 0; sGpxnSFIowQDlrk--) {
        xeBDIaNrvPQbxxcS = xeBDIaNrvPQbxxcS;
        HWscd += bkKAPxiCWCjJxqEJ;
        HWscd /= kEYQX;
        HWscd *= HDgnzRCnZRGOPt;
        bkKAPxiCWCjJxqEJ *= bkKAPxiCWCjJxqEJ;
    }

    return bkKAPxiCWCjJxqEJ;
}

bool CvTZAqGOL::QRnwOdTlteQSYz()
{
    bool lVObGomFQ = true;

    return lVObGomFQ;
}

string CvTZAqGOL::yCWOK()
{
    string pyeLIQONCNgSYk = string("WeZFoHhBjxHNnoHkBOjDmevzASSwGJGqQmWZpasrcZetNpdrdHxyksLfmjIAodhwXaZwJKbxNoLvZFdHpgBaRnoMjXHxcfLHDInQEyepiKOajcceaiuhgbiYWVXVeUBOhHyTsLztZrEXcJvOCQKOWpFVIqdnJIfMtdvoodIIwpEc");
    int YLnCxqo = 347334709;
    int OECQRrpWzSLIko = 1220772914;

    if (OECQRrpWzSLIko < 1220772914) {
        for (int XkhpVgiRyXUtK = 563242043; XkhpVgiRyXUtK > 0; XkhpVgiRyXUtK--) {
            YLnCxqo *= OECQRrpWzSLIko;
            pyeLIQONCNgSYk += pyeLIQONCNgSYk;
            OECQRrpWzSLIko += YLnCxqo;
            YLnCxqo /= YLnCxqo;
            OECQRrpWzSLIko /= OECQRrpWzSLIko;
            YLnCxqo -= OECQRrpWzSLIko;
        }
    }

    if (OECQRrpWzSLIko != 347334709) {
        for (int OGKPF = 682735298; OGKPF > 0; OGKPF--) {
            YLnCxqo += OECQRrpWzSLIko;
            YLnCxqo = YLnCxqo;
            OECQRrpWzSLIko /= YLnCxqo;
            YLnCxqo -= OECQRrpWzSLIko;
        }
    }

    for (int yYOtik = 532930581; yYOtik > 0; yYOtik--) {
        pyeLIQONCNgSYk = pyeLIQONCNgSYk;
    }

    for (int DRWNvDK = 2042824147; DRWNvDK > 0; DRWNvDK--) {
        OECQRrpWzSLIko *= OECQRrpWzSLIko;
        YLnCxqo += YLnCxqo;
        OECQRrpWzSLIko *= OECQRrpWzSLIko;
        YLnCxqo += OECQRrpWzSLIko;
        YLnCxqo += YLnCxqo;
        pyeLIQONCNgSYk = pyeLIQONCNgSYk;
    }

    if (pyeLIQONCNgSYk != string("WeZFoHhBjxHNnoHkBOjDmevzASSwGJGqQmWZpasrcZetNpdrdHxyksLfmjIAodhwXaZwJKbxNoLvZFdHpgBaRnoMjXHxcfLHDInQEyepiKOajcceaiuhgbiYWVXVeUBOhHyTsLztZrEXcJvOCQKOWpFVIqdnJIfMtdvoodIIwpEc")) {
        for (int FHPKDSDOsYc = 457373869; FHPKDSDOsYc > 0; FHPKDSDOsYc--) {
            OECQRrpWzSLIko *= YLnCxqo;
            OECQRrpWzSLIko += YLnCxqo;
            YLnCxqo *= OECQRrpWzSLIko;
            OECQRrpWzSLIko += YLnCxqo;
        }
    }

    return pyeLIQONCNgSYk;
}

double CvTZAqGOL::dblOP()
{
    int VfXXYJyaBUaDnodN = 623809305;
    double nAcTk = -809168.4577342556;
    bool dgqtEssBkqG = true;
    double NOjSiNZFFQImV = -734742.9522046886;
    string hRTRCzcHsVykIm = string("itcziGbUhVOGgOdAmndNOLgkBCMyIpUlihbXktcpnKWgTQphMVP");

    for (int QPOlTQ = 1925013909; QPOlTQ > 0; QPOlTQ--) {
        NOjSiNZFFQImV -= NOjSiNZFFQImV;
        NOjSiNZFFQImV -= NOjSiNZFFQImV;
    }

    if (nAcTk != -734742.9522046886) {
        for (int kdnSlRzeb = 604549436; kdnSlRzeb > 0; kdnSlRzeb--) {
            continue;
        }
    }

    if (NOjSiNZFFQImV >= -734742.9522046886) {
        for (int QHUhmv = 961228894; QHUhmv > 0; QHUhmv--) {
            NOjSiNZFFQImV *= nAcTk;
            NOjSiNZFFQImV -= nAcTk;
        }
    }

    for (int QRpfUyppIZ = 1631461015; QRpfUyppIZ > 0; QRpfUyppIZ--) {
        NOjSiNZFFQImV /= NOjSiNZFFQImV;
    }

    if (nAcTk >= -734742.9522046886) {
        for (int pDjqEICbsvtAfq = 2066180942; pDjqEICbsvtAfq > 0; pDjqEICbsvtAfq--) {
            nAcTk /= NOjSiNZFFQImV;
        }
    }

    if (NOjSiNZFFQImV < -734742.9522046886) {
        for (int YRqKoZsAbm = 775019492; YRqKoZsAbm > 0; YRqKoZsAbm--) {
            nAcTk += nAcTk;
            VfXXYJyaBUaDnodN /= VfXXYJyaBUaDnodN;
            nAcTk *= NOjSiNZFFQImV;
        }
    }

    if (hRTRCzcHsVykIm <= string("itcziGbUhVOGgOdAmndNOLgkBCMyIpUlihbXktcpnKWgTQphMVP")) {
        for (int HTYGmtryL = 155698062; HTYGmtryL > 0; HTYGmtryL--) {
            VfXXYJyaBUaDnodN += VfXXYJyaBUaDnodN;
        }
    }

    return NOjSiNZFFQImV;
}

bool CvTZAqGOL::wYmhDoKYD(string KWZoDwNoFy, double BpDaXMYYMN, string dbuDwxfjJI, string LntQYTMpTj)
{
    bool tgCfLBmitYrrPVTK = true;
    int UqBQOghbYUpgZUVi = -435580140;

    if (KWZoDwNoFy == string("ryKZoyhQRKCGxgaCDNEoMaBzmzEgHJLnCOJuBjYOYjomuIlNFsPrcaFWtFMRuuxjUqFQdyOvIXCrLTbHEcSGqLtrFknLfewLkEgLjnw")) {
        for (int ckJxRKp = 1514574304; ckJxRKp > 0; ckJxRKp--) {
            UqBQOghbYUpgZUVi = UqBQOghbYUpgZUVi;
        }
    }

    for (int PtTCPcatXkLoyaNd = 851490715; PtTCPcatXkLoyaNd > 0; PtTCPcatXkLoyaNd--) {
        LntQYTMpTj = KWZoDwNoFy;
    }

    for (int whuHuBiLPLgPI = 2095608760; whuHuBiLPLgPI > 0; whuHuBiLPLgPI--) {
        LntQYTMpTj = dbuDwxfjJI;
        KWZoDwNoFy += LntQYTMpTj;
    }

    return tgCfLBmitYrrPVTK;
}

void CvTZAqGOL::mTqxtHqtGe(string DjZxSK)
{
    int qJPnXCSOBuoulWU = -278251230;
    int AJkuxZuOfQQCM = -511258888;

    if (qJPnXCSOBuoulWU > -278251230) {
        for (int iJRZBY = 1684277769; iJRZBY > 0; iJRZBY--) {
            AJkuxZuOfQQCM -= AJkuxZuOfQQCM;
        }
    }

    for (int SdPadUEFmZ = 1858995069; SdPadUEFmZ > 0; SdPadUEFmZ--) {
        AJkuxZuOfQQCM += qJPnXCSOBuoulWU;
        qJPnXCSOBuoulWU *= AJkuxZuOfQQCM;
    }

    if (AJkuxZuOfQQCM == -511258888) {
        for (int HptMyXvs = 2004880921; HptMyXvs > 0; HptMyXvs--) {
            qJPnXCSOBuoulWU /= qJPnXCSOBuoulWU;
            AJkuxZuOfQQCM -= AJkuxZuOfQQCM;
            qJPnXCSOBuoulWU -= AJkuxZuOfQQCM;
        }
    }

    if (qJPnXCSOBuoulWU >= -278251230) {
        for (int cOEjFRRPH = 71368265; cOEjFRRPH > 0; cOEjFRRPH--) {
            continue;
        }
    }
}

void CvTZAqGOL::cqWLTjBtgnnulMi()
{
    bool ssMfagx = false;
    bool BEtxTpYfsfVVd = true;
    int dCvYk = 2004324367;
    double uRyxJ = -679106.4538396044;
    int tWCboQud = 2139320306;
    string hfLoFINo = string("SriPHzoAPizwwOBssxoJSdJkBDkMNhybLEMheUUhSQNLXelVJJiOoOjwANhOPgViifblnqgWBtjWhEZESgIEiQnuAwtmGjgWXNdabhFXDmCXWlfzjLFwEpvIaFHgsPZmSeRkCnsvemJMpdvjTgmTmuFKliYZZmDvxzBVqfNmMisCUiCJjDeguUIjyjORPxHnhMlntMJDPjGjZaetMIgkan");
    string LJGzRZXUQjq = string("dqHngsdSlCqqSweEKTqsSfxbQgZmHloFvWcRhpSZxuboJWbwqdneHAzciaBdiAhtDBRWdNemMYVFFliGjzyVEpRvdTLDXbkrVToBTsGJWYjvjVzabrIBgFXUeKxDpPEpeNlrmkJRjmUKynLRUKbxEtYmirybbruhfsrGIsmrcKkrtTmJ");
    string baiJgoGoXmQtcsuF = string("DrvWntwkbdnpfqHqYjhVDyYfFftiIfEyKIPpazwkdTYfPkIiNLMpKJBbWUdBJwPOZRxArYbtPEBvHJuPeSLWotSFoPlWSpltDQvIExCOwCIqshBmTnObPRackElRQCrcTJKJKcZvYLzIDFCkUTTTTLFvOWoJtOZVSltvbAocFnkXUARqaKhBYIOKNQMepGzrVmBCMMiURmmSnVZUKjyXLbnqSPwYGwzDQryB");
    int LQnIAQ = 2111813362;
    string dErybZLmxTqPbHEc = string("HngihwtFmoZTREbzLjLJZoSRKAcJmKVyOnzyCSnfLkMAERMuGSIFyCtMwPDJuFdHrStSdmbyEuWClujehMTNlXGtQMhCRtcKwasxzzhHmwqJzZcLMFefVYdiavccJtMUPxfHeHVvSZGhAnVMrAlmEeeBuJklQvjYcispqpVvKrNpiUMPBoSbjoHBQWdlWUZrnZuvAEvAKwkClUcNodRymyqEgyBsUdhcRuoFZbDSmNyNIKMVQqyKCZdmwN");

    for (int KqPWgTzSswndfoNI = 1497358847; KqPWgTzSswndfoNI > 0; KqPWgTzSswndfoNI--) {
        uRyxJ -= uRyxJ;
        uRyxJ -= uRyxJ;
    }
}

double CvTZAqGOL::kWQlqlTZtQGHysvS(bool VktynW, int hzvhAhUlGyQ)
{
    double FgardROR = 745931.5161741864;
    bool aYvEbmJ = true;
    bool Zpkjcu = false;

    if (hzvhAhUlGyQ > -695047757) {
        for (int ChmYOn = 439282561; ChmYOn > 0; ChmYOn--) {
            Zpkjcu = Zpkjcu;
        }
    }

    for (int GWSJZWooCHzhoJ = 1580397973; GWSJZWooCHzhoJ > 0; GWSJZWooCHzhoJ--) {
        FgardROR += FgardROR;
        VktynW = aYvEbmJ;
    }

    return FgardROR;
}

double CvTZAqGOL::VvOSRfCFasDT(string mkDyROlTAjIXgz, bool ZkQaQHP)
{
    bool ZEBecRDXlskLof = true;
    double PQXzFWkhWiM = 86640.39475110202;

    return PQXzFWkhWiM;
}

CvTZAqGOL::CvTZAqGOL()
{
    this->TYGphMW(false, false, -243451279, -1325228427);
    this->qYURknhqotCZ(829748061);
    this->GCnSJ(string("HFSPZxvkVPXtNAWjEznaqfLoHLRLriACwvXxoDTdhKxCfuHdBGxrkvncPfaaqmdmwWucsLmUePOqOivPWmDeSKjARfQVwqHxJbhhznxDebYQnEgDlQiINptDjgGFPmLzr"), true, 947295033, string("npBWBsxJsNvTIbAuGjzEXmTnQIEyRTNAyJUuQDkGcCSbpNEHsYNgpKXgpdFackxfoRSVLModuravtshZIozpigWoLIgAbEcBqIJtKNQoDpHetgFvKPOcCUUVRYPOxVkyigsJFeskYdBylnXrkQWnZyYRXvqbVklUQQSmQSDApTarBDImQfCPVoiKZlGqrgkarKCLBuSvGUMKfKdgRgu"));
    this->wdnYrQCp(-489254909, 1184094666, -414634.2207884576);
    this->QRnwOdTlteQSYz();
    this->yCWOK();
    this->dblOP();
    this->wYmhDoKYD(string("DbAhMn"), 996310.3380886441, string("UVNJotXSBqLLZNmLxtcUEUuziQXuUMlioIDNuvSWhaMskDQFPYebAEDRKVmXDFVXompFmZuWCiZTNGdPhoVAtxUCpcgOnLyVBpJswLtsEesvePRJpKWzHDzrDvhiCabGkBgUJNNNyNskXnJdZcbGuxRfzjGD"), string("ryKZoyhQRKCGxgaCDNEoMaBzmzEgHJLnCOJuBjYOYjomuIlNFsPrcaFWtFMRuuxjUqFQdyOvIXCrLTbHEcSGqLtrFknLfewLkEgLjnw"));
    this->mTqxtHqtGe(string("NpiwqmrDVyvefUGBfbizZikMgGoBAUGTwNWIzLVgUkLyxmXeSoCaUZssbzonpSTNwgZNrLXyRAivGkchZnKREuyLETHRKqVqdZqxmaoCEDzcGSywRFfbgEIMRxKGXfrUtIu"));
    this->cqWLTjBtgnnulMi();
    this->kWQlqlTZtQGHysvS(true, -695047757);
    this->VvOSRfCFasDT(string("eIWiWoPaoUebGifpkJWcXouplVemooAyaIiIBHTQRjSFMobXpcEjuqTvKDHbEVJhXViuiXXNWjDRPPcNOfcwWgEBXFpOHFXkQDTrZRXFWwmcIxpAYtgxKabuUZgdNqgcDFTGFuhoDblYEyuMStpYASxpJIKTOPwxiTaPMInvCktvbMEhRthsjLwXtzaYmqwhcdZQKtoKISYTMzliDYLNwaRbamiGt"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IEYdfXwKhs
{
public:
    string YGnsLSSIPJtQV;
    string ZQZtdvkOrjCZtIJ;
    bool CHnugaazXI;

    IEYdfXwKhs();
    string lylhackpAfjwB(bool JtIsYqSaAdI, string dWoZkoOZIB, bool sGDvrRJkw, bool hdLohIIYvreVP, string HyuzPYjqAK);
    int HYVIOEcvLkwji();
    double nZvnoNGKOzgJVBET(int TsYBRwWhCTCa, int fgJYthLxY);
    string HyRSlwPfvpH(string uydrluhEArDBt, int hrlYMFc);
    bool rIQAlreywXJySZj(double MQUlZDuoIdQAU, int eQfLDuiCQ);
protected:
    bool gfDScFTVJpFIXqa;

    int tnMvnW(double RATFriRfn, string aVKuGxgVsPWtfBx, int ATJMiLLhbVbVNZk, bool UABgin);
    bool ytnlZBlTzKZbY(bool QvQidu, bool NFPnqQBoaSGILctn, bool hTbBqznlgagjR);
    double qkbyVu(string ZSZkifCgaTqJKm, string cobAzHZUPdDFWkU, int GIJXuKVhc, int DdhpIOawGd, string hAKXf);
    string sKbpWtLIKUlHPds(string mIhZfs, string SFaiMOkRg, int jeqgocBJTioQ);
    void reXKopFnPCxKrrij();
private:
    bool KuEHiimBLJ;
    double AvNwo;
    bool jtdUDu;
    string JpPYAFLgOmeSTl;

    string qvJHGDUClXYIUCy(string dEeJa, string INMaGlJmRbOYI, int rBNIWxEBbuLD, string wrhhfubguNnquwMc, string mLJNqiHevtmaS);
};

string IEYdfXwKhs::lylhackpAfjwB(bool JtIsYqSaAdI, string dWoZkoOZIB, bool sGDvrRJkw, bool hdLohIIYvreVP, string HyuzPYjqAK)
{
    string mTVmXqbsFidr = string("QtqTRStOZlWtlfodbwadKXcigHrJuJQurIOIgIMhirAhrJvUpmsatNkxvzhoPIFvtagHBXBTlEbewtcjaoZWZpnDBAGbHtkEidjXXYnBkElgvXaO");
    int MqawRnwcKjjYH = -60394708;
    bool IvNxfemPf = false;
    bool VBtMQmo = false;

    if (IvNxfemPf != true) {
        for (int tUwSqo = 2056392930; tUwSqo > 0; tUwSqo--) {
            mTVmXqbsFidr += dWoZkoOZIB;
            VBtMQmo = VBtMQmo;
        }
    }

    for (int AyrxhnkROhK = 1839093079; AyrxhnkROhK > 0; AyrxhnkROhK--) {
        continue;
    }

    for (int XSYPDPDycEqfL = 158911921; XSYPDPDycEqfL > 0; XSYPDPDycEqfL--) {
        continue;
    }

    return mTVmXqbsFidr;
}

int IEYdfXwKhs::HYVIOEcvLkwji()
{
    double txWhFcQ = 718854.400906925;

    if (txWhFcQ < 718854.400906925) {
        for (int lwyGpGoHJngP = 2048246211; lwyGpGoHJngP > 0; lwyGpGoHJngP--) {
            txWhFcQ *= txWhFcQ;
            txWhFcQ = txWhFcQ;
            txWhFcQ += txWhFcQ;
            txWhFcQ *= txWhFcQ;
            txWhFcQ /= txWhFcQ;
            txWhFcQ += txWhFcQ;
            txWhFcQ = txWhFcQ;
            txWhFcQ /= txWhFcQ;
            txWhFcQ -= txWhFcQ;
        }
    }

    return -895092595;
}

double IEYdfXwKhs::nZvnoNGKOzgJVBET(int TsYBRwWhCTCa, int fgJYthLxY)
{
    bool kRQggQgO = true;
    double uMyxdIEzbhoL = -819888.7920367854;
    int RUKBClICLSg = -2069404134;
    int LlyMPSYSniGBsM = 574300423;

    if (RUKBClICLSg > -652757537) {
        for (int nGrFFygDQqryoDL = 1797570781; nGrFFygDQqryoDL > 0; nGrFFygDQqryoDL--) {
            LlyMPSYSniGBsM /= fgJYthLxY;
            fgJYthLxY *= TsYBRwWhCTCa;
            uMyxdIEzbhoL *= uMyxdIEzbhoL;
        }
    }

    for (int ZkQJx = 787428390; ZkQJx > 0; ZkQJx--) {
        TsYBRwWhCTCa *= TsYBRwWhCTCa;
        TsYBRwWhCTCa /= TsYBRwWhCTCa;
        LlyMPSYSniGBsM -= fgJYthLxY;
    }

    return uMyxdIEzbhoL;
}

string IEYdfXwKhs::HyRSlwPfvpH(string uydrluhEArDBt, int hrlYMFc)
{
    bool ZwcJjSeIoloGqK = true;
    bool oCyKLnQ = false;
    string zSESJhoZS = string("tylSMLXnkFPgSejHJGZmhXCtuQiwffgpETjtJBpgWeDEaumVNInMoiGYQBsnTkliEoxTgbAriXTXACUelDiPmeUmOQyZDVluGzEpnYJEPJbnurMvUHxxTKFZyjOJbKtSSHqXQQJGFdTWYOIWYuLdiTrMSNSZsVSXkknfXuKkFtIvGzwfLGJAMoleDcqKYqZHloaDLzxxpTNHzBfsmGGNbZYOgbCDcX");
    bool pGjAastGYFfg = true;
    int bzIGDHzBLSxZriBW = -1082990280;
    double PYKYUuoCwpVDQ = -768414.4018557987;
    string mITKGSzuWGX = string("uzqScvkDfHvKNYlmoAxeDwBYEZItrotQNNNAFqyMxjxYfSmrIYUdULBDjwMHIxSEgOnjqGnMAsRaByQXZGffeXlyTCxpHToBdfOikCXmZrGbmzzqKSmSAHFrgkIDuBCDgtyQiJEhLNJGMAGRFYhKYzCa");
    double IMFNGkkQI = 143890.06608680877;

    for (int PGEwWR = 1296676219; PGEwWR > 0; PGEwWR--) {
        uydrluhEArDBt += mITKGSzuWGX;
        zSESJhoZS += zSESJhoZS;
    }

    for (int FdUoCeQuRJ = 119110670; FdUoCeQuRJ > 0; FdUoCeQuRJ--) {
        IMFNGkkQI = IMFNGkkQI;
        zSESJhoZS += zSESJhoZS;
        uydrluhEArDBt = uydrluhEArDBt;
    }

    for (int fRjZyieHLcJeL = 590136700; fRjZyieHLcJeL > 0; fRjZyieHLcJeL--) {
        bzIGDHzBLSxZriBW -= hrlYMFc;
        IMFNGkkQI -= PYKYUuoCwpVDQ;
        hrlYMFc = hrlYMFc;
    }

    for (int fXRJq = 1144227932; fXRJq > 0; fXRJq--) {
        uydrluhEArDBt += uydrluhEArDBt;
    }

    for (int fhVfNEuoJYd = 1776934367; fhVfNEuoJYd > 0; fhVfNEuoJYd--) {
        IMFNGkkQI -= PYKYUuoCwpVDQ;
        mITKGSzuWGX = uydrluhEArDBt;
    }

    return mITKGSzuWGX;
}

bool IEYdfXwKhs::rIQAlreywXJySZj(double MQUlZDuoIdQAU, int eQfLDuiCQ)
{
    string oFxhZvNMvytwUOTj = string("yDIrWJUQCsXAADNpgzUttCviCcANCsrdDWcmICmsWONACIEIAaFqEukyjSfDaIZloKemmyajuCbqgdUnAkXbfOqsXXORUJFJRekFwNUewKXfmAOSEbiaRNthUeHdYuUeytqMSBPYzmWsdikpznTdxFDQQUtrKJgcOhnQSkQtjuEBYYKbmavLvfGMavsQBmKgtrMOxnjoTRviIGZgBJXYXUGYh");
    int tggeblMoNZEmiF = -592096612;
    int YfLmLR = -97150908;
    int eRNsjzHnHtWCXCcg = 1665620231;

    if (eQfLDuiCQ > -2027904234) {
        for (int bczymicHDpOWh = 1194057887; bczymicHDpOWh > 0; bczymicHDpOWh--) {
            eQfLDuiCQ *= eQfLDuiCQ;
        }
    }

    if (YfLmLR <= -97150908) {
        for (int UcsJptrtKhOqdEyo = 1223949363; UcsJptrtKhOqdEyo > 0; UcsJptrtKhOqdEyo--) {
            MQUlZDuoIdQAU *= MQUlZDuoIdQAU;
            tggeblMoNZEmiF = eRNsjzHnHtWCXCcg;
            YfLmLR -= eRNsjzHnHtWCXCcg;
        }
    }

    for (int kXHJszynBMrWev = 82634183; kXHJszynBMrWev > 0; kXHJszynBMrWev--) {
        tggeblMoNZEmiF += YfLmLR;
        eQfLDuiCQ -= eRNsjzHnHtWCXCcg;
        eRNsjzHnHtWCXCcg -= tggeblMoNZEmiF;
    }

    for (int quqWJgZq = 1329794825; quqWJgZq > 0; quqWJgZq--) {
        tggeblMoNZEmiF += tggeblMoNZEmiF;
        eRNsjzHnHtWCXCcg = YfLmLR;
    }

    return false;
}

int IEYdfXwKhs::tnMvnW(double RATFriRfn, string aVKuGxgVsPWtfBx, int ATJMiLLhbVbVNZk, bool UABgin)
{
    double fbHLotTKNCP = -308726.15019413194;
    double bRvKG = -524774.6953129082;

    for (int THMjo = 351962093; THMjo > 0; THMjo--) {
        ATJMiLLhbVbVNZk *= ATJMiLLhbVbVNZk;
    }

    for (int HoPiTUqQakaWC = 1323785122; HoPiTUqQakaWC > 0; HoPiTUqQakaWC--) {
        fbHLotTKNCP /= bRvKG;
    }

    for (int GIjYADEtGLJ = 1784383581; GIjYADEtGLJ > 0; GIjYADEtGLJ--) {
        RATFriRfn -= bRvKG;
    }

    for (int HjCmFt = 1538979009; HjCmFt > 0; HjCmFt--) {
        bRvKG /= bRvKG;
        RATFriRfn -= RATFriRfn;
    }

    return ATJMiLLhbVbVNZk;
}

bool IEYdfXwKhs::ytnlZBlTzKZbY(bool QvQidu, bool NFPnqQBoaSGILctn, bool hTbBqznlgagjR)
{
    bool OasfxVIJ = true;
    int KJGPtfg = -2025887094;
    int mPOZzps = 435021174;

    if (NFPnqQBoaSGILctn != false) {
        for (int wbPPIMRvr = 1634199203; wbPPIMRvr > 0; wbPPIMRvr--) {
            hTbBqznlgagjR = ! NFPnqQBoaSGILctn;
            hTbBqznlgagjR = OasfxVIJ;
            NFPnqQBoaSGILctn = ! QvQidu;
            QvQidu = OasfxVIJ;
        }
    }

    if (NFPnqQBoaSGILctn != true) {
        for (int HEXMdnSoo = 67781866; HEXMdnSoo > 0; HEXMdnSoo--) {
            NFPnqQBoaSGILctn = ! QvQidu;
            OasfxVIJ = ! hTbBqznlgagjR;
            mPOZzps = KJGPtfg;
            OasfxVIJ = QvQidu;
            hTbBqznlgagjR = OasfxVIJ;
            OasfxVIJ = OasfxVIJ;
        }
    }

    for (int RFGjvVywLBu = 924051569; RFGjvVywLBu > 0; RFGjvVywLBu--) {
        NFPnqQBoaSGILctn = ! hTbBqznlgagjR;
        KJGPtfg *= mPOZzps;
        OasfxVIJ = ! QvQidu;
        NFPnqQBoaSGILctn = hTbBqznlgagjR;
    }

    if (hTbBqznlgagjR == false) {
        for (int mAods = 1130861635; mAods > 0; mAods--) {
            hTbBqznlgagjR = hTbBqznlgagjR;
            OasfxVIJ = NFPnqQBoaSGILctn;
            KJGPtfg /= mPOZzps;
            OasfxVIJ = ! QvQidu;
            OasfxVIJ = OasfxVIJ;
        }
    }

    if (OasfxVIJ == true) {
        for (int WGRDUwGsmi = 1928014416; WGRDUwGsmi > 0; WGRDUwGsmi--) {
            KJGPtfg += mPOZzps;
            QvQidu = ! OasfxVIJ;
            QvQidu = ! QvQidu;
            NFPnqQBoaSGILctn = ! OasfxVIJ;
        }
    }

    for (int raPSDvXyvZAeOwt = 1202434196; raPSDvXyvZAeOwt > 0; raPSDvXyvZAeOwt--) {
        QvQidu = NFPnqQBoaSGILctn;
    }

    return OasfxVIJ;
}

double IEYdfXwKhs::qkbyVu(string ZSZkifCgaTqJKm, string cobAzHZUPdDFWkU, int GIJXuKVhc, int DdhpIOawGd, string hAKXf)
{
    double iXOjJPPhy = 434595.2997714994;
    int XVuDMvGIYdZzfT = -1358776836;
    double cVSFLHSRSPE = 648721.9202199087;
    double tlnRfDYR = 314709.597500848;
    bool SSrSmnLloeEQaUgr = false;
    bool HEWiw = true;
    string GyXaxp = string("JOSweFvxovGAyqWishcHMwjyCrBPIzGJLHVxIPUpjPZTYNCpcWLVvRpmppfRalkWELRTHYWirdoTwngUyRjkWNPoUxLRPktqWGhXebUkpKUIRCaqxbgPsbWNnylPBdFKqVDRFZNzsdSfKlyvoBIlGvBp");

    for (int ssfloz = 946279988; ssfloz > 0; ssfloz--) {
        ZSZkifCgaTqJKm = hAKXf;
        GyXaxp = ZSZkifCgaTqJKm;
        GyXaxp = hAKXf;
    }

    for (int WiLxFA = 439129239; WiLxFA > 0; WiLxFA--) {
        tlnRfDYR *= tlnRfDYR;
    }

    for (int aiAvG = 1918341898; aiAvG > 0; aiAvG--) {
        continue;
    }

    for (int YyrOYhNeom = 378430748; YyrOYhNeom > 0; YyrOYhNeom--) {
        cobAzHZUPdDFWkU = hAKXf;
        GIJXuKVhc = GIJXuKVhc;
    }

    for (int VYORU = 1643467619; VYORU > 0; VYORU--) {
        continue;
    }

    for (int oNUiBmrT = 587393530; oNUiBmrT > 0; oNUiBmrT--) {
        cobAzHZUPdDFWkU += GyXaxp;
    }

    return tlnRfDYR;
}

string IEYdfXwKhs::sKbpWtLIKUlHPds(string mIhZfs, string SFaiMOkRg, int jeqgocBJTioQ)
{
    bool mkRvKwAKioCaN = false;
    double AmhKkSmnzUzzXdcs = -482002.3514525679;
    bool nmSuYx = false;

    for (int OewHqzEjvOi = 1129132602; OewHqzEjvOi > 0; OewHqzEjvOi--) {
        continue;
    }

    if (jeqgocBJTioQ < 531162969) {
        for (int NUZavBwXNGuD = 219203003; NUZavBwXNGuD > 0; NUZavBwXNGuD--) {
            continue;
        }
    }

    for (int bBXTaNrLCF = 899656782; bBXTaNrLCF > 0; bBXTaNrLCF--) {
        SFaiMOkRg += mIhZfs;
    }

    for (int dHBeqYG = 1103528388; dHBeqYG > 0; dHBeqYG--) {
        SFaiMOkRg = SFaiMOkRg;
        mIhZfs = SFaiMOkRg;
        mkRvKwAKioCaN = mkRvKwAKioCaN;
    }

    for (int ECwXdgqQsmbU = 1918121731; ECwXdgqQsmbU > 0; ECwXdgqQsmbU--) {
        SFaiMOkRg += mIhZfs;
    }

    return SFaiMOkRg;
}

void IEYdfXwKhs::reXKopFnPCxKrrij()
{
    bool JsqEGGchlO = false;
    int pkxCsaAY = -929191289;
    bool hzOnnBe = false;
    bool rzktOJCAEWkBBys = true;
    string zydEwXlb = string("SkeiXiIGKsQqddXQOGXGejwFMkqxoEIVXKzRJjsoRAdysNxnDRKOCApWdWamZgpPpmgOSDKRIDDMrmKLQHSSwGqtvrUMopglVyvAAcxNYaqwGaya");

    if (hzOnnBe != false) {
        for (int xpCNPsg = 527524335; xpCNPsg > 0; xpCNPsg--) {
            zydEwXlb += zydEwXlb;
            rzktOJCAEWkBBys = ! hzOnnBe;
            JsqEGGchlO = ! JsqEGGchlO;
            rzktOJCAEWkBBys = ! hzOnnBe;
            JsqEGGchlO = JsqEGGchlO;
        }
    }

    for (int aWzvHtG = 326010896; aWzvHtG > 0; aWzvHtG--) {
        JsqEGGchlO = rzktOJCAEWkBBys;
    }

    for (int HEaSIBHYEkzZ = 326337397; HEaSIBHYEkzZ > 0; HEaSIBHYEkzZ--) {
        JsqEGGchlO = hzOnnBe;
    }

    for (int SCSbvaIAhznSjL = 724926324; SCSbvaIAhznSjL > 0; SCSbvaIAhznSjL--) {
        hzOnnBe = ! hzOnnBe;
        rzktOJCAEWkBBys = rzktOJCAEWkBBys;
        hzOnnBe = ! hzOnnBe;
        hzOnnBe = ! JsqEGGchlO;
        rzktOJCAEWkBBys = ! rzktOJCAEWkBBys;
    }
}

string IEYdfXwKhs::qvJHGDUClXYIUCy(string dEeJa, string INMaGlJmRbOYI, int rBNIWxEBbuLD, string wrhhfubguNnquwMc, string mLJNqiHevtmaS)
{
    bool XHeYocZZA = false;
    string WnDNbg = string("ScQJIjLxOAyZSHkFIlavsMslbTDFnXvccCKXvkiBrCwFwdPraPVBteEKmzxKKeAIzRwcQmnYsVEtILcGguyFHwqxvGBfEhiIUUNzvaXkdAZifaRWRkjyZUoLObgayTPyTkbCpPWbgEdLTbfsQuwNyCnHqIHGpZaiJAIslbLQvlPQQQasTqghGJPZrpckllLxgAGNjqfKkCuLEjuKkdozQWTNERCTuBIutqvlvtruHkMCehxill");
    bool cMZVbn = true;
    int oXypnDvup = 1934388984;
    string mduWmlT = string("RFVDngBNCXDVLrDLQeBRyzlTgdOmsolxEeJQdegmVdqtMAPipQPROehlbaatdtptMtBwwNJzxcCHKtBARcowUXekxmcZnPYCpBHNv");
    double lZTpuExMqlQCKtJ = -622113.414331668;

    for (int wfCeCcPaqCV = 232233652; wfCeCcPaqCV > 0; wfCeCcPaqCV--) {
        WnDNbg = WnDNbg;
        mLJNqiHevtmaS = mLJNqiHevtmaS;
        WnDNbg = WnDNbg;
    }

    return mduWmlT;
}

IEYdfXwKhs::IEYdfXwKhs()
{
    this->lylhackpAfjwB(false, string("cRlqDsKvkaedSNHpdMejGZNKMBXilxoBFEAvlRi"), true, true, string("eWcZRLPSVsELCBlMZKNwcANnblgwdwQgWjEjdzPFzfTeUDvCUJmLsnyrVrmtsNdojPqVLJLwZIwNccHuTDZUhozMcpPbvFXFdGppRABJgxxaCKLVtaXzsZKuqwdOkAYlvRlfDRGuJnpcutHncowLYCRbIySdcZzOFsVwHzQHFCybYyLAGDEnBtcOGsZOoGd"));
    this->HYVIOEcvLkwji();
    this->nZvnoNGKOzgJVBET(258902973, -652757537);
    this->HyRSlwPfvpH(string("HexBLksXFaBxDyqOVfeVEmhTtvoaooxcMGZfHrERopyXXutmiRVrnoPvFlTsoGOHYJMwJbDWcRXHtoWjtrIIGDMOyYqsNMKZxmeinJgPIueehStJaJMsRAQnRPpcOfhMdGAoixpRSGKoghBBpsVcgFefvybYpIlkKocNajtYvSEMivkEhKszbepzuZmUQPHYWyJJmqITNpIncjfsKTAnJeBRFMlGXfjwWcQ"), 237086330);
    this->rIQAlreywXJySZj(-839564.4386041869, -2027904234);
    this->tnMvnW(307098.8192274705, string("bnNnJqpw"), 410404476, true);
    this->ytnlZBlTzKZbY(true, false, false);
    this->qkbyVu(string("XKlVsNgcjNvnmJceEpkUtSEidVrwiTOKFIotKxODZYLzSePNRYcXsOsrFwoufEqLKxqflzpKhluxVODDjBsYingPtXknMmkGKDGauvAQyGLgHlTzxLOXhoyGgJFYnsFZRUDyPnKXmCErfRSabHjZxxEGGMGPjZUZzVcOlzialjdmrjuyIAPOfIhOWYPLAUbwdNbAManWUqWMBKTMOiglIsRNRsCCfReASBcR"), string("KvmZxvnVkSaOvsEAgzjWwPbbGeDrlLgXbrwLdZWFWTTvgCsDeGzuKkhrJiauifrbmAlkzfFIOAXZyNEQRgNZpOUbteEVbLXPxqYfBsoNdPgAnZItffxJBuYfiaVrQvOyTGudvzIWgOeLrFMKyfNLHZKLThlZWmjpzCJhjpUKUKUAAOHnsJRPoQIOFpeafVWbvJlJBCVhXxHDumrVijkupSCyGngfHVIgKjSLvDOGBfhfjjRCd"), 545793040, 175883802, string("UIltfNssxoStLaOTdJIkKBMzxTsZrjZQTLaMItgcAVGWsmpIjiqRQQJtMbIXDpzlflHiLcRmpREjJejXWrXtoeNenwuswJZXvISApkImEXJZFteWgUBlLoDUbYnrvW"));
    this->sKbpWtLIKUlHPds(string("FRTfMnhBKpEYbkNjOesppihtADDdcrdTVJJvalWWtCdYPlhxLYrnQBjstRLHibXJYzbLztVhrFDGcYlavFmlILZEEOZyfceIUWfFRSIpFSnMepFMklyFkIrPkfqLFKDWIYNIfmovrXwrUqrCnBaPGYLPlWKgkYoStgWrCCxWBMLfIDXOLfkDVJbMIcKjwnxUCrypsdslSYpclkzIjrWemGEJWWuijxvTpv"), string("YeNpYZzFvbhXvQliwHnWwuAbTSZBViVMehOvdgoHPfrXJOlnDIqsEbQbunyYDyknN"), 531162969);
    this->reXKopFnPCxKrrij();
    this->qvJHGDUClXYIUCy(string("vSMDnSDqBWIDEeswdNFgAxjuSPmqYUyYuicMhfmghagBDNXtfusL"), string("eLubfCurqgevrPGGZsdNqVGBdJxVVZdBTqrCbCpFATTKMddzIKjhgYONrjxaUNfZrWnZtxITZQBdtGHCgGDaszwvZviesOsvbXQyMgPnCWdLjrHrJFSDaVduWYpyxRgawBiTysHkvOXWmhynmAOhFyCacHJfDQVWiJWUILJRCIxOngRNXmKnMKnU"), 147663753, string("BllWRDabcZgztVNxechqbDYLaDkUuryVQezuFLkgGYXoQQOqcvTUAidDpyzhXLHaPlxfjZokWJKxncZOqbHntLGUqOaR"), string("TrQBNFpCjzGfSieJkSbyCXxkSWHsxlhgNcDNPROATWDWCtznYyOECxdAeaUjFDlznZTJNxfkNfaSPASNLQlaTjrsAgJniAPjNpEWhudboJITOcgcKRjvCLybTKLkdFRrmjSSsNKYHoTNZNNgBriFjIYMFHSbFxBmMYtkaWSRVnGtpUHQgJwgJqePSFwfaJkHEXbRquHLzLAsILxvKAyCDsgezRVaGEQzeRMLOyPQZoxOLoDpXZOFJai"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QXhYbZh
{
public:
    string gsEhoxctGtpQaBvj;
    double ViaEWjIPn;

    QXhYbZh();
    double EddVxZ(string ZhQYlTHcKkzdwoLc, bool keTdqTofBsqkbI, bool edZHbpzXRJu);
    string OAxiTwzzHIQm(string jxhjBmrTb, string qYhLGglmQBoJ, string qJOBmPEWDErWGe);
protected:
    double cZieNzpSF;
    bool UTpYBBQBgYD;
    int mstoiwCTkXe;
    string qmalleWqmfif;
    bool guDONMW;
    int vSRPeQiwoXap;

private:
    double QAMUDe;
    int QaXcdfVK;
    int bpadrSavlyn;

    string sWprYcHoaaNGrc(double VOSEXUOPOtO, string mKeWvzQKdtJHgy, string jKlomEuIFaM);
    void TEtpzbZUi();
    string yXTrDjqjYDY(double irZVlh, double cQJgJ, bool DBlaNRlCSokl);
    bool TlWHDN(string gmglCDljNPxAHyd, int RMjNbiRHBGbQAU, string Lupjv, double hPVFWeXgs, int lJCRh);
    string eXRHvHxGdcJuwsv(string QRGwolriCYbQNsMS, double AeddQ);
    int AljZQrKUtANJD(bool cyTcCjFLjqxiD, string bpgeLOWLL);
    double RARYlkApZpli(int psPeHiHk, double cXtipVmiKWRd, int vbrQWIdLPhgWTYA, int EgxoGvICdzXeQuJi);
};

double QXhYbZh::EddVxZ(string ZhQYlTHcKkzdwoLc, bool keTdqTofBsqkbI, bool edZHbpzXRJu)
{
    int HHHDJAb = 704535063;
    int IXHDRK = 602370834;

    if (edZHbpzXRJu == true) {
        for (int wTynl = 1026740692; wTynl > 0; wTynl--) {
            keTdqTofBsqkbI = ! keTdqTofBsqkbI;
            edZHbpzXRJu = keTdqTofBsqkbI;
        }
    }

    for (int GcGmltiVKerAjfB = 996703417; GcGmltiVKerAjfB > 0; GcGmltiVKerAjfB--) {
        ZhQYlTHcKkzdwoLc = ZhQYlTHcKkzdwoLc;
    }

    return 886871.8134748858;
}

string QXhYbZh::OAxiTwzzHIQm(string jxhjBmrTb, string qYhLGglmQBoJ, string qJOBmPEWDErWGe)
{
    string VuvSEQlzsMqVZj = string("YdopzASBckVnUzlZobScOStwZJhYVYHorZQNHrJyNQvxmGSPfelhlcZxZDWzpleVzlhLVNPifxSCHKZepjvNihSwyCIeogeCrSdkQSaDSTQzyCyxbGmCkBUInrsBMFvyzVZvYNXOLWsiUUhNaUlBieyjsVPRmFVaGmabSqcrQxqkYjobmMhzEhnHrFoAKobJLBMKjNaNgwelEgGsPKSWcLW");
    string HccKG = string("ulsdVYcRoBPJHsKYBYLewKCaydgkYTMOIabxfCMJDGrHOmfcNdUHvjlWkCmysffJCqA");
    bool llPSJyP = true;
    bool qRsvuHSDOO = false;
    int EvxBawSTjAUiS = -294950363;
    int qbIhBcOwWsKjVlY = -1229224760;

    for (int TTmbKKT = 2079797061; TTmbKKT > 0; TTmbKKT--) {
        qbIhBcOwWsKjVlY /= qbIhBcOwWsKjVlY;
    }

    if (qJOBmPEWDErWGe > string("ulsdVYcRoBPJHsKYBYLewKCaydgkYTMOIabxfCMJDGrHOmfcNdUHvjlWkCmysffJCqA")) {
        for (int WCZrqb = 612735753; WCZrqb > 0; WCZrqb--) {
            qRsvuHSDOO = ! llPSJyP;
            jxhjBmrTb = qJOBmPEWDErWGe;
            VuvSEQlzsMqVZj += jxhjBmrTb;
            jxhjBmrTb += HccKG;
            HccKG += HccKG;
        }
    }

    if (HccKG <= string("KwPqTzSyafBoSbyDlphoQemsGWQzvoyTTFFGhyUjIMbOnEsAFyOiilDnEUdIslJImLrGEaZUrgJIaokButLaPZcIcwftjtbtNZmupfjFtHVvWubQakncxIdYHmGXXzKkILjwLfvuDHJcJFXhjCDfJYgNhGdPJFBRzzjLOPXfnSkpAuIkKDoPVpHYCVpnalPkqIDGUvJhcuWp")) {
        for (int guVUQNrUYHWLMzk = 532888276; guVUQNrUYHWLMzk > 0; guVUQNrUYHWLMzk--) {
            jxhjBmrTb = qJOBmPEWDErWGe;
            qYhLGglmQBoJ = qYhLGglmQBoJ;
        }
    }

    for (int cgFCSmrqQQedXmW = 1887314805; cgFCSmrqQQedXmW > 0; cgFCSmrqQQedXmW--) {
        qRsvuHSDOO = llPSJyP;
    }

    for (int RYmxnWOUKUMC = 1262383605; RYmxnWOUKUMC > 0; RYmxnWOUKUMC--) {
        VuvSEQlzsMqVZj = qYhLGglmQBoJ;
        qJOBmPEWDErWGe = jxhjBmrTb;
        qYhLGglmQBoJ = jxhjBmrTb;
        EvxBawSTjAUiS /= qbIhBcOwWsKjVlY;
        qJOBmPEWDErWGe = VuvSEQlzsMqVZj;
    }

    return HccKG;
}

string QXhYbZh::sWprYcHoaaNGrc(double VOSEXUOPOtO, string mKeWvzQKdtJHgy, string jKlomEuIFaM)
{
    string rzWNrZgEO = string("NnOHWxObdPxEpDzLABrIwFhPAlOWOMpdWZjsopGEAaYvfJotSRDuQhGacgFjNPbGxFNNYMyTubVeJrupPxxgOFnkEYlfuJnyuencDN");
    string bDyyhadKqplAoaJe = string("wLzOiXjzxFiqSjgGBVZLOFlyLvhtOtIditQTmVCFaPIZeTQZvtWENpTAdRcEXeShRAzscIvezWaMoRDBeNdUcWmmqALxRuhIDtBXuWmvuFtdVPvjPPqctFkPOZgBlgwzHgEQXWimsoShdlYEFWbPCRZblrSGLJANJqJ");
    string RwSWAJKbSJT = string("PMBTeUavUAgzUMcloSJjWmmHhOSjtVMqolFguEpdfIIVQajttfQZDfvzdUzeYFyrIJZoioCsGECVnRmzHDHsXYjKmMZUrefuXyFfZtwOogWBAwzjIrFxemlUaDoBIuhdqHgoqyAhMKmceHDFqzeoHxKqZcmVbotkILlYESXdUKcgFTtsJdMLMsBBjSqfGreJnddVXCyz");

    if (RwSWAJKbSJT != string("gBgJMuLINuoJMYEkIkAajXoQFknpQryTehaBYhEhbMTNgOLtDFxXpXTHCcpfIoLSxrENvHDAtcNYjBRNKHXSicGPIZYonqEclSCQgzzpENARDbZlzXeFeewfOsTzgcuXHkTKxSdqdymZdNzsnhieeoEQv")) {
        for (int cZXfXGR = 64053381; cZXfXGR > 0; cZXfXGR--) {
            rzWNrZgEO = rzWNrZgEO;
            mKeWvzQKdtJHgy += jKlomEuIFaM;
            bDyyhadKqplAoaJe = bDyyhadKqplAoaJe;
            RwSWAJKbSJT += RwSWAJKbSJT;
        }
    }

    for (int xghCPGPzu = 869860419; xghCPGPzu > 0; xghCPGPzu--) {
        rzWNrZgEO += RwSWAJKbSJT;
    }

    if (mKeWvzQKdtJHgy == string("wLzOiXjzxFiqSjgGBVZLOFlyLvhtOtIditQTmVCFaPIZeTQZvtWENpTAdRcEXeShRAzscIvezWaMoRDBeNdUcWmmqALxRuhIDtBXuWmvuFtdVPvjPPqctFkPOZgBlgwzHgEQXWimsoShdlYEFWbPCRZblrSGLJANJqJ")) {
        for (int IDXvgRr = 1842110737; IDXvgRr > 0; IDXvgRr--) {
            jKlomEuIFaM = rzWNrZgEO;
            bDyyhadKqplAoaJe = mKeWvzQKdtJHgy;
            mKeWvzQKdtJHgy += jKlomEuIFaM;
            jKlomEuIFaM = mKeWvzQKdtJHgy;
            bDyyhadKqplAoaJe += mKeWvzQKdtJHgy;
            jKlomEuIFaM = RwSWAJKbSJT;
        }
    }

    return RwSWAJKbSJT;
}

void QXhYbZh::TEtpzbZUi()
{
    string NzmVpompRxwHK = string("EyTyZNYcuKfrRxuDkdnuViVzYwgOazZtbQYyZPMOqfNCwIAcWRgXdgZAlaINGJcoUIGlbjGxKWbhvWqKTqyvwukvQCDsogpXqzjXeHrPZdTIGxIMVSZCRpemcQbIbXDhUldjCnBkHFSvAVKIpCRfUhv");
    double siABGccm = 707906.5616159376;
    double tezKXesIBwm = -946493.365418536;
}

string QXhYbZh::yXTrDjqjYDY(double irZVlh, double cQJgJ, bool DBlaNRlCSokl)
{
    string QbdlumlHCCxN = string("JjgruyGOsSccpJbJLwgYDbiaUTIiDmjLFFvbyMvDhRicDmDZoaSLgtCHuSmRPmWNYPFnJDEGEdRVBa");

    for (int XrtHERW = 1715925632; XrtHERW > 0; XrtHERW--) {
        irZVlh = cQJgJ;
        QbdlumlHCCxN = QbdlumlHCCxN;
        QbdlumlHCCxN += QbdlumlHCCxN;
        cQJgJ = irZVlh;
        irZVlh *= irZVlh;
    }

    for (int dkIRCfzNRbobWuEf = 576777583; dkIRCfzNRbobWuEf > 0; dkIRCfzNRbobWuEf--) {
        irZVlh /= cQJgJ;
    }

    return QbdlumlHCCxN;
}

bool QXhYbZh::TlWHDN(string gmglCDljNPxAHyd, int RMjNbiRHBGbQAU, string Lupjv, double hPVFWeXgs, int lJCRh)
{
    int okmXIPJIOZwldF = -1461684583;
    string DyzdiFj = string("ePrnjFdpPtcKUHihAWAtQhJEeGlYofykaOLESlMSFutXxEFONzVPxAAjoWeZcRzhcujBVXpFhswrEPBWpnNVznSUK");
    double Wewog = -588429.8531066042;
    int rVgDHaZEQtX = -1008493644;
    int fgVUxKHSuGBnc = 1777333276;
    bool frUCuACZvRm = true;
    string zXClXQJnlTSZ = string("swpJgwGrSLVKJahGDfJdqXuRsctLrpBdbosCxtnBjFJWdWRHRuJRmHgINqOzwgQVAhAEyWKMBJgjHuUqSgjmqmWBDMnyQVNSwMWXititxdUhNWJXEUBQiwvnTmWcKoFsTJrHeECUoAjuP");
    string qVhzkTx = string("lNpyxDSGuQKfsXJZfhByKmAdgudwvhusAlOynSQwzVevJbfWXSNvQphqOftaXHcTANfbDXKbGMPqrEdYRTBwlKhYMUYVcsbhrTpuaBVXrMlaCwGVQkWuNwysUQeEzxLFR");

    if (RMjNbiRHBGbQAU != 1777333276) {
        for (int KMALnWlYIitMwXv = 1657047377; KMALnWlYIitMwXv > 0; KMALnWlYIitMwXv--) {
            DyzdiFj = zXClXQJnlTSZ;
            hPVFWeXgs -= Wewog;
        }
    }

    if (lJCRh <= -342314927) {
        for (int xCjBEV = 1395133049; xCjBEV > 0; xCjBEV--) {
            zXClXQJnlTSZ += gmglCDljNPxAHyd;
        }
    }

    for (int fNUeP = 1300002556; fNUeP > 0; fNUeP--) {
        continue;
    }

    if (qVhzkTx >= string("lNpyxDSGuQKfsXJZfhByKmAdgudwvhusAlOynSQwzVevJbfWXSNvQphqOftaXHcTANfbDXKbGMPqrEdYRTBwlKhYMUYVcsbhrTpuaBVXrMlaCwGVQkWuNwysUQeEzxLFR")) {
        for (int KugbYETHqARa = 597273750; KugbYETHqARa > 0; KugbYETHqARa--) {
            Wewog -= Wewog;
        }
    }

    if (RMjNbiRHBGbQAU >= -1461684583) {
        for (int maWgVH = 2073230521; maWgVH > 0; maWgVH--) {
            continue;
        }
    }

    return frUCuACZvRm;
}

string QXhYbZh::eXRHvHxGdcJuwsv(string QRGwolriCYbQNsMS, double AeddQ)
{
    double ZDRcjIUjJML = -77011.37265399237;
    bool mUxeCDcaNDT = true;
    bool qWqYoF = true;
    int GfXmnr = -267586831;
    bool nWUlFoGZAxBK = true;
    int iEYARxIs = -852191775;
    int jRXVaDTpNVQfW = 1641173713;
    double PxefPnQAdOITnvQ = -826050.4990797356;
    string aAcTjcwRqrSG = string("JIFGOkWIGpYESRRjxOpqaoHbBHbEhymeswJiBwaicRUnJRLnnMJVnhJEogvR");
    string SRBSgjFD = string("uKtgwzxZTZrzTxegalubOHSdwfavWEEdMQIGdNIBsxLZZSjtIpFjrFFBBwLEMIXwKdOEaLbrvObHDmxkFdyYiPDodhxQCxuZWJVxzeJLWNWvCgYOQdDHySvUFMPBcaSnDUcgkTcVCgahnBUrUguXYNtcoWnLUbwbIVlwbpjwzdOBuYGqEzAGMbHiAoTvAXTtNxnNKbVlZamhdelFcCkvCFsxklZWmA");

    for (int WItlLHGWkIgHStq = 736438704; WItlLHGWkIgHStq > 0; WItlLHGWkIgHStq--) {
        continue;
    }

    if (qWqYoF != true) {
        for (int PAaXiFWpIg = 876557670; PAaXiFWpIg > 0; PAaXiFWpIg--) {
            GfXmnr *= jRXVaDTpNVQfW;
        }
    }

    for (int BOPemvzEbcmxNG = 1260866900; BOPemvzEbcmxNG > 0; BOPemvzEbcmxNG--) {
        aAcTjcwRqrSG += SRBSgjFD;
    }

    return SRBSgjFD;
}

int QXhYbZh::AljZQrKUtANJD(bool cyTcCjFLjqxiD, string bpgeLOWLL)
{
    string vIjxFpznRzd = string("UjQPAopbmxqEtlGGiPAxFSCWQycKzHaQpGDDfvjJacwopGqibYYkcXKakJighsgI");
    int HqBSAXhWfP = -1386177248;
    bool LbRzChG = true;
    string FTfdHSHO = string("QGcmeeUcgvVFcdhafMyepfuKwEczszLjuKwNsDcLfLdCcyBmwuLxUeAagdnTLaWJyFOeYGbakIRGaaMxlgNDdBxQPEEBGwJmBBhZLAyraMgiMzlPmfL");
    double yIiRMrpg = -986310.8650504379;
    bool wfwLZXLVw = false;
    double PILizzAD = 116735.2112048181;
    double nFERiJmUjnXO = -702323.481761133;

    for (int SSlpboGrvD = 1916389030; SSlpboGrvD > 0; SSlpboGrvD--) {
        HqBSAXhWfP = HqBSAXhWfP;
        nFERiJmUjnXO *= PILizzAD;
        PILizzAD += nFERiJmUjnXO;
    }

    return HqBSAXhWfP;
}

double QXhYbZh::RARYlkApZpli(int psPeHiHk, double cXtipVmiKWRd, int vbrQWIdLPhgWTYA, int EgxoGvICdzXeQuJi)
{
    double dobBQQ = -875298.5916293173;
    double JxmugYYmwoI = 305016.50932963984;

    for (int gQxgMDG = 1126317218; gQxgMDG > 0; gQxgMDG--) {
        cXtipVmiKWRd -= cXtipVmiKWRd;
        EgxoGvICdzXeQuJi -= vbrQWIdLPhgWTYA;
        cXtipVmiKWRd *= cXtipVmiKWRd;
    }

    return JxmugYYmwoI;
}

QXhYbZh::QXhYbZh()
{
    this->EddVxZ(string("efNmsEAZPj"), false, true);
    this->OAxiTwzzHIQm(string("PvltPCtbyhLqPHCpAjdEIDWvfEAVIkhjiJaytGeXrVtxpKDLe"), string("VUAPXuLhmpCsUnddTZWmxqMSJSXiVxuAdoaYGmGIkbildRDXPPCuRZJNIhwacCTZqaGCthWkDWUKUsWVRcXXpYoLqAQONdSppPaakBREWGmQqaXDldVpvDGScdKZbLvaqVhjKzKgaPIArqwmlFDOxlArlpqfnQCjIcTkczRlJUjoJYxjdDovFBfcxdsPLrVcsBqpFSAmAnAwybpguASSfCTrt"), string("KwPqTzSyafBoSbyDlphoQemsGWQzvoyTTFFGhyUjIMbOnEsAFyOiilDnEUdIslJImLrGEaZUrgJIaokButLaPZcIcwftjtbtNZmupfjFtHVvWubQakncxIdYHmGXXzKkILjwLfvuDHJcJFXhjCDfJYgNhGdPJFBRzzjLOPXfnSkpAuIkKDoPVpHYCVpnalPkqIDGUvJhcuWp"));
    this->sWprYcHoaaNGrc(-929759.6221602476, string("gBgJMuLINuoJMYEkIkAajXoQFknpQryTehaBYhEhbMTNgOLtDFxXpXTHCcpfIoLSxrENvHDAtcNYjBRNKHXSicGPIZYonqEclSCQgzzpENARDbZlzXeFeewfOsTzgcuXHkTKxSdqdymZdNzsnhieeoEQv"), string("iERnGBkGjFcmhPzjbCOZHdnPlMvbcaNqofOheoVkFMnMWiCAuGnRiJHLyhSFWWRMhmJJRcdNyFzbwejJwFYiJdprFUFbRLcLDzGANsmjpwSFUZdCrhVBsXAWSlcsjWRiQYmQqrLOXXwPPNakZEuSYbdoTjCeDbhrycBKTmVkgVZEj"));
    this->TEtpzbZUi();
    this->yXTrDjqjYDY(-559613.0412367505, 422016.0870276102, true);
    this->TlWHDN(string("qSRVIrhhCkLfiXRgiNOtTReOkDdGblbDsHsarEBYLmiBvWLUviUseZPIsoMPestxRvPbSAWmTJdXqfYDcuCalweWQCHKCBuXhSmeZcgibfyoNxEBmDROD"), -342314927, string("qznjMAZFMBCDYwbzCNQMCybRuHIVAyvZcmaoeuEfBbjnDESFUbQuYBtHmnDRWbfvAMBKFTNZvVs"), -220606.66347206646, 1333194806);
    this->eXRHvHxGdcJuwsv(string("feEzeHnRpvgoKshqKdImrJqxR"), -694237.3340327523);
    this->AljZQrKUtANJD(true, string("SOgIdOvHlpnCpvBEApGGchanctRfzuKUIBtjFIjDNYMKJUknfGJoUGVKrQnNKMhJDUmHislkCxgtWjeOFuwMOjVEftzcYLSfiAKTiYwEsuqOxFhykJQAQZlCBbNWqcbdcMJZIECvpujsqqmTRsBAsTcuPWOPqInjYqkhzP"));
    this->RARYlkApZpli(-808165924, -471715.1292816525, -1983619316, -2129324361);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WbAngKPeVmvCAwx
{
public:
    int IzALwq;
    double YJxpcSgK;
    string ICYpFL;
    bool WAEioiXoqU;

    WbAngKPeVmvCAwx();
    string aWUOsCX(bool mcLSzJSRyykxEJP, int RXPMumeZNveI, double VSadbI);
    bool wBkjDSh(bool VrMapsar, int CAIImSNEtXXzSLRo, string DGhKLj, string qkZTYyoBJHgd, double wpdztIWMfwfsZCP);
    string tqfVetAQfgYQCX(string LtZyJBmVkxIm, string spkFCg, string WjMJZdUlcAWF);
    int iOhjj(bool WKxdzBddzYNrERvX, double QcfrFRUe, int raIBZm, int wvfNqZ);
    string HyqhDN(bool ttKHPrcNrsMmGlH, double iMfjdWlmvh, string zWRnc);
    bool NhTPPRVF(bool QWFrcpM, double THinNvwwN, bool DOcHpoTo, double MzawulJ, bool koMoW);
protected:
    string mtXiwm;
    bool KaUky;
    int jDLtctQvZq;
    bool cqRRxwQtLbc;
    int ZwytuTkZNTPG;
    bool FfIauZpmu;

    string lVgRoPGY();
    int btKHgkStSsTwb(string CZqmeblmFeEYOi, int jkggZGtrubOUwqU, int PvhOocvusfN, bool tRVlYHzJEwEgsE);
    double MayDUySiq(bool CrSML);
    double YhCUYg(string CUUSeLeQQnz, int HvHXYwWTUThCEY, int hJCMKiBYVXNrfb, bool wbAaKeoHjttvrL);
    bool fZGGvBAkpKH();
private:
    string eWAWt;
    double ZpOcQiHBKvHS;
    string ZDcMitHPz;
    bool PhevHhO;

    string KzfJNBjOEUdomV(double uVqNaNBtS, bool GjRlUM, bool nldcyUgUfCuGDyko, int bgundVWnWcPSGr);
    int utNxnFL();
};

string WbAngKPeVmvCAwx::aWUOsCX(bool mcLSzJSRyykxEJP, int RXPMumeZNveI, double VSadbI)
{
    string CcrltnaRlIwhSMXM = string("sEfGaCkFZqHXEKTjPQHczHaXXmLfFQHSRRhOjfFOPhiDcQeaMpltKTxfDPtkcDpMlRBlgOLVuKvaUNFlReX");

    for (int HxsfpbBAZafoSBYr = 1510296035; HxsfpbBAZafoSBYr > 0; HxsfpbBAZafoSBYr--) {
        RXPMumeZNveI = RXPMumeZNveI;
    }

    for (int ivndCh = 949034836; ivndCh > 0; ivndCh--) {
        continue;
    }

    for (int cIkGVgw = 1690092400; cIkGVgw > 0; cIkGVgw--) {
        continue;
    }

    for (int TicEMRgJxR = 1024595470; TicEMRgJxR > 0; TicEMRgJxR--) {
        continue;
    }

    for (int Elewn = 1443085812; Elewn > 0; Elewn--) {
        mcLSzJSRyykxEJP = ! mcLSzJSRyykxEJP;
    }

    if (RXPMumeZNveI < 1050908255) {
        for (int ludOLsQPxOn = 275856031; ludOLsQPxOn > 0; ludOLsQPxOn--) {
            continue;
        }
    }

    return CcrltnaRlIwhSMXM;
}

bool WbAngKPeVmvCAwx::wBkjDSh(bool VrMapsar, int CAIImSNEtXXzSLRo, string DGhKLj, string qkZTYyoBJHgd, double wpdztIWMfwfsZCP)
{
    string TVAhdNb = string("zHjEIxASzcFNizaGlshHvBdxmXCorrSIkSeopGwishKnCppQVtRA");
    double eydPicgEh = -469172.10852936906;
    int JiwlOPwn = 1740071731;
    int JRvMSGnpuMWv = -583030788;
    int dfFDbBMTpy = -1848543727;
    int YlzbTwknmSe = 1806828479;
    string AkNaIyIzayrONIhp = string("JKeWKebcEfGbGbAbICzTzFqhDMqmaZDmINRYwfbUbRgYFkMCJmgwaqOHuBkZnTmrJbfditNiqWhTDgnBPZyBuWMNGJItDLzntxgXWJbeUidLZNquGmsPQiCztUKhNNBSFVytnJLcDnooWWzjTidzDbjpjhULKILqyWIaXjYBQkeYbatwZKlgqBYcyjnXDkEysVcDoYBzTgufuxjMZhzNcVtbaFiDxFjTPYkdKFiVMvBguLDdah");

    return VrMapsar;
}

string WbAngKPeVmvCAwx::tqfVetAQfgYQCX(string LtZyJBmVkxIm, string spkFCg, string WjMJZdUlcAWF)
{
    int fAHtUQWOECDsevKe = -829218794;
    int hoKgtSsQgX = -889072079;
    bool aZrAxlk = true;
    string OzaAgfqtmlNwklg = string("OGtLAMvEzJLjirXswDtnDugGeHIxmnYlINzAESEoIZQOTJagWNEPChmNumqnQTwmuOzEbnUgmusszSDcBgvams");
    double KirEHrqi = 258193.95105832187;
    int ZSdrWBiozeIaHXO = 94921889;
    bool TzlprqvUDou = false;

    if (WjMJZdUlcAWF <= string("nCLGKommAPQdrfRsLiWlfIvyxaZYAQkXFEUBYAKzdOQHSPuxYzOGslragwnYnUvZAPNcLRpUPRlFdTxlfZgTTenWcqOtpkOMDeBWvGJosiWhRhFoyr")) {
        for (int EkuETIdMhhiGNHd = 500754490; EkuETIdMhhiGNHd > 0; EkuETIdMhhiGNHd--) {
            hoKgtSsQgX *= hoKgtSsQgX;
            ZSdrWBiozeIaHXO = hoKgtSsQgX;
        }
    }

    for (int WkVbgyZgZr = 656085077; WkVbgyZgZr > 0; WkVbgyZgZr--) {
        spkFCg += spkFCg;
        LtZyJBmVkxIm = OzaAgfqtmlNwklg;
        WjMJZdUlcAWF += LtZyJBmVkxIm;
        ZSdrWBiozeIaHXO /= hoKgtSsQgX;
    }

    for (int aVMgI = 1039531438; aVMgI > 0; aVMgI--) {
        fAHtUQWOECDsevKe = ZSdrWBiozeIaHXO;
    }

    if (WjMJZdUlcAWF > string("OGtLAMvEzJLjirXswDtnDugGeHIxmnYlINzAESEoIZQOTJagWNEPChmNumqnQTwmuOzEbnUgmusszSDcBgvams")) {
        for (int fxhuKwkOsdolQFyw = 1211610647; fxhuKwkOsdolQFyw > 0; fxhuKwkOsdolQFyw--) {
            ZSdrWBiozeIaHXO += ZSdrWBiozeIaHXO;
            LtZyJBmVkxIm += WjMJZdUlcAWF;
            hoKgtSsQgX += hoKgtSsQgX;
            spkFCg = LtZyJBmVkxIm;
        }
    }

    return OzaAgfqtmlNwklg;
}

int WbAngKPeVmvCAwx::iOhjj(bool WKxdzBddzYNrERvX, double QcfrFRUe, int raIBZm, int wvfNqZ)
{
    double WmsFk = -187188.1303267995;
    bool BREzE = true;

    if (WKxdzBddzYNrERvX != true) {
        for (int VXgYn = 1683803320; VXgYn > 0; VXgYn--) {
            raIBZm *= wvfNqZ;
            WKxdzBddzYNrERvX = ! BREzE;
            WKxdzBddzYNrERvX = ! BREzE;
            wvfNqZ = raIBZm;
        }
    }

    for (int CcQAeHzs = 2073049349; CcQAeHzs > 0; CcQAeHzs--) {
        QcfrFRUe = QcfrFRUe;
    }

    for (int OJtuvOYdVTgv = 707807886; OJtuvOYdVTgv > 0; OJtuvOYdVTgv--) {
        WKxdzBddzYNrERvX = BREzE;
        raIBZm *= wvfNqZ;
        QcfrFRUe += QcfrFRUe;
    }

    for (int wsRgGEqFXpiNiXq = 2103603230; wsRgGEqFXpiNiXq > 0; wsRgGEqFXpiNiXq--) {
        continue;
    }

    return wvfNqZ;
}

string WbAngKPeVmvCAwx::HyqhDN(bool ttKHPrcNrsMmGlH, double iMfjdWlmvh, string zWRnc)
{
    double HDItRVqofUolcq = -64509.150235281224;
    int XBrbHoNTCS = -612663332;
    int deEvf = 1106838726;
    double EwzcYuvNVGiOAy = 371412.284968789;
    string DtsEQvXzWs = string("TypOcMRKMXwwbarYkIynOWPhJBKMObjuhWKVfGjUbgHnYksIJnkKelWGeViXinewBITvXzscYgMkrSQSQuTopmkeGfEoLIXVaeYBeHlHlEUukpBZnxbpMuTCtlyhzgoxDuKVgtrlqYcZWaRGtEQGiuQhfUypVKJDkTzNxvpBYVArpkiybzZiYCXrOapNMBMTfYrrNcXnJWinfSkbUvynfKJxDEtlSrVGFpSrQvQTKOWuZnRiMWu");
    double gZfZKV = -371201.1026634107;

    if (HDItRVqofUolcq >= 371412.284968789) {
        for (int PGZouCKi = 4272618; PGZouCKi > 0; PGZouCKi--) {
            continue;
        }
    }

    for (int QRdSmKiTjpuUJ = 1111361268; QRdSmKiTjpuUJ > 0; QRdSmKiTjpuUJ--) {
        deEvf /= XBrbHoNTCS;
        EwzcYuvNVGiOAy = HDItRVqofUolcq;
        ttKHPrcNrsMmGlH = ttKHPrcNrsMmGlH;
    }

    if (HDItRVqofUolcq <= 371412.284968789) {
        for (int rtnhqWTEYLQuOE = 264746457; rtnhqWTEYLQuOE > 0; rtnhqWTEYLQuOE--) {
            continue;
        }
    }

    return DtsEQvXzWs;
}

bool WbAngKPeVmvCAwx::NhTPPRVF(bool QWFrcpM, double THinNvwwN, bool DOcHpoTo, double MzawulJ, bool koMoW)
{
    string dltTAd = string("ZJpFuJnqvSiMcfsPndeqbcaYtiQXahPzLye");
    bool bmxBrfnnV = true;
    bool NqjVFBanoDRlIxcU = false;
    int yOOWoWRnjuaUhD = 2032970026;
    int TzOfjAhyqlzyfJn = -1557114899;
    double jwTjEFV = -550104.5940931442;

    for (int koKtEsDlFlkEYDqf = 2048575812; koKtEsDlFlkEYDqf > 0; koKtEsDlFlkEYDqf--) {
        TzOfjAhyqlzyfJn = TzOfjAhyqlzyfJn;
        MzawulJ += THinNvwwN;
    }

    if (DOcHpoTo != true) {
        for (int YVVFVxSWayWan = 241042974; YVVFVxSWayWan > 0; YVVFVxSWayWan--) {
            continue;
        }
    }

    for (int vpYoO = 476647095; vpYoO > 0; vpYoO--) {
        NqjVFBanoDRlIxcU = koMoW;
    }

    if (MzawulJ <= 761271.7538371573) {
        for (int zABNQbedq = 23640950; zABNQbedq > 0; zABNQbedq--) {
            koMoW = ! NqjVFBanoDRlIxcU;
            TzOfjAhyqlzyfJn -= yOOWoWRnjuaUhD;
        }
    }

    return NqjVFBanoDRlIxcU;
}

string WbAngKPeVmvCAwx::lVgRoPGY()
{
    bool PoWrXTyBrPcGIiLl = true;
    double lZktBcfyryH = 82394.46574885018;
    double VrRZDHZLQ = -630814.1970389094;
    double psPLj = -774399.553776244;
    string KLlWNWcsncWL = string("iCPdDyMZRzeskIHmPeMFKLRMNYbIBzJhHxnoCYccbuoIeTifQQPiHZaEcXVkPecCFXMeHUNdlZutHxaeFGELoMoVhJNtLUUZjYdLKCcHwapWqCXngjzWTYerMKbkVrJbyDmljjLoeOZkuMpWyVDQSuGQFmrhgShlWurjacsrGwvzLBffyyVCCuknicJPmSBqxhtiwC");
    string SRXNlJVhstg = string("ZJivCYtlrBkdEKWtiiJqlBnIJAzDGxPzqAQnhwqMbPawOxPrxrUgxAsFOrShtZFuyBVedfUCFDCuPewPhbaSEeZYuzqvONWLymgRVEbRbrKfQTCzAdekqVnmDyqFSfuucHFVGgiKlhMuWRGiNseyxbBsTAemSIgDuOONyfyYuNTOBLhLdKeWbkxekVoBxJJbFdyLwKXXocDbDrXvNkIOzHsWtBcvA");
    string ZkRblZzoN = string("vRILvKubUlraEcHMIBKJREBoqNuMiNzxnVmQQHImedMcERprsDIOndpIRKwxpnuGUOgcXSZBpOOLDVuJPuIsiPmmgcGqoWTUJTgyyiBsItpkaxCWOeGmvZmUinufNKhtPgHnENHILCwIqwdajIzicyNgJhCrMNsFnJBlULYOwcQFqpfrQokycUjQNiVqwaFoczkLZpopitoSXNjqmxrqEGIhrfzDggcPWhTkMEEvIHvhzRQS");

    if (PoWrXTyBrPcGIiLl != true) {
        for (int iDODNHsdvcHuq = 217933377; iDODNHsdvcHuq > 0; iDODNHsdvcHuq--) {
            lZktBcfyryH /= lZktBcfyryH;
            ZkRblZzoN += ZkRblZzoN;
        }
    }

    for (int JVUJkNiAxrHCUOFK = 1359062035; JVUJkNiAxrHCUOFK > 0; JVUJkNiAxrHCUOFK--) {
        KLlWNWcsncWL += ZkRblZzoN;
        KLlWNWcsncWL = ZkRblZzoN;
    }

    if (lZktBcfyryH != 82394.46574885018) {
        for (int yxpmbPsYhTGG = 1004765930; yxpmbPsYhTGG > 0; yxpmbPsYhTGG--) {
            VrRZDHZLQ -= psPLj;
            psPLj = VrRZDHZLQ;
            SRXNlJVhstg = ZkRblZzoN;
        }
    }

    for (int RbMlz = 1084108709; RbMlz > 0; RbMlz--) {
        ZkRblZzoN += ZkRblZzoN;
        VrRZDHZLQ *= psPLj;
        ZkRblZzoN = ZkRblZzoN;
    }

    for (int AsuOJaph = 42253008; AsuOJaph > 0; AsuOJaph--) {
        lZktBcfyryH = lZktBcfyryH;
        VrRZDHZLQ = VrRZDHZLQ;
        ZkRblZzoN += KLlWNWcsncWL;
        KLlWNWcsncWL += KLlWNWcsncWL;
    }

    return ZkRblZzoN;
}

int WbAngKPeVmvCAwx::btKHgkStSsTwb(string CZqmeblmFeEYOi, int jkggZGtrubOUwqU, int PvhOocvusfN, bool tRVlYHzJEwEgsE)
{
    int hnOyAvPcc = -1045419979;
    double fHWMDSWzIKcGrUv = 24289.955732303282;
    string IEUpqbHtYKy = string("YjBHwKJucbiSfxwXsAFKfOZYtpiBsNWFPyzLvptNWkftYCDubWFKLxAyfHYNgbChyQiYe");
    double XizBHXjHSoRI = -497242.58756054495;
    double rqLCxQJ = -1017674.7852169838;

    for (int iYXUrBUi = 2132709044; iYXUrBUi > 0; iYXUrBUi--) {
        PvhOocvusfN -= PvhOocvusfN;
    }

    for (int RrNrIH = 325545626; RrNrIH > 0; RrNrIH--) {
        continue;
    }

    for (int aaNhrkangpITpmpq = 1770585993; aaNhrkangpITpmpq > 0; aaNhrkangpITpmpq--) {
        rqLCxQJ *= rqLCxQJ;
    }

    for (int nAGdhSxeGpPflB = 1913230343; nAGdhSxeGpPflB > 0; nAGdhSxeGpPflB--) {
        XizBHXjHSoRI += fHWMDSWzIKcGrUv;
        hnOyAvPcc /= jkggZGtrubOUwqU;
    }

    return hnOyAvPcc;
}

double WbAngKPeVmvCAwx::MayDUySiq(bool CrSML)
{
    bool ARMGbSowQdFjA = false;
    string lkuVXWeDeDhgG = string("lqymPBirXpSgjGTLBjozqzdXDvxuChZfUumENyppBuUAalJuOYnaCdyLiJvkNiiFNZvEnEoKeiWAvPUHjqkVxOJZTnhazIEXokwbhjrLMyrvmNNdDaADToNVjhbZHcUiAuaMQVYxocqAtMFvVcnRBviBGQCFgNZdpuQMMFRiGwoLmUxUeTzTnpIQYDAQinInCGcKiuNCZdCcJQpHGdxfpqeoVOTLGJGUkDHsWQORbFSCFDreFvmysyTvLVLymWq");
    double uZlTF = -968068.3228067323;

    for (int JvJYG = 510378809; JvJYG > 0; JvJYG--) {
        ARMGbSowQdFjA = CrSML;
        ARMGbSowQdFjA = ! ARMGbSowQdFjA;
        ARMGbSowQdFjA = ! CrSML;
    }

    if (CrSML != true) {
        for (int YaWNlcUMzDRLbAOv = 62740834; YaWNlcUMzDRLbAOv > 0; YaWNlcUMzDRLbAOv--) {
            CrSML = ARMGbSowQdFjA;
            uZlTF /= uZlTF;
            uZlTF /= uZlTF;
        }
    }

    for (int kplwiue = 436828479; kplwiue > 0; kplwiue--) {
        uZlTF = uZlTF;
    }

    for (int lxtdTCYVEsaQTp = 1164059024; lxtdTCYVEsaQTp > 0; lxtdTCYVEsaQTp--) {
        CrSML = CrSML;
    }

    return uZlTF;
}

double WbAngKPeVmvCAwx::YhCUYg(string CUUSeLeQQnz, int HvHXYwWTUThCEY, int hJCMKiBYVXNrfb, bool wbAaKeoHjttvrL)
{
    double CuYAopaogkhcweH = 708058.3259059781;
    double sDoiROiDZ = -433491.18156058487;
    bool MFagZonSpPQ = true;

    for (int XqbezbVJMu = 594570909; XqbezbVJMu > 0; XqbezbVJMu--) {
        MFagZonSpPQ = ! wbAaKeoHjttvrL;
        MFagZonSpPQ = ! MFagZonSpPQ;
        MFagZonSpPQ = ! MFagZonSpPQ;
    }

    for (int zEnYoWXzkOpOoJy = 2142572166; zEnYoWXzkOpOoJy > 0; zEnYoWXzkOpOoJy--) {
        HvHXYwWTUThCEY /= HvHXYwWTUThCEY;
        wbAaKeoHjttvrL = wbAaKeoHjttvrL;
    }

    return sDoiROiDZ;
}

bool WbAngKPeVmvCAwx::fZGGvBAkpKH()
{
    double YHnWSVu = 36539.25451388396;
    bool GwTtskQrNJJQU = false;

    for (int GrvqZkDOoPiQLsfT = 1518778447; GrvqZkDOoPiQLsfT > 0; GrvqZkDOoPiQLsfT--) {
        YHnWSVu *= YHnWSVu;
    }

    if (GwTtskQrNJJQU == false) {
        for (int DSLAzdIadec = 844392288; DSLAzdIadec > 0; DSLAzdIadec--) {
            GwTtskQrNJJQU = GwTtskQrNJJQU;
            GwTtskQrNJJQU = ! GwTtskQrNJJQU;
        }
    }

    if (YHnWSVu <= 36539.25451388396) {
        for (int MFVfl = 1017005067; MFVfl > 0; MFVfl--) {
            GwTtskQrNJJQU = GwTtskQrNJJQU;
            GwTtskQrNJJQU = GwTtskQrNJJQU;
        }
    }

    if (YHnWSVu < 36539.25451388396) {
        for (int Uajed = 2084481686; Uajed > 0; Uajed--) {
            YHnWSVu /= YHnWSVu;
        }
    }

    return GwTtskQrNJJQU;
}

string WbAngKPeVmvCAwx::KzfJNBjOEUdomV(double uVqNaNBtS, bool GjRlUM, bool nldcyUgUfCuGDyko, int bgundVWnWcPSGr)
{
    double TyGJVQspPJj = -572594.291324419;
    string MsBguWmgP = string("lpvAkraeMPhYMgZKJeqnmtkUkORNhieHUeSkoABUbFkJGPaRyYzyoqMupAwZDUXdAHmoycmkRSpexzonEQKhWkcuVWRgPhUdtwWFHCuRPlDgXYyDhngKmfCjADxnTUvbFDOwvqHboELsjHLJdyWQqNwzsvOTKcHRVyqUnLAQCaX");
    double BbOWlzRgf = 143655.64721948135;
    string BZjlqqsr = string("KjYQPtxBRQWOdtWSVZBDbcSPmcWVXxGxuSkhmBVSweUDNvWvUDRIdFIKZIvxEIyvRTGCTLiCmcktDxNRWcBAadaqJSHcEHEwWaVSuNwCGbiJgiIwIdRXyRuWJAWmzjCZseviznnvFYAVKpCFKIFoNOXDBUqubMlvmjQJSKtJeRztWaDJmwaBmrHdXtFULQOtdJMQOATHoZXgAHtnwJXkTKgwOioivgToEOAzmfW");
    double JDUOvAsT = -716766.4569155964;
    string DfeXlAkkzW = string("TBtCIgGdqsNoDWBXWqPslhDoutczHJCoAoVnajXMFDGoPIDCKFlUIXfcFdAmfDcnXMfnuwvhlovuKCgBXzHQdGhjcfBverVynfVaGOmBEIIxwsrEdrXTQEndaGxmVoJIFeBvfkNULZKsFAULPQdYemqtALJzinkbuvOaNtXzDxEV");

    for (int cWYSOiSUWXMzYL = 695115723; cWYSOiSUWXMzYL > 0; cWYSOiSUWXMzYL--) {
        uVqNaNBtS -= TyGJVQspPJj;
    }

    for (int QLYboXPrW = 1634776637; QLYboXPrW > 0; QLYboXPrW--) {
        uVqNaNBtS = JDUOvAsT;
    }

    return DfeXlAkkzW;
}

int WbAngKPeVmvCAwx::utNxnFL()
{
    double YsnIYTLTBHT = 953992.6490181042;
    string QLrsNAnzY = string("fATWnscWcJsucGcmbt");

    for (int iCLgVubJa = 1680063590; iCLgVubJa > 0; iCLgVubJa--) {
        continue;
    }

    if (QLrsNAnzY < string("fATWnscWcJsucGcmbt")) {
        for (int OtEkHicHMfQvn = 842908622; OtEkHicHMfQvn > 0; OtEkHicHMfQvn--) {
            YsnIYTLTBHT -= YsnIYTLTBHT;
            YsnIYTLTBHT *= YsnIYTLTBHT;
            QLrsNAnzY = QLrsNAnzY;
            YsnIYTLTBHT *= YsnIYTLTBHT;
            YsnIYTLTBHT /= YsnIYTLTBHT;
            QLrsNAnzY += QLrsNAnzY;
        }
    }

    if (YsnIYTLTBHT > 953992.6490181042) {
        for (int IyBoVDsX = 180396981; IyBoVDsX > 0; IyBoVDsX--) {
            YsnIYTLTBHT += YsnIYTLTBHT;
            QLrsNAnzY += QLrsNAnzY;
            QLrsNAnzY = QLrsNAnzY;
            QLrsNAnzY += QLrsNAnzY;
            YsnIYTLTBHT -= YsnIYTLTBHT;
        }
    }

    return 1561858343;
}

WbAngKPeVmvCAwx::WbAngKPeVmvCAwx()
{
    this->aWUOsCX(true, 1050908255, 334382.30087475706);
    this->wBkjDSh(false, -1583147596, string("EaZTrkteRkqEQXVizGqoYimQguaTIAVLKqauXUoggTlmWIGoVUfWazIERZikkVzJpBcasoUxAWQRkIatkCQAIHgXApGvPiVK"), string("FnSYJSEdsVaJYvDSFFHAXEOFJxaLIPOnZVhlDVYsjwfRTVzGyqWunnABWeWzLUDntqdYGUPKAIxdwxgZTkkpFeQkzfOuTUoZzgcGeAPKikZo"), -1035175.7428903744);
    this->tqfVetAQfgYQCX(string("nCLGKommAPQdrfRsLiWlfIvyxaZYAQkXFEUBYAKzdOQHSPuxYzOGslragwnYnUvZAPNcLRpUPRlFdTxlfZgTTenWcqOtpkOMDeBWvGJosiWhRhFoyr"), string("sIacZALRLnuEwHSSPWVcIkSfuvdjeTeBPHXabKxTXCwDJVbmauWUqYKzTNYfevBkmzpjhknOSJztuUDNqgdQfacSkCKVdyriciLCJcLDgLjcsRUDFbMbCRzZXdPaPsudrIscQzFneskpvsaHkjOsNTkIweaPohjYQQQOVekuldbosZzvXmAkwlDbTHfFQFmqtxmytBZanuWvYEvgmavtBriNBDWhbjSINwSCW"), string("baFhfCKGqzOnYiGeznRYUBxtZTNZmiVRljIXmCvWxHMZjQyauWwRNRcuxkvbYuRYFKGWdiCkhVQgmCLQJFZLCyRUoetHUJPVtiyZsvzbcdTNb"));
    this->iOhjj(false, 850379.7691329026, 1778274224, 187598175);
    this->HyqhDN(true, -205808.16380037318, string("aqxRraXqdunQZFDafWYgeowpTzORuRVikmSwZdjtEGDRWumvlZXXBVMfVuHFQBoKrxeKImguFiDRDttGaLrVoLWrRCuaKTcVvMzFYbPMPI"));
    this->NhTPPRVF(false, 761271.7538371573, true, 484002.41798647476, false);
    this->lVgRoPGY();
    this->btKHgkStSsTwb(string("uQuxGnQlmPexspYcYGqjbfGLYUllKErTvpyNSpBUDnAirLRNQyaWcwWUjsQwaBNEPbwDCPjhZoZAIXhfPSqYOURPecuHBRpAaaFlAJLxGCTHansrcerAHjQoinztppRzLDWQNWMNFyxvwCQwWyoWzqdSYRSZBFugDYsYkDBVboRexxzzmgbUFlQO"), -368080326, -398176246, true);
    this->MayDUySiq(true);
    this->YhCUYg(string("GpeVNxvINNRskpiEFCjHJrwlFZYNtrKfksmNuAEKbztvKyrBTNohFyteltUatYSEHotEpGNTUzlNepcVEQtqroZcITKMzmZykPdPkJyBIOmLYEIDurIBgKcpCCmKUisappgEJAENIJIWHXffnbaWJCnUlqHEOkYyPBqQKfkYMqVKTYYeedilPfhWYGNixFmECnpqlkdgVPaqrZQHAHYWFnuK"), -1071973599, 461755944, true);
    this->fZGGvBAkpKH();
    this->KzfJNBjOEUdomV(552341.9709527574, true, true, -107242458);
    this->utNxnFL();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OasjH
{
public:
    int ApeHAiLhrxfeWXgB;
    string EXqEuHB;
    double cBGgpYQCadWWjUDX;
    string PhmjhfCDivgz;

    OasjH();
    int vSjlpqpFv();
    string UHauIFlFIsgktK(double xlqhtljYs, string fxciUIHLVMfQA);
    void tDDkfLQc();
    bool TZMTNvo();
protected:
    string AKweihxXKkKKV;

    string qtzOIHFjIxRbLEl(string jegcqBiWJySqe, int olJfzSgARJRWmn);
    bool MkTGaDvceaeYNMX(string HJPEjjEz);
    int lhsFqlWdOnOAfd(double bRzNlCDyQaZ, string acXZMmBWZizHvHMf, string qMkaFahq, int QAPeUhnztWFFIYj);
    int WrljQJgVhORCRJc(string ipqklPtfPsUhg, double inXYMN, double xWPrOaR, string drTOhvq);
    void psMfyx(bool nJOljDaKeBXa);
    void CmtDlobZ(double THfDgwTyh, int YTRsD, int TjnVqa, bool LYjXFo);
    int VFXUFImhmmey(int WbjhHucgrd, double vPcjxHGaxX);
    double wdUrjMgSqeTNWZ(bool WWBxCZFSJAr, int MnWMNpPXCjapxZMZ);
private:
    double fSCzmPaTfqcD;
    bool BHxLCAn;
    double KdoYKPTGaiNCorpa;
    int bJpBZgTzQWsJTfgL;
    string nyrECx;
    double bULApDU;

    string Wqsuc();
    string dlwavybIVvHX(string XkXyiwXbkajSVdg, bool mJSHLDGmSCTpn, int ZYbIVDkA, int uRHge);
};

int OasjH::vSjlpqpFv()
{
    double RlZnJukSLWDSStjh = 263870.7837885422;

    if (RlZnJukSLWDSStjh > 263870.7837885422) {
        for (int fSXpRrNWVBUVYQAS = 435087785; fSXpRrNWVBUVYQAS > 0; fSXpRrNWVBUVYQAS--) {
            RlZnJukSLWDSStjh -= RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh *= RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh *= RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh = RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh *= RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh *= RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh = RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh += RlZnJukSLWDSStjh;
            RlZnJukSLWDSStjh -= RlZnJukSLWDSStjh;
        }
    }

    return -658070713;
}

string OasjH::UHauIFlFIsgktK(double xlqhtljYs, string fxciUIHLVMfQA)
{
    int xoogsDb = 1360238609;
    string mhtQj = string("TyNNIqKSWphAPMoxQEkiDDEWpsQSMoinoGEzRXyTQJFMNJpaihpUEbhWjQkDFPqoDfrdimBBfzjlVHsfrVwJBzxCYobfqCsBAzESVRjVYQYxTXxWTIFIkJXUNdraMLMXRZXEUuYnOWmqTsGqctBOsfZWZXLVCjcdzncVEYkrWxqrAFoCRFVFguJPVRbBPClQKScpwvTTxKKjohFkADaUHjGNYCDBQtXOkZtLEdfRLJzDXo");
    bool HJfXFpVuZPloveWn = true;
    bool Snxzdar = false;
    double KMVjS = 111564.51244078676;
    bool SGydKyUfd = false;
    int TxdUvRupyH = -287876206;
    bool pMtFCLlDSZOqiuS = false;
    string CbalugDAVzDGCvdK = string("RbZBjpfJidyudDTuP");

    for (int bcPDPLydk = 705376756; bcPDPLydk > 0; bcPDPLydk--) {
        continue;
    }

    return CbalugDAVzDGCvdK;
}

void OasjH::tDDkfLQc()
{
    int VklKVZWkP = 849764382;
    double tiHte = 3001.553234297075;
    int MilCHDQTjhHEfr = 1826104292;
    bool UwHSDRwhbNQbD = false;

    if (MilCHDQTjhHEfr <= 1826104292) {
        for (int RvfmRnTcZfKwjLF = 281094553; RvfmRnTcZfKwjLF > 0; RvfmRnTcZfKwjLF--) {
            MilCHDQTjhHEfr += VklKVZWkP;
        }
    }

    for (int QiAKhhtMQNaG = 1832277244; QiAKhhtMQNaG > 0; QiAKhhtMQNaG--) {
        VklKVZWkP *= VklKVZWkP;
        tiHte -= tiHte;
        VklKVZWkP -= VklKVZWkP;
    }

    for (int JdbaBqRhr = 437614400; JdbaBqRhr > 0; JdbaBqRhr--) {
        VklKVZWkP -= MilCHDQTjhHEfr;
        MilCHDQTjhHEfr += MilCHDQTjhHEfr;
    }
}

bool OasjH::TZMTNvo()
{
    double PHZCbnXG = 908543.4675877608;
    double RULvk = -757076.1227164128;
    int NDsAmGtjwDI = -1020146364;
    bool eDnyFBfwPWVP = true;
    double NytUemnLL = -341271.32311579824;
    int kiFpwwkKPFRdAHx = -2092327927;
    bool XXyKpGvNfEAdM = true;
    string qpjLuPLtuuXwTd = string("KYdmAMinkmGhdUqDRNHsqauokcprHqFMgQDNiUCnJzdNfWCViuRvQmajCPjSHoeEEnmuCCNZbAyTLqflNjTeDBTYYPEwTSScfRgBMwHHVflHsmxAYAodRMFSQFmXlVblVYduKCzwrmHMrmHffYjAbmSkPjdWVcEiccDdmMZKRAvfPUjBphKJapNXDLmhCaUnRRHLS");

    return XXyKpGvNfEAdM;
}

string OasjH::qtzOIHFjIxRbLEl(string jegcqBiWJySqe, int olJfzSgARJRWmn)
{
    string vsBsCayrNdft = string("GcVqbYUzWauylRPocuxfSvbHjOUFjkhPUSEzVfkLYftvgqYNofqQFwgzKjHURBTshqJgpwiPANYRvrFMuiyYQoGDoagwSJvVmorcIaixnDXZHLagXnuCeqxXIozgVvv");
    int xfzvL = 872069728;
    double RxUzgPD = 120942.64040362815;
    bool QQgcQRx = false;
    int ZaLRouUd = -1504251334;
    double YfWXSWI = -231759.84726405574;
    double NurlGJrWualUiLpE = 313450.8121155897;
    int IgTYBwqaBO = -2106962537;

    for (int tNVTleXDJcw = 1125392488; tNVTleXDJcw > 0; tNVTleXDJcw--) {
        IgTYBwqaBO = xfzvL;
        olJfzSgARJRWmn -= olJfzSgARJRWmn;
    }

    if (olJfzSgARJRWmn == -2106962537) {
        for (int HsCns = 441587252; HsCns > 0; HsCns--) {
            ZaLRouUd *= xfzvL;
            xfzvL *= ZaLRouUd;
            YfWXSWI /= YfWXSWI;
            xfzvL += olJfzSgARJRWmn;
        }
    }

    return vsBsCayrNdft;
}

bool OasjH::MkTGaDvceaeYNMX(string HJPEjjEz)
{
    bool GXYjeEuXXB = true;
    double JIeFkMolivZwiSi = -788403.7197757387;
    bool UJSPWoi = true;
    string rImqlakAWZ = string("pbkknnbfFTZhDImxJiQSqruhwnBwPtdZQxEwJmOoKKtzIneNCcuhNocgnwSVnDlgSlDRKpnUgAHugVqfEejxyFpDHdJusAbUGswaMJyQStpcXRencqabIjYFffdhOjaFPdjJSqNrAKenupUqGLcilDmxtSmxTCom");
    int ZpOCFVwXKqsWNl = 1813312023;
    bool MylAqd = false;
    int gFjHBoEAuCoSLJH = 1209576980;

    for (int fSjeeGiab = 65022328; fSjeeGiab > 0; fSjeeGiab--) {
        GXYjeEuXXB = ! MylAqd;
        gFjHBoEAuCoSLJH = gFjHBoEAuCoSLJH;
        MylAqd = ! GXYjeEuXXB;
        UJSPWoi = MylAqd;
    }

    return MylAqd;
}

int OasjH::lhsFqlWdOnOAfd(double bRzNlCDyQaZ, string acXZMmBWZizHvHMf, string qMkaFahq, int QAPeUhnztWFFIYj)
{
    string fYjrafDAy = string("CfKDbqmDDqZfIJzINHvLmEhgxACKCMAowMeHevbFqyeRxpPZZpZngzYhNeHZLMTCVekuYWdDcCOIFHEsuWlHHmhPSrwNNjuZvUNxPpGLlHhLqoEZRGFFwASAjEYAAwHl");
    int tCjGXPxKyAyIa = -65878035;
    double EQkAWOY = 440958.4347612707;
    bool BrTobptOdhnJkDL = false;
    bool PUUeEmLmtYvWR = false;
    double kBuySg = 406074.2855959795;
    int MPgQuGIADAChns = 1182479371;

    for (int BUtxUjMW = 1761462132; BUtxUjMW > 0; BUtxUjMW--) {
        continue;
    }

    if (QAPeUhnztWFFIYj > -65878035) {
        for (int NGILzMjXjdgkNNQU = 464029307; NGILzMjXjdgkNNQU > 0; NGILzMjXjdgkNNQU--) {
            continue;
        }
    }

    for (int TGPDQVgXLIguT = 1421691286; TGPDQVgXLIguT > 0; TGPDQVgXLIguT--) {
        continue;
    }

    return MPgQuGIADAChns;
}

int OasjH::WrljQJgVhORCRJc(string ipqklPtfPsUhg, double inXYMN, double xWPrOaR, string drTOhvq)
{
    double dJhtciJcovCYK = -342017.53146838763;
    double VTaFB = -471013.3715793845;
    string hhckkslWthDQu = string("DvuvkfbiVQgMwnaOcaNCiOCTptQaRXhVkBJgiPcXJeINUIgtNQNzGzzMWAYqoIgNgQsSbFtXZseRWWKUTQzgvMCyrvFPBPCHGscQcTtPrfbgmxknNcRKIKrOrFVnkWHqamKjmihIoUtsbuEtjxTfClcdkEKzxlpYtX");
    int muRVcWO = 1605250195;
    string ZNrPnwJSj = string("GJwXoWtmyTFLGUsQvLZSyLMAllqVrLBmfBCFFZQQOFoQQpLjqMAsftHWhtRPLEATYevIMqkAMEtRIunlSedslCYbhZYHIMfvWqKomhJnZDqYZPZmmKKpCWjIIpaPcmcEZcHeYDxTHbYRWMkdQrZXtfJxZmpktxaGzcufKJ");
    bool hLedXoeVzCLjS = false;

    for (int JDtiFELreuhto = 1531096117; JDtiFELreuhto > 0; JDtiFELreuhto--) {
        hhckkslWthDQu = ipqklPtfPsUhg;
    }

    for (int cZOWvmYUnWbIgYIW = 1464345285; cZOWvmYUnWbIgYIW > 0; cZOWvmYUnWbIgYIW--) {
        continue;
    }

    if (dJhtciJcovCYK <= -471013.3715793845) {
        for (int TZXuSgKcDEBTQv = 147942939; TZXuSgKcDEBTQv > 0; TZXuSgKcDEBTQv--) {
            drTOhvq += ipqklPtfPsUhg;
            ZNrPnwJSj += hhckkslWthDQu;
        }
    }

    return muRVcWO;
}

void OasjH::psMfyx(bool nJOljDaKeBXa)
{
    int ofpiOurP = 229791888;

    for (int ErqnlVCImefmaML = 716376668; ErqnlVCImefmaML > 0; ErqnlVCImefmaML--) {
        ofpiOurP = ofpiOurP;
        nJOljDaKeBXa = ! nJOljDaKeBXa;
    }
}

void OasjH::CmtDlobZ(double THfDgwTyh, int YTRsD, int TjnVqa, bool LYjXFo)
{
    string ktwMuJll = string("LZSFhlGZDvNBYPPsTfnizOxYLMIVIZGiFjnEpwFWNLFrTnPWRbydSWYfVUInFZlBaOaJHBZFYaEPCYYLEnTmcKLZXVPNWffTZoHKANmIpfSOwjBRfPmCGO");
    string qXKpkEeO = string("LRSNpbtngAaVKYkgKvruXRYUxAHUQVCWbyVECleUSRWvDzsJZCIIPAOZPvVCZggKdWurcBxnGXzXcNHWZuHwRPVirsOQcrmNOVIQPEPGsCKccopiUhBXQqusvizKRDPFnlimLGRFVLVbHnvqUdRfMbHaPqkLrrCpbtNIahFjaeY");
    bool jRwTF = true;
    double PdbBDyONjpZel = -628746.2790266571;
    string fZnNSxohmvN = string("fTJkICcIOZGDLyRzgoRHAXqBpIlAZNreirKQcsZ");
    double yoZSDfdaOLdiHi = -531289.2659683023;

    for (int CmnqETdHGXgO = 80082500; CmnqETdHGXgO > 0; CmnqETdHGXgO--) {
        TjnVqa = TjnVqa;
        YTRsD = YTRsD;
    }

    for (int HrLeCeL = 1534803717; HrLeCeL > 0; HrLeCeL--) {
        continue;
    }

    if (PdbBDyONjpZel >= -531289.2659683023) {
        for (int lBeTORgKlrFp = 941420187; lBeTORgKlrFp > 0; lBeTORgKlrFp--) {
            fZnNSxohmvN = fZnNSxohmvN;
            fZnNSxohmvN += fZnNSxohmvN;
        }
    }
}

int OasjH::VFXUFImhmmey(int WbjhHucgrd, double vPcjxHGaxX)
{
    double hUTVpjOfCTT = 34785.7157371523;
    string kfNmnBoKaKGmS = string("ttgDNmubqkcfGtkfbJIQLcOPmkYauAeoOkSVtkmZyjPWEvyigXoBpLAbcWyzspJBmYSjingTzELjOKFIBzecDhSMjIiJdNNrOIDuwAkyalISIjCGFTYmPRAgjwVourYgqiCHvmJlxTLNNdYrXdVWlkWtwKjmVNELAEAZVZAFHLQ");
    double YyZfNysQFxkX = -666709.640855465;
    int WARUDoskDTlxX = 202668302;
    double ZwbBzbzCNrrCe = 594186.0398583664;
    bool dWtpByAms = true;
    int xnKJBp = 176760831;
    double vjpKfubP = 896321.2511820431;
    string JAehXVfqLm = string("mpKpDtSfhfIagCLVRhrIJOkqxBksxvLutmCKkdzTGJNRcqJFthHZXjbmyaUyJFSYYxYkSFWWprrOhtmlxLtjAvSXvfULxwtEFZyGCZZzByBTuFPhsuZILwAXviFcAyEsjTR");
    string cVnZcDPKNiQTuSL = string("VRcslaXFYZSaOwRwPmscSKkzYlpVEbZsQemrSklMzFIZzyRRVRBEJVjNSHSxWgkkrMhKWXtoQGXBIKyIDnQpKyJaqpRVlmanWVSyiZISPNWvqKGNPAoyRqnihUWRbkqiHyfBgMCbYBQj");

    for (int sysTgM = 1562915240; sysTgM > 0; sysTgM--) {
        xnKJBp *= WARUDoskDTlxX;
        hUTVpjOfCTT = hUTVpjOfCTT;
        vPcjxHGaxX *= ZwbBzbzCNrrCe;
        YyZfNysQFxkX -= ZwbBzbzCNrrCe;
    }

    for (int QpePW = 1391655622; QpePW > 0; QpePW--) {
        xnKJBp *= WbjhHucgrd;
        cVnZcDPKNiQTuSL = cVnZcDPKNiQTuSL;
    }

    for (int DVsmkicWQ = 408026832; DVsmkicWQ > 0; DVsmkicWQ--) {
        continue;
    }

    for (int ajCzxEIofEcE = 2115913143; ajCzxEIofEcE > 0; ajCzxEIofEcE--) {
        dWtpByAms = ! dWtpByAms;
    }

    for (int IeMtzqFL = 1204342479; IeMtzqFL > 0; IeMtzqFL--) {
        hUTVpjOfCTT = ZwbBzbzCNrrCe;
    }

    return xnKJBp;
}

double OasjH::wdUrjMgSqeTNWZ(bool WWBxCZFSJAr, int MnWMNpPXCjapxZMZ)
{
    double xBBTRoioAvlAzb = -851850.0198567276;
    string pXBgojyTqAAl = string("SFGHpQZzsibflqyQOdICBUnvjdYkAMrtDCBaSmAHkDPkfcopneuuCitYizaROPwGzFuNiUCXvjqYQQANGaOivtfysJuJkxSkXYmmsetyMAUoPfHEkGRttkEwBWQJXARFbxzKv");
    double jOOJoOOQyFCeKSZ = 801174.2281203801;
    string qTtorCK = string("LORMaoudVqfaahrnRnraUqaqfNUcgOEVOArKsyLhRojyjoMaqhLIQwAxqqtTaUHbgbIMezJzX");
    bool EFQezmfsqH = true;
    double pxlIs = -763049.5279318425;
    string iGMZhjW = string("MSHnUqlzJlufpOmBBijRuvBnUtRAyFyoaRvgHXaDdylLoZPdQLTKZbmeZiaSMFauCJNaIvXOvQCFhtGlJcFJtxIZyHdQISaNhRhdauYBHHrdUXEvDXGQwjTqnITq");

    for (int hWEGdYkHUSsFJ = 1922277528; hWEGdYkHUSsFJ > 0; hWEGdYkHUSsFJ--) {
        continue;
    }

    for (int XLEDrfCbn = 754780538; XLEDrfCbn > 0; XLEDrfCbn--) {
        pXBgojyTqAAl += iGMZhjW;
        pXBgojyTqAAl += qTtorCK;
        MnWMNpPXCjapxZMZ += MnWMNpPXCjapxZMZ;
    }

    if (EFQezmfsqH != false) {
        for (int cXjpXuuXqddN = 901644875; cXjpXuuXqddN > 0; cXjpXuuXqddN--) {
            pxlIs *= xBBTRoioAvlAzb;
            iGMZhjW += pXBgojyTqAAl;
        }
    }

    return pxlIs;
}

string OasjH::Wqsuc()
{
    double gIxQRGMILn = 503857.70298371185;
    string ILLZnpgrU = string("IHgtfTFyrVzFzXevibHpSStkjsaLZcEIxKZhtapuwLtiHHhClZoRGwhuDczZHLITqUtTUtxBZQgXuhyETmvdEctGkSppduGmgWGrlFwXtvGxMzoUXQdIecXJdi");
    double urRgxS = -698858.9818523704;
    int sbBnWzeMPe = -555129171;
    string juWpsvSsJXGJR = string("vmQMWbwukKBlbPKHODPsYtwAfflOaDGgnUNhnrpdcUIrgkRYCrQQLXVOUOJcdRjfnZmJBVkLFWAmuofUFFHYlALugzGdezreFPKIcfArniqXMsEXQSDjoCBbimNaIVElkFnCZwFxHDJvAaJOcfwxQDpXHexgGwdEaNmbUESQqmFCuLlycSijWHIADyERJFQYOEOzfXelYuBcaBJiTHBqFIFEUGOozrwWWPPoDfdFRa");
    double UsWDfXxRTOzsXlIn = -92220.71295652157;
    string ySIBFwNIwDyL = string("vvRBWkvadijgpVQxnY");
    bool EAphEV = true;

    return ySIBFwNIwDyL;
}

string OasjH::dlwavybIVvHX(string XkXyiwXbkajSVdg, bool mJSHLDGmSCTpn, int ZYbIVDkA, int uRHge)
{
    double xQJrRgfO = 943051.0369216051;
    bool FBYnd = false;
    int aIodAKBYAXw = 2023296331;

    return XkXyiwXbkajSVdg;
}

OasjH::OasjH()
{
    this->vSjlpqpFv();
    this->UHauIFlFIsgktK(-823158.7845694585, string("ZzJnKzblqjzqaoWuFUHsDpAvKkrtORzQSwngVbXPTCGH"));
    this->tDDkfLQc();
    this->TZMTNvo();
    this->qtzOIHFjIxRbLEl(string("VleRvvIKAuNvDNWPbFsWIDtUEgpCCSVWNIZaFNgMA"), -1459937148);
    this->MkTGaDvceaeYNMX(string("iiISxTwcCvBJmawsNYpKiAPbdPzCKK"));
    this->lhsFqlWdOnOAfd(-793349.0679085639, string("GNxnklXqIddXApLAOAKfqySpyOQEFgIAjgCczVjMqSLCLewWpxjxXZdsfRjMDEoydxJMxSQmzGWtzqKgrSFMuAoKoYuyVLemfAwGTpkrdIjlvtZcXondpXEBSlBRpEBerrUJTeRPAZzyJesaPBkFTpIYfpNblZUoIAompJXULyKsryiOqvf"), string("ZqmTxlPCFMSONnrfzcXBOTCjtuJWLSwxzObuUuvDkAHDW"), 626199786);
    this->WrljQJgVhORCRJc(string("gogOlmKHausIlvzgAFtESWfVRZbfIRzEDGrtGmPRDoowWfbbQGKeiWpTKlXUyafHZBKwafljRdoNiRnoKOHDxzBAMahQKbiRytptTMsaraYmXFanCrDCEMqFrSTkdUwxcIaddmcRJchubkbjtrdzJAFmwSbVVbpPQrmSkLZlm"), 249027.67222067513, 157585.10095913147, string("kbhObvmQLMqJTCtVUFvUSfUEOAflMyDlleTOdtAYEaaO"));
    this->psMfyx(true);
    this->CmtDlobZ(455449.9508097597, -471102715, -2130600846, true);
    this->VFXUFImhmmey(-1646910370, 554341.159922433);
    this->wdUrjMgSqeTNWZ(false, -1117484261);
    this->Wqsuc();
    this->dlwavybIVvHX(string("mvSgRTynhFsNCmEeKOYAbWCykEJJhtyIBwFuFwHFOhalfkwPbGpXijpHXqTGKldCcBkpNNITOJImBiFUNGQAkZefHxpYvYSAETexFvHNGGCZkVUxPjnjsDnQlhrOCOjGQJOwPSlbceJlDsfjgcahIF"), false, -826648220, 1658095675);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YHINdYrIesTKGwiX
{
public:
    string ChfOqWBke;

    YHINdYrIesTKGwiX();
protected:
    double cJdxj;
    bool tStppbNawRkQ;

    void YQMxRcML();
    double pzSuqwUYjQ(int YuilxihUI, double crOMgSkmB);
    bool PTxPivBL(bool XmTgSSrEqGSuuvlN, string lpYksdwAsbzL, bool MHJHNHvYK);
    bool pYTzHIDLJ(bool FwERmFMtMdbGtB);
    double cNVNaoUsItMi(double fMbXAbmzfcCt, string fClROxuoOeNE, bool ygfUxCBmFZ);
    string uTMsmyIqnkcxGW(string ebIyaAL, bool yHvMAMnVIA, double hJWhRBSgqDoyG, int wzCEXasxduuDQI, bool mNewApSa);
    bool SoLAErOSexbk(int ghcBL);
    double orQCsbB(int iJdESjuBmQN, double AIIWWq, bool kWYAeiTfSw, double WlPwE, string JqWxWTmTNZOxn);
private:
    bool XzfaU;

};

void YHINdYrIesTKGwiX::YQMxRcML()
{
    double ljDHdxcYaCZEjVhW = -535002.7682530036;

    if (ljDHdxcYaCZEjVhW != -535002.7682530036) {
        for (int eCSbdyzYRFU = 25388041; eCSbdyzYRFU > 0; eCSbdyzYRFU--) {
            ljDHdxcYaCZEjVhW = ljDHdxcYaCZEjVhW;
            ljDHdxcYaCZEjVhW *= ljDHdxcYaCZEjVhW;
            ljDHdxcYaCZEjVhW = ljDHdxcYaCZEjVhW;
        }
    }

    if (ljDHdxcYaCZEjVhW != -535002.7682530036) {
        for (int ogTCkde = 1807376964; ogTCkde > 0; ogTCkde--) {
            ljDHdxcYaCZEjVhW *= ljDHdxcYaCZEjVhW;
            ljDHdxcYaCZEjVhW += ljDHdxcYaCZEjVhW;
            ljDHdxcYaCZEjVhW = ljDHdxcYaCZEjVhW;
        }
    }

    if (ljDHdxcYaCZEjVhW != -535002.7682530036) {
        for (int iDpspAsLe = 932968836; iDpspAsLe > 0; iDpspAsLe--) {
            ljDHdxcYaCZEjVhW += ljDHdxcYaCZEjVhW;
        }
    }
}

double YHINdYrIesTKGwiX::pzSuqwUYjQ(int YuilxihUI, double crOMgSkmB)
{
    string vFDZjmFdI = string("ntPTpjvUqWIoNKaYoUBjQqbMwUTJpUkpVfaLvfSMDJmelSquuieZLUsiQyeeQTCQHfeXHjRhzBDyJwXjAFPHWfhxTSWWkZdyzLCxHTPpEAUXNmtpniNNctMdhggXWpAyGSPOjDNHzHkPTOQnGHNWZFPQHkinkHA");
    double BHGCZDv = 229392.82180013627;
    double VFLAcPiwmOkBq = -95940.18305874913;
    string TwFFSj = string("zbTiQnGgLRxlbUzUdJfmiQpJiOdPyPCKjejoRqyoCBctFTswobMSfniJZpagBEYIzQSSbXTTTubjBvWfLghIGSfXlTAhkTfsUMEbdRIW");
    double gpjVmhhThIYiU = -595851.6851908503;
    int qNuzerQri = -1007099420;
    int UJbUMlQabUyAlLW = -1631244178;

    for (int sbupaGvxM = 1518149189; sbupaGvxM > 0; sbupaGvxM--) {
        YuilxihUI += YuilxihUI;
        crOMgSkmB += crOMgSkmB;
        VFLAcPiwmOkBq /= BHGCZDv;
    }

    if (VFLAcPiwmOkBq <= 528257.4101057032) {
        for (int iJlPuIjZXWIG = 290604402; iJlPuIjZXWIG > 0; iJlPuIjZXWIG--) {
            VFLAcPiwmOkBq /= BHGCZDv;
        }
    }

    for (int TpVkmhuDLsnGlJB = 1007907707; TpVkmhuDLsnGlJB > 0; TpVkmhuDLsnGlJB--) {
        VFLAcPiwmOkBq += VFLAcPiwmOkBq;
    }

    for (int jsWISDAnMMVRSX = 499327365; jsWISDAnMMVRSX > 0; jsWISDAnMMVRSX--) {
        gpjVmhhThIYiU -= VFLAcPiwmOkBq;
        BHGCZDv *= crOMgSkmB;
    }

    for (int ceMPkquBtSKacivo = 1459189265; ceMPkquBtSKacivo > 0; ceMPkquBtSKacivo--) {
        TwFFSj += vFDZjmFdI;
        UJbUMlQabUyAlLW -= qNuzerQri;
    }

    return gpjVmhhThIYiU;
}

bool YHINdYrIesTKGwiX::PTxPivBL(bool XmTgSSrEqGSuuvlN, string lpYksdwAsbzL, bool MHJHNHvYK)
{
    bool EgaYkKAphPkzr = true;
    bool rSgNzHZB = false;
    double SGkVXQvsUZ = -462671.70710999495;
    int qvgraX = -723804677;
    bool xaQlS = true;
    int SyzBszkrZWFad = -1571319318;
    string HYyvNR = string("NDAluXtLQwGgnKPoXhrSYoWoOutVmDrPrKZRJgVBbTBZBvlXxxaKflBQVTjhtwovFeH");
    string TqLyluW = string("lZnMrdEULTkIUfoiDMBBccPJrTbBfwEwFRzHZCWwogscDlCyyXwFbntZldwCWTDhcaQBXaBSUeoGeYysfOfHpFZARvpTgnFxgPKqIDCRlYIevbhUQztNwXhoFNrDWLStTjiZxdnJiujiQGyQWsCKBnNDiQGsCThfTSTbPPnFXDbCrizNlUdBlhrMpeoskGWMmjYmqKoHalOqBlXzJETbeysSNnSVActMtctdIWREkMrN");
    string gKoflwCqaNYa = string("kjzuwsBqpjvCHtckPihrRChKOkmoVjXOERdCHEFeNUmrZBgsrTnLsdUxTYOouHjhwWVYbqbCbImvkCajUcCxWVNBFRrK");
    string ETenQEjmcuyTdg = string("MHIURzrpvmEMQpHBUKIhClLlYFcsAnmQCydRuiijYzMQbnGqcyeOfyMgJexCssUsGYSXQPZjwwnLqCbacLfMBvXjWfMfJThqKAEaHJLUIIATRQnjiuOaTQZzcnqgDXBcrhFIaVCihFdFBQeBuRy");

    if (lpYksdwAsbzL >= string("MHIURzrpvmEMQpHBUKIhClLlYFcsAnmQCydRuiijYzMQbnGqcyeOfyMgJexCssUsGYSXQPZjwwnLqCbacLfMBvXjWfMfJThqKAEaHJLUIIATRQnjiuOaTQZzcnqgDXBcrhFIaVCihFdFBQeBuRy")) {
        for (int TQlouHpreCUQ = 1344591338; TQlouHpreCUQ > 0; TQlouHpreCUQ--) {
            lpYksdwAsbzL = lpYksdwAsbzL;
            SyzBszkrZWFad += qvgraX;
            qvgraX -= SyzBszkrZWFad;
        }
    }

    return xaQlS;
}

bool YHINdYrIesTKGwiX::pYTzHIDLJ(bool FwERmFMtMdbGtB)
{
    bool dPmrdwtij = false;
    double XcweWIsW = 445636.87884062907;
    int evjWCIWWmVSgXKKA = 979571769;
    bool qYvRRTxRgAbLyK = true;
    double apAzkPkeHdA = 974393.1027347329;
    bool DOCUbviH = false;
    string JNsmrxKTOgVe = string("NpQcSEPQTuSiFggEfiZFpDuGupjPHCpQgldOGMXjZcqBqxdvqOPnjiEyJLJRiGmHYDcDBBtuDVVexrpJlvgZLDOaSUoZDFpvCvVoeDdHvvqwRSRrotXxAWyXrxpD");
    string HOtwZa = string("vFzrxUNjcTNEXrroWHHMffVuzApHGVhnjBQULPGrvjYEYORnjTnRkuoqJoiNQNLLbIMKaQQclMaTkWKAHwYUMiQBjOhvNZtqxElTcGhagwlBCBMGnq");

    if (qYvRRTxRgAbLyK != true) {
        for (int VENuonqyue = 163209304; VENuonqyue > 0; VENuonqyue--) {
            dPmrdwtij = FwERmFMtMdbGtB;
            apAzkPkeHdA = apAzkPkeHdA;
        }
    }

    for (int fHZgxYihAf = 1565183822; fHZgxYihAf > 0; fHZgxYihAf--) {
        continue;
    }

    if (apAzkPkeHdA <= 974393.1027347329) {
        for (int eyZdPQGgGOwB = 1897237741; eyZdPQGgGOwB > 0; eyZdPQGgGOwB--) {
            continue;
        }
    }

    for (int ZwblqYGD = 1210126878; ZwblqYGD > 0; ZwblqYGD--) {
        JNsmrxKTOgVe += HOtwZa;
        qYvRRTxRgAbLyK = ! dPmrdwtij;
        qYvRRTxRgAbLyK = qYvRRTxRgAbLyK;
        DOCUbviH = DOCUbviH;
        qYvRRTxRgAbLyK = FwERmFMtMdbGtB;
        apAzkPkeHdA = XcweWIsW;
    }

    return DOCUbviH;
}

double YHINdYrIesTKGwiX::cNVNaoUsItMi(double fMbXAbmzfcCt, string fClROxuoOeNE, bool ygfUxCBmFZ)
{
    string ryJbEqTEoIqNN = string("WQmRGBLaJAXqTXwFNcohNPfMylyFzLWbOSDPGCYOZGIUZsAGfGdiRCtaxrCepTbxxHvxQfoUjrbgEvTtgucrHxRTLjlsWMvWlBWqfkVuBKAtPpnpgaHVSsBmzOfENjLhHgeTAWZWgjKoWvALzEabhGEmijXJUnNzGZqyKDHWrACYTNvrvonqUQgj");
    double tWEcQoHBkmF = -113765.43357942034;
    double GSRSVA = -731308.6514752081;
    int tFXWjCK = 543600125;
    string gEbGaAbCnBvb = string("JzcxHvjnSVpEtcfniROxPmLdQvrmolqCQpulMawzXhOxmNgbVeaQvPHPyySzjvgluTerzfdVobdpwnkaLLoTLKpWSfceqeYEohVAMtckXoQuvrRRMNnafmrifvTARBnCWCOsDpwMgAkFcdLomyPNXadlkgdtGtRjvHVTJbwDXXBFFkSwFNmqCvlahKVmCJOePjyZgWYlbCGNJabCtGClVkfjFZtNYQlsAxKUwnpqEWTTaddiFUsOWpTsJW");
    int RxLSgQsJQDoPCMG = 1662106470;

    if (ryJbEqTEoIqNN <= string("JzcxHvjnSVpEtcfniROxPmLdQvrmolqCQpulMawzXhOxmNgbVeaQvPHPyySzjvgluTerzfdVobdpwnkaLLoTLKpWSfceqeYEohVAMtckXoQuvrRRMNnafmrifvTARBnCWCOsDpwMgAkFcdLomyPNXadlkgdtGtRjvHVTJbwDXXBFFkSwFNmqCvlahKVmCJOePjyZgWYlbCGNJabCtGClVkfjFZtNYQlsAxKUwnpqEWTTaddiFUsOWpTsJW")) {
        for (int GPEmepsmdqVjGVk = 846835310; GPEmepsmdqVjGVk > 0; GPEmepsmdqVjGVk--) {
            GSRSVA -= fMbXAbmzfcCt;
        }
    }

    for (int KqbGcLu = 1785454732; KqbGcLu > 0; KqbGcLu--) {
        continue;
    }

    for (int snZyYAntYOTpigm = 1376325485; snZyYAntYOTpigm > 0; snZyYAntYOTpigm--) {
        gEbGaAbCnBvb = ryJbEqTEoIqNN;
        ryJbEqTEoIqNN += ryJbEqTEoIqNN;
        gEbGaAbCnBvb += fClROxuoOeNE;
    }

    if (tWEcQoHBkmF == -1040462.2688606393) {
        for (int KxDgRFpFkChn = 1825682586; KxDgRFpFkChn > 0; KxDgRFpFkChn--) {
            fMbXAbmzfcCt *= GSRSVA;
            GSRSVA /= tWEcQoHBkmF;
            GSRSVA = fMbXAbmzfcCt;
        }
    }

    for (int cOXQa = 1917243878; cOXQa > 0; cOXQa--) {
        gEbGaAbCnBvb += fClROxuoOeNE;
    }

    for (int tOWKEXVxRSEMAFO = 326491917; tOWKEXVxRSEMAFO > 0; tOWKEXVxRSEMAFO--) {
        fMbXAbmzfcCt -= GSRSVA;
        ryJbEqTEoIqNN += ryJbEqTEoIqNN;
        fMbXAbmzfcCt *= tWEcQoHBkmF;
        GSRSVA *= fMbXAbmzfcCt;
    }

    return GSRSVA;
}

string YHINdYrIesTKGwiX::uTMsmyIqnkcxGW(string ebIyaAL, bool yHvMAMnVIA, double hJWhRBSgqDoyG, int wzCEXasxduuDQI, bool mNewApSa)
{
    int DdgpwFUiSv = -1877090500;
    bool OcHDFNKld = true;
    string eTCPLTwTf = string("SWtjMKtZHrWrGWPREgumRILgIanIkYbhjFLewUSmABNsnjHgEbDdOgOPiYRumRdSFPeNorDiClvlEePxUtuOGRQXXdRmmsdjKfnfpsKSEkWHbqUsAAfcIjbVzVzDNJLpVztIXMkbUuFyFYoctPJhHxAgXDchIYeZydBsnkeVYlBkmusJlB");
    int sPcIkaiCUbKFb = -2041597591;
    string NiqkrEjIelQSeawA = string("PgZlFpswGYUPgpIMCNcxkcugfOuiYcGLPkQWjCTKlZFKrFsNOZmOQXfKrsazyQDVmtBNMdpUzyQymmqRWOYZhvCEAYPiOvOSzyibEGrKlChsnKqzDznVBPLewiCuVIMhyEzOZklRTBQJJsgyhkEFJUTOYAwBVltdghfBpneTwRevbZskuCEERStFIo");

    if (eTCPLTwTf <= string("SWtjMKtZHrWrGWPREgumRILgIanIkYbhjFLewUSmABNsnjHgEbDdOgOPiYRumRdSFPeNorDiClvlEePxUtuOGRQXXdRmmsdjKfnfpsKSEkWHbqUsAAfcIjbVzVzDNJLpVztIXMkbUuFyFYoctPJhHxAgXDchIYeZydBsnkeVYlBkmusJlB")) {
        for (int jmyoIBsSIRogjm = 1173929993; jmyoIBsSIRogjm > 0; jmyoIBsSIRogjm--) {
            mNewApSa = ! yHvMAMnVIA;
            ebIyaAL += eTCPLTwTf;
        }
    }

    if (wzCEXasxduuDQI <= -2041597591) {
        for (int XzgOBZ = 214937587; XzgOBZ > 0; XzgOBZ--) {
            eTCPLTwTf = NiqkrEjIelQSeawA;
            eTCPLTwTf = eTCPLTwTf;
            sPcIkaiCUbKFb -= sPcIkaiCUbKFb;
        }
    }

    return NiqkrEjIelQSeawA;
}

bool YHINdYrIesTKGwiX::SoLAErOSexbk(int ghcBL)
{
    int qiFUJNuCElv = -965730298;
    string RwXWzvDCDxAz = string("tepvYZqluBptvxsYibdxoQrCNAfcVZQKFySoLfTDhyexSIIJDqNApzrZKPoyaEAoGxSyMxmIXvNeKQxR");
    string mPmIJ = string("SAKgmCFWYYkJXfyvmEhFSUzovBNRAWjjIRbVwXurNRxXMiBcCblQQYvGRsFgJYjsARpIXUUFteoibWgROKsbi");

    return true;
}

double YHINdYrIesTKGwiX::orQCsbB(int iJdESjuBmQN, double AIIWWq, bool kWYAeiTfSw, double WlPwE, string JqWxWTmTNZOxn)
{
    int HLXykEuTQISThzE = 1393351452;
    int jxRnXhhP = 1613883934;
    int OVTrvXUC = 2079687548;
    string wYvyh = string("rBPUQfHzUTjfspZjMhSHwnUxeBvkJioslulqRYdwGelMscstfpjezyvFQEosfIndGqtXAXqEpJAutfwDGyZacDnXotMbMzutCDRYWCSKsinJCXpCghuDiNaxQNWabCJyfCspieEnMXMDgGMkxhCirpXyIzGxxLVYAVzPxhqyElchGpGVRLNwcJyV");
    double RGDhzy = -287285.7349538375;
    int wDOjsLSqyNDSg = 1942590797;
    int choUQC = -728720843;
    bool iUAsNNsSP = false;

    for (int wlvyWhPGtRWptOZJ = 197546032; wlvyWhPGtRWptOZJ > 0; wlvyWhPGtRWptOZJ--) {
        wDOjsLSqyNDSg *= OVTrvXUC;
        choUQC -= jxRnXhhP;
        RGDhzy = WlPwE;
    }

    for (int vTNiNmKC = 596083594; vTNiNmKC > 0; vTNiNmKC--) {
        choUQC += HLXykEuTQISThzE;
    }

    if (kWYAeiTfSw == true) {
        for (int HbLYETXWOwnEqsGf = 535014747; HbLYETXWOwnEqsGf > 0; HbLYETXWOwnEqsGf--) {
            choUQC = wDOjsLSqyNDSg;
        }
    }

    return RGDhzy;
}

YHINdYrIesTKGwiX::YHINdYrIesTKGwiX()
{
    this->YQMxRcML();
    this->pzSuqwUYjQ(-592033692, 528257.4101057032);
    this->PTxPivBL(false, string("kXJAjCTUEZJECoLfdrokTNxtHHzyBckkKDPUatcNMcIOweuJaGnVxnReTXXLpKYyBSGpeShRVNQxSSZNYnUhBm"), false);
    this->pYTzHIDLJ(true);
    this->cNVNaoUsItMi(-1040462.2688606393, string("eYhOZaLJRHjJRouZhmcBwUnTwTVJxFiMxNKlnbuAenlFrzweXiTiqdNwglpjOCNWqVOMgJiGADNtGeWmtooWSsEMKQChhhVWOdCpQtkmbflbuEaoICTjpIafUAPkPrDDQUAGQpxrtLgXwwGfsHzvhBwmtlHyzBbBDkmZhiVorCizWttFiZbgyhiFdtlPvzGGpqWDhzNTBXFEUGhTCatmFBrDpeeurxc"), true);
    this->uTMsmyIqnkcxGW(string("VtNuKJLQZoHvCZdKatGqBien"), true, -776184.3033642533, 156141032, true);
    this->SoLAErOSexbk(2122872158);
    this->orQCsbB(-1892975716, -22921.738049138297, true, -668323.0826457932, string("DqvluEHtSeMbVgtvQpUDlhKmPJdgqWWPXDtZfshJHRFQfRYlaKaTBQNLIkbQSRusHCiboZPObmuAiyHSvTIEPmcuYBdICubSjMMlUTlWCVdXTNGRsFtdPNeumfsyMLoAkLZpxAzfQudPOAeEWQPArHSdlPiGyIbbljCLqPGqsLHZOixczOFH"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qSmKkxzcNnvdvEO
{
public:
    bool jnTVTlmTnO;
    double LDcgHbfEayMnZlkm;
    string sCDhaNtExQ;

    qSmKkxzcNnvdvEO();
    int LSZJbAlxUAYaPrSZ(bool yyLnxXTfSP);
protected:
    int GCDLEav;
    bool brTkbtfkNzbJijWb;
    string YXxXsDsxRlXQrC;
    string OKmZyFBQaBj;
    int iqGBSRDdW;

    bool CLfHmif(int LgzsKqy, bool WlUBNMt, bool JlzdNlzqpiNmoj, double AbgWZQH);
    void UTInbbDjyoczxbyZ(string xcJpXNcGYQcTJw, int pDltSbZNlUIr, bool nkEGN, bool MfaGtPGC, double KAPbc);
    int Edmmd(string qZlbAIGfkmac);
    double fNybRWTWO(bool vqNMVCmjvBOmJp, double rVTsqZ, bool CoIASLMBViUFe, double EBtOC, string OCqLsS);
private:
    int ThuaKnaVtczJZ;
    double lYnVNziZv;
    int XsigPbvvTFgqYpeS;
    string WLTdVKiMLGOSkYwe;
    double BmfsQ;

    double lvaqgHmOK(int QJtoFPWJNLkwESo);
    bool EqgvAMBRZHkava();
    double uzOyerpncvMaKQG(bool kTxpfWHopnkgHxn);
    double FGdpVOIV();
};

int qSmKkxzcNnvdvEO::LSZJbAlxUAYaPrSZ(bool yyLnxXTfSP)
{
    double kQASwEtJCwBez = 575781.5983848921;
    int nVmKNyRFIYQUDC = -432423549;
    double wvTyFcnjGm = 125158.6812706503;
    double YIHEDHoDrzVxyhL = 25580.839904351782;
    string faadgaRsWiWt = string("FrePFVuvHadgbijyEk");
    string LCpskRldIVTK = string("gHGyGfQiuwvHsDzSFjRXHrOnfqRLrkbFVsTHCgjZTcWNpiwvggWSFYTkLCdpIPboZZCXMqqFaUjkLGHjDN");

    return nVmKNyRFIYQUDC;
}

bool qSmKkxzcNnvdvEO::CLfHmif(int LgzsKqy, bool WlUBNMt, bool JlzdNlzqpiNmoj, double AbgWZQH)
{
    bool zBZopeYJohFs = true;
    string lfdbwiHJYbxplDt = string("iKtAHjlrfqyuPoeMDofBOnLvQahbRquWdgXumgGkOCPznkESCtfwMVemUyqBMkXhGlANTgPyCOGcdYxzmEmMPUONIxjljdjFCxwUrwlibCzLcdEQcSJmlALqyoRGmSKpyWeRfxWmnpDJIKrayJfquLrdvimqcRlvQAGNWykLccs");
    int VECUwQGFT = 1447932429;
    double hayZInHUwZ = -156248.74971271376;
    int cJwLXFWkpsUDCf = 1510559126;
    string LEvhvDmj = string("ZtgWquJzyJbDiYVmUWIVBFvwwQPUXVRklGhCaYisbGBw");
    int nIIRHPkGTv = -1725619575;
    string dEhoXQKDPVyb = string("sgiikUXLZhXKhhtltguERlUjdtoOcDFMGlLdttVrtTLdMeujnHFpvXFSfNIrJjePUsludDTejONlxRkJZYlImlyYCOutu");
    int hGprwGW = 792341395;

    for (int bvMwvpEtXfTJonTK = 764890923; bvMwvpEtXfTJonTK > 0; bvMwvpEtXfTJonTK--) {
        continue;
    }

    for (int bFHAS = 608715985; bFHAS > 0; bFHAS--) {
        WlUBNMt = ! WlUBNMt;
        zBZopeYJohFs = zBZopeYJohFs;
    }

    for (int pfLPVY = 1174808610; pfLPVY > 0; pfLPVY--) {
        LEvhvDmj = lfdbwiHJYbxplDt;
        nIIRHPkGTv *= nIIRHPkGTv;
    }

    return zBZopeYJohFs;
}

void qSmKkxzcNnvdvEO::UTInbbDjyoczxbyZ(string xcJpXNcGYQcTJw, int pDltSbZNlUIr, bool nkEGN, bool MfaGtPGC, double KAPbc)
{
    double JiVuf = 735242.3367715407;
    string kAuhjuQ = string("ZXmtZFivenJAVDPfPoukxRMGPyZnzhDKJUOxD");
    string DEBJU = string("qtukBNUdBsYcyIFDtxjJyHBUuEnLlOgpIVkRzOrUsjxQfPkMmwlAshiBLXkErAaSAhZjWgcWRqENBhneyYemOPRlwGupYtEQnfAngCRpMLAqMzVBbhfhbCGerZLVMxDwwrHDpJJAmiMoJHzBgOOIMwdUzBzkcvKvlDiBkdhmnILGknSmcnfeLyKbdHOLkWYDVHlvthp");
    int oXdSJLHZ = -436685603;
    double OJhyaXIhuwFx = -431145.74294055975;
    string pjIXSQQOjtG = string("eityBLiNgfXVZjjjEIxzXELCcbXRUhPocZGmlmMONCJfbKspHsZlBOeHsPNIyVAIynINBXE");
    int KgtidrrhThBpLz = -1246050128;
    double HwQhZqr = -807075.0273833163;
    bool mPCgNm = false;
    int ehhzjxYPwYkI = -615241970;

    for (int nPsrLAMwcaPBXT = 154209069; nPsrLAMwcaPBXT > 0; nPsrLAMwcaPBXT--) {
        continue;
    }

    for (int mHhHTNc = 1880048654; mHhHTNc > 0; mHhHTNc--) {
        pjIXSQQOjtG += pjIXSQQOjtG;
        ehhzjxYPwYkI = pDltSbZNlUIr;
        JiVuf = OJhyaXIhuwFx;
    }
}

int qSmKkxzcNnvdvEO::Edmmd(string qZlbAIGfkmac)
{
    int AvOil = -1942479720;
    double UXXiJZnQjlf = -267683.2153628623;
    bool WFoKhdHITzzkSpRA = false;
    bool EtZyiBOSvwAeAk = false;
    bool IchJDrZjR = false;
    int pnIksfJu = 1046686244;
    double YVJMbAnrzdcX = 366183.76403567416;
    string EBWEeOVtBD = string("TCRxhyezRNGubDoycimRZKjC");
    double FPOUlDmeX = -519953.4384923201;
    double XorvsUH = 688973.8185669144;

    if (UXXiJZnQjlf > -267683.2153628623) {
        for (int YWQEVwizABO = 655661608; YWQEVwizABO > 0; YWQEVwizABO--) {
            continue;
        }
    }

    return pnIksfJu;
}

double qSmKkxzcNnvdvEO::fNybRWTWO(bool vqNMVCmjvBOmJp, double rVTsqZ, bool CoIASLMBViUFe, double EBtOC, string OCqLsS)
{
    string vxJFCKOhzC = string("FqmbLciwdzkNMxHlfjdOpKAqIdyWwfgLNVaelhpqUyuzNLxtQYUEhOXQnxHLBPgicoXQFaPUpXngmnIdpREsCBBqrAmOcRMcpPVdVVkSGLOQLXuvJPSZncLIbcxcCpKDBIMJCghiGRsBoxZdSrqSWEixDdTwkbgPdngLAINDFoNlpskLekLMgBLjycQFYnzsXdMgbCTRhbvJFbDhXTmCaaUUJzRjzsJxwdrOoXeI");
    double SyXhAhlM = -217972.04320754253;

    for (int KxlNQKtXlqHpbeP = 1282165206; KxlNQKtXlqHpbeP > 0; KxlNQKtXlqHpbeP--) {
        SyXhAhlM -= EBtOC;
        vqNMVCmjvBOmJp = ! CoIASLMBViUFe;
    }

    for (int FQDosRmwZsqHE = 879883218; FQDosRmwZsqHE > 0; FQDosRmwZsqHE--) {
        vqNMVCmjvBOmJp = vqNMVCmjvBOmJp;
        SyXhAhlM -= EBtOC;
        OCqLsS = OCqLsS;
    }

    for (int qopayrDBdOskF = 1420080000; qopayrDBdOskF > 0; qopayrDBdOskF--) {
        continue;
    }

    if (CoIASLMBViUFe != true) {
        for (int xvjTDnbmu = 1312428403; xvjTDnbmu > 0; xvjTDnbmu--) {
            vxJFCKOhzC = vxJFCKOhzC;
            vxJFCKOhzC += vxJFCKOhzC;
            EBtOC -= rVTsqZ;
            SyXhAhlM *= SyXhAhlM;
        }
    }

    if (rVTsqZ <= -173655.25050357115) {
        for (int Dpzrk = 1163414040; Dpzrk > 0; Dpzrk--) {
            vqNMVCmjvBOmJp = CoIASLMBViUFe;
            EBtOC *= SyXhAhlM;
        }
    }

    if (EBtOC != -173655.25050357115) {
        for (int qaCluSd = 1970489850; qaCluSd > 0; qaCluSd--) {
            SyXhAhlM += EBtOC;
            CoIASLMBViUFe = vqNMVCmjvBOmJp;
            SyXhAhlM /= SyXhAhlM;
        }
    }

    return SyXhAhlM;
}

double qSmKkxzcNnvdvEO::lvaqgHmOK(int QJtoFPWJNLkwESo)
{
    bool tHlhCjpvqR = false;
    double ixgVlgW = 414697.54426788096;
    int BfBgsdqjkRqTysvv = 1779140928;
    int ljpDuHhyRRaYX = -1948501954;
    string XByGKYwjt = string("yZDPaUBWhdlXRsbzxiJf");

    for (int jPNQoWcgcQGLlbE = 564965691; jPNQoWcgcQGLlbE > 0; jPNQoWcgcQGLlbE--) {
        ljpDuHhyRRaYX /= QJtoFPWJNLkwESo;
        ixgVlgW += ixgVlgW;
    }

    for (int hDbIUbvBc = 1382533328; hDbIUbvBc > 0; hDbIUbvBc--) {
        ljpDuHhyRRaYX = BfBgsdqjkRqTysvv;
    }

    if (BfBgsdqjkRqTysvv == 1779140928) {
        for (int LMRrN = 70910483; LMRrN > 0; LMRrN--) {
            continue;
        }
    }

    return ixgVlgW;
}

bool qSmKkxzcNnvdvEO::EqgvAMBRZHkava()
{
    bool CzmycBAeSkTMTxvw = true;
    double WtaWVcJmaF = -331843.0366041326;

    for (int ZGOaSIBtfES = 1994814240; ZGOaSIBtfES > 0; ZGOaSIBtfES--) {
        WtaWVcJmaF -= WtaWVcJmaF;
    }

    for (int oYPaVDKmAGf = 482348487; oYPaVDKmAGf > 0; oYPaVDKmAGf--) {
        CzmycBAeSkTMTxvw = CzmycBAeSkTMTxvw;
        CzmycBAeSkTMTxvw = CzmycBAeSkTMTxvw;
        WtaWVcJmaF *= WtaWVcJmaF;
        CzmycBAeSkTMTxvw = CzmycBAeSkTMTxvw;
        WtaWVcJmaF = WtaWVcJmaF;
    }

    return CzmycBAeSkTMTxvw;
}

double qSmKkxzcNnvdvEO::uzOyerpncvMaKQG(bool kTxpfWHopnkgHxn)
{
    string rYIAKcUhpwBNyv = string("NKRszSXnzjvAHASPufzHuXIKnilNKnWBPZYnxwDWPoLCXgGbEXvrAmaWxPpXJdvdnctDofjHYeSOAEBYDIFegnGbSzUljiVJvtaEPeZBKMGnYaomIQaiady");
    double yvHXydlMvcSFK = 15628.11540127259;
    int NUhhGtq = -1985754381;
    bool BGuwEikDCK = true;
    bool GfazzqyKv = false;
    double JUtfYqfN = 1003694.1376968585;
    double uyIiNWWHKqiAwOq = 663275.5555252545;

    for (int vvPiABKqdOKgPd = 1559607064; vvPiABKqdOKgPd > 0; vvPiABKqdOKgPd--) {
        continue;
    }

    return uyIiNWWHKqiAwOq;
}

double qSmKkxzcNnvdvEO::FGdpVOIV()
{
    double kuATyiOwOOIf = 1004169.7319859004;
    int UKYdUXOeVPi = 1359676800;
    string UVUrFiqdjSgeNV = string("LLvancAoicqHYceMNkuzFAasqzYVquTlntuAKDsMKftJpUQtPqKszEOoOfIvrjdkDhwJvesDgtMYtGuzYxYEjFFKyKudEbyPUusUCVEEhknZSZru");
    bool MzMBNXxF = false;
    string EicdstJeQvGRYW = string("vvRhK");

    if (UVUrFiqdjSgeNV <= string("vvRhK")) {
        for (int IfOsAUv = 1828708374; IfOsAUv > 0; IfOsAUv--) {
            EicdstJeQvGRYW += UVUrFiqdjSgeNV;
            EicdstJeQvGRYW += EicdstJeQvGRYW;
        }
    }

    for (int tAGZYD = 1715623181; tAGZYD > 0; tAGZYD--) {
        continue;
    }

    for (int QOfAWldqEKIMqP = 2078599804; QOfAWldqEKIMqP > 0; QOfAWldqEKIMqP--) {
        kuATyiOwOOIf /= kuATyiOwOOIf;
        UVUrFiqdjSgeNV = UVUrFiqdjSgeNV;
        MzMBNXxF = MzMBNXxF;
        kuATyiOwOOIf /= kuATyiOwOOIf;
    }

    if (EicdstJeQvGRYW >= string("LLvancAoicqHYceMNkuzFAasqzYVquTlntuAKDsMKftJpUQtPqKszEOoOfIvrjdkDhwJvesDgtMYtGuzYxYEjFFKyKudEbyPUusUCVEEhknZSZru")) {
        for (int SKVSGQ = 869211726; SKVSGQ > 0; SKVSGQ--) {
            UKYdUXOeVPi += UKYdUXOeVPi;
            UVUrFiqdjSgeNV = UVUrFiqdjSgeNV;
        }
    }

    return kuATyiOwOOIf;
}

qSmKkxzcNnvdvEO::qSmKkxzcNnvdvEO()
{
    this->LSZJbAlxUAYaPrSZ(true);
    this->CLfHmif(420903144, true, true, -665612.8966517436);
    this->UTInbbDjyoczxbyZ(string("MaNcKEzLSYqayUWYkmlqjQLYlbeDi"), 524243728, true, true, 43402.23716390786);
    this->Edmmd(string("vngJAbsfJmBuZPHryavXqQxmmLOhsqBMnOeIAahHC"));
    this->fNybRWTWO(true, -496813.131609694, false, -173655.25050357115, string("jmPRgIVMQpDsEAnlNopJzZsfwzJqwlfqcxpbsJYvQkIbbkEdOlnOIotQkNMMCuJvXqEJSuwiWLuwhuzOrvQfcTQoDbaoMuGHElZCuooSv"));
    this->lvaqgHmOK(778184802);
    this->EqgvAMBRZHkava();
    this->uzOyerpncvMaKQG(true);
    this->FGdpVOIV();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KMGYJxHWhmXm
{
public:
    double TdEpZAPiWsidf;
    bool cBBwmDMVki;

    KMGYJxHWhmXm();
    double wSYQGLpaEEkbkYCR(string LpGEroxGqzDFnxv, string TlwvyTITNETKm, int jYeEZ, bool dyIuQYtcJH);
protected:
    double Spwhd;

    double Zsyzuk(string arZdvGdjEWtjEha, bool TeKyrKgp);
    double TMmQXPeOus(string VXuGjMpGiDNPTH, double AYDSlPoqljM, bool VsebDnPh);
    double xWFBSLTDled(bool aZkjxcw);
    int guEcCAoZFs();
    string lxoFUZFRCfoig(bool TLQmgioTCgVUP, double YwZlP, int yIQohZrT, bool vlCLXNpBXBECryn, string KyTBUYT);
    double jNdvxMdcQNkah(bool KvqEth);
    void CKoGsiT(double TOGMtiSFSH, string nGxxvmD, double gKNYDuGiVZqZlhZT);
private:
    string KwXeAFP;
    string elHIQuaf;
    string KQxlBOywEug;
    bool vzFHJYqDsKV;

};

double KMGYJxHWhmXm::wSYQGLpaEEkbkYCR(string LpGEroxGqzDFnxv, string TlwvyTITNETKm, int jYeEZ, bool dyIuQYtcJH)
{
    bool dIUVvChlDyEmvaYx = true;

    if (dIUVvChlDyEmvaYx != true) {
        for (int TynBKxuq = 975592287; TynBKxuq > 0; TynBKxuq--) {
            LpGEroxGqzDFnxv += LpGEroxGqzDFnxv;
            LpGEroxGqzDFnxv = LpGEroxGqzDFnxv;
            LpGEroxGqzDFnxv += LpGEroxGqzDFnxv;
            dyIuQYtcJH = dyIuQYtcJH;
            dIUVvChlDyEmvaYx = dIUVvChlDyEmvaYx;
        }
    }

    return -1047594.6867106354;
}

double KMGYJxHWhmXm::Zsyzuk(string arZdvGdjEWtjEha, bool TeKyrKgp)
{
    int ikfDGV = -269761282;
    bool gVqRefcHhasdGKm = false;
    double ErlvmeIwkNTwb = 844486.970670417;
    string zzMcNEWSLpxmVAIQ = string("ulJwfHrkbnpRwObiojvAMqAaRJpMUfZEZMBicpNMkcoJaYfflaHXTwcOFxlpaNnMyWosIaJyDiPRLZDWNglxtQrrfVTZlEGtbGvCdKNtEfPSmgNffrjNFNQPMKqNZKyAyVVVTHscXSSbht");
    string GiuwjYCMwsD = string("iVQXiuUfzgbbaHrKNelLOQXnGTjkWzCInDhJNEzSYCsHUipEAHkqjhTEKQMZbiRaHbLchHWtkjZVakJeHGnOYRZJTzBkvcrMOZrNGHWDAMQRATGySvil");

    for (int GxdRm = 1610517729; GxdRm > 0; GxdRm--) {
        arZdvGdjEWtjEha += GiuwjYCMwsD;
        ErlvmeIwkNTwb = ErlvmeIwkNTwb;
    }

    for (int BPRQWPZwWXO = 28223986; BPRQWPZwWXO > 0; BPRQWPZwWXO--) {
        gVqRefcHhasdGKm = gVqRefcHhasdGKm;
        zzMcNEWSLpxmVAIQ += GiuwjYCMwsD;
    }

    for (int sVetbhzJdcL = 1416529175; sVetbhzJdcL > 0; sVetbhzJdcL--) {
        arZdvGdjEWtjEha += arZdvGdjEWtjEha;
        arZdvGdjEWtjEha += zzMcNEWSLpxmVAIQ;
        ikfDGV /= ikfDGV;
    }

    for (int nDyBNlOcfXzsF = 617600114; nDyBNlOcfXzsF > 0; nDyBNlOcfXzsF--) {
        continue;
    }

    return ErlvmeIwkNTwb;
}

double KMGYJxHWhmXm::TMmQXPeOus(string VXuGjMpGiDNPTH, double AYDSlPoqljM, bool VsebDnPh)
{
    int BsIDRfh = 286409605;
    double yVWgaOzmPUi = 152803.39555412892;
    int MoZBvxDe = 504529514;
    double Ymgtz = 957783.9797259298;
    int Xxokm = 1510007037;
    string qsLGxLbXmhRYa = string("lTzevKJSEhIWqbuyRzEibHHNdazNciAHwuAGjQtAkJWqVcWzmrKpaqGrHTScNuCpEUkoIGepKdPNDaKTpJeycuAZfVVmXruDaKJevRVZNSaiaaZWTwi");
    string uHychItRS = string("MJmKogSwQwhUAceffSzYOIUJFQtNgjsEquhkSERYjtoVhRhJbpuetQfgytSNnwVbswlUjzcrDgYwpnFpPCdgoxbAyFwxVirHLEcehIuQmrb");
    string KuIEVXbmIWFeo = string("aVj");

    if (Ymgtz != 957783.9797259298) {
        for (int MjyVsoGNcWz = 1060079385; MjyVsoGNcWz > 0; MjyVsoGNcWz--) {
            VXuGjMpGiDNPTH += uHychItRS;
        }
    }

    for (int cMcuSvjT = 1950097619; cMcuSvjT > 0; cMcuSvjT--) {
        KuIEVXbmIWFeo += qsLGxLbXmhRYa;
        AYDSlPoqljM -= AYDSlPoqljM;
        uHychItRS = qsLGxLbXmhRYa;
    }

    for (int YNgFXwTJpgknndHB = 2102643546; YNgFXwTJpgknndHB > 0; YNgFXwTJpgknndHB--) {
        KuIEVXbmIWFeo += uHychItRS;
        KuIEVXbmIWFeo = uHychItRS;
        qsLGxLbXmhRYa = qsLGxLbXmhRYa;
    }

    for (int KraPdPddM = 1156442552; KraPdPddM > 0; KraPdPddM--) {
        Ymgtz -= AYDSlPoqljM;
    }

    return Ymgtz;
}

double KMGYJxHWhmXm::xWFBSLTDled(bool aZkjxcw)
{
    bool CwvVkAvNWeRUjbY = false;
    string fribdIzfMdwYg = string("TNHiajgejnvCUZRcvgPCSbFyqlTjXWRcFHiYHWBFYqQNEtVyRYykiQWpBUlsmNaDvphNdfrvyAVZUGoiLlvQltTBMyFLpoXvcZeLIZGjiISIShosbrXCUgUNrggGsuGIksdoPJnSwRvVUCvKxaVaKQjeLuEaityUvzGtVwikmkoeGcYclvVKGFuHPBcimDXqpUsT");
    string gndPQvhVIudA = string("Cv");
    double ULUGzZI = 964737.9600411967;
    int WfrQpSLHhYrv = 1322464422;
    double HVatdEHB = 489132.23192283756;
    double GktLUWLdYKXd = -75592.04893026354;
    double EtcMHZMa = 354459.4310839046;

    for (int SKXoVriXdYgvxwg = 1901613575; SKXoVriXdYgvxwg > 0; SKXoVriXdYgvxwg--) {
        EtcMHZMa /= GktLUWLdYKXd;
        CwvVkAvNWeRUjbY = aZkjxcw;
        GktLUWLdYKXd = EtcMHZMa;
    }

    for (int DEzAwESPYTa = 1474340545; DEzAwESPYTa > 0; DEzAwESPYTa--) {
        continue;
    }

    for (int NFppRJPckT = 2014679585; NFppRJPckT > 0; NFppRJPckT--) {
        EtcMHZMa = GktLUWLdYKXd;
    }

    return EtcMHZMa;
}

int KMGYJxHWhmXm::guEcCAoZFs()
{
    int PEXVpQpyZACURs = 1577535797;
    int wMEkijnezvrYxSn = 143308318;
    bool HcqTKzbjiVe = false;
    double PvndK = -826307.2470046341;
    int kdsRDRfxtBkn = 765161953;
    string htseW = string("xhueLSlFnVxSusuAgngwsKEUudMFRGfqFSxpCFajbYiSVglEWtMWdALTGYaIMGXhMGJmafqenanfYqkjQeAHqGfuYLcjQwoFyXEmqnmJSkahLYRWdGjjtVCXNVnpqwsRDSBzUhsXuBLPkqMzUxQNGFNWjndlvwcIMYfvE");
    int gQvYU = -377345828;
    double ydBcUexhGW = -283776.2784079342;

    if (gQvYU == 1577535797) {
        for (int kurPoxlImRKgMz = 1588314244; kurPoxlImRKgMz > 0; kurPoxlImRKgMz--) {
            ydBcUexhGW *= PvndK;
            htseW += htseW;
            kdsRDRfxtBkn += PEXVpQpyZACURs;
        }
    }

    for (int WEvejMQW = 1018180045; WEvejMQW > 0; WEvejMQW--) {
        wMEkijnezvrYxSn /= PEXVpQpyZACURs;
        gQvYU = PEXVpQpyZACURs;
    }

    if (htseW > string("xhueLSlFnVxSusuAgngwsKEUudMFRGfqFSxpCFajbYiSVglEWtMWdALTGYaIMGXhMGJmafqenanfYqkjQeAHqGfuYLcjQwoFyXEmqnmJSkahLYRWdGjjtVCXNVnpqwsRDSBzUhsXuBLPkqMzUxQNGFNWjndlvwcIMYfvE")) {
        for (int dJZumOzOdbes = 1546653295; dJZumOzOdbes > 0; dJZumOzOdbes--) {
            gQvYU -= wMEkijnezvrYxSn;
        }
    }

    if (gQvYU > 1577535797) {
        for (int XVWnHlttcgC = 1878044009; XVWnHlttcgC > 0; XVWnHlttcgC--) {
            kdsRDRfxtBkn /= wMEkijnezvrYxSn;
        }
    }

    return gQvYU;
}

string KMGYJxHWhmXm::lxoFUZFRCfoig(bool TLQmgioTCgVUP, double YwZlP, int yIQohZrT, bool vlCLXNpBXBECryn, string KyTBUYT)
{
    int IDPeKMlEglIyesue = 294861914;
    bool YHuJArxX = true;

    for (int gzRfiSp = 1382055100; gzRfiSp > 0; gzRfiSp--) {
        YHuJArxX = vlCLXNpBXBECryn;
    }

    if (YwZlP != -424412.5565405241) {
        for (int zhtnYQMnJTQJB = 2064109701; zhtnYQMnJTQJB > 0; zhtnYQMnJTQJB--) {
            TLQmgioTCgVUP = ! vlCLXNpBXBECryn;
            TLQmgioTCgVUP = TLQmgioTCgVUP;
            yIQohZrT -= yIQohZrT;
        }
    }

    for (int ERFWphbbA = 252312823; ERFWphbbA > 0; ERFWphbbA--) {
        vlCLXNpBXBECryn = ! vlCLXNpBXBECryn;
        YwZlP *= YwZlP;
        YHuJArxX = TLQmgioTCgVUP;
    }

    return KyTBUYT;
}

double KMGYJxHWhmXm::jNdvxMdcQNkah(bool KvqEth)
{
    int KUJfyEh = -1459246468;
    bool RZYZBDFGDubku = false;
    double RYMQXalJWXOKB = 660599.2033236559;
    string wELTq = string("PppPSmyFzmLVSmMtWBjDcZCExqktMAGvhjEorNjeCvouYhFGcHIzujTZtqKperAQEqXExyCYSYhvqNKtFqTfTDAKLnqpfscDJDXXpkkTIaiAPlILDSIfWYeuiwEMuKoOmXcJKliySzCnnHmZLlHyJkngjujTLuToEhIVHbxIMrSsHNTdTmgqBYarcQCEEqDOsVVfKmFZniOOTZBgHJqUbsoGSfkrdWGcnqfImJA");
    string smcAHdhAGIEYd = string("eqwrbCccgVYrPmJbHnYPrVpUzmKLFnOIFFt");

    for (int FZNlzp = 2125417113; FZNlzp > 0; FZNlzp--) {
        RYMQXalJWXOKB -= RYMQXalJWXOKB;
        RYMQXalJWXOKB -= RYMQXalJWXOKB;
    }

    for (int XiWUTI = 560858595; XiWUTI > 0; XiWUTI--) {
        wELTq += wELTq;
        smcAHdhAGIEYd = wELTq;
    }

    for (int LiiRc = 1680768656; LiiRc > 0; LiiRc--) {
        continue;
    }

    for (int kpJuj = 1217052911; kpJuj > 0; kpJuj--) {
        KvqEth = KvqEth;
        smcAHdhAGIEYd = smcAHdhAGIEYd;
    }

    return RYMQXalJWXOKB;
}

void KMGYJxHWhmXm::CKoGsiT(double TOGMtiSFSH, string nGxxvmD, double gKNYDuGiVZqZlhZT)
{
    double fTqsyMhYRJerIUpP = -962387.8533590854;
    int xWFdEHfwkeVo = -1127728002;
    string uSwWPnjj = string("CsbwzeWjnGPzFucQsCAIVoCrnxuiRBqUqERambwCojlqYvyryaxGPDbyiCEKwHpfniVLUljJbtlzAWVhIpbadXadieuYSgE");
    string ewZjPuxI = string("qmOkb");
    double UDGUaYJ = -14574.983748982319;
    string LrEtSiLbZRSHWOGk = string("KRhdmWajCnQYOUoosOUbXTtJKHOkAIzHOqDcvWDDBrVidYAgdIOfMqAqQeOZBNOnsPYCxjedZSFHQPAKvAvvSWArQLpeinyCKqdWvpJXHLkrNMdlEchDXHiuYPnoUBVPYoBvNpVYdYSAaDQZNxwMYzDxDVpPf");
    double LEcxsv = 540818.4210828209;
    string IwGXUaCvTEWq = string("PHOcYqPiD");
    double cjoblufANKnWj = -618839.4500071888;

    if (ewZjPuxI != string("tOSQEFrSZLcInrvfCjpHJiagaeQtyXlmAQaFgrkffjewwUcVtwiCubSrvTIDMTYVpavDiAdWXjNkIQsvcuEaQQMqLxOXFQDTMAvcSRRoCMFfvCqTInCgJkxENdcrtCGSohFGhiztZoLbOCjODpSJeWjMQwMQpRYZuGlhodmjMQKcaHUxnmFBiCXXqZCBGcSiceiyOaDmbFfUCoowAoaDFrUxQDjKDVbehhCmhaAWq")) {
        for (int eBMqCUps = 975088381; eBMqCUps > 0; eBMqCUps--) {
            IwGXUaCvTEWq = ewZjPuxI;
            LEcxsv /= LEcxsv;
        }
    }

    for (int SHplgNRKp = 1586276201; SHplgNRKp > 0; SHplgNRKp--) {
        LrEtSiLbZRSHWOGk = nGxxvmD;
        fTqsyMhYRJerIUpP *= UDGUaYJ;
    }

    for (int ifGmyFZiDw = 1993265678; ifGmyFZiDw > 0; ifGmyFZiDw--) {
        LEcxsv = UDGUaYJ;
        TOGMtiSFSH /= fTqsyMhYRJerIUpP;
    }
}

KMGYJxHWhmXm::KMGYJxHWhmXm()
{
    this->wSYQGLpaEEkbkYCR(string("TjXPFCQdczrXVnOxrVrEKgcsWlvlNeqiLqeGHGOEmJPpXzaRbnxxTLRhMcKnVjkQYb"), string("iVfnOMwatHdjifAPLcNLzNDsdKWvjuHrNhNxsoMoaHqSzjIKoeaCEreDJWnjtispZVUjbLKbowxSpanNQifmvDZqGvHwBDZGXvngqRqIMaOjpBesoUkvPEWsgLBiqZHJVNngvPoDHYeSSqgwkmrQRAcZxYoZREKkneiIZEDmclAnjWubBbhSJtcxSfjvwTnvljWISzZyuPDlMbfkCl"), 967450237, false);
    this->Zsyzuk(string("kqhtQFLwEAYVAtfRQTamFydozgwPpFYJUphLdnvqBznhYNlEHmMKGUnghJHwuNSDNFKdfcypIyTfSpDFfBZSVSzUgyciEoUiblpZZGtWZhdnLrCnXbYzstktkLdtybWLoCrqwgjiWmSCjwQpqJIdnxPayoNYVmifLLWrypyzzTIiVdQdaWbxHrxt"), false);
    this->TMmQXPeOus(string("MfgViKxwkNZTbCXFaYlNatntVzfaRzYCPzgUXWhPBAmdjiKcBaSHLVozHNxyUAMwdvgTfztTpCMpAWcwDFBqQwxJWJfqkzmdLcJJVnByVNxrEKeAGoEVtQRdOStISRkJlWaygWVCLXgLjolumoLeaaNrgLzwMKwRUOeDXNqNYIIqdwkyKbwyCJXHqusaAprgVGZiSSqdyGTUhTOjOdhHRisnOalbEUcEXxIfJFRhJDUREQaxYtxPsYIEowy"), 763550.7741833937, false);
    this->xWFBSLTDled(false);
    this->guEcCAoZFs();
    this->lxoFUZFRCfoig(true, -424412.5565405241, 451746652, false, string("fXwPASUBKQLyajKEMXEdcKoHAmAprWWVZVTvJBGIBONbpqNrmOOJBOtJGDFaiLAXpCeXUhmXfwQQiotvMNhtDwDXJHiCAnxSpLOLrrHUfBjsImbofVdxsspvDyQqoljyFRvGMaTQmGgCaIqfMLe"));
    this->jNdvxMdcQNkah(true);
    this->CKoGsiT(-487547.7884325, string("tOSQEFrSZLcInrvfCjpHJiagaeQtyXlmAQaFgrkffjewwUcVtwiCubSrvTIDMTYVpavDiAdWXjNkIQsvcuEaQQMqLxOXFQDTMAvcSRRoCMFfvCqTInCgJkxENdcrtCGSohFGhiztZoLbOCjODpSJeWjMQwMQpRYZuGlhodmjMQKcaHUxnmFBiCXXqZCBGcSiceiyOaDmbFfUCoowAoaDFrUxQDjKDVbehhCmhaAWq"), 969114.2173375494);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mfQYXyVzhApF
{
public:
    int vBUdzVnFItnTxM;

    mfQYXyVzhApF();
    bool PVikhfATKBih(bool lTGOMpkA, string GYDUpvVoRV, string LHVwOMqVZLv, bool vAvNMHedQKY);
protected:
    string jRIqCt;

    double FeGxkDbUbBI();
    bool gXXtlArHoDdVe(string hGfjyTGvvSVNYTm, double wMybRfPiIJsbadYC, int vciQgrqP);
private:
    double vHmxIAVqkpgNW;
    int ikrfAtC;
    bool PEVNeHUfTkClx;
    string wxGjeGYYyE;
    int uLomHffYdiUrCX;

    string FPqiQLEQzrdxJj();
};

bool mfQYXyVzhApF::PVikhfATKBih(bool lTGOMpkA, string GYDUpvVoRV, string LHVwOMqVZLv, bool vAvNMHedQKY)
{
    int pFfpQzFUPO = -529662498;
    double gpqnTaxXcVTnZm = 110466.6226261097;
    bool NQqtuAblJBlyeCq = false;
    int HTGAOa = 1123437486;
    double lqKjilTkL = -103317.92140966644;
    double vaSrHPUoj = 531006.4745198976;
    bool IFEXF = false;
    double jxqTREKh = -140882.1354089556;

    for (int lqRbb = 2137213185; lqRbb > 0; lqRbb--) {
        IFEXF = ! lTGOMpkA;
    }

    for (int iTBIuU = 1303262370; iTBIuU > 0; iTBIuU--) {
        vAvNMHedQKY = NQqtuAblJBlyeCq;
        IFEXF = ! IFEXF;
        pFfpQzFUPO = HTGAOa;
    }

    for (int jDbck = 1994696475; jDbck > 0; jDbck--) {
        NQqtuAblJBlyeCq = NQqtuAblJBlyeCq;
        GYDUpvVoRV = LHVwOMqVZLv;
        NQqtuAblJBlyeCq = lTGOMpkA;
    }

    for (int lYMIUOTpzlK = 1926216615; lYMIUOTpzlK > 0; lYMIUOTpzlK--) {
        IFEXF = ! IFEXF;
        lTGOMpkA = IFEXF;
        vaSrHPUoj -= jxqTREKh;
    }

    if (GYDUpvVoRV == string("dAQiBtkrjlIMDkTUM")) {
        for (int zmcHevss = 790199047; zmcHevss > 0; zmcHevss--) {
            gpqnTaxXcVTnZm *= lqKjilTkL;
        }
    }

    for (int Dagdlcc = 1409016603; Dagdlcc > 0; Dagdlcc--) {
        lqKjilTkL = jxqTREKh;
        IFEXF = lTGOMpkA;
        jxqTREKh -= gpqnTaxXcVTnZm;
        IFEXF = lTGOMpkA;
        lqKjilTkL += jxqTREKh;
        HTGAOa /= HTGAOa;
    }

    for (int mMkwrd = 2115281879; mMkwrd > 0; mMkwrd--) {
        LHVwOMqVZLv = LHVwOMqVZLv;
        IFEXF = lTGOMpkA;
    }

    return IFEXF;
}

double mfQYXyVzhApF::FeGxkDbUbBI()
{
    bool DamANzfDIe = true;
    double CODHUy = -957618.6362015039;

    if (DamANzfDIe == true) {
        for (int BllGALrfVBZ = 444395749; BllGALrfVBZ > 0; BllGALrfVBZ--) {
            DamANzfDIe = ! DamANzfDIe;
        }
    }

    return CODHUy;
}

bool mfQYXyVzhApF::gXXtlArHoDdVe(string hGfjyTGvvSVNYTm, double wMybRfPiIJsbadYC, int vciQgrqP)
{
    double mpqDkReI = -698275.7378640265;
    string uaiZN = string("WfZSXwCyOifUkJHPtMveDbCOAMLoZjJauYjWdJfstvlbFKlModChozSuXcLIaMlJtNcvsrTkzOSykomChpHNNDDhvrUlarVYQlwUnpjENLFFVdJewErkgKhBItVLWoHtChFqTcGybhGTMTdpOrXZdjLbWOVFpWGrJQTMCHEMSMoQonPOxPbcEZFVqpyUyzCaMlRiOXREBxbnXyTiqQkFHnKhCWFoEzXTaUSreTxmIuar");
    bool vbWsfNPx = false;
    double XLrThJePnNLcK = 423787.0271681007;
    double lySYvXhgCszUOLjo = 853466.9717544839;
    double NfDnZMA = -240046.55501519848;
    int JhuyBLtz = 2116293140;
    string NVjbU = string("InNerlOXNSvkvpoEvaxRFhheveoxextTeFlavniNaXryX");

    if (hGfjyTGvvSVNYTm <= string("WfZSXwCyOifUkJHPtMveDbCOAMLoZjJauYjWdJfstvlbFKlModChozSuXcLIaMlJtNcvsrTkzOSykomChpHNNDDhvrUlarVYQlwUnpjENLFFVdJewErkgKhBItVLWoHtChFqTcGybhGTMTdpOrXZdjLbWOVFpWGrJQTMCHEMSMoQonPOxPbcEZFVqpyUyzCaMlRiOXREBxbnXyTiqQkFHnKhCWFoEzXTaUSreTxmIuar")) {
        for (int pxTKJuyU = 1484619325; pxTKJuyU > 0; pxTKJuyU--) {
            lySYvXhgCszUOLjo -= XLrThJePnNLcK;
            vbWsfNPx = ! vbWsfNPx;
        }
    }

    for (int RgQrwRYdXZtr = 1887692551; RgQrwRYdXZtr > 0; RgQrwRYdXZtr--) {
        mpqDkReI /= wMybRfPiIJsbadYC;
        NfDnZMA += XLrThJePnNLcK;
        wMybRfPiIJsbadYC += XLrThJePnNLcK;
    }

    for (int BaFSBPaH = 1971206262; BaFSBPaH > 0; BaFSBPaH--) {
        mpqDkReI += XLrThJePnNLcK;
        wMybRfPiIJsbadYC -= XLrThJePnNLcK;
        wMybRfPiIJsbadYC *= wMybRfPiIJsbadYC;
    }

    for (int PkgskKVqhjEbs = 1170137231; PkgskKVqhjEbs > 0; PkgskKVqhjEbs--) {
        vciQgrqP -= vciQgrqP;
    }

    return vbWsfNPx;
}

string mfQYXyVzhApF::FPqiQLEQzrdxJj()
{
    string gANhARjhimRl = string("XpRbOPlFVadXGgfWBRPoMnowiJnbXqoBAyRlvFsJp");
    bool iityrqZIdRWJe = true;
    double oDTbT = -436503.7045056763;
    double Aeopur = -92031.0277946424;

    if (oDTbT > -436503.7045056763) {
        for (int OCfurFzlCWYP = 1834312194; OCfurFzlCWYP > 0; OCfurFzlCWYP--) {
            iityrqZIdRWJe = iityrqZIdRWJe;
        }
    }

    if (Aeopur > -436503.7045056763) {
        for (int MafJCKmvsyvoZOS = 1309518049; MafJCKmvsyvoZOS > 0; MafJCKmvsyvoZOS--) {
            oDTbT /= Aeopur;
            Aeopur += Aeopur;
            oDTbT /= Aeopur;
        }
    }

    if (oDTbT > -436503.7045056763) {
        for (int WlvoNViWJxpmiX = 429361067; WlvoNViWJxpmiX > 0; WlvoNViWJxpmiX--) {
            continue;
        }
    }

    return gANhARjhimRl;
}

mfQYXyVzhApF::mfQYXyVzhApF()
{
    this->PVikhfATKBih(true, string("KlUEVgsCrRhFQWlGbwBDoUiWPOLOvKJUjlyNEgSbSLQTnQpcMLoiwhFFhKvPHKCUAkxqPKFMjkMTIiUBRbFEZuSYdzEklrMJuAuBTttZvoQRmdLynOurqTWbBGjHsNLBlSWyGHGvjPFGibQlCqzOZdeDxkdkOOMjNtBNfRCkFxPPlFZNgfLTsQTkcNzJTPDIZVoKQJaWusnuPtbiYNCZor"), string("dAQiBtkrjlIMDkTUM"), false);
    this->FeGxkDbUbBI();
    this->gXXtlArHoDdVe(string("LgTcnavcUnUEUqikjsTozzZZiRLNHVOIcxBujMRWbeJgpQMsRieoEndvwGuMuwJkcxsqKwymFqPYVRU"), 572555.8449697928, -1548717755);
    this->FPqiQLEQzrdxJj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EfGbjGDxWH
{
public:
    int ucXKvTZjoU;
    double vsquPA;
    double yqAhRiSOgM;
    int JwiOMBDUnl;

    EfGbjGDxWH();
protected:
    double dkRjmiXnBZnZoFU;
    double IiBAGcrKyPrxc;

    double ckwuAM(bool tpTUPRBBAzohtb, string TJhGaZRu, bool JlBJjeVxeMlIGoVq, string KpcTh);
    double KwlkXMViKlnp(int QzAUNdYnhfyJ, int jxrow);
    string YTBBAlGNwTyR(string OWJvojWIocRzgpY, double MpfextEZwIgrvUuS, int UvTWqKowca);
private:
    bool SAdofQhwJS;
    int ceNzHfBP;

    bool ykFYqjBOCEbsHL(int XZDdZFEXtdCf);
    bool bWyKQmmBMRWrg(bool nAbPOR);
    string jKwCCLnVpdbS(double tzKpzdor, double WiDgNAbmM, int FLoJCyvuloyP, double kDkAhnWAuFGdZl);
    string rPCSbrtsdHTA(double JQvpnzT, int OMcqCT, bool bhDMYdPXEYLi);
    bool jULTZz(double kjKNRkW, string gXNeNTPPZvf, bool TJObBSoFVQrcqxz, double VKfhfNlYcn, string JnavvviWcMbZ);
    double xkuMSkMtKzwMkb(int IuqiGmJELuL, double zOkFulByYZOOMi, int AiFqiJGQ, int dDJcXsa);
    void mFmdyqTIzNemCR(int vudbyeWnA, int vkihrVKhBjXBwB, int XhtJmenefmvh, double GqLmYiW, int zpbrtB);
};

double EfGbjGDxWH::ckwuAM(bool tpTUPRBBAzohtb, string TJhGaZRu, bool JlBJjeVxeMlIGoVq, string KpcTh)
{
    int OqaGbMSlTghP = -874662868;
    string FVJxWjRBfNWCgg = string("AgtBmqSwwoGpkeHAjrQiqNqTjqCInQSWDoYYVyWJuapPpADCKzzzVxmULfipCHvOnDUhYhpzzsXErqUgYvIsXkEsBLCUaDQCCItZUAACaVvBIQbhCdpKkEBjUjgJlRcHKqiqdmYUybiViuGulNcjXBTBcJUxaPCPMDXGFMnkKJVGilMaSFKKnUBPgkYHpkxWrgzVBncKhvZSwxKoiqRJtOhZ");
    string vuinunZkLuTXCR = string("PGXTkqBJYssKDtFxFNFnwjApHtsRwpgZiDSgyYASvaluOfmqFJRGoMhDbxcZwBOBqChQDudfZPOVtOxDrhFfErbWKAcQDsTALgouwwdgIlHefXUJldNPMMiWhUxVLGvAoJleiGBSEBIkSiTjLtcmtxtkNOTurhlYVDdqnWborOQIrdiewjuKBBNMvw");
    bool pgnyj = false;
    string xhRDORvuQthLLodY = string("RgssIyvUGeLpJGcrtjGJmPeAbsdrDXkRbEpJPbNOmyBHTePbSgqewXocozuMILlKoIFhRygZSKiJrBsJZGCclYBincGMTBjhUwCbPegpmmmwJQnDBMUDcCpmN");
    bool CdthqGKqLW = true;
    double JoEQV = -558073.921838852;
    bool nHzbAkEIAf = true;
    int sVWicfXrxnsOhotC = 777230799;
    bool wmRlRjdFkFA = true;

    if (CdthqGKqLW != true) {
        for (int dlopTdZtELTL = 1740701795; dlopTdZtELTL > 0; dlopTdZtELTL--) {
            xhRDORvuQthLLodY = xhRDORvuQthLLodY;
        }
    }

    for (int tdZoGhjoHvbacz = 1232857447; tdZoGhjoHvbacz > 0; tdZoGhjoHvbacz--) {
        wmRlRjdFkFA = CdthqGKqLW;
        CdthqGKqLW = ! wmRlRjdFkFA;
        sVWicfXrxnsOhotC /= sVWicfXrxnsOhotC;
    }

    if (FVJxWjRBfNWCgg > string("PGXTkqBJYssKDtFxFNFnwjApHtsRwpgZiDSgyYASvaluOfmqFJRGoMhDbxcZwBOBqChQDudfZPOVtOxDrhFfErbWKAcQDsTALgouwwdgIlHefXUJldNPMMiWhUxVLGvAoJleiGBSEBIkSiTjLtcmtxtkNOTurhlYVDdqnWborOQIrdiewjuKBBNMvw")) {
        for (int sovvVtDPxkHC = 684888739; sovvVtDPxkHC > 0; sovvVtDPxkHC--) {
            tpTUPRBBAzohtb = pgnyj;
        }
    }

    for (int mVYzdhlMbGkxvbR = 427736755; mVYzdhlMbGkxvbR > 0; mVYzdhlMbGkxvbR--) {
        xhRDORvuQthLLodY += TJhGaZRu;
        tpTUPRBBAzohtb = ! wmRlRjdFkFA;
        wmRlRjdFkFA = CdthqGKqLW;
    }

    return JoEQV;
}

double EfGbjGDxWH::KwlkXMViKlnp(int QzAUNdYnhfyJ, int jxrow)
{
    bool TUzmWiawyZoJwQ = true;
    int FHoYFkHC = 586799003;
    bool Jgwzu = false;
    double mUhCBdlCkoJbPQ = 984799.628235356;
    double ryGnxwiGIosKmC = 351475.3011380795;

    if (mUhCBdlCkoJbPQ < 351475.3011380795) {
        for (int WwGViRmzjAhO = 2023800382; WwGViRmzjAhO > 0; WwGViRmzjAhO--) {
            jxrow /= jxrow;
        }
    }

    for (int mUBCWwqgsJGxx = 347464432; mUBCWwqgsJGxx > 0; mUBCWwqgsJGxx--) {
        jxrow -= jxrow;
        jxrow -= QzAUNdYnhfyJ;
        mUhCBdlCkoJbPQ -= ryGnxwiGIosKmC;
    }

    for (int abNXDdU = 1937520327; abNXDdU > 0; abNXDdU--) {
        continue;
    }

    for (int XrAUuCOb = 457423785; XrAUuCOb > 0; XrAUuCOb--) {
        continue;
    }

    for (int svDxGOyASvMLXwfL = 1064885782; svDxGOyASvMLXwfL > 0; svDxGOyASvMLXwfL--) {
        QzAUNdYnhfyJ /= jxrow;
        jxrow += FHoYFkHC;
        ryGnxwiGIosKmC *= ryGnxwiGIosKmC;
        Jgwzu = ! TUzmWiawyZoJwQ;
    }

    return ryGnxwiGIosKmC;
}

string EfGbjGDxWH::YTBBAlGNwTyR(string OWJvojWIocRzgpY, double MpfextEZwIgrvUuS, int UvTWqKowca)
{
    int wxEUKxCT = 1165781491;
    bool qviDpvZyiFqZdN = false;
    bool KzhhfVajwCnS = true;

    for (int IFygwdaFEr = 1340135708; IFygwdaFEr > 0; IFygwdaFEr--) {
        continue;
    }

    return OWJvojWIocRzgpY;
}

bool EfGbjGDxWH::ykFYqjBOCEbsHL(int XZDdZFEXtdCf)
{
    string hcMWKBnxCwoQi = string("EogMrlcTFzzcMcZZvzfHaSmhdhLYBzkRntjwXzKLqrJczvbmmalZjTklSpGLODLPMplffDhuJTPfQjoANJRFuLAonbnxqDjCayMFSwUGAKMEeXCMocnFmokwxLhdgVClvTrYEbyKv");
    int SNtGt = -683087858;
    string xebuq = string("ZVnjlplzquvRdAZQkxvvmWbBmmaBbeKXZzlvFnjUwHKiCWtEajpCmqUSHJmtokSTCgrEFHOdkFvcCHKGhSOotEEecOLKjUTxWYNOwPsdZmspQFYuqddDGeZBPEIbvGlqQKjbvXnCNFukOFogFtHiBpZfYAMeHSOpRGrePjbkruqOCjZjqiurMidworBmaYgBhaxDxDzQYLUAmamlFkCnXJpnkRSVgZtHKQgcktMgeExxGxPJAsiRYg");
    double LoyKrdwZIxx = 44192.64079553773;
    double AsmpEjfZFsMWGQ = 721505.7323780832;

    if (SNtGt == 673052701) {
        for (int TXHonsEPHQNDeQeM = 1628593926; TXHonsEPHQNDeQeM > 0; TXHonsEPHQNDeQeM--) {
            hcMWKBnxCwoQi += xebuq;
            XZDdZFEXtdCf /= SNtGt;
            xebuq += hcMWKBnxCwoQi;
            hcMWKBnxCwoQi = hcMWKBnxCwoQi;
        }
    }

    return false;
}

bool EfGbjGDxWH::bWyKQmmBMRWrg(bool nAbPOR)
{
    bool bJLwo = false;
    double irzZPRyiFyU = -128870.89278002878;
    string SSNydXpJ = string("ZnCePpRvQkAnPxbZWFNEjLQayYLQXogppGWRpgdZgvqgdnjnaahjzgENzLYcsuUTPuPKKJTLPDBfqpYbltnVZaGaeRNmZWtYHOINxFiHZYyCWJfGtziLMNsmGzUGFvoPZrspDKtvMmGFSeVyUkvmEzIOavvuMWiDnJKtxZPXzQqNMjNerGfkXxSkqPdNncRPZqQ");
    int pdfoWvToDimKPeIW = 971482626;
    double QdagTXLWOLfwuxm = -390936.7994211277;
    bool XkbhX = true;
    string zWwqBYShFqOAQJzm = string("NKBgChtfXrnXlmroUiaLRmarfxIueHkAjbLyilAYiXWBsPNLOyWKighmGObCIHLfPkecEzMRwspohVi");
    double dYmLKSeFrTz = -195059.17329553454;

    return XkbhX;
}

string EfGbjGDxWH::jKwCCLnVpdbS(double tzKpzdor, double WiDgNAbmM, int FLoJCyvuloyP, double kDkAhnWAuFGdZl)
{
    string RoskRqncAtw = string("qBZlLQpTRGVPOMmRZeQogfFlOGtdpGqdyNTkLissrILixTrgooLjOtGNJdYFmIZhQtplGwlwBnKnIsNlK");

    if (FLoJCyvuloyP > -1587473132) {
        for (int stSFSxljA = 589327188; stSFSxljA > 0; stSFSxljA--) {
            kDkAhnWAuFGdZl += kDkAhnWAuFGdZl;
            FLoJCyvuloyP *= FLoJCyvuloyP;
            kDkAhnWAuFGdZl += kDkAhnWAuFGdZl;
            kDkAhnWAuFGdZl /= WiDgNAbmM;
        }
    }

    if (kDkAhnWAuFGdZl >= 133722.23247556205) {
        for (int CcTcRifGqOLexf = 1013954803; CcTcRifGqOLexf > 0; CcTcRifGqOLexf--) {
            WiDgNAbmM *= kDkAhnWAuFGdZl;
            tzKpzdor /= tzKpzdor;
            kDkAhnWAuFGdZl -= kDkAhnWAuFGdZl;
            WiDgNAbmM *= WiDgNAbmM;
        }
    }

    if (FLoJCyvuloyP != -1587473132) {
        for (int oYCnxxafh = 963585979; oYCnxxafh > 0; oYCnxxafh--) {
            continue;
        }
    }

    if (tzKpzdor <= -992721.4256375127) {
        for (int EwyMDs = 2015723413; EwyMDs > 0; EwyMDs--) {
            tzKpzdor -= tzKpzdor;
            tzKpzdor *= tzKpzdor;
            FLoJCyvuloyP *= FLoJCyvuloyP;
            tzKpzdor *= tzKpzdor;
            tzKpzdor *= WiDgNAbmM;
        }
    }

    for (int EzrZJJcQkciWIIZ = 2009811147; EzrZJJcQkciWIIZ > 0; EzrZJJcQkciWIIZ--) {
        kDkAhnWAuFGdZl += WiDgNAbmM;
        RoskRqncAtw = RoskRqncAtw;
        kDkAhnWAuFGdZl -= WiDgNAbmM;
    }

    for (int TlVuKhYIoNf = 1268853798; TlVuKhYIoNf > 0; TlVuKhYIoNf--) {
        RoskRqncAtw = RoskRqncAtw;
    }

    for (int uztzWrnmtEMS = 172918388; uztzWrnmtEMS > 0; uztzWrnmtEMS--) {
        tzKpzdor *= WiDgNAbmM;
        FLoJCyvuloyP += FLoJCyvuloyP;
        WiDgNAbmM = WiDgNAbmM;
    }

    for (int KxaBYFh = 1645962404; KxaBYFh > 0; KxaBYFh--) {
        kDkAhnWAuFGdZl = tzKpzdor;
        tzKpzdor -= WiDgNAbmM;
    }

    return RoskRqncAtw;
}

string EfGbjGDxWH::rPCSbrtsdHTA(double JQvpnzT, int OMcqCT, bool bhDMYdPXEYLi)
{
    double TacJrgqNw = 946530.60752981;
    int bLEUpRuzbm = 27350312;

    for (int CHmXSPEzPXt = 1665943132; CHmXSPEzPXt > 0; CHmXSPEzPXt--) {
        JQvpnzT += TacJrgqNw;
    }

    for (int rUsGyBSyAdlT = 1886748421; rUsGyBSyAdlT > 0; rUsGyBSyAdlT--) {
        JQvpnzT = JQvpnzT;
        bhDMYdPXEYLi = ! bhDMYdPXEYLi;
        JQvpnzT /= TacJrgqNw;
        bLEUpRuzbm = bLEUpRuzbm;
        JQvpnzT += TacJrgqNw;
    }

    return string("YHDCjVGrZFadNEaCSTWncBdqjRSsuyTEPVfAigdrxApeeXcTXlPwQzhsbJmqfpuPCebjKuAaVsfLtCyUpEtsTYaabahfgCVGVQvlXndPxMWXHIMkuJwWXkODxGYvIUBStiKcwEVkKfO");
}

bool EfGbjGDxWH::jULTZz(double kjKNRkW, string gXNeNTPPZvf, bool TJObBSoFVQrcqxz, double VKfhfNlYcn, string JnavvviWcMbZ)
{
    double sEExuoQb = 304603.1645761504;
    bool wWYwHuSq = false;

    if (TJObBSoFVQrcqxz != false) {
        for (int oxGkldsRpOAQIIqk = 601665055; oxGkldsRpOAQIIqk > 0; oxGkldsRpOAQIIqk--) {
            gXNeNTPPZvf = gXNeNTPPZvf;
            kjKNRkW *= VKfhfNlYcn;
            TJObBSoFVQrcqxz = ! wWYwHuSq;
            VKfhfNlYcn /= sEExuoQb;
        }
    }

    for (int ecrRgGpDRrbPbR = 1141442709; ecrRgGpDRrbPbR > 0; ecrRgGpDRrbPbR--) {
        continue;
    }

    for (int LrlvryqWiLEEZ = 39560391; LrlvryqWiLEEZ > 0; LrlvryqWiLEEZ--) {
        VKfhfNlYcn += VKfhfNlYcn;
        VKfhfNlYcn -= VKfhfNlYcn;
        gXNeNTPPZvf = gXNeNTPPZvf;
        gXNeNTPPZvf = gXNeNTPPZvf;
        kjKNRkW *= kjKNRkW;
        wWYwHuSq = ! TJObBSoFVQrcqxz;
    }

    if (wWYwHuSq == true) {
        for (int UIzHJBQefRUiOGL = 1127288055; UIzHJBQefRUiOGL > 0; UIzHJBQefRUiOGL--) {
            kjKNRkW += VKfhfNlYcn;
            TJObBSoFVQrcqxz = wWYwHuSq;
        }
    }

    return wWYwHuSq;
}

double EfGbjGDxWH::xkuMSkMtKzwMkb(int IuqiGmJELuL, double zOkFulByYZOOMi, int AiFqiJGQ, int dDJcXsa)
{
    string WhGsrPeIVU = string("IrZKGnNgWMCAOCVxUSMZwNjnVvpmAKACrifNkinQQtiCsYfhQAAYVsZioOMgayTuUNaqBITzY");
    double nHJPUo = 988065.049940611;
    double glBjjzvuPVvA = 856749.3851119097;
    int YfreoquYPytcV = 1793844114;
    int PWrnh = -335341184;
    string Jkkbp = string("PSOzAXiQlRJzpKeOKlSYXjOIPECnJXkWVvi");
    double lADONbL = -478460.8602365402;
    bool gKpEH = true;

    for (int veOghnrflsysAE = 641196133; veOghnrflsysAE > 0; veOghnrflsysAE--) {
        glBjjzvuPVvA += glBjjzvuPVvA;
        IuqiGmJELuL += PWrnh;
        nHJPUo *= glBjjzvuPVvA;
        IuqiGmJELuL += IuqiGmJELuL;
    }

    return lADONbL;
}

void EfGbjGDxWH::mFmdyqTIzNemCR(int vudbyeWnA, int vkihrVKhBjXBwB, int XhtJmenefmvh, double GqLmYiW, int zpbrtB)
{
    double zIJWpappq = 535084.4732409185;
    int SjTDwwnB = 1543775172;
    string cxgaYAOy = string("qoiYEAxZDBCvVjGBKEqWnJUvudgbWkrzHEjQfNAoZpxOlcMdhSgWQTqUzHvNwEGIwjSiYbpbhMZcIeCsekMWcBBYzpCQfoooYxFyzrkyDueFpNLAbuuOh");
    bool FTCIoWa = false;
    bool WOCrzNlRiTg = true;
    string RTwSxskvdtex = string("ER");
    double gvrojzRCIAigs = 29616.53037614001;
    double LCoeP = -544409.6580308364;
    double gJnSVOYuXmSzJO = -877105.8183241448;
    bool DQnwgbFMFsChcCU = true;

    if (GqLmYiW < 535084.4732409185) {
        for (int KZdmlASXdpqhbXCK = 1295301844; KZdmlASXdpqhbXCK > 0; KZdmlASXdpqhbXCK--) {
            zpbrtB /= SjTDwwnB;
        }
    }

    for (int NybbooQKgkvEzXe = 1601545154; NybbooQKgkvEzXe > 0; NybbooQKgkvEzXe--) {
        FTCIoWa = ! WOCrzNlRiTg;
        SjTDwwnB += vkihrVKhBjXBwB;
        cxgaYAOy = cxgaYAOy;
        LCoeP /= GqLmYiW;
    }
}

EfGbjGDxWH::EfGbjGDxWH()
{
    this->ckwuAM(false, string("MLPsPtkNBlrqlTQJkdHatljnDznlSBmIkcQxhFvLmTBzyTLAaqIeiBLHHQmgYnsSealrWGpzturPSpPjGTvJSlOFtUBIECmyWVfbqxEqqsolPJHmMRMePHhYtwAhjEbJJtycVfgdCdZNDBpVbkBBdbysFrCMmHyZhDgewqnsnKnKNrXhZUCTFJhsUAWlWXukxiHDgPpgECBkNTaWdszTzsu"), false, string("oVnAVafgxxaSDwbFmSOzgoAVitrzVPyvwXPBjirvzDiWyzCIpfBG"));
    this->KwlkXMViKlnp(-1608221737, 1386087617);
    this->YTBBAlGNwTyR(string("JySDdgOrwlBswmksralzguVwCMEcqlySjAPAvpHUyemIBOqQPOGIYMfxZZPyTGGLgHPnMWlrvTdkJTFMDJDvVbIzHIpkfhOktjfpHAaKFYeqgCMnToBkYDOUNmTBNtohQrjIVxcZWglMUvBGxJioG"), 702849.3259862248, 1800887512);
    this->ykFYqjBOCEbsHL(673052701);
    this->bWyKQmmBMRWrg(true);
    this->jKwCCLnVpdbS(-992721.4256375127, 552677.1537782267, -1587473132, 133722.23247556205);
    this->rPCSbrtsdHTA(912047.0541528201, 911120460, true);
    this->jULTZz(-1027861.6183808175, string("iOQHmndIlQyzdcbkQexbCXEBsAfwcxnb"), true, -759474.2233444654, string("iHDLVdkGeeiQPTycwAeiZvFteiJdvArNKfgPXUoxHKmGIjntoFPHbAZEzyLfetcbEkDXJXzpVYkeMKehbrOdoHLbSoGbsktaixlrTmSJEBvfCkHrPBpTFM"));
    this->xkuMSkMtKzwMkb(-2055805422, 516912.0766672123, -1871985520, -2022119415);
    this->mFmdyqTIzNemCR(-466804800, -150318203, -247975126, -269458.3408126999, -1386086764);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cnPHbzFJW
{
public:
    string XqEFmdjCVmYqrD;
    int gAnOHwtVE;
    string QdkIeJZMGM;
    bool EmeEs;

    cnPHbzFJW();
protected:
    double TrPSAcvzsa;
    int EMTTbbk;

    string HAfqEoxBAiKhab();
    void UcFgPPJiyJhqi(string CnEPhFckT);
    string ApxpwhFRJhMiVq(string SQqNcZgdyl, bool qtuLyYLtKrHqInk, string iLJueEfmWwTAibC, string NblsjFWutEuPK, double ZIcVNEjTx);
private:
    bool SNagGewEPXGARbbK;
    int HLFyVORwBxP;
    double sMDPguc;
    bool xhOAIp;

};

string cnPHbzFJW::HAfqEoxBAiKhab()
{
    int aficptxWa = -1325194099;
    string ppiuGK = string("irsbDJfWGWakR");
    bool faHKzkz = true;

    for (int JdOBPRZhbf = 1702890638; JdOBPRZhbf > 0; JdOBPRZhbf--) {
        continue;
    }

    if (aficptxWa < -1325194099) {
        for (int fkxUYnePqnsx = 1319901660; fkxUYnePqnsx > 0; fkxUYnePqnsx--) {
            continue;
        }
    }

    return ppiuGK;
}

void cnPHbzFJW::UcFgPPJiyJhqi(string CnEPhFckT)
{
    string NoGeYMEJxIsQrD = string("lXFOZRRiWsLiyFyOmRYTwa");
    string vDqcZCcICKQDur = string("SUmzHeliOhfxVJxmHCPbLucKjeUIqrpiDAbzrVWSMfTUZCgOFlcCQqRneWLwzTGEcqtOkaKCHgVDduXDDolBVwiwcoNVryzRJlEsLUBeDSBVQybfGlsdaFcwyTrXzyynqRjRrdUFpXMUuCYQKKJyhjDQjltoUGKqdsO");
    bool eGrMiYbrGA = false;
    double fEAsoEzza = -687273.4098929678;

    if (NoGeYMEJxIsQrD == string("pFbUCexxBkGtCeIGaUYBExwdLkcmIwyYyQjlRaMrFiPtUeNUUjCIgoJsecAJufdhIfspWEPUWjVmqRgAMDjYwuzNZrjiuRsTERVUWmoDoChGVMrdLTEUrrsmmsGlLBiKydPtRrXEIciwSFTtBGpJlRVbYjyBVYwUmaetdbxyqxqKAyKHNNXeaiixQCVZFJrNAvBNRBCePCUpmaHZsWHGVhtZXwRQXfD")) {
        for (int fkswO = 2126995376; fkswO > 0; fkswO--) {
            vDqcZCcICKQDur += NoGeYMEJxIsQrD;
            vDqcZCcICKQDur = NoGeYMEJxIsQrD;
            CnEPhFckT += NoGeYMEJxIsQrD;
        }
    }

    for (int XZcvjJ = 639081240; XZcvjJ > 0; XZcvjJ--) {
        NoGeYMEJxIsQrD += CnEPhFckT;
        eGrMiYbrGA = ! eGrMiYbrGA;
        vDqcZCcICKQDur += vDqcZCcICKQDur;
        NoGeYMEJxIsQrD = CnEPhFckT;
        CnEPhFckT = CnEPhFckT;
    }

    for (int CASXYcHR = 799086902; CASXYcHR > 0; CASXYcHR--) {
        NoGeYMEJxIsQrD = NoGeYMEJxIsQrD;
        CnEPhFckT = NoGeYMEJxIsQrD;
        vDqcZCcICKQDur += vDqcZCcICKQDur;
        NoGeYMEJxIsQrD += CnEPhFckT;
    }

    if (NoGeYMEJxIsQrD != string("SUmzHeliOhfxVJxmHCPbLucKjeUIqrpiDAbzrVWSMfTUZCgOFlcCQqRneWLwzTGEcqtOkaKCHgVDduXDDolBVwiwcoNVryzRJlEsLUBeDSBVQybfGlsdaFcwyTrXzyynqRjRrdUFpXMUuCYQKKJyhjDQjltoUGKqdsO")) {
        for (int DCIijRaU = 1868665894; DCIijRaU > 0; DCIijRaU--) {
            CnEPhFckT = NoGeYMEJxIsQrD;
        }
    }

    for (int AWRXqLuhqOGD = 1723489321; AWRXqLuhqOGD > 0; AWRXqLuhqOGD--) {
        continue;
    }

    for (int ropaXbqwbyCF = 1434257508; ropaXbqwbyCF > 0; ropaXbqwbyCF--) {
        CnEPhFckT = NoGeYMEJxIsQrD;
        fEAsoEzza += fEAsoEzza;
    }
}

string cnPHbzFJW::ApxpwhFRJhMiVq(string SQqNcZgdyl, bool qtuLyYLtKrHqInk, string iLJueEfmWwTAibC, string NblsjFWutEuPK, double ZIcVNEjTx)
{
    string dXvJHjpyyS = string("NbYqoAAoqfisyPKesvlWneqrjKlsuuZcoveFCFkgaYTjJLiLRYeHOLrMqmzWFHkKYYbUEIUlDpwdlYzalMhjrXnKJemZzuskUuAVXRXZwcrMsndhVbpHKYAGvOqujWMgaSKunlaFDfgMfkKW");
    bool KzOtnIaRCCnH = true;
    double fqhZpIZIBMZZBgN = 595276.6794842024;
    string XUYpOvATx = string("TlwDmFdmxWkowTUnyDJWXMvogLQFvlFfFZWjmYiIvDIdRDezcplvlxaRQQdKJGWMENSiyxWoasMiFQFzQSidspRKEjUezlubkjxIpsyAwywFaxNpCMFXTaLNBkJiVmQpubnReLyzJGPenwAWj");
    bool oqaGNtQMv = false;
    double BWIZQWBuYHOqfJg = -232236.94285433838;

    for (int RMaaTBnrkuybm = 1189000595; RMaaTBnrkuybm > 0; RMaaTBnrkuybm--) {
        XUYpOvATx = iLJueEfmWwTAibC;
        dXvJHjpyyS = iLJueEfmWwTAibC;
        NblsjFWutEuPK += XUYpOvATx;
        NblsjFWutEuPK += iLJueEfmWwTAibC;
        SQqNcZgdyl += XUYpOvATx;
    }

    return XUYpOvATx;
}

cnPHbzFJW::cnPHbzFJW()
{
    this->HAfqEoxBAiKhab();
    this->UcFgPPJiyJhqi(string("pFbUCexxBkGtCeIGaUYBExwdLkcmIwyYyQjlRaMrFiPtUeNUUjCIgoJsecAJufdhIfspWEPUWjVmqRgAMDjYwuzNZrjiuRsTERVUWmoDoChGVMrdLTEUrrsmmsGlLBiKydPtRrXEIciwSFTtBGpJlRVbYjyBVYwUmaetdbxyqxqKAyKHNNXeaiixQCVZFJrNAvBNRBCePCUpmaHZsWHGVhtZXwRQXfD"));
    this->ApxpwhFRJhMiVq(string("KAwVBwdsYxwYbtWOMNBWPTSPhyimXvJVuPcLxRdndJcyXOeVOcWbWJvnTTJPnuYDmigRtPGhtupijMdHBZFQjUHqcjCmsBlUpuPGRohNPsoREvTWrajUFmpViSDVTpsErlyqjkFIxmHPZYQdYRPpcFmpysRyJpnFEAOJleyMlRygdtalKgUKFSSmqAJyjlDZEyhpsUYIPTwEqKfsNwjqHqrMToByDsOPIITj"), false, string("JDhVQQbAsIGMXAVtiOKNcvrgeSJmWOjpympYuRhpLCrUwYIAIZklRJzgFnyyVMutxmxFAVkmUjmQJxqaatBHuHRAsqhViZsCR"), string("wvGrUT"), 948155.5911816367);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JqdAWYrDm
{
public:
    double GJaSDIFZDlKM;
    string cULOMESBRhjbHGRg;
    string yCMQfZKlJA;
    string WWBakLNSqORmeGs;
    int IURaWLxCPaKd;
    bool HcOTa;

    JqdAWYrDm();
    void AhYOEWEPRjMuVcc(bool xrTICnGuSd, bool WexnUrICIkNoa, bool rQQeSgsbykt, string kRsFPNUXzGC);
    bool lJIDrDek(int iUhdeNJuDQO, bool yjOqftPvEHOJQd, bool rhyHroGSk);
    string FaRpnJSUlBXHUD(string sJNoJUb, double SRQUNtVsSuRt, string nNSYElP, string OQRcQDTXT);
    bool voOcBMDjMOce(double pHUliSBvJooVt);
    double leVICbdjsE(int KrIAfxdWtOsrmLHt, bool eVepXhvODfEQwlMx);
    void QwghthYxX();
protected:
    string rHRkI;
    bool wLlvA;
    string zcmCACsS;

    bool lIuoasy(double SrbbupvDU, int nNfVKEKTghNvUcf, int dpUFDuND, double GZVacgBbjof);
    void eooaUymlROTu(bool kaRIuISjnuOaNM);
    void yagZirNUaJvfGh(double EmTxCpBqwKBS, bool pZXgTfPDsuVfixYY, string nYEAjcAMNQq);
    void xCEWqSjsMfCXxC(int MVcOhQiPuRUQ);
    string LiglGzwOq(int GsgIbHpysUfsr, double lyIAZey, int JUpCecw, string hfpsWkJixhdUslwO, bool aNmCSIGmHzX);
    void KveKyTCMao();
private:
    double zlTMwiFMVz;
    double NeBluodXNeqWiz;
    bool WthkHZjGgUMKNo;
    bool ldFhHPmHu;

    double HSSbyILEaV(double gqWxBHLlqSpFUBj, string JxdzdfyIbc, string YPqEsPH, int FIwDvxiOI);
    string tGNgEjCfASp(int EiJfDBijPiPxYx, bool gYlTzcmskhgzjfTI, string klLviMVGsPAZkcD, double WEuIDITDqWPYs, bool ChxPXNBhtrCQ);
};

void JqdAWYrDm::AhYOEWEPRjMuVcc(bool xrTICnGuSd, bool WexnUrICIkNoa, bool rQQeSgsbykt, string kRsFPNUXzGC)
{
    bool mRXLTWIy = true;
    int yeHVtM = 147119607;

    if (mRXLTWIy != true) {
        for (int lPJFvLMKHzAv = 1324894548; lPJFvLMKHzAv > 0; lPJFvLMKHzAv--) {
            yeHVtM *= yeHVtM;
            mRXLTWIy = rQQeSgsbykt;
            WexnUrICIkNoa = rQQeSgsbykt;
            rQQeSgsbykt = mRXLTWIy;
        }
    }

    if (WexnUrICIkNoa != true) {
        for (int vIwIQCrYw = 1881023349; vIwIQCrYw > 0; vIwIQCrYw--) {
            continue;
        }
    }

    if (xrTICnGuSd != true) {
        for (int oUKAl = 1352479726; oUKAl > 0; oUKAl--) {
            WexnUrICIkNoa = WexnUrICIkNoa;
            xrTICnGuSd = WexnUrICIkNoa;
            kRsFPNUXzGC += kRsFPNUXzGC;
            WexnUrICIkNoa = mRXLTWIy;
        }
    }

    for (int ElYhzgk = 122139051; ElYhzgk > 0; ElYhzgk--) {
        rQQeSgsbykt = ! rQQeSgsbykt;
        xrTICnGuSd = ! WexnUrICIkNoa;
        mRXLTWIy = xrTICnGuSd;
    }
}

bool JqdAWYrDm::lJIDrDek(int iUhdeNJuDQO, bool yjOqftPvEHOJQd, bool rhyHroGSk)
{
    double PTtRaMJikQEcAG = 592953.684994366;
    bool jAWqRlv = true;
    int nnApjGLKteJTKv = -504219745;
    string HzhbGHPw = string("aOQYPAKVASbLKkJVTjeHYRFaEgDCwnevRWuizCnJgIiHSwZLsUNxNjtPfQAHLJTWQVIhX");
    int WwJvWUMZ = 474769571;
    double pBfOTVbbvIUYIkKD = 676333.7449192065;
    string iAvzuHzILajNa = string("ZLTytlruzmCZHTdkpYRYpdPuVLMecukZyQAQowsUKmviCkbwLTqqwsMraINjXEIbOxKiDfMNMfdSgaANxdxQ");
    string ZjLGbtWQk = string("rtmznmZqNNHpiiXADWPjPgmUEPKBNorHqgvSkapxJTnxMmRHNQJzcMTbRzpaLYxHVBVZktBDQMIcpOmyQgbYKuQspiiWQErENBVVfxJiUAjUNrJvhPxQRfHzrivbeHQfGWCRquFkh");

    for (int eHxrmR = 725997859; eHxrmR > 0; eHxrmR--) {
        continue;
    }

    return jAWqRlv;
}

string JqdAWYrDm::FaRpnJSUlBXHUD(string sJNoJUb, double SRQUNtVsSuRt, string nNSYElP, string OQRcQDTXT)
{
    int LIyyoRWg = 1775209691;
    int EevJnwhJALBG = -1081623923;
    double LOFhIlSYOvbMKw = 201453.41467837273;
    double eGMzELaxZnjaKQk = -662923.9886448778;
    string QLewvYQrMRVZjGIn = string("RYzZdehPpprehfGUjhvVTfisyXYjnukFKXdtVhkkLeDqUayBbSkCRKhbBictrOPBVrUCYfYEAuDeDeBZdpBowrcOGtYjKircFYMMjsgiePZpTMAzwkOvcXclSSGkLnsIbLNuzdvPEzXPzrvghxdbOclmGrzJfUfVAxbTOPgPWGDtLufpwYlxFmcsnjZtyrAbaLRygXQtHNYBntEZQVzmiyANHL");
    int yrEcVkGSNGS = -14913718;
    double hKwczq = -890428.9219153094;
    int SCOsgZjoy = -1018318401;
    int rTinyGTArf = 574165447;
    bool RIlVbiMlpTCukL = false;

    for (int AfQfqaTZplDG = 687664465; AfQfqaTZplDG > 0; AfQfqaTZplDG--) {
        LOFhIlSYOvbMKw += hKwczq;
    }

    return QLewvYQrMRVZjGIn;
}

bool JqdAWYrDm::voOcBMDjMOce(double pHUliSBvJooVt)
{
    double dpGJlaxJyoMuq = 301553.2703001318;
    string idRGPJI = string("eGRVFKxeJYAlpsfOGxFMcXTwiLqSEbyhdyNwvrpJszpfptCsMRSQehLuYPIhoGlEScCPJUK");
    string RxWYtNJ = string("gzebCiuXDLhrARIFGrTNtIdUnsBbRDgtMjfAZLJFwVUTMPFzBUvHZntmBTqpuPoVlLjUooqxjQeggEgVwxMViTqPxOrGAzpYDlZAliIQbswQQRuLsqqOepTkZiwMOHSCzQfLZZTYHFQgiHRqSTUPMMKyztgXEXixDHJYhLiymMhKocXViQRFyTrmqiYcTPMQydftbhIbsZrKzciQFPKtYKEwutRhwESnweuqQyYMDIzmNcQcHZw");
    bool IYDKZWb = true;

    for (int oqYoieHfdpiLgrd = 1137878967; oqYoieHfdpiLgrd > 0; oqYoieHfdpiLgrd--) {
        pHUliSBvJooVt -= pHUliSBvJooVt;
        idRGPJI += idRGPJI;
        pHUliSBvJooVt *= dpGJlaxJyoMuq;
        pHUliSBvJooVt += dpGJlaxJyoMuq;
        pHUliSBvJooVt *= dpGJlaxJyoMuq;
    }

    if (dpGJlaxJyoMuq >= 301553.2703001318) {
        for (int UXedAukgSS = 1938154489; UXedAukgSS > 0; UXedAukgSS--) {
            continue;
        }
    }

    if (RxWYtNJ != string("gzebCiuXDLhrARIFGrTNtIdUnsBbRDgtMjfAZLJFwVUTMPFzBUvHZntmBTqpuPoVlLjUooqxjQeggEgVwxMViTqPxOrGAzpYDlZAliIQbswQQRuLsqqOepTkZiwMOHSCzQfLZZTYHFQgiHRqSTUPMMKyztgXEXixDHJYhLiymMhKocXViQRFyTrmqiYcTPMQydftbhIbsZrKzciQFPKtYKEwutRhwESnweuqQyYMDIzmNcQcHZw")) {
        for (int zvgwBlOrbdfrI = 869222983; zvgwBlOrbdfrI > 0; zvgwBlOrbdfrI--) {
            continue;
        }
    }

    if (pHUliSBvJooVt <= 301553.2703001318) {
        for (int OxjwVkxtNPlb = 33634680; OxjwVkxtNPlb > 0; OxjwVkxtNPlb--) {
            continue;
        }
    }

    return IYDKZWb;
}

double JqdAWYrDm::leVICbdjsE(int KrIAfxdWtOsrmLHt, bool eVepXhvODfEQwlMx)
{
    int WtFFbFBICXtwTVlm = -228512594;
    int DqknnUnxJABuu = -183742283;
    int DhMPooqceZtQL = 68305626;
    string veUBAzTOajwREDc = string("aoBOHLRsupumUxvqGzmwcspVRMUHEKuFGBHsYruhfxiqzpbaRrqbhdADDAjaSfERRtDbmHlnmvsxlzCRpzunyZPQJUVapGTadOVdobDHRGTGXsnnTHWoLIhtDvuzTRgNMedoYSBwRXKqhUNYYhcDNznXAFkjzEIfLJGuNXADKNXBiweUEjtucpTJqibkqbzsmmsIoHwUmQJYHCemgtyYqUbsEtOuPRnwFYhoBZlmoaDUAuHmiarNzB");
    double QvPHMBXuYfu = -764521.1871628732;
    int cnJNkBUTxf = -1900620829;
    int PgJniZ = -791505442;

    if (KrIAfxdWtOsrmLHt == -1430458244) {
        for (int vpdXHAYd = 275407946; vpdXHAYd > 0; vpdXHAYd--) {
            cnJNkBUTxf *= WtFFbFBICXtwTVlm;
            WtFFbFBICXtwTVlm = KrIAfxdWtOsrmLHt;
        }
    }

    return QvPHMBXuYfu;
}

void JqdAWYrDm::QwghthYxX()
{
    string pEUZQglCligqe = string("VUlWhlXRivLJkUaxvNUjXKYErdNlxqYVAYHwotLYzAyvSbsVCWqAIJLKjFkRfbONTxlAAepQcJYvsNBJE");
    int UtFiihqQpQCH = -2106386822;
    double WCKFXwYXHOYgoaWW = 966030.0035267061;
    double RarsvDJv = 729723.9417201973;
    bool JVjoAtfIYpC = true;

    if (UtFiihqQpQCH >= -2106386822) {
        for (int gKedSwaIick = 787019667; gKedSwaIick > 0; gKedSwaIick--) {
            RarsvDJv *= WCKFXwYXHOYgoaWW;
        }
    }

    for (int DGFChwj = 650088303; DGFChwj > 0; DGFChwj--) {
        UtFiihqQpQCH = UtFiihqQpQCH;
    }
}

bool JqdAWYrDm::lIuoasy(double SrbbupvDU, int nNfVKEKTghNvUcf, int dpUFDuND, double GZVacgBbjof)
{
    bool jhiicGDExRInb = false;
    string LiMhBkda = string("vsmcCYHWgbtZzqEaiPJxMbdNIuiNKZDPcAGpdYLSfiyudGFYPWHmssmAydKpvueKKoaeNnmkAjeAnvgCAacLfsfCaTegYehGqVrCsSLpWuIiUIuPOKWdnhOyYaxVpjcjPGHKUZR");
    double WWafsTQDCeMYhL = -623768.1032162026;
    bool ZidOl = false;
    string GmwNeO = string("kugJuBVSxIIENvgUIIFofbEXyDfZDzqkbtkNGuSBrPfjyczWJWuvbZXFoblaDRxtWcHKNoeggWysyxjxkCiaQLAnlzTddVCsjjhdNmskwEkMdjxYvGXpGLTWHJOFxDpqUysKLrxEwyYlMCChCQndHKzwbvodUVdjOKQQBZgQeSsfjtyiVLqur");
    int kTaXzUomnpeYO = 1029559797;
    bool SNJYKSwEEFkNtMD = false;
    string SzbClypbNqPhXq = string("UUIADEFPUIkAFyIdhEHVfJcpgQUpdiBQcbDALPnaiUKSLqRHNIqCokeTSxUSzwmEoGRbMLDEeIeFEblWuXtgiMkksjiFjXVMUqLzalURZwNSPBXomvVEeykljvgzpChFdeeljlulVTFtGgxVSknzqoLrZSszALyFMBFoBuzZpQXnkkKqFOyFIAALmnafCvplNKqpgFUVwwcqfMfXahGjduSfSGsJ");
    double rpRVkNFSbX = 135388.96620306393;

    for (int OSoZaKWuU = 436835393; OSoZaKWuU > 0; OSoZaKWuU--) {
        SrbbupvDU *= WWafsTQDCeMYhL;
    }

    for (int KzdchvUSxMRlDo = 1170045096; KzdchvUSxMRlDo > 0; KzdchvUSxMRlDo--) {
        jhiicGDExRInb = jhiicGDExRInb;
        WWafsTQDCeMYhL /= WWafsTQDCeMYhL;
    }

    return SNJYKSwEEFkNtMD;
}

void JqdAWYrDm::eooaUymlROTu(bool kaRIuISjnuOaNM)
{
    double ibRLNQEZVwdhAsp = -869369.6219320131;
    bool umGtsxYVqgXkIa = true;
    double hMgezcd = -351521.8559587273;
    double rEnmhLgbcbfxizbm = -647410.6544959372;
    string xQTzcMksMRaNfDb = string("gHeQmbNQyacLlEZumsEiclevlRJjELWlFXUOlnhUjoKwWPgNdsIRPIJogRXVIRaLoyabxYnWxHAlCbGHPRPRrUuqtxPgMJqjgEFqJLNpUzOviPePockODQxFoedtZLJcLcTMGyLLRVPzXxceFUEhoemXEXivJAQBmLkbavyYyAMdogvTOuMPnhVHYYyfUQyjRkqmddLJshAJBAPKDMHBsYT");
    double OrUPlIMyFS = -497193.88359716703;
    int imijCCZu = -1790523626;
    bool DERZSIhdUb = false;
    string YjGCI = string("YZfselJEMtPmNgRTnuRTZDLwsBIxLmnIywIGXmNwiAlFFunYiLfVqRuEKUVeqFDNOgXUkrjoKIHNXVxbKnIxQiIKwDsqdXfjFnUxwcxzJsxwFbxrnGDhLwvFHfnYzVERIdUrXuvXoDmRzPBVsSJysktNmiSFNVndhoveaSjDzVOqktPOUmNFcefDzmWzkVxppXDbvCkrIxj");

    if (OrUPlIMyFS == -869369.6219320131) {
        for (int jYAvGercSiT = 1882371151; jYAvGercSiT > 0; jYAvGercSiT--) {
            ibRLNQEZVwdhAsp += hMgezcd;
            OrUPlIMyFS = rEnmhLgbcbfxizbm;
        }
    }

    for (int lYyyIaDtxIAIjwv = 655603612; lYyyIaDtxIAIjwv > 0; lYyyIaDtxIAIjwv--) {
        DERZSIhdUb = ! umGtsxYVqgXkIa;
        hMgezcd += OrUPlIMyFS;
    }

    if (hMgezcd != -869369.6219320131) {
        for (int lqTFK = 967245840; lqTFK > 0; lqTFK--) {
            hMgezcd *= rEnmhLgbcbfxizbm;
            ibRLNQEZVwdhAsp -= hMgezcd;
            umGtsxYVqgXkIa = DERZSIhdUb;
        }
    }
}

void JqdAWYrDm::yagZirNUaJvfGh(double EmTxCpBqwKBS, bool pZXgTfPDsuVfixYY, string nYEAjcAMNQq)
{
    string JuWGgXl = string("PhnAdvMEFfFSLrUoSFdXNiRUUHKjzPBrneqzWPDudTrFIHOUKEMOBlualLEqgvVVjllzvxyeNKcBFjJXTCaLGYmzFZmehBAGxScqCptDOJYFEXrEZPMOblaSjlEqNdfOyZZNicKjTLWYhCJMNBKItbDvcUgIJMpGJEgbhlhpURSKXMzVmCZBWNrSdTMBMlFuXqTapPQNiEIZOXbppplvcoUbLSSppjyomhtmvLlhaGVM");
    int jkHRJl = -641539943;
    int MMKaAqKzjKWPTU = 350530160;
    double JRHlFBCjH = 475178.54421006667;
    bool lsYOjtTgU = true;

    for (int xnbmTIKrFYAbsnkQ = 419514500; xnbmTIKrFYAbsnkQ > 0; xnbmTIKrFYAbsnkQ--) {
        lsYOjtTgU = lsYOjtTgU;
        lsYOjtTgU = pZXgTfPDsuVfixYY;
    }
}

void JqdAWYrDm::xCEWqSjsMfCXxC(int MVcOhQiPuRUQ)
{
    bool ICBJgFtzeQjC = false;
    double HiMIqhu = -787367.5091231038;
    string wIOjDzIcjYcBSlK = string("DWgXrdKeapMsXgzVtsBKcCMXgLxrqiIPVfbCiZzzlabVKHLEICSrRIWlrnaFQjpmPjLgPVvcPtuiCGxrczQozqbPwAIpi");
    string JXSlTLCcrQoEAVIl = string("PKzeWwFzTVEBSRLxNvHcnJqzJZTXHroCWekveKpSaPTljYxJKWePHCeJYpOsewZFTlLBiAZDFydWKYUntLzWgULAuaNAZrTONSUQxuzevfBdrOAvEOjXdrfdjWgqcgiXfmooKiWGcejInFFwggUtKmlCYfeTMCGybgREmNKvKZDY");
    string IsCauZ = string("VZnwuqWluzNXAAFCnQUjDpvWRRSJkGJktlZnXGzjXHYnNtftyzQJPdFLLSYLPLZSNkTBkByAgODGHnaxkcCxJunjLbnXxtjcmiFkXrLYcRmqEqsITPELfzIdQShFVieplXdJEovXFQfOgTuxtytOAahYCrCIuAuGtaTPyRSbbEuxCScX");
    double yzOuQmeePo = -294423.86745463236;
    double PGaPn = 1022665.5802059316;
    int ZufCm = -1108751099;

    if (JXSlTLCcrQoEAVIl <= string("DWgXrdKeapMsXgzVtsBKcCMXgLxrqiIPVfbCiZzzlabVKHLEICSrRIWlrnaFQjpmPjLgPVvcPtuiCGxrczQozqbPwAIpi")) {
        for (int qekHLLsRjTNewg = 2000111879; qekHLLsRjTNewg > 0; qekHLLsRjTNewg--) {
            wIOjDzIcjYcBSlK += JXSlTLCcrQoEAVIl;
            MVcOhQiPuRUQ *= ZufCm;
        }
    }
}

string JqdAWYrDm::LiglGzwOq(int GsgIbHpysUfsr, double lyIAZey, int JUpCecw, string hfpsWkJixhdUslwO, bool aNmCSIGmHzX)
{
    int hKcfHwLaMPdNJcCr = 2032216340;
    double XqUfr = -73197.80124210236;

    for (int HuqsllbKq = 1907655403; HuqsllbKq > 0; HuqsllbKq--) {
        JUpCecw = GsgIbHpysUfsr;
    }

    for (int OCZsMfN = 2089251937; OCZsMfN > 0; OCZsMfN--) {
        continue;
    }

    for (int ZvmVsCqtljUoqX = 1798873778; ZvmVsCqtljUoqX > 0; ZvmVsCqtljUoqX--) {
        JUpCecw *= hKcfHwLaMPdNJcCr;
    }

    for (int KKgUPCQTWngvKn = 2056546688; KKgUPCQTWngvKn > 0; KKgUPCQTWngvKn--) {
        hKcfHwLaMPdNJcCr += hKcfHwLaMPdNJcCr;
        GsgIbHpysUfsr += hKcfHwLaMPdNJcCr;
        GsgIbHpysUfsr *= hKcfHwLaMPdNJcCr;
        JUpCecw -= GsgIbHpysUfsr;
        aNmCSIGmHzX = ! aNmCSIGmHzX;
        lyIAZey /= lyIAZey;
    }

    for (int tYrNldVqnAULpw = 1542510519; tYrNldVqnAULpw > 0; tYrNldVqnAULpw--) {
        GsgIbHpysUfsr /= GsgIbHpysUfsr;
        aNmCSIGmHzX = aNmCSIGmHzX;
        lyIAZey *= lyIAZey;
    }

    if (hfpsWkJixhdUslwO == string("TLiEsoYxoMukoFTNckhVMGLngCTrTQTAsjzXQpKUjhKpeHXdYtfoNCpHBaYmOyuGGpeXopoHDejgCTVtMwmtqrsYPEKZtRWaSCJMVolxjwuKvPtBvmUnEAoQgMGRHsYIpWMbgTKuIJLtUmfeYALcgvaSgqw")) {
        for (int ZGoBxhjJBGHVGuj = 383964755; ZGoBxhjJBGHVGuj > 0; ZGoBxhjJBGHVGuj--) {
            JUpCecw /= GsgIbHpysUfsr;
            GsgIbHpysUfsr -= hKcfHwLaMPdNJcCr;
        }
    }

    return hfpsWkJixhdUslwO;
}

void JqdAWYrDm::KveKyTCMao()
{
    int zfAwZ = -904275001;
    int hbCiiMdMENorrV = 211691255;

    if (hbCiiMdMENorrV < 211691255) {
        for (int PNELZDwWh = 753103566; PNELZDwWh > 0; PNELZDwWh--) {
            zfAwZ -= zfAwZ;
            zfAwZ *= zfAwZ;
            zfAwZ *= zfAwZ;
            zfAwZ = zfAwZ;
        }
    }

    if (hbCiiMdMENorrV <= -904275001) {
        for (int YnarxwqxjWcUIYiA = 1400143682; YnarxwqxjWcUIYiA > 0; YnarxwqxjWcUIYiA--) {
            zfAwZ -= zfAwZ;
        }
    }

    if (zfAwZ >= -904275001) {
        for (int iTbnZuMxJCog = 2108024087; iTbnZuMxJCog > 0; iTbnZuMxJCog--) {
            hbCiiMdMENorrV /= zfAwZ;
            hbCiiMdMENorrV += zfAwZ;
            zfAwZ *= hbCiiMdMENorrV;
            zfAwZ -= hbCiiMdMENorrV;
            hbCiiMdMENorrV += hbCiiMdMENorrV;
            zfAwZ *= zfAwZ;
            zfAwZ += zfAwZ;
            hbCiiMdMENorrV *= zfAwZ;
        }
    }

    if (zfAwZ <= -904275001) {
        for (int sCzWcqoguB = 204987539; sCzWcqoguB > 0; sCzWcqoguB--) {
            hbCiiMdMENorrV += zfAwZ;
            hbCiiMdMENorrV += zfAwZ;
            hbCiiMdMENorrV = zfAwZ;
            hbCiiMdMENorrV += hbCiiMdMENorrV;
            zfAwZ += hbCiiMdMENorrV;
            zfAwZ -= hbCiiMdMENorrV;
            zfAwZ /= zfAwZ;
            zfAwZ += hbCiiMdMENorrV;
            hbCiiMdMENorrV *= zfAwZ;
            zfAwZ *= zfAwZ;
        }
    }
}

double JqdAWYrDm::HSSbyILEaV(double gqWxBHLlqSpFUBj, string JxdzdfyIbc, string YPqEsPH, int FIwDvxiOI)
{
    bool HGciEdjpmNO = false;
    int KZoTrlNqsvIjr = -2026098163;
    double BhQYg = 626488.606804916;
    bool gbhoshmADcC = false;
    double asDgeVvzXS = -629636.4873959527;
    string hMsPsF = string("isusswtSsYiueSsdFMPSotEdoiAzzlhaONmqLGmXdZvBEcwVGzLKMVQGjmTguHaHbToFnBsLmSLdsKRUfeuwmDroOiAfLPLbiUPdDLpihsEHzuNJeYjDWwuwRfHaiLFqvFvIFToZBHjilJwUqZgbUHrJuhFkpCEKJOAsIFREVUHIeAgZjxnvuMFApORAuRLVLMp");
    bool thXAlGfBeZ = true;
    string OSvTc = string("tBaXUEddozUWYSvSnAdKVoCBBhwvQlVcOmQYAQjagLdZNVdJKvSIcrhYoKQZSkFDlwqzcxfgAVUVPsPdXTcbNUzAKIouEPQrViBIsPpOxzQmISWibktKxWW");
    bool NDdkzrCwU = true;

    if (BhQYg == 263991.8981465531) {
        for (int ZgfcnbmtXg = 1127631080; ZgfcnbmtXg > 0; ZgfcnbmtXg--) {
            YPqEsPH = YPqEsPH;
            OSvTc = YPqEsPH;
            thXAlGfBeZ = HGciEdjpmNO;
        }
    }

    for (int lAJAClKtOeLOJF = 1528614520; lAJAClKtOeLOJF > 0; lAJAClKtOeLOJF--) {
        continue;
    }

    for (int FyJhWOtVCxp = 897885466; FyJhWOtVCxp > 0; FyJhWOtVCxp--) {
        continue;
    }

    return asDgeVvzXS;
}

string JqdAWYrDm::tGNgEjCfASp(int EiJfDBijPiPxYx, bool gYlTzcmskhgzjfTI, string klLviMVGsPAZkcD, double WEuIDITDqWPYs, bool ChxPXNBhtrCQ)
{
    bool TnVNUY = true;
    string knCKUngPn = string("cNpdDkaHmCtXlnzUEsXtsurhraugPPkTgnaEOZCdERwMBnVJBXMKycrObUwcpVTXTcETspRRuYJXtNhQHmiTJlzzdgqLtUJuPEvBMsRnIfqJODjAtukTznXsAYZMmlSqqrZHxDKFcAqjLkSzZAjIDphDjxjcdWdtXbtY");
    double RbFbHDRCqSmTRTb = 359959.6225138766;
    double VdWaxr = -424428.2260304667;
    bool fYaSPGH = false;
    double KkUqRhyh = 574070.6597986246;
    double ynmVjg = 854436.8860066158;

    for (int TnKrz = 533688020; TnKrz > 0; TnKrz--) {
        KkUqRhyh += ynmVjg;
        WEuIDITDqWPYs /= KkUqRhyh;
    }

    for (int GLHWwXRfGbhvahCX = 229670460; GLHWwXRfGbhvahCX > 0; GLHWwXRfGbhvahCX--) {
        WEuIDITDqWPYs /= KkUqRhyh;
    }

    return knCKUngPn;
}

JqdAWYrDm::JqdAWYrDm()
{
    this->AhYOEWEPRjMuVcc(true, true, true, string("nuaganEbZsamJbVWWwpwJJqaODMconHHJeWhczhydYAmdhlbWvAcvOYgnDMaYXl"));
    this->lJIDrDek(-910825498, false, false);
    this->FaRpnJSUlBXHUD(string("pWDeXdozjPzMdEwhnrZmlY"), -600318.4776970443, string("gCpsGOCBrRoQYiTdcRdWIVJbcQjmjcqDuPginQGVwEgrAZPYDqCLWcyiTrYffXJHQxUcnTEszZzlxyGkgNSRczpDrLkSEWUtcdTblUtOhEYdohVZZUGSWoJraGGljYwOOYVrhUwVvhQEh"), string("RHFOzOiIGsuyqQrCBplwQkoKRzEcnPZHXBjMYhwcPEbILIcYSfRjGhZgYIBkJAkAlJAoIZukhXgJQYSWTCGztrDZEuVyhZNRYSIjnmqrYlBxhsHgHgDEGSreTFbonalwxXLNygnbTWwgYQaDUGYMMMzqEcqNtwoR"));
    this->voOcBMDjMOce(-161952.57600830783);
    this->leVICbdjsE(-1430458244, true);
    this->QwghthYxX();
    this->lIuoasy(451177.4966596592, 1968264034, -140726406, -644990.1695140866);
    this->eooaUymlROTu(false);
    this->yagZirNUaJvfGh(-893535.8519283356, false, string("wySoqwNKEHQflDGGRhLXySCqlOaTKIhGBmSbXCvfiJhrFPpLIXgFaDwvyLhiudOztjBqyapsNemrWBPSBWynVpGDMnETPChCRGqYyrNDfbtIBeWEsOVcXBSIRXQhMrnXoPeTfAGTSuFMijgFOHAxrBCVTIPJXAiyueGNnabgdwiChXOKPNSXIlDfLgywZGYKfzUtiAHpoJWvCJHehWRiZpupbNWCoRVpevEnVZovP"));
    this->xCEWqSjsMfCXxC(1003773839);
    this->LiglGzwOq(1509976969, -855412.676390559, 2064402981, string("TLiEsoYxoMukoFTNckhVMGLngCTrTQTAsjzXQpKUjhKpeHXdYtfoNCpHBaYmOyuGGpeXopoHDejgCTVtMwmtqrsYPEKZtRWaSCJMVolxjwuKvPtBvmUnEAoQgMGRHsYIpWMbgTKuIJLtUmfeYALcgvaSgqw"), true);
    this->KveKyTCMao();
    this->HSSbyILEaV(263991.8981465531, string("PRsPywtGIzFyHXWjujXqSUWZiRgprAdWKGYKRtRMcGkHoJWJOSXzjqEQDtoGVbrNqIRfNOEJhcXuzjCocySbHgXNiJVtaPAytoGaEJVVnGVSiIpZtVKMUDiGDdrSPIWQkqzDxFSBpTiMkYJkNWgIWrWbJpoLTtXFPYJjCNjnMPz"), string("QQdfFsXWxGrQqpDqACYaPItxcpVrAJoHfRVBktdgdzFnGCykmTLIxGHJmDeVVWSwlvKlhAeY"), -1840683058);
    this->tGNgEjCfASp(-454174457, true, string("POxoOhEgqOCkTmsbLfOYQSKPlndOOGHZZNBnaDWhwgVlNKNdWDNnpfuevyhtljoLYRNTYwLxqClBaoJwNBoILlVKhlmKBDALoOzjdjSHCdlHtFjiUggofPDzwXLlXokdlXiCXPEaiQeDYVGZVkHFxSQVs"), 462421.00685492024, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HdHJoFo
{
public:
    double AUYGdqxQD;
    double ZOOInUPXKS;
    string hRUCAQMCrBa;

    HdHJoFo();
    bool PayeuDXbjcSnW(bool ImOLTixmKLoiD, int nKZprVmzYNqUZA);
    string jrqlN(string OedqMqDN);
    string ZlOpMdcaxMXC(double gPCJKGMMoQaqQyJ);
    void bNzhKeqVdAGAgl(int LpZkmBwC, bool mFilY, string ZjLlsCCHkuGuCa);
    string TGwpEHVKYwJai(double VXyeODE, double zfwOWXgnxx, string iHpnthpCdOoyZnL, int VDYiTLXjdSgqgX, int TFfrNPUJtLeYeT);
    double ZInzqCXqKbAHwa(string ioDNW, bool dTwvtpnMLgPPeBY);
protected:
    double RNPry;
    double xErRIoOc;
    double GLAcgzhlSiGBFGXv;
    string BdXWdZCSX;
    double nizAmcsurTIEhKJ;
    int aDMoPxM;

    double GPoyrEshTXDbWAuO(string wYsmEgNXPF, int XKIAZWurnFftvsB);
    double Rnuga(bool JKSHIvw, string AuILzGlPnF, int IMHytT, double mvBMDeVBLtwXxw, bool vucks);
    void bvqGIpbIDFtYK(double JuPTRF, string rptLCvXzLfBcuk, string hGxkslhvVM, double JmLjQEkQSqbB, int mwqOAPDWeWGEqGB);
    void risNebU(int gMYYBDNPAz, int HFBzgmfhBCGAy);
    string hgHLHDzriZz(bool TMhqFDjV, int JNaYXqwFxrpSAU, double OHasXlYfvoNqWuuS, string IhfATJalAvm);
    void xNPOpOJAjGZvf(bool sNaUVPh, int rVOIdQxPHfMvcut, bool gslOkPysiQaztlg, bool yDrWPd, int fvCQRysj);
    int slPgBFamYILo(int YmzNShkPGNCY, int FFQRwchtfKRmkQ, string kVdFNjF, bool PALcOR);
private:
    double WGJfdbgv;
    string HCwydc;
    string IqXVLAU;
    double PHSLob;
    bool XBkMAkqKFarZJ;
    int UyFekGlyoSv;

    string hEjRnUjDS(double MXmvx, bool izVLAodDCNhx);
    void jRvzokNtlWdswBF(string fFxDvPwKK, int mGhVHkm, double evqtTZTVOgkvpqi, int ragsPENnoUXB);
    int gVyfNBqHH(int IEOioDIrWdvxTla, string CkHNzsAsCoa);
    void vsWJafoYjnr(string yklvVeC, int CshWWcj, int qbEIOpp);
    int BelnClN(double eVQrq, bool AxGNXWEALSBGptJx);
    void OCMbi(string mJnhLtbbHtToW);
};

bool HdHJoFo::PayeuDXbjcSnW(bool ImOLTixmKLoiD, int nKZprVmzYNqUZA)
{
    string yuUMzjJppMBkAj = string("OLbKRsKCcbiPhoxxbFJymHmFemkgakbutyMJBbpJFkaGYJAUrLlBFpgyrbVwIamOxvAHwBJsNmAmMzKkZWyblpFjUbHMBiknSppyBiZKPVdXocyARFzdHpTRuQteAjsLsPOcqWMuNKZHxrwuArrLzgfWsLQcTTePEhnmbyjsdLzpYQPgcszCcUZkohDhyVjEHDkfVAyCZhvXBjsSbaxoVYHqHyfyDOOAwfHuW");

    for (int safNDmBRzhKQ = 1695822250; safNDmBRzhKQ > 0; safNDmBRzhKQ--) {
        nKZprVmzYNqUZA /= nKZprVmzYNqUZA;
        nKZprVmzYNqUZA *= nKZprVmzYNqUZA;
    }

    for (int IQjtuzZiL = 957512099; IQjtuzZiL > 0; IQjtuzZiL--) {
        yuUMzjJppMBkAj += yuUMzjJppMBkAj;
    }

    for (int jilOzglU = 1908774772; jilOzglU > 0; jilOzglU--) {
        yuUMzjJppMBkAj += yuUMzjJppMBkAj;
        yuUMzjJppMBkAj = yuUMzjJppMBkAj;
        yuUMzjJppMBkAj = yuUMzjJppMBkAj;
    }

    for (int NkqoxWXTHXYgx = 915493861; NkqoxWXTHXYgx > 0; NkqoxWXTHXYgx--) {
        ImOLTixmKLoiD = ! ImOLTixmKLoiD;
    }

    for (int jEvunzFEA = 1712356073; jEvunzFEA > 0; jEvunzFEA--) {
        continue;
    }

    return ImOLTixmKLoiD;
}

string HdHJoFo::jrqlN(string OedqMqDN)
{
    double uTWvOc = -278774.10749310016;
    bool DocKhLg = true;
    string NGYZckbjcP = string("vWEFhtlJlRncVuBCUYCXvKEJucFwXaxahcTLLbEsjgncmmIOHz");
    bool DooxPMzORHqM = true;
    int cdqRKegtv = -1919561452;
    string gLRuzNvTwNKhJ = string("aBHXFOcwcrpDIUBnebQxVCptGLTtSufVVFjYStdRroGFZTOqqIzDGsYjKrlEPyhSbfxpZEJqfxBJopyluLavXnIEcWZwQZWWqHcgjWYpbBSurlPrjohVzBXXjROZqAiGGkVaiYJeGnjDmpldEzfCrBMkyUMqBOuRAspPydRGyVEIycrovcg");
    bool FaLERZWLA = true;
    string PUUScYVygHWL = string("FqByrSzVWawCLnWVnnBrkBKSQrjzOgowxgOQcMlXAdMOXdBrrDjpMUQUdraHfgvdBcjKjdeDCpPHeeQQXBRVNlpIcdJfWnVInbeSjvIADOJxslVmDLuEDsqhudbfWPxrEofzccLGYtsjhrLjKLM");
    string RqdHWGAlTtmFWH = string("gumddhiASyHnezWoxepNPHeimZKccPMsSsbiCeSiEZTmgFZxcYNqTjVpXnBQbWzjtOQKkDyMhaZWchuiHkQHrhtVEcHiYSdjWDZUJrStbmtuAungnGzBooSxHHQRPmQNLCtluLkBkYnZhjYfMCTdXMpsFVxAPLUDMmGDxSlFiwLAaXiSdKtPXQFEoxuOQXCVuUzatHIjfqakUvvFRyIgHzswHaMjDZiwiKeNxwpxrRHsdvAunBBkJIYOstFs");

    for (int nUgOZQQ = 2041679780; nUgOZQQ > 0; nUgOZQQ--) {
        DocKhLg = ! FaLERZWLA;
        FaLERZWLA = ! FaLERZWLA;
    }

    return RqdHWGAlTtmFWH;
}

string HdHJoFo::ZlOpMdcaxMXC(double gPCJKGMMoQaqQyJ)
{
    int pDjeivzB = 1667988469;
    string bzPCrALfToaDG = string("NmjzOvoGhhbUXtJtGXnRYBMyKfcIaSgZPhDOQKMIVjlXvIMPLBqFfTAWORKqvyxOBjlieXLWGDUTEyqgExzHCDdQRRjJWavcDSCzjwoTJrXENdrKnNbmcDOPOGoURqXWkkVNoGQKeQAjcgQgBRvFrgMGJiCXbLgQVdoHQKarOaWeMNoUzEsjRMMDKGPvgniMkPHAojEPdXNFCDlzYIUXvJTUQwxryJHka");
    string FoOXtsbOk = string("fvjwZqzlNolBfNvzwAvcbcElBclDaIOQSYneQUGdNGyJJhMoYhBRBnxdhwfvtaLmJCNrUHsTaROGPYZOKwIZFLlIElGMEoXwBEohbhPvBffnSyDEeDTrVWbzgkuZf");
    double vHqPWHH = 592985.4401878424;
    double lvDMFjrbDdvY = 999262.9286982992;
    bool VorIefEeGGsq = true;
    string pVuEolPiFIk = string("fbSlEnIaKLoVryxXEreuWdpcLhTawOvdvrCxyOtdGmTKvvyuiKdNqMdaIMFnqMcWrQFlRqjdnXRDyiRrKDdvwHSGAkdqdLdwLtvVlwQrmibireOrycrJMNgTDawFUcRnWfhZUsHRceMcVvaQVphBBeqHvdUDoaeTNSdNyODHPswGkrbZwYEIwRpEPreGrSMGlzflnD");
    int BDJty = 154543441;

    if (gPCJKGMMoQaqQyJ > 730159.9323843211) {
        for (int fLuFXCEAwk = 459604500; fLuFXCEAwk > 0; fLuFXCEAwk--) {
            pVuEolPiFIk += bzPCrALfToaDG;
            bzPCrALfToaDG += bzPCrALfToaDG;
        }
    }

    for (int LoEhQCt = 1640880435; LoEhQCt > 0; LoEhQCt--) {
        gPCJKGMMoQaqQyJ -= vHqPWHH;
    }

    if (lvDMFjrbDdvY > 999262.9286982992) {
        for (int OtJpWgcV = 1221765151; OtJpWgcV > 0; OtJpWgcV--) {
            pDjeivzB = pDjeivzB;
            pVuEolPiFIk += bzPCrALfToaDG;
            pVuEolPiFIk = FoOXtsbOk;
            pVuEolPiFIk = bzPCrALfToaDG;
        }
    }

    return pVuEolPiFIk;
}

void HdHJoFo::bNzhKeqVdAGAgl(int LpZkmBwC, bool mFilY, string ZjLlsCCHkuGuCa)
{
    bool mSHrixdlIP = false;
    bool NHKWeqEmSXxT = true;
    bool DTSYvg = true;
    bool XSKRpqPZzh = false;
    string HNTVTeiJ = string("ulEpFYQflfRoHgfyKbkzVAnMUzncURJsrzyyxrlSrOYtMRtjamMDrhiMKUomhkrwTWwyNkrWBdafDVluicpOTfGCkZKefFiDmOIdmemPOcvkaeewuMQWOnQErqfDyUmcRzNzvtnoEpcUXTbFAewyozarvalsYMOEXbSaEvyRWNlKoMslQjKJWyHciMItEyvrLUWlByfJZLBwOMzQ");
    int BHcKj = 430396307;
    string rHovjQtUT = string("yFiFiliOdSCRfDGSCPeEGphQqKJlqTrvsNALqdgSalOTMUZFWSzYZfR");
    bool MglEnY = true;
    int JhoZdWylFUO = -110492814;
    bool xIGqQCJASC = false;

    for (int oyfrYSjZB = 894564156; oyfrYSjZB > 0; oyfrYSjZB--) {
        continue;
    }

    if (mFilY == false) {
        for (int XdZWPrLQklo = 1776250372; XdZWPrLQklo > 0; XdZWPrLQklo--) {
            mSHrixdlIP = ! NHKWeqEmSXxT;
            NHKWeqEmSXxT = ! mFilY;
        }
    }

    for (int rEkcNKBlqx = 146679202; rEkcNKBlqx > 0; rEkcNKBlqx--) {
        NHKWeqEmSXxT = ! NHKWeqEmSXxT;
        rHovjQtUT = ZjLlsCCHkuGuCa;
    }

    for (int iHPLzd = 1837187709; iHPLzd > 0; iHPLzd--) {
        DTSYvg = NHKWeqEmSXxT;
        NHKWeqEmSXxT = mSHrixdlIP;
    }
}

string HdHJoFo::TGwpEHVKYwJai(double VXyeODE, double zfwOWXgnxx, string iHpnthpCdOoyZnL, int VDYiTLXjdSgqgX, int TFfrNPUJtLeYeT)
{
    double txDuQQV = 331533.8862899838;
    int gBWhIQlBraTpdD = -847138443;

    for (int VchiwCScTb = 755884138; VchiwCScTb > 0; VchiwCScTb--) {
        txDuQQV -= VXyeODE;
    }

    for (int NmlFInZhGZkVTD = 1088494069; NmlFInZhGZkVTD > 0; NmlFInZhGZkVTD--) {
        gBWhIQlBraTpdD *= VDYiTLXjdSgqgX;
        VDYiTLXjdSgqgX *= gBWhIQlBraTpdD;
        VDYiTLXjdSgqgX -= VDYiTLXjdSgqgX;
    }

    for (int aDwuADKULLdELo = 584949656; aDwuADKULLdELo > 0; aDwuADKULLdELo--) {
        zfwOWXgnxx /= zfwOWXgnxx;
        VXyeODE *= VXyeODE;
        txDuQQV /= VXyeODE;
        gBWhIQlBraTpdD *= gBWhIQlBraTpdD;
        zfwOWXgnxx *= txDuQQV;
    }

    return iHpnthpCdOoyZnL;
}

double HdHJoFo::ZInzqCXqKbAHwa(string ioDNW, bool dTwvtpnMLgPPeBY)
{
    string oFRdQUjfDs = string("fyAzGrftAqOeSxLQcNJpGSqpOPBSeZwtVdGvxBiPtxssLJejnQzdmZUCplVMeauokcDIxWyacPOVlUnGbeXdIZjCoiRUsYsykWdNJIiPBbfXzydLhKXKtuoOfZhEChAbGCQjEtoBsAPRXNgSpSTLCTQvTIQaznhVUPSGWDhHlvWRUriTFIiwipHXcqngMefDaYpsqgA");
    double aetiinJi = 1018290.6857342452;
    int bMAbJmBlNcQseCw = 1603842288;
    int SLdoibGKFKefxQ = 1905304428;
    int MYyePwOSsdScJ = 259755800;
    double SfqszgSmx = -476361.0734143008;

    for (int ocqsQTNpgdqVskuX = 880213189; ocqsQTNpgdqVskuX > 0; ocqsQTNpgdqVskuX--) {
        continue;
    }

    for (int zaPoL = 1618891550; zaPoL > 0; zaPoL--) {
        continue;
    }

    return SfqszgSmx;
}

double HdHJoFo::GPoyrEshTXDbWAuO(string wYsmEgNXPF, int XKIAZWurnFftvsB)
{
    double nSLYuaPUaEeTyjwX = 1022860.917740199;
    bool bTYKYdVYeOZ = true;
    int pkfQCeQtNXF = -15744115;
    string lEQYqgPPIOOpwXLH = string("RmlzgoFGoFEkjBUAZbnbwzZMsXpXlUfwncdgbHXjOuzHrjBEmJyWFZUPdlHjztjgbgDtPBsuTUryBGEuAgvLxWKJJUZbVIttLUuVCjBkkkEdNlsDFSUKwu");
    double BurctZi = -582245.5442839466;

    for (int gSSxCkbv = 1402095544; gSSxCkbv > 0; gSSxCkbv--) {
        continue;
    }

    for (int cqaTeure = 1923399656; cqaTeure > 0; cqaTeure--) {
        continue;
    }

    for (int dtGFgNKsUysbJxez = 2083215111; dtGFgNKsUysbJxez > 0; dtGFgNKsUysbJxez--) {
        pkfQCeQtNXF += pkfQCeQtNXF;
    }

    return BurctZi;
}

double HdHJoFo::Rnuga(bool JKSHIvw, string AuILzGlPnF, int IMHytT, double mvBMDeVBLtwXxw, bool vucks)
{
    int dJgDacUZQHZkcICk = 1130119755;
    int EWaUuwRzmb = -1514008123;
    int lQxHagEjsvvnHHWj = 730933475;

    if (vucks == false) {
        for (int TNYjmNyIcZw = 56752305; TNYjmNyIcZw > 0; TNYjmNyIcZw--) {
            IMHytT = dJgDacUZQHZkcICk;
        }
    }

    for (int spAwgJxRlfQid = 1035376036; spAwgJxRlfQid > 0; spAwgJxRlfQid--) {
        lQxHagEjsvvnHHWj = dJgDacUZQHZkcICk;
    }

    for (int TWxwHiSMXIAzeum = 1101523898; TWxwHiSMXIAzeum > 0; TWxwHiSMXIAzeum--) {
        dJgDacUZQHZkcICk /= lQxHagEjsvvnHHWj;
        lQxHagEjsvvnHHWj += EWaUuwRzmb;
    }

    for (int toFgXhOIarEabDm = 476613201; toFgXhOIarEabDm > 0; toFgXhOIarEabDm--) {
        dJgDacUZQHZkcICk = EWaUuwRzmb;
        EWaUuwRzmb += dJgDacUZQHZkcICk;
        lQxHagEjsvvnHHWj = IMHytT;
    }

    for (int jsEckaLGlGH = 853846413; jsEckaLGlGH > 0; jsEckaLGlGH--) {
        IMHytT *= dJgDacUZQHZkcICk;
    }

    for (int baBczpjWTCj = 2054005389; baBczpjWTCj > 0; baBczpjWTCj--) {
        dJgDacUZQHZkcICk -= dJgDacUZQHZkcICk;
        EWaUuwRzmb /= IMHytT;
        EWaUuwRzmb -= EWaUuwRzmb;
    }

    return mvBMDeVBLtwXxw;
}

void HdHJoFo::bvqGIpbIDFtYK(double JuPTRF, string rptLCvXzLfBcuk, string hGxkslhvVM, double JmLjQEkQSqbB, int mwqOAPDWeWGEqGB)
{
    bool zmiwCSrUYPGIX = false;
    string mOxBijnPrUeOWd = string("iaAaCwWhBnfbZwhapMDObzxVYtfXMJZjtOsZ");

    for (int xkoRQUUonCmnJY = 73496993; xkoRQUUonCmnJY > 0; xkoRQUUonCmnJY--) {
        continue;
    }

    for (int VfAtCSGlpqaXTWrP = 1204152702; VfAtCSGlpqaXTWrP > 0; VfAtCSGlpqaXTWrP--) {
        mOxBijnPrUeOWd += hGxkslhvVM;
        mOxBijnPrUeOWd += hGxkslhvVM;
    }
}

void HdHJoFo::risNebU(int gMYYBDNPAz, int HFBzgmfhBCGAy)
{
    double pVlDViJNPehUuy = -90258.62973937251;
    double CNwObJa = -378538.6120467961;

    for (int JEdVZqUpIkExmr = 1981505870; JEdVZqUpIkExmr > 0; JEdVZqUpIkExmr--) {
        pVlDViJNPehUuy /= CNwObJa;
        CNwObJa = pVlDViJNPehUuy;
    }

    for (int EMdeFqTLUSgRcvv = 675577430; EMdeFqTLUSgRcvv > 0; EMdeFqTLUSgRcvv--) {
        pVlDViJNPehUuy -= CNwObJa;
        pVlDViJNPehUuy *= CNwObJa;
        HFBzgmfhBCGAy /= gMYYBDNPAz;
    }

    if (CNwObJa < -378538.6120467961) {
        for (int wKPuZI = 1671202904; wKPuZI > 0; wKPuZI--) {
            gMYYBDNPAz *= gMYYBDNPAz;
            HFBzgmfhBCGAy = gMYYBDNPAz;
            HFBzgmfhBCGAy -= gMYYBDNPAz;
        }
    }

    for (int SJCSyczQBzNOnq = 1293915899; SJCSyczQBzNOnq > 0; SJCSyczQBzNOnq--) {
        pVlDViJNPehUuy *= pVlDViJNPehUuy;
        pVlDViJNPehUuy = pVlDViJNPehUuy;
    }
}

string HdHJoFo::hgHLHDzriZz(bool TMhqFDjV, int JNaYXqwFxrpSAU, double OHasXlYfvoNqWuuS, string IhfATJalAvm)
{
    string NETnrqwgTxRgYqoa = string("sUOLSlpubUJJQAZpAExSIggTymdEFPDQuXfjGCsxZYWDJuEYAnwqSnVVGizUFlbccVPgsXWKQJiXVahPzUkNARbDuCfZdqVLcInaafdTLkOygySGhWQrUmcVYAIovUAyAuVVgtQqZviuwsAEKw");
    string FMDaMuYbOvVG = string("DlPJuBJuczKdOpZ");
    bool poobXYETs = true;
    string CJRbXZHcLUgXMuKY = string("wvmvJHnGuaQevOvBKOhBnCkJzAZNTERkmOPxUdgjkQjjUSiEAUDoCXiHqSnJXiHEvLkLgMXwwzQnesUbIUtlTTXKaEIDCLICQVPQbHMGJuhWJWaNuPOnBuFIiHuQwXxCpTFHffPfrplUarEehbZqvxXsifgWZeKErNvUWwabWzJKAcAsKNHYpKJoEiJqmrtlfknqfzsQojOPOTLRSb");
    double eqUkrwosug = 817345.0805484226;
    bool RYRhdRBq = false;
    int ecNLmBMoPSH = -771914885;

    for (int iiGfaJfXb = 461158593; iiGfaJfXb > 0; iiGfaJfXb--) {
        NETnrqwgTxRgYqoa += IhfATJalAvm;
    }

    if (IhfATJalAvm != string("sUOLSlpubUJJQAZpAExSIggTymdEFPDQuXfjGCsxZYWDJuEYAnwqSnVVGizUFlbccVPgsXWKQJiXVahPzUkNARbDuCfZdqVLcInaafdTLkOygySGhWQrUmcVYAIovUAyAuVVgtQqZviuwsAEKw")) {
        for (int GTDovKvHGCa = 622840704; GTDovKvHGCa > 0; GTDovKvHGCa--) {
            continue;
        }
    }

    for (int OrQwts = 1831467948; OrQwts > 0; OrQwts--) {
        CJRbXZHcLUgXMuKY += CJRbXZHcLUgXMuKY;
    }

    return CJRbXZHcLUgXMuKY;
}

void HdHJoFo::xNPOpOJAjGZvf(bool sNaUVPh, int rVOIdQxPHfMvcut, bool gslOkPysiQaztlg, bool yDrWPd, int fvCQRysj)
{
    bool oicBcraYNmlCc = false;
    double vMTXmNevjL = -52834.43512869537;

    for (int mitOCnWcj = 623849299; mitOCnWcj > 0; mitOCnWcj--) {
        gslOkPysiQaztlg = ! oicBcraYNmlCc;
        fvCQRysj *= rVOIdQxPHfMvcut;
    }

    if (rVOIdQxPHfMvcut >= 1351463778) {
        for (int eDdVqAIZKauSzW = 1192707306; eDdVqAIZKauSzW > 0; eDdVqAIZKauSzW--) {
            rVOIdQxPHfMvcut -= fvCQRysj;
            sNaUVPh = ! yDrWPd;
        }
    }

    if (yDrWPd == false) {
        for (int vZfYi = 1770248212; vZfYi > 0; vZfYi--) {
            gslOkPysiQaztlg = yDrWPd;
            sNaUVPh = ! yDrWPd;
            gslOkPysiQaztlg = sNaUVPh;
        }
    }
}

int HdHJoFo::slPgBFamYILo(int YmzNShkPGNCY, int FFQRwchtfKRmkQ, string kVdFNjF, bool PALcOR)
{
    string wldthqqvycMm = string("zmLxhKXtUDQbNuhfNQxtIVnVztCVkMlWYHINxTBOxiwvwQwSNliINeSvNVidMFYXzOFJSiZgoLnIbyBGivtNtUdMXTgTEiHwXrcSaTwmndYsfRefwTiAckZkXYWLHrGPKiDuDWyUnxKisZKGHeAyfRyiivJlSVrCPYrFtSfIOoYPkFyhYDItpRxUxRAiLTAJxPBWvykMDUaQxG");
    bool bsPAYayrUvCU = false;
    int nWEiDq = 941739491;
    int QdPAf = 1047830710;
    string kSleU = string("etjUlHlCauLfMRDIHZUMGeCBaKsAItEwVZZftgzLewQhmzsTymTisHDPxYrAYOMJsL");
    double OunEySnRmfOq = -925328.2081400945;

    if (nWEiDq >= -784118604) {
        for (int mhVklbdOXJePPsa = 1288426430; mhVklbdOXJePPsa > 0; mhVklbdOXJePPsa--) {
            kVdFNjF += kVdFNjF;
            OunEySnRmfOq += OunEySnRmfOq;
            nWEiDq -= FFQRwchtfKRmkQ;
            kVdFNjF = wldthqqvycMm;
        }
    }

    for (int AzYxrJ = 741931841; AzYxrJ > 0; AzYxrJ--) {
        continue;
    }

    for (int txUoSTadnGYujtFy = 668084538; txUoSTadnGYujtFy > 0; txUoSTadnGYujtFy--) {
        continue;
    }

    for (int eHAmDNVlSbRIvK = 750092316; eHAmDNVlSbRIvK > 0; eHAmDNVlSbRIvK--) {
        FFQRwchtfKRmkQ /= QdPAf;
        FFQRwchtfKRmkQ /= YmzNShkPGNCY;
    }

    return QdPAf;
}

string HdHJoFo::hEjRnUjDS(double MXmvx, bool izVLAodDCNhx)
{
    bool FKQrZmu = true;
    int QBDzozwEjixXFa = -1279444659;
    bool KlSKn = false;
    int aHSCplmqNCoY = -1411020446;
    double HHLHA = -744502.841427665;
    string rIjhhzDsTrRQEic = string("sdGQykREJPDhpKPkGoMGQunwGpSWvReeSGzvgXOUxdQvOycVKMahDQVypJiTTZCNnXCWiEDHLciwKNbgeEsWbrOchebCvrvBpnWGFFDvMPNbZzsWvtlRzfawhcASjlwDBpEAuYgiLWoRcXCBaHvKZeeVRfWUAbeXLeBSrxziMuAcMNyxKmKmWfvPBanTETKuic");
    bool iDRRpzDgEh = true;
    string HDNHjGMCJ = string("prxqZfkTaOXFTDtweFddmfTyJyYdGRmRbghsFMFqnonrmMNUxURquejYKjtzZYJDHwftdLgIGLhSkJfBQsROqXAbIlHYZBDGiWsJyoYeHiDXxAjISXyPpagchZisZepBCCDvgYXVk");
    bool HJmEVlHr = false;
    string zIOiPiFtbOdHQy = string("rnZvTSCiOrqiSOIGvmAgbiNXedHA");

    if (QBDzozwEjixXFa != -1279444659) {
        for (int fUbfFGa = 1923950002; fUbfFGa > 0; fUbfFGa--) {
            rIjhhzDsTrRQEic += rIjhhzDsTrRQEic;
        }
    }

    for (int yaPzcXAbhMACZuus = 1529635558; yaPzcXAbhMACZuus > 0; yaPzcXAbhMACZuus--) {
        iDRRpzDgEh = ! iDRRpzDgEh;
        KlSKn = ! HJmEVlHr;
    }

    return zIOiPiFtbOdHQy;
}

void HdHJoFo::jRvzokNtlWdswBF(string fFxDvPwKK, int mGhVHkm, double evqtTZTVOgkvpqi, int ragsPENnoUXB)
{
    bool dEGBNTcONOhKBs = true;
    string snwFOqroIw = string("oWnUCmbMqyYtTJBIcSXziZIBLtuZtNhWFraIqquxkOyzQgouhxqrAekpFSXGHIgCvDpfjcwOUwWvgUvFRuuxPQsAYlKFPrRJCqFINOxktwsVnaEuGsTklFwOpyhDdDXjZFxgZjDaIipIUqjUKtCCzSLgyKMKZBPWFPSjxUdBqoUsNoTbKhoOLlwXzKPVEEvtuCULp");
    bool SEYVAlS = false;
    int wezHBwDlPLOYImT = 1041228838;
    int ukfzppuTaxQtD = 615830520;
    string iVwzgrBe = string("TzcLQQytDbxwwMfWLIwZcNgKMHvpAoTJrIJVXTBdAwHOmuZCcwrWMBWHFLDcczFtSvoKpuCittAXCQTTvSmXlNmymrypQrrQZnCRttkrWlFncjtTXZQVjKpZUnNJCRFHbpCGSfTWtFHUqRmvzTQVpXePYWQIYSoBQQcrTSbg");

    for (int lebGeJUKBPS = 1755029798; lebGeJUKBPS > 0; lebGeJUKBPS--) {
        continue;
    }

    for (int xkiYOeBfKZ = 591858524; xkiYOeBfKZ > 0; xkiYOeBfKZ--) {
        continue;
    }

    if (SEYVAlS != false) {
        for (int dMnCDwKf = 293911212; dMnCDwKf > 0; dMnCDwKf--) {
            snwFOqroIw = snwFOqroIw;
        }
    }

    for (int jduVvR = 653744272; jduVvR > 0; jduVvR--) {
        fFxDvPwKK += fFxDvPwKK;
    }

    for (int MakaJayRWK = 289341227; MakaJayRWK > 0; MakaJayRWK--) {
        mGhVHkm = mGhVHkm;
        wezHBwDlPLOYImT = ukfzppuTaxQtD;
        dEGBNTcONOhKBs = ! SEYVAlS;
    }
}

int HdHJoFo::gVyfNBqHH(int IEOioDIrWdvxTla, string CkHNzsAsCoa)
{
    int vlDFLslpUhTkog = -1837019715;
    string UrymAdWe = string("byzUQqubUolDUJJijmjzvMeKnBFvGBZmWXXhSayDToXYZrcuRWsmIbHdzqmTzDfiTRfKUGWuxisiCoKrrQNzeWfepxIpZcJYUViBCkEtNMFKdeHPtQCZwarWNKOXebKOcFuRUOYgfUADSBnOytVmTzbbGvMwdgQRfMGruQRulislpxyvUmdYpHepLfYbIoNEihyUzBZaYWiPdGqEamzPxfgm");
    double EsYUwUKesuizz = -379941.4570319159;
    double ZGckxhMc = 26887.055274968512;
    string pMiPGfBsxXidEbA = string("zRHbpeYnHVUUdJnBondAfzjFKEebhitXwxsncrjiJKOxUleUpjWmzchYapfOzBUoUrjEPqtUEIgpfcSGOGyzpiCqrIHfKDYHSpnzVbPzxDNYLpfTKGBDnZTGcyhDLUibDMqIHfPYtJkTGgrsmFWpLmrtziqrCTHSosRUkrFpMkTfKyBVJqkcUulGqrOgndPEabBZQcpEjOhmtZuTVtxlVYLkVYkpVQFVzMohCLYFGeRLH");
    bool EZaqYfsexPxy = true;
    int tYZQuoQDiKl = -1954220502;

    if (UrymAdWe > string("YlVcCsvS")) {
        for (int unvEbdKDWekOWek = 649533331; unvEbdKDWekOWek > 0; unvEbdKDWekOWek--) {
            IEOioDIrWdvxTla /= tYZQuoQDiKl;
        }
    }

    return tYZQuoQDiKl;
}

void HdHJoFo::vsWJafoYjnr(string yklvVeC, int CshWWcj, int qbEIOpp)
{
    double XHzqTDVG = -924152.3960851625;
    double MOwtDYxmYG = 161687.42586505768;
}

int HdHJoFo::BelnClN(double eVQrq, bool AxGNXWEALSBGptJx)
{
    string iDZBxsIAnmgri = string("cOVezuWGuKVhQSjgLKEIhKyYyMaczallRpenkxmOdJEBqWhBdciqKbgLoaijaHaLpnlrgVodKFiFESwBhsXwshbkVsFAUnMEzQgnRkiSwvlnztEusvtsNQZxABBBGpnrQJEBfZMBAsyaPpDiFeyvSPHbMbxXDxFTpCsKYXCRZovQATeWAChOuJXvyBvlJaCpzsXkpuloHbHHwDpkGZfXlZWlMWuOsmrBlIhsLcciLZDDLJT");
    int zgWGGzNPkriHsKk = 44143599;
    int CyVcNPCdZsueZQ = -1428176307;
    bool OfHAwmVb = false;
    bool DxxwkJW = false;
    int hNbmxFSFXGkWKFP = -928434436;
    string pxWQBwDTzx = string("wmNccmEnKqHCNeBENKqKcQcBVrjdtBrZVbGwtfGUpoeDLiSBwGOaRocNFOFyzIcoQqQeWiVKEbOOmuirgBxQWdIlVULTNUeELykjrYJIaVoEuENTYXesNtZTKPODbntzrrLCZAwQiXjmpsgAzuggRfDefcZSLrOOgScVXDglLebgnhmBs");

    for (int mZJnYO = 1344724720; mZJnYO > 0; mZJnYO--) {
        pxWQBwDTzx += iDZBxsIAnmgri;
        zgWGGzNPkriHsKk /= zgWGGzNPkriHsKk;
    }

    for (int UtSGNZtAgyCt = 830263987; UtSGNZtAgyCt > 0; UtSGNZtAgyCt--) {
        pxWQBwDTzx += iDZBxsIAnmgri;
        CyVcNPCdZsueZQ = CyVcNPCdZsueZQ;
    }

    for (int mWinraYlHuV = 1558054202; mWinraYlHuV > 0; mWinraYlHuV--) {
        DxxwkJW = DxxwkJW;
    }

    for (int QasrBfedslt = 1316333561; QasrBfedslt > 0; QasrBfedslt--) {
        continue;
    }

    for (int PCTGxjpRxYa = 737448280; PCTGxjpRxYa > 0; PCTGxjpRxYa--) {
        zgWGGzNPkriHsKk += hNbmxFSFXGkWKFP;
    }

    return hNbmxFSFXGkWKFP;
}

void HdHJoFo::OCMbi(string mJnhLtbbHtToW)
{
    string KEzTFVQDSSp = string("KZKogmmEHrTETBtrEDQsSLMSiDmGztYvlaDSyQCPcwzpyKCWotlJvdLmUUUYdLFdFVsviPPlxVCjCywsgKOlCJZClsefZAqQKrNkMpxiZQVjVaypYqsheKeUIhpyVwPSvymAmMoDrYJKdrymSneQMnZPtDimhnwXpxmeLLTgWejAprxNbiO");
    double DbIAlcKmkxlai = 609615.4662611387;
    bool RgxoKWiphdCNqhBI = false;
    double pooJIr = 911271.0196659286;
    double ZghScQfYAKkSZ = -58387.269896277656;
    double cnTEarwQMuGPc = 768472.8967963023;
}

HdHJoFo::HdHJoFo()
{
    this->PayeuDXbjcSnW(true, 652437238);
    this->jrqlN(string("bylbdfMcdkzhUehXNYnazPFDumcCoTuBgbxPSgLNTXvKCchMROBYtrKlraeegOLUKuNUyaQckvhRQJKHUQNGHybcwxqWMrcZyeISvgjoQUIOOSOsVhEDAMPDqYgWSCtFnPZKqKqrkZGzUjYcdQKEWhiW"));
    this->ZlOpMdcaxMXC(730159.9323843211);
    this->bNzhKeqVdAGAgl(1324559880, false, string("BbliZZTLOiPUTBJbiDpsAqBmgAMygktKbQlUUCTmhBOMxWRqSGYBBrZcjnBSQFCgqwybKSvZfJugFeluYkTGUQLDmZIdEJJfqEPPbhnbNlucQifxhBKzFHWXlpZADQsAYNCOKOXDAWhInaSZkuQEkzWUFpsh"));
    this->TGwpEHVKYwJai(1012303.922464637, -831620.2757311113, string("YriZpveuheRXpGBilifJhOcbnzXSRcjAOViQLWajUANXmLWsBrpKmEfSWhHcYdBTCCTdfvVEZIrumDaHrAWmTLSZFIFBBEIhGQDBjFBXaseLsBApOJmUEBiibqAhiIppbmiXmXdGDQBUDpIyvmreemLdmhjKRPVffgNzgQxfjcXdwoJDqWocvHdVJlVENcVVAxHlgurmPjpzfKzhAdqWGotNFc"), -193027418, 443672211);
    this->ZInzqCXqKbAHwa(string("vQeehjpDGiIoKKJdrKAXNUdVGlpRuhHwFRenQuoobnrlWjjAjCvuXjs"), false);
    this->GPoyrEshTXDbWAuO(string("yVVNAsrfDvltMKiSEKkAXkTMPGfSfOkqZvmWkUdfljGEEnDfucXBbsmuEOqzLYuBdGtYzYkssumYfkLzMbkgeKXDCVqJBVOsyzgXniYyrSFzMthmTLQJvqMOKTtvHSxiDcKGqnyKHtyDEkUyIAbifFEOycRRyfAUmzWTWakIGuqCDescokKZxqcnHhGFiYTaOAwpNwBGvRsmVZFjyLeY"), -346067190);
    this->Rnuga(false, string("LS"), 191151587, 117962.93986926862, false);
    this->bvqGIpbIDFtYK(965467.5121488903, string("PObjjLwOdOVgKCbPyRunFGsRpStyxxkwWWuEz"), string("ReOWESZRccHVgToVyFzZult"), -705126.607632198, -9678912);
    this->risNebU(-1502637372, -1081711752);
    this->hgHLHDzriZz(false, -1531507583, -923761.1716496105, string("bRkWstkGMjJEBLPeMQAlrOjHJPWIrqUSpwRxtPxBUgtyobegfnmuUZqdzvOtlqEZTwMHglUOVJVHQKjsQQMkwhDBSbIfghodySKWuVZpBeXbdTIqVBIiIyRBiiumSDsSQvLUyuxMWRImDXAKbJMOSxmQnLyEZFvNaAenewqOkbUjSEntnaecXmYDhvXzSPFIAYHOdjTZuAtpsADGYvdSRjLnmhYe"));
    this->xNPOpOJAjGZvf(false, 199825762, false, true, 1351463778);
    this->slPgBFamYILo(-2053830476, -784118604, string("ybxYTyoInfReuVtZbbWFpxqPCNEZBDtMoFJUgrtmHZmQPcUatXErpbEkKuZYGgPEcDwBxNsnsAulUlGppNArUnRLoUQFLPlnVXjHQdnpqfgZpczliBekAaPRXJtQBTQgpmqXiaEBUEwNDXpsYpvVbPVNddIpaVfCjyiHWKwuKmqMIzNttlMyktzapPNjBkZCUyikgBBZhfUaZEqNMQXSAb"), true);
    this->hEjRnUjDS(-832170.1744675849, true);
    this->jRvzokNtlWdswBF(string("ieyESVEVoIXTWJrypFJJuSrAZiaYBDZSghCSYJqYkBZvWwWtlFCdRHQWfWEdZDwLVkOKZDLXOOTyZoWPSYHQfZmfdoRXycnJur"), 1023183713, -440374.2674081135, 1391120826);
    this->gVyfNBqHH(1003170364, string("YlVcCsvS"));
    this->vsWJafoYjnr(string("OdLoOwDesElfWeTBHnyDXGQMMdmlPyrVTxtyyngJPgMlYbJueTbvpgVAmys"), -463335853, 810076164);
    this->BelnClN(70624.92848690577, true);
    this->OCMbi(string("QygdpzwgKJOfkkPdAYwlNJEWDJJBzXFRuLthwaMtRlfVWiLqgIYsPDKbNJcLVyTZEQOIKPKtAkaXLyUfymyYOUcRFfOj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YqwawpdIMb
{
public:
    double qeFCrGY;
    string ImlgDVAWDajExjtQ;

    YqwawpdIMb();
    void iPbpLqrxDRxmQW(bool tkbJVFRhXq, string zOYMkgY, int iwBBwAJ);
    string qmAHUuJqiKPx();
    bool uTNMApZMBmSKJsG(double SmwYHhILHXSW);
protected:
    double wiHrVWe;
    bool dAkEDAQzoYPIrcC;
    string gPwcolqdFagFJ;

    void PYkZAgqPormavtO(int SBuZiut, string KBuqSXNNjbaKWedJ);
    void yhkZb(int IWvZh, bool IPfTewPboej, string QtYfUOKkHYJKNuu, string ipNoAQfzJsbL);
    int fXYYvzCmMfagVrD(int VqPFecLU, int DpCcYDAYnAOCP, double rwwDBhDsMOmWle);
    string wIoGAzvP(bool HPITXvJTk);
private:
    string yGBpDVV;
    int WtpOQmyDPEX;
    bool QumgcOGF;
    double emTbcGjgvYVc;
    bool vCTgWG;
    int BZzbKe;

    double LEhKlAmPSvplalkJ(double kUisEe, bool KgnUjFzaPXoi, double uvAhnGDaLsIIT, double EIJlYPRhaKLBOg);
};

void YqwawpdIMb::iPbpLqrxDRxmQW(bool tkbJVFRhXq, string zOYMkgY, int iwBBwAJ)
{
    string xxgrSRezVaxrhQHz = string("pzhXoPvQWbblAeBicowUCOEvUOdtbLrASZmxihSIHJkXeWLlCPzEZlKFanABDdesJhHqesJQdRzdpoGmAjugmNmAoAJFMTogcRCLdnCsVOYdGACOQWK");
    bool LkyHHtgQC = false;
    string CiyIzFkg = string("FICwHrkJdODytzeRBPhZXcoHtarkaqSEfOKOckciCcXYzUsnvkGGXaWJlXkMnpVPSVIYZNDwncihyunWQIlBoJmBjdBNnceWQWZLSxaOXcqVJwfmqMTBoBZbhjqTtOBkscbLNzAvuZNWzHlfKjCDuEUkzXujXoIShEXfKPcHMDfaTFeSZdguMburbKcfxmeitoJVjtCtByGq");
    string GePpRJGfsIJVvH = string("ujnAjkXxDZYJYagCSFcGGLLmiNYJgKhuLlaZGVyPjtpRQAQJfwVtRZaLhXcsSPiSljuhEI");
    bool dGqelfi = true;
    double yUROEV = 1014685.0430573192;
    bool bxBKt = false;

    if (bxBKt == false) {
        for (int FFrfaRdBjEVnxp = 1526567302; FFrfaRdBjEVnxp > 0; FFrfaRdBjEVnxp--) {
            continue;
        }
    }

    if (zOYMkgY >= string("ujnAjkXxDZYJYagCSFcGGLLmiNYJgKhuLlaZGVyPjtpRQAQJfwVtRZaLhXcsSPiSljuhEI")) {
        for (int pZvPzI = 2028533804; pZvPzI > 0; pZvPzI--) {
            GePpRJGfsIJVvH += xxgrSRezVaxrhQHz;
            dGqelfi = ! dGqelfi;
            CiyIzFkg = GePpRJGfsIJVvH;
        }
    }

    for (int WqQNRdnkUMPygN = 625176302; WqQNRdnkUMPygN > 0; WqQNRdnkUMPygN--) {
        LkyHHtgQC = bxBKt;
        GePpRJGfsIJVvH += zOYMkgY;
        dGqelfi = ! LkyHHtgQC;
    }

    for (int WfNjkwwC = 1825208830; WfNjkwwC > 0; WfNjkwwC--) {
        continue;
    }

    for (int anVzzI = 663301295; anVzzI > 0; anVzzI--) {
        bxBKt = ! dGqelfi;
        GePpRJGfsIJVvH = CiyIzFkg;
    }
}

string YqwawpdIMb::qmAHUuJqiKPx()
{
    double KCifhMUyEawOi = -115217.97407893615;
    double XwfDJcTOLC = 163422.2416914152;
    string PailEcbGvGcePETv = string("zSebEJJqNQmfDiekARBGEPFwsxIIcuuJUwbxZurBmpUDAOMDwuuzoSlzWKYuZJGPJoHmDFmopHhgwPxFzHEevuQWhiUaHqIKtNlaHVoFGjbhLFpSBbauZKKeeWoXlidrBxXLqoeezgBTsNFQirOxIIIudRvPilecSnUJpqrHQALTWmlLHQmnGffUhSpKyfnbhAifhplqgeVXaOeKxhyvsWirgtQJtFPIoQ");
    int vTKKxqIWrA = 122943556;
    int xTyYIxvOuYFdu = 1153716018;
    string RormVuOYkRqYTY = string("IxgDSWErVNFMvuJQdHcHAmZydstRsxzsfALkOJLRMZfljLGEiNQeNJUfjYzuisrBjdlwodvAIBicnUInWdvJvBFxWJTjOEseEnLDspVphtejQDyUaYRhAghxlGDCgfFwdfVDFkvPmXPRqNcAwlmiYcgOihpBfiqaRYEJkJYMBNccvxYGwNCLjroJOSwa");
    string NBHmVD = string("eYoTvPLqEfITHYw");

    for (int WygxxGupEYyg = 1693738411; WygxxGupEYyg > 0; WygxxGupEYyg--) {
        vTKKxqIWrA *= xTyYIxvOuYFdu;
        KCifhMUyEawOi += KCifhMUyEawOi;
        vTKKxqIWrA += xTyYIxvOuYFdu;
    }

    return NBHmVD;
}

bool YqwawpdIMb::uTNMApZMBmSKJsG(double SmwYHhILHXSW)
{
    bool MHWACPitLYCPh = false;
    int TIAegpchJpWIMzM = 1132200940;
    bool PFfLX = false;
    bool ddwOoZJrfmZlO = false;
    string ZenEyiOC = string("EHiobIBwHCNeGuFxzCDqxdUricmnXaLxgBwYZAbMwPKkhpupnwzhxptNbiJr");
    string LCWkcgBh = string("CKhFmlmyOjaeciCspzogEBqpZvUBzMFkuJHGAyjuAxBvUPvDDFQKFfnlbBHbWbCbJISQUaqeOgCmusgVVqjWDaAzlSNSlCKwKkXonMborMdSySvRYogBdPgYjTlgJEMCDegrvHQTcFGJHYtybXiWCdbAqoYeGbbpXacj");
    string wQCMsFMroYmLbPl = string("kwcNxMxhnYhmDfIUpqzEnzbPFpikMcuVbJNohWatHFdclQVNkbumxVdXleKyzFuCquZJQlLhaSeTvIOJqxwJjfbLVwCNFpdgegWkTutUmyBttXKiezcogMWuoMInogkTyeVwtHYhlYTVnlzWkZV");

    if (LCWkcgBh > string("EHiobIBwHCNeGuFxzCDqxdUricmnXaLxgBwYZAbMwPKkhpupnwzhxptNbiJr")) {
        for (int glwtH = 625243958; glwtH > 0; glwtH--) {
            PFfLX = ! PFfLX;
            MHWACPitLYCPh = PFfLX;
        }
    }

    for (int gdezyxIvwFfpdWa = 2082472461; gdezyxIvwFfpdWa > 0; gdezyxIvwFfpdWa--) {
        MHWACPitLYCPh = ddwOoZJrfmZlO;
        wQCMsFMroYmLbPl += LCWkcgBh;
    }

    if (LCWkcgBh != string("EHiobIBwHCNeGuFxzCDqxdUricmnXaLxgBwYZAbMwPKkhpupnwzhxptNbiJr")) {
        for (int ecJpkmJ = 1448020006; ecJpkmJ > 0; ecJpkmJ--) {
            ZenEyiOC = LCWkcgBh;
            wQCMsFMroYmLbPl = ZenEyiOC;
        }
    }

    return ddwOoZJrfmZlO;
}

void YqwawpdIMb::PYkZAgqPormavtO(int SBuZiut, string KBuqSXNNjbaKWedJ)
{
    bool lPkilmBI = true;
    int mKciTKx = -130614915;
    int ajRjwJIgNLJDs = 1493135015;

    for (int CattgHtjXiYkUv = 1913579095; CattgHtjXiYkUv > 0; CattgHtjXiYkUv--) {
        lPkilmBI = ! lPkilmBI;
        ajRjwJIgNLJDs -= SBuZiut;
        SBuZiut += SBuZiut;
    }

    if (SBuZiut != -130614915) {
        for (int gmThXmxayCR = 2114288365; gmThXmxayCR > 0; gmThXmxayCR--) {
            ajRjwJIgNLJDs += SBuZiut;
            ajRjwJIgNLJDs = mKciTKx;
            SBuZiut /= SBuZiut;
            SBuZiut /= mKciTKx;
        }
    }

    for (int FHpdUnWCWrSAWR = 342921677; FHpdUnWCWrSAWR > 0; FHpdUnWCWrSAWR--) {
        ajRjwJIgNLJDs *= SBuZiut;
        ajRjwJIgNLJDs -= mKciTKx;
    }

    for (int tNasSafW = 2039038603; tNasSafW > 0; tNasSafW--) {
        ajRjwJIgNLJDs = ajRjwJIgNLJDs;
        ajRjwJIgNLJDs -= ajRjwJIgNLJDs;
        ajRjwJIgNLJDs += mKciTKx;
    }
}

void YqwawpdIMb::yhkZb(int IWvZh, bool IPfTewPboej, string QtYfUOKkHYJKNuu, string ipNoAQfzJsbL)
{
    string hKqkBb = string("fxrqZsJJNByCDqetLBNrxPJXoouoIKFaDKBEvBHmXcTwqMPYcLQuvhPQbaLfVXatwLZAHlrXDGubFCgSfiXFNESgznqDuQCsBJdphDzGzVOIJYKcZkmbRCjA");

    if (hKqkBb == string("qHEvxKdrVCGxqOKucAJuDRiHeNaegwXdiOdoIyIznaheuuKICYjWytErbScPQVYiWkRvUKBJeDSrVRTbUYQNJLVohWBKRYVHsaBxjeUCoAcCtFJceXgNNIeVQhAXPDWQXDxnOSriIViGckhnFzVWsCnvVybVpoivOKYTNqdIzyCXNjdWCbSpWPKIFvXsyphnFjgpSvBKjvGpOtlGzdmejVHNF")) {
        for (int DWxnXu = 1052670519; DWxnXu > 0; DWxnXu--) {
            ipNoAQfzJsbL = hKqkBb;
        }
    }

    if (ipNoAQfzJsbL <= string("qHEvxKdrVCGxqOKucAJuDRiHeNaegwXdiOdoIyIznaheuuKICYjWytErbScPQVYiWkRvUKBJeDSrVRTbUYQNJLVohWBKRYVHsaBxjeUCoAcCtFJceXgNNIeVQhAXPDWQXDxnOSriIViGckhnFzVWsCnvVybVpoivOKYTNqdIzyCXNjdWCbSpWPKIFvXsyphnFjgpSvBKjvGpOtlGzdmejVHNF")) {
        for (int AmnAtqy = 1681157602; AmnAtqy > 0; AmnAtqy--) {
            hKqkBb = QtYfUOKkHYJKNuu;
            hKqkBb = ipNoAQfzJsbL;
            hKqkBb += hKqkBb;
            hKqkBb += hKqkBb;
            hKqkBb = QtYfUOKkHYJKNuu;
            ipNoAQfzJsbL += QtYfUOKkHYJKNuu;
        }
    }

    for (int dHbfWkU = 1718228486; dHbfWkU > 0; dHbfWkU--) {
        ipNoAQfzJsbL = ipNoAQfzJsbL;
    }
}

int YqwawpdIMb::fXYYvzCmMfagVrD(int VqPFecLU, int DpCcYDAYnAOCP, double rwwDBhDsMOmWle)
{
    double sRMcVHiZJOU = 734766.9194429754;
    double VyVhue = -827516.2665213738;
    string qsinVS = string("mLryITyVrxdNLAtemBjPOfUhMNIDUImgojeJyEJHPoFtScEiJGUoCzJJAklFVnyj");
    double xifIeFjpvWcd = -118235.86098931699;
    bool KKjqitkxGCYidSTc = true;
    bool PRBXna = false;
    bool fwrHPJoOxn = true;

    for (int XpcQcaRRLRGDYrmG = 1670031315; XpcQcaRRLRGDYrmG > 0; XpcQcaRRLRGDYrmG--) {
        fwrHPJoOxn = ! fwrHPJoOxn;
        DpCcYDAYnAOCP = VqPFecLU;
    }

    for (int YMEXYDHpUG = 616181295; YMEXYDHpUG > 0; YMEXYDHpUG--) {
        PRBXna = ! KKjqitkxGCYidSTc;
        rwwDBhDsMOmWle *= VyVhue;
        xifIeFjpvWcd += VyVhue;
    }

    for (int moxceztdnEnhurcW = 1566824267; moxceztdnEnhurcW > 0; moxceztdnEnhurcW--) {
        VyVhue = VyVhue;
        fwrHPJoOxn = ! PRBXna;
    }

    for (int TqwQZAGPgf = 1765524159; TqwQZAGPgf > 0; TqwQZAGPgf--) {
        sRMcVHiZJOU /= xifIeFjpvWcd;
    }

    return DpCcYDAYnAOCP;
}

string YqwawpdIMb::wIoGAzvP(bool HPITXvJTk)
{
    double XuuPLb = 929123.0264404132;
    int imXYVywKvICYVA = 1218836884;
    bool PlfTgEArjgcA = false;
    double uHkXpJ = 705999.5317379213;
    string uXkRLHTzRqVIzk = string("vkMXMdwabJaxyMBTIgHRYziVctGrvKXtRKbusMZCLbhtHNAhMGLXPFPYrSErfryzZKPDbIOZzcJblReyMzNzrdoTCGXpeFOePpKR");
    int YcvjmopRlIGODlU = -1015389477;
    bool eSvKkTmzRkt = true;

    return uXkRLHTzRqVIzk;
}

double YqwawpdIMb::LEhKlAmPSvplalkJ(double kUisEe, bool KgnUjFzaPXoi, double uvAhnGDaLsIIT, double EIJlYPRhaKLBOg)
{
    double oARxS = -582208.2375357967;
    int fgLEtRwvOEmzlhCC = 1379017376;
    int WqcXHUQOnXEm = -1716727156;
    int rTXZSgTbOi = -2060344322;
    bool UDfHBzbS = false;
    double XgffjetFRQlIsSJV = 466389.00306838774;
    string vdfJhPkdUgRNN = string("axaAXGjXdWBeTzsaXFJwWisbptcIuQSNaqkhYMYcjhNiTNxGivQWYpoQEZYBnBiylnrevdqetyCLljGQDotqyvPGREpwzfTHLyxcBFMWMuItQEdJApOHeiRCuFYMtlcXcpuBLtrGMqlnjrzrIMKPDpTnEFPsdHKOEM");
    double KFrnbJZwpA = 914596.9780172304;
    double Lwbpquj = -250374.55182648625;
    double cwYRtqw = 1002769.3752607732;

    for (int ZEbwRuT = 495642799; ZEbwRuT > 0; ZEbwRuT--) {
        continue;
    }

    if (Lwbpquj != 60203.27061876882) {
        for (int CakHdlcFw = 938281419; CakHdlcFw > 0; CakHdlcFw--) {
            cwYRtqw += EIJlYPRhaKLBOg;
        }
    }

    for (int qAkgGYYdUZm = 1321209261; qAkgGYYdUZm > 0; qAkgGYYdUZm--) {
        KFrnbJZwpA /= cwYRtqw;
        Lwbpquj -= oARxS;
        Lwbpquj += kUisEe;
    }

    for (int ZKgtbGihr = 666841932; ZKgtbGihr > 0; ZKgtbGihr--) {
        uvAhnGDaLsIIT *= oARxS;
    }

    return cwYRtqw;
}

YqwawpdIMb::YqwawpdIMb()
{
    this->iPbpLqrxDRxmQW(false, string("CeRLzXLtEiVZWsMUmUGvReVlDXQDXmneDkqFMSzPqKhyZFMCnUsccwTZwoaiLWgAxEAVYSpDSErvEMEAfrfivcSpoNH"), -1627609125);
    this->qmAHUuJqiKPx();
    this->uTNMApZMBmSKJsG(-514885.8584349122);
    this->PYkZAgqPormavtO(-1719560456, string("rLezvmMINkRyVFmweoiQkKFGOpGUdArraFPyUOrQmUbxwtEzHLQKJovCdqlmbDmFHmXMmqXDKnQucacYgAOhLpnwhGUkPRTM"));
    this->yhkZb(183577204, false, string("qHEvxKdrVCGxqOKucAJuDRiHeNaegwXdiOdoIyIznaheuuKICYjWytErbScPQVYiWkRvUKBJeDSrVRTbUYQNJLVohWBKRYVHsaBxjeUCoAcCtFJceXgNNIeVQhAXPDWQXDxnOSriIViGckhnFzVWsCnvVybVpoivOKYTNqdIzyCXNjdWCbSpWPKIFvXsyphnFjgpSvBKjvGpOtlGzdmejVHNF"), string("zbNBChAoXkrXFdFTdoKGZfMobYiFtYVwyVVrTjAfsIEhNeELqqZncBYCZBNhphCXiPHcjhuxsBPpXAcmfvwNSgrXOsVupuMHrsgZHhBzmLucJMTuSgiIqbsMXtPDCUgMclnGPzZacOjyobYmhyuqENI"));
    this->fXYYvzCmMfagVrD(250184348, 1307168577, -388827.10585248994);
    this->wIoGAzvP(false);
    this->LEhKlAmPSvplalkJ(1011827.3897404297, true, 259631.15993841804, 60203.27061876882);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ULCylXgZSxj
{
public:
    int lxOrekciIM;
    int ZrkcJBvt;
    double PlgTEGUBJ;
    double WrjDcEbsbzPytqz;
    double PxgqkWQUngiN;
    int UCdXBptQM;

    ULCylXgZSxj();
    void XtmEcQTMuV(double UGIPIeeDpRuAI, string ETCrvzILdgk, double RtvkUAnCcP, double SRATwjDiVSl, double ZKZsBbq);
    double AmzRCiBUF(string YUUdRbWkEPHFT, double SiskCB, int QlSToEuFnUSqWKS);
    bool tJzOFXsxXDqSWk(bool MPufwZqCofaoDvc);
    void fFcsaaSgRTvaDH(int uTnZghZD, double obupmVndHLRR, int xkdWfCdCSvEakQ);
    bool LvHfkIlgw();
    void IFeyWeLJohVZWE(double vfrSBDDHFBkdDXjr, int DiRDON, int SGoIY);
    string vyiDAfqCLERFRm(bool sIjquX, double mDcufH, int NBIiLanwyPxa, double oBKOHqvzFLzGOqM, double GBAztDWGbWcI);
    void iFPVOZLSyCvHazf(double teGkfzFRQUgWcKqA, int rUMVCEB);
protected:
    string NobjfgwRjUCNUJc;
    double AijlcfKiR;
    string VmbFtYoLU;

private:
    string OZmJobFagnDl;
    double HRozkPTG;
    double AbWryYZE;

    void DhGRnX(string gbTTiJjjjqsmu, double RugNhAm, int ETdEnvHVcM, double yYBcSNFMMVOYeouy, int IIOcbpjZ);
    string cPIQDlE(double hFPMhrw, double qFyIwoTU, string kxORhwbeCIWMLHFw, double icASwDvnjk);
};

void ULCylXgZSxj::XtmEcQTMuV(double UGIPIeeDpRuAI, string ETCrvzILdgk, double RtvkUAnCcP, double SRATwjDiVSl, double ZKZsBbq)
{
    string lwheRsnb = string("q");
    bool jCgLoYAIWI = false;
    double wvnTTfup = -329237.44576122856;
    int RKqHbfleesbv = 1227378312;
    string gXCZPI = string("JkouTZTwmwuJMjyafpKhw");
    string XsxDuLLrtWR = string("KrHulvxaXsnLNuWvXMsdfUkgaHXFQkUppyXmEhFEwMOylJMSWhedckBOHfJMXHmMdmRvjShNHvoArvyVbaPSvySHylJGrkrdeyWAxlXmPcKphjRGkhcuxAwdDBisjhAXuUqiOoDdehiqIuIcGOFqArqcWUAPrFrMtKYfhTVHFWdDeuvkwxXlpnKnYCpA");
    double dGoyRdsDXWMTwc = -847375.2978666228;
    double ygnpVfTlANJEDsI = -580423.2089897329;

    for (int fIIWCkziD = 1775306715; fIIWCkziD > 0; fIIWCkziD--) {
        ZKZsBbq -= wvnTTfup;
    }

    for (int LvZamUMxEzko = 1349597954; LvZamUMxEzko > 0; LvZamUMxEzko--) {
        continue;
    }

    if (RtvkUAnCcP < -329237.44576122856) {
        for (int vidzuZShbeQX = 994033349; vidzuZShbeQX > 0; vidzuZShbeQX--) {
            wvnTTfup /= RtvkUAnCcP;
            UGIPIeeDpRuAI += RtvkUAnCcP;
        }
    }

    for (int hrXbugZGgMqOhD = 1903449696; hrXbugZGgMqOhD > 0; hrXbugZGgMqOhD--) {
        lwheRsnb = ETCrvzILdgk;
        wvnTTfup *= dGoyRdsDXWMTwc;
    }

    for (int tErAsb = 1448760858; tErAsb > 0; tErAsb--) {
        ETCrvzILdgk += gXCZPI;
        XsxDuLLrtWR += XsxDuLLrtWR;
    }

    if (SRATwjDiVSl <= 570370.8507215903) {
        for (int mEJcvZ = 1762333462; mEJcvZ > 0; mEJcvZ--) {
            ZKZsBbq /= ZKZsBbq;
        }
    }

    for (int qyHjfXkqWCvJ = 1706435357; qyHjfXkqWCvJ > 0; qyHjfXkqWCvJ--) {
        gXCZPI = lwheRsnb;
        SRATwjDiVSl *= wvnTTfup;
        ygnpVfTlANJEDsI -= wvnTTfup;
        wvnTTfup = dGoyRdsDXWMTwc;
    }
}

double ULCylXgZSxj::AmzRCiBUF(string YUUdRbWkEPHFT, double SiskCB, int QlSToEuFnUSqWKS)
{
    int NdRmfBaVBbZUDv = -398794469;
    int qsErrlWAhGgXCcJ = -460037200;
    string kYUqIyE = string("eCdlvrbDsgUFjGpzDDdQzQzmWRxidZwspyzRfflYpEVNvnbmgtNpTefNukwsOKbxCrpbQjyhnFumnOjajmilNkYOeMdcCfCkztwwPvRVRUxUClWRFQMLqNicAETwZHbEbESKylqMFFZKiQDdAJixUQyCImoGjuKummhlorHPExbQNacpjnAVKVuQWxEcLwbqrVcFjEbXaQqqbEuNCFsBDzBXFUAULFMGIAx");
    bool TVHfKgopjIu = true;
    bool NiwfpUSJdowweg = true;
    int fgfcuPJid = -202979914;
    double hoGJGWwcME = 151893.73308989013;
    bool GEctMBoZfjJD = false;
    string WEucOfmqh = string("zQonfNWYFgDevJkGksNIDukSrLUCdCaJdkeGMPOMJuYyWcZxnYOwAfUCngpDdKzGyKiOVZqtVNsvqvbEEtVLrFcXHUFAnNHKyFmiVyEZvKAAXenmmA");
    int nvHwrWOOlZErfmjt = -1887272663;

    for (int qVaQdfPhbU = 977363474; qVaQdfPhbU > 0; qVaQdfPhbU--) {
        continue;
    }

    if (hoGJGWwcME != 151893.73308989013) {
        for (int CooTcnshnkFMU = 1466348494; CooTcnshnkFMU > 0; CooTcnshnkFMU--) {
            nvHwrWOOlZErfmjt = fgfcuPJid;
            fgfcuPJid -= qsErrlWAhGgXCcJ;
            TVHfKgopjIu = ! GEctMBoZfjJD;
        }
    }

    for (int aCRADoPLF = 669169694; aCRADoPLF > 0; aCRADoPLF--) {
        NdRmfBaVBbZUDv /= QlSToEuFnUSqWKS;
        fgfcuPJid -= fgfcuPJid;
        nvHwrWOOlZErfmjt += qsErrlWAhGgXCcJ;
        YUUdRbWkEPHFT += WEucOfmqh;
        qsErrlWAhGgXCcJ = qsErrlWAhGgXCcJ;
    }

    return hoGJGWwcME;
}

bool ULCylXgZSxj::tJzOFXsxXDqSWk(bool MPufwZqCofaoDvc)
{
    string WHXVoiMhZyiJ = string("sFngWRcZsIPuntiYHFwACxWNvNdlNKaLpvYXBVWQdEQqRPUGVcFITkefFZDSTYbePy");
    bool EVVpEzNMaZDgoJBl = true;
    string AgqkCZdHOLEdMukc = string("aiXnssoMUONaQPAmLdvPWZaonNWxkrj");

    if (EVVpEzNMaZDgoJBl != true) {
        for (int hplGDNLIpCHzWV = 1140774205; hplGDNLIpCHzWV > 0; hplGDNLIpCHzWV--) {
            WHXVoiMhZyiJ += WHXVoiMhZyiJ;
            MPufwZqCofaoDvc = EVVpEzNMaZDgoJBl;
        }
    }

    if (AgqkCZdHOLEdMukc > string("sFngWRcZsIPuntiYHFwACxWNvNdlNKaLpvYXBVWQdEQqRPUGVcFITkefFZDSTYbePy")) {
        for (int uXlrKlRanQ = 274226519; uXlrKlRanQ > 0; uXlrKlRanQ--) {
            WHXVoiMhZyiJ = WHXVoiMhZyiJ;
            EVVpEzNMaZDgoJBl = MPufwZqCofaoDvc;
            MPufwZqCofaoDvc = MPufwZqCofaoDvc;
            AgqkCZdHOLEdMukc = AgqkCZdHOLEdMukc;
        }
    }

    if (EVVpEzNMaZDgoJBl != true) {
        for (int rcJlOKv = 1551916747; rcJlOKv > 0; rcJlOKv--) {
            EVVpEzNMaZDgoJBl = ! EVVpEzNMaZDgoJBl;
        }
    }

    return EVVpEzNMaZDgoJBl;
}

void ULCylXgZSxj::fFcsaaSgRTvaDH(int uTnZghZD, double obupmVndHLRR, int xkdWfCdCSvEakQ)
{
    bool xTsDzFiEIryweOip = true;

    if (obupmVndHLRR >= 543367.8745319484) {
        for (int cmKeCalYITOILCL = 2037806207; cmKeCalYITOILCL > 0; cmKeCalYITOILCL--) {
            continue;
        }
    }

    for (int NfmPQZGRn = 849041426; NfmPQZGRn > 0; NfmPQZGRn--) {
        uTnZghZD -= uTnZghZD;
        xTsDzFiEIryweOip = ! xTsDzFiEIryweOip;
        uTnZghZD -= xkdWfCdCSvEakQ;
    }

    for (int MlfVafQILAvg = 853574711; MlfVafQILAvg > 0; MlfVafQILAvg--) {
        xkdWfCdCSvEakQ -= xkdWfCdCSvEakQ;
    }
}

bool ULCylXgZSxj::LvHfkIlgw()
{
    double NhIfMEjMl = 734522.7158577571;
    double heZLsnnlIq = -36953.17040346788;
    string EPChuPXHcnEGM = string("GzMHpPMKZMhfmmsIJJiInVXgPnHrhVBGBElIXprqEixeunRfMYGVcSIHRBiyVYbFhdomwSzcpLulGJgauclepULSQSfAHEXtaNiAYREiCIwbYkmtAYcjRKZEicjKAMWjpVCCpDdjNWNZZbkSRiuSscGsuJaXv");
    bool eBldQzWwkcVsigSf = false;
    int KirGr = 1423230538;
    int VbrYVJPXNcAFbE = 412748244;
    double aNZueJsoPFFsrj = -862331.9055060323;
    string ZNfMCeuuUZuL = string("xlnEKUBuOkJJKAgRfuZrhbMaQTBIImmpySUoYErTlqTINUoycASWeOIPOQscpAvYktIoBvjtLrRTWWZcoRlRZetOJBoPddidkGxrMVbuJxxNuAmBaILmHCmfOSGqgOHNyHjQmvsoHlODwGySXxWHodTQLNTHmYoogjFAtXLejgbCBp");
    bool gkDRv = true;

    if (eBldQzWwkcVsigSf == true) {
        for (int mKFSprmMIDxuGx = 1575636968; mKFSprmMIDxuGx > 0; mKFSprmMIDxuGx--) {
            aNZueJsoPFFsrj -= heZLsnnlIq;
        }
    }

    for (int xbWfQwtR = 913291333; xbWfQwtR > 0; xbWfQwtR--) {
        KirGr -= KirGr;
        heZLsnnlIq *= NhIfMEjMl;
        KirGr *= KirGr;
        aNZueJsoPFFsrj *= aNZueJsoPFFsrj;
    }

    return gkDRv;
}

void ULCylXgZSxj::IFeyWeLJohVZWE(double vfrSBDDHFBkdDXjr, int DiRDON, int SGoIY)
{
    double QoTvcrismPMIV = -238250.05218402424;
    int oZXFaLSgVBn = -541965565;
    bool iPPpcsvyaWKFd = false;
    string xTfwLLgffyweunLz = string("QmzZDxSbaMhavcWVLklGoVqArRlMTcAhfXKtLRekpYdYbNHrEkcAiguggDiXmKhvbYJCaVajQXhydOOfcnCzYigZIaQvbicwwNFsbEJOONeIfDqTDofIghIfAmQXwiCmCRvyPAGsfqMBonoJsRvCtquFggkGdreetoTAiwDhNLmBeHIiUUtKEdmgkamkBaamKKpYJoSsBWTokLerJifHkdnkBYMrpBVYkCcOlXZobTgotCIRzmLjcOVMgNJYul");
    double jNZRS = -650288.871602893;

    for (int HBbYbCxEm = 1040814283; HBbYbCxEm > 0; HBbYbCxEm--) {
        DiRDON *= SGoIY;
        QoTvcrismPMIV *= jNZRS;
    }

    for (int ZgiRK = 2098514369; ZgiRK > 0; ZgiRK--) {
        continue;
    }

    if (xTfwLLgffyweunLz >= string("QmzZDxSbaMhavcWVLklGoVqArRlMTcAhfXKtLRekpYdYbNHrEkcAiguggDiXmKhvbYJCaVajQXhydOOfcnCzYigZIaQvbicwwNFsbEJOONeIfDqTDofIghIfAmQXwiCmCRvyPAGsfqMBonoJsRvCtquFggkGdreetoTAiwDhNLmBeHIiUUtKEdmgkamkBaamKKpYJoSsBWTokLerJifHkdnkBYMrpBVYkCcOlXZobTgotCIRzmLjcOVMgNJYul")) {
        for (int ivBRd = 492290024; ivBRd > 0; ivBRd--) {
            DiRDON /= DiRDON;
            QoTvcrismPMIV += jNZRS;
        }
    }
}

string ULCylXgZSxj::vyiDAfqCLERFRm(bool sIjquX, double mDcufH, int NBIiLanwyPxa, double oBKOHqvzFLzGOqM, double GBAztDWGbWcI)
{
    bool keWmPHERLEZM = true;

    if (keWmPHERLEZM == true) {
        for (int vUrhOSVPfYxB = 1069820696; vUrhOSVPfYxB > 0; vUrhOSVPfYxB--) {
            GBAztDWGbWcI = mDcufH;
        }
    }

    if (sIjquX == true) {
        for (int EEwtzTZJbhjIsIig = 415561447; EEwtzTZJbhjIsIig > 0; EEwtzTZJbhjIsIig--) {
            oBKOHqvzFLzGOqM *= mDcufH;
            mDcufH += mDcufH;
        }
    }

    if (GBAztDWGbWcI == -337445.4330103743) {
        for (int GQXQAD = 123722460; GQXQAD > 0; GQXQAD--) {
            mDcufH *= mDcufH;
            keWmPHERLEZM = sIjquX;
        }
    }

    return string("GsUxmVGvdDflMENSFekeERXTPVFOFJEdDfFTQpdzhxgCqXURDYEXNMcSlFCNPeLtkOhaGOMtMElMaTLCuKMtXdoMtnBCcbGdjxKGTimPYcrVHtrzyCVPHRbDFKodjwbZlYsdXWSrkaQGnVTKQoAKscvpTSRIShfBpdghljSaJE");
}

void ULCylXgZSxj::iFPVOZLSyCvHazf(double teGkfzFRQUgWcKqA, int rUMVCEB)
{
    double PAKOnptadHoEUHPk = -625768.8510316054;
    double eTNPTTykqkBhZs = -90532.44820935406;
    bool hFeLR = false;
    bool ORhwEoxqppkmG = true;
    string JwAYx = string("yTlMyaMQrpaLMPIEiuhoghZHGLfZWzRSxUQNcUVRjxWeFgzTloCAcfLkuiNoBUgQsQwCgUVfNJXsWLBbklpRPtgCHkrbSRZeZOFVGMvvbWMNtMrFZkbw");
    int xvVIeUnfrLclJHw = -1181633742;

    for (int FmcHMpQnLSCEN = 1561778748; FmcHMpQnLSCEN > 0; FmcHMpQnLSCEN--) {
        PAKOnptadHoEUHPk = eTNPTTykqkBhZs;
    }

    for (int MPuaROcVFoTtVy = 1916545173; MPuaROcVFoTtVy > 0; MPuaROcVFoTtVy--) {
        xvVIeUnfrLclJHw /= rUMVCEB;
    }

    for (int BDIKo = 105719826; BDIKo > 0; BDIKo--) {
        continue;
    }

    for (int XmnvFxqoc = 2076384603; XmnvFxqoc > 0; XmnvFxqoc--) {
        continue;
    }

    for (int yXNUNjALLuZY = 530670529; yXNUNjALLuZY > 0; yXNUNjALLuZY--) {
        continue;
    }

    for (int HbxuFPAokAeIm = 651741616; HbxuFPAokAeIm > 0; HbxuFPAokAeIm--) {
        PAKOnptadHoEUHPk = PAKOnptadHoEUHPk;
    }

    for (int NhIXnvAwHIqPcxw = 225180264; NhIXnvAwHIqPcxw > 0; NhIXnvAwHIqPcxw--) {
        hFeLR = ! hFeLR;
        eTNPTTykqkBhZs -= eTNPTTykqkBhZs;
        rUMVCEB *= rUMVCEB;
    }

    for (int rdvrRzQryoxCgTY = 2064633965; rdvrRzQryoxCgTY > 0; rdvrRzQryoxCgTY--) {
        teGkfzFRQUgWcKqA /= teGkfzFRQUgWcKqA;
    }

    if (xvVIeUnfrLclJHw <= -1181633742) {
        for (int tzKDyUssKxGVLGlQ = 1550910558; tzKDyUssKxGVLGlQ > 0; tzKDyUssKxGVLGlQ--) {
            rUMVCEB = xvVIeUnfrLclJHw;
            teGkfzFRQUgWcKqA *= PAKOnptadHoEUHPk;
        }
    }
}

void ULCylXgZSxj::DhGRnX(string gbTTiJjjjqsmu, double RugNhAm, int ETdEnvHVcM, double yYBcSNFMMVOYeouy, int IIOcbpjZ)
{
    double SqxvtMGlqInUN = -491151.59765365894;
    int xnFgLZlGF = 1522623453;
    int eNxCXsOFns = -376757360;
    string prjyiO = string("cSkhOlXFsZaQwmhVqubPMqrzSMiloWKHFfchavGDrusimOsZusPWAvMcFhBRgYtYcLDHIipxlPRvMFSHMPVumoRxBLMFhbthXyNQJzjnTyFNFUGIAhJdfuTCbgEvyJXthPzPEpcyYKIxfijkVCIApGUTrxl");
    double KfPwUduabQZ = 466687.00937605667;
    string eKlIsNNHY = string("LNnnEKwIzAWNFOTBdOnJFFyAJ");
    string xllhljWvUBO = string("tXZmphlQrbEykNuBqIPDgSsMixNFjeGygGbSdLkVZaFwFxDKo");
    string xIwNqVxHzP = string("TZOXPTmhJDRSiwxykPVDuDvIWggkayiFUlljkGdWWxeqOUFzWEVjdVzVSMrGxvwXnOAstzDRDWXSQPhhxteHVziggWspcTxNaLRBAFZjIYAqcPPDXRlQuAFMQSrovTBYMzSKWupCjufrlvIpTnEAkyQLDWxgEKzseRpVQqqiSOaoWfDZHRFZfpudFdJcUwXKjUaXVtOzdBTiamAYWhCeFKwJeLPTLXYMhjRQSOLmkYgaqTDWAF");
    int cXjlkdUgHhqsXMo = 25241951;
    bool xxptpRkChS = false;
}

string ULCylXgZSxj::cPIQDlE(double hFPMhrw, double qFyIwoTU, string kxORhwbeCIWMLHFw, double icASwDvnjk)
{
    string eooSkEqCtuIfI = string("YkAlqLfyniwWafqbnkhPUlJKzFAJLLATWyMMyZSByrhHsGZbmWvNUoTxXRZflvtdyx");
    double oXHYZDFMHDYeQLcq = -345680.50269310933;
    bool skjfzPiozmGqbwre = false;
    int kYhQPa = 1065100407;
    int ZuqWu = -1593332090;
    double llLOHstDlJDWm = 268047.4592399827;

    for (int XSjgZhAatcfqBI = 94723508; XSjgZhAatcfqBI > 0; XSjgZhAatcfqBI--) {
        llLOHstDlJDWm += oXHYZDFMHDYeQLcq;
        icASwDvnjk = llLOHstDlJDWm;
    }

    for (int lxJLRzFGnltvbISq = 1245921289; lxJLRzFGnltvbISq > 0; lxJLRzFGnltvbISq--) {
        continue;
    }

    return eooSkEqCtuIfI;
}

ULCylXgZSxj::ULCylXgZSxj()
{
    this->XtmEcQTMuV(-99172.46676489641, string("nkQsALztFyusUMUCoqesumadbbPhdViCcGlafJfDHHESuXNiuAztLWXshGCdVQmLHyWfbHHXPxnuZDNkhQfLCAlkdQEbRntIAPIHwHgAALezZQyjmPcrWG"), 123830.78368991338, -209300.60959969225, 570370.8507215903);
    this->AmzRCiBUF(string("jYyAjCvOrbvFwhBjGkJOsuBKkgQGVnEQWprQuZZROyeJCnSIcGBfDpXrGocgnMuQhmUcIYQGaSpNBBvWeYnUdHopasohORSLCEXcRyCpMtJkYxYOvIlIGKlidsGNIMdOjIUiZBTohlTmjzvVRdxIBUtGGKfPoFbGEBPHdMgTojxTtDyZULUTlnVgkQYyWXrtXQvqttiABxxhUGZtBDWvQvDetRNoGeDDvRoHPS"), 21238.066617790224, -809712023);
    this->tJzOFXsxXDqSWk(true);
    this->fFcsaaSgRTvaDH(-1103712896, 543367.8745319484, -48688374);
    this->LvHfkIlgw();
    this->IFeyWeLJohVZWE(930067.4483482727, 315988164, -821592883);
    this->vyiDAfqCLERFRm(true, -997406.3134997013, -1605593907, 739608.179066633, -337445.4330103743);
    this->iFPVOZLSyCvHazf(992848.0827851915, -1605622295);
    this->DhGRnX(string("KrYfEpRXprhCvMMKDJzOIHGnclkePULKhJSLkZOwHLpeWYIiGgqnaHgVkEKP"), 918850.8153051173, 862243884, 854434.99999255, 98458544);
    this->cPIQDlE(-677789.6839141549, -211492.56136133737, string("ZVPSNMVQgpYactupTbpntbkChiZmSEPzrwTlEkgDkIaIqELTuCIQMBCgJyvNDpHRepkQgBvWRjBbzJwIEThjGehRNBYMGRZjsROHibSIsDnAzSiKwFCNiBXfmEtVgsorkqYPxyjRNpxVNiviJfPvvRSDARmPjBeFEsncBiLXIhCuqLqvlsbwkxjzWbjxAOldoKAlAaFgoWYHRiHdvfwjqMiMfBrLMPJlJbdUqrPQTJBRpRPFzgkvVjiCTBO"), -595503.2636126492);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WVsmk
{
public:
    bool BAeXqX;
    int iUkFvBeMfgd;
    int HBklTHiwzLYuogSJ;

    WVsmk();
    int vyOvqtlLiFDYc(string kfuDU, string WahrBdSqqbFWnXf);
    int HpsWaHufZlr(string BLwzcv, bool fafIjmiSaQJTOf, double qiDAKUhYF);
    bool IHRMXkmdABVoK(double jQfZjMFqsYzOdYVC, double DjKNzueulwfgpdge, bool prCgDCslkFLD, int ZGrPXuKAySpn);
    string tnPiP(string slKuqLBbTgWsO, double IoxtKnQPHTST);
    double CZUMcXa(double LEgjrHOkDf, double MQteanITGOjGThaU, string EfiwaYmk, int alVjskPWMxnoIm);
    string QQbaDyL(string CDgsnMS, bool olbmnomAaIHPYU, bool qcdUBlLJ, double tqQEJvYCbYaYiZ);
protected:
    bool HdDHLFGolsIzjPZJ;
    bool ZXDrotLgCkH;
    string zkKIJCGEdzh;

    double sqTWtGaPWWtuoMV(bool vlhjxh, double pKolNvqDUE, int CNpBdQ, double IQlTNqvp);
    int CnziGrAxYEtsSw(double VNRoFfqMh, string zsnWXvIOklwoaB);
    bool hsfPvEXAMC(int bVebrShxdIIul, int OkhATEzlUXA, string IKUisnCFkiSCXImk);
    string saKDUIeFbpwLfOZ(double eAYlMCzv);
    int qqUIGfcGJp();
    bool qjoxQ(double iPsSiYUeMaFDY, string iIuKObFLMXi, int PxGOH);
private:
    string EkdMqpBRhQQSYt;
    string LvvUqyZaVMsO;
    double MrRNKfuN;
    string jjkBoTFVBfUYAf;
    bool MMrGKZokYpGUCrE;

    string stzKSE(int ywlvnF);
    void IvNEPSJLHomhk(double OfAMRRNYZuR, bool jYrIYXXhGYVKddA, bool rdzTSgElcA, bool UeLCyFQsIEAJPd);
    void bUJlxotc(string bgrYULYx, int jutaANlLfQ, bool acHDXNfbBU, double CwZZOIWEI);
    int ubfLwkLofQU(string vBGrbPn, bool HiQHhIdyWX);
    void RxWXAerOKS(bool QinBEJbjZsI);
    string xYZJr(string WZcFVpZaFv, string bZaRECf, int hByaIfQEsLPFyF);
    string ERRHXX(double YWrvbdbK, bool FAIBqDDdrGr, double FTkMxZPdMLR);
    string qfxOa(int mbaAtbiRcNe, string liKKpcC);
};

int WVsmk::vyOvqtlLiFDYc(string kfuDU, string WahrBdSqqbFWnXf)
{
    bool DOuruSGLlr = false;
    int oMFAihoFDY = -917642814;
    double TRgWDPXW = -1032046.955148534;
    string OQpXFkt = string("YuemaBsfwokSTxCdpHcXKAuDzzUIRddRTnlKYoMdHODF");

    for (int MBRTPCrcir = 1960397243; MBRTPCrcir > 0; MBRTPCrcir--) {
        continue;
    }

    return oMFAihoFDY;
}

int WVsmk::HpsWaHufZlr(string BLwzcv, bool fafIjmiSaQJTOf, double qiDAKUhYF)
{
    bool HaBdY = true;
    string RPjEMGiRyXkHOwX = string("zrNLGzIBgwIpazzxTrxyKxYKUfOzvhAmPSrAcionxfDoDfJxLqwXTeyLRhtulFzErJjWZfLrmbJXwaABGATqtbSiOJMJQLQzoktMASZsazvIqGyhoLbgSBKQIzHCyGDswwMZyRAWlIEtkbkuomHuYdJwpshqxoYEbTDYfzKDsGqXf");
    double fIhgGXgqQEEiVKmW = 502366.1189106177;
    double wtQmsxyRp = 643725.7886175767;

    if (fafIjmiSaQJTOf != true) {
        for (int KYKLylLo = 1086458874; KYKLylLo > 0; KYKLylLo--) {
            RPjEMGiRyXkHOwX += RPjEMGiRyXkHOwX;
            wtQmsxyRp -= qiDAKUhYF;
        }
    }

    if (fIhgGXgqQEEiVKmW != 643725.7886175767) {
        for (int oLfnqIkecHT = 1772767179; oLfnqIkecHT > 0; oLfnqIkecHT--) {
            RPjEMGiRyXkHOwX += RPjEMGiRyXkHOwX;
        }
    }

    for (int pWtZPtry = 635780201; pWtZPtry > 0; pWtZPtry--) {
        wtQmsxyRp *= qiDAKUhYF;
        fafIjmiSaQJTOf = ! fafIjmiSaQJTOf;
        HaBdY = fafIjmiSaQJTOf;
    }

    for (int dGHDQ = 538997728; dGHDQ > 0; dGHDQ--) {
        wtQmsxyRp *= fIhgGXgqQEEiVKmW;
        RPjEMGiRyXkHOwX += RPjEMGiRyXkHOwX;
    }

    if (wtQmsxyRp == 73073.07924126906) {
        for (int aOLyuDafDGDnmPT = 2012071265; aOLyuDafDGDnmPT > 0; aOLyuDafDGDnmPT--) {
            fafIjmiSaQJTOf = ! fafIjmiSaQJTOf;
            RPjEMGiRyXkHOwX += BLwzcv;
        }
    }

    return 987534138;
}

bool WVsmk::IHRMXkmdABVoK(double jQfZjMFqsYzOdYVC, double DjKNzueulwfgpdge, bool prCgDCslkFLD, int ZGrPXuKAySpn)
{
    int JsmpvtaHVLGDY = 1398374762;

    for (int CndnTEFhky = 1695576794; CndnTEFhky > 0; CndnTEFhky--) {
        JsmpvtaHVLGDY *= ZGrPXuKAySpn;
        JsmpvtaHVLGDY /= ZGrPXuKAySpn;
        ZGrPXuKAySpn = ZGrPXuKAySpn;
    }

    if (jQfZjMFqsYzOdYVC > 295828.13267037616) {
        for (int kjPDJFEMxWch = 2030457785; kjPDJFEMxWch > 0; kjPDJFEMxWch--) {
            JsmpvtaHVLGDY += JsmpvtaHVLGDY;
        }
    }

    return prCgDCslkFLD;
}

string WVsmk::tnPiP(string slKuqLBbTgWsO, double IoxtKnQPHTST)
{
    string jNWtEqnOjbpPIiZ = string("HCYOOSvUkXIHUtpGEJhMVDbjYPnHYBQNiTYKriutDonyGVHOAoGWmHtjAAlyOygFJSdgFdJmeliSmvhSztEPRjEONeGueKLaAcNITwokqGMzeneneKbNRWYEHuQNppOBC");
    int cojjlPmuHOuUPIYt = 184302785;
    double RmWXjkNkRk = 157626.48875909674;
    double mJlAuVfBCM = -41590.28638045987;
    string PobXQKJSlmuH = string("pkILFBTvajKoQHbnQgWFAgVoQkYQotfpJseLSBNwOIxQkIPQMfTTjLVXoLqHrMaWNykScpgirkGoygkatIXXHvWQPOcFawfsm");

    for (int GUdfDESyDCBa = 783734871; GUdfDESyDCBa > 0; GUdfDESyDCBa--) {
        slKuqLBbTgWsO = jNWtEqnOjbpPIiZ;
        RmWXjkNkRk += IoxtKnQPHTST;
        jNWtEqnOjbpPIiZ = slKuqLBbTgWsO;
    }

    if (jNWtEqnOjbpPIiZ >= string("pkILFBTvajKoQHbnQgWFAgVoQkYQotfpJseLSBNwOIxQkIPQMfTTjLVXoLqHrMaWNykScpgirkGoygkatIXXHvWQPOcFawfsm")) {
        for (int vnhNjxMXL = 81445901; vnhNjxMXL > 0; vnhNjxMXL--) {
            jNWtEqnOjbpPIiZ += PobXQKJSlmuH;
            IoxtKnQPHTST += RmWXjkNkRk;
            slKuqLBbTgWsO += PobXQKJSlmuH;
        }
    }

    return PobXQKJSlmuH;
}

double WVsmk::CZUMcXa(double LEgjrHOkDf, double MQteanITGOjGThaU, string EfiwaYmk, int alVjskPWMxnoIm)
{
    bool bHiGlfMfcsvooEG = true;
    double sWLhe = 55278.82870792405;
    string UqTatDI = string("lOTKIOKyUPRbsxbZEScOoHPFQcCUIFUDYnHCAgvMnRWPJQDOfocdgmdnhOnUJUMXyIOznRkgmoQksJEPxDRkhwiZbuoHtCfcGIlEpDwrh");
    int EQJymp = 2134749118;
    string LuRHKvZKvXxu = string("rGYVahNgUFBEpyrwptLguEUeFYiwINUEIpQTTzjbsEghQAGQDGEuqODGVdYzmqiEJpJyLXCbLtUTUUbstPQCVdJxDQNvtfWKkGTVjQDiiGIyuchzEfvkyXNLVsNGEGiZZwSCnfvSLyoqulXpKDzPHQPAisRpZtyHahDICdrtSFxiWRVcbaFIpSKoHXZEfHbbbKQj");

    for (int OLoUyTUgx = 2104930548; OLoUyTUgx > 0; OLoUyTUgx--) {
        EfiwaYmk = LuRHKvZKvXxu;
        MQteanITGOjGThaU = sWLhe;
        alVjskPWMxnoIm *= EQJymp;
    }

    return sWLhe;
}

string WVsmk::QQbaDyL(string CDgsnMS, bool olbmnomAaIHPYU, bool qcdUBlLJ, double tqQEJvYCbYaYiZ)
{
    bool dNXaITRL = true;
    int yViQuRSNxxdR = -1030158015;
    int BSHAltgYTwD = 236110510;
    int CewhgExQ = 1426397966;
    int hkLsbqDlpOSAF = 664417349;
    string YUDxlggmMUM = string("OAVTseycwxreKRjUMIVyrCkFORpOeWAnYEWUzlriOsTyxAxIrrUIKXEAlgFpNFBdJemkhRIEPdWoTbqhFeWApxcteypnKYWmEWfsOCWULifBTCAKRYiWBGAkctlrZDjoqMsRrnawtqG");

    for (int zzTLxs = 1531016732; zzTLxs > 0; zzTLxs--) {
        yViQuRSNxxdR += hkLsbqDlpOSAF;
    }

    if (CDgsnMS <= string("NcFHHnXCzzxlwIHDpMnHwOYHZrQNiuXRrxIbIQwVuHEqnttbyoLfrUauGJpcLNybnyaZdtEHBkDIBIblcozYbwrteqsIOIsMZBbCJHzgilUWVAQyJTJCrAPbQWZqrZPtrAXYHJabEuhgoqyXJFHEhabOjmTmnUAufQClYvPmeKhIjxCiVTetKiZyTjdEZJQAwSUSZkPzCQNNfFDOCHxj")) {
        for (int vGXlcpaqbH = 131812726; vGXlcpaqbH > 0; vGXlcpaqbH--) {
            BSHAltgYTwD += CewhgExQ;
            olbmnomAaIHPYU = ! qcdUBlLJ;
        }
    }

    if (qcdUBlLJ != true) {
        for (int yvcaNnUCPJn = 858739984; yvcaNnUCPJn > 0; yvcaNnUCPJn--) {
            CDgsnMS += CDgsnMS;
            CDgsnMS += CDgsnMS;
            yViQuRSNxxdR -= BSHAltgYTwD;
            qcdUBlLJ = olbmnomAaIHPYU;
        }
    }

    for (int rqZDHJnljHKPPZ = 1897635189; rqZDHJnljHKPPZ > 0; rqZDHJnljHKPPZ--) {
        continue;
    }

    for (int hmUkTfYPNFHpFPx = 929311243; hmUkTfYPNFHpFPx > 0; hmUkTfYPNFHpFPx--) {
        YUDxlggmMUM += CDgsnMS;
    }

    return YUDxlggmMUM;
}

double WVsmk::sqTWtGaPWWtuoMV(bool vlhjxh, double pKolNvqDUE, int CNpBdQ, double IQlTNqvp)
{
    int SagtXGncQZPDaf = -154267838;
    double YSkYUtVRxjYppz = -10351.829179094428;
    bool mzdCuuWMwYZ = false;
    int sppusBUe = -62998597;

    for (int Vsiqowe = 1927109017; Vsiqowe > 0; Vsiqowe--) {
        mzdCuuWMwYZ = vlhjxh;
        CNpBdQ -= SagtXGncQZPDaf;
    }

    for (int pcrULrX = 1940323262; pcrULrX > 0; pcrULrX--) {
        SagtXGncQZPDaf -= SagtXGncQZPDaf;
    }

    for (int iBlvB = 509623441; iBlvB > 0; iBlvB--) {
        YSkYUtVRxjYppz /= IQlTNqvp;
        vlhjxh = vlhjxh;
    }

    return YSkYUtVRxjYppz;
}

int WVsmk::CnziGrAxYEtsSw(double VNRoFfqMh, string zsnWXvIOklwoaB)
{
    bool aWQTOAxKNuzV = false;
    double NfTxLyuVXy = -622691.2748731339;

    if (NfTxLyuVXy == 756990.4433388856) {
        for (int IIvAEZprZBg = 1455912270; IIvAEZprZBg > 0; IIvAEZprZBg--) {
            zsnWXvIOklwoaB = zsnWXvIOklwoaB;
            NfTxLyuVXy += VNRoFfqMh;
        }
    }

    for (int ByqISZ = 2050665400; ByqISZ > 0; ByqISZ--) {
        NfTxLyuVXy += NfTxLyuVXy;
    }

    if (VNRoFfqMh <= 756990.4433388856) {
        for (int cTiSlYecfIqBLZ = 1422272327; cTiSlYecfIqBLZ > 0; cTiSlYecfIqBLZ--) {
            aWQTOAxKNuzV = ! aWQTOAxKNuzV;
        }
    }

    if (NfTxLyuVXy == -622691.2748731339) {
        for (int TjSaObWmjUcGEg = 714317965; TjSaObWmjUcGEg > 0; TjSaObWmjUcGEg--) {
            VNRoFfqMh = VNRoFfqMh;
            aWQTOAxKNuzV = ! aWQTOAxKNuzV;
            VNRoFfqMh -= VNRoFfqMh;
            NfTxLyuVXy = VNRoFfqMh;
        }
    }

    return -458284134;
}

bool WVsmk::hsfPvEXAMC(int bVebrShxdIIul, int OkhATEzlUXA, string IKUisnCFkiSCXImk)
{
    bool JtcfUU = true;
    string JwuwIZsESqgA = string("zYmrurrYDQkcrXbRcDGzoDyLJTWyBxyCsVdupSyiEfVAbzLMedSywPrHniqLwSCVsBFAAtEuxebqxAlVkyPgHtHOJumktXuGFOfnwaqLMOgVdxyZbLabxeOxLyPVsyvKxMqCAIpkBflpLzPomVEgKtwCrAEaAwzwwPtySbUwiyNJVGVUGtMsVrfyiojDfvccMqz");
    double ppxTv = -501920.58439626044;
    double INpJkPWjujtJMyGK = 481266.4597234571;
    double MTuNyiGrBohhm = -100840.29658083561;
    bool bWfJYqoXvztnXkAD = false;
    double FdDpQyxpCPqDC = 956867.0617747921;
    int qbgtFYRKz = 1509676905;
    bool AdVao = false;
    string uludILCdr = string("lVlZaqQPmsoDAaUhoamBVlmBQqSygYURzGTdKdvHqOpPyVUUwTthrMYSlDtTNqkZfggppSklAgarZoyRRdpMayNgKIpYgHPUacpZbIwlSIjGIqJdWMqWqlwYVJHwiuSgjxvUuJwmUGpBnSQeuFmAMhiYycmXQXcGeLpdlbgtEikvWeAtAEldlzBjHTxTIeTJoWsDwvgvurCSfmDCctSOwhw");

    for (int SfBvXtpAVOvYbgR = 1259593003; SfBvXtpAVOvYbgR > 0; SfBvXtpAVOvYbgR--) {
        continue;
    }

    for (int xfcnezZtbLKTDcRu = 1788847493; xfcnezZtbLKTDcRu > 0; xfcnezZtbLKTDcRu--) {
        FdDpQyxpCPqDC -= INpJkPWjujtJMyGK;
    }

    return AdVao;
}

string WVsmk::saKDUIeFbpwLfOZ(double eAYlMCzv)
{
    bool PIJvSoB = false;
    string BMNcnXg = string("NzwfAYbCUWfCZswMmbvDmMfRzYPgapsymwjoGOaAAgIpgDOWpFJPOGxUJiPEKQcUJhGlgZcZTzjjxFLoYFgtdPQlmJSlgmPuDuRVYGpRCmGNRGZhmDuxPnWVnsG");

    if (BMNcnXg < string("NzwfAYbCUWfCZswMmbvDmMfRzYPgapsymwjoGOaAAgIpgDOWpFJPOGxUJiPEKQcUJhGlgZcZTzjjxFLoYFgtdPQlmJSlgmPuDuRVYGpRCmGNRGZhmDuxPnWVnsG")) {
        for (int IFdGjTCvHO = 1052059540; IFdGjTCvHO > 0; IFdGjTCvHO--) {
            continue;
        }
    }

    for (int OdCtHRre = 643945362; OdCtHRre > 0; OdCtHRre--) {
        BMNcnXg += BMNcnXg;
        BMNcnXg += BMNcnXg;
    }

    return BMNcnXg;
}

int WVsmk::qqUIGfcGJp()
{
    double FODcgazgUM = -796959.8912728262;
    double dLWZDWdvmGkkgrCY = -8683.955253767603;
    double WYVLXDi = 441291.1332419287;
    double DkXhOdelJ = -390662.88564310566;
    string HvYUo = string("XwXdK");
    string LcFFTfIThjGAKLCr = string("IgLYgypAPUpGspuTDIlizlyQRsZlwCKZyAAvXPCKlxDserBrYkrnwFysgwSLDSMhgtVbhMuVLHYIRBjtSUIfqVgRosrLNwGFCEFCVwBrPrlyWxWIbFotcyzLFHhOyDAYjXsXPPYVbYPmlaqfvQeiljLRGgnCCMKZdLs");

    for (int jSIWgCjspFhG = 505451411; jSIWgCjspFhG > 0; jSIWgCjspFhG--) {
        WYVLXDi /= WYVLXDi;
        dLWZDWdvmGkkgrCY += WYVLXDi;
        FODcgazgUM = DkXhOdelJ;
    }

    for (int RTumbwKmmodqjPUE = 2139764480; RTumbwKmmodqjPUE > 0; RTumbwKmmodqjPUE--) {
        dLWZDWdvmGkkgrCY /= WYVLXDi;
    }

    for (int uLagIumhjdRECt = 1429244581; uLagIumhjdRECt > 0; uLagIumhjdRECt--) {
        FODcgazgUM *= WYVLXDi;
        dLWZDWdvmGkkgrCY /= dLWZDWdvmGkkgrCY;
        dLWZDWdvmGkkgrCY /= DkXhOdelJ;
    }

    if (WYVLXDi < -796959.8912728262) {
        for (int WAsGpheSlg = 1822281234; WAsGpheSlg > 0; WAsGpheSlg--) {
            WYVLXDi = dLWZDWdvmGkkgrCY;
            LcFFTfIThjGAKLCr += LcFFTfIThjGAKLCr;
            dLWZDWdvmGkkgrCY /= WYVLXDi;
            dLWZDWdvmGkkgrCY /= DkXhOdelJ;
            DkXhOdelJ *= WYVLXDi;
        }
    }

    if (WYVLXDi <= -390662.88564310566) {
        for (int BfvlDHAcSDhzeV = 1620590935; BfvlDHAcSDhzeV > 0; BfvlDHAcSDhzeV--) {
            DkXhOdelJ = DkXhOdelJ;
            DkXhOdelJ -= DkXhOdelJ;
            dLWZDWdvmGkkgrCY += DkXhOdelJ;
            FODcgazgUM -= dLWZDWdvmGkkgrCY;
            FODcgazgUM -= DkXhOdelJ;
            WYVLXDi -= dLWZDWdvmGkkgrCY;
            HvYUo += LcFFTfIThjGAKLCr;
        }
    }

    if (dLWZDWdvmGkkgrCY == -390662.88564310566) {
        for (int GFjKdq = 1059117473; GFjKdq > 0; GFjKdq--) {
            DkXhOdelJ += FODcgazgUM;
            dLWZDWdvmGkkgrCY -= dLWZDWdvmGkkgrCY;
            HvYUo = LcFFTfIThjGAKLCr;
            WYVLXDi *= FODcgazgUM;
            dLWZDWdvmGkkgrCY += dLWZDWdvmGkkgrCY;
        }
    }

    return -326911537;
}

bool WVsmk::qjoxQ(double iPsSiYUeMaFDY, string iIuKObFLMXi, int PxGOH)
{
    bool awVvu = false;

    return awVvu;
}

string WVsmk::stzKSE(int ywlvnF)
{
    string PTtQIN = string("qaaCdFihFJMDZnLqEEaWvMAVKadDZHlmifmEeGRiUAOfAtfHBEBuuapXPpdzpAsYztKIXdVhWMNPYHeEnUbBxkaNDANtNCfKKwoOVaZhfxFxWNgXpLYhHCgNUjdPfJRQxdMpbRVhdIKogpeFeoavDPTsTQAyI");
    double AKQaABkqPmBLlr = 425667.9051537858;
    double BXaAq = 198980.41321551174;

    if (BXaAq != 198980.41321551174) {
        for (int XTTHvf = 565974687; XTTHvf > 0; XTTHvf--) {
            AKQaABkqPmBLlr += AKQaABkqPmBLlr;
            BXaAq -= AKQaABkqPmBLlr;
        }
    }

    if (BXaAq == 198980.41321551174) {
        for (int WFutDYDGPx = 378008907; WFutDYDGPx > 0; WFutDYDGPx--) {
            BXaAq -= AKQaABkqPmBLlr;
            PTtQIN += PTtQIN;
        }
    }

    return PTtQIN;
}

void WVsmk::IvNEPSJLHomhk(double OfAMRRNYZuR, bool jYrIYXXhGYVKddA, bool rdzTSgElcA, bool UeLCyFQsIEAJPd)
{
    double LZSfwwN = 746098.0698282854;
    bool ESOJhFdfssNygJSI = false;
    string VJbJYHAtwqdwI = string("IlpgKLFhqWSyypZbddsfQEjMoqLAcgdCHCAHcsEYmDErqobhGhqhqrlCmgIBRYxrmWSvxtJwUjgoLYVWMzUl");
    string ulSNI = string("fAkonmhfvhdrMLxSgmTgCYiuSbwnYyUQuwVTLeaK");
    int dSLuicRPVR = 1050401175;
    int uSjFvBQWS = -898041926;
    double TRCKGIB = 72210.01584738297;
    int WiklaV = -1769675167;

    for (int hZWAAwZcJZLISfLv = 81218613; hZWAAwZcJZLISfLv > 0; hZWAAwZcJZLISfLv--) {
        ESOJhFdfssNygJSI = ESOJhFdfssNygJSI;
        LZSfwwN = OfAMRRNYZuR;
    }

    for (int ZCCDdpmgjIAVXZ = 711233729; ZCCDdpmgjIAVXZ > 0; ZCCDdpmgjIAVXZ--) {
        rdzTSgElcA = rdzTSgElcA;
        uSjFvBQWS += uSjFvBQWS;
    }

    for (int vABJTfyoTGYcmuD = 343854719; vABJTfyoTGYcmuD > 0; vABJTfyoTGYcmuD--) {
        continue;
    }

    for (int qGqTp = 1795171549; qGqTp > 0; qGqTp--) {
        continue;
    }
}

void WVsmk::bUJlxotc(string bgrYULYx, int jutaANlLfQ, bool acHDXNfbBU, double CwZZOIWEI)
{
    double voYXMQoTCccDYAS = 641442.8321947557;

    if (voYXMQoTCccDYAS != 641442.8321947557) {
        for (int LtietQDfodDB = 2129162667; LtietQDfodDB > 0; LtietQDfodDB--) {
            CwZZOIWEI += CwZZOIWEI;
        }
    }

    for (int luJelnPd = 1547791170; luJelnPd > 0; luJelnPd--) {
        acHDXNfbBU = ! acHDXNfbBU;
        voYXMQoTCccDYAS += voYXMQoTCccDYAS;
    }

    for (int Hmuyz = 67747164; Hmuyz > 0; Hmuyz--) {
        voYXMQoTCccDYAS = voYXMQoTCccDYAS;
        jutaANlLfQ *= jutaANlLfQ;
        voYXMQoTCccDYAS += voYXMQoTCccDYAS;
    }

    for (int poCEoPNIAAy = 1900448238; poCEoPNIAAy > 0; poCEoPNIAAy--) {
        acHDXNfbBU = ! acHDXNfbBU;
        voYXMQoTCccDYAS /= CwZZOIWEI;
        CwZZOIWEI *= voYXMQoTCccDYAS;
    }

    for (int KNzPusR = 1346258631; KNzPusR > 0; KNzPusR--) {
        bgrYULYx += bgrYULYx;
        voYXMQoTCccDYAS -= voYXMQoTCccDYAS;
    }

    if (CwZZOIWEI >= -484528.5265684101) {
        for (int wZCPAMAbzBTCMV = 1542390324; wZCPAMAbzBTCMV > 0; wZCPAMAbzBTCMV--) {
            continue;
        }
    }
}

int WVsmk::ubfLwkLofQU(string vBGrbPn, bool HiQHhIdyWX)
{
    int aTmdlWuDguQGcPHG = -1970054084;
    bool LJWxLSb = true;
    string veBYunnF = string("qWDAxnGTeCKLoFXWOsKShgMiPIyAyNruyCTQwHoUkzQNnILtrApIePhogjThsZfGeHIztqOefEDlgTKcJKItwlDHOoTItqecCnspeytFdUBrQAWPFPnVwFomaZpAHwbVsVVaCVPSs");

    for (int jnUNyJdYumoRSpHZ = 819107276; jnUNyJdYumoRSpHZ > 0; jnUNyJdYumoRSpHZ--) {
        HiQHhIdyWX = ! HiQHhIdyWX;
    }

    for (int JqsZq = 914277901; JqsZq > 0; JqsZq--) {
        veBYunnF += veBYunnF;
    }

    if (HiQHhIdyWX == false) {
        for (int AxMPfLXKK = 597864392; AxMPfLXKK > 0; AxMPfLXKK--) {
            HiQHhIdyWX = ! LJWxLSb;
            vBGrbPn = vBGrbPn;
        }
    }

    for (int KHmwAiPkeiYSxPYE = 703674306; KHmwAiPkeiYSxPYE > 0; KHmwAiPkeiYSxPYE--) {
        LJWxLSb = LJWxLSb;
        veBYunnF = vBGrbPn;
        aTmdlWuDguQGcPHG = aTmdlWuDguQGcPHG;
    }

    for (int AgfVrINf = 2120139889; AgfVrINf > 0; AgfVrINf--) {
        continue;
    }

    return aTmdlWuDguQGcPHG;
}

void WVsmk::RxWXAerOKS(bool QinBEJbjZsI)
{
    string YiDZdyVAbHgA = string("uDkMruguKQbuPEnTyzisBLEplHEqwMRWXVvvkMejbdAhcPAzAqTQqCfQOKrkocDaQcdpKDAHuVJEUlckjrkpZroEJVzbiCDlhEGqbAONPGsgxoAHccxcqclokRvADZAYmdizHib");
    int pVgFyiuzAipdKrSZ = 1316299316;
    bool kKOxrTyPudlVTe = true;
    int SuMlzEyheykoTOXH = 171930150;
    string OHYCzNnlAcXxA = string("drgSjcVQtvuIbQKxKlGhmeFsbldZESBbDAwrEVVpByqVimtdvbAGzENcBVDjQAlNkEzUeBgDpBUreuQIFFNgmspGMQmqyzRpXzzkyBmlGYbVmycCCeAutcbb");

    if (YiDZdyVAbHgA != string("drgSjcVQtvuIbQKxKlGhmeFsbldZESBbDAwrEVVpByqVimtdvbAGzENcBVDjQAlNkEzUeBgDpBUreuQIFFNgmspGMQmqyzRpXzzkyBmlGYbVmycCCeAutcbb")) {
        for (int LRGFmzZljZn = 1876342999; LRGFmzZljZn > 0; LRGFmzZljZn--) {
            continue;
        }
    }

    for (int bApbSUWL = 699708642; bApbSUWL > 0; bApbSUWL--) {
        QinBEJbjZsI = QinBEJbjZsI;
        kKOxrTyPudlVTe = QinBEJbjZsI;
        OHYCzNnlAcXxA += YiDZdyVAbHgA;
        OHYCzNnlAcXxA = YiDZdyVAbHgA;
        SuMlzEyheykoTOXH /= SuMlzEyheykoTOXH;
    }

    for (int OSQfZocb = 176814759; OSQfZocb > 0; OSQfZocb--) {
        continue;
    }
}

string WVsmk::xYZJr(string WZcFVpZaFv, string bZaRECf, int hByaIfQEsLPFyF)
{
    int tnHborXCJ = -406642386;
    string xVmOxVWVSZHES = string("TdWyYBpGcfqRPRMCAANWZrYexmvZhwgBTnJqsAVMIOSWoDAbkOqpKhrnPElsYkbVnAwEmTHSBBPFB");
    double utdBXXJqZShn = 667266.4788467237;
    string ZMvBAjWPskfvI = string("YJYATkUqABMUeGIOlAmMUqANMzeUSbagPEVsqvtlXxcgwOHtgNfAFebeGyTsZHAdDIpSAqmJBkosPjboZQCmyStZlZCksDzugYRtXmTfjMrFeiFJavalqwBDDTOrudZODpQsLxrCUvnNqzvbABdQDDqaIxINQhmbpViiBfdBxxyQQysfrUgmFGFxFCjCMfAcTIMXQzHhzPAJUXdMUkknsRmWUXgkaKxjOInYaeXEtTUoHxwTqNCPAiDAXOZIxsP");
    bool iQRKeppSKp = true;
    int lBTtPdOyQ = 257467871;
    bool gKyQxpB = false;

    if (bZaRECf > string("YJYATkUqABMUeGIOlAmMUqANMzeUSbagPEVsqvtlXxcgwOHtgNfAFebeGyTsZHAdDIpSAqmJBkosPjboZQCmyStZlZCksDzugYRtXmTfjMrFeiFJavalqwBDDTOrudZODpQsLxrCUvnNqzvbABdQDDqaIxINQhmbpViiBfdBxxyQQysfrUgmFGFxFCjCMfAcTIMXQzHhzPAJUXdMUkknsRmWUXgkaKxjOInYaeXEtTUoHxwTqNCPAiDAXOZIxsP")) {
        for (int YjkBBEF = 1020684263; YjkBBEF > 0; YjkBBEF--) {
            continue;
        }
    }

    if (hByaIfQEsLPFyF <= 257467871) {
        for (int cBdkkZjrTaWYALb = 1059361346; cBdkkZjrTaWYALb > 0; cBdkkZjrTaWYALb--) {
            WZcFVpZaFv += ZMvBAjWPskfvI;
            WZcFVpZaFv = xVmOxVWVSZHES;
            hByaIfQEsLPFyF *= lBTtPdOyQ;
        }
    }

    if (hByaIfQEsLPFyF > -406642386) {
        for (int osnbvTrmxRie = 255204572; osnbvTrmxRie > 0; osnbvTrmxRie--) {
            continue;
        }
    }

    for (int dczDdkOXAemx = 1248983580; dczDdkOXAemx > 0; dczDdkOXAemx--) {
        bZaRECf += ZMvBAjWPskfvI;
    }

    if (ZMvBAjWPskfvI >= string("YJYATkUqABMUeGIOlAmMUqANMzeUSbagPEVsqvtlXxcgwOHtgNfAFebeGyTsZHAdDIpSAqmJBkosPjboZQCmyStZlZCksDzugYRtXmTfjMrFeiFJavalqwBDDTOrudZODpQsLxrCUvnNqzvbABdQDDqaIxINQhmbpViiBfdBxxyQQysfrUgmFGFxFCjCMfAcTIMXQzHhzPAJUXdMUkknsRmWUXgkaKxjOInYaeXEtTUoHxwTqNCPAiDAXOZIxsP")) {
        for (int ARbwrhvCH = 1041200015; ARbwrhvCH > 0; ARbwrhvCH--) {
            gKyQxpB = iQRKeppSKp;
        }
    }

    return ZMvBAjWPskfvI;
}

string WVsmk::ERRHXX(double YWrvbdbK, bool FAIBqDDdrGr, double FTkMxZPdMLR)
{
    string ShjyZkRhuyXQR = string("dYvnfGbjVjrZCtuDCnZcESOcUOaOOVqXalxnoJNTSbcShvXMDwJxMCqavEthKhDzqHVhZmsCWIJhjOZhYNRVsJlGwIcTBdaTYIAfJTSVSEyCXOAvAsZkjOwhzmDSsxbhLErqMZTjosZLuybTAOYjRtTecOvgRBUXMMkyKUWGqMwvCHMqkrdYNVIdwRbErnhtVkJWQHNNFHUrBYBNaVPjqBmdSAcYoEaOIKMbQxunhsIXjn");
    int mMnwSdGGJk = -1858799007;
    string nzXiez = string("DOVeHYkMTtSxtaDeFwmkZbCV");
    double iMCdPBfBNKx = -566150.0848457548;
    double FBPzuBQmT = 28482.654775636885;
    int imtJlXp = -171582067;
    int YKNSIcMBRgdhiBE = -69468470;
    int UhhXiFZCuzvv = -1342100694;
    int vybQeDUVrPuG = 1308920392;

    for (int vXOpY = 1196258076; vXOpY > 0; vXOpY--) {
        mMnwSdGGJk += YKNSIcMBRgdhiBE;
    }

    for (int SyRWcFOKoRjFOjR = 581547533; SyRWcFOKoRjFOjR > 0; SyRWcFOKoRjFOjR--) {
        YKNSIcMBRgdhiBE *= imtJlXp;
        YWrvbdbK -= FTkMxZPdMLR;
    }

    return nzXiez;
}

string WVsmk::qfxOa(int mbaAtbiRcNe, string liKKpcC)
{
    double dKlcxjW = -387756.1512374245;

    for (int CRkBsMWIHlNmDi = 528856421; CRkBsMWIHlNmDi > 0; CRkBsMWIHlNmDi--) {
        mbaAtbiRcNe += mbaAtbiRcNe;
        mbaAtbiRcNe += mbaAtbiRcNe;
    }

    for (int kZionhFHrwl = 1522231570; kZionhFHrwl > 0; kZionhFHrwl--) {
        continue;
    }

    return liKKpcC;
}

WVsmk::WVsmk()
{
    this->vyOvqtlLiFDYc(string("rHhQSkVnmLFEXtDOAxyQSDEVSuWuGNgDbkSRjCVHNyBTvzjiLRrxIDFQGgnllqiAkoqlAkzdtPvGGQgnRswWRfGmnj"), string("vFHKjkPxFMzoFZuSemRbrmYffQAgihaZHVWzzhogasyUABtaqhWUauBpYMYg"));
    this->HpsWaHufZlr(string("mmYYDeDhJtbJujhGiKCFjohiWogyiNyrJlQjTEfqhRXwkHdyVvQupjTQkgvyBpEYosiPJiUedsvZosTyyHeAiRcnXXAOQjvcaLwVMoDHcZcQKlQtjxZgtFFrBoOebPCrhDOZvpNzkCXoQwaRQNWQnzxEQbfJMjdCrfZdPJ"), true, 73073.07924126906);
    this->IHRMXkmdABVoK(774567.9885444915, 295828.13267037616, true, -1340600740);
    this->tnPiP(string("ZjALNfxVsmWHLGOGcduGIFhKKhxYOPdwUIrtwMEAdAooWumJVhziDvSCwdQSIEbVQqLTOwtcrfVqiepkhyhSXGXcZlMjIwjwegkRJgTREGlUsIZERRmGxzvjXbzKQoxnhCelslbPYrsJQOnipSmdiBCRQvTsNoyhHVQzmVsAscJMINMENCrsOYJiJrwAqA"), -771646.5984620202);
    this->CZUMcXa(-1011733.1855587236, 683119.7890152581, string("ntRkhQJhublKbRtdzamSjFDmUWodpwzeAdJHzVPhzqbUsRPZMEzqXCcDtBTUVEsJfiJEkMwKxZLATOpgsWHwxlifrlgHrjlaAKCuzlA"), -1188152584);
    this->QQbaDyL(string("NcFHHnXCzzxlwIHDpMnHwOYHZrQNiuXRrxIbIQwVuHEqnttbyoLfrUauGJpcLNybnyaZdtEHBkDIBIblcozYbwrteqsIOIsMZBbCJHzgilUWVAQyJTJCrAPbQWZqrZPtrAXYHJabEuhgoqyXJFHEhabOjmTmnUAufQClYvPmeKhIjxCiVTetKiZyTjdEZJQAwSUSZkPzCQNNfFDOCHxj"), true, true, -974950.2359631673);
    this->sqTWtGaPWWtuoMV(true, -684846.1626893126, 1461032723, -743320.4139303953);
    this->CnziGrAxYEtsSw(756990.4433388856, string("zjloSNIwtthPEqEXyEzRPGrJVNkHyyeOmPZJEGCfXYgkRoiOAPKpijYGziSXKuuOhngXNrmocrchbRzxk"));
    this->hsfPvEXAMC(-293191167, -494097615, string("jSeOvcxaVYeTPnkcbkCkLVsaanzTkNJkszMtfVfBWzGchninNT"));
    this->saKDUIeFbpwLfOZ(58587.68632826745);
    this->qqUIGfcGJp();
    this->qjoxQ(-657345.419374633, string("HmFABKWxZjXOZEBZSecqdOvfKRKVmbdFxUDEimc"), -447666388);
    this->stzKSE(1839297370);
    this->IvNEPSJLHomhk(572043.3277455923, true, false, true);
    this->bUJlxotc(string("oygBfzJcZDLlyzzsgWnBrCvwuvSNNwKNGKGtHTeHCmBOlGAdkMcbToTROOncsRThzRCovuQiOXmbNXellQBrVzWADsSLDAmRezaXqhQWjffpppDkPmUasnmmvthKRhckpkNTVgBy"), 1736776456, true, -484528.5265684101);
    this->ubfLwkLofQU(string("bJOIogZSIBrMAzeDLKtMNIsYDPepNkfSTVHhTFDmkYRcLyRFlZuWjGvHekFAODFmnhpQtVjjZBLoNQjByHexCbcMxGSakbXmFiTFEuevvNOoHTCbC"), false);
    this->RxWXAerOKS(false);
    this->xYZJr(string("npUjyrYXPrtlFkPcvqGTetqNDfnDvhDmEyTTnYXqMbASqBKcOYmEVsifWhlaBbrFZFBqxbKGrWrobSzsCnIgONMypSYJPXLnrWfxncLoUpCkHIZhajVjFlnuVGwkdDvESvLFsKAzJxkyMHaPafFVOronRrPsNalMhbpxiPQoUMBDKXYSOJJRowQTgpxZiVjXePlPVtGrXkngPrksUEKolwahDmdyZCMjzco"), string("HmiUpgiiEiRTwSpymcPSHtCxwaMgaJApHnoXPRuJcpzhCNDCkVessCWkzKGksJqIscPgusDOZFPBdSDJKRGCpuGxaDqBXdsefQsGlpTrQXsurvFEcIP"), 1661756009);
    this->ERRHXX(277995.9473709082, false, 410138.34845556185);
    this->qfxOa(-1052149730, string("RxmvKztsKZfUgwQrWKlcvyIPSpdHLCRtACqGmavrEjBRuMMlrTQRTExDQkCIgmWIFuTYSCFrGAMBXujHwQuOdgciIBOIPeBttUmDMPYNMhVdGyApcfSnsEgBIXrnNtroiJSfOUgGtVskiMunvfG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MuaIsvz
{
public:
    string uxKHfwJ;
    bool hHyBzc;
    string uiOehT;
    string opLHXsA;

    MuaIsvz();
    int nlfxMVK(bool xKTPbJ);
    double fARFYmRPMSQe(string JovvY);
    void JdXRtge(bool vZnFQUdLiVbP);
    bool VtBXsYURfWZrSGs(double rCxumBvfoKfFiWD, double TbTKPaZNl, int MrRsMOS, string hdYZDiT, string QqBpMMG);
    int iGnxyxyBExxdd(double vvtSuSXiKxlKWO, bool EyXvJYVCaVIfz, int ZNZplplWjoC, bool MajsmyoDWwU);
protected:
    double jkmMFkMEQgIllW;

    bool bUAjP(int FOOzXSGue, string zqVWtfoFXg, string soeMvRjRKBruYcEF);
private:
    int wQfrkVyRIgI;
    double oVSJpY;
    bool dmnIYGMWOsYiLNHj;
    string ZfnKahRIr;
    string zHDpuz;

    int BKabs(string eXkqhGlEGonQnGh, string eCKFv);
    int jMBoXpVtauAuIKGm(int jqoxrDEGZefK, int QRObSOeVYxO, double IqkCSxrmtCKwLcc, double qmunOgtv);
};

int MuaIsvz::nlfxMVK(bool xKTPbJ)
{
    string pSuctUoQa = string("nIUlBrVjEXwAnZkIubDKHcINLLtvXQvKObRRvmVEvbCTnzsj");
    double wZayYIZXwmeL = -316260.5270647347;
    bool FNQkCh = true;

    for (int wrQpe = 1776567565; wrQpe > 0; wrQpe--) {
        continue;
    }

    for (int VSNkdXJrvKIVkBgO = 1541550787; VSNkdXJrvKIVkBgO > 0; VSNkdXJrvKIVkBgO--) {
        xKTPbJ = ! xKTPbJ;
        wZayYIZXwmeL /= wZayYIZXwmeL;
    }

    return 1473470847;
}

double MuaIsvz::fARFYmRPMSQe(string JovvY)
{
    bool XnFkcs = true;
    bool bKQwbXFFtVFzFlm = true;
    int jbfWREOkBmC = 598460135;
    double XqOyAtHpRQ = 990094.2414411228;
    int xMJRGEgcvDoh = 1985289508;

    for (int KlOCVNvHTEAmpA = 677122286; KlOCVNvHTEAmpA > 0; KlOCVNvHTEAmpA--) {
        XqOyAtHpRQ *= XqOyAtHpRQ;
    }

    return XqOyAtHpRQ;
}

void MuaIsvz::JdXRtge(bool vZnFQUdLiVbP)
{
    double ejnlDSqMtNC = -132743.1199509397;
    int TkBQhMNMU = 2111233848;
    string OqxYfb = string("HBVhvXF");
    bool qhunoCZ = false;
    double nNTFMsAfnJTQS = -518446.0062286735;
    int ByEWcL = -1667137311;

    for (int qqrczcqadaZ = 1583994281; qqrczcqadaZ > 0; qqrczcqadaZ--) {
        vZnFQUdLiVbP = ! vZnFQUdLiVbP;
        ejnlDSqMtNC *= nNTFMsAfnJTQS;
    }

    for (int PqvVprGsyKRvWAZw = 817316713; PqvVprGsyKRvWAZw > 0; PqvVprGsyKRvWAZw--) {
        continue;
    }

    for (int vOiwhRKDLtBDT = 1055310388; vOiwhRKDLtBDT > 0; vOiwhRKDLtBDT--) {
        continue;
    }
}

bool MuaIsvz::VtBXsYURfWZrSGs(double rCxumBvfoKfFiWD, double TbTKPaZNl, int MrRsMOS, string hdYZDiT, string QqBpMMG)
{
    int YqyAmAiWCTk = -463328682;
    double DkSJpxIVdPmLcbc = -129784.7887362501;
    string APeFYOENFC = string("dijoOgFewwPvzlSKAeEAHqLfJhTjSVBCdjwcRVnnEefsPFOPKcqQkHGVBYqrsXUsVmrUUFsIVzPZCksFFDoYLSVgmDASJWEkpmRziqLiOpenhXrQTsTrbVsLZhEkrCFKcQFXQduiSzOqVHmXNYIdGLQfpMxZNRKNQqCzldXtguHqDFpQRe");
    string LhAjwAOXlRXsy = string("sCxSnQsSKnGQuhJNJUBdJFcUFPpBawKzYJRNQEPSyoFhqbFJAbOsmsTkNcmasarHBRCzIhwpOCsvgVDjP");
    string cwFhAssaHfeK = string("RQnWsfcBmxIORoaBlnXppeUkoHrKcIpEfUUjvPMbrmpxASCQafGXzXcuhJKqQKwwhdGGPHFBUFVTDRC");
    double UvpjzVdQFDEvLiNS = 292739.14688352786;
    int VAZpBklYllIP = -1820906822;

    for (int WBieqgiWBAq = 862883521; WBieqgiWBAq > 0; WBieqgiWBAq--) {
        hdYZDiT = LhAjwAOXlRXsy;
        UvpjzVdQFDEvLiNS /= DkSJpxIVdPmLcbc;
        LhAjwAOXlRXsy += LhAjwAOXlRXsy;
    }

    return false;
}

int MuaIsvz::iGnxyxyBExxdd(double vvtSuSXiKxlKWO, bool EyXvJYVCaVIfz, int ZNZplplWjoC, bool MajsmyoDWwU)
{
    string cYiQp = string("dtVcWHuvwAIFlehFRUqhgjfFLiDcZLsWjlYAMcVAHPQtStdhauyMwaOFwEcvpYXcLdqSLMXiRqkeWYVsqTrgsBUQzfVkNZuSmwU");
    bool PubxCuSyt = false;
    double VWDDTooDPBFP = 670525.4143452967;
    int BSeKqHSbN = 738433904;
    int jMlWiw = -1319925439;
    int SSWqzsoREAtWbu = -1770805436;
    bool cILhMFL = false;
    bool CnCcpXdfP = true;
    bool pzwCPNrOGiCYZrB = false;
    bool fgZlGVyCsT = false;

    for (int ZYuHFugieSkMBR = 1698887385; ZYuHFugieSkMBR > 0; ZYuHFugieSkMBR--) {
        CnCcpXdfP = EyXvJYVCaVIfz;
        jMlWiw /= jMlWiw;
    }

    if (vvtSuSXiKxlKWO == 670525.4143452967) {
        for (int RgwpHYwoUsfAD = 1147109579; RgwpHYwoUsfAD > 0; RgwpHYwoUsfAD--) {
            ZNZplplWjoC *= ZNZplplWjoC;
        }
    }

    for (int qZNyraHluOL = 878960688; qZNyraHluOL > 0; qZNyraHluOL--) {
        EyXvJYVCaVIfz = pzwCPNrOGiCYZrB;
    }

    return SSWqzsoREAtWbu;
}

bool MuaIsvz::bUAjP(int FOOzXSGue, string zqVWtfoFXg, string soeMvRjRKBruYcEF)
{
    double xvjcLQkOujk = 682710.5122585016;
    double mncTk = 218904.29688623868;
    int YEIdKxXH = -716508352;
    string EtXbto = string("CEmnGsLNDyKQuERTNHfCXicmUElQsKbJWSUjYNJBqJRkIXfhYLqNiNmGaxGaerNFRuhpmrEaezkWxGOBwQjtkWpRLDXqZR");
    double jxyXcDXvdK = -793207.6348625739;
    bool oeOahHNJ = true;
    double uFpitQYsNBO = 721155.2907833013;
    int vxalMJ = -1585228813;

    if (EtXbto == string("mQFnUIzfgKasgWZvkdubXLqdvXueHeGJnNFyoszoqInMcVmydMGZoqCLuZyzJTtvpoysGcZgUaEqkTQnXZdsUFxXgPDBlNFlkrelReQGnjuHtmpNjWrYqYZpwAyJesxCbLeKfEBMtgwCpLrkVHzDKtMHxMFQPJDTLLozUbiONoUsJGFpjUarzlpSkuKalLuFlAfuLjlV")) {
        for (int IBtDWhDfrWq = 1226824653; IBtDWhDfrWq > 0; IBtDWhDfrWq--) {
            mncTk /= jxyXcDXvdK;
            xvjcLQkOujk = jxyXcDXvdK;
        }
    }

    for (int tPghNnHuj = 318313205; tPghNnHuj > 0; tPghNnHuj--) {
        FOOzXSGue -= FOOzXSGue;
        oeOahHNJ = ! oeOahHNJ;
        mncTk += uFpitQYsNBO;
    }

    for (int pRdmqHERUhAJAv = 1604861559; pRdmqHERUhAJAv > 0; pRdmqHERUhAJAv--) {
        FOOzXSGue -= YEIdKxXH;
    }

    for (int ByNtrLgrPsoPb = 997023703; ByNtrLgrPsoPb > 0; ByNtrLgrPsoPb--) {
        uFpitQYsNBO = jxyXcDXvdK;
        vxalMJ *= YEIdKxXH;
        vxalMJ += FOOzXSGue;
        zqVWtfoFXg = zqVWtfoFXg;
    }

    if (soeMvRjRKBruYcEF < string("mQFnUIzfgKasgWZvkdubXLqdvXueHeGJnNFyoszoqInMcVmydMGZoqCLuZyzJTtvpoysGcZgUaEqkTQnXZdsUFxXgPDBlNFlkrelReQGnjuHtmpNjWrYqYZpwAyJesxCbLeKfEBMtgwCpLrkVHzDKtMHxMFQPJDTLLozUbiONoUsJGFpjUarzlpSkuKalLuFlAfuLjlV")) {
        for (int facnTMjwOEosKdaA = 1032751116; facnTMjwOEosKdaA > 0; facnTMjwOEosKdaA--) {
            soeMvRjRKBruYcEF += zqVWtfoFXg;
        }
    }

    for (int zzXFEIREMSTzbUz = 174493345; zzXFEIREMSTzbUz > 0; zzXFEIREMSTzbUz--) {
        jxyXcDXvdK *= uFpitQYsNBO;
    }

    return oeOahHNJ;
}

int MuaIsvz::BKabs(string eXkqhGlEGonQnGh, string eCKFv)
{
    bool pxOpWSDssNi = true;
    bool QxfUUHtimP = true;
    string gABcSqqDzsU = string("PnSqRRKJskKrddmuffDM");
    int WttYZiB = 832215236;
    double eTOREIl = -163185.95494446144;
    int JdeMli = -1418264359;
    bool fCzCmgRxjkLWEXLK = true;
    int MwFIdMG = -2052463375;
    string YUHaJJmvxWRGv = string("URhnOeXDYwkJUuELPzVEYFstOeIkMznTShXEdqgcwpgspRWZoIwyVSlGkLGWOeIzIYjraIRMdqoAwhrxcLjgHzhgryRglKKOPhKjVLAoTsaZZOEyOZoRsaJZvooupbnRvmLlYefjCco");

    if (eXkqhGlEGonQnGh <= string("PnSqRRKJskKrddmuffDM")) {
        for (int gYyElDVghOv = 1152757998; gYyElDVghOv > 0; gYyElDVghOv--) {
            continue;
        }
    }

    if (WttYZiB >= -2052463375) {
        for (int PSKumaHkMVXCHwAt = 346529861; PSKumaHkMVXCHwAt > 0; PSKumaHkMVXCHwAt--) {
            continue;
        }
    }

    return MwFIdMG;
}

int MuaIsvz::jMBoXpVtauAuIKGm(int jqoxrDEGZefK, int QRObSOeVYxO, double IqkCSxrmtCKwLcc, double qmunOgtv)
{
    int FqSbTnPKSVg = -1235597561;
    double rdcuhATxK = 698918.302535008;
    string loZcuJWfp = string("YSIQuwLuxRckOiqCqPdwddNzRtJwgMJbpgujhpWoKFsxQiizFeJpWHbDPscFRtIEorNEOWmQgmrSjKWscdRlkpSrzVBpIOVkPtqBw");

    for (int ANyljrrNWUSKsRj = 2074393520; ANyljrrNWUSKsRj > 0; ANyljrrNWUSKsRj--) {
        continue;
    }

    return FqSbTnPKSVg;
}

MuaIsvz::MuaIsvz()
{
    this->nlfxMVK(true);
    this->fARFYmRPMSQe(string("DltRYAWVbHhnfExYSKQKoTtWbGndOcgfyxe"));
    this->JdXRtge(false);
    this->VtBXsYURfWZrSGs(597667.6149087729, 872614.9625277485, -589039397, string("tgAgLkkaqHYFAaDeerKxXcEqBZuEPEXYhAhLrjKAOaqcMMhzudYddUDUtrgmbAEgDYOorQZiGyTvKyeECkAFYhiPXauEGsSYOyOWJjattCvjMHzYKfoiRXHAoryEtghFuwwGelecGezFXrknAWmGfqwVBOHVayRQBbsSYxEbIquxXQqwAfPSQYtDFixQGMUealFsViMyRKgOuofQlrwZzJEYT"), string("YPmOkWzqSDEJNTEXGpZMJNdtkxhFiWzKcrsktticPgHYNFdNIsCpiJsdcxESRcyecPjlehVlYzLUjZvkZcZKwBaWFFrLdEjrIZILbskglKNLbCmbTBJVoWnCNYe"));
    this->iGnxyxyBExxdd(167645.7679615349, true, -1763189714, true);
    this->bUAjP(-66333194, string("XeKzVJLHNLHVZvHDCEpgxoPjLdOrcabMiBJSKViAVeFzyyuOrEfiPofMidABUKtxHQINqrcOyOAYnWwIukqcvANLKCULFKoZDqoKpjzMjTaTUJQlvEPzxPSpLiXNYkqgSrqLhHiQvD"), string("mQFnUIzfgKasgWZvkdubXLqdvXueHeGJnNFyoszoqInMcVmydMGZoqCLuZyzJTtvpoysGcZgUaEqkTQnXZdsUFxXgPDBlNFlkrelReQGnjuHtmpNjWrYqYZpwAyJesxCbLeKfEBMtgwCpLrkVHzDKtMHxMFQPJDTLLozUbiONoUsJGFpjUarzlpSkuKalLuFlAfuLjlV"));
    this->BKabs(string("YuxnbYOVipQhXyQtJDFzgzievFpjRCdhCKEHuRsOrIstDaJGVosioCTmESoBadaqaWLduxfLJNIHFwwmjOuJiAZmfauWLODIKttThUHpimISDicJkhPYmohAXNvZKF"), string("iqmhhg"));
    this->jMBoXpVtauAuIKGm(-548919131, -1858762122, -480686.57800365385, -792450.4241991652);
}
