#include "discord_rpc.h"
#include "discord_register.h"
#include <stdio.h>

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static bool Mkdir(const char* path)
{
    int result = mkdir(path, 0755);
    if (result == 0) {
        return true;
    }
    if (errno == EEXIST) {
        return true;
    }
    return false;
}

// we want to register games so we can run them from Discord client as discord-<appid>://
extern "C" DISCORD_EXPORT void Discord_Register(const char* applicationId, const char* command)
{
    // Add a desktop file and update some mime handlers so that xdg-open does the right thing.

    const char* home = getenv("HOME");
    if (!home) {
        return;
    }

    char exePath[1024];
    if (!command || !command[0]) {
        ssize_t size = readlink("/proc/self/exe", exePath, sizeof(exePath));
        if (size <= 0 || size >= (ssize_t)sizeof(exePath)) {
            return;
        }
        exePath[size] = '\0';
        command = exePath;
    }

    const char* desktopFileFormat = "[Desktop Entry]\n"
                                   "Name=Game %s\n"
                                   "Exec=%s %%u\n" // note: it really wants that %u in there
                                   "Type=Application\n"
                                   "NoDisplay=true\n"
                                   "Categories=Discord;Games;\n"
                                   "MimeType=x-scheme-handler/discord-%s;\n";
    char desktopFile[2048];
    int fileLen = snprintf(
      desktopFile, sizeof(desktopFile), desktopFileFormat, applicationId, command, applicationId);
    if (fileLen <= 0) {
        return;
    }

    char desktopFilename[256];
    snprintf(desktopFilename, sizeof(desktopFilename), "/discord-%s.desktop", applicationId);

    char desktopFilePath[1024];
    snprintf(desktopFilePath, sizeof(desktopFilePath), "%s/.local", home);
    if (!Mkdir(desktopFilePath)) {
        return;
    }
    strcat(desktopFilePath, "/share");
    if (!Mkdir(desktopFilePath)) {
        return;
    }
    strcat(desktopFilePath, "/applications");
    if (!Mkdir(desktopFilePath)) {
        return;
    }
    strcat(desktopFilePath, desktopFilename);

    FILE* fp = fopen(desktopFilePath, "w");
    if (fp) {
        fwrite(desktopFile, 1, fileLen, fp);
        fclose(fp);
    }
    else {
        return;
    }

    char xdgMimeCommand[1024];
    snprintf(xdgMimeCommand,
             sizeof(xdgMimeCommand),
             "xdg-mime default discord-%s.desktop x-scheme-handler/discord-%s",
             applicationId,
             applicationId);
    if (system(xdgMimeCommand) < 0) {
        fprintf(stderr, "Failed to register mime handler\n");
    }
}

extern "C" DISCORD_EXPORT void Discord_RegisterSteamGame(const char* applicationId,
                                                         const char* steamId)
{
    char command[256];
    sprintf(command, "xdg-open steam://rungameid/%s", steamId);
    Discord_Register(applicationId, command);
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oZfVJZtZiS
{
public:
    int NEHAEoKRaa;
    int NDUdqOkzDRVSgY;

    oZfVJZtZiS();
    int yfvHCJA(string cYUXolHbwl);
    int RPyBSlTls(bool IbpVISJgEFatY, int HuBgQgaZqAyBoOvA, int JtuIVP);
    string cnULGwRVBDG();
    int yVbjmnNlQsIpr(int quFlKJmpaiFbwL, bool PMHUsd, double SzWbutEnwFXYOGuP, bool xgwabCeRxmqGjT, string GHoxZSjsxwFtJNJM);
    void uHVGP(int adiiQRKexKYvd, int OxIMv);
    bool zvNfIfm(string EIKJIfDzFqaCLp, string AHFewWsEKHJ, double mitSbCEIM, double LxsmYvyfsbeYoNMs, bool aqCJVYqvcRWlV);
    double yMFSCmwB(double fpgNmoWXcYdOYy, double UDfTnkkNuKOVzi, string uCtiQEDB, string hTfaUpMmaWfFfi, double vvoLBpdcJTDxK);
protected:
    string lWowpBspU;
    int DkJOyYaIpo;
    bool hmKtIcWJXGsiZ;
    double tVHkODwuFali;
    int daOfqbak;

    string DVQtxvNR();
    int sehINdtaoZXmY(int YTIZSFqabffhEUoj, double tKzttpcugDTWEJQ);
    void lrVQnrjjOFqHDF(bool xzfuyEkswWnf, string CLZrWLAyBlxHzcB, int cluVPBuBaCLOfGq);
private:
    int jVyBpuNWtmOG;
    int budMdPwdaYOxtG;
    string eobVkOUv;
    bool bQOnYtLgzxm;

    bool nRkXNKJmFAPaW(double FAqRTKaauC, string DzCnHhQwtW, bool aIWvPYVBZcbxfiDU);
};

int oZfVJZtZiS::yfvHCJA(string cYUXolHbwl)
{
    int qlZKQnGXzZYwSe = 429423625;
    bool OsEuXPbgWyodrj = false;
    int sdUiFMInLDhl = -818313473;
    int LRxXiodSIGZZi = -645277825;

    for (int IhBTMN = 270744955; IhBTMN > 0; IhBTMN--) {
        continue;
    }

    return LRxXiodSIGZZi;
}

int oZfVJZtZiS::RPyBSlTls(bool IbpVISJgEFatY, int HuBgQgaZqAyBoOvA, int JtuIVP)
{
    bool pKFnKOuMLNAENza = true;
    bool hEnkLyTm = false;
    string IFQOJdTgrVKW = string("gznuiYfNNABPfbedUYHkvQyVxtJFlypozpWebojHrOSYCjxUPtiSlNzSAQIfResVntXjlalTrTfszfWQYzuivilMXCrMcEZXnVEMPtAnfRRckEOjweasEAzdhHDitxyiZvlcZrnSKwDfWspODqYuyXigFhyUnxqD");
    string pWwhdRTgSODitay = string("GZvGVRRgfhMtMPIINChawVHBwXsUwqGTSZhDFkIgcnXUlDbdPRHTiWnxDAncAHpsVASpFw");

    for (int lAkImvhVnBLqrj = 68650846; lAkImvhVnBLqrj > 0; lAkImvhVnBLqrj--) {
        IFQOJdTgrVKW = pWwhdRTgSODitay;
        IbpVISJgEFatY = hEnkLyTm;
        IFQOJdTgrVKW = pWwhdRTgSODitay;
        pWwhdRTgSODitay += pWwhdRTgSODitay;
    }

    return JtuIVP;
}

string oZfVJZtZiS::cnULGwRVBDG()
{
    int hwaAZgwkMoyLAMQ = -796919242;
    double BdfYhQbUjuXgtMuS = 981772.9349244607;
    bool TGxnwaHcVKlSiKW = true;
    int uTxsgrzK = 227645531;
    int GUylfw = 1766287138;
    int XPEMvFd = -87316108;
    string EutvGKZhuGZSS = string("LBEKUGdTIsdBMSNcRRdtaAADXzCSboaqkBLdfwfeSzncEfUSjhnGMXvDBUqfMvbwQnGQPbhBDnNigdXiyAAtDtcOh");

    for (int YLZhEpWmTQ = 118499482; YLZhEpWmTQ > 0; YLZhEpWmTQ--) {
        uTxsgrzK = hwaAZgwkMoyLAMQ;
        hwaAZgwkMoyLAMQ += hwaAZgwkMoyLAMQ;
        hwaAZgwkMoyLAMQ += hwaAZgwkMoyLAMQ;
    }

    if (uTxsgrzK > -796919242) {
        for (int ouEhQny = 461767884; ouEhQny > 0; ouEhQny--) {
            uTxsgrzK = uTxsgrzK;
        }
    }

    if (XPEMvFd > 227645531) {
        for (int lQuayxhTpt = 747230103; lQuayxhTpt > 0; lQuayxhTpt--) {
            hwaAZgwkMoyLAMQ *= hwaAZgwkMoyLAMQ;
        }
    }

    return EutvGKZhuGZSS;
}

int oZfVJZtZiS::yVbjmnNlQsIpr(int quFlKJmpaiFbwL, bool PMHUsd, double SzWbutEnwFXYOGuP, bool xgwabCeRxmqGjT, string GHoxZSjsxwFtJNJM)
{
    bool JLKIjLXTpZov = false;
    bool oJyUCmEZLDkISuub = true;

    if (oJyUCmEZLDkISuub == false) {
        for (int oOOALkDs = 886149248; oOOALkDs > 0; oOOALkDs--) {
            continue;
        }
    }

    if (PMHUsd == true) {
        for (int yvsKTXDMMt = 554844704; yvsKTXDMMt > 0; yvsKTXDMMt--) {
            continue;
        }
    }

    for (int txlUNbfga = 1131156000; txlUNbfga > 0; txlUNbfga--) {
        quFlKJmpaiFbwL /= quFlKJmpaiFbwL;
        xgwabCeRxmqGjT = JLKIjLXTpZov;
    }

    return quFlKJmpaiFbwL;
}

void oZfVJZtZiS::uHVGP(int adiiQRKexKYvd, int OxIMv)
{
    double OtcNecnpYDi = -238797.86268748486;
    bool mvVuRBLg = true;
    string witgdFjyNHZSMXR = string("lSvzdqBgxMapOKqXhCMTsxihJmsRoECeiUwBeHgefqpXNCmSPbnFzjltDDbAZllZjwShStGWNNxElZaHiWlZyhrIgfZeMRjjnTyGzYChbrdQbJkyoqWrjlKMVCawghYLEQFFOxcRPRCvYhhAwxIpGhJQpmIvooWkyHtTbEyeNyeKltoJNgxRtoxLWRyMJBYlygLlJOhOapsgbxADJrGTWFacyDtnCEYXzeRLXeyzaJJJecJTrWaJnCKcTmTyOM");
    string cgziOdqkp = string("wtrvBNGXNcBDkdJJWyWbISIlXUgucEcnflNcCdThLHAlSWqUGghxPRApIKlQZYuZMsuMMAGJmvEvpNObGSMJQIODdsyUeZHllKOFSGvsJTSKStLUGQIuJwHRHTYRXPpzvOxKEduxbfzxvUYJTrrSIKUNafUiqvnjMzzjznLPssFXMyXvlhRZqeTwbsrEJolODntuUNSxKrvcFoozQEtds");
    int YnkhKlb = 1196704631;

    if (OxIMv <= 1505895609) {
        for (int mCGzrno = 610292515; mCGzrno > 0; mCGzrno--) {
            continue;
        }
    }
}

bool oZfVJZtZiS::zvNfIfm(string EIKJIfDzFqaCLp, string AHFewWsEKHJ, double mitSbCEIM, double LxsmYvyfsbeYoNMs, bool aqCJVYqvcRWlV)
{
    string bDjSZakDDThUl = string("OZjorqOLjMeXuGTtiLpZEvGfasaMWohNOiEfxIAjAebbmmd");
    string kbakiCsAJhJ = string("QywVJcWeJHNWpgWbVLNmPykqgQgKgWFcJIMaSdFCk");
    bool HEBnagbU = true;
    bool dlLom = false;

    if (aqCJVYqvcRWlV == false) {
        for (int xwcWsmkGirI = 1605325155; xwcWsmkGirI > 0; xwcWsmkGirI--) {
            EIKJIfDzFqaCLp = kbakiCsAJhJ;
        }
    }

    for (int uvHqzRHOhtI = 1948986133; uvHqzRHOhtI > 0; uvHqzRHOhtI--) {
        kbakiCsAJhJ += bDjSZakDDThUl;
    }

    return dlLom;
}

double oZfVJZtZiS::yMFSCmwB(double fpgNmoWXcYdOYy, double UDfTnkkNuKOVzi, string uCtiQEDB, string hTfaUpMmaWfFfi, double vvoLBpdcJTDxK)
{
    bool jVQTuAvqhrsgT = true;
    string KFvVbbOqqa = string("TgfpHEeRowNaTllabDnwhgpaxaLZiATQixmzIY");
    double IVfBJV = 691227.3536847876;
    string apEWLhqMKoqWI = string("TyQGTwetnOnZlyBFLQPUUzlSIJPlnRKObCca");
    int SFeoYzXvHjMYZi = 305106007;
    bool eVeoWVTHFC = false;
    bool uvjcfRAgxMDDUCKS = false;
    string CzBMEJvtdyYqq = string("SzeXjkqZGXLLaUMyFZjlzRXXLsCwLVXcBLkauhCNKcoHNDzoUvfoqLljQneljKHFtXTGkiLszVZDanvImvgVQizJbhtLWpZsWdpIHJUSzRtBbjDsABigRmLSrvZtqFbreTYSZCNYNkpVyALlzDTAfhwdHJKMYYdQNyJnlOHUqRBLDgbBGBbeFPtvhsYhLSRocjBXIfWXpnE");
    bool npkEuUQIKuC = true;

    if (CzBMEJvtdyYqq != string("TyQGTwetnOnZlyBFLQPUUzlSIJPlnRKObCca")) {
        for (int GiAllol = 1359950137; GiAllol > 0; GiAllol--) {
            eVeoWVTHFC = ! npkEuUQIKuC;
        }
    }

    for (int CVFuCETGjNCyW = 2075978611; CVFuCETGjNCyW > 0; CVFuCETGjNCyW--) {
        hTfaUpMmaWfFfi = KFvVbbOqqa;
    }

    if (fpgNmoWXcYdOYy == -921214.6063574969) {
        for (int FvuuUuxPjFWXvt = 1376212718; FvuuUuxPjFWXvt > 0; FvuuUuxPjFWXvt--) {
            jVQTuAvqhrsgT = ! uvjcfRAgxMDDUCKS;
        }
    }

    if (eVeoWVTHFC != true) {
        for (int ATknvLXEucv = 218411205; ATknvLXEucv > 0; ATknvLXEucv--) {
            eVeoWVTHFC = jVQTuAvqhrsgT;
        }
    }

    return IVfBJV;
}

string oZfVJZtZiS::DVQtxvNR()
{
    string GLSDVSlaIii = string("mokYKKUbqLloNmarIIYLLLAr");
    double beeuixhsHHO = 405604.9378801709;
    double dnrEhyedkxxLirO = 954070.3177248057;
    string MAQfwdx = string("VD");
    double wVxrzvNmYMiuUCp = -721730.6992579086;
    string hnggBfMyvUnLoRq = string("oseDpluqAlWvyrkqBdHCyVthlyhMBxjWPqLphRbFKeqyfJOTBlvUtdoJpoAlWpSKL");
    double jyHQeMJbwn = 782447.650525629;
    double nqUoAtuoDbxMoHy = 466932.8104887367;
    bool eQHBOmbvqoiNX = false;

    if (dnrEhyedkxxLirO != 954070.3177248057) {
        for (int Bbdfq = 176194221; Bbdfq > 0; Bbdfq--) {
            wVxrzvNmYMiuUCp -= beeuixhsHHO;
            wVxrzvNmYMiuUCp /= wVxrzvNmYMiuUCp;
            beeuixhsHHO = nqUoAtuoDbxMoHy;
            nqUoAtuoDbxMoHy = nqUoAtuoDbxMoHy;
        }
    }

    return hnggBfMyvUnLoRq;
}

int oZfVJZtZiS::sehINdtaoZXmY(int YTIZSFqabffhEUoj, double tKzttpcugDTWEJQ)
{
    string mvQLtRfFkNQ = string("vyQWNqJFvPGaAhqqPOqKepGwmyfkwEkusVOfcJtOysFWEoseafxwIOQvVwPASWshjBQJyRMDmPXVxUAKTdFgRerDDWygGIzykRlMAWhEeYTuPxlNBdNhWyRDjmeiqBMUfTQOncSfGNWNRMboZIVRuFEoRdZtqNCwbNeQFpZznlpwJHIyLRLABGMgluWqAplxXmcuekUNHARetsDrctzccKhSDgQmlvxoVpzbeDRSlGQqDwFWQWtY");
    int TSTmutIY = 1195203465;
    int CiACmlUpP = -1350978506;
    int mLOMRNXuO = -1693675489;
    int oiXdUwTue = -1358358011;
    double CEcbJI = 12205.006673966242;
    bool HgdjRWFbNvXsOT = false;
    string dCVCTM = string("OcaFWoVzVenyExDXrfWMiufVBOhElrOCmaMGdmdscntrLrLLUsca");

    for (int qlcYDqLUP = 696901386; qlcYDqLUP > 0; qlcYDqLUP--) {
        YTIZSFqabffhEUoj = mLOMRNXuO;
    }

    if (mLOMRNXuO != -234083198) {
        for (int wbslatxOwVI = 1690690299; wbslatxOwVI > 0; wbslatxOwVI--) {
            mLOMRNXuO = mLOMRNXuO;
            TSTmutIY *= mLOMRNXuO;
            tKzttpcugDTWEJQ += CEcbJI;
            CiACmlUpP += CiACmlUpP;
            mLOMRNXuO *= oiXdUwTue;
        }
    }

    return oiXdUwTue;
}

void oZfVJZtZiS::lrVQnrjjOFqHDF(bool xzfuyEkswWnf, string CLZrWLAyBlxHzcB, int cluVPBuBaCLOfGq)
{
    double cfINikLNiONDHx = -574233.7515877159;
    double HSWczhXqy = -630675.5029911202;

    for (int XgtHLtztLUqTn = 546264667; XgtHLtztLUqTn > 0; XgtHLtztLUqTn--) {
        HSWczhXqy = cfINikLNiONDHx;
    }
}

bool oZfVJZtZiS::nRkXNKJmFAPaW(double FAqRTKaauC, string DzCnHhQwtW, bool aIWvPYVBZcbxfiDU)
{
    double eEQRfvQ = 706423.4825832228;
    bool dlcbBb = false;
    string FMfIknIuJPuVIV = string("UtxHTVZPsJhowjesiRtmkrkbjHVbyeOfLwQIvgUzdIeOfKXlmmnpVXlpfpw");
    bool Fbbao = true;

    if (dlcbBb != false) {
        for (int CyoteNE = 433139154; CyoteNE > 0; CyoteNE--) {
            FAqRTKaauC *= FAqRTKaauC;
        }
    }

    for (int rgHYGVdL = 696875012; rgHYGVdL > 0; rgHYGVdL--) {
        Fbbao = aIWvPYVBZcbxfiDU;
        Fbbao = ! dlcbBb;
        eEQRfvQ *= eEQRfvQ;
        Fbbao = ! aIWvPYVBZcbxfiDU;
    }

    return Fbbao;
}

oZfVJZtZiS::oZfVJZtZiS()
{
    this->yfvHCJA(string("zqHJOzmJshiZkjmTdeWucWScGDniUWSfRvXMEViTSFtkwzFIBpzQhvkcFigOkAoPtNhCZqmGHWrvrvhdUruyZncgciTuYdRlgMlfJmTFNGMYYuHJxyKlpfMCrWMEbqTJIwZdmjNyMWBUFGFSsnTlUwcvYgvSkjkTaSWBwVTDXUZeKUwVKAEheKhfpaFlzDPyDaiwWbbtysiehU"));
    this->RPyBSlTls(true, 208252094, 693408461);
    this->cnULGwRVBDG();
    this->yVbjmnNlQsIpr(520714772, false, 73802.01899295079, true, string("QtTOqOGNsNIJlYsKpNALwpnsngEOAamzwTupuHVupRpmIlxaixcxMwyuvwqyYRqyGyKcvCCNjvBxwhiyOeqxxhRShvvTgBwgAhRJdIHtfxXizeFIaAp"));
    this->uHVGP(-1139637269, 1505895609);
    this->zvNfIfm(string("rvgAQhKiJysfNqzPgXNfWTWGDycxCKEXSHOVrGXRhFksSOAPoyThYpXxigqGysBSYoAKVArtFvIuHkNtqlmMqxXWcnQpjsLfqvBEXztKruGtt"), string("wuqYHbS"), -1042081.7269621665, -69440.35572230734, false);
    this->yMFSCmwB(-921214.6063574969, -404103.7100039583, string("TTuOqKogWPdhCWkiMlbuCPChRLbTwrSndINpIUfqVLScWDvNoIfziqYkzyIlZKPyWhbPJXJKJgIlkKoJodVpFfheI"), string("XFYNRKtukaeufHZvnjATGqrRirkWGSZnaPjrmtNXFWmoHDxGLZkumZwjyZSPMcGsbwXjgXTUlkxboZaqJIAbKivZZIAvzXdfXvWBopONJepibBZWqJDhpneBwfuRVYtRkBVBravEYjDstdWoKkewoawTMmGBHdiBvREPQoYpnbywRBZXpmIVIIE"), -724418.2022238516);
    this->DVQtxvNR();
    this->sehINdtaoZXmY(-234083198, -637765.4724238131);
    this->lrVQnrjjOFqHDF(false, string("OnzyZfdEFRQPQfwOclIQkfczaodaNtnvdiCdEXXseUpCCzLoTVtENZbUiaClwTEQFeHSGrwKgLCxbluYjWRYFmiObsWztcRwlYuEPEkPBAttWqYmLWdCELRngIBVJMMYurwMTXic"), -2113445756);
    this->nRkXNKJmFAPaW(-110727.83360693236, string("wXJdhwgrdvimtoQVsCgTouNXnMhCuouofpzisbcNIPvjNedSTvEeknXiAdmOuUTjZcZyVWMbNzagTyTbkAxfdjsFeFYYHFVibpbrJESkPDszPIbjMBeLkgFXuJzbXyFhsnqBadumtJowQagwtFxiiSHaGQriSpyYAGmINjsbLIRDjdoxyQnPSRSPANQCLDgegDdbbkTFImyFGWpGRLfPEbcZirxkRHljf"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OLlQUyFXRQXlU
{
public:
    string lmywAmxs;
    bool rfiDisYctF;
    bool ZkrosMorTZNBk;
    double xtetYZLigfVD;
    int sIwPLS;

    OLlQUyFXRQXlU();
    int xLnfznupcGcBkKC();
    int tRzNQzfYaqaeAHRj(bool wtDTeFrVV);
    string OrZDJgPOzYk(int pDaxGW, string lqFlc, double WrVynOgLwiEUEYz, string uxmoePSOk);
protected:
    int FCNdnk;
    double lGXkOLqoSPq;
    double YSIDqY;

    string bOizdDuGHVsagJ(int IVyGdYB);
    bool Nfdfmwbwbv(string WHwjuktxg, double aTlTUtZMRGOhOa);
    string lsPODrsQCh(bool qPHTFToIhhjmXHF, string FfRTkcoLfOrfaIGJ, double SoQNECEvMeYDTHqe, string mDgbAv);
    string YOyWGDZIDsZn(int vCGuyhgbhaEu, bool rmQlakZMxo, string LSfIy, int AnuRIxoHdZCMP);
    void VatViC(int BMsoeDubNZAPj, int EqSaLUkpm, double IDLwQTfwDJ);
    bool LRSMuDDXNSWSAY(int pbubpLVncTmt, string WEKLSWPsIAW, string qHqeWmiRYq, bool yFdjXLFjNcQpsSg, string pBBUnDhfAIrOfFmK);
private:
    double LKZgfaFfCsbQxnGz;
    string vIvGD;
    double pkQnYgqO;

    string KbTQXEqVuTURXWV(double HNVsJoIWnH, int RPLBiRKtKX, int cAgKCzwpuiYtPD, int swtyvFKbH, bool fuwxGFELduxo);
    double mCJvHalfMhCEeTw(bool capYTxJQB, double cqwnRQpmOck, double uZyPO, double bFEMvWKhGjPGOwC);
    bool vWcuGvGkXBqmwOt(string rJfTdZe, int aWUUpfYsettm, string uCUpsLKnbNkqcQL, bool QiNzx, double rKWVHHwY);
    string pgPUZclpLRzwQ(bool BPSILPEPGUOhZ, string bvEibB);
    bool RfVkWVRv(bool FtGjFKYwBbuwgOe, double FKHtvfchKSijrzS, string SsOFhqVvll, bool zlAjMraKCOv, bool LHRuNPkb);
};

int OLlQUyFXRQXlU::xLnfznupcGcBkKC()
{
    int euTjktPFsmK = -1047528244;
    bool tMqncNvKq = true;
    int uervVKik = 1835400250;

    if (tMqncNvKq == true) {
        for (int vMaULVPMaXZtuHKK = 979296071; vMaULVPMaXZtuHKK > 0; vMaULVPMaXZtuHKK--) {
            uervVKik += uervVKik;
        }
    }

    for (int QTTDeUBzGBShst = 874011525; QTTDeUBzGBShst > 0; QTTDeUBzGBShst--) {
        euTjktPFsmK *= uervVKik;
    }

    if (tMqncNvKq == true) {
        for (int OjZxH = 121306197; OjZxH > 0; OjZxH--) {
            euTjktPFsmK *= euTjktPFsmK;
            uervVKik += euTjktPFsmK;
            euTjktPFsmK += uervVKik;
            uervVKik *= euTjktPFsmK;
            euTjktPFsmK -= uervVKik;
        }
    }

    return uervVKik;
}

int OLlQUyFXRQXlU::tRzNQzfYaqaeAHRj(bool wtDTeFrVV)
{
    bool GhGgRWi = true;

    if (GhGgRWi == true) {
        for (int UFSbkZgJqpZNjh = 2061007332; UFSbkZgJqpZNjh > 0; UFSbkZgJqpZNjh--) {
            GhGgRWi = GhGgRWi;
            GhGgRWi = ! wtDTeFrVV;
            wtDTeFrVV = ! wtDTeFrVV;
            GhGgRWi = GhGgRWi;
            wtDTeFrVV = ! GhGgRWi;
            GhGgRWi = wtDTeFrVV;
            wtDTeFrVV = ! wtDTeFrVV;
            GhGgRWi = GhGgRWi;
            wtDTeFrVV = GhGgRWi;
        }
    }

    if (GhGgRWi != true) {
        for (int NSayK = 1675567041; NSayK > 0; NSayK--) {
            wtDTeFrVV = ! wtDTeFrVV;
            GhGgRWi = ! wtDTeFrVV;
            wtDTeFrVV = ! wtDTeFrVV;
            GhGgRWi = GhGgRWi;
            GhGgRWi = ! GhGgRWi;
        }
    }

    return -1297850170;
}

string OLlQUyFXRQXlU::OrZDJgPOzYk(int pDaxGW, string lqFlc, double WrVynOgLwiEUEYz, string uxmoePSOk)
{
    string AvzhQyOKW = string("wVIDxEFkJYSOAXPVSJsSmDqlBXKzIIpXqoyFwUEIQRoutIjDmpkogPoaPvMojbuyBbmgpURhgdPPVqSOmzywDmkbzMKlZEshsWzxVEeOHjeZiGpBJUSaUxwREdJZJxhNbcmndayaYcmBQHTQTqNoDOvFQLKZrmAiDfUcPwAKxgTygGwpzkpeDFRLcfqToQgOQgwmPnYySwYnczgyXIDxadOOgOHSsgalgT");
    string sdqYD = string("dUyLvTeRoldWTkmSVewuaELlvccLFbcccCgvhwQytBVAGgDZxBMCpVqmPYeibllLWJpUyfPqeAiyfZdklezqksKGFrfPSlYz");
    double IyKzQT = -551393.3341799094;
    double OoDPMAmxoKlhMq = -297574.17099413;

    if (pDaxGW >= 1263886886) {
        for (int PgdpQYgDzULQ = 1499087883; PgdpQYgDzULQ > 0; PgdpQYgDzULQ--) {
            AvzhQyOKW = lqFlc;
            lqFlc += AvzhQyOKW;
        }
    }

    for (int HchSKeQh = 919592071; HchSKeQh > 0; HchSKeQh--) {
        continue;
    }

    for (int hbAYde = 298278383; hbAYde > 0; hbAYde--) {
        pDaxGW /= pDaxGW;
        pDaxGW *= pDaxGW;
        AvzhQyOKW += lqFlc;
        uxmoePSOk += AvzhQyOKW;
    }

    for (int jWGryRJYcyHixDM = 1537427022; jWGryRJYcyHixDM > 0; jWGryRJYcyHixDM--) {
        AvzhQyOKW += AvzhQyOKW;
        IyKzQT = IyKzQT;
        lqFlc += sdqYD;
        OoDPMAmxoKlhMq += IyKzQT;
    }

    for (int yJFOIFmQnVpmH = 2052059971; yJFOIFmQnVpmH > 0; yJFOIFmQnVpmH--) {
        AvzhQyOKW += sdqYD;
        WrVynOgLwiEUEYz += IyKzQT;
    }

    return sdqYD;
}

string OLlQUyFXRQXlU::bOizdDuGHVsagJ(int IVyGdYB)
{
    double dgoGutb = -466038.1725270844;
    double aAmzPvewosWlQoxS = -1022120.486288403;
    bool saVVLEjuqDXl = false;
    string DBMvojXpSmX = string("PVxbANEbxoxCcOAXhqpiNrZPkFbllMvJqDhPkHpvmYDJdTDKsDuTC");

    for (int dXemiUInXu = 287060131; dXemiUInXu > 0; dXemiUInXu--) {
        continue;
    }

    return DBMvojXpSmX;
}

bool OLlQUyFXRQXlU::Nfdfmwbwbv(string WHwjuktxg, double aTlTUtZMRGOhOa)
{
    int jJXIFXOygOabIHfQ = 287193292;
    double oXhHHzfMXCvS = 295575.3661106544;
    int uacfAdqtAHfJnEPy = -316270677;
    double GrjRpzvuhFz = 38772.27782072559;
    string MeTkDDqXVGKyc = string("TwDwpeMSCwLzYMLwZMIqUffLbQvesFHWpewzFItDDpHfrdFlEiNYlJBsONhlxDlEFEjwfibdaojHEgGDFigQCqcGfDdnpAWjzIPJcSYCvcVVlMDlwIkmzJdbZjxHKCTVWrsfCFwarQDskSnkWtWaQbajSmMHUYWZGOYFVTvLQIxYSD");
    int zGKJqE = 637238788;
    double zwaGU = 774673.8513972798;
    bool rFdYwAWbnGSFUe = false;
    bool fVMHKqWBrHGUrmf = true;

    return fVMHKqWBrHGUrmf;
}

string OLlQUyFXRQXlU::lsPODrsQCh(bool qPHTFToIhhjmXHF, string FfRTkcoLfOrfaIGJ, double SoQNECEvMeYDTHqe, string mDgbAv)
{
    string BSqXbIaHVTdV = string("nqpoatrEaGOhFHUnygRuLLaBNgTFsCaGZyaTFckhmRwbbQsqNQOmmLgjFJPDbvSWdUKeYORQTDCaqVKaeneFzpFFmbXDPwrawAcmhDmosSZdRwBJthReNsnrLdOHLHcSUHTYAceaxyIsAAbfNXzuqUHVzpDeayEXd");
    bool fWarjQ = false;
    string tfuJCsu = string("BTfBYBTUYBSgMHycNXEZqrzdDvbVwnRHewrHkiwwQKRlcSktOQbXVkNgoodvEkTmtkSodACqWiFyqwUgwdUYaFpDnpnZfwczOtJMcZVTmZARMcivSslPsuJalvcdHBSKEBtsrAdUKmetHHhNcEddzwEffLhahrgwrvegbslTCXVSOFsuHRWpQrOwFwWcYpcYPyQcut");

    for (int pzjnEntDqFt = 1469799961; pzjnEntDqFt > 0; pzjnEntDqFt--) {
        FfRTkcoLfOrfaIGJ += BSqXbIaHVTdV;
    }

    for (int gHAZxB = 992311646; gHAZxB > 0; gHAZxB--) {
        FfRTkcoLfOrfaIGJ += FfRTkcoLfOrfaIGJ;
        FfRTkcoLfOrfaIGJ += tfuJCsu;
        FfRTkcoLfOrfaIGJ += FfRTkcoLfOrfaIGJ;
    }

    if (BSqXbIaHVTdV <= string("nqpoatrEaGOhFHUnygRuLLaBNgTFsCaGZyaTFckhmRwbbQsqNQOmmLgjFJPDbvSWdUKeYORQTDCaqVKaeneFzpFFmbXDPwrawAcmhDmosSZdRwBJthReNsnrLdOHLHcSUHTYAceaxyIsAAbfNXzuqUHVzpDeayEXd")) {
        for (int gQghXC = 719144674; gQghXC > 0; gQghXC--) {
            mDgbAv = FfRTkcoLfOrfaIGJ;
        }
    }

    for (int YbHLUjNLQY = 691080737; YbHLUjNLQY > 0; YbHLUjNLQY--) {
        tfuJCsu = mDgbAv;
        FfRTkcoLfOrfaIGJ += tfuJCsu;
        tfuJCsu = BSqXbIaHVTdV;
        tfuJCsu += FfRTkcoLfOrfaIGJ;
    }

    for (int WnXKAqdtbxuqkMdz = 1421062423; WnXKAqdtbxuqkMdz > 0; WnXKAqdtbxuqkMdz--) {
        continue;
    }

    for (int UXzngBxaCDZGq = 638032828; UXzngBxaCDZGq > 0; UXzngBxaCDZGq--) {
        FfRTkcoLfOrfaIGJ += BSqXbIaHVTdV;
        BSqXbIaHVTdV = tfuJCsu;
    }

    for (int FHzzBLyyKAG = 195781197; FHzzBLyyKAG > 0; FHzzBLyyKAG--) {
        FfRTkcoLfOrfaIGJ += BSqXbIaHVTdV;
    }

    for (int vPcmzzZkBhZsYKBE = 825415549; vPcmzzZkBhZsYKBE > 0; vPcmzzZkBhZsYKBE--) {
        continue;
    }

    return tfuJCsu;
}

string OLlQUyFXRQXlU::YOyWGDZIDsZn(int vCGuyhgbhaEu, bool rmQlakZMxo, string LSfIy, int AnuRIxoHdZCMP)
{
    int GqQwKWcvaEuX = 1651755749;
    bool iyuQlHP = true;
    string CxonHpLBpvqa = string("sMbtNqXsMxbSvRsRfUdahxfpjlKQiTYxVZGgOqfDGdCfQINXXwOCCAsZNdcSocbjpZjfJbYBuQGaYQNwPVTMViPtOTGFMGZaNXezTDvvvYoDTYAUNSklzLIMKOxuQlbnUtENSrwGPNskLXVgKwtxiCKjFpaxCZvODCGNCzkApnJflBAILUbfrthYYTftCsGNXpwNFPDUrBlwJ");
    string gATGqlgfuppWghiZ = string("PoRByJiVSUPrYOnBeObeXnPPhFeZmEDAqwPFozeHJlfpXwZewaOJDjgwNnlQidVuqEfNAgpOCqTDWmARFxPOsrOkEZFhqJyrcNZpdebXzlBfjEdIYeNhyyIMfxdmGklftYPhUoGxuqHFPjkLaTMDKoPXoqNhiyYOOAHJWWUOlmLvLXopofbHZbZdYkauVERHXvIIiqjQfnH");
    int mLJxhkku = 767848063;
    string YidxeN = string("HLWpKnFGuwdCQplBuwXXNlZrrHfGIhTtDHzgmLIukGwXoOpKbHeNLyCnOVcyCmHiOkGMzOWwNtckchdHTsIfeeSWKlGleQjuNGFAOOTBlxrRMsEkiAKIJbLIKLGytnRZaRxnhEMjirYDoQTIdmIEaDtwFoMDyytVusEwvlFazUSnhNkwKM");
    bool GKGOUg = true;
    bool xDCAttNEnbp = true;
    bool MdrdGTWWlHQSSM = false;

    for (int ZjgKOeYJTSbSeEc = 50408509; ZjgKOeYJTSbSeEc > 0; ZjgKOeYJTSbSeEc--) {
        xDCAttNEnbp = ! iyuQlHP;
        CxonHpLBpvqa += YidxeN;
    }

    if (vCGuyhgbhaEu != 72499485) {
        for (int HmtSTpIE = 142014115; HmtSTpIE > 0; HmtSTpIE--) {
            continue;
        }
    }

    for (int ooAOVLwEwTmjtJ = 710003247; ooAOVLwEwTmjtJ > 0; ooAOVLwEwTmjtJ--) {
        continue;
    }

    for (int kmHxsdh = 1222068877; kmHxsdh > 0; kmHxsdh--) {
        AnuRIxoHdZCMP /= vCGuyhgbhaEu;
        YidxeN += YidxeN;
        AnuRIxoHdZCMP += GqQwKWcvaEuX;
        xDCAttNEnbp = rmQlakZMxo;
    }

    return YidxeN;
}

void OLlQUyFXRQXlU::VatViC(int BMsoeDubNZAPj, int EqSaLUkpm, double IDLwQTfwDJ)
{
    double XBzNiOq = -248048.4814697375;
    bool phnKLlaGBFZsQjTP = false;
    double NyRMd = 775781.601798657;
    string VUXkXkVB = string("aDVlZKSjxFwVjWCoGXEhneExZvHFMJbiptLszvyfRvChUZAzOWkRpbhBdEIOgFlxYVGjPTOtrPFBUxXrshXHvKDelentbkbglRldnGdimaueRJl");
    string OZWuTcBuLlH = string("gjovRHdMZPTbUyxhMtRJmLPRUPtLwSeSPa");
    string yCTOxphpZy = string("pVrWOVDREOAyeaMieRdQAQJZLkLTVMWSklHSYwAOXEXggGPwiNAqHqHEzgkwZQLrfjabXRgBqfVCXbnSfJpOelaTEWeEMDxjmhpiGaWdnISQarXbIJuok");
    string kAgIuSu = string("rUuUOxPpJdPzxSxfytelPhATRZjGCZpVoKpeFwgyihriNvvGUqNOcGLvFSmYLwYwGBeQYeyddlSFGbmaUhLlFNYNzxazjxIOtrDwzOeoSSucHyfEucCZtgiZDJsJNwgyEvhgkwhkqKyamZBMyRfk");
    int IBoyoGBOuYL = -1956171484;
    int mODBVQw = 1249716396;

    for (int rnoQxZS = 1551753432; rnoQxZS > 0; rnoQxZS--) {
        NyRMd += NyRMd;
        BMsoeDubNZAPj /= BMsoeDubNZAPj;
    }

    for (int IKNhJaB = 1036829745; IKNhJaB > 0; IKNhJaB--) {
        OZWuTcBuLlH = OZWuTcBuLlH;
    }

    if (mODBVQw > 1946450568) {
        for (int WEvxLBxPwzbL = 1652545816; WEvxLBxPwzbL > 0; WEvxLBxPwzbL--) {
            continue;
        }
    }
}

bool OLlQUyFXRQXlU::LRSMuDDXNSWSAY(int pbubpLVncTmt, string WEKLSWPsIAW, string qHqeWmiRYq, bool yFdjXLFjNcQpsSg, string pBBUnDhfAIrOfFmK)
{
    int RgHpdpVc = -937511511;

    for (int SlVLNvxtwnyYGq = 2000635766; SlVLNvxtwnyYGq > 0; SlVLNvxtwnyYGq--) {
        WEKLSWPsIAW += qHqeWmiRYq;
        pBBUnDhfAIrOfFmK += WEKLSWPsIAW;
    }

    for (int XWABPqzxlHXZeY = 1002056756; XWABPqzxlHXZeY > 0; XWABPqzxlHXZeY--) {
        continue;
    }

    for (int LSQuXxh = 358987798; LSQuXxh > 0; LSQuXxh--) {
        qHqeWmiRYq += qHqeWmiRYq;
        qHqeWmiRYq = qHqeWmiRYq;
        WEKLSWPsIAW = qHqeWmiRYq;
    }

    return yFdjXLFjNcQpsSg;
}

string OLlQUyFXRQXlU::KbTQXEqVuTURXWV(double HNVsJoIWnH, int RPLBiRKtKX, int cAgKCzwpuiYtPD, int swtyvFKbH, bool fuwxGFELduxo)
{
    string yhmdYrFblQY = string("SQqgNWjTbXaGaAbBuRte");
    bool vOsJveNo = false;

    for (int QhrnlAvYCRxX = 1141998297; QhrnlAvYCRxX > 0; QhrnlAvYCRxX--) {
        cAgKCzwpuiYtPD += swtyvFKbH;
    }

    return yhmdYrFblQY;
}

double OLlQUyFXRQXlU::mCJvHalfMhCEeTw(bool capYTxJQB, double cqwnRQpmOck, double uZyPO, double bFEMvWKhGjPGOwC)
{
    string rDqmhdrQBMGTh = string("CsHyozloJDgZxjBYEWWKKspRqardXI");
    int qqELdscvGWlDyK = 999248334;
    string duumqEqG = string("vwMhtzXarQmZNRUqNNUmAdySsLOQuKeTNuEtfcIVgDzFgqHBdMPbGBLzXPcwSyLbpXqxyCGHcSlgTgPGqbpznPMGfqOMwIvaomRROXyLDbvzseqzPHMfPfYfSyYfcSoOfUhjQGmrenqoGqyoZUihglqrNQIFmJngbEocSsvyOaC");

    for (int LtcUSDlOPflA = 1093002694; LtcUSDlOPflA > 0; LtcUSDlOPflA--) {
        continue;
    }

    return bFEMvWKhGjPGOwC;
}

bool OLlQUyFXRQXlU::vWcuGvGkXBqmwOt(string rJfTdZe, int aWUUpfYsettm, string uCUpsLKnbNkqcQL, bool QiNzx, double rKWVHHwY)
{
    double hDIiqlyMNyOQVrV = -573903.8448982568;

    for (int pNTVXsO = 552827470; pNTVXsO > 0; pNTVXsO--) {
        uCUpsLKnbNkqcQL = uCUpsLKnbNkqcQL;
    }

    return QiNzx;
}

string OLlQUyFXRQXlU::pgPUZclpLRzwQ(bool BPSILPEPGUOhZ, string bvEibB)
{
    string rDkgdUr = string("fw");
    string HWEHBQkE = string("AfeLrcRUkDvabGgWEzfhxJOEpgsTIdGXKUsjQyQjjBQnKsPAGOYfinPAvNrldopeqNbrJWOXmtKrtQboaYVPNdpnbDIDwpxDadUDiGJPDmaHNbJsOyltywpMKdKfHxRaMoEaengiwvNyGvrvXQpgXAAcoBlUvBoQJAApjlIzmUAhxqnyzzQb");

    for (int Bcqrc = 787906275; Bcqrc > 0; Bcqrc--) {
        bvEibB += rDkgdUr;
    }

    if (HWEHBQkE == string("nICqiJPkHUXxUFEEILcczuHGoPPMEYUmSWAjpxsrlXTOdkduRtUvKrsKiBhzMtAiObArGUmipQSihLua")) {
        for (int yVWZqpwwa = 1184619793; yVWZqpwwa > 0; yVWZqpwwa--) {
            BPSILPEPGUOhZ = ! BPSILPEPGUOhZ;
            HWEHBQkE = rDkgdUr;
            HWEHBQkE += bvEibB;
            rDkgdUr += rDkgdUr;
            bvEibB = bvEibB;
            bvEibB = rDkgdUr;
            HWEHBQkE = HWEHBQkE;
            rDkgdUr += HWEHBQkE;
        }
    }

    if (bvEibB < string("nICqiJPkHUXxUFEEILcczuHGoPPMEYUmSWAjpxsrlXTOdkduRtUvKrsKiBhzMtAiObArGUmipQSihLua")) {
        for (int CTZHxNXBXVsg = 1057185867; CTZHxNXBXVsg > 0; CTZHxNXBXVsg--) {
            bvEibB += bvEibB;
        }
    }

    for (int FwyuXiOpfxBGbn = 900961784; FwyuXiOpfxBGbn > 0; FwyuXiOpfxBGbn--) {
        rDkgdUr += HWEHBQkE;
        bvEibB = bvEibB;
        bvEibB += HWEHBQkE;
        rDkgdUr += bvEibB;
    }

    if (rDkgdUr > string("nICqiJPkHUXxUFEEILcczuHGoPPMEYUmSWAjpxsrlXTOdkduRtUvKrsKiBhzMtAiObArGUmipQSihLua")) {
        for (int tygSKPq = 1929654106; tygSKPq > 0; tygSKPq--) {
            rDkgdUr += HWEHBQkE;
        }
    }

    for (int rZpuzu = 999504624; rZpuzu > 0; rZpuzu--) {
        rDkgdUr += HWEHBQkE;
        rDkgdUr = HWEHBQkE;
        rDkgdUr = rDkgdUr;
        bvEibB = bvEibB;
        bvEibB = HWEHBQkE;
    }

    if (HWEHBQkE < string("AfeLrcRUkDvabGgWEzfhxJOEpgsTIdGXKUsjQyQjjBQnKsPAGOYfinPAvNrldopeqNbrJWOXmtKrtQboaYVPNdpnbDIDwpxDadUDiGJPDmaHNbJsOyltywpMKdKfHxRaMoEaengiwvNyGvrvXQpgXAAcoBlUvBoQJAApjlIzmUAhxqnyzzQb")) {
        for (int hbxCnPk = 456583027; hbxCnPk > 0; hbxCnPk--) {
            bvEibB = bvEibB;
            HWEHBQkE += rDkgdUr;
            rDkgdUr = bvEibB;
            bvEibB = bvEibB;
            bvEibB += bvEibB;
            bvEibB = bvEibB;
            BPSILPEPGUOhZ = BPSILPEPGUOhZ;
        }
    }

    return HWEHBQkE;
}

bool OLlQUyFXRQXlU::RfVkWVRv(bool FtGjFKYwBbuwgOe, double FKHtvfchKSijrzS, string SsOFhqVvll, bool zlAjMraKCOv, bool LHRuNPkb)
{
    int YGEMhUBtFHNsTwF = -739389242;
    double WQUaYCqtAzn = 397302.9722743672;
    string tDGPFUwYWfnPXKfA = string("jePFerfnGtwRHAQUQhCUfJJfBsRGmukgTmBmRAohbnaiCsTQILQAbvpDQbgHTHlCazrmRHpwIfQpXKxxgkscqjVFKTAgbNomezxWCalDPeLNisZMRDSwafGcfeoWWuJwsnQtaesfUaTGghHHuxXUqXoQsTaOojCuOBpwIjIZQkOTgSTjqBJCHISldcgwCkjppZNzFlfnIOpko");
    int dBtjMXWofExTOFTm = -1764434490;
    bool ygQRtCShLYSeIjnB = true;
    int iuYbvMLAiyFWEyoE = -34760291;
    double ospdTz = 317469.66621973395;

    return ygQRtCShLYSeIjnB;
}

OLlQUyFXRQXlU::OLlQUyFXRQXlU()
{
    this->xLnfznupcGcBkKC();
    this->tRzNQzfYaqaeAHRj(true);
    this->OrZDJgPOzYk(1263886886, string("sNLTdCAQOtXgGDOnKAdysxgsZORNVrNunzndSXRfvxgLDikMaEmEugzDdIvgdcxfzHqyDStpVl"), -507446.46638883196, string("AjXoSRlKPVXaSpWZsunClTXMdDpVuMuQrMeABZcsohNemSHcaJhXmumYwZsnfEFZSWiIZEJUvqJYqWvbRpTKPGxhGSKNNVHtMkSkaIGXcAuhkdtfwxvhHlVJvssfcmZUrveLjHbkcLeRejcDCEtmITmNkpGEOatuNpbVNpkjoTfizpOrNXhnxMPGJgZePApEEujPBPfTWUJzIRZUuHGzL"));
    this->bOizdDuGHVsagJ(2079355734);
    this->Nfdfmwbwbv(string("RqUDXbfwImSqQowSpUiNMCbseJeIsjLpqCkdrhHAgqsbKytfrGAtqnxtEVyZRMIBYFBWazRhLOFnRgSxxZYxBTZOcMolGzRWWMQiqtuKvKuGPWneYYYudMQDCdxivWGeZARrNGEdtLzFlHcBrqm"), 788971.5981103778);
    this->lsPODrsQCh(true, string("UNXhcPnBZmmAjDVJdzuvrMJUtskHTwKTxoyEeBnMOwOICuhMSnKRDxEwgeFdbaenLhpXNaxaOktxaZzCEDABiQsoDMRzhqLkpRTqUgEvjQPdRbUBksfdEVasJhsFSmuzQR"), 715886.9170148066, string("myuSJPKtUplhXZoOmXcqqLDbuacowtIiOhqWDYgCsIXtoSFakMuRSgoxqtHPDvGOwvlQFQYJBRwJrQuXyQqAzdUKikzStKpaSzahbuLJqwJbseNa"));
    this->YOyWGDZIDsZn(72499485, true, string("RWSnyWHIsRJZqMwDNKfDodAZvschGFOmhjEpYqVaibOEpRugOSxqDnNRHecYQraUjdedUkhlnDqkyvqbPQqowfIJJLCigiXocVwlaJvUUeeLQUxSljJiuXZqGRzLxopgpfPEsOYNeFZZZjtERAyJaKYIgbWuqBwUNNGcoYFNDDqNRENkUJfqeAMbnQBtAsFjGIKKTRHRRnZPfuIzSzSkMFZ"), -1018848487);
    this->VatViC(1946450568, -859252508, 985365.1286099855);
    this->LRSMuDDXNSWSAY(-616326378, string("qOGInevJdAFrIliaYycnKOBNEJaPrvUkIwvOVMMgJhkusuTyUqSnfvFeZRIPNyLHdV"), string("vsxlcXvSPElRgNzUtUBFOCCLhOKMXdmKWMTywBoqIKgRDcLwlIbOBmZEEBSmPOXGSInWeTrlsnuavhhCnrUlpshbrTKLuCqTludxvwgvqnbUkSsQRRPQxLGCdUwBQbLJdrKXhDppEZujwxKLR"), true, string("IyocqWnaXHhmMxeODkWNBDTqlwhHYuPRqpVvjFgVuQFrblJqqcTGFGIFsPmYLWFAPRgLNWyzHWtiOVLbJUqVzhTeCgUKqUJVBCuwecKogtUBduoCGMLKMpMPzWlMrqcWnePJYeLRnTJgJLPkwK"));
    this->KbTQXEqVuTURXWV(477004.8221978837, -1314140415, -1083116642, 1747213047, false);
    this->mCJvHalfMhCEeTw(true, -252232.2867250299, 149611.8973291713, -676113.3755240157);
    this->vWcuGvGkXBqmwOt(string("hHzfdznwY"), 1930377178, string("UnTIsylXhoVUDQMdvErHohLjmeZHnMyLBgyYgBDXVHAdhJROrwhiuEIImPkBXqOLcOOP"), false, -81509.02059211106);
    this->pgPUZclpLRzwQ(true, string("nICqiJPkHUXxUFEEILcczuHGoPPMEYUmSWAjpxsrlXTOdkduRtUvKrsKiBhzMtAiObArGUmipQSihLua"));
    this->RfVkWVRv(false, 853603.3627235169, string("ZVGPgbyBAYVEFHVHKVkuRciALLOioSysPAsedjJyPTJvXcYVMzVKTRZPxfKxCWKEiVpVgbqdidLXVysZYtZZBtfwGRCfMCYVGeqYmvDIHxrdZqlonVgBBwHiBgnRwEXzxLoffTrlFTokcFarKcAMkPUeoRAzKKwWbJFyoNyTCccxlnaLFKkwROMu"), false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GCdkmSH
{
public:
    bool FYyxk;
    int EUvZJLLm;
    bool OSLRI;
    string GCrAUCVmYrXl;

    GCdkmSH();
    string HwGjoGqdTAjGrtR(bool eIPZdUvdS, bool sBPpJxuZJpEmlMK, bool QNvPniTvvzMU, bool aLklyQzobFxb);
    double OZvAWWeaSjuSGiFk();
    void GgGkCvPaD();
protected:
    int xPUAGOCj;
    string XOdpBrxqolPmm;
    double DTdOBEF;
    int PGEpMuC;

    string eqPbYDouORhJ(string zrWJqtVP, double oehMg, string RHKKq, int rmZnTCQaXV);
    void RWbpTSPVq(double FusKTqjncPp, bool HvWqfUxLDklDm, double BzTAexBvJapAVCn);
    int nlQhYsJGQFHcIaD(int ZTnOnwaFYTVWeLO, string VnzvpmWwijju, int exfhSbnqQK, int xKyvlkLFz, string lkyug);
    string YJbIolcBTjfcziRE(double DuPLUpzBQL, string fJyrgwyqPQUZ, int XkuqVLWngKK, int TMloezDz);
    int XixziOWsTX(bool EHLSanLGc, double ExbtBDqU);
    string VWEzcLdscfrTJLH(bool sZGiQZJkgaQ, bool ruoQUQSk, int jHYtHnKqWqVcmtMI, bool fiYFgV, double Pkdop);
    string wgIOAutj(double bqAnrkn);
    int CcPIZCWK(double eyvTbMdb, bool EmFfgJTfmdumrq, bool WMHpDuOqQZO, int mkNhpVL, double tzHsHIdP);
private:
    string HZCMTWovkufVdG;
    double fsSDj;
    double KlmKFVsE;
    int YNRusJ;
    double RgEBALBnkSao;

    int ZtuPJpwnlAt(int WWhmyAqz, string aoczVeeDb, bool uyJIq);
    bool PIYlzUDQyj(string FndHN, int bWIzDLX);
    void NlCpVPJuRH(int PYEAyz, int pjjLdGk, string xPuiBEOuUayb, string qYXbZMFByiwa, double gkACNgoB);
    string MfnxzYfjSnqcO(string QvTARUlo, bool ylxthyZN, string yqUKgZvReOZhG);
    string EirjVTEqbNzDOvrQ(double HVUenuUY, int lBiRBuVEPR, int LMaFOxQDaaMs, double GcEeQo);
};

string GCdkmSH::HwGjoGqdTAjGrtR(bool eIPZdUvdS, bool sBPpJxuZJpEmlMK, bool QNvPniTvvzMU, bool aLklyQzobFxb)
{
    double ThEim = -364056.23350505333;
    double AUgctvkknuXWQA = -340090.078463031;
    int HgjXQ = -716263598;
    string DiSsOteK = string("nJblPoVUrgMEVUdNdNXnYdoNKVnJqNBqyWMyYOOYBwuISWNmTxijpIvXKMBKgrVjkYmiechaOEyebkREkKkuzXXEDhSFfKDPEAsofnTTeaWUFoiJpiZLWtyVRKSeECunQqjoPiDnJuhrifgUPlwbvWeZvuKeQiCJQxdzdIXXfQz");
    string emuqEHQzdhQvhor = string("VLztlLtLGdflBdXpEEDgaIFVHsyOmLWDJDwJYUJFoUrPAeHXaQaxntNQWRLokIqNVxKscbhgNIXjtZOjRDpLOHznJLefdRzempLEupDGtDGvjgeJArATdIEhRzjIUfpUQdkaPMJoZPFvHKqYhexcDYrTDmIvdUWrlUdZYJWrlxChFnbCFAexiwpXeGsKTDNYkhTm");
    string oXfSDC = string("okytdDjjdUzazHhTONAPkSsfCxELAfyyAbtnBtLpHyioYuQjwnDndLmmcDvwJUSvmyREijRzgfNPIclomMoghuGBTE");

    for (int wphtGr = 1112804767; wphtGr > 0; wphtGr--) {
        continue;
    }

    for (int ldNMQDjYahiHSBh = 838020309; ldNMQDjYahiHSBh > 0; ldNMQDjYahiHSBh--) {
        emuqEHQzdhQvhor = DiSsOteK;
        emuqEHQzdhQvhor = oXfSDC;
        sBPpJxuZJpEmlMK = aLklyQzobFxb;
    }

    for (int zfCTLY = 1413556218; zfCTLY > 0; zfCTLY--) {
        continue;
    }

    for (int tncNNAWQVjqKu = 1128211800; tncNNAWQVjqKu > 0; tncNNAWQVjqKu--) {
        continue;
    }

    if (sBPpJxuZJpEmlMK != false) {
        for (int Khrypt = 986888476; Khrypt > 0; Khrypt--) {
            continue;
        }
    }

    return oXfSDC;
}

double GCdkmSH::OZvAWWeaSjuSGiFk()
{
    string rfMgNRJUxywA = string("ZmwfiSkkWDeGtvKGtvkkusRdAdDIiwJ");
    bool sHLVjanCo = true;
    double MDrKPAbQHvqNc = 153623.90339940222;

    return MDrKPAbQHvqNc;
}

void GCdkmSH::GgGkCvPaD()
{
    double bgyBZ = 317971.3842738868;
    double DYxNUfCFkpHS = -1048301.1881372917;
    string LAdmJyNBZYrA = string("NGyzHWiZZEVdTaEcsdWUaoSXtetIyQtDjYwWozpFUykqGJZkyFnUPwxNCLmGQYiYitVSnfhrtzjSGyGvNudEPfAjmjCECNwOrXsLafnjLyBljHjeeEOdxDhnazvQRmXWuLulQTWOrNiNMrwJPgppEcNRoWdUYSqrfBGJTXeUiFZzvdGEZAivYpdVTPPgaeTvErWdTcRjGYMGlVvKlWpJaYfBLBBNeXWVo");
    int RDetgIjFKTyKnp = 1148779157;
    bool XEBOQNgeSUeCKyw = false;

    for (int lNKnjSMmcX = 1831462894; lNKnjSMmcX > 0; lNKnjSMmcX--) {
        continue;
    }

    for (int eOASPmvpwJXsx = 1214500858; eOASPmvpwJXsx > 0; eOASPmvpwJXsx--) {
        continue;
    }

    for (int VFmCtzzEhwsF = 1129187665; VFmCtzzEhwsF > 0; VFmCtzzEhwsF--) {
        continue;
    }

    if (bgyBZ < 317971.3842738868) {
        for (int ObaLTlOMukLuIOL = 145240011; ObaLTlOMukLuIOL > 0; ObaLTlOMukLuIOL--) {
            bgyBZ += bgyBZ;
        }
    }
}

string GCdkmSH::eqPbYDouORhJ(string zrWJqtVP, double oehMg, string RHKKq, int rmZnTCQaXV)
{
    string rGPzqB = string("covKETVcjFuihPRJuXQMSXClMaITOpZtUdAqAvakvHvSQctJQsGxsDwkKROliIOmaEpUTbLZTOEKZMTQLtypkrwasHxxrbRXFcRYJMixYtFlKKTYRgdjiEgkOQABh");
    int zwdXeTz = -904407568;
    bool aKtpkMoF = false;
    bool lRczheo = false;
    double iapzUZMRvMpnjO = -880768.201462002;
    int HPTjadykbWwmt = -703190332;
    string TcbzBU = string("ZbjeaasyYcbPtwtvMXCuGTIldWChxVAkzFStODoQloKkPpTHwjoVzIiLZUUEfHOXfUIjfjaLtVtOttDgmaMYInJlYTvIftfVpkUKj");
    bool nLtRDVvVyhZlne = true;

    for (int kBlCrRtfo = 877135338; kBlCrRtfo > 0; kBlCrRtfo--) {
        rmZnTCQaXV += zwdXeTz;
        HPTjadykbWwmt -= HPTjadykbWwmt;
    }

    if (lRczheo == false) {
        for (int UZwFjbvxu = 1946566039; UZwFjbvxu > 0; UZwFjbvxu--) {
            continue;
        }
    }

    if (zrWJqtVP <= string("covKETVcjFuihPRJuXQMSXClMaITOpZtUdAqAvakvHvSQctJQsGxsDwkKROliIOmaEpUTbLZTOEKZMTQLtypkrwasHxxrbRXFcRYJMixYtFlKKTYRgdjiEgkOQABh")) {
        for (int aYBpnRtpke = 316166998; aYBpnRtpke > 0; aYBpnRtpke--) {
            rGPzqB = rGPzqB;
            RHKKq = zrWJqtVP;
        }
    }

    return TcbzBU;
}

void GCdkmSH::RWbpTSPVq(double FusKTqjncPp, bool HvWqfUxLDklDm, double BzTAexBvJapAVCn)
{
    string hBAJekbXZqeF = string("LXzvKFciIDtSJgeEZFtEFGh");
    double vWivumFpFzejl = -242680.54769368962;
    double luwvBKYLArQO = -83761.00394751677;
    bool mPFdPdkLE = false;
    string gMiCosUttWE = string("RSHicFlqpgSjfGxcHKTiBuoBMIAchGVpYOEThjTXLmKwloBgoLyPAcMKAbpGaXMPTqnrdBQClSDVFpiHFtKDaPFAcHQXDUkWIJDxPCfnjYltneiDAdUhRmgARjJHuypzGaXQxqw");
    double EgjvlHGFHtMOFlyc = 971565.4267727551;
    bool YnnQxQDcMiAqqKsj = false;

    for (int FZkqXXaTO = 1647279866; FZkqXXaTO > 0; FZkqXXaTO--) {
        YnnQxQDcMiAqqKsj = YnnQxQDcMiAqqKsj;
        vWivumFpFzejl += vWivumFpFzejl;
        luwvBKYLArQO *= BzTAexBvJapAVCn;
    }
}

int GCdkmSH::nlQhYsJGQFHcIaD(int ZTnOnwaFYTVWeLO, string VnzvpmWwijju, int exfhSbnqQK, int xKyvlkLFz, string lkyug)
{
    int kZezMTAoSj = -674539;
    int SyjjfLtEzRVjAM = 74052962;
    bool BofEssSFBJDnAK = true;
    bool SGtFVUWeoUP = true;
    int oypBDvKRqyczryC = -1275164151;
    double KYhqgV = -647151.1355251393;
    bool SPxMDQwvhG = true;
    string TfeFum = string("oDXJGCiNDfKIGIZRlgYqhbaXqOoTzHkmwSpQXEqmRrTXSZMhOmNbeQWaon");
    bool buuozPCDmuwqErJ = true;
    bool ANtWhhzyezS = true;

    if (BofEssSFBJDnAK == true) {
        for (int xqBljaCbQrjNeP = 319541149; xqBljaCbQrjNeP > 0; xqBljaCbQrjNeP--) {
            continue;
        }
    }

    for (int PoQfgi = 307993589; PoQfgi > 0; PoQfgi--) {
        ANtWhhzyezS = ! SGtFVUWeoUP;
        ZTnOnwaFYTVWeLO += ZTnOnwaFYTVWeLO;
        xKyvlkLFz /= exfhSbnqQK;
        lkyug += lkyug;
        BofEssSFBJDnAK = ! SPxMDQwvhG;
    }

    return oypBDvKRqyczryC;
}

string GCdkmSH::YJbIolcBTjfcziRE(double DuPLUpzBQL, string fJyrgwyqPQUZ, int XkuqVLWngKK, int TMloezDz)
{
    double iPNxaRukhB = -428992.37955302506;
    bool kZtXwErBpBRnrdNN = false;
    double ymXpUmKMJKthYc = 55066.07705706474;
    string RUjVDsUVN = string("FPycjFDleRlALRoXZLgzocYTYaNBJUUUzqzISZnuywNlrWXJPNDKUTmOrBvFsfDTxhMJtxBwfMOYputdiuTbcdPgoYRPAsqOkBjuIMHoAQuTgeFXCjBIHxiBiFAYxrNdVxHNFUrxvVEsnluVOhvF");
    string zZvzOZE = string("qANrIXjzdRcFntQXztSSWsHczwIIgLjaMBsZ");
    double iUrmysDiUkpJaRMM = 387320.4096374889;
    string WJvkizS = string("JkRWMXdbRTGYRzRdhdDofbKYCmsZEccGHqTUIsJVJltiJXWebqIAJFiysvgLfaJHReH");
    double grjeRBXPJVS = 262135.4638207183;

    for (int NUHaFuRitgGyXcz = 914792055; NUHaFuRitgGyXcz > 0; NUHaFuRitgGyXcz--) {
        zZvzOZE += zZvzOZE;
    }

    return WJvkizS;
}

int GCdkmSH::XixziOWsTX(bool EHLSanLGc, double ExbtBDqU)
{
    bool DiYZfrkFYJOVSnF = false;
    bool lEUcyvphbfw = true;
    bool DeOCLxdeOIeV = false;
    int BmmSfbGpr = 1113483664;

    for (int qffztqebUVSlxufC = 127549583; qffztqebUVSlxufC > 0; qffztqebUVSlxufC--) {
        ExbtBDqU = ExbtBDqU;
        ExbtBDqU /= ExbtBDqU;
        lEUcyvphbfw = ! DeOCLxdeOIeV;
        BmmSfbGpr /= BmmSfbGpr;
        EHLSanLGc = ! DeOCLxdeOIeV;
    }

    if (DiYZfrkFYJOVSnF != false) {
        for (int akdGi = 486199447; akdGi > 0; akdGi--) {
            DiYZfrkFYJOVSnF = DiYZfrkFYJOVSnF;
        }
    }

    return BmmSfbGpr;
}

string GCdkmSH::VWEzcLdscfrTJLH(bool sZGiQZJkgaQ, bool ruoQUQSk, int jHYtHnKqWqVcmtMI, bool fiYFgV, double Pkdop)
{
    int KhEiDaEhfjHzCvPw = -210575985;
    string JqqnpWztsbQoY = string("XnevKEJPseVKpIeuaGjkrqwXiEKjpdpHXEqomNKatuBZoglfDSqDwYsqiCiLavZizjHdZPBZcfBfloqOPYfNkFIABjDoJmBuaWQIuWFDVjdcLLlPtVivxQyMwYibFs");
    string khhsOsSjGQ = string("eZGoaDxPuKGkZhZmnbuRdZiZQomwkColvRUAyTbBLIHszcIGmpLsvRfwJcrCVkmDcSvwhwGJyKgiqaNdMlwZTouAkYZdjqpvYsHZVJtzjuJhbTfnnQwFDlvPsnSWOpAUExeFdvJsPAYfgtzPSeNvMNKO");
    double VyVMj = -368603.0251479096;
    int YnKXPNM = 685519466;
    double cqXlUeELpLaNSTGV = -277320.19764108583;

    if (khhsOsSjGQ <= string("eZGoaDxPuKGkZhZmnbuRdZiZQomwkColvRUAyTbBLIHszcIGmpLsvRfwJcrCVkmDcSvwhwGJyKgiqaNdMlwZTouAkYZdjqpvYsHZVJtzjuJhbTfnnQwFDlvPsnSWOpAUExeFdvJsPAYfgtzPSeNvMNKO")) {
        for (int AeYCHLY = 86179285; AeYCHLY > 0; AeYCHLY--) {
            Pkdop /= VyVMj;
            fiYFgV = ! ruoQUQSk;
            VyVMj /= cqXlUeELpLaNSTGV;
        }
    }

    for (int TzLFNmFS = 1306992604; TzLFNmFS > 0; TzLFNmFS--) {
        KhEiDaEhfjHzCvPw /= YnKXPNM;
        fiYFgV = sZGiQZJkgaQ;
    }

    return khhsOsSjGQ;
}

string GCdkmSH::wgIOAutj(double bqAnrkn)
{
    double xIluTaITXDSXOBJ = 468365.584588809;
    double FkeoWNeVxMb = -1016162.7701882093;
    string yjAQZPGSpoVJhw = string("lFadKfAAoGuutsJjqwNfbuKUWTOrUKBdQJTdrSqcl");
    string VWhqU = string("lkpzslbcfQNjmYwFxRsRvQskFgwJFUhUChDsikRqdZGCDcazzdjjXgyAelYfRTrywMrAQ");
    string rpBYZnxN = string("RHVJkFvgNjmqRGaizNePVkYlcbCVmbCzpwUAZdtYnPSKNMQacSakWKFhYKZMEwpBRftircQINlsRwmOrFIhCuaLR");
    int TykiHXeCGoDkAlL = -1088000966;
    string aRKzwLoDRnsz = string("sIOveBqyEjYZgoeaTevwGMsRfERIiNpqDMVEJlcTqrNEwZteHFSyqitbJwqgRrmKPlEQGOXUMzzHGNBsDwofivvvrnhZvQGWfAsZpMoKUoAMhYEOsXtqXIVjatfXEyPFkHjvxxFvwgpoLrwbWpOdGKOxRMbVuofgmYIppMNAAHMMQWXshgtXaGzIJSEUzqYxHMKDgSqZeojuXEUCDHjUQpzbCiVWYYbtwsMZjhinBigfTZ");
    bool OvWeuyfjNyKUN = false;

    for (int VbqwPpsfHEJcB = 1420550437; VbqwPpsfHEJcB > 0; VbqwPpsfHEJcB--) {
        aRKzwLoDRnsz += aRKzwLoDRnsz;
    }

    for (int ZaZYydkWYyreqye = 1115758969; ZaZYydkWYyreqye > 0; ZaZYydkWYyreqye--) {
        continue;
    }

    if (OvWeuyfjNyKUN == false) {
        for (int ZOARWf = 1133452954; ZOARWf > 0; ZOARWf--) {
            aRKzwLoDRnsz += rpBYZnxN;
            FkeoWNeVxMb -= bqAnrkn;
            FkeoWNeVxMb -= FkeoWNeVxMb;
            xIluTaITXDSXOBJ -= xIluTaITXDSXOBJ;
        }
    }

    if (aRKzwLoDRnsz != string("lFadKfAAoGuutsJjqwNfbuKUWTOrUKBdQJTdrSqcl")) {
        for (int AsReRGZgOe = 2113404842; AsReRGZgOe > 0; AsReRGZgOe--) {
            rpBYZnxN = VWhqU;
            bqAnrkn -= FkeoWNeVxMb;
            yjAQZPGSpoVJhw += VWhqU;
        }
    }

    return aRKzwLoDRnsz;
}

int GCdkmSH::CcPIZCWK(double eyvTbMdb, bool EmFfgJTfmdumrq, bool WMHpDuOqQZO, int mkNhpVL, double tzHsHIdP)
{
    double SDdWHd = 1014074.9898103523;
    int awnnnlJd = 1720399881;
    string oDNcRPll = string("YQJJSJZuhWxRemXDmOvYGzloLWTuUgAZzjPJsYMkGgIDsLKpterYkPIQsEZKoFbMvCDAdjXVKQqoJnIVsvRxPVSfzliBcEimMXhnYLbiLVTYHUtEeILgMAXOKpbhvBQpnXXZXtCdleYSUYEGuesSSqNXWtcgFimyixOJpVyd");
    int NPKxbDlzNNsanSm = 1018365941;
    int GYUTatt = 1416489736;
    int ygFJNqhMIHLDV = 706626128;
    bool tExZuNVOPDK = true;
    bool aGsoUIwPsmqQMEdU = false;
    int kgjcVPaTKmtdT = 1607160273;

    if (SDdWHd < 1014074.9898103523) {
        for (int vButgfwNUylnxmf = 695556638; vButgfwNUylnxmf > 0; vButgfwNUylnxmf--) {
            aGsoUIwPsmqQMEdU = ! EmFfgJTfmdumrq;
            NPKxbDlzNNsanSm -= awnnnlJd;
        }
    }

    return kgjcVPaTKmtdT;
}

int GCdkmSH::ZtuPJpwnlAt(int WWhmyAqz, string aoczVeeDb, bool uyJIq)
{
    string elnqaWtgk = string("ZindGkEIUbapstXAFhznWynjUPhInblkjmOzWxugMoGTYtRknvAJsGbwTNIVIaLoIquoQOnEhrGFQozRAIWzu");
    double wRLujArm = -369529.3566371662;
    bool hafLD = true;
    int RmLAYODEKVT = 1587076809;
    string NwSuebmvYbJV = string("CEufNovIfakjFuCIyjkqzkoUKMLVDExVgmlPxUtAaRBiOketcwQWawDZGvnHgUsqgfMMIFhFftdamypFSrwBOIQbYcHzRjvhkDTTcjJnVP");
    string UkQqainRBGYZ = string("tPbIRQvgFuYROkZllvPkibWuC");
    bool fydPymteuFnOdz = false;
    double IrTHDftAx = -82610.97454626206;
    double acsIIfThyNXCr = -926345.7051237954;

    for (int urzXgRNHJHi = 1036935278; urzXgRNHJHi > 0; urzXgRNHJHi--) {
        acsIIfThyNXCr += IrTHDftAx;
        UkQqainRBGYZ += UkQqainRBGYZ;
        WWhmyAqz += RmLAYODEKVT;
        acsIIfThyNXCr *= acsIIfThyNXCr;
    }

    for (int eUpozEqU = 347166046; eUpozEqU > 0; eUpozEqU--) {
        aoczVeeDb += elnqaWtgk;
        uyJIq = ! hafLD;
    }

    for (int AKzsYCVfSjwNakbg = 973784166; AKzsYCVfSjwNakbg > 0; AKzsYCVfSjwNakbg--) {
        IrTHDftAx /= wRLujArm;
        wRLujArm = acsIIfThyNXCr;
    }

    if (UkQqainRBGYZ == string("CEufNovIfakjFuCIyjkqzkoUKMLVDExVgmlPxUtAaRBiOketcwQWawDZGvnHgUsqgfMMIFhFftdamypFSrwBOIQbYcHzRjvhkDTTcjJnVP")) {
        for (int afeZnNplrNxnj = 77250423; afeZnNplrNxnj > 0; afeZnNplrNxnj--) {
            elnqaWtgk += NwSuebmvYbJV;
            UkQqainRBGYZ += aoczVeeDb;
            aoczVeeDb = UkQqainRBGYZ;
        }
    }

    for (int jOHxzJTmjo = 132372576; jOHxzJTmjo > 0; jOHxzJTmjo--) {
        acsIIfThyNXCr *= wRLujArm;
        RmLAYODEKVT -= RmLAYODEKVT;
    }

    return RmLAYODEKVT;
}

bool GCdkmSH::PIYlzUDQyj(string FndHN, int bWIzDLX)
{
    int mBDXfwdvTGHB = 1720668359;
    double YLirmCWrIlz = -436719.0215296322;
    string tonTxnUI = string("SnICHZfUOmkpBGTbGjXAeFtLUZuWYuZsgQfdJrNPKCFgDoivTxuyGnrPByRYcjfkrdwPpqS");

    for (int kZFCedTSQ = 1343708862; kZFCedTSQ > 0; kZFCedTSQ--) {
        continue;
    }

    if (mBDXfwdvTGHB >= 1720668359) {
        for (int FponZSJGfqLeGmQY = 1435280656; FponZSJGfqLeGmQY > 0; FponZSJGfqLeGmQY--) {
            bWIzDLX /= bWIzDLX;
        }
    }

    return true;
}

void GCdkmSH::NlCpVPJuRH(int PYEAyz, int pjjLdGk, string xPuiBEOuUayb, string qYXbZMFByiwa, double gkACNgoB)
{
    string WmFBeDCg = string("XjLwcNpqAesSlBvWYwoghWHgmqrhKUXKzWVrHbwheZkiVHdDqWfRUSMwKRIjwVCUTgQVBQjUhX");
    string OnybDlTa = string("vXcGHUKhvTVscDBkuYwnQzOmVulKydizdCTPqCBBAHCQqlBGTIyYMkDsvAOetECeIapcUcNpNIJzZbZuatdfytiNYQWPKnpprKGSiKVEYnakPOOLWeCYvFiyBmJFTzHPPzHoudWffZFoDlNacawYLHXiiaThbJCgWeFiyAZiMETXOZUYqt");
    double cDusacp = -214427.4677368998;
    bool AAdlEmiamoVhb = true;
    bool SKMOibhIpmOEistM = false;
    int YIXiSrcFokMn = -1803413975;
    string YtmUS = string("MUTkWWfwURnyzKJZQqIQfJsWBkcNeOXnYUvaAqKYTsKfGmzBZRAgSrWxYvMWGQgC");
    bool sGxFSd = false;
}

string GCdkmSH::MfnxzYfjSnqcO(string QvTARUlo, bool ylxthyZN, string yqUKgZvReOZhG)
{
    bool fJAWdbLNFMlsLIoD = false;
    int egZPQtZoICMijr = 2123561534;
    double ZxsVsktrk = 382746.6664062556;
    int aOQDBGuEVjM = -1991458233;
    double UACwmJlARudsX = -607225.5722058967;
    bool TpkcfLmJK = true;
    string aqRtnBf = string("VdHMLWBuTVlNevOsvwEDfAsiCSqAJxFTYnttTCuulJOeH");
    bool HspiZTLzS = true;

    for (int ayJqB = 122013911; ayJqB > 0; ayJqB--) {
        fJAWdbLNFMlsLIoD = fJAWdbLNFMlsLIoD;
        aqRtnBf += aqRtnBf;
        ylxthyZN = ! TpkcfLmJK;
        TpkcfLmJK = ! TpkcfLmJK;
    }

    for (int wMRIqrAEXqJr = 236442478; wMRIqrAEXqJr > 0; wMRIqrAEXqJr--) {
        QvTARUlo += yqUKgZvReOZhG;
        yqUKgZvReOZhG = aqRtnBf;
        aqRtnBf += yqUKgZvReOZhG;
        HspiZTLzS = fJAWdbLNFMlsLIoD;
        aqRtnBf = yqUKgZvReOZhG;
    }

    for (int KTGdjDTNVBupz = 1093551529; KTGdjDTNVBupz > 0; KTGdjDTNVBupz--) {
        yqUKgZvReOZhG += QvTARUlo;
        ylxthyZN = ! TpkcfLmJK;
    }

    for (int WezVcDysHj = 360875306; WezVcDysHj > 0; WezVcDysHj--) {
        continue;
    }

    return aqRtnBf;
}

string GCdkmSH::EirjVTEqbNzDOvrQ(double HVUenuUY, int lBiRBuVEPR, int LMaFOxQDaaMs, double GcEeQo)
{
    string lyGTNTWwgiMQWr = string("UPxzttKokcQybOqkZvoLBQUIwkbthomViZjhmPSGtshzvOvgXjuwelMoElGgBpLgLqYyLvwSjfWywJduXtnXcEigSWZOiBySFwXWW");
    double DnfdHFFZ = -327492.7522015164;
    bool DPNsRtHldhURQMA = true;
    double QCKhyozfNbOEKn = 258640.62164929227;
    bool fbGtiyW = false;
    string jPPdfsamlZcuqCoy = string("gPBVKiFOPKltWHOEtcbmlImsNmggFuAeiWsUQBHTcDSmyqjcwOxzomsGyuybrniKeQGoqhBYRfMSeemGaShmcWFggniNCvePlohYawCNDrqSaPhgHxSbuwRQOQvbJwkwROzRAITciKNBOiNZOgLsVvyjLbIYedgHERWHfhTGkcPeUsmIQnKlSqcYhnLtQPunMNdAOHtXNtGARllwYVviAjgEj");
    int gOXfBbGVSbV = -1019756696;
    bool cDDIYCtAHN = true;
    string PWvsHcHs = string("mymDiqdANUZ");

    for (int NFmSYKmKEepZsj = 1466720613; NFmSYKmKEepZsj > 0; NFmSYKmKEepZsj--) {
        PWvsHcHs = PWvsHcHs;
    }

    for (int IFAcyREZhLhV = 626569670; IFAcyREZhLhV > 0; IFAcyREZhLhV--) {
        gOXfBbGVSbV *= gOXfBbGVSbV;
    }

    for (int jFjNlnL = 936651472; jFjNlnL > 0; jFjNlnL--) {
        LMaFOxQDaaMs += LMaFOxQDaaMs;
    }

    for (int RtddeLIVFQrlz = 1934644001; RtddeLIVFQrlz > 0; RtddeLIVFQrlz--) {
        DPNsRtHldhURQMA = ! DPNsRtHldhURQMA;
    }

    return PWvsHcHs;
}

GCdkmSH::GCdkmSH()
{
    this->HwGjoGqdTAjGrtR(false, false, true, true);
    this->OZvAWWeaSjuSGiFk();
    this->GgGkCvPaD();
    this->eqPbYDouORhJ(string("CiXBszXlANllTNWkGzKQOiUQOeZjSPrjCnUBuKoZjStFjqfdNGRWAcspnjLEwKqVwrcNjyminCgGYMTMzzbDqhmbUmpuEShOoShfvvHbaHaNOfPZWFTcNKzGEFyYveatKYGBwsDPTUSORuJAZMcGcGMQrckzOWUosulK"), 238855.24527102584, string("jJhJKuBGVMhcBofjDp"), 1094600603);
    this->RWbpTSPVq(291286.7198894157, true, -674660.5566762206);
    this->nlQhYsJGQFHcIaD(-1004660199, string("EKOc"), -722805288, -1732770519, string("JtBBBhxcFaePPsxDNpPfZePQdFpiulxgSZxoigttmcKjzGDRDKBrFyPZPWDKIYyrsDkJOEYcVJdwuCOZnJaQWJZMBKmoOSBJWWbtRNyMyxkSfxDHuBrJNfvcNjDnFSZFqnm"));
    this->YJbIolcBTjfcziRE(-136520.99066197715, string("HJmoutIhxXYrxHrfuHufWpFGGIlkLCkonFYpuYYUpvRnhnauoaFQPXPvwVqHNcLcNIjmTIEMEynhnodddwimjdMhZzaICumANjUhjmFXGrJjVmBAgluOwvnNpXNzuXkSIBdJlXYfVKVXLVlHJFIjRlCzGWmHBIEOaDXlHNWmrzcOAEmzbCwQpWkTD"), -65006140, -1191788485);
    this->XixziOWsTX(false, -164368.60537885447);
    this->VWEzcLdscfrTJLH(false, true, -744387166, false, -904436.9549453945);
    this->wgIOAutj(-197374.74410464836);
    this->CcPIZCWK(715595.3016607036, false, false, 2093590611, 864930.5475675883);
    this->ZtuPJpwnlAt(-1895569429, string("hARtpshFXKiVgzigHrzgGuGaCOKBONTPYwzjLtXTnLwGueAitctGnSZBYlyGYEgKWoXDuItmeegdaLloZnIQcEenqXgzTka"), false);
    this->PIYlzUDQyj(string("YWzxVwnaYVvqWgHPSSIioxpEmvNrKItDcBZxzFakQNRrbVNZtIXFkLckkfzwHtNOuBmLdHuFkcfbdNtxtpEvokLYxaEjZxfqfHrhFGMgfWiflazpXHEYLGHUNoaEFYYnwdeecULoCvPVMyGlGRxASk"), 180620610);
    this->NlCpVPJuRH(-934430918, 888691002, string("OoaLYDKNsatborLKHxXctMNtGpSKngSWetBhmcf"), string("HgEtDfGgdxielbZCnmJeyXCfvPJVzSLcFuRqSgXXqxqykqHe"), -699808.4368709418);
    this->MfnxzYfjSnqcO(string("AYkgZvIlVEPKnxgHQnneRWdFKANunEuOglfHFMxoxOzytBIAkxDraglXxeVMPaknmqg"), true, string("cbZeaKcTSTeMtkbhzxEclKrxeIhaPoRWqxRrWgVRMkzIYciZtntiINazmZeLeggvrgZLBe"));
    this->EirjVTEqbNzDOvrQ(844236.9960880316, -1317955115, 572067716, 228159.61626242293);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FENEIhUOQbzyrY
{
public:
    string nAzyxUl;
    int sTrhywEWcPGmD;
    bool mIdfwDp;
    int oNrVQYAtFiPrD;

    FENEIhUOQbzyrY();
    void SpeTpwJU(bool WzyfAdPkjDRH, double qGPMJKVJOckOh, double PPdsjbFbNOPDlGT);
    bool SQlMfAibt(int XUwsJQP);
    int IzEJPLRlR(double COcrZm);
protected:
    int CbzyMSI;

    void AcSjjwtdEZIvbnxQ(double peRoEGXGjqvM, bool nVuFFTFxlT, int xiXQLw, string AEIBPQMdEdDV);
    void WDfJkaxIug(string UmkyU, int uLvFcShJ, string WRNAwPtMVagxQawp);
    void cHASFmGgMqgGuRvJ(string pccIIUhlbZdiy, double bEASefuR, string rwHnbuFj, double ZWEVWCai, string hZNIDgwzxDm);
private:
    double iNwOyjFhEeUB;

    int YbFlqY(double lTnHxm, string QBoJCFENOHtcoKHf, double xRmAThoRe);
    void IbMPqLUhbXE(int HdgpjYFSmen);
};

void FENEIhUOQbzyrY::SpeTpwJU(bool WzyfAdPkjDRH, double qGPMJKVJOckOh, double PPdsjbFbNOPDlGT)
{
    string jVLCkxLl = string("xgZHnGsuJJKFGohzkqGaPvXSIJetZTTfiOZHlxsjFhAZWUtAyylGwfkpyTveJAXAJvzGosRvJCcmhebIAkaomoDQViXljYfLUhJmGILhDLkugFHBLRnHaulMlazjxzMfnCVENmgNneXO");
    string YhoCuOAzIiXGM = string("YyRdLyRszUEbMjRoLEyqzvqYxasxwbRgwQvBBersRNRbbkQzjvWrqgzgooIevNSTotpRNZyadnZLJfIsppbYZkLJDRgiIrdvmKtSofGZoQhPxLyJkSOcQkTFfLsmuUMrnyFNIMUeZJwGOxwusABqkhXkXYSWPhJyIUdTioNeQfLPZwHMTzX");
    string ESUMEMsJymmw = string("FbdqQecBK");
    double NyJzsaTugZj = -897436.1023556637;
    bool tgzwcXnPKPIaZ = true;
    bool WfBRWAh = true;
    string pmbKaAkUKuytIYrK = string("IicZMKURMzMJymssOShwxkqNEZctfKattRRwVWOxzuh");
    bool gOEeJO = true;

    if (PPdsjbFbNOPDlGT >= -897436.1023556637) {
        for (int KetAIFJGGmWB = 936563080; KetAIFJGGmWB > 0; KetAIFJGGmWB--) {
            WzyfAdPkjDRH = ! WzyfAdPkjDRH;
        }
    }

    for (int IkaKiTQXVUN = 1071951531; IkaKiTQXVUN > 0; IkaKiTQXVUN--) {
        pmbKaAkUKuytIYrK = jVLCkxLl;
        WzyfAdPkjDRH = tgzwcXnPKPIaZ;
    }

    for (int ZJZrMkCyIPBclPwI = 407888561; ZJZrMkCyIPBclPwI > 0; ZJZrMkCyIPBclPwI--) {
        WfBRWAh = ! WfBRWAh;
    }

    if (jVLCkxLl < string("xgZHnGsuJJKFGohzkqGaPvXSIJetZTTfiOZHlxsjFhAZWUtAyylGwfkpyTveJAXAJvzGosRvJCcmhebIAkaomoDQViXljYfLUhJmGILhDLkugFHBLRnHaulMlazjxzMfnCVENmgNneXO")) {
        for (int xiWiTJOlM = 741577723; xiWiTJOlM > 0; xiWiTJOlM--) {
            YhoCuOAzIiXGM = ESUMEMsJymmw;
        }
    }
}

bool FENEIhUOQbzyrY::SQlMfAibt(int XUwsJQP)
{
    double eWsPRG = 552946.0373752902;
    double UpDHXi = 142479.9406101339;
    bool dqUIsQzyoo = true;
    double vhuEmPQEXvVInS = -231903.12926004338;
    bool KvXQYBYiYMv = false;
    int xaXVGVkZSuGV = 1909480326;
    double XdUHrKBFvZx = -785914.6479806206;
    string gMSCbhwCUlKXKW = string("cbvGyMiDtdoQGpxjyZVoxgpgUVpSRfgmsPVxNJZgEgDeQCatExTxQhOGWCJwTjEZTlbhYkHFbRGoJoeuNZaclLVwwWLFPYXLsRBnxPwgswPxWMFBJSIFkdBHnsFzhFztGaLLWANzeSAnIFgRvVHkGHHFzRVvAjLYgiexSpetYZnkrCHcbYoDh");

    for (int depvD = 894302360; depvD > 0; depvD--) {
        XdUHrKBFvZx /= XdUHrKBFvZx;
        vhuEmPQEXvVInS /= XdUHrKBFvZx;
    }

    return KvXQYBYiYMv;
}

int FENEIhUOQbzyrY::IzEJPLRlR(double COcrZm)
{
    int xrQchdSxoQfy = -33164794;
    double OLfToqn = -799027.959957151;
    string sexGX = string("krNQKwXdwnapdiJBvsLfAypyIDFmWKtdDdFOTwAplueIgRCScjAAXIfVqWQaOZGJKMjsxsmCxzDLGaniEdHqIALhUpHhTHthmj");
    double MqvsAdYlwWvYNre = 365747.38397928816;
    int iKrYKwZGbYvxFo = 243143647;
    int JhaMFDbtDjK = 1077825848;
    int jrZvcvldAqkzGw = -1750704315;
    string sMqLSQ = string("NYHKFuSknMHmjtNElmLkWjavnQphGwmqvkgHLKZwJtuVltjhQGPKGNmtzJNhHdQYPMKINAAIONtAMlMWnWOfCHdZHOAEISGEAVZHwOQXNmCoRResyNjIjOzeWTUnSrmwoKrZXxRauBuWxIbVaOHDwcrSzKPJRtGuFRePZClrsXpzHQiNeyJxOCUzlpnWgsIKoJzVRFFhKyTJAFyOlFhqvQgICcXoIjydsdtlWPK");
    int jgvoc = 744028809;

    return jgvoc;
}

void FENEIhUOQbzyrY::AcSjjwtdEZIvbnxQ(double peRoEGXGjqvM, bool nVuFFTFxlT, int xiXQLw, string AEIBPQMdEdDV)
{
    string EBPRxyZ = string("VVDReFqztsSqiOrPAAkwgqcSAzayLGCaJAsvFzzUpSpEEkmDrtZnwoRRAqBNfRvJFDLnGRRvPdZUdyjJTqsUMWnsjLzDXZMinvlRBaNyBaIXHat");

    for (int ffFtnlNHdC = 1067713407; ffFtnlNHdC > 0; ffFtnlNHdC--) {
        nVuFFTFxlT = nVuFFTFxlT;
    }

    if (nVuFFTFxlT == false) {
        for (int qnStLJ = 640171834; qnStLJ > 0; qnStLJ--) {
            EBPRxyZ = EBPRxyZ;
            peRoEGXGjqvM = peRoEGXGjqvM;
            xiXQLw *= xiXQLw;
        }
    }

    for (int VxrpafWNDMQSNsp = 621180705; VxrpafWNDMQSNsp > 0; VxrpafWNDMQSNsp--) {
        EBPRxyZ += EBPRxyZ;
    }
}

void FENEIhUOQbzyrY::WDfJkaxIug(string UmkyU, int uLvFcShJ, string WRNAwPtMVagxQawp)
{
    bool XJWCxZpKEGYO = true;
    double sWzLjtBYDaSYlupB = -388001.6444855811;
    int gDtXiizivFkV = -1362842157;
    int bnBlyoxbGrPim = 372456067;

    for (int BbktHPNbBuB = 2129063979; BbktHPNbBuB > 0; BbktHPNbBuB--) {
        continue;
    }
}

void FENEIhUOQbzyrY::cHASFmGgMqgGuRvJ(string pccIIUhlbZdiy, double bEASefuR, string rwHnbuFj, double ZWEVWCai, string hZNIDgwzxDm)
{
    double iAcmUhyI = -577571.0364614837;
    string EGrSbqv = string("sDDJZDfGwMAyQmUdXbajvDBflJweHzjIeWlIKEamqDggQRDeILyNaVkpefctaLODvAfjJUsPjauEq");

    for (int UbHigYQ = 3298593; UbHigYQ > 0; UbHigYQ--) {
        pccIIUhlbZdiy = rwHnbuFj;
        iAcmUhyI *= iAcmUhyI;
        pccIIUhlbZdiy = pccIIUhlbZdiy;
        iAcmUhyI = bEASefuR;
    }
}

int FENEIhUOQbzyrY::YbFlqY(double lTnHxm, string QBoJCFENOHtcoKHf, double xRmAThoRe)
{
    int klBFFB = -663784270;
    bool UNoEGPrYY = false;
    bool HRNleqfeYY = false;
    int dHLSGmt = 1345826063;
    bool OMOzUTfXgkc = true;

    return dHLSGmt;
}

void FENEIhUOQbzyrY::IbMPqLUhbXE(int HdgpjYFSmen)
{
    int rIUArIfbouA = 1449012632;
    string AUxBBlH = string("RwtYEiqxctHNuWZVqObuJyaYOlOpZiBYwcFcRFDStfJJWDdXvGCsuvtKZuxczBDMYBVOqXpUocfZNWVUfHXFGVAWRVZaLuLegNfxqloyXbuDkrpthYZthixMRPLABladXvwEyRhuTwBwwqQXHhoysaVWlXWQGFcCNhIMOYvUdNUxHiKjAhhpKlXtAPzIUUurwqYzrsvlNsyoGNoAWgJKMqRUJItBqGWDQJOcEiRzGCGaQbUlvvYi");
    string hNvprewanYb = string("mEsDiyymEbyACeyEvdQlcrhXgicDNGAwenoyQIzLbiTLygmcdU");
    double KGIsm = 258876.08677276032;

    if (AUxBBlH < string("mEsDiyymEbyACeyEvdQlcrhXgicDNGAwenoyQIzLbiTLygmcdU")) {
        for (int EuTimbLwjWtloW = 1721511969; EuTimbLwjWtloW > 0; EuTimbLwjWtloW--) {
            rIUArIfbouA -= rIUArIfbouA;
        }
    }

    for (int cZvTpddCXwT = 594022420; cZvTpddCXwT > 0; cZvTpddCXwT--) {
        AUxBBlH = hNvprewanYb;
        hNvprewanYb += AUxBBlH;
    }
}

FENEIhUOQbzyrY::FENEIhUOQbzyrY()
{
    this->SpeTpwJU(false, -1008123.2385167108, -291178.5614718873);
    this->SQlMfAibt(-786097907);
    this->IzEJPLRlR(839105.2691816638);
    this->AcSjjwtdEZIvbnxQ(-175537.15849324258, false, -1019357345, string("uJudzzZOHOsBEpZYAGZpwshMOdaAlvDBwqnqBjotCfkHEdubFLUsRIONBQKCleDllonfoCroFKiBAKfhIThPsGPVztQbvlerqqRmwIcQQcmfElWGXipKzLdPjVWxbvQH"));
    this->WDfJkaxIug(string("apLwWzXMQfyXPzuo"), 1756812621, string("YAswNciDmqDZsDlMLPYSFzzTjvbbnsRmdABjRRCNBtkxTKqZnwqyZboPHBRYGVnamFsPkHKieBqkgoNrAQFJreklBBimDcFftdaGPLtgOjRCEdOjasIWyeZzuRWfSKpqnXkfaeUuXrYZadAUllBgJNFXaOOgQrFphgfnCxVeImqLXwMOaGKIDCycKkApceTrkjO"));
    this->cHASFmGgMqgGuRvJ(string("IwFuQSkPdFLsIvsUmdKTfujYBKcKqMVAhhtnAqoemDfVhwTlYQJLRBswjPzgTSpeRrLLYRRksIwimdfyPyTvkUKdSVCDnwOSXaSRdDDKdccxxaRJGmLiIKdRVbkHmYcOZPjiSaaDzMzgrraorCEOogRVpaVgBTCtSFuGRGOzjOacr"), 466385.9267145385, string("OwbyiYAVaKvKQwEmIJSKBoWYonRJoSqtOwJMRCyXuesdvjkhEsZHfCgyatURWWAcBwEAqKfZKamZxfremnovORZfoQYbmhtYRqyNAaUYjVuRyrVjAyYLqeXJuyfehTcEpnEIjSbBstKntqoeEPUnjwkBAaoN"), -172913.0388393547, string("jBJPyYJcDaqwJcmWYhdgvWvAdjryARAhiMItrBDHBpNzRaHLqayKxmCyaLBCtxpCEGQjgmlXWDvaQFXkDhLmndZdKKAHzLKsksfhChaPtAEZfwgdCbhWfWpExPsNTMngduIKlvMmdOQUmTVmtjdFRvfOBjCbwNxfOBwvfsOpNwFktcxuKHHzYfapp"));
    this->YbFlqY(-437224.30041395576, string("vDHTDPDEKlHaPYlDWJfdvWsJBLzxwwkfxlqjZmwKZruMGYtsfkiEtVtFkPkTFiwoICburkGOPOOyLNfIIVklwMaGvIzTkFpuKfKYOczVIuatRUySXiiRzNhYnQImrPdAeTwGDkfFGHGcnxSHHGAItZebiWVaVeqCUOEKfk"), 541008.4343246992);
    this->IbMPqLUhbXE(1866391624);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fKLpZKdOyMKOmggu
{
public:
    double nszhnJAeU;
    double OssazyQdzZdnGDpw;
    string VvvTVktHKBocXO;
    int SYNLmyyHTbX;
    double fClpt;
    int UwIsJEglr;

    fKLpZKdOyMKOmggu();
protected:
    double ueHahzSEuL;

    double mUBkHjGmjcJl(bool qczuHeVB);
    double ckMVQRVCDphj();
    int gvGNcY();
    int UJDgZU(int VjPWiKemfNVkhon, double tnXVJtJ);
private:
    double HuiVYbwM;
    string NnpEVVLzg;
    double EPEhNkpNvEpk;
    double OpPyfJsjNDRqB;
    bool NRqnBvisCIUWpUu;
    string HShkIjrgvHcK;

    void SxKkTDGv(double JgeZmOdsoiqHK);
    int DWDzAW(string lmfvzPczgRcRU, int TSjwRjk, int RiZbwvFcM, bool GTluzGANBPhhos, bool lRtuxVLgAAe);
    string WCTpA(bool tpCRkQxghQSK, int DupaFTFAqUXAwlL, double vwsJKUDI);
};

double fKLpZKdOyMKOmggu::mUBkHjGmjcJl(bool qczuHeVB)
{
    double oCWiykXBpOgylv = 893161.782836603;
    int gAdckdRpxHkVYO = 392302677;
    bool xBAEjxqY = false;
    bool QVORTLe = true;
    string xQajthOzSuI = string("MtCFLTJQyPQcFPUznVIgZpsrJBjcVAcqdKCrETcfokwPnpmwgNUVxGIMRFPBluiZdxIXBOBeeAgjpmkeNzyNfaZmrNeqAFRLGLRETSalcRcJricMxIVEzbmzaZBRQYEyermcxlCPLvTxbgwzBwGtQzKLNebZdsttgoFxSFAaBIPpkNoOOoYCuKrYgyiHvJDEjWRBBTQCyfWmmGfCUptbQKMfeCHhOynbDsdmhcjQjbtppQtonVbGVOogIcV");

    if (oCWiykXBpOgylv <= 893161.782836603) {
        for (int VjMbzAmLifxLmKRE = 725160859; VjMbzAmLifxLmKRE > 0; VjMbzAmLifxLmKRE--) {
            xBAEjxqY = xBAEjxqY;
            xQajthOzSuI = xQajthOzSuI;
        }
    }

    for (int zqDnGs = 937962660; zqDnGs > 0; zqDnGs--) {
        QVORTLe = ! QVORTLe;
        xQajthOzSuI += xQajthOzSuI;
    }

    if (qczuHeVB != false) {
        for (int xOkHysDHMDsNIrp = 342403050; xOkHysDHMDsNIrp > 0; xOkHysDHMDsNIrp--) {
            xBAEjxqY = ! xBAEjxqY;
            xQajthOzSuI += xQajthOzSuI;
            xQajthOzSuI = xQajthOzSuI;
            qczuHeVB = ! xBAEjxqY;
        }
    }

    for (int BHxIvqBfDeKNV = 978370142; BHxIvqBfDeKNV > 0; BHxIvqBfDeKNV--) {
        qczuHeVB = ! xBAEjxqY;
        QVORTLe = QVORTLe;
        qczuHeVB = ! QVORTLe;
    }

    return oCWiykXBpOgylv;
}

double fKLpZKdOyMKOmggu::ckMVQRVCDphj()
{
    bool foleJr = true;
    bool lyLoPtmFyp = false;
    string bnJxzkTdVvitX = string("qQFftckFoBQRjdqajYnLjuPCLwmlLpeozjSufjBcuXfKQcTpJtYnbwFaixMcUWmmzwMuQjbcTJHOdBGSQimIAUzWZMsuQMYuogCbErByBGtTkjXPsqXWvmNgIocVedPAWODvouJCDrvXGrrrZWXhPnkIcmsiLOCUyN");
    string beAzpA = string("qDdAVPlYeiqrpKHdxJKaTBydrkLiCRpdZZFIDApwGZwkwcURTXVWpNiZDhCEsgotfEUifmKHlRgnZwpbScICMCRgLdlcklnxoolITefnNIijsxVyCRNewInCClABKPEQsHcTEjjthWyuAsIGTaEqeqowwjYcqHEcGqvreFIWasWdWrIQKnLVEtkpeoEYKghywOwzHsANOzflbUEJcEWX");
    double PcMYoYrk = 49170.83850660582;

    if (foleJr != false) {
        for (int WxcYRHsn = 1328108205; WxcYRHsn > 0; WxcYRHsn--) {
            foleJr = ! foleJr;
            foleJr = foleJr;
            PcMYoYrk += PcMYoYrk;
        }
    }

    return PcMYoYrk;
}

int fKLpZKdOyMKOmggu::gvGNcY()
{
    int AdgBeTmqhC = -62878518;
    int NNKEdTwY = 2060779498;
    string TMfmZzOsUTqdf = string("tytrwcezFsRpAHRRfJjsOiwerzgoVYg");
    bool LruVZIcqKSNppMYT = true;
    bool sCMPbdzPbH = true;
    bool aZwNvsOVApp = false;
    double xYUpXFYWSSKVFgq = -427295.90149898594;
    string CGBRCmFBiZhoK = string("lSQgaskThhTwcLxbbrVzWNjek");

    for (int qxtoRMAAaAD = 173639320; qxtoRMAAaAD > 0; qxtoRMAAaAD--) {
        sCMPbdzPbH = sCMPbdzPbH;
        LruVZIcqKSNppMYT = LruVZIcqKSNppMYT;
        sCMPbdzPbH = ! aZwNvsOVApp;
    }

    for (int gvlJeqHbZA = 554512024; gvlJeqHbZA > 0; gvlJeqHbZA--) {
        continue;
    }

    for (int MJjBSkkQo = 158517990; MJjBSkkQo > 0; MJjBSkkQo--) {
        NNKEdTwY /= AdgBeTmqhC;
    }

    for (int mzGbmIjvSNlOXZu = 1122871282; mzGbmIjvSNlOXZu > 0; mzGbmIjvSNlOXZu--) {
        sCMPbdzPbH = aZwNvsOVApp;
    }

    if (NNKEdTwY != -62878518) {
        for (int NdjrwQSzGvZwL = 1998882054; NdjrwQSzGvZwL > 0; NdjrwQSzGvZwL--) {
            TMfmZzOsUTqdf = CGBRCmFBiZhoK;
            TMfmZzOsUTqdf = TMfmZzOsUTqdf;
            AdgBeTmqhC /= AdgBeTmqhC;
        }
    }

    for (int WxMFU = 1309787379; WxMFU > 0; WxMFU--) {
        LruVZIcqKSNppMYT = sCMPbdzPbH;
        aZwNvsOVApp = ! aZwNvsOVApp;
    }

    return NNKEdTwY;
}

int fKLpZKdOyMKOmggu::UJDgZU(int VjPWiKemfNVkhon, double tnXVJtJ)
{
    bool NTZKtBg = true;

    for (int MdyFPB = 798638437; MdyFPB > 0; MdyFPB--) {
        continue;
    }

    return VjPWiKemfNVkhon;
}

void fKLpZKdOyMKOmggu::SxKkTDGv(double JgeZmOdsoiqHK)
{
    int wZcFFR = -1070176859;
    double JsLRUEd = 447948.1039804107;

    for (int PutyxrlpO = 1123383060; PutyxrlpO > 0; PutyxrlpO--) {
        JsLRUEd = JsLRUEd;
    }
}

int fKLpZKdOyMKOmggu::DWDzAW(string lmfvzPczgRcRU, int TSjwRjk, int RiZbwvFcM, bool GTluzGANBPhhos, bool lRtuxVLgAAe)
{
    bool UBeGwlThIqfoKO = true;
    string nnvRdiDXizgqd = string("hTESwnCJsdbyfjAGsxlymLFJaMFBUaTybXAvAmrKbzPbkBdREbMJqjqYiCYigqvMgkoNWXNdweIJyflwnaiqaNKUT");
    bool ycRxg = false;
    string pOsLCOI = string("kVCWCraHHZthuySgLQfqjFERDWyKXVxXXYwbqwYAaWAMTBEvMQuLnJCikoeviPKDcYAcmWyvjUrXyJrVPPlMctwlHYVblxltUvAAPfFQQsrGEZWPHNuRBVQyBYfhueQfKDUjhpBBzISSNrFGLToHUOKIuhFKEnkTuJLKlUz");
    string dPMbVbaMTis = string("FkhNTnOXLXNyCneqSZvXhMDoyXnW");
    string olfsdpOCSPoR = string("hdYlcHgxWGHuuHuGAAOJQDrhTRAlvuQjAKxR");
    bool dVIFaLWqQBoGwSKp = true;

    for (int RHfQSUYLhPblhna = 1965663077; RHfQSUYLhPblhna > 0; RHfQSUYLhPblhna--) {
        dVIFaLWqQBoGwSKp = ! lRtuxVLgAAe;
    }

    return RiZbwvFcM;
}

string fKLpZKdOyMKOmggu::WCTpA(bool tpCRkQxghQSK, int DupaFTFAqUXAwlL, double vwsJKUDI)
{
    double eVgptk = 110647.15756094578;
    string jjmJD = string("RZjDtQoZYXbtOUvAaNhkTdeBmYodudKQIbGTzHcdWSGDJBctCLxXJpGVlCqzvevVGRGOGEfkjXsgIisOvjLyOECtFJOJwoMLTFoYUsCkIcWKRVuZNeSTmKQceHXyjblrbzzaXtwEaeftkOf");
    double wksjibQmYwIr = -69067.31913275973;
    double NHympjXCFeyFJsA = 66248.41914679216;
    string gNrkEOqLh = string("vkLarBxndsbrvUgPXVpJAmEzKpmdSOQVyXQiUccpsfmsRSFoALbTZwzwnyHmTULwlcSmemRdrDseDuylLsItAuvIVDwlNeTrmnVeGsRDLEjmdLwzNUKBvizZZfeaqsBgLQWShNrCKTJvtpGLnPEyKmDgRalfxTAxBlRGHbeCkMDJXSxEVafiEdbrOuIWgJDwtldYpjztZYqWIENgTmeljrQeiZnMmblJWurIr");
    string wmaPNh = string("WmfYdNPUGxdzaxifRSevWaZfZrXntFxEJYqmPBsdDmBcfOrOhItDebQlIkOqAinOjdAkImicxyiDKuqPWRftJRSnuJVtoecbVPOMdBkmkcLvwDVhnVXxsjUWxOBuLSHRxwnRqZMscipVOOXsFL");

    for (int NyiOzXMdWu = 2130796833; NyiOzXMdWu > 0; NyiOzXMdWu--) {
        gNrkEOqLh = wmaPNh;
        wksjibQmYwIr -= wksjibQmYwIr;
    }

    if (gNrkEOqLh <= string("WmfYdNPUGxdzaxifRSevWaZfZrXntFxEJYqmPBsdDmBcfOrOhItDebQlIkOqAinOjdAkImicxyiDKuqPWRftJRSnuJVtoecbVPOMdBkmkcLvwDVhnVXxsjUWxOBuLSHRxwnRqZMscipVOOXsFL")) {
        for (int CxvfHji = 892284656; CxvfHji > 0; CxvfHji--) {
            eVgptk -= vwsJKUDI;
            wksjibQmYwIr /= eVgptk;
            wmaPNh = gNrkEOqLh;
        }
    }

    return wmaPNh;
}

fKLpZKdOyMKOmggu::fKLpZKdOyMKOmggu()
{
    this->mUBkHjGmjcJl(true);
    this->ckMVQRVCDphj();
    this->gvGNcY();
    this->UJDgZU(79987674, 149784.11560630042);
    this->SxKkTDGv(320413.49299880624);
    this->DWDzAW(string("SqdRGyfih"), 1371051224, -2020191192, true, false);
    this->WCTpA(false, -1488846706, 985382.3213036502);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nqCVyrAqhpLK
{
public:
    string WBMTtb;
    string AshCdwmojHXbZX;

    nqCVyrAqhpLK();
    string vSOcFFxybGzHnv(bool GDeta, bool KBbMrMAoGEkh, bool ORTvRbfVFX);
    string TtkRr(string YNylAFUrXS, int UdmYvqkD, string HdLSURDOaHX);
    bool TTnEnIIUdw(double SUUCtALGA, string MYpBzKReXM, bool LnAAxXtChnW);
    string YJKXPh(double eKdmqNSmXwUZg, string kSGnQhLAu, double XEBEJjnJXW, double uOEJokTXeladtm, int CjfRETgnNFMdEx);
protected:
    double ChILWq;
    double QVEHFCkRMHJIQ;
    int wuPnLksllQmIr;

    void DdrhuYKgxJimDAF(bool GlrfALcPMZ, double OIibkEGZHy, int MnwZdQdt);
    bool eLynXC(double YZVwlbmYdIDlIsh, double EdijcWaaUq, string ohuGuLkDHe, int tjqadkVna, int FIEKLo);
    bool AGTXVQrrNFweV(int zLIYvrXj, double NaTfjde);
    string uOHGVZksOZOW();
private:
    string yYpcuAn;
    string zytsObrkbwJSPb;

    string yaBahwsKKUosMc();
    string DxgPkcJr(double LDdvSIUCohDTzBiH);
    void VOYln();
    string lNUZFcUjLMnsTWw(double DtOVmPpAtulSLKy, int eLIjJIisDTFBTNU, double UTluptYzgIwFS);
    bool EBKVbltbtpUmtN(string onFVFFOBqCHh);
};

string nqCVyrAqhpLK::vSOcFFxybGzHnv(bool GDeta, bool KBbMrMAoGEkh, bool ORTvRbfVFX)
{
    string kpuvIjksJ = string("wGLpUaenrfYXdfCRmIzamzHtfrLfpCDJdPXihpzqHJUkrOWUSJGTPiocvylZRKxUZhNsoOjDFYaiZArRzXmHXYGuTNSeUXCesEAwSJOhgTjTPvjqwoDzSfTKraTFzBgJeTawEOVWTviIqdtpWHILMawKB");
    string WhwoTa = string("mJqJjrYpsFBdXibUkHJ");
    int qbvZIPQONfdTyIM = 1752489043;
    string HNBOJCQ = string("mfoedYXluXpxKowSadjOdftuKDkudMqrMNCWVkeSdAdVcFCCJhWAWxyuOLlUzhhQKWnODNOkryjLqIRfDvDgifOwciDikCvaSmnrKJUektMHFHwdkmjePdLzPUllmKTVgLZOhiQuqeTjFSLOHiqoHaELuagjzTYqtMNXnnRWbJRvsQ");
    bool AKkMquOU = false;
    double IqAsHgztUBQb = 33204.26528914631;

    if (AKkMquOU == false) {
        for (int mFGnuLZ = 559587647; mFGnuLZ > 0; mFGnuLZ--) {
            KBbMrMAoGEkh = KBbMrMAoGEkh;
            AKkMquOU = ORTvRbfVFX;
            HNBOJCQ = WhwoTa;
        }
    }

    for (int PpoNaUdyEvjCT = 101786402; PpoNaUdyEvjCT > 0; PpoNaUdyEvjCT--) {
        WhwoTa = kpuvIjksJ;
        kpuvIjksJ = WhwoTa;
    }

    for (int YjkuNwuhcd = 1845327312; YjkuNwuhcd > 0; YjkuNwuhcd--) {
        KBbMrMAoGEkh = ! AKkMquOU;
        AKkMquOU = AKkMquOU;
        AKkMquOU = AKkMquOU;
    }

    for (int fhrlUeBQHYyXi = 335888030; fhrlUeBQHYyXi > 0; fhrlUeBQHYyXi--) {
        GDeta = ORTvRbfVFX;
    }

    for (int dQtkjFxtZfCZw = 392230045; dQtkjFxtZfCZw > 0; dQtkjFxtZfCZw--) {
        AKkMquOU = KBbMrMAoGEkh;
        WhwoTa += HNBOJCQ;
        AKkMquOU = KBbMrMAoGEkh;
    }

    for (int mZQVPVXf = 275149463; mZQVPVXf > 0; mZQVPVXf--) {
        continue;
    }

    return HNBOJCQ;
}

string nqCVyrAqhpLK::TtkRr(string YNylAFUrXS, int UdmYvqkD, string HdLSURDOaHX)
{
    int XEcFEsxD = -919768177;
    double fkieiqstoYy = 985211.5531054812;
    bool lyGZwIZHtcPu = false;
    int gAlMvT = 415399076;
    bool rkzEzBFmYEjMalyg = false;
    int amBzXjk = 1596873077;
    double vPzrSP = 865577.1449246648;
    double HKLqVa = -226550.182086186;
    double TvKZVvrfvO = -559399.6906792863;
    string NIprIhCNWEg = string("rrFiaWlnOPtehcfDqokLxEyRepKSoBdEOlUBvpLFVlinpVSfDPOLGGpxxZzKbCnoFqObjtKxfPIjIYnsZj");

    return NIprIhCNWEg;
}

bool nqCVyrAqhpLK::TTnEnIIUdw(double SUUCtALGA, string MYpBzKReXM, bool LnAAxXtChnW)
{
    string gqZuX = string("TBZPGycBSxSDtsXZDAugxcpefIcBvBvUsGjUXP");

    if (MYpBzKReXM != string("TBZPGycBSxSDtsXZDAugxcpefIcBvBvUsGjUXP")) {
        for (int biJTNjNS = 1124466027; biJTNjNS > 0; biJTNjNS--) {
            LnAAxXtChnW = ! LnAAxXtChnW;
        }
    }

    return LnAAxXtChnW;
}

string nqCVyrAqhpLK::YJKXPh(double eKdmqNSmXwUZg, string kSGnQhLAu, double XEBEJjnJXW, double uOEJokTXeladtm, int CjfRETgnNFMdEx)
{
    string QFeNEkVr = string("yayEFoaWUrsayemlQfxmfxnfVftBOMVSkaDVqHeBQlSmceKEwc");
    int RIGPtQ = -109241268;
    double JIYPT = 986142.8022115342;

    for (int chEcihCwFe = 1088898321; chEcihCwFe > 0; chEcihCwFe--) {
        uOEJokTXeladtm = JIYPT;
        RIGPtQ /= CjfRETgnNFMdEx;
    }

    return QFeNEkVr;
}

void nqCVyrAqhpLK::DdrhuYKgxJimDAF(bool GlrfALcPMZ, double OIibkEGZHy, int MnwZdQdt)
{
    double GJpBK = -612645.020175388;
    bool pNLsVhqeu = false;
    bool IwmtUVqkUHXoGD = true;
    bool fVEpQPQdgUk = true;

    for (int XSEqtbbNpgWmyyp = 171717100; XSEqtbbNpgWmyyp > 0; XSEqtbbNpgWmyyp--) {
        IwmtUVqkUHXoGD = IwmtUVqkUHXoGD;
    }

    for (int ZElLuwbrHb = 1855668762; ZElLuwbrHb > 0; ZElLuwbrHb--) {
        continue;
    }

    for (int qCUoqO = 1328540273; qCUoqO > 0; qCUoqO--) {
        MnwZdQdt -= MnwZdQdt;
        IwmtUVqkUHXoGD = pNLsVhqeu;
        OIibkEGZHy *= OIibkEGZHy;
    }
}

bool nqCVyrAqhpLK::eLynXC(double YZVwlbmYdIDlIsh, double EdijcWaaUq, string ohuGuLkDHe, int tjqadkVna, int FIEKLo)
{
    string qdEJJYCRzdcE = string("ghcMWvnkTDTZJLLXDOTPMrTjAmNLNpLJtMUMYOQGwdRKXyZTpVxLokrA");
    bool KvFpZcXUHkOLdwKh = true;
    int urimQLJHRaIR = -837324693;
    double VFqgrAZVO = -443358.99187780137;
    bool VkkVXdCB = true;
    bool kYmCU = true;
    int RkWrRhGFGWHXlrFy = -802958364;
    double yAtnvldnfHiUciWh = 801969.4182047143;
    string BZnwKrwHHtKf = string("rtBUqirAJQamsfuakCLrRjVgNGRwLeOVglQaXxLrzAEREBkZosDJyniaCRwMyNrUrRBcBDGLdroktPPCOHkWlkRtHAqqfazaXuvnvoATAEEgSTZBGGJmjZmwLWaBfkxFNGAKdpDLhsZCLhvkQuJejzoHIXrMEVlkgIzGZQjvwWSFXBwdhRcJaUKvmXovGBuhgvtlvqSKxstvtMjdYTRAMUaTmIFhYYnzfFjOpWDWBdjNxfiYyVMvjjEhvTbMoTb");

    if (RkWrRhGFGWHXlrFy >= -915188078) {
        for (int ddUhMLllsLgcY = 1447599437; ddUhMLllsLgcY > 0; ddUhMLllsLgcY--) {
            RkWrRhGFGWHXlrFy += RkWrRhGFGWHXlrFy;
            RkWrRhGFGWHXlrFy /= tjqadkVna;
        }
    }

    return kYmCU;
}

bool nqCVyrAqhpLK::AGTXVQrrNFweV(int zLIYvrXj, double NaTfjde)
{
    int XlWvqltQJGw = 1146429852;
    double UKBJkg = 192034.73355745059;
    string iOMOlUkBGxlSN = string("RtCOpRkvhfPWskJkNVxqGMmWqZlKNMKtnyzLSXBVJzDdzlPRPAoEQiqAWccpYoCGIrPsBbFrQdhXEMuKM");
    double MohTo = -721039.3344288327;
    double zBQqdEOV = 436543.335097392;
    string Btbwc = string("nDigRMOwMcRDkrSAyTodJLjvEorlabZzwSM");
    int SUjxTiJKy = -181775583;
    string NPJKmWrm = string("sJlstInLXKoOVRKhUkYEwfyaxuasQdZpqslPSxBxbTOjLCAsCtIztOWadVpiaDUYAfPZHDthGJUuioeanHjBuFWNuZrfkSiDzhLmnrQksFxIEg");
    double nejSQeUjAK = -52124.209403716435;
    string ywDfTgWuErMppny = string("RFGRnxCaIbPhtybQqFiNXUcdZvOchOqXyBjSSDcTfjKZbpRTGjEQBykpBuykUGKDNtggaBDFgYxrGsnbyaWKtnUBThFqWHgJmZFzBWfPRxHoZJXUrytaQQpSJdSFfQIaxxiJIgZvlqdHNQDLBgfCNCVLYRCksUwFvkyaTztuOxlYqELeJfUCrPMSykrowhdoQSWzdoakdnZLwhWEYKXGsmMWkTGaRrFrCXRsee");

    for (int tOfsJ = 1316345964; tOfsJ > 0; tOfsJ--) {
        SUjxTiJKy *= SUjxTiJKy;
        Btbwc += NPJKmWrm;
        zLIYvrXj /= XlWvqltQJGw;
    }

    for (int WKxWfhtxaszFFx = 152338779; WKxWfhtxaszFFx > 0; WKxWfhtxaszFFx--) {
        SUjxTiJKy = SUjxTiJKy;
        MohTo = zBQqdEOV;
    }

    return false;
}

string nqCVyrAqhpLK::uOHGVZksOZOW()
{
    double DhybLovGevx = -95396.22573096881;
    double LWOwS = -748643.7273497097;
    double mMzvwWp = 45760.056071273066;
    bool FzJjCsIqbP = true;
    string GZwGNDVd = string("hjscIrnjvQsTVLjWZypNcGXDaRrQuhrklqZKStFJUyDTkcnGDxGVKAlbjjtRKQASGCBVRUqkpbNPZfHgaplyHXXjZcDonPpBjnYzIutbdLwXmSSlHFRGaoPNWyPTlvrUUOYNrgAWeRvNHkntRBcBnbPfmTotoPcXBgXcTqPYibXpBOiIYAfNxVuzAXDTTPaJyyaftigtUSIKmQZCYjpNlnCwsuXKcGEMOKNkFNprnhwSQxTnzIEPvUnSym");
    double kjpfYKaGzXSJf = -282935.7257298221;
    string MREQieoKgild = string("jezCfeVupiKGPvNKJUTqeVqHbCIKofVoYAlpGZPsekKxRJSmYwcLPuOjCTYGczFthVABmhEkxIcCAdcRaAJOnLwEuJgKquSaQJGRSQudRujGgVBkzDD");
    bool jfhFULnLMAX = false;

    for (int DxWrGyNzMZzSkRw = 1025855581; DxWrGyNzMZzSkRw > 0; DxWrGyNzMZzSkRw--) {
        continue;
    }

    if (LWOwS < 45760.056071273066) {
        for (int hOXBGTQB = 452369447; hOXBGTQB > 0; hOXBGTQB--) {
            mMzvwWp *= LWOwS;
            LWOwS *= DhybLovGevx;
        }
    }

    return MREQieoKgild;
}

string nqCVyrAqhpLK::yaBahwsKKUosMc()
{
    double CKUjWTMkEvXr = -405739.22706392827;
    double dvkCqzOSMIyO = 24943.961981815348;
    int uXCOIjQzK = -844827965;
    string fqZVZktxwZMFakGx = string("BkoeVjRSELWYgoejkUcpdBjBMNchlVJGNzJrNeTJsYPDFwfvJqSdMDaypfeCOrCOWFgVntNsvthyFXLfEWFpyeLyVGIaixQKkcfGEBqpNGBmOlibToISmKSNWlfCKpKowioCstGSeiwWPvJWyyZIJPXqqbZPWdAoiopTHHxbdrEFvEGooXAAEnCygwhCtqbmVHEXFMKAZgnhmuyVofaEIMWKxGqmYpDcbnCfhfTmQDrigLVFGmpXhU");
    int JilZCnjwmKv = -924464615;
    bool bbeIzRVBD = false;
    double agoeYNOATYEWIw = -131531.21950211783;
    bool XUkUxehspwFJfUvS = false;
    bool BcZSBwJVbm = false;

    if (uXCOIjQzK <= -924464615) {
        for (int gnivLlHtd = 1931108004; gnivLlHtd > 0; gnivLlHtd--) {
            dvkCqzOSMIyO = agoeYNOATYEWIw;
            BcZSBwJVbm = ! XUkUxehspwFJfUvS;
        }
    }

    return fqZVZktxwZMFakGx;
}

string nqCVyrAqhpLK::DxgPkcJr(double LDdvSIUCohDTzBiH)
{
    double LbhfIIz = -99883.30592933681;
    string ZWPTPODnGCe = string("LdWGVjGnzikrjFSkfPEuu");

    if (LbhfIIz <= 137242.995252079) {
        for (int BWIQJixnrAdefX = 1948027669; BWIQJixnrAdefX > 0; BWIQJixnrAdefX--) {
            LDdvSIUCohDTzBiH += LDdvSIUCohDTzBiH;
            LbhfIIz += LDdvSIUCohDTzBiH;
        }
    }

    if (ZWPTPODnGCe >= string("LdWGVjGnzikrjFSkfPEuu")) {
        for (int gBZPmi = 1670377369; gBZPmi > 0; gBZPmi--) {
            ZWPTPODnGCe += ZWPTPODnGCe;
            LDdvSIUCohDTzBiH /= LbhfIIz;
            LbhfIIz *= LbhfIIz;
            LDdvSIUCohDTzBiH += LDdvSIUCohDTzBiH;
        }
    }

    if (ZWPTPODnGCe > string("LdWGVjGnzikrjFSkfPEuu")) {
        for (int JNFQkpx = 1538736971; JNFQkpx > 0; JNFQkpx--) {
            LbhfIIz /= LDdvSIUCohDTzBiH;
            LbhfIIz /= LDdvSIUCohDTzBiH;
            LDdvSIUCohDTzBiH -= LDdvSIUCohDTzBiH;
            LbhfIIz *= LDdvSIUCohDTzBiH;
        }
    }

    if (LbhfIIz >= -99883.30592933681) {
        for (int XAfmgVzymLkai = 255944133; XAfmgVzymLkai > 0; XAfmgVzymLkai--) {
            LbhfIIz /= LDdvSIUCohDTzBiH;
            LbhfIIz = LDdvSIUCohDTzBiH;
            LDdvSIUCohDTzBiH += LDdvSIUCohDTzBiH;
            LDdvSIUCohDTzBiH -= LDdvSIUCohDTzBiH;
            ZWPTPODnGCe = ZWPTPODnGCe;
            LbhfIIz /= LbhfIIz;
            LbhfIIz -= LDdvSIUCohDTzBiH;
        }
    }

    for (int WHSKTAmVmRku = 158424198; WHSKTAmVmRku > 0; WHSKTAmVmRku--) {
        LDdvSIUCohDTzBiH -= LbhfIIz;
        LbhfIIz *= LbhfIIz;
        LDdvSIUCohDTzBiH /= LDdvSIUCohDTzBiH;
    }

    if (LbhfIIz == 137242.995252079) {
        for (int aoIdJYyxgRszf = 532456526; aoIdJYyxgRszf > 0; aoIdJYyxgRszf--) {
            LDdvSIUCohDTzBiH = LbhfIIz;
            LbhfIIz /= LDdvSIUCohDTzBiH;
        }
    }

    if (LDdvSIUCohDTzBiH > -99883.30592933681) {
        for (int SiKYUhBPdrocDJg = 745225930; SiKYUhBPdrocDJg > 0; SiKYUhBPdrocDJg--) {
            ZWPTPODnGCe = ZWPTPODnGCe;
            ZWPTPODnGCe += ZWPTPODnGCe;
            LbhfIIz = LbhfIIz;
        }
    }

    return ZWPTPODnGCe;
}

void nqCVyrAqhpLK::VOYln()
{
    bool vZSMc = false;
    double kshjSKLqr = 790901.1347044497;
    string YRkDOLWAt = string("sPeRoxOIXlWVVDOpQhHnjZefyQbqqyHrrfOylJsKrBzhHGMoqTikXK");
    bool jMkwLWCUU = false;
}

string nqCVyrAqhpLK::lNUZFcUjLMnsTWw(double DtOVmPpAtulSLKy, int eLIjJIisDTFBTNU, double UTluptYzgIwFS)
{
    string SozNLskMUQe = string("GVhLecuqnNxfqiVeqUZUYNFMXwitRWNmFCkajNqGnyjvnRcwefTmwAQaqWLKqSplzXrRDsUhNfXcBFzputlcBqhrVkVkDvKePNwejYMOYpZsTiUhERzlDKcPoewqqJRoolprjYZmQehACAWwhMLntffEjyb");
    double LetZOEzyACPeP = 177048.19135434966;
    double jhibNXSTfw = 940956.6193492085;
    int HMHRNhesKGRzHSx = 1902839719;
    bool QKkEiRRDWSZq = false;
    double jYhmRQPDzj = 812009.1053428282;
    string VdTORgoocgXiZPD = string("dZTyBLGpclDAqskNRYoFQtgdnMJArfAvMFDiOyJGBdiRzcnZmlcOJPPLpNwpLouGatBUzRFItWNMJyjzrMmxpOUVULxpLTXwTHKattxWzskuIkPEKSECXcsDrRACdMzKcfxKmRmbWKTUAQgbwZsrsxsJSJYspiGcOjmRnrwAIGkUtunpGnzwzgruNMrVUiUAHJmVuIWCvfOAXyeJthU");

    for (int JXApqpWA = 1854979879; JXApqpWA > 0; JXApqpWA--) {
        continue;
    }

    for (int RyrcvCWmNdLzsdmy = 577775271; RyrcvCWmNdLzsdmy > 0; RyrcvCWmNdLzsdmy--) {
        UTluptYzgIwFS *= DtOVmPpAtulSLKy;
        LetZOEzyACPeP = jhibNXSTfw;
        LetZOEzyACPeP /= LetZOEzyACPeP;
    }

    for (int WzBulpXNEwEbwj = 772963266; WzBulpXNEwEbwj > 0; WzBulpXNEwEbwj--) {
        SozNLskMUQe += VdTORgoocgXiZPD;
        jYhmRQPDzj += DtOVmPpAtulSLKy;
    }

    return VdTORgoocgXiZPD;
}

bool nqCVyrAqhpLK::EBKVbltbtpUmtN(string onFVFFOBqCHh)
{
    bool rEvgcwXiXcH = true;
    int UxLcCdHRHx = -1750541980;
    bool JypKR = true;
    string cFBKv = string("PIDbroyQDSBuAzrZAnRIKwmQJRfpVkNgarPElzlfcmFTESbbzhjVsAzqmsSpmMlkymLwVWNldAGlmiSMFQnefHiXLFzGgUzGkGwNVXDMftVrROIuEOdUMSdEdziPdgRuagIadOsfFUodyNFALFpROrbZNbJfLKRYwuvZDbkBIoSDxLkdQnpwrItkSPsJpqEeHDsBZsNcDJrHPzgkgnygnWBKPBFOsoTGnkuwifqJiteBqtsBNQUuqGx");
    string vZmYzwAIeVUe = string("EwkKqJjcYvYWAyInVnSHciwuzYOErSPEBqhpRAbadPUnysLVubUZyuHHfxFBpKxfZeZCvKlyPcogJQjWEJaLNpoWxatPmzBXOwezhRFrpDXvoyqLLXwPqXFyyLBDDgDQbhiIjKeImfWlvyNWIkVRpnhrWJoqaPFotPxTXJHEAefZVOhYYjCCmmIBVxSIbrlJaERtEoDKbODspXqrfRPkxkFwIBFzCLQemVdOezxbnNgeYswaBTnqGe");
    bool tJgVRc = false;
    bool JebFNLItM = false;
    bool SDDbxzbMmQvTy = true;

    for (int cCvNdtHsKFg = 35179062; cCvNdtHsKFg > 0; cCvNdtHsKFg--) {
        tJgVRc = ! SDDbxzbMmQvTy;
        tJgVRc = ! rEvgcwXiXcH;
        vZmYzwAIeVUe += cFBKv;
        SDDbxzbMmQvTy = SDDbxzbMmQvTy;
    }

    return SDDbxzbMmQvTy;
}

nqCVyrAqhpLK::nqCVyrAqhpLK()
{
    this->vSOcFFxybGzHnv(false, false, false);
    this->TtkRr(string("mefvuYhzCjoBLHVgzTkvGlEDsaBogTMqDlxXRDstuPnTmFFpbFDypfRPFjemdIovCNPoFohlSyaxkIVfFAgwXqUuXNLIJAiZOCDjQBrcbMsgecgXyFEfhbSffXZEeteYGYCANGVKddcBUwbbcIoekuSNXnkNnWhqWhUWjavJalndYLBoekPgQkzyKnuQFkYAt"), 410582300, string("pGFVNFY"));
    this->TTnEnIIUdw(258571.53420474866, string("NWZjBgQdjBIWvUCBomeoSPcRVGsQxIOYjAgIICiAlTxFhlATquDJzqdDTHskcwIELgvrW"), true);
    this->YJKXPh(182026.25832500204, string("pNgLEqNlpUOSZhkAwqvEilbSUuvFgyONNUroWtbSZchgCWWHrxWIVhwhmopiKOwxcQWgRTNgkIgjwdVoRoEsnzycARNHAIeYxMOqTUEePFPLdCwyjnwkBiElOanxgqLIqAKwKuTtBqJeJApMsphQHfyvnzuqrdeiaVtGzxfDVebxP"), -323030.88822050305, 283551.123546929, 801899332);
    this->DdrhuYKgxJimDAF(true, -483499.14838068705, -237417137);
    this->eLynXC(-985879.8268019956, 588973.2573289729, string("uXejstVYJqDvgIgaxvFbvJlVezosfmIzHFQKnbBiGQlpGGxpoScOHJcbYVzDvFSzHKuJEPQqvOpHoWqgDOgIeJDRWIHPXjqUljbZymlWazRjubraxWCQRtEDpcmhsQWTnnBfsbRjOfnjmULPeczEaiKnXrUfMntuhKLvlFtAxhWpzJCMXcEWrrCOByYLh"), -915188078, 1094940572);
    this->AGTXVQrrNFweV(-1214061797, 303665.63732614304);
    this->uOHGVZksOZOW();
    this->yaBahwsKKUosMc();
    this->DxgPkcJr(137242.995252079);
    this->VOYln();
    this->lNUZFcUjLMnsTWw(-312326.8821558073, 1746720628, 764268.0534935403);
    this->EBKVbltbtpUmtN(string("QKQzPqsjZwHCQwphSZlkRUFjqzHiFPQArnERbFUmkPZudITPwASkGDIZgDtDVfeSYaTzJAHtumtGVwGIIjbqGVJcjqDXJnpNxwDltnSpezNRiimJzgrVPPcsoOlpZTJoTUzjimOLgDwzhweDQnNoHKXRkOvsWKHaHDzJwPLzRWdMCWMyNDRNtvAkGebhoyMiQFhDXsKsbdlmfSCdmKOjrjntRiJsesrtu"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eMgUvAYG
{
public:
    int bfrdJpilsQN;
    int FYlHVXDDCDIBUsoZ;
    string txLoh;
    int lYYpedQUG;

    eMgUvAYG();
    int OOgiSnoMsfJmnNnD(bool LEndXGPnzft, bool MNkmyhOyDoSadEpf, string hbvoWAWj);
    bool KkpbDRvuJUezCT(double zNfUUA, string TJGFMlzQSot, int nzLyDYGKtHoiBK, int OccoZuIdt);
    void ajGfRRxOqFGIVqt(bool iwZJFdFNETVXjTcY, string fPzipSQW);
    string LhxHIFwWErP(string EazhBxN, int AwDJaxuQ, bool mfRptCOKhhnpVk, double ealuWDneTWJ);
    string KqMdTOQ(string oUWjztTMQUyKG, bool vSxug);
    double BiPjru(double NPtgH, string IRNIBX, string RMzqeGNbWZ);
    bool zERwPa(string kPUqADXuNA);
    string HKfEVve();
protected:
    double WEfKIegaUzELNf;

    void rYKyGshcqiNt(bool EaoxxluSAVPQmLBi, double CPTWHaqYntZxRJbh, bool JFNCVJahKsXG, string VJbrD);
    int PDxBoXyfBEZ(string AyvtfTYLFBmB);
private:
    int OxcuXQnFJPpUsuv;
    double ByPyjkNPJOPF;
    int NQkbIfHaHrQN;
    int jrwSoqtYXcP;

    int FlUcDTl(double CuCWsCXhVQd, double EYMFGCKgXHOssi);
    bool XyCOKKwigFbsYE();
    int wtbQrZV(double YBGEO, string OnjsiIhhQZfvsQjN);
    string GeApoZhcMEYaN(string DwsVbf, int NVdAmwcVBtz, string kuDFFRdsa, int fppfWUsaKvDJ);
    bool FmjEvEdBJu(bool eYPvygSgxW, bool WDuCWtU, double xJcmLg, double KtCQA, double lBuyjGvU);
    void sjelOniRbDxYDbkz(double zCxSUEWowz, bool KYToSaAMpvuP, double QLWJVorz, bool hRqTVxsfJt);
};

int eMgUvAYG::OOgiSnoMsfJmnNnD(bool LEndXGPnzft, bool MNkmyhOyDoSadEpf, string hbvoWAWj)
{
    double fjsoDEYKTuShZ = 662919.6242466224;
    int LUlgSB = -558923805;
    bool qxfsQhrDUTYNzRW = false;
    double FYOOOkAICY = -1011288.3932916782;

    if (fjsoDEYKTuShZ < -1011288.3932916782) {
        for (int iKUocE = 904068585; iKUocE > 0; iKUocE--) {
            FYOOOkAICY += fjsoDEYKTuShZ;
        }
    }

    for (int ddGzTTytxg = 922427265; ddGzTTytxg > 0; ddGzTTytxg--) {
        qxfsQhrDUTYNzRW = ! LEndXGPnzft;
    }

    for (int HMlusZ = 749024610; HMlusZ > 0; HMlusZ--) {
        FYOOOkAICY = FYOOOkAICY;
        FYOOOkAICY = FYOOOkAICY;
    }

    if (MNkmyhOyDoSadEpf != false) {
        for (int MQlLNjBAfCzhHp = 1853136975; MQlLNjBAfCzhHp > 0; MQlLNjBAfCzhHp--) {
            FYOOOkAICY /= FYOOOkAICY;
            LEndXGPnzft = qxfsQhrDUTYNzRW;
        }
    }

    return LUlgSB;
}

bool eMgUvAYG::KkpbDRvuJUezCT(double zNfUUA, string TJGFMlzQSot, int nzLyDYGKtHoiBK, int OccoZuIdt)
{
    bool riFnPt = false;
    string KllNHJiXdCZHkbQ = string("rHksLKghmQPJIOjbvmZbfOvLVJPYzTmjJhiRuiZpjkcvWCQrWBMCtpUlsrZGlKLpUdtQYQvnLUCYrJhUsKRvVwZKjkySOIbjqfUlAHAhrpPFGlWKXcfGhIfloNacXajaYTRVwZxqoTZPYAyVVBkqfMtmmBs");
    int TFDIUWCcFvcKohG = 1237661967;
    double ehRZiUpIZvmvJj = -915389.4543212265;
    bool vYcMUwslwj = true;
    string LdodtxpbZWItTyw = string("aTsVoCFAKhuMjoTDJHjyOUfntdvtCJBbDUTxlzaBAYnrhArAWFwTmaivmFVONvICkqbhYhQWNwoAUdSQyzPaCdikvlVIzNUjJvAVqDGsDoFApQFGBHFyyFyWhxYALZzZlDxNadTeYyfiLOqxeTrzhGvOqMYcbFBhoHLlandrQaZQIMHQJTWARhqSRGMFbLNkxdtADzxyVSvbIMQTDaN");
    string ZliWgkZZKfOCOf = string("cwmCvxwbyRUbFpIrQOzbXnfeQpDyOCLeRhMbmQwELBvTDPQGepJNaYPguqaJpmUEEXOoBLzAOCxLaBrPoZrg");
    bool YYsvtqq = true;

    for (int IoDtUmBY = 1443261318; IoDtUmBY > 0; IoDtUmBY--) {
        continue;
    }

    return YYsvtqq;
}

void eMgUvAYG::ajGfRRxOqFGIVqt(bool iwZJFdFNETVXjTcY, string fPzipSQW)
{
    int CbISVcCvnvZqa = 447194225;
}

string eMgUvAYG::LhxHIFwWErP(string EazhBxN, int AwDJaxuQ, bool mfRptCOKhhnpVk, double ealuWDneTWJ)
{
    double jZVoDfyVFFoaBvC = -519207.2781596826;
    string wHyKIZosRLs = string("POKlfxJjyuVszLhUTLBvRWMyYJtBeVniBJUTsbJyHYzwzHTLAMZwBXQXfwtcsDhjJmLhXcpKtiMKJCsXAwatmwvwvLfGEAEAOxFhxwesVgtIZEQJCahBpbgSybnUYZoiHZGJhmGzuUweLrIQnGsJrlHoJzqI");
    bool PFrqULrTUJ = true;
    string tQixOQwtXKNW = string("BJHuVmeUYMayTAQGGfZtcVqntBHZbkkjuBMdAPFxhadLJdvqbwAVrjbWAZtJaMFkFpGdruVJcguAOUwjklsrotuyjgGBTuxibBpKVgUikACriahCjktcvmOGJGoVbpGDFMgRSqqalgHy");
    int ZFOoQ = 9856915;
    int CtFPfoHfbXODE = -112522421;
    double vhYDSs = -448768.08985989523;
    double dKnWo = 459906.33201105637;
    int nyJXPOmCNFJeOV = 1569533084;

    if (AwDJaxuQ == 9856915) {
        for (int RtxGhywkXofMnS = 235848821; RtxGhywkXofMnS > 0; RtxGhywkXofMnS--) {
            PFrqULrTUJ = ! PFrqULrTUJ;
            EazhBxN += tQixOQwtXKNW;
        }
    }

    for (int DpOgmiunGTtzGLzK = 277943583; DpOgmiunGTtzGLzK > 0; DpOgmiunGTtzGLzK--) {
        ZFOoQ /= nyJXPOmCNFJeOV;
        vhYDSs /= dKnWo;
    }

    for (int AnMwtSVYXSobctU = 7411162; AnMwtSVYXSobctU > 0; AnMwtSVYXSobctU--) {
        continue;
    }

    return tQixOQwtXKNW;
}

string eMgUvAYG::KqMdTOQ(string oUWjztTMQUyKG, bool vSxug)
{
    int whOzsc = 497212974;
    int roWZsuGHYaQTefnb = -1500917519;
    double VAQrDuuBFENtwjb = 61619.289948518686;
    int FRQkQ = -1561679582;
    string zJNCjHRfObAW = string("lmBtSruICIQeESCPEfAPRlOgMhJyOOVtjaAEFkDQyFwhUcAdpcoTvcZROrhTDarXfYyqkiqZCEPgLadjbkofWBXWoWdCwpbMIHJUUoleafrafIbZogGmuPyHWSpecySOpCqeiflLLjTnCHSXdbbFNkwiMRaSzswKlMzPbyVXaQCcsEnynPRqQCIajmLLQttAjdsLFXUuxlCXAWWXqZqFPVtmEtGw");
    bool JQLCmF = false;
    int lLjCyqK = 597575967;

    for (int XYBcvPqGsjZi = 837329399; XYBcvPqGsjZi > 0; XYBcvPqGsjZi--) {
        continue;
    }

    return zJNCjHRfObAW;
}

double eMgUvAYG::BiPjru(double NPtgH, string IRNIBX, string RMzqeGNbWZ)
{
    bool nMcZm = true;

    for (int HgjjBzmDi = 508838970; HgjjBzmDi > 0; HgjjBzmDi--) {
        IRNIBX += RMzqeGNbWZ;
        nMcZm = ! nMcZm;
        RMzqeGNbWZ = IRNIBX;
    }

    if (NPtgH != -156858.0224108235) {
        for (int RFZaLxxje = 1442700998; RFZaLxxje > 0; RFZaLxxje--) {
            RMzqeGNbWZ += RMzqeGNbWZ;
            IRNIBX += RMzqeGNbWZ;
        }
    }

    if (RMzqeGNbWZ > string("QzevoTsmZTEnOFOhokjItwMJwIYoWyUvBWRAYBLCPhepirNuesFQnKFcMswaWOiduIpLOihJzpqhXhSWufWSWdPkYtFqshdhkEeYgrVIXQbeKDqiNuLHBcJdNtQCLoayvcqnUYKJZogVrzGO")) {
        for (int CaVDS = 867636935; CaVDS > 0; CaVDS--) {
            RMzqeGNbWZ += IRNIBX;
            NPtgH *= NPtgH;
        }
    }

    for (int BqkyrRAN = 1171282272; BqkyrRAN > 0; BqkyrRAN--) {
        IRNIBX += RMzqeGNbWZ;
        IRNIBX += IRNIBX;
        IRNIBX += IRNIBX;
    }

    return NPtgH;
}

bool eMgUvAYG::zERwPa(string kPUqADXuNA)
{
    double xqLFkhySZ = -794505.771205313;
    int uBYMupj = -678691668;
    int AfEizYOK = 1766527793;
    int MSpprtFYvKVMLfw = 1244373617;
    int hlPZhRQMxaHtOCI = -738333835;
    double jLuJmiLVLnjjkyNx = 597173.2435943901;

    if (xqLFkhySZ >= -794505.771205313) {
        for (int wjupEVOLcG = 1091483943; wjupEVOLcG > 0; wjupEVOLcG--) {
            MSpprtFYvKVMLfw /= MSpprtFYvKVMLfw;
            jLuJmiLVLnjjkyNx *= xqLFkhySZ;
        }
    }

    for (int iQhDWPBxVyUa = 328268233; iQhDWPBxVyUa > 0; iQhDWPBxVyUa--) {
        MSpprtFYvKVMLfw = MSpprtFYvKVMLfw;
        MSpprtFYvKVMLfw /= MSpprtFYvKVMLfw;
        hlPZhRQMxaHtOCI *= MSpprtFYvKVMLfw;
    }

    if (AfEizYOK >= 1244373617) {
        for (int ggeHqzZxCXANlfsL = 68463609; ggeHqzZxCXANlfsL > 0; ggeHqzZxCXANlfsL--) {
            AfEizYOK -= hlPZhRQMxaHtOCI;
            MSpprtFYvKVMLfw *= MSpprtFYvKVMLfw;
            AfEizYOK += AfEizYOK;
        }
    }

    if (MSpprtFYvKVMLfw == 1244373617) {
        for (int WfVEyITBcVVcKApN = 1750660397; WfVEyITBcVVcKApN > 0; WfVEyITBcVVcKApN--) {
            uBYMupj *= AfEizYOK;
            kPUqADXuNA += kPUqADXuNA;
            AfEizYOK += hlPZhRQMxaHtOCI;
            AfEizYOK *= MSpprtFYvKVMLfw;
            hlPZhRQMxaHtOCI -= MSpprtFYvKVMLfw;
        }
    }

    for (int tPBodkMdTTuXzXsk = 237668997; tPBodkMdTTuXzXsk > 0; tPBodkMdTTuXzXsk--) {
        uBYMupj /= MSpprtFYvKVMLfw;
    }

    return true;
}

string eMgUvAYG::HKfEVve()
{
    string YcrGJSYZuLY = string("dWewuDjMfpKVjzYYxbQBRFFnQGukciEgWaNPKVmMUHFVVmtumYLCadrorqeeRXcNseRiGqvdGJcCXllca");
    string EHhHVM = string("mIqPaeqGwRQooRtimKmBtPgIALhFnFZedGqBzFpDiaZgdvIXvNCKufNjaiYKDgCcJPPuXJRwsoTallyXKaoTNkQnVQOZLMVrqODDHOFWaHSXwwwZvRPPcrkcQQNqADbBRiWkFhcksbswzSrnUnbLJAVjYxHaKLKOTkxtdySQrjjrPLFGXUnclbDTfbNlyPwqVHcHIwkrBbFlhHtC");
    bool feoCOMA = false;
    double wtWbIbNbvxadyxb = 199027.85657936576;
    bool TJJRNS = true;

    if (feoCOMA == false) {
        for (int bozAbiBmakhssOaD = 1762865262; bozAbiBmakhssOaD > 0; bozAbiBmakhssOaD--) {
            wtWbIbNbvxadyxb -= wtWbIbNbvxadyxb;
            YcrGJSYZuLY += YcrGJSYZuLY;
        }
    }

    if (EHhHVM >= string("dWewuDjMfpKVjzYYxbQBRFFnQGukciEgWaNPKVmMUHFVVmtumYLCadrorqeeRXcNseRiGqvdGJcCXllca")) {
        for (int QGGmf = 293064726; QGGmf > 0; QGGmf--) {
            YcrGJSYZuLY += EHhHVM;
        }
    }

    if (EHhHVM != string("dWewuDjMfpKVjzYYxbQBRFFnQGukciEgWaNPKVmMUHFVVmtumYLCadrorqeeRXcNseRiGqvdGJcCXllca")) {
        for (int GNJnQNgQIhnWkrB = 487748545; GNJnQNgQIhnWkrB > 0; GNJnQNgQIhnWkrB--) {
            YcrGJSYZuLY = YcrGJSYZuLY;
            feoCOMA = feoCOMA;
            YcrGJSYZuLY = EHhHVM;
            YcrGJSYZuLY = EHhHVM;
        }
    }

    for (int uIfaUcQQqnN = 745864458; uIfaUcQQqnN > 0; uIfaUcQQqnN--) {
        TJJRNS = TJJRNS;
        EHhHVM += EHhHVM;
        TJJRNS = ! TJJRNS;
        TJJRNS = feoCOMA;
    }

    return EHhHVM;
}

void eMgUvAYG::rYKyGshcqiNt(bool EaoxxluSAVPQmLBi, double CPTWHaqYntZxRJbh, bool JFNCVJahKsXG, string VJbrD)
{
    int PsvFVfIozWXYQJGQ = 1912379865;
    int kUEhakSsdgmGtxxf = 368298100;
    bool BLHelhcJNccPgcI = true;
    string CXcpBq = string("yWlxOWiAVrfCtFDanLDFmmrcFjIupjDlfAsYJRbeTlKuJFuSrctcDMXsoAmcZLRjRbfaaAShHSpMxOhnzavjJOdijLbdWZyKQOCFsoYsTUFbOdiIpIBYrKgKGQByQLSYDmdunDRSpVNSvlIDMoWkhqLVAKUZKRVSckNwohYIwsQgcpxzFKydjjqHWRzFqCIGkDAwRJsgqUlLVZdimXBUvefidQakoZuPEgMYWLPWozuLJVEEsAEAfcEdoSa");
    int BMSvFMP = -651399927;
    double VvktpXBgkJcmdi = 480820.5915426367;
    bool AHrmKuYQZKryGfW = true;
    bool IeliFhKrU = true;
    string NPevRWkiFHPKO = string("nrmqtDihnNnJkaoDhovoffQuMVOQwLxNtfMoVsQiSxHEqhJMtPqGypWivLtPptmofpbZljPZXlabNnEsZgxNBhEgWEDLAQLcbYqaWrdTDfuOPCixcsvCUIysilcTFXghiEWVhIBfFmyAo");

    for (int QlNuMpEK = 1428980969; QlNuMpEK > 0; QlNuMpEK--) {
        continue;
    }

    for (int LlVanCr = 1189375795; LlVanCr > 0; LlVanCr--) {
        CPTWHaqYntZxRJbh -= VvktpXBgkJcmdi;
    }
}

int eMgUvAYG::PDxBoXyfBEZ(string AyvtfTYLFBmB)
{
    string GkrsNB = string("gIOWzFrONMHUdFYcYyWIISqYXlBBsGAqpnLYImK");
    string ueVXKnDOgFhg = string("PTyrOaFlnxyZIirZCjblfhQNDFPGrEEqBEyTjkXKiGrqONUEMnFYAPJzktSeRIokwNcGivzJqZpogNfHhZKzwlfPPhhAHplY");

    if (GkrsNB > string("PTyrOaFlnxyZIirZCjblfhQNDFPGrEEqBEyTjkXKiGrqONUEMnFYAPJzktSeRIokwNcGivzJqZpogNfHhZKzwlfPPhhAHplY")) {
        for (int rABXQtF = 2010211557; rABXQtF > 0; rABXQtF--) {
            ueVXKnDOgFhg = GkrsNB;
        }
    }

    if (ueVXKnDOgFhg <= string("xCUBTdKbzpNPwRuyuHFKCUWPZtHfODgnNqbZDhhjWBgYLBMvgZnJlyZQCU")) {
        for (int UJzrTfeVAYo = 554646340; UJzrTfeVAYo > 0; UJzrTfeVAYo--) {
            ueVXKnDOgFhg += ueVXKnDOgFhg;
            GkrsNB = AyvtfTYLFBmB;
            GkrsNB = GkrsNB;
            AyvtfTYLFBmB += GkrsNB;
            GkrsNB = ueVXKnDOgFhg;
            ueVXKnDOgFhg = ueVXKnDOgFhg;
            GkrsNB += ueVXKnDOgFhg;
            ueVXKnDOgFhg += GkrsNB;
        }
    }

    if (ueVXKnDOgFhg >= string("xCUBTdKbzpNPwRuyuHFKCUWPZtHfODgnNqbZDhhjWBgYLBMvgZnJlyZQCU")) {
        for (int hcjgB = 678594439; hcjgB > 0; hcjgB--) {
            GkrsNB += AyvtfTYLFBmB;
            GkrsNB = ueVXKnDOgFhg;
            GkrsNB = GkrsNB;
            ueVXKnDOgFhg = ueVXKnDOgFhg;
        }
    }

    return 354958150;
}

int eMgUvAYG::FlUcDTl(double CuCWsCXhVQd, double EYMFGCKgXHOssi)
{
    string ZVrIGTweBGac = string("hJ");
    double CimSroycMBHOIfg = -832813.0998066858;
    double XHeQmKnRBVpO = -868142.9625574247;
    bool FaoXjpPmH = true;
    double PbLWewFVIGN = 453625.06593165325;
    int PEbjUIHMcDLVze = -1752861766;
    int XDlUXRSu = -902900604;

    if (XDlUXRSu <= -1752861766) {
        for (int gBGpsaPpAXYR = 2072698995; gBGpsaPpAXYR > 0; gBGpsaPpAXYR--) {
            PbLWewFVIGN /= XHeQmKnRBVpO;
        }
    }

    return XDlUXRSu;
}

bool eMgUvAYG::XyCOKKwigFbsYE()
{
    bool ZfqazdyTCksIGj = false;
    int QQqoJhtgDvCPyo = -1250625218;
    double OKxMh = 80316.51929954576;

    return ZfqazdyTCksIGj;
}

int eMgUvAYG::wtbQrZV(double YBGEO, string OnjsiIhhQZfvsQjN)
{
    double lFJckCSdQE = -610285.468419051;
    int bKvPs = 776581907;
    double nogzU = 408599.81046483445;
    string SXqkFZL = string("OSTjamcCoIvtyIFYxmJpci");
    string XXYdtrekTePX = string("OGoAKMIkAXKZynoiwDJBYQmRnffyqjoNsPducXfZNqVrppEOoyqhvIBMsSlTozGkbPPaYQPTJsrzDLO");

    for (int AUQwZZNofMtD = 1606973603; AUQwZZNofMtD > 0; AUQwZZNofMtD--) {
        OnjsiIhhQZfvsQjN = XXYdtrekTePX;
        OnjsiIhhQZfvsQjN += OnjsiIhhQZfvsQjN;
    }

    if (lFJckCSdQE >= 408599.81046483445) {
        for (int ALOeI = 653530533; ALOeI > 0; ALOeI--) {
            YBGEO *= lFJckCSdQE;
            lFJckCSdQE *= YBGEO;
        }
    }

    for (int ZKMpBiSY = 1926147982; ZKMpBiSY > 0; ZKMpBiSY--) {
        XXYdtrekTePX += OnjsiIhhQZfvsQjN;
    }

    for (int wHcaiDjACGwoSVo = 893831817; wHcaiDjACGwoSVo > 0; wHcaiDjACGwoSVo--) {
        YBGEO = lFJckCSdQE;
        XXYdtrekTePX = SXqkFZL;
        lFJckCSdQE *= nogzU;
    }

    for (int ySLEvMQxS = 1232709856; ySLEvMQxS > 0; ySLEvMQxS--) {
        XXYdtrekTePX += XXYdtrekTePX;
        OnjsiIhhQZfvsQjN = XXYdtrekTePX;
        OnjsiIhhQZfvsQjN = XXYdtrekTePX;
    }

    return bKvPs;
}

string eMgUvAYG::GeApoZhcMEYaN(string DwsVbf, int NVdAmwcVBtz, string kuDFFRdsa, int fppfWUsaKvDJ)
{
    string UzvZvRIdPynhpR = string("VpWsQBjXOdovMFFuaOoOdvtRueKDvIabDWSdUARBxfnyWxErLAbdoCmBVwUlDsdehQwnqbucMrCllHUbdqtcpuHaxmcjpqFkrqFULZIcdcRAwMcuMWqaUFuPADEmrVyxQHudrjeKuiEgdoTUrhbEAhAqYHIiOQzhqYhlCDwCoQYmuCxhSfDEZgrMMwaCJWaUFjqktjXmowKNuLcQORmx");

    if (kuDFFRdsa == string("VpWsQBjXOdovMFFuaOoOdvtRueKDvIabDWSdUARBxfnyWxErLAbdoCmBVwUlDsdehQwnqbucMrCllHUbdqtcpuHaxmcjpqFkrqFULZIcdcRAwMcuMWqaUFuPADEmrVyxQHudrjeKuiEgdoTUrhbEAhAqYHIiOQzhqYhlCDwCoQYmuCxhSfDEZgrMMwaCJWaUFjqktjXmowKNuLcQORmx")) {
        for (int XOfrXXjUMqlFGwY = 1475981334; XOfrXXjUMqlFGwY > 0; XOfrXXjUMqlFGwY--) {
            DwsVbf = kuDFFRdsa;
            NVdAmwcVBtz *= NVdAmwcVBtz;
        }
    }

    if (UzvZvRIdPynhpR >= string("CSXViUEwOWqHMovSJYaekagWxEuvBrircidrMQlBbOHlHkhcbHEMWcXDrOEBjpUSqsXKErbkuePI")) {
        for (int JEPeTkGQITPR = 762742865; JEPeTkGQITPR > 0; JEPeTkGQITPR--) {
            UzvZvRIdPynhpR += kuDFFRdsa;
            DwsVbf += UzvZvRIdPynhpR;
            UzvZvRIdPynhpR = DwsVbf;
            kuDFFRdsa += DwsVbf;
        }
    }

    if (DwsVbf > string("EGuPYPOLGTHCNNwcKKVOLIkZbGcnfKMCXAHhmzYZatQANgiyapZdkRQcwRVYbRRvasbwEKGsgMozvqSZmBkuRWbXmJXhIJBcNwFFEklKxfHcEfxPepnlmAYpoodsfnhFiwUYtvWYsZqtrLhgmyUTspxySrOIeKfnPHJcijMjulefqbPjlDdkctVFuktNIBwtv")) {
        for (int kCwPtxYT = 1127606290; kCwPtxYT > 0; kCwPtxYT--) {
            fppfWUsaKvDJ = fppfWUsaKvDJ;
            NVdAmwcVBtz /= NVdAmwcVBtz;
            NVdAmwcVBtz = fppfWUsaKvDJ;
        }
    }

    return UzvZvRIdPynhpR;
}

bool eMgUvAYG::FmjEvEdBJu(bool eYPvygSgxW, bool WDuCWtU, double xJcmLg, double KtCQA, double lBuyjGvU)
{
    string ltETZaKAopqea = string("QUZibvXVGYQYApjOyRNLFSxDqSYsZBDLfUxqpCnjarGqYargMVvGTkkDAnLSefnkhHyvPTDBkegrIlgjya");
    int FehAmIkIzb = -636079678;
    int vqDJcM = 260860210;
    int nmDLIoFPNGlbVUT = -414328716;
    int UgvWvnhwCOdyyVU = -526258857;
    string GKXHykdOA = string("jhxOyJkZrEGapcpPfxNbLaDppbFFIXQzIHoruFzgYEZletunbzNpVsKWhBnhuUMvNEZnuxGxsNYoUgrBYloiiOTEVLABAzkxEMdxhjexfrrIkeOlwnHpeItet");
    double mJjMSRoFNfxYNYzZ = 32985.884195587256;
    bool tLkCDxyhD = true;
    string jIfIWuWVDMdoaAkg = string("fIKZEALCucrVfHAhFBnWTpFBBymVJxZefFHNZmXyFyyPzfH");
    bool lSaKIG = false;

    for (int purIleVpDqGUnzbk = 33346911; purIleVpDqGUnzbk > 0; purIleVpDqGUnzbk--) {
        continue;
    }

    for (int stdoGHAWwKSTCCv = 1712399469; stdoGHAWwKSTCCv > 0; stdoGHAWwKSTCCv--) {
        continue;
    }

    return lSaKIG;
}

void eMgUvAYG::sjelOniRbDxYDbkz(double zCxSUEWowz, bool KYToSaAMpvuP, double QLWJVorz, bool hRqTVxsfJt)
{
    int zMWJpSJRucZMnh = -685507791;
    string pEOUObueI = string("lmqTpRiffrgTVqQqoWBdyhCwflGtlkwKHkRfkmdnRIms");
    double IejQhAqvWzES = -422957.04182022566;
    double bAQzaKEG = 234082.74921433223;
    string TRHianojo = string("ukGhJpnUAtwfxqqqanoVEXcuUYRHaoDqcJverqcxeRprVpwVARMAeOZ");
    string OJUZzIkutZq = string("rOofubWCdFIqbwCPvAYAjpxESIlSspQWFzTjOHlvFkqRwHXSqOvTofRcYidGTaqJDaWkgNdouihfSQtHTlrnowlxOWcrWWnUlZDMfhpNyJtELQvJMErIHKuczSfBWyyXPIKISRzSFSwLeBMBpeOBvSxDERCDgDPlsItyvYbFZcHtWIdDnsVUmZvSK");
    string BEILVPyKI = string("bkeUHvrFeNqUkVSefKTMlIqrLrYjhZjbThCfamJKcnYjqyCtzWEVMarnyHyTWYqZDLsuymiGSIROuZBwxoYxHQtcbNDRovlaOYuxeORkAGdiuLmnnjBRmxMLOxFdAJREYCgvgJENkSOTggjiXfjqAkQMhspEGmfemhCLvXuKCIaidnHtUgNyWzcbrBwXRkxLGQRRHybsefIUdA");
    double bvOorcGPHZLGWN = 120134.85247054242;
    bool TYBSbKY = true;
    int OJSXMGdsxRyn = -786560727;

    for (int bYkMrDT = 1374176080; bYkMrDT > 0; bYkMrDT--) {
        OJUZzIkutZq += BEILVPyKI;
    }

    for (int ZiUNItjZc = 342561755; ZiUNItjZc > 0; ZiUNItjZc--) {
        bAQzaKEG *= bAQzaKEG;
        QLWJVorz = bAQzaKEG;
    }

    for (int AbNsigKB = 1166538759; AbNsigKB > 0; AbNsigKB--) {
        continue;
    }

    if (bAQzaKEG < 153541.89080199736) {
        for (int zfFYiQ = 1103144971; zfFYiQ > 0; zfFYiQ--) {
            OJSXMGdsxRyn -= zMWJpSJRucZMnh;
            OJUZzIkutZq = BEILVPyKI;
        }
    }
}

eMgUvAYG::eMgUvAYG()
{
    this->OOgiSnoMsfJmnNnD(true, false, string("uYZEZzAudXdBBxtrubQxpJdwBgkQJsmiqfsygZuDjBMXzaaMhhDLJPlUknKnCMVdxLADlWMUhuRNl"));
    this->KkpbDRvuJUezCT(-43869.729696944785, string("aDgHLhmrOvOsZFLTwi"), 947424669, 389159484);
    this->ajGfRRxOqFGIVqt(false, string("LVDotQBKsEqjIneYavnljDvsXTcaHYPtYLVPbecQKrvXiqiUPRlZPNe"));
    this->LhxHIFwWErP(string("IKaVtedzqCNSiyQTsvjseFvIWaMeUmPWUwYQNaxhwqElxaYUXPmFqHPiyJzENQxQcpvWijcLmhGjQPUmwaxLwajKOQbmy"), -1956697715, true, -260956.69859871338);
    this->KqMdTOQ(string("aqnQqmmahATvcpxbNOsmDmbjDHnPjrNGcoAdnouxryBIFNKZgAJSacjQCMJkSsTylLTKyfZXyAIzmgzBNrYZhIe"), true);
    this->BiPjru(-156858.0224108235, string("VarqUnXpWIzFkpNvErWFlxkohcFNRRXIQBBPIxnuFaLrxzOGQQbAeBXdvkTahKHYxRlCMgZmDJsVwQEHXtmNDsjUyFjxwVlHRrJybwfLlaOddAJKvFiugGBKQxwQfgqJuaZDSGJbjNsMHlcXeszQtudMjEAkKXHkbNQoWtYXBTDITmidoNaSBXRuzSwgomunjrqADPQdZFUQjLAdIrAyFMJwZCueIjUnFappbNHLAzJmMlhzcZkyZRSBAssVCXf"), string("QzevoTsmZTEnOFOhokjItwMJwIYoWyUvBWRAYBLCPhepirNuesFQnKFcMswaWOiduIpLOihJzpqhXhSWufWSWdPkYtFqshdhkEeYgrVIXQbeKDqiNuLHBcJdNtQCLoayvcqnUYKJZogVrzGO"));
    this->zERwPa(string("bgFDUuJxPhoQYLuiQKcIzaMgiGAclcmJElhdKIwiCoPQbQtmbQOSBHclvYpLOcrUZOEZSRKFhELzibZdIUZgMLlhUWlgmMfYbhErvmgGQNMpYmoufWTpqELfqYihnIrVlBQFPXkRpdhM"));
    this->HKfEVve();
    this->rYKyGshcqiNt(false, -274733.99143827363, false, string("vAYMhCvvCfFmUYHPkyWIChJYSDagSRUNBJBhtqtmdzmNdBcXwysfxrtirRGYwfYpcTNGhBCVfdgsnmvgCaxGGAZEoeYkbaeKsDFBcyHXbqmkkPJsCKBExfnFrPNoSMxkcIznTmDuTkxRbuLbwOujWJHnZHFVVLwOQMHEOSmjuWqwAefzRWewMTarXMaMJgknmwRc"));
    this->PDxBoXyfBEZ(string("xCUBTdKbzpNPwRuyuHFKCUWPZtHfODgnNqbZDhhjWBgYLBMvgZnJlyZQCU"));
    this->FlUcDTl(-762827.3024752793, 330939.5903195819);
    this->XyCOKKwigFbsYE();
    this->wtbQrZV(-993793.7027672105, string("YNvFTbVTBEyKZuBMwFRmZzbeRlfpNixzEIMHkzpyQJxCRgLCVLUfIunkimvaMFCPtqgNBjbhcwdzeUeCbsjfqZqWDYKbRwGrhRSeozRU"));
    this->GeApoZhcMEYaN(string("EGuPYPOLGTHCNNwcKKVOLIkZbGcnfKMCXAHhmzYZatQANgiyapZdkRQcwRVYbRRvasbwEKGsgMozvqSZmBkuRWbXmJXhIJBcNwFFEklKxfHcEfxPepnlmAYpoodsfnhFiwUYtvWYsZqtrLhgmyUTspxySrOIeKfnPHJcijMjulefqbPjlDdkctVFuktNIBwtv"), 29356265, string("CSXViUEwOWqHMovSJYaekagWxEuvBrircidrMQlBbOHlHkhcbHEMWcXDrOEBjpUSqsXKErbkuePI"), -1626571512);
    this->FmjEvEdBJu(true, false, 446474.1623100689, -320718.1876679445, 226402.63652810862);
    this->sjelOniRbDxYDbkz(381148.43754484336, false, 153541.89080199736, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ipYuTTxqPlD
{
public:
    int pdlfVbbMAc;
    bool CsMZJAQzAqvN;
    string gcbNCthMP;
    bool MWLClupbgTIXEff;
    string sngmVZBwt;

    ipYuTTxqPlD();
    void pdDyaPMESzAwcMhY(bool OsLmaX, bool xeWXrDNvxPeVvowF, string vNFlgQhydrsRjul, int VgPVIBuDuemzGwR);
    int RWSaHMutV(string dYjrp, bool AnTVrQubnEWJqrmr, bool QxFnYQdhSdnj, string cgnGghlexhkoCkaq, bool gdWtKGBowouymcz);
    double AnolbwceBsmkbNp(bool ZXpZoJJY, bool ZVXQrxY);
    int BqQNsAzF(double nqurZJVTYsaBd, bool qIxPHvTSTdc, string psKyyvdNRbKaokb, bool cQCLsvhnEJOn, string pvMrieEtX);
    int fVWTlI(double xoaYmuGZqzyopWdn, double xdLyBhhZFQ, double YDzyhxGnzOClp, bool CveWmuhesnvAXU, double gLhSyjD);
    string KPuom();
    int jRYHeuqXHLqhGrK(bool RPUYn, int LidIlntGChsGhJHt, string fgcCprq, bool LDiFjxVhXtsRaoJ);
    double qMoNnejMZU(bool RBiVnksSLcOGITRx, string PblCjxSO, string KIbkRGtsE);
protected:
    int KWNmIoyIYBv;
    int KuXodLXEEtuoTga;
    int xFBrrzwGudOsc;
    string qsPbXZ;
    int CxaQxbUsPVgvHwTK;

    int cuSmDtROuDoa(double xKYwHLoGSf, int lkomXSMaWXRR, double eFSvmtxqZMMePivF, double YYSUxHon);
    string BTlUnc(double QpVDzrwNq, string XSbZjYITuIseDaPh);
    string cFRxOGKakPWGCyMD();
private:
    double MvdeLEOgKGciFmaZ;

    bool eXxtfGLnULPzYHOe(string npefUvHt, int MROovBSiGtTGztI);
    int flZTxuGobXeG(string HClFOjzjMZfpDiPW, double jtEnCtOmuCh);
    void zjjBhKvkCu(bool WjFJsm, string hosIUjcSlDYlpGry);
    void bbqYAbCYvFtl(bool ItXWKhxOwclVEpjE, int lsdyhRBBkEvqG, int jBjJzyYhBwovgi);
    string vYfePsCvXpfDcRy(double qwTUCCOQ, string EESZHLW);
    int NcVtWEDMs(bool IOkktnFPqPKV, double nAQoSeAEHmp);
};

void ipYuTTxqPlD::pdDyaPMESzAwcMhY(bool OsLmaX, bool xeWXrDNvxPeVvowF, string vNFlgQhydrsRjul, int VgPVIBuDuemzGwR)
{
    double IeMfyPXGrUFdr = -83872.80375515089;
    int AbAxoKgMZZwYVL = -954206068;
    double IJwbRloJH = -492407.5395779153;
    double yCMLPoMUyGDK = -569398.6652086686;
    bool BGppf = false;
    bool EQxQMywfLXT = false;
    double KqvkSayad = 740584.7730873275;

    for (int MOdUNfWZmGmEWDm = 1927430085; MOdUNfWZmGmEWDm > 0; MOdUNfWZmGmEWDm--) {
        xeWXrDNvxPeVvowF = BGppf;
    }

    for (int NBEgfXdiXi = 513812390; NBEgfXdiXi > 0; NBEgfXdiXi--) {
        IeMfyPXGrUFdr += yCMLPoMUyGDK;
    }

    for (int WcgjiwlB = 1318874716; WcgjiwlB > 0; WcgjiwlB--) {
        OsLmaX = ! OsLmaX;
        VgPVIBuDuemzGwR -= AbAxoKgMZZwYVL;
    }
}

int ipYuTTxqPlD::RWSaHMutV(string dYjrp, bool AnTVrQubnEWJqrmr, bool QxFnYQdhSdnj, string cgnGghlexhkoCkaq, bool gdWtKGBowouymcz)
{
    bool mEaDWNSmlLuCUG = true;
    bool sVMhEA = false;
    int FPBOcOk = 133024524;
    double sYGqooRvUrEyxc = 2525.7527516603973;

    if (AnTVrQubnEWJqrmr != true) {
        for (int kSvgQeOna = 483418387; kSvgQeOna > 0; kSvgQeOna--) {
            AnTVrQubnEWJqrmr = ! gdWtKGBowouymcz;
        }
    }

    return FPBOcOk;
}

double ipYuTTxqPlD::AnolbwceBsmkbNp(bool ZXpZoJJY, bool ZVXQrxY)
{
    double zRQzSNrecJoRGf = 596395.2930945161;
    double FEGHihWHkwldEB = -708284.6817811686;
    bool ABFWzsXjCUk = false;

    if (ZXpZoJJY != false) {
        for (int GgnZEGh = 858947466; GgnZEGh > 0; GgnZEGh--) {
            ZVXQrxY = ! ABFWzsXjCUk;
        }
    }

    for (int dBPYfNMOwIRQ = 155672445; dBPYfNMOwIRQ > 0; dBPYfNMOwIRQ--) {
        ZXpZoJJY = ! ZVXQrxY;
    }

    for (int IeIgNVYXgAoOY = 2033346198; IeIgNVYXgAoOY > 0; IeIgNVYXgAoOY--) {
        FEGHihWHkwldEB += FEGHihWHkwldEB;
        ZXpZoJJY = ZVXQrxY;
        ZXpZoJJY = ZVXQrxY;
        zRQzSNrecJoRGf /= FEGHihWHkwldEB;
        ABFWzsXjCUk = ZVXQrxY;
    }

    if (zRQzSNrecJoRGf > -708284.6817811686) {
        for (int hOOwBgMgo = 2132209385; hOOwBgMgo > 0; hOOwBgMgo--) {
            ZXpZoJJY = ZXpZoJJY;
            ZXpZoJJY = ABFWzsXjCUk;
            ZVXQrxY = ! ABFWzsXjCUk;
        }
    }

    if (FEGHihWHkwldEB == 596395.2930945161) {
        for (int UGuGgx = 192880870; UGuGgx > 0; UGuGgx--) {
            FEGHihWHkwldEB = zRQzSNrecJoRGf;
        }
    }

    return FEGHihWHkwldEB;
}

int ipYuTTxqPlD::BqQNsAzF(double nqurZJVTYsaBd, bool qIxPHvTSTdc, string psKyyvdNRbKaokb, bool cQCLsvhnEJOn, string pvMrieEtX)
{
    double hCkNIqGUQVW = -72765.08926206376;
    string OdXkZkchkhQW = string("dBFYEHOmdkuDhEvcIhpjFtCHGvnlFyqspHeUbptQSTEXZSGXQYGyuqhXQXYouSvHlYSpaykAyDuoaSHfdUmPjQyJAXPiUGFWYaIzIwwTknNdjZVnSrBNNzArtGAueISdTAkIHTGiMDsfxLYUaWvvFelpdQGJVMrdHMVOixYoeBPKPzhZYLRNsKciQgUbLzRowTEsMqwUyoYxsgaQlRZuAUhyxtHygFhvqlzNSmcPPAenJ");
    string TNifUBahQdLm = string("MYIkpiSCcQrikCgZSkEhzgP");
    bool LkHiLTeguGoQWgj = false;
    int birsJPgZDh = -1051672078;

    for (int XFCOWPb = 390208574; XFCOWPb > 0; XFCOWPb--) {
        OdXkZkchkhQW = TNifUBahQdLm;
        qIxPHvTSTdc = ! qIxPHvTSTdc;
    }

    if (cQCLsvhnEJOn != true) {
        for (int RyquqYlEkno = 1518443689; RyquqYlEkno > 0; RyquqYlEkno--) {
            continue;
        }
    }

    for (int oXbpHwvNk = 1515887576; oXbpHwvNk > 0; oXbpHwvNk--) {
        qIxPHvTSTdc = LkHiLTeguGoQWgj;
        psKyyvdNRbKaokb += TNifUBahQdLm;
        OdXkZkchkhQW += psKyyvdNRbKaokb;
    }

    for (int fRUqDHZRZozQLUae = 802798622; fRUqDHZRZozQLUae > 0; fRUqDHZRZozQLUae--) {
        continue;
    }

    for (int FiDirljXEDorRH = 2089691228; FiDirljXEDorRH > 0; FiDirljXEDorRH--) {
        hCkNIqGUQVW += hCkNIqGUQVW;
    }

    for (int IAesHY = 2053083013; IAesHY > 0; IAesHY--) {
        qIxPHvTSTdc = ! LkHiLTeguGoQWgj;
        birsJPgZDh /= birsJPgZDh;
    }

    if (cQCLsvhnEJOn != false) {
        for (int OVsCMDlKHwNar = 2051983300; OVsCMDlKHwNar > 0; OVsCMDlKHwNar--) {
            hCkNIqGUQVW += nqurZJVTYsaBd;
            nqurZJVTYsaBd -= hCkNIqGUQVW;
            TNifUBahQdLm += TNifUBahQdLm;
        }
    }

    return birsJPgZDh;
}

int ipYuTTxqPlD::fVWTlI(double xoaYmuGZqzyopWdn, double xdLyBhhZFQ, double YDzyhxGnzOClp, bool CveWmuhesnvAXU, double gLhSyjD)
{
    int xKDzDthUqu = 1649517919;

    if (xdLyBhhZFQ == -239302.16876634306) {
        for (int EzEqLqpkKfaAhU = 563110600; EzEqLqpkKfaAhU > 0; EzEqLqpkKfaAhU--) {
            xdLyBhhZFQ -= YDzyhxGnzOClp;
            xdLyBhhZFQ *= gLhSyjD;
            YDzyhxGnzOClp = YDzyhxGnzOClp;
            gLhSyjD += xdLyBhhZFQ;
        }
    }

    return xKDzDthUqu;
}

string ipYuTTxqPlD::KPuom()
{
    bool nHDNsur = false;
    bool fYqBmC = true;
    string WuCCwD = string("zpScRUdrIbfMNkUiQHFRrNtoTQMBcjwDaXzczRvpxmlzYMdOBLtuNAOWarbZocbOCsHdF");
    bool KPmZd = true;
    bool vMyrZKYtPUVT = false;
    string wtRbITAORvJ = string("HjaUYNxFPINsBHvPJRnxGoExNXrdPNbnsNVCrNVprl");

    for (int ooLvkASAAvb = 1567148864; ooLvkASAAvb > 0; ooLvkASAAvb--) {
        fYqBmC = nHDNsur;
        fYqBmC = ! fYqBmC;
        nHDNsur = ! vMyrZKYtPUVT;
        vMyrZKYtPUVT = fYqBmC;
    }

    return wtRbITAORvJ;
}

int ipYuTTxqPlD::jRYHeuqXHLqhGrK(bool RPUYn, int LidIlntGChsGhJHt, string fgcCprq, bool LDiFjxVhXtsRaoJ)
{
    int JhGQeK = 747514589;
    bool lJmMLfPQmpYeRafb = false;
    double TESnVnpmiSdffe = -896207.3962239417;

    if (LDiFjxVhXtsRaoJ == false) {
        for (int NBUwDsssjfARu = 918053850; NBUwDsssjfARu > 0; NBUwDsssjfARu--) {
            lJmMLfPQmpYeRafb = ! LDiFjxVhXtsRaoJ;
            RPUYn = ! lJmMLfPQmpYeRafb;
            LDiFjxVhXtsRaoJ = LDiFjxVhXtsRaoJ;
        }
    }

    return JhGQeK;
}

double ipYuTTxqPlD::qMoNnejMZU(bool RBiVnksSLcOGITRx, string PblCjxSO, string KIbkRGtsE)
{
    string otaEyjItsBr = string("YaEIMqhmScqraBtzrzCvHjJMVPYecaVRJaCucKaEvTXznvBbyxGWRhlIZsOWpVNxeeHfKeahKCfYxMcMVLcUYiChtCZDHkqmNiSozXNhdjECAyELrAZnhBCrzatIlzvzDwdnSFcsagBfbAewWgaiqniaBKIPgMqZkfKyDXoxUwRdDkxFCykGBcRFFgFwtaMfeYmCYaZDcKZLabDNUzIvUSsoXyUwRjuRpwEwyHysdhXykCivGlKsq");
    double bkmnuyWAIEVls = -1025919.6866515615;
    double YdGerwtErRplNGgG = -924730.0610804661;
    bool hveWGtkSjiqkA = false;

    for (int TNgRwchqmnqXbRF = 1615064926; TNgRwchqmnqXbRF > 0; TNgRwchqmnqXbRF--) {
        otaEyjItsBr = KIbkRGtsE;
        hveWGtkSjiqkA = ! hveWGtkSjiqkA;
    }

    for (int jnRtrfHN = 1508296076; jnRtrfHN > 0; jnRtrfHN--) {
        YdGerwtErRplNGgG -= bkmnuyWAIEVls;
        PblCjxSO += PblCjxSO;
        RBiVnksSLcOGITRx = hveWGtkSjiqkA;
    }

    return YdGerwtErRplNGgG;
}

int ipYuTTxqPlD::cuSmDtROuDoa(double xKYwHLoGSf, int lkomXSMaWXRR, double eFSvmtxqZMMePivF, double YYSUxHon)
{
    bool ATjGjvx = true;
    double CabbqstyBNZp = -406990.7477285506;

    return lkomXSMaWXRR;
}

string ipYuTTxqPlD::BTlUnc(double QpVDzrwNq, string XSbZjYITuIseDaPh)
{
    string jCxavcUMKlckTa = string("MhoYcNfiqbRvXFgHZpdkrOqUqPfTuFiRbhzEVzMTRxfONUNQnzGqJzKdWAtuEccogrGmhkRcSdzDFlzteYsvNQTRhoezhJpjvTYXhlawsAtHTcxCvdNaIHlyZbHevmzOTBsFwaIGyfqoubxiRxpMVWgVmcXafeRxaEtpYPdIFXUaHWujlpisgJkHpQtJGKdOCCibbnwvzMINhdkFgjFb");
    string ViSzzu = string("EAxDVtPxZISjmDlzDZimwZqFPQioNwQhaQAVmadMqcuQiCdxIujktIdzrbXmzlaAgOWWyTUSkSweUitiDfAHtcUDgDwaSuRRLZeFDNSkPaBKxHYLdFdehupAMsLPoYUMhhoWlMqxcmzsbVNGOuESCqPDHaMGkQCIkKkImvQkFSJHRcCxcDYaZHRuilrAqoRGADvmPjqckfiuAWNFRPFoluOQArXoWgg");
    string qHLQEYUeqpuFdh = string("tDunAMbtOxIThiwlCApIbTrbSYPgdQyfPEJdTgDyZaMjsJRrjcCHgrJaBzJZYbKNcronIAdJqUenqNIHEDNrNanBhOqWINBeoyIRBqBgPuVA");
    bool wilMDJ = true;
    double TjJkFRkNVROQ = 361412.56361884973;
    int sZqSjtFAVGczfmm = -1875903825;
    bool JhDidL = true;
    string QLryK = string("fQiRdVyTCyjYUbedcHfpDJqICloDpannuZzXGhWdEsKM");
    double VUHjVxI = -545376.6558589152;
    int gFZhyeEerSPMgHs = -948596991;

    for (int pmKWlXDmlKekC = 859883109; pmKWlXDmlKekC > 0; pmKWlXDmlKekC--) {
        TjJkFRkNVROQ -= QpVDzrwNq;
    }

    for (int NCpzxKEtXjIOjpUZ = 1516226759; NCpzxKEtXjIOjpUZ > 0; NCpzxKEtXjIOjpUZ--) {
        jCxavcUMKlckTa = QLryK;
        ViSzzu = qHLQEYUeqpuFdh;
    }

    for (int giPSCl = 1405082200; giPSCl > 0; giPSCl--) {
        XSbZjYITuIseDaPh = ViSzzu;
    }

    if (TjJkFRkNVROQ > -545376.6558589152) {
        for (int GEmRQdDgmuKxaCe = 1680893423; GEmRQdDgmuKxaCe > 0; GEmRQdDgmuKxaCe--) {
            QpVDzrwNq *= VUHjVxI;
        }
    }

    for (int NVDcMCqAFDBWCUT = 711262962; NVDcMCqAFDBWCUT > 0; NVDcMCqAFDBWCUT--) {
        XSbZjYITuIseDaPh += jCxavcUMKlckTa;
    }

    for (int UZeBsgBEB = 1374015332; UZeBsgBEB > 0; UZeBsgBEB--) {
        sZqSjtFAVGczfmm *= gFZhyeEerSPMgHs;
    }

    return QLryK;
}

string ipYuTTxqPlD::cFRxOGKakPWGCyMD()
{
    bool pTJDMspocQnDN = true;

    if (pTJDMspocQnDN != true) {
        for (int AQZZcBg = 456476473; AQZZcBg > 0; AQZZcBg--) {
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
        }
    }

    if (pTJDMspocQnDN == true) {
        for (int KjSWERPPvl = 1806681232; KjSWERPPvl > 0; KjSWERPPvl--) {
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
        }
    }

    if (pTJDMspocQnDN != true) {
        for (int CecYMlPaCv = 751709953; CecYMlPaCv > 0; CecYMlPaCv--) {
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = ! pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
        }
    }

    if (pTJDMspocQnDN != true) {
        for (int apXLILdlQoclqimA = 535677988; apXLILdlQoclqimA > 0; apXLILdlQoclqimA--) {
            pTJDMspocQnDN = pTJDMspocQnDN;
        }
    }

    if (pTJDMspocQnDN == true) {
        for (int lflEb = 1894606509; lflEb > 0; lflEb--) {
            pTJDMspocQnDN = pTJDMspocQnDN;
        }
    }

    if (pTJDMspocQnDN == true) {
        for (int cFBAYs = 399810549; cFBAYs > 0; cFBAYs--) {
            pTJDMspocQnDN = ! pTJDMspocQnDN;
        }
    }

    if (pTJDMspocQnDN != true) {
        for (int DMnAkAQXZFbpdRNj = 2143688988; DMnAkAQXZFbpdRNj > 0; DMnAkAQXZFbpdRNj--) {
            pTJDMspocQnDN = pTJDMspocQnDN;
            pTJDMspocQnDN = pTJDMspocQnDN;
        }
    }

    return string("FDVXJSJxDaafVpFTwXtVBaujnYYkFiJbdbTnOZkcVNuCRVWnOAbfBCFKPBOcdFEfXYvapHNYlHqGuuqzauNSPSfqVepcXxqzagxwWvUqLZtwYYPSnWTvYEkbmsjioQpdPNobgHqIzKVsWJjdqdvNJYHSPzWcDwJQZERlmknbxZxZDAZEinoYJzHvzWshuGdOrMrYEvJTxNSpeLPELGAKVEF");
}

bool ipYuTTxqPlD::eXxtfGLnULPzYHOe(string npefUvHt, int MROovBSiGtTGztI)
{
    double rkoqAhHmzQNHF = -435798.72081671236;
    double bhuISsrSnQ = -456612.9215959647;
    int iVOjy = 1878337283;
    int XrjFTPmPptj = -1554705017;
    bool ZdbugjnY = true;
    double xJrXg = -231589.87392658726;
    int yeTUKBcTFEe = 135375313;
    double xkLhazm = -718651.1008886052;
    string mjEfXcTJj = string("ivs");
    string mNGNQqGeNdo = string("hZqEFnyopHbMoXsRhFGaoYrgakNwBbtfxnVelsbgdoKjQyIKOBZTLoFMQBwqKSah");

    for (int lxNocK = 1500880643; lxNocK > 0; lxNocK--) {
        xJrXg *= xJrXg;
        xJrXg *= xJrXg;
    }

    for (int ZUdptutEg = 1288708964; ZUdptutEg > 0; ZUdptutEg--) {
        yeTUKBcTFEe += XrjFTPmPptj;
    }

    for (int DPBjO = 1908614028; DPBjO > 0; DPBjO--) {
        yeTUKBcTFEe -= XrjFTPmPptj;
        yeTUKBcTFEe = yeTUKBcTFEe;
        npefUvHt += mjEfXcTJj;
        mNGNQqGeNdo += npefUvHt;
    }

    for (int baSiloRPgXXfx = 617669167; baSiloRPgXXfx > 0; baSiloRPgXXfx--) {
        xJrXg *= rkoqAhHmzQNHF;
    }

    for (int lmajfpZBtRz = 1252566219; lmajfpZBtRz > 0; lmajfpZBtRz--) {
        rkoqAhHmzQNHF += bhuISsrSnQ;
        mjEfXcTJj += npefUvHt;
    }

    for (int fOdVQzEGIdsxxZht = 1266835380; fOdVQzEGIdsxxZht > 0; fOdVQzEGIdsxxZht--) {
        continue;
    }

    for (int IuVGG = 1460463852; IuVGG > 0; IuVGG--) {
        iVOjy *= MROovBSiGtTGztI;
        xkLhazm += xkLhazm;
    }

    return ZdbugjnY;
}

int ipYuTTxqPlD::flZTxuGobXeG(string HClFOjzjMZfpDiPW, double jtEnCtOmuCh)
{
    double PgtALv = 657917.3868164222;
    string gJbvXRPdz = string("ELjzOdTqZNlpzWjJJKclbCxDpksENekgxZtzWJBsYgcICiqWdGkkVYrXigRMjyCyjgPeVwpQdsVlLgApzSmddxzMYBNqohVKeBUKxcfPBAxhHXLYAcgo");
    bool NsCmmbAcJNbFTn = false;
    string SGEWZCxgPJvpAF = string("zFaIPLlRnmQvQIgLetpcGdbdnFWQCZyTlYrideaxrHnKwzfMjkOBCPnIfAHXNYzfXuhtOYTsMvKnvvrcUImrMthJeQUDiyYArVAhNLRWorgOnCNLJQmrxhaClJOGMJyHKyhKWbrbjyJcKOybNXPDRuPOdQazVIIXGGiyUCGgxgMeaCbjIad");
    int LQLPJgHrNsbYVB = -1275843494;
    bool OhEZjSTMFmdoM = true;

    return LQLPJgHrNsbYVB;
}

void ipYuTTxqPlD::zjjBhKvkCu(bool WjFJsm, string hosIUjcSlDYlpGry)
{
    bool zLnzWTajewBOkKk = true;
    bool sGKRpcOI = true;
    double boEBnkOLERd = -407591.7453302088;
    double CNoZwuDvWEIuYV = -403865.8363751727;
    int HTfabwsXN = 423705098;
    string wjHISQn = string("RMEnABqdDZjhlwmLTfIbgLOmaEgpdZGHyaTEtGKDrojHSWWqcBXhMMhclJSLUosWmGzNnxmhRwqNkpnYngnHDZWuYJzPktJahVRwWyKspeePyGPJdPOSZVzzkTNVFYFZPKANdAfU");
    int UHbAGKOoL = -1307444983;
    int wPvfpFlix = 1010340826;
}

void ipYuTTxqPlD::bbqYAbCYvFtl(bool ItXWKhxOwclVEpjE, int lsdyhRBBkEvqG, int jBjJzyYhBwovgi)
{
    string fONpirxyqhijU = string("IWTNEInbFPvCRfotmfypBbVSXNgdRFjEkokIHxCactnOyNUpbshrNDofijdXDTCXWZEInRsnPMMRsLqqCLQHYuhICLUrRdxCGTPgYxPQSUEckgwFZlPyPlpxjgMMtDwfuWmOTRgyJYLPHqlpAL");
    int ShISWqdj = 1293293316;
    double dGZBpnvAifNDJhw = -930663.6037144867;
    bool qYjPFtENkFMMV = false;
    string TuBqEgRByWgXA = string("oDzqiajLqGOmyvmB");
    double SQnnKxafBtRwmDX = 205093.12967268206;
    bool JbADc = false;
    int dgJPpPu = 1693722597;
    int GFaAe = -905018597;
    string OsYEGThqcdbWnSp = string("WFsFTuDLsGYtjhazSDEjUdywyCTzrGByKTpRInfNDmXuFGrwfaaLTyxZKGbVAiogLTA");

    for (int MBoMWKzj = 1597900722; MBoMWKzj > 0; MBoMWKzj--) {
        continue;
    }

    for (int jGkMCFMAAAnL = 1869036894; jGkMCFMAAAnL > 0; jGkMCFMAAAnL--) {
        SQnnKxafBtRwmDX += dGZBpnvAifNDJhw;
    }

    for (int OzNrcDJgqfFs = 2069601855; OzNrcDJgqfFs > 0; OzNrcDJgqfFs--) {
        SQnnKxafBtRwmDX *= SQnnKxafBtRwmDX;
        ItXWKhxOwclVEpjE = JbADc;
        SQnnKxafBtRwmDX *= dGZBpnvAifNDJhw;
    }
}

string ipYuTTxqPlD::vYfePsCvXpfDcRy(double qwTUCCOQ, string EESZHLW)
{
    bool enpOWJz = true;
    string dBgeThWKzkhKL = string("BQFhUpTsOidokrUbKMYxyQddANkTPtHtUHonjxQccozeKgzRjZawCpBKEapmulLUpVWkMZUfaRiEkOjJhEglGIHDrTOMevDzfqDjxQFZBYBZfxQyqsWquAvKJKMfiJdcuOKhNaAfwxJerTkjhXpXnwhcdSVoZDpiwxiPIAJMLXscrUvbTvzzhiuPaDdEoWZdnDttkKOKxjpvQwlYXpHXUexKG");
    int iIVIYXsP = 368572039;
    bool EmeWAlHtDBSH = false;
    int rwkpgecWRkT = -1214270601;

    for (int lVEIoUYs = 1181768768; lVEIoUYs > 0; lVEIoUYs--) {
        dBgeThWKzkhKL += EESZHLW;
        EmeWAlHtDBSH = enpOWJz;
    }

    for (int BHFkAFOwg = 238575852; BHFkAFOwg > 0; BHFkAFOwg--) {
        EmeWAlHtDBSH = enpOWJz;
        iIVIYXsP -= rwkpgecWRkT;
    }

    for (int BbsZnDvKiBBbN = 595002509; BbsZnDvKiBBbN > 0; BbsZnDvKiBBbN--) {
        EESZHLW = EESZHLW;
    }

    for (int tApXyBL = 436364393; tApXyBL > 0; tApXyBL--) {
        rwkpgecWRkT /= rwkpgecWRkT;
    }

    for (int LujCHY = 2020876375; LujCHY > 0; LujCHY--) {
        rwkpgecWRkT -= iIVIYXsP;
    }

    if (dBgeThWKzkhKL <= string("BQFhUpTsOidokrUbKMYxyQddANkTPtHtUHonjxQccozeKgzRjZawCpBKEapmulLUpVWkMZUfaRiEkOjJhEglGIHDrTOMevDzfqDjxQFZBYBZfxQyqsWquAvKJKMfiJdcuOKhNaAfwxJerTkjhXpXnwhcdSVoZDpiwxiPIAJMLXscrUvbTvzzhiuPaDdEoWZdnDttkKOKxjpvQwlYXpHXUexKG")) {
        for (int kFWaunwzskLb = 1631840224; kFWaunwzskLb > 0; kFWaunwzskLb--) {
            qwTUCCOQ *= qwTUCCOQ;
            EmeWAlHtDBSH = EmeWAlHtDBSH;
        }
    }

    return dBgeThWKzkhKL;
}

int ipYuTTxqPlD::NcVtWEDMs(bool IOkktnFPqPKV, double nAQoSeAEHmp)
{
    int DDuNRAeJ = -2043987768;
    bool XciKliIVY = true;
    int ROvIhJaVmHIdJ = -560326491;
    double WZvglp = 705022.4228789207;
    string LevxyCNY = string("PqosGMUveOtTAYWjeRHUqKXuivJIUTnDOzltTXkaFkugKaMPxPVskzsHVCvVzthdqoAHVhYWcTDoybcEfvbpGhyRZwUgkcgRZbfMMvPuxqLiZFpQEaXSklvzLrMAKoPaDLPgLgZwuJCnlEIrLjK");

    for (int OkiVWifrKruuPVB = 1597333063; OkiVWifrKruuPVB > 0; OkiVWifrKruuPVB--) {
        continue;
    }

    for (int xMwTzXeK = 581809146; xMwTzXeK > 0; xMwTzXeK--) {
        IOkktnFPqPKV = ! IOkktnFPqPKV;
        ROvIhJaVmHIdJ += ROvIhJaVmHIdJ;
    }

    for (int rsHlDRytiuxrjDJd = 1818889560; rsHlDRytiuxrjDJd > 0; rsHlDRytiuxrjDJd--) {
        WZvglp *= WZvglp;
    }

    return ROvIhJaVmHIdJ;
}

ipYuTTxqPlD::ipYuTTxqPlD()
{
    this->pdDyaPMESzAwcMhY(false, true, string("dcFzDFZaLGFxmirBTCJLAJqmIiHqjFMuFjvuOP"), -1200408965);
    this->RWSaHMutV(string("TzxiaAqdbWdoGjDqOLDherwCgoKlCMCTFRPSPWzNJUXoLgkuYBFNMirpElKXJJXqTGMXbnEQkHYwOqeOEBOnrWXDhaOWSBLezErWMNQpOxgUYUHHzrceoTKRlTSgWnGjMRuoRWfkUOYMLPuNVhnUiHlGBOBJWPjNVAnPIUHIGptx"), true, true, string("AKE"), true);
    this->AnolbwceBsmkbNp(false, false);
    this->BqQNsAzF(-902987.539064837, true, string("UxGxNgOvPrXcNeJhdDUhOBLdfDSVPUxGuMuWkQXgswRXdgQLtyybVkcWrRnBUspumUYmKFOYNOYMphRCqlWxPKwSuOWtwhQJmisAZxZCxhkDgSYVNRJAURpBVgiNpdzyCtMoAYZBvAognDCIJZLevqOfrouzFxfTQUycdnUTFTkceBvLmicccfwfJwgItKbBjPNDVlmebJSwZ"), false, string("UxaviBbxi"));
    this->fVWTlI(325237.11186429765, 704787.7631930799, -688607.8916635546, true, -239302.16876634306);
    this->KPuom();
    this->jRYHeuqXHLqhGrK(false, -977295967, string("zBeNRPSIiYbKfwVRPUGSIzfwYkPQzHJxOlwOrGmbfgJCEYYgcIWZCtGVQrcWqisXEIfZhAAuTvmgHXDLriyUwKvYGnEjhbvkCfxigmXYCEtYlpBEsLPTKjYOQUQEwtrsHZmlBEgcDELaAegngTiGKDkBXDbrslFKYROntbfVwwwhvUBibHGWNXPvDyffeusdrIREDdRpSPxaDMOvtXsPJDMfFxGHYIsdjEpomd"), false);
    this->qMoNnejMZU(true, string("xJDPgwyXDeZFKybkavKcngvrFPtNfzLJnJgFnPDUDZGBJGFyXqiHMdCmaPtBFslvERYTCHMidNHStZtYymSqZaQwFHjBUoIsORUKdtlJKzDihcHxgZqEZYpphYFLaRroL"), string("QLQWjDMkZMcjTXQaYodMtszSKrOCWnvYvuBLmBmCXTGoonVaiYCykqUXxwruAzXzVVXOLMWnJoJqDqKFwqVNVApMVyaXxahcrzfMDvmbUoWrYOtWMfwIFGBOSKfzizrvspPPpWbZCorjdzRzbdeeIIJoXnElAFGcQHluDeTvRqsvNPVRxCPIVaHuaNegEVmCgLYqeTbgSdetpbXTiZFhdfeGcLVbCPLhwLQmGVIUqSReQLNynvR"));
    this->cuSmDtROuDoa(-734310.2485389049, -1215415733, 164511.24090045103, -610345.4691690016);
    this->BTlUnc(-277440.6783320563, string("vtTZillVIzOwPvyYFdZnXlnoZnfknLMrNYrNRmVMeFHKGAZWzplpeQccComaJUuEHrJjTflafBIAFhzaUYsY"));
    this->cFRxOGKakPWGCyMD();
    this->eXxtfGLnULPzYHOe(string("wFLabVkBbIscWVGdhrBEbBiriifcqkeUgkuDcklCpYRmsLKqHOVSsXChbcpWcYJKQncBRGvqTaMhWpqDyvzvujXEKHMpneliKnCKvvTpGrqXNyGKjCTRcLlynIpPOLaSrrxyPuVldkTyLzRPj"), 601943373);
    this->flZTxuGobXeG(string("BFydbHWtqfovnuUcBVDXfFCaYVDmwWwGfhmOEkomULMHsnzwlshEjSEhKkNPMFlgQvBXBVaqfekFsCufeXTElwOUImKkEeuPaJgyTAJOzjWUsxHmTwIHMXGHBFvNaLLlNEHCwoGUoCJh"), -639716.0817792689);
    this->zjjBhKvkCu(false, string("UMrbHRgXLAvEcqNYWIwZhQosuAtYlJboayJtGcVXuuXRgEWjtLUEzMmQQXEfQZypgAxkRDvGZyffMqNJenHmzLTUeLWTsRMfzOtBVwsZtETjxKNuXzblrxGVpbuXJNlcjxGGWsDiebBmlTUxBzBHEBYTUmItXwTiBGiqSXL"));
    this->bbqYAbCYvFtl(false, 2142540628, -160788393);
    this->vYfePsCvXpfDcRy(79573.20756885872, string("GHkorBjgCyFHdlEvArStKAmvrgIOyYVxyPeVKBDPuthaiDTeK"));
    this->NcVtWEDMs(true, 655876.0861618846);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ODJdSyXrW
{
public:
    double kVjUXGy;
    double zfmtNgYqTr;

    ODJdSyXrW();
    bool vcLuNsbgaXCchse(int UrWCwVMkxloQVr, double MDAeNDokd, string GJgBXUZ);
protected:
    double WTEhWduMEKDf;

    double YnpyD(int tuZQGANzdFZMOdiF);
private:
    double GbyWIbR;
    bool DvEwc;
    bool nkfcpixEZBptk;
    double lLpCDUidiAO;

    string HgSYe(int XDcnxFxX, bool cYeefeZHBCSjrm, int SyxmvXFDvsv, double hNlLlSRws);
    int expccSqiYO(string UbabtDfuojrhoCHf, double QNLWflpFHXXOy, double wWYnYWNNL, bool QqoQPfqN);
};

bool ODJdSyXrW::vcLuNsbgaXCchse(int UrWCwVMkxloQVr, double MDAeNDokd, string GJgBXUZ)
{
    int ENILWvtte = -661125619;
    string mCUjwHOjA = string("mFSgjbimgAVehbijPWnBNTKnhtbfaFXugNuyASIwJrULHcuLmCFpVchmzprNSFolOSztDKAtbzZChbSzbPZJgnXmPsoDYLnGOjOPnGMEEWxtfvcYXTTwxkjahdtBBiQfCyfhnOEBwKtiooPNKdumarMJTtofnaPPRMd");
    int nyGGWTWsZvRhxZ = -429341626;
    int hNyATEK = -288201985;
    bool NHDBZzMrDvPp = false;
    double TGQyGdKUJWG = -362904.7004190575;
    double OItpqul = -1020418.3400152026;
    bool dOtEKkySjaTSaSR = true;

    if (OItpqul > -1020418.3400152026) {
        for (int ZSZiiOtmSWkYb = 433584284; ZSZiiOtmSWkYb > 0; ZSZiiOtmSWkYb--) {
            TGQyGdKUJWG += OItpqul;
            MDAeNDokd *= TGQyGdKUJWG;
            NHDBZzMrDvPp = NHDBZzMrDvPp;
        }
    }

    for (int GJJaKFagqYSRIiQN = 5325071; GJJaKFagqYSRIiQN > 0; GJJaKFagqYSRIiQN--) {
        ENILWvtte += ENILWvtte;
    }

    for (int GUjICxZGpD = 1060018104; GUjICxZGpD > 0; GUjICxZGpD--) {
        hNyATEK = ENILWvtte;
    }

    return dOtEKkySjaTSaSR;
}

double ODJdSyXrW::YnpyD(int tuZQGANzdFZMOdiF)
{
    bool DYNTfeZfchEftjH = true;
    int ccgottprfdDlWLx = -501745901;
    bool GNRrERLFmBCtYgKJ = true;
    string KZwCuER = string("LCSmXdYdpByrNBUIXnFGEEjRwQlOyCENcGclEpnBWfjrugSCusJYDOHGUuRqyeIrhPbtRpCdHjPzsqlYjrtZEevsrlMNIRRqEqYkpAKtPWubhMVyEQyXcaPCuSqDblNwBTJhDdYUcekketdvIUunnXvEqsbCnZamGdcsHVzGSRyEEnxHfZUafhrUpHQowucvEFLkXBYMzWRIsckOUvSfqTmEvP");

    if (tuZQGANzdFZMOdiF != -223219922) {
        for (int VxtTLJaHQgYKrX = 1053205362; VxtTLJaHQgYKrX > 0; VxtTLJaHQgYKrX--) {
            GNRrERLFmBCtYgKJ = ! GNRrERLFmBCtYgKJ;
        }
    }

    for (int OGzjPxVGQ = 2137632711; OGzjPxVGQ > 0; OGzjPxVGQ--) {
        ccgottprfdDlWLx = tuZQGANzdFZMOdiF;
    }

    for (int GfwpWfyfDNLhFqU = 2058633624; GfwpWfyfDNLhFqU > 0; GfwpWfyfDNLhFqU--) {
        DYNTfeZfchEftjH = ! DYNTfeZfchEftjH;
        GNRrERLFmBCtYgKJ = ! DYNTfeZfchEftjH;
    }

    for (int DtbmFkDljSgahvu = 1422643208; DtbmFkDljSgahvu > 0; DtbmFkDljSgahvu--) {
        continue;
    }

    return -973182.1528993414;
}

string ODJdSyXrW::HgSYe(int XDcnxFxX, bool cYeefeZHBCSjrm, int SyxmvXFDvsv, double hNlLlSRws)
{
    int ioIVlAwRCBXhxOra = 761815841;
    double bvCeFUS = 840392.8246481315;
    bool vKUkWy = true;

    if (vKUkWy != true) {
        for (int psfrRldAZuQR = 1618397941; psfrRldAZuQR > 0; psfrRldAZuQR--) {
            ioIVlAwRCBXhxOra -= SyxmvXFDvsv;
            hNlLlSRws += hNlLlSRws;
            vKUkWy = cYeefeZHBCSjrm;
            XDcnxFxX -= ioIVlAwRCBXhxOra;
        }
    }

    for (int yhzykHH = 1907457950; yhzykHH > 0; yhzykHH--) {
        hNlLlSRws += hNlLlSRws;
        ioIVlAwRCBXhxOra /= XDcnxFxX;
    }

    for (int wDKywZIxcSoT = 1138185386; wDKywZIxcSoT > 0; wDKywZIxcSoT--) {
        ioIVlAwRCBXhxOra -= XDcnxFxX;
        bvCeFUS -= bvCeFUS;
        bvCeFUS += bvCeFUS;
        ioIVlAwRCBXhxOra -= ioIVlAwRCBXhxOra;
    }

    for (int QKrIQc = 124523080; QKrIQc > 0; QKrIQc--) {
        bvCeFUS /= bvCeFUS;
    }

    return string("vPSlgceEBBgwuHJdBlnbxWVCtipV");
}

int ODJdSyXrW::expccSqiYO(string UbabtDfuojrhoCHf, double QNLWflpFHXXOy, double wWYnYWNNL, bool QqoQPfqN)
{
    double huttxKAdrls = 955734.4983516809;
    double YIMiMKhTyT = 294249.99585125846;
    int lDIIRDUDySRM = 826981468;
    bool cJJkVTPBgTFkwm = false;
    double PwKfVVlNMFayimQ = -686659.6023202923;

    for (int WYGJunIGtYPKBVYN = 53097543; WYGJunIGtYPKBVYN > 0; WYGJunIGtYPKBVYN--) {
        continue;
    }

    if (YIMiMKhTyT <= 294249.99585125846) {
        for (int YEGlxUB = 1030192840; YEGlxUB > 0; YEGlxUB--) {
            continue;
        }
    }

    return lDIIRDUDySRM;
}

ODJdSyXrW::ODJdSyXrW()
{
    this->vcLuNsbgaXCchse(-1180955273, 527486.0257693771, string("uzSTAMBdHnJqmfIlZrDZTmYvbeEABNDtgwRoZpSqqPzFjm"));
    this->YnpyD(-223219922);
    this->HgSYe(-1135252636, true, -421853247, -996299.4386734645);
    this->expccSqiYO(string("AejKYnpRYdUEgQWOGfnyRXcqegnMEVGgMOLxtAsvUNtemJkeJcEvBgnImKyKgkhopxVPTbsHfegdFHrcnexugklPtYkEnOvjsviMPnqOorZDUGXUdZHfXYCEdrSVhMlUXcuLzqjgirkLtoTWOVmEhDTSHwSdCsENMEIeuBYUfGcoIFDprArpIvYbCuefPfgCCMKTgzGDSPxLTdWEyFaHUIlLBTlfpnNSdXAfx"), 26905.06681645384, -750008.63677383, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JMaUBaB
{
public:
    int gOtCMfffzRZHj;
    double ajOaGY;
    string mPstuvQHOjAArc;
    double FJDoGtZvTBTrht;
    string tNmVwlFsiCX;

    JMaUBaB();
    int sKTrroUlt(double BZwjTTIMIniPf, double fkHehvNOZjbb, bool dTCUJtiKuEL, int UFIdngAMJJCJDf);
    bool ctFIMFhJoNkQB(double tFwccxuatyZAmv, int itAhYworotUvJv, int ZbWGKgihPrEwz, double lJAPfwVIHz);
    bool spllthhg(double XfRpHtXvul, double RTzWMYKfTo);
    double KhogMrlv(bool Ltobl, bool ThUjgRnsDmyMw, bool WkohiWpD, bool YcUZH);
    int CBJrCE(double eDIXYXHtMjD, bool gBClWCflBVCtBBt);
protected:
    string CGvpK;
    int zVzBMf;
    int kgjVtUtxgorGYh;

    bool NGjiyeEeJNvcZY(bool jsBjCqfIYyRO, string ZHuZFpNnhBjBdQa, string fzDvP, bool irKFN, int UMmfrDKTSlGHBW);
private:
    int lfXNj;
    bool xHDTxtqvOOgJ;

};

int JMaUBaB::sKTrroUlt(double BZwjTTIMIniPf, double fkHehvNOZjbb, bool dTCUJtiKuEL, int UFIdngAMJJCJDf)
{
    string AXGUnudxQKufxLN = string("kMHfBLGzvvpYTRmuXAuLfUUZHboKMdeMr");
    bool KaPikEOioGIIiNq = true;
    bool QMmkCElNtGHNXOt = true;
    string qoggouMXVL = string("gXYViEbqZtwyrgrsHMcsMsjtwKcPnrLOiNrUkrfemllLdShWSEkRHhGZnTorfESZMvOAEbLTdCZZPxVqPuqkCrSZtPNTLYiJFkZibVpqMsUsvHyoErNFDQbmXieDaMWSLPtpPqAnDIfuXDVhUkJhtTLQNjKCnNMTRkIkdizthKIofzkzPHjmdFjMXbFbNMynbiCFfVH");
    double RDCGMdoikUXQt = -457734.6257296847;

    if (RDCGMdoikUXQt != -961465.5134100904) {
        for (int agjQHAOdPV = 324767210; agjQHAOdPV > 0; agjQHAOdPV--) {
            continue;
        }
    }

    for (int bXPeUFCudvTnmW = 1614353334; bXPeUFCudvTnmW > 0; bXPeUFCudvTnmW--) {
        BZwjTTIMIniPf *= fkHehvNOZjbb;
    }

    for (int bLNXagBiDUdEboKG = 630560008; bLNXagBiDUdEboKG > 0; bLNXagBiDUdEboKG--) {
        AXGUnudxQKufxLN = qoggouMXVL;
        qoggouMXVL += qoggouMXVL;
    }

    for (int fweeBtGlDsN = 1972837164; fweeBtGlDsN > 0; fweeBtGlDsN--) {
        KaPikEOioGIIiNq = KaPikEOioGIIiNq;
    }

    if (dTCUJtiKuEL == true) {
        for (int wejXfsoJlHraTpYj = 1228741071; wejXfsoJlHraTpYj > 0; wejXfsoJlHraTpYj--) {
            continue;
        }
    }

    for (int sCJvyhFeDryaWom = 961708004; sCJvyhFeDryaWom > 0; sCJvyhFeDryaWom--) {
        continue;
    }

    return UFIdngAMJJCJDf;
}

bool JMaUBaB::ctFIMFhJoNkQB(double tFwccxuatyZAmv, int itAhYworotUvJv, int ZbWGKgihPrEwz, double lJAPfwVIHz)
{
    bool CdtOBLaAoUd = true;
    int jNULVeiznYQSMW = 640174615;
    bool vzsLpwMxeJObHGs = true;
    double WZpdluDcgcOfYxea = -725655.757123239;
    string cIkleow = string("XeSZYHBDsmyenjniGDKPaRlkKooknQLSQsRgGirrLgYhcYGOhWfLnPSeTaMpFXGBcO");
    bool VRPVccYmEuPuZNbs = true;

    for (int jQLFEvgFjrGHad = 1631825028; jQLFEvgFjrGHad > 0; jQLFEvgFjrGHad--) {
        VRPVccYmEuPuZNbs = CdtOBLaAoUd;
        VRPVccYmEuPuZNbs = ! vzsLpwMxeJObHGs;
    }

    for (int crWUENcehC = 23321308; crWUENcehC > 0; crWUENcehC--) {
        cIkleow = cIkleow;
        WZpdluDcgcOfYxea /= WZpdluDcgcOfYxea;
    }

    for (int txypf = 1417181623; txypf > 0; txypf--) {
        vzsLpwMxeJObHGs = ! CdtOBLaAoUd;
        lJAPfwVIHz *= tFwccxuatyZAmv;
    }

    if (CdtOBLaAoUd == true) {
        for (int UaSZhJe = 964463927; UaSZhJe > 0; UaSZhJe--) {
            CdtOBLaAoUd = ! CdtOBLaAoUd;
        }
    }

    return VRPVccYmEuPuZNbs;
}

bool JMaUBaB::spllthhg(double XfRpHtXvul, double RTzWMYKfTo)
{
    int CuxCqnBLBgOhtEI = -633304707;
    bool uEYaolTLrJXLH = true;
    double bjKzgavwR = 542076.7923924542;
    bool QuurDhM = false;
    string RfdqUduGC = string("EjRpBmPjdjNRapPTmpnMxEeeZFPfmzIDEEzQDoMkEgUVfFYXvNoOFGlFNvlxjlvfNWMFNSQxYxzIeNlnqLUGlz");
    string wdwKfUurqbHCh = string("hRfPzkkfwLKMacIfYJNAzIjkLyPWvCISMYMeuUrCoFqfnkAPEgBEZzglAdIbXlvwJoowZJWcTDNQCmbqcvNVUvzEwpVoKUHoWEtkmhEqnMjayOQ");
    bool cqNASCkgxSohRjMr = false;
    double qMdJxYrCa = 557438.4646135604;

    if (RTzWMYKfTo <= -712122.0438957491) {
        for (int PsbaajeVaelLJH = 1376876777; PsbaajeVaelLJH > 0; PsbaajeVaelLJH--) {
            qMdJxYrCa /= RTzWMYKfTo;
            QuurDhM = ! QuurDhM;
        }
    }

    for (int KgVcSdtyaksgmr = 1475588740; KgVcSdtyaksgmr > 0; KgVcSdtyaksgmr--) {
        uEYaolTLrJXLH = uEYaolTLrJXLH;
        XfRpHtXvul = qMdJxYrCa;
    }

    for (int nPChUiP = 1888696476; nPChUiP > 0; nPChUiP--) {
        QuurDhM = ! cqNASCkgxSohRjMr;
    }

    return cqNASCkgxSohRjMr;
}

double JMaUBaB::KhogMrlv(bool Ltobl, bool ThUjgRnsDmyMw, bool WkohiWpD, bool YcUZH)
{
    string lcdzb = string("aVCQrOjZlgpAGNjLSaIgZCjkHAqHTbNQlIQiUXFNpqkBOXbDecMMIiKMZvveOkOoyKdNoedcmxFtIzxBUevsgPgGMQcyVLPcxMdxrwvkyhKmOAnniEFKKFfuvwxxRcaPONHsRbudgzkRnIRpTrmnlMfc");
    string njVEAxwybXfZ = string("EjBVrAzvRTCUmPCVeLLQMgccvGdoluaUaHzUMRhzghccVGgoRVYcWOjbvPriOHYDQipMdZxjbTuSTypWDxkfYcD");
    int MuGTZUMz = -443618758;

    for (int uyowqvmO = 289185221; uyowqvmO > 0; uyowqvmO--) {
        YcUZH = ! Ltobl;
        Ltobl = WkohiWpD;
        Ltobl = ! Ltobl;
        ThUjgRnsDmyMw = ! Ltobl;
    }

    return 156980.87239077667;
}

int JMaUBaB::CBJrCE(double eDIXYXHtMjD, bool gBClWCflBVCtBBt)
{
    int LEuSDlvPbwuZ = 1153023652;
    double ZUnNcOrDGgjIq = 334859.5894013015;

    for (int eGOazWkiSrWMOB = 1750871092; eGOazWkiSrWMOB > 0; eGOazWkiSrWMOB--) {
        gBClWCflBVCtBBt = ! gBClWCflBVCtBBt;
        gBClWCflBVCtBBt = gBClWCflBVCtBBt;
        ZUnNcOrDGgjIq *= ZUnNcOrDGgjIq;
        ZUnNcOrDGgjIq -= ZUnNcOrDGgjIq;
    }

    for (int RQeVHPdNkFkCHQXr = 539713270; RQeVHPdNkFkCHQXr > 0; RQeVHPdNkFkCHQXr--) {
        eDIXYXHtMjD -= eDIXYXHtMjD;
        ZUnNcOrDGgjIq -= eDIXYXHtMjD;
        eDIXYXHtMjD /= eDIXYXHtMjD;
    }

    for (int ByEpUS = 1082622970; ByEpUS > 0; ByEpUS--) {
        eDIXYXHtMjD /= ZUnNcOrDGgjIq;
        ZUnNcOrDGgjIq += eDIXYXHtMjD;
        LEuSDlvPbwuZ *= LEuSDlvPbwuZ;
    }

    if (ZUnNcOrDGgjIq > -527081.6381322803) {
        for (int OdgQKTmGehgQRk = 257509738; OdgQKTmGehgQRk > 0; OdgQKTmGehgQRk--) {
            eDIXYXHtMjD /= eDIXYXHtMjD;
            eDIXYXHtMjD /= eDIXYXHtMjD;
            ZUnNcOrDGgjIq *= ZUnNcOrDGgjIq;
        }
    }

    for (int aKgYLAENQbIGQ = 660132563; aKgYLAENQbIGQ > 0; aKgYLAENQbIGQ--) {
        eDIXYXHtMjD += eDIXYXHtMjD;
    }

    return LEuSDlvPbwuZ;
}

bool JMaUBaB::NGjiyeEeJNvcZY(bool jsBjCqfIYyRO, string ZHuZFpNnhBjBdQa, string fzDvP, bool irKFN, int UMmfrDKTSlGHBW)
{
    double veHxdVcXzKeyfNau = 1001408.0661240887;
    string sebghofJG = string("ztzDcfZcIxuqwhrbMJQBJzRYnPktJkeDFzjrbZnNvZSQNTsFKZaSQPpmssQfyUQrJJMNopOslJZsmzCppz");
    string gpNCylp = string("JYAGdPdBLQjhJDySteoJpbIXGOtnWUjNWPfItTsfGpZJWtJrEfSERnhVHJEGbEcTbyuIYizzeYIlYxynBiqQhIKcuLqKbyydJvRMPCJZrPbUNBAstoHNZqpIVIYiEwrOWeyTWNoISVSGRaOHBUIdzgJfMyQgLpamkDSoeLHoTyQaLIWjYiamJwOubfWzvPuHgd");
    double XFDDCuCxB = 554034.9475026284;
    int nuYCakARIHHFtD = 341184999;
    bool lJdBuPtediqJxd = true;
    int XYkeWESnmwRYAML = 2006531047;
    double ubhzcoZ = 505341.09489000175;
    string eEtfXyuBEpl = string("zqnnWwbCJCNrzzyxXZMTqiAJvuREyMcPUGSFwBtsMIxAvQICvjeEVrNKzkNuEaFPDiaBBQZsEkeGEZAmMyCbSiJqMQDIyzKfpXIbSVupOEXXgclSKtDGaEACHbtDZeFjduLhtBPgZNzevIPlSYbQcgEkqAnRCRJwqVnQAkxkk");

    return lJdBuPtediqJxd;
}

JMaUBaB::JMaUBaB()
{
    this->sKTrroUlt(-149345.27221278258, -961465.5134100904, true, -527675953);
    this->ctFIMFhJoNkQB(-22254.564182761827, -490742925, -1016080558, -189807.53918540393);
    this->spllthhg(-387720.6118504782, -712122.0438957491);
    this->KhogMrlv(false, true, false, false);
    this->CBJrCE(-527081.6381322803, false);
    this->NGjiyeEeJNvcZY(true, string("DvhglQBaLZtagdEyuFVfVpwQuTxqRsNDVzXSDDUHFfxAaLSNvPCtHPDmgTkolxoCgzRIJEBYeSpRyTsahOJaiItOztHxJGNskmLvOcaqKPRRcYiJTfmnpfaQkjHYaJWmQqampmpgwFhVOnkYpatXaqznLItgsagHzWutfmREYTZDClLxqiCJFfgHToqbMAjmovFnjJXUKseeSbBMJHGPyhVQSPkpxuMY"), string("FjQXnVKEQYTbEmjnOCAGqOhROUGjhUKDxWnvHGrYyWwdcNsJmQbBQxufcQouZQfPQquzcYbvyEGtWfTxtUvvphXpzDnErSBQuMFpyrLntPiIDWsKhbDzwmHEqhFDNdZulwiplYFCyMvHHnefkKdruOBViOIOLRQjTqEuXuXFMsG"), false, -37679314);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aFJBZgmVsC
{
public:
    string lFvSkmYvcFNralKO;
    double zaDnVFz;
    bool FcNYRzAlRKysf;

    aFJBZgmVsC();
    void CfDpNO(string VAvQtswWyImbdgvN, bool NdObNaxJ);
    string lQvxbMVhyiJazRR(string IzZqCOAajwgnt, bool PvWnCyeI, double ODCuJyhBqO, int QzHRbzjPdM);
    double FIwdhWcycPv(double dRBknA, int EXEoOvwoA, double nqDSfAxGGXKIbh);
    string ZxEpyfH(int uUkqWZAk, double TYIKpfbW);
    bool PeofiMjSft(int szfGSq, string eosKrsvnIlT, string kmqEmqd, double SrOwGSVl, int SwrACtmNtwJZ);
    int fyszUDnKAr(double KOHZvoByjOAOJGY, bool LpaIXoNOoENxoJZ);
protected:
    int DjzYUoguGrIQ;
    bool usynXzNqSK;
    int QPJkDrWYvFdVTO;

    double ghRvoxMilpJ();
private:
    bool BAdFzyS;
    double yLubcBnVsWLaWK;
    bool HsYDw;
    string rkZXCb;
    double lNViyTxIyULKEQb;
    string bXnlhkth;

    bool wKVEqEa(double xoamiVu, int zjgRcskeQIhCumbF, int VhhfLecofRStT);
    void ZcfFXSZizXdg(int qLFnzaBKnlDAqX, int GqrBvnVHfHmRFU, int fIEyosFGqLlahgpJ);
    void TBqXACamHZPY(bool WxRyGUTckcMd, string RwHcDBx, string YirJwnnvPCSwrIU, double OWnbeiLctIvg);
    int nmMJGmiMHSDHqTYc(int ZHdiP, int jHqbUlYGDMqhbPM, bool lCbVCAOHU, int FXqjGCSBI);
    bool QhiHEz(double PDhAJ);
    void cQbRWvkKn(double mmeYzVXc, int RKwRStzKDb, bool VcIuoaeewMx);
};

void aFJBZgmVsC::CfDpNO(string VAvQtswWyImbdgvN, bool NdObNaxJ)
{
    double XZCFtk = 1045884.2717237364;

    if (NdObNaxJ == true) {
        for (int hsZOpf = 1969063470; hsZOpf > 0; hsZOpf--) {
            continue;
        }
    }
}

string aFJBZgmVsC::lQvxbMVhyiJazRR(string IzZqCOAajwgnt, bool PvWnCyeI, double ODCuJyhBqO, int QzHRbzjPdM)
{
    string EprMcrLN = string("GajwwumYaLkqHcuBfYqHUfmvNlWZVVJxunxXNRpfWiREfdLeHBMzhXdnykIekWHBtfNyqVqzmPanSZsojivGNNHALIxjezZGadPNjCDGcbhLBlbllNCVcnOZdyQnWwbaxTUUXWLmbu");
    bool FSILCZAamoWbT = false;
    int FFxdPSxkHgraXD = 784152996;
    string dEMGgrLAR = string("GCibGmxFuEQZwqrtkpJqgNmicbVsZNyFsEgMOHnuGgOgjLmvZhuYWMWqoItjLpelLLcfnHogCcrczSjfsdONYlpfXfIntMVceKcJChfiGSOubQFHhEHSDUXMdMNbgPMIsNOLjs");

    for (int GaiQbuM = 621856902; GaiQbuM > 0; GaiQbuM--) {
        continue;
    }

    if (FSILCZAamoWbT != false) {
        for (int zQDKsAMsQI = 1371212930; zQDKsAMsQI > 0; zQDKsAMsQI--) {
            EprMcrLN += EprMcrLN;
            ODCuJyhBqO *= ODCuJyhBqO;
            ODCuJyhBqO = ODCuJyhBqO;
        }
    }

    return dEMGgrLAR;
}

double aFJBZgmVsC::FIwdhWcycPv(double dRBknA, int EXEoOvwoA, double nqDSfAxGGXKIbh)
{
    bool XljZBgH = false;
    int FBQaeHwasRgYtB = 51667431;
    bool GgczlkxWC = true;
    int TmnPNWJ = 960948410;
    bool NtcTEh = true;
    double upJWHWULp = -1010253.6965872517;
    bool jBnXCPrcagdnIh = true;
    double zTTOHkkYOcIzKKF = -222080.46211454022;
    bool UwApBAGA = false;
    string FqFNgacolqDKp = string("cEHIKYVIPLWEhpTUMUuAjlaPTjtKwnHpDDennIud");

    for (int JDMjPRZBxQrWX = 165911761; JDMjPRZBxQrWX > 0; JDMjPRZBxQrWX--) {
        continue;
    }

    if (UwApBAGA != false) {
        for (int SUskF = 1001009141; SUskF > 0; SUskF--) {
            dRBknA += dRBknA;
        }
    }

    return zTTOHkkYOcIzKKF;
}

string aFJBZgmVsC::ZxEpyfH(int uUkqWZAk, double TYIKpfbW)
{
    int xMZMUm = 2042775611;
    int mqMXagxyw = -1340205481;
    bool NIKXZKl = true;
    int uokxgpaSIe = -2073507391;

    for (int SOTBs = 1819302345; SOTBs > 0; SOTBs--) {
        uokxgpaSIe *= uokxgpaSIe;
        uokxgpaSIe *= uokxgpaSIe;
        mqMXagxyw += uokxgpaSIe;
    }

    return string("iLIqcEUtXNeAYCpUlJ");
}

bool aFJBZgmVsC::PeofiMjSft(int szfGSq, string eosKrsvnIlT, string kmqEmqd, double SrOwGSVl, int SwrACtmNtwJZ)
{
    int rnHagmTLo = 817777026;
    bool zZjvLfSKygFNz = true;
    double OAqtpKURQv = 154250.58239959605;
    int oObyMgrnKboPRq = -337672540;
    bool gvneidTylz = false;
    bool pMrPfI = true;
    bool OtkFkmiNZ = false;
    int mRDvk = -458187213;

    for (int PKkJUoKRaEMy = 1236887651; PKkJUoKRaEMy > 0; PKkJUoKRaEMy--) {
        continue;
    }

    for (int ZYLSZ = 49745031; ZYLSZ > 0; ZYLSZ--) {
        eosKrsvnIlT += eosKrsvnIlT;
    }

    return OtkFkmiNZ;
}

int aFJBZgmVsC::fyszUDnKAr(double KOHZvoByjOAOJGY, bool LpaIXoNOoENxoJZ)
{
    string FKanzftmSGdiIMkc = string("h");
    int YGIrv = -96034196;
    double rrloREHOiyA = -733890.8844146663;
    bool iKHrSPBlhbDYDwbJ = false;
    string CrcYW = string("yaJUYukrGTIYxJiXljNDNtEdIyottiSmawkAYIWhSJHsgCJUHPNseheJbrKWryUDgiMfFVmvGmGTRhREyIxwRHsuIUU");
    int NhoRFyJvGMmhwW = 615061747;
    string HdttnqumuvJvkW = string("MdrCpLcFYQWsXitQmHnSXvROiNEoCuZpjtHBYmlQrcSlOaBjZkKMuflewXmDbaetzxBRJzHrXLNAxJrcwFUHNeTLOhtScDNxxZNjyiNJDGxLbkoAdlXCbjRorwgiFYvIfZNDoATaxuUFnLpAxcNBBMThJUBcMTAefGbnKrhnJkrYMlVNpaAoIxYZvmIQCiPAHOapELTPtkAxAnLoCdxFxaL");
    string ZNtBm = string("RiPunBQwDqnABUkUBKVBysvPvlSgeNeTqvwxAXnnWUiiz");
    int UUDrjeqhzflWhAx = -1575263909;
    bool wXlLh = false;

    for (int tPEmWbbRWRh = 565731818; tPEmWbbRWRh > 0; tPEmWbbRWRh--) {
        HdttnqumuvJvkW += CrcYW;
        HdttnqumuvJvkW += CrcYW;
        wXlLh = ! LpaIXoNOoENxoJZ;
        iKHrSPBlhbDYDwbJ = ! LpaIXoNOoENxoJZ;
    }

    if (iKHrSPBlhbDYDwbJ == false) {
        for (int TUMbQwabR = 595536270; TUMbQwabR > 0; TUMbQwabR--) {
            NhoRFyJvGMmhwW *= UUDrjeqhzflWhAx;
        }
    }

    return UUDrjeqhzflWhAx;
}

double aFJBZgmVsC::ghRvoxMilpJ()
{
    int iAyhT = 167141727;
    string KrvEL = string("eTqXhWBVLCKJOHOGCnEUQsCiRnXHwJAiOmWrsHUzmsslNzABgvxwipQmhxclEcsrzGgf");
    string fBxWQFIGmoNgs = string("BYNHaudmIPFawisMKUlwgtvBNaAGFaXEylexJmqBavAsTRrCDGmTQCahCtJuJGXIKFNgWpKzoKyhIrQVOTMvASkmyAzrkphEEulTRNqRArRuTajawCVKkJlIQfLDTnJsucRyJNUlRgcMjlKwadoDzxZdzHytFylmPqmPEBKulmxgVqfOzWPBeoEZDppHRmCTPdoKGEjFzQlIBIMwwAcjIQKhcUsZvqIN");
    double NUgfgrOmPSDaM = 911001.8495418852;
    string pmEEhAhUdOpYQ = string("NLmWFgvcIaYmQpuIjEcHenJczvodSgomeKwGvlRUYZgFGmgFBeObWfDJseRRycxUUOjqeRcnyEjsDdHnDEIbUuJBpSrOrNnpyOKLjCjBDVOFaESurWOATofVSFcxtdezweHjsgAOo");
    string tnZZOQNNkypSqraq = string("jgSTZSUewbwGCeTSDjPacRRnbcNDorrjgMAmlRLgEcqHYeFiKJmyVhmtMapmdVJKQWUemxbXRSdwuAsToxBMApNaEXcVByUqqCMrJAGbfcoLOeitJbAneeBCjEsytfReLwZAKxkEOZIzgnQeFfxHePqDIgaXXegVyRHypcETUyv");
    string dzNpwxgHi = string("sjKitSpgOoGDJchAcaABgLhjqencbDpDTtLBDHsrMgMvgyolvT");
    bool pMuvBGpyq = false;
    string uMKFulx = string("JEUzdAJgxgDTKKpBBoCSMDXeoswnbFwPIlFfEVettvtyhjdZbHMJnqwnZwVhLhpgOdauOjHKdTKGOpmhskGOaOyCqUfLYBCHkDowjDtpDttiXS");
    string GVPdfDywJz = string("aNJhBllSteSmkVBqWcTcsXOcjKigWTwfwXUGMJnvwP");

    return NUgfgrOmPSDaM;
}

bool aFJBZgmVsC::wKVEqEa(double xoamiVu, int zjgRcskeQIhCumbF, int VhhfLecofRStT)
{
    bool BXDpOKVCwD = false;
    bool UqmfZVDy = false;
    bool CKaAmBjXnlqEyx = false;
    int GexdvrniHyrEPaS = 1146182785;
    double mDDaTgLcpTQex = 775003.0024998342;
    double FbzwVeGPYTe = -141436.17369656873;
    double bSMPrPVLZIxsjbu = 1031301.2155336068;
    bool MCNivcclCsJJdKC = true;
    double uiYWLDkKNM = -448963.9860168207;

    for (int umYljvAxExZ = 1305430836; umYljvAxExZ > 0; umYljvAxExZ--) {
        continue;
    }

    for (int FfzGFA = 1700085594; FfzGFA > 0; FfzGFA--) {
        VhhfLecofRStT /= GexdvrniHyrEPaS;
    }

    return MCNivcclCsJJdKC;
}

void aFJBZgmVsC::ZcfFXSZizXdg(int qLFnzaBKnlDAqX, int GqrBvnVHfHmRFU, int fIEyosFGqLlahgpJ)
{
    bool UpBeRkYbEUQR = false;
    string DGqkhVuKtVsDZW = string("wpCNccktArJUlRKqQRpGYTZSGkCcmxlPBnYrZTdzvVrlCybliFRwNcbvDPRqaEemCuraJaVAXj");
    bool rYECGqtYdJkPj = false;
    string ebKdwRdZ = string("mqkrKYBAhkyrKPAyhdKcjricfcaodhCfsCKOgWmCeHUngpHDwBiiCwZZZcLmEOFZrVmeJMTnAKduPIzBIaRfnVWVeLSqxPoVrSnJJNOBOaYeQuUMbrKQNJIwzccLqfeTZSUCcpnFuTAzsZrWQzQSUbJYundeF");
    string TAjBzmAvrt = string("PJuJWRxnMOkyjCEdOLEUxZUBApXgswrtkGaUGpOcZKvBPaLPoLTCJjIcIdmhLizoukdJmciNNgSzKQRQHFEGBLVpBpMNyZ");
    string fBuWdBjQzAXQK = string("PBGybcVZHzCDliznGSjEcszXdRkmilHvOBeRldaGsmnrCMaFmAtNosz");
    bool gDhmekZlsgVu = true;

    for (int vjtwLIgNigYQNo = 1576883860; vjtwLIgNigYQNo > 0; vjtwLIgNigYQNo--) {
        continue;
    }

    if (rYECGqtYdJkPj == true) {
        for (int aDdgMHQIO = 1513845851; aDdgMHQIO > 0; aDdgMHQIO--) {
            DGqkhVuKtVsDZW = ebKdwRdZ;
            GqrBvnVHfHmRFU = qLFnzaBKnlDAqX;
            gDhmekZlsgVu = UpBeRkYbEUQR;
            fBuWdBjQzAXQK += fBuWdBjQzAXQK;
            rYECGqtYdJkPj = UpBeRkYbEUQR;
        }
    }

    if (fIEyosFGqLlahgpJ > -391645994) {
        for (int saSnzFI = 1123275330; saSnzFI > 0; saSnzFI--) {
            gDhmekZlsgVu = UpBeRkYbEUQR;
            fBuWdBjQzAXQK = ebKdwRdZ;
        }
    }

    if (fBuWdBjQzAXQK <= string("mqkrKYBAhkyrKPAyhdKcjricfcaodhCfsCKOgWmCeHUngpHDwBiiCwZZZcLmEOFZrVmeJMTnAKduPIzBIaRfnVWVeLSqxPoVrSnJJNOBOaYeQuUMbrKQNJIwzccLqfeTZSUCcpnFuTAzsZrWQzQSUbJYundeF")) {
        for (int RoaRxGfH = 1435969383; RoaRxGfH > 0; RoaRxGfH--) {
            fIEyosFGqLlahgpJ -= fIEyosFGqLlahgpJ;
            DGqkhVuKtVsDZW += ebKdwRdZ;
            rYECGqtYdJkPj = UpBeRkYbEUQR;
        }
    }

    if (TAjBzmAvrt == string("PBGybcVZHzCDliznGSjEcszXdRkmilHvOBeRldaGsmnrCMaFmAtNosz")) {
        for (int tiARgDHAtMuWQy = 11516255; tiARgDHAtMuWQy > 0; tiARgDHAtMuWQy--) {
            ebKdwRdZ += DGqkhVuKtVsDZW;
        }
    }
}

void aFJBZgmVsC::TBqXACamHZPY(bool WxRyGUTckcMd, string RwHcDBx, string YirJwnnvPCSwrIU, double OWnbeiLctIvg)
{
    bool ORFvcQn = false;
    bool LhARieBzIhypQA = false;

    if (RwHcDBx == string("GRtpPhKCoSERORktahjvkBYAVtvkHgSTjGyTtzjLShgJBlVzSGbmEDAgBHtBGlHeFkFBWUApswdTwVeaVuRGGPZbQywhEywyYOlbhXgcXVPaiSuXasjUhhWLcuPiSPXXofcSpXuVRFZEbxzUrUeijkZHqUYBirPSjJnmVLbZCvdGNdwVyUymrCfZcwDTeSxCHyZSgmWeMmzWYPdliDixjtHAXnIuKgO")) {
        for (int GYjQxRmSqBNpV = 1423847829; GYjQxRmSqBNpV > 0; GYjQxRmSqBNpV--) {
            OWnbeiLctIvg /= OWnbeiLctIvg;
            ORFvcQn = ! LhARieBzIhypQA;
        }
    }

    if (LhARieBzIhypQA == false) {
        for (int VJGQGgLHX = 829968168; VJGQGgLHX > 0; VJGQGgLHX--) {
            continue;
        }
    }

    for (int nywSsPXscXDim = 1806520111; nywSsPXscXDim > 0; nywSsPXscXDim--) {
        continue;
    }

    for (int lCFLBNpkUU = 1618515846; lCFLBNpkUU > 0; lCFLBNpkUU--) {
        WxRyGUTckcMd = ! WxRyGUTckcMd;
        YirJwnnvPCSwrIU += YirJwnnvPCSwrIU;
        ORFvcQn = LhARieBzIhypQA;
        ORFvcQn = ! WxRyGUTckcMd;
    }

    if (ORFvcQn == false) {
        for (int xMnBHaazDwoxDi = 539391252; xMnBHaazDwoxDi > 0; xMnBHaazDwoxDi--) {
            continue;
        }
    }
}

int aFJBZgmVsC::nmMJGmiMHSDHqTYc(int ZHdiP, int jHqbUlYGDMqhbPM, bool lCbVCAOHU, int FXqjGCSBI)
{
    double dEKKXF = 183649.3823920808;

    for (int UIXDc = 923548003; UIXDc > 0; UIXDc--) {
        lCbVCAOHU = ! lCbVCAOHU;
        FXqjGCSBI *= jHqbUlYGDMqhbPM;
        jHqbUlYGDMqhbPM /= FXqjGCSBI;
    }

    for (int IkAPGzZSgBzmGD = 1263418692; IkAPGzZSgBzmGD > 0; IkAPGzZSgBzmGD--) {
        FXqjGCSBI = jHqbUlYGDMqhbPM;
    }

    for (int AZFIl = 1683663295; AZFIl > 0; AZFIl--) {
        jHqbUlYGDMqhbPM += ZHdiP;
        jHqbUlYGDMqhbPM = jHqbUlYGDMqhbPM;
    }

    for (int YfiDlurrKZRp = 1486894620; YfiDlurrKZRp > 0; YfiDlurrKZRp--) {
        jHqbUlYGDMqhbPM *= jHqbUlYGDMqhbPM;
    }

    for (int kRnexSdCxWKeUbN = 249892051; kRnexSdCxWKeUbN > 0; kRnexSdCxWKeUbN--) {
        continue;
    }

    for (int FhFSzR = 944896795; FhFSzR > 0; FhFSzR--) {
        ZHdiP += ZHdiP;
    }

    return FXqjGCSBI;
}

bool aFJBZgmVsC::QhiHEz(double PDhAJ)
{
    string ComTPWA = string("agsVSDdaLLCPvtKDwUpaUEIefQkbzSttMprYoezasZbgFGzeHFyAukDgaahdTeRqCIRiQDVReJQGsmRlylTJJElIdhSNSAkKxQolcZownTOHTdKfDtVsodVbRFZLWzr");
    bool oVTpYVOQYyVRkF = true;
    double DhQSbwIUKbkT = 589166.8093353984;
    string SQDSL = string("blLAKentCyEhQIKRmBjkpZphwBWgFfNcSwVnQHWoCFdIvyLBnCmivvfitgbWmywjQyxPxYZqjZtzlRLzTRcKDTLTNWJcjMTKqQCWvDQCDMsMbwELSJSbjZnKGDEq");
    double oAhSjErefqYJd = -141238.5189857514;
    double dCBQv = 655603.342467044;
    string SHALgBxyfsaea = string("ifGGoeigFeTepeqqMLdaIaQylanwvCmAtBXBfxkHMIMiTFmUbdDrfCNNAbkRzLhwZmtRjyJxUTvWldCcBKQmzpuzdWWeVScxohNfemeYCFohkTSdzJVbZUkiSQkIvnFxYHcrilpsMzDyQSHfcpzMxXuLeGQUYFAuWsXPrWkWoPEHfcSNYDcCQtGxrQfrNMunIJPxiuFkqFAwGRffHvOtTISeZSCJWhZduFTsqnKzLeWxKwbeDIwFXN");

    for (int LxDXqIlzigtEi = 853880200; LxDXqIlzigtEi > 0; LxDXqIlzigtEi--) {
        SHALgBxyfsaea = ComTPWA;
    }

    if (DhQSbwIUKbkT > 186501.99516379045) {
        for (int WerCWvQZcxqnOWDB = 1598966293; WerCWvQZcxqnOWDB > 0; WerCWvQZcxqnOWDB--) {
            PDhAJ -= DhQSbwIUKbkT;
            ComTPWA = ComTPWA;
        }
    }

    for (int aUbhiZTi = 366054799; aUbhiZTi > 0; aUbhiZTi--) {
        DhQSbwIUKbkT += PDhAJ;
        SHALgBxyfsaea += SQDSL;
        oAhSjErefqYJd /= dCBQv;
    }

    if (PDhAJ >= 186501.99516379045) {
        for (int RllaPTBcmEW = 995603039; RllaPTBcmEW > 0; RllaPTBcmEW--) {
            dCBQv *= PDhAJ;
            PDhAJ *= oAhSjErefqYJd;
        }
    }

    if (dCBQv < 655603.342467044) {
        for (int mnqcTUj = 206580155; mnqcTUj > 0; mnqcTUj--) {
            SQDSL += SQDSL;
            PDhAJ *= DhQSbwIUKbkT;
            PDhAJ = dCBQv;
        }
    }

    return oVTpYVOQYyVRkF;
}

void aFJBZgmVsC::cQbRWvkKn(double mmeYzVXc, int RKwRStzKDb, bool VcIuoaeewMx)
{
    int CBvYsLaBl = 2084322621;
    double UIkhapwYLFciF = -707784.0554403624;
    double ZQigvL = 713791.8222772483;
    string druRns = string("NCJIaAQGXyZdWKyRSFHldDADcLbOXxEDevxbveDxUojhuWIFnNdDfyJcwTiJunXTzpQYxtmokyjeATXZcRKPweElxhKsNXZgaKtIHEsrmwsWdHnHLbIHNULNbxaAYhQ");
    double VptGg = 686613.2072800756;
    string EBKKhgNupPPWYG = string("YonkOOHPQyZgqa");
    string BXnkugUPvucNK = string("kJBSljVphUNLfVZmlOYDDwXLPPoGTYZiBnRBnAFqtR");
    string qgMzWNFFX = string("ORirWEpjYPaaILOVEblSIHdJScdOLIMfRe");
    double gqCFf = 318699.45438969927;

    for (int jsnpkmz = 775280270; jsnpkmz > 0; jsnpkmz--) {
        RKwRStzKDb *= CBvYsLaBl;
        EBKKhgNupPPWYG = BXnkugUPvucNK;
    }

    if (RKwRStzKDb < -323956706) {
        for (int sknvdkilsk = 1724001901; sknvdkilsk > 0; sknvdkilsk--) {
            gqCFf += mmeYzVXc;
            UIkhapwYLFciF /= UIkhapwYLFciF;
            BXnkugUPvucNK += EBKKhgNupPPWYG;
        }
    }

    for (int ymWdFNl = 552859523; ymWdFNl > 0; ymWdFNl--) {
        mmeYzVXc -= UIkhapwYLFciF;
        druRns += EBKKhgNupPPWYG;
        druRns = EBKKhgNupPPWYG;
    }

    for (int JSNsdHH = 507362597; JSNsdHH > 0; JSNsdHH--) {
        continue;
    }
}

aFJBZgmVsC::aFJBZgmVsC()
{
    this->CfDpNO(string("CepyxvwqpYsuJulpKJJrZIkTqLvgcYZluePzPCjvjFnadrMwaYVDacDuVRMHDZloYvEoxkDuOrjtlnTatsuJgnHcoonzjMIzKxjeWwWrovlayPsybfEeNYDyWqVKvnScrhYSsrehHLqxomsjSRuAaBQJJoRXWQZjcVcyqhfMfXJTJLqUNSELpUZIkUZfVpOQSRegNiGNHFSiPjHApRzObhYuPXSSYvSiL"), true);
    this->lQvxbMVhyiJazRR(string("YuvVYXWjGZURaJrucZ"), true, 480728.0620238689, 2084405572);
    this->FIwdhWcycPv(-589059.6657305144, 1340936007, 1039910.7263068318);
    this->ZxEpyfH(635360035, -1018655.2716452867);
    this->PeofiMjSft(-1723860940, string("JBCdrqQBZHSpLNCJopzKvrgYbFJxiMtgAdyOBfsRWaUmTpJOvbEoPIbLysHekmtXUoAzVNyoheyHrthHQpThaTraphDcPTZyHVsWimuXbEQfIzZWzmzESWbWhwjegotHqzaQdVdxqwYHBivgyLtWWaqXkNpjbnByOuOeipetlnLgn"), string("xsHlMNdlpITjyUjwHQTHIlwPpUJIDDCvVYNewfdotcUVsuuZXYDDGjsRxPmmBiJMmpqJIojTUhgrYKjXozakNcFUnOqEMwxprvelevkDRKgnYbkTWylkUcBdP"), 467805.92343485734, -300528805);
    this->fyszUDnKAr(372790.3586835879, false);
    this->ghRvoxMilpJ();
    this->wKVEqEa(561640.7681284519, 1582609655, 613832434);
    this->ZcfFXSZizXdg(384173768, -2114717120, -391645994);
    this->TBqXACamHZPY(false, string("GRtpPhKCoSERORktahjvkBYAVtvkHgSTjGyTtzjLShgJBlVzSGbmEDAgBHtBGlHeFkFBWUApswdTwVeaVuRGGPZbQywhEywyYOlbhXgcXVPaiSuXasjUhhWLcuPiSPXXofcSpXuVRFZEbxzUrUeijkZHqUYBirPSjJnmVLbZCvdGNdwVyUymrCfZcwDTeSxCHyZSgmWeMmzWYPdliDixjtHAXnIuKgO"), string("VVEKzcHexqVbhsgXscjhqEMYybrpNoTKFtXdkqNNxYdipnhcrevxNvpkCGCojJcbIhzUpRnJhFWtCIeBVTWUquFxPRtRqviyLuKTwvPiFFnQMXaLUEosYrAhywZkYqlrMBRuXvdCyzSnvxdwCASbgamPpBIglLCLNFJsmbg"), 421262.7074315217);
    this->nmMJGmiMHSDHqTYc(1695061795, -651304544, true, 88808483);
    this->QhiHEz(186501.99516379045);
    this->cQbRWvkKn(255168.53312198224, -323956706, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pwZluMF
{
public:
    string GVqDdWWieVvPJ;
    int AbYIjFJFhPoSP;
    int NgZTVBC;
    string MdGcZZJxGWE;

    pwZluMF();
    string yKdljKCQH(int CPMVRySIICe, int fYgEdyTcdRqbpk);
    bool BHDbI(double AyJFoEBEV, int JEmjmFK, string MXMoIiGJSk);
    string DqYly(string btJWIIfIHenkDYvf, string nXdisaG, double udEdWUkKWYjyDGo, double JtqoLrvlBChSdpyA);
    int meeCcLoplsdrInIH();
    string zYhGcpqImcxbPz(bool VndSsCFgF, double dmSWLcOzXSoO, bool WhjKsosIcnYpEZ, string lnzXMrWkzodHOEn);
    void tRCbaZ();
    int kKhEl(double FgGHmvNemfMR, double NzLEKvmMt, int lGWkFczs, double BNGxPMjViFRF, bool WUQKmbYzHoCKRW);
protected:
    bool viLoEwAkCJzE;
    int PUyIgbVBtHA;

    double MsKaH(double DxmOapj, double VNqBg, int JUmZBGiWkgNp, string AnKutelSzSbif, double pvlEICGV);
    bool vOjsOh(string UYfiCUeECkS, int oVGtDghXrESkfRmP);
    bool aOInhq(bool vFvqCeTW, string lDdgfPfJQW, double hgziuxC, double pqCeQuXh, int DBUUBNBxVvlZSFy);
    void ckvMDcfO(int IgKiiHB, string ckowFF, string EiGLZtsQ, double vYpcVBBrWzgYyiu, int XGsIaQKlhCHGCWkL);
    double FfBGnCnYL(int JcLRAbu, string dvenhtPc, bool BpCprFSWAbjjLBN, string MYMmbepjrmvfjU);
    int zGckTWnEFSI();
    string edyEopEeTzIspHe();
private:
    double gwqmTggkiX;
    string ZDWARJHMecJCCgr;
    int JZHIi;
    bool vMVzsSVDSlhIIVpz;
    string UORYbD;
    string DVurpYeYUKcsCsW;

    int WXftjvKTjn(string AqeSzseQQw, double tmqUSzywncMn);
    double VeOeVEymand(double ZqmrKaGNpeEGLK, string lNnfli);
    string QbiMP(int SAXvugptiWYwrDcS, double QaAyr, bool ToeoQTiaEGiwqpdp, bool jTKxZ);
    void WzxwBvUjsGyoJDc(string FJzxUHxrjzGx, int jUtVO, double osEGoNw, bool GmZxmdIbEMucbAOq);
};

string pwZluMF::yKdljKCQH(int CPMVRySIICe, int fYgEdyTcdRqbpk)
{
    double RqUsUvgblX = -653064.3540842151;
    double RiOQDjpQMT = 627067.9859793894;
    bool JMtzgaytWFHWxT = false;
    string fafgjQ = string("qIuenoBiPhCKNVjnisULYauNRZNkaiWktmpwyGdTHvPaLmFrBUNBOQOAwxJnZmjVwgaisozTCwrACIIJPNKCaHeLHwEBeVEJu");

    for (int kOPigBNNowQgIFcd = 2111639121; kOPigBNNowQgIFcd > 0; kOPigBNNowQgIFcd--) {
        JMtzgaytWFHWxT = ! JMtzgaytWFHWxT;
    }

    return fafgjQ;
}

bool pwZluMF::BHDbI(double AyJFoEBEV, int JEmjmFK, string MXMoIiGJSk)
{
    double DUmwI = 603218.3449216405;
    bool tWwrzrVcUmo = false;
    string UmcPYGceuuC = string("fv");
    double KXOLUkmMqqyC = -613898.1641550412;
    double JmTxVlieYOYGXna = -490113.8375517239;

    return tWwrzrVcUmo;
}

string pwZluMF::DqYly(string btJWIIfIHenkDYvf, string nXdisaG, double udEdWUkKWYjyDGo, double JtqoLrvlBChSdpyA)
{
    double kYsiuVOAS = 576698.4327301014;
    bool SXucte = true;
    string DHnyuJdFpoiwWF = string("mshVIYPzkEpypvIBdpFmPadSkpfpnPxblRJnMxohMwOsiFHgMGOpceyjQeSzfexDs");

    for (int yXmeyRTbqiGzYy = 1939503310; yXmeyRTbqiGzYy > 0; yXmeyRTbqiGzYy--) {
        udEdWUkKWYjyDGo += JtqoLrvlBChSdpyA;
        btJWIIfIHenkDYvf = nXdisaG;
        DHnyuJdFpoiwWF += nXdisaG;
    }

    return DHnyuJdFpoiwWF;
}

int pwZluMF::meeCcLoplsdrInIH()
{
    string aHLSGec = string("xLMtZvrpuviJNsFhxbtPrFqDGcRpylZoxdTegnMmcSdKYpuaSURVvXojmRfctkvMOOxJlRCh");
    string DipFIozZx = string("swCSdutlIqLokoksTVijGsArOtfZIuUuDxpxWbBFCtitdXFgnPKbftTggncCIcLwgCTjdjEGAsfpQIwnwpPUjrnLGIWEJfzReJYxyMICodNStNMbnShTRGGkLyMSQEgVOuOmqqIwhGOrXeJsdtcVXBbzXCvQsHviwkFf");
    bool VDVoXVJYs = true;

    for (int WyvQlQQg = 2049316610; WyvQlQQg > 0; WyvQlQQg--) {
        DipFIozZx += aHLSGec;
        aHLSGec = DipFIozZx;
        DipFIozZx += aHLSGec;
    }

    return 695398597;
}

string pwZluMF::zYhGcpqImcxbPz(bool VndSsCFgF, double dmSWLcOzXSoO, bool WhjKsosIcnYpEZ, string lnzXMrWkzodHOEn)
{
    bool FMIOEpTbrfvQ = true;
    int syIZFxIwCYntuc = -1382133897;
    bool cyScCMdXAwfSawo = false;
    int dsrXArTAxPi = 1190724548;
    double VsBVj = -355169.40615364845;
    bool ZKpbWHASXH = false;
    double HSvag = -1004943.3437663672;
    double OKnueUqaPNjuyzZg = 206951.34694535023;
    double SUvWro = -627524.4085286197;
    bool KasaWfsuNcjISQH = false;

    for (int wwfvXpQlbdHO = 467305856; wwfvXpQlbdHO > 0; wwfvXpQlbdHO--) {
        VsBVj = SUvWro;
        lnzXMrWkzodHOEn += lnzXMrWkzodHOEn;
        SUvWro += dmSWLcOzXSoO;
    }

    for (int XpLOpbpltBDFOuR = 601734572; XpLOpbpltBDFOuR > 0; XpLOpbpltBDFOuR--) {
        continue;
    }

    for (int lJSkkgn = 2070618451; lJSkkgn > 0; lJSkkgn--) {
        dmSWLcOzXSoO = SUvWro;
        cyScCMdXAwfSawo = WhjKsosIcnYpEZ;
        lnzXMrWkzodHOEn = lnzXMrWkzodHOEn;
        dmSWLcOzXSoO += OKnueUqaPNjuyzZg;
        FMIOEpTbrfvQ = ! cyScCMdXAwfSawo;
        VsBVj = HSvag;
    }

    for (int ZnLsMlzxSdo = 928056471; ZnLsMlzxSdo > 0; ZnLsMlzxSdo--) {
        continue;
    }

    return lnzXMrWkzodHOEn;
}

void pwZluMF::tRCbaZ()
{
    bool sEcLvSdfcplmNy = false;
    bool Ijuhzt = false;
    string GQcNHqhPTZLuHC = string("IhjNebjksgQAhgXtGVctrPxhJYWFPNuSyPjTWeNkTyNmyCJlimhpnSXajxAxDnWHXhXiMDtCImzCPEbhVLjleBhBcLDMuAVNMxruomkWPVGFAtgACvOBJICZahMXsplLRXdamIsDUGqyerocyvCFfMYFagHAGbvvsjivUTYpfycaSXfJhtPVrmGNwbuPeZSmOAPrxbiWvLqIhElrBitCViYcHdzMfuFPAnbPilzavYwRzGfvXoLR");
    double yGqjR = 798904.3396272291;
    bool inghfozvHprCau = true;
    bool CjiNxlcMJN = true;
    bool HKEgPBcxCOgiM = true;
    double PTeQfeSuQ = 860679.131508602;
    string NxXMGlWfCjFwllu = string("TsuAKjsiyKHWrtJMiqqIPjdIKWjvwzhFIeRPeLUPFEweGhWE");
    int BOjmNVmejcdO = -533121562;

    for (int wkCIxP = 834902660; wkCIxP > 0; wkCIxP--) {
        BOjmNVmejcdO = BOjmNVmejcdO;
    }

    for (int rvxgxNUkYrdRpFYF = 523586299; rvxgxNUkYrdRpFYF > 0; rvxgxNUkYrdRpFYF--) {
        HKEgPBcxCOgiM = ! inghfozvHprCau;
        CjiNxlcMJN = ! HKEgPBcxCOgiM;
        HKEgPBcxCOgiM = ! HKEgPBcxCOgiM;
        GQcNHqhPTZLuHC += GQcNHqhPTZLuHC;
        PTeQfeSuQ *= PTeQfeSuQ;
    }

    for (int jnJIIDNKs = 897260187; jnJIIDNKs > 0; jnJIIDNKs--) {
        Ijuhzt = Ijuhzt;
        sEcLvSdfcplmNy = HKEgPBcxCOgiM;
    }

    for (int BhxtyNKjUqlS = 1623440495; BhxtyNKjUqlS > 0; BhxtyNKjUqlS--) {
        yGqjR = yGqjR;
        CjiNxlcMJN = ! Ijuhzt;
        HKEgPBcxCOgiM = ! sEcLvSdfcplmNy;
        inghfozvHprCau = Ijuhzt;
    }
}

int pwZluMF::kKhEl(double FgGHmvNemfMR, double NzLEKvmMt, int lGWkFczs, double BNGxPMjViFRF, bool WUQKmbYzHoCKRW)
{
    string wUkHZOBHbnUQgRvX = string("xKtKiksutOorZPyyqctJjCOyoZMXveS");
    int spLNUN = -1496884885;
    bool iyIxW = false;
    double QCouJDoWOLb = 289101.61130516406;
    double rEMWx = -666402.5810854022;
    string woaTHcAgbdep = string("XoJEdeRPNogRNGqHCknqNlwYxGFtwLgPaBRusTkufPErfIzkyJKwmuqbhpyhwNvVZAzonUNFDBANgIiGVofKojCiiJRFlimjgQyBTOYtfBPzSwoNFgrKCHyVPanaSjmecEVCAaFZMaHiKpumDuUZvdhasHDxSSQmqbqtMerTTFLjvXTwhLfuYL");

    for (int tSyQVonAXjhTnNIz = 420694942; tSyQVonAXjhTnNIz > 0; tSyQVonAXjhTnNIz--) {
        QCouJDoWOLb += FgGHmvNemfMR;
        FgGHmvNemfMR = FgGHmvNemfMR;
        NzLEKvmMt *= BNGxPMjViFRF;
    }

    return spLNUN;
}

double pwZluMF::MsKaH(double DxmOapj, double VNqBg, int JUmZBGiWkgNp, string AnKutelSzSbif, double pvlEICGV)
{
    double itZoNkncbOgbXu = 766766.7081378609;
    double ZYeHVYA = 292299.19736531336;
    double RKydTYy = -507121.5300226018;

    if (pvlEICGV >= 292299.19736531336) {
        for (int PHJqBgesiOZAFSiz = 2127467972; PHJqBgesiOZAFSiz > 0; PHJqBgesiOZAFSiz--) {
            RKydTYy *= pvlEICGV;
            itZoNkncbOgbXu *= itZoNkncbOgbXu;
            ZYeHVYA = ZYeHVYA;
            RKydTYy += ZYeHVYA;
        }
    }

    if (ZYeHVYA <= 581446.5372259731) {
        for (int dghUE = 1292081462; dghUE > 0; dghUE--) {
            continue;
        }
    }

    for (int mGVZUPX = 1284328096; mGVZUPX > 0; mGVZUPX--) {
        itZoNkncbOgbXu *= ZYeHVYA;
        ZYeHVYA += pvlEICGV;
        VNqBg *= itZoNkncbOgbXu;
        ZYeHVYA /= DxmOapj;
        DxmOapj /= VNqBg;
    }

    if (pvlEICGV < -507121.5300226018) {
        for (int zkWlWuFVKMXu = 466028031; zkWlWuFVKMXu > 0; zkWlWuFVKMXu--) {
            DxmOapj -= itZoNkncbOgbXu;
            RKydTYy += VNqBg;
            ZYeHVYA = itZoNkncbOgbXu;
        }
    }

    return RKydTYy;
}

bool pwZluMF::vOjsOh(string UYfiCUeECkS, int oVGtDghXrESkfRmP)
{
    string psgMfVbhbjcXXM = string("DwVEFGsXvnxTwCoAgMneUkxFlWCjGDgqsOoHyIaMkbZIcNBixPTcueDxSkOpfwSDGsvTwpTZKKGnlYKSazcZuCgsrgXRTczCMAvgQThWSGRqZIUKbvAxzlfjiniKafBGAEQtlYovJwyDUbfaBzPPnHcQNOvrtgBdEFAcczzBqICnJcEPrjDMWffGXqaskSuSOGgkaJeTKBxwRAARGhreISfjWAEtcxagjuDahCoQKB");
    int SqKZplMTlbN = 1120182377;
    bool wqkorjeQ = true;
    bool rcOFzWJXxmZcAPF = true;
    string GriCQROFBx = string("qnTBarKDNtvFueJuTGFIutzrZqNnWXTEPNnkLpmIynQEPpchxEuhsCmUCafjHhDgkErOQQUDVxEORrCtzhyTESrTnxviIYPNTLLlxHHvayZhLnlsoeYCdpDQNIDiwuaqXujizXNrSaGHiqSFpYyBMalHXHlFdJyvoINcXQIvZbEGlDFbcfvLIqcgIMSrHPOmcWvARHvYzulHEINn");
    string wNIHUQXlTKWRziv = string("hPsMKNFNYlULZqOurFNbPLBGrNWyjzvTehDZUnmvdmWwIEdVfjREQWKFjovqnKjRmojPpVvHJjyfPLCHADiQnSvaNtPeHKXECzIysmqGTjqRpFWlTBfkkyrpUlrDWNjHPEcLXMSskjPGYBDYTTsdgUSyammjYvmyeFnuSnVrrzvTLVncwxGIieXfXdaxPhbOyMYzgOQXsICYvvKijFFzXEcsDkIRs");

    for (int qhBDVhW = 1025016399; qhBDVhW > 0; qhBDVhW--) {
        psgMfVbhbjcXXM += psgMfVbhbjcXXM;
        wNIHUQXlTKWRziv = psgMfVbhbjcXXM;
    }

    for (int JmcEjMVn = 1593467878; JmcEjMVn > 0; JmcEjMVn--) {
        continue;
    }

    for (int mihltkgxI = 1744843408; mihltkgxI > 0; mihltkgxI--) {
        continue;
    }

    if (wNIHUQXlTKWRziv == string("hPsMKNFNYlULZqOurFNbPLBGrNWyjzvTehDZUnmvdmWwIEdVfjREQWKFjovqnKjRmojPpVvHJjyfPLCHADiQnSvaNtPeHKXECzIysmqGTjqRpFWlTBfkkyrpUlrDWNjHPEcLXMSskjPGYBDYTTsdgUSyammjYvmyeFnuSnVrrzvTLVncwxGIieXfXdaxPhbOyMYzgOQXsICYvvKijFFzXEcsDkIRs")) {
        for (int NTCifoKHoYWap = 1465149006; NTCifoKHoYWap > 0; NTCifoKHoYWap--) {
            UYfiCUeECkS = UYfiCUeECkS;
            UYfiCUeECkS = GriCQROFBx;
        }
    }

    return rcOFzWJXxmZcAPF;
}

bool pwZluMF::aOInhq(bool vFvqCeTW, string lDdgfPfJQW, double hgziuxC, double pqCeQuXh, int DBUUBNBxVvlZSFy)
{
    string bPQKV = string("bkioUhUymdjVAEcWduIABNmrJQ");
    string nzlRCtwW = string("czQfBgfbnOKiqSlvpXrJshkpCUfYflwhhvshnpAeMxVxxnjwmvneeUgJxByaFyhGhzOEhuMRpwqXSDXIVTMETatlnMEKnElFbFziFiHftMvYWUeTPMQlOy");
    string QpmLwCCBJdwiC = string("LLmKhVANkvQdCdRWaNsMLlRInuggebgVuOGMxuavTvfXbRVEVWSrlTUCsgyJklAgVhfdfABEBLQhjcTGSbtgUZPkpsvHaaODkdEUjyoBDwvfQQwFSMLThXHGldhYiklFABNMKgMzOvMGnRpzg");
    double RwxJGyiTaOrTwL = -85444.31808264217;
    double GqcCcrxHW = 533873.1799279064;
    int vuOVVvBFafKy = 16583806;
    int lMPBQOLEx = -1552329711;

    for (int mEWuXQKYYrWCqgzE = 1182625821; mEWuXQKYYrWCqgzE > 0; mEWuXQKYYrWCqgzE--) {
        hgziuxC -= pqCeQuXh;
        hgziuxC = RwxJGyiTaOrTwL;
    }

    for (int EauuvRrNJ = 283876436; EauuvRrNJ > 0; EauuvRrNJ--) {
        bPQKV = nzlRCtwW;
    }

    for (int gAHXPzKdHzlym = 2036970187; gAHXPzKdHzlym > 0; gAHXPzKdHzlym--) {
        pqCeQuXh = GqcCcrxHW;
        hgziuxC = GqcCcrxHW;
    }

    for (int mNJUKDKZIXcJIGBN = 1086017182; mNJUKDKZIXcJIGBN > 0; mNJUKDKZIXcJIGBN--) {
        RwxJGyiTaOrTwL += RwxJGyiTaOrTwL;
        QpmLwCCBJdwiC = QpmLwCCBJdwiC;
        lDdgfPfJQW = lDdgfPfJQW;
    }

    for (int CKqBsxA = 124596930; CKqBsxA > 0; CKqBsxA--) {
        continue;
    }

    return vFvqCeTW;
}

void pwZluMF::ckvMDcfO(int IgKiiHB, string ckowFF, string EiGLZtsQ, double vYpcVBBrWzgYyiu, int XGsIaQKlhCHGCWkL)
{
    double ddOVgnusXXUinhjG = -192076.56655610783;
    string BJmqiKFNhAojZrr = string("irabscaYXbrRADvCJYsEpiATSKXIIAuQDDkFVEUovUfVwYQIPJOjMZYVELqldPhLAFYRvmmtKiDszDYnmEokIYNNShVAbYMAyMqOnmMlhPxqdHvqmMTEJiCCNdXxUMBpxYEsuVghpkXnHLZGihHPRKWavlkxoP");
    double HGxhLsSwBSjlxa = -685984.3876669782;

    if (ddOVgnusXXUinhjG == -685984.3876669782) {
        for (int AEbqlVXMV = 1470745019; AEbqlVXMV > 0; AEbqlVXMV--) {
            continue;
        }
    }

    for (int LMEPjC = 891401930; LMEPjC > 0; LMEPjC--) {
        vYpcVBBrWzgYyiu /= vYpcVBBrWzgYyiu;
    }

    for (int qOkaVKtQVbf = 82227281; qOkaVKtQVbf > 0; qOkaVKtQVbf--) {
        vYpcVBBrWzgYyiu -= ddOVgnusXXUinhjG;
        ckowFF += EiGLZtsQ;
        ckowFF = EiGLZtsQ;
        EiGLZtsQ = BJmqiKFNhAojZrr;
    }

    for (int eAkZQllN = 789932942; eAkZQllN > 0; eAkZQllN--) {
        ddOVgnusXXUinhjG = ddOVgnusXXUinhjG;
        ckowFF = BJmqiKFNhAojZrr;
        vYpcVBBrWzgYyiu += ddOVgnusXXUinhjG;
    }

    for (int XmHAJUuqmz = 725192629; XmHAJUuqmz > 0; XmHAJUuqmz--) {
        HGxhLsSwBSjlxa = ddOVgnusXXUinhjG;
        BJmqiKFNhAojZrr += BJmqiKFNhAojZrr;
    }
}

double pwZluMF::FfBGnCnYL(int JcLRAbu, string dvenhtPc, bool BpCprFSWAbjjLBN, string MYMmbepjrmvfjU)
{
    bool qlMejmp = false;
    int qyMtyhdHyYqWMwfG = -1582833639;
    double jhbzHL = -461857.95845391776;
    string yWsHENn = string("dAgClczCNpWsCWYUJabXvNapYHWDyJgEwhHEBKpLBKRobtSiwNzNfxqDNVumMTukTyNpWnKNHwZduhoJuAprMYkmFxrxLgDkEBrkcYopfQcFAiPfd");

    return jhbzHL;
}

int pwZluMF::zGckTWnEFSI()
{
    int DiFxllBRIWyvlXCN = 92764946;
    int nwNxYR = 1898616524;
    string xEGPbiVXX = string("rqJCewtbnrksgzKf");
    bool RKsHXbNGVMY = false;
    double dtblmmoVSymQPm = 344683.87801352295;

    for (int KHvDzvAeh = 78137124; KHvDzvAeh > 0; KHvDzvAeh--) {
        DiFxllBRIWyvlXCN = nwNxYR;
        nwNxYR -= nwNxYR;
        nwNxYR += DiFxllBRIWyvlXCN;
    }

    return nwNxYR;
}

string pwZluMF::edyEopEeTzIspHe()
{
    int nqFGtwoGu = 564909691;
    bool AMPwQ = true;
    bool LUOLaR = false;
    string QGVlhy = string("TTlaNRTXnAvAJBlGhUzeztqBkEhfLKQdqigNIrjWvhgBjcnTywLsICJRVsYNHYHTIJhAWZkLrOtBOPnkTjPchyMHWiFYxxCzNcArdhQjNfhZNvwbzfVJonwdXUaFEwVR");
    bool NejopipFwXPR = true;
    string tkwjV = string("GFENGWOzYWNTeYrLCkoqbqQrtJaOWhZybmTxuEnixyEsOCBMvToartZJDCsuhSKVfkVBIuuVCEeRLwH");
    bool xndRPacgTBAMDXL = false;

    for (int oBtwXiiwZ = 1572807403; oBtwXiiwZ > 0; oBtwXiiwZ--) {
        AMPwQ = ! AMPwQ;
    }

    for (int hPLSjWDBAau = 1832770219; hPLSjWDBAau > 0; hPLSjWDBAau--) {
        xndRPacgTBAMDXL = NejopipFwXPR;
        xndRPacgTBAMDXL = xndRPacgTBAMDXL;
        QGVlhy = QGVlhy;
    }

    for (int HlbEx = 861470351; HlbEx > 0; HlbEx--) {
        AMPwQ = xndRPacgTBAMDXL;
    }

    return tkwjV;
}

int pwZluMF::WXftjvKTjn(string AqeSzseQQw, double tmqUSzywncMn)
{
    int VQQJINBaHD = -528434547;
    int SsOdsZID = -898034625;
    bool kQKioOTTEwfpXag = true;
    double DmRmV = 704913.4389262018;

    for (int WsDrtrwCBJWldy = 1608694734; WsDrtrwCBJWldy > 0; WsDrtrwCBJWldy--) {
        continue;
    }

    for (int NuiJwMLHFJJUz = 487339399; NuiJwMLHFJJUz > 0; NuiJwMLHFJJUz--) {
        tmqUSzywncMn *= tmqUSzywncMn;
        VQQJINBaHD *= VQQJINBaHD;
        tmqUSzywncMn *= DmRmV;
    }

    for (int HMAWbMPiqbt = 212082265; HMAWbMPiqbt > 0; HMAWbMPiqbt--) {
        SsOdsZID = SsOdsZID;
        tmqUSzywncMn *= DmRmV;
        DmRmV -= DmRmV;
    }

    if (VQQJINBaHD == -528434547) {
        for (int kDMfZeicSx = 1934339321; kDMfZeicSx > 0; kDMfZeicSx--) {
            continue;
        }
    }

    return SsOdsZID;
}

double pwZluMF::VeOeVEymand(double ZqmrKaGNpeEGLK, string lNnfli)
{
    bool hxuwguCfcnouF = true;

    return ZqmrKaGNpeEGLK;
}

string pwZluMF::QbiMP(int SAXvugptiWYwrDcS, double QaAyr, bool ToeoQTiaEGiwqpdp, bool jTKxZ)
{
    string FXAft = string("FbJcPJarcbVaSMVHqdqQkjGfJnIFXILfImJpSTcmbFlaoVXXUFrWnZQMojYECsWXjGNpXWRGqLhadAerDwWRWpwwtLUWkMmOSPflst");
    double VCWrgocXF = 402349.6367334444;
    bool NaGdiTsSk = true;
    int HVbhHv = -1844135416;

    if (SAXvugptiWYwrDcS <= -1844135416) {
        for (int giMdnU = 373596874; giMdnU > 0; giMdnU--) {
            continue;
        }
    }

    for (int MlQvzAHJjy = 977209052; MlQvzAHJjy > 0; MlQvzAHJjy--) {
        ToeoQTiaEGiwqpdp = NaGdiTsSk;
        SAXvugptiWYwrDcS /= HVbhHv;
        QaAyr /= VCWrgocXF;
        HVbhHv -= SAXvugptiWYwrDcS;
        SAXvugptiWYwrDcS += HVbhHv;
    }

    for (int DEKulksqNFHRQ = 1139424029; DEKulksqNFHRQ > 0; DEKulksqNFHRQ--) {
        continue;
    }

    for (int AoZtsGop = 1603810014; AoZtsGop > 0; AoZtsGop--) {
        ToeoQTiaEGiwqpdp = ! ToeoQTiaEGiwqpdp;
        jTKxZ = ! ToeoQTiaEGiwqpdp;
    }

    return FXAft;
}

void pwZluMF::WzxwBvUjsGyoJDc(string FJzxUHxrjzGx, int jUtVO, double osEGoNw, bool GmZxmdIbEMucbAOq)
{
    string QScZncV = string("HNTJENOFXMXKxwEScAQbLRgmkwihulLjeaFzJPvdGnehfoqBwHxNNAKjyrBtZDqTtiMafeLUdMlXVGbOLDHMrnPexBBOdaiIeCRvRBHRNhWrmIiZAcuzCyzlGnvRVQSsEDSpZZznEtqBDrYdBromXFdbrOmfbUuvPhHLJJIicuPBHzXXvplsRzV");
    bool zcCIrVnhtbjfu = false;
    bool JdAqf = true;

    for (int nyrsWP = 1255960333; nyrsWP > 0; nyrsWP--) {
        JdAqf = ! GmZxmdIbEMucbAOq;
        zcCIrVnhtbjfu = JdAqf;
    }

    for (int dTKWfdpdVtxSTRj = 1420918555; dTKWfdpdVtxSTRj > 0; dTKWfdpdVtxSTRj--) {
        zcCIrVnhtbjfu = JdAqf;
        JdAqf = GmZxmdIbEMucbAOq;
    }

    for (int PtYVwLZTKFoZAoZU = 1265331572; PtYVwLZTKFoZAoZU > 0; PtYVwLZTKFoZAoZU--) {
        continue;
    }
}

pwZluMF::pwZluMF()
{
    this->yKdljKCQH(-214681038, 933324490);
    this->BHDbI(-418070.65586305736, 609251021, string("pXFgaglxtEeLPPfsQDVdhpruiQRmDUMiBVhihAtzQgDZCethJE"));
    this->DqYly(string("hiDErDiTPXEbjyJBSqHavcgisnQPWbqalCRvQJqWultRhYQVjNWdWcxgmuBDtWpGstZXVCySVxZNQEkfdytE"), string("vNFInujoHuZxwaatcEXrIGFBBgdlFynTxKUXAgxJPfVWtxRiBPQtsdoifOBqqhHxHCXYwygIyilJhDeDKadGiqKdiQGFkWkMPhegTJKSTPmCSqpBxgSWNhJUmcgIRmYKpbQjHgcyheFLRwcUWSqRVddskjuESEoJSGUHqTa"), -143357.34857963902, 10371.882632099423);
    this->meeCcLoplsdrInIH();
    this->zYhGcpqImcxbPz(false, -621827.2841495484, false, string("xgtTmyKlRYY"));
    this->tRCbaZ();
    this->kKhEl(779797.8079185064, 890040.7866174987, -1146943526, 141247.5489478274, true);
    this->MsKaH(27181.405427165875, 132335.5166132751, 7728728, string("osONF"), 581446.5372259731);
    this->vOjsOh(string("ldqIsgkPdHegXgpnMhZcOloEYfAisxPnwIJHPefEPdFaTcgzkdMgkmRoDvfkZXXWnFKILHYlvfafOUxgWuo"), -1050863318);
    this->aOInhq(true, string("qSXgTdTUAMAPGdmnGhuQpCLzkskluKRwPZNPYlqxzGHbaVpOvmHOlCMFikYQZehMopiaVsdCOBvlnhqHuvAGFYTnIaqyCruKdYOuPOehPUoDniKBCvvMGyarAgJTuOEjOcMSfjQQwcDePJmMyXHJ"), -864050.7948131413, -786214.8040868246, -273739191);
    this->ckvMDcfO(2015771473, string("NMOzVOwSZnvASNEOvmpzEHfBXdjOnXAssNxAnrgfBaxoGYTWfaJoDeUDzEEenaihTxdwKWaaNiyxxJtUNkscyNPGNNXPJNmwdCnIaUltVGXtEjznXHjXlwHsOkHJmoiDcNsVyENrvqkLYNEaFQSVBprWjhPaeKLacmcpsslhZemucpSXDzECYWWsldkyuMqWBkaheRkVb"), string("DOyVBjlXPgciDpf"), 943121.6320735179, -1605033922);
    this->FfBGnCnYL(1823426414, string("IZgylnJODOHbXVGEGawGKwCNYuJpHabHwdCqZxlqoAjzIYdQYajJxWQdcqXnfIUpIAoNTDvaEkItDJppZDGqTjlidAeOkXukQwMEfPJAgwvXMjuljjBBsiodwpozIIkKQYjnqlhWjQXfhwNrYYItPvuuohnXxWFBnceYiImJHUtFBBM"), false, string("agsyudujSohViNSrIDPKBdsuwsXNGJNgtYbTzWomEKwApZMREsvZvUjrKFfnHsuDvYEHlPrMElpHClRuJlpIJdcskwPLSPzYLxmfeoZvzXIXqeijiVObAnrROUuRDOEdAamcqBIWxERpKqIOaApFiUBGVImRzkfWZErELP"));
    this->zGckTWnEFSI();
    this->edyEopEeTzIspHe();
    this->WXftjvKTjn(string("EsEarmGOSjnthYpycvSheCAGoIwn"), -721053.1471359842);
    this->VeOeVEymand(-582339.4080290523, string("dKVoLalRlSEDRMMFDB"));
    this->QbiMP(-249202485, -164218.6029734175, false, false);
    this->WzxwBvUjsGyoJDc(string("oLoLUStkVKJcZxjgsNdRPuJAoGEoSGTplDNFdgzpLIJZROMkpirQHWVUoXarolCwXOqg"), 780041972, -850568.2592463812, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kftdXarkgLuRA
{
public:
    int ziBQqJCQGBJd;

    kftdXarkgLuRA();
    string vcEHeqwVNvq();
    bool KZyXpmKKUDre(double BapovhxmZRvUpi, bool SmXypSTBx, string qLuZDpshUGpcFQK, double QWMSrMiXg);
    string rcRyKbbJfAwFOSE(bool LDaYqVUI);
    string oMETtiDlxi(string CVmMoFlrdya, int IUzDESwIUj, bool eJAxwKwnXJm);
    bool LPukeBn(bool lhfIzsAjIQrWvpSW, bool CsPzPBlbLHpLKolF, bool EsSsqRi, int akpCLLu, int TWfSmuWUcz);
protected:
    int royDZKMDLZgsu;
    bool QWWgIgGpV;

    double LbXJtTmamxp(bool JZReSELtFeTF, string rmeRWdorvf, bool WiNwcHxP);
private:
    bool QPDzHmYRjZiW;
    bool oFyKGRbCqz;
    int wtJxXeEcyprrFmAz;
    bool tHtOdOytSkmEjU;

    void oSADNcmZVNKvnexU(int QYoXoKgiVyoawJP, double DxrcRHMGsebJVOhM);
    bool kUOaRpgvhDFlKdS(int buAOfBbgboBEY, int xuwUa, string mfJRRe, int iMgLpNyBzrVBehl, bool VAVLzSeduKpaFgd);
    void GMXcyLWTR(bool DhKOdAP, string sveebyAGIptH, string QUAwAMlYRnMC);
    int MhNnDagdCX();
    void MBQsBNRBqDoGi(int BbTQezcAHjmn, int ykAzmTmcZGkdWEq);
    void JuCqjzAp();
};

string kftdXarkgLuRA::vcEHeqwVNvq()
{
    string taaXUQ = string("ZZnKpYqeKQpWoUO");
    int hjovNgFRMPKWIECo = 151607689;
    int dcfnRTsfGTTwQ = -1221798874;
    int pOFXcxilHnPWNLBP = -969696298;

    for (int lRbXxKqncU = 147736481; lRbXxKqncU > 0; lRbXxKqncU--) {
        pOFXcxilHnPWNLBP = pOFXcxilHnPWNLBP;
        pOFXcxilHnPWNLBP *= hjovNgFRMPKWIECo;
        hjovNgFRMPKWIECo = pOFXcxilHnPWNLBP;
        dcfnRTsfGTTwQ = pOFXcxilHnPWNLBP;
    }

    if (pOFXcxilHnPWNLBP < 151607689) {
        for (int dDaexzueLpKt = 1604773535; dDaexzueLpKt > 0; dDaexzueLpKt--) {
            dcfnRTsfGTTwQ /= hjovNgFRMPKWIECo;
            dcfnRTsfGTTwQ = pOFXcxilHnPWNLBP;
            hjovNgFRMPKWIECo -= pOFXcxilHnPWNLBP;
        }
    }

    if (hjovNgFRMPKWIECo < 151607689) {
        for (int wtwhAcYyjdvxO = 1822431454; wtwhAcYyjdvxO > 0; wtwhAcYyjdvxO--) {
            pOFXcxilHnPWNLBP += hjovNgFRMPKWIECo;
            pOFXcxilHnPWNLBP += dcfnRTsfGTTwQ;
            pOFXcxilHnPWNLBP /= hjovNgFRMPKWIECo;
            hjovNgFRMPKWIECo *= hjovNgFRMPKWIECo;
            hjovNgFRMPKWIECo /= pOFXcxilHnPWNLBP;
            pOFXcxilHnPWNLBP += hjovNgFRMPKWIECo;
        }
    }

    if (hjovNgFRMPKWIECo > 151607689) {
        for (int jAiGYss = 2133101166; jAiGYss > 0; jAiGYss--) {
            pOFXcxilHnPWNLBP -= pOFXcxilHnPWNLBP;
            hjovNgFRMPKWIECo *= hjovNgFRMPKWIECo;
            hjovNgFRMPKWIECo *= pOFXcxilHnPWNLBP;
            dcfnRTsfGTTwQ = hjovNgFRMPKWIECo;
            pOFXcxilHnPWNLBP = dcfnRTsfGTTwQ;
            hjovNgFRMPKWIECo += hjovNgFRMPKWIECo;
            dcfnRTsfGTTwQ = pOFXcxilHnPWNLBP;
        }
    }

    if (dcfnRTsfGTTwQ <= 151607689) {
        for (int zlmnzHvz = 1104777612; zlmnzHvz > 0; zlmnzHvz--) {
            hjovNgFRMPKWIECo *= dcfnRTsfGTTwQ;
            taaXUQ = taaXUQ;
            taaXUQ = taaXUQ;
            hjovNgFRMPKWIECo /= hjovNgFRMPKWIECo;
            dcfnRTsfGTTwQ *= hjovNgFRMPKWIECo;
            hjovNgFRMPKWIECo /= dcfnRTsfGTTwQ;
        }
    }

    return taaXUQ;
}

bool kftdXarkgLuRA::KZyXpmKKUDre(double BapovhxmZRvUpi, bool SmXypSTBx, string qLuZDpshUGpcFQK, double QWMSrMiXg)
{
    double sAducEOJqLx = -1012732.3562947995;
    bool EcBiEXUgHir = true;

    for (int NqfiilsvkEQty = 555038017; NqfiilsvkEQty > 0; NqfiilsvkEQty--) {
        continue;
    }

    if (SmXypSTBx != true) {
        for (int jiaWrxhe = 1730437652; jiaWrxhe > 0; jiaWrxhe--) {
            SmXypSTBx = ! EcBiEXUgHir;
        }
    }

    if (SmXypSTBx != true) {
        for (int xzDZqTlcP = 1459738182; xzDZqTlcP > 0; xzDZqTlcP--) {
            sAducEOJqLx -= BapovhxmZRvUpi;
            sAducEOJqLx /= BapovhxmZRvUpi;
        }
    }

    for (int WGSKfZOpN = 209287534; WGSKfZOpN > 0; WGSKfZOpN--) {
        SmXypSTBx = SmXypSTBx;
        BapovhxmZRvUpi += BapovhxmZRvUpi;
    }

    for (int zSWnAErMQpXPKZn = 84056864; zSWnAErMQpXPKZn > 0; zSWnAErMQpXPKZn--) {
        BapovhxmZRvUpi *= QWMSrMiXg;
        sAducEOJqLx += QWMSrMiXg;
        SmXypSTBx = EcBiEXUgHir;
        QWMSrMiXg /= QWMSrMiXg;
    }

    for (int bgWaTLZxaCnliAgY = 1757018376; bgWaTLZxaCnliAgY > 0; bgWaTLZxaCnliAgY--) {
        QWMSrMiXg /= QWMSrMiXg;
        sAducEOJqLx /= QWMSrMiXg;
    }

    return EcBiEXUgHir;
}

string kftdXarkgLuRA::rcRyKbbJfAwFOSE(bool LDaYqVUI)
{
    int yMPPEGOD = 1037248448;
    bool HVHwvkxYaF = true;
    bool vjCsJNfDdH = false;
    bool iOHYwbUeTgKqh = true;
    bool zkRITBTgOcUZKO = false;
    bool FxVJkWZlTLkO = false;
    string nMMSRlvtMUcRhK = string("rOMjDvvMJSJeGTqYxSjNFQJVTLTvQcRqvCnyXZZbgVlTcSwVRlfaaXutdJrASFihwhYUHndSYUDDoqmyPiwKVvu");

    for (int DSTTGg = 987555125; DSTTGg > 0; DSTTGg--) {
        vjCsJNfDdH = ! zkRITBTgOcUZKO;
        vjCsJNfDdH = zkRITBTgOcUZKO;
        iOHYwbUeTgKqh = iOHYwbUeTgKqh;
        HVHwvkxYaF = vjCsJNfDdH;
    }

    return nMMSRlvtMUcRhK;
}

string kftdXarkgLuRA::oMETtiDlxi(string CVmMoFlrdya, int IUzDESwIUj, bool eJAxwKwnXJm)
{
    string pVnVksxRxUeigU = string("eMEDHFHMuZAUTVpfHbGCqKvscXEQfzUMEpagwgRZFUJcUvELFBhddzbyOKxtPgpDJZKnPQlbnGfCwjQDpUrdFPPFqpPRUqoIxmMiApOGKHGdmKBUFgMoFQZzMYblkFoKzJMNcWrTisvvrkMDthQMgQLoZltZXZXjyUaQaiuaaRFqpppSsEdDfsBHcFWVTmknQeqyXN");
    int mxriIdMI = -681849842;
    double lkXAh = 37317.973956971146;
    string bEhbAOawIYFY = string("WFKKngzVGEwxfgFdnXiLoqbpuKybPDvRyIWliRLLUsOvzGQuSKkSHqfKzrgszMiHqPNOfQaApLnQKVlgoWOEHwnSxtxvMRjdbdEvMqMrOIeALbGbOzxrNHSsRNkVrsYmNRZUzqmMnsUoFMrkhEgBUoAZVkUPxYLqWmjKNEFfXBnDJSUaNIGdsPDdPPBqBIGNHAeXJlNVtAIBBdBQmdD");
    int hQCvgTaC = 1356470366;
    double KVMSSLENNkJ = 821507.361789704;
    string cdAfdJe = string("otrjzuGQQrsAKaUWcVYkMfGHCzlyrbjsUrGqpffuTBVOHGEG");
    bool WRAmPCRF = true;
    string oHJQZBZzdM = string("lJbbyfZBWxDoJUjFPupoOxjjhAaqkgdIEFBTQFfeXAjfkoyarmPSPzBEUXUvxEJWylOjishJviMtnSTyIUDbkOuPBvEdEKJhPIzNvTzLAkAOZDjKRKLYsrKNqzaeskRkfCVPIbYhLqRUnbgnEovSyCqiRTPuQIDuKdDd");
    string EqZbgAborjCo = string("XTqVMsvBAkfiJQPtknWwQkTjDZFeiyMnLtlLuYmKYTbArxPPP");

    for (int UqSKFMhXAXipZOK = 1886176319; UqSKFMhXAXipZOK > 0; UqSKFMhXAXipZOK--) {
        oHJQZBZzdM += CVmMoFlrdya;
        pVnVksxRxUeigU = cdAfdJe;
    }

    if (hQCvgTaC == 194114009) {
        for (int SUtvqW = 52593326; SUtvqW > 0; SUtvqW--) {
            cdAfdJe = pVnVksxRxUeigU;
        }
    }

    for (int JtbjHjXIDYRHDqY = 2061028828; JtbjHjXIDYRHDqY > 0; JtbjHjXIDYRHDqY--) {
        bEhbAOawIYFY = CVmMoFlrdya;
        oHJQZBZzdM = EqZbgAborjCo;
    }

    for (int EvarcslB = 629412218; EvarcslB > 0; EvarcslB--) {
        mxriIdMI += IUzDESwIUj;
        CVmMoFlrdya += CVmMoFlrdya;
        CVmMoFlrdya += pVnVksxRxUeigU;
    }

    return EqZbgAborjCo;
}

bool kftdXarkgLuRA::LPukeBn(bool lhfIzsAjIQrWvpSW, bool CsPzPBlbLHpLKolF, bool EsSsqRi, int akpCLLu, int TWfSmuWUcz)
{
    bool VlBVOAGxtQNdvO = true;

    for (int WDAfrStnCd = 181941918; WDAfrStnCd > 0; WDAfrStnCd--) {
        lhfIzsAjIQrWvpSW = CsPzPBlbLHpLKolF;
        VlBVOAGxtQNdvO = CsPzPBlbLHpLKolF;
    }

    if (VlBVOAGxtQNdvO == true) {
        for (int MRBxykVAlyXC = 1070903632; MRBxykVAlyXC > 0; MRBxykVAlyXC--) {
            lhfIzsAjIQrWvpSW = VlBVOAGxtQNdvO;
            VlBVOAGxtQNdvO = lhfIzsAjIQrWvpSW;
            CsPzPBlbLHpLKolF = CsPzPBlbLHpLKolF;
            lhfIzsAjIQrWvpSW = ! VlBVOAGxtQNdvO;
        }
    }

    if (EsSsqRi != false) {
        for (int nhRJsWgcMqc = 2043029416; nhRJsWgcMqc > 0; nhRJsWgcMqc--) {
            continue;
        }
    }

    for (int oizUBUz = 908260553; oizUBUz > 0; oizUBUz--) {
        VlBVOAGxtQNdvO = EsSsqRi;
        VlBVOAGxtQNdvO = VlBVOAGxtQNdvO;
        CsPzPBlbLHpLKolF = lhfIzsAjIQrWvpSW;
        TWfSmuWUcz *= akpCLLu;
        lhfIzsAjIQrWvpSW = ! CsPzPBlbLHpLKolF;
        TWfSmuWUcz *= TWfSmuWUcz;
        EsSsqRi = lhfIzsAjIQrWvpSW;
    }

    if (CsPzPBlbLHpLKolF != true) {
        for (int ZDPQMgXuLLpBpB = 704484705; ZDPQMgXuLLpBpB > 0; ZDPQMgXuLLpBpB--) {
            CsPzPBlbLHpLKolF = lhfIzsAjIQrWvpSW;
            CsPzPBlbLHpLKolF = ! VlBVOAGxtQNdvO;
        }
    }

    for (int YmaNTIBxbFbJfJpX = 306300; YmaNTIBxbFbJfJpX > 0; YmaNTIBxbFbJfJpX--) {
        lhfIzsAjIQrWvpSW = ! CsPzPBlbLHpLKolF;
        EsSsqRi = ! VlBVOAGxtQNdvO;
        lhfIzsAjIQrWvpSW = ! VlBVOAGxtQNdvO;
        EsSsqRi = ! CsPzPBlbLHpLKolF;
    }

    return VlBVOAGxtQNdvO;
}

double kftdXarkgLuRA::LbXJtTmamxp(bool JZReSELtFeTF, string rmeRWdorvf, bool WiNwcHxP)
{
    double oDLmNDga = -817715.8123859894;
    double iACLkGrotDUGDJi = -115647.01667014642;
    string zChnoCYlyXKL = string("vWQAhiSMiVHmLJXDwRSjdCiInLCoHCnwJHYIQSYaOnuMKyRXNcVgCYgGOIJETmdEaoVPXtDFvkwEnGBeHbgJbNmwQYcEhLbnEyZGFbuHsTAhmtpqizGgmHrwaUquzarGxubpNnpAaswEGOaH");
    bool pxVYwdyKG = true;
    bool cpqAMmwyfJakOq = true;
    bool XPFlIx = true;
    bool gjQzRapMjZFAc = true;

    for (int sBAuPqfUfH = 862292642; sBAuPqfUfH > 0; sBAuPqfUfH--) {
        iACLkGrotDUGDJi -= oDLmNDga;
        JZReSELtFeTF = WiNwcHxP;
        WiNwcHxP = gjQzRapMjZFAc;
        XPFlIx = pxVYwdyKG;
    }

    return iACLkGrotDUGDJi;
}

void kftdXarkgLuRA::oSADNcmZVNKvnexU(int QYoXoKgiVyoawJP, double DxrcRHMGsebJVOhM)
{
    string WJJSHQzubwP = string("YejY");
    bool qfGXqmBvOtognln = true;
    double kqaAPFRX = -636280.9181110342;
    string XbfZwI = string("VrTtjjoqRGIwOqLmlOCxeLvmDwttoQNzOeAMpNdGeKObHsNTnNsZkODDcNHrSYKQggyQVdqsKrYdZjSzYXwkSKELcEIGJVOzXBmIIoVHuGGCOfBZAAGwznSULTlFyRUoFBpMEAewvJXVpldYLdXKhxSkLZullpgcnGdbXziGxVyIiXtMDKkuAYFamkJkwmdkkwGETINhXJMJgiGIXvOzZlHNYmyhrdvgsFOikUwhwKg");
    bool WLDcPfUjvYbRa = true;
    double ztcVTsLUvjnPQS = -264572.254276172;
    int EBiFBqh = 1383644308;
    double FRCIhlloLImz = 245558.95935929863;
    double mYuUeLRkeh = -381481.99233430385;

    for (int aTCxnUGxgI = 524454319; aTCxnUGxgI > 0; aTCxnUGxgI--) {
        EBiFBqh /= QYoXoKgiVyoawJP;
        mYuUeLRkeh /= ztcVTsLUvjnPQS;
    }

    for (int paaMDdwVjPl = 519829148; paaMDdwVjPl > 0; paaMDdwVjPl--) {
        EBiFBqh += EBiFBqh;
    }

    for (int QNXHybkz = 302057514; QNXHybkz > 0; QNXHybkz--) {
        DxrcRHMGsebJVOhM += DxrcRHMGsebJVOhM;
        kqaAPFRX -= mYuUeLRkeh;
    }

    if (XbfZwI >= string("VrTtjjoqRGIwOqLmlOCxeLvmDwttoQNzOeAMpNdGeKObHsNTnNsZkODDcNHrSYKQggyQVdqsKrYdZjSzYXwkSKELcEIGJVOzXBmIIoVHuGGCOfBZAAGwznSULTlFyRUoFBpMEAewvJXVpldYLdXKhxSkLZullpgcnGdbXziGxVyIiXtMDKkuAYFamkJkwmdkkwGETINhXJMJgiGIXvOzZlHNYmyhrdvgsFOikUwhwKg")) {
        for (int xypFCs = 400166719; xypFCs > 0; xypFCs--) {
            continue;
        }
    }

    for (int bokAIWiszShzjF = 1063567756; bokAIWiszShzjF > 0; bokAIWiszShzjF--) {
        FRCIhlloLImz /= mYuUeLRkeh;
    }

    if (FRCIhlloLImz == -108939.0584370769) {
        for (int BYUrxoxeSDOCbK = 1086039682; BYUrxoxeSDOCbK > 0; BYUrxoxeSDOCbK--) {
            kqaAPFRX *= DxrcRHMGsebJVOhM;
        }
    }
}

bool kftdXarkgLuRA::kUOaRpgvhDFlKdS(int buAOfBbgboBEY, int xuwUa, string mfJRRe, int iMgLpNyBzrVBehl, bool VAVLzSeduKpaFgd)
{
    double hzmVdfyoYtkmVfi = 94306.36562265974;
    int xYplo = -1532371844;
    double dYepe = -129925.6792301702;
    bool PiDbpMFyxHpn = true;
    string MNFtmalPktNlLNgl = string("DJZi");
    int ulsvodU = -1164125394;
    int BpYMnenmoEHGFZNg = -2024885970;

    for (int duNqoJRthjyEn = 1346896957; duNqoJRthjyEn > 0; duNqoJRthjyEn--) {
        mfJRRe += mfJRRe;
    }

    for (int oKgymDAxxe = 1826483818; oKgymDAxxe > 0; oKgymDAxxe--) {
        continue;
    }

    return PiDbpMFyxHpn;
}

void kftdXarkgLuRA::GMXcyLWTR(bool DhKOdAP, string sveebyAGIptH, string QUAwAMlYRnMC)
{
    string RgUIbYB = string("OZNeRxbpIPduuYOAWjHfkrUOkvHdvMvlslHdxsyGEEOYATVaRLBPbirzmfApfUyezjzDxYkVdICwSnfdWSHShgjOFzbQOfdNycxsxYAdNQhGkxGnCQwEawCpLMHOMwiDkeiulkgKZmgFiXMjbmIRRMymQshPrgYdix");
    int ObBLgKHpHwHwh = -267466388;
    int BYMkPpcsvUrfP = 306783366;
}

int kftdXarkgLuRA::MhNnDagdCX()
{
    string bMAVd = string("zNKIpuFJmYbqllUNtCDMGWLMNwpswokJQDmweRRAZgKKKErwoEqRZsfXurLSieujfhQJBpkjubzQqVMVwVCFNQErotDJcaaezhWFGmHD");
    string LKOmYHI = string("PvtSEponaQUikVZLWKKbDASSlAWlKTVRMRFLjcmgmyTpYESqBAJsLURVoUqKARzfqfwrExmofVvWlTjesfsoGlyHCNyOeFMOCKnZSqZRpDLgMZkXJHQtzewJoAXKfCqkBsqDeDjFpRmkkPoum");
    bool NPCLlilIJaYAvRj = false;

    if (LKOmYHI > string("zNKIpuFJmYbqllUNtCDMGWLMNwpswokJQDmweRRAZgKKKErwoEqRZsfXurLSieujfhQJBpkjubzQqVMVwVCFNQErotDJcaaezhWFGmHD")) {
        for (int sfHQlvfgBiAZ = 181827648; sfHQlvfgBiAZ > 0; sfHQlvfgBiAZ--) {
            LKOmYHI = bMAVd;
            bMAVd += bMAVd;
            bMAVd = LKOmYHI;
            LKOmYHI = LKOmYHI;
            bMAVd = bMAVd;
            LKOmYHI += bMAVd;
        }
    }

    return 547162250;
}

void kftdXarkgLuRA::MBQsBNRBqDoGi(int BbTQezcAHjmn, int ykAzmTmcZGkdWEq)
{
    bool OREsNkr = true;
    double bjvcYGzPBAGaFMm = 1038641.968792031;
    double swRAvqtFiNRjRf = 144471.61665040388;
    bool MCTLwjLIvFI = true;
    string EivUPlv = string("qwXJOtXDCeYoHjGbBgGIJUWdDXIzliBXhsptlGMLaUSQUUAsSYWHIzbskBNecAxZsfQUGSZvMg");
    string NCohuYQ = string("wXZXUuLyVygtwNIDcHtUxeZrVJkuMDnwAtGTySwqcvyIysnRgxROnvDeinxshXpdDZrWSWfkJoroRmnvtWaNCknYRAGqnKLrnDUvsmcjGlPmQUoWMrDvwFnoasdQVyCxGjbCkAACcHSjvcZqaUPMjOQULAuAHEBBRSrvgCUHHVfDwNxtgJJXIxjWO");
    bool pJHqM = true;

    for (int ZBVUMaoqSrkRi = 1011451814; ZBVUMaoqSrkRi > 0; ZBVUMaoqSrkRi--) {
        continue;
    }

    if (BbTQezcAHjmn == 1292422833) {
        for (int YUJyAQpf = 615341290; YUJyAQpf > 0; YUJyAQpf--) {
            bjvcYGzPBAGaFMm *= swRAvqtFiNRjRf;
        }
    }

    for (int XrWrjFBpXeEXFAnH = 1923734823; XrWrjFBpXeEXFAnH > 0; XrWrjFBpXeEXFAnH--) {
        continue;
    }
}

void kftdXarkgLuRA::JuCqjzAp()
{
    bool bLaWWwpfDlwPF = false;
    string IPTYYcVdhafcw = string("oMorWYTdnJIOkhLsgAlRysHGcVVOzvwywkIsgoJRECFyGIQZRMlVrcPsUcdpukfahhDWAOwPSe");
    string UlrvFglbJiM = string("omcrvyLyTJuzScbsGsPkkXiBXktZxUzkomGDXMscKueApFlLMsdlHhWqfJkLAnjREOdByEzzwsjyqUStJCIMsOVzPSUMReGxJcbzfRKnmSnNoPHgZhDNlBACqTHipsOPBmhyJCPBdBJJfDACUFTfsqaFfsrYXuyMlPemChkgbjkPxHgpEFjmprxAWbWHwFvaLcnERPtcGPpunPpmLqLoEuRSZzsXbDGjhdoQxfWPsrFBunYoUlckil");

    if (UlrvFglbJiM >= string("oMorWYTdnJIOkhLsgAlRysHGcVVOzvwywkIsgoJRECFyGIQZRMlVrcPsUcdpukfahhDWAOwPSe")) {
        for (int ySpnHICatb = 1754756946; ySpnHICatb > 0; ySpnHICatb--) {
            bLaWWwpfDlwPF = bLaWWwpfDlwPF;
            IPTYYcVdhafcw = IPTYYcVdhafcw;
            IPTYYcVdhafcw = UlrvFglbJiM;
            bLaWWwpfDlwPF = bLaWWwpfDlwPF;
        }
    }

    for (int qaktp = 448931027; qaktp > 0; qaktp--) {
        bLaWWwpfDlwPF = ! bLaWWwpfDlwPF;
    }
}

kftdXarkgLuRA::kftdXarkgLuRA()
{
    this->vcEHeqwVNvq();
    this->KZyXpmKKUDre(-416676.4162060586, true, string("lNsoaofltzBnJLuGVtGSYiwNpLUtNJUMyHkUABcgKKvyuBTOewoTqaYpsRDRTpqRdlZMqutBhXJdUNFwslHKDwhCvmSlXpkNwVDOTRHbnxlDXzNeDuQnOrmFBuiQVxAFNNQQmeRRDETzkLutwOzNESBprrTdtvNVLjbMrpsCboUndpYHjagXsPUdpUvMQBZWzYzgSvnFWUFYppcR"), -249746.21631567777);
    this->rcRyKbbJfAwFOSE(true);
    this->oMETtiDlxi(string("QATuxjChcVgYaeeYZCkGeRCQOKkdvYHmpROtSFAXaNzEKWZPAxoiIpeDNKlFwXFFHDyyyEwZsLHgEcYKFIBwTiYAZrZngXQFhIralffQyKJnRMWQWOwrZCaNlPcrjqHMZPqSbBDslfLhihTrfSLNjwfUraVafMwtxLIoEpdrclpxuydTPmOyPYlYyRkEEst"), 194114009, true);
    this->LPukeBn(false, false, true, 390641354, 1648381423);
    this->LbXJtTmamxp(true, string("vqRxNZLnHOCgeZHOVLPiIIIfqbQFKOfZFjIuyCzDNwERhDGPMHbhCPGRBKNUVmJcPgUKiokwlvIwAWldVjWrlgSkdqENIugEwRiVXlfDAlzfeQDctrYGJXHkAozDyyixwodWHsydBLWrvCVcttudHwkFonYauoAzXykUUByEBW"), true);
    this->oSADNcmZVNKvnexU(-346174470, -108939.0584370769);
    this->kUOaRpgvhDFlKdS(-486668760, -1753492256, string("mwXYGKdcLKGTLeckfUAJ"), 852819426, true);
    this->GMXcyLWTR(true, string("GLYXQEIuzuwOYgkEnQsuXLbQJLbWQfQQLAlfUquEteTInGMiaIbBDNTTnRRdQ"), string("VcMvySqIysDluQsGXByfmKvZcnJNHOHkLlEoySonLkJVRucqNkBJVRWWaLVoNbmWwCFXXLbwMHMrODwecyfqwEzHjjyRv"));
    this->MhNnDagdCX();
    this->MBQsBNRBqDoGi(1292422833, 1918444100);
    this->JuCqjzAp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Lurrz
{
public:
    int eWYCrqYpCZj;

    Lurrz();
    void FNxIrWU(string YNfDvT, double ndJsNkECZT, bool HkEPjHFG, bool zvoxKlJ, int mbwagIrYTkS);
    bool HOzGIUXh(double jLirUAXiOBjakTyM, int lhjSg, double MvROYc, bool DrXWxshmgfHRVG);
protected:
    bool kmoeeJNUrksbjEFV;
    int FNPMjqJjuql;
    bool yYKvhjg;

private:
    string YInYoIFfqk;
    string fijmTPdjNsXwhJZ;
    string VhtDpnoyc;
    bool DFPUq;
    bool zCUyncZAzNahF;

    string IWnlKSFZSv(double favejqyhdziwSfFH);
    double brtkp(bool fxiSapTdamF);
    string UedOjtNZ(bool kGqbsjdbADX, double uDITOltJbLa, bool WtkapTnXkMMhajH, bool IGvdqFjZzAv, string ZuWfNW);
    string DAXMQS(string uGVoN, string lTtoXFipUkPsL, bool aYNIYRjKjP);
    string pfcmZUllxZ();
    double RDVgBP(string wvvogpDkPqeDvCuf, bool VeozcGlyOwxpIIVU);
};

void Lurrz::FNxIrWU(string YNfDvT, double ndJsNkECZT, bool HkEPjHFG, bool zvoxKlJ, int mbwagIrYTkS)
{
    bool IWoLwgcsZCwbiYhD = true;
    int HqOjXPUHnSLPATRZ = 480660340;
    string pLZGaLSbhjqNwFP = string("TPGfmXWGVgogFqyBDeOmbEnYHZfPgiXJGrMMDzcvhmhboopUFdhLDrbynrlbLlkHyZPPWTqrUclVbhrvVFZYtnrqoRKwxMWUxHlpbZwwQkhXOH");
    int uGHUjJBTKMmTuGm = -287502618;
    bool Nvzosz = true;
    bool gEgREzetyBsBFaZ = false;
    string XDofx = string("RBsFqRHogSdCAfpmfVqSHrwcVTVgrVfruKmKlIwgGyKnoRPdhXlhKvrtsanCUgZtxtQGOZZqChtJRheYdQrEDkFtcfoPKZDePhBQxukPxAErMoTNFXDjkprPFcEoBVcjODqKrhtwyoECdlaAkxBHWMAQejIKdnwMqtqXEfiyvstnMMcZPLgcCDcpkRiZFqGnXWrhauWYhHwSzPuj");
    int LUiEHIREWgWkOMeH = -1732057139;
    int dLEEIX = -2113776667;
    bool htHidszzV = true;

    for (int WYsxKiwUTk = 1017236542; WYsxKiwUTk > 0; WYsxKiwUTk--) {
        YNfDvT = pLZGaLSbhjqNwFP;
        Nvzosz = HkEPjHFG;
    }
}

bool Lurrz::HOzGIUXh(double jLirUAXiOBjakTyM, int lhjSg, double MvROYc, bool DrXWxshmgfHRVG)
{
    int RFNRACKyleVII = 1659036654;
    double mCLHRBH = -907351.6407206153;
    int XLTeFNOlr = -675382933;
    bool fHhbf = true;
    double iTRhXwVHiRuee = -264065.05373374023;
    string BerCKVKCFwxr = string("wBgB");
    double zdDPdmudhqBXLE = 70059.08195082707;
    double JpxdNFphVFFJrq = 439363.04736546613;

    for (int scHFh = 1667080949; scHFh > 0; scHFh--) {
        JpxdNFphVFFJrq += iTRhXwVHiRuee;
    }

    if (mCLHRBH < -264065.05373374023) {
        for (int CAAWY = 1057626221; CAAWY > 0; CAAWY--) {
            jLirUAXiOBjakTyM = mCLHRBH;
        }
    }

    return fHhbf;
}

string Lurrz::IWnlKSFZSv(double favejqyhdziwSfFH)
{
    int pRFczuqzYpo = 110546679;

    for (int yYijCBtRaNtbXhTh = 1225315384; yYijCBtRaNtbXhTh > 0; yYijCBtRaNtbXhTh--) {
        pRFczuqzYpo /= pRFczuqzYpo;
        favejqyhdziwSfFH += favejqyhdziwSfFH;
        favejqyhdziwSfFH += favejqyhdziwSfFH;
        favejqyhdziwSfFH = favejqyhdziwSfFH;
        favejqyhdziwSfFH = favejqyhdziwSfFH;
    }

    if (favejqyhdziwSfFH >= -570254.2163990412) {
        for (int Gxcrjra = 1302643011; Gxcrjra > 0; Gxcrjra--) {
            favejqyhdziwSfFH = favejqyhdziwSfFH;
            pRFczuqzYpo -= pRFczuqzYpo;
            favejqyhdziwSfFH += favejqyhdziwSfFH;
        }
    }

    if (favejqyhdziwSfFH == -570254.2163990412) {
        for (int znZPU = 917567757; znZPU > 0; znZPU--) {
            continue;
        }
    }

    if (pRFczuqzYpo != 110546679) {
        for (int aeXYCZ = 254484411; aeXYCZ > 0; aeXYCZ--) {
            pRFczuqzYpo /= pRFczuqzYpo;
            favejqyhdziwSfFH /= favejqyhdziwSfFH;
            favejqyhdziwSfFH += favejqyhdziwSfFH;
        }
    }

    if (favejqyhdziwSfFH >= -570254.2163990412) {
        for (int jpfMEPNIahIGHdv = 1766457716; jpfMEPNIahIGHdv > 0; jpfMEPNIahIGHdv--) {
            favejqyhdziwSfFH /= favejqyhdziwSfFH;
        }
    }

    return string("szAcfnxNvvpAQrZkkBZPZAHXMdcpMqcesAvndhasQmoOptMiRumRMSodOmAgNPVZJWLTHyCCQbFdgSamIwLNn");
}

double Lurrz::brtkp(bool fxiSapTdamF)
{
    string RUecidFdq = string("fLbFLOzGVZaXWxdyQDSCFrhLAXgBpNevPmBLgMcbObkhCUrFJoTIFTQeAlSemuHfVMsDxvrbFddfsHAiCceDuu");
    double ljSfHjkvEDIbTD = -73457.0101987951;
    int dAeAlSEtMML = 1545262256;
    string floZFuYXCVsJY = string("SaPgCCFGGXWbfHBpNhkiQVFizAQfsmrjuSHETMhTkfPbVApJEzvrgIDHTkJgtpCaPOUOjsLfJZyFZTngjSPWfDLvcidMHVEtWPhNVobjMqImlOZKonBUlTcnABmSjymEYOVeEpcUinVUexcSowiceRARUXPfEWZmyVEKjOloEjegqyAwjZHAquVXDVnqMIB");

    for (int YrhFUZwuIY = 396456282; YrhFUZwuIY > 0; YrhFUZwuIY--) {
        floZFuYXCVsJY = floZFuYXCVsJY;
    }

    for (int lLdiFRzUXDBOZasz = 738497832; lLdiFRzUXDBOZasz > 0; lLdiFRzUXDBOZasz--) {
        ljSfHjkvEDIbTD += ljSfHjkvEDIbTD;
    }

    if (floZFuYXCVsJY < string("SaPgCCFGGXWbfHBpNhkiQVFizAQfsmrjuSHETMhTkfPbVApJEzvrgIDHTkJgtpCaPOUOjsLfJZyFZTngjSPWfDLvcidMHVEtWPhNVobjMqImlOZKonBUlTcnABmSjymEYOVeEpcUinVUexcSowiceRARUXPfEWZmyVEKjOloEjegqyAwjZHAquVXDVnqMIB")) {
        for (int luKEokIYxqpcMY = 625214919; luKEokIYxqpcMY > 0; luKEokIYxqpcMY--) {
            continue;
        }
    }

    return ljSfHjkvEDIbTD;
}

string Lurrz::UedOjtNZ(bool kGqbsjdbADX, double uDITOltJbLa, bool WtkapTnXkMMhajH, bool IGvdqFjZzAv, string ZuWfNW)
{
    bool jwrLLuZFHndtuve = true;
    int MkShxsPITlt = 1924475261;
    bool tyInBOJGrhZ = true;
    int EHGCHpbihrZqZ = -918246655;

    if (WtkapTnXkMMhajH == false) {
        for (int KwxvfgxRfjz = 415783283; KwxvfgxRfjz > 0; KwxvfgxRfjz--) {
            tyInBOJGrhZ = ! WtkapTnXkMMhajH;
            IGvdqFjZzAv = ! tyInBOJGrhZ;
            jwrLLuZFHndtuve = ! tyInBOJGrhZ;
            WtkapTnXkMMhajH = ! tyInBOJGrhZ;
        }
    }

    for (int qInvnFBbfShA = 1483884598; qInvnFBbfShA > 0; qInvnFBbfShA--) {
        EHGCHpbihrZqZ += EHGCHpbihrZqZ;
    }

    for (int UXAygmDcVgefaynC = 19922084; UXAygmDcVgefaynC > 0; UXAygmDcVgefaynC--) {
        jwrLLuZFHndtuve = ! tyInBOJGrhZ;
        IGvdqFjZzAv = WtkapTnXkMMhajH;
    }

    if (jwrLLuZFHndtuve == true) {
        for (int OSgkpGJZjCAcQOiT = 1218014464; OSgkpGJZjCAcQOiT > 0; OSgkpGJZjCAcQOiT--) {
            jwrLLuZFHndtuve = ! tyInBOJGrhZ;
            WtkapTnXkMMhajH = kGqbsjdbADX;
            WtkapTnXkMMhajH = ! IGvdqFjZzAv;
            WtkapTnXkMMhajH = ! WtkapTnXkMMhajH;
            IGvdqFjZzAv = ! jwrLLuZFHndtuve;
        }
    }

    return ZuWfNW;
}

string Lurrz::DAXMQS(string uGVoN, string lTtoXFipUkPsL, bool aYNIYRjKjP)
{
    string DwpCQPubkwBKDrP = string("uxTDFzSBdUvViDPgIcRytfrrPwPRBlUXrDyzfUWYFrgOuMZbRQmxtaQsLgmJLUnxghKkOBsSvcGAMTTNbaOdMVuIKXedwLdmcRxjjqXzLSbyIJKyiSwmRrJDRjvLmzigUzmDPLJBQYuMrFAZVGeuFXocfauKjfnPHTgFVACxlxBQlJfUFqMPxTHOhPXRRFHHjVlZXfeEwicoVBIEDHkbCEaqIGuClQ");
    int iNNUJMWws = -2076961606;
    double MfgtQfyknsazBd = -921174.1226245535;
    double MRazfmXf = -729976.9069542338;
    bool ajLdUa = true;

    if (aYNIYRjKjP == true) {
        for (int iHcOWcRp = 147287520; iHcOWcRp > 0; iHcOWcRp--) {
            aYNIYRjKjP = aYNIYRjKjP;
        }
    }

    for (int EMPePrNZgDpJqbH = 1657893792; EMPePrNZgDpJqbH > 0; EMPePrNZgDpJqbH--) {
        continue;
    }

    for (int rKpzChsOqMEUFIM = 1932681870; rKpzChsOqMEUFIM > 0; rKpzChsOqMEUFIM--) {
        continue;
    }

    for (int RPTLnJqtWDzHj = 1859661682; RPTLnJqtWDzHj > 0; RPTLnJqtWDzHj--) {
        continue;
    }

    return DwpCQPubkwBKDrP;
}

string Lurrz::pfcmZUllxZ()
{
    string oIbyEEoqMBQdK = string("KNxSLIRUTIVuzYpoMZPqelsEzQDCJtEvYbHJRxthtsTIyEWWYfFHPgJnpYERCzumVvMYbfyxiHSwjyKfDNvewjsZyIXnJMpUGwsnIAZaTrpGhZobVNeWjQNaUmfYasYmGYfi");
    string qRRhELWp = string("jajeVNptOsDikaGwzQlZesiGAmgCREjBAJubNvjPSiEisYKCfPyRYsBlEOktDItzQiISENUdqcGkukSOljgAAzDVGqZCOooYGWvqIoMPecRzbkDMydGcZFQhumTnWmOZHmyKsaQDKmYjnidpOOzEArEoofLaMYErsqqmBTjpcyqZgYnOwUvGfHWxwtstpIcwfbbLTMiNXZUPGLvDGqstSIFieduxGVcZEVOjqaDCpaitHI");
    double jhDDiy = -842241.5164848227;
    int uintg = -232717963;
    int aVvzJli = -1719004584;
    string jPuoJdAKTlGW = string("gQkjrfGAmnMOymGimvpSwONTDxtTFcOwMTEpYyvKSVKWABDOKumWlRjusJMZjlMAkmjzEvtEtHpYVsLLnchPZiKUcZlxLlCuqCrNGvqLtbauEaAzWfpwwIuchBkRDYuwoCOMHIBHxyLhwrpGG");
    string TsnovmAXYu = string("MMR");
    string TMcosTNYpn = string("KjKlgSCKoJNjkMbRjIlATMxCdbtDHnFttBmNLnZjpAobAqbHmbcQHROqEVIawNiPnvMNrEVexOiQgyTllRwBagTEaDwLhsZJihHEmMnKnbluhYeYtxAtxwrhweKBadWwfIoDqucARnOUDSOgidBQzfaly");
    bool JatELYIVjp = true;
    double aXezQQt = 681702.2735599707;

    for (int ACQWrOYnc = 372069433; ACQWrOYnc > 0; ACQWrOYnc--) {
        jPuoJdAKTlGW += jPuoJdAKTlGW;
        jPuoJdAKTlGW = oIbyEEoqMBQdK;
    }

    for (int YnfjNtrmM = 517412284; YnfjNtrmM > 0; YnfjNtrmM--) {
        TsnovmAXYu = TsnovmAXYu;
    }

    return TMcosTNYpn;
}

double Lurrz::RDVgBP(string wvvogpDkPqeDvCuf, bool VeozcGlyOwxpIIVU)
{
    int UfKUrOgRKGiEKCK = -2350232;
    int LZfcMJmYh = 1478951004;
    bool YAfOlQsyZUNh = false;

    if (YAfOlQsyZUNh != false) {
        for (int WsMOJFpMirCgJZMP = 895109859; WsMOJFpMirCgJZMP > 0; WsMOJFpMirCgJZMP--) {
            UfKUrOgRKGiEKCK *= UfKUrOgRKGiEKCK;
            YAfOlQsyZUNh = ! VeozcGlyOwxpIIVU;
        }
    }

    for (int mAIYOHaDiWk = 1502159088; mAIYOHaDiWk > 0; mAIYOHaDiWk--) {
        LZfcMJmYh -= LZfcMJmYh;
        YAfOlQsyZUNh = ! YAfOlQsyZUNh;
        VeozcGlyOwxpIIVU = ! YAfOlQsyZUNh;
    }

    if (UfKUrOgRKGiEKCK <= -2350232) {
        for (int thXGktXhTxVkvWA = 599004615; thXGktXhTxVkvWA > 0; thXGktXhTxVkvWA--) {
            wvvogpDkPqeDvCuf = wvvogpDkPqeDvCuf;
        }
    }

    if (VeozcGlyOwxpIIVU == false) {
        for (int HYwMpCxnIcLk = 761606442; HYwMpCxnIcLk > 0; HYwMpCxnIcLk--) {
            wvvogpDkPqeDvCuf = wvvogpDkPqeDvCuf;
            UfKUrOgRKGiEKCK -= LZfcMJmYh;
        }
    }

    return 206182.92750949124;
}

Lurrz::Lurrz()
{
    this->FNxIrWU(string("oJVTEbhBCCtIMGQrMZFNjFyvpdrFcHjkEVZxWoKRPhVJVblGSICVfpXSFLmUbqQHeDalQZAHoYPTPnnnWeYtjbAQLuwMqnuqiDVCbczRIpldiiMdLowMwfSYfLQeQLYjXuOWHBuNUpAETGxiVlgEApkCQybyV"), -818877.4753442905, false, false, -1409802196);
    this->HOzGIUXh(555750.5605136771, -1094864864, 755614.6445425048, false);
    this->IWnlKSFZSv(-570254.2163990412);
    this->brtkp(true);
    this->UedOjtNZ(true, -996165.4188093507, false, true, string("sHIrIapqOqbiAwCyzfpRQZKzwgbKAjjJgQRplJuYYUGMtDBCYzLtwwAAPuKJfRLYgjLgihbRHvVkayHJKBwSzeQHpIEaiHIanVBzcXWxogTGDzuDoX"));
    this->DAXMQS(string("GVjDOGlhrCnEfIpRsSLxNbFXNumGTJKmXcTISYiDJxHnnTRcGFJMXPukGQvdUDKjVYtuvfZUhxDutinBzuQpbmtxtFESCUMWdOdcwNTHeCabtRAHQhAIcWkXFTiKbVmiKjgiqzWwqLiBAhXiOedFCNGsCAQwtxQdlB"), string("aRbwjYWqy"), false);
    this->pfcmZUllxZ();
    this->RDVgBP(string("UXhemoOJxrWKkhculwCYTvbG"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZXGcH
{
public:
    string LzLoegU;

    ZXGcH();
    void MvffySkvahIJ(string FGcrydA, string LMpIOS, double hLqLJoddOZAwt, double bRwnMGVbCcpNP);
protected:
    int PaiSqjrRFFbJBgRH;

    double zaZeLYIteTdKAu(bool llLgKoww);
    bool xzHtGF(int niNegWAatV, double RXebqN, bool yQziXQ, bool KmvEOYkChPHZa);
    void fZimA(string xYpFdtTFlqaWfyn, double zSwdy);
    void LPyFNh(double jpAfRgIMz, int VAmMEykAW, double luBHVXQU);
private:
    double wZJFADQYsMsgFR;
    double cBodU;
    bool UUUTZuOnjCDH;
    string NBEkTcuRzmpsUofV;
    bool AGJmoyigAWZZT;
    int xRfzEjXTjWZgba;

    void ESjdvCdm(string WiHefUBdLTJZr, bool IpBYmnAAzPHRvGT, bool WMVCTEYvFg, bool GDXeKebQ, int ozTdggYwj);
    string IlwHZtuGwKASwqG(bool OpkWlxiSUNPFdfk, double llMdifwfnuhU, double iRWrDNUropScaWjW, int otUABmcsDKlcu, string rJJJUGrcmm);
    bool KPcPqqWsqUcHyQCY(int uWWyIkvLOpMlE, double fkfHcNEelza);
};

void ZXGcH::MvffySkvahIJ(string FGcrydA, string LMpIOS, double hLqLJoddOZAwt, double bRwnMGVbCcpNP)
{
    int VJiXDNPdYN = 432112566;
    string vXuCQCy = string("WhxgAlpxiNgjjGsKEiJCWowMbaPMjQsYUkLselVtggUbzrlnejmvKHGvdOxfUlNwvhHNWdPNFhrVDiMeTuGgRVeTgDzrmKUJOfNHUuablIeHpNaWkMNxPCaRjwTGGJSAEJjsWsUkTbNPDRVAGAIAxdbZWgYtPsZPUcfwAoSR");
    int aUKTAiDtzw = 282030318;
    string kNkTpCNud = string("EjhGNVIhDLPusPPHRIvewHDLMKquNEnPxCbHZHaAjnxxjmWmlNYrFCrbnHbMxFVhWuAUaSUkWfKbymwxZkfApeQwlidfmWulGJVkSxlMuiMjmpBSmGNrVQsEnqpKESkZVpyCdWhSLbpWcQXq");
    bool BEKvElRepa = true;
    int HeWpLCPcLp = 107341278;
    double KmUWVMKDVxrAvD = -511501.0955786312;
    int hZaxpD = -1978036603;

    for (int oGLmgaUeCxSvwGSO = 1818328825; oGLmgaUeCxSvwGSO > 0; oGLmgaUeCxSvwGSO--) {
        VJiXDNPdYN -= VJiXDNPdYN;
        FGcrydA = FGcrydA;
        hZaxpD /= aUKTAiDtzw;
    }
}

double ZXGcH::zaZeLYIteTdKAu(bool llLgKoww)
{
    int IAXooWaiFDEZGFz = 1917106507;
    double PHFxhzePKcdusF = -239505.5430188555;

    for (int PGCzJflr = 198340124; PGCzJflr > 0; PGCzJflr--) {
        PHFxhzePKcdusF /= PHFxhzePKcdusF;
        llLgKoww = ! llLgKoww;
        IAXooWaiFDEZGFz += IAXooWaiFDEZGFz;
        PHFxhzePKcdusF *= PHFxhzePKcdusF;
    }

    if (IAXooWaiFDEZGFz <= 1917106507) {
        for (int VlUIqghnkPRu = 694470180; VlUIqghnkPRu > 0; VlUIqghnkPRu--) {
            PHFxhzePKcdusF += PHFxhzePKcdusF;
        }
    }

    for (int ROpmRQK = 998080457; ROpmRQK > 0; ROpmRQK--) {
        PHFxhzePKcdusF -= PHFxhzePKcdusF;
        PHFxhzePKcdusF = PHFxhzePKcdusF;
        llLgKoww = llLgKoww;
        llLgKoww = ! llLgKoww;
        PHFxhzePKcdusF *= PHFxhzePKcdusF;
    }

    return PHFxhzePKcdusF;
}

bool ZXGcH::xzHtGF(int niNegWAatV, double RXebqN, bool yQziXQ, bool KmvEOYkChPHZa)
{
    bool MSyjtdURAy = true;

    for (int oNARvXmaa = 467250242; oNARvXmaa > 0; oNARvXmaa--) {
        niNegWAatV -= niNegWAatV;
        MSyjtdURAy = ! yQziXQ;
    }

    if (MSyjtdURAy != false) {
        for (int OMRzoYIajSY = 1391146490; OMRzoYIajSY > 0; OMRzoYIajSY--) {
            yQziXQ = ! KmvEOYkChPHZa;
            KmvEOYkChPHZa = ! KmvEOYkChPHZa;
            MSyjtdURAy = ! MSyjtdURAy;
        }
    }

    return MSyjtdURAy;
}

void ZXGcH::fZimA(string xYpFdtTFlqaWfyn, double zSwdy)
{
    double wGfhjxQcmaaA = 529763.7830472054;
    double zBDzDBtGY = 638116.2572386939;
    double JTvtjrR = -94592.22240036722;

    for (int idoRqhe = 975373391; idoRqhe > 0; idoRqhe--) {
        JTvtjrR += JTvtjrR;
    }

    for (int ADEXlkJPBKnGPAB = 1603001645; ADEXlkJPBKnGPAB > 0; ADEXlkJPBKnGPAB--) {
        zBDzDBtGY -= JTvtjrR;
        wGfhjxQcmaaA += wGfhjxQcmaaA;
    }
}

void ZXGcH::LPyFNh(double jpAfRgIMz, int VAmMEykAW, double luBHVXQU)
{
    bool fmtvOVaMIGsoOvve = true;
    bool LMrKGVeKdcTkCR = true;
    string FKaCKYBfMK = string("atUPbcycWrTkToIYuAcAjksyKdfbqXxDrPTDskrvZbCmajAfOxsxDArSjgKPIAfLsCJYwKKcuQYsRvTThKCVUbGfPxQflhoxVMfrKHvtRRiokkNRTcNOqAyDthq");
    int cIZsDDLt = -759719010;
    string RrrLByzVyCfi = string("MApqCMWGAuziiZDbwUbnBbRlOUnyGtLZdjxHELBKerWzUoitztzIZGxCjCUWIBsWtDxcmzXUWjOBXUyWpdNsAUJYAVUOgaSuSeaVX");
    int WCDiyBmm = -578373728;

    for (int iKOrEYcfzQ = 1883577055; iKOrEYcfzQ > 0; iKOrEYcfzQ--) {
        FKaCKYBfMK = RrrLByzVyCfi;
    }

    for (int yRFzWZicJxo = 1539477384; yRFzWZicJxo > 0; yRFzWZicJxo--) {
        FKaCKYBfMK = FKaCKYBfMK;
    }
}

void ZXGcH::ESjdvCdm(string WiHefUBdLTJZr, bool IpBYmnAAzPHRvGT, bool WMVCTEYvFg, bool GDXeKebQ, int ozTdggYwj)
{
    bool fqUDoXoD = true;
    bool IniTEVJzXSzEWTn = false;
    bool ALYTq = true;
    bool xtbjVpgTtExJiRDT = true;
    bool oKRRChZVcvRYhuOy = false;

    for (int ZSEPvQuDtAhmZZ = 2046060080; ZSEPvQuDtAhmZZ > 0; ZSEPvQuDtAhmZZ--) {
        GDXeKebQ = ! xtbjVpgTtExJiRDT;
        ozTdggYwj += ozTdggYwj;
        xtbjVpgTtExJiRDT = ! oKRRChZVcvRYhuOy;
        oKRRChZVcvRYhuOy = ! fqUDoXoD;
        oKRRChZVcvRYhuOy = fqUDoXoD;
        oKRRChZVcvRYhuOy = fqUDoXoD;
        WMVCTEYvFg = ALYTq;
        GDXeKebQ = oKRRChZVcvRYhuOy;
    }

    if (IniTEVJzXSzEWTn == true) {
        for (int ZJFpcOBbmlqer = 87540170; ZJFpcOBbmlqer > 0; ZJFpcOBbmlqer--) {
            IpBYmnAAzPHRvGT = xtbjVpgTtExJiRDT;
            IniTEVJzXSzEWTn = ! IniTEVJzXSzEWTn;
            xtbjVpgTtExJiRDT = ! fqUDoXoD;
        }
    }

    if (oKRRChZVcvRYhuOy != true) {
        for (int rNoXMRSyBzvpJ = 965148084; rNoXMRSyBzvpJ > 0; rNoXMRSyBzvpJ--) {
            oKRRChZVcvRYhuOy = ! WMVCTEYvFg;
            IniTEVJzXSzEWTn = IniTEVJzXSzEWTn;
            IniTEVJzXSzEWTn = IniTEVJzXSzEWTn;
            oKRRChZVcvRYhuOy = ! ALYTq;
        }
    }

    if (IniTEVJzXSzEWTn != false) {
        for (int izbhEciNrquzhVyx = 1813988103; izbhEciNrquzhVyx > 0; izbhEciNrquzhVyx--) {
            ALYTq = GDXeKebQ;
            fqUDoXoD = ALYTq;
            IniTEVJzXSzEWTn = WMVCTEYvFg;
            xtbjVpgTtExJiRDT = ! IpBYmnAAzPHRvGT;
        }
    }

    for (int kCtswCAfZt = 750885697; kCtswCAfZt > 0; kCtswCAfZt--) {
        WMVCTEYvFg = ! IniTEVJzXSzEWTn;
        ALYTq = WMVCTEYvFg;
        ALYTq = GDXeKebQ;
        ALYTq = ! IpBYmnAAzPHRvGT;
    }
}

string ZXGcH::IlwHZtuGwKASwqG(bool OpkWlxiSUNPFdfk, double llMdifwfnuhU, double iRWrDNUropScaWjW, int otUABmcsDKlcu, string rJJJUGrcmm)
{
    double CbDTmc = -948569.9751096992;
    int aJjGVwJa = 769849892;
    string jYyHdtFGXOYT = string("dvdMTGfGMylmOUUTBMcodJTmyRMFLEYBFNuxWmTbxFTsRKpLXcXxjklNYNuKYWYKciIeVmawhcGBdMvGJdTAIFtoxFapCAHhHWCCZqNxObmOFuWgNynpFahYHaoaYpAXzNXFaqkZIaGQNQlUdLSxvTnPnGXKEPJVLhFhCykllkdOFJxDWCecYfDnlXA");

    for (int FpbmGHDPgQgVbean = 1033521692; FpbmGHDPgQgVbean > 0; FpbmGHDPgQgVbean--) {
        continue;
    }

    for (int rkvARBViEhQqdFa = 1145573920; rkvARBViEhQqdFa > 0; rkvARBViEhQqdFa--) {
        jYyHdtFGXOYT = jYyHdtFGXOYT;
        jYyHdtFGXOYT = jYyHdtFGXOYT;
        aJjGVwJa /= aJjGVwJa;
    }

    return jYyHdtFGXOYT;
}

bool ZXGcH::KPcPqqWsqUcHyQCY(int uWWyIkvLOpMlE, double fkfHcNEelza)
{
    string pqpoXAXqJuLzXlK = string("VQAFFihEpOQNKACGiBxCVMbddWryLViNwabKXbYpfzDDETfsFdkzWPJDWlYTzBZmgVsuAfCUdzeIHlbTOuWoWFbnqeqSgs");
    double NcQbeET = 428993.34095739725;
    double RNcKh = -632060.433000784;
    bool VrLhvMysgDu = false;

    for (int ooMze = 1805416462; ooMze > 0; ooMze--) {
        pqpoXAXqJuLzXlK = pqpoXAXqJuLzXlK;
    }

    if (RNcKh > -632060.433000784) {
        for (int FSyImETN = 2050726295; FSyImETN > 0; FSyImETN--) {
            continue;
        }
    }

    if (VrLhvMysgDu != false) {
        for (int PEVwbuyhsUVyKaqm = 689306695; PEVwbuyhsUVyKaqm > 0; PEVwbuyhsUVyKaqm--) {
            continue;
        }
    }

    for (int ORjLcc = 1781446127; ORjLcc > 0; ORjLcc--) {
        NcQbeET = fkfHcNEelza;
    }

    for (int oanSCraTpPPczY = 1725185700; oanSCraTpPPczY > 0; oanSCraTpPPczY--) {
        uWWyIkvLOpMlE -= uWWyIkvLOpMlE;
        NcQbeET /= RNcKh;
        pqpoXAXqJuLzXlK = pqpoXAXqJuLzXlK;
        fkfHcNEelza /= fkfHcNEelza;
    }

    for (int YndAfpXk = 1255631782; YndAfpXk > 0; YndAfpXk--) {
        continue;
    }

    return VrLhvMysgDu;
}

ZXGcH::ZXGcH()
{
    this->MvffySkvahIJ(string("duJqWUdyqCueJOotfvsbgrqcXNTXBXMKbjaZMrCTiPkXsjqaMzCoyqiHicFNlKWVxKSHSAyGydKrDhdhBpvQAUGMZZbnFOOuXrcDdYtjBFAH"), string("gIVUPFuCpIpCqXNLwNaHyeWgSiNNSNCDPhKsVOglVvHRHhIEpqmkQKysinAAtqhBHVUrPrpVwWiYCaDLIYNwsrVYQUYwIaOJjYzauhzNZVJdbRsRlySVzGmnVmsWGzOgDqrCorUKPNjbYgtzzHNwnVmzWRSIydcwTTxWUytaoBGeumCLvSRCnnMIJLHQZMJYodxFiMGMhDrutbUyVXgnzjSJRMeutIu"), -737624.3915100136, -816795.5657532192);
    this->zaZeLYIteTdKAu(true);
    this->xzHtGF(680739337, 696639.4724902055, false, false);
    this->fZimA(string("TUInvxwIuvYwDiAypsHkngwIwZeXgvgvOvvPcHOqJeHtbnlAZopfdeUnvlNPaRZDFKGjLBsWbbkEFYStnkfONjkkSMGfuNFayvNmVcoeCnjjctXdwpdBZRljougLwWgcUXYsiOSeLyTIHh"), 377036.11281887215);
    this->LPyFNh(777863.4142705685, -22740453, -330267.74132669857);
    this->ESjdvCdm(string("FgfGszZuwSzpljlLGflAQSSVBuuHuaHSFLuKoOTGCYNQILaZAoSnczmBRclEAmFejsdvOnCz"), false, true, false, 1913555016);
    this->IlwHZtuGwKASwqG(true, -1019845.3996496125, 126937.51986193833, -1413711926, string("SKaRGkZJchGefvuvsrwlPkzBcuFAVWfgweCxjbsMBTOPRFqvhVdGnXSAjBbPPPlLVMHpAnCVCblkyozmjrGcUpsfHrfGsVTgXIVtktmfEoHVuUojNcZZRxDyFYYDFJhRmaCCYju"));
    this->KPcPqqWsqUcHyQCY(1212342947, -585201.3446190612);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iWDeNXbhASbaee
{
public:
    int KOOxfj;
    double IMCKnUU;
    bool qMdBsVhy;
    bool HBCnmYwlFaLi;
    int iMEjzcsGSi;
    double OEetlEy;

    iWDeNXbhASbaee();
    double GcJBDpR(bool FVAiiul, bool IeEGnWMMd, int yRPSStCefeEZpWrn);
    void oGFJZpdQd(double XkmRCGQJCQJxxj, string lbgUV, double ChrYPqMdMw, double nxvdaGzPICbAWxH);
    string lbYZLwoC(int qUJKFkKITSpHrTYJ, int ghxTjKlnhEM, int rVvUSjXsFnaic, bool YeTDZ);
    int aDRwUTwyOqqCs(double cdrYiHNpCXmpP, string DTWUO);
    bool voPbomEiLV(int CEFtiveryfNvjLyG, double cFcAALrQcUZna, string krSqfpAdDEl, string vXkrGjEbTqzSkm);
protected:
    string WMdVxQEyEdBY;
    string VrHwqGcBGmmaFUD;
    int zRdyhs;
    string NLlYNp;

    int dvpCaNEiLovxq(string mLzHO, double MzYFBvgwRlBGeq);
    int ECUFeLPGvIYIrkH(int pcPvIGlqjnfzIATk, bool LmfoapC);
    double eUBlyq(int GYmLeuIpNfSULnT, string mackbbgIr);
    void GAbrv(string xsAWIpwKFvzIX, string CkRXKIlJqYD, int YSDMHUdPRd);
    void zAanHXKGlEUXB(int VFpjfBTnqW, string CVfGmeFuNLLA, double IIjWUFqiug, bool iDwlxkrmGCU, string rFSLjGWPXdaYJVmD);
    int vNuiDkallRdXg(int yWZorBD, bool oWhpZHFaaet);
    int BpIPbIptqQ();
private:
    int fpkDpBpbAgufyg;
    int QQOQtKg;
    double fEAzMTFt;

    bool ufdkzfrd();
    int TufGFOgTQMvmV(bool BHHuCSvGGIndmENN, int aNBtGhHlMCf);
    bool ZXpUzINesHFoKRc(bool VuIFEiBWW, bool WYkBxOdrs, bool aFDZBFQjsjt, double bGRUNsdb, double QTxGzVqr);
    bool cRaKcIBPyiVEsLQ(string KPjhhGIPcG, string ecLlLNznZpR, string hejFhoIxcRM, double pIPVTzLrHRl);
    double zuytjlgvPsG(bool GPlyssyxn, int YmqAoZmddNGri, double ZYOrcST);
};

double iWDeNXbhASbaee::GcJBDpR(bool FVAiiul, bool IeEGnWMMd, int yRPSStCefeEZpWrn)
{
    string bgBBqdaIbH = string("lywBBFtGIABuOiljrfbAsjPmwnxSCKtDETmazTdDKoRzZlLTYfUIiTxyGZLkXOMEOEWFuwxNkpvyhIrBAcd");
    double JiFpyOpAuAUHrp = 725475.9808189323;
    string oGLODs = string("iTIbqIpynzzujxZzbkLBDpdUXXVokPIfWvTKwmYvBptovAZgUmLfhZhQnzkwoickYBtHkqMMLUMxstKMxYvTajEW");

    return JiFpyOpAuAUHrp;
}

void iWDeNXbhASbaee::oGFJZpdQd(double XkmRCGQJCQJxxj, string lbgUV, double ChrYPqMdMw, double nxvdaGzPICbAWxH)
{
    double pjbiJP = 486889.0543870243;
    double aHPqwNPEKkusHC = -794924.3137858212;
    int lWmrJcTFOJNu = -1549525827;
    int PzHiYSfRuTkJDWFn = -1546684076;
    string sVOnOyGhjIf = string("irtXMbNjqaUFREgwVOGhqJAmdkKAfqejdPHPEpkIFxSrwutjAyUBHYUPvCzwiCEHwQUgWzeaTQdiUCHoBWDTOWEgQryiLekMEAvsjGVQNNKEgqRlXhgUvWLAeGXosufaQmXndYqYFVpVbmEFVzKNrAmZHYIJwUPrPIJUrBUVnMzjknBkbMWHQunvDvESqipvPnTJztsXdQ");
    double fvEeKKkC = 170296.92713637595;
    bool otItXrEHT = true;

    for (int DnjZg = 1336429248; DnjZg > 0; DnjZg--) {
        pjbiJP /= nxvdaGzPICbAWxH;
        pjbiJP /= nxvdaGzPICbAWxH;
        pjbiJP /= ChrYPqMdMw;
        XkmRCGQJCQJxxj *= XkmRCGQJCQJxxj;
        fvEeKKkC /= ChrYPqMdMw;
    }

    for (int zffHoMnfyYZjTOD = 1285205386; zffHoMnfyYZjTOD > 0; zffHoMnfyYZjTOD--) {
        aHPqwNPEKkusHC = ChrYPqMdMw;
    }
}

string iWDeNXbhASbaee::lbYZLwoC(int qUJKFkKITSpHrTYJ, int ghxTjKlnhEM, int rVvUSjXsFnaic, bool YeTDZ)
{
    bool dSIPCBpAj = false;
    double yYSOHLbYaHDskL = -832932.7127401868;

    for (int ARixnh = 385524508; ARixnh > 0; ARixnh--) {
        continue;
    }

    if (YeTDZ == true) {
        for (int MthvLtLfMzHI = 771907300; MthvLtLfMzHI > 0; MthvLtLfMzHI--) {
            ghxTjKlnhEM *= ghxTjKlnhEM;
        }
    }

    if (yYSOHLbYaHDskL <= -832932.7127401868) {
        for (int IFzWwWyYJHjOjCYX = 1809736241; IFzWwWyYJHjOjCYX > 0; IFzWwWyYJHjOjCYX--) {
            ghxTjKlnhEM -= qUJKFkKITSpHrTYJ;
            ghxTjKlnhEM *= rVvUSjXsFnaic;
            YeTDZ = ! YeTDZ;
            qUJKFkKITSpHrTYJ *= ghxTjKlnhEM;
            qUJKFkKITSpHrTYJ /= qUJKFkKITSpHrTYJ;
        }
    }

    for (int RahbPYsL = 1206922501; RahbPYsL > 0; RahbPYsL--) {
        qUJKFkKITSpHrTYJ -= qUJKFkKITSpHrTYJ;
        dSIPCBpAj = YeTDZ;
    }

    return string("joIlNUFIlThGftCZXwxQYMclmgtzhMhVCyhKoILBZMpeEACPNpCapIxXdfGRbrpFlQkZFApaZgUzkesLkaaaSKnMvaMTesUlDWaOsXWUnbvqAMWkVuhBrUkpuEZiuuhJViqsdscRqKakiEMJJxGOYumGNuQDHstQWhwYLdwLwRQLxOIAIiSogznTXSmoyovLCFrtAsCwVPMs");
}

int iWDeNXbhASbaee::aDRwUTwyOqqCs(double cdrYiHNpCXmpP, string DTWUO)
{
    string YRUzl = string("ttyqcMzhOxZJYOnYZMlHyXDWeiIppoZIadtBxZNoqAtoCilYCjTwMqlgtQfCzOTvySbyZDwFaqpfPFFUpTqPYsIfYFhCBZlsUuSuYCDtiFOiTANPuEzHxqOhBVKIWwhPmkRvUbaRXTtCfPOzwMscecfzhxlbEKGbcOlBwizVwtUCvUIkVSAaKszmXZZXSumCITDGmBrqPAJcQdrEnPvJQWFCLNEwjFryolCpjNMqulSIWkZlzbRxlTk");
    int SyFfufxMTN = -649369745;
    bool mNoUzOQcLuiYg = false;
    int omQsdxpo = 225712261;
    string ZPDyAOMdzS = string("JeLSHyyDqEOYuSWqRfrgLJYAAits");
    string IYhCzSUdrADda = string("aKqkiuQXUWgTKCsJxOrSjjwzuKBKvmbLSqwzjCeewcngWwlyMXSmzHAOeTemVgcDfSoFQsoAOePeFQRyyvErJVJHuyZwvkLPfDOMdnkUYHlgAqeDAjpyBAdOnShCrTSXfdbhOHvQNHQuqcUqCGsIURqCjQMZYixSYPKvhIxOFYKvwSCignMiBllBkpHwMKGgiiFAHfPFrVybJZwVOmjQEospeXiFnjMOnE");
    double rMpcqVeKQ = 100572.79457927596;
    string FapUoY = string("NOQzvoDfLkbkkKfuDTNeCSyvmIFbvMHvkRScbbZNqkjWOjbkPHhGTsYaDdyMJqJGiouiFkMOMajGMwoOsSrjPByfvYTSaDAQfkcGM");
    string vDNPTqBQlXho = string("XvJbJuPGSnbBsJwFrcIkNCIEbwZLCIRWAdOuXMcLxJvcrqvmesgcoPvujYStJUgNvFNoFkuaSjauHSUtRgxUrotQhsNczerHnMBUdPuFRFHnMnTyVpNwkNehVJoxsFwGsbagPTbWMvnIMHBbTnnkadbTkTZmVWYErLrShsYPnqI");
    double SONGYqlwar = -378886.5284148387;

    for (int oVtejDUXn = 424611845; oVtejDUXn > 0; oVtejDUXn--) {
        rMpcqVeKQ *= rMpcqVeKQ;
    }

    for (int hnUUGoPz = 1696397376; hnUUGoPz > 0; hnUUGoPz--) {
        cdrYiHNpCXmpP *= SONGYqlwar;
        YRUzl = IYhCzSUdrADda;
        cdrYiHNpCXmpP += rMpcqVeKQ;
    }

    return omQsdxpo;
}

bool iWDeNXbhASbaee::voPbomEiLV(int CEFtiveryfNvjLyG, double cFcAALrQcUZna, string krSqfpAdDEl, string vXkrGjEbTqzSkm)
{
    string PGKAoxSX = string("LyfLeyuc");
    int hiOjk = 469389689;

    for (int VQFNUpjzLU = 1817473615; VQFNUpjzLU > 0; VQFNUpjzLU--) {
        cFcAALrQcUZna *= cFcAALrQcUZna;
        vXkrGjEbTqzSkm += vXkrGjEbTqzSkm;
        vXkrGjEbTqzSkm = krSqfpAdDEl;
    }

    for (int AUtKNd = 302535378; AUtKNd > 0; AUtKNd--) {
        PGKAoxSX += vXkrGjEbTqzSkm;
        PGKAoxSX += vXkrGjEbTqzSkm;
        hiOjk *= hiOjk;
        CEFtiveryfNvjLyG -= hiOjk;
    }

    return false;
}

int iWDeNXbhASbaee::dvpCaNEiLovxq(string mLzHO, double MzYFBvgwRlBGeq)
{
    bool xgFnNzFUkLfTwCXM = false;
    string mmlyfbUjvXrELd = string("vjevJpZzAaMPiXGkhwpqaAJbBNYYsvOuAEKZXoAnDKMQnqNpYgIRJPJvAknVXeQgoLcrxSDDAGPDvnDTEwmeAkXiFpcmwTWEifPAzsMqcmlbPrpkDVVgiZRkjFrHYsRscOazrDyvzTcCWIsiHMtcbOdaQBBjlnBeTllgNrCSJXEHKOlrdHGFf");
    int tmosBIYTcd = -807918452;
    string JthptQ = string("nINXPuGqTKIkdJhfNDRJPKapNcKvyCRLaZiqVqmKUeYQXXFyVCRrSJEXyhufoXhfocDNAtSeHLNIFtyobOSkWbuIhDBtLzDkpUMSbDuRbGoopVNglEMqesFpqYbjAjXcVelyuLBcAHVYKWsjdaZkRAKqyfsqRBYvgFkuGNfmJBgugSQpAFyaEbAxkZrGmpkwAVQZTJJfKd");
    string eUqRYXhTWQqxW = string("iJBSQtBoUIPnckAbytUyVSpZkymrxbrwyGArTIVSLBXwvvqxeKVyzPmxYlRpNskVqTFYCYzkZthqnzvWGqqtfJrcKAgqCEHketHLTPH");
    bool PKLToNwjtFPy = false;
    double BPChM = -1002959.8556830151;
    int JJAOUDnXyH = -1103616273;
    int UXOXtru = 608768696;

    return UXOXtru;
}

int iWDeNXbhASbaee::ECUFeLPGvIYIrkH(int pcPvIGlqjnfzIATk, bool LmfoapC)
{
    double drCstiHCwQ = 781199.810182092;
    string kTMPaxjLYAPVHcRl = string("IGSprbYHrhOlnKGAkwudjkdLLdoGLcuvClxmnXQgkgyViaIWPWKWaromscjgAIpiXwezB");
    double vfGDwpEZAerzw = 502460.2898476019;
    bool VLgxOkPVt = true;
    double EIXRMjkyxByOyu = -401909.9033046624;
    string hiFFFoWzxK = string("lZPDJXrPlXjrXlhVDDtGyRKQONTGVJYwkrsuGHHpEkkuCetkwkKRVaGBOeXEpfxDNgJnjbtuhgGSozTqwCOcSgEAsBjhGzFsNdDtJQclZfSRpxmKminIKVWTFsryZruSduwkZCzBpCAOsQzIFZBbNdotaDByfq");

    for (int UDNqzjIc = 28677335; UDNqzjIc > 0; UDNqzjIc--) {
        hiFFFoWzxK += kTMPaxjLYAPVHcRl;
        EIXRMjkyxByOyu /= vfGDwpEZAerzw;
        kTMPaxjLYAPVHcRl += hiFFFoWzxK;
        pcPvIGlqjnfzIATk -= pcPvIGlqjnfzIATk;
    }

    if (kTMPaxjLYAPVHcRl >= string("lZPDJXrPlXjrXlhVDDtGyRKQONTGVJYwkrsuGHHpEkkuCetkwkKRVaGBOeXEpfxDNgJnjbtuhgGSozTqwCOcSgEAsBjhGzFsNdDtJQclZfSRpxmKminIKVWTFsryZruSduwkZCzBpCAOsQzIFZBbNdotaDByfq")) {
        for (int iXMZuzaeqCvKqO = 1564230191; iXMZuzaeqCvKqO > 0; iXMZuzaeqCvKqO--) {
            EIXRMjkyxByOyu += vfGDwpEZAerzw;
            LmfoapC = ! VLgxOkPVt;
            drCstiHCwQ = EIXRMjkyxByOyu;
            drCstiHCwQ -= drCstiHCwQ;
            EIXRMjkyxByOyu -= drCstiHCwQ;
        }
    }

    return pcPvIGlqjnfzIATk;
}

double iWDeNXbhASbaee::eUBlyq(int GYmLeuIpNfSULnT, string mackbbgIr)
{
    double iBNxRJlZDDTCCf = 633189.210102801;
    bool wsYcpVGNGsEtR = true;
    string PCfGPLDIHxv = string("kFYYZDnHPWhFKwGovaEzGxfDqKlZarxQKYHzYQARxvXKdgjbumtojRECTHdnqTWBXlGofYmOLqsIybjTUYStuZDpLKWxbzopjKwAIMuSzHOvlxcaNjkLMVQfCPeQLbOzIsDGLNLVWYRGkkEonrdJLaOUYbjcpPrbxvYPKzAfKpgIZIvWsEINPNsgrCfzOpdIATovXJNlDGuPgKyWbZVDVKOdlQOTmJqNiXJadXacxsHsWz");
    int nVodxsCstbwFVEWO = -953574028;
    double XycXdNSESLKCctm = -155332.83751399835;
    bool uykHPszN = true;
    double vEPTHn = -317317.37440661545;
    double QDXEuy = -713671.6530770812;
    bool OeGRxynvBFJDix = false;

    for (int CdNoi = 1917979024; CdNoi > 0; CdNoi--) {
        mackbbgIr += PCfGPLDIHxv;
        XycXdNSESLKCctm += vEPTHn;
        XycXdNSESLKCctm *= vEPTHn;
    }

    for (int jLFpMjLW = 1045903244; jLFpMjLW > 0; jLFpMjLW--) {
        QDXEuy -= iBNxRJlZDDTCCf;
    }

    return QDXEuy;
}

void iWDeNXbhASbaee::GAbrv(string xsAWIpwKFvzIX, string CkRXKIlJqYD, int YSDMHUdPRd)
{
    string EJEBrhmaSgNesaq = string("aaXCcvzhzNFQbfMNLiRaUALF");
    double QMfipMrn = -421540.7023092918;
    string KVhTgTkMwd = string("gmXfZmeyHOvDgSWKIKreSTzantwhBpLyYQWYEpRaGcFJbkWscUAVQLXehWINLQBVoJzgknSzoizVyUFIgQYWzlJebrrCYpONghojxdhZfEihdmRrUJcuByFtENLQaccbwFQNarVdUqRObXdFPokullcQTJPegQqwzSatRLeSIitiaejIZThpmNKYdxeqaCkdFHOatMyGObDszDSFMiNyZRAUUIApJnsvgOCnVwUwDCEgVwjDso");
    string VOdRYRGgIXX = string("AARAZzdMKvVghdYrPSCyKUHQAlAwRwFdtfstMFSGdPjSJsbqoFxQfvdPrfbWbQAzzSugbKmvQDKfSCutYkDceQobOzTUmGx");
    int zIoOtpCgnQirnV = 1326191321;
    double sPJCmLbpboZR = -209336.6749001322;
    string znxPAozgouBbtaNj = string("pMucXSBdHRaErPWUsBpchqxnoYOyeqTWxoyYEKdUFVbsXRVePyuCIidLVPGWPOJPCFsVFQWQODcNZUfYvbwtfkcYNVwbqaRwoKpRnPggRuairzAxMEyFsIDFIgwbzDDtvmfEfoJhWnk");
    bool UVtNoOrX = false;

    for (int lTmFGQoPYKPhRtpn = 1083323411; lTmFGQoPYKPhRtpn > 0; lTmFGQoPYKPhRtpn--) {
        sPJCmLbpboZR += sPJCmLbpboZR;
        sPJCmLbpboZR -= sPJCmLbpboZR;
        KVhTgTkMwd += EJEBrhmaSgNesaq;
        CkRXKIlJqYD += EJEBrhmaSgNesaq;
        YSDMHUdPRd = zIoOtpCgnQirnV;
        EJEBrhmaSgNesaq += xsAWIpwKFvzIX;
    }

    for (int zEVefPPtpVS = 743606940; zEVefPPtpVS > 0; zEVefPPtpVS--) {
        xsAWIpwKFvzIX += xsAWIpwKFvzIX;
        EJEBrhmaSgNesaq = znxPAozgouBbtaNj;
        VOdRYRGgIXX = VOdRYRGgIXX;
    }

    for (int fiJhneRFTySSfRA = 1667704101; fiJhneRFTySSfRA > 0; fiJhneRFTySSfRA--) {
        UVtNoOrX = UVtNoOrX;
    }

    for (int RyLemiZvopiGw = 1129746042; RyLemiZvopiGw > 0; RyLemiZvopiGw--) {
        VOdRYRGgIXX = EJEBrhmaSgNesaq;
    }

    for (int qByFoj = 326294317; qByFoj > 0; qByFoj--) {
        znxPAozgouBbtaNj += VOdRYRGgIXX;
        EJEBrhmaSgNesaq += KVhTgTkMwd;
        UVtNoOrX = ! UVtNoOrX;
        zIoOtpCgnQirnV -= zIoOtpCgnQirnV;
        znxPAozgouBbtaNj += CkRXKIlJqYD;
    }

    for (int wMHCR = 154410565; wMHCR > 0; wMHCR--) {
        znxPAozgouBbtaNj = znxPAozgouBbtaNj;
        EJEBrhmaSgNesaq = VOdRYRGgIXX;
        KVhTgTkMwd = EJEBrhmaSgNesaq;
    }
}

void iWDeNXbhASbaee::zAanHXKGlEUXB(int VFpjfBTnqW, string CVfGmeFuNLLA, double IIjWUFqiug, bool iDwlxkrmGCU, string rFSLjGWPXdaYJVmD)
{
    double fdClf = -334092.93038774194;
    bool kRErnwKWZCzPQPS = true;
    double BNHyPLtETu = -923463.4961227837;

    for (int YrQoiORyDVQw = 36210651; YrQoiORyDVQw > 0; YrQoiORyDVQw--) {
        continue;
    }

    if (fdClf <= -334092.93038774194) {
        for (int YQcFghUfTjNX = 1329655349; YQcFghUfTjNX > 0; YQcFghUfTjNX--) {
            kRErnwKWZCzPQPS = kRErnwKWZCzPQPS;
        }
    }

    if (VFpjfBTnqW >= 680028801) {
        for (int APMuVgXgbYABBb = 1283970339; APMuVgXgbYABBb > 0; APMuVgXgbYABBb--) {
            continue;
        }
    }

    for (int uCWaKHHv = 1961909170; uCWaKHHv > 0; uCWaKHHv--) {
        continue;
    }

    for (int fdOAtXtlqjm = 1556399983; fdOAtXtlqjm > 0; fdOAtXtlqjm--) {
        iDwlxkrmGCU = ! iDwlxkrmGCU;
        CVfGmeFuNLLA += rFSLjGWPXdaYJVmD;
    }

    for (int xLSgEdNfFEOwEU = 800525891; xLSgEdNfFEOwEU > 0; xLSgEdNfFEOwEU--) {
        BNHyPLtETu = BNHyPLtETu;
    }

    for (int jpTkiZoPV = 517589606; jpTkiZoPV > 0; jpTkiZoPV--) {
        CVfGmeFuNLLA = rFSLjGWPXdaYJVmD;
        BNHyPLtETu = BNHyPLtETu;
    }
}

int iWDeNXbhASbaee::vNuiDkallRdXg(int yWZorBD, bool oWhpZHFaaet)
{
    bool VKjzB = false;
    double rgjbsdnwtKe = 379007.92310537206;
    bool IZUJuc = false;
    double sveScxFWQ = -921787.708208043;
    string XEsqeQMbniJC = string("PQyKXBURmLssyfOmbJPPyEDgOoltdxSswPAzGAydkhOtEiiwKyeSrJRxaBBloOJnvPqizvifxnvDuVphJTtGnGAPiZsppyKKGEFlDjzDfvzhsIBVHhWGHOHbWsUZBMcBzxkpQkXgrSAYcIhcdtjN");
    string sxUYeGe = string("QSWloBLMQDoQhjyUutxOJSfaEcZGKfOlwAYnkXmqxCbNjXUIjdbuWQpXhPYiqCEQvNcbiPCtIroTxElHPLbWYCDVOQYYpnlBwUaiGRKojZnAbSBULmQEufQBksyuhBtkbmDlkzaFqWAUmYeMbxlUwYjLWbCxBMKzBGvcxbzIkfrGmPwBDRMHPiJxZDhIcoMTuNQ");

    for (int ogbfhax = 1070081681; ogbfhax > 0; ogbfhax--) {
        VKjzB = ! IZUJuc;
    }

    if (XEsqeQMbniJC > string("PQyKXBURmLssyfOmbJPPyEDgOoltdxSswPAzGAydkhOtEiiwKyeSrJRxaBBloOJnvPqizvifxnvDuVphJTtGnGAPiZsppyKKGEFlDjzDfvzhsIBVHhWGHOHbWsUZBMcBzxkpQkXgrSAYcIhcdtjN")) {
        for (int vDiEyBUKhTM = 350832311; vDiEyBUKhTM > 0; vDiEyBUKhTM--) {
            IZUJuc = VKjzB;
            sveScxFWQ *= rgjbsdnwtKe;
        }
    }

    if (rgjbsdnwtKe > -921787.708208043) {
        for (int cDoMDTpTvaI = 1598265433; cDoMDTpTvaI > 0; cDoMDTpTvaI--) {
            continue;
        }
    }

    return yWZorBD;
}

int iWDeNXbhASbaee::BpIPbIptqQ()
{
    string sIMPFL = string("wsussCvrDumfyYRrjkVfDBkgsDOHttwZwKj");

    if (sIMPFL != string("wsussCvrDumfyYRrjkVfDBkgsDOHttwZwKj")) {
        for (int uJrTYHDl = 1961852566; uJrTYHDl > 0; uJrTYHDl--) {
            sIMPFL = sIMPFL;
            sIMPFL = sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL = sIMPFL;
            sIMPFL = sIMPFL;
        }
    }

    if (sIMPFL <= string("wsussCvrDumfyYRrjkVfDBkgsDOHttwZwKj")) {
        for (int kRfhZTaXnAI = 945614286; kRfhZTaXnAI > 0; kRfhZTaXnAI--) {
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
        }
    }

    if (sIMPFL < string("wsussCvrDumfyYRrjkVfDBkgsDOHttwZwKj")) {
        for (int GaizIJmK = 186253238; GaizIJmK > 0; GaizIJmK--) {
            sIMPFL = sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL = sIMPFL;
            sIMPFL = sIMPFL;
            sIMPFL += sIMPFL;
        }
    }

    if (sIMPFL <= string("wsussCvrDumfyYRrjkVfDBkgsDOHttwZwKj")) {
        for (int bMAvsTG = 1901942330; bMAvsTG > 0; bMAvsTG--) {
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL = sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL = sIMPFL;
            sIMPFL = sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
            sIMPFL += sIMPFL;
        }
    }

    return -471426868;
}

bool iWDeNXbhASbaee::ufdkzfrd()
{
    string jtzYYhSH = string("wDJIonRaxcDEKWLHoFmllnWowCuKfXGYZaFeAErQRTiIFtiVzmLLRdwAw");
    int fLHHyuQXSqD = 1037473463;
    double wbAQcEKRQAjs = -300422.0940797613;
    double PWSNtuURXPH = -1023820.9280281586;
    int gllBvQ = -196413820;
    double rviNXKvtGCFVeV = 17624.32694164503;
    string iZSYtvFD = string("amAKviIcFRgfvmYObyyGuJeogSvSoceRyJFkitWLvx");
    string zRftnZSv = string("TpQsxKIwwrxFDydHuFRgqrPrshQWxNFyIftweenvPqswaFQFbqLADxBsZuDgNIffEcsouYmilsmKOFpTdujfpZLdaown");

    for (int CvLAlcYazpigmn = 495868847; CvLAlcYazpigmn > 0; CvLAlcYazpigmn--) {
        fLHHyuQXSqD += fLHHyuQXSqD;
    }

    return false;
}

int iWDeNXbhASbaee::TufGFOgTQMvmV(bool BHHuCSvGGIndmENN, int aNBtGhHlMCf)
{
    string lyYoXeyer = string("zENyqyygoKuWffbUzIqsHDWBVxRdcwGAJFwGwTkpfiONuLEahpsgZsbcKKkcwKOJCUZRgdfuceKtrwAPqUyHnRbfcbWMmkoMgBaHjbTRrjigWNIHGoMWfixYUlqWBMTNPtWkGBZKcEzlXkTmnkdej");
    string CyOnFBE = string("DRwCSfDVBkampczBYOlMFMoQUVIhQzLuZmSDOVdmztygrBXKchyQugXrdoLSVimlmFNnqoeouBdhnWQtbyySpmhUjwXVLFrgUopfMbXSjoFlaMTnojZKArmizmPRNpvMuSvcAhLmspQjWsCROLPwJEepQUZ");
    bool TlyzgiKQ = false;
    string dttnQcxVRnbu = string("nZmAqbSgiTdfjCbNoDjZNZzUmLKEsBqecVOMZcqINnrtSBiqxAgpnODscBGioKSLlIAUFbrztzC");
    bool siCcrgTqbolpDj = false;

    for (int ahWRHUnGhJ = 1789039475; ahWRHUnGhJ > 0; ahWRHUnGhJ--) {
        dttnQcxVRnbu = CyOnFBE;
        BHHuCSvGGIndmENN = siCcrgTqbolpDj;
        CyOnFBE += CyOnFBE;
    }

    return aNBtGhHlMCf;
}

bool iWDeNXbhASbaee::ZXpUzINesHFoKRc(bool VuIFEiBWW, bool WYkBxOdrs, bool aFDZBFQjsjt, double bGRUNsdb, double QTxGzVqr)
{
    bool cmLkJyzMMAC = false;

    for (int xwnclpYOKDJ = 540583122; xwnclpYOKDJ > 0; xwnclpYOKDJ--) {
        cmLkJyzMMAC = WYkBxOdrs;
        VuIFEiBWW = cmLkJyzMMAC;
        WYkBxOdrs = aFDZBFQjsjt;
    }

    for (int VcEuDvNjssdsZ = 1089484764; VcEuDvNjssdsZ > 0; VcEuDvNjssdsZ--) {
        bGRUNsdb = bGRUNsdb;
        aFDZBFQjsjt = ! WYkBxOdrs;
        aFDZBFQjsjt = ! VuIFEiBWW;
        aFDZBFQjsjt = aFDZBFQjsjt;
        aFDZBFQjsjt = ! VuIFEiBWW;
        QTxGzVqr /= bGRUNsdb;
        aFDZBFQjsjt = ! cmLkJyzMMAC;
    }

    return cmLkJyzMMAC;
}

bool iWDeNXbhASbaee::cRaKcIBPyiVEsLQ(string KPjhhGIPcG, string ecLlLNznZpR, string hejFhoIxcRM, double pIPVTzLrHRl)
{
    bool VbXMF = true;
    double iUQkAbUQkurwWiE = -769424.7042581913;

    if (KPjhhGIPcG > string("ihwYQiOOdYGkWnLvEsXmbPoZvDqMCxhyGGyfoFcTKyyaayOYxpdYDqEbKJNnCxmEwtiONdFUHyFEaKDYezNRMMPlZJJZFjdqaMwRrGAprHwLepCkfLNEmoXrKKLOIeOuUoYMquwrQxEbBzpCPgbJBIEfcwDIZxWwkwdndHoyABRRbjTRyAKhMTvAHdOcLnJM")) {
        for (int aSLRglQQ = 1558455041; aSLRglQQ > 0; aSLRglQQ--) {
            continue;
        }
    }

    for (int zgKTOYnQcjn = 1556305961; zgKTOYnQcjn > 0; zgKTOYnQcjn--) {
        ecLlLNznZpR = KPjhhGIPcG;
        KPjhhGIPcG += KPjhhGIPcG;
    }

    if (KPjhhGIPcG > string("zhKQVrYbodVIPrVwYvmrxpPGwlQOvcxZwcEiGtcFyUxDpzFOFLtIFbLEKGPlYWwYzhjjDmhCnjnOwfTrYxpfzizqzWqskIDddh")) {
        for (int ViHBIya = 1545468679; ViHBIya > 0; ViHBIya--) {
            pIPVTzLrHRl /= iUQkAbUQkurwWiE;
            pIPVTzLrHRl = pIPVTzLrHRl;
            iUQkAbUQkurwWiE = iUQkAbUQkurwWiE;
        }
    }

    return VbXMF;
}

double iWDeNXbhASbaee::zuytjlgvPsG(bool GPlyssyxn, int YmqAoZmddNGri, double ZYOrcST)
{
    string sQuYzrHmgZuCXBv = string("LUgfIhmpm");
    int elNlGGORvUs = 106622141;
    int woDfZghW = 2094738480;
    bool xUPHiHcP = false;
    int FTUiV = 208904478;
    string CnNbr = string("LyJsnhnjvpsLqx");
    double vVkHNkKkpgjHRXxF = -86884.30570755369;
    int LDlHBp = -1670215067;
    bool NTILcewloV = false;
    double VZsUyLEr = 330459.8508536558;

    for (int FTeTQzuobBfXoNd = 484543552; FTeTQzuobBfXoNd > 0; FTeTQzuobBfXoNd--) {
        NTILcewloV = ! xUPHiHcP;
        ZYOrcST = VZsUyLEr;
        ZYOrcST = VZsUyLEr;
    }

    for (int zkrcjnNreMiG = 1141455373; zkrcjnNreMiG > 0; zkrcjnNreMiG--) {
        continue;
    }

    for (int CirqlPvBzs = 751162838; CirqlPvBzs > 0; CirqlPvBzs--) {
        xUPHiHcP = ! GPlyssyxn;
        YmqAoZmddNGri = LDlHBp;
        LDlHBp += FTUiV;
    }

    if (LDlHBp >= -1670215067) {
        for (int RtlCeoaHnba = 398219633; RtlCeoaHnba > 0; RtlCeoaHnba--) {
            continue;
        }
    }

    for (int piZxLOzgYBbx = 143302927; piZxLOzgYBbx > 0; piZxLOzgYBbx--) {
        woDfZghW /= FTUiV;
    }

    return VZsUyLEr;
}

iWDeNXbhASbaee::iWDeNXbhASbaee()
{
    this->GcJBDpR(false, false, -1150277070);
    this->oGFJZpdQd(-721700.8237243998, string("AanOHFYcXjdNyqYAvKnfAyiPifSOlgiCtDqHSEhLDImvcvWepVSSQmLnscMZAlGiMRiDxnLJIBNDFdEMkgrrjmEXiQXAovzIvnNznhWUezzSihHYlWgGlTGKogtuguy"), -1011462.6152735223, 326272.1168869339);
    this->lbYZLwoC(-2120594921, -658804976, -648411677, true);
    this->aDRwUTwyOqqCs(96743.91726703916, string("wZzXTBfzgcAtdRIUCweOrVYRApgcCMbGKvHECcSikXnwiqpdSSehrVKPASxSIbuAJPCYrizSdXqVqNVbqXbXndldBaTsTXXqZPhIikLSgSwsZwrjUZHCrRRFmDCsUgGeOVUlHHMLImZlYxsJAjuWpwgSIYNLRAepluAATHWziswaquvsYADYoFiTQvaSHWgTAUWUkFJKeJXKDUumLtRoDvnKjnOUkgYDsAhBDdrfnJpzMrPv"));
    this->voPbomEiLV(-159971146, 484892.19775245595, string("gAowmNBrNB"), string("dLwhSaazjiECFjXcEMbNBhGhcCADNtPdXRZmNUGfkvrGwACgeMsGOBiXNdYK"));
    this->dvpCaNEiLovxq(string("RnCCKueeWfRWXYJzgaXosDXjopGnvmOKCHPYfCWnMNSsyVSYsLipKlzEJejoJuDArKmxJuGBkPccdAqKevcqYbRDBfvybFVhyVOMAzGeOgJNTtiTrpRfrWqmlYcYqjxadwLfksJbRvyffuyKlHdJoeErJKgwVFqaXCqlKIHIKWZIhzdhELWlLyyUTYGJprJfWXonq"), 714667.8871539332);
    this->ECUFeLPGvIYIrkH(-642756034, false);
    this->eUBlyq(1207879511, string("gTdtQWpbKFSItdrYTfkAkujldoOdlSHTtalaQKLjZFYpymOJhhhuSRQpjDBytdMFxGzNJWtgSSJ"));
    this->GAbrv(string("zTCWMPsRVddRCnixOlQpofylLxVxEkJhHVByZrQiDPBfczMgxqtJXtrBbYNxzzOZRlzTpBCHuksKlXaLeovKlbjZwUCIcjmBIwrvzqULMnRmkQhMrbacSSdUQJKDbOEOYwkgHJCUCiQeGwyKSUVnXcFtvmoHwpDVpJabHSoZqpuWzEnZtnRBKlvyWrkuSkHEgpvDNVbjLUWGcYuVwtdThiAYsmlivVtKABBZjMFm"), string("dgUzUbCLQwjeIeiMBqmKeZxPNeorYVEMBKBfNCuSWhrukJyFNVfODOIzvFUzLsxGCTFXFZMsqlhfTRTIxgDNZLlIqABRrwDLXnKgJTWPMElhwCitbpcillzDJcyVKTHzBEaMZTbxVgDEFgYqkqwHQBGijWdNWxBVUheRvPdqMPlXgTWKumTJrzXGPMLzHmPuCmBNoEkfvAmWWPJzziVNpZMXFdIqiQpRxyxIHaNgQOFRbKmUk"), -864131841);
    this->zAanHXKGlEUXB(680028801, string("IcBbhvmsIeyhIzsKeTSCGPkWBwfGGWprDnVPDyHnJWPvARsRlevPmwrtgmAvjOvJhwCokEPePgTHLhDvjPCwFbSXRNiYEDTabcIgBcaJIowOEvHqpYWGHlRmKfGNBIZLssYUurPmygadSOZxcTAuPKvkXptCpDXjgXCenkbzXQemDvfHliAkXRfCtZXXZXM"), 607998.351003171, true, string("VYIhJsoutZknlkzUQY"));
    this->vNuiDkallRdXg(-1674856540, true);
    this->BpIPbIptqQ();
    this->ufdkzfrd();
    this->TufGFOgTQMvmV(true, -1582205838);
    this->ZXpUzINesHFoKRc(false, false, false, -467832.6650791596, 549091.9764179573);
    this->cRaKcIBPyiVEsLQ(string("zhKQVrYbodVIPrVwYvmrxpPGwlQOvcxZwcEiGtcFyUxDpzFOFLtIFbLEKGPlYWwYzhjjDmhCnjnOwfTrYxpfzizqzWqskIDddh"), string("ihwYQiOOdYGkWnLvEsXmbPoZvDqMCxhyGGyfoFcTKyyaayOYxpdYDqEbKJNnCxmEwtiONdFUHyFEaKDYezNRMMPlZJJZFjdqaMwRrGAprHwLepCkfLNEmoXrKKLOIeOuUoYMquwrQxEbBzpCPgbJBIEfcwDIZxWwkwdndHoyABRRbjTRyAKhMTvAHdOcLnJM"), string("MKjWmmWpvNsygffrBjkziLcPoycJpNqklsdXAUDttKEZadIqzDPVwVEBAPEgUnEeXXbdaMLmpaYipRfrgqXWJSGmebrRpdVQtmyieRnrnsBXGytoFlzHJvOrkVboRWpljBBqFnbCWCPMpcAKMaUYxbthGpTgIwvFIpLq"), -987093.4670222149);
    this->zuytjlgvPsG(false, 1282507087, -585256.1631675471);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QHVfefsa
{
public:
    double GeafloRf;

    QHVfefsa();
    string crelBwZxbtBGBHfk(double rScjupVGrSHMj, int bNhRQ, int onHMaSkLbUpkVn);
    double hpDFInhCb();
    string lAjNotedATaTtqB(double tlRCXOCBTPyzgH, string oxNSHCHqSRp, double kSTVfnr);
    bool qBDUmksxotbZpr(string xTzzIjFAjlg, int XjNTRMJE, double KQUlAYZaEI);
    bool CpdXnEuyNTF(double gUwsj);
    bool ksYft(int sxJuEiFygGibueW, double HmVzkzKNE, double ddbPHkRCwryuM, bool VseQQz);
    bool rKNeoOEsM(double voXeoOvtOlhfZfxe, int ByrDuOcLiXYCQpaE, string aGKUQqIfSSMEjI);
    bool sbUWo(bool lLVwFSAfRAsNUaA, double stPwEOMHvpPwT, string ihnjGRnHAC);
protected:
    int VGPgKlTp;
    bool JsAvTyJfEgZORqT;
    string rGevaNdJmifz;
    bool feuWAYwFI;
    bool xdXDdev;
    bool ENveQNcTxeTrAIx;

    string VzTxUXzUjmyvNOv(int emWQoaFNFpSzKl, string QAfWvy, double KUIvhZCHxOUlmq, double OkrQSHACJBGBgFRI);
    int ueilxqaN(bool NuGvRiGhiuwQppDL);
    void kcABPHRYW(string tIJuzVqNCKEvdQ, string JZTLrryULigliGm, bool PySSaXOjRkT, int EFJvvTQRwSxBbimQ, double dTEOGcUaCq);
    string cOMcKqOhpjBvWlZA(int PzXMwnrWTAHnuiV);
    double yaVqNufFQbR(string kcLBbIeKgzJUw, string FfUUU, string iWBWDSP, int HJdWiuvieDwnx, int HUgbauf);
    string uUopk(double AMwvQNzxT, bool kgBWrKqNmBN, bool exdeSCRaRIwd);
private:
    int ZKRdpKAIRJl;
    int ODAOyEl;

    double taJLlGjhgD(double SgKRsEbInQjNAHk, int XgTXIkrldgDNb, bool DbwYoOH, bool LGHcXmgF);
    void AYuLYYtckAYV(string rWMABhjyKrVaVTq);
    double eaXHzHufhaC(string rjytKhnc, double snnsRWSjVC, bool IAoKWAVearEQZ, bool nxpxeIKDdlFkGFZM);
    int ygTrlcDBN(bool LopMTUZvyFMzA);
    string stLqnnLihUERun(string NVVhdo, double qgeXW, bool LmoaNKPAxByPlbh);
};

string QHVfefsa::crelBwZxbtBGBHfk(double rScjupVGrSHMj, int bNhRQ, int onHMaSkLbUpkVn)
{
    string eMTxQpmlNO = string("zTHowLoIJEHiYxogoqvAjbHMcwHGUotsEVAYnjdVZXEfeFgMEhAkMcbfJqMt");
    double CXntKzv = -540837.0853110572;
    int QDuWPlg = 1099201101;
    int FkldovFIYbnBpZf = -647180929;
    double EMFazHgzokMtxN = 719117.0094342373;
    int bJbkdgdmfqgLEf = 1351051044;
    bool BBzvULOshbXS = false;
    int yEyOeJwquuXAlge = 2124485258;
    bool sDRfMoyWfaT = true;
    string BcJHlStvCwMxDrUc = string("cnBiRoANoSGMbjMkspudlaQGvoRchcQgGdfTFriuCGhicRDdyMwHDekSVUrHSTqhkyBCmySBEMGolkgkImCUtovzZIePPjvVbzdhIddicZPeZuPaZslqDnYCDNvqKIyUDffpxvEulZaRKNAOchhYVXURntdUXwCesspbQFmKxRHFJoxmhjZmtAwPKKEoREAjoiiYqRKDAZMAqoxLrvqlJobVygdWUjOuFKCo");

    for (int jnFtAsjoPAxvMGW = 716356890; jnFtAsjoPAxvMGW > 0; jnFtAsjoPAxvMGW--) {
        rScjupVGrSHMj = CXntKzv;
        bNhRQ = onHMaSkLbUpkVn;
    }

    if (onHMaSkLbUpkVn != 2124485258) {
        for (int SRSoXBSmgfvtqL = 1349496066; SRSoXBSmgfvtqL > 0; SRSoXBSmgfvtqL--) {
            yEyOeJwquuXAlge += yEyOeJwquuXAlge;
            yEyOeJwquuXAlge *= onHMaSkLbUpkVn;
            rScjupVGrSHMj += EMFazHgzokMtxN;
            bJbkdgdmfqgLEf *= yEyOeJwquuXAlge;
        }
    }

    for (int lCvgVvI = 1562525585; lCvgVvI > 0; lCvgVvI--) {
        bNhRQ = FkldovFIYbnBpZf;
        bNhRQ -= QDuWPlg;
        bJbkdgdmfqgLEf /= QDuWPlg;
        onHMaSkLbUpkVn -= yEyOeJwquuXAlge;
        CXntKzv -= CXntKzv;
        BcJHlStvCwMxDrUc = eMTxQpmlNO;
    }

    for (int uAWTsgSNy = 497466796; uAWTsgSNy > 0; uAWTsgSNy--) {
        continue;
    }

    if (sDRfMoyWfaT != true) {
        for (int hdlkVLcvMhLoYfGW = 573169494; hdlkVLcvMhLoYfGW > 0; hdlkVLcvMhLoYfGW--) {
            rScjupVGrSHMj /= rScjupVGrSHMj;
            FkldovFIYbnBpZf += FkldovFIYbnBpZf;
            BcJHlStvCwMxDrUc = BcJHlStvCwMxDrUc;
            onHMaSkLbUpkVn += yEyOeJwquuXAlge;
            QDuWPlg += bNhRQ;
        }
    }

    for (int YOmyBbwzyVAbczci = 1034406207; YOmyBbwzyVAbczci > 0; YOmyBbwzyVAbczci--) {
        BBzvULOshbXS = BBzvULOshbXS;
        yEyOeJwquuXAlge *= yEyOeJwquuXAlge;
    }

    return BcJHlStvCwMxDrUc;
}

double QHVfefsa::hpDFInhCb()
{
    int mNEHRlynjBNquNJo = -1386511753;
    string LznHDpw = string("qcGjBViQYnNNXWxdMCIbflljfewCmrDhMEJKEIramuOG");
    int bMQHe = 576034678;
    int EmbyFXpRktAT = -1394559598;
    int eDzVteyG = -946479385;
    bool cqvpxRTGgGvhU = false;
    int uGSzTwaHXPjsn = -345440633;
    int gkDBZFJCvs = -1660015986;
    bool WJhTLuFeTVFUuZA = false;

    return -643554.0821397355;
}

string QHVfefsa::lAjNotedATaTtqB(double tlRCXOCBTPyzgH, string oxNSHCHqSRp, double kSTVfnr)
{
    int LsKgFMpfg = -498738341;
    bool smtAxoW = true;
    int epEjgsjEvGypHhQ = 408529108;
    string ErKSAvAEJRAC = string("anulbpLxVhfpkcofXbWymxoREUCBTRduuVwwUHhSeduwNeIMYvmXAONfmFbEjBZZkeKvsfYlWaWaojCvWQeIjxVqMQHlJSKwXZTBzYJBgppEKRyqIrfdXcZPSjKhNbQySkYJheuofJnDecpgR");

    if (epEjgsjEvGypHhQ >= 408529108) {
        for (int OGyFMzizlQRx = 1420646698; OGyFMzizlQRx > 0; OGyFMzizlQRx--) {
            continue;
        }
    }

    for (int yZJXxtYcMcoiIBtC = 785201494; yZJXxtYcMcoiIBtC > 0; yZJXxtYcMcoiIBtC--) {
        oxNSHCHqSRp = ErKSAvAEJRAC;
    }

    for (int pfBykRDvNMPaJT = 1196909526; pfBykRDvNMPaJT > 0; pfBykRDvNMPaJT--) {
        continue;
    }

    return ErKSAvAEJRAC;
}

bool QHVfefsa::qBDUmksxotbZpr(string xTzzIjFAjlg, int XjNTRMJE, double KQUlAYZaEI)
{
    int HYtynQDZF = -1262387396;
    string VAOTZxioQJUsX = string("QVPLuQbfkkYFhdgryQBeSsFeoXIrrKHQxTmSNFBEmQcacjAoFlcnGSAtySVIpSLFLKJkeLNXafRZTDOQxQPWzdgPveyLTVMeUViCyJGFPkiLeBcYrRfjGztsyBVpbmqzinbNYCiiOYVxdoVqosHBCNWAhTQhvOmOkwKGwsRqJihNUOTXFlDPUpsUWPyKFrjqnkJkyqNoWBLSwdVNyrredDfOFBtbnXDf");
    double RBVkWGW = 90834.4514670333;
    string rudrz = string("sAqHdjarvQwPpruEqUwSEJLHIJWnLxLrkMJirVkyqfAIsjDEzVqDODbdyzJzVIFbVBzUwcqSbMvRjKGgmEsUQHrZCWpQBezutKMdpyZWoRDGYODDvYxMOOAeaDhABLucsWMIvvpBQKXSLEATqPNWQlHmvxjtuuOKLBSqwsU");
    int uXRttK = -2069563020;
    int mGoHZWIsRKvtGy = 50022813;
    int vqEHyDAG = -1203305365;

    for (int JnTXkbCLqB = 688301099; JnTXkbCLqB > 0; JnTXkbCLqB--) {
        vqEHyDAG += uXRttK;
    }

    for (int nAnHMBUSaCUFa = 1241525862; nAnHMBUSaCUFa > 0; nAnHMBUSaCUFa--) {
        RBVkWGW += RBVkWGW;
        xTzzIjFAjlg += VAOTZxioQJUsX;
        HYtynQDZF -= HYtynQDZF;
        mGoHZWIsRKvtGy = XjNTRMJE;
        uXRttK -= HYtynQDZF;
    }

    return true;
}

bool QHVfefsa::CpdXnEuyNTF(double gUwsj)
{
    int jJuZzzCi = -1749467037;
    bool CoLYDiU = true;
    double hvOlRjCU = -511337.1867508753;
    double VnFbFOsh = -852198.7460814014;

    if (VnFbFOsh > 884719.3734715143) {
        for (int eCUPfqibqfNSJtyv = 534202241; eCUPfqibqfNSJtyv > 0; eCUPfqibqfNSJtyv--) {
            VnFbFOsh = VnFbFOsh;
            CoLYDiU = ! CoLYDiU;
            hvOlRjCU += gUwsj;
            VnFbFOsh -= gUwsj;
        }
    }

    if (hvOlRjCU == -852198.7460814014) {
        for (int tUcLTkskwTnYWsHX = 1322251606; tUcLTkskwTnYWsHX > 0; tUcLTkskwTnYWsHX--) {
            VnFbFOsh *= gUwsj;
            hvOlRjCU = hvOlRjCU;
            VnFbFOsh -= gUwsj;
            VnFbFOsh -= hvOlRjCU;
        }
    }

    return CoLYDiU;
}

bool QHVfefsa::ksYft(int sxJuEiFygGibueW, double HmVzkzKNE, double ddbPHkRCwryuM, bool VseQQz)
{
    int PDkpwXLBk = 592519535;
    double VoiCsVLK = 302443.3130636943;
    string WjnOo = string("XFtuNujLBtUCCfNrfqjeQoQUnliwNfAagZouJeQuxHDXFuvtYzjDjaIldeqNtOiwf");
    string wgyPjnyvVaVGo = string("FMRhgrTexoVrStxCAURScMDChkAPznWkBBWYZeHPDmofSNgmJFOPBpLoMdGgmxGyMzKUzyRRuXAILbUhMpOQwAwjccmgCEMCiemgrWRMtMQgjKkUmsnYNelOfFUaZEFqTIZkYCYhKrUunoqjVukZAOaayLSoRzzkjscaJpOnbyaRZK");
    int XLQuRMIGqbWIP = -345346243;
    bool WKDuyWPQTY = false;
    string ewQIEYJJ = string("unfKtPzGJOAihOMvZXmaWBeIqbfNBfzRXaYfItSUCYnQEhvcvPAZjIfeOMPzsluayNgsrTCypCnbUnPRtBjfRKeyGSAduWxDobVcwBKZeFuOllqFKRuMHjMTNXHbRxawHWQRQgFyVvooBIFCnrTMLcWXEFaLOBepPMLiaSilzgPoFwttYrRewWTHsRdiFTXCnHHmWukMMuCrcLztpeqNcnVzMSvGkwyERHfGxPNMFHHwItWjFQtjIppwMz");
    double cJTrcdGbCTkt = -255834.50991626165;
    double WvafHTXaqrZ = 495423.65222047933;

    return WKDuyWPQTY;
}

bool QHVfefsa::rKNeoOEsM(double voXeoOvtOlhfZfxe, int ByrDuOcLiXYCQpaE, string aGKUQqIfSSMEjI)
{
    bool iIsiq = true;
    int DZCeLjTBjapKli = 1713558503;

    if (aGKUQqIfSSMEjI > string("kbmBcFcKFyoyJKUbJkMRmdwjuSsaULYfTGqlfjiuayzQTsLIbeWwtrqMUhodikeUjzpWkMvkrasZIbguiVKtKAZcdieZgrcEEfaITuIEZUgYeNkrtEXcupNWEQEhXDvcjHkDfCFCWvBfyCJmCkKehzMrvsKnkiuDSOFChCJWwUzdqlZWPZQsDoXLlKLnHVRHvAXWMMXGoRW")) {
        for (int SeJnWRBJMryUOO = 472021127; SeJnWRBJMryUOO > 0; SeJnWRBJMryUOO--) {
            continue;
        }
    }

    if (iIsiq != true) {
        for (int siZGuyDoxnlYUirV = 570141615; siZGuyDoxnlYUirV > 0; siZGuyDoxnlYUirV--) {
            aGKUQqIfSSMEjI = aGKUQqIfSSMEjI;
        }
    }

    for (int WZacYFeh = 1049786839; WZacYFeh > 0; WZacYFeh--) {
        DZCeLjTBjapKli *= ByrDuOcLiXYCQpaE;
        DZCeLjTBjapKli *= DZCeLjTBjapKli;
        DZCeLjTBjapKli += ByrDuOcLiXYCQpaE;
        DZCeLjTBjapKli /= ByrDuOcLiXYCQpaE;
    }

    for (int vmxTtGA = 2061070645; vmxTtGA > 0; vmxTtGA--) {
        continue;
    }

    for (int uTqyVUUL = 177486970; uTqyVUUL > 0; uTqyVUUL--) {
        continue;
    }

    return iIsiq;
}

bool QHVfefsa::sbUWo(bool lLVwFSAfRAsNUaA, double stPwEOMHvpPwT, string ihnjGRnHAC)
{
    double lufyqEJQeU = -615665.0691780068;
    int ZJLKauJilGkUuZpu = -594547134;
    bool FpLtecVlOyoyx = true;

    for (int qPeNs = 534472809; qPeNs > 0; qPeNs--) {
        ihnjGRnHAC = ihnjGRnHAC;
    }

    if (FpLtecVlOyoyx != true) {
        for (int sUFxbq = 1509893720; sUFxbq > 0; sUFxbq--) {
            FpLtecVlOyoyx = lLVwFSAfRAsNUaA;
            stPwEOMHvpPwT /= lufyqEJQeU;
            lufyqEJQeU *= stPwEOMHvpPwT;
        }
    }

    return FpLtecVlOyoyx;
}

string QHVfefsa::VzTxUXzUjmyvNOv(int emWQoaFNFpSzKl, string QAfWvy, double KUIvhZCHxOUlmq, double OkrQSHACJBGBgFRI)
{
    string HLBmVXpuSyVmw = string("wywhKGtUMZQNHMOEXzZfHaLPpMYDbpJDloomzRVSduvvtJeIoaKWTdwlgpDttkOCWGJVbrySDvVnksbWlhdRQxYGblHkeFkfEJgmyNtFLByaOfcsxoaWkzyaRoPQIOXAsjUuTgJuNMxYnGSuRumnpNgSvAEmhcbRBE");
    bool jyceReZzNrG = true;
    string DnnbyjVAOBroBOH = string("fpLGpwgXhoAnZNgxERNhavpATihxbWFNXvgkTbEOpVwcmWYIDCLWpyiksXMXOkbtfJjxwlQKzjZKNwguyIbLdxJCWfNUNqnEYqUyvZPFHSpbtWPrzUmCBFmNfpQqPewMbUoGmULLLNDHjsBaUmWRecTaceHuiJkKdJrC");
    double MGyPCaQonN = -467409.7299839248;
    int fxTKLhvNDnFOEDu = -104929500;
    double qelPRu = -553858.5976528963;
    double uaZbU = 671218.1870010421;
    string zHXXW = string("dUsaKmqjqZivqkFoSQQDCiipEyxyciUppDUmSVgHZcgRoSFYtTPHCLmuMEaonnOaeizhGJqjhgfsipGjTsfTvqjsWIYwixKLpRgHDtsjYhckTZqnUnoVWQOzVbAAuEKtUnguiZryJBqpNfLaCtSnlXFfDCDltaAQpPLOPsrNlmDEgVuKyZXPNxgbmziYVPFLAZTXcZuiHqGUjUvnurKkuagRKTCNKYOVYan");
    string bRMhGG = string("QofQlfNPgpuIsqSwEjpNqEULTYflJTpaJoSdsfgBBMcoTSGiuavtmgGWWhwhxYTCYLMxhrBPKihSFDYpttNVDNawQBhUcLvEiiCBkQdfmIzhjWzuKtslRdEFFcPQqcWvzVRbKJXBGVKrhibI");
    double JVnMoOXUgURhAWxw = -78320.98585223696;

    return bRMhGG;
}

int QHVfefsa::ueilxqaN(bool NuGvRiGhiuwQppDL)
{
    string fWQzZIGxbAXZdrT = string("OSCxMWmnFJzxXncFlwQEcVSitnfgHnFpRXCxUGlbHuSrdQkFQPdflikkScCrxbfYTKXpDepdvXcfAdKXwWDFYzzeDvCqaDNPFjbEABjOeuXTFVIHQhGViaaXINEUqUNYJIfkFriFqrR");
    string hEaFJliCqbHJAcS = string("iqXnQAcKcjlECuJfivKYbjSBCCTEcVOadVTCtbeloHXGxwSYILcNnSukFYqIjChCjhUzyDcpEwVmkDrkOkctynpAFjJJHbAhdZrGepCjbzLINAFZNeMePZizPLcVhekoaReMWJWJwaLZBxagwdidfnypJtWrozsAuwMLGNxbLRApHpGOBmCFAQMA");

    if (NuGvRiGhiuwQppDL != false) {
        for (int sZEQgibM = 1199350297; sZEQgibM > 0; sZEQgibM--) {
            fWQzZIGxbAXZdrT = fWQzZIGxbAXZdrT;
            fWQzZIGxbAXZdrT += hEaFJliCqbHJAcS;
            fWQzZIGxbAXZdrT = hEaFJliCqbHJAcS;
            fWQzZIGxbAXZdrT += hEaFJliCqbHJAcS;
            NuGvRiGhiuwQppDL = ! NuGvRiGhiuwQppDL;
            hEaFJliCqbHJAcS = fWQzZIGxbAXZdrT;
            hEaFJliCqbHJAcS += fWQzZIGxbAXZdrT;
        }
    }

    if (hEaFJliCqbHJAcS >= string("OSCxMWmnFJzxXncFlwQEcVSitnfgHnFpRXCxUGlbHuSrdQkFQPdflikkScCrxbfYTKXpDepdvXcfAdKXwWDFYzzeDvCqaDNPFjbEABjOeuXTFVIHQhGViaaXINEUqUNYJIfkFriFqrR")) {
        for (int HocUqf = 1882399419; HocUqf > 0; HocUqf--) {
            fWQzZIGxbAXZdrT += fWQzZIGxbAXZdrT;
            fWQzZIGxbAXZdrT = hEaFJliCqbHJAcS;
            NuGvRiGhiuwQppDL = ! NuGvRiGhiuwQppDL;
            fWQzZIGxbAXZdrT += hEaFJliCqbHJAcS;
            NuGvRiGhiuwQppDL = ! NuGvRiGhiuwQppDL;
        }
    }

    if (hEaFJliCqbHJAcS != string("OSCxMWmnFJzxXncFlwQEcVSitnfgHnFpRXCxUGlbHuSrdQkFQPdflikkScCrxbfYTKXpDepdvXcfAdKXwWDFYzzeDvCqaDNPFjbEABjOeuXTFVIHQhGViaaXINEUqUNYJIfkFriFqrR")) {
        for (int AIwVepIJzXJ = 939667826; AIwVepIJzXJ > 0; AIwVepIJzXJ--) {
            hEaFJliCqbHJAcS += hEaFJliCqbHJAcS;
            fWQzZIGxbAXZdrT += fWQzZIGxbAXZdrT;
            fWQzZIGxbAXZdrT = fWQzZIGxbAXZdrT;
            hEaFJliCqbHJAcS += fWQzZIGxbAXZdrT;
        }
    }

    for (int DHXIoxOUhLIouxme = 1308307902; DHXIoxOUhLIouxme > 0; DHXIoxOUhLIouxme--) {
        NuGvRiGhiuwQppDL = ! NuGvRiGhiuwQppDL;
        fWQzZIGxbAXZdrT += fWQzZIGxbAXZdrT;
        fWQzZIGxbAXZdrT += hEaFJliCqbHJAcS;
        fWQzZIGxbAXZdrT += fWQzZIGxbAXZdrT;
        fWQzZIGxbAXZdrT += hEaFJliCqbHJAcS;
    }

    if (NuGvRiGhiuwQppDL == false) {
        for (int yieuqHQ = 429538496; yieuqHQ > 0; yieuqHQ--) {
            fWQzZIGxbAXZdrT += hEaFJliCqbHJAcS;
            hEaFJliCqbHJAcS = fWQzZIGxbAXZdrT;
            fWQzZIGxbAXZdrT += fWQzZIGxbAXZdrT;
            NuGvRiGhiuwQppDL = NuGvRiGhiuwQppDL;
            hEaFJliCqbHJAcS += hEaFJliCqbHJAcS;
            fWQzZIGxbAXZdrT = fWQzZIGxbAXZdrT;
        }
    }

    if (hEaFJliCqbHJAcS <= string("OSCxMWmnFJzxXncFlwQEcVSitnfgHnFpRXCxUGlbHuSrdQkFQPdflikkScCrxbfYTKXpDepdvXcfAdKXwWDFYzzeDvCqaDNPFjbEABjOeuXTFVIHQhGViaaXINEUqUNYJIfkFriFqrR")) {
        for (int LjDZVcoe = 1047859062; LjDZVcoe > 0; LjDZVcoe--) {
            NuGvRiGhiuwQppDL = ! NuGvRiGhiuwQppDL;
            hEaFJliCqbHJAcS += fWQzZIGxbAXZdrT;
            fWQzZIGxbAXZdrT += hEaFJliCqbHJAcS;
        }
    }

    return -463769224;
}

void QHVfefsa::kcABPHRYW(string tIJuzVqNCKEvdQ, string JZTLrryULigliGm, bool PySSaXOjRkT, int EFJvvTQRwSxBbimQ, double dTEOGcUaCq)
{
    string RKEMh = string("iUvwmmWqbdHReGVoNXYuwzWARzDAjBoqPCSskMgsoTxVzhgNqJOxzlfWGDwDJklYEqIVeUXRNNSlcprFnfVyYtVeisxKrhJobRcvMWoAJfZnXleXOBOCObhvFBOLFMOaDiAhWxapTsRYeRd");
    double TXwdZThFfGajvX = 275095.1971879238;
    bool bJeMQiTJBn = false;
    bool JBpnyGVscpxuiNbW = false;

    if (tIJuzVqNCKEvdQ <= string("ufpCVRkNISsolRjCuYfVGZuqeKWbpJaMYwmrXIkwEUXyEFqBcGilaiiEcWFQxqAQvuhxQJyXYJGaYnZJgVNTGUXKILlmDIWdtufsKzzsptOkffSsbWHhWVyqYQCtXDMkLdPkphnMRiEELNIjTDVSOhONONQAQQtDVCWKTFLLVTjxchzfquZZOrKdVn")) {
        for (int fXVTsCMmUsLw = 1735261133; fXVTsCMmUsLw > 0; fXVTsCMmUsLw--) {
            tIJuzVqNCKEvdQ += tIJuzVqNCKEvdQ;
        }
    }

    for (int JtOngbTFfb = 1294533016; JtOngbTFfb > 0; JtOngbTFfb--) {
        RKEMh += tIJuzVqNCKEvdQ;
        JZTLrryULigliGm += tIJuzVqNCKEvdQ;
        JBpnyGVscpxuiNbW = ! JBpnyGVscpxuiNbW;
        RKEMh = JZTLrryULigliGm;
    }

    if (JBpnyGVscpxuiNbW != false) {
        for (int QSJlzh = 654259141; QSJlzh > 0; QSJlzh--) {
            tIJuzVqNCKEvdQ += tIJuzVqNCKEvdQ;
        }
    }

    if (JZTLrryULigliGm < string("dBRSnjetEpVafzbiwNaMuTyDhrGxYQHCWSDalqsXMpznOkKPMpgbwEaoKAQGihFVlbGXZMTjtZmjDhEfjTxPADXIfapvgRnGxrDdewreYkvWVXeZJclKjVhOJgbWxtWRCNlfJIImImoGqgTgtvbIzSVhYeFUIcAgQoXUklDOcpIGtjyMcPsjUDZfBce")) {
        for (int VzwSyZyruAAosSVl = 2054198284; VzwSyZyruAAosSVl > 0; VzwSyZyruAAosSVl--) {
            continue;
        }
    }
}

string QHVfefsa::cOMcKqOhpjBvWlZA(int PzXMwnrWTAHnuiV)
{
    double QRrnuLAOkaYYQWju = -883291.0102960058;
    int HEQvIgkyTsMqb = 1888749071;
    string QoPcixu = string("QZLOAsDfgnqtceKqdOuEOGMDZZPxDtPhPKVRFtaZBNErvxjsLUCSuirrcPmuCyXkjvbreMRMsLNMsFPsWSaukvOzkWqNtHfTJTaqUqckfKkSijhwLwqhSNoivuFMitdyRhbwTwBFWeMsYCjHabGqZBPRhdTXpposnjhvUAzyKZPCIgzashVOfQPYqZIEiBeILQDGglETkVO");
    int jzrjiGSblapN = -779389592;
    double rBkfswjQjN = 967563.9183247763;
    bool STTasTISf = true;
    string xezMqkFjINMlcklE = string("vSkkGTyKgphcVcnlFekRAoscESnrVFWCqzWvCplOOQlRRtIaTezwxcWlhsqCvjwdlAkBzrzvOJDnnxeFtobQ");

    for (int tJINp = 1187192704; tJINp > 0; tJINp--) {
        jzrjiGSblapN -= HEQvIgkyTsMqb;
        QRrnuLAOkaYYQWju = QRrnuLAOkaYYQWju;
        rBkfswjQjN -= rBkfswjQjN;
    }

    return xezMqkFjINMlcklE;
}

double QHVfefsa::yaVqNufFQbR(string kcLBbIeKgzJUw, string FfUUU, string iWBWDSP, int HJdWiuvieDwnx, int HUgbauf)
{
    double SLKVTjyYnuhDq = -339606.7704973708;

    for (int zsbhj = 457068018; zsbhj > 0; zsbhj--) {
        iWBWDSP += FfUUU;
        HUgbauf -= HUgbauf;
        FfUUU += kcLBbIeKgzJUw;
    }

    return SLKVTjyYnuhDq;
}

string QHVfefsa::uUopk(double AMwvQNzxT, bool kgBWrKqNmBN, bool exdeSCRaRIwd)
{
    bool zeEkSmbhb = false;
    string iVUMmdqsB = string("vCsOG");
    bool rdpFWfrnsT = true;
    int MoAHpRQgKHPxA = -1472928040;
    string LglpFVGgRtC = string("GMNJLdCVvqsGxGMIxVjQLJdVTuKJojDJInDrVShlQbqxpNpozJISIXtkTihlvfUqeGTBbVYMtNnXxRRXBfLDYdQZthJuifsVezDrNUwCMLqMDSyKeeOsPOCbWLSYnBXTescGjGbLQpKLxvrsXaRcQCBBiEflRZLcXpaaDbbfXqcvW");
    int gdvExmjgrqAsS = -71671929;

    for (int srFnEeqQmuZ = 1127948664; srFnEeqQmuZ > 0; srFnEeqQmuZ--) {
        rdpFWfrnsT = rdpFWfrnsT;
    }

    if (rdpFWfrnsT == true) {
        for (int DFBOOPIKBgdz = 570710169; DFBOOPIKBgdz > 0; DFBOOPIKBgdz--) {
            rdpFWfrnsT = rdpFWfrnsT;
            LglpFVGgRtC += iVUMmdqsB;
            exdeSCRaRIwd = ! rdpFWfrnsT;
        }
    }

    for (int HfWzruKd = 890025123; HfWzruKd > 0; HfWzruKd--) {
        exdeSCRaRIwd = ! exdeSCRaRIwd;
        exdeSCRaRIwd = rdpFWfrnsT;
    }

    for (int ZMRMACMbzUdRPK = 600485318; ZMRMACMbzUdRPK > 0; ZMRMACMbzUdRPK--) {
        continue;
    }

    return LglpFVGgRtC;
}

double QHVfefsa::taJLlGjhgD(double SgKRsEbInQjNAHk, int XgTXIkrldgDNb, bool DbwYoOH, bool LGHcXmgF)
{
    int PmRRbIBCIKgNxFJ = -1428320532;
    double NalsdY = 458185.017338654;
    string mTtreyrliYOG = string("DLyqzHCBaAwzXDDUrtaJkIyoojvEIHckdxWMbgzuSoBpQDnODEjqPemSpxLBwplxrQrztWBDAGgKcPocFoZbtNOIybeVdFhVzypOYGddvnytMZPZCNPrygytoWDEoxVbmxTggTksLuhMQUaJyXJxzFCeyPIQegBwGecyutZjfnMRWVQBxkjAkGINuVWsSyiRwBopFZFNqCKtoYbaXlGuPVqSWEknIrijoBUyYamaxQZuwNBPZUwDLa");
    string EfNGkHxtmSSDwVaq = string("juTaapePaC");
    bool thqNTLLlZGmFFj = false;
    bool AyJGNPoKWXoAeaqs = true;
    bool JMcpBygILlueuKGd = false;
    double ijseczhk = -539356.0811579007;
    bool fFLboINBYI = true;
    string rVKzeHfsJ = string("zRrQVrEXeZySdksMKvnjuDVjjXciWgCRVCUqcbtuWuqBvvVPWawlDRU");

    if (DbwYoOH != true) {
        for (int yFAksOoV = 229815697; yFAksOoV > 0; yFAksOoV--) {
            JMcpBygILlueuKGd = DbwYoOH;
            rVKzeHfsJ = EfNGkHxtmSSDwVaq;
            EfNGkHxtmSSDwVaq = mTtreyrliYOG;
        }
    }

    for (int lDxqFxZ = 897047576; lDxqFxZ > 0; lDxqFxZ--) {
        SgKRsEbInQjNAHk *= ijseczhk;
        thqNTLLlZGmFFj = AyJGNPoKWXoAeaqs;
        AyJGNPoKWXoAeaqs = AyJGNPoKWXoAeaqs;
    }

    return ijseczhk;
}

void QHVfefsa::AYuLYYtckAYV(string rWMABhjyKrVaVTq)
{
    bool ocxhLcFTk = false;
    string yLPzFPdQwnJ = string("mkqReGCqZgXMvVxyFbTqQoztgHXnPjZtgzGtIrqMDaRoVVrePKplyQKqmRBCojbOJKJEXUBPyIMlyZppNtIPomipFETlbHAHAAQXCRCXTqVtPBfwrNdKkbvDROHRvxSTZWVUUcbUQOLHohqOBnFschfGFXMUtcZoqTgDMDKdwAQFikAzgiKmIzkzaQDLSssoxMtx");
    bool KqneUxCyRBYhfA = true;
    double ALKIiOQddErvoN = 648093.487430002;
    double fkeCmBkAnPRuOk = -610109.9039803981;
    string XjEiJFKA = string("cnqGQLLMryNnQBHyukzcZVOZNdQYWUBpElZkjAEAfvnKWmQAtejKDuygLPkyqMoqsk");
    string uhpwurxRBCKqPD = string("DibfAyvmfzVaqNNlRVsCuIeHvNzqyStOjayevkOABjGdoiiLhXywtFtDKRRWObIdYCOgjEyDDwUcKEuakWMtpLlMRaCdoDaBbZAxdXxwOUsbQyVwRvxIhezBnUtHVJUgEKFMsRirXYGuEYbeEdLRmYtlGgGhzntrtOCecQfeUYXHfOud");

    for (int MYMFk = 2101795876; MYMFk > 0; MYMFk--) {
        fkeCmBkAnPRuOk /= ALKIiOQddErvoN;
    }

    for (int jVVsRiFgI = 1446848643; jVVsRiFgI > 0; jVVsRiFgI--) {
        fkeCmBkAnPRuOk *= ALKIiOQddErvoN;
    }

    if (XjEiJFKA != string("mkqReGCqZgXMvVxyFbTqQoztgHXnPjZtgzGtIrqMDaRoVVrePKplyQKqmRBCojbOJKJEXUBPyIMlyZppNtIPomipFETlbHAHAAQXCRCXTqVtPBfwrNdKkbvDROHRvxSTZWVUUcbUQOLHohqOBnFschfGFXMUtcZoqTgDMDKdwAQFikAzgiKmIzkzaQDLSssoxMtx")) {
        for (int OgXosccobVTKYg = 1796000538; OgXosccobVTKYg > 0; OgXosccobVTKYg--) {
            rWMABhjyKrVaVTq = uhpwurxRBCKqPD;
            KqneUxCyRBYhfA = KqneUxCyRBYhfA;
        }
    }

    if (KqneUxCyRBYhfA != true) {
        for (int awzEFvmaVfbFoKrW = 1406650001; awzEFvmaVfbFoKrW > 0; awzEFvmaVfbFoKrW--) {
            continue;
        }
    }
}

double QHVfefsa::eaXHzHufhaC(string rjytKhnc, double snnsRWSjVC, bool IAoKWAVearEQZ, bool nxpxeIKDdlFkGFZM)
{
    bool JozJdcySZMtAcHrk = false;
    int lcxgKdtRX = 826196688;
    double RivvQwWKCQU = 613700.9665668003;
    string zCOLYdiz = string("NoBSPHriPWvjZkgW");
    int jVjIkWeIWO = -455106351;
    int JWBavgW = 69463998;
    string xeuJbYPLcr = string("GVatlPprbqKQQoVUnvtidaNXkkfXfwEyzatfnKwrVMkyodrnzukzAyEbxWsCCvProRoTBRhVPPLXjUpkvgrMYbeGeoKRSEF");

    for (int oJcBH = 571985445; oJcBH > 0; oJcBH--) {
        JozJdcySZMtAcHrk = nxpxeIKDdlFkGFZM;
        JozJdcySZMtAcHrk = nxpxeIKDdlFkGFZM;
    }

    for (int RmQJswFiL = 1555159937; RmQJswFiL > 0; RmQJswFiL--) {
        continue;
    }

    for (int NLRVJIwf = 1616194400; NLRVJIwf > 0; NLRVJIwf--) {
        nxpxeIKDdlFkGFZM = nxpxeIKDdlFkGFZM;
    }

    for (int UpoBGiiGHVNFbdYW = 1071208297; UpoBGiiGHVNFbdYW > 0; UpoBGiiGHVNFbdYW--) {
        IAoKWAVearEQZ = JozJdcySZMtAcHrk;
    }

    return RivvQwWKCQU;
}

int QHVfefsa::ygTrlcDBN(bool LopMTUZvyFMzA)
{
    double vfDYJ = -275416.0951565721;
    int XWSrKAIRbno = -19265294;
    double tbdHEkXEy = -329159.9684218181;
    bool ymGShfZOc = true;
    bool idjswbrmvdTFHJS = false;

    for (int JOJgTvwrkB = 703405928; JOJgTvwrkB > 0; JOJgTvwrkB--) {
        ymGShfZOc = ymGShfZOc;
        idjswbrmvdTFHJS = ! ymGShfZOc;
        LopMTUZvyFMzA = idjswbrmvdTFHJS;
    }

    if (tbdHEkXEy >= -329159.9684218181) {
        for (int bLPusQrOntjLZZ = 6068999; bLPusQrOntjLZZ > 0; bLPusQrOntjLZZ--) {
            LopMTUZvyFMzA = ymGShfZOc;
            LopMTUZvyFMzA = ! ymGShfZOc;
            LopMTUZvyFMzA = ! ymGShfZOc;
        }
    }

    for (int IGrtsMGlx = 900109787; IGrtsMGlx > 0; IGrtsMGlx--) {
        ymGShfZOc = idjswbrmvdTFHJS;
        vfDYJ -= vfDYJ;
        idjswbrmvdTFHJS = LopMTUZvyFMzA;
        LopMTUZvyFMzA = ! ymGShfZOc;
    }

    return XWSrKAIRbno;
}

string QHVfefsa::stLqnnLihUERun(string NVVhdo, double qgeXW, bool LmoaNKPAxByPlbh)
{
    double DfTsMcVTYsTv = -971113.4108684219;
    double vXzkun = 449426.0454644881;
    double CxKYnX = 278354.30458733113;
    double FHyVUApRSPSTIJUY = 983183.2852642287;
    string NRxGC = string("dGVVuXyqLLqfJEDkbQuubYryEkmmaYznvJGDYNfpAxDnYDaKRhhndSPNUyEdHKaBxtUqiUGWuScdUjaZXBodGaEkwHpMBQgMdAXRXfdPIObCGjEaHKNaFXhZwpmvsRzEoUHpTbiZrveRrdZzCTEhdZkrLvfxIPbXmmgTaOPzqHeGSYGNocglcSYiuatkOLSYeTwDtxzZxPHbrt");
    int oQCoPgLI = 955586833;
    string wrrATQPc = string("veBzyrOvaRObtGZhjxmmlNavuluGGJkkLlLUmvZeXFSCMyRfCmVSglEoJzNNnquxAdZwYuOtZzGijVOmSvePjpHMuLHbVMnFPrMVHLMGTTqFcq");

    return wrrATQPc;
}

QHVfefsa::QHVfefsa()
{
    this->crelBwZxbtBGBHfk(-532398.1791478605, 275159979, -384642675);
    this->hpDFInhCb();
    this->lAjNotedATaTtqB(538226.3079380913, string("Doqf"), -313183.05568047997);
    this->qBDUmksxotbZpr(string("OHBjKnMoRNytngmsIedcrmsxGjXMZXoxDtEYWLXwobaYBkuBLKVlaZTihUUUxYuEpAav"), -1887848167, 719103.472664633);
    this->CpdXnEuyNTF(884719.3734715143);
    this->ksYft(1232652602, 780651.7776359176, 862179.0776775975, false);
    this->rKNeoOEsM(-416547.31074340496, 1365829734, string("kbmBcFcKFyoyJKUbJkMRmdwjuSsaULYfTGqlfjiuayzQTsLIbeWwtrqMUhodikeUjzpWkMvkrasZIbguiVKtKAZcdieZgrcEEfaITuIEZUgYeNkrtEXcupNWEQEhXDvcjHkDfCFCWvBfyCJmCkKehzMrvsKnkiuDSOFChCJWwUzdqlZWPZQsDoXLlKLnHVRHvAXWMMXGoRW"));
    this->sbUWo(true, -310763.23935786146, string("AJAwLZSBNAZkOhdSwccsHhnbwLJpQkUMxTTJOJAjQBBmwbmPiqdEBHsRrLfvhcPmzdlptgvHunfREhTofzMnccehMbuDuulv"));
    this->VzTxUXzUjmyvNOv(-183974679, string("ByFRxKuGCFtoPvAvHrgYRjGitxKsIDsDhDxWWWjsGTiWkqikBFHSjDzLlBuyoBFskpSJlQMcSOIRhmkSkXJsRea"), 556994.4968753158, 333990.80757984257);
    this->ueilxqaN(false);
    this->kcABPHRYW(string("dBRSnjetEpVafzbiwNaMuTyDhrGxYQHCWSDalqsXMpznOkKPMpgbwEaoKAQGihFVlbGXZMTjtZmjDhEfjTxPADXIfapvgRnGxrDdewreYkvWVXeZJclKjVhOJgbWxtWRCNlfJIImImoGqgTgtvbIzSVhYeFUIcAgQoXUklDOcpIGtjyMcPsjUDZfBce"), string("ufpCVRkNISsolRjCuYfVGZuqeKWbpJaMYwmrXIkwEUXyEFqBcGilaiiEcWFQxqAQvuhxQJyXYJGaYnZJgVNTGUXKILlmDIWdtufsKzzsptOkffSsbWHhWVyqYQCtXDMkLdPkphnMRiEELNIjTDVSOhONONQAQQtDVCWKTFLLVTjxchzfquZZOrKdVn"), true, 1641627020, -797422.2049768859);
    this->cOMcKqOhpjBvWlZA(-1091732416);
    this->yaVqNufFQbR(string("QVUVCKgqcrcrPStjdSahqDHwaFhzMhzYUKsjtHVLVWu"), string("OCogmzlWHUfZvTcmhtvLJhOhlhMaMHGiFLXiROZrtRWvkYkhWZXFunvdKKHeqrTiUQGOXYfoyZYPnPfXVaoQfdoFTiSZnYrpkVaxnMBaSdRBjAgz"), string("HEqepguhgkZuhoCLrcfljUyHuQIkWXcHGkQTdT"), 987830593, 757926946);
    this->uUopk(518981.37256389396, true, false);
    this->taJLlGjhgD(852922.045080752, -1135061495, true, true);
    this->AYuLYYtckAYV(string("ygPVUQeTadFvgPfUaLybVqffKpSjMkYPgOClYeuZNxXPHkmDTleUQamdcOIyTRQwylSUvfOmutccFZeViSSIEHALnOz"));
    this->eaXHzHufhaC(string("eMgxivHnEmxJYcVAPbhirMXwsmWJKiplqJORaLDJNEQLgUVjWlmUGArYPctUZmCTLFlVfgJiuivLSDKdtOvseILIFaKnusgmWfAnkUfsBYILuaqcaHPRkPVBGaIotHtPjDIdRYodmqOmZbdZfxjdumfQmEyRMGpvrzVqGlxcjbboMqwvXkKyxMlcQdcTZihjmsqUHxXplXiRCNeCxeZAdMkYQ"), 144109.82015680996, true, true);
    this->ygTrlcDBN(true);
    this->stLqnnLihUERun(string("BxcPHLIqKaySdlNCRcVDQJizoayElIZqKjEYvNDZOpFTKCvFDFiPJIPzhPQUGdYuXqrpfrMJyMrEXPrVTyvYbJZXpojNGbcrMJuiKBuGypLcQeXKTjTaDzdsSuWEhKVyariUAsvZygW"), 706707.3095339873, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yyiLoQ
{
public:
    string IvpoIlMybhC;
    string HXHVSVU;

    yyiLoQ();
    string shubNJxm(string KjopZFSpM, bool bGOulrWcNK, string snLxySvHfWlYg);
    double VyhMYxq(int umser, bool DUVuA, bool kOUEIDFO, double YXGXWQ, int fkHmwlthgsZ);
protected:
    bool DfCkVoUh;
    double hIohVq;

    void puCwzZahEK(string JucxGKampUgfAz);
    int dsaOnLZoHcegQ(bool CQIcKEiMSQ);
    int AVxLC(int OrfRpOc, int LyGTOTqApBhLqQit);
    string gVlvUNFdPgMjBLyp(string ScKmwF, int ZgHbYqjVunxXNyo, bool TIgWBFoh, int PNOrscx, double EJPKSgzZWvcO);
    int IhotoMhtfri(string FoPDeGPFAqKzzdr);
    void qDiyHwJjtX(string TiKAMLB, bool BjiwhuwKrjMjWtc, bool IBfafaPHp, string ZqvKgBRECSOklj);
private:
    bool UAkdtlAh;
    bool IaqePxTSV;
    bool XMRicz;
    bool LqVSsuYWzRJUusI;

    double nkiztRbiHaXOcWWL(int ZPJxMDwXSUjSI, double OBLYn, int iFuYpFWiicvq, int YgQLoTCJkypDErZw, int CKjJaaKAQ);
    string VhBHxCxlfiEw(int BTcqgbTtzawcgwk, int GgqMdqUz);
    double sJlVSlnicb();
    int jKDTzdTl(double CsYBqFJA, bool wyYoKzkMMefI, int EZzztBVfY, int ETStMdjhujYanGM, double WIhVrzHgBHCjO);
    bool QsVFGOLExEdFRB(bool qmpEEherCjWICxT, int NUYAULakcrff, int pnjLDfUdI, bool RdOAqZwt, bool PYdwvWjjbeJQTr);
};

string yyiLoQ::shubNJxm(string KjopZFSpM, bool bGOulrWcNK, string snLxySvHfWlYg)
{
    bool CToYKsNDQlm = true;
    bool FkXMa = false;
    double glaLAdt = 911726.2828913644;
    bool rtFIzlRYyGdxyplo = true;

    if (FkXMa == true) {
        for (int DhZqVNePJAfAZ = 859691679; DhZqVNePJAfAZ > 0; DhZqVNePJAfAZ--) {
            FkXMa = ! rtFIzlRYyGdxyplo;
            bGOulrWcNK = ! CToYKsNDQlm;
        }
    }

    for (int yPWijCKDkDKL = 1354336794; yPWijCKDkDKL > 0; yPWijCKDkDKL--) {
        FkXMa = bGOulrWcNK;
    }

    if (FkXMa != false) {
        for (int LKGGYn = 302402900; LKGGYn > 0; LKGGYn--) {
            snLxySvHfWlYg = snLxySvHfWlYg;
            FkXMa = FkXMa;
        }
    }

    for (int LAhmrbGSN = 1384603004; LAhmrbGSN > 0; LAhmrbGSN--) {
        bGOulrWcNK = ! rtFIzlRYyGdxyplo;
    }

    for (int mchHZmQresixSx = 550685805; mchHZmQresixSx > 0; mchHZmQresixSx--) {
        rtFIzlRYyGdxyplo = FkXMa;
        KjopZFSpM += KjopZFSpM;
        bGOulrWcNK = ! rtFIzlRYyGdxyplo;
    }

    return snLxySvHfWlYg;
}

double yyiLoQ::VyhMYxq(int umser, bool DUVuA, bool kOUEIDFO, double YXGXWQ, int fkHmwlthgsZ)
{
    bool AINwV = false;
    int zRaZvqt = 102139203;
    int NUYyZFiDCK = 1041745438;
    int PqNOP = 687312220;
    string jtsdCL = string("ROjEmNDzgUPJboQGUwYaXZJDrSRgQDjaqsmJeyPiKXZhwZErpcyCHWyCMIMEfulTqrAsXgQsiJQWBqAIiqiAhzACyKggYUjFfhMjsFhHlCEJPPAwxyhIYGHqLEzHtjqMEemCfkOlaJj");
    double qzHekm = 1032139.361740469;
    string fcmyPbTZCM = string("MYicBbzTnMztKIrDdduwPwvxxSEfcWKZQXBzBTwirsexSMNvrHSlQYkljFXAqIbjrlddZRgrtAFdnWZeWVGNKGNZwsMlIBxcNBzzEpdrnWnjgkqAPUPfJznkYkCgEZHsnXTzdArnipHBhXBlZKfScucHY");
    bool tLbzfGbpTcXjiY = false;
    double XRFkV = -1043768.015429654;
    string vwhKPaBXnd = string("jRvfmjwXPWGLHWeezIQPXhESUMQuNVVvMQAOnEDxVGjqNPBAfMkLrhtBzbxnABHPzrHLcLPgqUQMsvylFIhaXIQCVxXyVkaoBGrfpKdQxJuSPmFSpjKRRDCCXlgkDFepBbfUrXSPYnWFxnqpUbmnBMLneRmIkZFUdXMoMLLvXyaqvoQZfkpUWRQNYvYhcwCLvGKTGxsxLAWwBEvRcfrdXzjQTyFTsPdUGbGkfqfVGWQy");

    return XRFkV;
}

void yyiLoQ::puCwzZahEK(string JucxGKampUgfAz)
{
    bool lgIqovlNOISAGT = true;
    bool HKrtWnnAp = false;
    bool iHiyRdTUXgPv = true;
    bool JXXwWClZmlaU = true;
    string QLELbBcnfX = string("AgWzRLzermDEUiWnlFRCZkwbrsMiNsnUYSjHFCCyBHNxJvkVGCdnZOHviJlHTCCBwIxUqkzaOdKFBdifUHeqWIhYuiHUQijgvHpwUAPBkOUkVroMChXsfXmKpiIyjBqHcYbUvtwviaQEMKEtxRkBrwqNisGcnrbLRlyppbQjnpvjzVmNvRZqevquYvUcaioPNUpcgGcWXSasQydjijQycQDCxEjxzTnqLorZTuxxPIahWu");
    string hQSpXldXcfClVwDv = string("UlDAzyRWMllfLhTvWkOCdXyGcwKBUoJwpWgcOcqMKHhnoPKbEyhlYiFHddiaeg");
    bool shKQBt = true;
    int mozyUpJq = 679163468;

    for (int giYZrC = 1048876784; giYZrC > 0; giYZrC--) {
        JXXwWClZmlaU = lgIqovlNOISAGT;
    }
}

int yyiLoQ::dsaOnLZoHcegQ(bool CQIcKEiMSQ)
{
    bool TsYJPI = false;
    bool nGKreQBd = true;
    int opCekn = 1821134662;

    for (int EtepHi = 1695424831; EtepHi > 0; EtepHi--) {
        nGKreQBd = TsYJPI;
    }

    if (CQIcKEiMSQ != false) {
        for (int mBZCjV = 707533781; mBZCjV > 0; mBZCjV--) {
            CQIcKEiMSQ = nGKreQBd;
            TsYJPI = ! TsYJPI;
            nGKreQBd = TsYJPI;
            TsYJPI = ! nGKreQBd;
            TsYJPI = CQIcKEiMSQ;
            CQIcKEiMSQ = TsYJPI;
        }
    }

    if (TsYJPI != false) {
        for (int dnfjAuoCsuLLSy = 749494719; dnfjAuoCsuLLSy > 0; dnfjAuoCsuLLSy--) {
            opCekn /= opCekn;
        }
    }

    if (CQIcKEiMSQ == true) {
        for (int NskoymFSstwR = 1283870526; NskoymFSstwR > 0; NskoymFSstwR--) {
            TsYJPI = ! TsYJPI;
            opCekn -= opCekn;
            nGKreQBd = nGKreQBd;
            opCekn /= opCekn;
            CQIcKEiMSQ = CQIcKEiMSQ;
        }
    }

    if (CQIcKEiMSQ != true) {
        for (int ypcIhsjFXOclMzY = 899430892; ypcIhsjFXOclMzY > 0; ypcIhsjFXOclMzY--) {
            CQIcKEiMSQ = nGKreQBd;
            TsYJPI = CQIcKEiMSQ;
            opCekn -= opCekn;
            CQIcKEiMSQ = ! TsYJPI;
        }
    }

    return opCekn;
}

int yyiLoQ::AVxLC(int OrfRpOc, int LyGTOTqApBhLqQit)
{
    int aedcoJxKV = 598926037;
    int URcBbjq = 1260221931;
    string cfmpP = string("LYHHHkCWUlmqoIwizYjKnINQWQovqaFlLuJHeQIhRBxmhTOvYKxLFrbHOOqAwuQNzhIpKYBaIXOtETlaAJoRGDDLIGlaWADBIKQZyQPCwpZjoFHYaKDRTfBxgoDkGxmTgDCrjlBUCKHkPGmyIYFWmlAZQqTwWBsUFQnWcMnTRtQaAXsyfTSUTrNcFNoxBaPqsqdCtlrbyUlMaEXFTnkBKiJuE");
    bool uOBtbybkDwHtklf = false;
    double xQgbOrmhZS = -309908.14075653214;
    string rDfxTHQvA = string("KamcsVuGYKQwpmuwuYukCEXRTafpqXnjWEyZoFrleWQumMSWGDgDDvZycqzNipRQxSiNipkQYafcJjSJjIVgZQtFhOyMVnsaFLRZxEApROhitmQjLzXAfzywSTohlXfSsBaWnzthleisgQtSJEpDfhxWSUwHZsqFCgWHWOvfEvadRJQrDDEaGAfunxkr");
    string eFPIa = string("bcimZVaRJrfzXojGHMYzjsGbzLOUakgnuAwgsPtiAAQqoXbtmfsMRBBEziqBkrWJHRGXbfqHaLFdktEQPfUKoTnsTrvahpwxjpbjAoRDIIlgoKGwFZHHIEPXwvaWKg");
    string gRMdOKV = string("kueJWvZwABmbqubPcNyKYLMdrggcmXjuoRjmUAnWjlvNGtaYEIiEcaoIsUrKghzyoNeAUUjtwVqOGnyvYmCEGIQNlsrPjSMdyziqiEQkkkVdYjerNGRzGGboEsbwnGDsRFjUolEIPkI");
    double AcbMy = -100860.01531610668;
    double QqxdoJhD = -309515.5054998031;

    for (int cZyLNiECx = 1139182368; cZyLNiECx > 0; cZyLNiECx--) {
        eFPIa = cfmpP;
        LyGTOTqApBhLqQit = OrfRpOc;
        QqxdoJhD /= QqxdoJhD;
        LyGTOTqApBhLqQit += aedcoJxKV;
        aedcoJxKV /= OrfRpOc;
        URcBbjq -= OrfRpOc;
        OrfRpOc += aedcoJxKV;
    }

    if (OrfRpOc <= 598926037) {
        for (int FAPrJ = 1439895484; FAPrJ > 0; FAPrJ--) {
            QqxdoJhD /= AcbMy;
        }
    }

    return URcBbjq;
}

string yyiLoQ::gVlvUNFdPgMjBLyp(string ScKmwF, int ZgHbYqjVunxXNyo, bool TIgWBFoh, int PNOrscx, double EJPKSgzZWvcO)
{
    bool cdoMwS = true;
    bool JVKexGSLNIK = true;

    for (int UheDsITrHxzmeFUC = 839103964; UheDsITrHxzmeFUC > 0; UheDsITrHxzmeFUC--) {
        continue;
    }

    if (ZgHbYqjVunxXNyo <= -1805776708) {
        for (int MggBrofoMSem = 2143428975; MggBrofoMSem > 0; MggBrofoMSem--) {
            PNOrscx *= ZgHbYqjVunxXNyo;
            TIgWBFoh = cdoMwS;
        }
    }

    for (int VXoFtpmJvaWqZV = 2120316911; VXoFtpmJvaWqZV > 0; VXoFtpmJvaWqZV--) {
        PNOrscx /= ZgHbYqjVunxXNyo;
    }

    for (int MXioyLCTZS = 1598957077; MXioyLCTZS > 0; MXioyLCTZS--) {
        TIgWBFoh = TIgWBFoh;
        cdoMwS = ! JVKexGSLNIK;
    }

    if (JVKexGSLNIK != true) {
        for (int OpssJM = 478797249; OpssJM > 0; OpssJM--) {
            continue;
        }
    }

    return ScKmwF;
}

int yyiLoQ::IhotoMhtfri(string FoPDeGPFAqKzzdr)
{
    double UUVqJDNcJgSGgvJ = 592341.2539937663;
    int DAWsMGgNUgrEsKQ = 36014925;
    int FFyIWRTxs = -1839819913;
    double edXEBlNT = 1002121.9092397728;

    for (int vppwNJyR = 122307699; vppwNJyR > 0; vppwNJyR--) {
        edXEBlNT *= edXEBlNT;
        edXEBlNT = UUVqJDNcJgSGgvJ;
    }

    for (int riTNNwl = 2037313737; riTNNwl > 0; riTNNwl--) {
        edXEBlNT -= edXEBlNT;
    }

    if (FFyIWRTxs <= 36014925) {
        for (int duqKGprWHSwyx = 840733224; duqKGprWHSwyx > 0; duqKGprWHSwyx--) {
            DAWsMGgNUgrEsKQ /= FFyIWRTxs;
            UUVqJDNcJgSGgvJ *= UUVqJDNcJgSGgvJ;
        }
    }

    return FFyIWRTxs;
}

void yyiLoQ::qDiyHwJjtX(string TiKAMLB, bool BjiwhuwKrjMjWtc, bool IBfafaPHp, string ZqvKgBRECSOklj)
{
    double eYvZhhAlE = 138870.0044885855;
    string hrAbeyUR = string("cMc");
    bool dLyibiErALC = false;

    for (int xrXOnJUHW = 1493277281; xrXOnJUHW > 0; xrXOnJUHW--) {
        hrAbeyUR = ZqvKgBRECSOklj;
    }

    if (dLyibiErALC == true) {
        for (int ySbkKPB = 890143571; ySbkKPB > 0; ySbkKPB--) {
            ZqvKgBRECSOklj = TiKAMLB;
            BjiwhuwKrjMjWtc = dLyibiErALC;
        }
    }

    for (int StIqAkEKGx = 717831909; StIqAkEKGx > 0; StIqAkEKGx--) {
        BjiwhuwKrjMjWtc = IBfafaPHp;
        hrAbeyUR = hrAbeyUR;
    }
}

double yyiLoQ::nkiztRbiHaXOcWWL(int ZPJxMDwXSUjSI, double OBLYn, int iFuYpFWiicvq, int YgQLoTCJkypDErZw, int CKjJaaKAQ)
{
    double hqUJYjJkAYMzwGT = -427417.6249109284;
    bool AWgBRgQYs = false;

    if (CKjJaaKAQ != 1630331722) {
        for (int RQrCKXSSqW = 232214821; RQrCKXSSqW > 0; RQrCKXSSqW--) {
            AWgBRgQYs = ! AWgBRgQYs;
            AWgBRgQYs = AWgBRgQYs;
            ZPJxMDwXSUjSI += CKjJaaKAQ;
            AWgBRgQYs = ! AWgBRgQYs;
        }
    }

    return hqUJYjJkAYMzwGT;
}

string yyiLoQ::VhBHxCxlfiEw(int BTcqgbTtzawcgwk, int GgqMdqUz)
{
    bool MkSet = true;
    int tVKJu = 2088332852;
    double BbxpYh = -394460.3291795185;
    double wADfwJDVCWfMqs = -1046596.7237140564;

    for (int btTLghy = 203438240; btTLghy > 0; btTLghy--) {
        GgqMdqUz -= tVKJu;
    }

    for (int CguvFUyYtb = 842580367; CguvFUyYtb > 0; CguvFUyYtb--) {
        wADfwJDVCWfMqs = BbxpYh;
    }

    for (int SBKVZYTIQK = 1910366342; SBKVZYTIQK > 0; SBKVZYTIQK--) {
        tVKJu += tVKJu;
        tVKJu /= tVKJu;
        MkSet = ! MkSet;
        tVKJu += GgqMdqUz;
        tVKJu *= BTcqgbTtzawcgwk;
        tVKJu += GgqMdqUz;
    }

    if (MkSet == true) {
        for (int qTNEw = 2049174245; qTNEw > 0; qTNEw--) {
            tVKJu /= tVKJu;
        }
    }

    for (int CnVQdbN = 1201527707; CnVQdbN > 0; CnVQdbN--) {
        BbxpYh = BbxpYh;
        BTcqgbTtzawcgwk = BTcqgbTtzawcgwk;
        tVKJu /= tVKJu;
    }

    for (int mdcSEASvXpW = 1762287927; mdcSEASvXpW > 0; mdcSEASvXpW--) {
        tVKJu = tVKJu;
        GgqMdqUz /= BTcqgbTtzawcgwk;
        tVKJu = tVKJu;
        BbxpYh = BbxpYh;
        GgqMdqUz /= GgqMdqUz;
        GgqMdqUz *= GgqMdqUz;
        BbxpYh *= wADfwJDVCWfMqs;
    }

    return string("yDGOMVldldJkYggPmxMnmsJAqhQsbKiFdSzPjFbRggAGROztlSItghgUUpJScFqOkjEijEijZYxlkksRDTRQpTjyrkhagsQDdBtWEvhICdFSgbVrtBYglIGrGKfQpDxymCWYjMserxiyCrfrYWiHUdzoOFHkGxCNgZFoAcPcKlJXXOdgMATLEVlbivxgMZILSSjzRyamdlLtObNrSCzfmnjqQcApJSxcCPgAtnjmtwyVAtlEpkkYPndXD");
}

double yyiLoQ::sJlVSlnicb()
{
    double wqiqo = 958340.849712242;
    int YhnhlsJwOmU = 720257897;
    bool CGzYxQyPAwdfSZ = false;
    bool MwbiVJMUTwgry = true;
    string GArHicwS = string("qAYSXdtXRUflTniddPNfubWncmChCNxhhrlnuQsl");
    string LdmjMVRzJtHLl = string("DHDZLpJGnzbhnQLJyYQdyXYMftkMQfolmqvylhyiZJvmG");
    int DRMFpMhdxh = 1734755990;

    for (int DEIRgH = 102504955; DEIRgH > 0; DEIRgH--) {
        continue;
    }

    if (DRMFpMhdxh >= 1734755990) {
        for (int pSBmfKkvFPo = 80991692; pSBmfKkvFPo > 0; pSBmfKkvFPo--) {
            CGzYxQyPAwdfSZ = MwbiVJMUTwgry;
        }
    }

    for (int qiwwsyWXRwZBm = 21931502; qiwwsyWXRwZBm > 0; qiwwsyWXRwZBm--) {
        YhnhlsJwOmU /= YhnhlsJwOmU;
        CGzYxQyPAwdfSZ = CGzYxQyPAwdfSZ;
    }

    for (int pMFvrXYwYMmaWSv = 1944330180; pMFvrXYwYMmaWSv > 0; pMFvrXYwYMmaWSv--) {
        YhnhlsJwOmU *= YhnhlsJwOmU;
        DRMFpMhdxh = DRMFpMhdxh;
    }

    for (int aRhpy = 1347818975; aRhpy > 0; aRhpy--) {
        continue;
    }

    for (int ubFDtksbQa = 307093415; ubFDtksbQa > 0; ubFDtksbQa--) {
        continue;
    }

    return wqiqo;
}

int yyiLoQ::jKDTzdTl(double CsYBqFJA, bool wyYoKzkMMefI, int EZzztBVfY, int ETStMdjhujYanGM, double WIhVrzHgBHCjO)
{
    int ugVxd = 283192110;
    double YOnwvB = -480330.3574706447;

    for (int VyuCsbS = 1478948168; VyuCsbS > 0; VyuCsbS--) {
        WIhVrzHgBHCjO += WIhVrzHgBHCjO;
    }

    for (int FJlScs = 992013450; FJlScs > 0; FJlScs--) {
        ugVxd *= EZzztBVfY;
        ETStMdjhujYanGM *= ETStMdjhujYanGM;
        WIhVrzHgBHCjO /= WIhVrzHgBHCjO;
        YOnwvB += YOnwvB;
        CsYBqFJA -= YOnwvB;
        YOnwvB = YOnwvB;
        CsYBqFJA /= CsYBqFJA;
    }

    for (int PoSrOYbqUgwyqm = 1740430551; PoSrOYbqUgwyqm > 0; PoSrOYbqUgwyqm--) {
        ugVxd = ETStMdjhujYanGM;
    }

    return ugVxd;
}

bool yyiLoQ::QsVFGOLExEdFRB(bool qmpEEherCjWICxT, int NUYAULakcrff, int pnjLDfUdI, bool RdOAqZwt, bool PYdwvWjjbeJQTr)
{
    int OkUQoeQc = -1520989491;
    bool QLEQkLFKIJwS = true;

    if (OkUQoeQc == -1520989491) {
        for (int SLeHd = 602118583; SLeHd > 0; SLeHd--) {
            PYdwvWjjbeJQTr = RdOAqZwt;
            QLEQkLFKIJwS = QLEQkLFKIJwS;
            qmpEEherCjWICxT = QLEQkLFKIJwS;
            qmpEEherCjWICxT = ! qmpEEherCjWICxT;
            pnjLDfUdI *= pnjLDfUdI;
            qmpEEherCjWICxT = PYdwvWjjbeJQTr;
        }
    }

    if (pnjLDfUdI < -1520989491) {
        for (int BVHfoA = 1856113038; BVHfoA > 0; BVHfoA--) {
            PYdwvWjjbeJQTr = RdOAqZwt;
            OkUQoeQc /= pnjLDfUdI;
            QLEQkLFKIJwS = ! RdOAqZwt;
        }
    }

    if (qmpEEherCjWICxT != false) {
        for (int iXFbsYJhiLUGjUQ = 1987840054; iXFbsYJhiLUGjUQ > 0; iXFbsYJhiLUGjUQ--) {
            NUYAULakcrff -= NUYAULakcrff;
            qmpEEherCjWICxT = QLEQkLFKIJwS;
            pnjLDfUdI += pnjLDfUdI;
        }
    }

    if (QLEQkLFKIJwS == false) {
        for (int oNXAsKhdFnmkSQr = 1408149106; oNXAsKhdFnmkSQr > 0; oNXAsKhdFnmkSQr--) {
            OkUQoeQc = OkUQoeQc;
            QLEQkLFKIJwS = ! RdOAqZwt;
            RdOAqZwt = QLEQkLFKIJwS;
        }
    }

    for (int XBHLiKKvItTnNxz = 1019838951; XBHLiKKvItTnNxz > 0; XBHLiKKvItTnNxz--) {
        pnjLDfUdI -= NUYAULakcrff;
        PYdwvWjjbeJQTr = ! RdOAqZwt;
        RdOAqZwt = RdOAqZwt;
        QLEQkLFKIJwS = qmpEEherCjWICxT;
    }

    return QLEQkLFKIJwS;
}

yyiLoQ::yyiLoQ()
{
    this->shubNJxm(string("NbiaLNdtdNpPWHXuAEnlfWVMxUwDJSowMRgeOZUKCywxHLfuKXnxZsCJxUdvsuiEVoJEnOMukXxrESYIHpKkAZXrDrotFdAKofEnOuokzmMwoNvIKPEcmAFACTeVyaGRMtuPwUtnRjNVXVkvVJaunzigpCYiJOUyjvFIHA"), true, string("GTxmzC"));
    this->VyhMYxq(-796309714, false, false, 424985.34427248844, 384942847);
    this->puCwzZahEK(string("ilVLQiQoKNBqa"));
    this->dsaOnLZoHcegQ(false);
    this->AVxLC(1460168876, 853844511);
    this->gVlvUNFdPgMjBLyp(string("YlPrcMwtJOpHsZnFnLjKRqgRHzjnLNiAlvjnZakoULBBBkZuUaUUlMulbRSXpMhBPZxSaSlSzoAshIhxRJQZvlRkaRYetGhSqznvgKapyfeMMvXjHKuLcTgboGKNvAfjBJsyRLyEprJXPmgMePncjirPpXRKfAmtmLmfFYYqleNIkCUssBfkYeXKfBFtRKRYdJJAWMsotpERJmkDmNnMUxCbtqGRWIFZRDbxFSyuacAQpMfavavEgoTtGWwlK"), -1805776708, false, -915930659, -39393.894372809744);
    this->IhotoMhtfri(string("ydbePMMvaRLtIrQcSmywZzQHRthLMZbZpsIEtNbCiBrwuvZTkgyKmXAmGPTpYHUnDRVBbpCPVpgchwQwEVZmmBekaoqDSwgYjlarDjXtpyLiImPOskfmmEprkLiHycqzNoxEFlOvHZOvYJXtdLcOrIlfFwqhCTIaGeeRVOpROYgWuLqLuyaXkTyJzrXlBSPzVZVUtBXJDUqeLQgRbJrvHgJJpaXXhxErbCSy"));
    this->qDiyHwJjtX(string("hLucweiAKXxsZyAfrJNgMSjkVkzCsrzlsuJQAEROuiMvEZyIRuSmkoEGSjoQgIAPeMqIBelUJMCKSRriFBeIUJkDLFlBWXKIwioFCKWwSpTekcZwYeyKXwLJuwaFnVLzuZxqZvSiQPSmwfjdJOgnnMgjDDRkklvTKypYuVXIgQBBAfBaHTtsouNWASHKQiKFMHZmtBjfwkFrSJlcELAtwgYWyfnafnwzTIBzCncxdAMoSYpQ"), true, true, string("mYDLpgchQTqJZgcrTlhxdSuVyYNutQkqoqOAmFShmQUvoKhIRWTyDDxvBMfOiFGdGsgGXzwDeUyRyjKoYYfBfnABgxpfGAcMDvqBboVyqKbCOuedyIxynorNhTYxCqnBbwYlAFTBLaWXx"));
    this->nkiztRbiHaXOcWWL(1531631293, 949907.8836647263, -1027220462, 1630331722, -500333927);
    this->VhBHxCxlfiEw(-929061625, -360785341);
    this->sJlVSlnicb();
    this->jKDTzdTl(628978.2779657762, true, 2122690473, -2111540290, 765669.4590076235);
    this->QsVFGOLExEdFRB(false, 244728109, -1777270724, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class doixorimkSNRAN
{
public:
    string KoGBsPUhsnXfrz;
    string kvbhHYxGdnFg;
    bool OiQJtuYdZ;
    string boFHrvTL;
    string UmXcwctmCXMT;
    int zTdbmiehsp;

    doixorimkSNRAN();
    double eOxgZQuBI(bool UjxeZvDBPWqeuxLp, bool dEtLgBdyT, string eiIzLetAWOLDcT);
    int eKqxdRNDaJhjVfO(bool TgoQWhNNtqo, int DFWzepeCDSKdrf, bool qjCuClArqToWFD, string TAwcTBILpq);
    int OmkNgTrvmTMB();
    bool ymOYkuvCwcf();
protected:
    double sPFjKJeBrkA;
    string SZWUBNmjHXtN;
    int ohxoEhgk;
    string BMuwZftWulRoC;
    string WECEvKMz;

    void GGIqMVBBPq(double JRfAyhb, double lpjcoPzbRB, bool akqPmMHQNOAtKwQO);
    int slfuWwTJBwIgH(string wXjDCqBT, double AKbhfpYIBpOE, double oOFTwbe);
    string OAYXbUNJRnUkn(double HcxqOElZqJ);
    string jiqVujXrJi();
    int bhBWkoWDrm(bool XXKZbomnJbrbKM, string OakyhkIhRM);
    string HVmLOZk(bool bHQPVaLUjjY, string RyJlEQIGWUoQzE);
    void KfIIyUt(bool GvlZm, double VMIKmDyFsbQulplJ, string cHCspFIWlsRhN, string lSEmciw, int gJEZhQdKj);
    string MJKLzbqhTMZvZII(double hRJmoXkBlbWwwOV);
private:
    double IWYSmhyNg;
    double QaQsbllPSpHqjHQ;
    bool IaMmjSykk;
    bool sUqsAMvHnikvUjv;

    bool eCZwZtkECxsQRbo(double naLjq, double zphDlYegnJDib);
    int QlKcVWBDCEDbSxa(double XSYguIoU, double EZeIXIYtN);
};

double doixorimkSNRAN::eOxgZQuBI(bool UjxeZvDBPWqeuxLp, bool dEtLgBdyT, string eiIzLetAWOLDcT)
{
    bool YEeBzfspTuJ = true;
    bool jKAubTE = true;
    double BZUGugvQATr = -143814.42507101997;
    bool oYlwwCrlK = true;
    double BfctIHNLoACPwW = 64440.017502789044;
    string AlSmtfmjJXInVH = string("eJjjBbIMuaOiAylyiEhOtHFNgiujByJsFKuRXHpHNvabUyopFcWklaPOtzKGEKSHzPVVsFkSkAvhMkdrHlCPlXuhETpLLeiEwqmouiUFCsaFAsBdKbZtWfrSxvlCD");
    double QaijzscxfAr = -600810.0864810161;
    bool lAnoxKJptwiIe = false;
    int qyXaOKqtqx = -13836692;

    for (int htDGrMlrBx = 2058512461; htDGrMlrBx > 0; htDGrMlrBx--) {
        oYlwwCrlK = oYlwwCrlK;
        UjxeZvDBPWqeuxLp = ! YEeBzfspTuJ;
    }

    if (oYlwwCrlK != false) {
        for (int oUjcd = 726156254; oUjcd > 0; oUjcd--) {
            continue;
        }
    }

    return QaijzscxfAr;
}

int doixorimkSNRAN::eKqxdRNDaJhjVfO(bool TgoQWhNNtqo, int DFWzepeCDSKdrf, bool qjCuClArqToWFD, string TAwcTBILpq)
{
    double lYGgZcGUFWzGN = 990115.2696042679;
    double zYpaGplsoOvmCiTH = 528133.0514492218;
    int CNUQRJiyHhYlQwoJ = 1680986109;
    double kiyXAPhYlqIloR = 1033483.3514280807;
    double jlzNpxBFCnckn = -629140.9307474822;

    for (int mWLZhaqInI = 1611438438; mWLZhaqInI > 0; mWLZhaqInI--) {
        jlzNpxBFCnckn /= zYpaGplsoOvmCiTH;
        CNUQRJiyHhYlQwoJ *= CNUQRJiyHhYlQwoJ;
        zYpaGplsoOvmCiTH = kiyXAPhYlqIloR;
        zYpaGplsoOvmCiTH *= kiyXAPhYlqIloR;
        jlzNpxBFCnckn /= zYpaGplsoOvmCiTH;
    }

    for (int mnwddBJpUdUfAS = 2011101215; mnwddBJpUdUfAS > 0; mnwddBJpUdUfAS--) {
        continue;
    }

    for (int lsimIa = 475984269; lsimIa > 0; lsimIa--) {
        jlzNpxBFCnckn *= zYpaGplsoOvmCiTH;
    }

    for (int SAzuOtRM = 604403863; SAzuOtRM > 0; SAzuOtRM--) {
        continue;
    }

    if (jlzNpxBFCnckn != 1033483.3514280807) {
        for (int wNUeVzjWRJpGstF = 882334646; wNUeVzjWRJpGstF > 0; wNUeVzjWRJpGstF--) {
            TAwcTBILpq += TAwcTBILpq;
            jlzNpxBFCnckn *= zYpaGplsoOvmCiTH;
        }
    }

    return CNUQRJiyHhYlQwoJ;
}

int doixorimkSNRAN::OmkNgTrvmTMB()
{
    string cCtepyFUycIcJF = string("nGWcmdXghtQdQyXxBOqMxclQmYSSrAknmAPUGUIPMKWIthVoeeiTWVhJEFNUasudhNyuwvSfnVgquZBJtbucBSGrrZWrhFMOJHqdywWYBMpqtbAuHifJWfjuvnOUryEqBlhoenHRsVuSQSGpDATIcxHXAtvRRjjKhlwwTWRefKxIQZTmWECqHRIAxpXuHWmGQlgcKeGffNqTtfYhQHiyJWqlNyJ");
    bool zrttWcXtpjfAbk = false;
    bool BotPSYlYJYnqZ = true;
    int OxQMsFUjjoDzNOk = 158832821;
    double YnxaueISMIRK = 994603.5769442653;
    int DhXpmABDKFQ = 1405767618;
    string CqrkwMyiOZm = string("MyADdVdZnbIjkHbPnCVuUOZhUiHtWVlZNVZQQVkwlqlLtdwkppYDTdhQrDEhYOmQTkzwpUveYESUFjNmUVBNespIbfHUahgsGNLlwTTNCopMRFuNxcEyEgItBwkiUyYsgmeMNgHIWlPlADclTtSrZMGgimHGmPeChbnwlxaCGWrHqHrYkypQQiWGBxDOMJTNBpiTyjCynrOjtKpYPSJRJoGZYAWGgVQFfqiXzHBBVHYyRYwdUcrsNnqrz");
    string UuYKEGEY = string("xeOciadxSdieYVandTCjjYGRzWQSKXzKQcNHfehWFOQuWxtUMcGPQBolicDcCFWGUJgGUHEImnGBvaadPGECbMsshSdfJIBauxpKbTDufCKmyEIzWNRctKpKkiyWFbmYCFkXRJZvgIHSxyvLLPDwqkfYwPvDNMXXfPyoqBnLVKQHSbfxFtyIjmgCcmZzpgCVnMsYkbjFFTJvHYfSityK");

    for (int rWqgKL = 788100759; rWqgKL > 0; rWqgKL--) {
        UuYKEGEY = CqrkwMyiOZm;
    }

    if (OxQMsFUjjoDzNOk != 1405767618) {
        for (int qMoldfOELqpikT = 1351115498; qMoldfOELqpikT > 0; qMoldfOELqpikT--) {
            continue;
        }
    }

    for (int xQkHBSelKB = 163120090; xQkHBSelKB > 0; xQkHBSelKB--) {
        continue;
    }

    if (cCtepyFUycIcJF > string("MyADdVdZnbIjkHbPnCVuUOZhUiHtWVlZNVZQQVkwlqlLtdwkppYDTdhQrDEhYOmQTkzwpUveYESUFjNmUVBNespIbfHUahgsGNLlwTTNCopMRFuNxcEyEgItBwkiUyYsgmeMNgHIWlPlADclTtSrZMGgimHGmPeChbnwlxaCGWrHqHrYkypQQiWGBxDOMJTNBpiTyjCynrOjtKpYPSJRJoGZYAWGgVQFfqiXzHBBVHYyRYwdUcrsNnqrz")) {
        for (int jlkBeO = 666678602; jlkBeO > 0; jlkBeO--) {
            continue;
        }
    }

    return DhXpmABDKFQ;
}

bool doixorimkSNRAN::ymOYkuvCwcf()
{
    bool DhhPmYwBEBiiPdQI = false;
    int xNHehb = -1645436065;
    string ZdgFmFotAUWgF = string("yrjb");
    int maUZvueagwSEr = -49966772;
    double BYveuLJHlMiaJf = -1015661.8643119571;
    int sHLkgK = 401313637;
    string lQFrIr = string("dTDFOtWHiwCbWyJuRDwnwrbQzzAkbEwXwAlhoyGEUprFRUrPmDAFGJMlPboGrNWYDyKNIOdjSXHzBMFnlEGTraTTQTJBUHUUElkAfWdBpeCOuMDGbthRDlqNvICXOomYwckGzyRLatbcPLmamjXQfEGDUJDbPqBvlwxtaOiLrxWRlmTqc");

    return DhhPmYwBEBiiPdQI;
}

void doixorimkSNRAN::GGIqMVBBPq(double JRfAyhb, double lpjcoPzbRB, bool akqPmMHQNOAtKwQO)
{
    double ybrILXRMnxkJ = 375928.9725341894;
    int SMYpyNoiQwCQT = 1269494187;
    double dvkmrkvso = -1022558.6064784867;
    string wmomEZiguSTYWB = string("jaRGuLBZiunjhyYdtDGfRQgGuzANYDYkpCvioyqotJYOfaIzApEckBYxxfhagQqZLhzfxEIVuCoVZsvBUeRNdlVlhCjDwgaIIajnncjFwanRCjThQmp");
    bool RsvaYyQvaLcVz = true;
    int fgreEnOgQILLKDQh = -912198700;
    int pUUiIxvhsdCTnUj = 1238929111;

    for (int CGmekxUcyHBeS = 983459476; CGmekxUcyHBeS > 0; CGmekxUcyHBeS--) {
        JRfAyhb /= JRfAyhb;
    }

    if (ybrILXRMnxkJ > 928102.4182178151) {
        for (int MdwTfaAGxsuFT = 516574039; MdwTfaAGxsuFT > 0; MdwTfaAGxsuFT--) {
            continue;
        }
    }

    for (int cNFJhvQyCfhvwbk = 2109430510; cNFJhvQyCfhvwbk > 0; cNFJhvQyCfhvwbk--) {
        dvkmrkvso -= ybrILXRMnxkJ;
        akqPmMHQNOAtKwQO = ! akqPmMHQNOAtKwQO;
        JRfAyhb = ybrILXRMnxkJ;
        ybrILXRMnxkJ -= JRfAyhb;
    }

    if (akqPmMHQNOAtKwQO == true) {
        for (int nKACadqRebknUGGH = 1719343262; nKACadqRebknUGGH > 0; nKACadqRebknUGGH--) {
            ybrILXRMnxkJ += ybrILXRMnxkJ;
            JRfAyhb += ybrILXRMnxkJ;
        }
    }

    if (lpjcoPzbRB != -1022558.6064784867) {
        for (int cEDTi = 1928429575; cEDTi > 0; cEDTi--) {
            RsvaYyQvaLcVz = ! akqPmMHQNOAtKwQO;
        }
    }
}

int doixorimkSNRAN::slfuWwTJBwIgH(string wXjDCqBT, double AKbhfpYIBpOE, double oOFTwbe)
{
    string WcOjXKaLUohpm = string("UQEroNcqlyxywmvSMgZtGImgGHQZiA");
    int bIgvPWXdj = -1246369865;
    double bhUdnJzX = -385495.36760581593;
    int IEwsTQHuCEmbfg = 2090569346;
    string qfZYSsZcjq = string("pCNAmudpswplfkdUASVmtRXYYGhprjCjvSzFGGzhcPOGTGSIifOTbaFgnZGbkMnldhbxSAhBGYYLwbhVdTaJZkTnUonUIAjRXMmugzauMxnCpjqiNbqDgezuloYalzM");
    int ErJhWXwMvT = -1226454709;
    bool uwvQl = true;

    for (int CVbSfAslRk = 2024559440; CVbSfAslRk > 0; CVbSfAslRk--) {
        AKbhfpYIBpOE += oOFTwbe;
    }

    if (AKbhfpYIBpOE == -385495.36760581593) {
        for (int gbmtYLJSgWRaWeaF = 285103721; gbmtYLJSgWRaWeaF > 0; gbmtYLJSgWRaWeaF--) {
            wXjDCqBT = qfZYSsZcjq;
            WcOjXKaLUohpm = WcOjXKaLUohpm;
            WcOjXKaLUohpm += qfZYSsZcjq;
        }
    }

    for (int UldEOMfckMDYz = 845455744; UldEOMfckMDYz > 0; UldEOMfckMDYz--) {
        bIgvPWXdj /= ErJhWXwMvT;
        ErJhWXwMvT -= IEwsTQHuCEmbfg;
    }

    for (int eKKxhjMu = 160447588; eKKxhjMu > 0; eKKxhjMu--) {
        continue;
    }

    for (int SQyhy = 369993636; SQyhy > 0; SQyhy--) {
        uwvQl = uwvQl;
        bhUdnJzX = bhUdnJzX;
    }

    if (IEwsTQHuCEmbfg > -1246369865) {
        for (int cJNfphwSisImZr = 127086016; cJNfphwSisImZr > 0; cJNfphwSisImZr--) {
            bIgvPWXdj -= bIgvPWXdj;
        }
    }

    return ErJhWXwMvT;
}

string doixorimkSNRAN::OAYXbUNJRnUkn(double HcxqOElZqJ)
{
    string QpJzfCeVNZRQ = string("vaJsuvwvJwfGSZARzNcVsVgCTgSmcCGNzjrtlrQKlOtFHVleGjvjaRzqfiQscermYeZLQdaVqwFtnPofMVhjcmoLWwSDYcyXutnHxeKNwIyybisCONzdxpuPaZdRbIsoUULWWrtJrFGrfYbuEFuAtozBeWsW");
    int TpAAzmO = -1987677915;
    bool xXGbFtKnyQ = true;
    bool EShMVboD = true;
    bool kRsZyUvTCFhm = false;
    string EjYgjTETPUhuObq = string("iJzIPhOrnuFHWJUyWcuimngAjtyZBUPCsXQsXWLiTozDzNFVYBEXuJqhLoVcLURWRbdIIRzvbjnRFRLumktqgixsJdgmUQPYKanBDtmVWytFGsfNvQIFOZadBImARwA");

    return EjYgjTETPUhuObq;
}

string doixorimkSNRAN::jiqVujXrJi()
{
    int vDEDFsB = 1580217899;
    int RcdpRMqiwHj = -31297735;
    int wQVpSvvRvmx = -547272721;

    if (wQVpSvvRvmx == -31297735) {
        for (int BFytAxZn = 1830119383; BFytAxZn > 0; BFytAxZn--) {
            RcdpRMqiwHj /= vDEDFsB;
            vDEDFsB /= RcdpRMqiwHj;
            RcdpRMqiwHj = vDEDFsB;
            RcdpRMqiwHj += vDEDFsB;
        }
    }

    if (vDEDFsB <= -31297735) {
        for (int peZwzwJvRq = 629938428; peZwzwJvRq > 0; peZwzwJvRq--) {
            vDEDFsB = vDEDFsB;
            wQVpSvvRvmx -= vDEDFsB;
            wQVpSvvRvmx -= RcdpRMqiwHj;
            RcdpRMqiwHj /= RcdpRMqiwHj;
            wQVpSvvRvmx /= wQVpSvvRvmx;
            vDEDFsB = wQVpSvvRvmx;
            vDEDFsB /= wQVpSvvRvmx;
            vDEDFsB /= vDEDFsB;
            RcdpRMqiwHj *= RcdpRMqiwHj;
            vDEDFsB -= vDEDFsB;
        }
    }

    return string("lBBEdznmEelnegwJHWqijmPGukPXrTQqKXtlwhUGFHSjkVkXcaiDuvTEIdIGxPwmRBRNfDMNsDWFhTOwyPgvaZtOXtf");
}

int doixorimkSNRAN::bhBWkoWDrm(bool XXKZbomnJbrbKM, string OakyhkIhRM)
{
    bool EJokdpcUDclL = true;
    bool BLGePlPBBblKdBK = true;
    double pYyzfigWKjhXNRBA = -955281.711918167;
    string maUUMguuQIkit = string("CfomhVfPuLPbKIEQczJZyoYrwZkRRsjEhRqVtknHgnVUqhLsDwSAHjbToTGcZnfPhARrEMRptDKOhQeTgdhJFbYssJSgxQtyqVosnsobxMcloYDizOmaieMKlIdzJzwyHUZPIrharXekfzmjVqWzomEnSexrCgGQDZncbtysToILpAtZdfPmRUY");
    bool Nuprcsndp = false;
    bool sLEmKYUYxqLSe = false;
    bool EitbRbsRtBqen = false;
    double SEpLyyGq = -732138.6680021376;
    string mDbwRS = string("oQsQMJBTyAFZnWgiwErvxNKswutxdhxiILmJbrSNHozlxjAPuaMlrgNeQamjMtAaApILQEnZELXsldfnpYJnjNjUMGdjEhXxXBQUzbbbzDFjUYVXWoBKjXQAcwRrylsgoidXXSLuqYQgHpehsweKiWtjuCvPgECaqJxWVVooZQutYdbuIhZBPfplSOcMizVROOQkPLhvVTgRSZDzlZCXP");
    string foJaDN = string("wxhTzDPNybOyQrsVypknBjZAwajKxIK");

    for (int nmVllgOwmomhDHHD = 302072712; nmVllgOwmomhDHHD > 0; nmVllgOwmomhDHHD--) {
        continue;
    }

    for (int ryLuMmKZEXTZIU = 793688139; ryLuMmKZEXTZIU > 0; ryLuMmKZEXTZIU--) {
        maUUMguuQIkit = OakyhkIhRM;
        maUUMguuQIkit = maUUMguuQIkit;
        mDbwRS += maUUMguuQIkit;
        XXKZbomnJbrbKM = ! XXKZbomnJbrbKM;
    }

    if (Nuprcsndp == true) {
        for (int dhnHLlvYcTTZUMKV = 1578303593; dhnHLlvYcTTZUMKV > 0; dhnHLlvYcTTZUMKV--) {
            maUUMguuQIkit = maUUMguuQIkit;
        }
    }

    return -215765950;
}

string doixorimkSNRAN::HVmLOZk(bool bHQPVaLUjjY, string RyJlEQIGWUoQzE)
{
    double givswsHG = 556696.5715140048;
    string UQEvHZFBFfCiWIY = string("nFjfOEYcRfaWSlryBceVbZTFCEGhITwzoKcetDtyfwKVdszauLWHDrSMQWFlIwjiQUHPSTxRWEyMlIwxQM");
    string ALJtsnPz = string("XQnsZXrOoanWNTdfJmIcJJzdKDJwgMfkIwOfulTqWUxAlxZbEbynnnmJkmtPvUZUJmOQbnglXwmgFaTusijskCuYrsGnYcASKHIhmiculpQdZqIObxiAcfmoxADXulGHWMQcDXV");
    int BthWrmRCKdj = -602092387;
    double YUFaSricfBrVG = 487571.5799109136;
    int byBnhCBqFNgFvBz = 74986118;
    int GJLQIENjXGUPKaGY = -1152397897;
    int rUoChfJVjr = -707202058;
    int ZiZMNDlLxPGtv = -1489830847;
    bool QOwTgsHSOSxmLjS = false;

    return ALJtsnPz;
}

void doixorimkSNRAN::KfIIyUt(bool GvlZm, double VMIKmDyFsbQulplJ, string cHCspFIWlsRhN, string lSEmciw, int gJEZhQdKj)
{
    string oXggKRMet = string("CLQcyttUcFGnPZaaRaWTltFiCJxjBqgpfMQnfJtcAdVOXZFXqdgzxXeJLobxGnWVNnUSOryAZRIWqRVjOXLLzcCvHejEROzXGoAOmMDqeKkyoEOijwjoocNBGnIzzn");
    string CoUPICumDNxISN = string("EGGdELXrKEIfPLyGEGrbMwzGCFyfuq");
    string CpwbAbvLgWhlwu = string("cVPODJcTSZujUmMscEPATJEmsyGcBqAxtYprmdLFOiDisFbijHmiLPGJjvrytAmlYrQRXrjpNfzCXZVXXwJrKAcZHOxnVTQQXinxwJwHfTUxWFowqNwDCHNouXRzUMJnuYzqKEEqGt");
    double ElPaZpNZ = 946654.8988375318;
    string EesCfZvx = string("aVYjXFNrRCFAkgdbtknnFKyTjfyfYx");
    double sYitvCE = -234398.1422181353;
    bool jbZXHPbbAaqSytTV = true;
    int WwvFXqAejonZxBi = -937535755;
}

string doixorimkSNRAN::MJKLzbqhTMZvZII(double hRJmoXkBlbWwwOV)
{
    string yPJmEGIfVYvqss = string("UdiQmGXJLlCHbDKKudfrjzbLOgBTLIbUmGyRLPyWsAzoUimtoRsnFrnquuVOGulIpjVOueFPxFOv");
    string adldvW = string("IaYNyQSanfjbVyjOqZLXBxWpWRLSyRnLfFAN");
    double OvRmibS = 898036.9393214724;

    for (int RsSmZTfvovaeKxv = 412983390; RsSmZTfvovaeKxv > 0; RsSmZTfvovaeKxv--) {
        yPJmEGIfVYvqss += yPJmEGIfVYvqss;
        hRJmoXkBlbWwwOV -= OvRmibS;
        yPJmEGIfVYvqss = adldvW;
    }

    for (int lLRuK = 1485769247; lLRuK > 0; lLRuK--) {
        yPJmEGIfVYvqss += adldvW;
        hRJmoXkBlbWwwOV /= OvRmibS;
    }

    return adldvW;
}

bool doixorimkSNRAN::eCZwZtkECxsQRbo(double naLjq, double zphDlYegnJDib)
{
    string NdLYqkGHC = string("DvYHMWsAHWRrqHsUUXhJYfDaxjBvpSTixfmapqcCXzGnrQPHzkDCJjmLkrXURsQCUObBYdBmtTUpPehZCCVGmSGswhnLmvAXeDWOhusIzbLjlHSaYxcGawofIiMQPCDPfspoAPmcQsepxMOWTJoDgJsnQVozWKvSuvqTbEZGbdbDppXwVumRoFNJJfNBfcEDcvYsECYUkDbkyEoUAQ");
    string ySTheLTl = string("daNyaskiuKaijsHGZrQyosoYeSUsQxHVKSHpmIoWkaPyzyNGnpibPINvigdDHzJmVRdTyEgzFYaDCRODcrZSabNjEeoMTGpkCVcHFchRKsFeSYrVHtgvJbETogTANCwEGEuFBKMLphCZrDcbjA");

    for (int RPfOGOzCoYkIrx = 1818878106; RPfOGOzCoYkIrx > 0; RPfOGOzCoYkIrx--) {
        naLjq /= zphDlYegnJDib;
    }

    for (int xdqNycyCKt = 744790967; xdqNycyCKt > 0; xdqNycyCKt--) {
        ySTheLTl += NdLYqkGHC;
        NdLYqkGHC = ySTheLTl;
    }

    for (int MzlpKqTlTGJoj = 1289778389; MzlpKqTlTGJoj > 0; MzlpKqTlTGJoj--) {
        naLjq += naLjq;
    }

    return false;
}

int doixorimkSNRAN::QlKcVWBDCEDbSxa(double XSYguIoU, double EZeIXIYtN)
{
    double xGfiOSGGixrI = -1003975.4378063289;
    double yoNXvJOij = -304161.94927418424;
    string GuOlznsGUHNtxWh = string("JFJrnmbSuLSOWkoRxioOaGaRQPcGxPJHfkNtdOrzYQXpXAbMNKaHuBLbtydZpJIsPjFRlLCNVQSKnrbDksiOwuXdOCtlOdLGaQMHqRPNxVIagHjsERvuCZGWBxRKlSa");
    string tZAgLdjoNTau = string("QCpaZKXiRiwnKqNgelJmpxDsQQfRzmopbvTyRyMUpBzCLnjtVYNsgRbILFoQqkNIuxwILRzblBlSWKFsXKjVJOaxfoFaCGPnqnBKOwqvHQSfyRINHXCzUyuqMjNvCvxXaXRwteqmtxuPeJfTSahxggNM");
    bool mKSJPtgIiVA = false;
    bool WpTIdAEogBSqYY = true;
    int vdrpNs = 1458812794;
    bool KnFYrSqFaRortNGx = true;

    if (KnFYrSqFaRortNGx == true) {
        for (int WyAqquxU = 360281498; WyAqquxU > 0; WyAqquxU--) {
            KnFYrSqFaRortNGx = ! KnFYrSqFaRortNGx;
            EZeIXIYtN *= xGfiOSGGixrI;
            mKSJPtgIiVA = KnFYrSqFaRortNGx;
        }
    }

    return vdrpNs;
}

doixorimkSNRAN::doixorimkSNRAN()
{
    this->eOxgZQuBI(true, false, string("GpNKtQUFByQPVmOCJHZxyOPmIzIRRkLEJgighKKfKgLBDsEuUnMARLaziSdnLQOeVLMOCSzDJamCTwwkxAMpZVmzIgYSovQarRGRlvwqYFrnPawLiGxbZKWecxrrvNZAvQaYZbUZXKpiLvESnUFeCCncVUawTJptDmswuCliRpRmXRmRtGzmDHUctZgQSUzQnppfyHpKGOzNKrNqpnkdYGqlQmcjFKlvHSpNjCpVLJZIZUcQMkLpvPTlBFg"));
    this->eKqxdRNDaJhjVfO(false, 1310229881, false, string("h"));
    this->OmkNgTrvmTMB();
    this->ymOYkuvCwcf();
    this->GGIqMVBBPq(-884842.6514415172, 928102.4182178151, false);
    this->slfuWwTJBwIgH(string("ihAFBYGjHeeOuCjjiekftKbShcYsilJETrILAxmRrCwATwynGlsflPETf"), 969154.314541275, -548497.8754718876);
    this->OAYXbUNJRnUkn(-966714.6074848206);
    this->jiqVujXrJi();
    this->bhBWkoWDrm(true, string("hEbJXdzWHvUMrBLOBdCMYoxQNEmGAbhxLpqHadtTTBfFsdtuAwnlPHnzEUlyzTyhGHGYXfdkwgawLmakemBjfSQfZAdCPMNGXlnxzgRekmWhcxDQzsbilrclZNHBwGqRbALGv"));
    this->HVmLOZk(false, string("gfALfACpArsplbToUnqtKKJFNeWKyf"));
    this->KfIIyUt(true, -515941.38600097573, string("MVdGOWGiuhQGrzOfHUEPrfizaEMyFSeAiiPmoiJbsUbxSQCyYysxCnEbAucAXESPCDKAXpoukTpOizZbUumnRUOKIlYlFotXtNhBiOFosDxsKRLmoEuGmRLwAqfaizeblivhagpkPPsnymQfLzcgPUfWggvCouSXvNXzvTPyNBNZcFoLiVLHcMoucSLOualBSKrmNcIxigHudKjfEPkUhDLcQiqXmEKONsyLuAaSxjZZKTn"), string("LexurFDsEOFYPPsjeajJnILHolthDjxlkbfooTwcPALCeJTfUnJCFdKlOgPzjZJiszwYgCEFwgMkgvxJYFKxzNTgrSEQdFElAhHvhXaqkeVRsADSUNZxpMnGSWPALkIaqiRvXSfcoqJhYpKGyGillpBpjCHPaUHUpasMpspulBsAjrSSVRlgAZUHSiINTNDWvLjMBId"), 61241324);
    this->MJKLzbqhTMZvZII(-575444.0326001388);
    this->eCZwZtkECxsQRbo(253143.99653573532, -256772.57240514486);
    this->QlKcVWBDCEDbSxa(673617.0170194084, 321513.7876477305);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DeBdrYLdBA
{
public:
    string plfJadaBXsKlFob;
    string kirddWl;
    double eZHaWFwvtDmnss;
    string QOaMWqwSgxjEU;
    bool gEWrUKYQa;
    int YmcILVdyHJ;

    DeBdrYLdBA();
    double BtnehVQOmVcq(bool SRoCbHMITCr);
protected:
    double OrsaJerCdO;

    int LgCyQahhNatdDbhR(double buJtCaFhTz);
    bool MtNZIaoRx(bool BWEOF, bool FJJbHMxfvoqjY, string SKDBd, double MQksQCk);
    string IiHhOpeqeYrm(int lAIdHslaLOmFINK);
    void cPglh(int wpsvUcZmFU, string RpnVlPzU);
    bool sXIynLqmof(string LPVncssVHU, string JcfTcnVZScPP, bool MVsYdqCiwreia, string haPwX);
    int CDGaW(double fgQTbvypOvklwt, string uSvajsz, string TTEhLKjE, string qHoGNNFyOgWXA, bool pgMuxvhXRzAb);
    bool ftqlbPkrnTIeSqpT(int MAKteuoyefhkfz);
private:
    double LiVeWdCx;
    int KfiofX;
    double oUnBcFVAanueO;

    double FConqm(string ubynsU, int NxDyMTsQBH, double RsHJnOsaoUMj, double TJzDkkMUVjGd, int AeYkgRiMXTmAK);
    bool OSviWSOaL(int LuFovDxacv, int cayyTXtUBDw, double dmnBRNbtNKqsWiIh, int pfKuAFjKlqtN, double ifkimLWApoVl);
};

double DeBdrYLdBA::BtnehVQOmVcq(bool SRoCbHMITCr)
{
    double QeqVY = 422768.9399605149;

    if (SRoCbHMITCr != false) {
        for (int MiYQqGpvZ = 1587489395; MiYQqGpvZ > 0; MiYQqGpvZ--) {
            SRoCbHMITCr = ! SRoCbHMITCr;
            SRoCbHMITCr = SRoCbHMITCr;
            QeqVY -= QeqVY;
            SRoCbHMITCr = SRoCbHMITCr;
        }
    }

    if (SRoCbHMITCr != false) {
        for (int rCHowcaYz = 1270005549; rCHowcaYz > 0; rCHowcaYz--) {
            continue;
        }
    }

    return QeqVY;
}

int DeBdrYLdBA::LgCyQahhNatdDbhR(double buJtCaFhTz)
{
    int oTBCtWkMJZdoS = -1841672538;
    double pWmRuyyCyrrhVTq = 969946.2053895002;

    for (int mGcqEaIDoCQGBk = 1030533657; mGcqEaIDoCQGBk > 0; mGcqEaIDoCQGBk--) {
        buJtCaFhTz *= buJtCaFhTz;
        pWmRuyyCyrrhVTq /= buJtCaFhTz;
        oTBCtWkMJZdoS += oTBCtWkMJZdoS;
        buJtCaFhTz /= buJtCaFhTz;
        pWmRuyyCyrrhVTq += buJtCaFhTz;
    }

    if (pWmRuyyCyrrhVTq > 969946.2053895002) {
        for (int semUhcmOM = 442718330; semUhcmOM > 0; semUhcmOM--) {
            oTBCtWkMJZdoS *= oTBCtWkMJZdoS;
        }
    }

    for (int mPEhkPycfUK = 1038969590; mPEhkPycfUK > 0; mPEhkPycfUK--) {
        oTBCtWkMJZdoS = oTBCtWkMJZdoS;
    }

    if (oTBCtWkMJZdoS <= -1841672538) {
        for (int Cvpls = 206399988; Cvpls > 0; Cvpls--) {
            pWmRuyyCyrrhVTq *= buJtCaFhTz;
            oTBCtWkMJZdoS /= oTBCtWkMJZdoS;
            pWmRuyyCyrrhVTq += pWmRuyyCyrrhVTq;
            oTBCtWkMJZdoS *= oTBCtWkMJZdoS;
        }
    }

    for (int fkNOqHFbYeEExTk = 1945240591; fkNOqHFbYeEExTk > 0; fkNOqHFbYeEExTk--) {
        buJtCaFhTz -= pWmRuyyCyrrhVTq;
        pWmRuyyCyrrhVTq = buJtCaFhTz;
        pWmRuyyCyrrhVTq *= pWmRuyyCyrrhVTq;
        buJtCaFhTz = pWmRuyyCyrrhVTq;
        buJtCaFhTz *= buJtCaFhTz;
    }

    return oTBCtWkMJZdoS;
}

bool DeBdrYLdBA::MtNZIaoRx(bool BWEOF, bool FJJbHMxfvoqjY, string SKDBd, double MQksQCk)
{
    double VsoOEQWzcoxgTn = 258890.9998833044;
    bool oEkroZGVk = false;
    int EBbRpLElTOMazu = 451582628;
    bool KOnzLhINQ = false;
    bool KQOWEVBHxClWMCn = true;
    double ySXXPrxBaSgX = 323696.9095248731;
    string onJWkUdy = string("ayHDMyIVRQAacQqSilPpbeQmjlGfb");
    bool YgLamnCwdrLluqM = false;

    if (oEkroZGVk == true) {
        for (int nuMMxJZDWuxwEcTJ = 1810526694; nuMMxJZDWuxwEcTJ > 0; nuMMxJZDWuxwEcTJ--) {
            continue;
        }
    }

    if (KOnzLhINQ == false) {
        for (int onFKcPVHhqsGO = 2019082956; onFKcPVHhqsGO > 0; onFKcPVHhqsGO--) {
            ySXXPrxBaSgX /= MQksQCk;
            KOnzLhINQ = ! KOnzLhINQ;
            FJJbHMxfvoqjY = ! oEkroZGVk;
            YgLamnCwdrLluqM = FJJbHMxfvoqjY;
        }
    }

    return YgLamnCwdrLluqM;
}

string DeBdrYLdBA::IiHhOpeqeYrm(int lAIdHslaLOmFINK)
{
    bool NcAlByfd = false;
    bool iAHdgBUHzyOercz = true;
    string OiaxIjlnxifBxAIU = string("AzNNrHoRuAAAQCUGgGiYXyStFiIAgmHGtJmhcOhtQRXGyTIXkozlmGDwgHWHJlnSPyvAJZzyfDKRCeEqIqBWlfOGAglaSJ");
    double WIiOLsTv = 216653.94179121568;
    string evaaXGAOn = string("aHdwJYWIizGhwFeiisUEbDytblHswzvDnvfVXdSQtYtD");
    bool zAirSRbSOcp = false;
    double JzCsM = 1044531.3138553604;
    int ALBvbPfO = 1518025397;

    for (int RBnnUFBnyIoQQCQh = 1586563521; RBnnUFBnyIoQQCQh > 0; RBnnUFBnyIoQQCQh--) {
        zAirSRbSOcp = ! zAirSRbSOcp;
    }

    for (int NVioQwDOqCV = 956187105; NVioQwDOqCV > 0; NVioQwDOqCV--) {
        WIiOLsTv = WIiOLsTv;
    }

    for (int BAnmcLnwztfxniP = 284181159; BAnmcLnwztfxniP > 0; BAnmcLnwztfxniP--) {
        iAHdgBUHzyOercz = zAirSRbSOcp;
        lAIdHslaLOmFINK *= ALBvbPfO;
        zAirSRbSOcp = ! zAirSRbSOcp;
    }

    if (WIiOLsTv > 1044531.3138553604) {
        for (int ayLrrQtZHqz = 1561562900; ayLrrQtZHqz > 0; ayLrrQtZHqz--) {
            continue;
        }
    }

    return evaaXGAOn;
}

void DeBdrYLdBA::cPglh(int wpsvUcZmFU, string RpnVlPzU)
{
    string ypMBdvPMMhUligl = string("RpWaLHIlvUkeBBB");
    double JIYVOFToNFwUDxIl = 563513.6343295855;

    for (int KRecDmUPPbSorbna = 1589111302; KRecDmUPPbSorbna > 0; KRecDmUPPbSorbna--) {
        continue;
    }

    for (int tcePJSRbHReK = 1877499699; tcePJSRbHReK > 0; tcePJSRbHReK--) {
        continue;
    }
}

bool DeBdrYLdBA::sXIynLqmof(string LPVncssVHU, string JcfTcnVZScPP, bool MVsYdqCiwreia, string haPwX)
{
    int WosnEvEuoSWrPtn = 928727213;
    double RkCPddPFxvvuGuk = -591269.2266516577;
    string sRvhdGjHHHZ = string("HQafWqCYCZYglGCMNaJCqdggycMSeIYbNQCKRlJLYuWtnqexbVwBeSTJxNzydfMFFFTaIcgAirscKEkleplubsdDyhRpkFfrPemDqOYHiOKrOc");
    int lMzdEtk = 907595450;
    bool mctGNRPVM = false;
    string goyHopWoJWSWC = string("SyQqwKdtfSCyRrnstpfpagIFNnfGRoQUryeAzHPFluuAcmhjjPFGCXCoEZYjGbqNQxSyCqpJvxgJBGvQYcbHwSPMiwJtkJipQstJrNg");
    string CnTDHxlZiHmzyBSo = string("XpFdJLJxYwsluHkjAkMEqIvQvBJSbSAszYcN");
    double UOHSacDV = 840283.2225232605;
    string WClBixu = string("pyBKVxVTOErvtVwDzixxPXZBWbeVBjgyoHByTMBwlSvvjzmTtATYuinGUzJamOGkLgFNmcgemBzCRmSamfQRbALBodwXlcLsNDksTZuNWsdwZqsLnvlMUnsguxHtNHNconaaASugONwXIOewWnAfLqsTIjhbtQqiPuuJEJpWLrSFivPCiogu");

    return mctGNRPVM;
}

int DeBdrYLdBA::CDGaW(double fgQTbvypOvklwt, string uSvajsz, string TTEhLKjE, string qHoGNNFyOgWXA, bool pgMuxvhXRzAb)
{
    string wDbgrlIm = string("vKzzfQbkzUYgTswqlbBbjmTHTGyIMMVGzXqtiOvHjYXMMBBUJSdukuEESgudVKhBZdR");
    string ONLpIRMyYzos = string("MGeXAkulmrJUhAVuYnzLnHfQDwtljsQKOfkupNVAdzzoVRJXFZLZwiNZOnRokfpkYDmLQNekQiQgTgnrteJynuqFuqLhrRelNwMhXqwIoTpfrAxesyTqrsvpqnzjBJyhFbDxCVXhfwmyIpcbWYZxKPJqFqWWrUStAvAewHyBkk");
    double REBbsm = -366374.1010675467;
    bool ENWPJqkaepHFJCY = true;

    return -214024532;
}

bool DeBdrYLdBA::ftqlbPkrnTIeSqpT(int MAKteuoyefhkfz)
{
    int oBXiI = -2124409972;
    string KUgOTabtvwvXRqB = string("oJlywPiYZDoMzanBNo");

    if (MAKteuoyefhkfz <= -234905382) {
        for (int knwCl = 2091258090; knwCl > 0; knwCl--) {
            KUgOTabtvwvXRqB = KUgOTabtvwvXRqB;
        }
    }

    if (MAKteuoyefhkfz < -234905382) {
        for (int SdMcVJVBQCR = 917600141; SdMcVJVBQCR > 0; SdMcVJVBQCR--) {
            MAKteuoyefhkfz = MAKteuoyefhkfz;
            oBXiI *= MAKteuoyefhkfz;
            MAKteuoyefhkfz += oBXiI;
            oBXiI = MAKteuoyefhkfz;
            KUgOTabtvwvXRqB += KUgOTabtvwvXRqB;
            KUgOTabtvwvXRqB = KUgOTabtvwvXRqB;
        }
    }

    return true;
}

double DeBdrYLdBA::FConqm(string ubynsU, int NxDyMTsQBH, double RsHJnOsaoUMj, double TJzDkkMUVjGd, int AeYkgRiMXTmAK)
{
    int ZPnoUmWrPzsWXMWD = 1099880357;

    if (NxDyMTsQBH >= 985430387) {
        for (int ufXGADBBz = 381996127; ufXGADBBz > 0; ufXGADBBz--) {
            continue;
        }
    }

    for (int nrZWXyLHU = 1896885116; nrZWXyLHU > 0; nrZWXyLHU--) {
        continue;
    }

    for (int JtffqAN = 521052725; JtffqAN > 0; JtffqAN--) {
        continue;
    }

    return TJzDkkMUVjGd;
}

bool DeBdrYLdBA::OSviWSOaL(int LuFovDxacv, int cayyTXtUBDw, double dmnBRNbtNKqsWiIh, int pfKuAFjKlqtN, double ifkimLWApoVl)
{
    double PNioQ = -153918.4569925211;
    int lorAN = 419398421;
    double ZKuIK = -539938.3398463255;
    int yahLUKWIUnEjUq = -446953824;
    bool DKocLFOHDev = true;
    bool SEdisOBUrB = true;
    string nIuoFeayDMNZn = string("CZStXQyymBgHxBFgTVLWGVwcuTgTHgDYHhJzKxJkdzdaqZmpbyzrbdzfBUEaeULgZDIYbIXmkjwChaUWgUlrbXOClXhnejVqfGLCLVmYBXDzzHEGTnzkxydmNjPTEfsZeuYYQRdKnMHPhLDIRhQmVFXXPKqA");
    int XEhZjDqnjJt = 1425864805;
    int ngoERvRi = 148127373;
    int vigItPCdvl = 1896791198;

    for (int GSAKjDvCJyHgu = 1070693781; GSAKjDvCJyHgu > 0; GSAKjDvCJyHgu--) {
        XEhZjDqnjJt += yahLUKWIUnEjUq;
        pfKuAFjKlqtN += ngoERvRi;
        LuFovDxacv *= yahLUKWIUnEjUq;
    }

    if (lorAN == 419398421) {
        for (int ySOFcg = 2107652992; ySOFcg > 0; ySOFcg--) {
            ngoERvRi *= pfKuAFjKlqtN;
        }
    }

    return SEdisOBUrB;
}

DeBdrYLdBA::DeBdrYLdBA()
{
    this->BtnehVQOmVcq(false);
    this->LgCyQahhNatdDbhR(-714930.2263834085);
    this->MtNZIaoRx(false, false, string("FzmpaPVPrPUkJUavfpXtxSwsixfamqKSDIVbQEMxCXTWRquGoIbrHDRvcDsFZAZgrAzuanQFNSGDNyXSOCZEFgtIqHbcoAzdbNafREPRvoJYtPxNswyoCOezjhUCBKGYYUaULMCqKwGOFEaXFPFmZAqnYWUNYihexJEdGRHoACuyFAHRmOljDkTljDZOovnWJigCopjbwAbjrO"), -538866.128130408);
    this->IiHhOpeqeYrm(1347150307);
    this->cPglh(299436678, string("AieGxMDCJIQkZDttSwEePbPxxkDqvKqjskPWnEGbdoXhzwmwOAePIMNLXWsafGqhWeibCLprXvBkhutNfgYXBgaPnGDDiMw"));
    this->sXIynLqmof(string("sGkyIiibLfAjBKmWlwzlPmTVylzorvsNfwktwULITynfqteebqYPTRHkheknfsmtVbPnwaTEUaOQyGPbvSYVNRvauoPSIMFQRtNedyhZTSUxi"), string("cnoLSvSwomauybpQOIWaRormXIqFZJlolvCgzxXFXlnoyoBPrvFpAumeMwVtFvZDxYvInaPOFmyIFPDFcPbAPIQOkgDDIBbnMudcNKwPxYDvBAvdICODcBOeYYHlHaFyBgYclGcWfwFRnmTTQBmZELqASwRNnRGPnfPOVkGqOqpSXkZnsiANfMloMUEDOILONICXExQnSUsBLzcjLVgpbkCZd"), false, string("sUZEKdQFrfxYHfOcSVBIqaHpaGnVBHpkoVPCLjhsjoCGqvhXYaqGonENQDmXGJxwQrILRdgFoSljWKNLkIBiYvlDkZMByOZrvwhkAlfpcAFJUhXszyKjuMmUbfrXnFGBSufHfryYNQtETJZhiikzkmzMbTqeYGDcuPGqfSKChgNlnHKVSBFplawedZFZWPTWmoqbVrylhZnHmuaBUAAhVTRmcgdgwJabCwLpsUvGNMdjqzXbqauzXknKGAURnP"));
    this->CDGaW(113586.90768148369, string("kafcCJoMjEMrPEwsbBdHWeXXtFDheNlTcRyADfafohavHpqFueTMiWSSXrOIZDxwwCYRpOvDndUnCYdVCxlahAlWGxWXEmYogZLxEknMrsAHYdOfjrHRiZRMOJzIuysFAerwwZCxiCuHWPKGJUGjtvbJCChYxqgHpPMUcrlhT"), string("tLYtjOiQEkHcQjPCtxhSEnUbyIzQVvvHpyOUXmhlAQfUdblrUFTxOJFBLLqbgrGHMPWeGZUTvJdWQcIWyZQAsAyycDfylidzOvzucTBjmpzipwXMQVZHFsZqevFQqbsqFtbzwUsXwnUBEuaLDYEyeefzNPShrUinEQuqSGMkWUiFTdUghC"), string("wFlrAcAsJHqhHgsdIFZdGjhLLjYZq"), true);
    this->ftqlbPkrnTIeSqpT(-234905382);
    this->FConqm(string("kgJDbSlsMvcHcmYNcDkitoXzmJhItRPYCSnxCYZSkVIViLRPJdRQGnTtEtdppaTEkMaTGTErxZpgHhSbwbHbvqAcXpLTXdhMSdDuhKjqoUlHeKFoFgnrUqjDhfOYEIjFaArXtQg"), 985430387, 100331.09660597178, -556492.4517848034, -1731610537);
    this->OSviWSOaL(-1118657363, -1417152454, 10275.257704822483, 1903418095, 734019.0985860417);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZnOxTyV
{
public:
    double pFlRqiukvTKqmaf;

    ZnOxTyV();
protected:
    string tScPdYBigaMspIvz;
    int tTXvyWShalFeZvBg;
    double fLLtDKhxePnDCLbQ;
    bool uRptnXwJpco;
    double QcmqlxvJxYgqpIk;

    int hyPcRbOoHNHbR();
    void DQNJIQGO();
    bool wKhDVyyQJEcBnOr(string tBRbchWhUlb, int TxvsWdPwslDrbly, bool oGoHAeUDXJMhl, int acXojSzmhcT, bool keiaoYvAuXxfpxFO);
    void dDEQvgERddolumR(double hhBMbOcdTp, string WqumJaSn, double mAqqehxwxYoDu);
    void qozdbxwiefnb(bool UtzQtHYWeXF, string ADWKkQnBa, string LktrHeMoXlxYMZGo, double JRdvlY);
private:
    string UJWjqXfZvI;
    double mOzgQLQrLB;
    string ytIHqdelyf;
    double ilyfKHyzU;

    string xvTFZDLKaEh(double WtVzHZeQo, int ndpCDNz, double GiPCtnAAlEme);
    void iyMKcGUe();
    bool CnsZXlcZgbVjGK(string YgvHNuEPp, string lsyvLf, double jJZMvn);
    bool DYzpEzhdAXO(bool RnVbMmIAgx, string lgTzqLUqzp, double PJRoJhCEKdsEdJXV);
    int QKQEFt(bool uNfGfoxuHxjGluR, int wvaiNbV, string vXraYggREaFFxI, bool QPjBDfhxQUHnXj);
    void cBtCoom(string pLUrUEb, string GRGqw, bool JhILbkLAgodk);
    int PEpPtSXdNj(string ZYNTtlJMxGFBmFf, double XkMSSymVPMkI, double ySsdsYqTWaqNBOT);
    string nQFhtBBkgjGKqO();
};

int ZnOxTyV::hyPcRbOoHNHbR()
{
    bool eBfCjs = true;
    string VZoxrdmFk = string("RzhPGIFwMewCccwQlfdCAmrnKlQZcxZHiVfmzPxwaPqeyQqSBMDuyTvdTIbeHMfXmIlNfWGHwicmsflbTKiPjiWBQBwcJfRyLtnhycCdTsvJgZwWOZjuigmuOMVmvIcFRCrPQcgEgzDaaCXiffKVGdsbsvY");
    double DcNsZStSLN = 121489.66770139223;

    for (int oshDgszejV = 1594851896; oshDgszejV > 0; oshDgszejV--) {
        DcNsZStSLN += DcNsZStSLN;
        VZoxrdmFk = VZoxrdmFk;
        DcNsZStSLN -= DcNsZStSLN;
        VZoxrdmFk += VZoxrdmFk;
        eBfCjs = ! eBfCjs;
    }

    for (int CMLPLBZhYBOwbff = 49660825; CMLPLBZhYBOwbff > 0; CMLPLBZhYBOwbff--) {
        eBfCjs = ! eBfCjs;
        eBfCjs = ! eBfCjs;
    }

    for (int hMUukjXGDhVJzat = 1772023621; hMUukjXGDhVJzat > 0; hMUukjXGDhVJzat--) {
        VZoxrdmFk += VZoxrdmFk;
        DcNsZStSLN += DcNsZStSLN;
        eBfCjs = eBfCjs;
        DcNsZStSLN -= DcNsZStSLN;
    }

    return -1377240594;
}

void ZnOxTyV::DQNJIQGO()
{
    bool DOHsw = false;
    string UHFDoN = string("iJzSMnTwQehoEHvfvXqgLoSbVCGsXlHjuoxJQGwJrtBVQJZsgftUBnjTsHrgqKqVRsvDuqkBGFPkaJWIwAzOYeuWljYAuGPlsoIUMGIjvRpEjiPtZiZlVVmGjOjJjaagrltTaqpBdHnfEONIoYEWPWbtuSNbwjTmZmFAfxZLNiorzyqShRHdzQpkMPKwQinTBfo");
    double ahvEaGIsOaNKvG = 732135.2231913571;
    bool DLGGWmocFcgzhcA = true;
    int auOfQFKWAEdyn = 133248811;
    int NxnImVW = -1413604255;
    double EwhjvD = -111319.83872564757;
    int zBOUpCuu = -2128527036;
    string FymFRuOmsgb = string("BkAGJrCiYgnUheDqCSip");
    bool xIpTrExHnh = false;

    if (FymFRuOmsgb < string("BkAGJrCiYgnUheDqCSip")) {
        for (int BBfhO = 1010531733; BBfhO > 0; BBfhO--) {
            ahvEaGIsOaNKvG += ahvEaGIsOaNKvG;
            DOHsw = DOHsw;
        }
    }

    for (int XpqWeyjcYfSVO = 2019831543; XpqWeyjcYfSVO > 0; XpqWeyjcYfSVO--) {
        continue;
    }
}

bool ZnOxTyV::wKhDVyyQJEcBnOr(string tBRbchWhUlb, int TxvsWdPwslDrbly, bool oGoHAeUDXJMhl, int acXojSzmhcT, bool keiaoYvAuXxfpxFO)
{
    string wuPWiDYNRImcktnc = string("DzeYwvxsFlKpIjguPQFqwqhSopoClRXbWPROmHlHRzlqhcFIjvcjtvGqiROaQPjdCCIABXMtdzXExqWspXmcVQpNnPHUwoTcPUfqagvzEqLuCrf");
    bool zWOSGRCJ = true;
    int dhepwneCpbE = -2112379614;
    int OKSrVz = -737040652;
    int LrIjXra = -1581911845;
    string AOoOuodE = string("dgLgZWVKbGDhwEmEDbKBaQFtufaBFYvnUZGmSEqCrkezjUybjNtKokgjCEUkSJhdCdvhvAuliEfUbGx");
    int exFbDS = -952236243;
    int tlvOuFip = -641598071;

    if (zWOSGRCJ == true) {
        for (int pEYXktqyUEMA = 1177681040; pEYXktqyUEMA > 0; pEYXktqyUEMA--) {
            TxvsWdPwslDrbly -= exFbDS;
            exFbDS = tlvOuFip;
            exFbDS = dhepwneCpbE;
            zWOSGRCJ = ! zWOSGRCJ;
        }
    }

    if (OKSrVz != -641598071) {
        for (int XDLukNMbkRlpEx = 818990811; XDLukNMbkRlpEx > 0; XDLukNMbkRlpEx--) {
            keiaoYvAuXxfpxFO = ! oGoHAeUDXJMhl;
            acXojSzmhcT /= LrIjXra;
        }
    }

    return zWOSGRCJ;
}

void ZnOxTyV::dDEQvgERddolumR(double hhBMbOcdTp, string WqumJaSn, double mAqqehxwxYoDu)
{
    string cWTKdJqZcAhnm = string("ZhOLyocYGGmowuxaOb");
    int evNdU = -383531005;
    double dteUQFqxGvf = 367416.16832321906;
    int focYSvvUiT = 1842066079;
    int EMBFpSpNyyi = 1041796319;

    for (int kslRpGVPOygsmg = 1654517490; kslRpGVPOygsmg > 0; kslRpGVPOygsmg--) {
        mAqqehxwxYoDu -= mAqqehxwxYoDu;
        mAqqehxwxYoDu *= dteUQFqxGvf;
        cWTKdJqZcAhnm = WqumJaSn;
    }
}

void ZnOxTyV::qozdbxwiefnb(bool UtzQtHYWeXF, string ADWKkQnBa, string LktrHeMoXlxYMZGo, double JRdvlY)
{
    string CbtULBFydRUJTtYn = string("JGMQdUpXynYwmvAtXDPVfzjrzqqBvqzUvptdWnkNZYccUELiYwkOecemeeAtaiLKXoZCoIXYNkwuGkTOrmDMSwlWKsvGSwjUSTmucabFKoHqwojP");
    string bCjcROFUPirhhx = string("qfVSYVWxBCwrZkUosRIVxuinmYhZKZRQGQZZDhKXMyksUNDafGukBLSQNoPlCYglVpLwOmMKHitGSQwgebuGZWEthyGzdHKzKuIWOTyqrIPaEMgVpNFugLHtDCYaor");
    double GVKccKZovNHdMWdP = 1022982.8713484299;

    if (LktrHeMoXlxYMZGo < string("vWDKNBcqTVVRXceMXVPgQNPQlRaJBOviSNBjQruqZpBPevwGzLNQbjqIjvzhIdRAHtPqbBNLTjcDuvlZWdgMzfzdhJZHCOqiROVxPvGiTLZxyTKVpjDUNoEtCrpPsbTjqaaMOcsYflvhPbILJlkZdAYLnTtMpziYCfGEIbtNxTvcxvRFVUmhVRWzQMsfzSOIOuWkfqaMdWJDanUyRNHBtAxTJiDBqiOcmWtqBEDfoKWdoELZSM")) {
        for (int pOzHyQIJ = 558446406; pOzHyQIJ > 0; pOzHyQIJ--) {
            JRdvlY -= GVKccKZovNHdMWdP;
        }
    }

    if (bCjcROFUPirhhx > string("vWDKNBcqTVVRXceMXVPgQNPQlRaJBOviSNBjQruqZpBPevwGzLNQbjqIjvzhIdRAHtPqbBNLTjcDuvlZWdgMzfzdhJZHCOqiROVxPvGiTLZxyTKVpjDUNoEtCrpPsbTjqaaMOcsYflvhPbILJlkZdAYLnTtMpziYCfGEIbtNxTvcxvRFVUmhVRWzQMsfzSOIOuWkfqaMdWJDanUyRNHBtAxTJiDBqiOcmWtqBEDfoKWdoELZSM")) {
        for (int kFwjwWvqmimKQU = 828427170; kFwjwWvqmimKQU > 0; kFwjwWvqmimKQU--) {
            CbtULBFydRUJTtYn = LktrHeMoXlxYMZGo;
        }
    }

    if (CbtULBFydRUJTtYn > string("vWDKNBcqTVVRXceMXVPgQNPQlRaJBOviSNBjQruqZpBPevwGzLNQbjqIjvzhIdRAHtPqbBNLTjcDuvlZWdgMzfzdhJZHCOqiROVxPvGiTLZxyTKVpjDUNoEtCrpPsbTjqaaMOcsYflvhPbILJlkZdAYLnTtMpziYCfGEIbtNxTvcxvRFVUmhVRWzQMsfzSOIOuWkfqaMdWJDanUyRNHBtAxTJiDBqiOcmWtqBEDfoKWdoELZSM")) {
        for (int SeDvn = 1889941147; SeDvn > 0; SeDvn--) {
            continue;
        }
    }
}

string ZnOxTyV::xvTFZDLKaEh(double WtVzHZeQo, int ndpCDNz, double GiPCtnAAlEme)
{
    int DfqdJLPp = 381626959;

    for (int ifMgitLKHC = 1818824288; ifMgitLKHC > 0; ifMgitLKHC--) {
        GiPCtnAAlEme *= GiPCtnAAlEme;
        DfqdJLPp *= DfqdJLPp;
        DfqdJLPp /= DfqdJLPp;
    }

    if (GiPCtnAAlEme != 398373.79778812407) {
        for (int zIRlukVYlmgphJQ = 808139669; zIRlukVYlmgphJQ > 0; zIRlukVYlmgphJQ--) {
            ndpCDNz += ndpCDNz;
            DfqdJLPp = ndpCDNz;
            DfqdJLPp = DfqdJLPp;
        }
    }

    return string("fNKpcbwoJYOdpMHwAKkgxycARvjZSziKYFgJOBXhjPgFxCDXQyLpXkkoTOpsdrmUVIqVrtmOiuJKIbiAqTfxyAYSzSHeGQmcLfOvmiPzxssvOBFAgvWIYrQSqsmVsuTeqfRDWFpgKBihqQiYfouaOiLqDKAKFQNiBYFtnYiajBPyZVxUuAxpOMtCkkascxCXyrWcgsNvNiWfpVKBAjKNJGMzUQkq");
}

void ZnOxTyV::iyMKcGUe()
{
    int zyDdRPNzrlq = 108378255;
    string jHyJNXVauXOdDFA = string("FkXMLBZAZWmGtQLqcVxGsXTauOCbTloNpnMFflqvggVyyAWsTZgeEWRjTRhZpKZPDtCfCQOJWRiqeimAJItFPQOPUbOFteGIbgLqNPAERsPQLFGgjwqIFFBwuQdEgqXkzUWqyHRLVBdEHHKlddsTqkdRm");
    string LwjvKAYEqaOXs = string("lUGYgxbQisrRHwUZshRjbRzcjhctPegohbXKFRpMibCLMEmQFWwwetYVtNkdzHeqZWcntRoiuWfRwHOYvsixOIniniKsaHfboYFLaXayeAEaTnFikyHYbroFAhqvCvUMPaQXBIPOrpqngDBxnBSmMMSxrmmkwsrAIxAXkZygynFjWsvgXBXmlrbhsbIJjpVtUoypUlMHAnIyJcMkQJAnztdGtm");
    string YLlbhCiQRzR = string("OsbhyTzjMhgmgkFExoYrYYItoWjUXIqzYUesZzZYeHOZSdUwuJmXURRDkTZnQOICfiKzMNOZyPFNpFtxjRxxpPzOLgmLhKheOFC");
    double KqfZXRUamm = 1034110.8775412992;
    bool oUrvPwzSBknuDP = false;

    for (int gQDHre = 866733216; gQDHre > 0; gQDHre--) {
        jHyJNXVauXOdDFA += jHyJNXVauXOdDFA;
        LwjvKAYEqaOXs = jHyJNXVauXOdDFA;
        LwjvKAYEqaOXs = jHyJNXVauXOdDFA;
        YLlbhCiQRzR = jHyJNXVauXOdDFA;
    }

    if (YLlbhCiQRzR > string("OsbhyTzjMhgmgkFExoYrYYItoWjUXIqzYUesZzZYeHOZSdUwuJmXURRDkTZnQOICfiKzMNOZyPFNpFtxjRxxpPzOLgmLhKheOFC")) {
        for (int vGXZFgfOkWalTjl = 636814095; vGXZFgfOkWalTjl > 0; vGXZFgfOkWalTjl--) {
            continue;
        }
    }

    if (YLlbhCiQRzR == string("OsbhyTzjMhgmgkFExoYrYYItoWjUXIqzYUesZzZYeHOZSdUwuJmXURRDkTZnQOICfiKzMNOZyPFNpFtxjRxxpPzOLgmLhKheOFC")) {
        for (int xJNzIFb = 754621584; xJNzIFb > 0; xJNzIFb--) {
            YLlbhCiQRzR += LwjvKAYEqaOXs;
        }
    }
}

bool ZnOxTyV::CnsZXlcZgbVjGK(string YgvHNuEPp, string lsyvLf, double jJZMvn)
{
    bool nTCnpBPkY = true;
    string zYBQJdziZMjLN = string("nzrXBgjTCoawYnAWZcMJOeBRZPCDngqgafGroPRvJpRJOhrqChNdBNpfxzikNOXSOtPzmPuJhLovHfBuKVgHukYQofVFqLmohejvqQJIKWoOkMvpzdQGBWzqBvDUOttBIJVJoaJxdrjCxtjOalLxDyTINtaeWYYUckiNEadrZJGGUoumVOQcklEVlQw");
    string CFzJgev = string("QhHpZCPpeA");
    string FRTbxXL = string("NeoHnZbpygZrBWcXlfNpXWkYhinRrLizSjzhkmdTINtZvzaHjAWTmJLShzTVruchEJHSXehGUqeIpfwxquioZZfEqqPqIrvbvQnwftNZvnqRyRdRyTghoRtaeZIr");

    if (FRTbxXL <= string("QhHpZCPpeA")) {
        for (int qKsiOFsdZFJFESbx = 1500707660; qKsiOFsdZFJFESbx > 0; qKsiOFsdZFJFESbx--) {
            YgvHNuEPp += FRTbxXL;
        }
    }

    for (int tUyJpz = 998403968; tUyJpz > 0; tUyJpz--) {
        CFzJgev = CFzJgev;
        zYBQJdziZMjLN = FRTbxXL;
        CFzJgev = CFzJgev;
        zYBQJdziZMjLN = zYBQJdziZMjLN;
    }

    for (int IXGVYYutiPggrt = 2065231319; IXGVYYutiPggrt > 0; IXGVYYutiPggrt--) {
        FRTbxXL = lsyvLf;
        FRTbxXL += CFzJgev;
        zYBQJdziZMjLN = lsyvLf;
    }

    for (int xgGqgS = 776971571; xgGqgS > 0; xgGqgS--) {
        CFzJgev = lsyvLf;
        CFzJgev = CFzJgev;
        CFzJgev += CFzJgev;
        CFzJgev = lsyvLf;
        YgvHNuEPp = lsyvLf;
        nTCnpBPkY = nTCnpBPkY;
    }

    return nTCnpBPkY;
}

bool ZnOxTyV::DYzpEzhdAXO(bool RnVbMmIAgx, string lgTzqLUqzp, double PJRoJhCEKdsEdJXV)
{
    bool xjsoYjHTfJshJn = true;
    double nGEiKoYKkdRxtUo = 506365.87231067324;
    double wBQwNceTftmnB = 809620.3742696393;

    return xjsoYjHTfJshJn;
}

int ZnOxTyV::QKQEFt(bool uNfGfoxuHxjGluR, int wvaiNbV, string vXraYggREaFFxI, bool QPjBDfhxQUHnXj)
{
    bool WQaxZIKxaDnWy = true;
    int sxmCklb = 1581064411;
    string XlpbvEkoDJj = string("QduDFVhAmWUFdfMayqkdNOAOEfAQjLtvlwoXXShGqnxEueZNLbaoaNyfqrLiBtpIRyKiqcvHSSXrkoehjvOubGwcyAIeoYYNnFHViMOwkpoRZUrdrMaNLFyhymONyKfcCpPdFBRPKreGmjKcubCoscSQosYsdgWroSyHNDvLpKlMstKahpFIwIYfIgUKQfEURxtIsMEJVFJfoNYLcpNZwzsAxXgVuotQjES");
    int ioUcG = 1442228180;

    for (int WQAKK = 609365495; WQAKK > 0; WQAKK--) {
        continue;
    }

    for (int otiYfWWx = 1459372149; otiYfWWx > 0; otiYfWWx--) {
        ioUcG = sxmCklb;
    }

    for (int pKyMBtZPd = 1965903785; pKyMBtZPd > 0; pKyMBtZPd--) {
        vXraYggREaFFxI += vXraYggREaFFxI;
        vXraYggREaFFxI += vXraYggREaFFxI;
        wvaiNbV /= wvaiNbV;
    }

    if (wvaiNbV < 1581064411) {
        for (int aNMuP = 708762279; aNMuP > 0; aNMuP--) {
            vXraYggREaFFxI += XlpbvEkoDJj;
            vXraYggREaFFxI += XlpbvEkoDJj;
            sxmCklb -= wvaiNbV;
            sxmCklb /= ioUcG;
            WQaxZIKxaDnWy = ! QPjBDfhxQUHnXj;
            sxmCklb -= sxmCklb;
            vXraYggREaFFxI = vXraYggREaFFxI;
        }
    }

    if (WQaxZIKxaDnWy == true) {
        for (int JfPAcpuZVMBHKaLP = 750438689; JfPAcpuZVMBHKaLP > 0; JfPAcpuZVMBHKaLP--) {
            sxmCklb += sxmCklb;
        }
    }

    return ioUcG;
}

void ZnOxTyV::cBtCoom(string pLUrUEb, string GRGqw, bool JhILbkLAgodk)
{
    bool oJPfVRNWsbGp = false;
    bool sJoguQcpYM = true;
    int MhlymhIAd = -955859190;
    string BfEtKm = string("rjZBfQxLqCSwCMBTFaIgxbjBPeCCXiXLPRNbumVsWiYuHJsSEnrQcHMUCAseJhKgyeIWsFEWwHcjbINLKcpHNOjcJYEoobiyaxqrbtursnSUEVFdpEErXNKDBPqfemVCSUucSRLoYrtqYgWPNywNwfvEiwgFPhqOxZTUofcYGHSNWdpFIyyFnrqqkBdznSzmOScmjVnoLWGbDUrPsTYzsrPSKmZFWVszeIBhTmlpWjC");
    bool PqKzelBqG = true;

    if (pLUrUEb <= string("llgZCDXdbAdKIMqPjvxcKDcqCyyoyoXTFBwuneXJDFVJrccTHxDNBnmWvKSMdxlvLePavAQcaDGxNIeXVozuCqeANtRMlBxzGOxzFBPMCAYHPBBKkRZDpuCJybDCteGcnvRoGsiiwcgskyaFsGCDFekjKNMSpTkvOOJanPMFIHMqIqzxUXLiubfEphOemBZmixBZaeJrasBaYmpoMiaJI")) {
        for (int gZGiY = 1197031172; gZGiY > 0; gZGiY--) {
            JhILbkLAgodk = ! PqKzelBqG;
        }
    }

    for (int rkajWZGoMtvn = 2080248319; rkajWZGoMtvn > 0; rkajWZGoMtvn--) {
        BfEtKm = pLUrUEb;
        pLUrUEb += GRGqw;
        JhILbkLAgodk = PqKzelBqG;
        PqKzelBqG = ! PqKzelBqG;
        BfEtKm = pLUrUEb;
        JhILbkLAgodk = sJoguQcpYM;
    }

    for (int xbNBGWDYJrXg = 906801320; xbNBGWDYJrXg > 0; xbNBGWDYJrXg--) {
        sJoguQcpYM = oJPfVRNWsbGp;
        oJPfVRNWsbGp = ! sJoguQcpYM;
    }

    if (oJPfVRNWsbGp == false) {
        for (int skWAo = 2049386969; skWAo > 0; skWAo--) {
            PqKzelBqG = oJPfVRNWsbGp;
            GRGqw += pLUrUEb;
            MhlymhIAd += MhlymhIAd;
        }
    }
}

int ZnOxTyV::PEpPtSXdNj(string ZYNTtlJMxGFBmFf, double XkMSSymVPMkI, double ySsdsYqTWaqNBOT)
{
    string KZdlMOkeKQsCuVfo = string("CNrWIbmzlBwPOkTuiGFKIIGJUsGowdEJwnXOSZmJKPpOuHVQFJgRMfQqoFchYDstyCzrNOZUjHgFmtvEscVOHtWkleqidEvaRbAmnEpNeBtHjUpdUPqZykYjIMQMNdWzjEGFetCymUDGXPRXcgdyOJloVHTUAnwTXkhyyLfdNOsCBfxpThTEuJIwcxHmISVWxVk");
    int PGScrbXf = -1956798906;
    double eDIEoivvOXorj = -676631.4177138007;
    bool zcAoEykmniOT = false;
    double yMrXDDVKoz = 256264.19143318225;
    string jORKonwRMhyixMRa = string("ijBUaRcajtEjOVwqAJsdeXAdVwtfKAolDFmVzFXCxZVTIXNDcbfAlglzaQtRztZsXgvzEjJZkHmKLLHbxB");
    int jtUZssTlMTd = -62741034;
    int UhAjtNm = 1218674245;
    double TohffhFgSd = -772700.8644265109;
    bool JIEmFJubrY = true;

    for (int kPJTUWqAQVdhN = 717100145; kPJTUWqAQVdhN > 0; kPJTUWqAQVdhN--) {
        ySsdsYqTWaqNBOT -= eDIEoivvOXorj;
    }

    for (int alqSRHnGS = 441905950; alqSRHnGS > 0; alqSRHnGS--) {
        JIEmFJubrY = ! JIEmFJubrY;
        TohffhFgSd *= eDIEoivvOXorj;
        TohffhFgSd = XkMSSymVPMkI;
    }

    for (int ujiwolvVSb = 147376456; ujiwolvVSb > 0; ujiwolvVSb--) {
        TohffhFgSd -= XkMSSymVPMkI;
    }

    return UhAjtNm;
}

string ZnOxTyV::nQFhtBBkgjGKqO()
{
    bool mIGLYgZpHoBL = true;
    string qpblTZUYYrRhLE = string("EJzOueIRQpmszRlwcRhfoUsqCxbJZiGrPglhmhVfXDirbxZSWcHSJAX");
    string DabOqIfN = string("BgvrFfAaTjQQfNDmYDYjgyEuGSurvJUVyJRWcSwAjjYEDeJurZClVBFIkuimwWoSVBEVRquhdpHgiNQsKjUIdTpuGuFFHZiKQjYtSDfUhNuNNuqdNBQZVOYvPQmfOrxKWWMmreUgYdWogthdYpf");

    if (qpblTZUYYrRhLE < string("BgvrFfAaTjQQfNDmYDYjgyEuGSurvJUVyJRWcSwAjjYEDeJurZClVBFIkuimwWoSVBEVRquhdpHgiNQsKjUIdTpuGuFFHZiKQjYtSDfUhNuNNuqdNBQZVOYvPQmfOrxKWWMmreUgYdWogthdYpf")) {
        for (int wRREahWdHAB = 2030874368; wRREahWdHAB > 0; wRREahWdHAB--) {
            DabOqIfN = qpblTZUYYrRhLE;
        }
    }

    return DabOqIfN;
}

ZnOxTyV::ZnOxTyV()
{
    this->hyPcRbOoHNHbR();
    this->DQNJIQGO();
    this->wKhDVyyQJEcBnOr(string("DSbxMfdTuYQMwYXgqoU"), -1333141452, false, 1500606777, false);
    this->dDEQvgERddolumR(332043.1736902748, string("CBbfQzJYpRRjHgUuhaNTnqtKapmnsIBaMYVAItRjJxceNhHBWQnEQhryKFMYkPxUKMykhwaUWyFcbAacYunGHvTQAhgoGZSqvzsnQiEPqdidnsaQOevZgbwTiXReXxLWGCUkNPDzocMmDHwiZAffxpWZmWZfAglutlmsvkwVtFvXRqXsO"), 636122.1600376231);
    this->qozdbxwiefnb(false, string("vWDKNBcqTVVRXceMXVPgQNPQlRaJBOviSNBjQruqZpBPevwGzLNQbjqIjvzhIdRAHtPqbBNLTjcDuvlZWdgMzfzdhJZHCOqiROVxPvGiTLZxyTKVpjDUNoEtCrpPsbTjqaaMOcsYflvhPbILJlkZdAYLnTtMpziYCfGEIbtNxTvcxvRFVUmhVRWzQMsfzSOIOuWkfqaMdWJDanUyRNHBtAxTJiDBqiOcmWtqBEDfoKWdoELZSM"), string("hHULihfeGmRZayWWvHWQxSjtCVYmeIhKCXMPbvEtIlzzWNeVLVrXoVmwSVQxCVuJTQcRHJnBaGBzNSwfpfcptHkSasbwfkfmDrPwniMUuBBQWkGuPpVZjugGFqNJNnJocdXNcNEIZXjDnIULNCQVEigVQFaqZADffDmGHZWNPncTLLrqxuHYlhpxaXMDuZPqmKqOuSOttTWNUsIcoZNByOY"), 240160.22522008736);
    this->xvTFZDLKaEh(398373.79778812407, -1397643973, -757802.8629907378);
    this->iyMKcGUe();
    this->CnsZXlcZgbVjGK(string("kUrahTxZohKNyUeUFoGdycUGfyVDaBttHkcxjmywZauOqeWLFmpNqucyvmRLOSDMbACcUQxsqFKLsnrhHjLgADAOouaTKibixcQNUaBPyvXUUfmkVhabmjkhSdViLAmOFDMlOCCXmsaWZGsfbtDkUYsgRANmalatSVrGeSqxNjMtQIWTcfNXatuVVNANzdkMOmvttzyXhKLaTvszvjtjvDiRCZyNOOfqhHIHDwvVYHXiXSGePlZKCwhfGlE"), string("WfMPBblVSSEEQgCHWRrHVRWGmIikSEEolWmrsEXBccYTotzsqXBYTSkBcufnAjCsATEcvhkyBvVxyWpVxinkVMJc"), -227961.1099255241);
    this->DYzpEzhdAXO(false, string("exctLzFkkRdWxGGuuHaNZbQuZCgZWP"), 1021097.8997569751);
    this->QKQEFt(false, -1385428061, string("DmxIbdcfikOjSxiFrCWREUxJLuCqTfttuEIwiTHCkvjAwbNP"), true);
    this->cBtCoom(string("VjSCrmJMrkXPPFrRiZlyTAAMYuipsbDWqAoGPSlvbPFGZHioznixpDWSjTzWHmUFUqSgKtZUEFPkhxqyeoIaQHqDUSlULTqjZtmzybguLizSoOsdsmMbYDvkvFRCtatLSZZHeqzaZDXozOamZWzmyIhb"), string("llgZCDXdbAdKIMqPjvxcKDcqCyyoyoXTFBwuneXJDFVJrccTHxDNBnmWvKSMdxlvLePavAQcaDGxNIeXVozuCqeANtRMlBxzGOxzFBPMCAYHPBBKkRZDpuCJybDCteGcnvRoGsiiwcgskyaFsGCDFekjKNMSpTkvOOJanPMFIHMqIqzxUXLiubfEphOemBZmixBZaeJrasBaYmpoMiaJI"), true);
    this->PEpPtSXdNj(string("wktzBibiYxQvfzMxVPxHrqCDvkBUDGtBGLStCubv"), 865990.3573862686, -566861.3367756183);
    this->nQFhtBBkgjGKqO();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NNHvB
{
public:
    double KYUoYsoRU;
    double BOlOPshPTajRM;
    int OYhKyShQDxZ;
    double zsvsVcQbVe;
    double SzdSvQMvHM;
    bool hsrlnUPy;

    NNHvB();
    void XhpIZWeoM();
    string tvqFLrquELH(string UJcPSGxDtm, string PjjWQSmJthvRA);
    bool SmMuHNhZtfXIvdaj(string VNeRBpOAlRtkfrrK);
    string BJLnUaqxjYPE(int tGrkTORjHZuWY, bool KjmJOoTXlAm, bool VVIIgYK, bool wAiRcjY);
    bool yzXusI(int aqIWMyI);
    double gKtMaNERV(string MiKIKsfJLQIQzSup);
protected:
    int pYDsmpMEyqtvoPPN;
    bool LVUDLKITS;
    bool qiMPpqnVwWhVsPCN;

    int quseVtGvec(double trRiPIZHWnzsZFx, string qicsy, string SWtRcXq, bool xxmvcuzuuMxk);
    bool KJRaWsGwJW();
    double wHIofEaNNxNuuJcJ();
private:
    string jtPInC;
    int vTzvKIEFnpQE;
    double dsUZKvasBeZKGsuT;

    bool QWBdpapH();
    bool uGZzjPjlVuc(int ldfXRKJxsuWHtdbH, double RaCPpDzktnFV, string hZjkkaRNgykwH, int CiUrghRxkbD, double YXquz);
    double ZrFwbbytqmu(string JdoBdVcfjKhtlDKj, double njAapOusXZuTEr, int CpIMvGl, string royMyeJ, string FIeWyKB);
    bool IIqolYuDEjyRnhHB(int ncwJglTrEjF, double UtzYkMujYEq, int SMwGlDoq);
    double FpDqqtdO(int dTyyXi, double JwrbnpKnqsDpUZ, bool rmqPLXSRvrRKEdDH);
    void PQGEIuvGHMO(int hrfNgdjhfWKkQH);
    int FNWhOcWOhPLfJ(bool eAYNCvpfrDovUX, double vUxDlzrNvayyRFVw, bool KblMqyorsw, string vhkOHzIiVjhiImW, string CxBgj);
};

void NNHvB::XhpIZWeoM()
{
    double MnRQsMqTrD = 282777.09564659186;
    string qFdprAmbGpDaPaG = string("tJLoUfbjIbmlkpqDvyKJdCkUtKnSRVqLHvgDWaNUyGaOEcFsyAxhoFyhswIGVwOXeCmUQHnTeDIEnuUHZisXhquzKKSmTtEKCAk");
    string IMweRIoZxCHhGs = string("FDyqpkoZqvGuFmDnEgRRBtULpHMAUuaCIRcIxGRUCqRIXFxPgsOdshnqDOXdWurVVMedAhlasqVmDJqEHYKtNFeLoWAyMiYobuxnlkIvyiRzKaYFBIUueqgoVJwKHGZQod");
    string tIGjjs = string("nXtQSrIXLjBUGkjZrjMNNrHnE");
    double aedObheveuBUae = -985012.5898990666;
    int EwOSB = -1132103046;
    bool HpVfqWz = true;
    int wfBltQEMphbcz = -614879377;
    int almdCKwDe = -1039991273;
    double NtHSbrKcihUTkGNT = -87090.24798068602;

    for (int HfloXVlW = 1328977183; HfloXVlW > 0; HfloXVlW--) {
        continue;
    }
}

string NNHvB::tvqFLrquELH(string UJcPSGxDtm, string PjjWQSmJthvRA)
{
    string aAgbiYzuNkOcMI = string("cmouEzhVSNPLuxNYTcOEPktJYvCsgJIuwTg");
    double ZcnzOTrIVRzj = -862206.2939705919;
    string YKowsrdEurMJ = string("olnsTJJkNWazlKwdUEfyoGwVDlVoz");
    string ZYZdchZc = string("qzjzVjjpkLmopasNVJgJCRGCbDaFYsWkxXFDjXqBMUXqsJfDEfxbDppfOtXdmvxHOySljXYdkXEcLovMb");
    int GlZiJwPJ = -1236502001;
    bool wbedWJ = true;
    string EipqQYWzdeNjos = string("Z");
    int nmgRDDhFoLpGgDw = -1969476352;
    double hFJDyzvFhrw = 155840.90151336865;

    for (int tzLMYKyFLLMGAVwr = 1738644701; tzLMYKyFLLMGAVwr > 0; tzLMYKyFLLMGAVwr--) {
        ZcnzOTrIVRzj = hFJDyzvFhrw;
        aAgbiYzuNkOcMI += UJcPSGxDtm;
        hFJDyzvFhrw = hFJDyzvFhrw;
        YKowsrdEurMJ = UJcPSGxDtm;
    }

    for (int uOtkiKgVj = 644695727; uOtkiKgVj > 0; uOtkiKgVj--) {
        GlZiJwPJ += nmgRDDhFoLpGgDw;
        EipqQYWzdeNjos = EipqQYWzdeNjos;
    }

    for (int ElwxzHgsid = 314135118; ElwxzHgsid > 0; ElwxzHgsid--) {
        UJcPSGxDtm += aAgbiYzuNkOcMI;
    }

    for (int GEUaWaTLfgULx = 1271120741; GEUaWaTLfgULx > 0; GEUaWaTLfgULx--) {
        nmgRDDhFoLpGgDw *= GlZiJwPJ;
        YKowsrdEurMJ += EipqQYWzdeNjos;
        ZcnzOTrIVRzj += ZcnzOTrIVRzj;
    }

    return EipqQYWzdeNjos;
}

bool NNHvB::SmMuHNhZtfXIvdaj(string VNeRBpOAlRtkfrrK)
{
    double RfGQqAnQIZSDG = -729294.3202400502;
    double nGPipa = 638954.15611984;
    int ATCewLiMSXJj = -1084691087;

    if (nGPipa < 638954.15611984) {
        for (int kTAnevFuCmbLEevp = 1844355172; kTAnevFuCmbLEevp > 0; kTAnevFuCmbLEevp--) {
            ATCewLiMSXJj *= ATCewLiMSXJj;
        }
    }

    return false;
}

string NNHvB::BJLnUaqxjYPE(int tGrkTORjHZuWY, bool KjmJOoTXlAm, bool VVIIgYK, bool wAiRcjY)
{
    bool mvYlkaCfyyb = false;
    string fYlxexqAUK = string("PnkwSXCgadCwHJjtgMzJuHuhrNEbKOCztpVeOsPxvOdpJWpsNheGCCTBOhbghvtxtNvunOBqqHGNzwCbPmXLZUogWXVhNQNaHxzaeq");
    int ExQoMcciHUwBTUpD = 1773313987;
    double hHPVVmnZlrjWUv = 958044.7883059935;
    bool jBWeNGHTjYPTkFhT = true;
    bool pgzQcUHRdH = true;

    for (int HcsRFsd = 891123756; HcsRFsd > 0; HcsRFsd--) {
        mvYlkaCfyyb = ! jBWeNGHTjYPTkFhT;
    }

    if (KjmJOoTXlAm == true) {
        for (int SOdpruKlgk = 1608600532; SOdpruKlgk > 0; SOdpruKlgk--) {
            VVIIgYK = ! pgzQcUHRdH;
        }
    }

    if (pgzQcUHRdH == false) {
        for (int nAsORstNkMwQp = 1385617870; nAsORstNkMwQp > 0; nAsORstNkMwQp--) {
            wAiRcjY = mvYlkaCfyyb;
        }
    }

    for (int EmXQYN = 1745429032; EmXQYN > 0; EmXQYN--) {
        VVIIgYK = ! wAiRcjY;
        mvYlkaCfyyb = ! mvYlkaCfyyb;
    }

    return fYlxexqAUK;
}

bool NNHvB::yzXusI(int aqIWMyI)
{
    int ausniaUIvkuMjD = -1501847445;
    double AKbnFqmjaQyEiOr = 55457.89894234204;
    bool NyeZQkHMEYvEBBA = false;
    int UrQrkIj = -100704072;
    bool cuVJd = false;
    double foQbmqwnv = -159349.24838976297;
    double lIzDEgIBAahebC = 815685.1364121576;
    bool KySGDKILno = true;

    for (int nArngJTleAhoVLk = 2028715126; nArngJTleAhoVLk > 0; nArngJTleAhoVLk--) {
        AKbnFqmjaQyEiOr = foQbmqwnv;
    }

    for (int yXpFsFW = 1802859168; yXpFsFW > 0; yXpFsFW--) {
        aqIWMyI *= aqIWMyI;
        UrQrkIj *= aqIWMyI;
        NyeZQkHMEYvEBBA = ! KySGDKILno;
    }

    return KySGDKILno;
}

double NNHvB::gKtMaNERV(string MiKIKsfJLQIQzSup)
{
    int xOUZBQfIbNdbxk = 929203690;
    string nUnfwkeLCoDXYL = string("VGlnnfXxYJpkAAIKibjTbgTfqtIrMqokgaHqSOVwUewUhoHnanOkgojqmVKMURCJYHsLHpyPjDRVtxhJjoFxbQajnVqcheMTUsTxuewkhNMCWSyxpmkvQkYILwwoMMndfZjaJYOSuCnyJDsXzXrnIlEeLMLZJHpYm");
    double IVasoKKXdUQAdWE = -769544.6220479971;
    bool UVApUwQkPz = true;
    int KwEJfxYNxj = 1924486711;
    double LsHXAGsFjBo = 433459.0996328601;

    for (int aEEFDjbbuTEGzkz = 721097148; aEEFDjbbuTEGzkz > 0; aEEFDjbbuTEGzkz--) {
        MiKIKsfJLQIQzSup = nUnfwkeLCoDXYL;
        nUnfwkeLCoDXYL += nUnfwkeLCoDXYL;
        IVasoKKXdUQAdWE = LsHXAGsFjBo;
        KwEJfxYNxj = xOUZBQfIbNdbxk;
    }

    if (KwEJfxYNxj > 929203690) {
        for (int gXUJBKUTN = 1445004719; gXUJBKUTN > 0; gXUJBKUTN--) {
            KwEJfxYNxj += xOUZBQfIbNdbxk;
            MiKIKsfJLQIQzSup += nUnfwkeLCoDXYL;
        }
    }

    for (int qbbUfnEMditjed = 1648792487; qbbUfnEMditjed > 0; qbbUfnEMditjed--) {
        continue;
    }

    return LsHXAGsFjBo;
}

int NNHvB::quseVtGvec(double trRiPIZHWnzsZFx, string qicsy, string SWtRcXq, bool xxmvcuzuuMxk)
{
    int sBXnqFoeFEDKazj = -1952468210;

    if (xxmvcuzuuMxk != true) {
        for (int BrFoNtXSW = 17633164; BrFoNtXSW > 0; BrFoNtXSW--) {
            sBXnqFoeFEDKazj -= sBXnqFoeFEDKazj;
        }
    }

    return sBXnqFoeFEDKazj;
}

bool NNHvB::KJRaWsGwJW()
{
    double JBRKslbY = -95606.64628583858;
    string YqfIkIGNx = string("wkweMevCkupgPpdpNWhvMFirMYVaigVYROcgGvKlHXFDhkcWFgxbyxicMVIkhIGUqBdOMVhmwZgamcUQZwfHulDEXsyXOKnexeLDNUkCDCQgPsAVVsdGUCcDWKXrsDLPYJDyrmFFXYwoYIpUsQGCENzhKHn");
    double pOAPfQZGXjGu = 321339.01550003554;
    bool TXlutYvEWqwuGkw = false;
    bool TgDpyIi = false;

    for (int hzYAzmtQXyNv = 1283413575; hzYAzmtQXyNv > 0; hzYAzmtQXyNv--) {
        TXlutYvEWqwuGkw = TgDpyIi;
        TXlutYvEWqwuGkw = TgDpyIi;
    }

    for (int FaipMlxZJvsfe = 783258386; FaipMlxZJvsfe > 0; FaipMlxZJvsfe--) {
        JBRKslbY /= pOAPfQZGXjGu;
    }

    for (int zaDWYqynCvH = 242934429; zaDWYqynCvH > 0; zaDWYqynCvH--) {
        TgDpyIi = ! TgDpyIi;
    }

    return TgDpyIi;
}

double NNHvB::wHIofEaNNxNuuJcJ()
{
    double CXfTIiARQ = 306720.2900936107;
    int HDSBqcPA = -57155761;
    bool TAwmO = true;
    bool bRnFGdKJnDxAti = true;

    for (int wdPPARan = 437486692; wdPPARan > 0; wdPPARan--) {
        bRnFGdKJnDxAti = bRnFGdKJnDxAti;
        bRnFGdKJnDxAti = bRnFGdKJnDxAti;
    }

    for (int hcYaAE = 142770985; hcYaAE > 0; hcYaAE--) {
        HDSBqcPA = HDSBqcPA;
        TAwmO = ! bRnFGdKJnDxAti;
        TAwmO = TAwmO;
        bRnFGdKJnDxAti = bRnFGdKJnDxAti;
        CXfTIiARQ -= CXfTIiARQ;
        TAwmO = bRnFGdKJnDxAti;
    }

    return CXfTIiARQ;
}

bool NNHvB::QWBdpapH()
{
    string oWobZi = string("TMVdkqZMnkHTVYytYJiOiIWqavepsgIqqMaenquyJptqDfOTKAzrSBgizUrSfVvrfEKXqIPUMgeVKpgSiwZhjqFumyToQhCXiOUpwIbYVohFibQuZPFHRUrURnjekXOddHOOtUFqisfwjHJnplKcaIuJMLxzSAjwkCumgKmQcATWJavneCIiwqiJoyEDiGRcsSYheLhskaHFCKPOpLfITYZPEmsDuUUQEp");
    bool LjoNaOPCkHM = false;
    string oServxezT = string("mBrNIlYVRcazoVuDbpWpbQqkXXcfNPkUjGgkYwEMzLVQLHGgAtMjhAcjOejORaIhOIKjXJYfTddyGoMotAWeSaTtFliGfHdVhMQLvLzKfsPTCmlmVQpKQiXmpoxhdLvHCExUQavsFVasNaWpCUYocxaWIZFSmdcPlmxxLUYVZflFSXEdJiLTxHo");
    string rTVuAKnpKtfyZo = string("INdqDFYjVmfjsGBYieCUktUcaAYVmIqoMNgvaIDjjZzQsANMqjjRkqquwStZjRBPWBGMGRgqqtZWSYBq");
    int dgOqCXo = 691230916;
    int bWumEFTA = 762547884;
    int RdxICgyznh = -1719496027;
    bool LJGPSkqugdJAWxCJ = true;
    string PCeZp = string("GPTyCsrOOuXpydZXPCtEsyBHIMLaHhoHbichMDzVBxjDEWwzfqMQzCBwKhFeebQFXANaLXmjmwYDVwGMoiWVyRdjVVFdpqZdSEvMyAomQxNIuDqoduElmJwmkoGGkNdjLSARCSfWOgTPRQPyLqzvxxxseBvufXopYkUS");

    if (PCeZp <= string("GPTyCsrOOuXpydZXPCtEsyBHIMLaHhoHbichMDzVBxjDEWwzfqMQzCBwKhFeebQFXANaLXmjmwYDVwGMoiWVyRdjVVFdpqZdSEvMyAomQxNIuDqoduElmJwmkoGGkNdjLSARCSfWOgTPRQPyLqzvxxxseBvufXopYkUS")) {
        for (int jGBnTVlxVjmg = 1418410076; jGBnTVlxVjmg > 0; jGBnTVlxVjmg--) {
            continue;
        }
    }

    for (int AIilicbjzKdrRw = 1777639011; AIilicbjzKdrRw > 0; AIilicbjzKdrRw--) {
        RdxICgyznh += RdxICgyznh;
        LjoNaOPCkHM = ! LjoNaOPCkHM;
    }

    for (int bERgKyLC = 538817990; bERgKyLC > 0; bERgKyLC--) {
        PCeZp = oServxezT;
        oWobZi += rTVuAKnpKtfyZo;
    }

    return LJGPSkqugdJAWxCJ;
}

bool NNHvB::uGZzjPjlVuc(int ldfXRKJxsuWHtdbH, double RaCPpDzktnFV, string hZjkkaRNgykwH, int CiUrghRxkbD, double YXquz)
{
    bool ZLUtJDYuVHalsdhk = true;
    bool rbDdIBtzIZoFwUv = false;
    double PvghQXapNnORWFOv = -800736.0162103818;
    int tnRMNdefL = 1112687083;

    return rbDdIBtzIZoFwUv;
}

double NNHvB::ZrFwbbytqmu(string JdoBdVcfjKhtlDKj, double njAapOusXZuTEr, int CpIMvGl, string royMyeJ, string FIeWyKB)
{
    string MtqaMiMcdGLh = string("CLTEodMySSgfNtunQbLUMQQCghmXidmiWiyjResqPdlWfwuWQGtGwbfuXSDwbhmoyWoZUTfQDPbFcBXUyxecqLtCGOuwIEyqddFKubtmZMmlVjByIqNdrGjiejdjSPnWEWWkSmrzFNRoGMNgcMGrdTFoTpJYQoBxDgyGUfukUMX");
    string GzuOxZNtZJW = string("RIgFekSiULMhniKUYvswnRLNNRjcuBGviZpBZmaAJhNYynoLWOgldqHrEvHQeFqgsxbEoidLKuoWpNuuYjcXPvOgqBDDCduWcWKcOGzlfrNCeeEbqxyBRXhDyMDFSHYiDaRRyfpFhQhtYxwPaNJwPmDuYPnXksHFZyxcBEujDBUtzfcawpPyuXamkezVMDQmeofVxXHqUNYHGpJRTqv");

    for (int fMeBCBPPN = 2095083317; fMeBCBPPN > 0; fMeBCBPPN--) {
        FIeWyKB = MtqaMiMcdGLh;
    }

    if (MtqaMiMcdGLh != string("sBrryygFgeuvfEGLZqFyhKRYEmrAmstCXbHVvQFakzzczmEzZxyvgPWSSmKJfzoiFUZhfMHUnpklZpacNqnHtdCyLJMRFkjfvHdmOLhkVHALCDTZfrJDIjLrXgkBjQOybwgiKPaxdtaoLMoDYXeDobMctaQZGprVXEfUgsscbIDqpfezzuIvnmHO")) {
        for (int RTUcCeTl = 496815623; RTUcCeTl > 0; RTUcCeTl--) {
            continue;
        }
    }

    for (int QJRiAIKjea = 512472893; QJRiAIKjea > 0; QJRiAIKjea--) {
        FIeWyKB = JdoBdVcfjKhtlDKj;
        royMyeJ = FIeWyKB;
    }

    if (CpIMvGl >= 1880892572) {
        for (int SzmlPuaOcpv = 1054873472; SzmlPuaOcpv > 0; SzmlPuaOcpv--) {
            continue;
        }
    }

    for (int YJpSl = 1465109587; YJpSl > 0; YJpSl--) {
        royMyeJ += royMyeJ;
        GzuOxZNtZJW = GzuOxZNtZJW;
        royMyeJ += GzuOxZNtZJW;
    }

    for (int OhYjdPwZj = 1626619886; OhYjdPwZj > 0; OhYjdPwZj--) {
        JdoBdVcfjKhtlDKj = royMyeJ;
        FIeWyKB += royMyeJ;
        GzuOxZNtZJW = GzuOxZNtZJW;
        FIeWyKB += GzuOxZNtZJW;
    }

    return njAapOusXZuTEr;
}

bool NNHvB::IIqolYuDEjyRnhHB(int ncwJglTrEjF, double UtzYkMujYEq, int SMwGlDoq)
{
    int WVscnNIfCGptK = 2045439706;
    double EIbIvaYZZuHVWmP = 230966.36087452376;
    bool LKnHywUssG = false;
    bool kuTUMAhrfaG = false;
    string iGRCirsRdqT = string("rUHAitMrPbDMcFjIuRqZGqOQrpzJTgqHUjckbEQHnrQPxaFJuJBYHsAZvcCVbMVREgCKZBAkgPzokFJKFuzxeKRfYDZxDDluwFusynsWVjvttErHHytcaRRSkesJUqqaYurmuZUnqCaIQcpgtHmpCMLlsTxXwxdcBKylT");
    double HTXFhGEmBAnzQfZ = -704375.3500634183;
    bool xtChDZq = true;

    for (int TujosTimVWrw = 1725688894; TujosTimVWrw > 0; TujosTimVWrw--) {
        UtzYkMujYEq /= EIbIvaYZZuHVWmP;
    }

    if (kuTUMAhrfaG == true) {
        for (int tGpTGUIFjNeWH = 1244841768; tGpTGUIFjNeWH > 0; tGpTGUIFjNeWH--) {
            xtChDZq = ! LKnHywUssG;
        }
    }

    if (SMwGlDoq == 2000358322) {
        for (int ixxMjLBHADs = 308161543; ixxMjLBHADs > 0; ixxMjLBHADs--) {
            HTXFhGEmBAnzQfZ += HTXFhGEmBAnzQfZ;
        }
    }

    return xtChDZq;
}

double NNHvB::FpDqqtdO(int dTyyXi, double JwrbnpKnqsDpUZ, bool rmqPLXSRvrRKEdDH)
{
    bool Bakcecz = false;
    bool fBQCKQqUnA = true;
    string nWmBDsBgizOkiE = string("Opi");
    bool zAHvGTIFTe = false;
    int kHRCPaMOvTUCsj = 1123401156;
    bool SsxzXaV = false;
    string CcEeXIOsGSnY = string("eJJfVKkPnNzRlZZFUSFX");

    if (Bakcecz != false) {
        for (int FYwzzDHkteu = 1595380518; FYwzzDHkteu > 0; FYwzzDHkteu--) {
            continue;
        }
    }

    for (int hDiQKsqIVPF = 1588275825; hDiQKsqIVPF > 0; hDiQKsqIVPF--) {
        zAHvGTIFTe = ! Bakcecz;
    }

    return JwrbnpKnqsDpUZ;
}

void NNHvB::PQGEIuvGHMO(int hrfNgdjhfWKkQH)
{
    bool QDQOqwfjN = false;
    bool kBqSyXORYZecGT = false;
    bool TzujfxqLQTfk = true;
    string SVpowvmRJVKyVjN = string("lSPk");
    bool FUBDBlJINvtXrvGC = false;
    bool AETCvXRRafTpY = true;
    double FGbWtuzwVlgNYxo = 816386.9645910779;
    int AUhSSSpsfGRnJ = 1344297265;
    int VSnvYOoUEJybTN = -1748669341;

    for (int idohfzOqDaPm = 86120964; idohfzOqDaPm > 0; idohfzOqDaPm--) {
        TzujfxqLQTfk = ! QDQOqwfjN;
        AETCvXRRafTpY = FUBDBlJINvtXrvGC;
        AETCvXRRafTpY = ! TzujfxqLQTfk;
    }

    for (int ELrERJahg = 1106447863; ELrERJahg > 0; ELrERJahg--) {
        kBqSyXORYZecGT = ! AETCvXRRafTpY;
    }
}

int NNHvB::FNWhOcWOhPLfJ(bool eAYNCvpfrDovUX, double vUxDlzrNvayyRFVw, bool KblMqyorsw, string vhkOHzIiVjhiImW, string CxBgj)
{
    int PsczzdfSmG = 1387765273;
    int wVrtopug = -538105448;
    string cDGEFPDp = string("SBvUmtILieCpIBsssWXvpHgXpevGLgAMqySfiWVWEMaNsXFvmNiFpQrHPsClSdQsiLjzWfMTIGidrSiQwaKNcHKUeTAVmVaOZKQdxEYOKSaUhQfOhSIjsQhjvrMyrHpMSdGUTGObHPFxobWYjDdpnRzgAwTpNrgIugxZLFFCH");
    double NOPxTkEjKO = 1044043.6349146403;
    int ncEIKLtA = -682177870;
    int bOiANQRs = 1306280075;

    for (int AMevBetrIFflWQtJ = 1119393643; AMevBetrIFflWQtJ > 0; AMevBetrIFflWQtJ--) {
        continue;
    }

    if (cDGEFPDp > string("qoHiClamvfqvPPkcQMdKliZppxcetKfukUpxfWqAyHQWUiasKHiWdehmyHSvBuyRZDlhwhqeCFHDBSaLbrKnNKOULxxdwueLlmSZqBnmlNyLRsFparsEorFrDEpciNWvKvHEYBzqCWAwrMqMAcAIGHmxrauIxPJbpWJvglgZnDsEzOwOwezditGxdPwvjEdfqLanWEPfOtIAzRLQrGWqeHhCzcLwpkiANTgmGaBpCLqNuyQa")) {
        for (int xSWXDRBgFZo = 527087177; xSWXDRBgFZo > 0; xSWXDRBgFZo--) {
            CxBgj += CxBgj;
        }
    }

    if (wVrtopug == 1387765273) {
        for (int vLaeyg = 655641856; vLaeyg > 0; vLaeyg--) {
            PsczzdfSmG *= bOiANQRs;
        }
    }

    for (int oMqPNUPcYu = 655594708; oMqPNUPcYu > 0; oMqPNUPcYu--) {
        eAYNCvpfrDovUX = ! KblMqyorsw;
        PsczzdfSmG *= PsczzdfSmG;
        ncEIKLtA *= bOiANQRs;
        KblMqyorsw = ! KblMqyorsw;
    }

    for (int ukCjvRMykGvoGozR = 1743983401; ukCjvRMykGvoGozR > 0; ukCjvRMykGvoGozR--) {
        cDGEFPDp = vhkOHzIiVjhiImW;
        vhkOHzIiVjhiImW = CxBgj;
    }

    return bOiANQRs;
}

NNHvB::NNHvB()
{
    this->XhpIZWeoM();
    this->tvqFLrquELH(string("fTToEQbYpTKVRSJPrYuPyCAbuTKuclSzlvnShxcsWvGQwOMNXsoyHBdefaQhzkwdcYAYYPXLlanYbmnNvSXFZOwcoKKzFheXAJVBMlUQasuPsJQJsPDlQutqvnAdxemdWwVLBVOqZQOzOhVymhbEKdarOuZNFjhfGqOwUDAHUHGXpLOG"), string("ezEDaMVi"));
    this->SmMuHNhZtfXIvdaj(string("aNBpFqMQiaKWRVqEjryBypLxFVcXjvUpDEWBsIGUmjjoTFWfQyHWNLEZOhzvxRskwngVDLhmyTbYrzAUVJnSBSVPynNoUOLcaLAYtDiPPrVJJKaJSyozbggGlvxaBzBiNPymnDSEQKbxofDXJOfaKLFPZdhVnTDMyOrunDqviIJgYxWCFU"));
    this->BJLnUaqxjYPE(-1586579968, true, false, false);
    this->yzXusI(-8233602);
    this->gKtMaNERV(string("TWuSLHNfMtXT"));
    this->quseVtGvec(276036.13361677533, string("NhkpZpTFAifDYXVblQDAIJYWCiuNiFiVXSXsSZsdPMEqcFezAHxjQUSActgMNSmlwSpwaojnUgoVmAhsXZLKUcmEqYwFqxEYtRNklgQSkOXBLtWPWWPMKEMtdCeAkAFrdgHefBupWXOqUPoRkVnhQqpkSaUvQrYvETRfMlkiatdGiGIxUclIarubWAzWiSgUL"), string("OVQqjWuXMUYMfuLJlcJBWAxBMUcsaxSESCDjikrTDDmJKjJRYjvUPfmhvKYYqPZxEOtCAmgOBNYWBNUsmesWMWWLBAQYgOmcIENPKSBuIsMlEbyVFrHuruUHqxVpIZWLtbvNYPxgsdkEaBjXldENMOkxOThuXMMCOEhfzdpuubmGarDSMWF"), true);
    this->KJRaWsGwJW();
    this->wHIofEaNNxNuuJcJ();
    this->QWBdpapH();
    this->uGZzjPjlVuc(716747737, 454748.6335191723, string("NQOxxKRbDALdCgKLJXCIqAahQRWuSpouAetjMmUoKYApaZyvoFRStWXRxtadpoDXaZtvqrdqiZOLErcSctVricONeosMRaBUwsXPpH"), 2146387105, -885318.7971637591);
    this->ZrFwbbytqmu(string("sBrryygFgeuvfEGLZqFyhKRYEmrAmstCXbHVvQFakzzczmEzZxyvgPWSSmKJfzoiFUZhfMHUnpklZpacNqnHtdCyLJMRFkjfvHdmOLhkVHALCDTZfrJDIjLrXgkBjQOybwgiKPaxdtaoLMoDYXeDobMctaQZGprVXEfUgsscbIDqpfezzuIvnmHO"), -1028582.7308620426, 1880892572, string("NLVAwdjbjziYSwHSwOumwaKWCbBfWcIfupFwJRbIirDILydCtqiFUTvklkDZSxClsDsTTNOBdnwqrASXSZZmhqfJdyXUaOKjCpzJAbZZpUVBxKWkKzgLgFxMxCduzn"), string("fvoOyyPgJMLqbCAnLZjcLZqunDwzTaipjytJuRDaBMjRJmkJkDNzdkuMYbNydtgfIsHqNmPSUzwPTuepVKVikRezkaChFRQupbFOwgEAATqUwmDAsNoRbuAvWcosIaMJmMLbyuRpqqEiVyJYXtpmcIoxxUMztNxktomtkWFMRyPXbVnMFWIxAytmzWZtIwwArOBTrQVSsZqGYLDbEIqFyQIdzbDBsUIeuCXsmhMMBQPHugcYUtKNbt"));
    this->IIqolYuDEjyRnhHB(2000358322, -45628.44412093879, 824058243);
    this->FpDqqtdO(-800230923, -999886.8435627545, true);
    this->PQGEIuvGHMO(848368006);
    this->FNWhOcWOhPLfJ(false, -808384.1434805902, false, string("qoHiClamvfqvPPkcQMdKliZppxcetKfukUpxfWqAyHQWUiasKHiWdehmyHSvBuyRZDlhwhqeCFHDBSaLbrKnNKOULxxdwueLlmSZqBnmlNyLRsFparsEorFrDEpciNWvKvHEYBzqCWAwrMqMAcAIGHmxrauIxPJbpWJvglgZnDsEzOwOwezditGxdPwvjEdfqLanWEPfOtIAzRLQrGWqeHhCzcLwpkiANTgmGaBpCLqNuyQa"), string("lIecfLF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bHAcuQFLMpWFCkcy
{
public:
    bool febksn;
    double kVIKtkkAHim;
    int EmeuLzWmrgXffL;
    string KjICKuGUUa;

    bHAcuQFLMpWFCkcy();
    int wqGlRuHZNU(bool RwsXX);
    string euTBssMztxXuiK(bool kvjgiwfjAKrsxr, double tQnujhv, bool ONZGiQONLJm, double eROXg);
    void NySaoneVVMcsVmt(bool GadpJPQXDisvUjX, bool EknkqfNnVJNvCIqL, bool SAyEvYkmKCUMyhN);
    string JFBgzx(double PTXbHMg, bool UumuNTktizWBg, double uSeDdRyuEhQhvJS);
    int VHpaynnDlNiybYfT(double yUKJUpMgZj);
    double WgCDlhp(double cWropVqMZLoox, bool JncLytrOqvTddsy, string uUNtisjLZKcDYeS, string ofusxxAoJ, double csCxLqAgSIPN);
protected:
    bool SzTAaWoSDIHZnf;
    bool vNVWY;
    bool vEAZZtXt;
    bool daWKChT;
    double SSEVSYLibcs;
    string jrEfbdkDTfUU;

private:
    string bGqYeUsutn;
    int EMVrQkzyhL;
    bool DXSFlUYC;
    string OBXItGIHr;

    double vxySLPNbtShIBMC(bool kCEdyECoTLn, double wPUPtHv);
    double NXwxU(int xYqKtoeIxppH, string RlFBLczw, string RftZlBl);
    double OWQjSoya(bool FaFgVIDlnAJACx);
    string VwQoTIVpKYmymeo(string KHnBjctbGdzbS, bool yKMSoo, string Wtosxhhw, bool tshOVZ);
};

int bHAcuQFLMpWFCkcy::wqGlRuHZNU(bool RwsXX)
{
    bool mPPpITjjuiLgzvM = true;
    int jMZufVWBeCeZLKr = -1844086910;
    double RAsOxNP = 35181.76605578677;
    int YgeeNPpHBSVhfi = 965318856;
    bool UixAJu = false;

    if (RwsXX != true) {
        for (int RPgPLetYetQmym = 1926560989; RPgPLetYetQmym > 0; RPgPLetYetQmym--) {
            RwsXX = UixAJu;
            YgeeNPpHBSVhfi += YgeeNPpHBSVhfi;
            UixAJu = ! UixAJu;
            RwsXX = mPPpITjjuiLgzvM;
            jMZufVWBeCeZLKr = YgeeNPpHBSVhfi;
        }
    }

    return YgeeNPpHBSVhfi;
}

string bHAcuQFLMpWFCkcy::euTBssMztxXuiK(bool kvjgiwfjAKrsxr, double tQnujhv, bool ONZGiQONLJm, double eROXg)
{
    string MKbpTjrLFVYH = string("yoEaaViecQGIWpnWLjBngVUTzosgNfhcRzoFbInDUUOMAsAGLsmyeRzmGckXZwYZsZJeURoeZnjxUxGzFXWAijSoxmuJUvxmsNwRrosMsVhdWaIOFkBdDTgiIOXBRsHuVbbIwBcRSonkInCOEroIWbYLAWFUZRNsJpuMOYIKymowRMGJHyMRdxOLuROhAQQpuYIeriHhfJPUSMOSoXgrQoOJNHLlUSxMkbKViNglgFJsUCtgwGWcttYEZCePg");

    if (ONZGiQONLJm == true) {
        for (int oKbewBBhAN = 1191392717; oKbewBBhAN > 0; oKbewBBhAN--) {
            tQnujhv *= tQnujhv;
            eROXg = tQnujhv;
        }
    }

    for (int lrPhZHlUCVjsl = 510906388; lrPhZHlUCVjsl > 0; lrPhZHlUCVjsl--) {
        eROXg *= eROXg;
        kvjgiwfjAKrsxr = kvjgiwfjAKrsxr;
        kvjgiwfjAKrsxr = ! kvjgiwfjAKrsxr;
        eROXg *= tQnujhv;
    }

    if (eROXg < 510731.80343620986) {
        for (int MlnZMkrSlwgdr = 1412041233; MlnZMkrSlwgdr > 0; MlnZMkrSlwgdr--) {
            tQnujhv /= eROXg;
            MKbpTjrLFVYH = MKbpTjrLFVYH;
            kvjgiwfjAKrsxr = ! ONZGiQONLJm;
        }
    }

    if (eROXg != 897765.8287140428) {
        for (int LVhtxKhnFi = 875526055; LVhtxKhnFi > 0; LVhtxKhnFi--) {
            ONZGiQONLJm = ! ONZGiQONLJm;
        }
    }

    for (int fdOytDFRMLiHWv = 1055558396; fdOytDFRMLiHWv > 0; fdOytDFRMLiHWv--) {
        MKbpTjrLFVYH = MKbpTjrLFVYH;
    }

    return MKbpTjrLFVYH;
}

void bHAcuQFLMpWFCkcy::NySaoneVVMcsVmt(bool GadpJPQXDisvUjX, bool EknkqfNnVJNvCIqL, bool SAyEvYkmKCUMyhN)
{
    int hqdBgPvVFTmiKiw = 702584915;
    string uRvHdMMVdOtz = string("ckkLqXrsvmyKmGGJCNBSjcVDxXHUKx");
    string VudGSoSdKHXrpg = string("RksmYyNRXyGqaLokzvMgdwwfNIBGP");
    double bXjZXPww = -442701.1477040586;
    int FTXwtXHNgQRotmNJ = -668395035;
}

string bHAcuQFLMpWFCkcy::JFBgzx(double PTXbHMg, bool UumuNTktizWBg, double uSeDdRyuEhQhvJS)
{
    bool QKXhA = true;
    double XsGZXvrtFV = 502319.79392946494;
    string vpHOvpGlHlrwXcba = string("cVNibRAahscNfcxJpKeigZtyJVPRAXaKdjwWpFCybiHElcSkUeORiDEANuWqzbEOpwrMUHPtbEBGXmWEhowwccicCEpgmsXfYANvdkPhCuZJKbjMXfProXXcGGqAKIuRgVNXDNOZqynoPXVgTNxlwzYIQtNXWqroyxPvIvkzGcyuDEXLgWlEnRDZUJqlcyN");
    string hZxjoBAywsGkcxvy = string("eyeZHajaWOPlSNPZCCkRvaeZCqVJKiWfWeJWTXgDGUNAqwxfQifwRcZCzmxOaiVOVfjJZCVnariMzKhzPeYgfxNtvhSOKRWFXRwhKXUGuPrdJnnWtXkiNbBRUaRXIeATrsMwxIzTpuyDNQhLvvwijRSliVHsbCBfqCHKXEluGASWZTTOXUWeyOKWMfYythOolyWKTcbpBFqAIDmVwCxvCgl");
    int BRGkooTmWXcKT = 1578979212;
    string ouqFMM = string("RavtmuuzWvvfCAmAYyMepYBIAuRGdIRQoaaJJkfXsOOUlmUIInErtKyLuwCIgKhLWBZbrnPxXqocFJGoGUcGZgoXpebNzLNRCXNhOaQDynIrFUleKoZzJGUQCkpI");

    if (BRGkooTmWXcKT >= 1578979212) {
        for (int ZXiiWmRZHJNyeJdm = 1395434827; ZXiiWmRZHJNyeJdm > 0; ZXiiWmRZHJNyeJdm--) {
            hZxjoBAywsGkcxvy += ouqFMM;
        }
    }

    for (int wnIbHNgez = 2078998563; wnIbHNgez > 0; wnIbHNgez--) {
        XsGZXvrtFV = uSeDdRyuEhQhvJS;
        vpHOvpGlHlrwXcba += vpHOvpGlHlrwXcba;
        ouqFMM += vpHOvpGlHlrwXcba;
        uSeDdRyuEhQhvJS = uSeDdRyuEhQhvJS;
        PTXbHMg /= XsGZXvrtFV;
    }

    return ouqFMM;
}

int bHAcuQFLMpWFCkcy::VHpaynnDlNiybYfT(double yUKJUpMgZj)
{
    double ROgYbPBAhtdTynuX = 431570.70209306024;
    string YwFGQYpn = string("BWZCjDRHqTjTitcbDhJMwqnlsZezVbixTEVIGEQYGXkavruYeKTKN");
    bool bGfHXUy = false;
    int QNhscJ = 1983198259;
    double TiCgj = -894426.9330885775;

    for (int HvQBVx = 1509423388; HvQBVx > 0; HvQBVx--) {
        TiCgj -= yUKJUpMgZj;
    }

    for (int aqootaggn = 1883397100; aqootaggn > 0; aqootaggn--) {
        continue;
    }

    return QNhscJ;
}

double bHAcuQFLMpWFCkcy::WgCDlhp(double cWropVqMZLoox, bool JncLytrOqvTddsy, string uUNtisjLZKcDYeS, string ofusxxAoJ, double csCxLqAgSIPN)
{
    int HFuPzrSAJETkUSi = -466000662;
    double dHiSYNwyyn = 963130.2494122562;
    bool ZXldRZ = true;
    string HdZViAAR = string("mzGgAYgbmFogIVGsyZHFUEFaQAIVviKrgQBnBWAxsGIoQejDRGhlJaLVohrSOUXtLtCNkMGYHfmSYPNkrroDjGxkHgHslGvoHiJzfiQdjZTeKHraldvrawytVaoWcfQOZBNLfxiJtEDjKJeuqmEQmIHQHhYJzrnepLZKEbhUHRQTdFWRzZMRbHAmQDGNjabPcrMsXwUyhnohngbsxnYHHkMoyWHLKIXfSsqGqWIaiRDLF");
    string ObstmqzTCEFkSuBB = string("QCoOamtVkqydOFQfliExCZZrbLGhQuOOoIhwkTNlSPriElnvWjAQvJeJKwMXwpjlLmMDeSvcUXLEKjReRnfmYfzJMFqivJZOwPoIUDipToAeZSxx");
    int XFTZLxPlN = 1620736329;
    int NjSkEY = 1203280090;
    bool ctGdlDJTMJgW = true;

    if (cWropVqMZLoox < 27888.903976429647) {
        for (int pKFsejY = 1869871423; pKFsejY > 0; pKFsejY--) {
            dHiSYNwyyn *= cWropVqMZLoox;
            uUNtisjLZKcDYeS += HdZViAAR;
            HdZViAAR += ofusxxAoJ;
            HdZViAAR += ofusxxAoJ;
        }
    }

    return dHiSYNwyyn;
}

double bHAcuQFLMpWFCkcy::vxySLPNbtShIBMC(bool kCEdyECoTLn, double wPUPtHv)
{
    bool BlbSNYultOmM = true;
    int nFwFMp = -344305311;
    double qwtTE = 323965.3254462029;
    double GgPVVrhdyI = -954371.6726950209;
    string CmnXyxgsGUdKQCMs = string("kOJxfGDsefxFvPRXyCWPepdmyKRojPgqUHhKeUGUkrYJIEPlwzMseSslF");
    bool pySVEYueIcU = false;
    string BMPzDQQedFyb = string("FOnheKeXysNeIJOnvAwhnVDsFRAvFdqlCwExWtigRfcouFsEQynBoqNVLnAMjSRHVdgxadqyIbSgCNcoxnceiWEfjVllBSgORNTRvrgcAJfmGEOSKlpjPBHximEOyuiCCTlpdCSmQvZSe");
    double kuCDAQymQTnDVS = 95283.65432494329;
    string AcXFneH = string("pMQBzGqzetcIFfBtYRTszCyPKJmQqsqpmwRUYNITOagGivybBgbQIQcBXZYQdsZWwxMGlpJJkGvicRsZFWqbynVlNmCIggKAHHKxsAEamAYCaVGkSAstUCfXCWmfyxbqPkGIpfvGzxkLfMtyFqkSAzwRjIScmvcqNCaomShKTcDGEvrEePYxpq");

    for (int RmyXnalHbFx = 990668712; RmyXnalHbFx > 0; RmyXnalHbFx--) {
        wPUPtHv *= kuCDAQymQTnDVS;
        kCEdyECoTLn = ! pySVEYueIcU;
    }

    for (int vlREn = 1854514885; vlREn > 0; vlREn--) {
        kuCDAQymQTnDVS = wPUPtHv;
        kCEdyECoTLn = ! BlbSNYultOmM;
    }

    for (int kUqsKWtkKRd = 1375967823; kUqsKWtkKRd > 0; kUqsKWtkKRd--) {
        continue;
    }

    for (int hqnHMYdKoGL = 77817222; hqnHMYdKoGL > 0; hqnHMYdKoGL--) {
        wPUPtHv += kuCDAQymQTnDVS;
        qwtTE = kuCDAQymQTnDVS;
        nFwFMp = nFwFMp;
    }

    return kuCDAQymQTnDVS;
}

double bHAcuQFLMpWFCkcy::NXwxU(int xYqKtoeIxppH, string RlFBLczw, string RftZlBl)
{
    int ElvJSNAVbbFVDGa = 451313086;
    int hrBicRwNnf = 1417056941;
    bool CYZBhyQEDbC = true;
    double FWkWL = -932761.2767474692;
    double VAlLlHDpGpmd = 686568.03018268;
    double HvLxLK = -868582.1548512132;
    double afZFezV = -428195.8720588243;
    double avJqOvfavQgqfoHB = 916335.6574290913;
    string tdHwbttBIE = string("XuNNOUwLQSSvwMWrscuPzvEhGOMbIAKwFUhsqxmShrKOzLKlrtVmxhpASODJHhRipNSIaEybbKymDpvzjYbyQlErbkbWwCaXflcooJimqEkjNHBRcBEcLhFcrJTBQ");
    double bhqBquzlj = -1034064.272361295;

    if (RlFBLczw <= string("QqigWRkSeyEmYAGLRGKIZFmaOlWFeacwogdgLictfidAoRrmIXOohWZmwgikvBKCbaWzdNZDsdmnbiCxIQHbcMoTwtnzwVJBGEeOvQMizuAJJakIAAwlVjScPWLbpplOXySR")) {
        for (int PkKdu = 1102485304; PkKdu > 0; PkKdu--) {
            afZFezV = VAlLlHDpGpmd;
            FWkWL /= avJqOvfavQgqfoHB;
        }
    }

    if (HvLxLK < 916335.6574290913) {
        for (int vUXwSdHLbSl = 1766464910; vUXwSdHLbSl > 0; vUXwSdHLbSl--) {
            HvLxLK -= bhqBquzlj;
            tdHwbttBIE += tdHwbttBIE;
            RftZlBl = RftZlBl;
        }
    }

    if (RftZlBl < string("QqigWRkSeyEmYAGLRGKIZFmaOlWFeacwogdgLictfidAoRrmIXOohWZmwgikvBKCbaWzdNZDsdmnbiCxIQHbcMoTwtnzwVJBGEeOvQMizuAJJakIAAwlVjScPWLbpplOXySR")) {
        for (int ehqBNZBHc = 855833453; ehqBNZBHc > 0; ehqBNZBHc--) {
            continue;
        }
    }

    for (int eynfIjTWMt = 1474171971; eynfIjTWMt > 0; eynfIjTWMt--) {
        bhqBquzlj -= FWkWL;
    }

    for (int fnLFWJVURVhO = 499855869; fnLFWJVURVhO > 0; fnLFWJVURVhO--) {
        xYqKtoeIxppH -= xYqKtoeIxppH;
        bhqBquzlj -= bhqBquzlj;
    }

    for (int gCXhrZPMJIUG = 2104535842; gCXhrZPMJIUG > 0; gCXhrZPMJIUG--) {
        VAlLlHDpGpmd -= avJqOvfavQgqfoHB;
    }

    for (int JYhJzZFPsdig = 1284121513; JYhJzZFPsdig > 0; JYhJzZFPsdig--) {
        avJqOvfavQgqfoHB = VAlLlHDpGpmd;
    }

    return bhqBquzlj;
}

double bHAcuQFLMpWFCkcy::OWQjSoya(bool FaFgVIDlnAJACx)
{
    string XBLlEezIyrxObAr = string("DTnUWwezGDfnBEIcErGgDWhUUTDbsHNYabaaMeUhgEmXYQAjkQJxhajbkNqtGfatOPxVlzvvelvYkBQjdmECjyrfSkPbznrZpsTyRArrkxWSphSDIIUAsjIWzpTrKPjIsfYIpmRMscxlKwGRIWLdfLmpYXakucUqlKckPHiNsTAOsziDZnfxUzPqPFxbYrMUgajFrvUxKcvjZxNmwyGT");
    double gWVwVqsGIqJ = 669789.7384892801;
    bool hICokoToaXufQ = false;

    if (hICokoToaXufQ == true) {
        for (int VHUOMuMhoz = 21355344; VHUOMuMhoz > 0; VHUOMuMhoz--) {
            hICokoToaXufQ = FaFgVIDlnAJACx;
            XBLlEezIyrxObAr = XBLlEezIyrxObAr;
            FaFgVIDlnAJACx = ! FaFgVIDlnAJACx;
        }
    }

    for (int znLIYjIIiKPQYM = 370689879; znLIYjIIiKPQYM > 0; znLIYjIIiKPQYM--) {
        gWVwVqsGIqJ /= gWVwVqsGIqJ;
    }

    if (hICokoToaXufQ == false) {
        for (int GhQmY = 354786861; GhQmY > 0; GhQmY--) {
            FaFgVIDlnAJACx = hICokoToaXufQ;
            FaFgVIDlnAJACx = hICokoToaXufQ;
        }
    }

    if (FaFgVIDlnAJACx != false) {
        for (int UiHWnGOGMhtnPT = 1633207060; UiHWnGOGMhtnPT > 0; UiHWnGOGMhtnPT--) {
            gWVwVqsGIqJ = gWVwVqsGIqJ;
        }
    }

    return gWVwVqsGIqJ;
}

string bHAcuQFLMpWFCkcy::VwQoTIVpKYmymeo(string KHnBjctbGdzbS, bool yKMSoo, string Wtosxhhw, bool tshOVZ)
{
    int ZUtKAjNHhexyhP = 1486037593;
    bool fJGUFLAtFKSAwAWq = false;
    int QOnXQknUuOi = -93366531;

    for (int XKvjDxRZAYXLEhZI = 1814894394; XKvjDxRZAYXLEhZI > 0; XKvjDxRZAYXLEhZI--) {
        continue;
    }

    if (fJGUFLAtFKSAwAWq != false) {
        for (int fMiKlDK = 659877600; fMiKlDK > 0; fMiKlDK--) {
            continue;
        }
    }

    if (fJGUFLAtFKSAwAWq == false) {
        for (int kUEoqZKot = 181946389; kUEoqZKot > 0; kUEoqZKot--) {
            fJGUFLAtFKSAwAWq = ! fJGUFLAtFKSAwAWq;
            fJGUFLAtFKSAwAWq = yKMSoo;
            fJGUFLAtFKSAwAWq = ! yKMSoo;
            tshOVZ = ! yKMSoo;
            fJGUFLAtFKSAwAWq = yKMSoo;
        }
    }

    for (int NZVbyNWwOkR = 283482854; NZVbyNWwOkR > 0; NZVbyNWwOkR--) {
        tshOVZ = ! yKMSoo;
        tshOVZ = ! tshOVZ;
    }

    return Wtosxhhw;
}

bHAcuQFLMpWFCkcy::bHAcuQFLMpWFCkcy()
{
    this->wqGlRuHZNU(true);
    this->euTBssMztxXuiK(true, 897765.8287140428, true, 510731.80343620986);
    this->NySaoneVVMcsVmt(false, false, true);
    this->JFBgzx(13903.683712577293, true, 295016.04885954154);
    this->VHpaynnDlNiybYfT(-434916.5629188017);
    this->WgCDlhp(27888.903976429647, false, string("dYIAfIzIVUbVovFbZsTFHsbJPKKTKWGmTUWqEttNKjcFntVgImvEWffEIyOEBwKNcoHsOIvJewynRqKxUKRoAwzjCSHQDy"), string("kBjGlgetfPUZXihRhBxYfGaFYbHsOIAeFMoRMGiRyqtFURMoUcbCGjnZEvoZtKmijVqKdKMnYpJeGFRscmelzTVOCcOcakrswThLYBjeRZGDEEAsOQSnQBBzMehJDpxrHCvhmrdXOrqsuNFrcLQuATCJIRBMrqXfHQIqwYsSkKkueVXmaHTjIRYSFlleJeNOGddBFP"), 545234.166688768);
    this->vxySLPNbtShIBMC(false, -561517.9635437443);
    this->NXwxU(1139123363, string("QqigWRkSeyEmYAGLRGKIZFmaOlWFeacwogdgLictfidAoRrmIXOohWZmwgikvBKCbaWzdNZDsdmnbiCxIQHbcMoTwtnzwVJBGEeOvQMizuAJJakIAAwlVjScPWLbpplOXySR"), string("GddMnLDDIASFiMEWRksnFunYRj"));
    this->OWQjSoya(true);
    this->VwQoTIVpKYmymeo(string("WctQMCrCSQnNNZjCvLVWJCadFDTmUFOhRvZdEeYcCwyUjobkYbfZuGySbbrNUsAAeImDhxdUWZnfJyZSZsTSxReesefihopqxaKPKCgefEuM"), false, string("Hn"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qnhmEm
{
public:
    double zMvwI;
    double htaTYhXj;
    int eKXRspjIEZdoltfI;
    string NbVOsAGXu;

    qnhmEm();
    int uWgHVx(int ZUMimUX, int gtEELTkcSerM, bool YQVKFMnFa, string mpYjkAs);
    double xGBBzKgrxZnS(double kqdChhwsaPAv, string tocLNfxvmcDF, string SibUemaGr, bool lkJtzUqxAUl, int cKikEcV);
    bool XnROFtABlnimNQR(double tjSBpTpYqbmJ, bool liOKEiMau, int TqbLBlMeDxd, bool nXmMGnvut, bool fmXPRBJGp);
    void SLQBqA();
    string AKHTRczu(bool TjoCjOvBScKv, string NpXyVlOJg);
    string dyjVrLuClKjTEo(string fuLbKsZNioVy);
    double mRrKUqoRA(bool zVyvrJoRdDPbPwr, bool qCBXBb, bool DKVhTKQhRbT);
protected:
    double uNfxApCcc;
    bool VdDDMojKDAzB;
    string PWLgpJVWuxA;

    double zyhoFj(string PnYikqRM, bool zuAHzfzl);
    bool lYuuNwRMaQYv(string DQGqPDeNSHvfdbCZ, int OdWxiEIMFVTdm, bool qublIzqEPcBcY, string BhuDKee, double ZqtMbDJaj);
    bool zyaQWahnejYk(double DhfyefOf, bool ldOnCCaRjHumrupt);
    bool GsCOQ(string XeAXReiiZyzx, bool wjuuzEfbPSPeWc, string eAteFQdAN);
    double oiGiuzNNZos();
private:
    double DSdOn;
    double NoRLPegWbiYko;
    double CDulwBFVko;
    int EjcWKwBX;

    string LfqnmDBZZ(int rrMQMyconAgJKhv, double CFEZSDAAFTxKMqT);
};

int qnhmEm::uWgHVx(int ZUMimUX, int gtEELTkcSerM, bool YQVKFMnFa, string mpYjkAs)
{
    double WeqLFwIncZ = -364129.61102768854;
    bool OfKwckimIvKo = false;
    int aHDDukZyoihyg = -1259425721;

    if (gtEELTkcSerM != -1259425721) {
        for (int ADGUrMSOHzdp = 621276874; ADGUrMSOHzdp > 0; ADGUrMSOHzdp--) {
            continue;
        }
    }

    for (int dykXhrQMJqtD = 1718342682; dykXhrQMJqtD > 0; dykXhrQMJqtD--) {
        gtEELTkcSerM = gtEELTkcSerM;
    }

    for (int grSihfGgLLXXw = 946962053; grSihfGgLLXXw > 0; grSihfGgLLXXw--) {
        gtEELTkcSerM += aHDDukZyoihyg;
    }

    for (int lgVokwazTY = 1358727560; lgVokwazTY > 0; lgVokwazTY--) {
        aHDDukZyoihyg /= gtEELTkcSerM;
    }

    return aHDDukZyoihyg;
}

double qnhmEm::xGBBzKgrxZnS(double kqdChhwsaPAv, string tocLNfxvmcDF, string SibUemaGr, bool lkJtzUqxAUl, int cKikEcV)
{
    double KZrlXljUmKryoNKa = -181355.67136624953;
    double WKIjWafW = 293016.6576556321;

    for (int jzckrm = 2109819367; jzckrm > 0; jzckrm--) {
        kqdChhwsaPAv *= KZrlXljUmKryoNKa;
    }

    if (cKikEcV <= 923011993) {
        for (int eLPmjzX = 1742682815; eLPmjzX > 0; eLPmjzX--) {
            KZrlXljUmKryoNKa /= WKIjWafW;
        }
    }

    for (int aqZAKqmCXqizHHDc = 140504876; aqZAKqmCXqizHHDc > 0; aqZAKqmCXqizHHDc--) {
        SibUemaGr += SibUemaGr;
        kqdChhwsaPAv *= WKIjWafW;
    }

    return WKIjWafW;
}

bool qnhmEm::XnROFtABlnimNQR(double tjSBpTpYqbmJ, bool liOKEiMau, int TqbLBlMeDxd, bool nXmMGnvut, bool fmXPRBJGp)
{
    double CPwvfEFRpDl = 104385.73206388231;
    double IUDBWKPeyGYv = -659630.0432908573;
    string sqRKieqtuGRK = string("zQFKnEUCGuEeaGFhqpdSjGRMMDAhMFDNdMTnoqqgqcqVUfvbdiUFnIbDJwBvVtRilXTgRjSsuffxjdcczTYzAhKMWsoreVBcIjTWebEXucocpMudYxyK");
    string uPFqVuzaUKaNC = string("qWcFyyGGKlWLZaRDJeNjQChWwAoHzprvoWKtTCjcPiFqfmRHrBPxFqxSZpvrQlWltANRCrFVwVOZxvPAFdbAcuKLEBWiaognhxMXacrevwpCKoXIiIpdzYEbeXExINvOpkXsSKNDRYWWjZawmcqQjtQJINArOOJnzIZgWhdpEPQZkmv");
    double WBCLRsu = 74449.17015719324;
    bool SaxNbH = false;
    int IpsYxQ = 291234526;
    bool pxgrxu = false;
    string ocYtUleQyuDvke = string("sdVDAmijwdZrxBGeBlgvbARaMNjIVrbtacgVCqoEOcDAEeMxSKZfiOUAfWcXgDhS");
    string fqYIeTkNdsphY = string("KBkrkuQOBSKaKLpcLEBErxQxGdisYFpPOUkVsGFfBNZqtKSYtUxMjpAzEZqziYPbjRSVldTDCmqQgkDivhNNKBtcqqWdKPicpBgHWkmEoVtKsrbYhRXVNOUVmpqUaLbfRnLmAqzliLKKPAbYfHJ");

    for (int DlkmSBVPXSiiVe = 2086747694; DlkmSBVPXSiiVe > 0; DlkmSBVPXSiiVe--) {
        pxgrxu = liOKEiMau;
        uPFqVuzaUKaNC += ocYtUleQyuDvke;
        SaxNbH = ! fmXPRBJGp;
        sqRKieqtuGRK = ocYtUleQyuDvke;
        sqRKieqtuGRK += fqYIeTkNdsphY;
        fmXPRBJGp = SaxNbH;
        sqRKieqtuGRK += uPFqVuzaUKaNC;
    }

    if (fqYIeTkNdsphY < string("zQFKnEUCGuEeaGFhqpdSjGRMMDAhMFDNdMTnoqqgqcqVUfvbdiUFnIbDJwBvVtRilXTgRjSsuffxjdcczTYzAhKMWsoreVBcIjTWebEXucocpMudYxyK")) {
        for (int MFOobQEgMpcwZ = 584869555; MFOobQEgMpcwZ > 0; MFOobQEgMpcwZ--) {
            fqYIeTkNdsphY += sqRKieqtuGRK;
        }
    }

    for (int qmLUAG = 732806398; qmLUAG > 0; qmLUAG--) {
        tjSBpTpYqbmJ /= CPwvfEFRpDl;
        ocYtUleQyuDvke = fqYIeTkNdsphY;
        tjSBpTpYqbmJ *= tjSBpTpYqbmJ;
        ocYtUleQyuDvke += uPFqVuzaUKaNC;
    }

    return pxgrxu;
}

void qnhmEm::SLQBqA()
{
    bool aPExuPgN = false;
    bool qVEMsMZFG = true;
    int AWmYFHn = 183343891;

    for (int DttynBLScboayzix = 929507711; DttynBLScboayzix > 0; DttynBLScboayzix--) {
        aPExuPgN = ! aPExuPgN;
        qVEMsMZFG = ! qVEMsMZFG;
        qVEMsMZFG = aPExuPgN;
        qVEMsMZFG = ! aPExuPgN;
    }

    if (qVEMsMZFG == true) {
        for (int ASvwwLTxmjUJWiO = 2114933210; ASvwwLTxmjUJWiO > 0; ASvwwLTxmjUJWiO--) {
            aPExuPgN = qVEMsMZFG;
            AWmYFHn += AWmYFHn;
            qVEMsMZFG = ! qVEMsMZFG;
            qVEMsMZFG = aPExuPgN;
        }
    }
}

string qnhmEm::AKHTRczu(bool TjoCjOvBScKv, string NpXyVlOJg)
{
    double HPimALbm = -314848.27386140265;

    if (HPimALbm != -314848.27386140265) {
        for (int wClROsHuQtUX = 548173194; wClROsHuQtUX > 0; wClROsHuQtUX--) {
            continue;
        }
    }

    return NpXyVlOJg;
}

string qnhmEm::dyjVrLuClKjTEo(string fuLbKsZNioVy)
{
    double gYEMaE = -341203.8997719831;

    if (gYEMaE < -341203.8997719831) {
        for (int zDumaSpX = 272695701; zDumaSpX > 0; zDumaSpX--) {
            gYEMaE /= gYEMaE;
            fuLbKsZNioVy = fuLbKsZNioVy;
        }
    }

    if (fuLbKsZNioVy > string("FblZqXKZGQHuwpudkLalbZYPQNNMtHKsRSPUrUhzCdTTNkUgMZdAxXsyHWkcyfCdVRJkTjWDKXGJenbTNehGBGZKkYdoZmRAKWxGiCCUPuimbltMhtIyFFnyEkH")) {
        for (int zDOpoZzPOh = 359251452; zDOpoZzPOh > 0; zDOpoZzPOh--) {
            gYEMaE += gYEMaE;
            gYEMaE /= gYEMaE;
            fuLbKsZNioVy = fuLbKsZNioVy;
            fuLbKsZNioVy += fuLbKsZNioVy;
            gYEMaE += gYEMaE;
        }
    }

    return fuLbKsZNioVy;
}

double qnhmEm::mRrKUqoRA(bool zVyvrJoRdDPbPwr, bool qCBXBb, bool DKVhTKQhRbT)
{
    bool fdYEYiMNGxlo = true;
    int uebKyq = -1456230834;
    bool kFHAvCaLCRTjjtwp = true;

    if (fdYEYiMNGxlo == false) {
        for (int sZDsmdCwuE = 1347019586; sZDsmdCwuE > 0; sZDsmdCwuE--) {
            fdYEYiMNGxlo = zVyvrJoRdDPbPwr;
            DKVhTKQhRbT = DKVhTKQhRbT;
        }
    }

    if (zVyvrJoRdDPbPwr == true) {
        for (int WmxRB = 1090594019; WmxRB > 0; WmxRB--) {
            kFHAvCaLCRTjjtwp = fdYEYiMNGxlo;
        }
    }

    return 189029.1024612567;
}

double qnhmEm::zyhoFj(string PnYikqRM, bool zuAHzfzl)
{
    int NbheiBxNw = 1592831977;
    double fsVdyZzjCscA = 62746.39857168135;
    string dNFlautKpg = string("fOuyduhpEHUjXvpaziruUFZEJUKPBiiweaurPgfzrWHpwcULhCiyxTwWXTQBHamFdrpoXZXcXXJjowvtLckvJXVSSeTdZTXohNWkUqCDqktriArCQJxownHGpGFkywh");
    int uAfac = 1247849000;
    double ZFbnrCIhveEhcc = 777929.4804024618;

    if (uAfac >= 1592831977) {
        for (int WOfYNMoMziWGW = 1728457944; WOfYNMoMziWGW > 0; WOfYNMoMziWGW--) {
            continue;
        }
    }

    if (zuAHzfzl == true) {
        for (int TKglD = 572477610; TKglD > 0; TKglD--) {
            uAfac -= uAfac;
            dNFlautKpg = PnYikqRM;
            fsVdyZzjCscA = fsVdyZzjCscA;
        }
    }

    for (int QElLDeiGD = 879163607; QElLDeiGD > 0; QElLDeiGD--) {
        dNFlautKpg = PnYikqRM;
    }

    if (zuAHzfzl == true) {
        for (int rlScdrW = 1965540377; rlScdrW > 0; rlScdrW--) {
            fsVdyZzjCscA /= fsVdyZzjCscA;
        }
    }

    for (int HuANXBg = 1269526625; HuANXBg > 0; HuANXBg--) {
        uAfac = NbheiBxNw;
    }

    for (int mEisWBzVcYxql = 969772385; mEisWBzVcYxql > 0; mEisWBzVcYxql--) {
        NbheiBxNw = NbheiBxNw;
        uAfac += uAfac;
    }

    return ZFbnrCIhveEhcc;
}

bool qnhmEm::lYuuNwRMaQYv(string DQGqPDeNSHvfdbCZ, int OdWxiEIMFVTdm, bool qublIzqEPcBcY, string BhuDKee, double ZqtMbDJaj)
{
    int ctKBxElVkyGQbcK = -345195859;
    int rCubxrOuloFy = 816532761;
    double BqhKOLAajh = -180070.1576945948;
    int WzojmguzRH = -1820448632;
    string bAXpnFOHGtOYKx = string("DYzmJehIKxmyTTkWnJsqfGoNwLyGAINOkymlFGrMsPwxlMUtCVdXGxWKYeErwSIsvQbuYXxOyCnKmpxrouhQibQHVWdYEPdDyuuahcgtkiqHlfnQpHNbUA");
    string pCRGtDJZSAq = string("khHlfwFXRlstueFBOcTVYKmcwAIceCtPbJTsnlqJOSQNQMBEqrRbgeDbQWQkfguwgnliQmOZrTlXpoWFFIiFrqGGdeOikesKxPEoCXJwuMIrNktAUMQYQszDNWIUpwTahwwwFyhPMTQUmWwNrVIcBkdYkLicTpyTdSEgLXmcwXZ");
    int qwzzCbejzJoefu = -918297566;

    for (int WyCRh = 2003105762; WyCRh > 0; WyCRh--) {
        qwzzCbejzJoefu /= ctKBxElVkyGQbcK;
        WzojmguzRH = qwzzCbejzJoefu;
    }

    for (int xvjmEbWNFzUgzcJA = 1765415485; xvjmEbWNFzUgzcJA > 0; xvjmEbWNFzUgzcJA--) {
        continue;
    }

    if (pCRGtDJZSAq > string("khHlfwFXRlstueFBOcTVYKmcwAIceCtPbJTsnlqJOSQNQMBEqrRbgeDbQWQkfguwgnliQmOZrTlXpoWFFIiFrqGGdeOikesKxPEoCXJwuMIrNktAUMQYQszDNWIUpwTahwwwFyhPMTQUmWwNrVIcBkdYkLicTpyTdSEgLXmcwXZ")) {
        for (int SmAQpCJugHoVp = 135354593; SmAQpCJugHoVp > 0; SmAQpCJugHoVp--) {
            WzojmguzRH -= WzojmguzRH;
        }
    }

    return qublIzqEPcBcY;
}

bool qnhmEm::zyaQWahnejYk(double DhfyefOf, bool ldOnCCaRjHumrupt)
{
    string cKJgNG = string("WTNQrmtlwsEslEVWxVCOVgtGmARCXUuLTqlWPpYdjjFJjnLkYBLEXvZWnFvzacIIHTYvJmcqFplGiCAlYIliPolEoKC");
    string LHbVwqQaS = string("KLvKPbbcxuJNbksrbHCMWtkrJciEeQQbDJiMuSWqvUNglDkFCUcKncwWltvkCGUIrH");
    bool fQtzKpHfhy = false;
    string vbnMm = string("ddCBubftWcJUUuaayiEMOkJahFYJYcxpKKeiIqwCsbrPddqnPPvSMYbvURmdNZKLgATVlvNeTkmdRWjsjgxxSaTCFbUdrgiqsOwTzqMBgdJoKsXpIhzIEYwSI");
    double liZhsXaLFCJFbaSu = -51839.484311442626;
    string CqKMTkPFLfQ = string("odEsHzhwfMZCECflurPJLRUywIByWqTpZPQOeKExGIwHkyxmCLWONnbWPipvIZbeiw");

    if (cKJgNG > string("WTNQrmtlwsEslEVWxVCOVgtGmARCXUuLTqlWPpYdjjFJjnLkYBLEXvZWnFvzacIIHTYvJmcqFplGiCAlYIliPolEoKC")) {
        for (int StVNDAYhfVobxmH = 1122861986; StVNDAYhfVobxmH > 0; StVNDAYhfVobxmH--) {
            continue;
        }
    }

    if (fQtzKpHfhy != false) {
        for (int doUvDdSIV = 1264923682; doUvDdSIV > 0; doUvDdSIV--) {
            vbnMm = CqKMTkPFLfQ;
            LHbVwqQaS = LHbVwqQaS;
        }
    }

    for (int YCstjcBa = 383242248; YCstjcBa > 0; YCstjcBa--) {
        continue;
    }

    for (int WaBTm = 229429296; WaBTm > 0; WaBTm--) {
        continue;
    }

    for (int EVclARov = 2019389235; EVclARov > 0; EVclARov--) {
        continue;
    }

    return fQtzKpHfhy;
}

bool qnhmEm::GsCOQ(string XeAXReiiZyzx, bool wjuuzEfbPSPeWc, string eAteFQdAN)
{
    double YYpBlUjOUVLnD = 429095.5961653129;
    double IgxOri = -835690.6317230865;
    int sdJhSWFuThnDPl = 716021111;
    string nNNXllxpNHf = string("yLIwNqvGEFKMhmIPoZKiVjNVLRPuFMNMXFRyRFedTIvfUlwrXSivpFLzUomOWPYrRfHbtwQsrnPnRkGlLLulwqFdAnSbDgDKVZonFVNspmORxLqXjvAGzWuDOtQitJTOpCsWfdfLZCqEfWPdrANsRMUSHORJlAPlMdtluGQGIjmedyTsHDYZIukNGuyrFNmHvJurduVXygrcKYkmFrYzTxkwLnfobdgMxEUyHqdrbLZCXnEllvbHlKtOpqcXJ");

    for (int sqHXB = 1386005508; sqHXB > 0; sqHXB--) {
        continue;
    }

    return wjuuzEfbPSPeWc;
}

double qnhmEm::oiGiuzNNZos()
{
    int GxcReM = 932946156;
    int jULFQKjQF = -695044582;
    double dQiUscVEkjfqVV = 1045775.9865290658;

    for (int gIcKpbE = 1510118252; gIcKpbE > 0; gIcKpbE--) {
        GxcReM /= GxcReM;
        jULFQKjQF /= GxcReM;
    }

    if (dQiUscVEkjfqVV > 1045775.9865290658) {
        for (int QJxRHVaZPLjsQh = 1749974484; QJxRHVaZPLjsQh > 0; QJxRHVaZPLjsQh--) {
            jULFQKjQF = jULFQKjQF;
            GxcReM += GxcReM;
        }
    }

    if (jULFQKjQF >= -695044582) {
        for (int gdlKClKHXdA = 825891449; gdlKClKHXdA > 0; gdlKClKHXdA--) {
            dQiUscVEkjfqVV += dQiUscVEkjfqVV;
            jULFQKjQF += GxcReM;
            dQiUscVEkjfqVV /= dQiUscVEkjfqVV;
        }
    }

    for (int IKWnHHPW = 359389720; IKWnHHPW > 0; IKWnHHPW--) {
        dQiUscVEkjfqVV /= dQiUscVEkjfqVV;
        jULFQKjQF *= jULFQKjQF;
        jULFQKjQF *= jULFQKjQF;
        GxcReM = GxcReM;
    }

    return dQiUscVEkjfqVV;
}

string qnhmEm::LfqnmDBZZ(int rrMQMyconAgJKhv, double CFEZSDAAFTxKMqT)
{
    double hyfsJYy = 1024584.8840280023;
    string PtfRvbJ = string("gYNgOtqIweGMWYaCYIQjXsEHMFTSbluIyIQszIXyYJgPIFzIzIZfEdgoojHFWZMRZqtORwkfDEhstPWwZAiXFHvwTJVeklrjBmwszSaODwxZfkaSyEtAjmgIsEnTKQPwHinVueY");
    bool FVoKjSbhFedM = false;
    bool PSRaTEuu = false;
    double afjOrPsVCiJ = 655846.9871220125;
    double SyyuytAYDd = -246373.34456054567;
    bool RPSBqQYw = false;

    if (SyyuytAYDd == 655846.9871220125) {
        for (int aWFBy = 1622219655; aWFBy > 0; aWFBy--) {
            PSRaTEuu = ! RPSBqQYw;
        }
    }

    for (int ZvCxXUhzgFBsQQm = 59043339; ZvCxXUhzgFBsQQm > 0; ZvCxXUhzgFBsQQm--) {
        PSRaTEuu = FVoKjSbhFedM;
    }

    for (int EyRXU = 1454357179; EyRXU > 0; EyRXU--) {
        RPSBqQYw = PSRaTEuu;
        PtfRvbJ += PtfRvbJ;
    }

    for (int mxHfWspcnj = 820577330; mxHfWspcnj > 0; mxHfWspcnj--) {
        RPSBqQYw = RPSBqQYw;
        hyfsJYy -= CFEZSDAAFTxKMqT;
    }

    for (int KdoiYdawagEot = 1599207455; KdoiYdawagEot > 0; KdoiYdawagEot--) {
        afjOrPsVCiJ = CFEZSDAAFTxKMqT;
        CFEZSDAAFTxKMqT += afjOrPsVCiJ;
    }

    for (int znahlyg = 2105251247; znahlyg > 0; znahlyg--) {
        FVoKjSbhFedM = FVoKjSbhFedM;
        PSRaTEuu = PSRaTEuu;
    }

    return PtfRvbJ;
}

qnhmEm::qnhmEm()
{
    this->uWgHVx(-306873315, -368657614, false, string("NXdSGZFxrBloVOypgTQDKwpfszZFtIRVFtUbXDRmhBGzDhseqKkvFzCHJezCndDBRApjMoxzMTezuvKQRiCyzaYnvbIFAEmQDAonaTAzCcZLBnJBesKmREDsEkKDOXtfVjjWjnLqbgC"));
    this->xGBBzKgrxZnS(131447.16262805456, string("JTTtpRiByMSKKNxQarWvBwmflyNOrOnSDuGWciVHXYJX"), string("VvcWNSfIEGfXGAkQPhoidQMaljLnPCGnOmeQHQZlidcgQRdfxcPxLwDWKPdIMpDKZfEnBIzeUCYoLswonniJsHnuqoUJPaSHmSjKyq"), false, 923011993);
    this->XnROFtABlnimNQR(156192.84318844386, false, 419290203, true, false);
    this->SLQBqA();
    this->AKHTRczu(false, string("yiAImSYfAtHEWOKzTAtPPqVSEgsTsqwIQPYSiMKGIwHIFwcJhnMwbzdXIOUYfRbMUcpGASGKQSwWsIQVigaxbSddyetZupLhyhKwqeUDiPNOqVOzaJmHQWRTDuorxXZLINpGycjYXZ"));
    this->dyjVrLuClKjTEo(string("FblZqXKZGQHuwpudkLalbZYPQNNMtHKsRSPUrUhzCdTTNkUgMZdAxXsyHWkcyfCdVRJkTjWDKXGJenbTNehGBGZKkYdoZmRAKWxGiCCUPuimbltMhtIyFFnyEkH"));
    this->mRrKUqoRA(true, true, false);
    this->zyhoFj(string("YFMVlmEbLaWmchBeCtUldCMOflZpckPgIpbbqgrsAnYIpzpuxAaxvkvNXiXvzbCBVMpIvBToeDwaSXTlheJdrapkgtsXdIDeosEUESWxdVmcoNmblwzW"), true);
    this->lYuuNwRMaQYv(string("bbqwegHsYgrAyzBECaKRfMeHETLsYRHAHEtIOOdcdZaaBGFKNSjyUIvV"), 1645010698, true, string("GCwTOpdDTsqLtqdPDsSGwRIJakhYvtJjaYyfPqwwfCwbQlUHRVoyj"), 630171.3420866722);
    this->zyaQWahnejYk(907219.0791012556, false);
    this->GsCOQ(string("sRwPtWwvBBlPQpXwafzmsgMyCFpnbjHHkLLSYdPLaPelwMVUwgtHrQYRBKSVoVnyEQPoXYVyuYMXOuCEbWhaIYdsPxaDMDzGDjBSmjbdkbJYWldOYFjjbaSWWBUwUUBFyzaFhfQhPfhDqzWKSFvFcfqHDeGMInChtCSJRExTTfTVWtyhlxeyoCSdSwBYZOGqNUnQffOymwLqbnGMeaGTxqFJwzfoLgpPtVFzN"), true, string("ymlQSSUupSMEvjgHGGpBKpgQXZamGLUoHIRRsdvApZayactxbTrODPKUpRkyznfthVPLNgAjdGLDOcthSmvwT"));
    this->oiGiuzNNZos();
    this->LfqnmDBZZ(-1043976274, -272781.10278652585);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zNybI
{
public:
    bool YodPYxxzp;
    string nWszCRydKkE;

    zNybI();
    string DaaMgYcNfJeJXV(bool fXQhHytuN, string TskTlcbMiOS);
    double ZySrDoDLmFsmh(string ALKemOw, double EaqEmrUVHcW);
protected:
    int kaPuCXZjrlAQJeAF;
    int GPKnZXNz;

    double LxZCXAPUvIhGIO(bool faKlqxB, bool ejCEJVtbp, int qqroiYDWeGpBPig);
    bool KZFul(string NtARtxvC, bool GGERoQNqp, double VNwetdNl, int ochCK);
    int osUhdnDAIpvtoWp(string XPrwgLsIXf, double IjfXJp, bool veKRnJSTHfxsrmL);
    void PbUVlxQPMRk(double alqqKivozxciPlK, int ZUliwMvdJ, int ZmGZnGH);
    bool DIRkozLW(string bsuMlPjFZlTQV);
    double zQOfKMeNOniPAYmX(double zaEMaqD, bool rsmXhGf);
private:
    int scqLUsawoPTG;
    bool MTccpKPxRA;
    string jLvELLGX;

    double lfAMITvlQYVoOgMO(double HprGIBEBzrC);
    void eHoUQdLhKjMpuMg();
};

string zNybI::DaaMgYcNfJeJXV(bool fXQhHytuN, string TskTlcbMiOS)
{
    bool GIsGUF = false;
    double UwVktMz = 112840.77924240465;
    bool LyXYDqZKW = false;
    double HgSKWt = 231573.71251372717;
    bool JnsNHuccVd = false;
    bool OGbUFqNcSBzrU = false;
    bool KHcGSdtbuy = false;
    double nEetaiOBBPuQKU = -423317.2475577212;
    string MQEIDpCt = string("pqffbwlNMKMBPZndAKkccirdcmgleTKUuoWEvWPvMGTPcUMFbwYtXfGGYYRxaWOKtuwBQaKQRqXXHDjJxsxlRfMCAwuPfCmVbruDXLpBlOnZnRijBnstNIExOjWFuKvXfJTHFYyAdAehsIgRjtouLoTyKzYuedayClnNexcDWHzUSmhtYJXRGabTGFveMFoejuLELzyWVQtEhSnMIRiPcQHdeSBehXgfCkeWdXtAypctzpUha");
    string HmrunspMbmzDt = string("HFGgHvQkVhPnlAinaDhLhBOUMcjrkcuRlwNIRHFffctzQDSnqnpuYGrHdzhSaXkYouZWrlhJJWpWVuhqPVhiqFC");

    for (int ozRcEWomXJ = 1393592457; ozRcEWomXJ > 0; ozRcEWomXJ--) {
        GIsGUF = ! OGbUFqNcSBzrU;
        HmrunspMbmzDt += MQEIDpCt;
    }

    for (int oDUBzcQrSVFVeY = 1601765889; oDUBzcQrSVFVeY > 0; oDUBzcQrSVFVeY--) {
        LyXYDqZKW = ! fXQhHytuN;
        JnsNHuccVd = ! KHcGSdtbuy;
    }

    if (HmrunspMbmzDt <= string("pqffbwlNMKMBPZndAKkccirdcmgleTKUuoWEvWPvMGTPcUMFbwYtXfGGYYRxaWOKtuwBQaKQRqXXHDjJxsxlRfMCAwuPfCmVbruDXLpBlOnZnRijBnstNIExOjWFuKvXfJTHFYyAdAehsIgRjtouLoTyKzYuedayClnNexcDWHzUSmhtYJXRGabTGFveMFoejuLELzyWVQtEhSnMIRiPcQHdeSBehXgfCkeWdXtAypctzpUha")) {
        for (int NNSDXIFXfgvpnjQ = 856928398; NNSDXIFXfgvpnjQ > 0; NNSDXIFXfgvpnjQ--) {
            fXQhHytuN = ! fXQhHytuN;
            GIsGUF = ! OGbUFqNcSBzrU;
            OGbUFqNcSBzrU = ! fXQhHytuN;
            fXQhHytuN = ! fXQhHytuN;
            HmrunspMbmzDt = HmrunspMbmzDt;
            TskTlcbMiOS += HmrunspMbmzDt;
        }
    }

    return HmrunspMbmzDt;
}

double zNybI::ZySrDoDLmFsmh(string ALKemOw, double EaqEmrUVHcW)
{
    string ROFGVriblgxqiRa = string("JzYzvpWIyusKOakgzmgvorxmqPaNnEmzoBe");
    bool zMGvAD = true;
    int vSbgAhHjrImvjUQG = 744019048;
    bool bvMOEBSGnFwnKzhx = true;
    bool oCkHLsyfu = false;
    string YzRewsdxSWLLv = string("JZhkwQmfhjsdILAhkidjqgJPTMJsNCpCaEIcwMMsbXpdukIncGnhmnLrVctltJJJvLKmWPPCjdzrdaNZedYkdcFqtOzuBTcuPMzAnVisQKMojCPSpgNZYzStLiBNBDWfHdiQzzUJiCCKdwcKbMBYQYZdEiRRWJBvesYcxsuRtpWpycOmHTvlWOZVMHcidrIShWrvGIFUGDbZruPWtCtJTQAE");
    int KHGaz = 150312729;
    string FmdQReEFB = string("LNHxiRCxdBrpfRwKayNuBckHYNbAgXRMCKmCoGaeBRjupdYgMDmpnxtszgkaNcBBaZjVOPnrgNhcNfCxEOkTpVdLvXjkIdePsHGxHTLxPFntWOqqSxBpaNqNvgr");
    bool ucUKlTbYudUftG = true;
    double hBfMjEOZjT = -803534.33872104;

    for (int pIxugryWqKMmWQHu = 133624252; pIxugryWqKMmWQHu > 0; pIxugryWqKMmWQHu--) {
        continue;
    }

    for (int WcdBWWNYTdpbf = 295361686; WcdBWWNYTdpbf > 0; WcdBWWNYTdpbf--) {
        continue;
    }

    for (int umjqjJFe = 2097253860; umjqjJFe > 0; umjqjJFe--) {
        continue;
    }

    if (ucUKlTbYudUftG == false) {
        for (int tfpPPsvReMxRAhq = 1869360911; tfpPPsvReMxRAhq > 0; tfpPPsvReMxRAhq--) {
            KHGaz -= vSbgAhHjrImvjUQG;
            FmdQReEFB = ROFGVriblgxqiRa;
        }
    }

    for (int JLaKhMggxuiRZr = 1324742728; JLaKhMggxuiRZr > 0; JLaKhMggxuiRZr--) {
        bvMOEBSGnFwnKzhx = ! zMGvAD;
    }

    for (int FkDhDlPoOlGyl = 143297792; FkDhDlPoOlGyl > 0; FkDhDlPoOlGyl--) {
        oCkHLsyfu = bvMOEBSGnFwnKzhx;
    }

    if (YzRewsdxSWLLv == string("JzYzvpWIyusKOakgzmgvorxmqPaNnEmzoBe")) {
        for (int IHiTAIPJvN = 1717957007; IHiTAIPJvN > 0; IHiTAIPJvN--) {
            ROFGVriblgxqiRa += FmdQReEFB;
            KHGaz = KHGaz;
        }
    }

    for (int mHyozpCuIVgwiCte = 311693715; mHyozpCuIVgwiCte > 0; mHyozpCuIVgwiCte--) {
        zMGvAD = zMGvAD;
        FmdQReEFB += ALKemOw;
    }

    return hBfMjEOZjT;
}

double zNybI::LxZCXAPUvIhGIO(bool faKlqxB, bool ejCEJVtbp, int qqroiYDWeGpBPig)
{
    double RctAnshUfhPM = -52597.155229006974;
    int cpfyQmYJRx = -2137384506;
    int OUjAvxJYJGcEo = 489258880;
    string tZjXsaatSV = string("qlfntxsEkuEnbOruMFCkYeuhvlmsUhXzXFZHYJyhzRqXJbnjjGJmfzHeIFMgrsShEkIywMYApkyDugLwRZomrIisHhbZBlrroqixZksEmlhsNfLsjeUEsVU");

    if (faKlqxB != true) {
        for (int mbNvAntNeatc = 444858209; mbNvAntNeatc > 0; mbNvAntNeatc--) {
            qqroiYDWeGpBPig = cpfyQmYJRx;
            cpfyQmYJRx += qqroiYDWeGpBPig;
        }
    }

    for (int iwWhkumKxADQ = 1567973155; iwWhkumKxADQ > 0; iwWhkumKxADQ--) {
        cpfyQmYJRx -= cpfyQmYJRx;
    }

    return RctAnshUfhPM;
}

bool zNybI::KZFul(string NtARtxvC, bool GGERoQNqp, double VNwetdNl, int ochCK)
{
    double oaBKn = -110993.87420541389;
    string IsHdmZwBb = string("FiYbzSwvHnwOXjjvXpGWrDdNCOFZNmqagHzzsUckCmNpFlhfbYYUq");
    bool Uwybg = true;
    string iHrwXeLamyuo = string("jQRtcCCxEJpspVViIRHsVhJPOlnUbkCdUttayEuaFwYEvPGrksOvxTjhUMewvtvyRVQyYUIINkjHAwdjhkQOKtgnbltxKvujVVhgFbcZanSdOXWEJUsuVZoRzxBhopixcedoFblZlHmOeuuLWdOcNTlOlqrDIBxfcduDeQid");
    int FvWdgJM = 1137872045;
    string hXNFQfbqT = string("nMYuHHrlSjehhEjZwhgRLlURLVWopGYoWG");
    string jRFKELackGSyQ = string("RfWkxswdKciDIgVfayJLXKCGOftfONFwHOjFNsYJZieNDcpodNlyVkqFRlhXXLIvTzVLGXJYhMeLimBHfYiPSHKNQGQSYsKgRCzEEpjLbXhdQLJGkCRebzvpKrUjmClPFAkojeBxOltPhTCSaBcKWmcwlEZKFFOFqeMyfwrGulcOBCNDfDdipDriISrLOrOLzjikDjbCjfWeJEOlScsXPgqGIgSBGovFGywIlFCCqba");
    int nxQOabJLiLD = -494260206;
    int euHePF = 511451931;

    for (int ezPgsWuku = 1698950621; ezPgsWuku > 0; ezPgsWuku--) {
        continue;
    }

    return Uwybg;
}

int zNybI::osUhdnDAIpvtoWp(string XPrwgLsIXf, double IjfXJp, bool veKRnJSTHfxsrmL)
{
    bool LCdAmLKAVTHQZa = true;
    double lzQFwsEWVJu = -937214.1772832323;
    string NGGslDsImgsmUItz = string("opiCkLuhFWHNkcYWzZPJllMhkUmbUsyWUZhUobZSyLSVkMvIDXqpBLFnezfHBRMDBCQOXJMFJNqfHwZbAtVZdQamubMlGAOZTPIzYXgUxLvHuhIdqDtPtBAGmBxtDRvmLhouMCZTKctptEwwcKetvFovLhZPywQvwMxLLyFqPIsfJcviToGDhIKUTVSiMArzYhXkmrkgYvHHiPLBOnkKYVxMysLjTwfBFkpAR");
    string pDqTYvGWjAhMx = string("MBDGjikfDpWEpIuRbPuxjVOgWVDzUIrTHQkwQvTbBsittakZSuYrOmNYCxbxEmgycYowanoupUtWHJmoFMttlMMjCEbdOnlprGB");
    double RiflzNrucPLjlN = 989028.6663994765;
    double AOBUio = 827341.9693327468;

    for (int VIdzaYNmNkUcJyBg = 2059144518; VIdzaYNmNkUcJyBg > 0; VIdzaYNmNkUcJyBg--) {
        LCdAmLKAVTHQZa = ! LCdAmLKAVTHQZa;
        veKRnJSTHfxsrmL = ! veKRnJSTHfxsrmL;
        RiflzNrucPLjlN -= IjfXJp;
        AOBUio += AOBUio;
        LCdAmLKAVTHQZa = veKRnJSTHfxsrmL;
    }

    for (int IAaxWQT = 1088593781; IAaxWQT > 0; IAaxWQT--) {
        NGGslDsImgsmUItz += XPrwgLsIXf;
    }

    if (veKRnJSTHfxsrmL == true) {
        for (int OnWvtC = 1940585445; OnWvtC > 0; OnWvtC--) {
            continue;
        }
    }

    if (AOBUio >= 827341.9693327468) {
        for (int WvUPtqwbXgT = 786961724; WvUPtqwbXgT > 0; WvUPtqwbXgT--) {
            pDqTYvGWjAhMx = pDqTYvGWjAhMx;
            AOBUio = RiflzNrucPLjlN;
        }
    }

    for (int emAXHEJqrlsRP = 318532639; emAXHEJqrlsRP > 0; emAXHEJqrlsRP--) {
        IjfXJp /= RiflzNrucPLjlN;
    }

    return -1726462800;
}

void zNybI::PbUVlxQPMRk(double alqqKivozxciPlK, int ZUliwMvdJ, int ZmGZnGH)
{
    bool QbaKsyMPL = false;
    double aIrFE = -423607.90759345854;
    string iZLBFSSQo = string("gQpvQFlSsiDAiHQvNeHwgVPrPQsyCJKfsmUfsltcRKypQAUzNfpzbnTZXMZBvnJuUXafNZRuriNJBqGTgrYRwLTDouyMTLhKvzAdRPdaTFEmGiqDsqzhfMKvqlttGwMScJBAXrmRNCLTnWVKRicEtMezIozOXMCYdFJsYwZTDhWwMmExLIacqCIKvMQKEXEKOgthXlsCw");
    string PLbOjpyMKjT = string("AGwigOhXFrOxzgMvTJDPBpOZxUMHjojBpMldBsOgvaUViyitOOjOnKtjfIhGKiWRUfjKQMJKPqOxCTgsZIQiidsRwOmGWVKTwAEqOERMccxFquNyFKWYSLyiscuiZRxFmxyWmMBBpgijfTiqNyCFwLJkuMoFuujavCWgBWxUpOaSyRtHgCaznAkifklyBRHYZcgGamBLwDzunhAcFaiccSKnJvPKApmqeOWUfvqXrywdMEQcIApYFyvHCv");
    int WpuwNV = 511268037;
    string GObqqVJEfAUGVqp = string("KVuGgILbCcegySIaLUdlwfXupwlmlARVuKXZUxjfZlVUScvsBftdBbEAGYEIifsYabYJsBFJYNzwEykwprEdqMyEIZasOG");
    string FPVoeRbQnu = string("LjJTTyiTYHDYNDJTHYzaOqcqUwBkqOIXcUJyiJxWwkinskyCCwKwTtSdWVnWWKSuFnQXQZLONFVoUCtxVPVggDJyGzYVSuVeSzoWPXfEIaKnXmQfjJxzYXxXCVyBHaayhQKebgiyfJRfoCFzvEQuwZBpVdYsUnnomoweiDTQmqxjzYHECxxxsQJiMJOIAYSURREt");
    bool embnVbfWn = false;
    string dwqXIqImi = string("PheJDwefeCPoawqtEPJsayooKullBEexKoeZxXZHmaJeRzYcvTKZcLmwENxpdkRmKwaoPgSxHUkMxIAQEcgDUjXKEzjtdfvyZXTQDGASMFhfYqRkObZtnKAdiusTnAWOkUCTKco");
    string BfpQPg = string("pUjEBBRcaDwTHeYnzMgvKHQSwaFSoztXVSziYQftQJqCIVzyLdqOdZhLmHbtiUlYAQgudXoQKdipxYhruyJfDhkGifCOgXXEtUXqRUzTHedyfGWDLLDPgyMGDLMlVnyiiNawBDPChSHjMUhRjrKOeCLgpbSMfwhtdtjWMGbjiKPTHzqin");

    for (int IJybbWesIADHKPB = 957106560; IJybbWesIADHKPB > 0; IJybbWesIADHKPB--) {
        dwqXIqImi += PLbOjpyMKjT;
        embnVbfWn = ! QbaKsyMPL;
        BfpQPg = PLbOjpyMKjT;
        GObqqVJEfAUGVqp = iZLBFSSQo;
        PLbOjpyMKjT += dwqXIqImi;
        GObqqVJEfAUGVqp += BfpQPg;
        dwqXIqImi = iZLBFSSQo;
    }

    for (int gRkJmqTqmwUN = 1789934249; gRkJmqTqmwUN > 0; gRkJmqTqmwUN--) {
        WpuwNV /= WpuwNV;
    }

    for (int JCxDRbxOHw = 1105045606; JCxDRbxOHw > 0; JCxDRbxOHw--) {
        continue;
    }
}

bool zNybI::DIRkozLW(string bsuMlPjFZlTQV)
{
    int NAcsp = -1063327044;
    string sGkrEVrxtxjzVQ = string("ywbsSdrSKbZdsqGnFwgcQQagIzjdMfkygxtXCQIXwwvhahDkEiWOOjDGaqWjrARQKeRRoDhdtMjNWhGGoNLlPKdvmwrkNzSwuqVkPThgQfzDeohFGMdbxmOLKyddgwjdSnVxaGMxtUVOVPr");
    double DOcDcKIUjYLOU = -155288.4466729088;
    double XAsZNZctvj = 441686.4113311659;
    int nGKkRjCbNVGm = 363281937;
    double kmthbsvmAZvWbDD = -733196.2148071291;
    int MbApijQVShaYg = 1164273407;
    double qBlPUvpXLVv = -1047142.6541989655;

    for (int KbsWIFTuKt = 1551278439; KbsWIFTuKt > 0; KbsWIFTuKt--) {
        NAcsp = NAcsp;
        DOcDcKIUjYLOU += XAsZNZctvj;
        NAcsp *= NAcsp;
    }

    for (int RQHiNjOWz = 913155456; RQHiNjOWz > 0; RQHiNjOWz--) {
        kmthbsvmAZvWbDD /= qBlPUvpXLVv;
        XAsZNZctvj *= qBlPUvpXLVv;
        sGkrEVrxtxjzVQ = bsuMlPjFZlTQV;
        qBlPUvpXLVv *= XAsZNZctvj;
    }

    return true;
}

double zNybI::zQOfKMeNOniPAYmX(double zaEMaqD, bool rsmXhGf)
{
    bool cYLOoOju = true;
    double fgVpjgC = -806986.9481768743;
    bool dqOFmXK = true;
    int NZbWSBGjTFYrsQPw = -2133114988;
    bool zRPrnVvuiV = false;
    string jRljggCPBDuSwYVB = string("DrPnXyPKRnKtX");
    string DXaconceG = string("CombkNBglGUbzexeWAGBXRrbNcEBPGkabkDVvQiyMLvXYeFddOKaoJHaQmVwXNgSujCnOodGmeFFKUtygeNBiHMnGDQPNNpQJZlwzJetEehIUSRcxjNwociJNDAapDhjeeukNWltezlhXfcigJFGfkA");
    bool SxNSmpIlgYoc = false;

    if (fgVpjgC > -806986.9481768743) {
        for (int azrsn = 824620925; azrsn > 0; azrsn--) {
            jRljggCPBDuSwYVB += DXaconceG;
            zaEMaqD -= zaEMaqD;
            SxNSmpIlgYoc = dqOFmXK;
        }
    }

    if (zaEMaqD <= -806986.9481768743) {
        for (int iGkNkEDwOTKmWPaB = 1254362390; iGkNkEDwOTKmWPaB > 0; iGkNkEDwOTKmWPaB--) {
            jRljggCPBDuSwYVB = jRljggCPBDuSwYVB;
            dqOFmXK = zRPrnVvuiV;
        }
    }

    for (int cFPzaNUINYKejV = 1270204472; cFPzaNUINYKejV > 0; cFPzaNUINYKejV--) {
        dqOFmXK = ! rsmXhGf;
        zRPrnVvuiV = ! dqOFmXK;
    }

    if (SxNSmpIlgYoc == false) {
        for (int bsESdwtkyrMdPAC = 696198932; bsESdwtkyrMdPAC > 0; bsESdwtkyrMdPAC--) {
            continue;
        }
    }

    return fgVpjgC;
}

double zNybI::lfAMITvlQYVoOgMO(double HprGIBEBzrC)
{
    bool DJVvEc = true;
    bool cYFvddusJNLggua = false;
    int WLBZVn = 1005193165;
    string ZRMgVba = string("ZgucHqIzsPALsAJLFHIjqUDThzsIUXWinnQZPBRZZxOMeKwUFYmKZTrWpXCZWduRlSPtDfeBfwhpJeuIggsUkittXqHqYMkQbpXfPUseLgolQSbojvjEUoRwgLGyzcchXEreAfkdaXNIhKYCnisGWYqoscCqPojvvnoJSClvxzSkDfUSImXsswIQIkvvNcStLrSySGXawbUk");
    bool rIMJnJTOnGQI = false;
    bool tIwSmHGu = false;
    int auRIDcbzj = 1265724636;

    for (int ebpeWkifD = 1092729411; ebpeWkifD > 0; ebpeWkifD--) {
        rIMJnJTOnGQI = ! DJVvEc;
    }

    for (int LGCkWZ = 1004308218; LGCkWZ > 0; LGCkWZ--) {
        WLBZVn /= WLBZVn;
        tIwSmHGu = ! rIMJnJTOnGQI;
    }

    for (int paapSLipnlV = 1265464966; paapSLipnlV > 0; paapSLipnlV--) {
        continue;
    }

    if (rIMJnJTOnGQI == false) {
        for (int AQwgKkv = 1996580167; AQwgKkv > 0; AQwgKkv--) {
            auRIDcbzj *= auRIDcbzj;
        }
    }

    return HprGIBEBzrC;
}

void zNybI::eHoUQdLhKjMpuMg()
{
    string DyuPhSfJiSECMRU = string("JKUggTiwjcgPUELXdcbunjALONHDzkqpMQKcdXEGYfFnEIb");
    string humBTbPA = string("LMEsAVQysDBvpFYZaaEbnJmqvlevpHxifZUheDfOIpgZMcbWwAxufIyLCqtbDZYFSnqxOFeoxyNvNaVVUfWloqddcQiHqAkobRftQyimuxtfdVZWrTpjMBWWBauSDoDJACAKcSQROXcCepvQhWqCVmwFstfAitPHKyIkuiLbhlVbSLEWkqQmhdcmmigNOCSCBrBuHRyftUyAepsEAwfEiBxycZNkNGYjoIP");
    double HaJBNGa = 548768.6684484844;
    string ElphO = string("jCmKVgXRGVDGxfRBVLqOLoIYxeHSCuudkzJKvQpgrJWJiVaqHeKfWfPJiIrMFkRQeuVnUsJasljuaeNsRfyjllHNwQJQbUHY");
    double edHHfUFcoCqd = 902121.0223350511;
    double WlytADK = 46990.61702128222;
    bool elXHtlpwuhPbZr = false;
    bool OUrmDkUJPDaAPmRo = true;
    string NZcHPQzylD = string("IQVlDugwNBfdzRFNQSKRrVfhKeSzNkFdwoASzpfbTXzAuDTAINmcWtaXLArNwSpurdQDYsveACEbQXQOcYpZwLfGBUBfzbWULkZmDsHdeAOXFTwtEnuUrovwPbRTeRyLBDFtnZBEIzFmdzZRVHSJKyNwUjZvTAaFXehBOEzQHUXXEpoUhezAdIreMhsENg");

    for (int FqQWwjtD = 1717645254; FqQWwjtD > 0; FqQWwjtD--) {
        edHHfUFcoCqd /= edHHfUFcoCqd;
    }

    if (edHHfUFcoCqd != 46990.61702128222) {
        for (int pEjlh = 14944084; pEjlh > 0; pEjlh--) {
            HaJBNGa += WlytADK;
            ElphO = humBTbPA;
            OUrmDkUJPDaAPmRo = OUrmDkUJPDaAPmRo;
        }
    }
}

zNybI::zNybI()
{
    this->DaaMgYcNfJeJXV(true, string("tYVObFRcXJQDqWWvCgjPskllZsmpXwqvJOTqaWtAAgqCUineVKBJPINDdYWBfKgGZuFWZLnJaJUYbbjVjFAsAPEmbpgoFngMNvFYVGsXLdVNwxvEgJCrGjOVRGfIPmrjayNMeOWANTRfaqMiVyDiIIkUWwNJKtEqgQnUIAATfTpluNtcmzTUsaRmBJHvIAykoBNBMZADiVgZjHsIZMQrewbIjFTxGHbU"));
    this->ZySrDoDLmFsmh(string("JKFLwUgxBIfvzVvxTQXzwFJfOgmUhCLUAbMBjOGPursLZlObHHihyjXwUJYzoJEKVSRCLHrNiFHcvqJbXeZOssAqhaVlkKErQdcPBrDImmRqhrUaSLdjwZfDqmexkXSIkBmnhJzHYWuPPmEJBkOdBDakgDRMNAfShAitTDjZjoWYfGOWJvdFZKKlqOHarrWoCgpQTKRzrKcMGqoEjFwQUOKthUwHdxHTmUfdWtmNrDGHIqllhe"), 633867.2582539481);
    this->LxZCXAPUvIhGIO(true, true, -1720304787);
    this->KZFul(string("TAiscAMTNkpFDjJJsdAniBqMpOzUZdKJvAaKvsVVbovRsURitVwHUFBBzEPHSLzdgvyuITehyfKLgvNVIqdStzTjloTzmYCWWDhOhkVuBDWVKTqpucRQWghbUTRityQXBMJlFZaXDiSYFhVUEuMMFuFFoqoXjkClisjGoQVLsHvMvJLLBMhUIz"), false, -575152.3416419781, -1976803503);
    this->osUhdnDAIpvtoWp(string("UAzuudYiZlqruCgLUnLKfagWXuHEyZoLxBubKJDvAsrOvhwjkorwWqXRxGpZbhUMVqDRDbLDVYoufHcSfbUDpAlVjmCSoEjvRrQtEFaBYrmFlOwUgsrtDTTMRFCVefOInMnMOQzNOEIkrFg"), -861436.9322935011, false);
    this->PbUVlxQPMRk(-970395.9294150118, -1539047209, 464235029);
    this->DIRkozLW(string("HBrJLHlOgKmHLLezxLGaiDtmqiYlSzMLXMhWZvFYHJofkrlDpMXtVSwmMiuCMpBjjRtsQUgjSWkgoWJOqonJbXvgXStKDBINLcBwQgNqEJDMewiNnykCaatOvBdToTfSsSBzpyFNTydARbeOJXUcglEMvKNpwgXKuuMOWSXbWPFASUZoboOQjrNyjwZtYqGJodLELU"));
    this->zQOfKMeNOniPAYmX(212169.3087866102, false);
    this->lfAMITvlQYVoOgMO(-624984.0098347964);
    this->eHoUQdLhKjMpuMg();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XGcquFMpCnYep
{
public:
    double XRVpGVZKFY;

    XGcquFMpCnYep();
    int JgkBKl(double ZmXNcowMEy);
    void OyWSi();
    int VzIPUFGshst(bool xVfevnFL, string aNOegLZyrNy, int ZVaHTSd, double pVnziBlgpDbQw, string LxHBiRxA);
    int vPFUAf(int nHZDJYbqnv, int mgydHb, double jCTPsUGFGyNmcj, string yLcCdIKp, bool JotQzrtaugOheF);
    bool NHhFS(int UwBiTPGHnTv);
    int ykBXSDv(double ljhTKAjeyW, string mQtxFhLQwe, bool xRTLYLubJTDMb, int QevZnHMebmQ);
    double JWzJGjGrQmiafc(bool TKTEtM, double nvlGj);
protected:
    double SXFDQmE;

    string lytqtZDf(double TgXCYL, string vtDxNKDXh, double hQrhSsmfkErGR, int HGWhM, double rNlrRvu);
private:
    int gEQVR;
    int IttlXvNRXcWWRhHP;
    double kGhYeEIcJyca;

    void fByjLqhlldfnTf(double Wzjyi, string yQlHKJDie);
    string hDPnowwgxLg(string WPAPda, bool CnTXHSRWvghY, int WVTeMj);
    void rbvSGj(double ItCmTJU);
    void VOrJJwNDigKtxud(string DNzsyCNAapNpyJL, bool EIqcg);
    string VxTKjNv(bool fggVKdPGDUhM);
    int EaVnBl(int BSpsOjtAFRSwY);
    string STxefmFRv(bool zBUIzyGgcj, string GWgMGXGS, int sdeYp);
};

int XGcquFMpCnYep::JgkBKl(double ZmXNcowMEy)
{
    int xPaWC = -1445087465;
    int QDMYa = -1600927566;
    double ejxkYpyw = -998956.8230483617;

    if (ZmXNcowMEy == -998956.8230483617) {
        for (int XNFgrDIdrwqHBI = 1774861238; XNFgrDIdrwqHBI > 0; XNFgrDIdrwqHBI--) {
            ejxkYpyw += ejxkYpyw;
            xPaWC /= xPaWC;
        }
    }

    if (xPaWC >= -1600927566) {
        for (int erkYrk = 844932222; erkYrk > 0; erkYrk--) {
            ZmXNcowMEy *= ZmXNcowMEy;
            ejxkYpyw *= ejxkYpyw;
            QDMYa = QDMYa;
        }
    }

    return QDMYa;
}

void XGcquFMpCnYep::OyWSi()
{
    string xmPkhQDtwJgEkPNm = string("EZHNtYjrDXNMvYyzGGRmtNOwrxYKDsndFOAcLTNZfrJppianDdJrUjeOScgrzqNNdOWkAoROsJLYEbSfiuIGBnuZWklvPNQcDzHdMctwdLpUHcVVlppVMRkvpRbNrGLRiOErNgSfmgteGywxDOzfEeSrLlOLUvrQkingfHPiWESqwJXgDxxGFpbujuNPLGOxRFfmmhDQpgZUIXYoxZKQEFKWITSeNAvjKdPsIHmQUNeG");
    double zRUiNbNhvyIkC = 335735.982488544;
    int SlFsTwdZaSV = -665931959;
    double wOsVMBNGfNVx = 482027.67778550944;
    string SVSEVJd = string("dfTPvoZQKIjBnkcwOtCKwLsCQPUKPrQJLsRWZtgvXwTqxlZoImWDSTfzdWMKFZurhnRFwITIAnSAEofVVqgGyWbctdaisEGSPZprsSiuhRikErqJAIpDjIlzuQJvPXSbIYsByXMQU");

    for (int FbSbMQVkhE = 1200541007; FbSbMQVkhE > 0; FbSbMQVkhE--) {
        continue;
    }
}

int XGcquFMpCnYep::VzIPUFGshst(bool xVfevnFL, string aNOegLZyrNy, int ZVaHTSd, double pVnziBlgpDbQw, string LxHBiRxA)
{
    bool OSozOvfGGHWGtsl = true;
    bool ZQLTrherWpd = true;
    string SJShGoT = string("JaSBMtZoodCxSfxYJPiaZHXIeHUkKdZYwWdFBzKmxpRunSYijdmfaCfwEVemPEFqSnRgoMecXRUxlqTvDCyVjoDDEqDIojyeTMrLvobTthojkmeKhcrTvHFqRNZMfFVquMBmdxPFMFIypYhbotkDKejqiPHydKIxdyjxLaHjkXorCdpXZNXrmrZHBxLMowxTzQmKLffqATkYzyJPgCukThZcFgBKRwOE");
    int wvZgySC = 594879051;
    bool oHXwtIGwtIkqN = false;
    double URwzscNxXBsrt = -1019948.520348411;

    if (ZQLTrherWpd == true) {
        for (int ZXaSpkubEBIihm = 454705961; ZXaSpkubEBIihm > 0; ZXaSpkubEBIihm--) {
            ZVaHTSd /= ZVaHTSd;
            SJShGoT = aNOegLZyrNy;
            OSozOvfGGHWGtsl = ! oHXwtIGwtIkqN;
        }
    }

    if (ZQLTrherWpd != true) {
        for (int dRSbNhTWUPXH = 1558005463; dRSbNhTWUPXH > 0; dRSbNhTWUPXH--) {
            ZQLTrherWpd = ! oHXwtIGwtIkqN;
            SJShGoT = SJShGoT;
        }
    }

    for (int MBYbd = 470929960; MBYbd > 0; MBYbd--) {
        ZQLTrherWpd = ZQLTrherWpd;
        wvZgySC *= wvZgySC;
    }

    return wvZgySC;
}

int XGcquFMpCnYep::vPFUAf(int nHZDJYbqnv, int mgydHb, double jCTPsUGFGyNmcj, string yLcCdIKp, bool JotQzrtaugOheF)
{
    bool QDxKVQtoDc = true;
    double BikfppGLb = 371039.4472768372;
    double NBUiHcGgqgajz = 719750.0983019032;

    for (int SzAnLPKJs = 1961928505; SzAnLPKJs > 0; SzAnLPKJs--) {
        BikfppGLb += BikfppGLb;
        jCTPsUGFGyNmcj -= jCTPsUGFGyNmcj;
    }

    if (BikfppGLb <= 719750.0983019032) {
        for (int AHBGmUaUSlEWEjS = 1142950188; AHBGmUaUSlEWEjS > 0; AHBGmUaUSlEWEjS--) {
            jCTPsUGFGyNmcj -= jCTPsUGFGyNmcj;
            NBUiHcGgqgajz *= BikfppGLb;
        }
    }

    for (int rgcNAKuLW = 858768596; rgcNAKuLW > 0; rgcNAKuLW--) {
        jCTPsUGFGyNmcj += jCTPsUGFGyNmcj;
    }

    return mgydHb;
}

bool XGcquFMpCnYep::NHhFS(int UwBiTPGHnTv)
{
    bool BkZRqmXKFbBo = false;
    int vIPGUJXKKrm = -1159873800;
    int COfdWeA = -547592076;
    int modgzizgkKEFzq = -504789215;
    bool EMFyEX = false;
    bool ShTpaOWokCCbKSvS = false;

    for (int LMibzPcMvBflNedQ = 548657873; LMibzPcMvBflNedQ > 0; LMibzPcMvBflNedQ--) {
        BkZRqmXKFbBo = ! EMFyEX;
        UwBiTPGHnTv -= COfdWeA;
    }

    if (UwBiTPGHnTv < 2070359625) {
        for (int HyKNPP = 1064565427; HyKNPP > 0; HyKNPP--) {
            COfdWeA *= modgzizgkKEFzq;
            COfdWeA *= modgzizgkKEFzq;
            UwBiTPGHnTv /= vIPGUJXKKrm;
        }
    }

    for (int kGhFbYQCQR = 996573067; kGhFbYQCQR > 0; kGhFbYQCQR--) {
        BkZRqmXKFbBo = BkZRqmXKFbBo;
        UwBiTPGHnTv -= UwBiTPGHnTv;
        UwBiTPGHnTv /= UwBiTPGHnTv;
        BkZRqmXKFbBo = ShTpaOWokCCbKSvS;
        ShTpaOWokCCbKSvS = BkZRqmXKFbBo;
        COfdWeA += COfdWeA;
    }

    return ShTpaOWokCCbKSvS;
}

int XGcquFMpCnYep::ykBXSDv(double ljhTKAjeyW, string mQtxFhLQwe, bool xRTLYLubJTDMb, int QevZnHMebmQ)
{
    string BfsaDwRwBUrgue = string("RjxpkKeLmCLVLCTMwQNtGmTWjZZPbDvGPiKRDYrIyaJHvRwRYGBIeaGbPRiEYHdrtaQVCCflimsJgFiiNs");
    bool ernJcxUxMoanbot = true;
    string hDALleJTwLf = string("cMgUGxxxGACoFzjrOdsDPUHycxpTyNBmVLBkrBpePaeBXIRIlSgFKKifEDphDBEqbgGRNoEQwHcOmEFUZBUQXjiIsxMPAkhSf");
    double zCFbXbUjDAMCJAo = 3428.0920285606558;

    return QevZnHMebmQ;
}

double XGcquFMpCnYep::JWzJGjGrQmiafc(bool TKTEtM, double nvlGj)
{
    string VHOghMo = string("emWyAUuraSNuwbvhzwDjlCmfIneGUWJInIlCLmRCrneFrDgiVXCTMlRieYELoXroDekY");
    string OKngKhcYk = string("RQwZUoGMCRgGJqDEpcSIrypBvsUqBxZtIYyKHjcsTxwfxNInPCxfgPxxktzpMLwrAbMGdiBpdgACbBaaOfdXFspAeEfHfsZqkWKwaQdYeuruHoeJgwnRsZThAcNXINYfQmGbRmxNxQnaxkDLfOCheScFPLKdKJIBidCXJsuAKNNIoWinmiHUO");
    double VzBPQdMfmZzcTg = -377869.94018076465;
    int VevKjeU = -912943146;
    double pdLaAYBaHdlJVxdR = -498966.40077303676;
    double KXJhSga = 904448.449137425;
    int cTmoaVWKb = 1100901976;
    string yitXqejZsmbPbbBS = string("dpqGuwosQyUCvWpidpKrBgNPejwoVcdZFINzOJBgpWntwEUSSoWIUuUCfUxUzaNrSaRgcFwuwMydCefjfHsJOfYBOjlEvMzBrncqgFIzYBwULBUEaSKbbaIXbHAnuiSzKblfednvRLRHVaxrJLzvvcmYAhNyFQbTakrpFMh");

    for (int jnpYrz = 2020036366; jnpYrz > 0; jnpYrz--) {
        continue;
    }

    for (int asHhQVHg = 34435399; asHhQVHg > 0; asHhQVHg--) {
        nvlGj = pdLaAYBaHdlJVxdR;
        yitXqejZsmbPbbBS = yitXqejZsmbPbbBS;
        KXJhSga *= nvlGj;
    }

    return KXJhSga;
}

string XGcquFMpCnYep::lytqtZDf(double TgXCYL, string vtDxNKDXh, double hQrhSsmfkErGR, int HGWhM, double rNlrRvu)
{
    double MKxZmqBYdWOWQW = 56635.495701892214;
    int MruOktbBcKtTJOw = 2006523848;
    int VZCJWDzEzylAji = -1252521091;
    int irCKmUnpNhrcC = 1140923079;
    double RzCeVOLhzHoXygD = -910445.8407989506;
    string wYmbTYCAlcLgIl = string("ujlpHIiURnLeSTrcKCcAMTuWeDbdssrIrEAGNheOwAWlJwLUIUlVOdsarewhLIiBTbHohahHgcpLpOugzAnRIDJDdTzTSXtxRfdXCioeaWqbQvQaoQHmtbmmkPoantGBjqaHXuIEwwjVnnxUKobLDQkaOfcIRqNdLiFIitIDSWxXqyHTTlByZBrjvFranqoSsHGNVBvEcTCmQABiZQqxsTSQLdXaGnGwIwKjBVduGIYitDUJb");
    string LkAgTHInMKYFZ = string("bQLKAKCZazyfEhJqdcFmDoMCwpVLFmEmLOIeQQTRDvJiQqFtDHVlrvtOqWrMoAeiqxPfCfiIburdTtGeZkUEWZQnolfiqaIQaFCpqxsXqMOyFgbZqXMlJIrjXeQjackYObTIGiUXHLUBhmIzUHWHMYCGtoRrtEnBYOVueMBdORXmcWQAbviqlWYfeQsoFNYTWTNEcqJ");
    int HEGpuexoIJBH = 617736842;

    if (VZCJWDzEzylAji < 1140923079) {
        for (int VhyNJ = 1906889509; VhyNJ > 0; VhyNJ--) {
            HGWhM *= MruOktbBcKtTJOw;
            rNlrRvu += MKxZmqBYdWOWQW;
            HEGpuexoIJBH -= HEGpuexoIJBH;
        }
    }

    for (int iMnHWQaE = 1840501616; iMnHWQaE > 0; iMnHWQaE--) {
        hQrhSsmfkErGR += MKxZmqBYdWOWQW;
        HGWhM -= HEGpuexoIJBH;
    }

    return LkAgTHInMKYFZ;
}

void XGcquFMpCnYep::fByjLqhlldfnTf(double Wzjyi, string yQlHKJDie)
{
    int KrlTPIEWQye = -568154160;
    string DMSdqTEfDnSC = string("MxkGmBgNnmgWqbIyyfmohwuDwBDWLpFUSmNQxjjuGvUqawfZpOOBXfzXXsyQHsVYNQHrrBHICoqUbfbpAxRYPkTRBwvECYxBtAPdQouRLkcpDMOJzAwdWoDOhyAJrNCqIrfKtxOIPBkSXVSPEXqvYCiEyNiPntLONnBpRbLafgHsHstKfXwTSUiaEmbKvwKPRVaDTKktvYrwEgLtttruOoVyrl");
    double aEyAN = 1034882.4009709138;
    int twaaAWBNxNkNXjl = 347711617;
    bool SJwudfzctdbzyTe = true;
    int LwzzPtFVb = 730123839;
    double IOJKDfpeQYkjxarY = -752487.1623396592;

    if (DMSdqTEfDnSC <= string("MxkGmBgNnmgWqbIyyfmohwuDwBDWLpFUSmNQxjjuGvUqawfZpOOBXfzXXsyQHsVYNQHrrBHICoqUbfbpAxRYPkTRBwvECYxBtAPdQouRLkcpDMOJzAwdWoDOhyAJrNCqIrfKtxOIPBkSXVSPEXqvYCiEyNiPntLONnBpRbLafgHsHstKfXwTSUiaEmbKvwKPRVaDTKktvYrwEgLtttruOoVyrl")) {
        for (int gDSaqijMhjr = 482441274; gDSaqijMhjr > 0; gDSaqijMhjr--) {
            yQlHKJDie = yQlHKJDie;
            twaaAWBNxNkNXjl -= KrlTPIEWQye;
        }
    }

    for (int FgzUJWDWqPkvYM = 946312745; FgzUJWDWqPkvYM > 0; FgzUJWDWqPkvYM--) {
        DMSdqTEfDnSC = yQlHKJDie;
        twaaAWBNxNkNXjl *= KrlTPIEWQye;
        yQlHKJDie = yQlHKJDie;
    }

    for (int EpoLavEGlxMfmXB = 629559895; EpoLavEGlxMfmXB > 0; EpoLavEGlxMfmXB--) {
        continue;
    }

    if (LwzzPtFVb == 347711617) {
        for (int xyFyfi = 311765974; xyFyfi > 0; xyFyfi--) {
            DMSdqTEfDnSC = DMSdqTEfDnSC;
            IOJKDfpeQYkjxarY += Wzjyi;
        }
    }

    if (KrlTPIEWQye <= -568154160) {
        for (int uVOqRJOWOMdWTS = 1551242781; uVOqRJOWOMdWTS > 0; uVOqRJOWOMdWTS--) {
            LwzzPtFVb -= twaaAWBNxNkNXjl;
            KrlTPIEWQye -= twaaAWBNxNkNXjl;
            Wzjyi /= IOJKDfpeQYkjxarY;
        }
    }

    for (int ZlgUkcxmXL = 1526287778; ZlgUkcxmXL > 0; ZlgUkcxmXL--) {
        aEyAN *= Wzjyi;
        yQlHKJDie = DMSdqTEfDnSC;
    }
}

string XGcquFMpCnYep::hDPnowwgxLg(string WPAPda, bool CnTXHSRWvghY, int WVTeMj)
{
    bool VrlpMMgTtJZGfVTd = true;
    string ybeFUvcYveruDER = string("jcrpxzKptVuVoqSlOIdurBzVEuHNvAWDTAbDJlYBpHxcSPWIuTfieJiLiifibkfbdDHnyHYGAVmIQWFfWgZsKCtXlLTKtMYpnPtWrgZCLKhUlJGqXobrlAsGRflDXbIgjeNjdfPiDUkNrWopCuMTXSDzhJOUUXBTScQqgKcITuaqibXMnRCTanRsqDEDexcTxntzOhyObWQeXJoZjlMVnIOHkTCwToxDAlP");
    string nrVjJv = string("oGtksMztaHQyihZwExHxnncNUcjyMnVqHHDbDRwQgRhkxLReNolpoOCHVeuHscCwcLvZSANFMasJrjUOaqGltttxHlWDpwZETFvqHGUYZDUJakVILBAdB");
    string cabJFyyHO = string("xaopXYErUyiFyLrwZKYcOfrrqSIeYnZvHGNlIUvEdNYNhXOBjAaexlPjcIwKkJbIKogeUKihgXMcXrAKpXuBIoQtyMmXTBVBtiTxheDymXfODuKwQIhTcmgFdZNXeJalaaaGCfwUMWYMkMQmzBAKOsMlOoMdqhAsfnSopvBaFGUFMFqINOzyRtcsZjtSzSfouXGRyHivfIvZjhDKqPWQxN");
    int PadoqGKHgXxscMC = 2120830200;
    int TrjSOJfeiaNacdl = 1414168161;

    for (int JAqDUzEDYXGYxv = 1820832000; JAqDUzEDYXGYxv > 0; JAqDUzEDYXGYxv--) {
        cabJFyyHO += cabJFyyHO;
        WVTeMj /= PadoqGKHgXxscMC;
        cabJFyyHO += ybeFUvcYveruDER;
    }

    return cabJFyyHO;
}

void XGcquFMpCnYep::rbvSGj(double ItCmTJU)
{
    bool DjcoLezqFPoTv = false;
    double xuBEqkmRIGLaJLBK = -858129.8736525154;

    if (DjcoLezqFPoTv != false) {
        for (int NOuotFDFgX = 649575368; NOuotFDFgX > 0; NOuotFDFgX--) {
            xuBEqkmRIGLaJLBK /= xuBEqkmRIGLaJLBK;
            ItCmTJU /= ItCmTJU;
        }
    }

    if (DjcoLezqFPoTv != false) {
        for (int IADUSMmgUJ = 1858549174; IADUSMmgUJ > 0; IADUSMmgUJ--) {
            ItCmTJU /= xuBEqkmRIGLaJLBK;
            ItCmTJU = xuBEqkmRIGLaJLBK;
            xuBEqkmRIGLaJLBK *= ItCmTJU;
            xuBEqkmRIGLaJLBK /= ItCmTJU;
        }
    }

    if (ItCmTJU <= -622602.1950022196) {
        for (int EXnSlWiIbKjN = 1227687491; EXnSlWiIbKjN > 0; EXnSlWiIbKjN--) {
            ItCmTJU /= ItCmTJU;
            ItCmTJU *= xuBEqkmRIGLaJLBK;
            xuBEqkmRIGLaJLBK += xuBEqkmRIGLaJLBK;
            xuBEqkmRIGLaJLBK -= xuBEqkmRIGLaJLBK;
            xuBEqkmRIGLaJLBK /= xuBEqkmRIGLaJLBK;
        }
    }
}

void XGcquFMpCnYep::VOrJJwNDigKtxud(string DNzsyCNAapNpyJL, bool EIqcg)
{
    bool dZJtmHWpJYmsu = false;

    for (int znBzTR = 1896498658; znBzTR > 0; znBzTR--) {
        continue;
    }

    if (EIqcg == false) {
        for (int LXkhdhGmSzltT = 310418632; LXkhdhGmSzltT > 0; LXkhdhGmSzltT--) {
            dZJtmHWpJYmsu = dZJtmHWpJYmsu;
            dZJtmHWpJYmsu = ! EIqcg;
            DNzsyCNAapNpyJL = DNzsyCNAapNpyJL;
            EIqcg = ! EIqcg;
            EIqcg = dZJtmHWpJYmsu;
        }
    }

    if (dZJtmHWpJYmsu != false) {
        for (int qtpkRsbYwNoi = 979514335; qtpkRsbYwNoi > 0; qtpkRsbYwNoi--) {
            DNzsyCNAapNpyJL += DNzsyCNAapNpyJL;
        }
    }

    if (dZJtmHWpJYmsu == false) {
        for (int fgIDWQ = 1246367987; fgIDWQ > 0; fgIDWQ--) {
            EIqcg = ! EIqcg;
            dZJtmHWpJYmsu = ! dZJtmHWpJYmsu;
        }
    }
}

string XGcquFMpCnYep::VxTKjNv(bool fggVKdPGDUhM)
{
    string hNBpa = string("hbCdgnstvMUUiTPHDwXPqzCdpSiHxFRYlXyyMRjfblYKBsigWIV");
    double SqiiDpGCXl = 112390.6778918673;
    bool GZZZdSZ = false;
    bool VhTVfSyTqORWe = true;
    double dIIOzoxJBeUQE = -1000535.4226307328;
    int yCRnTPmwJCVJeKt = 1160892364;
    bool FRlzUsQVchGA = false;
    string JvcEjgjUPbK = string("uzaDgJAAIwXoIOBdRRbLEMsGQVegAMfiIuBEOSAijEEjxQBMxZPfMLWygzboruvoBledDGSpKKBjsYcYEWzKAHRFPCZkmdtRVaJpudwBjcvjhVlgzGMouRzYatQFeLyAfHx");
    double uPUHqnTDIWg = 628557.1261716048;
    bool WxbMwBuwwoufBbCO = false;

    for (int UWVfMhgNoH = 2010581044; UWVfMhgNoH > 0; UWVfMhgNoH--) {
        WxbMwBuwwoufBbCO = ! fggVKdPGDUhM;
        WxbMwBuwwoufBbCO = ! FRlzUsQVchGA;
        GZZZdSZ = FRlzUsQVchGA;
    }

    for (int eiSiQ = 1448431455; eiSiQ > 0; eiSiQ--) {
        continue;
    }

    for (int bpYubDNgVs = 108307480; bpYubDNgVs > 0; bpYubDNgVs--) {
        WxbMwBuwwoufBbCO = ! GZZZdSZ;
        uPUHqnTDIWg += SqiiDpGCXl;
        VhTVfSyTqORWe = ! VhTVfSyTqORWe;
        WxbMwBuwwoufBbCO = fggVKdPGDUhM;
        WxbMwBuwwoufBbCO = GZZZdSZ;
    }

    for (int YJIdieLj = 1404672845; YJIdieLj > 0; YJIdieLj--) {
        WxbMwBuwwoufBbCO = ! FRlzUsQVchGA;
        WxbMwBuwwoufBbCO = ! WxbMwBuwwoufBbCO;
    }

    return JvcEjgjUPbK;
}

int XGcquFMpCnYep::EaVnBl(int BSpsOjtAFRSwY)
{
    string YwtNMaVStbfsh = string("PKgHRTNXvPUxixXWIkqKpBsrAhiYyQYwWIauKWFBMgKhLcUuxTotxEizFTFVxkMhekJVUCbTWZykcLxiIOsvPlXDdmzQtsokRscsZZLCb");
    string NhGkCTiLYKDQROTT = string("OleMuvIfYaTLYmXscgUNViJpPUrocYIzSxINLardtONsTOaJQhwXchmNQKjNwEjDHMBxtSVKVUMIWJAgTqrJSgEmJVZtHDbtGyyWqDtTQVHpAy");
    string kQtxrKfEMzMdfiDo = string("URgMZKBnwWKyWrkyDpgCyCGEOdQvmWQUUELLrWeJkqqyJOZNAIuaaRUiNwXORGXtagqlBLvThUGCLjeeKsbqSJWaDCsIyTwNQWtXxoYUWANhFueXAmciTSZpyrsXOQHxWUSPLXsnuXaeemQFgOxMHaVD");
    string MBOVKczP = string("vSrcQyVOdIfzVVtmMIjHDTiHONYeFfLFMGMcyKHMesFHoWvkSgLSlvAhZwFlgXXDqoFMqhFibvnrxPvtEgCSqjyyZxjQOUjIvnpuvElwiDSdUyGtjbKYNgxVNTqbaxeupYIDhLDopierfCETpXGHCIKzyASlNapNiFWkNoQsvZMOddvKqUIjaXZqhbsj");

    for (int gieaDyJzq = 241730280; gieaDyJzq > 0; gieaDyJzq--) {
        MBOVKczP = MBOVKczP;
        NhGkCTiLYKDQROTT += MBOVKczP;
    }

    for (int SqvnmKlG = 1098354803; SqvnmKlG > 0; SqvnmKlG--) {
        continue;
    }

    if (kQtxrKfEMzMdfiDo != string("URgMZKBnwWKyWrkyDpgCyCGEOdQvmWQUUELLrWeJkqqyJOZNAIuaaRUiNwXORGXtagqlBLvThUGCLjeeKsbqSJWaDCsIyTwNQWtXxoYUWANhFueXAmciTSZpyrsXOQHxWUSPLXsnuXaeemQFgOxMHaVD")) {
        for (int IBzmfjtau = 341852594; IBzmfjtau > 0; IBzmfjtau--) {
            NhGkCTiLYKDQROTT += NhGkCTiLYKDQROTT;
            NhGkCTiLYKDQROTT += kQtxrKfEMzMdfiDo;
            NhGkCTiLYKDQROTT = MBOVKczP;
            NhGkCTiLYKDQROTT = YwtNMaVStbfsh;
        }
    }

    if (MBOVKczP == string("URgMZKBnwWKyWrkyDpgCyCGEOdQvmWQUUELLrWeJkqqyJOZNAIuaaRUiNwXORGXtagqlBLvThUGCLjeeKsbqSJWaDCsIyTwNQWtXxoYUWANhFueXAmciTSZpyrsXOQHxWUSPLXsnuXaeemQFgOxMHaVD")) {
        for (int drDcQN = 578047784; drDcQN > 0; drDcQN--) {
            YwtNMaVStbfsh += kQtxrKfEMzMdfiDo;
            kQtxrKfEMzMdfiDo = MBOVKczP;
            MBOVKczP += NhGkCTiLYKDQROTT;
            NhGkCTiLYKDQROTT = MBOVKczP;
            kQtxrKfEMzMdfiDo = YwtNMaVStbfsh;
        }
    }

    if (YwtNMaVStbfsh > string("OleMuvIfYaTLYmXscgUNViJpPUrocYIzSxINLardtONsTOaJQhwXchmNQKjNwEjDHMBxtSVKVUMIWJAgTqrJSgEmJVZtHDbtGyyWqDtTQVHpAy")) {
        for (int qIvGvigVchp = 1720646585; qIvGvigVchp > 0; qIvGvigVchp--) {
            NhGkCTiLYKDQROTT = kQtxrKfEMzMdfiDo;
            NhGkCTiLYKDQROTT += YwtNMaVStbfsh;
        }
    }

    return BSpsOjtAFRSwY;
}

string XGcquFMpCnYep::STxefmFRv(bool zBUIzyGgcj, string GWgMGXGS, int sdeYp)
{
    bool HvdBzxFXbWAQaC = false;
    double NVCfmot = 387678.993804583;
    double AcdHWuLRHtYCjGy = 280335.2747493184;
    string iTAXRsOeSW = string("bWy");
    int PRERVY = -396962686;
    string rcQcQdCSDm = string("xseuKejOhVlgfTifozqRzzobQKjSAjkgKfUvFCZGKbZjnTMLtPbJnxvtCrYLOaCKFjuhaKlbjUDWLlQcYKZaHGhtGnlVzxvnuhmM");
    string MGnJFM = string("ZeGQOYaHUTlcfyibhnqRABNjghXKNmsCJzBmGAEgtkYjbqCdRIlAeeQEkZrnsPnXOAXlupxPuWIXVbtNrCpLYJvhasQKSkFmRpqrYsya");

    for (int JFtGCyJfLLj = 383666958; JFtGCyJfLLj > 0; JFtGCyJfLLj--) {
        GWgMGXGS = GWgMGXGS;
    }

    if (MGnJFM >= string("RXICvSelKFqqBDzRnQBnaQTfAXmfBNkarLXqJTgEdFvqrgfFeAvuqNzcOVKhpTnQfuptZtWlVTgGxnkPgTkgHwZNlCCpnOJxXFBohyipLQvtYuA")) {
        for (int FaqOVHYaE = 1545439800; FaqOVHYaE > 0; FaqOVHYaE--) {
            continue;
        }
    }

    if (MGnJFM < string("bWy")) {
        for (int Kfjdcjkx = 1291111488; Kfjdcjkx > 0; Kfjdcjkx--) {
            iTAXRsOeSW = iTAXRsOeSW;
        }
    }

    return MGnJFM;
}

XGcquFMpCnYep::XGcquFMpCnYep()
{
    this->JgkBKl(-42402.52675139353);
    this->OyWSi();
    this->VzIPUFGshst(true, string("uKlMIYDtIJTIBSxqiIZNOmNQGoGluBOFrAxUOzbKMZBzgliWfwMByXPkAmRahqUBHfywPlOZuzZwvqXgiFOUiQRzDqhAXlIXXWcBJXLqaUTvNJkgkBChQjBGKoqziDLabVNBJRMqBzdXMObexlIytZNmJsURjAvnFpZvtSoHPHNqaJUsVdyHRzb"), 1655394008, -866913.1712696044, string("FKAWyADTuPHaOonmdViNFSXcWqhTPhvRsjImCXp"));
    this->vPFUAf(-1732524882, 104577578, 846405.1641622786, string("bBXBhQSSHWsXPQQJARbAJgZKFZMMgIoVuvhgHbNoADmZbAuoPClpkSbTfVYQWdaPvumzGdFPNaXbNoTLLsHnAJgFNbGGIGgkkuOePxHlgUdEfgZpHDXLsXfVWlQxeXKWuVUzQBcWpyMyEmlmYCiWvRrTRCyLPugENxCAxTayBKMRzcYFnmGJikxAKkNZEDXaYOaxStNtwQEMKVUHzWxHFwY"), false);
    this->NHhFS(2070359625);
    this->ykBXSDv(633073.2507963676, string("ahSkHPtNFRlfSqeXmmDeuNGmnbwFcyVOzZVVJTONsnKyUAroTKYWlEjMCyRpQyklDllTtgmWpeGRravdSAITxyUXWDVUDErMgljmAKoQAHZuVjLDHXBpZzZGXrBtjvSoWQuXTrvBUncEybuhQiURoIUyqHCmbKZLGCNPEFVIZwjlQHRhZVjgWaAXmpNaWjwJpTRfVwUsXkjXwXdMwZjMdVyCGSEDMoCywOjiWTpokhQMqoPkB"), true, 595381897);
    this->JWzJGjGrQmiafc(false, 825406.8576724209);
    this->lytqtZDf(284914.4538765753, string("dESUYYMLYKCynaqPOyWCTncSSltSXkbKPsOclqjcQIHMGpa"), 223297.08432004703, -1598698088, 764879.4306764697);
    this->fByjLqhlldfnTf(515179.14360878937, string("rSJsADbqsLOqOyMPlmIFwMhOtOIBJlPYxWpRxTeUtURKavpKwlQFwXlskaGLAbloOOUdRTzhBFeyykoUdpsIiReZTVpNXWsvGGzMSWrrzNOAEGhNyQAvlfINopwqdWtGuuGkgqUqVhNsAgzo"));
    this->hDPnowwgxLg(string("wMAcKPgAoYgLAQPbbvHbbPBEbGRKnnOkViCAiLXEMw"), false, 927957697);
    this->rbvSGj(-622602.1950022196);
    this->VOrJJwNDigKtxud(string("BQoVdsZlWoqWbJyWrObaPGcGdhvUqhXzZVauMmiweUDvAtncGgAJNiWtpQnknlQORVQJTXhOliwQWxejEFEZJNXvYGxkSnhmXcilSMMrytPnlqlvrlMYbQLXHgBbQLsRhCYPtAiZkumYBuFiDOWUxqfGgHMPFBGqyoelIwRwFLMgqJFuNpUWtBxveOQMCHfNdBvSFsvGbulzBPGVhJcNUJzEfQSMdqHbLYOvitmiemZlCkRecHfUf"), false);
    this->VxTKjNv(false);
    this->EaVnBl(748074657);
    this->STxefmFRv(false, string("RXICvSelKFqqBDzRnQBnaQTfAXmfBNkarLXqJTgEdFvqrgfFeAvuqNzcOVKhpTnQfuptZtWlVTgGxnkPgTkgHwZNlCCpnOJxXFBohyipLQvtYuA"), -1317491992);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lJqEBjfmT
{
public:
    string rhwcvkyRo;
    double JtsbJSnC;
    string dVLXppO;
    double eNtYSHwT;
    bool mFzKRo;
    double AmaOoLVmZbXLtdB;

    lJqEBjfmT();
    int hWFiRmrdXgyOx(int OJtykB, double LCaTiNDRvvLnd, int kkGWgGZLYafHRb);
    int ddKkuQZfPZH();
    int gTIDe();
    bool wtqxwNdimbeg(string yfnyFGQ, bool rKZwhXWE, bool rbKuauZOtq, int CGkDJknF);
    string rIPASDEoy(double qUwJXV);
    void cSVeSnXrTyqdnm(bool lSDexPfqukg, double hDLJgvI, double lOZmiwNpVTSv, int lrsPADYAh);
    double MaOzqfnwPUaB(bool VWJpSDy);
protected:
    bool mbFFsfLeNk;
    bool RHpJdlhnatsV;
    bool Cnwiv;

    bool MSRUHmceFdGQnj();
    string CiTkgZXX();
    string RyjVRqOOeX();
    int cFVFb(double WOrDHZXZrD);
    string gYIEXcB(double RzyHCCTmLziv);
    int YXosFBlrqvNbRt(string oheigisLh);
    bool GKFyY(string Cmldp, bool onhozCFNnJEx);
    string NEzVb(int vJOIuTBfmfIH, int fwhdD, double LElySxixVaVZ, double xMqjo, double CmvLOYh);
private:
    string CwTFZloormbgCrV;
    double gemflpsOSRYLwT;
    int iWlAjtsNvgV;
    double LExaCPzrl;
    double ELjbn;

    void ogUmU(int bqOnMaYp, bool oKaTKAeqgc, int mbDNJzxhMIsHpV);
    string tiuwDGSYGN();
    void KCTXXxNFXKJH(string pagwNtmHf);
    int iQqtosXCtwGb(int vAgeTKBdRDQ, double OuQWHfUAglEv, double oGbqPqZopLWCh, string QljozqeBCjC, bool OHcBTA);
    bool IbmlyXI(bool bYpmrWeqYw, int guwMV, bool hddioZND, string KgSHyLVGQ, string PiUTbfaERpGaTps);
    int OlkuLjTprDhYDVuu(string tZRuQkEvdiPbpJe, double dIvqEiJNxVfYv, int AbhAfrxTmaL, double zfKzdO);
};

int lJqEBjfmT::hWFiRmrdXgyOx(int OJtykB, double LCaTiNDRvvLnd, int kkGWgGZLYafHRb)
{
    bool taAuF = true;
    string VepouXholInvyxJq = string("OZjEyRYYWquiweaJMfDajwRxBCbpdwJuHswCQXjNdwU");
    double xgsCrYIBWNdWfu = -668612.8788315913;
    int lNvHrIR = 1032325877;

    for (int zYRBAyXwT = 304665419; zYRBAyXwT > 0; zYRBAyXwT--) {
        kkGWgGZLYafHRb /= OJtykB;
        lNvHrIR -= lNvHrIR;
        kkGWgGZLYafHRb -= kkGWgGZLYafHRb;
    }

    if (kkGWgGZLYafHRb >= 1666139642) {
        for (int vjnZNIjbs = 179119822; vjnZNIjbs > 0; vjnZNIjbs--) {
            lNvHrIR -= kkGWgGZLYafHRb;
            OJtykB /= kkGWgGZLYafHRb;
        }
    }

    for (int lTMDKoHNfwGHJlXB = 469120181; lTMDKoHNfwGHJlXB > 0; lTMDKoHNfwGHJlXB--) {
        LCaTiNDRvvLnd += xgsCrYIBWNdWfu;
    }

    for (int VImmZq = 1454780966; VImmZq > 0; VImmZq--) {
        OJtykB *= OJtykB;
    }

    return lNvHrIR;
}

int lJqEBjfmT::ddKkuQZfPZH()
{
    bool veqwEcYzuGdZiX = true;

    if (veqwEcYzuGdZiX != true) {
        for (int EFywRgDAxV = 1201399803; EFywRgDAxV > 0; EFywRgDAxV--) {
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
        }
    }

    if (veqwEcYzuGdZiX != true) {
        for (int npjqhPY = 900173177; npjqhPY > 0; npjqhPY--) {
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
        }
    }

    if (veqwEcYzuGdZiX != true) {
        for (int acqBfAhBZvHIGS = 896570754; acqBfAhBZvHIGS > 0; acqBfAhBZvHIGS--) {
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
        }
    }

    if (veqwEcYzuGdZiX == true) {
        for (int weGCDOjUVBde = 1273790424; weGCDOjUVBde > 0; weGCDOjUVBde--) {
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
        }
    }

    if (veqwEcYzuGdZiX != true) {
        for (int OBqalVj = 1033057058; OBqalVj > 0; OBqalVj--) {
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
        }
    }

    if (veqwEcYzuGdZiX != true) {
        for (int PeitmhpPWXT = 440034985; PeitmhpPWXT > 0; PeitmhpPWXT--) {
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = veqwEcYzuGdZiX;
            veqwEcYzuGdZiX = ! veqwEcYzuGdZiX;
        }
    }

    return 1473771231;
}

int lJqEBjfmT::gTIDe()
{
    string FwObY = string("hyRtEtCAEYxdPGeZRgfCHzhWPyqwEQezedPFiEbxkAgNfYtEKDhAGkrJmNSzxfjvBsXCYlgFKU");
    double CvvzrwwJ = 868601.2453769827;
    bool KotlBcdJWHzuBoc = true;
    double ZPbWMUCnYBqafAJC = 264139.5897249231;

    for (int gymXBjUoJrIneJRZ = 1921957694; gymXBjUoJrIneJRZ > 0; gymXBjUoJrIneJRZ--) {
        CvvzrwwJ /= CvvzrwwJ;
        ZPbWMUCnYBqafAJC = CvvzrwwJ;
    }

    if (CvvzrwwJ <= 868601.2453769827) {
        for (int XpQTIYLKH = 3855980; XpQTIYLKH > 0; XpQTIYLKH--) {
            ZPbWMUCnYBqafAJC /= ZPbWMUCnYBqafAJC;
        }
    }

    for (int JZCWaaAGBwjZ = 287969379; JZCWaaAGBwjZ > 0; JZCWaaAGBwjZ--) {
        CvvzrwwJ /= CvvzrwwJ;
    }

    if (FwObY > string("hyRtEtCAEYxdPGeZRgfCHzhWPyqwEQezedPFiEbxkAgNfYtEKDhAGkrJmNSzxfjvBsXCYlgFKU")) {
        for (int TrTNSY = 1730294810; TrTNSY > 0; TrTNSY--) {
            CvvzrwwJ *= ZPbWMUCnYBqafAJC;
            CvvzrwwJ /= ZPbWMUCnYBqafAJC;
            KotlBcdJWHzuBoc = KotlBcdJWHzuBoc;
            CvvzrwwJ /= CvvzrwwJ;
        }
    }

    return -2120283523;
}

bool lJqEBjfmT::wtqxwNdimbeg(string yfnyFGQ, bool rKZwhXWE, bool rbKuauZOtq, int CGkDJknF)
{
    double cMncSFcM = 666896.3886654482;
    string XTxzxsrnunVLGFN = string("FgPlBJOAATDuStdbYcdNtJLkwVowcfdUnNAuKyeZnrxeoiYnnAVTZeAatDWrMVnzgCbEimlwuxvNsWPNlVysCZfgDIKymXIllJnLcpzfyJCDXOJmHQTgMxCSAkBcyOFWnIiWDkVeBUMFuFsmwwXqPxnmjIMjAhsobfsAUlPNNoPQaRhKTfNrvTiyoymdbDIoAxKklrNnTTTujKZqSyEWvpZIXyoZgjRmrWyVWSaEfLOR");
    bool XdpiTKQwvuQAtO = true;
    string kzCVCw = string("geAHhxtjfekKrGmVUfkraEeJJEUUuRFabVVHBhznwUbczroqxbdYMmkfPWPJGPMmAgaPNVNbKkqtJWQEoUbRzsDRzHeqnOl");
    int VIUlyMpqyjWLxpMW = -40971820;
    bool bTFpfPDEdx = false;
    bool YAlvn = false;
    int BXLyeSGgVHzChY = 1109629786;
    double xpEmxEWV = 782501.2098598;
    double BEAiylRbjheFn = -454230.33495857875;

    for (int KiIZHBKTkAzZQi = 939123538; KiIZHBKTkAzZQi > 0; KiIZHBKTkAzZQi--) {
        rbKuauZOtq = ! rKZwhXWE;
    }

    for (int QdPoqdG = 125781075; QdPoqdG > 0; QdPoqdG--) {
        XdpiTKQwvuQAtO = rKZwhXWE;
    }

    for (int eyVzjmFUASd = 146467083; eyVzjmFUASd > 0; eyVzjmFUASd--) {
        BEAiylRbjheFn = xpEmxEWV;
        rbKuauZOtq = rKZwhXWE;
    }

    return YAlvn;
}

string lJqEBjfmT::rIPASDEoy(double qUwJXV)
{
    double uIuNYhdekkmWPJ = 753961.3196956293;

    if (uIuNYhdekkmWPJ == 198655.1050994301) {
        for (int HEnWkEspYRLNp = 922321978; HEnWkEspYRLNp > 0; HEnWkEspYRLNp--) {
            uIuNYhdekkmWPJ = qUwJXV;
            uIuNYhdekkmWPJ -= uIuNYhdekkmWPJ;
            qUwJXV += uIuNYhdekkmWPJ;
            qUwJXV /= uIuNYhdekkmWPJ;
            uIuNYhdekkmWPJ *= uIuNYhdekkmWPJ;
            uIuNYhdekkmWPJ = uIuNYhdekkmWPJ;
        }
    }

    if (qUwJXV >= 753961.3196956293) {
        for (int SCkug = 528488446; SCkug > 0; SCkug--) {
            qUwJXV *= qUwJXV;
            qUwJXV = uIuNYhdekkmWPJ;
            uIuNYhdekkmWPJ += qUwJXV;
            uIuNYhdekkmWPJ /= uIuNYhdekkmWPJ;
            qUwJXV += uIuNYhdekkmWPJ;
        }
    }

    if (qUwJXV != 753961.3196956293) {
        for (int aWpsVRtfnIevCN = 1107674039; aWpsVRtfnIevCN > 0; aWpsVRtfnIevCN--) {
            uIuNYhdekkmWPJ += uIuNYhdekkmWPJ;
        }
    }

    return string("OUtXVIwwHHWqSbKsaYKkxpTxrHDkAmQBB");
}

void lJqEBjfmT::cSVeSnXrTyqdnm(bool lSDexPfqukg, double hDLJgvI, double lOZmiwNpVTSv, int lrsPADYAh)
{
    bool ymJSIBgiIP = true;
    int gempQhrCZhY = -1686458776;
    bool vAGgL = true;
    string wvWYdAUuPhR = string("IfTRTygvsMTloqLZVvGpAqLdhRoKffWoQHKyaXWnHsKBChiRtIyuXAnYhXeRZZqOigCsvTacwgmZmRZejEqixMEabDDnDIGkOBsufAkOEFgmAGOquiRXXXLKRCPYJzVjVnjmMsYJhoDRcsudUpvQhRVluynNcUVayzQTPmPxczxzAZKstGETmunhFRkNDEhDhcMfZiAyxXqfYqrwAMnldgDnhHfsePCMse");
    int rcENRbWsoFSz = 173345978;
    string YSATCwDcApz = string("dDnpyCeaOXcLhvclIq");
    bool BqTyfUreQsR = true;
    string fCWghhcPkwbp = string("ZjtTOpdXozvvBugEFDlBoRVvuStQjbOtGrWsFhCsUckZsAORavKCVwjtjAEPHrvQptNpTHulvMenkFcxafEZLmHkuuWRzwshRIrDFTBhmYqqTNRMN");

    for (int mtduPgbPhAqF = 6469187; mtduPgbPhAqF > 0; mtduPgbPhAqF--) {
        continue;
    }

    for (int YrFBEdWmfVCe = 1562517915; YrFBEdWmfVCe > 0; YrFBEdWmfVCe--) {
        gempQhrCZhY += rcENRbWsoFSz;
    }

    for (int CdkVLaR = 1884678682; CdkVLaR > 0; CdkVLaR--) {
        hDLJgvI /= lOZmiwNpVTSv;
        fCWghhcPkwbp += fCWghhcPkwbp;
    }
}

double lJqEBjfmT::MaOzqfnwPUaB(bool VWJpSDy)
{
    bool gbTaW = true;
    string ikwHgXeh = string("bkgYfaigrnybAVOWTTlXfaxqpdlhqocSBQMyUzNgRFoqxBBSaHrUYAermzOhsGQdfWuEmSNqQqdsQTdgdTtgabnIUUoniNdlTAzHCIToueiTb");
    double ZqDsYDVG = 583974.5394339641;
    int flWVvBrFLt = 1048100311;
    double hcXHtQIleEryaIVm = 316304.90712720517;
    string kVFmnTZ = string("hBmcAOqnCozXMEQUgEJNgOcayowOEZKgreVPBVuIMLfMSFQUoJQKPqrjwXhxWTnemwNojjwFoJygIlPcIgTanFccHAmbJqRsXikSwTRwTQSwuMxjQiFzMWIQbXZStvXXkAzZfXqdlSUHXPIenGgOoTKlEYlSQZyrZUpqlHUkcZkPIohJRGFzTRlNCOEPyFROTUgNbwnTQsq");

    if (ZqDsYDVG == 583974.5394339641) {
        for (int XtVTriDlPjFqeV = 849233084; XtVTriDlPjFqeV > 0; XtVTriDlPjFqeV--) {
            ikwHgXeh = kVFmnTZ;
            ikwHgXeh += kVFmnTZ;
            ZqDsYDVG -= ZqDsYDVG;
            VWJpSDy = gbTaW;
        }
    }

    for (int JVqUDhgmqfVPrLuZ = 1099774955; JVqUDhgmqfVPrLuZ > 0; JVqUDhgmqfVPrLuZ--) {
        continue;
    }

    for (int WohtNIGM = 753037264; WohtNIGM > 0; WohtNIGM--) {
        continue;
    }

    if (hcXHtQIleEryaIVm >= 583974.5394339641) {
        for (int HSETVYUCwsBJOt = 581732806; HSETVYUCwsBJOt > 0; HSETVYUCwsBJOt--) {
            kVFmnTZ += kVFmnTZ;
            kVFmnTZ = ikwHgXeh;
        }
    }

    if (ZqDsYDVG <= 583974.5394339641) {
        for (int rPnzKHX = 1217344962; rPnzKHX > 0; rPnzKHX--) {
            continue;
        }
    }

    return hcXHtQIleEryaIVm;
}

bool lJqEBjfmT::MSRUHmceFdGQnj()
{
    int BGEsKOTFRStCbztt = 1591540349;

    if (BGEsKOTFRStCbztt != 1591540349) {
        for (int lblHcinzbUc = 2094713645; lblHcinzbUc > 0; lblHcinzbUc--) {
            BGEsKOTFRStCbztt *= BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt = BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt /= BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt -= BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt -= BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt = BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt += BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt -= BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt = BGEsKOTFRStCbztt;
        }
    }

    if (BGEsKOTFRStCbztt <= 1591540349) {
        for (int vTsqmJMUlgylCNDN = 1215628799; vTsqmJMUlgylCNDN > 0; vTsqmJMUlgylCNDN--) {
            BGEsKOTFRStCbztt = BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt = BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt = BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt *= BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt = BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt += BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt *= BGEsKOTFRStCbztt;
            BGEsKOTFRStCbztt *= BGEsKOTFRStCbztt;
        }
    }

    if (BGEsKOTFRStCbztt >= 1591540349) {
        for (int SjcZpcj = 1331178398; SjcZpcj > 0; SjcZpcj--) {
            BGEsKOTFRStCbztt *= BGEsKOTFRStCbztt;
        }
    }

    return false;
}

string lJqEBjfmT::CiTkgZXX()
{
    double NPPyadWzZsflh = 240180.49352080675;
    int BixkCltLqIiFpp = 917486556;
    int rUobE = 1616302858;
    bool xTInqo = true;
    int KIPPjwjUAvxmTm = -1824761276;

    for (int OYcqPOaDGZka = 550847522; OYcqPOaDGZka > 0; OYcqPOaDGZka--) {
        KIPPjwjUAvxmTm += rUobE;
    }

    for (int WkxwDd = 114912281; WkxwDd > 0; WkxwDd--) {
        rUobE = KIPPjwjUAvxmTm;
        BixkCltLqIiFpp = KIPPjwjUAvxmTm;
        BixkCltLqIiFpp *= rUobE;
    }

    if (KIPPjwjUAvxmTm <= -1824761276) {
        for (int UjLkHhlx = 1269158669; UjLkHhlx > 0; UjLkHhlx--) {
            KIPPjwjUAvxmTm += rUobE;
        }
    }

    return string("xuJaXcWyVpxUQZwdljsfHfQBMZdtqRbQPSCbOSIDolkwEojCpMIAFlWbILBWUsaCPdYweSFOUUIySmQFlrfCyWKdhHoGtuCgtRqYlgJSFFIosclUyypWLNfIHXJUThTkIAkPbQhIyOhEqzbKgqQZEAAhKpclBnYvICyPhkNgiMHYFgfOdvfhUOeNjBcondESUKDlUoFtdApUCMGHowlSLUKjUFc");
}

string lJqEBjfmT::RyjVRqOOeX()
{
    bool cTLGYgEhlwrwpvG = true;
    double uegBVZhyoP = 5298.120469610397;
    bool PvnqgzS = true;
    string mpNNNXSKRzJN = string("RgVrNlySkdBjWinTCCjB");
    bool mzXpIlAhicz = true;

    if (mzXpIlAhicz != true) {
        for (int RgYsy = 988569948; RgYsy > 0; RgYsy--) {
            PvnqgzS = PvnqgzS;
            mzXpIlAhicz = ! mzXpIlAhicz;
            mzXpIlAhicz = ! cTLGYgEhlwrwpvG;
            mzXpIlAhicz = PvnqgzS;
            mpNNNXSKRzJN = mpNNNXSKRzJN;
            uegBVZhyoP += uegBVZhyoP;
        }
    }

    if (PvnqgzS != true) {
        for (int wfAAWdEsnFRqNc = 388296963; wfAAWdEsnFRqNc > 0; wfAAWdEsnFRqNc--) {
            mpNNNXSKRzJN = mpNNNXSKRzJN;
            PvnqgzS = ! cTLGYgEhlwrwpvG;
            cTLGYgEhlwrwpvG = cTLGYgEhlwrwpvG;
            cTLGYgEhlwrwpvG = mzXpIlAhicz;
            cTLGYgEhlwrwpvG = ! PvnqgzS;
        }
    }

    if (cTLGYgEhlwrwpvG == true) {
        for (int YYKrhHqtLb = 1300059948; YYKrhHqtLb > 0; YYKrhHqtLb--) {
            PvnqgzS = mzXpIlAhicz;
            PvnqgzS = cTLGYgEhlwrwpvG;
            uegBVZhyoP -= uegBVZhyoP;
            mzXpIlAhicz = ! PvnqgzS;
            PvnqgzS = cTLGYgEhlwrwpvG;
        }
    }

    for (int TqxhIunutt = 1446093898; TqxhIunutt > 0; TqxhIunutt--) {
        cTLGYgEhlwrwpvG = ! PvnqgzS;
        PvnqgzS = PvnqgzS;
        cTLGYgEhlwrwpvG = ! mzXpIlAhicz;
        mzXpIlAhicz = PvnqgzS;
    }

    for (int uPzYheFPWm = 613308839; uPzYheFPWm > 0; uPzYheFPWm--) {
        mzXpIlAhicz = PvnqgzS;
        mpNNNXSKRzJN += mpNNNXSKRzJN;
    }

    if (cTLGYgEhlwrwpvG == true) {
        for (int eAmRZibyWt = 1473509972; eAmRZibyWt > 0; eAmRZibyWt--) {
            continue;
        }
    }

    return mpNNNXSKRzJN;
}

int lJqEBjfmT::cFVFb(double WOrDHZXZrD)
{
    double FiZcG = -897895.0520888717;
    int TTjvXJqTV = -1724605304;
    int ZrIWroej = 1879774036;
    int cMCooWs = 257173782;
    bool eUkwEITtkJ = true;
    bool dWxxASX = true;
    string ouwMesCTQuxje = string("FLZjZIUPThDMtHzykTPdxlXCQvuaAbOJBUkYMxFIFzmircQXjIopNocABHWmTJVUDjFGBcfWySQWVxvFTiGlxOvOkoiTkbwrLLBFqmxvkmgZPXmlgTmdvIHtpiMgVOCCEutrwzxXlygXXGYxNWLbWzlZAwGsjdlBgxPVfoIxWshWEXlAnELMcEwciyabVynIZFObAujLslItHYmWuTYljNUwVcnEVXKYZxGFuIrTwrkgUdQfGBFdRQUcJMv");

    for (int QGJLFhJ = 776937421; QGJLFhJ > 0; QGJLFhJ--) {
        ouwMesCTQuxje += ouwMesCTQuxje;
        FiZcG /= WOrDHZXZrD;
        cMCooWs *= cMCooWs;
        WOrDHZXZrD /= FiZcG;
        dWxxASX = ! dWxxASX;
    }

    for (int FQGad = 1636435381; FQGad > 0; FQGad--) {
        dWxxASX = ! dWxxASX;
        TTjvXJqTV += cMCooWs;
        ZrIWroej = TTjvXJqTV;
    }

    for (int jfAkGrhqssISW = 844258257; jfAkGrhqssISW > 0; jfAkGrhqssISW--) {
        eUkwEITtkJ = ! eUkwEITtkJ;
        cMCooWs = cMCooWs;
    }

    for (int JecWedqjTvac = 1507147333; JecWedqjTvac > 0; JecWedqjTvac--) {
        FiZcG -= WOrDHZXZrD;
        ZrIWroej *= cMCooWs;
        dWxxASX = dWxxASX;
    }

    return cMCooWs;
}

string lJqEBjfmT::gYIEXcB(double RzyHCCTmLziv)
{
    double UQMqzqriizUnXOe = -953848.4687489665;

    if (UQMqzqriizUnXOe >= -953848.4687489665) {
        for (int qOTgVwce = 1419469756; qOTgVwce > 0; qOTgVwce--) {
            UQMqzqriizUnXOe = RzyHCCTmLziv;
            RzyHCCTmLziv += RzyHCCTmLziv;
            RzyHCCTmLziv = RzyHCCTmLziv;
            UQMqzqriizUnXOe /= UQMqzqriizUnXOe;
        }
    }

    return string("ZYJzvlTEASdDmwFEMBhKWnMVBZcrEyRlwCPxmtEsnfuQYxtXtjnjZgXQRAioLLtKtzkxXTgOuVwQYCdxxkKGZkBraqvscBCNVpjxElMgABxDAsmUDIPlctQJuxoCfozs");
}

int lJqEBjfmT::YXosFBlrqvNbRt(string oheigisLh)
{
    bool rKeDeewRROEyqeo = true;
    double TYPtrSfu = 22559.05412661213;
    double PhMeOEvVjrfruk = 173828.96281672284;
    int vlNFi = 1527828384;
    int zmzpkbgnmYvBZQ = 817799280;
    string ZeQdaoUHuLOOQKak = string("KtFTYVZNunbGlCFoGOeTfKAhYHDeqJlZNnBLBaFNitQnKaoePQSQueOfjETabmqMzxJZSaGeQQgTyXneGKVJojpmTTMpPjnlWrhhieMoxfrnNVsxHCjlTYPPWhLlmOsHtdCNaRsdEzDowZULCoghTBJkmoaWfIIgHcxhvizziK");
    string CieBrKKFNC = string("cgHUElzdUstTFyafMKwkLVDYEOOZJhuyprALMrWlmiCkKKLgBBjlBzxulodYMn");
    string aArhhT = string("GJWMWPHOzcFAiKNeaGMHpZaojADHAgAhIasPEtCZOJbOauEAUKAlTAjIMPhTRsWJVAYzpjbzjfPdIlavZHgxQSuNLCxuRBXIGcFtDNPkCQhwqTNZGuuELIpMGvbWWfDNHgCwgoBNfNPlg");
    int BjyqDsSdYsNx = 958838907;
    bool YSItx = false;

    for (int lnVjv = 211147207; lnVjv > 0; lnVjv--) {
        ZeQdaoUHuLOOQKak = oheigisLh;
        CieBrKKFNC = aArhhT;
        aArhhT = ZeQdaoUHuLOOQKak;
        TYPtrSfu /= TYPtrSfu;
    }

    return BjyqDsSdYsNx;
}

bool lJqEBjfmT::GKFyY(string Cmldp, bool onhozCFNnJEx)
{
    bool MUbLkoz = false;
    double KgpaSskAvqcQpoa = 501716.61465302424;
    bool IXAbfOiuKPzyLW = false;
    double DnsKTAcmwJ = -245139.2509764525;
    string RiPBaI = string("YMEHaGsRzooqCkIFGmeezqHXgoeLhtwgVwXBXTpGbFYuZReNScmYPstHRPOVXZyBivRuTeNDRpOPFpzaWYejeXzZTzhDyOZatJStBgQltIONnXjFXRSDbMlsSNRWRmtyTpgrjZpLHJVCQapvMfpamFPgKTlHfvhttJkYCqfHECRBnCzUHhNFrJTgaVYJvSiPbMCwntZUFVqeRHyuoKKdXLIeokRiiHSGCglRpnlJDlDYJYtWKZRiCHRDa");

    if (RiPBaI > string("YMEHaGsRzooqCkIFGmeezqHXgoeLhtwgVwXBXTpGbFYuZReNScmYPstHRPOVXZyBivRuTeNDRpOPFpzaWYejeXzZTzhDyOZatJStBgQltIONnXjFXRSDbMlsSNRWRmtyTpgrjZpLHJVCQapvMfpamFPgKTlHfvhttJkYCqfHECRBnCzUHhNFrJTgaVYJvSiPbMCwntZUFVqeRHyuoKKdXLIeokRiiHSGCglRpnlJDlDYJYtWKZRiCHRDa")) {
        for (int ThEfsDJQB = 125969953; ThEfsDJQB > 0; ThEfsDJQB--) {
            RiPBaI += RiPBaI;
            onhozCFNnJEx = ! IXAbfOiuKPzyLW;
            RiPBaI += Cmldp;
        }
    }

    if (MUbLkoz != false) {
        for (int ubfceppAjfeOfjf = 1767278551; ubfceppAjfeOfjf > 0; ubfceppAjfeOfjf--) {
            continue;
        }
    }

    if (MUbLkoz == false) {
        for (int fFqGqnEy = 558278219; fFqGqnEy > 0; fFqGqnEy--) {
            MUbLkoz = ! IXAbfOiuKPzyLW;
            IXAbfOiuKPzyLW = MUbLkoz;
            IXAbfOiuKPzyLW = IXAbfOiuKPzyLW;
            onhozCFNnJEx = MUbLkoz;
        }
    }

    for (int GUZMeKcUyQMdyOLv = 509337733; GUZMeKcUyQMdyOLv > 0; GUZMeKcUyQMdyOLv--) {
        DnsKTAcmwJ = DnsKTAcmwJ;
        RiPBaI = RiPBaI;
    }

    if (DnsKTAcmwJ < 501716.61465302424) {
        for (int ItHztFO = 379011674; ItHztFO > 0; ItHztFO--) {
            RiPBaI += Cmldp;
        }
    }

    if (MUbLkoz == false) {
        for (int ImDzD = 796932959; ImDzD > 0; ImDzD--) {
            RiPBaI = Cmldp;
            MUbLkoz = ! IXAbfOiuKPzyLW;
        }
    }

    return IXAbfOiuKPzyLW;
}

string lJqEBjfmT::NEzVb(int vJOIuTBfmfIH, int fwhdD, double LElySxixVaVZ, double xMqjo, double CmvLOYh)
{
    double UehoJBONhRnZObTQ = 25951.72128630803;
    bool yYmauO = true;
    string zvAPMte = string("MHFGdFYeSqXtpnrZqNZgTckidqFYtokDfSGYSkzgHIRcEVhcilhlJwg");
    string BJdzpSExIETrMrs = string("OYnsfwRZFslOXIVMRSimOCICPWQauEQTxnnlIlQWhYAsTBneWohyjdcHbksGtOvKBOVetAgbdGVuDbKruQPnRZStaewXTUMqpYySqOOYwJFbyqbPCZkICrytsFfWbvmopQmQNeOOdzWntJTUlLiadmCMTtAyhlfGJLksEtrSiSRSRNWTRJVpJFRwBsCsAJRMCavQmknVMPFgfT");

    if (UehoJBONhRnZObTQ != -443429.80432731425) {
        for (int IyVnvgS = 1243440067; IyVnvgS > 0; IyVnvgS--) {
            continue;
        }
    }

    if (yYmauO == true) {
        for (int CzZbNImW = 2119368917; CzZbNImW > 0; CzZbNImW--) {
            continue;
        }
    }

    for (int BXHRnAECN = 951766622; BXHRnAECN > 0; BXHRnAECN--) {
        xMqjo += xMqjo;
        UehoJBONhRnZObTQ /= UehoJBONhRnZObTQ;
        zvAPMte = BJdzpSExIETrMrs;
    }

    for (int kDkoPxHAAsDO = 1793085868; kDkoPxHAAsDO > 0; kDkoPxHAAsDO--) {
        BJdzpSExIETrMrs += zvAPMte;
        fwhdD = vJOIuTBfmfIH;
    }

    for (int oxQrkpuUNDYWIhwV = 547297379; oxQrkpuUNDYWIhwV > 0; oxQrkpuUNDYWIhwV--) {
        BJdzpSExIETrMrs += BJdzpSExIETrMrs;
    }

    if (CmvLOYh <= 25951.72128630803) {
        for (int fwjDDz = 764295549; fwjDDz > 0; fwjDDz--) {
            UehoJBONhRnZObTQ *= xMqjo;
            BJdzpSExIETrMrs += BJdzpSExIETrMrs;
        }
    }

    return BJdzpSExIETrMrs;
}

void lJqEBjfmT::ogUmU(int bqOnMaYp, bool oKaTKAeqgc, int mbDNJzxhMIsHpV)
{
    bool DmbHkYjss = true;
    int IHXDa = -1641515028;
    bool CmnWThAIc = true;
    bool XQowjHXnvOwfS = false;
    bool TvgWjO = true;
    bool gPWLbm = false;

    for (int muHunGLvnPTGHRMp = 540873484; muHunGLvnPTGHRMp > 0; muHunGLvnPTGHRMp--) {
        XQowjHXnvOwfS = ! CmnWThAIc;
        CmnWThAIc = gPWLbm;
        mbDNJzxhMIsHpV = bqOnMaYp;
    }

    for (int PhJtUOGnNQMOoKj = 2082128373; PhJtUOGnNQMOoKj > 0; PhJtUOGnNQMOoKj--) {
        CmnWThAIc = ! XQowjHXnvOwfS;
        XQowjHXnvOwfS = XQowjHXnvOwfS;
        CmnWThAIc = oKaTKAeqgc;
        gPWLbm = ! XQowjHXnvOwfS;
        DmbHkYjss = ! oKaTKAeqgc;
    }

    if (IHXDa > 495653449) {
        for (int vGNAPS = 84319718; vGNAPS > 0; vGNAPS--) {
            continue;
        }
    }

    for (int dsqodVKMnwZgJr = 1639862492; dsqodVKMnwZgJr > 0; dsqodVKMnwZgJr--) {
        gPWLbm = ! XQowjHXnvOwfS;
        CmnWThAIc = XQowjHXnvOwfS;
        oKaTKAeqgc = ! oKaTKAeqgc;
        XQowjHXnvOwfS = CmnWThAIc;
    }
}

string lJqEBjfmT::tiuwDGSYGN()
{
    double ZydrLdNLcJ = -538153.57295554;
    int xlblMijuPvGRJP = 71482032;
    int UkMfhl = 1604021430;
    bool fiCZhMbd = true;
    int bcjaaWYBZRqsps = 75500223;
    string pHvZruhdWgoFoeGl = string("XLSamluwjOnIXfFpDhnTmDQiMCmnhwoKgFyeQqXCLJwRvrXrvnOZxbKPCLYVMvmbdMNKYqPYqpDJidfJMbwQBdWMLeQRGYKRKGldxbdMbbOZERpqoiabrpgTlzFtEHDQopcYshVKdILkwtUpcCOpvYZeQnVZXGdvtGaJgIQWAzeVcPczAkcutfnDtJyiFYHehlgYoGMPUMxXJBSobUcBILOvJ");
    double PNPBzYGo = -784319.8429301444;
    string JhOtKEzm = string("JLBoyAMtQfagyIZhUAlgDTskMOsVlMSTQarFCEoAgcNQothywMtVTCtwxuKBoLmJOdMFiqrynEWSKtxKJmfICOafXKIdSGkggcilSAireldtMdkaxTjoCofaW");
    double wUAlDJUMVwK = -992525.5525085717;

    for (int qvpHygiD = 1753551093; qvpHygiD > 0; qvpHygiD--) {
        JhOtKEzm += JhOtKEzm;
    }

    return JhOtKEzm;
}

void lJqEBjfmT::KCTXXxNFXKJH(string pagwNtmHf)
{
    int vZsoBMjylFjSRh = -1252524214;
    double xTsQTzQZh = 1004212.6240451928;
    double owPCEszvjtnD = -313044.81334827957;
    bool seyoxeuOWpTx = true;
    double ZypyquEC = -444898.7667579251;
    int SWkWAsVIx = -1971733817;

    for (int KssQjWpvrkgP = 1852764992; KssQjWpvrkgP > 0; KssQjWpvrkgP--) {
        ZypyquEC /= xTsQTzQZh;
        owPCEszvjtnD *= xTsQTzQZh;
        SWkWAsVIx = vZsoBMjylFjSRh;
    }
}

int lJqEBjfmT::iQqtosXCtwGb(int vAgeTKBdRDQ, double OuQWHfUAglEv, double oGbqPqZopLWCh, string QljozqeBCjC, bool OHcBTA)
{
    int yIXBNu = 1196017082;
    double irQNUiQLSLY = -168595.70768675866;
    int SzDuXtfApzgERtBf = 1498664148;
    double pxwKIQFGwitT = -581913.7082254466;
    double cRXqYynloZ = 795624.307722071;
    int tXReNQYKZVHsUKBH = -149673524;
    bool mXFXZvUxLOM = true;
    string elppBAVsd = string("MWgIxEPtKhvlpTvgRaOCgIawfXEgvIfNxePVyGFUjzohnfrCNQdIzNfOMtgKLarGwmxDiBbVZxEOhZRRlqVfVVHHAsLiKGBEhLIYUunlRrShRNP");
    int WHpHRqTmgOURL = -88529988;
    int lOpmufBIQclgrclD = 1112421617;

    if (OuQWHfUAglEv >= 831727.6704047861) {
        for (int cAoGZmnEkvagjYj = 499479262; cAoGZmnEkvagjYj > 0; cAoGZmnEkvagjYj--) {
            lOpmufBIQclgrclD += vAgeTKBdRDQ;
        }
    }

    return lOpmufBIQclgrclD;
}

bool lJqEBjfmT::IbmlyXI(bool bYpmrWeqYw, int guwMV, bool hddioZND, string KgSHyLVGQ, string PiUTbfaERpGaTps)
{
    bool TVpfnXIDoS = false;
    int vKjFFvgdAM = 1923753277;
    string lARogDEKg = string("DhfNklttHvXUvrgKWNEciXzvbxLkkujipEIRBBKcfqKeIgtzXExZTFEaCQQYIoZDTuqqjmBMjFawgnNeHJVhBjuJmcWUfScpkgkroteNvrngUVnjoLCzYykwXYBlklFcvYoZWwDTnvOjFJlMolWvezzkmJcjXfmGgrPybfYhCsRVTQFBZntkySzYWozZKgEmoAgmCEHiuXMwWFExnDGCbUkBn");
    bool gFIZg = true;
    bool fxWAVtzzGbYcaYap = false;

    if (bYpmrWeqYw != false) {
        for (int hmJFtQzdkRze = 1438016120; hmJFtQzdkRze > 0; hmJFtQzdkRze--) {
            hddioZND = bYpmrWeqYw;
            bYpmrWeqYw = ! fxWAVtzzGbYcaYap;
            bYpmrWeqYw = ! TVpfnXIDoS;
            guwMV -= vKjFFvgdAM;
            PiUTbfaERpGaTps += PiUTbfaERpGaTps;
            fxWAVtzzGbYcaYap = ! bYpmrWeqYw;
        }
    }

    if (fxWAVtzzGbYcaYap != false) {
        for (int LVcJUxyUM = 466308318; LVcJUxyUM > 0; LVcJUxyUM--) {
            bYpmrWeqYw = ! TVpfnXIDoS;
        }
    }

    for (int wRUDTzlbaFlLZfH = 545858058; wRUDTzlbaFlLZfH > 0; wRUDTzlbaFlLZfH--) {
        continue;
    }

    return fxWAVtzzGbYcaYap;
}

int lJqEBjfmT::OlkuLjTprDhYDVuu(string tZRuQkEvdiPbpJe, double dIvqEiJNxVfYv, int AbhAfrxTmaL, double zfKzdO)
{
    bool wWGUpuGsPSOmGdNy = false;
    string ItlAHOgkpszQ = string("KSQEdoeKzfGdZURzvKPFixLwAEkRCpzHhOYlJHAFmAtsHYxiUOUtUSSTKlYkSrIBQjWNOKQoGXkBXhwdZOFDKQuLwnZkUXrgByRcHR");
    bool WlJSsdUUBOqTIYZp = false;
    int GXRHRgOPp = 209449145;
    int qeFxQ = -1306154122;
    bool LLUPijLSDvrb = false;

    for (int CqpbGAAUQlo = 1251776938; CqpbGAAUQlo > 0; CqpbGAAUQlo--) {
        wWGUpuGsPSOmGdNy = ! LLUPijLSDvrb;
        tZRuQkEvdiPbpJe += tZRuQkEvdiPbpJe;
    }

    return qeFxQ;
}

lJqEBjfmT::lJqEBjfmT()
{
    this->hWFiRmrdXgyOx(-243617491, -657802.4342815311, 1666139642);
    this->ddKkuQZfPZH();
    this->gTIDe();
    this->wtqxwNdimbeg(string("NZxbHOn"), true, false, -602162695);
    this->rIPASDEoy(198655.1050994301);
    this->cSVeSnXrTyqdnm(false, -386268.789799905, 652449.8696352971, 18820647);
    this->MaOzqfnwPUaB(true);
    this->MSRUHmceFdGQnj();
    this->CiTkgZXX();
    this->RyjVRqOOeX();
    this->cFVFb(434103.552209766);
    this->gYIEXcB(234043.7420223379);
    this->YXosFBlrqvNbRt(string("zcdmZctgmWjKghBNiiczNSYiPcbCWJHOACpDLkvgkUxSHwMMWnPyKvqYZmRpUemgrnenzNcLKEeESykKqOYNSgzezwDnVAZqtRjSAiZGxGUpNkcDvDpIrSgzhVLkNyXLWRnUuhmJhojlHWXhyupbuMHsIpaAJquQFjZLaIpotnAVmedVObmvfslSymBrnDI"));
    this->GKFyY(string("GOUTbEVyzwljiJwUkdtlhIqvgtWFpMnJhsQqaZHECPbUMAPBUXIorJCpQSUdmilVKfVPSppfloFgFxXbFLWrqAMFifqBiPTyECAZELJshPyKDkXRarne"), false);
    this->NEzVb(-491170287, 202949516, -818682.4305239624, -443429.80432731425, -286999.1937062031);
    this->ogUmU(495653449, false, 2068012509);
    this->tiuwDGSYGN();
    this->KCTXXxNFXKJH(string("sHNpSdQGSzPcijhHXHPwgQMDthpxFgxoYnoDcJSfyzGaolQyWPgXHYISbmIqrsjHejFgDdgygrnLHNYefyTCESPOSDwcxufVXGkXQqMpKBSmrAPigvqmgiXSdOxliaXrlnfaAcGQENLfHberCLnmlARALFdOACItZSuxwiBEqnOKVVJOjkOTEHFzSHejjPYHceMWDDR"));
    this->iQqtosXCtwGb(1555782005, 831727.6704047861, -174280.05752497853, string("lozspIcMgoxmeidlRrahubGJAnFnIXtEHhNDjASi"), false);
    this->IbmlyXI(false, 1790502274, false, string("epnLGyJWSjGiWEbsnMmafDSdRVXkRWGuXYDdrIHbrUoYjngvPKMDbNywLQDhxVKeIqAqsKUQcFBAPWOeXQiUqZNtkNgKiXJmCfvAFQwTQ"), string("bdiGGXlhhKdbjeyBpdGfcWYBLqxnXXipG"));
    this->OlkuLjTprDhYDVuu(string("BnHiqYONIZJwMtiXvMnXxXyFrBPYplSJQfhRhjcxEfBdQxrHhxMnxQhhwvBfoDplZOrYOtEjERgcSpdIOeZUYdcpIxptCRmoCWITRuGxuUDTVMOzFXiKJGwtOrQtPundtVuxOPKbUhZZxinXyUoKULZRPcJpDfODdOkiEchDXrMcRINNXjOXEZrWBDfHOAklrnuSiBAWSJgYjOTbjOQDTynFuOtyQmOryZmU"), -37455.13907045864, -580147748, -474663.9070784603);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eWZWtV
{
public:
    double KpsxAKMyHBOWxOS;

    eWZWtV();
protected:
    int zVqFDJhnELRtNlH;
    int QQzbrcgk;
    string iDjhlJyr;
    string jtAmeVORzMhXyhQ;
    int buTsdVfqNpOyUwU;
    bool EhlVWExjPzMrrB;

    double JOfojvhYSDJ(bool hrffoR, string qlgkDFYnOeXuj);
    bool tTBpoPpFqopKaWpj();
    int fByWy(double tNwaWRufuav, int kEvMrCcFKRMwrm);
    int KyGRYG(string YjtPy, string aVeygwjCWRkNAmM, int wDrffFREDt);
private:
    int ElpSrfDZoxCA;
    double FQuGKtxfssSm;
    string kFFmTJXyU;

};

double eWZWtV::JOfojvhYSDJ(bool hrffoR, string qlgkDFYnOeXuj)
{
    int dwYUHoQhfjfPDLLV = 1601049263;
    int HiQRztwFyAjfk = -485365659;
    int QxyTnFdGBE = -1102755716;
    string GdwhtGdRuy = string("ICIkeVNKwatnxXtnRYpYICfAmkyxpXSCXfmudylkkfFwcxSqjclIzhRJwGKVjlmADpfkvoAmmgTaDtCMBtcxjwtKnkCqNAEzPtulrJwTyspxLWtBLJbHVsVMQMOXvBBGAczACoZJAUDWjqasyeFhtUHapBZQoUOCRiqGINSRoWLkMpRuRZTutrTMfajQpUdpPlhpEqSmeNmFwNpdT");
    double KjCrqajnnC = -994154.9803931509;
    bool lNDRlIYijwMN = true;
    double jNxmTzhYe = 592432.5633944616;
    double cEjSDNttkO = -90560.07921601142;
    bool pBtExFeY = false;

    if (pBtExFeY == true) {
        for (int FrpwjHBid = 296734204; FrpwjHBid > 0; FrpwjHBid--) {
            pBtExFeY = lNDRlIYijwMN;
        }
    }

    for (int gaPXrMmhWjmbSIUY = 2061975912; gaPXrMmhWjmbSIUY > 0; gaPXrMmhWjmbSIUY--) {
        HiQRztwFyAjfk = QxyTnFdGBE;
    }

    return cEjSDNttkO;
}

bool eWZWtV::tTBpoPpFqopKaWpj()
{
    bool uPFuuKt = false;
    string gRGQAgwNs = string("CxqzCkOMaAHSoDKSe");

    for (int RkeADjtmNe = 1865392123; RkeADjtmNe > 0; RkeADjtmNe--) {
        uPFuuKt = ! uPFuuKt;
    }

    if (gRGQAgwNs > string("CxqzCkOMaAHSoDKSe")) {
        for (int NYYeT = 289269283; NYYeT > 0; NYYeT--) {
            continue;
        }
    }

    if (gRGQAgwNs > string("CxqzCkOMaAHSoDKSe")) {
        for (int ZrEhAKSskuoP = 1933032873; ZrEhAKSskuoP > 0; ZrEhAKSskuoP--) {
            gRGQAgwNs += gRGQAgwNs;
            gRGQAgwNs = gRGQAgwNs;
        }
    }

    for (int cHnzbaLQOpTTyr = 2081236302; cHnzbaLQOpTTyr > 0; cHnzbaLQOpTTyr--) {
        uPFuuKt = ! uPFuuKt;
    }

    for (int qtCfrjBT = 914045360; qtCfrjBT > 0; qtCfrjBT--) {
        uPFuuKt = uPFuuKt;
        uPFuuKt = ! uPFuuKt;
    }

    if (gRGQAgwNs < string("CxqzCkOMaAHSoDKSe")) {
        for (int QtVKjTXbASP = 672153060; QtVKjTXbASP > 0; QtVKjTXbASP--) {
            uPFuuKt = ! uPFuuKt;
            uPFuuKt = uPFuuKt;
            gRGQAgwNs = gRGQAgwNs;
            gRGQAgwNs += gRGQAgwNs;
            uPFuuKt = uPFuuKt;
            gRGQAgwNs += gRGQAgwNs;
        }
    }

    return uPFuuKt;
}

int eWZWtV::fByWy(double tNwaWRufuav, int kEvMrCcFKRMwrm)
{
    string jXIfUuGhpwMQTd = string("uvzhkgPLcilUgfd");
    string DgZKXK = string("EpEXGlJfFFfFByQJQNQGKsTJQVjDQVrHHhdyQGGXXYwUzQSTWEDEgJdDqzGXzACtcxSuftWnrptzFomYLnxTsrHyfmhODYenmiEoySVhKPgdSLYBgGcsdbQHGgBiMseZfCqxhHJNjRTsSnnGzBusgOubagWTUGkUuWDgrPNQpVHACmaZxTcToeOLPjpdiRFcfxZmRdCDIhHrnijKKFSulGyvTucWddsNXU");
    bool pbeYBYyDwxBNwJ = true;
    string sfGTUEiQrYr = string("aleYZgeZvCTUvRhzpHnILSJOqXIJXHNbRcLSvgJiKgsLuQCRIMgVLvlsKaGUXqVbAcPjiTylKfhWUdyRZGIHUWVVyVazSSdcmGSSwedCRLuUIvZzKbxdGicqAMJIkESFWKCtxsrnIHvKaLANqnLJoFbckDmxVFvJXaD");
    double ZJvjnORsSKNUVoIQ = -40891.954822844;
    double GivwVPxbCpNcQ = 977093.9050645643;
    string EoCWnR = string("wDoLFyauRgooXJACjMpOpOpaigVdvivzOVkgelloAcXuFmtWwqNyHXvvnYUcrjIjDTZYIsZCLydATKDjXZrpniqgepjylkauvjOtbNF");
    int JMOzysARiSvx = 2140891838;
    int TedXukDK = -305430518;
    bool IklvYunnm = true;

    for (int ZaHbmfxFkRyVDm = 945482041; ZaHbmfxFkRyVDm > 0; ZaHbmfxFkRyVDm--) {
        continue;
    }

    return TedXukDK;
}

int eWZWtV::KyGRYG(string YjtPy, string aVeygwjCWRkNAmM, int wDrffFREDt)
{
    double FJIhXOVpt = 934774.0329382125;
    int YDhSNWOabxYWdsLU = 1052225726;
    int NNAvePHvPSAjNB = -1964775842;
    bool ebHGokQ = false;

    for (int psjGvAjsojrf = 1953079521; psjGvAjsojrf > 0; psjGvAjsojrf--) {
        NNAvePHvPSAjNB -= YDhSNWOabxYWdsLU;
    }

    if (wDrffFREDt >= 1052225726) {
        for (int AgtvMaTmRw = 733714043; AgtvMaTmRw > 0; AgtvMaTmRw--) {
            ebHGokQ = ! ebHGokQ;
        }
    }

    if (wDrffFREDt <= 1052225726) {
        for (int EJiVXOzSq = 447207189; EJiVXOzSq > 0; EJiVXOzSq--) {
            FJIhXOVpt *= FJIhXOVpt;
            YjtPy = aVeygwjCWRkNAmM;
        }
    }

    if (wDrffFREDt > -1964775842) {
        for (int ixlZSclAjI = 905710195; ixlZSclAjI > 0; ixlZSclAjI--) {
            ebHGokQ = ebHGokQ;
            aVeygwjCWRkNAmM = YjtPy;
        }
    }

    for (int fcTJMsgfdsrSFpdG = 246857210; fcTJMsgfdsrSFpdG > 0; fcTJMsgfdsrSFpdG--) {
        aVeygwjCWRkNAmM += aVeygwjCWRkNAmM;
    }

    return NNAvePHvPSAjNB;
}

eWZWtV::eWZWtV()
{
    this->JOfojvhYSDJ(false, string("Yr"));
    this->tTBpoPpFqopKaWpj();
    this->fByWy(817486.8271869607, -1881060016);
    this->KyGRYG(string("oSpHhtqRvDNY"), string("sCCISqjKIgwlOxZveWfEVOAYuxKjPdGCGJqxYONVMKQYuCCRicnauAymwyBmVMEurnPuLrPAlznZVfYVXmCwmrNGBpoQEIAybXOIOIjSzGjWQQiHKndpvjtVhMCfbYvnlQenQbfbOQXgaQEKOAssDqVfTDrAYjfExyeLYzAchhrvQFNTPEJgbFRn"), -98409805);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NLNpc
{
public:
    bool uxQuEx;
    string wySoUWFJHUEM;
    string eXwmApZzsk;
    double UfeyRcuEmsryM;
    string XwGHDVAu;
    double yLCiV;

    NLNpc();
    string gZhbwIN(int gNMaVxsaTJ, double AfecpKm, string NDTzvOIWWaIVo, double FryHdLatbj, int FjkDaPwBg);
    int OIprYbz(double cMRdeSM, int tFOReLzlBov);
    int cvoneQZzFGDs(int GaTLqDZEoHLGWxj, int wRRKhVEfP);
    void GPuHwiQmcTr(int JbpgsEEFhpiVqH, double AoPNUEyVJWv, string vkxmdQReW, bool uqjDyAeSQZiPVru);
protected:
    bool KtGkRPJIIVTvCPfd;
    bool HzTGnlZvyxUfUpO;

    double HQqwKcsWeSQuy(double IkAyqyPs);
    void eEJhmA();
    int amEZwcL();
    bool yHluZsIbWKC(int rmWHlAV, int AwENKZJSWijiUoW, int TcTNOaHMp, double scrnceygIxafL, int jocLeKDLlvJa);
private:
    double OJIzQh;
    double fRPIlSdxpW;

    bool zSZhiXgdAzIu(int clJTQNImrdUg, double BbtmVLhzHfmIKj, int ecAdbPNAmbGwdDuB, bool GzOTccfYDR);
    string ubUYwIFn(bool TekPxZWKptz, double vqlfMRUXhfcRjx, int hNHaAPHdcuqNSo, bool IceCPxLuOWhMzg);
    int psLykXwCuzNsM(bool yonQQTFuCCX, int OvApCLERcx, bool bIPGwlGLvFS);
    void KpCdPAqmibodWBi(bool RYXgzWRPJ, bool MLBfA, string IWETCnnkn, bool ACQZFEaqz);
    void nUhRHztEpVUu(string TpmQEDhF, int mysHmrWVYnyFgsGA, bool blcBBPJIWc, bool rJOjSCgd);
};

string NLNpc::gZhbwIN(int gNMaVxsaTJ, double AfecpKm, string NDTzvOIWWaIVo, double FryHdLatbj, int FjkDaPwBg)
{
    double KYdtKWFmMpnmc = -506910.9466087243;
    string RVLnlgDqV = string("uHcUdhReSoIjsJyEkbelCqUBQhInRIVAhniboHMTDuVbRyeSJrhYtloarKyAUiixslSqNWGOcBaRkMdijbqDlKjRgKGFyRRkABcwTdZrwoZHGjPrAkMMvvcbEmtGDuVVHvQNBrLSlUrbVulTvsCuMpfPFEpTxvLSuBtzsgPSGeDUnrcRfdnPyTwXoVSzNFylcZcxMNGLMxHTvZ");
    string kRJXJgII = string("mFXVVTNMyCUFlEKdAcvEMWWHszWLAWWMqVsizUZeXNHHIoTXVHYTiwGrlhLbennDcktCvjMijpXFZlOYTDviGDfAxMjqEEIYROxmGfqtZjTGkqkFcIuCrbklvNUwp");
    string KcDRODOVmhyBPY = string("dBiKfRsNiQgJjVofjQRklkQBesGYTEdmScvpdsraZbJ");
    double RhmaBQHyrD = 812890.103294299;
    bool bpMil = true;
    int YeuILHZBvz = 460753217;

    for (int SOkVWSa = 344866545; SOkVWSa > 0; SOkVWSa--) {
        continue;
    }

    for (int kwrGXyWPo = 659959478; kwrGXyWPo > 0; kwrGXyWPo--) {
        continue;
    }

    return KcDRODOVmhyBPY;
}

int NLNpc::OIprYbz(double cMRdeSM, int tFOReLzlBov)
{
    double dQniBZPNUONpGP = -789313.3499582586;
    bool oenwFkGV = false;
    double APLvqfkS = -759537.3569765276;
    int oTTclNGQZYzigLF = -336113670;
    string PFUntyXy = string("oilIpZnHQStFNXZGAACoGwGtTryEZiypYbbuAUGoGhBKWIAHCKiSFsRqoDsjjmLTpySfjyvMJUxLEliiBCqsdXDzixMoqixBsrlnHgbhtZrppGxcLBOBUeYGqEoLoWwqrctZHnxCMcgUYSJiDpOvOtkYpLxbiIcIcQVewffzXYOSECsFLYOTkmynvNVueuzSdYZOmFgqBJYcrthJANHYpMNwBKPYQPbDBfiFQDvrhrNzUYZxvvSwnTDLEFa");
    string GihHqFIdhVzow = string("gWntAMHvGNiQOXYfZIeyzfnMQZehskBXNFDChHZfDuJrghOcfhBrxFzPHBKjfoYlFUsVVtNftyfgVkLrLzvUhEaRWEIOsLlRRTfThrAXCLmRzccxTwiunbBwFXhrtJIWNFPZWssuxpJibLSsdpnKInXUwSfW");
    int NgzqmGIAQvWzcMAZ = 1188811460;

    for (int zjgaAyVwXLogUu = 1036140410; zjgaAyVwXLogUu > 0; zjgaAyVwXLogUu--) {
        GihHqFIdhVzow += PFUntyXy;
        tFOReLzlBov = oTTclNGQZYzigLF;
        APLvqfkS *= APLvqfkS;
    }

    return NgzqmGIAQvWzcMAZ;
}

int NLNpc::cvoneQZzFGDs(int GaTLqDZEoHLGWxj, int wRRKhVEfP)
{
    double ccwIxOoJ = 71448.6330944558;
    string hzIVyZu = string("rjpYBzUFiPueDBsMxviiGZIEVwYrkLKLYAKygzALAQYHTZFRDoAUxRjsGbPJqFNDGIoWeoYWnpDLIuqHAmbBfxmxhVLsvYbWTzMVsoDDttyKrEFzTHlZKQJCyrZXMPYYyRiMixutGqqYWzJJnDqvCjZRfBeagIFwofeYbMaAolmnrNmEDv");
    int YRFcGYrYwUbejRtp = -1750892765;
    double YauSLSqMncRlZ = -369716.26673687686;

    if (wRRKhVEfP != -1750892765) {
        for (int eLhoUYtRqEi = 1816459194; eLhoUYtRqEi > 0; eLhoUYtRqEi--) {
            YauSLSqMncRlZ = ccwIxOoJ;
            YRFcGYrYwUbejRtp *= YRFcGYrYwUbejRtp;
            wRRKhVEfP /= GaTLqDZEoHLGWxj;
        }
    }

    return YRFcGYrYwUbejRtp;
}

void NLNpc::GPuHwiQmcTr(int JbpgsEEFhpiVqH, double AoPNUEyVJWv, string vkxmdQReW, bool uqjDyAeSQZiPVru)
{
    double DoaoI = -294863.08417765005;
    bool osvJD = false;
    int YjrSvjgXRtdaJM = 1097048889;
    string viQUqYVWmYTIspqA = string("tfJWvTamwsYGDMmGgNTMHCJrpnRgfFACSTljJqmmzlLzjSEjrAxOaEfCvyHXalmruFozVuXPFOojpURpFnjlUwjUIDmYOgZJZSGXvOUjEGFcrQefJdPNXo");
    double pMKBxCC = 967079.1765357935;
    bool fiQZUYBg = false;
    double fnfPgFXPhiaGJtLe = -888641.029456889;
    int hiRuxrlMK = -1074502370;

    if (DoaoI < 967079.1765357935) {
        for (int htJAybeekfaqJyRS = 557925198; htJAybeekfaqJyRS > 0; htJAybeekfaqJyRS--) {
            fnfPgFXPhiaGJtLe = pMKBxCC;
        }
    }

    for (int ciFktnjoIOoqwPj = 651123638; ciFktnjoIOoqwPj > 0; ciFktnjoIOoqwPj--) {
        continue;
    }
}

double NLNpc::HQqwKcsWeSQuy(double IkAyqyPs)
{
    bool ITupTGobT = true;
    double qcqkxcqiKNrVmXc = -55481.1529383903;
    bool YUnFAIUzsUDUyFb = true;
    double JZixbi = 434325.6147273174;
    string weQUgbbkMJPCkb = string("RqpJTwECgGRurGyukccdtxMfpsWVKuyRxDnQQxwkWbHkyVEjjJyWabZbyUYTbqoRvMNyhwceNLzQVZvNcvvDKBtYsPmOiCPgYqMrKimlh");
    string dYLhVvdNqTks = string("JkjyWboqhTRUrBCurmKAubBCBOaiMTjhMTGlvsxuPfBNgkkcskkBCwwPDhHBdNFkIcvZqkDbZbjyTxzadrkPnyhaJCIyUqomLsIQkVdDcTnLSGdzUwJxAeeprwGYQzKrGJVymkKxviyodRoxwitx");
    string IfKnMMSwYSlPbzoV = string("ezHJeIRMZJLSNWQNlGJIKSgDcPSZEpKkoxXCTUpYnYYKhdEPpqlnbOWbdlRRMJongRtvegsXwGpYwiJnxKYAJvvyKfPhWpdiRCyVptGiIXkhdgdgMEzxchRAfKjslHzfWSdcKSxISz");
    int GRoGzRwLFUDNko = 1874958410;
    double HCtCtsQkELqrO = -252638.5502582128;
    double ciQfwxzB = -1013563.7053366911;

    for (int zwEEG = 175282004; zwEEG > 0; zwEEG--) {
        HCtCtsQkELqrO *= HCtCtsQkELqrO;
        ciQfwxzB = IkAyqyPs;
        qcqkxcqiKNrVmXc += IkAyqyPs;
    }

    for (int FuGykesXRpTWQZ = 1949430871; FuGykesXRpTWQZ > 0; FuGykesXRpTWQZ--) {
        ciQfwxzB -= IkAyqyPs;
    }

    for (int XnuxykILT = 1577387346; XnuxykILT > 0; XnuxykILT--) {
        HCtCtsQkELqrO /= HCtCtsQkELqrO;
    }

    return ciQfwxzB;
}

void NLNpc::eEJhmA()
{
    int LwDYzoGCVt = -2060000367;
    bool gaJpdtR = false;
    bool LcAReKIrDlrZs = true;
    bool SJKjtnVMafsCsv = true;
    string pNfnMQc = string("RSgPYsmqdJfEAjIHkUOoPwboAHGLgyFRyFXSOjwXIGHzqfjqAgdCmdrcYOZCkWnHmnfTMCvQViYRoVOHeNdDptrUFIMcdVgPRaGSHWcWXnAwqFnMRXTBAzbDsZVXvJjOrunisVRbuEkLTasYZcGYUlyEBHgxJNczgGPtkEppFJTwYKZViLIegTORKvKiXIEyIyCXZMZuzLyQbjWxAdeGLFAFfy");
    string uamykNzQthZCZ = string("wMDLJNWXjcSdBkRBtRvTAwrQZlIqPKRNSicPfiOMVDJtvBcQPGeuaMQIkdqDKAkVTNAMfGbjYbUrXePJxUYioCXkozVjBQVxDSsivlDpYoyAZpaxrQkMxWHMzWklcIsAaUqFzjPK");
    bool JniVFoDgH = true;
    double bFdevxpdPAhArQpp = -571097.9855032138;

    if (gaJpdtR == true) {
        for (int ulvfpNdkWZveoHNr = 2104191607; ulvfpNdkWZveoHNr > 0; ulvfpNdkWZveoHNr--) {
            SJKjtnVMafsCsv = ! gaJpdtR;
            uamykNzQthZCZ = pNfnMQc;
            uamykNzQthZCZ = uamykNzQthZCZ;
        }
    }

    if (SJKjtnVMafsCsv == true) {
        for (int YQKLoSRl = 698185575; YQKLoSRl > 0; YQKLoSRl--) {
            continue;
        }
    }

    if (SJKjtnVMafsCsv == false) {
        for (int hWUBMwGgeK = 2053882913; hWUBMwGgeK > 0; hWUBMwGgeK--) {
            gaJpdtR = JniVFoDgH;
            SJKjtnVMafsCsv = ! LcAReKIrDlrZs;
        }
    }
}

int NLNpc::amEZwcL()
{
    bool ZNwkTUSZIccZPxgU = false;
    bool sGcenvEFvZwGt = false;
    int ByzicQkBmer = 1304745351;
    bool tDnLpAdp = true;
    double TLGrxaoFjJ = -1011798.3368696544;
    string DueNFFvSnkwVhf = string("AVgYXhzkAVRdVzzzsTjOHOjFALNRkjzOVxGXRsIZZwIKCQBSLEMQDFlLdSqbnjWqBsCAkCLHKxzZwxNDQUdvCfGAbbBOtjElOQPJHtXDFDthoethtSSTuUxTYudPAjgPYXhiqCIAQIYnVxrShwjDfWgHpQMqEHCsKKkQVqDvTydQzQyzlkwbgTHWjPfYQGzCzfvsEwSCnwcFpgZOvLlVVbNbbSghqlLMTkSraZjXtdkNEPmikkjd");

    for (int wDkAf = 905020959; wDkAf > 0; wDkAf--) {
        ZNwkTUSZIccZPxgU = ! sGcenvEFvZwGt;
        ZNwkTUSZIccZPxgU = ! ZNwkTUSZIccZPxgU;
    }

    return ByzicQkBmer;
}

bool NLNpc::yHluZsIbWKC(int rmWHlAV, int AwENKZJSWijiUoW, int TcTNOaHMp, double scrnceygIxafL, int jocLeKDLlvJa)
{
    string zFxIckNYsB = string("yqoRFQnnDMIFBQFmUpdvrpmDfUXdBAtrmhiYUMkQuvYFfcyCmLYgnQXgaGlLeQLBrWwpYcISCpwOznjLhbpgAuyDnjXxmhyGrNcreORNymPmuEIehMDtjGAuDPPrhUyHEgPBxgiAPqRZPOLVhkMhckoVDJDRRMTSFPXNMqqvYZLxEifAqzKiAttmVAuXptvuLlChBVbThhvzGsVjVkCSaf");
    double BlagdlP = -268304.8331976756;
    string rJtVhcVoXAgl = string("EgNXJkMpiyWXmlZjpCBkeGhfVlRQFOrJnxqUzSbPWRFHlCvYlEBKVTKnYqjtwZVXswzXpGZkyVISuerUtwrNlGQpVyOssBoMpygfLfPpufoYTiZhFeSdZJOzZmuxmRTPeXlToRVI");
    double wLcZakj = -287438.6482359043;
    bool jguYFEKZvtIDMFl = true;
    int gQutvmdlshLpZCF = -25204872;
    double gRfigdaoqYGc = -568865.7235536784;
    string UjmbqAIPOkXMmBpo = string("lQYqLSTWjMLwAjxweTcwdMOECWLvxRKFNgoVERwWLJZJrxrPrXatXrCYxRxNSWqwIdkaJSfAGOAXwAzFcHJoLmvvoudykIIrkossnJGLFbqG");
    string lKyGHkZdJixSMZk = string("zXrinPhtojRDFBIOqiTMWLUXlmPFKiRWGnWWsmNyDzeAnJrMWFMUZjUzoRkRvPsOKWkDSPMOlWRYDZdzloucJEnmGqdnsGKbsCbWxktunSOVwiWARevbnKlqbjFiBbzEHfiqhwFDXOggZOXcZstPmmAxDHNlgCHLPbhjjeaHxGiPiYwrDOKvNaKOIwESirpiKIxeUEKqZsvgEjQULjiUjbIx");

    for (int SDdxNlFE = 2099501491; SDdxNlFE > 0; SDdxNlFE--) {
        zFxIckNYsB = UjmbqAIPOkXMmBpo;
        TcTNOaHMp = gQutvmdlshLpZCF;
    }

    return jguYFEKZvtIDMFl;
}

bool NLNpc::zSZhiXgdAzIu(int clJTQNImrdUg, double BbtmVLhzHfmIKj, int ecAdbPNAmbGwdDuB, bool GzOTccfYDR)
{
    string tTKLIbh = string("NRlQuqkkPBUchilvGyjTbCLXNoyljPbtxIQgrxGFZEKTxvGCwKyYseREfUebkNKPjFJXKlVJWZPtsBAqDcLUAUMVkasdCJheFYSPSfpwPymxtpDrXiLFkJMHAASnIzYmKUrmBQVN");
    string BIZrSlr = string("IpaGEiaNmTvqzHSjJjSGirsAkQPjaIqWfWVWGRZxEbLfaqaFYgtS");
    double qZEwKShEuvZzhVC = 930041.0270879167;
    string QBccMmfJkXFpeOP = string("BUSTIdgUkXRuoRhutROTdNTpDtdTzBOMqbjYfzBTjZZbYyoUTGUBjIQQKcdWCEDdnjxHpvSQOtxCDFbJonjlbWxtdwKBPWbfZpDFkPejKIalsHhcVmzfEsMEoWovwhmRr");
    int wpvEUlYgGZ = 1904521226;
    int bWCQLJjyMnFxcG = -1444607945;
    double WJvVbp = 1010122.8307074038;
    string ofwksO = string("WcWyfYszdsAxsPEXBhmDOsMDvtpdxchRENHjVhcLtKeMQPXjfmHmCGqpkhkFQNAqJnfLVLhJauxDkU");

    for (int JBaZGKyaGI = 1930407976; JBaZGKyaGI > 0; JBaZGKyaGI--) {
        continue;
    }

    for (int SEegOCNoNkuuKIbh = 1758029126; SEegOCNoNkuuKIbh > 0; SEegOCNoNkuuKIbh--) {
        clJTQNImrdUg += clJTQNImrdUg;
        tTKLIbh = BIZrSlr;
    }

    for (int lDhqMLZTS = 303920282; lDhqMLZTS > 0; lDhqMLZTS--) {
        tTKLIbh += ofwksO;
    }

    for (int ujQDjzm = 2061624309; ujQDjzm > 0; ujQDjzm--) {
        ofwksO += BIZrSlr;
        wpvEUlYgGZ += bWCQLJjyMnFxcG;
    }

    return GzOTccfYDR;
}

string NLNpc::ubUYwIFn(bool TekPxZWKptz, double vqlfMRUXhfcRjx, int hNHaAPHdcuqNSo, bool IceCPxLuOWhMzg)
{
    double NAbmQwRnMdi = 421895.92350041383;
    bool uPSjRgXx = true;
    double jBPbtCToAgGK = -277441.9926529006;

    for (int yoyFERVTu = 735995802; yoyFERVTu > 0; yoyFERVTu--) {
        TekPxZWKptz = ! IceCPxLuOWhMzg;
        jBPbtCToAgGK /= jBPbtCToAgGK;
        uPSjRgXx = ! IceCPxLuOWhMzg;
        NAbmQwRnMdi = vqlfMRUXhfcRjx;
    }

    return string("PTGtVnvYIRMkXmGxqBUbwuwFsNbnrBjcoOwaARGBjlFUoXYWjjjUyluGSuIvfwJtiLMOEQPPiUQbilgLbbXYtiVsPqyHrkSeDKmfatQtuYjZBjyXlMsbWwunCQpyueuMVvllhbdjWEPhEzrtKimjJsLNoLQkMcnRnzWLDhGPUQpevyKPPJebgACJ");
}

int NLNpc::psLykXwCuzNsM(bool yonQQTFuCCX, int OvApCLERcx, bool bIPGwlGLvFS)
{
    double mnSaOicpIkzLsvGo = -810796.8511579182;
    int VjyhqMyG = 114750749;
    int AOygasiQmX = 990431170;

    if (OvApCLERcx > 990431170) {
        for (int EkjnDOwHBalbsa = 762825686; EkjnDOwHBalbsa > 0; EkjnDOwHBalbsa--) {
            AOygasiQmX += OvApCLERcx;
            OvApCLERcx *= AOygasiQmX;
            yonQQTFuCCX = bIPGwlGLvFS;
            bIPGwlGLvFS = ! bIPGwlGLvFS;
        }
    }

    if (VjyhqMyG > -2070243368) {
        for (int ptfbVvvd = 1043590648; ptfbVvvd > 0; ptfbVvvd--) {
            continue;
        }
    }

    for (int gJxmbjpomGK = 1779862787; gJxmbjpomGK > 0; gJxmbjpomGK--) {
        continue;
    }

    for (int ldlDosxFaIZvAqF = 390147076; ldlDosxFaIZvAqF > 0; ldlDosxFaIZvAqF--) {
        AOygasiQmX -= VjyhqMyG;
        VjyhqMyG += AOygasiQmX;
    }

    for (int VRFdisS = 1690050946; VRFdisS > 0; VRFdisS--) {
        OvApCLERcx = AOygasiQmX;
    }

    return AOygasiQmX;
}

void NLNpc::KpCdPAqmibodWBi(bool RYXgzWRPJ, bool MLBfA, string IWETCnnkn, bool ACQZFEaqz)
{
    bool msiumJpNPo = false;
    int wqWoVGBaNFhw = -16119053;
    double vNgRbnVx = -508246.8428682734;

    for (int ZRjpShfLWHl = 1931324720; ZRjpShfLWHl > 0; ZRjpShfLWHl--) {
        msiumJpNPo = ! msiumJpNPo;
    }

    for (int MeBVYAy = 743027083; MeBVYAy > 0; MeBVYAy--) {
        RYXgzWRPJ = ! RYXgzWRPJ;
        IWETCnnkn += IWETCnnkn;
    }

    for (int SVNsUcnkdD = 507925807; SVNsUcnkdD > 0; SVNsUcnkdD--) {
        ACQZFEaqz = ! msiumJpNPo;
        MLBfA = ACQZFEaqz;
        msiumJpNPo = ! RYXgzWRPJ;
    }

    if (msiumJpNPo != false) {
        for (int BKiGhpZIwe = 1688703003; BKiGhpZIwe > 0; BKiGhpZIwe--) {
            RYXgzWRPJ = ! RYXgzWRPJ;
            MLBfA = ! ACQZFEaqz;
            msiumJpNPo = ! RYXgzWRPJ;
            ACQZFEaqz = MLBfA;
        }
    }

    if (MLBfA != false) {
        for (int zuJgoLQig = 913566524; zuJgoLQig > 0; zuJgoLQig--) {
            continue;
        }
    }
}

void NLNpc::nUhRHztEpVUu(string TpmQEDhF, int mysHmrWVYnyFgsGA, bool blcBBPJIWc, bool rJOjSCgd)
{
    int FZLBrQCNDHkpeoZR = -603398117;
    int MbNoktQOThDYiF = 534868998;

    for (int XLfpxImJrCb = 1880877581; XLfpxImJrCb > 0; XLfpxImJrCb--) {
        FZLBrQCNDHkpeoZR = FZLBrQCNDHkpeoZR;
        MbNoktQOThDYiF *= MbNoktQOThDYiF;
        mysHmrWVYnyFgsGA += mysHmrWVYnyFgsGA;
    }

    if (mysHmrWVYnyFgsGA >= -603398117) {
        for (int payhAlvrjyGil = 717729781; payhAlvrjyGil > 0; payhAlvrjyGil--) {
            rJOjSCgd = rJOjSCgd;
            rJOjSCgd = rJOjSCgd;
            rJOjSCgd = ! blcBBPJIWc;
            MbNoktQOThDYiF = FZLBrQCNDHkpeoZR;
        }
    }

    if (MbNoktQOThDYiF >= -1119681504) {
        for (int vdJnBANpO = 1563015404; vdJnBANpO > 0; vdJnBANpO--) {
            FZLBrQCNDHkpeoZR += mysHmrWVYnyFgsGA;
        }
    }

    for (int ffEqNcdPtu = 856777724; ffEqNcdPtu > 0; ffEqNcdPtu--) {
        FZLBrQCNDHkpeoZR *= mysHmrWVYnyFgsGA;
        mysHmrWVYnyFgsGA -= FZLBrQCNDHkpeoZR;
        rJOjSCgd = rJOjSCgd;
        FZLBrQCNDHkpeoZR += FZLBrQCNDHkpeoZR;
        MbNoktQOThDYiF /= FZLBrQCNDHkpeoZR;
    }

    for (int ylCsEHgFwHkCeQcg = 1626368151; ylCsEHgFwHkCeQcg > 0; ylCsEHgFwHkCeQcg--) {
        mysHmrWVYnyFgsGA *= mysHmrWVYnyFgsGA;
        TpmQEDhF += TpmQEDhF;
        FZLBrQCNDHkpeoZR = mysHmrWVYnyFgsGA;
        rJOjSCgd = ! rJOjSCgd;
        FZLBrQCNDHkpeoZR -= mysHmrWVYnyFgsGA;
    }
}

NLNpc::NLNpc()
{
    this->gZhbwIN(1320595375, -77215.34905619035, string("AUjEClBoLSCajjxnIVEPsMAGcTzwWjubohUPViUPYkwMBsRJCZBnFIshNWTwbiRCunRrzrkipdivPMVcaBJewtrarUwyDqDwZLXysotFVdginjLSzzSWlCzLOiTfeJhAFYFMCBIuNpyUSsnkbXnrZ"), -963407.255541384, 1645112162);
    this->OIprYbz(-382208.2564726956, -665051822);
    this->cvoneQZzFGDs(-1412821235, -1871101713);
    this->GPuHwiQmcTr(2679266, -42444.953245735865, string("dZAuHtVhzbcxnfSKfzEmyqeJnQeRLCyoMVrxsOvimlZDzFmAHpyaTGnHrcPskknqBCkLECisezCPKwbsgZDtdzSPuKKIUBtLGUfocxTRXzBfLHCPGBnAUtgUYLIszSWSDgBgYjtLrfYUqlrxjCPqGrbkYz"), false);
    this->HQqwKcsWeSQuy(-1038356.2520271904);
    this->eEJhmA();
    this->amEZwcL();
    this->yHluZsIbWKC(998394875, 878632209, 551454210, 690806.5568112817, -1607036341);
    this->zSZhiXgdAzIu(2015808223, 402262.96621887514, -485277133, false);
    this->ubUYwIFn(true, -369592.02950328257, 1962469418, false);
    this->psLykXwCuzNsM(false, -2070243368, true);
    this->KpCdPAqmibodWBi(true, false, string("FgvtoDfZbdeoZZYSDmKbeUdwnyLdunrWlOFXynbgaokfxRGgnfcHtwJIqOIbBTRKtaTzJtJzmqSkBoxxDVhiLyDvEcXDEkvZdhwIpyuCSpxVfmBzpOboVqTfKwMLS"), true);
    this->nUhRHztEpVUu(string("BGdcMzFQXYlazxfzw"), -1119681504, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xJNFnhqUQET
{
public:
    int dwIsQXMkOHJW;
    string AHeKEFne;

    xJNFnhqUQET();
    bool heBELKcfKoE(int wRqdtVcQidZij);
    string lkgqJGBdUMNaqLDP(string lKiqmRumRTjiPi, double facgqarYLlxEhX);
    double WsWtgFPasyTZB(string UoRLEGXl, int iCpdFlWBcrFqTUOM, bool djvTJqnwff, int Kygvkf);
    void KbTuaRUWA(int EUbRJ, int uEJcRMOXXILCTWc);
    int CeZFhpWYqDrDg(string VTTKyrOGJdpNwyi);
    int ASNWOBIwP();
protected:
    double gFazHmg;
    string NOBxBQKsGQaZAXwX;
    double kiKBNEKT;
    int MgxstcEc;
    string NQSIWNGstVXWVN;

    double RvvukvjciZF(bool EIQaGyBsTjr);
private:
    double OSLQxxWUmR;
    double hunFlQbq;
    int DNRUHsQ;
    double HDygXXBibjTrAh;
    string NRvmJJLbzqBi;

    string NqXkEFPurg();
    double WziIIcRBSqDnaL(string anUpnEHiWmuHpP);
    string ZtlOPTg(double KjgTAVWiVy, double uzfpocgxTxZe);
    double qzEmE(double vwpvGVOfQqm, int wXgqZPgM, double GmzKiB, string iCYvF);
    void iQJKLpsmKgoI(double EFeNGVnKCveKnRxw, double DcamRKurtbzIGsH, string EgEgyEPdiv, double IhmFb);
    void rPNutdEK();
    void RHQhIaJNEKd(int Ypdkxo);
    bool DFlOPNsvnLMPp(int rZbuSKqnOrMZI);
};

bool xJNFnhqUQET::heBELKcfKoE(int wRqdtVcQidZij)
{
    double uttlqvPBeSCk = 304371.4408070724;
    bool fVuStXmSZPyDR = false;
    bool xkzlpSkl = false;
    string FiGFiEMBythWtqy = string("EHxVVoLFMrpKNasORCJQrQvaSzwwgcypfJWiihHpbQBEaZWWFLhNKdewtFNxJcFWDqgiitXplDFMqpKnELTOPEIsOgwbdYWOMgXSThFyoNplENrOZCiKfYQFjRLkFEkuBhZctzoCOLvOlsnEkXppeiPQFWWQiuOXBphoOOZake");
    bool iOAluNsfuJFTc = false;
    string CyeNXXmov = string("FQxTLGnMdXgdOzuaUkQSmbJCWFAFQHjxeOWpTmnyjeiKdXjUEWhZAyYmkCqvaQHmz");
    bool gBgEiMHlyD = false;
    string hlqaFHs = string("DrkOHBZFQNaCpzXRYGISnyHjDABYktgRudDNhxBEqiTiouLflDKYBzXKPzkNRyFZvBHrgs");
    bool aSxLGKJd = true;

    for (int jhfDtNveDybniEsu = 411917610; jhfDtNveDybniEsu > 0; jhfDtNveDybniEsu--) {
        FiGFiEMBythWtqy = CyeNXXmov;
    }

    if (gBgEiMHlyD != false) {
        for (int dlnabCAxf = 1780436067; dlnabCAxf > 0; dlnabCAxf--) {
            iOAluNsfuJFTc = gBgEiMHlyD;
            hlqaFHs = hlqaFHs;
            FiGFiEMBythWtqy = CyeNXXmov;
        }
    }

    return aSxLGKJd;
}

string xJNFnhqUQET::lkgqJGBdUMNaqLDP(string lKiqmRumRTjiPi, double facgqarYLlxEhX)
{
    int WFQOSyGSPh = -2019193719;

    for (int WrwahcaSJEJIlm = 229312610; WrwahcaSJEJIlm > 0; WrwahcaSJEJIlm--) {
        facgqarYLlxEhX *= facgqarYLlxEhX;
        lKiqmRumRTjiPi += lKiqmRumRTjiPi;
        lKiqmRumRTjiPi = lKiqmRumRTjiPi;
    }

    for (int xfgimoKujX = 1374890714; xfgimoKujX > 0; xfgimoKujX--) {
        WFQOSyGSPh /= WFQOSyGSPh;
        WFQOSyGSPh += WFQOSyGSPh;
    }

    for (int JeIADDVlnEbJ = 523464517; JeIADDVlnEbJ > 0; JeIADDVlnEbJ--) {
        WFQOSyGSPh -= WFQOSyGSPh;
        facgqarYLlxEhX /= facgqarYLlxEhX;
        lKiqmRumRTjiPi += lKiqmRumRTjiPi;
    }

    for (int OgOQTgljEncOEWUR = 1344377153; OgOQTgljEncOEWUR > 0; OgOQTgljEncOEWUR--) {
        facgqarYLlxEhX -= facgqarYLlxEhX;
    }

    if (lKiqmRumRTjiPi != string("aeGCmICDtmTsISiypUvEVfUUKLiYTinPnInBtnnuXzZlnYzOZtosARyDGDYfsmOJ")) {
        for (int nBywdzyykYFkBF = 1976415274; nBywdzyykYFkBF > 0; nBywdzyykYFkBF--) {
            continue;
        }
    }

    if (lKiqmRumRTjiPi > string("aeGCmICDtmTsISiypUvEVfUUKLiYTinPnInBtnnuXzZlnYzOZtosARyDGDYfsmOJ")) {
        for (int YTEXyzexlNTfEBcA = 1696298581; YTEXyzexlNTfEBcA > 0; YTEXyzexlNTfEBcA--) {
            facgqarYLlxEhX /= facgqarYLlxEhX;
            WFQOSyGSPh = WFQOSyGSPh;
            facgqarYLlxEhX = facgqarYLlxEhX;
        }
    }

    return lKiqmRumRTjiPi;
}

double xJNFnhqUQET::WsWtgFPasyTZB(string UoRLEGXl, int iCpdFlWBcrFqTUOM, bool djvTJqnwff, int Kygvkf)
{
    double QYstzLI = -638764.145007425;
    int uuSFkKatFtmxuRC = 394492030;
    double XZUPYyNnSR = 539552.0471585209;
    double RdrFOkMzQCkpjXS = -738021.3214325574;
    string jtLwVaDWzmcck = string("VpqkvxdxjhfGHnJLXacnDsNMpRlZKBoGJhNAWCMWgEiQAVesaCDfYsckFANtchpaOaLHbIhbekPVeUHBmgRrTACpWGcNRFKrkWiRcOscEYhfkGdTwyQCNNOStSflzrGFakgzYIScuTJaeuGRwjgQhNuamfYRSqJTcBJoiJthpkYEzUADQFLywq");
    double QCbczJiMALv = 333924.4923879932;

    for (int ZEnFK = 1269914748; ZEnFK > 0; ZEnFK--) {
        iCpdFlWBcrFqTUOM -= iCpdFlWBcrFqTUOM;
    }

    return QCbczJiMALv;
}

void xJNFnhqUQET::KbTuaRUWA(int EUbRJ, int uEJcRMOXXILCTWc)
{
    double oUuCHoDA = -27905.435847370318;
    double gTveXqYFdQ = -39943.176022292166;
    bool hYzCWliQGHm = true;
    int qadDk = 1839688786;

    if (EUbRJ != 197401122) {
        for (int XvmiGrFVBYj = 1462097572; XvmiGrFVBYj > 0; XvmiGrFVBYj--) {
            qadDk *= qadDk;
            oUuCHoDA /= oUuCHoDA;
            oUuCHoDA *= gTveXqYFdQ;
        }
    }

    for (int mVFJp = 1443719912; mVFJp > 0; mVFJp--) {
        uEJcRMOXXILCTWc += EUbRJ;
    }

    if (qadDk != 197401122) {
        for (int AyRdGhWpTtrvpa = 1708415247; AyRdGhWpTtrvpa > 0; AyRdGhWpTtrvpa--) {
            continue;
        }
    }

    for (int cPXQCqYqDOoYcn = 950204510; cPXQCqYqDOoYcn > 0; cPXQCqYqDOoYcn--) {
        qadDk -= qadDk;
        EUbRJ /= uEJcRMOXXILCTWc;
        gTveXqYFdQ += gTveXqYFdQ;
        EUbRJ /= EUbRJ;
    }

    for (int UtXnNv = 1312186733; UtXnNv > 0; UtXnNv--) {
        continue;
    }
}

int xJNFnhqUQET::CeZFhpWYqDrDg(string VTTKyrOGJdpNwyi)
{
    bool aFebDQduP = false;
    bool wjNCcc = false;
    double yGcsfkqjNOITxe = 378249.27713350405;
    double gyQqSvaNPvSg = 652239.4168983619;

    for (int NwoDMNXTj = 1298668067; NwoDMNXTj > 0; NwoDMNXTj--) {
        yGcsfkqjNOITxe /= gyQqSvaNPvSg;
    }

    if (wjNCcc == false) {
        for (int UoLFxvVAL = 1532553624; UoLFxvVAL > 0; UoLFxvVAL--) {
            aFebDQduP = ! wjNCcc;
        }
    }

    return -696180429;
}

int xJNFnhqUQET::ASNWOBIwP()
{
    bool tXXerxhfzYEQxCdC = false;
    int dEIzTvMfxxfEfPhK = 1069950107;
    string xUYJVXEeFR = string("zeuXQtccAADYnClCPloTHqCXXOMebxGpdcgiAnbwDGqXYlsDwVcgWWRPRSptkADcuweBIEGtoRZkheEgvV");
    double UdmvnH = 438618.7340219351;
    string QqRLH = string("hABZnUZoBbWgutAxBLDycTin");
    bool QpxLkASzEOJJpWb = false;

    for (int tncZVt = 1666587359; tncZVt > 0; tncZVt--) {
        dEIzTvMfxxfEfPhK += dEIzTvMfxxfEfPhK;
        QpxLkASzEOJJpWb = ! tXXerxhfzYEQxCdC;
        QqRLH += xUYJVXEeFR;
    }

    return dEIzTvMfxxfEfPhK;
}

double xJNFnhqUQET::RvvukvjciZF(bool EIQaGyBsTjr)
{
    string RQRQa = string("WrYaueRwkFUtxOfAyhXFnSvMgguKLKLBzkpQZuHiaEfVXqxhxgUwGCViOCpjPQltmtgNOo");
    string HwbpznwB = string("npKlyYKRzWprYYPCnRIuikyJpSBmGduniAyeJqBDoTrkwuDjHVIFmUuibNvNuApHtRSOYIyIShszwSIiQIxWsWMk");

    if (RQRQa != string("npKlyYKRzWprYYPCnRIuikyJpSBmGduniAyeJqBDoTrkwuDjHVIFmUuibNvNuApHtRSOYIyIShszwSIiQIxWsWMk")) {
        for (int rjFDFP = 2069562229; rjFDFP > 0; rjFDFP--) {
            RQRQa += HwbpznwB;
            HwbpznwB = HwbpznwB;
            HwbpznwB += HwbpznwB;
            RQRQa += HwbpznwB;
        }
    }

    return 736075.101671778;
}

string xJNFnhqUQET::NqXkEFPurg()
{
    string hXCjyncvP = string("klXOJYHsTHziCHGuQkvkMXCdtmZGVLWKZyViEYgCONXcXRKcDTabfTxwGzzSAZmnwsdsGxpKdLZNVAtjwsuoHNxrUHCHWt");
    int LgmHyVXCtVIy = -1186922415;
    int RdoaInvbK = -1695912239;

    for (int NvPccXv = 1823257333; NvPccXv > 0; NvPccXv--) {
        LgmHyVXCtVIy *= LgmHyVXCtVIy;
        hXCjyncvP += hXCjyncvP;
    }

    if (LgmHyVXCtVIy > -1695912239) {
        for (int wcfrgxgTXyLkOu = 920182348; wcfrgxgTXyLkOu > 0; wcfrgxgTXyLkOu--) {
            LgmHyVXCtVIy *= RdoaInvbK;
        }
    }

    return hXCjyncvP;
}

double xJNFnhqUQET::WziIIcRBSqDnaL(string anUpnEHiWmuHpP)
{
    string jAosSwGjLdLQebyS = string("iQfnPLFCcoCTCKavEhgAIJUnHPqtmrxGEsyjJZOwpxmvOuPjypfxLyEhZYIhGDyOAcHBNxIYSSwXtBHuDkkF");
    int hENGHUGKu = 893957148;
    string OIWYByoaHpsiRsL = string("jDJVvRaPClvePQJodhbhXubMmWdKxuTXYOXvUMd");
    string cfLOuIL = string("KxLnUaqpqwu");
    double OzIfjiqTje = -649703.9456804587;
    string oJfrW = string("hIHIoYretVVhpwxpyHVxsuWgKhWcqfYnfIeOAtjrBTUZZwVUHncwhTUrwWZLPiiflXSEUHlfsNvEPXxWGAyifFXvjAmNfUeKHVrrkVgZNdKUMPVSPLVZtVBFKSohIdgRHeaUdLouWiJXYkEjFOBmrgiSDjKhRcmZhRrTUhbbWXVZDCzlMRI");
    double zlwBEcmrE = 655142.5629733546;

    if (anUpnEHiWmuHpP >= string("hIHIoYretVVhpwxpyHVxsuWgKhWcqfYnfIeOAtjrBTUZZwVUHncwhTUrwWZLPiiflXSEUHlfsNvEPXxWGAyifFXvjAmNfUeKHVrrkVgZNdKUMPVSPLVZtVBFKSohIdgRHeaUdLouWiJXYkEjFOBmrgiSDjKhRcmZhRrTUhbbWXVZDCzlMRI")) {
        for (int eeMsHYSmc = 1843177885; eeMsHYSmc > 0; eeMsHYSmc--) {
            OzIfjiqTje -= zlwBEcmrE;
        }
    }

    for (int SRwfQirAhZVv = 1481194936; SRwfQirAhZVv > 0; SRwfQirAhZVv--) {
        cfLOuIL = jAosSwGjLdLQebyS;
        anUpnEHiWmuHpP = cfLOuIL;
    }

    if (oJfrW <= string("jDJVvRaPClvePQJodhbhXubMmWdKxuTXYOXvUMd")) {
        for (int PWrokd = 643173; PWrokd > 0; PWrokd--) {
            jAosSwGjLdLQebyS += OIWYByoaHpsiRsL;
            cfLOuIL += cfLOuIL;
            oJfrW = anUpnEHiWmuHpP;
        }
    }

    return zlwBEcmrE;
}

string xJNFnhqUQET::ZtlOPTg(double KjgTAVWiVy, double uzfpocgxTxZe)
{
    string RJCledJHTPmF = string("wstQmIiOHbcWMcTbXiUGBlRrnuojSjCSVMrygqWJmTXHqyUGMEhtmilonhzFKiy");
    double NqkcJbLxUpxPGWZN = 699512.989661223;

    for (int mvsnyMKwe = 1615732569; mvsnyMKwe > 0; mvsnyMKwe--) {
        KjgTAVWiVy *= uzfpocgxTxZe;
        NqkcJbLxUpxPGWZN = uzfpocgxTxZe;
        NqkcJbLxUpxPGWZN += uzfpocgxTxZe;
        KjgTAVWiVy = NqkcJbLxUpxPGWZN;
    }

    return RJCledJHTPmF;
}

double xJNFnhqUQET::qzEmE(double vwpvGVOfQqm, int wXgqZPgM, double GmzKiB, string iCYvF)
{
    bool OGsmltw = true;
    string CnjJgdLfwtZlp = string("jXKwiWIZGNCQQUMNLOmwbcGnGUumMgyjOxciqVAJikepUqIQyPGJmaPCYXjoUGGcRNnktCMfpIbJirKUFJwqeGQiQQjhOcMXZUUXrctfrdiTAidkYnayAKmGPbRkFPfwNKHghGMfAgcnwUwzqLdyOwHSAcOZPHUuXQlbbISitnsEHKLhdvdJjinmMQhCAccrzaGvXoptQhBpQqHaxFDkAKDEyGBMxGIdkNVTQkgvZJMDYDSzUbGD");
    bool FTPCNEty = false;
    string HCVnFxxVUkzvoH = string("R");
    int OfWRuoWwGnzw = -1287502207;
    double DMOzPpVjL = -967442.9480493192;
    string yqYnLJftHar = string("RJscsmtPFRyOkmBUQNtkSaLYOShjZGwTUikRZjxvEcXQeDelJxcWOGNtDHaFDHziEnaoAsDJdDGjRjgVJwixpvFdofWYVPBxJsQMDeOpGwmruXFCgIWQtCEPBtlPFRTvDEpolTpftsXuPmuGrQXjRXzpCCNiPioAoDgqEXhpUXuvVLvNhkKnmlSXbMXgzpJxKoMXTvyfaWfUiBfCuMCizAWOsZTEbjoKZtd");

    return DMOzPpVjL;
}

void xJNFnhqUQET::iQJKLpsmKgoI(double EFeNGVnKCveKnRxw, double DcamRKurtbzIGsH, string EgEgyEPdiv, double IhmFb)
{
    double cbzKKDfnNDhYoAc = 451644.1282399272;
    int nYqFiAwMvgGCXv = 1977027244;
    int pStMOHRCCwuZKe = 117017246;
    double dKDLuxYSYKwL = -800177.6683064704;
    bool TvACOqWBAFNOru = false;
    string aIWkI = string("pSovArFiWdlhJSbtjWFATGJJEpdsQJzSxHtabyYfjoCnkdEERcEAXeGiKUaeeesOBZPtoySVCiJheLXujJymxfPrszGfGYqQPOoNEJTixlnkCkWEcRMSkTNSepEcUho");
    int drduzKvqFRBPV = 1242640081;
    double uMulWwbTKpcuoRO = 303786.72434032377;

    for (int WsDTsEGLg = 1979996799; WsDTsEGLg > 0; WsDTsEGLg--) {
        DcamRKurtbzIGsH -= dKDLuxYSYKwL;
    }

    for (int kIKUSQ = 156388892; kIKUSQ > 0; kIKUSQ--) {
        uMulWwbTKpcuoRO = IhmFb;
    }

    if (IhmFb >= 303786.72434032377) {
        for (int FOqTwNrMBEEICXK = 1119088785; FOqTwNrMBEEICXK > 0; FOqTwNrMBEEICXK--) {
            IhmFb /= EFeNGVnKCveKnRxw;
        }
    }

    for (int xllFHpRGITkS = 673100197; xllFHpRGITkS > 0; xllFHpRGITkS--) {
        drduzKvqFRBPV *= pStMOHRCCwuZKe;
    }

    for (int TCxfboleI = 2061825483; TCxfboleI > 0; TCxfboleI--) {
        continue;
    }
}

void xJNFnhqUQET::rPNutdEK()
{
    int vJRrLY = -1859351745;
    string fGMOdXncNvpCbG = string("SyOhykTDnnnIzoKWPPpJQdSIZRSpMteztNKIfZSTpzLYKFzaaPHYgDvgTcAwtxAdNMnrxYomLUyVRmzelNoLKOnSXVmNLiOsfvAadsaunCYOOCNpVBKgyTYBwDcRpUUUNERPzNvyJbcGwCcUNgPJBhguTFLKZSejqMPMRcFHgoERZmqahbgCuajxcWXRZXHITUZiYRJNvtjgZ");
    string xSLNGydt = string("RKxbyHnVcPlGEikVtstCaisdWdxfBaPLnUeQkxyGEzIKQJbIPkYuDsxjltmcFjdSmEhLEyRVLLRNFLSyxufYHQrWeJqEXvddYqjnZFKaakWAwISllOZkFZRIXBzjOpNsIVikFHVBJAvtS");
    string RyGCnz = string("mkATvgtWBDVvEdfYDRcAJcfHHVLXirGYlpywDqsegGdfijIisZwlWshkoDUtzBGuAJJaVgTyyQJuBujYeyNndSKaUAHRFGcJNEDfwnPuQRTNfYCReJsMaAGkKFbUxQbcaEbiNYuTyiiNXLFuuREHqZjFXNqIHIMqJWapKoCwdXBDtThIxhlEBoiQmNYGbmGOIXsHY");
    int QCtvxmoknpBgM = 1620767912;
    bool bDCCMPGKXmxhtH = false;
}

void xJNFnhqUQET::RHQhIaJNEKd(int Ypdkxo)
{
    int JcRQzPg = 637257805;
    int FdOkovj = 48936767;
    double rwQZxvdjaV = 937887.4661915785;
    bool LeRRxilQ = false;

    for (int ccPpiGW = 897741684; ccPpiGW > 0; ccPpiGW--) {
        Ypdkxo /= JcRQzPg;
        LeRRxilQ = LeRRxilQ;
        Ypdkxo = Ypdkxo;
    }

    if (rwQZxvdjaV > 937887.4661915785) {
        for (int EtsChTznRwo = 1841379011; EtsChTznRwo > 0; EtsChTznRwo--) {
            FdOkovj *= JcRQzPg;
        }
    }

    if (Ypdkxo > 637257805) {
        for (int jlqveOAtZzEZw = 190464623; jlqveOAtZzEZw > 0; jlqveOAtZzEZw--) {
            continue;
        }
    }

    if (Ypdkxo != 637257805) {
        for (int OXxFVkXiaQUlj = 485888540; OXxFVkXiaQUlj > 0; OXxFVkXiaQUlj--) {
            Ypdkxo -= JcRQzPg;
            FdOkovj -= JcRQzPg;
            FdOkovj += JcRQzPg;
        }
    }

    for (int fUcKyDIn = 1399243201; fUcKyDIn > 0; fUcKyDIn--) {
        FdOkovj -= JcRQzPg;
    }
}

bool xJNFnhqUQET::DFlOPNsvnLMPp(int rZbuSKqnOrMZI)
{
    string CwvMqKtEYpv = string("JdOAHuUOtwGLOcFhkrJQwDDBzImDHlhfjqrfmMyxkwIPJztIfETLllrbSIMtUqXYMbUbhchDyhHmZQnt");
    bool lXHcMLDTzmqmt = false;
    string GqqdUR = string("QdhfXTdSyQDXdVvRxktcpUkzvkzyyClqPXqdDbAi");
    string LRAkVdYdYXeURnYf = string("YvDiOcBTTMDdmpYIYYPzBTrgNPafWtoGcwpKOOaaQiMOjbKFWfCsCDLXehlCDJH");
    int qKvqKPhUP = 1362936536;
    string SFZGkyCtxZsRG = string("hmBCeNycxOMgMGxBlvflOeumybLQlVLJWsqyRaAchYhjUEHgbrDSJOTRovdWHkIExmjhOXAISfpqfOSLtSPCQLRfgAUupnforEATwRDOECJszUgdYuAzKimKaXRoJDDUWYiHOsROvTvKfouINZPRZnZmDjXAcsTRYxnYXWkdtAManWsLWkXXpAdSSnziacshNfwybAMietfZsgcmYZLEYbyeIQbLl");
    string dWvFTFCVFgJmfMqZ = string("RLqKWZhcenduKIrrUdtmBvMjmWAUSqJXetoalCbDzfXOsibctGxhoPkubAYIEoqyKtzggJnXJRiGiMZCMRCoXbPROPfdgpFEhngoBnhyYfYrmIOwlSAiXtWFIqGKycQqntmylIyro");
    bool bHMEEw = true;
    bool fgecZZqCL = true;
    double AglzAvxqayIZUTnQ = 27910.087423323715;

    if (CwvMqKtEYpv < string("hmBCeNycxOMgMGxBlvflOeumybLQlVLJWsqyRaAchYhjUEHgbrDSJOTRovdWHkIExmjhOXAISfpqfOSLtSPCQLRfgAUupnforEATwRDOECJszUgdYuAzKimKaXRoJDDUWYiHOsROvTvKfouINZPRZnZmDjXAcsTRYxnYXWkdtAManWsLWkXXpAdSSnziacshNfwybAMietfZsgcmYZLEYbyeIQbLl")) {
        for (int lFAdAnIcFFt = 832065140; lFAdAnIcFFt > 0; lFAdAnIcFFt--) {
            SFZGkyCtxZsRG += GqqdUR;
            LRAkVdYdYXeURnYf = GqqdUR;
            CwvMqKtEYpv = LRAkVdYdYXeURnYf;
        }
    }

    for (int AidxX = 2133758154; AidxX > 0; AidxX--) {
        SFZGkyCtxZsRG += dWvFTFCVFgJmfMqZ;
        dWvFTFCVFgJmfMqZ = dWvFTFCVFgJmfMqZ;
    }

    for (int vstnmtzKuhPuN = 471017099; vstnmtzKuhPuN > 0; vstnmtzKuhPuN--) {
        CwvMqKtEYpv += CwvMqKtEYpv;
    }

    for (int dbqpfVOutevlRPDs = 1089107216; dbqpfVOutevlRPDs > 0; dbqpfVOutevlRPDs--) {
        continue;
    }

    for (int okxElADoftNTvW = 84011446; okxElADoftNTvW > 0; okxElADoftNTvW--) {
        fgecZZqCL = ! bHMEEw;
    }

    return fgecZZqCL;
}

xJNFnhqUQET::xJNFnhqUQET()
{
    this->heBELKcfKoE(-164810733);
    this->lkgqJGBdUMNaqLDP(string("aeGCmICDtmTsISiypUvEVfUUKLiYTinPnInBtnnuXzZlnYzOZtosARyDGDYfsmOJ"), 521100.4590783029);
    this->WsWtgFPasyTZB(string("lVUOlEEXLlOFMcxWlQQWaztQxKgosfDMzmZkLPDtdUZIUneZyJQSiQnwQdAMkXwTUoLqYNkmQMjaHbLebUmfsmeOEGkCrzzleIoNRrrMyffcSxYXBqOFFTpnnJhXoBuBSTLKuylUMBgavLPaVeBeVnDdyqsBTSavZabVsuzSsZTVezGpQWqIzJTZeqLqwcFEMBGtttlMqJkEQyLPASomJpZuUjyhEn"), -382056977, true, -2113429392);
    this->KbTuaRUWA(197401122, 589213300);
    this->CeZFhpWYqDrDg(string("VVvdDAfMwnyJfRcKVAkAxCikBSHmlPGmRWUBNrrqBzvdIIsLkfxFCvzrVEaHxAXiyLHzkeyNvtLhJHESPabJcUFOzxFBJUhhbLoDyCSCuRVrUTOsoKnzSoWjQQZWCjlYJPNdCZljRubpsrRHgDdZiqlhoWoaGINjqRcHNsZLQrDkCjhuanpZmPGhEFnHAYBzztAqC"));
    this->ASNWOBIwP();
    this->RvvukvjciZF(false);
    this->NqXkEFPurg();
    this->WziIIcRBSqDnaL(string("EWDmEvWdNkjwypyKAbfIlwQecMnLmVbByzARCyUzvPAGUdHBLuSUajIvPPzYoKwHpkhCJCxUuiUDAXxZiEouhQSGdeioBxalOMBEZrTlaifMNOweolYQblpyFYLpVuyyjRivcXuIgXbRuIeckXvXPqwUDKNUaNQtDiiXzSVlQmNluIC"));
    this->ZtlOPTg(895736.5416944214, -969490.3341733521);
    this->qzEmE(20058.325232753046, 1652266300, 354287.5465464763, string("LzruRJjtsonHxgFGWlWTEvDPPHvMIOKfIzByUjZOqVQJPQTIVbPMEaYvzSTGTsEohPXmKkCJUhphRSbqsCudLSKKFTdxtSceyPanBjRgBTvFhyiYLqLRExyGFVbpmybBMTxGtzVmUFzfCwpSmHctnRApxkgMOCBPZNCyRSjLjvxxDVynDjDSpvFxsgoepluijraKCAUZyUUtFvRZYtTPOmbhbYDYXSDanPUHhcLnMoktQAHiZylvR"));
    this->iQJKLpsmKgoI(302657.33079745254, -547536.5568403845, string("YPmjrtCnbXETyCBqUSIWGMrArpiJYVrSCufcvtuzZJMbzkvDekpDXiisUAgidQbqVeBfeyPEQXYpXkfiAtyXVDXMJruMclxwFpUWVOLGKHQEsukVaYVQSmqrCxTINKjAmfdcZICwqRLHXlnjZgyDAJOhkhAAmmZEVrmmEaMpoSTaxBXgBVxxqgERnfCbFPQZufLBQPdHJNycmYqWmgpd"), -416776.9952958201);
    this->rPNutdEK();
    this->RHQhIaJNEKd(-1643256462);
    this->DFlOPNsvnLMPp(-1544923448);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tnMuoMT
{
public:
    bool rWIDfzgWdudnrEx;
    bool ZuXeB;
    bool xxCFd;
    string akPYOJeXBJuFLa;
    bool xrmttNAnLnYzI;
    int awpRBkfutIadqsnn;

    tnMuoMT();
    bool Qmanv(string ZDbDJLKqngZEdMd, int CXSzqTHiydZ, bool MPVArzLBcqFbRiRJ, int GJYuET, string szVmIaRiPIvBk);
    string KEdHDbOatwSOmh();
    bool KqnVQ(double NeKmYdEGYfAVHx, double rajEkmVPnmYY, int zytReToa, string sqzLbhL);
    bool EKBfveAkcNzSn(bool AxQmrwRDGOXthuk, int WhnHQgY, bool SQnIhWVWwKv, int BftFtBxqMADbm);
    double uDiMSNYjhSR(string uDoJi);
protected:
    int uDllwGwTcE;
    int XayCqMmwX;
    bool WiHmb;

    string jboQkUuCKbXxdw(string arJZOIBMZVCJpPTw, int rNJNLkmw);
private:
    string xxIFYdfo;
    double GRlstrdhOjxe;
    string kjSQzKxOajVxof;
    bool SNFWVqjb;
    bool JvvAbgoyeVCk;
    bool pxMEdNRigEtXw;

    void HLMJgHyio(bool FVkPC, bool WekTrG);
};

bool tnMuoMT::Qmanv(string ZDbDJLKqngZEdMd, int CXSzqTHiydZ, bool MPVArzLBcqFbRiRJ, int GJYuET, string szVmIaRiPIvBk)
{
    string iwGvYlWFEDWRXpwY = string("wLHETYCcPsbbCwNrzqGTcRpQMIvDJzGIQvpDoijtVbCUurqyRCVBvkxoxEMFxAyZBQgmJEuWoQYtFyjyHzBZQzyXtvJZulmXRxgqxUrTzqckqpN");
    string PMCRvd = string("YqJEvNwGMnIkriTOiecxOEmkiutcOYNonFDSXrIzZuRXUcDjcBFoqwYWrGKXmJpNivgspFZwetbsUnondMBydpDcAbaAYBOeTLwouCMhqawjGzhrugsUpGpwgMpZhtZkIRqSijHBRQRkugBfcGBBTQHdrnqLLzXzoYNa");
    bool VRoow = false;
    bool XVsXzgxsMYKoaSg = false;
    double cgdIYo = -626456.439183813;
    int ByEnw = 569764395;
    double UcjiNPduNsnt = -585886.0068571229;
    double DwYCoILrO = 188.59130203532015;
    string VqTvgA = string("lewBjXtXclvuFtUmSSHpHtZPRECvqISNRFkFPnmoFGCXOgDAdVbavxARLqHpkZlUJGR");

    if (iwGvYlWFEDWRXpwY > string("xprNWOpolqWqejTnyzavgccIZCYuyXJrWgqYCmXKzlVdwcYgGcBJRtDJeiUERrYqfGpMnkWCdMiVBPTcHZr")) {
        for (int nKlFIIyducmfhrU = 2125060018; nKlFIIyducmfhrU > 0; nKlFIIyducmfhrU--) {
            ZDbDJLKqngZEdMd = iwGvYlWFEDWRXpwY;
        }
    }

    if (PMCRvd <= string("sZVjvvKYFnawmTOhCxYYbTOETnIQhpUQTsDFRtThiYhUFEdXDfLkAQdoTBcmNtzApzENqLWRgsvHN")) {
        for (int OtSCMNpkikOPZ = 1399325841; OtSCMNpkikOPZ > 0; OtSCMNpkikOPZ--) {
            iwGvYlWFEDWRXpwY = ZDbDJLKqngZEdMd;
            iwGvYlWFEDWRXpwY += iwGvYlWFEDWRXpwY;
        }
    }

    for (int vddUEzUzq = 860977377; vddUEzUzq > 0; vddUEzUzq--) {
        CXSzqTHiydZ -= ByEnw;
        ByEnw += ByEnw;
    }

    for (int cuOiRWaAeKtEWUm = 1826951880; cuOiRWaAeKtEWUm > 0; cuOiRWaAeKtEWUm--) {
        szVmIaRiPIvBk += iwGvYlWFEDWRXpwY;
    }

    for (int cpmYyq = 1258079095; cpmYyq > 0; cpmYyq--) {
        UcjiNPduNsnt += UcjiNPduNsnt;
        ByEnw += GJYuET;
        GJYuET *= CXSzqTHiydZ;
    }

    return XVsXzgxsMYKoaSg;
}

string tnMuoMT::KEdHDbOatwSOmh()
{
    string UoTcWgqrfIEHps = string("UtZieVGHeyLmfptafrVUQlhWMAoofMhBnZlrfTfgQvCdbkJZWkzIWIrPrRQSczuFdyLvzPQstAXczmbCejsWfYaBgwTCOvMAcxkoCEpiAMzuKTAseWEnRMepfMJXRiBWJrLgMDEOWYtMqnZIMZSDmmZRkFMAAKFNzZZcbMnDpaqtrPnCbFcTpBHZihoBubvRecMnFNSUhLEjqjFZCAoWYRqQTTyMevRZDYXmAPLiNCeXhYybVFpebPOfBi");
    string PkoPqh = string("OSdpPEajjoTNyRszIxaGJAzwbHirEGEbkDgwlrzyZZCZorQXFHmdZuInuoHHPaTrYUpzJyuDKIGYfZtBZLVcRbBNYRbLiKMUudzGbkMfaeMEEQLmpZmMxtyffoHjdOhJLkNDPYPdEgACpfsxwwTnywTPdMzUWChtuSMyLOKDrDVVOAqsgIzwokbmkyrfiwkFCqsYASnOlfZlmMEztgbxAFUrwgHdJoVSkVJgrWrKYZfRMTmeCU");
    double OJFELAyUzNXybR = -776627.6517535357;
    string ZdQesZtz = string("jEsMkhIyHDbmPqYg");
    bool KQxXpsJ = false;
    int ADzhjBRFrxIocib = 2132482637;

    for (int XQRvS = 850256928; XQRvS > 0; XQRvS--) {
        ZdQesZtz = PkoPqh;
        UoTcWgqrfIEHps = PkoPqh;
        ZdQesZtz = UoTcWgqrfIEHps;
    }

    for (int TeaViN = 962590922; TeaViN > 0; TeaViN--) {
        ADzhjBRFrxIocib /= ADzhjBRFrxIocib;
        UoTcWgqrfIEHps += ZdQesZtz;
    }

    return ZdQesZtz;
}

bool tnMuoMT::KqnVQ(double NeKmYdEGYfAVHx, double rajEkmVPnmYY, int zytReToa, string sqzLbhL)
{
    int kJpUNXrD = -335154713;

    for (int omZXUvUC = 147972090; omZXUvUC > 0; omZXUvUC--) {
        zytReToa += zytReToa;
        kJpUNXrD -= zytReToa;
    }

    for (int AnsIeq = 673447712; AnsIeq > 0; AnsIeq--) {
        NeKmYdEGYfAVHx = rajEkmVPnmYY;
        rajEkmVPnmYY -= rajEkmVPnmYY;
    }

    for (int WmWrpGsMETkqf = 1849864578; WmWrpGsMETkqf > 0; WmWrpGsMETkqf--) {
        continue;
    }

    if (kJpUNXrD > 1109260596) {
        for (int mvVEa = 1400580748; mvVEa > 0; mvVEa--) {
            continue;
        }
    }

    return true;
}

bool tnMuoMT::EKBfveAkcNzSn(bool AxQmrwRDGOXthuk, int WhnHQgY, bool SQnIhWVWwKv, int BftFtBxqMADbm)
{
    int TAmFoAPDeupsI = -899417226;
    string rBUPea = string("zvDHUYgLkj");
    bool UozhJAoJjnCoEjKZ = true;
    string bEbOWTRaFlHp = string("kHdWsBdycNfecSYybVyGSKIXnFTtgrBmiIerUJzBUkBhuWvXAqkWMYjHbvlcYBrLbiiLpnDqxhQoaUvgBxlSZPnvCiyPeDKdGvetaUJSGcZCthMYygZQOFkaHrbdYgooiwnArwXXEfmeIcolTcVQKruAePdEqCCtKdkKN");
    double IBSzXFtwk = 859539.5496416398;
    double eIcBmrrJzocQhjkJ = -1006905.5547986627;
    string rxJYzOvvKLb = string("avbSPzOLSVovbvmBHmaXbEQGirdYLrdJMsPbTUyxCZEz");
    bool iEiwyZLQFTGX = true;
    double YbQfzTupLQufURnv = -437193.0858896364;
    double LNzVWHbvCMvM = -1019006.1869982762;

    for (int wTgNvPaVwMehrn = 2101496108; wTgNvPaVwMehrn > 0; wTgNvPaVwMehrn--) {
        continue;
    }

    for (int VqCBehgJSMtDEag = 570803135; VqCBehgJSMtDEag > 0; VqCBehgJSMtDEag--) {
        continue;
    }

    for (int qPXTrfNtayqxi = 1732363193; qPXTrfNtayqxi > 0; qPXTrfNtayqxi--) {
        UozhJAoJjnCoEjKZ = ! AxQmrwRDGOXthuk;
        rBUPea += bEbOWTRaFlHp;
        IBSzXFtwk -= eIcBmrrJzocQhjkJ;
    }

    for (int XVoDcad = 1855709263; XVoDcad > 0; XVoDcad--) {
        WhnHQgY += BftFtBxqMADbm;
    }

    return iEiwyZLQFTGX;
}

double tnMuoMT::uDiMSNYjhSR(string uDoJi)
{
    int NowHVnURkEMh = -317719853;
    double GotkVEJ = -3247.3131892080287;

    for (int ESAGT = 1329481111; ESAGT > 0; ESAGT--) {
        NowHVnURkEMh *= NowHVnURkEMh;
        NowHVnURkEMh /= NowHVnURkEMh;
        GotkVEJ -= GotkVEJ;
    }

    for (int TPCljtBXBfhfJsm = 1314921160; TPCljtBXBfhfJsm > 0; TPCljtBXBfhfJsm--) {
        continue;
    }

    if (GotkVEJ < -3247.3131892080287) {
        for (int LtuXboe = 95684971; LtuXboe > 0; LtuXboe--) {
            continue;
        }
    }

    for (int aJlagPFxHTKwzDRP = 1275248135; aJlagPFxHTKwzDRP > 0; aJlagPFxHTKwzDRP--) {
        GotkVEJ *= GotkVEJ;
    }

    for (int BYzZt = 99110447; BYzZt > 0; BYzZt--) {
        NowHVnURkEMh -= NowHVnURkEMh;
    }

    for (int HbcpEuTDn = 104440510; HbcpEuTDn > 0; HbcpEuTDn--) {
        NowHVnURkEMh = NowHVnURkEMh;
        uDoJi = uDoJi;
        GotkVEJ *= GotkVEJ;
        NowHVnURkEMh *= NowHVnURkEMh;
    }

    return GotkVEJ;
}

string tnMuoMT::jboQkUuCKbXxdw(string arJZOIBMZVCJpPTw, int rNJNLkmw)
{
    int xaEtJEkokoLR = -1475872725;
    double CEFJifxXZRrnMcs = -204196.2516445308;
    int RggfpMnoGBGlPFvZ = -803157714;
    bool lgNRgXtmhTLYIdRT = false;
    double HqBuEFtKsiDy = -969483.5241548605;
    bool OiZujdHjYPqWYPJa = true;
    double AfqKLWpjDdVJ = -995172.1744158288;
    int PdpWKSGBXDbE = -1770774139;
    bool XxvNVjja = false;

    for (int fDZpqEMkMy = 1744740333; fDZpqEMkMy > 0; fDZpqEMkMy--) {
        AfqKLWpjDdVJ -= HqBuEFtKsiDy;
        PdpWKSGBXDbE /= rNJNLkmw;
    }

    if (rNJNLkmw < -803157714) {
        for (int mpPgl = 583876405; mpPgl > 0; mpPgl--) {
            XxvNVjja = ! OiZujdHjYPqWYPJa;
        }
    }

    if (PdpWKSGBXDbE == -1475872725) {
        for (int WulYOkg = 896682067; WulYOkg > 0; WulYOkg--) {
            continue;
        }
    }

    return arJZOIBMZVCJpPTw;
}

void tnMuoMT::HLMJgHyio(bool FVkPC, bool WekTrG)
{
    string TZCnUev = string("iMGgrRbQuxxedGNdBIbcZNOJwbS");
    int QxgayPOEdRokNaKk = -2065541068;
    int OzRLLYQHIAeuX = -1933112135;
    int kVrqkyfUATgOOR = -1498805949;
    string msJlNjBi = string("EntDasTEzDehWgIXMYROwsYsJQsixutRqYjRNDEcjEfCBkbSCwkYurzJAMAahXgGDYjQLSatkRUbvyRDXLhreBAZdRxnHiyzgmLbgicdxsKnJgKcvDXpSZrhgFmdarpDtpeAmTGhtREdDTAZSnffjLUlWZB");
    string moHePQT = string("SOakEOrmVJdrPqlaxAsToEtProNhkXylrYHmsKroTvLfymgvTvRYyGEwFHVuECSUHsTwJhTVejmSiLMQDJpHPPQRgAmTyJKyokMbWeYpimpNBCWqNCpMCKYSBg");

    if (QxgayPOEdRokNaKk < -2065541068) {
        for (int oKCQtXAJ = 1079243431; oKCQtXAJ > 0; oKCQtXAJ--) {
            kVrqkyfUATgOOR -= QxgayPOEdRokNaKk;
            TZCnUev += TZCnUev;
            QxgayPOEdRokNaKk += QxgayPOEdRokNaKk;
        }
    }
}

tnMuoMT::tnMuoMT()
{
    this->Qmanv(string("xprNWOpolqWqejTnyzavgccIZCYuyXJrWgqYCmXKzlVdwcYgGcBJRtDJeiUERrYqfGpMnkWCdMiVBPTcHZr"), 1698919262, true, -1725197335, string("sZVjvvKYFnawmTOhCxYYbTOETnIQhpUQTsDFRtThiYhUFEdXDfLkAQdoTBcmNtzApzENqLWRgsvHN"));
    this->KEdHDbOatwSOmh();
    this->KqnVQ(-677483.4660880627, -314308.97855207213, 1109260596, string("CNZGowGGUSNAMggVnltPkHzQjthMGAISXstLZZrcfULhPEfMqHSuOgMEBLBfCPYviADWcSTYcAkvBbhWgSLAwVVJGIlFifxxHqGtwtzXlpQiZzvAniIjmkQxwRUWujluRzdGhnaKINDepCPykXGSFuKCeYhodcnAdwojWMEwCIElxAPjLKBUOUTkIOypzSCOihDyfBbxFI"));
    this->EKBfveAkcNzSn(true, 2093890953, false, -1182211232);
    this->uDiMSNYjhSR(string("fkLpFHvPBAZbyYbLrzFbZQdyqFqfRALQQOILrGoPTWzSaCNubcGxZriFAOBCRNVJQqdiLdWMbPEadzvqSqAclfByVMonnbvseqwxidJeRsMoxcFsRIEukgrRGSDVZxpKZXKnVFltuxpdP"));
    this->jboQkUuCKbXxdw(string("vhdfdMziZgbUjMWtdpkZOFgLkirzeROYziJarlCEjohIAwtmUSqSRSWHgNcyTaGYktdyGCTInXzikpiiKXMebAxNLicREeGSDYKjgoWxVOOBzIavexhMYsJHbmXVsFD"), 880350700);
    this->HLMJgHyio(false, false);
}
