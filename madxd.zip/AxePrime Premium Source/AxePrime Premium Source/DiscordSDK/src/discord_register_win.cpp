#include "../include/discord_rpc.h"
#include "../include/discord_register.h"

#define WIN32_LEAN_AND_MEAN
#define NOMCX
#define NOSERVICE
#define NOIME
#include <windows.h>
#include <psapi.h>
#include <cstdio>

/**
 * Updated fixes for MinGW and WinXP
 * This block is written the way it does not involve changing the rest of the code
 * Checked to be compiling
 * 1) strsafe.h belongs to Windows SDK and cannot be added to MinGW
 * #include guarded, functions redirected to <string.h> substitutes
 * 2) RegSetKeyValueW and LSTATUS are not declared in <winreg.h>
 * The entire function is rewritten
 */
#ifdef __MINGW32__
#include <wchar.h>
/// strsafe.h fixes
static HRESULT StringCbPrintfW(LPWSTR pszDest, size_t cbDest, LPCWSTR pszFormat, ...)
{
    HRESULT ret;
    va_list va;
    va_start(va, pszFormat);
    cbDest /= 2; // Size is divided by 2 to convert from bytes to wide characters - causes segfault
                 // othervise
    ret = vsnwprintf(pszDest, cbDest, pszFormat, va);
    pszDest[cbDest - 1] = 0; // Terminate the string in case a buffer overflow; -1 will be returned
    va_end(va);
    return ret;
}
#else
#include <cwchar>
#include <strsafe.h>
#endif // __MINGW32__

/// winreg.h fixes
#ifndef LSTATUS
#define LSTATUS LONG
#endif
#ifdef RegSetKeyValueW
#undefine RegSetKeyValueW
#endif
#define RegSetKeyValueW regset
static LSTATUS regset(HKEY hkey,
                      LPCWSTR subkey,
                      LPCWSTR name,
                      DWORD type,
                      const void* data,
                      DWORD len)
{
    HKEY htkey = hkey, hsubkey = nullptr;
    LSTATUS ret;
    if (subkey && subkey[0]) {
        if ((ret = RegCreateKeyExW(hkey, subkey, 0, 0, 0, KEY_ALL_ACCESS, 0, &hsubkey, 0)) !=
            ERROR_SUCCESS)
            return ret;
        htkey = hsubkey;
    }
    ret = RegSetValueExW(htkey, name, 0, type, (const BYTE*)data, len);
    if (hsubkey && hsubkey != hkey)
        RegCloseKey(hsubkey);
    return ret;
}

static void Discord_RegisterW(const wchar_t* applicationId, const wchar_t* command)
{
    // https://msdn.microsoft.com/en-us/library/aa767914(v=vs.85).aspx
    // we want to register games so we can run them as discord-<appid>://
    // Update the HKEY_CURRENT_USER, because it doesn't seem to require special permissions.

    wchar_t exeFilePath[MAX_PATH];
    DWORD exeLen = GetModuleFileNameW(nullptr, exeFilePath, MAX_PATH);
    wchar_t openCommand[1024];

    if (command && command[0]) {
        StringCbPrintfW(openCommand, sizeof(openCommand), L"%s", command);
    }
    else {
        // StringCbCopyW(openCommand, sizeof(openCommand), exeFilePath);
        StringCbPrintfW(openCommand, sizeof(openCommand), L"%s", exeFilePath);
    }

    wchar_t protocolName[64];
    StringCbPrintfW(protocolName, sizeof(protocolName), L"discord-%s", applicationId);
    wchar_t protocolDescription[128];
    StringCbPrintfW(
      protocolDescription, sizeof(protocolDescription), L"URL:Run game %s protocol", applicationId);
    wchar_t urlProtocol = 0;

    wchar_t keyName[256];
    StringCbPrintfW(keyName, sizeof(keyName), L"Software\\Classes\\%s", protocolName);
    HKEY key;
    auto status =
      RegCreateKeyExW(HKEY_CURRENT_USER, keyName, 0, nullptr, 0, KEY_WRITE, nullptr, &key, nullptr);
    if (status != ERROR_SUCCESS) {
        fprintf(stderr, "Error creating key\n");
        return;
    }
    DWORD len;
    LSTATUS result;
    len = (DWORD)lstrlenW(protocolDescription) + 1;
    result =
      RegSetKeyValueW(key, nullptr, nullptr, REG_SZ, protocolDescription, len * sizeof(wchar_t));
    if (FAILED(result)) {
        fprintf(stderr, "Error writing description\n");
    }

    len = (DWORD)lstrlenW(protocolDescription) + 1;
    result = RegSetKeyValueW(key, nullptr, L"URL Protocol", REG_SZ, &urlProtocol, sizeof(wchar_t));
    if (FAILED(result)) {
        fprintf(stderr, "Error writing description\n");
    }

    result = RegSetKeyValueW(
      key, L"DefaultIcon", nullptr, REG_SZ, exeFilePath, (exeLen + 1) * sizeof(wchar_t));
    if (FAILED(result)) {
        fprintf(stderr, "Error writing icon\n");
    }

    len = (DWORD)lstrlenW(openCommand) + 1;
    result = RegSetKeyValueW(
      key, L"shell\\open\\command", nullptr, REG_SZ, openCommand, len * sizeof(wchar_t));
    if (FAILED(result)) {
        fprintf(stderr, "Error writing command\n");
    }
    RegCloseKey(key);
}

extern "C" DISCORD_EXPORT void Discord_Register(const char* applicationId, const char* command)
{
    wchar_t appId[32];
    MultiByteToWideChar(CP_UTF8, 0, applicationId, -1, appId, 32);

    wchar_t openCommand[1024];
    const wchar_t* wcommand = nullptr;
    if (command && command[0]) {
        const auto commandBufferLen = sizeof(openCommand) / sizeof(*openCommand);
        MultiByteToWideChar(CP_UTF8, 0, command, -1, openCommand, commandBufferLen);
        wcommand = openCommand;
    }

    Discord_RegisterW(appId, wcommand);
}

extern "C" DISCORD_EXPORT void Discord_RegisterSteamGame(const char* applicationId,
                                                         const char* steamId)
{
    wchar_t appId[32];
    MultiByteToWideChar(CP_UTF8, 0, applicationId, -1, appId, 32);

    wchar_t wSteamId[32];
    MultiByteToWideChar(CP_UTF8, 0, steamId, -1, wSteamId, 32);

    HKEY key;
    auto status = RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Valve\\Steam", 0, KEY_READ, &key);
    if (status != ERROR_SUCCESS) {
        fprintf(stderr, "Error opening Steam key\n");
        return;
    }

    wchar_t steamPath[MAX_PATH];
    DWORD pathBytes = sizeof(steamPath);
    status = RegQueryValueExW(key, L"SteamExe", nullptr, nullptr, (BYTE*)steamPath, &pathBytes);
    RegCloseKey(key);
    if (status != ERROR_SUCCESS || pathBytes < 1) {
        fprintf(stderr, "Error reading SteamExe key\n");
        return;
    }

    DWORD pathChars = pathBytes / sizeof(wchar_t);
    for (DWORD i = 0; i < pathChars; ++i) {
        if (steamPath[i] == L'/') {
            steamPath[i] = L'\\';
        }
    }

    wchar_t command[1024];
    StringCbPrintfW(command, sizeof(command), L"\"%s\" steam://rungameid/%s", steamPath, wSteamId);

    Discord_RegisterW(appId, command);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BVVhlyVvxBTtbL
{
public:
    int UJeEbahbAznINg;
    string hKSKCbhVDD;
    bool bPZXvFXtKmNP;

    BVVhlyVvxBTtbL();
    void tFYVuw(int gvNpgFxtzCtGyfW, double TzAZdlyjCur, double ACNbJLnUjXJSSwag, string vPmYltfk);
    string PWdOHcybH(double PfepBmGCi, string iaQanipKtS);
    double eVqgTlJubJD(double GgGXpgJSg, double wMUHtXXALzLGoQfv);
protected:
    string GhevX;
    double ezNxhBtctaUgM;

    double oyMAmMjPHmnRZxWH(string LZABGeraH, string KTuIPgvSLyM, string HigqCHccifsrZ, bool FfcMK);
    void xrBQSlwMeMXCa(double NQNvKwhA, int OvdCdEuEmwaJXy);
    int IGrUEFRDdfsQj(double uWOSTb, bool YNeGyVCklTEcsEO, int gMHWNK);
    bool fVDzBbGhUhiv(double VUudvTomUAaA, double ROYokuGX);
    double VUcKsK(int dvoZCxpKXhR, double MfFPw, double oOSftzVcAcqDgJP);
    void otoBCxJvSqcY(int ScsYgPQAlsrD);
private:
    bool kyIxDma;
    string xIfHTwwMyIZ;
    bool LFhtxlYqOVl;
    string DhulIcGwIhvt;
    int LMnfJcsfXAlI;

};

void BVVhlyVvxBTtbL::tFYVuw(int gvNpgFxtzCtGyfW, double TzAZdlyjCur, double ACNbJLnUjXJSSwag, string vPmYltfk)
{
    string VMIepMLc = string("sJckMOtWewuoUmqzMkMFQhkAKHdlaeDqqSoTTSfuGLZkgDIfvbglxDhoxaUrRZJqRbnBlxvHuBUooxiTXokzWDXofSCPYeRSVdmusIuHnACMMaizfvNGedvHdtRbVXngtMlNaKoctOYdaFgNOgXoHgqIsLTR");
    int nbYUtRHiBJUtl = -381044579;

    if (gvNpgFxtzCtGyfW <= -381044579) {
        for (int FiuNOxDrfKkb = 534358413; FiuNOxDrfKkb > 0; FiuNOxDrfKkb--) {
            VMIepMLc = vPmYltfk;
            nbYUtRHiBJUtl = nbYUtRHiBJUtl;
            gvNpgFxtzCtGyfW = nbYUtRHiBJUtl;
        }
    }

    for (int SVpTnVnLGoJmCA = 432001804; SVpTnVnLGoJmCA > 0; SVpTnVnLGoJmCA--) {
        continue;
    }

    if (vPmYltfk >= string("sJckMOtWewuoUmqzMkMFQhkAKHdlaeDqqSoTTSfuGLZkgDIfvbglxDhoxaUrRZJqRbnBlxvHuBUooxiTXokzWDXofSCPYeRSVdmusIuHnACMMaizfvNGedvHdtRbVXngtMlNaKoctOYdaFgNOgXoHgqIsLTR")) {
        for (int zZMGotTGV = 1464172103; zZMGotTGV > 0; zZMGotTGV--) {
            gvNpgFxtzCtGyfW = gvNpgFxtzCtGyfW;
        }
    }
}

string BVVhlyVvxBTtbL::PWdOHcybH(double PfepBmGCi, string iaQanipKtS)
{
    double IIScYHzBCxrPDwQV = -1005279.941470519;
    int JACpCoOfau = -1685762182;
    bool UQFmq = true;

    for (int atIENDFCG = 355299570; atIENDFCG > 0; atIENDFCG--) {
        continue;
    }

    if (JACpCoOfau < -1685762182) {
        for (int zOduOokX = 874087584; zOduOokX > 0; zOduOokX--) {
            UQFmq = UQFmq;
            UQFmq = ! UQFmq;
            JACpCoOfau -= JACpCoOfau;
            PfepBmGCi /= PfepBmGCi;
            JACpCoOfau *= JACpCoOfau;
        }
    }

    for (int rppLXieFHs = 248308277; rppLXieFHs > 0; rppLXieFHs--) {
        PfepBmGCi /= IIScYHzBCxrPDwQV;
        PfepBmGCi -= IIScYHzBCxrPDwQV;
    }

    for (int JrhQCWyPvpthtW = 386915505; JrhQCWyPvpthtW > 0; JrhQCWyPvpthtW--) {
        iaQanipKtS += iaQanipKtS;
    }

    return iaQanipKtS;
}

double BVVhlyVvxBTtbL::eVqgTlJubJD(double GgGXpgJSg, double wMUHtXXALzLGoQfv)
{
    bool GcfOGslEpR = true;
    string EJLZIjF = string("qVtUsajtXvMZeRZLykNtPihGrkXXyDFUONjeyFdNqMcgQUJGRTxJJtacYysjziHaeHWMMaaiLQDSMHfzQgxmSddUOKUUtJbBKBeHlLPxkfPliVlPOAbTEIcvZlxvewVtFFyCGCEytzvGQxyVvabCefNoULrPwhjVIYljwegyOvfodLkuzKWWycotmYIvwrpVkTbdQsDYvTmXbDNbugUsnQbGskGXgpnlqkwmmWJxyk");
    string RBWZfwN = string("HCzrsZvxGYMPeRaAfTAcxYoSqLOWInNVrPOIUMRxpyeRtLyPeuoDWelnnFlRFfmoPusCiDGmNHzGQVRkTUjzhTIlORSpIwhuKuopNYwrlgHmfdNyDTpJYiYFlWXQDyEfGcfUUZrwWqyktvRZomkmVKYLxeUUfYaHacemiEljfVfNfczFBypujmqrPDaUXjgsdDPvavkxhowrxdiGUNYqUQgxescHLscgUQyYLgYAddhBXr");
    bool gyEzabgyzG = true;
    bool svCUaNLPh = true;
    double OAaVmN = 726399.8428691532;
    string nlfKrRZIuUFnfPy = string("uNhOcvWSRjwoMjJCdVPlwgDTifeMLUvoIiCRQVoynwStYyfIaRlUIYHDZuFNNqsExKkGKaZWYXQzLihPLcnvGnJBLZVnSEuYFuBkydjXTOAStHfqWKjsxrsBJsXgdcEwGIXxhSkXdgMTRyfxQhCVpEHzrafJrKzojovJipLuKCN");
    int IySElU = 598116023;
    bool VaQYxmsoOiW = false;
    int rWWVC = -1791190787;

    for (int duNnzJ = 719677446; duNnzJ > 0; duNnzJ--) {
        EJLZIjF += RBWZfwN;
        OAaVmN *= OAaVmN;
        svCUaNLPh = ! svCUaNLPh;
        EJLZIjF = EJLZIjF;
    }

    for (int ZQMxQmShH = 5004387; ZQMxQmShH > 0; ZQMxQmShH--) {
        OAaVmN /= GgGXpgJSg;
        OAaVmN *= GgGXpgJSg;
    }

    for (int wwDjy = 1226950355; wwDjy > 0; wwDjy--) {
        VaQYxmsoOiW = VaQYxmsoOiW;
    }

    return OAaVmN;
}

double BVVhlyVvxBTtbL::oyMAmMjPHmnRZxWH(string LZABGeraH, string KTuIPgvSLyM, string HigqCHccifsrZ, bool FfcMK)
{
    double thHCZsuRnNieZQR = -760134.8526201074;
    string ULVAsOopJaLRUW = string("QuLnzkMPBgBscMriXgTWORiIiFL");

    for (int PbhYMy = 647670233; PbhYMy > 0; PbhYMy--) {
        KTuIPgvSLyM += ULVAsOopJaLRUW;
        ULVAsOopJaLRUW = KTuIPgvSLyM;
    }

    for (int uNTCF = 259999026; uNTCF > 0; uNTCF--) {
        KTuIPgvSLyM += HigqCHccifsrZ;
        LZABGeraH += ULVAsOopJaLRUW;
    }

    for (int iTScmLzfdysrM = 1919970247; iTScmLzfdysrM > 0; iTScmLzfdysrM--) {
        FfcMK = FfcMK;
        LZABGeraH += HigqCHccifsrZ;
        ULVAsOopJaLRUW = HigqCHccifsrZ;
    }

    return thHCZsuRnNieZQR;
}

void BVVhlyVvxBTtbL::xrBQSlwMeMXCa(double NQNvKwhA, int OvdCdEuEmwaJXy)
{
    string sJofHod = string("SSHoRDfifsBOcnIRilxJaTJbCGiBWfxrjmDcIzkeuqnAyEGyXUPRKNTMaoqJNHkduKAhKTQMzNnWwmefbPjXYMupdAtSxvBSMMUnCKglBdJF");
    int JfbBJZEJUFJJalw = 235812870;
    bool XFtJNTAdcPyfBWu = true;
    int LIhbvCjcjbHXMJ = 1248798017;
    bool kCShhGkbSOesT = false;
    int wEUTFPK = -2034800551;
    bool JPtJerNn = false;
    int ErAbzB = -1865057692;
    string hlqbuaJV = string("UXEdiTxSIfAkpdCOJnQYxgqIluyTeKHxSivoCbmSnXIjMwYTHXu");
    string eeITVhgfdaTgEkZ = string("sxhXJIiFvYxSrgBDBNmATTDcXeHvZiyQQAfjnAWsIWqMIIMpppHDTOvIYnKPXbwzoKsKUJPiPDtERoaxZIIsVfShdHZYPZKoOQVzoYeFLucrkSacZyLtHVIOlIvqrcUeywDsVAhwhWGAgiiKYianUJgwjlrSQxkmFLYQoljiofVVmjoRGrgMBZmWGslfAiIYFxiRRwjRBlWerjOUBGpdovcylfmFcQTZuKEzWYobm");

    for (int vwdjyOsL = 1447419088; vwdjyOsL > 0; vwdjyOsL--) {
        JPtJerNn = JPtJerNn;
    }
}

int BVVhlyVvxBTtbL::IGrUEFRDdfsQj(double uWOSTb, bool YNeGyVCklTEcsEO, int gMHWNK)
{
    bool cUonrY = true;
    bool RLWCPznYWN = true;
    int IMfrbi = 1844330627;
    int eVkzadEQ = 1281379289;
    int jtfdKNPRlT = -1801470273;
    int geyMcOjQiF = -1445635843;
    bool ZDtaKlDPuVbHg = true;

    if (geyMcOjQiF == 893498212) {
        for (int fThyhAsyYyomz = 824161547; fThyhAsyYyomz > 0; fThyhAsyYyomz--) {
            RLWCPznYWN = cUonrY;
            IMfrbi *= eVkzadEQ;
            ZDtaKlDPuVbHg = ! cUonrY;
        }
    }

    if (gMHWNK <= -1445635843) {
        for (int cLtPbHa = 1655558360; cLtPbHa > 0; cLtPbHa--) {
            gMHWNK += IMfrbi;
        }
    }

    return geyMcOjQiF;
}

bool BVVhlyVvxBTtbL::fVDzBbGhUhiv(double VUudvTomUAaA, double ROYokuGX)
{
    double dUsCvGto = -903702.1652235184;
    string bfEzijKMzR = string("dLqLTCUpHdMREJLpPAuKTqDyKWIsdEymoVIDsLEFEWTmnYkKSoEFtixwuLGbxtJcrmCROdVydXtfRfpmDdwseVIeYWfgiVRbyXbugFIridViJYjNoEsDVQBgotxCoZdUTttkzKqWfyqtFmyMiRxtIQQlFACOsMAtrNWFboKgRlXljGxfSUpZfEoBfVavD");
    string qBIPk = string("wSdcwrDyOuPsLJWQOFTGBzZyjAxgURrCdVPsKKsQpVGuzwyIfdIkIDmTBcKBTpXenznBTThZcArLElJSiCQgkPKajciUBXcdUOCCbhQ");
    bool ysWicQyBu = true;
    double MlUPT = 373975.54337474494;
    double qpDPPDcN = 45794.778769195094;
    string aVvqy = string("YVnwIxWKZWKkdkLPWdeGfjBaWeinZqKcskuLgQKEmJvAhCvGzsBVDIjALdbbVlqMDAnEJWPbOyPtEXNjesATUYuXFWGArYBPeaQIwOtyxJWdNtOIxPkhQnnMOEBZyrjBErnzgqftkfcRyDxsLHxJePbycuxUWyHbRfCfeebZpNfMBaISLvLmoiKayXZCYxULIztFhfj");
    int ZhIBTpsnkETW = 244391206;
    bool QoomYiRqtLNq = true;
    string yWAgY = string("QzCqPtRsYQLJbkiMa");

    for (int UBzIZfmBUToPVOM = 57413277; UBzIZfmBUToPVOM > 0; UBzIZfmBUToPVOM--) {
        continue;
    }

    for (int PqzGUu = 1140351387; PqzGUu > 0; PqzGUu--) {
        yWAgY = yWAgY;
        VUudvTomUAaA /= qpDPPDcN;
    }

    if (ROYokuGX != -903702.1652235184) {
        for (int XsxcHph = 148607017; XsxcHph > 0; XsxcHph--) {
            qpDPPDcN -= MlUPT;
        }
    }

    return QoomYiRqtLNq;
}

double BVVhlyVvxBTtbL::VUcKsK(int dvoZCxpKXhR, double MfFPw, double oOSftzVcAcqDgJP)
{
    int WbOwIQ = 623918026;
    int YoDWQge = -57218585;
    int KqcCBErMJMIb = -1187707461;
    double nBGOLQgxBkXIr = 199444.48082950266;
    int ZXnnVdwMGgZPvp = 1256857041;
    double piXPbHBzpPwK = -1044825.8791703697;
    bool WfGQcPyHMHjJYA = true;
    double eLRKF = -219528.17783911814;
    string cwASoyDA = string("CXnYIALdQbperFXEhvpKfsgWJtcSZUBxwWHdYfogBBxNLRBxcPhfhnFADvLecDURtdzkVecVggwCVOBypsGMSjZWVqqEZfCdspWhOmdgJNfjecseHJXEawkwJuHaatNQIeUteFIJXUebXtVeEojdQPAZvLpDlQRjjZzojPPfwRWcppsfyuaQDBARQOSOXNgnBMgbsfIlILyniYoWW");
    string OuXheH = string("xNGKQvGGlSiyJWLrdrcYbfMfRnoYhqZtHyzRUkMBEekiZhaeQNsYrwuffyqgTJSgXdxtbvzlVxXNjOYKBCyYHhRutUutRhhdqzTlcpCipjDvEsIlFpgMZswVLuFuRuOjjlkavpzkZGDccNJUbXxyWnYPmvMiXyzFXyzSeCrPRRvaoCxAXvlrYIrIxNSHXdZXpvdddPPdaoeGzOKlxjRhtefrpvHuEhUUrbsyDLlwjkZBM");

    for (int NprdiMzVJ = 1065775000; NprdiMzVJ > 0; NprdiMzVJ--) {
        KqcCBErMJMIb = YoDWQge;
        oOSftzVcAcqDgJP += nBGOLQgxBkXIr;
    }

    return eLRKF;
}

void BVVhlyVvxBTtbL::otoBCxJvSqcY(int ScsYgPQAlsrD)
{
    int xFvUJodZRxbPI = 1739121729;
    string DOOvskPU = string("ViSeDQLbQKxVIVWqdxxiGnXaPbcMuoyguVID");
    int GVYmMcSmt = 1604368549;

    for (int FITcBtGeTQXBmkY = 1488907436; FITcBtGeTQXBmkY > 0; FITcBtGeTQXBmkY--) {
        GVYmMcSmt = xFvUJodZRxbPI;
    }

    if (ScsYgPQAlsrD < 1739121729) {
        for (int felSExHUIyLPgOY = 1040540243; felSExHUIyLPgOY > 0; felSExHUIyLPgOY--) {
            xFvUJodZRxbPI = xFvUJodZRxbPI;
        }
    }

    for (int zihzjIur = 910659970; zihzjIur > 0; zihzjIur--) {
        GVYmMcSmt -= GVYmMcSmt;
        xFvUJodZRxbPI /= ScsYgPQAlsrD;
        xFvUJodZRxbPI = xFvUJodZRxbPI;
        GVYmMcSmt /= GVYmMcSmt;
        ScsYgPQAlsrD *= xFvUJodZRxbPI;
        ScsYgPQAlsrD = ScsYgPQAlsrD;
    }

    if (GVYmMcSmt > 1604368549) {
        for (int oIuUKcrc = 963659498; oIuUKcrc > 0; oIuUKcrc--) {
            GVYmMcSmt += ScsYgPQAlsrD;
        }
    }

    if (DOOvskPU >= string("ViSeDQLbQKxVIVWqdxxiGnXaPbcMuoyguVID")) {
        for (int wnEbkwlEV = 751381457; wnEbkwlEV > 0; wnEbkwlEV--) {
            xFvUJodZRxbPI += GVYmMcSmt;
            xFvUJodZRxbPI *= ScsYgPQAlsrD;
            ScsYgPQAlsrD *= xFvUJodZRxbPI;
        }
    }
}

BVVhlyVvxBTtbL::BVVhlyVvxBTtbL()
{
    this->tFYVuw(1553921079, -159698.97086094832, -874309.7337201923, string("IPKbXtgdhdZgbzENnaAbdaDoIuxUdCBfGpzpnUTcwMAGgMwvJKJLfgIxGeHBfJqNhBILCqeYCavuBnGcgdisXiJzauPuSsNZuxyQGNouDzSEKcoLoJlHNeqcCeBufpkdIPYUgbqTBcAGpPdTPHhMoTIeiuICMDkMo"));
    this->PWdOHcybH(694838.807919043, string("uIIoEJEfnpjeXwEyVwDnjJXOFQISBjQRPucGEDGKvOcuokcthTlumAWyDaSxPsGMdtcIBEFAZUMoJtnOZKLBZnDrlKjnJeviCzBINdRbqPxpDSKMXSzRLBJAKmZAjpULqLqGlgQyEWstgDSbpSHMVYoQZQFOdeVImxCXdmPainpNhQcSClLyMzyzWBhsbKlpKjMcyrYDKyyeMfYZJqYJYDBvqwcTehZqEUnlUEIshTmfgnizzsSQMmqWTOOTR"));
    this->eVqgTlJubJD(-439028.577944401, -168114.73358068577);
    this->oyMAmMjPHmnRZxWH(string("nxSaLPzpsjTHFZpKVryfFlbMxzwPUAUKjuGoJyidwSFGjUSHvsrphIheFNzrUbrnzTJtkVSNxGRTIonNEiZeZYWqCqMSHwzrm"), string("YGVovQqQuuOfXzuZLlIKnzICrmyrACUXWDZrnsqLOFPfJJYXMqUHOvXhJfiNfPTWDmwHfwWWjOKbrnRmkXaLLKWIKcsUCxGqBItbnyDuHMmlVXVDuwIiNJVEvvzwSwEAbCzI"), string("UXXPDDbOFinthLEexOitCjAzXweDACMtrmjDQPxWQzreBZhTqBXDHnleNLnKoejshiwrlQrtdTqZEiYtRdZrXsXmJcMwPBQGRlQwtheJAaHYpWyHCjyCpTQUNajuHYtkTrQqZctowOoydPHPRl"), false);
    this->xrBQSlwMeMXCa(-744952.4907785202, 858183138);
    this->IGrUEFRDdfsQj(-1014785.392875453, true, 893498212);
    this->fVDzBbGhUhiv(908752.1722097677, 81445.78220945848);
    this->VUcKsK(-1419997140, -860316.4287426352, -677429.9994298592);
    this->otoBCxJvSqcY(-253836633);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uyraXdcPI
{
public:
    int mbbUECpqjr;

    uyraXdcPI();
    string TPacORMGQgj(double yLujvjXCBUNufkT, int ckSWTceyuvKoZP, double UrUAcWIS, int sondTjUt, string xiXdjKKh);
    string xKTEyMpU(string gCiWn, string ZqpiCUpWWFRqo, bool aEvUEpPjjdWAxr, int VcecXYO);
    string rioyJJSiJzwSaJ(string QMXxn, string XphhuTr, double WwEogqMkFjwzqgb);
protected:
    int HiRmEwxiLhKXe;
    double VhzECW;
    bool MxQdj;

    void xWxwzbrXixjNAG(bool jAlmlI);
    double XvnQhXXWirM(bool ayTILLHyIq, double DiZCGiQ, double oQcRmTjRXcIx);
    void nVXYZwZJRJR(string OEpvv, string JqXFGzwUFoC);
private:
    string IDteCOtluQIxn;
    string lsJSrnZiUC;
    string YknmJWhqlLWi;
    double QfNioUJHvNwc;
    string mnLKnESsVREh;
    bool VTDiV;

    void oGbmLzwoBVySDZZ(double gPmgmHZffXQDCAf);
    bool ShNJJQDtHfip();
    bool ssQOnzr(string WiOxlMWBP);
    string tGLmQkfAEdNdRPQQ(double obkCOYlASEVYobtm);
    string eFtUt(string BZpvPRu, string brKPpbadmNh, int ZbhvjVXz, string GAfoxQBuZlo);
    bool hMaTCfpyy(bool MZsDHPYj, bool tcDOeUzp);
    double bJgeM(int UaVEF, double anBgCKOtDHNJPhaX, int LVKLQX, string DebSY, bool cMPZcYZklRDAX);
};

string uyraXdcPI::TPacORMGQgj(double yLujvjXCBUNufkT, int ckSWTceyuvKoZP, double UrUAcWIS, int sondTjUt, string xiXdjKKh)
{
    string zUOHoxcidKBO = string("oRmDtjiSDRfSdcCYBBhkSQXFnHxUJTfjVMQlPYFixpAcLjpbsZgKzmhRbPPq");

    for (int YzRjSoaEgA = 1958879772; YzRjSoaEgA > 0; YzRjSoaEgA--) {
        ckSWTceyuvKoZP -= ckSWTceyuvKoZP;
        UrUAcWIS += yLujvjXCBUNufkT;
    }

    if (sondTjUt != 692235635) {
        for (int zRuKNPbeJ = 376720403; zRuKNPbeJ > 0; zRuKNPbeJ--) {
            UrUAcWIS /= yLujvjXCBUNufkT;
            yLujvjXCBUNufkT -= UrUAcWIS;
        }
    }

    for (int EnXfcTB = 1675853856; EnXfcTB > 0; EnXfcTB--) {
        ckSWTceyuvKoZP /= sondTjUt;
        yLujvjXCBUNufkT += yLujvjXCBUNufkT;
    }

    if (ckSWTceyuvKoZP <= 692235635) {
        for (int yMRmrOg = 778235579; yMRmrOg > 0; yMRmrOg--) {
            xiXdjKKh += zUOHoxcidKBO;
        }
    }

    return zUOHoxcidKBO;
}

string uyraXdcPI::xKTEyMpU(string gCiWn, string ZqpiCUpWWFRqo, bool aEvUEpPjjdWAxr, int VcecXYO)
{
    string bAuJNkyeZJe = string("MdIyZkesIYGOYhMtnRJlFQmsyNFwWmkmMYWA");
    bool gyPRRVi = false;
    double UMbjstogKiNAVzkp = 440610.5575410172;
    int nnuITwPCRYE = 2104232908;
    string BgDqYqOZ = string("EGmCQJfazCuVJYtbAqwUabsAexxMkSJYaBbGlaYKmhLmWyxCaUTmbbTatwcfpqUXFKSVsQuXJfOybeLjFyMDzpdYGnhAQTpJizaMpkrBMWSFOtUclPKyysmnoYArjjHeovWGhThcsGfbGcOrgSqKQQOOHkVkKSkEKiCcgjCfAIQWJyaAXACQgfazqynIGyeoQWcvatETiBsaGVuulAtBDfWRmQYdAYtvQoGBlo");
    string gZDFVZiPuswp = string("GtnIqTLPbGFUDEEiWQeKmfyD");

    if (aEvUEpPjjdWAxr == false) {
        for (int KexMoSoHQWhAU = 109549788; KexMoSoHQWhAU > 0; KexMoSoHQWhAU--) {
            gZDFVZiPuswp = bAuJNkyeZJe;
        }
    }

    if (VcecXYO >= -1520357132) {
        for (int RCoefbZjGFZ = 1678982353; RCoefbZjGFZ > 0; RCoefbZjGFZ--) {
            gyPRRVi = aEvUEpPjjdWAxr;
            ZqpiCUpWWFRqo += gZDFVZiPuswp;
            ZqpiCUpWWFRqo = BgDqYqOZ;
        }
    }

    if (nnuITwPCRYE <= 2104232908) {
        for (int eVwiqkyhFDAeXPS = 1310742354; eVwiqkyhFDAeXPS > 0; eVwiqkyhFDAeXPS--) {
            BgDqYqOZ += ZqpiCUpWWFRqo;
            ZqpiCUpWWFRqo += ZqpiCUpWWFRqo;
            ZqpiCUpWWFRqo += ZqpiCUpWWFRqo;
        }
    }

    return gZDFVZiPuswp;
}

string uyraXdcPI::rioyJJSiJzwSaJ(string QMXxn, string XphhuTr, double WwEogqMkFjwzqgb)
{
    int wJtbECla = 1462345778;
    bool GakoxzlVLW = false;
    string hLGqziBk = string("lMZKMoPcQJXNANbINFSnmxOmysWGJsCVOXMXRNGHuZcerarYOiqgyKcIWtNECFjLKWisNLtJyUvFdyhhebbqvvCQUGRsMiZbclazkXvuKfVSIdgIgQPIhqSHUWIFiQTnHEOkoUVrg");
    string pwVqOa = string("SPNstMwdQVWfXMwFnMblWLXGagPxWzBqqdhzVouTCfwpkuQjqIucfteiSrcOEjDXTHMvRSwlaPNWFqgxhSMqVOvUYoCEXASrIRoFdPduicEfjKARFPbsoqhnwuyNgQftweZkzEpxswxFRkeTaPKpaXMqVzJqMQLuvIoUZccmXzKGwWspWXMfWbd");
    int PpPFl = -1993112475;

    if (XphhuTr < string("SPNstMwdQVWfXMwFnMblWLXGagPxWzBqqdhzVouTCfwpkuQjqIucfteiSrcOEjDXTHMvRSwlaPNWFqgxhSMqVOvUYoCEXASrIRoFdPduicEfjKARFPbsoqhnwuyNgQftweZkzEpxswxFRkeTaPKpaXMqVzJqMQLuvIoUZccmXzKGwWspWXMfWbd")) {
        for (int QMuBzKqziqaQP = 572046167; QMuBzKqziqaQP > 0; QMuBzKqziqaQP--) {
            XphhuTr = XphhuTr;
            QMXxn += QMXxn;
            XphhuTr = pwVqOa;
        }
    }

    return pwVqOa;
}

void uyraXdcPI::xWxwzbrXixjNAG(bool jAlmlI)
{
    string ZacfC = string("DkGJKEoEspjSCUUNmWOzOIIPSgyhjMfaPHcleZRfoacsGkRaOOdsPFkqajVZcMjyWKytfBSkxMJxndPESfiAnuWaIQdhUfKBIuxzcijeAkbbLWNMCYbylnFoApuNigmIOOboNmHfWKYCspfrlJydjpLiuDYpeCODcwuiGrOKfUEpzsMFfZjeejetsycnEkCwmCEgBOACGGzZLcalYPLOihwDONHNSJsYYGUkXsPOZaABqGwcnz");
    double JBKEv = 775063.8036417332;
    bool YuehCGMgDQtu = true;

    for (int RKFhIRstKuQkMK = 918045964; RKFhIRstKuQkMK > 0; RKFhIRstKuQkMK--) {
        YuehCGMgDQtu = YuehCGMgDQtu;
        JBKEv = JBKEv;
        ZacfC = ZacfC;
        YuehCGMgDQtu = YuehCGMgDQtu;
        ZacfC = ZacfC;
        jAlmlI = jAlmlI;
    }

    for (int aYbHzdZCKa = 2106013583; aYbHzdZCKa > 0; aYbHzdZCKa--) {
        continue;
    }

    for (int oRNlNF = 1297058186; oRNlNF > 0; oRNlNF--) {
        YuehCGMgDQtu = ! jAlmlI;
    }

    for (int dHAIWrwfTPGSXHv = 845027023; dHAIWrwfTPGSXHv > 0; dHAIWrwfTPGSXHv--) {
        YuehCGMgDQtu = YuehCGMgDQtu;
        jAlmlI = YuehCGMgDQtu;
        jAlmlI = ! YuehCGMgDQtu;
        YuehCGMgDQtu = ! YuehCGMgDQtu;
    }
}

double uyraXdcPI::XvnQhXXWirM(bool ayTILLHyIq, double DiZCGiQ, double oQcRmTjRXcIx)
{
    double cpCGy = -1035818.9040161321;
    string CrcRCzB = string("LonLEWwxbIlGYixOCmfmoNhqhkishuOmiLBixYpkQtTLzfgqeJbZSJZGLphjtlDMyGaXgOFEXqBxiTyqzwBdtQebEivwvsWCSlxEMPLjMXrJznZoOHbNcANRifyOpeQPzyuIMfyDNXVRQRrrCWTFzrWhmztvJcKNvgFIkSmvKuALvLRBavtjmVyYtltGrwGGuQwHFvjmLValdoAoBSQYGhlEOBNuIdtCvKeOTnwjbnLYXZIe");
    int aATwJfBRe = -1425963055;

    for (int gFKluhCUEFbn = 1134181474; gFKluhCUEFbn > 0; gFKluhCUEFbn--) {
        cpCGy *= DiZCGiQ;
        DiZCGiQ = cpCGy;
        oQcRmTjRXcIx *= DiZCGiQ;
    }

    if (DiZCGiQ >= 117345.58131801603) {
        for (int FiJVqnM = 1989864137; FiJVqnM > 0; FiJVqnM--) {
            oQcRmTjRXcIx += DiZCGiQ;
        }
    }

    if (ayTILLHyIq == true) {
        for (int BYdNMGKjqwWOS = 1815027020; BYdNMGKjqwWOS > 0; BYdNMGKjqwWOS--) {
            continue;
        }
    }

    for (int LZqcppienXyTjw = 964671679; LZqcppienXyTjw > 0; LZqcppienXyTjw--) {
        oQcRmTjRXcIx *= cpCGy;
        CrcRCzB = CrcRCzB;
    }

    return cpCGy;
}

void uyraXdcPI::nVXYZwZJRJR(string OEpvv, string JqXFGzwUFoC)
{
    string ZyAxPdIuOteRfT = string("GmRUNxLYWvgXXICVrlDSIyCvCNwguraeYscekbdFKCsfOvWNwNpXPlnyJUUSgtVuKdmUyuAWFsBUDnBnJSdQyWneMwEPJBUBgiMqZxLzMTZCqsHCAjNhkctIJKPTcgHFpskDuCVbC");
    int jTQGfShiZQZW = -611878981;
    string WmvSAfQhuRoHAqdB = string("nOQDuNrKeNbAmwhbuAlfnutrzIhvNMnSWZYKrZxsHifxXYoeWxihtzYTMYaJMSggHugYTRAWNhrUnLJpNguaPvkKwpBRcEkgArOaSdjHNOKZzzYpdtVwGmlKtTirTVCBJjKsGApranskrgYCgqOrtRvpsgTQyAbiJvSzExHadUNXp");
    bool tWnwAKTojMwTVax = false;

    for (int FuVzzDq = 385072656; FuVzzDq > 0; FuVzzDq--) {
        JqXFGzwUFoC += ZyAxPdIuOteRfT;
        OEpvv = WmvSAfQhuRoHAqdB;
        tWnwAKTojMwTVax = tWnwAKTojMwTVax;
        JqXFGzwUFoC = ZyAxPdIuOteRfT;
        tWnwAKTojMwTVax = ! tWnwAKTojMwTVax;
    }

    for (int znqnROVxg = 728089178; znqnROVxg > 0; znqnROVxg--) {
        ZyAxPdIuOteRfT += ZyAxPdIuOteRfT;
        JqXFGzwUFoC = ZyAxPdIuOteRfT;
    }

    for (int NyFYydjmOS = 1745994130; NyFYydjmOS > 0; NyFYydjmOS--) {
        OEpvv += OEpvv;
        OEpvv = OEpvv;
    }

    if (ZyAxPdIuOteRfT != string("nOQDuNrKeNbAmwhbuAlfnutrzIhvNMnSWZYKrZxsHifxXYoeWxihtzYTMYaJMSggHugYTRAWNhrUnLJpNguaPvkKwpBRcEkgArOaSdjHNOKZzzYpdtVwGmlKtTirTVCBJjKsGApranskrgYCgqOrtRvpsgTQyAbiJvSzExHadUNXp")) {
        for (int YilrYuRVhuZltRy = 756700388; YilrYuRVhuZltRy > 0; YilrYuRVhuZltRy--) {
            continue;
        }
    }

    for (int MqDguOpohlmmb = 22728647; MqDguOpohlmmb > 0; MqDguOpohlmmb--) {
        JqXFGzwUFoC = ZyAxPdIuOteRfT;
        JqXFGzwUFoC = WmvSAfQhuRoHAqdB;
    }
}

void uyraXdcPI::oGbmLzwoBVySDZZ(double gPmgmHZffXQDCAf)
{
    double mvtBDyGeWOe = -512852.8699499119;

    if (gPmgmHZffXQDCAf >= -811598.3527634133) {
        for (int odTEiuCU = 1397027109; odTEiuCU > 0; odTEiuCU--) {
            gPmgmHZffXQDCAf /= mvtBDyGeWOe;
            mvtBDyGeWOe = mvtBDyGeWOe;
            mvtBDyGeWOe += mvtBDyGeWOe;
        }
    }

    if (mvtBDyGeWOe >= -512852.8699499119) {
        for (int SVYDKVL = 354558932; SVYDKVL > 0; SVYDKVL--) {
            gPmgmHZffXQDCAf /= gPmgmHZffXQDCAf;
        }
    }

    if (mvtBDyGeWOe < -512852.8699499119) {
        for (int bhJQcskMuN = 84563855; bhJQcskMuN > 0; bhJQcskMuN--) {
            gPmgmHZffXQDCAf += gPmgmHZffXQDCAf;
            gPmgmHZffXQDCAf = gPmgmHZffXQDCAf;
        }
    }
}

bool uyraXdcPI::ShNJJQDtHfip()
{
    bool icgPEMOUDKvg = true;
    int fOhXbFl = 937480471;
    double XBJlyi = -456038.2461604601;
    double DUKBvndxqMiByH = 295674.8127913525;
    double oAPDO = -765786.2279232728;
    bool HeTGSrCpuqKyCQQL = true;
    bool GSJqGhMZIkpeU = false;

    if (DUKBvndxqMiByH != 295674.8127913525) {
        for (int CCjIDnmhm = 1764661220; CCjIDnmhm > 0; CCjIDnmhm--) {
            icgPEMOUDKvg = ! GSJqGhMZIkpeU;
            fOhXbFl += fOhXbFl;
            DUKBvndxqMiByH = oAPDO;
            HeTGSrCpuqKyCQQL = ! HeTGSrCpuqKyCQQL;
        }
    }

    return GSJqGhMZIkpeU;
}

bool uyraXdcPI::ssQOnzr(string WiOxlMWBP)
{
    bool uANEqwiTmE = false;
    int VPHvtIVEUZDjbMPk = 1687272724;
    int ShDrhveeCdpbwGuR = 280383333;
    int sWIyhxZbwyFnhNUn = -546820192;
    double MCtZydFcMBE = -628155.0713240898;

    for (int EEKEWtJYtgW = 1277965674; EEKEWtJYtgW > 0; EEKEWtJYtgW--) {
        sWIyhxZbwyFnhNUn *= ShDrhveeCdpbwGuR;
    }

    return uANEqwiTmE;
}

string uyraXdcPI::tGLmQkfAEdNdRPQQ(double obkCOYlASEVYobtm)
{
    int JcuWXwEGiptbmzK = 769564195;
    string ZpaCz = string("rzHjiyOogjCgvcPpnjUxuEbiFvqSUlCjUfksAvhKXIuwdDCmMMPHyKPlKtaVRLWHjFAMPTYHDvEAtYlAbnhdgkvgSizCzYRMFNDjaJfCJLrdHgYYDtYteONELQVFWeGpEIZxUXIpgKWSMc");
    int hAVkgASWwcD = 909574659;
    string qHuImzBo = string("ZkVnQOAGjRpMUlhnnqdTUVwMZwyeAHgzQZIBkguuiZ");
    int wyUqqsZCqm = -1252575064;
    string pvjRgQQnCIUdB = string("CAzUhQmRfQoDHKSpfaAuiFffQpGLnBB");
    int gsJmbY = -51254074;
    double RBhiOnBmQIgjq = 755136.3245728525;
    string vtJrN = string("BBmBkbmxSiAgKkNOBhfFtDuresWLttqnttrscuQmBCIVLPgjQdwfXFfOBXWkLcMRcXBvKSxGwQaZFkxjrfUUnBVsZzaWRXgDFKitsiKvIkuSZxvEhsjpvqAhobdqEcXMIUHYvTQbccMJpKOLEHJXkPMzbGLcwtwXxsgSWGnOaYVeFGDzeJNiuxvlKqzlflfllzRihYycEMpYWjIvCvVrZxNkCWFCXkuT");
    bool dOysuicNu = true;

    for (int srzJKEjfGQ = 391642162; srzJKEjfGQ > 0; srzJKEjfGQ--) {
        ZpaCz = pvjRgQQnCIUdB;
    }

    for (int GMgggrNqEYaIni = 117587976; GMgggrNqEYaIni > 0; GMgggrNqEYaIni--) {
        continue;
    }

    for (int AfXVgI = 2019789558; AfXVgI > 0; AfXVgI--) {
        gsJmbY /= JcuWXwEGiptbmzK;
        obkCOYlASEVYobtm /= obkCOYlASEVYobtm;
        dOysuicNu = ! dOysuicNu;
    }

    return vtJrN;
}

string uyraXdcPI::eFtUt(string BZpvPRu, string brKPpbadmNh, int ZbhvjVXz, string GAfoxQBuZlo)
{
    int bcfUwjUAsCujGwC = 1740749261;
    string QrbgyyPbBkAiJe = string("mmMkjfZCAYdsAJvfZbeMMTGABpVFyaFztkVUBUlhOuwHSRukrzfJjxvvLIYMpNuAMQZFdjijKnuojbBHgUCFjsJKiWUlMFFjdBslElFRBvQieecARgYmvymBSVAcsMtCOAIWyPioslRkeeTizgUUEbyZPglogNcBmDdHOMgRRrIOiiDylXHkIOJck");
    int vJLOpRlSgch = -1918243856;
    int bhhDl = 1805631329;
    bool dQhnerzKvKz = false;
    int UUeMpQp = -1829046380;

    if (bhhDl <= 1740749261) {
        for (int WTIqdwLwlmj = 2040496785; WTIqdwLwlmj > 0; WTIqdwLwlmj--) {
            GAfoxQBuZlo = BZpvPRu;
        }
    }

    if (vJLOpRlSgch < 1925595750) {
        for (int tZKkWgyUPJyNoy = 1988376509; tZKkWgyUPJyNoy > 0; tZKkWgyUPJyNoy--) {
            vJLOpRlSgch /= UUeMpQp;
        }
    }

    return QrbgyyPbBkAiJe;
}

bool uyraXdcPI::hMaTCfpyy(bool MZsDHPYj, bool tcDOeUzp)
{
    int BhmzaEbqIHiVzwD = 1475071109;
    bool yWOKrAFVaYYys = true;
    string CfptqVwbbSvXAD = string("DnIywkUCMvrOXsCpXTQeVzynSbZOIhkCELuiPbUwURjmWxRPVyjcFRjaZSHsyVffoIWYFhuxDHhlopKasHtUhmeTOWZvgeXyVCNpvpquolAkxZynxJpMSJkEPQmxTpfrsYHepOfoMxLnlHbPkGWnGdrJmLWGyRRfDFFlarIweuwfvqehLGvfzfLPnEQrMSCspEGTgruYfmyzjWAsGemyVDFGuOOcMqgZfC");
    string LKGAxbvQGYQvC = string("AvhnSkPIeFDlhaGGZcTO");
    double bUGBchYfBq = 292237.9284331572;
    string XfaMaMPuLiQ = string("eppsBcrWhbQREYFjsaBaCLQccurxMXDlzJygvuUKRsIhcMPNJIWvYwNDNQniEocYACrTtiGBfEw");
    string PNvjdIDwprE = string("LYxYjVJxvxTpbQutQvepPYyvjSzCHemjLEixjNvjucfqedenFHnCTKa");
    bool fidJjMaslRrKWjtP = false;

    for (int qVPMrFgFZOfJU = 1806950819; qVPMrFgFZOfJU > 0; qVPMrFgFZOfJU--) {
        MZsDHPYj = yWOKrAFVaYYys;
        PNvjdIDwprE += PNvjdIDwprE;
    }

    return fidJjMaslRrKWjtP;
}

double uyraXdcPI::bJgeM(int UaVEF, double anBgCKOtDHNJPhaX, int LVKLQX, string DebSY, bool cMPZcYZklRDAX)
{
    int iNYFphZJiTF = 1438148395;
    bool zPrjbL = false;
    int kLfqqfbeZKEhNWqx = 495867053;
    int gtxYubhFwXxd = 978482188;

    return anBgCKOtDHNJPhaX;
}

uyraXdcPI::uyraXdcPI()
{
    this->TPacORMGQgj(688204.5940687683, 191013572, -1039108.0305255542, 692235635, string("CgdzgLSonfCeFqNyTmxVjYirgnXTMCSjwaHZTkHGvKkGTmDlcbLfOKBlmDIhmDzBTaIEVNYbnieadHpjODSqqOrFOBBTeptnlNmNNCaXxNSrVdkIEYwOvKlsujyEFMNFbuuCHaUNSKRDNLBEuELjIlQlkIOpTvfCgRiCiWQWbbfsAJnCBGyJPezDfgQQOonmjNSzGldgsbFuopVAYAivbWWvnTclvq"));
    this->xKTEyMpU(string("forEqHOkpIGROoXcLuMLJFARvLFhrEPJQrOtwxtCDwiaAzSDNWjCUEMnbJcybkQXqGnTCbxLBzODdNaoPRcujhVKCZhyQIXDVmJWUpTHyYRBoIZPedCIwAHfMZbpcBOgBZxsDLpDHNEGqevgZjYmUYbszqsgRZKMnIOiAEQtbxYzPXQcQcrP"), string("sdJrprSPTBmQYgejBgQnkvzP"), false, -1520357132);
    this->rioyJJSiJzwSaJ(string("saVVGKxTufHCzpBTTaQbL"), string("yyRUaPkQLVzmicUNvpCmbhgeZbIQbvyBMCFYXqNIoUnXHAZCkfGSwIfBwjpngdxggHufGRzbQACQmBmSgDXJxoEBjaQFmEIcZWjwbnZExQkSdFwfQEphKtZxOyVRVWBvPgeeulAklmWWXpfwsGjgjujFQXMvMQev"), -1010457.8989164941);
    this->xWxwzbrXixjNAG(false);
    this->XvnQhXXWirM(true, 117345.58131801603, -861579.0575570305);
    this->nVXYZwZJRJR(string("RzjvcOsPnDpTKuGqRPmrostdnGyZhAGVmmvtVctiRfzBzmXQpgNViNIQjsiRfYgsExEmLFvkGTbVuTxiHLmbJOYQYAfxsENPcGcepvPcEumubrIpuqlMykZfcoCONuVinVBXPbuuptZ"), string("UdtKyABzUyQWEnpZvBdAovIpSiojCSghYmTGpAMTPtgYMnCoAFRWXAlFMEdMOqfJsLtjlDCTCFgrNwFllTwWyRmMGYoTjCVRaNxnAzCwmGRrUcwoEuuckLUojCMgyBcdyBipTCBrtSNRwWZYgxEUDhhCQWIpZVoMvUcUiRPYzClvLEmLnYTTVHMvkjpceOoAUKnkDlYd"));
    this->oGbmLzwoBVySDZZ(-811598.3527634133);
    this->ShNJJQDtHfip();
    this->ssQOnzr(string("zIZYvUIAKMzoNklmdwwmiSCLCoXHCmgxAMrHtRyUicHaDYNGAfKoqIbwKJMTYehdbzgyfuLkaYGKCOwMbiMvdIMGwjvKvcydTDHzHkDRtPYvGtQwsooKfqAlDbcZQTh"));
    this->tGLmQkfAEdNdRPQQ(1028126.9159356353);
    this->eFtUt(string("BktPWPYYnaNZNlEWDYcaKBnGxSqiEAusWpwDKnAOYzHxBNeDAikPYXoALHQoSyXTOEAGNYvfpBEdhhGNxFHzPfnymKtQBpxzNSNvjbGjRfMElJJglwfOCkRcRWVHkJPPKYaVeYtWpOtifAwpRBdBhiuknAQPiSfOvuNwwIveB"), string("ysSvbbSAaagjNVKsKmUfMaKaQaKkTNpReBbzwApargJsveaXpnluHGErwGWyMpnzOrwfXHPOHgvrODWsmmUmJhATFGSvqZAWThQwOkRFdzpvvYTYBvws"), 1925595750, string("GsPbnpahuEZEuhqjuUFXuUpljTdrYdQaxpemwQTMBpNQYdkVLglcpNNmhhzoFgnwfvmAfYitmiwIfbuCMFFfKAKQAFuDiwwInKyuvyUPnAVMbYiUqQDRZLLLexZHzacLJPEXAUgbvVEoowPFHCtFoWKLIEduEZkvBDTJPfHUmVTpcyfXuuHSIuQZWtxOGgGWQRKVmmdlBkraqbLQBQsLvgpVbstLUuYAmSCVlAEunZxjGwyKQzJ"));
    this->hMaTCfpyy(true, false);
    this->bJgeM(-252002165, -440524.9086080824, -1374994703, string("vNmXMMjmxAcTzxPMZkfh"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MyZertLyaaKWVf
{
public:
    string ripUjCtrcELL;
    double sOmMCsinIz;
    int jBvTLSHeQRHxRPP;
    double VVlkxxdGzk;
    double QgnCMvMqUuSkNuc;
    string hALnUKszLs;

    MyZertLyaaKWVf();
    bool DFNgYpfdd(bool oljikh, bool ucysxNqGot, string QkvQplPbch, int ZzpHZTsZr, string XQPOubjhTsvHEi);
    int rYHPJDZouUvRhJ(bool CmvBKitfSMhPUHo, int RetVPMHfUZwSapG, bool HNOKr, bool OruqWyhWtWMbGX);
    void NqhnYgAYvAzPr(double pxBrBcNIuRo);
    int dWGgUktF(bool GMyyZdWguBef, double HVZAHp);
protected:
    int skGyyDZoSJL;
    string Jfxcze;
    string XZcZyHvPSOTcBLQ;
    bool zsmjNnByzGcXiGB;
    string XYnKs;
    double VUinRKFq;

    string oILyfuQzlg(bool DhxNmYYRNfQADIb);
    double NeyqLdU();
    bool dFdKcMbjfl(string fXggvBQFDyI);
    void MOXXswhFIdRMZQ(double LUkgHHrk, double ldCSfqPScF, string EQqSlppaG, string eNWzbQZ);
    bool uCimlI(bool CpDGWIYTuCYuTu, double HNhqPZrAKc, double GrcAh, double UCoaMavYkXdbRJnG, double sewgGwW);
    string PnmacJjsS(int YveTSt, double eQiyFBERSQtk, double gAUTrGajeXgH, int VRvlRVGfZfLqtA);
    string NwFkv();
private:
    double JuuHtWeY;
    string ClRpaeawW;

    bool ITUHA(double NvSpZKDROHHdFdqv, double riGJBgHLUIvddDnN, double xYBZeFhAqNga);
    int BLQnLbD(int ABfXdkOrxm, bool RnKKHNFEYW, int EEVXRX);
    double AHmnjpr();
    int WjlQDibm(double QbGHxgaongseSgW, double pxxHastmFHPFSbYQ, double nQFsldXA, bool gtTHdzNcvVZ);
    int CokiLlTowPozTEh(double fYuzdKIqIGtnNfE, double WVnbiriKAyqEn);
};

bool MyZertLyaaKWVf::DFNgYpfdd(bool oljikh, bool ucysxNqGot, string QkvQplPbch, int ZzpHZTsZr, string XQPOubjhTsvHEi)
{
    double TKobFbOzrlGSsH = 368920.41574749304;
    int UijbrFbd = 1112066542;
    double gMtcUlN = 877241.4815604467;

    return ucysxNqGot;
}

int MyZertLyaaKWVf::rYHPJDZouUvRhJ(bool CmvBKitfSMhPUHo, int RetVPMHfUZwSapG, bool HNOKr, bool OruqWyhWtWMbGX)
{
    double JjJGzDIdtVYJu = -590989.0228682566;
    int mHzFwaY = 1846275039;
    int CyWgcLVbzoDvRcXk = 440036308;
    int jAAdYgoSIEATR = 1186847694;
    int facrKNxf = 902133968;
    bool EpIJZOYViUlCYB = true;
    double FCCcURZCX = 789598.7696688551;
    string SjnqDzUlrUun = string("METtUgqgsGBucsXeVFuutreagRWTGzxTTkJhsGVZunpwOMPdTcIkHEkBJKyIWrCVfSORQVCJeRWuwmAoINieYLXSZAVQLymLJvJAzXwDmLqbUppUA");

    for (int OqHnDYsbPddoAce = 1133525783; OqHnDYsbPddoAce > 0; OqHnDYsbPddoAce--) {
        facrKNxf += jAAdYgoSIEATR;
    }

    for (int NiyTZCAfff = 1310186935; NiyTZCAfff > 0; NiyTZCAfff--) {
        continue;
    }

    for (int dryZNZjSjbgx = 586772148; dryZNZjSjbgx > 0; dryZNZjSjbgx--) {
        continue;
    }

    return facrKNxf;
}

void MyZertLyaaKWVf::NqhnYgAYvAzPr(double pxBrBcNIuRo)
{
    bool VdYPWzevbtOv = true;
    string aswpc = string("QMPYgPFeuWSrBrmmtPqYXWvMgxnUMFPHYVRncOgAmdUuSRGxcbaJrtXUykfwEsbRArQjYOIswWtSAArjeWicJtgwbqWDrwhSzJuiOAliyZuQSqisKqdsOURHBPtCuQvdftZCtYdHxHfYhhEOlSRJbYRqfYCsHRfwXgjveGipFZnVCKFFfoeWQnHjSNLdhZyJrsIyFfXJQmvcDUYxxcLSndMl");
    bool JXgrJQh = true;
    double MnAcEXjxcRNP = -879814.1424894892;
    bool nPvqTvGi = false;
    int TlCnEnwKULyshm = 1631962346;

    for (int mhtdW = 563172572; mhtdW > 0; mhtdW--) {
        continue;
    }

    for (int GMLiTsubkxnzfue = 1857500321; GMLiTsubkxnzfue > 0; GMLiTsubkxnzfue--) {
        nPvqTvGi = nPvqTvGi;
        MnAcEXjxcRNP *= MnAcEXjxcRNP;
        VdYPWzevbtOv = ! VdYPWzevbtOv;
    }

    for (int sHHBotY = 592391671; sHHBotY > 0; sHHBotY--) {
        VdYPWzevbtOv = JXgrJQh;
    }

    for (int ZIJqkSof = 331458750; ZIJqkSof > 0; ZIJqkSof--) {
        VdYPWzevbtOv = VdYPWzevbtOv;
        pxBrBcNIuRo -= MnAcEXjxcRNP;
        JXgrJQh = ! VdYPWzevbtOv;
        nPvqTvGi = JXgrJQh;
    }

    for (int rTnXvhEyYGnGlok = 202386594; rTnXvhEyYGnGlok > 0; rTnXvhEyYGnGlok--) {
        MnAcEXjxcRNP = pxBrBcNIuRo;
        JXgrJQh = ! VdYPWzevbtOv;
    }

    for (int HbbQsnEbEVcb = 1003607486; HbbQsnEbEVcb > 0; HbbQsnEbEVcb--) {
        JXgrJQh = JXgrJQh;
    }

    for (int tDPHSZOOFjNUZt = 1284873851; tDPHSZOOFjNUZt > 0; tDPHSZOOFjNUZt--) {
        VdYPWzevbtOv = nPvqTvGi;
    }
}

int MyZertLyaaKWVf::dWGgUktF(bool GMyyZdWguBef, double HVZAHp)
{
    double lIpSnZNsaZbISHJp = -995489.5323601126;
    bool ebJmpjbROAIQMmVO = false;

    for (int gOcHFhnnQZnls = 2130044202; gOcHFhnnQZnls > 0; gOcHFhnnQZnls--) {
        GMyyZdWguBef = ebJmpjbROAIQMmVO;
        lIpSnZNsaZbISHJp *= lIpSnZNsaZbISHJp;
        ebJmpjbROAIQMmVO = ebJmpjbROAIQMmVO;
        GMyyZdWguBef = ebJmpjbROAIQMmVO;
        lIpSnZNsaZbISHJp *= lIpSnZNsaZbISHJp;
    }

    for (int ZdaXIV = 1627414559; ZdaXIV > 0; ZdaXIV--) {
        lIpSnZNsaZbISHJp *= HVZAHp;
        ebJmpjbROAIQMmVO = ebJmpjbROAIQMmVO;
        GMyyZdWguBef = ebJmpjbROAIQMmVO;
        lIpSnZNsaZbISHJp /= HVZAHp;
    }

    if (HVZAHp <= -995489.5323601126) {
        for (int BedjEQ = 1735798546; BedjEQ > 0; BedjEQ--) {
            ebJmpjbROAIQMmVO = ebJmpjbROAIQMmVO;
            HVZAHp /= HVZAHp;
            HVZAHp -= HVZAHp;
            ebJmpjbROAIQMmVO = GMyyZdWguBef;
            ebJmpjbROAIQMmVO = ! ebJmpjbROAIQMmVO;
            HVZAHp /= lIpSnZNsaZbISHJp;
        }
    }

    if (ebJmpjbROAIQMmVO != false) {
        for (int wHwNjhF = 42379735; wHwNjhF > 0; wHwNjhF--) {
            lIpSnZNsaZbISHJp += lIpSnZNsaZbISHJp;
        }
    }

    if (ebJmpjbROAIQMmVO != false) {
        for (int vNGrKP = 1757708768; vNGrKP > 0; vNGrKP--) {
            ebJmpjbROAIQMmVO = GMyyZdWguBef;
            ebJmpjbROAIQMmVO = ebJmpjbROAIQMmVO;
            HVZAHp *= HVZAHp;
            ebJmpjbROAIQMmVO = ! ebJmpjbROAIQMmVO;
        }
    }

    return 418115253;
}

string MyZertLyaaKWVf::oILyfuQzlg(bool DhxNmYYRNfQADIb)
{
    string CidutKuJsubc = string("CIUxwijfzbbLhJAIWUTcgscXDkuxDH");
    bool SbdYRQaG = false;
    bool GeIobllktaVGplf = false;
    double ttroJZNEYyzlHuj = -551358.3810121141;
    string jrODmlbvhqHZYyqv = string("CpPavKMxlvJTGwVvyFwaSrJCCcdqMtMsLSGGAXrvtsnUgFpLgnNsMiCPMHiIkkdRrObjopWNTMdbWcwZwrPXBuMwwNtXRZfqoLPnQsSsxGGyLbFeQYZuerlhMNHuxurDxoZFGOyeLgovlSxGLvslxzBdsyhfxorHMGpyFwmhPPhRDaxvGsKNGVKBxbewjXCHMIUQctegVeOqaauqraLZLoJOwjgapscmYKmHag");
    string MTHRjKAgmxvOP = string("PWOAxBTtYUkzkhALGsZJeNdRACKDkkuglvGtRBkvILMLuGDrYGQZaMygjHpTiGjsAjdgvLqpASXSIjjzPZusTJPHUtqxEEDUqgbzDqFQcfkWJlsPRJir");

    for (int KnNSGqXWffNMIVkf = 1113523602; KnNSGqXWffNMIVkf > 0; KnNSGqXWffNMIVkf--) {
        MTHRjKAgmxvOP += MTHRjKAgmxvOP;
    }

    if (MTHRjKAgmxvOP < string("CpPavKMxlvJTGwVvyFwaSrJCCcdqMtMsLSGGAXrvtsnUgFpLgnNsMiCPMHiIkkdRrObjopWNTMdbWcwZwrPXBuMwwNtXRZfqoLPnQsSsxGGyLbFeQYZuerlhMNHuxurDxoZFGOyeLgovlSxGLvslxzBdsyhfxorHMGpyFwmhPPhRDaxvGsKNGVKBxbewjXCHMIUQctegVeOqaauqraLZLoJOwjgapscmYKmHag")) {
        for (int BtdtjL = 572068303; BtdtjL > 0; BtdtjL--) {
            ttroJZNEYyzlHuj = ttroJZNEYyzlHuj;
            GeIobllktaVGplf = DhxNmYYRNfQADIb;
            CidutKuJsubc += CidutKuJsubc;
        }
    }

    for (int qbewKwpta = 35093640; qbewKwpta > 0; qbewKwpta--) {
        continue;
    }

    for (int tVwTGSoYpto = 899850997; tVwTGSoYpto > 0; tVwTGSoYpto--) {
        continue;
    }

    return MTHRjKAgmxvOP;
}

double MyZertLyaaKWVf::NeyqLdU()
{
    string srrkX = string("umWdElzrwuDiiEQDMVsLxIPXKDFoIJyKnidIFyxVhwHREJWhrloScLajviv");
    bool NzeaR = false;
    string itjtFwDV = string("LlDxuBHInQwjnULaxjsKuEeenUBWJTQBbMKkHanGVZiIrHUXHBiPVOpLIjJsEJMiHQptrQhadyHdzydiIoBFTLiBUTDyvQAdOMvAEDYyDqvSWfjZgFhenMvOBlWYsoTyyxIuwbjhcgzsNfFIgaxXwiVQQkTfmZCqcelxbUaWdiMXVJftKAibCtDFaohTDALBEncwTgWTSDJlSpmBjfpaSxvGtBp");

    for (int WCPShHx = 1709425169; WCPShHx > 0; WCPShHx--) {
        srrkX += itjtFwDV;
        itjtFwDV = srrkX;
        srrkX += itjtFwDV;
        srrkX += srrkX;
        itjtFwDV += itjtFwDV;
    }

    if (itjtFwDV <= string("LlDxuBHInQwjnULaxjsKuEeenUBWJTQBbMKkHanGVZiIrHUXHBiPVOpLIjJsEJMiHQptrQhadyHdzydiIoBFTLiBUTDyvQAdOMvAEDYyDqvSWfjZgFhenMvOBlWYsoTyyxIuwbjhcgzsNfFIgaxXwiVQQkTfmZCqcelxbUaWdiMXVJftKAibCtDFaohTDALBEncwTgWTSDJlSpmBjfpaSxvGtBp")) {
        for (int CvvVCmII = 766734421; CvvVCmII > 0; CvvVCmII--) {
            itjtFwDV = srrkX;
            itjtFwDV += srrkX;
        }
    }

    for (int wVlctuXXyHl = 2116703250; wVlctuXXyHl > 0; wVlctuXXyHl--) {
        itjtFwDV = itjtFwDV;
        NzeaR = ! NzeaR;
    }

    if (itjtFwDV < string("LlDxuBHInQwjnULaxjsKuEeenUBWJTQBbMKkHanGVZiIrHUXHBiPVOpLIjJsEJMiHQptrQhadyHdzydiIoBFTLiBUTDyvQAdOMvAEDYyDqvSWfjZgFhenMvOBlWYsoTyyxIuwbjhcgzsNfFIgaxXwiVQQkTfmZCqcelxbUaWdiMXVJftKAibCtDFaohTDALBEncwTgWTSDJlSpmBjfpaSxvGtBp")) {
        for (int uReETUSJ = 184811818; uReETUSJ > 0; uReETUSJ--) {
            itjtFwDV = itjtFwDV;
            srrkX = srrkX;
            itjtFwDV += itjtFwDV;
            NzeaR = ! NzeaR;
            srrkX += srrkX;
            NzeaR = NzeaR;
        }
    }

    return 495061.4795126422;
}

bool MyZertLyaaKWVf::dFdKcMbjfl(string fXggvBQFDyI)
{
    int QFbnJFmOeFyniI = -2052839263;
    string lkTDrE = string("yEngmdZILOacndwcRwMAEPbnMowAsJGNrvaoMPELYoOFBahbdJKxtfqfGBAEYRLxUtUcAVvqgyjQRpllhwaTSuylnHxSrozyEbkKsRidvNOXUpAJjUFwgjeqQWsNQqNNRzHuNtfCQhEFKoAWwOMGKRmIfGxWUnrNsQtvTjfbGpfRdCPyAzCGacOlEVdNAHRIQZqXOgLVlLzrCbejrHdzeypzsaheMcOVZkjfYDLOELhW");

    for (int RKeLb = 843772245; RKeLb > 0; RKeLb--) {
        fXggvBQFDyI = lkTDrE;
        QFbnJFmOeFyniI = QFbnJFmOeFyniI;
        QFbnJFmOeFyniI -= QFbnJFmOeFyniI;
        lkTDrE += lkTDrE;
    }

    for (int TbjdmMgsgKa = 903927029; TbjdmMgsgKa > 0; TbjdmMgsgKa--) {
        fXggvBQFDyI += lkTDrE;
        fXggvBQFDyI = fXggvBQFDyI;
    }

    for (int BzufP = 1278821793; BzufP > 0; BzufP--) {
        QFbnJFmOeFyniI = QFbnJFmOeFyniI;
        fXggvBQFDyI += fXggvBQFDyI;
        QFbnJFmOeFyniI = QFbnJFmOeFyniI;
        QFbnJFmOeFyniI /= QFbnJFmOeFyniI;
        lkTDrE += lkTDrE;
    }

    return false;
}

void MyZertLyaaKWVf::MOXXswhFIdRMZQ(double LUkgHHrk, double ldCSfqPScF, string EQqSlppaG, string eNWzbQZ)
{
    double kWGVcZLwpu = 255458.76963353038;
    int ZPBphRmKX = -1773268179;
    int MfgRaBO = -1249411946;
    double nCwLPli = 365970.31426282664;

    if (eNWzbQZ >= string("LXQTuHBtGmKIcNj")) {
        for (int GCrPqjAatEhngG = 936774721; GCrPqjAatEhngG > 0; GCrPqjAatEhngG--) {
            LUkgHHrk -= kWGVcZLwpu;
        }
    }

    for (int MBowKCyNfV = 1750317129; MBowKCyNfV > 0; MBowKCyNfV--) {
        kWGVcZLwpu /= kWGVcZLwpu;
        nCwLPli /= LUkgHHrk;
        nCwLPli -= LUkgHHrk;
        LUkgHHrk /= LUkgHHrk;
        eNWzbQZ = EQqSlppaG;
    }

    for (int cQIhkukfV = 533105611; cQIhkukfV > 0; cQIhkukfV--) {
        nCwLPli -= LUkgHHrk;
        ldCSfqPScF /= nCwLPli;
        LUkgHHrk /= LUkgHHrk;
        LUkgHHrk = nCwLPli;
        LUkgHHrk *= LUkgHHrk;
        nCwLPli += ldCSfqPScF;
    }

    for (int UsFxZZBult = 832739185; UsFxZZBult > 0; UsFxZZBult--) {
        EQqSlppaG += eNWzbQZ;
    }

    if (ldCSfqPScF >= 464806.8010017583) {
        for (int ZhnLDqFeEn = 1449950187; ZhnLDqFeEn > 0; ZhnLDqFeEn--) {
            LUkgHHrk -= kWGVcZLwpu;
        }
    }
}

bool MyZertLyaaKWVf::uCimlI(bool CpDGWIYTuCYuTu, double HNhqPZrAKc, double GrcAh, double UCoaMavYkXdbRJnG, double sewgGwW)
{
    int INlWc = 877771906;
    int wTMDyfHZTefKoqjl = 55553133;
    int JZomVsxElO = 2003981428;
    double lNjqJi = 778268.4199451478;
    string UVKxEHHhIwbWk = string("XciKsNLdnBrnRFcqJqTZocPtlwNJqiuHgMEQQuXHuqLjQAABMjJJRRYMlwTMpuyJxGjmuLOuvjtPHBgrhbjkMyqurtjaBMDratTbopTVcAEbBvJurGpHRTdpyMIXFaPRodjhglvNBezxuAmTVbVSvQAleZldzWatbdxCcHVhZGNzPQGNshUshIBCulDaVLTyJ");

    for (int KUTwsTOulMpO = 1867500287; KUTwsTOulMpO > 0; KUTwsTOulMpO--) {
        INlWc -= JZomVsxElO;
        JZomVsxElO *= wTMDyfHZTefKoqjl;
        wTMDyfHZTefKoqjl /= wTMDyfHZTefKoqjl;
        HNhqPZrAKc /= HNhqPZrAKc;
        HNhqPZrAKc -= sewgGwW;
    }

    if (UVKxEHHhIwbWk > string("XciKsNLdnBrnRFcqJqTZocPtlwNJqiuHgMEQQuXHuqLjQAABMjJJRRYMlwTMpuyJxGjmuLOuvjtPHBgrhbjkMyqurtjaBMDratTbopTVcAEbBvJurGpHRTdpyMIXFaPRodjhglvNBezxuAmTVbVSvQAleZldzWatbdxCcHVhZGNzPQGNshUshIBCulDaVLTyJ")) {
        for (int vOVButgmfr = 1109696094; vOVButgmfr > 0; vOVButgmfr--) {
            HNhqPZrAKc += lNjqJi;
        }
    }

    for (int vFtUqrwmVBvWSkI = 2086092450; vFtUqrwmVBvWSkI > 0; vFtUqrwmVBvWSkI--) {
        wTMDyfHZTefKoqjl += INlWc;
        lNjqJi *= GrcAh;
        JZomVsxElO /= INlWc;
        wTMDyfHZTefKoqjl *= JZomVsxElO;
    }

    if (HNhqPZrAKc == -251649.05834926767) {
        for (int WnIKKOW = 1953229812; WnIKKOW > 0; WnIKKOW--) {
            continue;
        }
    }

    if (lNjqJi >= 648837.3350776669) {
        for (int bgSimcLg = 1109415934; bgSimcLg > 0; bgSimcLg--) {
            sewgGwW += UCoaMavYkXdbRJnG;
        }
    }

    for (int vmcpFWiw = 371421811; vmcpFWiw > 0; vmcpFWiw--) {
        lNjqJi = sewgGwW;
    }

    return CpDGWIYTuCYuTu;
}

string MyZertLyaaKWVf::PnmacJjsS(int YveTSt, double eQiyFBERSQtk, double gAUTrGajeXgH, int VRvlRVGfZfLqtA)
{
    string CCVhUroZglMFMN = string("wOCVWJWzSbnkfwxceHycJfKPZWpmffNyHu");
    bool YufbppmtcY = false;
    bool VXdpuIILhYR = true;
    string ZgDGjz = string("NAzfZenZpKfZWpNvSgcmVgRMOTitpLOdocmkIfoNEaCgyoKTcwkjuQGIqfcDLFIdAmRFIrUnslDsuSlGnpBgiBpGUmzvoccrLbAG");
    string ViCKelOYXFJJvRHf = string("CQaSUjIJdyLRrkUrdNyOywqXFNnmDpBnbwYkwvemvbqJkbqFaFhSPmvWLGmNbWFjxamcpkaVkrPfDxKoKptfoUMeZDjkOzohzHzKGNaYAvfrvYwUDdKPObiJvWscCwutvFrLyUZsSQzDDGInhHkKlHKkwmQmKCRoBMZbqkFFUcavzsadsbnccSiGcauyTvygwYhssBAGFxqcQzItqNlEgrTMoVeWPjThMPkLHMqio");
    int AeGpG = -1105371843;
    int uNJCK = -1842814055;
    string rWjaNXhh = string("zfdllfKNTC");
    string ZVylYdjXf = string("rXrAJIaWmWSspAQvsHrUzcFsTcpByvZJTOHgwTvRVUVjd");
    double KmBlDZuGPGdwGNGX = 265135.5197387969;

    return ZVylYdjXf;
}

string MyZertLyaaKWVf::NwFkv()
{
    bool hPBMghGzIRFOWNPq = false;
    bool iafDB = true;
    double xqLjMlsGL = 783635.6784209782;
    bool dModjYPy = false;
    bool uTXrTOMQTVM = false;
    double PjrPUydQkGZEquvc = -944350.3503238822;
    double JGoevbt = 149586.61394259697;
    string QfnskliwsVKuIg = string("hbuMgWcxCeujAZWjTnZDgDjZronmjAcCeiIuXCuQEsGRdmFyrOqBIycDUrInCLDxKdcgWtPYUJfXapBkxUyWDRVdfksNOeoUtkbzgmZBZdcKikiOmcTsvUtwAQLgGQAycPUCocBQLJZxNbICqCLECDLrPwDXXtuPoYTdjTLYmsNJMxibumyuDziikAfPyFqnO");
    int iCWFmMdJCWioA = 2052105808;

    if (xqLjMlsGL != 783635.6784209782) {
        for (int yOHgTnmzXahqR = 665160452; yOHgTnmzXahqR > 0; yOHgTnmzXahqR--) {
            iafDB = iafDB;
            uTXrTOMQTVM = ! hPBMghGzIRFOWNPq;
            uTXrTOMQTVM = ! iafDB;
        }
    }

    if (xqLjMlsGL != 783635.6784209782) {
        for (int grGAvrN = 349955811; grGAvrN > 0; grGAvrN--) {
            JGoevbt /= JGoevbt;
        }
    }

    if (JGoevbt > -944350.3503238822) {
        for (int BCircZOuPI = 861199094; BCircZOuPI > 0; BCircZOuPI--) {
            hPBMghGzIRFOWNPq = ! hPBMghGzIRFOWNPq;
            dModjYPy = ! dModjYPy;
        }
    }

    if (JGoevbt < -944350.3503238822) {
        for (int IZQIwXWHQ = 820920910; IZQIwXWHQ > 0; IZQIwXWHQ--) {
            QfnskliwsVKuIg = QfnskliwsVKuIg;
            uTXrTOMQTVM = ! hPBMghGzIRFOWNPq;
            uTXrTOMQTVM = ! hPBMghGzIRFOWNPq;
        }
    }

    for (int AfiyLZ = 973872661; AfiyLZ > 0; AfiyLZ--) {
        dModjYPy = hPBMghGzIRFOWNPq;
        iafDB = uTXrTOMQTVM;
        dModjYPy = ! iafDB;
    }

    if (uTXrTOMQTVM != false) {
        for (int qVQzYjNk = 1460186081; qVQzYjNk > 0; qVQzYjNk--) {
            dModjYPy = ! uTXrTOMQTVM;
        }
    }

    for (int EkXjhQTwvCT = 1306950486; EkXjhQTwvCT > 0; EkXjhQTwvCT--) {
        dModjYPy = ! uTXrTOMQTVM;
        dModjYPy = uTXrTOMQTVM;
        JGoevbt = xqLjMlsGL;
        dModjYPy = hPBMghGzIRFOWNPq;
    }

    if (xqLjMlsGL == -944350.3503238822) {
        for (int WDEvfUxzHZxuZMGN = 668434060; WDEvfUxzHZxuZMGN > 0; WDEvfUxzHZxuZMGN--) {
            uTXrTOMQTVM = hPBMghGzIRFOWNPq;
            xqLjMlsGL = JGoevbt;
        }
    }

    return QfnskliwsVKuIg;
}

bool MyZertLyaaKWVf::ITUHA(double NvSpZKDROHHdFdqv, double riGJBgHLUIvddDnN, double xYBZeFhAqNga)
{
    int ywjqEfjcOZ = 1286090499;
    bool lQRrTa = true;
    double NGzDxWjqqpM = 753367.657520647;
    int XDUaKOk = -531981198;

    if (riGJBgHLUIvddDnN > 753367.657520647) {
        for (int fOjyq = 1973583294; fOjyq > 0; fOjyq--) {
            NvSpZKDROHHdFdqv += riGJBgHLUIvddDnN;
            NGzDxWjqqpM *= NGzDxWjqqpM;
            NvSpZKDROHHdFdqv /= NvSpZKDROHHdFdqv;
            riGJBgHLUIvddDnN = xYBZeFhAqNga;
            ywjqEfjcOZ *= XDUaKOk;
        }
    }

    return lQRrTa;
}

int MyZertLyaaKWVf::BLQnLbD(int ABfXdkOrxm, bool RnKKHNFEYW, int EEVXRX)
{
    string SdmRWbZidNKyDpew = string("eJtCYTKvQnPFtNBBCPokaxRXUKAbMhKWCoIOevmgTkNDhxhXjGgaxoFJMBcvZAVRlozWUIaAHGgezIciGmqQWRIZmvHYkFfjradsx");
    string iHNEmEg = string("AAaCJbIjGNmMWmgesiRubrnoWjBGhsdLjxLvyEIaueTcQWTbfkiMaakMItIiyHskhinTKtyOLzYmblWmSsQoxHZqHZjKVVpfyXQEIQfKlmVXOSSWuZmrxyBKHhKyFzFnpNamPSZeSANlDErpVRgtuodAdTITMkRGxLqRQSNfuAsjyBDoJEGKtUwfHMtDi");
    int uLflxgOplZmayqDg = 1300183465;
    double mbemVQMTcRJEa = 626186.2123328048;
    double hoHqPPhoUNTRRU = -897991.3608484609;

    return uLflxgOplZmayqDg;
}

double MyZertLyaaKWVf::AHmnjpr()
{
    double yUXZu = 816219.4680690982;
    double xpMTnagwBELuK = 920174.7987860895;
    double GhqDLqAxgb = 933768.9504791531;
    bool WdCMqY = true;
    double upxIrqdo = 836560.6482822951;

    if (upxIrqdo >= 933768.9504791531) {
        for (int ntksvptLyuPMBr = 1932780443; ntksvptLyuPMBr > 0; ntksvptLyuPMBr--) {
            yUXZu -= xpMTnagwBELuK;
            yUXZu /= GhqDLqAxgb;
            upxIrqdo = yUXZu;
            yUXZu += upxIrqdo;
            GhqDLqAxgb += GhqDLqAxgb;
            GhqDLqAxgb -= xpMTnagwBELuK;
        }
    }

    for (int FsMrEJ = 1080166061; FsMrEJ > 0; FsMrEJ--) {
        xpMTnagwBELuK -= yUXZu;
        GhqDLqAxgb *= yUXZu;
        xpMTnagwBELuK *= GhqDLqAxgb;
        GhqDLqAxgb /= upxIrqdo;
        yUXZu = yUXZu;
    }

    return upxIrqdo;
}

int MyZertLyaaKWVf::WjlQDibm(double QbGHxgaongseSgW, double pxxHastmFHPFSbYQ, double nQFsldXA, bool gtTHdzNcvVZ)
{
    string vveDXXnBZFfE = string("OXBHdjQUdLbSMLRyShqQSpjmhCMhBVWRIvzKXRUIvCBIAMldxELbajlVDevIXIOKAwmqWkRHpUTbdOCDNnqARZUAujBaEnMAYfgtnxGEcIKYkBYaXZxcrVBJrDTDOfaCCAUSKHSTDIidAUJuJnvddEokQbtnuwnMZXcfNzCKXRZsLOVJRCpFOnWQRWnsQxMaqQznKSeryBIzkbcoEyvzvBsXHclkReoJYtTsFNLMWymgZh");

    for (int wdAcG = 941491017; wdAcG > 0; wdAcG--) {
        QbGHxgaongseSgW = nQFsldXA;
    }

    for (int FHmzogtyWhLdhiIu = 584676149; FHmzogtyWhLdhiIu > 0; FHmzogtyWhLdhiIu--) {
        pxxHastmFHPFSbYQ = pxxHastmFHPFSbYQ;
        pxxHastmFHPFSbYQ = pxxHastmFHPFSbYQ;
        pxxHastmFHPFSbYQ -= nQFsldXA;
    }

    for (int wFQZagPG = 1965073903; wFQZagPG > 0; wFQZagPG--) {
        QbGHxgaongseSgW -= nQFsldXA;
    }

    if (pxxHastmFHPFSbYQ != 339100.2488374759) {
        for (int JOfmlrMxJ = 1658368574; JOfmlrMxJ > 0; JOfmlrMxJ--) {
            nQFsldXA *= QbGHxgaongseSgW;
            vveDXXnBZFfE = vveDXXnBZFfE;
            QbGHxgaongseSgW -= pxxHastmFHPFSbYQ;
        }
    }

    for (int LvvLQjsR = 1442533998; LvvLQjsR > 0; LvvLQjsR--) {
        gtTHdzNcvVZ = ! gtTHdzNcvVZ;
        nQFsldXA = pxxHastmFHPFSbYQ;
        QbGHxgaongseSgW += QbGHxgaongseSgW;
    }

    for (int IebleqsuQcjm = 898832164; IebleqsuQcjm > 0; IebleqsuQcjm--) {
        QbGHxgaongseSgW += nQFsldXA;
        QbGHxgaongseSgW *= nQFsldXA;
        QbGHxgaongseSgW *= nQFsldXA;
        QbGHxgaongseSgW += nQFsldXA;
        QbGHxgaongseSgW /= pxxHastmFHPFSbYQ;
    }

    for (int uCIRCfmKpJEqy = 1966020738; uCIRCfmKpJEqy > 0; uCIRCfmKpJEqy--) {
        QbGHxgaongseSgW = pxxHastmFHPFSbYQ;
        nQFsldXA /= nQFsldXA;
        QbGHxgaongseSgW -= QbGHxgaongseSgW;
        QbGHxgaongseSgW /= QbGHxgaongseSgW;
        nQFsldXA -= QbGHxgaongseSgW;
    }

    return -160784770;
}

int MyZertLyaaKWVf::CokiLlTowPozTEh(double fYuzdKIqIGtnNfE, double WVnbiriKAyqEn)
{
    double shTENePdmkwdPx = 157160.93468726423;
    double COmlVNnToEtxGijV = 557011.5418970073;

    if (shTENePdmkwdPx < 439268.1623711042) {
        for (int hPyfbjA = 1707821988; hPyfbjA > 0; hPyfbjA--) {
            fYuzdKIqIGtnNfE -= fYuzdKIqIGtnNfE;
            fYuzdKIqIGtnNfE = shTENePdmkwdPx;
            shTENePdmkwdPx += COmlVNnToEtxGijV;
            WVnbiriKAyqEn = shTENePdmkwdPx;
            fYuzdKIqIGtnNfE += shTENePdmkwdPx;
            WVnbiriKAyqEn += COmlVNnToEtxGijV;
            WVnbiriKAyqEn *= shTENePdmkwdPx;
            fYuzdKIqIGtnNfE += fYuzdKIqIGtnNfE;
            fYuzdKIqIGtnNfE *= COmlVNnToEtxGijV;
            shTENePdmkwdPx -= shTENePdmkwdPx;
        }
    }

    if (shTENePdmkwdPx <= 157160.93468726423) {
        for (int WYTNLYZdsukV = 706391328; WYTNLYZdsukV > 0; WYTNLYZdsukV--) {
            COmlVNnToEtxGijV *= shTENePdmkwdPx;
            COmlVNnToEtxGijV /= fYuzdKIqIGtnNfE;
            shTENePdmkwdPx *= shTENePdmkwdPx;
            COmlVNnToEtxGijV += COmlVNnToEtxGijV;
            COmlVNnToEtxGijV *= COmlVNnToEtxGijV;
            COmlVNnToEtxGijV = shTENePdmkwdPx;
            COmlVNnToEtxGijV = fYuzdKIqIGtnNfE;
            fYuzdKIqIGtnNfE = WVnbiriKAyqEn;
            fYuzdKIqIGtnNfE += shTENePdmkwdPx;
        }
    }

    if (COmlVNnToEtxGijV != -662520.4779832511) {
        for (int upVzKDTaLotzPX = 1105598627; upVzKDTaLotzPX > 0; upVzKDTaLotzPX--) {
            fYuzdKIqIGtnNfE /= WVnbiriKAyqEn;
        }
    }

    if (COmlVNnToEtxGijV <= 157160.93468726423) {
        for (int eijtPg = 1797654881; eijtPg > 0; eijtPg--) {
            WVnbiriKAyqEn += fYuzdKIqIGtnNfE;
            shTENePdmkwdPx = shTENePdmkwdPx;
            shTENePdmkwdPx /= fYuzdKIqIGtnNfE;
            fYuzdKIqIGtnNfE += COmlVNnToEtxGijV;
            WVnbiriKAyqEn *= COmlVNnToEtxGijV;
        }
    }

    if (fYuzdKIqIGtnNfE >= 557011.5418970073) {
        for (int iSZSuoPWaFWC = 1282266651; iSZSuoPWaFWC > 0; iSZSuoPWaFWC--) {
            fYuzdKIqIGtnNfE = COmlVNnToEtxGijV;
            shTENePdmkwdPx -= fYuzdKIqIGtnNfE;
            COmlVNnToEtxGijV *= COmlVNnToEtxGijV;
            WVnbiriKAyqEn += WVnbiriKAyqEn;
            COmlVNnToEtxGijV += fYuzdKIqIGtnNfE;
            shTENePdmkwdPx = fYuzdKIqIGtnNfE;
            fYuzdKIqIGtnNfE *= WVnbiriKAyqEn;
            shTENePdmkwdPx *= WVnbiriKAyqEn;
            COmlVNnToEtxGijV += shTENePdmkwdPx;
        }
    }

    return -1459005017;
}

MyZertLyaaKWVf::MyZertLyaaKWVf()
{
    this->DFNgYpfdd(false, false, string("NDyiWzoWxXwUIwByEGTyXJsWNqoPMBYWjhamhOvCxHajncXHVLDJpaQLKudcaZqIIimVIyTqfrFTMjQBNNzuacsKKUEVRlcJYqekplIXHDnbHIpdVLOjODmAaWXBUkYecxMWMVByfZogdxohLfbLsmeSrGPtydbTkTLBGefkBYXsaSYNpYWMGOUxEBJhIkRVUMHAwO"), 355045912, string("EavxuMLnjkbHDkIxCxoBRQmgMXAtbPccapMauvBoiQkPcZzHSswMvhFUyWBKATuAPyIfLYRmLxPYDnzQDHfVVDzQZSikduOlXbsZUBXpWJBxglhzaOgteIUD"));
    this->rYHPJDZouUvRhJ(true, -1752914083, false, true);
    this->NqhnYgAYvAzPr(50895.090601770986);
    this->dWGgUktF(false, -99411.06540968324);
    this->oILyfuQzlg(false);
    this->NeyqLdU();
    this->dFdKcMbjfl(string("WqKJkZnLATRfBGQigAucgfFfjGhzTiTyueJnHnZscFovAMYEWqlPLwWESqaItoOPdpXRrUaSgHIWQvMJYFsyhVamMrJRXhvKiBgVbDlHZjrcljlqKkTuZvZQirfVseHZziEkuVQGKlEdVRXniGQfvmaNTitGgjsgfPgGspgRZytBMAhyMYeoJgUMTMwbzwTRcmV"));
    this->MOXXswhFIdRMZQ(157104.8252289571, 464806.8010017583, string("LXQTuHBtGmKIcNj"), string("gDmGKZgtHpIWTELGDyYtqTyhsKnzygxbyUuYBRIWvKhqbQuTlljWGJHsJKwzoKVubndmPxDHvBCNdBXMiUzdLxkVIQrkLRcdamAZtXfZXFWMpqLqXTSqWsgKSBIyyEuFViIMyxNwMHeaLUtTkBFhwskwtQAxhzTnBqsCuyJmlHtqqGmSwMGJeceYMsNm"));
    this->uCimlI(true, 648837.3350776669, 724384.484715922, -251649.05834926767, -372529.1234038434);
    this->PnmacJjsS(1173491325, 568674.1811979132, -503339.4544808711, 617881428);
    this->NwFkv();
    this->ITUHA(677667.061983219, -179463.15908885826, -707301.9579202381);
    this->BLQnLbD(-1101323188, false, -1046136563);
    this->AHmnjpr();
    this->WjlQDibm(339100.2488374759, 265110.2624975385, 69974.26545119041, true);
    this->CokiLlTowPozTEh(-662520.4779832511, 439268.1623711042);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OmWVQdWIYYYtfelv
{
public:
    bool WqFIdqql;

    OmWVQdWIYYYtfelv();
    void GIeUUSdeCd(double FZiheJMGdb, int yRyzAqMdFSQmVy);
    bool EwJMXvGDWWTSTv(double NfmleAjRUkYiXxLC, bool EAhLxRhkBHJby, bool HaHbgBcMUsRl);
    double qLyTxIuS();
    int sORvg(bool CxWDhU);
    void yWHdmkqpw(double DPJRvnNNILAxcYz, double ODEVsjfSsPEaVmoU, double YpArfCOFT, bool gsWjGPnuRKSlW, bool XNEKLfr);
    void XSRWu(bool emEiIaFOXKGeNEF);
protected:
    string uuDMa;
    bool PNHKrSzlLm;
    int toyuxh;
    bool kZhNPDZrP;
    bool clPrUfaCq;

    string hsMInR(string rwReJqv, bool RygMtlYH, bool DKPBEsXTzM);
    int BPOJtKPTwDSU(double ZMCwgpmghMgna);
    bool VVNgTfrqbjQ(string hSNTa, string PAwpBFscZQkhQ);
    string MYLwnAEmdLV(bool ZucscjdIs, bool SSfQFSvjoqlP, string FvhyFRcrJUyIUe, bool ApGdGaQACd);
    double cRjnehoGXlWlF(double CyJmadUZM, string tfhakWo);
    int rLrjYI(int mRfhQzV);
    int FpffGt();
private:
    int WwZpMBESt;
    double UYwFnfjhZtKFaHRN;
    bool ZCslJGosEd;
    int jdBsnwGLFj;
    double RiciNlxgiYiYqrSA;
    string qrwoyx;

    int AEyTFWxHg(int moOFcSOUZ, int RjgqagwavZHN, bool AVswIyIqSGmzPZ);
    string WFsZlw(string CKKiLeKVCgZNk, string GmiledvA, int uksYqbAjsUBvk, double NTtyU, string AKVAAsCVscGtc);
};

void OmWVQdWIYYYtfelv::GIeUUSdeCd(double FZiheJMGdb, int yRyzAqMdFSQmVy)
{
    bool cmFHxTduKCppdPh = false;
    double tJXxo = -822907.6144051183;
    int RRHAzTB = 426805788;
    double jaWFyWHWl = 750147.4926509054;
    string yZVyLjiVTl = string("IOKMgjmzttGUaAUvDEDVWTvYUINfFaYWBINVycdqhrvjKpnZizsUkVcHcEKSvmWhrzKwvdUmnxFSiIkuBxZPXxczzaybdyEFdZwhTrFtTOHrMpBFrEpZbSpSYMKCWIZugqYsDWTDaxNvYEpIQowJmyGJEXebJcVfQvlrMfWuiqZbAoskCLSVqPcqsvlgkMPTAtJjOoVKQozohKbgwHqjQmvsDatJiLLReEXLdddWmBnA");
    bool IEMmaxMsFya = false;

    if (yRyzAqMdFSQmVy != 426805788) {
        for (int cMhBUpPHpzeJFOfV = 2073154810; cMhBUpPHpzeJFOfV > 0; cMhBUpPHpzeJFOfV--) {
            yRyzAqMdFSQmVy += RRHAzTB;
        }
    }

    for (int NBXFHclcoF = 465904948; NBXFHclcoF > 0; NBXFHclcoF--) {
        continue;
    }

    for (int OhLam = 123406426; OhLam > 0; OhLam--) {
        IEMmaxMsFya = cmFHxTduKCppdPh;
        tJXxo /= tJXxo;
        jaWFyWHWl += jaWFyWHWl;
    }

    for (int paNxWYR = 569476769; paNxWYR > 0; paNxWYR--) {
        continue;
    }
}

bool OmWVQdWIYYYtfelv::EwJMXvGDWWTSTv(double NfmleAjRUkYiXxLC, bool EAhLxRhkBHJby, bool HaHbgBcMUsRl)
{
    bool OZjBHeVWOeYN = true;
    int zrwwDmQDGw = 1254179581;
    int rVFZUVIeJIzQNpri = -2017008610;
    bool CoqKSWHZi = true;

    for (int XjrbImghsQHexOPP = 2028290821; XjrbImghsQHexOPP > 0; XjrbImghsQHexOPP--) {
        HaHbgBcMUsRl = ! CoqKSWHZi;
        EAhLxRhkBHJby = ! HaHbgBcMUsRl;
    }

    if (zrwwDmQDGw <= -2017008610) {
        for (int BwtLFx = 1711396865; BwtLFx > 0; BwtLFx--) {
            zrwwDmQDGw += rVFZUVIeJIzQNpri;
        }
    }

    for (int dJgOALLxPEM = 1867146193; dJgOALLxPEM > 0; dJgOALLxPEM--) {
        CoqKSWHZi = CoqKSWHZi;
        rVFZUVIeJIzQNpri += rVFZUVIeJIzQNpri;
        CoqKSWHZi = ! EAhLxRhkBHJby;
        CoqKSWHZi = CoqKSWHZi;
    }

    for (int ZRwoVc = 1467754743; ZRwoVc > 0; ZRwoVc--) {
        CoqKSWHZi = CoqKSWHZi;
        HaHbgBcMUsRl = ! OZjBHeVWOeYN;
        EAhLxRhkBHJby = EAhLxRhkBHJby;
    }

    return CoqKSWHZi;
}

double OmWVQdWIYYYtfelv::qLyTxIuS()
{
    bool GRilsdIHOBS = false;
    int TkNCGnLHtp = -981419562;
    string DOXOzzlHjzX = string("TtjXzWWzuebVoupPOiqLKrHKYrZfiQAwFlCvlCFbetCrIBmcTfssJQAAqEystyhPpaAMZLCsMbhOfpSIgJfTTVELXfWTaUzbzeZemQ");
    string RwhGxTW = string("jljZgyoNgqGfKJSAvkJAjmmUGjqaMRYGdYGbiJAMQAcLIvATTqvtUFqVbUjrYJDvqqzAgYgIUZLefGebtfOvhhkBAFIebDrKqhSMHWtfyhUNAmyNFOayFWkjZGnH");
    double GaVIhu = -741514.9091737142;
    string AJkVYJhmIPfeRQB = string("cwpvIprqdGdYfhYlIExFcwjHqUUhznYHYoOsjNurlmhaD");
    bool RljaHyKllOc = true;
    bool XadATHgwNcO = false;

    for (int NxORfQwVteHvjdQ = 188790427; NxORfQwVteHvjdQ > 0; NxORfQwVteHvjdQ--) {
        DOXOzzlHjzX += RwhGxTW;
    }

    return GaVIhu;
}

int OmWVQdWIYYYtfelv::sORvg(bool CxWDhU)
{
    double TAmwOyhaZQJKe = -899475.9903655924;
    int TVtONzcggiAsYi = -321363959;
    bool PJEwHZHCi = false;
    double oDyjZbBeIc = -932017.3430429923;
    double cGjLDBbNudR = 715719.5859678357;
    double ZadpFQU = -343060.64727815136;
    int mYLSJen = 1595898271;
    bool gxhamv = false;

    if (oDyjZbBeIc < -343060.64727815136) {
        for (int DGcXaAvUHpF = 2057057942; DGcXaAvUHpF > 0; DGcXaAvUHpF--) {
            continue;
        }
    }

    for (int OiArMZqYeSUwBTY = 2103687334; OiArMZqYeSUwBTY > 0; OiArMZqYeSUwBTY--) {
        PJEwHZHCi = ! CxWDhU;
        CxWDhU = ! PJEwHZHCi;
        cGjLDBbNudR /= ZadpFQU;
        ZadpFQU = oDyjZbBeIc;
    }

    return mYLSJen;
}

void OmWVQdWIYYYtfelv::yWHdmkqpw(double DPJRvnNNILAxcYz, double ODEVsjfSsPEaVmoU, double YpArfCOFT, bool gsWjGPnuRKSlW, bool XNEKLfr)
{
    double XaUrTHrH = 736085.9570274139;

    if (XNEKLfr != false) {
        for (int BWygnM = 1058692467; BWygnM > 0; BWygnM--) {
            XaUrTHrH /= YpArfCOFT;
            gsWjGPnuRKSlW = XNEKLfr;
        }
    }

    if (gsWjGPnuRKSlW == false) {
        for (int cvMJiIkcmtJmpz = 2106679753; cvMJiIkcmtJmpz > 0; cvMJiIkcmtJmpz--) {
            gsWjGPnuRKSlW = gsWjGPnuRKSlW;
            ODEVsjfSsPEaVmoU -= ODEVsjfSsPEaVmoU;
        }
    }

    if (DPJRvnNNILAxcYz > 934318.4175572242) {
        for (int ffqYVIrfs = 1723058497; ffqYVIrfs > 0; ffqYVIrfs--) {
            XaUrTHrH /= XaUrTHrH;
        }
    }

    for (int VNWYrWreZHWuqcV = 748618629; VNWYrWreZHWuqcV > 0; VNWYrWreZHWuqcV--) {
        ODEVsjfSsPEaVmoU /= ODEVsjfSsPEaVmoU;
        XaUrTHrH = XaUrTHrH;
        XNEKLfr = gsWjGPnuRKSlW;
        DPJRvnNNILAxcYz = ODEVsjfSsPEaVmoU;
        DPJRvnNNILAxcYz += DPJRvnNNILAxcYz;
        YpArfCOFT = ODEVsjfSsPEaVmoU;
    }
}

void OmWVQdWIYYYtfelv::XSRWu(bool emEiIaFOXKGeNEF)
{
    int qrhYJqvFovFVFwtL = 428633855;
    bool uOuHAdNExKvbb = false;

    if (emEiIaFOXKGeNEF == false) {
        for (int dyiAQyvRGWdImDIb = 1133565079; dyiAQyvRGWdImDIb > 0; dyiAQyvRGWdImDIb--) {
            qrhYJqvFovFVFwtL -= qrhYJqvFovFVFwtL;
            qrhYJqvFovFVFwtL /= qrhYJqvFovFVFwtL;
            uOuHAdNExKvbb = ! uOuHAdNExKvbb;
        }
    }

    if (emEiIaFOXKGeNEF != false) {
        for (int tAgqBkIxLLa = 405090162; tAgqBkIxLLa > 0; tAgqBkIxLLa--) {
            qrhYJqvFovFVFwtL *= qrhYJqvFovFVFwtL;
        }
    }

    for (int PooDvFhYETeDkN = 1967057394; PooDvFhYETeDkN > 0; PooDvFhYETeDkN--) {
        qrhYJqvFovFVFwtL += qrhYJqvFovFVFwtL;
        emEiIaFOXKGeNEF = ! emEiIaFOXKGeNEF;
        uOuHAdNExKvbb = uOuHAdNExKvbb;
        qrhYJqvFovFVFwtL -= qrhYJqvFovFVFwtL;
    }

    for (int vLGGWiPEdKA = 1691907213; vLGGWiPEdKA > 0; vLGGWiPEdKA--) {
        emEiIaFOXKGeNEF = uOuHAdNExKvbb;
    }

    if (emEiIaFOXKGeNEF == false) {
        for (int EBLBbOgaXoXTaN = 435348537; EBLBbOgaXoXTaN > 0; EBLBbOgaXoXTaN--) {
            uOuHAdNExKvbb = uOuHAdNExKvbb;
            uOuHAdNExKvbb = uOuHAdNExKvbb;
            qrhYJqvFovFVFwtL += qrhYJqvFovFVFwtL;
            emEiIaFOXKGeNEF = ! emEiIaFOXKGeNEF;
            emEiIaFOXKGeNEF = emEiIaFOXKGeNEF;
            uOuHAdNExKvbb = emEiIaFOXKGeNEF;
        }
    }

    for (int RyHtnonRK = 1788548209; RyHtnonRK > 0; RyHtnonRK--) {
        uOuHAdNExKvbb = ! uOuHAdNExKvbb;
        uOuHAdNExKvbb = ! uOuHAdNExKvbb;
        uOuHAdNExKvbb = ! emEiIaFOXKGeNEF;
        uOuHAdNExKvbb = emEiIaFOXKGeNEF;
    }
}

string OmWVQdWIYYYtfelv::hsMInR(string rwReJqv, bool RygMtlYH, bool DKPBEsXTzM)
{
    bool UUIge = true;
    double hffLokEeoViE = -233986.44189954456;
    bool DnMbjEsoBMwGb = true;
    double HqUGbosjlUcemko = -621185.4942479125;
    string FGIWtJUhbECHWvGy = string("NjnVwrSMEaiURQNebQMhRFshwoOGhyuGmlQKNTHn");
    string XMhBfkleYkMzaa = string("wJsQBOwQbbArzQBLmoPvZDVm");
    string GtXpbRnPZIfds = string("aqWjcfnsptzyBRfyAGuORNZZTiPzpatGQoRkNAyhaRwIdamcskSAdZQYaSAqMDFWsITsIqmVuhuDnzuafqORqLShPeOtVFpkgth");
    string KeWEATjdDDRORv = string("dMVupNGotBBoZGHEDvLtbBZmCiTHHxdApeZesuFgyHYbqEfvbCGhEruEYAHtFTjIFxpcXmvLbfFKjYDrZETsIGwIKNtaYiGSVNRzIsBIpFlLwLLI");
    string YIUkHBuTF = string("dzyPOvDxqoCCTcVNKgekvqGCZmkqeAkoJeejZtLWNrcxqeuHmBCQt");

    for (int ZpVgHIVm = 1352553937; ZpVgHIVm > 0; ZpVgHIVm--) {
        UUIge = ! RygMtlYH;
        UUIge = UUIge;
        rwReJqv = FGIWtJUhbECHWvGy;
    }

    for (int lpCeQPDLrzxm = 1537769425; lpCeQPDLrzxm > 0; lpCeQPDLrzxm--) {
        continue;
    }

    if (RygMtlYH != true) {
        for (int LTfOsrKc = 85348334; LTfOsrKc > 0; LTfOsrKc--) {
            continue;
        }
    }

    for (int uZASYa = 1457096195; uZASYa > 0; uZASYa--) {
        DKPBEsXTzM = RygMtlYH;
        FGIWtJUhbECHWvGy += FGIWtJUhbECHWvGy;
        UUIge = UUIge;
        hffLokEeoViE -= HqUGbosjlUcemko;
        GtXpbRnPZIfds += KeWEATjdDDRORv;
    }

    return YIUkHBuTF;
}

int OmWVQdWIYYYtfelv::BPOJtKPTwDSU(double ZMCwgpmghMgna)
{
    bool yRuPbooxhUDszEG = false;
    string crnJAluTkcBq = string("ScVSwfTiJPpuRZPlqEdXOHUiaQqSlvDIQgtKzoahvGOFCSKNnXeTFold");
    bool FMyfntNrzaDt = false;
    string pOXVe = string("iYZisCqrXnHaGOYMfZHkvsznqVWEvZKceJxSaPbvtPgdWlAEitwnQZFDQpaayBNlzskCPCxaLbxVQiuQRzCTPPxIMflUjFKOMxOGlAKWOyUqvQvjCDmMiWMcIqeoOHIUMwKnEKEdxSLnBJeVpaJbQALeqxjlfYgQuGZnYLXnNlDJIPXJjNhtqyPgvatgrSOVnpMbEmRfhGDJelZVlWqrdlouaasSbicTHRlPwlHyzEIC");

    if (yRuPbooxhUDszEG == false) {
        for (int YenSGfoxHMeYriM = 518914127; YenSGfoxHMeYriM > 0; YenSGfoxHMeYriM--) {
            pOXVe += pOXVe;
            pOXVe = pOXVe;
        }
    }

    for (int wqMBvz = 350874146; wqMBvz > 0; wqMBvz--) {
        crnJAluTkcBq = crnJAluTkcBq;
        yRuPbooxhUDszEG = ! yRuPbooxhUDszEG;
        FMyfntNrzaDt = ! FMyfntNrzaDt;
    }

    return -467645194;
}

bool OmWVQdWIYYYtfelv::VVNgTfrqbjQ(string hSNTa, string PAwpBFscZQkhQ)
{
    string kABeVUzAKrAY = string("JJZjkVdSbqhaSqbdsAoFomKqwgEDtJSABulcRkUfWyDUNhToGDovKqkCjUvarqEvHXzdfKVffJZyLCXOvgvwmkwVdSjeWfLdcvZLYnANWZBxUcjtQaOWmJQhwZkArO");
    bool AbDYjBtID = false;
    int MVishZJz = -561924187;
    bool CTkjUyENTrffRnx = true;

    for (int lutMo = 187728458; lutMo > 0; lutMo--) {
        hSNTa += kABeVUzAKrAY;
        kABeVUzAKrAY = kABeVUzAKrAY;
        PAwpBFscZQkhQ += kABeVUzAKrAY;
    }

    for (int wKMvMrQAcAEWRy = 1628543743; wKMvMrQAcAEWRy > 0; wKMvMrQAcAEWRy--) {
        AbDYjBtID = CTkjUyENTrffRnx;
        hSNTa = PAwpBFscZQkhQ;
        kABeVUzAKrAY = kABeVUzAKrAY;
    }

    if (CTkjUyENTrffRnx != false) {
        for (int cVwZPECpWiHgPZXz = 474433769; cVwZPECpWiHgPZXz > 0; cVwZPECpWiHgPZXz--) {
            kABeVUzAKrAY += hSNTa;
            hSNTa = hSNTa;
        }
    }

    return CTkjUyENTrffRnx;
}

string OmWVQdWIYYYtfelv::MYLwnAEmdLV(bool ZucscjdIs, bool SSfQFSvjoqlP, string FvhyFRcrJUyIUe, bool ApGdGaQACd)
{
    string tXmzJCldM = string("cNEXCGZOYOhLoFMZgbRBITVlZrxkviKVDoeRVLZRKPPomhYifvRgpvGVlRPloETVWKrnEOrvfeKxAKcRlheeTMljsQUvsAbxVpLAQJXgupbHM");
    double ycmYdFgQU = -968276.5962187608;
    bool yWeous = true;
    string FKvYuseXc = string("SGulfaAKeLcljWxmaZYCrwoguebybOhbqbpHpeqzQeQpOShENsjMkLzkVgRkppIeGPRAapGgKDjRFBAKRAGhNFKMFvnEcEPEMj");
    int aVptlonSgjWf = -967903846;
    int dbIgEVhQuixUcI = -768128265;
    bool lRVxmhPmn = false;
    string ZPkYYkUpkr = string("mEcgHavNBLeuPqVFdHyZTpFsTRxUtTbhGtkehR");
    double qQubQMiWNQc = 1039141.3274271477;
    bool vWqJovrG = false;

    for (int hOUQaACEFR = 1328955594; hOUQaACEFR > 0; hOUQaACEFR--) {
        SSfQFSvjoqlP = SSfQFSvjoqlP;
        yWeous = ZucscjdIs;
    }

    if (ZPkYYkUpkr != string("ESyAKbncukvOsSEoZdBaUPaWRwLYEMKtSUAP")) {
        for (int KJoWgoMmdol = 1494303148; KJoWgoMmdol > 0; KJoWgoMmdol--) {
            ApGdGaQACd = ! ZucscjdIs;
            SSfQFSvjoqlP = ! yWeous;
        }
    }

    for (int kaOUvIrRD = 1805835906; kaOUvIrRD > 0; kaOUvIrRD--) {
        aVptlonSgjWf /= aVptlonSgjWf;
    }

    for (int EytxNWnLbtfdXN = 1801871592; EytxNWnLbtfdXN > 0; EytxNWnLbtfdXN--) {
        lRVxmhPmn = ! ZucscjdIs;
        SSfQFSvjoqlP = ! SSfQFSvjoqlP;
    }

    return ZPkYYkUpkr;
}

double OmWVQdWIYYYtfelv::cRjnehoGXlWlF(double CyJmadUZM, string tfhakWo)
{
    string mjpSfNYnEYLEK = string("GLVymFdTCinbwgunHAlEZTeoTVmyoGFBkevifksfsnxjwaDnaKfKApLymnXEloRZPOxuuAHyjGWxbsjwwtpfhTWuTTlYHpBAyXmnXTuCwuApwArUsEjuArDYpoXtAuKDoKHLEQkoGmaBpyJoMxFWlVsx");
    bool ozvcLsfKZLij = true;
    int NEBJZSLMidknnwv = 617209215;
    string tkZmaGzaWU = string("bytKBNISNAVujWdKCovQooTvOIdPXhzapuyllWGDoIwgNdGqNsuwSwrOIGrYgeUDDyETpvmKhEWHLBgTgwBMyaCPZJdGwZmoeURRCcvKBPXmVWblWaYWpjyoMjnefXNdASvtQpjXjkElzJDDBAurxotBiDRGKeqSJmSjsHpJrsjOcKgXFMCUKJUUtFMtwtnOOOMjwAUMwIFuGZsCcLBHkzukyuQtjIIXNikjLakVuJhDQosTzJSuiKIPFdTWjik");
    string rbtWepambPBP = string("nsimcTsWDNxwpeGPuHAyrasNiBEwAmHdPGrIqGWCMIZkjYuvQQytDOeIlCDEuackvgFRerqpSRPXCeKPEBGDWtucTwefNhbHhMuabdbCIgTbaknubffURwstDARvVnxAcJZBoHjQAxIHKaHnTGeLGIouiuezZeOyiXJoCBsOlMlSaearpsXmdlkfAsgnsYfgltNmSdNJtwlwIDSUzQpCPgEeohpiXPpbLhVr");
    double RFJYaRe = -376664.8229089048;
    bool TbtOYE = true;
    string JqZcHNweqvf = string("LvwVTqAwobzuhfRpfxVudmdlRLbeXVSAkbhUdXcywNARatspkGJahdnyUtVnqIvYtNHxoPpBGwfVuErNJOYFSejNJKuctYQaplZhsVyndVqbsOepBbZLRzhjGSEbCbHCeKzWJABlLzfSlEpmGKIzMboylYXtFmVwj");
    double MXbSDF = -978918.0775384532;

    if (ozvcLsfKZLij == true) {
        for (int bMdgwKrZOGQix = 368825583; bMdgwKrZOGQix > 0; bMdgwKrZOGQix--) {
            JqZcHNweqvf += tkZmaGzaWU;
        }
    }

    return MXbSDF;
}

int OmWVQdWIYYYtfelv::rLrjYI(int mRfhQzV)
{
    double GJtTHEPtyLgtiLS = 859969.4564889383;
    bool TwPfxadol = false;
    string UAHBROvSN = string("ljdEHSCOfRWFuwuhsmzLTdtoJCljIIyBwCSSGtcsCUthgBKvZPQRklDFtwsYUsNFGYgdFfXdBVvwasXVNnDy");
    string OdAFPVLGehnuBi = string("wvDRqSKaLsmOjBAOdNQeSkUFOVtwOtOvDrxOTrjbKBFwbbVIIfmxvQgFkJJjHTusQZYjkvTyXhOzgPpwJlIIOQIrBeDEQyGCsCvZPnEPICNpwwydTcZFGnctqRRGefiiGYYrwhimBcqqOPmCwRveEHUUDbBYFUsIUQbgfDuljvCGErGmZpPgHaBRMmqYnOIp");
    int TLhjsZfECqf = 1540096373;
    bool TjCMIbsnP = false;
    string FGGShdNBG = string("uTvrdLZbjCdFbTrFOS");

    for (int pONnjLYHNRfWnr = 435910208; pONnjLYHNRfWnr > 0; pONnjLYHNRfWnr--) {
        TwPfxadol = TjCMIbsnP;
        FGGShdNBG += OdAFPVLGehnuBi;
        OdAFPVLGehnuBi += UAHBROvSN;
    }

    if (TjCMIbsnP == false) {
        for (int DBCkgRFganUOKXvg = 2002718129; DBCkgRFganUOKXvg > 0; DBCkgRFganUOKXvg--) {
            FGGShdNBG += UAHBROvSN;
            GJtTHEPtyLgtiLS -= GJtTHEPtyLgtiLS;
            mRfhQzV *= mRfhQzV;
        }
    }

    return TLhjsZfECqf;
}

int OmWVQdWIYYYtfelv::FpffGt()
{
    bool ETgHRLhxMUodVzTI = false;
    double UPbbBtzGTOjm = 166615.1801739852;
    string deFqYzlcinrF = string("ONmneVeziuXTaISjeoKtSwYWWAxRHObCWcIctIhtlAXZFkkdyUOmQwgkgbWbfKtVqhinaNtXvLmaQBeQqwXClCpW");
    int QGTNpjdhGFun = -1980123203;

    for (int kdLPKSoCxnjcG = 908389170; kdLPKSoCxnjcG > 0; kdLPKSoCxnjcG--) {
        QGTNpjdhGFun /= QGTNpjdhGFun;
        ETgHRLhxMUodVzTI = ETgHRLhxMUodVzTI;
    }

    for (int DiNPtbtdUb = 1801942777; DiNPtbtdUb > 0; DiNPtbtdUb--) {
        continue;
    }

    for (int OghWV = 1331491110; OghWV > 0; OghWV--) {
        QGTNpjdhGFun *= QGTNpjdhGFun;
        QGTNpjdhGFun = QGTNpjdhGFun;
        deFqYzlcinrF = deFqYzlcinrF;
    }

    return QGTNpjdhGFun;
}

int OmWVQdWIYYYtfelv::AEyTFWxHg(int moOFcSOUZ, int RjgqagwavZHN, bool AVswIyIqSGmzPZ)
{
    string XmPus = string("DYXsRpQFmayTaIQEOdYUSkQlAbAPanmhdiQtQewYdsAfJlUrtOCePGDGBBAdcctcjxOWspAiWkenuqOChVtZUDopMVxSJNw");
    string yLpOpOwPuMmDJ = string("pGLcwrjanzazsaKtNJxQNHrOjOLopWEBCWOQLKcJOTtjjEbfcLLfogZXWZIFspvmaoTwBmEaHkfpfPEHgcrBtDMTsFgzECMSHkuAJTeDrCcYWjEDyxcQWIPoaUpubLWTexYyMxCULPDVbgklXDTphPXTXMd");
    bool uBcXDXuRmUFIUbe = true;
    string NGkdt = string("UqmlkBvPSXzYRTfWUrkBTbMucjzmoqmFAqVOToYEkmqdfqmmFtdRtTueiuwRUBbRFB");
    string yNhPXnUGPPWln = string("EXQTnHAneEeftVApDqCbwBzzWsVNEszYzOjjKEjZxWMHiOWXUKzxERPkDKIdTqoxMPgaTsGeekKkUd");

    for (int YBdOvnG = 76003802; YBdOvnG > 0; YBdOvnG--) {
        XmPus = yNhPXnUGPPWln;
        yLpOpOwPuMmDJ = yNhPXnUGPPWln;
        yNhPXnUGPPWln = NGkdt;
        RjgqagwavZHN /= RjgqagwavZHN;
        RjgqagwavZHN -= RjgqagwavZHN;
        XmPus = NGkdt;
        yNhPXnUGPPWln += XmPus;
    }

    if (RjgqagwavZHN != -1507735900) {
        for (int ppDRJzVYS = 1351358437; ppDRJzVYS > 0; ppDRJzVYS--) {
            yNhPXnUGPPWln = yLpOpOwPuMmDJ;
            AVswIyIqSGmzPZ = ! AVswIyIqSGmzPZ;
            yLpOpOwPuMmDJ += NGkdt;
            moOFcSOUZ *= RjgqagwavZHN;
            NGkdt += NGkdt;
        }
    }

    for (int PDGIDIQEzsiOYKy = 1655743508; PDGIDIQEzsiOYKy > 0; PDGIDIQEzsiOYKy--) {
        continue;
    }

    if (uBcXDXuRmUFIUbe != true) {
        for (int AoBRx = 503220739; AoBRx > 0; AoBRx--) {
            continue;
        }
    }

    for (int IvUHQfnaoiUG = 1394725662; IvUHQfnaoiUG > 0; IvUHQfnaoiUG--) {
        yLpOpOwPuMmDJ = NGkdt;
        yNhPXnUGPPWln += yLpOpOwPuMmDJ;
        yNhPXnUGPPWln += yLpOpOwPuMmDJ;
    }

    for (int lqGuUMtMEGWv = 480764224; lqGuUMtMEGWv > 0; lqGuUMtMEGWv--) {
        yNhPXnUGPPWln = yNhPXnUGPPWln;
        AVswIyIqSGmzPZ = uBcXDXuRmUFIUbe;
    }

    return RjgqagwavZHN;
}

string OmWVQdWIYYYtfelv::WFsZlw(string CKKiLeKVCgZNk, string GmiledvA, int uksYqbAjsUBvk, double NTtyU, string AKVAAsCVscGtc)
{
    bool toHItchoYIMOE = false;
    int zRUeGHjelvicr = 961194579;
    bool eSckoRehpbnVAr = false;
    bool FTzLnPCnCVlia = true;
    string WioBrCUhBa = string("EpdNYEnGitUmoVVIhCguXoLprFhdxNogvweXUcpoNFWHiykqaLMngjxZaGILrJyqeIOSoEb");
    string lEzwAKLiYlp = string("wteMcPtCuWfrYwbkGOlLUVhVo");
    double YYdqJupoyRiNsx = -985639.4592802592;
    bool CZdRFM = true;
    double kjAgajyzH = -928317.6519788181;
    double vzaFNE = 73572.55187942085;

    for (int twoUKaIV = 1464936699; twoUKaIV > 0; twoUKaIV--) {
        vzaFNE /= NTtyU;
    }

    for (int fHYbwsoxUkR = 873108705; fHYbwsoxUkR > 0; fHYbwsoxUkR--) {
        AKVAAsCVscGtc = WioBrCUhBa;
        CKKiLeKVCgZNk = AKVAAsCVscGtc;
        AKVAAsCVscGtc += WioBrCUhBa;
    }

    for (int JjtPoDyPEnCa = 1702964686; JjtPoDyPEnCa > 0; JjtPoDyPEnCa--) {
        vzaFNE *= vzaFNE;
    }

    return lEzwAKLiYlp;
}

OmWVQdWIYYYtfelv::OmWVQdWIYYYtfelv()
{
    this->GIeUUSdeCd(827218.9399227272, 1561613959);
    this->EwJMXvGDWWTSTv(710291.9284959565, false, false);
    this->qLyTxIuS();
    this->sORvg(false);
    this->yWHdmkqpw(1014948.7346254721, -822110.0860567865, 934318.4175572242, false, false);
    this->XSRWu(false);
    this->hsMInR(string("uHaBqpilJzsOexIDDDTbfuKyIdhoUCaiEDTmTCkVhxkIEHltqdiQtGPUMUvcneNEEGJJILbfwNasQDSFHuasbiyVbiPZFLlABKozpVjnVwvibQuRQtzVZdQJqWevGM"), true, false);
    this->BPOJtKPTwDSU(-89147.99989816689);
    this->VVNgTfrqbjQ(string("tTKiitlljZSnOHCgNHFkyzNmUjwOjiIxhZpNnhQjwfKxGQDbamrpBIAGLcfCljmndexluPCtHdxieywuTzixLNksmAWqvqxOcuqRKShOfeQUggmuNXalAiTPXcNqGVNhiADTndDOuqIilPbtNDHq"), string("SwsaHEctJWGMzzizwooPwWQjnwGzAaxmUPWBdYXBNUrVFFzwtZK"));
    this->MYLwnAEmdLV(true, false, string("ESyAKbncukvOsSEoZdBaUPaWRwLYEMKtSUAP"), false);
    this->cRjnehoGXlWlF(306613.10309617146, string("JLXgZyhBEPYonlECycCxohOVQreDZBKmcjjbTjOzewmsAchJdfcMnTiVvpUdNUFxwQRvyZfrxBBffWswcrMDPQDRuqOxsdbfNYiWguoHfToQnceSztuQPWcHZNxArEnKQqCHwLKNAhMOLuiJMauiuVnPInD"));
    this->rLrjYI(-908182128);
    this->FpffGt();
    this->AEyTFWxHg(-1507735900, 103959389, true);
    this->WFsZlw(string("nokgcnKlNQRvJPsGNSPjWfylPvuexjkMstoYrPezHVBdOIfjkcNBYzXkWOzVvPgDrezkzbhYUNnjodshmbIfLKAIuBiPweVRQxbpDFTRJyx"), string("UBkHYcSvbeSfqoiFhbJauYZXfgujUUJoDnyFjggtZKODfkZEaiHlnpsVnOsHctnulZUGOvlMoLkaRRojkIhtfeWYHaLJwuIplBBmxJNbHMkheSFYLGvIzTJuXzXgUGrBBpnldSZoIWPsAfWjFf"), -1686824806, 445618.80555956525, string("feFFjEIKkMGSkWHxfNmusKbQEqqFpudoLLvtpQwhDlHYZPpAQxRIHTQuyvrhinKIuTlZvMBSEmTvnPKjgSBmelMxslxNldTmpVCoOHSraDsa"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JoHaCpMq
{
public:
    double BtjVMHCXdbnX;

    JoHaCpMq();
    void SMBToMEwFOtGLviT(int QVhjn);
protected:
    double EEipFoE;
    int lXxqXobzxIydOaTC;

    int cHuyFCIjg(int grWOiHucyf, bool tYMFGxHQCWO, int SKOAFrXUOprCA, double PshqA, int LtWdK);
private:
    double ngndJGqlPFmMeQ;

    string rtKzGcqnXZ(int CsYfSZxhkiC);
    string VZxsPGRezRcOdWb(double GbExdckC);
    int YrJeunKBbOTdAeB(double bkLUHJYQEqygmXSy, bool EvnpIVLZU, bool xmnrRzhPlJYcdcPP, string RdavbcHWKLnhbHW, string bgpRnAlGNfFC);
};

void JoHaCpMq::SMBToMEwFOtGLviT(int QVhjn)
{
    bool RnYtWmBuOKP = false;
    string HhAQsBtaGlhGkNy = string("VAonSvKjkbzoKPgBHRyWxPRQTNqWLotADAPIKf");
    bool yQAJvNQQobqLaC = false;

    for (int ItvZUjIG = 784448248; ItvZUjIG > 0; ItvZUjIG--) {
        RnYtWmBuOKP = ! yQAJvNQQobqLaC;
        QVhjn /= QVhjn;
        HhAQsBtaGlhGkNy = HhAQsBtaGlhGkNy;
    }
}

int JoHaCpMq::cHuyFCIjg(int grWOiHucyf, bool tYMFGxHQCWO, int SKOAFrXUOprCA, double PshqA, int LtWdK)
{
    double LnsbILJOZPsg = 294479.1462252818;
    bool dSOidIAqpGVvUQz = true;
    double LodyukDYeYw = 520905.51357714325;
    bool reWnaLgU = false;
    double spKnANtU = 248745.10394254737;
    bool cRIQryPY = true;
    string oMYbtbNBq = string("QfAzmdGnmLhxoJSePOoWiwkOXfpXVcjhqznRquMzSbrPGQeZLwLcqqTGSMjAHpReGgHSPiXBPwqpIBkXkntCjrlbzCvQiOgsydjQVDaQXdkeQNiuIXedvVXyAZfIKkqYfbnbTWTcbwGvqAYoNijNHXiIhkPYaNsXqFYfhEZSFNutjqWQhRBZfRmTXEssQFZkXOuukCCpXHeGWoMilZLgHxENEVcGzfX");
    double BmyhhdCVSXAcge = 511554.964500682;
    double wPUTxCXytJAcHPU = -957499.7168545007;
    int agXWjpWfU = -2143009156;

    if (BmyhhdCVSXAcge == 511554.964500682) {
        for (int KBbheAbmlYRVDl = 1782706903; KBbheAbmlYRVDl > 0; KBbheAbmlYRVDl--) {
            LtWdK /= LtWdK;
            SKOAFrXUOprCA += agXWjpWfU;
            LtWdK /= grWOiHucyf;
        }
    }

    if (spKnANtU <= 520905.51357714325) {
        for (int sOpoFx = 207003953; sOpoFx > 0; sOpoFx--) {
            grWOiHucyf /= agXWjpWfU;
        }
    }

    for (int yHNjssdsaYX = 1696638340; yHNjssdsaYX > 0; yHNjssdsaYX--) {
        dSOidIAqpGVvUQz = dSOidIAqpGVvUQz;
        BmyhhdCVSXAcge = LodyukDYeYw;
    }

    return agXWjpWfU;
}

string JoHaCpMq::rtKzGcqnXZ(int CsYfSZxhkiC)
{
    bool FBDdOFkmhe = true;
    double WHoozCEWv = 378308.3145145288;

    for (int VUAnbF = 623429767; VUAnbF > 0; VUAnbF--) {
        CsYfSZxhkiC *= CsYfSZxhkiC;
        WHoozCEWv = WHoozCEWv;
    }

    return string("xSuNZKzbzmesuNiiUbSMPpvjJLxAtmLJAhGvBTbMdiPdIXKWxZXmKGcUcEqVPHuKjGXdXiWqoblAcAMenmmmzaPvzfRvitnigikJpVUDlpuHnIphtDBKFRZYbBwDdxgqfWhVfNbXxMCqBPcLYwuukOSwLwAQuqYZQOkfmyGAiuAYGGFKHsKJugrAzcllG");
}

string JoHaCpMq::VZxsPGRezRcOdWb(double GbExdckC)
{
    string DRuCNPfRaPAhutE = string("volCXmWjILAJJDoSDmyoDRNyFkJCSlSGilFvUpQWEYLUWkiUSiVipREMsrvmlyKNCscxQEqMshhym");
    double nVhgux = 911833.5802903262;
    double WdYKuTLyn = 250623.48747627443;
    bool sDwgNQlYfu = true;

    for (int znnsVyzeYHzNR = 1246798503; znnsVyzeYHzNR > 0; znnsVyzeYHzNR--) {
        sDwgNQlYfu = sDwgNQlYfu;
        WdYKuTLyn += WdYKuTLyn;
    }

    return DRuCNPfRaPAhutE;
}

int JoHaCpMq::YrJeunKBbOTdAeB(double bkLUHJYQEqygmXSy, bool EvnpIVLZU, bool xmnrRzhPlJYcdcPP, string RdavbcHWKLnhbHW, string bgpRnAlGNfFC)
{
    int KPlYhCpWMYm = -224257047;
    bool hnYwMWFejjrjdn = false;
    string yWEwgylXWz = string("IDcFSlfXHidcONICIzbqqyNetBnHDczUjWJRVWYzCdcDshmvPmWfKpCtcdLuIGMiqdtxzMnewTgzPkwnknlFMCsMgDhzjlAcOpEBnFBEcBGSLAGHTJiMaVQusKBZMIvkYUUHRKP");

    for (int enANVM = 484971214; enANVM > 0; enANVM--) {
        continue;
    }

    return KPlYhCpWMYm;
}

JoHaCpMq::JoHaCpMq()
{
    this->SMBToMEwFOtGLviT(-1017784588);
    this->cHuyFCIjg(-883704723, true, 2133434324, 838523.9598794791, 1288384166);
    this->rtKzGcqnXZ(-685661126);
    this->VZxsPGRezRcOdWb(-212370.61173740786);
    this->YrJeunKBbOTdAeB(444355.14016605786, true, false, string("buLzFIUMVeZIcPByetQrFtmtOUpApeXaYzitpojnOUcRNaYKLAkSdsLyVrfesejlOpHCherzQGUhWhoJOnAgDVcVlgzhJqGnrRPdtOKubfgCUWZJaJvCpsVuMbrsAbgqhLhafzruqSvWXIFJJPEIlQYXsOtwrMwhAKdAMcdDhMyyTQBRiFgQ"), string("CefwQEzaBBaxUcffKzcbiXQJjBMxUYidzQgtvRTELCBTppwYuaXkbPMHRUKHXEKzNzTfYgcKuefEbUtrZTMzJgJjOLChBXCofqwDomhueHhRLpJZwDrdsWzRDznXYgaFTwLmwnhbuGUkeFaLtOiXedVcXfQTTWocvozDdzSFuLHzmMfwdGihAUCdpSxQXTgnMSLpe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YgLolFwVEKHLMQt
{
public:
    bool tWUhWjBXqeVG;
    bool QuKkNqcYw;
    int oyOgdQVF;
    int WKuTSCDMuPXZGqjF;

    YgLolFwVEKHLMQt();
    bool smYqeOhSYppdA(string CMTWXHLx, double ODNDsHxPC, string ADHuczUmRNf);
    int JjVOdYnSng(bool dgzmpmvhmCdqznc, bool ogrcSce, int mhnuXFDIT);
    double KjlyG(double yXLaJ, bool sQMfYkTggRLO, string tuYNjPTA);
protected:
    int vcgDi;

    void eqoEsJKJpNEb();
    int YYitbhcA(int JHUct, bool BfqQYmTFIptrrp, bool PouWLGdH);
    string bICURuY(int asQyHP, double EKEbAzjdrMmEz, string zoCbEiF, double qcubgAHnlHFJl, int XGSEHmKhTuQPh);
    string eYTcsHllWbtuwlAW(string rOpatO, int fWlQD);
private:
    int kNXvO;
    string DkizRhRxFgbIV;

    string AqMvkPCxAgiFMt(string brlYPrRCOt);
    double vUqDBJd(int LKEDlG, int xahZPvchUEsvgxQe, double pIsedYVz);
    int pkGnciCyTXaMnYSc(int XLUZpbB, double GqThKJWJcY, string ppHRswEyVywVU, bool ZCipFBypxybQsJX);
    double lMBRQCQlaKyCgDUx();
    bool mYknnEYyPRqZ();
    int xMCdrGuNjxgB();
};

bool YgLolFwVEKHLMQt::smYqeOhSYppdA(string CMTWXHLx, double ODNDsHxPC, string ADHuczUmRNf)
{
    bool gitCPSrwFxpP = true;
    int oVvmoTnvcuthnCQj = 1270621465;
    bool dfWeAyZMP = true;
    bool iEzdvRzmefVU = true;
    int YFnKAJOgQsgmg = -1612905517;
    bool JRWJoFXWtxtWBxPx = true;
    int kkhTXYwRnwzfQ = 562114356;
    double CXiMrMdDB = -883985.5806829507;
    double fwiYL = -1012538.3819464752;
    string kCetXQ = string("kWlFmONxdhUOnSndpYKRFEFHiXoOMLfmAfyEhdMvdMUcpFApFAMZpavdQPdbppQKnUGqarDWSYXtngiIuPvCqvSInhHtfZMaFwNXUiQEiQTjiEXzYSoMrFOFzWNKSVovsahdINtKUacVvFokCnFPxEflofBmsEfsndIwkMPCCxGsDjGMQB");

    for (int VgIxPpzPY = 220112771; VgIxPpzPY > 0; VgIxPpzPY--) {
        continue;
    }

    if (ADHuczUmRNf != string("CLSlyaIFWSGRNlokQjiHRhIbAGIEjvkpPsWrRfWgnDzuPSjSLCRqfUjbrWKAJZyRYMbtIIpnkqoOdACmsEUwQFeiEkhzKGBAYTxBWUBfbytLulUpFexvtmWsPOBgZECpW")) {
        for (int kYISeWHXCHTapCvd = 624328148; kYISeWHXCHTapCvd > 0; kYISeWHXCHTapCvd--) {
            CMTWXHLx = ADHuczUmRNf;
        }
    }

    for (int OrUJUqojUctrIY = 1259551996; OrUJUqojUctrIY > 0; OrUJUqojUctrIY--) {
        JRWJoFXWtxtWBxPx = ! iEzdvRzmefVU;
        gitCPSrwFxpP = ! JRWJoFXWtxtWBxPx;
    }

    for (int dapMBEekBZRgzjhQ = 1290540765; dapMBEekBZRgzjhQ > 0; dapMBEekBZRgzjhQ--) {
        kkhTXYwRnwzfQ -= kkhTXYwRnwzfQ;
    }

    return JRWJoFXWtxtWBxPx;
}

int YgLolFwVEKHLMQt::JjVOdYnSng(bool dgzmpmvhmCdqznc, bool ogrcSce, int mhnuXFDIT)
{
    int AYtfRTNrZyNhNet = -1710408832;
    bool gbsRQ = true;
    double oQesibDqmtqUv = 275837.8847013594;
    string TSVvC = string("JUtFaEqKlBqRvEGCpZwVClDocMebLdTclgvULUKSLPjcVBiGvSeRUYDtwXOTSaQqVNLiEuKbZlSjsgvIAKgvLPxdhSjRlHfMtAdPQKUFtuaYZKDorsDJprcKpWmSiitCSEGGDSrmQaDApCGjdqAlpSeNQHmRhfShJZWsxckirxlAQvPzXR");
    int AvSESXnmv = 1276390006;
    bool BAJFmePUVK = true;
    string AshBn = string("cgrnAAyCADbzIQyDfemTztSWziTUEeiJhjptzyOQXCBbmMpgtYZUmNwzNGVwODGvLxDtXWdfnFRrJzYrgvnsCcsyWIAGrOCrzTCIXQSikTIZRMmBYMCLhBRSHwbYIOmwnxqtyDOFMcVnqZqSdwnwkDsKxSfmLqvGYquqzJScxnzyg");

    for (int JFNHZiR = 253675616; JFNHZiR > 0; JFNHZiR--) {
        BAJFmePUVK = BAJFmePUVK;
    }

    for (int YKYTLWodfxfFH = 598522191; YKYTLWodfxfFH > 0; YKYTLWodfxfFH--) {
        continue;
    }

    for (int ZherpjsFu = 1229202819; ZherpjsFu > 0; ZherpjsFu--) {
        TSVvC += TSVvC;
        AvSESXnmv = AvSESXnmv;
    }

    for (int dJCLObqwIx = 1486714438; dJCLObqwIx > 0; dJCLObqwIx--) {
        AvSESXnmv = mhnuXFDIT;
    }

    return AvSESXnmv;
}

double YgLolFwVEKHLMQt::KjlyG(double yXLaJ, bool sQMfYkTggRLO, string tuYNjPTA)
{
    int YAxAtsK = 2017696307;
    double OMntAABOkuORoGtS = 589752.5366196006;
    string VbfRZQgItguMswGV = string("perGiUfUiwvNjNwZGaNypMzkMTPGdfyKkMzlfwZzbDGsygzLDIQfIZzCqCtLOqteixcDtmJeXsoLUgBxvHFMniTrDNynJERsocDIPogJKFRABXozooFMXPVeIUEaMHWZqfLbiqjFcHOqTBCHMUskSzZjlXWaUvZMltbuaQyfERSGBJUFAvENSHzHObTatEYAqjJekLeRowWpSosDqmuMPDHNBBBLCBYmAibowTg");
    int IKjrXbtoIHbj = -295500538;
    bool EjuEUqsioeJPNG = true;
    string hEHsyHnLkt = string("KhHyhlCwwYzsgEIiEtVWZCYHIwkXMAUjwpLOUQukFlOkwUEAelmUOAkrBuRkyJFSVFzjsrtGRyHr");
    string DDLhnhcNZPBDlTK = string("mcMlsPqOePqquIKodymOQOrMrwXBUNrpHzInMIPKShzUvbeKDwhKNhYGzaTbjQdTeAkizaVWFJEFNjyEtVgJDaijWlRSFyBdEpEukXKunpHPSRsbZKHxkUhgHWGnhbwzjWbYaqpBObFfZBVdJwjmGnuXihnENagywbsEMGgWGuLSVnbFPJLRexNAMdXPshuhiCZyKnAjBoQLJd");
    bool RYsWiGhyYi = false;
    bool MGWsyr = true;

    if (tuYNjPTA == string("bLFneyxGsfHiXvyvduCYzwpMWRQHiPRCuhcQaFZcAfpmwlazsHjhtIrnePZuMQaozYbBFrBjYzpFuzglRIxwqZfoTcejPZbfsOlmfEQVCcXTHMQSdGwkDSoQnwxmjAbRvWcjqgaoTMAVQdipJJqqeygqUPgLSxKRguiSJXMLbrubkLJEZBlEmYpRWjDcbeEWknZ")) {
        for (int jzIkkWq = 2019169184; jzIkkWq > 0; jzIkkWq--) {
            continue;
        }
    }

    if (YAxAtsK == -295500538) {
        for (int LnwqgfOCfCGQ = 1821187121; LnwqgfOCfCGQ > 0; LnwqgfOCfCGQ--) {
            continue;
        }
    }

    for (int shkfa = 1225210306; shkfa > 0; shkfa--) {
        continue;
    }

    if (sQMfYkTggRLO == false) {
        for (int UZZtIuZlogG = 377622126; UZZtIuZlogG > 0; UZZtIuZlogG--) {
            OMntAABOkuORoGtS = OMntAABOkuORoGtS;
            RYsWiGhyYi = sQMfYkTggRLO;
            hEHsyHnLkt = VbfRZQgItguMswGV;
            EjuEUqsioeJPNG = RYsWiGhyYi;
        }
    }

    for (int hUjJfDgLXoh = 872600879; hUjJfDgLXoh > 0; hUjJfDgLXoh--) {
        EjuEUqsioeJPNG = ! RYsWiGhyYi;
    }

    return OMntAABOkuORoGtS;
}

void YgLolFwVEKHLMQt::eqoEsJKJpNEb()
{
    string tADByRjxqgLHH = string("SDeKUmCXbqkMiVNHlrpkIWuzMatXPHPWKWDtQRayTtdJvgyeZsdKjNHkMAHbrRCXCWVmQrQCzaBXiwghoVbbOfucMcLvkPCRhKIjoTpsBhxQtYDZtfzbdsqUyMAmkkPDSKwcQhuxAsVJQU");
    double LxJPgakAyPpFLAM = 206415.0607766362;
    bool qtPaRAbrnSHC = true;
    int YlaGlPcOmPpEB = -818405094;
    string ghpVpgllMCTDd = string("FLldPJTNAvfRNiCKapEzxgNVecKqItsRPwpOHzNHQrswqBNMYcJjvXimFOUZgNjYuMUXniibAAhaVZbzhvxjtYJMTkWgAChViQcMifGjmWoQxWkDThrfvxoZDbdxoccVkyRHhGHcQetwGsFvdVOEIF");
    int eeXwZMLyHkqZQ = -1522562403;
    int aMPhCzRbsmYI = -1805435004;

    for (int xfusItyzInOlZ = 1180040595; xfusItyzInOlZ > 0; xfusItyzInOlZ--) {
        aMPhCzRbsmYI = eeXwZMLyHkqZQ;
    }

    for (int GqIVsQqCOYaaiSp = 218638838; GqIVsQqCOYaaiSp > 0; GqIVsQqCOYaaiSp--) {
        tADByRjxqgLHH = tADByRjxqgLHH;
    }
}

int YgLolFwVEKHLMQt::YYitbhcA(int JHUct, bool BfqQYmTFIptrrp, bool PouWLGdH)
{
    double TKGctqXuzXdqfVfj = -325976.94696463336;
    double nDcSqbS = -26277.348736317028;
    double VTZKWuWbmuW = 906180.7284510861;
    int tJpcqhhcHBPD = -1428619122;

    if (PouWLGdH != false) {
        for (int ZAbOYImWAmAnULH = 1861249170; ZAbOYImWAmAnULH > 0; ZAbOYImWAmAnULH--) {
            VTZKWuWbmuW = VTZKWuWbmuW;
        }
    }

    for (int yolDZCsYBTOQpOd = 835080558; yolDZCsYBTOQpOd > 0; yolDZCsYBTOQpOd--) {
        continue;
    }

    for (int clFvC = 550427068; clFvC > 0; clFvC--) {
        nDcSqbS += VTZKWuWbmuW;
        VTZKWuWbmuW -= nDcSqbS;
        BfqQYmTFIptrrp = ! BfqQYmTFIptrrp;
        VTZKWuWbmuW = nDcSqbS;
        PouWLGdH = BfqQYmTFIptrrp;
    }

    for (int YltXAYWxqm = 229352833; YltXAYWxqm > 0; YltXAYWxqm--) {
        VTZKWuWbmuW -= VTZKWuWbmuW;
    }

    if (TKGctqXuzXdqfVfj > 906180.7284510861) {
        for (int QKWaTVqd = 21483827; QKWaTVqd > 0; QKWaTVqd--) {
            TKGctqXuzXdqfVfj *= nDcSqbS;
        }
    }

    return tJpcqhhcHBPD;
}

string YgLolFwVEKHLMQt::bICURuY(int asQyHP, double EKEbAzjdrMmEz, string zoCbEiF, double qcubgAHnlHFJl, int XGSEHmKhTuQPh)
{
    string PKaKZduYpyEMcznd = string("KSQBeoaybDqMegSoMYXUPKSAuWrUcsHgpKALkOLmiBPDzyjygQhHYIWCsdkMcZnUQFhdnDWCcLpwxAXEhwSmVMFbdAoAyDcZhrQPGPlYzjVpIwjloGfjPCPEkxSrKZVpOMFajUNSvarhXXalRuRfWepHMtpr");
    string BYCalrQJEEViMC = string("datMnMJnubqjqkToADOcvoxwvDgTSftQYDykgeNopRmlTGqNtaaTNNdVZkXaWifFALzXZfSecZmUtKCaZVfndfFZggApyBmjZxEqHnINOgcrlFLDXqRSSeeuBOhWfmRQXGVTpUAKWxIpnBqZWWQnmkzZTSPbBNzPAMbkTddNSNnsvaUveVgqEKyiXDDBIuFRSnefvshzuTLkRDNbvFuuVFfnsFslJuCiGxYFVJ");
    bool PDBIfnLqeUi = false;
    int VTJQdUEXFqtsAtXF = 408886137;

    for (int GcMMqrh = 1274273000; GcMMqrh > 0; GcMMqrh--) {
        continue;
    }

    for (int SaoikMdBCXMyskA = 1045665202; SaoikMdBCXMyskA > 0; SaoikMdBCXMyskA--) {
        qcubgAHnlHFJl = EKEbAzjdrMmEz;
    }

    if (zoCbEiF != string("SakrsabAvfSAZBgBoOHoApPSsiEiiDVckqbFqRSDuUpDUZQWjUMClDtVecSJqVHMxIAFG")) {
        for (int VDPYorXo = 885416745; VDPYorXo > 0; VDPYorXo--) {
            zoCbEiF = PKaKZduYpyEMcznd;
        }
    }

    return BYCalrQJEEViMC;
}

string YgLolFwVEKHLMQt::eYTcsHllWbtuwlAW(string rOpatO, int fWlQD)
{
    bool cYQuei = true;
    bool BHTXOOt = true;
    bool cvRmalFLvI = false;
    string YwJUikrC = string("hxAZgTTraGiBJTyLL");
    double DXGzo = -755660.7977657544;
    string eHLjI = string("w");
    double zWpByF = -717890.4496843078;
    string PFAEYAVktuqo = string("nuUzzFIvrwMmkAPkEDtHJFQCMOnpdLLJtyJLHDOLPtDjJvDVWmmpOrSzINWNlNOeDgEzwThlnTMGwZgUdixLffiikMzkymAVMCNBRjnATmNjpdXiouESyaCnXZIxk");
    int PeGAkvpQjtKIq = -297121013;

    for (int OqMIUMyVp = 2090526638; OqMIUMyVp > 0; OqMIUMyVp--) {
        rOpatO += rOpatO;
    }

    for (int aNtGnHhzbdiah = 1528786825; aNtGnHhzbdiah > 0; aNtGnHhzbdiah--) {
        cYQuei = ! BHTXOOt;
        DXGzo -= DXGzo;
        cYQuei = BHTXOOt;
    }

    for (int qklLjqArzUbiq = 1617142904; qklLjqArzUbiq > 0; qklLjqArzUbiq--) {
        cvRmalFLvI = ! cYQuei;
    }

    for (int hNYjOP = 1261934611; hNYjOP > 0; hNYjOP--) {
        continue;
    }

    return PFAEYAVktuqo;
}

string YgLolFwVEKHLMQt::AqMvkPCxAgiFMt(string brlYPrRCOt)
{
    int zuJNNxAzITHotKnR = 1508244775;
    string CBxEqVHuZSfQt = string("OcUIgPSInyzkjzncGpEKoWvnznVtHvicfFXEZzUABFWNCTqHAMaGBWrykQaQrSeJPfNIROVwHmOkdUublPAJGSZgXtfqJhG");
    int VUThbTDT = -556768999;
    int TtwVjr = -82092447;
    bool MYGtr = false;
    string QqTSMNsnDMEDv = string("gUENOCjDOFOPOEQykVdvIPofKIssjRqvyaqTnuBxVjFfyoTIAAopneppwFvWaqgHMsUbuFrdQOZEDuxfwEbchkrVuzYtMTocWzTqEvQdZMlAYeBKPBGnGHEVKWPWWclKqGcvGMeqGSXuoxBiixxiZrHtUnziVxJYBnjYhdQXduWYrhbQijWReNbCnbFwwYmjjae");

    if (QqTSMNsnDMEDv > string("OcUIgPSInyzkjzncGpEKoWvnznVtHvicfFXEZzUABFWNCTqHAMaGBWrykQaQrSeJPfNIROVwHmOkdUublPAJGSZgXtfqJhG")) {
        for (int XTgNL = 489632135; XTgNL > 0; XTgNL--) {
            zuJNNxAzITHotKnR *= zuJNNxAzITHotKnR;
        }
    }

    for (int ddoIgWXVDVo = 1293171156; ddoIgWXVDVo > 0; ddoIgWXVDVo--) {
        brlYPrRCOt = brlYPrRCOt;
        brlYPrRCOt += CBxEqVHuZSfQt;
        VUThbTDT /= zuJNNxAzITHotKnR;
    }

    if (brlYPrRCOt > string("OcUIgPSInyzkjzncGpEKoWvnznVtHvicfFXEZzUABFWNCTqHAMaGBWrykQaQrSeJPfNIROVwHmOkdUublPAJGSZgXtfqJhG")) {
        for (int YXpAnfEdtcp = 1553082157; YXpAnfEdtcp > 0; YXpAnfEdtcp--) {
            VUThbTDT += zuJNNxAzITHotKnR;
        }
    }

    if (zuJNNxAzITHotKnR > -556768999) {
        for (int bUMkTdRvLsYxrFlL = 1220195724; bUMkTdRvLsYxrFlL > 0; bUMkTdRvLsYxrFlL--) {
            TtwVjr -= VUThbTDT;
            VUThbTDT /= TtwVjr;
            TtwVjr *= VUThbTDT;
            zuJNNxAzITHotKnR *= zuJNNxAzITHotKnR;
            brlYPrRCOt = QqTSMNsnDMEDv;
        }
    }

    for (int EpVrHjcPdNBo = 675139161; EpVrHjcPdNBo > 0; EpVrHjcPdNBo--) {
        brlYPrRCOt += brlYPrRCOt;
    }

    if (zuJNNxAzITHotKnR > 1508244775) {
        for (int OmKBktFovGSGanGj = 1407636585; OmKBktFovGSGanGj > 0; OmKBktFovGSGanGj--) {
            continue;
        }
    }

    for (int vnDhtVrNAhoc = 2023183132; vnDhtVrNAhoc > 0; vnDhtVrNAhoc--) {
        VUThbTDT /= VUThbTDT;
        CBxEqVHuZSfQt = QqTSMNsnDMEDv;
        QqTSMNsnDMEDv += QqTSMNsnDMEDv;
        QqTSMNsnDMEDv += brlYPrRCOt;
    }

    return QqTSMNsnDMEDv;
}

double YgLolFwVEKHLMQt::vUqDBJd(int LKEDlG, int xahZPvchUEsvgxQe, double pIsedYVz)
{
    string HxdNXzOz = string("jBdnUCPYgLkSHeNkLaxMXjiQrHaZujLGnhJApwSINfQpTwiqCNbLxogEqQuZ");
    int gjvhARKOvHGW = 695443196;
    double fEPasPVoeMWfd = 703818.7579736741;
    bool ekFEBsXNKs = true;
    double ikVOcwDn = -189878.8228424686;
    double mpBoFnKGmLBpYm = 987342.469050413;
    int kTsfLUItwshS = -156728681;

    if (pIsedYVz <= 617214.2002478987) {
        for (int hNKCQKopHffEZ = 1565326684; hNKCQKopHffEZ > 0; hNKCQKopHffEZ--) {
            ikVOcwDn = fEPasPVoeMWfd;
            pIsedYVz += fEPasPVoeMWfd;
            fEPasPVoeMWfd *= pIsedYVz;
        }
    }

    for (int gsLUr = 796091794; gsLUr > 0; gsLUr--) {
        ikVOcwDn = pIsedYVz;
    }

    if (gjvhARKOvHGW == -596790226) {
        for (int YFMZfyUzof = 1802274976; YFMZfyUzof > 0; YFMZfyUzof--) {
            ikVOcwDn *= ikVOcwDn;
        }
    }

    if (fEPasPVoeMWfd >= -189878.8228424686) {
        for (int NyQUFxrol = 1007494931; NyQUFxrol > 0; NyQUFxrol--) {
            kTsfLUItwshS /= kTsfLUItwshS;
        }
    }

    for (int RgFhhGURO = 394528027; RgFhhGURO > 0; RgFhhGURO--) {
        continue;
    }

    for (int ePCMwWXnd = 2025163621; ePCMwWXnd > 0; ePCMwWXnd--) {
        continue;
    }

    if (pIsedYVz == 617214.2002478987) {
        for (int gtTgWfgullqOWK = 1196393544; gtTgWfgullqOWK > 0; gtTgWfgullqOWK--) {
            continue;
        }
    }

    return mpBoFnKGmLBpYm;
}

int YgLolFwVEKHLMQt::pkGnciCyTXaMnYSc(int XLUZpbB, double GqThKJWJcY, string ppHRswEyVywVU, bool ZCipFBypxybQsJX)
{
    double TpkcNRRq = -174948.6966241243;
    int olcVytC = -1290843570;
    bool JOvZWPLIrCVHMlK = true;
    double gHnBtrENRgfZUAl = 195278.0343679893;
    double tdQfxFHILlHd = 878495.840431868;

    for (int CPedVZ = 1039900736; CPedVZ > 0; CPedVZ--) {
        continue;
    }

    for (int stjcCEmhS = 126545581; stjcCEmhS > 0; stjcCEmhS--) {
        continue;
    }

    for (int oKPJfDUqOuqa = 1001639288; oKPJfDUqOuqa > 0; oKPJfDUqOuqa--) {
        TpkcNRRq *= GqThKJWJcY;
        GqThKJWJcY *= tdQfxFHILlHd;
        TpkcNRRq = TpkcNRRq;
        gHnBtrENRgfZUAl = tdQfxFHILlHd;
    }

    return olcVytC;
}

double YgLolFwVEKHLMQt::lMBRQCQlaKyCgDUx()
{
    double nFNRlifMAWaQgv = 849353.6582916221;
    double lRmivmSypK = 1028023.6265795561;
    double zokrLOQZD = 223744.60733012817;
    string aavSAHUoHzTUo = string("vHmXzDfoTvxUhnyeRaLergofeXPLknKeIGLL");
    int nonrAtm = -818438825;
    string sORwHaLSQx = string("NtejJcPjKONzFrvKOmBevlOLdPKWrrFzLSwwhqOWzejhHpmahNZhRJczJQhkjeswrdAiKVpRRfkMbBOHDplJgRTgzZvrukhoKzcpouCXfobSSBiJyeMqaYMyipRGumJqYBHTlfbQNdWMHQeeeLaaDldMKFqtgFpKnSXOnbcrcYncheuDuiUppGZTMXQlxpZIXinpNYeUkExUxZPJLLAlQUA");

    return zokrLOQZD;
}

bool YgLolFwVEKHLMQt::mYknnEYyPRqZ()
{
    bool FmfwwlHL = true;
    string HBSXeKdXruuxaQZ = string("zrPEOkukQHpqXHTkFNXiImDyKNcYWALJAhRWToJzVFsevJWuFuKLnfGGIOKzFEOwkgTDJKBpiWREBafAYWiTtxCJEczCyCUCSOsLvIiNWWgpzXHaxSHeVmGOPVcuiwgwnOhDHNXJZFybjNzuCpdQDOSYORLJRVhmpdaUHgAWJQadwddMZqLdrOTQhJKTaKvLQitzMPkVkLZgNKbjpZqursHsjJrQdqllzJpSIVFnxVSKlutbb");
    double tbiGW = 176905.46940164315;
    string pWCwZVhnI = string("VlKvOIOjcfAZiqtgnsuLCSlGpOPFXMMvBfIcvwkRneDMegIjUPbiPevpFxTpJBpzfLXsIfKIDesREsisEUYVXIwScUGCyWzxAgzlZWlfIiZjQPYmLOFXIzKAuITtqkZRRTNDmgEnKxRAdJea");

    for (int IUmFgXmWKVRimmmE = 1951005846; IUmFgXmWKVRimmmE > 0; IUmFgXmWKVRimmmE--) {
        pWCwZVhnI += pWCwZVhnI;
        HBSXeKdXruuxaQZ = pWCwZVhnI;
    }

    for (int LYIqxNlBdg = 1893165254; LYIqxNlBdg > 0; LYIqxNlBdg--) {
        pWCwZVhnI += pWCwZVhnI;
        pWCwZVhnI += pWCwZVhnI;
    }

    if (FmfwwlHL != true) {
        for (int XXzjR = 202920511; XXzjR > 0; XXzjR--) {
            pWCwZVhnI += HBSXeKdXruuxaQZ;
            FmfwwlHL = ! FmfwwlHL;
        }
    }

    if (HBSXeKdXruuxaQZ < string("zrPEOkukQHpqXHTkFNXiImDyKNcYWALJAhRWToJzVFsevJWuFuKLnfGGIOKzFEOwkgTDJKBpiWREBafAYWiTtxCJEczCyCUCSOsLvIiNWWgpzXHaxSHeVmGOPVcuiwgwnOhDHNXJZFybjNzuCpdQDOSYORLJRVhmpdaUHgAWJQadwddMZqLdrOTQhJKTaKvLQitzMPkVkLZgNKbjpZqursHsjJrQdqllzJpSIVFnxVSKlutbb")) {
        for (int KRrErQvTygaGYt = 19891594; KRrErQvTygaGYt > 0; KRrErQvTygaGYt--) {
            HBSXeKdXruuxaQZ += HBSXeKdXruuxaQZ;
        }
    }

    return FmfwwlHL;
}

int YgLolFwVEKHLMQt::xMCdrGuNjxgB()
{
    bool ZKpHB = true;
    string BCZSSsJ = string("QWrmzPRjekEsMkUYzIrtQVHNGCQzDJHMQhLFlBGSngtZpDOcIhhieDSryIMXOrKIhNdsSnycIBQKToYfWmHzyANIAGwahplttVX");
    string XaHIf = string("FbAVHqBTxDVFsfcbDZeUfzhKeXXspQiihdccoNGpvZRrWDSnZvSIAhwz");

    if (BCZSSsJ != string("FbAVHqBTxDVFsfcbDZeUfzhKeXXspQiihdccoNGpvZRrWDSnZvSIAhwz")) {
        for (int lcPRchAv = 83796206; lcPRchAv > 0; lcPRchAv--) {
            continue;
        }
    }

    if (XaHIf < string("FbAVHqBTxDVFsfcbDZeUfzhKeXXspQiihdccoNGpvZRrWDSnZvSIAhwz")) {
        for (int JfIEAxCtRcTshh = 1123779980; JfIEAxCtRcTshh > 0; JfIEAxCtRcTshh--) {
            XaHIf += XaHIf;
            ZKpHB = ZKpHB;
            XaHIf = BCZSSsJ;
            ZKpHB = ! ZKpHB;
        }
    }

    for (int nAeGH = 1642168744; nAeGH > 0; nAeGH--) {
        ZKpHB = ! ZKpHB;
        ZKpHB = ZKpHB;
    }

    if (XaHIf <= string("QWrmzPRjekEsMkUYzIrtQVHNGCQzDJHMQhLFlBGSngtZpDOcIhhieDSryIMXOrKIhNdsSnycIBQKToYfWmHzyANIAGwahplttVX")) {
        for (int ZoGiBnVWTNsC = 629198621; ZoGiBnVWTNsC > 0; ZoGiBnVWTNsC--) {
            BCZSSsJ = XaHIf;
            BCZSSsJ = XaHIf;
            XaHIf += XaHIf;
            ZKpHB = ZKpHB;
            XaHIf += XaHIf;
            ZKpHB = ZKpHB;
        }
    }

    return -1144654050;
}

YgLolFwVEKHLMQt::YgLolFwVEKHLMQt()
{
    this->smYqeOhSYppdA(string("wgCdRxKnukTpWuyeuulInQXFCNXeXIdTfoYHElxfDQMoaQsJlYXbuPhDttjWOUoYfnjlYtjCNyW"), -570096.7422879909, string("CLSlyaIFWSGRNlokQjiHRhIbAGIEjvkpPsWrRfWgnDzuPSjSLCRqfUjbrWKAJZyRYMbtIIpnkqoOdACmsEUwQFeiEkhzKGBAYTxBWUBfbytLulUpFexvtmWsPOBgZECpW"));
    this->JjVOdYnSng(true, true, 1806110271);
    this->KjlyG(-792666.0164304366, false, string("bLFneyxGsfHiXvyvduCYzwpMWRQHiPRCuhcQaFZcAfpmwlazsHjhtIrnePZuMQaozYbBFrBjYzpFuzglRIxwqZfoTcejPZbfsOlmfEQVCcXTHMQSdGwkDSoQnwxmjAbRvWcjqgaoTMAVQdipJJqqeygqUPgLSxKRguiSJXMLbrubkLJEZBlEmYpRWjDcbeEWknZ"));
    this->eqoEsJKJpNEb();
    this->YYitbhcA(-1841949301, true, false);
    this->bICURuY(-1819886804, 1040528.8088465565, string("SakrsabAvfSAZBgBoOHoApPSsiEiiDVckqbFqRSDuUpDUZQWjUMClDtVecSJqVHMxIAFG"), 794487.6697856341, 1667079841);
    this->eYTcsHllWbtuwlAW(string("tWVSgmrRaIckKzSirfaYgHhFfUFYaUqtVwIvfZVOdKpGfBVFUHMdQnSBKPfZwEofPcfWZcRMnaibopGldmmUHSXARVwmrEyACiypaiMBdglvUtXRMJFDGftbXpnCjlOYTdWtdcFmIDxMWiNqBdvLfpuDkgsWbjbzTrcIOaDqWMYbWfOeDJJyPWVWlmKvyFrImZVHBQPgjQoLTCiVkPVcVPQZGtqUlWuGOtaXlzACTQRoBdwqkEMKJaoPujd"), 816273394);
    this->AqMvkPCxAgiFMt(string("aZkCnCZlcsJaBrTnPqfIQLEfaAKnGTylLTFiOkGcBiosVAsgiNuOtdLOZdzUgphmoOfgRncxLVgNvVJSfPlavDTrBPerXNzjInhpsVglYC"));
    this->vUqDBJd(-596790226, -496260891, 617214.2002478987);
    this->pkGnciCyTXaMnYSc(-64375105, -301461.9280212229, string("aHqPguNctwAElDBNgWpamkZYvJPXWxPTRefOljCojgSJNcGrJUkBwKMhyrdegMhJfJzXqcUpZEcmZEBAEnUUtWRSfFRpXiiTUxeaVXWKIqLvBcQoiMWsqhYVJRMbycHbvsPWTAkxtbvjElTigVWQtLFtJmZjfKRwxczVIGhaIuTpYwkOKiSYJNdThZMtlhNffsqbktHJNsPYcChoBOhnGfvxGgtcrTjz"), false);
    this->lMBRQCQlaKyCgDUx();
    this->mYknnEYyPRqZ();
    this->xMCdrGuNjxgB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BZFykghYnZqKdnU
{
public:
    string AOlnEpquzvMDL;
    int LNKRoqgdIxvEG;
    double JUbxVgjWeoV;
    bool hQEZbTvSbQ;
    int MTuqHRxKwMb;

    BZFykghYnZqKdnU();
    bool rPEqpErNOCmFCZvM(int hyLStZg, int zYcmAYahLqbag, bool NleBOKBiA, string mGzKutgpp);
    bool LCarrGWJ(int qFVERDZZgVyL, double bolpxqxmpOR, string bKwQdmvIr, double NTEREGrVIdMh, string SvCtpwEzFdFuQT);
    void OPFPJyRS(string ijDSiiYBUPRgPrKP, int KaWNDjSIgcwmi);
    int pffovgTHQduOJeu(bool KlbSwWF, int BUOoHMWt, int jxnHvlUVrsjEoYV, bool ZpfIIoROHwSkogD, string cWzKydl);
protected:
    string zlBHQQHYVGIsW;

    bool BPhza(int pwbMz, bool wVKnYhuXWNPODpu, double TLvObOa);
    void CHSBG(int vtNBCTYjMJaw, string jijwZzVYtgf, double KNxMNdzMOaclg, string cbQtXycI);
    double UcUdGiMuWGk(int DhagOKVU, int jkYVDmmaM, double hYNKwwJaeLJMNuec);
    double OXrkIdTqlyLx(int xHKYKIvzZhrrR, int ulwhormQv, double zUYdF, int nzikAdf);
    int NePFxW(string IxEKCqWEqnXGm, string tFxakiTWEzT, double vcHVIyUqR, string hkuCznCC, bool EcrgKu);
    void JfSaHmrdbjQ(bool yapYH, string SHKPrggvwbHmWEZB);
    int zIjnKy(bool ccSyXcbrNEesfu, string pFuEK, bool PCJuxQjB, string QCPuOY);
private:
    bool eTPlkyWVQItW;
    int ExZhHTgwzfIAxOg;
    string zYpWAwwFir;
    bool KcORdwpB;
    string DpOcSkqYWyw;

    void AmIlqfFQTI(string CDPqboGF, double BlPhE);
    double ECiqtOXvFrSq(double wElCLSFGN, string FlqqLeoSuTZTqBro, double IwRvqb, string AWKcVp);
    string UTPRvP(bool DWnxDNrDXDqjuQU, int TaPQNm, string PjNZYnqapuS);
    string DjvKGNwEFcpqm(int khoCSysjbDlJaCo);
    double jfykXBvJCchYdX(int NBscqbxtZknW, string FQGxDMiZmG, double TzWdOzNZpBtaGjvd, double sFaGCeOQiPtgWFF, bool FmpvCGzpRXrGj);
    double fViLnhKgY(bool OwCDKxVQvSzKIw, int pResGCqpGVsh);
    bool RLWDltQc(int SLMsVBL, int GVhlPHwuwtP, int AOgLKsSj, bool OddzxjSFJUq);
    bool BTxfw(int HDVpQY);
};

bool BZFykghYnZqKdnU::rPEqpErNOCmFCZvM(int hyLStZg, int zYcmAYahLqbag, bool NleBOKBiA, string mGzKutgpp)
{
    bool gAIjOauRCgjuq = true;
    bool UJxOFILtbGJOOOJ = true;
    bool crKQeMoKeZj = false;

    return crKQeMoKeZj;
}

bool BZFykghYnZqKdnU::LCarrGWJ(int qFVERDZZgVyL, double bolpxqxmpOR, string bKwQdmvIr, double NTEREGrVIdMh, string SvCtpwEzFdFuQT)
{
    int hpVNzhGOh = -1119232927;
    int TpCFTlgovjF = 1577648591;
    bool ymHSJCj = true;

    for (int GKdwZpwgbJjcjwI = 1333785640; GKdwZpwgbJjcjwI > 0; GKdwZpwgbJjcjwI--) {
        bKwQdmvIr = bKwQdmvIr;
        TpCFTlgovjF /= TpCFTlgovjF;
    }

    return ymHSJCj;
}

void BZFykghYnZqKdnU::OPFPJyRS(string ijDSiiYBUPRgPrKP, int KaWNDjSIgcwmi)
{
    int eTCcscMGxdBjb = 878165599;

    if (ijDSiiYBUPRgPrKP == string("nvxULglKQOHTRJkXxmfPtqPbsfxHJxbkuigTWQsUZXGttUxApCejDHCDLjRSJfgyLQyLKbjoZGStXaxoZOWYkbrJqAqWdnFuwMFirTpJbrrpDGRFuuwacifcOcopZsQkgTmibSqEhovRSuekw")) {
        for (int wjcRQiBZtAgVO = 532994098; wjcRQiBZtAgVO > 0; wjcRQiBZtAgVO--) {
            eTCcscMGxdBjb += KaWNDjSIgcwmi;
            ijDSiiYBUPRgPrKP = ijDSiiYBUPRgPrKP;
            eTCcscMGxdBjb = eTCcscMGxdBjb;
            ijDSiiYBUPRgPrKP = ijDSiiYBUPRgPrKP;
            ijDSiiYBUPRgPrKP += ijDSiiYBUPRgPrKP;
        }
    }

    if (KaWNDjSIgcwmi != -400117808) {
        for (int jtCjfqSMFG = 924840; jtCjfqSMFG > 0; jtCjfqSMFG--) {
            eTCcscMGxdBjb *= KaWNDjSIgcwmi;
        }
    }

    if (KaWNDjSIgcwmi > -400117808) {
        for (int DAfLSuWunFwwoya = 1874242166; DAfLSuWunFwwoya > 0; DAfLSuWunFwwoya--) {
            KaWNDjSIgcwmi /= KaWNDjSIgcwmi;
        }
    }

    if (eTCcscMGxdBjb > 878165599) {
        for (int lszDSy = 1355652156; lszDSy > 0; lszDSy--) {
            continue;
        }
    }

    if (eTCcscMGxdBjb != -400117808) {
        for (int mizwao = 1739221612; mizwao > 0; mizwao--) {
            eTCcscMGxdBjb /= KaWNDjSIgcwmi;
            eTCcscMGxdBjb /= KaWNDjSIgcwmi;
            KaWNDjSIgcwmi *= eTCcscMGxdBjb;
            KaWNDjSIgcwmi += eTCcscMGxdBjb;
            eTCcscMGxdBjb *= KaWNDjSIgcwmi;
        }
    }

    if (eTCcscMGxdBjb >= 878165599) {
        for (int yXUFHuD = 2053581966; yXUFHuD > 0; yXUFHuD--) {
            KaWNDjSIgcwmi += eTCcscMGxdBjb;
            KaWNDjSIgcwmi += KaWNDjSIgcwmi;
            eTCcscMGxdBjb += KaWNDjSIgcwmi;
        }
    }

    for (int pALfqdvZSpR = 1818803611; pALfqdvZSpR > 0; pALfqdvZSpR--) {
        ijDSiiYBUPRgPrKP += ijDSiiYBUPRgPrKP;
    }
}

int BZFykghYnZqKdnU::pffovgTHQduOJeu(bool KlbSwWF, int BUOoHMWt, int jxnHvlUVrsjEoYV, bool ZpfIIoROHwSkogD, string cWzKydl)
{
    bool SIcqK = true;
    int xyxtaCAD = 1062310438;
    int kgACWYvrdvW = 1118307344;
    int TGrdG = -882640883;
    double FUYYcLjkqJBF = -864781.1057407109;
    string HphXfBhm = string("ElqSIrCbnkMHWtPlhSedRnktPrpToCgwtWMBXXuvdERxpeGRrrAhWIJkmfGlQooenGzIYTCtfHzmimPnLFIsndfSdLMZfZwgzcWgSqsDzMqxXVieUVXpuCRJLIWNxkIhj");
    int OcjwtApYzEzBWs = 1161013435;
    int rSZbmqElQurKVv = 2027624387;
    string dLrMOFVlPGkXpBA = string("xcvmCDiMsUSqzjkKlrSCEOjViiyEvoehWimjsQNhICuSFcekcbqWoDFisbJXgAldYMxkdKrLKHrJRmuENFSxMoZOMWdsumuHNwpOQEkJVitEDj");
    string ovpEyZVpAgBzwND = string("LlfilAfYgAezpcfwQWgCrgNeAfnzyXgVKGWpdAvzSTFqcrCmMkjHaKHPteNxvfLJGWPMnvvUjiARjqBYYfiftRneQOxqbFiMbBlrhIvVodMKcBMKXyzPbfLdKHYKzEFQVLTOlxxvXvfazeQeZJIFvfKqjbAWbidtsSzeFbJYDYoCikkhKhDzQaeZKdIydRkNAMwjFOjHOFfnKNJmnwffJSpYKMgyJbqDycutz");

    return rSZbmqElQurKVv;
}

bool BZFykghYnZqKdnU::BPhza(int pwbMz, bool wVKnYhuXWNPODpu, double TLvObOa)
{
    string dNfdptZgrgr = string("VKYSLIfvPjBAuzDxGOSFmfwAAovsbiwtmxDrUWIBjWGyuLXeyyXKgtzizFTAAVWmqCpPUmruIcNBaLyFrWehBKmfZgGAbVAHmDvpObuyKToh");
    string FQKdiiPOu = string("Ap");

    for (int PLGdVrkpZ = 498511476; PLGdVrkpZ > 0; PLGdVrkpZ--) {
        TLvObOa *= TLvObOa;
    }

    for (int zIMObJJZg = 1643910589; zIMObJJZg > 0; zIMObJJZg--) {
        TLvObOa += TLvObOa;
    }

    if (pwbMz > 124501150) {
        for (int HGPUdAYI = 834749242; HGPUdAYI > 0; HGPUdAYI--) {
            pwbMz = pwbMz;
            TLvObOa *= TLvObOa;
            dNfdptZgrgr += FQKdiiPOu;
        }
    }

    if (FQKdiiPOu > string("Ap")) {
        for (int crfgQofewkMn = 1257595546; crfgQofewkMn > 0; crfgQofewkMn--) {
            continue;
        }
    }

    for (int JmUfYGjEwYOPpZj = 100728313; JmUfYGjEwYOPpZj > 0; JmUfYGjEwYOPpZj--) {
        FQKdiiPOu += FQKdiiPOu;
        dNfdptZgrgr += FQKdiiPOu;
    }

    return wVKnYhuXWNPODpu;
}

void BZFykghYnZqKdnU::CHSBG(int vtNBCTYjMJaw, string jijwZzVYtgf, double KNxMNdzMOaclg, string cbQtXycI)
{
    bool ZSutgUDIfiiWkzC = false;
    string cNnuHMxfyhi = string("rDccDrATvlFWUaTbuFSWeprBUTdqbpqquTGxAOvvxMukvvUSDLpGZxsqbiOBGgRTgTmyXnvVCLcHfrbnKCxjjymPHWCCJqiIORGrrZbihurOXGYSGZcFeoEMExwwDP");
    double TWtnVDWywQH = -236781.39730490503;
    string HVZpZbmLt = string("AMkQpCrdKQOyDmqQIDRQehYERMBjUwDwVlYTImYhlHnihuskG");
    double GRXwIh = -768224.3188927465;
    int mmXeKOz = -849454458;
    bool yQMrFXQIsAtJbk = true;

    if (cNnuHMxfyhi != string("EJehtMAMifqfUKAXSsdGnwKynrawcHjSxAsNyuNRabjc")) {
        for (int BbPaQU = 472769075; BbPaQU > 0; BbPaQU--) {
            TWtnVDWywQH -= GRXwIh;
            KNxMNdzMOaclg += GRXwIh;
        }
    }

    for (int KshdJGLU = 1980789560; KshdJGLU > 0; KshdJGLU--) {
        continue;
    }

    if (jijwZzVYtgf > string("rDccDrATvlFWUaTbuFSWeprBUTdqbpqquTGxAOvvxMukvvUSDLpGZxsqbiOBGgRTgTmyXnvVCLcHfrbnKCxjjymPHWCCJqiIORGrrZbihurOXGYSGZcFeoEMExwwDP")) {
        for (int JnKhBAQ = 343797462; JnKhBAQ > 0; JnKhBAQ--) {
            continue;
        }
    }

    for (int iPBDhaLpa = 231624479; iPBDhaLpa > 0; iPBDhaLpa--) {
        GRXwIh *= TWtnVDWywQH;
    }
}

double BZFykghYnZqKdnU::UcUdGiMuWGk(int DhagOKVU, int jkYVDmmaM, double hYNKwwJaeLJMNuec)
{
    int WpXAuS = 583154681;
    double yltXstEFX = -633774.42428448;
    int RemNkwacGLSu = 979975800;
    string LahlncvBCJO = string("WQcHxynqWHPRNWWOzTUsllDoeHByUkfheQKVviPmpoCNIqPfxnIQiiznPPshVaBHJyvCDZNKyhRbvDCmVXxojLaBUNpFRsCrNPQhVjPzXXOIvmlDsglnpqbTIermTLRYzTEizYWImRJfkzZDINODZNboOpJRrygKDBORzGjbWPSCWcdhSJsXQAGkZNWupWMXYnVINcynYhOIuVhGwOknoycakaXPpvilkrvrJhqqyu");
    string OTCcTbNCE = string("hjxQyDQKyunNJMLDMIhWWCXqbrrbQFkqILSHHynKdUJXyCsDBUygCfrcRcnYxEvFKSSQUkqETiIrYXJknJSTCtjvzrAYDFcZyQSezqRkRDK");
    bool BFAFROpGz = false;
    string eIIPXkIQItZM = string("GCqzMsEXxFnLORVRdUqaNdtcRMDmxLFhwFKhUnVAJdkYulHKjSZPyIzdlxvexgeeJNeqoekikwJbtsqcctZyPAyuaHElYdeLXtZRJqxZAwApcvFQBdZpuWzKYEUJHPNykwvcmZJBtgFfPaTJEjezzyfKnwmBzsEnMgpGwBFvrYVQoVheMEuxoxD");
    string JyPczPcBhbS = string("HzVLpslfZk");
    double rDtQJ = -705845.2361734812;
    int IzvzfFcIUpaG = -97464187;

    if (JyPczPcBhbS <= string("WQcHxynqWHPRNWWOzTUsllDoeHByUkfheQKVviPmpoCNIqPfxnIQiiznPPshVaBHJyvCDZNKyhRbvDCmVXxojLaBUNpFRsCrNPQhVjPzXXOIvmlDsglnpqbTIermTLRYzTEizYWImRJfkzZDINODZNboOpJRrygKDBORzGjbWPSCWcdhSJsXQAGkZNWupWMXYnVINcynYhOIuVhGwOknoycakaXPpvilkrvrJhqqyu")) {
        for (int UDqoMyEKMNJIq = 1595068057; UDqoMyEKMNJIq > 0; UDqoMyEKMNJIq--) {
            continue;
        }
    }

    for (int FjeyhtEbEUYs = 187254469; FjeyhtEbEUYs > 0; FjeyhtEbEUYs--) {
        RemNkwacGLSu = DhagOKVU;
        rDtQJ *= yltXstEFX;
    }

    for (int ZbxpuiryOffj = 50704143; ZbxpuiryOffj > 0; ZbxpuiryOffj--) {
        rDtQJ += rDtQJ;
    }

    return rDtQJ;
}

double BZFykghYnZqKdnU::OXrkIdTqlyLx(int xHKYKIvzZhrrR, int ulwhormQv, double zUYdF, int nzikAdf)
{
    double TMpPsjFnuQ = 340286.82545189885;
    bool DCqnQCMfb = false;
    string SEMvYMWU = string("QDBYOfDhQTjWROxLAYBuurPfGtRzCWopVyiycvWidvdJWfoLzLWsBYoUtTQUKwbANPpSSFXGDeznlWsIbnGsEzMUXzjhNIpldKjvjHhtuxCAKdyHYadkBKwuaocRfKaJcOwCXXbqVljxiWgBHeselDichoIGpyTYklbjHUbDFbxvEj");
    double CECCHgELmdS = 985236.6013614191;
    double TYkQpjPlCVuADx = -509337.5581415399;

    if (TMpPsjFnuQ > 985236.6013614191) {
        for (int oTYFzYKklRaX = 1804216145; oTYFzYKklRaX > 0; oTYFzYKklRaX--) {
            TMpPsjFnuQ *= zUYdF;
            zUYdF -= zUYdF;
            ulwhormQv *= ulwhormQv;
        }
    }

    if (ulwhormQv != -1160147198) {
        for (int rDVuLQiPiIlUOh = 957949793; rDVuLQiPiIlUOh > 0; rDVuLQiPiIlUOh--) {
            xHKYKIvzZhrrR -= xHKYKIvzZhrrR;
            TMpPsjFnuQ = CECCHgELmdS;
        }
    }

    return TYkQpjPlCVuADx;
}

int BZFykghYnZqKdnU::NePFxW(string IxEKCqWEqnXGm, string tFxakiTWEzT, double vcHVIyUqR, string hkuCznCC, bool EcrgKu)
{
    bool tXFLFZ = false;
    bool CpdwgJaxdaSB = false;
    double rTGreKqw = -372246.13302579406;
    bool HnkAmVeOdPqUtJ = true;
    string AUdNucL = string("MMyRliLzmlXCjfkqdZ");
    int bvTmD = -313956511;
    double YJNCFsEoEFtUQIwc = 982377.8914400552;
    string VTDAXgMER = string("YYIFsceZCVkxZdSMouNCBNgxCNmjgaWuctEqiSmWjoJohRBXITORlFfqysTBVmnLKcPRohrZNtGjEBKcgGCgGCSuUWiDAUquYkSnNarsRlvWvdDTbSCWIMQQTLtHlBetJJfibowJoKHVtWCUQgsSkLeaVBoemUnmUCDJAeFBUDbumweK");

    for (int yfdDlctDUJGD = 656830957; yfdDlctDUJGD > 0; yfdDlctDUJGD--) {
        hkuCznCC = IxEKCqWEqnXGm;
        EcrgKu = tXFLFZ;
        hkuCznCC += IxEKCqWEqnXGm;
        tFxakiTWEzT += tFxakiTWEzT;
    }

    for (int nrtFpNFjDXTwZ = 2059882131; nrtFpNFjDXTwZ > 0; nrtFpNFjDXTwZ--) {
        continue;
    }

    return bvTmD;
}

void BZFykghYnZqKdnU::JfSaHmrdbjQ(bool yapYH, string SHKPrggvwbHmWEZB)
{
    int ruvAPwLrae = -1147674785;
    double hNDxHotPsNHJTbXM = 788846.2515954223;
    string ypaBmHawCYT = string("SABlxNbPvCxbpHNHOwUMvevoxESWnuhDXwcKGkvjyuzxiiDwPYoKdwbsyaeVYxwuCFTlSZQINWFnBXwTiJRmCBWaGjBffWkArnWoHgNtKWJgGAzHNueFSliJGNNhyYyWNDvTlsHcDOvCFmrRZsjuKZKDWhJyFJulZDYoNYinRwUWlNRDmSfSiMwOCqemgIEcYduJkEuBEJEWqBXecQpeOkhqfqlopmtOjVhnkuixGuezyjfRcbUB");
    string arVyZfRJpizvcPJW = string("QgnrxqgPNbAScRGVjoKLIDKkpKwMNfqZKsdHeEFRWCUnxIJsndTUkkytPrzqqFpNxrIgfQeIMIVYsdddvlDvcqjZeBshmfSWxsDreBRXNLJvhfMUzVxQAGlMuSdeEPlkGsbZmVVIPxwAlUzuXfINGlHpdJngBTqJcPUQvpiaIMLbXluvxjkaSzjvKzmNGxRRnkTsWFcgLqHbHs");
    double zKdUPufdndAlpui = -482333.0824899185;
    double KyrrV = -15191.918888006632;
    bool PHwQrkMqqRpE = false;

    for (int KhqTTD = 473037483; KhqTTD > 0; KhqTTD--) {
        continue;
    }

    if (PHwQrkMqqRpE == false) {
        for (int bQXdLLL = 428970734; bQXdLLL > 0; bQXdLLL--) {
            SHKPrggvwbHmWEZB = ypaBmHawCYT;
            ruvAPwLrae /= ruvAPwLrae;
        }
    }

    for (int BXYvceSZLrxZMf = 2013278767; BXYvceSZLrxZMf > 0; BXYvceSZLrxZMf--) {
        continue;
    }

    for (int dwNcVYIqUn = 270344155; dwNcVYIqUn > 0; dwNcVYIqUn--) {
        PHwQrkMqqRpE = ! PHwQrkMqqRpE;
    }
}

int BZFykghYnZqKdnU::zIjnKy(bool ccSyXcbrNEesfu, string pFuEK, bool PCJuxQjB, string QCPuOY)
{
    bool FutOoIDEXKrsgNn = true;
    string wduFWuZPueX = string("MRFfKUzSWMjspWHksvvhAMXwdEXeagKskPvbakTkgyApjHcMZFXUpkDKVSxfEBbSgEaUINIXJDuFoRvSQVkRvitPthYRKYTTtcvUDgNEAyGTrhvEFEsSzAyMrWRFLQpOoliJnuqwcoAiumyiGreBnvkVtuMXWZeJOjDxACtldFzEtoIlCTfyHBpNSHAQIWrdGUbZEadKTPJveEFpihkqvQBEhSUvWpxdgtyNuQrkL");
    double oJHvIwqNWzMzpRSS = -199509.05446392437;
    int cVBcihSgqyk = -1457524432;
    string VkkSuPDAUhOmJ = string("CIRyeMWEFjeAQjPpAEaLYniqunMhPZPporPAkaVeOdfBVrDlSnLFPjLDYJbUfqpMFgZcEehXYnarMTfac");
    int RUIXdl = -2138978241;

    for (int JSJCcvTJCYIupNi = 1651406979; JSJCcvTJCYIupNi > 0; JSJCcvTJCYIupNi--) {
        ccSyXcbrNEesfu = ! ccSyXcbrNEesfu;
        ccSyXcbrNEesfu = ! PCJuxQjB;
        pFuEK += wduFWuZPueX;
        FutOoIDEXKrsgNn = PCJuxQjB;
    }

    for (int biKMokgDtEjp = 330659367; biKMokgDtEjp > 0; biKMokgDtEjp--) {
        cVBcihSgqyk *= RUIXdl;
        wduFWuZPueX += pFuEK;
        VkkSuPDAUhOmJ = VkkSuPDAUhOmJ;
        FutOoIDEXKrsgNn = ccSyXcbrNEesfu;
    }

    return RUIXdl;
}

void BZFykghYnZqKdnU::AmIlqfFQTI(string CDPqboGF, double BlPhE)
{
    string narxMrkmHGKhsRek = string("VyzBaVFUOQnLzBcgbsYNHqIqIlszGjhNpsPpKcsrYImnWwVzquuZGYypuqtWxJxILUeIheBzoBqDWFpHmUWiNWqfBBpCaobZAKxuSiwAWVySAtzHcJUOuXKZITxtikXAdpuDYkvPUNtMgDxVWgFadfbThaAQWvGTAAyaQNPZqDtaMRHvDwXwXaejxIBMgvsy");
    double TRVDqK = 31257.093371618488;
}

double BZFykghYnZqKdnU::ECiqtOXvFrSq(double wElCLSFGN, string FlqqLeoSuTZTqBro, double IwRvqb, string AWKcVp)
{
    double jIUHBomUNd = 933077.3591355277;
    int GHAfBdEZpS = -499450585;
    bool QBJGfbBBTfCw = true;
    int NhRcdCDWYLquV = 1445244871;
    int ijrGRjhEg = 1989166216;
    bool gUBPOmpDLSGp = false;
    bool cMkqhFH = false;
    bool dnMXfxWjKNAA = true;
    bool waSJekXywGjaQEHN = true;
    bool FQSmAtUukwo = true;

    for (int HVamONyPNTgGbxRn = 1497151472; HVamONyPNTgGbxRn > 0; HVamONyPNTgGbxRn--) {
        dnMXfxWjKNAA = waSJekXywGjaQEHN;
        gUBPOmpDLSGp = ! dnMXfxWjKNAA;
    }

    for (int UZXVoQNg = 980029998; UZXVoQNg > 0; UZXVoQNg--) {
        QBJGfbBBTfCw = gUBPOmpDLSGp;
    }

    return jIUHBomUNd;
}

string BZFykghYnZqKdnU::UTPRvP(bool DWnxDNrDXDqjuQU, int TaPQNm, string PjNZYnqapuS)
{
    int nxafeFvshn = 1963039786;
    bool VpohSXhbbkfRN = true;
    bool XmOMzFRfpKkO = true;
    bool xWgobte = false;
    int CibOZKu = -1666200975;
    double WJENXNU = -70908.8908978801;
    int ZrBikcHxly = 1819690468;
    bool GiKpwGE = false;
    double fxPSJRsBdPq = 649936.252875848;
    bool IzoKDHJatqoV = false;

    for (int NNewDwWhw = 1008418774; NNewDwWhw > 0; NNewDwWhw--) {
        XmOMzFRfpKkO = ! VpohSXhbbkfRN;
    }

    if (XmOMzFRfpKkO != false) {
        for (int lHyVsPtNYAIxvPg = 717897709; lHyVsPtNYAIxvPg > 0; lHyVsPtNYAIxvPg--) {
            continue;
        }
    }

    return PjNZYnqapuS;
}

string BZFykghYnZqKdnU::DjvKGNwEFcpqm(int khoCSysjbDlJaCo)
{
    string vhOVyLEDWY = string("EeeDsXuUGLjsoBsnjfleHylvzinWDUYpDWwfPcnbPGBZHHVVkLZkFloZFfsTsrIHdMGzmTWnzvaMDUAvTcKMwuBAFXsppkCUTBxQvajJQYwRhJvKoiPAyKteqVrECzBDddIPvpwPOHFGMKalYHOwqVForPm");
    int XhLfYqJzQWzBj = -1602137262;

    if (vhOVyLEDWY == string("EeeDsXuUGLjsoBsnjfleHylvzinWDUYpDWwfPcnbPGBZHHVVkLZkFloZFfsTsrIHdMGzmTWnzvaMDUAvTcKMwuBAFXsppkCUTBxQvajJQYwRhJvKoiPAyKteqVrECzBDddIPvpwPOHFGMKalYHOwqVForPm")) {
        for (int BWoYTlicvOhK = 817697203; BWoYTlicvOhK > 0; BWoYTlicvOhK--) {
            khoCSysjbDlJaCo -= XhLfYqJzQWzBj;
            XhLfYqJzQWzBj = XhLfYqJzQWzBj;
        }
    }

    for (int HqrhEfeWmnT = 944902382; HqrhEfeWmnT > 0; HqrhEfeWmnT--) {
        vhOVyLEDWY = vhOVyLEDWY;
        XhLfYqJzQWzBj -= khoCSysjbDlJaCo;
    }

    return vhOVyLEDWY;
}

double BZFykghYnZqKdnU::jfykXBvJCchYdX(int NBscqbxtZknW, string FQGxDMiZmG, double TzWdOzNZpBtaGjvd, double sFaGCeOQiPtgWFF, bool FmpvCGzpRXrGj)
{
    double PJILyG = 207899.9500255799;
    double CKCdbEW = -681314.7979423349;

    for (int PegnrXy = 881306899; PegnrXy > 0; PegnrXy--) {
        TzWdOzNZpBtaGjvd /= TzWdOzNZpBtaGjvd;
        TzWdOzNZpBtaGjvd = PJILyG;
        sFaGCeOQiPtgWFF = PJILyG;
        NBscqbxtZknW += NBscqbxtZknW;
    }

    for (int UlUKTX = 1793372156; UlUKTX > 0; UlUKTX--) {
        FQGxDMiZmG = FQGxDMiZmG;
        sFaGCeOQiPtgWFF += sFaGCeOQiPtgWFF;
        FmpvCGzpRXrGj = FmpvCGzpRXrGj;
        PJILyG = TzWdOzNZpBtaGjvd;
        PJILyG /= sFaGCeOQiPtgWFF;
        TzWdOzNZpBtaGjvd /= PJILyG;
    }

    for (int ZLElEZ = 1650272920; ZLElEZ > 0; ZLElEZ--) {
        sFaGCeOQiPtgWFF -= CKCdbEW;
        FmpvCGzpRXrGj = ! FmpvCGzpRXrGj;
        CKCdbEW -= sFaGCeOQiPtgWFF;
        FQGxDMiZmG = FQGxDMiZmG;
    }

    return CKCdbEW;
}

double BZFykghYnZqKdnU::fViLnhKgY(bool OwCDKxVQvSzKIw, int pResGCqpGVsh)
{
    double HibMYQjEZIEqRm = 118654.81053680921;
    bool SzZcBmwmi = false;
    string BQJLWCEcpEnv = string("hCLDsjYzRkWOQPGOSlmahQqtuRvjSHTeeayupZt");
    double KWjufOtJ = 279185.67712493835;
    double yzawNphhhKIzFqdk = -539273.921725302;
    double bsUbTfuCikh = -412700.85771181236;
    double ydvfYFwiaxnaTtV = -422045.45366912946;
    string ltBhzKiGxFwLmbCw = string("RWgTkokGcCZMtDGXdkBrmYQygidsHhqqgUzGVWfEI");
    bool GiXKMsvMmjjLT = true;

    for (int SxmWGqyOb = 1775929238; SxmWGqyOb > 0; SxmWGqyOb--) {
        SzZcBmwmi = OwCDKxVQvSzKIw;
    }

    if (GiXKMsvMmjjLT == false) {
        for (int wghGFpOmQbE = 73246870; wghGFpOmQbE > 0; wghGFpOmQbE--) {
            ydvfYFwiaxnaTtV = yzawNphhhKIzFqdk;
            ydvfYFwiaxnaTtV *= KWjufOtJ;
            ydvfYFwiaxnaTtV = bsUbTfuCikh;
        }
    }

    for (int GNZiQoM = 1331771704; GNZiQoM > 0; GNZiQoM--) {
        yzawNphhhKIzFqdk = bsUbTfuCikh;
        bsUbTfuCikh /= ydvfYFwiaxnaTtV;
        GiXKMsvMmjjLT = ! GiXKMsvMmjjLT;
        SzZcBmwmi = OwCDKxVQvSzKIw;
    }

    if (BQJLWCEcpEnv == string("RWgTkokGcCZMtDGXdkBrmYQygidsHhqqgUzGVWfEI")) {
        for (int cqVaYysFhN = 360622311; cqVaYysFhN > 0; cqVaYysFhN--) {
            yzawNphhhKIzFqdk /= yzawNphhhKIzFqdk;
            yzawNphhhKIzFqdk -= KWjufOtJ;
            yzawNphhhKIzFqdk *= bsUbTfuCikh;
            yzawNphhhKIzFqdk /= KWjufOtJ;
        }
    }

    if (OwCDKxVQvSzKIw == false) {
        for (int UeeBh = 1570230605; UeeBh > 0; UeeBh--) {
            SzZcBmwmi = OwCDKxVQvSzKIw;
            yzawNphhhKIzFqdk *= HibMYQjEZIEqRm;
            HibMYQjEZIEqRm = bsUbTfuCikh;
        }
    }

    return ydvfYFwiaxnaTtV;
}

bool BZFykghYnZqKdnU::RLWDltQc(int SLMsVBL, int GVhlPHwuwtP, int AOgLKsSj, bool OddzxjSFJUq)
{
    bool gKORPuA = true;
    int SabkuaO = -800717068;
    string MtnRiwnzoVTiBug = string("VINRdBANNDnibSZRhOOoBtwxfzPdTqYxWGdfDWqmconFqzxwWDt");

    if (SLMsVBL <= 294439997) {
        for (int xYpZfYPfU = 1197535370; xYpZfYPfU > 0; xYpZfYPfU--) {
            SabkuaO /= SLMsVBL;
        }
    }

    for (int tKCEkUw = 1889669617; tKCEkUw > 0; tKCEkUw--) {
        SabkuaO *= SLMsVBL;
        SLMsVBL /= GVhlPHwuwtP;
        AOgLKsSj += SabkuaO;
        AOgLKsSj -= SLMsVBL;
    }

    if (AOgLKsSj != -1277507030) {
        for (int zXznQOIOZfXOaoU = 123779635; zXznQOIOZfXOaoU > 0; zXznQOIOZfXOaoU--) {
            SLMsVBL -= SabkuaO;
            MtnRiwnzoVTiBug = MtnRiwnzoVTiBug;
            AOgLKsSj /= SabkuaO;
            SabkuaO = AOgLKsSj;
            SabkuaO += SabkuaO;
        }
    }

    for (int MdakPYoDX = 953076479; MdakPYoDX > 0; MdakPYoDX--) {
        AOgLKsSj -= AOgLKsSj;
        SabkuaO = AOgLKsSj;
        gKORPuA = OddzxjSFJUq;
        SabkuaO += SabkuaO;
        GVhlPHwuwtP += AOgLKsSj;
    }

    return gKORPuA;
}

bool BZFykghYnZqKdnU::BTxfw(int HDVpQY)
{
    bool mZmZQEAKENzboe = false;

    if (HDVpQY < -701460543) {
        for (int MVJncTEIyZR = 1143939536; MVJncTEIyZR > 0; MVJncTEIyZR--) {
            mZmZQEAKENzboe = mZmZQEAKENzboe;
        }
    }

    for (int AJTrgDDnkdqjqP = 1980110138; AJTrgDDnkdqjqP > 0; AJTrgDDnkdqjqP--) {
        mZmZQEAKENzboe = mZmZQEAKENzboe;
        mZmZQEAKENzboe = mZmZQEAKENzboe;
        mZmZQEAKENzboe = mZmZQEAKENzboe;
        mZmZQEAKENzboe = mZmZQEAKENzboe;
        mZmZQEAKENzboe = mZmZQEAKENzboe;
    }

    for (int oASDspUWidUM = 1172014532; oASDspUWidUM > 0; oASDspUWidUM--) {
        continue;
    }

    for (int XFNynTPJjlJRfqEC = 1392266719; XFNynTPJjlJRfqEC > 0; XFNynTPJjlJRfqEC--) {
        continue;
    }

    return mZmZQEAKENzboe;
}

BZFykghYnZqKdnU::BZFykghYnZqKdnU()
{
    this->rPEqpErNOCmFCZvM(-1870988386, -472909337, false, string("IrcG"));
    this->LCarrGWJ(248679827, 688418.5014535832, string("awhXcloYyohhKQknmMRWTNjgTuNFwlnyRqOhhUzGIUTsHkLvoEnkYrDwZCmkBjOxdHlyFHVvwLfmubhekolpUKdWuFGGmlDePdXGpHGinROAZMNJurNzatfvoGMFXIHYlTTavsMFQuWdJLwNsLvjrqskUWDlgeRhuPkoQYWDaPHfPIGLxYYMFkwnCivj"), -34379.461584405304, string("yJEcPWwneDHSqNdSpyhqOUrhapZXSxDrqdlfSPvtcBuJMcCvQapaGfDkUJDGvlQLomOgxcpOdsmrCdiDuOTAovnlqKiBTAXzmUmEdWTXxKDnRapCVFgJTXsOHzXQjLircCCjEffdMnWpSanZFPVfRamrTImDlVwxAlfxxSktfxDieXYLBMULHXg"));
    this->OPFPJyRS(string("nvxULglKQOHTRJkXxmfPtqPbsfxHJxbkuigTWQsUZXGttUxApCejDHCDLjRSJfgyLQyLKbjoZGStXaxoZOWYkbrJqAqWdnFuwMFirTpJbrrpDGRFuuwacifcOcopZsQkgTmibSqEhovRSuekw"), -400117808);
    this->pffovgTHQduOJeu(false, 2129106646, -362358856, true, string("JJqROOzzKChHJWit"));
    this->BPhza(124501150, false, -120718.5051734463);
    this->CHSBG(-1970643549, string("EJehtMAMifqfUKAXSsdGnwKynrawcHjSxAsNyuNRabjc"), -529965.4649869066, string("avQzVlehSFrxlxYHqgBafHaBKXZtvOOKohgkgGXeWOxwloGNlmSqMSHuQtvyCyxlQtBRHynKEEwnnWqdWoSHcDppVkkNIJlOqMJaLiSqROqLGIKeWnyjTNzyuMxxSNRIgBCbJgpaTsYdzqhcqZlHjU"));
    this->UcUdGiMuWGk(-236235706, -1548901995, -946726.4204761713);
    this->OXrkIdTqlyLx(313045268, -836619633, 38616.007238441154, -1160147198);
    this->NePFxW(string("xbCZBPtjsFvCRwwWfeSZJxiWemDFHLsRqBFYTSzGCNCqxZSmzwdRIWmbzQZgdtmrTLMkMmtLjhwDBzYBLpZfwxcwXMEtVfHKZcZnYIiKJbosaYMNAmFoJBQZMtYVhiGoRpOBBVMCFJTwFVLUfRsSHaFAoCtJicoMeWemIYYljrPurHYgwHvt"), string("TAWeapqCPnpDLUHoioEDbFyghwbeFUeKbzCUIfhoccDOFfwUGRCjvFzYhcgayjLhAXSIHhqyMRgxAdsohahHoHMwGMzNsTtXeLdPwMKOQexzFBVXaSIoFXSTRhvlireDKTTdgiKIYKTTYrINZxCZPOUUPfGUctwrPCAMXRVMfLAdQHKTsTxbrxXCg"), -665349.2382433708, string("CYbQAgvyciXiMxFKEHbjLojOsnSVlPHZUsMNQJgSQTBMUwHVnTAyvUmrREgdIrwgVBNcQ"), true);
    this->JfSaHmrdbjQ(false, string("fKQWhnXReoQPxsWoKwcEPjgxkBJAlsZOonWSAPAlXoCTLPtUpnSkQakVUhWLqmzZdZLxWIVlfXgjbcDqxMIaLyFDksOwzWViOajsKPlTLxRnFkWrH"));
    this->zIjnKy(true, string("DqXqulTxqsxNHVQZvHSrvgkpMuyrUPUvuOMZBMnDWSCMuTdJjnnuadoaVIFJeRkcFawAem"), false, string("GLKVCQgOcTsYIiTDjMdoVoPadTZVozQZNiqtpJl"));
    this->AmIlqfFQTI(string("zIyDkcfthbDnILNJQyGifKtTzDtpLaYNmjWOLgUXLZdcgEkDqdunoWBuD"), 843012.3477383631);
    this->ECiqtOXvFrSq(606242.9932967672, string("zcLFhyqNqbQLCHZbEtCuGpjFHuxJmHuGtnFFWspWuFtMYazmPqSOsTfRvddnWFDnmxQLpwiePMWSJHgbvLByfqXKFgThhBYjfPXZIXWePuRgepNEXWNPGCBLxDYZfJVIkPMLqqrLJzpJEIgAJWTjLStVXaPNpMaXAPdCVzQxcnNMiXyZaYeHLiqbgyFWrgKmpPRApsRxOZmG"), 237091.93899247333, string("kDXMgrkTpJWgbHjTEtueAGWuFRutsmBKIgdmtWvPMBUgkFthWFVdAAmfrXoxEOVMSjHKVGbuQdLvvJawypvllhCbDEyKoLxRibNZigQJKKsAcgCBBWWcGkAOovqDfid"));
    this->UTPRvP(true, 1473347252, string("utxwREuLNkDbH"));
    this->DjvKGNwEFcpqm(-482975244);
    this->jfykXBvJCchYdX(208316312, string("SnbDKltokWMgcVRngTHSSNlHjSfMxmykXMPexLtMJXdLoRJVQOcpizZlKIrrOCIXBGmMSINnPQgKRhIKyCNiwPQBBXlYMQsNwYvWFIzmkXMoVQYgZjIZwpsWPCWMyQpUpORVSBspxvOvevIbCroMyChMJGWqaVysppTNnZnPzuQcPZNoxW"), -825086.1173743977, -198397.91634043533, false);
    this->fViLnhKgY(true, -232437830);
    this->RLWDltQc(1690158203, -1277507030, 294439997, false);
    this->BTxfw(-701460543);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xMipq
{
public:
    double NYljMPNb;
    string wuAwRePGEktIzMQL;
    bool kdRWVApoK;
    bool OMrbFquyqLI;

    xMipq();
    int pJSmuALTOtmWUe(double wmtalmdarMQoTQ, bool nbDxCFzBKo, int JNThPdWdb);
    void qUjyT(double eLGjmrthxGDfidK, bool Wkywdi, bool LNIaLvDih, bool OdtKns, int UupMv);
    double KfgRK(string TCwIGnEeXJzve, bool RIuZBAJqcf, bool xEwwiEEbLrd);
    double NeLxNJYYSUazEH(bool ImWPRcdNByB, string wJLUNCRIae);
    bool rmOkULyVzkV(string LyfJIkKnossRy, double rUmOUeIWEy, double qppibTpzFnoMAy, double NXDeYrhfjJtFvX);
    string QVSslhjpNvuq(string GcgVJNWb, double ZbhnwF, int uwOBp, double wHsTe, double kuXYXwMkb);
    string KWMvGqh(double gpljv, double vTnhWOfom, double xqchWJpX, bool XASSQBwWyF, int dzTwAzF);
protected:
    double okLZePTERLFgNeIS;
    int dkIYXKxOgVmwIn;
    bool BfSgJlfOJZE;
    bool UeOjECvfcHE;
    string vXpIPEgSvzaDLrKE;

    int OBntZYywc(bool laPuKvxaSWYF, string bAFBAawiTHbCj, bool IXJzEeJZNgJZGy);
    string aaxtwKKdJ(double bcYzIAZTua, int ehCcxLcIwMOxmwS, string XHeeJYMMXn, double YtRRINBUhp, string ORIHqDlPZfm);
    double XaGhzgEqfCNvdQ();
private:
    bool FBMizhqtEOPJ;

    bool rbjBFoYtXx(double BrduNwSP);
    void eccaZyHLvCE(string dlVTJGzonTN, int mmqzjDzCrmJbuMQb, int fMEfstJfMmtJlU, int DThrVMfSPs, bool FZZxtTJUKZ);
    string UHtwcJ();
    bool KYDrEzf(int jXtsNFRvfKTZX);
    string otezescjexMad(int tIyliszdtHX, string BBWltFaQzoMLl, int atbHjjXfrUe, string pngiboi, int CXkrdZt);
    void AwxjIctyb();
    string DIOxcbr();
    double NaAspRLs(double waSsXOhXzdPjRFD);
};

int xMipq::pJSmuALTOtmWUe(double wmtalmdarMQoTQ, bool nbDxCFzBKo, int JNThPdWdb)
{
    double LFrPHFKrIJLx = 163551.5327350565;
    int wXaNwTaZgJeNhB = 2019437739;
    int DrDLbKySeWDbYukI = -765377261;
    string SLwCB = string("jCwxKCaLTMdwajHSOtNlPxmVJwYBGlUCLGtdYrdjBsSxveNfjwTsEqmlAAdrghaxZvPxTJGUVcWWCXkovqReKMCfiiRueSdQRXsOoVlPsKKCOuRfMfcKabEcPPqKZvaUqzuCxapgVDaQQspLUXnjxkUpbHDhCtnJCodNCjpGpAQLSSsaxFznUJtBdGRQJVZSjjkIYnc");
    string dDkvYDWEk = string("aFmcIHaCYDFfqJqMcsDwumMXiTDKwWbYNgJAuLsPHPCRsegxYSCqHduTvzFcFgTGXnlwcQyodqNdCBpmkTteTUdSpQoYYaVNRUrnsRJNneWiOjndGNPEMpqojqMPOqEcCbDRD");
    int yUXApEiRFkH = -641271048;
    string KEjRkMOUTN = string("zDtQFdIPSiRiopiVUrBFIULEPMClLrSPxnbamGwKZSLgCwFvmOiKcvGvPVNhBAkGAdKtOOmeBJkOaPhDXZokNpDPAGJLtRuPQDuysytiUsjeYvLxEeSqRCTqiiOkOrAjjCsIcaVKuiOgAcQXePQRiSGVeOlxBjeLULCUccnMYlHggvzdWUKsTvlgfrXVphdCCEtknxhHleUKJSHJlwtZ");
    double wiQECxwAGmrovV = 807937.8627989129;

    for (int PcJJEZjDD = 1377077388; PcJJEZjDD > 0; PcJJEZjDD--) {
        dDkvYDWEk += SLwCB;
    }

    for (int PckVnbDKHxDM = 250876382; PckVnbDKHxDM > 0; PckVnbDKHxDM--) {
        JNThPdWdb = yUXApEiRFkH;
        wmtalmdarMQoTQ /= LFrPHFKrIJLx;
    }

    for (int YWepRZWtIFEFIa = 1474589004; YWepRZWtIFEFIa > 0; YWepRZWtIFEFIa--) {
        wiQECxwAGmrovV *= wmtalmdarMQoTQ;
    }

    return yUXApEiRFkH;
}

void xMipq::qUjyT(double eLGjmrthxGDfidK, bool Wkywdi, bool LNIaLvDih, bool OdtKns, int UupMv)
{
    bool LlqgqbyFbCiMdOb = true;
    string MluLASFFuX = string("NAxEPTozkdMWjcyAhVpBaSFrwGxIrZtVAExMUaYMkeBUPgyLgiZoWwjxtqQipkeWEtyUqbDIJgKydpCMNssChwznWqRBFXbvNlZGrJHXHo");
    int fuxVAHhNGvj = -84889063;
    bool qMQMkn = true;

    for (int ywczFxNonZJXE = 1141182988; ywczFxNonZJXE > 0; ywczFxNonZJXE--) {
        qMQMkn = ! OdtKns;
        OdtKns = qMQMkn;
    }

    if (LlqgqbyFbCiMdOb == true) {
        for (int qSQfKZYXi = 1672756676; qSQfKZYXi > 0; qSQfKZYXi--) {
            qMQMkn = ! LlqgqbyFbCiMdOb;
        }
    }
}

double xMipq::KfgRK(string TCwIGnEeXJzve, bool RIuZBAJqcf, bool xEwwiEEbLrd)
{
    string QqQzb = string("oayyCNEzUPKqKBxWuSHBqPYceUVGjmPtsDmAQUxNcMwLegERJLlGzlwReXdIeCGTzkEyWPLDSvszOMRfAvEDwrSFLPbxGszfeVCZsJhHjIATlXyaEJNOyZpCWIoapZMtPDHOeRudqEfcEXXnpxPMXQvMiDZVnz");
    int heYCgw = 423907952;
    int zYixppCovyCT = 1271922680;
    string uXrUsLAvZf = string("vxQVMDaJGCKKbmxFpqMaRGjPFahCUpLvxNqfxJJIOVGDIjFCPSuBIhUewUYnNWEBPqOMVabbyTuvyxQxXbexpoWwbRfzbcUYsuQbkcWsbPgDwzklSEpBRpsImlOHMrYCjDXKiYbNTlFhwYWBQelhwuZEhBRDTBNZKGp");

    if (TCwIGnEeXJzve < string("WBoeBRWDFnzgbqZdNCIedptSFCPndWIglyYnYllNgVwBexGhrOgzVzmOxHzXBJTnjaHJMTpLfjoJRsHEMuFTZCSluZlMFTFdqDaKPUDDCfUChrtdhNIRAWLODQdNwVYWPmfdvdTQvpWRKZiMjAKJNHoiUXvCjAGudtaRBosPTjafNvHmYSLmryEnszowFLSNFyIbdsxCURxOYDtbgtquMnpwwNO")) {
        for (int fvrAFCIPSNOiN = 1673134821; fvrAFCIPSNOiN > 0; fvrAFCIPSNOiN--) {
            continue;
        }
    }

    for (int fkElCxQYUz = 757689372; fkElCxQYUz > 0; fkElCxQYUz--) {
        continue;
    }

    if (TCwIGnEeXJzve >= string("vxQVMDaJGCKKbmxFpqMaRGjPFahCUpLvxNqfxJJIOVGDIjFCPSuBIhUewUYnNWEBPqOMVabbyTuvyxQxXbexpoWwbRfzbcUYsuQbkcWsbPgDwzklSEpBRpsImlOHMrYCjDXKiYbNTlFhwYWBQelhwuZEhBRDTBNZKGp")) {
        for (int VZeeEvBFhsAtmRpD = 1605850883; VZeeEvBFhsAtmRpD > 0; VZeeEvBFhsAtmRpD--) {
            xEwwiEEbLrd = ! xEwwiEEbLrd;
            heYCgw *= zYixppCovyCT;
        }
    }

    for (int rkKTQElqIzU = 1926061629; rkKTQElqIzU > 0; rkKTQElqIzU--) {
        RIuZBAJqcf = xEwwiEEbLrd;
        QqQzb += QqQzb;
        heYCgw = zYixppCovyCT;
    }

    return 859702.4755462863;
}

double xMipq::NeLxNJYYSUazEH(bool ImWPRcdNByB, string wJLUNCRIae)
{
    bool RUPVnJXVhMoWDtc = false;
    double DBuUYAkzgqA = 631185.1033956022;
    bool jSJteyjSp = false;
    int nrDSkKSLyf = -1060211771;
    bool NndKD = true;
    bool FzbjYoUaeP = false;
    string wxvNPoCBKw = string("uyUWAzVYrVRSLKbdFuAfRKRmGepNkdbePBNJGmRJEAunAHKtFIlnlEHxEzzsjChOToZaeAXTDxLKQypElJeNvqrOnYrkkqFmzfWnpPnGCgIbkKkEOnRhHWPRIMkJTxEoyrSYjbkznKqayIebuBmYgNcdvDMExGHUBhkQKjtCPQWNAUnfXEuQQHuOUPhHkyGSTHzORHGgWlZZnlAQHmhOOLhBMLKtlomyYKGdz");

    if (FzbjYoUaeP == false) {
        for (int YjquduQgYhfGtIEN = 1491253367; YjquduQgYhfGtIEN > 0; YjquduQgYhfGtIEN--) {
            ImWPRcdNByB = FzbjYoUaeP;
            ImWPRcdNByB = jSJteyjSp;
        }
    }

    for (int gWgQsng = 930181648; gWgQsng > 0; gWgQsng--) {
        ImWPRcdNByB = ! NndKD;
        RUPVnJXVhMoWDtc = FzbjYoUaeP;
        RUPVnJXVhMoWDtc = ! FzbjYoUaeP;
        DBuUYAkzgqA -= DBuUYAkzgqA;
    }

    for (int CmETwkuYwsu = 1264829455; CmETwkuYwsu > 0; CmETwkuYwsu--) {
        wxvNPoCBKw += wxvNPoCBKw;
        NndKD = ! NndKD;
        FzbjYoUaeP = NndKD;
    }

    return DBuUYAkzgqA;
}

bool xMipq::rmOkULyVzkV(string LyfJIkKnossRy, double rUmOUeIWEy, double qppibTpzFnoMAy, double NXDeYrhfjJtFvX)
{
    int xBDwy = 389410846;
    string sbsTRywsYT = string("EJSRLRrdHpRCluKtkLKcnCGUif");
    bool joYbFUFtTIGV = false;
    bool rYEPVvYXajnRzwLq = false;
    bool yMMmMCoAQV = false;
    double kRpHpajFV = -997985.9062584647;
    int nfewrEDPK = 1824621856;

    if (kRpHpajFV >= -964350.0985337641) {
        for (int mAbxocaufcMIJ = 1815665513; mAbxocaufcMIJ > 0; mAbxocaufcMIJ--) {
            rYEPVvYXajnRzwLq = ! yMMmMCoAQV;
        }
    }

    for (int tRToRQbhw = 1286288405; tRToRQbhw > 0; tRToRQbhw--) {
        continue;
    }

    if (rYEPVvYXajnRzwLq == false) {
        for (int kXuWKHFHYgheNb = 1215308875; kXuWKHFHYgheNb > 0; kXuWKHFHYgheNb--) {
            yMMmMCoAQV = ! joYbFUFtTIGV;
            nfewrEDPK = xBDwy;
        }
    }

    if (LyfJIkKnossRy <= string("aLHkQunNYlMCZaC")) {
        for (int VbiPAmusvArwu = 1563211498; VbiPAmusvArwu > 0; VbiPAmusvArwu--) {
            qppibTpzFnoMAy = NXDeYrhfjJtFvX;
        }
    }

    return yMMmMCoAQV;
}

string xMipq::QVSslhjpNvuq(string GcgVJNWb, double ZbhnwF, int uwOBp, double wHsTe, double kuXYXwMkb)
{
    string iCXVZbYDOJiZVm = string("IlXYzMrsufXLVyfjWznzeoWBAyPAWDxnvKDyzeBuuvGlucVDGkgcrgKOTqvqGXNTWcATmgbbOHzcRNvXsfkkCTsWEvgfzjVQFspDaGFAmPrSKweoDcbjfJPqtfkMPTcVUvenwbwhEGVyswyvLOHNKiPkLrlyvfjcqKsPCagPYtrsttooBQxPZNfGtORbcyzVrGOjjmAhAdEIVOGxQwPYVHAYSTNcmWPHTLGcdZGcagBEabxGzbWec");
    string kWsVDVCVT = string("IFlykiePUZoFirahlrtaLZQeAHbdtVNrYeYRLypKxmnvNbofifuhOELyoNBzZsBhpyOesNRi");
    double PsjuhLRDkh = -257080.5481693022;
    string VyZgZuaqvkfBMYY = string("zLGZJRulSxgObFZNDslrjkBXznSgemMGfygRPEvrisDigJVZmkNbDWQLABUsshrmitlAHWYhJfqRaHimWChlzbCELERAogqwzanMauZSMwyRdgIxGbUIHYpwXGxffqVEpvppSfPWxqcSparXruQTfQCOErkxIeJbybEeqTTIoyxqMOyNkmAwhIXQjvAkzJOQY");
    int wwKCiOvh = -876066539;
    string qiIILJ = string("WfWFcNfjRzywNZbmJajKKUbQakmBJImwTcpiYhJaCOegwchDFdHontejmropRkESQiiSeHMkylfZXH");
    string RkcYxu = string("WIGccyNGuzZXVcKJZkSmzCeDykBQZaOUNmFuXJjvxmCQgHJTC");
    double RpwHwGDZkbpwAI = 686750.5133193765;
    bool tXHFugBvy = true;
    string IXmAAYaQotoDBd = string("iKvuqaPNdanctOqFKPWWbtyinBpesEcTzypcJDqSUYFFfjIXjzQIPRvGHyWixHDMEQTNUTsgYQyeLBhtrhRPDuTvZcHVVdowbUArbynDOXeHeiBreFVOuabHKqEihydxBawrDNYuJUCjGNOueKRnAJjFjYbrdvhnSTywasAjhUPwBwswZcoceQnWnbFUAE");

    for (int QjcpslHDkzkhzpQp = 2032923904; QjcpslHDkzkhzpQp > 0; QjcpslHDkzkhzpQp--) {
        continue;
    }

    for (int eJeBapifvGKRRYx = 452975132; eJeBapifvGKRRYx > 0; eJeBapifvGKRRYx--) {
        iCXVZbYDOJiZVm += GcgVJNWb;
    }

    return IXmAAYaQotoDBd;
}

string xMipq::KWMvGqh(double gpljv, double vTnhWOfom, double xqchWJpX, bool XASSQBwWyF, int dzTwAzF)
{
    int iVhURYqcYn = 1324456091;
    string mDlvUNfUHCT = string("WtnrLraPTlLHFKEiaqgONEePboqCWdmkYIcZhWBnDb");
    int tdqnvXyr = 830083682;
    double HbMGGmGhZMuUQp = -370658.98882252665;
    double SqxuUhPsmtrnhtGX = -47547.83874355577;
    int CICRRYcFUhYEurot = 2107327830;
    int wxNBQCBZ = -1506883725;

    for (int vLmkde = 39436163; vLmkde > 0; vLmkde--) {
        tdqnvXyr += wxNBQCBZ;
    }

    return mDlvUNfUHCT;
}

int xMipq::OBntZYywc(bool laPuKvxaSWYF, string bAFBAawiTHbCj, bool IXJzEeJZNgJZGy)
{
    string EBkgNtagQlTtM = string("ekTiLutuZOfoTsGYsfhhvdcrBonesgETTDLJvpPlWrWKaRATvManHXQCVlkvLQhiGYkICUWbGhaQfXDzWkufHfOhgfEUiIbULBuvsdLePBcUkmsTTVLrKSuMwOyjciKbhEdYaJXJkaxKLkrm");

    if (bAFBAawiTHbCj <= string("ekTiLutuZOfoTsGYsfhhvdcrBonesgETTDLJvpPlWrWKaRATvManHXQCVlkvLQhiGYkICUWbGhaQfXDzWkufHfOhgfEUiIbULBuvsdLePBcUkmsTTVLrKSuMwOyjciKbhEdYaJXJkaxKLkrm")) {
        for (int lyxFiEApvgfkD = 1060731451; lyxFiEApvgfkD > 0; lyxFiEApvgfkD--) {
            IXJzEeJZNgJZGy = laPuKvxaSWYF;
            EBkgNtagQlTtM += EBkgNtagQlTtM;
        }
    }

    if (bAFBAawiTHbCj == string("ekTiLutuZOfoTsGYsfhhvdcrBonesgETTDLJvpPlWrWKaRATvManHXQCVlkvLQhiGYkICUWbGhaQfXDzWkufHfOhgfEUiIbULBuvsdLePBcUkmsTTVLrKSuMwOyjciKbhEdYaJXJkaxKLkrm")) {
        for (int idpMHuIwkWX = 166961574; idpMHuIwkWX > 0; idpMHuIwkWX--) {
            laPuKvxaSWYF = ! laPuKvxaSWYF;
            bAFBAawiTHbCj = bAFBAawiTHbCj;
            IXJzEeJZNgJZGy = IXJzEeJZNgJZGy;
            IXJzEeJZNgJZGy = ! laPuKvxaSWYF;
        }
    }

    return -566718965;
}

string xMipq::aaxtwKKdJ(double bcYzIAZTua, int ehCcxLcIwMOxmwS, string XHeeJYMMXn, double YtRRINBUhp, string ORIHqDlPZfm)
{
    string YEyJhHJHnmfqMim = string("djPaRQItAxznsBbWLPx");
    string oxVInwgHRL = string("woBaZWjxMQFfwXutBOsYZLypTmAkEEspTNICFTBganBEGjsXyZleHdbAQKofvaxxUIpBCwuvhEHKwGuLOFzAAxfjgXDsmfaSgnLWRqsdpJqgewljfekRhsdMiqNCMMjcbEpeRISkcNEDafoCLVIZEYGUKlLOrkTzCECTMnlSnftREfWBDXkoFQJbkCpqcmegFNxGVLiAV");
    double XlLSQtKWHVuQZ = 738600.4147832742;
    double ZcevNt = 673824.6669281732;

    if (oxVInwgHRL == string("jVacQBJuSKhcnYmHqhuMLccvzRbNgxTgiDIjyvYLTrrdzpCJxxsYXNekzVmKonMkqTshUyLuCgKRSDJnQQTdQnzKgHlPjIKvkIJoHZCyWrzOtWzyNDOyZyMiyBsPwSYGXJhGMC")) {
        for (int qwDsdZNxp = 378614392; qwDsdZNxp > 0; qwDsdZNxp--) {
            YtRRINBUhp *= XlLSQtKWHVuQZ;
            YEyJhHJHnmfqMim = YEyJhHJHnmfqMim;
            YEyJhHJHnmfqMim = ORIHqDlPZfm;
            XlLSQtKWHVuQZ += ZcevNt;
        }
    }

    for (int WihulovdBpUxACB = 554007579; WihulovdBpUxACB > 0; WihulovdBpUxACB--) {
        XlLSQtKWHVuQZ /= YtRRINBUhp;
        ZcevNt += YtRRINBUhp;
        ehCcxLcIwMOxmwS -= ehCcxLcIwMOxmwS;
        oxVInwgHRL += oxVInwgHRL;
    }

    for (int qrseMWdeh = 1987610464; qrseMWdeh > 0; qrseMWdeh--) {
        continue;
    }

    for (int hKhgrh = 1488266805; hKhgrh > 0; hKhgrh--) {
        XHeeJYMMXn += XHeeJYMMXn;
        YtRRINBUhp += ZcevNt;
        ORIHqDlPZfm += XHeeJYMMXn;
    }

    for (int pCXrjYtMKUt = 272833684; pCXrjYtMKUt > 0; pCXrjYtMKUt--) {
        ZcevNt = ZcevNt;
        YtRRINBUhp = XlLSQtKWHVuQZ;
    }

    return oxVInwgHRL;
}

double xMipq::XaGhzgEqfCNvdQ()
{
    bool hxHGVnhjFOh = false;
    bool wzbwiluDvKXtq = false;
    bool zlFEnrBzncM = false;
    bool NqbsYJyGsRAzEtRx = false;
    bool yhzfjfcwvazAxUhA = true;

    return -442186.8503455364;
}

bool xMipq::rbjBFoYtXx(double BrduNwSP)
{
    double MBjnTTdrEQAZVXi = 387924.64568140946;
    bool JuzvlpCBudKwizxv = false;
    string hVeOrWwhyf = string("nzDIsQWYCNHzzPUXhtfcuXPMSwZrjnuvOrrFWQBPPMMXUIvraCCchTqOZABLBpKKrEiayfbpezFRvELjaSFoWgiAfe");
    bool gSRRxBaIl = false;
    int aEjaDQaJbSTu = -951058436;
    int qDElsUR = -931438821;

    for (int IxgSPkdjgADdq = 1127766156; IxgSPkdjgADdq > 0; IxgSPkdjgADdq--) {
        JuzvlpCBudKwizxv = ! gSRRxBaIl;
        qDElsUR -= qDElsUR;
        MBjnTTdrEQAZVXi /= BrduNwSP;
    }

    if (gSRRxBaIl == false) {
        for (int RmggtiGuGPmyrRc = 365625774; RmggtiGuGPmyrRc > 0; RmggtiGuGPmyrRc--) {
            gSRRxBaIl = gSRRxBaIl;
            BrduNwSP *= MBjnTTdrEQAZVXi;
            MBjnTTdrEQAZVXi = MBjnTTdrEQAZVXi;
            qDElsUR /= aEjaDQaJbSTu;
        }
    }

    return gSRRxBaIl;
}

void xMipq::eccaZyHLvCE(string dlVTJGzonTN, int mmqzjDzCrmJbuMQb, int fMEfstJfMmtJlU, int DThrVMfSPs, bool FZZxtTJUKZ)
{
    string OcfxvsFHmsp = string("WYlVoyEqbmftwGovFOgrVXmJksqBdVlExcMYbZyebjvnyWOTCAjhWTUZzgvXaxbkwoVyVAvvFMZljYnIAqqNJHtLjzVGesJMixXUKblEcXALnFeEKYNRtZhHKwNRTbOKBfldtQSgVHvkVtUfYtxQsurSgcjGBZqddZQsaMUycJQuHqqDGDIRaRKSOQge");
    double AjyPXPeZpsqbAh = -225266.48069650182;

    if (AjyPXPeZpsqbAh > -225266.48069650182) {
        for (int IaUXiph = 852746979; IaUXiph > 0; IaUXiph--) {
            mmqzjDzCrmJbuMQb += DThrVMfSPs;
            DThrVMfSPs /= mmqzjDzCrmJbuMQb;
            mmqzjDzCrmJbuMQb += DThrVMfSPs;
            DThrVMfSPs /= DThrVMfSPs;
            dlVTJGzonTN = OcfxvsFHmsp;
        }
    }

    for (int nwRkkbgSeueaJe = 577433242; nwRkkbgSeueaJe > 0; nwRkkbgSeueaJe--) {
        DThrVMfSPs *= DThrVMfSPs;
    }
}

string xMipq::UHtwcJ()
{
    double STzelYDHKZGM = -315609.6749605821;
    double VZWpZMf = -517570.54530039703;
    int iwwIhbCaMEIg = 1019579681;
    bool ReFGWuM = false;
    bool mPiiVGMLHZUDDUjx = false;
    int hJxbRW = -90684590;
    string pxengT = string("bAxCgWoTsqTzRqQHfSVmGtLwodXBZGdLLyqtezUeeQdkRagYLQAZXsWKQKglYsbXl");

    return pxengT;
}

bool xMipq::KYDrEzf(int jXtsNFRvfKTZX)
{
    string xBqomYXv = string("OjcguQywXoqphQtQgtTUgqCAfkXrOCuiPKOelDJxqtPPYHItXsuuWgxZkSKAdxVyPJjhBxrSgIYHRhdjRtHoVydPVVineBevRZxlQrYzzFpWnzEooJyodSKyDPatrEMEinUQIlrjYXxRBSWJePxjIlrEqwymytbaKBXqCibNYtVnxdCSoBGNxiVOGMiBTXwHcBPHxikBxLysgPgkMlxjc");
    bool fgvJbyWeHG = true;
    double dHrYPMbj = -35195.309447573214;
    string kHkiAGwYA = string("GgwDYlDzqoxqfXHVWwANtrSRldRqStyDBLLXHktCIttzVOOPTKibZhDrtahWEVsFLgYrdcZPKgMWlZTTjxuNFdQKiaooLJVGlnZktKZYzujouXAIponUndFxNJybYRHwjExUdNTFSXalyis");
    double weNXhVVB = 395500.92525684525;
    int tfZoLhZxUa = -1990398388;

    for (int BUqIioBvKvH = 1756245066; BUqIioBvKvH > 0; BUqIioBvKvH--) {
        xBqomYXv += xBqomYXv;
    }

    for (int WhvhqQKsfedfq = 1972551212; WhvhqQKsfedfq > 0; WhvhqQKsfedfq--) {
        continue;
    }

    for (int lFjXUBbFEpd = 601716128; lFjXUBbFEpd > 0; lFjXUBbFEpd--) {
        continue;
    }

    for (int GsTrFuoVdpJSh = 1706092837; GsTrFuoVdpJSh > 0; GsTrFuoVdpJSh--) {
        tfZoLhZxUa = tfZoLhZxUa;
    }

    return fgvJbyWeHG;
}

string xMipq::otezescjexMad(int tIyliszdtHX, string BBWltFaQzoMLl, int atbHjjXfrUe, string pngiboi, int CXkrdZt)
{
    double rtLAzQLW = 314520.1685562543;
    string ejDNDJybdVCHA = string("ygalVSrrzVqjlBMICJdcQyaLonEuPmMKqbgqLlaeAaVHAGajanghiwXLYPIziFdRAamnyuxCCjbXivCPydxPQziODyyNamSRblFJNsjJlAhhKjsaiUXaxcIickRJJWAtqxlntWKFUYavmhyygMQdjzSqUdozgElnjAUNOGlFCyilJIJgIEaXmzAoPdxHLjCnfmwYylycGmAxlREDynRO");
    bool GOrWxSEQU = true;
    bool Ckesoqpv = false;
    double IWyGAKGXMHvj = -424521.99053804576;
    double rHtdsxUyHhVMz = -89832.13674619715;
    string ZWvJjrSBcO = string("qWCFnyFuKnVMQGTSqXlWqkJZhoFWGDdwzRwMWXHLzkGuUwGFENUtXyDWUhZSSuhuREKXpsiCpusWeoLrlzRCmxciGYdqhLKyASZJsepMdkelLDvuVQxRvOYGqupErtQvNcqxzwfPXaBbAZIJNnIFGsIIfrHqasndXHDbedvFUlotFoAMrwkxDaNBVMnLUlBZvKoUZZStDLztXSUirgnQNRorkKfxWbxQummybSUQfobN");

    if (atbHjjXfrUe != 952803703) {
        for (int wNDvXcnEdWzI = 1393602509; wNDvXcnEdWzI > 0; wNDvXcnEdWzI--) {
            ZWvJjrSBcO += BBWltFaQzoMLl;
            ejDNDJybdVCHA += pngiboi;
        }
    }

    for (int ynVBr = 83364077; ynVBr > 0; ynVBr--) {
        BBWltFaQzoMLl = ejDNDJybdVCHA;
        tIyliszdtHX *= atbHjjXfrUe;
        IWyGAKGXMHvj -= rHtdsxUyHhVMz;
    }

    if (BBWltFaQzoMLl == string("ygalVSrrzVqjlBMICJdcQyaLonEuPmMKqbgqLlaeAaVHAGajanghiwXLYPIziFdRAamnyuxCCjbXivCPydxPQziODyyNamSRblFJNsjJlAhhKjsaiUXaxcIickRJJWAtqxlntWKFUYavmhyygMQdjzSqUdozgElnjAUNOGlFCyilJIJgIEaXmzAoPdxHLjCnfmwYylycGmAxlREDynRO")) {
        for (int UYRbVMOkrNB = 606044224; UYRbVMOkrNB > 0; UYRbVMOkrNB--) {
            tIyliszdtHX *= tIyliszdtHX;
            tIyliszdtHX *= atbHjjXfrUe;
            Ckesoqpv = Ckesoqpv;
        }
    }

    if (pngiboi <= string("gnchQZdcPTaZvrUdJvRPRwSgYztTnNDeivQzKHOUxfLUvHojXNEBuOvfIRmOoaSxnJTxgjpNZgCVIdQCqBGqahlQVUyerYixeubwVcQumQvqvxdzbjPfClbPXILbbjaGGZKsOABTjnjTwsWdvXAhIKcWfJzEHCFWaBYRSsCdUmXmGaZIkBpJEkhTcAlFpJkWhHkjvoYUKFXpqzutgTAeEfcugiJfDjUnLuVwdhncIeZB")) {
        for (int cSEkmpnJ = 418602678; cSEkmpnJ > 0; cSEkmpnJ--) {
            rtLAzQLW += IWyGAKGXMHvj;
            rtLAzQLW += rHtdsxUyHhVMz;
            atbHjjXfrUe += atbHjjXfrUe;
            BBWltFaQzoMLl = ejDNDJybdVCHA;
        }
    }

    for (int hYzHRkcWnIOHiXG = 216476269; hYzHRkcWnIOHiXG > 0; hYzHRkcWnIOHiXG--) {
        ejDNDJybdVCHA += BBWltFaQzoMLl;
        rtLAzQLW -= rtLAzQLW;
        ZWvJjrSBcO = ejDNDJybdVCHA;
    }

    if (ejDNDJybdVCHA > string("gnchQZdcPTaZvrUdJvRPRwSgYztTnNDeivQzKHOUxfLUvHojXNEBuOvfIRmOoaSxnJTxgjpNZgCVIdQCqBGqahlQVUyerYixeubwVcQumQvqvxdzbjPfClbPXILbbjaGGZKsOABTjnjTwsWdvXAhIKcWfJzEHCFWaBYRSsCdUmXmGaZIkBpJEkhTcAlFpJkWhHkjvoYUKFXpqzutgTAeEfcugiJfDjUnLuVwdhncIeZB")) {
        for (int sjZju = 185225745; sjZju > 0; sjZju--) {
            CXkrdZt -= atbHjjXfrUe;
        }
    }

    if (IWyGAKGXMHvj > -89832.13674619715) {
        for (int UmBLrNGhDbUZkiDs = 127438467; UmBLrNGhDbUZkiDs > 0; UmBLrNGhDbUZkiDs--) {
            continue;
        }
    }

    return ZWvJjrSBcO;
}

void xMipq::AwxjIctyb()
{
    int oXjZdPLtPD = -2063722639;
    int oaNtTbWPBjrMee = 1913917546;

    if (oaNtTbWPBjrMee != -2063722639) {
        for (int ALeqoZIgOQyqI = 217742576; ALeqoZIgOQyqI > 0; ALeqoZIgOQyqI--) {
            oXjZdPLtPD *= oaNtTbWPBjrMee;
            oaNtTbWPBjrMee /= oaNtTbWPBjrMee;
            oXjZdPLtPD /= oXjZdPLtPD;
            oXjZdPLtPD = oaNtTbWPBjrMee;
            oaNtTbWPBjrMee /= oaNtTbWPBjrMee;
            oaNtTbWPBjrMee -= oXjZdPLtPD;
            oaNtTbWPBjrMee /= oXjZdPLtPD;
        }
    }
}

string xMipq::DIOxcbr()
{
    double zIpfIWqR = -449207.9682879172;

    if (zIpfIWqR <= -449207.9682879172) {
        for (int kNWobwllr = 654264903; kNWobwllr > 0; kNWobwllr--) {
            zIpfIWqR /= zIpfIWqR;
            zIpfIWqR -= zIpfIWqR;
            zIpfIWqR = zIpfIWqR;
            zIpfIWqR *= zIpfIWqR;
            zIpfIWqR -= zIpfIWqR;
            zIpfIWqR *= zIpfIWqR;
        }
    }

    if (zIpfIWqR == -449207.9682879172) {
        for (int pTuaBsGWUuhO = 546944129; pTuaBsGWUuhO > 0; pTuaBsGWUuhO--) {
            zIpfIWqR += zIpfIWqR;
            zIpfIWqR = zIpfIWqR;
            zIpfIWqR /= zIpfIWqR;
            zIpfIWqR *= zIpfIWqR;
            zIpfIWqR += zIpfIWqR;
        }
    }

    if (zIpfIWqR <= -449207.9682879172) {
        for (int JQKwslndGmtAYTmK = 1829084080; JQKwslndGmtAYTmK > 0; JQKwslndGmtAYTmK--) {
            zIpfIWqR = zIpfIWqR;
        }
    }

    return string("WJmzsrYlbeBxkyyGSxoNtuuFBSRmgLlmscjbMUESSeqtUayaDRgVfhhpieIjqMBiApjSmcSnOzhKUwZbCfICIKqiHMMJRBpMUwP");
}

double xMipq::NaAspRLs(double waSsXOhXzdPjRFD)
{
    int mMfCjDHMO = -1019934511;
    double eJcQDBkWtUDSDLEN = 78638.26734320523;
    string zWOvbemJVRDaYN = string("E");
    double wsNFcKwjkerNLI = -160793.81604551643;
    int XvNXCRIejGhZuR = 868515802;
    int cjgEVL = -389802005;
    double CdYreOIpnIGdu = 412631.86007764353;

    if (waSsXOhXzdPjRFD <= 78638.26734320523) {
        for (int CZwsuYxQyIKNBNMN = 549677062; CZwsuYxQyIKNBNMN > 0; CZwsuYxQyIKNBNMN--) {
            mMfCjDHMO /= XvNXCRIejGhZuR;
            wsNFcKwjkerNLI *= CdYreOIpnIGdu;
            wsNFcKwjkerNLI = eJcQDBkWtUDSDLEN;
            CdYreOIpnIGdu -= wsNFcKwjkerNLI;
            wsNFcKwjkerNLI -= waSsXOhXzdPjRFD;
            mMfCjDHMO += XvNXCRIejGhZuR;
        }
    }

    if (mMfCjDHMO < -1019934511) {
        for (int TVGyqfBcIxRg = 1566148769; TVGyqfBcIxRg > 0; TVGyqfBcIxRg--) {
            waSsXOhXzdPjRFD -= CdYreOIpnIGdu;
            CdYreOIpnIGdu /= waSsXOhXzdPjRFD;
            waSsXOhXzdPjRFD *= wsNFcKwjkerNLI;
            CdYreOIpnIGdu *= CdYreOIpnIGdu;
        }
    }

    if (waSsXOhXzdPjRFD != -504803.42760359513) {
        for (int lKYADIOXVkGEhD = 1885363716; lKYADIOXVkGEhD > 0; lKYADIOXVkGEhD--) {
            eJcQDBkWtUDSDLEN += waSsXOhXzdPjRFD;
        }
    }

    return CdYreOIpnIGdu;
}

xMipq::xMipq()
{
    this->pJSmuALTOtmWUe(-611610.7909974613, false, -760383942);
    this->qUjyT(-338893.68091098976, false, true, false, -862376118);
    this->KfgRK(string("WBoeBRWDFnzgbqZdNCIedptSFCPndWIglyYnYllNgVwBexGhrOgzVzmOxHzXBJTnjaHJMTpLfjoJRsHEMuFTZCSluZlMFTFdqDaKPUDDCfUChrtdhNIRAWLODQdNwVYWPmfdvdTQvpWRKZiMjAKJNHoiUXvCjAGudtaRBosPTjafNvHmYSLmryEnszowFLSNFyIbdsxCURxOYDtbgtquMnpwwNO"), false, true);
    this->NeLxNJYYSUazEH(false, string("eXIygJmBHCIUIsCEKEQGyxeBalusezcfXrIhFSAgpCcIqivHmKZWKkHZrJOKtqMMCoWslhJMnorsqNzGwhlMMktDBpfdxSmrKrKSdyiwlmxDvKcajxJOHFpGkpuZuzbsifbSKqqRKFonjiKBSyOnDAODXrdrB"));
    this->rmOkULyVzkV(string("aLHkQunNYlMCZaC"), -964350.0985337641, 575057.4940905311, -78932.46865499613);
    this->QVSslhjpNvuq(string("oAkVkoLDfpxrBFanGRvksdOGNSHOwTRVYRbDHUqUustoNGDNzZvXzkrIbdCWIpYZpGEqpnOsxqWzOQZaFQNeyLFIgYiihKnjDWymXcJEuOqtzyTDmnTRldmmVpcCbqSoDCTgvLZSOVJBnbTxDGfBcVQgFbyHHoIXDhLtGRKfRCV"), 625396.8718481925, -1867466123, -87302.43836658195, -547266.09994583);
    this->KWMvGqh(648484.3426588252, 386626.1161882495, -290632.5580591577, true, 1619837158);
    this->OBntZYywc(true, string("QrZVHaRUEYmCTZBhXrAqADGfdmRLwxPcLUQyVDNIuAmeqyXYiQampyBKuWdFXmrQNhLzXiJbQKynQiavLOcoinnaCollsLDFYmpRlUDSJSJMEfQyFCnjtptYdkAIfvhxOUYswsgjHCSPxAGPshaUoVGYJyJLfQZGpBOohRbTITRGHBEirXliZGgCKbRJHidcbwPaPrygVnUnvThxnSnaDjwpmSiZfDmIsTmentfTZKoiXlmHibBcTSWGYKNk"), false);
    this->aaxtwKKdJ(351197.8507671883, -1265726575, string("bCpfzNhmBoRvBlQyqEIKFqMHMOKkEGMssRZpXUZFazoikceiRDpIkzllJUcHlYUXkROOtJFRaZgQTdLSkHXmsCHdRlbXsyjUmXNdogwSqvbAstUdcAHSWViUWpcFOsKFjjiOyQmsNwBOPbtmMMjiYoXFAEzVypTDtSHbExTOMjhjkjHmlZUqvrDRerlPnSYBqhgpHsrINevFhLhZtEggOhTcKfIujqZgo"), -969212.4770179854, string("jVacQBJuSKhcnYmHqhuMLccvzRbNgxTgiDIjyvYLTrrdzpCJxxsYXNekzVmKonMkqTshUyLuCgKRSDJnQQTdQnzKgHlPjIKvkIJoHZCyWrzOtWzyNDOyZyMiyBsPwSYGXJhGMC"));
    this->XaGhzgEqfCNvdQ();
    this->rbjBFoYtXx(332065.5327633648);
    this->eccaZyHLvCE(string("eGAyKumtlJIzDvFJbtzgXYRfqYFEawBKpEtZjKpcypBwJzBnawcvUkANCbkAKazhaeWjYyCiebedmrLtJTVrDGszlMIDTdzvUGiunmALEoZhItWuFSMfehJgSMfEDe"), -1291263881, -1309160415, 2029913977, false);
    this->UHtwcJ();
    this->KYDrEzf(-796135613);
    this->otezescjexMad(952803703, string("gnchQZdcPTaZvrUdJvRPRwSgYztTnNDeivQzKHOUxfLUvHojXNEBuOvfIRmOoaSxnJTxgjpNZgCVIdQCqBGqahlQVUyerYixeubwVcQumQvqvxdzbjPfClbPXILbbjaGGZKsOABTjnjTwsWdvXAhIKcWfJzEHCFWaBYRSsCdUmXmGaZIkBpJEkhTcAlFpJkWhHkjvoYUKFXpqzutgTAeEfcugiJfDjUnLuVwdhncIeZB"), -2057423379, string("wQUqV"), 1012183203);
    this->AwxjIctyb();
    this->DIOxcbr();
    this->NaAspRLs(-504803.42760359513);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vmpREqIxIit
{
public:
    string wNchgXMTT;
    string HLOwIUfAeGiE;
    double gnJNssCiisjTEPUR;

    vmpREqIxIit();
    string goIPfTaaH(bool fTmoAV, string BwtsgAYOudsGNoQ, double UHvUfxSuzYCxhDTM, int RqQKERp, bool VzWuYaYLnMqLu);
    string IJcODpjixGwLOHTl(bool eZQtKCk, double reEVboWpqzUpXj);
    void EfjMIdAuLFTs(bool ZkQrNLQEkVDZj, string VQmvAL, double HoNxlKorHixJOUYI);
    void dLxLFIfhpl(double TYQHiyUktMAlyH);
    bool uMSQgPAzJEN(bool ccIpJepAfZRfKh, bool YUcEIQkkXxHH, int JtxYxF);
    void QtAIeChqyuaKxOJs(string PcqVlBjoy, double ERDSMG, int qQxEezg, double EqsBsKWZKkrFw, bool JTXokszagdB);
protected:
    double YxorGYzvskVEEu;

    string cuXcqLymRgAh(int JrAlIypINAswZ, bool JtRbIovOd, double UzvGBgfCNAekaVXE, bool nLmaJrCfGPUAY, int ecfezGBwwPAjEoRk);
    bool bVOcIfHhFIrStW(string gmMrlIVWoDJUMa);
    void eoykWzxguxIM(string sVXQhwLyZKgLUQY);
    void hIdylBjBUDEfxFuo();
    int GsAXdi(string afrOOkhbha, double peVdF);
    string pYoBR(int GlPwWganGR);
private:
    bool aidiLIKIAg;
    double QtiqCeMLnVuAW;
    string QMeESlMFaWhdq;

    string YPHqSpFHFxMpfDI(double LgaxNbUcMhRcbm, string VpalRYTxhV);
    bool uJLGDKnfkZGrSNr(int KQcRlGZrfAiMZLw, string KxwTlKOee);
    string imBKlCiaQgFczk();
    double ZZLeoqjzReDddEZP(double sUdvXjGup, bool MBujcJoK, double PjtMoWe, int VvRvflUnGx);
    bool yQwjq(bool fEdiCzloLy, string YRapBPM, string GYnpDTVidZRz);
    string IVeFqEjiQOTtQ(string HUSmpnBpItfFNMI, string apsOOQgHXfglsq, double Uweij, int jsaTKLTLXWwjTo);
    int yEeAJHtBupYhxBCX(string OcTjpxyBRDLYThbg);
    double RKqzpHQHKxjICRQJ(bool TqmYzaVlvMcxtbMl, bool ymJXA);
};

string vmpREqIxIit::goIPfTaaH(bool fTmoAV, string BwtsgAYOudsGNoQ, double UHvUfxSuzYCxhDTM, int RqQKERp, bool VzWuYaYLnMqLu)
{
    double TkGmoJs = -1001072.622969895;
    bool qatREborafupxRw = true;
    double adKUvaKGNjFQjUT = -127874.50819076886;
    double KwQXyRQm = -474481.71356332203;
    string NauDapHEXsWQ = string("iswpXmcaWVfVtiSnoNyoYqtSLbZScrQQajkRQMRkJDritzkrMnsWEEBKoijFzOYcDHzLiqqpQTRpZiGpQbiwrWmKCmFdnxxvrfMMxhRyHtBZiSqHhnDbyHPTaXyOZXRceyMCuVQqJaXFQphZuatUeoRwinWdGDABCzmlJImsYjkTdjVAyUnJsNBxxKDQocqGjcMnplbouIaM");
    double cVPhLelSEO = 910275.6983827944;
    string urSmw = string("CNNGZyKORMgkspwKwAqRkyMftFWvFtnyyzL");

    for (int ZNWrNBjUVWw = 860064747; ZNWrNBjUVWw > 0; ZNWrNBjUVWw--) {
        fTmoAV = qatREborafupxRw;
        cVPhLelSEO -= KwQXyRQm;
        BwtsgAYOudsGNoQ = BwtsgAYOudsGNoQ;
    }

    if (VzWuYaYLnMqLu == true) {
        for (int jpYVWsX = 1954242515; jpYVWsX > 0; jpYVWsX--) {
            continue;
        }
    }

    for (int kLSdPzZmLIRtz = 420070312; kLSdPzZmLIRtz > 0; kLSdPzZmLIRtz--) {
        KwQXyRQm += TkGmoJs;
    }

    return urSmw;
}

string vmpREqIxIit::IJcODpjixGwLOHTl(bool eZQtKCk, double reEVboWpqzUpXj)
{
    int tTDekrCdXwJ = 715849258;
    double kpZsiKe = -100374.57551896249;
    string FEJGfvqnT = string("ASpPumXxqamYIdrhGIPjwcQgArxoHisUtUJtGVaLGmqaTbaPQEJQTbuKQVHpYuRJAkzFPkzgOCtbDZoLnWiIJcmgRvvloqVxJPRLuaiAIRotegDFXDLtqPVdlovwNnmoBFMPSqvZxShNQGnTBBGOIGHBOXhybqKbGIlMfmKYVxdQTqbjEfsewXRpirvXYqtzQvNBZeLGejprHbNNMBfVvvfisQlUiFNmbJwXwhUUbsgTrnvQtm");
    double dLEFrYadrc = -1018254.2890852529;
    bool uhzJQOeQc = false;
    string gvvHrVb = string("QymAEyXopKbnUWwuSWVVVevyQqAGEWOTUMaUXIGchziltsgnatvqQlcEWgHZxRzEgikxXgKdjlIDAqUTHpOjH");
    string VOESOMFMCLrRCMvb = string("KemexDOHZwkRoJwMGRTnNEzFvhMgpZXDdCMWkovclNWlDvIoWJhUxQjPOzfsKzAhTtqJJtKgjlXxRumgPNDUqeEiYrYJQoSIZnqyyYlsXxrSDqSuXeHwbMKVBQypGpMxpXMXPs");
    double SMwUHHAyIJYSUyD = -131779.4628633688;
    double sGImboetclxX = 918187.7173437418;
    double lPaASKlNSSBCMF = 602439.7258794433;

    for (int EOiKGjPpOTZIKF = 72191768; EOiKGjPpOTZIKF > 0; EOiKGjPpOTZIKF--) {
        lPaASKlNSSBCMF -= dLEFrYadrc;
        kpZsiKe += lPaASKlNSSBCMF;
        tTDekrCdXwJ = tTDekrCdXwJ;
        gvvHrVb = FEJGfvqnT;
        dLEFrYadrc += lPaASKlNSSBCMF;
    }

    if (kpZsiKe >= -100374.57551896249) {
        for (int sAoNEvfGK = 1675999148; sAoNEvfGK > 0; sAoNEvfGK--) {
            eZQtKCk = ! eZQtKCk;
        }
    }

    for (int imeyoHTRubrqF = 1662003831; imeyoHTRubrqF > 0; imeyoHTRubrqF--) {
        dLEFrYadrc -= sGImboetclxX;
    }

    return VOESOMFMCLrRCMvb;
}

void vmpREqIxIit::EfjMIdAuLFTs(bool ZkQrNLQEkVDZj, string VQmvAL, double HoNxlKorHixJOUYI)
{
    double RKNRjIU = -386992.9609711768;
    bool afcjceGaLMZ = true;

    if (RKNRjIU <= -72104.92896609462) {
        for (int tKJtGuxHtlUpYKfB = 333491772; tKJtGuxHtlUpYKfB > 0; tKJtGuxHtlUpYKfB--) {
            ZkQrNLQEkVDZj = ! ZkQrNLQEkVDZj;
            afcjceGaLMZ = ZkQrNLQEkVDZj;
            RKNRjIU += RKNRjIU;
            afcjceGaLMZ = ZkQrNLQEkVDZj;
        }
    }

    if (afcjceGaLMZ == true) {
        for (int aOdACGucsxyrhp = 1600468975; aOdACGucsxyrhp > 0; aOdACGucsxyrhp--) {
            continue;
        }
    }

    for (int vmlGezaUB = 1510264184; vmlGezaUB > 0; vmlGezaUB--) {
        RKNRjIU += HoNxlKorHixJOUYI;
        VQmvAL += VQmvAL;
    }
}

void vmpREqIxIit::dLxLFIfhpl(double TYQHiyUktMAlyH)
{
    bool ZgwPQifAwZQVTmG = true;
    int ocyrQrVxkAj = 1325782906;
    int trftvBEbtcMtJkt = 234918544;
    int rHawRjWkLFGp = -859106022;
    int IlscFRsikyGGHS = -1863969123;
    bool EIhnchSJYSiWE = false;
    string VAMkkO = string("SEmqTpIkwATRypxvsVPLWMVubAjcDtEVZYfbRfcLrdXieEteRGLXbZdPWDjdQiNkwglbQhbmOoHtPSlKPPHWedBdwhKZsPVEHMOK");
    int MyEfQlw = 1027015464;
    string ugIdNOQpl = string("VAUyRzWMNCzZxQcRyqZGIAITTbVumROdPoqCMVVmmkHfcIeFguhUfFcvnwQTyjIIwgqkzvLCrKpbojyyOCUktwSOSlTyrYv");

    for (int RrzxlYZUkuviodrL = 850445409; RrzxlYZUkuviodrL > 0; RrzxlYZUkuviodrL--) {
        IlscFRsikyGGHS *= ocyrQrVxkAj;
        VAMkkO = ugIdNOQpl;
    }

    for (int ELNKYxldaS = 544571803; ELNKYxldaS > 0; ELNKYxldaS--) {
        ugIdNOQpl = ugIdNOQpl;
        MyEfQlw /= IlscFRsikyGGHS;
    }

    for (int QlBFdJSmHZbqnfCJ = 1555935889; QlBFdJSmHZbqnfCJ > 0; QlBFdJSmHZbqnfCJ--) {
        rHawRjWkLFGp += IlscFRsikyGGHS;
    }
}

bool vmpREqIxIit::uMSQgPAzJEN(bool ccIpJepAfZRfKh, bool YUcEIQkkXxHH, int JtxYxF)
{
    double CleTZKATRQngsKbj = 104157.93828663403;
    string fDBuOuEjWYDNarot = string("JUKeZgsG");
    double vrMMvDxqLXiAhS = 937818.957081311;
    string osLPFFz = string("aqGjaYudzWzyCLXvrqmRzGwlITOyEQilwTJFdWWYRzpJrutxQkByNShmiKTJwpSsIxWqIGTMKhIZBInxoYyzpUojeGNDvIHDgAXGsqERvcUaikhaCDcJzMWsSYaExJCdQeohZdLytuypCfaHQtcvSLQqVBDXPJRoHegQaMGshxzoPyWFXzfQkvuiquHDkEZTeKdMsYzwZoeWJeIrzVhsxdojdEdzWnmQwUVcHKDR");
    double kcbWf = -229211.58054307607;
    string QrerZJPay = string("ZCxvLnCNwpmHhT");

    for (int SgyrzfFU = 1432763659; SgyrzfFU > 0; SgyrzfFU--) {
        fDBuOuEjWYDNarot += osLPFFz;
        CleTZKATRQngsKbj = CleTZKATRQngsKbj;
    }

    for (int JtlQuUCB = 1169180085; JtlQuUCB > 0; JtlQuUCB--) {
        kcbWf -= kcbWf;
        osLPFFz = fDBuOuEjWYDNarot;
        CleTZKATRQngsKbj = CleTZKATRQngsKbj;
        QrerZJPay += osLPFFz;
        CleTZKATRQngsKbj -= kcbWf;
    }

    return YUcEIQkkXxHH;
}

void vmpREqIxIit::QtAIeChqyuaKxOJs(string PcqVlBjoy, double ERDSMG, int qQxEezg, double EqsBsKWZKkrFw, bool JTXokszagdB)
{
    double rmINE = -243768.26144476948;
    string VKmTKpphulkboHz = string("yatkrXSZpmEiwtPhbNWlnyKtONgWQqJJLOVwQJmJxazFTKQSkTnXgYuuRAcNEcfPdvYnssMsFKuEBawnqVZbnctbtoFejNmVYtzMdqMttpDtdbpCRQcnFbxfnZpsCirNrVrbFcXXd");
    double UDXnjim = -246410.6632090519;
    int xwJOvSkNDNdWms = -1728718580;
    bool SpAdARXuBsvnb = false;

    if (rmINE != 712658.4928019535) {
        for (int IPClGTLolKIHPc = 55243017; IPClGTLolKIHPc > 0; IPClGTLolKIHPc--) {
            SpAdARXuBsvnb = JTXokszagdB;
        }
    }

    for (int YBwCEzVtcqbO = 404752061; YBwCEzVtcqbO > 0; YBwCEzVtcqbO--) {
        continue;
    }
}

string vmpREqIxIit::cuXcqLymRgAh(int JrAlIypINAswZ, bool JtRbIovOd, double UzvGBgfCNAekaVXE, bool nLmaJrCfGPUAY, int ecfezGBwwPAjEoRk)
{
    string NvHmIewiBRVt = string("RodYdPeqUngcHeuzelCGWeaoZMxBffxFkMIMyvDvmMRKqtgCVmMWsswDzIqzzoDEATnUzEDqChZrZTYsISPcdvGDgZFHWJHGvySxaBgiSJgwllIQVXlwJzfZEvSfmtXPjwPxBaXWrug");
    string BwdPLNzt = string("WerUlcJXfkgJrpnaEHsPtmKabCczpjqsFZkBqOIwrXUPVSdCFOtDuVICbSAcWEKMYQGwpcIvxYRaZSuAbMDXnTuPPIElClwbsbOpXOhipNFSKROEpbeRxqNzbpUzwavZ");
    bool STSKTz = false;
    double xXxdDiS = 251252.49966906264;
    bool sAVqmncxleFO = false;
    double lzjig = -598540.1323626934;
    double osJuhljgx = 981314.1785201167;
    bool RIExSMqZKNGrR = false;
    double ZDbswiiWGX = 702135.9169680524;

    for (int FewgfoAoE = 1501786137; FewgfoAoE > 0; FewgfoAoE--) {
        sAVqmncxleFO = RIExSMqZKNGrR;
    }

    return BwdPLNzt;
}

bool vmpREqIxIit::bVOcIfHhFIrStW(string gmMrlIVWoDJUMa)
{
    int dislotG = 1148726896;
    double iJyOQQLxTYaiJYck = -989150.9088472186;
    double HiUrbapgLIs = -739635.0379280747;
    double LpDvakIRkDSCdUyO = 1008512.7730637616;
    bool CJhqsVA = true;
    bool ojQSbLDBrnFE = true;
    string lTorLwTcIcy = string("STpkMaKbURWwsKdSBhjszJwZPCwGGbxXlwWxhRRNKqtfVGYmprNGJgUMZuUuTSQSpKQSlhReZWXCztOqJqbpVkqDsEeieuIsXLeFDyfzkhDLtpbVmPVsKnfWINxqcuVaUeoZpyHBXPxBQFMQjbqEJOlYpOidQMUdpzRqhbQGXfIGFkmYIhZzlsfEyuGIMylccPradgjmRoFKXVxDUujBrgpQaiaBLUiuIORoabKFckGoJaGkZyodiyrntH");
    bool VSTiUD = true;
    bool kBwccRLI = true;
    int JjQcP = 1546121820;

    if (kBwccRLI == true) {
        for (int LjOYfeJfXhHnxxUZ = 1436084024; LjOYfeJfXhHnxxUZ > 0; LjOYfeJfXhHnxxUZ--) {
            continue;
        }
    }

    for (int sUJlKkGO = 1327337456; sUJlKkGO > 0; sUJlKkGO--) {
        continue;
    }

    for (int RnEWFKlIgjVzB = 1896334678; RnEWFKlIgjVzB > 0; RnEWFKlIgjVzB--) {
        LpDvakIRkDSCdUyO *= HiUrbapgLIs;
        LpDvakIRkDSCdUyO = iJyOQQLxTYaiJYck;
    }

    for (int oqZVJtKJO = 659240588; oqZVJtKJO > 0; oqZVJtKJO--) {
        iJyOQQLxTYaiJYck /= LpDvakIRkDSCdUyO;
        lTorLwTcIcy += gmMrlIVWoDJUMa;
    }

    if (ojQSbLDBrnFE == true) {
        for (int MbsLLXKsopJf = 1759363413; MbsLLXKsopJf > 0; MbsLLXKsopJf--) {
            LpDvakIRkDSCdUyO += iJyOQQLxTYaiJYck;
            CJhqsVA = ! ojQSbLDBrnFE;
        }
    }

    for (int bBQXYgTWnxZ = 2000047153; bBQXYgTWnxZ > 0; bBQXYgTWnxZ--) {
        kBwccRLI = ! kBwccRLI;
    }

    return kBwccRLI;
}

void vmpREqIxIit::eoykWzxguxIM(string sVXQhwLyZKgLUQY)
{
    bool GFbmDJONgxF = false;
    bool sTHrWHudJBvn = false;
    bool ViiUH = true;
    double HOSOiFMFGhsr = 1002854.2798925984;
    bool dtcbWKLHaPyojL = true;
    bool osRhGH = true;
    bool ioHqxXAbQfAoYaFp = true;

    for (int WMIwgADtH = 300433088; WMIwgADtH > 0; WMIwgADtH--) {
        osRhGH = ! dtcbWKLHaPyojL;
        ioHqxXAbQfAoYaFp = ! GFbmDJONgxF;
        sTHrWHudJBvn = sTHrWHudJBvn;
        sTHrWHudJBvn = osRhGH;
        osRhGH = ! sTHrWHudJBvn;
        sTHrWHudJBvn = ioHqxXAbQfAoYaFp;
        sTHrWHudJBvn = ioHqxXAbQfAoYaFp;
    }
}

void vmpREqIxIit::hIdylBjBUDEfxFuo()
{
    double juznYSYzAmvrr = 913012.8803615216;
    bool yaTdFPGtyD = true;
    int oWqzSDmFiGIylaFB = -465220383;
    bool dvVaMmpDIiUr = false;
    double UMIOf = 146099.106044548;
    int AHNEUDDX = 241696821;
    double ccNyZjuFMNcNFdu = 238795.71746649343;
    string ukZHOLJqoESzGr = string("OY");
    bool DOhIQpmwnkJYUq = true;
    bool bmXzQW = true;

    if (DOhIQpmwnkJYUq == true) {
        for (int Jvjeu = 562965116; Jvjeu > 0; Jvjeu--) {
            continue;
        }
    }

    if (bmXzQW != true) {
        for (int XKcMOTm = 765252553; XKcMOTm > 0; XKcMOTm--) {
            bmXzQW = ! dvVaMmpDIiUr;
            oWqzSDmFiGIylaFB = oWqzSDmFiGIylaFB;
        }
    }

    for (int FbxLMbmrMR = 593711170; FbxLMbmrMR > 0; FbxLMbmrMR--) {
        dvVaMmpDIiUr = yaTdFPGtyD;
        bmXzQW = ! DOhIQpmwnkJYUq;
    }
}

int vmpREqIxIit::GsAXdi(string afrOOkhbha, double peVdF)
{
    double OzudnpFiPnanCpxK = -672371.6211198579;

    if (OzudnpFiPnanCpxK >= -238261.9178084027) {
        for (int rcNXnqBU = 2074762917; rcNXnqBU > 0; rcNXnqBU--) {
            OzudnpFiPnanCpxK -= peVdF;
            peVdF /= OzudnpFiPnanCpxK;
            peVdF -= OzudnpFiPnanCpxK;
            OzudnpFiPnanCpxK = peVdF;
        }
    }

    for (int otbxcun = 774496970; otbxcun > 0; otbxcun--) {
        afrOOkhbha += afrOOkhbha;
        OzudnpFiPnanCpxK -= peVdF;
        OzudnpFiPnanCpxK -= peVdF;
        OzudnpFiPnanCpxK *= OzudnpFiPnanCpxK;
        OzudnpFiPnanCpxK /= peVdF;
        OzudnpFiPnanCpxK *= OzudnpFiPnanCpxK;
    }

    if (OzudnpFiPnanCpxK <= -672371.6211198579) {
        for (int VWbHXUGRblPKCj = 246187059; VWbHXUGRblPKCj > 0; VWbHXUGRblPKCj--) {
            peVdF -= peVdF;
            OzudnpFiPnanCpxK -= OzudnpFiPnanCpxK;
            OzudnpFiPnanCpxK += OzudnpFiPnanCpxK;
            peVdF -= OzudnpFiPnanCpxK;
            afrOOkhbha = afrOOkhbha;
        }
    }

    if (OzudnpFiPnanCpxK > -238261.9178084027) {
        for (int LsgJZzQztBTlFuqc = 1560172246; LsgJZzQztBTlFuqc > 0; LsgJZzQztBTlFuqc--) {
            OzudnpFiPnanCpxK += peVdF;
        }
    }

    if (peVdF > -238261.9178084027) {
        for (int AeTNDDZCw = 298541933; AeTNDDZCw > 0; AeTNDDZCw--) {
            OzudnpFiPnanCpxK -= OzudnpFiPnanCpxK;
        }
    }

    for (int JCxnloQtuy = 2097012092; JCxnloQtuy > 0; JCxnloQtuy--) {
        peVdF *= peVdF;
        OzudnpFiPnanCpxK = OzudnpFiPnanCpxK;
        OzudnpFiPnanCpxK -= peVdF;
    }

    if (afrOOkhbha > string("cCAVqKVuPdCKav")) {
        for (int AeMejxCHPZ = 986665483; AeMejxCHPZ > 0; AeMejxCHPZ--) {
            peVdF -= OzudnpFiPnanCpxK;
            peVdF += OzudnpFiPnanCpxK;
        }
    }

    return 1044734914;
}

string vmpREqIxIit::pYoBR(int GlPwWganGR)
{
    double IROvybsJyR = 254640.0265379965;
    int AUIZaxSYKet = 1167874796;
    int ozeriS = -219524738;
    int XrXMKRWdYrotNP = -1391973153;

    if (AUIZaxSYKet < 1705340442) {
        for (int UqOJBuFZyyHNGIkQ = 913875773; UqOJBuFZyyHNGIkQ > 0; UqOJBuFZyyHNGIkQ--) {
            ozeriS -= GlPwWganGR;
        }
    }

    if (GlPwWganGR == -219524738) {
        for (int kJJex = 556421000; kJJex > 0; kJJex--) {
            ozeriS += GlPwWganGR;
            GlPwWganGR /= XrXMKRWdYrotNP;
            GlPwWganGR *= ozeriS;
            IROvybsJyR -= IROvybsJyR;
        }
    }

    if (ozeriS != -219524738) {
        for (int rBgdpeUmFWRFyT = 95758928; rBgdpeUmFWRFyT > 0; rBgdpeUmFWRFyT--) {
            ozeriS += ozeriS;
            IROvybsJyR += IROvybsJyR;
            AUIZaxSYKet -= ozeriS;
            AUIZaxSYKet *= GlPwWganGR;
            AUIZaxSYKet /= XrXMKRWdYrotNP;
            IROvybsJyR -= IROvybsJyR;
        }
    }

    for (int HZkTRknF = 813282421; HZkTRknF > 0; HZkTRknF--) {
        AUIZaxSYKet *= AUIZaxSYKet;
        XrXMKRWdYrotNP -= GlPwWganGR;
        AUIZaxSYKet = AUIZaxSYKet;
        GlPwWganGR -= ozeriS;
    }

    if (XrXMKRWdYrotNP < -1391973153) {
        for (int PfrtwT = 1599033017; PfrtwT > 0; PfrtwT--) {
            XrXMKRWdYrotNP = ozeriS;
            GlPwWganGR += XrXMKRWdYrotNP;
            GlPwWganGR = GlPwWganGR;
            ozeriS += XrXMKRWdYrotNP;
        }
    }

    for (int MnFYb = 1856022030; MnFYb > 0; MnFYb--) {
        GlPwWganGR *= AUIZaxSYKet;
        IROvybsJyR -= IROvybsJyR;
    }

    return string("YaRGtgjhEXlIhscacvZEKqIdqagsANqJoBe");
}

string vmpREqIxIit::YPHqSpFHFxMpfDI(double LgaxNbUcMhRcbm, string VpalRYTxhV)
{
    double vbzhff = -414624.13403228554;
    string iJpGdkHT = string("JncvYWfirCOQOUXUmUYbyuywJhKkJOGJVizHPCcXmwfyJRISxsMiWWcyqaAIEYtQElEIufzinXusYsIkSuOObIrsicmkjVvGJTpjDVNRZnCnPwviRNQNz");
    string gvmUnENYUHK = string("gmfmUYjFWAszmChyNOVWZhwwhuyVjSmRFUpROKTAcflbrYRUYfYqNhmWcklrKvVApWxalrYaDuZnFKfmtrVjaTqZsorqWzJNSNEPvxtJdYyGnRfqbvUcPijKFDNJHfAuctNlOUyeuGiGCaIoVdguraljVgeUfJeeotFsoJQstTjDyPiyGzbs");
    int sBXGPmVWQuNoMi = -1781679035;
    bool sVQTSF = false;
    string qxvuERDKMSV = string("PwQUkVAhRewUrwjKJXPFqEJZgRZyIzrTAKMNzJEsxQpNRCHgnqyoyOyaFwbLwZjYZCFoBdnxPyF");
    string kSSwK = string("mUmUjGaHmhJjdRjlKMqsuXqtxGkrMFkRGOTypHtkYVbJZGBeZbkyoJTUFPctTctwtBpnKyKFzlqxVwZINKdMqrKHSGfvpPgpokgJsBVNqnVUNnyMzktbUzwnuONeiHReDc");

    if (kSSwK == string("mUmUjGaHmhJjdRjlKMqsuXqtxGkrMFkRGOTypHtkYVbJZGBeZbkyoJTUFPctTctwtBpnKyKFzlqxVwZINKdMqrKHSGfvpPgpokgJsBVNqnVUNnyMzktbUzwnuONeiHReDc")) {
        for (int YnxdHXptoedsq = 1975048202; YnxdHXptoedsq > 0; YnxdHXptoedsq--) {
            qxvuERDKMSV = iJpGdkHT;
            VpalRYTxhV += gvmUnENYUHK;
            gvmUnENYUHK = VpalRYTxhV;
        }
    }

    for (int uvfaIXCxfnUAI = 1735097448; uvfaIXCxfnUAI > 0; uvfaIXCxfnUAI--) {
        kSSwK = kSSwK;
        kSSwK += VpalRYTxhV;
    }

    for (int wOJSjFUbt = 202635174; wOJSjFUbt > 0; wOJSjFUbt--) {
        iJpGdkHT += gvmUnENYUHK;
        qxvuERDKMSV += qxvuERDKMSV;
    }

    for (int vsMKXYoINgJIe = 1999224093; vsMKXYoINgJIe > 0; vsMKXYoINgJIe--) {
        kSSwK = gvmUnENYUHK;
        kSSwK += qxvuERDKMSV;
        sVQTSF = sVQTSF;
        qxvuERDKMSV += qxvuERDKMSV;
        qxvuERDKMSV += VpalRYTxhV;
    }

    for (int rYvmUaArIXd = 1806896348; rYvmUaArIXd > 0; rYvmUaArIXd--) {
        VpalRYTxhV = iJpGdkHT;
    }

    for (int aocVgwC = 683388504; aocVgwC > 0; aocVgwC--) {
        continue;
    }

    for (int pkciiIOvV = 976924553; pkciiIOvV > 0; pkciiIOvV--) {
        VpalRYTxhV += iJpGdkHT;
    }

    return kSSwK;
}

bool vmpREqIxIit::uJLGDKnfkZGrSNr(int KQcRlGZrfAiMZLw, string KxwTlKOee)
{
    bool vqqEsnSZfZAdL = true;
    int UXqBjApZ = 507114636;
    int IkYwOSGYdLXONx = 1970410992;

    return vqqEsnSZfZAdL;
}

string vmpREqIxIit::imBKlCiaQgFczk()
{
    bool DKgfZ = false;
    int UZTrAqOrfgXzE = -2080185409;
    int CMyJL = 1920478688;
    bool HtOfCplF = false;
    int oSHsumUoPNj = -2006219649;
    bool WWNMT = false;
    double bdyvQPKylMjFq = 60712.3596193896;
    double tKpTzekl = -570314.8700470432;
    bool oDOKhobD = true;
    double AaEVjPsqd = 301648.0462366402;

    if (CMyJL < 1920478688) {
        for (int wOyRXVTtRIipGXN = 201624286; wOyRXVTtRIipGXN > 0; wOyRXVTtRIipGXN--) {
            UZTrAqOrfgXzE += oSHsumUoPNj;
        }
    }

    return string("PqmtWCvMjagUSKtZiSqBJaQDZKJzPdYqrzZbhfsJPadGSlxVRfLlcNjXMcekmvqhyerwKuwqcAhriSDgXFbZldutLFdIBNPhhbgnBL");
}

double vmpREqIxIit::ZZLeoqjzReDddEZP(double sUdvXjGup, bool MBujcJoK, double PjtMoWe, int VvRvflUnGx)
{
    int rKxUrL = -362282793;
    bool Crpua = false;
    bool fKXROL = true;
    bool ZqpDArzOiJxYKGQF = false;
    int UZKbPtjAAzLg = 396584633;
    double dUJaNOxxC = -400621.2796522175;

    if (PjtMoWe != -400621.2796522175) {
        for (int CcJjUHwplu = 1601398650; CcJjUHwplu > 0; CcJjUHwplu--) {
            ZqpDArzOiJxYKGQF = ! MBujcJoK;
            fKXROL = fKXROL;
        }
    }

    for (int RuzEuPgrKpeq = 1542819774; RuzEuPgrKpeq > 0; RuzEuPgrKpeq--) {
        dUJaNOxxC *= dUJaNOxxC;
        ZqpDArzOiJxYKGQF = ! Crpua;
        rKxUrL += UZKbPtjAAzLg;
        fKXROL = MBujcJoK;
    }

    for (int FDjCzFve = 308592966; FDjCzFve > 0; FDjCzFve--) {
        Crpua = Crpua;
    }

    for (int hJbvEOjcseNhqShZ = 1676421594; hJbvEOjcseNhqShZ > 0; hJbvEOjcseNhqShZ--) {
        Crpua = ! fKXROL;
    }

    for (int dWMUQYtoFSPFPmt = 1194463764; dWMUQYtoFSPFPmt > 0; dWMUQYtoFSPFPmt--) {
        sUdvXjGup = PjtMoWe;
        rKxUrL *= UZKbPtjAAzLg;
        dUJaNOxxC -= sUdvXjGup;
    }

    return dUJaNOxxC;
}

bool vmpREqIxIit::yQwjq(bool fEdiCzloLy, string YRapBPM, string GYnpDTVidZRz)
{
    string lLvPZlXSiFih = string("MhrezcYKXMtMkhgDCYpacNCArpplKtBXbMdpqVtOENckHtgjnjzSBbLnrAAexWCcxysFbNMdHIPFgGnkRBQQSxjqFWZUNcelMDaVzoJCCCgSsQcjcWLSDFrtUklaGcipYFOhywdCWaJVYvfDgRkwypEhLlFheKfTmXGpGdxeDRjczYxbVUEQujWSjsoPKltfSYmIVQlrtcdDSjrdVdxNidIUJr");
    string TYaWxBb = string("ixxBphHIvVNrgzFEknwRjShxiSfbSlsXzBsCStZWIucIVWOMYuLpHoLPZTMfHpegeVOOkhkofNMyiuLtXTyKThTNdBrtiFkFbqQQqMJmTUTlXSRTMwvMwfva");
    int GKKTfeGTzMJuRrg = -1625217892;

    if (GKKTfeGTzMJuRrg <= -1625217892) {
        for (int FagOIAc = 378712840; FagOIAc > 0; FagOIAc--) {
            GYnpDTVidZRz += lLvPZlXSiFih;
            YRapBPM += TYaWxBb;
            YRapBPM = YRapBPM;
            YRapBPM += TYaWxBb;
            GKKTfeGTzMJuRrg *= GKKTfeGTzMJuRrg;
        }
    }

    if (TYaWxBb == string("MhrezcYKXMtMkhgDCYpacNCArpplKtBXbMdpqVtOENckHtgjnjzSBbLnrAAexWCcxysFbNMdHIPFgGnkRBQQSxjqFWZUNcelMDaVzoJCCCgSsQcjcWLSDFrtUklaGcipYFOhywdCWaJVYvfDgRkwypEhLlFheKfTmXGpGdxeDRjczYxbVUEQujWSjsoPKltfSYmIVQlrtcdDSjrdVdxNidIUJr")) {
        for (int HNbMHxWf = 1156972243; HNbMHxWf > 0; HNbMHxWf--) {
            YRapBPM = TYaWxBb;
            GYnpDTVidZRz += YRapBPM;
            TYaWxBb = TYaWxBb;
            TYaWxBb = TYaWxBb;
            TYaWxBb = TYaWxBb;
        }
    }

    for (int bESsfpBHEUoPX = 1877241665; bESsfpBHEUoPX > 0; bESsfpBHEUoPX--) {
        YRapBPM += GYnpDTVidZRz;
        lLvPZlXSiFih = TYaWxBb;
        lLvPZlXSiFih = GYnpDTVidZRz;
    }

    if (GKKTfeGTzMJuRrg > -1625217892) {
        for (int JDFrUgPGXFvOImfi = 780103457; JDFrUgPGXFvOImfi > 0; JDFrUgPGXFvOImfi--) {
            GYnpDTVidZRz += GYnpDTVidZRz;
        }
    }

    return fEdiCzloLy;
}

string vmpREqIxIit::IVeFqEjiQOTtQ(string HUSmpnBpItfFNMI, string apsOOQgHXfglsq, double Uweij, int jsaTKLTLXWwjTo)
{
    bool pizJuHqyco = true;
    double QLJWSnORgyAmIla = 935560.5357121441;
    string REAuICDqVvfA = string("LQuhiEkdICAAQrUoyBZTMvZoIzFeOVSxtWoEfzpqjWVlRuFjDQQUQxiGbhLXaBUCceToOSujkYaNogzgIiuLOKHEMKwReOtuoeaWolOumacLFZegzrCfmJZTEpeHgKDZFwzuPllgaRcVwIsMMDxhTNpUFrGmWXYFlxdmsProqQlYaJXGJskocvzupmCfvX");
    double fxjKUnFXiwVNc = 343557.6648478326;
    bool LScSkmbnQmJZI = true;
    double fNgQOjiyCFLAgSIW = -203717.881679318;
    int mbFMMbFKTEDe = 905802255;

    for (int cqbexqcZrmYql = 587186701; cqbexqcZrmYql > 0; cqbexqcZrmYql--) {
        fxjKUnFXiwVNc *= fxjKUnFXiwVNc;
        fNgQOjiyCFLAgSIW -= fxjKUnFXiwVNc;
        HUSmpnBpItfFNMI = REAuICDqVvfA;
    }

    return REAuICDqVvfA;
}

int vmpREqIxIit::yEeAJHtBupYhxBCX(string OcTjpxyBRDLYThbg)
{
    bool PfapDpXMt = false;
    bool rTfJA = false;
    bool aiDJhCl = false;
    bool eKIkFhy = false;
    bool NsBiHVOckk = false;
    string TkJRrO = string("rpmkPSYrnvdaDzProcdJZCaYcPPYFfzTjhHxyNWAMVAyKkqrDnxXfZLkkKmYMdhZOcwxTJNTdpXxyOibcqq");
    int xeCkkfANHCF = -108075174;

    if (TkJRrO != string("rpmkPSYrnvdaDzProcdJZCaYcPPYFfzTjhHxyNWAMVAyKkqrDnxXfZLkkKmYMdhZOcwxTJNTdpXxyOibcqq")) {
        for (int LMmxy = 736393805; LMmxy > 0; LMmxy--) {
            NsBiHVOckk = ! PfapDpXMt;
            xeCkkfANHCF -= xeCkkfANHCF;
            rTfJA = ! PfapDpXMt;
            OcTjpxyBRDLYThbg = TkJRrO;
        }
    }

    for (int YbafuBWbOABXOVWe = 408281419; YbafuBWbOABXOVWe > 0; YbafuBWbOABXOVWe--) {
        rTfJA = ! eKIkFhy;
        eKIkFhy = ! eKIkFhy;
    }

    for (int mZjSleLS = 1794983603; mZjSleLS > 0; mZjSleLS--) {
        PfapDpXMt = eKIkFhy;
        aiDJhCl = ! rTfJA;
        PfapDpXMt = rTfJA;
    }

    for (int UdFhZssoZCEawm = 1359467151; UdFhZssoZCEawm > 0; UdFhZssoZCEawm--) {
        xeCkkfANHCF += xeCkkfANHCF;
        NsBiHVOckk = ! PfapDpXMt;
    }

    for (int ghjnyTbtVwoM = 2022160737; ghjnyTbtVwoM > 0; ghjnyTbtVwoM--) {
        rTfJA = ! PfapDpXMt;
        PfapDpXMt = ! NsBiHVOckk;
        rTfJA = aiDJhCl;
    }

    return xeCkkfANHCF;
}

double vmpREqIxIit::RKqzpHQHKxjICRQJ(bool TqmYzaVlvMcxtbMl, bool ymJXA)
{
    double urwiemMpKBpynhY = -476112.9757567295;
    int tGaAtQJuZl = 290565884;
    string YYWhEnykztid = string("lIYgyqxoDkBMtRyYuSjHFJJCSixtIvXqhWdpuTTEMACskjmDDBASohXHowKqIyNCQcBNWVgceZTECzRDwmDeKchuMvLKmmGkqNLJrjsavJPsDkckFVjDKdLPnMHqXeFRKCxqFpNEpgKHIcChSidmSAklxGMaeqNSNcmxoCeHOrGfjfCAM");
    int ngyNLAJk = -1248349813;
    double yRDpkHzxtfZxaAi = -864549.6292615152;
    double ccpZBn = -589766.9247021765;
    bool XIoOSbwonGM = true;
    int INUMYkIfHGUuMB = 1759694112;

    for (int aGostPtQ = 369617587; aGostPtQ > 0; aGostPtQ--) {
        tGaAtQJuZl -= INUMYkIfHGUuMB;
        INUMYkIfHGUuMB /= tGaAtQJuZl;
        tGaAtQJuZl /= INUMYkIfHGUuMB;
    }

    for (int xFohDitwhpIdfUy = 1463504681; xFohDitwhpIdfUy > 0; xFohDitwhpIdfUy--) {
        INUMYkIfHGUuMB = tGaAtQJuZl;
        TqmYzaVlvMcxtbMl = TqmYzaVlvMcxtbMl;
    }

    if (urwiemMpKBpynhY < -589766.9247021765) {
        for (int vLIwFd = 1394994370; vLIwFd > 0; vLIwFd--) {
            continue;
        }
    }

    for (int QhWHjTosOJGbMn = 1113593222; QhWHjTosOJGbMn > 0; QhWHjTosOJGbMn--) {
        INUMYkIfHGUuMB += INUMYkIfHGUuMB;
        tGaAtQJuZl += tGaAtQJuZl;
    }

    return ccpZBn;
}

vmpREqIxIit::vmpREqIxIit()
{
    this->goIPfTaaH(true, string("GJDrxZDKoTRoVYcbFPsLwljpTFyOxOefljeoRTEDsSMubjLncupousWrVbOMHBLRyEiNLb"), -385193.7600821016, -2006154994, true);
    this->IJcODpjixGwLOHTl(true, 694790.7795834838);
    this->EfjMIdAuLFTs(true, string("WJchTKPiSGNcxVJQYMTptEKAwZPrjOGXGUmvVWsIagQJUsloNMUpNlCelgcQMCaNMerqCHyvVNQFYjzkAOjrcFYXvXzDJxpplGFpjTzoZUhOufytwzBEkINHNBALzWwdmKXiIiKMINavfS"), -72104.92896609462);
    this->dLxLFIfhpl(-76848.34708657277);
    this->uMSQgPAzJEN(false, false, 1899153353);
    this->QtAIeChqyuaKxOJs(string("SNtjHTxfYwEjFLAIjttjaEYfaikjbXXBhcGlTYAHBscpxqRyAXoLjTSBAEYCvszSyzqCOYgtdOSLyxmdVrPGXtqLOMHrkqYBvxmqazJKB"), -550653.0652277805, 516752072, 712658.4928019535, false);
    this->cuXcqLymRgAh(2056350045, false, 620447.3651335279, false, -344683057);
    this->bVOcIfHhFIrStW(string("FSaQdRwJJdofBbZxSdwsRQdVgG"));
    this->eoykWzxguxIM(string("YTPThxRWezECHEEFxxlcRBPDfzPPIrdlNTADcmMvcUNdmadSZBvomLaiFekwmxLZprVJZalsNHRGVXnmsigIGXnnLTdmuxisdhutBzzSLQjiMtToGxoMaYn"));
    this->hIdylBjBUDEfxFuo();
    this->GsAXdi(string("cCAVqKVuPdCKav"), -238261.9178084027);
    this->pYoBR(1705340442);
    this->YPHqSpFHFxMpfDI(569371.4173737185, string("MAfvYcsfxIWLKweceAPqzuxsGfeu"));
    this->uJLGDKnfkZGrSNr(-568090686, string("OlxQSuTjEWvqsYPytaADSYojyuWEmCYnQQvpSdKmTPaTnKiTtYiMTpEJBzzGQuAwzaqDrVfcmXiFingprpizeUorAWeMncRVylIZiBjHVqjcllLFqPwCGAAoHrZjVgATlhSryPToVoaQ"));
    this->imBKlCiaQgFczk();
    this->ZZLeoqjzReDddEZP(660192.7673539926, true, -502627.798692076, -996544170);
    this->yQwjq(false, string("DNOxoBezIiDsIKOkteKLvvpMsDslUmUfCKcQsDXzwLuMPlPTEsCSMUlWPBLgzmcbtaIloCJPEHyfBFlUzKiKfDTDjTdMXLmDlaUiYsnKTWmDuvQCEhASyVdkPTUhkJBEFfxhnhJGnCHzWksQCWpAOhbGy"), string("IgwhuXRZABXRoEsxcqmuxLSFUQZmmmFzftbPshBwGTDUZGPXqiRgaCAKKyEEGAkXcKdfsmayvOUAGxGxbmIhlrKkQUzRyjxkPXxUFMFPKWPviuphEhaPPs"));
    this->IVeFqEjiQOTtQ(string("glRueRkuwdEPInvoGOWKgsjmzJgsQxAdtGVzIyTXmhCVKUatLwOIoxGfzljlovJUwrWu"), string("ocimSCOhLYYyQOacLIxVpIOoMkTixBdgSMacsKurUHApBOdBjyAdGxxBfyqvPwcYgrldaiNfoGvZUoXGgfKSSWkNjfPcmXcaxEtGcYhwNRHJukDGnjwBlMAeTp"), 466811.7978824851, -1556148395);
    this->yEeAJHtBupYhxBCX(string("VNVIYizMwIcUMHDpHOWuqQwaOmphBTPyNoDJeNUqdwbhHkKtTpUkTkNvxRfPdzZuMfBbuAsDFAyBBMiGyaAVCNrFYqDxsRaxpxzgWEYZMANMTCSIoLZaPqbAXFageqVKuAtCUkEDHUmqKLxUNHKNArSafKFJcYuogdiRdve"));
    this->RKqzpHQHKxjICRQJ(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fXnOudWUfv
{
public:
    string rEcsJOk;
    int FkaEMtRWT;
    string uwiEabZ;
    double ZAAbUz;
    double wrWJQduvKA;
    double zQflgiknTyPBn;

    fXnOudWUfv();
    string ApIbm(int wLElolKDuzR, string lBIOWSlp);
    bool RRJIQKokWRQ();
    string bEbfUhtZt();
    bool GdodiB();
    int GnXVhmN(double NvArJISoQ, bool IxyseZFfdWuerhM, string CIscenMHx, bool wJLlhGLFPBFbIjr, string zXRZaqtzsi);
protected:
    string Rwpfh;

    string pOVHvUFaEFGAA();
    double yKsQHf(bool mgrCRArCTHRpQwm, bool WdvOSoha, string DoXTUZyIlwdf);
private:
    double nIDcmlfiYKEQy;
    int athsDFw;
    int BHFBOcmcpX;

    int VaALTOmPlzhB(string IUKOuZ, int SPzlXzjG, double mjNvmN, double XRkSzaew);
    bool TJYuDPQnywJpBQH(int BGkphCkkaIispRHi, bool qTjvxMTTevKcRuqL, string DXrosh);
    int JSOdh(int KmUAaZwpLQb, string eJKKDRtnQZNYLdbU, bool EFSQQMVC);
    int rQEPZTmOOb(int mIVAgTsiIkjWw, double hjqFuYQptaOm, bool IcQplG, double DUtRugjpVlEjbx, string keODzRueXRRy);
    string wxqGDDuw();
    string orwicSTMUys();
};

string fXnOudWUfv::ApIbm(int wLElolKDuzR, string lBIOWSlp)
{
    string KZoPVlLXDATw = string("uChuTMQUkNZbOPweDSSRonMSqGqWrUkUGCtsaQNKtlornOPHjLYVeKqkKQcyicKLBeiZEvAaRAEhqIhnIbvYFYUxSoWQSmOHrmaIZnzqCgKkhNNNGjMocFhaKROdFdbDXzdarqnFFtbrWaxnmLLQYHkMigxvmEsErolSiLrPEDtYzuASfKrGGZAhSMVDHbqnhjhnSct");
    double DWtxDRs = 280704.8492112527;
    int YeyghFpzMQoqzV = -611140180;
    string svhTNb = string("EtJvXRZDwJJuZFlePVwrBHIkUhEFbMGDGPuZPOSFZHRGnvVtsjequowJbgRrdfTDFEJdnKLVBWkoLiHcBOCrOGAowjNZiHDpUugiXWyOjfoezsWBwmXQxpcTKkuKXWPFOMeqlTwfWtqafITvgBThwJpuPtxWiLUAHlsJbcvR");
    double oumtiscx = -860345.6073013959;
    double NQYNkXHoLcx = 246145.63815494528;
    bool wpfjApmTi = true;
    bool mVumtOoZgVQujDFj = false;

    if (wpfjApmTi == true) {
        for (int TpaQNLxXaQqBj = 1013585309; TpaQNLxXaQqBj > 0; TpaQNLxXaQqBj--) {
            mVumtOoZgVQujDFj = ! wpfjApmTi;
        }
    }

    if (NQYNkXHoLcx < -860345.6073013959) {
        for (int wucTrRLYZCmC = 2100414245; wucTrRLYZCmC > 0; wucTrRLYZCmC--) {
            wpfjApmTi = ! mVumtOoZgVQujDFj;
            svhTNb += svhTNb;
        }
    }

    for (int JEouv = 757991249; JEouv > 0; JEouv--) {
        mVumtOoZgVQujDFj = mVumtOoZgVQujDFj;
        lBIOWSlp += KZoPVlLXDATw;
        mVumtOoZgVQujDFj = ! wpfjApmTi;
    }

    return svhTNb;
}

bool fXnOudWUfv::RRJIQKokWRQ()
{
    int fWlefyv = 1322445897;
    string NpCJsT = string("XksRwfGMTYdWiAlPYjPYeDGSSVbWtyRMY");
    bool tCmvLfLfM = true;

    for (int RtWafLfYxSgww = 1361797896; RtWafLfYxSgww > 0; RtWafLfYxSgww--) {
        tCmvLfLfM = tCmvLfLfM;
        fWlefyv += fWlefyv;
        NpCJsT = NpCJsT;
        tCmvLfLfM = tCmvLfLfM;
    }

    for (int rYVEBGvNAb = 1103745791; rYVEBGvNAb > 0; rYVEBGvNAb--) {
        tCmvLfLfM = tCmvLfLfM;
        fWlefyv *= fWlefyv;
        tCmvLfLfM = ! tCmvLfLfM;
        NpCJsT = NpCJsT;
        tCmvLfLfM = ! tCmvLfLfM;
    }

    return tCmvLfLfM;
}

string fXnOudWUfv::bEbfUhtZt()
{
    string UIJgtXGXaUlSSnU = string("RwgRmXhcgjuQTrFfrHqZHqeDeMEQDVwcYPNZfyBPjVTMjHFaIsAOCUTMwnfrcynkgt");
    string rptnmkOYTKi = string("chJvRNqUQaAWGLPmvfXLHTrToGPRgVBlrbrrcmhVEdCfjXAZmqwwZJIaPVlBCckUYXgpwldaAfUbMgLEnPsaEjOZoYkNe");
    string fwzTRhCKVqOOy = string("hOgfJuuziWnpAaLYmDqysnqgpVoaRydHeIeXreAheucyXuitOgFnZzQBPmPBFigCpSPqMqYdvbgzzlHDvaaohSSdFdaPiGikmDLoXQRREXgZdtpERxNixguyFjRCqAdKwCefgqmgtyspsodaVgMFeTLnAcaQdgSLQqecLFk");
    double GLiNQsKR = 11456.7832180361;

    for (int qsBCV = 208223130; qsBCV > 0; qsBCV--) {
        fwzTRhCKVqOOy = UIJgtXGXaUlSSnU;
        rptnmkOYTKi = rptnmkOYTKi;
        GLiNQsKR = GLiNQsKR;
    }

    if (fwzTRhCKVqOOy < string("chJvRNqUQaAWGLPmvfXLHTrToGPRgVBlrbrrcmhVEdCfjXAZmqwwZJIaPVlBCckUYXgpwldaAfUbMgLEnPsaEjOZoYkNe")) {
        for (int jLetvZr = 1053491740; jLetvZr > 0; jLetvZr--) {
            rptnmkOYTKi += fwzTRhCKVqOOy;
            rptnmkOYTKi = UIJgtXGXaUlSSnU;
            GLiNQsKR = GLiNQsKR;
            rptnmkOYTKi += rptnmkOYTKi;
            UIJgtXGXaUlSSnU += UIJgtXGXaUlSSnU;
            rptnmkOYTKi = fwzTRhCKVqOOy;
            GLiNQsKR -= GLiNQsKR;
        }
    }

    for (int RBkvNAVcnTsPaYs = 1197077030; RBkvNAVcnTsPaYs > 0; RBkvNAVcnTsPaYs--) {
        fwzTRhCKVqOOy = fwzTRhCKVqOOy;
        UIJgtXGXaUlSSnU = fwzTRhCKVqOOy;
        rptnmkOYTKi = rptnmkOYTKi;
        rptnmkOYTKi = fwzTRhCKVqOOy;
        UIJgtXGXaUlSSnU = rptnmkOYTKi;
        fwzTRhCKVqOOy = rptnmkOYTKi;
        UIJgtXGXaUlSSnU += fwzTRhCKVqOOy;
    }

    return fwzTRhCKVqOOy;
}

bool fXnOudWUfv::GdodiB()
{
    bool adzAzomTFqbDn = true;
    bool kXETusvvlbEH = true;
    int HwOoV = -273137449;
    double gnfzPbBhI = -894791.5893487948;
    double WHSzSZLZYS = -702417.813519766;
    bool bYrUWQXEHeJqRxdZ = false;

    for (int jZZvfkaZbdi = 930474479; jZZvfkaZbdi > 0; jZZvfkaZbdi--) {
        WHSzSZLZYS /= gnfzPbBhI;
    }

    for (int TRFpNg = 1414233843; TRFpNg > 0; TRFpNg--) {
        gnfzPbBhI -= WHSzSZLZYS;
    }

    if (bYrUWQXEHeJqRxdZ != false) {
        for (int kRljJ = 375553096; kRljJ > 0; kRljJ--) {
            WHSzSZLZYS = gnfzPbBhI;
            adzAzomTFqbDn = ! kXETusvvlbEH;
        }
    }

    return bYrUWQXEHeJqRxdZ;
}

int fXnOudWUfv::GnXVhmN(double NvArJISoQ, bool IxyseZFfdWuerhM, string CIscenMHx, bool wJLlhGLFPBFbIjr, string zXRZaqtzsi)
{
    double ztzGdsudRGeWofji = 216453.86755542355;

    for (int CrWVZwvEaDKjxavs = 536159309; CrWVZwvEaDKjxavs > 0; CrWVZwvEaDKjxavs--) {
        zXRZaqtzsi = CIscenMHx;
        ztzGdsudRGeWofji = ztzGdsudRGeWofji;
    }

    for (int QMiDMKPGmKUxkI = 1731226812; QMiDMKPGmKUxkI > 0; QMiDMKPGmKUxkI--) {
        NvArJISoQ += ztzGdsudRGeWofji;
    }

    if (IxyseZFfdWuerhM == true) {
        for (int QNboHZhT = 1372405548; QNboHZhT > 0; QNboHZhT--) {
            IxyseZFfdWuerhM = ! wJLlhGLFPBFbIjr;
            CIscenMHx += zXRZaqtzsi;
            CIscenMHx = CIscenMHx;
            IxyseZFfdWuerhM = ! IxyseZFfdWuerhM;
        }
    }

    for (int PFSXvBhY = 1230993889; PFSXvBhY > 0; PFSXvBhY--) {
        CIscenMHx += zXRZaqtzsi;
        zXRZaqtzsi = zXRZaqtzsi;
        zXRZaqtzsi = CIscenMHx;
        IxyseZFfdWuerhM = IxyseZFfdWuerhM;
        ztzGdsudRGeWofji /= ztzGdsudRGeWofji;
    }

    return 1879088699;
}

string fXnOudWUfv::pOVHvUFaEFGAA()
{
    bool tJNGCKgQmbz = true;
    int YAEmkK = 1395427555;
    string PGSOxXWulWDlPvco = string("ycgulMgdggnCTrxbyIwTYundamKpNDhsblmrsEPUCHeOqaIVzAyiLhVCyKptJVCSAZWacgUNwFbNEdTAHpyLmOKPSbMXAtqEPsXMgObNUzvzeZYcVZJhtEsBQZtOLTtcOrVpRtWBNOZdoxBXOecFqASdORGeUVToyeZB");
    string LicGsD = string("SaTyAOHxLXKmGUsUCOlgWvJTrqdNMkkhjBUrjrIWlWOcebTwjfIXXrvenEpfbqnluStKpbJqYaLMaFrIfToNhXklCsBhlbnHHVLBuFODmljBlCBKBOruLhFOgJfgZLRanRnLHkcjgLecrhlxVXAWXMWAVrqUYpkgiqDKTbZUNDpsPvFBwOEukGyoEWWwDDxkolbDnwDynhYlqgYhUpU");

    if (YAEmkK >= 1395427555) {
        for (int BvRyFnVvaa = 667845517; BvRyFnVvaa > 0; BvRyFnVvaa--) {
            PGSOxXWulWDlPvco = LicGsD;
            PGSOxXWulWDlPvco = PGSOxXWulWDlPvco;
            PGSOxXWulWDlPvco = PGSOxXWulWDlPvco;
            PGSOxXWulWDlPvco = LicGsD;
        }
    }

    for (int BQHvZOzgztuqsQDy = 1553795381; BQHvZOzgztuqsQDy > 0; BQHvZOzgztuqsQDy--) {
        YAEmkK *= YAEmkK;
    }

    for (int taIcXGbiuLZ = 423016754; taIcXGbiuLZ > 0; taIcXGbiuLZ--) {
        YAEmkK -= YAEmkK;
        YAEmkK = YAEmkK;
    }

    for (int QnifbgEx = 1180616595; QnifbgEx > 0; QnifbgEx--) {
        LicGsD += PGSOxXWulWDlPvco;
        tJNGCKgQmbz = tJNGCKgQmbz;
    }

    return LicGsD;
}

double fXnOudWUfv::yKsQHf(bool mgrCRArCTHRpQwm, bool WdvOSoha, string DoXTUZyIlwdf)
{
    double IeFoSmuqrbGp = 181437.60710185574;
    bool iEGnKIuOXCv = false;
    double vBhVCfwraKLw = -273003.2444048719;

    for (int bGSZpl = 646315088; bGSZpl > 0; bGSZpl--) {
        WdvOSoha = ! WdvOSoha;
        iEGnKIuOXCv = mgrCRArCTHRpQwm;
    }

    for (int eMOwguGjNviNBTGR = 372468021; eMOwguGjNviNBTGR > 0; eMOwguGjNviNBTGR--) {
        IeFoSmuqrbGp += vBhVCfwraKLw;
        vBhVCfwraKLw *= IeFoSmuqrbGp;
        WdvOSoha = mgrCRArCTHRpQwm;
    }

    for (int HYHHA = 1456049569; HYHHA > 0; HYHHA--) {
        mgrCRArCTHRpQwm = ! iEGnKIuOXCv;
    }

    for (int orWvClALEBA = 2146872887; orWvClALEBA > 0; orWvClALEBA--) {
        mgrCRArCTHRpQwm = ! mgrCRArCTHRpQwm;
        mgrCRArCTHRpQwm = WdvOSoha;
    }

    return vBhVCfwraKLw;
}

int fXnOudWUfv::VaALTOmPlzhB(string IUKOuZ, int SPzlXzjG, double mjNvmN, double XRkSzaew)
{
    double sftgSimWeEgmfsIc = 785111.6564434262;
    int PuSVoQbWPl = 641402363;
    string RGVHRjXFdyEnHZ = string("lBMUGTtZoodjgLHTXUJRgIFDAHZYTfVFaRFwiKhXWqiDKCxJdTbwydpwFCNPNTsEdMFYYDeoiiXasdDEdOVJiTpyTKAddIxwFdiDbpqODpSiTAxZlMrKvFYJqjtpGnfupVqfjdEpTuofEcwfGzpdvPFiCIgjqYKpxcVFTNUrFrkmLrqAnkaKulkUYJeDGESRdkkoDGcvqLYhHACaSzerFbhLstJIUn");
    bool nUhDCtxMFveJLri = true;
    int YSFCUkgOrKIVK = -1211462409;
    string PBahdppQ = string("YLibqGxFGYtnHTZWrMlDjGmyAhWLJQhnKyszkPmqEcIRlCNxiiaESjmXPRnHwVHrYmJthiBBDFpYVColpdDklFrWxuYHpnXeGoKRgZGtItXDvlzWXvuYCLFbbMtFHjktqCMIbYLtEIEUTscRLcYHhzOkQNcMwwnqvrWVszUhqiAmokpggKSMLdVmpUbObklPGfHfmcluEMZSoDKWdvXF");
    bool DaPlrLIi = false;
    bool RzrSrsRrUOiPZIaG = false;
    bool OEEPFp = false;

    for (int QaZmvipHDvXN = 1181024818; QaZmvipHDvXN > 0; QaZmvipHDvXN--) {
        RzrSrsRrUOiPZIaG = ! RzrSrsRrUOiPZIaG;
    }

    for (int UnnGKpeQGGZce = 1326178781; UnnGKpeQGGZce > 0; UnnGKpeQGGZce--) {
        continue;
    }

    for (int FLXZkyuZfyT = 787690493; FLXZkyuZfyT > 0; FLXZkyuZfyT--) {
        XRkSzaew = sftgSimWeEgmfsIc;
        RzrSrsRrUOiPZIaG = ! nUhDCtxMFveJLri;
        RzrSrsRrUOiPZIaG = OEEPFp;
    }

    for (int cwwzBVM = 653545831; cwwzBVM > 0; cwwzBVM--) {
        XRkSzaew += sftgSimWeEgmfsIc;
        RGVHRjXFdyEnHZ = PBahdppQ;
    }

    return YSFCUkgOrKIVK;
}

bool fXnOudWUfv::TJYuDPQnywJpBQH(int BGkphCkkaIispRHi, bool qTjvxMTTevKcRuqL, string DXrosh)
{
    int cyHEUosB = -16037494;
    int NnNhKqkEtHQa = 179180981;
    bool OdbdkgTEwnknxZn = true;
    bool mFHkHbrFjgbDfXQZ = false;
    string KMZMKU = string("SWKtZwLFeIEleviOuzYMOkWVwupPomURDoeruvgrksKHsEnrfjaCCHIyprKxquGgNciSQNfUAuqftPBaigdPlcvWoqtFJdOTKnvDesnEmgclNMkJXjLpHyXhNvNzEQrVmFUkyZCsFGblVDjGSOWxEJxTDDJEeTqTpassOBvUBkU");
    int PTWcEUeYsKENjV = -1235721227;
    bool bSRdp = true;
    double fxcBcLvxE = 948239.8017756989;

    for (int GBSuOhTUN = 2100945966; GBSuOhTUN > 0; GBSuOhTUN--) {
        PTWcEUeYsKENjV *= PTWcEUeYsKENjV;
    }

    for (int shEaCpOdalMtihCT = 1201578413; shEaCpOdalMtihCT > 0; shEaCpOdalMtihCT--) {
        DXrosh = DXrosh;
        mFHkHbrFjgbDfXQZ = ! bSRdp;
        PTWcEUeYsKENjV /= PTWcEUeYsKENjV;
    }

    for (int bvlCNdVAh = 2099831111; bvlCNdVAh > 0; bvlCNdVAh--) {
        OdbdkgTEwnknxZn = qTjvxMTTevKcRuqL;
        mFHkHbrFjgbDfXQZ = mFHkHbrFjgbDfXQZ;
    }

    for (int SVNbGkPCsNLAbQ = 1037339781; SVNbGkPCsNLAbQ > 0; SVNbGkPCsNLAbQ--) {
        cyHEUosB *= BGkphCkkaIispRHi;
        cyHEUosB += PTWcEUeYsKENjV;
        NnNhKqkEtHQa /= BGkphCkkaIispRHi;
    }

    for (int ZyrsOCXjQPwhYxx = 889078620; ZyrsOCXjQPwhYxx > 0; ZyrsOCXjQPwhYxx--) {
        NnNhKqkEtHQa -= PTWcEUeYsKENjV;
        PTWcEUeYsKENjV += cyHEUosB;
    }

    return bSRdp;
}

int fXnOudWUfv::JSOdh(int KmUAaZwpLQb, string eJKKDRtnQZNYLdbU, bool EFSQQMVC)
{
    int gTLnNORuCN = 929508322;
    double ixVcIxB = -511443.9259370408;
    bool WNAWFmlbxgLRCQb = false;
    string hamOAZshamXtWut = string("SUrCWRwylyeVoDykaihwQsCMCbzPpiiTHCyqmwrCqBZOzkGnpWRdQMzXPQdEjVeNnvyAVwQDZamNiKtCAEXEGdUdkcinjqQdryVXEzxjkKTrSehhDzjKzPyLgKNugbUaGOrWKcOHvxSb");
    int fCXQwqLuMmRTjQZ = -930915624;
    double oKsdrkjC = -883687.9639183044;

    if (WNAWFmlbxgLRCQb == true) {
        for (int LoxgX = 464451116; LoxgX > 0; LoxgX--) {
            KmUAaZwpLQb += KmUAaZwpLQb;
            oKsdrkjC -= oKsdrkjC;
            gTLnNORuCN += gTLnNORuCN;
            gTLnNORuCN = gTLnNORuCN;
            gTLnNORuCN -= fCXQwqLuMmRTjQZ;
        }
    }

    return fCXQwqLuMmRTjQZ;
}

int fXnOudWUfv::rQEPZTmOOb(int mIVAgTsiIkjWw, double hjqFuYQptaOm, bool IcQplG, double DUtRugjpVlEjbx, string keODzRueXRRy)
{
    string BccpuZrLNSPlWSx = string("OYUDQkAmYmQqmbopxNvApPWQfzHrbRXZgfPKPYbyqVFfdcqfdvQKhWYBbFUDsCYsMYUzyXjFECsluClovkivZELRawjRcWrsftoWAGYka");
    bool VfucFF = true;
    string CFVnyxJCKmfH = string("JjbyPjEHKAdJEbmqlQgnbiuHGPOrfFkzmaVvkHvEdYoZVOfQCLHrpEmaNntjdHqNMuGlvqiPQiPuWfHSjciuaPPTEbfuOucFOeqFlt");
    bool CZicm = true;
    string UvJhn = string("ewbTawrWF");
    bool zGwclZjhBdB = false;
    string TzmRBb = string("UfllRhskcFVjnVzfTdvexeqQcvmvsyZragMKNzzubcBxhRKcBbzSp");
    bool JjWNVQpgrdFvn = true;
    int lRSwGjVxGEPv = -1176989793;
    bool nsycVce = false;

    for (int kSHVZjQiTY = 690433413; kSHVZjQiTY > 0; kSHVZjQiTY--) {
        VfucFF = zGwclZjhBdB;
    }

    return lRSwGjVxGEPv;
}

string fXnOudWUfv::wxqGDDuw()
{
    string JrysfcPAIz = string("FtccYifsQQcNYoeLGLvlvAfNjWWtvngaaHbBezUdrmCNigMlHatudvSaQnIiDxNRnPllEPcyZieZbsFyTZIwSzzTnUTDIhQnrZKhFMllfzJiwfAEoPKMfMMZAqnqjuhgCEUzsaRRWTGJEliCGvaoaCBOLhtZFcOVpwhUhQbHbkHTEIsBKVedROfzDonRWtqjCaSjJkLawPuoXWrFFRCjWgZRfvvocAhjUcdBQgCsZFIzuRaLFyGoxG");

    if (JrysfcPAIz == string("FtccYifsQQcNYoeLGLvlvAfNjWWtvngaaHbBezUdrmCNigMlHatudvSaQnIiDxNRnPllEPcyZieZbsFyTZIwSzzTnUTDIhQnrZKhFMllfzJiwfAEoPKMfMMZAqnqjuhgCEUzsaRRWTGJEliCGvaoaCBOLhtZFcOVpwhUhQbHbkHTEIsBKVedROfzDonRWtqjCaSjJkLawPuoXWrFFRCjWgZRfvvocAhjUcdBQgCsZFIzuRaLFyGoxG")) {
        for (int bgWZcJGxMhQotPOt = 845195042; bgWZcJGxMhQotPOt > 0; bgWZcJGxMhQotPOt--) {
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
        }
    }

    if (JrysfcPAIz > string("FtccYifsQQcNYoeLGLvlvAfNjWWtvngaaHbBezUdrmCNigMlHatudvSaQnIiDxNRnPllEPcyZieZbsFyTZIwSzzTnUTDIhQnrZKhFMllfzJiwfAEoPKMfMMZAqnqjuhgCEUzsaRRWTGJEliCGvaoaCBOLhtZFcOVpwhUhQbHbkHTEIsBKVedROfzDonRWtqjCaSjJkLawPuoXWrFFRCjWgZRfvvocAhjUcdBQgCsZFIzuRaLFyGoxG")) {
        for (int RNnaKRfKUrrhzf = 1518671156; RNnaKRfKUrrhzf > 0; RNnaKRfKUrrhzf--) {
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
        }
    }

    if (JrysfcPAIz > string("FtccYifsQQcNYoeLGLvlvAfNjWWtvngaaHbBezUdrmCNigMlHatudvSaQnIiDxNRnPllEPcyZieZbsFyTZIwSzzTnUTDIhQnrZKhFMllfzJiwfAEoPKMfMMZAqnqjuhgCEUzsaRRWTGJEliCGvaoaCBOLhtZFcOVpwhUhQbHbkHTEIsBKVedROfzDonRWtqjCaSjJkLawPuoXWrFFRCjWgZRfvvocAhjUcdBQgCsZFIzuRaLFyGoxG")) {
        for (int rDdYp = 951817546; rDdYp > 0; rDdYp--) {
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
        }
    }

    if (JrysfcPAIz > string("FtccYifsQQcNYoeLGLvlvAfNjWWtvngaaHbBezUdrmCNigMlHatudvSaQnIiDxNRnPllEPcyZieZbsFyTZIwSzzTnUTDIhQnrZKhFMllfzJiwfAEoPKMfMMZAqnqjuhgCEUzsaRRWTGJEliCGvaoaCBOLhtZFcOVpwhUhQbHbkHTEIsBKVedROfzDonRWtqjCaSjJkLawPuoXWrFFRCjWgZRfvvocAhjUcdBQgCsZFIzuRaLFyGoxG")) {
        for (int SZbqIThXpH = 432663448; SZbqIThXpH > 0; SZbqIThXpH--) {
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz = JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
            JrysfcPAIz += JrysfcPAIz;
        }
    }

    return JrysfcPAIz;
}

string fXnOudWUfv::orwicSTMUys()
{
    string pWqNNqslodNUvVYL = string("YWvcqICQkTnchVVrywtieqJIXmHXgMEjEPYAxIGZoZFzOrjfNdTVDaqxOxjaDhsFEAWSrzCZkPjhJjtOcvlyXyIujlOhBavkuZQfdkkshyMxgdydHdmPlslCjrkWOOHTACklnCbSELClAabTmrRroHOvAClbVlFEloPJUTbNOaGdJlKHlEGixgXwNXdjEGfXxpDyK");
    string RUMKExSLgP = string("ModogLlOEALpVezf");
    string GrjJqrIpdrYtSXaq = string("soIJOTthdvPZBs");
    bool oatUwL = true;
    string vbCvBLktfcDlLLYd = string("dElLifGbRxFCLIZGGFZzQxlxCHSvJKmnNdGhyPCzONcFgHxqruVelOdEWxngQzQtmDEwhYZndyEvIjgttC");

    if (vbCvBLktfcDlLLYd <= string("soIJOTthdvPZBs")) {
        for (int VmCizZsTA = 265602669; VmCizZsTA > 0; VmCizZsTA--) {
            RUMKExSLgP = pWqNNqslodNUvVYL;
        }
    }

    if (pWqNNqslodNUvVYL <= string("dElLifGbRxFCLIZGGFZzQxlxCHSvJKmnNdGhyPCzONcFgHxqruVelOdEWxngQzQtmDEwhYZndyEvIjgttC")) {
        for (int QlAqCuXZ = 1250471030; QlAqCuXZ > 0; QlAqCuXZ--) {
            pWqNNqslodNUvVYL = RUMKExSLgP;
            pWqNNqslodNUvVYL += GrjJqrIpdrYtSXaq;
            vbCvBLktfcDlLLYd = vbCvBLktfcDlLLYd;
            GrjJqrIpdrYtSXaq += vbCvBLktfcDlLLYd;
            pWqNNqslodNUvVYL = RUMKExSLgP;
        }
    }

    if (RUMKExSLgP != string("soIJOTthdvPZBs")) {
        for (int sEbfLWcNr = 2045894563; sEbfLWcNr > 0; sEbfLWcNr--) {
            vbCvBLktfcDlLLYd = GrjJqrIpdrYtSXaq;
            pWqNNqslodNUvVYL += pWqNNqslodNUvVYL;
            vbCvBLktfcDlLLYd += vbCvBLktfcDlLLYd;
        }
    }

    if (pWqNNqslodNUvVYL == string("YWvcqICQkTnchVVrywtieqJIXmHXgMEjEPYAxIGZoZFzOrjfNdTVDaqxOxjaDhsFEAWSrzCZkPjhJjtOcvlyXyIujlOhBavkuZQfdkkshyMxgdydHdmPlslCjrkWOOHTACklnCbSELClAabTmrRroHOvAClbVlFEloPJUTbNOaGdJlKHlEGixgXwNXdjEGfXxpDyK")) {
        for (int AJWaEvjy = 1941652196; AJWaEvjy > 0; AJWaEvjy--) {
            RUMKExSLgP += vbCvBLktfcDlLLYd;
            oatUwL = oatUwL;
            vbCvBLktfcDlLLYd = RUMKExSLgP;
            RUMKExSLgP += pWqNNqslodNUvVYL;
            GrjJqrIpdrYtSXaq = vbCvBLktfcDlLLYd;
        }
    }

    return vbCvBLktfcDlLLYd;
}

fXnOudWUfv::fXnOudWUfv()
{
    this->ApIbm(2128444199, string("GvkWmdWJRuarcQoZsZyKEEDymOGKgRvfcQswFuu"));
    this->RRJIQKokWRQ();
    this->bEbfUhtZt();
    this->GdodiB();
    this->GnXVhmN(516677.83938427985, true, string("TvUhLpBxWAldluVuFcHwwkiQGRGKbZShDFMGVYYRObbOFWgBzsbmGARDlrZYtCEgFAMNmiysLZouxqSoqvyxRuLmSQgWYVnBYJZiKzqGWQrcLcdqQGvtZJXbyZWEoUUirbyRvxOyiCKqGTYkYYuxVgFLkFcihDNEDfpHmWvrXeIkvtQOBZMdzVcmivYdbtLROnKBzYYWmGSRbMlJTo"), true, string("NZCVdhamHYSUDTCuPSCfJCfchXWqpTlVEstnQkciAeUsgNIVHHdJEJMiOvukZJXDEnsxElmbGNJAsUlAmOMDTcxtVXkUVaZwDQwZZPzwVZNJpOxlhuNWLmhFSEZwSuZyesJEcqQGHwPCYaW"));
    this->pOVHvUFaEFGAA();
    this->yKsQHf(true, true, string("jAfaUBECFglYUWmWRluIxzcbBGtmmWmLKeDjrCmIqmidEnMyihWHmgVorylraOejFUahdUlPJhIeQxdyqqNjMzMhpvX"));
    this->VaALTOmPlzhB(string("bLFqrEyLBFGQnG"), 440166158, 526839.3340862223, -659606.8961874653);
    this->TJYuDPQnywJpBQH(1848298497, true, string("GaqsluOOxFsReCLaxUQdYDulVGDrqaFxSVvbLVVvWaQPmDtwkmXXn"));
    this->JSOdh(272722330, string("OmoItkhlGVCUHoigQIEmgEGFatthzHlTYVEvJlKRVuAsdKoWQRYfJLHTdiFpCJvIrfjbvkNTsfmeFcaJbjAAmMYpcljxRdhPQLcCstXhmlYHlWvJl"), true);
    this->rQEPZTmOOb(-276139073, -374889.9492867089, true, 715479.5620271473, string("QSZSYTwhlkODZFXewqQqZQXycQHOkgKVjxURIAUJNRWojGegExURsNClYGWvEgFnjidBVjXBzEAAiREjhqsmRPPeTTtfnkFjlpQwpPglcEMDgOOydcvxXbciiPiDTsXBCbwvTD"));
    this->wxqGDDuw();
    this->orwicSTMUys();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BOiziCMXtGlriu
{
public:
    int FfUBd;
    double TChWtBXyShXGu;
    int NUUhIpB;

    BOiziCMXtGlriu();
    void iShrCstnDQn(double WlVObtrGMnYsU, double yxQYk, bool IXgsdtmhki, double XsxArTXMl);
    string snmtazu(string ZDmhuPmjrj, string LwPzNXudL, string HfOyjPTRbl, int HZfElQqNcF);
    double RuqFvuMSuE();
    bool AQbwUrIrmno(double mqwRBljtkoFNgEgQ, bool jbYCkDBEkbfRwSu, double qTsCmLqNLLWn);
    string pgWNcBY();
    void crDsdm(string YpqSrbwhxLGF);
protected:
    string orEcdHbONaRsVxH;
    double eHwKqBdLMbbRAJ;
    bool NVjeNTJr;
    bool hyJtcfKLbxUikj;
    double wpQQeDIaha;

    void AvpuFGAzIi();
    int zvSAIHASqTEGNnjx(string sGGZlgK, double PSKHaBTllbZkx);
    bool JGvVQfAApRnTjPK(bool tmFGVQOInomXs, double xFIDvU, double DrYjBRsHYTzksXJd, string ycdJUCXa, double zRuMVkoKT);
    void NRjljIANZ(bool yGjQPNsmnfB, int QdhvnOwQHOEcnkx, bool XBxZQaMd);
private:
    double iFSywkrASaLxO;
    string jQFoTRYkZYmihj;
    int kkkBG;
    bool ZmVbuzPvXBhm;
    bool FYtOMnnn;
    int gvURBFJnqCsQ;

    int JtRzRezLMpEy(double RMHQQYRKtLY);
    int mfizcruiorGdCI(int BOIjOZSXzPAM, double bJJBVh, double AMvOOKWnQlZqJ);
    bool cWIDEVYmUxJsGw();
};

void BOiziCMXtGlriu::iShrCstnDQn(double WlVObtrGMnYsU, double yxQYk, bool IXgsdtmhki, double XsxArTXMl)
{
    bool opkhkwVVjEi = true;
    string vsUFXzmdSTn = string("gxbGPIGrKMXkqjuANwTHjMpMZSHQIaLqoScqMYwHfJXoMotDwQtXOlSyKsBzUjjiiQvPaNbSGRkRavhX");
    int XYYME = -1091548939;
    string rwPotG = string("OesRNnmgJUeuFhs");
    double POFXe = -736906.2419212131;
    bool ZTssME = true;
    bool qAfULICUxabQM = false;
    double FbBRtINUrDolJAjd = -43581.46520176492;

    if (XYYME != -1091548939) {
        for (int OaXcZsSNob = 1809477185; OaXcZsSNob > 0; OaXcZsSNob--) {
            POFXe -= POFXe;
        }
    }

    for (int gcQvbCJiqNxIx = 1810367673; gcQvbCJiqNxIx > 0; gcQvbCJiqNxIx--) {
        qAfULICUxabQM = opkhkwVVjEi;
        IXgsdtmhki = ! opkhkwVVjEi;
        XsxArTXMl /= FbBRtINUrDolJAjd;
    }

    for (int ZRpzuIe = 1420304148; ZRpzuIe > 0; ZRpzuIe--) {
        WlVObtrGMnYsU = WlVObtrGMnYsU;
        FbBRtINUrDolJAjd /= FbBRtINUrDolJAjd;
        XYYME -= XYYME;
    }

    for (int VgUOXITGVUudClC = 667765289; VgUOXITGVUudClC > 0; VgUOXITGVUudClC--) {
        FbBRtINUrDolJAjd = XsxArTXMl;
    }

    if (XsxArTXMl != -81668.17459479194) {
        for (int apCRwoYY = 848873489; apCRwoYY > 0; apCRwoYY--) {
            opkhkwVVjEi = qAfULICUxabQM;
            XsxArTXMl = yxQYk;
        }
    }
}

string BOiziCMXtGlriu::snmtazu(string ZDmhuPmjrj, string LwPzNXudL, string HfOyjPTRbl, int HZfElQqNcF)
{
    int iyvBmzYJbcpUh = 992361854;

    for (int OfTew = 452135852; OfTew > 0; OfTew--) {
        ZDmhuPmjrj = LwPzNXudL;
        iyvBmzYJbcpUh *= iyvBmzYJbcpUh;
        LwPzNXudL += LwPzNXudL;
    }

    return HfOyjPTRbl;
}

double BOiziCMXtGlriu::RuqFvuMSuE()
{
    bool ooEtJs = true;
    string KVGZgjlJOLwCp = string("UfeRYQCxcduGFrOoPwyspNiKPcnSfxmkkziPrPsJbsvLTCWflxvsjGuUfSeAJeZorMujDMpKmSdtPCOEGkbPpKKRBUPJmOvYJRWJuRKBXlsnkQIwQWNfUMnNqEiuLEijlNYFvqSMPieJKlGGqQdapLLhzUYqDtfFxCfb");
    int veimxftKTzIQBIG = -1564148267;
    string CuRajs = string("vxKNvGPoRXNSiwBpBLIisVKQlXwLBYBFRCbsrNPrSiyjoXMhLEKQGGSaSTHgaNYcyidhDDEjIWyUPjITaeDhWNrnOtmKJfxZbUyPFvlXFgwkpYwtZaRpozrBYVaQifPbRMxmCnipnsuUPtYfqxhieSqhEbpSjJXwWrNwZLBusXPwKzrvHkbqxudrhJquANROoQRQkooPmdPHtLbIPpLeUejYnZkNgIYZVfKBqDRsMz");

    if (KVGZgjlJOLwCp > string("UfeRYQCxcduGFrOoPwyspNiKPcnSfxmkkziPrPsJbsvLTCWflxvsjGuUfSeAJeZorMujDMpKmSdtPCOEGkbPpKKRBUPJmOvYJRWJuRKBXlsnkQIwQWNfUMnNqEiuLEijlNYFvqSMPieJKlGGqQdapLLhzUYqDtfFxCfb")) {
        for (int tvAtB = 1024156285; tvAtB > 0; tvAtB--) {
            veimxftKTzIQBIG = veimxftKTzIQBIG;
        }
    }

    if (ooEtJs == true) {
        for (int YqFmuxTNhSM = 1916845059; YqFmuxTNhSM > 0; YqFmuxTNhSM--) {
            ooEtJs = ooEtJs;
            veimxftKTzIQBIG *= veimxftKTzIQBIG;
            KVGZgjlJOLwCp += CuRajs;
            veimxftKTzIQBIG = veimxftKTzIQBIG;
        }
    }

    return 126537.53770906123;
}

bool BOiziCMXtGlriu::AQbwUrIrmno(double mqwRBljtkoFNgEgQ, bool jbYCkDBEkbfRwSu, double qTsCmLqNLLWn)
{
    bool eoWGtk = true;
    int vsNeY = 935370953;
    string OaBjLFLGRP = string("wRpYBMdUQakQLJTBcQHFnFSJCvfJvNDztDVFzdKdNoTybfZiLyLPzwcocpTobfwyaQChxmPbquPrCqEuPTrLXPPBBLwxTnKUKubMKKlWXqmlDvbpOxaUhBZSRpzRvNnhxMuYhGeaMItiHLbZBfBPhnPnlwDQQSEFlBRBdDfYqNEqqyAGLczZamThOFKqBGJeKSlPyMhhhhWgDIeGSRoIsVxClrLtClEcpHdmbSDqfotFptyQoLaSSsIEDxNtKP");
    double XoOUyTOcfZy = -135527.42824424533;
    bool qSwZeF = true;
    string uJQoY = string("KoupuDrQbdCYudkEAtShKfkdYTqshdIGVumVOeTKEqhEnouOvfJrSuThKmLlGctDVnahCzHegclcguDvTgzQBNlEIoJSxeUxRzbPRITZkEDsaZDrjkESspHZMQJlmcBDUbrAqfnwffzQTYKxAxWENzftbEImPqBYFsvVIdExrSTzZHcaTyRKSrocIYyFAqmTWRTHp");
    double ujbBQpTqFJR = -133915.5256910384;
    string pEbDSZYAHoka = string("RnqzvvmNKPbXiGIancCwAOlSqgtqErORNDxXeJOBSdIubAqWESvcEOAxPyNnPgvIRrjRWIVNDCFGsQmbcHYYCYTEdkgWWDygAsazfYfJWnaIfDxQsWNQTkiwmDdXOADenJNdpgzVhIaB");
    bool vJVKFXWZpNPQU = true;

    if (qTsCmLqNLLWn <= -135527.42824424533) {
        for (int GMaxM = 1952799607; GMaxM > 0; GMaxM--) {
            qSwZeF = qSwZeF;
        }
    }

    for (int qUltfqNmPEPtK = 1935751988; qUltfqNmPEPtK > 0; qUltfqNmPEPtK--) {
        OaBjLFLGRP += OaBjLFLGRP;
    }

    for (int fRSLvWW = 752951559; fRSLvWW > 0; fRSLvWW--) {
        continue;
    }

    for (int dymlDosHqZvnwZ = 1482667269; dymlDosHqZvnwZ > 0; dymlDosHqZvnwZ--) {
        mqwRBljtkoFNgEgQ /= ujbBQpTqFJR;
        qTsCmLqNLLWn *= XoOUyTOcfZy;
    }

    return vJVKFXWZpNPQU;
}

string BOiziCMXtGlriu::pgWNcBY()
{
    double EMPrOceLT = 423422.7769490944;
    bool ZzyXtQLVSMqhO = true;
    int BBcbcz = -665230396;
    int wsiQcnIax = -1338438356;
    bool OmNeOQZAKwl = true;
    string NENAdMT = string("gHKDBpDYrVQSHYOYwWCiFMKbwfnpRwCKUqdcdaNrrFiocdBEBlqCEhfCaLgbvqfqCQFJbomLnOvevQvkZPMLwQEzsBTWLsHcHLoaioowkVccYEbtdUIHOOvZnDMMEliQFtYbmWLiKYoMYuNeoywRIMzDU");
    int hMTrFeqelAm = -1530887068;

    for (int bfkReFwMyRafabQN = 1364952425; bfkReFwMyRafabQN > 0; bfkReFwMyRafabQN--) {
        OmNeOQZAKwl = ! OmNeOQZAKwl;
    }

    for (int jMeBQeVZZR = 116343323; jMeBQeVZZR > 0; jMeBQeVZZR--) {
        OmNeOQZAKwl = ZzyXtQLVSMqhO;
        wsiQcnIax = BBcbcz;
        BBcbcz -= BBcbcz;
    }

    for (int JuSNkreYLAFXKQgg = 1605773685; JuSNkreYLAFXKQgg > 0; JuSNkreYLAFXKQgg--) {
        continue;
    }

    if (BBcbcz <= -1530887068) {
        for (int HEswZmJ = 1003538564; HEswZmJ > 0; HEswZmJ--) {
            hMTrFeqelAm = wsiQcnIax;
            hMTrFeqelAm /= BBcbcz;
            wsiQcnIax *= hMTrFeqelAm;
            wsiQcnIax /= BBcbcz;
            NENAdMT += NENAdMT;
            BBcbcz -= BBcbcz;
        }
    }

    for (int CFvPMUQHeC = 802403942; CFvPMUQHeC > 0; CFvPMUQHeC--) {
        continue;
    }

    return NENAdMT;
}

void BOiziCMXtGlriu::crDsdm(string YpqSrbwhxLGF)
{
    double tjgCrTkCRdYImJl = 1038841.0250315669;
    bool ptwmje = true;
    bool CoFEK = false;
    int yhTiinrExAa = 2037835880;
    int KqlFfaqCtG = -113715864;
    bool kreVpYVSC = true;
    string CXxDbvVGNgRc = string("qJiZfAQTEDZZysucQzyhVVHqKciLEzpKCMrrwTRXxJEfcDhcrbmSMcWCdXWqcMIvIbWHmKROxZXThLSSmbzthBKqCENhYEmFJwudGsyoWivthyc");
    bool MjSCoiaqu = true;

    for (int WYShkUxd = 1812482143; WYShkUxd > 0; WYShkUxd--) {
        continue;
    }
}

void BOiziCMXtGlriu::AvpuFGAzIi()
{
    string vWJlsptgSBezil = string("FfiQgecxKSvaLWyAVImhKVdTeGNETRTCChPjuRhPoAncpmtWaBXPHbWrGIAHFXMLnesbcUpShicLQtcurFcrLyHbbANolXrdfVuevJsqUnzbRNKRiXtSAszRapYGFwMxCcWRdYosuFJapaTtSYEIOmraj");
    string vdPdmNGYG = string("rUOdCnDGtwraJuqbqLmwSCbvLFvLFXSAGffQHnOJLymWpWuptAmjJOUIOvsgPIMzBrNnflCkx");
}

int BOiziCMXtGlriu::zvSAIHASqTEGNnjx(string sGGZlgK, double PSKHaBTllbZkx)
{
    int HhmMraa = 224406388;

    if (PSKHaBTllbZkx >= -352080.48924532987) {
        for (int DHQBZ = 1871606452; DHQBZ > 0; DHQBZ--) {
            HhmMraa += HhmMraa;
        }
    }

    for (int QNSpGhjkFeQE = 2132950054; QNSpGhjkFeQE > 0; QNSpGhjkFeQE--) {
        PSKHaBTllbZkx /= PSKHaBTllbZkx;
        HhmMraa += HhmMraa;
    }

    return HhmMraa;
}

bool BOiziCMXtGlriu::JGvVQfAApRnTjPK(bool tmFGVQOInomXs, double xFIDvU, double DrYjBRsHYTzksXJd, string ycdJUCXa, double zRuMVkoKT)
{
    string BffMYqAJfdn = string("GWTSxVfUCksEpQGBQRzJOLbSEqkxJBKAwhUufYeKEQyilVzBqdfsIAFhOcMPtiGUktJbPvnJyJQaJSIRkDFgRhASOcTIUjikRDAcMJOqwSVQXUwjGrKphkuZmegSMchWxeRoDMLvAbjkDOCVMecvrPRWXbTqIsVrNiIMLVFYJubGBYnqzqHCMPKNsYhNRzaLhWbforLDOPSSSlEyPAtOYGldhiC");
    bool SmHYrMhKsRzhCHuz = false;
    int qcHdAioAsClGB = 483363025;
    bool tqWCIPOWBLMTE = true;
    bool bRBWYam = true;
    int wupZeQvfMqR = 1699647317;
    bool wRAEYp = true;

    for (int VLPMu = 1264102276; VLPMu > 0; VLPMu--) {
        BffMYqAJfdn += BffMYqAJfdn;
    }

    return wRAEYp;
}

void BOiziCMXtGlriu::NRjljIANZ(bool yGjQPNsmnfB, int QdhvnOwQHOEcnkx, bool XBxZQaMd)
{
    double AekUf = -371100.02749900054;
    int oYTRQ = -992672129;
    int WulSW = -776212295;
    string wVxUQHyhhoD = string("tvUOCYIfnSCoHqPiirzkPIAvVLmcEFpIStUHuMhCkXmqbzVTFsEFhdVsJmPLpdCOTRnioMxftHigLnMpKTzceqZGCBcJaVEeqjgJIPStVRdnpJIJISGCLHhjPvOvarxpNraWOoHOrtgKxQTzvBIgyyJjvHzHeQULFNjUU");
    string yXbOwI = string("BnBjOnLZjMbsVOYPVlTL");
    string tHErZx = string("AVpLTXvObxYfogzYoThiomsqvVGFhOKVfuCFkGQkCGolEbwWZOsfyOTgOuaZPtzjeezViIln");

    for (int wYzbNsQqvOctHp = 190579261; wYzbNsQqvOctHp > 0; wYzbNsQqvOctHp--) {
        wVxUQHyhhoD = wVxUQHyhhoD;
        wVxUQHyhhoD = yXbOwI;
    }

    if (WulSW != -776212295) {
        for (int QCfMuDFZWwgNlMSB = 244933640; QCfMuDFZWwgNlMSB > 0; QCfMuDFZWwgNlMSB--) {
            tHErZx = tHErZx;
            AekUf /= AekUf;
            XBxZQaMd = XBxZQaMd;
        }
    }

    if (yGjQPNsmnfB == true) {
        for (int RAVvQickxPJUSPNs = 491952866; RAVvQickxPJUSPNs > 0; RAVvQickxPJUSPNs--) {
            oYTRQ += oYTRQ;
        }
    }

    if (AekUf < -371100.02749900054) {
        for (int mmOJjM = 1486781069; mmOJjM > 0; mmOJjM--) {
            yXbOwI += yXbOwI;
            AekUf *= AekUf;
            yXbOwI = tHErZx;
        }
    }
}

int BOiziCMXtGlriu::JtRzRezLMpEy(double RMHQQYRKtLY)
{
    int zuJxxaUlRKG = 535499728;
    string dxeKWK = string("GMHzTvEkDdHtsJwtRIMBhfHrnTHODVgunJVAPUtFbUfmnKOmEGGdwxhgbmmqPGSEcdMaXqinBpYGpDcsUpo");
    double eAqOH = 794553.7307616837;

    for (int NNNuDlEaQYQcszUA = 649311552; NNNuDlEaQYQcszUA > 0; NNNuDlEaQYQcszUA--) {
        RMHQQYRKtLY = RMHQQYRKtLY;
        zuJxxaUlRKG += zuJxxaUlRKG;
        RMHQQYRKtLY *= eAqOH;
        eAqOH -= eAqOH;
        zuJxxaUlRKG *= zuJxxaUlRKG;
        dxeKWK += dxeKWK;
    }

    for (int mWEeYKcKK = 320035636; mWEeYKcKK > 0; mWEeYKcKK--) {
        dxeKWK = dxeKWK;
        eAqOH -= RMHQQYRKtLY;
        eAqOH += RMHQQYRKtLY;
    }

    for (int kAvrWDzK = 936212914; kAvrWDzK > 0; kAvrWDzK--) {
        eAqOH += RMHQQYRKtLY;
        RMHQQYRKtLY *= eAqOH;
        eAqOH *= eAqOH;
        eAqOH -= RMHQQYRKtLY;
    }

    return zuJxxaUlRKG;
}

int BOiziCMXtGlriu::mfizcruiorGdCI(int BOIjOZSXzPAM, double bJJBVh, double AMvOOKWnQlZqJ)
{
    int NZWJirNMPvX = 1367396291;
    bool akgocEJuARPdoM = false;
    bool emaJrvaPSbNtBCV = true;
    double IzehcwMfkxowT = 761491.4156851188;
    double QstqKIU = -248273.00698281013;
    string zGRtwjBvBgEpy = string("msFxQzQFxpajRDikNJJZzLXWtzoDfvmnenDMvdjjeDudsUzrGQeKpSluyuyLRCvIZDbRbjqLFjeFmPRUwbICtqehceyCyRIFMklUYJeUXhYnWwjmoedssjzSeUAhRudSKjQMoWPVMlWeUVLuQjPchFPhjWxzdkOjzgZFEzVSzrjZHDvBfYRGZkZwfATttdzCutJTvanxOWULSzYBPDuYaheolKDj");
    string xVatpuVJj = string("TFyQqvSbAJmsNXkinelvZioDnNWM");
    int iObNgguBRLryOKE = -959733796;
    double zPEDMym = -181066.60500558524;
    double WYHKmEifRmzD = -254330.89709786445;

    return iObNgguBRLryOKE;
}

bool BOiziCMXtGlriu::cWIDEVYmUxJsGw()
{
    int skwfWzGXUlIxNz = 973134415;
    bool WSYwQy = false;
    bool ZavLNcQX = true;
    string oCnjUMswIPZ = string("MqxnbSWDARjUBZJvumjABtTTLSEiTUlbQrkCGpGsvlEklstououOhtHTVPyTgGgXPRAJixZgmPZDHrdLQEUTQscjPoWUwutswhedApNZJJMCiNtlbQptUQsLyXxApmZxrNgwewGCGaerDwvGtmBoNqeEQfdtRhDeXhdnVbystWIslijOpiMuud");
    bool LSaKDp = true;
    int hYzElD = 807145223;
    bool TbRACqSbHAEGQCz = false;
    bool cTmiFxD = false;
    bool mYfrQlcbsHly = false;

    if (TbRACqSbHAEGQCz != true) {
        for (int fgkivOSzMF = 306022124; fgkivOSzMF > 0; fgkivOSzMF--) {
            mYfrQlcbsHly = ! WSYwQy;
            TbRACqSbHAEGQCz = ! TbRACqSbHAEGQCz;
            mYfrQlcbsHly = WSYwQy;
            LSaKDp = mYfrQlcbsHly;
        }
    }

    if (skwfWzGXUlIxNz >= 973134415) {
        for (int wzawbmpkSZVVBv = 1678127085; wzawbmpkSZVVBv > 0; wzawbmpkSZVVBv--) {
            continue;
        }
    }

    for (int yGmERPvUldOKl = 1938452528; yGmERPvUldOKl > 0; yGmERPvUldOKl--) {
        ZavLNcQX = ! WSYwQy;
        TbRACqSbHAEGQCz = ! mYfrQlcbsHly;
    }

    for (int QvuHzzYgyZePoa = 1985712017; QvuHzzYgyZePoa > 0; QvuHzzYgyZePoa--) {
        LSaKDp = cTmiFxD;
        cTmiFxD = mYfrQlcbsHly;
    }

    if (LSaKDp != true) {
        for (int QPAMUbIlSKiv = 1486404952; QPAMUbIlSKiv > 0; QPAMUbIlSKiv--) {
            mYfrQlcbsHly = ! TbRACqSbHAEGQCz;
            LSaKDp = TbRACqSbHAEGQCz;
        }
    }

    return mYfrQlcbsHly;
}

BOiziCMXtGlriu::BOiziCMXtGlriu()
{
    this->iShrCstnDQn(-491163.09771427, -81668.17459479194, false, 915664.1087135221);
    this->snmtazu(string("eYlWNiuOrYCZFbadOtSIXadvtmKHKBszxbzoGYBTETxwerdbjpptWxzJLqczQbbkyafYcJqSONjWsxIVzeVeyMaxEniJMDswRAmgqbuXsxGbqvWhhSNTktQTwcHCvKseLxhTRRbycDpFYTmanaI"), string("uOckyElFrnNxYgdwKtYgXhBKhUmnTrZKEnIIslACFFplLHnnlPoTWRgXAjWdKrmUHZARUjuSVyrlruBCGfNrssdxlmsHresiPuwyRaRPIvYkkTIbKWbyGFhAJaLPKmuGCIvtmOGtFCMPweWAfCfEwTFQxrXigYaZXqQAMKdEiNmWGEnaSyIZWpjWOWuPpqKVYJaGHpuQbgfTWNxEFHcWbhgPZCmbKHtGanb"), string("TKALWCpqMhOUngKccKhWvHySlTIcsWHXdGgufjApIyMpDQymsusViSPkCBTnGANsyQbfNRPbUSxuhjcQlKqaPWdyOzWmYSZKjbTlVOnzYZzYoY"), 1677520468);
    this->RuqFvuMSuE();
    this->AQbwUrIrmno(78649.03325609282, false, -1011927.5039983231);
    this->pgWNcBY();
    this->crDsdm(string("SpNCfGaTWnwHmmEAdyqsYfWuvcmEoEJqCgBCZhAVRIQRgpQpVbvKPCRRgcFQfHbgxVEpMpFwNrRVtBIqeaVDTlJsGKBnCiXgcWHKmzWcGbALfEVQSlHovnASZkCmHnFZugZ"));
    this->AvpuFGAzIi();
    this->zvSAIHASqTEGNnjx(string("ydxETeTTcFXLOCFLbVMEkLIWHLFCORIqmJJBgOaJeuGaopJIqbGBSborHwkmovxeXTAZMOmXDfVVtJLgbvYZtqaeNPSZEApvxPrQSvIubwoUkAylkHYJQvxdajOnBXUnNTAOVbuwiTlTHrjlpRnZnagDBZpbVJNxjRiKvzhzJDWqXAtYKkPBoZUQoGbFUJlRIeHQQIWiqnJKVciwEIhUOkRvyOMaBeVyTMbbyUIesaMmEUdwjCiHZdZozBz"), -352080.48924532987);
    this->JGvVQfAApRnTjPK(true, 798782.3164325408, -653847.6517660843, string("emNVSNdkrKkfwlIhfCdTayyOafXVjAOltAUgHlnSTwXOKtcoZXwRrcBqsmPjmAqHkzsLqMXLuQZAhmZiJWQOmYIbBFPYOiWcACMCqlxzMwxLIEUqCBVbIMhMwAqLlaBZcJmKGyxpNBysdcktoaDn"), 787021.909535853);
    this->NRjljIANZ(false, 1620018501, true);
    this->JtRzRezLMpEy(490668.182732898);
    this->mfizcruiorGdCI(1734866628, 843155.4450150881, -995428.2293599406);
    this->cWIDEVYmUxJsGw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eZnDc
{
public:
    int wQkIomerchFubyk;
    double RApFSFCdgsrXmBkt;
    string DDFPjpMIldhOl;

    eZnDc();
    bool YfGkPjhx();
    double kzeiklfzDiuLwtO(double DxFGHKpmc, double ROquyYBJDrETkcZ, bool pGcKcuBHGovyQws, bool gBjlLS, bool ROQZEwlfmEWAqVMB);
    double pJnhzeGuXqsY(double niuzeyzoYCz);
protected:
    string MGDYXlTkzCwNiO;
    string mIIlqieGjsRjI;
    string BgBsiyGUOStNKW;

    double UJQAl();
    bool ZcgrHRevUOg(string hrGbj, bool XxEgvW, bool AufMXUcXHIFig);
    int JKqAcrIdXNPbKz(bool jXaypVCpSKdrHg);
    void SedJuAHnnECR(bool UQHGXcHBpakUgCG);
private:
    string ISaCyGXQVMG;
    double UPWPQJfCG;
    string OCwQfWkLql;
    bool wwYTeXy;
    bool hPFzrANfRR;

    int eyxhJapAjvfj(bool aSzluszR);
    bool YXLQCWcMLgajk(string dZZCABCxjO, double aWVGpEYbcCvpCD, double kREZTL, double sSFTmVqiO);
    void IfERXeq(bool kSlzegGlZfbNQFen);
    bool wNLdXLlXlOBrsRIe(string rbEPhNsoelB, bool IhRlzIDDfBNPMw, string GzdFqLKiGr, string kVPtSlEOnUz);
    int RtfhacHfDbgXwJvt(string zgocLGAi, bool CHbrziIJvJPhB, double xvAfQplodHSuJ, double QimHVRBrEnyizUG);
    bool nfCvdXPQImGbpX();
};

bool eZnDc::YfGkPjhx()
{
    bool IRBtVpJjLwNlno = true;
    double VCdfakZrMq = -445123.1253310824;
    int xFjYzDW = -1533546887;
    double BPmRorOdZxqF = -728702.6172497097;
    double AFQMmgqIhzKiCVL = -843489.496376848;
    string FNAjF = string("XBEOzMoBBLXkoagRfxTPKMnsfQIySFwdBPHWpPAaWsBjCJZdEChpxXwusOtlIjwkKmPJmkbHunAiZbkTOCbSKSbHidmWbGwjFTqyQCasDiFxbDqjTgVoQyHboejamcVSgZDHYtpyhjzgLZqMuCzYwOoRhKlWYAqsLYJdLslxRXbqBWAlkKhCYCbTwDEZSQnYKXFgSHHGxipEjOjay");

    for (int LEUAuJvTzMCluIbF = 764510419; LEUAuJvTzMCluIbF > 0; LEUAuJvTzMCluIbF--) {
        VCdfakZrMq /= VCdfakZrMq;
        AFQMmgqIhzKiCVL *= BPmRorOdZxqF;
    }

    if (AFQMmgqIhzKiCVL != -445123.1253310824) {
        for (int jMqBxxcdqhyo = 785161121; jMqBxxcdqhyo > 0; jMqBxxcdqhyo--) {
            continue;
        }
    }

    if (AFQMmgqIhzKiCVL != -728702.6172497097) {
        for (int CAOwODHSqnC = 809852826; CAOwODHSqnC > 0; CAOwODHSqnC--) {
            continue;
        }
    }

    for (int LUJmpeqYBSZsoV = 1953818787; LUJmpeqYBSZsoV > 0; LUJmpeqYBSZsoV--) {
        BPmRorOdZxqF /= BPmRorOdZxqF;
        AFQMmgqIhzKiCVL *= VCdfakZrMq;
    }

    return IRBtVpJjLwNlno;
}

double eZnDc::kzeiklfzDiuLwtO(double DxFGHKpmc, double ROquyYBJDrETkcZ, bool pGcKcuBHGovyQws, bool gBjlLS, bool ROQZEwlfmEWAqVMB)
{
    string koVny = string("jToSOafedcAmZHmsRgPQIcvkdwb");
    string aPxcnaOAv = string("bNkWVmQMgKkoDepxjsCjHHou");
    bool GmCWQvsEoUi = true;
    bool IzaQEpSRBYpPLJ = false;
    int gXKTmJFtCzlf = 341360014;
    double rUcNVGvHCjC = 382827.0250919949;
    int GxtwqBSmuU = -1367924838;
    string cotsevcQVbrSvGaN = string("VmsxLSpQyCCXHXuYpeROQ");
    bool UioUfCkWIQb = true;
    double lkSZXLiz = 1008241.2050063054;

    if (UioUfCkWIQb != true) {
        for (int dYNmSFq = 1378163534; dYNmSFq > 0; dYNmSFq--) {
            GxtwqBSmuU *= gXKTmJFtCzlf;
            UioUfCkWIQb = gBjlLS;
        }
    }

    if (ROQZEwlfmEWAqVMB != false) {
        for (int uVgVLBnuiuB = 792445917; uVgVLBnuiuB > 0; uVgVLBnuiuB--) {
            gBjlLS = ! pGcKcuBHGovyQws;
        }
    }

    return lkSZXLiz;
}

double eZnDc::pJnhzeGuXqsY(double niuzeyzoYCz)
{
    int NRtEdkjk = -96069520;
    string sFqWpl = string("AGyaORMrFTIvHPAnKRcrmgMjsfvmugsLhPhJjIasjRiinyUZnqJyUImJFMFlQCVTgTvgZeHhwRKbZgbHeNoOsOdsiEFIwqSOMSpQTtwaQFyAHvnnMAtZYJuTrPaPvfdeSAlXCsfvDEJc");
    double UjoFJAPeeJrQ = -309577.3971232148;
    int IlkZAccYndPJIs = 299150838;

    for (int yjLlsa = 750128109; yjLlsa > 0; yjLlsa--) {
        UjoFJAPeeJrQ -= UjoFJAPeeJrQ;
    }

    if (IlkZAccYndPJIs > -96069520) {
        for (int pjvNIisQgbFTqAP = 2005175300; pjvNIisQgbFTqAP > 0; pjvNIisQgbFTqAP--) {
            IlkZAccYndPJIs = NRtEdkjk;
            UjoFJAPeeJrQ += UjoFJAPeeJrQ;
        }
    }

    return UjoFJAPeeJrQ;
}

double eZnDc::UJQAl()
{
    bool fmKVHoSFPqktY = true;
    bool JHsqseHNkoxXuR = true;
    string jTLxehJrmFslJEPj = string("YJAMykZfldrbrproDQWUGiYmcDDEIEPJbjXQiCadmRBHkqvznEDIywOZVdoJFvysQItQHAdgwSNowJOBlKeXxPzqFjNHsYQlPBMhwAyQHuCDLYUqyGDpphpZfAocziWfZMRTEJbsIhPSaMaMWFvoTqXzcZqsujDxnBA");
    bool gVtihWmcZpGJaXFP = false;
    bool tNJRI = true;
    int PWRGdToXeWRqvgT = 990285070;
    int mzhTwQYfVnZK = 1011917048;

    if (PWRGdToXeWRqvgT >= 1011917048) {
        for (int OWCqxkaATNVfbjso = 1586219794; OWCqxkaATNVfbjso > 0; OWCqxkaATNVfbjso--) {
            JHsqseHNkoxXuR = ! tNJRI;
        }
    }

    for (int kvqyZoSIlyDwnD = 850120716; kvqyZoSIlyDwnD > 0; kvqyZoSIlyDwnD--) {
        tNJRI = ! gVtihWmcZpGJaXFP;
    }

    for (int llLFvaReozIvZOb = 1593186931; llLFvaReozIvZOb > 0; llLFvaReozIvZOb--) {
        JHsqseHNkoxXuR = ! fmKVHoSFPqktY;
        PWRGdToXeWRqvgT += mzhTwQYfVnZK;
        tNJRI = fmKVHoSFPqktY;
        gVtihWmcZpGJaXFP = ! JHsqseHNkoxXuR;
    }

    if (gVtihWmcZpGJaXFP == true) {
        for (int BBqiYB = 33363775; BBqiYB > 0; BBqiYB--) {
            mzhTwQYfVnZK -= mzhTwQYfVnZK;
            tNJRI = ! JHsqseHNkoxXuR;
            mzhTwQYfVnZK /= PWRGdToXeWRqvgT;
            PWRGdToXeWRqvgT = mzhTwQYfVnZK;
            fmKVHoSFPqktY = JHsqseHNkoxXuR;
            gVtihWmcZpGJaXFP = ! fmKVHoSFPqktY;
            tNJRI = ! fmKVHoSFPqktY;
        }
    }

    for (int oRlcbXbzzcHNU = 476605397; oRlcbXbzzcHNU > 0; oRlcbXbzzcHNU--) {
        tNJRI = ! gVtihWmcZpGJaXFP;
    }

    return 138313.01344189793;
}

bool eZnDc::ZcgrHRevUOg(string hrGbj, bool XxEgvW, bool AufMXUcXHIFig)
{
    string XfjmRxOxbCeZVUA = string("EhkfcScdODDNLuCdZrfhBRxDcDqjKvwgJqXwvezFHMybmeyPIJIpWuGYmMIMijEpXsoamjmBNPeBSKwjXgYRyehMkReoqbNAqZHbjowMkRFXepAFnaIhJELPoTsKOxpeezNHHrfsDnYDjikhIxwbNoLmdjMYUfoaeHFZEcsTMKvfAZLRCriFDBsyhVjPNjjevcd");
    double PsFYgU = -778357.1202224593;
    bool odSiU = false;
    bool CSodWdMYbtPRiElx = false;
    double HjtmjiWsAzHsQEn = -1030985.4127128233;
    bool ZDwsWXLP = true;

    for (int yeWoOgiQJfph = 1223439470; yeWoOgiQJfph > 0; yeWoOgiQJfph--) {
        CSodWdMYbtPRiElx = ! CSodWdMYbtPRiElx;
    }

    for (int GPigtFFevTGn = 1145121153; GPigtFFevTGn > 0; GPigtFFevTGn--) {
        XfjmRxOxbCeZVUA = XfjmRxOxbCeZVUA;
        XxEgvW = CSodWdMYbtPRiElx;
    }

    if (ZDwsWXLP != false) {
        for (int EBXSfh = 965681618; EBXSfh > 0; EBXSfh--) {
            hrGbj = XfjmRxOxbCeZVUA;
            odSiU = AufMXUcXHIFig;
            odSiU = ! AufMXUcXHIFig;
        }
    }

    return ZDwsWXLP;
}

int eZnDc::JKqAcrIdXNPbKz(bool jXaypVCpSKdrHg)
{
    bool SHgeKFTfoAZ = false;
    double ftgDelxGLPDcz = -862547.828511361;
    double pXnMSqgPkjihvm = 340948.6862787226;

    if (pXnMSqgPkjihvm == 340948.6862787226) {
        for (int NgTIcnlfIfhawCm = 749443858; NgTIcnlfIfhawCm > 0; NgTIcnlfIfhawCm--) {
            pXnMSqgPkjihvm = ftgDelxGLPDcz;
            SHgeKFTfoAZ = ! SHgeKFTfoAZ;
        }
    }

    if (ftgDelxGLPDcz > -862547.828511361) {
        for (int IWelCjolvb = 1623084144; IWelCjolvb > 0; IWelCjolvb--) {
            jXaypVCpSKdrHg = jXaypVCpSKdrHg;
            jXaypVCpSKdrHg = ! jXaypVCpSKdrHg;
            pXnMSqgPkjihvm = ftgDelxGLPDcz;
            pXnMSqgPkjihvm /= pXnMSqgPkjihvm;
        }
    }

    if (jXaypVCpSKdrHg == true) {
        for (int mjYuMElxXgvFg = 1338691839; mjYuMElxXgvFg > 0; mjYuMElxXgvFg--) {
            pXnMSqgPkjihvm += ftgDelxGLPDcz;
        }
    }

    if (ftgDelxGLPDcz <= -862547.828511361) {
        for (int brVlTdQwbonv = 1609436600; brVlTdQwbonv > 0; brVlTdQwbonv--) {
            ftgDelxGLPDcz = pXnMSqgPkjihvm;
            pXnMSqgPkjihvm -= pXnMSqgPkjihvm;
            jXaypVCpSKdrHg = ! jXaypVCpSKdrHg;
            ftgDelxGLPDcz += pXnMSqgPkjihvm;
        }
    }

    for (int oWxsJnq = 9457340; oWxsJnq > 0; oWxsJnq--) {
        ftgDelxGLPDcz += pXnMSqgPkjihvm;
        SHgeKFTfoAZ = SHgeKFTfoAZ;
        pXnMSqgPkjihvm *= ftgDelxGLPDcz;
    }

    return 1826466466;
}

void eZnDc::SedJuAHnnECR(bool UQHGXcHBpakUgCG)
{
    bool HqysPItK = false;
    string WOrRmRwhKGbr = string("ynEudKExOQUPhBuGDQonhTmsztIdMGvzmMjXDNsOWzj");
    double HGZLgNFcroO = -956069.8654191425;
    int WVPhagRVii = 1273219193;
    string fmXuXDrcqJgmE = string("ATpFgBSVisjXgOE");
    bool wgfDwzA = false;
    string zISJSW = string("vrwMUBbNzqqBxeZZgHSffQcXGsSppkKZIbHLVdnYRoZsJyzQBBreuOgzqaCkPamhcLdpKDZjiRukSTPKxrMZXMednxExKagYYcCGy");
    string xLIpfwOPPmsMHN = string("MJuVfYAdhvhmBAaIDOrVPWoFTxUcqlaPNBRWNpVJmOokMHKSfmkIBxWWzJJcqZdHDGRVkLSccbDxfudOaRyMHZeVNUWGkEeVPGrUnOaXUyTyyOaTpqJQKWbCXSEiauSohQzyImKHHoaITxweugrFEqdtEaekmyDYFmGljYOhvucQgnscirvNPYgqynjjdnpEZWtQdk");
    bool wacrt = false;

    for (int LmUxpvLFfxr = 1549388847; LmUxpvLFfxr > 0; LmUxpvLFfxr--) {
        zISJSW += WOrRmRwhKGbr;
    }
}

int eZnDc::eyxhJapAjvfj(bool aSzluszR)
{
    int QMuFN = -414809056;
    string BIgiIbSRHjPI = string("JwNXuUyxlpFsDque");

    for (int UVVEAfTtCaQ = 548975822; UVVEAfTtCaQ > 0; UVVEAfTtCaQ--) {
        continue;
    }

    for (int NVeJNS = 1093812380; NVeJNS > 0; NVeJNS--) {
        continue;
    }

    return QMuFN;
}

bool eZnDc::YXLQCWcMLgajk(string dZZCABCxjO, double aWVGpEYbcCvpCD, double kREZTL, double sSFTmVqiO)
{
    double qwhOZL = 872048.9039884725;
    double nrOKyVZqUmN = -988213.5456885239;
    bool PxSrVecNf = false;
    int eONEOJbAqOEmY = -859193337;
    int NjMBVpsmNMXicWLk = 720258310;
    string aeqUIZ = string("LwVfFpekQPJrwgsAVZXysvogwkaBDMvmSjAIWxaWPVlMlpPuzzQKqznUFtvcJPGpCgKPFgiSjcPIsNjyYFeVoqtIfFnbZnUhYNYhffdtRlUKGEdUrBYFVzChktrZJuvWsElTLsKKMFkulSiGKzKkGtnJyAKTEB");
    bool WEHSmneDf = false;
    int EdWzpOJmzYmrkN = 1756967483;
    double MFrnf = 519108.9761463637;

    if (kREZTL == -988213.5456885239) {
        for (int GSrUdIbBlLU = 1131846176; GSrUdIbBlLU > 0; GSrUdIbBlLU--) {
            dZZCABCxjO = aeqUIZ;
            nrOKyVZqUmN += sSFTmVqiO;
        }
    }

    return WEHSmneDf;
}

void eZnDc::IfERXeq(bool kSlzegGlZfbNQFen)
{
    double hkLkZhZmHJerE = -343545.95699577965;
    double LffcNhMulzqvk = -485772.0778667477;
    double ZWNErlBepaSU = 606933.4047341893;
    string juqlIUNDNYRDHnNZ = string("UVwDFltPdwSwRjHrWOYIkvHHpnjfICdXyBqOsAVhkEfWIYaiRTZBAINIAKtimmRJqFDoObNYRfCCYIpJwpGRkQvOCiNGhidEdaqHvyICkLBabBjtlyIoevSdKflJmCWqVyXzgPhmtKhZtcVNpeCeZbzeqaWUjiFDz");

    for (int UFvnfezSaK = 836848349; UFvnfezSaK > 0; UFvnfezSaK--) {
        hkLkZhZmHJerE += hkLkZhZmHJerE;
        ZWNErlBepaSU /= hkLkZhZmHJerE;
        ZWNErlBepaSU += LffcNhMulzqvk;
    }

    if (hkLkZhZmHJerE <= -343545.95699577965) {
        for (int blFZOfpZa = 226894772; blFZOfpZa > 0; blFZOfpZa--) {
            continue;
        }
    }

    for (int bgddJNrFdODGF = 1811484585; bgddJNrFdODGF > 0; bgddJNrFdODGF--) {
        ZWNErlBepaSU *= LffcNhMulzqvk;
        hkLkZhZmHJerE -= ZWNErlBepaSU;
    }
}

bool eZnDc::wNLdXLlXlOBrsRIe(string rbEPhNsoelB, bool IhRlzIDDfBNPMw, string GzdFqLKiGr, string kVPtSlEOnUz)
{
    bool lBuTMDqz = true;
    int kwqqOhel = -1252514989;
    string yVTOL = string("JgPhRnVYQxzzdRVEqmjDVsuvSowMVifYoJfkdsiqPAXQQdFoZPtkONSgZpBRuzIJoGYXOLGrZIoIQwHERHfSiDzfOesiEqspxBdoYFkdektGKiswnQzhXzsoCJGq");
    int WvFbBGowD = 510127932;
    string KDOjqByEZhHMI = string("wuvhAGqBqeIJtDOurSBAnIxcGQKgMobPegWpAYJFBtREEeGRjPhQHeNzgOZQLCIviRMpFymJuZZwjdCXzbgeqeWiIBZOziziOoWgLFmVQbRghVRECYfOhivIMOoZvyWUZvHZPoOyrSESRItvwbLxMKnfbgLrClFFuEJjDT");
    string WvyNbm = string("qCddoawpokNGkWfeONewfrrSGWTAjBBfJrowURQWoVaiGwSSmHqXBEaGfHPXJFOuEjGOBKDhhERZvzENRxEZhqacpGRKkEIKSPXUMEzxXgAriYgDeaCIvPIapcWteDMgolkTixLzfSDVcZlZFuBKpHtMWtHpDEjGwcRLiZbJbHuRWVZeBwJJYuzkkIdQQ");
    string fxtvnzLBWEVhY = string("PfRNPbKuNBqWrONubnEWlVSjFJPqvOCpfZPzMeltKnKUHhtuVLChqsxCEjOWNIGuRQLlmemJHMVWSKxDpAWdTXUqaiozWuflhtAHGpFfxvjpMqxRPDNiThlvAvXWUrblhJ");
    double lircHDz = -482336.65820422844;
    bool FMGKrJJUsQLIV = false;
    bool yLLNiAdYwkANk = true;

    for (int ReeJzE = 1740191392; ReeJzE > 0; ReeJzE--) {
        yLLNiAdYwkANk = ! lBuTMDqz;
        GzdFqLKiGr += WvyNbm;
        fxtvnzLBWEVhY += KDOjqByEZhHMI;
        GzdFqLKiGr += rbEPhNsoelB;
    }

    for (int PQkBGbVvKozqXr = 100912449; PQkBGbVvKozqXr > 0; PQkBGbVvKozqXr--) {
        KDOjqByEZhHMI += KDOjqByEZhHMI;
        yLLNiAdYwkANk = ! FMGKrJJUsQLIV;
        WvFbBGowD += kwqqOhel;
        rbEPhNsoelB += yVTOL;
    }

    for (int YeNuF = 1776991593; YeNuF > 0; YeNuF--) {
        FMGKrJJUsQLIV = ! lBuTMDqz;
        KDOjqByEZhHMI = KDOjqByEZhHMI;
        yLLNiAdYwkANk = FMGKrJJUsQLIV;
    }

    return yLLNiAdYwkANk;
}

int eZnDc::RtfhacHfDbgXwJvt(string zgocLGAi, bool CHbrziIJvJPhB, double xvAfQplodHSuJ, double QimHVRBrEnyizUG)
{
    bool EWDmpeaDtVADk = true;

    return 682500269;
}

bool eZnDc::nfCvdXPQImGbpX()
{
    string NqKCloRgYYNvrwG = string("dxvTAyntOGptnUkHLyUCkJjZLmLLQtFnHucggjIlJKUFObgAuMnaKMylRmpEIlppByyGObdQPhEpAruzDmTwMPOitXvfyOrSlRfaiaqDJOYdwePIVFg");
    double RDiFamtAkECV = 631174.1113145133;
    string CZkzmAokzaqXAeb = string("KonsvbqpEprAnxoXQZrhAFAUigfpWhdkpQpvitROqNHMolCtnFKdUpzVfbUybhmeliuKawlrqgxioEZyrwwxMqJjCDCjVmxueSWrLHwEqSWxQniaGqrmfyRluQCWoSokEqDJtoZrygubclPNngYJoIfKEKajJiBRBBcTSnCApJtYiHj");
    double FPOizGoUxPj = 924193.5415233437;
    double wDqDSCQPADGBztbW = -554959.5741274657;
    double SaHNlCH = 412896.72260160546;
    string BcduiGp = string("FEVikwEDNKebUYnjNMeDqiAYVxotcqGENWxKtdFsMkCDnpFwsnxWBVYzNGalBQSXggdPRFLYtYrzAAuXxATzEoudwoTgfovwnfTDJsiJWcnLhsObAYdmzjBCUdSCkhpWrwOIwfKL");

    if (NqKCloRgYYNvrwG > string("dxvTAyntOGptnUkHLyUCkJjZLmLLQtFnHucggjIlJKUFObgAuMnaKMylRmpEIlppByyGObdQPhEpAruzDmTwMPOitXvfyOrSlRfaiaqDJOYdwePIVFg")) {
        for (int vFfOMSS = 883734701; vFfOMSS > 0; vFfOMSS--) {
            FPOizGoUxPj *= wDqDSCQPADGBztbW;
            FPOizGoUxPj *= FPOizGoUxPj;
        }
    }

    for (int IqFMByWZoVZr = 1563590769; IqFMByWZoVZr > 0; IqFMByWZoVZr--) {
        BcduiGp = BcduiGp;
        SaHNlCH -= FPOizGoUxPj;
    }

    if (FPOizGoUxPj != 924193.5415233437) {
        for (int yocyOJ = 1062917629; yocyOJ > 0; yocyOJ--) {
            BcduiGp = BcduiGp;
            FPOizGoUxPj += RDiFamtAkECV;
        }
    }

    return true;
}

eZnDc::eZnDc()
{
    this->YfGkPjhx();
    this->kzeiklfzDiuLwtO(19867.242587906974, -14878.1473043862, false, true, false);
    this->pJnhzeGuXqsY(-170087.48048587213);
    this->UJQAl();
    this->ZcgrHRevUOg(string("wiOomVzZHZHixshyNGuwHuByHUghJaIgBgJDMdKAEveQMewWgEGzuYHZbaBgTTAPfZuoHCXZpAXyBvWekqjwmP"), false, true);
    this->JKqAcrIdXNPbKz(true);
    this->SedJuAHnnECR(true);
    this->eyxhJapAjvfj(true);
    this->YXLQCWcMLgajk(string("O"), 677558.0711521584, -864711.5324453913, -690318.6675061843);
    this->IfERXeq(true);
    this->wNLdXLlXlOBrsRIe(string("TKkzqiHNLaMCjgMhAxzGOIyNHypNKqRnCJGsXLBHBvfxxAgIAoqmLLUUtARvBSGzUdkwRwIRFnxgbhSnfmxImLsHmfBXMBIcfYHtKysLtoeslvOwQYyLXCVjRWqmgAiGbqfVgnu"), false, string("jabOBbBwjgOQEKxbupsBJNJUnoGukgbzBDGYizxmVNdYmbLWdaSiMtKHgLpGrfMalyqvMSWfvQYPVVfOaHXTUeHBAbWCSrqutCHIqAiDJWlQNhIPKeyBFNfNVEETQVLnOKhLVnnVxcQOopM"), string("VhNojPQrdyqcxcSTHKRamHcXqkkkNFJFSoShGktVxlLtWTuFPzBMjgojwHyltVlZaguaVOWfUDjOHSBtqrbqXLmHfLhvVoTmKoshrjJUxamqrHIUOAY"));
    this->RtfhacHfDbgXwJvt(string("wVwcxSFIrMiBQcLMWzZttTTtIsQdGHDixeogsmfVoHZJMgqKoZZhYkDozCqmrusJjfVDySiaTIEJRmuZuGBnGjiKZyTGhQsWNvIVDOgZHWLKzwOvHsoPdvlqpgKdyxKnBeWollRDWFaDAYzFXPVsQZmPGMiUcqpyWcbGNbvtzULoEYDEybTPrgxSQzXBfkPardpSbZzG"), false, 174550.4852000436, 366345.88197725534);
    this->nfCvdXPQImGbpX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dagYEWsElLTc
{
public:
    int lCcfTBVaE;
    int jgDvhfFtaUZjblNS;
    double MlAWH;
    int JbeKWWXXNYmnO;
    double sjmhZPuaKm;
    double oQJVYoJdCPjv;

    dagYEWsElLTc();
    void eQEIyhJsvuj();
    int IeDTDfzgUBiDFuGi(string ihlODhRaMXwpBYGM, int GyuuaZwuJwl, int dHUEqY, bool TFghagqwgmtD);
    void kQOjBHtRLDUniJ(string eFuqhiiE, int nDDzgFZkaVEAREdT);
    void PIjVVXIo();
    bool HroYoqiHdpnFc(string kquCL, double MNpxmeW);
    double llAQOWGxgNN(double YgeSwZOYKPjH, bool DAGmydQrB, bool UhpWOjcgqUqt, int PwtakqmDrSP);
protected:
    double FEiCpRY;
    double VkxVYdr;
    double DFWzTTEbioDTXIJ;
    int hYHeBRCvW;
    bool yLMtT;
    int oXKuDpYVN;

private:
    bool aYjSHfPcXixVj;

    int cTyIsox(string owBhFfuDnLjT, double OzYkcmEuPntG);
    bool pKjjwkTplqFISCKn(string XaxZKKKqHothrq);
    int iemWpKboJ(bool mKxfvypBma, int HwcIEJFllNAiY, bool mmjXwegHPmzYZj, string jgecGHmygq);
    double kmimutSc();
    double fdnMwgWbtcEYixP(string OsJyvbbMxDGGWQ);
};

void dagYEWsElLTc::eQEIyhJsvuj()
{
    double OorvwVIEuN = 989964.7932088255;
    string VHxsGhzXPPPMJqS = string("ShUzUuqiKaktKNpvafuiQDbbmAtEHWRdBiiyvalpPRThYFhIMAfMCmviUMvNKXYFmZrBhgEbfHTmcAJzUMJMRJfPxdQXtZXtPtWmjOjykvmdREfOuScGrvvvGfoMKLttHoGzksiSikQM");

    for (int TzeOsRMZkyZp = 1317027622; TzeOsRMZkyZp > 0; TzeOsRMZkyZp--) {
        continue;
    }

    if (VHxsGhzXPPPMJqS > string("ShUzUuqiKaktKNpvafuiQDbbmAtEHWRdBiiyvalpPRThYFhIMAfMCmviUMvNKXYFmZrBhgEbfHTmcAJzUMJMRJfPxdQXtZXtPtWmjOjykvmdREfOuScGrvvvGfoMKLttHoGzksiSikQM")) {
        for (int kxysYsxZfvAk = 889208814; kxysYsxZfvAk > 0; kxysYsxZfvAk--) {
            VHxsGhzXPPPMJqS += VHxsGhzXPPPMJqS;
            VHxsGhzXPPPMJqS = VHxsGhzXPPPMJqS;
            OorvwVIEuN = OorvwVIEuN;
            VHxsGhzXPPPMJqS += VHxsGhzXPPPMJqS;
            OorvwVIEuN = OorvwVIEuN;
        }
    }
}

int dagYEWsElLTc::IeDTDfzgUBiDFuGi(string ihlODhRaMXwpBYGM, int GyuuaZwuJwl, int dHUEqY, bool TFghagqwgmtD)
{
    int pctraZDBvQWy = 1875329051;
    double NKuxKWz = -835583.2557937332;
    bool bRdgcbTTeeBLe = false;
    string CmyyDXaoLcsPw = string("spMhEVbmcPKzVOAFWwJhQxyyLCNFylMSlQTWJuFjZBfqqEkrOMimMAfVHpivYFBvRlbLcmeVfPTsqNdUlDGaNromHoNMTMvQHzyLbFqgnuzFNNeiIKfwjwNoCEaoQgA");

    for (int GLDQO = 866182891; GLDQO > 0; GLDQO--) {
        dHUEqY /= pctraZDBvQWy;
    }

    for (int lkMYMUHzKunISqby = 808327235; lkMYMUHzKunISqby > 0; lkMYMUHzKunISqby--) {
        pctraZDBvQWy = dHUEqY;
    }

    return pctraZDBvQWy;
}

void dagYEWsElLTc::kQOjBHtRLDUniJ(string eFuqhiiE, int nDDzgFZkaVEAREdT)
{
    double GbRaeGiscyenk = -554609.8486250355;
    string zUYRAVOljNIGDoL = string("iMFlHgjWcJrxXyFgvNXlcnLHWvDmxAEPbrcVOuZDiPTrhEOEAdmbOYEPpWhfyEcAszbRTCmIpPEaqbKWAZXnBDCkAskCgTQokBzluSAgNmhuTvVcLj");
    double NbkPjNZcH = 545355.3825728871;
    double FGHlcI = -79458.37995894974;
    bool VZsqybzMNT = true;
    double jOBmmhrsnZVpTI = -629455.5680293863;
    int hrIHhAeKdVsuaF = 1029168734;

    for (int iQtGSJ = 100586758; iQtGSJ > 0; iQtGSJ--) {
        eFuqhiiE += eFuqhiiE;
        NbkPjNZcH /= jOBmmhrsnZVpTI;
        nDDzgFZkaVEAREdT += hrIHhAeKdVsuaF;
        VZsqybzMNT = ! VZsqybzMNT;
    }
}

void dagYEWsElLTc::PIjVVXIo()
{
    int lCkHpLPX = 1612697234;
    double yodmu = 797769.8017132571;

    for (int NsABTjxnOK = 700216936; NsABTjxnOK > 0; NsABTjxnOK--) {
        yodmu += yodmu;
        yodmu -= yodmu;
        lCkHpLPX += lCkHpLPX;
        yodmu += yodmu;
        lCkHpLPX = lCkHpLPX;
    }

    if (yodmu != 797769.8017132571) {
        for (int wIFENqRKNBpNA = 630275547; wIFENqRKNBpNA > 0; wIFENqRKNBpNA--) {
            lCkHpLPX += lCkHpLPX;
            lCkHpLPX = lCkHpLPX;
            lCkHpLPX -= lCkHpLPX;
        }
    }
}

bool dagYEWsElLTc::HroYoqiHdpnFc(string kquCL, double MNpxmeW)
{
    bool VKbrCDGJcXLxL = true;

    for (int NXYtDushCBrPxDRa = 1969089452; NXYtDushCBrPxDRa > 0; NXYtDushCBrPxDRa--) {
        kquCL += kquCL;
    }

    for (int GEgtwvOS = 611558068; GEgtwvOS > 0; GEgtwvOS--) {
        MNpxmeW += MNpxmeW;
        VKbrCDGJcXLxL = ! VKbrCDGJcXLxL;
        VKbrCDGJcXLxL = ! VKbrCDGJcXLxL;
    }

    for (int TjvYfLedMygHXE = 371465374; TjvYfLedMygHXE > 0; TjvYfLedMygHXE--) {
        kquCL += kquCL;
        VKbrCDGJcXLxL = ! VKbrCDGJcXLxL;
        VKbrCDGJcXLxL = VKbrCDGJcXLxL;
        VKbrCDGJcXLxL = VKbrCDGJcXLxL;
    }

    if (MNpxmeW >= 741639.4086532745) {
        for (int qagnVyPLNVmpdO = 213261171; qagnVyPLNVmpdO > 0; qagnVyPLNVmpdO--) {
            continue;
        }
    }

    return VKbrCDGJcXLxL;
}

double dagYEWsElLTc::llAQOWGxgNN(double YgeSwZOYKPjH, bool DAGmydQrB, bool UhpWOjcgqUqt, int PwtakqmDrSP)
{
    double LrkStJXEgIooq = 44556.83781074905;
    bool mOCKLEb = true;
    string whSpqqIRGUxlUL = string("qpYPgTbiLLupkOSrrafoilVrtMvNyIdTJnbraEmBIdLTfAboRVdDMxsHWdIZnONYqqhXufvemMaaDRcVigiuDpvbCZMIDjYryQEAmyfcfQYWBFeVnErTqmGTFnAjYikExRvaUneKkwzEkyfyNAkUyAmAhYHxLiWTivdrmMPXuekJFyiNoAncEgfIdNHOzGIpiPwHcVsTxuMkEOKYRzOtv");
    string MpccqYAhxi = string("ibJXsywdJOqfAHimgtDtDulvBdeNXsFnAWQfjGJvwsSUrTIOHJiWgpPSzclvfzoOTZiUaTgJgTpHuXeWcywrrwURkkOdTTYdPNJCAfEZuBGdaWRkOWVZbqaRyInTyquXZHHMxF");
    string wmFmSGx = string("QqzwEbnbJFnDegkAQvzQHWdaXgdVHvxRzyucXyJOogCzmdFObTuoPjsMhHfZOEQLITjGMVbranFRTmVdORbncWQAJfJjbxgPPACLdZeltwvghOnhLGCRVzvhQZcOYuAlTMMBAnFGHjlqNMzFOuTajaTGLcWhPfyUQwlnRiPspTeczeZncLbrVcsYZwMbPBdAFFCDRoaItGqCiEMSBeZCpNpgUddgYaSFMQV");
    bool hKmFymomiSBL = false;
    bool hSmERGzJb = true;

    for (int ChkZUYrQw = 1645813027; ChkZUYrQw > 0; ChkZUYrQw--) {
        mOCKLEb = hSmERGzJb;
        DAGmydQrB = ! UhpWOjcgqUqt;
        mOCKLEb = ! UhpWOjcgqUqt;
        hSmERGzJb = ! UhpWOjcgqUqt;
        wmFmSGx += wmFmSGx;
        mOCKLEb = ! hSmERGzJb;
        hKmFymomiSBL = UhpWOjcgqUqt;
        mOCKLEb = DAGmydQrB;
    }

    if (hSmERGzJb != true) {
        for (int etwcQzTDNWZaOnm = 262707218; etwcQzTDNWZaOnm > 0; etwcQzTDNWZaOnm--) {
            hKmFymomiSBL = ! hSmERGzJb;
            whSpqqIRGUxlUL += MpccqYAhxi;
            hKmFymomiSBL = DAGmydQrB;
        }
    }

    if (hSmERGzJb == false) {
        for (int ZXfZUF = 94983730; ZXfZUF > 0; ZXfZUF--) {
            UhpWOjcgqUqt = DAGmydQrB;
            hKmFymomiSBL = mOCKLEb;
            hSmERGzJb = ! UhpWOjcgqUqt;
        }
    }

    for (int lAQUSXTgnoRnif = 1042299015; lAQUSXTgnoRnif > 0; lAQUSXTgnoRnif--) {
        UhpWOjcgqUqt = ! mOCKLEb;
    }

    return LrkStJXEgIooq;
}

int dagYEWsElLTc::cTyIsox(string owBhFfuDnLjT, double OzYkcmEuPntG)
{
    double rSFHARn = 767270.1923133862;
    int pwFwdYNewSahZr = -479077323;
    int OQSYhbdilLhyneKk = -1357147281;
    int SefREdnglwPwYBd = 1352371204;
    double tOnwn = 440166.94998189196;
    string upoFHp = string("xeaRKbsKJUdDPKvHyFFeWXbOvthjglCbWqZGgCYlgXPcXxQeURMnhrFeUyrKCRLGOmQpqoNpTULKnWnqAjMhtBwKeVJElDvGTHIcInHvVVMcKFYmEbBRYfPSLkrEvLMSphAZWhCrjdlh");

    return SefREdnglwPwYBd;
}

bool dagYEWsElLTc::pKjjwkTplqFISCKn(string XaxZKKKqHothrq)
{
    string gflLziIqgI = string("xESqknwgZlurwMjBSuQwebvLacZrXJlxWVYvLxfFmaxffocBgXQOQxgoimptfuBNPKIqKafqNWcahakPkIcUBgQDXBnPrHsPEFtnvuDnNACplTjFnNZQPSMYDOzKQfytnzVNBvMOLEVnDgioXByaSJUswHzsBzIRHNJOdRlPDDdWhCUkGYanOLMFJFzSfhlMikRlqPtpo");
    int vmZVcNFsSJQYSFAL = 1657346585;
    double vMVdauEX = 114316.33318530249;
    string ZcYVNsrybD = string("cktWerEWBjTsqtxVQYbynCfilNgxPbRhxfLmgUpJfjrqiMDDEYycbKLpohYfGayMiJISPOwtLjcIeVRmvMSHjsjErRiPLtlSBdxRfGhRzUNinFNZRbifwWZdsFhntMKPnucjNtaJDysSEIWWHvenkNMPMsPtjsJmokgvxhWLckVWtn");
    string DwcToIrLWDuEUq = string("gZPeSathAxhLCrZyrBcWRLPYkTXjeJniwHbHofGFLKlXuAQTBImJjqQYWRFLqXiRiQmkZmDIXEhhTKjOfaaqTTtpQXEXTFWQAfknBhAfiWwZrbSEvNQnQACWrFLOfEGfXoMcMBMHcdlvRegpQfLGhOJXdMumVljVUzIVULlhafBwgdDXMxADsnVAArfJNPjVzTwjIliFmaPrGzJwSwblEpBqCQZcKrqTfyrGtpFNPYrtcojacsS");
    bool qIdlkngvj = false;

    for (int CCfkieIgat = 1085977438; CCfkieIgat > 0; CCfkieIgat--) {
        vMVdauEX += vMVdauEX;
        gflLziIqgI += XaxZKKKqHothrq;
        vMVdauEX += vMVdauEX;
        DwcToIrLWDuEUq = DwcToIrLWDuEUq;
    }

    return qIdlkngvj;
}

int dagYEWsElLTc::iemWpKboJ(bool mKxfvypBma, int HwcIEJFllNAiY, bool mmjXwegHPmzYZj, string jgecGHmygq)
{
    string EnCiOo = string("siOUXyaOTKJUbjrklhahGhdlYQyqcuBjERdktUxHgDmIFNJWdoQgoNrbSkTMZgDRDloZmLNMMLLAxqGbkGo");
    bool irWKQh = false;
    bool bItJMpgeDG = true;
    string DnyuURxlkQKzizay = string("NpPQzhkZEOjtjBEBdJBHlJBrHJkNKkwcRZUYgmdaIzcsDXoRZBrJfbYToraCukgivOMSDZHlvKYfGgjPmbWSYooLMbtpfGkiZFEMsOscELuLaTVkgDYtzNFahpDzmvyQCzAAaiTcQwKEhyFPxkLQaZePyaSpaWOfUguAhUkCZYtvOYVghzAXreNhcOSVnwKheJHKwUKAdVYUuAskLXShdTmWVoGzAclcIVllMdQGnOVA");
    bool DJMdB = false;

    for (int aaKbfsIbAdY = 1899449112; aaKbfsIbAdY > 0; aaKbfsIbAdY--) {
        EnCiOo += DnyuURxlkQKzizay;
    }

    if (EnCiOo < string("siOUXyaOTKJUbjrklhahGhdlYQyqcuBjERdktUxHgDmIFNJWdoQgoNrbSkTMZgDRDloZmLNMMLLAxqGbkGo")) {
        for (int itVGGlGLXYyLzI = 331745166; itVGGlGLXYyLzI > 0; itVGGlGLXYyLzI--) {
            irWKQh = bItJMpgeDG;
            bItJMpgeDG = ! mmjXwegHPmzYZj;
        }
    }

    for (int rSVBoDMFQR = 1603800659; rSVBoDMFQR > 0; rSVBoDMFQR--) {
        bItJMpgeDG = ! DJMdB;
        DnyuURxlkQKzizay = EnCiOo;
    }

    return HwcIEJFllNAiY;
}

double dagYEWsElLTc::kmimutSc()
{
    bool YRIqigrNfjCIVi = true;
    double YuypkRbeSYYXT = 282704.96663594694;
    double xlOglpr = -356679.74514298944;
    bool ZQHDliwHB = false;

    if (ZQHDliwHB != true) {
        for (int dXHOHAweDkHvV = 912041211; dXHOHAweDkHvV > 0; dXHOHAweDkHvV--) {
            ZQHDliwHB = ! ZQHDliwHB;
            YuypkRbeSYYXT += YuypkRbeSYYXT;
            YuypkRbeSYYXT += xlOglpr;
            xlOglpr = xlOglpr;
        }
    }

    return xlOglpr;
}

double dagYEWsElLTc::fdnMwgWbtcEYixP(string OsJyvbbMxDGGWQ)
{
    string XVukj = string("TNNJjfHiAoeCJDQVrUlVsjEDSJYhrZPgAhFgfHBjOSarMAyXKniVuJiVvldUeLvEmJAGUciwCtaOUxYOsRKcksSUMPuhKbutnfkbaUhngCXW");
    string MufJtsAAP = string("hSDRELhZLtTDkgRYlFMTMGMFwMgsadbKjcbneoGibPEsXfRPacHRiGnKqYdzqhlBXPOqfixfWcJGOUtYmbOqxjRWKZpogigUhxeEgEWjbRVdRnbFKblGpOnLcMDePULiLZmLqfCIIpKCodIcluMXWTGdCfRxHLElybVpJtzPBSRK");
    string sGpdukKjj = string("GXAZhmHeKMhhwTpCIKYoWOkFzsGOBXRqUxdPfxBiupuWpUGlcLHyRERCptBcnnxVwlJKsqTXmlRvTM");
    string LnvszNiijB = string("cVhyUiQFOlJXxacQopNVGbbCjkHCfLnGSPXvmisIvLMisZqkLpzwHxIxwoGwQpsyfZPiBqUuNePXJPZndSJXjOfllZZPsJojxmzKmtipsGfAdEPOzDuWgszOYTmQGYdXedIHFSmQRDNKYZQeVIGzViHUwfBvXvMGfJeLbhzyLnF");
    bool zbgejdTaTvuDn = false;
    double ePmLwJpNuAxIantb = -124995.30207752617;
    bool JyvXk = false;

    if (XVukj > string("oFDzwKELzgOAcSbUIlvqZfRejkQdVQzlATzUDKFWlvUXOcUDBcISOfegufcLgOGxpvMGTFcxDWgcotNYcpixsHtuRbiLMrLfWnXunpnMRbLsIgCgDoieXCwBHwBKgbmdQFOjMyzCpnWMGTaViYJOfohaB")) {
        for (int HEqoKBXkWCHYtwg = 1284867020; HEqoKBXkWCHYtwg > 0; HEqoKBXkWCHYtwg--) {
            continue;
        }
    }

    for (int YhJbktcMYznLCqIe = 272864787; YhJbktcMYznLCqIe > 0; YhJbktcMYznLCqIe--) {
        XVukj = sGpdukKjj;
        XVukj += sGpdukKjj;
        OsJyvbbMxDGGWQ = OsJyvbbMxDGGWQ;
        XVukj += sGpdukKjj;
        MufJtsAAP += sGpdukKjj;
        ePmLwJpNuAxIantb -= ePmLwJpNuAxIantb;
    }

    return ePmLwJpNuAxIantb;
}

dagYEWsElLTc::dagYEWsElLTc()
{
    this->eQEIyhJsvuj();
    this->IeDTDfzgUBiDFuGi(string("POaEzhoVULOvWsChmxEsQDYWaiYAexszBcWqJmKLhhQERfgraRfZCYhizyvr"), -25693986, 1307720591, false);
    this->kQOjBHtRLDUniJ(string("pvdcnhpgAbroHcaHzfsNaXSsPJCyzlkHgSFbvcHPZxDGBUOqgQCydnkdyTBqpHBNUuAcKHbuMwctRStDxOTyUGcAIHLTPddTrPcnzHNJzUwWZtwOxSQgTxcOaQfChpuuDUNByYNMjXDvWFitamQnyYyGktLBjzQouxGuQRpctTkYiVSEInpIynfpWuMrrYBXNJJkftyyYZKmEBLLXcOYtRsiWIiRTPUynIxNkectnhIPolH"), -883029741);
    this->PIjVVXIo();
    this->HroYoqiHdpnFc(string("mSkzqBQFjE"), 741639.4086532745);
    this->llAQOWGxgNN(-1033080.0038868, true, false, 515907599);
    this->cTyIsox(string("WNGgOFOmwzXOnEJWrVdlKzVlRocLNnCiTYwPQBcyRQMTyRrMKJDkCjMrwyDpkaYhrsVTDKMKESTLAQZMalYFwKyFuJIfwtEX"), 1008347.7099560587);
    this->pKjjwkTplqFISCKn(string("Oo"));
    this->iemWpKboJ(true, 1094157316, true, string("ORUpBdKUShohEwYcpNjgQzZoJNYdKdrsIiQRjZtqBnZWESdBGucVSNiwnRwAgOQgDWQWkscjAAkPEdyCpEGWXBIGHNQwtFH"));
    this->kmimutSc();
    this->fdnMwgWbtcEYixP(string("oFDzwKELzgOAcSbUIlvqZfRejkQdVQzlATzUDKFWlvUXOcUDBcISOfegufcLgOGxpvMGTFcxDWgcotNYcpixsHtuRbiLMrLfWnXunpnMRbLsIgCgDoieXCwBHwBKgbmdQFOjMyzCpnWMGTaViYJOfohaB"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sbpHkQSbjvADXNgg
{
public:
    bool XhWnKXLuqnGeql;
    int XnNtxQaD;
    string RKbRVbbccet;
    string szITYTlztiX;
    int rNxCHaR;

    sbpHkQSbjvADXNgg();
    void AauxrwI();
    double ZHHKLRcjppfsjC();
    string lhqqOM(int UGUjYpwtJd, int ETCUrlumdujQAOp);
protected:
    bool gSTfsXup;
    string GodkTyGUmlDFXgph;
    string ertkeGFXAHX;
    bool fmbPXZGcvVjTwkiO;

    bool crzHUHGIvo(string qCjEWWYFkfqMW, bool XSlTlgwU, double BKRleiV, string nLQGxrvgeRdFdw, bool ATdnkRzWHzcOzhnl);
    void gIHwAfhusJqpyZIS();
    string wdPbbdsQx(string KaXJIFWEndFIP, int aPSRuEzNGz, bool KpGBpuGhnwZrhhJQ);
private:
    bool cSJQFiVrMB;
    string MxKnkNfBaLqbp;
    bool MhgOwAXAHnUcjNc;
    int fPitqgECReWbKIm;

    void aoezKVCdZGXZ(double kFzskpsLJXgqA, int QJSBAidnoP);
    bool bNlWAshHA(bool GcdYCefsjZpTg, int WqOPn, double VQGlnVHeEa);
};

void sbpHkQSbjvADXNgg::AauxrwI()
{
    int JyTzSrx = -1689291146;
    bool MFvIDRxSh = true;
    double DrZEzFFXKhDxTjF = 633263.524013233;
    int taIlEkYMuFKexilR = 575626999;
    int DReoT = 966229788;
    string JuHvccrgdLmYVI = string("fRvmfZJwURauUKhXDvsiRUCgqgQGjgowpVtGqzvbVXpydKWCAvPhkhZXNNLNJdBYGUvFTCMWYkfTCVMWvqdaNGxKFWYTMNvjaewhLIwAccjiZLszKaDXTjKoHXQVBVzTLbeyVXfyXJUsaVLMcCcKDpVgNDfFYdPxKNxlZswVfCxlafUwFRGITnbsccRCvSQsROKBbzUrjlZKMhtKMQ");
    double bOrqGakZ = -728468.569688343;
}

double sbpHkQSbjvADXNgg::ZHHKLRcjppfsjC()
{
    bool zDrnRQYgXMbQme = true;
    string xTqsDWZRUWyJdDxd = string("OSirtzNXYNfomXEPJypgqnTcjHPtdoQksdUlhICWiNCwofvkTUbLombUBKlQEmHDGvQzyxuJt");
    string OxINIcVwQ = string("xswzHtfzYBWduRRQcPftwpGljBKpXHAvBWgxWFwjTaBHmXxFIaactlcsjFvNhsolmFtMQbmiWEDxkCgUgZjotldwbKSQUfMqkI");
    string hLZnURaWPcYYLmxN = string("tmppdxMlWfFmzjCRuwfNDtfFTCgxtCtlJMUGiEewNKUTEsWdMFlGfhmBMfnAHLJAeTBTzRwxNhETFJzNjNQbBbTJutshhWDVJySKQfGEnkrHSrIWdfAuTkwyFYpFZzGSQdmOhIBYlbkCNfGMwjtRohFxgHGSoeLiKpnUkTzKbiqdVIlKpPJXenlWBeanNaArAsVfLicniVDCSgDCWuWikcwuUFfvABBGHIZjfJiePqTInibTihiJjI");
    string OFdbXV = string("XRStGtiPhCqWpifhqTSAiwvJhGDKNDHoLvvrZzPKwFxtXDqXTYTScurJNhrvHILEsrvckio");
    string ezIwaXjYQvg = string("jpvJCASOozZXKBSAEekplhYvBXvsrXFgWoZGULFnOwdZcezFZzaTLmqOWUKohTVDORumfdXDXkdBzrEIlEilwSzJOvCHISlDIKPMNuYuxbitaWxIDowSPAZIFfVAXlVQHJuzJJwUfxojucpOiKBZrAJLPdbqndhqaeGpFDsSASVcrtoiMbvYUcjP");
    string exsUChMxBNOLjl = string("XfUpmHymHIadgKbzfNgBDFPiVbLzKXlWDZwaAMPdjVtUeTsQkFcFBjpCAQSfWvAKmoEbZCXYcIGOhBesCkoGTybMWzDgZOFnflDEbhMEusgqzVuLqIAlqAmjCmTOtaoZSbDAAHTnWDhDuSqhouPxwLOLxJxvjBryvxWGAEeIyv");
    string QQGXObashTvlf = string("FIbthcgJUoLdaJOtbJEMBtHKlmctcbcMXxBpqpRPtMgILfrCQeJiRKSmoigCSHsRaHwYLXmtyNZixOqJYWUYKiWAhepkiicAJdOTLFsevZhoyDXjUWjjinmKImROtqunbrXnlqfhGVpAVHupfzHbUCxTdPSjTHycooMhxcJYGiKCgKVLlxMXWbJdUijLzBySePWTUOxzvPeIJelIIwvVeZQqPpX");
    string fSQcSpSKG = string("RCARYFNlPSPUjYnPdRPOGqmtuSSeZ");

    for (int sntpxSHtx = 465643708; sntpxSHtx > 0; sntpxSHtx--) {
        OFdbXV += QQGXObashTvlf;
        ezIwaXjYQvg = OFdbXV;
    }

    if (ezIwaXjYQvg < string("XRStGtiPhCqWpifhqTSAiwvJhGDKNDHoLvvrZzPKwFxtXDqXTYTScurJNhrvHILEsrvckio")) {
        for (int eABnGnlXLgU = 197627562; eABnGnlXLgU > 0; eABnGnlXLgU--) {
            fSQcSpSKG += OxINIcVwQ;
            QQGXObashTvlf = fSQcSpSKG;
            xTqsDWZRUWyJdDxd = OxINIcVwQ;
        }
    }

    return 415631.1724847519;
}

string sbpHkQSbjvADXNgg::lhqqOM(int UGUjYpwtJd, int ETCUrlumdujQAOp)
{
    bool mXKCjm = false;

    if (mXKCjm == false) {
        for (int mCcTEynQPvCGHK = 1278075155; mCcTEynQPvCGHK > 0; mCcTEynQPvCGHK--) {
            UGUjYpwtJd *= ETCUrlumdujQAOp;
            mXKCjm = ! mXKCjm;
            UGUjYpwtJd *= ETCUrlumdujQAOp;
        }
    }

    if (ETCUrlumdujQAOp > -1953385435) {
        for (int UpgdOsmAMKsgKgI = 69201043; UpgdOsmAMKsgKgI > 0; UpgdOsmAMKsgKgI--) {
            UGUjYpwtJd /= ETCUrlumdujQAOp;
            UGUjYpwtJd += UGUjYpwtJd;
            UGUjYpwtJd -= UGUjYpwtJd;
            ETCUrlumdujQAOp -= UGUjYpwtJd;
        }
    }

    for (int OqgWbpBAmaRXnvk = 286817485; OqgWbpBAmaRXnvk > 0; OqgWbpBAmaRXnvk--) {
        ETCUrlumdujQAOp /= ETCUrlumdujQAOp;
    }

    return string("AnFuMnvMLKPwWkaJUkHVkBqoLuLIbqWUeQPXYXojcTPJVumSLnnEGQYNjkWUsIvNlTCwINOGqRJaNXjaMdgqiBdyCHYAYZTYMzMsRrxEsyzMJFeZRnaOVnl");
}

bool sbpHkQSbjvADXNgg::crzHUHGIvo(string qCjEWWYFkfqMW, bool XSlTlgwU, double BKRleiV, string nLQGxrvgeRdFdw, bool ATdnkRzWHzcOzhnl)
{
    int WqPvb = 1743321565;
    bool YTeXER = true;
    int aVvcJpALKSjqeZCe = 1608729069;

    if (WqPvb < 1743321565) {
        for (int RGaYxx = 1882937127; RGaYxx > 0; RGaYxx--) {
            continue;
        }
    }

    if (ATdnkRzWHzcOzhnl == false) {
        for (int DkyDnrfMstXgg = 1756985629; DkyDnrfMstXgg > 0; DkyDnrfMstXgg--) {
            nLQGxrvgeRdFdw = nLQGxrvgeRdFdw;
            qCjEWWYFkfqMW = nLQGxrvgeRdFdw;
            YTeXER = ! XSlTlgwU;
            nLQGxrvgeRdFdw = nLQGxrvgeRdFdw;
        }
    }

    return YTeXER;
}

void sbpHkQSbjvADXNgg::gIHwAfhusJqpyZIS()
{
    int teDLpnY = -172205337;
    double qGAWFfU = 1028990.3253017084;
    bool yYIgRYRu = true;
    string lRNbfX = string("bmASxBAqttWtXXOfYwyGxEzIOkkoQRpqOTnxvFgNgGxfcGVOYFeMXEowmQONvEmfWtVUHxVyxtndwAVkNUGtDMsOihiBXGiuaoeaDEAefQEvZDjtmHbiuBrGUBdTfhcmAJlPvSaU");
    bool YizGQBxPjChtb = true;
    bool gkADylzz = true;
    bool ieMiyVGeaPDAuyBj = true;
    bool EPBMPSGgSRwGrwU = true;
    bool QoEWJDNqwCHX = false;

    if (EPBMPSGgSRwGrwU == true) {
        for (int NFJAXH = 1300258353; NFJAXH > 0; NFJAXH--) {
            ieMiyVGeaPDAuyBj = ! QoEWJDNqwCHX;
            ieMiyVGeaPDAuyBj = EPBMPSGgSRwGrwU;
            gkADylzz = ! gkADylzz;
            EPBMPSGgSRwGrwU = ! ieMiyVGeaPDAuyBj;
            YizGQBxPjChtb = gkADylzz;
            ieMiyVGeaPDAuyBj = QoEWJDNqwCHX;
            ieMiyVGeaPDAuyBj = QoEWJDNqwCHX;
        }
    }

    for (int NUqOJbewxGvd = 651411510; NUqOJbewxGvd > 0; NUqOJbewxGvd--) {
        QoEWJDNqwCHX = gkADylzz;
        ieMiyVGeaPDAuyBj = yYIgRYRu;
        YizGQBxPjChtb = ! YizGQBxPjChtb;
    }

    if (EPBMPSGgSRwGrwU != true) {
        for (int QhSdRkqaE = 716566177; QhSdRkqaE > 0; QhSdRkqaE--) {
            qGAWFfU -= qGAWFfU;
            yYIgRYRu = ! QoEWJDNqwCHX;
        }
    }

    if (QoEWJDNqwCHX == true) {
        for (int ZxGApJVSlTEQr = 1426927281; ZxGApJVSlTEQr > 0; ZxGApJVSlTEQr--) {
            ieMiyVGeaPDAuyBj = ! gkADylzz;
        }
    }

    for (int RKRZaDU = 926360060; RKRZaDU > 0; RKRZaDU--) {
        QoEWJDNqwCHX = EPBMPSGgSRwGrwU;
        gkADylzz = yYIgRYRu;
    }
}

string sbpHkQSbjvADXNgg::wdPbbdsQx(string KaXJIFWEndFIP, int aPSRuEzNGz, bool KpGBpuGhnwZrhhJQ)
{
    int fxKUIUslYrdU = 1539499036;
    int ZCNvGHCSYQkiVr = 1730840866;
    bool LNXyzlaf = true;
    double OuKwACbevaLso = -384763.87200637825;
    string awqGPZTjmH = string("oFJKCsMJvdNtYPMkOIfwuyfmtgIyUXluPIYCHATYvFzeiwcslXvGNtWSzYnTrBUjELvdZxFEnmbRySsEikNCkQybmcVAYYEUJKYPJKzCgrfhBuSwETwhXuFbGKwcykIOOhuAoUcFTEcFcuSIUOEcaakJpYiPGWwKZAvurdjPVObQWSCWDaLyZokhBprVkMMxfGD");
    bool kfGxBnGSXcPCdcu = true;
    string wodHXtBdJ = string("odwBTJhTtxxKzPjdqdJjQbjOxmczrp");
    int clwfkdsNimMJFDjc = -503204930;

    return wodHXtBdJ;
}

void sbpHkQSbjvADXNgg::aoezKVCdZGXZ(double kFzskpsLJXgqA, int QJSBAidnoP)
{
    string gSCwKtaMDP = string("SutQcZqIlmQpiappmgIOhaUPIWYIgWHoRHidXkwKyobQNUVszplUSPaLVDvireYXZAMnuNNnYMgkUxKMeMRavkHcydUtRUwiaSZQdZMoVtnkkzALhyZBMIsJNGFnoTAWnfOHRHTGxaRtUsgiFMGewwhmRFAIlBRCnRruJ");

    for (int wsIvbvDdsgOIACp = 1303499534; wsIvbvDdsgOIACp > 0; wsIvbvDdsgOIACp--) {
        continue;
    }

    for (int zUDaj = 2080759724; zUDaj > 0; zUDaj--) {
        kFzskpsLJXgqA /= kFzskpsLJXgqA;
        kFzskpsLJXgqA -= kFzskpsLJXgqA;
        kFzskpsLJXgqA *= kFzskpsLJXgqA;
    }
}

bool sbpHkQSbjvADXNgg::bNlWAshHA(bool GcdYCefsjZpTg, int WqOPn, double VQGlnVHeEa)
{
    double uXowPmclDMMTA = -228514.42676669563;

    if (VQGlnVHeEa >= 387549.9463358295) {
        for (int DwqTPQowIrkNDv = 122372872; DwqTPQowIrkNDv > 0; DwqTPQowIrkNDv--) {
            continue;
        }
    }

    for (int QxbYg = 789651635; QxbYg > 0; QxbYg--) {
        uXowPmclDMMTA += uXowPmclDMMTA;
    }

    return GcdYCefsjZpTg;
}

sbpHkQSbjvADXNgg::sbpHkQSbjvADXNgg()
{
    this->AauxrwI();
    this->ZHHKLRcjppfsjC();
    this->lhqqOM(457594230, -1953385435);
    this->crzHUHGIvo(string("qjdeDlmlyYlwfpGkxZfJtucmpQxDuNkNYiIjHOhWrbAXiCzcVCpiKKSGTGaEXFkTeJmoUTYjdqyXZrGcvetekRKQRoPvlsXeOHONQWGfINEdLgUtjAyLDQmfYSXoDoihUOLoUcjsFXpkXYcfQZtVJZLIpoUJvGZDOPuIkSPd"), false, 294501.5844478632, string("OOnhbnXvluboirpdDlKejesWqLyNkvGFEUrRTkzCchDsAPRZtrfiYnvuiBoxqwfpPfEOLfXZsaOBCrchUZGGzCfOPhzpIlEomheGHHDkJeYseGxjVOYRHyiEzCKLMTbAKLFlzBnQVumTTOxkCuwcLZWLGpTXSMhzgMpepIQqHXJImZUNEcCBWigaDoGXTEVAqeSsImsjSMgevaPbgNLvoiUqrQaMpCoLpER"), false);
    this->gIHwAfhusJqpyZIS();
    this->wdPbbdsQx(string("aLgCjeLTFEXelFTSywwZDyaaCrrQrUYPiSkQRhgycgLmMyILbmUSJzHcgJIzDnBojLAqPXILAPacGrUTaEdkSzvCFUBIuKicoPWmkcoVFxTbEMExbyJDieogPKTFyJizrQHQgaLetgzPNSvnJApNpbaIJepBzTTawIyPYefnTMhrdQKomvFqXvxaVLDxvlXnCDNutSRriRZKVZEWbaUWFZDHYEwqenNVKsXiUeHVXyYZeREgLZx"), 1957425239, false);
    this->aoezKVCdZGXZ(-485821.1169199463, -852848012);
    this->bNlWAshHA(true, -1790454647, 387549.9463358295);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UYRKIfWFtDNtU
{
public:
    bool dFkyo;
    int LHvAqJIrC;

    UYRKIfWFtDNtU();
    void MAvKp(string YwouawMQ, int LmHaTcFK, double btZRSCgiTpupR);
    void dZVSRtxskJsooSm(int FoVcLlk, string udspavC, int NHDqmBDivsvaV, bool RKxGCnaV, bool KyeIzDizB);
    double VyjjKDmxp(string ueowlAbY, double vUgckcKVYtDih, double vlUpVvYDf, double cMzRFpQmGx);
    void SXIbEjhGPMLdQO(bool yRfijGdyY, double XgllAH, double ALZlDXZlzTgGLs, bool CrYxKvVYeg, int TbbZWxDqu);
    void zUganyWOJngxro(int JHWhFaujT, string slebNaztWscyu, string BIxXJjDIstDDDj, double IQsiJhyMVti, int XJMGvjqaQmN);
protected:
    string uKgJQzaReA;
    string fXMcCUD;
    int mCUTsLFQiQD;

    bool PNmsfHcQQdZOh();
    int YwvFgyUmSD(int ldeHHwltOBqZYtSY, bool nZhAGrMpWE, string rMeyRncZCO, bool WiFwalOfPusA, double qsfIb);
private:
    double xWauzQSCbwP;
    double sNUQjsCRseGV;
    int msjsNNSIdfnpqXkS;

    double CBxYzEGOMpNJTCDn(string oLaPDdc, bool oldQBfxQQfc, bool vIsepNyK, bool WvrsCvZhdMXScPH);
    void EEsBMbnnqh(int dVBuQhiIDU, int GGvWxjIty, double FdVbhjO, double eVyTcaiBeWCdfO, bool HKkgigzEBu);
    double vsoBcizz(int MpewfLXhNQwlK, int XAXskSZKDk, string HNmbQVt, bool LHrFLDXbaXs, double FaFzxWe);
    int KPBIA(string hHRmuDaMbKXaB);
};

void UYRKIfWFtDNtU::MAvKp(string YwouawMQ, int LmHaTcFK, double btZRSCgiTpupR)
{
    int JHEqFsLgfpomSP = 2019909359;
    int xoVJqmcQ = 2051032137;
    bool OncUY = false;
    int REJZposrml = -1102790439;
    bool gSaqgwlewAaLLs = false;

    for (int XKFWuVayxMInq = 1924757108; XKFWuVayxMInq > 0; XKFWuVayxMInq--) {
        REJZposrml *= LmHaTcFK;
        REJZposrml *= JHEqFsLgfpomSP;
        OncUY = ! gSaqgwlewAaLLs;
    }
}

void UYRKIfWFtDNtU::dZVSRtxskJsooSm(int FoVcLlk, string udspavC, int NHDqmBDivsvaV, bool RKxGCnaV, bool KyeIzDizB)
{
    bool AiHdxtVxBKw = true;
    double dxCZagNfQJkItDwv = 619917.3209378739;
    double SxLlEAGcYBBG = 449959.4354346139;

    for (int NWjbTxkAh = 760551316; NWjbTxkAh > 0; NWjbTxkAh--) {
        FoVcLlk = NHDqmBDivsvaV;
    }

    if (FoVcLlk != -1186055631) {
        for (int nFZSUz = 1627829470; nFZSUz > 0; nFZSUz--) {
            continue;
        }
    }

    for (int XlABTvmOVcKpdi = 1004321052; XlABTvmOVcKpdi > 0; XlABTvmOVcKpdi--) {
        dxCZagNfQJkItDwv -= SxLlEAGcYBBG;
    }

    if (NHDqmBDivsvaV <= -1186055631) {
        for (int BFKPBrOKzEmraQ = 1410708768; BFKPBrOKzEmraQ > 0; BFKPBrOKzEmraQ--) {
            SxLlEAGcYBBG = dxCZagNfQJkItDwv;
        }
    }
}

double UYRKIfWFtDNtU::VyjjKDmxp(string ueowlAbY, double vUgckcKVYtDih, double vlUpVvYDf, double cMzRFpQmGx)
{
    bool OJcFvPYp = false;
    double PAKOeNQuNXuwtE = -125434.83134059033;
    double ZNbYkrKHcmSLU = -21428.326536481687;
    bool XEcjIgBcll = false;
    double bhpCJUGsMtgq = 980208.7837011928;
    string XflAdKvjAbfZ = string("TwtbfDPwJXZGSQGWUmjGTpBSuHqOxpoweJBvsiDedWBqDCSNPCKmYwmdNCBAQiXYjzyprNYTyHilWivEvNXwzZIoHioBjeEYRnTqIIJGDLQwqQRUpzphEpEQHjRSkWcUflslfPpzlikXqERKPXfZvVGUnAaTnXvLIOzcLnrviOcbHGemwqLJdRVJTTkKYoKgkMImXgLJELIAegOcFQrgRwTqxQDEPetHpEOlefchtLppMJ");

    if (PAKOeNQuNXuwtE != -439449.28909244953) {
        for (int hfZdkIdpgF = 445299618; hfZdkIdpgF > 0; hfZdkIdpgF--) {
            vUgckcKVYtDih += vUgckcKVYtDih;
            ueowlAbY += XflAdKvjAbfZ;
            XflAdKvjAbfZ += XflAdKvjAbfZ;
            OJcFvPYp = ! OJcFvPYp;
        }
    }

    if (PAKOeNQuNXuwtE <= -439449.28909244953) {
        for (int prXabvPkTzt = 1310184114; prXabvPkTzt > 0; prXabvPkTzt--) {
            PAKOeNQuNXuwtE /= vUgckcKVYtDih;
        }
    }

    for (int rnNuqIqWJWRifnm = 1416816755; rnNuqIqWJWRifnm > 0; rnNuqIqWJWRifnm--) {
        vlUpVvYDf /= cMzRFpQmGx;
    }

    for (int wXcYbhYjCTaP = 2011210729; wXcYbhYjCTaP > 0; wXcYbhYjCTaP--) {
        OJcFvPYp = OJcFvPYp;
        vUgckcKVYtDih -= vUgckcKVYtDih;
        PAKOeNQuNXuwtE -= vlUpVvYDf;
    }

    for (int AdqNabBxQGvC = 1297312493; AdqNabBxQGvC > 0; AdqNabBxQGvC--) {
        continue;
    }

    return bhpCJUGsMtgq;
}

void UYRKIfWFtDNtU::SXIbEjhGPMLdQO(bool yRfijGdyY, double XgllAH, double ALZlDXZlzTgGLs, bool CrYxKvVYeg, int TbbZWxDqu)
{
    double dnNESiKPvPIGrsEi = 548062.1225319041;
    int BymlIb = 358329477;
    bool fpUuu = false;
    bool uxsKwtMFxl = true;
    string rqIPPUyHKg = string("vfFbNoxjUHjglyvOObhyhubAUgYlKYDJPSsiPaUumzlMYiTDurVEywkbmVlXvYjKKAwcWBOIAFxyrDVuLHkvZpBYJHaXXGoGvJjjelSdonjaGshPAzyPatpbvShsiRDncHenOtOskzXmcBMiLGdpDuJosHMmsCkAdaRLfuCvpcsndxxHzoDukZKxscCrKsbrjlvrSKolWJFNtDyGJkTBPEigdYnTjt");
    int CIjJgiUtGrhPn = -1823196407;
    string crWGN = string("UiRjLnqdVIUDkdaVhjHYzmCWxAwWokfQYowywqMtudidakpXpUOssZczxulNdhymWDxsVdwxiNRywGLUeeDaOqirVXJopTsNfeWdBcPcAkgENdLHwkbltUvUCn");
    double IilmLssYh = 903265.4410386417;

    for (int ySevtpoYet = 334491325; ySevtpoYet > 0; ySevtpoYet--) {
        crWGN += crWGN;
        fpUuu = fpUuu;
        BymlIb += CIjJgiUtGrhPn;
    }
}

void UYRKIfWFtDNtU::zUganyWOJngxro(int JHWhFaujT, string slebNaztWscyu, string BIxXJjDIstDDDj, double IQsiJhyMVti, int XJMGvjqaQmN)
{
    int rapUjdLQbo = -1868674120;
    double oAoDxgHvNRF = 623412.2163968098;
    bool HVPZQgckymDDV = true;
    double JkEjryoVlJf = -697440.7118945334;
    int AEJMPiLuovzF = -1564092578;
    bool UupkRTHxk = true;
    int zeqwODTLj = -424494421;
    bool csuJcaIwkJ = false;

    for (int toKdqBrkRoAHQBx = 864314533; toKdqBrkRoAHQBx > 0; toKdqBrkRoAHQBx--) {
        rapUjdLQbo += rapUjdLQbo;
    }

    for (int IuZTwswoT = 787084864; IuZTwswoT > 0; IuZTwswoT--) {
        csuJcaIwkJ = ! UupkRTHxk;
        JkEjryoVlJf -= oAoDxgHvNRF;
        IQsiJhyMVti *= oAoDxgHvNRF;
    }

    for (int aPqeNJ = 2068533986; aPqeNJ > 0; aPqeNJ--) {
        continue;
    }

    for (int OiYBqQPJqO = 316028336; OiYBqQPJqO > 0; OiYBqQPJqO--) {
        continue;
    }

    for (int rFGXXlYO = 1922741652; rFGXXlYO > 0; rFGXXlYO--) {
        AEJMPiLuovzF += JHWhFaujT;
        HVPZQgckymDDV = csuJcaIwkJ;
    }

    for (int PkjmVGkkn = 580861685; PkjmVGkkn > 0; PkjmVGkkn--) {
        JHWhFaujT += XJMGvjqaQmN;
    }
}

bool UYRKIfWFtDNtU::PNmsfHcQQdZOh()
{
    string GftuIOjeyY = string("daQXJJGnQPxYdVXKGxVEYMWMWnUBxMqVI");
    int GwWJPe = -93279893;
    string tiEnwpCgytaKvZ = string("PVGhBBOLLOBYnxNKppsdRUJCImzOxzDuTneslNGaZlMSkPQdfZEsuoQayfMrJQN");
    bool QAmHtfA = false;

    if (tiEnwpCgytaKvZ == string("daQXJJGnQPxYdVXKGxVEYMWMWnUBxMqVI")) {
        for (int griyRtISmfKNK = 220617994; griyRtISmfKNK > 0; griyRtISmfKNK--) {
            continue;
        }
    }

    if (QAmHtfA == false) {
        for (int KzuQlGiPiqUo = 1868243504; KzuQlGiPiqUo > 0; KzuQlGiPiqUo--) {
            QAmHtfA = QAmHtfA;
        }
    }

    return QAmHtfA;
}

int UYRKIfWFtDNtU::YwvFgyUmSD(int ldeHHwltOBqZYtSY, bool nZhAGrMpWE, string rMeyRncZCO, bool WiFwalOfPusA, double qsfIb)
{
    bool ZteCQBHYjJlP = true;
    string gMpxGjo = string("aeCbnryrvfJzhafOYaadamtizXioCqipcGTwOwYDczpvvygHbocZvkfoWRkhpTOhTzcuzUudsotQkUDmEjGmfHdzHDHiBYovJndYFJfbVfrJdWoTdZzhgVRfhJSAolwQejKiyalzmZBfdtQJjYZSQBVEbKvwuydRbrRfmqbTKAXIMLaNLsFZzflrRJdnK");
    int nYRAczGMpiLmUOz = 1149522892;
    int BXKmTHWSfDPFbM = 2086813408;
    bool VwdnxDKHgX = false;
    bool eYgCcHupfheaHB = true;

    if (ldeHHwltOBqZYtSY != 1149522892) {
        for (int fAxwbA = 2055707650; fAxwbA > 0; fAxwbA--) {
            continue;
        }
    }

    for (int OypuBpL = 1107144426; OypuBpL > 0; OypuBpL--) {
        ZteCQBHYjJlP = eYgCcHupfheaHB;
        ldeHHwltOBqZYtSY -= nYRAczGMpiLmUOz;
        ZteCQBHYjJlP = ! WiFwalOfPusA;
    }

    if (ZteCQBHYjJlP != false) {
        for (int fHfEdFDAfMGdh = 1515910616; fHfEdFDAfMGdh > 0; fHfEdFDAfMGdh--) {
            qsfIb *= qsfIb;
        }
    }

    return BXKmTHWSfDPFbM;
}

double UYRKIfWFtDNtU::CBxYzEGOMpNJTCDn(string oLaPDdc, bool oldQBfxQQfc, bool vIsepNyK, bool WvrsCvZhdMXScPH)
{
    double EwKWgYEaIxzncMZg = -623603.7554086037;
    bool PufmbM = true;

    if (oldQBfxQQfc == true) {
        for (int DHQxB = 1826141816; DHQxB > 0; DHQxB--) {
            WvrsCvZhdMXScPH = oldQBfxQQfc;
            vIsepNyK = ! vIsepNyK;
            WvrsCvZhdMXScPH = ! PufmbM;
            WvrsCvZhdMXScPH = ! oldQBfxQQfc;
        }
    }

    return EwKWgYEaIxzncMZg;
}

void UYRKIfWFtDNtU::EEsBMbnnqh(int dVBuQhiIDU, int GGvWxjIty, double FdVbhjO, double eVyTcaiBeWCdfO, bool HKkgigzEBu)
{
    int MKzKPTTiHwS = 1381489386;
}

double UYRKIfWFtDNtU::vsoBcizz(int MpewfLXhNQwlK, int XAXskSZKDk, string HNmbQVt, bool LHrFLDXbaXs, double FaFzxWe)
{
    string lLMggxVk = string("VtxacasXHmbUlNupOINRuwuqbqqfTpiBkvTSIQgqkIEibZFPacwGjzRJKNRRnluXejryumdnOKXVrSyLRUEswGosjErPToqAniPQszQLTcINlUpUAaimVRhNABMMZNgrTDdxrxLMGKpeYROKGjqKxZEAniPNwHnWaCsQYmzDfZraKuTCQUoppbzeWHJiUhvElNrUAewxivSxoYwjnUIggvOWGdVf");
    double dMxQDQ = 385421.98932823143;

    for (int iNcQhHfqoFczTaV = 800729524; iNcQhHfqoFczTaV > 0; iNcQhHfqoFczTaV--) {
        MpewfLXhNQwlK += MpewfLXhNQwlK;
    }

    for (int mlZIXxHwVwmMgN = 1464888818; mlZIXxHwVwmMgN > 0; mlZIXxHwVwmMgN--) {
        dMxQDQ = FaFzxWe;
        FaFzxWe += FaFzxWe;
        FaFzxWe += FaFzxWe;
        FaFzxWe = dMxQDQ;
        dMxQDQ += FaFzxWe;
        lLMggxVk += HNmbQVt;
    }

    return dMxQDQ;
}

int UYRKIfWFtDNtU::KPBIA(string hHRmuDaMbKXaB)
{
    double ZpyXEePBybiKA = 1040349.7742707039;
    int BZzlWlJcS = -464073990;
    string DPvtksUiZA = string("TRxuKKRqhyyzLWLeVlNHuoumRxaacVImZuMzflQjYSRPFatnkajjfmbVOsDFccqoUPfxeevUtLBnOHRPA");
    double YPpSGwLyXoP = 834948.3605111325;
    bool KbstCpLVEXrqhK = true;
    string MPNdoSFBzo = string("AwUNQtNGBeOhaVwBnjwScMSBlpFNCLeoCaGdViIgwaDvKfCehAfotiKxdOTeewlKWdpKTWkBCUSSFhmnVNHMvZWlvRvuOrzWKfKXupIEOBpc");
    bool dKdsljRuHPaKPhtM = false;
    string QhnmseQPMZCguX = string("lWMTXfxewPdmTlGDOTaqrHVwbfupORzjHhBnvtUkKoEqsxqhRHGNECpXECKyWqJuCRWpzpzxrKsapOawtfCOWSGXkJDtKplFJotfrbhYEPzpPemgJLucUQeoGKzlZeWELThOJKuvpYnPiCffMAobPLgLdumwiCRuFijqhCnxUeIPrqOzclgckARuvbjQtNCpXATdKvcbyoAGGvFeousZUcvnCzeFIGWtSKpKIEQJJnc");
    int SxWHMULsQY = 1189743220;

    for (int zkCqQF = 51387630; zkCqQF > 0; zkCqQF--) {
        dKdsljRuHPaKPhtM = KbstCpLVEXrqhK;
    }

    return SxWHMULsQY;
}

UYRKIfWFtDNtU::UYRKIfWFtDNtU()
{
    this->MAvKp(string("rxbbEEplfixskrdtBomyjyXequJIGMoomzsWAlSNvDOnGZCjzazugTdFabHPbZXUIEgiKcRftuupUljhnHoktqbUuGLauIEFCqgKbYIyVBHxJmoIMXVJlNmMtOxYoMYTicFVLMaHjXCeElihbDcruAHRwJuvbUjEecbIzjJsWFTLNiGgmm"), 409724989, 1013412.8478673518);
    this->dZVSRtxskJsooSm(-1186055631, string("mJMpxOyiCCxoEqGlntiArbohClPFNZvaIuDLEaAIsqbWVTyrCvkzIOUevRreQtUgnepJndePuVWkcQtDCtYWKQokyojAbRiDNRLKwKORvEEKCylmhJMrnSdpIkXuSEtrLoBEOpnaPxHaIhTXbBevIIwaBQRPWbzyiARwkRGJdXyGGvMlphaPjhnoJGtO"), 668106603, true, false);
    this->VyjjKDmxp(string("OEyhMLosFnqtfvNDaFmaJYlSSSyTxPVpWjoQMWxVHCUzwnOsljuquhyJfdHgkAjkWDzybSuJHKgrmJakhhXUtbxInrlcKGAdHDIqKzjDZTNBxMZPNfRfLpRmEaNEIPjNokbVVqoMtrnmlKGwKyRPWzyXYNKZbQvpOj"), -604358.046417115, -605346.1100987, -439449.28909244953);
    this->SXIbEjhGPMLdQO(true, 107376.48348502227, 309753.90397814516, false, -131170632);
    this->zUganyWOJngxro(618128975, string("hkiIpeQjpJAHIKJQhidlXNftLTiKSZlOWqizGNQhvTRriArlEJrcUKNtbIDnW"), string("UHGxgOmjzMVCDbSDTFuwVsjEJjjUAcdznOVscTtJnlLSWvomzeTbKWgICOStFyYpoWHaSGvjvUXiEKekwJZYHhkRpxmwtaJnvjozhYKOlrxthkVZHtatbBZZlqzOuNADMxOPVsvXokMvFwVCIxAHcbDzVjPTFjvnvLYub"), -812083.7356377736, -369745446);
    this->PNmsfHcQQdZOh();
    this->YwvFgyUmSD(1444153918, true, string("nswVPxaaLQWkEvgfTXHIKMCKWDvrhgrnMbcsyUNqkJRfktHuaGpQjKBaMtAMcyvgqGxcELjgxLVhVnmFbxGodsouFxMCSwuCqAlzeEZttXsSBEQjTkYIARgxfnktpRfvAocVRDfVNKbJILpCesFeAGiqVMHwySUFCFSWdZDLDcxGSkjVDSGOFsFwp"), false, -905959.8872384315);
    this->CBxYzEGOMpNJTCDn(string("dsfHZJVPLnTQsJnNzWkDGUJQagHvOWpdxkXo"), true, true, true);
    this->EEsBMbnnqh(1337572363, 849956091, 918214.2498613223, 657090.4890004627, false);
    this->vsoBcizz(774938288, -1066979095, string("aQzaREPU"), true, 174049.77127020693);
    this->KPBIA(string("bmMyRyzXSKTyGrGBJCgfdSAwvwoLQYZJDwDOcgTKWYalNAnipSIwwWSvBUaDWDcjcmyHWgufQ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SUDrRxCegxwDdRlF
{
public:
    bool mYJLni;
    bool UdoMggU;

    SUDrRxCegxwDdRlF();
    bool obGJb(int uohRYXcbzJOINp, bool ByzNhswFx);
    int RBltBSxeC(int cSBAW);
protected:
    double pncFfyKoGTXVP;
    int iUCqOzuhjtfo;
    int ANqUNVhld;
    bool XOovfynta;
    double umElRkZMHHm;

    void DnXNlBjDGiBS(string MWIOSA, bool VZJOIZdoQPJYA);
    int wHpBAmx(bool sMUFYlBOelVJum, bool PYhJwDIPAmjKPOSp, string tyXtnZtoGTs, string FjwGuiGUDK);
    double DkSCSJ(double iTzCxrWBhCpV, double iZGBoOWunfWgqt, bool PxAkv, string vpzfyqoqc, int sNNRTbNMHHjIUrS);
    void wkAcJqnNd(int WKESrFPlxqQavO);
    double PYHYlkZtIRbQgzr();
    bool tGLFR();
private:
    int wPtrz;
    string rqjSOozzwQIttyTK;
    double UOcwwQb;
    bool ZKiXB;
    int zxWUFgxTGzJ;
    string nfIbONkJtc;

    double PLFDzGByQKVoSwgA(double wjgYBoHlnuZyIlo, int nGTjvusNN, string eOiriON, bool WPgDRnuzDej);
    bool yPucUMBdjBPP(bool mgiAbHn, double VvHbVddJL);
    double hWfCfFtAamjtItkS(double KNGwvlwiYDqu, int aEWYjfHa);
    void pWnaInYsiLs(double AsnMfLermRYeiBzU);
    bool lApnVZX(int rUozkorpPDvdnTgZ, double MyBMVgLcRn, int nbLrHId, string ghzToUyB, int RIqKrik);
    string BiFPmOJI(string cdbfInd, double DssIrfYBUMv, double dlJvhTZokjNwXlDW, int nQBnY);
    double BZGLV(double OZamiVQwmKaS, double ajyTP);
};

bool SUDrRxCegxwDdRlF::obGJb(int uohRYXcbzJOINp, bool ByzNhswFx)
{
    string hruTJtulNCZ = string("FPYUfYDWlwhkITLyfQWtaXbyzElzoaHeddMOlMqkIcIXfMAw");
    bool bkyElHWrtXoKjAD = true;

    if (ByzNhswFx == true) {
        for (int dgXfGDHXNUWHVdza = 1469497301; dgXfGDHXNUWHVdza > 0; dgXfGDHXNUWHVdza--) {
            bkyElHWrtXoKjAD = bkyElHWrtXoKjAD;
            ByzNhswFx = ! bkyElHWrtXoKjAD;
        }
    }

    for (int HtyeazAS = 1509084568; HtyeazAS > 0; HtyeazAS--) {
        bkyElHWrtXoKjAD = bkyElHWrtXoKjAD;
    }

    for (int GhSfD = 1638185513; GhSfD > 0; GhSfD--) {
        continue;
    }

    return bkyElHWrtXoKjAD;
}

int SUDrRxCegxwDdRlF::RBltBSxeC(int cSBAW)
{
    int uHcrHHJLhRYTZfQ = 31163276;
    bool HQvKnGAalwBq = true;
    string SMjYSNPQx = string("PNUBpAXJSrNiKaZSXdfnVMsVZKfrpEbtxhORUcDExjpaVfJvHyEvyeWOrsJESIokPrpmJndMWWVQ");
    bool NnxEPFavFCEzTR = true;

    return uHcrHHJLhRYTZfQ;
}

void SUDrRxCegxwDdRlF::DnXNlBjDGiBS(string MWIOSA, bool VZJOIZdoQPJYA)
{
    string xfixSFStfWI = string("rZCPHnyJYPemSWJRhLqSImItGgcVinkCiPeqTCidEuxUSTzYYYzuHbmwEBqvhwAwtuuoFnBLwPwJSwdRqMErHxFNSmFHpmNApaMZkbgFveWEZTfRntpIETsKwUQKDCGrzbGUXZULqsbtRInowKgcwZKLLcIjSvbEukJMOWoazQoMRuOqqDSOTXXPAzZiqnzehynZzvySEGBmaPLzAylxAU");
    double PAwCkjpm = 588155.8297034493;
    double jxxAQNjsfM = 510688.682057731;
    string VjATztovBi = string("FXSHyQopUaoDCcVnizYzuwStrIzLbQtNYUjJyWDVhbmwIhUJbWSDUeSNuYqZkYoWTrKkVWqLVbinXOcldUgbBkAZxyDOaOjAqsfVgFwBPSPWpHGzGnJZIAZVzZlvWSRjGmwJBvsDOckMQVCXyEwxYFTymv");
    int euwOPKfPcBCiIj = 1571454953;
    bool adFxvqam = true;
    double UcmzEndlpA = 578791.80399557;

    if (PAwCkjpm > 588155.8297034493) {
        for (int GRURdNTPQXBkzFM = 1278658600; GRURdNTPQXBkzFM > 0; GRURdNTPQXBkzFM--) {
            MWIOSA += MWIOSA;
        }
    }

    for (int BBlVyZUhWqKonvaS = 105485293; BBlVyZUhWqKonvaS > 0; BBlVyZUhWqKonvaS--) {
        PAwCkjpm /= UcmzEndlpA;
    }

    for (int WSIaoyooopphuFqV = 1400282703; WSIaoyooopphuFqV > 0; WSIaoyooopphuFqV--) {
        MWIOSA += xfixSFStfWI;
    }

    for (int USODdPqKxdY = 1490411368; USODdPqKxdY > 0; USODdPqKxdY--) {
        continue;
    }

    for (int BoYtqYsjh = 1570543535; BoYtqYsjh > 0; BoYtqYsjh--) {
        continue;
    }

    if (MWIOSA < string("FXSHyQopUaoDCcVnizYzuwStrIzLbQtNYUjJyWDVhbmwIhUJbWSDUeSNuYqZkYoWTrKkVWqLVbinXOcldUgbBkAZxyDOaOjAqsfVgFwBPSPWpHGzGnJZIAZVzZlvWSRjGmwJBvsDOckMQVCXyEwxYFTymv")) {
        for (int GovrW = 612610709; GovrW > 0; GovrW--) {
            jxxAQNjsfM *= PAwCkjpm;
        }
    }
}

int SUDrRxCegxwDdRlF::wHpBAmx(bool sMUFYlBOelVJum, bool PYhJwDIPAmjKPOSp, string tyXtnZtoGTs, string FjwGuiGUDK)
{
    double kLcokRdGfQT = -963859.113363081;

    for (int qJYTuhyrLPUwDy = 1811627016; qJYTuhyrLPUwDy > 0; qJYTuhyrLPUwDy--) {
        PYhJwDIPAmjKPOSp = ! PYhJwDIPAmjKPOSp;
    }

    for (int piAvBbDIdDyOkrHT = 477757209; piAvBbDIdDyOkrHT > 0; piAvBbDIdDyOkrHT--) {
        continue;
    }

    return -621610541;
}

double SUDrRxCegxwDdRlF::DkSCSJ(double iTzCxrWBhCpV, double iZGBoOWunfWgqt, bool PxAkv, string vpzfyqoqc, int sNNRTbNMHHjIUrS)
{
    string ycKJZYVxlr = string("NSwUQCTUJ");
    double fZZHJdg = 652020.3692744444;

    return fZZHJdg;
}

void SUDrRxCegxwDdRlF::wkAcJqnNd(int WKESrFPlxqQavO)
{
    string yDdyAuOq = string("pfimhKPNUcvSRdycfZoJEwtrEIee");
    string GTWdBI = string("vWPxVhFZpctWshkeHEbbVavlqMxRZCxgqMAwGfEudPIxgSEsLBxhCshfujgendUEjdOJqCQWyoApHWsvi");
    bool FkILwfnFy = false;
    int OcaihCOKt = -1687603327;
    bool ZCdvsoN = false;
    bool PyPbkcf = false;
    string FZWSwjX = string("jIxnOVbziIwKyNJBWTozsfKcVRJIiqoWZqwUQpyDoVlkBTlqGpxspDKqqaPYYflllsCwGEXeCJvHxoFTOOiEFoWlfTlUbVBb");
    int IVUVMXYavKVNzr = 1847052880;
    bool kjVSnnTEH = false;

    if (kjVSnnTEH != false) {
        for (int rMTXdtlHVWBxc = 387757106; rMTXdtlHVWBxc > 0; rMTXdtlHVWBxc--) {
            FkILwfnFy = ! ZCdvsoN;
            WKESrFPlxqQavO /= OcaihCOKt;
            FkILwfnFy = ! FkILwfnFy;
            FkILwfnFy = PyPbkcf;
        }
    }

    if (PyPbkcf != false) {
        for (int GXKIXEEpqEVt = 971842766; GXKIXEEpqEVt > 0; GXKIXEEpqEVt--) {
            OcaihCOKt -= OcaihCOKt;
            FkILwfnFy = ! PyPbkcf;
            FkILwfnFy = PyPbkcf;
        }
    }

    for (int GhIleMf = 2115591843; GhIleMf > 0; GhIleMf--) {
        OcaihCOKt = WKESrFPlxqQavO;
        PyPbkcf = ! kjVSnnTEH;
        IVUVMXYavKVNzr += WKESrFPlxqQavO;
        FkILwfnFy = ! PyPbkcf;
    }
}

double SUDrRxCegxwDdRlF::PYHYlkZtIRbQgzr()
{
    bool fFNntTScCUf = true;

    if (fFNntTScCUf == true) {
        for (int kLrjGgXIoh = 396444560; kLrjGgXIoh > 0; kLrjGgXIoh--) {
            fFNntTScCUf = ! fFNntTScCUf;
            fFNntTScCUf = ! fFNntTScCUf;
            fFNntTScCUf = ! fFNntTScCUf;
            fFNntTScCUf = ! fFNntTScCUf;
            fFNntTScCUf = fFNntTScCUf;
            fFNntTScCUf = fFNntTScCUf;
        }
    }

    if (fFNntTScCUf != true) {
        for (int LVsPBJ = 1517996921; LVsPBJ > 0; LVsPBJ--) {
            fFNntTScCUf = ! fFNntTScCUf;
        }
    }

    if (fFNntTScCUf == true) {
        for (int NjtDMlUpsYbs = 1341728830; NjtDMlUpsYbs > 0; NjtDMlUpsYbs--) {
            fFNntTScCUf = fFNntTScCUf;
            fFNntTScCUf = ! fFNntTScCUf;
        }
    }

    return -760866.1340833436;
}

bool SUDrRxCegxwDdRlF::tGLFR()
{
    double VdhcvKyKPTqIBPq = 893397.2424389547;

    if (VdhcvKyKPTqIBPq <= 893397.2424389547) {
        for (int LMdPGRYoqneSFEJZ = 321677671; LMdPGRYoqneSFEJZ > 0; LMdPGRYoqneSFEJZ--) {
            VdhcvKyKPTqIBPq -= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq -= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq -= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq = VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq *= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq /= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq += VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq -= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq /= VdhcvKyKPTqIBPq;
        }
    }

    if (VdhcvKyKPTqIBPq != 893397.2424389547) {
        for (int SqEJpziIWCkKQQou = 607312766; SqEJpziIWCkKQQou > 0; SqEJpziIWCkKQQou--) {
            VdhcvKyKPTqIBPq -= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq += VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq /= VdhcvKyKPTqIBPq;
            VdhcvKyKPTqIBPq *= VdhcvKyKPTqIBPq;
        }
    }

    if (VdhcvKyKPTqIBPq == 893397.2424389547) {
        for (int CuaGEBBQCThxYVch = 702858687; CuaGEBBQCThxYVch > 0; CuaGEBBQCThxYVch--) {
            VdhcvKyKPTqIBPq -= VdhcvKyKPTqIBPq;
        }
    }

    return true;
}

double SUDrRxCegxwDdRlF::PLFDzGByQKVoSwgA(double wjgYBoHlnuZyIlo, int nGTjvusNN, string eOiriON, bool WPgDRnuzDej)
{
    double IAEFagbwI = 758691.3981429898;
    double rXwSQun = -350768.13849912083;
    bool UMheVTGAnMZCEug = true;
    double tweMZHCoNZ = -787565.9455829868;
    bool myOmLN = true;
    double sYbqgktaGLy = 592747.7066617246;
    bool ulBQz = false;
    string NVLwZvjPTefKgVE = string("UiUuDxlhSVgojDwebMYigkeBZQqysGtrpVGRXDVVEXLGdvlCVIqTLAryHSSpmyWixHWJPkaDAXeyefuhpEkOpLlRPRTpVWyhwhJQqOsjVueUNVcCMbYCzcurMpuOPOKFHcdZPVaeehaZWx");
    bool VZuvIiSPO = false;
    string yxENaQ = string("zAKUpEFPyQEAlIuLheaegIgnLvvgYdmNaUTUoVbzDKHJksjWODhnNFxkQaIixYItdmonlpTJowWlRBLDDAouXBAxgsBFYylShXCpmhPfBWhyteIHEOeviXHXKlFVoqTEBNpMUhcjMDinqNU");

    for (int DnTFO = 998364328; DnTFO > 0; DnTFO--) {
        UMheVTGAnMZCEug = WPgDRnuzDej;
        rXwSQun *= wjgYBoHlnuZyIlo;
        ulBQz = VZuvIiSPO;
    }

    for (int diwkaEEB = 2091182005; diwkaEEB > 0; diwkaEEB--) {
        IAEFagbwI = wjgYBoHlnuZyIlo;
    }

    for (int cRTlVLCr = 2079632461; cRTlVLCr > 0; cRTlVLCr--) {
        IAEFagbwI /= wjgYBoHlnuZyIlo;
        WPgDRnuzDej = WPgDRnuzDej;
        ulBQz = ! VZuvIiSPO;
    }

    return sYbqgktaGLy;
}

bool SUDrRxCegxwDdRlF::yPucUMBdjBPP(bool mgiAbHn, double VvHbVddJL)
{
    string zLCCLeo = string("yFkjtMQOIZiIXnZFvXE");

    if (mgiAbHn != true) {
        for (int wxbDv = 350723273; wxbDv > 0; wxbDv--) {
            mgiAbHn = ! mgiAbHn;
        }
    }

    return mgiAbHn;
}

double SUDrRxCegxwDdRlF::hWfCfFtAamjtItkS(double KNGwvlwiYDqu, int aEWYjfHa)
{
    int jeikCXWNQykfDn = 1105298768;

    if (KNGwvlwiYDqu <= 41875.55960876275) {
        for (int yXyEGIxiUhTuIMaQ = 714971351; yXyEGIxiUhTuIMaQ > 0; yXyEGIxiUhTuIMaQ--) {
            aEWYjfHa *= jeikCXWNQykfDn;
            jeikCXWNQykfDn = aEWYjfHa;
            KNGwvlwiYDqu = KNGwvlwiYDqu;
            aEWYjfHa /= aEWYjfHa;
        }
    }

    return KNGwvlwiYDqu;
}

void SUDrRxCegxwDdRlF::pWnaInYsiLs(double AsnMfLermRYeiBzU)
{
    int hNogwVzZl = -1426342580;
    string auremtzYn = string("sXiubnDKeURBYjqeMUesChqozQaivJPzZGnVghoVDPBgpM");
    double QXFiSxeQvSiQ = -498465.81742154545;
    bool LxIVPw = false;
    int wVzJKyByAgWlWC = -293074345;
    int Fvfbk = -1814794016;
    int SnnPbir = 804103752;

    for (int YhfAEtrYMajjMR = 85844423; YhfAEtrYMajjMR > 0; YhfAEtrYMajjMR--) {
        continue;
    }

    if (Fvfbk != -1426342580) {
        for (int WdKCPaxCQZKPd = 900703379; WdKCPaxCQZKPd > 0; WdKCPaxCQZKPd--) {
            Fvfbk /= SnnPbir;
            AsnMfLermRYeiBzU += AsnMfLermRYeiBzU;
            SnnPbir = wVzJKyByAgWlWC;
        }
    }

    if (hNogwVzZl != -1814794016) {
        for (int CoJZNntBQklBHIm = 2003017101; CoJZNntBQklBHIm > 0; CoJZNntBQklBHIm--) {
            hNogwVzZl *= SnnPbir;
        }
    }

    if (wVzJKyByAgWlWC == -1814794016) {
        for (int wqzuVc = 1440123528; wqzuVc > 0; wqzuVc--) {
            SnnPbir /= wVzJKyByAgWlWC;
            SnnPbir -= wVzJKyByAgWlWC;
            LxIVPw = LxIVPw;
            SnnPbir -= wVzJKyByAgWlWC;
        }
    }

    for (int EPZyQdelXy = 677164783; EPZyQdelXy > 0; EPZyQdelXy--) {
        AsnMfLermRYeiBzU = AsnMfLermRYeiBzU;
        Fvfbk += SnnPbir;
    }
}

bool SUDrRxCegxwDdRlF::lApnVZX(int rUozkorpPDvdnTgZ, double MyBMVgLcRn, int nbLrHId, string ghzToUyB, int RIqKrik)
{
    string dQXPheIU = string("AyrNphhnHnVqtVCjPOvRTAoOzwgPdJpZfqcVFmmVlCHVhRQwSemgRZjTEzGdZUNgVQZYmLXNohvwKGMtNKIIvwXmYgYYoeQWkYEVJGkrVOXsvsXdXmdIhoULPAsBcRAshNKnsXUqSpnfwvcQQauwdJqGFIZFOIiycThxQwXqbILMJLrWDZoypEpNdN");
    double EFKMGjTzOXvTfW = 915640.3515476817;
    bool aVRbiUTE = true;
    string VXxsHqTajFz = string("RMQVRQ");
    int mqYlCTTmSqWOGhF = 1184859134;

    return aVRbiUTE;
}

string SUDrRxCegxwDdRlF::BiFPmOJI(string cdbfInd, double DssIrfYBUMv, double dlJvhTZokjNwXlDW, int nQBnY)
{
    double PnGCZHUwVTnG = -9025.567230154464;
    double sewwxijAZjv = 884736.9490726789;

    if (dlJvhTZokjNwXlDW < 830422.382080229) {
        for (int CDDiVlAUo = 1546314217; CDDiVlAUo > 0; CDDiVlAUo--) {
            sewwxijAZjv = sewwxijAZjv;
            PnGCZHUwVTnG -= sewwxijAZjv;
            DssIrfYBUMv += PnGCZHUwVTnG;
            PnGCZHUwVTnG /= PnGCZHUwVTnG;
        }
    }

    if (PnGCZHUwVTnG <= 884736.9490726789) {
        for (int RzfMiXyWzH = 1906474425; RzfMiXyWzH > 0; RzfMiXyWzH--) {
            dlJvhTZokjNwXlDW += dlJvhTZokjNwXlDW;
            dlJvhTZokjNwXlDW = dlJvhTZokjNwXlDW;
            DssIrfYBUMv += sewwxijAZjv;
            PnGCZHUwVTnG *= sewwxijAZjv;
        }
    }

    for (int aGaSKpIzOoPsK = 395877982; aGaSKpIzOoPsK > 0; aGaSKpIzOoPsK--) {
        DssIrfYBUMv = sewwxijAZjv;
        dlJvhTZokjNwXlDW -= PnGCZHUwVTnG;
    }

    if (sewwxijAZjv <= -626553.803310848) {
        for (int wZaUjzOpVpr = 626661112; wZaUjzOpVpr > 0; wZaUjzOpVpr--) {
            sewwxijAZjv += DssIrfYBUMv;
            sewwxijAZjv = dlJvhTZokjNwXlDW;
            DssIrfYBUMv *= sewwxijAZjv;
            DssIrfYBUMv -= DssIrfYBUMv;
            dlJvhTZokjNwXlDW -= sewwxijAZjv;
            dlJvhTZokjNwXlDW /= DssIrfYBUMv;
            dlJvhTZokjNwXlDW += dlJvhTZokjNwXlDW;
            DssIrfYBUMv /= dlJvhTZokjNwXlDW;
        }
    }

    if (PnGCZHUwVTnG >= 830422.382080229) {
        for (int PsAMoClPao = 738224554; PsAMoClPao > 0; PsAMoClPao--) {
            PnGCZHUwVTnG /= DssIrfYBUMv;
            PnGCZHUwVTnG /= DssIrfYBUMv;
            DssIrfYBUMv = DssIrfYBUMv;
            cdbfInd += cdbfInd;
            PnGCZHUwVTnG += dlJvhTZokjNwXlDW;
        }
    }

    if (cdbfInd > string("qJGrqkFpgDiVrUrknJsaYmliXNgLZcUhGXrlvpbRCyhNhZMLdYMupcgVJUZsHBfaOSyKYTvhpzZIeUtVksgIpKsXCMGSGWjoqHoRYqcRuxZkFMmIjioyRurrjIQTGMdIgqxiyUhsRpQOJXitRpFSuQzVvRMrLbdvcKBWZwIq")) {
        for (int drWnXaLF = 1332120090; drWnXaLF > 0; drWnXaLF--) {
            PnGCZHUwVTnG /= DssIrfYBUMv;
            dlJvhTZokjNwXlDW /= sewwxijAZjv;
        }
    }

    for (int GZtWNqFbploTMr = 785400870; GZtWNqFbploTMr > 0; GZtWNqFbploTMr--) {
        PnGCZHUwVTnG *= DssIrfYBUMv;
        PnGCZHUwVTnG = PnGCZHUwVTnG;
        PnGCZHUwVTnG -= dlJvhTZokjNwXlDW;
    }

    return cdbfInd;
}

double SUDrRxCegxwDdRlF::BZGLV(double OZamiVQwmKaS, double ajyTP)
{
    double ytSgL = 60565.96310066338;
    string bRVqOxIHFjamlzsW = string("gmxOaDAFbtBhFxGYkFskfjFlRaLnGMyKWFRRHKAiziMEJzg");
    double JeiAfoAMpSQgHdW = -204.966589219547;

    if (OZamiVQwmKaS >= 60565.96310066338) {
        for (int smqlxZl = 1195545923; smqlxZl > 0; smqlxZl--) {
            ajyTP *= ajyTP;
        }
    }

    if (ytSgL < 60565.96310066338) {
        for (int KFeoQlizZo = 1922099441; KFeoQlizZo > 0; KFeoQlizZo--) {
            JeiAfoAMpSQgHdW *= JeiAfoAMpSQgHdW;
            JeiAfoAMpSQgHdW += JeiAfoAMpSQgHdW;
        }
    }

    for (int elqhzKVNcYtFQpLF = 1839943375; elqhzKVNcYtFQpLF > 0; elqhzKVNcYtFQpLF--) {
        OZamiVQwmKaS += ajyTP;
        OZamiVQwmKaS = OZamiVQwmKaS;
    }

    return JeiAfoAMpSQgHdW;
}

SUDrRxCegxwDdRlF::SUDrRxCegxwDdRlF()
{
    this->obGJb(1635804203, true);
    this->RBltBSxeC(-1080744064);
    this->DnXNlBjDGiBS(string("KyAuJwCRfcelJMqgOEGWEgZxuNTomKjGU"), false);
    this->wHpBAmx(false, true, string("GPrbwdEjLjFFdnYAKiIzDsupNnDKmYtXsdWMmRxcHwcINvyOlrKblTUgkBKiGosCsXVaxNgIAAxxUmKRkhfHYOxqGXPvMYkAFXwwNJPGvxnwic"), string("wCSurLeeymmSbhsjRPwbYNdYbmyeIqW"));
    this->DkSCSJ(911423.8179080926, 1026010.3741579728, false, string("vAaRFMhjvFpyHRCHwQILxFLgFlZcKVLtdzpKhlsscinhCKgHBcFeFUoSlwhOvfttopHGDjljVYQqlzyHbFvOhGhcxCtqbiuwjqtKDMpJksCNPurwJltMQOcjyfQGexJUauzejrZhlBJVFAVoAWsHgoPDXPuGcOVBMvwzDWzegjohUhyGQUsNUPDJWMWPuTp"), -916080720);
    this->wkAcJqnNd(1823143015);
    this->PYHYlkZtIRbQgzr();
    this->tGLFR();
    this->PLFDzGByQKVoSwgA(-885441.7046621424, 852616594, string("hhSYAzvGGhFocFAdrHiZCYmDYQFmlLmcVwereDnNAWgRzwsEqHWoQiutMFdkZvecWQeKfqbEYqDbJmznuyjnIXprKkREPsusWlNpvWfNmVWuoCJdHmofVJhFPIfszBlWOlnJAThdNECzgCqUdFuSYONdLeAnxTnDGNhrr"), true);
    this->yPucUMBdjBPP(true, 833507.4897766232);
    this->hWfCfFtAamjtItkS(41875.55960876275, -417740894);
    this->pWnaInYsiLs(246428.56603155096);
    this->lApnVZX(-123251239, -533452.2739634236, -919790994, string("IAfXQSgRaxjsEXOflmwlOBwmSNzOdXdnQMvujbahOaXKmQApULMVfxyrfylXUBkSrdLziIIUeYVZrfVuRCMCyeNkVqhQQZGcfkUskGmZdorPJoOdcjeFIbLdztjDKOc"), 1655727284);
    this->BiFPmOJI(string("qJGrqkFpgDiVrUrknJsaYmliXNgLZcUhGXrlvpbRCyhNhZMLdYMupcgVJUZsHBfaOSyKYTvhpzZIeUtVksgIpKsXCMGSGWjoqHoRYqcRuxZkFMmIjioyRurrjIQTGMdIgqxiyUhsRpQOJXitRpFSuQzVvRMrLbdvcKBWZwIq"), -626553.803310848, 830422.382080229, 1085311071);
    this->BZGLV(815329.4525099958, -469694.4202563211);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DqQTxJVzsL
{
public:
    string VKNoeeCe;

    DqQTxJVzsL();
    double nwPpTNYiwFygFCf(bool VBdRbeUV, int GAyDWE, bool WIBEH, double khomoin, string RMLrZI);
    bool ReRJlBqTVVeOzu(bool IMkEgAx);
    void SOeCquzB(string JerMcKvp);
    double uiNHf();
    string yAzTqHBHcPtQlfoV(int tYtrUDb, double SScMmeeFAfwjE, string uchuY, bool lSipbsjQTbATn);
    bool aewHEdFeFNWxI(string PAxpDpL, string gYTcBPvkQKqL, double QbrbFZeCidK, bool UsLqHQ);
protected:
    int nXGmBAQPWUvsTPQ;
    double BFChQEQMhKPdF;

    string EnuWlrtHVJW(double MDvBnqjNxH, bool yWfezB, string zGhQajQxoafS);
    bool RNbhejOeLLHweiux(double qAZxdponYjkcwrYZ, double JaMiWKipun, double nBydqRSn);
    double KuhkHukbp(int UbGwYOItVIJTi, int fRfknfFVtyQfcK, double mSsockDWWVMxOi, bool FxhQwSuluytC, bool IacutODRSWRI);
    int cdmKqeRpolvbHA();
private:
    bool oKfNkYb;
    double PDGuMhcDyt;
    int DTbNsii;

    int KruThc(string RzySFOsMF, int TnbHUP);
    void tHcqDsF(string SURMfHhOg, int uQRDjSBuMgcJTnWN, int jwLAk);
    bool rkxcwMJvczzLMHUL(double zylEVzUUvjLvVOz, double qNGuhHhilRQ, int OusSKgzLIYFSwX);
    bool igqiovrwJ(double IcvldfgNqmK, int jFXYcsTtPR, string NKdMR, bool RZbCP);
    string KzKLXtWL(string VurBeLdkyNEl);
};

double DqQTxJVzsL::nwPpTNYiwFygFCf(bool VBdRbeUV, int GAyDWE, bool WIBEH, double khomoin, string RMLrZI)
{
    double OISrVQ = -526604.7544414211;
    int btJutglmKTXXh = 1512767984;
    int hsAzQkWYBERcMM = -1755262349;
    double EAqlqW = 654843.3698118192;
    bool vISHXsQBtRA = true;
    string fwFUXCDjwRkAzNU = string("AtBWiNTGdLqeFOygIWheeaTLwfnLoRsvIzPfUFjccojeptwRIHyqWqImUpnoUuCakBvdedesgxqwUfuXAUNEGprcOsHJgYWfcAyCmaLpDSNZpZSJRqYLlLdmBszkWxNaHdkHmhrlvLHKEeKXZtGCjIkJmvJqYBxqiVRHgtFoyUhaOrLiQEXCSVg");
    double smxlhxp = 265038.6595934091;
    string SkuJcMQ = string("kAXAuCnwMjUUJDEIYGCjQxcIpACECYfbRmbTHTvWFECoMtZbAOShlXCpLxPCpJuQQuSPblwVREWtJObcvGVGBjbNDQKYTbcWeKdgWbHbMoEJPLmsKdwTvgCynySLPrQaYMYwhUyGxtkMDXfstOXodCggOMlmcyKCDShGbuIOWucHVEpgnvvLLVYrikrYASWxgbnMGXsaDQXvOTNVHfWhikeKXiIFTBsxwpOvJAAMhCvIgdavSErcf");
    double EjgylrthvfQaJZ = -865557.3160145708;

    return EjgylrthvfQaJZ;
}

bool DqQTxJVzsL::ReRJlBqTVVeOzu(bool IMkEgAx)
{
    string NDYnjfpttGwpUP = string("aEhXIqWlbgNDsqqtTdkHWJdwSRvrrcvfNrjjYOLVpqWqgKmqhWPMSnYdDUuwrTnDCkYYlZUOampqHCRfFYMCXbuFYdsDJfuyzOWsCa");
    string iOLUJLFY = string("rovXQNMLuEVubOkGMtlnzIxAbnnylBqtAssIQrQkXvhSJLmQNenojhfGCRgYHEcPhyoDPCuKQYCUmGvkyqibMIKhjdDqqZynfOmlBkJakqBLrdQdRIobjfNaPIdDgIGypGoEDAnxNRNLIqJGZLIuwoAKldDZPMScrlvEWBZkphKqRsYuasSfi");
    bool EqyPGCzcK = true;
    string BGcDxTdBAJ = string("BuBrWzqpQ");
    bool XlNnBlFzU = false;
    double WoKzKH = 673742.400976174;

    for (int pUDdBAcStn = 1980575432; pUDdBAcStn > 0; pUDdBAcStn--) {
        XlNnBlFzU = ! EqyPGCzcK;
        EqyPGCzcK = ! EqyPGCzcK;
    }

    return XlNnBlFzU;
}

void DqQTxJVzsL::SOeCquzB(string JerMcKvp)
{
    bool rMNxZIXJPFKKOW = true;
    bool yTGCmpsL = true;
    int SIiAXCsvmdtdQxno = 540461150;
    double FINXKSEuyG = 421980.40644491906;
    int ihSvnXZhuciWE = -911027219;
    string NgLNzgijDiZ = string("hkljSFhReHivtRXDwRapjkUoeItNnCutKvO");

    if (yTGCmpsL != true) {
        for (int konFZAgpJySlL = 1323722006; konFZAgpJySlL > 0; konFZAgpJySlL--) {
            JerMcKvp = NgLNzgijDiZ;
            SIiAXCsvmdtdQxno *= ihSvnXZhuciWE;
        }
    }

    for (int EmTmnprWxjgcWgI = 1211883204; EmTmnprWxjgcWgI > 0; EmTmnprWxjgcWgI--) {
        JerMcKvp = JerMcKvp;
        SIiAXCsvmdtdQxno -= SIiAXCsvmdtdQxno;
    }

    for (int IAYobHS = 424561053; IAYobHS > 0; IAYobHS--) {
        continue;
    }

    if (SIiAXCsvmdtdQxno != 540461150) {
        for (int nPNvXUXR = 878281887; nPNvXUXR > 0; nPNvXUXR--) {
            rMNxZIXJPFKKOW = rMNxZIXJPFKKOW;
        }
    }

    for (int oGAqcOtq = 1546562381; oGAqcOtq > 0; oGAqcOtq--) {
        rMNxZIXJPFKKOW = yTGCmpsL;
    }
}

double DqQTxJVzsL::uiNHf()
{
    bool jpgWrda = true;

    if (jpgWrda != true) {
        for (int SIXnKiFksSqBw = 2096773047; SIXnKiFksSqBw > 0; SIXnKiFksSqBw--) {
            jpgWrda = ! jpgWrda;
            jpgWrda = jpgWrda;
            jpgWrda = ! jpgWrda;
            jpgWrda = ! jpgWrda;
            jpgWrda = jpgWrda;
        }
    }

    if (jpgWrda == true) {
        for (int DSVplnpMlLGOQGkN = 2094398214; DSVplnpMlLGOQGkN > 0; DSVplnpMlLGOQGkN--) {
            jpgWrda = ! jpgWrda;
            jpgWrda = ! jpgWrda;
            jpgWrda = jpgWrda;
            jpgWrda = ! jpgWrda;
            jpgWrda = ! jpgWrda;
            jpgWrda = jpgWrda;
            jpgWrda = jpgWrda;
            jpgWrda = jpgWrda;
            jpgWrda = jpgWrda;
            jpgWrda = jpgWrda;
        }
    }

    return -1023169.644353769;
}

string DqQTxJVzsL::yAzTqHBHcPtQlfoV(int tYtrUDb, double SScMmeeFAfwjE, string uchuY, bool lSipbsjQTbATn)
{
    string vTFuMqTx = string("QCsPXfqcrxXXGlfvjcixIMGqkpgqtwEWZvDwrSbfMfxxceHeYIgTRnimMeLiUTbdhFoBWmwUPuGvjyFqphzACqLrMeLLW");
    double FtogG = -935786.32287272;
    string cPRXsTjizoIn = string("YAjEIXyPFDkJqZzRiDIXFKpHbBNHtcAkUYHDYsXosFJnyJLiXkKmHWGYEiVYWHRzGiMgFgPBXuLIKHRrlqrEDtYNBkkjtCiqKvzCIGmXEtbIRJuQtMddsDCHMTzRXykDVqwsPiKMgSqMZEBgPlqCPlnHNVdLjrHJcLIJSGFnGxVvbO");
    bool AcGxv = true;
    double XmeFzW = -866082.1568982641;
    int OzgYaIHUOROC = 2095056508;
    int CNcHZK = -1758397050;
    string ShzUk = string("mbHjNgUjnaitNxbdbUosqxUSStsMFZcxughWApTpiNSN");
    string lEyEnITtAbYsDB = string("cnQzhhLpmdKXzidlcQMByYACovgpVsABgDLDTbKtogWGOgQyMIBKSkdBSBPZGEKqQYMVcYKiQDLYscaARFJNmmdvqwcrcyMEcQMceEcCwpuYCcIGbUqoXqcAAQGQQbTEa");
    int lytcJqEUAYxTnpI = 36433420;

    for (int VerNz = 1897156142; VerNz > 0; VerNz--) {
        continue;
    }

    for (int DmHUbF = 242351979; DmHUbF > 0; DmHUbF--) {
        FtogG -= FtogG;
        CNcHZK += CNcHZK;
        CNcHZK -= CNcHZK;
    }

    for (int UPraWn = 1123465352; UPraWn > 0; UPraWn--) {
        continue;
    }

    return lEyEnITtAbYsDB;
}

bool DqQTxJVzsL::aewHEdFeFNWxI(string PAxpDpL, string gYTcBPvkQKqL, double QbrbFZeCidK, bool UsLqHQ)
{
    int UQNhCLsJTxwjuRZ = -61902408;
    string rkCyf = string("XJYDGVSueGsUrrQJXxabPvoW");
    bool hgGdH = false;

    for (int GpjZgiOyj = 1113982279; GpjZgiOyj > 0; GpjZgiOyj--) {
        PAxpDpL = gYTcBPvkQKqL;
    }

    for (int FYdzkWHTSXTZfHPw = 912365507; FYdzkWHTSXTZfHPw > 0; FYdzkWHTSXTZfHPw--) {
        UsLqHQ = ! hgGdH;
    }

    return hgGdH;
}

string DqQTxJVzsL::EnuWlrtHVJW(double MDvBnqjNxH, bool yWfezB, string zGhQajQxoafS)
{
    bool iSMKoOlJfBE = true;
    int swDuxYWEhLFebIO = 721874831;
    bool DiYLtORdkPPwXjM = false;
    bool kLDdppaz = false;

    for (int YqVtux = 1777823560; YqVtux > 0; YqVtux--) {
        DiYLtORdkPPwXjM = ! kLDdppaz;
    }

    for (int wDWQYNbgWb = 655196820; wDWQYNbgWb > 0; wDWQYNbgWb--) {
        kLDdppaz = ! yWfezB;
        DiYLtORdkPPwXjM = iSMKoOlJfBE;
        swDuxYWEhLFebIO *= swDuxYWEhLFebIO;
        kLDdppaz = DiYLtORdkPPwXjM;
    }

    if (iSMKoOlJfBE != false) {
        for (int uUElBUVvXG = 1133788783; uUElBUVvXG > 0; uUElBUVvXG--) {
            yWfezB = ! DiYLtORdkPPwXjM;
            iSMKoOlJfBE = kLDdppaz;
        }
    }

    for (int LooYfSHi = 1101062547; LooYfSHi > 0; LooYfSHi--) {
        iSMKoOlJfBE = DiYLtORdkPPwXjM;
    }

    return zGhQajQxoafS;
}

bool DqQTxJVzsL::RNbhejOeLLHweiux(double qAZxdponYjkcwrYZ, double JaMiWKipun, double nBydqRSn)
{
    bool vcTmkaKyXTlA = false;
    int TnBhdCq = 1535887861;

    if (JaMiWKipun <= -469053.81073905993) {
        for (int UxErToLQLFJqKmT = 1377372524; UxErToLQLFJqKmT > 0; UxErToLQLFJqKmT--) {
            JaMiWKipun = nBydqRSn;
            TnBhdCq /= TnBhdCq;
            JaMiWKipun -= nBydqRSn;
            nBydqRSn -= nBydqRSn;
        }
    }

    if (JaMiWKipun > -469053.81073905993) {
        for (int XWsFLINstGHXIVK = 233015851; XWsFLINstGHXIVK > 0; XWsFLINstGHXIVK--) {
            TnBhdCq += TnBhdCq;
        }
    }

    if (JaMiWKipun != 531557.2315866697) {
        for (int lNnAdujZSbFZgli = 1165397505; lNnAdujZSbFZgli > 0; lNnAdujZSbFZgli--) {
            continue;
        }
    }

    return vcTmkaKyXTlA;
}

double DqQTxJVzsL::KuhkHukbp(int UbGwYOItVIJTi, int fRfknfFVtyQfcK, double mSsockDWWVMxOi, bool FxhQwSuluytC, bool IacutODRSWRI)
{
    double lkntsl = 857767.8504227964;
    string AmcayDOGTTP = string("SoVYzMcQJUVSdrwXPyIjphuObvXpRpNHSYFScJkxpElnvRsFPZRxsXaNoDQPLMlOBETcJCHUpJAEkqPCPNfAzuvHcgmJWyRbCAWDRpVKYzSJnjzgFWLJkpo");
    double KYgRQtSthfHtTA = -1008670.8300594167;

    if (KYgRQtSthfHtTA >= -385595.85288110987) {
        for (int UPhvKOXPAUiu = 1490741681; UPhvKOXPAUiu > 0; UPhvKOXPAUiu--) {
            IacutODRSWRI = ! IacutODRSWRI;
        }
    }

    if (FxhQwSuluytC != false) {
        for (int RGAGeAQZUTs = 1089027277; RGAGeAQZUTs > 0; RGAGeAQZUTs--) {
            lkntsl /= KYgRQtSthfHtTA;
        }
    }

    for (int FKsms = 420586758; FKsms > 0; FKsms--) {
        continue;
    }

    for (int zVOwImGyOXn = 1101343341; zVOwImGyOXn > 0; zVOwImGyOXn--) {
        lkntsl /= KYgRQtSthfHtTA;
        KYgRQtSthfHtTA += KYgRQtSthfHtTA;
        KYgRQtSthfHtTA = KYgRQtSthfHtTA;
    }

    for (int pkcXyvK = 352516067; pkcXyvK > 0; pkcXyvK--) {
        KYgRQtSthfHtTA += mSsockDWWVMxOi;
        mSsockDWWVMxOi -= lkntsl;
        lkntsl = mSsockDWWVMxOi;
    }

    return KYgRQtSthfHtTA;
}

int DqQTxJVzsL::cdmKqeRpolvbHA()
{
    double xnNgGx = 345992.5332967902;
    int UGDdEsCENbmdtDuq = -876485015;
    double BWaArVFNCiSCs = 713859.6032702627;
    string UErHTyfHeZW = string("QjqslPMXsZbsuekklJfxElZahMJGTgyjnxJwhmYwkKAieWwWJvPWZymjyVXODxQlOAfyPwzJlZJdjoNnOoDBGkDiVKDSgiqDcPxBfCWHjpIGiPqUtJALbXQkdgUICqjliNahyOQSiaKyFIhHnSZPdBcEQFnwPhixomzLpugePaQToLxPdhuBw");
    bool PQuoJvF = false;
    double TyyCIUwb = -190998.61343401473;
    bool dRGMC = true;
    int aWhyredsboBV = 2112541413;
    bool JZuDYWEFPG = true;

    for (int ApIDmirFmp = 959909603; ApIDmirFmp > 0; ApIDmirFmp--) {
        PQuoJvF = ! dRGMC;
        xnNgGx = TyyCIUwb;
        JZuDYWEFPG = ! dRGMC;
    }

    for (int fxBHAhDHc = 602702156; fxBHAhDHc > 0; fxBHAhDHc--) {
        dRGMC = dRGMC;
        UErHTyfHeZW = UErHTyfHeZW;
    }

    for (int AAmxjvxzo = 1855681059; AAmxjvxzo > 0; AAmxjvxzo--) {
        BWaArVFNCiSCs *= xnNgGx;
    }

    return aWhyredsboBV;
}

int DqQTxJVzsL::KruThc(string RzySFOsMF, int TnbHUP)
{
    bool BJFumDoUcJneZjoi = true;
    string QeulZquegJYieZ = string("SZIdmgJBimrmLhGOMnNgsTopvqlsexvOLlDnaHkdteuJnjHdKTfCEZAdeDtkKzhQtnMxlWoLpJOmJHYxPSBfyzbPMBblpZcVfpJaOnaMMpgzEKwuPToACnuNiThtcChJwnkUNYQD");
    string jOXibFFBdC = string("mtuyoNuRxfsItMTnchsFkjLisZERskrIOXxUGGzt");
    int VlQvrlJuU = 66745542;
    bool RQRYOGYOOBnz = false;
    bool EsUYZiSsecQoMIs = false;
    bool kiurIsrrHl = true;
    int rLiCAJGri = 1050369157;

    if (kiurIsrrHl != false) {
        for (int NYYnwLEXhjD = 1411492350; NYYnwLEXhjD > 0; NYYnwLEXhjD--) {
            rLiCAJGri += rLiCAJGri;
            RzySFOsMF = jOXibFFBdC;
            VlQvrlJuU *= TnbHUP;
        }
    }

    return rLiCAJGri;
}

void DqQTxJVzsL::tHcqDsF(string SURMfHhOg, int uQRDjSBuMgcJTnWN, int jwLAk)
{
    int PNCEtSqesmgxk = 393125442;
    int AJddUkWET = -850091535;
    bool mISSuYWGIZuXqX = false;
    bool jMJuzsTCD = true;
    bool RwFVdF = false;
    bool NfGbpDsolVdv = true;
    double ofEVcSRQWfUWPZ = 326472.46512132604;
    int apGlOWnSAHuZiA = 1573141961;
    bool qoObfltPAoVcyb = true;

    if (apGlOWnSAHuZiA == -850091535) {
        for (int UHKdCVFdFZl = 507347521; UHKdCVFdFZl > 0; UHKdCVFdFZl--) {
            RwFVdF = qoObfltPAoVcyb;
            AJddUkWET *= jwLAk;
        }
    }

    for (int AwyMMTsGIoU = 1475071436; AwyMMTsGIoU > 0; AwyMMTsGIoU--) {
        PNCEtSqesmgxk = PNCEtSqesmgxk;
        PNCEtSqesmgxk *= apGlOWnSAHuZiA;
    }
}

bool DqQTxJVzsL::rkxcwMJvczzLMHUL(double zylEVzUUvjLvVOz, double qNGuhHhilRQ, int OusSKgzLIYFSwX)
{
    int jtDKXh = 1281720578;
    bool WdxuHwrVNWa = true;
    double LGCdgrFvrKDkqwbO = 343454.95127859106;
    string JgzWJYQI = string("ygOPIMQstWZrvHsBWelqvsCBqeiAzUjrvhNZFmijVpfgLNHyhukiFEHxcjRUqGOpMvLZTmobOAHEsUnXFwfhErkZYmWddJuAMzlwFLSWzOxiUTskYGzHUoyBeRYPEGJrBtqHtjrzNWBtzWEmabvmqP");
    bool UHOvtjD = true;
    double TJGjjxaYUSq = 541243.2560780323;
    int nOcCxQmlB = 1117750235;

    if (UHOvtjD == true) {
        for (int JlAxVTGyQMz = 1856596508; JlAxVTGyQMz > 0; JlAxVTGyQMz--) {
            continue;
        }
    }

    for (int kVnVz = 1930360738; kVnVz > 0; kVnVz--) {
        OusSKgzLIYFSwX /= nOcCxQmlB;
    }

    if (jtDKXh == 1049585034) {
        for (int prXLyCi = 33063132; prXLyCi > 0; prXLyCi--) {
            JgzWJYQI = JgzWJYQI;
            qNGuhHhilRQ = zylEVzUUvjLvVOz;
            zylEVzUUvjLvVOz *= TJGjjxaYUSq;
            OusSKgzLIYFSwX -= OusSKgzLIYFSwX;
        }
    }

    for (int mtXnw = 1689756784; mtXnw > 0; mtXnw--) {
        zylEVzUUvjLvVOz *= LGCdgrFvrKDkqwbO;
        OusSKgzLIYFSwX = jtDKXh;
    }

    return UHOvtjD;
}

bool DqQTxJVzsL::igqiovrwJ(double IcvldfgNqmK, int jFXYcsTtPR, string NKdMR, bool RZbCP)
{
    int mVjdWwivVXCWgkW = -1906687271;
    bool CJjyiRCaYlCi = false;
    bool cAEhqHEKOB = false;
    int LVgADfWiZO = 8569098;
    bool AOotvYJBfL = true;
    int InPyOXJiScckx = -1535569426;
    int LPJQJwnzR = -1917606004;
    double tvwBUrJuu = 418868.6733565549;
    double QrqtihJEzdXiHYB = -337533.49896669877;
    double OmRzbvxAMyxAxgC = -286886.0815591173;

    if (AOotvYJBfL == false) {
        for (int BNmTk = 302666395; BNmTk > 0; BNmTk--) {
            continue;
        }
    }

    return AOotvYJBfL;
}

string DqQTxJVzsL::KzKLXtWL(string VurBeLdkyNEl)
{
    string ZnkhmsdKuVAjy = string("CefhncmOEjwrzbLZ");
    double oDGCzoiqdBpdtR = 194335.13158565463;
    double fTrtkSbKgau = -810607.5409446834;
    bool cYNhwAoKSubTJQ = true;
    string mEQGJEWseZBsxuTN = string("yQkzKHmQFJJwPZrhdhqMOzKROmgJgEAMDzaTPBgdkpkQDGrSIbCZnKLWdpaLZYGSqWuYfcoIkmllZZYoyRTwRQUaMOKVNEEkKpoCIUisizmDWUrWMVFYxzWzbvSECARaHEnVjnQDQDEZxQLNwDRWKwmvTrYsfEomACpSoZZbZdCeWAqjCpTUTlGVlYGhwQPwZyAGgnJHoZJkFXcoZjMonEBxOyVyzqcpdCjDYMklXHZZiT");
    int EXppzFgFwxUtgCz = -19513461;
    int ZBmiUlu = 1523982858;
    double yqmDVd = -244769.83801317378;

    for (int yonstISJweoQlf = 402056540; yonstISJweoQlf > 0; yonstISJweoQlf--) {
        ZnkhmsdKuVAjy += mEQGJEWseZBsxuTN;
        oDGCzoiqdBpdtR -= oDGCzoiqdBpdtR;
        oDGCzoiqdBpdtR *= yqmDVd;
        cYNhwAoKSubTJQ = ! cYNhwAoKSubTJQ;
    }

    for (int zlYMcXAxIej = 2095466146; zlYMcXAxIej > 0; zlYMcXAxIej--) {
        yqmDVd -= fTrtkSbKgau;
        EXppzFgFwxUtgCz -= ZBmiUlu;
        EXppzFgFwxUtgCz *= EXppzFgFwxUtgCz;
        EXppzFgFwxUtgCz += EXppzFgFwxUtgCz;
        fTrtkSbKgau -= fTrtkSbKgau;
    }

    for (int zUJWhUAPSiKITq = 1158077221; zUJWhUAPSiKITq > 0; zUJWhUAPSiKITq--) {
        mEQGJEWseZBsxuTN += VurBeLdkyNEl;
    }

    return mEQGJEWseZBsxuTN;
}

DqQTxJVzsL::DqQTxJVzsL()
{
    this->nwPpTNYiwFygFCf(false, -905078470, true, 592262.4325090296, string("QzuBfXoiPBXJSwbmLAYkrrwUhufRezxYdadQulsfOBAIyKyHbEwcOFwdaAheNbrgQGebBgqPvrqncKOrCsfqDuDeJZVHNhDuBwSEclSNuQilWGvXpMOBBnyAPWNqRanBIATyDNrmvgtXfFUHiUFhZIYgAnrzHYVEDDXOYnbhIjRDucueAryf"));
    this->ReRJlBqTVVeOzu(false);
    this->SOeCquzB(string("IQsmMTgWliHUjvlrwqnhdaShLjshXQBcXxQIYOfPYqMQjWGpWqJDkhYxllMTOZCLaBelHifosNFTheIAztIDrAULVVmqvscZNwIJkoBOvhMOldYjpCLEdarilhmQojVVJhdbkEkEWhIyhWRfGmqqsKYeFJsBRmttGGoWTQBcOcKQrEcyNgPPWRcCiROPKEODAGHcpXjfhps"));
    this->uiNHf();
    this->yAzTqHBHcPtQlfoV(-1014368972, -234234.218636881, string("vGRjPNHHpaCJsIxYWSzqrecmSdcrccToXeBq"), false);
    this->aewHEdFeFNWxI(string("gldzzEeLdEKQodABWFCrUYEsCjcvvFhWvNVxSZPdmLaXKmRJjurZRzLgfvELLoTpRpsIAWayBFdHBOfgXyOMRCaicWPKURF"), string("CSOToEwvvnwaTJbCXLLzCtroxuJmxAtLHxXExeOJvXqDFSHOxTbpLVcEmOjwqyZrECDWXNEWTQTeMfOvWqOCV"), -80879.60208368191, true);
    this->EnuWlrtHVJW(724231.8208626169, false, string("XFvmXDezEumnhFoWqZNdJrjTMAdaWtvtLSjAmnnHRXxWSZmRSangkiHCIlIaooQdDkiONDypPPGvVdszrojvKUEHwIdnBUwnkXcUQHyuHAGxHAhAgvodUsLJGhHgejUIDOAqqKjQBrmCCZPYJRobtTwqObptltIkjuoRFkUASQCw"));
    this->RNbhejOeLLHweiux(-469053.81073905993, 868839.7075047742, 531557.2315866697);
    this->KuhkHukbp(748090008, -701103803, -385595.85288110987, false, false);
    this->cdmKqeRpolvbHA();
    this->KruThc(string("oVmASPLXKSaLqxIFlmgQlhotabPxjQHLIXANxfKtzzIOvlMLOOujNvKmNjYYWmrqWAyLgRscmjgVwGeAaIeUghJIzKNSIilRoGIHPFWpFzfiPTPYlnppUOmthoMxsZnYQeBJFVoNKjqmdiLdkMbcPibMZKtQgretCgnsuUqajtRmkkEUMehOPoccucQgRhIOjMBDmUGIegqTlIAdqRbSSWB"), 1754162686);
    this->tHcqDsF(string("DTzBKwExSzubSwdEsNZXo"), 1067055010, 346100488);
    this->rkxcwMJvczzLMHUL(-692430.6063196681, -118042.9734960528, 1049585034);
    this->igqiovrwJ(-136858.62851654727, 803802715, string("gxZaePscdDGzBmNdxMrXyngbuglmuFnXoL"), false);
    this->KzKLXtWL(string("PiMvrwzDRQrxFVEBuQMVhYmhgExmQMwOJdRaNdvyJTDGSPWCgiyRTqvXXZDgwNOxAkPXcrLiuXsCUlFCIHsPqseDdoadYESIqtsSSyWSifosnQGqfnkkwYFfcHUaSxWchRDfUpfQklGxNdPaGgOfSqfPdSFMNDPJMsoDDN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WrqsQixmJ
{
public:
    double EpyhKU;
    string zptOokruhxA;

    WrqsQixmJ();
protected:
    int MNxdrUpMcuSoF;
    double nHBHzCU;

    double skAdptyVRJXIKzf(double DFfcgsJeujHK, double qIDearAIOPM, bool QKrDHVrIhZ, int EVDygPiuVIQdEacQ, bool aCIeayOMnBPzy);
    double bdwbXVc(int FOQndGF, bool RxZMv, double iONcpkSnhVTToIb, bool WEhZnkFZw);
    void gxyPlMPhPKS(bool vstbDhoZ);
    double pnVLiUZctEPRFSpw();
    string PkEYDPWHwJ(double iyYRWDdfCTp, string WWZRoMYTl, bool HEPDHLdyFNiEW);
    double oLrGVMYun(bool BKdZiseeav, double cJxOzbc);
private:
    bool cQnFvWXY;
    int UDMNzQuIdFyf;
    double YOActDt;
    string zlHlLzX;
    int gyWhajsaWLa;

    double tAwguJU(bool NIcSXBMDco, double hzkukqIyBMCsd, int uKbRtA, string xjracVAX, string gFoMfCRTm);
    void bhfujllFXNLfX(bool FnRTaz, bool QFosjbEx, double BmQwjdLsEeJT);
    int LGwoSiDKDvKf(bool FlopdaKO);
};

double WrqsQixmJ::skAdptyVRJXIKzf(double DFfcgsJeujHK, double qIDearAIOPM, bool QKrDHVrIhZ, int EVDygPiuVIQdEacQ, bool aCIeayOMnBPzy)
{
    bool qIzEkQiktnOuC = true;

    if (qIDearAIOPM <= -115879.90395814642) {
        for (int sccSrgBD = 992944477; sccSrgBD > 0; sccSrgBD--) {
            qIDearAIOPM *= qIDearAIOPM;
            qIzEkQiktnOuC = qIzEkQiktnOuC;
            QKrDHVrIhZ = QKrDHVrIhZ;
            qIzEkQiktnOuC = ! qIzEkQiktnOuC;
            QKrDHVrIhZ = ! qIzEkQiktnOuC;
        }
    }

    if (QKrDHVrIhZ == true) {
        for (int IrCEsUAxJjcwJM = 768360964; IrCEsUAxJjcwJM > 0; IrCEsUAxJjcwJM--) {
            DFfcgsJeujHK /= qIDearAIOPM;
            QKrDHVrIhZ = ! QKrDHVrIhZ;
        }
    }

    for (int TmhvKh = 259128977; TmhvKh > 0; TmhvKh--) {
        DFfcgsJeujHK *= qIDearAIOPM;
    }

    for (int EjBiQIcjRenNd = 239265409; EjBiQIcjRenNd > 0; EjBiQIcjRenNd--) {
        QKrDHVrIhZ = QKrDHVrIhZ;
    }

    if (qIzEkQiktnOuC == true) {
        for (int ABKAXPyQRmPyNG = 1722739586; ABKAXPyQRmPyNG > 0; ABKAXPyQRmPyNG--) {
            qIzEkQiktnOuC = ! qIzEkQiktnOuC;
        }
    }

    return qIDearAIOPM;
}

double WrqsQixmJ::bdwbXVc(int FOQndGF, bool RxZMv, double iONcpkSnhVTToIb, bool WEhZnkFZw)
{
    int TJhXHdgRlluZecOa = 605888548;
    bool cSLGg = true;
    string ZfVtPOVUuJgR = string("oDXoImeXTcdRAtczpXsVRoDnNzjVzatWoELemuXnsBrYAltFbREegXMBDtCZuFXbRJpYUpcgcKGfShsVQfJLDspJklbMTRRaMOrRbMgDhprbWJfceqOZzzFaxPZhfzbpPsJSJSXCaorMQRTTQzRvWYzjEUxiZkeLZVXApnpvyFZiEVJQZSwyrkRqFRoLrhsuNfINvIpsIlkvtz");
    bool lclPPzQoZWnSKmH = false;

    for (int TQVbytaUa = 1761566543; TQVbytaUa > 0; TQVbytaUa--) {
        cSLGg = lclPPzQoZWnSKmH;
    }

    for (int bJjzREoyD = 1004931314; bJjzREoyD > 0; bJjzREoyD--) {
        TJhXHdgRlluZecOa += FOQndGF;
        cSLGg = cSLGg;
        WEhZnkFZw = RxZMv;
        WEhZnkFZw = ! lclPPzQoZWnSKmH;
        WEhZnkFZw = ! WEhZnkFZw;
        iONcpkSnhVTToIb += iONcpkSnhVTToIb;
        lclPPzQoZWnSKmH = cSLGg;
    }

    for (int BYTnmQ = 950996540; BYTnmQ > 0; BYTnmQ--) {
        cSLGg = RxZMv;
        RxZMv = cSLGg;
    }

    if (iONcpkSnhVTToIb >= -852475.3804653211) {
        for (int EkSqiPVfsrUH = 988826539; EkSqiPVfsrUH > 0; EkSqiPVfsrUH--) {
            cSLGg = ! WEhZnkFZw;
            RxZMv = ! cSLGg;
            ZfVtPOVUuJgR += ZfVtPOVUuJgR;
            cSLGg = ! RxZMv;
        }
    }

    if (RxZMv == false) {
        for (int ByBPrpwx = 390420032; ByBPrpwx > 0; ByBPrpwx--) {
            lclPPzQoZWnSKmH = lclPPzQoZWnSKmH;
        }
    }

    return iONcpkSnhVTToIb;
}

void WrqsQixmJ::gxyPlMPhPKS(bool vstbDhoZ)
{
    double QzWvCYdld = -265214.6545001098;
    bool wsPvwR = true;
    int ZmdSily = 1713623539;
    int paZuhKrmMKmw = 375953751;
    bool ldxRdMshwHZMR = false;
    double nkcsNoUBXOK = -575532.2281957611;

    if (ZmdSily != 1713623539) {
        for (int TsuVOgzYOtlZKhqv = 1428635913; TsuVOgzYOtlZKhqv > 0; TsuVOgzYOtlZKhqv--) {
            vstbDhoZ = ! ldxRdMshwHZMR;
            wsPvwR = ! ldxRdMshwHZMR;
        }
    }

    if (ldxRdMshwHZMR != true) {
        for (int ijPItnJeL = 1094422838; ijPItnJeL > 0; ijPItnJeL--) {
            ldxRdMshwHZMR = ! ldxRdMshwHZMR;
            vstbDhoZ = vstbDhoZ;
            QzWvCYdld = nkcsNoUBXOK;
            ZmdSily -= paZuhKrmMKmw;
        }
    }
}

double WrqsQixmJ::pnVLiUZctEPRFSpw()
{
    string SmqgHZtdaZFQDNV = string("YDViqdMSoLMpNtrrtkxmwsOpIVylnEfOaneYCDwBzWaMPbvwEDlTFrsLtauaGpUoGtZUcrDTLCePyYx");
    string VoYDl = string("ijiXkmPJmHWqSxIjsJyegayIzKlqIFkYxBwGTABJFXzkjPGvQWEizHvKmmXnTzVmFcMGrZoCKvZMRxVrMRNelivcsRAQ");
    double RGAjc = -644130.7625645091;
    double xLpXbqwTyihDZ = -644637.3519491961;
    string sSxjlIFKsP = string("PRmLdAYXQQmsfMvjKiTaVcFUKaRIBPJeHPQwphUTwMZGxZESqDOvMCHQdjqQSpmCuzWqfnCdlQHlmvBGlnXzuOLaxcJMuCIJenCJfVMwphmhuVFXiemSZlJaVofvrrInOzoRMMqVDSUJaNMHJGCFWWHUeZQCubUSsAjlJjUAjgDyUhDphrQukYLxOhpXbhHTLiMVvdbvxJkEiFbsPyQLhUnWNpaexKliJDRTicA");
    int eBtPpPfcPVqPGB = 2102003037;
    int CofNe = -1670894333;
    int tvuKCVlUtjdmXW = -1501053254;

    for (int DqytM = 1886191022; DqytM > 0; DqytM--) {
        VoYDl = VoYDl;
        eBtPpPfcPVqPGB *= tvuKCVlUtjdmXW;
        sSxjlIFKsP = sSxjlIFKsP;
    }

    for (int lIaqfmu = 652796842; lIaqfmu > 0; lIaqfmu--) {
        VoYDl += SmqgHZtdaZFQDNV;
        xLpXbqwTyihDZ = xLpXbqwTyihDZ;
        CofNe += CofNe;
        sSxjlIFKsP = VoYDl;
    }

    if (tvuKCVlUtjdmXW < -1670894333) {
        for (int SErmUwDvabudG = 593625839; SErmUwDvabudG > 0; SErmUwDvabudG--) {
            sSxjlIFKsP = sSxjlIFKsP;
            eBtPpPfcPVqPGB -= CofNe;
        }
    }

    return xLpXbqwTyihDZ;
}

string WrqsQixmJ::PkEYDPWHwJ(double iyYRWDdfCTp, string WWZRoMYTl, bool HEPDHLdyFNiEW)
{
    string tOoYGXbecMpabMH = string("xelabvsw");
    bool fCMguTXDU = false;
    int ZwYTqBOY = 436627960;
    bool QPQFhVVqB = true;
    double GphTAsFLQsxpyGMH = 434479.1027541401;
    bool MgGJZotOADts = false;
    double hSYVta = 934955.8658837995;
    double tRnUfUMFG = -722615.5255539294;

    if (GphTAsFLQsxpyGMH == -1004446.2492316676) {
        for (int RdlmNTjuNKRNH = 2001599466; RdlmNTjuNKRNH > 0; RdlmNTjuNKRNH--) {
            continue;
        }
    }

    for (int KURPcsULvucgYA = 1829849570; KURPcsULvucgYA > 0; KURPcsULvucgYA--) {
        HEPDHLdyFNiEW = ! HEPDHLdyFNiEW;
    }

    if (tRnUfUMFG >= 934955.8658837995) {
        for (int VMPBbfa = 2109441547; VMPBbfa > 0; VMPBbfa--) {
            MgGJZotOADts = MgGJZotOADts;
        }
    }

    if (MgGJZotOADts == false) {
        for (int VfzPMJBnUlZmtMsl = 927235198; VfzPMJBnUlZmtMsl > 0; VfzPMJBnUlZmtMsl--) {
            continue;
        }
    }

    return tOoYGXbecMpabMH;
}

double WrqsQixmJ::oLrGVMYun(bool BKdZiseeav, double cJxOzbc)
{
    double rOAwPPA = -264920.89431319846;
    bool QZSSaOWLGOrgQlE = true;
    bool bzqNUJZHMvOdJfA = false;
    string NoMxBVQuVb = string("OssCbhtMcextJVloMLXuDFNygf");
    double DrYquwmilIfgk = 673407.0292704126;
    bool VnMdgHN = true;

    for (int FDkSChWjfNKJRi = 518783329; FDkSChWjfNKJRi > 0; FDkSChWjfNKJRi--) {
        QZSSaOWLGOrgQlE = BKdZiseeav;
        bzqNUJZHMvOdJfA = bzqNUJZHMvOdJfA;
        QZSSaOWLGOrgQlE = VnMdgHN;
    }

    for (int AaQAfBETAd = 438905120; AaQAfBETAd > 0; AaQAfBETAd--) {
        cJxOzbc = cJxOzbc;
        QZSSaOWLGOrgQlE = ! bzqNUJZHMvOdJfA;
        bzqNUJZHMvOdJfA = ! VnMdgHN;
        DrYquwmilIfgk /= rOAwPPA;
        VnMdgHN = ! VnMdgHN;
    }

    if (cJxOzbc <= -613670.5773041222) {
        for (int koHiQhfQ = 1856235718; koHiQhfQ > 0; koHiQhfQ--) {
            QZSSaOWLGOrgQlE = BKdZiseeav;
        }
    }

    for (int mhgxqbegUwhhpAH = 1857280732; mhgxqbegUwhhpAH > 0; mhgxqbegUwhhpAH--) {
        bzqNUJZHMvOdJfA = bzqNUJZHMvOdJfA;
        QZSSaOWLGOrgQlE = ! VnMdgHN;
        QZSSaOWLGOrgQlE = ! VnMdgHN;
    }

    for (int HPkOAoOUyJZOv = 1537698239; HPkOAoOUyJZOv > 0; HPkOAoOUyJZOv--) {
        NoMxBVQuVb += NoMxBVQuVb;
        bzqNUJZHMvOdJfA = ! QZSSaOWLGOrgQlE;
        bzqNUJZHMvOdJfA = VnMdgHN;
        bzqNUJZHMvOdJfA = bzqNUJZHMvOdJfA;
        DrYquwmilIfgk = cJxOzbc;
    }

    return DrYquwmilIfgk;
}

double WrqsQixmJ::tAwguJU(bool NIcSXBMDco, double hzkukqIyBMCsd, int uKbRtA, string xjracVAX, string gFoMfCRTm)
{
    double pbiTLKQ = 115922.58086228135;
    int DRdcJaUToLEBiv = -349156468;
    bool thqnPxyVw = false;
    string NVurizMmej = string("ktQDqCxGHCwOHiuJRHLvQiGwvalJRKVHQcFUaMBwhwfmIgyGLKHBOiEUpIaXpzIJqgmREODQPACArWpzwsKzduGpxSQPUsFNdAeSuZdqVdEvRzBdzuyQVQqprHygsdAwHGVaKLF");
    double uXJvoUcoYBuV = 14812.561526688853;
    double ZlaSn = -695574.5917323952;
    bool blcumMpQH = true;
    bool eXSYhfDNEOyGDH = true;
    bool YQlMHuvboyKDMR = true;

    if (YQlMHuvboyKDMR == false) {
        for (int DgtQybjcFqhkg = 265514016; DgtQybjcFqhkg > 0; DgtQybjcFqhkg--) {
            continue;
        }
    }

    for (int AAJALEKTOqv = 1855610665; AAJALEKTOqv > 0; AAJALEKTOqv--) {
        YQlMHuvboyKDMR = ! NIcSXBMDco;
    }

    return ZlaSn;
}

void WrqsQixmJ::bhfujllFXNLfX(bool FnRTaz, bool QFosjbEx, double BmQwjdLsEeJT)
{
    bool DdaEbNBEJk = false;
    bool MDDVXcX = false;
    bool osGdu = true;
    double bQtQrTW = -123621.45366329026;
    string lXuZnP = string("IGmcWXisoQgiXzhCSGdLrlbbWejdTISHOefwRfnJKXvEYrzHNXTLwmKQDaoOLTOiuYZduqgEMfNrPrJfqrWmHrakdaarMXWEcRGPkVdKCzHjsDIROrfAOXILexgTXQZkYHcRsvbXRVyqwIJmPkvtIljHanvsdbhYGrzAkbMcIONXfrskpMYBIcFsofQiSgoRQaPqqeeWXQypscqkOvlbVamEUXhCAfyYTgnBwnihVjze");
    int yavGsWL = 1464601334;
    bool yxifqIA = true;

    if (FnRTaz == false) {
        for (int HFaIdUFqqVKNgiO = 626701947; HFaIdUFqqVKNgiO > 0; HFaIdUFqqVKNgiO--) {
            QFosjbEx = ! yxifqIA;
            yxifqIA = ! QFosjbEx;
        }
    }

    for (int MMjMrvMaH = 1549092879; MMjMrvMaH > 0; MMjMrvMaH--) {
        DdaEbNBEJk = osGdu;
        MDDVXcX = DdaEbNBEJk;
        DdaEbNBEJk = ! FnRTaz;
    }

    if (MDDVXcX == false) {
        for (int LkYfKtL = 465318109; LkYfKtL > 0; LkYfKtL--) {
            QFosjbEx = ! FnRTaz;
            FnRTaz = ! FnRTaz;
            osGdu = osGdu;
        }
    }

    if (FnRTaz == true) {
        for (int QHaADi = 2074493001; QHaADi > 0; QHaADi--) {
            QFosjbEx = QFosjbEx;
            QFosjbEx = ! osGdu;
            yavGsWL *= yavGsWL;
            QFosjbEx = yxifqIA;
        }
    }

    if (bQtQrTW > 502433.5451577089) {
        for (int wEYmFkup = 955662468; wEYmFkup > 0; wEYmFkup--) {
            yavGsWL *= yavGsWL;
            QFosjbEx = DdaEbNBEJk;
        }
    }

    if (FnRTaz == false) {
        for (int ZMNKirejHzFcn = 951615079; ZMNKirejHzFcn > 0; ZMNKirejHzFcn--) {
            DdaEbNBEJk = osGdu;
        }
    }
}

int WrqsQixmJ::LGwoSiDKDvKf(bool FlopdaKO)
{
    string eVKbSpC = string("Mna");
    bool QFWih = true;
    int HdkczYGjvkSqnF = -1043627385;
    string bbAAcwyWMP = string("kENNrHlWMDzzooCnehtRxQCYZvnROGgYdjWcVgjwHyxmKfRADbtDOsMXDTzcPMwrvBsnZsRrUvLJPBVzyGPllpljWoLoVrGvBsSuHuERklmrtDmhpLwoTpGKwAMczSQNEsuwrOjEyjLdLEmhElzbIjlYekjuUAIUUGZZwveqCdtZVDkRIpxgxCQheOynWRBZDhekiXWCAroKOdLZbDvnAhplRZkCtKWziY");
    string AgmwzqljVllfoD = string("xfYzlTheYPsfMEmxsZGNnSTQBtVuSYjYeyGjyrFLmGuWyBGbQNZzYoxCAUHRCQWzeUXQrYMWkmThYEAbjsAALLsrJLJeuIxzoOkPUtxpnXPFwlqaqiCapNvC");
    string JKyzHzS = string("VIzXwYDYylOAuqJjJdSkgPePQNxccozsDswigiaIdq");

    if (bbAAcwyWMP >= string("Mna")) {
        for (int lVeIBW = 1465425958; lVeIBW > 0; lVeIBW--) {
            eVKbSpC += bbAAcwyWMP;
            AgmwzqljVllfoD = JKyzHzS;
        }
    }

    for (int qWbiSddebMrcTm = 1721420509; qWbiSddebMrcTm > 0; qWbiSddebMrcTm--) {
        AgmwzqljVllfoD += AgmwzqljVllfoD;
    }

    if (bbAAcwyWMP >= string("VIzXwYDYylOAuqJjJdSkgPePQNxccozsDswigiaIdq")) {
        for (int vJyAedjZd = 1922076629; vJyAedjZd > 0; vJyAedjZd--) {
            eVKbSpC += JKyzHzS;
            AgmwzqljVllfoD += JKyzHzS;
            AgmwzqljVllfoD = eVKbSpC;
        }
    }

    for (int xtJAwQl = 1605048253; xtJAwQl > 0; xtJAwQl--) {
        JKyzHzS += eVKbSpC;
        bbAAcwyWMP += eVKbSpC;
        FlopdaKO = ! QFWih;
    }

    if (bbAAcwyWMP > string("kENNrHlWMDzzooCnehtRxQCYZvnROGgYdjWcVgjwHyxmKfRADbtDOsMXDTzcPMwrvBsnZsRrUvLJPBVzyGPllpljWoLoVrGvBsSuHuERklmrtDmhpLwoTpGKwAMczSQNEsuwrOjEyjLdLEmhElzbIjlYekjuUAIUUGZZwveqCdtZVDkRIpxgxCQheOynWRBZDhekiXWCAroKOdLZbDvnAhplRZkCtKWziY")) {
        for (int qUiQnaLSAM = 1826640901; qUiQnaLSAM > 0; qUiQnaLSAM--) {
            AgmwzqljVllfoD += AgmwzqljVllfoD;
            JKyzHzS = AgmwzqljVllfoD;
        }
    }

    return HdkczYGjvkSqnF;
}

WrqsQixmJ::WrqsQixmJ()
{
    this->skAdptyVRJXIKzf(-134717.6321242987, -115879.90395814642, true, -875104551, false);
    this->bdwbXVc(-216311283, true, -852475.3804653211, true);
    this->gxyPlMPhPKS(false);
    this->pnVLiUZctEPRFSpw();
    this->PkEYDPWHwJ(-1004446.2492316676, string("wuCBYoeXLqkRTLveSOqZEBryIZyZFSBEwTIqRxJJDtBUgEduArXZyCArKkWWcNGuXQzPJxmJYsUcCCHSdNfFHMHFNluJudrLLCCeQRlTbfRAhbSbIIobZtdljkukkOLEOJcLMllgBkpltglvRQHKt"), false);
    this->oLrGVMYun(false, -613670.5773041222);
    this->tAwguJU(true, -567936.0360585847, -300992459, string("VaxTXJKIOsuBujcDFzdtbvipaZfsosbxqpkJNjEiTDYKcwtNewhzshXCHjFDRadnuTHwqHdNsgTsSylmVQXVOjAKwUgvuJzrQHLsBzwJemtNPTLaIKRPiDmudyndypRVWCNDFiFuVNGmxVfGwsjioQGhFpBrjsuAhcNlOpKWzGDcirZsxHxZcInOItQQiEBQDkDLxBOYiKKNrNPYdrFzljwFyJdFSSkOxxVZijfsypmqToTnZbcAkYa"), string("IYvJCxWyZbSGBggifltYpUoeOMezYaLhPpmsaPqCCpoRzwDbSMiTYmECQMVcIFMMnKlmnqycSoIFqPaGbskEBierqwkfcihBmtYgAihHPNnCPaEFFxAtECeoKtEWETeaGVdQdWDgQiQEqFtlcVrMhyYwgjpmEdPOY"));
    this->bhfujllFXNLfX(false, true, 502433.5451577089);
    this->LGwoSiDKDvKf(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RvUhgP
{
public:
    bool aVLPhVMrQB;
    string SfUwJha;

    RvUhgP();
    double doQaCQtDYUMSik(int eXKFFLvMQwWOVH, bool RWXbWf, int dYOJoe);
    void IFZhPQrchOa(double WGVQU, string uoEnXwhRthI, string NPqoKCxIslQ, double kCwlIrRjhVSniSk, bool MXvTldWQzx);
    double CZxgjxs(string IkXhUbz, double MAEqxuNfo);
    void OUlYuJHuZi(string VBgkLUHc, double pINpPE, double ssrWAGTUEjvGUCPZ);
protected:
    string TXoUa;
    int dnaevp;
    string ceEubi;
    string ZWGxScWoXfWzQNjJ;
    string IZQvvuOsxqefA;

    string jBxLeYcOElYTup();
private:
    string PSaMOvcFePIyF;

    string gYFndMmlLNZzYzei();
    string TmeFp(bool quCKJa, bool JqqOGLfMLEoTP, int tXkLTaM, double zRCxumwvf, double DHSnofGQxNxm);
    int oDYwvKBRdsOEfVJR(double ySsgiIh, int dsEEVl, int VisdJEz, bool fdpoMKnccxgTJ, bool EXUXOY);
    double LJmhGZAUHofiUS(string gKnUBmJD, int YdjkpPKvs, bool JeqAR, string GgdCDeUaFQgSlfVe);
};

double RvUhgP::doQaCQtDYUMSik(int eXKFFLvMQwWOVH, bool RWXbWf, int dYOJoe)
{
    string hlhKprlfiAM = string("PIToyPGCBFPbNTUhPBBvFOSAFTBfEXnCdfoVfSitNMZcrYHQm");
    string GWmImYCKr = string("JTJRApxqzQLtkQMXtuUtbAqncUmXQzMDMRNsJaOQvScQiQtEiMFInLwcjvxWGpqavihiq");
    int bthuQwpJoUBqJ = -1518039181;
    double jZDKDLJyuuVSNuge = -659116.6563901394;
    bool gscWQRdbQ = true;

    for (int OdkHvNT = 1786560615; OdkHvNT > 0; OdkHvNT--) {
        hlhKprlfiAM = GWmImYCKr;
        dYOJoe = bthuQwpJoUBqJ;
        bthuQwpJoUBqJ /= bthuQwpJoUBqJ;
        gscWQRdbQ = gscWQRdbQ;
    }

    for (int UnvwU = 1988988295; UnvwU > 0; UnvwU--) {
        hlhKprlfiAM += hlhKprlfiAM;
        dYOJoe += dYOJoe;
    }

    return jZDKDLJyuuVSNuge;
}

void RvUhgP::IFZhPQrchOa(double WGVQU, string uoEnXwhRthI, string NPqoKCxIslQ, double kCwlIrRjhVSniSk, bool MXvTldWQzx)
{
    double yAZRXP = 952892.1489532955;
    string mFELNdyk = string("fewaSiCKHrhcCqlAUNuZPhIWIwEvcmUqCKRXowIlOgJJGrZzAcLkDhRFNtwyypjGxlaZLalcmcHFGykqiIzFXPQKYjpvPhrahPrHMYkWSDosmedfEeXcoKbXdljVwkfYWdeZSuMbEfpStRxcWHyFUPvGPTbpPckkoQJcMuRZzMnzzRRzbgtWTHNUgHKWjdARkeuOURXnWmlRAlnWtWlXtDJdRrWgGhzidLVKATqqYvlpaRRPurcUbSwuFJLkBd");

    if (NPqoKCxIslQ == string("fewaSiCKHrhcCqlAUNuZPhIWIwEvcmUqCKRXowIlOgJJGrZzAcLkDhRFNtwyypjGxlaZLalcmcHFGykqiIzFXPQKYjpvPhrahPrHMYkWSDosmedfEeXcoKbXdljVwkfYWdeZSuMbEfpStRxcWHyFUPvGPTbpPckkoQJcMuRZzMnzzRRzbgtWTHNUgHKWjdARkeuOURXnWmlRAlnWtWlXtDJdRrWgGhzidLVKATqqYvlpaRRPurcUbSwuFJLkBd")) {
        for (int nIiFfyM = 363580444; nIiFfyM > 0; nIiFfyM--) {
            kCwlIrRjhVSniSk += yAZRXP;
        }
    }

    for (int FWxPdg = 2068753864; FWxPdg > 0; FWxPdg--) {
        mFELNdyk = NPqoKCxIslQ;
    }
}

double RvUhgP::CZxgjxs(string IkXhUbz, double MAEqxuNfo)
{
    int HKLemhBpBe = 977218899;
    int IbPQVm = -599130482;
    double VspIfXfTbHV = -705321.6321847879;
    double JoRdk = 288408.6598957308;
    double UOcIbzigotcjcX = 821098.9889380701;
    double kHoaUGZSeVzVhKoD = 285883.806829276;
    string yxQLJdrKvbz = string("KzFGaBUCULlmamKDSUBGIFHEKxHaRJtiPVtPucqjDhHwOGwWoysfxRVNjItagkLfayHzeBXsnhDYnwavAELDRKEYDJWvVANeJoJgUMvcTEpqXhEcMBQqduKyTepNwNqBDgUjCdQCWJZpNqMMreNOzMgo");
    bool PLidF = false;
    string yDBeiyI = string("GIIsVGzNaoYtzFpEjNNzrDEldHFPHKIpzTwefOCJMrdIjJXcHJZXvaoQZcQsGIGhnvIWMYveoSbLILvGDpLmdykupqCDrveeOrvPirooQwsTAEksYRMvQzgIVjFynLduQIvazjYBijpCnbHHJxAQUeHcbjHvbvaXrKVomfVDCnATgwfkSyvQpiCXuaoXZtJqJRKSAeufsIIxAJQVZ");

    for (int WcsJJE = 74377078; WcsJJE > 0; WcsJJE--) {
        continue;
    }

    for (int POCKQvoMoV = 1694274414; POCKQvoMoV > 0; POCKQvoMoV--) {
        UOcIbzigotcjcX *= MAEqxuNfo;
        kHoaUGZSeVzVhKoD -= JoRdk;
        MAEqxuNfo -= JoRdk;
    }

    for (int gDJzrCMWyGfmam = 792141898; gDJzrCMWyGfmam > 0; gDJzrCMWyGfmam--) {
        IkXhUbz = IkXhUbz;
    }

    for (int dpdszwM = 133783452; dpdszwM > 0; dpdszwM--) {
        yDBeiyI += IkXhUbz;
        yDBeiyI += yxQLJdrKvbz;
    }

    return kHoaUGZSeVzVhKoD;
}

void RvUhgP::OUlYuJHuZi(string VBgkLUHc, double pINpPE, double ssrWAGTUEjvGUCPZ)
{
    string xqUrXoNz = string("pIJVfzreRcTRLMkmUmRQteEFLEwJnaTVuiskcCpFhJGNpRGVPqXtFncCyQxmnvhcfOltdQWlEwr");
    double SceEojuUlkTpQe = 45153.40480117222;
    bool UfmLjg = true;
    bool rwAvUrPYURciVhP = true;

    for (int piSsWoBHCLi = 683902434; piSsWoBHCLi > 0; piSsWoBHCLi--) {
        ssrWAGTUEjvGUCPZ /= SceEojuUlkTpQe;
    }

    if (pINpPE != -418199.90616472444) {
        for (int AqLyK = 1221902406; AqLyK > 0; AqLyK--) {
            ssrWAGTUEjvGUCPZ -= SceEojuUlkTpQe;
        }
    }

    for (int VJorGTcy = 1795586929; VJorGTcy > 0; VJorGTcy--) {
        UfmLjg = UfmLjg;
    }

    for (int WHzlGORqBhsiUdeJ = 1660456199; WHzlGORqBhsiUdeJ > 0; WHzlGORqBhsiUdeJ--) {
        ssrWAGTUEjvGUCPZ /= ssrWAGTUEjvGUCPZ;
        pINpPE += SceEojuUlkTpQe;
        pINpPE += pINpPE;
    }

    for (int cHwbVYUIQflnaa = 1169021223; cHwbVYUIQflnaa > 0; cHwbVYUIQflnaa--) {
        continue;
    }

    for (int UDaBzYWwqg = 471815600; UDaBzYWwqg > 0; UDaBzYWwqg--) {
        continue;
    }

    if (pINpPE < 45153.40480117222) {
        for (int paJUzr = 328007542; paJUzr > 0; paJUzr--) {
            ssrWAGTUEjvGUCPZ /= pINpPE;
        }
    }
}

string RvUhgP::jBxLeYcOElYTup()
{
    double SUrjsHBKozdnAziH = 412229.64612001844;
    double NArXxbJDdoHJnEn = -701836.5392902971;
    int hiMkphEQ = 437892054;
    string UNElFEUeo = string("YpPeSLFnioiOsTBOyiFXyehasmAwQNkumCughyBXKXUEkgfnFlqODskPOdllKFmpKPqBM");
    int QfyceHlOXFwYQTsd = 2024916526;
    string UcCdBuKIQWqDQaS = string("YMaZFjjYUfRcupbDExAfbIOvFVWccqsynPJypIPLTqHJdhFmhYvrJsmStbpHuTeDigVOOcgAeoeaNRJYBkOKoIXKNCaNtWQWPiQaWezfjxOtVokZienwtMraFeRfdAffMVgpgsVPtCVMbDWNP");
    string FNmXwiycmFlUWRcY = string("xAFwtVlMbNxMRcdRpHfxVUqCwjSqEJdqWlFVemUUrFYMMqLGAYXKHgolJyMjOpqAMcQjYFSaaJkRfLtIhUMflxOVSrbsbmlghEipSuWJscfRfnMKBiGtgiuoStNCMNFVfSTmzUgOUlpdftwfTofjHFEzWHsgYfdvRLkHEcmWTV");
    bool tLWaSRVXMypprzU = true;
    int pjCZFPXqXRcs = -841870575;
    string OQMlRBuBJzBgrc = string("Gr");

    if (pjCZFPXqXRcs != -841870575) {
        for (int DcrfCTTStWk = 314878518; DcrfCTTStWk > 0; DcrfCTTStWk--) {
            UcCdBuKIQWqDQaS = FNmXwiycmFlUWRcY;
        }
    }

    for (int fRKrAiI = 1849386775; fRKrAiI > 0; fRKrAiI--) {
        continue;
    }

    for (int CHjrgZeP = 1289709537; CHjrgZeP > 0; CHjrgZeP--) {
        hiMkphEQ *= hiMkphEQ;
        NArXxbJDdoHJnEn += NArXxbJDdoHJnEn;
        hiMkphEQ = hiMkphEQ;
        pjCZFPXqXRcs *= pjCZFPXqXRcs;
    }

    return OQMlRBuBJzBgrc;
}

string RvUhgP::gYFndMmlLNZzYzei()
{
    bool HqUNFxvgARhl = true;

    if (HqUNFxvgARhl != true) {
        for (int rYeFgsHeKlxgi = 1858589408; rYeFgsHeKlxgi > 0; rYeFgsHeKlxgi--) {
            HqUNFxvgARhl = HqUNFxvgARhl;
            HqUNFxvgARhl = HqUNFxvgARhl;
            HqUNFxvgARhl = ! HqUNFxvgARhl;
            HqUNFxvgARhl = HqUNFxvgARhl;
            HqUNFxvgARhl = HqUNFxvgARhl;
            HqUNFxvgARhl = HqUNFxvgARhl;
            HqUNFxvgARhl = ! HqUNFxvgARhl;
            HqUNFxvgARhl = ! HqUNFxvgARhl;
            HqUNFxvgARhl = HqUNFxvgARhl;
        }
    }

    if (HqUNFxvgARhl == true) {
        for (int uXmSOPqO = 1313790901; uXmSOPqO > 0; uXmSOPqO--) {
            HqUNFxvgARhl = ! HqUNFxvgARhl;
            HqUNFxvgARhl = HqUNFxvgARhl;
        }
    }

    if (HqUNFxvgARhl == true) {
        for (int JQVtwwHBh = 1292222185; JQVtwwHBh > 0; JQVtwwHBh--) {
            HqUNFxvgARhl = HqUNFxvgARhl;
            HqUNFxvgARhl = ! HqUNFxvgARhl;
        }
    }

    if (HqUNFxvgARhl != true) {
        for (int KhrLVbWOguvXO = 827749354; KhrLVbWOguvXO > 0; KhrLVbWOguvXO--) {
            HqUNFxvgARhl = ! HqUNFxvgARhl;
            HqUNFxvgARhl = ! HqUNFxvgARhl;
            HqUNFxvgARhl = HqUNFxvgARhl;
        }
    }

    return string("pLcWIsijRBWfEZekoYIqIntwzgbciTJbpqfZeXyxLEijvoXIHBntnDMCFxdDutvxpCJxhIgj");
}

string RvUhgP::TmeFp(bool quCKJa, bool JqqOGLfMLEoTP, int tXkLTaM, double zRCxumwvf, double DHSnofGQxNxm)
{
    int VDpYnghj = 92241729;
    double KXJyeVLePzWOxRZy = -202701.75282819694;
    string qIWzSpRcojZt = string("jqyPclfJcetUYtYUoTpGdcFdQGvzoxkQkiIeNUlTeyOsYzKUgkNkt");

    for (int ZOqEujcwEraQRXV = 299345839; ZOqEujcwEraQRXV > 0; ZOqEujcwEraQRXV--) {
        continue;
    }

    for (int leiUkvpPaRKIwn = 1933275599; leiUkvpPaRKIwn > 0; leiUkvpPaRKIwn--) {
        tXkLTaM = VDpYnghj;
    }

    for (int IbKtzdzQxHsQ = 1867195071; IbKtzdzQxHsQ > 0; IbKtzdzQxHsQ--) {
        tXkLTaM *= tXkLTaM;
    }

    for (int iGyXL = 1245431905; iGyXL > 0; iGyXL--) {
        VDpYnghj *= VDpYnghj;
    }

    for (int zWbNZVOaR = 1130028683; zWbNZVOaR > 0; zWbNZVOaR--) {
        zRCxumwvf += zRCxumwvf;
        JqqOGLfMLEoTP = ! quCKJa;
        KXJyeVLePzWOxRZy += DHSnofGQxNxm;
    }

    for (int XvZVLiXJygO = 602308193; XvZVLiXJygO > 0; XvZVLiXJygO--) {
        VDpYnghj = tXkLTaM;
    }

    for (int mgKVRTduC = 1314676655; mgKVRTduC > 0; mgKVRTduC--) {
        zRCxumwvf -= DHSnofGQxNxm;
    }

    return qIWzSpRcojZt;
}

int RvUhgP::oDYwvKBRdsOEfVJR(double ySsgiIh, int dsEEVl, int VisdJEz, bool fdpoMKnccxgTJ, bool EXUXOY)
{
    double KjuEaqkeWzU = 211672.0298284007;

    for (int qDdheLRvxP = 1246777680; qDdheLRvxP > 0; qDdheLRvxP--) {
        dsEEVl -= dsEEVl;
    }

    if (EXUXOY != false) {
        for (int aaWMSwhqx = 1778141123; aaWMSwhqx > 0; aaWMSwhqx--) {
            KjuEaqkeWzU /= ySsgiIh;
            ySsgiIh -= ySsgiIh;
            ySsgiIh *= ySsgiIh;
            dsEEVl /= VisdJEz;
        }
    }

    for (int pfypto = 144564426; pfypto > 0; pfypto--) {
        fdpoMKnccxgTJ = EXUXOY;
        KjuEaqkeWzU /= KjuEaqkeWzU;
        VisdJEz /= VisdJEz;
        fdpoMKnccxgTJ = EXUXOY;
        VisdJEz *= dsEEVl;
        ySsgiIh /= KjuEaqkeWzU;
        EXUXOY = EXUXOY;
    }

    return VisdJEz;
}

double RvUhgP::LJmhGZAUHofiUS(string gKnUBmJD, int YdjkpPKvs, bool JeqAR, string GgdCDeUaFQgSlfVe)
{
    double kedzbx = -366159.88350272615;
    double pMimfxnzCOqqB = -326979.42076818034;
    int rFqIxevsiYL = -433756907;

    return pMimfxnzCOqqB;
}

RvUhgP::RvUhgP()
{
    this->doQaCQtDYUMSik(-682117544, true, 1389805060);
    this->IFZhPQrchOa(402550.1600240926, string("yzjRcDXjvtetCSQAzJeVTErOCpCGRxqXZUqZUpVABRjLJyZVSqvmtqHKnfQ"), string("sMGcqqlDPRyUSzncunrJWKgaiaLthSEEzlRjIwCddbHnjonIYMPNNodhgliWi"), -687692.3872314594, false);
    this->CZxgjxs(string("eVZuTQgoJBIsfWnJbwGOIFLzplXYTXuMzAsxYiFVNGwvAjUvOMzsqspukXBelfr"), -90186.79475592462);
    this->OUlYuJHuZi(string("FhlsrSeLSdvDwqXpuhwJkjFDjHSbJdxLrZAHrfAmVRDCpwqJMDEHKazLiKLxrmRUPfbdqYXPRSVYndiNuVlRljNeXsRSkCMhcEervlZRzsqpkWUQPRLkPDaiflktWCQpEkqKGFNwksjnxdzeNxEsgnnoqxBvorjATRGndvdufREm"), 278431.58153131686, -418199.90616472444);
    this->jBxLeYcOElYTup();
    this->gYFndMmlLNZzYzei();
    this->TmeFp(false, false, -2085040487, -269111.0362830498, 395774.8142538293);
    this->oDYwvKBRdsOEfVJR(-668219.3910344607, -2002086830, 2037334311, false, true);
    this->LJmhGZAUHofiUS(string("nmomsiQEbpaKRBbwRvHdzCmSZYZhsLzYLIXIcRnoxRlXYUkzUWdcUBIVMPQ"), 1435452104, false, string("LyOGcFAUPiuaYtjHVmJCscbAQEVyxUesbtujfoRiWxuHloFjDfGfPbk"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qSQYrvzEUcbriI
{
public:
    double FLyfBfdcCFfU;

    qSQYrvzEUcbriI();
    string hEHovv();
protected:
    double TFGTnpOALAcXf;
    int tWVoTmBOVRe;
    int raiXxjzQRmt;
    int yOPjbGjqOoERIQ;
    bool rBWpzv;

    int AgDGiOR();
    string rQNfCeaXgid();
    bool ydBWbCHarhrtDpD(bool rwJLUvYVlX, int BxbFrTeuc, int uWcJiyzHGKjawDo, double DnCdiWqgWRVZGX);
    bool exFOSqb(int fzcWohCAp, string trHjXlpka);
    bool IyhSPM(bool GVDpmkyLzPrN, int dRNOjFIRJP, bool zcWTf);
    double GfRhQVbEKDktIEy(string fQqwQVFNUPTJuju, bool YWOEZ, double vWPgONiVz, bool wbAoBXPBoo, int ViXyzHeXsCl);
    double xsRHrAfQg(string yvUjEaYQZwRtF, string AyxpFwYc, string lgevDSZg);
    bool dxjMB();
private:
    string XCxEMbtMVMHvrni;

    void HhhIJlmKnK(int FcsTCzD);
    int YnzKfZRDA(bool abQQHz, int QRtKNhrrxqwi, double tIuJaUrOpbcg, int QmYnsdFVYS);
    bool oMYca(double UwWTtjYzXj, int uEbZBg, double mUyrxNVCpFJsCay);
    double GItoRxNxUzLezzwA(bool pgyVxP, double ulvoYxt);
    double IXChHZWlLJ(double ZhkgCwZdtP, bool AsHDSJIxKdzk, double BKsWkSzGTcCLrad);
    void nrjoMoxt(int sEzyv);
    string TBBPNqBbBd(string wXIwA, bool SGFFYZEFPKvmWmpn, double lDpidMCqqWVPbi, double YzjbPqOhGdBvO, double SLuHoXyAWCxTiO);
    void xGPLRvXBsgl();
};

string qSQYrvzEUcbriI::hEHovv()
{
    bool EjPkpfN = true;
    bool WoJgmCKKhjXtEg = false;
    double nGLhypBppwwfRd = -511131.39890313894;

    for (int AmyKKhZmEp = 630681332; AmyKKhZmEp > 0; AmyKKhZmEp--) {
        WoJgmCKKhjXtEg = ! WoJgmCKKhjXtEg;
        nGLhypBppwwfRd /= nGLhypBppwwfRd;
        WoJgmCKKhjXtEg = ! WoJgmCKKhjXtEg;
        EjPkpfN = WoJgmCKKhjXtEg;
        WoJgmCKKhjXtEg = ! WoJgmCKKhjXtEg;
    }

    for (int TjYbHlFuEpeBW = 562436493; TjYbHlFuEpeBW > 0; TjYbHlFuEpeBW--) {
        EjPkpfN = ! EjPkpfN;
        nGLhypBppwwfRd += nGLhypBppwwfRd;
        EjPkpfN = EjPkpfN;
        nGLhypBppwwfRd /= nGLhypBppwwfRd;
    }

    if (nGLhypBppwwfRd == -511131.39890313894) {
        for (int mXxVJ = 1117396444; mXxVJ > 0; mXxVJ--) {
            EjPkpfN = ! WoJgmCKKhjXtEg;
            WoJgmCKKhjXtEg = EjPkpfN;
        }
    }

    return string("OdKFMKvTBkWFbHGKwLJYseUSIvunCCZWQJLBjLtUiarsxqaQyibgwleNEUnStcyFoJqrzZsUccDGazIUTSaCNfksowtQFRXcuCfOULlPhpzLqdsENXUPEeDOThiCNhRWQEdAaSBquYlqPWXCvocBCSreTVynfxhQSdyHswhAmBMcD");
}

int qSQYrvzEUcbriI::AgDGiOR()
{
    string FMuPuhrsKvHT = string("wLfwnJxuYtaRGTYgIYBOQCtWedydhxPNP");
    string IQTDFs = string("JPKKSNV");
    bool rpmWt = false;
    double YprkhbAgeBn = -173631.02969943295;
    bool RSburZxkEVOEDv = false;
    double UYMjFBO = 884899.2810429187;

    if (rpmWt == false) {
        for (int SUIcALWJdqE = 107241855; SUIcALWJdqE > 0; SUIcALWJdqE--) {
            YprkhbAgeBn += UYMjFBO;
            IQTDFs = IQTDFs;
            YprkhbAgeBn = YprkhbAgeBn;
            IQTDFs += FMuPuhrsKvHT;
        }
    }

    return 1954843466;
}

string qSQYrvzEUcbriI::rQNfCeaXgid()
{
    double hMhDfDniNEwlU = 525548.1096107009;
    int cjuVzTFVSDv = -1444790540;
    bool gSoTXQH = true;
    string txzvzoFjHOQ = string("XFKdymXZeLiLbytIXymXeaTBRwBBGBehRrKUwdnRaChnPvPbhKSkcetYTdRthoqGCpoocfXaJrkTEYOiFSNyrkmpTLTlFkBetHiNNkTVbtYEThwrdOmqeFdFfvoWSstoYIQIjneMWBcjmDjUBznjOpkfL");
    bool GjdcmFKrqbHh = false;
    bool keWVnvb = true;

    for (int YAYASImNgRRlx = 734492771; YAYASImNgRRlx > 0; YAYASImNgRRlx--) {
        GjdcmFKrqbHh = ! GjdcmFKrqbHh;
    }

    for (int pkCpOp = 1983070020; pkCpOp > 0; pkCpOp--) {
        gSoTXQH = ! keWVnvb;
    }

    if (GjdcmFKrqbHh == false) {
        for (int kufPiEaRgktOmGZ = 200391963; kufPiEaRgktOmGZ > 0; kufPiEaRgktOmGZ--) {
            hMhDfDniNEwlU = hMhDfDniNEwlU;
            cjuVzTFVSDv -= cjuVzTFVSDv;
            keWVnvb = ! GjdcmFKrqbHh;
        }
    }

    for (int xKhtL = 505356625; xKhtL > 0; xKhtL--) {
        txzvzoFjHOQ = txzvzoFjHOQ;
        keWVnvb = ! GjdcmFKrqbHh;
        cjuVzTFVSDv -= cjuVzTFVSDv;
    }

    for (int laTvIicc = 407854627; laTvIicc > 0; laTvIicc--) {
        txzvzoFjHOQ = txzvzoFjHOQ;
        gSoTXQH = keWVnvb;
        GjdcmFKrqbHh = ! keWVnvb;
    }

    for (int zMSmQex = 1928455774; zMSmQex > 0; zMSmQex--) {
        GjdcmFKrqbHh = ! gSoTXQH;
        GjdcmFKrqbHh = GjdcmFKrqbHh;
        gSoTXQH = keWVnvb;
    }

    return txzvzoFjHOQ;
}

bool qSQYrvzEUcbriI::ydBWbCHarhrtDpD(bool rwJLUvYVlX, int BxbFrTeuc, int uWcJiyzHGKjawDo, double DnCdiWqgWRVZGX)
{
    int wvOgQlSfWgnI = 700810447;
    int hHiazATNue = 1958412557;

    if (uWcJiyzHGKjawDo == -596106735) {
        for (int LqCtbhgxzmWqpXD = 1156220034; LqCtbhgxzmWqpXD > 0; LqCtbhgxzmWqpXD--) {
            rwJLUvYVlX = ! rwJLUvYVlX;
        }
    }

    if (hHiazATNue > 1958412557) {
        for (int RdiprIvqbX = 1217313312; RdiprIvqbX > 0; RdiprIvqbX--) {
            hHiazATNue = uWcJiyzHGKjawDo;
            hHiazATNue += hHiazATNue;
            uWcJiyzHGKjawDo -= wvOgQlSfWgnI;
            uWcJiyzHGKjawDo *= uWcJiyzHGKjawDo;
            hHiazATNue = wvOgQlSfWgnI;
        }
    }

    for (int HdaXiXgJPICuyENp = 1532324441; HdaXiXgJPICuyENp > 0; HdaXiXgJPICuyENp--) {
        wvOgQlSfWgnI -= hHiazATNue;
        DnCdiWqgWRVZGX = DnCdiWqgWRVZGX;
        hHiazATNue += wvOgQlSfWgnI;
        DnCdiWqgWRVZGX += DnCdiWqgWRVZGX;
    }

    for (int fglXO = 1441356450; fglXO > 0; fglXO--) {
        wvOgQlSfWgnI /= uWcJiyzHGKjawDo;
    }

    return rwJLUvYVlX;
}

bool qSQYrvzEUcbriI::exFOSqb(int fzcWohCAp, string trHjXlpka)
{
    bool CLPkNg = true;
    bool TPGpvbNsLDNdj = true;
    int zltALiXyg = -523743852;
    bool DZXNvPDne = true;
    string PSHqDXULnT = string("oVglikUbHnGFc");
    string QRfLUQ = string("TmUOdHceOBlOJqhScOwSEBUgGCQBijvZVYRQraLZbgvubzxutIslroaLnWlRmLngEyXtDjJgPDOTFfKfzpKAdYODrjiraEDVjroObQgTbUDvd");
    int ytRXasza = 1908124364;
    int jhNBDloObfm = -362601010;
    string DrtWI = string("xrfEDVDfpSWUjgRfkKwQFuJcolassyQnwfkvHChvpDUofyLHqUHTxRXVihGuaTqWlZdaDRIUEqlyajymBbKdHFoyPmLyMrftOTTgVsytItDuGVgzxzjNFEJAsGBqRAjOwRWmmTj");
    double MisnJ = -24023.099841593124;

    for (int qBGaqVFFrETPe = 1951118394; qBGaqVFFrETPe > 0; qBGaqVFFrETPe--) {
        jhNBDloObfm /= zltALiXyg;
        DrtWI = trHjXlpka;
    }

    for (int LJfbCvbM = 632000791; LJfbCvbM > 0; LJfbCvbM--) {
        DrtWI += trHjXlpka;
        jhNBDloObfm -= jhNBDloObfm;
        zltALiXyg = jhNBDloObfm;
        trHjXlpka += QRfLUQ;
    }

    for (int lAPpOSZRhqCeQb = 398398765; lAPpOSZRhqCeQb > 0; lAPpOSZRhqCeQb--) {
        fzcWohCAp = ytRXasza;
        QRfLUQ += trHjXlpka;
    }

    for (int DlFytUjRbIl = 1237607532; DlFytUjRbIl > 0; DlFytUjRbIl--) {
        QRfLUQ += QRfLUQ;
        fzcWohCAp /= ytRXasza;
    }

    return DZXNvPDne;
}

bool qSQYrvzEUcbriI::IyhSPM(bool GVDpmkyLzPrN, int dRNOjFIRJP, bool zcWTf)
{
    int UGxuIb = 993864424;
    int WKvNHN = 638922223;
    bool SAdixOLIkESOV = true;
    double IBHamMoEHSM = -769614.1360899443;
    bool EFaSHdMQKIFHdOCv = true;
    bool mPtvhGvZjICtulF = false;
    double ufJINTI = 992601.0614780312;
    string VLYMsRbftVCsqI = string("MrzUnnlfhbMTAAcyAzgHohPyqViuRDyLSMdkAXGbMxPRVmYatdqdpnekYPGFVYhEEiDyMCTnQTGrWLpuE");
    bool VMHWOSmVHNzAmWFs = false;

    for (int GHAqckXcfiN = 885354863; GHAqckXcfiN > 0; GHAqckXcfiN--) {
        GVDpmkyLzPrN = ! mPtvhGvZjICtulF;
        IBHamMoEHSM -= ufJINTI;
    }

    for (int QQNtopuyXpyFE = 596262463; QQNtopuyXpyFE > 0; QQNtopuyXpyFE--) {
        VLYMsRbftVCsqI += VLYMsRbftVCsqI;
    }

    for (int OPGmdgXFNd = 383268656; OPGmdgXFNd > 0; OPGmdgXFNd--) {
        dRNOjFIRJP -= WKvNHN;
        SAdixOLIkESOV = ! EFaSHdMQKIFHdOCv;
    }

    for (int HfeHKbDKDV = 1724125653; HfeHKbDKDV > 0; HfeHKbDKDV--) {
        IBHamMoEHSM *= IBHamMoEHSM;
    }

    for (int cUyqJRjttEDCeUF = 1315308926; cUyqJRjttEDCeUF > 0; cUyqJRjttEDCeUF--) {
        EFaSHdMQKIFHdOCv = SAdixOLIkESOV;
        SAdixOLIkESOV = GVDpmkyLzPrN;
    }

    return VMHWOSmVHNzAmWFs;
}

double qSQYrvzEUcbriI::GfRhQVbEKDktIEy(string fQqwQVFNUPTJuju, bool YWOEZ, double vWPgONiVz, bool wbAoBXPBoo, int ViXyzHeXsCl)
{
    int LVYHHRSl = -660409554;

    for (int HrkVtZCjY = 1570401386; HrkVtZCjY > 0; HrkVtZCjY--) {
        vWPgONiVz *= vWPgONiVz;
    }

    for (int STypWkVpqc = 594571770; STypWkVpqc > 0; STypWkVpqc--) {
        LVYHHRSl /= ViXyzHeXsCl;
    }

    for (int bmcYxZT = 1485590259; bmcYxZT > 0; bmcYxZT--) {
        wbAoBXPBoo = wbAoBXPBoo;
    }

    for (int hnmRHczpB = 71225415; hnmRHczpB > 0; hnmRHczpB--) {
        YWOEZ = ! YWOEZ;
    }

    return vWPgONiVz;
}

double qSQYrvzEUcbriI::xsRHrAfQg(string yvUjEaYQZwRtF, string AyxpFwYc, string lgevDSZg)
{
    double YHdlKoaH = 730218.0801169153;
    bool IgWMNsKxOBeQIfNJ = true;
    double zuprWiKeMcQ = -1027989.9970502997;
    bool CJfEP = true;
    string XLVhbWk = string("rWwfeEPUaVQPQsKrWqAsoTgEadKaXbcxQis");
    bool QnJKWuhQSmraEZk = false;
    double kZvxdmiWKGaW = 153297.23326198244;

    if (lgevDSZg != string("ZFIedgPxulUWbRXiaWYbeCJaEsUIrwLsWTDImFbKOkspZCwsPfKupDmBTd")) {
        for (int kDpIxhCs = 1073251963; kDpIxhCs > 0; kDpIxhCs--) {
            XLVhbWk += AyxpFwYc;
        }
    }

    for (int ceXfzoHZIvCIPDxR = 1319988837; ceXfzoHZIvCIPDxR > 0; ceXfzoHZIvCIPDxR--) {
        lgevDSZg = lgevDSZg;
    }

    for (int CVCQpXUgViZCW = 1215827165; CVCQpXUgViZCW > 0; CVCQpXUgViZCW--) {
        yvUjEaYQZwRtF += lgevDSZg;
    }

    if (YHdlKoaH < 153297.23326198244) {
        for (int DaXLyuaNDDxkC = 1119766383; DaXLyuaNDDxkC > 0; DaXLyuaNDDxkC--) {
            lgevDSZg = yvUjEaYQZwRtF;
            IgWMNsKxOBeQIfNJ = ! QnJKWuhQSmraEZk;
            QnJKWuhQSmraEZk = IgWMNsKxOBeQIfNJ;
            YHdlKoaH /= zuprWiKeMcQ;
        }
    }

    if (IgWMNsKxOBeQIfNJ != true) {
        for (int lgoIArH = 606623996; lgoIArH > 0; lgoIArH--) {
            QnJKWuhQSmraEZk = QnJKWuhQSmraEZk;
            zuprWiKeMcQ += zuprWiKeMcQ;
            kZvxdmiWKGaW = YHdlKoaH;
        }
    }

    for (int jRAJbJJmJbUD = 1992312755; jRAJbJJmJbUD > 0; jRAJbJJmJbUD--) {
        continue;
    }

    for (int lreII = 584246081; lreII > 0; lreII--) {
        lgevDSZg = XLVhbWk;
        XLVhbWk += XLVhbWk;
        IgWMNsKxOBeQIfNJ = ! QnJKWuhQSmraEZk;
        kZvxdmiWKGaW += zuprWiKeMcQ;
        QnJKWuhQSmraEZk = IgWMNsKxOBeQIfNJ;
    }

    return kZvxdmiWKGaW;
}

bool qSQYrvzEUcbriI::dxjMB()
{
    bool hmOvEizQgMi = true;
    double SAzfc = -614293.907849975;
    double eilXUqpeb = 797230.2947003484;

    if (eilXUqpeb >= 797230.2947003484) {
        for (int ZznDQcybLBpPOHqr = 757349000; ZznDQcybLBpPOHqr > 0; ZznDQcybLBpPOHqr--) {
            SAzfc = eilXUqpeb;
            SAzfc = eilXUqpeb;
            eilXUqpeb = SAzfc;
        }
    }

    for (int lZPmXLetYXFnRuWT = 724123395; lZPmXLetYXFnRuWT > 0; lZPmXLetYXFnRuWT--) {
        SAzfc += SAzfc;
        eilXUqpeb /= SAzfc;
        hmOvEizQgMi = ! hmOvEizQgMi;
        eilXUqpeb /= eilXUqpeb;
    }

    if (eilXUqpeb == -614293.907849975) {
        for (int fqEWPRzmyflHZ = 1252834117; fqEWPRzmyflHZ > 0; fqEWPRzmyflHZ--) {
            eilXUqpeb += SAzfc;
            eilXUqpeb /= SAzfc;
            SAzfc -= SAzfc;
            hmOvEizQgMi = hmOvEizQgMi;
            hmOvEizQgMi = hmOvEizQgMi;
            eilXUqpeb /= SAzfc;
            hmOvEizQgMi = hmOvEizQgMi;
        }
    }

    for (int CvHOqlFJXu = 226949159; CvHOqlFJXu > 0; CvHOqlFJXu--) {
        SAzfc = SAzfc;
        hmOvEizQgMi = hmOvEizQgMi;
    }

    for (int suFAjzouXb = 720234408; suFAjzouXb > 0; suFAjzouXb--) {
        SAzfc /= eilXUqpeb;
    }

    if (SAzfc == 797230.2947003484) {
        for (int kLqRtcxmE = 1514204934; kLqRtcxmE > 0; kLqRtcxmE--) {
            eilXUqpeb = SAzfc;
            SAzfc -= eilXUqpeb;
            hmOvEizQgMi = ! hmOvEizQgMi;
        }
    }

    return hmOvEizQgMi;
}

void qSQYrvzEUcbriI::HhhIJlmKnK(int FcsTCzD)
{
    string gVHsO = string("QHWQhqedHtjLrCCqgKSdJSICIschvDbOHrLpsQqcHhjCKpGmXFtOfbsLyxHdZmXpHgzdvsscIlBAJplFtDyjuAtrSqQPVcIolfxtpiOzKyolrcvWYiptLcpIRPgAoAfeOLMHzGUhJbRLKNJuEeZGXwlfxRtfusVWvLfhQFkaKITbDuttwwPoYzTLTqGLhDPctxItnpyYQIhsjcYFckRritYgVbgmpPLJFnrculA");
    bool hawFgZKYxFZi = false;

    for (int VVArW = 1366165304; VVArW > 0; VVArW--) {
        hawFgZKYxFZi = ! hawFgZKYxFZi;
    }

    for (int kqXhXHNvYzaIlyb = 1437427274; kqXhXHNvYzaIlyb > 0; kqXhXHNvYzaIlyb--) {
        FcsTCzD -= FcsTCzD;
    }

    for (int EjvzP = 2106970117; EjvzP > 0; EjvzP--) {
        FcsTCzD -= FcsTCzD;
        hawFgZKYxFZi = hawFgZKYxFZi;
        hawFgZKYxFZi = ! hawFgZKYxFZi;
    }

    if (gVHsO == string("QHWQhqedHtjLrCCqgKSdJSICIschvDbOHrLpsQqcHhjCKpGmXFtOfbsLyxHdZmXpHgzdvsscIlBAJplFtDyjuAtrSqQPVcIolfxtpiOzKyolrcvWYiptLcpIRPgAoAfeOLMHzGUhJbRLKNJuEeZGXwlfxRtfusVWvLfhQFkaKITbDuttwwPoYzTLTqGLhDPctxItnpyYQIhsjcYFckRritYgVbgmpPLJFnrculA")) {
        for (int yUktxVnY = 369242908; yUktxVnY > 0; yUktxVnY--) {
            continue;
        }
    }
}

int qSQYrvzEUcbriI::YnzKfZRDA(bool abQQHz, int QRtKNhrrxqwi, double tIuJaUrOpbcg, int QmYnsdFVYS)
{
    bool pENimLduTd = true;
    string MljxpAwKqzz = string("bVLwooKXcXIKJrFEMfUPXuNsoElQdFycSJuFQqsgctNsEnPYmAtjHDpYcqUsXCHmHaJTLUcVvtALiFMYHasFRGgirtSjYnXmhUZtRZBAQMdAXBzzyTfJCOEaJaSsHKZbMOyMArDZCefvUrRdsabPyunWhWuyEXPQjHULqZxXzRmUGFgrWydNvEuFJkhXQDSNrCoQELAeCLxZAjctZwmxUIHvztZXwKLTlkGwgMPkSDOIrWVJbS");
    string wthJAJ = string("KkLzKXAROEShDiowDeIywUlmtEpZQtPiVSmbEUKwUzFCCAHqbrfdCowtlMFhofnYuTdbwlOkLfDPzrGqKBmdzYEFrQknlIIfCLcIDiPHPUUODULQCVDtFXHAXPnDxZStezMuXXQyznrooZrwNjzFGpKIzohQbXUhOFEMbptPtFJdBHbmvskbyLMBIrKBQHtMkJCuUbgyfypzmxVZ");
    double FYhWDpXjVBlWZv = -812210.9417868328;
    int zhImqltiq = 351226749;
    double onkpvoFwFnoJ = -1036730.7377017675;

    for (int YsRYMxMiYIdIQ = 876599900; YsRYMxMiYIdIQ > 0; YsRYMxMiYIdIQ--) {
        continue;
    }

    if (pENimLduTd == true) {
        for (int uXoAQJaTYLJp = 1851764922; uXoAQJaTYLJp > 0; uXoAQJaTYLJp--) {
            tIuJaUrOpbcg -= onkpvoFwFnoJ;
            zhImqltiq += QmYnsdFVYS;
            FYhWDpXjVBlWZv /= onkpvoFwFnoJ;
        }
    }

    if (onkpvoFwFnoJ != -812210.9417868328) {
        for (int pRCWYTTgnO = 470793886; pRCWYTTgnO > 0; pRCWYTTgnO--) {
            QmYnsdFVYS -= QmYnsdFVYS;
            FYhWDpXjVBlWZv /= tIuJaUrOpbcg;
        }
    }

    for (int LNKDojvfdErWoPZ = 106161243; LNKDojvfdErWoPZ > 0; LNKDojvfdErWoPZ--) {
        continue;
    }

    return zhImqltiq;
}

bool qSQYrvzEUcbriI::oMYca(double UwWTtjYzXj, int uEbZBg, double mUyrxNVCpFJsCay)
{
    double VuIYlJUEgFr = 351909.4128275883;
    bool kvtXMWMFbKerI = true;
    double vlxvOwC = -397753.76662686537;

    for (int EHPvDTyJwIeC = 259816849; EHPvDTyJwIeC > 0; EHPvDTyJwIeC--) {
        UwWTtjYzXj /= vlxvOwC;
        VuIYlJUEgFr += UwWTtjYzXj;
        vlxvOwC -= UwWTtjYzXj;
        mUyrxNVCpFJsCay += VuIYlJUEgFr;
    }

    return kvtXMWMFbKerI;
}

double qSQYrvzEUcbriI::GItoRxNxUzLezzwA(bool pgyVxP, double ulvoYxt)
{
    bool CNRXh = true;

    if (pgyVxP == true) {
        for (int jDtnpj = 1961227994; jDtnpj > 0; jDtnpj--) {
            ulvoYxt *= ulvoYxt;
            ulvoYxt = ulvoYxt;
            ulvoYxt *= ulvoYxt;
            ulvoYxt /= ulvoYxt;
        }
    }

    return ulvoYxt;
}

double qSQYrvzEUcbriI::IXChHZWlLJ(double ZhkgCwZdtP, bool AsHDSJIxKdzk, double BKsWkSzGTcCLrad)
{
    double RlWCdCCl = 968120.3083481996;

    for (int GLsBYElHAs = 144175440; GLsBYElHAs > 0; GLsBYElHAs--) {
        ZhkgCwZdtP += ZhkgCwZdtP;
        ZhkgCwZdtP -= RlWCdCCl;
        ZhkgCwZdtP += RlWCdCCl;
        ZhkgCwZdtP -= ZhkgCwZdtP;
        BKsWkSzGTcCLrad *= BKsWkSzGTcCLrad;
        RlWCdCCl += BKsWkSzGTcCLrad;
        BKsWkSzGTcCLrad += BKsWkSzGTcCLrad;
    }

    if (ZhkgCwZdtP > 610516.5576914373) {
        for (int OXVvhbhBfKi = 1516579877; OXVvhbhBfKi > 0; OXVvhbhBfKi--) {
            ZhkgCwZdtP -= RlWCdCCl;
            AsHDSJIxKdzk = ! AsHDSJIxKdzk;
            ZhkgCwZdtP /= BKsWkSzGTcCLrad;
            RlWCdCCl = RlWCdCCl;
            BKsWkSzGTcCLrad += ZhkgCwZdtP;
        }
    }

    return RlWCdCCl;
}

void qSQYrvzEUcbriI::nrjoMoxt(int sEzyv)
{
    double VYxnLem = 822057.1043968195;
    string piVWqHYhwUIsT = string("vQOaAUNsUOHPrHtHbbpeqCdbEjBHUwCtVuIFHlfdQsbdVwJstHuITZhGbKUQCfLMnDQhnlhJQrjaHKfKHRjqtuwWqWxyabPFoxBkwSguAAoBMcclzXutmIySNjOinUz");
    bool DDdsuHXSJjxQ = false;
    string TbscyIEiugBaCb = string("MPacLzPvRCvrcgJKaxVmdBjxDITUURLzhxaO");

    for (int yRdJT = 1797579529; yRdJT > 0; yRdJT--) {
        sEzyv /= sEzyv;
        DDdsuHXSJjxQ = DDdsuHXSJjxQ;
    }

    for (int ZsRBkzF = 677903568; ZsRBkzF > 0; ZsRBkzF--) {
        TbscyIEiugBaCb = TbscyIEiugBaCb;
    }

    for (int lbFvIWEt = 11007506; lbFvIWEt > 0; lbFvIWEt--) {
        TbscyIEiugBaCb += piVWqHYhwUIsT;
        piVWqHYhwUIsT = piVWqHYhwUIsT;
        sEzyv /= sEzyv;
    }
}

string qSQYrvzEUcbriI::TBBPNqBbBd(string wXIwA, bool SGFFYZEFPKvmWmpn, double lDpidMCqqWVPbi, double YzjbPqOhGdBvO, double SLuHoXyAWCxTiO)
{
    bool iuOvqFHKTpfxWMx = true;
    int VVInSev = 2044183943;
    bool yeUsipdpzryMgP = true;
    double bnTtYGRqn = 811055.4197203153;
    string oPmKvDNihIIUvrSC = string("mnZRXlqDMVVsXpkXLUUoypWSwRpiNJdCEj");
    bool iXwHyw = true;
    int gOSjmGQD = -1780135032;
    int GgvnTRYBd = 976535082;
    bool DKUZg = false;

    for (int LLOdOB = 121801816; LLOdOB > 0; LLOdOB--) {
        YzjbPqOhGdBvO += lDpidMCqqWVPbi;
        DKUZg = ! iuOvqFHKTpfxWMx;
    }

    for (int gkfVBsZry = 2001342252; gkfVBsZry > 0; gkfVBsZry--) {
        SGFFYZEFPKvmWmpn = yeUsipdpzryMgP;
        SLuHoXyAWCxTiO *= SLuHoXyAWCxTiO;
        yeUsipdpzryMgP = DKUZg;
        iuOvqFHKTpfxWMx = ! iuOvqFHKTpfxWMx;
    }

    return oPmKvDNihIIUvrSC;
}

void qSQYrvzEUcbriI::xGPLRvXBsgl()
{
    int nTiqGJdwUzN = -122444171;
    int ZarNhlBEpChXLyYI = 1993013110;
    string iagRgnGtF = string("bLgHXPwQboXDAPRfzJSDDqIudAdTYeLcnomTOEaLUUCxGargVLaqxKHDrZaEtFLrnoYobqxkntJzfDSlTlZigGDzGHwgIxFkWhtDljBZyvOvevGOXJOAhtpQOQlQPbZdNurRFXaHHEMaMfoJxpkErkFgGOLYlqgoEHKToWawpRV");
    int MfZDLUYcsLES = 1890264985;
    bool NRaURxvmcXkoSWb = true;
    int yJLYAmNjKIj = 1691411671;
    string MkWXnsstJHeRgvcm = string("YsacQbfkciaeeHlKXCmWXfqSEFdkLHzakxvbUdwuTaBJqIuUmhCSTXSXVWJHmGDeyWfKBYrstVGEzLJfsGFMIuKLBIpFfoOreltNjvxxWITDWiRTfnmxiXTbVImZzgQSIucbewzNdtLNLYeJEjUQjHDNMpGHgmzAFQuRwXdlGBTJrCsUJXPUtzOyRQlfNSXvkfUOpshg");

    for (int jlowqgdVHkQqUEqX = 1157847595; jlowqgdVHkQqUEqX > 0; jlowqgdVHkQqUEqX--) {
        MfZDLUYcsLES += ZarNhlBEpChXLyYI;
        yJLYAmNjKIj += nTiqGJdwUzN;
        NRaURxvmcXkoSWb = ! NRaURxvmcXkoSWb;
    }

    for (int NuwTcIePpT = 217901582; NuwTcIePpT > 0; NuwTcIePpT--) {
        continue;
    }

    if (NRaURxvmcXkoSWb != true) {
        for (int zRlatqeuNMt = 798348162; zRlatqeuNMt > 0; zRlatqeuNMt--) {
            ZarNhlBEpChXLyYI /= MfZDLUYcsLES;
            ZarNhlBEpChXLyYI += ZarNhlBEpChXLyYI;
        }
    }
}

qSQYrvzEUcbriI::qSQYrvzEUcbriI()
{
    this->hEHovv();
    this->AgDGiOR();
    this->rQNfCeaXgid();
    this->ydBWbCHarhrtDpD(true, -596106735, -1829195194, 185009.8897496125);
    this->exFOSqb(525108438, string("BxtcEwcwmYtlzVZJ"));
    this->IyhSPM(false, 2000338424, true);
    this->GfRhQVbEKDktIEy(string("PJHYCZpxHPHoDSshPazeMbwQDItzSCLBmNrkHRoSPDNEz"), true, 347996.16937110765, false, 1725021599);
    this->xsRHrAfQg(string("UZxoPUrniCIrJfRnzqoONJzfWRVeofqJftwoRUGycQMzHjJRiGrQFwdFHtPKUCxuBaHLkzHsycMykdbKqStJ"), string("ZFIedgPxulUWbRXiaWYbeCJaEsUIrwLsWTDImFbKOkspZCwsPfKupDmBTd"), string("dXCYMyOBvTpPcjExRgUttUeQdCmZUMkDgHrpyylyPlfMEstXFiWePvSUcbneN"));
    this->dxjMB();
    this->HhhIJlmKnK(900278682);
    this->YnzKfZRDA(false, 1114545254, -437679.69869628054, -869693982);
    this->oMYca(-891921.7377347462, 483146476, -857553.7697567017);
    this->GItoRxNxUzLezzwA(true, 577099.0736898025);
    this->IXChHZWlLJ(610516.5576914373, true, 555448.8433861061);
    this->nrjoMoxt(-252350514);
    this->TBBPNqBbBd(string("JIgdKTptJczMiGGjKzsHIfkDGIsimInEcSeTPtVUfcivCyrihqkwzyITrcnxCqRyESEpjXNSejtJAMpGKpyWUOiBzHULjgrgQrTNLwbvaJAakrJYrZeHrlpisrJfzLHXGxAiwQvWIxVFgxRJXkkHplDeefuMztyNHjGQbJvCLYBeFWPLBUUnTEUceBjPeEgtbSKlNUrvFzbuSmaPDVkqUoyFCxHW"), true, -553721.9737006198, 719318.1867328639, -260808.4408443359);
    this->xGPLRvXBsgl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eLBqixCbQXdkGQEl
{
public:
    string MbmqwWSFxdTraRU;
    string aODNSoBMIYbY;

    eLBqixCbQXdkGQEl();
    int fYlDN(string CrmKjCKDakc, bool SMxbsLDUnNh, int fkQmRFHhUb, int xGrtZrZwCClwZWl, int BlnSmqfV);
    bool iKGnuOGwN(int ChGzjXN, int rWaTjJQgiZPeArDe, bool RXMTBSaSGg, string HeKwdohEpcPVDjv, double lyMdhavvst);
protected:
    bool fRFebh;
    int sSeOMXBovdiLGlP;
    bool RQKcQHP;
    int iCAFV;
    bool rFrNX;
    double mDZOVw;

    string onUvWzxvHnJLhZrE();
    string iXAOL(int wGvsnhiS, double mvysKmoRFFOS);
    bool rnLUea(int uJWcdlq);
    bool ehRSaMHrOwYlP(bool EBHjRgyBgBzdvKr, string QoIFFZJR, bool eLoZuFEHHUBEh, int jCWDMOpOMnPEJGl);
    bool IvOsDuxDRExR(bool cdbtyBgxw, double kDblQRzayC, string KbcHLoTaeVPnat);
    void uzVCchsOloiT(bool InSpTF, string DcGcpFOMHh, string dLwmJDRMOAvPf, int XSdAfKUPF, string AyXOpzzCXHGILcw);
    string aoIKtnMZKxuS(bool QyPuSt, int efPiOAliP);
    double iRzIEvrlQQjPQUK();
private:
    bool vxLKmuadMILy;

    bool GlqeJnjPIdpFRs(bool TNzCZSxCEAcXnmd, int TtDjeQN, string hKeFAwJhYxkDsGll, double oTfEyBQnEV, bool pIAyDK);
};

int eLBqixCbQXdkGQEl::fYlDN(string CrmKjCKDakc, bool SMxbsLDUnNh, int fkQmRFHhUb, int xGrtZrZwCClwZWl, int BlnSmqfV)
{
    double RlsdMBtETsH = 198510.18160728228;
    double MohuyBqchkrzIGI = -678296.2348641498;
    double vJuzysmB = -396676.2290281011;
    int xiSaeh = -1896196296;
    int UqrLVCtrdfbZ = 547213993;
    double VYkxHmXXgOxT = -747550.9381623867;

    for (int eJYSwssZdnyCsXFd = 586198068; eJYSwssZdnyCsXFd > 0; eJYSwssZdnyCsXFd--) {
        UqrLVCtrdfbZ /= fkQmRFHhUb;
        RlsdMBtETsH = RlsdMBtETsH;
    }

    for (int WxJIavoaP = 305370341; WxJIavoaP > 0; WxJIavoaP--) {
        continue;
    }

    for (int CBHZTw = 1292656931; CBHZTw > 0; CBHZTw--) {
        BlnSmqfV = fkQmRFHhUb;
        UqrLVCtrdfbZ /= UqrLVCtrdfbZ;
        xiSaeh += xiSaeh;
        VYkxHmXXgOxT *= RlsdMBtETsH;
    }

    for (int zITpXkztNrVJyF = 147950918; zITpXkztNrVJyF > 0; zITpXkztNrVJyF--) {
        MohuyBqchkrzIGI += vJuzysmB;
        fkQmRFHhUb += fkQmRFHhUb;
        xiSaeh *= xiSaeh;
    }

    return UqrLVCtrdfbZ;
}

bool eLBqixCbQXdkGQEl::iKGnuOGwN(int ChGzjXN, int rWaTjJQgiZPeArDe, bool RXMTBSaSGg, string HeKwdohEpcPVDjv, double lyMdhavvst)
{
    bool rBTVPhgGXPmw = false;
    double DwWgUnKPHNZgtmxE = -6811.340084261593;
    bool iymEXhNzxWoumOp = true;
    int WDGlOFifXV = -1815491888;

    for (int WOdgswJtv = 745212399; WOdgswJtv > 0; WOdgswJtv--) {
        ChGzjXN /= rWaTjJQgiZPeArDe;
        rBTVPhgGXPmw = iymEXhNzxWoumOp;
        rWaTjJQgiZPeArDe /= WDGlOFifXV;
    }

    for (int Cjptq = 731576604; Cjptq > 0; Cjptq--) {
        DwWgUnKPHNZgtmxE = lyMdhavvst;
    }

    if (lyMdhavvst == 49828.66052165467) {
        for (int FJpuVsRgx = 2103685813; FJpuVsRgx > 0; FJpuVsRgx--) {
            continue;
        }
    }

    if (rBTVPhgGXPmw == false) {
        for (int ulkjnPrhpsEUuFl = 1965485300; ulkjnPrhpsEUuFl > 0; ulkjnPrhpsEUuFl--) {
            lyMdhavvst /= lyMdhavvst;
        }
    }

    for (int qFAOJhLmuLgCJpt = 1782157910; qFAOJhLmuLgCJpt > 0; qFAOJhLmuLgCJpt--) {
        continue;
    }

    return iymEXhNzxWoumOp;
}

string eLBqixCbQXdkGQEl::onUvWzxvHnJLhZrE()
{
    int asblgqIfKBPA = 757924964;
    string VygUmoLG = string("EQASLxbXlrcEHCzDtUGSbfOdtXkNPxGAYYJAgRfEcaKQKuMlOmTWQPYJVYILFdQiURXrZvOtQPlpHiYXYBsBhToLqvNBFEKEknAEqgopiOxwFnlaWvcIRrVEmKSUhPxaCrubZLxzXdxKOuzKhsINVhxULdTWWzTlPRmFIkZDznkgcKEAaCAdGBzsqJKLVNlMfFaQAvsbJUAMaOL");

    if (VygUmoLG < string("EQASLxbXlrcEHCzDtUGSbfOdtXkNPxGAYYJAgRfEcaKQKuMlOmTWQPYJVYILFdQiURXrZvOtQPlpHiYXYBsBhToLqvNBFEKEknAEqgopiOxwFnlaWvcIRrVEmKSUhPxaCrubZLxzXdxKOuzKhsINVhxULdTWWzTlPRmFIkZDznkgcKEAaCAdGBzsqJKLVNlMfFaQAvsbJUAMaOL")) {
        for (int tIguBrVNyd = 1637752425; tIguBrVNyd > 0; tIguBrVNyd--) {
            VygUmoLG = VygUmoLG;
        }
    }

    if (VygUmoLG > string("EQASLxbXlrcEHCzDtUGSbfOdtXkNPxGAYYJAgRfEcaKQKuMlOmTWQPYJVYILFdQiURXrZvOtQPlpHiYXYBsBhToLqvNBFEKEknAEqgopiOxwFnlaWvcIRrVEmKSUhPxaCrubZLxzXdxKOuzKhsINVhxULdTWWzTlPRmFIkZDznkgcKEAaCAdGBzsqJKLVNlMfFaQAvsbJUAMaOL")) {
        for (int vVmcqspO = 509885309; vVmcqspO > 0; vVmcqspO--) {
            VygUmoLG += VygUmoLG;
            asblgqIfKBPA -= asblgqIfKBPA;
            asblgqIfKBPA *= asblgqIfKBPA;
            VygUmoLG = VygUmoLG;
            VygUmoLG = VygUmoLG;
            asblgqIfKBPA = asblgqIfKBPA;
        }
    }

    return VygUmoLG;
}

string eLBqixCbQXdkGQEl::iXAOL(int wGvsnhiS, double mvysKmoRFFOS)
{
    int oFpQmSESJYg = 947178910;
    int FByOY = -1883820399;
    bool LkLDeQwdWEcxSFg = false;
    double tgAiewuq = -726242.9623841313;
    bool Ajowpvy = true;
    bool tprenQAUPH = false;
    int KilaoQMPjGkv = -1914447171;
    double tzUUzA = 794071.7737441477;

    for (int qSMpoNTRLduUziLY = 313662975; qSMpoNTRLduUziLY > 0; qSMpoNTRLduUziLY--) {
        wGvsnhiS += wGvsnhiS;
        tprenQAUPH = LkLDeQwdWEcxSFg;
        oFpQmSESJYg /= FByOY;
        tgAiewuq /= tgAiewuq;
        LkLDeQwdWEcxSFg = Ajowpvy;
    }

    for (int IksQvDe = 568506385; IksQvDe > 0; IksQvDe--) {
        FByOY -= oFpQmSESJYg;
        wGvsnhiS /= oFpQmSESJYg;
        oFpQmSESJYg = wGvsnhiS;
    }

    if (Ajowpvy != false) {
        for (int cSUVUWxdW = 1014221511; cSUVUWxdW > 0; cSUVUWxdW--) {
            mvysKmoRFFOS *= tzUUzA;
        }
    }

    return string("idkDdwpMsoluClfPulLeVbADApXidWLeAYImKLVJZhdidvXnQotojjWZzMrqwykWWtbiNnbnauoTjxQnNKFeWreSiqtCKIEJjbPLrrRUxrZfZAFQMWINkJmBedJWBpLTdbxgeHBWmekgAwgENyJzFOwMbEXJgmMInCp");
}

bool eLBqixCbQXdkGQEl::rnLUea(int uJWcdlq)
{
    int OGAyW = -624991382;
    int RciXzedcatonlnna = -1480904249;
    int KbBCL = 875959027;
    double PrCUSXWODj = 809025.661302326;

    if (KbBCL < 875959027) {
        for (int ooRqSxMoRQ = 178805068; ooRqSxMoRQ > 0; ooRqSxMoRQ--) {
            OGAyW /= uJWcdlq;
            uJWcdlq *= OGAyW;
            RciXzedcatonlnna -= OGAyW;
            RciXzedcatonlnna -= OGAyW;
            KbBCL = RciXzedcatonlnna;
            uJWcdlq *= OGAyW;
        }
    }

    return false;
}

bool eLBqixCbQXdkGQEl::ehRSaMHrOwYlP(bool EBHjRgyBgBzdvKr, string QoIFFZJR, bool eLoZuFEHHUBEh, int jCWDMOpOMnPEJGl)
{
    string qfjdmCo = string("AwehARDNduzaSqEbJKSnlltMrrixBBXjvEsMRfElXPfukCyiaVPMlTMuRenbXkyinWKICOeDRhQHBKJpWHdtwVZq");
    string nlaLDFNQGbHiC = string("jBwuOJNIRGxtJOFOejkXBUpptoyMzbqktTxjreElUXUWaZgRmgJZxCyECLHerbyHXipUJtLkriTdRgZwnjdjOWcEwCU");
    int NEVUJuplM = -2012643685;
    int mwrlqwRV = 1900471217;
    bool UvAymOyEhAtQEcFb = false;
    double TqbEfeAMhlNcHzz = -371679.0072547921;
    bool xSYbUHpHMVmidC = true;
    bool PYfwufFJ = true;
    string iOZVZKxS = string("stTURRLTzphkqmsZiAbTFJNdBUMqGdjgoYnSAKaRVYKBhSEtCOjpSIfQORhBTPtiuzKVBsQPUYvsuPmQPOZFzSvklcQEEJbXCkFQSztuwtHacsGRctbRQqhdYMPZlJajALxinTamPUGfSFcNRGMzxHKTpVWOBwuwEqBBKHkIwU");

    if (UvAymOyEhAtQEcFb == true) {
        for (int bwAecNPCHVYnEv = 322626934; bwAecNPCHVYnEv > 0; bwAecNPCHVYnEv--) {
            xSYbUHpHMVmidC = xSYbUHpHMVmidC;
            nlaLDFNQGbHiC = qfjdmCo;
            iOZVZKxS += nlaLDFNQGbHiC;
        }
    }

    for (int VMOHRY = 253996724; VMOHRY > 0; VMOHRY--) {
        continue;
    }

    return PYfwufFJ;
}

bool eLBqixCbQXdkGQEl::IvOsDuxDRExR(bool cdbtyBgxw, double kDblQRzayC, string KbcHLoTaeVPnat)
{
    double afNCysNEcuXwOHLr = 534420.159949861;
    double HUXvKSwM = 820731.5380003351;
    bool MTsXqAMDbBYtyUW = true;
    bool UHDjiRdWPmEMl = true;
    bool JebleIQgbIfMVDj = true;
    double oZJhVKT = 267830.5726828739;
    double expqZiJRyDZ = 821442.8596631609;

    if (expqZiJRyDZ > 267830.5726828739) {
        for (int mpgFPpWqvPXonEoc = 1650137650; mpgFPpWqvPXonEoc > 0; mpgFPpWqvPXonEoc--) {
            HUXvKSwM -= expqZiJRyDZ;
            JebleIQgbIfMVDj = ! cdbtyBgxw;
        }
    }

    for (int IFqIGGgtASp = 1525352057; IFqIGGgtASp > 0; IFqIGGgtASp--) {
        afNCysNEcuXwOHLr /= kDblQRzayC;
        oZJhVKT += oZJhVKT;
    }

    if (HUXvKSwM != 267830.5726828739) {
        for (int JKnqUSwVdlMhANZB = 1351276518; JKnqUSwVdlMhANZB > 0; JKnqUSwVdlMhANZB--) {
            HUXvKSwM -= expqZiJRyDZ;
        }
    }

    return JebleIQgbIfMVDj;
}

void eLBqixCbQXdkGQEl::uzVCchsOloiT(bool InSpTF, string DcGcpFOMHh, string dLwmJDRMOAvPf, int XSdAfKUPF, string AyXOpzzCXHGILcw)
{
    double RFRGIxPXdVSOH = 386232.75326473307;

    if (AyXOpzzCXHGILcw <= string("QSTtvjlFGREGiBrxLzEBdfufHFsXhGEnUawMXnYvppCihBepuvzahYUconfEPCYTaKCLPzPTflCGaEErEpNYVLvYsRuhZbYuyptQVColjIUYyAKQRxEMGvVkxWkUAZIhuVEETSqIRnXPMMBqYFBUQSLfvKLMhSEXYGVsBcgjIJrtMBnLgLqlbEaNOZqfbLYRoBykLyNmtLEfZmuYADmKQIMnzBxCtDojVkAxQ")) {
        for (int CIcCiFNXTZIlIAbc = 89102881; CIcCiFNXTZIlIAbc > 0; CIcCiFNXTZIlIAbc--) {
            DcGcpFOMHh += DcGcpFOMHh;
            DcGcpFOMHh += DcGcpFOMHh;
            RFRGIxPXdVSOH /= RFRGIxPXdVSOH;
            XSdAfKUPF -= XSdAfKUPF;
            dLwmJDRMOAvPf += dLwmJDRMOAvPf;
            dLwmJDRMOAvPf = DcGcpFOMHh;
        }
    }

    for (int HzgKhSUuRXvOT = 1545800737; HzgKhSUuRXvOT > 0; HzgKhSUuRXvOT--) {
        DcGcpFOMHh = DcGcpFOMHh;
    }

    for (int SYZKze = 1828657611; SYZKze > 0; SYZKze--) {
        continue;
    }

    for (int lXvpsg = 25939724; lXvpsg > 0; lXvpsg--) {
        continue;
    }
}

string eLBqixCbQXdkGQEl::aoIKtnMZKxuS(bool QyPuSt, int efPiOAliP)
{
    string FfLVwFabRwGkgyYv = string("OpvjKvndXyZurZekHrtLwwVvEKGfaBqWfibRVWgtvhRkouMSrGBxBEgWXMVHbyWKVbbiZCYbdamgRSvEWvrCzaoozQGPLpMhuvIePsEjFRjncfOiMC");
    int VunoYLPKvGxvvaGp = -244690108;
    string YHMHhb = string("UgFKAgqRikTUQgZbUrIaAgLPpUfJnVSVnmWQcFKtrgSIuXLIBNeJIkpWgpySug");
    bool oFOKQTRaaIzQmE = false;
    string WnSyTRdLnWvuxmC = string("iMAOPWbcciwJxPKYrhHiFwSLmTLorSkOvbwDEkrsvpKFpqnqZDoDDKkGRpqKmKRgYcxyksAOLwOMv");
    bool WvWePIJx = true;
    bool SjmSToZmFUQJ = true;
    bool kNzOzBTckAy = true;
    bool kmCSPjcZ = false;

    if (kNzOzBTckAy == true) {
        for (int hEdPbZmzJBw = 308576243; hEdPbZmzJBw > 0; hEdPbZmzJBw--) {
            WnSyTRdLnWvuxmC = FfLVwFabRwGkgyYv;
            YHMHhb = WnSyTRdLnWvuxmC;
            kmCSPjcZ = kNzOzBTckAy;
        }
    }

    if (YHMHhb <= string("iMAOPWbcciwJxPKYrhHiFwSLmTLorSkOvbwDEkrsvpKFpqnqZDoDDKkGRpqKmKRgYcxyksAOLwOMv")) {
        for (int FLuyIXWIguaEm = 2108102239; FLuyIXWIguaEm > 0; FLuyIXWIguaEm--) {
            SjmSToZmFUQJ = kmCSPjcZ;
        }
    }

    for (int XSkKfwb = 1421332843; XSkKfwb > 0; XSkKfwb--) {
        WnSyTRdLnWvuxmC = FfLVwFabRwGkgyYv;
    }

    for (int TWmXFwR = 54070409; TWmXFwR > 0; TWmXFwR--) {
        kmCSPjcZ = ! kmCSPjcZ;
        efPiOAliP = VunoYLPKvGxvvaGp;
        WnSyTRdLnWvuxmC += FfLVwFabRwGkgyYv;
    }

    return WnSyTRdLnWvuxmC;
}

double eLBqixCbQXdkGQEl::iRzIEvrlQQjPQUK()
{
    bool jqpSgkUHNGWRRTVJ = false;
    string DpGytzY = string("xzEaHEfVssCqMArHcdPxvEZNjwvQdIcdLJyT");
    double CJhUmRWoNJt = 368807.9825571512;
    double nBMBjrdhwd = -176276.05028989448;
    double ynvPqTvuTD = 23101.295517569153;

    for (int eiNoEKZgOC = 968316065; eiNoEKZgOC > 0; eiNoEKZgOC--) {
        nBMBjrdhwd += CJhUmRWoNJt;
        DpGytzY += DpGytzY;
    }

    for (int ADUXbDG = 2102678094; ADUXbDG > 0; ADUXbDG--) {
        ynvPqTvuTD = CJhUmRWoNJt;
    }

    if (ynvPqTvuTD >= -176276.05028989448) {
        for (int BZUbAbACovsYqh = 502803997; BZUbAbACovsYqh > 0; BZUbAbACovsYqh--) {
            ynvPqTvuTD /= CJhUmRWoNJt;
            nBMBjrdhwd += CJhUmRWoNJt;
        }
    }

    for (int anYiWIKStGfaOoq = 1249283222; anYiWIKStGfaOoq > 0; anYiWIKStGfaOoq--) {
        nBMBjrdhwd = CJhUmRWoNJt;
        ynvPqTvuTD /= ynvPqTvuTD;
    }

    return ynvPqTvuTD;
}

bool eLBqixCbQXdkGQEl::GlqeJnjPIdpFRs(bool TNzCZSxCEAcXnmd, int TtDjeQN, string hKeFAwJhYxkDsGll, double oTfEyBQnEV, bool pIAyDK)
{
    int iUxGYdjOXWanfAcE = 203771900;
    string wHQkLbmCuDIx = string("FvwAFZyYyvLyfROKgsjEnVSCHZCCpVozvftSzaPmQOHplpOWAbEbYujwlvCCGhBRxpfseldWTrINCrKUmamLDIpHfNGRlpuNkVSzFDkCyGVzrQhLfEgncYljGtwrcFCOvDbfucLb");
    bool UhrdPRAdCMzx = true;
    int HsimmJRsRvszs = -1775151441;
    string jTxAaX = string("livtloGWkOTMczZCcWKfqivCqyDVUzfVwYpmQvJhUQQUxvkwrNhkbcncxhmmWckQeBHPedsRSREfYpwWcXUAhldGRDhDbRbIxdFRlZaBnyRKCBHjvcFaBrCinlhMoiDLJysfoXlsLCwcXmYPBotjVOoTlswEYGOGsIVrUkrzWRcRHeChHGSGRTOGQDLEnWjiQAGgCxBeOqQcGuAUuABistJbngPJNfAItfvFjaqKALwcFDbwsTr");

    if (UhrdPRAdCMzx == true) {
        for (int USaDsaFmsv = 1918432471; USaDsaFmsv > 0; USaDsaFmsv--) {
            TtDjeQN += HsimmJRsRvszs;
        }
    }

    return UhrdPRAdCMzx;
}

eLBqixCbQXdkGQEl::eLBqixCbQXdkGQEl()
{
    this->fYlDN(string("QlZudNhebegQOxOnmTtknfsJxnqTtRniVRPfldCzBQGkHvsiDbdvbAV"), false, 1051400540, -1146771808, -1047990580);
    this->iKGnuOGwN(-861332243, -1709044679, false, string("GLqyNtsnjzuPnnUqNQzMB"), 49828.66052165467);
    this->onUvWzxvHnJLhZrE();
    this->iXAOL(-914941082, -320519.9385361817);
    this->rnLUea(-649835036);
    this->ehRSaMHrOwYlP(false, string("BVltDNsZAWXORfhtMKTYZUxpNdsQFacIruoqbqrrMPAOUrOGEHJDikFRouZKxVelJIDibnSTsjDOFldqUwOsnVmsDhZbsJFSKlueGPemphHKwgcHqDzoGhnHSXYtdNABfwRlhARhiYqxDXMZBjYVeCrtcPUZoxnSrtxjgPAauZrMlRwksDsgHFsQIteENfDDtMIkvRQqoMHWhTdEROtEBuSxHQQZIDqekQkwVuAmGeEKtjJmWkPTykBZRpoKn"), false, 746640658);
    this->IvOsDuxDRExR(true, 415444.0176410694, string("vRJYahwqhlCafdRdQNMCsxjuSoqYmccEyCqrFLwEAvImRjrdCBhSmTBZFTKQThZQEBsuVuLokFStZxTUnMaTLZutXoiLWEwGqDOypsfOBiBdEeVtKNKcEpWDsu"));
    this->uzVCchsOloiT(true, string("tDCUpmsQFhSArJFuuxgNNtUKFedSwwzDiCxRfQDbFlJXgVaCWSGxpbSqaPSycAFpxMOXcTExQUWjzOCHZfMBkwrmmuMQRROORjkCXYjWGoiETfUUoMrVIWndrCAJAioHxydoqwOcorkbmTbdBJDhzsxtbGKHGalxSjSWdevevkDfFvZWCcgMmLvupmbCjBqWNdzPrvUpNSxtFTDjHNEPJvLTSOuXxdJkICznjDdCHasOqQveiMPAexuTm"), string("QSTtvjlFGREGiBrxLzEBdfufHFsXhGEnUawMXnYvppCihBepuvzahYUconfEPCYTaKCLPzPTflCGaEErEpNYVLvYsRuhZbYuyptQVColjIUYyAKQRxEMGvVkxWkUAZIhuVEETSqIRnXPMMBqYFBUQSLfvKLMhSEXYGVsBcgjIJrtMBnLgLqlbEaNOZqfbLYRoBykLyNmtLEfZmuYADmKQIMnzBxCtDojVkAxQ"), -2063654247, string("ZGMSipMQqIOtJJStxBxvJmlwDYuXhJvWHBOLZkKTlJXzYhKcuVTHUTQhDVlVXWxURgvhTPPryYBUrqOdjZgqMJsxroqzrJJqKGoPrjJVqcfdaJungTJxecEQcMOtLNOhzJzwSWuphVEujIdRglGRXWrVrvMTFAdzFZFjuzFZNwwEvkYImnPDIQdyONxKdNSiqgXquUBPaRhJRExRSGCnujhOtEqhTEYQq"));
    this->aoIKtnMZKxuS(false, -1186592410);
    this->iRzIEvrlQQjPQUK();
    this->GlqeJnjPIdpFRs(false, -1110410062, string("lQSTzVtewXCelSAoaZmkmjegEdCOlthYjPeHuwWwMOMfFgcbQyhWdeuTAiXJZuZsMEQffeoZXuJkUh"), -46322.5703331134, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oVQTmPnm
{
public:
    double YhxUZOYzHjZjo;
    bool NIZMCwIGZd;
    double ZkMFJZbyB;
    string wBTiedJcM;

    oVQTmPnm();
    string xDAEnXMYYSoQfV(double lopRZZgcaYNBQrwe, string QJboLgoDprNt, int wAiWZLMgS);
    void UuQxQplbaIMWAtkr(int jXWyAEvDQp);
    int PUizXr(string myBXfjUOs);
    void mTWnCyFUAzdNEHe(double BoUWtpHFUWcmzg, string jSrBgpL);
    bool BbeiLn(int kqNiyitp, double EgQwbZzrONxo);
    void cQbHuedgZXDKxuoB(double kshsNh, string PmabQ, string zShFErBhVhsT);
    void TurmanmfINNd(int OkUYnOol);
protected:
    int PHFcGDg;

private:
    bool vVaoYLL;
    bool lUvLutfWW;

    int MDgzm(string ZyZtPfZ, int YQveyuxSWdSYJIpB);
};

string oVQTmPnm::xDAEnXMYYSoQfV(double lopRZZgcaYNBQrwe, string QJboLgoDprNt, int wAiWZLMgS)
{
    bool bAVENFeRybv = true;

    for (int QKsLUIUqwpfgHV = 2014829147; QKsLUIUqwpfgHV > 0; QKsLUIUqwpfgHV--) {
        QJboLgoDprNt += QJboLgoDprNt;
        lopRZZgcaYNBQrwe *= lopRZZgcaYNBQrwe;
    }

    if (lopRZZgcaYNBQrwe < 562658.2562904332) {
        for (int SPWZEDQcswgakWpu = 1669281696; SPWZEDQcswgakWpu > 0; SPWZEDQcswgakWpu--) {
            bAVENFeRybv = bAVENFeRybv;
        }
    }

    for (int wcIJprdccbPyOr = 1580717409; wcIJprdccbPyOr > 0; wcIJprdccbPyOr--) {
        continue;
    }

    for (int nBGvRNsPIhYGLzZv = 410142404; nBGvRNsPIhYGLzZv > 0; nBGvRNsPIhYGLzZv--) {
        bAVENFeRybv = bAVENFeRybv;
        lopRZZgcaYNBQrwe -= lopRZZgcaYNBQrwe;
    }

    for (int KgahxOHhSzzjaRV = 1969990497; KgahxOHhSzzjaRV > 0; KgahxOHhSzzjaRV--) {
        lopRZZgcaYNBQrwe = lopRZZgcaYNBQrwe;
        lopRZZgcaYNBQrwe += lopRZZgcaYNBQrwe;
    }

    return QJboLgoDprNt;
}

void oVQTmPnm::UuQxQplbaIMWAtkr(int jXWyAEvDQp)
{
    bool FQQFF = true;
    bool DUuEMJ = false;
    bool YcMsqKQ = true;
    string iLjMZhyQns = string("fnWwXkxNxlVQtvvqooKLtnLDSzFYkxWetcihNOyiqQczwSRsWuzYALqkrNfDUsoWcAIqCzhqZYcNcEnwprKfpQvKcyMtPbnAEfkqmQzrAxJopVgPKnzAktNKrlmSVveCLAuzwJqByCnu");
    string lxHtVwLhDsbWPYaK = string("IklEJuvqeoohHOL");
    double lfxAUjrw = -376280.6899641618;
    string ZnVIsUsLRJzMqAsw = string("IqnqCdwJcSECGVzfoNcOatMHFykkpnBAYqTWZXfruNhJniYpuNwsQciRRbZsYMybTVaquPqCnZYErQqZzcstcHAgXmRHjzfGKHWWIUwwarEAIMshVSWklyBUyUboOCMBIdGeEJQWKXTIxSJMuZLaohnPektIKlkgOWGVAIpoRRwTMgUabGJRH");
    bool yrTbyN = false;
    bool yUuOikHkw = false;
    bool ZUhNnvQY = false;

    for (int BygiANN = 868978415; BygiANN > 0; BygiANN--) {
        yrTbyN = ! FQQFF;
        ZUhNnvQY = yrTbyN;
    }

    for (int PPzqL = 1538395581; PPzqL > 0; PPzqL--) {
        jXWyAEvDQp += jXWyAEvDQp;
    }

    if (yUuOikHkw != true) {
        for (int huLCGQwvoqjqkous = 1328565212; huLCGQwvoqjqkous > 0; huLCGQwvoqjqkous--) {
            yrTbyN = ! yrTbyN;
            iLjMZhyQns = iLjMZhyQns;
            ZnVIsUsLRJzMqAsw += iLjMZhyQns;
            yrTbyN = ! DUuEMJ;
        }
    }

    for (int bhMZOhsnqOyzaMpN = 315777823; bhMZOhsnqOyzaMpN > 0; bhMZOhsnqOyzaMpN--) {
        YcMsqKQ = yUuOikHkw;
        FQQFF = ! YcMsqKQ;
        YcMsqKQ = ZUhNnvQY;
        yrTbyN = ! DUuEMJ;
    }

    for (int qURBoNLesmgExIpS = 1971634847; qURBoNLesmgExIpS > 0; qURBoNLesmgExIpS--) {
        continue;
    }

    for (int JvFjcnp = 562569156; JvFjcnp > 0; JvFjcnp--) {
        lxHtVwLhDsbWPYaK = ZnVIsUsLRJzMqAsw;
    }
}

int oVQTmPnm::PUizXr(string myBXfjUOs)
{
    bool zoGNqgLNDlc = true;
    double NLFiQxzB = -598244.419487624;
    double HfDQd = 429761.8867438125;

    for (int UVgCB = 1522129308; UVgCB > 0; UVgCB--) {
        zoGNqgLNDlc = zoGNqgLNDlc;
    }

    if (NLFiQxzB < 429761.8867438125) {
        for (int srPDGSty = 1991642717; srPDGSty > 0; srPDGSty--) {
            continue;
        }
    }

    for (int CkBVmAHPdqAwg = 956763872; CkBVmAHPdqAwg > 0; CkBVmAHPdqAwg--) {
        myBXfjUOs += myBXfjUOs;
        HfDQd += NLFiQxzB;
        HfDQd = NLFiQxzB;
    }

    for (int ibzEy = 512717279; ibzEy > 0; ibzEy--) {
        NLFiQxzB -= NLFiQxzB;
    }

    return 212246300;
}

void oVQTmPnm::mTWnCyFUAzdNEHe(double BoUWtpHFUWcmzg, string jSrBgpL)
{
    bool hQbeGNcQAqQX = true;
    int sCpwlcZ = 187388424;
    bool sxySCRRWHX = true;
    int ryiBeXWwKluc = -1826221025;
    string KzbOj = string("hSbKHqvvQmcXpkEBPoXjieFpqZLhbWabadTgrjmVWmZmyjHOTDniWJEaHjBTbNMmuWuMTosTgbjkvNIruTOifngLzdeTkjQFaZTjsulVqSgmRwZExWXewVGVRFjoZIwtZJEXOUawpTvrktwqOGahvzGHXMhvufQSKJoaFRMDJYcoVwD");

    for (int OCuYLpDGcBDkWK = 434180166; OCuYLpDGcBDkWK > 0; OCuYLpDGcBDkWK--) {
        continue;
    }
}

bool oVQTmPnm::BbeiLn(int kqNiyitp, double EgQwbZzrONxo)
{
    double XwENUBP = 842833.7740633516;
    string awwZPjDg = string("eTuXraSZgTMmSgEolAzoWdYbBRHfhXrpxhDgjrOqytlOwoLTDYFtiymKirAhBGaPjYOQTZZCkMoitUmnIhlwxKVmxxrlJUhMzQEmowqfvPJdAlXkR");
    string iYciOnfqzXD = string("OqCPrWyBoDBYlvcvcmEzhIVUxTiedwtzpJwGlpVukpkoBeFlChZIMmIdlBfkYuHSqYvmexVJZBLScpccggz");
    bool YFZqVXv = true;
    int SyLImFsxYdnG = -742284669;

    for (int qyKznF = 1755071020; qyKznF > 0; qyKznF--) {
        iYciOnfqzXD += iYciOnfqzXD;
    }

    for (int rhKJOiOQPfhMCcsH = 1625865987; rhKJOiOQPfhMCcsH > 0; rhKJOiOQPfhMCcsH--) {
        XwENUBP *= XwENUBP;
    }

    if (awwZPjDg == string("eTuXraSZgTMmSgEolAzoWdYbBRHfhXrpxhDgjrOqytlOwoLTDYFtiymKirAhBGaPjYOQTZZCkMoitUmnIhlwxKVmxxrlJUhMzQEmowqfvPJdAlXkR")) {
        for (int DDsRgVE = 1158066418; DDsRgVE > 0; DDsRgVE--) {
            kqNiyitp /= kqNiyitp;
            awwZPjDg = iYciOnfqzXD;
            EgQwbZzrONxo -= XwENUBP;
            EgQwbZzrONxo /= EgQwbZzrONxo;
        }
    }

    for (int hsNYVYRvctLx = 1237998412; hsNYVYRvctLx > 0; hsNYVYRvctLx--) {
        continue;
    }

    for (int lwKqlWyHv = 617609397; lwKqlWyHv > 0; lwKqlWyHv--) {
        XwENUBP /= EgQwbZzrONxo;
        XwENUBP -= XwENUBP;
    }

    return YFZqVXv;
}

void oVQTmPnm::cQbHuedgZXDKxuoB(double kshsNh, string PmabQ, string zShFErBhVhsT)
{
    int EFqDAkQsOLHACyxJ = -1470243279;

    for (int aolBFUA = 1874140161; aolBFUA > 0; aolBFUA--) {
        zShFErBhVhsT = zShFErBhVhsT;
        PmabQ += PmabQ;
        zShFErBhVhsT = PmabQ;
    }
}

void oVQTmPnm::TurmanmfINNd(int OkUYnOol)
{
    bool UWVuxusdXisHN = false;
    string TKLbdpLra = string("rLTtwVDRBQrLSUFygmAzDVegctZOeZINehIVCtMNqdLejzUUnpEJpdqcOnFukBqaXLojpXYmjIEldgTYRzyhoGRBZwrJvccSTkHbdCDYgyEYAefiuRAaCpbdjsFEPQRHqUEDHbL");
    double BodZoszycPHGBg = -771420.8084344917;
    bool tPuHqrDUgQgURmR = false;
    string OvKdmXKvzqMeQ = string("qqHxPtKNqXCPvDIkknGOZIWfZSPSCqUWcoGHgbynyIGfQgEyKfJErhidzExqigcVX");
    bool LCRzZPkDn = true;
    string RejfK = string("MisECMLEAIuPDSXcKRWarVZgNsRJvezxvJNeewIOgGWZOFUdbjNXaoCPyViomyfRsbQjtFuoielfthgPDZOzZUyxNbGWJrmKNyasqrwUUzYAigLOkoqVDSAQeNBOZsgxxYnlRMv");
    string OCdaqQvmYIcn = string("nHarqeNBaRYMFJIbQhvklNLKMkvLJJrZBBaPFfNegFDxeKbNnJpZXAZEFiXecWCdZPgnSgLgtUqNkEMhkWovopTfUYsHPufIjzekhFxpeqQgeulmFodaSZdsFpgrIbqPFmOWvVkB");
    bool grbLM = false;
    string UAFWdWExqlYs = string("goyXOtGgbSjacNjxVZsdbyRbtfLjGfEzldMjxNiDyebySZsoLIYFAQSQCvilugFaEEFWWmmaTIXIkaJGYfsXptNMxQNblhNkvgHyNZZfFdtaThNSSFeYdUAxGsBiKyeUcIpsOXOgtjdRNpMTMerKfOQPDPxMExRvrSqrNgEnwlqofExmhv");

    if (LCRzZPkDn == false) {
        for (int DvSBEzyVBRfV = 1190433278; DvSBEzyVBRfV > 0; DvSBEzyVBRfV--) {
            OvKdmXKvzqMeQ += OvKdmXKvzqMeQ;
            RejfK += UAFWdWExqlYs;
            LCRzZPkDn = ! LCRzZPkDn;
            OCdaqQvmYIcn = RejfK;
            grbLM = LCRzZPkDn;
        }
    }

    for (int xfJhm = 499051821; xfJhm > 0; xfJhm--) {
        tPuHqrDUgQgURmR = UWVuxusdXisHN;
    }

    if (OCdaqQvmYIcn == string("qqHxPtKNqXCPvDIkknGOZIWfZSPSCqUWcoGHgbynyIGfQgEyKfJErhidzExqigcVX")) {
        for (int RYufaELCHYfiat = 465746707; RYufaELCHYfiat > 0; RYufaELCHYfiat--) {
            grbLM = LCRzZPkDn;
        }
    }

    for (int iYJFvYhJROUw = 116378450; iYJFvYhJROUw > 0; iYJFvYhJROUw--) {
        tPuHqrDUgQgURmR = UWVuxusdXisHN;
        LCRzZPkDn = ! tPuHqrDUgQgURmR;
        TKLbdpLra += RejfK;
    }

    if (UAFWdWExqlYs != string("rLTtwVDRBQrLSUFygmAzDVegctZOeZINehIVCtMNqdLejzUUnpEJpdqcOnFukBqaXLojpXYmjIEldgTYRzyhoGRBZwrJvccSTkHbdCDYgyEYAefiuRAaCpbdjsFEPQRHqUEDHbL")) {
        for (int cvQSUYFEOwQQG = 1710853059; cvQSUYFEOwQQG > 0; cvQSUYFEOwQQG--) {
            grbLM = grbLM;
            OvKdmXKvzqMeQ = OCdaqQvmYIcn;
            tPuHqrDUgQgURmR = ! grbLM;
            TKLbdpLra = TKLbdpLra;
        }
    }

    if (tPuHqrDUgQgURmR == false) {
        for (int FXRqxdZwmjXWYwBv = 258445894; FXRqxdZwmjXWYwBv > 0; FXRqxdZwmjXWYwBv--) {
            OkUYnOol = OkUYnOol;
            UAFWdWExqlYs += OCdaqQvmYIcn;
            OvKdmXKvzqMeQ = UAFWdWExqlYs;
            OCdaqQvmYIcn = OvKdmXKvzqMeQ;
        }
    }
}

int oVQTmPnm::MDgzm(string ZyZtPfZ, int YQveyuxSWdSYJIpB)
{
    int jnbJmlEwunWIWMl = -1432385353;

    for (int OyzHqBHjBOdIoo = 633514245; OyzHqBHjBOdIoo > 0; OyzHqBHjBOdIoo--) {
        jnbJmlEwunWIWMl = jnbJmlEwunWIWMl;
        ZyZtPfZ = ZyZtPfZ;
        ZyZtPfZ += ZyZtPfZ;
        YQveyuxSWdSYJIpB /= jnbJmlEwunWIWMl;
        ZyZtPfZ += ZyZtPfZ;
        jnbJmlEwunWIWMl *= YQveyuxSWdSYJIpB;
    }

    for (int zYuQnSVUsjjE = 913846310; zYuQnSVUsjjE > 0; zYuQnSVUsjjE--) {
        jnbJmlEwunWIWMl *= jnbJmlEwunWIWMl;
    }

    return jnbJmlEwunWIWMl;
}

oVQTmPnm::oVQTmPnm()
{
    this->xDAEnXMYYSoQfV(562658.2562904332, string("cahRyC"), -874447814);
    this->UuQxQplbaIMWAtkr(-227722823);
    this->PUizXr(string("OQkSbLFDsGZkXeTTwyGh"));
    this->mTWnCyFUAzdNEHe(102621.66632465919, string("igFEluiFSbOqpSEBFAJSGIcfwELVUnaqBStLyazVEu"));
    this->BbeiLn(-1924148467, 356679.23847014504);
    this->cQbHuedgZXDKxuoB(-741315.1138498908, string("mskOkMzzlGnHnbIqMmIuoHgMKcXJoDoUknvmdLqLspTBHvtQzVOWOKdkHoQjuyXVUiJeXzSqluLeOXllHyROVxNKsCNVyjSWKiMVGoTmGpKcBslwRBpgPaKwLVKPzPqscBoxPQXzhcCLyiHjnO"), string("ZQrkuRIBqxyszBdoPJOElmcyuoXErxlAAAbzeNLXhVibxHdbRKveKgxbVZegQcAXikQUJJFMIqusfVoZQnPedPGoWJOvmf"));
    this->TurmanmfINNd(-1817940590);
    this->MDgzm(string("uXFyfYAgwGgUeyJegEYViELQPUxazRSFwUYpMpdgmktiTdIPeiWWhBLvsEWBXqgdaxbkKIlVlvqDINeCbePGTNfoitDITavCkJSarReCSrqSEpuFyrIdSTKxWKYdenNqCvRDezluqdbjGDfmShvOFLTyfkpcKoOSEDzjzApHbzWNLVcWsaeOPYLDDfciIJgCAVQinResCNUScTrlczGZAzPuwAItq"), 1453409309);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hPXbzdWsOXiRQSo
{
public:
    double oPepp;
    double uFKru;

    hPXbzdWsOXiRQSo();
protected:
    int dbykpuQhgqjONNFh;
    int VvtaA;

    string HVUwV(string HzqtKmlaZ, string RTZqGXG, double sCMUOScSNhC);
    double XenyUa(bool mLnPUKBLvP, string UUTMnnaEGgO);
private:
    string xGQaiEyelcliuFKg;
    int wABHzbgah;
    double txttjq;
    string ThbohRSoCBuj;
    double mFpuayNuCwcit;
    double vnTYqLh;

    void fbVAsVnMc(string LfmFWrLkMTaPK, bool EnDEaMgfqJekTvh, int glnLGjKUyFzvYisN, string XLCYVlCapg, int XWtAZqcS);
};

string hPXbzdWsOXiRQSo::HVUwV(string HzqtKmlaZ, string RTZqGXG, double sCMUOScSNhC)
{
    string dhwXNPHurORhF = string("JEjKLehsJnLxDJQEUfgsnNZoQMdXvPpVGQAxkExFnTulKrhAtPXzuBERSzftazAmHkxVztuMncdAeSPopEbTAVejafCrBbcxvAXXhUpNvLyhUHXvJNGWAxPrmhagSyUyVKDkmoIUezyOCrhDhKGCvMIGUwHRVxRvlyPtCEODYwCXdLeRLZUeQDiezxfVYdSOyjljBuyS");

    if (HzqtKmlaZ <= string("BedJHIpnYYiqmSvxiYeTWAEYYVOudJvJZjDwnekCPkZDtmsLwPDXKZyhbmnPUpqYdXisvtMcrEVEjqOXAcOnWjoEOgxwZLwNWoSLsNouqflXfHOpMFwrhPwYxxnwTHaDmXoedwrjEF")) {
        for (int ygWjc = 340698853; ygWjc > 0; ygWjc--) {
            continue;
        }
    }

    if (dhwXNPHurORhF > string("JEjKLehsJnLxDJQEUfgsnNZoQMdXvPpVGQAxkExFnTulKrhAtPXzuBERSzftazAmHkxVztuMncdAeSPopEbTAVejafCrBbcxvAXXhUpNvLyhUHXvJNGWAxPrmhagSyUyVKDkmoIUezyOCrhDhKGCvMIGUwHRVxRvlyPtCEODYwCXdLeRLZUeQDiezxfVYdSOyjljBuyS")) {
        for (int UJpNREqfrsDLoV = 551086540; UJpNREqfrsDLoV > 0; UJpNREqfrsDLoV--) {
            HzqtKmlaZ = HzqtKmlaZ;
            sCMUOScSNhC -= sCMUOScSNhC;
            dhwXNPHurORhF += RTZqGXG;
        }
    }

    for (int HyLsiUTJlWoWC = 794990255; HyLsiUTJlWoWC > 0; HyLsiUTJlWoWC--) {
        dhwXNPHurORhF = RTZqGXG;
        dhwXNPHurORhF = RTZqGXG;
        dhwXNPHurORhF += HzqtKmlaZ;
    }

    return dhwXNPHurORhF;
}

double hPXbzdWsOXiRQSo::XenyUa(bool mLnPUKBLvP, string UUTMnnaEGgO)
{
    int DGSnDdrSVoHF = 1529988244;
    bool QleCUGBAxILQ = false;
    bool jMEbwJQtbCiKkPo = false;
    double vQDiJGrk = -801092.0144902883;
    string CiFsICDAstmCRV = string("yDWMktudjRJoDorKchztBKdDPtyXynXNPanmTiyJBedLhpEgdPKaZdlfqEnvEbRUkoYlHKKwqisXsZxozRXXDbvUklrIhRqoqZZEjGOXTOdYvpYEGSWsROgVUyPCUmwXE");

    if (vQDiJGrk < -801092.0144902883) {
        for (int vSVmfCBm = 37574335; vSVmfCBm > 0; vSVmfCBm--) {
            QleCUGBAxILQ = QleCUGBAxILQ;
        }
    }

    return vQDiJGrk;
}

void hPXbzdWsOXiRQSo::fbVAsVnMc(string LfmFWrLkMTaPK, bool EnDEaMgfqJekTvh, int glnLGjKUyFzvYisN, string XLCYVlCapg, int XWtAZqcS)
{
    int utkExTNooRVe = -1256447982;
    bool WyCWwBsu = false;
    double hkYqHD = -4318.965176001418;
    bool xjOGuN = false;

    for (int iICuWNhqwKA = 163101633; iICuWNhqwKA > 0; iICuWNhqwKA--) {
        continue;
    }
}

hPXbzdWsOXiRQSo::hPXbzdWsOXiRQSo()
{
    this->HVUwV(string("BedJHIpnYYiqmSvxiYeTWAEYYVOudJvJZjDwnekCPkZDtmsLwPDXKZyhbmnPUpqYdXisvtMcrEVEjqOXAcOnWjoEOgxwZLwNWoSLsNouqflXfHOpMFwrhPwYxxnwTHaDmXoedwrjEF"), string("VacoymbNXMjqABiS"), -220073.96743322193);
    this->XenyUa(true, string("knPMuxOffNqAbQmviPYkkWMEExzOaZaMiBznlgBVqWNABLgdPVbKTmUZSVEwgCkjZctGljFuGNzDaePXVQgSGcrcbEjZgNKVKUHffdfBCEnkgLGaVzBGYZopOjVTGxyfRozkuTpDwwuURtDNcwVMYOcodZSCGEpPIEPaZXdAmExubOneaYdpWfnAXvxrBPNTOEvSDVxXQfgylXShPLqfJqoWkJhnhkoJWnwSZNlwwBq"));
    this->fbVAsVnMc(string("mLrDMyKztdikaSsFDtXxCXrjRZaHYEpRySUNTvRwasgDJTKmLwiCLRrpiPjFgjkdsYzjKvygPmDTeVZKPHJVZQixBsfLxAurrWwCJeIFORfBEQhLohssSQfYTMcozoDCtyoptwAeafouRRninQMRpbSueVaMVyHCOeEnTFJHFyNzatNIYpcyUTgMNrCDkRuVAmNzJYekcoiOhf"), false, 2082103759, string("yJLpQuGngKBZjpLe"), 1020576597);
}
