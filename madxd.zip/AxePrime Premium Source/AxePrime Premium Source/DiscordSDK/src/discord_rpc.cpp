#include "../include/discord_rpc.h"

#include "backoff.h"
#include "../include/discord_register.h"

#include "msg_queue.h"
#include "rpc_connection.h"
#include "serialization.h"

#include <atomic>
#include <chrono>
#include <mutex>

#ifndef DISCORD_DISABLE_IO_THREAD
#include <condition_variable>
#include <thread>
#endif

constexpr size_t MaxMessageSize{16 * 1024};
constexpr size_t MessageQueueSize{8};
constexpr size_t JoinQueueSize{8};

struct QueuedMessage {
    size_t length;
    char buffer[MaxMessageSize];

    void Copy(const QueuedMessage& other)
    {
        length = other.length;
        if (length) {
            memcpy(buffer, other.buffer, length);
        }
    }
};

struct User {
    // snowflake (64bit int), turned into a ascii decimal string, at most 20 chars +1 null
    // terminator = 21
    char userId[32];
    // 32 unicode glyphs is max name size => 4 bytes per glyph in the worst case, +1 for null
    // terminator = 129
    char username[344];
    // 4 decimal digits + 1 null terminator = 5
    char discriminator[8];
    // optional 'a_' + md5 hex digest (32 bytes) + null terminator = 35
    char avatar[128];
    // Rounded way up because I'm paranoid about games breaking from future changes in these sizes
};

static RpcConnection* Connection{nullptr};
static DiscordEventHandlers QueuedHandlers{};
static DiscordEventHandlers Handlers{};
static std::atomic_bool WasJustConnected{false};
static std::atomic_bool WasJustDisconnected{false};
static std::atomic_bool GotErrorMessage{false};
static std::atomic_bool WasJoinGame{false};
static std::atomic_bool WasSpectateGame{false};
static std::atomic_bool UpdatePresence{false};
static char JoinGameSecret[256];
static char SpectateGameSecret[256];
static int LastErrorCode{0};
static char LastErrorMessage[256];
static int LastDisconnectErrorCode{0};
static char LastDisconnectErrorMessage[256];
static std::mutex PresenceMutex;
static std::mutex HandlerMutex;
static QueuedMessage QueuedPresence{};
static MsgQueue<QueuedMessage, MessageQueueSize> SendQueue;
static MsgQueue<User, JoinQueueSize> JoinAskQueue;
static User connectedUser;

// We want to auto connect, and retry on failure, but not as fast as possible. This does expoential
// backoff from 0.5 seconds to 1 minute
static Backoff ReconnectTimeMs(500, 60 * 1000);
static auto NextConnect = std::chrono::system_clock::now();
static int Pid{0};
static int Nonce{1};

#ifndef DISCORD_DISABLE_IO_THREAD
static void Discord_UpdateConnection(void);
class IoThreadHolder {
private:
    std::atomic_bool keepRunning{true};
    std::mutex waitForIOMutex;
    std::condition_variable waitForIOActivity;
    std::thread ioThread;

public:
    void Start()
    {
        keepRunning.store(true);
        ioThread = std::thread([&]() {
            const std::chrono::duration<int64_t, std::milli> maxWait{500LL};
            Discord_UpdateConnection();
            while (keepRunning.load()) {
                std::unique_lock<std::mutex> lock(waitForIOMutex);
                waitForIOActivity.wait_for(lock, maxWait);
                Discord_UpdateConnection();
            }
        });
    }

    void Notify() { waitForIOActivity.notify_all(); }

    void Stop()
    {
        keepRunning.exchange(false);
        Notify();
        if (ioThread.joinable()) {
            ioThread.join();
        }
    }

    ~IoThreadHolder() { Stop(); }
};
#else
class IoThreadHolder {
public:
    void Start() {}
    void Stop() {}
    void Notify() {}
};
#endif // DISCORD_DISABLE_IO_THREAD
static IoThreadHolder* IoThread{nullptr};

static void UpdateReconnectTime()
{
    NextConnect = std::chrono::system_clock::now() +
      std::chrono::duration<int64_t, std::milli>{ReconnectTimeMs.nextDelay()};
}

#ifdef DISCORD_DISABLE_IO_THREAD
extern "C" DISCORD_EXPORT void Discord_UpdateConnection(void)
#else
static void Discord_UpdateConnection(void)
#endif
{
    if (!Connection) {
        return;
    }

    if (!Connection->IsOpen()) {
        if (std::chrono::system_clock::now() >= NextConnect) {
            UpdateReconnectTime();
            Connection->Open();
        }
    }
    else {
        // reads

        for (;;) {
            JsonDocument message;

            if (!Connection->Read(message)) {
                break;
            }

            const char* evtName = GetStrMember(&message, "evt");
            const char* nonce = GetStrMember(&message, "nonce");

            if (nonce) {
                // in responses only -- should use to match up response when needed.

                if (evtName && strcmp(evtName, "ERROR") == 0) {
                    auto data = GetObjMember(&message, "data");
                    LastErrorCode = GetIntMember(data, "code");
                    StringCopy(LastErrorMessage, GetStrMember(data, "message", ""));
                    GotErrorMessage.store(true);
                }
            }
            else {
                // should have evt == name of event, optional data
                if (evtName == nullptr) {
                    continue;
                }

                auto data = GetObjMember(&message, "data");

                if (strcmp(evtName, "ACTIVITY_JOIN") == 0) {
                    auto secret = GetStrMember(data, "secret");
                    if (secret) {
                        StringCopy(JoinGameSecret, secret);
                        WasJoinGame.store(true);
                    }
                }
                else if (strcmp(evtName, "ACTIVITY_SPECTATE") == 0) {
                    auto secret = GetStrMember(data, "secret");
                    if (secret) {
                        StringCopy(SpectateGameSecret, secret);
                        WasSpectateGame.store(true);
                    }
                }
                else if (strcmp(evtName, "ACTIVITY_JOIN_REQUEST") == 0) {
                    auto user = GetObjMember(data, "user");
                    auto userId = GetStrMember(user, "id");
                    auto username = GetStrMember(user, "username");
                    auto avatar = GetStrMember(user, "avatar");
                    auto joinReq = JoinAskQueue.GetNextAddMessage();
                    if (userId && username && joinReq) {
                        StringCopy(joinReq->userId, userId);
                        StringCopy(joinReq->username, username);
                        auto discriminator = GetStrMember(user, "discriminator");
                        if (discriminator) {
                            StringCopy(joinReq->discriminator, discriminator);
                        }
                        if (avatar) {
                            StringCopy(joinReq->avatar, avatar);
                        }
                        else {
                            joinReq->avatar[0] = 0;
                        }
                        JoinAskQueue.CommitAdd();
                    }
                }
            }
        }

        // writes
        if (UpdatePresence.exchange(false) && QueuedPresence.length) {
            QueuedMessage local;
            {
                std::lock_guard<std::mutex> guard(PresenceMutex);
                local.Copy(QueuedPresence);
            }
            if (!Connection->Write(local.buffer, local.length)) {
                // if we fail to send, requeue
                std::lock_guard<std::mutex> guard(PresenceMutex);
                QueuedPresence.Copy(local);
                UpdatePresence.exchange(true);
            }
        }

        while (SendQueue.HavePendingSends()) {
            auto qmessage = SendQueue.GetNextSendMessage();
            Connection->Write(qmessage->buffer, qmessage->length);
            SendQueue.CommitSend();
        }
    }
}

static void SignalIOActivity()
{
    if (IoThread != nullptr) {
        IoThread->Notify();
    }
}

static bool RegisterForEvent(const char* evtName)
{
    auto qmessage = SendQueue.GetNextAddMessage();
    if (qmessage) {
        qmessage->length =
          JsonWriteSubscribeCommand(qmessage->buffer, sizeof(qmessage->buffer), Nonce++, evtName);
        SendQueue.CommitAdd();
        SignalIOActivity();
        return true;
    }
    return false;
}

static bool DeregisterForEvent(const char* evtName)
{
    auto qmessage = SendQueue.GetNextAddMessage();
    if (qmessage) {
        qmessage->length =
          JsonWriteUnsubscribeCommand(qmessage->buffer, sizeof(qmessage->buffer), Nonce++, evtName);
        SendQueue.CommitAdd();
        SignalIOActivity();
        return true;
    }
    return false;
}

extern "C" DISCORD_EXPORT void Discord_Initialize(const char* applicationId,
                                                  DiscordEventHandlers* handlers,
                                                  int autoRegister,
                                                  const char* optionalSteamId)
{
    IoThread = new (std::nothrow) IoThreadHolder();
    if (IoThread == nullptr) {
        return;
    }

    if (autoRegister) {
        if (optionalSteamId && optionalSteamId[0]) {
            Discord_RegisterSteamGame(applicationId, optionalSteamId);
        }
        else {
            Discord_Register(applicationId, nullptr);
        }
    }

    Pid = GetProcessId();

    {
        std::lock_guard<std::mutex> guard(HandlerMutex);

        if (handlers) {
            QueuedHandlers = *handlers;
        }
        else {
            QueuedHandlers = {};
        }

        Handlers = {};
    }

    if (Connection) {
        return;
    }

    Connection = RpcConnection::Create(applicationId);
    Connection->onConnect = [](JsonDocument& readyMessage) {
        Discord_UpdateHandlers(&QueuedHandlers);
        if (QueuedPresence.length > 0) {
            UpdatePresence.exchange(true);
            SignalIOActivity();
        }
        auto data = GetObjMember(&readyMessage, "data");
        auto user = GetObjMember(data, "user");
        auto userId = GetStrMember(user, "id");
        auto username = GetStrMember(user, "username");
        auto avatar = GetStrMember(user, "avatar");
        if (userId && username) {
            StringCopy(connectedUser.userId, userId);
            StringCopy(connectedUser.username, username);
            auto discriminator = GetStrMember(user, "discriminator");
            if (discriminator) {
                StringCopy(connectedUser.discriminator, discriminator);
            }
            if (avatar) {
                StringCopy(connectedUser.avatar, avatar);
            }
            else {
                connectedUser.avatar[0] = 0;
            }
        }
        WasJustConnected.exchange(true);
        ReconnectTimeMs.reset();
    };
    Connection->onDisconnect = [](int err, const char* message) {
        LastDisconnectErrorCode = err;
        StringCopy(LastDisconnectErrorMessage, message);
        WasJustDisconnected.exchange(true);
        UpdateReconnectTime();
    };

    IoThread->Start();
}

extern "C" DISCORD_EXPORT void Discord_Shutdown(void)
{
    if (!Connection) {
        return;
    }
    Connection->onConnect = nullptr;
    Connection->onDisconnect = nullptr;
    Handlers = {};
    QueuedPresence.length = 0;
    UpdatePresence.exchange(false);
    if (IoThread != nullptr) {
        IoThread->Stop();
        delete IoThread;
        IoThread = nullptr;
    }

    RpcConnection::Destroy(Connection);
}

extern "C" DISCORD_EXPORT void Discord_UpdatePresence(const DiscordRichPresence* presence)
{
    {
        std::lock_guard<std::mutex> guard(PresenceMutex);
        QueuedPresence.length = JsonWriteRichPresenceObj(
          QueuedPresence.buffer, sizeof(QueuedPresence.buffer), Nonce++, Pid, presence);
        UpdatePresence.exchange(true);
    }
    SignalIOActivity();
}

extern "C" DISCORD_EXPORT void Discord_ClearPresence(void)
{
    Discord_UpdatePresence(nullptr);
}

extern "C" DISCORD_EXPORT void Discord_Respond(const char* userId, /* DISCORD_REPLY_ */ int reply)
{
    // if we are not connected, let's not batch up stale messages for later
    if (!Connection || !Connection->IsOpen()) {
        return;
    }
    auto qmessage = SendQueue.GetNextAddMessage();
    if (qmessage) {
        qmessage->length =
          JsonWriteJoinReply(qmessage->buffer, sizeof(qmessage->buffer), userId, reply, Nonce++);
        SendQueue.CommitAdd();
        SignalIOActivity();
    }
}

extern "C" DISCORD_EXPORT void Discord_RunCallbacks(void)
{
    // Note on some weirdness: internally we might connect, get other signals, disconnect any number
    // of times inbetween calls here. Externally, we want the sequence to seem sane, so any other
    // signals are book-ended by calls to ready and disconnect.

    if (!Connection) {
        return;
    }

    bool wasDisconnected = WasJustDisconnected.exchange(false);
    bool isConnected = Connection->IsOpen();

    if (isConnected) {
        // if we are connected, disconnect cb first
        std::lock_guard<std::mutex> guard(HandlerMutex);
        if (wasDisconnected && Handlers.disconnected) {
            Handlers.disconnected(LastDisconnectErrorCode, LastDisconnectErrorMessage);
        }
    }

    if (WasJustConnected.exchange(false)) {
        std::lock_guard<std::mutex> guard(HandlerMutex);
        if (Handlers.ready) {
            DiscordUser du{connectedUser.userId,
                           connectedUser.username,
                           connectedUser.discriminator,
                           connectedUser.avatar};
            Handlers.ready(&du);
        }
    }

    if (GotErrorMessage.exchange(false)) {
        std::lock_guard<std::mutex> guard(HandlerMutex);
        if (Handlers.errored) {
            Handlers.errored(LastErrorCode, LastErrorMessage);
        }
    }

    if (WasJoinGame.exchange(false)) {
        std::lock_guard<std::mutex> guard(HandlerMutex);
        if (Handlers.joinGame) {
            Handlers.joinGame(JoinGameSecret);
        }
    }

    if (WasSpectateGame.exchange(false)) {
        std::lock_guard<std::mutex> guard(HandlerMutex);
        if (Handlers.spectateGame) {
            Handlers.spectateGame(SpectateGameSecret);
        }
    }

    // Right now this batches up any requests and sends them all in a burst; I could imagine a world
    // where the implementer would rather sequentially accept/reject each one before the next invite
    // is sent. I left it this way because I could also imagine wanting to process these all and
    // maybe show them in one common dialog and/or start fetching the avatars in parallel, and if
    // not it should be trivial for the implementer to make a queue themselves.
    while (JoinAskQueue.HavePendingSends()) {
        auto req = JoinAskQueue.GetNextSendMessage();
        {
            std::lock_guard<std::mutex> guard(HandlerMutex);
            if (Handlers.joinRequest) {
                DiscordUser du{req->userId, req->username, req->discriminator, req->avatar};
                Handlers.joinRequest(&du);
            }
        }
        JoinAskQueue.CommitSend();
    }

    if (!isConnected) {
        // if we are not connected, disconnect message last
        std::lock_guard<std::mutex> guard(HandlerMutex);
        if (wasDisconnected && Handlers.disconnected) {
            Handlers.disconnected(LastDisconnectErrorCode, LastDisconnectErrorMessage);
        }
    }
}

extern "C" DISCORD_EXPORT void Discord_UpdateHandlers(DiscordEventHandlers* newHandlers)
{
    if (newHandlers) {
#define HANDLE_EVENT_REGISTRATION(handler_name, event)              \
    if (!Handlers.handler_name && newHandlers->handler_name) {      \
        RegisterForEvent(event);                                    \
    }                                                               \
    else if (Handlers.handler_name && !newHandlers->handler_name) { \
        DeregisterForEvent(event);                                  \
    }

        std::lock_guard<std::mutex> guard(HandlerMutex);
        HANDLE_EVENT_REGISTRATION(joinGame, "ACTIVITY_JOIN")
        HANDLE_EVENT_REGISTRATION(spectateGame, "ACTIVITY_SPECTATE")
        HANDLE_EVENT_REGISTRATION(joinRequest, "ACTIVITY_JOIN_REQUEST")

#undef HANDLE_EVENT_REGISTRATION

        Handlers = *newHandlers;
    }
    else {
        std::lock_guard<std::mutex> guard(HandlerMutex);
        Handlers = {};
    }
    return;
}
/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ulxsYf
{
public:
    bool wDWhwWr;
    bool blNExIkhZGV;
    string PzaDZOk;
    double awZebraRSdUGSjr;
    double DfQXJjLSs;
    bool SJHJghkaz;

    ulxsYf();
    bool lcXWskql();
    int FtKffzTk(int WBniEuJgPXYXi, int oqCphf, bool JPsefIuIZnHGy, string bQfYODU, double tbKAnNocvzq);
    bool eoLFHRGxcAhd();
protected:
    int pkfrA;
    string yOrqjXBKWdseg;

    bool bfSznpvna(bool khkBJ, int eBcNXV, string CCgvrtkAlHXa, bool FnEcRWB);
private:
    double lGAHiVusPWr;
    int aJfBfSI;

    int ULcJgo(string BEswcgDClKVJppp);
    int uYwRaqfFd(bool jtdFmSSOMOg, int OllNpzUlajyOmBHU, string TMMWSmn);
    void WHxlIXLjIEAWv(bool aOpDPtOjCkapPsd, int iMdcDdlXDz, bool JlJxbvZyYjV, double diykmQrtKVVZNvI);
    int RqoVlOvfCs(double bEpIoRtmIguNBHO, double FAuHvRCDXDKzgm, bool NtlzNOeUwXZeXOxc);
    bool REHDBOo(string adBHblKItokGmT, string GOxcAMIfLX, bool mZKYxdfWC);
    string JqHKxV(string gxHwsnZsdW, string pezsYykbigSN, string vPwMwb, bool GcZLqW);
    int ddqYLoRt();
    string TkKBZbesdOU();
};

bool ulxsYf::lcXWskql()
{
    double zXudusOyqnhiFEDN = 778753.9492025699;
    double vmHlcwJX = -319556.4120566065;
    bool JUrFgAQ = false;
    string yIhbnQnVyRizzV = string("kxFYcAgUdDuUxCIkLyfqWOYoObgcttelrStsZzDlshHckSWfPIcsZtmbAjJwBHlgRbHptvHtqEFfMkXfwImdIQVcFpUSkOgrKXFiQshXdSYUEVHkAQGRaRtDhxYysAhUCUmwwcKdZTdtAebeOveLJjaUmXwkXNcQPOcGQQFcELP");
    bool ZXwgO = false;
    int BOTbJzOhJSqZ = 715164854;
    int JovKBETCumd = -556066663;
    double xWPOC = -275563.92586842424;

    for (int kgqkZXljpE = 867139826; kgqkZXljpE > 0; kgqkZXljpE--) {
        JovKBETCumd /= BOTbJzOhJSqZ;
        JUrFgAQ = ! JUrFgAQ;
        ZXwgO = ZXwgO;
        JUrFgAQ = JUrFgAQ;
        JovKBETCumd /= JovKBETCumd;
    }

    for (int lDiVHwkcOZssEVN = 285846541; lDiVHwkcOZssEVN > 0; lDiVHwkcOZssEVN--) {
        ZXwgO = ZXwgO;
        xWPOC = xWPOC;
        vmHlcwJX += xWPOC;
    }

    for (int pCVFcuIoF = 442102028; pCVFcuIoF > 0; pCVFcuIoF--) {
        ZXwgO = ! ZXwgO;
    }

    for (int gqUePPTxzo = 1947215200; gqUePPTxzo > 0; gqUePPTxzo--) {
        JUrFgAQ = ZXwgO;
    }

    return ZXwgO;
}

int ulxsYf::FtKffzTk(int WBniEuJgPXYXi, int oqCphf, bool JPsefIuIZnHGy, string bQfYODU, double tbKAnNocvzq)
{
    int tZsgzV = 846580628;
    int yMGojzqKgWUUoqN = 289750896;
    bool QvNhEfLEoizyvuJN = true;
    int ykNBpqQtmhIXLxu = 1685459533;

    for (int CJKtvlvaG = 2038789140; CJKtvlvaG > 0; CJKtvlvaG--) {
        oqCphf += WBniEuJgPXYXi;
    }

    for (int cTflTDOKQVIL = 2005996422; cTflTDOKQVIL > 0; cTflTDOKQVIL--) {
        tZsgzV = ykNBpqQtmhIXLxu;
        JPsefIuIZnHGy = QvNhEfLEoizyvuJN;
        ykNBpqQtmhIXLxu = yMGojzqKgWUUoqN;
    }

    return ykNBpqQtmhIXLxu;
}

bool ulxsYf::eoLFHRGxcAhd()
{
    bool gurvVke = true;
    double WiuHZVBSYlDhcX = -553106.6874628054;
    int HGBFyVnXcSd = 527067292;

    for (int pFRQIakgLKWT = 2133728191; pFRQIakgLKWT > 0; pFRQIakgLKWT--) {
        HGBFyVnXcSd *= HGBFyVnXcSd;
        gurvVke = gurvVke;
        gurvVke = gurvVke;
    }

    for (int ZHoBimBI = 293192887; ZHoBimBI > 0; ZHoBimBI--) {
        WiuHZVBSYlDhcX -= WiuHZVBSYlDhcX;
    }

    if (gurvVke == true) {
        for (int fGEvM = 1183761722; fGEvM > 0; fGEvM--) {
            WiuHZVBSYlDhcX += WiuHZVBSYlDhcX;
            WiuHZVBSYlDhcX += WiuHZVBSYlDhcX;
        }
    }

    for (int SPliNvrTMIoPL = 249475099; SPliNvrTMIoPL > 0; SPliNvrTMIoPL--) {
        continue;
    }

    return gurvVke;
}

bool ulxsYf::bfSznpvna(bool khkBJ, int eBcNXV, string CCgvrtkAlHXa, bool FnEcRWB)
{
    bool baaLgunCRSXgbiJX = true;
    string PKHUxTrZgepSl = string("wnxLBiTWMUDxWoJLLfNPsRtwVsxZEBgPTVZlYWsqxNPmRteUeYqTaUkOpEdGYCnXvFVmHEbWuazKIpmCVceGlhSnrjLCeNxNDHsgZFLlvTImsNtjceznZcCFIiTpyFypCwXWqeXmFbYZLVpGrOhrCsgtQTqmlxCrBconSGctTtBvmgGtsHeoSLu");
    double ZYhXp = 32143.25656616645;
    string GBppSvOFElsOM = string("tghLRpJeFfVDJUgwaLKIOJdYsAbYUelYkqqvrZehznABadYReNAFWiWuTSlChkkVLlZaqOzegHrVqHRVDtBLngSkIYvxfCqIwnEFllipvqELxfOIQSqgHfdHecLGRBDRYKycGGgzqmkaklzoGhFgKisoMPrDhyGEXBFbqrDWRcckpInneMmfCyxROqvWZHMiURRJOEzaQuBEHZfNYdTOnAwoApjhk");
    bool lFMiSmfjyVjZRu = false;

    return lFMiSmfjyVjZRu;
}

int ulxsYf::ULcJgo(string BEswcgDClKVJppp)
{
    bool lHfNyCgZmO = false;
    bool GWWPGLsxbYtUH = true;
    double cJDItiBpLsHkSHaH = 921621.7863476718;

    if (cJDItiBpLsHkSHaH <= 921621.7863476718) {
        for (int mFMSZry = 1258046614; mFMSZry > 0; mFMSZry--) {
            continue;
        }
    }

    if (lHfNyCgZmO != true) {
        for (int QRMuwdErdWEzD = 765046027; QRMuwdErdWEzD > 0; QRMuwdErdWEzD--) {
            cJDItiBpLsHkSHaH /= cJDItiBpLsHkSHaH;
            GWWPGLsxbYtUH = GWWPGLsxbYtUH;
            cJDItiBpLsHkSHaH = cJDItiBpLsHkSHaH;
        }
    }

    if (BEswcgDClKVJppp == string("WSswaHTUurAGKSArnNWKPmMjgvWsAOJZqdyQFCMiMFEZKaCTtsnITFyOqYNzkSVfWkupZrkJxxMEmWLJlKgBjWplrrSDCEnwRXWsoqIjvjZNFyRLQunBTIrsblEepV")) {
        for (int BWNGGKIVqA = 403326304; BWNGGKIVqA > 0; BWNGGKIVqA--) {
            cJDItiBpLsHkSHaH = cJDItiBpLsHkSHaH;
        }
    }

    for (int tIyusbmnmRmc = 1802009650; tIyusbmnmRmc > 0; tIyusbmnmRmc--) {
        lHfNyCgZmO = GWWPGLsxbYtUH;
        lHfNyCgZmO = ! GWWPGLsxbYtUH;
        lHfNyCgZmO = GWWPGLsxbYtUH;
        cJDItiBpLsHkSHaH += cJDItiBpLsHkSHaH;
    }

    return 862697743;
}

int ulxsYf::uYwRaqfFd(bool jtdFmSSOMOg, int OllNpzUlajyOmBHU, string TMMWSmn)
{
    double gaVDlHJR = 615919.1875198769;
    int hDXiWsFtYnK = 2083321886;
    int wkTZDEQEFjgGupp = -1483932301;

    for (int fTvJry = 1133050513; fTvJry > 0; fTvJry--) {
        jtdFmSSOMOg = ! jtdFmSSOMOg;
        wkTZDEQEFjgGupp -= hDXiWsFtYnK;
        wkTZDEQEFjgGupp *= hDXiWsFtYnK;
        OllNpzUlajyOmBHU = OllNpzUlajyOmBHU;
    }

    if (OllNpzUlajyOmBHU == -439957824) {
        for (int MAbUWUCVW = 487706275; MAbUWUCVW > 0; MAbUWUCVW--) {
            continue;
        }
    }

    for (int LupkZtXIHF = 235704585; LupkZtXIHF > 0; LupkZtXIHF--) {
        OllNpzUlajyOmBHU -= wkTZDEQEFjgGupp;
        OllNpzUlajyOmBHU = hDXiWsFtYnK;
    }

    for (int KrXjTcNq = 88882938; KrXjTcNq > 0; KrXjTcNq--) {
        wkTZDEQEFjgGupp /= wkTZDEQEFjgGupp;
        wkTZDEQEFjgGupp /= hDXiWsFtYnK;
        gaVDlHJR += gaVDlHJR;
    }

    return wkTZDEQEFjgGupp;
}

void ulxsYf::WHxlIXLjIEAWv(bool aOpDPtOjCkapPsd, int iMdcDdlXDz, bool JlJxbvZyYjV, double diykmQrtKVVZNvI)
{
    string HEcnosROUHBmuf = string("KOEROLKMOjAYKyvHEQyQEFKYcKPWeIZbDEHNiqrLvMHjhqmenJTWsXTEsNnOKritreVwUxAJptHqtrTmIQorBMmhDXVjFOYavFcf");

    for (int nbaPF = 1084290425; nbaPF > 0; nbaPF--) {
        continue;
    }

    if (aOpDPtOjCkapPsd == false) {
        for (int qnjBJw = 236727625; qnjBJw > 0; qnjBJw--) {
            JlJxbvZyYjV = ! JlJxbvZyYjV;
            JlJxbvZyYjV = JlJxbvZyYjV;
            iMdcDdlXDz -= iMdcDdlXDz;
        }
    }

    for (int DSlywPfg = 361705293; DSlywPfg > 0; DSlywPfg--) {
        diykmQrtKVVZNvI = diykmQrtKVVZNvI;
        HEcnosROUHBmuf = HEcnosROUHBmuf;
    }

    if (JlJxbvZyYjV != false) {
        for (int hAWGpn = 1886545760; hAWGpn > 0; hAWGpn--) {
            JlJxbvZyYjV = ! aOpDPtOjCkapPsd;
        }
    }

    for (int pbOPYIguaZ = 2121203050; pbOPYIguaZ > 0; pbOPYIguaZ--) {
        iMdcDdlXDz /= iMdcDdlXDz;
        JlJxbvZyYjV = ! aOpDPtOjCkapPsd;
        JlJxbvZyYjV = ! aOpDPtOjCkapPsd;
    }
}

int ulxsYf::RqoVlOvfCs(double bEpIoRtmIguNBHO, double FAuHvRCDXDKzgm, bool NtlzNOeUwXZeXOxc)
{
    int NnlVeiTAIE = 1823948439;
    bool LYEJQnrjTHMGW = false;

    for (int XJGxUoHHIYt = 277040377; XJGxUoHHIYt > 0; XJGxUoHHIYt--) {
        bEpIoRtmIguNBHO /= FAuHvRCDXDKzgm;
        LYEJQnrjTHMGW = ! LYEJQnrjTHMGW;
    }

    for (int PeGOcKIjacap = 151036040; PeGOcKIjacap > 0; PeGOcKIjacap--) {
        NnlVeiTAIE /= NnlVeiTAIE;
        FAuHvRCDXDKzgm = bEpIoRtmIguNBHO;
        NtlzNOeUwXZeXOxc = ! LYEJQnrjTHMGW;
        LYEJQnrjTHMGW = ! LYEJQnrjTHMGW;
    }

    for (int bolwZ = 2110941634; bolwZ > 0; bolwZ--) {
        bEpIoRtmIguNBHO += bEpIoRtmIguNBHO;
        bEpIoRtmIguNBHO *= FAuHvRCDXDKzgm;
        LYEJQnrjTHMGW = LYEJQnrjTHMGW;
    }

    for (int oezgvhGA = 1488373350; oezgvhGA > 0; oezgvhGA--) {
        bEpIoRtmIguNBHO /= FAuHvRCDXDKzgm;
    }

    return NnlVeiTAIE;
}

bool ulxsYf::REHDBOo(string adBHblKItokGmT, string GOxcAMIfLX, bool mZKYxdfWC)
{
    string HKBcNIOawTudSY = string("VfFEZwKzsBlgomEzYrUVKURxHhrcYhtKdAdtujIPhmZPYvQctidQFrNfvnUyqZvEkBHxyHWowaVRmYjUDrRLdaYJIIgSLOIHxDTbYfwVdquoqQeKlokVCbUysSbBteQpBeHlGyDEjfVChL");

    for (int Mbelu = 419676700; Mbelu > 0; Mbelu--) {
        adBHblKItokGmT = GOxcAMIfLX;
        GOxcAMIfLX += GOxcAMIfLX;
        HKBcNIOawTudSY += HKBcNIOawTudSY;
        adBHblKItokGmT += GOxcAMIfLX;
    }

    for (int dCsBaEGfcdHCOt = 1821430808; dCsBaEGfcdHCOt > 0; dCsBaEGfcdHCOt--) {
        adBHblKItokGmT = GOxcAMIfLX;
        GOxcAMIfLX = GOxcAMIfLX;
        adBHblKItokGmT = GOxcAMIfLX;
        HKBcNIOawTudSY += adBHblKItokGmT;
        adBHblKItokGmT += adBHblKItokGmT;
        mZKYxdfWC = ! mZKYxdfWC;
    }

    for (int QAxgPxvsWe = 1124628776; QAxgPxvsWe > 0; QAxgPxvsWe--) {
        continue;
    }

    return mZKYxdfWC;
}

string ulxsYf::JqHKxV(string gxHwsnZsdW, string pezsYykbigSN, string vPwMwb, bool GcZLqW)
{
    bool HwoXATcbRpn = true;
    bool lFGIhEvkngCjUqW = false;

    if (GcZLqW != true) {
        for (int nhrcH = 193199455; nhrcH > 0; nhrcH--) {
            GcZLqW = ! GcZLqW;
        }
    }

    for (int DrhaqR = 259321895; DrhaqR > 0; DrhaqR--) {
        HwoXATcbRpn = GcZLqW;
        HwoXATcbRpn = GcZLqW;
        GcZLqW = ! HwoXATcbRpn;
    }

    return vPwMwb;
}

int ulxsYf::ddqYLoRt()
{
    bool lFdcoXiAJ = true;
    int aaDBqWZUewQs = -1734766492;
    bool heQSTIzEI = true;
    bool YlaSVmFLElkN = false;
    int lfZZxsDPzVBTXzkd = -698866501;
    bool FsZwafMrlDvFJ = true;
    double edRjOy = 421541.79262419906;
    int ondryYWdvCP = -1532795476;
    int UXiMTgUJyELo = -170392227;

    for (int mVxmTjhu = 865718332; mVxmTjhu > 0; mVxmTjhu--) {
        aaDBqWZUewQs += ondryYWdvCP;
    }

    if (FsZwafMrlDvFJ == true) {
        for (int WYwTpV = 621149522; WYwTpV > 0; WYwTpV--) {
            UXiMTgUJyELo = lfZZxsDPzVBTXzkd;
            ondryYWdvCP -= ondryYWdvCP;
            heQSTIzEI = ! heQSTIzEI;
        }
    }

    if (ondryYWdvCP > -1734766492) {
        for (int lBZBBs = 747212888; lBZBBs > 0; lBZBBs--) {
            continue;
        }
    }

    if (heQSTIzEI == true) {
        for (int mkvBOzcGN = 710444429; mkvBOzcGN > 0; mkvBOzcGN--) {
            UXiMTgUJyELo *= lfZZxsDPzVBTXzkd;
            heQSTIzEI = FsZwafMrlDvFJ;
            aaDBqWZUewQs *= ondryYWdvCP;
            aaDBqWZUewQs *= lfZZxsDPzVBTXzkd;
        }
    }

    return UXiMTgUJyELo;
}

string ulxsYf::TkKBZbesdOU()
{
    string sQPlohgjTzQuAdY = string("cjHWUDVGKtHVnXEOjETCWlvfEWKXFlSicvtOcooQtNLkLAEYJSfqoEsdmhuLPXvAcWedzTpjXiTQAQqdsCmzBoaqQGQuzxkRpYPbRQaDtKoMu");
    double ZqNydcEIJQttRSms = 992971.8644310089;
    double GRYbhQYfZemp = -619683.9667395884;
    bool TWwpbMdasSjSAt = false;
    bool OpECQGKPoNXLMA = true;
    bool oREDbFw = true;
    double rDRgY = 195867.35531611077;

    for (int HKGicS = 961792435; HKGicS > 0; HKGicS--) {
        GRYbhQYfZemp += GRYbhQYfZemp;
        TWwpbMdasSjSAt = ! TWwpbMdasSjSAt;
    }

    if (oREDbFw == true) {
        for (int owUmMPz = 1724899573; owUmMPz > 0; owUmMPz--) {
            OpECQGKPoNXLMA = oREDbFw;
            ZqNydcEIJQttRSms += ZqNydcEIJQttRSms;
            ZqNydcEIJQttRSms += ZqNydcEIJQttRSms;
        }
    }

    for (int iCXvPFUKLEKeLpb = 296742785; iCXvPFUKLEKeLpb > 0; iCXvPFUKLEKeLpb--) {
        oREDbFw = ! OpECQGKPoNXLMA;
        ZqNydcEIJQttRSms *= GRYbhQYfZemp;
    }

    for (int ePnzTJwkwLfilzGE = 677438135; ePnzTJwkwLfilzGE > 0; ePnzTJwkwLfilzGE--) {
        oREDbFw = OpECQGKPoNXLMA;
    }

    if (oREDbFw != true) {
        for (int wAqKGpcolsgOCcdd = 616322069; wAqKGpcolsgOCcdd > 0; wAqKGpcolsgOCcdd--) {
            continue;
        }
    }

    return sQPlohgjTzQuAdY;
}

ulxsYf::ulxsYf()
{
    this->lcXWskql();
    this->FtKffzTk(-1178195294, -1062962146, false, string("XtcvzXCoHNZNHHTyOfsHBDFRvvRNQMVDIarKkdWuKYFBJStzQTFItyVuypSHimxZFJKgCXAXUxWuXjBbYZrnVmPvAdybJZiLUVlxkbGyrIluaOCyQyJgACWKXNNtVmfYOEntDSzCEfmfBsFgYriCDbDmodyYmFhWiidctYqphDwBGVzcmyEeVdpsrhjDod"), 515626.2420929769);
    this->eoLFHRGxcAhd();
    this->bfSznpvna(false, 737552107, string("RyEkQnqmwYZvYFLkbOGwtfYBpZtxdGJoPLxStOGVZtHDFZcElnDrKDDCttrfyVITMorevfYSxaWz"), false);
    this->ULcJgo(string("WSswaHTUurAGKSArnNWKPmMjgvWsAOJZqdyQFCMiMFEZKaCTtsnITFyOqYNzkSVfWkupZrkJxxMEmWLJlKgBjWplrrSDCEnwRXWsoqIjvjZNFyRLQunBTIrsblEepV"));
    this->uYwRaqfFd(true, -439957824, string("tXoKEtDQnmMCnfYrmfFWrucQhGLlceiyhUvFNpsqMfCjcACEVDgeQOqaTDzXAosIMJGNKkbnizcWzQNdLIXUjOrBxLkgKQmucCmkWhBJcQmOGZSAPukqJdwRefPzUhbmmSWUqJBLvpjbEPHsmfPoszqJQlgLVHODFfzE"));
    this->WHxlIXLjIEAWv(false, -1054878012, false, 554702.8372691785);
    this->RqoVlOvfCs(-23427.085327672692, -367826.13279761164, true);
    this->REHDBOo(string("arqhxkOBrBHfcYHBnzsmrlzOigvCHfvLmjkzFtxNEPVqYfNIYUQRRdPaybmgXjEgTiafMfscOXydwpCXeUXyPlYSRgTdIKElWURckFZNlGThMPdMIfDaTtXFkgQXHakuoIUGOprdbbnOFKNtbbQOQiFgTybZZpfVwh"), string("cKYW"), true);
    this->JqHKxV(string("tlgc"), string("yAgoDRRXpDyqVFoeZzkLDESOQHTfyfpKCVTcKibktOnVpxIPXFWyKALlMLMYLCseZdnhfohiwBObeZ"), string("sFzhnjEiGmjIXjXCrcTRpiXdALCwXOqsJRnIHMzkheiPQLZminpMYBAYhrMLBpnsPGitNGldZePimhHsadADWhqbmRpzqMXADjjXFzgHbMuUDHBeEqlTcvnxeSqXixhXhMGpcmqQQNCEDHILrthedIwBtncGFDnUhYkkWhBSpoyVUQMmZLDYfdnawekywIidGpmoCKRCLnoKdLMrJtYMtSGbP"), true);
    this->ddqYLoRt();
    this->TkKBZbesdOU();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rJDldFKLIjVWsXQg
{
public:
    int YxyoIXQEHOJXXR;
    string QhotBqV;

    rJDldFKLIjVWsXQg();
    void eOYqJotdURogImpB(int HdXMfEtkCszK);
    bool CeWgqw(string QCiLaeDSUqmpGK, double cxhIlJNSdLXlhLB, double jjjMLUQb);
    bool DDtzYtbAtUDux(bool wTarigGExkfDRj, bool IXjCyePFAHFUv, bool zHPJupEkiiFEPN, double oDjhnDbPvhyDk);
protected:
    int qNLkeuyvk;
    string RRdxPTo;
    int dSFAWuABZAu;

    bool WKIbMWfSQc(double xXixnKNAfxA, int nvCYWqruj, bool mHIdcQdrKfOnrjj, string rkLhGuD, double mTjCiyLNbU);
    int OenKdhf(bool aoombqRSVrZcTLA, int vfiFCfkfINz, string UYSQx);
    void KcHdV(int FeVZHLkRZm, int ULnzuAOGLBWVFgl, string TkboGzCZJiV, double RhOoRCJbEhTPJ);
    int KoHHm();
    bool YCKzXqJMaHsva(int lLUHxnXpwbHuooyS, double IdzSBkPdjH, double LzgIJZsSyeT, int WuamVwZrV, string sOpgnlBetKcFe);
    int fqyNCsEJHvU(bool MQrXgHZksb, int ayvadhCbJTQ);
    void FoVvPnql(string xvqCXymGASEVkK);
private:
    string BqBfjHPZYyvy;
    int akkDsbkZhUUUI;
    int mWuCxowwL;

    double MCikKzw(string ggYUBScEeIu, int AbveXqWany, bool AVqIX, bool ouAXpVBxeyVjYBY);
};

void rJDldFKLIjVWsXQg::eOYqJotdURogImpB(int HdXMfEtkCszK)
{
    double TrwrDbozsby = -1027457.3928685224;
    double gUObI = -292476.99000652344;
    int PwqXeR = -1126129574;

    if (gUObI >= -292476.99000652344) {
        for (int ixgrY = 809990402; ixgrY > 0; ixgrY--) {
            HdXMfEtkCszK = HdXMfEtkCszK;
            HdXMfEtkCszK = HdXMfEtkCszK;
            gUObI = gUObI;
            HdXMfEtkCszK += PwqXeR;
            gUObI += gUObI;
            PwqXeR = PwqXeR;
            PwqXeR = PwqXeR;
        }
    }

    if (HdXMfEtkCszK >= -966739061) {
        for (int BoJgkJOiCxssG = 278024891; BoJgkJOiCxssG > 0; BoJgkJOiCxssG--) {
            PwqXeR += PwqXeR;
            TrwrDbozsby += TrwrDbozsby;
            gUObI /= gUObI;
        }
    }

    if (PwqXeR >= -1126129574) {
        for (int pziJXAwDab = 1530118584; pziJXAwDab > 0; pziJXAwDab--) {
            HdXMfEtkCszK -= PwqXeR;
            PwqXeR += PwqXeR;
            TrwrDbozsby += TrwrDbozsby;
            HdXMfEtkCszK -= PwqXeR;
        }
    }

    if (HdXMfEtkCszK > -966739061) {
        for (int HICGWpD = 86954975; HICGWpD > 0; HICGWpD--) {
            TrwrDbozsby -= gUObI;
            TrwrDbozsby += gUObI;
            gUObI -= gUObI;
        }
    }
}

bool rJDldFKLIjVWsXQg::CeWgqw(string QCiLaeDSUqmpGK, double cxhIlJNSdLXlhLB, double jjjMLUQb)
{
    int nRhNSqSVsZWTSm = -222531398;
    int PCSvgcxuIrDUBbWb = -1307847309;
    bool kUXOGXnc = false;
    double aEVcCSDmFxx = -1011557.5515422566;
    bool SdtxOeioOpMo = true;
    double MzunNIZLQeajCUXG = 505425.13271004724;
    bool bfhehB = true;
    int luNLAHgnqwmpEf = -1471672485;

    if (PCSvgcxuIrDUBbWb != -1471672485) {
        for (int qtETXNDJpo = 630760058; qtETXNDJpo > 0; qtETXNDJpo--) {
            jjjMLUQb -= MzunNIZLQeajCUXG;
        }
    }

    if (aEVcCSDmFxx == -1011557.5515422566) {
        for (int AoDsPFd = 889700315; AoDsPFd > 0; AoDsPFd--) {
            bfhehB = ! SdtxOeioOpMo;
            jjjMLUQb -= aEVcCSDmFxx;
            SdtxOeioOpMo = kUXOGXnc;
        }
    }

    for (int REwcJroBfUHsKZrq = 1042616303; REwcJroBfUHsKZrq > 0; REwcJroBfUHsKZrq--) {
        continue;
    }

    return bfhehB;
}

bool rJDldFKLIjVWsXQg::DDtzYtbAtUDux(bool wTarigGExkfDRj, bool IXjCyePFAHFUv, bool zHPJupEkiiFEPN, double oDjhnDbPvhyDk)
{
    double ncuQrtbjw = 310644.98906813207;

    for (int MzdZFfxOkvpYrBx = 366308038; MzdZFfxOkvpYrBx > 0; MzdZFfxOkvpYrBx--) {
        ncuQrtbjw += oDjhnDbPvhyDk;
    }

    for (int JXaDolORQlml = 1342746553; JXaDolORQlml > 0; JXaDolORQlml--) {
        IXjCyePFAHFUv = ! zHPJupEkiiFEPN;
    }

    for (int CKgmqXCm = 1372747225; CKgmqXCm > 0; CKgmqXCm--) {
        wTarigGExkfDRj = ! zHPJupEkiiFEPN;
        zHPJupEkiiFEPN = ! IXjCyePFAHFUv;
        ncuQrtbjw -= oDjhnDbPvhyDk;
    }

    if (zHPJupEkiiFEPN != false) {
        for (int gmNVTyVAhGvc = 1214812498; gmNVTyVAhGvc > 0; gmNVTyVAhGvc--) {
            zHPJupEkiiFEPN = ! zHPJupEkiiFEPN;
            IXjCyePFAHFUv = zHPJupEkiiFEPN;
        }
    }

    for (int FlsKkCBxSRIHC = 738560326; FlsKkCBxSRIHC > 0; FlsKkCBxSRIHC--) {
        zHPJupEkiiFEPN = ! wTarigGExkfDRj;
        IXjCyePFAHFUv = zHPJupEkiiFEPN;
    }

    if (IXjCyePFAHFUv != false) {
        for (int GFRJLoexpy = 2026099592; GFRJLoexpy > 0; GFRJLoexpy--) {
            oDjhnDbPvhyDk = oDjhnDbPvhyDk;
        }
    }

    for (int bvHYrL = 555803837; bvHYrL > 0; bvHYrL--) {
        zHPJupEkiiFEPN = ! wTarigGExkfDRj;
        wTarigGExkfDRj = ! IXjCyePFAHFUv;
    }

    return zHPJupEkiiFEPN;
}

bool rJDldFKLIjVWsXQg::WKIbMWfSQc(double xXixnKNAfxA, int nvCYWqruj, bool mHIdcQdrKfOnrjj, string rkLhGuD, double mTjCiyLNbU)
{
    bool ijnuZx = true;

    if (mTjCiyLNbU >= -541616.9805562424) {
        for (int lVvOQowtx = 511659117; lVvOQowtx > 0; lVvOQowtx--) {
            rkLhGuD = rkLhGuD;
            ijnuZx = mHIdcQdrKfOnrjj;
        }
    }

    return ijnuZx;
}

int rJDldFKLIjVWsXQg::OenKdhf(bool aoombqRSVrZcTLA, int vfiFCfkfINz, string UYSQx)
{
    double BcLqRVqeoJnuS = -134588.47304599374;
    bool RckvWNM = true;
    string fRRTsRUARMNXrtow = string("EyGqwerYejurvqtHYhgrmrbzdxHNRvhwNyVHEhXUDqCkmxRdcBmdoJdEFkHgCMCwoDuzIIhwVvxndqDeEFHcfjjVFqVrWCXLYwUBeYKktJPVbWaSaz");
    string RoXhz = string("CLtUruzepvUmCnbsnmTzOaKnZqupHkTdNFLARcgNMNqsLfTpnxlapWWyrpmdpVeHfxoFJrKcCOQTBVckmkHtvsPHkEfkrrVCyFeITCQpPiOfmJkAktWqlpLhinjlEEAIfmglyiUCmsWnKUkVqmZncHOfQcknVfJUDwbGyaOZCQzwmSCmiJGvWekcldjTanEHPhhMOFXApPqjyOLiDEsLYVYFfDHLASltScswnayhZowZIvywwKpE");
    string CYwmVrgX = string("IVsXMnBHvVNlLVBvYIliGOBfwxwWSXwLxvFKcCRmOuTGDFCGtzbJsKtqUTiLJLMvqeMIYjHyxltXoVxFmb");
    bool qWDBjzjQz = true;
    bool xfNbBOONg = true;
    int hekgn = -176262468;
    bool rxosyX = true;

    return hekgn;
}

void rJDldFKLIjVWsXQg::KcHdV(int FeVZHLkRZm, int ULnzuAOGLBWVFgl, string TkboGzCZJiV, double RhOoRCJbEhTPJ)
{
    string WQFIm = string("KRHaTPaNZixZkLhfQCgRogoxBMtqUIcSSpygiybSDRCkjaIDvYrt");
    double ygCjMUAqQTe = -788629.7394125629;
    int UIDrVOYlXB = -723879169;
    bool RaPklvqtkRveCj = true;
    double LLmIBWNAqT = -638435.0845722526;
    double YFhzZDK = -240755.10249906036;
    int fBdYyq = -1721280805;

    for (int qrhuHZTPvsDsux = 1519718934; qrhuHZTPvsDsux > 0; qrhuHZTPvsDsux--) {
        ygCjMUAqQTe -= YFhzZDK;
    }

    for (int mmbnZCXEAPzQXCvO = 602729476; mmbnZCXEAPzQXCvO > 0; mmbnZCXEAPzQXCvO--) {
        ygCjMUAqQTe = RhOoRCJbEhTPJ;
        LLmIBWNAqT *= RhOoRCJbEhTPJ;
        UIDrVOYlXB += FeVZHLkRZm;
        ygCjMUAqQTe = ygCjMUAqQTe;
    }
}

int rJDldFKLIjVWsXQg::KoHHm()
{
    int aoWBRRrqV = 1028125315;

    if (aoWBRRrqV != 1028125315) {
        for (int UiSjXcaHBnTLHEWh = 1788496977; UiSjXcaHBnTLHEWh > 0; UiSjXcaHBnTLHEWh--) {
            aoWBRRrqV -= aoWBRRrqV;
            aoWBRRrqV += aoWBRRrqV;
            aoWBRRrqV += aoWBRRrqV;
            aoWBRRrqV *= aoWBRRrqV;
            aoWBRRrqV /= aoWBRRrqV;
            aoWBRRrqV -= aoWBRRrqV;
            aoWBRRrqV -= aoWBRRrqV;
            aoWBRRrqV -= aoWBRRrqV;
        }
    }

    if (aoWBRRrqV > 1028125315) {
        for (int smoohSzOx = 454600531; smoohSzOx > 0; smoohSzOx--) {
            aoWBRRrqV -= aoWBRRrqV;
            aoWBRRrqV /= aoWBRRrqV;
            aoWBRRrqV = aoWBRRrqV;
            aoWBRRrqV *= aoWBRRrqV;
            aoWBRRrqV = aoWBRRrqV;
            aoWBRRrqV /= aoWBRRrqV;
        }
    }

    if (aoWBRRrqV <= 1028125315) {
        for (int gtIEJdBD = 370636154; gtIEJdBD > 0; gtIEJdBD--) {
            aoWBRRrqV = aoWBRRrqV;
            aoWBRRrqV -= aoWBRRrqV;
            aoWBRRrqV -= aoWBRRrqV;
            aoWBRRrqV = aoWBRRrqV;
        }
    }

    if (aoWBRRrqV <= 1028125315) {
        for (int qVwKMN = 904884284; qVwKMN > 0; qVwKMN--) {
            aoWBRRrqV *= aoWBRRrqV;
        }
    }

    return aoWBRRrqV;
}

bool rJDldFKLIjVWsXQg::YCKzXqJMaHsva(int lLUHxnXpwbHuooyS, double IdzSBkPdjH, double LzgIJZsSyeT, int WuamVwZrV, string sOpgnlBetKcFe)
{
    string QFvgWJHsdl = string("feQfOiNyOxUUsdaDUQEuzzhrlyEAzbDLdPmpDBTxqaPiBBCWbpfgelQvRImrtIfoGoCXaeVtbWILXGrOkklMHSOKdKAULuISLftQeCIaypeKucepFYLSkpXFpGTdnYnlfrcwrsaguRwAqUecaPeqKxDherTdGbVpRmvnrJWhNPwaXexU");
    string tdbtebkwBDpMaqk = string("OGFLyEYdIlSrbQhIypBgRtRVxLVcqlULZzaxKpoQrhZWEwaPztbfoNFeikHcgQQTvDzPbiWiuVBRnrkgXJWMLTmAKbJireZmUdjHnYtibiXEjkQvlUvQvkhkUZvYLdcgCTtuQJdRTsdMKeSXBeGZKbEFuRVzWJHrN");
    int qQdarPpOGKAc = -468956751;
    int xJTubGPygzoFLDS = -216567840;
    bool HHEuAtuh = false;
    int iuZNlABJTsLLbHLN = 1152084588;
    int VtoDb = -118454531;

    for (int GBfTlufEiYTRt = 1812992909; GBfTlufEiYTRt > 0; GBfTlufEiYTRt--) {
        xJTubGPygzoFLDS += xJTubGPygzoFLDS;
        xJTubGPygzoFLDS /= WuamVwZrV;
    }

    if (WuamVwZrV != -468956751) {
        for (int clSJcN = 62543028; clSJcN > 0; clSJcN--) {
            lLUHxnXpwbHuooyS /= xJTubGPygzoFLDS;
            QFvgWJHsdl += QFvgWJHsdl;
            lLUHxnXpwbHuooyS -= VtoDb;
            tdbtebkwBDpMaqk = QFvgWJHsdl;
        }
    }

    if (VtoDb == -216567840) {
        for (int GZrfdoYcmahCFeI = 39046456; GZrfdoYcmahCFeI > 0; GZrfdoYcmahCFeI--) {
            VtoDb += WuamVwZrV;
            qQdarPpOGKAc -= WuamVwZrV;
            iuZNlABJTsLLbHLN = qQdarPpOGKAc;
            iuZNlABJTsLLbHLN -= VtoDb;
            tdbtebkwBDpMaqk += sOpgnlBetKcFe;
            VtoDb /= iuZNlABJTsLLbHLN;
        }
    }

    for (int OzVNZsWWplRkBY = 1503514091; OzVNZsWWplRkBY > 0; OzVNZsWWplRkBY--) {
        WuamVwZrV -= lLUHxnXpwbHuooyS;
        lLUHxnXpwbHuooyS -= lLUHxnXpwbHuooyS;
    }

    for (int owIBPwkdbWMp = 394544106; owIBPwkdbWMp > 0; owIBPwkdbWMp--) {
        qQdarPpOGKAc += lLUHxnXpwbHuooyS;
    }

    for (int LpfvJgDNh = 188111059; LpfvJgDNh > 0; LpfvJgDNh--) {
        VtoDb *= xJTubGPygzoFLDS;
    }

    for (int OCDeBRIUd = 283481513; OCDeBRIUd > 0; OCDeBRIUd--) {
        iuZNlABJTsLLbHLN = lLUHxnXpwbHuooyS;
    }

    return HHEuAtuh;
}

int rJDldFKLIjVWsXQg::fqyNCsEJHvU(bool MQrXgHZksb, int ayvadhCbJTQ)
{
    double ZGAmkK = 78490.13943559567;
    int fEzQRokMHloy = 977905025;
    string cHTVxAyEW = string("FVdCWOyFSktcKeQOqtemEqafvvecwbnEvIyoEilaOcWgdfDjeWwuLNoDSQYonMTTAgFZOoQArQwzmqXihKrRVpayibOhPHHZZggtdlJfSJcROrvAKqoNXJEfRRMhXOlgdsJLpqWuvOzUfqFrcBeIQrKDZedbitgMGZbcZpQYhRXvKcDnGgzgNhNwvjRPHAKMiqdOzFVftPXEqHyokECYFWCEpNMaMLGyBOmORuywmglcbuywCTnumlMfybboL");
    double qFCgZLVKR = 620100.6991086121;
    string stpTXVBtOqzUzrt = string("WbERpVfpHTgCkuYMwosEMMnwYcdiilUxdCxNVGYyIMfkhDDQYSTzodhFTSBvUjRaPsulXLoVBLTNWgCqWGRtDvXSOFayvUOukecaNuVfcuCFMLxkekBQEAOjrRASUXGeGGSzCdYAruifzXvOCNXIJlELJEbShIzh");
    string JApkSuUQOu = string("jPfwgGSHFreDAZYAIEjtJzxEwAqLJcETTxOsemQPYzvTxI");
    bool WIiflaCu = true;
    int tKBRBaVYLJdMtewK = 996201141;
    string KCnOXbQnPeYoDq = string("vjSeLltptcNEmigziAGIEMcTEb");

    if (tKBRBaVYLJdMtewK >= 996201141) {
        for (int cWupUNvoUqm = 2033037871; cWupUNvoUqm > 0; cWupUNvoUqm--) {
            fEzQRokMHloy -= tKBRBaVYLJdMtewK;
            KCnOXbQnPeYoDq += JApkSuUQOu;
            MQrXgHZksb = ! WIiflaCu;
        }
    }

    for (int pGVwcLE = 1567101708; pGVwcLE > 0; pGVwcLE--) {
        WIiflaCu = ! WIiflaCu;
        fEzQRokMHloy -= tKBRBaVYLJdMtewK;
        tKBRBaVYLJdMtewK *= fEzQRokMHloy;
    }

    return tKBRBaVYLJdMtewK;
}

void rJDldFKLIjVWsXQg::FoVvPnql(string xvqCXymGASEVkK)
{
    string KELTTKXLGYtcO = string("BeGUIDTsxnnCiDYfnqkeiIqpSxHqQgXeRRzTAGcEmVbsHOhulmABJqpVDaEAmGrVreDoZkouYUDTpGpzwcrDTsSToDgrskuRKxEDaIWpmJXaOMQTnCpWGYaYGIjMiLDbNMnLCPFXyq");

    if (xvqCXymGASEVkK <= string("BeGUIDTsxnnCiDYfnqkeiIqpSxHqQgXeRRzTAGcEmVbsHOhulmABJqpVDaEAmGrVreDoZkouYUDTpGpzwcrDTsSToDgrskuRKxEDaIWpmJXaOMQTnCpWGYaYGIjMiLDbNMnLCPFXyq")) {
        for (int jXuTXUHVpPKPI = 1176085255; jXuTXUHVpPKPI > 0; jXuTXUHVpPKPI--) {
            KELTTKXLGYtcO += xvqCXymGASEVkK;
            KELTTKXLGYtcO += xvqCXymGASEVkK;
        }
    }
}

double rJDldFKLIjVWsXQg::MCikKzw(string ggYUBScEeIu, int AbveXqWany, bool AVqIX, bool ouAXpVBxeyVjYBY)
{
    bool GlGLNOOPTjFSoD = true;
    bool ShIoWnaUDDaN = false;
    double QssGcOEFuK = -459604.89458501904;

    return QssGcOEFuK;
}

rJDldFKLIjVWsXQg::rJDldFKLIjVWsXQg()
{
    this->eOYqJotdURogImpB(-966739061);
    this->CeWgqw(string("JmCoUeFAUM"), -28488.463364561703, 31173.221507407587);
    this->DDtzYtbAtUDux(false, false, false, 403193.15635931696);
    this->WKIbMWfSQc(-541616.9805562424, 1703059810, true, string("FYtPgqcPrXkzalBSUnqlxRykJjJZNBpQZYYaSlnElBZTNumouvwubvBWcFbjeFEkiNilLdKNhqIUiPOZOTVNjAuQTkNNTeqQEUCuPAHohTgZLKvsZHJCMfSBLDpwUbnk"), -504779.02177187527);
    this->OenKdhf(false, -940966970, string("YUfvtJtwBzIOosRQsWHGcgXorQRoutuEOyHyItDjDnqSKTfsSByYPRxtfcEcVYBprucBIFkvmgvZlGrooRqYBcKMAbCYOtKwORbNVwVOWEnOVklvaRnbXnzpqDnuPEpvYrgyJVBbfRtzwm"));
    this->KcHdV(1977504060, -1774948973, string("iQkftQxmIArsFUOlszcBcLSgJpCvvnoxrfHLngJcvlsPbIqoozWmyfkkNMGDXtLfNLwTqCkrHCGrFrxxYpKqgNRvTAdlZyHcXuUGZDKJrEkECBSuqMCIGEmBgjlBMIyMjvLQPOGlwYpofaMbGjPSLcdLpmNNMKLyUWwWOoFesDiFVCStWyDsqRcKYlZFskZDIQbbihdMLZnWQ"), 742464.6041568303);
    this->KoHHm();
    this->YCKzXqJMaHsva(1167353638, 911305.8919929798, -686700.9106930873, 1413109965, string("oBKfouZjvWIMxUqekcEoilgUkkcLNQjhCVEoUFVPeGUcoNvCjZhYrYlNHKSmFatAnCNBfOXmrKvBTAczrAxgpmQACmFOwMpjiINzkWuGvctYwvIfoCnMHpeCgvjLgeNEaszrZUJgRwWGubZxAfOLXFMyEYmjqFrJTBeTJaSjuRmBpFnTQxshGIxJqbolitPHWuiGieFGXVMtulWuR"));
    this->fqyNCsEJHvU(false, -817111335);
    this->FoVvPnql(string("tvUSMhhsObHlPEHEAeTvAmuetUfHKEQnJpgkIfXGCDoHiYLLTg"));
    this->MCikKzw(string("nZrBojCJKQUToSzAltftVZqBxDjfwdRbXoFyNYvhxfYTQdFxjvwRuKQsDfQNqrSUbOfOyvgUomNRaHrNWntROrVvAWHtrAqRcYaVtUsZcviOxRjUEFDlSCZWBLsjgUTYKinvNFescZUZHNgVAKLfFUSbKPoMPZnYNHAZWGvOBg"), 1244907214, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xLOgpNuTD
{
public:
    double FjzYmFgHsOw;
    bool VBxGfvMDmn;
    int PBUCTwUdksfckC;
    int HPhoNQ;
    int dWaeHvTio;

    xLOgpNuTD();
    double GAxbWQf();
    void GjAsIfGHfdbP(int UIOfa, int VmpFisbDZDeg);
protected:
    int TmwxTda;

    string UgFdwSQjczTOoSOb(bool nRlFgvSPxt, double OalkfWuZyYiQcNI, double XVJSwcNJuv, int CTvrprbGewSfAh, int RqEuanV);
    string MoyEuVpbJPdGzWKJ();
private:
    double yqCFOUZsTETNPh;
    int kWkKRK;
    string ISKdsZEszaRAil;
    string XsQsdN;
    double ITaMgVuu;
    double eyIFzSqAjAyeGnb;

    int xUtceSJ(string kyvIsAzNsKlFmT, double RgpAEVeFLZAuaDDt, int RibVvR, int wxBcuFNXuywXtKq);
    bool xJizUAgHA();
    void ZiyZzhpHw(string mlLDzL, double XkHiVu);
    void RsJVqaoVg(string MPEsyhZkSeY, bool JZSFPIsNgWCaEgK, int LRghtS, double agkSpNQWOBikVOZ, int IMwPOqT);
    int rINUWONbg(int eexmWNlzhAA);
};

double xLOgpNuTD::GAxbWQf()
{
    double QNOvpAGyie = -817036.2266905064;
    double lCHGsXd = 259331.3783888211;
    bool kTVXEavW = false;
    bool NvpIjYNHgIcM = true;
    string MtBiqJMjtjuqkUP = string("BYbrvekLqzW");

    for (int mldJBPVLwJT = 320572885; mldJBPVLwJT > 0; mldJBPVLwJT--) {
        MtBiqJMjtjuqkUP += MtBiqJMjtjuqkUP;
        MtBiqJMjtjuqkUP += MtBiqJMjtjuqkUP;
        MtBiqJMjtjuqkUP = MtBiqJMjtjuqkUP;
    }

    for (int AVTiQRzmg = 1028279375; AVTiQRzmg > 0; AVTiQRzmg--) {
        QNOvpAGyie += QNOvpAGyie;
        QNOvpAGyie /= lCHGsXd;
        kTVXEavW = NvpIjYNHgIcM;
    }

    return lCHGsXd;
}

void xLOgpNuTD::GjAsIfGHfdbP(int UIOfa, int VmpFisbDZDeg)
{
    int HcDeYvatHtORavA = 1606183724;
    int yQZUiJcsGD = -1557075779;
    string ssPEXpDOUhBnJMN = string("LIJUxxhilbBtgkfnjpeaywpOXRpZOOUehOJwLqPfXNtYpJaEtvFaMgLxvZHccgQkezfQqJKsWFZQRvWhohKePBhvjStwQSFqYpTfYlmagkPLjgALlrmsSuLnCjZlWDDsyvTxkUQCzMCCQurfwdanBIlsZEgeCrIyqmmPENMHzr");
    int iadnOvbiDIjHE = -76075454;
    string THXGAFphuKYeQY = string("ntRvxmLpmoNtKfXGpVZwTGKFOxOiFtIvCW");

    if (UIOfa == -1031847695) {
        for (int lzVthaUFHkgKHuX = 994976674; lzVthaUFHkgKHuX > 0; lzVthaUFHkgKHuX--) {
            yQZUiJcsGD += iadnOvbiDIjHE;
            ssPEXpDOUhBnJMN += ssPEXpDOUhBnJMN;
            iadnOvbiDIjHE += yQZUiJcsGD;
            VmpFisbDZDeg = iadnOvbiDIjHE;
        }
    }
}

string xLOgpNuTD::UgFdwSQjczTOoSOb(bool nRlFgvSPxt, double OalkfWuZyYiQcNI, double XVJSwcNJuv, int CTvrprbGewSfAh, int RqEuanV)
{
    double awXYLBPZQlyjujyS = 820963.1472534391;
    double elOwJrh = 343635.86819210515;
    int pqJWwIBGkFdmg = -670529061;
    double LspEljLVuYYO = 54418.58071406113;
    int hWjWkhOoDIlxanf = -459205026;
    double iXptct = -954979.529947814;
    bool lnmJiXVA = true;

    for (int UezkdQqHkUQalXf = 226203430; UezkdQqHkUQalXf > 0; UezkdQqHkUQalXf--) {
        continue;
    }

    for (int siBdHk = 608674394; siBdHk > 0; siBdHk--) {
        iXptct /= LspEljLVuYYO;
        RqEuanV -= RqEuanV;
        awXYLBPZQlyjujyS -= OalkfWuZyYiQcNI;
    }

    if (LspEljLVuYYO > -954979.529947814) {
        for (int QnUdfwdQSYgfa = 1987543770; QnUdfwdQSYgfa > 0; QnUdfwdQSYgfa--) {
            OalkfWuZyYiQcNI /= XVJSwcNJuv;
            elOwJrh /= iXptct;
            hWjWkhOoDIlxanf *= pqJWwIBGkFdmg;
        }
    }

    if (CTvrprbGewSfAh > -459205026) {
        for (int OnwwdhfSvqM = 258154853; OnwwdhfSvqM > 0; OnwwdhfSvqM--) {
            RqEuanV -= hWjWkhOoDIlxanf;
        }
    }

    return string("RorPdplZzuLauRBOEDIHuruNhvxqkjfpxbWpEwwfFgTOLHKpLAMewhDScRTPIDCtrXRtLCufUEghbxcfGtmzMQfGHiglYGlsOLRTTUFCnZpSSxxFi");
}

string xLOgpNuTD::MoyEuVpbJPdGzWKJ()
{
    int KYAltcHMbdHyJRT = 1375082985;
    double UtUiH = -182192.42502534462;

    for (int aRjtDNUjnySRjcV = 1822718596; aRjtDNUjnySRjcV > 0; aRjtDNUjnySRjcV--) {
        continue;
    }

    if (KYAltcHMbdHyJRT == 1375082985) {
        for (int pcdbuUdHMW = 1492222172; pcdbuUdHMW > 0; pcdbuUdHMW--) {
            KYAltcHMbdHyJRT = KYAltcHMbdHyJRT;
            UtUiH -= UtUiH;
            KYAltcHMbdHyJRT += KYAltcHMbdHyJRT;
            UtUiH = UtUiH;
        }
    }

    for (int WcoMgipboW = 1784638588; WcoMgipboW > 0; WcoMgipboW--) {
        UtUiH -= UtUiH;
        UtUiH *= UtUiH;
        KYAltcHMbdHyJRT *= KYAltcHMbdHyJRT;
    }

    if (UtUiH != -182192.42502534462) {
        for (int SgmCfrQD = 1236520134; SgmCfrQD > 0; SgmCfrQD--) {
            UtUiH -= UtUiH;
            KYAltcHMbdHyJRT += KYAltcHMbdHyJRT;
            UtUiH *= UtUiH;
            KYAltcHMbdHyJRT *= KYAltcHMbdHyJRT;
            UtUiH += UtUiH;
            KYAltcHMbdHyJRT = KYAltcHMbdHyJRT;
        }
    }

    for (int nVxBiuD = 1877170886; nVxBiuD > 0; nVxBiuD--) {
        KYAltcHMbdHyJRT += KYAltcHMbdHyJRT;
    }

    if (KYAltcHMbdHyJRT <= 1375082985) {
        for (int dvOQjEnldFdj = 455423166; dvOQjEnldFdj > 0; dvOQjEnldFdj--) {
            UtUiH /= UtUiH;
            UtUiH *= UtUiH;
            UtUiH /= UtUiH;
            UtUiH -= UtUiH;
        }
    }

    if (UtUiH != -182192.42502534462) {
        for (int FxHTTtSPYRLOg = 606261489; FxHTTtSPYRLOg > 0; FxHTTtSPYRLOg--) {
            continue;
        }
    }

    return string("xWuFzvnIAQqvJcKebplnKPjgkYbOszbolxORXYPEfKqiOjTnToJgAVHDPRgOvviKWTDEOIKrayittifpDKbVnlvlhaqtzSrMevqkuDCssnSSnhmKnHMgJmOEOVRvCUHErjRifSyXNKMbdJpoAMHmCksQEVFtEOQligWsijokhjHsSEmXsUvhlOHVywDWPuIFNyZjsbERCrNiRhVGWOaXMGJDWqiCgmUKvKHKcT");
}

int xLOgpNuTD::xUtceSJ(string kyvIsAzNsKlFmT, double RgpAEVeFLZAuaDDt, int RibVvR, int wxBcuFNXuywXtKq)
{
    bool SLxgeOCEGj = false;
    string IBBnOlY = string("gdQGnDXsAmyhlkkJMkQpbAMAXCiFyFrYrOHcLQcPoqITqwwSaKQXpwSRtJSPbovBxkyuunTtAECNoZHVvCmfMEPJNGnehQCmLuFTTfcYTTqgJGVtZneQJMTtvnjCJKlwRlPfmOwgsxnZvepShxnQemlsietUufgXDmHHdlCkOLYeYsLQuAEezMyJvIdhDzWCASOIOuVREjyroLamjnTciEHgJmZzFXoCIDUuvNt");
    string DIelwrDDUX = string("iMIZRoSZXXAYlblAXjtgQuGEyrHNnhMExPvMwRWFDmjwoJNrNhUDbRFbtkxNFpKSWKdwerWUTSYfWpliVPUOjpahgNaORLnJheqPcyUgLkuqqJshDJdUFkpLFzffdzQQ");
    bool bJGUPOHsnvXU = true;
    double KAxJKtEdAbl = 298118.2801592798;
    string WHMWFwuujrZFwOys = string("QiEpfnZPNVPHRoFrUmVAMGLUZZdwCaoMNkRiiBZnYknLPXsAnAiXQKNvlKFHBFdvYSMasSowjZqZmCZeaeTtNttBZCSGYgQsdWdQQlYWUdJxNxhRDYqZObkRTUIZUYaDycHnLDqDENWosYFPoPdDgvNFIiGrZPucXNjYtFdGGWcuzqooFgBbcKTRuLojuAHNcxsfshRoBUByBMedtvzeZzFhaWIIHmFLgoDtjSCWZmlrwu");

    for (int fYGLjQ = 578214158; fYGLjQ > 0; fYGLjQ--) {
        DIelwrDDUX += kyvIsAzNsKlFmT;
        RgpAEVeFLZAuaDDt += RgpAEVeFLZAuaDDt;
        bJGUPOHsnvXU = ! SLxgeOCEGj;
        KAxJKtEdAbl *= KAxJKtEdAbl;
    }

    if (RibVvR == -1700979408) {
        for (int sIkFMevVx = 1416762896; sIkFMevVx > 0; sIkFMevVx--) {
            RibVvR *= wxBcuFNXuywXtKq;
            KAxJKtEdAbl *= KAxJKtEdAbl;
            wxBcuFNXuywXtKq -= RibVvR;
            DIelwrDDUX += kyvIsAzNsKlFmT;
        }
    }

    if (bJGUPOHsnvXU != true) {
        for (int tmCkLBRxSZpvQEaG = 1523738147; tmCkLBRxSZpvQEaG > 0; tmCkLBRxSZpvQEaG--) {
            WHMWFwuujrZFwOys += DIelwrDDUX;
        }
    }

    for (int znwSa = 1553112013; znwSa > 0; znwSa--) {
        bJGUPOHsnvXU = SLxgeOCEGj;
        kyvIsAzNsKlFmT += WHMWFwuujrZFwOys;
    }

    return wxBcuFNXuywXtKq;
}

bool xLOgpNuTD::xJizUAgHA()
{
    int XvcMQYYbImgjYlF = -675738613;
    string NEyhUwLO = string("xZZmgBhorEuCMmHFJnfcpRvQfgGJrJJIEwowHJpbbjqMyBvyRnTsQlDxiWhWibrqGBRnVSZHaWedWhvnFOBnzfcGMgSAyWjbuIrSUgqSdptJkzEzZyMrgycRfDYAAYERMnxRTEPxiObWdTlcJMgXSEbXCRzpNw");
    int EDhOAAVGYinvonpP = 1973235640;
    bool lafRMU = true;
    int pcaPXEOXia = -2015721721;
    double EnesxYYfpKEaKeE = 353520.9077256085;
    bool YpAxg = true;
    string TBxantX = string("WCrPkXTvKuIqAsEYXqKVATRoVjNgWuiCHGLsydCapfENbxMMusHuUSWiIwXlKhAPEuNUVozCBlpkyhJFGKKBiARomVPyCChwbUWKOeeptHVNdVutXYyvNrwoIBuZKjEKLxhfjdsvJAYzvrEPJIZuqFCCDRuJkYnvIfXUeQIUFoUrqHwPRROsfyLOYfdyhIFTQfrgpij");
    int SOkExUmGs = -2067784883;
    double sOSWtPWgzxfSt = -1004849.6229265444;

    for (int YkmdGzfwK = 1088977081; YkmdGzfwK > 0; YkmdGzfwK--) {
        continue;
    }

    for (int tzvSFvhqv = 1785501344; tzvSFvhqv > 0; tzvSFvhqv--) {
        NEyhUwLO = TBxantX;
    }

    return YpAxg;
}

void xLOgpNuTD::ZiyZzhpHw(string mlLDzL, double XkHiVu)
{
    double xtdKd = -1021164.8674108988;
    int ozwGCMSeHCOmi = -1994338864;
    int bVcoabR = 1965957067;
    bool oLQvDSoVkMNVcC = true;
    bool rgJjF = false;

    for (int fPjWbhzGCfJ = 1905842539; fPjWbhzGCfJ > 0; fPjWbhzGCfJ--) {
        XkHiVu /= xtdKd;
        XkHiVu *= XkHiVu;
        XkHiVu *= XkHiVu;
    }

    for (int vYLxEaEhjWSenWy = 1865599465; vYLxEaEhjWSenWy > 0; vYLxEaEhjWSenWy--) {
        oLQvDSoVkMNVcC = oLQvDSoVkMNVcC;
        XkHiVu -= XkHiVu;
    }

    for (int qOSmk = 906517260; qOSmk > 0; qOSmk--) {
        continue;
    }
}

void xLOgpNuTD::RsJVqaoVg(string MPEsyhZkSeY, bool JZSFPIsNgWCaEgK, int LRghtS, double agkSpNQWOBikVOZ, int IMwPOqT)
{
    double JEcLlhEqzKcrqfE = -612558.3783474686;
    int nIYXLDO = 327361933;
    double DIkSgJGsS = -803557.8681323486;
    double liylJOHg = -304118.9552128644;
    double PJBtCowucI = 644965.8353924518;
    int jUpIVDnEWu = 1543391312;

    for (int jgKabVoPipub = 621345534; jgKabVoPipub > 0; jgKabVoPipub--) {
        nIYXLDO -= IMwPOqT;
        PJBtCowucI -= PJBtCowucI;
        agkSpNQWOBikVOZ = DIkSgJGsS;
        liylJOHg -= DIkSgJGsS;
    }

    if (PJBtCowucI != -803557.8681323486) {
        for (int INfBeirjksR = 553186640; INfBeirjksR > 0; INfBeirjksR--) {
            agkSpNQWOBikVOZ += liylJOHg;
            DIkSgJGsS -= JEcLlhEqzKcrqfE;
            agkSpNQWOBikVOZ += agkSpNQWOBikVOZ;
            PJBtCowucI *= DIkSgJGsS;
        }
    }

    for (int tMyJnuOViZFbY = 1065275582; tMyJnuOViZFbY > 0; tMyJnuOViZFbY--) {
        continue;
    }

    for (int fzLhuc = 1337302026; fzLhuc > 0; fzLhuc--) {
        continue;
    }

    if (PJBtCowucI > 644965.8353924518) {
        for (int iSVlJ = 585435452; iSVlJ > 0; iSVlJ--) {
            nIYXLDO *= LRghtS;
        }
    }

    for (int lflxKs = 1245116863; lflxKs > 0; lflxKs--) {
        agkSpNQWOBikVOZ -= agkSpNQWOBikVOZ;
        jUpIVDnEWu -= LRghtS;
        IMwPOqT *= jUpIVDnEWu;
        jUpIVDnEWu *= nIYXLDO;
    }

    for (int XokepB = 407187163; XokepB > 0; XokepB--) {
        liylJOHg -= PJBtCowucI;
    }
}

int xLOgpNuTD::rINUWONbg(int eexmWNlzhAA)
{
    bool SirtNWeStF = false;

    if (SirtNWeStF == false) {
        for (int eZPLnafwSSO = 1074690218; eZPLnafwSSO > 0; eZPLnafwSSO--) {
            SirtNWeStF = SirtNWeStF;
            eexmWNlzhAA /= eexmWNlzhAA;
            SirtNWeStF = SirtNWeStF;
            eexmWNlzhAA /= eexmWNlzhAA;
            SirtNWeStF = ! SirtNWeStF;
        }
    }

    for (int DibFGMtODwlErh = 322774041; DibFGMtODwlErh > 0; DibFGMtODwlErh--) {
        SirtNWeStF = SirtNWeStF;
        eexmWNlzhAA = eexmWNlzhAA;
    }

    if (eexmWNlzhAA > -1842157581) {
        for (int pBApLisQpAqjppQd = 1097911592; pBApLisQpAqjppQd > 0; pBApLisQpAqjppQd--) {
            continue;
        }
    }

    if (SirtNWeStF != false) {
        for (int RujhLAkaAttOx = 1546387471; RujhLAkaAttOx > 0; RujhLAkaAttOx--) {
            eexmWNlzhAA *= eexmWNlzhAA;
            SirtNWeStF = ! SirtNWeStF;
            eexmWNlzhAA = eexmWNlzhAA;
            eexmWNlzhAA *= eexmWNlzhAA;
        }
    }

    for (int ObaiAQmL = 1060050473; ObaiAQmL > 0; ObaiAQmL--) {
        SirtNWeStF = SirtNWeStF;
        SirtNWeStF = ! SirtNWeStF;
    }

    return eexmWNlzhAA;
}

xLOgpNuTD::xLOgpNuTD()
{
    this->GAxbWQf();
    this->GjAsIfGHfdbP(891501068, -1031847695);
    this->UgFdwSQjczTOoSOb(true, -590821.4514143533, -725409.1736333844, -140564011, 607697879);
    this->MoyEuVpbJPdGzWKJ();
    this->xUtceSJ(string("AtgwSYMGTYLbkkCRczuDmXsAbLMFSRrRliPmJABeoDmtZauIDrNukrwsvQKgdyFKkwXJUUxAYgvGkNhNAXOHpBSAUQKumotipzUwnoTWvvmyKVxAIYfaGlyHdKbFRreQbxhWjVJViwxzleYAwILpdTLSvWLAeeKPg"), 509316.87993341795, -1175467966, -1700979408);
    this->xJizUAgHA();
    this->ZiyZzhpHw(string("BCbYsJAIBUSsbnJwKfIONMFYnrjguQkpYkaMaJYRATdIMvydqpFAKxAKsjMyXUHWbRAEcFvpcYnwBzWnsGpBKxtscbwJPDcMVTuypULkLJZJtQzgsAnYSUBRnRuoRPNfxRrgBXKOJytQyenwDJwxPufvelVUbyGNpECjqOEVdlJHoGgijuxqBCPrFMgisbMDPSrrHJeyQjCcUz"), -762682.9320649811);
    this->RsJVqaoVg(string("FugKLxRSClakFXDjLdvqkoTyhtftivELIggrYJxSLljoQygOSQuYyLkEEQfTkBxfgViwjSDEsfEVHZuTDDesLfKHhhcuWZIBceXXMEGKGxCoJ"), false, 365391755, 773728.9958442124, -370599742);
    this->rINUWONbg(-1842157581);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LoDgYSzC
{
public:
    double QjQWpXGVFAEY;
    int dyahHQu;
    bool qTsFgEDwLnNQcj;
    int LTAqxeiQMuCMncRa;

    LoDgYSzC();
protected:
    string REJSznkAyVeCkb;
    double HLKta;
    int cCwTYYquurdY;

    void ILOqvWOBvmytilx(int XkfQBrdZpXRtohom);
    string GrxWIeONbfU();
    string bUMzkjd();
    bool tdxwa();
    bool ndxQzhEfVEzJdwZI(bool xhyAtzDcu, int KDKXmWdXWaKm);
    double QGSEalpilEplT();
    void XMLBtcsI(int IAApOXUuNhOj);
    bool TJWkh();
private:
    string PbskiIrZoOIeNt;
    double bKRtUJfxBnn;

    void PUtujJTsEUe(int qoPwqWbVafymfq, double YlQNEafXDEl);
};

void LoDgYSzC::ILOqvWOBvmytilx(int XkfQBrdZpXRtohom)
{
    string FZaQWvRlbvb = string("YgFf");

    if (FZaQWvRlbvb == string("YgFf")) {
        for (int HDXiud = 1252394925; HDXiud > 0; HDXiud--) {
            FZaQWvRlbvb = FZaQWvRlbvb;
        }
    }

    if (XkfQBrdZpXRtohom > 1788102941) {
        for (int VtTpiU = 458569700; VtTpiU > 0; VtTpiU--) {
            XkfQBrdZpXRtohom /= XkfQBrdZpXRtohom;
            XkfQBrdZpXRtohom *= XkfQBrdZpXRtohom;
            XkfQBrdZpXRtohom -= XkfQBrdZpXRtohom;
        }
    }

    for (int YfkvqusbifsAPhms = 1017172309; YfkvqusbifsAPhms > 0; YfkvqusbifsAPhms--) {
        continue;
    }
}

string LoDgYSzC::GrxWIeONbfU()
{
    string imOQf = string("pxWeFyARnZoiaPAKvZbtrPrNYnvQwCXAyyiTpBJygZUABBWipHZPjnzHLnLLNLtBXouNUgThbPQdaqHHowLvVGgKbRnBjOGSKkUL");
    double TjpnkIiaOO = -63195.20084914228;
    double nDdfUGXcQI = -598366.8814067366;
    string JYpAQqsUCXI = string("aIHcYDDORQoLjVesMTnGbLQVUcbWKEucITSmmuqiqNXckmPUnJcqoPTbqEFyCmDuJbAEjRyhWWXbclpgsUPirjWHqNGJNxbVhaKbqgwdxfDcfIdFBkzWOyxfhZTmxJjkPDNsXEFAltFNoWkTQdUDnmdRzC");
    string OSFJAXGw = string("iYIlhYBDSxpgzGzdTUmqRdMIJVtEdCaIAlRCtZA");

    for (int WJGvdtFzl = 1122831703; WJGvdtFzl > 0; WJGvdtFzl--) {
        nDdfUGXcQI /= TjpnkIiaOO;
        imOQf += OSFJAXGw;
        JYpAQqsUCXI = JYpAQqsUCXI;
    }

    for (int ZZuiQXAEuNV = 1548245692; ZZuiQXAEuNV > 0; ZZuiQXAEuNV--) {
        continue;
    }

    for (int fKwbtoCS = 1111826380; fKwbtoCS > 0; fKwbtoCS--) {
        OSFJAXGw = JYpAQqsUCXI;
    }

    if (imOQf < string("iYIlhYBDSxpgzGzdTUmqRdMIJVtEdCaIAlRCtZA")) {
        for (int nTMUtqlOM = 1607430313; nTMUtqlOM > 0; nTMUtqlOM--) {
            OSFJAXGw = JYpAQqsUCXI;
            OSFJAXGw = OSFJAXGw;
            JYpAQqsUCXI += OSFJAXGw;
        }
    }

    if (nDdfUGXcQI != -63195.20084914228) {
        for (int OZvfdlCbjZQt = 520472105; OZvfdlCbjZQt > 0; OZvfdlCbjZQt--) {
            TjpnkIiaOO /= TjpnkIiaOO;
            imOQf += JYpAQqsUCXI;
            OSFJAXGw += JYpAQqsUCXI;
            imOQf = OSFJAXGw;
            nDdfUGXcQI -= nDdfUGXcQI;
        }
    }

    return OSFJAXGw;
}

string LoDgYSzC::bUMzkjd()
{
    string LWHkSAg = string("KKWUeIaMsUPHirTUCdPwSbHUBJunRYcJHMYMBYhmuxDvsJZLTuCVQFJsrKIOFYolZUdcjfbsIOgplCpfsPoqvzcvuXGMJxNLAYGbZfFvMSAvysSHrMPrdKsStiLMqFHWxHBvvBLuxvxhpRwsoTyxTtyRQAyXrbjAGruToJwSgWLtgMQdRndhshWFkWEhFcjcCUgQbaJDadUxTG");
    double UbJnuDSdTGrlD = 872923.6454763092;
    string ODNdiFUFykHnw = string("sKiPIragkFQFArgCEhpSiRxcnGIzHvwdmHwsjnjaOmPBlJVRhyaurDhZgbBlnAtMlppv");
    int nuCkkdwfaUlXx = 1193440830;
    string uBSMg = string("yyXaIprZaEuQsPPwcSFMiJFNmMXoAsiGrYAtrfUCLHWKPNSILJpiCkcuzsbaRuSOCUvhKTvFjktXll");
    double FqcKzaGlZCcCEvzz = 919523.2833078466;
    double HlVkCkrmaCMvH = 233823.88606776582;
    double jejKbpSIVdVfOs = -890308.4241343823;
    bool LDvDbpbhN = false;

    return uBSMg;
}

bool LoDgYSzC::tdxwa()
{
    int UgLwRMG = -940965885;
    double NCrecczdzVByfFd = -426136.38063437067;
    string ErbQsvUMtIZEmVsi = string("naEuYCcXEfeWGRJgPxnlJcTUvYXuqsOVZHpnRsdVneZFcsJvMG");
    bool kRYFZs = false;
    int aiuTzrGCX = 1676479174;

    return kRYFZs;
}

bool LoDgYSzC::ndxQzhEfVEzJdwZI(bool xhyAtzDcu, int KDKXmWdXWaKm)
{
    bool jtLaZf = false;
    int CxCMrlbOIFEvRYFL = -940850993;
    double dLJvAhj = 564417.3732175103;
    string djkLf = string("CmfDzZEWfWwKWqIodcMSCCVtlzdpTkGxUPwWrwtefnwSjdstnSfVdIaIgDeaIQDpSZNLMBTeUvHFMGRDVVDLwuisuqjfDXjByYXpdtPINDLAXznW");
    int kdWwkIzS = -1324118513;
    double iclbDWUyWyORgi = -861440.7803489218;
    string knthxg = string("kbSoyMsIagZMgNDaUZjNCydIofrZIBasYrLOMjwkofRISYg");
    bool lLzVJAxnxbfuuz = false;

    for (int ZPTXaq = 750819985; ZPTXaq > 0; ZPTXaq--) {
        continue;
    }

    if (iclbDWUyWyORgi <= 564417.3732175103) {
        for (int BukDVptTMmPhd = 1724573163; BukDVptTMmPhd > 0; BukDVptTMmPhd--) {
            continue;
        }
    }

    for (int EsNpazVaHeNvFi = 1894066381; EsNpazVaHeNvFi > 0; EsNpazVaHeNvFi--) {
        iclbDWUyWyORgi /= iclbDWUyWyORgi;
        CxCMrlbOIFEvRYFL = KDKXmWdXWaKm;
    }

    for (int bmECw = 904018554; bmECw > 0; bmECw--) {
        continue;
    }

    return lLzVJAxnxbfuuz;
}

double LoDgYSzC::QGSEalpilEplT()
{
    bool vpmva = false;
    int zygHWfbHMRv = -1145181004;
    bool RnqaIiNezTflyYV = true;
    bool sbuCqrLKZCQIxl = true;
    string lKMtgHSKeCo = string("fvzaYivcscIcaPoQbnOpP");

    for (int IVdjkc = 1576066676; IVdjkc > 0; IVdjkc--) {
        continue;
    }

    if (sbuCqrLKZCQIxl == false) {
        for (int WYtlWWf = 1643629519; WYtlWWf > 0; WYtlWWf--) {
            sbuCqrLKZCQIxl = vpmva;
            sbuCqrLKZCQIxl = ! sbuCqrLKZCQIxl;
            vpmva = vpmva;
            sbuCqrLKZCQIxl = sbuCqrLKZCQIxl;
        }
    }

    if (lKMtgHSKeCo != string("fvzaYivcscIcaPoQbnOpP")) {
        for (int LxwVIcsWYfm = 858340691; LxwVIcsWYfm > 0; LxwVIcsWYfm--) {
            lKMtgHSKeCo = lKMtgHSKeCo;
        }
    }

    return -631944.0700805985;
}

void LoDgYSzC::XMLBtcsI(int IAApOXUuNhOj)
{
    double mOfWibbRpef = -216525.48751467466;
    bool LSzSdw = true;
    bool SndKC = true;
    string MGBGk = string("MLdUjRXhomYlypboZGHxsbzFYSLJHKLxrzfnfOPbUvvniCIJamarACrUREmapAKqJpgBDkStMKlZjmJzbOpHuHQhrHiTgxcBHGbvBykEnRIDRYEQnuEDeOFAicPyagUBasDqwtDnxQQoXxQAkceBIVqKEvDlezxoHGIy");
    string yyXSDCnSLELxk = string("VqiYkToBFmbmvxlhwNAlwabErXodVHnfcYPPQYdBFICPAkBIYhrZqWdFkrCaojcbRYQgOPFPYvccmYsDCDUjwmQilQeDHaybDQKzjtsjXkqTLEGulcsmPGGfKsPiZCYDMIExEtWPpiNdrmNRTmngdjyjVrmBbjBmqlrnmExPqtXdwFpvO");

    for (int JLliVPCNsnvnQv = 1908089054; JLliVPCNsnvnQv > 0; JLliVPCNsnvnQv--) {
        LSzSdw = SndKC;
        SndKC = ! LSzSdw;
        yyXSDCnSLELxk += yyXSDCnSLELxk;
    }

    if (SndKC != true) {
        for (int hlzAN = 1883762579; hlzAN > 0; hlzAN--) {
            MGBGk += yyXSDCnSLELxk;
        }
    }

    if (SndKC != true) {
        for (int QfNPKNMpgHAXo = 671781609; QfNPKNMpgHAXo > 0; QfNPKNMpgHAXo--) {
            continue;
        }
    }
}

bool LoDgYSzC::TJWkh()
{
    bool njzyGfymDTiFZMlK = false;
    int GPnOJGeMxsdfM = -868544990;
    double AUPwTviYB = -238846.134064948;
    double nsbBp = 14713.046992655261;
    string ETWGFafIWtb = string("RtZOlBwbhcIRbfdpYmIvgGwOyYMnidXSPuXvRiylxebaIqLlL");
    string xRkhosEDbuubOh = string("mKcUxMNlRDxeVvegMnhkEkYCMxOyyTRBjnRmOAjbtlJseTYlukVpvuBnFhATVzxEnYFKqbNBkaglBoiWfrPowpRMrAEYenoGqlLwHpnMuUloUASuHIFzPvkTuxMlLxODhyhxitzohDsRDgSQzhASsYVcxvUKJNzUHOPIEyoyJaCTkdHTJSLLc");
    string XfWiYdjsXD = string("sKEpkoALaQHIJYDjRSrwuvfuzWrubYuKXteZDrnGVHIfyVIOdBTYsWvXgayLxtbmPBDhPchtKWOHZMrHxoBmwKDxwKBrcEdRQyIJZUjztSEeEljDVGvwoyCVvYDuCASBrFwYhYwyHooJMVIbeelykkxGcaPSYnXwGNUcbbcFHflOBFRwTcZDiwDPqCLULHIFSmhvSzgbdrindGFhiFWiJDyhEjvnsEBXbyzu");
    string FxcUuYrzR = string("aYrvIRNHVCxaROnGECSnVSEMeCoAjCBrKEiDqoPjmEjzKEQjtLZzXlHqejxVoOiGJAojeDCpOcWxLrDXFYqKTdjYcgtTzGoyenJjYbvYpwjqIEbADpxPgPnPadOmjxcRijpFfZeZzNeyVhsvGekOekwzVwxgqeVYuEiXPLVxqLxTUfKSRnwNEP");

    for (int qMDJvnJdI = 193011684; qMDJvnJdI > 0; qMDJvnJdI--) {
        FxcUuYrzR = FxcUuYrzR;
    }

    for (int SroOYuWY = 1757809053; SroOYuWY > 0; SroOYuWY--) {
        continue;
    }

    return njzyGfymDTiFZMlK;
}

void LoDgYSzC::PUtujJTsEUe(int qoPwqWbVafymfq, double YlQNEafXDEl)
{
    bool uWnbyq = true;
    double eYeeqc = -169877.10255064722;
    bool mkoJD = false;
    int NlrMBN = -653063815;
    string ZJOmOQSrs = string("MrWsAqGTwm");

    if (NlrMBN >= -517024181) {
        for (int AsZNpw = 716539199; AsZNpw > 0; AsZNpw--) {
            uWnbyq = uWnbyq;
        }
    }

    if (mkoJD != false) {
        for (int BuyEMlfB = 98741794; BuyEMlfB > 0; BuyEMlfB--) {
            mkoJD = mkoJD;
            uWnbyq = uWnbyq;
        }
    }

    for (int mCXwTGaGNtUQ = 713280017; mCXwTGaGNtUQ > 0; mCXwTGaGNtUQ--) {
        ZJOmOQSrs += ZJOmOQSrs;
        NlrMBN = NlrMBN;
        mkoJD = ! uWnbyq;
    }

    for (int KcGmqQguaRySvFVp = 325568078; KcGmqQguaRySvFVp > 0; KcGmqQguaRySvFVp--) {
        eYeeqc += eYeeqc;
    }

    for (int TOaduW = 1020769632; TOaduW > 0; TOaduW--) {
        continue;
    }
}

LoDgYSzC::LoDgYSzC()
{
    this->ILOqvWOBvmytilx(1788102941);
    this->GrxWIeONbfU();
    this->bUMzkjd();
    this->tdxwa();
    this->ndxQzhEfVEzJdwZI(true, -1434890155);
    this->QGSEalpilEplT();
    this->XMLBtcsI(-870046483);
    this->TJWkh();
    this->PUtujJTsEUe(-517024181, -143871.70467576385);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZjVNUiUoifCnb
{
public:
    string JBorBektlDuq;

    ZjVNUiUoifCnb();
    string MoFWqBtHUAcXBE(double OYEaYeCCvoBVB, int UUfbR, int rKCNRlOOigT, string byUckqUlqyCXJq, bool FXNhXzywoUHiFbr);
    void vofAkmYVWKdhNeLY(double qJMNnsJ, string YUJRMDGn, bool UIFdMtsSrb, bool RMWQgxPViLJ);
protected:
    bool zEeOs;
    int Bvzuah;
    double hnZOqXFfBvq;
    int FsDWnxSIEyZ;

    int MohDmLcQzGuwGI(int vbdQwJD, int vCATtTyy, int BkQmEtUIIvja, double GtUJMznEcvyK);
    string yQnBMGEyluyqNp(int JJDNZadUjBwSq);
private:
    bool EwrievjpZvvvfdSR;
    string RLgZYIBh;
    double ylvwpgeL;
    bool eJnMg;
    bool gvRdAOaMtI;
    double eOBkQNPN;

    int fiytJuAN(double dDoZvGUpiIEiwmTb, int oXNZkibiZ, int VOuyvWWUx, bool mMqgxjswYX);
    bool QtCgbHvxh(int UbEWbZKkLRdg, int OhDmoIJHQ, bool sUMfkgVoARZnEp, int tjFihwPYE, bool RNSjBr);
    int oFHfRfQUI();
};

string ZjVNUiUoifCnb::MoFWqBtHUAcXBE(double OYEaYeCCvoBVB, int UUfbR, int rKCNRlOOigT, string byUckqUlqyCXJq, bool FXNhXzywoUHiFbr)
{
    string ufMzYIle = string("IuCBJCQYWHIjBenrqaTxHAjkzUhJBKPdQOaKbIVUZdDyJATZNQTNJzEXzPMersKOHlHmYllIltsJEwnfsMxlgMsBfByWmGpNNIfbhEMjedJqQjHKXCcJfQUBFlagnYjfQycERrKDLAKeDnEPrutiVCUtdjQSXtvrBCirmj");
    bool DuSNHQUqinTSXPXh = true;
    bool RyJbpeaRX = false;

    if (RyJbpeaRX == false) {
        for (int LlMYijESQIteMS = 680318042; LlMYijESQIteMS > 0; LlMYijESQIteMS--) {
            FXNhXzywoUHiFbr = ! RyJbpeaRX;
        }
    }

    for (int KrJLgfuAGnj = 1761408198; KrJLgfuAGnj > 0; KrJLgfuAGnj--) {
        FXNhXzywoUHiFbr = FXNhXzywoUHiFbr;
    }

    for (int pCBJyPtPYRCZS = 1756274964; pCBJyPtPYRCZS > 0; pCBJyPtPYRCZS--) {
        continue;
    }

    for (int lmJjifybBpq = 828649814; lmJjifybBpq > 0; lmJjifybBpq--) {
        continue;
    }

    for (int pVeicsgLVY = 1609094523; pVeicsgLVY > 0; pVeicsgLVY--) {
        ufMzYIle += byUckqUlqyCXJq;
        UUfbR = rKCNRlOOigT;
        DuSNHQUqinTSXPXh = ! RyJbpeaRX;
    }

    return ufMzYIle;
}

void ZjVNUiUoifCnb::vofAkmYVWKdhNeLY(double qJMNnsJ, string YUJRMDGn, bool UIFdMtsSrb, bool RMWQgxPViLJ)
{
    int mbcNHdjtNINFOJf = 120606603;
    bool xFItaqMQutLsKTp = false;
    string NlKenuNno = string("bVAlQMBcyvuXsmMxlMSMPyJuZgcszDGdSqQoheBExWpMmPqhGWqsMrUMmaUlHGTbcUZupVwbzhbnIADOnfVCAINzxRZdrwtMxlUtgoEFJgbZReZRUCbRnsuUbVdLjPPpNsPLdHTAWkaHHPzYHaMyiZSCMCiLgKCTySuEUpadRrTctZAnoTIRXkfALgPfSMORvfscJjEbuE");
    double xQBYOLqAQtOvBYdw = 936392.5628404337;
    bool NSVFSS = true;
    string CmWAgdrUDkSD = string("FzIwAHqxJqwFEmNtEEPUPmNhwKNKavRYTHknuCyMhaKxAHrgOABFNMBwsCEqrKHBDGqmGxmHHRtxmtQXHOFMaSIbBuYACozHNuLjgkeQLOYAiYAdmJybcLZmNTDBPRjDLAPewtgcqqlQzTKYTaGtbaYkVFxuW");
}

int ZjVNUiUoifCnb::MohDmLcQzGuwGI(int vbdQwJD, int vCATtTyy, int BkQmEtUIIvja, double GtUJMznEcvyK)
{
    string hVwABUdKQDdfGabz = string("jtFgzDzITKgYRVYNHAzSROrjGiAkEGTsyiyWEJGAAwxRXwXlCIpUjRAygYOjIwOPdqGONLyQKjAiZISNSffVVfHdfEKHftQyZEhVvlxVgantdlzTkUacZUuYIbUSWZCyyXmMJsJOwELsBOSdPgnULAlrLPchVnjHFZRMZCRiLQGPbhIYaOJSdfLGBoZDyXjZqPYPAruVTLZSjfJFWomDFfIZrhRVrGRlBDuydxFJyYpBDyiipixW");
    bool uTcYlCm = false;
    double hUciyxqjRu = -872026.3602854147;
    bool jqYQV = false;
    bool JKCEGdS = false;
    string SfpnfKLAISwyhVy = string("dKLXBLpVkQJNAulCczHgZGzlyfVgZuuZyUEKxgnYMHpDKGgVPhZSJioDZIWDUHAvAsDnAaRKjiVkIoDavaptkNsBHyx");

    return BkQmEtUIIvja;
}

string ZjVNUiUoifCnb::yQnBMGEyluyqNp(int JJDNZadUjBwSq)
{
    int CaDJjnbyaJSN = -986127296;
    int OXalAGESQSBtEXz = 754168573;
    int Cehftn = 2117067683;
    int PTuhA = -1099509333;
    int qhakOEpq = -1088399716;

    if (PTuhA < -1099509333) {
        for (int noRuiwHVfJlVWDC = 362817701; noRuiwHVfJlVWDC > 0; noRuiwHVfJlVWDC--) {
            PTuhA *= qhakOEpq;
            JJDNZadUjBwSq += JJDNZadUjBwSq;
            JJDNZadUjBwSq *= PTuhA;
            CaDJjnbyaJSN -= qhakOEpq;
            PTuhA = JJDNZadUjBwSq;
            CaDJjnbyaJSN = JJDNZadUjBwSq;
            CaDJjnbyaJSN *= Cehftn;
            qhakOEpq += PTuhA;
        }
    }

    return string("dHmRnvjpRdZVAHQrtiUcyOFxfOtgXeiBulUomWXZyCpJARrnHEIlHPDIsrSbqJThYmaZUFYGzzKORKKzyaMHYBOSCxhiIbILMSWhMOJNjYdLmfFCXZGRimSbXMFrQrBoOPfDuCgEOboupRPYskPNuBHaLJughVYhBtiaEmPLmBnppzjgcsxhBPLpdbdRjrsmUOcUbvIgLcUxiIhYzbA");
}

int ZjVNUiUoifCnb::fiytJuAN(double dDoZvGUpiIEiwmTb, int oXNZkibiZ, int VOuyvWWUx, bool mMqgxjswYX)
{
    double jBdVGrvqhg = -466252.6967535804;

    return VOuyvWWUx;
}

bool ZjVNUiUoifCnb::QtCgbHvxh(int UbEWbZKkLRdg, int OhDmoIJHQ, bool sUMfkgVoARZnEp, int tjFihwPYE, bool RNSjBr)
{
    int qoIeudpV = -1467995018;
    double RwszzluopoN = -891950.8362358022;
    int WzchNJGPEKtEoXR = -1614778214;
    double ohVRMbWaIXq = 132256.55015093516;
    string hELOr = string("djGogAjqDrxxWHtdZxq");
    bool RVkXGvW = false;
    double CSaZJnAZchlNxOzc = 243144.33628860116;
    bool mCteQs = false;

    for (int fsBFaZr = 679056758; fsBFaZr > 0; fsBFaZr--) {
        continue;
    }

    if (mCteQs != false) {
        for (int ybQYZMJT = 245991039; ybQYZMJT > 0; ybQYZMJT--) {
            qoIeudpV /= WzchNJGPEKtEoXR;
            tjFihwPYE -= qoIeudpV;
            tjFihwPYE *= tjFihwPYE;
            WzchNJGPEKtEoXR = UbEWbZKkLRdg;
            UbEWbZKkLRdg /= tjFihwPYE;
        }
    }

    return mCteQs;
}

int ZjVNUiUoifCnb::oFHfRfQUI()
{
    int QvpcAwLHIle = -778672130;
    int nayJYXqkpl = 943233219;
    int ayLEIXgHMQVKOrA = -899292958;
    string bapeQeCPWYSXiIsb = string("vbZNezSKwgDnVEhkexTlNXhZuaHLGtCaHUtyMLfydzxnTVFNQMvecBoQqeUzJSzlUYARZpkbNwKBNMQKEoNghiroSyNbsCOvrhIiKniSSqiIlSGWtzuRKgyHPyQRmCOoCBzzcRgJGFtdIcVGejZcMZOpcVxVoyvLhEZERXSJJiryUKJewptjXJDGUJsxqZdPWKYdSDtMakJxAODVQIHDghdPAWjpNnKNzvNByYSqxJCcywHJsykFBNHkjNpS");
    int wIwczM = 1938052833;

    if (wIwczM < 1938052833) {
        for (int FZLte = 1516547345; FZLte > 0; FZLte--) {
            bapeQeCPWYSXiIsb += bapeQeCPWYSXiIsb;
            nayJYXqkpl *= wIwczM;
            wIwczM += QvpcAwLHIle;
            QvpcAwLHIle *= QvpcAwLHIle;
            ayLEIXgHMQVKOrA *= wIwczM;
            nayJYXqkpl *= wIwczM;
            nayJYXqkpl -= nayJYXqkpl;
        }
    }

    return wIwczM;
}

ZjVNUiUoifCnb::ZjVNUiUoifCnb()
{
    this->MoFWqBtHUAcXBE(-539414.6725267954, 1892258654, 878719962, string("aaxzBpFbsaRHmGuVsLkVSNOoQLRMNVASDPkhWqWbAXAYRuWLXQNOisYtXQCfEACbMpnKgryIsaUhYJlJxIvQbAItEOMPseEuaXpOHEyNShDCiUBBLjMQXSPTuGcVtd"), false);
    this->vofAkmYVWKdhNeLY(912865.5355929413, string("xXxkYJGBNrgjKCXyJMItAsOPSVMNjzvhIIqgLalLSXMpyFvTUrwSTQzXPqawDilAvydUjJfxWVdX"), true, true);
    this->MohDmLcQzGuwGI(916432862, 1384932163, 195553709, -472723.1266735759);
    this->yQnBMGEyluyqNp(839525184);
    this->fiytJuAN(300557.6554930563, -1539211797, -978627691, true);
    this->QtCgbHvxh(-1382953714, -1023982693, true, 176058063, false);
    this->oFHfRfQUI();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ICmwoWZuJC
{
public:
    bool nBLTsPqJvtWfLhyw;
    bool QrBnaXmouUABI;
    string FjNQfeDl;
    string QFKpxA;
    bool GBrznNJV;

    ICmwoWZuJC();
    int uHNFGBkCEjH(string WEAeqHbkvtgYyKD, bool qBykBstJIR, bool WuhMvIlzOWTeFA, double iVlZLxoaR);
    int AZcjVKKFVutvL(int WQsRamqlFFNxE);
    int ZUlvomsoJkbnKk(string eWGddNqbPxz, int ewoAgBq);
protected:
    string PIomdJPSjZ;
    bool wzbZW;
    string MakNoVSCReGJWrxS;
    double eWxFZxVKOghc;

private:
    double bzuqsCvDPwVeI;
    double PgbbZsWnUEHI;
    int sgpKwnNkjN;
    bool NqZxUjIVmZ;
    string tFBMASq;

    string qDzTmqKmSSy();
    int gWjqNNpMvvIbAT(int CmalEzRScpCf);
    int UsGgbwPsTrSmvs(double LiLMsJNswNI, int HPzKsawHqHgXhKg, int TqvGDKSTCgmi, bool oSzwAneacCXTP, string mDkklhVwIQswC);
    void ClMddhhOADt(string WxWmTaJS, string jxrid);
};

int ICmwoWZuJC::uHNFGBkCEjH(string WEAeqHbkvtgYyKD, bool qBykBstJIR, bool WuhMvIlzOWTeFA, double iVlZLxoaR)
{
    int prqxUULdvwK = -586533870;
    bool EozIPHCONXjdCF = true;
    double AAHitusKJZ = -877325.8363093118;
    int dIvkn = 1010220634;

    for (int kKDhWWE = 198551087; kKDhWWE > 0; kKDhWWE--) {
        AAHitusKJZ -= AAHitusKJZ;
    }

    return dIvkn;
}

int ICmwoWZuJC::AZcjVKKFVutvL(int WQsRamqlFFNxE)
{
    double ZvCzkGJQG = -510578.04511901503;
    int RJKepbyPjN = -122300212;
    string fUqvqjPWHKpmpv = string("ihcgosjVhbKQjKFeWmxtadIAEJWdM");
    int vHaJDcV = 754910547;
    int ctmtyQwpJiBkz = 274277338;
    int duskoocZvblH = 1352226520;
    string OilLFQiZeqkXHHE = string("sBgTMxlFhyzBmcOvhyQJJPwOtbjktkcftVDKUsdFdrnmryUdJosHBslmtUtORiSgMurqruWwlTtjeuhMYYhBnaYywksEgYVbJbkUQIusqOnNwCygVVSUzRyFtPbWRZQicQTcUqpHjrgbeaOlAdeTnmiVChXoSDkcRDZzeDoDyKcramKrAnacGcobFnMYrJxoviNzFMtzwuIEKgTbiZHmfNzc");
    string PGWpBCS = string("vaDGSyGQXtmhSWKvfIOtaDbJPzGsFhsPKqhDHgbGFSDmIXrassrgnflvcyIzkKALAjRyMyRGImOIfzMEpOTIgJWSyTMGIToqVLipTgjqQOiWPnkGlsDUiicNlYui");
    string rjyzZLkUIICCEwWR = string("dArtNYdHRodiwNIjQmxeWQeucHYlEgUecTbHxalnbeqQChRSBuJwLVkBGkrxMJSOkRMUeFHmPqKLEtkjRuTvNxlendbaZeZYkElOOGbOlhdXpfNMbwhjnHArfsEibzsPEZvOtnPMQNZtZGJX");
    bool JvXbXdI = true;

    if (rjyzZLkUIICCEwWR > string("sBgTMxlFhyzBmcOvhyQJJPwOtbjktkcftVDKUsdFdrnmryUdJosHBslmtUtORiSgMurqruWwlTtjeuhMYYhBnaYywksEgYVbJbkUQIusqOnNwCygVVSUzRyFtPbWRZQicQTcUqpHjrgbeaOlAdeTnmiVChXoSDkcRDZzeDoDyKcramKrAnacGcobFnMYrJxoviNzFMtzwuIEKgTbiZHmfNzc")) {
        for (int zRftirITkJrWCyUj = 298171075; zRftirITkJrWCyUj > 0; zRftirITkJrWCyUj--) {
            vHaJDcV = ctmtyQwpJiBkz;
            fUqvqjPWHKpmpv = OilLFQiZeqkXHHE;
            PGWpBCS = OilLFQiZeqkXHHE;
            RJKepbyPjN += vHaJDcV;
            vHaJDcV -= vHaJDcV;
        }
    }

    for (int iTfrEilCGYCD = 1477490791; iTfrEilCGYCD > 0; iTfrEilCGYCD--) {
        fUqvqjPWHKpmpv += OilLFQiZeqkXHHE;
    }

    for (int UqARbxTZZeYhSl = 1141691097; UqARbxTZZeYhSl > 0; UqARbxTZZeYhSl--) {
        rjyzZLkUIICCEwWR = PGWpBCS;
    }

    for (int crStAlj = 305244909; crStAlj > 0; crStAlj--) {
        vHaJDcV /= ctmtyQwpJiBkz;
        PGWpBCS = fUqvqjPWHKpmpv;
        RJKepbyPjN *= vHaJDcV;
        vHaJDcV = ctmtyQwpJiBkz;
    }

    for (int ldzkeuwdABQLeE = 468866754; ldzkeuwdABQLeE > 0; ldzkeuwdABQLeE--) {
        continue;
    }

    if (ctmtyQwpJiBkz != -122300212) {
        for (int iSFht = 1653546064; iSFht > 0; iSFht--) {
            continue;
        }
    }

    return duskoocZvblH;
}

int ICmwoWZuJC::ZUlvomsoJkbnKk(string eWGddNqbPxz, int ewoAgBq)
{
    bool bqPQdRdF = true;
    double zaSMuXMVIPARCX = -166511.98800212704;
    double OINmbFUusaQFC = 417326.17245544033;
    int owQlDcxGmu = -1467494196;
    double KyWGlzWixbiUq = -739072.312347278;
    bool diEkHr = true;
    int shmbFVz = 474138201;

    for (int rKWMVkZxqaexsCJ = 1940845773; rKWMVkZxqaexsCJ > 0; rKWMVkZxqaexsCJ--) {
        owQlDcxGmu -= owQlDcxGmu;
        ewoAgBq *= owQlDcxGmu;
    }

    for (int orzKSZKnFBse = 1457189641; orzKSZKnFBse > 0; orzKSZKnFBse--) {
        OINmbFUusaQFC = KyWGlzWixbiUq;
        bqPQdRdF = bqPQdRdF;
        KyWGlzWixbiUq -= OINmbFUusaQFC;
    }

    return shmbFVz;
}

string ICmwoWZuJC::qDzTmqKmSSy()
{
    string zMCWptwNETqjQU = string("CSDstiaNyqpiBrmCfHYDMlXGydfPyqQhOTegtgyzdClxYzSuWPbjiBaeZNJXFcrpKWqBzxJgzRFF");
    string NwOqtrouaZeJz = string("NtyRbZVstvLRnwEKiWONZcEWvYnwroESAahSMfFIhvvvyxMhijDD");
    double rsvgvfY = -275193.11197573453;

    if (zMCWptwNETqjQU == string("NtyRbZVstvLRnwEKiWONZcEWvYnwroESAahSMfFIhvvvyxMhijDD")) {
        for (int nhGsYTi = 1090165824; nhGsYTi > 0; nhGsYTi--) {
            NwOqtrouaZeJz += zMCWptwNETqjQU;
            NwOqtrouaZeJz += zMCWptwNETqjQU;
            zMCWptwNETqjQU = zMCWptwNETqjQU;
            zMCWptwNETqjQU += NwOqtrouaZeJz;
        }
    }

    for (int xZsLNLbSwPLDpQis = 24709599; xZsLNLbSwPLDpQis > 0; xZsLNLbSwPLDpQis--) {
        NwOqtrouaZeJz = NwOqtrouaZeJz;
        zMCWptwNETqjQU = zMCWptwNETqjQU;
        zMCWptwNETqjQU = zMCWptwNETqjQU;
        NwOqtrouaZeJz += NwOqtrouaZeJz;
    }

    if (zMCWptwNETqjQU == string("NtyRbZVstvLRnwEKiWONZcEWvYnwroESAahSMfFIhvvvyxMhijDD")) {
        for (int MvhjXbK = 1756706916; MvhjXbK > 0; MvhjXbK--) {
            zMCWptwNETqjQU = zMCWptwNETqjQU;
        }
    }

    if (NwOqtrouaZeJz > string("CSDstiaNyqpiBrmCfHYDMlXGydfPyqQhOTegtgyzdClxYzSuWPbjiBaeZNJXFcrpKWqBzxJgzRFF")) {
        for (int mlOhaZLcZmhs = 702231789; mlOhaZLcZmhs > 0; mlOhaZLcZmhs--) {
            zMCWptwNETqjQU += zMCWptwNETqjQU;
            zMCWptwNETqjQU = NwOqtrouaZeJz;
            rsvgvfY *= rsvgvfY;
            NwOqtrouaZeJz = zMCWptwNETqjQU;
        }
    }

    if (zMCWptwNETqjQU < string("CSDstiaNyqpiBrmCfHYDMlXGydfPyqQhOTegtgyzdClxYzSuWPbjiBaeZNJXFcrpKWqBzxJgzRFF")) {
        for (int YcLunZpnXz = 1161618609; YcLunZpnXz > 0; YcLunZpnXz--) {
            zMCWptwNETqjQU = NwOqtrouaZeJz;
            zMCWptwNETqjQU += NwOqtrouaZeJz;
            NwOqtrouaZeJz = zMCWptwNETqjQU;
        }
    }

    return NwOqtrouaZeJz;
}

int ICmwoWZuJC::gWjqNNpMvvIbAT(int CmalEzRScpCf)
{
    double OIuLZknHNG = -489165.3577500428;
    int oNyALPdMMgY = 478180784;
    int BGWZEeYclV = 1913673546;

    for (int peVyMTGgDFHkZcYc = 670703065; peVyMTGgDFHkZcYc > 0; peVyMTGgDFHkZcYc--) {
        BGWZEeYclV = BGWZEeYclV;
        BGWZEeYclV += oNyALPdMMgY;
        oNyALPdMMgY *= BGWZEeYclV;
        CmalEzRScpCf += CmalEzRScpCf;
        OIuLZknHNG *= OIuLZknHNG;
        CmalEzRScpCf -= BGWZEeYclV;
        oNyALPdMMgY += CmalEzRScpCf;
        oNyALPdMMgY *= CmalEzRScpCf;
        BGWZEeYclV = CmalEzRScpCf;
    }

    return BGWZEeYclV;
}

int ICmwoWZuJC::UsGgbwPsTrSmvs(double LiLMsJNswNI, int HPzKsawHqHgXhKg, int TqvGDKSTCgmi, bool oSzwAneacCXTP, string mDkklhVwIQswC)
{
    double APQkwLfzsvHHX = -257627.9101181047;
    string RkLoSyJGP = string("bwBzhEustoAxEMLnjSTXNRtAhlHWjPvRBTyoMBdeKQzIvzrfNhMlpYtIjYSigZBEbUTxfSxznLtfZPkfaIuQfoABZHQckxrQpxSPWIwLGBxCMibpHfLNEcCWemSKnxnvTAIHOJwUpqgICndEftReZQeeiSuSVEpmTaRUM");
    string WXhJvGR = string("HXYHRKJRyNkwprHYZikMmuAUzdhlibtRRpumsqlvFSAaOjjBWNvAaFZQpgxMnPUGDGdaelwzOISPGuJgXsJEvEUYxnIufstHVlpeFaLZOAXzKOnro");

    for (int cPzrmRdo = 1693214572; cPzrmRdo > 0; cPzrmRdo--) {
        mDkklhVwIQswC += RkLoSyJGP;
    }

    for (int MWpHgq = 1629497234; MWpHgq > 0; MWpHgq--) {
        RkLoSyJGP += WXhJvGR;
        WXhJvGR += mDkklhVwIQswC;
        HPzKsawHqHgXhKg = HPzKsawHqHgXhKg;
        LiLMsJNswNI -= LiLMsJNswNI;
    }

    return TqvGDKSTCgmi;
}

void ICmwoWZuJC::ClMddhhOADt(string WxWmTaJS, string jxrid)
{
    double QVKIx = -76759.92139605078;
    bool wKIFWuBIP = true;
    int BsUapgTKTlxWhX = 147894902;

    for (int fcRrlKvBcP = 1024629405; fcRrlKvBcP > 0; fcRrlKvBcP--) {
        BsUapgTKTlxWhX *= BsUapgTKTlxWhX;
        QVKIx *= QVKIx;
        wKIFWuBIP = ! wKIFWuBIP;
    }
}

ICmwoWZuJC::ICmwoWZuJC()
{
    this->uHNFGBkCEjH(string("MmaLJoZlNxeDUyqEcERIBqPRgWoxwapPxCeGsvhHslZTCSHFqlPFcXAdVWxcbgfGqYyiqSvDikPsgEELMasWjXKCVJkZsijiHuXUCIWCJcAbBrjQTGEcvvEocLnhatzEZShXvFFoYtxOdllHASumfQFyVmytOBdopVvYliBqAIBeeVfWxUcWldIZZfiZoFK"), true, false, -188325.7504481334);
    this->AZcjVKKFVutvL(763351643);
    this->ZUlvomsoJkbnKk(string("hmPjFDEYRatZjYpiBJLIHuUKEWFNbbMTPDkLnMWkwbxpegAoVMQcZNHFyYLAqSCtMridhvQMFfmInEdcgRmiMtfoDwGQJVfGWsNOijUaEIIuAmJkKmVZtKGAuJSpAmCfcfWDwYUVcENYhwTehPOhzNcrrsreTJzQtYltTnIieRUQXYhnXxyeyulGyYRYYZpuPheILEZZkRMkWvzP"), 993314431);
    this->qDzTmqKmSSy();
    this->gWjqNNpMvvIbAT(-174332680);
    this->UsGgbwPsTrSmvs(742379.6969334021, 1198333049, 995697166, true, string("fEsjhRyBxEyWvLCMuiESxVYWmNfGFSyjThcouQxMXOSiYOjHkABVaZwMPnqHgxGlWZNbgCTHftbwcwsZJAWfyPzYgjtbOgDiXaOIVcoTxmlaBHWnitEIRXVRCuyihovdKTFkDWrFOuHjopYjtSPUoihCzDzwClsDvjrLdPXBXYZujKEaboBnMcKGqBypiJgehxgeXyJSRdVkaCnlvkqSVyPtZoHVhz"));
    this->ClMddhhOADt(string("SUYnzlQCCDz"), string("XdHURPPzWjxKWJkudjhEYnbkZvusNBAmAiXnqxCRvUBWsGTFpbxNUaBnQfVdPfTHOIUdqPMppJyfLWSblndnTJhbNIEEOWWmmESbNzrCXPy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CgDexr
{
public:
    double ShsAOmkykyd;
    double nhdLvnMd;
    string iOHaTR;
    int SMiwbzDCmp;
    bool kbemhkwkEo;

    CgDexr();
    void DbgMuJThxQs(double rzidaiVqKzskEr, double gOYRbWPnunmh, int ugltpfkGMEgDqmF);
    string iQlrTTIaYtIp(double MJFwMBzLiLr, bool MlYIZ, bool IvSdfjmnePzcgqK, double sEjBZKXgMvZtxG);
    void HvyAliwVh();
protected:
    bool hlWrvLYqVbwEHF;

    double rlmrWsBtAkw(double ljQXzULiHCWYHpK, int IoxBGcHdzYIl);
    int ootcfSSO(int rWUExVwmNEVoJz, double awpzwMfBdtbGVb, bool CwTsRSKhGu, string OkaEcGJ, double qoNKj);
    bool tyKDFAIVirFcm(int OSXCgsfVxwiyvQOD);
    double WjUfhC(int MXMkNMGJH, string lpSsvAGtVfaVtvIa, string FfLFFHxVWqEB);
    string jRbSBcQZDFD(bool LuZifGzmz);
    int hDQVGOANV(double oNHxkPwhTSHN, bool yqDLHEyrasQByn);
    string kxTnK(bool rcpDRlXUYCXVXl, int leXVrFVRwqEx);
    bool FDwwoNTAsSYaQ(double AveFBnUxHYiI);
private:
    bool srWvDodP;
    string pKxxSsxKUwyV;
    string NdHvkRG;
    int CWNIDYKPZb;
    double kjkrEpnyvewgXxD;
    string kXXxmmtjsFlqZI;

    int XFLBjvYZg(bool eZrcGZhac, string pSdNcDT, bool mCBOjCRYKnCrcQ, int uVFVWw);
    double SoJjjepTTnZvEh();
    int hLQALjwbA(int IqghHe);
    string dtqJZgvjUIfXO(bool xwxHNAKAL, double PaodyznahHyPOhjC, string WRRWoPrJmgmX, int HeCmSBrEZfVwNO, double gNkDFafk);
    bool LsLdLlcEp(double qvDQDEAuNIkKQEt, bool JDKoVPZUfVbsWBX);
    bool cnHbIEex(bool QonKeUx, int bijXlRow, double bIvfZpzrdXxgtMO);
    void qKYMT(double LfSyWnMz, int iVfdEfiyS, bool iKjNgEHfL, string TLARqZXELQHBeRK, double HOghmgKjTAJ);
};

void CgDexr::DbgMuJThxQs(double rzidaiVqKzskEr, double gOYRbWPnunmh, int ugltpfkGMEgDqmF)
{
    double oKqkFrbt = 36296.594166945906;
    string qgzmOMBtdRQH = string("SEywbRXowKeyBVQwqxlhRTCCzaDLVaagcTLajgiWeXhnEgdqmVRyqISlzHuMaLytGOMoujBJxrguVNAqiuKwEWDQBubTVjGx");
    string TSHJfD = string("zfXzEgpLaHMMqyUbenueKNqiBMSKLeHXoOfghNNpAholhCGRVrpIVtwlUZNCVOvqbsBbRDgFzsfyOsmZOySCmuqPTdMFViqXOQnqTUKxTgzTfZWIYItBUDSYnRgGnneBwOhNpoqkQOUilbBMDipTbP");
    string hjrZbogAWeCc = string("sSFIkhMHBurhIrWCtYrAyhgPwSleXvArvmtPFiDdjCaUHtrgOnKvOcekHzxNsM");
    double QqiSpqXJakpkVri = -630953.3756374303;

    for (int UrQIOMMjCHQUp = 80497266; UrQIOMMjCHQUp > 0; UrQIOMMjCHQUp--) {
        qgzmOMBtdRQH = hjrZbogAWeCc;
    }

    if (QqiSpqXJakpkVri != -630953.3756374303) {
        for (int joyoHnf = 966569395; joyoHnf > 0; joyoHnf--) {
            oKqkFrbt = gOYRbWPnunmh;
            gOYRbWPnunmh = oKqkFrbt;
            qgzmOMBtdRQH = qgzmOMBtdRQH;
        }
    }

    for (int fpKnX = 1033227; fpKnX > 0; fpKnX--) {
        hjrZbogAWeCc = TSHJfD;
        qgzmOMBtdRQH += TSHJfD;
        oKqkFrbt += QqiSpqXJakpkVri;
        qgzmOMBtdRQH = TSHJfD;
    }

    for (int GIfQTxhKNVI = 613569833; GIfQTxhKNVI > 0; GIfQTxhKNVI--) {
        QqiSpqXJakpkVri /= gOYRbWPnunmh;
    }
}

string CgDexr::iQlrTTIaYtIp(double MJFwMBzLiLr, bool MlYIZ, bool IvSdfjmnePzcgqK, double sEjBZKXgMvZtxG)
{
    string aisYKwNn = string("cuYxhnrUdjYRsjyiKipTmwYZuTOxoRHyRoGPRyayolHIBjDLFjlOCt");
    double wZRrEyxr = -526448.1553544068;
    string wyZxjo = string("gIgCrWtTAnQiKBeDsTrkWJddijqUAXrOEhPlqOtjTBClFnYIXFWAKRcFcaZzQDpmexuGLtIYKiUMsjVaUDhRxxDmXQAtGTdvJCLJLBCnSYGVFbRJKCrnKcNbrgOsQjegEkOCkAAdoGTrsfKKWhdkTMinMLxUzBqOmXTIzQU");
    string idNKbWlhIoJybJO = string("EVxuUHgHfLgFVzhuwdNQBGEWNhcIEAMDCMTkVXFlqElcTNKMDtzVczBoJSYWxWHheCawIGjDcksRiZtnyoHFXwXVudATjRwSwwsmOhUiYHFgEcDFLRptzsluRGEfvDSsNvBVjsCRtXUQxJmzIZsVrEbYvtkksUYsMrcxfeENefEZqftqpcqHefpItgveaAoqsiLSEbMqNxqorapoDmCdPpHuo");
    double pUcNUrDujzxmEo = 901197.6884765719;
    bool fTqvOxMZYDvug = false;
    string jtBBETCVRa = string("zHRSOcZYmxbAeSfVZLjZiyenvaHGEegAB");

    for (int QJzediWaqUuTC = 1354711299; QJzediWaqUuTC > 0; QJzediWaqUuTC--) {
        aisYKwNn += aisYKwNn;
        pUcNUrDujzxmEo *= MJFwMBzLiLr;
    }

    for (int micGVYcKDC = 1374707222; micGVYcKDC > 0; micGVYcKDC--) {
        continue;
    }

    for (int DxvPIWUJGTD = 220927689; DxvPIWUJGTD > 0; DxvPIWUJGTD--) {
        wyZxjo += idNKbWlhIoJybJO;
    }

    return jtBBETCVRa;
}

void CgDexr::HvyAliwVh()
{
    string vtCwXLJesrjOOq = string("NZOknnJmaafLdVsNeECrwULKPlpNGluRttIdglSJIONKAQJoHEepgVOzckMMoEDBOFPyVUAKkKFfTyMEbDDxBHPOvDeDIwbLFtAWxRFIUXfMZHFpbMgOELxiPDAXLbWbhQIeZQsWRixmscjiKURjGgcNSkYFmgAmGZGTAcobeNhbzjnySoGTkNaoXxeHaieHxbNmKc");
    bool aQFrfsjgIb = true;
    string oJdqylthgAhq = string("jlkkvEfqRpfkAaHAUtFmApqXjePwBrvHFReGizvrCgAduxBgEDGKPjgHrASezxoihZtlAkbSGoESomCXNzpjHtspbyPGfhfUTbjtiPKBczuLGyMauIrp");
    string AQvWm = string("MufCfmGWFXOqAjnaPbNOqWecgspSlubNchmogwutBPLXOcdvtgTtMXPmyQcUgJRPBJXNN");
    int wwGgWbpnLZA = -1405268840;
    int cibMBogmR = -1732152524;
    int xevIRYdedUlLq = 1400729112;
    int VFmRl = -1880762532;

    for (int hoNNZxzrkQsSmWxL = 1552132404; hoNNZxzrkQsSmWxL > 0; hoNNZxzrkQsSmWxL--) {
        vtCwXLJesrjOOq += AQvWm;
        AQvWm = vtCwXLJesrjOOq;
        cibMBogmR /= xevIRYdedUlLq;
        cibMBogmR += VFmRl;
        xevIRYdedUlLq -= xevIRYdedUlLq;
        AQvWm += vtCwXLJesrjOOq;
        cibMBogmR /= VFmRl;
    }
}

double CgDexr::rlmrWsBtAkw(double ljQXzULiHCWYHpK, int IoxBGcHdzYIl)
{
    double mcJeoxTtL = -1036071.3075611658;
    int ulGtYyRxc = 991588717;
    bool VCXbsyITpzbxuX = true;
    string HawepCWLlCXKH = string("cqxQRBdUXZksshgoCNoGuFZ");
    int lcmKJqRI = 1044833991;
    int CaZToNBmKUAd = -675695657;
    bool oEcAGm = false;
    double uETIXaxAHQsSJIK = 725889.2318707292;
    int ZMshOIAEKB = 1002785683;
    int XPKaAJKb = 767728486;

    if (uETIXaxAHQsSJIK > -1036071.3075611658) {
        for (int RhixzvjwsWDVeF = 1811543062; RhixzvjwsWDVeF > 0; RhixzvjwsWDVeF--) {
            HawepCWLlCXKH = HawepCWLlCXKH;
        }
    }

    for (int dnUEVtygCjkseb = 2108441915; dnUEVtygCjkseb > 0; dnUEVtygCjkseb--) {
        continue;
    }

    for (int LOUwHRPeYfkcxqJ = 1628951586; LOUwHRPeYfkcxqJ > 0; LOUwHRPeYfkcxqJ--) {
        uETIXaxAHQsSJIK /= mcJeoxTtL;
        XPKaAJKb = XPKaAJKb;
    }

    if (uETIXaxAHQsSJIK != -755686.365944569) {
        for (int koBbQqYZoVnH = 2075196657; koBbQqYZoVnH > 0; koBbQqYZoVnH--) {
            continue;
        }
    }

    return uETIXaxAHQsSJIK;
}

int CgDexr::ootcfSSO(int rWUExVwmNEVoJz, double awpzwMfBdtbGVb, bool CwTsRSKhGu, string OkaEcGJ, double qoNKj)
{
    double dORkfq = -19176.432285825565;
    string UbpCSMCVpTGdT = string("QKEjMoxqbVdkmqnRqxKBuclu");

    if (awpzwMfBdtbGVb < -712834.0962563838) {
        for (int dTZGkAcjFieiQk = 1055935044; dTZGkAcjFieiQk > 0; dTZGkAcjFieiQk--) {
            dORkfq = dORkfq;
        }
    }

    for (int oVcoHLTnEpQc = 922193782; oVcoHLTnEpQc > 0; oVcoHLTnEpQc--) {
        CwTsRSKhGu = ! CwTsRSKhGu;
    }

    for (int UwAiUfgPlyj = 1379272406; UwAiUfgPlyj > 0; UwAiUfgPlyj--) {
        continue;
    }

    return rWUExVwmNEVoJz;
}

bool CgDexr::tyKDFAIVirFcm(int OSXCgsfVxwiyvQOD)
{
    bool QeUGm = true;

    for (int INHUMqXaBEH = 1675324172; INHUMqXaBEH > 0; INHUMqXaBEH--) {
        continue;
    }

    return QeUGm;
}

double CgDexr::WjUfhC(int MXMkNMGJH, string lpSsvAGtVfaVtvIa, string FfLFFHxVWqEB)
{
    bool NHUTYRJ = true;

    for (int LlxTJMHgxQ = 262045203; LlxTJMHgxQ > 0; LlxTJMHgxQ--) {
        FfLFFHxVWqEB += FfLFFHxVWqEB;
        FfLFFHxVWqEB = FfLFFHxVWqEB;
        MXMkNMGJH *= MXMkNMGJH;
    }

    if (MXMkNMGJH > -1337051204) {
        for (int FkQIPC = 2096768262; FkQIPC > 0; FkQIPC--) {
            MXMkNMGJH += MXMkNMGJH;
            FfLFFHxVWqEB = FfLFFHxVWqEB;
        }
    }

    if (MXMkNMGJH < -1337051204) {
        for (int KtFCdAKr = 897259644; KtFCdAKr > 0; KtFCdAKr--) {
            FfLFFHxVWqEB += lpSsvAGtVfaVtvIa;
            lpSsvAGtVfaVtvIa += lpSsvAGtVfaVtvIa;
            FfLFFHxVWqEB = lpSsvAGtVfaVtvIa;
        }
    }

    for (int LvkUoWqtpGbGiq = 470614306; LvkUoWqtpGbGiq > 0; LvkUoWqtpGbGiq--) {
        FfLFFHxVWqEB += FfLFFHxVWqEB;
    }

    for (int QwuSmKyKh = 1958921710; QwuSmKyKh > 0; QwuSmKyKh--) {
        lpSsvAGtVfaVtvIa = FfLFFHxVWqEB;
    }

    return 21748.99285742165;
}

string CgDexr::jRbSBcQZDFD(bool LuZifGzmz)
{
    int XWbeyeytb = 1696050189;
    double VZMmakkqHHDrKV = 201507.30654122235;
    double xIgYAD = 332493.86608742;
    bool snqoyfAmuT = false;
    int KLLbrAzN = -1932624596;
    int vIBoLiLGaZlckOm = 1001476923;
    int WLMwVHNS = -36287854;
    int WShfrmxyrUhxcIDy = -376906550;
    double hFLUudTlnqsWIoJP = 1007445.628899625;
    int WWJXZjccZq = 660710569;

    for (int fQBhQRV = 1867377580; fQBhQRV > 0; fQBhQRV--) {
        WShfrmxyrUhxcIDy /= XWbeyeytb;
        WWJXZjccZq += KLLbrAzN;
        XWbeyeytb *= WWJXZjccZq;
    }

    return string("jmLyyJdGiomIPAYHudnAbacEAsMrlnJmksqOrrDHgLUsOGtSpejdAbNEJcKeYyrZlKMGmEUNYUKmYMJqRiKSVOjDHbsRGoJbCPDVKJhqOMbCEmft");
}

int CgDexr::hDQVGOANV(double oNHxkPwhTSHN, bool yqDLHEyrasQByn)
{
    string XfmbBsyQvhERlpK = string("DRpgAXhTJwoAfdKupwVsgg");
    bool WSHqNicPAXYBxy = true;
    bool yVOgmVkqFPidlR = false;
    double ipOnDuBDFzNhl = 980743.9860147767;
    bool uMCVBYhtpipIqY = false;
    string RVjYXqp = string("IUUOjUeAnwEjFBwTUQkgpQpbOK");
    string BGwwwWaZZ = string("eXpWwJqJvxuIyTMBUHwOlwtuBPNYdyJISKNqbqiziGNLEncZJQmjLDaHhzjWAIGuFNGEStkgRHfTbhwPskhZLirNJDAHtrbUzaGqxTOGuqMHCosDZJSzrPgUSAMLAHBXzPiuXYwwBhhRmzQoXLCFbFceYgzDyhXTqeFYCztNWmqcmfcUczLSCxIiKJnXJnUiQ");
    bool gFSIiUWMEelI = false;
    string MpTqe = string("CqJxRsGtltmprztBZUUgNHJaLmFOgJDKxYaTQeqSTjTLazltDoO");
    double bVwgC = -40170.97794592511;

    if (RVjYXqp >= string("DRpgAXhTJwoAfdKupwVsgg")) {
        for (int cZrDBiaLk = 1415283508; cZrDBiaLk > 0; cZrDBiaLk--) {
            uMCVBYhtpipIqY = uMCVBYhtpipIqY;
            ipOnDuBDFzNhl -= bVwgC;
            oNHxkPwhTSHN += ipOnDuBDFzNhl;
        }
    }

    for (int mdVBKMnn = 1766781119; mdVBKMnn > 0; mdVBKMnn--) {
        MpTqe = MpTqe;
        RVjYXqp = XfmbBsyQvhERlpK;
        gFSIiUWMEelI = ! yqDLHEyrasQByn;
        BGwwwWaZZ = XfmbBsyQvhERlpK;
        ipOnDuBDFzNhl += bVwgC;
    }

    for (int atpEnSaBponsXsJ = 1679625856; atpEnSaBponsXsJ > 0; atpEnSaBponsXsJ--) {
        continue;
    }

    for (int PIUbSakxxKbFtRH = 867490776; PIUbSakxxKbFtRH > 0; PIUbSakxxKbFtRH--) {
        bVwgC = bVwgC;
        gFSIiUWMEelI = WSHqNicPAXYBxy;
    }

    for (int HgFNklF = 685527346; HgFNklF > 0; HgFNklF--) {
        WSHqNicPAXYBxy = gFSIiUWMEelI;
        MpTqe += BGwwwWaZZ;
        ipOnDuBDFzNhl /= ipOnDuBDFzNhl;
    }

    return -98726238;
}

string CgDexr::kxTnK(bool rcpDRlXUYCXVXl, int leXVrFVRwqEx)
{
    bool WOZemauJQeu = false;
    bool NJNYIPMOsfJ = true;
    int FfXsTJQE = 1932027017;

    if (NJNYIPMOsfJ != false) {
        for (int lTIESFo = 1132101544; lTIESFo > 0; lTIESFo--) {
            NJNYIPMOsfJ = ! WOZemauJQeu;
            WOZemauJQeu = WOZemauJQeu;
            NJNYIPMOsfJ = ! rcpDRlXUYCXVXl;
            leXVrFVRwqEx -= FfXsTJQE;
        }
    }

    if (NJNYIPMOsfJ == true) {
        for (int TAMROXThbwwRQ = 1805428199; TAMROXThbwwRQ > 0; TAMROXThbwwRQ--) {
            WOZemauJQeu = rcpDRlXUYCXVXl;
        }
    }

    return string("uypRmLAPxsKGViRFKxbDqnmcnNDzvrypMyNOxgwSIviE");
}

bool CgDexr::FDwwoNTAsSYaQ(double AveFBnUxHYiI)
{
    int QOYofUcTOJRwshV = 248002569;
    bool skSDz = false;
    string PBFvQVH = string("mLfUkakJBqMwPjMclOyxhTlSJgLLpRubQmRPcHueGylwNpCLRLydiSAKlhQZTCbcSCqqOVzAPZKdcOHgPMkBmwWYmtcshGqxbnlKpFYMReLvNCDKEdhxwaMUJviKWQNmPFOnyCWlIXiSWbuNhLs");
    string aHfsbBfUyb = string("bPYQdIsrbKTnamRVUFjFPCRRVXbTlKkmGvRSgETLaQsAAslJFIICjCELIUjXztTfSamVjuuyRKHwsTbLydEuKJqJlCxNLHjobUMbnmgbvxjMfOcQYywgaELbEYOXBuZSFTjovhFIXKorItTBObLVUVXxtfyJvFRStMnVSPHTlrwNkSfQZgKnmSKyuIMJwcbJswdrFIdTgUWssqeDQc");

    return skSDz;
}

int CgDexr::XFLBjvYZg(bool eZrcGZhac, string pSdNcDT, bool mCBOjCRYKnCrcQ, int uVFVWw)
{
    bool eplEp = true;
    double AiOleuTnGJaomF = 1041978.4493808973;
    string KqfTFAUhDCabhIYx = string("XspSONOZnuRwGbvezOeOJohcsuYvmHAJXiMSdUBKtHsqJGilfsLijAxXuLwGWYKVbzzyQJOmWYihwPLyRzfnqKGAWZgPDFdvPkZyAgusBXRNaHmgqAKfDpQxTiBdaZegyLsPXqmhGvjvlQqBnfWivzhivAmFshGkNuSqwTcBQboKARSUCzPkftXpbioCJImozjwCWTLRosRuNBemMxfNLouiRhoqiqhiidBKVOdo");
    int mIMmTNRJuRDYMlGs = 522181186;
    string lfXxXoji = string("sIeTSvKafwSyJPkjEIhddtbZrXOYFoXUxJqMdYFkJAvCLSDHBHpVCiHn");
    string TXdoegjvjTxRfrF = string("hMqDBFVkJYaGikGnIyyJnWfnJzMlIUyRSTkFKSElLGLOmLRffTGIwoRMWzHPHXtHdFnAyjofpreWQPbdcYV");

    if (pSdNcDT < string("XspSONOZnuRwGbvezOeOJohcsuYvmHAJXiMSdUBKtHsqJGilfsLijAxXuLwGWYKVbzzyQJOmWYihwPLyRzfnqKGAWZgPDFdvPkZyAgusBXRNaHmgqAKfDpQxTiBdaZegyLsPXqmhGvjvlQqBnfWivzhivAmFshGkNuSqwTcBQboKARSUCzPkftXpbioCJImozjwCWTLRosRuNBemMxfNLouiRhoqiqhiidBKVOdo")) {
        for (int nobIvDWHaIsTwwH = 465605565; nobIvDWHaIsTwwH > 0; nobIvDWHaIsTwwH--) {
            KqfTFAUhDCabhIYx += pSdNcDT;
        }
    }

    if (KqfTFAUhDCabhIYx <= string("XspSONOZnuRwGbvezOeOJohcsuYvmHAJXiMSdUBKtHsqJGilfsLijAxXuLwGWYKVbzzyQJOmWYihwPLyRzfnqKGAWZgPDFdvPkZyAgusBXRNaHmgqAKfDpQxTiBdaZegyLsPXqmhGvjvlQqBnfWivzhivAmFshGkNuSqwTcBQboKARSUCzPkftXpbioCJImozjwCWTLRosRuNBemMxfNLouiRhoqiqhiidBKVOdo")) {
        for (int AmLwSbJIYR = 111967230; AmLwSbJIYR > 0; AmLwSbJIYR--) {
            uVFVWw /= mIMmTNRJuRDYMlGs;
            lfXxXoji += pSdNcDT;
            uVFVWw *= mIMmTNRJuRDYMlGs;
        }
    }

    if (lfXxXoji > string("XspSONOZnuRwGbvezOeOJohcsuYvmHAJXiMSdUBKtHsqJGilfsLijAxXuLwGWYKVbzzyQJOmWYihwPLyRzfnqKGAWZgPDFdvPkZyAgusBXRNaHmgqAKfDpQxTiBdaZegyLsPXqmhGvjvlQqBnfWivzhivAmFshGkNuSqwTcBQboKARSUCzPkftXpbioCJImozjwCWTLRosRuNBemMxfNLouiRhoqiqhiidBKVOdo")) {
        for (int mAExmazsgTtmgV = 835904885; mAExmazsgTtmgV > 0; mAExmazsgTtmgV--) {
            pSdNcDT += pSdNcDT;
        }
    }

    for (int fmEWgfFq = 626650766; fmEWgfFq > 0; fmEWgfFq--) {
        eZrcGZhac = eplEp;
    }

    for (int RnjFQncoqI = 391815553; RnjFQncoqI > 0; RnjFQncoqI--) {
        KqfTFAUhDCabhIYx += KqfTFAUhDCabhIYx;
        KqfTFAUhDCabhIYx += TXdoegjvjTxRfrF;
    }

    return mIMmTNRJuRDYMlGs;
}

double CgDexr::SoJjjepTTnZvEh()
{
    string FLJnnguDLQ = string("zQIzBjIFvCUQlIXijzavIVZlsKjVxtXSTImRojWGTyEsqsqzemgSzCJjMWZAoTNIOkZbmACNIuoXREAustSPUWYLrPqatHNLkSOm");
    string WWrIwX = string("UemqKBLBsBAcBUbqMwuNsZunqRTZvrjcdxrtQjBCEXQilkyohyAFRObOQeWdtmKYIdETPsCYANxjgmatfpeVNllqpvxoPQTKwCazTMwRRrZCX");
    bool LUPXbDOZX = false;
    bool EHRIXaSZUjmmJ = false;

    for (int vtsqpIIYgCqnHCz = 1512582779; vtsqpIIYgCqnHCz > 0; vtsqpIIYgCqnHCz--) {
        WWrIwX += FLJnnguDLQ;
        WWrIwX = FLJnnguDLQ;
        EHRIXaSZUjmmJ = EHRIXaSZUjmmJ;
        FLJnnguDLQ += WWrIwX;
    }

    for (int qxZHO = 117612718; qxZHO > 0; qxZHO--) {
        FLJnnguDLQ += FLJnnguDLQ;
    }

    for (int VuFcVwLeM = 1192060993; VuFcVwLeM > 0; VuFcVwLeM--) {
        LUPXbDOZX = LUPXbDOZX;
    }

    for (int mNpsUTxaxtI = 12298230; mNpsUTxaxtI > 0; mNpsUTxaxtI--) {
        WWrIwX += WWrIwX;
        LUPXbDOZX = ! LUPXbDOZX;
    }

    return 483355.88562229485;
}

int CgDexr::hLQALjwbA(int IqghHe)
{
    string PxemnUx = string("oXHyH");
    int SEapmWJwj = 398668060;
    bool BKmIDC = true;
    int lHAhHfKgjVuI = -1929076851;
    bool dJigyD = false;
    int twvIwhKgNhJxka = -829544810;
    bool roNIq = true;
    double lurLI = -339854.6652537752;
    string oZvnsIkRaUVmGn = string("WrmfrPECQfKgsXjTSHkVtfIoIrHsgOYxaYVhERNRJgANXPIUMzpyVbnkKLqMAtmVMTAgJYAQeCeNVkeroScYNTtASsvMTNdhmMJIEqzuAKGRWPisDPNwfjsMBxwYNdGQptKEuFjLrkjAEehOxZjsiRfzevwlTeFUKGYawhmGxyJyxYALFCJfNWIvzGpNmWpAJSwrerfPaphTcEKUNOghMdalZVHeiSDlrgeBeXtZVKfHSjUdqgXquVPPWM");

    for (int IJHzUeomMmtUTmx = 362131620; IJHzUeomMmtUTmx > 0; IJHzUeomMmtUTmx--) {
        twvIwhKgNhJxka /= lHAhHfKgjVuI;
    }

    if (twvIwhKgNhJxka < -1655869338) {
        for (int pCiuAhSoaMOIV = 1832748446; pCiuAhSoaMOIV > 0; pCiuAhSoaMOIV--) {
            IqghHe /= twvIwhKgNhJxka;
        }
    }

    for (int hbIHkpp = 603063764; hbIHkpp > 0; hbIHkpp--) {
        continue;
    }

    for (int sWFMRaDOYkGXce = 1362957219; sWFMRaDOYkGXce > 0; sWFMRaDOYkGXce--) {
        IqghHe -= IqghHe;
        IqghHe *= SEapmWJwj;
        roNIq = BKmIDC;
    }

    return twvIwhKgNhJxka;
}

string CgDexr::dtqJZgvjUIfXO(bool xwxHNAKAL, double PaodyznahHyPOhjC, string WRRWoPrJmgmX, int HeCmSBrEZfVwNO, double gNkDFafk)
{
    bool LkTapDRG = true;
    string PfOgUOYzZEbYCZw = string("xoGBahyGQovftHjLQORFEeIXrmLJHQogEQLgJJfAKFavoYOfcbgSrs");
    string ioteG = string("FdySNhjNupuGKNAhjJhaRlpNyWkOUgDGKxkaNyGytTjaofNUkxGoRUbxhIGXsXXTyLExRFETcKDUhqEwdUJEbfWAbYIRbJqpgAZXkGtZydiQEeZZayQJAJsfVHOxfOGBWHSSKORjYTPoBuNUHnhiRuRRsznOuYFYnFFmJWtJjSjnZPZJhepNSVtsodwjPOFaQoTyWSTLpkapNZjWFuoTZhKYrZKDvFhqKsWcyzKqKOMDfNBtJ");
    bool NblnpgyqW = false;

    for (int ufElTMNatlnObIj = 289985108; ufElTMNatlnObIj > 0; ufElTMNatlnObIj--) {
        LkTapDRG = ! xwxHNAKAL;
        WRRWoPrJmgmX = PfOgUOYzZEbYCZw;
    }

    return ioteG;
}

bool CgDexr::LsLdLlcEp(double qvDQDEAuNIkKQEt, bool JDKoVPZUfVbsWBX)
{
    int psjLJS = 2115428334;
    bool tzXtxfY = false;
    bool jrhGdD = false;
    string QVpzDjtQFnbmQPr = string("vuIxMfMhgERohJArNQhvgaNtNOpRHZAjujLGRPDSAQvxAhIOgOyPEPNngkOeniWcfEMUAyEpRpPsGjcAyylRIWHOuznlbNLtRcSKHviihLbaxyEQvSdSmgaRigWXtTFXICdTSeCNYTQQMbVTtFnnPAmqLzfJOaHIfdybEVKooRBusC");
    bool rrnBRIuR = true;
    double bsiDbloOYtdeMac = 317651.8785048888;

    for (int YvvTHOtJBoPLAal = 1377138691; YvvTHOtJBoPLAal > 0; YvvTHOtJBoPLAal--) {
        continue;
    }

    for (int GlLcpcq = 317749771; GlLcpcq > 0; GlLcpcq--) {
        jrhGdD = rrnBRIuR;
        tzXtxfY = jrhGdD;
    }

    for (int xRvXNZKIio = 693637673; xRvXNZKIio > 0; xRvXNZKIio--) {
        continue;
    }

    if (rrnBRIuR == true) {
        for (int wigcie = 1877209285; wigcie > 0; wigcie--) {
            bsiDbloOYtdeMac /= bsiDbloOYtdeMac;
        }
    }

    for (int YoFGBzLeGfZnDd = 1676901539; YoFGBzLeGfZnDd > 0; YoFGBzLeGfZnDd--) {
        tzXtxfY = ! JDKoVPZUfVbsWBX;
    }

    for (int KxlCgM = 499390090; KxlCgM > 0; KxlCgM--) {
        bsiDbloOYtdeMac = qvDQDEAuNIkKQEt;
        QVpzDjtQFnbmQPr += QVpzDjtQFnbmQPr;
    }

    return rrnBRIuR;
}

bool CgDexr::cnHbIEex(bool QonKeUx, int bijXlRow, double bIvfZpzrdXxgtMO)
{
    int BsrMkBAONDrh = 480079974;
    bool xZgvdalBiLPNEV = true;

    for (int fZCztHFqsHkdPCvD = 376061551; fZCztHFqsHkdPCvD > 0; fZCztHFqsHkdPCvD--) {
        bijXlRow -= bijXlRow;
    }

    return xZgvdalBiLPNEV;
}

void CgDexr::qKYMT(double LfSyWnMz, int iVfdEfiyS, bool iKjNgEHfL, string TLARqZXELQHBeRK, double HOghmgKjTAJ)
{
    double rmKupxu = -598313.8067864726;
    double aXMtHiPZSuyGxNy = 984666.3492484624;
    double nNoPMKLsCMTHnEW = 326386.2696438954;
    bool AaZTi = true;
    double vkKJngByb = 224729.5654780763;
    string nscdwHLPIbKPQv = string("EqxhrRwEcSeTLTsTlYJcEGVUzJxoMMnUrYeMaToTTxSJqNCENpiFAdZUKXyrdyMRHnsMzEkZgkqBFqXMRjaRzdWhYWtHLibJzPsHQvmkMKzXaSILdteFNtVROVOXGrxMrqesSMNerhLPtmMmDcFqStFUBkN");
    int QvLHKmeLxzLoKq = 1225462045;
    double fCEcvqun = 796632.9484442952;

    for (int pWzFXseGAs = 812468178; pWzFXseGAs > 0; pWzFXseGAs--) {
        fCEcvqun += aXMtHiPZSuyGxNy;
        nNoPMKLsCMTHnEW -= vkKJngByb;
        QvLHKmeLxzLoKq /= QvLHKmeLxzLoKq;
    }

    for (int hPouTYlEh = 1928385469; hPouTYlEh > 0; hPouTYlEh--) {
        nNoPMKLsCMTHnEW -= HOghmgKjTAJ;
        HOghmgKjTAJ += nNoPMKLsCMTHnEW;
        HOghmgKjTAJ -= fCEcvqun;
    }

    for (int AaJVWRwzFGi = 1973125177; AaJVWRwzFGi > 0; AaJVWRwzFGi--) {
        rmKupxu += vkKJngByb;
    }

    for (int VIJcILXB = 672176809; VIJcILXB > 0; VIJcILXB--) {
        vkKJngByb += vkKJngByb;
        fCEcvqun -= HOghmgKjTAJ;
        vkKJngByb += rmKupxu;
        vkKJngByb *= nNoPMKLsCMTHnEW;
    }
}

CgDexr::CgDexr()
{
    this->DbgMuJThxQs(133397.78426356407, -458351.4765258888, 1351706034);
    this->iQlrTTIaYtIp(-511553.5765149273, false, false, 195628.8858834374);
    this->HvyAliwVh();
    this->rlmrWsBtAkw(-755686.365944569, 1220096812);
    this->ootcfSSO(-1633898353, -363400.62814128754, true, string("BnSDaPNGiccpMtkRdeFYjqHuPTUgIJCRZscPNlFBZAbkEhQQdiKJrQLyOmzxUrpwHdgDTBJLlzdmkkPloHcrJCSpVYHjvXkdopVJuFntxSFVahlNyjJUPcJoljxssetLefuElsUvJvCgAsRGMRuQayNATPBgFBgOYFHklzzYtRpbkZnyvevRzlLbffcMBcypFBBbNQhHBbzWTYYCxPPINYs"), -712834.0962563838);
    this->tyKDFAIVirFcm(-394694567);
    this->WjUfhC(-1337051204, string("KSzyaXEpBEvbTMuWNVKtvFZDEjbuCikOWeGnNoLpAxnsSYxKzmnDeGzpDRLPzxyOPBRBoRbmmWxqFzMFnTXSoAfdvvnbrvtzfdRuvRqMvAfhxaLIQWYIAMeRugDKkylM"), string("ZzuwmwGQDtvzTlfDvstazzQxwSHLaPHlgnDODdmyQDhyhtuvUVTrkuCcPtalJGoyexqXbSZdGwzvKeDiKtlKbDnLZZjXIpoFcvmteFNsFW"));
    this->jRbSBcQZDFD(false);
    this->hDQVGOANV(829849.190031939, false);
    this->kxTnK(true, 665094167);
    this->FDwwoNTAsSYaQ(791537.1348376551);
    this->XFLBjvYZg(false, string("YHQKMXu"), false, -1576902164);
    this->SoJjjepTTnZvEh();
    this->hLQALjwbA(-1655869338);
    this->dtqJZgvjUIfXO(true, 725414.652579306, string("FLSnpqYLKXnXXdSBpuCqoFKQUnuzXMgsLiFgDcyNZbeGZXLKZrCoXZZGBopwypLWjGaVpapkrgSGniwxpcVzDmNXTROZiFXDPIVtYWONEkwpwKmYredysTABCMCfGcWrVDGuidBVhCWXUvoxMJsFZdSLHMoNPcgvwUBbqZGqiJbhFkHuuWAaxUOysSVrMmMBQNirRoEEJoTzGDMaNDWGNOHmXuPstAdPZHjzkWeNFnKEuThyDnvghSEbWsle"), 1132933818, 298992.6396876579);
    this->LsLdLlcEp(675639.8593220229, true);
    this->cnHbIEex(true, 706102894, -110789.04290327118);
    this->qKYMT(-477741.44230371446, 2060647127, false, string("UuytAcfwiHoKcQaIeWXMoZsFCKPIAPNRMoghTisyXcsDnvIVltmlNRMqMKfRFpFCBtpKUTaPhtjcb"), -844278.3224291698);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nslAXyqymNacR
{
public:
    double OzvcBjqW;

    nslAXyqymNacR();
    string dGnoiME(bool HjVPoAwxFTblr, double NzAyVCHAdz, string IMVsomsaNLtDLuJ, double GDqhqlAJIVfXFy);
    void xEggtXNUi(string JNuDzUemvDy, int KhYnX);
    void PBnyUtWzlcsClhn();
    int VzyzEolrsEKA(bool MLBThQEL, int ZBoYiP, int McqisWBDPXJv, string QrGMTIaRexnxG);
protected:
    bool kEgMNBrpFay;
    double MtZZHv;
    bool WICCwdhPOFkMUat;
    bool bpeGjdbh;
    string fQfljVYv;
    double yaZieehoZCHc;

    void gkqUakGcQEMhTG(bool hEalwYSCObZlM, bool rZXJAeQyUV, int sBZoMVQfSsrdL, string LEaqXfetkypSa);
    void EoZymbeV();
    string GklmzOUGxLqZa(string OGglehyls);
    void vAUUq(string IZCNjDGbtqdHKP, string nJRFTuNSRpAtJ);
private:
    int CwYBaqPrtXbP;
    double qAbLI;
    int YjlpvHIThEwemnYz;
    bool BzLGC;

    int ESrzfeSWqK();
};

string nslAXyqymNacR::dGnoiME(bool HjVPoAwxFTblr, double NzAyVCHAdz, string IMVsomsaNLtDLuJ, double GDqhqlAJIVfXFy)
{
    double WrbZxAOuawLJAGo = 378170.5578874853;
    double vwNLSMEOq = 61281.15878009748;
    int kdPuOjeU = -494014332;
    bool JmYQbHJUh = true;

    if (NzAyVCHAdz > 61281.15878009748) {
        for (int jsBBQWNItdYVb = 1139103887; jsBBQWNItdYVb > 0; jsBBQWNItdYVb--) {
            continue;
        }
    }

    return IMVsomsaNLtDLuJ;
}

void nslAXyqymNacR::xEggtXNUi(string JNuDzUemvDy, int KhYnX)
{
    double NaycWIFr = 229604.81550865615;
    bool TOxtwXiYzzY = true;
    bool KJaRnJVyGeAqn = true;

    for (int asviNWlAXm = 1332701070; asviNWlAXm > 0; asviNWlAXm--) {
        NaycWIFr *= NaycWIFr;
        TOxtwXiYzzY = TOxtwXiYzzY;
        KhYnX = KhYnX;
    }

    for (int ERXluM = 1057621514; ERXluM > 0; ERXluM--) {
        TOxtwXiYzzY = KJaRnJVyGeAqn;
        KJaRnJVyGeAqn = TOxtwXiYzzY;
        TOxtwXiYzzY = TOxtwXiYzzY;
    }

    if (KhYnX == -1412002454) {
        for (int VUVCMHAhBg = 1427076256; VUVCMHAhBg > 0; VUVCMHAhBg--) {
            JNuDzUemvDy = JNuDzUemvDy;
        }
    }
}

void nslAXyqymNacR::PBnyUtWzlcsClhn()
{
    bool yiyNXyhzbnVL = true;
    string mrSIcac = string("iBnhxsmBTqNGyejVIXgZPmDnUnXgqlkdzOfUeykdmFBzXJawvayYqiDmdubxvYoGGpuqdbOjXTFJSxjPyOyMHWBREtQMMYFGUzIaFVSNdNdvRZOsLgARHgGebvZjWAVlHglYGfiFWuAlgDEKpUZoqNSwBCvdOsjRgBbiVarvLrJgdEaTuUxGrvBpESYsWKENH");
    int pOkcUqPQsXpy = 836922250;
    double kJokxEGjRgIdF = 770979.2029522643;
    int XmPThcsGBclOi = -1943221637;
    bool eYdhdVLTaQPS = true;
    int iabQfi = -1471498064;
    double KyvhlpZ = 763576.4644468236;
    double AYexaxdbbYJE = 963993.825915631;

    if (pOkcUqPQsXpy != -1943221637) {
        for (int CEGifABHNJ = 1840249127; CEGifABHNJ > 0; CEGifABHNJ--) {
            XmPThcsGBclOi = iabQfi;
            XmPThcsGBclOi -= XmPThcsGBclOi;
            AYexaxdbbYJE *= AYexaxdbbYJE;
        }
    }
}

int nslAXyqymNacR::VzyzEolrsEKA(bool MLBThQEL, int ZBoYiP, int McqisWBDPXJv, string QrGMTIaRexnxG)
{
    bool MFQkIkErutaJaB = true;
    string jBipqSZyidrItDWk = string("KybdhwMpRxdxRFylhMdYdzCTnyjzPnHZKPHGULcKhczHKKstyzooduQkzUhynyxgrArMKlhxgRPIZLIvkmKBkEdPhOmtTxausMXlMseLWpXcQKUTqLMrvlnrdSMCLO");
    int TommXsGv = -422212282;
    double FflxWJ = -1032801.2856014185;
    int OAZFlaulIyO = 229087383;

    for (int FKHpNBQeTOQsrHj = 1914618821; FKHpNBQeTOQsrHj > 0; FKHpNBQeTOQsrHj--) {
        MLBThQEL = MFQkIkErutaJaB;
        OAZFlaulIyO *= OAZFlaulIyO;
    }

    for (int QkSmib = 790531122; QkSmib > 0; QkSmib--) {
        McqisWBDPXJv *= TommXsGv;
    }

    for (int lygYJLiXtRt = 930947514; lygYJLiXtRt > 0; lygYJLiXtRt--) {
        ZBoYiP += OAZFlaulIyO;
        McqisWBDPXJv += McqisWBDPXJv;
    }

    return OAZFlaulIyO;
}

void nslAXyqymNacR::gkqUakGcQEMhTG(bool hEalwYSCObZlM, bool rZXJAeQyUV, int sBZoMVQfSsrdL, string LEaqXfetkypSa)
{
    bool uJcjlMD = false;
    bool PDkVetTSOQhKFTP = true;
    bool nNibDjL = false;

    if (rZXJAeQyUV == false) {
        for (int ksllpPGClSj = 2042943934; ksllpPGClSj > 0; ksllpPGClSj--) {
            hEalwYSCObZlM = ! nNibDjL;
            nNibDjL = hEalwYSCObZlM;
            hEalwYSCObZlM = uJcjlMD;
            nNibDjL = nNibDjL;
            hEalwYSCObZlM = rZXJAeQyUV;
            rZXJAeQyUV = ! hEalwYSCObZlM;
        }
    }

    if (rZXJAeQyUV != true) {
        for (int KoXnof = 592451015; KoXnof > 0; KoXnof--) {
            nNibDjL = nNibDjL;
            nNibDjL = ! PDkVetTSOQhKFTP;
            nNibDjL = uJcjlMD;
            rZXJAeQyUV = ! PDkVetTSOQhKFTP;
        }
    }

    if (rZXJAeQyUV != true) {
        for (int SInFPcJfB = 555951260; SInFPcJfB > 0; SInFPcJfB--) {
            LEaqXfetkypSa += LEaqXfetkypSa;
            sBZoMVQfSsrdL /= sBZoMVQfSsrdL;
            hEalwYSCObZlM = ! PDkVetTSOQhKFTP;
            PDkVetTSOQhKFTP = ! hEalwYSCObZlM;
            LEaqXfetkypSa += LEaqXfetkypSa;
        }
    }

    for (int owLfAqDOfqsVm = 655574760; owLfAqDOfqsVm > 0; owLfAqDOfqsVm--) {
        PDkVetTSOQhKFTP = PDkVetTSOQhKFTP;
        PDkVetTSOQhKFTP = nNibDjL;
        uJcjlMD = ! uJcjlMD;
    }
}

void nslAXyqymNacR::EoZymbeV()
{
    bool eNxkzndRR = false;
    bool xVcDClzybfXb = false;
    double djAAtoraQ = -932825.5087940535;
    bool EoOeHv = true;
    double frtcoDeg = -672105.8529548171;
    double ZKLoRqdURMfwUq = 483741.6218089261;
    string auPyHnbWD = string("zbsWSRwiMbnGDJRPgBzxaHodIdUgfzazgASSihjsIQVRbFklWSImRheFeRTFMBERljCoiTAfTryacjGyXEwRtJroPmdUFq");
    string WrYoeaqCLuMdxjy = string("cGHkFzmxHA");
    int TwpncqCUdw = -799008572;
    int xvOJDcDpFWIu = 385785987;
}

string nslAXyqymNacR::GklmzOUGxLqZa(string OGglehyls)
{
    int yOEQXd = -886255567;

    if (yOEQXd >= -886255567) {
        for (int bCEcbQuY = 491391987; bCEcbQuY > 0; bCEcbQuY--) {
            OGglehyls += OGglehyls;
            OGglehyls += OGglehyls;
            OGglehyls = OGglehyls;
            yOEQXd -= yOEQXd;
            OGglehyls += OGglehyls;
        }
    }

    for (int CrkVMKPbqAdyEdy = 1303362918; CrkVMKPbqAdyEdy > 0; CrkVMKPbqAdyEdy--) {
        OGglehyls = OGglehyls;
    }

    return OGglehyls;
}

void nslAXyqymNacR::vAUUq(string IZCNjDGbtqdHKP, string nJRFTuNSRpAtJ)
{
    bool ErwfHEFWQUaViq = true;
    int xtiFoVaESzvDfg = 710064218;
    bool RWniVD = true;
    double UrnIeVNkOSqifT = 899982.8485870868;
    bool BuiSnrMeER = true;
    bool rebcR = false;
    double VqSrqVH = 927929.6221915703;
    string qbfuixbqYYdwmRSl = string("VbKwcLuUEhCBDWvwdskrzCUNXfIZcRPhCowYJoyJDcJhzECeqblYOyOUGteivcMrIafqZCCCdMbeIpWRqkWPHjDaDTsTycNzaOUNJKSeLnYqbOSHsPSljOXreAouxobzzINvGfETQwikXbdHSXaqaqHFmBYiOteLWRrLAOnKiuZYXGGRzTPBrbsuOtEKmcXACobPVLW");
    string IioTFvtC = string("umIiXpAFrxyRdTG");
    string MyJboPdwdOrBETL = string("eLI");

    for (int OuFvtKfcB = 1506836430; OuFvtKfcB > 0; OuFvtKfcB--) {
        rebcR = RWniVD;
        IZCNjDGbtqdHKP = MyJboPdwdOrBETL;
    }

    for (int NwAPNyd = 1580862756; NwAPNyd > 0; NwAPNyd--) {
        continue;
    }

    if (IioTFvtC == string("eLI")) {
        for (int kGjkOaqkOYoKlPt = 1142436396; kGjkOaqkOYoKlPt > 0; kGjkOaqkOYoKlPt--) {
            IioTFvtC += MyJboPdwdOrBETL;
            BuiSnrMeER = rebcR;
        }
    }

    for (int gDiHYqLBquTA = 815174853; gDiHYqLBquTA > 0; gDiHYqLBquTA--) {
        MyJboPdwdOrBETL = qbfuixbqYYdwmRSl;
        nJRFTuNSRpAtJ += IioTFvtC;
    }

    for (int yKnhYQRIX = 931148458; yKnhYQRIX > 0; yKnhYQRIX--) {
        continue;
    }
}

int nslAXyqymNacR::ESrzfeSWqK()
{
    string AssxgX = string("hSXrvwwakaHntQqFpJawfGydiypLAsqDUJRzLyDoTuoBCZhrXKdOvPUtcfslCMTLpiIWbQrGA");
    string ffggnbRtpt = string("nIvmcotMZuRWzoCPayfpUsITDgLJReCaFFaiiamuPjimfDqjByFFWoZtIRLKUusJsZQcGtYWA");
    int lLFFjUVKkP = -1005743544;
    string bLdzzNIio = string("yzaiwLLGimvCZzGBJdUsOViFmIHtmdSyCgrecbGxtphLVHOwQjzSAzPpLsUPlfwvNdFxLYYFzgrqGRxwtTvfrv");

    for (int CLumUCSA = 155795063; CLumUCSA > 0; CLumUCSA--) {
        bLdzzNIio = AssxgX;
        ffggnbRtpt += ffggnbRtpt;
        AssxgX = AssxgX;
    }

    if (ffggnbRtpt != string("hSXrvwwakaHntQqFpJawfGydiypLAsqDUJRzLyDoTuoBCZhrXKdOvPUtcfslCMTLpiIWbQrGA")) {
        for (int ZNosYIh = 113644422; ZNosYIh > 0; ZNosYIh--) {
            ffggnbRtpt += AssxgX;
            AssxgX = AssxgX;
            AssxgX = ffggnbRtpt;
            AssxgX += AssxgX;
            bLdzzNIio += AssxgX;
        }
    }

    if (ffggnbRtpt != string("yzaiwLLGimvCZzGBJdUsOViFmIHtmdSyCgrecbGxtphLVHOwQjzSAzPpLsUPlfwvNdFxLYYFzgrqGRxwtTvfrv")) {
        for (int KHpOgBeLTombjezq = 873292969; KHpOgBeLTombjezq > 0; KHpOgBeLTombjezq--) {
            AssxgX = AssxgX;
            AssxgX += ffggnbRtpt;
        }
    }

    return lLFFjUVKkP;
}

nslAXyqymNacR::nslAXyqymNacR()
{
    this->dGnoiME(false, 540391.2128490682, string("MAZWOIvcwfNhyRRqOrKLaPlfNIgPIRxjxDDiDMacShrRoqAHpXOtQqJMbGizQvbwrHiTbqPiYaQwYeBbHLCJIWmKpCNIqElRFgxfFmOgdsKZlslrrkACNQzEZvvRivdnAIEPLjqrugdGylpHCUrtcYrFItgsTnJJdQygZfaIxzmlZNJaFiLIokFDMKsfWOhfRnHKPJqy"), 443052.4238143602);
    this->xEggtXNUi(string("OebofbGIBJZMRvuyAZjPgCCKfJCVkupFTnsDVNhrGZSfYThCRVSlTOtnwqOtZEbgljXPhxDqucajvfexUMqWPDuGyWUQaJvCzPTTcLFhMpsJbGJpmMLbliYMHoPYesll"), -1412002454);
    this->PBnyUtWzlcsClhn();
    this->VzyzEolrsEKA(false, -941107213, 716246197, string("DOFNtOVZPYNTUKNZGBNrKhtEiAPGaIcbNoDorymvyBgZNHWqGJljakDrbyeIjkDySZQpypwrtRJMwNYisucypgzsI"));
    this->gkqUakGcQEMhTG(true, true, 1254579571, string("baymotmpCPmrpSQVQLFVHbUqdgDQDZyiJSeSPprzIlGaVnjcMtYpgkruUWH"));
    this->EoZymbeV();
    this->GklmzOUGxLqZa(string("EqUicRDLCrMTsoSNdqVGrxzriTsn"));
    this->vAUUq(string("UwCwgzJIlnqJUXytHLqyjFrvQEdhuhqhKcCqVZzWfWfaoRLypCRBzgqLDbVbCOcignRhLwpttZQwOsqqvQUFKyRaNpVXtXgJbuyeJXFxumSUhaNgvrBWFEwohEGOFRMPrPeaqVHBQQJzruLvalbVQKJbTNARRXGmDaktSeUoMwFRHpFJvWQhoNUMLyVwfPlOlYsJRd"), string("GPcoisdAsIACNaCacmHZGIEamLnWRfZfESyENNhpuxVqxoWRTEGQqZHShWqCvogwXPXDVXgtLosaSpZqAnpmkwKATSZjCTzuUtljbNuvSKYkuKELBiLZTXelYZNnFUrrMmqQXyKNECQWrbDXpCBrFnhDEUrRjRAwjHaMvhKiWORcxflvdh"));
    this->ESrzfeSWqK();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qEIUw
{
public:
    string FzmsCmmeuSMlsWld;
    string MOMFuJKYDKG;
    int EdfhLuieYBhiWlHK;

    qEIUw();
    double ygvEmc(int CUVNsAdSBVUbQuE, bool XRxFYGWWttwKe, int ANrsXWtKx, string CIEqqQnZwavslv);
    int EvwtmhSOGvL(double UCzvAvNWMnMUW, bool DRlcLCap);
    string thyugt(double VHmNBfSupiJiGX, double HAeaJXI);
    double dsMNAKuTXC(double NhtErTIciV, bool LXTAkvSNUnoxsOV, int FZFTfTGD);
    void KLgnmXrzsq(string GGbiLJYJqutxmu, string xxVyRVRtAqgLoi, bool jHFGJQzEqm);
    void BcyxCAvSkMA(int JRtOChHJ);
    bool dECLJCTVo(int xmYRGpRh, double HcesomSZllahyTaB, int ojHyaBzKfiBfQvK);
protected:
    int hyCLiYp;
    double XKSxJXgOUjPyesf;
    int rTsQqVH;
    string trmlBY;

    bool ccwOewf(double lZjQhXMpQ, double JxsZTqapzJBGbpH, string hqPWIXZYu, string VJqntvAMSUTPeVJ);
    bool Tmvmr(string yhjdbyLHmBVkHMpj, bool Nzflw, int togjQWdkVXS);
    void DgAnbBJjO(bool nEiNjRZJPcH, string vVupfpkZk);
    string UuwnhCcqjD(string GDsUqfYarCdMcfJS);
    double nLBTw(string yHvzNaNpImx, bool gQJcBYX);
    double DSzpzzngtq(string HNnpZIU, string OIrWmG, int kRekjCXC);
private:
    double CVVjYkPlEdnC;

    bool PbohCktbTe(string butxmzwrYxldsXA, int qywdMGKdrCVOa, double lkfQDIIRwUkBVjj, string rdyCJicMQ, bool xRCmfkWfWzCYwlLC);
    int odQdgyD(bool hvTDtCN, double qSelZfv);
    string JIPMVorslqNejkVc(int FjqApTX, int qLYXftMxeklArVP, string kgQifDYaXJ, string JIfzApeHyB);
};

double qEIUw::ygvEmc(int CUVNsAdSBVUbQuE, bool XRxFYGWWttwKe, int ANrsXWtKx, string CIEqqQnZwavslv)
{
    int rCNeLjQqXOdvON = 118388909;
    string aoqQVvRHRKiVq = string("gnpZVMcfLbDhs");
    bool JQNfojvEirjy = true;
    string utjTFIoy = string("JSuofLXQdzHOjYOnHqVIyiwTgMHOcXYbXriDNNfhWPPwyHTTBJaTmX");
    string NdrKCuLuM = string("aIOLZQIcuWgbiCOSpxRlkNdiGVJnumjgIQgnrPiOfFwtpibzszEcyRfehgLsXGAveDMGfePmudlhUhWjSQ");
    int pTEjVSUAhoi = 1468232295;
    int XaKlbki = 939789243;

    for (int TvWhe = 1643106206; TvWhe > 0; TvWhe--) {
        CUVNsAdSBVUbQuE += XaKlbki;
    }

    for (int HWJlzd = 759002134; HWJlzd > 0; HWJlzd--) {
        ANrsXWtKx *= rCNeLjQqXOdvON;
        NdrKCuLuM = utjTFIoy;
    }

    return -569412.1445451924;
}

int qEIUw::EvwtmhSOGvL(double UCzvAvNWMnMUW, bool DRlcLCap)
{
    string MggwlnFcVlBtuDu = string("IEZahVfJLCEYqqrypWMXGvdHqVXcBbfASjtuymraCBSGZFXDRfDyBzWpOx");
    bool fnUunqHdff = true;
    string gfCBTgbIXziv = string("FLnWUWdYXTKmIKXWlMMbIKJRdTVSQWenxkEjwYzjvxkYAZsNGDnpMRXkoKzrnZwulPYO");
    bool UIFAFBBApIxn = true;
    bool SyIMO = false;

    if (MggwlnFcVlBtuDu >= string("FLnWUWdYXTKmIKXWlMMbIKJRdTVSQWenxkEjwYzjvxkYAZsNGDnpMRXkoKzrnZwulPYO")) {
        for (int FSgSdWtcf = 559089615; FSgSdWtcf > 0; FSgSdWtcf--) {
            fnUunqHdff = ! UIFAFBBApIxn;
            SyIMO = ! SyIMO;
        }
    }

    if (fnUunqHdff != false) {
        for (int hZaRRDLiGN = 1881944114; hZaRRDLiGN > 0; hZaRRDLiGN--) {
            fnUunqHdff = DRlcLCap;
            SyIMO = ! fnUunqHdff;
            fnUunqHdff = SyIMO;
        }
    }

    for (int FuZqqpSRFVZRAo = 277787405; FuZqqpSRFVZRAo > 0; FuZqqpSRFVZRAo--) {
        DRlcLCap = SyIMO;
        fnUunqHdff = SyIMO;
    }

    for (int fHAjHJH = 847075731; fHAjHJH > 0; fHAjHJH--) {
        fnUunqHdff = SyIMO;
        gfCBTgbIXziv = gfCBTgbIXziv;
    }

    for (int WMJjHoxnnSuStgyq = 2071344937; WMJjHoxnnSuStgyq > 0; WMJjHoxnnSuStgyq--) {
        UIFAFBBApIxn = DRlcLCap;
        MggwlnFcVlBtuDu = MggwlnFcVlBtuDu;
        MggwlnFcVlBtuDu += gfCBTgbIXziv;
        UCzvAvNWMnMUW = UCzvAvNWMnMUW;
    }

    return -1188329303;
}

string qEIUw::thyugt(double VHmNBfSupiJiGX, double HAeaJXI)
{
    double ZZOOAggB = -340621.50365082483;
    double wPClXnLHndw = -145153.35581806026;
    bool wrLGCaRwCdvSimgJ = true;
    int gznXJS = -46544304;
    double GDvZTXKx = 686831.9834905061;
    double SoLRFJQLiLsgWjR = 437262.8677428512;
    double HKRTvMcVD = 442867.6321567792;
    bool rfsHGr = false;
    bool zEcChD = true;

    if (HKRTvMcVD > 686831.9834905061) {
        for (int vFMjxWlD = 1387349802; vFMjxWlD > 0; vFMjxWlD--) {
            SoLRFJQLiLsgWjR /= ZZOOAggB;
            GDvZTXKx = GDvZTXKx;
        }
    }

    for (int tGkjzCcKY = 371782710; tGkjzCcKY > 0; tGkjzCcKY--) {
        zEcChD = ! wrLGCaRwCdvSimgJ;
        zEcChD = ! zEcChD;
        VHmNBfSupiJiGX /= GDvZTXKx;
    }

    for (int Bhxtwbzv = 666168189; Bhxtwbzv > 0; Bhxtwbzv--) {
        SoLRFJQLiLsgWjR *= VHmNBfSupiJiGX;
        GDvZTXKx /= wPClXnLHndw;
        HKRTvMcVD += SoLRFJQLiLsgWjR;
    }

    if (zEcChD != true) {
        for (int tdalpTVLsszLA = 497063120; tdalpTVLsszLA > 0; tdalpTVLsszLA--) {
            SoLRFJQLiLsgWjR = HKRTvMcVD;
            wrLGCaRwCdvSimgJ = rfsHGr;
        }
    }

    for (int rwomxtduFhgcKD = 1098817164; rwomxtduFhgcKD > 0; rwomxtduFhgcKD--) {
        ZZOOAggB *= VHmNBfSupiJiGX;
    }

    return string("gPzqnRSUMqNgOOQUzNRfEA");
}

double qEIUw::dsMNAKuTXC(double NhtErTIciV, bool LXTAkvSNUnoxsOV, int FZFTfTGD)
{
    double ycKvWUXVam = -468862.641245833;

    for (int mZDDlPiz = 1741200228; mZDDlPiz > 0; mZDDlPiz--) {
        FZFTfTGD /= FZFTfTGD;
    }

    if (ycKvWUXVam >= -468862.641245833) {
        for (int KdezJq = 863631823; KdezJq > 0; KdezJq--) {
            ycKvWUXVam *= NhtErTIciV;
            FZFTfTGD *= FZFTfTGD;
        }
    }

    if (FZFTfTGD <= 170513376) {
        for (int Tzphc = 2131304052; Tzphc > 0; Tzphc--) {
            ycKvWUXVam /= ycKvWUXVam;
            FZFTfTGD /= FZFTfTGD;
            NhtErTIciV *= NhtErTIciV;
            NhtErTIciV -= NhtErTIciV;
        }
    }

    for (int ukfMpcAtGmbvud = 2018026408; ukfMpcAtGmbvud > 0; ukfMpcAtGmbvud--) {
        NhtErTIciV = ycKvWUXVam;
        NhtErTIciV += NhtErTIciV;
        LXTAkvSNUnoxsOV = LXTAkvSNUnoxsOV;
    }

    if (LXTAkvSNUnoxsOV != false) {
        for (int veEtxQMvKPEi = 194889194; veEtxQMvKPEi > 0; veEtxQMvKPEi--) {
            NhtErTIciV -= NhtErTIciV;
            LXTAkvSNUnoxsOV = LXTAkvSNUnoxsOV;
            ycKvWUXVam += NhtErTIciV;
            LXTAkvSNUnoxsOV = ! LXTAkvSNUnoxsOV;
            NhtErTIciV = ycKvWUXVam;
            NhtErTIciV += NhtErTIciV;
            ycKvWUXVam += ycKvWUXVam;
        }
    }

    return ycKvWUXVam;
}

void qEIUw::KLgnmXrzsq(string GGbiLJYJqutxmu, string xxVyRVRtAqgLoi, bool jHFGJQzEqm)
{
    int xTVIHUzKOuwen = -1498512305;
    double zjfsIBZ = 770427.8857796903;
    double nPDOIhQW = 200765.42727324596;
    bool JnTHJwqcMrQQZ = true;
    int mJsWpggVPEjdmjQ = 1186827100;
    int MLGsLFvigaH = -1419055646;

    for (int OFPYTm = 638549411; OFPYTm > 0; OFPYTm--) {
        xTVIHUzKOuwen /= xTVIHUzKOuwen;
    }

    if (mJsWpggVPEjdmjQ < -1419055646) {
        for (int mOOahbihWLBti = 1023655654; mOOahbihWLBti > 0; mOOahbihWLBti--) {
            xxVyRVRtAqgLoi = xxVyRVRtAqgLoi;
            MLGsLFvigaH = xTVIHUzKOuwen;
            JnTHJwqcMrQQZ = ! jHFGJQzEqm;
        }
    }
}

void qEIUw::BcyxCAvSkMA(int JRtOChHJ)
{
    int wKKILFwbFNYwk = -1648847066;
    int LiYAPodtfvkdvrN = -1935896939;
    int zaAudLRrMEDJF = 121245826;

    if (JRtOChHJ <= -1648847066) {
        for (int ilyFCerUUDglhom = 259467075; ilyFCerUUDglhom > 0; ilyFCerUUDglhom--) {
            LiYAPodtfvkdvrN += JRtOChHJ;
            wKKILFwbFNYwk = JRtOChHJ;
            wKKILFwbFNYwk /= JRtOChHJ;
            wKKILFwbFNYwk = zaAudLRrMEDJF;
            zaAudLRrMEDJF *= JRtOChHJ;
        }
    }

    if (JRtOChHJ > -1648847066) {
        for (int ZuFfSUDvnpK = 1646854895; ZuFfSUDvnpK > 0; ZuFfSUDvnpK--) {
            zaAudLRrMEDJF *= wKKILFwbFNYwk;
            LiYAPodtfvkdvrN *= zaAudLRrMEDJF;
            LiYAPodtfvkdvrN = zaAudLRrMEDJF;
            LiYAPodtfvkdvrN *= zaAudLRrMEDJF;
            wKKILFwbFNYwk /= zaAudLRrMEDJF;
            JRtOChHJ += JRtOChHJ;
        }
    }

    if (zaAudLRrMEDJF >= -1157420415) {
        for (int OpMZxpKc = 723773213; OpMZxpKc > 0; OpMZxpKc--) {
            wKKILFwbFNYwk += JRtOChHJ;
            LiYAPodtfvkdvrN += zaAudLRrMEDJF;
            JRtOChHJ *= JRtOChHJ;
            zaAudLRrMEDJF = zaAudLRrMEDJF;
            wKKILFwbFNYwk += LiYAPodtfvkdvrN;
            LiYAPodtfvkdvrN = JRtOChHJ;
        }
    }

    if (zaAudLRrMEDJF <= -1157420415) {
        for (int ExJdb = 1896147149; ExJdb > 0; ExJdb--) {
            wKKILFwbFNYwk += zaAudLRrMEDJF;
            JRtOChHJ -= LiYAPodtfvkdvrN;
            JRtOChHJ -= JRtOChHJ;
            JRtOChHJ -= zaAudLRrMEDJF;
            wKKILFwbFNYwk = wKKILFwbFNYwk;
            zaAudLRrMEDJF *= LiYAPodtfvkdvrN;
        }
    }
}

bool qEIUw::dECLJCTVo(int xmYRGpRh, double HcesomSZllahyTaB, int ojHyaBzKfiBfQvK)
{
    string HaDFQKV = string("ZrrakPwrAgDcrqiVuzrH");
    bool iTVUUabPzhcL = false;
    string MWqmcWeRVOUR = string("tvOfLFxRhDPldfDdfGosehEBvvlbDwQZGkjjAuLmWGGdIKgpSAzgSrNDViMddzMGfHSOePLQbmZFQrZqPTWgzuKUFbgCHEKhIQJXLwWVRHOnduZJuSVdWtXaAaGopOTBsbscDyohVAvtILlsVyZjbNDRHCCmDBQZHuAwxCzJWbNnAeVaqnXPFUVbPYcdVfgAtQUPZXYGwgujMYzwJaRXJyGUiOjzbWeiwZhnYbpTPCSNgCihfCArKVOEoNlN");
    int ZwnGAZ = 282368264;

    return iTVUUabPzhcL;
}

bool qEIUw::ccwOewf(double lZjQhXMpQ, double JxsZTqapzJBGbpH, string hqPWIXZYu, string VJqntvAMSUTPeVJ)
{
    bool eVOGKDWF = true;
    int qUcOS = 1083313832;
    string CxtCbpuLaNsShHig = string("juExWUOCPltRcjlKRhxicSeWADgphVjLqGfSKkkvCfuDxLzKdKneholwULOPZMPFHwOuCqxkDlodzBJFEgJNiGRVyaBjXIBsPrnIADlycDoytIUWHDiuWSBvhYhnPtLMKTIhGyPaEuWYZcqaOVqosqcPcuNkWiLXxDLjJvNfmzkQCEnWiWQyFHkYpYAsWhYDVCQISOJUjccYgTYsSlIuSfxmlwmhzSWufuhXawELZUSjFwjSlkP");
    int WhNoYBSfHBE = 49322011;
    double jZGuTAZRPZAHze = 537612.772498915;
    string vxbVhseOR = string("KvJQxUjZARQseLapRmsALkXqdNPJEgPDUpFVIwzERpQrEdbPdbegAUSfwbRaqrQwqQZbJLZMaBQkXPPXbyYTIufCRZZKeiPVtVHGJtFMhovRPVqjjUdkRkkogXlyYZHbhzVZVBYGZSGjUlwwvuIkctzyinHdgHHyBDREBAcSfItAtKDhyrFlQDIlzmcZiRzDAwVWCEDFJdPUWMyJQMKSHVUbppHEGZYbsupCjlSnuPwbv");
    int CmdyWhxp = -1117321214;

    for (int XHWpsN = 1266121551; XHWpsN > 0; XHWpsN--) {
        qUcOS -= CmdyWhxp;
    }

    for (int IsvmCOgT = 341078196; IsvmCOgT > 0; IsvmCOgT--) {
        CmdyWhxp /= qUcOS;
        qUcOS -= qUcOS;
        hqPWIXZYu += hqPWIXZYu;
    }

    for (int PGiwzhKrsWCLCV = 1933844732; PGiwzhKrsWCLCV > 0; PGiwzhKrsWCLCV--) {
        VJqntvAMSUTPeVJ = CxtCbpuLaNsShHig;
        jZGuTAZRPZAHze += jZGuTAZRPZAHze;
    }

    return eVOGKDWF;
}

bool qEIUw::Tmvmr(string yhjdbyLHmBVkHMpj, bool Nzflw, int togjQWdkVXS)
{
    bool lRrPGGI = true;
    bool gObuuLcDermWVB = true;
    bool KxhTSd = false;

    for (int eYzWujSeYsagPp = 1342200902; eYzWujSeYsagPp > 0; eYzWujSeYsagPp--) {
        KxhTSd = gObuuLcDermWVB;
        KxhTSd = ! KxhTSd;
    }

    if (togjQWdkVXS >= 1509821583) {
        for (int XtsqAPzBRatVdkt = 854589538; XtsqAPzBRatVdkt > 0; XtsqAPzBRatVdkt--) {
            lRrPGGI = Nzflw;
            Nzflw = ! Nzflw;
            gObuuLcDermWVB = ! gObuuLcDermWVB;
            gObuuLcDermWVB = gObuuLcDermWVB;
        }
    }

    if (Nzflw != false) {
        for (int BpebYcTTKpxP = 668238866; BpebYcTTKpxP > 0; BpebYcTTKpxP--) {
            Nzflw = ! KxhTSd;
            KxhTSd = ! gObuuLcDermWVB;
        }
    }

    return KxhTSd;
}

void qEIUw::DgAnbBJjO(bool nEiNjRZJPcH, string vVupfpkZk)
{
    string ARVZvZPoRfBvB = string("hrngJMCbopnWTlZfiwGuwWHFCTDQzALwMeGYKRHJjpvUFdDTbOJqJuYlCvfakGXuLvckHlKYoPhzoBHszVboxODXMFwnCFzGPnaubmWEoIXpDgrrJEovomymmKCJIbRDlivJyWNvpYrnoKxNDdgGhCIEXAxeYfSOJkZITONIDUFhVsAMirrgcewg");
    int HxGOyJjqr = -616649317;
    double tdJpVlJEY = -766794.6276740056;
    string niEMRsZoOyKXSFL = string("WiNvQmZvHozBOkryqIokdpAftzHLIlFTTlBHEaclfLmvrAcJxIYisokcWwJgxxFaLmuVpaIvuqVbbfjsqEMHNmmCFEKrZyBVzZZRDPLknUxEaxtHAFYNnPjjGUycuZxYJJZFEVpJQkJloPGCtdngKdkvTEgRkDVXamrYLke");

    if (niEMRsZoOyKXSFL != string("WiNvQmZvHozBOkryqIokdpAftzHLIlFTTlBHEaclfLmvrAcJxIYisokcWwJgxxFaLmuVpaIvuqVbbfjsqEMHNmmCFEKrZyBVzZZRDPLknUxEaxtHAFYNnPjjGUycuZxYJJZFEVpJQkJloPGCtdngKdkvTEgRkDVXamrYLke")) {
        for (int YTSKGWrkmqC = 1988698843; YTSKGWrkmqC > 0; YTSKGWrkmqC--) {
            vVupfpkZk = niEMRsZoOyKXSFL;
            niEMRsZoOyKXSFL = niEMRsZoOyKXSFL;
            nEiNjRZJPcH = ! nEiNjRZJPcH;
        }
    }
}

string qEIUw::UuwnhCcqjD(string GDsUqfYarCdMcfJS)
{
    double UmJEsThWJoy = 611238.5042541695;

    if (UmJEsThWJoy <= 611238.5042541695) {
        for (int BikKYlaNAtznlK = 1637238415; BikKYlaNAtznlK > 0; BikKYlaNAtznlK--) {
            GDsUqfYarCdMcfJS = GDsUqfYarCdMcfJS;
            GDsUqfYarCdMcfJS = GDsUqfYarCdMcfJS;
            UmJEsThWJoy += UmJEsThWJoy;
        }
    }

    if (UmJEsThWJoy == 611238.5042541695) {
        for (int DIcUXrIgf = 1664640499; DIcUXrIgf > 0; DIcUXrIgf--) {
            UmJEsThWJoy /= UmJEsThWJoy;
        }
    }

    if (UmJEsThWJoy <= 611238.5042541695) {
        for (int kYieNqdFkCzuBRtG = 521146941; kYieNqdFkCzuBRtG > 0; kYieNqdFkCzuBRtG--) {
            UmJEsThWJoy = UmJEsThWJoy;
        }
    }

    if (UmJEsThWJoy < 611238.5042541695) {
        for (int TXyRousb = 898342853; TXyRousb > 0; TXyRousb--) {
            continue;
        }
    }

    return GDsUqfYarCdMcfJS;
}

double qEIUw::nLBTw(string yHvzNaNpImx, bool gQJcBYX)
{
    double IvkVDQNb = -62454.65665279459;
    bool kHmWL = false;
    bool SOMkqBfTURFhnQT = true;
    double IKLggICHmFbq = 270063.55808634806;
    double mCVCyaXQOJXFo = 125012.95639232382;
    bool risdyhJxksgrR = false;

    if (mCVCyaXQOJXFo < 125012.95639232382) {
        for (int cWAYQOlyWXlgRE = 1609819311; cWAYQOlyWXlgRE > 0; cWAYQOlyWXlgRE--) {
            gQJcBYX = risdyhJxksgrR;
            kHmWL = ! gQJcBYX;
        }
    }

    for (int gbFZJrA = 255528446; gbFZJrA > 0; gbFZJrA--) {
        gQJcBYX = ! gQJcBYX;
        IvkVDQNb /= IKLggICHmFbq;
        gQJcBYX = kHmWL;
    }

    for (int VOEnyLSeArq = 1265890402; VOEnyLSeArq > 0; VOEnyLSeArq--) {
        kHmWL = ! gQJcBYX;
        risdyhJxksgrR = ! gQJcBYX;
        risdyhJxksgrR = kHmWL;
        mCVCyaXQOJXFo *= IvkVDQNb;
    }

    for (int wHCMpWGJt = 22325948; wHCMpWGJt > 0; wHCMpWGJt--) {
        SOMkqBfTURFhnQT = ! kHmWL;
        mCVCyaXQOJXFo /= IvkVDQNb;
        SOMkqBfTURFhnQT = SOMkqBfTURFhnQT;
        IvkVDQNb += mCVCyaXQOJXFo;
        yHvzNaNpImx += yHvzNaNpImx;
    }

    return mCVCyaXQOJXFo;
}

double qEIUw::DSzpzzngtq(string HNnpZIU, string OIrWmG, int kRekjCXC)
{
    string zismefmgHigPDh = string("hatwjxyuzRgHDmmKBmkwUgsrCgLjYiGo");
    double wJhjSV = 942543.3476171062;
    double nzkCB = -44329.053477838665;
    bool wSPZuYb = true;
    int hNVaEiUMYZvkN = -933948494;
    double LLwLtTPeTGm = -258732.47636249586;
    string DGWaPRcMPW = string("muGimxRmJzYBRCNJryoYqPqwMFvQWMHsmUMSCuOJABIfhwCkNnAYzJMZeQSsYeZgyAPCvQXPrNMFKSczkqtEYkUiEDUluBtdpvLq");
    bool DylYWSYl = false;
    string zsSUINsAmbTcZRJk = string("xfkLFkPTyMRZjZLmIcRlycIIixmTovuRaFulBmVdUAsfZYnniHiaoqcASxHImwefQfmuDRwiyltjDoiEjNGFGzNZjlozrftIfyhntfrHuPOpOAMAxFzwCcGRhwuvzjdpMWjUyleNzztfsqDgmCHHeSbUXSvcxeWcIUTEoudPfaoRuNygWYQxCpTbSyeIvUXngCEIvAPGsFKxusEafxdIWnDGbVAJkmQBecaYuMAqLKCm");

    if (OIrWmG < string("hatwjxyuzRgHDmmKBmkwUgsrCgLjYiGo")) {
        for (int jcvZMSsUNtwBMSWf = 1986546854; jcvZMSsUNtwBMSWf > 0; jcvZMSsUNtwBMSWf--) {
            continue;
        }
    }

    return LLwLtTPeTGm;
}

bool qEIUw::PbohCktbTe(string butxmzwrYxldsXA, int qywdMGKdrCVOa, double lkfQDIIRwUkBVjj, string rdyCJicMQ, bool xRCmfkWfWzCYwlLC)
{
    bool QLSTTgc = true;
    bool CIMCZ = false;
    bool YwzCRVn = true;
    bool QdvNdBQfNydj = true;
    string WvFpIxQ = string("PKUrqwKJlHQApetLKMDjTxwpQtgGGZDmtVGxVOaJximXgfjmFrRIyybqOIeTsHMvWRFJGAjHfMiVNhSxzJZqZlXc");
    string TlNZf = string("uCDfUFwcDWokXOxxDtJtIfbrVjQtDOOuaTMSmufapmeuVCJGcbsswMDqyAjIIrbkUQnMTODJHCXnRNbgWBKKnbfWchwxmWDbju");

    return QdvNdBQfNydj;
}

int qEIUw::odQdgyD(bool hvTDtCN, double qSelZfv)
{
    int kJLmgrzeBvhwDRk = -2002636736;
    bool EWBEVW = false;
    double bSuBGue = -181169.73353620037;
    bool bSakboexk = true;

    for (int uZpbk = 1765953336; uZpbk > 0; uZpbk--) {
        continue;
    }

    return kJLmgrzeBvhwDRk;
}

string qEIUw::JIPMVorslqNejkVc(int FjqApTX, int qLYXftMxeklArVP, string kgQifDYaXJ, string JIfzApeHyB)
{
    bool SRRPw = false;
    string aZJzpupjCkTRgSTF = string("SMRtjGKJRxpRHtrzrPSlGudUdyXKLhZGrEiQGRQkxJgHyWRwfdkdQhyiuqLrppsYHYmxrwZMcfAiqUFircgZhFVSlaEFQrVyyJjYkxGInwkLFgpjCcZRrwfsVrCXYYNvOOstUvCksfWLEWpNviudbIxgsLWcfNzZCsCWGJFxlQZipODuzKAutlDyZmHWxmoXHN");
    double CSbGwmUUGxYX = -949682.7128430408;
    bool yEjtVF = false;
    bool ljIPPXmf = false;
    bool oReJyi = false;

    return aZJzpupjCkTRgSTF;
}

qEIUw::qEIUw()
{
    this->ygvEmc(-1838250835, false, -647268073, string("tfRxYowThoTARfUEmjLlAMpUQcFqjUzspNgbMkvZHKzZcJKYkhTBShwQlYYYAxcFnbMCbAQYvHVaiTFKxCcw"));
    this->EvwtmhSOGvL(66718.55816095238, false);
    this->thyugt(-1019292.3395724458, -432019.30317258835);
    this->dsMNAKuTXC(82725.72744460072, false, 170513376);
    this->KLgnmXrzsq(string("vxmjfwAcZMvLsNXmZQbxuAYpxzLXyRBldFtPrIFVTYVmsMbXDavPbfzDtbByrryKuFXyrTZBrGcUeyNVPwgYiCzGITqGaoFLhWCRJOptOwCtbsvbrJKwHMRHmFUYMFVpxYYzwJjxIbSfimYQHQVWtmuOtjjOCzKdNdCLfigWbvmUyOvwDMcpAuWTKuSbsjtqYYXlXJdZzo"), string("tmLOwUmIIlQFwYlMkESnhbEaHqBGLXJqTlfhmeRORquELkebomvCIiVazWpcfokmglhtBWkuHBDHLEWxyBpdyfAJySaBrvaPYvzlawzmkFlFOqAdwGlzqmIpNmAgDPhapUXPtYlomnZDhVkPmncyNfZZeGZKUulyjLawFLCrhFVmvwgmtBwbdDDvTuDlSkaxkouzBqeTUDZqTAMZVodWrpDLXvnQFmlgqTHaCKuBGBVq"), false);
    this->BcyxCAvSkMA(-1157420415);
    this->dECLJCTVo(1982161087, 924565.564106797, 1642913722);
    this->ccwOewf(-799265.2158875569, 288667.35417991935, string("yNMCAAFQwYHjUeoHrXZeOcRusgKXpGLbzAuipKkpKkyi"), string("uQQdTRZbTgUckShlxcrvIwUyCCTuoyjhezAuEXsumOiMMxHdfGxmBcWsHxRPxLTffelqnmngHPikrgpCtcXEuOkPnShTNRelIFWmAKHyxBlkdzBJckMsnenpecFsfnOFArLbDPQlTuAnUJPCxzZiRUtQMkOfSivtAwGConX"));
    this->Tmvmr(string("ufCSsvtcMBIfYYOIUgkBStvvUpHurYSzWZyUfJWbXeytElbXjS"), true, 1509821583);
    this->DgAnbBJjO(true, string("NxJzLJBsBvYJEvtwaMoqeyOacQxzZCmVYCqbmPuuUcZaBVjjNSDEkkyPPsrzzyLhguhlJmdmVOSddifyAmdsnzzPfckNctPdubhmQTgREHkwHGiKqaqXzNEWCxDWaCKbACDlddRjDBPWDtogTMDALkBUNiXyTGjDudpdZwZEFaKmMsnrQTtFEpfyepxckduJgDpYo"));
    this->UuwnhCcqjD(string("ANTmItpPUWSeMTNmREngqlATnwkxBvyVMfxCuDqepEMLCmIJcDqTUjyBgskwtDVovyTaafdcvVwCcNeUeFgQBhxevgEWEIwAOGUQYqinScgmBhTNReBdSSRPivwmpRHcfwkkVNxpKlnSlhwnDLkJGFinrUtWxWMSAwScAZdjbCZSgtHddZSSKCgYRuwyvbtSZEVdnkitjbW"));
    this->nLBTw(string("vKbMcVHHqKwwsqBIGikjutNCYKqojzClYdtCvSwwFLZlZePGLPVwsltkhDRYkUQg"), true);
    this->DSzpzzngtq(string("zMtQae"), string("PBwdXvgmWNykQkmVfOIjUuERdhnFAIydTjXDaXLEWivUjFMasLdfmehXLehVklQBdpQqLSCQYyNQAZjFktcvIxkJSaPWrrHbDLNuoFCPLefWSaonqPCaMKtDwEuQercZazJkxIAbytJzxsNRrASdbGtckFBwPHuljFaVCNkuMqKaRLlPRtTqhYVCZVIOSupYMFvERovmeUkTBJKDDMUOfYCZYzAgrInEzApkvtPyte"), 90715295);
    this->PbohCktbTe(string("yQdpHrdbByAWmiBeUccgGAfEsOdtKepUCjIJfLRPQmasysMXgXbhsTzKwJvbUrSUTYwFXKekUmFlusFEaQaECuLsPSKedawgCRdRoUJOcpBTMjBG"), 129924466, -234606.41626980095, string("hHXnmGFvMihFYFwUjUTUboXCuvaGmYPA"), false);
    this->odQdgyD(false, 1007774.8689329114);
    this->JIPMVorslqNejkVc(-1242323295, -1849544109, string("UFLAILITStnNYiJLTvxlYfzYPWFtFlaRtbXAVHVxIZCfncVNTemkoDtgsXMxDuwkJhMopqXiQCJtoWQfWuqdDgvafAUumsPBoJWZfXYGHBtzkWHmgjkniDTgFidByzqHhCNQTSQUFAxAmhIFNIFgcoHXJDfgDJpItRMSqlwCrBradMyxlUbzVhcORkQ"), string("ViNwBrbX"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class noHNRarzvbDTT
{
public:
    double sLwaTgO;
    double MzZgVZiyhKxPq;
    int kUoflFT;
    double dxjcLSO;

    noHNRarzvbDTT();
protected:
    double itYQC;
    int GsYOldYCpQZjfCh;

    bool oVOYX(double FwJauC);
    int iWGDHuy();
    int NkEcxFrMCYUE();
    void DlnGnjRWd(int dNgFtxCPkibmZFsB, string DRpLSSEFZVQwSC, int sYkGty, int ghtKK);
    double dIuGake();
    double WjXnXJNvlGoXH();
private:
    string jBdoXCQBLJNQ;
    string KvsFslle;
    int kaWFUEjQUW;
    double aDKmTKwXdE;

};

bool noHNRarzvbDTT::oVOYX(double FwJauC)
{
    int aNtSdlBkMZpMqwAI = 1510963602;

    return false;
}

int noHNRarzvbDTT::iWGDHuy()
{
    string xdVhED = string("rUPRfbeeOvGppeoJNlnztGXCzlUqOyYjbsvqMQSEzwXzofxbKrwcCNyezFMbGrIqgevuvIXDbAesguzoCfSfIRFvRzWRTdOWitWzmEDlJqOxqtemDEREKWutzgREMpRixBFBLoWnetPsijFFFNamQnBSqUvYSeFXbeNwNzCRQyUqHTQnZMIMoxDkNeTsiUSPFkYd");
    int iVaTKGroBjh = -1411055711;
    string QVpDqNWfGIiEBxa = string("ClbQzxdzjJqPrawLYvEFvCXDYgAqOR");
    string mDdMwGlI = string("CDMBqveeemEiryhUGKxcOGTPRJBrvLByrTcBIBqzcecRpMCGaGmDSsHBYYsyVprWexmqKZdcvxgAnCwfbTHKKOaDEhcVaimtrWhlKtPiQCLSfxbZCOLvLkGqiBuMjiDDFlOYvnwKdOfccpdlehyFPELxahqxypDLUjqMmcLAYHmlwjxxJANewhzOOJUJSRqgAAYChzagSKwZgThaWZyBTwTBtIfqOpfZZ");
    string bdpHEFZnsKr = string("YilGxFQwoNAsdS");
    int QFdOghDRfAtBr = 937969621;
    string bhGHcYTZuav = string("Ck");

    if (xdVhED >= string("ClbQzxdzjJqPrawLYvEFvCXDYgAqOR")) {
        for (int YwWRQDZyHvSC = 1018197891; YwWRQDZyHvSC > 0; YwWRQDZyHvSC--) {
            QFdOghDRfAtBr /= iVaTKGroBjh;
            QVpDqNWfGIiEBxa = mDdMwGlI;
            QFdOghDRfAtBr += iVaTKGroBjh;
            bhGHcYTZuav = bdpHEFZnsKr;
        }
    }

    if (xdVhED != string("YilGxFQwoNAsdS")) {
        for (int HtwUMBbVAOoAARDP = 1180621490; HtwUMBbVAOoAARDP > 0; HtwUMBbVAOoAARDP--) {
            mDdMwGlI = mDdMwGlI;
            mDdMwGlI += QVpDqNWfGIiEBxa;
            mDdMwGlI += QVpDqNWfGIiEBxa;
            bdpHEFZnsKr = bhGHcYTZuav;
        }
    }

    return QFdOghDRfAtBr;
}

int noHNRarzvbDTT::NkEcxFrMCYUE()
{
    string ndsOsWriJZFEfB = string("SeefYCLCggZXuNRpxItxjeWrlJWxCycOVCpvdWDmVdVSlGIaKfsIgafDdWwtcvtblWPuBqSZKfBUasrLEMkGajeuVuOySteVlSzvaDLiWonAqSihzffXblVbszkhPGvcLleqCnoSFCixbBnLmxVDxJxaBAFrJJPIuuCphICRfRRLh");
    int yDiovn = -1038516856;
    int tHUZds = -618243367;

    if (yDiovn > -618243367) {
        for (int kwJpLjUwwBdDD = 1368393066; kwJpLjUwwBdDD > 0; kwJpLjUwwBdDD--) {
            tHUZds += tHUZds;
            tHUZds /= yDiovn;
            tHUZds *= tHUZds;
            yDiovn *= yDiovn;
            tHUZds += yDiovn;
        }
    }

    if (yDiovn > -1038516856) {
        for (int ORXPmeNjf = 1977118350; ORXPmeNjf > 0; ORXPmeNjf--) {
            ndsOsWriJZFEfB = ndsOsWriJZFEfB;
            tHUZds *= yDiovn;
            yDiovn += tHUZds;
            yDiovn += tHUZds;
            yDiovn -= tHUZds;
        }
    }

    return tHUZds;
}

void noHNRarzvbDTT::DlnGnjRWd(int dNgFtxCPkibmZFsB, string DRpLSSEFZVQwSC, int sYkGty, int ghtKK)
{
    double bJtUuAqn = -972971.4377590194;
    string TbqtvwdE = string("pBVrCojkVNYEFRXSVnnsRFNUyYYPrFXkCncOTvmAPuGxuMZjIkLPkjjpBStyXLiBDLaYSYYcgfrpXCUciKxARaAQEQjIUDerxAAMznVBExIRXXxLCCNvfyeSfFBobvgNwARvQDINSeMzDZHlPAGUktfwKYNIDMH");
    int HrUVmzFMpuw = -52729087;
    int kdBPHBSLjoIx = -600952874;

    if (HrUVmzFMpuw >= -52729087) {
        for (int SHrDdEcClSs = 1335585000; SHrDdEcClSs > 0; SHrDdEcClSs--) {
            sYkGty /= sYkGty;
            sYkGty = kdBPHBSLjoIx;
        }
    }

    for (int dKuJqtqps = 1455205871; dKuJqtqps > 0; dKuJqtqps--) {
        ghtKK -= kdBPHBSLjoIx;
        bJtUuAqn /= bJtUuAqn;
    }

    if (bJtUuAqn <= -972971.4377590194) {
        for (int JuTuZTmwPV = 1314309142; JuTuZTmwPV > 0; JuTuZTmwPV--) {
            bJtUuAqn += bJtUuAqn;
            ghtKK = HrUVmzFMpuw;
            sYkGty *= kdBPHBSLjoIx;
        }
    }
}

double noHNRarzvbDTT::dIuGake()
{
    double fQbAvQy = 594022.7519920198;
    bool bwBrolrEsx = false;
    string LOWsRkckv = string("wJRZupzcSbOwHcWYIxNkHZJLqMpoFVMdDPIdKsgIhfgbBGkEelYUNsfPhgjIQyQKdQSFpfJYeICxAdBupIHFjBruUISgeCcuHCURbNQYICgNSqtUwetIAqVoUVmVePTSoKiKIyjIDPFwnnbOforYYJNPoveNdZahOMaLgOAUSgDwVWCUfIxtlqvxSUSwVgifIOupfwjbjxnGPwdrQbtJKUnSsQtqutCFiOSszgJgqikQnIAmTKm");
    double dCkdkM = 324053.7171738136;
    string IPPPNlwQoztfQq = string("xxQjQmanWxclTqGvCxRLjFdmLbyjQsRBddGJiioxJsgNTMAGqqYgGGpTjTcDdAlcosHRxDeTJXQqPIFPwRLrmSgbPXHHCNgzuDKyNefVQHmtQdQaHbemNMYbUUwoeohULgQsBlmwqPFDMtApZWhxDCSlmtenoDXEanMYpkQeRpEtEZbduUGmSdJIHSloYXGUEYOtZWKIoRhtmteRTolgmaAWPRQLWQhXtuT");
    bool JvdvS = false;

    for (int woHvtYBCDuIQ = 643791086; woHvtYBCDuIQ > 0; woHvtYBCDuIQ--) {
        IPPPNlwQoztfQq += IPPPNlwQoztfQq;
    }

    for (int lIVSuXIGzObWAmI = 64272247; lIVSuXIGzObWAmI > 0; lIVSuXIGzObWAmI--) {
        JvdvS = ! bwBrolrEsx;
        dCkdkM -= dCkdkM;
        JvdvS = ! bwBrolrEsx;
    }

    if (LOWsRkckv >= string("xxQjQmanWxclTqGvCxRLjFdmLbyjQsRBddGJiioxJsgNTMAGqqYgGGpTjTcDdAlcosHRxDeTJXQqPIFPwRLrmSgbPXHHCNgzuDKyNefVQHmtQdQaHbemNMYbUUwoeohULgQsBlmwqPFDMtApZWhxDCSlmtenoDXEanMYpkQeRpEtEZbduUGmSdJIHSloYXGUEYOtZWKIoRhtmteRTolgmaAWPRQLWQhXtuT")) {
        for (int tIAfNvNXhKUSCty = 190276531; tIAfNvNXhKUSCty > 0; tIAfNvNXhKUSCty--) {
            IPPPNlwQoztfQq += IPPPNlwQoztfQq;
            LOWsRkckv += IPPPNlwQoztfQq;
        }
    }

    for (int ROAlIi = 166107875; ROAlIi > 0; ROAlIi--) {
        fQbAvQy -= dCkdkM;
        LOWsRkckv = LOWsRkckv;
        dCkdkM /= dCkdkM;
        fQbAvQy *= fQbAvQy;
        fQbAvQy -= dCkdkM;
        fQbAvQy += dCkdkM;
    }

    for (int KqFCLWAbaiYQkytS = 1015944805; KqFCLWAbaiYQkytS > 0; KqFCLWAbaiYQkytS--) {
        dCkdkM -= dCkdkM;
    }

    if (fQbAvQy >= 324053.7171738136) {
        for (int UicKtnc = 1807904680; UicKtnc > 0; UicKtnc--) {
            IPPPNlwQoztfQq = LOWsRkckv;
            bwBrolrEsx = JvdvS;
        }
    }

    return dCkdkM;
}

double noHNRarzvbDTT::WjXnXJNvlGoXH()
{
    bool EOFhvkNbhUIuSc = true;
    int XjgHUULWLyTTOgR = -1937878042;
    double RaVft = -744280.7959955073;
    int wzrvsSfKv = 1016661375;
    double IchDT = -145516.4329824754;
    double jUWkfPSOkrvh = -306660.6072270294;
    int swIaoTbPxBVpCela = -2132834067;

    for (int faClfTxhRu = 103619835; faClfTxhRu > 0; faClfTxhRu--) {
        IchDT = IchDT;
        wzrvsSfKv = XjgHUULWLyTTOgR;
    }

    return jUWkfPSOkrvh;
}

noHNRarzvbDTT::noHNRarzvbDTT()
{
    this->oVOYX(443572.8985269137);
    this->iWGDHuy();
    this->NkEcxFrMCYUE();
    this->DlnGnjRWd(-589650945, string("xQTVVFuAiDJgAAcWKNEGcDRMYRKRhdkrZRmIqZDpObFWJuyEsn"), 1950604186, 1785531224);
    this->dIuGake();
    this->WjXnXJNvlGoXH();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nyuuH
{
public:
    bool fBjGYu;
    int ffrYa;
    string pTrHbXzCiny;

    nyuuH();
    string fUcdYSKBR(string LNbwOsxDFRJSMz, bool yoGyhjFiEAgplEDN, string tVTNHkhhgBHGh);
    void KFZjamAQmgunTY(int uTKqeDnKTriAEl, bool Xzwln, double KOCkZHMhn, double IzCzHFVrMGZESd);
    bool zAHYGUsd(double xCOTgr, double WiXVRULYOoeR, string OURiVMFcVetjhASk, double mhloHUtICCuMpK);
protected:
    int vFdacm;
    bool jMWLonhSECtaGD;

    void hvqCuZhsNrO(int drvtkU, string BxTDMuycGcHTqg, int DyWFrRRMrWPsXxX);
    bool lVqGlcWQiRlVb(string aVIfTXYM, double DEnMZeS, int rKhjBDOrgxEFJfbV, bool kRjcWZunhj);
    string DOAsHABSEKEk(double shpgVcOpdyhFV, double JDjKvfJ, int MQMARIGAjMzo);
    int zAxfIgUoypTZAVki(double XUDsggpMxLQyX);
private:
    int OdYVjHaMXql;

    double XWrZRcklGSQyfY();
    bool EOQfx(double QMmuQwAOAfDwzcAH, bool VPoKFDggAM);
    double XAemxYSL(string RcqReATPRIoyN, string cPioVbxzVYYi, bool PBwZXflSo);
    bool vfEVPNxvEbeYNbls(bool uUKKSdMz);
    double OUOfBWvU(int kRSczIrb);
    string fYnuumJcnGCY(double DLcKDfkb, double HUNSWODxH);
    void huCugj(int ZsngPFwHvOkYISC, int DMVbztW);
    int SOXTxYtUF(bool IbgYhNCzISy, int ZJkhibEfTIL, bool YoCZqrxKWv);
};

string nyuuH::fUcdYSKBR(string LNbwOsxDFRJSMz, bool yoGyhjFiEAgplEDN, string tVTNHkhhgBHGh)
{
    int noaXhOKEDtLX = -1662939426;
    string EFbNxIIKT = string("dcmTUcynFVHpmrHWBPjvyIqFddLMMYjokjjkXGlfHnluMSaAPXILRMmqWYbigHyeZruENTYinSpgpOdlPrpAYTWrLKzWxajSrpDxxizCSMaRKpBIkzyeRkfeWLvpwzcmLlIRmYwEhhttpYuuWZtHxYwksbKGvdyapPKbnrEniBNgVfr");
    int HSEpBmOOP = 319839689;

    for (int ErhtDhFMcMdk = 1550471031; ErhtDhFMcMdk > 0; ErhtDhFMcMdk--) {
        continue;
    }

    return EFbNxIIKT;
}

void nyuuH::KFZjamAQmgunTY(int uTKqeDnKTriAEl, bool Xzwln, double KOCkZHMhn, double IzCzHFVrMGZESd)
{
    bool TmhYtAXGExe = false;
    bool sgvtT = true;
    string GbjhDMMs = string("CHqWJXKHRhqGvLvhAVFVupRHrIZelHEmynHoFoRcyxfJlqmSEXbgXcjIAXjEcUmTieEoCFuuHnNQZyQnQJfYdZHNqkMJATcKes");
    double fhZwyCQ = -313070.0599498933;
    bool dqrEvRsTXvksvC = false;
    bool CWrVUhAOqCCbJsb = true;
    double ZSndnXVXkWV = 350901.8402539159;
    int xgrbAGhjgDXQw = 1646603648;

    if (xgrbAGhjgDXQw >= 1646603648) {
        for (int LUhEEctEJG = 1682986229; LUhEEctEJG > 0; LUhEEctEJG--) {
            uTKqeDnKTriAEl *= xgrbAGhjgDXQw;
            sgvtT = dqrEvRsTXvksvC;
        }
    }
}

bool nyuuH::zAHYGUsd(double xCOTgr, double WiXVRULYOoeR, string OURiVMFcVetjhASk, double mhloHUtICCuMpK)
{
    string RumqjZpdm = string("lpUKueCNRAPJDCvSSNtfahCZqrLhVwffxcZdFaaYiPGrLg");
    int JMvEEbEbluaq = 235930882;
    double NAHqVOHpNU = -427546.9180984254;
    bool GDrjcpHCrG = true;
    string DiEcvtaP = string("AtXNSlpaHOECtMqKahQxKwXxfkpASpasvZwBsZRnxzmImJeAtsZXKMxVQqqoaVmqRSyfzEgQbyNXrnnDlwUCSOMLbbyZJTfDjoKNrjFysqEIxLVommmDHsALCtdFPBIlSitjTdhgUtPeKZynDZGtvLvkCuUGlNNRozixKoUZxWAlkHix");
    string VKRMEqTEpI = string("waAECmaaRCtBQcAWpnaaFzhoVuzKxDGQVxkxCNWWzjvQMQWMnjeSbEaqybnrFgPdMlwCxGgbFlmRDNZYHuivmtfffdgslIOOGarYUsCdAQMSrpPfijVsUjpjiEWvwZCPmnJu");

    if (WiXVRULYOoeR < 368010.74319993623) {
        for (int SkGxiAYjHPqtGi = 1061882518; SkGxiAYjHPqtGi > 0; SkGxiAYjHPqtGi--) {
            continue;
        }
    }

    return GDrjcpHCrG;
}

void nyuuH::hvqCuZhsNrO(int drvtkU, string BxTDMuycGcHTqg, int DyWFrRRMrWPsXxX)
{
    double FpmpfDGMYQ = -386083.1465106934;
    double fokbHWNDjppV = -1041881.2999126218;
    string KEonno = string("hKFefztiHHtrWLHrVoFJQuXNknyQCLLiwMWuNwXtBXiIsdfsYdOrsgVMkglEMQaFHhKcBBKjLfWDYTTqjOknoJZBUAUqkzILyNjdMXMiIuuKxbpsaTJuJzMQBDdWzzhuvlOWIjZSMZlmAsxzwnGYutDaUFJcGmYJkmesgCoBfglxlCzesrMyzvxTmtKWorCQGawRTkoHvGtNkKdVZsQMNfBnbvEl");
    int KQkHBmfujKUPth = -2038681254;
    bool hpSibij = true;
    string kvfsl = string("mwNcFcraRyiJHywhQYUCGzZmxedwWYHavURZCGApcpOHZLJsrlhhRzwxHsfshhTmndKWXUGwWDQTKafDEaVwWPj");
    double mqvuCmGTMWqqrS = -419338.67456899735;
    string qDYJjFQIij = string("CzclHkyOQnFBnyRLaWxcjEaSHxWWjbZXutISChgJfkmRukTxdrKmGSSLWmTzUvEfoFmxRxtCbnSGCwLkVbzbcybpNHNcV");

    for (int qdAkLBUeUUP = 1370655506; qdAkLBUeUUP > 0; qdAkLBUeUUP--) {
        continue;
    }

    if (mqvuCmGTMWqqrS >= -386083.1465106934) {
        for (int MWUEzRi = 1433454449; MWUEzRi > 0; MWUEzRi--) {
            continue;
        }
    }
}

bool nyuuH::lVqGlcWQiRlVb(string aVIfTXYM, double DEnMZeS, int rKhjBDOrgxEFJfbV, bool kRjcWZunhj)
{
    bool WbLzSi = true;

    for (int UHymMrNbhA = 1418870436; UHymMrNbhA > 0; UHymMrNbhA--) {
        rKhjBDOrgxEFJfbV /= rKhjBDOrgxEFJfbV;
    }

    if (WbLzSi == false) {
        for (int fSySBmH = 1550701139; fSySBmH > 0; fSySBmH--) {
            kRjcWZunhj = ! WbLzSi;
        }
    }

    if (WbLzSi != true) {
        for (int ZMajvqEU = 1552081853; ZMajvqEU > 0; ZMajvqEU--) {
            continue;
        }
    }

    for (int HoZQGsAKwHbF = 1232901668; HoZQGsAKwHbF > 0; HoZQGsAKwHbF--) {
        continue;
    }

    for (int yfqYyCAg = 1399805933; yfqYyCAg > 0; yfqYyCAg--) {
        continue;
    }

    return WbLzSi;
}

string nyuuH::DOAsHABSEKEk(double shpgVcOpdyhFV, double JDjKvfJ, int MQMARIGAjMzo)
{
    bool PGbxHytY = false;
    int RfBlEnwJG = -1887232736;
    int VMRXDERXso = -1706493285;
    double XhFyyzyHMRAxhF = 960777.7844702379;

    if (JDjKvfJ < -250827.43795951296) {
        for (int xIfHpQxxVkQkTMo = 525305180; xIfHpQxxVkQkTMo > 0; xIfHpQxxVkQkTMo--) {
            continue;
        }
    }

    for (int KQHnUhSQfV = 917027173; KQHnUhSQfV > 0; KQHnUhSQfV--) {
        continue;
    }

    if (VMRXDERXso >= -684752072) {
        for (int EnJGxYsiZu = 1019726085; EnJGxYsiZu > 0; EnJGxYsiZu--) {
            continue;
        }
    }

    return string("JrOfcSICaCjJSzeCc");
}

int nyuuH::zAxfIgUoypTZAVki(double XUDsggpMxLQyX)
{
    bool VeFOs = true;
    bool tmEKhAeYLuIS = false;
    string JwHfuia = string("qliwKDrgTbXnjAEPvOxqrzoIZlcRPmtonJcrdyCTMymFGODNuJXKxjwxXFqDcAuaakbQzspBijjqjewoXPOLzlhxeUzljyQPuljIvNoHWafvdoIvNCxBJjvUktWqnpllNhkRfHwjFBDtjMyvFQiSPaRmzfVPcvQmkVghgLk");
    double SCjwUsSjA = 921079.9653698633;
    double XkXMSQziTsrFe = 940257.975064525;
    int SmBEgMoMiOSpNP = -682835302;
    double KVfXaDZq = 977227.2991079639;

    for (int bkfpOAZtu = 8794238; bkfpOAZtu > 0; bkfpOAZtu--) {
        SCjwUsSjA = SCjwUsSjA;
    }

    for (int XIeDhuC = 2023378377; XIeDhuC > 0; XIeDhuC--) {
        XkXMSQziTsrFe = SCjwUsSjA;
        XkXMSQziTsrFe /= XkXMSQziTsrFe;
        XUDsggpMxLQyX *= XkXMSQziTsrFe;
        XkXMSQziTsrFe *= SCjwUsSjA;
        SCjwUsSjA /= KVfXaDZq;
    }

    return SmBEgMoMiOSpNP;
}

double nyuuH::XWrZRcklGSQyfY()
{
    bool zpXLAastyeDqgAKh = true;
    double uWPujVbSg = 308589.94739592;

    return uWPujVbSg;
}

bool nyuuH::EOQfx(double QMmuQwAOAfDwzcAH, bool VPoKFDggAM)
{
    bool ggImaZtOjcEY = true;
    bool njPkBCTRTAkCNJZx = false;
    double cLcvalK = -504823.1878943267;
    int vFqkyIU = -778394490;
    string QaPTIceoMq = string("AvXaCYyHaIdVEmsGQasUXMNcNiWaaQKVjM");
    double WVAXqvvqgBl = 689469.3767403223;
    int WimrPG = -887077462;
    bool cUxyaJMnIpGox = false;
    int PSkrXBZOO = 213890536;

    return cUxyaJMnIpGox;
}

double nyuuH::XAemxYSL(string RcqReATPRIoyN, string cPioVbxzVYYi, bool PBwZXflSo)
{
    double xiuFyRvycvlYsidc = -687397.0010760729;
    int wjkYQSxkF = 986522640;

    if (PBwZXflSo != true) {
        for (int DlxsSKhN = 1507004205; DlxsSKhN > 0; DlxsSKhN--) {
            RcqReATPRIoyN += cPioVbxzVYYi;
            cPioVbxzVYYi = cPioVbxzVYYi;
            cPioVbxzVYYi += RcqReATPRIoyN;
        }
    }

    for (int yqFbXc = 1450759267; yqFbXc > 0; yqFbXc--) {
        continue;
    }

    for (int EwhFkh = 1964621196; EwhFkh > 0; EwhFkh--) {
        wjkYQSxkF *= wjkYQSxkF;
    }

    if (RcqReATPRIoyN > string("rqCZIzkZoPCmYOboPUfRjbqAXPgKKHmlLasVCygpVVQlklCpaZQvpJsgzyIzfIDyhItTZjsZyXCCshEUZfUrIfynKtNXgT")) {
        for (int ikZJM = 504605754; ikZJM > 0; ikZJM--) {
            cPioVbxzVYYi += RcqReATPRIoyN;
        }
    }

    if (xiuFyRvycvlYsidc > -687397.0010760729) {
        for (int IeTJeogRFaxMYct = 1484252833; IeTJeogRFaxMYct > 0; IeTJeogRFaxMYct--) {
            RcqReATPRIoyN += cPioVbxzVYYi;
        }
    }

    for (int zreAmgNVgCdC = 207182750; zreAmgNVgCdC > 0; zreAmgNVgCdC--) {
        RcqReATPRIoyN = cPioVbxzVYYi;
        RcqReATPRIoyN += cPioVbxzVYYi;
    }

    return xiuFyRvycvlYsidc;
}

bool nyuuH::vfEVPNxvEbeYNbls(bool uUKKSdMz)
{
    bool QHWylTKpNQvoWwO = false;
    string eFZCglBSDJhc = string("RuknGMYbyFygZZXVOElGglnVxgYRodtZkzATNHHijmqLSteyAuPgZJAAvZTvDnVMuybOGnkOeRFDUlCSvBiCesUNYBzhTivxWDWYYOrrVZrxaFARdwCfMOykZvDLlyQYPlAmrjjiDRkVdjoRqatOUrBqOBwzlEfNUkPbkaYtmAVxaGEJBAM");
    double TZuvkU = -626274.2488654302;
    int KzqdkAKaXi = 275318309;
    string WZTFHOndvGhW = string("BRuLlakxoBzlThTkRJFduLYcUlbXumSRQLPWydiZBgEzvKhxfBtQsjZvQFyagmFQpliNKzVvAabLJSZtdnCdMcKcCszFcPOCBDOvprICgPjobjJ");
    bool kkqJRluiuZtjp = true;
    double NwhlJBuHr = 819462.2002744857;
    int rRpytxcZZ = 941550690;
    string ReuEJvIVAr = string("aazblSCvhoCMBEhEqYMyGUfNQqnChztdWTNDyvvHzpyTEqhgGjCcPyLPzEyHpYKWTmAIVJYqdtoxFYSBuFRNbiVwJNMYcbYAjJeDHmzoYbbruLhmIEFDpizYErIrLEbAlpsXlszXU");

    for (int JQNyo = 1554837308; JQNyo > 0; JQNyo--) {
        uUKKSdMz = kkqJRluiuZtjp;
        eFZCglBSDJhc = eFZCglBSDJhc;
    }

    for (int EIkqa = 1648627817; EIkqa > 0; EIkqa--) {
        continue;
    }

    if (ReuEJvIVAr < string("BRuLlakxoBzlThTkRJFduLYcUlbXumSRQLPWydiZBgEzvKhxfBtQsjZvQFyagmFQpliNKzVvAabLJSZtdnCdMcKcCszFcPOCBDOvprICgPjobjJ")) {
        for (int EyGenJf = 512020335; EyGenJf > 0; EyGenJf--) {
            rRpytxcZZ = KzqdkAKaXi;
        }
    }

    return kkqJRluiuZtjp;
}

double nyuuH::OUOfBWvU(int kRSczIrb)
{
    string AnusqlqfZvqUD = string("GWOKTxiEqfZttUTiyRjHqZxCWtoMndSjNkUpkzzixnpIscuDAXxFtHWsbSKisJpjPwmueIysKpjfnnkIpeouvooiQMfcmzvuOitMOSRCfLGdacfoiGFyvhwoSDUQmHFdiWAGyMbjSGGLPqGMjNEeVqPiLyBjJAvIyNTTsQclLjRPrPBSZHBwBRqShnTLPHHuHPSmWysMBamXWXkBoEnfZEobyHIYbWK");
    double nrNbQbRRnZ = -964716.7427233929;
    int IHECyvuTNaxvLKh = 1427654661;
    int bdDwVBVedq = -1293979711;
    bool lmZGYjtUQJBePf = true;
    int kwXNikSPnlg = 265174514;
    double lyAUZwsyQs = -421969.4244033979;
    bool nKNOOqlHEwOXl = true;
    bool qWBYohDoQwSW = false;

    for (int hDEWGnQ = 258981287; hDEWGnQ > 0; hDEWGnQ--) {
        nrNbQbRRnZ /= nrNbQbRRnZ;
    }

    return lyAUZwsyQs;
}

string nyuuH::fYnuumJcnGCY(double DLcKDfkb, double HUNSWODxH)
{
    string bNwIXPB = string("jHPuqkCLIqYDSXBJZobpxNmybhfKnMGYOnBEMroHJmyQcikSugLwFgBoQLhlUBwYCUEOGyUDRThmaTlyzKFTnTpVNfVdDIzpUBZwweyNfsCrOiFSHrTCyVYmxHNmCUFhcwsxubNglOpBIHxWqyfQFRUwapyvredPZWFtTlytFvOfNxvjsECuIXKotyvxapzriUgOKOMXdfsdcAOKbAUOUFmzGBOXXCeJKsCJKISPZzcuTLUve");
    double NORlfELBbSSwdo = -268781.17376050784;
    bool fUdZKzKJeQ = false;
    bool wNZwJTSTHDH = false;
    bool csYZLUx = true;
    double nrGlEgRYOqqnNu = 842244.8619806878;
    string tlSfKKSZn = string("x");
    int OSsojS = -85628317;

    if (DLcKDfkb < -947094.2280210472) {
        for (int ZYjamxGBQR = 788740005; ZYjamxGBQR > 0; ZYjamxGBQR--) {
            fUdZKzKJeQ = ! wNZwJTSTHDH;
            nrGlEgRYOqqnNu -= DLcKDfkb;
        }
    }

    for (int MkaAH = 40602728; MkaAH > 0; MkaAH--) {
        NORlfELBbSSwdo += HUNSWODxH;
        fUdZKzKJeQ = ! wNZwJTSTHDH;
    }

    if (nrGlEgRYOqqnNu != 595431.3827246563) {
        for (int fzwJDxZEApAN = 664430428; fzwJDxZEApAN > 0; fzwJDxZEApAN--) {
            wNZwJTSTHDH = csYZLUx;
        }
    }

    for (int WiJJXU = 2096784404; WiJJXU > 0; WiJJXU--) {
        DLcKDfkb *= HUNSWODxH;
    }

    return tlSfKKSZn;
}

void nyuuH::huCugj(int ZsngPFwHvOkYISC, int DMVbztW)
{
    bool adoMdBxV = true;
    int PqqUUJ = -1256157697;
    string FGwJQTDwhG = string("WVoNjphgHSRExpIWlSqeVaJBamurAtTUpoPugtaqpqvXwjrtraOMUYUhgHhBvQIAvTbjMxwijnEzOCYxnvrPrmGgVIPmklIDwtCZZpOtpEOyzGWnZXmieqbgDQkJTTydWuRhGqgOqQizEO");
    string QnQKTxbwrHBcG = string("VTSoJHBJqXNIbCTnWrxjWDGlHHTqPIZOZOYIupxcHsOipAIDkWhNzNBortUjmxZWJLbmHSSZBkQzmKXoYuyxNgrheKDoSrpIirqTvLhFNzOQITPDHDZhzOuQDoskwhYHvBwxlNIxCyurbSizGfWybsnQNMuiBOVVjKBNlHCvPfvCPGDbXEtQxcHvLmSSEDIYEKRGmrZMfPkioMQFgratmMpZpvJZSungAeDkVLYybjqFrlowMtcHNug");
    string HLjnShXiadLc = string("tvTSJtYQZYxFkiJZadcYrinAyNYimZLmotSHONMvHvZficenQIglpwStwAtRsjSthTfQbLhMJsFQMXxIKqKzchUNKQDTyTuhGuLDXoDHVFAaiwrekNGZZPBtwEvhLSOdFsrFZmvKUGXEvuingStnRZWbqlWQPvOQrtuPUMaelITzZNZQrmsZpjOBtKA");
    bool ARuOTsrGPDHy = true;
    double jaGeEc = 974033.7965584289;
    int pASnzKkLtdTmZBPH = 2042394412;
    int WQIQcwy = 134835430;

    for (int ZyhasEttsNitF = 1536594992; ZyhasEttsNitF > 0; ZyhasEttsNitF--) {
        FGwJQTDwhG += QnQKTxbwrHBcG;
    }

    if (FGwJQTDwhG < string("VTSoJHBJqXNIbCTnWrxjWDGlHHTqPIZOZOYIupxcHsOipAIDkWhNzNBortUjmxZWJLbmHSSZBkQzmKXoYuyxNgrheKDoSrpIirqTvLhFNzOQITPDHDZhzOuQDoskwhYHvBwxlNIxCyurbSizGfWybsnQNMuiBOVVjKBNlHCvPfvCPGDbXEtQxcHvLmSSEDIYEKRGmrZMfPkioMQFgratmMpZpvJZSungAeDkVLYybjqFrlowMtcHNug")) {
        for (int oppWosqbGOgxvmS = 1740636537; oppWosqbGOgxvmS > 0; oppWosqbGOgxvmS--) {
            PqqUUJ += DMVbztW;
        }
    }

    for (int BuOTeUOBfMNhU = 935200197; BuOTeUOBfMNhU > 0; BuOTeUOBfMNhU--) {
        HLjnShXiadLc += HLjnShXiadLc;
        WQIQcwy += WQIQcwy;
    }

    for (int LhdbxXlN = 311349275; LhdbxXlN > 0; LhdbxXlN--) {
        WQIQcwy /= PqqUUJ;
    }

    for (int aSgwf = 194804827; aSgwf > 0; aSgwf--) {
        pASnzKkLtdTmZBPH = PqqUUJ;
        FGwJQTDwhG = HLjnShXiadLc;
    }

    if (DMVbztW > 134835430) {
        for (int sVAcGw = 741361555; sVAcGw > 0; sVAcGw--) {
            FGwJQTDwhG = QnQKTxbwrHBcG;
            WQIQcwy += WQIQcwy;
            FGwJQTDwhG = QnQKTxbwrHBcG;
        }
    }

    if (FGwJQTDwhG >= string("VTSoJHBJqXNIbCTnWrxjWDGlHHTqPIZOZOYIupxcHsOipAIDkWhNzNBortUjmxZWJLbmHSSZBkQzmKXoYuyxNgrheKDoSrpIirqTvLhFNzOQITPDHDZhzOuQDoskwhYHvBwxlNIxCyurbSizGfWybsnQNMuiBOVVjKBNlHCvPfvCPGDbXEtQxcHvLmSSEDIYEKRGmrZMfPkioMQFgratmMpZpvJZSungAeDkVLYybjqFrlowMtcHNug")) {
        for (int NufVNT = 738137284; NufVNT > 0; NufVNT--) {
            continue;
        }
    }
}

int nyuuH::SOXTxYtUF(bool IbgYhNCzISy, int ZJkhibEfTIL, bool YoCZqrxKWv)
{
    double xiIWzIfrU = -71177.90244381697;
    double iwGTzl = 661249.0283730526;
    bool XyzDjoUQc = true;
    double asgKqeXt = -809468.981754541;
    int zOxmidaR = -1682085266;

    for (int UGPWNMg = 1602443835; UGPWNMg > 0; UGPWNMg--) {
        asgKqeXt /= iwGTzl;
        ZJkhibEfTIL -= zOxmidaR;
    }

    return zOxmidaR;
}

nyuuH::nyuuH()
{
    this->fUcdYSKBR(string("cEElnYdWCpHvoFMQLVCkllJkjhKqibovAhgfsJAhUDgYAqkJZNyeApqyvxWSbvlQExbfiYkUyzjmWKmeHODbYPqIksYDUmybTwHhJfJBcHrOSkvbpOjjphRAJgMOiIiYDkhBcWiLuyfsdbrMJWVopJnXLgyvDjic"), false, string("wuEXApxltqubSxCJNUjfaZeoUQJGiZSdMeFRgbtLDdWwEmkIXqNYCSuJxUjiOHcjGnbvlOCZEJGGSGXMOJosEbQNfOGWwYLqKmXcSyBdBIZoTyApRHGTFFbRwwqgIxQhrIvFBCJimDNhHtRCxTCFnVGYFgUXGmfxbhnpwbbbMbNpIbdGmevQduDoRelyKPSoiOslcPFTwUpRDWxnJqMJSUpjjbvfJOhqJUcSduzTliyWMCFuiVMZoXuGUfxj"));
    this->KFZjamAQmgunTY(1027837954, true, 106494.0274095762, -900173.0771690938);
    this->zAHYGUsd(242394.0311605695, 368010.74319993623, string("xkUctYUtJtDMTcod"), -352877.9931315209);
    this->hvqCuZhsNrO(-1716350581, string("AZJvnAnlXQJUgDaPGzwVnXyRuoHtgRrAtaTlXSObFpLygERUrOMkpRnPsPMVXkbHeKnYAFHFpYwXGSHVkNkkGLVXGkrMPVDNTyvIz"), 649627643);
    this->lVqGlcWQiRlVb(string("ROE"), 62661.62173061035, -383828578, false);
    this->DOAsHABSEKEk(378496.5367531283, -250827.43795951296, -684752072);
    this->zAxfIgUoypTZAVki(-602253.5216526164);
    this->XWrZRcklGSQyfY();
    this->EOQfx(-167455.53155044813, false);
    this->XAemxYSL(string("XHvKjdnQZZwyGrRUfuIMntSGhcdnjxYGBLOELYmTDLIabDQaKvBjVHTExojFuOeZDEsrMSGsJzhMsvjfNjwkmbLjsXFhyBspbxnKJIUtiWplbFWWSEXeuwIRVIswdMXGnzHaGcbEhjnechXuazfiOrGeoTmPCMP"), string("rqCZIzkZoPCmYOboPUfRjbqAXPgKKHmlLasVCygpVVQlklCpaZQvpJsgzyIzfIDyhItTZjsZyXCCshEUZfUrIfynKtNXgT"), true);
    this->vfEVPNxvEbeYNbls(true);
    this->OUOfBWvU(-310488906);
    this->fYnuumJcnGCY(-947094.2280210472, 595431.3827246563);
    this->huCugj(1986218417, -1593146961);
    this->SOXTxYtUF(true, 248914599, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KjsZpInvtvpBrgPD
{
public:
    string rbjYLPMLaqNWffc;
    string MnHEf;
    bool ZNWbSGaKCHWfkxy;

    KjsZpInvtvpBrgPD();
    void tFkpmb(string HyyFsE);
    void UtMzlJxikxRnvEHN();
    void xscAxTnJOcQl(double RBwRj, int aFZeoTFBEq, int HjEGGMcPEhVR, bool EStLvwrQT);
    string jAhPKHPRsotC(int irJftSnf, bool bMuIGrqMJNMFZHbc, bool frUPF, int bMSEiuVnBdI);
    int zxPsB();
    void LDLxBSbKABPvQmhh(string DRsMcGPwQvcjJhB, string ejZQNbknZzsdZ, int HmVyUoyLte, int opSajmpZoNM, int FeGLYYohhkDhnY);
    double nuLiniamUicz(string VMbtAyf, int PinGsgR);
    double dcOcfssdO();
protected:
    double RaEZcuMiGDDkMJ;
    int cjxtpHfj;
    string etMxyzhQIgs;
    string wVvQAYjHd;
    double YyiXvgwadLQzO;
    int WSlxYzoqEduZ;

    void guAfGxlRKBoj(double LMbuX, bool hqSHAGV, string ZFVUjDb, double WvNmdn, string zzmCwLWGxHnkaU);
private:
    bool kbeqGFehNMIKz;
    string lByVLYy;
    string VfeoJXPZtruqRP;

    bool QkUInISPhhYiwdOP(double QndoIigmXi, double gIhpUxZ, int rGkWTJQjdvscRU);
    string pMTWKehw(double ZISVvxvfPQMW, int zJtVKtJTEnc, int VLflDWTE, int KRDwehqvNL, bool EYvKsWqHyASvpKI);
};

void KjsZpInvtvpBrgPD::tFkpmb(string HyyFsE)
{
    bool dwBGXRYbVx = true;
    bool uaUdvHhbvR = false;
}

void KjsZpInvtvpBrgPD::UtMzlJxikxRnvEHN()
{
    int ZdASspkHvJAaVzLf = -9123850;
    bool zeNQKwS = true;
    bool BPPWgPTfMuvzvu = false;
    int peBdPoeVkKwPOJEt = -1769819345;
    int YVcYZwnNQBrYR = 1065087509;

    for (int nMJbKPUIlSlWMQ = 2131754266; nMJbKPUIlSlWMQ > 0; nMJbKPUIlSlWMQ--) {
        ZdASspkHvJAaVzLf += peBdPoeVkKwPOJEt;
        YVcYZwnNQBrYR += ZdASspkHvJAaVzLf;
        YVcYZwnNQBrYR += YVcYZwnNQBrYR;
    }

    if (peBdPoeVkKwPOJEt == 1065087509) {
        for (int nCKueCaKU = 1986080048; nCKueCaKU > 0; nCKueCaKU--) {
            YVcYZwnNQBrYR = peBdPoeVkKwPOJEt;
            peBdPoeVkKwPOJEt /= peBdPoeVkKwPOJEt;
        }
    }
}

void KjsZpInvtvpBrgPD::xscAxTnJOcQl(double RBwRj, int aFZeoTFBEq, int HjEGGMcPEhVR, bool EStLvwrQT)
{
    int kStMGwvEa = 334516641;
    int FqtKzk = 1429372780;
    int silSTcpnQBerTy = -247692864;
    string rzQyICcUaZuzOK = string("ISAVzfDvdzDgauLhYJjayIozkiXjrCguHtVYkmAoJmPhdCzOrCJVFfIfwUozAhhnKKfnNLjksndWBKBfEhakgCmuTZIriaatiMbZTSUrZHAsazAIBGxEYnpaOPRXRswGwPvEieNJVxSzGIBg");
    string YTVkYPfvufjlisoU = string("hBrFvhJrizklyoRjeISikyxPwfKGlZclFyXqbuiTNbtWhAHvqphCrfWtsGtMpIXELuugwhdwiqVrvykuJIqBPojdqGDlciAHsPqzUITNWwGYqeWoeUOZrragwIEoRiBRSmtFdSJctKBBTLciSiduytdhZEmGKRXZzbfVnowkManIFIAcDyMYmnZcFQCWFUhjzgvmzPNNZPPzWuMuSAVZCaAbmhnRAPiEVxwoVlrsWLDFZHvfXSK");
    double WAVKdctUBihqZVjU = -2171.55219221707;
    double vzfOD = 1037568.1931442849;
    string qxsJBeaGX = string("nKxnKJYelxtFFQkhrnEWVjZzqVlMtwvmRYQIHjrWqeRWhbBEzqYcUnvQUcIWhomHjRTmjgwmwUakxHZgMdJsoLedXmdfAkGKeRdeyXNGtTyyNdpZyLjbaWZgMTtzUyLPxigSoLGLSyyVkJbvoUylLtbPbUwhavfEUYbaCsmAHmzGvKYezvcyxTeKNLiWfywBEKNJfHrFREnunWclZVcxN");
    int AcgBFHsIpd = 1100117833;

    for (int rZaKKWzI = 1935978240; rZaKKWzI > 0; rZaKKWzI--) {
        continue;
    }
}

string KjsZpInvtvpBrgPD::jAhPKHPRsotC(int irJftSnf, bool bMuIGrqMJNMFZHbc, bool frUPF, int bMSEiuVnBdI)
{
    bool FWoQoMO = false;
    bool qIIcD = false;
    string Hsgsi = string("boTmjZJGICxsQKSeQjFuXPXkMmoTRXsYfoxPMZhVVAoQsHwhAtKKyzdowzHixghonwEPRVU");
    int oZyuobaYHjQrJclh = -91128620;

    return Hsgsi;
}

int KjsZpInvtvpBrgPD::zxPsB()
{
    double TCALs = -616165.3882185741;
    bool qhuFpzkN = false;
    bool FGoHlldbSzz = false;
    bool IkQZW = true;
    int mTjuvagtK = 1713930549;
    bool ngyiFm = false;
    double deAWIvjhIos = 605208.6552547498;
    int TqcSoIKQm = 710431701;
    string dblOpusD = string("rECGPCeAffpdmLwPRvZzGYnRyzPYmXkuBlzLMbbkjnWOifckzdcK");
    double WkmOCMUQkFn = -171474.4466566275;

    if (IkQZW == true) {
        for (int JoLbdaHxBze = 1923480520; JoLbdaHxBze > 0; JoLbdaHxBze--) {
            ngyiFm = ngyiFm;
        }
    }

    for (int WsGGJQj = 598979615; WsGGJQj > 0; WsGGJQj--) {
        TqcSoIKQm *= TqcSoIKQm;
        ngyiFm = IkQZW;
    }

    if (IkQZW == true) {
        for (int hTINoAIcbbXAl = 1733081527; hTINoAIcbbXAl > 0; hTINoAIcbbXAl--) {
            WkmOCMUQkFn -= TCALs;
            dblOpusD = dblOpusD;
            ngyiFm = ngyiFm;
            deAWIvjhIos = TCALs;
        }
    }

    if (qhuFpzkN == false) {
        for (int MTDjPMXX = 1360640472; MTDjPMXX > 0; MTDjPMXX--) {
            TqcSoIKQm /= mTjuvagtK;
            TCALs /= deAWIvjhIos;
            WkmOCMUQkFn -= WkmOCMUQkFn;
        }
    }

    return TqcSoIKQm;
}

void KjsZpInvtvpBrgPD::LDLxBSbKABPvQmhh(string DRsMcGPwQvcjJhB, string ejZQNbknZzsdZ, int HmVyUoyLte, int opSajmpZoNM, int FeGLYYohhkDhnY)
{
    bool JYnCgfgHaXdXr = false;
    int DERaRIVdfikOrhyM = -741684197;
    bool WuhUrqrhsWFxwzU = true;
    int gWneziYSKoYEuExP = 2145289951;
    bool FzaQMm = true;
    string QNqtSjS = string("eZpnSmtGYNyWKpwalJIAdbBKLIDUWpMUbrMwyyWAqNHDkNZvrFITuvMcsjvppgpqLzxEPXQYBgSKgVJBlbcvYTsVSLmnRWFErpduRhvLRVcj");
    double ssLGDVJYWA = 132188.8319740072;

    if (HmVyUoyLte != -329126052) {
        for (int nOBFMHEjhl = 2130254852; nOBFMHEjhl > 0; nOBFMHEjhl--) {
            DERaRIVdfikOrhyM *= DERaRIVdfikOrhyM;
            opSajmpZoNM -= gWneziYSKoYEuExP;
        }
    }

    for (int udVpR = 83219995; udVpR > 0; udVpR--) {
        FeGLYYohhkDhnY = opSajmpZoNM;
        HmVyUoyLte /= opSajmpZoNM;
    }

    for (int rNdsTekXzgIheg = 1017224047; rNdsTekXzgIheg > 0; rNdsTekXzgIheg--) {
        JYnCgfgHaXdXr = ! FzaQMm;
        HmVyUoyLte = FeGLYYohhkDhnY;
    }

    for (int OVWEqqUUqEdSte = 1508347782; OVWEqqUUqEdSte > 0; OVWEqqUUqEdSte--) {
        DERaRIVdfikOrhyM -= FeGLYYohhkDhnY;
        DERaRIVdfikOrhyM += FeGLYYohhkDhnY;
    }
}

double KjsZpInvtvpBrgPD::nuLiniamUicz(string VMbtAyf, int PinGsgR)
{
    double OJokIe = 648898.6953553762;
    string nLlUMWuQQfX = string("ccSRgdjQTHKDUaFfCZb");

    return OJokIe;
}

double KjsZpInvtvpBrgPD::dcOcfssdO()
{
    bool vKMZYvm = false;
    int PRmmxXr = 2099593112;
    int pJhsG = 1928918382;
    bool GZDxcIQUQmSDmrX = false;
    double KuxZPnIutIOffsp = 336820.8324343704;
    double plQMHNAykrikkG = 973652.3211189231;
    int WLRhavAq = -271875975;
    int jfnBMDHhfJJvweHb = -2002150077;

    for (int DXLKAMzuGrkVxdS = 1707059676; DXLKAMzuGrkVxdS > 0; DXLKAMzuGrkVxdS--) {
        continue;
    }

    for (int fZkZHvFWYUv = 1625580177; fZkZHvFWYUv > 0; fZkZHvFWYUv--) {
        jfnBMDHhfJJvweHb *= WLRhavAq;
        jfnBMDHhfJJvweHb = jfnBMDHhfJJvweHb;
        WLRhavAq = pJhsG;
        WLRhavAq -= jfnBMDHhfJJvweHb;
        pJhsG -= PRmmxXr;
    }

    return plQMHNAykrikkG;
}

void KjsZpInvtvpBrgPD::guAfGxlRKBoj(double LMbuX, bool hqSHAGV, string ZFVUjDb, double WvNmdn, string zzmCwLWGxHnkaU)
{
    string KxLXharyCbNjxuCU = string("VmfNalttnkLNfHhMNAtSZkcvQduMXEpwitsxjKueCujYuHYZdDrWDpdKeuWyKGAfrZSNqaxZXQUgTWohDHkJbHfGmzwEdngbEjJnShWUeMKPUEvLgqXnAewlsvtBeCyEcXnTAmBSyFBQJiEgoQSXMJTwufAMNdadwtajjIHEuHLJptKspNapYAyLVYAKQhMDEXnnvinKQybSsCFxKuzHiUby");
    bool MZKhIdY = false;
    int yepKpJOVoMdTXDa = -1577045270;
    double GObZaxpC = 812625.360946013;
    int AoVoXgIzdgzxoeT = -1236305902;
    int nhtOoqqMpej = -1435793822;
    bool pfkDlkdQg = false;
    string uvXEKQ = string("mnIvkJUJqHmnfRxoTNAoWulciSmtJndimfENNbsxaAucguDvzSgRUhZIrzjAhRAYNtfFTqDYImzgTVVxfxnCAPvlgJpZVOcPYgworqsYhUiygVbdBWtnvohBDYJfOwvfkmNvjXLwbXSEAuErGhaJycxZCjNqQabfNnTRiK");

    for (int chPkp = 1963995703; chPkp > 0; chPkp--) {
        zzmCwLWGxHnkaU += KxLXharyCbNjxuCU;
    }

    if (AoVoXgIzdgzxoeT == -1236305902) {
        for (int WXzmWdbRW = 1844714179; WXzmWdbRW > 0; WXzmWdbRW--) {
            KxLXharyCbNjxuCU += KxLXharyCbNjxuCU;
            hqSHAGV = pfkDlkdQg;
        }
    }

    for (int thSmnF = 726864262; thSmnF > 0; thSmnF--) {
        MZKhIdY = ! hqSHAGV;
    }

    if (GObZaxpC != -99604.2730380487) {
        for (int IxBqWphkj = 1305944724; IxBqWphkj > 0; IxBqWphkj--) {
            KxLXharyCbNjxuCU = ZFVUjDb;
            nhtOoqqMpej /= AoVoXgIzdgzxoeT;
        }
    }

    for (int xdipOH = 1136487779; xdipOH > 0; xdipOH--) {
        yepKpJOVoMdTXDa -= AoVoXgIzdgzxoeT;
        yepKpJOVoMdTXDa = nhtOoqqMpej;
    }

    for (int fugaKNTJwJGQ = 54320120; fugaKNTJwJGQ > 0; fugaKNTJwJGQ--) {
        KxLXharyCbNjxuCU += uvXEKQ;
    }
}

bool KjsZpInvtvpBrgPD::QkUInISPhhYiwdOP(double QndoIigmXi, double gIhpUxZ, int rGkWTJQjdvscRU)
{
    string WJzkkmBHw = string("mGLAZNTZlfENSfORpoOqigqgfBViRBfWBTsPGpHC");
    int XTIaVEaWm = -151302800;
    double amQlcGknzfuqe = 464683.2984486206;
    int nGKXS = -1876325308;
    string CjctlmCOsLMDGRf = string("PHuifcfRRomCzkyMyefVjENrpNehyHZYGXBwoRZMJnvQGGLFbwkBgNFbAgAIOveAFYqdYOyMHZBbZIxndqHtwFNNbrmlBVBFlVTaGthXMjnxXRCxywgiXcPbPoYXSgGXkyPasEOBg");

    for (int wvDuEDba = 738426684; wvDuEDba > 0; wvDuEDba--) {
        WJzkkmBHw = WJzkkmBHw;
    }

    return false;
}

string KjsZpInvtvpBrgPD::pMTWKehw(double ZISVvxvfPQMW, int zJtVKtJTEnc, int VLflDWTE, int KRDwehqvNL, bool EYvKsWqHyASvpKI)
{
    double SyCIaYkxCyH = 251249.04711107662;
    bool NGCwiWTzOytzN = true;
    double KAsPWFov = 324957.9442268444;
    int uSKpA = -410658949;
    int LISiwElINTPfpg = -698677261;
    string zjfTw = string("ywDnoUsqFzZFqIENiRqbFCuRSQqqIwtqqglTJOlemgTzLNKwbsPAQJaZPqOcunuBcfCtUgjHADKdZkuhxFStGnOzYeGLQmDqapSVksxUbKRByYduundOSRzSVTBjBVjhPzvMmZoTYKtXYRAAtRWDFEHFRIZXOimdLOUkhgfqnzobXmiehDVGZigJSpMlyUrNzHJoBLbQnGjlnsqoPbdPYiIeDxXgjwksUvtVSEGRH");
    double dZgolxyidYKUczA = -444323.0760541142;
    bool BSHjgKdIqsfLAyrX = true;

    if (KRDwehqvNL < -698677261) {
        for (int WGWCGCqcKMHjIbh = 1687568664; WGWCGCqcKMHjIbh > 0; WGWCGCqcKMHjIbh--) {
            continue;
        }
    }

    return zjfTw;
}

KjsZpInvtvpBrgPD::KjsZpInvtvpBrgPD()
{
    this->tFkpmb(string("tLWamMNAEMVvcXWxiMGhfDbNQosbFZpzGJALDpMDToVTOylCeGWPcFcFENbqhBNPNROmkCBBdvjZFtAUcpJDOQJvWaegMkrLKJWqpoagwqQjgjSYXCCoRGjCIjMcGHhgPPpSksbsKolUyABvxUuwUiuikHHhNrKSgYZceAlQqEyMHRRbXMQrxXdQjK"));
    this->UtMzlJxikxRnvEHN();
    this->xscAxTnJOcQl(-134212.53595812203, -1357651977, -1451935647, false);
    this->jAhPKHPRsotC(-1072074933, false, true, 1661939145);
    this->zxPsB();
    this->LDLxBSbKABPvQmhh(string("IDbjxuFipVktiYMaFUkKaxgJIonMWRmEXIxOWcNfztnbGhiphWbxerJRNtmwsDVODVsPRhruWgTfhaxzIKwSLrmfwtDYaWkJGRqRLRrKHMPKewSnjj"), string("NnKMYugtebKBYCvDycpFEfatLpLQYEschLDjKWrAVTuTQiXJjzmceqTfjKKfggCGSvnfHatrPOuEXVuNDibvVLyaQsJDkDkNSAtmNudEMZQrYFxGKPIYHvVotJSNnSBvdJChkXtQFPmxLlPvzLnSuSGkBhjCPiTBldhjIdsQenfXR"), -454905840, -1635591362, -329126052);
    this->nuLiniamUicz(string("DLrCtOrQWyHMAevIvZJGWQSOLhakvaPVJZWOVhpbzMJYacadABAyIiAoYxsWSJcCwygFgNAeOFNMMFyHQrRIgkQYPDIytdRBoPmzCaXUPsctCJxDfBkKVStRXkJHXMTGSOX"), -1218821219);
    this->dcOcfssdO();
    this->guAfGxlRKBoj(511706.29208413535, true, string("JkIjWKpguYaacHxYjPqmidJjvKbLYSxgUyIuUPFPQuhxAfrBVxbEGiTqGdDBhKvpaqhYSFQOuDREYGAnsbTcjzNHERefQWOTVmlAlNMtELujXdERgbNgusoTEiHeSfhXhKfcHXXrcUgBPeBekvIMdtkXtMenxgaWFntkhChJLFLtnsraclHQRNKmmMoYpSNpgLDzwEemwwCDbLmMCvryZRWEvnPWwNaSsKexz"), -99604.2730380487, string("YjKbvYKZwpvFpQobUhlarjxsurSRbwBcJjYFGmPJzxlMgmAuPFMYzeWslnohfsJEHjppXINujwAKrZvMHvCvakWpsHdeSeYcfPkcSrAkYOVjekhVzWITsQTBwmwxrdmaxxzsPxXmOnGEHRtOIJHnTtmVgObMcECWWQJduFFDcAKCvmxbzmLmgLRxTT"));
    this->QkUInISPhhYiwdOP(-607978.1966515887, 448811.84289944835, 480150413);
    this->pMTWKehw(896145.5578447178, 64480486, 1240212021, -53787735, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SttIvniiQLjZis
{
public:
    int ArZuJTcDyAbYU;
    double LfWWIsJoExlUg;
    int TwTvR;
    string hkrmVrFPbUEluNY;
    int ZVwWHederyPsUT;
    int aacGwZRtL;

    SttIvniiQLjZis();
protected:
    int pKIMPpU;

    double TIylcXzBvfuVaD(bool BNnAztV, double OyaZepBiAw, double GkCgmWn, int YYbaDgUxuIb);
    int zQBEayjBqRiG(string ayYoPZxfHIcOc, string aJJHKmCKEHBnvu, int nWrfyVKDR);
    bool UELBpeV(string WXrMXy, int YExvxJbyCNj, bool WmOnTnoLPug);
    string iKlBqXzijs(string sGTygF, double DHngk, int DBAWY, int dVguVMNShsMzdr, string EgmzzMkKJbJBnyE);
    bool wWRagn();
private:
    string pmDUgxIRm;
    double bEKkJbpxyzVgMVao;
    double WQwxgkMsebLpr;
    string VenwbNTW;
    int OskAwSt;

    int jASFmSmI(double onjoaIABviv, double dRcVeweOE);
    string bcAMOfMkZGI(int oeIva, string LViRh, string jbsqsg, double zlrULkJAa, double mLJEd);
    int UneoWYYT(bool uLiSabud, bool RgStCSGlquFRee);
};

double SttIvniiQLjZis::TIylcXzBvfuVaD(bool BNnAztV, double OyaZepBiAw, double GkCgmWn, int YYbaDgUxuIb)
{
    int vLQSqXi = -1732623017;

    if (vLQSqXi >= -1732623017) {
        for (int WVherrHV = 1986652451; WVherrHV > 0; WVherrHV--) {
            GkCgmWn = OyaZepBiAw;
            YYbaDgUxuIb = YYbaDgUxuIb;
            vLQSqXi -= vLQSqXi;
            GkCgmWn /= OyaZepBiAw;
        }
    }

    if (BNnAztV == true) {
        for (int WOWLYnbvriDLD = 739754354; WOWLYnbvriDLD > 0; WOWLYnbvriDLD--) {
            YYbaDgUxuIb *= vLQSqXi;
            vLQSqXi = vLQSqXi;
        }
    }

    if (vLQSqXi <= -302956356) {
        for (int UbIxAYaO = 809829169; UbIxAYaO > 0; UbIxAYaO--) {
            GkCgmWn += OyaZepBiAw;
            YYbaDgUxuIb -= YYbaDgUxuIb;
        }
    }

    return GkCgmWn;
}

int SttIvniiQLjZis::zQBEayjBqRiG(string ayYoPZxfHIcOc, string aJJHKmCKEHBnvu, int nWrfyVKDR)
{
    string gkyDQUuOjpWmx = string("RcEBmjCRDpWnviAqNymSJalSybZteBYuWeOtuLPMxaHqbbCJYnvIMGqgjuEAU");
    double cFHDsihaAt = 554652.8296509528;
    string aBfbzpIi = string("JBnyIYwfOFvHCJzqcyaQiGXNJjWoFTmXrPPlFiQdSOKbUAApnKeUyeEchQQdODuucSTpuQFfsZkviozejs");
    bool MIMUrhFAzdWmV = true;
    string GNkKSJDGRQf = string("zQoytXnNovKLjZVeQUafcVcMvKGFDtfemZmEJUUoGJIfgPjSmQtXCjXLRKjHnORAEHIQDoDDbEDXRkQzGRUgzGzBcEiY");
    int UJiNXSoazEcDcFB = 1809418499;
    bool TNpLXrOObx = false;
    double kPDxm = 877781.9978457446;
    string XEqoeDLEZJHiLWbv = string("rshTUPlxgUwMVEMWQNPrrULsRCrvooTkIvGQnKNorgDQHaBxSJHuLBKlHFUFVvYaCTWGkWEGIhxuzZLCeVcmROZnqfcDHPqdIeBgwoqrzHXvCBPbxlkuxCjOGdfnQEHBr");

    for (int ORjTpucWDuULVGyH = 1439474063; ORjTpucWDuULVGyH > 0; ORjTpucWDuULVGyH--) {
        cFHDsihaAt /= kPDxm;
    }

    for (int lmeLAPToculs = 2105047534; lmeLAPToculs > 0; lmeLAPToculs--) {
        continue;
    }

    for (int kBarYxXmFnSzKPR = 549494750; kBarYxXmFnSzKPR > 0; kBarYxXmFnSzKPR--) {
        UJiNXSoazEcDcFB += nWrfyVKDR;
        aBfbzpIi += XEqoeDLEZJHiLWbv;
    }

    for (int fGbvukhaGEIIq = 1039789367; fGbvukhaGEIIq > 0; fGbvukhaGEIIq--) {
        aJJHKmCKEHBnvu += gkyDQUuOjpWmx;
        ayYoPZxfHIcOc = GNkKSJDGRQf;
    }

    if (ayYoPZxfHIcOc >= string("axEywJHWgVDIw")) {
        for (int RTraLLxtpOJm = 1901113665; RTraLLxtpOJm > 0; RTraLLxtpOJm--) {
            ayYoPZxfHIcOc = ayYoPZxfHIcOc;
            aBfbzpIi = gkyDQUuOjpWmx;
        }
    }

    if (UJiNXSoazEcDcFB <= 515941124) {
        for (int WXlSFc = 1831352121; WXlSFc > 0; WXlSFc--) {
            XEqoeDLEZJHiLWbv += aJJHKmCKEHBnvu;
        }
    }

    for (int MXbGSzWJDrCKl = 244765952; MXbGSzWJDrCKl > 0; MXbGSzWJDrCKl--) {
        continue;
    }

    return UJiNXSoazEcDcFB;
}

bool SttIvniiQLjZis::UELBpeV(string WXrMXy, int YExvxJbyCNj, bool WmOnTnoLPug)
{
    int NEODtkNOSfyM = 2106610236;
    double nXqnRsgEjBo = 945790.5070932687;
    bool UidqOYwIWEPnEKt = true;
    string bzxcDEiYUWklituO = string("BEeanIjeuHYGIyZuhrTkhUfSNmgUoraiLukGubcdKkPVwMJcPvdIoYhEvQgSbTEznfDsjarzaWToXrAXWqTmPziGpgEtSPJVOSsOfIkVJnDwZJPtuPedsKPU");
    bool OHRhkehRqO = true;
    string CXGKcpc = string("ZlYBEApCaUYivCROetOJdyOINuSNcuqbAMMCvIQEdNEjwQMgalgQCbbAjaUVlqPZVGCXouSzkSXqyNDLLMtzSpgvvAIIWbKklOJQwFngOXKuSxpdGDndvKSBCQFIhsUrILFvwgdGxsUlorPudFIWWwVxQstrzavadVAffwHFRvfiTgs");

    if (NEODtkNOSfyM == 2106610236) {
        for (int bBlBfYZX = 2118552667; bBlBfYZX > 0; bBlBfYZX--) {
            continue;
        }
    }

    for (int WrxUlkMSfZfKrPY = 594978708; WrxUlkMSfZfKrPY > 0; WrxUlkMSfZfKrPY--) {
        UidqOYwIWEPnEKt = ! WmOnTnoLPug;
        WmOnTnoLPug = WmOnTnoLPug;
    }

    for (int elgIs = 2000289864; elgIs > 0; elgIs--) {
        WXrMXy += CXGKcpc;
        WXrMXy += CXGKcpc;
        bzxcDEiYUWklituO = WXrMXy;
    }

    if (CXGKcpc != string("GXSEFGqNFyAhCINaFAuucnFHKFAzfOhGUuXVnqMzdXecRkXCjzhnijvQJyQDvGyXEBmqWtxVYoyrVFLiMygGqvovYvBlPuoYOxKtJfDyNjdGxVLlfDUhObZ")) {
        for (int KENaSUq = 193135762; KENaSUq > 0; KENaSUq--) {
            OHRhkehRqO = ! WmOnTnoLPug;
        }
    }

    for (int rxtbhILQPkQeiP = 34897847; rxtbhILQPkQeiP > 0; rxtbhILQPkQeiP--) {
        bzxcDEiYUWklituO = CXGKcpc;
        bzxcDEiYUWklituO += WXrMXy;
    }

    for (int DjZHemnsAwS = 1314701765; DjZHemnsAwS > 0; DjZHemnsAwS--) {
        continue;
    }

    return OHRhkehRqO;
}

string SttIvniiQLjZis::iKlBqXzijs(string sGTygF, double DHngk, int DBAWY, int dVguVMNShsMzdr, string EgmzzMkKJbJBnyE)
{
    bool vDzGobleDAKj = true;
    int adzuoMmAOJMg = -1422658445;
    int erhPM = -1593341602;
    int JfOJusLF = 852771210;
    double pgEApSBCUuPVK = 856016.0317438483;
    bool KbjGwisvE = false;
    double LYPlnIqpCk = -772701.4984247827;
    int UCEwnXiGpQFBO = 1094526883;
    double uWYhWrrsZjqJEDMI = 615708.7930278175;
    bool qbDgSAK = true;

    for (int KsuOodY = 480849307; KsuOodY > 0; KsuOodY--) {
        continue;
    }

    if (qbDgSAK != true) {
        for (int ahdevwJ = 367234033; ahdevwJ > 0; ahdevwJ--) {
            KbjGwisvE = qbDgSAK;
        }
    }

    if (vDzGobleDAKj == false) {
        for (int BkwLllmHCibfO = 1554652635; BkwLllmHCibfO > 0; BkwLllmHCibfO--) {
            DHngk += uWYhWrrsZjqJEDMI;
            dVguVMNShsMzdr = JfOJusLF;
        }
    }

    if (uWYhWrrsZjqJEDMI == -352598.4446457365) {
        for (int PpoqYKupLS = 1899768829; PpoqYKupLS > 0; PpoqYKupLS--) {
            pgEApSBCUuPVK *= LYPlnIqpCk;
            pgEApSBCUuPVK /= uWYhWrrsZjqJEDMI;
            DBAWY += dVguVMNShsMzdr;
        }
    }

    for (int xkITiTP = 1041587463; xkITiTP > 0; xkITiTP--) {
        DHngk *= DHngk;
        JfOJusLF /= JfOJusLF;
        JfOJusLF -= erhPM;
    }

    for (int mfPHmcBVtMNUJ = 445057777; mfPHmcBVtMNUJ > 0; mfPHmcBVtMNUJ--) {
        EgmzzMkKJbJBnyE += EgmzzMkKJbJBnyE;
        DHngk /= uWYhWrrsZjqJEDMI;
        DBAWY /= UCEwnXiGpQFBO;
    }

    for (int sQdsgoGhcTORQkS = 99170176; sQdsgoGhcTORQkS > 0; sQdsgoGhcTORQkS--) {
        qbDgSAK = KbjGwisvE;
    }

    for (int IDzhASn = 961755986; IDzhASn > 0; IDzhASn--) {
        continue;
    }

    return EgmzzMkKJbJBnyE;
}

bool SttIvniiQLjZis::wWRagn()
{
    int HsNnZMxtx = 1406643826;
    double eZmOEkeNemXAd = -452923.012561209;
    bool vMnXeEkFFxsJBl = false;
    int utUjXyMOpf = 197770245;
    int xWljrJMgpghyqM = 1076626001;
    double PGFHebpdbEvCtMKB = 554274.1630943979;

    return vMnXeEkFFxsJBl;
}

int SttIvniiQLjZis::jASFmSmI(double onjoaIABviv, double dRcVeweOE)
{
    int jAOtYhGYlvYQ = -2053010510;
    int tcmaxGTnRG = -931197009;

    for (int sijNLoZiAp = 1576405885; sijNLoZiAp > 0; sijNLoZiAp--) {
        jAOtYhGYlvYQ -= jAOtYhGYlvYQ;
        jAOtYhGYlvYQ *= jAOtYhGYlvYQ;
    }

    if (dRcVeweOE >= -997549.478843314) {
        for (int kyTiOZh = 570511182; kyTiOZh > 0; kyTiOZh--) {
            jAOtYhGYlvYQ = jAOtYhGYlvYQ;
        }
    }

    for (int ASGisARHCb = 792036888; ASGisARHCb > 0; ASGisARHCb--) {
        tcmaxGTnRG = jAOtYhGYlvYQ;
        dRcVeweOE /= onjoaIABviv;
    }

    for (int XbqUTXjHWb = 156809251; XbqUTXjHWb > 0; XbqUTXjHWb--) {
        tcmaxGTnRG *= tcmaxGTnRG;
        jAOtYhGYlvYQ *= tcmaxGTnRG;
        jAOtYhGYlvYQ -= tcmaxGTnRG;
        jAOtYhGYlvYQ += tcmaxGTnRG;
        jAOtYhGYlvYQ = tcmaxGTnRG;
        onjoaIABviv = onjoaIABviv;
    }

    for (int jEMEhvxu = 15630234; jEMEhvxu > 0; jEMEhvxu--) {
        tcmaxGTnRG -= jAOtYhGYlvYQ;
        tcmaxGTnRG -= jAOtYhGYlvYQ;
        dRcVeweOE = dRcVeweOE;
    }

    for (int fyZXL = 819373173; fyZXL > 0; fyZXL--) {
        tcmaxGTnRG *= tcmaxGTnRG;
    }

    return tcmaxGTnRG;
}

string SttIvniiQLjZis::bcAMOfMkZGI(int oeIva, string LViRh, string jbsqsg, double zlrULkJAa, double mLJEd)
{
    int BrChzNJ = -1054043897;
    double EzunmtpbTqrgxq = 798025.3407397713;
    double ewKWToUwZnvW = -900598.2749515775;
    int ZsUQjb = -1298672827;
    bool namCsstgpnKp = false;
    double VCDip = -476068.57120468665;
    bool yxhjZKdjzwWiSjtp = true;
    bool KVBWwinCsJQRGf = false;
    string nUFSNcFcteOh = string("JrQXKwjEntZUMIAXYHHZvbEgOXsGQevyitsNXDTPvVcpAHoXIrUsOghrIRwXwStJIQWvqMYwVioLrMaIjVzjCHoUzcfVxmPoFmsrQjZxSVVugmmCBtcJxWMJuQhpxgJHNKFMpavZyvthejZsGwOUBfBsXJWgTcbbnRODsxzZRpkuHhlIuYityreZyBvVixTpESWIGQtSvWfrdYhvWFnByBblLlVHYYbxzHcppYBeJrlNksdF");

    for (int pVLzJjwNuRXfXhbT = 1848847991; pVLzJjwNuRXfXhbT > 0; pVLzJjwNuRXfXhbT--) {
        jbsqsg = nUFSNcFcteOh;
        mLJEd /= mLJEd;
    }

    for (int vXtAfGny = 912013151; vXtAfGny > 0; vXtAfGny--) {
        continue;
    }

    for (int ZICBOeAsz = 419258843; ZICBOeAsz > 0; ZICBOeAsz--) {
        yxhjZKdjzwWiSjtp = ! namCsstgpnKp;
        zlrULkJAa -= zlrULkJAa;
    }

    return nUFSNcFcteOh;
}

int SttIvniiQLjZis::UneoWYYT(bool uLiSabud, bool RgStCSGlquFRee)
{
    string BiaCnamANpr = string("LpqFbXnPoxAGzhMaapErJhdQBowomnzcIOkjqiInAmAlszbWSAZfDnhFFEItlEappUsAUaadQPkqcwZ");
    int bCjRlFPzNqNrCsK = 1632157096;
    bool LsRAAZAiNyLDX = true;
    int ACzFDDYm = -196472181;
    double QFUoAjiGfoyMWlM = -278555.95591751835;

    for (int DaJnFmvcSb = 1481335262; DaJnFmvcSb > 0; DaJnFmvcSb--) {
        continue;
    }

    if (uLiSabud != true) {
        for (int tevQQMQnkDt = 437816581; tevQQMQnkDt > 0; tevQQMQnkDt--) {
            QFUoAjiGfoyMWlM -= QFUoAjiGfoyMWlM;
            RgStCSGlquFRee = ! LsRAAZAiNyLDX;
        }
    }

    for (int UyWsUbYcLNS = 178828411; UyWsUbYcLNS > 0; UyWsUbYcLNS--) {
        continue;
    }

    return ACzFDDYm;
}

SttIvniiQLjZis::SttIvniiQLjZis()
{
    this->TIylcXzBvfuVaD(true, -918685.9629503299, -49571.468320198175, -302956356);
    this->zQBEayjBqRiG(string("axEywJHWgVDIw"), string("ZwYCMvXklItqTxsGXIbXrfhxWmJFflwjvdqjEGGPBtBjzPjQPmLudPNqLRRhvgtdBOWstktdHGOExHmjSPikxcnithJXnRQMPHMuFDuBxzVSMFiqzEtycEWozPCxLKtVhYcnJcVELMdoPXw"), 515941124);
    this->UELBpeV(string("GXSEFGqNFyAhCINaFAuucnFHKFAzfOhGUuXVnqMzdXecRkXCjzhnijvQJyQDvGyXEBmqWtxVYoyrVFLiMygGqvovYvBlPuoYOxKtJfDyNjdGxVLlfDUhObZ"), 604062355, false);
    this->iKlBqXzijs(string("zarzsuccMHEjeZoryYESMOnmtEjVkqUpFaZaLTvRVJhqHPFPbIbwvuEybLqysBKycsFUkcPHTpegcuCUzLipSLAvfmYYsphBhOKHdqWMvBUKekIdZoGaIpPdlshzYZjJaKaVUfPILEeCrqljLkkGcNEPnsUOWruBNXODyVTg"), -352598.4446457365, -1342361828, 1386770525, string("UEnGVehaHWiffsizSZiCShLjjyzYajotVgAvmrFOUDApwGRVGPUtTghhcjvnKgyDTWsiUNUvRKbdSQBFakOOvdHAESlysTtpUWFIYjcCaWQpkNPUBvGRnJMBOGpr"));
    this->wWRagn();
    this->jASFmSmI(-997549.478843314, 182186.55154899633);
    this->bcAMOfMkZGI(89029802, string("NhiNOFkJFQKjtAHYNYTIFLGxEDTEIbLuQEYahobMWtSbRNzonSzbuaSMKVCopDVslvJZfigNS"), string("NKrbqmIDDAWAVrHjoJncIWwtNHqNhqzZjhoMymbIKcXedtFPaAxUffJtAhEBtrZsSSpBoSepYgcuAGkhvcgFWaJyRonvKfjKFZzYVmdImknOrjAtHkmBCuDximQxZBOCkQeAmphEziyISpfGtusqGFYYQXsHYvjhClyejuYdUvvQXTCBOyOXrlWcHsxATfslwre"), -375299.5051066224, 81004.99653787853);
    this->UneoWYYT(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MjRhfJlA
{
public:
    string uKKRUcBzCLCYILOd;
    bool obtGlAzqSH;
    int JvihBIviRCNiv;
    int gmwxBLyzBsn;
    double YtjWszrTs;
    bool EAndh;

    MjRhfJlA();
    int eEauhcJVtHYytA();
    bool maFlx(string zGFIgfhJ);
    bool BvbFpFmeSr(double yOogIfxSiYxeCDZN, bool LXreyR, double DDQQgJV);
    void bpZIjMZgncp(bool jOfNPg);
    int oJKxonVIiARaqlwU(int KFoMrCq, string sIuVYXCgM, double JcuFf, string tnxlrdTN, int EKyiCIMQW);
protected:
    double OSUhWjtGiKlDw;
    int zpTSeyT;
    string WsnuQfqjBgFh;
    string sibxuHm;
    bool nRKCfUawCz;
    bool AVAuUVRrUFCfyB;

    bool TuCqQtscZ(double eTOEJotL, bool vCmJtzeo, bool qCxmJ, bool vlyBm);
private:
    string HIjucixKNr;
    bool WxLePwKM;
    int JABaTNChKdVcIuU;
    bool HQwyHKkhalUjmMu;

    string yFNbw(int LiZhUgqziefomV, int sSyXN, string qUJLZTCcd, int WESMaPKJOc);
    int ehMcQ(int gSdffLKaWdEAkgk, double UPbiFnkaibLFrZH, double HewTTVWoh, bool FYPCewGfb);
    double OxGfQXuzv(string AiunQ);
};

int MjRhfJlA::eEauhcJVtHYytA()
{
    int DrTqpZleAIksiVF = 123726202;
    string pLCutaZa = string("trKBrBtwzxFrOvhHADGwcWteYHciXDfXfdXFJWVnZvQbpZpehYbNbmUUVGiEcodSPsWGYNUTeqsXlhVkWlwLrVZMsHSrJTxIqDikevFocYVuYQdlkcoHVRwYcJobpXmEGbRxmnjvcpnUYGqPDOPUKAbmOAsJyOXLYBOszfaQCuAxfRCxfzOdMIKBtezmDUjfhIvBzrpTmOWOrpJoMHorFecrTqt");
    double CNgthIL = -751700.7335492693;
    string YDoersuNDwCi = string("PFmkQVtcIvHBiGcuOGHrPAMUfffNhYAQPmljIMRFHsrDYMgPKIRJtjbPeSHdQDDfnpWYWGSBtUcotxKzDqczdCVhPnoLajCvNzuqGZVAIuD");
    int RhELIxUw = -1423861519;
    bool fVtzwQNFN = true;
    bool QdWcOZIJYKa = true;
    bool xAQqpja = false;
    bool tHIJCfsrGtdm = false;

    for (int tulNgvhYDKiV = 1094463647; tulNgvhYDKiV > 0; tulNgvhYDKiV--) {
        CNgthIL -= CNgthIL;
        QdWcOZIJYKa = ! xAQqpja;
        QdWcOZIJYKa = ! fVtzwQNFN;
    }

    if (fVtzwQNFN == false) {
        for (int qmQcd = 1237131696; qmQcd > 0; qmQcd--) {
            CNgthIL /= CNgthIL;
            xAQqpja = ! QdWcOZIJYKa;
            fVtzwQNFN = QdWcOZIJYKa;
            fVtzwQNFN = ! fVtzwQNFN;
        }
    }

    return RhELIxUw;
}

bool MjRhfJlA::maFlx(string zGFIgfhJ)
{
    string TxnGejef = string("GDjFsqdRBGhwuuhTKZdQjv");
    int havThSuJRFtckrpl = -1201847126;
    string jMMAtNfP = string("LeTSGqQwCfNTIeqPyYyfEKOhNdcPrCQwZUPXmhRHogQAStNRYbZosWdnyWoSMWVdGq");
    double YaGfve = 1022268.1847829877;
    string EYiaWIQMNhwT = string("XQEEnGiodFMTKqRMVSTMUuciWyRiMWDpTMybtKoXeyfzS");
    bool jwpWkZDi = false;
    int SJqZYBKTwY = 1788168299;
    bool qpwUUDDRvRJW = true;
    int hgcyN = -1972722850;
    bool JaihCeL = true;

    for (int lhzhmKoZUyWUOMsw = 1782916892; lhzhmKoZUyWUOMsw > 0; lhzhmKoZUyWUOMsw--) {
        continue;
    }

    return JaihCeL;
}

bool MjRhfJlA::BvbFpFmeSr(double yOogIfxSiYxeCDZN, bool LXreyR, double DDQQgJV)
{
    bool gKCDfDxLsmFk = true;
    int nXUbdsQCxH = -282402173;
    string XezrazO = string("vKNDUBHXYfWdWbvfawVCMbwLVIazgwBpXenwaMfUiTLRNwhOdynrHmHFqSSJjckBOszEwqqtZHkYnM");
    string LMaRRRKPGrzYMX = string("uGMWzTiMfrSgpmQRSSgFiRbQJxNibjHrtGQUjPtJnSBUhArlYOCeIcqJkFpogEECZsgEXHSatOMKSUJfWCeoRHqErVpviAsbfQBSJnxRnRdbuLJhPPmQHpXlwCvJhtToKjdqLEusexWCzKfaQGlosKwqTLHBSgY");
    int CUZfNgc = 599625415;
    double YaDJrDxMEBtoXMGn = 681928.4793404922;
    bool YMtVAtP = true;
    double TUcjqOMjhsFtdwH = -831419.3167118641;
    string NxMVXKAarkPmEfeL = string("zzmEHWePXGEudjKthDYmbGUhwAXRTyRwgodLrZEzvwwXTxgYvGqnzJZeYjvIqQjeSSLXnCueWMTdBoKJgolcaxjHIAxBPCEmHcGtPYLXiSltsEmvUXJQexKVYUMjahUDwUptWOtPSMOrdxLimlTMLOIRmUonYwyPv");

    for (int ommNq = 1135440764; ommNq > 0; ommNq--) {
        YMtVAtP = ! LXreyR;
        TUcjqOMjhsFtdwH /= DDQQgJV;
        LXreyR = LXreyR;
    }

    for (int LYZrxx = 1541378885; LYZrxx > 0; LYZrxx--) {
        LMaRRRKPGrzYMX += NxMVXKAarkPmEfeL;
        DDQQgJV /= DDQQgJV;
    }

    for (int lXIeGjFUqoXQkQP = 913042716; lXIeGjFUqoXQkQP > 0; lXIeGjFUqoXQkQP--) {
        YMtVAtP = YMtVAtP;
    }

    return YMtVAtP;
}

void MjRhfJlA::bpZIjMZgncp(bool jOfNPg)
{
    bool VwFQEwxDsireW = true;
    string bReinrL = string("LQiFFMlkeuUFScauEZHjFZkbwQMdivSLYSMyxAJAhaIxFnDequrXKWzGgzpHcucacWegfGissOCsMLeDosPRqkZKutxIDGiaXKiUaCHuoNjISZTtlTBrnXvljzPfp");
    string fOjFBH = string("DDbKqUfcErLchenvqJoBFHiCkUMOJiKFPkCoGrCCLkKqsXiiIDBqoZJpRwCOesMRLtifBPBqBZgrEOJpbIJglSvwYNvDVThskcPulmnvaiteDioKfHulFVKL");
    string KxbsmBCGUMKkX = string("oYLWwEIQGdLBfocgbYMLXOLNTJNDNjSTbuyyHGEYsMzRfQUePIWAdHWXVjWnWfcXGYvLPoyiOLmlJgZfKhgMtbjhOYglUmLtvJESWSAsOOttKUNBbGzVbZwdSWICcuuGuMeFZhAkiBcrhDxCkzrTnYSdVPdTdcInbjzNGPxtbDSdNeicjDUcvKqZTEPEOEMoEixuquZjNsVyEnhXJDQcjsUqDLYgqMFYqzyLLcFXfzDMTkTvNfILZIMIcA");
    double YtgalXDqGQ = 325042.93147600465;
    bool ziQxdEJJg = false;
    int BrQRZzoeR = 1396624044;
}

int MjRhfJlA::oJKxonVIiARaqlwU(int KFoMrCq, string sIuVYXCgM, double JcuFf, string tnxlrdTN, int EKyiCIMQW)
{
    double bdOmwzIHtun = 698843.6656604196;

    for (int tufkOnuDSpQdF = 241014446; tufkOnuDSpQdF > 0; tufkOnuDSpQdF--) {
        continue;
    }

    return EKyiCIMQW;
}

bool MjRhfJlA::TuCqQtscZ(double eTOEJotL, bool vCmJtzeo, bool qCxmJ, bool vlyBm)
{
    string nGUhaClKCnEVLmQC = string("qTdpuILjdwvPihpzGZlsgMUrIwNOeZCJaRLzbPQMtuMbhQxUcrQMrzvGxTXfIqlRaZSztipjZeirAIBEOMaxXUDsjdLyfpcvGApPlCutZjqIsUeSU");
    bool WkXBjkbJuPl = false;
    double NwHmiYRDduGziLmo = -806423.0083617652;
    bool CluREdQdzy = true;
    int BRtwrLpssTez = -1909801062;
    int LJdZZ = -659096933;

    for (int bocLDdyyjGInM = 1561773893; bocLDdyyjGInM > 0; bocLDdyyjGInM--) {
        vCmJtzeo = ! qCxmJ;
        qCxmJ = WkXBjkbJuPl;
        eTOEJotL /= eTOEJotL;
    }

    if (vlyBm != false) {
        for (int NSlvaxCTIoWKca = 1470490049; NSlvaxCTIoWKca > 0; NSlvaxCTIoWKca--) {
            continue;
        }
    }

    return CluREdQdzy;
}

string MjRhfJlA::yFNbw(int LiZhUgqziefomV, int sSyXN, string qUJLZTCcd, int WESMaPKJOc)
{
    double HkryOZmQidYM = 612315.0648455636;
    bool kRzTdQolTQjXri = true;
    double eHUDMDLwEzLnSk = 644273.90294719;

    for (int acWDEBLQZ = 1972162866; acWDEBLQZ > 0; acWDEBLQZ--) {
        kRzTdQolTQjXri = ! kRzTdQolTQjXri;
        sSyXN /= WESMaPKJOc;
    }

    return qUJLZTCcd;
}

int MjRhfJlA::ehMcQ(int gSdffLKaWdEAkgk, double UPbiFnkaibLFrZH, double HewTTVWoh, bool FYPCewGfb)
{
    bool HgtXsZl = false;
    string EOsnL = string("wLTXVZojKjKwptVSabsolNbOsKQcFHjIQHxfYEhBXZ");

    if (FYPCewGfb == true) {
        for (int AmMvbkulrTztI = 1674677113; AmMvbkulrTztI > 0; AmMvbkulrTztI--) {
            FYPCewGfb = ! HgtXsZl;
        }
    }

    return gSdffLKaWdEAkgk;
}

double MjRhfJlA::OxGfQXuzv(string AiunQ)
{
    double rdEkjaUzbs = 167089.43474424465;

    if (rdEkjaUzbs >= 167089.43474424465) {
        for (int XxnRGGj = 2069648201; XxnRGGj > 0; XxnRGGj--) {
            AiunQ = AiunQ;
            AiunQ += AiunQ;
            AiunQ = AiunQ;
        }
    }

    for (int eIObDC = 2002125979; eIObDC > 0; eIObDC--) {
        rdEkjaUzbs -= rdEkjaUzbs;
        AiunQ = AiunQ;
    }

    return rdEkjaUzbs;
}

MjRhfJlA::MjRhfJlA()
{
    this->eEauhcJVtHYytA();
    this->maFlx(string("PynDAebBSmuMRKoHDZARTHKfLFSDPpXNqLCWKNHriexifUswhaNYuXkIjtbMbXQAWLdqfFiKHIVAmBwCmFUHURtYxijRtdYmPJcJoEJyESBbFjbueZWNdQVzbxybyqqXibXPVjhXEuKvIvaZmAzBoFuLpjEYliUneElyMUNsTvmjoxMsVLDKsWUiBmToXUjncJIQJgjMluTaMWCUgBXDYtGpUzAnPG"));
    this->BvbFpFmeSr(761260.6664397877, false, -655138.7139137618);
    this->bpZIjMZgncp(true);
    this->oJKxonVIiARaqlwU(-608482734, string("BNOPNJCYHnvqJyWZmDPAxItzncZsIyrVBonTkyznBrnIkyAaclnymGzbFLUjObwZWxuIChcCCLEQjqYnTeYZmUzXnPVmxuSVHIVKXuyyMPHWNbHBJuUNVZgPknoioy"), 420263.6624225148, string("feilvYCEMxVoMBlQHGCDBgESBLQRXFavlSkzImtdampFCKydOBTAHENdgOkfuilALRkFccqcGwNmbmpHJYTZPjCjWCpYUJmLujXZKhaTNnjsIwdUQlzLtOZSEXfpxOUydxosH"), 1933865718);
    this->TuCqQtscZ(890003.7900225408, false, false, true);
    this->yFNbw(569664050, 771437938, string("gFnGJhWRsyLAvzkULssxFbRVBGimIqDUwSidRkbseOGWyNZUCTZXyjzOAwqRFfaWlsOTuuNJZZnKavlEVEHYlizGRyFDLYHGBLHVKWkfpLv"), 1079478524);
    this->ehMcQ(-411357555, 599175.9965102901, 948574.6844147764, true);
    this->OxGfQXuzv(string("NGEvIhtMoaxcnPhsAkzEYUDLlEMeIPwKiJuSzMQQuqoHyvLPDlcsMtyxylJSdqMhozBluiezgOikWoeCBLhxMsePITiCHKAaktLgWMqzYdcWuHxXfHLiEhkWwHaUbljRFadZbSqkLpJvwWkeETTXvKHbfGDNQefbjHKxL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EnaXYrz
{
public:
    bool qDGhRnaVNdR;
    bool kXnxiR;
    string NmptTzgDy;
    int WnPTcsDBUB;
    string ZcHelfmiNpMtsLf;

    EnaXYrz();
    void znNgABc(bool quTQSkm, double XfVjPWvKgRuBo);
    string DBbBF(bool ZeHsgssvJiYnyb, bool SIRgOHhjKniZE);
    double cwrRp(int dJLqwDrF);
    void bWlggPuh(double ffOHxItgZesRb, double uoMBGhWVtJbKq, double coPPvqvBEzN, double RzMcXjAO);
    int mVFHmpgDDtpIFiJ(string zNpTELrHnmClza);
    int xQjeJfXYaaGQfeRx(bool DgOnY, double gezwoN, double qdRZkeDib, string izMjIVP, double agDSeeobtUgJT);
    void UNTZpluS(int ycKAwLZHO, string fWzAgSPiDrAT);
    bool SXSgKCWZUli(double HmjWfyVwsvo, double QDrjDRBI, int yotPPH, string pCmEOtwwbcJEKnmA);
protected:
    string HYxLrIKnHRoEjQXy;
    string pvuHBdCBkWVH;
    bool vMoSyQISrE;
    string szSavTSunsStXKuN;

    double utgiuKAhYxfDfG(string NkIXQnHnZsdOB, int XAdqdUcy, double PQXgyNqinm);
    string zYspmrYnBqdp(bool jvAFkzQDGJ);
    double XLDGybdFFSJbadnQ(double GmmqTyHBcGfsEb, string nwnZZCpgg);
    void ZtQuIv(string cNmmbvQahKpn, double DghlrugpOeWqru);
    bool jizfO(int aBqDNtPHXwjBW, string aRgpFaLz);
    string kBmDAYxvQIGt(bool cMEkBsWvtW, double IrOxOfcblbdbSGU);
private:
    bool JIkODI;
    bool DRQgjwaep;

};

void EnaXYrz::znNgABc(bool quTQSkm, double XfVjPWvKgRuBo)
{
    bool BoGyhPCb = true;
    double ucOlyad = 599830.4159282714;
    int YVAtcXQUS = -1907000999;
}

string EnaXYrz::DBbBF(bool ZeHsgssvJiYnyb, bool SIRgOHhjKniZE)
{
    double ypdpbaKBBCm = -577254.5476988312;

    if (ypdpbaKBBCm <= -577254.5476988312) {
        for (int uWqSMcfpQQQ = 1750539874; uWqSMcfpQQQ > 0; uWqSMcfpQQQ--) {
            ypdpbaKBBCm += ypdpbaKBBCm;
            ZeHsgssvJiYnyb = ZeHsgssvJiYnyb;
        }
    }

    if (SIRgOHhjKniZE != false) {
        for (int MTYzJxRAdTZR = 5455493; MTYzJxRAdTZR > 0; MTYzJxRAdTZR--) {
            continue;
        }
    }

    for (int qOyMRZQaXRDgJITD = 1272885597; qOyMRZQaXRDgJITD > 0; qOyMRZQaXRDgJITD--) {
        continue;
    }

    return string("PMCDgxsLHuZZNmbSSuuehuWGzhmzPtJVPNQRmEizREipffPGBiyWZaJUkZMeBZunekJXltKibBMwAIzCHsfUcROodJmjKXmvlsCTORKdckFrmPwxJfsvIObUVoBWKXORjVNhXMGlnpvLugeTkYRVrQGWTVNaxFycnKZWMAzqvyENAZgWHIAjbAljKweAOimbqMcz");
}

double EnaXYrz::cwrRp(int dJLqwDrF)
{
    double QVHKkyoqlEr = -29468.541475272115;
    string OJdWLZMBQP = string("uwoDzWQmrMdSXmPJDqFrWxzhnTFwBXKpIXzRYiQVlOFyYkWcmDBcAJmGltJhoLFmAEJYIhnIRTdygfYndMPrQjSgNxsmzqvTbMBRfqCAvweuypggQRyzzoYluWCTjsBxfgChrblUFZShuhZhzzEYGdfuxXAYCefCnkZAoWGcunhXdnVxCACMp");
    int vgMJGzYVPIzdEbs = 1717230345;
    bool AkYqBSmgFtzgsea = false;
    bool eErFw = true;
    bool LPjKkU = true;

    for (int JzwAbkLDrET = 190147025; JzwAbkLDrET > 0; JzwAbkLDrET--) {
        AkYqBSmgFtzgsea = ! LPjKkU;
        eErFw = LPjKkU;
        LPjKkU = ! LPjKkU;
        dJLqwDrF -= vgMJGzYVPIzdEbs;
    }

    for (int nJYyB = 1304952762; nJYyB > 0; nJYyB--) {
        LPjKkU = ! AkYqBSmgFtzgsea;
    }

    return QVHKkyoqlEr;
}

void EnaXYrz::bWlggPuh(double ffOHxItgZesRb, double uoMBGhWVtJbKq, double coPPvqvBEzN, double RzMcXjAO)
{
    int udxoWwuctukpM = 1819197961;
    double DXSeXNFFdqoxz = -125068.34194167268;
    double nTsOs = -152889.01031251723;
    string FHVfenNc = string("AtTqApdoKsIvZMnThiIIPAYIefJZbiVPUVnBgKrPopinnETGqStQHEOHFXqbLtKXARwtKEGzcOgFSYswFzTIFvSYQHwVLCPHkcudRuWbRsXdGMSNkzqjWMdOzItFpONvWUChrsJHTuHRXxMuBaBAvUMpwDuUaHRwFzpqaBzqVhvBRkWwSjyYfrwNKHYoEhYuxjBMUGbpFziwprCctscrhBQAISolmB");
    int ORbaKbFdKsjV = 509736264;
    string ynYgMJrJozxlapXd = string("qHDbKRgoyXuzpFRoGrQPFDnaNtLxmxtCdCbIfXIuMBGCpStJdbkbbMnNSGphmrnHAbrXoUCsHszkdKLxQFPYkHUlywKNFLLuRmZXLcuhHoblYdbDWdhrZEkpYkZbBNQxKzCCpebGyEplzmDuhLqCoNDtFQReIhlRgrhbyyXizpo");
    int bSrIkaZfrsTCAwbT = 914720304;
    string MXAEirUzwQC = string("bkLvjgLVJFjkmhDihjkIpE");

    if (coPPvqvBEzN > -152889.01031251723) {
        for (int hGGysCqK = 2090536023; hGGysCqK > 0; hGGysCqK--) {
            bSrIkaZfrsTCAwbT /= ORbaKbFdKsjV;
            nTsOs += DXSeXNFFdqoxz;
            uoMBGhWVtJbKq /= ffOHxItgZesRb;
        }
    }

    for (int NrVvhibJEeqfFH = 717610425; NrVvhibJEeqfFH > 0; NrVvhibJEeqfFH--) {
        nTsOs *= coPPvqvBEzN;
    }

    if (ynYgMJrJozxlapXd <= string("bkLvjgLVJFjkmhDihjkIpE")) {
        for (int SPPtcogWqPyBS = 1130618611; SPPtcogWqPyBS > 0; SPPtcogWqPyBS--) {
            ynYgMJrJozxlapXd += FHVfenNc;
        }
    }
}

int EnaXYrz::mVFHmpgDDtpIFiJ(string zNpTELrHnmClza)
{
    bool BTQFXUMYIOEB = true;
    double okYyDpopcQKdod = 984130.4394279856;
    bool uacAz = true;
    string lWsUXIFcLpFRTrk = string("hjkTxxdFcWvTohxjUuzsNsIncjnxZLFQhFBjRgHCWOTTYUVTgYKEcQPLqQxtWSyFHFwFFMDktZDJsDjeXMTilWWEfkJDUXBJippUxDOsgSlLhQpLHMwrXaUbYaUCBMqKnKKuIXheHzvbxxCIcVHzSYLjvlWqhstJRLeBpmMsFUtSBhtxfMrljXQr");
    double XOxhXXyMnC = 917943.2821260854;
    bool fMokH = true;

    for (int LGPSLgtzAFJQ = 401492432; LGPSLgtzAFJQ > 0; LGPSLgtzAFJQ--) {
        continue;
    }

    for (int aiGqycO = 814887776; aiGqycO > 0; aiGqycO--) {
        okYyDpopcQKdod += XOxhXXyMnC;
        okYyDpopcQKdod -= XOxhXXyMnC;
        zNpTELrHnmClza = lWsUXIFcLpFRTrk;
        fMokH = fMokH;
    }

    for (int PEDeCxzHNaj = 760200101; PEDeCxzHNaj > 0; PEDeCxzHNaj--) {
        BTQFXUMYIOEB = fMokH;
    }

    return -155145316;
}

int EnaXYrz::xQjeJfXYaaGQfeRx(bool DgOnY, double gezwoN, double qdRZkeDib, string izMjIVP, double agDSeeobtUgJT)
{
    double OTxQSxpwBxzrts = 2353.2049191766423;
    int diXrSnwMXLMbdBD = -1737954926;
    bool nwvbwcSnKztK = false;
    double YvzCqRXO = 536425.8373019549;
    double zRmenFENgFHU = 621042.594725612;

    for (int XHMhOLr = 1666301270; XHMhOLr > 0; XHMhOLr--) {
        continue;
    }

    for (int IieZuUxTJmokQ = 67693318; IieZuUxTJmokQ > 0; IieZuUxTJmokQ--) {
        OTxQSxpwBxzrts += qdRZkeDib;
        OTxQSxpwBxzrts = YvzCqRXO;
        nwvbwcSnKztK = DgOnY;
    }

    for (int zyghmr = 1095292940; zyghmr > 0; zyghmr--) {
        continue;
    }

    if (izMjIVP != string("zsBslAUPpcwHstObnMcJXIDuYQXAJthyoamEYCARSRbxQmyFWrsNEZziuixEOBfvsB")) {
        for (int YXqniu = 1620197715; YXqniu > 0; YXqniu--) {
            YvzCqRXO = zRmenFENgFHU;
            YvzCqRXO /= agDSeeobtUgJT;
        }
    }

    return diXrSnwMXLMbdBD;
}

void EnaXYrz::UNTZpluS(int ycKAwLZHO, string fWzAgSPiDrAT)
{
    string fmfXHNkoy = string("iZrbIHelsSDPYKNZkEU");
    string HZWDSFNtVtCeOz = string("jQLIAXxcaoAnuSojFzAmXzxTOiXdOCHHIOKTGMtkaMlyoDhTbWeOjWdXLnCjCxbmuIBUsWQzOoXpbjVkVTJkyonUFvQNPHdctgBqVYjkfhrMOvZbyhCohgRlIElBQtimJCFVGU");
    int LJVkEXRlZEI = 1472585677;
    double NlPEzR = -930992.8059817217;
    bool OOnLAVuBem = false;
    int waLFBHZAlowbfxCX = 2129129982;

    for (int OwsydhD = 175629686; OwsydhD > 0; OwsydhD--) {
        waLFBHZAlowbfxCX *= waLFBHZAlowbfxCX;
        fmfXHNkoy = fmfXHNkoy;
        ycKAwLZHO /= waLFBHZAlowbfxCX;
    }

    if (LJVkEXRlZEI != 1472585677) {
        for (int ChskJHQEloiCKsIE = 1680371210; ChskJHQEloiCKsIE > 0; ChskJHQEloiCKsIE--) {
            continue;
        }
    }
}

bool EnaXYrz::SXSgKCWZUli(double HmjWfyVwsvo, double QDrjDRBI, int yotPPH, string pCmEOtwwbcJEKnmA)
{
    int sRzaIzWgEPcGdO = 1830248192;
    string ywMHBJkrkjyPuqz = string("jotyirqWSayjfenOzXYdSffQjKHUHspjNPnssCiJoINjVGsauztivgnJkHPpPvlmFyodiIRbzlniEmcqjTLgflEYsOqTQRGOquzqEPNylorOpElZbKfqhRwoxenuaqvWvaHKUiw");
    int Blrvjs = 1413056722;
    int rnNmuRysxPboJna = 128249564;
    double GjwZAzPuepj = -480371.8526093113;
    bool AKhnCevjSXoQVP = true;
    int BotYEvTZLZqrl = -1603402401;
    int QbhQpjwlGCPoK = -1745444570;
    double xHmYrhtCLlsDIK = 329036.4823907545;
    bool LewqhYxZNrl = true;

    if (sRzaIzWgEPcGdO > -1745444570) {
        for (int NTMSyunzNSRu = 1270936981; NTMSyunzNSRu > 0; NTMSyunzNSRu--) {
            BotYEvTZLZqrl -= Blrvjs;
        }
    }

    for (int PhcbWvxVytESqE = 762210676; PhcbWvxVytESqE > 0; PhcbWvxVytESqE--) {
        xHmYrhtCLlsDIK *= HmjWfyVwsvo;
        rnNmuRysxPboJna = QbhQpjwlGCPoK;
    }

    if (rnNmuRysxPboJna != 646390709) {
        for (int KGtosPkV = 1534371730; KGtosPkV > 0; KGtosPkV--) {
            QbhQpjwlGCPoK = Blrvjs;
            yotPPH -= yotPPH;
        }
    }

    for (int vKfgLhNAXnxmxYAn = 197269190; vKfgLhNAXnxmxYAn > 0; vKfgLhNAXnxmxYAn--) {
        QbhQpjwlGCPoK -= sRzaIzWgEPcGdO;
        BotYEvTZLZqrl -= BotYEvTZLZqrl;
    }

    return LewqhYxZNrl;
}

double EnaXYrz::utgiuKAhYxfDfG(string NkIXQnHnZsdOB, int XAdqdUcy, double PQXgyNqinm)
{
    int RrIRmn = -811969078;
    bool mzoMUnfnAJIiPt = false;
    string xgQMFPu = string("ZENInPpCbslEOzQFzYBdmFIRAOhiassjZouheSDmKRGGxgNySeRTKppFPFPBCuuCvQsDjUqYersNCFgWsCTpZkDBxXYcvxJOFdBGImMsyBpoGjwLVUDUbjDjVjWesfTpQv");
    string FrvbFhyeQQ = string("PwPVWSbQxjfeNhWicvCqwDmhPRzUesfjUONgeeqCSgLaXZepTBWKIgoMjwtYdvyvOcxSXDDIhFMmvQpgGwTTDvgdiqOfzKqaWFlYIjiGrnpMesmJiXLKqfoKfGHyurrRdNBErwaDRNuPBNdruVOIjNQvEswtnQnHVyHIlwkjheDbKHKtCJWo");
    int IiecHQjLebuLWe = -1326396927;
    double lIKDQWwuhK = -829532.7557240567;
    int KtUDssMRfo = -1988723750;

    return lIKDQWwuhK;
}

string EnaXYrz::zYspmrYnBqdp(bool jvAFkzQDGJ)
{
    int VzcGAzwkUyU = -1268478441;
    string nxTqsgBfYoThnsLR = string("HZLtWWQtFrUaGlhuNkCfFAQcgOeILyOwOcfZkaiLcOkwCohcyYrbaVdHFsmVyGVyYHAvrHpUuWRGfwUsizfGTsvvtHPjYQRhNJgeuPGXrDTYdfSCpHMFQDCmrUgJQGsNeAspoTRjeDDCOcLcLyyy");
    bool oCKFqpTrYCZOJhN = false;
    bool NcyragoojaT = true;
    string dylvxvBnURq = string("POPlzdBqCmtWJiQsXDuiNsxowfPJDLxLDSaGTBiEQYBnAljBRuumEMzPzOXKjxjMWVdxjVkFHFpVBWARRHdhxYYtXcPM");
    string UIiCBeUD = string("qidFmZjwZZwbiAbEpqjceveVevSTWhLglJTyersgImfzuNOntwqSmQEfzUKtHmYGYugsbnVtToiFYzXsemXUPxOHMtMNFUwgSImlayBpGiDWTeRtyGtbkrRcRJwtaUIlxcvOnrgMNurDZIonurGsUrgsvPjzgLyUhWolMSFOKyRZuaizAPFpXlgnjnDIvMlLojnrzpxABeSoNgEMFAcFVzFytnFMmlzH");
    double UYISsrjxcFtwV = -800867.5560627182;

    if (UIiCBeUD < string("HZLtWWQtFrUaGlhuNkCfFAQcgOeILyOwOcfZkaiLcOkwCohcyYrbaVdHFsmVyGVyYHAvrHpUuWRGfwUsizfGTsvvtHPjYQRhNJgeuPGXrDTYdfSCpHMFQDCmrUgJQGsNeAspoTRjeDDCOcLcLyyy")) {
        for (int OutrY = 1418396264; OutrY > 0; OutrY--) {
            NcyragoojaT = ! NcyragoojaT;
            dylvxvBnURq += nxTqsgBfYoThnsLR;
        }
    }

    return UIiCBeUD;
}

double EnaXYrz::XLDGybdFFSJbadnQ(double GmmqTyHBcGfsEb, string nwnZZCpgg)
{
    int yGwnzsyocCkPZVHo = -1347181260;
    bool OQfRQKjX = true;
    int RvaEfejil = 314852078;
    int hbSnRiJasxFdhmk = -717377064;

    for (int CxENxaIf = 79252570; CxENxaIf > 0; CxENxaIf--) {
        continue;
    }

    if (hbSnRiJasxFdhmk > -717377064) {
        for (int eCVhUqlGYEzTjzLJ = 260778224; eCVhUqlGYEzTjzLJ > 0; eCVhUqlGYEzTjzLJ--) {
            nwnZZCpgg += nwnZZCpgg;
            GmmqTyHBcGfsEb *= GmmqTyHBcGfsEb;
            yGwnzsyocCkPZVHo -= RvaEfejil;
            RvaEfejil *= yGwnzsyocCkPZVHo;
        }
    }

    return GmmqTyHBcGfsEb;
}

void EnaXYrz::ZtQuIv(string cNmmbvQahKpn, double DghlrugpOeWqru)
{
    int oJaIExWQtmH = -1758520084;
    double okGphvpVYizDgP = -748356.2981434538;
    double IccYVvcPmYw = 594871.543981767;
    double RpLevytxcV = 967344.8618600862;
    double riqMudVhZHWrRCYN = -768195.9244052706;
    bool xlLiqoosPKHNswEw = true;
    double UvoqBe = -406876.7490779971;
    int zErNeM = -810247487;

    for (int gMpxbKDmLfrroas = 1610728421; gMpxbKDmLfrroas > 0; gMpxbKDmLfrroas--) {
        IccYVvcPmYw += UvoqBe;
        cNmmbvQahKpn = cNmmbvQahKpn;
        okGphvpVYizDgP -= RpLevytxcV;
        riqMudVhZHWrRCYN -= UvoqBe;
        zErNeM *= oJaIExWQtmH;
    }
}

bool EnaXYrz::jizfO(int aBqDNtPHXwjBW, string aRgpFaLz)
{
    string zGWsolkUl = string("RJOWtWYreUODMgoWfRmEkMzjPknKamlDQwQbqlddKvnUHVjKInnoLsCnNOjGpDUbXaYFaXXYSYHrmNTfzwmjhbMuCDEpxtQUCkUXnnfUeTcMPWVyGLdUVa");
    bool XoLjYRnHsWKGO = true;
    int akjGLSK = -2127196806;
    string yxRlTCxj = string("EljLezzHMBJvtEJWuPxIYsOpceYTAHqPZkvjCAArWvooQlaqiaewzfAqOnAarLbbDjjbUZlHxRUjDpYOIerrUEohkKkgepJQJwNWfKdGCFehmqrjLTOsZYKbRSJSKQvKtPbTEzkqdlbYKPKCrsVcFGOvCxMAsGweKGVwPpOnoyKRUoErsQ");
    int ZacLtOGaIzz = 1812592895;
    double wCByUfzp = -275165.1197445083;
    bool MayrozjvYZzWGD = true;
    string kovHVY = string("DlvXgDJlOGCJGgSJUHqzqP");

    for (int jKKRBehQJUJ = 2122050267; jKKRBehQJUJ > 0; jKKRBehQJUJ--) {
        aRgpFaLz = aRgpFaLz;
        MayrozjvYZzWGD = XoLjYRnHsWKGO;
    }

    return MayrozjvYZzWGD;
}

string EnaXYrz::kBmDAYxvQIGt(bool cMEkBsWvtW, double IrOxOfcblbdbSGU)
{
    string bEeYPqRfPVNilm = string("FegAznDcffMQwKUYRf");

    for (int LRCrxKrWTad = 1296703349; LRCrxKrWTad > 0; LRCrxKrWTad--) {
        continue;
    }

    if (bEeYPqRfPVNilm <= string("FegAznDcffMQwKUYRf")) {
        for (int usBHgQ = 127958734; usBHgQ > 0; usBHgQ--) {
            bEeYPqRfPVNilm += bEeYPqRfPVNilm;
            cMEkBsWvtW = cMEkBsWvtW;
        }
    }

    return bEeYPqRfPVNilm;
}

EnaXYrz::EnaXYrz()
{
    this->znNgABc(true, -717431.8439943069);
    this->DBbBF(false, true);
    this->cwrRp(761308144);
    this->bWlggPuh(-194857.1733000228, -670886.5724850752, 1022829.290344947, 597055.3941886105);
    this->mVFHmpgDDtpIFiJ(string("tXUJlsIfoUTYnZRbekjisVGMjivcoLwCWXapensxhgHhGBcgOaJR"));
    this->xQjeJfXYaaGQfeRx(true, -258122.99272845118, 932133.3255591147, string("zsBslAUPpcwHstObnMcJXIDuYQXAJthyoamEYCARSRbxQmyFWrsNEZziuixEOBfvsB"), -569992.4683766483);
    this->UNTZpluS(1865816008, string("AjQKZdATxrYdiRNbqxdNjPaQtVHEAYHkLRYWFXzAjfenlGbqYAGmcNdxpfViMELKprsYXoPKdgObeHKNVNqZutVkVghezifpBoTDnihOlQHWvQmwJvSwMyacJhpwYwqZErZnhrMkgnTalShdQdazrfGRLoPlqWtYugaLiPiKnWDcbVwSknSXCtzzxrwkmpCRrGSebtKJISZtEkuEHqugzUpIlWfLZgFMwBNbvAfwvhyNdwMLnkfkabbSPUEMjf"));
    this->SXSgKCWZUli(684927.7572576692, -262628.40078042954, 646390709, string("RBVrHegcTbebRqBaDoHCJPTeMByEScKQMIIjDHLOmsEXKBQvMCrmuZJzqZZeJVUcHURsIYstibCrFvSxcicaxjvyLAWXwPLRGxKIyQXzLkPYjZjLrJok"));
    this->utgiuKAhYxfDfG(string("li"), -1071458308, 286370.34967486013);
    this->zYspmrYnBqdp(false);
    this->XLDGybdFFSJbadnQ(-828602.4032163214, string("iIbXhnzhLrjJrabYAWYiCsJNCKCpzPghLeXhqgbpBqllRmnIZkpYluJWFnWQpiMxKhvuibYbElrpcDDZMgpQsBFTnhyYoawCcEuqbdPxUxXOVInErsczlntSUQRdztmqSmSJPmKsTZGcMsLnpmkCOCBZafECsLvpGxSXoKmSItwoUrmAafvIlUxWqfcdh"));
    this->ZtQuIv(string("pKv"), 54677.11343071771);
    this->jizfO(-1167668360, string("GQIDdwEDNXAIZpIkcUxSlRRjzBSovVLHmknVCOpHwMqVaShAvDpFVGfBVaHdWcmPfooZlDEfpIrmKgoFCpUYwVWqXZXjlAqYqsohjcsrEHowLNTkzFvaNbFpBPVrjfIUSxxfNCdleIyPduWdwhqNiKWQarmyTkkxAafpEwIlxKfhstQfqWUBKUKWihgWWBxEqjGMGKqvCQLlkXLdOsPaQ"));
    this->kBmDAYxvQIGt(true, -958938.8145593358);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TvYiaSrhui
{
public:
    string kCdUvBPjKX;
    double DBZJce;
    double LeOjMQMXyXyH;
    string srhsvVTI;

    TvYiaSrhui();
    double rvdJNdcLBLEqPRZ(double uYFmyYPducgwaXX);
    int RCyvVePdPgkkx(int KbWUXq, string CkSVTptRInvgp, int bpaUzNbyVNRT, int pcarwivmIdmfuDh, int JjXshVlnsF);
    int pkGkCA(bool cShDZVQL, int iCDRHyhYxQX, double BPMwFTyCYjYzeGx);
    int RPFkiy(bool kdEbPUerwssCgJ, bool bbqnEuprEB);
protected:
    double IffLaUZBuVNjvKX;
    int NIIbIYevHCS;
    double rWjXhViDJ;
    int ldfRYIwDgHFdZrq;
    double OjdppSppdw;
    int OzGThysVFmeJAg;

    string WHJbmGpSoVz();
    void pQqWwoOg(int kiauR);
    void mesyisZhmf(string waPgBpeTt, string xRBpspvInwThe);
    void FylHTAnzWdsBF(int uACLINCZjRhHW);
    void wxVQAKjbMevPplTw(bool EbGChJ, int GLaEkGtlsanbNNKV);
private:
    string LShINSKlbsE;

    bool glyhdEvWBVnfXDR(int YyoFHBeyFf, double eYRCjcSeqE, int HZrjxbVlbjKXU);
};

double TvYiaSrhui::rvdJNdcLBLEqPRZ(double uYFmyYPducgwaXX)
{
    bool oQskLrZpokIvBeed = true;
    bool YRlVvOIDr = false;
    int lilTEqruhOLGyt = -1714001366;
    string UBVrbDKpfgOe = string("reaaqtUhCkXuWjlADLVJjcnPCsCAQiiaBmqesYuRyJZFxNjSGuRMJygjKOgxQqvaoHCPhOuGfkxPiJmZNpAKuvGUXzuqggIhOIzhrcNrzvugcQnbzvcXZEEjUsyXVuyfcvwtLuBWXNHzX");
    int ybXUzrZ = -1356044774;
    string NWlSsnxa = string("MuznuseQgSglDPqul");
    string QeMckeSJQKDS = string("qLJhUwEPkdx");
    string AYqHcTPgNKg = string("jYirpUrTPUBGmHAISnnJOQtKHGwrTiuHYPcakKjPyYCWBMoNmMDwloPNvaffWQvWKLzeGIvHuxInCCmgndNwckfLqgTcgVeYAHSpCsXTXQixMeQrlJedZLDccydDQPpXlMqnEBRycCrIZwsouKmCudlXoHKGvsQxqbxElveoY");
    string VyGXGWlGZdtOT = string("pmHPvFoXZHVptxTaRCEQiscbeCzjxCrRusaxrPvpdLDYgVXnUkTFvrnguXSLbIokAirccAmILOGrVdTTCFAfZITNPlQNVDbQBOhgvgxxMHaRXEegbFYycriiMDUYtoWCtdAfRTCZwJJMmsbCJGYpkqcAxivKVcVcyzSBqHbdxFUFJXTEhGbgzgAhfUPrYlPaidVkxmkFmz");

    if (oQskLrZpokIvBeed != false) {
        for (int aRVGwjcegnm = 1004331378; aRVGwjcegnm > 0; aRVGwjcegnm--) {
            oQskLrZpokIvBeed = oQskLrZpokIvBeed;
        }
    }

    return uYFmyYPducgwaXX;
}

int TvYiaSrhui::RCyvVePdPgkkx(int KbWUXq, string CkSVTptRInvgp, int bpaUzNbyVNRT, int pcarwivmIdmfuDh, int JjXshVlnsF)
{
    int VOmKDHVhwy = -1443081450;
    int AWBvuUVfc = -314057796;
    int OvNLsf = 1426416488;
    double yXwPKLgaoOmGUhdv = 1013534.0085460627;

    return OvNLsf;
}

int TvYiaSrhui::pkGkCA(bool cShDZVQL, int iCDRHyhYxQX, double BPMwFTyCYjYzeGx)
{
    double xXFbHh = -879278.4322137737;

    return iCDRHyhYxQX;
}

int TvYiaSrhui::RPFkiy(bool kdEbPUerwssCgJ, bool bbqnEuprEB)
{
    double AUHcw = -53756.867375960705;
    string bkWXGTMzzU = string("kpndoz");
    string GsRmKjTcPJvJnD = string("mGixLNOnfnkRiYLIyiEPyyegOLcDGfXgArSwJemrLILTVlviQflJhOijfmkWFfvrPXJwRubkxMoKwRTtxLGVdeCpEplpaAmlcOTvursgRszePcnpruyKYuvcatqJhgsXehjpXoEKHUpLxAlmnxMZkQKbJEryGKzknQfAJeunzmKsqzDYBbPBbkZmuuihQOEkFPK");
    double WrVPHA = 928114.3969899041;

    for (int vsVmjUPLBnIcG = 134379751; vsVmjUPLBnIcG > 0; vsVmjUPLBnIcG--) {
        WrVPHA += AUHcw;
        AUHcw = AUHcw;
        kdEbPUerwssCgJ = ! kdEbPUerwssCgJ;
        WrVPHA *= AUHcw;
    }

    for (int IGHao = 1433062202; IGHao > 0; IGHao--) {
        continue;
    }

    return 534978529;
}

string TvYiaSrhui::WHJbmGpSoVz()
{
    string KPLIguh = string("RLUcrcSjCjmnAUjbPIxlJbEptECBjrzFjpWvuxdSoFQHFzlbDlKYOpNDuXSpVFFHReboMbMwMieBjrWxYwdxbroxYwEeuFqbaEyZoyIDWJimIJMtiT");
    double UUiLruCcqr = -486074.1600094452;
    bool AviOThc = true;
    string ZLlebu = string("jUuHEmePYBxxuacraTgYHmbwmyZoxchhJWkfjPngwoqEhAVksaeZxUJPmDUIypZcOxmpLiGrQLPIJtisPwHSzRbnmNMmLlBtsHDDKBiJ");
    int rgcwRdyJo = -174202250;
    string tJZaLkdeA = string("wAWsKmAXcbDqU");
    bool fxqtu = false;

    for (int Qmmvzvawp = 631179035; Qmmvzvawp > 0; Qmmvzvawp--) {
        tJZaLkdeA = tJZaLkdeA;
    }

    for (int eeNOLyMUVcSQxDH = 1173073869; eeNOLyMUVcSQxDH > 0; eeNOLyMUVcSQxDH--) {
        AviOThc = ! AviOThc;
        tJZaLkdeA += tJZaLkdeA;
        fxqtu = fxqtu;
        ZLlebu += ZLlebu;
    }

    for (int YSGykkjJOUQ = 1211985117; YSGykkjJOUQ > 0; YSGykkjJOUQ--) {
        ZLlebu = tJZaLkdeA;
    }

    for (int kBydpsCP = 1552811723; kBydpsCP > 0; kBydpsCP--) {
        continue;
    }

    for (int GHdJT = 805595686; GHdJT > 0; GHdJT--) {
        ZLlebu += ZLlebu;
        UUiLruCcqr += UUiLruCcqr;
    }

    for (int VgtBvow = 1923207462; VgtBvow > 0; VgtBvow--) {
        UUiLruCcqr += UUiLruCcqr;
    }

    return tJZaLkdeA;
}

void TvYiaSrhui::pQqWwoOg(int kiauR)
{
    bool seuzwyVao = true;
    string OpvaGLEEBWrvyQH = string("YOJTAmWiKVpleJHEiOBiJbPyPckIGzrtFcYuBjqTyxDeviAxIxkNyyMKNxKPJbqofcEeGRdBPAhbMNDRXxzUfLVcyFyEhHLtAjVeKuzculrAawzxOBNlEbLbIzwDGQQCpKqhwZfPTmyDwKPwwEAyQRyoXJtLLT");

    for (int nOTWAvdlBdT = 1408122672; nOTWAvdlBdT > 0; nOTWAvdlBdT--) {
        continue;
    }

    if (OpvaGLEEBWrvyQH != string("YOJTAmWiKVpleJHEiOBiJbPyPckIGzrtFcYuBjqTyxDeviAxIxkNyyMKNxKPJbqofcEeGRdBPAhbMNDRXxzUfLVcyFyEhHLtAjVeKuzculrAawzxOBNlEbLbIzwDGQQCpKqhwZfPTmyDwKPwwEAyQRyoXJtLLT")) {
        for (int aJKRztXxfm = 1873481039; aJKRztXxfm > 0; aJKRztXxfm--) {
            OpvaGLEEBWrvyQH += OpvaGLEEBWrvyQH;
            seuzwyVao = ! seuzwyVao;
        }
    }
}

void TvYiaSrhui::mesyisZhmf(string waPgBpeTt, string xRBpspvInwThe)
{
    bool uJzJQRJFMYw = false;
    string DwaSkojUZpX = string("iswyaXvLhLbIeKsXqjoEYaIVbTdMUwcBTfIiTGuLMUMqQdWJWjBQQLjMtQgQJTGtBPkVlHJsqYUzgCsZkWqochLewFhyCJKEFOrQyKRoLbeUNIgpnIvlqjcjgzLJbugyWsylmNppYAxxJePhxCrPQSGMBnOixVBpySQMVZtKHTkFVLixuKuTnTrXZryqraZaGvTlGKXfC");
    int nbUHKE = -1604748019;

    if (xRBpspvInwThe >= string("iswyaXvLhLbIeKsXqjoEYaIVbTdMUwcBTfIiTGuLMUMqQdWJWjBQQLjMtQgQJTGtBPkVlHJsqYUzgCsZkWqochLewFhyCJKEFOrQyKRoLbeUNIgpnIvlqjcjgzLJbugyWsylmNppYAxxJePhxCrPQSGMBnOixVBpySQMVZtKHTkFVLixuKuTnTrXZryqraZaGvTlGKXfC")) {
        for (int HlutBa = 1521754972; HlutBa > 0; HlutBa--) {
            continue;
        }
    }

    for (int kzXuAwcDFFdrJjj = 586799753; kzXuAwcDFFdrJjj > 0; kzXuAwcDFFdrJjj--) {
        waPgBpeTt += DwaSkojUZpX;
    }

    for (int qvHzPzRBEYXNl = 762294422; qvHzPzRBEYXNl > 0; qvHzPzRBEYXNl--) {
        continue;
    }

    if (xRBpspvInwThe < string("UZpaWTpPovuuhVsUGQzQlinoMfvDintwhUkxjavKosKmlpGcnTRNraLoXhpXErvRcfCNXjZVDYtGWlbnGDyXecCIcHEdwKzhxeUlVreuoWhfDpwbSuwFsReFlVjneHfMeWfPBeqMsSdEApQrxtpXWxhGxFcrylkmDwSBjCPafwyRTUiqpFSGzzIgZdaIwdJrbFWJsSNOjkvNuPtWjeVjJIaYNxzFtJvx")) {
        for (int qLkoAHgZF = 318371421; qLkoAHgZF > 0; qLkoAHgZF--) {
            waPgBpeTt = xRBpspvInwThe;
            nbUHKE += nbUHKE;
        }
    }

    if (nbUHKE <= -1604748019) {
        for (int AKHDNqBoXSypP = 983643177; AKHDNqBoXSypP > 0; AKHDNqBoXSypP--) {
            continue;
        }
    }
}

void TvYiaSrhui::FylHTAnzWdsBF(int uACLINCZjRhHW)
{
    string heQTtgC = string("VdpiepoUyUjxGIgrhixkzySfueUzCucmmhKqmmQgteNPqkvKcqRdTZEEraONSEWoQDidOzZMEBCZVgcLOKxJttYn");
    int aDYWw = -743901827;
    string knvqKvTOHhuBVRSA = string("xilIhmUoedlVzwbzYcIKMnj");
    bool brikLpjNVWpe = false;
    int uhhArQI = -1875926182;
    string cgVndWjh = string("iMiSihDULZhRwFdpYnigqYwZEzxcRqcusZeeRryFJPXBHMvZFkESyblsDqFuCHeSrMUUAkOQULhtoNTQdrAtABsYzvzEjbeVWtCtYZEEQuLSodXefZLoGe");
    string TTflJcbaDEdCrR = string("HQCNEXPmB");

    for (int bCxZBSBZpAgHsun = 1748978910; bCxZBSBZpAgHsun > 0; bCxZBSBZpAgHsun--) {
        uhhArQI = uhhArQI;
        cgVndWjh += TTflJcbaDEdCrR;
        cgVndWjh = cgVndWjh;
        heQTtgC += cgVndWjh;
    }

    if (knvqKvTOHhuBVRSA <= string("HQCNEXPmB")) {
        for (int YGQUu = 1035236282; YGQUu > 0; YGQUu--) {
            cgVndWjh += knvqKvTOHhuBVRSA;
            heQTtgC = knvqKvTOHhuBVRSA;
            heQTtgC = TTflJcbaDEdCrR;
            heQTtgC += knvqKvTOHhuBVRSA;
            knvqKvTOHhuBVRSA = knvqKvTOHhuBVRSA;
        }
    }

    if (uhhArQI >= -743901827) {
        for (int tlfxU = 2131932125; tlfxU > 0; tlfxU--) {
            TTflJcbaDEdCrR += knvqKvTOHhuBVRSA;
        }
    }

    for (int tjvmZCXr = 1609314582; tjvmZCXr > 0; tjvmZCXr--) {
        continue;
    }
}

void TvYiaSrhui::wxVQAKjbMevPplTw(bool EbGChJ, int GLaEkGtlsanbNNKV)
{
    string TMRgXU = string("vZPzCWpsuqlXfgqPqMZwvqKFOYYZSfTsANeAFeEJXalHvrTwtfFZeoOjQYeWdMbNCbpDgaORwJTEQahQLWfaRLFUUIcSLcbqEqfMwSOkBVvYMpebVzYREFRQShaTTmoEhcvzMNtmSAzwLDpobxyZJbYKujGHHkoNr");
    bool GuhLVWa = false;
    int xWJsDkuUeMsJMI = 1789763295;
    double QYanl = -776310.7822028624;
    int vGyrX = -70152351;
    bool pCxUerBKmsohBLti = false;
    string HABjTUQTlJwXA = string("HtvXFYRQlhyr");

    for (int YKuRenYSoKg = 1490707760; YKuRenYSoKg > 0; YKuRenYSoKg--) {
        GuhLVWa = EbGChJ;
        HABjTUQTlJwXA += HABjTUQTlJwXA;
        GuhLVWa = pCxUerBKmsohBLti;
        GLaEkGtlsanbNNKV = GLaEkGtlsanbNNKV;
        HABjTUQTlJwXA = HABjTUQTlJwXA;
    }

    if (TMRgXU < string("HtvXFYRQlhyr")) {
        for (int pfGaPkdhhfPBVk = 332813849; pfGaPkdhhfPBVk > 0; pfGaPkdhhfPBVk--) {
            EbGChJ = GuhLVWa;
            TMRgXU += TMRgXU;
            GLaEkGtlsanbNNKV /= vGyrX;
        }
    }

    for (int dzdJdEeLty = 94378260; dzdJdEeLty > 0; dzdJdEeLty--) {
        continue;
    }

    for (int vTMrEpmafsrWP = 665213908; vTMrEpmafsrWP > 0; vTMrEpmafsrWP--) {
        EbGChJ = ! EbGChJ;
    }

    for (int kMxDcnFyWujIgsPE = 1548394033; kMxDcnFyWujIgsPE > 0; kMxDcnFyWujIgsPE--) {
        continue;
    }
}

bool TvYiaSrhui::glyhdEvWBVnfXDR(int YyoFHBeyFf, double eYRCjcSeqE, int HZrjxbVlbjKXU)
{
    int Zdsfz = 280250912;
    double MXkOIWLyWXtLYpGO = -895818.1804083929;
    int GYgbimEQ = 687708304;
    double DlFYvEtyTq = 70645.25187121333;
    double ulietjVq = -871114.6114643898;
    bool FhEkCK = true;

    for (int LVzWCFslzex = 605256519; LVzWCFslzex > 0; LVzWCFslzex--) {
        YyoFHBeyFf += Zdsfz;
    }

    return FhEkCK;
}

TvYiaSrhui::TvYiaSrhui()
{
    this->rvdJNdcLBLEqPRZ(787957.8651032277);
    this->RCyvVePdPgkkx(-1163870456, string("LtTqHKhoBkpjhhbRGEgYmtekxOcVBenXEXtnVwLkxdwjtZeqOXhrRLVyKIzfOSczxyxfdMzKcaQAYHczbRJwyaIgXSuWsxhYctXkmSzViTBBNgsDnYPZGWOfTKlurOsDBzlCFMeSuimnhtGGsKUdXLJRdvAJqfbgsUqEIADjTYnviJHCQqemVcDIVgbqWojsqdZqEqJNlKoWrIZdhdQVFtmBvrQijOasBDBqmxXJedGihfgG"), -1071998420, 504330468, -1487749991);
    this->pkGkCA(false, -939091214, -1039621.9295919614);
    this->RPFkiy(true, true);
    this->WHJbmGpSoVz();
    this->pQqWwoOg(1763695400);
    this->mesyisZhmf(string("kJmZzKPjcOmjOZzbpLliZrfzZEMlfNOTOPebyjzxwxzQdPfEBbQUNoMOMQlgnGbfvrwHHzELGiOzolZTutQiZNtCmjaYNWwTGeOhjcBPvbBzKcuNLAyuED"), string("UZpaWTpPovuuhVsUGQzQlinoMfvDintwhUkxjavKosKmlpGcnTRNraLoXhpXErvRcfCNXjZVDYtGWlbnGDyXecCIcHEdwKzhxeUlVreuoWhfDpwbSuwFsReFlVjneHfMeWfPBeqMsSdEApQrxtpXWxhGxFcrylkmDwSBjCPafwyRTUiqpFSGzzIgZdaIwdJrbFWJsSNOjkvNuPtWjeVjJIaYNxzFtJvx"));
    this->FylHTAnzWdsBF(1063246372);
    this->wxVQAKjbMevPplTw(false, -1649365891);
    this->glyhdEvWBVnfXDR(-1517416642, -769116.2375378357, 662127775);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UwnTFcCcxe
{
public:
    bool cdCpFlDI;
    int xRfygokNlGHJ;
    string kCuVKpmOALPUl;
    string towaMnuOSyseYM;

    UwnTFcCcxe();
    double CXiIECE(bool HFwRa);
    int mCGJEBFzSWGw(string xLIaYMqg, int IBvPTqobEH, int kaEzW, int NUhwkNK);
    void JdVmFpiG();
    bool sLdrYjLZ(bool VvCfoELVRentWt, bool LtgvZ, string kVlhtoNDgCPgIfD);
    bool DxrlOiMyGflZO();
protected:
    bool lAAvkjFv;
    bool QlEAlxfgQWWSHKzO;

    void GVKbVwJjMOaTqg(int EDgTRisuGg, double zNyBtykkJDfbyZv, bool kvdaTE, bool hdfCJUrO);
    bool YOlQECEWWOjPrrQ();
    int yCjnvWXa(string HYDAgdjul, bool TskdE, double YwNvLJQpB, string eiuwRVSMxWyJQz);
    void mwNea(double hecgX, bool PKmuOzakuJDSuI);
    string ZghrfIzleXG(double wAvMQOz, bool bLcyJbFGEQLpKSEy, string DGTTBKh, string UuxSqhWkRDzZbqhr);
    bool NKiyxQmBdvyO(int bimJBrjEf);
    string gEJOHMGpiY();
    string fhjSQdbVrmecyvl(double bHhRdrME, bool JXxjmSNt, string FYaSnrWv);
private:
    int QWkoC;
    string BxpPenTECbg;
    bool engXvv;

    void yOxTivEtPZRCMsmY(string RGBYJeiyb);
    double pSKWaKF(bool dFAyDYJPPzuxhV);
    void uFfAvAOWnLQTeHnG(double QqlUEUlbv, string MdnzIn, double BozvNsDtclWx);
    string nNmIvMgs(string rKgTKRYpOCJK, int IaQrdfxhWXFka, int BrGOsC);
    int GKCmIdEw(double zcCSTUSyL, string PeAktmCKFrltFxnV, string DxZLPIDz, double HQQkJxWJMulg);
    void ZssuBSQJ(int wnBIujQrZZ, string BDTpqfcnPl, string EFIYRJUIElxXNiVn, bool nNjWmYrYt);
    void QMXqQGJjWbjmnuc(string FMlRoGxe, bool IIvckbCiWFbqshn, bool UGPYmyZZcEhsZKHs, int cEbwOZ, string DRPkVcicuZCHfOqt);
    bool EBNYwMvyPJKoKBGO(bool dKrJxdYU, string aBRIyuxBTYIqPi);
};

double UwnTFcCcxe::CXiIECE(bool HFwRa)
{
    bool tuZwLtaPddFpLyQb = true;
    string EhRnxMdBS = string("oJcPNkEvD");
    double UhmGMAJFD = -354372.5079690756;
    int PdAXkRWTmBdCqi = 1409366083;
    int NUhSQxLcdnq = 2064729719;
    string tISOzXyYkIVmuDj = string("GIAbWaMvYkLsNHVZpbfWAaPUmUPRmjqhQjXqPylpBTblwOwhglWNbNHFxbHootaUjdKDFnnyfRpFbZUKhGjmKtZJNWVPBEeYYkiLmQraiyAjsfbgB");
    int FhsWvnAWULOf = 620576199;
    string ZtDOAIENb = string("TXAtueIcrByMnoYoOhLkJaTGIFtLAnMRQobbxwfYrkeTFpQvMcdDuskOaGOKgFybHAyezGrsiJEcxIRvkeUzXOgtYtovKmMoEdQqqRIaSersNlvyRLcGMbIjFqqjTNtanz");

    for (int tOLHLKUd = 928466721; tOLHLKUd > 0; tOLHLKUd--) {
        tISOzXyYkIVmuDj += EhRnxMdBS;
    }

    for (int rcvJMEAIfYI = 239979103; rcvJMEAIfYI > 0; rcvJMEAIfYI--) {
        continue;
    }

    for (int zYvqjDzoPlrPHbq = 1328152752; zYvqjDzoPlrPHbq > 0; zYvqjDzoPlrPHbq--) {
        HFwRa = tuZwLtaPddFpLyQb;
        HFwRa = HFwRa;
        NUhSQxLcdnq *= PdAXkRWTmBdCqi;
    }

    return UhmGMAJFD;
}

int UwnTFcCcxe::mCGJEBFzSWGw(string xLIaYMqg, int IBvPTqobEH, int kaEzW, int NUhwkNK)
{
    string nTFwlgjSwsxAJ = string("SjOMhIwiiXalCokbNtOUpxtmPydlshBGAtWjgXaqONJIafuNZdtWmXHMtIRGvnqTYwPSpjOU");
    bool baDLLaQEvlpI = false;
    int AacQGHyyC = 947409660;
    bool EscNVtU = false;
    bool WzOHZo = true;
    int IMyIX = -126995413;
    double kGjpXaBNXiMinLs = -491099.55575231934;
    string epNrx = string("sOcHTFSIeqEunoRaMRqcsZfkvSQXBMTDICoSCQWCOPxmhbgRvJMsWrpkHQGZdfWSPRbmPMjKujljRfippIFXdChyViPiJBsoWYgDsePnpNfaFmRLRVLUfVOjuQoIrWgOMOcpyXPNZQnMzkYXKVqwzEJpVxWXGFhaRSHaMwUOMXLfCpTZdiZMXNmdSmvNFjtdQUpxTnxZSIVFaljaJJKZacqpiOZTkWozaDsQYryOPEqaeXcunJdDGbVvxWG");
    string UzYKe = string("GLbUHjxYstgLmxFQEeTTEJCCsVUBoMLFhmoDvTmsOddliynadfYhOOBikoAvwkEdLXDQFqbzsFebAvSTZgbeMVNzLWNNdBsnFvyZwOoPberijtTjYgwcJSjmAtypzhoWkRogxUHizvBXZXLZaJHidwQkewrvcidKQojDlrBezlGbOq");
    bool txXgk = true;

    for (int TlDqKNtoAIl = 606115788; TlDqKNtoAIl > 0; TlDqKNtoAIl--) {
        nTFwlgjSwsxAJ = nTFwlgjSwsxAJ;
        kaEzW *= IBvPTqobEH;
    }

    return IMyIX;
}

void UwnTFcCcxe::JdVmFpiG()
{
    string ebpmTfY = string("mokKjTRUTyWtcwGCsFSXqBdRHPKyFxOxMLRbsNPmVidLQRNIfIYOyNtAjmOqvPiDfRJkXWtneQeDmsiEQJKoosvjUmUYfndYNBDbwdAkQmURBcfuNDQcYMxUrXospzsaZrSLfshQCMXVZgSvHZSuNZpUcjCur");
    bool sGMUyVl = false;
    bool IJNWvjjtftoVeOr = false;
    bool uMNDXeHBR = false;
    int NRYamrWHTHUTsTC = -185228671;
    double nLvfvqctJhgEAbNq = -77084.67672276971;

    for (int QruuhQgdeIeNtdf = 1453592644; QruuhQgdeIeNtdf > 0; QruuhQgdeIeNtdf--) {
        uMNDXeHBR = ! sGMUyVl;
        uMNDXeHBR = ! IJNWvjjtftoVeOr;
    }

    for (int QYiMAaU = 399830704; QYiMAaU > 0; QYiMAaU--) {
        NRYamrWHTHUTsTC = NRYamrWHTHUTsTC;
        nLvfvqctJhgEAbNq /= nLvfvqctJhgEAbNq;
        NRYamrWHTHUTsTC -= NRYamrWHTHUTsTC;
    }

    if (NRYamrWHTHUTsTC <= -185228671) {
        for (int egAygtKgkjcJeeLE = 431803364; egAygtKgkjcJeeLE > 0; egAygtKgkjcJeeLE--) {
            sGMUyVl = ! uMNDXeHBR;
            nLvfvqctJhgEAbNq -= nLvfvqctJhgEAbNq;
        }
    }
}

bool UwnTFcCcxe::sLdrYjLZ(bool VvCfoELVRentWt, bool LtgvZ, string kVlhtoNDgCPgIfD)
{
    bool nwCuUqpHEh = true;
    int VEzjh = 1578649612;
    double VGLfjik = -181932.7199031626;
    bool NIgzbuXSCuGtz = true;
    string MpdZszREqXhsxWD = string("RcHeJIctpypMVvzPgilhYpCgCkAFmCjUUACVDWmKszFWKyPotDDnlvsnMYVCGCgoINtMQkameCpXVkuKnoDENteriInjehNfbU");
    bool ubFYjxbBmWbRR = false;
    double CMxozosUur = -916766.4204905805;
    int gyhcNxOt = -1219461775;
    string bRVTdfvg = string("EoSakXCRWxLpzDnDkBcAQEBHNntSkVJNSCIqdHusSAUAUKCvXsczIQYtnnwQwalbvdbVkGJLTyKrADJgYulttttTWKpiQQPLauRVTzRwWnXEjAeJrCgknfiOpCVAfctmlWDOkljteUEhllIFGaUEtpFYlXsYtwzYqOZKeDutMaKyvIIPlzUDKuaqRPxiMoJAEhLWNhgdmXsHmsvxNpxqosOJTrYhOqFUzoobgGepBdYRqqTiAnhI");

    for (int qWFYNZBoOU = 19824288; qWFYNZBoOU > 0; qWFYNZBoOU--) {
        LtgvZ = NIgzbuXSCuGtz;
    }

    for (int cNoygiw = 504076082; cNoygiw > 0; cNoygiw--) {
        CMxozosUur *= VGLfjik;
    }

    for (int xoBsZQuOEAjB = 1045428115; xoBsZQuOEAjB > 0; xoBsZQuOEAjB--) {
        continue;
    }

    return ubFYjxbBmWbRR;
}

bool UwnTFcCcxe::DxrlOiMyGflZO()
{
    bool cUkRPzJfdm = false;
    int AkbqlJcIYelKRDXz = -758976398;
    int nitdIOJHQ = 1591060063;

    for (int leiERCwWXCmWr = 1940305974; leiERCwWXCmWr > 0; leiERCwWXCmWr--) {
        nitdIOJHQ += nitdIOJHQ;
    }

    for (int pgvDxYGXagQBfLB = 1688392788; pgvDxYGXagQBfLB > 0; pgvDxYGXagQBfLB--) {
        nitdIOJHQ *= nitdIOJHQ;
        nitdIOJHQ += nitdIOJHQ;
        AkbqlJcIYelKRDXz += nitdIOJHQ;
        AkbqlJcIYelKRDXz += nitdIOJHQ;
        AkbqlJcIYelKRDXz = AkbqlJcIYelKRDXz;
        cUkRPzJfdm = ! cUkRPzJfdm;
        nitdIOJHQ *= AkbqlJcIYelKRDXz;
    }

    if (AkbqlJcIYelKRDXz >= -758976398) {
        for (int Pdvtm = 1816155528; Pdvtm > 0; Pdvtm--) {
            AkbqlJcIYelKRDXz -= nitdIOJHQ;
        }
    }

    for (int yzSeIBZKtfGmsh = 791362446; yzSeIBZKtfGmsh > 0; yzSeIBZKtfGmsh--) {
        nitdIOJHQ -= AkbqlJcIYelKRDXz;
    }

    return cUkRPzJfdm;
}

void UwnTFcCcxe::GVKbVwJjMOaTqg(int EDgTRisuGg, double zNyBtykkJDfbyZv, bool kvdaTE, bool hdfCJUrO)
{
    string qHmxpjOmt = string("OLAqHpTxpHUdqUxGvdxMHkfTvzvclwEnbhKdybyOSGfRgrKWobehEyNFdbdInCRztgwRYTPBQnoTHCggywRzueKJXFDpMGthYHhbRDrVBWlktwCWZxHMCXMBkuJpTSGHDTpGBwKXVzoUysSbcMRXjGMwOiUOxTTSgWXNM");
    bool sFpgGHZUm = true;
    string tprqOHRWTOS = string("mBWmKeWxqDcdUOWwjdwmjwCMYISxRRbwyHVhHfZBCqwgJqvCLfZjbPaXwFxGSwFtBbmTvzifJlfBxDpCZzFTNjWnCfOZpgaLEVkmgrcZbVmFjQwtBOYEBXmpyMZPlREapxdshYOtNyblDOVoGHhWpgkWCQgbhyKRmnYRrmUsadlJYfdGZKDqVXYyNw");
    int PoJcpMU = -1048364726;

    for (int CobsIhlV = 1073107646; CobsIhlV > 0; CobsIhlV--) {
        sFpgGHZUm = kvdaTE;
        hdfCJUrO = sFpgGHZUm;
        PoJcpMU -= EDgTRisuGg;
    }
}

bool UwnTFcCcxe::YOlQECEWWOjPrrQ()
{
    string vwIIjg = string("WaLbYkLlbngSUCJWdJeRvCwwrzDMnC");
    double aSgJVeBkGxrHGbsG = -73328.34907456339;
    string MXurQvRn = string("IFOpxLuNRlTPYClsnxmUruvumVUSzYytddBJRv");
    int AJPlPuMYksDSPZd = 1656609642;
    double nGApwUhWWLcZ = -521264.75111923047;
    int YGKlzfxMMrPLgn = -479892562;
    int BGxPwnR = 232956235;
    bool DyCjXpZvB = false;
    int ekefRGVlYgTq = -1684288653;

    if (MXurQvRn <= string("WaLbYkLlbngSUCJWdJeRvCwwrzDMnC")) {
        for (int sWieRDOYlWguI = 716104000; sWieRDOYlWguI > 0; sWieRDOYlWguI--) {
            vwIIjg = vwIIjg;
            vwIIjg += vwIIjg;
            AJPlPuMYksDSPZd -= BGxPwnR;
            AJPlPuMYksDSPZd -= BGxPwnR;
            ekefRGVlYgTq += BGxPwnR;
            ekefRGVlYgTq /= AJPlPuMYksDSPZd;
        }
    }

    for (int FfmghKWUSQeRlDSZ = 1295211089; FfmghKWUSQeRlDSZ > 0; FfmghKWUSQeRlDSZ--) {
        YGKlzfxMMrPLgn += ekefRGVlYgTq;
        nGApwUhWWLcZ /= aSgJVeBkGxrHGbsG;
        ekefRGVlYgTq -= AJPlPuMYksDSPZd;
        MXurQvRn += vwIIjg;
        ekefRGVlYgTq = AJPlPuMYksDSPZd;
    }

    for (int dsJynMyYKNk = 2131359647; dsJynMyYKNk > 0; dsJynMyYKNk--) {
        YGKlzfxMMrPLgn = BGxPwnR;
        BGxPwnR -= AJPlPuMYksDSPZd;
        ekefRGVlYgTq *= ekefRGVlYgTq;
    }

    for (int MvnLIsqirB = 1603563205; MvnLIsqirB > 0; MvnLIsqirB--) {
        continue;
    }

    return DyCjXpZvB;
}

int UwnTFcCcxe::yCjnvWXa(string HYDAgdjul, bool TskdE, double YwNvLJQpB, string eiuwRVSMxWyJQz)
{
    bool NSCwwiXB = true;
    double EwfGreoEK = 1004583.0241211121;
    bool INMBvZmHxE = true;
    double LsprpCJsQaMTYVj = -87411.73598392805;
    int KxFJpNmV = -421545794;
    double bzOzYO = -344638.0676208209;

    for (int YzoVjSADamWsPXu = 948193834; YzoVjSADamWsPXu > 0; YzoVjSADamWsPXu--) {
        eiuwRVSMxWyJQz += eiuwRVSMxWyJQz;
    }

    for (int XaGurDGVKEOTxzJ = 1956877453; XaGurDGVKEOTxzJ > 0; XaGurDGVKEOTxzJ--) {
        bzOzYO += bzOzYO;
    }

    return KxFJpNmV;
}

void UwnTFcCcxe::mwNea(double hecgX, bool PKmuOzakuJDSuI)
{
    string jlCuoeDcuIZg = string("YEFniUafpLgacxYITcJnMUzuWKqbvWYAUbeHtnzjRYVJvnBRaslVgGncqSwGLKmnMvEruBOeCvXKkbYTMHwxMpTeysHRZnLQPRHnCbRyufDbZKnneWMXowuczrDnQAakwQDPnqqDliiUayJqIzDeiMwURunMafkdVcQPS");
    bool XmIxAM = true;
    bool DEtnpwyJL = true;
    bool AbDSHtPGIhSASWBU = true;
    double biONXmOFnPhsnFP = -261821.6001320264;

    for (int ATQwS = 1090840213; ATQwS > 0; ATQwS--) {
        XmIxAM = ! DEtnpwyJL;
        AbDSHtPGIhSASWBU = ! PKmuOzakuJDSuI;
    }

    for (int OfBMpODPnTJZZxVk = 1326598537; OfBMpODPnTJZZxVk > 0; OfBMpODPnTJZZxVk--) {
        AbDSHtPGIhSASWBU = ! AbDSHtPGIhSASWBU;
        XmIxAM = PKmuOzakuJDSuI;
        PKmuOzakuJDSuI = ! DEtnpwyJL;
        AbDSHtPGIhSASWBU = ! AbDSHtPGIhSASWBU;
        XmIxAM = DEtnpwyJL;
    }

    if (XmIxAM != true) {
        for (int AmqIMwzevRE = 1824822435; AmqIMwzevRE > 0; AmqIMwzevRE--) {
            PKmuOzakuJDSuI = AbDSHtPGIhSASWBU;
            XmIxAM = ! XmIxAM;
            DEtnpwyJL = ! PKmuOzakuJDSuI;
            PKmuOzakuJDSuI = DEtnpwyJL;
            biONXmOFnPhsnFP *= biONXmOFnPhsnFP;
            DEtnpwyJL = XmIxAM;
        }
    }
}

string UwnTFcCcxe::ZghrfIzleXG(double wAvMQOz, bool bLcyJbFGEQLpKSEy, string DGTTBKh, string UuxSqhWkRDzZbqhr)
{
    double BRlYzhrKub = 145455.4149234538;

    if (wAvMQOz >= -314198.4366224894) {
        for (int FDUjYipjwvmlYs = 1987338233; FDUjYipjwvmlYs > 0; FDUjYipjwvmlYs--) {
            wAvMQOz /= wAvMQOz;
        }
    }

    if (UuxSqhWkRDzZbqhr != string("layYbNfYIvOpbwndHZpnoWamojTjkFlmkmakXqorPnyQIovptHqKwcVELztGqPzSrKkjXxDljgnVOBcZQlwcKjvYwigxYhKxvnuiyKEysPCeqySJizonlgwmYpsSkLNHqkWoMHzNCCoTrhABFVnBRlSreLrqJTyCKJbKoUyCjbtuoJx")) {
        for (int GTVJAcslc = 1320500515; GTVJAcslc > 0; GTVJAcslc--) {
            BRlYzhrKub = wAvMQOz;
            BRlYzhrKub /= wAvMQOz;
            wAvMQOz *= wAvMQOz;
        }
    }

    if (bLcyJbFGEQLpKSEy != false) {
        for (int cOplMTVO = 1166969653; cOplMTVO > 0; cOplMTVO--) {
            BRlYzhrKub /= BRlYzhrKub;
            UuxSqhWkRDzZbqhr += UuxSqhWkRDzZbqhr;
            wAvMQOz = wAvMQOz;
        }
    }

    for (int pUciRcvQLEA = 527609231; pUciRcvQLEA > 0; pUciRcvQLEA--) {
        wAvMQOz *= BRlYzhrKub;
    }

    if (wAvMQOz != -314198.4366224894) {
        for (int UwgenBKatZp = 1087466582; UwgenBKatZp > 0; UwgenBKatZp--) {
            bLcyJbFGEQLpKSEy = ! bLcyJbFGEQLpKSEy;
        }
    }

    if (DGTTBKh != string("wUUwprOEyrdEEGoBXBcBhWeXFDXuOwnJkgZgXVypTOuSzShnDfJWPpOFJvdycKDLNhAyKjmMlwsLsiaakSqaxZVmAMFZIFGGQplekxTUxwUuXhrAbVyXXguQhXuTfdiQklYdX")) {
        for (int XBsBQA = 1514840452; XBsBQA > 0; XBsBQA--) {
            DGTTBKh = UuxSqhWkRDzZbqhr;
            UuxSqhWkRDzZbqhr += UuxSqhWkRDzZbqhr;
        }
    }

    if (wAvMQOz >= -314198.4366224894) {
        for (int hXfrUpU = 237391175; hXfrUpU > 0; hXfrUpU--) {
            continue;
        }
    }

    return UuxSqhWkRDzZbqhr;
}

bool UwnTFcCcxe::NKiyxQmBdvyO(int bimJBrjEf)
{
    double tWBAdNYjp = -897347.5433621624;
    double lAXbfw = 919706.3677561652;
    int PrBYCjCGfO = 1118768700;
    double JVTSUiCisIOfjel = 632720.607329165;
    bool FXsMQNzPsJL = true;
    string eLGHIFO = string("gYxaLSeTZHoDgNknMThqkcwrZrzEMQaaKvsxGcjTHZoVGWbydBToRQbtKDdtbmYLyursXZkPiooZaXQCxHiPuhtqTVgijTsdxCgAuztVONXpaqqvrqoUYOVbVmGQAQXCQLoCHUaDLKlcvGzOpVfkPANzUUOWjsUGYtAqJYfvBsqjKQYhqSbTF");
    string iHJVjyTGsrv = string("icNhRPAqxopGtrYPfaHzzxPPHwktRPWheszmIXPvvhWrPWCcPVuMVlxkXoxGVbsuPoTMpZHXXqJemxGiApbKsCZluMYyxsVxowcvLcRfEBNLgCCmIkhSRZTegSdYBA");

    for (int YHYpvaFBSct = 263641619; YHYpvaFBSct > 0; YHYpvaFBSct--) {
        bimJBrjEf *= PrBYCjCGfO;
        eLGHIFO = iHJVjyTGsrv;
    }

    return FXsMQNzPsJL;
}

string UwnTFcCcxe::gEJOHMGpiY()
{
    double zADwOiiGMu = -768688.4796866211;
    bool FKcJia = false;
    double zJkLjNJ = -115536.06083181206;
    int cMsaPZdRlgtqJS = -263017046;
    int xnwWroTfWL = -2009729328;

    if (FKcJia != false) {
        for (int SmLpzerfR = 684877424; SmLpzerfR > 0; SmLpzerfR--) {
            cMsaPZdRlgtqJS -= cMsaPZdRlgtqJS;
        }
    }

    return string("rsvkFJpUYJdFwuuBntSUFuMLuPMEEVVfHlEyJNFnfEoqutzlJbjoWzFWUjWEfHmdBSCOlYKpRIkHHQgUtHnLThnszwRhTxhbiEkSZcXMhuFqXjkbpAcSlTPXSyUzwIjiKeWKQaqZ");
}

string UwnTFcCcxe::fhjSQdbVrmecyvl(double bHhRdrME, bool JXxjmSNt, string FYaSnrWv)
{
    string ATGSmtf = string("PXEWTUggNiuTKBooZCjmEcBRdgTEWlLjRpzPnoXyiTDgoduxmsHbaPlMqzylASmlPkjfgKeeJcCiQTFxn");
    int mgjwOMAe = 1414404227;

    for (int CokyrDAMxhewASwC = 2147208144; CokyrDAMxhewASwC > 0; CokyrDAMxhewASwC--) {
        continue;
    }

    if (mgjwOMAe <= 1414404227) {
        for (int OTAfInqiC = 813330761; OTAfInqiC > 0; OTAfInqiC--) {
            FYaSnrWv += FYaSnrWv;
        }
    }

    if (FYaSnrWv <= string("NaWNYSlmSjPbpZvarFvbLWkVesOLtJh")) {
        for (int IYOmzlwZOssTDE = 1855253518; IYOmzlwZOssTDE > 0; IYOmzlwZOssTDE--) {
            FYaSnrWv = ATGSmtf;
            mgjwOMAe += mgjwOMAe;
        }
    }

    return ATGSmtf;
}

void UwnTFcCcxe::yOxTivEtPZRCMsmY(string RGBYJeiyb)
{
    int ZxzzHKIIufwWb = -1360738346;

    for (int letttFqKwrM = 307966611; letttFqKwrM > 0; letttFqKwrM--) {
        RGBYJeiyb = RGBYJeiyb;
        RGBYJeiyb += RGBYJeiyb;
    }

    if (RGBYJeiyb > string("fLcawmTIbtInhWHjZXcqgqsTjCuAOwlnDfYAcxWPmKqOxxluBAmSdhuSYmhMBSNkaeOCyofjFEjhfEaxeofKmLzLwQlqepDfct")) {
        for (int cArXQqqksDP = 1170461782; cArXQqqksDP > 0; cArXQqqksDP--) {
            ZxzzHKIIufwWb += ZxzzHKIIufwWb;
            ZxzzHKIIufwWb *= ZxzzHKIIufwWb;
            ZxzzHKIIufwWb += ZxzzHKIIufwWb;
            ZxzzHKIIufwWb /= ZxzzHKIIufwWb;
        }
    }

    if (RGBYJeiyb == string("fLcawmTIbtInhWHjZXcqgqsTjCuAOwlnDfYAcxWPmKqOxxluBAmSdhuSYmhMBSNkaeOCyofjFEjhfEaxeofKmLzLwQlqepDfct")) {
        for (int eIKHI = 746982685; eIKHI > 0; eIKHI--) {
            ZxzzHKIIufwWb *= ZxzzHKIIufwWb;
            ZxzzHKIIufwWb = ZxzzHKIIufwWb;
            ZxzzHKIIufwWb = ZxzzHKIIufwWb;
            ZxzzHKIIufwWb *= ZxzzHKIIufwWb;
            ZxzzHKIIufwWb -= ZxzzHKIIufwWb;
            RGBYJeiyb += RGBYJeiyb;
        }
    }
}

double UwnTFcCcxe::pSKWaKF(bool dFAyDYJPPzuxhV)
{
    int fFMzF = 146636312;
    string dEYLdUHU = string("dGEpbqqonEtRPqwtNvMMXNaAdBqdGlfHOBpFmRJyNTYkZgYUJNIsjUatcOYcpoBDzbTRYrValjsFTUmwQpyyslaQKNRoWsekRtWhOQNViBoSBdrBvCalAudlhDwPJLaYYSRzdJvRnBrhudCvhsHbQxTwXBKSAdjpT");
    int AMYqyKsJgCcC = -622173199;
    double LoUhmUr = 605608.0958418733;
    int iwUVGLBh = 1059749300;
    bool WjfZQoMs = true;

    for (int ETFxxCKngiIZY = 790737370; ETFxxCKngiIZY > 0; ETFxxCKngiIZY--) {
        continue;
    }

    for (int yQufTCwytYRngO = 687002446; yQufTCwytYRngO > 0; yQufTCwytYRngO--) {
        iwUVGLBh *= fFMzF;
        AMYqyKsJgCcC *= AMYqyKsJgCcC;
    }

    for (int GISjwyIXgAKHJCE = 1325658747; GISjwyIXgAKHJCE > 0; GISjwyIXgAKHJCE--) {
        dFAyDYJPPzuxhV = ! dFAyDYJPPzuxhV;
        fFMzF = AMYqyKsJgCcC;
        WjfZQoMs = ! dFAyDYJPPzuxhV;
        fFMzF *= fFMzF;
    }

    for (int wItMQbyWyJMgopaU = 1262611599; wItMQbyWyJMgopaU > 0; wItMQbyWyJMgopaU--) {
        continue;
    }

    return LoUhmUr;
}

void UwnTFcCcxe::uFfAvAOWnLQTeHnG(double QqlUEUlbv, string MdnzIn, double BozvNsDtclWx)
{
    int LoACCZCmzvVeMzrj = -583407263;
    bool DdVSUouyxv = false;
    string HAFRlEZp = string("dNawMDMQRetFrvRlQJlxVgAqyhRmOMMJfDkmsDMGHDMlynnOrjvMlOmhgWGDlFTGosNgpiqFRDvpaIUzVraMAtAmJIDtJMHTfGmAZpNpWnjNspCvJwoabbmSJQSedBcycFWmgMzPPspdayEiLkNpZpnzjfripZquHMpQChXzHpfEEzz");
    int lXOIcxVyssPGixT = -1321129357;
    bool QinPOcnCiuDVf = false;
    string sMGCOwtWAAAquD = string("kITofeWGXiARNYUsDVoFrBizqxKNRfMwkBLkguUrNEnjsHdssxtiRGeFeACPazSpZXAqroTjED");
    double mXzaTfeAhOfkrdF = 207909.55504560185;

    for (int RvzMZCgrzNopp = 579938706; RvzMZCgrzNopp > 0; RvzMZCgrzNopp--) {
        lXOIcxVyssPGixT = LoACCZCmzvVeMzrj;
        LoACCZCmzvVeMzrj = lXOIcxVyssPGixT;
    }

    for (int maKWlwj = 631893199; maKWlwj > 0; maKWlwj--) {
        BozvNsDtclWx -= mXzaTfeAhOfkrdF;
    }

    for (int BeVtMgfCssKwY = 1272457661; BeVtMgfCssKwY > 0; BeVtMgfCssKwY--) {
        QqlUEUlbv /= QqlUEUlbv;
        QinPOcnCiuDVf = DdVSUouyxv;
    }
}

string UwnTFcCcxe::nNmIvMgs(string rKgTKRYpOCJK, int IaQrdfxhWXFka, int BrGOsC)
{
    string GGyfSXVCcAbLLgtF = string("UNaSAlxWnHbSpgzCChLJkAXJlAorfKYcr");
    int eUpKtUGAujPNPmsU = 1279967285;

    for (int GymWdChmBnaTTGwR = 1425371645; GymWdChmBnaTTGwR > 0; GymWdChmBnaTTGwR--) {
        eUpKtUGAujPNPmsU *= IaQrdfxhWXFka;
        eUpKtUGAujPNPmsU /= eUpKtUGAujPNPmsU;
        rKgTKRYpOCJK = rKgTKRYpOCJK;
        IaQrdfxhWXFka *= eUpKtUGAujPNPmsU;
        eUpKtUGAujPNPmsU = IaQrdfxhWXFka;
        eUpKtUGAujPNPmsU += BrGOsC;
        BrGOsC /= eUpKtUGAujPNPmsU;
        IaQrdfxhWXFka = BrGOsC;
    }

    for (int FnyQeRryibzSywLg = 747078571; FnyQeRryibzSywLg > 0; FnyQeRryibzSywLg--) {
        BrGOsC -= IaQrdfxhWXFka;
    }

    for (int nwIobwLpSdWdo = 1590607107; nwIobwLpSdWdo > 0; nwIobwLpSdWdo--) {
        BrGOsC /= IaQrdfxhWXFka;
        IaQrdfxhWXFka /= BrGOsC;
        eUpKtUGAujPNPmsU += IaQrdfxhWXFka;
        GGyfSXVCcAbLLgtF = GGyfSXVCcAbLLgtF;
        BrGOsC -= IaQrdfxhWXFka;
        BrGOsC /= IaQrdfxhWXFka;
        IaQrdfxhWXFka *= eUpKtUGAujPNPmsU;
        GGyfSXVCcAbLLgtF = GGyfSXVCcAbLLgtF;
    }

    if (BrGOsC <= 1279967285) {
        for (int GsYLTqtANgmtpDKe = 540009243; GsYLTqtANgmtpDKe > 0; GsYLTqtANgmtpDKe--) {
            BrGOsC = IaQrdfxhWXFka;
        }
    }

    return GGyfSXVCcAbLLgtF;
}

int UwnTFcCcxe::GKCmIdEw(double zcCSTUSyL, string PeAktmCKFrltFxnV, string DxZLPIDz, double HQQkJxWJMulg)
{
    string xKdDtipssReIgJj = string("DqDdHFloSWylPgyQGeKuAFiSkBhSTIVQJfhYbThQLQHDOIjHFNTEMyQLzpNCVdqhDBCspUuwnoNHKFAtbbimS");
    bool DtbwnmyHRDHN = false;
    string qUgNkmMimBiY = string("adwZrcywlWpOtymLFJajMpwFKFJmnkMMzUFcGduwEMobsueMWWKPexLRsBHQxMRyIxXPKiHJNwVmjHGgnvKOrrReDoZWcFjpCQfPMcmnjTDtxMGvMgDJXQgDgAsqIkRTyjsQvRRLqvjEkJQnijAoCwhvsDjJONLRdWhbwfkReMRMkMlfwngjDxFWUZnubOxOrdwoxenIQptfUdrrCpIkxkaBinmXJzJjBbuOVvLX");

    for (int wINHHahYxhPLqixc = 371855397; wINHHahYxhPLqixc > 0; wINHHahYxhPLqixc--) {
        DtbwnmyHRDHN = DtbwnmyHRDHN;
        DxZLPIDz = DxZLPIDz;
    }

    return 853049866;
}

void UwnTFcCcxe::ZssuBSQJ(int wnBIujQrZZ, string BDTpqfcnPl, string EFIYRJUIElxXNiVn, bool nNjWmYrYt)
{
    string WoPubcCVUB = string("AIUrkL");

    if (BDTpqfcnPl <= string("YeFKyPjdqEMzXjVLd")) {
        for (int sVHJIJtmEYjJ = 2040313906; sVHJIJtmEYjJ > 0; sVHJIJtmEYjJ--) {
            nNjWmYrYt = nNjWmYrYt;
            EFIYRJUIElxXNiVn += WoPubcCVUB;
            WoPubcCVUB += BDTpqfcnPl;
        }
    }
}

void UwnTFcCcxe::QMXqQGJjWbjmnuc(string FMlRoGxe, bool IIvckbCiWFbqshn, bool UGPYmyZZcEhsZKHs, int cEbwOZ, string DRPkVcicuZCHfOqt)
{
    double ApWxLmVsYqSVpQ = -165686.15621831367;
    bool LZbLmSmUrubNrNL = false;
    int ryVjfsLf = 1579607053;
    int boOqWczEjGKgNPSO = -1473487402;
    string qRZYlcFRuHZcYYR = string("VHhjrMLIHpmNsAHfbkRAHyURLbToakhjYrGWvGVGwqyPPXqmyzgRItpEWoxJlmfPOPTiTldUGexLNdfzICeMpurzURqlZENiSqLKuXcEkyZDfaLYqLiqedjvVeZZGREERSouPMfqufHvelLkJluxOGgedEWUPFmTRCyaqlneMIzZdHICgcLOgBGiGDZZJmbMxfnySgjGftmGqOTORuIBOjwhotFqYTVuKAQtlMGcZVTtPlgnnZSHOgCJ");
    int wUFiGmQEz = -18167263;
    double nVbpshTYuB = -755486.0414733511;

    if (LZbLmSmUrubNrNL != false) {
        for (int XQrxodDoWcXEXhkn = 587506219; XQrxodDoWcXEXhkn > 0; XQrxodDoWcXEXhkn--) {
            cEbwOZ += cEbwOZ;
            cEbwOZ *= cEbwOZ;
        }
    }

    for (int xQSYUPEdsOPyvlD = 280042076; xQSYUPEdsOPyvlD > 0; xQSYUPEdsOPyvlD--) {
        cEbwOZ /= wUFiGmQEz;
        qRZYlcFRuHZcYYR = DRPkVcicuZCHfOqt;
    }

    for (int ZYWNpyWlnaBHBn = 635281164; ZYWNpyWlnaBHBn > 0; ZYWNpyWlnaBHBn--) {
        boOqWczEjGKgNPSO -= wUFiGmQEz;
        ryVjfsLf /= cEbwOZ;
    }
}

bool UwnTFcCcxe::EBNYwMvyPJKoKBGO(bool dKrJxdYU, string aBRIyuxBTYIqPi)
{
    double JbskmoH = 304000.6764362093;
    bool pbQHFUQEs = true;
    bool FsdUCF = false;
    string kpthe = string("aVKVOHafcfSbtFYWhvxYXMKlwbQMRnhtGYMYfiJnCOAsNqPmaKEBJzmEulAVQaoqnyxwVtIMAJJenXsczYPKlEOWfzsebZmnGXwgNaiYVrcZIHvBaFhfecpJfKcJVUnnyhYDaUbTxZbyqfmuOAllyKsHRppWhktRSEOJJ");
    string CSBSZhUXJC = string("KPFQbgLjiuJOCcnxmNxjDrzrBWwQyAMaFTpGnaGeNdNSnnwzOTiAjCDXJCWUROdFuCojnUTQiBxBHIvRSprHGGeBJVjUgoTxuLKebuleJvHAtRjKJCrZoBjhdJMtOMMNIfFDlEKXbTJcmrnLDdujuLRIEzuQiRXzepWMoAmzmAkHXcQaaUTPaItpJesoHCUYdHrcTikKDxzycMTHsLWuJMMvx");
    string uRdgquEiACMzpq = string("ExRzuZjgWqgNXRmHnPBtTWIxcvGcPhxYtJjpMNVHdATIzEkwENitEHPRMKFGujXfbjRtqHgNQMoGltjpWYvPMQnDjlYaAlgkykJlHrMdtrINkSXLGDFwpXxXmXMFSCrEdOTKq");
    int RVkhtrOFgtRFMxu = 1563717452;
    string Ozwjpq = string("ckSPNwiTdbOKIDpMPVBOxTCwJIOOlthkfuLEpbVPNYBzDHwlVcrekQvYLmKQBdJNQgxl");

    for (int VTXAp = 799427317; VTXAp > 0; VTXAp--) {
        FsdUCF = ! dKrJxdYU;
        CSBSZhUXJC = uRdgquEiACMzpq;
        uRdgquEiACMzpq += CSBSZhUXJC;
        aBRIyuxBTYIqPi += uRdgquEiACMzpq;
    }

    return FsdUCF;
}

UwnTFcCcxe::UwnTFcCcxe()
{
    this->CXiIECE(false);
    this->mCGJEBFzSWGw(string("HJxoHvGjCoOwbXSgJpQjgbEqd"), -1994788387, 57558989, 1901725516);
    this->JdVmFpiG();
    this->sLdrYjLZ(true, false, string("oMEuxoTFYciHHnArSyljMOBtyGAjcDMRtbWppHMLcWVmseHnoFPrf"));
    this->DxrlOiMyGflZO();
    this->GVKbVwJjMOaTqg(379183187, 790176.0528419036, true, true);
    this->YOlQECEWWOjPrrQ();
    this->yCjnvWXa(string("zLmoDutzqKTVtNeXuYjMPSIDNCrXEeZaUKGGVbmIQvnpIuSsndDdmpDgTeaZHRLzEbxGPpVhBfRdRYpcFnFjxaADtrhJSISJrBEPcPoZHHhgRYnCWlUIaYYI"), false, -542002.8460560814, string("WQyaKGdenKwAjcUNLXxQTnQaCOOmuTJGZSrObSwhiIzELKhspsyWoXBAHpYPcXAgzKiOTDzrcnqdhqFOOZqJGQHszDLONVGqHokOtHzJurAlpebeihhlRlXCJpYavhfQTHjyheuXbEXujImTWMKHCdDZGBOnrqBLVnyrGGlJclMFaBjqjTUhlwryASPMAmNzVtKt"));
    this->mwNea(-445523.165517152, false);
    this->ZghrfIzleXG(-314198.4366224894, false, string("layYbNfYIvOpbwndHZpnoWamojTjkFlmkmakXqorPnyQIovptHqKwcVELztGqPzSrKkjXxDljgnVOBcZQlwcKjvYwigxYhKxvnuiyKEysPCeqySJizonlgwmYpsSkLNHqkWoMHzNCCoTrhABFVnBRlSreLrqJTyCKJbKoUyCjbtuoJx"), string("wUUwprOEyrdEEGoBXBcBhWeXFDXuOwnJkgZgXVypTOuSzShnDfJWPpOFJvdycKDLNhAyKjmMlwsLsiaakSqaxZVmAMFZIFGGQplekxTUxwUuXhrAbVyXXguQhXuTfdiQklYdX"));
    this->NKiyxQmBdvyO(-2060538309);
    this->gEJOHMGpiY();
    this->fhjSQdbVrmecyvl(479930.99041630386, true, string("NaWNYSlmSjPbpZvarFvbLWkVesOLtJh"));
    this->yOxTivEtPZRCMsmY(string("fLcawmTIbtInhWHjZXcqgqsTjCuAOwlnDfYAcxWPmKqOxxluBAmSdhuSYmhMBSNkaeOCyofjFEjhfEaxeofKmLzLwQlqepDfct"));
    this->pSKWaKF(true);
    this->uFfAvAOWnLQTeHnG(-945198.2877946221, string("SEcDGRZOBjEwJGGOpdSZPvdDmZvVscKULwEdxgeBKitaMSIrjjwVRIyMajhNdGQTPjyZjlzjDtIpyRZwmgfJZjZWdWxwryGVbipTTUPgxzTsTVSVEbXzOAOCrbjwcYjNfr"), 481738.0599620927);
    this->nNmIvMgs(string("FlWjfiVRPXwRlpgvGaANyyhWnfveUVXvTnqEhKoQLJEWMFybbdXgYpQvrBtNfwiGFxosYzQNEQQQnIwbJdrYCPhgGylkcYcmUgtoYjHjFoXlGcqnXzrGnrDOnyUCsSFQxOynJEcrnLPNDTiRUVQOnKMYMYRwfoiyQEpUfQjfyRPKJzDOfTzyrakwPqdyeBsRbsziPSrSAtqerEGbXXwuho"), -885690663, 1149894143);
    this->GKCmIdEw(-991925.9777432963, string("aoLtIrARLZheHTXRYtbfRmaPsBZXcSdcekIFfuoPZEULujYOOYfipTWhUdEOyeMl"), string("iHaLVxWaNGKRDQMAdUlMJsYomCmPpFybnoEGhgUOMxYmqjcRTWdloWLMJQQlpryboYhUSkljKdhiVFfBJpXXeSveWrAbUlWwaQAPji"), 819092.2189176315);
    this->ZssuBSQJ(-774692149, string("YeFKyPjdqEMzXjVLd"), string("MXBSJZuHwnNJTJGjmXKJZMQIhABmpDvTEzidGfMWVULzzagyKShgybZFILtNywLOVagvvonDhraZGbEBjGliINCPDEYzTMoqZINPvpBIISUoNnHlkeDYzGTHc"), false);
    this->QMXqQGJjWbjmnuc(string("VJHPWyTCzxlMXecSyHaKGkkzxHrGZbfNgfJvrqixeTetMWWQbfLHlkGKmnYZFinISItHtUxQOKONOmbQknPdIGXCcSphpArLJKOabHCqUdrKrvhykMvsVqjMezGKNZVWxBRrRNUWVjSMsgjdegfHubkEePOlEeccblOIoDfphIanoTumKzRUWKwEFsLtUTVF"), false, false, 1258474936, string("GWFqFYUwASDqhnCTdNlKZraycukukyTMLkBWlcSYBCgCxAaQbjwTxFhdLwEysSmKAXijCqAdiFAffIofUSFSNEQSm"));
    this->EBNYwMvyPJKoKBGO(true, string("YUYFNDtaZhPkhcJFwSoqLMGFBCPcFZYZqVDyGfywgvwmycKAwmSgxOzFeuBbhqwjeShCKThNJPxCneoyBGNMXAJaisxMpnjdwvRbKCjNUbEmlwNYVPoCJTwEcTSkjBOhcxhlgavAHIevrfBYKssxNFsdDsOORBjmPsLhsEKzIriTVRUVwMBPFccJtzJAc"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RveuWCLYgXzL
{
public:
    bool eQgkEhyreTzVV;
    bool xGMMdDzou;

    RveuWCLYgXzL();
    void PDCmnlKVoruU(double HuFzV, string dDgIeDwcaqAjEQr, double QHALyB, double IZWaNGGzZj, double HzNnbzqmhFjpdSwG);
    int bzthhwwKywDBZ(int NdxeGmFlPu, string DMruXcx, double nclqkUiSQ);
    string pjiyj(int gbMZCNBRW, string eexUSlCLdj, int GxEpAoWBOzXBHFx, string umVNls);
    string mDKqcghMB(double jIRNdX, bool Hkajpjioni, double AiVaUnXi, int MZzuwkDVXb);
    int LFoRKIlBgOA(string hsfgu, int hOVhAi);
protected:
    string dwMTeE;
    bool okvAhgggW;
    double nVoVOiNc;
    int yPDwzdVytLeFYic;
    double iktjQcAenc;
    int MRDLuiJDqhH;

    void srdhSriy(bool ggOWnXX);
    string CnbqDy(string BZiavodlIUZdX);
    string MihqfFBGVxrm(string qUtKhzXu, bool fGIvMRxz, bool KEPySAHccDNlw, double WDwMNe);
    string Axmqvr(double LLzcqAeMwXNSPosb, int qhtAZZiNInmuXQGX);
private:
    double GeUPCYL;
    double yBtVQTPSZ;
    string GpIkNbFQa;
    string LVPKhbKkUDq;

    string bWAAejURxLWMu(bool PRLGBC, bool OEHHhvMWWEKuPTqg, string BpBMeBJrxeDxz, double VWfBLwjqAYWCbR);
    double wibDmO();
    int ZqAuVllIIiDk(int eLMREzO, string FaUye, int YqETWW);
    bool lZaIw(bool mEOpQYrnu);
    int FTIUWU(string GkPHSNlkC, bool svlpCBzicdpwZ, bool LcNOVJcbGtnojW, string PTZZncrUCSdPiC);
    string yKcGuGtUijNcf(double brGvWYoAJPYRb, int EMHlfuo, bool pnGgeratIXaupT);
};

void RveuWCLYgXzL::PDCmnlKVoruU(double HuFzV, string dDgIeDwcaqAjEQr, double QHALyB, double IZWaNGGzZj, double HzNnbzqmhFjpdSwG)
{
    bool fcdHnDXdhdenv = false;
    string oHVfXsrqFKdjQ = string("KdSpTptEpPiRXIeJHiIErQdwFQnuhJFlEhijOMhvcVJpR");
    int lvVzXXgxiLsajc = 1527076311;
    bool YOYQlerBrNOO = true;
    string Cutiv = string("REnOAKMwwjIBuNNcKviqSKSHTyKNbIXdAdlrMYwIeyNduZIaQrjDaRqocUUUaWRzDWefiUaJnhPQMVamHS");
    bool QVNZoNfaRG = false;
}

int RveuWCLYgXzL::bzthhwwKywDBZ(int NdxeGmFlPu, string DMruXcx, double nclqkUiSQ)
{
    int OhBWI = 1543966779;
    double krwVUGzQ = -660809.4365726125;
    bool pzGzrrjCTGC = false;
    bool tYleS = false;
    double ESfwPsxDrTuOB = 1016466.714813484;
    string QaHavNXCuwldDF = string("yWAGSklidGtaeOiaJaYEVFKTwMEVOVOQGNlIRZKAVUKOTdVmWVsdHyRiIwnCDcJ");
    string AViRQz = string("IHmGyqLyOUawNJxiDcRbvnIQkcZBqrDqTvxXlDOJpXXUHtAqmTTkqSRIjuRviUDzNXDKHMlAHfKpOglHACiDjfKJGdIXBLvhLxnIjmZbRvqQhnhREPVKRcpwJVfkzuxRdkOrKCKkEFmlpjDTqPjqCzqrfPTovpadugccmMzIBxvxMNiQKXvIOCQnzBAzGqENkUgEKvQzfavtUBbwUMdmmAwBMudjgxxJGaqmPymrRIFICBnREjJk");
    bool OIKFmciEgY = true;
    string bofbjvL = string("HohyOSnppEXRrGgfaqpPFAbIWcvKmljCQQpCertOjegGKVQJJo");
    int czgMSOdiU = 774272316;

    for (int iYLDRLtKEbTbd = 1658555308; iYLDRLtKEbTbd > 0; iYLDRLtKEbTbd--) {
        continue;
    }

    if (NdxeGmFlPu < -555601057) {
        for (int DjFkJvtMQjPnsjvX = 7695870; DjFkJvtMQjPnsjvX > 0; DjFkJvtMQjPnsjvX--) {
            continue;
        }
    }

    if (czgMSOdiU == 1543966779) {
        for (int pMbjeJRzIMcEG = 733254736; pMbjeJRzIMcEG > 0; pMbjeJRzIMcEG--) {
            OIKFmciEgY = ! tYleS;
        }
    }

    for (int pTsRNws = 1777155040; pTsRNws > 0; pTsRNws--) {
        continue;
    }

    for (int LbriUb = 1211337441; LbriUb > 0; LbriUb--) {
        continue;
    }

    return czgMSOdiU;
}

string RveuWCLYgXzL::pjiyj(int gbMZCNBRW, string eexUSlCLdj, int GxEpAoWBOzXBHFx, string umVNls)
{
    double uesSIgNA = 359675.44727373007;
    bool uFfwEcJaZDVUali = true;
    bool BnJpaBJe = false;
    int StHabCTyOBHzav = 2058643380;
    int ewGjmm = -772374612;
    string irCtQdD = string("cYgudGXJlSMlarIueNqiQnbZailYiIAAlnrIJuVoUxnbjxxHwaOeyDusWqODIYEXBiKWfovZENHoezQrzzjrFPraeoRTgsOoRnwPdBqnNjaWUzdMkBVuLiTkPwkJFBWdaFOqyzwmXXEItZFhrEseaWXEoClQeUzoCHqvmVlJXFkwGZqinCT");
    bool VZqYFyNrEiYfJtVY = true;

    for (int pabpNufqCrYuEb = 1451977457; pabpNufqCrYuEb > 0; pabpNufqCrYuEb--) {
        StHabCTyOBHzav = ewGjmm;
        gbMZCNBRW *= ewGjmm;
    }

    for (int yPEHTFi = 52977686; yPEHTFi > 0; yPEHTFi--) {
        uesSIgNA *= uesSIgNA;
    }

    for (int JCRvAjQaBNRQVWLI = 1916679176; JCRvAjQaBNRQVWLI > 0; JCRvAjQaBNRQVWLI--) {
        VZqYFyNrEiYfJtVY = BnJpaBJe;
        irCtQdD += irCtQdD;
    }

    if (uFfwEcJaZDVUali == true) {
        for (int oApUhwKAljJRXrE = 754099940; oApUhwKAljJRXrE > 0; oApUhwKAljJRXrE--) {
            StHabCTyOBHzav /= gbMZCNBRW;
        }
    }

    for (int wlzCwjH = 1495229245; wlzCwjH > 0; wlzCwjH--) {
        GxEpAoWBOzXBHFx *= ewGjmm;
        uFfwEcJaZDVUali = ! BnJpaBJe;
        uFfwEcJaZDVUali = uFfwEcJaZDVUali;
        ewGjmm = GxEpAoWBOzXBHFx;
    }

    return irCtQdD;
}

string RveuWCLYgXzL::mDKqcghMB(double jIRNdX, bool Hkajpjioni, double AiVaUnXi, int MZzuwkDVXb)
{
    bool GYKxtl = false;
    int dXabmfpyUh = -1392620990;
    string haTCooN = string("GmOPsRjKjDv");
    string HDhfmZInU = string("NspaCdOXdRfWlnXOsLOenIKOLmgpLUqGkDybhAOOYcaVBBpaOscAplwVhmfdSBvPAKynGXFONytVmqZybZkYimOZIFdtnNJbRvgWaGhJGIOOChjSgNChHnOIlIKgbxvdLEWJVsxgxMOzGXNUJd");

    if (haTCooN <= string("NspaCdOXdRfWlnXOsLOenIKOLmgpLUqGkDybhAOOYcaVBBpaOscAplwVhmfdSBvPAKynGXFONytVmqZybZkYimOZIFdtnNJbRvgWaGhJGIOOChjSgNChHnOIlIKgbxvdLEWJVsxgxMOzGXNUJd")) {
        for (int DFSZolduZ = 1327869780; DFSZolduZ > 0; DFSZolduZ--) {
            haTCooN += HDhfmZInU;
        }
    }

    if (HDhfmZInU == string("NspaCdOXdRfWlnXOsLOenIKOLmgpLUqGkDybhAOOYcaVBBpaOscAplwVhmfdSBvPAKynGXFONytVmqZybZkYimOZIFdtnNJbRvgWaGhJGIOOChjSgNChHnOIlIKgbxvdLEWJVsxgxMOzGXNUJd")) {
        for (int OFdcttSsWjCalZGR = 1818276463; OFdcttSsWjCalZGR > 0; OFdcttSsWjCalZGR--) {
            continue;
        }
    }

    return HDhfmZInU;
}

int RveuWCLYgXzL::LFoRKIlBgOA(string hsfgu, int hOVhAi)
{
    bool etuXnLUCfZuYX = false;
    int uvOWAGDGJRgw = -1856034899;
    bool cvOLxthW = true;

    for (int EgffbuBd = 223997631; EgffbuBd > 0; EgffbuBd--) {
        continue;
    }

    if (hOVhAi > -1856034899) {
        for (int wPaudlfxjWxzZDY = 839606006; wPaudlfxjWxzZDY > 0; wPaudlfxjWxzZDY--) {
            continue;
        }
    }

    return uvOWAGDGJRgw;
}

void RveuWCLYgXzL::srdhSriy(bool ggOWnXX)
{
    double tQueNwKTj = 67492.64001975524;
    bool HiafphvumqLajp = true;

    if (HiafphvumqLajp != false) {
        for (int iyPLNMw = 360715300; iyPLNMw > 0; iyPLNMw--) {
            tQueNwKTj *= tQueNwKTj;
            HiafphvumqLajp = ! ggOWnXX;
            tQueNwKTj = tQueNwKTj;
        }
    }

    if (ggOWnXX != true) {
        for (int voOXrwTCfJlvA = 280608695; voOXrwTCfJlvA > 0; voOXrwTCfJlvA--) {
            HiafphvumqLajp = HiafphvumqLajp;
            ggOWnXX = ggOWnXX;
            tQueNwKTj /= tQueNwKTj;
            HiafphvumqLajp = ! HiafphvumqLajp;
            HiafphvumqLajp = HiafphvumqLajp;
        }
    }

    if (ggOWnXX == false) {
        for (int LFdlqFulR = 423869658; LFdlqFulR > 0; LFdlqFulR--) {
            HiafphvumqLajp = ! HiafphvumqLajp;
        }
    }
}

string RveuWCLYgXzL::CnbqDy(string BZiavodlIUZdX)
{
    double QpshJbkCvJiykg = -935966.3348452597;

    if (BZiavodlIUZdX >= string("gkDyBawqNNbMftwaOqUZXzqEBncYHRNADuRIRdUlitGwcwSWJZQGdAQrkTSZlltuwORqZDxZJdduwecKaGalEpDTrKAdVWEMqdkultsnQxRQsICoZIgTWIsBJAsPxXrJEKUNuXInVZtwpWjb")) {
        for (int SXBHG = 23935273; SXBHG > 0; SXBHG--) {
            BZiavodlIUZdX += BZiavodlIUZdX;
            BZiavodlIUZdX += BZiavodlIUZdX;
        }
    }

    for (int PxMWamRLqKtxv = 238401369; PxMWamRLqKtxv > 0; PxMWamRLqKtxv--) {
        BZiavodlIUZdX += BZiavodlIUZdX;
        QpshJbkCvJiykg += QpshJbkCvJiykg;
        QpshJbkCvJiykg -= QpshJbkCvJiykg;
        QpshJbkCvJiykg = QpshJbkCvJiykg;
    }

    if (QpshJbkCvJiykg != -935966.3348452597) {
        for (int bsFZCPwMsS = 2147300525; bsFZCPwMsS > 0; bsFZCPwMsS--) {
            QpshJbkCvJiykg += QpshJbkCvJiykg;
        }
    }

    for (int DMVHsKpvigFNIe = 2060405107; DMVHsKpvigFNIe > 0; DMVHsKpvigFNIe--) {
        continue;
    }

    if (QpshJbkCvJiykg != -935966.3348452597) {
        for (int nIviv = 570030570; nIviv > 0; nIviv--) {
            continue;
        }
    }

    return BZiavodlIUZdX;
}

string RveuWCLYgXzL::MihqfFBGVxrm(string qUtKhzXu, bool fGIvMRxz, bool KEPySAHccDNlw, double WDwMNe)
{
    double hSlDsYiDRb = -42879.87242614628;
    bool krBAa = false;
    double bkeikTnZtcU = -415080.43447531556;
    string HjBLqk = string("wFtYhLQrZzDjyLfRyzarVuglYNqEUThNgZQxfKOcBzBroGcyYKcxPCfhZreTUJvuGRtdFtYaeJlQrouqBDhxGLZDQCOhAFzIaQLMEynRcOZOUDWZgsAvYPtDPnllHPNLiBVJdNuzTyYVlfddHz");
    string uTMavnnwskLmkh = string("LWvAfjRWvAnKwQoUiModxZukmEdIyoBwibvGo");
    bool OYCDfamD = false;
    string lKAuwEHsqz = string("JbFyfTcGCPxMxRfpYlWHQfQTiKMFqThQRmitVCVSdkmVRKkioPhuRQnQwxAthEkQlAjlqhjnONzQTuuICLAiBptoPNKBQOgXkrGYgkxCcBCsobgRuxUcjwfrlVhdfPTvszJZtgdERRixMnuVVoNuhnAvafsTyYwZjAlWQyiMSHIKkHlHk");
    int CoCsmDheFfrla = 869878986;
    bool ZmGMMLqwihEttX = false;

    for (int YBPyvFAt = 732467068; YBPyvFAt > 0; YBPyvFAt--) {
        KEPySAHccDNlw = ! krBAa;
    }

    for (int PQFMYiS = 1591409890; PQFMYiS > 0; PQFMYiS--) {
        continue;
    }

    for (int THEKGQALNOIc = 414664402; THEKGQALNOIc > 0; THEKGQALNOIc--) {
        KEPySAHccDNlw = ! OYCDfamD;
        uTMavnnwskLmkh += uTMavnnwskLmkh;
        hSlDsYiDRb = WDwMNe;
    }

    for (int GEnQTzVhlFSVtqpN = 1108623013; GEnQTzVhlFSVtqpN > 0; GEnQTzVhlFSVtqpN--) {
        krBAa = OYCDfamD;
        WDwMNe = bkeikTnZtcU;
    }

    return lKAuwEHsqz;
}

string RveuWCLYgXzL::Axmqvr(double LLzcqAeMwXNSPosb, int qhtAZZiNInmuXQGX)
{
    int cIbKmOAqfsc = -610504789;

    if (qhtAZZiNInmuXQGX == 1168062623) {
        for (int wdaqeJbu = 147455555; wdaqeJbu > 0; wdaqeJbu--) {
            qhtAZZiNInmuXQGX /= qhtAZZiNInmuXQGX;
            cIbKmOAqfsc += cIbKmOAqfsc;
        }
    }

    return string("qBpfWDruyMwpqRHUjrPDcjHVCSXIqzQlfFFgWOPCJDpRctapKAyQQIKBMrtPhciCsJfWiFwhjhCGVSrVSttbmgboAdQdaBEFrNiPzoJmnkFIafYpGXIGMxZgfZYUTTjmYwYUjjUCYwHgLtKJizcwmOMNWQjajDjtOPWlfCDHHQNU");
}

string RveuWCLYgXzL::bWAAejURxLWMu(bool PRLGBC, bool OEHHhvMWWEKuPTqg, string BpBMeBJrxeDxz, double VWfBLwjqAYWCbR)
{
    int fiHQhLE = -482573562;
    double MLGBzVfVK = 222068.88206585278;
    int tcqezFUssva = 1575127078;
    bool uZHbvkdLF = true;
    double OZSNBaqwapHm = 380119.15543289046;
    int KzXvxAGT = 591696494;
    int nDmaaXtRm = -1522831100;
    double tGfZbzwNd = -107650.52579067077;

    for (int mLcHGWcKXrM = 2140591271; mLcHGWcKXrM > 0; mLcHGWcKXrM--) {
        continue;
    }

    if (tcqezFUssva > -482573562) {
        for (int sJabNkMTxeWxDgnt = 449074607; sJabNkMTxeWxDgnt > 0; sJabNkMTxeWxDgnt--) {
            tcqezFUssva -= tcqezFUssva;
        }
    }

    if (uZHbvkdLF != true) {
        for (int RdbStaPdZBhedmd = 1439439134; RdbStaPdZBhedmd > 0; RdbStaPdZBhedmd--) {
            MLGBzVfVK /= tGfZbzwNd;
            tcqezFUssva += fiHQhLE;
            KzXvxAGT = KzXvxAGT;
        }
    }

    return BpBMeBJrxeDxz;
}

double RveuWCLYgXzL::wibDmO()
{
    bool jQFpACDP = true;
    string AIcEAWNc = string("HLzbLlvbPIQXDWOpWBtOClJmGvtpPBujvFDWHxvhmodnteolOyrihuRlHpOruIEwwHYjWCdgRaqhhLTWxchrgyVvkVG");
    string yCbdIHwgKC = string("TnXltXSwXYkLzDKEDdoYgzNHKCmjnzbwbjGVYYzactJKOsrDFncaIorsRmxgFwfeCrniqIqswiZnurYAfWPTNMyTMrZQpTCAaqbGPTCCgswazFmxeGQrwpphjLETTenmEnH");
    int oDMwbDBKCaNOXY = -752243076;
    int IvNwpLgFeqErT = 1358107723;
    int wGBqEQVmnWkrlW = 1545989526;

    for (int oJxueAdRLHhawU = 1145807678; oJxueAdRLHhawU > 0; oJxueAdRLHhawU--) {
        IvNwpLgFeqErT += IvNwpLgFeqErT;
        IvNwpLgFeqErT /= IvNwpLgFeqErT;
        oDMwbDBKCaNOXY = wGBqEQVmnWkrlW;
        IvNwpLgFeqErT /= wGBqEQVmnWkrlW;
        wGBqEQVmnWkrlW *= oDMwbDBKCaNOXY;
    }

    if (IvNwpLgFeqErT <= 1545989526) {
        for (int XAxNawZghuY = 1204495157; XAxNawZghuY > 0; XAxNawZghuY--) {
            yCbdIHwgKC += yCbdIHwgKC;
            AIcEAWNc += yCbdIHwgKC;
            yCbdIHwgKC = yCbdIHwgKC;
            IvNwpLgFeqErT *= oDMwbDBKCaNOXY;
        }
    }

    for (int YkQtsIyAINseLqx = 2087118445; YkQtsIyAINseLqx > 0; YkQtsIyAINseLqx--) {
        yCbdIHwgKC += AIcEAWNc;
    }

    for (int jKBjaRlmleVU = 1477043878; jKBjaRlmleVU > 0; jKBjaRlmleVU--) {
        continue;
    }

    return 440003.26520900696;
}

int RveuWCLYgXzL::ZqAuVllIIiDk(int eLMREzO, string FaUye, int YqETWW)
{
    double lyuaMSYowuFKJWGm = -849024.707522737;

    for (int rObzQddWgIBOJe = 1100458053; rObzQddWgIBOJe > 0; rObzQddWgIBOJe--) {
        YqETWW -= eLMREzO;
    }

    if (YqETWW > 1408775701) {
        for (int EirXilDE = 2049611517; EirXilDE > 0; EirXilDE--) {
            FaUye += FaUye;
            eLMREzO /= YqETWW;
            lyuaMSYowuFKJWGm /= lyuaMSYowuFKJWGm;
        }
    }

    for (int gdaZCmmMTf = 214206286; gdaZCmmMTf > 0; gdaZCmmMTf--) {
        lyuaMSYowuFKJWGm -= lyuaMSYowuFKJWGm;
    }

    for (int qzOXfR = 1465676707; qzOXfR > 0; qzOXfR--) {
        lyuaMSYowuFKJWGm *= lyuaMSYowuFKJWGm;
        eLMREzO = eLMREzO;
        YqETWW -= eLMREzO;
    }

    return YqETWW;
}

bool RveuWCLYgXzL::lZaIw(bool mEOpQYrnu)
{
    int uQjLclyKeP = 1818403921;
    double RphFRVWL = 638124.2053172555;
    string kKRax = string("pzhIzNFrDOyrQWVmgDbsFYvLOFkBPwgSfSbyxrXFmRKUcUbgUtyHzPdbbjKtjpBRhdsQRDoeFnnQRSIdaFBobrzjAMeYvodJXGRvDTPPxwIvmyJKQSBottmWwCrPZJfNj");
    int ZieLRWz = -362959449;
    double xZYuwRJJrAoEVzk = 70113.58306601288;
    string JFNkXApO = string("zSvgeYJWjwQJypDAMovPJKuZvJWALjuOdDpRHagWfesjEvaWdlvzJKSXLqbSBABMVWRQGYcdeYOWTpILxmBmeOHMETwbTECYaipqtyBSBDBqXWUmyLfROCN");
    int SHXmtbennHpoJ = 1433194684;

    for (int EpzvdB = 1812770924; EpzvdB > 0; EpzvdB--) {
        continue;
    }

    for (int KMsDFI = 353828803; KMsDFI > 0; KMsDFI--) {
        kKRax = kKRax;
        kKRax += kKRax;
    }

    for (int vCGLpaMRE = 486167309; vCGLpaMRE > 0; vCGLpaMRE--) {
        SHXmtbennHpoJ = ZieLRWz;
        RphFRVWL += xZYuwRJJrAoEVzk;
        ZieLRWz /= SHXmtbennHpoJ;
        SHXmtbennHpoJ = SHXmtbennHpoJ;
    }

    for (int wrumZ = 1294039036; wrumZ > 0; wrumZ--) {
        continue;
    }

    return mEOpQYrnu;
}

int RveuWCLYgXzL::FTIUWU(string GkPHSNlkC, bool svlpCBzicdpwZ, bool LcNOVJcbGtnojW, string PTZZncrUCSdPiC)
{
    double sDIXitQRUZh = 532612.5146720689;
    int SHrNnFXJfoen = 443248585;
    double DCZDApoVzKfaCObt = 79167.50223081795;
    string CXZQB = string("QQvoDEFlyGeKGiPjFBabtdnHyayexCLBJNJsXRiSwUEPTpAomoGhYgKwvRSmYxdzuflnsIzNRaeDvyVCtHmnMkgoeCbBSXkTXRGiRcuenyyymAUJdsToKukXfPpvscrCdjJTFLNOTNPRScj");
    bool MAUgxEoIBSPWoYW = true;
    bool bZTpi = true;
    double netKrvtGhjo = 901674.1482708467;

    for (int pRbswFbLbvCBJRS = 590767918; pRbswFbLbvCBJRS > 0; pRbswFbLbvCBJRS--) {
        DCZDApoVzKfaCObt = sDIXitQRUZh;
    }

    for (int JawHEz = 1382190750; JawHEz > 0; JawHEz--) {
        DCZDApoVzKfaCObt *= netKrvtGhjo;
    }

    for (int oZDyPrlzuoIdCX = 1337990501; oZDyPrlzuoIdCX > 0; oZDyPrlzuoIdCX--) {
        LcNOVJcbGtnojW = LcNOVJcbGtnojW;
        GkPHSNlkC = PTZZncrUCSdPiC;
        LcNOVJcbGtnojW = svlpCBzicdpwZ;
        svlpCBzicdpwZ = ! bZTpi;
    }

    if (PTZZncrUCSdPiC <= string("QQvoDEFlyGeKGiPjFBabtdnHyayexCLBJNJsXRiSwUEPTpAomoGhYgKwvRSmYxdzuflnsIzNRaeDvyVCtHmnMkgoeCbBSXkTXRGiRcuenyyymAUJdsToKukXfPpvscrCdjJTFLNOTNPRScj")) {
        for (int iTZcveOwym = 770638390; iTZcveOwym > 0; iTZcveOwym--) {
            GkPHSNlkC = CXZQB;
            PTZZncrUCSdPiC += GkPHSNlkC;
            bZTpi = svlpCBzicdpwZ;
        }
    }

    return SHrNnFXJfoen;
}

string RveuWCLYgXzL::yKcGuGtUijNcf(double brGvWYoAJPYRb, int EMHlfuo, bool pnGgeratIXaupT)
{
    double yGNBSydXO = 500967.77565082815;
    int pvXRfSiZcTiTxEI = -357276921;
    double FYUtjmKSkXZYBrnu = 746098.5225762734;

    if (FYUtjmKSkXZYBrnu != 162394.21458119017) {
        for (int GLAJFzQ = 1973867739; GLAJFzQ > 0; GLAJFzQ--) {
            FYUtjmKSkXZYBrnu /= FYUtjmKSkXZYBrnu;
            EMHlfuo -= pvXRfSiZcTiTxEI;
            pvXRfSiZcTiTxEI -= pvXRfSiZcTiTxEI;
        }
    }

    for (int GJqthrQ = 1992023510; GJqthrQ > 0; GJqthrQ--) {
        yGNBSydXO -= brGvWYoAJPYRb;
    }

    if (pvXRfSiZcTiTxEI <= -357276921) {
        for (int FcsBbOLQScvmmHC = 2048286289; FcsBbOLQScvmmHC > 0; FcsBbOLQScvmmHC--) {
            yGNBSydXO *= yGNBSydXO;
        }
    }

    if (FYUtjmKSkXZYBrnu >= 162394.21458119017) {
        for (int mGVBlQfqk = 553307161; mGVBlQfqk > 0; mGVBlQfqk--) {
            pnGgeratIXaupT = ! pnGgeratIXaupT;
        }
    }

    return string("CFwcmTnuPTgPhnfMlcUeEpqucHjmushdonUDxAopYwSGwaeTOoxveShnVDAJrvgQmSEUejBbKAlRozpHGxVaOYLsuPqozJQiyfmvOMdLilJoQKTNfvFMJVFEZCBLkCUxnsxWPkNgiapTmIFpjXGJjlMsYFFcwwiebsZCIyuhhlIdfVnRVDtXBBkexoLRYijiuDsUHTzSXClDIOiNWloAThPCkRewmrUBxuEKdqUY");
}

RveuWCLYgXzL::RveuWCLYgXzL()
{
    this->PDCmnlKVoruU(511124.3025802055, string("YTlUoNSQuYudruxxZxsRGeEUzzFTLhZBjlEXKeiIhFMIGKoEkOWUpriLJmbbKGvYhZlAroPEMfEtWiTUmOgoGkwcmtYEyxVMmVgDggoIqGaTvQdaUmyCrFfGEcKmAhAifihKIhewzNbPTnUsCKreWtnKYhqngwXDEJTfdPXagJwdNvqymdgutxaH"), 845210.6963066434, 283218.6174115058, -926792.1918138324);
    this->bzthhwwKywDBZ(-555601057, string("LMpzVPvwRTcTglAazCpmLkBrJmvKbdgHzHRaisTgZnnSJlWcRaMfjrgW"), -803501.6536702067);
    this->pjiyj(-429208583, string("pyXrPGytYJPrfelxKDCJ"), 987919387, string("WjuNyLxccYDWykTcwuZUdRnsHqZYDMJTRygnroqpLtpGGrbxsatGkTydjJJCFKzTpRFqJqaNzuFztPRPkYZwLMKetHuhwZXWPkmlvgxkXPOaiJrrxltMvQPhWuLnRLKahsKjZxhBgQUJuUMCVLTrdcYNFWIxDTWMrLrEJIqeemRWMkyJAFFbStYdjCLZwCxJnJWMujNoBtmyqXLBzjoUTDvxPAXlO"));
    this->mDKqcghMB(-458386.5948609646, false, -882035.6739438642, 1606562850);
    this->LFoRKIlBgOA(string("qqiKACwcDJEWOcpZhGotdNSkipKAIgUSoPMdexSNpeclWYCtAQOdpUQUMrwgIAtDHsUCqruRIezXesMRiomulp"), 1186736170);
    this->srdhSriy(false);
    this->CnbqDy(string("gkDyBawqNNbMftwaOqUZXzqEBncYHRNADuRIRdUlitGwcwSWJZQGdAQrkTSZlltuwORqZDxZJdduwecKaGalEpDTrKAdVWEMqdkultsnQxRQsICoZIgTWIsBJAsPxXrJEKUNuXInVZtwpWjb"));
    this->MihqfFBGVxrm(string("awGrWiPdQlgtnmMjVfiuGhkieUDrYUfMfXeIvkVdrexYvRZiAWlGbXhDAWlLbBfFxQAPExZVlVPNpAIyiRRfbqcUgHiWNLSAykGDSlQWaJUDBkJqeqMOWYwamAWVLAfEatOArPhtelbyoOANzgTkhmCFIsKmUwIfKJhQxnPNjakBlPljWzxFTnFVOJWNBjJTFEGibzUpcKUEmmJvEG"), false, true, 707979.2721218037);
    this->Axmqvr(-334614.8550126815, 1168062623);
    this->bWAAejURxLWMu(true, true, string("efEoPgPOtEjbbVCUqACQdgGQHENlxzhhpHAFHYoJFJJRgdqyGzXTIVGdsBrTZjWdZKolRWCSnvYfnTseIsKFIVnqkcbTWPOPqAV"), -80841.25387892251);
    this->wibDmO();
    this->ZqAuVllIIiDk(1408775701, string("ICKjtxHKYRqeKPrSBStHzCJSqtqDUCryoShKgNtotBTxBiffTOBQdcxtGyHZpJhWugZzxRAwQoKUEdNDTglIDFWuhPOyCrjahWVbbGDAriNKQvuUyYFRfRNwsxWOTunZnUpBVGPrBEq"), 2127312018);
    this->lZaIw(false);
    this->FTIUWU(string("OScaCDvhqbMfsklQjuVtGYHqvfInIbfnulpRvqbmByFiZuRwxVbFWqXYnlFBrTKYGJTaxNtxdCehTDHosgiNGnvZlBAfkCoHGmVgspkcpbNJGfDVWlvPjrxSqNQLDaLCdJLt"), false, true, string("nUCmQNuxOMhyXfOyGZwJwdvgqmTFPLcVCfkxfiBjqweRzrcXTKGjnWBDlhWlKUZWYAgfWWoYVdKJnADKardUUoOGhFxwPrRXgAITPjzUKRvyQuaTpqdHnYTiZhoPWHJoRIiNJkdbgdzicXwDoUdzJoyYgCaVpveLUbGRduWIxXaecEjkmLxrXZyhVJphFuoYBptojnFzxqmPlxxjGhYxbzaZKQoWTFGMirtJwpDyiVvMzMfBSsai"));
    this->yKcGuGtUijNcf(162394.21458119017, -1725843607, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tkcHjOzqvge
{
public:
    double TuWmDOReSOU;
    string cJKmpa;
    string XaqkXTLdWz;
    int lLOPzFjLzsqWQpO;
    int fECLpABpKz;

    tkcHjOzqvge();
    double BFhELhPVKte(string vusCxVEr);
    string hwKQrP(double MECtOEsFmTsxn, bool jBrAQ, double wIULxYzymuBJTrV, double onxfgJI, double kiltaZsMDhPjtub);
    bool jXuzMtMrGuqRJS(double hzcGEc, string BUunJYuHLO, double TcplaB, int XiTYxLnrdUUREO);
    void LuICiS(bool DyEVSw);
    void UsLfjMGO(double apIqYXc, string dmCIMxkZGncxgXp);
    string YCNqSEElLOlsdjkA();
protected:
    bool oYCdl;

    bool TZhnWNVen(int vEQTcnmr);
    double sSguVnoS(bool ZINLcF);
    int TSeUTcusjmOJYyy(double WraiDau, int kqbrLgucu);
    int gKOqTHS();
    string ZQfpitEj(int dOIXssptsMcN);
    int PFdZVLJrCeU(double psHJA, int oZiqXDyXQbXCKGjJ, bool JtNzuStSqBvqxFYY, string SvjGFyKq, int rlidTZDf);
private:
    int qIHEfibrb;

    string GTpyEYU(bool htint, int RMZqmJpKIZXEP, bool qdNqsthRZIkfRN, bool yuEwELftFwK);
    bool lihiyktWhzlRJCrj(double pVhMKgQeIe, string yLWIUFCpwmuQfs, string kwVcFHvBY);
    void BEOEWfLz(double OqAwzsRgAJx);
    void odAfdyL(bool gQxbIhrgYQc, bool QGKUi, int UbwSsdbeaBrgFMr, int ywWBIaFkrDwfrf);
    void uItevKpKfzZj();
    double KRLTeCWDeRFDKbjm(string grESjsko);
    string iljqxhxgBXR(bool Rgmkzovp, string xNzdIiifw, string QGzrrUPSRt);
};

double tkcHjOzqvge::BFhELhPVKte(string vusCxVEr)
{
    double DSuMnsmHl = 186234.06153001645;
    string IfpvbAyNSMdf = string("pEvFOHTNqbfvbWXPgmMngOkVIBXzyxGIxvRJaOuBbrESqV");
    double tHiTKMbdrSsOjJAE = 160914.1129350598;
    string VUNJSUTkgJ = string("xUHLvjGpvPeCtOfDCwtrzwBlOYZGNJPYwsUBYoLvbIWWaTTywmiZLHNuzXNsUkeldueSFrWhLFYOAoqDLAtUjqWYHSDMamvtKpCpblqfd");
    bool WNJcctJjrePGprG = false;
    int ZREfd = -1058197688;
    string UeDphjp = string("EGWlHbgnzAPeJPFxrGBsRFlAVcnBUlxnQPxoVsPZVHAczhbsiZuKptbSHxoSpqaQzWpcHBdILGudwyL");
    string JdoPQiUJDuxnxunf = string("jMPQoDQeryDapEVkrXLWpvsMRsWaAdSCoVJJxCtwUCMrTLluVirXQAVbAwnBVSxWTMeDXixecCwNjvOGmVYBSEwEWYozPrDcCqIDPoLaXFiQYFZNxxIDoEHLgkeMYdobqFKoTHWrmzyIhzJMdZckNdkMtDnYfLnnpCuKYdOHhQbMUnTq");
    int BZKrEshDTrQut = 315740975;
    double hWjklpuGQT = -233717.5075744856;

    for (int hmoSWHIlkHZRfRB = 104055378; hmoSWHIlkHZRfRB > 0; hmoSWHIlkHZRfRB--) {
        VUNJSUTkgJ = UeDphjp;
    }

    for (int zBgSoahFMuiXWt = 109107929; zBgSoahFMuiXWt > 0; zBgSoahFMuiXWt--) {
        IfpvbAyNSMdf = vusCxVEr;
        tHiTKMbdrSsOjJAE -= hWjklpuGQT;
    }

    return hWjklpuGQT;
}

string tkcHjOzqvge::hwKQrP(double MECtOEsFmTsxn, bool jBrAQ, double wIULxYzymuBJTrV, double onxfgJI, double kiltaZsMDhPjtub)
{
    double fpkQq = -980425.3108343292;
    bool uacypTFTSvdu = false;
    bool apHvzRHfz = true;
    string eMiuHQjIpN = string("GCDNTlOScbpxOSiexPUCuVZRrHPZKqZOfdBfGPRwdZXLuBYixbqnGUxrNQplqmpVTwpxfskpduLVdxMTpUWFuEiBGQzdIHjifLWirBojKmjSzeuiHEXRuWXxbuEVOykJXyPECHnjClGMuuMtjcTfRypfoLniawEcdZxyuvOSpMzmCFEgolPCdnQNjztyXyycQLPIvrXRPGiDMGfKJQzaoSLzrRfOlKmBWvGmB");
    double oRdxMF = -855229.2360889728;
    int NUAdwgqF = -1977113316;
    bool qmqiZo = true;

    if (wIULxYzymuBJTrV >= -635203.2765680731) {
        for (int AGrzOBMd = 1345532217; AGrzOBMd > 0; AGrzOBMd--) {
            jBrAQ = ! uacypTFTSvdu;
        }
    }

    return eMiuHQjIpN;
}

bool tkcHjOzqvge::jXuzMtMrGuqRJS(double hzcGEc, string BUunJYuHLO, double TcplaB, int XiTYxLnrdUUREO)
{
    double fXNnq = 725789.3297325813;
    double kbAqwHHMYVT = 332396.756764636;
    int pXZnfcoeo = -1825070924;
    int aavibjQgcQssO = 851611848;
    bool LAJJQ = true;
    bool CpYkKhtjGCBwmN = false;
    int MVALlGpSIWN = -1553319360;

    for (int vzdqGIlxXdfNNk = 1545562607; vzdqGIlxXdfNNk > 0; vzdqGIlxXdfNNk--) {
        continue;
    }

    return CpYkKhtjGCBwmN;
}

void tkcHjOzqvge::LuICiS(bool DyEVSw)
{
    bool QRXbozHauZG = false;
    string FaoQhMzEQRMdaHv = string("uVKQSvSXkJCqFwxwwAIUlCpnfwizsDmbElIsBjQgDVNONgwQBtVIbGrzKrbkkRNlHkOnqpSCUdLoyIgsLvjxVbeBZcMxbOGQeYHDoJpiUfpngDNqzDXukQXAQSvyyJnCuRlUBufTaVJTxSIkvzObddiJLVAtZBCzDOMdTdLgypZveybUjyBWeBITpkLaNkMzJaxlGRbXIGRvWjhLSznjJxHzJvWt");
    string XDsPEiU = string("EvoEfPodSOficNRJUcYSjjQhQXWztcXGDrwhupLldnyjiBOQhdrlsFHdnsUGUHEWMlEBYDjYxvxbgeqXUBbllwtPQpPddvoopeqGTQdHyBOJsCPBvkLpuekpILFiZbmWjgYisbgsrXjrQabNonfEujYLoMeMEzFCSAvhMaXhzwbGvadH");
    double cCCfN = 113437.56228284672;
    double AmUgURoFNvUtjr = 55627.840893815155;
    int llMgYPIbZ = 844828095;
    double xyFcIOgDhgpAstII = -294835.420601039;
}

void tkcHjOzqvge::UsLfjMGO(double apIqYXc, string dmCIMxkZGncxgXp)
{
    string lqcHcORWMaP = string("gDlYcbLXopOkULwQItzsVUiEIRZMVnQbhrtHQDvzYIsoTNRhmiHWizySmgERkXrlZiuUOLvw");
    int EEhti = 1495495956;
    double MpoATVmUao = -1046029.7947670731;

    if (dmCIMxkZGncxgXp > string("gDlYcbLXopOkULwQItzsVUiEIRZMVnQbhrtHQDvzYIsoTNRhmiHWizySmgERkXrlZiuUOLvw")) {
        for (int dpaQOnyIANVdllXj = 805185401; dpaQOnyIANVdllXj > 0; dpaQOnyIANVdllXj--) {
            EEhti -= EEhti;
        }
    }

    for (int QEiTtKPjxUidEH = 877824591; QEiTtKPjxUidEH > 0; QEiTtKPjxUidEH--) {
        apIqYXc -= apIqYXc;
    }

    if (EEhti < 1495495956) {
        for (int MJexVjkPTugj = 246071016; MJexVjkPTugj > 0; MJexVjkPTugj--) {
            lqcHcORWMaP = lqcHcORWMaP;
            lqcHcORWMaP += dmCIMxkZGncxgXp;
        }
    }

    for (int dNftkgn = 40150864; dNftkgn > 0; dNftkgn--) {
        dmCIMxkZGncxgXp += dmCIMxkZGncxgXp;
        MpoATVmUao *= apIqYXc;
        EEhti += EEhti;
    }

    if (dmCIMxkZGncxgXp >= string("gDlYcbLXopOkULwQItzsVUiEIRZMVnQbhrtHQDvzYIsoTNRhmiHWizySmgERkXrlZiuUOLvw")) {
        for (int RohFPLMmPaUxJkAa = 521338648; RohFPLMmPaUxJkAa > 0; RohFPLMmPaUxJkAa--) {
            MpoATVmUao *= MpoATVmUao;
        }
    }

    if (MpoATVmUao == 628695.5175414031) {
        for (int NCkjzwgEfSWRjW = 38186798; NCkjzwgEfSWRjW > 0; NCkjzwgEfSWRjW--) {
            EEhti -= EEhti;
            apIqYXc -= apIqYXc;
        }
    }
}

string tkcHjOzqvge::YCNqSEElLOlsdjkA()
{
    string DOqTkWzc = string("QpXCWACxLsxkfKJYXgDmKgaHEzFhKzSkxSOyVcPYeZoKkdafQqBvSmrHKEIlbacqjhWIBJLJwxTGhAENjsbaOuaDTuAhouwohiDCNAPuIzaARaKGwqFcLlsNYTWHHUQWFfMKAuWDsEIbCOiyQwLVTZJnTZtZqWWSHIxFgQFGG");
    int nOkmWsFvfgvhaoX = 936592510;
    double GceoZWuGAU = 280881.19426487567;

    for (int DPgaXKKtMZzWlxaY = 459437519; DPgaXKKtMZzWlxaY > 0; DPgaXKKtMZzWlxaY--) {
        GceoZWuGAU += GceoZWuGAU;
        DOqTkWzc = DOqTkWzc;
        DOqTkWzc += DOqTkWzc;
        DOqTkWzc = DOqTkWzc;
    }

    if (DOqTkWzc == string("QpXCWACxLsxkfKJYXgDmKgaHEzFhKzSkxSOyVcPYeZoKkdafQqBvSmrHKEIlbacqjhWIBJLJwxTGhAENjsbaOuaDTuAhouwohiDCNAPuIzaARaKGwqFcLlsNYTWHHUQWFfMKAuWDsEIbCOiyQwLVTZJnTZtZqWWSHIxFgQFGG")) {
        for (int DqZIQlh = 1020494094; DqZIQlh > 0; DqZIQlh--) {
            continue;
        }
    }

    if (DOqTkWzc <= string("QpXCWACxLsxkfKJYXgDmKgaHEzFhKzSkxSOyVcPYeZoKkdafQqBvSmrHKEIlbacqjhWIBJLJwxTGhAENjsbaOuaDTuAhouwohiDCNAPuIzaARaKGwqFcLlsNYTWHHUQWFfMKAuWDsEIbCOiyQwLVTZJnTZtZqWWSHIxFgQFGG")) {
        for (int WaisFhnmLjHcuwn = 33736608; WaisFhnmLjHcuwn > 0; WaisFhnmLjHcuwn--) {
            GceoZWuGAU = GceoZWuGAU;
            GceoZWuGAU -= GceoZWuGAU;
            nOkmWsFvfgvhaoX = nOkmWsFvfgvhaoX;
        }
    }

    for (int sHYYkKbU = 1111904970; sHYYkKbU > 0; sHYYkKbU--) {
        DOqTkWzc = DOqTkWzc;
    }

    for (int LeRLgmmJyfz = 1432622357; LeRLgmmJyfz > 0; LeRLgmmJyfz--) {
        nOkmWsFvfgvhaoX = nOkmWsFvfgvhaoX;
        nOkmWsFvfgvhaoX *= nOkmWsFvfgvhaoX;
    }

    return DOqTkWzc;
}

bool tkcHjOzqvge::TZhnWNVen(int vEQTcnmr)
{
    double AHvKVTUAkkXsd = 628177.3129658833;
    int tVLPOGlKtShZ = 1169500295;

    if (tVLPOGlKtShZ <= -775289348) {
        for (int pwdLHvAtpxzqHQz = 266064699; pwdLHvAtpxzqHQz > 0; pwdLHvAtpxzqHQz--) {
            AHvKVTUAkkXsd *= AHvKVTUAkkXsd;
            vEQTcnmr = vEQTcnmr;
            tVLPOGlKtShZ *= vEQTcnmr;
            tVLPOGlKtShZ += vEQTcnmr;
            vEQTcnmr = tVLPOGlKtShZ;
            AHvKVTUAkkXsd += AHvKVTUAkkXsd;
        }
    }

    for (int GtWcgqGyVGhEhfp = 439323167; GtWcgqGyVGhEhfp > 0; GtWcgqGyVGhEhfp--) {
        vEQTcnmr += vEQTcnmr;
        tVLPOGlKtShZ = vEQTcnmr;
        tVLPOGlKtShZ *= tVLPOGlKtShZ;
        AHvKVTUAkkXsd *= AHvKVTUAkkXsd;
        vEQTcnmr /= tVLPOGlKtShZ;
        tVLPOGlKtShZ = vEQTcnmr;
        tVLPOGlKtShZ = tVLPOGlKtShZ;
    }

    if (tVLPOGlKtShZ < -775289348) {
        for (int eicbjrr = 1108704899; eicbjrr > 0; eicbjrr--) {
            vEQTcnmr = vEQTcnmr;
        }
    }

    for (int MAYfgMaCFpzLb = 986755313; MAYfgMaCFpzLb > 0; MAYfgMaCFpzLb--) {
        vEQTcnmr -= tVLPOGlKtShZ;
        AHvKVTUAkkXsd += AHvKVTUAkkXsd;
        vEQTcnmr /= tVLPOGlKtShZ;
    }

    for (int DzPcDMxu = 1221995336; DzPcDMxu > 0; DzPcDMxu--) {
        vEQTcnmr -= tVLPOGlKtShZ;
        AHvKVTUAkkXsd = AHvKVTUAkkXsd;
        AHvKVTUAkkXsd = AHvKVTUAkkXsd;
        AHvKVTUAkkXsd *= AHvKVTUAkkXsd;
    }

    return false;
}

double tkcHjOzqvge::sSguVnoS(bool ZINLcF)
{
    bool AAoHKeslLS = false;
    double XvZlvwWVRPQYS = -227963.54808372105;
    bool umrryl = false;
    int QwvTgnnc = -1885757509;
    double RyhVz = 352619.4362185024;
    string QyITozKxhExdCy = string("ISLljHoPxsCRsRzkbLNLpIDKNizVhHuGWJVTEqKlDkPzrMgUrWZTChUrsgPNProxVggAxwfcMLwsMyMWhAjMzeJMJWsSZOukEsRVkcsPZNkWCmCBFRIyrYRKBQeLTrIjSkneVIZjZDTDSLQggguymIYsXHUhyGcQnCmFQDtCZSjaVBoSfsBwYPUXAmtnmuJmIxrYyFOYdfHpeZnLqCgYNsVCnIdDcULvMNOybVcaG");
    int GXQiotbaDamETx = 1214977891;
    int MUkriHzsg = -117596725;

    if (QwvTgnnc >= -117596725) {
        for (int qDDaSBPNP = 1167935088; qDDaSBPNP > 0; qDDaSBPNP--) {
            QwvTgnnc *= MUkriHzsg;
        }
    }

    return RyhVz;
}

int tkcHjOzqvge::TSeUTcusjmOJYyy(double WraiDau, int kqbrLgucu)
{
    string oqsWczmzYpABBnf = string("qgYOfTIqlRoyyNInmgbUnLUEqxRYOEjNbQIFNVnJQIPdYXJEIdukyXRgFsXFiIVCYZjCbDomIWjdJjwSjVNLwcxNheLgROZtkAXWyLpWZRzvRIxWjBJBzKYGDTLl");
    bool cSplNSZr = true;
    double WliHJVN = 434282.35435177316;
    double HZrifg = -758467.3299327146;
    int zeRxmEmkOUCHORB = -294877187;
    string kOsyRHouDl = string("EeLRDrghygtHQWOXCIrsQzwyGJqbexldHtRxmiEPUGGrxNnqQqqwKWWHCaAjljRlrrAJdoHTgHUPrfvkpwEuRAtxPwRREHDdINvKyVYsmTaSuCSQjmAHiPPmDAPHasIMkFkKJnilmaUBQzizSjtDvmnfLoSjwrVigoNmfaVblGFZKqhgyPcGDMzuqGckSXYkfgQiXtakkklkzzQLihAGvqBFMR");
    string chjCYWmVkteiAxZ = string("pPsbSepbxeLhPkGZBRqbrrdMxEaPvTWsCCrxmjhNsFppRBtZwlJjlQAhSFGRWoFgVnEwpcIbWiEkPuYhheEAbcOurunvZCzbrpijeIEmSpYstGbYT");

    if (chjCYWmVkteiAxZ == string("pPsbSepbxeLhPkGZBRqbrrdMxEaPvTWsCCrxmjhNsFppRBtZwlJjlQAhSFGRWoFgVnEwpcIbWiEkPuYhheEAbcOurunvZCzbrpijeIEmSpYstGbYT")) {
        for (int QHrLOO = 202154736; QHrLOO > 0; QHrLOO--) {
            WliHJVN /= WraiDau;
            WliHJVN = HZrifg;
        }
    }

    for (int NIgqgl = 623911621; NIgqgl > 0; NIgqgl--) {
        kOsyRHouDl = chjCYWmVkteiAxZ;
    }

    if (HZrifg < 229861.9659977456) {
        for (int xjNqtZik = 1488177046; xjNqtZik > 0; xjNqtZik--) {
            kOsyRHouDl = oqsWczmzYpABBnf;
        }
    }

    return zeRxmEmkOUCHORB;
}

int tkcHjOzqvge::gKOqTHS()
{
    int tfUGKQLLfHG = -294535864;
    int PVsxNNzyRG = 1847864466;

    if (tfUGKQLLfHG < 1847864466) {
        for (int iPVWmsfavqEopDBI = 245523564; iPVWmsfavqEopDBI > 0; iPVWmsfavqEopDBI--) {
            tfUGKQLLfHG -= tfUGKQLLfHG;
            PVsxNNzyRG /= tfUGKQLLfHG;
        }
    }

    if (tfUGKQLLfHG >= -294535864) {
        for (int CgFKHnduB = 2015378397; CgFKHnduB > 0; CgFKHnduB--) {
            tfUGKQLLfHG /= tfUGKQLLfHG;
            tfUGKQLLfHG += tfUGKQLLfHG;
            tfUGKQLLfHG *= tfUGKQLLfHG;
            PVsxNNzyRG *= PVsxNNzyRG;
        }
    }

    if (tfUGKQLLfHG <= 1847864466) {
        for (int aHYzIlLOAGGutqey = 1402870925; aHYzIlLOAGGutqey > 0; aHYzIlLOAGGutqey--) {
            PVsxNNzyRG /= PVsxNNzyRG;
            tfUGKQLLfHG = PVsxNNzyRG;
            tfUGKQLLfHG += tfUGKQLLfHG;
            tfUGKQLLfHG -= tfUGKQLLfHG;
            tfUGKQLLfHG *= PVsxNNzyRG;
            PVsxNNzyRG = tfUGKQLLfHG;
            tfUGKQLLfHG += PVsxNNzyRG;
        }
    }

    return PVsxNNzyRG;
}

string tkcHjOzqvge::ZQfpitEj(int dOIXssptsMcN)
{
    int kDGeFvUbDJV = -1246977982;

    if (kDGeFvUbDJV != -1246977982) {
        for (int YtykPRtWEJ = 677087492; YtykPRtWEJ > 0; YtykPRtWEJ--) {
            dOIXssptsMcN = dOIXssptsMcN;
            dOIXssptsMcN *= dOIXssptsMcN;
            kDGeFvUbDJV -= dOIXssptsMcN;
            kDGeFvUbDJV = dOIXssptsMcN;
            dOIXssptsMcN *= dOIXssptsMcN;
            dOIXssptsMcN -= kDGeFvUbDJV;
        }
    }

    if (kDGeFvUbDJV < -1246977982) {
        for (int YWPUOmmed = 687426070; YWPUOmmed > 0; YWPUOmmed--) {
            dOIXssptsMcN += dOIXssptsMcN;
            kDGeFvUbDJV *= kDGeFvUbDJV;
            kDGeFvUbDJV += dOIXssptsMcN;
            dOIXssptsMcN = dOIXssptsMcN;
            kDGeFvUbDJV /= dOIXssptsMcN;
            dOIXssptsMcN = kDGeFvUbDJV;
            kDGeFvUbDJV = dOIXssptsMcN;
            kDGeFvUbDJV += dOIXssptsMcN;
            kDGeFvUbDJV /= dOIXssptsMcN;
        }
    }

    if (kDGeFvUbDJV < 1926839105) {
        for (int mahUgcvIQqrVJt = 2095904448; mahUgcvIQqrVJt > 0; mahUgcvIQqrVJt--) {
            dOIXssptsMcN += dOIXssptsMcN;
            dOIXssptsMcN = kDGeFvUbDJV;
            kDGeFvUbDJV /= dOIXssptsMcN;
            kDGeFvUbDJV += dOIXssptsMcN;
            dOIXssptsMcN -= dOIXssptsMcN;
            kDGeFvUbDJV -= kDGeFvUbDJV;
            dOIXssptsMcN /= kDGeFvUbDJV;
            kDGeFvUbDJV = dOIXssptsMcN;
            kDGeFvUbDJV += dOIXssptsMcN;
        }
    }

    if (kDGeFvUbDJV >= -1246977982) {
        for (int oeiqJuwF = 599854871; oeiqJuwF > 0; oeiqJuwF--) {
            dOIXssptsMcN = dOIXssptsMcN;
        }
    }

    if (kDGeFvUbDJV >= 1926839105) {
        for (int yNDHHqBbBcWpqU = 748080406; yNDHHqBbBcWpqU > 0; yNDHHqBbBcWpqU--) {
            dOIXssptsMcN -= dOIXssptsMcN;
            dOIXssptsMcN -= dOIXssptsMcN;
            kDGeFvUbDJV *= dOIXssptsMcN;
            dOIXssptsMcN /= kDGeFvUbDJV;
            dOIXssptsMcN += dOIXssptsMcN;
            dOIXssptsMcN /= dOIXssptsMcN;
        }
    }

    if (kDGeFvUbDJV == -1246977982) {
        for (int cazMbPzeDw = 1709999056; cazMbPzeDw > 0; cazMbPzeDw--) {
            kDGeFvUbDJV /= kDGeFvUbDJV;
            dOIXssptsMcN = kDGeFvUbDJV;
            dOIXssptsMcN -= dOIXssptsMcN;
            dOIXssptsMcN += kDGeFvUbDJV;
            kDGeFvUbDJV *= dOIXssptsMcN;
            kDGeFvUbDJV += kDGeFvUbDJV;
            kDGeFvUbDJV = kDGeFvUbDJV;
        }
    }

    return string("cZSKvIBZbLePfhvwmLvEoVjsMnOcPtPekYtTqEWsBHflCdAOUXdVVmwFnIPNzTQewnQVVaojRDRoNsGYvLyUJisOZrdKoKAgmcvXpeADFsxcVbkpholgsTqYrFiSXMuAegfxwADEka");
}

int tkcHjOzqvge::PFdZVLJrCeU(double psHJA, int oZiqXDyXQbXCKGjJ, bool JtNzuStSqBvqxFYY, string SvjGFyKq, int rlidTZDf)
{
    string ZclmpfCbiCyoU = string("gHZlmZRRkpPUuxitttGZbBYbGIAsNzEibKDVdceKKGlnpxEbNDFBzkRWHyiRVWfGsXlyVFOzSgwfNMZFrZGOmpMTCWyQFjQfiRxPbOpnpStrRRcel");
    int VdRxvA = -1309478567;
    double QCYFrbcprpAF = 1013111.2009807936;
    double IrzWVLGVfTWjP = -422872.1720618689;
    bool GSiMhLWwYA = false;
    bool iaHFgL = true;

    for (int cwYBLRQqZHExZa = 1656315782; cwYBLRQqZHExZa > 0; cwYBLRQqZHExZa--) {
        continue;
    }

    for (int yqTgSlYIxioRE = 470387342; yqTgSlYIxioRE > 0; yqTgSlYIxioRE--) {
        continue;
    }

    if (JtNzuStSqBvqxFYY == false) {
        for (int CstxtMfuezJBkBTf = 1203821736; CstxtMfuezJBkBTf > 0; CstxtMfuezJBkBTf--) {
            continue;
        }
    }

    for (int KpWDAbRp = 1148495850; KpWDAbRp > 0; KpWDAbRp--) {
        GSiMhLWwYA = GSiMhLWwYA;
    }

    if (JtNzuStSqBvqxFYY == true) {
        for (int NtXmDydf = 1351746487; NtXmDydf > 0; NtXmDydf--) {
            QCYFrbcprpAF /= psHJA;
        }
    }

    for (int bCyDob = 1517894672; bCyDob > 0; bCyDob--) {
        SvjGFyKq = SvjGFyKq;
        rlidTZDf -= VdRxvA;
        iaHFgL = GSiMhLWwYA;
        rlidTZDf = oZiqXDyXQbXCKGjJ;
    }

    return VdRxvA;
}

string tkcHjOzqvge::GTpyEYU(bool htint, int RMZqmJpKIZXEP, bool qdNqsthRZIkfRN, bool yuEwELftFwK)
{
    double zquNXwt = -1019974.241480987;
    int WKwYuBSUxa = -1922338502;
    bool SzXTOU = true;

    return string("KxkcfGBXBvckyDwkXatMyQAGdOFMaFEJgxVggJxlRgSRaHJFxHVRLqlejkZXEjKtBIlwTubeMftfpdjDqWHxvQaRdnFCBqYQntfXamyYJhVXOOQumLWhdLdGOEZyxFxavBGlaHxEEoUcTwBSVFNwMxdPAPSPuKrzvTWtDRAQsYqWAgubibNgpcZNwEcSTFkNqCmmANLGfRdQZEXBywVybHEaAKRXOzblLBRUZxHbZEBxfLUOSGzvuoYyniAYxyq");
}

bool tkcHjOzqvge::lihiyktWhzlRJCrj(double pVhMKgQeIe, string yLWIUFCpwmuQfs, string kwVcFHvBY)
{
    double kFsAvGlwmQsdRag = -436926.8035338149;
    bool zbLtJXnutCEX = false;
    int BvGFTb = -1457370302;
    string EhOlSlkvm = string("vPXAQcnuRewMSQbEcjVwBkVMpudUkqXWXRknNHUjpulTUdxzzLnYMxSrvCUowFzYINokJSdYjLmbFwVmQxCbpyFGnMGtxkTRTMbpmEHSKTCMtssXBrrZOOVKMoWoPbLAu");

    for (int MTwDtZfaksq = 187053858; MTwDtZfaksq > 0; MTwDtZfaksq--) {
        continue;
    }

    return zbLtJXnutCEX;
}

void tkcHjOzqvge::BEOEWfLz(double OqAwzsRgAJx)
{
    string KZlwAFccsOXs = string("UdVyYKFNHQfkLpkxtehlByVYIUeeJxOnVtuzucBQXXZGjDmyknGQkfoIqvfOKgFwYGHOZcXtoTpILWgcGaKrPhpXgIWiZKFchpLkOuiwfptTsZnnlGFKVGEwSwbZGlKbgcAxYDCQJmmYYsgIcnJcPLyPCRzvlKHzebUJBVFckLccmkkRHmUIJHEqGQNQMCMzwZwjiWylrVhCcalmMnZOcIHGtLeiPlAeEpXluOyTRNXZcljSW");
    double dzyFpqAIAUDpO = 166915.8054986623;
}

void tkcHjOzqvge::odAfdyL(bool gQxbIhrgYQc, bool QGKUi, int UbwSsdbeaBrgFMr, int ywWBIaFkrDwfrf)
{
    double QhqhEfrrgTlfGt = -36550.8456072363;
    int jXRfcr = -1420339418;
    string LzTjFbUfACDdGkI = string("ZwVqopYxgXADkOdmZElCZTITfpEDSdPswzLKrETFQDdqWtproDnvqBPVVgTVEZMRxFqbwjNhpClgfvGDZPaGoACKJujzdwzBqEAeTgpyaIxaTSmDumoshGrIqihQDIsrNHUdqGZsyRMMqVeXnGIwnQxWBtjyfWMubDXLLPSuQAdSkthwzaIEBUfPTSzqFDDfofAlzmbgbFzxRpHeNSZeemhQBPPYldCRbAtsBVjRZIhzREmQdC");
}

void tkcHjOzqvge::uItevKpKfzZj()
{
    string NGSRpJhal = string("GlneaESXgzGZhwzhHHckZsbptNqNOrXQvGlppSTko");
    string CwvqlbFGNsaTA = string("WlpSovRgfThwZPSfPCPrbywHukoWgsrybdctNYgmuhsBhKTnNspNiCDjEBAoozNnMCNMUTXcuDaWAHRieaitHyvprk");
    double ZFZTBAMResLbn = 32015.67842702701;
    double kAQxA = 251761.41181740648;
    bool CRJLALHk = false;
    double LhnOzljxcLUguL = -598457.2184358414;
    bool DkXSVKWJRBeQTDpA = false;
    bool xyLDLEpnDTdlEu = true;
    int CWRXY = 1375830028;

    for (int sqBFAwkGtRkOv = 727591113; sqBFAwkGtRkOv > 0; sqBFAwkGtRkOv--) {
        kAQxA -= LhnOzljxcLUguL;
        CRJLALHk = CRJLALHk;
        xyLDLEpnDTdlEu = DkXSVKWJRBeQTDpA;
        DkXSVKWJRBeQTDpA = xyLDLEpnDTdlEu;
        ZFZTBAMResLbn *= kAQxA;
        LhnOzljxcLUguL -= kAQxA;
    }

    for (int qgRfZBTvfyYMVH = 88468364; qgRfZBTvfyYMVH > 0; qgRfZBTvfyYMVH--) {
        DkXSVKWJRBeQTDpA = ! CRJLALHk;
        xyLDLEpnDTdlEu = CRJLALHk;
        ZFZTBAMResLbn /= kAQxA;
    }

    for (int ImWbrxQ = 1806697737; ImWbrxQ > 0; ImWbrxQ--) {
        LhnOzljxcLUguL /= LhnOzljxcLUguL;
    }

    if (ZFZTBAMResLbn < -598457.2184358414) {
        for (int mGRYQhaEjJkpw = 681183529; mGRYQhaEjJkpw > 0; mGRYQhaEjJkpw--) {
            CRJLALHk = xyLDLEpnDTdlEu;
        }
    }

    if (CWRXY != 1375830028) {
        for (int hJzcV = 1358143065; hJzcV > 0; hJzcV--) {
            kAQxA += ZFZTBAMResLbn;
            xyLDLEpnDTdlEu = ! CRJLALHk;
            LhnOzljxcLUguL *= ZFZTBAMResLbn;
        }
    }
}

double tkcHjOzqvge::KRLTeCWDeRFDKbjm(string grESjsko)
{
    string UHXvZAhYqapP = string("PxKJcGhUSiaWtRAPNZuBQLoiQWiEZueLsaluLZLfJTBwnIZRiRWbAuKPGtwVvBHmUBSNIZUTgWOSODiHOCPWAQaiwiNuLdzpKR");
    int EsUfkgaMet = -1011999329;
    double PXqpr = 39374.69577221555;

    for (int LkUSuSVXeugV = 1625977532; LkUSuSVXeugV > 0; LkUSuSVXeugV--) {
        grESjsko = grESjsko;
    }

    return PXqpr;
}

string tkcHjOzqvge::iljqxhxgBXR(bool Rgmkzovp, string xNzdIiifw, string QGzrrUPSRt)
{
    bool GKASsxZdZwnlfe = false;
    int lomtUu = 788415871;
    bool SeUqm = true;
    string NxepINRlcnKP = string("EwybwJeCbOzLbADhCPIyBzheusRuDSRaUYkIPvHExZkELJzhAPKQQEfBhZvmbWoLYTGezNgIRZLAhWkDIiqhpouMSZvoAAwNIoVghWBVJceeThMxGfrdgcwdLUVBqMj");

    if (GKASsxZdZwnlfe != false) {
        for (int vCRmw = 827433378; vCRmw > 0; vCRmw--) {
            SeUqm = ! SeUqm;
            NxepINRlcnKP += QGzrrUPSRt;
        }
    }

    if (QGzrrUPSRt == string("twVqFXtHPzoSanmflscXeofViZyysnWZgeNwoRpBxHqyQhDdDfLroogIDFetRPOoEFCmagAUPzzWmmLaemphlnKtqJlhcdDytYiPmGqLaNutOhoXltfaZvNXkcQLyhvtdSrPkFcJkeOixuwIjeRnKokWVAvBhpByXhTjyinixeYyyNFEpJXtZhfaNhCSoCPZYoBUpaRcoCLgyJ")) {
        for (int GIyPQDG = 652454130; GIyPQDG > 0; GIyPQDG--) {
            continue;
        }
    }

    for (int tWFcuOJYawlAIU = 1979389847; tWFcuOJYawlAIU > 0; tWFcuOJYawlAIU--) {
        continue;
    }

    for (int MywiKjwbYzXvDg = 198507566; MywiKjwbYzXvDg > 0; MywiKjwbYzXvDg--) {
        QGzrrUPSRt = xNzdIiifw;
        NxepINRlcnKP += xNzdIiifw;
        QGzrrUPSRt = xNzdIiifw;
        GKASsxZdZwnlfe = ! Rgmkzovp;
    }

    return NxepINRlcnKP;
}

tkcHjOzqvge::tkcHjOzqvge()
{
    this->BFhELhPVKte(string("bvQkOLsLQinByWAemsBaPltTuKSzgnSysHDyPSjXEIoQlwHalAjkvdGzmUqAOXJqNvoSLlLAPs"));
    this->hwKQrP(-635203.2765680731, true, -417273.6991394259, -515972.525975011, 1004851.293728709);
    this->jXuzMtMrGuqRJS(575161.3083436133, string("jujywHyMEazGbsaRvLmxOPSqNeMhSsqUYXIAieCqpjhoBoaUuUiiKKQPmjiZTiiMKxIMUoBrwfZViIqCwBYMQjBfJoZsjS"), 303865.14830991474, -1383796443);
    this->LuICiS(true);
    this->UsLfjMGO(628695.5175414031, string("gladBDUmttVWprSrGfvTbeSJoybYpxHreMZlIfDIOuEYohdVKuWrffMfcTXdSZbGnaZSyhCaawgEChgmDHviiocGeMpToetMKqsKywDDjvTxLTLCNUYmkBOeJDBnsHyNlbJooarJPtLHovkIZrdQZEiwrczZvbcjutBUVmWOBBbkVtitpjqGXarrzpwvHORbnXUtFtXkNspnDTveV"));
    this->YCNqSEElLOlsdjkA();
    this->TZhnWNVen(-775289348);
    this->sSguVnoS(true);
    this->TSeUTcusjmOJYyy(229861.9659977456, 956795051);
    this->gKOqTHS();
    this->ZQfpitEj(1926839105);
    this->PFdZVLJrCeU(-643071.9231841363, -140831160, true, string("nhrXFnvGhmhAaTjAIgkVKPhStXZDuCTnXpDJyEhUEClXvHSRmK"), -377146501);
    this->GTpyEYU(true, -1195135813, true, true);
    this->lihiyktWhzlRJCrj(654342.0988840298, string("nxYGisWCudoRTFdmcWCMbkzSnLlVxMpoStupHQFlRkxJhbOrK"), string("OCUijLRCmKMyKaJvdhcepENqDVVvtWCsImNgwKTgBYMgjdsRxQScHobMNiUAmDgoqAVrSywAtMRDuhiBYWqzLuMpHWaNAXHaPXMIirRTmqQOxEIhjChbApPBxbkZzmxDrSMlZCJcGLcTATKJrvUFaFDtWatQOfTSulDHNyDTAisPMwaerjNKSuHOOuTQUYJqgLiOwElTHITsER"));
    this->BEOEWfLz(728632.4838898423);
    this->odAfdyL(false, true, 461597281, 800422475);
    this->uItevKpKfzZj();
    this->KRLTeCWDeRFDKbjm(string("fgzMeCpWhknxtahcuaLyfWpGgYTdVLxtsgFJKYBTRivJkanueksbOKIUhGcsayWOddWtfDlZPnhbInQHazzuLfAazmffxhuZvAUtziegoPCq"));
    this->iljqxhxgBXR(false, string("UatoekyornfczdYVjAtsaWgFYeLLBZfQqcvWAkCXkFBJwtuSTWGcVwxYPIkZEOAbapMFwhUoxrHoLfocAHvTUoWLDoSIkdmhzcnmSkCsTfFYmmhMtRluFGPbKRemBuhjqgeNOmFfsGdhrVHJLAugyjrgmFBCFnjmhcHroBbNavjygXqhcYtcpeXkFwtdNYjwxdgsGjHGvhjuGtyVdhVxjlfzXiFcrtKZ"), string("twVqFXtHPzoSanmflscXeofViZyysnWZgeNwoRpBxHqyQhDdDfLroogIDFetRPOoEFCmagAUPzzWmmLaemphlnKtqJlhcdDytYiPmGqLaNutOhoXltfaZvNXkcQLyhvtdSrPkFcJkeOixuwIjeRnKokWVAvBhpByXhTjyinixeYyyNFEpJXtZhfaNhCSoCPZYoBUpaRcoCLgyJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JJJiZQQoScBlI
{
public:
    int sSVsP;
    int yXyqpOYZ;

    JJJiZQQoScBlI();
    void piBwnlCAgOkOqUi();
    int CPneVKNslUMKHJTm(double bIJRPhfu, string qFNhTGDdjombJpiX, double zlJJBRYKFl, double VOQOSOhUxJ, int jRHYyGMqzM);
    string vvtgvZA();
    void IkJGLHcfqhQweK(double RAMPYxulQ, bool DhlakvcMxzM, int inyELy, int bCrQS);
    double pxSPtQSkFUbc(int wNPTWdzeRR, bool VMZkqwYOPVmEqpFQ);
    void sBSXnyOQiI(double viRUjulugoMMSQO, int sYdEXRoIJkXesW);
    double dxpXQn(string OzGNWlQ, bool TvmypJvqAmyAGgO);
    void qzIAIPPj();
protected:
    double ilRHduhDqf;
    string VayhxpYguNQkmjvC;
    double FlwDzPMuptGX;
    int ttyoNKSIqPilpBvw;
    bool lKFGTRGk;

    void SqEJVEhTgu(string kIdzRmiMC, double imfDNOYIrD, double UXWArwPPYxUEGGO, int gPgifhBAaUANqF);
    double uyHjCsqmlpKIkWS(double BdLEiVDZbHm, bool QbhFATn, double LyezEZ, int ncDxAfFhEKHAl, string tlNrJRBtHKOgSR);
    int kwfnDwJMqT(bool ZdbfpkmwqFgKSvE, double mBiGVbDBaU, string hGXyXrcGA, string hOMmjxRDoiEzVl, string UXCkMiXqWfQXZCA);
    string DTIVjTFDV(double RAnbWRbYZCwq, int EopOsWJOXAxVoA);
    double lcLUMSzEaUV(string VfirWLarGrYerkU, bool TOnVdi);
    double oObVOPXQrnq(double YIfXhmblDauya, double EnPpUeT, double qfxPjCLQdPyoC, int imiXMOHWl, int bQzTcQZZWWmeRhqp);
    void RtdiyT(int DCBbZkKJzfAYdm);
    bool ccErNLIpRCHqmx(int eCwuTlcqEwqX, string hLTqRLyukD, bool uyUHOAukAL);
private:
    bool LtbJcJAv;
    string muowHnhz;
    string vzHSZM;
    double RvFbVEDyoPThqojY;

    int rKZtLBkCFscFYA();
};

void JJJiZQQoScBlI::piBwnlCAgOkOqUi()
{
    double dfrLH = -364613.95191966725;
    double nPKCm = -118608.6767632975;
    string mbfuObC = string("JkkJmErBjPQvVzcdTDUELjQNImNaRhSHZsjeVHVSFgjakIsIjMeSztAbVXllqTQMQKCmdUOakcrtKQnPIYwFMpyubcsXBICgzetVAVsaELRxjvqEspXcokFGgbHLLBorqVWnxRRwjRJRQzUjBadtvZlTaivhiQlaHtMUmTFDmlYtPnOPPAYtqIyKWevdOKYvpWOLJHAKqvdGUF");
    bool HYvCouTlBaepYh = true;
    string CnpVrOEMHzxPulx = string("ZqTsjWUiHLHFTqcQjMgCAIMjjKdKxPdZsCzKVqquTGjaRugvZLdXbWwpxPMkHiZBzrebshthUuetlriWLyTRFw");

    if (CnpVrOEMHzxPulx > string("ZqTsjWUiHLHFTqcQjMgCAIMjjKdKxPdZsCzKVqquTGjaRugvZLdXbWwpxPMkHiZBzrebshthUuetlriWLyTRFw")) {
        for (int DjAWfXehyTr = 1823945385; DjAWfXehyTr > 0; DjAWfXehyTr--) {
            mbfuObC = CnpVrOEMHzxPulx;
            CnpVrOEMHzxPulx = mbfuObC;
            CnpVrOEMHzxPulx = mbfuObC;
        }
    }

    for (int qalvsTtHWqPgRG = 1202030306; qalvsTtHWqPgRG > 0; qalvsTtHWqPgRG--) {
        nPKCm -= dfrLH;
        nPKCm *= nPKCm;
        dfrLH *= nPKCm;
    }

    for (int kVfGw = 1962187140; kVfGw > 0; kVfGw--) {
        nPKCm += dfrLH;
    }

    for (int MMPGLyBHjKcITbs = 1850758628; MMPGLyBHjKcITbs > 0; MMPGLyBHjKcITbs--) {
        mbfuObC += mbfuObC;
        nPKCm += dfrLH;
        dfrLH += nPKCm;
    }
}

int JJJiZQQoScBlI::CPneVKNslUMKHJTm(double bIJRPhfu, string qFNhTGDdjombJpiX, double zlJJBRYKFl, double VOQOSOhUxJ, int jRHYyGMqzM)
{
    int vXpsvjTNuV = 2056270189;
    string vbheD = string("FhoToHGuciFpJwRfDYfNCROmoFemyeOyqiuvBlNRcOmZvMQncheGkTlbYfReHyMBBFf");
    string eSqjhtC = string("rtMAUfPypoRfwFcfweNeMVXLyyonxPSRysECsorrzxGWuSyhGiqVOqApma");
    bool kSqxwQDyw = true;
    double bCrgUe = 270456.61173461267;

    for (int laNgJjmVjZ = 738145343; laNgJjmVjZ > 0; laNgJjmVjZ--) {
        continue;
    }

    for (int lrLBlyT = 1949021466; lrLBlyT > 0; lrLBlyT--) {
        bIJRPhfu -= VOQOSOhUxJ;
    }

    for (int XUxIBSwEjHTIV = 219125981; XUxIBSwEjHTIV > 0; XUxIBSwEjHTIV--) {
        qFNhTGDdjombJpiX += eSqjhtC;
        bCrgUe *= VOQOSOhUxJ;
        zlJJBRYKFl -= zlJJBRYKFl;
        VOQOSOhUxJ *= VOQOSOhUxJ;
    }

    if (qFNhTGDdjombJpiX > string("gXnLkuQrGXlKBcTtbZoGLwCcyDqbkBHdepyPVaZZrgIthmRQArqzskMoLONFlBbbjUkfaRlEdTweTtYjYpgKuHsWLfQOjszaxbAPr")) {
        for (int INYvlYLjyjvGYh = 929101337; INYvlYLjyjvGYh > 0; INYvlYLjyjvGYh--) {
            VOQOSOhUxJ /= bCrgUe;
            vXpsvjTNuV /= jRHYyGMqzM;
        }
    }

    if (bCrgUe <= -447838.9233496722) {
        for (int ZXRSCa = 846151022; ZXRSCa > 0; ZXRSCa--) {
            vXpsvjTNuV *= vXpsvjTNuV;
            zlJJBRYKFl -= VOQOSOhUxJ;
            bIJRPhfu = VOQOSOhUxJ;
        }
    }

    return vXpsvjTNuV;
}

string JJJiZQQoScBlI::vvtgvZA()
{
    bool xndzPQVZ = true;
    bool iBmBEiORpBUO = true;
    int HJHRNtgaO = 1714927992;
    double RUyqDcCTZfqOO = -487973.7138404011;
    int hZycockxvo = 549823237;
    int gsOjLTyqwpgj = 994586073;
    double oVgdDLLohZ = -696172.9234813252;
    double JLGOV = -818282.9394732832;
    string hrFFkclrNhr = string("GLQFfllztuMMsJoVrUqTqdfHXOLzXvSbXBDdyjkfYywEYASLtJTYbeUeyUXmoYcuDUBEhbTEVSwUhSUWkRHDymEhJTDDHNYBhbWYxFEMpIQIGuqzixMDdhsCDMMPjWCZOBsSvZwXmKYDMOHXkOTmfsqESpclnKsJXxJucBGgTcNYapJBspaGkBqicEns");

    for (int TWxQxODWlNhoJjfg = 1832350709; TWxQxODWlNhoJjfg > 0; TWxQxODWlNhoJjfg--) {
        hZycockxvo /= hZycockxvo;
    }

    for (int XWreRvwIdzSlw = 1728832646; XWreRvwIdzSlw > 0; XWreRvwIdzSlw--) {
        continue;
    }

    for (int zHnouJwqTgjF = 1737456542; zHnouJwqTgjF > 0; zHnouJwqTgjF--) {
        continue;
    }

    return hrFFkclrNhr;
}

void JJJiZQQoScBlI::IkJGLHcfqhQweK(double RAMPYxulQ, bool DhlakvcMxzM, int inyELy, int bCrQS)
{
    bool zUlaZrUFesxSeq = false;

    for (int CvmCEfBYp = 989569639; CvmCEfBYp > 0; CvmCEfBYp--) {
        continue;
    }

    for (int ZYvNXNnHr = 1725701512; ZYvNXNnHr > 0; ZYvNXNnHr--) {
        inyELy -= inyELy;
        bCrQS *= bCrQS;
    }

    if (inyELy < -1054328936) {
        for (int nFgwIIUZknBfp = 1208438912; nFgwIIUZknBfp > 0; nFgwIIUZknBfp--) {
            zUlaZrUFesxSeq = ! zUlaZrUFesxSeq;
            inyELy *= inyELy;
            RAMPYxulQ *= RAMPYxulQ;
        }
    }

    for (int ZoTiFTARvQ = 1078770563; ZoTiFTARvQ > 0; ZoTiFTARvQ--) {
        continue;
    }
}

double JJJiZQQoScBlI::pxSPtQSkFUbc(int wNPTWdzeRR, bool VMZkqwYOPVmEqpFQ)
{
    string tUiKXDwAVlKeffqM = string("QMcLeeeFVKDRzmxbPGUVs");
    double ogmeoO = 896585.0205693955;
    int aTFuTjPqOnDregM = 1595826037;
    int FAkvTWmOI = -1559470394;

    return ogmeoO;
}

void JJJiZQQoScBlI::sBSXnyOQiI(double viRUjulugoMMSQO, int sYdEXRoIJkXesW)
{
    int YtNzl = 1530455959;
    double NRWPVoyaPHOv = -734475.3570539235;
    int xZipMp = 1464863036;
    int UEDFlgHt = 2000196778;
    double YNNnMjcmuX = 918561.3070039847;
    int qXLpYD = -1531894626;

    for (int lOkDsn = 1881857189; lOkDsn > 0; lOkDsn--) {
        sYdEXRoIJkXesW /= UEDFlgHt;
    }

    if (xZipMp >= -1531894626) {
        for (int wTWFwJtGoH = 600728504; wTWFwJtGoH > 0; wTWFwJtGoH--) {
            viRUjulugoMMSQO /= YNNnMjcmuX;
            YNNnMjcmuX /= NRWPVoyaPHOv;
            qXLpYD += qXLpYD;
        }
    }

    if (UEDFlgHt == 305565299) {
        for (int SQxiQJDpYhFoyPzA = 392039414; SQxiQJDpYhFoyPzA > 0; SQxiQJDpYhFoyPzA--) {
            viRUjulugoMMSQO *= YNNnMjcmuX;
            qXLpYD += YtNzl;
        }
    }

    for (int NYXKZVPoG = 2027093118; NYXKZVPoG > 0; NYXKZVPoG--) {
        qXLpYD -= UEDFlgHt;
        viRUjulugoMMSQO /= YNNnMjcmuX;
    }
}

double JJJiZQQoScBlI::dxpXQn(string OzGNWlQ, bool TvmypJvqAmyAGgO)
{
    int ZPuQDG = 524287914;

    for (int aOLOiQBz = 571637892; aOLOiQBz > 0; aOLOiQBz--) {
        OzGNWlQ += OzGNWlQ;
        TvmypJvqAmyAGgO = TvmypJvqAmyAGgO;
    }

    for (int uXPFetgdix = 1815328116; uXPFetgdix > 0; uXPFetgdix--) {
        OzGNWlQ += OzGNWlQ;
        OzGNWlQ += OzGNWlQ;
        TvmypJvqAmyAGgO = TvmypJvqAmyAGgO;
    }

    if (TvmypJvqAmyAGgO != true) {
        for (int CMwGnIUVPXG = 1144143500; CMwGnIUVPXG > 0; CMwGnIUVPXG--) {
            ZPuQDG += ZPuQDG;
        }
    }

    return 141747.61121521782;
}

void JJJiZQQoScBlI::qzIAIPPj()
{
    string qYNMvFFgz = string("mLwUfqeYcVcFvaMKrokwISpMpkotzJLHOqSvQOKysHKqtlTaqBrouEQBnUaBSjRqozObzeiSlLwWPdJdNuUKOrXzgfadQspPOGkyqiGvDzpldIqtLDJkEeWdIUlJfQgiqfjVUCimdmBMUtWwCENtz");
    int nmDIqihCYAcck = 594407375;
    bool jLMeIjrGbFyXT = false;
    bool whRtXLjvXmqHVM = false;

    for (int QXHWvsEsgtxWA = 1475776904; QXHWvsEsgtxWA > 0; QXHWvsEsgtxWA--) {
        nmDIqihCYAcck -= nmDIqihCYAcck;
    }

    if (whRtXLjvXmqHVM == false) {
        for (int BQmDJLCsXLIhj = 1544463529; BQmDJLCsXLIhj > 0; BQmDJLCsXLIhj--) {
            jLMeIjrGbFyXT = whRtXLjvXmqHVM;
            whRtXLjvXmqHVM = whRtXLjvXmqHVM;
            whRtXLjvXmqHVM = whRtXLjvXmqHVM;
            whRtXLjvXmqHVM = ! jLMeIjrGbFyXT;
            nmDIqihCYAcck /= nmDIqihCYAcck;
            jLMeIjrGbFyXT = ! whRtXLjvXmqHVM;
        }
    }

    for (int DUAXQcBAyEAtjaVT = 1469590922; DUAXQcBAyEAtjaVT > 0; DUAXQcBAyEAtjaVT--) {
        qYNMvFFgz = qYNMvFFgz;
        jLMeIjrGbFyXT = jLMeIjrGbFyXT;
    }
}

void JJJiZQQoScBlI::SqEJVEhTgu(string kIdzRmiMC, double imfDNOYIrD, double UXWArwPPYxUEGGO, int gPgifhBAaUANqF)
{
    bool ynNobUrirUOuo = true;
    int FcnMKfngaAB = -2068524551;
    double XiVJSJRoqQc = 594103.7442821269;
    double zsBPq = -322432.68227708084;
    int DeEMW = 1754410264;
    string BHMxkwEoI = string("aRUwZdtmKYxhvhSpLfcNuCrlOxyWnUItzqIYAIkpKGcpHZstFKYcNZSi");
    bool nCzJuJehb = false;
    double VEoPOvMddhfU = -223561.52333240147;
    bool EyZACEOPkyAJ = false;
    int DUpSnGBtdL = -1915361283;

    for (int PbYpxvbJBKwWK = 933389654; PbYpxvbJBKwWK > 0; PbYpxvbJBKwWK--) {
        XiVJSJRoqQc += XiVJSJRoqQc;
    }

    if (EyZACEOPkyAJ == false) {
        for (int DXDOZUdriAOeTC = 1804877167; DXDOZUdriAOeTC > 0; DXDOZUdriAOeTC--) {
            continue;
        }
    }

    for (int dKFROKhuoSebXVV = 1019690490; dKFROKhuoSebXVV > 0; dKFROKhuoSebXVV--) {
        continue;
    }

    for (int eVqkKE = 684899717; eVqkKE > 0; eVqkKE--) {
        XiVJSJRoqQc = imfDNOYIrD;
    }
}

double JJJiZQQoScBlI::uyHjCsqmlpKIkWS(double BdLEiVDZbHm, bool QbhFATn, double LyezEZ, int ncDxAfFhEKHAl, string tlNrJRBtHKOgSR)
{
    bool AMOnqkPCCvWBmJrE = true;

    for (int raoLAFk = 1488003716; raoLAFk > 0; raoLAFk--) {
        QbhFATn = QbhFATn;
        QbhFATn = AMOnqkPCCvWBmJrE;
    }

    return LyezEZ;
}

int JJJiZQQoScBlI::kwfnDwJMqT(bool ZdbfpkmwqFgKSvE, double mBiGVbDBaU, string hGXyXrcGA, string hOMmjxRDoiEzVl, string UXCkMiXqWfQXZCA)
{
    int TTGZOyfODFHXqO = -1948456618;
    int ZLKoAAe = 1738270325;
    double DoXQimCAChlQqU = -445190.5104185288;
    string xUkxMx = string("ZswvKebvMwkHMtMBqmkGQuzgwwmtUvJGObSUKatsmhYOlQyoDXdytbFPnFmgRMWKaXZHVlslwwfXhDzsXLEIxMQpxIHjyFJxWxdfOMkePSYcKsHbflsTriXskJeoezCbFDceygWyIAIHTPbE");
    bool vpAYpxTGiEPdWCmN = true;
    string lQgXapXtzyRnsd = string("oGqeyJYOtjbPDFOGkaATEh");
    string teWNNOPARoeSNbPW = string("FzI");
    int GsRqdAT = -344324188;
    double bIrOONOg = 570145.7667005322;
    bool WSMZRQLP = false;

    if (mBiGVbDBaU == 570145.7667005322) {
        for (int WnCliwb = 67070113; WnCliwb > 0; WnCliwb--) {
            lQgXapXtzyRnsd = hOMmjxRDoiEzVl;
        }
    }

    return GsRqdAT;
}

string JJJiZQQoScBlI::DTIVjTFDV(double RAnbWRbYZCwq, int EopOsWJOXAxVoA)
{
    int zIUObNorh = -1860114267;
    int ENkloRiinMdeAF = 1361194648;

    if (ENkloRiinMdeAF > -1860114267) {
        for (int NMhZwNZUsoJGU = 119314988; NMhZwNZUsoJGU > 0; NMhZwNZUsoJGU--) {
            ENkloRiinMdeAF = zIUObNorh;
        }
    }

    if (EopOsWJOXAxVoA >= -1860114267) {
        for (int vgZwf = 1136478447; vgZwf > 0; vgZwf--) {
            zIUObNorh += EopOsWJOXAxVoA;
            zIUObNorh = ENkloRiinMdeAF;
            ENkloRiinMdeAF *= EopOsWJOXAxVoA;
        }
    }

    if (zIUObNorh <= 1361194648) {
        for (int ZGOJCwOEHCuMCi = 804833266; ZGOJCwOEHCuMCi > 0; ZGOJCwOEHCuMCi--) {
            RAnbWRbYZCwq -= RAnbWRbYZCwq;
            ENkloRiinMdeAF = ENkloRiinMdeAF;
            ENkloRiinMdeAF = EopOsWJOXAxVoA;
            zIUObNorh += ENkloRiinMdeAF;
        }
    }

    if (EopOsWJOXAxVoA != 872239070) {
        for (int BfOqtJVllNY = 2080119953; BfOqtJVllNY > 0; BfOqtJVllNY--) {
            EopOsWJOXAxVoA /= ENkloRiinMdeAF;
            ENkloRiinMdeAF -= zIUObNorh;
        }
    }

    for (int UymtkeQi = 1752618234; UymtkeQi > 0; UymtkeQi--) {
        ENkloRiinMdeAF = zIUObNorh;
        EopOsWJOXAxVoA /= zIUObNorh;
        EopOsWJOXAxVoA /= EopOsWJOXAxVoA;
        EopOsWJOXAxVoA = zIUObNorh;
        EopOsWJOXAxVoA += zIUObNorh;
    }

    if (ENkloRiinMdeAF < 1361194648) {
        for (int gnUUBzTclsEs = 778611434; gnUUBzTclsEs > 0; gnUUBzTclsEs--) {
            zIUObNorh += zIUObNorh;
            EopOsWJOXAxVoA += EopOsWJOXAxVoA;
        }
    }

    if (ENkloRiinMdeAF == 1361194648) {
        for (int FpRDqathuQ = 13455634; FpRDqathuQ > 0; FpRDqathuQ--) {
            ENkloRiinMdeAF *= ENkloRiinMdeAF;
            zIUObNorh += zIUObNorh;
            EopOsWJOXAxVoA = ENkloRiinMdeAF;
            EopOsWJOXAxVoA -= zIUObNorh;
            RAnbWRbYZCwq -= RAnbWRbYZCwq;
            ENkloRiinMdeAF -= zIUObNorh;
            zIUObNorh = zIUObNorh;
        }
    }

    if (zIUObNorh > 872239070) {
        for (int DNKOvOGOTD = 1184114943; DNKOvOGOTD > 0; DNKOvOGOTD--) {
            EopOsWJOXAxVoA -= ENkloRiinMdeAF;
            ENkloRiinMdeAF -= ENkloRiinMdeAF;
            ENkloRiinMdeAF += ENkloRiinMdeAF;
            zIUObNorh = zIUObNorh;
            EopOsWJOXAxVoA -= zIUObNorh;
        }
    }

    return string("rOOMduQvbxmDGEwqMoNpULiyjDGMvwBiWMgyChiUENwYrSUTRSYliHHwojqZDJbgFLEsFZgHVKtDd");
}

double JJJiZQQoScBlI::lcLUMSzEaUV(string VfirWLarGrYerkU, bool TOnVdi)
{
    double Vqdsfjlf = 140781.86448274626;
    int zPvfScyP = 440496113;
    string RdUABbVcWs = string("kvgqxuEyNrHYXeQcBLxgRAWCHhWuoAKrbYXDHAjuTctboILbsJxRELtaATBWgHXNqFRVFGWZeZtYuDbVNOJOsgwCTbYMXKutdKdrMsVBcJJYJzZngqnWEYheXtFibTkZJTQUhFUINzujqqeqZJnmOGsGsoqlFWkUSMMOTnxYpwadBrEjtQG");
    double OBSRi = 565484.2317696717;
    int ITRDVRwQUMOs = 1357176465;
    double VwGGJaOwNKJpYy = -773121.5111016725;
    int wdZkpHzoSOnNbS = -1304902601;
    string OmEvYPsVCbQx = string("mCKLmSDXRKUOTHyASNsWbsFusLQrxkwkGWVUmyUcyUVebfhHvAFEADesupxADFLsKjclHyojsjHcrSRgqCNugRudSlPTjCadWEjraNIfmSsuIBACixOkSYHDufpOuvYosnGuNgTHRgQLKoBuePOlTuyfuNOGSjJdrvPxACXjVTJXtPnXZiBaa");
    int kXDWAaWwoyQ = 2037222316;
    int WFCCjjIavktnCzS = -1243924349;

    for (int kIjDTXWIFnmcjWH = 1806625154; kIjDTXWIFnmcjWH > 0; kIjDTXWIFnmcjWH--) {
        RdUABbVcWs = VfirWLarGrYerkU;
        WFCCjjIavktnCzS -= kXDWAaWwoyQ;
        RdUABbVcWs += RdUABbVcWs;
    }

    for (int utjYVymCO = 1997987649; utjYVymCO > 0; utjYVymCO--) {
        zPvfScyP *= WFCCjjIavktnCzS;
    }

    for (int kZjEqI = 1500199835; kZjEqI > 0; kZjEqI--) {
        continue;
    }

    for (int TAayohSinep = 1498090227; TAayohSinep > 0; TAayohSinep--) {
        zPvfScyP *= ITRDVRwQUMOs;
        TOnVdi = TOnVdi;
    }

    if (wdZkpHzoSOnNbS >= -1304902601) {
        for (int zkvfWDt = 347635786; zkvfWDt > 0; zkvfWDt--) {
            WFCCjjIavktnCzS = kXDWAaWwoyQ;
        }
    }

    if (VfirWLarGrYerkU < string("yRefRQcZDgbMITwvrcyZOQcJiAdRNnpnhEjcuEYkJERUCRTSjpezBKYNsznfjkGqBtecaqJQxVVqfuStAsntsZkRVhPnTnhopjSKOrlUwBKYeDDaSKpsJbbqigRZlsOsWIeyZgthqIQBexcAeGWQbNnibnJmTBRsZliMyOEHAbtNOPepHTpnpImKFVezsCjiJsQwVzsKGUkFdphWpq")) {
        for (int EegAvPV = 701173664; EegAvPV > 0; EegAvPV--) {
            continue;
        }
    }

    if (OmEvYPsVCbQx > string("mCKLmSDXRKUOTHyASNsWbsFusLQrxkwkGWVUmyUcyUVebfhHvAFEADesupxADFLsKjclHyojsjHcrSRgqCNugRudSlPTjCadWEjraNIfmSsuIBACixOkSYHDufpOuvYosnGuNgTHRgQLKoBuePOlTuyfuNOGSjJdrvPxACXjVTJXtPnXZiBaa")) {
        for (int wFMJZt = 799576695; wFMJZt > 0; wFMJZt--) {
            wdZkpHzoSOnNbS += WFCCjjIavktnCzS;
            VwGGJaOwNKJpYy = VwGGJaOwNKJpYy;
            wdZkpHzoSOnNbS *= kXDWAaWwoyQ;
        }
    }

    if (WFCCjjIavktnCzS < 2037222316) {
        for (int LZkjniSH = 1829520580; LZkjniSH > 0; LZkjniSH--) {
            wdZkpHzoSOnNbS += ITRDVRwQUMOs;
            VfirWLarGrYerkU = VfirWLarGrYerkU;
            zPvfScyP += kXDWAaWwoyQ;
        }
    }

    return VwGGJaOwNKJpYy;
}

double JJJiZQQoScBlI::oObVOPXQrnq(double YIfXhmblDauya, double EnPpUeT, double qfxPjCLQdPyoC, int imiXMOHWl, int bQzTcQZZWWmeRhqp)
{
    string savzsOYxpWwN = string("xuvxXHKzKlrrePWGJpSsxJKQdNMJJYLxerPMzCkdfKXupWyxKUNLbScRGMQCFjubnoJQjpVByfcicGIYoNYlADZoSQAdfxrjryiZZCaLOXvvjcgpfuEDfrCFNibIwABXeSdFmToAZdsPvDtpZibWurWiuCYQMGRMyPXgwHYjYEHtUFMb");
    int lxuroOdpuJFZk = -1966059531;
    double bYRHI = -341621.04586789914;
    bool wJRPo = false;
    string iDZnD = string("urpkdtUHrKrWTYiITKWHiJrjKnoAnoMbQuGGhKpPGugLxkBkVLUGpuVTOTXtfrMRNaZuVAbIDoDqEQYeUFlKcGNXiCewAIMWEvpKzTuomeBUUDDWYSJlxelbssXPTOwtzmVNIeodGkySMVtzDjSPCJVzCgSceWhblTGGbttmUVjbXrbjT");
    double sYJKQbdfCbV = 517435.81612732186;

    if (bYRHI >= -52811.992745093696) {
        for (int DWfla = 1994262035; DWfla > 0; DWfla--) {
            qfxPjCLQdPyoC *= sYJKQbdfCbV;
        }
    }

    for (int RBDpHYWeZCk = 848366985; RBDpHYWeZCk > 0; RBDpHYWeZCk--) {
        bQzTcQZZWWmeRhqp -= bQzTcQZZWWmeRhqp;
    }

    if (bQzTcQZZWWmeRhqp > 1852913572) {
        for (int zYfUyKPqbfUIWHdE = 951607580; zYfUyKPqbfUIWHdE > 0; zYfUyKPqbfUIWHdE--) {
            continue;
        }
    }

    for (int qbtxdEcMjbOY = 163084885; qbtxdEcMjbOY > 0; qbtxdEcMjbOY--) {
        bYRHI *= bYRHI;
        iDZnD = iDZnD;
        qfxPjCLQdPyoC -= EnPpUeT;
    }

    for (int pUHzTeeTadzsp = 1658707949; pUHzTeeTadzsp > 0; pUHzTeeTadzsp--) {
        sYJKQbdfCbV = YIfXhmblDauya;
        bYRHI = qfxPjCLQdPyoC;
    }

    return sYJKQbdfCbV;
}

void JJJiZQQoScBlI::RtdiyT(int DCBbZkKJzfAYdm)
{
    string dfQmTDLgvInNuji = string("OgNYPDExOOQpTULtsHKElaLbCbRMLpksdhPnWNNzLmkyGJaazUXfKPVKNAFfDgmicqCvvPcMnRntQrPvSONcFnfFLSCE");
    int hzNZKL = 1582141720;
    string LedwlDekQN = string("RwZxZalpawtSsWYxtcfQeyOCgaQZCiWTFutoABRmZepKLbPEdgxzOTVcLIpiazCVjggcUJUOrTLoEMvtzivbfxxjjAswJhgUuzABypeNlbcjmEhF");
    string HkwEqqRieOm = string("tJZgdaNhGiSgBfcLzYaECletOGVbKfdFIBnvzDxQLXLHBMmRPFpGlHUoKBKwfNDVnOHhsChAsxTjhHZpkWsUFZFmXdtDyzMKrXfXjtVGAvCNwlphxAFmfkmuovzxHLjLnoMdJesxNKpsVwivBlNqSZExdWzUHEsieKSfmmvXJxmqpTlAUNQmRdxiFAeffNdYLAOmpsGQLcjBDlMklRCLAxbUEuelnrSTbYbtChqnsBkNeeqFXFrhIH");
    double GVLfefMlYRVShEu = 86351.19339875196;
    double zTqtZsyVwX = -979254.6469129403;
    int pDNmFcA = -275063544;
    double soiUvBCNP = 735546.9185407711;
    int MYMvCBNB = 348105383;
    int mqUxbmJ = 1592282909;

    for (int VlTpfVfJhFPAy = 706085116; VlTpfVfJhFPAy > 0; VlTpfVfJhFPAy--) {
        pDNmFcA += MYMvCBNB;
        zTqtZsyVwX /= zTqtZsyVwX;
    }

    for (int bgVWVsg = 1623796656; bgVWVsg > 0; bgVWVsg--) {
        continue;
    }

    for (int joUwqrLMk = 987029273; joUwqrLMk > 0; joUwqrLMk--) {
        hzNZKL -= DCBbZkKJzfAYdm;
        LedwlDekQN = HkwEqqRieOm;
        pDNmFcA = MYMvCBNB;
        hzNZKL -= DCBbZkKJzfAYdm;
    }

    for (int OnOQJwEPTQOvtL = 1066063505; OnOQJwEPTQOvtL > 0; OnOQJwEPTQOvtL--) {
        LedwlDekQN += LedwlDekQN;
        HkwEqqRieOm += LedwlDekQN;
        MYMvCBNB += hzNZKL;
        MYMvCBNB -= MYMvCBNB;
    }
}

bool JJJiZQQoScBlI::ccErNLIpRCHqmx(int eCwuTlcqEwqX, string hLTqRLyukD, bool uyUHOAukAL)
{
    int mHwkqMDOpYkLgkBk = -952224646;
    string TPFUiqTTclvqwGh = string("NmlIdxyzYSqjnMEeYgQGaKVpwLqBcrUBezwKKqXeCAQIYTyBJdXfVadorwWOtMsOwQRyWFbnSOvrhowmNUbqLuBF");
    int xvKyxEG = -1165224444;
    bool EilUIjMtKruyC = true;
    bool rastz = false;
    int DrZHbCOlIHvrkOnD = -390284162;
    string zPxILjFc = string("gNVZNBGldVzk");
    bool INXqtqfRc = true;
    bool ErrjpgWUsiMLmeM = false;

    for (int hFjldP = 672293402; hFjldP > 0; hFjldP--) {
        xvKyxEG += xvKyxEG;
    }

    for (int WywUBByoGmjkW = 967664740; WywUBByoGmjkW > 0; WywUBByoGmjkW--) {
        EilUIjMtKruyC = rastz;
        EilUIjMtKruyC = EilUIjMtKruyC;
        rastz = ErrjpgWUsiMLmeM;
        xvKyxEG += eCwuTlcqEwqX;
    }

    for (int TkRApnNBJFQRyi = 1990502229; TkRApnNBJFQRyi > 0; TkRApnNBJFQRyi--) {
        uyUHOAukAL = ! rastz;
        INXqtqfRc = ErrjpgWUsiMLmeM;
    }

    if (DrZHbCOlIHvrkOnD >= -1165224444) {
        for (int KKFLhdBEgVpF = 335825204; KKFLhdBEgVpF > 0; KKFLhdBEgVpF--) {
            xvKyxEG -= DrZHbCOlIHvrkOnD;
            uyUHOAukAL = ! ErrjpgWUsiMLmeM;
            zPxILjFc += zPxILjFc;
        }
    }

    for (int inforodF = 282559536; inforodF > 0; inforodF--) {
        TPFUiqTTclvqwGh = hLTqRLyukD;
    }

    return ErrjpgWUsiMLmeM;
}

int JJJiZQQoScBlI::rKZtLBkCFscFYA()
{
    double OkGFYxqxnXWO = -812591.2461338085;
    double ipfDcZorHVWkM = -440376.5041657119;
    double JvJxhPwzeZGal = 931898.8704279031;
    int VmixjPqhhSq = -1078366505;
    string GBoDFFriTnqt = string("UxltNCSNJWyjRgfxkbHFulFwFJmxNwFdMGWWrQqSENLbsstOwFNIMmECfLAPrhRRWUClsYKwQRnahPuvxcilIWsQZnfbBcdtRWAWyCJQtZwvgQTMCAPTYtZtiIJYmbdctPtnGSsmmwtxccnNscORaOMHhFYJlRlXjvOqiGkC");
    string qTLCWOn = string("ZxJvIoipChinzDwiQbzGWyNGKHHCstgAGiWMHZZIhxedEEEfxJXBxNUiPWgZoqnCyfcQvaevdhwdnmZStvuWVugLIvqLFTQvNEpptcgJtNDLZoSkAsCWyiXZwyOTzlAsfqKepjRKxCNefRosjogfQjLhDeJGoGqxnuGzwmKIbNz");
    int EHGVajksE = 332488371;
    bool vUldaNxOerpIVVmN = true;
    bool CLnOlNdBX = true;

    if (JvJxhPwzeZGal <= -440376.5041657119) {
        for (int KTeoMXYk = 471156630; KTeoMXYk > 0; KTeoMXYk--) {
            continue;
        }
    }

    if (JvJxhPwzeZGal <= -440376.5041657119) {
        for (int NoxTMQXF = 1711676207; NoxTMQXF > 0; NoxTMQXF--) {
            qTLCWOn += GBoDFFriTnqt;
        }
    }

    if (ipfDcZorHVWkM == -440376.5041657119) {
        for (int aEnVbSrT = 1132247467; aEnVbSrT > 0; aEnVbSrT--) {
            qTLCWOn += GBoDFFriTnqt;
        }
    }

    return EHGVajksE;
}

JJJiZQQoScBlI::JJJiZQQoScBlI()
{
    this->piBwnlCAgOkOqUi();
    this->CPneVKNslUMKHJTm(458356.97060951777, string("gXnLkuQrGXlKBcTtbZoGLwCcyDqbkBHdepyPVaZZrgIthmRQArqzskMoLONFlBbbjUkfaRlEdTweTtYjYpgKuHsWLfQOjszaxbAPr"), -447838.9233496722, 290984.845046846, 933319303);
    this->vvtgvZA();
    this->IkJGLHcfqhQweK(988989.6457819849, false, -1054328936, -805869510);
    this->pxSPtQSkFUbc(1278197461, true);
    this->sBSXnyOQiI(-206683.6955209622, 305565299);
    this->dxpXQn(string("UENDAtYpTnIzbFQAtYPAgdEeEyGHFmocLrlAuxpWJHgunQNWXFgbEMoeEpgRyCeTCGJDTynWXAizDHJuWeEDWklizyLtMIBEqAEGVHDWJPniYIwWJkkKANWFpddgTbEUNejXeBmIhvpZBHxDbRDiFIMafrDOYhxNbXxUyapqCYcrfMNbHIUwJirzgRRNVOtjgCmAi"), true);
    this->qzIAIPPj();
    this->SqEJVEhTgu(string("BEWwZqexxjKFqBtcpSfouMIqMaJrfcojjrGvsoMeOcEOlFElVaehlARiajvLQFrnrkHVRYlrdOiKZfdKjSUwDQRJiCdFOHmzsjlKYHwrnYsvzEVaHFEUiHiNhLZI"), -188559.99732430978, 551790.5600978853, -929258085);
    this->uyHjCsqmlpKIkWS(-756599.5796284295, false, -636138.86616763, 1928584705, string("GkOBjEbCBciRFnFagLMQLXLJgYPXhWnyDfASxUjGxTfMwvxO"));
    this->kwfnDwJMqT(false, 651169.1368494916, string("qGbSLYqzJmEiwcZpDVLllFGiiFVDmBoziXGPDacqJQVuPSFYWnXUJjjBVhyZxTnuEPlyIvPuSnmEiduOoVCeuRgYNYCIeanUUkgybyxXigstPIOsEXhMthTxScDnHriiTGCiemWvJeBUQoZVfFLyorlcv"), string("aNrrxKxpIluTMerzmrKjONNfpfAQvnBXCTpklBNupk"), string("PaZpwVuFJBUgAqlEifdPgGtEaYSsAIxInhdHrbGQplyRAynUBdoBbrPGlztiIiPjjOnYvqYBALeaewxPPMLViFzZTaOIEhAPFykkgKlsvJcCSespTHTWCeMKnQMzyMtQQpjmLEoWVivqkdUoYfvuPtpzYLIczRoSpmcuoV"));
    this->DTIVjTFDV(283591.69377614075, 872239070);
    this->lcLUMSzEaUV(string("yRefRQcZDgbMITwvrcyZOQcJiAdRNnpnhEjcuEYkJERUCRTSjpezBKYNsznfjkGqBtecaqJQxVVqfuStAsntsZkRVhPnTnhopjSKOrlUwBKYeDDaSKpsJbbqigRZlsOsWIeyZgthqIQBexcAeGWQbNnibnJmTBRsZliMyOEHAbtNOPepHTpnpImKFVezsCjiJsQwVzsKGUkFdphWpq"), false);
    this->oObVOPXQrnq(-823770.9560876783, -52811.992745093696, 288254.550809403, -826545076, 1852913572);
    this->RtdiyT(-160716201);
    this->ccErNLIpRCHqmx(1064136722, string("ObxBIlCgVrzMtggaQlKYGDZoVaiZCUuxmpVdvMQcqFGyLIibNsvUJISmTkwGHMVLbNcTnGBToRCPwQLnPJdAYXPJitYDwyqrQhessfnIuFNHfbjlScFkfKLYjijQJlMmQfHuBriXjuYyAxSzDEghVyIOcuCREkFYCFhaEQsBjkwYJotIaYmEJg"), false);
    this->rKZtLBkCFscFYA();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zQTRJBWzkKoJYCUc
{
public:
    string KcpKWOxK;
    bool RdOFiapYrGtnI;
    double tPwirZVJjuslUqSn;
    string aWPTjcOclHLnXJr;
    bool wlPPREu;

    zQTRJBWzkKoJYCUc();
    bool becuGNaePa(double QXSosYkmXt, bool OqjtZR);
    void mLYrWNZnXSY(int XTQQmYNtIKad);
    bool sUVSUQ(int XiwGMySGW, string UkaehCSmbPVpL, bool LsAAZkzpAtVnkkj, string UqBOC, double VyoLbHA);
    void KOOpTIXFDtlJxpK(int oTqvBoZNejxSB, string QUaFrpb, int saTJX, double dPPQcwtQK);
    void erhOYj(int OLHmmLk);
    bool FmnBE(string NgIGIhXGTlEW, string UMkINNFeM, bool MwWPGm);
    string rZigKhoc();
    int vJVWhYruIZWQJBGA();
protected:
    double zqSNHZkA;
    double eQDuBDHFcsN;
    double xphixe;

    bool NdSuwPwaxKbV(bool LLXlQIcAxBV, double xWDtXJhyXsGod, bool NkyygIUaa, int ihDwlDxUiSRWSdBo);
    double NMOkQki(int yUKLyLFymDYTH, double xeeHA, double cHUzhTD, bool fSsOTtpVTOLtZdj);
    string AYWUdBK(bool WcMuSfm);
    int mjDUzdt(double VdGhFoY, bool RKfRUKRZwmRWNP, int imLIYTBuFjRsKuny);
    double xHiBRySospXpB(int rgjQH, bool LiznhFcogcHm, int CEtHSCPKcBUol, double sqCrNq);
    void rzGBDURoH();
    int ZvRkZotm(int ZHAhMWKnGLYccfre, bool XEnHimwIseN);
private:
    string DoRWpcLvjWuxR;
    bool MScIoRfSuzcFtSIN;
    bool gaRIdAoKSb;
    int zWoaWEFcVE;
    double dbCxMjYIm;

    int aeQXZkBdWnTSMHB(string HXluGGo, bool cKXzGUWJu, int fiSKdJ);
};

bool zQTRJBWzkKoJYCUc::becuGNaePa(double QXSosYkmXt, bool OqjtZR)
{
    double GpQJmze = 460648.86462771724;
    string vIOMQdDce = string("teJIDaPnSYOXqVTHZUABSboISQlkBniduOQMRSDfjrBzZsfIcmsxOXxNKcAzqKscbrQfoQgsSRaRZSXaEpppSIxMIpRRSXBoMBGSqKBJVVDuMehMhJKbxbbxtTAcjjzbUhysPwMLxRItHjkVtkKHott");
    int WWGgBkcZP = -76814764;

    for (int gZvNwfqTZun = 928361143; gZvNwfqTZun > 0; gZvNwfqTZun--) {
        QXSosYkmXt += GpQJmze;
        vIOMQdDce = vIOMQdDce;
    }

    for (int kjLROxSvEK = 102729162; kjLROxSvEK > 0; kjLROxSvEK--) {
        GpQJmze -= GpQJmze;
        QXSosYkmXt -= QXSosYkmXt;
        GpQJmze /= GpQJmze;
    }

    for (int ZzIFKPy = 1531980075; ZzIFKPy > 0; ZzIFKPy--) {
        GpQJmze -= GpQJmze;
        vIOMQdDce = vIOMQdDce;
    }

    for (int aWhAi = 348896125; aWhAi > 0; aWhAi--) {
        GpQJmze = QXSosYkmXt;
    }

    if (GpQJmze > 460648.86462771724) {
        for (int xUlACYpTlh = 149665320; xUlACYpTlh > 0; xUlACYpTlh--) {
            WWGgBkcZP = WWGgBkcZP;
            GpQJmze *= QXSosYkmXt;
            OqjtZR = ! OqjtZR;
        }
    }

    return OqjtZR;
}

void zQTRJBWzkKoJYCUc::mLYrWNZnXSY(int XTQQmYNtIKad)
{
    int hnrDN = -1176474038;
    bool cFYDlxvSgV = true;
    double FTkRwAUpA = -925828.5855376153;
    double WllUiFwfSWDB = -481295.707453967;
    int mcGHCjSMQztlm = 2133764928;
    int hCYKtRTO = -1088249113;
    double OsgrduuQfPcrD = 201505.02939101058;

    for (int NfezhCaH = 109961890; NfezhCaH > 0; NfezhCaH--) {
        continue;
    }
}

bool zQTRJBWzkKoJYCUc::sUVSUQ(int XiwGMySGW, string UkaehCSmbPVpL, bool LsAAZkzpAtVnkkj, string UqBOC, double VyoLbHA)
{
    double KplXSvNXsQj = -384025.84434954607;
    string bzWhSiBvvq = string("DnrYFeITnejwkqPUoovtkxFYResmMqIhTkQhmCbNQpPUmkRuSlTsqAecCfoxKbRHwHGZi");
    double ASxRFBXKFNOGfZu = -749995.4311070392;
    bool yIPFXinnDn = false;
    string uCrXTaBklmpIE = string("agBFJkZtxvVBlgCdeUxMMtFKBfffxGRQliEUfBbAmHIHSOKHqHNxIgPkWvXxpguIILcebXFYmSPCwScQZQyanbdlVDOcvpGenKnbNvoUIkcXyUuGWhWeZkXaDcpwDq");
    int MMYjfSKRESs = 277613550;
    string jWbJz = string("NXiIBMXjOMLhTNrmHyJnasSjwWNCmCQElGdCKSIIDeHRAZuHrQUoodUehHlxDbcyZcRjwgOLORgnlNgbhZaHQZfvOvaTzmfiJGdHnHYsMRqfyChpjBWvLGKwMDlRDtidIHBjNNpmyfMdIcARRwqnXnvnrcMOfyzKqnPtPUKudtOdabjokcCXyvSnnXmisFysXKlFQgiaptnBuYANAgaNaipfJbYEmJPcAkqYTCcgQNJHvWONaoCaKhCL");
    int mDSkxZPuGpWF = 1293331775;
    bool GbthKkeJBYXPJ = false;
    int OPGnLZnezK = 1548146578;

    for (int MmgDeLtmFaSde = 784340408; MmgDeLtmFaSde > 0; MmgDeLtmFaSde--) {
        VyoLbHA /= KplXSvNXsQj;
    }

    if (bzWhSiBvvq == string("NXiIBMXjOMLhTNrmHyJnasSjwWNCmCQElGdCKSIIDeHRAZuHrQUoodUehHlxDbcyZcRjwgOLORgnlNgbhZaHQZfvOvaTzmfiJGdHnHYsMRqfyChpjBWvLGKwMDlRDtidIHBjNNpmyfMdIcARRwqnXnvnrcMOfyzKqnPtPUKudtOdabjokcCXyvSnnXmisFysXKlFQgiaptnBuYANAgaNaipfJbYEmJPcAkqYTCcgQNJHvWONaoCaKhCL")) {
        for (int yxqVtUVKNxKeBtp = 647244759; yxqVtUVKNxKeBtp > 0; yxqVtUVKNxKeBtp--) {
            OPGnLZnezK += XiwGMySGW;
            MMYjfSKRESs = OPGnLZnezK;
        }
    }

    return GbthKkeJBYXPJ;
}

void zQTRJBWzkKoJYCUc::KOOpTIXFDtlJxpK(int oTqvBoZNejxSB, string QUaFrpb, int saTJX, double dPPQcwtQK)
{
    int NqFcG = 704492611;
    double NjOUVeBgtfVuEMVx = -539900.7900259262;
    int tIIXkhotgmU = -1698070567;
}

void zQTRJBWzkKoJYCUc::erhOYj(int OLHmmLk)
{
    string dzgqm = string("bSmIzVYmLaTWWQxFqaXvvopKajQwvKdbdWfFhfjBDsNunUmvZnNZhQVcVCwCuqdjEyYrSsUUtmfLfbsotMRCtlRoNxpffuQJmAobEhsUuPahTbiyiFyxcUzAikeYlaXrFIHTxpKnBhCqfvPHiZZzFH");
}

bool zQTRJBWzkKoJYCUc::FmnBE(string NgIGIhXGTlEW, string UMkINNFeM, bool MwWPGm)
{
    string WMnbcbWQGUq = string("lTuUtUIgvXNKVQEzCIpnXqMqNxlZwJpOtOvyCDGEWRaqIVvUMHPwhYukZIVQBbMZTRRLNOfqZNXOtcQVwpwmSLjoCZ");
    bool HhhxJrgM = false;
    string xsszWon = string("qwToCgpRqWxeIdfNZRdXQVnCufxkOxkMhVRhOJSLSPocRAGBiNfaTjBpENmMQcnQHGARDiabfXkFXaKuXbcwFCLvWgDOPHbSjHpmJjUpzeMpqRTFuCnLAMUmcuMEaeWTjXwpDEPnFjfUBPAKsfsIiVWgWYekQooptXNFFy");
    int opZHYIyd = -65306635;
    double RbBlHH = 569207.037036875;

    if (WMnbcbWQGUq >= string("KeDUjJAnLvSFtnMOcvsgEFelcOokMWfHWlfQd")) {
        for (int XkGcULQNocNWh = 1841899919; XkGcULQNocNWh > 0; XkGcULQNocNWh--) {
            xsszWon = xsszWon;
        }
    }

    return HhhxJrgM;
}

string zQTRJBWzkKoJYCUc::rZigKhoc()
{
    string flTayoujxogFB = string("GNpWywJtTRWdtGvWdkVvoirzlpBlGBjLamnvWcgOvRAZzZcrxqDuoElwmdatcLdobNWBVJQSZwkJvjHfvcVHdNLNYdvVYWWVLonmwPwwEVEocBPBpQZVjphcYjCMxdkKFdXEavLuakNuDjvcWRtwjYeiYmheAfvqAUPpYGVXQbGHGFBDRKUmSsXSSTqIarErECnCxpYcwhblUFnFpDuDunWKjABFTpLEi");
    double PmuUHxPf = 825472.6398113578;
    string OEmCdzsXR = string("DICniUIunYvaQmNMSYPQbsjlcbdCxaKMqMgBxFBbchUShhUeqHVkZcGNgTcAQfnt");
    double QCGMGtOexBXHk = 630704.1950855532;
    string BFzWuoJNpcMAUv = string("xcwhDpElljqqkEUDXfMhsyGbsfmSXbaJnbxGAYYJOTZAuaXVhjhGeGiCQbeQTUEHGEXkGXTlSpVfCpLAqnAvVRoZCKZPBNnsIJEhhTIuvIlcpAyHFrQrKCcAdrGStpSyqIOnAPxuDKUUGgeFsFAqPHrGarhhMQMpOaMqFrWIbxOfwSBuJyGqsKQl");
    bool RBquC = true;
    string FXWpmLxhLwmhVr = string("kvVNAxJrLUIedrJeqHrjzRqRVxgeFsJvKoKTuZIxCbuSIUFfjYXfEQqbpKYhweQzvNAtwXlhwsIjQkfPXwOiZXwkzdggfiGeBsSbYvirLzoPXrqWaFdHveRprLZXGlyIUCFDRvTHGSpIvpHsYTKtgqWbyVUzTckmrwaxDCMkannAObDRHvdlfojhopfbwbJFtHOXkFjalVOxISLImReCOOzPcOXYVPENFZQzKcNis");
    bool xfesaf = false;

    for (int vRCaJxTT = 1046448779; vRCaJxTT > 0; vRCaJxTT--) {
        flTayoujxogFB = BFzWuoJNpcMAUv;
    }

    for (int etKIecOYW = 286873429; etKIecOYW > 0; etKIecOYW--) {
        continue;
    }

    return FXWpmLxhLwmhVr;
}

int zQTRJBWzkKoJYCUc::vJVWhYruIZWQJBGA()
{
    bool fvkzjTpfxfW = false;
    double sgRhTeYueGLEW = -350770.21036248945;
    bool qpNZlFqGVNRXq = true;
    string OOlYOmmtMSr = string("nyfMdPcVHGgOGObARmgcPUBMUkdhXtgzLAOyAFURPyWEsWidiWSsVVjC");
    int iQJVyxVWdZiezd = 206597616;
    string YVAeFEpEarSpABYc = string("zZfipcgKRPbVnvuUkrifDzETOLGHlLyBlTjysJxqUuXWXUCCMeCVQIexrmXuroqCtwCQLyJcpWpNRcIrszfJrICLAiAnGxEVzSHdiGYGblzVMNryZEQOEFObTuBBBOeSXYRUKwDnVboloOjqGPmsOAklgriXCSNVIOskAAHKXuKzgRccosRcdgDQTBKwvFPyPcMUlYtZxfWKVlIuvinSwvEpSXnNrx");
    bool SaWjowTdiRLgOYi = false;

    if (sgRhTeYueGLEW >= -350770.21036248945) {
        for (int xZmhERgfhrg = 161091386; xZmhERgfhrg > 0; xZmhERgfhrg--) {
            continue;
        }
    }

    return iQJVyxVWdZiezd;
}

bool zQTRJBWzkKoJYCUc::NdSuwPwaxKbV(bool LLXlQIcAxBV, double xWDtXJhyXsGod, bool NkyygIUaa, int ihDwlDxUiSRWSdBo)
{
    double CgEoYgPHQ = 684194.0356664148;
    double IuLwCaF = -956874.4532987204;
    double RCUEMcicaH = 432499.6658146204;
    int fhBPwsSYQ = -1019149801;

    return NkyygIUaa;
}

double zQTRJBWzkKoJYCUc::NMOkQki(int yUKLyLFymDYTH, double xeeHA, double cHUzhTD, bool fSsOTtpVTOLtZdj)
{
    int bjJhygQHWNycHHDU = 1282061123;
    double STTqMMLfzHeUq = -1008637.4477136234;
    double yUPkHoECglb = -659019.2148682664;
    int COXagXb = -130592424;
    bool wUOUOS = true;
    double OKiHirgI = -632308.0444042824;

    if (cHUzhTD <= -632308.0444042824) {
        for (int WZqNzrcu = 1745444744; WZqNzrcu > 0; WZqNzrcu--) {
            bjJhygQHWNycHHDU += bjJhygQHWNycHHDU;
            xeeHA = yUPkHoECglb;
            cHUzhTD += OKiHirgI;
        }
    }

    for (int CCemIo = 1419284463; CCemIo > 0; CCemIo--) {
        continue;
    }

    for (int yANAOGxGIGNF = 570039981; yANAOGxGIGNF > 0; yANAOGxGIGNF--) {
        OKiHirgI += OKiHirgI;
        cHUzhTD -= OKiHirgI;
        OKiHirgI -= OKiHirgI;
    }

    return OKiHirgI;
}

string zQTRJBWzkKoJYCUc::AYWUdBK(bool WcMuSfm)
{
    string aAUOFCTHLUZyKpG = string("oawVyGNk");
    int QGqgonmJrcTlL = -1145797596;
    double RJYjGeBiJKZ = -358753.3174978603;
    bool WxeOxiZndME = true;
    double lolgI = 923174.5979749536;
    string CDUckT = string("tonhcdbb");
    bool xZtLhJPGg = false;
    bool PIuLYfSYV = true;

    for (int MHvDcOiJs = 1523631654; MHvDcOiJs > 0; MHvDcOiJs--) {
        lolgI = lolgI;
        lolgI -= RJYjGeBiJKZ;
        xZtLhJPGg = xZtLhJPGg;
        xZtLhJPGg = PIuLYfSYV;
    }

    if (xZtLhJPGg != false) {
        for (int Yetff = 869996896; Yetff > 0; Yetff--) {
            CDUckT += aAUOFCTHLUZyKpG;
            PIuLYfSYV = ! xZtLhJPGg;
        }
    }

    for (int SJFXtoWUeGDOQHSi = 1393062808; SJFXtoWUeGDOQHSi > 0; SJFXtoWUeGDOQHSi--) {
        RJYjGeBiJKZ /= RJYjGeBiJKZ;
    }

    return CDUckT;
}

int zQTRJBWzkKoJYCUc::mjDUzdt(double VdGhFoY, bool RKfRUKRZwmRWNP, int imLIYTBuFjRsKuny)
{
    int ynqPVSfj = -244406152;
    string DyMmAsfoZcnUmD = string("algPkDWhCC");
    int cMUwcqMSXQJGGXL = 193826446;
    double kDwXVaY = 751920.1482871729;
    double lMIXCIykhHpIPK = -671195.1699240553;
    bool qcblemYNmHFB = true;
    string bFUDuPvBYCgCe = string("mRwtOyitpDgNAGyCnIPqsjUqkovVCLbftMqoGbhUkgwsnOpQViQPhCHHpaviQTohxFtSLX");
    int uOEAWozZE = 708484959;

    for (int AYHSxjAQQ = 58601844; AYHSxjAQQ > 0; AYHSxjAQQ--) {
        lMIXCIykhHpIPK /= lMIXCIykhHpIPK;
    }

    for (int dVBdFbiBEFFw = 718490475; dVBdFbiBEFFw > 0; dVBdFbiBEFFw--) {
        uOEAWozZE /= ynqPVSfj;
        uOEAWozZE -= uOEAWozZE;
        uOEAWozZE = ynqPVSfj;
    }

    return uOEAWozZE;
}

double zQTRJBWzkKoJYCUc::xHiBRySospXpB(int rgjQH, bool LiznhFcogcHm, int CEtHSCPKcBUol, double sqCrNq)
{
    string GiRRrTPJOfvxH = string("GmJmwMmVfKNbDFGaSyIoTkkOfYOLvXLzMvKNraDFAegIwuZsecBAnjjxcUGwcSAomEWRJlpiEnSriFRYjiabBTvwZtKsRHobKzZePdbUMGPfKDdguqNXtsyqNyONeExLEhg");
    bool OKuTZXhGvN = false;
    bool BzFomYWl = true;
    bool QjBJavoqhaBxWtpw = true;
    bool GLFauGjDZpFE = false;
    string GRdDAwLUY = string("WEWoCTxfuSsjXGxcUarnuexejJnsHpYjlAUmHNBjIqasXZYuufPQBemgQqsKduByCcCytrhCAphDAEAqRqAyrXyzoUnadRJUgUTErnFuEMXWpqZzQXeezKZIKtkQzHirvcNvwLaTdFzOwIEXxsOxsgrWENuCjxAdbXNXsZwoxjIgEAZNgSwbhTThOdSnnoCZsEmChhEkIpYjciazWmhVEYfYceaKQlLRiDqkQi");
    string VEYpkLmjhX = string("iyCYqoLzRBmYImFhUoVACoDKegfqPFBpsaBQBKNtAmCTbveQFJKDeKNtWwEIRDGYTJGBbXIuICMPRtPfpkkFjBnJuOOfSuQyPBKsyWDFuZJmVmTNrkxPklZkrTxZqPMdrITbVcLrHPjpfNcSYqkBmuciCVvaUAMaliwrqonvNlnrXJsTYoUjPIzggEJAFkiqVcjFVdRFcFbWguBBRJQPWprAluzNprvQyGGKHVGVaGSAwFjonMP");

    for (int uZOGUsjxORKygPri = 414352350; uZOGUsjxORKygPri > 0; uZOGUsjxORKygPri--) {
        continue;
    }

    for (int yrLantLo = 2078307382; yrLantLo > 0; yrLantLo--) {
        OKuTZXhGvN = GLFauGjDZpFE;
        QjBJavoqhaBxWtpw = GLFauGjDZpFE;
        VEYpkLmjhX = GRdDAwLUY;
        LiznhFcogcHm = LiznhFcogcHm;
    }

    for (int VsOhdXL = 932117114; VsOhdXL > 0; VsOhdXL--) {
        GLFauGjDZpFE = ! OKuTZXhGvN;
    }

    if (OKuTZXhGvN != false) {
        for (int UyuOsTbHdAMR = 1028298179; UyuOsTbHdAMR > 0; UyuOsTbHdAMR--) {
            GRdDAwLUY = GRdDAwLUY;
            LiznhFcogcHm = ! LiznhFcogcHm;
        }
    }

    return sqCrNq;
}

void zQTRJBWzkKoJYCUc::rzGBDURoH()
{
    double NdgWT = -870020.1199614571;

    if (NdgWT == -870020.1199614571) {
        for (int xtFhVEeHFxItQFk = 2046066184; xtFhVEeHFxItQFk > 0; xtFhVEeHFxItQFk--) {
            NdgWT *= NdgWT;
        }
    }
}

int zQTRJBWzkKoJYCUc::ZvRkZotm(int ZHAhMWKnGLYccfre, bool XEnHimwIseN)
{
    double cSTcNJbKMdwZrXQp = -200603.51734773663;
    double WTyNJC = 874476.1892094185;
    double evCSloZ = -985574.448153462;
    string ciEDLKdgdy = string("fNPsHGvpTQzXVPLugNPXGdEkMGzOaSRkxR");
    string stATTn = string("TIvyrdSCORIStcezPrUwLZxkKYklaeJMyDTrRCUshONRBrOwrJQjCHzmpoNsevxGVNSCV");
    bool sLpKCwlKyQyYwwa = true;

    for (int BcpbHUkNE = 370031991; BcpbHUkNE > 0; BcpbHUkNE--) {
        continue;
    }

    for (int rrnecWCxcD = 324267564; rrnecWCxcD > 0; rrnecWCxcD--) {
        stATTn += ciEDLKdgdy;
        evCSloZ += cSTcNJbKMdwZrXQp;
    }

    for (int vewLYGz = 1365870356; vewLYGz > 0; vewLYGz--) {
        evCSloZ += WTyNJC;
        stATTn = ciEDLKdgdy;
        cSTcNJbKMdwZrXQp /= WTyNJC;
    }

    for (int QnWKWuKCqCIqB = 1792185811; QnWKWuKCqCIqB > 0; QnWKWuKCqCIqB--) {
        stATTn = ciEDLKdgdy;
    }

    for (int NxdzqdApR = 334776561; NxdzqdApR > 0; NxdzqdApR--) {
        WTyNJC -= cSTcNJbKMdwZrXQp;
        evCSloZ = WTyNJC;
    }

    return ZHAhMWKnGLYccfre;
}

int zQTRJBWzkKoJYCUc::aeQXZkBdWnTSMHB(string HXluGGo, bool cKXzGUWJu, int fiSKdJ)
{
    string QuvYWmAYDVHjazA = string("ePPWsHRJrGFnKguVusfuWUUByHTqxtwRGkYYLeEcWXrTyUcBPdyJmgtNBhdhhYDbedjgkHgWpJbqGGNyoWjZSBntHASerckokzZBkJcIQEPErLQLWnGAvEMkdYOjHhpJhTnQPLKetKCADPBu");
    double yJStgPLOvffuxN = 904923.2654537928;
    bool WidAVuaWOzmwMln = true;
    string ipZogXYhkaXRbR = string("FnbVyZKCCnIVXzVtXAgGMvLTAkjfHlTQZtnSKuAobIOYGMBihhygOzJkeScjptNQCVNLiBMLvLkLjAJrDvOjDTPKkhWSHbnWqqgaNYRjcdBsLPKtxyiMasSlkvYmeIpJJ");
    string gSkebhNFlqBjv = string("VSUJGwwTUmKqbTzsthUDyvQQyIwnlXLrMAnsOwzWaNSaSvohoRIvwTSNFgDvJfTaBYWVVLtvBMphPICDzSOtoXfwuMNRKYpFGbXAhDQQyvBOdMmeFlWjTGuqnwzmfGmqscyhatIojNoVRkRywRmPranVASAHvblQuFiAjtzXkCtbfEHMeOrxBqbIiToZW");
    int MwSoSHNFCpaqIUxj = -1736793312;
    bool BFTpI = false;
    bool sLzefhPL = true;
    string ZLEqCFBeGkfYYCeW = string("ZSfiRDxaGToYWyVWXUGCLwTfuKDiSiLpZjstFmASFRiSZJqyHibuuKC");
    double VyyCpXiJGE = 949435.6301053116;

    for (int isoVML = 1793075257; isoVML > 0; isoVML--) {
        BFTpI = ! sLzefhPL;
        yJStgPLOvffuxN += VyyCpXiJGE;
        ZLEqCFBeGkfYYCeW = HXluGGo;
        gSkebhNFlqBjv = ZLEqCFBeGkfYYCeW;
    }

    if (sLzefhPL != true) {
        for (int WAPfJWcFPQq = 1411441851; WAPfJWcFPQq > 0; WAPfJWcFPQq--) {
            ipZogXYhkaXRbR += ZLEqCFBeGkfYYCeW;
        }
    }

    for (int xDVAhrhDAhToyhu = 1105437723; xDVAhrhDAhToyhu > 0; xDVAhrhDAhToyhu--) {
        ZLEqCFBeGkfYYCeW += gSkebhNFlqBjv;
        sLzefhPL = cKXzGUWJu;
    }

    for (int ISKuR = 1347663953; ISKuR > 0; ISKuR--) {
        continue;
    }

    for (int KTuIfiHiSy = 166645082; KTuIfiHiSy > 0; KTuIfiHiSy--) {
        cKXzGUWJu = BFTpI;
    }

    for (int FVKQNTbUUUYshqEJ = 908208021; FVKQNTbUUUYshqEJ > 0; FVKQNTbUUUYshqEJ--) {
        gSkebhNFlqBjv = ZLEqCFBeGkfYYCeW;
        gSkebhNFlqBjv = HXluGGo;
        gSkebhNFlqBjv += ZLEqCFBeGkfYYCeW;
        ipZogXYhkaXRbR = ipZogXYhkaXRbR;
    }

    return MwSoSHNFCpaqIUxj;
}

zQTRJBWzkKoJYCUc::zQTRJBWzkKoJYCUc()
{
    this->becuGNaePa(-31253.32287195955, false);
    this->mLYrWNZnXSY(37417977);
    this->sUVSUQ(246397888, string("ythaHylaiuDsAwIvtibeRIHGEwKjiAFEIIGODvmKjrfTGqgpRSaRYkXASosSHPstNQzsvAVwkinMtMdaHyEOOagqPJEOKVxrqmHrXcNvoPapVhkIGMVXzuZDbApShOUXNXAreVEMzFqjCbiOWlYsCbIAxosFyLTuFoRDUInaxduxrqqfDhocvlCFsXWdDgmwZUGxrbuvKHauwvbAbYMtjasXThDSiUyHQtzQXrvGESzfjxlfVHTLPYuXXZq"), true, string("tSnUTMWkpzfPzVCwgOmRHRUOkqrprrtmjiusKLKhuGxsGUXApoJsOEymZunsjcLNIiQMCCBBvYgzjrxnmQmkiCQTgHoCstLfHTSINTVogcjMWaUPIrlQvIWpqlhfCWLiCnWIVMmewiwUxpWdjdHRIrKFsPPCmmYYiPWZbRPUX"), -531199.5790033973);
    this->KOOpTIXFDtlJxpK(-1581463256, string("wYgHOaGZltmdZCsTOxPQNnoVbKLgaMZfIcnGwWbLpFbMbhjprAtAlYelhYGDYjUDBBFNcwxcawqrlPUSajExIYPZOHoUJiOrVjAxbduqlfUKbMVTOzuWKEJOLTOLHUDqxEUXdPDrHRnLYmiPGrKzSNZdtjSkvKfyIzNgzEEIcXFcLxVcuUGFvjnJIBkYEpryzqyrdBRXLJDfeGKwxIFbMxwJnZgHVPAAJaIXNQUcTNCUsBghpNyWFC"), -1178258095, 902808.5757762479);
    this->erhOYj(-550111640);
    this->FmnBE(string("KeDUjJAnLvSFtnMOcvsgEFelcOokMWfHWlfQd"), string("bSiKltWmVVytVFDDEBaTZALtkRxDcGYafEYRjAPyJSDosLBenGtNkftasxuRfzLwCcewLGsIZsxmYmQDEishXrsfRAMRlTGjZIDfeVrZEdjLwHEIYIFOkMCVKQhazlkQCsbBDyidBOdhdKVaZSWEpvDPQagOYrXXzamyRxOvOpissFwDafdBxIuRXpblopdMcUtwzkIqvaMvpAxdfFhjqFGWSXEytNIpjpLpIqGYrvwqildPVSfq"), true);
    this->rZigKhoc();
    this->vJVWhYruIZWQJBGA();
    this->NdSuwPwaxKbV(false, 361791.3644813977, true, -1489555141);
    this->NMOkQki(-24760844, -761540.3884716062, 655252.1907337063, true);
    this->AYWUdBK(false);
    this->mjDUzdt(-696531.6368241659, false, 880672832);
    this->xHiBRySospXpB(-147888155, true, -1221127232, 214791.99806971027);
    this->rzGBDURoH();
    this->ZvRkZotm(-1429485093, true);
    this->aeQXZkBdWnTSMHB(string("OIGyLpplneOBloAboaQHVfoRSsDIlGryEwUgiZvjqPKKpPbPaQtUkigdDhWIDABWipxhUZjucQfhOfQqibzvJeAHvQJPiavMzjXgcsLQxgxUoMmlcrqygEKLmVjWLWefWoDNzJfLZyukDmrmRwAHLmIezPLQEgAiehEZriWacYFxOnozCNGsAbRXGVvDFDAdcTqURKsNbV"), false, 1468512186);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XYesfKREZyFhKn
{
public:
    bool ZNSxcudbTAzH;
    string yNnjnNuld;
    int ImCheGgz;
    string nVFTWvrn;
    double YukbIGL;

    XYesfKREZyFhKn();
    bool LkajT(double ZHNqTPIN, double vzhIyPmUmR, double BgpZRGyHtcjt, double kYyEfDB, string wmYvMcbke);
    int hWCZHBWYdVi(bool ynSRrMwuhWeEZt);
    string cmJzMJaVtaiF(int DQxtrFrmDyZmL, int Fqnrg);
    int ZYfJEjwizx();
    void KmzyhzXpxTPys(int uXkKzwkaeFTRWl, bool LcrpT, string klNNGXlJwU, bool NYZAimzBq);
    void ersVKcr(bool XwuqFH, double HSZlToOqF, bool KHOip);
protected:
    double ShFYDSBKF;

    bool HgXABUActqqhQPeg(double wgcqRoyx, string ScaobYxZWRUuO);
    bool eqENxSnq(double KjRDMUH, int mtzjGmysMBx, bool XgoattVirBeDq, double AYbEKOYxgYdzt, bool BuGwYs);
    void WfVYYnvsG(int kpBhEtyhHHtQk, bool LNPGVKVBZBAhQ, int lwzBviUmtiwnTVlo, string CLpeKtYkiY, bool VVBdKVQQq);
    double WIEspecCDiBCVuF();
private:
    string jeIXR;
    bool PyYjJDhpyxTAEHb;
    string jTOkFBQjoAXVJXO;
    int rVoAgtdsiZia;
    bool AQwbkfiHCQWmthU;
    int mhhPwNKeioTZmvlt;

    int fnPclne(bool yWfLxlCNBhcZ);
    string QuygpDArJ(bool TFOLDgXqoeneXBAV, int XKcNiwbDDXmO, int cEsoE, bool mKvXPHW);
    int MREJkSs();
    bool LMjtzqBQuC(double UDonGnhaCUUYpHW);
    void PqJVWD(double waxACbKVPB, bool XIxfe, bool HKRoxFfnhmzCX, bool xONWukef);
};

bool XYesfKREZyFhKn::LkajT(double ZHNqTPIN, double vzhIyPmUmR, double BgpZRGyHtcjt, double kYyEfDB, string wmYvMcbke)
{
    bool JvpZqYWn = true;
    int agoqyk = 1430354531;
    int xChSojPDnkf = 1446281766;
    bool ZioygSuess = true;
    string ZpRUqcvqNOtKazxE = string("DdWGzyeZPOuAbTmAJtiCZxLHLzYRsrEBCNIPgEYkNURflKeLXfgQpBPPFgVnSCrnxDnQifHHqnZrQYyBPomxMdIPpFAFcVcRblZQKQTfkpoNswtcUzWXZCAtKcBmDzrryPhXaSFPNuibZcJOXwSIICifBetSUzdSzvOnphnIvxGTvHakzIABJXdZDjaMYMwSbyABQfGSWxDzJBdoCATlirziMOFWrEOjvyZjtgVQxbjWz");
    int QRPGjabv = 896775366;
    int KmNMAhO = 544281054;
    string GpMfbE = string("SWQVTOAuonxOmKtvwfPIIzbdTCsRDhZGUpzgwcpbYYbaIDKCqdmapFavxmHoEeRyQhedLSXzfJYWYxCxxwDipLKwiiOTdOqDakIDcAiYEzLPbjWBFRhrUMUBzzEWZADUgMQdvcILgJHByVgFSZAcaQyKrQslaaeGTgZcRTlVyBA");
    int IBNup = -812798011;
    string AosFCdr = string("VmaeIGAlCmfcblJbbydQvywcWTdIpCVAoEmUyYYUEoNAzBFLLUXhLCjMLHhvNzywshxfBLzxajArypywQlSzWyRUAYzeGuLjMjAK");

    for (int IVhxT = 764525184; IVhxT > 0; IVhxT--) {
        agoqyk *= IBNup;
        QRPGjabv *= IBNup;
        ZpRUqcvqNOtKazxE += GpMfbE;
    }

    for (int CmGjD = 1445163548; CmGjD > 0; CmGjD--) {
        vzhIyPmUmR -= kYyEfDB;
        vzhIyPmUmR = BgpZRGyHtcjt;
    }

    if (KmNMAhO > 1446281766) {
        for (int vthXIIlqLqQPHtlw = 1309241800; vthXIIlqLqQPHtlw > 0; vthXIIlqLqQPHtlw--) {
            continue;
        }
    }

    for (int psCGvhLulCHOg = 1867155752; psCGvhLulCHOg > 0; psCGvhLulCHOg--) {
        ZHNqTPIN -= ZHNqTPIN;
        ZpRUqcvqNOtKazxE += GpMfbE;
    }

    for (int AmmPWZI = 764898191; AmmPWZI > 0; AmmPWZI--) {
        continue;
    }

    return ZioygSuess;
}

int XYesfKREZyFhKn::hWCZHBWYdVi(bool ynSRrMwuhWeEZt)
{
    bool BCxjEgQPTdxNlfz = true;
    double OShSLRiLhwfQQhR = 324591.3029901339;
    double LZZrTlYfPWsIxu = -920323.7646741373;

    if (LZZrTlYfPWsIxu == -920323.7646741373) {
        for (int NVVkvsIjFHfWIJf = 657488221; NVVkvsIjFHfWIJf > 0; NVVkvsIjFHfWIJf--) {
            ynSRrMwuhWeEZt = ! ynSRrMwuhWeEZt;
            ynSRrMwuhWeEZt = BCxjEgQPTdxNlfz;
            BCxjEgQPTdxNlfz = ynSRrMwuhWeEZt;
            OShSLRiLhwfQQhR = LZZrTlYfPWsIxu;
            ynSRrMwuhWeEZt = ! ynSRrMwuhWeEZt;
        }
    }

    for (int WoKslPCn = 1643892393; WoKslPCn > 0; WoKslPCn--) {
        LZZrTlYfPWsIxu += OShSLRiLhwfQQhR;
        BCxjEgQPTdxNlfz = ! BCxjEgQPTdxNlfz;
        LZZrTlYfPWsIxu /= LZZrTlYfPWsIxu;
    }

    for (int ccaZmvm = 516321741; ccaZmvm > 0; ccaZmvm--) {
        LZZrTlYfPWsIxu += OShSLRiLhwfQQhR;
    }

    return 1243380722;
}

string XYesfKREZyFhKn::cmJzMJaVtaiF(int DQxtrFrmDyZmL, int Fqnrg)
{
    bool mjBNz = true;
    double ouSlPSxfEUsxdkmF = 123652.54443797529;
    string fAqbAofSPiLMzX = string("pujsSeamAVrqttuHhwNwQrYjSXKTkGSzdsgBRgTERUBDHyHVgoPjGOgTsUDXitPXVPLlninLNjimUIiPccnRrazftmOdHsGyuwQJjEbWgpunxeqjacvlXYXuksI");
    int oXAEPXTKl = 424164010;
    bool wwRjkeD = false;
    bool zmUELJvHzYomy = true;

    for (int kHWSnoByZ = 2061389375; kHWSnoByZ > 0; kHWSnoByZ--) {
        fAqbAofSPiLMzX = fAqbAofSPiLMzX;
        DQxtrFrmDyZmL += Fqnrg;
        fAqbAofSPiLMzX = fAqbAofSPiLMzX;
        DQxtrFrmDyZmL = oXAEPXTKl;
        mjBNz = ! zmUELJvHzYomy;
        DQxtrFrmDyZmL -= oXAEPXTKl;
    }

    return fAqbAofSPiLMzX;
}

int XYesfKREZyFhKn::ZYfJEjwizx()
{
    double hwIEZNYfrVCtVO = -957174.3290510573;
    double CqrBOxFmVnknx = 209846.71803668435;
    int tANdTcdKLe = 2144064405;
    string RxncvdOpIEiH = string("DeiCVnrQjLAwmdVjLdnIuLbXYLNpZDLllFKARsFTSedhYXOiPlIEuYIXJLGFqqYnUjXPcNldcUIAxDEuVQJtvbrjebGMiOGbTIwcYQFfzNVQr");

    for (int DDhMgQj = 402477553; DDhMgQj > 0; DDhMgQj--) {
        continue;
    }

    return tANdTcdKLe;
}

void XYesfKREZyFhKn::KmzyhzXpxTPys(int uXkKzwkaeFTRWl, bool LcrpT, string klNNGXlJwU, bool NYZAimzBq)
{
    bool dsbqVwQ = false;

    if (LcrpT == true) {
        for (int rbAPH = 710582507; rbAPH > 0; rbAPH--) {
            dsbqVwQ = ! NYZAimzBq;
            uXkKzwkaeFTRWl -= uXkKzwkaeFTRWl;
        }
    }

    for (int xjENqAxgGmAO = 1371184180; xjENqAxgGmAO > 0; xjENqAxgGmAO--) {
        LcrpT = NYZAimzBq;
    }

    for (int ZuDXavxOKv = 647165797; ZuDXavxOKv > 0; ZuDXavxOKv--) {
        LcrpT = ! LcrpT;
        NYZAimzBq = ! dsbqVwQ;
        NYZAimzBq = dsbqVwQ;
    }
}

void XYesfKREZyFhKn::ersVKcr(bool XwuqFH, double HSZlToOqF, bool KHOip)
{
    bool okrxxuCzTovrOhdj = false;
    int tcAyOAyD = -970815474;
    bool GipLZifYRds = true;
    bool XoQGnblpl = false;
    string QkDto = string("yilrDuXVZkEzwUebEbaeXPsdIJqWWoAhmQNAVQPwQsmrRZkSCfI");
    bool bUZdu = true;
    int TiUUbZe = 595649886;

    if (XoQGnblpl != true) {
        for (int AWOJWwhRf = 1272788153; AWOJWwhRf > 0; AWOJWwhRf--) {
            XwuqFH = ! XwuqFH;
            GipLZifYRds = okrxxuCzTovrOhdj;
            XoQGnblpl = KHOip;
            KHOip = ! bUZdu;
        }
    }
}

bool XYesfKREZyFhKn::HgXABUActqqhQPeg(double wgcqRoyx, string ScaobYxZWRUuO)
{
    bool hwCGVRN = false;
    int VbdvqlihG = -1568869237;

    for (int BfZNjgCViA = 1529070565; BfZNjgCViA > 0; BfZNjgCViA--) {
        hwCGVRN = ! hwCGVRN;
        wgcqRoyx = wgcqRoyx;
    }

    for (int NoGEM = 2128260668; NoGEM > 0; NoGEM--) {
        continue;
    }

    for (int jcMlMHScTBfE = 810748508; jcMlMHScTBfE > 0; jcMlMHScTBfE--) {
        ScaobYxZWRUuO = ScaobYxZWRUuO;
        VbdvqlihG *= VbdvqlihG;
    }

    return hwCGVRN;
}

bool XYesfKREZyFhKn::eqENxSnq(double KjRDMUH, int mtzjGmysMBx, bool XgoattVirBeDq, double AYbEKOYxgYdzt, bool BuGwYs)
{
    int DVuPkXPNEJCfi = -1795359034;
    int ZWVPLTJfP = -1070716164;
    string gAKFsPmVonsGUc = string("VlhdvyJhnQdXELjefdsunfmqkMuhWgvBmELwIUDcZxQtfNrzLosKcJecCXxtUEXFVfCjqqkrzeEungKRJHeTxHaRIXvQMZqobvIgVxPxxKtcLahJZaiVhuOAoDTzmqUdUkdHnqNKCqSVnFRAEkBUFNhAApIuWBfTpsjUqSgdzHgQbMiTHeafNLTuqShqLiRwFVZpvcjQHWyjiAcRsCgRzcSCusxlLDtxogSXRcl");
    double trblMyXPzle = 803086.9280650142;
    double OzzLMfzPOygEBh = 881296.7089866882;

    for (int vhowbE = 675953099; vhowbE > 0; vhowbE--) {
        DVuPkXPNEJCfi *= DVuPkXPNEJCfi;
    }

    for (int TvSEXDNcWmIRuhd = 529677762; TvSEXDNcWmIRuhd > 0; TvSEXDNcWmIRuhd--) {
        KjRDMUH -= KjRDMUH;
        DVuPkXPNEJCfi /= mtzjGmysMBx;
    }

    if (ZWVPLTJfP < -1795359034) {
        for (int WoAzXTwi = 291720582; WoAzXTwi > 0; WoAzXTwi--) {
            AYbEKOYxgYdzt = OzzLMfzPOygEBh;
            KjRDMUH *= OzzLMfzPOygEBh;
            trblMyXPzle /= trblMyXPzle;
        }
    }

    for (int TLVSTxSGEWEBKmx = 1878744958; TLVSTxSGEWEBKmx > 0; TLVSTxSGEWEBKmx--) {
        continue;
    }

    return BuGwYs;
}

void XYesfKREZyFhKn::WfVYYnvsG(int kpBhEtyhHHtQk, bool LNPGVKVBZBAhQ, int lwzBviUmtiwnTVlo, string CLpeKtYkiY, bool VVBdKVQQq)
{
    double sowVzfFUtQFPDZ = 552662.2562745942;
    bool SpVSJ = true;
    string tUcmzExeXHATBK = string("fypSWhrjZozCvxmQSHmzczFvctnvfWGwSQzuoxjZqjnvNnvCRMnBaYxPpkQesqtrdUWUOWucFZnnwtSLZAjYtwclRoGNVpAxY");
    string FvccIijNcFW = string("BdMIeEnHnKgtUphVVUAvHhXQkINTtqWDswnkXzJFJFCdUgoeFtUjIObNRicaIKggyyOONsdDnsxPGouuYlLXnzRUKsuWtRRTmrAdSxHtIXeWQufizTjIsTGUMMTUJaQyWDzjvxeBoYdrcwZiTqJROKoYyHDxryqPBkY");
    string AUfCrFDMrVJkW = string("HQXwJcGTiShgGgmlMBzOAOEkIMqDobhXaajNZRqOOErjCfTznVqZmotKgOZUznbSRPyFkRajZdAAOLAKMjZKccihoVCzYXJlpaciEsQvDUBlPwtBRoBsYJDTsFfmQiUaoKgkDugHOGIVkOSPJFTHcDuFAjbIpKAkSHTESUdfdcRmEFdUz");
    double CHEdblbjU = -488908.1244085853;
    bool aNKSSxoudR = true;
    int PMPHOG = -2069844932;

    if (tUcmzExeXHATBK <= string("BdMIeEnHnKgtUphVVUAvHhXQkINTtqWDswnkXzJFJFCdUgoeFtUjIObNRicaIKggyyOONsdDnsxPGouuYlLXnzRUKsuWtRRTmrAdSxHtIXeWQufizTjIsTGUMMTUJaQyWDzjvxeBoYdrcwZiTqJROKoYyHDxryqPBkY")) {
        for (int RNlyjYFJpf = 1263603690; RNlyjYFJpf > 0; RNlyjYFJpf--) {
            CLpeKtYkiY = AUfCrFDMrVJkW;
        }
    }

    for (int PiUdLNzeFPeIK = 1837674406; PiUdLNzeFPeIK > 0; PiUdLNzeFPeIK--) {
        tUcmzExeXHATBK += FvccIijNcFW;
    }

    if (VVBdKVQQq != true) {
        for (int YDvuwiBvSQkSq = 1284276605; YDvuwiBvSQkSq > 0; YDvuwiBvSQkSq--) {
            tUcmzExeXHATBK = CLpeKtYkiY;
        }
    }
}

double XYesfKREZyFhKn::WIEspecCDiBCVuF()
{
    string JCZELQAkxQPt = string("dSFTiqVbcNyGZNJeYdVJMfXMohUdQeyqSCxjUZvtyEJOOqPVjDpZylYLgqMRSnXyqKYuSqMtkhEhGpBzXqiPNGQmuLUrIGeoYJPMJnxOGCyyHrKk");
    int zdNvBYguQhEBK = -534449068;
    string SIcbpJkJphTBCj = string("JmHESAWAKHFZKSUmsiwSlzQiqntjbtYGtocxlsVIdsXqPvMtzroUqrMHPDJHeNmBwGOiMKWbBkIboPfEKwlaHowLVVCmQFZzCdbJglGqGigiOlxUkrkLyZQZaSzSchiLIaCUuTiFFNVpjCxcbFlzzpYfyQDxFFqUpvYwYatgfMZTTlcilUFKGaXpNlPwiudDBxscReHsGoGXYVkXsKoTYseVxVwzqMmGgaeUCqpZQlUuzLnYrUmkZBFvgBlT");
    int lKSuodVSOeUOpWt = 550657477;
    double AbljMwiXAOw = -869051.8950903863;

    for (int YPoInQBJSrfFS = 2117650275; YPoInQBJSrfFS > 0; YPoInQBJSrfFS--) {
        zdNvBYguQhEBK /= lKSuodVSOeUOpWt;
    }

    for (int csvmZyoW = 737405702; csvmZyoW > 0; csvmZyoW--) {
        continue;
    }

    for (int knVhVZpMuNsYI = 446646760; knVhVZpMuNsYI > 0; knVhVZpMuNsYI--) {
        AbljMwiXAOw += AbljMwiXAOw;
        zdNvBYguQhEBK = zdNvBYguQhEBK;
    }

    if (JCZELQAkxQPt < string("JmHESAWAKHFZKSUmsiwSlzQiqntjbtYGtocxlsVIdsXqPvMtzroUqrMHPDJHeNmBwGOiMKWbBkIboPfEKwlaHowLVVCmQFZzCdbJglGqGigiOlxUkrkLyZQZaSzSchiLIaCUuTiFFNVpjCxcbFlzzpYfyQDxFFqUpvYwYatgfMZTTlcilUFKGaXpNlPwiudDBxscReHsGoGXYVkXsKoTYseVxVwzqMmGgaeUCqpZQlUuzLnYrUmkZBFvgBlT")) {
        for (int BNFeifMXA = 1705984870; BNFeifMXA > 0; BNFeifMXA--) {
            AbljMwiXAOw = AbljMwiXAOw;
            JCZELQAkxQPt += JCZELQAkxQPt;
            lKSuodVSOeUOpWt = zdNvBYguQhEBK;
        }
    }

    for (int wXXFOZCJ = 1072479116; wXXFOZCJ > 0; wXXFOZCJ--) {
        JCZELQAkxQPt += JCZELQAkxQPt;
    }

    return AbljMwiXAOw;
}

int XYesfKREZyFhKn::fnPclne(bool yWfLxlCNBhcZ)
{
    string LjLbLuoY = string("RJEWnSpEosTfpRHOXNJGSiUKaHPENhcRnHcOxFqtBjnZTobENFKjIvHwQAyrwCrkZFgmHgJHdTEHYTRlCDuWCVevSMswWMPeyWbdXGddrvaFumdYeJEWDgpYKCIZejhnFUXThoFzrWTzCYBqEslAMRoGpIyBNYNwWRvWIbZHiOYpyOOGsRIxClcAakVTkLygDcOUSCodaLWdmEUOiFgBZPTeNRk");
    double qLPvp = -658327.2862509635;
    string iemDKyUequmcO = string("egdzASGEZOkQNjNcbiYAVNSRsytOWUXTidmjrRSCTFxfpZRXorYLEOiGwAsOuMooXzYJVmGxBwFUMffTUozENTigEDJNTrsMwFrnskfnVtjANQdHtGoTufOnrfqnGzHfNegigpcLtlGsQPTiGNGMbv");
    bool fsfodbnFrVjaIY = true;
    bool nWRwGQneJHrkz = true;
    bool enmni = false;
    bool pVelgzCnUgSqs = true;
    string fOiLZLapTBvKcC = string("oNWdBIxbfbWzRGjKFWvvdiBHcTmRWSMaNJdTxCUYqaZDINSFuhxaCTwGHjOgpvlfBYmXtKMdIEoVLBDHRoOOJivIZrJXuJqoLUOFXschOVAJpRLhZxgZJRfkxCmJcGEvGzgbH");

    for (int MbLRZXk = 151897518; MbLRZXk > 0; MbLRZXk--) {
        fsfodbnFrVjaIY = fsfodbnFrVjaIY;
        LjLbLuoY = LjLbLuoY;
        fOiLZLapTBvKcC += iemDKyUequmcO;
        LjLbLuoY += iemDKyUequmcO;
        enmni = ! fsfodbnFrVjaIY;
    }

    for (int jlUeHYsafLAsAPt = 262362210; jlUeHYsafLAsAPt > 0; jlUeHYsafLAsAPt--) {
        nWRwGQneJHrkz = yWfLxlCNBhcZ;
        fOiLZLapTBvKcC += iemDKyUequmcO;
    }

    for (int PjAjssqywKTBq = 481969423; PjAjssqywKTBq > 0; PjAjssqywKTBq--) {
        pVelgzCnUgSqs = ! yWfLxlCNBhcZ;
        iemDKyUequmcO += iemDKyUequmcO;
        nWRwGQneJHrkz = ! pVelgzCnUgSqs;
        pVelgzCnUgSqs = pVelgzCnUgSqs;
        fsfodbnFrVjaIY = pVelgzCnUgSqs;
    }

    return -421159213;
}

string XYesfKREZyFhKn::QuygpDArJ(bool TFOLDgXqoeneXBAV, int XKcNiwbDDXmO, int cEsoE, bool mKvXPHW)
{
    string yTrftUihVnnuNk = string("cOjcAURxqQvBueAtYhwqJHdGvGECcChIlkRnNtXYxHWnaxlnLVyDbEAUHOYckAISjVSuUbnuwInjlXXrMN");
    bool TrAvGpYGv = true;
    double WuUgt = -514576.5180072768;
    string BQHIbBUDShrV = string("iNOgNLrVsLaKWcFIlSGJNhhqnpMUaxtqZByntJfshBQWrOCANVbQXuvArBtmzCxukGqMDYcCgxZBzILMsuppABgqPFGtKHGjCiCjjilMIJpweoIGhQhXnfUVGfbvHTSBXYbCBLrflaFJeWnARvPkndohFdrAwglgIWdXybHPpWVrSxgsEbedFsuMHDkRkdAXJBjeigymhBgmshOGvRQvgwdhNpZRQuFLCOnBk");
    string POyXywNhoOGx = string("DFCQUrmQZqCIQNJqSTqZaSsHyrOaVQqRfxppSgZdyKjdzpWgxvNaENImpqsNKvqheJxrFpOuranQCqHNqrpEbRMrEjqctQLXisKffhtPkaWCWpoeczZCANBRVJTvLPCqudgAZMjnCtMUQlknfnHwwmOADaYPBgojsykVWNLwYvDzcJpbNNysOwZGNTbmcisKNqRUguPxXgVuZuebLvpccqoqMrr");

    for (int WZuXbvm = 1124985481; WZuXbvm > 0; WZuXbvm--) {
        continue;
    }

    for (int FVccXaq = 2021077212; FVccXaq > 0; FVccXaq--) {
        POyXywNhoOGx += BQHIbBUDShrV;
        BQHIbBUDShrV += BQHIbBUDShrV;
    }

    for (int ZmCGCv = 450048903; ZmCGCv > 0; ZmCGCv--) {
        TrAvGpYGv = TFOLDgXqoeneXBAV;
        BQHIbBUDShrV = POyXywNhoOGx;
    }

    for (int qbXDZ = 628298422; qbXDZ > 0; qbXDZ--) {
        XKcNiwbDDXmO /= cEsoE;
        mKvXPHW = mKvXPHW;
        yTrftUihVnnuNk = yTrftUihVnnuNk;
    }

    if (BQHIbBUDShrV < string("cOjcAURxqQvBueAtYhwqJHdGvGECcChIlkRnNtXYxHWnaxlnLVyDbEAUHOYckAISjVSuUbnuwInjlXXrMN")) {
        for (int aKgGCNwoUIHAWA = 1370035039; aKgGCNwoUIHAWA > 0; aKgGCNwoUIHAWA--) {
            TrAvGpYGv = ! TrAvGpYGv;
        }
    }

    for (int DCXkcdbyhNuW = 1517406666; DCXkcdbyhNuW > 0; DCXkcdbyhNuW--) {
        TFOLDgXqoeneXBAV = ! TFOLDgXqoeneXBAV;
    }

    return POyXywNhoOGx;
}

int XYesfKREZyFhKn::MREJkSs()
{
    double iSxCrJswtAADiesK = 923383.8983167247;

    if (iSxCrJswtAADiesK == 923383.8983167247) {
        for (int igojVUJkfDBFNW = 40966149; igojVUJkfDBFNW > 0; igojVUJkfDBFNW--) {
            iSxCrJswtAADiesK /= iSxCrJswtAADiesK;
            iSxCrJswtAADiesK *= iSxCrJswtAADiesK;
            iSxCrJswtAADiesK -= iSxCrJswtAADiesK;
            iSxCrJswtAADiesK += iSxCrJswtAADiesK;
        }
    }

    return 1882439061;
}

bool XYesfKREZyFhKn::LMjtzqBQuC(double UDonGnhaCUUYpHW)
{
    string uKacJIgRVn = string("yaimNhMcvQljsEKxpnzBMRmRqAnYPpsezvgaiOjqQNuYXmuQyihwACyLJenbbihBCYyYqXQHbdWPsuTbPwkIwTiDlaVkhQsaxNarlqBkWjtlWkSdXhrcWDCBigQhbxgtjQU");
    bool JxpsyjqNeUekJt = false;
    double WVxSpMZoal = -243213.83979634458;
    string uOllBwGbnEmYm = string("sjTHCaEVcrwFMaaOsfelcJSfuEgNhMFKZRFfZrMXXDMNCrIwpEJfgTCxlLMkMCJBuAvzLLeQPHdwZZqCebWsnsTxZutorEnUnWrEIIKrvqqagCKuSGOn");
    int oYInyAjbojK = -1410205341;
    double AWmdvq = -252276.19653807997;
    double PIiHrrjFA = 270292.16627717536;
    string ECuQUZxvxRwN = string("sTxzLGWSsUNBFxErTLCsWdsLdOPcawMTCyDpFFJ");
    string tKVdTdv = string("QhDgMUiCUCixQHzkNWqyebnxtOuHhOtSSnXYphqJUYatcwgGxClQPUSpCKgMTdfSpEIdwkldkNWvvbLieXHedbojrfvpezqSXdgvvwNWGoQMTfsakzwEqSRyuTuIeKjndfhfiwXikUvCAwAdFBgGpzHerVlxCbxuozcISiIsHjdACNYVKxiIzkCnhxnwbnvUB");

    for (int JBrKUKoAOUCGxG = 1350054419; JBrKUKoAOUCGxG > 0; JBrKUKoAOUCGxG--) {
        AWmdvq += WVxSpMZoal;
        tKVdTdv += uKacJIgRVn;
    }

    for (int zRYpDAroAjPwxk = 1651432895; zRYpDAroAjPwxk > 0; zRYpDAroAjPwxk--) {
        oYInyAjbojK += oYInyAjbojK;
        uKacJIgRVn = ECuQUZxvxRwN;
        ECuQUZxvxRwN += tKVdTdv;
    }

    return JxpsyjqNeUekJt;
}

void XYesfKREZyFhKn::PqJVWD(double waxACbKVPB, bool XIxfe, bool HKRoxFfnhmzCX, bool xONWukef)
{
    string MTaUYZhMWDV = string("tnGGrRwsouSBZwlnSHBRwoxbVVIKPiKnrhWoXhoKstUZckhBewBgSeYCKbEOQMBFxbIFaLNWyBiAmhLgBUxtxKWNsllGzzXQcaectMLfAqYYnIJysKXQEnFVrLyryCFGDHUZuAOBltvSTiOsPKRfNgJbLjvvEHUIFaGpEHRCurLaHqAEWVcLNzIDMWYUuEaggt");
    bool DrWEwHFbBfhPCwX = true;
    int yhFFAK = -274895496;

    if (xONWukef != false) {
        for (int BfOQE = 398283812; BfOQE > 0; BfOQE--) {
            DrWEwHFbBfhPCwX = ! XIxfe;
            DrWEwHFbBfhPCwX = ! XIxfe;
            MTaUYZhMWDV = MTaUYZhMWDV;
            MTaUYZhMWDV = MTaUYZhMWDV;
        }
    }

    if (XIxfe != true) {
        for (int HTVDv = 604070781; HTVDv > 0; HTVDv--) {
            HKRoxFfnhmzCX = HKRoxFfnhmzCX;
        }
    }

    if (XIxfe != false) {
        for (int nKBJvle = 207430668; nKBJvle > 0; nKBJvle--) {
            DrWEwHFbBfhPCwX = ! xONWukef;
            XIxfe = DrWEwHFbBfhPCwX;
            xONWukef = ! DrWEwHFbBfhPCwX;
        }
    }

    for (int rbTfdF = 960170138; rbTfdF > 0; rbTfdF--) {
        xONWukef = DrWEwHFbBfhPCwX;
    }

    if (waxACbKVPB >= 460271.35254735936) {
        for (int DOaDP = 1309586063; DOaDP > 0; DOaDP--) {
            XIxfe = ! HKRoxFfnhmzCX;
            xONWukef = xONWukef;
            XIxfe = ! DrWEwHFbBfhPCwX;
            DrWEwHFbBfhPCwX = ! XIxfe;
            yhFFAK += yhFFAK;
        }
    }
}

XYesfKREZyFhKn::XYesfKREZyFhKn()
{
    this->LkajT(762403.1522720873, -556307.3092479858, 417515.2112178121, 570734.637838648, string("JKAMrwIPevxLwYJUnEKSveDdbgPqzBETODXRmdptdkDIuZdhIlgflsOvFeJjPZVmjKNRGbfFKlgLHPTFQCJzuWefuXRtiRcsLYIyHRljQCxiqMdWHXDrlPbDTFJUijnsXYuXmfuaXPqPfqHmzfwUONFWnZHyLzhojdMBvLDjWkTGDYksevwouvyiXYVxGId"));
    this->hWCZHBWYdVi(true);
    this->cmJzMJaVtaiF(-1551508904, -440017598);
    this->ZYfJEjwizx();
    this->KmzyhzXpxTPys(1101993997, true, string("uPoswWqFZTmlcBgoEFWwktbFuHpOobnUBIqhNsylhFoLjQMSDbiqwabYGuxWvjgdgoSVWhOAuzENWEEcZJcjzvwevtzpcoXABGlvCJVBhPnu"), true);
    this->ersVKcr(true, -449427.1343176263, true);
    this->HgXABUActqqhQPeg(799439.5018419592, string("IsuPIcuPcbPOroFKCxkTkhbKEUEYXizMxtFxZaXerldGQMLwmCjhvmBrRrwUhHAnjgoTucwaodJssRwNRyocpUBePUqjYTgwQPVmLnRVwpjTrGppaYrHRgRCEOudWISGntFWvLPOVsyEszYINYcjIEQTvwNxaoOODfZgzeFzhLIXQXtHZDGIohngxrFfBiiGo"));
    this->eqENxSnq(45041.76483741608, -644421141, false, 812450.0631105173, true);
    this->WfVYYnvsG(-2121593660, false, -1323089100, string("HULmLTCjFxtkhGJotIzSPCkXbFDxlXSbkIzLTPcsuzAklRWBMjCVmjcbQ"), false);
    this->WIEspecCDiBCVuF();
    this->fnPclne(true);
    this->QuygpDArJ(true, -2058412112, -1633521254, false);
    this->MREJkSs();
    this->LMjtzqBQuC(-1044599.5063323285);
    this->PqJVWD(460271.35254735936, false, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jdLqTr
{
public:
    string tQeCdb;
    string TndNzaGgobMER;

    jdLqTr();
    string mqbKtchiTOTTsont(double rsLhIckirCf);
    int OJqgVKgDBzj(string rJjbQiTYcQXx, string jvChm, double JBAxxIJVGy);
    double MMaTWqO(int mwFnwn, string VXgrDdXLuHlMgvA, bool lhEkIGEQvgMeNA);
    string InaHjYuNyOZRTgQ(string pjUqovcxgdapeZvC, string CZnsooF);
    void AMmUkAU(double SpybGXddYXVK, double nGkaFSklKQvGlyd, string OXbLVYbhwoj, bool HqlqXDff);
    double nWnHHEeY(int gQOhDDBxx, string kKBmyrnDAXK, string WfIpZWXOTJ, bool MzBmYncAU);
protected:
    string JwSTdw;
    int oMTVLgtgRm;
    double MxCtWDE;

    string tJpVhJ(int JJNpHYjh);
    int dZqlyWuhScnPVPR(bool FuLRhTbf, double BfuflGlwuQltql, double QogkYli, string mxsxncebnI);
    void oUmIyg(bool gEuftnPvQPydB);
    int CKrHBAsMoJbCckG(int fMDgv);
    double tZFPXfFKcD(int YOFRCu, int QiiKidRMT, string LksvBKPDPxfLRu);
private:
    string RGQTB;
    string jKcFzlOD;

    bool LEZcbZrtw(string lhYqSRFuAWNtINT, bool LUvYROnT, int hdhtSzTgdMVOl);
    void ZIUgfuleyieI(int VOFvLpbEci, double fXVwXFrWZr);
    bool zOIPqDeeTPBSVfs(bool APfdyPMQD, string VlOJgyfvttdqV, string vTPUtoPIzdpATl);
    double FAlvuJKowr(bool CcJkJ, string JZmCuPOikQypu, int udKdldQXBmlkc, string ZvsOgpJeacTvQFbj);
    double TGHZjIR(double dFHbuIDdhsR, int sHPIfheIZFMA, string cmbNwOYGAf, int wQvuCRYrjCiK, int iGwSdzhpiuq);
};

string jdLqTr::mqbKtchiTOTTsont(double rsLhIckirCf)
{
    bool OCaRaHjhlV = false;
    double oJtHaP = -546549.8103663039;
    bool jZmfi = true;
    bool yjwGJfRshJwt = false;
    int OVhKLoRp = -512510054;

    if (yjwGJfRshJwt == true) {
        for (int fxXOljfnhfyRecpZ = 251618700; fxXOljfnhfyRecpZ > 0; fxXOljfnhfyRecpZ--) {
            rsLhIckirCf /= oJtHaP;
            jZmfi = ! yjwGJfRshJwt;
        }
    }

    for (int bBSKwYMqbJ = 1022706618; bBSKwYMqbJ > 0; bBSKwYMqbJ--) {
        jZmfi = jZmfi;
    }

    return string("PmyQJcWNtKbuCqBkJRJXZWQrbymQNLLalyDOFgpaxnzyvUSKCeGmnrGKwYrPPAxxzYkyLcidhpABhEqItksrhCsisIyEFTrUsOnyPndnvRGfchKxLcLDzEaBaQZvJjoEsIfkjBXGZHIVZL");
}

int jdLqTr::OJqgVKgDBzj(string rJjbQiTYcQXx, string jvChm, double JBAxxIJVGy)
{
    double pDdXojoFsGli = -243454.52903994627;
    double pqUcoCu = -672440.7411801951;
    string OiTcBHmYYnVy = string("RuKmSstYuE");
    bool rnWVwgXUC = false;
    string JHPitQSMRhd = string("qAvxczlyTCjVb");
    double nBjYpYJ = 900952.4990859425;
    double zcSHoYKlrnEZzMQ = 801026.8762562126;
    double cAQryliD = 846774.8970938104;

    for (int GeeRwCp = 871204962; GeeRwCp > 0; GeeRwCp--) {
        nBjYpYJ *= cAQryliD;
    }

    for (int GLBTplieYakgqIz = 483338096; GLBTplieYakgqIz > 0; GLBTplieYakgqIz--) {
        pDdXojoFsGli *= cAQryliD;
        zcSHoYKlrnEZzMQ += cAQryliD;
    }

    for (int mlKje = 1404862778; mlKje > 0; mlKje--) {
        nBjYpYJ -= nBjYpYJ;
    }

    for (int aqrzJ = 489669391; aqrzJ > 0; aqrzJ--) {
        nBjYpYJ /= nBjYpYJ;
    }

    return -612334517;
}

double jdLqTr::MMaTWqO(int mwFnwn, string VXgrDdXLuHlMgvA, bool lhEkIGEQvgMeNA)
{
    double iEbFtk = 829477.3673898996;
    double kQgqqn = 371505.2039913377;
    bool MyrxkHeT = false;

    if (lhEkIGEQvgMeNA != true) {
        for (int JxUrlus = 428535020; JxUrlus > 0; JxUrlus--) {
            continue;
        }
    }

    if (iEbFtk < 371505.2039913377) {
        for (int mBBFHhJrI = 1669868979; mBBFHhJrI > 0; mBBFHhJrI--) {
            iEbFtk -= iEbFtk;
            lhEkIGEQvgMeNA = lhEkIGEQvgMeNA;
        }
    }

    for (int xCgALOxjj = 668244684; xCgALOxjj > 0; xCgALOxjj--) {
        iEbFtk *= kQgqqn;
        MyrxkHeT = ! MyrxkHeT;
    }

    for (int gqvJbFMLgix = 1034968658; gqvJbFMLgix > 0; gqvJbFMLgix--) {
        MyrxkHeT = ! lhEkIGEQvgMeNA;
        kQgqqn += kQgqqn;
    }

    for (int gtdVKZUjvgtK = 972290594; gtdVKZUjvgtK > 0; gtdVKZUjvgtK--) {
        lhEkIGEQvgMeNA = ! MyrxkHeT;
    }

    if (iEbFtk > 829477.3673898996) {
        for (int tSHqAWzOfnMN = 562175824; tSHqAWzOfnMN > 0; tSHqAWzOfnMN--) {
            kQgqqn += iEbFtk;
            VXgrDdXLuHlMgvA = VXgrDdXLuHlMgvA;
            mwFnwn = mwFnwn;
        }
    }

    return kQgqqn;
}

string jdLqTr::InaHjYuNyOZRTgQ(string pjUqovcxgdapeZvC, string CZnsooF)
{
    double BBQCrwjQclZo = 244085.5847871028;
    bool LSNZMWGWL = true;
    bool qpFGmBFuRun = false;
    int ZFutdWipbih = -1392456789;
    bool TfSwYfGAnV = false;
    bool nueuYfRQNSFPPXZ = true;
    double iVFiAMa = 155125.82092070897;

    for (int AjYpNkrZGmPj = 977991404; AjYpNkrZGmPj > 0; AjYpNkrZGmPj--) {
        BBQCrwjQclZo += iVFiAMa;
        qpFGmBFuRun = ! nueuYfRQNSFPPXZ;
        TfSwYfGAnV = TfSwYfGAnV;
    }

    for (int yuKGaoDWYCZbMEdI = 28653852; yuKGaoDWYCZbMEdI > 0; yuKGaoDWYCZbMEdI--) {
        TfSwYfGAnV = nueuYfRQNSFPPXZ;
    }

    if (ZFutdWipbih != -1392456789) {
        for (int GjsTDBIzJRnptg = 1061027505; GjsTDBIzJRnptg > 0; GjsTDBIzJRnptg--) {
            continue;
        }
    }

    return CZnsooF;
}

void jdLqTr::AMmUkAU(double SpybGXddYXVK, double nGkaFSklKQvGlyd, string OXbLVYbhwoj, bool HqlqXDff)
{
    string AVTDgqlLR = string("MjMlhSsZGItNRFXeImvUtyMfIjcgIZVvGaDYpYFnyUQrsLeBRpofrIEizXTrSCFdppHhObEnBvpsNAGKcrpNCIYSlWCEFxxQkhUNqHGwJvGcrDfPBBhUJiAHkYPmrwwHHOoAugZVbTHsAvq");
    int sBdaIUFBCCuwsrX = 304352999;
    bool OsUszvLZxj = true;
    double LBCJu = -607339.6235122517;
    int XwPaXznELMmGkVp = -1962045697;
    double FKuYVjiJllxxXfI = 558911.4031927234;
    double cvJdtNlpokU = -827953.0279783149;

    for (int aecEBRIPsIL = 1603719233; aecEBRIPsIL > 0; aecEBRIPsIL--) {
        FKuYVjiJllxxXfI /= FKuYVjiJllxxXfI;
    }
}

double jdLqTr::nWnHHEeY(int gQOhDDBxx, string kKBmyrnDAXK, string WfIpZWXOTJ, bool MzBmYncAU)
{
    string UAcvhqhnEwUElDs = string("dBwJrGVbJIMBbBDBNkXKGUDlpyQFESOGUIuwASyIMBoKguGFeEpPfkdTdAifKiIBWdBFsNRtuALPyOUwhzBDZVbwPQfmWbBPfWjHpFgaduUySOss");
    string wWIbdJEuND = string("NbtSlTcUeTnXEkuPwlRdvKNPBIBfajdUxGCaOYJLauFZZiQlcVjvULxtOCIHoJtxVOUMrOghoHAZyCFhpfEKUMcfsAZLwCDDDTsXyJLrsXQahVKQZRFrskcUIAhmLIANEJvZMwyUOTzyOUFbjiNoCgmzLLIiHzRVegodYNBngXEqJcWlPwWoZCCokfmfdwuYMnWHRJdnGEVogeAdGIlvBadOpJYnSVrMPVsAeyLySSSUEfnTUot");
    int qcatORtEDmHRqRMx = 208673071;
    int rkfjiC = 1470806454;
    double yWuwbW = 1037071.167990768;

    for (int LnrQFrOOw = 1056216551; LnrQFrOOw > 0; LnrQFrOOw--) {
        UAcvhqhnEwUElDs = WfIpZWXOTJ;
        kKBmyrnDAXK = UAcvhqhnEwUElDs;
        kKBmyrnDAXK += WfIpZWXOTJ;
        gQOhDDBxx *= qcatORtEDmHRqRMx;
        qcatORtEDmHRqRMx *= gQOhDDBxx;
    }

    if (WfIpZWXOTJ != string("NUNUNmxEuzmjRzDqmyRaBJPyBWJWySdcQjCyDFlngkYmLQBXHrSawlUygbRALUnbrqMKKbGlQPkGHEZZLqpWWxrDqlUSWvtFdIsgPbgPMxRWBSFdGYUbwZsJnrElbirgeuQMmDGkwwyviwgyimEiagHtxmLhiexbf")) {
        for (int GmJVnV = 56821480; GmJVnV > 0; GmJVnV--) {
            rkfjiC = qcatORtEDmHRqRMx;
            kKBmyrnDAXK = kKBmyrnDAXK;
            qcatORtEDmHRqRMx *= rkfjiC;
            UAcvhqhnEwUElDs = UAcvhqhnEwUElDs;
        }
    }

    if (kKBmyrnDAXK != string("lbEJxQKDpsqbKLUqMHlQYznjQmzYkRPajpWCTSAHFfikWiGsbJcxjDQrnxJUdBgSWFKuWCRaGAUzh")) {
        for (int FdeWgujbnm = 963969793; FdeWgujbnm > 0; FdeWgujbnm--) {
            rkfjiC = rkfjiC;
            gQOhDDBxx = rkfjiC;
            gQOhDDBxx /= rkfjiC;
            wWIbdJEuND = kKBmyrnDAXK;
        }
    }

    return yWuwbW;
}

string jdLqTr::tJpVhJ(int JJNpHYjh)
{
    double FSMAfeV = 43541.14214910461;
    string SQBXmvlATgaBPF = string("kRrAPDsuHAuAerKQceuBmwFOFTxKukpnoQMRyqTpmWEApigFgcQaCdbvPvJLtUCuZyFCHdJokwZbUmkBhqBnAxHopSqBdxVPuFQZieSfpSPiZdTKxWMXHDFSylJIuoYftbxLpUeFMnGYKPkcBtwmrSQAy");
    double MtAjigtoSwERap = 601934.0324512544;
    double FNnVsRmTHLSWdxh = -170034.2140351654;
    bool aPDqsmUHczEKud = true;
    bool QlXJhSodl = true;
    bool vJNNwRdsmWlJZcM = true;
    double wwriIvNUDaa = -580818.9417179461;
    string QyaOolvqxhMarjx = string("TebbkFniPBDrSasSyuhisawSmY");
    string fnhyWCg = string("eJBNGVALCsxiXkjjYrzMCBATxzeMiIwfBbOZrzaismWIFUyCNEEglFjdqObNwiPqloKEuLsuGnbAdjfpXlkbDHwAHQpTpTZHPNnASWUZXEqJyUjCkbaopPMIOUvPNOtqKOOIVaxLzLRceUpYFh");

    for (int BODNuWwLGxjaLOR = 1808935958; BODNuWwLGxjaLOR > 0; BODNuWwLGxjaLOR--) {
        MtAjigtoSwERap = FNnVsRmTHLSWdxh;
    }

    for (int kXfMsU = 931228923; kXfMsU > 0; kXfMsU--) {
        FSMAfeV *= MtAjigtoSwERap;
        FNnVsRmTHLSWdxh /= MtAjigtoSwERap;
        SQBXmvlATgaBPF += SQBXmvlATgaBPF;
    }

    for (int gOMBXBCinSbwbw = 6875127; gOMBXBCinSbwbw > 0; gOMBXBCinSbwbw--) {
        wwriIvNUDaa -= FSMAfeV;
    }

    for (int SYxvR = 192183875; SYxvR > 0; SYxvR--) {
        JJNpHYjh *= JJNpHYjh;
    }

    return fnhyWCg;
}

int jdLqTr::dZqlyWuhScnPVPR(bool FuLRhTbf, double BfuflGlwuQltql, double QogkYli, string mxsxncebnI)
{
    int KuykEreJHYqxA = 212749301;
    bool FbfHxYtet = true;
    bool qqhImuyMIgzZNGNR = false;
    bool GsWsTA = true;
    string sQKclzA = string("tcfJTZLcUxbAeloSlMhmlmsyIdQpwoZsujbSMmKLfLjWUBtFUNYBdmfPopevjYUFOYvTtKXrmhcBjLbvOBANdLyCPlssxkoWKnYoWkWpASZTWcpWbgixkWabWduhdrMIsKhqJolPpnG");
    string JxzykqgxFS = string("AcSlNbPRGmIFUdqHhiKhtzxKuWrougAFCHWZxLRkVaECkfBQeiJXLaTDbdHRjqHcYnbPOuUJjYDxoFaYNxGEqzRdkqxofLMnCmdgdeyPhCaPNjLEfcdhgRbusJsLjVRrlbpniLgxkPLBVZqdvhXvAOcDXhmXYRIewFuJqXHriTKoEFKPICwA");
    string QhuuEnZSuHQljVGR = string("pDDDcRkTiFlNAqvkpvOicMRvsUbSUxUohZAVxcgwUNPWAmKqQgeaxfaFoyVaRPubqqBkoVnhMXcDeuNdiZMmrpWfOpoiKhFFWRbTtporXOnalMlNOufoZDMvXSAOX");
    double LMOgmzUi = 355703.8952287488;
    bool eMXSvqRzsJ = false;

    for (int OvortrcYrjUWSNwf = 1075364921; OvortrcYrjUWSNwf > 0; OvortrcYrjUWSNwf--) {
        FbfHxYtet = FbfHxYtet;
    }

    for (int QRXCpveqox = 1700322617; QRXCpveqox > 0; QRXCpveqox--) {
        continue;
    }

    return KuykEreJHYqxA;
}

void jdLqTr::oUmIyg(bool gEuftnPvQPydB)
{
    string lSEqBRecVl = string("hZFOblbcKSUZemhIhjSrLLJwxuqMPYzjUmNuTUYKBgKiSUnKLaxoUNgFGdiXQUQxTbOQpwwRaLOZMCWQeEMTiPdizFGXlcHGdKASFauNzk");
    string ePkLAIkEzYaDeC = string("OqdfcgTcROrHBcIfbRVvvlnuAijXWrPqZzpF");
    string pRPmbBTzemANK = string("yf");

    for (int cDVFIzpAr = 1993805706; cDVFIzpAr > 0; cDVFIzpAr--) {
        ePkLAIkEzYaDeC += pRPmbBTzemANK;
        lSEqBRecVl += ePkLAIkEzYaDeC;
        lSEqBRecVl = ePkLAIkEzYaDeC;
        ePkLAIkEzYaDeC += lSEqBRecVl;
        lSEqBRecVl += ePkLAIkEzYaDeC;
        pRPmbBTzemANK += pRPmbBTzemANK;
    }

    if (gEuftnPvQPydB == true) {
        for (int JGOhoufoZLBQCagR = 559072179; JGOhoufoZLBQCagR > 0; JGOhoufoZLBQCagR--) {
            pRPmbBTzemANK = pRPmbBTzemANK;
            ePkLAIkEzYaDeC = ePkLAIkEzYaDeC;
            ePkLAIkEzYaDeC = pRPmbBTzemANK;
        }
    }

    if (pRPmbBTzemANK < string("hZFOblbcKSUZemhIhjSrLLJwxuqMPYzjUmNuTUYKBgKiSUnKLaxoUNgFGdiXQUQxTbOQpwwRaLOZMCWQeEMTiPdizFGXlcHGdKASFauNzk")) {
        for (int pUZWmIWSDRjcuO = 474350767; pUZWmIWSDRjcuO > 0; pUZWmIWSDRjcuO--) {
            lSEqBRecVl += ePkLAIkEzYaDeC;
            gEuftnPvQPydB = gEuftnPvQPydB;
            ePkLAIkEzYaDeC = lSEqBRecVl;
            ePkLAIkEzYaDeC += pRPmbBTzemANK;
            lSEqBRecVl = pRPmbBTzemANK;
            pRPmbBTzemANK = lSEqBRecVl;
        }
    }

    for (int IqhfRkPvISTquSIH = 1521484445; IqhfRkPvISTquSIH > 0; IqhfRkPvISTquSIH--) {
        pRPmbBTzemANK += lSEqBRecVl;
        ePkLAIkEzYaDeC = lSEqBRecVl;
        ePkLAIkEzYaDeC += lSEqBRecVl;
    }
}

int jdLqTr::CKrHBAsMoJbCckG(int fMDgv)
{
    int tUPKLNHHxZph = -630197324;
    bool IDvnc = false;
    int plDwzpIR = -473224085;
    int LxkbOEtpI = 969595544;
    int vuInsjbzWF = 1876736945;
    double RZVYxB = -780843.2015271424;
    bool CSncome = true;
    double NnWiqNK = -356331.4616333361;
    string eBleo = string("WQZKpgdqMcMLjjBaekkJKgBhDXqeaZSSDcilsArccFbMhNbkHjRGzNNvSDwZRhcfduXOlIcJrfxYsOJfOXliFgJSHsXwPUgcKJrRHGBGBdFYmhwblxYIMGNVHsToorFrVHkghXMesRprgoDVdipdYVdtCsnqgQDNczDftkfqOhTOCjkPhpkM");

    for (int cbhFfksanRMgVnO = 1818107967; cbhFfksanRMgVnO > 0; cbhFfksanRMgVnO--) {
        tUPKLNHHxZph -= tUPKLNHHxZph;
    }

    for (int HxfrukABlArN = 372931918; HxfrukABlArN > 0; HxfrukABlArN--) {
        continue;
    }

    return vuInsjbzWF;
}

double jdLqTr::tZFPXfFKcD(int YOFRCu, int QiiKidRMT, string LksvBKPDPxfLRu)
{
    int McFXhwQlTzvT = 1951333103;
    bool llHpHrjGMUFPW = false;
    int vnvPk = -663366147;
    bool lxliESelMQY = true;
    int ckdGZtsB = 1546503674;
    bool mRcbxcZEBNc = true;
    int XVdhlnBmOz = -1865672005;

    if (XVdhlnBmOz <= 1546503674) {
        for (int TSwXmPKE = 2098618804; TSwXmPKE > 0; TSwXmPKE--) {
            YOFRCu /= YOFRCu;
            vnvPk *= ckdGZtsB;
        }
    }

    for (int gYnLNbJlqyPFDoyU = 1809381460; gYnLNbJlqyPFDoyU > 0; gYnLNbJlqyPFDoyU--) {
        vnvPk = vnvPk;
    }

    return 1026161.3674184554;
}

bool jdLqTr::LEZcbZrtw(string lhYqSRFuAWNtINT, bool LUvYROnT, int hdhtSzTgdMVOl)
{
    int tpirLtUoKpYOY = -1950691811;
    bool wasyZPPcFLyqfpM = false;
    double nNheN = -941393.0767552229;

    if (hdhtSzTgdMVOl > -1950691811) {
        for (int SvdnW = 1270425161; SvdnW > 0; SvdnW--) {
            tpirLtUoKpYOY += hdhtSzTgdMVOl;
            lhYqSRFuAWNtINT += lhYqSRFuAWNtINT;
        }
    }

    return wasyZPPcFLyqfpM;
}

void jdLqTr::ZIUgfuleyieI(int VOFvLpbEci, double fXVwXFrWZr)
{
    bool otzTuPt = true;
    string FPiBas = string("DVgYszwLFVCAnXrzvrMotMbRdvbbzgpleQgthNrigFChGuXDmqSphIgQSWCdjpOBLASdgYfNNlZWpXSAnQvWGSkGhaiVhQOsVtZeoyopkjAcyJuVLJtuFkNvikRXjEfmKtAEfZMfoeaAVSOULASuSVogWWsltvPwAkGuopNDRzgjccGArwsBgPfCQdYkcaePJCDsygGZCWICidAkqVNnszeYRmPslJVfhSdxIxAMGtYxpjYINaMVFOiMfsQxkHO");
    int BgYSFH = -1848763591;
    double tfKpkCSqdMAY = 1010933.0410795816;
    bool KwGJdVOgchwr = false;
    double Zifog = -610733.3130597357;
    int HUffuGMprn = 1557913334;
    string QQVhFAdlxHAF = string("nnHndsxCvNEfzNVLTtILsAnKOQbHfJJgOMJwLnURBDVMWdRLwgVDJqpJhcXZxjHHwcxIrMUaYaQRhuzaJtFDGKnuDYjLDRlMmjuktlVXBXfOqXEDExHozVzRIDVNVDTbrIpXySeEZvZPPOAeyZjzlXtRkysNUmo");

    for (int CmnvgkfaQDlCa = 2052052704; CmnvgkfaQDlCa > 0; CmnvgkfaQDlCa--) {
        continue;
    }

    for (int ZywqK = 54511801; ZywqK > 0; ZywqK--) {
        VOFvLpbEci = BgYSFH;
    }

    for (int RgQCSzxWhUok = 485756795; RgQCSzxWhUok > 0; RgQCSzxWhUok--) {
        otzTuPt = KwGJdVOgchwr;
        tfKpkCSqdMAY *= tfKpkCSqdMAY;
        QQVhFAdlxHAF += FPiBas;
    }

    for (int OzJnlYfveSbJIHB = 510699357; OzJnlYfveSbJIHB > 0; OzJnlYfveSbJIHB--) {
        continue;
    }

    for (int hTxzrZxEXqqi = 668539802; hTxzrZxEXqqi > 0; hTxzrZxEXqqi--) {
        tfKpkCSqdMAY = fXVwXFrWZr;
    }

    for (int NCAlY = 32709921; NCAlY > 0; NCAlY--) {
        Zifog *= tfKpkCSqdMAY;
    }
}

bool jdLqTr::zOIPqDeeTPBSVfs(bool APfdyPMQD, string VlOJgyfvttdqV, string vTPUtoPIzdpATl)
{
    int MRyVHUG = 297433929;

    for (int CyZpdlLKr = 1604264800; CyZpdlLKr > 0; CyZpdlLKr--) {
        vTPUtoPIzdpATl = VlOJgyfvttdqV;
    }

    if (VlOJgyfvttdqV <= string("VK")) {
        for (int tnZBGmMHPCUOuz = 281789012; tnZBGmMHPCUOuz > 0; tnZBGmMHPCUOuz--) {
            APfdyPMQD = ! APfdyPMQD;
            VlOJgyfvttdqV += VlOJgyfvttdqV;
            APfdyPMQD = ! APfdyPMQD;
            VlOJgyfvttdqV = VlOJgyfvttdqV;
            vTPUtoPIzdpATl += VlOJgyfvttdqV;
        }
    }

    for (int ltadrrDcBhSwXx = 1693396316; ltadrrDcBhSwXx > 0; ltadrrDcBhSwXx--) {
        APfdyPMQD = APfdyPMQD;
    }

    if (vTPUtoPIzdpATl == string("AZTdhhSBNSGCWCwqIAxlaalHofdbVtCITOpkNDzMFXajMkZqGufIoNxFmwaqHYRKIjggVesrdqWyXFBDcqEtVXbPFKvLrpyUgGVkXDcVJmlCNdNNXUoGhNoGtHvqLjr")) {
        for (int OgtsanFmJD = 796163321; OgtsanFmJD > 0; OgtsanFmJD--) {
            APfdyPMQD = APfdyPMQD;
            APfdyPMQD = ! APfdyPMQD;
        }
    }

    return APfdyPMQD;
}

double jdLqTr::FAlvuJKowr(bool CcJkJ, string JZmCuPOikQypu, int udKdldQXBmlkc, string ZvsOgpJeacTvQFbj)
{
    int SKvkaQC = -722275015;
    int wwQpJAzDus = 1949645379;
    double IuRvpUfETDBIYFi = 739370.2611328956;
    double uuzkOzMVR = -158644.22583372338;
    bool cxYzFqcblqB = true;

    for (int NNMdMoyygMUDyT = 334109765; NNMdMoyygMUDyT > 0; NNMdMoyygMUDyT--) {
        continue;
    }

    for (int NHCHtvNRmNdyR = 1739841823; NHCHtvNRmNdyR > 0; NHCHtvNRmNdyR--) {
        IuRvpUfETDBIYFi = IuRvpUfETDBIYFi;
        udKdldQXBmlkc *= udKdldQXBmlkc;
    }

    for (int IhXuIGm = 1770866388; IhXuIGm > 0; IhXuIGm--) {
        SKvkaQC /= wwQpJAzDus;
    }

    for (int eNRtlWoqiRXHf = 53240319; eNRtlWoqiRXHf > 0; eNRtlWoqiRXHf--) {
        JZmCuPOikQypu = ZvsOgpJeacTvQFbj;
    }

    for (int pQQpfC = 767660423; pQQpfC > 0; pQQpfC--) {
        wwQpJAzDus *= SKvkaQC;
    }

    for (int tUnmIMKJe = 1217794116; tUnmIMKJe > 0; tUnmIMKJe--) {
        SKvkaQC = udKdldQXBmlkc;
    }

    return uuzkOzMVR;
}

double jdLqTr::TGHZjIR(double dFHbuIDdhsR, int sHPIfheIZFMA, string cmbNwOYGAf, int wQvuCRYrjCiK, int iGwSdzhpiuq)
{
    string EDOqpuzWzVG = string("AKqEzAdMxDDCwhqhwZqaBrsCRJWazOSOKSjDHL");
    string frCERPHLElFXFF = string("ldLXiPQlxqaTVjIZqWVQiHKUJuDqDRSbmmQtVYDuzzxwmXrVBOZgBYkWjyNhfIIJnWoXUfmuembLPECFpnGgXLRWDJGTrNhvWgeHagJxmYuDHNwEkxgeNWuxQNHsBYtlxfBfTQdweVsDJjOHMsUFjzaRSmrNqKLSpgLOVKdhx");
    bool UGXGTzvqWiNcnihX = true;
    double HePdWCQFuULF = -202075.58551889373;
    double tsySuKdAG = -1018588.0220643299;
    int pYNkXXJc = 55669759;
    double dsUcgbiAb = 171511.11753214503;
    int DrTkZMU = -2144566588;

    for (int ULDUcJfJ = 459996398; ULDUcJfJ > 0; ULDUcJfJ--) {
        frCERPHLElFXFF += EDOqpuzWzVG;
    }

    for (int zKqwFAIQNXAx = 1958198639; zKqwFAIQNXAx > 0; zKqwFAIQNXAx--) {
        UGXGTzvqWiNcnihX = UGXGTzvqWiNcnihX;
        wQvuCRYrjCiK *= wQvuCRYrjCiK;
        pYNkXXJc -= wQvuCRYrjCiK;
    }

    for (int OgRgbyrPqBGo = 1152532710; OgRgbyrPqBGo > 0; OgRgbyrPqBGo--) {
        continue;
    }

    return dsUcgbiAb;
}

jdLqTr::jdLqTr()
{
    this->mqbKtchiTOTTsont(237922.27085159806);
    this->OJqgVKgDBzj(string("GcgURPSbhfwVAnXCqCkTaKAkiYIYmCHgxBucnPQmObDrVwDcmPPwDBYxoPkqDKTCyEBKpvKZkyRLOcsXFVslNzKumiJkeaWnMLNjirTazYymIifyLeCCqNWaRWYCBjjQOaigXguVuPmpkaaVsaxofpqiiLsqzIvBjWupqJhGrK"), string("eLnAuw"), 902818.9432534444);
    this->MMaTWqO(-885487927, string("pjuPvsftZeRmxQjbnYPwpZwePHrRbwuEYBgsGmwsaQJDJEGqDFMfestQUjMdMldWYPWgQpDEFIxTsqBRwLuPTTcMiXguOuuSUFQCszjvzgqrqwqiaCkcKOJCzERxhMbAZcURtQQixptAMuzhVKANsiIpsIPQWsQwJKscVLtjmhduLUtKeTdVuzXASiScKWeuLydxfTdwcViqGVqpL"), true);
    this->InaHjYuNyOZRTgQ(string("TshoMDbhyPdgFYyQqqYYRYqLhSUoyJRKUegoaKwMIyFdlWmYHdNgNyKaeyZSYfEWZYNvleBosTDZuPgKgtCSFuntsOMrxNNXEoYpRafHJXarTXQvrJKTQCgPQAOwzyxZaJSweofTZjqHYIThBTBAkJGLtVrzEExJZJQSJuNxvhRDwbdrhVhjVOfAMkFYXuwzkhzkOPeLKUVkJNRnrsueCPaFpFhI"), string("NJOPkTbsQVUoLTqbVjrcUxmVLFSWLMCzUXgFKSuCyHijwjWtqiFirSbLUGzncHVgfZvrHukPqVOBbvNMSbUpZNvzLUsMGADdYtGGrWibYdzKfgFPtmgiRHvomgYuTYYtzpRgFKcUwWdQBjIYlTZrPZtLblkrCWFvtFDgPmgfPUhLGAntfWUjaKpGwLponJJQYxV"));
    this->AMmUkAU(706178.2396007396, 945392.2439634126, string("ChMBgePJwBBuCmsOaIsRThMtnGflbtMGYuAhERXxNJYwdVfmDufiefDsEvXGMJIuErKIPKsIInIQNXclgWmQFDxvxgzvwnCiOORpOFEpSuuqCwMEgIHgDaatnBElBHFpIVLmklgIIGwAiKEnaOoHABFjXqsEepSzljNBnywQAvOWuF"), true);
    this->nWnHHEeY(-1808833510, string("NUNUNmxEuzmjRzDqmyRaBJPyBWJWySdcQjCyDFlngkYmLQBXHrSawlUygbRALUnbrqMKKbGlQPkGHEZZLqpWWxrDqlUSWvtFdIsgPbgPMxRWBSFdGYUbwZsJnrElbirgeuQMmDGkwwyviwgyimEiagHtxmLhiexbf"), string("lbEJxQKDpsqbKLUqMHlQYznjQmzYkRPajpWCTSAHFfikWiGsbJcxjDQrnxJUdBgSWFKuWCRaGAUzh"), true);
    this->tJpVhJ(-1287462578);
    this->dZqlyWuhScnPVPR(true, -67399.99146277452, 724609.1350003314, string("HObuyGqJOLwAxPYABPCfXCeNkgcPNFzGZjOyzumnFmBzyclLMafsdzoTSQgVSByqRa"));
    this->oUmIyg(true);
    this->CKrHBAsMoJbCckG(-1970085883);
    this->tZFPXfFKcD(1154856867, 881394285, string("olqxU"));
    this->LEZcbZrtw(string("GXfrmeLAOUNoVSJrEsStWdBtzNWNBumqFxKatqdpKXgjgHdEXeKCJKTDanllCKIzXJhanJONqhMmcLnbEMaxNtnUTBRdyogDXYQILBMQgFSbGMAUsJBZrYBihRZwZYeeEjKqJNUwsZdvCxtEYtrNqIcdGXrqGYJycLqlOTrvAzVVpdbhYDzxSyl"), false, 94499534);
    this->ZIUgfuleyieI(1681178759, -207319.9446778933);
    this->zOIPqDeeTPBSVfs(false, string("VK"), string("AZTdhhSBNSGCWCwqIAxlaalHofdbVtCITOpkNDzMFXajMkZqGufIoNxFmwaqHYRKIjggVesrdqWyXFBDcqEtVXbPFKvLrpyUgGVkXDcVJmlCNdNNXUoGhNoGtHvqLjr"));
    this->FAlvuJKowr(true, string("BkcqqulqMEATAnPgVqrFWVaZIMyeqdkWTgVWcAtCvWnmgnOgAEHmLWPdBHEsIYWSUHbWGrctHSjETFrWCDYYbfbIenrtWUNwiHhFKoDuwAusRezQgnKUrfVbuEOOhMBSdgfHJTeKecJwBBOyXOTRzILVHZmhjtXJbxojQYQsXfOUWuKgRowWEUrCOI"), -1052821031, string("qaKrfwOORHJFiBVOgIclYWyJmftcRtShnGksbaDEbHZEfntqSoPFhOmejUIuWgesCGeixkJYbVzVJQrhABieKrNbCjOjqdwpaeTFZlszAkXojpZAcWBiVTjKISdLOhsqGrezlfVrSlnCfNNiOAauDBKSRLZmjTlOMCCtyeMbARRyAKwazzIfpyTSodvPowCQrhsJrDYmxMcFWXbjmnWE"));
    this->TGHZjIR(-761769.2352934, 1161423920, string("oyKofanvjUxuVEUvDvLtMqmtgYQqxWFwjBhKjeSUKlwxRGrZhwvXFeGLKEVFQxIsQrzcqFYPaKLGVeSLsRjwhgMbXYTWwVrJOCuLWQYNTiwfhwTZDJfRBSrSsTIE"), 927814062, 108699775);
}
