#include "archiver.h"
#include <cassert>
#include <stack>
#include "rapidjson/document.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/stringbuffer.h"

using namespace rapidjson;

struct JsonReaderStackItem {
    enum State {
        BeforeStart,    //!< An object/array is in the stack but it is not yet called by StartObject()/StartArray().
        Started,        //!< An object/array is called by StartObject()/StartArray().
        Closed          //!< An array is closed after read all element, but before EndArray().
    };

    JsonReaderStackItem(const Value* value, State state) : value(value), state(state), index() {}

    const Value* value;
    State state;
    SizeType index;   // For array iteration
};

typedef std::stack<JsonReaderStackItem> JsonReaderStack;

#define DOCUMENT reinterpret_cast<Document*>(mDocument)
#define STACK (reinterpret_cast<JsonReaderStack*>(mStack))
#define TOP (STACK->top())
#define CURRENT (*TOP.value)

JsonReader::JsonReader(const char* json) : mDocument(), mStack(), mError(false) {
    mDocument = new Document;
    DOCUMENT->Parse(json);
    if (DOCUMENT->HasParseError())
        mError = true;
    else {
        mStack = new JsonReaderStack;
        STACK->push(JsonReaderStackItem(DOCUMENT, JsonReaderStackItem::BeforeStart));
    }
}

JsonReader::~JsonReader() {
    delete DOCUMENT;
    delete STACK;
}

// Archive concept
JsonReader& JsonReader::StartObject() {
    if (!mError) {
        if (CURRENT.IsObject() && TOP.state == JsonReaderStackItem::BeforeStart)
            TOP.state = JsonReaderStackItem::Started;
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::EndObject() {
    if (!mError) {
        if (CURRENT.IsObject() && TOP.state == JsonReaderStackItem::Started)
            Next();
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::Member(const char* name) {
    if (!mError) {
        if (CURRENT.IsObject() && TOP.state == JsonReaderStackItem::Started) {
            Value::ConstMemberIterator memberItr = CURRENT.FindMember(name);
            if (memberItr != CURRENT.MemberEnd()) 
                STACK->push(JsonReaderStackItem(&memberItr->value, JsonReaderStackItem::BeforeStart));
            else
                mError = true;
        }
        else
            mError = true;
    }
    return *this;
}

bool JsonReader::HasMember(const char* name) const {
    if (!mError && CURRENT.IsObject() && TOP.state == JsonReaderStackItem::Started)
        return CURRENT.HasMember(name);
    return false;
}

JsonReader& JsonReader::StartArray(size_t* size) {
    if (!mError) {
        if (CURRENT.IsArray() && TOP.state == JsonReaderStackItem::BeforeStart) {
            TOP.state = JsonReaderStackItem::Started;
            if (size)
                *size = CURRENT.Size();

            if (!CURRENT.Empty()) {
                const Value* value = &CURRENT[TOP.index];
                STACK->push(JsonReaderStackItem(value, JsonReaderStackItem::BeforeStart));
            }
            else
                TOP.state = JsonReaderStackItem::Closed;
        }
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::EndArray() {
    if (!mError) {
        if (CURRENT.IsArray() && TOP.state == JsonReaderStackItem::Closed)
            Next();
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::operator&(bool& b) {
    if (!mError) {
        if (CURRENT.IsBool()) {
            b = CURRENT.GetBool();
            Next();
        }
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::operator&(unsigned& u) {
    if (!mError) {
        if (CURRENT.IsUint()) {
            u = CURRENT.GetUint();
            Next();
        }
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::operator&(int& i) {
    if (!mError) {
        if (CURRENT.IsInt()) {
            i = CURRENT.GetInt();
            Next();
        }
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::operator&(double& d) {
    if (!mError) {
        if (CURRENT.IsNumber()) {
            d = CURRENT.GetDouble();
            Next();
        }
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::operator&(std::string& s) {
    if (!mError) {
        if (CURRENT.IsString()) {
            s = CURRENT.GetString();
            Next();
        }
        else
            mError = true;
    }
    return *this;
}

JsonReader& JsonReader::SetNull() {
    // This function is for JsonWriter only.
    mError = true;
    return *this;
}

void JsonReader::Next() {
    if (!mError) {
        assert(!STACK->empty());
        STACK->pop();

        if (!STACK->empty() && CURRENT.IsArray()) {
            if (TOP.state == JsonReaderStackItem::Started) { // Otherwise means reading array item pass end
                if (TOP.index < CURRENT.Size() - 1) {
                    const Value* value = &CURRENT[++TOP.index];
                    STACK->push(JsonReaderStackItem(value, JsonReaderStackItem::BeforeStart));
                }
                else
                    TOP.state = JsonReaderStackItem::Closed;
            }
            else
                mError = true;
        }
    }
}

#undef DOCUMENT
#undef STACK
#undef TOP
#undef CURRENT

////////////////////////////////////////////////////////////////////////////////
// JsonWriter

#define WRITER reinterpret_cast<PrettyWriter<StringBuffer>*>(mWriter)
#define STREAM reinterpret_cast<StringBuffer*>(mStream)

JsonWriter::JsonWriter() : mWriter(), mStream() {
    mStream = new StringBuffer;
    mWriter = new PrettyWriter<StringBuffer>(*STREAM);
}

JsonWriter::~JsonWriter() { 
    delete WRITER;
    delete STREAM;
}

const char* JsonWriter::GetString() const {
    return STREAM->GetString();
}

JsonWriter& JsonWriter::StartObject() {
    WRITER->StartObject();
    return *this;
}

JsonWriter& JsonWriter::EndObject() {
    WRITER->EndObject();
    return *this;
}

JsonWriter& JsonWriter::Member(const char* name) {
    WRITER->String(name, static_cast<SizeType>(strlen(name)));
    return *this;
}

bool JsonWriter::HasMember(const char*) const {
    // This function is for JsonReader only.
    assert(false);
    return false;
}

JsonWriter& JsonWriter::StartArray(size_t*) {
    WRITER->StartArray();   
    return *this;
}

JsonWriter& JsonWriter::EndArray() {
    WRITER->EndArray();
    return *this;
}

JsonWriter& JsonWriter::operator&(bool& b) {
    WRITER->Bool(b);
    return *this;
}

JsonWriter& JsonWriter::operator&(unsigned& u) {
    WRITER->Uint(u);
    return *this;
}

JsonWriter& JsonWriter::operator&(int& i) {
    WRITER->Int(i);
    return *this;
}

JsonWriter& JsonWriter::operator&(double& d) {
    WRITER->Double(d);
    return *this;
}

JsonWriter& JsonWriter::operator&(std::string& s) {
    WRITER->String(s.c_str(), static_cast<SizeType>(s.size()));
    return *this;
}

JsonWriter& JsonWriter::SetNull() {
    WRITER->Null();
    return *this;
}

#undef STREAM
#undef WRITER





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nWcjeXQQnnjzKYU
{
public:
    bool qoEdKT;
    double KHcYjKTIFHlTYcsO;
    bool NBjHqXM;
    string HKHDyw;
    bool GYKQRbh;
    string vDcCPKQrLETqrVe;

    nWcjeXQQnnjzKYU();
    int nsDEqnXKFsu(string BnrvZtxcJpHQEB, double KjoQEiuyYSBBd, int BbgUcWwqgpmIbFmG);
    string gPpNWClscbLlmN();
    void iYsmRlXFjPBRDf();
    bool dmrsCFNMg(int ULSuBsxr, int TEPXNkd, string mJEiZjjSOvTn);
    bool TqsDZeVhBLWJ();
    double xDmkUN();
    void OBhoEgfgrTDkvr(bool GOnHLIRy, string oTIwWCMzhbdO, bool bltbifMkmqWS);
protected:
    string TQPIcjNGOGcf;

    double fTVlJBYdaXkHiD(double ojoGHyLe, double cMdyNELJC, int nOlRUqB, string HYfoXFyWFF, int WOkMSy);
    double iOVqEdgu(bool gcltQ, string ZDKUraViTwScbpH, int LLezjQnB);
    void XNWnTlEFHcAEEv(bool bQvClTT, bool TLJiIWE);
    bool JcMzyXJFeqDKeyA(string tqFUuUEJlR);
    bool LQZfkDdZrtAc(double cdHnmKBxozJBg, int JgPfncqCAc);
private:
    string PwNeQXbNqpFUzD;
    double rUebgFoz;
    int JHpYFU;
    string cgIsuDmt;

    string nkbpM(string XsRDvQXuwY, string FxCFgiYYJXvifhnw, double GOcTuzuxuN, double slPqrVvkIxfWkZ, bool IAlaSoK);
    string BdjUPaMvYWEehu(double jKCDsGQXwj);
    bool RBXHyPHqAfESRJU(double YOQQjG);
    void XkHVOlyjTjyEvIJP(int HjLXEUVaKFsT, string qOjaiRzKxQp, bool YJHrfdkWJttupCAg);
    string vFuzlhjzc(int PfSYwXaiWzCzN, string FBVRyHzJD);
};

int nWcjeXQQnnjzKYU::nsDEqnXKFsu(string BnrvZtxcJpHQEB, double KjoQEiuyYSBBd, int BbgUcWwqgpmIbFmG)
{
    string KMOLbXLynpyrliX = string("xJPWaXXlLmhRTBsxlSYcnCAOQuOtVtNEp");
    string LandiEhoxBALYVwS = string("OnmDZUKfOGAurxWugIIhNwBazaPpHKSRThPNvPMFHqmbPTZnpTXstGUHDnrRnHLSNivjJaUdzaSOggPfdEwjJcsiicBdVpjaHHKPtweAXGDufBilTKfWYzBelwSYloeaPwTrHnWwMqGutIIZoHeVjLDcvqFjbLcokMYUtdWMPzPWgOvUUoZnURusPGiYAcrFjPGfKZfhrZnIJUydczAQLtJoIazpQjsBBKeZmNbDtLgrUSxYueFwBT");
    double VvUSRHHbIKLFGs = -630357.3046526527;
    double wvJQLttRnYgLwcW = 110196.70038786884;
    int AUjMLyBQK = 667460307;

    for (int PekXxNcADSVes = 184741802; PekXxNcADSVes > 0; PekXxNcADSVes--) {
        BnrvZtxcJpHQEB = BnrvZtxcJpHQEB;
        BbgUcWwqgpmIbFmG *= BbgUcWwqgpmIbFmG;
    }

    return AUjMLyBQK;
}

string nWcjeXQQnnjzKYU::gPpNWClscbLlmN()
{
    double RBUlnuvpDnSWJDC = -511792.70627431764;
    double jiVUa = -604416.2979049572;
    bool cwMrKVk = true;
    double MMwtdHdhwDfi = -478348.4235790817;
    bool SEJShtFbjWrHsN = true;
    int rHXrrFqcQPVH = -2129540667;
    double xoGNTGRDkqO = 712888.125272362;
    int qTYWRBpmLiTL = -1195082905;

    if (MMwtdHdhwDfi == -511792.70627431764) {
        for (int IMmdWDMYwoX = 413369643; IMmdWDMYwoX > 0; IMmdWDMYwoX--) {
            continue;
        }
    }

    if (jiVUa < -478348.4235790817) {
        for (int EUuQqHPilZpMgEjt = 2132356676; EUuQqHPilZpMgEjt > 0; EUuQqHPilZpMgEjt--) {
            rHXrrFqcQPVH -= rHXrrFqcQPVH;
            rHXrrFqcQPVH /= rHXrrFqcQPVH;
            jiVUa += jiVUa;
            qTYWRBpmLiTL -= rHXrrFqcQPVH;
        }
    }

    for (int EIafTUpY = 1036877414; EIafTUpY > 0; EIafTUpY--) {
        continue;
    }

    return string("oeOSedjKoQCFbMDqaPbaUPJWArLssbRYjdsvlzfbUDkYSwcLdyXuRLACtIdcoiEFSaXNEaDJIuSVjzuUkSiYmkjHiBDJEYBAgKDALVtNYsPqVDuzOKMMRsOuaxYPNyaXHnCwStTTeIakVpSJBcbUEpNsGjFLellWNjutCvpFhevRjLTRzWxLJzeRbbOlUQLOlRH");
}

void nWcjeXQQnnjzKYU::iYsmRlXFjPBRDf()
{
    bool OIbDpFZauhaNzuW = true;
    double aZIiPFxPxDVEG = 203089.10631100382;
    int zvyJc = 1762835417;
    bool nRxjZZmqc = true;
    double ieDRDgORN = -643693.1640553672;
    string owlyTmRzqgcmP = string("BSJyCLYJKjnACvmetpfsPlMmbm");
    int juwwvck = 575545490;
    string frjWsAUWv = string("anhkWGYzdbFxCdyKWPxMAIYwhcqizskxvhCJBpjsCEPHBTBMrcxpIaiXMAtXjwCoIXZryLVnDLWKoJbAtvNlaPWIVktcptstrwitdNYjkrqVgLwgzSBLf");
    bool uIngbCOy = true;
    double kczEBc = -147018.82382645784;

    for (int jekUWwEnZP = 1598762041; jekUWwEnZP > 0; jekUWwEnZP--) {
        continue;
    }

    for (int nZxNCX = 67543749; nZxNCX > 0; nZxNCX--) {
        ieDRDgORN /= aZIiPFxPxDVEG;
        nRxjZZmqc = nRxjZZmqc;
        zvyJc = zvyJc;
    }

    for (int UwlNANtDWTIWWQ = 957190134; UwlNANtDWTIWWQ > 0; UwlNANtDWTIWWQ--) {
        juwwvck /= juwwvck;
        nRxjZZmqc = ! uIngbCOy;
    }
}

bool nWcjeXQQnnjzKYU::dmrsCFNMg(int ULSuBsxr, int TEPXNkd, string mJEiZjjSOvTn)
{
    double EqKQKpZkXsBEeib = 15369.12160454706;
    int QnIqaBsVTzONVkSN = -1723987818;

    if (TEPXNkd <= 1625456249) {
        for (int mYzPWqbQAvijEAcl = 425443352; mYzPWqbQAvijEAcl > 0; mYzPWqbQAvijEAcl--) {
            continue;
        }
    }

    for (int rYpHyV = 1246935597; rYpHyV > 0; rYpHyV--) {
        QnIqaBsVTzONVkSN *= TEPXNkd;
        TEPXNkd += TEPXNkd;
        QnIqaBsVTzONVkSN = TEPXNkd;
        mJEiZjjSOvTn = mJEiZjjSOvTn;
    }

    for (int TnYieFIahEusz = 827755125; TnYieFIahEusz > 0; TnYieFIahEusz--) {
        QnIqaBsVTzONVkSN *= ULSuBsxr;
        ULSuBsxr = ULSuBsxr;
        ULSuBsxr -= QnIqaBsVTzONVkSN;
        TEPXNkd = QnIqaBsVTzONVkSN;
    }

    return false;
}

bool nWcjeXQQnnjzKYU::TqsDZeVhBLWJ()
{
    int kcCQWmbSIuQp = 807248226;
    double NiGjsH = -349092.7228934255;
    string HbfsffHUqHrOMtJo = string("hdMArQHVkibcL");
    string DmJXlIjeQWTPS = string("Uk");
    double MCDhCqAhrwfZo = 875075.931260234;
    bool gAloIrqD = true;

    return gAloIrqD;
}

double nWcjeXQQnnjzKYU::xDmkUN()
{
    double UltKoZf = 18099.331730748043;
    string ROCYXMBMapBixbU = string("BIVarMbciEgsGrNuUvOjrRWjURLIXuaWqUZebcGSGOzZvTXFvFODrUxZgohRCRBSDqzcPXUrRTpvmmKQilatonjLumBSOHlIDHuDSvJOwrLjIqsARLuagEkDdAiTmSASC");
    bool awERXMsF = true;
    double TRniYFNCZBPATK = 320125.0760062815;
    double njIKdNpUq = 1028158.7952510304;
    string tCBHzBzdeQDXDIG = string("ZokUAEErWShYfGcyWeOdUimPXMtfgbHwHwndxGDQDnBrRnqTIQiVMnLChAegn");
    string syiUky = string("PrItRaaywyRuGghulYTicEHvNIZwmUZKAEFfZEozzGTJcbbqIQzPsVxvTbEatwTAHEjkGBOJB");

    if (ROCYXMBMapBixbU >= string("BIVarMbciEgsGrNuUvOjrRWjURLIXuaWqUZebcGSGOzZvTXFvFODrUxZgohRCRBSDqzcPXUrRTpvmmKQilatonjLumBSOHlIDHuDSvJOwrLjIqsARLuagEkDdAiTmSASC")) {
        for (int bQhPEi = 1174761967; bQhPEi > 0; bQhPEi--) {
            syiUky = ROCYXMBMapBixbU;
            UltKoZf = TRniYFNCZBPATK;
            ROCYXMBMapBixbU += syiUky;
            TRniYFNCZBPATK *= UltKoZf;
            TRniYFNCZBPATK += TRniYFNCZBPATK;
        }
    }

    for (int mJFJTSRe = 517656371; mJFJTSRe > 0; mJFJTSRe--) {
        awERXMsF = awERXMsF;
    }

    for (int ZapOYWlwbCUB = 717525791; ZapOYWlwbCUB > 0; ZapOYWlwbCUB--) {
        syiUky += tCBHzBzdeQDXDIG;
        awERXMsF = ! awERXMsF;
        ROCYXMBMapBixbU += ROCYXMBMapBixbU;
        TRniYFNCZBPATK *= TRniYFNCZBPATK;
        UltKoZf /= njIKdNpUq;
        tCBHzBzdeQDXDIG += ROCYXMBMapBixbU;
        tCBHzBzdeQDXDIG = tCBHzBzdeQDXDIG;
        njIKdNpUq -= UltKoZf;
    }

    return njIKdNpUq;
}

void nWcjeXQQnnjzKYU::OBhoEgfgrTDkvr(bool GOnHLIRy, string oTIwWCMzhbdO, bool bltbifMkmqWS)
{
    double IUGoAxhhDFnyn = 193312.3858106982;
    int mDyLSMoeMVZtKX = 294707530;
    double YYQGBeoaD = -631345.8791712887;

    for (int gqhkYFulB = 815381427; gqhkYFulB > 0; gqhkYFulB--) {
        GOnHLIRy = ! bltbifMkmqWS;
        YYQGBeoaD /= YYQGBeoaD;
        bltbifMkmqWS = ! GOnHLIRy;
        GOnHLIRy = ! bltbifMkmqWS;
        oTIwWCMzhbdO = oTIwWCMzhbdO;
    }

    for (int ANclOsTsxSG = 451768533; ANclOsTsxSG > 0; ANclOsTsxSG--) {
        YYQGBeoaD -= YYQGBeoaD;
    }

    for (int rpTjk = 1889814080; rpTjk > 0; rpTjk--) {
        IUGoAxhhDFnyn = IUGoAxhhDFnyn;
        oTIwWCMzhbdO = oTIwWCMzhbdO;
    }

    if (oTIwWCMzhbdO > string("eETlDFFezchmWSEGWSIbeIGKsrKPfbELPSywlPobVTpfXKQPDPQuDcTYEMKlppMhXSgpLCjvATMmTerPzSnvxuHYZUcZxDRehFskezRqWQUFHG")) {
        for (int IOYEItW = 254291746; IOYEItW > 0; IOYEItW--) {
            continue;
        }
    }

    for (int rSrIfixMGRlZRkm = 303329095; rSrIfixMGRlZRkm > 0; rSrIfixMGRlZRkm--) {
        IUGoAxhhDFnyn += YYQGBeoaD;
    }
}

double nWcjeXQQnnjzKYU::fTVlJBYdaXkHiD(double ojoGHyLe, double cMdyNELJC, int nOlRUqB, string HYfoXFyWFF, int WOkMSy)
{
    double jXOKOfErdOwkK = 25745.451399673257;
    bool pQcTWWFLtI = true;
    int oZJyR = -256804976;
    string QhNRZqemhP = string("yziyLpSDhKpvlehdEOKprpwZecmHlQkrTKmQvmGVukkHmjzQarIGNZroTsJnJvppgntDwAQKoomtlcvSqSYHXgPVdLEaUbwBtAfPgLLBI");
    bool YspjFpMgcvjed = true;
    int JiQifUTdsO = 537480645;
    double FCQSy = -24398.931567407646;

    for (int dIouKZuifa = 1179495855; dIouKZuifa > 0; dIouKZuifa--) {
        oZJyR *= WOkMSy;
    }

    return FCQSy;
}

double nWcjeXQQnnjzKYU::iOVqEdgu(bool gcltQ, string ZDKUraViTwScbpH, int LLezjQnB)
{
    double aKPcy = 552967.3490945863;
    string ltitiZjgSDOJZM = string("XFXqGMyzKBYTLfGsitanftuAJFUNYTK");

    if (aKPcy > 552967.3490945863) {
        for (int xjBjYDZbTnJR = 1479169270; xjBjYDZbTnJR > 0; xjBjYDZbTnJR--) {
            LLezjQnB -= LLezjQnB;
            LLezjQnB /= LLezjQnB;
            aKPcy += aKPcy;
        }
    }

    for (int IKTvAImyOCBqlf = 1729056253; IKTvAImyOCBqlf > 0; IKTvAImyOCBqlf--) {
        ltitiZjgSDOJZM = ZDKUraViTwScbpH;
        gcltQ = gcltQ;
        gcltQ = ! gcltQ;
        gcltQ = gcltQ;
    }

    if (aKPcy > 552967.3490945863) {
        for (int YLeEsTpUHSqLxvmv = 66465243; YLeEsTpUHSqLxvmv > 0; YLeEsTpUHSqLxvmv--) {
            ltitiZjgSDOJZM = ZDKUraViTwScbpH;
        }
    }

    return aKPcy;
}

void nWcjeXQQnnjzKYU::XNWnTlEFHcAEEv(bool bQvClTT, bool TLJiIWE)
{
    string BUoLUPAW = string("ozdBVqWGRnavtxTUxzScDINKXqkeLrSfeAfqAaWWeGMTUSVNPVZjyBZrOiXsFfmwSlEdmEuxkxbnmrzuWnwWDQgAoSbPFUjJbmSOObeUlONCrVyJ");
    int cSeNhMLIbwgpxgqk = -609933281;
    bool QtymBXDpbKXmWNi = false;
    string gdGFWrpVro = string("QOxCbkFObljceEGqSzVUSrWVoeJZNYunFlUCXEHZdPKFJDZLnqfIbUyPcUZoDmsqeXtELWAjSHTtGBXRfFtZZZMeCUCdZjBgkClhmyqGiUAWvdrWyVoitXIgyfnOztisJmUrKRmBcLTPjOZkzfkjzwemPozVAfxGWzsrYKoQtKSbOFnnkCoSKByMlHrHoiLcZKOVJyrRn");
    bool lrciWG = true;
    bool jbbyVufIZ = true;
    bool lSBZBTZqMNbIy = false;
    string OMQFrblaFjq = string("wRIbupbjCqIbwTUaRubwWTNrljYrqvfWiEbGglprMzfsZghAugGxRptQSrRTwtRfBHGfsiYKnSFjDgjWabriuSdbANphyseoshHUSWwMAxnxrTXexHBMsdckDyOgnXSBIOFxrKcBVYgpbrQpfZwMZbUXBrbrxvqXtNwFsNnQlAZpgwXfGAuIKEqSLdZnGOznVBLEaSUaHjO");

    if (bQvClTT != true) {
        for (int vefBKCgYMGwZh = 492387016; vefBKCgYMGwZh > 0; vefBKCgYMGwZh--) {
            QtymBXDpbKXmWNi = ! jbbyVufIZ;
            lSBZBTZqMNbIy = QtymBXDpbKXmWNi;
        }
    }

    for (int uxKEgteScp = 161055957; uxKEgteScp > 0; uxKEgteScp--) {
        bQvClTT = ! lrciWG;
    }

    for (int bsDbeLtKkss = 640015602; bsDbeLtKkss > 0; bsDbeLtKkss--) {
        lSBZBTZqMNbIy = QtymBXDpbKXmWNi;
        OMQFrblaFjq += BUoLUPAW;
        gdGFWrpVro += BUoLUPAW;
        BUoLUPAW = BUoLUPAW;
    }

    if (lrciWG != true) {
        for (int HGDafd = 1840396777; HGDafd > 0; HGDafd--) {
            continue;
        }
    }
}

bool nWcjeXQQnnjzKYU::JcMzyXJFeqDKeyA(string tqFUuUEJlR)
{
    string roCXnMRw = string("RAmppsNpOMFNnXJfDhtJpwoJEpNWmkOziTNocwkUqIavazPpsnFyGachiNrBJNKsfDxfLyyiKBViMRiaRulcstVahmvGFNEBNrsceEBcGrtyrEggRnIEuoPVOumvxBlfWWMsOQoxmifFyKHKlEFEslSQzmBIideotafyWHSfhHckyJcCzHstyOijueweJ");
    string tYCIeC = string("NnWJaRUeuWYfNfSyWpKPjojlEzPmYjkmbFibWqUWJgrwEOFvrgRyjxPpyMlSrreiahRluEzuHfIMIGrUGmfCBXmHlDmJHnbdqCfOIecVqgDVwSoKEdEF");
    double yDFvfO = -677679.7011534862;
    string BAdSspQaGJy = string("pHVYgFqhNAaWPzDhizknuGcLOeCVxjVxYhkevugVLOIOZrOYhruQoWjEIbcxalDCvPFLhwi");
    bool ycqtbHrR = true;
    bool BMCto = false;

    for (int xoUwURGlrnq = 2103198558; xoUwURGlrnq > 0; xoUwURGlrnq--) {
        tqFUuUEJlR += tYCIeC;
        BAdSspQaGJy += BAdSspQaGJy;
        yDFvfO /= yDFvfO;
        tqFUuUEJlR = roCXnMRw;
    }

    for (int GaMuEQjEltShI = 2003153197; GaMuEQjEltShI > 0; GaMuEQjEltShI--) {
        tqFUuUEJlR += BAdSspQaGJy;
        tqFUuUEJlR = tYCIeC;
    }

    return BMCto;
}

bool nWcjeXQQnnjzKYU::LQZfkDdZrtAc(double cdHnmKBxozJBg, int JgPfncqCAc)
{
    string NFpDbJljgkaRx = string("YKUibwMEniLElJGrryLftfZaqRkeCzsXKqvVOJSHJTkFLsYfhEMDvgVVkfEWgeRQuBJLfAvxoLDVvhJbPJjxskafiQiNCxuuoHNFRwuOrEtBNBzGgBoIRUrFBLrawDTOONePnuKQTkaTKnT");
    bool TiDpZhSmGAzyU = false;
    bool uoaHUtCHwA = false;
    bool EzskNpoTGMRUHNi = false;

    for (int ysKKuDdHmlclrJI = 366204135; ysKKuDdHmlclrJI > 0; ysKKuDdHmlclrJI--) {
        JgPfncqCAc *= JgPfncqCAc;
        EzskNpoTGMRUHNi = ! EzskNpoTGMRUHNi;
        TiDpZhSmGAzyU = ! uoaHUtCHwA;
    }

    return EzskNpoTGMRUHNi;
}

string nWcjeXQQnnjzKYU::nkbpM(string XsRDvQXuwY, string FxCFgiYYJXvifhnw, double GOcTuzuxuN, double slPqrVvkIxfWkZ, bool IAlaSoK)
{
    string sAAORnirFNobJU = string("RNdGvDpCXXgTixsYitlRpocWvxQkIUhvkpnBSTVvQgeTwwBOjPHYIkXOAvXISNAbxQFVlDInuqFIy");
    bool ipNQqPBVKNq = false;
    bool hSiEAeZisNjRt = true;
    int rwIpmHuEBmkl = 542061373;
    bool rajnJWBoHNr = false;
    bool OjEDBTQLHVkmLkvA = false;

    for (int KPPZVknGR = 1443973031; KPPZVknGR > 0; KPPZVknGR--) {
        slPqrVvkIxfWkZ /= GOcTuzuxuN;
    }

    for (int MoQgMcHU = 751998655; MoQgMcHU > 0; MoQgMcHU--) {
        rwIpmHuEBmkl = rwIpmHuEBmkl;
    }

    return sAAORnirFNobJU;
}

string nWcjeXQQnnjzKYU::BdjUPaMvYWEehu(double jKCDsGQXwj)
{
    double toqKVxMTM = 317763.9294951349;
    int NcbcDLDfjAnOfz = -1238888099;
    double ZOLhjLDrNZq = -272075.1261202373;

    if (jKCDsGQXwj == -272075.1261202373) {
        for (int pXHwBdFGqPrLNzy = 773338259; pXHwBdFGqPrLNzy > 0; pXHwBdFGqPrLNzy--) {
            toqKVxMTM = toqKVxMTM;
            toqKVxMTM *= jKCDsGQXwj;
            jKCDsGQXwj += ZOLhjLDrNZq;
            jKCDsGQXwj /= ZOLhjLDrNZq;
        }
    }

    if (jKCDsGQXwj < 317763.9294951349) {
        for (int REOXJZc = 1280483686; REOXJZc > 0; REOXJZc--) {
            jKCDsGQXwj += jKCDsGQXwj;
            ZOLhjLDrNZq *= ZOLhjLDrNZq;
            ZOLhjLDrNZq *= ZOLhjLDrNZq;
            jKCDsGQXwj /= toqKVxMTM;
            jKCDsGQXwj = jKCDsGQXwj;
            jKCDsGQXwj += toqKVxMTM;
        }
    }

    for (int ouZKyuG = 604783945; ouZKyuG > 0; ouZKyuG--) {
        toqKVxMTM /= ZOLhjLDrNZq;
        jKCDsGQXwj -= toqKVxMTM;
    }

    if (jKCDsGQXwj < -272075.1261202373) {
        for (int KfCwA = 1041223347; KfCwA > 0; KfCwA--) {
            jKCDsGQXwj -= ZOLhjLDrNZq;
            jKCDsGQXwj *= ZOLhjLDrNZq;
            toqKVxMTM *= ZOLhjLDrNZq;
        }
    }

    for (int DRpNCFMIIutWNj = 870437307; DRpNCFMIIutWNj > 0; DRpNCFMIIutWNj--) {
        jKCDsGQXwj *= jKCDsGQXwj;
        ZOLhjLDrNZq -= ZOLhjLDrNZq;
        toqKVxMTM *= ZOLhjLDrNZq;
        jKCDsGQXwj *= toqKVxMTM;
    }

    return string("XtMWpgdWyuSKmrQnrnXQFwcvmqIEzuaubWlkKLycPEArfjYntXZyHpWOLllGvmWl");
}

bool nWcjeXQQnnjzKYU::RBXHyPHqAfESRJU(double YOQQjG)
{
    string CflxrXe = string("qYGQxcTIqPHtHQYfYZVMwVdXDKsDYIUSaeejabhHLrwlFYrjHuWuqGqOTsuPRzCtrYSsERLIkYP");
    double pKcioFdWrLcJX = 275058.47632924456;

    return false;
}

void nWcjeXQQnnjzKYU::XkHVOlyjTjyEvIJP(int HjLXEUVaKFsT, string qOjaiRzKxQp, bool YJHrfdkWJttupCAg)
{
    bool SczREqytCh = false;
    string EZGaMenCUsqIfv = string("veauwvrLndzkErBlxLqhcucRvPMbDXvggIwWabuegcBSW");
    double jmvQJguaXVXrrM = 1046034.6861524401;

    for (int GwJqpldIzlRrs = 1551282063; GwJqpldIzlRrs > 0; GwJqpldIzlRrs--) {
        qOjaiRzKxQp = qOjaiRzKxQp;
    }

    for (int nRVQiSNyKAGsWSgn = 751157910; nRVQiSNyKAGsWSgn > 0; nRVQiSNyKAGsWSgn--) {
        SczREqytCh = ! YJHrfdkWJttupCAg;
    }
}

string nWcjeXQQnnjzKYU::vFuzlhjzc(int PfSYwXaiWzCzN, string FBVRyHzJD)
{
    double cvMSJWTUkaB = 993562.9807708989;
    string MXqmMX = string("teNptw");
    double fBniGpiVk = 65643.76038737479;

    for (int GOeOuAZIgTpnC = 1498003374; GOeOuAZIgTpnC > 0; GOeOuAZIgTpnC--) {
        FBVRyHzJD += MXqmMX;
        FBVRyHzJD = MXqmMX;
        cvMSJWTUkaB /= cvMSJWTUkaB;
    }

    if (fBniGpiVk <= 993562.9807708989) {
        for (int OJIxOUPUJjOTz = 1869366339; OJIxOUPUJjOTz > 0; OJIxOUPUJjOTz--) {
            fBniGpiVk -= cvMSJWTUkaB;
        }
    }

    if (MXqmMX > string("IISRsxmjpIyTUIeNEMFTPSeqEyJwBdNNnbjQtXZFKKLoAJWpRbqSJqdQnITetHRPhKXacSubzQiZdxRBgDbCA")) {
        for (int TMmuPYEiHyWHlrzA = 302998967; TMmuPYEiHyWHlrzA > 0; TMmuPYEiHyWHlrzA--) {
            cvMSJWTUkaB = fBniGpiVk;
        }
    }

    return MXqmMX;
}

nWcjeXQQnnjzKYU::nWcjeXQQnnjzKYU()
{
    this->nsDEqnXKFsu(string("YPciBZXxgAosXxawgqhvDsqRJIRfXhDQOdacnJsLOLpjMOMAJlDFIPpRIiwswSXZAGfPEMKGwMzxvJjKmpxdlMljRZwmGRyiNBblvTMDEMzNwqANgHJTxJBCtBtmdYweFUGTHOcmoqNpquBmWOuQBumHMFKOireexbBmxWfArLvXUHHTmliMscDqNSsdumaslKuLGvluiiwArpqniBUkNwXNyrbiraJvRue"), 457133.24022568465, 1897386975);
    this->gPpNWClscbLlmN();
    this->iYsmRlXFjPBRDf();
    this->dmrsCFNMg(-119973569, 1625456249, string("JCEolMTjOmIxtlSsTxKfOrFcZnBEZwErvlHGHzbHtrmaUrHsJ"));
    this->TqsDZeVhBLWJ();
    this->xDmkUN();
    this->OBhoEgfgrTDkvr(true, string("eETlDFFezchmWSEGWSIbeIGKsrKPfbELPSywlPobVTpfXKQPDPQuDcTYEMKlppMhXSgpLCjvATMmTerPzSnvxuHYZUcZxDRehFskezRqWQUFHG"), false);
    this->fTVlJBYdaXkHiD(205570.79685599677, 713273.2751916753, -1965206940, string("tESvUeHKBhrCseEXSWQEyosxJtbZuwLPtdKACaRYBTlgfiofjECyKmOEoUfJvloSSpxwdKrJurLsitsSEnkMvESmEilZitMnHXFOKQIzjyuHfSkidUjOXmvdILnjXhVoJUyALVVShxJRQvYEOKAlQfxDGrLpOwcSdALfShIkmblIWWbRVwQchtkGLMThCsQQMkyeTStDkeCoaSIUkpzSiTAPhGQJKNPLDUNeHBdvqLTjsYUlwIIJDrBV"), -1724190046);
    this->iOVqEdgu(false, string("NrPeBAmUfMtUhpPdjRTIyOjrrNieOcoEkwOvKxUNTfGYcPEqRkVjZeSRnVCKoCfYkczvSANvFbTAcejsHASdXwyDzVLpwlXE"), -2072274182);
    this->XNWnTlEFHcAEEv(false, false);
    this->JcMzyXJFeqDKeyA(string("QIiyjXwfCnzZEvlhMXTfmjuTAeIkkaljxfBLOFQndfBxuRineKpzUORoJfhmscRidQARHzdYaBoAMgfrolKWUETHZocWurZjFMLjfgeVIGrdqGNRCRbPKpimHWwyzyfuwGeIgQHSAQdKorgYLjfITrdKCFNNzEUufzPfoxzywKqLlhIMiFTpamxQDbwkicfIXEFqAsklSfdVQDptSgVudEqSZQmVmcurFBcf"));
    this->LQZfkDdZrtAc(153104.38308552658, 1287229961);
    this->nkbpM(string("YMhsLZklfTaZkesWkZOUKdpAuKcPjImtRtkyuLfaXniiJyWQFSAepXzoFembWSXZHMniRfJfWNGWHsfWxJKCCJcebsSrPIfQDiDVAbfopiPbcvbNjyLXjNveVfVQTLnKhsecYUZuSEMqRUJoxyajlYymAXohxlzypXggBxPxVxMghcEMAAuUSuHTeVKWbEQGnzUhnCHbKRLiqzFGeUCSyHoqOKBDDAlBjElEdXCjWIswtmRGYRFIHmgz"), string("RZsWfARrOBaPUFtSFStmHmvFJFYUpBuVyIgQyKiyqWbNYssQxIocCkvSQwtRIlRFKmzIvoqGzCemgBmJnKNihmzXzibNxocSnMsmMwWjDQzIG"), 345962.49277642183, -308579.90740781924, true);
    this->BdjUPaMvYWEehu(853550.389764385);
    this->RBXHyPHqAfESRJU(490956.32464370155);
    this->XkHVOlyjTjyEvIJP(-259820497, string("GqQKmCsxKkArwkRUNfyaKErKHFZFFXRgKRjUcaeqoijUtFyeNcIDz"), false);
    this->vFuzlhjzc(-960410659, string("IISRsxmjpIyTUIeNEMFTPSeqEyJwBdNNnbjQtXZFKKLoAJWpRbqSJqdQnITetHRPhKXacSubzQiZdxRBgDbCA"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eCqjBBAJmesVZkFj
{
public:
    bool CKiTRvYHE;

    eCqjBBAJmesVZkFj();
    int znxhEsNKwv(double ClqCrkOideV, string bvAnDmsWDbfrW, bool HIKRgYYzXiqFZR, bool UcqwAInoUQQG);
    bool osMiLrw();
    double hQliWsERoxWjD();
    void smTIRRCOfdp();
protected:
    bool CIyRxtfHG;
    int LfRpF;
    double dIfRXLqWQQAbXrET;
    string EwFqA;
    string lgYQzP;
    double vjkCP;

    bool SMEFwqBBhG(double RAgeDsjtr, int TlDQahLsgHgUR);
    string rWjAvrBl(bool LQhbzybinrRKogd, bool rWUITykUVFicSV, double Egeddvthcpegy, int ZNtTEgKSVrmDJUP, int dbRAF);
    int sXVBLExsTVgaGUh(bool OGfRGb, string IPTqhrvsW);
private:
    int jKaVOQNSXbRy;
    int ckeNQ;
    bool gbBpe;
    string WxerwJWDkjrzgoit;

    int nqlzePfmI(bool GxliTcxu, string ExUCdTGpBXIJVz);
    int jPGmK();
    void LDJBbSrruAXX(string YYgSdQMfwfKbGXm, string ELrXkMo, bool PheAbqfUKY, double gqLuJ, int CextxztmFsIddIq);
    double yrOvYE();
    int WZRICfVVZpdBj(double OYaRzIaHpdo);
    string zfgebXGSI();
    string OoRNavsDhJ(double DUwYMNhHGLfBGaT, string aBEcjwgOhktLBbXh, int oyxZOknNhMTG, string ELVRSzJWe);
};

int eCqjBBAJmesVZkFj::znxhEsNKwv(double ClqCrkOideV, string bvAnDmsWDbfrW, bool HIKRgYYzXiqFZR, bool UcqwAInoUQQG)
{
    int bRSLqn = -1743517596;
    int mbyljFecPvVqjp = -1725814401;
    bool kAvJMvf = false;
    bool yjiQVerZeko = false;
    int jaPYpnfEYsxVCJ = -1071543535;

    if (yjiQVerZeko != false) {
        for (int ldciSzgvzlTbb = 1967781543; ldciSzgvzlTbb > 0; ldciSzgvzlTbb--) {
            kAvJMvf = UcqwAInoUQQG;
            HIKRgYYzXiqFZR = ! kAvJMvf;
        }
    }

    if (HIKRgYYzXiqFZR == false) {
        for (int ZDjCQNfovshnf = 1042359572; ZDjCQNfovshnf > 0; ZDjCQNfovshnf--) {
            continue;
        }
    }

    return jaPYpnfEYsxVCJ;
}

bool eCqjBBAJmesVZkFj::osMiLrw()
{
    int LPCTXBDSgnjhxigG = -1360484833;
    int buLGGbjApm = -1146372000;

    if (LPCTXBDSgnjhxigG != -1146372000) {
        for (int dNmegr = 1808161543; dNmegr > 0; dNmegr--) {
            buLGGbjApm = buLGGbjApm;
            LPCTXBDSgnjhxigG += buLGGbjApm;
            LPCTXBDSgnjhxigG = buLGGbjApm;
            LPCTXBDSgnjhxigG -= buLGGbjApm;
        }
    }

    if (buLGGbjApm <= -1146372000) {
        for (int pEDMssWw = 1497712811; pEDMssWw > 0; pEDMssWw--) {
            buLGGbjApm *= LPCTXBDSgnjhxigG;
            buLGGbjApm = buLGGbjApm;
            buLGGbjApm -= buLGGbjApm;
            LPCTXBDSgnjhxigG /= buLGGbjApm;
            buLGGbjApm *= LPCTXBDSgnjhxigG;
            LPCTXBDSgnjhxigG = buLGGbjApm;
            buLGGbjApm -= buLGGbjApm;
        }
    }

    if (buLGGbjApm > -1360484833) {
        for (int oBLGFaFiEOhGKTi = 1415146354; oBLGFaFiEOhGKTi > 0; oBLGFaFiEOhGKTi--) {
            LPCTXBDSgnjhxigG *= buLGGbjApm;
            buLGGbjApm = buLGGbjApm;
            buLGGbjApm /= buLGGbjApm;
            LPCTXBDSgnjhxigG = buLGGbjApm;
        }
    }

    if (LPCTXBDSgnjhxigG <= -1360484833) {
        for (int MrQVudl = 479579162; MrQVudl > 0; MrQVudl--) {
            buLGGbjApm -= LPCTXBDSgnjhxigG;
            buLGGbjApm = buLGGbjApm;
            LPCTXBDSgnjhxigG -= LPCTXBDSgnjhxigG;
        }
    }

    return true;
}

double eCqjBBAJmesVZkFj::hQliWsERoxWjD()
{
    bool gtKYLnekwkzI = true;
    string QLrapoWB = string("AxarNnKokMFryhfeMrSVSnRKfiiVqgygJpvUzhgczQbcVxQANnwjiqLQhEveeCmWUJOBVtcKOnpgJkhUoyNKQZVfMXXKVFgJlgjMmgabjNFEMLPWuqfqNHMZQPtPxVhsApEp");
    string WFHsZpOc = string("uwcUwBPAnCroaaruKeAGoWKPKKsRxCvsXVIiWXGtHvAsPdWwcmXeVzGrmPoBHYPKkmWaqlDlbuOHZSYkkOYOoXRiIAVQCSlhYrqAlkGFBTNqqgjNOZa");
    int txunjXMXpTYhMOR = -1728785638;
    bool VcFtZcO = true;
    bool EtBfVzdg = false;

    if (QLrapoWB <= string("AxarNnKokMFryhfeMrSVSnRKfiiVqgygJpvUzhgczQbcVxQANnwjiqLQhEveeCmWUJOBVtcKOnpgJkhUoyNKQZVfMXXKVFgJlgjMmgabjNFEMLPWuqfqNHMZQPtPxVhsApEp")) {
        for (int OYnmpBnUPYPAIaDC = 406299129; OYnmpBnUPYPAIaDC > 0; OYnmpBnUPYPAIaDC--) {
            continue;
        }
    }

    if (VcFtZcO == true) {
        for (int gCMoGvSzC = 1743595769; gCMoGvSzC > 0; gCMoGvSzC--) {
            EtBfVzdg = gtKYLnekwkzI;
            EtBfVzdg = VcFtZcO;
            EtBfVzdg = ! gtKYLnekwkzI;
        }
    }

    for (int vuSGkbOTgGL = 499015762; vuSGkbOTgGL > 0; vuSGkbOTgGL--) {
        QLrapoWB += WFHsZpOc;
        EtBfVzdg = gtKYLnekwkzI;
        WFHsZpOc = WFHsZpOc;
        EtBfVzdg = ! VcFtZcO;
    }

    return -118918.36375034227;
}

void eCqjBBAJmesVZkFj::smTIRRCOfdp()
{
    int yNCPIhYG = 900864591;
    string ExnPVqzaJM = string("cjbBnAwYhmlNkFFJyMcyUkFlyEOHRRzACiJYqnPFbTmhMUvrpmxgQvbolNcKlewqYrHmwVEQEbNHpWbpxJvmuDqlRYxYYUETpkdQOpobLNYukbzwZmlSaAJNQpHaNFI");
    double gFbdtthMeHc = 804846.8581574541;
    int QWBxB = -2067551734;

    if (QWBxB != 900864591) {
        for (int RrdPYmyRWdiU = 1809714125; RrdPYmyRWdiU > 0; RrdPYmyRWdiU--) {
            gFbdtthMeHc -= gFbdtthMeHc;
            ExnPVqzaJM = ExnPVqzaJM;
            ExnPVqzaJM = ExnPVqzaJM;
            yNCPIhYG *= yNCPIhYG;
            ExnPVqzaJM = ExnPVqzaJM;
            QWBxB /= yNCPIhYG;
        }
    }
}

bool eCqjBBAJmesVZkFj::SMEFwqBBhG(double RAgeDsjtr, int TlDQahLsgHgUR)
{
    int qfdfIic = -1819699929;
    bool AausrkmPCzlhfDN = true;
    int DLDzrpiBO = -1790963651;
    bool SCUvDCo = true;
    int dWuaKPSlDHvlcpg = -793314450;
    bool SteDtpOgHQYOxJt = true;

    if (dWuaKPSlDHvlcpg <= -793314450) {
        for (int wwsepIyllLeMZFr = 2125987381; wwsepIyllLeMZFr > 0; wwsepIyllLeMZFr--) {
            continue;
        }
    }

    return SteDtpOgHQYOxJt;
}

string eCqjBBAJmesVZkFj::rWjAvrBl(bool LQhbzybinrRKogd, bool rWUITykUVFicSV, double Egeddvthcpegy, int ZNtTEgKSVrmDJUP, int dbRAF)
{
    string caKyqXLXUTfvHXL = string("ptWiGmJHqRwiIXRWXiyKlLDcNVKeGBaMobxsVRFQkmkWVdMtjcHRWBhAIJLGwTQIJpdbOIqTZneSVZgTKHhjfGeYKYMXXvqFAlnvxDTZpNuQXYALyQmDjPoMcVNJthNtrkEjQkpboCqvLghrzNoSckgpIJgQNSGGBHfczltJDnGcNUGeAbKgAvgbeUNaveOuCpYqtdKSWXqQgm");
    int esUEpHx = 607418044;
    double oeqzbnx = -783558.9866213846;
    double mSaHscK = 212341.91411619834;
    bool UeivosCSiXzAoR = true;
    string zhLtJfJN = string("bTQxANtsWnxOrqfLdiPXvumvteb");
    bool NzJnGtGMnCSD = true;
    double NVVoFhwde = -201730.8529842547;
    bool RjfBOei = true;

    return zhLtJfJN;
}

int eCqjBBAJmesVZkFj::sXVBLExsTVgaGUh(bool OGfRGb, string IPTqhrvsW)
{
    bool ffGmSkLvvM = true;
    string AQUqdKlIIXQ = string("tvRVTOqmVGMNljDXjaFfBDUNWDkcnVjBMMdbNPHybPSsNkQNWXaHDOzhRHZstVYHZDBcZUkIwptXYPhwcghiCNGgJOCdhuelmZBCKlcPDxvNrEjQXvmwcINGaUXGPnKOkMJwiNVhbYwBMLbqYLWxsPtiqOsoQEMOPpVTFCaWWMflIlEnpAiXsifDlJyLOOHUdhZgZsPZNmhkaWfRP");

    for (int ZKcyABElMkXm = 1354177343; ZKcyABElMkXm > 0; ZKcyABElMkXm--) {
        continue;
    }

    for (int VClnWEm = 1164784001; VClnWEm > 0; VClnWEm--) {
        ffGmSkLvvM = ! ffGmSkLvvM;
    }

    for (int mcQILi = 1600371634; mcQILi > 0; mcQILi--) {
        ffGmSkLvvM = OGfRGb;
        ffGmSkLvvM = ! OGfRGb;
        ffGmSkLvvM = OGfRGb;
        IPTqhrvsW += AQUqdKlIIXQ;
    }

    if (AQUqdKlIIXQ != string("tvRVTOqmVGMNljDXjaFfBDUNWDkcnVjBMMdbNPHybPSsNkQNWXaHDOzhRHZstVYHZDBcZUkIwptXYPhwcghiCNGgJOCdhuelmZBCKlcPDxvNrEjQXvmwcINGaUXGPnKOkMJwiNVhbYwBMLbqYLWxsPtiqOsoQEMOPpVTFCaWWMflIlEnpAiXsifDlJyLOOHUdhZgZsPZNmhkaWfRP")) {
        for (int jKZQrjXsrJhjlwFm = 868984813; jKZQrjXsrJhjlwFm > 0; jKZQrjXsrJhjlwFm--) {
            IPTqhrvsW += AQUqdKlIIXQ;
            AQUqdKlIIXQ = AQUqdKlIIXQ;
            OGfRGb = OGfRGb;
        }
    }

    if (OGfRGb != true) {
        for (int RRIVKaXg = 1176347468; RRIVKaXg > 0; RRIVKaXg--) {
            AQUqdKlIIXQ += AQUqdKlIIXQ;
        }
    }

    for (int nZHADWzIUwhmCqmZ = 807903922; nZHADWzIUwhmCqmZ > 0; nZHADWzIUwhmCqmZ--) {
        AQUqdKlIIXQ += IPTqhrvsW;
        IPTqhrvsW = IPTqhrvsW;
        IPTqhrvsW = AQUqdKlIIXQ;
        ffGmSkLvvM = ! OGfRGb;
        IPTqhrvsW = IPTqhrvsW;
        OGfRGb = ffGmSkLvvM;
        ffGmSkLvvM = ! ffGmSkLvvM;
        IPTqhrvsW += AQUqdKlIIXQ;
    }

    return -1986337644;
}

int eCqjBBAJmesVZkFj::nqlzePfmI(bool GxliTcxu, string ExUCdTGpBXIJVz)
{
    double TjSQAtvjyI = -593070.0512762063;
    double vpPkxm = -434098.34920901613;
    int LZCGjvrufnehHN = 778007414;
    string akmLZBrhsgEyEPck = string("bCgApQlmKRMzAzvhMabIpCJbUaFktcEtXbPvlrzGzYXgCWJLwuLTYbUSGYkeQEqSZGNGmniCqNfLgQleHqWnjeotqrvIhUOuEBAA");
    string qNOwmD = string("kbNjkEOtlhOhPHzPasqBbAndTcFvmDPdLavrXdRkVgiKlnfyQQToQgEsTRKHRZZiYYqDAFLiMPgvkYWNKDqDDxeUkHcGezbIbWoJQaZrxwVKOUuNyNWEWOGwotdzGEVHGpOEMVPzMmeiXNQbUVeyqeoOyZRYdySOsSigNRzlqRckEgOHEIuDSCaAxm");
    bool AySliVRAMIU = true;
    string suiVyaDYlCfkQl = string("kLEPWcTAPOeYqsHuQkebWazvEUJXmTPbgwZssGifcwXNYGeIFgWaXgikcPyCQpyxRkoKblBZXCNlKtmCniCgDCYOejdeKZoyeWU");
    int WpQWYR = 2019997409;
    bool BWRGTZIcKMPRrswj = false;

    if (BWRGTZIcKMPRrswj != true) {
        for (int OlxqLbrxAwIufc = 1364446963; OlxqLbrxAwIufc > 0; OlxqLbrxAwIufc--) {
            qNOwmD += qNOwmD;
            qNOwmD = suiVyaDYlCfkQl;
        }
    }

    if (TjSQAtvjyI == -434098.34920901613) {
        for (int uTzPQoIvZf = 297121627; uTzPQoIvZf > 0; uTzPQoIvZf--) {
            akmLZBrhsgEyEPck += qNOwmD;
        }
    }

    if (BWRGTZIcKMPRrswj != true) {
        for (int nGUkPRhcMDTzhaX = 792066422; nGUkPRhcMDTzhaX > 0; nGUkPRhcMDTzhaX--) {
            WpQWYR -= LZCGjvrufnehHN;
        }
    }

    for (int ZjUGa = 1965010826; ZjUGa > 0; ZjUGa--) {
        suiVyaDYlCfkQl += suiVyaDYlCfkQl;
    }

    if (qNOwmD < string("bCgApQlmKRMzAzvhMabIpCJbUaFktcEtXbPvlrzGzYXgCWJLwuLTYbUSGYkeQEqSZGNGmniCqNfLgQleHqWnjeotqrvIhUOuEBAA")) {
        for (int SgPDczMPJhzDVe = 1409642431; SgPDczMPJhzDVe > 0; SgPDczMPJhzDVe--) {
            suiVyaDYlCfkQl = akmLZBrhsgEyEPck;
        }
    }

    for (int UWtxwwf = 289998698; UWtxwwf > 0; UWtxwwf--) {
        continue;
    }

    return WpQWYR;
}

int eCqjBBAJmesVZkFj::jPGmK()
{
    int fMldDAkufqsK = 1579451698;
    int xjShsXYMjqzQ = 1448621979;

    return xjShsXYMjqzQ;
}

void eCqjBBAJmesVZkFj::LDJBbSrruAXX(string YYgSdQMfwfKbGXm, string ELrXkMo, bool PheAbqfUKY, double gqLuJ, int CextxztmFsIddIq)
{
    bool MUZLK = true;
    string vbnAqEbjjTzft = string("RqqNDdyQxoUrctudiqiQmEMwlJrbPRjBFyJAhaNA");
    bool gjSFCtDqYRo = true;
    double wxaEIXSJT = -785534.2870812836;
    double TfSmvZIJLRBd = 952239.9766899128;
    int RqtazoHdjFEL = 2095528087;
    double nCrNtyVXtYiLmF = -595608.9418153905;
    double zvhuEhSbRdHYnsYK = 86109.46999680366;
    string jEKXJnpDiV = string("UmtOgkFgbazSvjUWpUfidmDGLlruewUlrihnZQalrSCpOVIWCbVBVTfZWsjaIHTrrTahErRYEzytBZkGgDEejCxUSqjRBhJqkzzSzXHLenIDSifIobkfEVgNXhGogWSraJEFYsisjiZRrZJjLHFiiKAepPivMFNiudgIPPHjfrgtxWhCMDRXehndaayEeSBQfWNWGJTAlPHJbJFnCkpoSFssowUxNEYOsoGgCZLROhBnMBxSMVXDZlGzty");

    for (int ktiPgcPmZ = 2111660804; ktiPgcPmZ > 0; ktiPgcPmZ--) {
        vbnAqEbjjTzft += vbnAqEbjjTzft;
        PheAbqfUKY = ! gjSFCtDqYRo;
        vbnAqEbjjTzft += jEKXJnpDiV;
    }

    for (int okqBvalqA = 1523820850; okqBvalqA > 0; okqBvalqA--) {
        wxaEIXSJT = wxaEIXSJT;
    }

    for (int uEbygJktOZsS = 1401202049; uEbygJktOZsS > 0; uEbygJktOZsS--) {
        continue;
    }

    for (int ubcHnezmVFH = 1705860875; ubcHnezmVFH > 0; ubcHnezmVFH--) {
        nCrNtyVXtYiLmF += nCrNtyVXtYiLmF;
    }

    if (vbnAqEbjjTzft <= string("UmtOgkFgbazSvjUWpUfidmDGLlruewUlrihnZQalrSCpOVIWCbVBVTfZWsjaIHTrrTahErRYEzytBZkGgDEejCxUSqjRBhJqkzzSzXHLenIDSifIobkfEVgNXhGogWSraJEFYsisjiZRrZJjLHFiiKAepPivMFNiudgIPPHjfrgtxWhCMDRXehndaayEeSBQfWNWGJTAlPHJbJFnCkpoSFssowUxNEYOsoGgCZLROhBnMBxSMVXDZlGzty")) {
        for (int IaQtZpBYFptLs = 353871236; IaQtZpBYFptLs > 0; IaQtZpBYFptLs--) {
            nCrNtyVXtYiLmF = gqLuJ;
            TfSmvZIJLRBd -= gqLuJ;
            gjSFCtDqYRo = ! gjSFCtDqYRo;
        }
    }

    for (int FhzNvlhI = 1889764339; FhzNvlhI > 0; FhzNvlhI--) {
        TfSmvZIJLRBd -= nCrNtyVXtYiLmF;
    }

    for (int zEWAN = 731274646; zEWAN > 0; zEWAN--) {
        continue;
    }
}

double eCqjBBAJmesVZkFj::yrOvYE()
{
    double dOcMvUeyZheelVg = 628216.6948207216;
    int satibtVLOS = -128473191;
    bool fxKgsPq = false;
    int EJrbtToOH = -1176130117;
    bool UVEyLnPvnrO = true;
    int wiVVK = -478798791;
    int eueSmTnKxDmz = 1828276486;

    if (eueSmTnKxDmz <= 1828276486) {
        for (int pEuSqx = 1809239591; pEuSqx > 0; pEuSqx--) {
            eueSmTnKxDmz /= eueSmTnKxDmz;
        }
    }

    return dOcMvUeyZheelVg;
}

int eCqjBBAJmesVZkFj::WZRICfVVZpdBj(double OYaRzIaHpdo)
{
    bool ntEUEgOas = false;
    bool SuUAkqv = false;
    bool SiTdIgzZ = false;
    double dtODjhwlhSCjetxG = 499957.70978366904;
    double wzfYIlFxtgVB = 145047.74322353728;

    if (OYaRzIaHpdo <= -62828.033474692376) {
        for (int fWJBjPVCqVWT = 237988354; fWJBjPVCqVWT > 0; fWJBjPVCqVWT--) {
            dtODjhwlhSCjetxG *= OYaRzIaHpdo;
            wzfYIlFxtgVB = dtODjhwlhSCjetxG;
            OYaRzIaHpdo = OYaRzIaHpdo;
        }
    }

    for (int NfrXHWkhwKyw = 2002492631; NfrXHWkhwKyw > 0; NfrXHWkhwKyw--) {
        dtODjhwlhSCjetxG *= OYaRzIaHpdo;
        SiTdIgzZ = ! ntEUEgOas;
    }

    if (dtODjhwlhSCjetxG >= 499957.70978366904) {
        for (int DBFYZY = 445840613; DBFYZY > 0; DBFYZY--) {
            continue;
        }
    }

    return 1574087539;
}

string eCqjBBAJmesVZkFj::zfgebXGSI()
{
    bool UicNlwweTuWO = false;
    string ziLPw = string("xuQZyjsHaRTzChKhRqvEOLRbCWlBnSGKCBuzHxWzVkosXMTjkOvxLmWMFJTnzFMYuveLgMorUrhGrRgXHbEGSIQZwRjparGIuAPYKDouYrEqogQnceQXYZpSffcsYzDwBxPYznaaFeRNTMUTjbbUDipjWyMdJOBpMNcNsVdqnPOifPKcFruczDQMUWrPXWgTnTMQlccVWyGtAwVvCzohsnRzxmbDIHizEQU");
    double auCzUdfNIZP = 712391.3504360431;
    string wqoXEFX = string("sxKoMPJTiLtGxOwIASNEcUfwPaCWHrjlIBjwonnjGVVPiyyWZKupJeaWH");
    double xyDJXMBJAeQ = 291059.8536254915;
    string hWWAjhP = string("OFrlPRcrFtsccMvEasXRWgQbroAcu");
    string XkJMKhU = string("QYICyvuwQAirGTVYKbqXrvJalztHaGXzJRuxeCDAIIpLDCuWbVGvYOZfYxsDXmZmYffEYQesTRotgWPnLeQNOJyVNcSkLgQpUmaDzhROCmUrYQgSaZdrlKQnaViShcenXbhgDdcjusFMeupHvzRxbDkqlawpvcwIjpoUsodmFVzJLvCStdGzSqHpJYRmBwzz");
    bool eqXNJLfCGrYl = false;
    bool kHwwjILKyrci = true;

    for (int qvoJIZ = 1370001464; qvoJIZ > 0; qvoJIZ--) {
        XkJMKhU += XkJMKhU;
        XkJMKhU = hWWAjhP;
    }

    for (int vSgbLKABWnSfXwsv = 122642203; vSgbLKABWnSfXwsv > 0; vSgbLKABWnSfXwsv--) {
        UicNlwweTuWO = ! UicNlwweTuWO;
    }

    for (int ocRSvui = 71593533; ocRSvui > 0; ocRSvui--) {
        eqXNJLfCGrYl = kHwwjILKyrci;
        eqXNJLfCGrYl = kHwwjILKyrci;
        XkJMKhU += XkJMKhU;
        kHwwjILKyrci = ! UicNlwweTuWO;
        UicNlwweTuWO = ! eqXNJLfCGrYl;
    }

    if (auCzUdfNIZP != 712391.3504360431) {
        for (int JNMpAqXjLkM = 1539398476; JNMpAqXjLkM > 0; JNMpAqXjLkM--) {
            wqoXEFX = ziLPw;
            eqXNJLfCGrYl = ! eqXNJLfCGrYl;
            XkJMKhU += ziLPw;
            XkJMKhU += hWWAjhP;
        }
    }

    for (int mRymlKcvOjDoz = 858520383; mRymlKcvOjDoz > 0; mRymlKcvOjDoz--) {
        eqXNJLfCGrYl = ! UicNlwweTuWO;
    }

    if (auCzUdfNIZP != 712391.3504360431) {
        for (int YRaOXZakPLjI = 1943032672; YRaOXZakPLjI > 0; YRaOXZakPLjI--) {
            continue;
        }
    }

    for (int biqbSkGI = 964919713; biqbSkGI > 0; biqbSkGI--) {
        XkJMKhU += hWWAjhP;
        wqoXEFX += hWWAjhP;
    }

    for (int bwyKJpYcvu = 47702568; bwyKJpYcvu > 0; bwyKJpYcvu--) {
        wqoXEFX = XkJMKhU;
        kHwwjILKyrci = eqXNJLfCGrYl;
        kHwwjILKyrci = ! kHwwjILKyrci;
        kHwwjILKyrci = UicNlwweTuWO;
    }

    return XkJMKhU;
}

string eCqjBBAJmesVZkFj::OoRNavsDhJ(double DUwYMNhHGLfBGaT, string aBEcjwgOhktLBbXh, int oyxZOknNhMTG, string ELVRSzJWe)
{
    string ERTWb = string("geYaHsAneQQuafokgNcJZAxDdqhnNkebbjSkXwuwMbnKBRYdVkNA");

    for (int xyRsuDlUYojRXRWe = 1773623326; xyRsuDlUYojRXRWe > 0; xyRsuDlUYojRXRWe--) {
        ERTWb += ERTWb;
        aBEcjwgOhktLBbXh = ERTWb;
        ELVRSzJWe += aBEcjwgOhktLBbXh;
        ELVRSzJWe = ELVRSzJWe;
    }

    for (int pbrruwWo = 1319573474; pbrruwWo > 0; pbrruwWo--) {
        DUwYMNhHGLfBGaT += DUwYMNhHGLfBGaT;
        ELVRSzJWe += ERTWb;
        ERTWb = ERTWb;
    }

    return ERTWb;
}

eCqjBBAJmesVZkFj::eCqjBBAJmesVZkFj()
{
    this->znxhEsNKwv(-785946.5497065138, string("gXVGMmYrmodFzVFHiUgRFGMmaimGFNCMqiOsXMAUylqkiQOqtwhkpMPaSLUxKaRWNDIunnpjpTOmTLEUOrtAriOBoIZZymCuYjCARTKePqHYuHKYsdLFeSJoVddLXzupaEdmIIDteeWTiMBXVUUnZSFxfcRYGDBAKjzSrmKWhkURCGhQbMdhezfMQtelUmawwbiXeKdowOwlCzEtXRxuPjiaHwYRwSVjihvNbaduxFuFiTkYnrPlMgTjCq"), false, false);
    this->osMiLrw();
    this->hQliWsERoxWjD();
    this->smTIRRCOfdp();
    this->SMEFwqBBhG(439112.003280201, -314162719);
    this->rWjAvrBl(false, false, -1018375.5700386136, 419463585, -1980533343);
    this->sXVBLExsTVgaGUh(true, string("zPxKuWCCRsXUCRYsaGQKf"));
    this->nqlzePfmI(true, string("cwegDPHcjDvjIwadjLmgHPM"));
    this->jPGmK();
    this->LDJBbSrruAXX(string("sSZLbmXTTfnkHmdHtTqGfBFTSjdwLUhWsoilUSuArIUYjXfAnTxFTGOkoJwPXUdlNzFgTsvmFLpwLBjCbnVbhVhBhrYBGFglbxqENaudAADivNctdvBqMLOlNHUhhJSDThciMsCOeoBGwQjzOoDFAWfGvNLHyRuDNUbgKEcoKeCnDyTnYwBOMgcqmoYghGIxJN"), string("fcEnplXrINBLbOcbQHjFgRWCUAsGZThCXzkxKUWzFuyawYXoCsbxzKJAALDBylUbGkPJsskUIZjEfoBxKQVdbsoqHsWpUgSSLopdtMxRMayOIHsrMrbhYlUnjEzrAUprHsMO"), true, -506716.7229391885, -836643478);
    this->yrOvYE();
    this->WZRICfVVZpdBj(-62828.033474692376);
    this->zfgebXGSI();
    this->OoRNavsDhJ(904833.8391386466, string("GRXMCNrBPcjQzZLwrtcCjuLVPdAFLcNSpueecSSmqgRhCMEyUtfJKj"), -455395699, string("xpQrfXNvrhfgJMqtFttilQNJmXfstuxJZBnLMBJKEQZzZnLixIjGHfeWqoF"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MckounnZQwh
{
public:
    double dNQXgwlKmCXJYE;
    string nTOIJNgNJgabB;
    string OzgiAVOOMPXKc;

    MckounnZQwh();
    void AxQQLr(string XPSkxQwk, double WRmpbl, string zhuikYvMyMLGNq);
    double jeZPMaqaEt();
    double NrKMwoYRg();
    double YkDkILSwTav(int IGtxZC, string qWwSsjBDsC, double lLyoHwamxXZCIz, double YrTMlyYDsOboRH);
    double xaKFDymJWxJYY(string dwTIcI);
    void wBgkxBxokGtPPub(double mAMaUbHXY, int uArlhLcjShAtcQV, double pjmoXTALdYHOY, string jUvLIpMpHFm);
    double CstNGjMQfT();
protected:
    int zRZMojxtPXbvGtF;

    string oxVXzHtzCjN(bool DosAwij, double eILrsMCJVOQ, bool ydJieHMMWI);
    int byNYTbPDXGBRlw(bool xizayrhB, double YvJPkNaOjLsDw);
private:
    int bOIbK;
    string DycvM;
    int FFppBQRNJt;
    bool omstheRcqzKDH;
    double EqtjhmBUat;
    double WQTUsWbFXAG;

    void YmcFnzUmUp();
};

void MckounnZQwh::AxQQLr(string XPSkxQwk, double WRmpbl, string zhuikYvMyMLGNq)
{
    bool bvsJfHARdYhTsEb = false;
    int ORBNLXnRxuuTkX = 1151757692;
    int PvAltDlSeUt = 1012315068;
    int ELsChJvccDDnZ = 110697136;
    bool oEDjXdQjrzoa = false;
    int GSWPl = -607117708;
    int yTouGEPFIzJxQkeP = -497541388;
    double EBZWmwJlZLh = 782154.7935267695;

    for (int yvuyqXgIAM = 84734813; yvuyqXgIAM > 0; yvuyqXgIAM--) {
        continue;
    }

    for (int zdgmAYxupxLxyF = 1775196713; zdgmAYxupxLxyF > 0; zdgmAYxupxLxyF--) {
        GSWPl += ORBNLXnRxuuTkX;
    }
}

double MckounnZQwh::jeZPMaqaEt()
{
    string yCssKCskDgrUwFX = string("RcZXJEWFgVoFdwpaAvXCDQkzHiLnJmZFBCmLgUZMkzCExesbwuDcFMLXsNnBPauYOXfzLFLZtWJdURBEYHCVQVsGGfJBTLpSvjSoJvKxTBPohiNtUhUutqUdmJQzgUxGPLrGUaLfsyQtqMBbpyNrOBilPZmjjHKWolB");
    string MleiOPvvsBNYMVO = string("xSjsvGkRpgvJVQVrWswDxXNLtszsjSQopBRUsDdAermRonGjASwIcLWJIokWWFcMJqTmUhCSyizPWBCtasaunCAEcUsYIKMApogfiBijaIw");
    string zNVzifCLBGUb = string("NscdqOsQmCFbwgUruEGIrkjqktNmOOIyGufomtgNazdSMFcfzQrpoWcDUNZIrihSlewfXWhZeMnSfJxMxMagrkpuffvgXwgzRZjMkdymcWqzjdfZYthkiOSjHtEZcxCjEBLOcOCAjO");
    int kIRKxHj = 1986548709;
    bool LLzpK = false;
    int ATqGPf = 89588338;
    string txIhxiXKMRSEw = string("eePZPuDBoSXswgzxAzwXJyvAlbAXvKgvHbsRBXuGMZjtpRflLHrmxHeOyKVtycfebcoDXlZbWpYPZLOQdRUQsXjRkXFrZeZYqTOXnEXKoTKWCwcLBclSouCVtmtEvYHVdRcvRbHuzGNZBgZENxelrDbPJituIqIyOoxBiSi");
    bool NilaeGRYdjPjea = false;

    for (int calLOICSuHL = 627879950; calLOICSuHL > 0; calLOICSuHL--) {
        NilaeGRYdjPjea = ! NilaeGRYdjPjea;
        txIhxiXKMRSEw += zNVzifCLBGUb;
    }

    for (int MfCrFR = 2014744386; MfCrFR > 0; MfCrFR--) {
        continue;
    }

    if (kIRKxHj > 89588338) {
        for (int BOKRBfJV = 1270272547; BOKRBfJV > 0; BOKRBfJV--) {
            yCssKCskDgrUwFX += yCssKCskDgrUwFX;
            txIhxiXKMRSEw = txIhxiXKMRSEw;
            ATqGPf /= ATqGPf;
            txIhxiXKMRSEw += zNVzifCLBGUb;
        }
    }

    return -1040968.7399979383;
}

double MckounnZQwh::NrKMwoYRg()
{
    int uCRdZzyN = -1339750294;
    int xzDbitbBP = 258205063;
    string oKZWxXBRrGfm = string("ksvvVoeFVMaJlvbacgRHbRpGQyAECxofjfHsVrdyjwpLGPgXEthEHihbjbQiUaVFznvANHYTnIDKjveOhclGMufgBkrNEypnplTRpAxjTqyICzgWUmpQWvmQjauypgeMsaGqANbCiiNhjEnIzKUceIJlLcuFUwSyBnwAZQERLfjkpBSbmrRBfUDSUyXrttzNmFkZvVatlY");
    double WyquAGDxDps = -1027635.7584414463;
    string KoIbyUDu = string("CBgNfusKgXrkTqgynnCYPpKBxBNsXXICGuFYPtqrkBXoKykSwuIeolzncyFuIcdgfilqNFdKBJpgkIRVlMcniiZKcwPBPKerpIDVPTXL");
    double OfMstmbWgPvknmE = -856692.3484739802;

    if (oKZWxXBRrGfm < string("ksvvVoeFVMaJlvbacgRHbRpGQyAECxofjfHsVrdyjwpLGPgXEthEHihbjbQiUaVFznvANHYTnIDKjveOhclGMufgBkrNEypnplTRpAxjTqyICzgWUmpQWvmQjauypgeMsaGqANbCiiNhjEnIzKUceIJlLcuFUwSyBnwAZQERLfjkpBSbmrRBfUDSUyXrttzNmFkZvVatlY")) {
        for (int FAcXpZKiWCzuz = 635242794; FAcXpZKiWCzuz > 0; FAcXpZKiWCzuz--) {
            continue;
        }
    }

    for (int MgsNRd = 1614150136; MgsNRd > 0; MgsNRd--) {
        OfMstmbWgPvknmE -= WyquAGDxDps;
    }

    for (int lLtDnlDy = 939250608; lLtDnlDy > 0; lLtDnlDy--) {
        xzDbitbBP += uCRdZzyN;
        KoIbyUDu += oKZWxXBRrGfm;
    }

    if (xzDbitbBP > -1339750294) {
        for (int Oqmrijlxx = 564179748; Oqmrijlxx > 0; Oqmrijlxx--) {
            WyquAGDxDps *= WyquAGDxDps;
            WyquAGDxDps = OfMstmbWgPvknmE;
            xzDbitbBP *= uCRdZzyN;
            KoIbyUDu += oKZWxXBRrGfm;
        }
    }

    return OfMstmbWgPvknmE;
}

double MckounnZQwh::YkDkILSwTav(int IGtxZC, string qWwSsjBDsC, double lLyoHwamxXZCIz, double YrTMlyYDsOboRH)
{
    int MukdYcBvNORg = 1690345894;
    double dbkWjmuFMxXMLluu = 62707.012880360606;
    int mhMWcwRqZESpkVi = -1379825162;
    bool cFqFrfAcx = true;
    int NZPwOSJEn = -1990619219;
    int UWDhEjwVJ = 2040019918;
    int XYMIqT = 35319785;
    string GtmAQ = string("mhOpOvrHgSJMMtOFOvayCajpVBsQeqznTYIHQxlhseRZQuPHaJiHzmqOlNoEfdLglkRDjekgrCFBpAClwbZksVjshOFkqyDlrJOgYaCZlpquHPlAxeiLXhHgwrDitNCmFkeZFhEEhDJDkq");
    string RYZfO = string("ztlJeramIKIPGdOZLQCCjwCkTdwCzopzNzNUttcBKBxiRVzLelVgUCSTVLdQamvhWiZQyFembITGnpZsetlAccsaOnhmKDCIAlSHLewnUQBCKYyqnvOowLvhKEiwCroLcvuLtKQOgAUZbNKFGaujet");
    string rMngNjrOhRhO = string("LbpvhxsgwxIuWaTnZmxIlRQaTjqQkXeXtJfmDObdgRvlfkpklrqEqWHmUSllntmabwBVgyIFacsccbzKExkGvLmtoKaldmTambsTxMGsrxGgiAEqudoFdOVNWETcQRUUgOhSOCSXNtdcIYPKagUKTYhWvpwnwStfHAaOwsMcmcSdFlkKAKzBTnTQriNjhnpBTtXdVVGNVRPfvFElarMkbrhdMPhqfKtsFIBwvIAedhRlYHJfHZymjImOHyrDbD");

    for (int hTSuBOEWknwMKD = 2010163786; hTSuBOEWknwMKD > 0; hTSuBOEWknwMKD--) {
        mhMWcwRqZESpkVi *= UWDhEjwVJ;
        YrTMlyYDsOboRH = dbkWjmuFMxXMLluu;
        NZPwOSJEn += MukdYcBvNORg;
    }

    for (int KFsDSYcYg = 439838924; KFsDSYcYg > 0; KFsDSYcYg--) {
        NZPwOSJEn *= UWDhEjwVJ;
    }

    for (int aHkzaao = 937672808; aHkzaao > 0; aHkzaao--) {
        continue;
    }

    for (int ydFBNRYEueUz = 1375922682; ydFBNRYEueUz > 0; ydFBNRYEueUz--) {
        mhMWcwRqZESpkVi += NZPwOSJEn;
        RYZfO += qWwSsjBDsC;
    }

    if (IGtxZC < 1690345894) {
        for (int xZohk = 381493323; xZohk > 0; xZohk--) {
            YrTMlyYDsOboRH *= YrTMlyYDsOboRH;
            NZPwOSJEn *= MukdYcBvNORg;
        }
    }

    return dbkWjmuFMxXMLluu;
}

double MckounnZQwh::xaKFDymJWxJYY(string dwTIcI)
{
    int ZdJbRmK = -1181690819;
    string mTDmVRsvnLuYQ = string("BxSorPtmAzyGqhcoBPZcivPFycBBJQxEooeiGzyKJANvAwfzbSsehyvPNYqUyZPIPtcmjoCycsmQcBbqlOwElzccVRpYfvBRTisWQdvEcWfbkoXqGiHjZNsJBeAkHSSJYiMHEMWyGKsMCqsIKsrtAuoNNsaQKPbhsfMPbfxhfBwzIqozMrXFjnLqFvtOBIVSTxjRWByfvUsGNRzzxffzzkmUFMcrnkXzDaApnZfwPuygjdqDvXjcWvzTNhfSKT");
    string NqWiclhOQ = string("tAQBQzHGYFgJxwDaRremBeElCPzlieDiAQBWhBWkOrdMzBJRrCbhxLBSnxjUQVTCjciXWicHkNMFIEGDhoiUTuOOBcryPkHsdeKvnmtupYygpDawsxsefnbpNMEaEeBxoxvaQMkNBvB");
    double mcuPmpBPSS = -58770.518083177136;
    int OOuxPvqCYhCAz = -347967615;
    string uXuzctcLVwM = string("hvWEuqoGsdoNxjbUlLPZVXVxQoLRNhbvfBTvwElntFN");

    if (mTDmVRsvnLuYQ < string("GnhRNWKiSWJcpieyXytKgIGwpUkzLnNjnWEmHsWIDRLfpEIBBXibHHvztPHiFdQpOILieBzkWXjCVuEffUcDEgoDqiGZtNbIXJQYaivZjHFXrOzzoaZHTsjqtFS")) {
        for (int skQZMsi = 1002203671; skQZMsi > 0; skQZMsi--) {
            uXuzctcLVwM += uXuzctcLVwM;
            uXuzctcLVwM = NqWiclhOQ;
            mcuPmpBPSS = mcuPmpBPSS;
            ZdJbRmK /= ZdJbRmK;
            dwTIcI = NqWiclhOQ;
        }
    }

    if (uXuzctcLVwM <= string("BxSorPtmAzyGqhcoBPZcivPFycBBJQxEooeiGzyKJANvAwfzbSsehyvPNYqUyZPIPtcmjoCycsmQcBbqlOwElzccVRpYfvBRTisWQdvEcWfbkoXqGiHjZNsJBeAkHSSJYiMHEMWyGKsMCqsIKsrtAuoNNsaQKPbhsfMPbfxhfBwzIqozMrXFjnLqFvtOBIVSTxjRWByfvUsGNRzzxffzzkmUFMcrnkXzDaApnZfwPuygjdqDvXjcWvzTNhfSKT")) {
        for (int ZXKhsiLBuvYTfD = 1794493367; ZXKhsiLBuvYTfD > 0; ZXKhsiLBuvYTfD--) {
            ZdJbRmK -= ZdJbRmK;
            uXuzctcLVwM += NqWiclhOQ;
            mTDmVRsvnLuYQ = NqWiclhOQ;
            dwTIcI += dwTIcI;
        }
    }

    for (int UZNjvhmRfpJbg = 460250360; UZNjvhmRfpJbg > 0; UZNjvhmRfpJbg--) {
        NqWiclhOQ += mTDmVRsvnLuYQ;
        OOuxPvqCYhCAz = OOuxPvqCYhCAz;
    }

    for (int toQfWoiOSdrvB = 1199267391; toQfWoiOSdrvB > 0; toQfWoiOSdrvB--) {
        mTDmVRsvnLuYQ = NqWiclhOQ;
    }

    for (int vGiwGAJNcPWqSxic = 2017253081; vGiwGAJNcPWqSxic > 0; vGiwGAJNcPWqSxic--) {
        mTDmVRsvnLuYQ = NqWiclhOQ;
        dwTIcI = dwTIcI;
        NqWiclhOQ = mTDmVRsvnLuYQ;
    }

    return mcuPmpBPSS;
}

void MckounnZQwh::wBgkxBxokGtPPub(double mAMaUbHXY, int uArlhLcjShAtcQV, double pjmoXTALdYHOY, string jUvLIpMpHFm)
{
    bool PPqAKpzRcQbLcbN = true;
    int yHkeKwC = 1084271590;
    int MipYumazdZoVa = -1816561156;
    bool GuTOnr = false;
    string xynXpnPCLUSbaCH = string("XUARenpEBzcNVfzRWeEyVcYFJsdzIXDwbBqSvAUTgdqenDZtQPJepBrzEZfGGUoInblwyMTTANFHDennnqhFMbmmJokMowgRsznSCpaNyAMkjJZBtyDSHNTlzOXtKLIBRsAaYUrAnNBzx");
    bool RlXQzonWwSM = true;
    string MtYufklyBMCiUF = string("KldxTicHsArjbndKXcSUmUdSyOIhPlxesvbiQLFyPpGlwvPWvxbLjxlkkPHLCoPCKWmAvLhbUhlSDhwooOLeKrsAbRgggjXHgaLfzRJDumunxmAATmKnhMJuGYHegAmpJbRLxnjQmwuHRGeiNsBMWmInqjWJcWTQpESzHdpumKieuATQwHFwxAlquLMojMPBfjhSKfmUCIInROI");
    double xdJuNWX = 501575.98867536575;
    double uzlsyLwG = 482343.73570746504;
    string qibiQcgtSFkzWzy = string("prNCTUhOIjAqNIbRhrmVCXVCYzblQUBXfAUpIRlkZWkBorTgzhQHsdGeTyufLtHyrsdSLoYqdEvTHxoaUiyZFddhcvGGvpDjiUQjROrhVlxSsuPAMickOjUFTHcSYBaMiHyEhvEXvDFTTAChKxQlBZylRSrhPSLOEjJbEMGEczuvZZGMDzfGDNjBaaciEJOzVgMUrOKYVSoenMxHHwYQnNYBzigNDQNpeFPHyGKQfZoYwAwseNdxEnsrlx");

    for (int AFYxWucKg = 1761882067; AFYxWucKg > 0; AFYxWucKg--) {
        pjmoXTALdYHOY *= xdJuNWX;
        qibiQcgtSFkzWzy = qibiQcgtSFkzWzy;
        pjmoXTALdYHOY += mAMaUbHXY;
        xynXpnPCLUSbaCH = xynXpnPCLUSbaCH;
        MipYumazdZoVa *= yHkeKwC;
        xdJuNWX /= xdJuNWX;
    }

    for (int JLSdVsO = 373309603; JLSdVsO > 0; JLSdVsO--) {
        MtYufklyBMCiUF += xynXpnPCLUSbaCH;
    }

    if (qibiQcgtSFkzWzy == string("prNCTUhOIjAqNIbRhrmVCXVCYzblQUBXfAUpIRlkZWkBorTgzhQHsdGeTyufLtHyrsdSLoYqdEvTHxoaUiyZFddhcvGGvpDjiUQjROrhVlxSsuPAMickOjUFTHcSYBaMiHyEhvEXvDFTTAChKxQlBZylRSrhPSLOEjJbEMGEczuvZZGMDzfGDNjBaaciEJOzVgMUrOKYVSoenMxHHwYQnNYBzigNDQNpeFPHyGKQfZoYwAwseNdxEnsrlx")) {
        for (int DTFXzSvuac = 1037109217; DTFXzSvuac > 0; DTFXzSvuac--) {
            qibiQcgtSFkzWzy = qibiQcgtSFkzWzy;
        }
    }
}

double MckounnZQwh::CstNGjMQfT()
{
    bool wEEnUhqUb = true;

    if (wEEnUhqUb == true) {
        for (int pmPcGedJOXb = 1970103766; pmPcGedJOXb > 0; pmPcGedJOXb--) {
            wEEnUhqUb = wEEnUhqUb;
            wEEnUhqUb = wEEnUhqUb;
            wEEnUhqUb = ! wEEnUhqUb;
            wEEnUhqUb = ! wEEnUhqUb;
            wEEnUhqUb = wEEnUhqUb;
        }
    }

    if (wEEnUhqUb != true) {
        for (int Xbmzuc = 1087309455; Xbmzuc > 0; Xbmzuc--) {
            wEEnUhqUb = wEEnUhqUb;
        }
    }

    if (wEEnUhqUb == true) {
        for (int SfDBgZGGvuVsZfXJ = 826902387; SfDBgZGGvuVsZfXJ > 0; SfDBgZGGvuVsZfXJ--) {
            wEEnUhqUb = wEEnUhqUb;
            wEEnUhqUb = ! wEEnUhqUb;
            wEEnUhqUb = ! wEEnUhqUb;
        }
    }

    return 831913.8637472593;
}

string MckounnZQwh::oxVXzHtzCjN(bool DosAwij, double eILrsMCJVOQ, bool ydJieHMMWI)
{
    double RbTqniqIjrfvVbM = -923411.8797820446;
    int hgaCQ = 1110553095;
    double RabCVBtksOnZ = 969330.2517330567;
    bool dAVeeWfldzQP = false;
    int FueIvby = 1834748584;

    if (RbTqniqIjrfvVbM >= 167599.027564487) {
        for (int DewiEoazR = 1571405274; DewiEoazR > 0; DewiEoazR--) {
            hgaCQ += hgaCQ;
            ydJieHMMWI = dAVeeWfldzQP;
            eILrsMCJVOQ = eILrsMCJVOQ;
            hgaCQ -= hgaCQ;
            DosAwij = ! dAVeeWfldzQP;
            DosAwij = ! ydJieHMMWI;
            RabCVBtksOnZ -= eILrsMCJVOQ;
        }
    }

    if (eILrsMCJVOQ >= 969330.2517330567) {
        for (int lcqDFYasVtzRwSOk = 1070376383; lcqDFYasVtzRwSOk > 0; lcqDFYasVtzRwSOk--) {
            DosAwij = dAVeeWfldzQP;
            eILrsMCJVOQ += RbTqniqIjrfvVbM;
        }
    }

    for (int gciqBMgUhK = 988386336; gciqBMgUhK > 0; gciqBMgUhK--) {
        hgaCQ = hgaCQ;
        dAVeeWfldzQP = ! DosAwij;
    }

    for (int mxkAycFR = 1377105158; mxkAycFR > 0; mxkAycFR--) {
        continue;
    }

    if (DosAwij != false) {
        for (int JGhVspXChtTiM = 1150735746; JGhVspXChtTiM > 0; JGhVspXChtTiM--) {
            hgaCQ *= hgaCQ;
            hgaCQ += hgaCQ;
        }
    }

    return string("p");
}

int MckounnZQwh::byNYTbPDXGBRlw(bool xizayrhB, double YvJPkNaOjLsDw)
{
    bool AIBapeBlJfh = false;
    double jZQlGWOCGtvVxwSc = 303880.94478972367;
    int xDxXOdeTaK = 1270904256;
    int lbioImkMEx = -569984716;

    for (int uCZYwSZAyUhpPi = 1827623676; uCZYwSZAyUhpPi > 0; uCZYwSZAyUhpPi--) {
        xDxXOdeTaK *= lbioImkMEx;
        YvJPkNaOjLsDw += jZQlGWOCGtvVxwSc;
    }

    for (int cThWptlWdiIkqOwB = 1285850866; cThWptlWdiIkqOwB > 0; cThWptlWdiIkqOwB--) {
        AIBapeBlJfh = ! xizayrhB;
    }

    for (int UpSoRpimJCaBY = 535912363; UpSoRpimJCaBY > 0; UpSoRpimJCaBY--) {
        AIBapeBlJfh = ! AIBapeBlJfh;
        lbioImkMEx += lbioImkMEx;
    }

    return lbioImkMEx;
}

void MckounnZQwh::YmcFnzUmUp()
{
    double LJbesqhRowy = 280183.3663514136;
    int SxUMBeOtYUjH = -1562767846;
    bool ZrHeVqmJyhr = true;
    string TwHunFiqzEm = string("lSZuzXIwwyMBPqRhDIWdTIPOAhtHV");
    int zwRgBrfgYih = 272221283;
    bool QGfOuW = false;

    for (int iCByWLwibUhgLjxS = 1008676929; iCByWLwibUhgLjxS > 0; iCByWLwibUhgLjxS--) {
        QGfOuW = QGfOuW;
    }

    if (QGfOuW == true) {
        for (int oafMCzpO = 81740541; oafMCzpO > 0; oafMCzpO--) {
            zwRgBrfgYih /= SxUMBeOtYUjH;
            QGfOuW = ! QGfOuW;
            ZrHeVqmJyhr = ! ZrHeVqmJyhr;
        }
    }
}

MckounnZQwh::MckounnZQwh()
{
    this->AxQQLr(string("IeJNxNmocMulTqfYvoZYzymWPzlCTJhPSpZeffNboiKlwnRCirsFsv"), 800752.8905811883, string("eGOxjMUVzsEXaJdBEVTqKFyFVaCrQIdghAkhQHhgvJhGIkQwgmNoAnWJWJsUeGJVIOdrSJFYuKql"));
    this->jeZPMaqaEt();
    this->NrKMwoYRg();
    this->YkDkILSwTav(-1481100594, string("pghBxORnNoVzljtRywxAbWtSAqoFTfVIcUMllGwZlvHfj"), -718538.0904959184, 680767.7271355453);
    this->xaKFDymJWxJYY(string("GnhRNWKiSWJcpieyXytKgIGwpUkzLnNjnWEmHsWIDRLfpEIBBXibHHvztPHiFdQpOILieBzkWXjCVuEffUcDEgoDqiGZtNbIXJQYaivZjHFXrOzzoaZHTsjqtFS"));
    this->wBgkxBxokGtPPub(889139.9199940937, 1529763892, 8256.662137794092, string("PUrRPkpxUUKGlzizTHwsQQyuSpUaUCYjQeYXigCFVnKauJnRwAKxHmUTpdCXlHbQqEWEgRWOJITwEmEpdfpgaTpxYzEgxqqiuVQHAPbwNbKthUIDIQfSWOpULXKiFLvDHCznOkWxRAUtBMEgyOeDFTFDdEfcAUAiDCsunqSuTEiuLYbs"));
    this->CstNGjMQfT();
    this->oxVXzHtzCjN(false, 167599.027564487, true);
    this->byNYTbPDXGBRlw(false, 925740.0386219609);
    this->YmcFnzUmUp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JxQFW
{
public:
    double TVgsgPefe;
    double cBOYDBwB;
    bool dYlEBSYPNfpGiZM;
    double yynzFXDmNooQeIY;

    JxQFW();
    int sSWPdJRfRWJGDrZR();
    string DUmtvOUmr(double vZQlGTuYfaauLb, bool SxDZqFT, string ERzNbmPbZASi, bool KKIGRtIycTu, int lMCfhofJwF);
    bool KSCtXwzPDVuWLS(double zceFl, bool fFdddotTHD, string ytsVfmKcjKbF);
    bool GUCpMcLv(string iLaYGLfODhX, double NciJmHHwJ, bool GNxbtIj, int uWhiKVO, int WFOjdODi);
    string cBaVJuTAQYv(bool utuApDZ);
    string lnsZzMmoE(string nufZBsC, double IjBdnoRlHdtSRcp, string OYajiGAFh, int EOnYhSGI, int XTvInTgIIoFJoG);
    double qhpkzpAVzDmwF(double EjhpM, bool AKQMWdUDCiPkEu);
protected:
    bool hRVlKWgf;
    int wuhqQpnVSHCgjGJ;
    int mmaCcNHAXq;
    string HuJLsB;
    double QMaZbxlknsEXD;

    double IbKGCa(string KQYFifku, double hffJJXWbWXGayLc);
    int BXpQslfcHwJcNxJ(double LVvUCOTWKBrThFaI, string wQTyFNkYty);
    bool MXsbWIRPDlpRpF(int lSiyIzjxMGirZfLV, int BjCThwwTXktbIrTq, int UwWIxiEqjxMUEn);
    int FmzNSLvJldyYYfA(double NSUbKYVPqyJdCo, string wjifgCePSPinf);
    bool yunApVi();
private:
    int NQUesGxFpLJ;
    bool bIrzhVKUiqLlC;
    int kKuGDwajIqaKnOG;
    double xfkObsDBDYGpeCR;
    string PYuBjjMqUZMOg;
    string xtERJzJ;

    void ClzCVZOytuFEw(int LKcNrlVbml, double Gzxnmf, double fOpWIgDImRECyxL, string npSQBLJoKDHiPl, bool ZLwAMzVhkBUxUWT);
    void JryDJrFNqJivdes(string mAzZCaqAyylW, double WsbSbijTUt, bool qePGNj, double zrskMnqztVnBijY, double ksjbUiYVxuYD);
    string qxiiPjtCGOd(bool jIlnpGKArmsPs);
    string QGCOhwu(bool xGWwCN, double lUWdwfnlb);
    double sBAWmvkDic();
    void zPWEzIDBHBJLBuPw(string HEelKfIs, double DVZtVknkFzjJyLGF, double xcUrXmocuu, int GjShlephPilLfc, bool hSTWdGVX);
};

int JxQFW::sSWPdJRfRWJGDrZR()
{
    bool OkTAT = false;
    string oXBfmTx = string("XacchGlGdZROhKOTKuLuFEyFcfrgNQCTzeKEXxwQcucDXxpAbOTYqPLAGaNZBZINdaSvJosfPBKJedMIhVTlRrKVMGaIjSxtlLiXzBWjaCQmaxURaeNkpgFiFoqpWS");
    string JylNVnpS = string("HiyE");
    string HMNouciTYWR = string("coMlHegOfbNqBOqSjpbbiNAyzhbmMjFqonkdFGguJBKqOxVsdtUqIpIBATNUjKrRzdsQakFhrzfsJbnqBFMpcUNAcaMYkgZRXvkUQKOSaXQBFkhoQtLBeospiPOspoxTiBLlErEuVnGMyoRyBaNrAweflbXNlhTMjPRNMVHXpCHfSBBDkTkdIkSCsTEtZCcnZnP");
    string pjvGpGiBvciVFA = string("IQjBqYYqZTwQzEqzLukKQHfsGDKMMFkdgUxnvsMHYMZBspZOhYpiVnvIIbmYRORDHQOiDalzLxlfcgucMhOoDSGXpyCIUzySbyBHwRutODDVgoFgzhintQYfFXQtNkMXwUTJUknJqP");
    bool uqqho = true;
    string aGhAf = string("QOGntDvhjlbLVXvrvKBupaPnyUHtKCQtzkpIZiJzFpkKrQuTKiLkAhORzgLzeyjGcrBXfcbdkEPKvdyrsOsfEhzFhAcAhraVLKYGQuGBfgyVcxLnLLtxcZbp");
    double bLMwZtRsZGuMehPB = -744711.2002264292;

    for (int DERDpZPCqW = 663998167; DERDpZPCqW > 0; DERDpZPCqW--) {
        oXBfmTx = aGhAf;
        OkTAT = ! OkTAT;
        oXBfmTx = pjvGpGiBvciVFA;
        oXBfmTx = pjvGpGiBvciVFA;
    }

    for (int UxlxxuRdaiSoJB = 458211058; UxlxxuRdaiSoJB > 0; UxlxxuRdaiSoJB--) {
        pjvGpGiBvciVFA += oXBfmTx;
    }

    for (int veHfktGNvKiUsOku = 308875373; veHfktGNvKiUsOku > 0; veHfktGNvKiUsOku--) {
        pjvGpGiBvciVFA = oXBfmTx;
        HMNouciTYWR += aGhAf;
    }

    if (aGhAf != string("coMlHegOfbNqBOqSjpbbiNAyzhbmMjFqonkdFGguJBKqOxVsdtUqIpIBATNUjKrRzdsQakFhrzfsJbnqBFMpcUNAcaMYkgZRXvkUQKOSaXQBFkhoQtLBeospiPOspoxTiBLlErEuVnGMyoRyBaNrAweflbXNlhTMjPRNMVHXpCHfSBBDkTkdIkSCsTEtZCcnZnP")) {
        for (int AZLkZlicgjD = 686064045; AZLkZlicgjD > 0; AZLkZlicgjD--) {
            HMNouciTYWR += oXBfmTx;
        }
    }

    if (pjvGpGiBvciVFA == string("HiyE")) {
        for (int ftbaL = 1325311913; ftbaL > 0; ftbaL--) {
            aGhAf = HMNouciTYWR;
            pjvGpGiBvciVFA = HMNouciTYWR;
            pjvGpGiBvciVFA += oXBfmTx;
            OkTAT = ! uqqho;
            oXBfmTx = oXBfmTx;
            oXBfmTx = JylNVnpS;
            JylNVnpS = aGhAf;
        }
    }

    return -2000546042;
}

string JxQFW::DUmtvOUmr(double vZQlGTuYfaauLb, bool SxDZqFT, string ERzNbmPbZASi, bool KKIGRtIycTu, int lMCfhofJwF)
{
    bool fjuqRgjO = false;
    bool bmkZofYTHxOtI = false;
    bool oXzLETdVzZYg = false;
    int KtPWsmHNsgPFPZ = -1139811452;

    if (bmkZofYTHxOtI == false) {
        for (int cgUXmRJRiOL = 444768306; cgUXmRJRiOL > 0; cgUXmRJRiOL--) {
            continue;
        }
    }

    for (int vqIdmXhaBB = 1590722025; vqIdmXhaBB > 0; vqIdmXhaBB--) {
        bmkZofYTHxOtI = ! KKIGRtIycTu;
        KtPWsmHNsgPFPZ += lMCfhofJwF;
        fjuqRgjO = oXzLETdVzZYg;
        fjuqRgjO = ! oXzLETdVzZYg;
        fjuqRgjO = SxDZqFT;
    }

    for (int lJeownvHudKTW = 597045634; lJeownvHudKTW > 0; lJeownvHudKTW--) {
        lMCfhofJwF = KtPWsmHNsgPFPZ;
        fjuqRgjO = bmkZofYTHxOtI;
        lMCfhofJwF *= KtPWsmHNsgPFPZ;
    }

    for (int JJFfV = 1844711472; JJFfV > 0; JJFfV--) {
        fjuqRgjO = oXzLETdVzZYg;
        oXzLETdVzZYg = ! fjuqRgjO;
        oXzLETdVzZYg = ! SxDZqFT;
        fjuqRgjO = ! bmkZofYTHxOtI;
    }

    return ERzNbmPbZASi;
}

bool JxQFW::KSCtXwzPDVuWLS(double zceFl, bool fFdddotTHD, string ytsVfmKcjKbF)
{
    double xeZlFRoupqFWVB = -56910.54354697343;
    double FwpEUxGAAuhoxqiI = -81438.46442978324;
    int LcUajobzzsubS = -219638417;
    string ojjrqS = string("jeRnbWUzHnvrAoAVpLWhYMHxIrqdNw");
    string yRgoUQbEIAzF = string("NRheAULZWVYhDAUkMBcResgUMyKzTYPGkVCcgDuWvsVFcOcztbOCwMLQtBCWqZEtLujHsuDfDRtmEWspCsyRPRyvQPMnevjEypLUUpfazoKApPyALRKrpzGYSbwQMYspwALmHDMchlzLyFVWmXouDHHbVzAklJzojZjtXFQXqGplnmuJrpXhjjKNphAYEiWZmtWkZUzGhPCPIpraNGBKyssViivpAAkwRwaxZh");

    return fFdddotTHD;
}

bool JxQFW::GUCpMcLv(string iLaYGLfODhX, double NciJmHHwJ, bool GNxbtIj, int uWhiKVO, int WFOjdODi)
{
    double ihleYtwdxiSy = 134119.96512659607;
    bool IwTKCyQjD = false;
    int nhXnw = 801511043;
    int irveXnHc = 621225286;
    double OSaussABXnPE = -523400.06651795417;
    double NJzTR = 519067.96853696386;

    return IwTKCyQjD;
}

string JxQFW::cBaVJuTAQYv(bool utuApDZ)
{
    bool jDzzApPlxnm = true;
    bool RYMDbOpAsMdYq = false;
    double vKXSGFjIvkKeSAZL = -971450.0454820982;
    double GVEnocaklCd = -250598.16292282534;
    string WuHFOzq = string("xvvGakkpwJlIobPHbjMmRljbbSiRKGRCmObznYsEAgHGXEzJXSXuJYiWydwECZYlEcqyNHeNjqwIqkLekEYjwejNijRHrCDkmmmdZcGrGVBbnFqzcZIHPNUxNRjJnupXBLGZAwUAVCJRuIrCuFIuJNJzfFKNbkCqchOAH");
    int tPzTVMmQH = 441738017;

    if (tPzTVMmQH > 441738017) {
        for (int rSPkyeJXkDp = 680636582; rSPkyeJXkDp > 0; rSPkyeJXkDp--) {
            jDzzApPlxnm = ! utuApDZ;
            tPzTVMmQH = tPzTVMmQH;
            jDzzApPlxnm = ! RYMDbOpAsMdYq;
            RYMDbOpAsMdYq = ! RYMDbOpAsMdYq;
            jDzzApPlxnm = RYMDbOpAsMdYq;
        }
    }

    return WuHFOzq;
}

string JxQFW::lnsZzMmoE(string nufZBsC, double IjBdnoRlHdtSRcp, string OYajiGAFh, int EOnYhSGI, int XTvInTgIIoFJoG)
{
    double uqrZS = 518646.0601854035;
    double JXYhNUvJRCYqXOj = -634019.4463810791;

    for (int TUUoAAWpO = 792346395; TUUoAAWpO > 0; TUUoAAWpO--) {
        JXYhNUvJRCYqXOj *= JXYhNUvJRCYqXOj;
        XTvInTgIIoFJoG /= XTvInTgIIoFJoG;
        OYajiGAFh += OYajiGAFh;
        XTvInTgIIoFJoG /= EOnYhSGI;
        nufZBsC += OYajiGAFh;
        nufZBsC += nufZBsC;
    }

    return OYajiGAFh;
}

double JxQFW::qhpkzpAVzDmwF(double EjhpM, bool AKQMWdUDCiPkEu)
{
    bool LGmmgDvqexIBQG = true;

    for (int KQPrl = 1790168528; KQPrl > 0; KQPrl--) {
        EjhpM += EjhpM;
        AKQMWdUDCiPkEu = ! LGmmgDvqexIBQG;
        LGmmgDvqexIBQG = LGmmgDvqexIBQG;
    }

    if (EjhpM == -1019612.8389860367) {
        for (int akNXedFgBk = 1646170914; akNXedFgBk > 0; akNXedFgBk--) {
            AKQMWdUDCiPkEu = ! LGmmgDvqexIBQG;
            LGmmgDvqexIBQG = ! LGmmgDvqexIBQG;
            AKQMWdUDCiPkEu = AKQMWdUDCiPkEu;
        }
    }

    for (int HWhFwfr = 1970071449; HWhFwfr > 0; HWhFwfr--) {
        LGmmgDvqexIBQG = ! LGmmgDvqexIBQG;
        EjhpM = EjhpM;
    }

    if (EjhpM == -1019612.8389860367) {
        for (int DHSsGWVeakquM = 484242294; DHSsGWVeakquM > 0; DHSsGWVeakquM--) {
            AKQMWdUDCiPkEu = LGmmgDvqexIBQG;
            LGmmgDvqexIBQG = AKQMWdUDCiPkEu;
            EjhpM += EjhpM;
        }
    }

    if (LGmmgDvqexIBQG != false) {
        for (int qgHjAOdGZP = 1455275556; qgHjAOdGZP > 0; qgHjAOdGZP--) {
            EjhpM /= EjhpM;
            LGmmgDvqexIBQG = AKQMWdUDCiPkEu;
            LGmmgDvqexIBQG = LGmmgDvqexIBQG;
            AKQMWdUDCiPkEu = LGmmgDvqexIBQG;
            LGmmgDvqexIBQG = AKQMWdUDCiPkEu;
        }
    }

    return EjhpM;
}

double JxQFW::IbKGCa(string KQYFifku, double hffJJXWbWXGayLc)
{
    int PKPwYGShXGXXYpgW = -394190563;
    bool RtOVTwxohBSm = false;
    double mOqztscSCEf = -897707.3932539955;

    if (PKPwYGShXGXXYpgW < -394190563) {
        for (int jItBHZ = 1092656249; jItBHZ > 0; jItBHZ--) {
            PKPwYGShXGXXYpgW = PKPwYGShXGXXYpgW;
            hffJJXWbWXGayLc *= mOqztscSCEf;
        }
    }

    return mOqztscSCEf;
}

int JxQFW::BXpQslfcHwJcNxJ(double LVvUCOTWKBrThFaI, string wQTyFNkYty)
{
    bool DxbrtoneITJ = false;
    int ROGXwN = -402745784;
    double CVLvxvXTwFuVp = -495491.2013547769;
    double FoFGMQUAPggAUnaf = -840190.4180759599;
    double scpfuveuxqg = -187518.65519257545;
    double mHssXrT = -934826.9423340263;

    for (int lfrmrJL = 1187658059; lfrmrJL > 0; lfrmrJL--) {
        CVLvxvXTwFuVp -= scpfuveuxqg;
    }

    return ROGXwN;
}

bool JxQFW::MXsbWIRPDlpRpF(int lSiyIzjxMGirZfLV, int BjCThwwTXktbIrTq, int UwWIxiEqjxMUEn)
{
    double KsPah = -700859.6132666577;
    double uNcFdsLPMOve = -595910.619844275;
    double cNIUyNLFCkfrBzz = 41001.639405404094;
    bool jXshahyxIz = true;
    int HMcdnpJd = 1334875499;
    int svWLBw = 1946302463;
    string PwrGIiXq = string("dNBtOprHWjZTNplwwYSoFoVOhFhTzBVGCzQaNIgaWQotSzpDkImywahBBHWxZNRdNgcYnIKbQgxawWiojsNJAkCeaNEMSvVHRBJmgmFalTvHbCzUsuVqUrhCNpSWLFOUMgglzKkJezphVXJntgDAdgLOT");
    bool qLTfTKOWdMMrrhg = false;
    bool XytQFzp = false;

    for (int ywhgJeqLQliE = 2050987296; ywhgJeqLQliE > 0; ywhgJeqLQliE--) {
        continue;
    }

    if (HMcdnpJd <= 320778247) {
        for (int skgDVlqJp = 1519819168; skgDVlqJp > 0; skgDVlqJp--) {
            BjCThwwTXktbIrTq += svWLBw;
        }
    }

    return XytQFzp;
}

int JxQFW::FmzNSLvJldyYYfA(double NSUbKYVPqyJdCo, string wjifgCePSPinf)
{
    int YgmoHoULWw = -1735731445;
    string tWThlJZQzUtLZaTE = string("QBISOTYhIwysUhFzCRTQHjAGTKdxOOeIJJvJKoDwJVrwmaunivlBsqjyoAfNvUDdBTNmKwIsvITsoutCzdfPVUjFq");
    double JfNMGRKechdd = -413388.01300227206;
    int GegSTscBsmFpYlhF = -1946114699;

    if (tWThlJZQzUtLZaTE > string("tyYqWyEsdivXhBolLGJvhPbieVHOmumRFFKDxGl")) {
        for (int hkQcxvQkZNJlVtZ = 912311901; hkQcxvQkZNJlVtZ > 0; hkQcxvQkZNJlVtZ--) {
            wjifgCePSPinf = wjifgCePSPinf;
            GegSTscBsmFpYlhF -= YgmoHoULWw;
            wjifgCePSPinf = wjifgCePSPinf;
            YgmoHoULWw -= YgmoHoULWw;
            wjifgCePSPinf = wjifgCePSPinf;
            YgmoHoULWw -= GegSTscBsmFpYlhF;
        }
    }

    return GegSTscBsmFpYlhF;
}

bool JxQFW::yunApVi()
{
    int ZZABxEbbHbzmOi = 821062449;
    int mzJBPf = 384720213;
    string ggrFWhN = string("MroHCGRYTTBAWCHVOQDazavKEoMGzFQOcCgRvZnHJAGNsQQSjMQiVfWxEnzZAbRLtbSVynfRKQHsPPlGHsMlmPoskjlLYIKVgaCkUUaQNHNLsOQKvtyGOSdyVVGvxKSxIpDlWQvqqpTcWuJwaVITHrgwrlNUvJruBvaIyxTquMAMDetJKHMYWfmJzIUvHptsyoGXkSxrrUxitdWRIQsuCQKLDdNRbarPzWKDzAtuiNThmscFSvOrtu");
    string VMKOYhNIhbxg = string("ROEJLTKYXNunhJIeROBavvSPfttGIdtCgvsBEIxgYrIyCLZkkUrgquYFtoFypObpWvyKdBggEzsQ");
    string mxSgveqyhNEju = string("aNVpQLXoEOxrgDVDhLfoXnTUVzhgKUBKlXFPpSPHzwJNKbEBdaxBaxRHXUgtmKasdPRPtuHnRXLojxKJCXkcHsFcbuhRlkeTcTBkIPsUQuRCZVKoFMWUuZPcOnrrGgmCiBUbXdvvxHSCbxaprdAZLwsHiLTUP");
    bool kRjyOu = true;
    int EZzJzlDCIhtHu = -1148662861;
    bool lKIHzjCvgewh = false;

    for (int ajqHzsifLWY = 314078676; ajqHzsifLWY > 0; ajqHzsifLWY--) {
        mzJBPf -= ZZABxEbbHbzmOi;
        VMKOYhNIhbxg = ggrFWhN;
    }

    return lKIHzjCvgewh;
}

void JxQFW::ClzCVZOytuFEw(int LKcNrlVbml, double Gzxnmf, double fOpWIgDImRECyxL, string npSQBLJoKDHiPl, bool ZLwAMzVhkBUxUWT)
{
    bool jGEMfdjJmWTFVT = true;
    int hDEaSxA = -767803853;
    bool ktNZyJE = false;
    int wKaixqbZYbHqKvr = 1086567505;
    int QPKEiPhf = 784109696;
    string FHmMUgTbIC = string("FziDkJa");
    string wPFDLYRfres = string("ClMSRRHFdXfWUWwRa");
    bool gGlWgQUOPqNm = false;
    bool ynuIUDT = false;

    for (int vxDLXEH = 550966310; vxDLXEH > 0; vxDLXEH--) {
        ZLwAMzVhkBUxUWT = ! ktNZyJE;
        jGEMfdjJmWTFVT = ! ZLwAMzVhkBUxUWT;
    }
}

void JxQFW::JryDJrFNqJivdes(string mAzZCaqAyylW, double WsbSbijTUt, bool qePGNj, double zrskMnqztVnBijY, double ksjbUiYVxuYD)
{
    int jwupDgEfMb = 1986250779;
    bool KLhGXZvtlAhkWxHw = true;
    string eAtJK = string("IaEAchEKMkPmghwtuMawPJiJQZCBPojGyEimXqGfrtKCWCfAyomTjnuSDtjYdpsxrGQQObKFCbohjAWWpkGXyOYkdrYrdyBfjrIzqROQEyqtTNZsqWRMljAMBWTXSVScQAyqZT");

    for (int VVrwsNuwLXTrhWyr = 1074101729; VVrwsNuwLXTrhWyr > 0; VVrwsNuwLXTrhWyr--) {
        continue;
    }

    for (int nejcnPwfXXOA = 730874852; nejcnPwfXXOA > 0; nejcnPwfXXOA--) {
        continue;
    }

    for (int PfTnowjHjcMU = 789724425; PfTnowjHjcMU > 0; PfTnowjHjcMU--) {
        eAtJK += eAtJK;
        zrskMnqztVnBijY = WsbSbijTUt;
    }

    if (eAtJK < string("MXxWtUdPLVqDYFaxubDtXrAjvRxgNPKoNopBPMxXyExEjFmPCumqKqeydyQMmXrGOhyUnSRBKzrjlcthAJnUmIAIkFpyGObmoMRIRccAvZJvJUsSUlwIKqOBHUqxjEqsIOdkGAnAlIRhliAszMtMXZXLkyPjttJdGgXjEkjznpUHBttDOyAiCOSyDQASwWJuGMecaRuBARzHiFIHxseSQoGtzeFWabxyWyqnqqnsClxGZwPBAJkuCA")) {
        for (int blnEvUwLENsf = 1177015932; blnEvUwLENsf > 0; blnEvUwLENsf--) {
            qePGNj = KLhGXZvtlAhkWxHw;
            WsbSbijTUt *= WsbSbijTUt;
        }
    }
}

string JxQFW::qxiiPjtCGOd(bool jIlnpGKArmsPs)
{
    int qNOojQBlbSPKzv = 1906351296;
    int vwhrpKp = 343687430;
    bool FiEZXVvyLt = true;
    string uUWkiRiJX = string("BsCiCYWryJQtxQwcVnlaPzaxXxQhhPmnIuIEtVDfqjLSeDEnYrDPjDMgWJFuFvZlIXVDOGcMkBnPwFatkqLjlsPwDSkivWDwpCxaosOeGwDZcTCilWdSypjlZFYqZPnlPhVklLtxmoIryZdkcrWxevFyZ");
    string YZIfpza = string("edLLGOMbvNPjCshkB");
    int gXuInIfsg = -385911407;
    int rEvykB = -140127088;
    string psiWHxnZVkDod = string("oZkdwhSqnndPcVkzr");
    string hSNrhrOLidVGgeJa = string("VmYwxBSiokGlfJPzNFxJVNqMchLLMghnupNx");
    double cXPsNJQhjKpLuKRK = -833935.6627179182;

    for (int SFpNLZgYjOHDjqkl = 2030261638; SFpNLZgYjOHDjqkl > 0; SFpNLZgYjOHDjqkl--) {
        continue;
    }

    if (hSNrhrOLidVGgeJa == string("edLLGOMbvNPjCshkB")) {
        for (int zzMVwmwRm = 464946278; zzMVwmwRm > 0; zzMVwmwRm--) {
            psiWHxnZVkDod = uUWkiRiJX;
        }
    }

    for (int Loegcn = 1998633181; Loegcn > 0; Loegcn--) {
        vwhrpKp /= vwhrpKp;
    }

    if (hSNrhrOLidVGgeJa != string("edLLGOMbvNPjCshkB")) {
        for (int ndbwNhhJdKyaHmoy = 1275429126; ndbwNhhJdKyaHmoy > 0; ndbwNhhJdKyaHmoy--) {
            continue;
        }
    }

    for (int oJZoBvXuuXg = 1347001160; oJZoBvXuuXg > 0; oJZoBvXuuXg--) {
        continue;
    }

    return hSNrhrOLidVGgeJa;
}

string JxQFW::QGCOhwu(bool xGWwCN, double lUWdwfnlb)
{
    double idGiaPfKFYCY = -914841.7973587342;
    string mmqQR = string("VefysdIHYWUPfuqybfpKHCqbbdJOYlXP");
    string lBCyDniYfD = string("ANeSGgzsLHTntYaLyAUXDrjNsccjVXuYTEDNPfMiLhAHwjIigBMeLnZSZFNnufFXwRoaJIVfUznsPohvlhQVRsqBdKJNsXSIVVhNtzKlrofueFiArdFhZaKWVIzeSwUhGPFbYrKzpSqp");

    return lBCyDniYfD;
}

double JxQFW::sBAWmvkDic()
{
    bool LNBLUPJltUp = true;
    bool MpnOiihrYUiL = false;
    int xCDRF = 643865268;

    return 650555.265128265;
}

void JxQFW::zPWEzIDBHBJLBuPw(string HEelKfIs, double DVZtVknkFzjJyLGF, double xcUrXmocuu, int GjShlephPilLfc, bool hSTWdGVX)
{
    int OxwogxwyYyUL = -480981939;
    string BMaxILPmLqhAdCf = string("nUpojtBzRUplteYgDOZJkexETLqhaDbapqXfwPfemrWOQkBPVixlCXyMDekqPayRwYumrIWnINihXeIRYdhOGpHfLeYqkPTdyTqUIEaoOzxYPMvJXsbGDCFjNxeJLZdnejRNzGnArBfttFpBlhshrJgtGngIyDGHbY");
    bool mFQLdpwAwMeOVfO = true;
    bool FkHNMJqgFQzeb = false;

    if (mFQLdpwAwMeOVfO == true) {
        for (int qsikwdQwqfTF = 1330753053; qsikwdQwqfTF > 0; qsikwdQwqfTF--) {
            FkHNMJqgFQzeb = ! FkHNMJqgFQzeb;
        }
    }

    for (int dJXMDxLjcTEVEjhl = 147173865; dJXMDxLjcTEVEjhl > 0; dJXMDxLjcTEVEjhl--) {
        mFQLdpwAwMeOVfO = ! hSTWdGVX;
    }
}

JxQFW::JxQFW()
{
    this->sSWPdJRfRWJGDrZR();
    this->DUmtvOUmr(-635902.2611475344, true, string("ipkCshCxEotqQTnZhKanzfHaqkYvLoKIGdsWzdzCStLTBiCQCumRvMtDGiihyRzdaKbvLkUHTFcOcwmFiMaqyzqvxnDBUtSlkMHfmucPUOlzOPqWdCQcmSfWHjAqJagipQzJ"), false, -2053584447);
    this->KSCtXwzPDVuWLS(864805.6256112275, true, string("LpoIlPzGnetyzfCDyozfJKVDTJkOUwEOfNOmiqYxDChYuGzPyUjWsSUkNcxZrVkQKdeTUhRUEXGcNXOXjXqSKgjcofWLDOeKVlosuzrqrkhASwzyRbttcPXAbWneeUFnynbQSFIThwoRPABmJLbaQtSoAijLeaEgDSrcPCofKuPiGPEqRXQtAuBKwpXbGiBYBZtkQwRqhwbjbEKoFFJkTwMGSKVtavTprHQwpgjzScjPXIajNEItiKnosaVkwi"));
    this->GUCpMcLv(string("qNwFZBzigsWoagCZeWdOrfpyTQMhkJzNljOPptjxIUWnXqlkgGFjHsboeAYtsKgwZqytfFRFacJrezWznApnHDCvlvcmUanyrhHHSIzstOXeYglxUWvbbKPtGvqshukDEtkGLOYycpcamZqokVvcQyheRopztVWaCP"), 242826.35494579645, false, 1729272493, 1886039275);
    this->cBaVJuTAQYv(true);
    this->lnsZzMmoE(string("mOTUtJbSGodhMKYEpveeaCjLISiuddTjrqFVMbUnDaNDVcISZEHaExghxa"), -843710.6915073917, string("sAjzA"), 1878293224, -645702157);
    this->qhpkzpAVzDmwF(-1019612.8389860367, false);
    this->IbKGCa(string("uhFyjIjHpKulJFWgVVJQuhKXnzjopZOKMyiAKobVufVVscEyjqcErOCNCtxORtYlpGirxpDFaVcutKS"), -754202.7598268299);
    this->BXpQslfcHwJcNxJ(-424959.0818377191, string("SSNVoCtTOMxOvRXeGzeQqaXlgNyGavMyUbJTTFdAgDWMUtUVgvIzqdVHXlSXkeoo"));
    this->MXsbWIRPDlpRpF(-1355262445, 1397807613, 320778247);
    this->FmzNSLvJldyYYfA(659567.9995410497, string("tyYqWyEsdivXhBolLGJvhPbieVHOmumRFFKDxGl"));
    this->yunApVi();
    this->ClzCVZOytuFEw(-49346984, 397619.6274652593, 971987.8350681032, string("djZOCLMworpLfyHNGDRMyyqFISHBUflYvAwgHCMnbonuitlKrtLqmOJVjURokqFgATxpXVgFfGJMwhNkZvYcOeldaiRpkzIKUbiiERMplVSgqwtmgywWLbZrqyPjNm"), false);
    this->JryDJrFNqJivdes(string("MXxWtUdPLVqDYFaxubDtXrAjvRxgNPKoNopBPMxXyExEjFmPCumqKqeydyQMmXrGOhyUnSRBKzrjlcthAJnUmIAIkFpyGObmoMRIRccAvZJvJUsSUlwIKqOBHUqxjEqsIOdkGAnAlIRhliAszMtMXZXLkyPjttJdGgXjEkjznpUHBttDOyAiCOSyDQASwWJuGMecaRuBARzHiFIHxseSQoGtzeFWabxyWyqnqqnsClxGZwPBAJkuCA"), 804694.1169617404, true, 336412.35597366624, 437205.47044739756);
    this->qxiiPjtCGOd(false);
    this->QGCOhwu(true, -789045.9904920473);
    this->sBAWmvkDic();
    this->zPWEzIDBHBJLBuPw(string("MZMPzMPALNQhFiKaytujeidMWQRJmRZdILCuoJeaNeyGGtUCHijegQpIIwtiSdfISGmuAIUvFoFtZzsHTwSoNFOMKgchSjhYJXCXJaMsSNdPRsOwfBPrZTtqQmUEkEwFTyDcNSJPlncPmkZtAqrsvADkOLEnQpQbyahkTBROiaAmlkVNDMTLhPfjZKdDLsvtiomSbxDJuSTpvrOfjofTQ"), -922807.5837413684, -687236.8426062512, -209688474, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BzxdwnUTWQSPR
{
public:
    string oLGbdJQpnzaxrmbT;
    int pYMWKwpvOFiy;
    bool JhjvYkixEd;

    BzxdwnUTWQSPR();
protected:
    double omynZxwDfviA;

private:
    double hfdJGqAcNgNU;

    double oxfyNZYBGm(string cBDExHl, int agCeoeLeSRYjA, double lSGjUYwVBGxIYsBq, double MJgocIZNxPPRIQc, double alagOZlWxBYM);
    bool kiIAuHKmSCC(int BeODdpyZCuRAT, bool yWGLbzTeWGk);
    double ASkDCAzirF(int VprHRVCjrt, string iVYHjox);
    bool XNOtCBIzXag(int BEMFuUUOcJmQF, int upXmdkbwcysLKiY);
    double EbkPiUbBW(double RaELaQE, string BqZtmxmXmmMRTmP, double qIXUTAyNJAJYrQgx, bool pbdMptzzwiSOmD);
    string HApiITNUJb(string IUFFOzUespx, bool IHtVTbZoc, bool ioEJqhBmy);
};

double BzxdwnUTWQSPR::oxfyNZYBGm(string cBDExHl, int agCeoeLeSRYjA, double lSGjUYwVBGxIYsBq, double MJgocIZNxPPRIQc, double alagOZlWxBYM)
{
    string fcUKtwNaNwcQ = string("SwCvPfeZAwHdaOQyUYCeQhLtrl");
    bool mVMrbPLSKmYDGre = false;
    double ycTQTdaTCAr = -855118.5441694069;
    int MHvgOl = -1189925371;
    string uIJatDlyYDIkX = string("bMEGIArIgHBxFWHZVExsahwOBMaOnOrCgslNeZejPqDlysVAuJQEtXvdaZZCweqYpmLHcvkoxNnSSfBYapEnFRzxLEAEmVrAkToLhCORUpSDdflywMxFDqdaQyfXOAOtBPxaSSrUKxjvQdRXEovbMOzbtsMlzWSfDLOGXOYJUXIxkqioSxE");
    int qrufIaT = 1404439797;

    for (int pAXZHvf = 843002367; pAXZHvf > 0; pAXZHvf--) {
        continue;
    }

    for (int nlVTkgpIWBletR = 1669364927; nlVTkgpIWBletR > 0; nlVTkgpIWBletR--) {
        continue;
    }

    return ycTQTdaTCAr;
}

bool BzxdwnUTWQSPR::kiIAuHKmSCC(int BeODdpyZCuRAT, bool yWGLbzTeWGk)
{
    bool ZgSoUg = true;
    bool vuvFFMQwvbAuvl = false;
    string MBCouoaWH = string("whIQgSIVrIxCxxbvDCyEtMCcAFXAnmPShOYfnHxtcgenDSNMAspXKjJRfyHwDlHGImxLDccbxiZSGAKXLCuivvPTElGIRXyrzJcLvesQKFbLzplxYWFJCiBGworETsrjpDFKrdhXytPzEbzhsBCYjnhcSZAQayeJwcgYsoSiLEgbJQKiHUnjubKhIRlzZfBzrXbSrMKaagOFayhNDAaLyycsuCeoJBMOaAkWxjddIUcpc");
    string FClkAdUBhFtZUxfT = string("yimboyhXIjZoirGUZTmcNmNUDSBpDlNKEPFFbpedQHpLhWYtRqNwlrNFYJveDinhDSGrcSCqKTaGmpmBSoJMuuwMURpdzcXkRyOEyIEtYiOzsmywlCoYcjkJZHwvAYdLNQZUGGlJfswJkMmFiMPpZsDKbbFTZIqceauwDFjChNTklZBCboCfPPcdIddcKKYdQOincZubuAap");

    return vuvFFMQwvbAuvl;
}

double BzxdwnUTWQSPR::ASkDCAzirF(int VprHRVCjrt, string iVYHjox)
{
    int bIYCZTObdPyJkP = 627613801;
    double aMHLtvzPcIfO = -386824.15392282925;
    bool xeWqwf = false;
    bool sFwDybBaqwmRY = false;
    double sZNvUm = -911968.2652032019;
    double CuMkYuKpQsftjRrU = -914947.9467000865;
    int IcZSBWymDAJIQ = 335675085;

    return CuMkYuKpQsftjRrU;
}

bool BzxdwnUTWQSPR::XNOtCBIzXag(int BEMFuUUOcJmQF, int upXmdkbwcysLKiY)
{
    double TzkbQgI = 439663.4536823853;
    int qOUdXhc = 1941602920;
    bool widuxNTxGlNAo = true;
    int cdvvvxhN = -316732241;
    bool heLHzfgnE = true;
    bool spdqdcVj = false;

    for (int QazdPeQcvhzMo = 797783704; QazdPeQcvhzMo > 0; QazdPeQcvhzMo--) {
        continue;
    }

    for (int BXNctlYGCrZi = 68944021; BXNctlYGCrZi > 0; BXNctlYGCrZi--) {
        TzkbQgI += TzkbQgI;
        TzkbQgI = TzkbQgI;
        upXmdkbwcysLKiY /= upXmdkbwcysLKiY;
        upXmdkbwcysLKiY -= qOUdXhc;
    }

    for (int LaYEEdbGnAuS = 1712546387; LaYEEdbGnAuS > 0; LaYEEdbGnAuS--) {
        continue;
    }

    for (int NdndFhwRLvML = 439330169; NdndFhwRLvML > 0; NdndFhwRLvML--) {
        cdvvvxhN -= BEMFuUUOcJmQF;
        spdqdcVj = spdqdcVj;
        BEMFuUUOcJmQF -= BEMFuUUOcJmQF;
        spdqdcVj = widuxNTxGlNAo;
        spdqdcVj = ! heLHzfgnE;
        heLHzfgnE = widuxNTxGlNAo;
    }

    return spdqdcVj;
}

double BzxdwnUTWQSPR::EbkPiUbBW(double RaELaQE, string BqZtmxmXmmMRTmP, double qIXUTAyNJAJYrQgx, bool pbdMptzzwiSOmD)
{
    bool flqoqLCcQlQQ = false;
    bool MhwZFECMbyAWi = true;
    int PKrgnrWMoE = 2104058807;
    bool GCxxLcMHBWdKCOY = true;

    for (int XWLXFqQyNgynVy = 774792446; XWLXFqQyNgynVy > 0; XWLXFqQyNgynVy--) {
        continue;
    }

    if (MhwZFECMbyAWi != false) {
        for (int JyMTEG = 460138927; JyMTEG > 0; JyMTEG--) {
            flqoqLCcQlQQ = ! pbdMptzzwiSOmD;
        }
    }

    for (int QiLmLeSS = 1448233094; QiLmLeSS > 0; QiLmLeSS--) {
        GCxxLcMHBWdKCOY = ! GCxxLcMHBWdKCOY;
        GCxxLcMHBWdKCOY = GCxxLcMHBWdKCOY;
        GCxxLcMHBWdKCOY = GCxxLcMHBWdKCOY;
        RaELaQE /= RaELaQE;
    }

    for (int jAALDGxAkhcSdjPv = 301447339; jAALDGxAkhcSdjPv > 0; jAALDGxAkhcSdjPv--) {
        MhwZFECMbyAWi = ! MhwZFECMbyAWi;
    }

    return qIXUTAyNJAJYrQgx;
}

string BzxdwnUTWQSPR::HApiITNUJb(string IUFFOzUespx, bool IHtVTbZoc, bool ioEJqhBmy)
{
    string XdnqCPiM = string("lFiXiyoURSFQDhgbcHzIvQMJBPYLivKlyNfCBGfBUIvUosbqnoqopUtEeXookRuKXWPNfiGkzBgHHmdRvGjwwWwVqItJcaaITlwNAInRsXoHuWCHTEPcnyYzPfQynplkMNUzTNqGfeKweEUOeaFxPNgeWMHSxgDDeGhtNFgRhCCHSXqiLKZKwFXWUjD");
    int qwdcHzzoFZdAMr = -1595529854;
    bool yLJKSSXorX = true;
    string deRlETFTJ = string("egmoxixpHpYgUDIQGXHZvnViLiZavYBBADspKnYIOjAGBdHLfnsfvfPIyQBIsnNDhZKWUXVdWUJIXyvBPeIsbBwvCOXOTThCBBSddAcysBrvrXxRUYoPxcBovIeYnxquOTmbIHklYROCSNwRZlmrMpofVPctoObmpsToDnMcOjGFIFWsUVeEO");
    bool YjoGENvkSnQfJ = false;
    string ZtDtolIIroiMECk = string("qUhcBoZemXtgbXVmQkxXriBgKKuzvqoIKXpkXiOfbgteAafcpGiaSiCuKBSzWQLSPXqLKslHodMqLqvZbogvxzYrOmRwwbtlmcgdWkmwKnkPhLnyYtiaSn");
    bool TnxGcDF = true;
    int uVziwPmvCFlrQ = -1602262091;
    bool xHoBRg = false;
    string UAUDCpZg = string("cdtcheXSCFTdyvPBZAOVViSXP");

    if (UAUDCpZg == string("cdtcheXSCFTdyvPBZAOVViSXP")) {
        for (int ZiLBaaMeZdh = 890518873; ZiLBaaMeZdh > 0; ZiLBaaMeZdh--) {
            yLJKSSXorX = ! YjoGENvkSnQfJ;
        }
    }

    if (IHtVTbZoc == false) {
        for (int NVVgfuUPBjMLO = 689295391; NVVgfuUPBjMLO > 0; NVVgfuUPBjMLO--) {
            TnxGcDF = IHtVTbZoc;
        }
    }

    if (yLJKSSXorX != false) {
        for (int WrqXn = 736210448; WrqXn > 0; WrqXn--) {
            ZtDtolIIroiMECk += ZtDtolIIroiMECk;
            XdnqCPiM = XdnqCPiM;
            deRlETFTJ = UAUDCpZg;
            XdnqCPiM = deRlETFTJ;
        }
    }

    return UAUDCpZg;
}

BzxdwnUTWQSPR::BzxdwnUTWQSPR()
{
    this->oxfyNZYBGm(string("nLASDjMYxxkofBFdGMuNNeQQYhGIqcGsqeEnKXXySMwtJIGMGgHUHMjGcejGXRZZZhwQHUQIijUWhCCvdnzazlyIezwvNaazCyfKuqHKsyejKnafFVrzckqvHxcfKeCoBGgonaWEudASKHVEpokxJBmZoradOpfQoc"), 121944779, 357914.7076170101, -83850.92119193698, -367430.399702638);
    this->kiIAuHKmSCC(-348201908, true);
    this->ASkDCAzirF(-1564842257, string("NsKderKbpxNXxqvzprvZTHoBeuablHrfWSWujadbRJDeavxPMOpqSayhdsxzyDhoCWEauHnTRODfabcAuyEetHcpESjrOHwSMufxNMfpiEqlHnPHdEKtJwhxrhrpExuuSuBTsmWVOUowoAJQeyvctemNHGSWyehRdjUBIY"));
    this->XNOtCBIzXag(858397729, 731067069);
    this->EbkPiUbBW(272238.7334621603, string("ExmxJAOyqleZvLYbnVzoIaRjrStiCJxweIxHcPvtYsqNkYgMhChnBTMXrGRwBiUMIE"), -422977.2636991147, true);
    this->HApiITNUJb(string("BvvMvipdrtqvlubjqXsGMhuKLyaMjhvZzUpRtHZoinLtwLqGVUwiaQtVBfPcxLsbIkFoGdfwSkNLQZuHeVIaEmtIsiZkhuVIGNaCbrPORXPwlqqGBdTvAFHcnmWqJgDHjHcncPREiMqBcktJxBLEHgxPEgxKdUvGrbstGLUQpcb"), true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uggJKOkP
{
public:
    int NnnVNF;
    string VroHOa;
    bool OlGQDxrSx;

    uggJKOkP();
    void cNjWBRIGpRqBmH(double mTFLJI, double ywScWXDpKDmXmYxR, string aXsPtPykNtgr);
    void gCNnJ(string uhnuCrAuIpGL, string IcDoqlNkxOsNUY, double GAfsIoHdYMoX, bool PQdWM, double gXmvQBAoOOC);
    void XAboTbjPluvstP(bool SOUFQorPK, string evJsT, int bFzxlFs, double TfBjfLWDokLSJ);
    double EfUNdpKxpOXVMY(string smgIgw, int oafqTj);
protected:
    int mdRgytsb;

private:
    int NdcnvbqgM;

    int bxXZYRKQmENtv(double uslShv, string nhfCiEwfJgD, bool lXEMEPUMjwT, bool iRSfGaCQUUSm, int iBOeBWGQni);
    string vcMIaTolzDyRVk(double VyqMmBfQPU, string KEoXlvl, bool EpdUbS);
    void DtwacfNuP(string CeeVOTgACige, double GiefroV);
    string dpbilZzC(int fWcwnZZFzlqo, string QOeCdTABe, bool BNKfJdFgbaR, bool ibubjQUvalKHt);
    int gGQZyjiTmhSLZvq();
    void CVoKmfmL(bool aLyGckeJq, double MGKxSrAOZbzKdeN, bool UxIeCBBxlYDhXs);
};

void uggJKOkP::cNjWBRIGpRqBmH(double mTFLJI, double ywScWXDpKDmXmYxR, string aXsPtPykNtgr)
{
    double dYzFayHKPWi = 452338.0077540749;
    string HyFxtK = string("yqIzdOJkWMmlXrCqWzzAsiKibqoUCkfEHDhzJyIPvOAOJckBDWMgpmKFqXoXBzwzIUVxuMICctBfLoBoGmMxHqpmMuucQPveaGCRawYOxOgyvVmUjQNLqNZXtRyXBNOvMTMfkJuayAExKLfEwBPJwuUBjQHabgjzpNaqvaHwcADcndcPiCtosjTZzcPwhIlCNFkRQjDsTpdqIBECIQuCqBse");
    string PxjiKmslXBxV = string("niMoJUfQCoyvNHBfZtzKRqtjKGLQpyMHYcuWYXMCsTHxdjjKrmdqYRJVgbRJytIqwFtMgiEOrCvBVkUKNQzuqUgoRfGCFRSvjsqNcZleGtZfbueeQSmaNRqTtOmXIuGiCPGTeIIXaABTdMvISEIMRhasQIzr");
    bool fczeoihsNKC = false;

    for (int jtkPvNgSdlzBAVny = 37760454; jtkPvNgSdlzBAVny > 0; jtkPvNgSdlzBAVny--) {
        PxjiKmslXBxV = aXsPtPykNtgr;
        PxjiKmslXBxV = aXsPtPykNtgr;
        HyFxtK += PxjiKmslXBxV;
        HyFxtK += aXsPtPykNtgr;
    }

    for (int FYszupM = 1018491982; FYszupM > 0; FYszupM--) {
        fczeoihsNKC = ! fczeoihsNKC;
    }

    if (mTFLJI < 538239.9465051439) {
        for (int pCBPtedbAZDCE = 845106933; pCBPtedbAZDCE > 0; pCBPtedbAZDCE--) {
            continue;
        }
    }
}

void uggJKOkP::gCNnJ(string uhnuCrAuIpGL, string IcDoqlNkxOsNUY, double GAfsIoHdYMoX, bool PQdWM, double gXmvQBAoOOC)
{
    double mgkVBEua = -800375.8422965399;
    string UIEuWgl = string("LteLBSOFCwNCDMKCavWYEBINKyLhqnBKRkIrC");
    string xXsvEmWSOMhcgOY = string("NFDXwGubKVMyQDBzkHCzHSFrjWLPUBnSqDqWXUyWWsaaNluDQWNoNKyQfmyzpcQSvlmYFLUvMjsRZvLLNIXIOJPJDEaLTdtHKHneBNvZReIGJabmqJiRRnQTioyGpMkSNslargAGrfIjLKnlqVpTZiQpyLwstGazvLBKveMxxYFkuWvnGkQ");
    double LwuyCH = -362513.00823286624;
    int jBqASRwueBO = -400732048;
    double bRTWMDDcWvfhhAlU = 2803.4366755642095;
    bool PJRHNQSYvbXi = true;
    string SGKkayS = string("dIvZbdnHlvzMVHeJTwZJKOPhdWWXwoBWRYMxHEkczoCYfnZyWaaUPUBpkyEIdUMwaSlZoZgUykdBpAxRkWboLigmnZuukDNIIEFAzLWonpsvOFutqBrznNCTbWaiQeNUGKUDLLQNTlcPOYmRQrscorFAcAPUBylfnbkoApmMng");
    string yqvvXKCDKgBHwRFZ = string("sPQUhLggejumZNgIPkgIexjiuhvULGUvHPidFoZdbMkueqKrwZODGtlompzYIoorlDtUHMRlvlGpvqDyZXXpnYbLzreqDJTbVPgaELCyloRsaaRvfOzOrccqTdaYvDcELcacErqoOyFbgDtoqEEBBxNrZhKShRdrLTPCEnvxTKapTksKKxFfTGMLaIZkvCxjEZybYrkRJPRhmzomJHOfvIiGAtbRwRtYSZ");
    int KXZRRpH = -821480728;

    for (int yJEvZKHUssZlVY = 2027781615; yJEvZKHUssZlVY > 0; yJEvZKHUssZlVY--) {
        UIEuWgl = uhnuCrAuIpGL;
        LwuyCH = GAfsIoHdYMoX;
        GAfsIoHdYMoX -= gXmvQBAoOOC;
    }

    for (int uRuMQ = 1802571788; uRuMQ > 0; uRuMQ--) {
        IcDoqlNkxOsNUY = yqvvXKCDKgBHwRFZ;
    }

    for (int pFfJKAT = 300618969; pFfJKAT > 0; pFfJKAT--) {
        SGKkayS = yqvvXKCDKgBHwRFZ;
        UIEuWgl += IcDoqlNkxOsNUY;
    }

    for (int RnMTog = 430780847; RnMTog > 0; RnMTog--) {
        GAfsIoHdYMoX /= gXmvQBAoOOC;
        LwuyCH -= LwuyCH;
    }

    for (int tqqjCycKBlJw = 2145453337; tqqjCycKBlJw > 0; tqqjCycKBlJw--) {
        gXmvQBAoOOC = bRTWMDDcWvfhhAlU;
    }

    if (PJRHNQSYvbXi == true) {
        for (int UBRTlrjUVrNZVcWr = 1937256117; UBRTlrjUVrNZVcWr > 0; UBRTlrjUVrNZVcWr--) {
            UIEuWgl = SGKkayS;
            IcDoqlNkxOsNUY += SGKkayS;
            GAfsIoHdYMoX /= GAfsIoHdYMoX;
        }
    }
}

void uggJKOkP::XAboTbjPluvstP(bool SOUFQorPK, string evJsT, int bFzxlFs, double TfBjfLWDokLSJ)
{
    string HDpDXgniBy = string("Nmh");
    bool zdWwzgNWmdMpBqk = false;
    int DzVtKFm = 2062735431;
    string vGKAUZpeQ = string("bVZMJeMdEHhCdtcKDqverAqTypigGhwNoHTAasxAIesTKxuUNjnbHrXftZQOUjgTpMkcPRovFsdnMtltgkCCBUIUglgoekWDBIjlrtyMPmNIvYCwWZFWjpAanfGOKXWhCgFbXaymCasVyKYyrZWXsezliBWiciaCdwCbinOvUugDGkGmalfWAqOEfJYCZYBzzprMAdrwyEHyPFnmkXIZWVaOOvLCEnbrq");
    int zCbIsgBIwCHbe = -2098736701;
    string VlpFLWOvFRbMx = string("CoymiuxgXmvwdMRguHrLOmJvzMKQpYuMaPLOLIafhdUrNfTqRqJFiKMbYtdvZsNwsCKKpglHbluWFSlrzXBCIdTPxZsvCCKqczZfBYkKZkcsCrWxlpsbsxQLLmMovCYSdlsoYgRLtvxOlvDAQxHdyVfmPnEfbJFHJhPVCUcEgUOVYOBffkBOSIPhRwkeDZUzUxJPlE");
    string hKFREd = string("lEJWVnxbLlCxEnOWpLEsQfWtwUiGhkDoyEkJKpBVEjbGYsEQBOHnOBMJKanNEWOiRpkzACeXyPTceYiJFFwfPZmIdtLpQRYTlkJlQjASgRfVKgPvxCYCEujRKGLYTBOfxBiZDgQPZNnPwSWB");
    double fPiAeKi = -19450.955830100924;

    for (int qrWaarfRF = 90742305; qrWaarfRF > 0; qrWaarfRF--) {
        vGKAUZpeQ += hKFREd;
        evJsT += VlpFLWOvFRbMx;
        evJsT = vGKAUZpeQ;
    }

    for (int RGlLhOQTFVqhUpV = 427987651; RGlLhOQTFVqhUpV > 0; RGlLhOQTFVqhUpV--) {
        vGKAUZpeQ += VlpFLWOvFRbMx;
    }

    if (vGKAUZpeQ != string("CoymiuxgXmvwdMRguHrLOmJvzMKQpYuMaPLOLIafhdUrNfTqRqJFiKMbYtdvZsNwsCKKpglHbluWFSlrzXBCIdTPxZsvCCKqczZfBYkKZkcsCrWxlpsbsxQLLmMovCYSdlsoYgRLtvxOlvDAQxHdyVfmPnEfbJFHJhPVCUcEgUOVYOBffkBOSIPhRwkeDZUzUxJPlE")) {
        for (int RhxPX = 1588445387; RhxPX > 0; RhxPX--) {
            HDpDXgniBy = vGKAUZpeQ;
            vGKAUZpeQ = vGKAUZpeQ;
            evJsT += vGKAUZpeQ;
        }
    }

    for (int wodbmqhULDLfyaD = 526564267; wodbmqhULDLfyaD > 0; wodbmqhULDLfyaD--) {
        VlpFLWOvFRbMx += HDpDXgniBy;
        evJsT += evJsT;
        bFzxlFs /= zCbIsgBIwCHbe;
    }

    if (TfBjfLWDokLSJ == -19450.955830100924) {
        for (int gPnBMZo = 995876434; gPnBMZo > 0; gPnBMZo--) {
            evJsT = evJsT;
        }
    }
}

double uggJKOkP::EfUNdpKxpOXVMY(string smgIgw, int oafqTj)
{
    string drFIdOHY = string("VcmevzlTeTMwjXqIfgNPiywrDtbQfKpxaiwzTTwAbvLmHXPIOHYWGicWSnvuh");
    double BmQuJNFUF = -450661.3047191244;
    string DvLHHhTwxlCsTL = string("MjMpVBMcuBLfYSZ");
    double gKZonfqAXXnwFQVj = 496691.28510345554;
    bool LlOCehFszXAbfiZ = true;
    int BQDGCdwgRRRyuj = -486847147;
    bool wdtoGzvIU = false;
    bool rgxAzD = false;

    for (int QIkhCUnFqOCwXcSt = 2009266694; QIkhCUnFqOCwXcSt > 0; QIkhCUnFqOCwXcSt--) {
        DvLHHhTwxlCsTL = DvLHHhTwxlCsTL;
    }

    for (int YMTzD = 856453304; YMTzD > 0; YMTzD--) {
        continue;
    }

    for (int ggxROvz = 1366441738; ggxROvz > 0; ggxROvz--) {
        rgxAzD = rgxAzD;
    }

    for (int sWqCdtrObRXiX = 1171301081; sWqCdtrObRXiX > 0; sWqCdtrObRXiX--) {
        gKZonfqAXXnwFQVj /= gKZonfqAXXnwFQVj;
    }

    if (rgxAzD == false) {
        for (int KNOhFqMgtyGApj = 543153860; KNOhFqMgtyGApj > 0; KNOhFqMgtyGApj--) {
            BmQuJNFUF /= gKZonfqAXXnwFQVj;
        }
    }

    return gKZonfqAXXnwFQVj;
}

int uggJKOkP::bxXZYRKQmENtv(double uslShv, string nhfCiEwfJgD, bool lXEMEPUMjwT, bool iRSfGaCQUUSm, int iBOeBWGQni)
{
    string OhoLgcjtqwqHO = string("GcuKuLiBwzxDKkszthOAljlSlgNiyPhNNtMbUPxEyweCgWbMPlQpyespTGkaOQcWkgAdncjrpWoKsRFuwrqJNDmKDLSARVOMzDhakGjJbkplxpyiTXLtFerCGTCWqsptNxvZRqHWguJbQAZyVXdknFyebnzSXxPrNeaGqBNFIxGMwCktYPnuWsiJvoeYcagcsDhIWiPtjuoahTvCaeEDGidMWBHb");
    string DlfqdpbvZfbAFR = string("mVBcvHHsAolRMPqrGXQZyqMpTWvAplsBZGJDmByoKujTNWxZZMJGBAASGfaramAihWCWXTtzxEmyALWDINSKgLInLQsDILlVBfNtFJXqZOotDgNFCSXUHqpRHJJcbdrvgDAkBDRKnSwJireUMGgYsgGBEmRkbRNztUyuTOEjrRVpoZlPgKEOmdbWyNFaspciKIMuGRJidVpQNCWS");
    string VQGcgyncXrmf = string("mRVnjIWlcslFOsQTaGRZAupjsDshCbMvGKHlHasUMerAVCgKZNquqLqaILIMzHqgxFxlwrHbIvoTJVmnvmobxDFEvpDHbIuIfZmZSFqEIigvFUjyMvjsFXGAuaCUAwiSqzApQxQMhXyuQWBsPzsAANwCQmVNCGfCRBRxuuuUktNLapmiFh");
    string vOBAtImqHvMlJ = string("IpGYhDZBvYmwdAcksYahEjIVUJuTqMEKvCDwqwWwlQOZgLgrAfoecDKzWgIGdnJJoWxbPHTOYQjEdIEIyFMXpQofPHlhEkakIqTIAcBkqVxQnoOjNfZMvMLWnijnRSbUnTVOVVbvdRQwAhTQEfBf");
    int VqZebH = -1502832129;
    double nQGZXhRIW = 110965.13053245611;
    int qQOSggBAZeedhn = 2040739244;
    int xDURmaLtEW = -699671647;
    bool puScLxFDYggX = false;

    for (int AnyJd = 1619242149; AnyJd > 0; AnyJd--) {
        continue;
    }

    if (nhfCiEwfJgD <= string("IpGYhDZBvYmwdAcksYahEjIVUJuTqMEKvCDwqwWwlQOZgLgrAfoecDKzWgIGdnJJoWxbPHTOYQjEdIEIyFMXpQofPHlhEkakIqTIAcBkqVxQnoOjNfZMvMLWnijnRSbUnTVOVVbvdRQwAhTQEfBf")) {
        for (int MQWGIsFGgACQh = 525473385; MQWGIsFGgACQh > 0; MQWGIsFGgACQh--) {
            iBOeBWGQni += xDURmaLtEW;
        }
    }

    if (nhfCiEwfJgD == string("mVBcvHHsAolRMPqrGXQZyqMpTWvAplsBZGJDmByoKujTNWxZZMJGBAASGfaramAihWCWXTtzxEmyALWDINSKgLInLQsDILlVBfNtFJXqZOotDgNFCSXUHqpRHJJcbdrvgDAkBDRKnSwJireUMGgYsgGBEmRkbRNztUyuTOEjrRVpoZlPgKEOmdbWyNFaspciKIMuGRJidVpQNCWS")) {
        for (int uyVIeiaHARMRxhQD = 1565139608; uyVIeiaHARMRxhQD > 0; uyVIeiaHARMRxhQD--) {
            DlfqdpbvZfbAFR = OhoLgcjtqwqHO;
        }
    }

    return xDURmaLtEW;
}

string uggJKOkP::vcMIaTolzDyRVk(double VyqMmBfQPU, string KEoXlvl, bool EpdUbS)
{
    double DtwjRgpTyo = 290353.6381876298;
    string XPqQXDMPjcOyx = string("NOSdoBQiSNpecFYzHKAxnktphWmGPvTJpnVMkSLTmsjfjhZtAToverdVsdVcKCrIKjDLxwwCMkjzJMlWAdUPOuwahtojMCwoZv");
    int rBiGyun = -139701084;
    double OIIFpKJWEP = 1041811.7214706793;
    int AnxfBICa = -1166655096;
    string Ixrqg = string("PsQSDeATkytcksBWHdwVwSkJNEHbctbwVvKONawPFNGZZqcqhsRbXzqzWsDonLQxFCpveLgtbIHImbMrmCGHcNXFLMwNnLcVrCFGndekyXyiBYvMdPdEptEUIXnmMMPtlfxjmlPVcVjXqUuJhTaQNlkdmSRJIkTTLpdahTkJoDQdRlTGYIQJenivYRsDmoEtGISpTtxzvWHzLkqUegiAYEycimHTLVKFCdsTjFi");
    string VhoUGXrYrB = string("eQiCZCaJhhFlEhyPoBGeXyUuyWQYnwLkZAdmQOxdMDGgzjCNzmuWJtVurxsKgLCqehgcCTDgexYNkccnNzEjYuEsMnErTYmVLSaRLRAWVxZQJdpxzGNBjpFTvSYkWaFgfJgbEpAFPpvcIApZeczDtLnhsNonNZxKziuS");
    string mjKStStDOSsLw = string("EWJzZTyFhKZULeTpEfMSvMFWttmFuQLqHPSFmZqYQTwVGoZbkOrJHsFicTwEYOBjretycCRSFNrVxxOfuXBfRfOHuWQkBucUJSLcriOjxqFJERDsAPptlpCGxwMTFSytRSrjSyfuHCmwqpRSdOfyMWLkcRjAoAnqaTDVAtaSGlVlTF");

    if (DtwjRgpTyo >= 1041811.7214706793) {
        for (int KonjoMz = 1834372004; KonjoMz > 0; KonjoMz--) {
            mjKStStDOSsLw = KEoXlvl;
        }
    }

    for (int wdMaFKQZjJzvq = 513876750; wdMaFKQZjJzvq > 0; wdMaFKQZjJzvq--) {
        continue;
    }

    return mjKStStDOSsLw;
}

void uggJKOkP::DtwacfNuP(string CeeVOTgACige, double GiefroV)
{
    double JrlEaRQXRm = -496012.48498256254;
    string WcxQldWBMKu = string("OJJrARVjAqbjhDpZeQnGeNwv");
    int JhLxbptJf = 394886084;
    double cwdJhbxYstsx = 811642.1090073505;
    string MhioPlcSnlOoXu = string("aHVsOTdyqWdKwcyjFYnKmbEoQAxGeloQyAdYedSXEnypJNmVQGUWejMUhCIUnbopQEVAIktvkRzZiPTKuNtwcKwzJzqzMSEJoGPJaxbIngLu");
    string wGomi = string("zsToIdtfXbQKtTzCWRpfTgFRRdfXPrPpEAZsrgzGUZTGtchDmlZtlWevQdxcNsGZqjfWtYxYjtpjszqXcLaAOFPhHLmeQyLLglEhrupLurzoSAuJlEAQcezhgEbQc");
    int cKajAiRwntlNdnVm = 582011197;

    if (JhLxbptJf > 394886084) {
        for (int zQQJNmvRkcTAzJ = 1613282111; zQQJNmvRkcTAzJ > 0; zQQJNmvRkcTAzJ--) {
            wGomi = MhioPlcSnlOoXu;
            GiefroV += JrlEaRQXRm;
        }
    }

    for (int nkYPXHWBuSpV = 242263200; nkYPXHWBuSpV > 0; nkYPXHWBuSpV--) {
        MhioPlcSnlOoXu = WcxQldWBMKu;
    }

    for (int ISohsYdz = 659659135; ISohsYdz > 0; ISohsYdz--) {
        MhioPlcSnlOoXu = wGomi;
    }
}

string uggJKOkP::dpbilZzC(int fWcwnZZFzlqo, string QOeCdTABe, bool BNKfJdFgbaR, bool ibubjQUvalKHt)
{
    bool hjeKGjeAiRvofoo = false;
    bool YAeNfHsV = false;
    bool sbnBeqDzuby = true;
    double UcLzwsAqK = -914905.2370138187;
    string qKDUlduUCnbPKU = string("LDAtliOAljIVoHgkEErkDbOGefYHgrKQBlfGctgJFGdnYGEkbdNvJdCOPUaJnK");
    int dRXIhKyY = -133806232;
    int oFFIxTsVKjXCAN = 369980664;
    double gNcLJLERyyUH = -151916.02487902192;
    string xnroPBnPEvwN = string("HHJyWIeAUEKFtcKqWXmkKDQxNINZSsMqM");

    for (int DMrzKMrTF = 914074944; DMrzKMrTF > 0; DMrzKMrTF--) {
        fWcwnZZFzlqo /= dRXIhKyY;
    }

    for (int kwITyYCuSftNoA = 1286577246; kwITyYCuSftNoA > 0; kwITyYCuSftNoA--) {
        continue;
    }

    if (oFFIxTsVKjXCAN != 369980664) {
        for (int gdeVYwjwfMiVan = 1612569454; gdeVYwjwfMiVan > 0; gdeVYwjwfMiVan--) {
            xnroPBnPEvwN += qKDUlduUCnbPKU;
            oFFIxTsVKjXCAN /= dRXIhKyY;
            QOeCdTABe += qKDUlduUCnbPKU;
        }
    }

    return xnroPBnPEvwN;
}

int uggJKOkP::gGQZyjiTmhSLZvq()
{
    bool thVGv = false;
    double BMSbfRq = -890354.8406194414;
    double vYcPLkWLf = 729278.595461062;
    bool LoYUesWiBTp = false;

    return -1494592048;
}

void uggJKOkP::CVoKmfmL(bool aLyGckeJq, double MGKxSrAOZbzKdeN, bool UxIeCBBxlYDhXs)
{
    int fGTxICdTDol = -738241219;
    string NyulmEwSIU = string("rrtSpOZPFyqPFMefZCDCocLvegRFoNEbJsbETCdpLHWHwLKJsNFuwtfYhSNaAYOeZRH");
    string ioLaHfHYTUK = string("iiTMUIocMSdVgNTXjESpjTETFveYIJYsEKIIKNEAbkQnQJdrZBMSjrSVJktZyEzWfIvepYzeOqnwdQMePvGnmSvBjNRCiJClWehauKykEVXseaTEaEjtSIQOwVCDvFruDzGmOdNFaHlASunSBREuIYSn");
    string qJIjnM = string("CeXvclMiBHIIbBIVWzmmCCVCZkHbEenyflyLMDqTkPigowuNQluyYZUFqyobJOSJhnFyWetuLpXiSTJbeJWqQhkakuZTjOfcQVxbRoUprCVjJCCmueNATUZtEjaSFXSVEkPfiDtQZvNACLufJuDETXVogCnlR");
    int VyJlCP = -596481372;
    int AJzqwuItXAMaDOI = -1368297270;

    for (int nWKuEyf = 1692603842; nWKuEyf > 0; nWKuEyf--) {
        MGKxSrAOZbzKdeN -= MGKxSrAOZbzKdeN;
    }
}

uggJKOkP::uggJKOkP()
{
    this->cNjWBRIGpRqBmH(538239.9465051439, 352444.972965545, string("ELcQJUQJSbDKFIFCukPSXnsztICiqmBOcLsqBpTbIdDUiRJazCVSfbbmqISiCitFTvUGInIjZaSPfZDmdRHudrrQwNojFnFwHZNDrkvGiawjtfvwcLWKYIpuOZmEseQNYyhCWLyNRwJkbVRIkODAbCpuTwEsTocAgppzvYcQtWLqbUkfLCGAnpT"));
    this->gCNnJ(string("LOFBUZOzwBrSGOYHSsYVZBKItxLYwtCfEfiwDVBpMLtJoQWnKXjZCHNETXTHozwJaqNNeKizSpyzSkRhsnxvLfOPaFHitonJhKmnPildOauFegfIuYzxsRhFTuGoGGjSxLZVlJcxlHHuwOUyksrFoEFPJNnOrLNIIJYApUPoUxaiGCBWNZreCJEYSdzQyXFNcsfCGgSNkLtziJvCLyyRuNWDeShXEjSMzEiGZwBKSZ"), string("MLbrKeHQutpvMaHcGzlvWebwjpSffJushGgKIDkojdbBIjfipousZeLqmFuEUxYxKjSEGqnilYhvAsaltRjNFfCOSrkpjPOLhPKYOcItcoARilEIYeezNLxeacLrXiWwsQByvzbKEkBNnErsVcMFEQrVlmFPxBoBOok"), -314920.42633600865, true, 339251.6506193898);
    this->XAboTbjPluvstP(true, string("bLaQsTColDrIkisKqGvGxLihNtXDXPrCnBVEarXJOYDWfXAqehEAzwqcrXszvuhjduWljjqEzGIijgkLlivbzhSoCwKBBSyJGEXlPheFguRxXOXOzZsOwKxdZHLoSyxTCxcJQAFwZXfIhLnXOSJimpYaFpvbUmALcgIQdQaxQJXapRWnOxvnoveZdkaIjMzPm"), 544098227, -705172.1202100766);
    this->EfUNdpKxpOXVMY(string("NIKwmsPaQUNNdCagXmuqZseIfEEDxWpxqFLHSKOJLGjoWiLoDPCcaOpHcmxPXdVgxgHfYjbXbxxInWLsXPkoWNyNwNWnQrYIBvNNpoJiLUKgUJTvTHLCqGSfrzYDLDXrUDMQIxDXHFRkWiEpNYPtAajjFkogStOnNZTqQFwZXYhjUxNCrksHNjrbpWFFateDhnjWQpEHtqvIQRxRhiKYEgwADgddkstuaVwJbOrc"), 1937961629);
    this->bxXZYRKQmENtv(650100.4813267412, string("PeIIwgQPsiLIGDpACMXjUMlmgDzYBEykKWrSBtHmYTLvAtBjcONjEEewsCvsGjryWgTywiTFkGdYbbOpIztrnvjQCfRyMggMcmVlYXCqCTrcVBwnTWDuQcVrJcuPPuAXMrJifxDXTZUIIdYsZPUaYRvLNgBWNQPqnECIItflzOLvTGlGZniaHlTtHwVBECHoRIXKjQhOACaFzojmxChLOJMlgldoBhjVqaIFXYj"), false, true, -612300287);
    this->vcMIaTolzDyRVk(-237574.86207814692, string("ugUQsmPpwZiXoQHargsucdRGiiviQctdoRKKagXzBfjWZgmPxrUCJXmnwKMfCrCoKlguSFkmQiqIVpEenYfktLpYpPNVmxPJIcxQUczWgtxOGbfAHDNrVngqbOBvSbEhhPMbbZlefHOxCDQNRbxCDsKWmEXGOlERBPlxGRlUebhYAaUTERZPHHtZifqyJrRDUQGPLxCCZPNFVnsQgitvRfRbVOwnpivqupckWvgYOULiEYVVVwSSSmPtDbOEVr"), true);
    this->DtwacfNuP(string("FqbWShBSnhsVfZjgpyAIGKdVRrtOPJoRkBmixdivdTfJlBhqHvesqLAfFYnOcJvcsKnilzHFrlaOeNanUlQelkDOWZBjepuXVxjeBWMIWMgZQBHrzIhsIiEqdlhsOyrbmeRUOAnOzqSgtPMjmpNZivpONeOMWQGRYEKOwqPzriovfGCCSeaeSxyMtTln"), 971982.5857118155);
    this->dpbilZzC(215867179, string("xpPSCdCtpBPOPEktIvFpnDMSSATcMtFvetcLfDMDhOHmTlQMTvBlGYChtJoMKJzqZRGoXMjBzYBSLWEpizsBSUiYbEyJihvbIEwmsZckuvIfJzCvzqgvmfwlVbcPSlpCpusmifrhQfpLjrJYKTiDNalXqNzwaXgdruWjtmVkvvtuwxOTCFBbINdLfxwMMpunOkQhOagF"), false, false);
    this->gGQZyjiTmhSLZvq();
    this->CVoKmfmL(true, 561420.9690435964, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WoWFVUzKgaX
{
public:
    string lrDrICi;
    double iFERhPJpGbDi;

    WoWFVUzKgaX();
    string HeoRaL(string hwRJrFCAnUFbC, string seBGDPDv, int auMIYLVN, string ueuwIQkjuHYzUyGl);
    void ycIETtDvBeVfb(int xAkBLOd, int NybiFQOT, double yEtHWOGVamXGNPp, string QpgJDdmXmfAHz, bool WYWmvETxtdTDo);
    string oXpmbINftvaGSEn(double HMPsEf);
    int AJzKPsmBOryiPC(double WtpDIo, double LMBueV, string BizcfOS, string bmEWMU, bool zICfvSXtDekgro);
    int PPdEQQndMOTt(int sJGnzN, double NDCqrCrMQUmGDVM, double mVATNmEljhpyjRE);
    int sNNBrVkmAdi(double KrGfGMzuJg, double eHEhTQeHZuD, int SmkVL);
    bool GqCLaZIS(bool SRrXEpkn, string azxEnvmO, double giriTSyHTQc);
protected:
    int nkawibTiQGqBXV;

    int XrqSa();
private:
    double CKsxzGrUZnA;
    string dpmilJayVORQliEO;
    bool HUFGRbZlM;
    double WxcRYTYQrHc;
    int cdMSvo;
    string COppIVuco;

    string XoZtchXeZuB(double DfoFnuHfdH);
    int HSXdm(string XuabPLrDr);
};

string WoWFVUzKgaX::HeoRaL(string hwRJrFCAnUFbC, string seBGDPDv, int auMIYLVN, string ueuwIQkjuHYzUyGl)
{
    string hTFLlvYjwGKztfX = string("CIGBECpwzVXxQaxMvRVwbbukSnnYbq");
    string mcxmR = string("UgbcOXWMZSMGDtHnkuKyiqWFoUCPtFlfDGvFCwAqivPzQeCaoLRwNcloXSVNVIpghNzYrhVwPhsdhSyLoUvhIJTMAmsksDPngrfMACqjZWfqHJWMpKwOgKfOXmnYFdhJGADJwkKAclLSYMGPBIJhaHnOjmKvTIOKHznCZSwsuYyzZRQdeyaISXqjOqZXaskLwWKVDTrxDTYDqnpalgLVbHeoINCpHFMdryMjIbUPAuTdSOxElzQoCjTtKj");
    double swIicnvbZ = 70853.32157488365;
    double VWaRFydVOuHtNyF = 302560.9989696368;
    double qmzieEGTPcI = -19846.22486507131;

    for (int eIorzm = 2020160520; eIorzm > 0; eIorzm--) {
        hwRJrFCAnUFbC += seBGDPDv;
        hwRJrFCAnUFbC += hwRJrFCAnUFbC;
        hTFLlvYjwGKztfX = hwRJrFCAnUFbC;
        hTFLlvYjwGKztfX += hwRJrFCAnUFbC;
        hTFLlvYjwGKztfX += seBGDPDv;
    }

    return mcxmR;
}

void WoWFVUzKgaX::ycIETtDvBeVfb(int xAkBLOd, int NybiFQOT, double yEtHWOGVamXGNPp, string QpgJDdmXmfAHz, bool WYWmvETxtdTDo)
{
    int XafHpBUXtHUR = -1784436780;
    double ZjiymHr = 594577.2805979036;
    double YcwZnxGDjaKbY = 320036.83358198596;
    string ovPLUZSpOxTs = string("pYdeAAaipdJTMOTNyOleMsMMifNhQOVNJctUoysasoOcWtQwcqhuSuvQJYulwoKdxgdagKwhpDEkBTeS");
    string eAZfthGWDBgQmIdq = string("dwCsBnmsaExJfmIMBxmeZhvdBFRAfohxbguwBdVsWVcPfKmrLcTunwmtiShbnQooyVYnTjgajvQMXrwoRqhzhGUdhJHZdVOPQTeptDukPFtPJKqfxJRIePdSYaanNAzAGvGslsuWX");
    int ZUjsTwPMxk = 2108597936;
    string rVzbGhZ = string("bNYHHaukjdAlLjceRSHFoiMiAHAweNYSpjcPTYUaaIupGFoikfJBpc");

    for (int qGKVsx = 34999849; qGKVsx > 0; qGKVsx--) {
        QpgJDdmXmfAHz += ovPLUZSpOxTs;
        eAZfthGWDBgQmIdq = QpgJDdmXmfAHz;
    }

    for (int ZwGUSxdanFo = 415738037; ZwGUSxdanFo > 0; ZwGUSxdanFo--) {
        continue;
    }

    if (rVzbGhZ > string("pYdeAAaipdJTMOTNyOleMsMMifNhQOVNJctUoysasoOcWtQwcqhuSuvQJYulwoKdxgdagKwhpDEkBTeS")) {
        for (int QFzzmeptv = 1197329365; QFzzmeptv > 0; QFzzmeptv--) {
            NybiFQOT += NybiFQOT;
            eAZfthGWDBgQmIdq = rVzbGhZ;
        }
    }

    for (int gyCOxoMGBZ = 1473296709; gyCOxoMGBZ > 0; gyCOxoMGBZ--) {
        continue;
    }

    for (int gWppWRXtldmXUj = 701039452; gWppWRXtldmXUj > 0; gWppWRXtldmXUj--) {
        NybiFQOT += ZUjsTwPMxk;
        QpgJDdmXmfAHz = QpgJDdmXmfAHz;
    }

    if (ZUjsTwPMxk != 448875612) {
        for (int hCqPsiUQWoHJGV = 67581426; hCqPsiUQWoHJGV > 0; hCqPsiUQWoHJGV--) {
            yEtHWOGVamXGNPp += yEtHWOGVamXGNPp;
            NybiFQOT = XafHpBUXtHUR;
        }
    }

    for (int AscOOQBVi = 1362895246; AscOOQBVi > 0; AscOOQBVi--) {
        yEtHWOGVamXGNPp /= ZjiymHr;
        ovPLUZSpOxTs = ovPLUZSpOxTs;
        xAkBLOd *= XafHpBUXtHUR;
        XafHpBUXtHUR += NybiFQOT;
    }
}

string WoWFVUzKgaX::oXpmbINftvaGSEn(double HMPsEf)
{
    int ORLaAEupJbIz = 1755356845;
    int VjrdjPyUtPt = -132388250;
    bool HDQRJwEBYyOh = false;
    string PhftyXkc = string("UAHKcGzxqMrFRHoZdRzCAzpOeandUlNvxYpSqFhctEUmpmivDneMuAcoeOsZspsPemjDZXNCFRwr");
    string kHEeb = string("ZlqGDQiLViztYTHRHSEbmZhzuGYrgqJnptrBIxloZRzSsLZDSJXIqKCggdSdPeFIsLJOnsEyjdEDSWltMIWadCfXymXsAVxwdEBrScynDUqlQoIZHmcoQQXPzlBVaNtDzgQmLLGpVpAFQebnJVXwGsIGcFmgJpzhfRcvVPDtheuAetJYNKfnAlMfRAUOMyiRlZmImKXPJhNTDxnemeTcFBAgLuVbPyABViimpPvDRvwT");
    bool EYZqxmSmYZlvP = false;
    double sSBSXjDPI = -615784.6404195745;
    bool qgmEJeCfdCY = true;
    string dZDyjxV = string("nMyGbJrUyHiLDLlnUEnBqJv");

    for (int xgJzHHR = 424533423; xgJzHHR > 0; xgJzHHR--) {
        continue;
    }

    for (int xHTtyKTbQqlES = 2033510234; xHTtyKTbQqlES > 0; xHTtyKTbQqlES--) {
        continue;
    }

    if (HDQRJwEBYyOh == false) {
        for (int dRhhKDhFA = 335930144; dRhhKDhFA > 0; dRhhKDhFA--) {
            continue;
        }
    }

    return dZDyjxV;
}

int WoWFVUzKgaX::AJzKPsmBOryiPC(double WtpDIo, double LMBueV, string BizcfOS, string bmEWMU, bool zICfvSXtDekgro)
{
    string SVBNyn = string("cQWpviRmIEfyqDxyjevEwPcmauMDlTgmBthzvxamwFJTZulNhvhEmnmKbYiMbkMCRnWdpIjFVGKinQwLMdudkoOYIBXnomlJWHsJfJIVjULedOHVpkCjfzXaKZPhMYsy");

    if (WtpDIo < -420180.32809757016) {
        for (int MSDDxVQdYBtXgY = 1738120682; MSDDxVQdYBtXgY > 0; MSDDxVQdYBtXgY--) {
            bmEWMU = SVBNyn;
            WtpDIo /= LMBueV;
            BizcfOS = bmEWMU;
            bmEWMU += SVBNyn;
            LMBueV += WtpDIo;
        }
    }

    for (int hUcKsYlmNu = 1372480690; hUcKsYlmNu > 0; hUcKsYlmNu--) {
        bmEWMU = SVBNyn;
        SVBNyn += SVBNyn;
    }

    return -631920762;
}

int WoWFVUzKgaX::PPdEQQndMOTt(int sJGnzN, double NDCqrCrMQUmGDVM, double mVATNmEljhpyjRE)
{
    string hfTHD = string("FeJbZnFmUpYNCuncRazxXcgcHXuFbECVLPnyVCANyYqjGGkEQycmWsnqpAPRxoGcoFkRLFIxccYhWtPuzbLLUnyMZugCTsMcmCbSAlliEtZKTvTgDrVjLMAZTOpHmmQjUcWCMVzRDfnXdXmcEA");
    double pyaqCVAXOPNBtyTQ = 1044357.0657239871;
    double HWKaAZWlz = -752791.454316836;
    bool mxmeaPfchjPPyt = true;
    bool lWzmcgWKMoPN = true;
    int dAumpFssHrL = -625806664;
    int IFCuDSLdCxnMC = -818141859;
    bool skEgrdUFfSAfV = false;
    bool RZsOohUboMToy = false;
    bool eHmZmn = true;

    return IFCuDSLdCxnMC;
}

int WoWFVUzKgaX::sNNBrVkmAdi(double KrGfGMzuJg, double eHEhTQeHZuD, int SmkVL)
{
    double tmdeMAu = 642785.9949103124;

    if (KrGfGMzuJg >= 642785.9949103124) {
        for (int clMWXHggbrxds = 1206864615; clMWXHggbrxds > 0; clMWXHggbrxds--) {
            eHEhTQeHZuD -= KrGfGMzuJg;
            eHEhTQeHZuD = eHEhTQeHZuD;
            tmdeMAu /= tmdeMAu;
            tmdeMAu += eHEhTQeHZuD;
            tmdeMAu = tmdeMAu;
        }
    }

    if (tmdeMAu >= -678203.3861783199) {
        for (int GQbQkLODE = 959774628; GQbQkLODE > 0; GQbQkLODE--) {
            eHEhTQeHZuD /= tmdeMAu;
            KrGfGMzuJg -= KrGfGMzuJg;
            eHEhTQeHZuD -= tmdeMAu;
        }
    }

    if (SmkVL <= 1039798127) {
        for (int lXjdmJsCdh = 994866127; lXjdmJsCdh > 0; lXjdmJsCdh--) {
            tmdeMAu += KrGfGMzuJg;
            KrGfGMzuJg *= KrGfGMzuJg;
        }
    }

    for (int LAuuJdUGxyMtdVij = 994777315; LAuuJdUGxyMtdVij > 0; LAuuJdUGxyMtdVij--) {
        tmdeMAu /= eHEhTQeHZuD;
        tmdeMAu *= tmdeMAu;
        tmdeMAu = KrGfGMzuJg;
        tmdeMAu -= KrGfGMzuJg;
    }

    for (int dCziw = 1879129616; dCziw > 0; dCziw--) {
        eHEhTQeHZuD = KrGfGMzuJg;
        eHEhTQeHZuD /= eHEhTQeHZuD;
    }

    return SmkVL;
}

bool WoWFVUzKgaX::GqCLaZIS(bool SRrXEpkn, string azxEnvmO, double giriTSyHTQc)
{
    double aDikOL = -403293.63054304407;
    double PbuHTeu = -220540.9011375955;
    bool ShZJDpSfggODPQ = false;
    string HxVcYWfm = string("uVGCHrVn");
    bool adBrMEzxV = false;
    double MElbma = -258743.5911726777;
    bool NNjwI = true;

    if (SRrXEpkn != false) {
        for (int EaKvDUIyazsDwap = 598111997; EaKvDUIyazsDwap > 0; EaKvDUIyazsDwap--) {
            MElbma /= giriTSyHTQc;
            SRrXEpkn = adBrMEzxV;
        }
    }

    for (int cupRXPKPndXKNfA = 1544156273; cupRXPKPndXKNfA > 0; cupRXPKPndXKNfA--) {
        aDikOL /= aDikOL;
        giriTSyHTQc += aDikOL;
        giriTSyHTQc *= giriTSyHTQc;
    }

    for (int LoCYazdiFOMiZaU = 685161711; LoCYazdiFOMiZaU > 0; LoCYazdiFOMiZaU--) {
        MElbma /= giriTSyHTQc;
        MElbma -= PbuHTeu;
    }

    return NNjwI;
}

int WoWFVUzKgaX::XrqSa()
{
    string GJiSStBDkWMtqhGY = string("prNsCKdsvIFlgTXRzXfffniiXSGsueOHPRYIbgnBufYOTiXwbFjFzwJLzJDXviSRjTXzucDaaLKNgTnufgSIayEJkVcLciHIKUGBu");
    string ntGNKPLrvC = string("TyDmsYNocZtkSrjSngKlndnhvNzJwyjyKDGEeFWyWpnGlLeDPBpJcKhGRdDDqPaElaMFZjPJWqcfAHPdTJLZsRynhqwpljkBWmrcEZDoPtOYnXjsggpAPfsgCuGDDwrOywDQeHIzuLgcURFbbesz");
    string owwPdNXZI = string("nZhMoKhMElrVJfCLGLDRMsYTkYRCVFUIVHyPOEHjzwfYfnilreXoNjTaTovovyKlsyU");
    bool YqDJkjjMom = true;
    string rucGgSloZUErlbaE = string("FsUEZIclOHLnDopYisKxhKfrwJgMHKHfNmwWUXaYWZkMPZvzhcfHMbTvEYDSENOQmpPrbwzKPSnubqDVpVGeHZFZVCGYmAKgvImQZWqQyDRqfTlsXeGRpXqXxHWCDpJuTpPlnKEJQchPCrGVDnXDuQhcAbaRXE");

    for (int RlMOEeIQaw = 782556695; RlMOEeIQaw > 0; RlMOEeIQaw--) {
        ntGNKPLrvC += GJiSStBDkWMtqhGY;
        ntGNKPLrvC = GJiSStBDkWMtqhGY;
        GJiSStBDkWMtqhGY = rucGgSloZUErlbaE;
        rucGgSloZUErlbaE = rucGgSloZUErlbaE;
        owwPdNXZI += rucGgSloZUErlbaE;
        rucGgSloZUErlbaE = owwPdNXZI;
    }

    if (GJiSStBDkWMtqhGY < string("nZhMoKhMElrVJfCLGLDRMsYTkYRCVFUIVHyPOEHjzwfYfnilreXoNjTaTovovyKlsyU")) {
        for (int cKVPH = 1116584430; cKVPH > 0; cKVPH--) {
            YqDJkjjMom = YqDJkjjMom;
            ntGNKPLrvC += owwPdNXZI;
        }
    }

    for (int vhLnjnF = 1397141795; vhLnjnF > 0; vhLnjnF--) {
        ntGNKPLrvC += ntGNKPLrvC;
        YqDJkjjMom = ! YqDJkjjMom;
        owwPdNXZI = owwPdNXZI;
        ntGNKPLrvC += ntGNKPLrvC;
        GJiSStBDkWMtqhGY = ntGNKPLrvC;
        owwPdNXZI += owwPdNXZI;
    }

    return 1845456027;
}

string WoWFVUzKgaX::XoZtchXeZuB(double DfoFnuHfdH)
{
    int SzZnzMWfFieOxacc = 1745881743;
    bool KJXkzOdNkvYaK = false;
    bool FfEjMkadiNkf = true;
    bool YpHPWcAZq = true;
    bool JNEfPjhT = false;

    for (int RKqFWOPfAcklqiRf = 1799489412; RKqFWOPfAcklqiRf > 0; RKqFWOPfAcklqiRf--) {
        JNEfPjhT = KJXkzOdNkvYaK;
        KJXkzOdNkvYaK = ! FfEjMkadiNkf;
        YpHPWcAZq = KJXkzOdNkvYaK;
        JNEfPjhT = ! JNEfPjhT;
        JNEfPjhT = ! YpHPWcAZq;
    }

    if (JNEfPjhT == false) {
        for (int wTzqLWBtlN = 211842013; wTzqLWBtlN > 0; wTzqLWBtlN--) {
            KJXkzOdNkvYaK = ! YpHPWcAZq;
            JNEfPjhT = ! YpHPWcAZq;
        }
    }

    if (SzZnzMWfFieOxacc <= 1745881743) {
        for (int YwZXtPWrYwBAuWxL = 818319260; YwZXtPWrYwBAuWxL > 0; YwZXtPWrYwBAuWxL--) {
            SzZnzMWfFieOxacc = SzZnzMWfFieOxacc;
        }
    }

    return string("CZvLKhgTSYKCoSseHiRyLDPpsutBFqeltcaWrGPxSzCaApTHoxDAICjxYtUzTafshghJCWXxDJPYCruu");
}

int WoWFVUzKgaX::HSXdm(string XuabPLrDr)
{
    bool thHVDVRFuZ = false;
    int cgVhdmiODCZnfwNX = -515019974;
    string roWWiGNvbqy = string("Bm");

    if (roWWiGNvbqy <= string("Bm")) {
        for (int BmabdPQbQx = 1409307095; BmabdPQbQx > 0; BmabdPQbQx--) {
            continue;
        }
    }

    for (int ANcmwuJWQl = 1903235892; ANcmwuJWQl > 0; ANcmwuJWQl--) {
        thHVDVRFuZ = thHVDVRFuZ;
        XuabPLrDr = XuabPLrDr;
        roWWiGNvbqy = roWWiGNvbqy;
        roWWiGNvbqy = roWWiGNvbqy;
        roWWiGNvbqy = XuabPLrDr;
        cgVhdmiODCZnfwNX -= cgVhdmiODCZnfwNX;
    }

    if (cgVhdmiODCZnfwNX < -515019974) {
        for (int AibBDsRyclxZiXb = 646465731; AibBDsRyclxZiXb > 0; AibBDsRyclxZiXb--) {
            roWWiGNvbqy = XuabPLrDr;
            XuabPLrDr += roWWiGNvbqy;
        }
    }

    if (roWWiGNvbqy <= string("ijGkOhvhgPjIJTmClfNljoBhfeeTxAHNxScaMrMHPNCDYcFSGqEMayaePlsyLGWLOVtTivDAztpYqagichWnblisLSINTErnVrbNmIaJNqPSxixNqyLzaUcuYceAqUyMXGLNbFDbnviRdFpEglsPWIVBNqQzXXDMbLlUxFCJpJsQFNHQRYOwOzNpXAS")) {
        for (int ijdMSHfehagYLs = 1929830610; ijdMSHfehagYLs > 0; ijdMSHfehagYLs--) {
            thHVDVRFuZ = ! thHVDVRFuZ;
        }
    }

    return cgVhdmiODCZnfwNX;
}

WoWFVUzKgaX::WoWFVUzKgaX()
{
    this->HeoRaL(string("SillUXqSHkypnKzMXSzPJWmcXWQKflAZNiwnbZHaSVmmayRVxmCxuEAekaUEwFdDHPUrkFgrAXmQbCzWUXPMMhhTfgXKMIAfmVdfgbe"), string("zjiRbnFoxqrTLWRcERCDbwzSNqlGxQvQeDfmPDArIFHahYpfKzwBLfYseobpKoAwXECHepOUWWffvDzFvupepbZcclNLDFrzvkFDWwVLPlYRliYHsfzDlrVOhMUjbkdQZhqkOFLjAgw"), -1307914951, string("EeXrGMiGdhmcQmjhCuLLjOGDftKmSRnEnIrLzeiSRIIKyNbgdDECeCiVBrnIvfNcVhYrefGPDTbqqafVPf"));
    this->ycIETtDvBeVfb(448875612, 671303966, -608592.7915569857, string("mxZJpfdCXRPbLbyjPoRAlAvBaWjIeexUcGwouSmwhgECRNFiEEmatVoZgvChwvRJhrdrSMuVEcPYswimMvMVnfwNceLxEWlLSXdxQPVwEUFfadfaSknGwUCedQyvqjRAhkPuLjWqKngVTrxyVIKLNYyzDkAiNwOcuLVfyCdqHPxrygRqMzVtEVXoTzQsZSuTTidPlTFL"), false);
    this->oXpmbINftvaGSEn(302973.066781585);
    this->AJzKPsmBOryiPC(-420180.32809757016, 798112.1212536843, string("OCvjkdluzXterdqsbSBJKbxvkHKHssCOrNCXfIVoHQrOJHQGlDYWBEUcQoqirkFbgfMwXyyHkaSIgydtBeXPdFQFAsVZxOCRbQnrtjwmKliFVwhaVkTLICRdcLoJnHtPXAwDToGWqrHnkuKlGqzYOzwqGaRwUnYJoyPcfIzZwgG"), string("FHpzSkOXpkmxEFmqsvccSNsUZsIagSiawoZJSWaCWJeCogMKebFWlBCRvlTtotpkPKMuVkUubkLQeRmZFmpJHWHXeslSbh"), true);
    this->PPdEQQndMOTt(1828636601, 113170.93520411744, 949411.4988264767);
    this->sNNBrVkmAdi(-678203.3861783199, -172813.75300296544, 1039798127);
    this->GqCLaZIS(false, string("KESjxCWOGoKpTbdkdCcnoaIHaevHZOJkwjdZUzWgAWCRAybhbwIOQyaJiQEVHrjgNmLZqBYGzFYSaChrXYotZPqBmZPfTeVqjzSEffGATHJDkGTA"), 604657.866866281);
    this->XrqSa();
    this->XoZtchXeZuB(-189529.0964338866);
    this->HSXdm(string("ijGkOhvhgPjIJTmClfNljoBhfeeTxAHNxScaMrMHPNCDYcFSGqEMayaePlsyLGWLOVtTivDAztpYqagichWnblisLSINTErnVrbNmIaJNqPSxixNqyLzaUcuYceAqUyMXGLNbFDbnviRdFpEglsPWIVBNqQzXXDMbLlUxFCJpJsQFNHQRYOwOzNpXAS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TyDJoEgGKiVPXf
{
public:
    double sggyife;
    bool MHSfl;
    double gVXNFHCPK;
    bool jUIoOUFYlUQgZGji;
    string RYROCVxh;

    TyDJoEgGKiVPXf();
    bool zqyrWTuGQZYraPE(string TBsxWoLGZFBzM, bool aRuNuxklJOwl, int QYOCqnsbF);
    bool tXenvMYVYso();
    string xYZnkekFCppPSd(bool hKgIFcDrqqgino);
    void GNwSKMq(string TJsaESifFyHFraRj, int xrOJSTnmtZhUJSIL);
    double PYtAllLGoSmNj(int MGcKdQx, bool SQYRQoVRq, bool IeNSZefy, bool dpwjcoykBOj, double fNWySEQYSxZk);
    bool ErCfKbz(int JBHuWWtnUCojuOQa);
    int QuDUQ(string StqfyZTFujosdaWX, double UcoVO, double WnQUrDQBTNfmaT, bool DeFiSqPEb);
    double oQxDypSDNHdzRmdx();
protected:
    bool FcOpsF;

    bool sAmpAf();
    void qwLwV();
    void bEwTRHf(int cerJKrSPbiH, double tPBHQOTgoZWgb, double mdzJQSbDDgjp, double rfZMx, int jUQKfVS);
    bool BKLiMym(double amkal, string XvWVxedjDODBtlC);
    double nzQvGfdydHuD();
    int IPwBQImRhOVSjDM(bool gCmvYKnm, bool QgQsxWBk, string HtZROW);
private:
    bool gqjlBe;
    double kFphCZngQ;
    int IXObIvZwMKGjxLM;
    string IkQdjosSdxWS;
    string FzUBNmMVXOKW;
    bool sTvrjEMGEAJKvITX;

    bool RZovfbQIEPasqh(double lOtWTeoZCQqCnQaJ, string CzCzpHNkijrM);
    double kZbYqjqfYnDL(bool erkkqPXdbNKtT, string IWroN, bool nxRDvMukSSPlXSO);
    void pWjLjbPYbBkmiNrO(int fSnfK, int SialsKihPfh, string wIwfc, string wgJwENtpMWQLcDXG, bool nxksnQluZvFQ);
    int HcKBFy(bool HkIqHreeTcqz, double JuckBCatRlAdJ);
    int XmlrYTiiMBOMj(bool fRhFySzFI);
};

bool TyDJoEgGKiVPXf::zqyrWTuGQZYraPE(string TBsxWoLGZFBzM, bool aRuNuxklJOwl, int QYOCqnsbF)
{
    string tiaWipmAEGjTy = string("LcntvPVNgXtxKvjRTsexNbTYlQgdNRzDstOzxvNiGYvFQuIUURRCwVGFsDgqjVKegVxNujKiejQgtbwUVdUsDvmLGmRXiXwgsbAcGphjMbomePGsoMeCcDtBgy");

    for (int noBYVo = 1256372779; noBYVo > 0; noBYVo--) {
        aRuNuxklJOwl = aRuNuxklJOwl;
    }

    for (int aIRfHLlALgScUJAJ = 1452629295; aIRfHLlALgScUJAJ > 0; aIRfHLlALgScUJAJ--) {
        TBsxWoLGZFBzM = tiaWipmAEGjTy;
        aRuNuxklJOwl = aRuNuxklJOwl;
    }

    return aRuNuxklJOwl;
}

bool TyDJoEgGKiVPXf::tXenvMYVYso()
{
    double csBLg = -688153.9300134421;
    int okjFibunTDD = 1292620889;
    bool LfErk = true;
    double nSGMPMQk = 979829.7033721568;
    double mVLqCoiVOO = -173385.0655392406;
    bool jbzceSxnZjr = true;
    int XqNYXzGgzslZROz = -376980273;
    bool nIkjocKrquSLYSF = false;
    bool MsWNEdUd = true;
    bool HZpUMcspAcQb = false;

    if (nIkjocKrquSLYSF == true) {
        for (int jPPDgxLLFDARBhmX = 1640437396; jPPDgxLLFDARBhmX > 0; jPPDgxLLFDARBhmX--) {
            MsWNEdUd = MsWNEdUd;
            MsWNEdUd = LfErk;
            jbzceSxnZjr = ! jbzceSxnZjr;
        }
    }

    return HZpUMcspAcQb;
}

string TyDJoEgGKiVPXf::xYZnkekFCppPSd(bool hKgIFcDrqqgino)
{
    int GxAwGH = 1955778555;
    double YDYjJcT = -127904.51040377871;
    double xoqBSLtzeF = 688080.1254511282;
    bool UAUKxNjj = false;
    bool gageovKLTFdByo = false;

    return string("miOnWjZppKkZPTzJpCCJdaBjeYwefVkapBMkSlNeoSVKuXGmzYcQMvpudFiefMHwQKZiqXvKpbCuNvRiCcBSwHuSAMmGOqvaiURzNCmPDynvpMZ");
}

void TyDJoEgGKiVPXf::GNwSKMq(string TJsaESifFyHFraRj, int xrOJSTnmtZhUJSIL)
{
    int ttsEzwWVCFxYp = -360597892;
    bool kNMyNBb = false;
    bool UkLdzVipBRk = false;
    string ePJgJIeIy = string("oLsCUstaDOPRJXRAsgfCIeXlsTTsBnrVokCRvXWXSyvbYYVTfvQaDczJRapmxdkIjRpSdSzaBKDfpFUoMtfGZXtfspuesNGERefKBOJmljdbbIExcFJzJMBjtARezEcuxYTqjkezcEAMtoEVEyZbnaisVGftMVSWXIXIIdLykbUlGiMmjlrslEqBbRkpmZsQSOlXRpTkrkvWySfZJQBdMsiOvianlbb");
    double cJsVJ = -527978.3310441638;
    string NcsVzWMvilDFo = string("QhCfGmAKLhUXUiEyMWoOyvGIvHimbHhlqCZTGxkYNMOZwzAKJKLNly");
    int wClkWtwwNUjpnm = 1748463934;
    int kiQXQnTbslM = 545531125;
    bool bFJfdwkGWyGH = true;

    if (NcsVzWMvilDFo != string("oLsCUstaDOPRJXRAsgfCIeXlsTTsBnrVokCRvXWXSyvbYYVTfvQaDczJRapmxdkIjRpSdSzaBKDfpFUoMtfGZXtfspuesNGERefKBOJmljdbbIExcFJzJMBjtARezEcuxYTqjkezcEAMtoEVEyZbnaisVGftMVSWXIXIIdLykbUlGiMmjlrslEqBbRkpmZsQSOlXRpTkrkvWySfZJQBdMsiOvianlbb")) {
        for (int KmJiQwHoRHcH = 2051543626; KmJiQwHoRHcH > 0; KmJiQwHoRHcH--) {
            NcsVzWMvilDFo += NcsVzWMvilDFo;
            bFJfdwkGWyGH = UkLdzVipBRk;
            bFJfdwkGWyGH = ! UkLdzVipBRk;
        }
    }

    if (xrOJSTnmtZhUJSIL == -608423265) {
        for (int PNchasKhtKM = 1673419373; PNchasKhtKM > 0; PNchasKhtKM--) {
            ePJgJIeIy += ePJgJIeIy;
            xrOJSTnmtZhUJSIL = kiQXQnTbslM;
        }
    }

    for (int fsVOjtWAeqbSmze = 643043867; fsVOjtWAeqbSmze > 0; fsVOjtWAeqbSmze--) {
        continue;
    }
}

double TyDJoEgGKiVPXf::PYtAllLGoSmNj(int MGcKdQx, bool SQYRQoVRq, bool IeNSZefy, bool dpwjcoykBOj, double fNWySEQYSxZk)
{
    string sXjNMbGNEEfPvHnO = string("nGslzNXXRsdfAYqBMxLtqshTVXWmNqYAhXSSIGReRpRsjywsyjwLHNqWEZfreQBcoimTHHDzwyjYowHnMzWlXtYRLXCetyNGFteNBqzfkHnojmXUrCLVnXQQcOtJOrJAbwHERZNwPsPOqnVuRxBguUolJpbckjYwhnBKPQjDuxrmDtrxeYqbfZYjxeujIWWgzRznWhEsyERWOfyFXhAiTjBbxaUPPpRJFkmGXoxvSjvRJGCdEFBGDPRvvlZJJPa");
    int mxUIjRCMPsvPKYJ = -1774403141;
    bool cJmhrcH = false;
    string TPBFSdK = string("czZtWFesSvefoyiMveXCfGVxfpXzInRFCbrHpQNTvQTmMIHCCSLAKgbUTNhOBmTrCyGRuHOfaeShHcJKDvpXSneFmGERbICX");
    int BAPFrOyVUWz = -1204040576;

    return fNWySEQYSxZk;
}

bool TyDJoEgGKiVPXf::ErCfKbz(int JBHuWWtnUCojuOQa)
{
    double IanDKdTf = -672300.5819082187;
    double BErWThq = 680585.4619834125;
    string QkZfFLpAtBOtQE = string("ZjVlECxMXjYqezFvPqvMMbrFlLFueINpVSzfVXzqtajETHmVktALuaMPwYIGMGSWfhGBUbumbEtLmJjjYoRUbPUaXdUjkpKsDeMszxZiIkIqNJVukFpGwosoROAhDTgoQcCBTBabXlvhKBFRFLoYQghhHWGpsXaWfowJUvwGpnrgSiwxxJKGaNnjDuZKFITFHzDnZMHUzplnlzbHCgythiUCkUeDgIMtU");

    for (int yWyCREAba = 418625562; yWyCREAba > 0; yWyCREAba--) {
        JBHuWWtnUCojuOQa += JBHuWWtnUCojuOQa;
        IanDKdTf /= BErWThq;
    }

    if (BErWThq != 680585.4619834125) {
        for (int uwauiIAW = 1095927185; uwauiIAW > 0; uwauiIAW--) {
            JBHuWWtnUCojuOQa *= JBHuWWtnUCojuOQa;
            IanDKdTf -= IanDKdTf;
            IanDKdTf = IanDKdTf;
        }
    }

    return false;
}

int TyDJoEgGKiVPXf::QuDUQ(string StqfyZTFujosdaWX, double UcoVO, double WnQUrDQBTNfmaT, bool DeFiSqPEb)
{
    bool maZqMbB = true;
    bool wEtKEBlbITnlTGf = true;
    int SPTVcdQqo = 267398436;
    int dwHZBWyobFfc = -1681952751;
    bool eUVSGBCWJXo = false;

    for (int EeAqNcGwkZaMhx = 471891262; EeAqNcGwkZaMhx > 0; EeAqNcGwkZaMhx--) {
        DeFiSqPEb = ! eUVSGBCWJXo;
    }

    if (eUVSGBCWJXo == false) {
        for (int oUgTtLCXDo = 1822264710; oUgTtLCXDo > 0; oUgTtLCXDo--) {
            DeFiSqPEb = DeFiSqPEb;
            DeFiSqPEb = wEtKEBlbITnlTGf;
        }
    }

    for (int geOHjiVjevALX = 131387127; geOHjiVjevALX > 0; geOHjiVjevALX--) {
        maZqMbB = ! maZqMbB;
        wEtKEBlbITnlTGf = eUVSGBCWJXo;
    }

    for (int CULMx = 2062824846; CULMx > 0; CULMx--) {
        continue;
    }

    return dwHZBWyobFfc;
}

double TyDJoEgGKiVPXf::oQxDypSDNHdzRmdx()
{
    double lykWdLNudCPowJ = -370975.17730769445;
    double PGGqIi = -697253.871554185;
    bool uNgatlkctcu = true;
    string oCMhtnQSJTEoYI = string("kpXBIuHmtaiBMpYrbZQkUreUTfsDdsfLZVVAheApUHkNNaVhvaQCuktaToUwbWxuVOQsGkfEpVhfyybNEfkaIIvtXKCQGPghmfbfeVpvJMdTSyfNomhpKIxmJhjjNRFkPJFtLMgoXFkVfIZaCouJOpHtmVHrgtgfwZUFLmzOVTPYPPLvVmsQEpPVfdCdEgTEWfqftZYmwAPzbtKeF");
    double bSOZIy = 148956.96423849458;
    bool hYMke = true;
    bool tgYUlXO = true;
    bool LFmsAD = true;

    for (int bpFxndeFH = 223673680; bpFxndeFH > 0; bpFxndeFH--) {
        continue;
    }

    return bSOZIy;
}

bool TyDJoEgGKiVPXf::sAmpAf()
{
    string lkEsyqVMyloiay = string("hzAmIubnwTvVACdSdrvoW");
    double vtDoodTgTlJ = -108108.75677067183;
    string VNEDVanu = string("sFqPOPVWkZwSJZXyWCqveMDdenmkkYkshsbazekwqpKuzyTuGwZGKMlkxLZYudAlYapVzbnPqTEzKGuTrTEjUZleYCFeFRRGKVzISNHfYMURveFlgLxzpcgQwguTehgFDixQKIkplyyMfqEEnRFZSVeZvdkNVewoetoTLmONguLsrdzEFjYWeAXbDcsnbuGzmWuNAhpbGBXiUgbKpDDmmFTjBTiGKWbEPqghBnfVsEIhVCPruGMZFt");
    bool aeYNTz = false;
    string JhVmCJVFik = string("agdPDRQRBEfSZFNAoSOcSlJQVqcJAuOiOnXKeBGbbJQlzbFPIMXcIaBBnLVnMIJGMKchwBmHowktIwIgAOXVPfNofjrxpVgNZYludcKxfIeaZQsEIFvUfEWHLClstJYOvwTqkAVFOFcmOvGmrsPgrBhAYHYZuCAjmvJtDNFtqNdkkFootTMeyLVhEokCnTFSvbIJowjpBWOgFOLVLFzzaLqBgTkzLcmH");
    double HmjACxNNggQK = -451630.28006575874;
    bool StzXOocPQH = false;

    for (int sXpANMvAGQT = 863531156; sXpANMvAGQT > 0; sXpANMvAGQT--) {
        JhVmCJVFik += lkEsyqVMyloiay;
    }

    for (int UhBXEftXAJGweZ = 1673435951; UhBXEftXAJGweZ > 0; UhBXEftXAJGweZ--) {
        continue;
    }

    for (int lSwtZakYYmnSwQ = 161989022; lSwtZakYYmnSwQ > 0; lSwtZakYYmnSwQ--) {
        continue;
    }

    for (int MhCQYKlefHPeciuI = 635904521; MhCQYKlefHPeciuI > 0; MhCQYKlefHPeciuI--) {
        aeYNTz = aeYNTz;
    }

    if (JhVmCJVFik <= string("sFqPOPVWkZwSJZXyWCqveMDdenmkkYkshsbazekwqpKuzyTuGwZGKMlkxLZYudAlYapVzbnPqTEzKGuTrTEjUZleYCFeFRRGKVzISNHfYMURveFlgLxzpcgQwguTehgFDixQKIkplyyMfqEEnRFZSVeZvdkNVewoetoTLmONguLsrdzEFjYWeAXbDcsnbuGzmWuNAhpbGBXiUgbKpDDmmFTjBTiGKWbEPqghBnfVsEIhVCPruGMZFt")) {
        for (int XISUoU = 1576816941; XISUoU > 0; XISUoU--) {
            VNEDVanu += VNEDVanu;
            lkEsyqVMyloiay = JhVmCJVFik;
        }
    }

    return StzXOocPQH;
}

void TyDJoEgGKiVPXf::qwLwV()
{
    double JjsclsLJvfg = -76750.27316405234;
    int wPXhhpW = 551062541;
    int ZotEUKTVD = 725534054;
    int JlkoLGtBKNQ = 1428983493;
    int qdgWhii = 1120814469;
}

void TyDJoEgGKiVPXf::bEwTRHf(int cerJKrSPbiH, double tPBHQOTgoZWgb, double mdzJQSbDDgjp, double rfZMx, int jUQKfVS)
{
    string LdZmaD = string("OcnTnyUlaroDAORwfEobtZBwMzGrXNLriVXVzPiknHrCblpmdySijjcPetRfrqNZxdZefzZhhzZheFNbnWtoxIwafRSXnChKktpsrxKKjeNYggDibsdxojDRYQNibyQvlzXsHsRWjPhmQRDoTMLCTuMgAHAEzxqzEPTWdKnXtweqcrWWLxu");
    int qSFqucnHuloz = -968093782;
    double CXDhlMSuBWAQpgI = 762209.1260223911;
    bool dBcTJVXxjcgBwRwK = false;
    bool mkncCAoBrf = true;
    bool RJgPAIUCUj = true;
    string mtPsXOSw = string("xfKKjqGiXqDQoFTidjEVhnOMCFJOgGHFBVVxyVUnzCTXqUdzAwEJIguaXozoiCXUERzpakbsgoTXQpjljtLWEuHLzCOBgfBrKOPixgswLnMbGoERIoxeNFZSNWYefgoaZXvBnCNFZWGSpLYXWcacCBSPOVSMAmeqyUlWvuZjHuIL");
    bool IAPxJez = false;
    int xsZZxHiLyyHBe = -1494197152;

    for (int tsgNXzibDIsV = 145290158; tsgNXzibDIsV > 0; tsgNXzibDIsV--) {
        continue;
    }

    for (int RXlWpDhcalxs = 1673315860; RXlWpDhcalxs > 0; RXlWpDhcalxs--) {
        mdzJQSbDDgjp *= CXDhlMSuBWAQpgI;
        mtPsXOSw += mtPsXOSw;
    }

    if (qSFqucnHuloz < -1473519553) {
        for (int yRIYcbhFQXNFNiY = 590827169; yRIYcbhFQXNFNiY > 0; yRIYcbhFQXNFNiY--) {
            cerJKrSPbiH += jUQKfVS;
        }
    }
}

bool TyDJoEgGKiVPXf::BKLiMym(double amkal, string XvWVxedjDODBtlC)
{
    bool WXqfYRtatUDq = true;
    string RnJkW = string("DUqAYeJgTdvbGuKHXdWCJpJJqkQlKkHVWXV");
    string sEUscEzrfbnvxCGr = string("wnpaTFxRdBsBAOhRxNCbwAuDdKnCwrwjwuJlZkzHbLeIsAxWXCjGftjwaxXrhAyddFgjcAJZHkzydDXSrFJWINHzGrHOwfoCprxneQkoVMjIBZYDspCfQSneeyEkIxZtyGWoIrGkOSfyStXroKpWVDVagDiaUZqlogfxAZDkBbwPnrpoRkhaAzlMZAvFCrfRAyfsRtMxStygwOQWbmQsJOhNuPvdKPBDbRuryOAYpiavpfjGtojszWVMM");
    double hrswycKIFvrQ = 642773.1152235577;
    int nGfmevmUC = 2137667201;
    double XhvgjEMaqRQGBml = 270487.27176707075;
    string JTBYFIuVLbYM = string("PasljhcjjPTGwY");
    int cWEgIojbRIy = -997209541;
    bool WrTWsGqTapzk = true;

    for (int HSBSOyuZ = 1428805020; HSBSOyuZ > 0; HSBSOyuZ--) {
        nGfmevmUC += cWEgIojbRIy;
        amkal *= hrswycKIFvrQ;
        XhvgjEMaqRQGBml /= XhvgjEMaqRQGBml;
        cWEgIojbRIy = cWEgIojbRIy;
    }

    if (nGfmevmUC != 2137667201) {
        for (int pNQZiFjGTtnU = 792867694; pNQZiFjGTtnU > 0; pNQZiFjGTtnU--) {
            continue;
        }
    }

    for (int dxzbsT = 1982255482; dxzbsT > 0; dxzbsT--) {
        continue;
    }

    for (int saBRPhPfxrGiFFVD = 1632313115; saBRPhPfxrGiFFVD > 0; saBRPhPfxrGiFFVD--) {
        cWEgIojbRIy = nGfmevmUC;
        amkal /= amkal;
        RnJkW += JTBYFIuVLbYM;
    }

    if (cWEgIojbRIy >= 2137667201) {
        for (int JmxaG = 2104926591; JmxaG > 0; JmxaG--) {
            RnJkW += RnJkW;
            XvWVxedjDODBtlC += sEUscEzrfbnvxCGr;
            JTBYFIuVLbYM += sEUscEzrfbnvxCGr;
        }
    }

    for (int XwCCJOGVr = 2105305560; XwCCJOGVr > 0; XwCCJOGVr--) {
        XvWVxedjDODBtlC += XvWVxedjDODBtlC;
        nGfmevmUC *= nGfmevmUC;
    }

    return WrTWsGqTapzk;
}

double TyDJoEgGKiVPXf::nzQvGfdydHuD()
{
    bool aWGkpfmSGZnoIshC = false;
    double tyahJMXBR = 706163.6106706695;

    if (aWGkpfmSGZnoIshC != false) {
        for (int TqOwOoksjwZaQJe = 618177958; TqOwOoksjwZaQJe > 0; TqOwOoksjwZaQJe--) {
            aWGkpfmSGZnoIshC = ! aWGkpfmSGZnoIshC;
            aWGkpfmSGZnoIshC = aWGkpfmSGZnoIshC;
            aWGkpfmSGZnoIshC = aWGkpfmSGZnoIshC;
            aWGkpfmSGZnoIshC = ! aWGkpfmSGZnoIshC;
            tyahJMXBR -= tyahJMXBR;
            aWGkpfmSGZnoIshC = ! aWGkpfmSGZnoIshC;
        }
    }

    if (tyahJMXBR < 706163.6106706695) {
        for (int GyfGvLyUjSVJ = 1813236505; GyfGvLyUjSVJ > 0; GyfGvLyUjSVJ--) {
            tyahJMXBR -= tyahJMXBR;
            aWGkpfmSGZnoIshC = ! aWGkpfmSGZnoIshC;
            aWGkpfmSGZnoIshC = aWGkpfmSGZnoIshC;
            tyahJMXBR *= tyahJMXBR;
            tyahJMXBR /= tyahJMXBR;
            aWGkpfmSGZnoIshC = ! aWGkpfmSGZnoIshC;
        }
    }

    if (tyahJMXBR == 706163.6106706695) {
        for (int kvqEtmfYJiix = 1818229250; kvqEtmfYJiix > 0; kvqEtmfYJiix--) {
            tyahJMXBR += tyahJMXBR;
            tyahJMXBR *= tyahJMXBR;
        }
    }

    if (aWGkpfmSGZnoIshC != false) {
        for (int hFQzH = 1012053364; hFQzH > 0; hFQzH--) {
            tyahJMXBR += tyahJMXBR;
            aWGkpfmSGZnoIshC = aWGkpfmSGZnoIshC;
            tyahJMXBR = tyahJMXBR;
        }
    }

    if (aWGkpfmSGZnoIshC == false) {
        for (int MECOVGodCYq = 1559516550; MECOVGodCYq > 0; MECOVGodCYq--) {
            tyahJMXBR *= tyahJMXBR;
            aWGkpfmSGZnoIshC = aWGkpfmSGZnoIshC;
            tyahJMXBR /= tyahJMXBR;
        }
    }

    return tyahJMXBR;
}

int TyDJoEgGKiVPXf::IPwBQImRhOVSjDM(bool gCmvYKnm, bool QgQsxWBk, string HtZROW)
{
    string bDnskeTkdSvYxv = string("TQtjHQlAUYdmiJclCaMNxVETqPQAoJCULsDKNSZWeOGWOhESQ");
    double WZQMfHdaFDEb = 928450.4113258991;
    bool GCAnm = true;
    string QadHk = string("rYyXvRasXXnZXsjyCFmSuoUMGTbvWceZnYMfrKzgIInJlEqNfqXBPOeshOTKnqDEScNhVpQwzMRUnJabszrbvxMhKpOSeJzuWbYuZfsIizwnAIagYdsgbgbbfvKkdCiAfDNnizopGLnNsHHBBccQXslkzzZQWjvLnUVNZHdlBYhZTmMUdjHXfCMKGyu");
    string GoyojqUGV = string("mhVoVdZMKerFzXQLOOTlTYGBLqJyCWVJIM");
    string BcDWCrW = string("KBJXNiicdfSmimJzRpOImhstnlWCuTzPrfkujtGEWvOsmQqoxUPuxbarXkfDcvkJqhGQVquWbHvhsSpWQpFpbpxpVBqHrmvEdkmKhRILCKXcmGxrrkISSjeyuBvSizriSlTEXTEqAsfMvSsUAIWVkmaRmVbOCOlJNvwVIXZGkpwYdpukvGtnlA");
    double lblVrZKvwguCLR = -895726.0414841216;
    bool EcvMtOFO = true;
    bool eKjwpHH = true;
    string OLCMRtkx = string("ZfAeEuSCuQtiEqFKgqFpjFxpESaBUxMLGorSNdCcEGIQWlyHxdRVoVoADvDkXdxGTGsIoXNoZsNfXQdBjmaSBThPTdoysgAzkvKRszUrbeYUHuUzIhZunnYcMDPRZwvpmlGOtrEzogHMwCtnDJUxqzTFJTuExXiblbMOLVrcOeUNyqcnracvxQQagbaiNUicqTDFCyqydDriaIwrKzOKMVBUYOlyUUOcXIwkhyMCwfHwzfbbMUJseqKAoOIjO");

    for (int QTVpmDoPifP = 982632091; QTVpmDoPifP > 0; QTVpmDoPifP--) {
        BcDWCrW = OLCMRtkx;
    }

    if (HtZROW <= string("ZfAeEuSCuQtiEqFKgqFpjFxpESaBUxMLGorSNdCcEGIQWlyHxdRVoVoADvDkXdxGTGsIoXNoZsNfXQdBjmaSBThPTdoysgAzkvKRszUrbeYUHuUzIhZunnYcMDPRZwvpmlGOtrEzogHMwCtnDJUxqzTFJTuExXiblbMOLVrcOeUNyqcnracvxQQagbaiNUicqTDFCyqydDriaIwrKzOKMVBUYOlyUUOcXIwkhyMCwfHwzfbbMUJseqKAoOIjO")) {
        for (int kiqMdfwPPzvWhj = 767402043; kiqMdfwPPzvWhj > 0; kiqMdfwPPzvWhj--) {
            BcDWCrW = OLCMRtkx;
        }
    }

    if (EcvMtOFO != false) {
        for (int IqjRQDtjNDHho = 1470687083; IqjRQDtjNDHho > 0; IqjRQDtjNDHho--) {
            HtZROW = HtZROW;
        }
    }

    if (EcvMtOFO == false) {
        for (int MRkyXz = 1209176002; MRkyXz > 0; MRkyXz--) {
            gCmvYKnm = ! EcvMtOFO;
            OLCMRtkx = HtZROW;
        }
    }

    if (gCmvYKnm == false) {
        for (int LWaoVPVNkRibj = 609622624; LWaoVPVNkRibj > 0; LWaoVPVNkRibj--) {
            continue;
        }
    }

    return -1990483493;
}

bool TyDJoEgGKiVPXf::RZovfbQIEPasqh(double lOtWTeoZCQqCnQaJ, string CzCzpHNkijrM)
{
    int hWgka = 377660746;
    double mcCbX = -156398.13163654626;

    return false;
}

double TyDJoEgGKiVPXf::kZbYqjqfYnDL(bool erkkqPXdbNKtT, string IWroN, bool nxRDvMukSSPlXSO)
{
    string WymXXEOmcMlXOoJ = string("BSqs");
    int RFqyOntLOOkxt = 1792910474;
    string VJKiRXNYw = string("EhafUQKkThLABzqcfoHLusVcTrYNFSgiDkuq");
    double EOGfBhRooYIn = 92667.9366205687;
    string lItTDLClyRW = string("jCdXAGqXZIrNvpMZqaMbERuPyBeLqZMImTCiXSxSPpLJmKZkbssAmQmDyNebGKNAtpSYyBGaxEXWryQOYBeRkHpgXcnlozsbGquugdMYHfjDxICuMXOZYRDMqZzvvGrnPeNbZGDAKWLadgJOPAnxWgHtYegwwSSQYwlArNeMzWWwkRBTQNvvZvbIIPpATkBhADDfqEljtgeEKvkjyfbrqsjDiCiksRrmJRUilDlhrIbEyJGTH");
    double aknzUuQPjyw = -920587.7569242254;

    for (int NHYKMGQUwkex = 1360969449; NHYKMGQUwkex > 0; NHYKMGQUwkex--) {
        WymXXEOmcMlXOoJ += IWroN;
    }

    return aknzUuQPjyw;
}

void TyDJoEgGKiVPXf::pWjLjbPYbBkmiNrO(int fSnfK, int SialsKihPfh, string wIwfc, string wgJwENtpMWQLcDXG, bool nxksnQluZvFQ)
{
    bool YgfcleJn = true;
    double fsVoQYeNhO = -997864.3492309969;
    string cGJjaY = string("VZcnGvrELJSQqSrzCxOwSQyQXWTOCPeFlRIBVOUTIdvxTWyynO");
    int bQkwQPZWanCUar = 1385015773;
    double IhjJPESd = -413927.58084914327;
    double Tygwi = -746074.3861052992;
    bool uGyvUoErxpsz = true;
}

int TyDJoEgGKiVPXf::HcKBFy(bool HkIqHreeTcqz, double JuckBCatRlAdJ)
{
    string GYgqYxqb = string("QCQneFLQpUrmaeFKElyVZjsMzFEFGTXEpDYDOAxwlylYrASyrOVuDkqnIxBprljzqXKOGx");
    bool IptXnkIPY = true;

    for (int KYsFWjUqxPztdo = 1471625079; KYsFWjUqxPztdo > 0; KYsFWjUqxPztdo--) {
        IptXnkIPY = ! HkIqHreeTcqz;
        HkIqHreeTcqz = ! HkIqHreeTcqz;
    }

    for (int fBwstpfJBVyM = 1054969300; fBwstpfJBVyM > 0; fBwstpfJBVyM--) {
        continue;
    }

    for (int WeweYF = 595557584; WeweYF > 0; WeweYF--) {
        IptXnkIPY = IptXnkIPY;
        HkIqHreeTcqz = ! IptXnkIPY;
    }

    return -552465553;
}

int TyDJoEgGKiVPXf::XmlrYTiiMBOMj(bool fRhFySzFI)
{
    string lIOsCEpOGfJz = string("CYZZFdmMzZkGNQxisfCIFVbSlonHzQKpYYDUTBFmXweczNwGnZWrmJfhrIBzqKzLYelwMmAjtpRmAllYCBvAFuQBsLxflOIrcAfwsVvuhLYTHbHti");
    string orBXSPvZfx = string("UxaREFiAtqqglUZquwdjLEhPKhhxnhbOkrCcmcRnVGwfWGPqyctmMoEmQGItubsqphnfnyTVUrrvcybvYVZhyLjUPiVpghJwwCatiYeoOASoUlFqmvYZLjiKziaXgofGJsoHJQxBVTqoLykhETGGVNBcUhhmljPBxUAMOrstCDSmPIZcJpZwnvbKqN");
    string bkLICxOZA = string("TIxpuWWtGSewUBgupFNRIIxuLygtVUujKPyFzWxhwNezZRlqXgaaTDDkQsPJzSxxyMjqVqfCwdEAkLVayTVnLavnAFSFkMQhHqThvKXXjXxoBgPcYjCPRngjnudipstFrIFeaNZnNkQwJdETGtMAawChlOhGCwIcsoXNpUBarxzWMHXQcnYmJbeaAEdXOMiXvz");

    for (int okYJKpTW = 606919880; okYJKpTW > 0; okYJKpTW--) {
        orBXSPvZfx += lIOsCEpOGfJz;
    }

    if (lIOsCEpOGfJz <= string("CYZZFdmMzZkGNQxisfCIFVbSlonHzQKpYYDUTBFmXweczNwGnZWrmJfhrIBzqKzLYelwMmAjtpRmAllYCBvAFuQBsLxflOIrcAfwsVvuhLYTHbHti")) {
        for (int YcDPcyRIlwHqx = 613612010; YcDPcyRIlwHqx > 0; YcDPcyRIlwHqx--) {
            lIOsCEpOGfJz += orBXSPvZfx;
            bkLICxOZA = orBXSPvZfx;
            bkLICxOZA += orBXSPvZfx;
        }
    }

    if (lIOsCEpOGfJz > string("UxaREFiAtqqglUZquwdjLEhPKhhxnhbOkrCcmcRnVGwfWGPqyctmMoEmQGItubsqphnfnyTVUrrvcybvYVZhyLjUPiVpghJwwCatiYeoOASoUlFqmvYZLjiKziaXgofGJsoHJQxBVTqoLykhETGGVNBcUhhmljPBxUAMOrstCDSmPIZcJpZwnvbKqN")) {
        for (int IktUnsc = 80666882; IktUnsc > 0; IktUnsc--) {
            orBXSPvZfx += lIOsCEpOGfJz;
            orBXSPvZfx += lIOsCEpOGfJz;
            bkLICxOZA += lIOsCEpOGfJz;
            orBXSPvZfx += orBXSPvZfx;
        }
    }

    for (int ptbSFdnUYfhisX = 414650862; ptbSFdnUYfhisX > 0; ptbSFdnUYfhisX--) {
        orBXSPvZfx = bkLICxOZA;
        orBXSPvZfx += lIOsCEpOGfJz;
        lIOsCEpOGfJz += lIOsCEpOGfJz;
        lIOsCEpOGfJz += orBXSPvZfx;
    }

    return 1006144354;
}

TyDJoEgGKiVPXf::TyDJoEgGKiVPXf()
{
    this->zqyrWTuGQZYraPE(string("CUvksJWRCYmhbxZgKFaSqVoVECoTRyPzhpBQWjAxwgNskkFANSlCJtrZkMAmMxTkrFKQsQmPrFowSmKvLmuCOEeKaPh"), false, 1729891071);
    this->tXenvMYVYso();
    this->xYZnkekFCppPSd(false);
    this->GNwSKMq(string("WyGrGWDWztnNtMGYxcYWttWdsaDiXLRDmpPijGhSIOtMLJZTlNDLxEDIMPeKuaZqzHmCtbMuHqTtRLzjGXyBZIXiraAZNzJxuTUfkEcvRAmXPrrbICwMZGdGPPrCrAbYFoGuZKgRxUpjtYmAzdhRDyTBpRFjnxuozgehDrvoVTWFelCOwHeOoDCKEyltxgZNXpyIKeoJlOkbYyZvqDDeVmPsXhggwreCM"), -608423265);
    this->PYtAllLGoSmNj(-638776323, true, true, false, -765475.9285270451);
    this->ErCfKbz(-724533176);
    this->QuDUQ(string("IQSNJXRNwLjjUkCilZCOUVntfwPwYsxTQMnCGPspRPMiGwFsGPpGhgngdjwbArYToVcdmQWfjqeapAnrlGmtPDuwfBGsWLcWRoXpRBO"), 761697.3306589477, 605300.3997187534, false);
    this->oQxDypSDNHdzRmdx();
    this->sAmpAf();
    this->qwLwV();
    this->bEwTRHf(-1421087860, -1035672.1310988764, 1019262.2458581204, 865465.3306516078, -1473519553);
    this->BKLiMym(-670653.0608820514, string("dSfGoInqvMLiHzkLSIHwkeBrGihUWlygpDJEzmxmyKogvdawMwXeOmbxYYRcMOCxjrlQAKnyJhxdtvnucEyMWNIKaezvPxpdRFxjJAHlqvaNJWiDCEXCZRbUXlcgJZrRMJZuFISbNUHSrUMLtcDVhFbWsYhZZdXTyBYAoibuPqIOZmWKqwVvx"));
    this->nzQvGfdydHuD();
    this->IPwBQImRhOVSjDM(false, false, string("CYLBEQCTsPYRPFHZHaSvetmDqRNVItYrZjFGBelYIvqZPLwrBFiVNaWDaeaEqYxtBRLzNdCIlXPWvkAJkUVELbjAiNWSqFWMoZTmDTntKCkifPdaarnZJRjDTUONcHgyPHlPdlcFbWAksRtUiKkxGncLMFaKuGWCMjoszOcloALczirYZbGYRIyVmWkkjwIF"));
    this->RZovfbQIEPasqh(-692415.5107226938, string("JjSRBnTVMtfjVyZpxNqVORGVIRxGPVonFbnY"));
    this->kZbYqjqfYnDL(true, string("KJUlkMdOALdMIHFZDEVeUwZNrGmZIRoohBtZjuTxkfgUTESfyJJBVCgITJzpNjgdWdBenlWgjlFUhuosPDXhXBtNORLCfTAbpDqetfCwRmAbGkxDOCCwkaQfZlpVtxkALkFCdY"), true);
    this->pWjLjbPYbBkmiNrO(1100775803, 845381924, string("QRKuSdgLnzTQOfCHkLioBVeBqweuCEHZcHkDrcEkNnmpDrDbiPaUPQpWRtYlEIGyxJAUebvTvzcvYNfPqwyIfiInnPLAYqrlXlnyPizdPPIIIswOvTtyFCZYfGbQaCjKovRBcauaglkswYicCjpgkPaFJqEkqYdxAFwUfGKkuScHBiCXdRQqhmJHtJCCsCZFnpssrqukmWwSMwBunoMuEFIIuOZOLctAbtjhFHZiLGyIUQAQCJREPjtExceYdX"), string("wQOPgKhZIQyJiEMhylEoPbbLfHckjfrOQbjrvrHLXTDJvPvNPDCFYZekWmsfmgPEDOtiGbDvIQwgSZpDddzMrQKHXVBXYxOESCMdpCHsJNUYhNwslnFIwXXrYDRzdhpvpLKTIqhAwd"), true);
    this->HcKBFy(false, 683240.6540820858);
    this->XmlrYTiiMBOMj(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ckyaucFxPi
{
public:
    double tFsezk;
    string MSUSlEdKHiZioMD;
    double iUIwM;
    string KFsyBXHHBCdQL;
    string cTEwYPuzvnBRqx;

    ckyaucFxPi();
protected:
    double vdJJcfPAcmOwHqZ;
    bool DYNlaK;
    string OQnAVkoaUB;

    int VeHgunWFhyiC(int OxbjjgTgmssh, string IPAPQuvGzhmb);
    bool NDTIcsvXRzn(bool yJQwvUOeh);
    void jVCUV(int mSNfsg, double PZCOUZkSMIvBwgN, double toHqNJDgqQnCQPAW);
    double xzarmDFMAMEEPFH(bool XLxraKwaYUYkppi, double koDQNnzBmo, bool JXuytKQP, double mQMJMDTynWoR, int GTlYThcTsTU);
    int COwAuVK(int kTCOIcktycfziE, string EoANBeJp, double DOnvwSUmgH, string wfzBwEYXjNCnf, bool MGrNixQeP);
private:
    string WvwenhzfwqF;
    double LxCEUmepmuxo;
    bool naspiutUztpy;
    int qhDpqGdSonjecIhf;
    double zklAKms;

    bool KOMzFQi(bool MlLBJYu, bool IlZstBDTciB, bool tZykkFb, string LuDResTpmiAAQTyz, bool UTzEuTucUbwZ);
    string aaaEuCeL(double MzxjbyGlH, bool dlJtotN);
    void yTEZdT(int vdejbQcQ, double mMjGhoweDk, double wSeyOzywGjcdXkg);
    int jHUVwBjtRhpdhB(int trLwvVcC, double haHVqEIfpHbus, double TTHdCMnz);
    double QojvYL(double mFIPMUd, bool nOYCqv);
};

int ckyaucFxPi::VeHgunWFhyiC(int OxbjjgTgmssh, string IPAPQuvGzhmb)
{
    int cLVZMivVstlgzyan = -672462760;

    if (cLVZMivVstlgzyan >= -1413135500) {
        for (int rbUfgNIMxiYvebK = 1946865979; rbUfgNIMxiYvebK > 0; rbUfgNIMxiYvebK--) {
            cLVZMivVstlgzyan /= cLVZMivVstlgzyan;
        }
    }

    return cLVZMivVstlgzyan;
}

bool ckyaucFxPi::NDTIcsvXRzn(bool yJQwvUOeh)
{
    bool vayPODmBX = false;
    bool eoJmsXpZyhh = false;
    double yikrLMz = -23608.300520354835;
    string ZsaydVpjAAFfRFl = string("RVYJi");

    for (int hBBWZHyc = 2093978498; hBBWZHyc > 0; hBBWZHyc--) {
        yikrLMz -= yikrLMz;
        yJQwvUOeh = eoJmsXpZyhh;
        yJQwvUOeh = yJQwvUOeh;
    }

    for (int nqfNfkwoBI = 2098105976; nqfNfkwoBI > 0; nqfNfkwoBI--) {
        continue;
    }

    return eoJmsXpZyhh;
}

void ckyaucFxPi::jVCUV(int mSNfsg, double PZCOUZkSMIvBwgN, double toHqNJDgqQnCQPAW)
{
    double ZMxFntDmGawIN = 690248.3307067797;
    double VevOggHAqQj = 611328.0949348692;
    string eEdsggEmElVLGU = string("WAfzpIdvsJwDzInfyHKPzEkdvokCfkDoumfSCmRssgeqPzjadPdVKgXWxZVsJskAFsNYIsdIVDIolmmrxWlgzwmYgMDGUrTOnXfXWGmYMLoIZoUHoGRrDc");
    bool lcIqqGoEcZzRTUqI = false;
    bool NyzwQttWQanEwe = false;
    int EiRAzbcD = 1554600181;
    double tERBeTSJaphACJj = 390892.5853421321;

    for (int YyjyaqMj = 2035924917; YyjyaqMj > 0; YyjyaqMj--) {
        lcIqqGoEcZzRTUqI = ! NyzwQttWQanEwe;
    }

    for (int dIIzbfSxlKSXC = 1722945686; dIIzbfSxlKSXC > 0; dIIzbfSxlKSXC--) {
        ZMxFntDmGawIN /= tERBeTSJaphACJj;
        toHqNJDgqQnCQPAW -= ZMxFntDmGawIN;
    }

    for (int nJBKQiXpPShim = 1647416416; nJBKQiXpPShim > 0; nJBKQiXpPShim--) {
        VevOggHAqQj -= tERBeTSJaphACJj;
        PZCOUZkSMIvBwgN *= tERBeTSJaphACJj;
    }

    if (VevOggHAqQj >= 390892.5853421321) {
        for (int XefxKAssyMoVvXm = 1429018630; XefxKAssyMoVvXm > 0; XefxKAssyMoVvXm--) {
            tERBeTSJaphACJj *= tERBeTSJaphACJj;
            toHqNJDgqQnCQPAW = VevOggHAqQj;
        }
    }
}

double ckyaucFxPi::xzarmDFMAMEEPFH(bool XLxraKwaYUYkppi, double koDQNnzBmo, bool JXuytKQP, double mQMJMDTynWoR, int GTlYThcTsTU)
{
    double mIndP = 103361.57618378;
    string vWiwFWwt = string("gfGqWCVPLjLlKrjIRKzGHoCPQmOdVbMphbCEfGFeYHbCmbsTmCUmltLvfrFJBfykMFziBrfNDPGWNjVsCzjgzpMVuHHYBbpBVJF");
    double ULAgovpWgNHhdM = -439613.0599236548;
    bool kyYTw = false;
    bool YJtXtTCpPbSe = false;

    for (int dqiGxxVlI = 1607803371; dqiGxxVlI > 0; dqiGxxVlI--) {
        continue;
    }

    return ULAgovpWgNHhdM;
}

int ckyaucFxPi::COwAuVK(int kTCOIcktycfziE, string EoANBeJp, double DOnvwSUmgH, string wfzBwEYXjNCnf, bool MGrNixQeP)
{
    string nrPcDCNIfERaLrSM = string("hGHeeqlXOyCJzWgkHmVPbgNTosAYKNxOAQZMN");
    bool fFTrRRQNJZHzQOed = false;
    bool tBRyH = true;

    for (int QxZohokojcpAiRiv = 132536554; QxZohokojcpAiRiv > 0; QxZohokojcpAiRiv--) {
        continue;
    }

    for (int BpqAIrqPuHofLTg = 686499905; BpqAIrqPuHofLTg > 0; BpqAIrqPuHofLTg--) {
        MGrNixQeP = MGrNixQeP;
    }

    return kTCOIcktycfziE;
}

bool ckyaucFxPi::KOMzFQi(bool MlLBJYu, bool IlZstBDTciB, bool tZykkFb, string LuDResTpmiAAQTyz, bool UTzEuTucUbwZ)
{
    double Hctfny = -488294.0820851331;
    string xISnQDigDBOhUp = string("typnWbFnscrZMIzqllvXDYSE");
    double VfArmBppZOJRPTp = 432265.0210345777;
    bool PVIEuz = true;
    double WzBLGYhajfhMF = -522344.1194388594;
    bool ZsjgOCiQ = false;
    double nxlPJrC = -52518.89677005166;
    string mojkQKRudVgXVL = string("ndfhoFSyAhYTZwyvAxiFHxJYcgVVjBJfGBILUzZbzrrFtpWZTzSbHzHDVCfqEqxfylwDVdzTiTfchIRHnPAAYZhTxItTjXfRVydTcPCXuhFYXdchCceCOqfWkoTqmAkpUxWCTZAXJEVuYgjOTGKjNBDIkLFTlqZBCJRQjPjEZbmssCZqWMoQjnkJvXuWfvbODzAHlEruKutSgJFStQYsTrEgFslWqUoHjxuyxZUmEQaTJeR");
    int MUxgxWHqgAeCY = -347288854;

    for (int fuBms = 16656020; fuBms > 0; fuBms--) {
        ZsjgOCiQ = ! MlLBJYu;
        tZykkFb = ! UTzEuTucUbwZ;
    }

    return ZsjgOCiQ;
}

string ckyaucFxPi::aaaEuCeL(double MzxjbyGlH, bool dlJtotN)
{
    int uxKuIQGlSM = 1695682620;
    bool eglmYptxR = true;
    double UckPSzikClV = -143986.49512388065;
    int fjXrUEvZaZx = -544341088;
    bool mWXvRiABV = false;
    string nzwBbq = string("YtKVARVSQYTRSPdOejORWDxygpCQNdlwetBZsMnhWkIksFegexEfCaRAeXgCKzINHOnULSOYXzputnKjIBqytVqXIAZwfQHnvQlgVPZLNMqnSUEsduOmYbCMLuMhPMjCmCSsCuVSWGlptasqnpWhiAyFITIpdAlRHeZTntprbWZyLUyBSOkmzVSuuxZvF");
    bool ADsYC = true;

    if (UckPSzikClV > -143986.49512388065) {
        for (int JywEOFfANrEJZRJ = 2079803018; JywEOFfANrEJZRJ > 0; JywEOFfANrEJZRJ--) {
            ADsYC = ! mWXvRiABV;
        }
    }

    return nzwBbq;
}

void ckyaucFxPi::yTEZdT(int vdejbQcQ, double mMjGhoweDk, double wSeyOzywGjcdXkg)
{
    int FZxcfhy = -381355106;
    int kReIsljTO = 1759419225;

    if (mMjGhoweDk != 750536.9777971857) {
        for (int SxBPZijZUWD = 1034181414; SxBPZijZUWD > 0; SxBPZijZUWD--) {
            FZxcfhy /= kReIsljTO;
            kReIsljTO += vdejbQcQ;
            FZxcfhy *= kReIsljTO;
            kReIsljTO /= kReIsljTO;
        }
    }
}

int ckyaucFxPi::jHUVwBjtRhpdhB(int trLwvVcC, double haHVqEIfpHbus, double TTHdCMnz)
{
    int HklReFJr = 1068510370;
    int IXetJaIuBmXpeBb = -1113326217;
    bool peJKB = true;
    string bluSUPVksY = string("auokrnLImjaVNszQbkoKiCdpUJxuOwalhAWCHy");
    double CfCticMm = 404756.5434248339;
    int lmzUxzCJUzsEzNN = -1494192946;
    double gsTgoAVEkiLYpga = 118968.66260077764;
    double jkRrfgXmKDCqIO = -76611.0466238121;

    if (trLwvVcC == -1113326217) {
        for (int zWAGxKFybQ = 1560669675; zWAGxKFybQ > 0; zWAGxKFybQ--) {
            trLwvVcC /= trLwvVcC;
        }
    }

    if (CfCticMm > -137151.53227164585) {
        for (int EZkuExXKxWPdhIu = 1751615508; EZkuExXKxWPdhIu > 0; EZkuExXKxWPdhIu--) {
            continue;
        }
    }

    for (int VmRihNXPUHham = 221284841; VmRihNXPUHham > 0; VmRihNXPUHham--) {
        CfCticMm /= jkRrfgXmKDCqIO;
        lmzUxzCJUzsEzNN += lmzUxzCJUzsEzNN;
    }

    for (int nLUwgjC = 1127552342; nLUwgjC > 0; nLUwgjC--) {
        continue;
    }

    if (trLwvVcC > -1113326217) {
        for (int hqaqwWZ = 543954151; hqaqwWZ > 0; hqaqwWZ--) {
            haHVqEIfpHbus *= TTHdCMnz;
        }
    }

    for (int XYBauPYuasd = 1233137573; XYBauPYuasd > 0; XYBauPYuasd--) {
        HklReFJr -= IXetJaIuBmXpeBb;
    }

    return lmzUxzCJUzsEzNN;
}

double ckyaucFxPi::QojvYL(double mFIPMUd, bool nOYCqv)
{
    int BhuyfQWZ = -600965431;
    string TNHKGDVL = string("hkZCTbTpxchZLGxJtVp");
    int OqjZaKUDTuGgI = 265588671;
    int HgCRltNn = 1452383903;
    bool tJKWcIhBrhlwtIg = false;
    int wijoyJrtJ = -52775663;
    int sLpndQJ = -2071295737;
    double MnpfYjrHAbEoCjet = -65925.43386875438;

    for (int WEVmyzxqOtbnFPME = 1556264339; WEVmyzxqOtbnFPME > 0; WEVmyzxqOtbnFPME--) {
        OqjZaKUDTuGgI *= BhuyfQWZ;
        OqjZaKUDTuGgI += sLpndQJ;
        HgCRltNn += OqjZaKUDTuGgI;
    }

    for (int Byorp = 1113451319; Byorp > 0; Byorp--) {
        wijoyJrtJ /= BhuyfQWZ;
    }

    return MnpfYjrHAbEoCjet;
}

ckyaucFxPi::ckyaucFxPi()
{
    this->VeHgunWFhyiC(-1413135500, string("aGwxSLAupBQuSgcLvkPjYISByOxjoDAgKLYjBoqHCfFzNOqFsDEMojSsLRToGbHeLTbEHxlAxckmCYAxthiRoMkYIcpujVGfsXClYYWXGQRJGWVKUSigWCsnycCvDUbbYRjjdsodTRRGPwxHZbkshvgQNeQeEVxVYgZrltlmAyUwkcSLWxwcRJbIAHGlbgyihkLNngufWdwJkKJxXOthPRlQMuohSDlhIlKxNENFkSHRKmcdIOBoSxHmHiSy"));
    this->NDTIcsvXRzn(false);
    this->jVCUV(481457699, -265900.9933119183, 999182.782902413);
    this->xzarmDFMAMEEPFH(true, -1014903.1385226358, false, -4523.086823847054, 1519373485);
    this->COwAuVK(-2025949500, string("qSjaHdMhZJVWdaEUXCXdpRZHzssXoBwKPTbnrnBZxNsrcFIIeyraVCelKsNfuPVkVZrlfiVdomgWUcwmnnwzhZBDjZZtlIXVcSwrBNTVOQkMlWsRogajcjjzTxFlgeEPfsoFwzBQQTnkaSNyBRFZOfOfkGJoFqrwIHZyodGKHqQCNZtWRaaUUtkaccTu"), 936175.2114166234, string("WJOAsOoBxsyRWLGaOlSTWAJqMgsocLyyEiRzRRXuWkMkoEVBSss"), true);
    this->KOMzFQi(true, false, false, string("ewzrhcxkHtzfybqNBOZssjINtnCrSJJFTwELlEEeeSpXAvUJmDqHJMUTPKZkONtLMofmpbXVGZoBUaVPXmq"), true);
    this->aaaEuCeL(379060.57751801383, false);
    this->yTEZdT(-194841631, 750536.9777971857, 956688.9423921069);
    this->jHUVwBjtRhpdhB(2038177496, -137151.53227164585, -937164.0074260358);
    this->QojvYL(-700165.4946697329, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UiJNBuRtK
{
public:
    string mFqMZgKwhDEsPSzV;
    double DAOmw;
    double YzfMNC;
    int vYSxeTpvUoW;
    int NbxZq;
    string BIInH;

    UiJNBuRtK();
protected:
    double hxPGESCsfQKj;
    bool NJATkIPMfz;
    string kdCuRizG;

    int JuquJzu(int EpDsYx, bool WZfldYaHYiIW, int vhFmgexDiGvPZpJM, int FXxyRKw, int SLVcsCS);
private:
    double bvrSAOvcQnzm;
    string SapzqMj;
    string cngSTrzFBKiMAVML;

    bool lfQdhCbLZhHewbSK(double ObfQSQZXEI, int oDlUuE);
    int dwLKgHBXzyjnUoT(bool EiYHAcyNJ, int ySizywzLDN, int oGiOySYAkZeKXxZ, bool BXMPbhFxLg, double dzSmLeUdLp);
    string ZCGcs(bool ObfhrEVJzsKbgZi);
    void ALTIGw(bool HhqkpckpfGQh);
    int tcZhIJS(bool kyuoy, bool uUzBbKACpHGlxC, bool zToAxasIEeUbYI, double NislJnjrAQS);
    void ZUCiRfWFpa(bool KFaWWnYcgJ, int rQYNuAAYFcm, string izQycqSffx);
};

int UiJNBuRtK::JuquJzu(int EpDsYx, bool WZfldYaHYiIW, int vhFmgexDiGvPZpJM, int FXxyRKw, int SLVcsCS)
{
    double ylIdAQAnKk = 20271.439354966642;
    bool BpiWHSeC = false;
    bool nzfkXm = true;
    double yGXrMtNdrXS = -273905.342604855;

    for (int jJvYlpFxIfVuda = 355494832; jJvYlpFxIfVuda > 0; jJvYlpFxIfVuda--) {
        nzfkXm = WZfldYaHYiIW;
        vhFmgexDiGvPZpJM *= SLVcsCS;
    }

    for (int AZVHAO = 580870921; AZVHAO > 0; AZVHAO--) {
        BpiWHSeC = BpiWHSeC;
        nzfkXm = BpiWHSeC;
        BpiWHSeC = BpiWHSeC;
    }

    for (int LiLwDEVYOwGY = 1698155436; LiLwDEVYOwGY > 0; LiLwDEVYOwGY--) {
        FXxyRKw = FXxyRKw;
        EpDsYx *= vhFmgexDiGvPZpJM;
        WZfldYaHYiIW = BpiWHSeC;
        ylIdAQAnKk -= ylIdAQAnKk;
        nzfkXm = ! nzfkXm;
        WZfldYaHYiIW = ! WZfldYaHYiIW;
    }

    if (vhFmgexDiGvPZpJM < -712704060) {
        for (int mvPqQuLYC = 1836595778; mvPqQuLYC > 0; mvPqQuLYC--) {
            BpiWHSeC = WZfldYaHYiIW;
            vhFmgexDiGvPZpJM -= FXxyRKw;
        }
    }

    return SLVcsCS;
}

bool UiJNBuRtK::lfQdhCbLZhHewbSK(double ObfQSQZXEI, int oDlUuE)
{
    string xHkWkPkYOqe = string("bAPcxikkAHcSUTdHkyxJHJwrmvoXhgKVQosIfRsPSOlcUPAZiVTNqbGHuwrXIxHmcHCrTMDDWTVfwOrDdloJSRtvTVRuHHLZqeOHAJHfUnFgyNShHSmXWFmhTyFlWvgZxTzLsRtRSFXgWhUbkANeibTZsVvEyBuObiJAdEDWnhWXJCLGsJzbpHhblJdKHmPxMKduDmRzERdEtoxFzeuLEaEMDQYLqqYar");
    double AQhCLELk = -1042290.4585974388;

    for (int bxZDyrIoCBbGMeO = 1782481220; bxZDyrIoCBbGMeO > 0; bxZDyrIoCBbGMeO--) {
        ObfQSQZXEI += AQhCLELk;
    }

    return false;
}

int UiJNBuRtK::dwLKgHBXzyjnUoT(bool EiYHAcyNJ, int ySizywzLDN, int oGiOySYAkZeKXxZ, bool BXMPbhFxLg, double dzSmLeUdLp)
{
    string TlnbRzT = string("vfgxEcusLYKcHvlHdEGzhIkEykBOeGDdBvfdXDfhnFqajHXsTssaDaEBjNUCVeQjImpWurNRusYrWhpmukMdJXxDDoEQqqBPjYiekDbOcGXpzkEwCMqDGnNGmXZMlSFECkFrykTQgJJdDpgh");
    int NdxMakea = 821503767;
    bool QdDPSZKOXEtd = false;
    bool foMwwGusgGTvp = true;

    for (int HMcfIVMsIbdadzDR = 252948682; HMcfIVMsIbdadzDR > 0; HMcfIVMsIbdadzDR--) {
        continue;
    }

    for (int NJBAiJ = 860381099; NJBAiJ > 0; NJBAiJ--) {
        QdDPSZKOXEtd = BXMPbhFxLg;
    }

    for (int SSNRUS = 309209074; SSNRUS > 0; SSNRUS--) {
        oGiOySYAkZeKXxZ += ySizywzLDN;
        ySizywzLDN /= ySizywzLDN;
    }

    if (BXMPbhFxLg != false) {
        for (int HomaRVzBzoWxK = 1008411109; HomaRVzBzoWxK > 0; HomaRVzBzoWxK--) {
            continue;
        }
    }

    for (int gQhgfPgRvlvStBY = 1643722177; gQhgfPgRvlvStBY > 0; gQhgfPgRvlvStBY--) {
        NdxMakea += NdxMakea;
        TlnbRzT += TlnbRzT;
        EiYHAcyNJ = EiYHAcyNJ;
    }

    for (int JkmXpDGM = 1166136953; JkmXpDGM > 0; JkmXpDGM--) {
        foMwwGusgGTvp = foMwwGusgGTvp;
    }

    return NdxMakea;
}

string UiJNBuRtK::ZCGcs(bool ObfhrEVJzsKbgZi)
{
    string pdEhMsEPZATxA = string("tDPzyqGSgljJHWTPhAbhrvUjruKWSzKwks");
    int bMSiwJ = -650225086;
    double FcKUGP = 310114.65428408014;
    int UMYjdll = -1018263275;

    for (int xQWTYndlXGo = 644931020; xQWTYndlXGo > 0; xQWTYndlXGo--) {
        bMSiwJ -= UMYjdll;
        pdEhMsEPZATxA = pdEhMsEPZATxA;
        UMYjdll -= bMSiwJ;
        UMYjdll /= UMYjdll;
        pdEhMsEPZATxA += pdEhMsEPZATxA;
        pdEhMsEPZATxA = pdEhMsEPZATxA;
    }

    for (int ocBxJQDqM = 1934382588; ocBxJQDqM > 0; ocBxJQDqM--) {
        bMSiwJ = bMSiwJ;
        bMSiwJ -= UMYjdll;
    }

    return pdEhMsEPZATxA;
}

void UiJNBuRtK::ALTIGw(bool HhqkpckpfGQh)
{
    double MDINOSZXtYdDjBG = 377333.3403333667;
    bool zepPnqc = false;
    bool iFvTbqovk = false;
    bool rcYri = false;
    string BngcMXarr = string("YcUBRCcdLbCZFHxkDbeheQdmAWUNpuBNdsqEEurvTtKhebKOTzjdYZfQnf");
    int rYTsMxxJyAFw = -715242882;
    int xsBCFWYwRA = 908254109;
    int zMMzC = -780851237;

    if (iFvTbqovk != false) {
        for (int nLjQgxfDxUfqSo = 1796840562; nLjQgxfDxUfqSo > 0; nLjQgxfDxUfqSo--) {
            BngcMXarr = BngcMXarr;
        }
    }

    if (BngcMXarr > string("YcUBRCcdLbCZFHxkDbeheQdmAWUNpuBNdsqEEurvTtKhebKOTzjdYZfQnf")) {
        for (int XckvakCnIOKAq = 678154981; XckvakCnIOKAq > 0; XckvakCnIOKAq--) {
            continue;
        }
    }

    if (rYTsMxxJyAFw > 908254109) {
        for (int yuquxQTFbCMB = 911319717; yuquxQTFbCMB > 0; yuquxQTFbCMB--) {
            iFvTbqovk = ! iFvTbqovk;
            rYTsMxxJyAFw -= zMMzC;
            rcYri = ! iFvTbqovk;
            HhqkpckpfGQh = iFvTbqovk;
        }
    }

    for (int ujlQTDymtIFfqLT = 2086578118; ujlQTDymtIFfqLT > 0; ujlQTDymtIFfqLT--) {
        zepPnqc = iFvTbqovk;
        zMMzC /= rYTsMxxJyAFw;
    }

    for (int HSYkrL = 1214495817; HSYkrL > 0; HSYkrL--) {
        rYTsMxxJyAFw -= zMMzC;
        rYTsMxxJyAFw += zMMzC;
        BngcMXarr += BngcMXarr;
    }
}

int UiJNBuRtK::tcZhIJS(bool kyuoy, bool uUzBbKACpHGlxC, bool zToAxasIEeUbYI, double NislJnjrAQS)
{
    int HutnEs = -607078666;
    string CclisHnLPIAAN = string("tEnSitWSIIsAXgbSeXpMRRvKsSGVkiGIfRwOSXTuRTjeQgDfwEyVoonGGiGsjQB");
    double TcZulTlhb = 653951.4079335826;
    double KITPpooJdBkJ = 229706.92903511418;
    bool gWUUug = true;
    double aLaeysMxs = -291174.90580133954;
    string BoFrwIMO = string("HBcCiyhErglTmyNYXbxVQkBQRVlaYKmvCGkWYCpksdfbYMkIZoFhSsPEGlBKekpQUivepaBjLOzOaNPzeQWvpvwRlzxOTLfvZwaACucDkLBB");
    int zyMeuUenldEgcrP = -1851276112;
    string ZRFwlRSKtk = string("xmNTpOSalxXkopdvposzJfbuHollRXpWRNROztDsgXxucFfSylLoajAvRfXteJwnNBSiTNslMuIWbOIKRLijHrnmKCPByhzrpBSRITAVMhEtyrUKCNZFjAxGWQUDCTexBhvFucLpsiBLKHSMbhDVetPjtOILtaWATFGbIuHwyiPCdssVLIifrKfLETICbHsCyAyJTzhGwIjSrOHEgOYVHTjaFXdtEhj");

    for (int SjoOMPiPBT = 1461825412; SjoOMPiPBT > 0; SjoOMPiPBT--) {
        ZRFwlRSKtk = ZRFwlRSKtk;
    }

    return zyMeuUenldEgcrP;
}

void UiJNBuRtK::ZUCiRfWFpa(bool KFaWWnYcgJ, int rQYNuAAYFcm, string izQycqSffx)
{
    string lRgYD = string("gHnotZxgRVtYEYsOfxMunEbHFsvYUKMaDoGISOHihZyjaTGxjYDRzmSneiDDjOLYwrmMaHixACErISkYVsvoZPvoAVTKuQebkMBLyUlkbtCwVdRyQvcxCTUSoOyfUlvGJVGizXXAYigkxPEWjQyfwEuhbzhwfBLDQJCFQxrmxotueBrBcCTVfIGmzhQIIDdFQMWnJMHqTfzs");
    int utptBxC = -1031566016;
    int zKlvFhyQgEvC = -913818033;
    bool MjiEVHg = true;
    double EXmeywxBAdtXZR = -200829.27306538986;
    bool tipCfMB = false;
    double dReFHDXmiZryQM = 1042862.3754338541;
    string QlQQdpT = string("JnFpHLJBfcGjvtykUjGhxDsfoduvBAovPhBmLErrcOMZcXetrrfHufmRSQZhIUiSfxxNZySZmCahTTjMsLHpDRAMjFkTkALMzc");
    double mKVvZy = 199124.43767780706;

    for (int uvADAVnRFY = 258574126; uvADAVnRFY > 0; uvADAVnRFY--) {
        mKVvZy *= mKVvZy;
    }

    for (int yzBtDsRjc = 774817895; yzBtDsRjc > 0; yzBtDsRjc--) {
        continue;
    }

    for (int EycbMrD = 594101352; EycbMrD > 0; EycbMrD--) {
        continue;
    }

    for (int DbzVOMBQ = 1453522547; DbzVOMBQ > 0; DbzVOMBQ--) {
        continue;
    }

    for (int YgjlLsQHZLpWumU = 1831615679; YgjlLsQHZLpWumU > 0; YgjlLsQHZLpWumU--) {
        utptBxC = zKlvFhyQgEvC;
    }
}

UiJNBuRtK::UiJNBuRtK()
{
    this->JuquJzu(-712704060, false, -1930012923, -28394012, 802229361);
    this->lfQdhCbLZhHewbSK(947519.4683363328, 109575556);
    this->dwLKgHBXzyjnUoT(false, 2018274213, -1180998881, false, 963774.5446500097);
    this->ZCGcs(false);
    this->ALTIGw(true);
    this->tcZhIJS(true, false, true, -821997.7885002396);
    this->ZUCiRfWFpa(false, -1197665196, string("hxHMOODiQNiciHJiMaauJYJMcYtNvAwrpkoAnwqbSbljfSZMyWfwkBKWdRTHULCXRFuqtCYedjYUrKnCulYUwrvasLlMQoOTvaJiJhxUrSmmdfgUvgiqIfeBtBBVvWpRiVmbtlDfAwqkPeJzaHaxIpeMwzhwgACmMUouBxzPADccAtASPLbWnplKKHqfQgRpnOlQqzUIztRcIPRCDtJQCEJtBIqnXidTMYeyIBevvipCkpVd"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xMnmRfQkZmLm
{
public:
    bool YNHEF;
    double YBtwNdqCxBujoq;
    double BsLeTBmIfpZTPWs;

    xMnmRfQkZmLm();
protected:
    double MsTNTdWerIuBu;
    bool zLnDNhvllwjssyXK;
    bool tGlkOoUINfuTl;
    double zUYmt;

    int vwoVEtxCOVhznh(double xoxgEiFBJNxVlP, double jzwJe, int sjPyfoDbafStaoKK, int YUzksNtjXnVW);
    void AOEqdP();
    string nKnQqXXwZezs(string ZQhhfetagOTUh);
    int QjrWQEXrQYp(int UpqAo, int hiznlQIwwdLoZx, int APMfNqSlBo, double kwxIRiqFdrhIK);
    string pxvaKWTLw(double XLBCDnAcFjdol, bool xhPwYg, int IkgfsIeFmNVGrg);
    string IyayNpnHjWoVGHIT(bool PBFmFl, bool WLxijFeQsGlqeEo, double cEldlZ);
private:
    string jkeBEAVIexxzhXb;
    bool JXXsiFoqBdnStd;
    string XzAHXIcpYIiDKEne;

    string DdeMUZmjMVGtWH(string EjwWr, double okFFbpLUQwEN, int GOdvYxl);
    void QaSNstFlAgH(int YYeqJivxUhQRyhcF, string xppiYo, bool dCCyCGEmYPdPv, bool akjwCeMDQDt, int vrHqR);
};

int xMnmRfQkZmLm::vwoVEtxCOVhznh(double xoxgEiFBJNxVlP, double jzwJe, int sjPyfoDbafStaoKK, int YUzksNtjXnVW)
{
    string GWxddVhympAp = string("ZkpFRUAcxgaKKvjZuLibRSvfGXNlVZhkpBDhwwoSqUFoWRKqqqkIUvJPSaCfGvYUWSkEMXFPNWvyLMZe");
    bool xcmzYxLxFvm = true;
    string aXWoQx = string("jWzcvCVyCNXLeafdGppMGMQxbfoUkOEMkAkUyqMywCtDsuNrHkdRQiqJkmjKXtMkaHAxyBZbodEOKbmpsmaPzfqsSkgDQfcGfGQdyMAFyxNEXpFia");

    if (xcmzYxLxFvm != true) {
        for (int TSzNYvxays = 1810581370; TSzNYvxays > 0; TSzNYvxays--) {
            sjPyfoDbafStaoKK *= sjPyfoDbafStaoKK;
        }
    }

    if (jzwJe >= 1044794.5910913467) {
        for (int WQhdapwGWT = 1838441474; WQhdapwGWT > 0; WQhdapwGWT--) {
            xoxgEiFBJNxVlP = xoxgEiFBJNxVlP;
            jzwJe /= xoxgEiFBJNxVlP;
            xcmzYxLxFvm = xcmzYxLxFvm;
        }
    }

    for (int DdBVVOzUjwwyOixR = 646560764; DdBVVOzUjwwyOixR > 0; DdBVVOzUjwwyOixR--) {
        YUzksNtjXnVW += YUzksNtjXnVW;
        YUzksNtjXnVW /= sjPyfoDbafStaoKK;
        xoxgEiFBJNxVlP /= xoxgEiFBJNxVlP;
        xcmzYxLxFvm = xcmzYxLxFvm;
    }

    for (int mLPhXDGg = 171242737; mLPhXDGg > 0; mLPhXDGg--) {
        GWxddVhympAp += aXWoQx;
        sjPyfoDbafStaoKK = sjPyfoDbafStaoKK;
        aXWoQx += aXWoQx;
    }

    return YUzksNtjXnVW;
}

void xMnmRfQkZmLm::AOEqdP()
{
    bool PKvLqXryNoaNDbh = true;
    double xiXTxVcfXR = 47710.58135698687;
    bool czlGWBrjhjL = true;
    int boreJAiK = -1446710945;
}

string xMnmRfQkZmLm::nKnQqXXwZezs(string ZQhhfetagOTUh)
{
    double pVVUHdliIINoi = -390057.075391141;
    string InLiPykswyjhN = string("PZIfCzcSqhycpILAniLnCmqaiwefMqRbTZNVzQXvgagythbCDtCTCUNnlXAbszgKqVXsVEfxtEtFqCLBaIBKgOYhjiOXpbreeyuTsFVpofmzVJblMjymXEuZtXKxepZZZcpDKWQXXBtcAZmjuEvhSeUKiLRkubQAeeeZXnDwNIkbSnMcPTdZqDChYPGXSEVemeNTAYKFPCJXZBHiwbZgIUSxNDeZdtBubGypiTEKS");
    bool fpSNU = false;
    bool XsfGliEVsWQm = true;
    string gzHFTs = string("jrSzjcerksyUiCSXulJqzTjfPXshQkOcwaJcBobLtaprwmNzmzvTrrwnLREKvLcjaiIsHmLBpzVPKzdhkUHzkBproRHUYLggCgBrakMzkDaPjUxWkCESLQAfgrMjrnzxpbMmnRwCTZPCbiMDdxpQNHQhxPSgUuYkTfhjfIalqbmfYUMAsURYLvgVEzBIDPxVLyxRZPOsUNh");
    int LmrixGc = 1695786009;
    int pCsSIxrtrlZeEqVr = -1970066491;

    if (XsfGliEVsWQm != true) {
        for (int ZpUcJAxqaqxsmCYr = 1082206998; ZpUcJAxqaqxsmCYr > 0; ZpUcJAxqaqxsmCYr--) {
            LmrixGc -= LmrixGc;
            ZQhhfetagOTUh = InLiPykswyjhN;
            gzHFTs += InLiPykswyjhN;
        }
    }

    return gzHFTs;
}

int xMnmRfQkZmLm::QjrWQEXrQYp(int UpqAo, int hiznlQIwwdLoZx, int APMfNqSlBo, double kwxIRiqFdrhIK)
{
    double DvveBY = 12962.058632507005;
    double sgVxZ = -170716.10572507305;
    bool FmyWWUMLtKnJoaDX = true;

    if (DvveBY >= -193117.6011405561) {
        for (int auyzDLc = 160130762; auyzDLc > 0; auyzDLc--) {
            kwxIRiqFdrhIK += DvveBY;
        }
    }

    return APMfNqSlBo;
}

string xMnmRfQkZmLm::pxvaKWTLw(double XLBCDnAcFjdol, bool xhPwYg, int IkgfsIeFmNVGrg)
{
    string FguPg = string("sLAaORXWRSKmfhehhHSUWZdgpVTKvXidrPseuXVPlKRYkGPpRPfLjsTouMNCukIjSyVHUdBphZhOkZfraFvmWfxNnSBYRJqiGuNtfzTOaKYAdbHDjLJWdGvMRzhmbDbwGJjZasESocrfoCVlkHLnfrlTxGXREIAdQOqpFdigvEQNgKPOyjddlgiArMbNoShsCJFzTNoKshOGWAyNaNtKezVxzjutVwhWppbWwiTowUrxftEKA");

    if (FguPg == string("sLAaORXWRSKmfhehhHSUWZdgpVTKvXidrPseuXVPlKRYkGPpRPfLjsTouMNCukIjSyVHUdBphZhOkZfraFvmWfxNnSBYRJqiGuNtfzTOaKYAdbHDjLJWdGvMRzhmbDbwGJjZasESocrfoCVlkHLnfrlTxGXREIAdQOqpFdigvEQNgKPOyjddlgiArMbNoShsCJFzTNoKshOGWAyNaNtKezVxzjutVwhWppbWwiTowUrxftEKA")) {
        for (int vCuWTRnhYm = 50635618; vCuWTRnhYm > 0; vCuWTRnhYm--) {
            continue;
        }
    }

    for (int VWuDVLHUKnJCH = 265347021; VWuDVLHUKnJCH > 0; VWuDVLHUKnJCH--) {
        FguPg += FguPg;
        FguPg = FguPg;
    }

    return FguPg;
}

string xMnmRfQkZmLm::IyayNpnHjWoVGHIT(bool PBFmFl, bool WLxijFeQsGlqeEo, double cEldlZ)
{
    int RHJlJSd = 1469670105;
    bool zAXaJuehwUZV = true;
    double NxMJxFHglRcYb = 1040355.3420582322;
    string bqeQJXuiOTV = string("EAuAWOdcSeggSanivTEysVUrVlVWydATskpDCrKnbPLFvsVFNuMBnlptYcylvAAhRjiaLVDUhdZNCZwUGKEHDAFvltvkOykqiMACimTWqFZbIztySPPOkhxmQFYUniAxzVbnoctRPxgjulfdosmZUJMCRNHxjchkhRnGBZDVNbnzLqTiktQsQOTFHWaJTEdCLJeIPWleoqkArwdzHBcRHwY");
    int BaFXbPZBFHcJ = 894824955;
    double VqkXRnL = -178214.82566276618;
    bool pqzHuvZV = false;
    bool XlzYxJQyZn = true;

    return bqeQJXuiOTV;
}

string xMnmRfQkZmLm::DdeMUZmjMVGtWH(string EjwWr, double okFFbpLUQwEN, int GOdvYxl)
{
    double RqCXhGlvDPBtOH = 557835.8606213641;
    int WCZWvsiB = -1389947601;

    if (EjwWr > string("BlmYJLlewiASwMnI")) {
        for (int aSPNYxSbzY = 1371673684; aSPNYxSbzY > 0; aSPNYxSbzY--) {
            WCZWvsiB += GOdvYxl;
        }
    }

    if (WCZWvsiB <= -1327017968) {
        for (int fAoBAvvXl = 1658498571; fAoBAvvXl > 0; fAoBAvvXl--) {
            okFFbpLUQwEN /= RqCXhGlvDPBtOH;
        }
    }

    return EjwWr;
}

void xMnmRfQkZmLm::QaSNstFlAgH(int YYeqJivxUhQRyhcF, string xppiYo, bool dCCyCGEmYPdPv, bool akjwCeMDQDt, int vrHqR)
{
    bool hYjziMRtDouICkz = true;
    int eNqmCtfDnTObL = -613006003;
    int HbjWdPpEf = -350533164;
    string nuKxDZaSzZweK = string("PBygbCNkcbGtUsAOEbPOWSOzamDOOuOrBRnjbmjvCrIAKVQcFrASeAtbBzZdYxvxWfXWgHQViimDkLayjEKYfTWKQjZkxeCVifyiXtTnaHUoxGXSjGfeHZIDEOQLhuNHSaHwrfwAFTzmkrmvLqyRbBiAGGFzKBMweeWrCCwoeORbWhqRoUMKXIxQKrIrQxlTxYuvQwzwvGClsSngdJTJbzbFdWjggrzpHPcopZnIJW");
    int sPYRzmvQGrrRB = -593676305;
    bool LPospREPdLHuHk = true;
    bool QKbBXUEZfbIp = true;
    double EefiYGaywyqJwO = -337365.71377141104;

    for (int LZBwcyDQMEn = 2071366703; LZBwcyDQMEn > 0; LZBwcyDQMEn--) {
        sPYRzmvQGrrRB /= sPYRzmvQGrrRB;
        vrHqR += sPYRzmvQGrrRB;
    }

    for (int XisaRHKtzqZo = 911679871; XisaRHKtzqZo > 0; XisaRHKtzqZo--) {
        continue;
    }
}

xMnmRfQkZmLm::xMnmRfQkZmLm()
{
    this->vwoVEtxCOVhznh(497203.9236667808, 1044794.5910913467, 671213552, -120459349);
    this->AOEqdP();
    this->nKnQqXXwZezs(string("HIhLhxXTZBirYelvLnbrJrzkPXPBvfWBPtVnPyqYNYYqBbtRkiGuNhBJseUEyiYBAOXeSuPPPCqobymVNbUzekLYqePDTUBBFGNZyKbZBayuPmrjyWoJcMDwQQrjPzqMRUKJvWODqnydaoiMCbmRVjKpgyplllcrvDLkGPwKyJyfDRhkMbQHeVYlnwkzthqysjVBDfMJxIrmKiEtrARnudZKogzcEPsxwlOkuEjGimttTSVVREdYUAgGSM"));
    this->QjrWQEXrQYp(318185294, 1391619337, 2131178783, -193117.6011405561);
    this->pxvaKWTLw(380701.5830550309, true, -1696974372);
    this->IyayNpnHjWoVGHIT(false, true, 938326.7713165627);
    this->DdeMUZmjMVGtWH(string("BlmYJLlewiASwMnI"), -608953.0101880855, -1327017968);
    this->QaSNstFlAgH(280002113, string("sYnDblaYZwLNTGPAFINHRzrVUNxnhyQFYyQUnvvruwGIbmlXxtrwPLHeyMHJfVAmYExNmFdZNnzgZtlygyZFELRwCFdvknGTlBRqCtbYmomPioCMXGDUXMqQBnFpJbfVSwwkYUvnqEaNAVCMuMsBfRyCf"), false, false, 1960526577);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PDUnm
{
public:
    bool RcRLTIMUF;
    int ctfbLxdwNfoQnBK;
    double OxyLZBpXV;
    string WWezBLugUjGTxAP;
    bool SgOPfZwHqWdAIUld;
    int whZkizKcjMY;

    PDUnm();
    int FZcFmpCTK(bool WuFlwjxCZbG, bool VjMiSsrAtHX, double ZZcbPyKJxxaJpcBC);
    string LJUBqStIkbrVv(double QewILNX, string VyPBSLcAYPaFvgL, string fGjAkiaSIp, double VgBCAUaAobtBqiW, int IBMtxWsq);
protected:
    int HDcacyNTVmhEidUg;
    int ttMFaBVbOWR;
    string xyBiVWKGFgkfOYgY;
    bool BnTXgqRq;
    string OpPYgD;

    string FpgRLqre(string aSumKyr);
    string LozqjAXsDCDULfFZ(int MhQNKpta, double acEyyTSrQ);
    double KKdKAFnl(int RzGydMmRjXigm, string SzYZXUNzwzB, bool pyKoodyVRUnWU);
    string SUsOhbowC(bool mGjVrDBC, string PeIaxqwpgvPOcOv, string DLnNNfqNnjY, double SbyscpEZDKJkWKmC);
    double wwGkrILayATGJPHM();
    double ZphMkBO(bool RwfgneO, double MffdzELTrmib, bool WpSTuO, bool IuExliizrfGBjNy);
    bool plfHCWQsGeL();
private:
    string ZMHlKiq;
    double hVNICIOTVjeS;
    int AFbzKwSuX;
    string YVQWNUnX;
    int LWamA;

    void MJNbslJeERSZb(bool TXajCiAfqt, double rcSsGaXhFtQf, bool AhUFENDV, string QIlWMpWgVMTCgB);
    bool vDozCSiGuvTt(double srbRANIEDKJO, int dDoDtTffrnCQ, double SJITFdgVf, string sfkzloggJrrpMVB, int lNnPRelQN);
    void qbugpxmU(double YRaXe, bool DVEloqVsnPKckow, int AohuLADNxMQJL);
    double sCrHCcgkGTLn(bool kDFHVUCJEJDxm, double qmqFQXG, double qNqJInERRYLVx, bool UkSTGZ, string dNqLjxMci);
};

int PDUnm::FZcFmpCTK(bool WuFlwjxCZbG, bool VjMiSsrAtHX, double ZZcbPyKJxxaJpcBC)
{
    int xmxWK = -665489631;
    int KzEaqInYXV = 1633677781;
    int ECkZxMP = 1255649418;
    double ZgdrHacNldF = 566828.7885513316;
    bool DQMysEw = true;
    bool pbcjdqkzEyOnUyHI = true;
    int Pumkn = -1354743848;
    bool NpiwAMwoGKOoWsUQ = false;
    bool fFqELqtDLtPoja = true;
    bool EpSVwUyZZx = true;

    if (NpiwAMwoGKOoWsUQ == true) {
        for (int icWHQYexS = 976294361; icWHQYexS > 0; icWHQYexS--) {
            DQMysEw = ! DQMysEw;
            EpSVwUyZZx = fFqELqtDLtPoja;
        }
    }

    if (xmxWK <= -1354743848) {
        for (int lTJmsummdpoBEnAx = 359667042; lTJmsummdpoBEnAx > 0; lTJmsummdpoBEnAx--) {
            continue;
        }
    }

    for (int MpGhppvQ = 925667077; MpGhppvQ > 0; MpGhppvQ--) {
        EpSVwUyZZx = ! EpSVwUyZZx;
        VjMiSsrAtHX = ! pbcjdqkzEyOnUyHI;
        VjMiSsrAtHX = WuFlwjxCZbG;
        NpiwAMwoGKOoWsUQ = DQMysEw;
    }

    if (fFqELqtDLtPoja != true) {
        for (int egYrbPrg = 676619524; egYrbPrg > 0; egYrbPrg--) {
            pbcjdqkzEyOnUyHI = DQMysEw;
            VjMiSsrAtHX = ! DQMysEw;
            xmxWK = KzEaqInYXV;
        }
    }

    if (DQMysEw == false) {
        for (int eGjcSzLbutgrU = 538391649; eGjcSzLbutgrU > 0; eGjcSzLbutgrU--) {
            continue;
        }
    }

    return Pumkn;
}

string PDUnm::LJUBqStIkbrVv(double QewILNX, string VyPBSLcAYPaFvgL, string fGjAkiaSIp, double VgBCAUaAobtBqiW, int IBMtxWsq)
{
    bool gJrNvyRLfnMtB = false;
    string Hzcwu = string("GfeUjBTnZWzQnxHXUIsqdRysDHUOZxKPHgjPUoWDrJobiPgqUdFVOxigRlBiRnCvwJvBsRykFUGINLcLbdVvPUhvSzklaCBYuLFBTDLdihQVCYByJPbAoajnAMSJUAOOMHhCDEENHvIFdzqrvXQOvPfrYMcTBFEKkHPaBBXyAetNlODEADqBKkKQNyXHqDLQvughNkyOCsMXLgfwzIfcaRNTjXxKSrTzIoQadfQaZiT");
    int zxQIR = -458301063;
    bool lTUXZpAIbrUp = false;
    int KakRdZ = -1672808899;
    string qfegKPwWSr = string("WJBpBQTCFaBqTZskTFiojLAnOcDuAliAgqxQQNLsHtTTnEtLKosGwdXGanCpDPLVZfsTwkSimOxpaHbADndkCQutmpClGKUoBjiPCFDiFJpAhlifaSSsxdNckBoBOJfYGwRQwLEbMwCtzFIYAqSzVNfQLQgcqVcihNfWRsAOrCnIcbJuCLbCSTUZLekNuphLFYxkglkayBJQdWKanWGgNjtJhineLRuxsFRIALrmrekyPMz");
    int YEXHvXEMTbPPDrdV = -1154049384;
    int TTLBZoSHUOo = -211948540;
    bool OHncQDIRgSEWgZ = true;

    for (int YYqIFSr = 1248006375; YYqIFSr > 0; YYqIFSr--) {
        KakRdZ -= IBMtxWsq;
        IBMtxWsq = TTLBZoSHUOo;
        zxQIR -= TTLBZoSHUOo;
        IBMtxWsq += KakRdZ;
        KakRdZ = zxQIR;
    }

    for (int PHiJYM = 777167245; PHiJYM > 0; PHiJYM--) {
        QewILNX /= QewILNX;
        TTLBZoSHUOo /= YEXHvXEMTbPPDrdV;
        Hzcwu = Hzcwu;
    }

    return qfegKPwWSr;
}

string PDUnm::FpgRLqre(string aSumKyr)
{
    string hlaTEHyZNwwA = string("OhRCzSVVyeVBdyQmYIlUidhIpXgvXetCMcBIIJdqEDYLEheEQxJPzDVpMjZuTKLJaMFvnoBsSKVKNrqZKOMFQvLdtpgUQCaRUxveexzsCqmSeQKbXLyVZTksnRXsnouYOEcKZPIiCYJohwRarARQYzscQVUEXEVatPxlqXBLHUKhNngrcNfXvuusyurrcjBcmUVtvyKHWIqrvMoczgFbGpNDnGXPHW");
    string InXwHLaK = string("UHnoyedsWWWgCtZDcivKDpCNkVrfoBiEzqLCJLPbNYBIkysRjwjRcxfesLUdFVpLcxhdrHeKASrfOQIwPJejKlWMtlLjrhTxHoJTsGekEWtqXnEhMWipmHpqHpaVidKPsOEufAmyMAVIVBoCmhlwMmHFtiUGJwiricVPaFpwWgXQWhSiNGTXBHNyGTdDMutoXNSpJDJOjrhkfYjyHhxqFDhUdMYwZDQFNdlCUSzLgHbPGIZfGKwHFG");
    string AhCmWFNrfASfLEvB = string("tRSbDGCNfWyUFFyRj");
    double MqjcUz = -369841.4930559384;
    double jZbWKQxlpTzhOgm = 137093.92251064946;
    int OrFcHkjZOUmMaKpa = -1793418659;
    int WrurvdzvV = -1130090251;

    for (int iMndVcIV = 1728458893; iMndVcIV > 0; iMndVcIV--) {
        OrFcHkjZOUmMaKpa /= WrurvdzvV;
    }

    if (hlaTEHyZNwwA == string("tRSbDGCNfWyUFFyRj")) {
        for (int xPLYo = 56982609; xPLYo > 0; xPLYo--) {
            continue;
        }
    }

    if (hlaTEHyZNwwA != string("UHnoyedsWWWgCtZDcivKDpCNkVrfoBiEzqLCJLPbNYBIkysRjwjRcxfesLUdFVpLcxhdrHeKASrfOQIwPJejKlWMtlLjrhTxHoJTsGekEWtqXnEhMWipmHpqHpaVidKPsOEufAmyMAVIVBoCmhlwMmHFtiUGJwiricVPaFpwWgXQWhSiNGTXBHNyGTdDMutoXNSpJDJOjrhkfYjyHhxqFDhUdMYwZDQFNdlCUSzLgHbPGIZfGKwHFG")) {
        for (int OSZZvsFwD = 180192974; OSZZvsFwD > 0; OSZZvsFwD--) {
            jZbWKQxlpTzhOgm += MqjcUz;
        }
    }

    return AhCmWFNrfASfLEvB;
}

string PDUnm::LozqjAXsDCDULfFZ(int MhQNKpta, double acEyyTSrQ)
{
    string vOJAtpfKI = string("sLglsgTFFbgDETpovzfRLs");
    bool NcFjmy = true;
    string GbMbhTKHxJxz = string("DSxUODMQUEwGZFjzaVKiytShPAChKakyEgQmdkbOKNfNPresKsxdjfVyBxNmUQrkAEXtqTJteiQppLKhlzgIeWtjReTiTxhdstSqiIrVVZDctDrLNwniEzwywszifsmbdoeFaMSRypOMuMRUTbEvjorEalxcLvjAKnVtxJufQjoqkAcNjXnqnNvuNEpkcJxhGbmiTCOZFVIVryXiwwyFdQpPqsCUAAtBJVuWKBCkhDFojvtCtIQDoevuj");
    bool GOrYoCggIwE = false;
    double PkcWPI = -578135.7150466084;
    string lRWYskgYkNKCsF = string("oMSLzzBgyDnaYPkIsjzWDGmUklODEkpXnxDDvxosNJaBPj");
    int UmSoxWmPbbsALq = -995916575;

    for (int xGBQfAPSmPp = 708382349; xGBQfAPSmPp > 0; xGBQfAPSmPp--) {
        PkcWPI += acEyyTSrQ;
    }

    for (int XQHmzcmEXqtLDi = 2073523257; XQHmzcmEXqtLDi > 0; XQHmzcmEXqtLDi--) {
        NcFjmy = GOrYoCggIwE;
    }

    if (MhQNKpta <= -995916575) {
        for (int lJCsZC = 706843404; lJCsZC > 0; lJCsZC--) {
            GOrYoCggIwE = NcFjmy;
            GbMbhTKHxJxz = GbMbhTKHxJxz;
            NcFjmy = ! GOrYoCggIwE;
        }
    }

    for (int rahlkljWvPnl = 1697585241; rahlkljWvPnl > 0; rahlkljWvPnl--) {
        NcFjmy = NcFjmy;
    }

    return lRWYskgYkNKCsF;
}

double PDUnm::KKdKAFnl(int RzGydMmRjXigm, string SzYZXUNzwzB, bool pyKoodyVRUnWU)
{
    string rdfjxU = string("vniyereEx");
    int wBJBCkOvwfv = 1793660603;
    int oVWJNlzEUZgy = 1977255379;
    string LXMLMOsB = string("bAtYkwEVRzMYmezFjkYjauDEwQyzGlWFTHVBcmcCxrINsKjDJeFLmtbwzthRkrZiUuQLzyvBsLmdrnHsuncgiXXCE");
    bool PrfUZPifxMnPLxs = true;
    double YFTBGKU = 893930.1342272803;

    for (int AlkDyQ = 986903040; AlkDyQ > 0; AlkDyQ--) {
        continue;
    }

    for (int AtwGrcv = 2095266394; AtwGrcv > 0; AtwGrcv--) {
        SzYZXUNzwzB += LXMLMOsB;
        RzGydMmRjXigm /= RzGydMmRjXigm;
        rdfjxU += rdfjxU;
    }

    if (wBJBCkOvwfv == 1977255379) {
        for (int yDPQu = 133743686; yDPQu > 0; yDPQu--) {
            SzYZXUNzwzB = rdfjxU;
            wBJBCkOvwfv /= oVWJNlzEUZgy;
        }
    }

    for (int LzlsFNvgnJcWcAl = 1155482565; LzlsFNvgnJcWcAl > 0; LzlsFNvgnJcWcAl--) {
        SzYZXUNzwzB = rdfjxU;
    }

    return YFTBGKU;
}

string PDUnm::SUsOhbowC(bool mGjVrDBC, string PeIaxqwpgvPOcOv, string DLnNNfqNnjY, double SbyscpEZDKJkWKmC)
{
    string KnUlicG = string("NQsENoIMWpDMCmeICYHBqlslNHSDTWfJKkaHEUHkYykzDwwDDEQpKTtSOLuwiwXemqGEyyTEiJLTgaZFPYfoCVoZcYyTjnSXQojYGnJCQQQZxFsSmLCbJIQLqBjIgCnSzMwpAfhKLvPutGzrFiybwArOiJjVWyPSNqNocJejfLuG");
    double HOeIRzUpMzXEM = -931703.3493832778;
    string skBhe = string("VcOfULEzCelQIJJCmgKoVSvIJaJWFZqgARUeiMHJNhwiLjxumjgckvMYVb");

    for (int KKGleyLfkRkXIS = 1278699129; KKGleyLfkRkXIS > 0; KKGleyLfkRkXIS--) {
        PeIaxqwpgvPOcOv = KnUlicG;
    }

    for (int DIOrjkimKJRNb = 749743211; DIOrjkimKJRNb > 0; DIOrjkimKJRNb--) {
        HOeIRzUpMzXEM /= SbyscpEZDKJkWKmC;
        KnUlicG += PeIaxqwpgvPOcOv;
        HOeIRzUpMzXEM /= HOeIRzUpMzXEM;
        skBhe = DLnNNfqNnjY;
    }

    return skBhe;
}

double PDUnm::wwGkrILayATGJPHM()
{
    bool VXeAyGdL = false;
    int TbShqsb = -545126356;
    string pMugSddM = string("imRgAMmuZejriKuRdCVKCtHRwvbTeTaXLYbYLxIcsBLddkXbGgcJeGPEZwjVLsCUhgHIPvEKIKFjdZUABLJOXvCFIMaPjZAKVjlrOIeCCcYcOp");
    int XHvoslbRwitGs = 894149408;
    double dlmaKxtDYGS = -3363.240216428853;

    for (int nfPCmpqqRDblVY = 1367760039; nfPCmpqqRDblVY > 0; nfPCmpqqRDblVY--) {
        TbShqsb -= TbShqsb;
        VXeAyGdL = VXeAyGdL;
        pMugSddM += pMugSddM;
    }

    for (int BkGLD = 591657148; BkGLD > 0; BkGLD--) {
        XHvoslbRwitGs = TbShqsb;
    }

    if (dlmaKxtDYGS != -3363.240216428853) {
        for (int ddfMQr = 1348423327; ddfMQr > 0; ddfMQr--) {
            XHvoslbRwitGs = XHvoslbRwitGs;
            pMugSddM = pMugSddM;
            TbShqsb /= XHvoslbRwitGs;
        }
    }

    return dlmaKxtDYGS;
}

double PDUnm::ZphMkBO(bool RwfgneO, double MffdzELTrmib, bool WpSTuO, bool IuExliizrfGBjNy)
{
    bool dznlBnsAVsXsIck = true;
    double IrMHsjjExi = 892369.9081460617;
    string OEHTupAaC = string("HhFYhWYFTqgddRldbXlTgyEVsNXwOrStVUBmDvJLCoazDAhDZygHyFEVTxDzOPpubcooIJUJtC");
    double lzmMsBHCQnHnNHA = 434808.67035630177;
    double sxZfxEkFsaxHpdQG = 112176.63840912675;
    int wdzfwvgH = -2053161387;
    string wMSlCrYxGOXoJpx = string("EKbDzAvsGyFarUtqbiCAAMLcmfmIbhskPGhLEwDxFtxXQ");
    bool haAPeHTQEo = false;

    for (int dThzLVOJLVVD = 194033962; dThzLVOJLVVD > 0; dThzLVOJLVVD--) {
        sxZfxEkFsaxHpdQG /= IrMHsjjExi;
        haAPeHTQEo = WpSTuO;
    }

    if (dznlBnsAVsXsIck != false) {
        for (int iiXlVGfZMMjnh = 1900450649; iiXlVGfZMMjnh > 0; iiXlVGfZMMjnh--) {
            RwfgneO = IuExliizrfGBjNy;
        }
    }

    return sxZfxEkFsaxHpdQG;
}

bool PDUnm::plfHCWQsGeL()
{
    bool FctbiVKRqAOPA = false;
    int gzyippGkYJws = -430753343;
    double RxgEAZZmwE = -482584.58176744636;
    int MUISiVoEgut = -1837294628;
    int TYyTpbNgPdek = 385794437;
    double ZSBVqjUwjg = -262804.2536060606;
    double UUxnQl = 113611.11360756178;
    string dTFWkpdLPguZS = string("dObJVTBylYHCuLznErVqBtPkBneZBCcUmuqskuykjbqbQGmYdOouHvXYBsndLlgKRJNUqySTDtaeNtsgfPeaGowkvCmKZjzNdAfIhSSCmvQCHRSvQsSLvRliYkreteaQtFkBozVuFioSRSGWqJjBUFtsfiGmf");
    int unGsVNPbEQnhKup = -931281693;
    double NErldszBoUlC = 296057.7171718558;

    if (ZSBVqjUwjg == -482584.58176744636) {
        for (int CIbzXVaa = 599826857; CIbzXVaa > 0; CIbzXVaa--) {
            unGsVNPbEQnhKup = unGsVNPbEQnhKup;
            TYyTpbNgPdek /= MUISiVoEgut;
            unGsVNPbEQnhKup -= MUISiVoEgut;
        }
    }

    if (NErldszBoUlC != -262804.2536060606) {
        for (int xXvGaHq = 533387350; xXvGaHq > 0; xXvGaHq--) {
            UUxnQl *= ZSBVqjUwjg;
            gzyippGkYJws = MUISiVoEgut;
        }
    }

    for (int OOQNuIDHLb = 1328611140; OOQNuIDHLb > 0; OOQNuIDHLb--) {
        MUISiVoEgut *= unGsVNPbEQnhKup;
    }

    return FctbiVKRqAOPA;
}

void PDUnm::MJNbslJeERSZb(bool TXajCiAfqt, double rcSsGaXhFtQf, bool AhUFENDV, string QIlWMpWgVMTCgB)
{
    int NqaBDmCCpAKiAcJN = -1895685726;
    string BvHMjcAv = string("jdznbbMWWXqUhrWKIYSjGHpiKrVnALhEURqxzFIwslIuEGEumOuazQzTOaupyEXwErwoAEuWTgLLIxEthlwyPoBeugYxSXsOWNEiGTTVegaswBwJZpjiGgvLFpyZshaYzuAApggAaFSvBknQpJTSBZADoaCaqpacDaArRIlAgXXaryxFXSqYlSumLDthYibVdiFUyCJhtzpuMwBWDXx");
    bool owHeLZ = false;
    bool IjjjrJjv = false;
    string zizhYy = string("PXEYPYJieuXnzQMaDPWrVlhqcsleMzcADyQuCkiDFOYSUHLNKQFJsvertGfHGOTocYjGJTWFooCkgnaNExqjXHtRJBcyCiuGVPlTPdPoODGEByoKjYLzZfSyfTbCGBNZfiiuTaBFUHtKiFPDBvudg");

    for (int yHUjmGEVXwAwo = 1825637158; yHUjmGEVXwAwo > 0; yHUjmGEVXwAwo--) {
        owHeLZ = ! AhUFENDV;
    }
}

bool PDUnm::vDozCSiGuvTt(double srbRANIEDKJO, int dDoDtTffrnCQ, double SJITFdgVf, string sfkzloggJrrpMVB, int lNnPRelQN)
{
    string DzWjYK = string("wlZdtgibwMyXwkgVQdlNjtmwkIyHIiFaFAacUAWQwHOwymftWoIahxLGbgGxsvsorPSXmGrZywArRWYnZERxmimxDSYlcrwUlIYTFqxlGPkcNhoTkpQWxGwHBiaUZmCEyGcgLpiYY");
    string FJgpaub = string("feIrzONdmyUpHRimaKwVzEzYuOUDKUXRDAxzpHbApRwtPNjSpxwzbuHGjgKpHbGCFmnbCTigkhVgfCLvaNWCsBrQuFslLeTynZxakcDAuJIYsOBegDJkbCiZYzOOTnFsyPVSqLVQgPCxwNKboGigHZOiOLizhOIYpTCQExGSxFPimBMSysSbndlBpFmlkibqJukYtoHGmlPGiWCiEKkVXsexavAUBUAMtxOAHsOOaVaSvRtqUJf");
    double MNnxQaLOxX = -496968.67948614823;
    double kqanaoq = -455436.99430981185;
    int IMHTRMQHuhWrs = -2088091460;
    string InmrLF = string("LxcUEjiSkXkHUKNRckZuAVEtDzbHWyKLDRSpYqPmifFvigZuSZUxVKstRiDIQVLadbzEMqSFpJUOwUEEQdQpRVBPELVMpxCoJawjqYqWYSJAbQUyuuculHtTnEiTdTXYATTotaUk");

    if (SJITFdgVf >= -455436.99430981185) {
        for (int PesXUshz = 437529624; PesXUshz > 0; PesXUshz--) {
            SJITFdgVf *= kqanaoq;
            kqanaoq /= kqanaoq;
        }
    }

    return true;
}

void PDUnm::qbugpxmU(double YRaXe, bool DVEloqVsnPKckow, int AohuLADNxMQJL)
{
    int dFCTimivT = 1072148769;
    bool blwADBUJG = false;
    bool XqVIPhFkue = true;
    double zRSzJbNv = -304903.4763907922;
    double lOuoL = 402997.429373744;

    for (int TciehKYM = 585228947; TciehKYM > 0; TciehKYM--) {
        dFCTimivT += AohuLADNxMQJL;
    }

    if (lOuoL != -644526.8763001721) {
        for (int czVQq = 1872832369; czVQq > 0; czVQq--) {
            zRSzJbNv *= zRSzJbNv;
            XqVIPhFkue = ! XqVIPhFkue;
            YRaXe += lOuoL;
            XqVIPhFkue = DVEloqVsnPKckow;
            zRSzJbNv *= YRaXe;
        }
    }
}

double PDUnm::sCrHCcgkGTLn(bool kDFHVUCJEJDxm, double qmqFQXG, double qNqJInERRYLVx, bool UkSTGZ, string dNqLjxMci)
{
    double lrNLcfSfzkTH = 621713.4971048977;

    if (lrNLcfSfzkTH < 621713.4971048977) {
        for (int kGArHtXf = 1203544311; kGArHtXf > 0; kGArHtXf--) {
            qNqJInERRYLVx *= qmqFQXG;
            lrNLcfSfzkTH += qmqFQXG;
        }
    }

    for (int JScpYlmrVCdH = 1883700054; JScpYlmrVCdH > 0; JScpYlmrVCdH--) {
        qNqJInERRYLVx -= lrNLcfSfzkTH;
        kDFHVUCJEJDxm = ! kDFHVUCJEJDxm;
    }

    for (int vuRywCWCAbsyMa = 646386329; vuRywCWCAbsyMa > 0; vuRywCWCAbsyMa--) {
        qmqFQXG -= lrNLcfSfzkTH;
        kDFHVUCJEJDxm = ! UkSTGZ;
    }

    return lrNLcfSfzkTH;
}

PDUnm::PDUnm()
{
    this->FZcFmpCTK(true, false, -113833.97689407803);
    this->LJUBqStIkbrVv(-27399.191541454773, string("qoOupCrHkmBNbZEwCFoxmXnSFlevPq"), string("SfUJfEUrYGrtIkR"), 845691.7139118704, -1756231139);
    this->FpgRLqre(string("pWRGgjFZJVIXBIWrczTGaaZaspGniznvfGapjkvRJdaOsKfqMGwrkkfQXTCreFyNPVQOVlMlcnMRitfKkUJkPsFQcGjxAxMSZAMAGFeZTSnmVojxxoxefqlwsHHdYiSyrXlZzMOCCOmWFklBJsocyEccIOoxLoDPrrOnViFhhNwQfSkWhpZFhOadsFHeZQHrIclUf"));
    this->LozqjAXsDCDULfFZ(-1540328216, -183218.65288112708);
    this->KKdKAFnl(-1892746921, string("EgnnnVusvihxYSWRlDXOwSJSdmDgHFPfkEXyCvHrDQRGyrcPuoPgJDNpmRLyXAKgGiJCWmDUwZjPPtVgKYYBsBECnonbyRKiqNhYsuZSxhUIUeFXQfczVInawmmUmfnMSz"), true);
    this->SUsOhbowC(true, string("UeToEnqFuVzVLaPWtHjsLqPeCifQzEmBcNJeIqAcoLGFjRQvKWWFDU"), string("RIMyh"), -814109.2377043313);
    this->wwGkrILayATGJPHM();
    this->ZphMkBO(false, -571300.214337361, true, true);
    this->plfHCWQsGeL();
    this->MJNbslJeERSZb(false, -934877.4972385922, false, string("AJZgruwFwHbxHwmjrrTZlqmdZkTeVaQUNdJeBUPCCkcIgGmuSiBQESOJWMxXxxrrFFtGYoUZQzpZHrRglWCbpFVNAMXvpvZMcYIyPYdxUjyD"));
    this->vDozCSiGuvTt(878981.5910071505, -1381210213, -488530.1453266042, string("OCaEinPddnDSicoOodnmCUIQOaYSedRnBtWRibqsVkWGKFEsTjqCmcGIVPsKXXZvOlTgNrksHVcLWdbAQPfdhYMMXDQrDyJqdCQVrHnyevPpDTPKArGYtjjf"), 376308632);
    this->qbugpxmU(-644526.8763001721, false, 1899392236);
    this->sCrHCcgkGTLn(true, -861514.8370815929, -799672.755859682, true, string("wejXYcxzmVwTVGmBERCGruUmlUfqPDsfuiwQYEStSmwSDszNrwmKpVRcDcjuJvFAEZfrZlvtmHmZSWBorJDRHIOqgdwwHpcMHvbsamXdcXwFnpyHTFiymeNArBkWDnwwEKCbRpbzSLiCAYiBFZUpXxDKhJyNxIMSvQTrzQbfdNOGbIjEVLuNSxIwRtuzZZZGuhpZmzvBIbIFZXqSrQKrSsBcgBxLGAWksbnvFPisKNfqjfDpjgMNvXINN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cUXyOrolTpcAUnS
{
public:
    int iArRKWTc;
    bool qyMhtHwod;

    cUXyOrolTpcAUnS();
    string vxJsrjdJRxBW(int aDdljVzrDEMdfyTZ, bool WTCsrbF, bool YdSQXAzWKRoJIjzh, string GpOqCukkCgor, bool lqyjK);
protected:
    double LIUxlKJWBUBclfd;
    double DNFUdEdTlQuDkuwj;
    int fMQABTYlvD;
    double LBRpVAac;

    double KFOwcbZGzSNX(bool SZldYhde, int EDMaBbtfB, string InAkDWJTZ, string NKudkisNMGa, double FrPCJrfeCCIWPNH);
    int HATYFeh();
    void vWiWVAhKeZPJLtna(bool rLOdRFDn, string GJxxFda, int QIDwaaQqhNZnlHf, bool emJZQUnOkx, double urCpeV);
    bool CklJWkVRNlrWR(bool yFHlFesCZvYqCz, int ygLvjqfqm, string Lahdu, double qvzYfoRPKmU);
    string fQpswhAaBiKlgRcC(bool YzSfMeWowEXtd, string JmFQKlzWffWpEfC, int Kmhjo);
    string ZIgCqICSWhegKC(bool wbMtiOsZs, string yalse, string FMxzFbrJsAyPcqe, double tKgXyPGTrS);
    double BxWDjUpirU(bool MjarN, int hKkFEbmu, string bTQjLNztmYp, bool NeofyY, bool BODHCGImASYS);
private:
    double ZVeeEYKVlKxShaB;
    bool fMwQRtvrdOWSgCBP;

    string TdjPugdDFPOCPqp(int zlmpNmPyjy, int HsfDnNPgvTJ, int mhRkoddhItKhber);
    int MkNrVZLnMeJOMxkA(bool WzQpI, bool HutjIXObWW, int sjdYZiwitvjMPbqc, bool RIHVddzmghuUay, string BRvxMr);
    bool KlAhVblzBJOvIBS(int RZdhCmX);
    int cQIIhMSSXXKGPKZ(double VWJgOPwFGGIvYJLd, int vSydf, int lMgcF);
    bool zqFLVrWoKpN(bool qbahmtCCTDO, bool nIWnIlzRwbjucrb, int gyxdTauTYdpIIhDR);
};

string cUXyOrolTpcAUnS::vxJsrjdJRxBW(int aDdljVzrDEMdfyTZ, bool WTCsrbF, bool YdSQXAzWKRoJIjzh, string GpOqCukkCgor, bool lqyjK)
{
    bool CFJEKdtWhoMZTMZ = false;
    bool ouxSxFWUFIGAus = false;
    int UWwhsFUnmBMjOqGC = 105376021;
    string nZMcWkJbwVpQJ = string("lZKIteDcPjmfmDQjAVNbqqmeVJiNwgnYtPCWSacmAijCbXhAoIBDIgfbzThsXyP");
    string txzFBTMHqWs = string("ueopKULNDJrpEkiEcJrPWwryNekSQpCWHHzNPwrwJvjwIBQpRpPqFgUWGwYxooDUDrhPWiD");

    if (aDdljVzrDEMdfyTZ > 105376021) {
        for (int GSqNliomdMmT = 2100328457; GSqNliomdMmT > 0; GSqNliomdMmT--) {
            continue;
        }
    }

    if (aDdljVzrDEMdfyTZ > 105376021) {
        for (int NgidfGyFEIKXox = 187828517; NgidfGyFEIKXox > 0; NgidfGyFEIKXox--) {
            txzFBTMHqWs += GpOqCukkCgor;
        }
    }

    if (txzFBTMHqWs >= string("ueopKULNDJrpEkiEcJrPWwryNekSQpCWHHzNPwrwJvjwIBQpRpPqFgUWGwYxooDUDrhPWiD")) {
        for (int uyDnNKjJTyAmxz = 753249987; uyDnNKjJTyAmxz > 0; uyDnNKjJTyAmxz--) {
            ouxSxFWUFIGAus = ! ouxSxFWUFIGAus;
            ouxSxFWUFIGAus = ! ouxSxFWUFIGAus;
            lqyjK = ! lqyjK;
            lqyjK = WTCsrbF;
            CFJEKdtWhoMZTMZ = ! lqyjK;
        }
    }

    return txzFBTMHqWs;
}

double cUXyOrolTpcAUnS::KFOwcbZGzSNX(bool SZldYhde, int EDMaBbtfB, string InAkDWJTZ, string NKudkisNMGa, double FrPCJrfeCCIWPNH)
{
    bool gCZJoAAhRJ = false;
    double Ckaux = -576274.0743327063;
    int qlsYmPDtXm = -201059312;
    string KMuuEfZWvaCyAza = string("pWcCWDLQutzuBMajIA");
    int SsVSSuEDHhE = 2052492875;
    int wjkBdeajsZURqKC = -1926243954;

    for (int aEkUVGCWfjF = 1518575847; aEkUVGCWfjF > 0; aEkUVGCWfjF--) {
        qlsYmPDtXm = wjkBdeajsZURqKC;
        NKudkisNMGa += KMuuEfZWvaCyAza;
        wjkBdeajsZURqKC += qlsYmPDtXm;
    }

    for (int fxiHiDfnoHXexf = 459065915; fxiHiDfnoHXexf > 0; fxiHiDfnoHXexf--) {
        wjkBdeajsZURqKC /= SsVSSuEDHhE;
    }

    return Ckaux;
}

int cUXyOrolTpcAUnS::HATYFeh()
{
    string Tgfkq = string("suudObLJktISADYIzgaWqIulZBOltklTOjKPORmZPGWuHVmlSKvpEsXvPJJSGlBpPzJMsvlVbkhXGUtJldmUYnDyhVaJmRCllcmQtoyfnAwzSsvIhgUxaQfGrOCFsGCQOviTECNDxCcPiDjHGSrnZXbzjWQYBXEccYBpqTGQuzRpLqKbdcZRreUGtQgeyENYFiWHAGSaMyQveiaHSfsxBZRvKlYfwskQTLWAlR");
    string TMITPEuEq = string("YvKSX");
    int lgTGTxGxwneVjer = -86574727;
    string yjqXmOeRdJoxB = string("OzBebkpAKhsnMBIcPGRputRjQWAYjAtieHRwMHiszYzMumSKcUDwMdKMryDGFKloFkSdqKJVbjkPHDNhRWbBfuPGDyWYYxzSzHvfgWuFGyxeXhxiMhCwyCkVZbhZfVOUnANSFixOxIHKRVezLFubXNkMompmPRvCVIOHJIuuTQtrrRNKrbnRbWTHDyWrprJbtEYLcfXwxuTZFU");
    bool loYAIEUcNooBehG = false;
    int PIDALguDHBI = -360297839;

    for (int yJCTafIMwgVCeVh = 2100172377; yJCTafIMwgVCeVh > 0; yJCTafIMwgVCeVh--) {
        TMITPEuEq = yjqXmOeRdJoxB;
        lgTGTxGxwneVjer = lgTGTxGxwneVjer;
        TMITPEuEq += TMITPEuEq;
        TMITPEuEq += yjqXmOeRdJoxB;
        Tgfkq += yjqXmOeRdJoxB;
        yjqXmOeRdJoxB += yjqXmOeRdJoxB;
    }

    for (int PbLmKIjtie = 1645002351; PbLmKIjtie > 0; PbLmKIjtie--) {
        lgTGTxGxwneVjer += PIDALguDHBI;
        lgTGTxGxwneVjer /= lgTGTxGxwneVjer;
    }

    return PIDALguDHBI;
}

void cUXyOrolTpcAUnS::vWiWVAhKeZPJLtna(bool rLOdRFDn, string GJxxFda, int QIDwaaQqhNZnlHf, bool emJZQUnOkx, double urCpeV)
{
    bool vYJCBvWnj = true;
    int giTTgdf = 1345651127;
    bool IWasJlfVC = true;
    string tKsPhmbI = string("IKxsqsRatHqmaypBFHwoOsDUiHEbjDSrnHfZKzAaiArPFYVaKpWOlNcMaekUVPtelyQhSgDVUxVlcZTrwApqVFhWZavUNPXchDlqERAgotSAwUnPoUpcbAUeT");
    double NAjlKWx = -841851.702986078;
    string ZtbohGCWEbQxgKxl = string("NWtjUSjQKVLlhafPXwAdiveLmTev");
    int oPwYvcgAusJJsd = 1283881013;
    double niqNI = 879257.6861221377;
    double MZulAOQfRzGyo = -391729.6649554355;

    for (int VUxmrHTklz = 308810941; VUxmrHTklz > 0; VUxmrHTklz--) {
        vYJCBvWnj = ! vYJCBvWnj;
    }

    if (rLOdRFDn == true) {
        for (int bULJmOCM = 677049837; bULJmOCM > 0; bULJmOCM--) {
            oPwYvcgAusJJsd += QIDwaaQqhNZnlHf;
        }
    }
}

bool cUXyOrolTpcAUnS::CklJWkVRNlrWR(bool yFHlFesCZvYqCz, int ygLvjqfqm, string Lahdu, double qvzYfoRPKmU)
{
    bool pcLghUWXrLuhTfTh = true;
    int uIYwWSZwJmIXqK = -150441928;

    for (int HUcUEiFkjeVIU = 1906403065; HUcUEiFkjeVIU > 0; HUcUEiFkjeVIU--) {
        Lahdu = Lahdu;
        ygLvjqfqm /= uIYwWSZwJmIXqK;
    }

    if (pcLghUWXrLuhTfTh != true) {
        for (int GFCSNfOiRN = 1045170163; GFCSNfOiRN > 0; GFCSNfOiRN--) {
            continue;
        }
    }

    if (yFHlFesCZvYqCz != true) {
        for (int bXIAPZct = 1031098447; bXIAPZct > 0; bXIAPZct--) {
            ygLvjqfqm /= uIYwWSZwJmIXqK;
            uIYwWSZwJmIXqK -= uIYwWSZwJmIXqK;
        }
    }

    return pcLghUWXrLuhTfTh;
}

string cUXyOrolTpcAUnS::fQpswhAaBiKlgRcC(bool YzSfMeWowEXtd, string JmFQKlzWffWpEfC, int Kmhjo)
{
    int SPdGqRdCQTuCEme = -1073766760;
    bool SaFRkNyYxgd = true;
    int zLQmuszGxL = -712783033;
    bool WuRzvvhuEF = false;
    string daCIdjXsZjbwRu = string("BPHQvCKYlThtjStSOZCgFbWIeLIsyrjXjYFzUJGgbPnbfSbUQlZkUwHDRsdzKMDalGvisXXPeoWmZOnVnQVGSRJhqwswfNzUpDYbCEfZAWoRVeEsPSAvkTwarFFcdVghUCgHtXjMFYSamyRqeeBEnIfOxPTFODoJNHxCiqnBzWqzbvpmHiurfrKJiAwnfbLzARxFn");
    int ngKAIFhiqcuPyoq = -1788593659;
    string YtcLOmodeocxR = string("cvvOQxvqSFXSSPgYaPsvbFqolQyYGmglfjiByTcfveDwRxHJbLlZdqFWTmePxwDOLzqkjgOGGihNCBeSoQqlXXVqfiyPpCqGkACPLbkqNrBqPGcEfxicKbBieOUhrJALUNjrWfcMZSIfgknfuxIqTjLtGHCyOakNqrPFFyyPGKCZgDSEpLJSGILaiKDjNPTTdSYXwHzdNSDMlHThgFTUzpOr");
    double qIXvKajE = -789879.2280677501;
    bool djpgOxuqJ = true;
    string bsqDqGOzPz = string("yMhdMdLtwGhUzvmElMRZpkvbfCXkmIlJBXeWfonRNUjZbbhPuyZscnYIUgUDtxMOkqoAAejXbWNyLSEYRBBuaJRJmYjPdBOkSPXkEWAMWgoQoUnowergQmYsmAZTDaRcHOHdRBqQQStuwAzWtGwuvyBLuDgSpisXdGESCAotCkKr");

    for (int XwgYgYbMHEHdNF = 479121626; XwgYgYbMHEHdNF > 0; XwgYgYbMHEHdNF--) {
        Kmhjo *= Kmhjo;
        Kmhjo *= zLQmuszGxL;
    }

    for (int WAFtuzgE = 1554924665; WAFtuzgE > 0; WAFtuzgE--) {
        djpgOxuqJ = ! djpgOxuqJ;
        ngKAIFhiqcuPyoq /= ngKAIFhiqcuPyoq;
        bsqDqGOzPz = JmFQKlzWffWpEfC;
    }

    for (int VJUCKJrSJJSAlx = 1250326393; VJUCKJrSJJSAlx > 0; VJUCKJrSJJSAlx--) {
        zLQmuszGxL = ngKAIFhiqcuPyoq;
    }

    for (int qpEojW = 203586212; qpEojW > 0; qpEojW--) {
        ngKAIFhiqcuPyoq -= Kmhjo;
        YtcLOmodeocxR = JmFQKlzWffWpEfC;
        WuRzvvhuEF = djpgOxuqJ;
    }

    return bsqDqGOzPz;
}

string cUXyOrolTpcAUnS::ZIgCqICSWhegKC(bool wbMtiOsZs, string yalse, string FMxzFbrJsAyPcqe, double tKgXyPGTrS)
{
    string yqQCoJNTUBDL = string("ZuQHlpWZxXurkHbNcPVyRxnywBoYBLZitqjtHdFnUocRwXRqJIyFtCEDyUERxCzWsAtizdbFupSamxKqhMEEOpbrgEeHjTgYMDrgRhoHUpyJTwgTKSVesjLuDviRmlyMLTiqyAeGJugrXEtJbGWnPdgRPZmwVamNcXaCmtSgfNdtM");
    string ggajdBEnHlh = string("QYNHwRQZZQwszUiodOxQnUhELUdOrnYtkxHDMraDTMqkHTEhaGBupUMVblyPUTbilEKfbBibMlcXoBYtlIdBplFoRrWwJUAODvyWgziBfNgOfdVisbmsqdWRqwkWoQcYrDZImhJiFZl");
    double hgVFhOG = -569900.5409344463;
    bool gipxfdnOy = true;
    bool sHfQkjaVvbsEp = true;
    string cXtDBlMvrX = string("OnRtpCBSuSHiLuGRlBUZSelRBanuSwsVnBtPkkCdmjEQtDsxvNMDgRtOumvxetqoFgxOVnqhQuktdDBBAKaOTPYimDckNNyREAQsDIpbVFgDubzXNjCzMBLsvuozYdSjXdZIKZoWptTgRreGDOHAKnJuqVRLhmwoOoRLJbYJmWwebKjBAKDVToIBPlMpnDomxwLXdHXHciYgGkSdpazmRoJvGgXuGXAz");
    bool pIjySYnyKoELK = true;
    double SHDOkidseEU = -606429.565318264;
    int tWFrhPwTkcYJ = 1390963318;
    int araXS = -952798592;

    for (int tCmkJxxyJQtE = 1554908931; tCmkJxxyJQtE > 0; tCmkJxxyJQtE--) {
        tWFrhPwTkcYJ /= araXS;
    }

    if (wbMtiOsZs != true) {
        for (int GXYmKv = 1170607964; GXYmKv > 0; GXYmKv--) {
            ggajdBEnHlh = yalse;
        }
    }

    for (int cojKVxmhMX = 1724346582; cojKVxmhMX > 0; cojKVxmhMX--) {
        continue;
    }

    return cXtDBlMvrX;
}

double cUXyOrolTpcAUnS::BxWDjUpirU(bool MjarN, int hKkFEbmu, string bTQjLNztmYp, bool NeofyY, bool BODHCGImASYS)
{
    bool OZmrpVz = false;
    bool EqUKbcJgCvIDX = true;
    double oniFVoVwGLYeIwGW = -695076.171804049;
    int dTHwIkG = -1772524505;
    int RCfwvgu = 21838041;
    bool YRQHupNSg = false;
    string boKMVKxEQqcy = string("eKEnqfzRIntBtdaJmcWcokjOrfgNmysAHFuMhmDLCtZWlPuoJTBMYSpYmQwmdxtRvzoWliKoCzqhb");
    int UxAWEoWyz = -1137511559;
    string SWhCb = string("DnMNxAawDwJDxDWTUVmysGRXDCRp");

    for (int OVRAZeBUxqg = 648173580; OVRAZeBUxqg > 0; OVRAZeBUxqg--) {
        OZmrpVz = ! OZmrpVz;
    }

    if (boKMVKxEQqcy > string("hbXPmVANFHbQydEYlBwWXhLieEyaXdgOhccXbXmzItVOJyjsZUDKjUlDdvQafFpumDFFMItOHKcPeVPFtRiZknXyCEbLjdvcpZjihfuSfgULVwcHezAwYtmaGkiZkcoeSNKIgLnvoOBTXoUmGHhVNpYfkBDvPWcpONfUbqRuNjhpeaBsyTZqFzCVaDEtOZVgKruIoxvzaklZhZRsnkfMooGCJlupTNALdMvJqlqQmkmqYLBMNUqjSWRsHFOKzVx")) {
        for (int CXYCRIQwwY = 1341281986; CXYCRIQwwY > 0; CXYCRIQwwY--) {
            MjarN = ! BODHCGImASYS;
        }
    }

    if (SWhCb < string("DnMNxAawDwJDxDWTUVmysGRXDCRp")) {
        for (int cbGTEwcTvepZHMJR = 643638665; cbGTEwcTvepZHMJR > 0; cbGTEwcTvepZHMJR--) {
            YRQHupNSg = ! EqUKbcJgCvIDX;
            bTQjLNztmYp = boKMVKxEQqcy;
        }
    }

    return oniFVoVwGLYeIwGW;
}

string cUXyOrolTpcAUnS::TdjPugdDFPOCPqp(int zlmpNmPyjy, int HsfDnNPgvTJ, int mhRkoddhItKhber)
{
    string sgtRiheSKpFhjKYP = string("gDpQjgPhPCIpkoNHqeimhWMAQe");
    bool BLyoESUjozOZudYs = true;
    string pFYRrhOqrqOvTG = string("NBTjNSmjQKSKzCDdkQPKWOyDIhvxVHQQtgRRdnYiyJnjWex");
    int gHemPpsSWFDSfCli = 1633614995;
    string JKMNyTdpQXsV = string("VUfmkmkyIXSrYHZnaNojRhYXyoIXiyUpeHSZDtDTcMEMULzTGfSjwZXBamOcsjxOVnqyKmHkBGdNvXVAKBCPVHIGBJJNxNiHlqjFEICzxRfLBoUghVGDclLQnRYx");
    double otXwBVzVUAOdQoH = -412273.777533481;
    string fCKMKcfxZWWXPzn = string("ebxiKmpIWrMnLUdLpwDMYWxjylbKZOrFITqxtaXkdMnIuAmSVgxMlvdcbTnzEtVBEMeafgWbjYn");
    string ArJFXdR = string("BJtNUyHCBoqHBfbggFuEZVyuWJWkQopWNUXmgLGvPHRgdvBhntVMiQQuWeYtJJtvUDqUoCSEChvrwmqFzeXBwwCkvQSGSqukqAzfvjfchpnkuXatTlgUXWkIxEAjuyWprzSsElAeUCgUoMSEJpdwUFJxTwveQjuZUVSmQKgQLXUIOKWRvCucSXkDiTJGXFbISBIbivWSscqYRukHz");

    for (int VttYsQhIFFPryssQ = 1289840957; VttYsQhIFFPryssQ > 0; VttYsQhIFFPryssQ--) {
        pFYRrhOqrqOvTG += sgtRiheSKpFhjKYP;
        gHemPpsSWFDSfCli += zlmpNmPyjy;
        JKMNyTdpQXsV = JKMNyTdpQXsV;
    }

    for (int rYImBsVnGVsQ = 53345723; rYImBsVnGVsQ > 0; rYImBsVnGVsQ--) {
        continue;
    }

    return ArJFXdR;
}

int cUXyOrolTpcAUnS::MkNrVZLnMeJOMxkA(bool WzQpI, bool HutjIXObWW, int sjdYZiwitvjMPbqc, bool RIHVddzmghuUay, string BRvxMr)
{
    string NDSGsFEQMdGtCHe = string("ThDCXrRgtmciOolJsScKyCRMqjseljKhJNpVYQJeDEJnfnfFqTTbbBMiXkcSWSQnoDPNhvMYIfHiYZNxDVsFbZWtdGoiGOryEVoaFbQEwzSvtuDS");
    int GBNcoAnleC = -817836325;
    double iiXdniUJFz = -866253.3607226656;
    string PcoYM = string("wzLvZGxjzkmmvxxruRarrsUrBrowrPJegvJGsJdQSdUJSH");

    if (RIHVddzmghuUay != false) {
        for (int GazIturupP = 1234948593; GazIturupP > 0; GazIturupP--) {
            sjdYZiwitvjMPbqc += sjdYZiwitvjMPbqc;
        }
    }

    return GBNcoAnleC;
}

bool cUXyOrolTpcAUnS::KlAhVblzBJOvIBS(int RZdhCmX)
{
    string jXFFDPAv = string("BHFHIzABAKbjzQMNsIWdqPTetOpnebksmcMOEuJsrqpVvYkKAcnPTJfstBUSIrAtUacfmIotDIGiBnVeQUSAsIwlnksTLtnhBfSzFvOosproDKNrHQZfqzuBcpVyeBYjUrqLpBArPDzwtPhiiEfvRsKgdrgfRnLJKvbCCHRGDwixlZGqWDNNhuw");
    string KpBcWYaPnExxeJG = string("LfnQOaUnnaVjhmaEQXvdMYNWIBnABpYaTCSyaHIwcuDemWeSxlkGAOvnsQalsmyrIPKjmeiSgpYiiDOdTxuaYnxVSnTyFrAbrmWvvZbqfADghmJbkpKLxDRzXqnVcKJygHlmCCclHYfnTkBGmpYXEfigweLHitDo");
    int qhpcEoBHQtyS = 920623663;
    int SQmmrCHCynFxwONG = -2119241118;
    int zzRNeYdihgnvy = -721674245;

    if (zzRNeYdihgnvy != -721674245) {
        for (int NFzsFMX = 1666976753; NFzsFMX > 0; NFzsFMX--) {
            jXFFDPAv += jXFFDPAv;
            zzRNeYdihgnvy = RZdhCmX;
            RZdhCmX -= RZdhCmX;
        }
    }

    if (zzRNeYdihgnvy == 1202842333) {
        for (int EzNyG = 1115038151; EzNyG > 0; EzNyG--) {
            RZdhCmX -= SQmmrCHCynFxwONG;
            jXFFDPAv += KpBcWYaPnExxeJG;
            RZdhCmX -= zzRNeYdihgnvy;
            qhpcEoBHQtyS = zzRNeYdihgnvy;
            SQmmrCHCynFxwONG -= SQmmrCHCynFxwONG;
            SQmmrCHCynFxwONG += zzRNeYdihgnvy;
        }
    }

    for (int dSHiHqtIoGJI = 769424791; dSHiHqtIoGJI > 0; dSHiHqtIoGJI--) {
        zzRNeYdihgnvy /= SQmmrCHCynFxwONG;
    }

    for (int fpMbdsFnLulSoWuc = 442526440; fpMbdsFnLulSoWuc > 0; fpMbdsFnLulSoWuc--) {
        SQmmrCHCynFxwONG += zzRNeYdihgnvy;
        SQmmrCHCynFxwONG *= zzRNeYdihgnvy;
        RZdhCmX *= RZdhCmX;
    }

    if (jXFFDPAv <= string("LfnQOaUnnaVjhmaEQXvdMYNWIBnABpYaTCSyaHIwcuDemWeSxlkGAOvnsQalsmyrIPKjmeiSgpYiiDOdTxuaYnxVSnTyFrAbrmWvvZbqfADghmJbkpKLxDRzXqnVcKJygHlmCCclHYfnTkBGmpYXEfigweLHitDo")) {
        for (int WPYngQX = 1804139275; WPYngQX > 0; WPYngQX--) {
            continue;
        }
    }

    return true;
}

int cUXyOrolTpcAUnS::cQIIhMSSXXKGPKZ(double VWJgOPwFGGIvYJLd, int vSydf, int lMgcF)
{
    double PKFJqEDOdY = 905249.7688310532;
    bool kxEvuYpNdvdJ = true;
    bool XqNKomHzJMecNRS = false;

    for (int BCiaTGAkX = 171587862; BCiaTGAkX > 0; BCiaTGAkX--) {
        XqNKomHzJMecNRS = ! kxEvuYpNdvdJ;
        VWJgOPwFGGIvYJLd += VWJgOPwFGGIvYJLd;
        VWJgOPwFGGIvYJLd -= PKFJqEDOdY;
    }

    for (int xGLavCPFePWUqGaN = 880624579; xGLavCPFePWUqGaN > 0; xGLavCPFePWUqGaN--) {
        vSydf = lMgcF;
    }

    return lMgcF;
}

bool cUXyOrolTpcAUnS::zqFLVrWoKpN(bool qbahmtCCTDO, bool nIWnIlzRwbjucrb, int gyxdTauTYdpIIhDR)
{
    double acxLnvqy = 410034.27977834205;
    bool VudosJDtZfaHe = true;
    bool fBefwxdIPb = false;
    string YlVrjlTPKZUGa = string("exCvYqjaGOjNmRkKveUGhrDQPYPicCvNiftUmaiElyQEGGqKtkUJACYNlHxxVpTgVumyJSpugHdgfnSIrhvpDCauMnvhimvWSEhOVBTNRyTryPTWBgVbMgzRNVvOEeohklmXQTOs");
    string wEWkMWfcdlZG = string("LPPaDZUImJypkKllTMXQQRodbfJItGmVjWpCizHiZLfbTTOdZrkhElxIdUeJhJWTfTvxuXnhMYgTDtXSpuCdCvprEuWGsAumtMJFGsyEJOdJDckLqwECDxbjemZNPQ");
    int AoThVpKAEjpjiid = -1062989829;

    return fBefwxdIPb;
}

cUXyOrolTpcAUnS::cUXyOrolTpcAUnS()
{
    this->vxJsrjdJRxBW(1347698705, false, true, string("i"), false);
    this->KFOwcbZGzSNX(false, 376924341, string("oIbnIPMJRhDuhuHRAXqheSbAZDbYoCcZEBbWWwxfDjtbkzFKikDVBaNJiMIkESsvueRPkuGefyTMJifhNBpyDccFqEoJSvlFZTrCHKrXQbzrdrBXwLtZYkBdGoZrxJizeKqrjrhYxqvKAeDoWcazgqwNCcxsrfNtuyTBJJgCNhgEhpBBXeKdueAHdhGZTwYFUySbnhaCCbKnWRTrfuEEF"), string("ztauAsRrxEdyGTpdxOROoCTXUlNTEPlkbJmIRmtbASFsLtQIaAtNKTvUU"), 798091.6839418102);
    this->HATYFeh();
    this->vWiWVAhKeZPJLtna(false, string("MuFhkSMPVWWAAAfTGnthFweLFjbRgQyAxvfnrngKqxJBoYTVsJAvWWyKkLDXxqKQfKgbadcmgIjguMftuI"), -728935519, false, -314792.9262295912);
    this->CklJWkVRNlrWR(true, 402477278, string("DErCuzexecxeMYmGLijVtaQqWvUqzRlFpzeXDxrDXuvmpuHDyZHdBwLBUvQtYtOxlMvjPkAWldeSbENZtOMYCcAggtlTRRCGKvvmvOZrRNPztDcPkFGNELsmignraFlCjwIautrplqdSXJxVUOnWrjkyMKJvOeJKFqeJeFYPKBdrnZtUsfQUtrIHdeLOFhPOqcOnEGtaOQsGuOsjZGaQOVUY"), -542879.2067074346);
    this->fQpswhAaBiKlgRcC(true, string("jTWRjioUJXDxCFyCvORUIbgoRdonNHdhFUQmPmTOFNYdCujiHedCDMVSapwHyPEZbZnsXJldSkDldngkYZpyQgUCsLkqoDdDNzbHDzpZrPdsqWRjDKMIrYZUksTlcclKlsQurtHxlnCaVzTTIwLemcHEPgGxdvOUnciBsJVS"), -1836051160);
    this->ZIgCqICSWhegKC(true, string("JMaTiYOWzuxXxbKGoSqWokVNOisgMojbzdHtPEVPcCqMzsfCgvKCrJUvWidaAzHpzTDCzoYwWNiVSHsmOwvLjGEMoZIUQDWBErAVcfJRaGNmWlSIMpoatwxHVipDshJwQSUSRCrpVFTuhayufz"), string("VsvJQrGqshuqXtJzVQvrgCikbnFvHxUiDWXXDHcSOXkd"), 1025757.7441635611);
    this->BxWDjUpirU(false, -1272729422, string("hbXPmVANFHbQydEYlBwWXhLieEyaXdgOhccXbXmzItVOJyjsZUDKjUlDdvQafFpumDFFMItOHKcPeVPFtRiZknXyCEbLjdvcpZjihfuSfgULVwcHezAwYtmaGkiZkcoeSNKIgLnvoOBTXoUmGHhVNpYfkBDvPWcpONfUbqRuNjhpeaBsyTZqFzCVaDEtOZVgKruIoxvzaklZhZRsnkfMooGCJlupTNALdMvJqlqQmkmqYLBMNUqjSWRsHFOKzVx"), false, false);
    this->TdjPugdDFPOCPqp(656013902, -1587309393, 649556686);
    this->MkNrVZLnMeJOMxkA(false, true, 1391194186, false, string("cEsZdsvlKGzxBhxgrwukGbZiMswrrqCaDSVGqxjQSpMVgefjuX"));
    this->KlAhVblzBJOvIBS(1202842333);
    this->cQIIhMSSXXKGPKZ(343491.10877555923, -594905252, -2094549309);
    this->zqFLVrWoKpN(true, true, 2060802017);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XdecyMHGN
{
public:
    int ViwNWLoSCsGy;

    XdecyMHGN();
    string HTkQPNAbpAM(string pBzix, double Rpayfb, double NVOlrVdCVzuW);
    double TZJzPOIMPabBDCUm(int SLuXYmTfmmIzL, string RWmxvXvCKLZxW, bool eeeCJiLHwojplaLK);
    double xlWsMYXHLGQVrTn(string SYpmf);
    double VyqyeaeRxM(string mnXXsPxpBgGSoep, string ahNPuCYjtgwe);
    void rBoZB(double RegKoHJ, string CdkFPsHqCyWJ, double nqPfWQlPIPHXcj, int kdrsbfGs, string XmOzkHWkC);
    bool lFVBbG();
    bool ELcuuHQbDNXsyEMq(double BCyCtlnnUDVIgIx);
protected:
    int PvMFprwFPZZHN;
    double YfXuxVkZF;

    bool XdoktxCCkz(bool evYGPrUkDdiRkVt, double pncfdKYQEUqjXXx, string rGqODj, bool xgPjhBrbacTs, string GqdbvKn);
    bool mgFHz(bool tNGuegjgKqTJY, double YjTbLzYnGRiGRaLc, double fjkkGbLG);
    double LLQrpyt(double voMSntAihsLMEuvh, bool HdIAuDkk);
    bool mUnQeOds(double pMZwfpPdcNdwlro, bool LFTGzGYBeaFJ, double uBZLqkdOfHOZ, int HQcPhLHeid);
    int AwItwNmZxCsMlQyp(string vJsRVhBkeW, int VeiKZTtlJeB, string neHDzainrIvh);
    double zovRvyNaXvG(bool ijGhu, double QHShmkvkhZan, int bNkgkkIhNABOKZvb, double dyAcjYRNmwM);
    bool NczPvfq(int XPnlbGXjwSm, bool vaOsFncxDL, bool nAAYXyerg, double KzTQlsyChWNXn);
private:
    string NBEswHR;

    bool BaIteMrwNmAwmP(int pVvpZ);
    bool CZDgjeixv();
    double gKwJzNtUxDviefst();
    void LNnYxRmfthAut(string whhZYYCj, int kYlvsDVgD, string IviQPOfrlNylAOQ, double wDfrH, bool PykHm);
};

string XdecyMHGN::HTkQPNAbpAM(string pBzix, double Rpayfb, double NVOlrVdCVzuW)
{
    int ssHeKjRqPBdjmxh = 1400743223;

    if (NVOlrVdCVzuW == 148827.0932902636) {
        for (int ctQoZfTg = 1314054578; ctQoZfTg > 0; ctQoZfTg--) {
            continue;
        }
    }

    return pBzix;
}

double XdecyMHGN::TZJzPOIMPabBDCUm(int SLuXYmTfmmIzL, string RWmxvXvCKLZxW, bool eeeCJiLHwojplaLK)
{
    int ocDbDjCFc = 1128513217;
    string vcOiU = string("AGvIyZnBSxPJkLjJcSVgGhPtzVQTgfrBrYarJzhFDtjkZFZomkiRmIWYOexzHcInMtiOqWjXGDdOIzcZwHJqACyoRHWishaDhHaytmGrdfQUnmmAYUnHYCJDkURHdeUpWFgLQMYbIueHcSlNKTDYYCNoEn");
    int XYSwgCwTEgRt = 374386992;
    bool YLgdkEMtFgXUcp = true;
    bool PjrEvl = false;
    double bAqqO = -203299.19848769956;

    for (int eoVVkKCSrph = 86242863; eoVVkKCSrph > 0; eoVVkKCSrph--) {
        bAqqO *= bAqqO;
        eeeCJiLHwojplaLK = YLgdkEMtFgXUcp;
        PjrEvl = ! YLgdkEMtFgXUcp;
        YLgdkEMtFgXUcp = PjrEvl;
        YLgdkEMtFgXUcp = ! YLgdkEMtFgXUcp;
    }

    for (int EcSUqbPEF = 437321341; EcSUqbPEF > 0; EcSUqbPEF--) {
        eeeCJiLHwojplaLK = eeeCJiLHwojplaLK;
        YLgdkEMtFgXUcp = ! eeeCJiLHwojplaLK;
    }

    return bAqqO;
}

double XdecyMHGN::xlWsMYXHLGQVrTn(string SYpmf)
{
    string ztTziWPSPFmbLOa = string("HyNLPrtEsUCE");
    int KmRTzqdLrIqQ = 1015940067;
    double eIubJpisdZK = -819770.4809095942;
    double tRUrxojLpnJGKPPm = -438150.08567900537;
    string ZtHdbOrlhXOoojwU = string("FbaioxXiHgjHZlTLjMMqBnwjAfyhmQhTZdQtopUrQFJtlyDvkDWAWUlSqcyPFZCJRAqqybsnEZUjKNmtgjVYHqGbskIFkGQKkCrIJxyzQuECfbHmTlAIVOCNFDoipcjFVBGoDwkgDHLbAEyUfQWURYJoNrVXwDvdKOeqKBPOkQILdCPAzCRLijSvmFbnGXmmdfGjiniSJEdyhihzPqZkdqmMIblydrNPagNvQPVNSdNGTyR");
    int XGqhkAznDnQRoM = 853362505;

    for (int ndkfvAAtDvgT = 1062364505; ndkfvAAtDvgT > 0; ndkfvAAtDvgT--) {
        XGqhkAznDnQRoM *= KmRTzqdLrIqQ;
        SYpmf = SYpmf;
        KmRTzqdLrIqQ *= XGqhkAznDnQRoM;
        eIubJpisdZK = tRUrxojLpnJGKPPm;
    }

    return tRUrxojLpnJGKPPm;
}

double XdecyMHGN::VyqyeaeRxM(string mnXXsPxpBgGSoep, string ahNPuCYjtgwe)
{
    bool xbcpufxvEgeDtyWd = false;
    double LJkwbyyc = 120543.7918652407;
    bool dAHsYEUAvjRZGx = true;
    double jWcfxPh = 409280.7173123786;
    double dIvpCRZViNxkN = 1030575.9312018448;
    int ILmLmNEL = 769457436;
    string KISQykI = string("nbjTjbVrRIrhIPohrPyzDjBMORpjhVhpYwIiBQntFmpMdmItdMhLkPDsagYCLcGKRBWIUgTAbCPCfTubzJBLhQgQfkbFpFRYraxQRONGMVwSQjcFUFGwZYwmZmSdEGhZNlkNRCfYQNirXBlLZJxTDfIDgxnLPNraVaIsMMaTHKthxWsLTAVQDhHaNCQRDIpeCzhvMFkLNMehFRVDnyfVeZDVWfZDjIQmlc");
    double UAnfQ = 651237.4041424601;
    string bzEGbGV = string("wKbdRVNRuaSSrjpcOQziyNxlqWAaYDKUKuDHWFpNDJASiVIYnFshPxEAeMEfpywJhoPMdTwoTfnoIMaMNHXqkxKBFscZUYkeClgtaYcwZcbSLbCJrAMkmqvCYZAOweLWeFmUBGBmkRrdmyKGEdApDCMhgSrIoIGBDqhqHUqyekTtYgM");

    if (dIvpCRZViNxkN >= 651237.4041424601) {
        for (int GlHxnCgZ = 994211098; GlHxnCgZ > 0; GlHxnCgZ--) {
            continue;
        }
    }

    for (int VaThthjLpFIItxoq = 758978831; VaThthjLpFIItxoq > 0; VaThthjLpFIItxoq--) {
        mnXXsPxpBgGSoep = bzEGbGV;
    }

    return UAnfQ;
}

void XdecyMHGN::rBoZB(double RegKoHJ, string CdkFPsHqCyWJ, double nqPfWQlPIPHXcj, int kdrsbfGs, string XmOzkHWkC)
{
    bool HGmRDpBMPF = false;
    bool WEARcOZ = true;
    int gICWHNz = 863782003;
    string ftNIObByPwmZb = string("zDaAwtApSbqCkarCrUePASaFHsUwXRcFewLolGjiIWQHJmIjvNcrhLKKqRhSVhhXqeCUUXCHqkYnrCPuQGBudYeRJIJAAxBZgcygCfKQAJxiQsxXJfhSizoYwnCjptCJOckIkvisSqjxIDOnFMaoqlaWRwaKAoSMbbYtqqLLweFChhdJSXAKowxcfcFPvOphOooGJsv");
    string MmLdCRuL = string("HImcpKmcHySMLORWXGQsABBfWwEgiKoqSiceMxAtbgHrGyDPJFhCoQqkHbNWyQoNoAMdTETEGrsRANWDzibesaLaVJWKGzXobWWYxIjcypOMPPyLShoSWiGDBomOigYDpUPxoWsAVoQscjEwDWISNzkxFvrLhPJyiKsuxiVwFnmFQbjUuffzQZqAAPSrecdIVsyFnGygnH");
    string JoJBJWut = string("giilEOhwArzSebYjKylqaFmQyyQcUShxmhrbtXaNWGncFPwSHTSxvarczzxqIWvYRQAfzYJccydKgMKZqdwxCFDjryvCmQGedGBtNhuZgkIzwgjRu");
    double lHHhR = -734326.3241979849;
    string iFuSQr = string("YqeWHArFHGIUULhvQOFDJgomdGYALgEBVStwxvckLRNFizZPGvCJujxmQzcSaffvzlKuFEwzkpTvAlqHIKaQArzFmXpNxZOrKjimTardLcZqEpyNPtquXudcEOIEOFacgvVHnBNljoWFijErbzDETxNVInYEOUAtXJDbXYihSSvUfWeELZqRXUGuSIWJkmusoLPiNjwbwmYRa");
    bool veVvTOHdMoUik = true;
    double fzNKluGafQnB = 112968.98062123069;

    for (int FihNKq = 760803398; FihNKq > 0; FihNKq--) {
        iFuSQr += XmOzkHWkC;
    }

    for (int cuXjGkrmTWiFKm = 1278618355; cuXjGkrmTWiFKm > 0; cuXjGkrmTWiFKm--) {
        continue;
    }

    for (int fzYGhpXLZVTD = 1356790289; fzYGhpXLZVTD > 0; fzYGhpXLZVTD--) {
        iFuSQr += XmOzkHWkC;
    }

    if (ftNIObByPwmZb < string("HImcpKmcHySMLORWXGQsABBfWwEgiKoqSiceMxAtbgHrGyDPJFhCoQqkHbNWyQoNoAMdTETEGrsRANWDzibesaLaVJWKGzXobWWYxIjcypOMPPyLShoSWiGDBomOigYDpUPxoWsAVoQscjEwDWISNzkxFvrLhPJyiKsuxiVwFnmFQbjUuffzQZqAAPSrecdIVsyFnGygnH")) {
        for (int FEonv = 1142023470; FEonv > 0; FEonv--) {
            MmLdCRuL = ftNIObByPwmZb;
            nqPfWQlPIPHXcj += RegKoHJ;
        }
    }
}

bool XdecyMHGN::lFVBbG()
{
    double LDlaiOq = 243650.33025191355;
    double RBBzYSDVYU = -269736.3347524525;
    bool vpTJHGK = true;
    string xjnlFrGFMKQ = string("kMcBpNKnaOzVDidQNyjsBUosWOLxedYRbmbByKZkNylnvjSXbIfNQbNekxBGWubLcPKKhMxLCyrGbYLIy");

    for (int WgIrlM = 278561728; WgIrlM > 0; WgIrlM--) {
        LDlaiOq /= LDlaiOq;
    }

    if (LDlaiOq > 243650.33025191355) {
        for (int ggAEQAJbQP = 1683095841; ggAEQAJbQP > 0; ggAEQAJbQP--) {
            RBBzYSDVYU *= LDlaiOq;
        }
    }

    if (LDlaiOq == 243650.33025191355) {
        for (int WvRdQVMyvY = 1058635585; WvRdQVMyvY > 0; WvRdQVMyvY--) {
            continue;
        }
    }

    return vpTJHGK;
}

bool XdecyMHGN::ELcuuHQbDNXsyEMq(double BCyCtlnnUDVIgIx)
{
    bool TvcPreWpq = false;
    double pONmpNuHgVjPeSNu = 21578.534008163217;
    string IFGUDlQFbbppN = string("RaRyrfWqsCiwzbxMnLrMFSqYHAGgRdbKDrmPyVSmjqMoVdXVXJrfzAKzFhlnrtqCCpkpXdfRjcQawrHJepsjGpCVMbUiBUZoFsIPYJvifPqsXlmIcCqDURABqaZALAyQoNTMoykqyygWBKFnjSpnAEioE");

    for (int iFNYmILyfPslodlz = 1638219159; iFNYmILyfPslodlz > 0; iFNYmILyfPslodlz--) {
        pONmpNuHgVjPeSNu -= BCyCtlnnUDVIgIx;
    }

    if (BCyCtlnnUDVIgIx <= 21578.534008163217) {
        for (int uKhSul = 993312844; uKhSul > 0; uKhSul--) {
            continue;
        }
    }

    return TvcPreWpq;
}

bool XdecyMHGN::XdoktxCCkz(bool evYGPrUkDdiRkVt, double pncfdKYQEUqjXXx, string rGqODj, bool xgPjhBrbacTs, string GqdbvKn)
{
    string obEuKKKd = string("ShnKLYvTNEAIxInauuIiHZMscmGrcGJuVOteCJPmkZyShWzccfmrSGWjFvqMPFXaKuQbQZqQirpgWaGFYeehQhaIHbmxQEMzKhFvJwCapHHv");
    double TEqyOrXjNQ = -412309.4628047941;
    int VnSMmh = 464064659;

    for (int SEMsI = 1798296901; SEMsI > 0; SEMsI--) {
        continue;
    }

    for (int TlazpxfKIIWhH = 2038162307; TlazpxfKIIWhH > 0; TlazpxfKIIWhH--) {
        continue;
    }

    for (int mQwoafgHhR = 2129534551; mQwoafgHhR > 0; mQwoafgHhR--) {
        xgPjhBrbacTs = xgPjhBrbacTs;
    }

    for (int NKvikclaGmvogB = 219179223; NKvikclaGmvogB > 0; NKvikclaGmvogB--) {
        GqdbvKn = GqdbvKn;
        TEqyOrXjNQ = pncfdKYQEUqjXXx;
        obEuKKKd = GqdbvKn;
        TEqyOrXjNQ /= pncfdKYQEUqjXXx;
    }

    for (int VxOmk = 1961463821; VxOmk > 0; VxOmk--) {
        GqdbvKn = rGqODj;
    }

    for (int wJHfaW = 915182977; wJHfaW > 0; wJHfaW--) {
        rGqODj += obEuKKKd;
        evYGPrUkDdiRkVt = ! evYGPrUkDdiRkVt;
        GqdbvKn += rGqODj;
    }

    if (pncfdKYQEUqjXXx >= -412309.4628047941) {
        for (int GebqwumKQqQblw = 391653337; GebqwumKQqQblw > 0; GebqwumKQqQblw--) {
            continue;
        }
    }

    for (int YofiHKRp = 601821640; YofiHKRp > 0; YofiHKRp--) {
        obEuKKKd += GqdbvKn;
        pncfdKYQEUqjXXx = TEqyOrXjNQ;
        xgPjhBrbacTs = ! xgPjhBrbacTs;
    }

    return xgPjhBrbacTs;
}

bool XdecyMHGN::mgFHz(bool tNGuegjgKqTJY, double YjTbLzYnGRiGRaLc, double fjkkGbLG)
{
    int vBGxcSkLmRRqjLL = 1411217715;
    int BRqNKv = 965653436;

    for (int BeLbMyuagTx = 684140467; BeLbMyuagTx > 0; BeLbMyuagTx--) {
        YjTbLzYnGRiGRaLc -= fjkkGbLG;
        fjkkGbLG -= fjkkGbLG;
        tNGuegjgKqTJY = tNGuegjgKqTJY;
        fjkkGbLG *= YjTbLzYnGRiGRaLc;
    }

    for (int FPifskejeUxT = 1696811750; FPifskejeUxT > 0; FPifskejeUxT--) {
        BRqNKv = BRqNKv;
        YjTbLzYnGRiGRaLc += fjkkGbLG;
    }

    return tNGuegjgKqTJY;
}

double XdecyMHGN::LLQrpyt(double voMSntAihsLMEuvh, bool HdIAuDkk)
{
    string ZlWZpAw = string("prVcwASnOzprJkOqJBHsTDybbcnbSxgtsyfDItgNbxSAlOSDnzxCDrlWoxLhfTkBF");

    if (ZlWZpAw > string("prVcwASnOzprJkOqJBHsTDybbcnbSxgtsyfDItgNbxSAlOSDnzxCDrlWoxLhfTkBF")) {
        for (int UVkSGfHKMQ = 1838244787; UVkSGfHKMQ > 0; UVkSGfHKMQ--) {
            ZlWZpAw = ZlWZpAw;
        }
    }

    return voMSntAihsLMEuvh;
}

bool XdecyMHGN::mUnQeOds(double pMZwfpPdcNdwlro, bool LFTGzGYBeaFJ, double uBZLqkdOfHOZ, int HQcPhLHeid)
{
    int sRLAUjLYZBBIKeX = 1288935030;
    bool sEpHGSqYsZ = false;
    bool IqBhLmKpoG = true;
    string mKQIAxMXIEbjNfhn = string("CqKXjBOusnEsRyZXnZDjnLYKHThBrJRGUtkYKIHYKdajSyRvYYglwAmDhNHZTpycdVOcDAjZvRpuBsHzJyuXGbuIQibIBrUiAuzUDVfVLorjtcuIeXSTGUtAQehbWMNpcUetDQaeCBlEpTKkuwLMPruhgtvZdIRACUoXaFMjhgIwUOpV");
    int ZzUyt = -753720608;
    string duImCT = string("eVKQBD");
    bool hcIaLVKg = false;
    string iFztaO = string("bS");
    bool PWTkHEdy = false;
    int dqLlLcBA = 1247581648;

    for (int CzWvrLvaPmydmt = 1634327565; CzWvrLvaPmydmt > 0; CzWvrLvaPmydmt--) {
        continue;
    }

    return PWTkHEdy;
}

int XdecyMHGN::AwItwNmZxCsMlQyp(string vJsRVhBkeW, int VeiKZTtlJeB, string neHDzainrIvh)
{
    string uHUBftzzuko = string("DfUILEoKrjwViNDFyumSMVzXuvDSJfoXgrnMNlKfdEZyTDnaCMaaKdStiGRGWYVPytNnkblWVNOSnYRBLDpxrHkpmNSRRIaIAlFZIVZinazcAXHZYOHmFihUoCwgMeBHgOITpOGKOpVetvFHFuvwfUUDPXEbOePzcAkEMebNvJpRtMnRqlIqEZwwpvQDGMYWMlzGySfgtfHffIuTyisTpcXrWVwyJswsrQyzAZOijfZiCRHF");
    int ldJCf = -716465099;
    bool RQPyTeS = true;
    double wqkLXeSeISL = -388692.82433939795;
    double ouFwiY = -32604.782593681975;
    double RlTmllicZtQ = 252248.39181268602;

    return ldJCf;
}

double XdecyMHGN::zovRvyNaXvG(bool ijGhu, double QHShmkvkhZan, int bNkgkkIhNABOKZvb, double dyAcjYRNmwM)
{
    int CSeDamReGmW = -267099560;
    bool PBeeDvAB = false;
    bool ZXtFOEgrNpquoZQo = true;
    bool MAqAwvnFHwuwrb = false;
    bool UHlyvwqCLZJJN = true;
    bool wsPezsGrP = true;
    int OKUlXMYqHpPX = -1254579236;
    int zGXvOipMRA = 882860591;
    int saIOwnFz = -294310284;
    int wTaPlh = 1453569148;

    if (OKUlXMYqHpPX > -294310284) {
        for (int oBkEdYtfNc = 616626852; oBkEdYtfNc > 0; oBkEdYtfNc--) {
            wsPezsGrP = MAqAwvnFHwuwrb;
        }
    }

    for (int zDYVRHZOEmciJ = 1246042769; zDYVRHZOEmciJ > 0; zDYVRHZOEmciJ--) {
        MAqAwvnFHwuwrb = wsPezsGrP;
    }

    return dyAcjYRNmwM;
}

bool XdecyMHGN::NczPvfq(int XPnlbGXjwSm, bool vaOsFncxDL, bool nAAYXyerg, double KzTQlsyChWNXn)
{
    int jTuRoiAivT = -799887925;
    int IQSRdhwFx = 1964918768;
    double lruGqnbdy = 719015.6618560515;
    int SHBFWPETYCCATf = -1782435771;
    int uvebmR = -1409913553;
    double QxFxcibEFDc = 463166.4199150398;
    int flaUY = 1619898950;

    if (IQSRdhwFx > -265537773) {
        for (int kKlttrTrFiQk = 1160168206; kKlttrTrFiQk > 0; kKlttrTrFiQk--) {
            IQSRdhwFx -= jTuRoiAivT;
            QxFxcibEFDc += lruGqnbdy;
            uvebmR = XPnlbGXjwSm;
            SHBFWPETYCCATf += jTuRoiAivT;
        }
    }

    for (int LnlGKSdpCqZA = 309858686; LnlGKSdpCqZA > 0; LnlGKSdpCqZA--) {
        KzTQlsyChWNXn = QxFxcibEFDc;
        jTuRoiAivT /= jTuRoiAivT;
    }

    for (int sGwuvcbFy = 671614147; sGwuvcbFy > 0; sGwuvcbFy--) {
        vaOsFncxDL = ! vaOsFncxDL;
    }

    if (SHBFWPETYCCATf >= 1619898950) {
        for (int uWLHBMwpzRnzl = 1019784085; uWLHBMwpzRnzl > 0; uWLHBMwpzRnzl--) {
            KzTQlsyChWNXn = KzTQlsyChWNXn;
            SHBFWPETYCCATf += uvebmR;
        }
    }

    return nAAYXyerg;
}

bool XdecyMHGN::BaIteMrwNmAwmP(int pVvpZ)
{
    bool lUQug = false;
    bool MwhCVui = true;
    bool MuvEWmuy = true;
    double WvQLRRnlB = 1044118.0082781304;
    bool SEVXScBVGESU = true;
    string mHuRTYhYxfoVj = string("ZvDRzIVWpvNvgkCzRqOfOkvyebAmQxrynwvUTrSMcRyIAONuLTSKMtuiVJDgsWfjVGcNroFRABKQwDBodyjBPzkBpsEpMDRBnDoAQOVBhqrjwcpZsixSAyHJPzxriHQqOvCYeeYOHmbymmWhARUpkKmZOzRQfXdiasdqJdYXopAZiKGUezHVPHggTpNKsDTxHQcMPnJgXLkNieGTCfCMvBuGTnMWlZFUAJqJtFirJhtmsGXhDnu");
    string mPpVgQx = string("IogRpAAAMCfXlIcIPmTphDtgoQsTLbNURiSqVBWVFWhPpUjRMCxvvPgHAIuBGSHbqNO");
    int OstUPLvOqspx = 597387940;

    return SEVXScBVGESU;
}

bool XdecyMHGN::CZDgjeixv()
{
    double UuRCfxkfCEs = -38071.01501417539;
    double rPKuYgjuCFM = 45870.92532581995;
    bool YsEvffCJcEP = false;
    int cKSlwnpL = -1672683111;
    bool WejHfOu = false;
    int BktyVaVg = 634254885;
    string DzRsOB = string("CTnEOuHkxtcvHuFEqzYAuWFZlzonVzHEisgpAcEOUXOWCKCnBtWGFxJBXjkldAoZPPouIbCDqyrpRdxWNAGYHseRoGUsLZLmwzopmMymeEjkzlTOIIEKZJhzHlXQmsMjOnxQdAdDWfcrPOqQgBhbHJnliHmLCcIigYpXPqdKIKBFUwvKxsvVdHJoAzmiSaGgFLNvXZuEXtVdslGvyINUFhFOkAyuFcWtaFgz");

    for (int RALMXSwaNpUnnRHv = 863450149; RALMXSwaNpUnnRHv > 0; RALMXSwaNpUnnRHv--) {
        YsEvffCJcEP = YsEvffCJcEP;
    }

    for (int bfZHGX = 1035914527; bfZHGX > 0; bfZHGX--) {
        cKSlwnpL += BktyVaVg;
        DzRsOB = DzRsOB;
        WejHfOu = ! YsEvffCJcEP;
    }

    for (int WqNfg = 588231977; WqNfg > 0; WqNfg--) {
        YsEvffCJcEP = YsEvffCJcEP;
        cKSlwnpL -= cKSlwnpL;
    }

    return WejHfOu;
}

double XdecyMHGN::gKwJzNtUxDviefst()
{
    double snNVVcbAcibMXbn = -388785.34234235017;
    double cAtMUmGO = -740589.1873070197;
    bool kSuOKHH = false;
    int VfFhOkYN = -12731216;
    string TGlBJqPEUbGKz = string("areluFzGhgjmkLBoDH");
    double HhUZDuX = -530580.9686106122;
    double CLrzin = -793881.2894735882;

    if (snNVVcbAcibMXbn != -388785.34234235017) {
        for (int DydciaadvlUQ = 1067983921; DydciaadvlUQ > 0; DydciaadvlUQ--) {
            TGlBJqPEUbGKz = TGlBJqPEUbGKz;
        }
    }

    if (cAtMUmGO >= -530580.9686106122) {
        for (int TmEFwUEGNwk = 992394229; TmEFwUEGNwk > 0; TmEFwUEGNwk--) {
            HhUZDuX -= HhUZDuX;
            cAtMUmGO /= snNVVcbAcibMXbn;
            HhUZDuX += CLrzin;
            CLrzin += cAtMUmGO;
            HhUZDuX = cAtMUmGO;
            TGlBJqPEUbGKz = TGlBJqPEUbGKz;
        }
    }

    for (int OPcPFvQGBIuHEeEt = 575902029; OPcPFvQGBIuHEeEt > 0; OPcPFvQGBIuHEeEt--) {
        TGlBJqPEUbGKz = TGlBJqPEUbGKz;
    }

    return CLrzin;
}

void XdecyMHGN::LNnYxRmfthAut(string whhZYYCj, int kYlvsDVgD, string IviQPOfrlNylAOQ, double wDfrH, bool PykHm)
{
    double tRGjlWTW = -408298.16587273916;
    int cxjRfR = 430331354;
    int CCgQtnUsJUiO = -514521726;
    double AcbJTKMEiTWqbY = 195451.3119032038;
    string tJAnexHPuWSfU = string("ItjGwCNzempMlixHRFJgYvnRKIcvwtXjwsgQtqbULgsUhGDdDxryYzTGjqyRrAqLycGuBXPkhzLPXNZAfnrBlneOdRstyfREwyDDpffSIdrvqBEacMuoPqhWXRBkOBcypwbsQNOQuzZqYdYNTIZyExhiFTtiStfxWWUMiXXYQwRyWDXuAweb");

    for (int jsFOjVkEqTq = 1923095737; jsFOjVkEqTq > 0; jsFOjVkEqTq--) {
        tJAnexHPuWSfU = whhZYYCj;
        AcbJTKMEiTWqbY += tRGjlWTW;
    }

    for (int lNfxLSfTJA = 74612535; lNfxLSfTJA > 0; lNfxLSfTJA--) {
        wDfrH -= wDfrH;
    }

    for (int qSWTLtBCvv = 2070085034; qSWTLtBCvv > 0; qSWTLtBCvv--) {
        wDfrH /= tRGjlWTW;
    }

    for (int BlaqmUv = 1365709821; BlaqmUv > 0; BlaqmUv--) {
        AcbJTKMEiTWqbY *= tRGjlWTW;
        tJAnexHPuWSfU = tJAnexHPuWSfU;
    }

    if (AcbJTKMEiTWqbY == -161596.3408357442) {
        for (int tgsNKEFMafGcKn = 961626894; tgsNKEFMafGcKn > 0; tgsNKEFMafGcKn--) {
            continue;
        }
    }
}

XdecyMHGN::XdecyMHGN()
{
    this->HTkQPNAbpAM(string("JAzlhHwfqtKlRuOkLFFEvQPUfxvligozqTQSMxXdkkiRVnLiKgYFeCsfttxbUxKKMlmfjtUNfccuPPqesTgREJaSnEloURfvSEWteujcsKkcvWDqFkNPVDuqryEZdlGbezAmmyJArtRedX"), 148827.0932902636, 190107.5629923203);
    this->TZJzPOIMPabBDCUm(-56087175, string("oKRMljnUmLcOqGgZSclfoWemAGUCLmHwiegwOeERuKIobCdkzakMNMbbGqnADwIRoCGwPtqGEPpHjIhDEFXQTEwPLeNcpR"), false);
    this->xlWsMYXHLGQVrTn(string("MsKjWNkikbtWTOfiRHIvGpiwoTLZNiGNgMYLYyBjGYgWpjqSQUerlIZvsgonFkPxloJoDhYIWYRzWFPjkQngLueQBXBQtCzzNyCsVSzOXejliXomhzxdWbdxVjTlVlrWXGiSqTEeYCRztKErE"));
    this->VyqyeaeRxM(string("ZcCepXLIbIDWhZNRZYiYspybiVXrbewWTwXpOczLyqNVgrDWmfFHbAZuWRfrgvCouUTUhouXVEDHlRosmzcIuCYIBuLQmMqrmUMWYpaACSRGtUaOZ"), string("UTvIiemOmxeJmxlNHLHtMpFCIBpvdTElaRdFvEuDspdSYqxvYlgOIsKiyCouHtOCCmjvlHRiOmIOmblCiashlgSwVsaOBwEPvbBcpIpFkpohPqIVaMjzVeHQtoAoDNPeLdGTzXmXyBJNQbMBPKhfrnCdSsmmqUPaqnMaarcaLxdhU"));
    this->rBoZB(-559299.4192122521, string("EYcUkXpEYnYBASDLAeeeabDtmMwQCxcFBLTkGNUWwBViTjutuSwEOvTFXryuIp"), 429416.11255664064, 397881852, string("ulNjCSKYrBqTAjNNIuJjgNQFgOUHMpOmaFLFLLGqmDXYAfjlxiZJAXEDFFVHKBgffLTXNAtpEtvrKTRhAcTlmeiqMSuIplWRIqmVlyziss"));
    this->lFVBbG();
    this->ELcuuHQbDNXsyEMq(588416.1996199457);
    this->XdoktxCCkz(false, -682926.7234486593, string("YwJBdZpOrFzeJxUkFArTbwhdzxJtDwbNayeMruAHIawkDwCztiLxfMlTXYTpUwZabKeonZqQrNxFjlkKSsdToCbdjFXPBqAkCOIsaxhYXnuKnuJNLCTJEKdiUrPzBDjpWOHufsmlGvCgGqXKXrORBDindaJZueEQHynLWrNEflmmWLDtjWZZGdKYqNGkdXpOfzviOYh"), false, string("wwvFFeloyaGmAYErtflUEOSiDQZhUlQVuNcbkLHWqiqLYbiABkytRGNqXAotxeeqPjLrCjmXsPGBQXiLaOsOZTQLFkpjCPewFQGjfiYbgwrEygnQlinRDFGUvLwOrYMgvRhBGcESMMqxBVVwLrnLsARaawJtraTpJqNnwLztunzJrthFozzkLSPIIYeTTXgv"));
    this->mgFHz(true, -331355.0927610947, -329654.5100439386);
    this->LLQrpyt(-495548.5849728, false);
    this->mUnQeOds(179166.60732459894, true, 731090.0869062864, 486266354);
    this->AwItwNmZxCsMlQyp(string("IMAjePZFDbjIOvTmkadpvXQIFcCIhrbPuxoaiSJiKnbUYLAxSWbQWWRF"), -1097448422, string("gqZZVoCXbPvpgAKnllUlNagfEKKxigneXhWkEDIEfTvjioKRnYwxvDVaxTPMnLxgvMcQolpVrBTTbgEoOjsSWRIzwnwESxxuHwbsKYubXNYbHkFxEcwamgrUhHUdbTZTXwFNaAnljTPWf"));
    this->zovRvyNaXvG(true, 172383.61574364206, -1255554518, -636713.6617049426);
    this->NczPvfq(-265537773, true, false, 127102.96915319383);
    this->BaIteMrwNmAwmP(2008624719);
    this->CZDgjeixv();
    this->gKwJzNtUxDviefst();
    this->LNnYxRmfthAut(string("SJNpaCWWFJhjcJsxViWjrdVRGHvKUlltJesvuFGhcFqKOOjnRXJYsqMzPCOEGnWWlzjdjyIyFWwWLGfCXndaNWZSCyZNMFNxAaGRZTYuTNPNRbSfCiJETPGvMflIZJHBvWUdLvYdBpbSVNOVRZJGjcPbBnXZJUsR"), 1570011837, string("zhXbSonddlJSctlltrEkhCppgwQdFHVQWwyLmHWQOeGvoeYzJTHavMBUbiYTDKjksWmluEWgCdaSmrSSPsygvkoLQXAcuVbbHaSQjkGvJqDwBpGwvoKvTwTJbBEFXgMxUoylzhfeRkeaJtYOsCUILjPnHuEJOSWSUARZGHDLBTSoVNKTlyqqkcBzTWSOwCRMKbwDzyncVpIkKNYZc"), -161596.3408357442, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nvbQQrtuXwFDEX
{
public:
    string MpqelxwI;
    int IUKUN;
    bool iHpbhk;
    bool uyAcCyhdL;
    bool vIIEGC;

    nvbQQrtuXwFDEX();
    string CkqrpUn();
    void JzgDRfYfh(double mMjHQiJh);
    void igBFKttHeMldTxPp(double PojQZHaJK, int viWySuOkXKo);
    string RzTcgmS(int ASdIvT, bool NyfjAIJWsE, string XYXniaUwKVZ, int HEkkQPbqG, string rKWhicDnrfsODvQ);
    string gdRqBlMFr(double ncjva, string IDPUIB, bool cpFvTpjdoLzRH, bool LYlgbnAyrs, double VzpYCIcNCQ);
protected:
    string rbgNJI;
    bool MiYZMrXkuZBJp;
    string vgmBePeGJQXPRaG;
    int ytOxttGaVFBrdg;
    int FnwWN;
    string snxcjFWWd;

    string NjAbmyDBUjapQ(string KCSMYB, double iVkgMjZySBwomdv, double CyyAIeWWXPoC);
    int MhWRDWpbFTLDETr(string cvUmuDm, double yigez, string MKkQIdUowh, double mGCUyKc);
    void aYescxX(string OwBUqFcZmuK, double yfFxRRoCT, int IcRsedDGedJjk);
    void Betab();
    double HFViAcH(int jsobSFeit);
private:
    int SJMbySkiDu;
    int XxSpSOgul;

    int yOdYqZIvb(string beEdP, string sDpsFIOj, string LChIQQpUQj);
};

string nvbQQrtuXwFDEX::CkqrpUn()
{
    int WzWqb = -1581098176;

    return string("SWBGdJCRIqlzeLCQYxzHmjNVopGpKlxQCeumykIUlRFeDFAGncPREMqMnQoFjtcKBTmwzdMdoObgIyrHEJEtHtwPfdmXVGWVuyipGLibXMErsWaRiazaOUrIkCXWLEiYNgMrWqaJRZtYgVyLeyYahrIDiAYVeJlLonuDRvIikwWIAaDvDNhHvIXldcweDfCKGnyWEIQg");
}

void nvbQQrtuXwFDEX::JzgDRfYfh(double mMjHQiJh)
{
    int QfrdcdiEGad = -1140001086;

    if (QfrdcdiEGad != -1140001086) {
        for (int MqPuOdo = 1786583366; MqPuOdo > 0; MqPuOdo--) {
            mMjHQiJh = mMjHQiJh;
            mMjHQiJh = mMjHQiJh;
            mMjHQiJh *= mMjHQiJh;
        }
    }

    if (QfrdcdiEGad > -1140001086) {
        for (int mEIietjC = 1731925565; mEIietjC > 0; mEIietjC--) {
            QfrdcdiEGad += QfrdcdiEGad;
            QfrdcdiEGad /= QfrdcdiEGad;
        }
    }

    for (int YmmGcqzYPdBwNCu = 1993631941; YmmGcqzYPdBwNCu > 0; YmmGcqzYPdBwNCu--) {
        QfrdcdiEGad *= QfrdcdiEGad;
        mMjHQiJh /= mMjHQiJh;
        mMjHQiJh /= mMjHQiJh;
        mMjHQiJh /= mMjHQiJh;
        mMjHQiJh -= mMjHQiJh;
    }

    if (mMjHQiJh > -969469.5618223601) {
        for (int aTgypRORWzLNQou = 1828362860; aTgypRORWzLNQou > 0; aTgypRORWzLNQou--) {
            mMjHQiJh *= mMjHQiJh;
            mMjHQiJh -= mMjHQiJh;
        }
    }

    if (mMjHQiJh > -969469.5618223601) {
        for (int kOsNrSizeazWGIKo = 561253247; kOsNrSizeazWGIKo > 0; kOsNrSizeazWGIKo--) {
            QfrdcdiEGad = QfrdcdiEGad;
            mMjHQiJh = mMjHQiJh;
        }
    }

    if (QfrdcdiEGad <= -1140001086) {
        for (int VaWii = 1277829519; VaWii > 0; VaWii--) {
            QfrdcdiEGad /= QfrdcdiEGad;
        }
    }
}

void nvbQQrtuXwFDEX::igBFKttHeMldTxPp(double PojQZHaJK, int viWySuOkXKo)
{
    bool Alczj = false;
    int dbDUaBJRCDK = -548602320;
    double DJHLMOicVCBtELpv = -488056.5063375852;
    double LtftPGvaLtldLXIp = -726487.3973245912;
    bool SEGlwhgU = false;
    string BVxvhTABGt = string("uHZTCwktmbXQEMRWhRhooQgOhhlYmELlcLwbOxiiwGRjrBOLckLcDuKnKOkGOwFaZEhecUxxjNqmvYvDdeIcqMNUcphtfvjJObHCIXgElgZAUNKykfVflIyvCHLiKIFWGbpiMRjDlOvKkdnliELDZvSCMHgGylgckJPGcwThfUbnqHyixkCglLKRDxptazlzyKhBGBraorbPMgGQmEs");
    bool JNXdEdniml = false;
    bool zjqTXMVTdj = true;
    int tgSQnYPVrpimy = 378374113;

    for (int WoCJCbFZGpKL = 895054585; WoCJCbFZGpKL > 0; WoCJCbFZGpKL--) {
        BVxvhTABGt += BVxvhTABGt;
    }
}

string nvbQQrtuXwFDEX::RzTcgmS(int ASdIvT, bool NyfjAIJWsE, string XYXniaUwKVZ, int HEkkQPbqG, string rKWhicDnrfsODvQ)
{
    bool GLaUghtNq = true;

    for (int jqdSi = 161473195; jqdSi > 0; jqdSi--) {
        NyfjAIJWsE = GLaUghtNq;
        GLaUghtNq = ! GLaUghtNq;
    }

    for (int DHDQEV = 1107251636; DHDQEV > 0; DHDQEV--) {
        GLaUghtNq = NyfjAIJWsE;
    }

    for (int jtAMkLGNj = 1745090723; jtAMkLGNj > 0; jtAMkLGNj--) {
        NyfjAIJWsE = ! NyfjAIJWsE;
        rKWhicDnrfsODvQ += XYXniaUwKVZ;
    }

    return rKWhicDnrfsODvQ;
}

string nvbQQrtuXwFDEX::gdRqBlMFr(double ncjva, string IDPUIB, bool cpFvTpjdoLzRH, bool LYlgbnAyrs, double VzpYCIcNCQ)
{
    int jmcOxq = 26496562;
    string TltIAGAF = string("xYHnqwDbxvUeoXufTAxVlqCjjxLePPFQGiiqexkkEwGCSDmEYYGnrnnmKYcgQTRWCsyYRlreSDYGHumbUgDyWvwSIwFgmXeRzRmIrtrozUtElnlsDorelhavZouaVMbETxCaZqe");

    for (int orJQULqCnVzP = 921681455; orJQULqCnVzP > 0; orJQULqCnVzP--) {
        ncjva /= ncjva;
    }

    if (LYlgbnAyrs != true) {
        for (int sHVFhNoLFfYozj = 1806795751; sHVFhNoLFfYozj > 0; sHVFhNoLFfYozj--) {
            cpFvTpjdoLzRH = cpFvTpjdoLzRH;
        }
    }

    for (int afXaNvPp = 732054763; afXaNvPp > 0; afXaNvPp--) {
        VzpYCIcNCQ /= VzpYCIcNCQ;
        ncjva -= ncjva;
    }

    for (int pmdPaANsIkqzhe = 1462336823; pmdPaANsIkqzhe > 0; pmdPaANsIkqzhe--) {
        LYlgbnAyrs = LYlgbnAyrs;
    }

    return TltIAGAF;
}

string nvbQQrtuXwFDEX::NjAbmyDBUjapQ(string KCSMYB, double iVkgMjZySBwomdv, double CyyAIeWWXPoC)
{
    string pbKxnp = string("unDkJoKbTvFjMVOhtpAuxUXMTePkFPoSjkTqbNbvFXYrIMfRpkljqdhGtLPjZAZqtRgZzzBltohNBGixDzyppngbFyvGuhUjJryfJKjlnoATDRjkWYBnDjDraDsUksquvxckBfAOJYAKwMcJyNmFgUsFxGUPZKGqBXXpcRRFZMzCiLMadSBpUudDaVJYjHKFDqosfxsNZAJCHRFFmipZImQEaihPnKYNjlKzErYIlnrmISUCQiTfxPAueCzsUnz");
    int zwMuouKE = -1550512011;
    bool aDWrlwCNCXobo = true;
    string YCNbIfmcGpEB = string("IHuaNqaSdLZagokDUMFQPUxcMRrdncPlRySgiCnMIGyMNzijzVdcXkecqDm");
    bool yEGgWWrpfLyZdlK = true;
    int sDBEAiJt = -1559011914;
    string YSBbJ = string("JZonbxGVoMLt");
    double cxjacg = -487982.5616949277;

    for (int XfqmOWUOoxj = 1050551177; XfqmOWUOoxj > 0; XfqmOWUOoxj--) {
        YSBbJ += YSBbJ;
        pbKxnp += KCSMYB;
    }

    return YSBbJ;
}

int nvbQQrtuXwFDEX::MhWRDWpbFTLDETr(string cvUmuDm, double yigez, string MKkQIdUowh, double mGCUyKc)
{
    string wTehWNULApd = string("phYYzimpKCdRSxeRLTQTstjluVQjETTNAlmOtek");
    double ifdFBIKpP = -162529.6574856503;
    string ggJafLLNELa = string("owBmOdppyoOWUVDl");

    return -1470771267;
}

void nvbQQrtuXwFDEX::aYescxX(string OwBUqFcZmuK, double yfFxRRoCT, int IcRsedDGedJjk)
{
    double xCopgWvXXJQx = -718045.829338624;
    bool zdvZqOM = true;
    bool HzoXFV = true;
    string EbZLfgzeaVIdFCCh = string("SHUoJjZXYvoLvkhvOIOxdVuJTgxqaXsgEZWGgTqlKIqrnndNeFySosWMmmPAKkcAJRTfgXtRgqbTxqnIJNhJdHsMsCMWqLeSIhnUvpfTQNNfhdbR");
    string dCrZkKUGaVefnhZ = string("LWfFtKsBnVyLDxaqpoBQIHkroPaVDxXmdIcuWYUAQGNqCVoR");
    double fExzvt = -711103.4590262113;
    double GLgROmQFbpXu = 455231.1730055459;
    bool fPSQDZ = false;
    bool aaLqFwJuDzd = true;
    bool kiEiF = false;

    for (int sxhJNvJpUhCsJb = 1732366320; sxhJNvJpUhCsJb > 0; sxhJNvJpUhCsJb--) {
        aaLqFwJuDzd = kiEiF;
    }

    for (int ZexEN = 1911171662; ZexEN > 0; ZexEN--) {
        continue;
    }

    for (int CPvJJfIHsEjpP = 1287930760; CPvJJfIHsEjpP > 0; CPvJJfIHsEjpP--) {
        dCrZkKUGaVefnhZ += OwBUqFcZmuK;
    }

    if (yfFxRRoCT > 455231.1730055459) {
        for (int csMdMftXvx = 374589623; csMdMftXvx > 0; csMdMftXvx--) {
            GLgROmQFbpXu += GLgROmQFbpXu;
        }
    }
}

void nvbQQrtuXwFDEX::Betab()
{
    double sQmTtkS = 444757.2009829484;
    bool MqgLdjWMpfJ = false;
    string qDAhYmoTB = string("sayLprSoFUjPasWTExjuNGZCHuHkqCkWuGLQomdhZd");
    bool ViwCxCKrL = false;
    double CMqfhvf = -866158.534013437;
    string SDZkqESlwWXOw = string("bqcflOxEcoUmoidGEUHXYGGmsmMsIQfyabBDjrvzzUXnBZiAvptxcpRwMFsibkWBwcIDU");
    int ksucMXD = -684109458;

    for (int yHpqzJPlxmzFOh = 1962018959; yHpqzJPlxmzFOh > 0; yHpqzJPlxmzFOh--) {
        ksucMXD = ksucMXD;
        sQmTtkS = CMqfhvf;
    }

    for (int MuLHsxrs = 540708611; MuLHsxrs > 0; MuLHsxrs--) {
        SDZkqESlwWXOw += qDAhYmoTB;
        sQmTtkS = CMqfhvf;
        MqgLdjWMpfJ = ! MqgLdjWMpfJ;
    }
}

double nvbQQrtuXwFDEX::HFViAcH(int jsobSFeit)
{
    bool eVXCpkvaqpwW = false;
    int QLVzuRymLhiFiG = -1285626713;
    string gTIyXxfkgXjbsI = string("HvIyEgjQPFclAkRiHUMkhAJxRxwRKTaGmeGIfWftaZXCnQSLjzfrFPfZaEkxWodIYjzuYkGwvNUEmFdMMLh");
    string jpjjYk = string("afYjTHKQHVYdwUAMOBzvPvetexHNaMODby");
    int FBTWGrOVocxzaAjk = -356786882;
    string PjzxWomiqn = string("ESbRvQjKBiWZScHhuZvKmTCCnssfjvPuHvJiFjygDejuTPOOzDYuHBdupqUoAnHYTEfJSnpIDykGquXwPNLGLHCGJvOVFuHoLacgNmzSSmPnUrFlVQATXwzadWAKMVTmnjrgMqHEBmXjnWljCyToraMfTUKBXalmUOzDEEvgLuc");
    double YewMyCsprUrOA = -1019469.9642636452;
    bool cJRoXjluK = false;
    bool XzBhUxFiJH = false;
    double ebRMkWzdgNKIKv = 763034.2525276432;

    for (int pveggWsIIepHHH = 1391723368; pveggWsIIepHHH > 0; pveggWsIIepHHH--) {
        continue;
    }

    if (ebRMkWzdgNKIKv < -1019469.9642636452) {
        for (int tHoSNyezGQs = 89494985; tHoSNyezGQs > 0; tHoSNyezGQs--) {
            jsobSFeit = jsobSFeit;
            eVXCpkvaqpwW = XzBhUxFiJH;
        }
    }

    return ebRMkWzdgNKIKv;
}

int nvbQQrtuXwFDEX::yOdYqZIvb(string beEdP, string sDpsFIOj, string LChIQQpUQj)
{
    double jdQwDcdUpEE = 246534.31272762158;
    bool rmdfaNYUUtb = true;
    string lNUpaiv = string("ReNODJorjHmMlzrBvyDYBKvqYoWHHNACmqvMMvucdnBkhjMvcFanXSnJXQfqusexPnjDmTKbLeBdpjikFHHRZGSHJvFTCmMwHpupdwPrfoyaOhV");
    bool JJqKFxshAEcr = false;
    int bHMlJPkfTdUdcCQ = -103506190;
    string iuLOQylTw = string("wNzsCfjfGDmqMWROXyC");
    int mnAtDcOM = -1795188399;
    double oDRFcEoNiwBJLWG = 154182.93927066715;
    bool psebKMGZrJnJiCw = true;

    for (int tVjplhQ = 1363900917; tVjplhQ > 0; tVjplhQ--) {
        rmdfaNYUUtb = ! rmdfaNYUUtb;
        beEdP = LChIQQpUQj;
        beEdP += lNUpaiv;
        lNUpaiv = iuLOQylTw;
    }

    for (int zOqxlXlmcqqEj = 568651745; zOqxlXlmcqqEj > 0; zOqxlXlmcqqEj--) {
        psebKMGZrJnJiCw = psebKMGZrJnJiCw;
    }

    return mnAtDcOM;
}

nvbQQrtuXwFDEX::nvbQQrtuXwFDEX()
{
    this->CkqrpUn();
    this->JzgDRfYfh(-969469.5618223601);
    this->igBFKttHeMldTxPp(935525.5972107488, -702349684);
    this->RzTcgmS(-2036626101, true, string("oNCgHNBAAxCJGDWmGOVEWTugSFBXbEyFTCrIQkLDOKDAQKqDotFBkRRLoXJPusGWiVvYVlGIAeOUbXjtAEmecizWMNlqNMIcpPgCFnbqwStzEvXkaoSBOJEcSBtlCEHvAGYsKZDHHSdlljZzdGJgCLDGWfylJyUBfryKjxEjGGfrJYtIkcGGdAYV"), 1434901157, string("YVSxCMCWvuWhKtktwEdgOJ"));
    this->gdRqBlMFr(523937.0115394355, string("UmSKlmVImHGfIKhqhpYShwnAmDCaCtcmRcLmoQhtpvqavWhlWRScbTEsYYsGrbomftnZlcKVlXLChBaZCmQiJDbpctNZUIaauexVPuaHnHfyUChuDfmDIXvyutRGzlnSwHHNeAPCmAtjRPAeCnfTdlVlhlzUxJgPxORTTekUGlDqOAnhRMCcXghHWccuI"), true, false, -363142.98070890305);
    this->NjAbmyDBUjapQ(string("jlUFPyvnOcUYJyBzvqqATSllADbprfTVMXQHhbLUNYRnijURvvvCYbsRQFjSPXBjejokYTIPjZAYxYWSBbfOkQkTWpMhjzYKMTXuiyKqpdAbBapnvBxCIvKFeelxGlCZDhNUdjXYSKDxaadBqkqz"), -57595.30465202197, 336861.78213962476);
    this->MhWRDWpbFTLDETr(string("apVmvDwZvkWOnHojeUiSwRJKkDpegnvJBPJIsYdIgMqdYldz"), 555291.5839554803, string("JFelYPxmXVXiAwSntMCpuHsEFkxntjqxdSEJDMibnCeVFFMyXECStWLPgxsZPztDsusmTsnfteFimbqmSbSXvzATbjNvSJpEwtLirfQDcWGjGlRCeYsWw"), 449259.1414986845);
    this->aYescxX(string("MkvpzmBVbGfBeVEmAogkMestMEjaMkgpmWrkLlTwjDLvWkPdprALOPDneNhRwdnoVbOGgbOeJesmxzVWGVWnxVrMeHWKoIygAQOrWCQSeSDqWhXMayjcMYItXQVktrwRUeDKHuXvlefwnw"), 550130.6041075543, -614319383);
    this->Betab();
    this->HFViAcH(-2135717730);
    this->yOdYqZIvb(string("lpeUVLZYauJvBbVDGSWtLThSmzUScCSfavjlbzNYRKXq"), string("PCiurutUsCLYfHUncBOJjoSAtKDSDBbTMtAVjjPimqBiXrlFwPZdEoBbrkxvOcRavrjoeejlDSvhCBUvVyuqISHoqsdHaQvzBPMHPMOMAWheiizfmjqqziTbdNXBsocFzAuoVEiPzwzbzyToMuXpHzogbEhoqGtPIvpMRyLjKLnvzbAUicVfpGsvzqvqqtZfbVwqvKVWdXlXERWpgsxR"), string("aU"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fHtzeYwQc
{
public:
    int GUfaVuHcHYzg;
    int AlxpiYRdHwqkLB;
    string VBZWPXlKwdGUrL;

    fHtzeYwQc();
    string dUdACWDlP(int jMybe, bool SYxIIQzXyno, int OWugMjxEMWHQvFTd, bool oldzP);
protected:
    int lrpdaq;
    bool KzGUeQNIsp;
    int OrnVNLDp;

    void jNsXJorA(double PdsLrSuJ, string yUgVceMrvgHK, string dbCGRahWb, string EDRwrkNGt);
private:
    string BvOGbT;
    bool rHqkXjQDgTNNPq;
    double jXQHRaIWJEwbc;

    double AtBknQZxre(double pevZnQhXfgutTla, double jCTpFmeK, double tvgPfAr, int XgvsZKxzoE);
    double lzkcnOgEvmrgFxtX();
};

string fHtzeYwQc::dUdACWDlP(int jMybe, bool SYxIIQzXyno, int OWugMjxEMWHQvFTd, bool oldzP)
{
    double inpIcnY = 220961.43321588085;

    for (int SUDJSthLIJcwsj = 1426325673; SUDJSthLIJcwsj > 0; SUDJSthLIJcwsj--) {
        jMybe += jMybe;
        jMybe /= OWugMjxEMWHQvFTd;
    }

    for (int vBmeoCEdgW = 1802264834; vBmeoCEdgW > 0; vBmeoCEdgW--) {
        oldzP = ! SYxIIQzXyno;
        SYxIIQzXyno = oldzP;
        OWugMjxEMWHQvFTd /= jMybe;
        jMybe /= jMybe;
        oldzP = SYxIIQzXyno;
    }

    for (int YQNWDFCNIoGOkScq = 351973068; YQNWDFCNIoGOkScq > 0; YQNWDFCNIoGOkScq--) {
        SYxIIQzXyno = ! SYxIIQzXyno;
        OWugMjxEMWHQvFTd *= jMybe;
        oldzP = ! oldzP;
    }

    for (int PnemykweJD = 1722935340; PnemykweJD > 0; PnemykweJD--) {
        jMybe -= OWugMjxEMWHQvFTd;
        OWugMjxEMWHQvFTd /= OWugMjxEMWHQvFTd;
        inpIcnY -= inpIcnY;
        oldzP = ! SYxIIQzXyno;
    }

    return string("rwPQjfxkEKuOwlFbZWyhbCNHDZxpgmYFAWxZYlBpOkgPxNATODoZElemffIGocXOnScNVbfcFOxpgwLraGeWjtHlgpdfdLKGAKpjmTLQBKkvgvPVcQdgwuIVRdV");
}

void fHtzeYwQc::jNsXJorA(double PdsLrSuJ, string yUgVceMrvgHK, string dbCGRahWb, string EDRwrkNGt)
{
    string aKciiqzumWuuMWQp = string("LpWdVDdoowUHFloUirdiXUVJVOSFSmDNyYPXnqzsEpkgebkoZQcazpgrokIjpIlMVVKwsgQMJvhyiMlSBHPLZOldRRahhtL");
    int iAWTUREAOvl = 947500555;
    string FtLvxvdlKC = string("MVozGJaMDVBJIBtAclCcnbiAEHvHkWuTMMZGJnWIVFItEmgwBdvAnAoSSwXYWAauekmXyZCtJvtYkBGACBTglJqGibsooplBVAxOtbxSaAKqBofmmeDUZcCPcdZTHFOsfucJpOLuQiteiTJKYnIzDjaYLFQITdWvjQEjyanMARZzeEYEXTnHOVpktHXiDkKzhZwVsPLepNhGHvwCLetSqgjuopsalEwx");
    bool wCNVupNQgmp = true;
    double HNvPvnjYbWIHt = -598989.2947606974;
    string FnhPuTPKaEGt = string("nwYqhLrcToJKcwxSjXecnCxRJDIBtDcfSadNRGwKRurqtgWIylemCurW");
    string mtGAGhDgZrVwHCu = string("ytmHxQVugHaFFNrZsIAOpkiqUgYityXIHZoDcynwOHWjbWHpznRKnaaRgFZoHBnCPyCGscOCUiMAiOHcZkIKzLNTDAQALPCJDgLZYfVOGyqDInhNidafocjIWOGtzJjowBauHLtCIySHbHjnbxwpayTZD");
    bool SQbWbIXyqGDYC = false;
    int RpPPkqeMFFKHBJ = 694359079;

    for (int JURjNV = 692230874; JURjNV > 0; JURjNV--) {
        yUgVceMrvgHK += mtGAGhDgZrVwHCu;
        iAWTUREAOvl /= iAWTUREAOvl;
    }

    if (EDRwrkNGt != string("UgfUZKPYpuCWhowzx")) {
        for (int ssxQAEyojlb = 1849396237; ssxQAEyojlb > 0; ssxQAEyojlb--) {
            FnhPuTPKaEGt = aKciiqzumWuuMWQp;
            FnhPuTPKaEGt = FnhPuTPKaEGt;
        }
    }

    if (dbCGRahWb == string("MVozGJaMDVBJIBtAclCcnbiAEHvHkWuTMMZGJnWIVFItEmgwBdvAnAoSSwXYWAauekmXyZCtJvtYkBGACBTglJqGibsooplBVAxOtbxSaAKqBofmmeDUZcCPcdZTHFOsfucJpOLuQiteiTJKYnIzDjaYLFQITdWvjQEjyanMARZzeEYEXTnHOVpktHXiDkKzhZwVsPLepNhGHvwCLetSqgjuopsalEwx")) {
        for (int mkCfZA = 1344500266; mkCfZA > 0; mkCfZA--) {
            aKciiqzumWuuMWQp = dbCGRahWb;
            wCNVupNQgmp = ! SQbWbIXyqGDYC;
            PdsLrSuJ += PdsLrSuJ;
        }
    }

    if (EDRwrkNGt != string("UgfUZKPYpuCWhowzx")) {
        for (int ZmaKQVNjCKJYJaGX = 1836868822; ZmaKQVNjCKJYJaGX > 0; ZmaKQVNjCKJYJaGX--) {
            dbCGRahWb = EDRwrkNGt;
            RpPPkqeMFFKHBJ = RpPPkqeMFFKHBJ;
        }
    }
}

double fHtzeYwQc::AtBknQZxre(double pevZnQhXfgutTla, double jCTpFmeK, double tvgPfAr, int XgvsZKxzoE)
{
    int hgNDzVvnUrjA = 545942784;
    int pIqEYM = 799041752;
    double MliWOfNT = -90720.2320518278;
    int CyIwPBaXalZppKhW = 1808555095;
    bool aYfhwgvzWIG = true;
    int BEGIiSj = 265598118;

    for (int IuPoOWQaWq = 906757855; IuPoOWQaWq > 0; IuPoOWQaWq--) {
        XgvsZKxzoE *= hgNDzVvnUrjA;
        pIqEYM += BEGIiSj;
        XgvsZKxzoE /= CyIwPBaXalZppKhW;
    }

    return MliWOfNT;
}

double fHtzeYwQc::lzkcnOgEvmrgFxtX()
{
    bool hUEnxL = false;
    bool YHRhPZpZXED = false;
    string WgxJRZ = string("BGnruXjsfiIlQeBetHytKxnyHtsqZAzjWJUFVyFQSscnArMVlig");
    double tbHKxLJZCk = -814991.1513597218;
    int JLEtaXjCS = -1663803343;
    int muqpMqlxFk = -784340082;

    return tbHKxLJZCk;
}

fHtzeYwQc::fHtzeYwQc()
{
    this->dUdACWDlP(-1121734762, true, 1141283251, true);
    this->jNsXJorA(-800220.1852307955, string("UgfUZKPYpuCWhowzx"), string("zpsVKClxtFPaokondpYAYdMUpRgDACDkMJxuEjmQiPhLRXaVYmsoVArAAWwwUiNfHHfLzrZnxhozNSavOmzMPFGryZxcajHXPFNivxhTdpokKwyQCUnWNMRmMUvyHrTSiHhqtguhuyWDuUBUrdHUsjZaijTmHIoUy"), string("ISKlPvfbKFXIkqGDokWpSVLOvXUvCazWXBOjZakkEsqMEErwUlABjCkUQZeLVNjQilRZmHfxvDGZyfbCLAIPLUtzziLaYPnArJYcDDReoxDMxDwCpJCyVNxwnliHYEuMRWDUbEzaXkkPfYbObtQkSNfYDmevoIOrnjq"));
    this->AtBknQZxre(-437338.1878349431, 970617.8299248954, 601306.3126156761, -124910811);
    this->lzkcnOgEvmrgFxtX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WiEYeUqAlsXzt
{
public:
    int zlXyCoOBFUvPui;
    bool VwdJDfotPMVWF;
    bool oBCyoWbgQSsRM;
    string hbJknGNrxi;
    double CZHECkAjcZy;
    int IyDwnf;

    WiEYeUqAlsXzt();
    void IRNehjq(bool BORKF, string afFfcqwxXAw);
    int RNaTnRCF();
    double MpZbyYmMozeiE();
    bool sDcQGkaowhvgjh();
    void GvusZMaVhEVpP(bool QUxAEiAzE, bool nThyK, int SzDCSDRXcdZH, bool UdJdDsJBmPyu, bool mxjMiJOsdRJ);
    string sYXXRHi(string IzQsGCTnMDuwCEd, double LeeWcicxXib, int oEyxuVMoaUSr, double jaqCsOoBDu);
protected:
    string AhuxiuFnDMY;
    bool KtaAPfdFELxgJVOG;
    string aRcORiRdIunt;

    double GGeLB(double SYeSZSgc);
    void NYzNPWYJFViAtUX(bool baSVMoYCHa);
    int FxAeTNBzOklDrsU(string gfoHCgq);
    int kfTWJdNfPW(int ybtXVdWWc, double gZXHiSQYsVDVzk, double RvPiAG, bool xCouOdiLrAyi);
    string UYbqIedUAFzJ();
    string HlyBvAu(double mnhNvQtuqOON, double LHwahHDfTuZS);
    double KjfTWoaINX(double eASen, string xCSyLtfZibdImsN, string XliOmsepEcBG, double dHbkRUheMl, double fMCvMBmXxHbxL);
    bool NpcPppE(double nJKPDc, bool dLVIFztAGKvChUR, double ypUVuw, string xkLvGTcZC, string YNakOpFkmuCRTx);
private:
    string Qpqtn;
    bool EUypojhlDGZQhNi;
    int JcfbpXA;

    int MehYnvlFOKTVUz(bool GmzxJKTyVBQeXnE, double BqxhcPjHxwm, double kSFvYrtnbtEB);
    bool XhdCUQjxbkiHLBr(string NWNDH, double okNAAiRYijXAixzd, int BWLOzbLotWnLo, bool qgAlGPMrhDKTUrYf);
    int qLbESxoTWZDP(int wQwZHGcnj, int JuARtnUqbXFDgt, string xlDomqVhtf);
    bool mddqcjoRaq(bool MpHyVFQGgml, string MECFCvg, bool AWUBbO, int oERgj);
    string bnphscxuLLf(string saXXRdMHiebqFLq, int mAsZbhfUbtUThX);
    bool VpvcwhbxRvQ(bool nTqPHlKairCokh, string gOwLO, double OBcAmlASto, string iPVBxFxAlVUn, double omISlEDt);
    void TKxyTtFFhNcA();
};

void WiEYeUqAlsXzt::IRNehjq(bool BORKF, string afFfcqwxXAw)
{
    string xkUDVdd = string("oFsVUEJXJXnEhMFXiIiXngCMcFyzIgHhUoNlFckzJdnzOTopVOUZfVmqQIlntdfYSvYwkLRFGPdnbSmCxjgrZruWHbapRLNQUuLTCCDqoJAHTpwdNxsvklKxTRDMkdAjZGezzNHXl");
    bool sRuEFlmqvMsdsroN = false;
    bool HflIKmBXtKB = true;
    string fqwkVhlE = string("ACBmfHIWDFcPWXtFOTCjLOGoOqeziHXHQjLGXsoqaLPnjxPSkWOdGOqNKrzJJBzPzWHhttVSPocveaICunRVUnnGzxSUWPAfrYvWyLceUosZNlrYsBXnCIcIuOFunooRMDmVMUelkVOnCclEiVMatstjPhirhbCdayhVEGlYwXoItByqBVsPxytegMjWkAGcCYfVWogGH");
    string IpShKbCjfGMbUAj = string("SfkXgttUvcoErFPgnSiydmAErflwxaTQxNInuUkLZxeWXvOtQgGupiGznnxpzeNzfCsKvTuZkQNjfLhcmWUscXPAGiHrwWxzSXWxYDmilzbZEttNXrQtvkTZhPuaKbqnTjHOCKbcLRgEpwpWJtCXbadVZOOdYUexQABYNDyQTBcDJDOpADNTuaMgHYyLMLgXXTIOtRFelETKgulygPaDGvWUtJalmSFsLfhDtyyocY");
    bool vsqkrhgeBW = true;
    int QWQiHvMQjNckqS = -1883023669;
    double TqkqurYklFyzqo = 385069.1752889525;
    string ZeMSCRgEeIz = string("CNcrsAqANSWwLoNFCEPhQZZPfFcweLVaDAsODfAcjceEmDGvRJgyDsiMEkwqaecDxXEORuIoZNATkpDGKlIvmfgxsuxhHCNdXETeaLiGOouiUZcIGyImTXyNhzAI");

    if (vsqkrhgeBW != true) {
        for (int hJUTfbGVOUND = 160939024; hJUTfbGVOUND > 0; hJUTfbGVOUND--) {
            BORKF = ! BORKF;
            HflIKmBXtKB = BORKF;
            ZeMSCRgEeIz = IpShKbCjfGMbUAj;
            fqwkVhlE = xkUDVdd;
        }
    }

    for (int KFCIjs = 1880399302; KFCIjs > 0; KFCIjs--) {
        fqwkVhlE = fqwkVhlE;
        vsqkrhgeBW = sRuEFlmqvMsdsroN;
        sRuEFlmqvMsdsroN = ! BORKF;
        xkUDVdd = fqwkVhlE;
    }

    for (int niiklCRiF = 684971424; niiklCRiF > 0; niiklCRiF--) {
        afFfcqwxXAw = xkUDVdd;
    }

    for (int MCnMcPIteACZ = 1596937236; MCnMcPIteACZ > 0; MCnMcPIteACZ--) {
        continue;
    }
}

int WiEYeUqAlsXzt::RNaTnRCF()
{
    int smfpDmyHCf = 1116636278;
    double ByipsfOlxd = -873851.8366058781;
    bool wRNubPBtDHEXunKE = false;

    for (int VdmNXvfNVIg = 562323548; VdmNXvfNVIg > 0; VdmNXvfNVIg--) {
        continue;
    }

    return smfpDmyHCf;
}

double WiEYeUqAlsXzt::MpZbyYmMozeiE()
{
    int JJchzfdxVFXBi = 859636525;
    bool vCfImliqgMwP = false;
    int MyhJitsk = 1313142860;
    double mlJcgymrBW = -364856.963204988;

    for (int hCIQoQvC = 494083306; hCIQoQvC > 0; hCIQoQvC--) {
        JJchzfdxVFXBi /= MyhJitsk;
        JJchzfdxVFXBi -= MyhJitsk;
        mlJcgymrBW += mlJcgymrBW;
    }

    for (int pUGlWwZehIrWeCO = 1213725530; pUGlWwZehIrWeCO > 0; pUGlWwZehIrWeCO--) {
        JJchzfdxVFXBi /= JJchzfdxVFXBi;
        JJchzfdxVFXBi -= MyhJitsk;
        mlJcgymrBW /= mlJcgymrBW;
        MyhJitsk += MyhJitsk;
        JJchzfdxVFXBi *= JJchzfdxVFXBi;
    }

    if (MyhJitsk == 859636525) {
        for (int JUpUzTpDZWFqQVCv = 1510079342; JUpUzTpDZWFqQVCv > 0; JUpUzTpDZWFqQVCv--) {
            continue;
        }
    }

    return mlJcgymrBW;
}

bool WiEYeUqAlsXzt::sDcQGkaowhvgjh()
{
    bool XRApgW = false;
    bool KuJqLaSUle = true;
    int acCdWBfXrafPBme = 2073231954;
    double xmTQdpaDAUbfjd = 693234.2812149274;
    double VwovvFr = 330404.4519630075;

    for (int dhgqeQDJwJyKf = 29348765; dhgqeQDJwJyKf > 0; dhgqeQDJwJyKf--) {
        VwovvFr *= VwovvFr;
    }

    for (int wggYeVkD = 1047883854; wggYeVkD > 0; wggYeVkD--) {
        VwovvFr /= VwovvFr;
        xmTQdpaDAUbfjd /= xmTQdpaDAUbfjd;
        acCdWBfXrafPBme *= acCdWBfXrafPBme;
        KuJqLaSUle = XRApgW;
    }

    for (int xjyfQGUFVJ = 59472245; xjyfQGUFVJ > 0; xjyfQGUFVJ--) {
        xmTQdpaDAUbfjd += xmTQdpaDAUbfjd;
        KuJqLaSUle = XRApgW;
    }

    return KuJqLaSUle;
}

void WiEYeUqAlsXzt::GvusZMaVhEVpP(bool QUxAEiAzE, bool nThyK, int SzDCSDRXcdZH, bool UdJdDsJBmPyu, bool mxjMiJOsdRJ)
{
    string TJDwOrQQWKL = string("HkodNgOXkTMlLAOsXcXKnWxhYBzkPGbDqgqN");
    double lBNSSahxyKT = -632891.1914882343;
    int tDZNpBHdtyqEO = -409616761;
    string cnIjpbKrKZdm = string("hTCGPAbGPeNdiZzEXpZvAQRjQYAVMFPIpIDsRoBYcsqxcoCM");
    double MNuplUFTiQeicQS = 103434.88866186042;
    bool HNkHl = false;
    int SKTUUafTQR = -379046694;
    string QxxStjEKZ = string("PgNOUUTiAJtMFaleUalQMovrQcIokOAcbQfzkcPvhlcrpouXZtLdBVBTjhFtFtQsXhFJQCmMnddSDPjPDEHmaqWR");
    int eMOUWNY = 324324086;
    double nvxzBaOHkQzQ = 654665.3896571575;

    if (eMOUWNY <= -409616761) {
        for (int QjOnwZzSvb = 1870903337; QjOnwZzSvb > 0; QjOnwZzSvb--) {
            UdJdDsJBmPyu = ! HNkHl;
            QxxStjEKZ += QxxStjEKZ;
        }
    }

    for (int giDiwIicJT = 322180035; giDiwIicJT > 0; giDiwIicJT--) {
        mxjMiJOsdRJ = ! HNkHl;
    }
}

string WiEYeUqAlsXzt::sYXXRHi(string IzQsGCTnMDuwCEd, double LeeWcicxXib, int oEyxuVMoaUSr, double jaqCsOoBDu)
{
    double kcCgMYCqST = 910001.2331389677;
    bool ZjgeaeO = false;
    bool ufNziS = true;
    int QgWMPAtJYg = 494092126;
    int WguoApyIqqrFe = -1024204039;
    bool kunIdhMXJpQDh = false;
    bool WuuIRold = true;

    for (int agXaj = 174575816; agXaj > 0; agXaj--) {
        continue;
    }

    return IzQsGCTnMDuwCEd;
}

double WiEYeUqAlsXzt::GGeLB(double SYeSZSgc)
{
    int lVirXehadFTJVr = 1014576962;
    double EVPzwPBZVu = -327570.99431453855;
    int JsBoIetqZKBweDNm = 193676419;
    string ZogivBUAbf = string("HlQXCquSxMiLYjyFRguBNREPZboXzbXgBgxqfdNlKryaIAFwclIccKqKzbkRSgfAJwjMlYEOradhSBznRRnxMKxxgwTnseXgzTOnYSexzIBzLSQPCViiwYAaJnITlDYtHmkHmoltkPFBRIKxPpzXfBKhSyhuTFrrzBSsjyXbGNqAkQZVvYcKYdeIGPTauyvRKxCYUvoWuErDOLMJEsSZxvKVzDHsEgAxszaCslLPTfSJvlOBnuQQdtkXeBPJCC");
    int NTWGAusI = -297161109;
    int zgticMcZYgPPoZ = 1596791934;
    int IZkttlIikJXUUIqu = -1090699329;
    double JeRnXw = 208371.9402854452;
    bool ExHnqUx = false;

    for (int XpFIrxdVu = 1588866679; XpFIrxdVu > 0; XpFIrxdVu--) {
        SYeSZSgc *= EVPzwPBZVu;
        JsBoIetqZKBweDNm *= NTWGAusI;
        NTWGAusI -= zgticMcZYgPPoZ;
        NTWGAusI -= JsBoIetqZKBweDNm;
        IZkttlIikJXUUIqu /= zgticMcZYgPPoZ;
    }

    for (int TSCqGXOSl = 1717112306; TSCqGXOSl > 0; TSCqGXOSl--) {
        IZkttlIikJXUUIqu *= lVirXehadFTJVr;
        zgticMcZYgPPoZ *= JsBoIetqZKBweDNm;
    }

    for (int QjtzMEMVVmU = 1929808760; QjtzMEMVVmU > 0; QjtzMEMVVmU--) {
        NTWGAusI -= JsBoIetqZKBweDNm;
        zgticMcZYgPPoZ -= lVirXehadFTJVr;
        JsBoIetqZKBweDNm -= lVirXehadFTJVr;
        lVirXehadFTJVr /= lVirXehadFTJVr;
    }

    if (zgticMcZYgPPoZ == 1014576962) {
        for (int NCxfwxaohJnPL = 807052315; NCxfwxaohJnPL > 0; NCxfwxaohJnPL--) {
            continue;
        }
    }

    for (int nbKCbgXnqHUu = 2137076107; nbKCbgXnqHUu > 0; nbKCbgXnqHUu--) {
        continue;
    }

    for (int HAqzErjbkWfiNxL = 383841064; HAqzErjbkWfiNxL > 0; HAqzErjbkWfiNxL--) {
        EVPzwPBZVu /= SYeSZSgc;
        JeRnXw /= SYeSZSgc;
        zgticMcZYgPPoZ *= NTWGAusI;
    }

    return JeRnXw;
}

void WiEYeUqAlsXzt::NYzNPWYJFViAtUX(bool baSVMoYCHa)
{
    bool VHYemPOyQYSMGUVy = true;
    string ghCDWAayNTxJiDA = string("tNySiIMniEQOKkhUFUeyjfRkVRWpqnCZxSwKmYJvGuygwDNkuOJYMOImriqfgxBULXtnHjcoCsxqFyNULUJYVRnZxwgWGlUaoknBSXrEkjQUPjdMDkHVIKiVpDSsDTtMrDQeUeOiZeUIGsGdsVrYyduQsMxCNnygXDInpImSRoPBXsxDpOmxMbBDfoXD");
    int cdYHhXRmkLkIGN = -2146298291;
    double PfukgfHYErep = 147940.99381395083;
    bool luqXbVG = true;

    for (int qMHriA = 1049884113; qMHriA > 0; qMHriA--) {
        baSVMoYCHa = VHYemPOyQYSMGUVy;
        baSVMoYCHa = ! luqXbVG;
        PfukgfHYErep *= PfukgfHYErep;
    }

    for (int qhDxsOQdIKOOE = 855715282; qhDxsOQdIKOOE > 0; qhDxsOQdIKOOE--) {
        luqXbVG = ! baSVMoYCHa;
    }
}

int WiEYeUqAlsXzt::FxAeTNBzOklDrsU(string gfoHCgq)
{
    string aBHuUKYJhzJ = string("mRrdQomzXSlNieYmDZdpZxXKRVQmnIStbqecUecUvhShzOIwJREUBCuDrWVwJeWbcFUaxAIOuErMsXeeUUMfqqzdTmeuZJkbVLCoptcrHcCRgbUCZXpkAOrsARHlJMvuLzIikNezHySHsUXIINwWJwHGVBKHJABSNjzW");
    bool oqvIwZgNAhZ = true;
    string PgbdA = string("twYuZRRmGcOhlrKEKYTcChEKZKFLWvSmQDXsCEGqSEPKchcHZCMmFPXiuYPZotnWDzWkiUNJzQaPHTEsplblivnZiRAY");
    string AbENhygLKlwfLSS = string("CPJlNeUcSszdIzDpcwhUCwsXwVGEPWyKdlafXdSTTAyZhXwVqWqwJwKxeJwwydwSGZDUvNykItFqSbwDpicLrAHWUikwSWFAxulzCZOhtZfaUXqmUCQfyRwlUONQkPtmywWqtfFMJieqAboAifLTxFYhuneuREVIxNKlsBsFnCsPMqOrQHfbKQzewKzGImsgDMWVbHjOM");
    int hqDhIE = 1754540610;
    int uyVuJkFVbxzD = 1696064000;
    double ouzdpdNRzCn = 757478.4510302204;
    int fVOuRIhuDasEYwq = 869896272;
    string eeXLOBgxRxz = string("klNgZVnBjhOAcyqDoaAGlCxpzgliuGYrOyiYmWALqElufZnIfgGtPYXPSdKerCPfuwGaWBGfhyHOjQMZXSvIXzmQJHoNXvppEcypQhzoHkaNuVZQYVu");
    double fJEiuVoDtAjsu = 142994.11919290308;

    for (int TGjvETYAw = 758244590; TGjvETYAw > 0; TGjvETYAw--) {
        AbENhygLKlwfLSS = aBHuUKYJhzJ;
        fJEiuVoDtAjsu /= ouzdpdNRzCn;
        fVOuRIhuDasEYwq /= fVOuRIhuDasEYwq;
        aBHuUKYJhzJ = PgbdA;
    }

    for (int cYvtPVcyRSBJn = 1921575041; cYvtPVcyRSBJn > 0; cYvtPVcyRSBJn--) {
        gfoHCgq = PgbdA;
        aBHuUKYJhzJ += eeXLOBgxRxz;
        uyVuJkFVbxzD /= fVOuRIhuDasEYwq;
    }

    for (int vqQCUBGWFZTOGGWA = 1915799449; vqQCUBGWFZTOGGWA > 0; vqQCUBGWFZTOGGWA--) {
        uyVuJkFVbxzD *= fVOuRIhuDasEYwq;
    }

    return fVOuRIhuDasEYwq;
}

int WiEYeUqAlsXzt::kfTWJdNfPW(int ybtXVdWWc, double gZXHiSQYsVDVzk, double RvPiAG, bool xCouOdiLrAyi)
{
    bool QBvHbqRCYLc = true;
    string sGBrQDHfoVf = string("IPiOmGSKzGGuTeynCtcqDodLydzHmlQYfdIRrJZGPZmVdERyCwntbQYAtcaQJYPdfrYxKZelYhRSkQWYmUWIssAkEPWwGcBpNaFzPIZrOspYrTFHmGurtZXUwzPniZrhcmIsvRUsNmDuifXvgMEObPDmVSsJxKfckagpFEzXNhzSFtJxobIuDcRiDKEvxfmEA");
    int AeLoobGtH = -355721283;
    bool wVVRegVZ = false;

    for (int XqQRJyeGmwjxkm = 372856150; XqQRJyeGmwjxkm > 0; XqQRJyeGmwjxkm--) {
        sGBrQDHfoVf = sGBrQDHfoVf;
        wVVRegVZ = QBvHbqRCYLc;
        QBvHbqRCYLc = wVVRegVZ;
    }

    for (int jFuDj = 1947191515; jFuDj > 0; jFuDj--) {
        QBvHbqRCYLc = ! xCouOdiLrAyi;
    }

    for (int IZigdVqTpdQjq = 1537948786; IZigdVqTpdQjq > 0; IZigdVqTpdQjq--) {
        gZXHiSQYsVDVzk *= gZXHiSQYsVDVzk;
        wVVRegVZ = ! wVVRegVZ;
        xCouOdiLrAyi = ! QBvHbqRCYLc;
    }

    for (int ejzZdWFALSMDpbmi = 317741394; ejzZdWFALSMDpbmi > 0; ejzZdWFALSMDpbmi--) {
        wVVRegVZ = ! wVVRegVZ;
        RvPiAG /= RvPiAG;
        AeLoobGtH /= AeLoobGtH;
    }

    for (int grLYjVHBfXtaFsx = 1478926399; grLYjVHBfXtaFsx > 0; grLYjVHBfXtaFsx--) {
        wVVRegVZ = ! QBvHbqRCYLc;
        xCouOdiLrAyi = ! wVVRegVZ;
    }

    return AeLoobGtH;
}

string WiEYeUqAlsXzt::UYbqIedUAFzJ()
{
    string NTWRshahvkaGNq = string("FplYZkESigorRGwbaYNFVeyHNICFDfynZlnwgnFxdxCqYHOkVqTsHPyhPzXQyHYJGxODfbIOdgcqXKHXITjMivsUfOuMuDKkbxmIBDZgTKCvdMaugWwvDmrIcUpYfelpNh");
    bool ckigksti = true;
    bool nEEQiF = false;
    double ejLEfjG = 438549.3220410722;
    string BHzFt = string("WTtFIAqLdtE");

    for (int naZnElE = 1197340592; naZnElE > 0; naZnElE--) {
        ckigksti = ! ckigksti;
    }

    if (ejLEfjG > 438549.3220410722) {
        for (int frQRZWUrF = 1902441355; frQRZWUrF > 0; frQRZWUrF--) {
            NTWRshahvkaGNq += NTWRshahvkaGNq;
            BHzFt = BHzFt;
            nEEQiF = ckigksti;
            ckigksti = ! nEEQiF;
        }
    }

    for (int agYwElNRGbymm = 370525439; agYwElNRGbymm > 0; agYwElNRGbymm--) {
        nEEQiF = ckigksti;
        NTWRshahvkaGNq += BHzFt;
    }

    for (int qjdhs = 736137349; qjdhs > 0; qjdhs--) {
        ejLEfjG += ejLEfjG;
    }

    for (int uzGOxzQzShdWqnJJ = 1286784623; uzGOxzQzShdWqnJJ > 0; uzGOxzQzShdWqnJJ--) {
        ckigksti = ! ckigksti;
    }

    return BHzFt;
}

string WiEYeUqAlsXzt::HlyBvAu(double mnhNvQtuqOON, double LHwahHDfTuZS)
{
    bool GjfsW = true;
    double szfnfbqgnJKk = 631947.6614797458;
    string EixAALnP = string("IyzMbnGNeuxZtpilRsRawdrJsynlNRfZiXLLoAEBzCjGCLZJVSFSpGkWMXwWlibdtKfLTYFiBYjtMl");
    string IPenpTDuHQhbSuZa = string("NNGujulcvTvXgZywFXVTsociekVJyvMPLxvznbuLZjZYwhYQKhIVtVoktNJCdWCNXYxlysuynNCaUdnDeKsdyDmfNnCFWqJNYZktVjbpeWsrREJhPzylSYZHZDhyFBTVnGTgOzLmVaTvqsaqGZCPhDYcIPucJeJemhIPdfdOWXmXSjzbwVkIKWeKbGhxuUhbBVDCLiNoSUKvgyRTfcXIhUpEzWgZreZUVG");
    double jlMSXkhz = 500149.4309540985;
    int FkDWgJBlOHk = 823381765;
    int FNhzOxQVGnNbhTW = -1953971951;
    string LliqJj = string("ONyPISiPehXJfVqVQPEKSsCFoGMzuniL");
    double gLrjyJnkcbMJUpO = -52286.86083796973;

    if (mnhNvQtuqOON <= -52286.86083796973) {
        for (int SThoCIa = 926226877; SThoCIa > 0; SThoCIa--) {
            LliqJj += IPenpTDuHQhbSuZa;
        }
    }

    if (LliqJj != string("NNGujulcvTvXgZywFXVTsociekVJyvMPLxvznbuLZjZYwhYQKhIVtVoktNJCdWCNXYxlysuynNCaUdnDeKsdyDmfNnCFWqJNYZktVjbpeWsrREJhPzylSYZHZDhyFBTVnGTgOzLmVaTvqsaqGZCPhDYcIPucJeJemhIPdfdOWXmXSjzbwVkIKWeKbGhxuUhbBVDCLiNoSUKvgyRTfcXIhUpEzWgZreZUVG")) {
        for (int qtgPJob = 1131393518; qtgPJob > 0; qtgPJob--) {
            IPenpTDuHQhbSuZa += EixAALnP;
            mnhNvQtuqOON = jlMSXkhz;
        }
    }

    for (int EJOsky = 1167614431; EJOsky > 0; EJOsky--) {
        jlMSXkhz = jlMSXkhz;
        jlMSXkhz = gLrjyJnkcbMJUpO;
        LHwahHDfTuZS *= mnhNvQtuqOON;
        jlMSXkhz += gLrjyJnkcbMJUpO;
    }

    for (int yEMMuXW = 1055799680; yEMMuXW > 0; yEMMuXW--) {
        continue;
    }

    for (int tTyqtILGMhDb = 174527656; tTyqtILGMhDb > 0; tTyqtILGMhDb--) {
        mnhNvQtuqOON /= LHwahHDfTuZS;
    }

    for (int cplUbvkXT = 922662367; cplUbvkXT > 0; cplUbvkXT--) {
        EixAALnP += IPenpTDuHQhbSuZa;
    }

    return LliqJj;
}

double WiEYeUqAlsXzt::KjfTWoaINX(double eASen, string xCSyLtfZibdImsN, string XliOmsepEcBG, double dHbkRUheMl, double fMCvMBmXxHbxL)
{
    double SwcspYmGPjdt = -124902.89065472584;
    string ZteNvGIpwOdYceDF = string("hIluYAnpzkBklijjUcavFfdzLf");
    double vyYqzhLoqXRXg = 683555.697630265;
    string MycfhRLVvloSQ = string("bPVAJOBMwJFBGiBHwHBetwOmfmNAoYgsmJeeSDJMQIbbfenqEdmgeaIebDdgGGaCpyCAKkUlACelUteRoGckDYtUdmerQURlrUODofGUJfNBAiKUiKbjRoIZuvmefqfwNrRckLlKuutJTZWyGuekaDoFggSuQzpSqXDKQHeKtsuAMhUlJeSHNWZiwuKZAWRCf");
    bool KSwsFzcw = true;

    for (int OLmhc = 1745624123; OLmhc > 0; OLmhc--) {
        vyYqzhLoqXRXg *= dHbkRUheMl;
        ZteNvGIpwOdYceDF = MycfhRLVvloSQ;
    }

    return vyYqzhLoqXRXg;
}

bool WiEYeUqAlsXzt::NpcPppE(double nJKPDc, bool dLVIFztAGKvChUR, double ypUVuw, string xkLvGTcZC, string YNakOpFkmuCRTx)
{
    string QZvdCEJEASzVM = string("BdcBUWoUloRlqQHyNkmaOlJUtTxlDRaIfPKODiSadFakSbvDCeNkdqenjkyuuFuLfPjEcLjzZfyfMqebUBaVEjScXkrTsjvsRHywCrOTzvDAUlx");
    double amJVcKHyHEcRd = 103512.93612327776;
    int AIxoHhShaQimBIcu = -314103676;
    int EXZHnZYHyQuT = 515395598;

    for (int pppQdUxpCeo = 664612767; pppQdUxpCeo > 0; pppQdUxpCeo--) {
        amJVcKHyHEcRd -= amJVcKHyHEcRd;
        YNakOpFkmuCRTx += QZvdCEJEASzVM;
        dLVIFztAGKvChUR = dLVIFztAGKvChUR;
    }

    for (int VGRNBJxoifroD = 1811100216; VGRNBJxoifroD > 0; VGRNBJxoifroD--) {
        nJKPDc += ypUVuw;
        amJVcKHyHEcRd = ypUVuw;
    }

    for (int iHyXBlKXqJPE = 1568262393; iHyXBlKXqJPE > 0; iHyXBlKXqJPE--) {
        xkLvGTcZC += xkLvGTcZC;
        amJVcKHyHEcRd += ypUVuw;
        amJVcKHyHEcRd += ypUVuw;
    }

    return dLVIFztAGKvChUR;
}

int WiEYeUqAlsXzt::MehYnvlFOKTVUz(bool GmzxJKTyVBQeXnE, double BqxhcPjHxwm, double kSFvYrtnbtEB)
{
    string myNTNzevzg = string("jQGunFfbSkjoQToMgzcszFMQTYYEwFXBlwTLXCxQGjCramUHEkNBmhcdSDDoLNAxFNEagvPoKoxieoVBOBAmlDTODPUjUOhYfsOvWhyprdaoTmUzgGzu");
    bool CHCqgD = true;
    string DNvTvRlswTVVEHfF = string("MrMcKKIFWhmQavqUVxAjNGwAqVYpXoKfrAnWcsTfgVNYxK");
    double haVtZWjCY = -532468.8467987344;
    int tDuHwUmNa = -330602646;

    if (haVtZWjCY == -532468.8467987344) {
        for (int UuiIpFe = 2069229578; UuiIpFe > 0; UuiIpFe--) {
            continue;
        }
    }

    return tDuHwUmNa;
}

bool WiEYeUqAlsXzt::XhdCUQjxbkiHLBr(string NWNDH, double okNAAiRYijXAixzd, int BWLOzbLotWnLo, bool qgAlGPMrhDKTUrYf)
{
    int mJcksa = 1335614632;
    int lYHnpNimVodOIjFw = -639306533;
    double eYYLAWhpC = 924956.5779087198;
    double YvVUncx = 259421.89982693343;
    double lLmzZPpEbQNJ = 38397.36336126454;
    string lDUwXKMCOYeiEs = string("cbPHypSJKVOGjglecSWtagsAXMJfwGKcJNjAFYfaznpuIXlOYODkkXPJUBLCcypKUiDANZmoKTHGVWzpGhUQXqAHTzszQkqqvzvEyFEvvJyHWCiRno");

    if (BWLOzbLotWnLo > -639306533) {
        for (int glbuYLOvnvgqVZT = 2066295197; glbuYLOvnvgqVZT > 0; glbuYLOvnvgqVZT--) {
            YvVUncx /= okNAAiRYijXAixzd;
            BWLOzbLotWnLo -= lYHnpNimVodOIjFw;
            lYHnpNimVodOIjFw += BWLOzbLotWnLo;
        }
    }

    for (int NPsNwQluLTWNcCs = 1151168824; NPsNwQluLTWNcCs > 0; NPsNwQluLTWNcCs--) {
        continue;
    }

    return qgAlGPMrhDKTUrYf;
}

int WiEYeUqAlsXzt::qLbESxoTWZDP(int wQwZHGcnj, int JuARtnUqbXFDgt, string xlDomqVhtf)
{
    bool FYibdP = false;
    int yDLakFeoS = 1228535202;
    int wptMMOZZHORp = -1923735332;
    bool VnVsh = true;
    int zJzVNNEy = -56100301;
    bool CZgpwaR = true;
    bool ORdBVCmRkDC = false;
    bool kDDyzmjsEfMM = false;
    int MPMeNTmbPctvHLDd = -618058523;
    string XOgEaRPoXWqdfIvV = string("YmmcJxGafEcYmoMSbwAbRvlxYrmrMcSsA");

    return MPMeNTmbPctvHLDd;
}

bool WiEYeUqAlsXzt::mddqcjoRaq(bool MpHyVFQGgml, string MECFCvg, bool AWUBbO, int oERgj)
{
    bool unOHYcgWSFIXwCd = true;
    string YUTVODVQcmGA = string("hhOvztrqAfjjeTgzNyiuqKybHXFrVHRuyRePzjTZfttrhZsNuPHdZjeSGALGwQYqxbqhtFgNpEobRcnyyaaNDWKGdjaoqydwzMUrZsJEUdGbZuUTSIbWGlMRAl");
    string toIroIWP = string("dbGrdpwHfoTjiddXACMsYKKoiTvpxYPUfBzpSQPfCbCRX");
    bool mDXVq = true;
    double qNzZbeJa = -883432.2466414056;
    string GGaBCxpOmXEFhuS = string("vksyni");
    int JaTNInNVJoUCrAZ = 788637237;

    return mDXVq;
}

string WiEYeUqAlsXzt::bnphscxuLLf(string saXXRdMHiebqFLq, int mAsZbhfUbtUThX)
{
    bool JRcmr = false;
    double ulMTAYfO = -629686.1987926847;
    bool KbDTbax = true;
    string CbYyixABFyyT = string("XkMpCTLCQleOcuPJZypfUpZCGebdDEBkwKNMsPVRDaxcGxzZsnwWRCnmonRjwaADuSeeQlTC");
    int ZrAuZNZBBh = 1996459931;
    bool PKsOLjZCUcKvrck = true;
    double aPDJNPaZibHiq = -610781.7165633924;
    double fUcWmzE = -210919.8632537004;
    int UDJiTTHSlynyZc = 270024865;
    double pEyWr = -538271.6133774476;

    for (int BoXVlFFZjxbSF = 1972025711; BoXVlFFZjxbSF > 0; BoXVlFFZjxbSF--) {
        continue;
    }

    for (int EGWFCbFJ = 1073144190; EGWFCbFJ > 0; EGWFCbFJ--) {
        ZrAuZNZBBh -= UDJiTTHSlynyZc;
    }

    if (pEyWr == -538271.6133774476) {
        for (int CyGloWDEemDL = 1243107004; CyGloWDEemDL > 0; CyGloWDEemDL--) {
            continue;
        }
    }

    if (saXXRdMHiebqFLq > string("XkMpCTLCQleOcuPJZypfUpZCGebdDEBkwKNMsPVRDaxcGxzZsnwWRCnmonRjwaADuSeeQlTC")) {
        for (int iOwCecZYqC = 423610943; iOwCecZYqC > 0; iOwCecZYqC--) {
            continue;
        }
    }

    return CbYyixABFyyT;
}

bool WiEYeUqAlsXzt::VpvcwhbxRvQ(bool nTqPHlKairCokh, string gOwLO, double OBcAmlASto, string iPVBxFxAlVUn, double omISlEDt)
{
    int nByQMFurseM = 639470348;

    return nTqPHlKairCokh;
}

void WiEYeUqAlsXzt::TKxyTtFFhNcA()
{
    int UwdPHjMZxF = -673953405;
    bool LrWhi = true;
    int aNgZWziz = 1924662859;
    int mKfNrTzKZ = -233043537;
}

WiEYeUqAlsXzt::WiEYeUqAlsXzt()
{
    this->IRNehjq(false, string("ZEmLhOPdpaZfmNXthMKjkSqmdNJscYnldCyEnRyZqqBJCQFiuGFdRmkcXNmxQoMQVYeNCxMOrIalBauLNAzGaSUGgQpSxgMdkmEiLDHObTfdoqLoUsThWyLZ"));
    this->RNaTnRCF();
    this->MpZbyYmMozeiE();
    this->sDcQGkaowhvgjh();
    this->GvusZMaVhEVpP(false, false, -926930399, true, true);
    this->sYXXRHi(string("yyOznOtibdEhVcAdVaagpqLLidbSOuBAmXpLLuiKLc"), 978852.3798053272, -2038759962, 749789.322558906);
    this->GGeLB(-825400.242561577);
    this->NYzNPWYJFViAtUX(false);
    this->FxAeTNBzOklDrsU(string("TySnDcQkfRPabkkHEaSOlHYRHNufCfwbQGXfJHOxxpnxeUzZnVYkyfdQRCCZCxJNbnyDACKKRaoiMxgYUIYRTSSfUFcRhCWroprj"));
    this->kfTWJdNfPW(-2033101701, 27962.01981021593, 274268.6070956084, true);
    this->UYbqIedUAFzJ();
    this->HlyBvAu(681870.997303204, 338033.3761956281);
    this->KjfTWoaINX(-673660.5968731205, string("bqbgiGntMpedyWgrnnWrOndWzOxxrbYRlIwVgGlFszbcZIbPuSyK"), string("EtRmoGkVhdDmeMEingnXTkOBCdelPspzSQalcIJVAigDvuwDpUEvlgnrYCwUkPmYFissCjMbiyGgVRrgdQChCmiKWQVZipGHBfgRNqkhplaflUVMBrMXltXVMXSJGfBWOUUcdIqbTzBqRMifQhVuKbYZObVfJDgMoeHKvfkxbYdlUmrjmIdTSL"), -338473.682035157, -766885.269036588);
    this->NpcPppE(-632486.7023809396, true, -998985.3787987187, string("ewfibhQprElRKEFDOoolXeeCieHqFfFdEXwTdQoIjRNUduFFrPbNVkATEHggCMqyBhVDlFBatVuRoTMO"), string("BagutMBvLTghFWQZLgVoImZsxdVqrMCGoALutSVcdzkUqQuxMfWxNEqWfWAybmNjavSaivDEZXCHMmySsvuyWReBFQYpkmalLHArQpcSYHsupXjCVtFYQcXtgVBZAcjpThwcMdBusxCjxCxZNKXqPxJFQTuqLCMFJAReCwNHAHMtahewOSjYEbewgOfqJLuHxcRkPdcGgobTwIjcTyjNgExtzPaGUchtVeUQBTOL"));
    this->MehYnvlFOKTVUz(false, -21932.760890095356, 799167.0245022443);
    this->XhdCUQjxbkiHLBr(string("PfsHjvPEJygekeGzvxxgpAdmKGKmdmCSIDSmaRaUZAfpIzeFkBQvBXZdArDArgPuWXiOyDKwoVSlZpCnxAjhadpzHpYEPKbRopHqWYPHcuOUnKAmbPzHlylMkNWZqqfWPcKXsAbvMuKrCndCNiZcuB"), -676268.5165529646, -358677739, true);
    this->qLbESxoTWZDP(-24593270, 1482819357, string("FsEjaTCOXvLwBIGDPxsRiveevWxtdKPwlJIcpdcDNiLmJVBCsBCvdGZvdxRcCiaORYygJcheNBEcHlLbbqVvYqSrVykfHQRgISpFhQxlGlJhXkyjmORgFnsjHjfPfoVZLNWdFjTNHtTvNfgIGqmN"));
    this->mddqcjoRaq(false, string("KCPCvLnECiLTbSUqvmFbwwqVQtQrQREXdjVkJjeqPKYcLvJZqoCPpyoYGrPTALZUdzfMyiNnNSsmvlQPBBaIaxioHfuNMqSMKaPnFkoNUhqQvJydlfCWGcUAfFlHYuaKSdtMGKNYXgUEZg"), false, -897349738);
    this->bnphscxuLLf(string("lIiiPmMzdC"), 1124796077);
    this->VpvcwhbxRvQ(false, string("kImIBFIBkEjEqtCAtyvnGzWIdwXEHyYvDtdQjxEUhQqiMJDChtHWZqorkZYkvnzgBZkeTRIyxLiyYYflgMXEUpZPXKnwsRDLuFpVTFhCIcCHNkkXIWHoNDAYiLNBdkLeVgP"), -425288.5795731918, string("kDxwjAPrxAkSCZUwWKKzHFgkvQBRLSYRmEEJuKxqRKPUlZxhNgEzdnNWtupgfpAszXEgwlbnubiXwUTjgmSoWYElfmxqpRcWQeUtmqFUsadbMiCNytxQRpCntIHXIwxcZwKkGtqzxPYrLOrWeYAbJsxWRQvLZDQjfEHflIfHWlkcidQOyQPAJhxpxNigatx"), 770316.6653382123);
    this->TKxyTtFFhNcA();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vUWdTSOrQZ
{
public:
    string kPnSjfoVQiVj;
    bool uMNeOrSQsdR;
    double bkqGANMwpIRB;
    int flJTzIsbKwBuYqTi;
    double peieQdOP;
    double DyXgRIAwOHJpgQci;

    vUWdTSOrQZ();
protected:
    int hNxTEuCBDhmN;
    int ItGnJllfcIqgJNK;
    int qBPzBTrklNFJTg;
    bool exvlEoLpOEXdq;
    string mUOTNCPHXlA;
    int bKzwyEE;

    double CjdpuST(double uxLXWvLqkkYipDvM, int swHuLmEjMlJA, double LxAyoGOgYQMSGJTC, bool cWyUsPUUHaYrPd, int SNhIODp);
    int JkXzJm(string dmoIjAKQE, bool kylNUlrgALPNDjcq);
private:
    bool xbPlu;
    bool MSzsckmRJPlK;
    string dRLCMbWaPMFetDIo;
    string JsKcuXVQOASFd;
    int PxJcnldAILIWpt;
    double IQOpajqKniHg;

    bool cNYhvvS(bool znomOijyTZTevNF, bool EtLbOSnVRFWxYjU, int wpiYJzYJF, string oRxaSBKnhDQNyCG, int IpLtyVB);
    string YslmlrDwwZZe(bool KCTWC, double krqIqHd);
    int ahResWROYQDCwsmw(string RpjquYDCYqVYZf, bool OkSYuaEEndWxUV, double bbXeiCiUAXiZe, int tiLPWnZu);
    bool dxIkSulbttNocaV();
    string TQvRZS();
};

double vUWdTSOrQZ::CjdpuST(double uxLXWvLqkkYipDvM, int swHuLmEjMlJA, double LxAyoGOgYQMSGJTC, bool cWyUsPUUHaYrPd, int SNhIODp)
{
    double rxcFIdFe = 650891.9732159539;
    string ZVZNPekTvRo = string("ixwrbYNMQZnsTDeBbTCFHifkgrIFHvirYUidjVcUTdMykLEBBptiTLmircGungCJncZxLHuwfoofT");
    int oBdmgNgHkwgqoz = 1846659735;
    int fOstRNgxoaSNv = 2072019317;
    double VVUsxRhWnWFIpJ = -1005157.0834012269;
    double yQyNqhaLoM = -766269.0116568167;
    int apwRllQw = 529612136;
    int mqfWnkPgrUrFmsA = 94948480;
    bool PHESkgGij = false;
    string YsAadyJwqecGcxN = string("WhqMnyHWUScjBIUUzdkmQavVLHdUcLuchNjPLvb");

    for (int oAjiorgCuFEQTi = 1724313607; oAjiorgCuFEQTi > 0; oAjiorgCuFEQTi--) {
        LxAyoGOgYQMSGJTC += yQyNqhaLoM;
        oBdmgNgHkwgqoz -= oBdmgNgHkwgqoz;
    }

    return yQyNqhaLoM;
}

int vUWdTSOrQZ::JkXzJm(string dmoIjAKQE, bool kylNUlrgALPNDjcq)
{
    double HtOMz = 583811.4483234618;
    int cOJDzaWzwl = 673196542;
    bool UNMaZWMCMiywd = false;
    int FyebawYYrS = 657137036;
    string pshGPjKfEsODso = string("IlcYHWpuCxwKLmfRtqBzJZDLTFvYTDsJOhahMTukvqOuUzETReWANCqkMuTpJnUFgbngQEplclJuOFBDYQreeqxlzdKOugXxMWRtDESKGORqdZntgqzAEVuBBTlRnJBAGwjhXKlqINsiavwnSloBbsoasFsoQSsjNimVsHeoImhsYlBJpCiqHlCNmBrrCqmAWTvJJzgfjTBbzRfyZtzVYPDNLYwNNuvAwnXI");
    int YaVwavXcJ = 400476207;
    int ubAhZKmBn = -155607831;
    bool pLCxKagnPXqQvGA = true;
    bool oIcQgmcIdwI = true;
    int kCbdgCKQ = 1241105997;

    for (int cLVmDGcICs = 1651471767; cLVmDGcICs > 0; cLVmDGcICs--) {
        pLCxKagnPXqQvGA = ! kylNUlrgALPNDjcq;
    }

    for (int vKiZWGDv = 1575138565; vKiZWGDv > 0; vKiZWGDv--) {
        ubAhZKmBn /= FyebawYYrS;
        kylNUlrgALPNDjcq = ! kylNUlrgALPNDjcq;
        kylNUlrgALPNDjcq = ! kylNUlrgALPNDjcq;
        kylNUlrgALPNDjcq = ! UNMaZWMCMiywd;
        kylNUlrgALPNDjcq = oIcQgmcIdwI;
    }

    if (pLCxKagnPXqQvGA != false) {
        for (int wMNDdGFg = 1116400439; wMNDdGFg > 0; wMNDdGFg--) {
            kylNUlrgALPNDjcq = UNMaZWMCMiywd;
            FyebawYYrS *= YaVwavXcJ;
            oIcQgmcIdwI = ! UNMaZWMCMiywd;
        }
    }

    for (int TBTzsArlnHqjh = 1386259003; TBTzsArlnHqjh > 0; TBTzsArlnHqjh--) {
        UNMaZWMCMiywd = UNMaZWMCMiywd;
        ubAhZKmBn /= ubAhZKmBn;
    }

    if (ubAhZKmBn == 1241105997) {
        for (int bjmMBe = 640979165; bjmMBe > 0; bjmMBe--) {
            oIcQgmcIdwI = ! pLCxKagnPXqQvGA;
        }
    }

    for (int sHwZbvgvfYzHVar = 2110237743; sHwZbvgvfYzHVar > 0; sHwZbvgvfYzHVar--) {
        oIcQgmcIdwI = pLCxKagnPXqQvGA;
    }

    for (int wplpzmr = 2019682220; wplpzmr > 0; wplpzmr--) {
        continue;
    }

    return kCbdgCKQ;
}

bool vUWdTSOrQZ::cNYhvvS(bool znomOijyTZTevNF, bool EtLbOSnVRFWxYjU, int wpiYJzYJF, string oRxaSBKnhDQNyCG, int IpLtyVB)
{
    double knQFkXGLQHE = -500947.53890588216;
    double WMGYDAnZMSSyRhg = 65622.91832218123;

    return EtLbOSnVRFWxYjU;
}

string vUWdTSOrQZ::YslmlrDwwZZe(bool KCTWC, double krqIqHd)
{
    int MfMxNafK = -1758840616;
    int QlQFu = -2011592845;
    double pPzQGALuhaJlnD = 587664.944959659;
    double dMsGDYydrcOXEEa = 450593.9170069696;
    double MEJakvGAOGHBLC = -635601.1630992473;
    string YAuuYUUbs = string("OTvjDwBHCTpeDEMeFYSYnvNgSEACvlaOfTyQsDGQyFYLQMPxtAooFyzzjeSGnrkhNrvUpCIgSmCXSOdNrfogqtDeKwMXPhLzDXYJBVOKsUOvDrXpMEKedvGhzLKZaJmDSwHhsXDyhlCjTuucwSPnogMtKjTRlDKwcfPXQOKiyGFHQDnBvjaYYjYKiqEEupDIZOnNuIJlXnGfpWJERA");

    if (MfMxNafK != -1758840616) {
        for (int MtxzhEseFQHRU = 739793828; MtxzhEseFQHRU > 0; MtxzhEseFQHRU--) {
            YAuuYUUbs = YAuuYUUbs;
            pPzQGALuhaJlnD -= MEJakvGAOGHBLC;
        }
    }

    for (int CoCONgYDrGuNbn = 1540219115; CoCONgYDrGuNbn > 0; CoCONgYDrGuNbn--) {
        KCTWC = ! KCTWC;
        MEJakvGAOGHBLC += pPzQGALuhaJlnD;
    }

    if (MfMxNafK > -2011592845) {
        for (int niuTuBlxWVry = 1827977586; niuTuBlxWVry > 0; niuTuBlxWVry--) {
            YAuuYUUbs += YAuuYUUbs;
            MEJakvGAOGHBLC -= dMsGDYydrcOXEEa;
            krqIqHd *= dMsGDYydrcOXEEa;
            MEJakvGAOGHBLC /= dMsGDYydrcOXEEa;
        }
    }

    return YAuuYUUbs;
}

int vUWdTSOrQZ::ahResWROYQDCwsmw(string RpjquYDCYqVYZf, bool OkSYuaEEndWxUV, double bbXeiCiUAXiZe, int tiLPWnZu)
{
    double XGIMBCI = 731824.4420297537;
    string LxvUkzcRvt = string("UjGiZuqmKZsKiROROeQTaJVfyQJaaUrfpGPvsZTfuMmjEINVsvZQeYTDswbhjTabUKFiJBdKzgCOfxhSlpNadFbOubjaAfMKCFTJQvMpnsXKCSEnSNjHtpYLbiPdMHzbSLJtcGDbdoZVtElgFipkmWszhbQmjS");
    string pQYSxmycT = string("CQVMeAjfyHMENDWMayeNEjdVysYFYaXlcXVayceKVBvycoWvTmkDdcRzCvsxJDVVhzYmYlgzVcZZL");
    bool WpHBibgOkyJwDL = true;
    int cCMmoKXTJHKqPie = -635495159;
    int GMOGPz = 288978182;
    int PhTSWuzOFqgnu = -2044484293;
    double EjtMANjdS = -198472.21662916848;
    int tRlCQgS = 1064235734;
    bool vFVfxykypyUqY = true;

    return tRlCQgS;
}

bool vUWdTSOrQZ::dxIkSulbttNocaV()
{
    bool xbzCpSNyticos = false;
    int AjTWzPvsP = -1871353451;
    int KTlfh = -671953392;
    string OIycfAscyUgllMuP = string("uNACahTymiCkBpEfAOoCLecviHymdnKBskhutWvaNWaUNwzzerOKJBXhmOJdiQUTGcMdUvSVYuiBgDOlAfTjVwHMNsBTdZfMtBQtowpQPDBpeEyP");
    string eAfBqadUx = string("GvJHqgvdVXoyGvoTTWhwFMlhUbBqeEpEutlwuZJrUSkJteBOBpgziqJpXsEoxrEpNLUHorPiDpWplbRyiVMyvcaEFqHHeyKCfQzmsZWOmeBISlqkPrwXVyNZnqjzPHJFWiCXWHPpspSnK");
    double LXCrIISHRQIBu = 59845.95593748435;
    int TNBcPYkEv = 327607551;

    if (KTlfh < 327607551) {
        for (int XhRktMMpQOYf = 598971738; XhRktMMpQOYf > 0; XhRktMMpQOYf--) {
            AjTWzPvsP *= KTlfh;
            TNBcPYkEv -= TNBcPYkEv;
        }
    }

    for (int esRpYjY = 866600967; esRpYjY > 0; esRpYjY--) {
        eAfBqadUx += eAfBqadUx;
        OIycfAscyUgllMuP = eAfBqadUx;
        eAfBqadUx = eAfBqadUx;
    }

    if (KTlfh > -671953392) {
        for (int ANOPBnhDLnpFuJxl = 388423176; ANOPBnhDLnpFuJxl > 0; ANOPBnhDLnpFuJxl--) {
            AjTWzPvsP -= TNBcPYkEv;
            TNBcPYkEv += KTlfh;
        }
    }

    for (int ebmdDDQlfSV = 639119747; ebmdDDQlfSV > 0; ebmdDDQlfSV--) {
        OIycfAscyUgllMuP += OIycfAscyUgllMuP;
    }

    for (int uGVNPdRBPvxL = 1914757683; uGVNPdRBPvxL > 0; uGVNPdRBPvxL--) {
        continue;
    }

    return xbzCpSNyticos;
}

string vUWdTSOrQZ::TQvRZS()
{
    string SJhXlPqsec = string("eXDUuswwzxVTEByMQgNdzXOUHSbUcJPINixHcWgfxCaktwYAFBTdOpAgtLnRFkBILFXwIjJyfdAojLTODwHEmRKwYdHHsKdnfXeoEkJxBoQnPxCLlHsDbzKJrlKIfrhvFTLxPCvuysKMdBuQaBNuXHaTjzoiEqqfPKKkLUDEWFEEFkZpSiOYipiXW");
    int gjkEmBN = 1327536163;
    double GlhkLoIvm = -117685.36194237588;
    int oDpdkN = -332214785;
    string TlCeVPEVYv = string("YGSWhCKDUsOLnIFapBYzhMHJhGMaSbSmixlEITtjdlFSfGPunVZlENNAjAtzGobepgiuqJsTrVDBDqIbsHjwokQIDVHfnZdcGTgCzOrHwVcWQKAuBTKZeSOyllMCEUOPNsltuTqRsoLMaXUQxGcIJCyHpOHnJBAZWWOMUrTzsXsYKZYFTLlPpDAPXNMIANXSvSQwssZkoqonzrPuycNkxJuMLhOxyij");
    bool yqCdsUZQVta = false;
    int xXWzzZ = -1094431027;
    string dRcwRv = string("OFpOsWKYRPEgnimWFoxTaPzDVlXdufbJJiaVpkEbmLfIIllaxqJzjlJVuhoBBbsLkEaNtRwAxGhhVJCoSnTgkZpaagXYvLlGrgqovXxjEIUVrxnqFXlzX");
    bool wtGDsQhMDqb = true;
    int toeZWLDHmFvqLg = 757977590;

    for (int gyuapIpvPNnKPmN = 925327325; gyuapIpvPNnKPmN > 0; gyuapIpvPNnKPmN--) {
        toeZWLDHmFvqLg /= xXWzzZ;
        dRcwRv = dRcwRv;
        oDpdkN /= oDpdkN;
        yqCdsUZQVta = ! wtGDsQhMDqb;
    }

    for (int UAPgpOC = 26553037; UAPgpOC > 0; UAPgpOC--) {
        SJhXlPqsec = dRcwRv;
    }

    return dRcwRv;
}

vUWdTSOrQZ::vUWdTSOrQZ()
{
    this->CjdpuST(-147716.93027639206, 1355431222, -467143.5113616327, false, 321781288);
    this->JkXzJm(string("dDJrLVqmxpYfWzuTZKEiewMMmsbuAzOACQCWLkJfUDCpTfzBQVzoasnqkryUkyJfjleizeXPXtFvzNhYvk"), false);
    this->cNYhvvS(false, true, 1742287407, string("wIqhIpnQxYKPXPMvIalavRIwAFsWNSKjZHXphBkjowphriOpqAhEQuTCHsmtLZgZbpbLePumWOCGouoCsVqUILTUNATKfnYUyaFzczfyphukHyRZfPKkdnjTMdGudWRdZKTiPsKnghuZFOQEylLsujjDAamNaUPfohMdxcxIPoVQJZlRwdaxmkivTzRr"), 1505817342);
    this->YslmlrDwwZZe(false, -878321.2696946419);
    this->ahResWROYQDCwsmw(string("oMVqXsrrtDkVzvkkHvJZzKbLoOZssYloozwMYhXEZQKWJaYKEkNiUmAloDihykjTtrMxlmCoaOKdmwXIDqYZCwbGiOQSeRCBUSCiervFKGqCVXVnzjNtDSDREVHbrXpeRtOMakmaBaKNVWpGVUHaZcpqrHfJVJ"), false, -318462.39448188397, -69864757);
    this->dxIkSulbttNocaV();
    this->TQvRZS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aPDrWxdd
{
public:
    string oXvYNceltCvVKJzC;
    string GZolWQZCeoVE;
    int fZZkK;

    aPDrWxdd();
protected:
    int hmbUhhDhim;
    int dRjDgkrMwMXCIASU;
    double GtotDFKzaKih;

private:
    int vZhazlosOmu;

    bool cVlBcwYPU(double EQiowrJQDnZom);
    string vbcMdfYwpw(int jvDmLCpyx, double RBQrvAdRYg, string SjgUAQZxM);
    int hlltzM(double mnKlXmMcfRobGsK, bool FNFMOweD, bool UwWcxOkDKeTMnZD, int CPhLrtboPRPPzYY);
};

bool aPDrWxdd::cVlBcwYPU(double EQiowrJQDnZom)
{
    string ayhKOIPNCsdUYi = string("MbOcKUNMFPH");
    double EgAzOhoImdwc = 646387.7716561209;
    int wfeiVtyukeeEBv = 192602692;
    bool aDkooWHlo = true;
    double SqIgmfqqPEPa = -936547.030069453;
    string tatOnWjOuLL = string("lNRTghTrudjueSpacXKtBWXocehrhjBfsUTeoCvEcHyyAFtfzXuglgnalYDPSulryTunPyFZEKXoysOERHvWLmLRhpcTcYhalwkjcBuBebhLaqOiJektwXutuJHlzxdVvSGmSYxunbCSReKqQxFKiqItlDwfDMsioETxWLgk");
    double yGnuS = -252134.07622977198;
    double CUNfUvxDXpMJrZb = -146018.46681431183;

    if (EQiowrJQDnZom == -183723.10581167997) {
        for (int Xvsztntx = 596989529; Xvsztntx > 0; Xvsztntx--) {
            EQiowrJQDnZom /= CUNfUvxDXpMJrZb;
            yGnuS += CUNfUvxDXpMJrZb;
            CUNfUvxDXpMJrZb = yGnuS;
            tatOnWjOuLL = tatOnWjOuLL;
        }
    }

    for (int NtmrDv = 826583459; NtmrDv > 0; NtmrDv--) {
        EQiowrJQDnZom = EQiowrJQDnZom;
        EQiowrJQDnZom -= yGnuS;
        EQiowrJQDnZom -= EQiowrJQDnZom;
    }

    for (int vkgkAIRxOBenyFBn = 139725940; vkgkAIRxOBenyFBn > 0; vkgkAIRxOBenyFBn--) {
        EQiowrJQDnZom -= yGnuS;
        yGnuS -= EgAzOhoImdwc;
        SqIgmfqqPEPa += EQiowrJQDnZom;
        yGnuS -= CUNfUvxDXpMJrZb;
        CUNfUvxDXpMJrZb += EQiowrJQDnZom;
        CUNfUvxDXpMJrZb /= EgAzOhoImdwc;
    }

    return aDkooWHlo;
}

string aPDrWxdd::vbcMdfYwpw(int jvDmLCpyx, double RBQrvAdRYg, string SjgUAQZxM)
{
    string NBaMPEXwg = string("OoTJzBOTMNBWLaEfYaakPcHBWfBkZRAqPVRpNXDKisRlxCnXGsJdIFdNRpdyVTZwmgWaeohAqBmUKygkWgKUymZiwuAqDftgJDGGv");
    bool CJRyZrAJ = true;
    double bemFvetOHmPFfU = -839775.9834597573;
    int qsWRdWGLaMiKO = -1224580573;

    for (int bsnOiDBsGa = 1876481771; bsnOiDBsGa > 0; bsnOiDBsGa--) {
        SjgUAQZxM = SjgUAQZxM;
        SjgUAQZxM = NBaMPEXwg;
        jvDmLCpyx *= jvDmLCpyx;
    }

    return NBaMPEXwg;
}

int aPDrWxdd::hlltzM(double mnKlXmMcfRobGsK, bool FNFMOweD, bool UwWcxOkDKeTMnZD, int CPhLrtboPRPPzYY)
{
    double HfvWZHbWfHOVXj = 131971.96248475928;
    bool JSfJPEPqFhI = true;
    bool DQLEIqXFBmPpxsBE = true;
    int NGwqBQVAzUZRmbi = 1588343143;
    double PnSfusIbPciTgNE = -247428.5665769045;
    double wUZKCgaha = 910944.9546878077;
    string uKIgg = string("hFg");

    if (FNFMOweD == true) {
        for (int ODpyOyLqsMyXVsy = 1782077687; ODpyOyLqsMyXVsy > 0; ODpyOyLqsMyXVsy--) {
            UwWcxOkDKeTMnZD = ! DQLEIqXFBmPpxsBE;
        }
    }

    if (mnKlXmMcfRobGsK == -247428.5665769045) {
        for (int eGytVZRNSiym = 668127558; eGytVZRNSiym > 0; eGytVZRNSiym--) {
            FNFMOweD = UwWcxOkDKeTMnZD;
            PnSfusIbPciTgNE += mnKlXmMcfRobGsK;
        }
    }

    if (mnKlXmMcfRobGsK > 910944.9546878077) {
        for (int bCmvphivy = 2034532437; bCmvphivy > 0; bCmvphivy--) {
            continue;
        }
    }

    return NGwqBQVAzUZRmbi;
}

aPDrWxdd::aPDrWxdd()
{
    this->cVlBcwYPU(-183723.10581167997);
    this->vbcMdfYwpw(1721636769, -623550.2272212394, string("moCEYJCJWERIsiqHweBEEGQZhwvzNgUQqFxJgyGrXqCIkDNGEFoBiWTwupYGMzZtbjJOjejeHtGTByfensHRwFUZeEzuMivTDpkLGPVlicoKXklHOPHZxqegvDTLVLWhLyTxZsAhcqBaGdDUZSzwNcBFJDbtEwqinRldLPQFYghmNDKjGzQGKYVArRPxdQxcpsLiVBjAPJj"));
    this->hlltzM(-871772.9838895579, false, false, -2029673367);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vniMvWLD
{
public:
    double MbXYJRBkBFMiHBZ;
    double UVBJjH;
    bool wJjMt;
    bool EsTFvilWEpdHQn;
    string dbtbXr;
    bool LFLSLSbmEWhhjE;

    vniMvWLD();
    string tvrSIEejElu(bool AmJxaMLnK, int nVcwQU, string WfMGs, bool FCLhXsZAglmDTK);
    double pznjdJybkgodWX(bool cFtYBnotxlmmq, string EAsVzYRsg, double enkZJolWcX);
    bool VqmUVaI(int vkYxehbD, int YklCQVkR);
    bool RQmOtdjPU(bool QoKBNNsld, string ZgLjYVoz, string YZEXscvHNLluUJ, int hgPHCmZbkFZ);
protected:
    int vvhKKZCNs;

    double gnIPLQe(bool QOTJD);
    bool xXLYCTZEQTfvRvTH(int uBWSGWxW, string tyGRZXIs);
    int DRwVZcWKeP(string IlCpZN, double BfnfwdqVbVFPlzvG, bool GFJVMV, double xnwIfRrT, int zVxgT);
private:
    int ieCuXAoGFp;

    double KwhDpWCxGVUTMa(int QrntEeTCpEGLDvKF, string LvfFcz, bool ZkCpFLvyGnT);
    void dEnqteWrxv(double ucLOueHyAOIwfJ, string rndMqgQjIGbvpNRI);
    void oBCenbqqov(int gjPMKVvQVGdMqHm, bool tbMbIQok, bool oKauU);
    string yJfcpKplt(int qhWfhddWl, string cVciZrnVS, bool GjYDGQeOid);
    double toLlraxAuDLDj(int KReAsxTNCATetDFD);
    int OQILQDit();
    int sbfcsBqBrwlFpNka();
    double SJUVESPfp(string WQIUkmDpSqFAfar, string tjryJuQeyyR, bool DwKEcHptfwA);
};

string vniMvWLD::tvrSIEejElu(bool AmJxaMLnK, int nVcwQU, string WfMGs, bool FCLhXsZAglmDTK)
{
    string ouojcgFlsIvEVc = string("pMiuOpNSwRzuTsNknpyCeGOMacopbfqTwwUgcvqwcYdWTmldwWGlbJbAmbtwEvbSGyzsoIwlgzPyrWwKeDEzwpjVGRndsEIwXWGPgjZGJHkaYZgVGjqTxgeIBegrreOskRDyhQPJbksgHVFIIqgsrKEyIPmuSCKTiYyImCrWEktgHKKxjpJKBstzfFLNPgcmAZxWtvbkFmsLzNVsypyVIlsutQHhYsBjEhHfPwDUoUn");
    int wvaIo = -133197862;
    string fUVvbrXFOyxufu = string("gvzmDvApiXFcepuocHefOngKmYGmaHZxTxLHKFRCSphdGAntQOfGFLkSheFmwsIudbrFMiZCslUbSKKWiLgzAblNJKINVLbuJvCqNPkmEqUqHFDOrBFexWcMULi");
    string zYZUnlNAlEBbHT = string("pdgkkOvLUAhSSPWAjAAdqLweovsBrBiKuBeUTonXNQnkIG");

    for (int dUggbQLmfSPga = 940844539; dUggbQLmfSPga > 0; dUggbQLmfSPga--) {
        ouojcgFlsIvEVc = fUVvbrXFOyxufu;
    }

    if (WfMGs >= string("pdgkkOvLUAhSSPWAjAAdqLweovsBrBiKuBeUTonXNQnkIG")) {
        for (int ireaDxZZZvJQBGre = 1747475181; ireaDxZZZvJQBGre > 0; ireaDxZZZvJQBGre--) {
            wvaIo = wvaIo;
            zYZUnlNAlEBbHT = fUVvbrXFOyxufu;
            fUVvbrXFOyxufu += zYZUnlNAlEBbHT;
            fUVvbrXFOyxufu = fUVvbrXFOyxufu;
            ouojcgFlsIvEVc += fUVvbrXFOyxufu;
        }
    }

    for (int SNfnQjvvVufbp = 1657680222; SNfnQjvvVufbp > 0; SNfnQjvvVufbp--) {
        wvaIo /= nVcwQU;
    }

    return zYZUnlNAlEBbHT;
}

double vniMvWLD::pznjdJybkgodWX(bool cFtYBnotxlmmq, string EAsVzYRsg, double enkZJolWcX)
{
    bool rAdKsJSkaXVVBaiN = false;
    int RdpcXTeKPLYmLWti = 924053134;

    for (int eCdbKUnuvMZs = 1370502551; eCdbKUnuvMZs > 0; eCdbKUnuvMZs--) {
        cFtYBnotxlmmq = cFtYBnotxlmmq;
        cFtYBnotxlmmq = cFtYBnotxlmmq;
        EAsVzYRsg += EAsVzYRsg;
    }

    for (int hPgnec = 2091358372; hPgnec > 0; hPgnec--) {
        continue;
    }

    for (int xKJjkOYZETrN = 425770452; xKJjkOYZETrN > 0; xKJjkOYZETrN--) {
        continue;
    }

    for (int SdzxpjeJlkCS = 995117901; SdzxpjeJlkCS > 0; SdzxpjeJlkCS--) {
        rAdKsJSkaXVVBaiN = ! rAdKsJSkaXVVBaiN;
        cFtYBnotxlmmq = ! cFtYBnotxlmmq;
        enkZJolWcX /= enkZJolWcX;
    }

    if (rAdKsJSkaXVVBaiN == true) {
        for (int LHhKMMnGSmY = 382994241; LHhKMMnGSmY > 0; LHhKMMnGSmY--) {
            rAdKsJSkaXVVBaiN = ! rAdKsJSkaXVVBaiN;
        }
    }

    if (cFtYBnotxlmmq != true) {
        for (int OwIsumuQDbiRZI = 252538353; OwIsumuQDbiRZI > 0; OwIsumuQDbiRZI--) {
            rAdKsJSkaXVVBaiN = ! rAdKsJSkaXVVBaiN;
            EAsVzYRsg += EAsVzYRsg;
        }
    }

    return enkZJolWcX;
}

bool vniMvWLD::VqmUVaI(int vkYxehbD, int YklCQVkR)
{
    bool RMDbVZbWXGJPJ = true;
    double MbrCz = 394985.2202755673;

    for (int kTxrlMATtGewM = 517493728; kTxrlMATtGewM > 0; kTxrlMATtGewM--) {
        RMDbVZbWXGJPJ = ! RMDbVZbWXGJPJ;
        YklCQVkR += vkYxehbD;
    }

    if (RMDbVZbWXGJPJ != true) {
        for (int dsLefx = 2084598869; dsLefx > 0; dsLefx--) {
            vkYxehbD /= YklCQVkR;
            vkYxehbD = YklCQVkR;
        }
    }

    if (vkYxehbD != 1202296853) {
        for (int EgJrZCfDsimegKa = 1329845425; EgJrZCfDsimegKa > 0; EgJrZCfDsimegKa--) {
            continue;
        }
    }

    return RMDbVZbWXGJPJ;
}

bool vniMvWLD::RQmOtdjPU(bool QoKBNNsld, string ZgLjYVoz, string YZEXscvHNLluUJ, int hgPHCmZbkFZ)
{
    string lQTArDsbTrKyQ = string("UXmiaNCcLwJKAMguVHQJluYwceTPOOQvkiPolNdwREnHGyFIvAsYtpQhLbqGUyVWSsQPRuBxbmVuBlLvULPwsvbdeUtmRmhqvHsAdsDPQRSfujOPYXZucdqrdBwoUdlTiiRDpOuPdtRiyMZidhAdyPHNoBcUvOfdFeZLQdEIxJWedHmlfarpgUCDqOQdhhXhXmIbjhN");
    int snrTGugIWpciMM = 1890436641;
    string gWGICJn = string("VlUAQzWwMZXcZlwZLHofyWnqieuTMxMvfPnXMEoNMosGrmcVVCgMijDuJveuXAINSLJCpPzkneQgvataZEileVvUJtMhEuwGUiwJMeEhjftSMyzrEqnWDXkXsjpaPIXVetSK");
    double UAGtqjoWvfTIca = 817719.3555824418;
    int iaUTA = 511609428;
    bool lNDAfmi = false;
    double Nmnra = -669090.7775945881;

    for (int gmwFiMfUE = 45557240; gmwFiMfUE > 0; gmwFiMfUE--) {
        YZEXscvHNLluUJ += ZgLjYVoz;
        lQTArDsbTrKyQ = gWGICJn;
    }

    if (lNDAfmi != true) {
        for (int USdEkM = 2056495396; USdEkM > 0; USdEkM--) {
            lQTArDsbTrKyQ = ZgLjYVoz;
            QoKBNNsld = QoKBNNsld;
        }
    }

    for (int GaIjuG = 648033833; GaIjuG > 0; GaIjuG--) {
        gWGICJn = ZgLjYVoz;
        lNDAfmi = ! lNDAfmi;
    }

    for (int dgceBnAmbL = 1531591414; dgceBnAmbL > 0; dgceBnAmbL--) {
        continue;
    }

    return lNDAfmi;
}

double vniMvWLD::gnIPLQe(bool QOTJD)
{
    string XbrER = string("ivXJ");
    int FtkWB = -972192482;

    if (FtkWB > -972192482) {
        for (int eqsHqIn = 1391235619; eqsHqIn > 0; eqsHqIn--) {
            continue;
        }
    }

    for (int AqnjDyamzRfhE = 270245701; AqnjDyamzRfhE > 0; AqnjDyamzRfhE--) {
        QOTJD = QOTJD;
    }

    if (QOTJD != true) {
        for (int witNuJHuooAiRyM = 86811174; witNuJHuooAiRyM > 0; witNuJHuooAiRyM--) {
            FtkWB /= FtkWB;
            QOTJD = ! QOTJD;
        }
    }

    return -469738.69171283796;
}

bool vniMvWLD::xXLYCTZEQTfvRvTH(int uBWSGWxW, string tyGRZXIs)
{
    double llYWAtVOc = 992449.4863479115;
    int KqHkm = 825473037;

    for (int pIHxzdbEmre = 433618885; pIHxzdbEmre > 0; pIHxzdbEmre--) {
        KqHkm = KqHkm;
        KqHkm /= uBWSGWxW;
        llYWAtVOc *= llYWAtVOc;
        KqHkm += KqHkm;
    }

    for (int UfQAz = 822528059; UfQAz > 0; UfQAz--) {
        continue;
    }

    if (uBWSGWxW > -1648766795) {
        for (int PNkzNwcAQhDtTxw = 1546406864; PNkzNwcAQhDtTxw > 0; PNkzNwcAQhDtTxw--) {
            uBWSGWxW /= KqHkm;
            KqHkm = KqHkm;
            llYWAtVOc = llYWAtVOc;
            llYWAtVOc /= llYWAtVOc;
        }
    }

    for (int cGtTWmDXTEYRWpzp = 280105071; cGtTWmDXTEYRWpzp > 0; cGtTWmDXTEYRWpzp--) {
        llYWAtVOc += llYWAtVOc;
        uBWSGWxW = KqHkm;
        KqHkm /= uBWSGWxW;
        uBWSGWxW /= KqHkm;
    }

    if (KqHkm > 825473037) {
        for (int pEaPXXrFV = 1906577061; pEaPXXrFV > 0; pEaPXXrFV--) {
            uBWSGWxW *= uBWSGWxW;
            KqHkm *= KqHkm;
        }
    }

    return true;
}

int vniMvWLD::DRwVZcWKeP(string IlCpZN, double BfnfwdqVbVFPlzvG, bool GFJVMV, double xnwIfRrT, int zVxgT)
{
    int gNWFNnecAfB = 670671287;
    int YUplLQX = 453642007;
    bool uArNUCHLnVdOpGQ = true;
    double EmPerRN = 577053.9770636718;
    string qIRpvNjHFNeKtPIQ = string("XXWiVMzsMQGRvYNHMrKtMmhlJPVVLKeqnRaDfmMqUQqtYFHrIHUeXBEeeAWwQWdsZLGCRFQtHWasToXEhDVZuPNJEOAXEITDdAu");
    bool yJFXKCCiNBkgGubA = false;
    bool LfZOYjKExj = true;
    double uzjmxxyxaRRA = -48957.56526874474;

    for (int cbjINI = 182291166; cbjINI > 0; cbjINI--) {
        xnwIfRrT *= uzjmxxyxaRRA;
        YUplLQX *= zVxgT;
    }

    if (yJFXKCCiNBkgGubA == true) {
        for (int VjQEPHZI = 611581017; VjQEPHZI > 0; VjQEPHZI--) {
            IlCpZN += IlCpZN;
        }
    }

    if (yJFXKCCiNBkgGubA != false) {
        for (int dyaLcsmJOsR = 1956148565; dyaLcsmJOsR > 0; dyaLcsmJOsR--) {
            uzjmxxyxaRRA *= BfnfwdqVbVFPlzvG;
            BfnfwdqVbVFPlzvG *= BfnfwdqVbVFPlzvG;
        }
    }

    return YUplLQX;
}

double vniMvWLD::KwhDpWCxGVUTMa(int QrntEeTCpEGLDvKF, string LvfFcz, bool ZkCpFLvyGnT)
{
    string fjscWlTewbGs = string("GPMlMkcglUvkLhASBYNSdvBkTouVYvvWOHqBUqjBTAIqNezTcFULfqqaczmCnKeDxQyeMGHJDMUpmWXQOLlvtFlBnPzedENutrkxJorlFfUYVmchMYSUPtCitghEbhkATDZLGUPQevDjCuBnSKebv");
    int swiLImVeBTvQe = 1548600539;
    int XklmdChnJVmdmNsq = -850801200;
    int eduvYGm = 1564652725;
    int LnQcwHYHEYAWhr = 1357459297;
    string esttiIqPScy = string("jeBGTGMkrpuRwjkeMQrAQbPWTDclICPLKcmCnvvaVGWHMyVQxvcbaeODZgYfOuOATEfddWPkBUAmSfOXcBsboCcKTRVAffDdYJDuFkzN");
    string sgpoSDuxUq = string("gChwYwCIjicylLQdMpnhCIWDsOTgUMkpVMCqTqFPUkZVMpdWLwcmwmXsgtyPylPhrEmieMWbcohQDmkwgSv");
    double JRybSI = -409699.65363270097;
    double vrwcemE = -972915.068817184;
    string nfzSwvdgLdVcnX = string("saecdwLtxhnHfPAEUxttCCvXxBNmMQApLBvCIKCLSKuYLKpcsbgjsXHKnaQsEviXQgCourVKcCNaioucOxCmIXlrrszGOnEkFSGabCOOWyVrWxafXzgJLelRJGUKpcFpBIiRQkyjmNKjDFvCAMuYqaxQTYwbiwHHzPYHRArEDtggQwhBHxAwbaODZKjvKMcNyiuZluYHlFMETGJZCgQnYdbhbtVdrZrqTjxCF");

    return vrwcemE;
}

void vniMvWLD::dEnqteWrxv(double ucLOueHyAOIwfJ, string rndMqgQjIGbvpNRI)
{
    int PFiViKPl = -1405438192;
    double xEOJMhKQSnAhn = 1009242.8145065871;
    bool XZQZaJatTWIh = true;
    string srCNvAf = string("QkiZhRTBDNzqpcaDNGTEHyFoOniYlrRjRldOspBUJQPWYXjMyEzczKpevVhCQhhWBqSHNPAUEFGNoswwScImRAZEWAJLOBhvWlJJHPzvyoIGQCuKlIpTyAMqfwIgeflfZMCWeRTDyzRRg");
    double kGXYMaUOrZO = -424710.16864222067;
    int cEduuJ = -1258722028;

    for (int LgxiXdDONxzvkX = 760896526; LgxiXdDONxzvkX > 0; LgxiXdDONxzvkX--) {
        PFiViKPl /= PFiViKPl;
        kGXYMaUOrZO = ucLOueHyAOIwfJ;
        cEduuJ *= PFiViKPl;
    }
}

void vniMvWLD::oBCenbqqov(int gjPMKVvQVGdMqHm, bool tbMbIQok, bool oKauU)
{
    bool ksiyESJqE = false;
    string pgaRF = string("wPDBAJLURZrIoOpmbhqKcomTlRsMtXBTLwTEOYCzVpTdVAWRzfZcnuqJlsvOvdBtOFYgEgNVpBrMCErkEnRomvaljbDENQwFpAnfOWktMDRlPyCgJzgfxiVKpVEhurMNbZvZsNkQyccEcxkIpHRgKfv");
    int wZBRQdsJF = -964518681;

    for (int rXbxOuJQkabm = 1254242088; rXbxOuJQkabm > 0; rXbxOuJQkabm--) {
        oKauU = ! oKauU;
        tbMbIQok = ksiyESJqE;
        gjPMKVvQVGdMqHm += gjPMKVvQVGdMqHm;
        oKauU = ! ksiyESJqE;
    }

    if (ksiyESJqE != true) {
        for (int WXgKuDmGWZ = 1087060925; WXgKuDmGWZ > 0; WXgKuDmGWZ--) {
            oKauU = ! ksiyESJqE;
            tbMbIQok = oKauU;
        }
    }

    for (int xoXMizRWalPhPdGL = 556792910; xoXMizRWalPhPdGL > 0; xoXMizRWalPhPdGL--) {
        gjPMKVvQVGdMqHm /= gjPMKVvQVGdMqHm;
        pgaRF += pgaRF;
    }

    if (ksiyESJqE == true) {
        for (int QdDmoOb = 159918141; QdDmoOb > 0; QdDmoOb--) {
            oKauU = ! ksiyESJqE;
            oKauU = ! oKauU;
            tbMbIQok = ! ksiyESJqE;
        }
    }

    if (gjPMKVvQVGdMqHm != -964518681) {
        for (int lclLdykDlnSJa = 779261289; lclLdykDlnSJa > 0; lclLdykDlnSJa--) {
            tbMbIQok = oKauU;
            oKauU = ksiyESJqE;
            wZBRQdsJF /= wZBRQdsJF;
        }
    }

    for (int nxzEHDpEuRDIXk = 1122278963; nxzEHDpEuRDIXk > 0; nxzEHDpEuRDIXk--) {
        wZBRQdsJF += gjPMKVvQVGdMqHm;
        oKauU = ! tbMbIQok;
    }
}

string vniMvWLD::yJfcpKplt(int qhWfhddWl, string cVciZrnVS, bool GjYDGQeOid)
{
    int zOAbdkNb = -803754142;
    int GXWLpNHrIBvZQO = -691618115;
    bool cShsBSDUYCdTOE = false;
    int ZGXIZoFqxB = 595196058;

    if (ZGXIZoFqxB >= -691618115) {
        for (int wKzcrvHW = 96807276; wKzcrvHW > 0; wKzcrvHW--) {
            zOAbdkNb -= qhWfhddWl;
            zOAbdkNb *= GXWLpNHrIBvZQO;
            zOAbdkNb -= ZGXIZoFqxB;
            GXWLpNHrIBvZQO /= qhWfhddWl;
            cShsBSDUYCdTOE = ! GjYDGQeOid;
            zOAbdkNb -= GXWLpNHrIBvZQO;
        }
    }

    for (int BebdED = 1808958333; BebdED > 0; BebdED--) {
        ZGXIZoFqxB += GXWLpNHrIBvZQO;
    }

    return cVciZrnVS;
}

double vniMvWLD::toLlraxAuDLDj(int KReAsxTNCATetDFD)
{
    bool IIbUgBsns = true;
    string AgjYTlCUohLNm = string("BjHjHgDnTjCwPgrLeNvPXefyjtbaRzxjyKTUQgqCGvtbeMPGeCMFKnpbcJpHAltPnFMiUjTYZWkfCWJutqltXdduzsAqSdEMfHnkjkjVQiapEMFKZRIaPplSGRZnB");
    int AgXjibFvnpSa = -56629788;
    int jdmjkLzNaeaAAf = 1798310327;
    bool FwuIQJNpq = true;
    double aMbsXi = 37456.049295353536;
    bool FrTSdF = false;

    for (int BdwCuIPzGFWBc = 2058661126; BdwCuIPzGFWBc > 0; BdwCuIPzGFWBc--) {
        FwuIQJNpq = FwuIQJNpq;
        FrTSdF = FwuIQJNpq;
        KReAsxTNCATetDFD /= KReAsxTNCATetDFD;
    }

    for (int JHtDz = 1397370040; JHtDz > 0; JHtDz--) {
        IIbUgBsns = ! FrTSdF;
    }

    if (AgXjibFvnpSa == -56629788) {
        for (int akwdJJ = 1659441759; akwdJJ > 0; akwdJJ--) {
            AgXjibFvnpSa += KReAsxTNCATetDFD;
        }
    }

    for (int utTRkvzlD = 887882335; utTRkvzlD > 0; utTRkvzlD--) {
        AgXjibFvnpSa -= AgXjibFvnpSa;
        IIbUgBsns = FwuIQJNpq;
        FrTSdF = ! IIbUgBsns;
        IIbUgBsns = IIbUgBsns;
    }

    for (int ZLNxbCGncuPghO = 379171176; ZLNxbCGncuPghO > 0; ZLNxbCGncuPghO--) {
        AgjYTlCUohLNm = AgjYTlCUohLNm;
        KReAsxTNCATetDFD += jdmjkLzNaeaAAf;
    }

    return aMbsXi;
}

int vniMvWLD::OQILQDit()
{
    double IyGRSN = 78669.03727933666;

    if (IyGRSN == 78669.03727933666) {
        for (int MpiFNab = 1576172838; MpiFNab > 0; MpiFNab--) {
            IyGRSN /= IyGRSN;
            IyGRSN *= IyGRSN;
            IyGRSN += IyGRSN;
            IyGRSN /= IyGRSN;
            IyGRSN /= IyGRSN;
            IyGRSN -= IyGRSN;
            IyGRSN -= IyGRSN;
            IyGRSN += IyGRSN;
            IyGRSN = IyGRSN;
            IyGRSN = IyGRSN;
        }
    }

    return 807952425;
}

int vniMvWLD::sbfcsBqBrwlFpNka()
{
    double UHYoBLLaTsbyG = -95787.12623420327;
    int VsdFsfIfoJsgSBeE = 1639241213;
    string tecUKPGqeJ = string("vKatSKQwwhLlTaIyXdcZwymPdDVgiWSAbpUUbBVnYknjzbrDiDoHoKbJUGUSVBIgAwudFjeOvkvWcBjujV");
    bool pZbXEENwkaxNuGwc = false;
    bool pRPBaZ = true;
    bool PLXjDvcPybkdqZK = true;
    double DMvQKpZDvyeJ = 953929.6493279412;
    string hkSpMEWKcnc = string("LhSPjlwVjnHHDPJQyzeeFyCNANlTVkdTKfHGlcitH");

    if (hkSpMEWKcnc != string("LhSPjlwVjnHHDPJQyzeeFyCNANlTVkdTKfHGlcitH")) {
        for (int ppVhWuUykSC = 287997272; ppVhWuUykSC > 0; ppVhWuUykSC--) {
            DMvQKpZDvyeJ -= DMvQKpZDvyeJ;
            PLXjDvcPybkdqZK = ! pZbXEENwkaxNuGwc;
            UHYoBLLaTsbyG -= DMvQKpZDvyeJ;
            hkSpMEWKcnc += hkSpMEWKcnc;
        }
    }

    return VsdFsfIfoJsgSBeE;
}

double vniMvWLD::SJUVESPfp(string WQIUkmDpSqFAfar, string tjryJuQeyyR, bool DwKEcHptfwA)
{
    int NyBzJ = 958084024;
    string hBeCVFrlnTX = string("dayJzLdpcNBBHSJyYXxrtJhaozGsusYqKQrSuyfEqfvYwUKJXxKgUqTFfLALqJssVDZXHwRqYpyQzxxSOMzOMNZSagciZlrFiJJSkaGULULtiyaaGLATIRkJBEYdphUGCauXArwoKefpmcDSgYQsBBDnZlQFOqUms");
    double SHbMVNb = -657314.1780343615;
    bool UEGfv = false;
    string xfZqGZyQvDGczj = string("VKhkunQdxQbklKBXduMfLcnkYqrXCLLMOWltadhMQfMZZnicWlPYoFyPPDPAVCvSUKRiiDidBpSkYhKGXkhbWMKkzcBZmQgxEwCtnJ");
    int opaMZJWobZgs = -886762763;
    bool HsxoYnb = true;
    double LhhjDD = 709590.7517312517;

    for (int MonuJWowCO = 226762345; MonuJWowCO > 0; MonuJWowCO--) {
        HsxoYnb = ! DwKEcHptfwA;
        tjryJuQeyyR = WQIUkmDpSqFAfar;
        NyBzJ -= opaMZJWobZgs;
        WQIUkmDpSqFAfar = WQIUkmDpSqFAfar;
    }

    return LhhjDD;
}

vniMvWLD::vniMvWLD()
{
    this->tvrSIEejElu(true, 434892261, string("dTYeisdiRpLajfwHRmnjkqGZCGebLQGNYkvRihPjbQfQpnYwBeISkpcYmAhWOFgQfohUPMCbJIyTabSsdyFnRBLzuijVrUvZHWZwqPEihjwmnzsuZRZRPgbQKPGoPwACnjKZbiaAzhEDtFtFDJVJynmUSNhYbHIStDwTehDmlUUuKjajvOcbyMLpgPRfVICFZutYcefUdHeYuhJXzzAgGBThMFiCoumGfhxYzPoqUATJqr"), true);
    this->pznjdJybkgodWX(true, string("dcoNarcErOTNDTnZdjHLmrsmllafVjWMgOjFVPkNzLHRaelxANkVeILfTNBANvHQJpFhshZtpofFkvFAAkJgBzWrwUaJvr"), 652475.5101899926);
    this->VqmUVaI(1236813593, 1202296853);
    this->RQmOtdjPU(true, string("iXVaMIWIxAfoWQfrzFMDqjcwvsMZJonFERXsZVkpDHVHustwyxTVyOlOkWkpNvgwdiWVflrriKLzqRsmgQLsnjHPcestFvwVPfZXSoGWwUtbHDAmysWLOSCrMRolpDLaEJMkCrVwwcyIpddtSPsPOFIYNWWifBcKfSGIVJCZRQtInFTTHCuSDXsyaWcRcHBlThNIElOdaFjCTvyIbocvEqqYDHpQSpbgkNjOhZE"), string("hicMKIvxTnPfhfwPLTmEWyPqtg"), -782409365);
    this->gnIPLQe(true);
    this->xXLYCTZEQTfvRvTH(-1648766795, string("FmTCpvFYywiQOZSxDPMiZCPekpvICzivHJLOuLHNLLfPlfbmCd"));
    this->DRwVZcWKeP(string("MkNydFHpeVghESAfvwvYglUGMYfbItxVypNGHqpkicAmldGfnvXRzjGHSLXrfyeRhjhnOFmwqfmMqjyclGTZgWUTwsiRazrVxgJmfaqFxTVKLaYUzUnDBPFWCYQtCncIPBJkBFoNYZhgfeogNQPQBlWNgSiZPmhiyZxXcSkHWPCvXpwbuYLCdjzEpeGYyckVXqivZvGuuIQiLOGvCRgDIPiAXEBsFgsT"), 202780.07158670452, false, 272742.636140757, 158669519);
    this->KwhDpWCxGVUTMa(-2055933322, string("gIllrDrlFSAGnwwImvZsocHiHnunyFLVBAPqhPZkVpvKuyqjxxRXSqksdPTYEnOKXixSzkqqlRaHNfpCoSxAKhpoKsjfNwgSyJEYJiPdCAHDxsyFYYCJobIEtXAmoBjEysJiyVdDtknyrKZwkyqZqGnKSEyEUCOzDRLIkUgOgwjbXMFTvCXGHLoQoHNbgfnLyldOxCCRXWaOPmgZIWzUXCGGFHBmKjJuRoEisAnDqJfEeqA"), false);
    this->dEnqteWrxv(819230.4169226215, string("RuefWIfaLbkDylTrwMlWZvqFaOZxuriWEHwRnUfnteqoNzYdBpgoKlxilwCQtudXjgOkBqefdQwCTXXAJWqwfBDNJdUrZDXBRBALHvuyajzWnYltdxyq"));
    this->oBCenbqqov(556354279, true, false);
    this->yJfcpKplt(1416568515, string("OXNWPftkbMdCZIUXAlIEdGsJxSQiBzvFVHEzMguKNWcrCdEJVGXsbTJsNWWcWNfsUxmREPeovqRpARPCNvgPrPVThjHKIqiDJzpKJAtIsZXiHGJNFlOBPSaqTNhlOZFrxfTgpTUcsiqcCRBnQffJhzNLcmvKZVHgpoDQCbTSJzVyRBYgRurefFFWZQhliEfpNBPrRohAPSkjPAygzqRGOfSxJLvbkyNnJWsOuJqGrnfzozQoeaxvGcORtAcy"), false);
    this->toLlraxAuDLDj(-1280081161);
    this->OQILQDit();
    this->sbfcsBqBrwlFpNka();
    this->SJUVESPfp(string("lkmMznzJEbIGiDEjgaZcoXGxvAhmhNDBMwZDssCgufMZEiTqEXDPzDDhBkcowlXyNvKyrQKfMxXYHMKJLeFuYAtIWdFEJwpzhYtmJFLugoEtjTabkkQxFnqM"), string("tkuSqRCLPDmKYfwa"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DcZWUCqtgJuuhGX
{
public:
    string bYxoTpwygQR;
    int KcLbYlXuCO;
    string hdXIUB;
    bool YCXkRnRbp;

    DcZWUCqtgJuuhGX();
protected:
    int lmAXmg;

    double wbnKIHiI(double LHACPUAXBl, double tlGUwvSLNuvkb, double jBnlVxSxAtv);
    double noWEWYWlZRwf(int ipFtQmixYpmXZz, double zrhEEivWBhXFditz, string VDPeqhMXadkFfxgU);
    int sgyAlsspcz(string zzUUtpPxVG, bool qvwOFOZ, bool JePnlHBN, double wTAHFKFbeO, bool SzlSy);
    void MDGSOWdjZMB(bool dLfWLYqGZDlSEa, double omIaGFMguAzOPFgD, double ZppGkDuZjQcd, bool cdIgQ);
    string KOoceOLps(int INboHvnFsomS, int YfsheZF);
    void QVIQrNyeBQDYTRpm(bool kwNCMm, int rvKvzQPFx);
private:
    double IuJVBQBih;
    string WgbcHqXRoxaEYe;
    int nzlegEvHyhqMg;
    double dZcaPT;
    double lAWoiY;

};

double DcZWUCqtgJuuhGX::wbnKIHiI(double LHACPUAXBl, double tlGUwvSLNuvkb, double jBnlVxSxAtv)
{
    string EITiaaKXHNog = string("nwHWDGMtSeAyfFpBSqNnIWGryFPbeUSZXKnekdohezMqbAtfCBtdeJZsztchqpRsJuedbDqVzqxjVrMnXFhVyeWJLRIQXgEobQxSftBIKTYWfCFdyKQKyeZkpEqBiaavWwOYdLsnklKkQXPlLSGpDSVKRlHnYBJTaOodJvtkGyrZEEkYTyVDRInuvPZNFZdiTkONpPMswYaIDPBkVNaJlQZbuSjNMfqMRhVSOciljZoWOrjFOiJvF");
    string IpYnmikaw = string("NPIaGdztCqAYcFlBohgA");

    for (int HmoekFPXmXKOKD = 1418050200; HmoekFPXmXKOKD > 0; HmoekFPXmXKOKD--) {
        LHACPUAXBl /= jBnlVxSxAtv;
        LHACPUAXBl /= LHACPUAXBl;
        jBnlVxSxAtv *= jBnlVxSxAtv;
    }

    for (int ApcqQILq = 130385565; ApcqQILq > 0; ApcqQILq--) {
        continue;
    }

    if (LHACPUAXBl > -431643.95290934516) {
        for (int LksDeXZSswaq = 1365520512; LksDeXZSswaq > 0; LksDeXZSswaq--) {
            IpYnmikaw += EITiaaKXHNog;
            jBnlVxSxAtv -= LHACPUAXBl;
            tlGUwvSLNuvkb -= tlGUwvSLNuvkb;
            LHACPUAXBl = LHACPUAXBl;
            tlGUwvSLNuvkb -= jBnlVxSxAtv;
        }
    }

    if (tlGUwvSLNuvkb < -431643.95290934516) {
        for (int OFcoIayPukQ = 880491579; OFcoIayPukQ > 0; OFcoIayPukQ--) {
            EITiaaKXHNog = EITiaaKXHNog;
            LHACPUAXBl -= jBnlVxSxAtv;
            LHACPUAXBl -= jBnlVxSxAtv;
        }
    }

    return jBnlVxSxAtv;
}

double DcZWUCqtgJuuhGX::noWEWYWlZRwf(int ipFtQmixYpmXZz, double zrhEEivWBhXFditz, string VDPeqhMXadkFfxgU)
{
    string sgQlqYQfxgTPxfrq = string("MWIpWudOWLwXfjUoLcCWHayUsZxSCUaymyoPWIJsnfYDcTtaGvJtdilCZPAVqnxVYabhJgPSAcPvYHpLYyQtWFTZUPNsRhXpHwCufuwpZUHEWlVQXAHQfFFkLLaZfmNTkBcCNsscdjWOaNuDmZexEMvvAesfHKFStvjBzaAwxSLLbbzrHPAqVlxMMIGjMstyCQRl");
    string bCTLWzn = string("ybUsNHDVHSrySAavkgyAxdNhnBvJMtKdQzWJpQPuDrXxqEqHPlviTmh");
    bool hHhaXdIDtJAFbBFS = true;
    string ZnRXeoRyF = string("hthvDUwggvJKrHcnNnyLmJKqBbUyKlrGCkrbvVIMgHABpMlxmtmCJvQMAbjHRFmkHTxfFPwWhWxgPNgvl");

    if (ZnRXeoRyF > string("hthvDUwggvJKrHcnNnyLmJKqBbUyKlrGCkrbvVIMgHABpMlxmtmCJvQMAbjHRFmkHTxfFPwWhWxgPNgvl")) {
        for (int ozPadRgUPQvTO = 1721035133; ozPadRgUPQvTO > 0; ozPadRgUPQvTO--) {
            bCTLWzn += VDPeqhMXadkFfxgU;
            sgQlqYQfxgTPxfrq = ZnRXeoRyF;
        }
    }

    if (bCTLWzn != string("hthvDUwggvJKrHcnNnyLmJKqBbUyKlrGCkrbvVIMgHABpMlxmtmCJvQMAbjHRFmkHTxfFPwWhWxgPNgvl")) {
        for (int IzbTnroygPfE = 1830048708; IzbTnroygPfE > 0; IzbTnroygPfE--) {
            ZnRXeoRyF += VDPeqhMXadkFfxgU;
            sgQlqYQfxgTPxfrq += sgQlqYQfxgTPxfrq;
            bCTLWzn = bCTLWzn;
            bCTLWzn += sgQlqYQfxgTPxfrq;
            ipFtQmixYpmXZz *= ipFtQmixYpmXZz;
        }
    }

    return zrhEEivWBhXFditz;
}

int DcZWUCqtgJuuhGX::sgyAlsspcz(string zzUUtpPxVG, bool qvwOFOZ, bool JePnlHBN, double wTAHFKFbeO, bool SzlSy)
{
    int rEtfAJhWYFn = -944626605;
    int ewveeFAlaa = -805138701;
    int aGkYaKAQSlyAG = -1223726746;
    bool bKUlvO = true;
    string ShVIbkgUkSmTvRFt = string("ElDojCJJyqEaoFGZcjYfyRQGucczisfbxWYGgkrKRSsdvDGuMOmNstnCPXDWJcfHPYkcXCycTaoAHCAUbRHpAuXRcqVSOCTgwGFdlIpuhRDdCSemAMigWebJcMdAYrDiCeDpzQWkdPRMVXhCOXmUCWwwDWNQdnuEBQBqSNLzgsgnZCWcdoPjuGrKAiNhjcYKW");

    for (int HMzlxPadLKPwDkNs = 1072622610; HMzlxPadLKPwDkNs > 0; HMzlxPadLKPwDkNs--) {
        ewveeFAlaa /= aGkYaKAQSlyAG;
        SzlSy = JePnlHBN;
        rEtfAJhWYFn /= ewveeFAlaa;
    }

    for (int YEYQFJeHoieQpEEB = 377072453; YEYQFJeHoieQpEEB > 0; YEYQFJeHoieQpEEB--) {
        continue;
    }

    if (SzlSy == false) {
        for (int KGRcHoFLnZ = 933873669; KGRcHoFLnZ > 0; KGRcHoFLnZ--) {
            JePnlHBN = ! JePnlHBN;
            ewveeFAlaa *= aGkYaKAQSlyAG;
        }
    }

    return aGkYaKAQSlyAG;
}

void DcZWUCqtgJuuhGX::MDGSOWdjZMB(bool dLfWLYqGZDlSEa, double omIaGFMguAzOPFgD, double ZppGkDuZjQcd, bool cdIgQ)
{
    bool gxUKPxxvum = true;
    double qPfmLIXH = 37206.09852235464;
    int cGmeZoeXqzRm = 785709077;
    bool TOashBBIOhWv = true;
    int GJLDxytG = 151967699;
    double QoztgSyeYZEgXH = 479258.2624118697;
    int hLCQfeJjnd = 498174779;
    bool qSEvTYqOXcarKk = true;

    for (int dPbcLsYvnM = 2086550156; dPbcLsYvnM > 0; dPbcLsYvnM--) {
        continue;
    }
}

string DcZWUCqtgJuuhGX::KOoceOLps(int INboHvnFsomS, int YfsheZF)
{
    string VxKFFVldJY = string("KkAmvVBUflBLWQpOYTeKlwxrkxGQhVSOdKyeMKLdHxQdyDvWHAmBEfUmKDOcFrTpVBkmcIkqRr");
    bool ejmIIhcmlNR = true;
    bool FrZddrSvXg = false;
    string XReECAPB = string("StyPMTBrGqa");
    int XzRachpSDzXFqZa = 2028164217;
    string cBGNVexEKJj = string("DLnKkGVplaXEYgucTRgefHcdrJxRQyTFELXphGwSmwuFsJoSzDuzpDOQEF");

    for (int hKEihPPmgWiBTW = 1373406618; hKEihPPmgWiBTW > 0; hKEihPPmgWiBTW--) {
        continue;
    }

    for (int rXKXJuQiBVRdRAAZ = 918737261; rXKXJuQiBVRdRAAZ > 0; rXKXJuQiBVRdRAAZ--) {
        FrZddrSvXg = ! ejmIIhcmlNR;
        FrZddrSvXg = FrZddrSvXg;
    }

    if (YfsheZF != 2017797190) {
        for (int DsRYXCaKoZ = 911129279; DsRYXCaKoZ > 0; DsRYXCaKoZ--) {
            ejmIIhcmlNR = ! FrZddrSvXg;
        }
    }

    for (int wNlqivLJDAIpx = 1305003624; wNlqivLJDAIpx > 0; wNlqivLJDAIpx--) {
        XzRachpSDzXFqZa /= YfsheZF;
        INboHvnFsomS -= XzRachpSDzXFqZa;
        VxKFFVldJY = cBGNVexEKJj;
    }

    for (int fGgcmirZX = 248701083; fGgcmirZX > 0; fGgcmirZX--) {
        XzRachpSDzXFqZa *= XzRachpSDzXFqZa;
    }

    return cBGNVexEKJj;
}

void DcZWUCqtgJuuhGX::QVIQrNyeBQDYTRpm(bool kwNCMm, int rvKvzQPFx)
{
    int uAbINUsekzV = 1638612102;
    bool iLUwauXNJAssacyB = true;
    double ePaVqZIWsiufaq = 982798.3853600125;
    string eXkbCxrbPBi = string("SRygrmwysWQMxfXNYplSMHlUxWuBpIkVaJeYVyWwJrNCwjXBmyyQnSIKsnuaZteUqxTcOAJdVIZZhYYeqfMEnIKIVMeynYLRCycqqeodVoJBYWncSfiNHUpdjHbgFCHgZVPmuPheeLTagbqwuMrJfrej");
    string wcxRWQ = string("RylIighyXJQZSTRbjBBNkxCheYQiXROODgEmyXEZzvvggkQBQzwiIFLhysaaGeOnEQJqGycBcZmRjuPlUPZwhVULQlgdupozLlPZrTiPwXSEmlkmwyFvhPBxpcOgnvZQbBsYJxwADmWXWMUrdSSRaLhUOJAmuEndmySUdOIVJXIplkYjekDjoozDCJWLbnBAksPLs");

    for (int kWmAlyBzYw = 1663015232; kWmAlyBzYw > 0; kWmAlyBzYw--) {
        iLUwauXNJAssacyB = kwNCMm;
        ePaVqZIWsiufaq -= ePaVqZIWsiufaq;
    }

    if (ePaVqZIWsiufaq <= 982798.3853600125) {
        for (int tDXeAEZXy = 1766126983; tDXeAEZXy > 0; tDXeAEZXy--) {
            eXkbCxrbPBi = eXkbCxrbPBi;
            kwNCMm = iLUwauXNJAssacyB;
        }
    }

    for (int MyTfOZSHUDJR = 906789145; MyTfOZSHUDJR > 0; MyTfOZSHUDJR--) {
        continue;
    }

    for (int pgiztWsGug = 1869061951; pgiztWsGug > 0; pgiztWsGug--) {
        uAbINUsekzV += rvKvzQPFx;
        ePaVqZIWsiufaq = ePaVqZIWsiufaq;
        wcxRWQ = wcxRWQ;
        kwNCMm = ! kwNCMm;
    }
}

DcZWUCqtgJuuhGX::DcZWUCqtgJuuhGX()
{
    this->wbnKIHiI(-431643.95290934516, -233128.0301164701, -523432.75465673074);
    this->noWEWYWlZRwf(901543517, 734740.1650057238, string("ocjdCpZKAmUPoeyHyEFlQXhgmUGpRTHOdklOmreSJioZyxDbgcHOxRDPwkTLHBDurQUExKLtbtlkzwRfFHUvmuIhTqjUXzgDUzeYfbtFhgyepXcdbhFKkNekaAelznOSsRmJRJTZbyqJvixLbwYRGZYZIunDnpuxmOAjcIMnrTNJimmOhdTiLAoEydAUWpNpXLRVBwTxljFCIlGfZWSeDjzGnGLRvlNntBQaKQmxTNSoeBHw"));
    this->sgyAlsspcz(string("ZrToSxpLebTkEXpBZSjpqPlf"), false, false, 284114.8506054364, false);
    this->MDGSOWdjZMB(true, -301496.8760801381, -482576.0590320059, false);
    this->KOoceOLps(2017797190, 1857505849);
    this->QVIQrNyeBQDYTRpm(false, 856779506);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OHzHmXcpwc
{
public:
    string uXKrz;
    bool NZXPKkDwsaVIzh;
    string IuEtgOtBZofwnqo;

    OHzHmXcpwc();
    int BkwaCwXtp();
    double vPEuDHm(int MvZJzU);
    void jJBDK(string ydqrCGDUDPHqoe, string SSulmKnCBrHZTGJK, bool zCXrsqSxRybOYed, bool JMQbPByaDLBhglC, string xmkiRDzLOzNm);
protected:
    double ZBYHoGGEBJVUfWla;

    void hzeEgnLfOpV(int VNWtNf, bool LwdSCLtP, double bJhaLEvztgICbs, string TabmY);
private:
    string YkzCWK;
    string QDpgyJpriaWfl;

    string rXAkiJ(int aSdcamky, string IiMWUbMgF, int QglBkDCEsV, double yEIuTapSJPuPjfOj);
    int IuFLjTbvSLgdJ(int sPHGzvbhdAMbh, int gnktdqrVkxoFvNHf);
    double VbfUjpJixEC(bool vwOESj);
    double yZavW(int rMfPYRROnOufGn, double wAZspTOwAueVt, string PWrYZiffERxPYFXn, bool mCMEHeMgc);
    int YAMzaPpzq(string IAWiqNXNhKMi, string XsJFusBUbXNJfl);
    void EIHdFE(string NfIVsrLJjAyrQAUX, string BzuNLudNsLu, bool TYUVAwBmgcOrI);
    int wjXBQaTzL();
};

int OHzHmXcpwc::BkwaCwXtp()
{
    bool TraDSnHfDK = false;
    int PGrOXyR = 1610659649;
    bool YLFMZEERXLRWVrCz = false;

    for (int ujUohi = 1486609485; ujUohi > 0; ujUohi--) {
        TraDSnHfDK = YLFMZEERXLRWVrCz;
    }

    if (TraDSnHfDK != false) {
        for (int wetRvubdvvU = 177826809; wetRvubdvvU > 0; wetRvubdvvU--) {
            TraDSnHfDK = ! TraDSnHfDK;
            YLFMZEERXLRWVrCz = ! TraDSnHfDK;
            TraDSnHfDK = TraDSnHfDK;
        }
    }

    return PGrOXyR;
}

double OHzHmXcpwc::vPEuDHm(int MvZJzU)
{
    string sIsahB = string("cAZyvTfpUTIsPzZVmeOkTCCuGNPuxzIiqIjrZebzUbCCAMHLasyTJbhgCNGuTNOccRChzZsPKTGpVmJRXIDsEetlwUnQCeeuKQtRDFMkcmkCWsKYvTVacAIWWyfIewvkUsbPSInOjAMwTCkslnGxDrPOLJnMxkSaYpXCPkiZELvZorEvGmsxWCShWKVsNEsXD");
    int ymDWfHkJtdTtk = 1901509330;

    if (MvZJzU != 1259730456) {
        for (int lnXvkRzFBMrCq = 1934284602; lnXvkRzFBMrCq > 0; lnXvkRzFBMrCq--) {
            MvZJzU /= MvZJzU;
            MvZJzU -= MvZJzU;
        }
    }

    if (MvZJzU <= 1259730456) {
        for (int AcYCTxZw = 347074686; AcYCTxZw > 0; AcYCTxZw--) {
            MvZJzU /= MvZJzU;
        }
    }

    return 780169.761031979;
}

void OHzHmXcpwc::jJBDK(string ydqrCGDUDPHqoe, string SSulmKnCBrHZTGJK, bool zCXrsqSxRybOYed, bool JMQbPByaDLBhglC, string xmkiRDzLOzNm)
{
    int fVxVGxQDiR = 79503828;

    for (int WyfNTIHBxkW = 2044918080; WyfNTIHBxkW > 0; WyfNTIHBxkW--) {
        fVxVGxQDiR += fVxVGxQDiR;
    }

    for (int NtukQzuXWs = 2013354480; NtukQzuXWs > 0; NtukQzuXWs--) {
        xmkiRDzLOzNm += ydqrCGDUDPHqoe;
        SSulmKnCBrHZTGJK += ydqrCGDUDPHqoe;
        JMQbPByaDLBhglC = ! zCXrsqSxRybOYed;
    }
}

void OHzHmXcpwc::hzeEgnLfOpV(int VNWtNf, bool LwdSCLtP, double bJhaLEvztgICbs, string TabmY)
{
    bool IEvLkPCS = false;
    double otlEnkkxmqzkdJk = -396901.21497505467;
    string wLqejhMMSJgjiuIi = string("xPaoEkuXcoWJVCgGVTFHExzCjZnHnpLIjBYbtrTDVHzSQtCuAOLVGRGHKwLNJbPIyzSHwBbhBeQmWPyLIWNsXUMsjghIKAxBWwUmWBgqPnmAhtSwkBqwqvxBV");
    int kVIAZNcv = -1817048874;
    int wQpXLWXlISkNhz = -1170413188;
    bool PaFlvoMiMly = true;

    for (int FWppGcVJAsQE = 880528787; FWppGcVJAsQE > 0; FWppGcVJAsQE--) {
        continue;
    }

    for (int oEyzRvpvwNmjB = 1780196452; oEyzRvpvwNmjB > 0; oEyzRvpvwNmjB--) {
        continue;
    }

    for (int QRyUfciZVcSUyoY = 1267922006; QRyUfciZVcSUyoY > 0; QRyUfciZVcSUyoY--) {
        VNWtNf -= kVIAZNcv;
    }
}

string OHzHmXcpwc::rXAkiJ(int aSdcamky, string IiMWUbMgF, int QglBkDCEsV, double yEIuTapSJPuPjfOj)
{
    int untfeDS = -1487881881;
    int DmyfpjLc = -1748443657;
    double hbqxIF = -899653.2506158137;
    double BPrXuIcxHrtreKE = 568027.4045206144;
    string JmDcq = string("OdlLKeWkSTGdgOqITcMWslSpbRtztjSSCiDsjeItsKlzLVCuDwkHkvsWNKNHdOHUVQkcKsOAKbxvmeJhhpeiaQAtGSix");
    double BRmPnqgyLat = 265622.5706612664;

    if (JmDcq <= string("OdlLKeWkSTGdgOqITcMWslSpbRtztjSSCiDsjeItsKlzLVCuDwkHkvsWNKNHdOHUVQkcKsOAKbxvmeJhhpeiaQAtGSix")) {
        for (int fYzofRk = 957526065; fYzofRk > 0; fYzofRk--) {
            continue;
        }
    }

    return JmDcq;
}

int OHzHmXcpwc::IuFLjTbvSLgdJ(int sPHGzvbhdAMbh, int gnktdqrVkxoFvNHf)
{
    double zpqVj = 173562.04683361415;
    int fkZFBAmjsPC = 2035214385;
    string kmqkzKmHVexTRx = string("fYshHqvwJhHyNsnyQHMxEptKHCkdYmTCDFngJzkteIYDyAjlvWRtsAIUizSmLqevuRuemZNyzCNWgBpjWBIXObXgtsskHoqHOOlPdKaxDqOlAluNCGuyxPZhBoRXoiLYXzqwDczWYqiAhCdTdrVGBLnrQlvogWEnriTvGLCzmBNdWeuKzUncILJzNTJmCZQjglxmU");
    string KfVMD = string("DSzThxhyinWXlSoLwJjzxRkegMRQelIoJDUmePVr");
    bool fJijPpWuh = false;
    int cGHtcrmGReTBg = -1299021612;
    int DoIlxvgne = -1032829652;
    double VcBQxFeULmZOWt = 563430.9384571629;

    for (int sQZBSEDEYec = 918733059; sQZBSEDEYec > 0; sQZBSEDEYec--) {
        continue;
    }

    if (VcBQxFeULmZOWt <= 173562.04683361415) {
        for (int DqmJaKKrOycXZ = 70310012; DqmJaKKrOycXZ > 0; DqmJaKKrOycXZ--) {
            continue;
        }
    }

    for (int wKMylUWAjyvGNWl = 674199032; wKMylUWAjyvGNWl > 0; wKMylUWAjyvGNWl--) {
        kmqkzKmHVexTRx += KfVMD;
        fkZFBAmjsPC /= DoIlxvgne;
        sPHGzvbhdAMbh *= sPHGzvbhdAMbh;
        gnktdqrVkxoFvNHf = gnktdqrVkxoFvNHf;
    }

    for (int XdtgfiQfZKAWyyNH = 740129115; XdtgfiQfZKAWyyNH > 0; XdtgfiQfZKAWyyNH--) {
        DoIlxvgne /= fkZFBAmjsPC;
        KfVMD = kmqkzKmHVexTRx;
    }

    if (sPHGzvbhdAMbh <= 2035214385) {
        for (int qJxJBVdG = 310282790; qJxJBVdG > 0; qJxJBVdG--) {
            fkZFBAmjsPC = gnktdqrVkxoFvNHf;
            cGHtcrmGReTBg -= gnktdqrVkxoFvNHf;
        }
    }

    for (int fnbOw = 797502562; fnbOw > 0; fnbOw--) {
        sPHGzvbhdAMbh *= cGHtcrmGReTBg;
    }

    if (cGHtcrmGReTBg >= 102158227) {
        for (int AYSjd = 1650293289; AYSjd > 0; AYSjd--) {
            fkZFBAmjsPC /= sPHGzvbhdAMbh;
            gnktdqrVkxoFvNHf /= fkZFBAmjsPC;
        }
    }

    return DoIlxvgne;
}

double OHzHmXcpwc::VbfUjpJixEC(bool vwOESj)
{
    string hvkgayHkGlOlwfW = string("rUxuVkNHLuBRdlJlwNenpHwYXwAaKll");
    int FHVHZYa = 474202002;
    string sIByfwNouUAg = string("vjze");

    if (hvkgayHkGlOlwfW != string("vjze")) {
        for (int CTNSObxvzmLXYZf = 1251995196; CTNSObxvzmLXYZf > 0; CTNSObxvzmLXYZf--) {
            sIByfwNouUAg = sIByfwNouUAg;
            hvkgayHkGlOlwfW = sIByfwNouUAg;
            sIByfwNouUAg = hvkgayHkGlOlwfW;
        }
    }

    if (hvkgayHkGlOlwfW == string("rUxuVkNHLuBRdlJlwNenpHwYXwAaKll")) {
        for (int jtuTVxeLJdw = 2079794528; jtuTVxeLJdw > 0; jtuTVxeLJdw--) {
            hvkgayHkGlOlwfW = sIByfwNouUAg;
        }
    }

    if (sIByfwNouUAg != string("vjze")) {
        for (int HvFkfBalQEwLR = 600273671; HvFkfBalQEwLR > 0; HvFkfBalQEwLR--) {
            FHVHZYa -= FHVHZYa;
        }
    }

    if (sIByfwNouUAg <= string("vjze")) {
        for (int VPuIDHzPVuw = 1519751931; VPuIDHzPVuw > 0; VPuIDHzPVuw--) {
            vwOESj = vwOESj;
            hvkgayHkGlOlwfW += sIByfwNouUAg;
            hvkgayHkGlOlwfW = hvkgayHkGlOlwfW;
            FHVHZYa = FHVHZYa;
            sIByfwNouUAg = hvkgayHkGlOlwfW;
        }
    }

    return 1037236.9137025977;
}

double OHzHmXcpwc::yZavW(int rMfPYRROnOufGn, double wAZspTOwAueVt, string PWrYZiffERxPYFXn, bool mCMEHeMgc)
{
    bool YDMKxZHsWzqGy = true;
    bool gZsNJwaes = false;
    bool lTYSLphiuDgD = false;
    int ymfpJvJKXhv = -1269153329;
    int ILaXcVpSNIV = -2088870687;
    double FViLlkxsGrW = -530454.463603407;
    int lECLNMopnOUAx = -1978870429;
    string ozjQYTpoeHRlo = string("geDMnhaDCVwqkgkGJrznypZSMJOLgGknpkYjieVFdnbTXobJaipKUWRFzzmDpukevudNhRzXTTnkZCYeA");
    string OwNbPI = string("FOvUaDRdcNkNOOfDXIdJxMSrFzEjpFYHaLrbxjMbmeOVbUFgWKuwgAHjhAObiJD");

    for (int ubrGTzRHBKiemhb = 2008732793; ubrGTzRHBKiemhb > 0; ubrGTzRHBKiemhb--) {
        lECLNMopnOUAx *= ymfpJvJKXhv;
        rMfPYRROnOufGn += ILaXcVpSNIV;
    }

    for (int PLmxUxcSwxWhqx = 1059601545; PLmxUxcSwxWhqx > 0; PLmxUxcSwxWhqx--) {
        lECLNMopnOUAx -= lECLNMopnOUAx;
    }

    return FViLlkxsGrW;
}

int OHzHmXcpwc::YAMzaPpzq(string IAWiqNXNhKMi, string XsJFusBUbXNJfl)
{
    int bKJOMmWxcDTQF = -150957097;
    string PNcGiROcHaZ = string("vAdudaHqFeUCiifnoKlDRKiPCXXuqHvGwggUbFndktuRWVDISpCakFEyLLvAlcZCXmHggAQqDroSu");
    string fTHrnilQNkzZ = string("OECEFZpjFdXdbHVeHWYKkrkXdtKoheGydgwzlQlSgmynMpaGgcDodkfhDhoJvmvknygTXKxHyIkJgdjuODRwIv");
    bool PKFVUsHcw = false;
    string DujJsHtJvMRPKtl = string("LAzEuEnvMjQUfWxxPmNtxiGOhXkaKGwTncGmozfmaFtwNbOaSjXXikmegiKGBTtxGzoeUKryZgumLdHguzlMdxiSxTpZmQuneTHmugPdjxrbaVyOEKfVbiKHufPSBjpoYgOJwIkMxNqzGLBQZvTkUuJJMYFsYorBSewDlVrUpZAmoHYVEWcXNmdsZoGnUzimeagHAZivEAEwYFFUUeZoLQINMfbBjIwZfDQOCBuuuo");
    bool wSyfXfuoLFcmch = false;
    string TvJBBC = string("GpIWTVKGEqgEAMgVRbQbFkRSjgXefAbLid");
    string QocdSKhcIGyp = string("HGGosbcaHaiGAebFTJXDmcDyrUOgfgGptDSKroPyjvWRijewsklQPcGTVCWSDxDTRvjYsVcNAktYTQevDQWWDhgMNyGhjBJktMoHmGXHkhzHezYtlupBNMKgoGKABApvjDayMlZQgDYMCkDhoYGARMtdUulwbpQzdPOgrah");

    if (bKJOMmWxcDTQF > -150957097) {
        for (int PpTaTYMkCJvWsVm = 1832640214; PpTaTYMkCJvWsVm > 0; PpTaTYMkCJvWsVm--) {
            IAWiqNXNhKMi = TvJBBC;
            XsJFusBUbXNJfl += QocdSKhcIGyp;
            DujJsHtJvMRPKtl = QocdSKhcIGyp;
        }
    }

    if (DujJsHtJvMRPKtl == string("sOHddStOAOCPHqiIRnBjpKzIdyixxciAOLqpACcGhGmwzJqARDQAfRhMDbhGosodwFqvNBnBKovDozBVyzDpATlTJAYSxEZJDbwqQeDTyzOKnjtTvzsPekdLuHfkeKIyxguQIxRwlfnZkvHgldMJMdMukWXnvcEYdRGdFuVOIbLBdHEhyuIeoPxGAGlyIwmXavGXWvFhmZgkFItvOMjgbHpqhzMITw")) {
        for (int AMkeKVRhr = 1096299243; AMkeKVRhr > 0; AMkeKVRhr--) {
            PNcGiROcHaZ += PNcGiROcHaZ;
            QocdSKhcIGyp += fTHrnilQNkzZ;
            fTHrnilQNkzZ += DujJsHtJvMRPKtl;
            PNcGiROcHaZ += IAWiqNXNhKMi;
        }
    }

    return bKJOMmWxcDTQF;
}

void OHzHmXcpwc::EIHdFE(string NfIVsrLJjAyrQAUX, string BzuNLudNsLu, bool TYUVAwBmgcOrI)
{
    bool kXLOFcf = true;

    for (int SREdRiJhUsOlkR = 2006802074; SREdRiJhUsOlkR > 0; SREdRiJhUsOlkR--) {
        continue;
    }

    for (int HTffo = 1935587437; HTffo > 0; HTffo--) {
        TYUVAwBmgcOrI = ! kXLOFcf;
    }

    for (int skllOJy = 330580921; skllOJy > 0; skllOJy--) {
        TYUVAwBmgcOrI = kXLOFcf;
        NfIVsrLJjAyrQAUX = BzuNLudNsLu;
        kXLOFcf = TYUVAwBmgcOrI;
        TYUVAwBmgcOrI = ! kXLOFcf;
        NfIVsrLJjAyrQAUX += NfIVsrLJjAyrQAUX;
        TYUVAwBmgcOrI = ! TYUVAwBmgcOrI;
    }
}

int OHzHmXcpwc::wjXBQaTzL()
{
    double yHDkqMXaxYlbWig = -574256.7235575992;
    string vvitdDcQESzNo = string("aYxMnWbtxxHnuIWgItxEZOxzoXJIhwXNhfDlFaSBmUabKqBpLoRhVdQXSMmawkSRqhbicTCORfpfXRcMukCGJeMvkAfiuTAviztBzTZolWQrzdjpYkrrBsNeJnjKijNJqUJThyWhyINfMgfNmrwUQkOjXTmJBzuoKjXmtuAVgHDLlsGqUAaMAoRpGPwEZFmuNJJpyqRzSsiojNDodrdqCclXf");
    int iakhfTuABlx = -762828899;
    bool VNUWhCaIXMVPAxup = true;
    bool cmPalVtz = false;
    bool ZSbgpOnSdplo = true;
    bool lnMslPXmwDMn = true;
    int kuuIPc = -54855814;

    if (VNUWhCaIXMVPAxup != true) {
        for (int StLIwP = 527672319; StLIwP > 0; StLIwP--) {
            ZSbgpOnSdplo = cmPalVtz;
            ZSbgpOnSdplo = ZSbgpOnSdplo;
        }
    }

    if (lnMslPXmwDMn == true) {
        for (int VtPJHxvwfBPatWUC = 967723312; VtPJHxvwfBPatWUC > 0; VtPJHxvwfBPatWUC--) {
            continue;
        }
    }

    if (VNUWhCaIXMVPAxup == true) {
        for (int zOUDOenBIYSn = 345588301; zOUDOenBIYSn > 0; zOUDOenBIYSn--) {
            iakhfTuABlx -= kuuIPc;
        }
    }

    for (int pzQYQ = 1558896631; pzQYQ > 0; pzQYQ--) {
        cmPalVtz = ! ZSbgpOnSdplo;
        ZSbgpOnSdplo = ! cmPalVtz;
    }

    return kuuIPc;
}

OHzHmXcpwc::OHzHmXcpwc()
{
    this->BkwaCwXtp();
    this->vPEuDHm(1259730456);
    this->jJBDK(string("RuSxWQmsNGdoEGszWSeLAsIaaGgJVdEhvBTHlIqBFLzqfzAeEIhmuZCFTIu"), string("SWFRe"), false, false, string("oSnjaZQSMRlBTNTxaTsCLUIhEdeEtVPJDXYtxAkBPJbDtHgEsRtlhpmnoYVnpjMysLRqdQTdkQASeqeJdijkOrMUClDgpnmUnLONFbbuKclpPMCsjgxWmZrXJfwADXOqFeOlygpKZYTkTyRFXGKFWXSakQRXnIDzlRzmyJAannyzOIyLFUJVubLiSBtzOtQGAQGP"));
    this->hzeEgnLfOpV(1972571960, false, -10570.292782763669, string("kKCqlhFIyHGEVvPRDWheHCvlqhpyfRiGrBdNqVHRBrGtpYHwTYwzQcvTRkpBBQnFYIYZcikMpoivESMowjsHladnlvdhFCAAKCiVVydGRt"));
    this->rXAkiJ(564949770, string("sGybOZvZGUbyYxCLxxJMFeBmMnsRpveCLekOAxGQqQQmgNJtFMvsfTgVzJAfKxRfDEWcJHaJnzzIpdUCvVxJWSOiDLLeZTbyupyhkRiUJvYdrjlalDFnINXuquyZySjoSfFAxXQPpeUcNonrxhhTHAFCSWtdeVmLfvrEwtUDoeaCvEgeJEjlUKaTBjbAQ"), -1759513257, -444949.3010722236);
    this->IuFLjTbvSLgdJ(-1264416010, 102158227);
    this->VbfUjpJixEC(true);
    this->yZavW(-1584354479, 363116.5645194013, string("BgKMojFZmjWhqEdHNB"), true);
    this->YAMzaPpzq(string("sOHddStOAOCPHqiIRnBjpKzIdyixxciAOLqpACcGhGmwzJqARDQAfRhMDbhGosodwFqvNBnBKovDozBVyzDpATlTJAYSxEZJDbwqQeDTyzOKnjtTvzsPekdLuHfkeKIyxguQIxRwlfnZkvHgldMJMdMukWXnvcEYdRGdFuVOIbLBdHEhyuIeoPxGAGlyIwmXavGXWvFhmZgkFItvOMjgbHpqhzMITw"), string("PLdGeeEKJNZuAeQDuhKdCSrXwfRFVHswmWrJJzsrtAGTOgoaBMfCEOZgSDDxUJcwkqKIAbcogZubOtZpwbNSIKRFDNHqQIPKGxVMVyyojjpWtHDsQKqiBqQgALJSJwJoclrNCXMYZDqqEeCWgnzpSwQrMdEZucGXuizOdIbxjnkpgLlUjuq"));
    this->EIHdFE(string("NxzbgzVfkqwzshhMkfdWTeDQrKPGqzUTpZRyLMHqdxJvyRjHVmpoBcbtOYkbaOvcUwkORbVGUtlIzGEUfXbWeiZtPpHRKzprnJimZifSRuvmAAjFIZPdMXXPhRaVzmBhZGfyPJtUGXITiydwuQmkHsFpEdyoYQHJMZIMKkCAKdPGvcEUCuJSGibDfUyXMhPTJZVfi"), string("YNcfTSKrCBpZhbBmawBAzKlmcWcAviwaulqTFqniFIagieHdOgrgYipQBWwJrwriyILyguQWpAiLylhyuJtJvYHoAqisFtkQCKzPSGiONlnuCWuuPVDkmZmbmzLvkjiEhiHdVTwsSjgOblxwaAZirBEHIzedaXeChicUApfUQPpObFv"), false);
    this->wjXBQaTzL();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EFSfEEylt
{
public:
    int bNogvc;
    bool NUqGDubpCFmBxe;

    EFSfEEylt();
    string kaEleXynmmybxZu(string OlOcCaVrsan);
    bool NAQjllivusA(bool ZAwqYiF, double gfiDJa, string efNSgrdZqnFKs, bool sargfzNfv, int AVcMwAwCtYBLfrh);
    bool thbEfSo(int GUSVbEgVBUqQvwo, double YhcEjiw, string kWmgi, bool ECuBvPLQRSps, bool sHaOziI);
    int vxcPh(bool DjUDfrzPQcpQkr, bool OiYLlRawhCv, string mFaFdNMCvUVrL, double KJSoYgLPzwLSGsl, int tkKjMNQVeklXCrW);
    void YBMELqrR(string LPuWBxKrgy);
    bool bHHDSgIz(string SDcTVsDvxel, bool HvyDA, bool WMGDwuYz, int ZYtpqqIDj, string VwwVQEGPyKpmegRO);
protected:
    bool wbztH;
    bool UeMcdkEpvH;

    bool MYnsVQABnuarM(bool BWrNlDVx, string zXvwqRCutrDuJM);
    string Xqujzc(double kgqByfddpkwXVo, double yWqgBkF, bool sofnGKuIL, int WvhKWx);
    string VtafKsixN(bool zryYxWG, double VNQvRBWAInUXHf);
    bool xiOWFl(int EThOyHEHrTKB);
private:
    bool TpXwcCQNVlrGuG;
    bool trEtaqRaGgw;
    int OFjFGkYlfTY;

    bool jKCiLCLiASarma(double UdqztKJvGOWZ, double HrfLuidmtwtrh, bool linjahN, double TrYSImcGpRa);
    void hwNwOTnEXVSd(int ECabjKUatuzPb, string lfcADXgH, double ihXPAGogTsz);
    int nUNNlYaTdI(double GTFUNwyI, bool IFivDqVxUx);
    int reaxylJxL(string KXTTFwYtLnsvrLkT, string mPypyWV, double FZePZt, int UDFGaxlbzotkneH);
    string XmqSSU();
    string hAgdAexWzxqSVc(int qwlVrb, bool fNiPDkn, double JsNHvoMu, double azHGmOaAY);
    double sJCoaUdzoEU(double udWBtxdH, bool CQILwyJlrkj, int WWrzpTSIl, bool FRApMFyut);
    double opdpBRBKrrtPUDdb(double OknmLopnZZHue, double CfQfNSDKSIjgFQ, string qZVenTggYBeYuI, double KfYGIjxIVFVaZD, bool dFWccUSewvJu);
};

string EFSfEEylt::kaEleXynmmybxZu(string OlOcCaVrsan)
{
    string doLAhHsLBnV = string("FfbMzyfYxhftNyvsDXkRbzqtiXtqagnSTqxHPSCqKOYlIrAtDPoiGqJQxHVnaYSfyEKyhyhCthRNauBRIvndtyPLMtNUJhmXiWvtAYweSqvdrgJIdEXgNzLxvaKceMcpNQgvuJJqkoGAjbdSNyVeMmgmWZerzWVakFdHCtPJIAMwVLgfPEcKKPZAQLWPUKqpcGWZPyOnyQcNTzHkQmOovZmmfaEbfhhcnXxfDavgnTuuoCiKtcIHBdkZY");
    string IxIuegBnsF = string("Thm");
    bool EOSHLeXceZFxX = true;
    string byDOTKk = string("eoTFeszOdattMpQbolgVomOHQraSciVJFeFFXebewuKxOYqVJjikiNUuSPqUVQgYUVfqEwqxFfGoTIO");
    int rwgeerl = -1449784205;
    string YlzmDZqKks = string("vcBYBFbgAKyjIFlIVKqOmnatmCeXUAILiCeUaFsWbCykNbmbnSqGkvLtFgriiXKMhGLdJIhfauradSTWOncEHAuVKGOXayHSfTHeUTyHRZpfKbZGlOWuGzmMeqzkNpMnJorhKOwsZikRbITYbfNgvanWHCbqKUorYFqNvxteDJZNDLmDAdhvNbkMfzNTHrJhAIpmwFRNcyRTNwWUNZaAHBfPDLgTPyQcfWNySojnOyUCNYG");
    double JKTpVhxTpbfbLVIC = -40201.30969272165;

    if (doLAhHsLBnV <= string("vcBYBFbgAKyjIFlIVKqOmnatmCeXUAILiCeUaFsWbCykNbmbnSqGkvLtFgriiXKMhGLdJIhfauradSTWOncEHAuVKGOXayHSfTHeUTyHRZpfKbZGlOWuGzmMeqzkNpMnJorhKOwsZikRbITYbfNgvanWHCbqKUorYFqNvxteDJZNDLmDAdhvNbkMfzNTHrJhAIpmwFRNcyRTNwWUNZaAHBfPDLgTPyQcfWNySojnOyUCNYG")) {
        for (int cWZqeFXiBk = 523063059; cWZqeFXiBk > 0; cWZqeFXiBk--) {
            IxIuegBnsF += IxIuegBnsF;
        }
    }

    for (int EUpYifCkYu = 1416423036; EUpYifCkYu > 0; EUpYifCkYu--) {
        doLAhHsLBnV = YlzmDZqKks;
        YlzmDZqKks += IxIuegBnsF;
    }

    return YlzmDZqKks;
}

bool EFSfEEylt::NAQjllivusA(bool ZAwqYiF, double gfiDJa, string efNSgrdZqnFKs, bool sargfzNfv, int AVcMwAwCtYBLfrh)
{
    double SFYaufiILFHokoj = 413268.00978501944;
    double AMTdubW = 417377.2889550538;
    int PRiWlXCssAKmMw = 728629482;
    string HmOACxzKKDPCfJFv = string("klFaAmyZuAFtQkiibAjkqhWBrkVoRQIbtJbrdOunOXBgaxPZvOZCtEMNuNuSxFtJuWXpaGzSFRGvnVluXOVjOGucSxzylBPUwatnCoWdcOMuglsGUROcIzLOdlgbBrODnskRcUQWSCRTYczNqvIKHPJVbeWEnRXsfCrXIakrfSh");
    bool yvSYyG = false;
    string JbmjNvycrSiJ = string("YheCHYTCgZsypKVjHYAYkCnlobDUmBGNBpVFOwbjdTSURVWOYEhjVGHnBVcEYypTXapkBUtqnsdtlRkXqpFharIBpWhkbprMXmlfwQaxSqLbBdiWqvGJraidlhJgCdAYcauoflIbaJlUrpSnuCtBWEsDwsEyqsIAKgSFyrlEnmQEsEhGmbQEQfaXRlgbhmGdVDAZDBiUjGijBvRDyuhKvahWlscdyrc");
    double dukHXpMwjY = 762174.14268861;
    double lUoceMtfsOFhOYWv = 235375.53654225936;
    string EjzrjxPVRV = string("yTLuLJrxyUtoETQxxhhChobhnNwfLcbZm");

    if (lUoceMtfsOFhOYWv != 235375.53654225936) {
        for (int yIWNPjOM = 2098966747; yIWNPjOM > 0; yIWNPjOM--) {
            gfiDJa = lUoceMtfsOFhOYWv;
        }
    }

    for (int pDnGUtriPsIjAy = 1726248512; pDnGUtriPsIjAy > 0; pDnGUtriPsIjAy--) {
        continue;
    }

    for (int gZICsZvzgZxK = 1708021185; gZICsZvzgZxK > 0; gZICsZvzgZxK--) {
        gfiDJa += lUoceMtfsOFhOYWv;
    }

    for (int oSlYyIlS = 1130055650; oSlYyIlS > 0; oSlYyIlS--) {
        gfiDJa *= SFYaufiILFHokoj;
    }

    return yvSYyG;
}

bool EFSfEEylt::thbEfSo(int GUSVbEgVBUqQvwo, double YhcEjiw, string kWmgi, bool ECuBvPLQRSps, bool sHaOziI)
{
    bool ooaeXWCB = false;
    int EDEeSpOk = -193264280;
    bool hSRfrWlYtF = true;
    string amMzVzekDKYp = string("mAprEpxSbnNXsKirMJryooQQmiKFLofwGCTXkMMzOivEWfTCIjaHiqMGuIDOgNaiexNZMNmqItQDSlSdubNKigSwKGJVrwaAWBxnuBhBSTnROLlKuQCFPtWraTpkQUDmTuFzswHzKOWMuZrjzEsViGlykLGCBBNMkLtbPFPFsLPjWmbBPXCWXondDsNneRKafFqlXSzlQbycgeWzYonBCNuWkEGx");
    double wIaphdw = -761916.087190445;
    double NpAESXNJRQbkqaST = -704892.0408136676;
    double jTEgTsZTYjGedJyr = -571683.1887295784;
    bool QbSJEK = false;

    if (YhcEjiw < -482548.7609952913) {
        for (int pZKYQyxyKgjc = 611773959; pZKYQyxyKgjc > 0; pZKYQyxyKgjc--) {
            continue;
        }
    }

    return QbSJEK;
}

int EFSfEEylt::vxcPh(bool DjUDfrzPQcpQkr, bool OiYLlRawhCv, string mFaFdNMCvUVrL, double KJSoYgLPzwLSGsl, int tkKjMNQVeklXCrW)
{
    int MnaeFxXeNnxf = -1718446234;
    string MXdGT = string("LsqrLzlCntmUmTbgokIQCJBhciRqJuPnWgyujEttnvTjQffAcNYPSZQOWmlxgfcWVAZwnotwEFEyiZRpOOfwGESOwb");
    int qtmLFd = -39957985;
    double YLlQQQUF = -300701.1653448196;
    int rSQwtZnuSOtZdXuh = -966838244;

    for (int BweErgObreA = 1426337472; BweErgObreA > 0; BweErgObreA--) {
        rSQwtZnuSOtZdXuh += rSQwtZnuSOtZdXuh;
        qtmLFd *= rSQwtZnuSOtZdXuh;
    }

    for (int YmgOtT = 1424285334; YmgOtT > 0; YmgOtT--) {
        MXdGT += mFaFdNMCvUVrL;
        qtmLFd -= MnaeFxXeNnxf;
    }

    for (int VcZgI = 1215124834; VcZgI > 0; VcZgI--) {
        MXdGT += mFaFdNMCvUVrL;
    }

    for (int ajOFBYT = 1529059682; ajOFBYT > 0; ajOFBYT--) {
        continue;
    }

    for (int HwUoz = 971049114; HwUoz > 0; HwUoz--) {
        continue;
    }

    if (OiYLlRawhCv == false) {
        for (int mRKSHwUBbs = 837423121; mRKSHwUBbs > 0; mRKSHwUBbs--) {
            mFaFdNMCvUVrL = MXdGT;
            qtmLFd += tkKjMNQVeklXCrW;
            KJSoYgLPzwLSGsl *= KJSoYgLPzwLSGsl;
        }
    }

    return rSQwtZnuSOtZdXuh;
}

void EFSfEEylt::YBMELqrR(string LPuWBxKrgy)
{
    bool etRVbKVuuA = false;
    int UblQgjFqYKDmq = -439451991;

    if (UblQgjFqYKDmq >= -439451991) {
        for (int eqWOsB = 491678691; eqWOsB > 0; eqWOsB--) {
            UblQgjFqYKDmq /= UblQgjFqYKDmq;
            UblQgjFqYKDmq = UblQgjFqYKDmq;
            UblQgjFqYKDmq *= UblQgjFqYKDmq;
            LPuWBxKrgy = LPuWBxKrgy;
            UblQgjFqYKDmq += UblQgjFqYKDmq;
        }
    }

    if (UblQgjFqYKDmq != -439451991) {
        for (int dIonP = 1013348787; dIonP > 0; dIonP--) {
            etRVbKVuuA = ! etRVbKVuuA;
            etRVbKVuuA = etRVbKVuuA;
            UblQgjFqYKDmq *= UblQgjFqYKDmq;
        }
    }

    for (int jDrHrPoOCfvRXPO = 1250184013; jDrHrPoOCfvRXPO > 0; jDrHrPoOCfvRXPO--) {
        etRVbKVuuA = ! etRVbKVuuA;
        UblQgjFqYKDmq += UblQgjFqYKDmq;
    }
}

bool EFSfEEylt::bHHDSgIz(string SDcTVsDvxel, bool HvyDA, bool WMGDwuYz, int ZYtpqqIDj, string VwwVQEGPyKpmegRO)
{
    bool sMelTvvETR = true;
    string HFlmWjjHdkmEeho = string("mZOaowszVkaoohAGlLiTNVPeeghhvrNFFRDsFpQbpHYgtwExQNBLDruXCcehAmwpvnhxSkOJlQiDWQbrNaQRNextkYSnK");
    int bpTiLKtPnB = 1149662736;
    bool FuNpZymKEdazY = true;

    if (FuNpZymKEdazY != true) {
        for (int XsAlAhPjZoR = 943423458; XsAlAhPjZoR > 0; XsAlAhPjZoR--) {
            FuNpZymKEdazY = ! WMGDwuYz;
        }
    }

    for (int oAPbZWbryKS = 1133099701; oAPbZWbryKS > 0; oAPbZWbryKS--) {
        continue;
    }

    for (int ZnYBDMtXsvt = 68591869; ZnYBDMtXsvt > 0; ZnYBDMtXsvt--) {
        ZYtpqqIDj = bpTiLKtPnB;
        sMelTvvETR = ! sMelTvvETR;
    }

    for (int ZbNPphuK = 652116740; ZbNPphuK > 0; ZbNPphuK--) {
        continue;
    }

    return FuNpZymKEdazY;
}

bool EFSfEEylt::MYnsVQABnuarM(bool BWrNlDVx, string zXvwqRCutrDuJM)
{
    string ushJjbWAgSOzQUS = string("boOBZjIPbHaaiAYVVnNsUBi");
    string teEgtOZCeMGXxr = string("YmMZESqAzPVheteFZznIPBzDZuvqVPsEerfMvQcfvuitOdjlgiMWFggNcHwfWSrJKWXIJkSDJRudPLFGOTRrzfKRSxTvUkMIZPwpwhAAieCvBCOOYPyDVqSCxiGmfLhAnahcOhpIbGFQKQiihZjiNlzSWxMZRoZNXMYHtnQIXhBQaVQEbKKkcTQwHstxnHUzfpXC");
    bool sKtPJev = true;

    for (int usxYpDJRcbWc = 1745873972; usxYpDJRcbWc > 0; usxYpDJRcbWc--) {
        BWrNlDVx = BWrNlDVx;
        sKtPJev = BWrNlDVx;
        ushJjbWAgSOzQUS = zXvwqRCutrDuJM;
        sKtPJev = sKtPJev;
    }

    for (int UJYDqUWCcSn = 553887919; UJYDqUWCcSn > 0; UJYDqUWCcSn--) {
        ushJjbWAgSOzQUS += teEgtOZCeMGXxr;
        teEgtOZCeMGXxr = teEgtOZCeMGXxr;
    }

    for (int uBSVxI = 370255831; uBSVxI > 0; uBSVxI--) {
        teEgtOZCeMGXxr = teEgtOZCeMGXxr;
        sKtPJev = BWrNlDVx;
    }

    for (int dbdCAe = 390707765; dbdCAe > 0; dbdCAe--) {
        ushJjbWAgSOzQUS += teEgtOZCeMGXxr;
        zXvwqRCutrDuJM = ushJjbWAgSOzQUS;
        sKtPJev = ! sKtPJev;
    }

    if (teEgtOZCeMGXxr != string("YmMZESqAzPVheteFZznIPBzDZuvqVPsEerfMvQcfvuitOdjlgiMWFggNcHwfWSrJKWXIJkSDJRudPLFGOTRrzfKRSxTvUkMIZPwpwhAAieCvBCOOYPyDVqSCxiGmfLhAnahcOhpIbGFQKQiihZjiNlzSWxMZRoZNXMYHtnQIXhBQaVQEbKKkcTQwHstxnHUzfpXC")) {
        for (int pdVXiUAAs = 1820928683; pdVXiUAAs > 0; pdVXiUAAs--) {
            sKtPJev = ! BWrNlDVx;
            teEgtOZCeMGXxr = teEgtOZCeMGXxr;
            zXvwqRCutrDuJM += ushJjbWAgSOzQUS;
            BWrNlDVx = ! sKtPJev;
        }
    }

    return sKtPJev;
}

string EFSfEEylt::Xqujzc(double kgqByfddpkwXVo, double yWqgBkF, bool sofnGKuIL, int WvhKWx)
{
    double ZzJfLqilhqadL = 163771.88423752476;
    string VIVnhEmpMe = string("BkbTAipFrQhWsemcCMoWmekpVuIClripTSzTKOyfkblVsjNZRcsiTwcdehCZePtEWzUqlLXovgaj");
    double mriMSVAePoOk = -526431.6331689472;
    string BdpEQTwLwrtpmq = string("craMCZcUekWpcUKFajeyHPEUtnQgXccFcWmZjYxFERWvDFAbDNZnniggttxclRTxxRlOcyArllTWowp");
    string xJRWWlH = string("ZOKySXBVjLDaxRNWFuYmMYZvnDWEBvvEvPLNkPFODXPZuKplSQDmIXUtqvbekWGRqiDIlKmDViojqxcbLoJIpVgBxAxZgekMqmNEscIghOeODXDKwYgBnkYTFXjZyMahUqlVXMxLXjvMdbivyyRaeQLoCu");
    int hyDwjlYnH = 1486620015;
    string jZbVrVyevrjs = string("xbMWN");
    double wNojuy = 347031.7629733027;
    int fjqSVVobj = -2090176443;
    double WUYBgnNWAkrTf = -980610.4558874867;

    if (ZzJfLqilhqadL > -223818.22631137443) {
        for (int UNDtLdpqRRt = 2053878947; UNDtLdpqRRt > 0; UNDtLdpqRRt--) {
            kgqByfddpkwXVo = mriMSVAePoOk;
        }
    }

    for (int cvMQHnJ = 1103873339; cvMQHnJ > 0; cvMQHnJ--) {
        kgqByfddpkwXVo += ZzJfLqilhqadL;
        jZbVrVyevrjs = jZbVrVyevrjs;
        yWqgBkF -= mriMSVAePoOk;
        yWqgBkF -= wNojuy;
    }

    return jZbVrVyevrjs;
}

string EFSfEEylt::VtafKsixN(bool zryYxWG, double VNQvRBWAInUXHf)
{
    double oNEcTCx = 935504.1970692761;
    int LHtobi = -558833742;
    bool vWtYWAa = false;
    int KJCqlIEDUldQb = 34200331;
    int jBqTgPtT = -2123304547;

    for (int TkvRao = 799741546; TkvRao > 0; TkvRao--) {
        oNEcTCx /= oNEcTCx;
        LHtobi = LHtobi;
        jBqTgPtT *= LHtobi;
    }

    for (int uzZxuTqpg = 1880777917; uzZxuTqpg > 0; uzZxuTqpg--) {
        vWtYWAa = ! zryYxWG;
        jBqTgPtT += jBqTgPtT;
    }

    for (int WZEOWxr = 1895089594; WZEOWxr > 0; WZEOWxr--) {
        jBqTgPtT += jBqTgPtT;
        VNQvRBWAInUXHf += oNEcTCx;
        LHtobi /= jBqTgPtT;
        KJCqlIEDUldQb -= LHtobi;
    }

    return string("zZenJJqNixPAXQihOiEJrMkuLkmAQaKBhLuFtDUcLdUFWCpZCgjpuWUaFLZvnoMTmCBZvgtLbFrPLmCYfVzeOERrKclaDoJbhyQYKnFjwHEcslGfJnWhdEKohIjCwnSTahBurWuHRjgIkoRIExeFgNiIWHTUXvqJeAQLUzserKryELSbaQXIfLupCJYDzYZ");
}

bool EFSfEEylt::xiOWFl(int EThOyHEHrTKB)
{
    int UXVzfT = -1073277950;

    if (EThOyHEHrTKB >= -1073277950) {
        for (int rNEZQ = 195564620; rNEZQ > 0; rNEZQ--) {
            EThOyHEHrTKB /= UXVzfT;
            EThOyHEHrTKB = UXVzfT;
            EThOyHEHrTKB /= UXVzfT;
            UXVzfT /= UXVzfT;
            UXVzfT += EThOyHEHrTKB;
            UXVzfT += UXVzfT;
            EThOyHEHrTKB *= EThOyHEHrTKB;
            EThOyHEHrTKB /= UXVzfT;
        }
    }

    if (EThOyHEHrTKB >= -1073277950) {
        for (int PcAmacoO = 249087950; PcAmacoO > 0; PcAmacoO--) {
            UXVzfT /= UXVzfT;
            UXVzfT = EThOyHEHrTKB;
            EThOyHEHrTKB += UXVzfT;
        }
    }

    if (UXVzfT <= -1073277950) {
        for (int xnTzNUVERIR = 1840638154; xnTzNUVERIR > 0; xnTzNUVERIR--) {
            EThOyHEHrTKB /= EThOyHEHrTKB;
        }
    }

    if (EThOyHEHrTKB > -1073277950) {
        for (int QQKMnNJ = 1323363680; QQKMnNJ > 0; QQKMnNJ--) {
            EThOyHEHrTKB -= UXVzfT;
            EThOyHEHrTKB += EThOyHEHrTKB;
            UXVzfT *= EThOyHEHrTKB;
            EThOyHEHrTKB *= EThOyHEHrTKB;
            UXVzfT -= UXVzfT;
            UXVzfT += UXVzfT;
            EThOyHEHrTKB += UXVzfT;
        }
    }

    return true;
}

bool EFSfEEylt::jKCiLCLiASarma(double UdqztKJvGOWZ, double HrfLuidmtwtrh, bool linjahN, double TrYSImcGpRa)
{
    int gTMvLNhdK = 1365317923;
    string JcvjI = string("gQJwjqYwuoAAIirtvMjTfZNFWlMOeGZEeebShwXzZpHTPuzqAjWZFI");
    bool HhGVWknowCuFTrC = false;
    double JDbjTObpZAxKQJS = -957072.6320255112;
    bool tfXFfQBqNnhE = false;
    int ZEvQsne = -830913941;

    for (int LTdbwKkvQlgILC = 1440648007; LTdbwKkvQlgILC > 0; LTdbwKkvQlgILC--) {
        continue;
    }

    if (UdqztKJvGOWZ >= -622441.2695547374) {
        for (int BverpcnyQbngD = 583493013; BverpcnyQbngD > 0; BverpcnyQbngD--) {
            HrfLuidmtwtrh = TrYSImcGpRa;
        }
    }

    for (int bstkaWLCxU = 878612230; bstkaWLCxU > 0; bstkaWLCxU--) {
        ZEvQsne -= gTMvLNhdK;
    }

    for (int KgQHqhRRBAV = 2055705628; KgQHqhRRBAV > 0; KgQHqhRRBAV--) {
        tfXFfQBqNnhE = linjahN;
        gTMvLNhdK += ZEvQsne;
    }

    return tfXFfQBqNnhE;
}

void EFSfEEylt::hwNwOTnEXVSd(int ECabjKUatuzPb, string lfcADXgH, double ihXPAGogTsz)
{
    double FNLWsbJS = -120559.02297583008;

    for (int vPMpLj = 684378239; vPMpLj > 0; vPMpLj--) {
        ihXPAGogTsz -= ihXPAGogTsz;
        FNLWsbJS = FNLWsbJS;
    }

    for (int zxRTJIlqptopoC = 1613871671; zxRTJIlqptopoC > 0; zxRTJIlqptopoC--) {
        ihXPAGogTsz *= FNLWsbJS;
        FNLWsbJS -= ihXPAGogTsz;
        FNLWsbJS -= ihXPAGogTsz;
    }

    if (ihXPAGogTsz > -1034272.9699347436) {
        for (int aqRTBzmtyN = 1740563252; aqRTBzmtyN > 0; aqRTBzmtyN--) {
            ihXPAGogTsz += ihXPAGogTsz;
            ECabjKUatuzPb += ECabjKUatuzPb;
            ihXPAGogTsz /= ihXPAGogTsz;
        }
    }

    for (int BbgnItSD = 288630253; BbgnItSD > 0; BbgnItSD--) {
        ECabjKUatuzPb -= ECabjKUatuzPb;
    }

    for (int XDyAcEsmOMQZXOYv = 1695416162; XDyAcEsmOMQZXOYv > 0; XDyAcEsmOMQZXOYv--) {
        FNLWsbJS /= ihXPAGogTsz;
        FNLWsbJS += FNLWsbJS;
        FNLWsbJS *= FNLWsbJS;
    }

    if (lfcADXgH <= string("zwdRVaIoXJnosrYfGIOfmXcWdCLhOZDepsiEPhYjNKitZAECdxPpVhrWRQzFrMBhGocJqJGFrwThkHOfYHTyTasJjFtpFbvJPQUKbbi")) {
        for (int dBnXlf = 1035238278; dBnXlf > 0; dBnXlf--) {
            continue;
        }
    }

    for (int ikacBDMFw = 677395957; ikacBDMFw > 0; ikacBDMFw--) {
        ihXPAGogTsz -= FNLWsbJS;
    }
}

int EFSfEEylt::nUNNlYaTdI(double GTFUNwyI, bool IFivDqVxUx)
{
    bool Xbcrj = false;

    if (GTFUNwyI < -528095.5252451462) {
        for (int UUtknvGroZqGsWb = 967590926; UUtknvGroZqGsWb > 0; UUtknvGroZqGsWb--) {
            Xbcrj = ! Xbcrj;
        }
    }

    if (GTFUNwyI != -528095.5252451462) {
        for (int ctdSjGaAbSk = 1124124669; ctdSjGaAbSk > 0; ctdSjGaAbSk--) {
            GTFUNwyI += GTFUNwyI;
            IFivDqVxUx = IFivDqVxUx;
            IFivDqVxUx = ! IFivDqVxUx;
        }
    }

    return 1815536283;
}

int EFSfEEylt::reaxylJxL(string KXTTFwYtLnsvrLkT, string mPypyWV, double FZePZt, int UDFGaxlbzotkneH)
{
    double eCKHOjAVQlct = 784830.6062429243;
    int YMkcQmiAXUd = 1914434475;
    int VbIwYOUaNUJAFh = 853316730;
    double zzjjnmKUwmJmSLq = 85205.98367732616;
    int zJvSEPQ = -503652442;
    string WlUrkmMY = string("ONoiaBBwYrPzXyKhPMSzSdtzSfOJYRGWuaaEACTOwSMMcUlVwpXlqrZBbqGTzlfnRLmahLWodEKsIDzXZslNrLPQIfhOFfnYqoGLLBuTRNWmZUfrDqrrMLfepHtBwHxkPZEaqCzlijlJIsrlyyZiMHBCNGAxOwXQgWRltkMovrBKaKpoDOllyDEsgUBtkOT");
    int JHbBFVKVrBJJgUb = -1449654377;
    bool VDmwJnoO = false;
    bool tzMmIZBqWyH = true;

    if (mPypyWV == string("ONoiaBBwYrPzXyKhPMSzSdtzSfOJYRGWuaaEACTOwSMMcUlVwpXlqrZBbqGTzlfnRLmahLWodEKsIDzXZslNrLPQIfhOFfnYqoGLLBuTRNWmZUfrDqrrMLfepHtBwHxkPZEaqCzlijlJIsrlyyZiMHBCNGAxOwXQgWRltkMovrBKaKpoDOllyDEsgUBtkOT")) {
        for (int ZkCjnio = 932763017; ZkCjnio > 0; ZkCjnio--) {
            eCKHOjAVQlct *= FZePZt;
            VbIwYOUaNUJAFh *= VbIwYOUaNUJAFh;
            KXTTFwYtLnsvrLkT = KXTTFwYtLnsvrLkT;
        }
    }

    for (int ncCoQ = 1071016791; ncCoQ > 0; ncCoQ--) {
        FZePZt += FZePZt;
        KXTTFwYtLnsvrLkT += mPypyWV;
    }

    for (int ufbEqPY = 1510137718; ufbEqPY > 0; ufbEqPY--) {
        mPypyWV = KXTTFwYtLnsvrLkT;
    }

    if (eCKHOjAVQlct < 784830.6062429243) {
        for (int FVxNW = 865397194; FVxNW > 0; FVxNW--) {
            continue;
        }
    }

    for (int mTEPdQVFWaTPGs = 142869546; mTEPdQVFWaTPGs > 0; mTEPdQVFWaTPGs--) {
        zJvSEPQ *= VbIwYOUaNUJAFh;
        JHbBFVKVrBJJgUb /= UDFGaxlbzotkneH;
    }

    return JHbBFVKVrBJJgUb;
}

string EFSfEEylt::XmqSSU()
{
    int mZUHnwCgbVrvTcBb = -2104852993;
    int LtiHpJaDwVy = 94224282;
    double KFZjZjTpeWhTs = -640498.541320208;
    string zKvKJUytARREGUc = string("deGPfgEoZWmTsVmyGAbaqEpBuQgzTZTtmANCtSNNSsirczSpDSqz");
    bool spnMAWPQXtzUo = false;
    int jrgHrrCFFMgJWRy = -471691774;
    bool nUULlRRaHaKHH = true;
    int tmNsbmlZiBNLOD = 1352977853;
    string cDvfexYXCFjxn = string("VfydrFckvVcHsfYVDtRxXoJpUFsMIiwISfHDvOSakakHqiQSAnaKgXKLkiXGohGbiqvLD");

    for (int hAukFvPBIKkmXd = 1559375890; hAukFvPBIKkmXd > 0; hAukFvPBIKkmXd--) {
        cDvfexYXCFjxn = zKvKJUytARREGUc;
        tmNsbmlZiBNLOD += jrgHrrCFFMgJWRy;
        mZUHnwCgbVrvTcBb *= tmNsbmlZiBNLOD;
    }

    for (int jvTPLZcHrqxBj = 571801438; jvTPLZcHrqxBj > 0; jvTPLZcHrqxBj--) {
        tmNsbmlZiBNLOD -= mZUHnwCgbVrvTcBb;
    }

    return cDvfexYXCFjxn;
}

string EFSfEEylt::hAgdAexWzxqSVc(int qwlVrb, bool fNiPDkn, double JsNHvoMu, double azHGmOaAY)
{
    int HToDrPD = 1198257981;
    bool tXHsqmnnsi = false;
    double pkNyfcsPMm = -694051.626199868;

    return string("qWNFFWfaPVmYHzDdqSeoOGohWLUDzRsRVhgXhzGXoZIPNFHwVymWJQzcQATYfcnSzcYqVWsjQXKEnFzHAn");
}

double EFSfEEylt::sJCoaUdzoEU(double udWBtxdH, bool CQILwyJlrkj, int WWrzpTSIl, bool FRApMFyut)
{
    double UApwspxLgbEQY = -411417.5454962036;
    int fKoTi = 1265596336;
    string lYceshqh = string("hgdXgAJujTHkiaZXivSOMuIxFygggPzVuntTbpvdkJJqsXjuIoiovIRpoMbSMXfIoMJaZygXjCWZrkoxkSFEvCqPKpBFWOevcNvOsPTVKviGGJbyCZBWjDuoLuRXFarTEAByyNAuGgaifhfPpVMEqBLuwppOHmXMDJryoqSPFqewdsTBvGXqCkq");
    int lotdrsJEvCvL = -855991964;
    double uICdnZfluYCkHG = -217311.33053633737;
    bool kznNEiyZGh = false;
    double XaQRencvHK = -332178.5357359461;
    string mpICmJzh = string("zYVOjXeThqwUPZwrMHbbIGabHMHQaEIorKMmfrZqUgTylKPdFAweFTtdFBKVUCpyigxGChTFtEhMwqORXMTUYInPBBPfmGJUUTTdCaoJEQeXgsRTLagwkOjSeLAnuuKeQclDwXzAasqxZIUNRRpttSSmnXaNIIBFaSPeOgmnsoDZVGqrPWKOrWXOzleGELyWLxSStjTXsjxvNhAKfZKQcdhLzmhiYuLOlVfJmOvDCoNWuNnF");

    for (int MpSsInINoi = 305244647; MpSsInINoi > 0; MpSsInINoi--) {
        CQILwyJlrkj = ! kznNEiyZGh;
        fKoTi /= lotdrsJEvCvL;
    }

    if (XaQRencvHK >= -411417.5454962036) {
        for (int BPqIEjpPez = 810543215; BPqIEjpPez > 0; BPqIEjpPez--) {
            lYceshqh = lYceshqh;
            lotdrsJEvCvL += WWrzpTSIl;
            mpICmJzh += lYceshqh;
            lYceshqh = mpICmJzh;
        }
    }

    for (int bInjOXBDjJEVRN = 976507877; bInjOXBDjJEVRN > 0; bInjOXBDjJEVRN--) {
        continue;
    }

    return XaQRencvHK;
}

double EFSfEEylt::opdpBRBKrrtPUDdb(double OknmLopnZZHue, double CfQfNSDKSIjgFQ, string qZVenTggYBeYuI, double KfYGIjxIVFVaZD, bool dFWccUSewvJu)
{
    int TRhnM = -2090223064;
    int PfegqWlYOuGeQ = 902270464;

    return KfYGIjxIVFVaZD;
}

EFSfEEylt::EFSfEEylt()
{
    this->kaEleXynmmybxZu(string("uiRjPAktwztzQHNBFwhaIqDJxcCdjISQvjOHFqGxGGdoFiMwqVvBEzRBrtjuYUXwZLoSCOqIDOANxrVdwpPfxyCMVnMLCggFTJuRiNxdglcjRMJBrVqlwwnkwOKPeFhmsLPVqjYGGEXlrSTxMpwdlXBNmKbOlduhkAphrN"));
    this->NAQjllivusA(true, 66419.10310268178, string("trpzFXPYgdRIHLNjdfcqnuwrhouNYjYQXIMvxRWHTQSObYvOYkOJlNfXTwqNCiIJltKJtdKDnyVpdKFIIHHQBqqeliRhGlKCmapJoCmcsQnjkzijxIStvClcWjSEgtVepNQEomhhnswHVxZFzCoMpJktToyaxKlVitQUGqvrTuCupntlgveEruidXuVvUVziZPsRgtlLJ"), false, -1925793687);
    this->thbEfSo(-275577721, -482548.7609952913, string("iSmorszVbKscVOhxwocNkHvgQWMNxfEvJBwzqI"), false, false);
    this->vxcPh(true, false, string("uVlvCU"), -687522.8785036694, 662047999);
    this->YBMELqrR(string("EzCWkhnK"));
    this->bHHDSgIz(string("ZRNFcLVNfCaWnTzpYVTsIgJoVuRXDXbcHeFNBeokzNYTTdVxjecJXurJKEHyqjzXOiIBmnsybiHIBQpOZulGadxbNsdNnUVCKedBavMktmjqzyOoPlinNWGZCUNFQhgYDnmbCwsacDbWldmughacVaCBgtKAMeBnoFKfsxLKaDmuyEzauKEllajSuDEtWwYLTBencAxEeCVoQsDbYCWrEFdaYPyRufqxAUoPDXWGxkYIRzqgHoIafJ"), true, false, -850362176, string("FULlVlPlXDwguaAnnjrsJPJNJJlRAEmXMoeTVAgTtXBT"));
    this->MYnsVQABnuarM(true, string("BQowjoEdItfBWJeTZyVWOPjGgfAXolWMuXBzMreAwcKymMtrcYvuEziFLpNRhIRWabnYWoTbUKXZXbUheWWwxreCFLeOdakkFsKUsQalMBsmlGhhEERUAoWttNMXLctQQoTibUfdZNrXiZiLuGBVHakJTWikmVqOkGXXZrlYwlsfPbaPQNaLCqouwsPrOxtbogoOiUlSwSHqFVvl"));
    this->Xqujzc(-658021.7169458745, -223818.22631137443, true, -386441576);
    this->VtafKsixN(true, 766657.6589773607);
    this->xiOWFl(-1250597324);
    this->jKCiLCLiASarma(-704218.0547593711, -46831.96139612163, false, -622441.2695547374);
    this->hwNwOTnEXVSd(-973318933, string("zwdRVaIoXJnosrYfGIOfmXcWdCLhOZDepsiEPhYjNKitZAECdxPpVhrWRQzFrMBhGocJqJGFrwThkHOfYHTyTasJjFtpFbvJPQUKbbi"), -1034272.9699347436);
    this->nUNNlYaTdI(-528095.5252451462, true);
    this->reaxylJxL(string("FwfPEoWRnQAJMRlrYPBYbTnBjJJFubvMDrGlAciQUTAFyCIoZSmxxxaSjsbttvdubyAFBxjmfuEdRQMDnZtSRkpKAsosQbBoBOMmVNUEGNwcDGnOAeFxpGhnexiBdKGrGHFMdPxIPmVwkSlwXlV"), string("FAQrWVhaJGkBqqWjpWPSzPkjWbrGbrFYJuOWmZzVLoEohvOnRsKiHeWYaFmWeCXgXqUehIghkineKkWkjRwvxrhSyLjdZirZUoJRjmpdNGDRjpb"), 80949.61847740496, 1243442);
    this->XmqSSU();
    this->hAgdAexWzxqSVc(-292895487, true, -699483.1755380047, -1003465.6000380159);
    this->sJCoaUdzoEU(-970420.2038275416, true, 2114277844, false);
    this->opdpBRBKrrtPUDdb(702721.3295822946, 869343.3126417703, string("VIwnzLaFWFUrEHFAlnICYBeVoeXdFPMLnPmWtFgbICghJhWLXzFNPWyyMvMLjznIvKeJuioZAiHRqlxsNzJNOWChVzpbjWRianMhJyyVDVTtQAlENlNTAzsagOMkGkmlYnKaYsrFaHoxyVzvpRKuasLLWpoExRNBaBotfkDdZpvqwgUDxGuYvVsINNRBEpnSFqidHFVJfwrPiMqNEreDeIP"), 980149.0191206386, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VnJbyzKTgYb
{
public:
    bool hLMTd;

    VnJbyzKTgYb();
    bool yeYFLRX(bool XUfGYrxwH, bool CBmTU, bool lFLThRFeWd, int hKoug);
    bool dfDnty(int UYcPAoDP);
protected:
    double EQpLwtQphv;
    double gwXHRBkoDV;
    double aQOKlbZnu;
    bool lzjDViyzq;
    bool DcldPHNYT;
    int XiFocvXwv;

    double xDSiVDX(string MiJasVE, bool NnwpVRxeE, int LOhgwz, bool GPlYk);
    string enxqbPDOpSe(int GZltBbDIPhhq, string DPVcWnkb, int HqcVteJNJGM, bool ONLCZbwJXZXWeqRC, double yzYoElbS);
    double HLHgt();
    bool CxiYcnWjWUL(int RTICxVzorsvSnJs, int rNLUOsbdG, string jjypJBL, bool COUXrhw);
    double nNbJHoRT(int fRbkIs, string SfeajYAtK);
    string wqgRGVPP(double WdqXuB);
private:
    double JtPGyayHMJ;
    string WMsIzzPWbJOI;
    int rkXyNnuA;

    void cBHTwOACTOJgDsd(bool NZpyRSCBlUJbjhCv, bool bwZkiSaQivRyCrYn);
    void wwEnXScAc(int PnaIxF, bool wduqeM, bool mXKUwMp, string cbuRtA);
    bool lBtMKZdmL(double ThTSTFAAN, bool vwrTuQZpevtSiYpP);
    double rkIEr(int ikZNdxtRW, bool ghOvWR, double XLnNFtplkIokMzp);
    bool KYNkPVRhk(double KONYhcwqQyDMX, int hmThgdCJtxvznaz, int UojRznaDB);
    bool jvYdjwLhYqEXlP(int qdDTGiRHDCsNejF, int NgVYVMshuRc, double gwnPSxPd, double htRpJR);
};

bool VnJbyzKTgYb::yeYFLRX(bool XUfGYrxwH, bool CBmTU, bool lFLThRFeWd, int hKoug)
{
    string RvnNAVFMsp = string("apIXlDjGVgBWDYwjbAMmwCbVUtHmfokHbTlkNXfDLSObqAGbEgplZcNTkMtfoEJbhSTXlTqAdKXlfGpdOiKxIpgIwSexDeWiOxRlcnLUjYbkNnskNTHfikgOVVYJHVDLbAOlzpVLFYnocgulcWQxXpcCBGfDtAWHsFzEXQTfSJPqzEYkJBXcRebp");
    string RLLYp = string("WwVUWKWAhjveNYBzCNKdMRkUzcSKUyvMwjkNXgYiVqegxQzrnzcJXLymCoDAglOeLogEctDqGpbwpdDJzWtuSTvyUkjlWVdskDUAPJBwQeSowidGAxuuWfemjdBMLmdxPnbvRYpXTUiwuHeLpmpKBkEoospvfvswoacEmQVmQwoBCpofpKUIufaFkcuMhBITTyWiLYEXGBEbXomeavtbaCJBds");
    bool fSGpFIYyQilXLI = false;

    for (int HhvnDs = 697402666; HhvnDs > 0; HhvnDs--) {
        XUfGYrxwH = fSGpFIYyQilXLI;
        XUfGYrxwH = XUfGYrxwH;
        CBmTU = ! fSGpFIYyQilXLI;
    }

    for (int dvdWhKzv = 1701143001; dvdWhKzv > 0; dvdWhKzv--) {
        hKoug += hKoug;
        CBmTU = ! lFLThRFeWd;
    }

    for (int kniniKKq = 247244605; kniniKKq > 0; kniniKKq--) {
        lFLThRFeWd = XUfGYrxwH;
    }

    for (int zYcRUNfzgnm = 2017400899; zYcRUNfzgnm > 0; zYcRUNfzgnm--) {
        lFLThRFeWd = ! fSGpFIYyQilXLI;
        RLLYp += RvnNAVFMsp;
        RvnNAVFMsp += RLLYp;
    }

    return fSGpFIYyQilXLI;
}

bool VnJbyzKTgYb::dfDnty(int UYcPAoDP)
{
    double mAwgNBiIiC = 701096.4727645754;
    bool auNpFS = true;
    bool WdLGZh = false;
    bool pjEWeJgrifdvTG = true;
    int nonNM = -1155190859;
    int ibFgTjDx = -7878361;
    string fIljwEBElX = string("bzpCJSWGbCguaSWTTmaUBJKRqTeSlQjsLRrzlApxiOhjUQWbZrFEjPzeJDmzANoledlDmBTMkTRymc");
    bool ulBYyVw = true;

    if (WdLGZh != true) {
        for (int vGkuDXg = 719660827; vGkuDXg > 0; vGkuDXg--) {
            pjEWeJgrifdvTG = WdLGZh;
        }
    }

    return ulBYyVw;
}

double VnJbyzKTgYb::xDSiVDX(string MiJasVE, bool NnwpVRxeE, int LOhgwz, bool GPlYk)
{
    bool uxqjoUmFbiIFGE = true;
    bool ugQLAUtlaWJIj = true;
    double mcpPTWsJa = -756209.5233046033;
    string EZLyOVgopGlwwf = string("oRICHEoQDBACBqtZuaQlFjziSgsaGoppeNLPGgfwHamYoyBokugIzEuFNmsojsLDAbNARGVYw");
    string wMMlNcHgBhKUZ = string("ZYRPRXFVqSegrFjBwGJoavYHMfeZvF");
    string kkKjjjblr = string("tGGrLflYWDwfeogUewdpfQaRWFTwfQHkUOtgxkbvRJxyg");

    for (int rNHTHyOgfXwy = 2089828191; rNHTHyOgfXwy > 0; rNHTHyOgfXwy--) {
        uxqjoUmFbiIFGE = ! uxqjoUmFbiIFGE;
    }

    if (EZLyOVgopGlwwf >= string("plyFclexpQQkqcHzFUGAOTwATJXmBaVDaNAiOAMCJEElDlSCZRlIkPTePyNWDtHFASQnjGeQXGZuDvBPKGdudpdPPskbmagSODBKlwEDtgbgmYHoISSgHqwBAUcNyxWJtftYrNVzshZmLiYhzgPIlOKYfHsPGHIGhYEvEOUcIqtLzcEPyNfonhWkwcZdElwGytOubrEHkmvEwErgugKMpVRwcWVuKpWg")) {
        for (int LzOHzXglTNSrMBo = 2007223060; LzOHzXglTNSrMBo > 0; LzOHzXglTNSrMBo--) {
            GPlYk = ! GPlYk;
        }
    }

    for (int gfhAqhrCxJPhhhE = 1478412073; gfhAqhrCxJPhhhE > 0; gfhAqhrCxJPhhhE--) {
        EZLyOVgopGlwwf += EZLyOVgopGlwwf;
        uxqjoUmFbiIFGE = ! ugQLAUtlaWJIj;
        uxqjoUmFbiIFGE = ! uxqjoUmFbiIFGE;
        ugQLAUtlaWJIj = uxqjoUmFbiIFGE;
    }

    if (MiJasVE == string("tGGrLflYWDwfeogUewdpfQaRWFTwfQHkUOtgxkbvRJxyg")) {
        for (int AhnlFXcjqLbo = 579017875; AhnlFXcjqLbo > 0; AhnlFXcjqLbo--) {
            NnwpVRxeE = uxqjoUmFbiIFGE;
            ugQLAUtlaWJIj = GPlYk;
        }
    }

    return mcpPTWsJa;
}

string VnJbyzKTgYb::enxqbPDOpSe(int GZltBbDIPhhq, string DPVcWnkb, int HqcVteJNJGM, bool ONLCZbwJXZXWeqRC, double yzYoElbS)
{
    double POOFHaTnt = -158979.86244926087;
    bool exScgNxxFEi = false;
    int oaDNUpmozRBT = -601557114;
    string wVNCLlG = string("UKuXZfsFwLkDllZqiMgYKhgxPQiNIojQfgWNYbAGLjUzmXNPvMUrUgchAoazoISZqjJIFaCMoIlUIbmJHxSPIGqSCglAuLmjcTwOKkDiouNvoeCDbaXTcUZQLyGfRHIPZSwaciuLcWqP");
    bool nZjYyaWEj = false;
    bool envwPwsM = false;
    string RqTEq = string("HECDSUDYTAriilUedPEOczTjUQgRmFhCJoCPdFMxrxlBBtKwGNqldBmKYdLbsWOogKzCowqQKaUgIwgqflcrdMMOGAcsGKjUkAujARoCIJlEBqsHQyHurTxMcJPRDdPadiMCNlyJuInDuLFuKLtiJTsNKHJXaEFrPTVYDzRAVEMKJFdhsVEU");
    bool wfkqrFhWagz = false;

    for (int BeIRTpufrXEQ = 459103942; BeIRTpufrXEQ > 0; BeIRTpufrXEQ--) {
        continue;
    }

    for (int zmFVhCLFwqnKfL = 1258021452; zmFVhCLFwqnKfL > 0; zmFVhCLFwqnKfL--) {
        wVNCLlG = wVNCLlG;
    }

    if (exScgNxxFEi == true) {
        for (int CTdxZBEqgd = 1147484599; CTdxZBEqgd > 0; CTdxZBEqgd--) {
            GZltBbDIPhhq = oaDNUpmozRBT;
            ONLCZbwJXZXWeqRC = ONLCZbwJXZXWeqRC;
            wfkqrFhWagz = ! wfkqrFhWagz;
        }
    }

    for (int TQjIWb = 782914498; TQjIWb > 0; TQjIWb--) {
        RqTEq += wVNCLlG;
        wfkqrFhWagz = ! envwPwsM;
    }

    for (int ekqtDMiPfuOg = 51934708; ekqtDMiPfuOg > 0; ekqtDMiPfuOg--) {
        continue;
    }

    for (int oBvNFzRKrARwXV = 529143481; oBvNFzRKrARwXV > 0; oBvNFzRKrARwXV--) {
        envwPwsM = ! envwPwsM;
        envwPwsM = ! exScgNxxFEi;
        POOFHaTnt *= yzYoElbS;
        POOFHaTnt -= POOFHaTnt;
    }

    return RqTEq;
}

double VnJbyzKTgYb::HLHgt()
{
    int Cfoknjhjo = 1333908808;
    int hZKNkrhabzG = 266570345;

    if (hZKNkrhabzG == 266570345) {
        for (int QNjTUTxTGowsTRAt = 478307; QNjTUTxTGowsTRAt > 0; QNjTUTxTGowsTRAt--) {
            Cfoknjhjo /= Cfoknjhjo;
            hZKNkrhabzG *= hZKNkrhabzG;
            hZKNkrhabzG /= Cfoknjhjo;
        }
    }

    return -913059.6337509361;
}

bool VnJbyzKTgYb::CxiYcnWjWUL(int RTICxVzorsvSnJs, int rNLUOsbdG, string jjypJBL, bool COUXrhw)
{
    string gnncSaHkOgvHtN = string("lGizNEdfwKEwkukAUmkrBnaHYyZjIdotkLWWAEkYpoMzyGsPUFhrGUNiuACeqXQOEKpVCubVQelXCM");
    string HiLYWArpoCrZNm = string("OJUUMlMqikWGBsymlkdWbqnUsIGhPetDnkLpvrLtPStCgSBZTMZodXWyjcjFMREjXJYMMCsqLdqRunWVQJikUkTgQVTb");
    int YBzHkizJnTBAYB = 265380273;

    if (RTICxVzorsvSnJs >= 572484387) {
        for (int qTAal = 779349276; qTAal > 0; qTAal--) {
            gnncSaHkOgvHtN += gnncSaHkOgvHtN;
            rNLUOsbdG += rNLUOsbdG;
            COUXrhw = COUXrhw;
        }
    }

    if (jjypJBL != string("OJUUMlMqikWGBsymlkdWbqnUsIGhPetDnkLpvrLtPStCgSBZTMZodXWyjcjFMREjXJYMMCsqLdqRunWVQJikUkTgQVTb")) {
        for (int ELwBCoBUtGlzwX = 864007900; ELwBCoBUtGlzwX > 0; ELwBCoBUtGlzwX--) {
            jjypJBL = gnncSaHkOgvHtN;
            gnncSaHkOgvHtN = jjypJBL;
            HiLYWArpoCrZNm += gnncSaHkOgvHtN;
        }
    }

    return COUXrhw;
}

double VnJbyzKTgYb::nNbJHoRT(int fRbkIs, string SfeajYAtK)
{
    bool EqfQv = false;
    double omQZGNNamHas = -475912.1833043155;
    double cHupxdDdDpI = 987697.2749171685;

    for (int reexZelpkpGHVeK = 500896955; reexZelpkpGHVeK > 0; reexZelpkpGHVeK--) {
        omQZGNNamHas /= cHupxdDdDpI;
    }

    for (int XHzdabnKeVyqK = 1260636600; XHzdabnKeVyqK > 0; XHzdabnKeVyqK--) {
        EqfQv = ! EqfQv;
    }

    if (omQZGNNamHas != 987697.2749171685) {
        for (int cNTuaYz = 524880424; cNTuaYz > 0; cNTuaYz--) {
            omQZGNNamHas += cHupxdDdDpI;
        }
    }

    return cHupxdDdDpI;
}

string VnJbyzKTgYb::wqgRGVPP(double WdqXuB)
{
    string OwwTlhWhyUMmjp = string("crBEUoNLXUDZDFWCINJndfhhZvlkzsmUkSCGfJjeehJKCLBTxnfEgqWRCQjIuiIGJrooSSSnfUbmDdmsHJWTKgDcIMKMAzgWfNVapoyffSYVrdTXXrXUTmPLSlWpEmABUjXSCsMUYSlKkGWjUGgryErmBIxzpeWvWMjGSMInhYMLLdYkMbxkTumzCGXoOxPmAaHHMRG");

    if (OwwTlhWhyUMmjp != string("crBEUoNLXUDZDFWCINJndfhhZvlkzsmUkSCGfJjeehJKCLBTxnfEgqWRCQjIuiIGJrooSSSnfUbmDdmsHJWTKgDcIMKMAzgWfNVapoyffSYVrdTXXrXUTmPLSlWpEmABUjXSCsMUYSlKkGWjUGgryErmBIxzpeWvWMjGSMInhYMLLdYkMbxkTumzCGXoOxPmAaHHMRG")) {
        for (int VlbjzcWHPSD = 681248946; VlbjzcWHPSD > 0; VlbjzcWHPSD--) {
            WdqXuB *= WdqXuB;
            WdqXuB /= WdqXuB;
        }
    }

    return OwwTlhWhyUMmjp;
}

void VnJbyzKTgYb::cBHTwOACTOJgDsd(bool NZpyRSCBlUJbjhCv, bool bwZkiSaQivRyCrYn)
{
    int ZGNETaaJywv = 1757576610;
    bool uxhBHXa = false;

    if (bwZkiSaQivRyCrYn == false) {
        for (int UgOprqwZemgzsZZa = 254621455; UgOprqwZemgzsZZa > 0; UgOprqwZemgzsZZa--) {
            NZpyRSCBlUJbjhCv = ! bwZkiSaQivRyCrYn;
            uxhBHXa = ! uxhBHXa;
            bwZkiSaQivRyCrYn = ! uxhBHXa;
        }
    }

    if (uxhBHXa != false) {
        for (int UzLeXkiPRZ = 273316642; UzLeXkiPRZ > 0; UzLeXkiPRZ--) {
            NZpyRSCBlUJbjhCv = ! NZpyRSCBlUJbjhCv;
            NZpyRSCBlUJbjhCv = uxhBHXa;
            uxhBHXa = NZpyRSCBlUJbjhCv;
        }
    }
}

void VnJbyzKTgYb::wwEnXScAc(int PnaIxF, bool wduqeM, bool mXKUwMp, string cbuRtA)
{
    string DkoldJkqnfxEh = string("DurxiufXLTcywodXfeDYzzMeMFgxSfLZoDKWkciRquOBqNsuQiZsSQgoScalnxUIGDMqxlcOmjacoEZvpXORtSHEQdtOrZltuayrhZReKtytacHRQkVxNzByYcTzgoZTmMmiVNbXQzjxIqwl");
    bool pSChuOMbzNVMI = true;
    double OYVxrgVxWQUml = 507307.08777583024;
    int ZvrFkslyk = -863502414;
    int ePTSUwpaN = -1373349800;
    int LdTwqtEVjhN = -2095607270;

    for (int iCjQkfUcwE = 661354421; iCjQkfUcwE > 0; iCjQkfUcwE--) {
        ZvrFkslyk -= LdTwqtEVjhN;
        wduqeM = mXKUwMp;
        LdTwqtEVjhN /= ZvrFkslyk;
    }

    for (int FcEKgWgMWU = 1180544102; FcEKgWgMWU > 0; FcEKgWgMWU--) {
        PnaIxF /= ZvrFkslyk;
        ZvrFkslyk /= ZvrFkslyk;
    }

    for (int HCreHQkbsLoOoCAH = 381708430; HCreHQkbsLoOoCAH > 0; HCreHQkbsLoOoCAH--) {
        DkoldJkqnfxEh += cbuRtA;
        mXKUwMp = ! pSChuOMbzNVMI;
        mXKUwMp = ! mXKUwMp;
    }

    for (int lTCiXbsz = 1728689585; lTCiXbsz > 0; lTCiXbsz--) {
        pSChuOMbzNVMI = ! wduqeM;
        LdTwqtEVjhN /= LdTwqtEVjhN;
        LdTwqtEVjhN *= ePTSUwpaN;
        ZvrFkslyk = LdTwqtEVjhN;
        mXKUwMp = ! wduqeM;
    }

    if (PnaIxF <= -863502414) {
        for (int mjJMAJrEugMz = 1533070327; mjJMAJrEugMz > 0; mjJMAJrEugMz--) {
            DkoldJkqnfxEh += cbuRtA;
            LdTwqtEVjhN += LdTwqtEVjhN;
        }
    }
}

bool VnJbyzKTgYb::lBtMKZdmL(double ThTSTFAAN, bool vwrTuQZpevtSiYpP)
{
    int OYIIseCmgNmbvTmN = -1736365346;
    string QBtmgqLIfjqo = string("HmyUOgBxiAUJNfvAzSLfbLlDkiNXJGlKHlSFkXxnkxMgaPREtzjmiInHxVnPpQhGBLrURGamWrdSJXwJZLsHtIZQyBrpeenqvVjOqIRdrIsvwtCQhRYDLEZvkLBIyWPypssZHoIJvWqcMjVYGddSCOBCtavnMyFqmTVJcjCWEknlCKMQrXlhjIuJtDHANVtYgTsPMofCweJbMQsJrVUstMaAHwYVYtxIbgBtdmeNzbwpaTyIgPKNSKmpAALZ");
    double aMgTTN = -547241.8835206875;

    for (int uoBSfLXiOLFHLWK = 2029729718; uoBSfLXiOLFHLWK > 0; uoBSfLXiOLFHLWK--) {
        continue;
    }

    for (int OcJmFdWRRypl = 62723618; OcJmFdWRRypl > 0; OcJmFdWRRypl--) {
        vwrTuQZpevtSiYpP = vwrTuQZpevtSiYpP;
    }

    return vwrTuQZpevtSiYpP;
}

double VnJbyzKTgYb::rkIEr(int ikZNdxtRW, bool ghOvWR, double XLnNFtplkIokMzp)
{
    double qXuWGlDrlA = -758038.3745606594;
    double FHiTQnADZAKVaRA = 794286.4225201167;

    for (int bveeI = 468218537; bveeI > 0; bveeI--) {
        qXuWGlDrlA += qXuWGlDrlA;
        XLnNFtplkIokMzp *= FHiTQnADZAKVaRA;
    }

    for (int DNzGTFCTkBZpnlKb = 590508807; DNzGTFCTkBZpnlKb > 0; DNzGTFCTkBZpnlKb--) {
        FHiTQnADZAKVaRA += XLnNFtplkIokMzp;
        FHiTQnADZAKVaRA /= qXuWGlDrlA;
        ghOvWR = ghOvWR;
        qXuWGlDrlA -= qXuWGlDrlA;
        qXuWGlDrlA -= XLnNFtplkIokMzp;
        qXuWGlDrlA /= FHiTQnADZAKVaRA;
        FHiTQnADZAKVaRA /= qXuWGlDrlA;
    }

    for (int EzgSvxp = 973751378; EzgSvxp > 0; EzgSvxp--) {
        continue;
    }

    for (int TqaafIKwpn = 795889727; TqaafIKwpn > 0; TqaafIKwpn--) {
        continue;
    }

    return FHiTQnADZAKVaRA;
}

bool VnJbyzKTgYb::KYNkPVRhk(double KONYhcwqQyDMX, int hmThgdCJtxvznaz, int UojRznaDB)
{
    double gaTcfpULT = 979383.8844221075;
    int kYxaA = 157587700;

    if (KONYhcwqQyDMX > 979383.8844221075) {
        for (int wIYaB = 668577804; wIYaB > 0; wIYaB--) {
            continue;
        }
    }

    if (kYxaA > 1968496094) {
        for (int NtgfVXOzcL = 134178855; NtgfVXOzcL > 0; NtgfVXOzcL--) {
            kYxaA *= hmThgdCJtxvznaz;
        }
    }

    for (int OJsOKyAJn = 1426752107; OJsOKyAJn > 0; OJsOKyAJn--) {
        KONYhcwqQyDMX = KONYhcwqQyDMX;
        gaTcfpULT -= KONYhcwqQyDMX;
        gaTcfpULT /= KONYhcwqQyDMX;
    }

    return false;
}

bool VnJbyzKTgYb::jvYdjwLhYqEXlP(int qdDTGiRHDCsNejF, int NgVYVMshuRc, double gwnPSxPd, double htRpJR)
{
    string JVUksqVz = string("RRLz");
    string QmcrbVr = string("XvdfytcMuVmaLVzTPgOCACbnBitRGbCaqJRvQdkBeXESwiCMoAvFEqwmZzgwKlJmpyYIiDUbyLKmoEKpKWslguMrQEHrqwFgRAweszSikpbvlUbuDRntmNFJqFSdedGmDYasCiCpGIvxQFvLhKjZTVbyLNTXQnBLwJEOyvktGgTbsSlLmxtPwEhbuoMIREiZyCxccWWYZkYCbPemsdu");
    int NzRUfeWNBuAOeFo = 87470162;
    bool PeCaFrkgIUSp = false;
    double nPCVbHfF = 898561.4220583115;
    string OPKMsdJQtW = string("DxbiDfRgolAbFaaDGHVSvEWCRzvrUoEUXFnSTPGHZLBaxkyhJXCirLGLWlRCDofmitrRUuxHRYueUlSBtLFvsBFJrhspoBeShCKqIomGXROBncdBpAMbkxQdcrCSUazbFErJMgSPoETwGBucnAnouIgAhlNTTYEijMCagUplbUKTRrVszOUdTyodPPicmvcABrjiIuGNQqVwaXZzgHboDTDMKZAOmzdOLyN");
    double eRYURzLvulCdOThC = 534688.2468652579;
    double VIgEAxY = 581485.8592036668;
    bool lyDFOEW = false;

    if (QmcrbVr >= string("XvdfytcMuVmaLVzTPgOCACbnBitRGbCaqJRvQdkBeXESwiCMoAvFEqwmZzgwKlJmpyYIiDUbyLKmoEKpKWslguMrQEHrqwFgRAweszSikpbvlUbuDRntmNFJqFSdedGmDYasCiCpGIvxQFvLhKjZTVbyLNTXQnBLwJEOyvktGgTbsSlLmxtPwEhbuoMIREiZyCxccWWYZkYCbPemsdu")) {
        for (int reRncxdagtKFi = 656649120; reRncxdagtKFi > 0; reRncxdagtKFi--) {
            continue;
        }
    }

    for (int fQmpBiXQktyq = 1423358376; fQmpBiXQktyq > 0; fQmpBiXQktyq--) {
        PeCaFrkgIUSp = PeCaFrkgIUSp;
    }

    for (int kRnKwEkT = 6404837; kRnKwEkT > 0; kRnKwEkT--) {
        VIgEAxY *= gwnPSxPd;
    }

    return lyDFOEW;
}

VnJbyzKTgYb::VnJbyzKTgYb()
{
    this->yeYFLRX(true, false, false, 1504059043);
    this->dfDnty(-492666280);
    this->xDSiVDX(string("plyFclexpQQkqcHzFUGAOTwATJXmBaVDaNAiOAMCJEElDlSCZRlIkPTePyNWDtHFASQnjGeQXGZuDvBPKGdudpdPPskbmagSODBKlwEDtgbgmYHoISSgHqwBAUcNyxWJtftYrNVzshZmLiYhzgPIlOKYfHsPGHIGhYEvEOUcIqtLzcEPyNfonhWkwcZdElwGytOubrEHkmvEwErgugKMpVRwcWVuKpWg"), false, 524689222, false);
    this->enxqbPDOpSe(110647291, string("FgJMtKUqyhiggJPGdUeKBhccPBVCewbupFvemTYnGOkrUjTGtgjQYcZJGewUgergMdesoGrLjYIHxfMdjEzKOLhmxwgjsXqFxAfVTsfnomkfFYpZaVXWfNRuzXKrIyPsAKqJzWpvJigOAUWLZsqIKTVeSpWpXdZAhqaCxRPmjvXXTmEUdqDapnHUggCPxkMwShhkUqvfYrRIOBcGmpBILCgJBcUxdyqI"), 1073234638, true, -772264.1068533105);
    this->HLHgt();
    this->CxiYcnWjWUL(1968215701, 572484387, string("noowTVGbMGhzSzrJZtfLRlPNlRIgMcyyJyKDGfBFykCzjymsOOxvBGhRaICajvErxBntyrFXCVRHpHwuzwHanVbNaKCyRrmtotioqygjrXIKmYOvDissaPbMmvaqtVPkwxCqSqzVwccnlMJMkmTXHGKvJYzLuTORziAbcGDodnapisvuhqzlyEHAgSlnzfuLWjznYujRVKpcwcWUWhvbsnTr"), true);
    this->nNbJHoRT(-730526770, string("dNDZJefGEYZhYllugCRTKujNoMnmKYtnhMrTVuomfrnRpbrfrTrlmlilORQzoLTnaiztltZGovmSiYuNrPnu"));
    this->wqgRGVPP(801331.0381967567);
    this->cBHTwOACTOJgDsd(false, false);
    this->wwEnXScAc(302328812, false, true, string("wZtMnujCJgWkjDIUiIZAdnVctUKrPiUMAHGwUPVNcIFnjzbqdzrNKnyQfomWOvhgGkWFxqXlPbnOUFKMGYYFISNsoworPpPCyqvTHlboxMJWQPytTQjuSDyHFwIrGBJV"));
    this->lBtMKZdmL(-339417.70605648676, false);
    this->rkIEr(-1266989412, false, -198951.2814492335);
    this->KYNkPVRhk(-654084.7505907386, -1602127897, 1968496094);
    this->jvYdjwLhYqEXlP(-1362493617, 1413414379, -233801.55898810687, 400115.929372354);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CnhLoHTc
{
public:
    double EoNxYbyK;
    string glOerICjiaSPpS;

    CnhLoHTc();
    int GnxnCh(string qWyRK);
    void ovzLsDNdyC();
    bool inZgEb(string mYnJujRMQTHa, double waRrxbmXQv, int SUqNwqvjX);
    bool YoxhHZXbAhURDOqm(double RXkuaP, double VQLWI, bool qrAnyQ, string VXmiINYpAcRUNZIH, string REmJPydAbrzSMr);
    void qthvF();
    int sUjSyOyNvIjwDWS();
    string zgTyQ(string rQcZDjpJ, double KohLme, double mvxix);
    int rDVrzUcIVCoYj(double UuxkrvSzzdn);
protected:
    string xxRdsIfIy;
    bool jLRQLf;
    bool CuiTTUtdddjQFy;
    string UkqatbnXNtFSnqN;

    void QIxBaIN(double HvGKUGxSw, string EhCqsKLOfgDAi);
    void IfiFW(int IqUQYyWH, int MsaEDZm);
    string TNhuzQZt();
    bool CJYtQYNdqtdjgM(bool XPKeTGVd);
    string bSBZuSbYUnlyOTcd(double HrtqeRZAIEIVAhVS, string SsPyVJXKG, int eMrDsrtV);
    int LszhuH(string wKEzpK, bool SjsQxyU, int qXNsflgB, int lBHcAM, string Rultc);
private:
    bool kLBwHrgWwTtVh;
    string UfizUpN;
    bool IrKOG;

    int FdlNpgKG();
    void ZMhsoDzspWd(bool PjsDPYcN, bool mhFPdiRQJPWaHtbE, double ITqEwMbjBRSFO, double xCUaAMfCUDJ);
    string OkyBGbWdwve(double tcSUZc, double oXykFwjCIm);
};

int CnhLoHTc::GnxnCh(string qWyRK)
{
    int iHlKtmzkNwDceOtc = -895476432;
    int njuiYywNFoLKH = -1118539512;

    if (qWyRK != string("fsUHHWsYGnCdbpVgwHbyKgzbQjjWCahoswoSmXAncnHVPEMkIkrGNTKxVfaxVXQTOBjPMXZGHPkNgiiFsWfPgRhEyUMJKSRixZpONHpyRKQlAznCwkOfrylaPMNRzIfUP")) {
        for (int GOogSAUcAR = 1982595487; GOogSAUcAR > 0; GOogSAUcAR--) {
            njuiYywNFoLKH += iHlKtmzkNwDceOtc;
            iHlKtmzkNwDceOtc += njuiYywNFoLKH;
            njuiYywNFoLKH /= njuiYywNFoLKH;
            qWyRK = qWyRK;
            iHlKtmzkNwDceOtc = njuiYywNFoLKH;
            njuiYywNFoLKH -= iHlKtmzkNwDceOtc;
        }
    }

    for (int QAgdkeBiBRN = 1189376677; QAgdkeBiBRN > 0; QAgdkeBiBRN--) {
        iHlKtmzkNwDceOtc *= njuiYywNFoLKH;
        qWyRK = qWyRK;
        qWyRK = qWyRK;
    }

    if (iHlKtmzkNwDceOtc == -1118539512) {
        for (int nXstFUkwXVjKq = 1674578499; nXstFUkwXVjKq > 0; nXstFUkwXVjKq--) {
            qWyRK += qWyRK;
            njuiYywNFoLKH *= iHlKtmzkNwDceOtc;
            njuiYywNFoLKH *= njuiYywNFoLKH;
            qWyRK = qWyRK;
        }
    }

    for (int MgwniJV = 799637356; MgwniJV > 0; MgwniJV--) {
        iHlKtmzkNwDceOtc = njuiYywNFoLKH;
        iHlKtmzkNwDceOtc -= njuiYywNFoLKH;
        qWyRK = qWyRK;
        njuiYywNFoLKH += njuiYywNFoLKH;
        iHlKtmzkNwDceOtc /= njuiYywNFoLKH;
        iHlKtmzkNwDceOtc = iHlKtmzkNwDceOtc;
    }

    return njuiYywNFoLKH;
}

void CnhLoHTc::ovzLsDNdyC()
{
    int RzhRDSb = 253596213;

    if (RzhRDSb > 253596213) {
        for (int JdyNdHSjs = 1295703821; JdyNdHSjs > 0; JdyNdHSjs--) {
            RzhRDSb = RzhRDSb;
            RzhRDSb += RzhRDSb;
            RzhRDSb -= RzhRDSb;
            RzhRDSb += RzhRDSb;
            RzhRDSb = RzhRDSb;
            RzhRDSb *= RzhRDSb;
            RzhRDSb -= RzhRDSb;
            RzhRDSb *= RzhRDSb;
        }
    }
}

bool CnhLoHTc::inZgEb(string mYnJujRMQTHa, double waRrxbmXQv, int SUqNwqvjX)
{
    string uTsrNYChPoHEwYD = string("EqwfxkggTsZKqjnQXzZOMcZALmHlBBNWfiSlkTXjRgBsUIfIglsgGdWKdQLGXCOIxmfETvRcUOpgAMLgplVyYGiJJFKVCneehYgBzLJBLpllGhSmeQDyfvEBKuqotUIoeXVXwkbYaJtjwaECGjfRmAMnBmEuzsxoEUoVGGyjBJ");
    string CaRsPksVKmEuX = string("dZiuCCiJvhkmfqArFtYoRBmwAGbHmzgGffZLrxMBJtzYhuIsgwjXHpCExUlFrhUoswSPZhpQpoIdgxVCquRJvMHSMjMgsdJUoCfwbuaZbvdVwpAwklIxtYufNkSQEAPnkKQTDDHrbMWbyNssuKiglEZpmVBaGAbbBKbaKJExUkVmjbVbRIielpaZouuTwRKPHNjvkod");
    int hfpbwraNHysLN = 305723930;
    int acaUXVKuQ = 945709527;
    bool BbxDhMofxbFGYMH = false;
    bool iJBRtjA = false;
    bool tMrRFI = false;
    bool EgEnIuEL = false;

    if (EgEnIuEL != false) {
        for (int Dsxtxio = 2068440245; Dsxtxio > 0; Dsxtxio--) {
            continue;
        }
    }

    for (int nFNQMtUsf = 1282132849; nFNQMtUsf > 0; nFNQMtUsf--) {
        uTsrNYChPoHEwYD = CaRsPksVKmEuX;
        uTsrNYChPoHEwYD = mYnJujRMQTHa;
        iJBRtjA = ! EgEnIuEL;
    }

    return EgEnIuEL;
}

bool CnhLoHTc::YoxhHZXbAhURDOqm(double RXkuaP, double VQLWI, bool qrAnyQ, string VXmiINYpAcRUNZIH, string REmJPydAbrzSMr)
{
    double iZtsfOl = 119869.0885665524;
    double lFjRRPngDOF = -203130.3535078519;
    double oDNlfLDM = -172182.543029556;
    bool XqRLYcPf = false;

    if (oDNlfLDM < 119869.0885665524) {
        for (int WmPwxWIFKlCYtf = 1259447049; WmPwxWIFKlCYtf > 0; WmPwxWIFKlCYtf--) {
            oDNlfLDM *= VQLWI;
            lFjRRPngDOF = VQLWI;
            XqRLYcPf = ! XqRLYcPf;
            RXkuaP = iZtsfOl;
        }
    }

    for (int KKWUagVePru = 434591690; KKWUagVePru > 0; KKWUagVePru--) {
        iZtsfOl = oDNlfLDM;
        oDNlfLDM /= RXkuaP;
        qrAnyQ = ! qrAnyQ;
        lFjRRPngDOF -= RXkuaP;
        RXkuaP = oDNlfLDM;
    }

    if (iZtsfOl > -172182.543029556) {
        for (int BvZYFXLnB = 1604805823; BvZYFXLnB > 0; BvZYFXLnB--) {
            qrAnyQ = ! qrAnyQ;
            lFjRRPngDOF -= oDNlfLDM;
            qrAnyQ = qrAnyQ;
        }
    }

    return XqRLYcPf;
}

void CnhLoHTc::qthvF()
{
    double WrxWtyrWFQHDZjxf = -724889.2746382115;
    double RDmjBEs = 933898.894666882;
    int QkQlieg = -2130790895;
    double ADWyPPZUTUb = 842270.4425682087;
    bool WeyFiBM = true;
    double qZUxyFbsO = 35345.90577315364;
    int ooEHNxvTwrfCY = 1140268290;
    int tYqdkV = -738252322;

    for (int kkrejygMtpO = 653245555; kkrejygMtpO > 0; kkrejygMtpO--) {
        continue;
    }
}

int CnhLoHTc::sUjSyOyNvIjwDWS()
{
    string qEGqdCmOmmP = string("KXnAIvjEYarECHDPCGYMxTaAafvuxKsGIilWONlAYvhtMfgVCSKgfibEduhhXnvADsLvzgHngfwzmwkLqEIVvzjeVrPvJC");

    if (qEGqdCmOmmP > string("KXnAIvjEYarECHDPCGYMxTaAafvuxKsGIilWONlAYvhtMfgVCSKgfibEduhhXnvADsLvzgHngfwzmwkLqEIVvzjeVrPvJC")) {
        for (int DlkCOSirZOkm = 1069816495; DlkCOSirZOkm > 0; DlkCOSirZOkm--) {
            qEGqdCmOmmP += qEGqdCmOmmP;
            qEGqdCmOmmP = qEGqdCmOmmP;
            qEGqdCmOmmP = qEGqdCmOmmP;
            qEGqdCmOmmP += qEGqdCmOmmP;
            qEGqdCmOmmP += qEGqdCmOmmP;
            qEGqdCmOmmP += qEGqdCmOmmP;
            qEGqdCmOmmP += qEGqdCmOmmP;
        }
    }

    return 1670483081;
}

string CnhLoHTc::zgTyQ(string rQcZDjpJ, double KohLme, double mvxix)
{
    string oDVkGzxI = string("thViUwdBmsGtaKZUZJTAyhHKzzPPOsbbqmXhmemUHmTANryKLkLeIuWLwdqvUHgKUfQkFOLQokAdFaeLdxObbGDFgwhXJIUJiwpJNpvYZLgbotxhuIgwRaJZxhQCnhNzOeQVaWrRYYzecutfyAnLULSRljaYvWpgLBHSNUmUHSQOqwFPLoSgFHkMRRhEiFxVrmtMMgtNokikLPFbgXb");
    int TomwiRgQMI = -423723063;
    int skXuxn = -528983185;
    int JCRfFToeoln = 1824305505;
    string byOwggOxMkqzyrMY = string("LGVaPVcKWxScfiRUYQgiNsMstxglDrrjRkmfaKI");
    double BnlfNGEmqNYpChG = 68208.65292557758;
    int WjVTDtCY = -359577627;

    for (int BrxCqixio = 127728967; BrxCqixio > 0; BrxCqixio--) {
        JCRfFToeoln = skXuxn;
        WjVTDtCY -= JCRfFToeoln;
        JCRfFToeoln -= WjVTDtCY;
    }

    return byOwggOxMkqzyrMY;
}

int CnhLoHTc::rDVrzUcIVCoYj(double UuxkrvSzzdn)
{
    int waqrcfWQJfag = -683126975;
    bool RQowWCND = true;
    double WiBxUDNtUNbLm = -134787.08211984948;
    int RTDAfE = -1763575809;

    for (int uQsyxpHSlyVSAeEH = 166708311; uQsyxpHSlyVSAeEH > 0; uQsyxpHSlyVSAeEH--) {
        WiBxUDNtUNbLm = UuxkrvSzzdn;
    }

    for (int FlhlpSEVIpRmUjlF = 218363980; FlhlpSEVIpRmUjlF > 0; FlhlpSEVIpRmUjlF--) {
        UuxkrvSzzdn /= UuxkrvSzzdn;
        RTDAfE *= RTDAfE;
        WiBxUDNtUNbLm += WiBxUDNtUNbLm;
    }

    if (waqrcfWQJfag < -683126975) {
        for (int XKPRyNfcj = 1823672011; XKPRyNfcj > 0; XKPRyNfcj--) {
            continue;
        }
    }

    for (int fQVHV = 1538783174; fQVHV > 0; fQVHV--) {
        RTDAfE *= waqrcfWQJfag;
        WiBxUDNtUNbLm = WiBxUDNtUNbLm;
        waqrcfWQJfag -= RTDAfE;
    }

    if (waqrcfWQJfag > -683126975) {
        for (int TpVdArpl = 1275555027; TpVdArpl > 0; TpVdArpl--) {
            RTDAfE /= RTDAfE;
        }
    }

    for (int iJYjJSywd = 1688113042; iJYjJSywd > 0; iJYjJSywd--) {
        UuxkrvSzzdn /= UuxkrvSzzdn;
        RTDAfE += waqrcfWQJfag;
    }

    for (int oWGGnCpoMiHj = 452030559; oWGGnCpoMiHj > 0; oWGGnCpoMiHj--) {
        WiBxUDNtUNbLm -= WiBxUDNtUNbLm;
        waqrcfWQJfag += waqrcfWQJfag;
        waqrcfWQJfag /= waqrcfWQJfag;
    }

    for (int CmTMTmFfPPfJ = 1642577174; CmTMTmFfPPfJ > 0; CmTMTmFfPPfJ--) {
        RTDAfE *= RTDAfE;
        RTDAfE += waqrcfWQJfag;
    }

    for (int mdOioifAy = 2056892335; mdOioifAy > 0; mdOioifAy--) {
        WiBxUDNtUNbLm = WiBxUDNtUNbLm;
        waqrcfWQJfag /= waqrcfWQJfag;
        waqrcfWQJfag -= RTDAfE;
        RQowWCND = ! RQowWCND;
    }

    return RTDAfE;
}

void CnhLoHTc::QIxBaIN(double HvGKUGxSw, string EhCqsKLOfgDAi)
{
    string fxWoUaZBiupiAcOR = string("aemKA");
    double NcJBnyRTQwUlx = -470572.0596057225;
    int DXvcNeEdiqiHErL = -997478080;
    int VwKytdu = 853708661;
    bool bdadHk = false;
    string PbQCs = string("gWHwWAuhrA");
    double WkyuHIj = 432690.3077092427;
    bool PjqUnmHZ = false;

    for (int RxbvgQOzE = 1409067946; RxbvgQOzE > 0; RxbvgQOzE--) {
        WkyuHIj = HvGKUGxSw;
    }

    if (VwKytdu <= -997478080) {
        for (int DfeluimBWuDTMxHE = 1152192380; DfeluimBWuDTMxHE > 0; DfeluimBWuDTMxHE--) {
            WkyuHIj *= HvGKUGxSw;
            fxWoUaZBiupiAcOR = EhCqsKLOfgDAi;
            PjqUnmHZ = PjqUnmHZ;
            fxWoUaZBiupiAcOR += PbQCs;
        }
    }

    for (int PCxCyqCPzfqRVtL = 1876441306; PCxCyqCPzfqRVtL > 0; PCxCyqCPzfqRVtL--) {
        fxWoUaZBiupiAcOR += PbQCs;
    }
}

void CnhLoHTc::IfiFW(int IqUQYyWH, int MsaEDZm)
{
    bool fykzsLHJdTNeHCPP = false;
    int mHFMSwwiiW = 1557221902;
    int CHEfHznVN = -1034194161;
    int ccJOzAO = -376242097;
    double JkyRZEmXqkbGhUZ = 508017.7905330701;
    bool wbvBUVcYfvFXfjP = true;
    string AZvXOv = string("VejfDByXsknwl");

    if (CHEfHznVN != -376242097) {
        for (int OBwmrdPNZVVbJZyl = 142664120; OBwmrdPNZVVbJZyl > 0; OBwmrdPNZVVbJZyl--) {
            IqUQYyWH = IqUQYyWH;
            mHFMSwwiiW /= ccJOzAO;
        }
    }

    for (int PJOTjREt = 2106990726; PJOTjREt > 0; PJOTjREt--) {
        IqUQYyWH /= mHFMSwwiiW;
    }

    if (wbvBUVcYfvFXfjP != false) {
        for (int UCGUHpqFAMyNS = 1924299437; UCGUHpqFAMyNS > 0; UCGUHpqFAMyNS--) {
            ccJOzAO /= IqUQYyWH;
        }
    }

    if (IqUQYyWH >= -376242097) {
        for (int ozupbUa = 1279619976; ozupbUa > 0; ozupbUa--) {
            IqUQYyWH /= mHFMSwwiiW;
            ccJOzAO /= mHFMSwwiiW;
            IqUQYyWH *= CHEfHznVN;
        }
    }

    for (int ZzoKdfDBrisHN = 757197318; ZzoKdfDBrisHN > 0; ZzoKdfDBrisHN--) {
        continue;
    }
}

string CnhLoHTc::TNhuzQZt()
{
    string QuxHf = string("XXTTNmmhWiPGXzHtiOLsDCDBIKvsVMWUiHEQEStNFjgWBwCZvuRt");
    bool DNhwdaCdDdkIDCZc = false;
    int lZUuohmYJ = 272453692;

    for (int PtkcIeqVrwvEyOaL = 1074580940; PtkcIeqVrwvEyOaL > 0; PtkcIeqVrwvEyOaL--) {
        DNhwdaCdDdkIDCZc = ! DNhwdaCdDdkIDCZc;
        DNhwdaCdDdkIDCZc = ! DNhwdaCdDdkIDCZc;
        QuxHf += QuxHf;
    }

    if (lZUuohmYJ < 272453692) {
        for (int rbtZgxrczVtJCW = 371031767; rbtZgxrczVtJCW > 0; rbtZgxrczVtJCW--) {
            continue;
        }
    }

    for (int NhFgHGuimi = 72752920; NhFgHGuimi > 0; NhFgHGuimi--) {
        QuxHf = QuxHf;
        DNhwdaCdDdkIDCZc = ! DNhwdaCdDdkIDCZc;
    }

    return QuxHf;
}

bool CnhLoHTc::CJYtQYNdqtdjgM(bool XPKeTGVd)
{
    string yJaajheag = string("gRHIskONvjpIesGONPuQeALWqPvKtBdPZxgedTkUSBzVuyZLbixRaJHAPsAHxbTgbDzUrqMiXDXfnCMxLnQNjMyzpWYJvgAuKUKOzgrpyAaqamoOkfaIjlqMDDjquuiZtqrsdSsQwOblnoqKPmHjrYxupsAklqkHkeXJrWtQMOFeioIacRqECGGfUkAvaYan");
    bool mcWonNHQ = false;
    bool fvbEQZWTcBoHH = true;
    int UKQPXBbX = -753496907;
    double APNNXTtpd = -174542.24162646235;
    bool BOGlzS = false;

    for (int CfpkOXbgFp = 1802650256; CfpkOXbgFp > 0; CfpkOXbgFp--) {
        XPKeTGVd = ! mcWonNHQ;
        mcWonNHQ = mcWonNHQ;
    }

    return BOGlzS;
}

string CnhLoHTc::bSBZuSbYUnlyOTcd(double HrtqeRZAIEIVAhVS, string SsPyVJXKG, int eMrDsrtV)
{
    double rFebjo = 771471.078944581;
    int GxlaUBPCCVLb = -2086928702;
    int OBxTLBzMilvSg = 415895626;
    double HLNaYBN = -926336.0910854696;
    string GPbelsqcyEjjfn = string("QXoriJffiwMmaujRfuWjpfCSgZdupZKmTJPbFHtENoabGNyBgrNMsmdRFtnqCRqkGpXAyNrZcYbpoGhgHTlWYLJuPQmzKdVNXyffBAFHpLGhQfifoSrAjeWGcUHrigKbOkqpWqhzGdgKNSqogAEYlZc");

    if (GxlaUBPCCVLb != -2086928702) {
        for (int fxJwADy = 658840621; fxJwADy > 0; fxJwADy--) {
            rFebjo = HrtqeRZAIEIVAhVS;
            HrtqeRZAIEIVAhVS += HrtqeRZAIEIVAhVS;
            rFebjo = HLNaYBN;
        }
    }

    return GPbelsqcyEjjfn;
}

int CnhLoHTc::LszhuH(string wKEzpK, bool SjsQxyU, int qXNsflgB, int lBHcAM, string Rultc)
{
    bool SNZkYdn = true;
    string DhqkaFj = string("UDOCskMsnYIJwkHt");
    bool pvOlWwsWW = true;
    int YOsHIXh = -1765085786;
    bool NsHOKYEduCridG = true;
    int EajvePqWFcGfqya = -1422043298;
    int IYigdl = -2053090246;
    int FGCGCMUjmhdHDgrQ = 1051832795;
    bool EOAAU = true;
    string DZwTlgKmQy = string("HzsTCHFmLxDIoyWjmzhlUxAQxrZYyQmhNEJQIpGpZAXyCcTJASctxTXiEaiHGcrTOzpsT");

    for (int ySvZFKPijxcQILvF = 460099388; ySvZFKPijxcQILvF > 0; ySvZFKPijxcQILvF--) {
        continue;
    }

    return FGCGCMUjmhdHDgrQ;
}

int CnhLoHTc::FdlNpgKG()
{
    string xQrTge = string("bAKuRpTAbaULesyHWirHGcGVmxOMfvkMNKylPVgpyvUOUvNzcyR");
    double gACCasId = 708485.9511749418;
    int DYmXzvbbFGmdCBw = 103696476;
    bool XfiDDIQrypTsT = true;
    int CotQJfJaXY = 1728634776;
    string AIGfzOmEE = string("FjExPwXLQosPPvUYbsdplWiUvcgmVZwJTLTGSbOWnuISxCgdgITHFqxevWdclBqjteUeOcVWtLnRgdNsfagRSJBwlRFLpuvaKWtylhjPukBwYUIrfdWlJCiwANnxgMKYDcnSUVlxnYKEhyNdZcqMglEjysCKMvwWaKVyljCRUBapicYZrbndLDMFUWqxvlIzxlElImgNsd");
    string HTXaPSoZptBbz = string("CoIyDoeOOHrroxNYUufWyNLTEsnBulvCgshXkKRgHqTAcXzMioDPXbVzRLfwRyIxqOmWJwRmKqoNgaZSdEGjAzCJaBgWDOFxeEwToMwzENNfjNBDMrupkDAvtAPdGzKykBESrTFnRAsAZrcXfyewNvCJMEsbgIORrgoI");

    for (int obQWshihuvueGig = 519766786; obQWshihuvueGig > 0; obQWshihuvueGig--) {
        continue;
    }

    for (int LAEqIIBtlW = 93088242; LAEqIIBtlW > 0; LAEqIIBtlW--) {
        DYmXzvbbFGmdCBw = CotQJfJaXY;
        DYmXzvbbFGmdCBw /= DYmXzvbbFGmdCBw;
        AIGfzOmEE = AIGfzOmEE;
        DYmXzvbbFGmdCBw += DYmXzvbbFGmdCBw;
        HTXaPSoZptBbz += xQrTge;
    }

    for (int DXIOJ = 990175846; DXIOJ > 0; DXIOJ--) {
        continue;
    }

    if (DYmXzvbbFGmdCBw >= 103696476) {
        for (int BZhFWw = 212223836; BZhFWw > 0; BZhFWw--) {
            CotQJfJaXY += DYmXzvbbFGmdCBw;
        }
    }

    return CotQJfJaXY;
}

void CnhLoHTc::ZMhsoDzspWd(bool PjsDPYcN, bool mhFPdiRQJPWaHtbE, double ITqEwMbjBRSFO, double xCUaAMfCUDJ)
{
    int qXhgclJuRi = 690876057;
    bool aVvdrMvoYlC = true;
    bool UwvUq = true;
    int WGQTjEeD = -149801557;
    bool mBHEss = false;
    string XzwzTk = string("KQghDbuIqgTuwAcAsJdqbxMzCowJvAKeYCdhkQQCStRYSFYhZkeZBCTuOoofJAMDWgqkuRnNNpVwmmyUSbxDZwntlioiItVgoOinASNkEQJUFCMLIGrlyVlowdO");

    if (mhFPdiRQJPWaHtbE != true) {
        for (int UgYaztvyg = 140976059; UgYaztvyg > 0; UgYaztvyg--) {
            continue;
        }
    }

    for (int YuTJTtdFMcxrt = 405208028; YuTJTtdFMcxrt > 0; YuTJTtdFMcxrt--) {
        continue;
    }

    if (PjsDPYcN != true) {
        for (int FHYKFq = 1546926161; FHYKFq > 0; FHYKFq--) {
            WGQTjEeD *= qXhgclJuRi;
            XzwzTk = XzwzTk;
            WGQTjEeD *= qXhgclJuRi;
            WGQTjEeD = WGQTjEeD;
        }
    }

    for (int POHzZXbtk = 1838578306; POHzZXbtk > 0; POHzZXbtk--) {
        PjsDPYcN = UwvUq;
        ITqEwMbjBRSFO = ITqEwMbjBRSFO;
    }

    if (PjsDPYcN == false) {
        for (int izOHyJjk = 651189769; izOHyJjk > 0; izOHyJjk--) {
            mBHEss = ! PjsDPYcN;
            qXhgclJuRi *= WGQTjEeD;
        }
    }

    for (int IazZowCrUt = 2092042169; IazZowCrUt > 0; IazZowCrUt--) {
        UwvUq = PjsDPYcN;
        aVvdrMvoYlC = ! aVvdrMvoYlC;
    }
}

string CnhLoHTc::OkyBGbWdwve(double tcSUZc, double oXykFwjCIm)
{
    string WXlBJsJpznyUbSW = string("evSLFNJpYvTOeUbkLUXLLoxcFiwMTlrMpKyaRfFWjOLRCLouQdMhtQRjCLyPeKdYvSPWSQURGhzkNddeaFnDNvYxobqCNGtsgmmhXgvRflUlrVJOPDVZGtkokZFrgXtGluXByeNGGYbtePteU");

    for (int XmiyBgVjJxcONKs = 233220842; XmiyBgVjJxcONKs > 0; XmiyBgVjJxcONKs--) {
        oXykFwjCIm *= tcSUZc;
        tcSUZc /= tcSUZc;
    }

    if (tcSUZc == 196127.00887743218) {
        for (int nTlHgHLlULBK = 1906210328; nTlHgHLlULBK > 0; nTlHgHLlULBK--) {
            tcSUZc /= tcSUZc;
            WXlBJsJpznyUbSW += WXlBJsJpznyUbSW;
            WXlBJsJpznyUbSW = WXlBJsJpznyUbSW;
            oXykFwjCIm += oXykFwjCIm;
            oXykFwjCIm /= tcSUZc;
        }
    }

    return WXlBJsJpznyUbSW;
}

CnhLoHTc::CnhLoHTc()
{
    this->GnxnCh(string("fsUHHWsYGnCdbpVgwHbyKgzbQjjWCahoswoSmXAncnHVPEMkIkrGNTKxVfaxVXQTOBjPMXZGHPkNgiiFsWfPgRhEyUMJKSRixZpONHpyRKQlAznCwkOfrylaPMNRzIfUP"));
    this->ovzLsDNdyC();
    this->inZgEb(string("taKVWiCJoHQbfeTyhLbNPZAoAIedAhoUNQqItvIbxBDQSRYHfHOjOgdFvhHTpiZoEDXCQTPpcpCuMyytu"), -60275.614577575136, 793378210);
    this->YoxhHZXbAhURDOqm(-345144.98681257013, 475802.97671638575, true, string("AzvMaLAbzgJqktiDuOSmALUhiwwQKhSlulzWOzHZkWcfuCEyKVtZyaAYCJWwXGklQoGykx"), string("aTAbXfiRKkgKpvVSLUyyDuUFKGXJVpKzlEMOTVZhCbNseIlSikLjLxKkYJuTgdBbYasvrLJBFbFeq"));
    this->qthvF();
    this->sUjSyOyNvIjwDWS();
    this->zgTyQ(string("OwWjjUYDfQFEEqRADHXhdDTHyYqwjqNlEseNlRwCqQRUkzRxKZheEWMMfcjcEwXrrWaAFgGHyCDCwlhEZpGcIjityAJQXdqgFfmdmzVUiTbXSmrasUThVntwwzngypYyTnbzHdjuNWeSKFniUMzHDUPMGasVyRdfFOatvAyjqIprFMzVfABxHhwupCOyLVFIVguuQTTDeamjozsVzYjjGcmHLQtoEZphavrOCAqnqpiRY"), 748631.7567786523, -241729.3683407919);
    this->rDVrzUcIVCoYj(802548.886422322);
    this->QIxBaIN(-997185.9302100033, string("dIHsHCIOGgwdtjBsVgaCZ"));
    this->IfiFW(-1273599257, 655160956);
    this->TNhuzQZt();
    this->CJYtQYNdqtdjgM(true);
    this->bSBZuSbYUnlyOTcd(505751.41065331746, string("jqypSMAdfpfnDnnYyizRPmYiikfndiHtFLHFyvvUqXVzCQPXYAAOvyaUhvaaAqlhJUlZWcqJVhbalSmDCtOsuxLmsgWPFxd"), 537835429);
    this->LszhuH(string("EHukKyRSChFhhegSljDZjgJcFlAJQEqXzbUQThUtchOILEJxqnpojzemkpJkOJfCtqmEOcvyvFSPZBbgNoCVJRKEPcdZLlCrkPCamrVqsdmbSaSFPYIgLHawfedrIjzWVqLlqWbSuyIWPXObdvQRQxwEPKreDKpw"), false, 1361895996, -1754879812, string("oIKwXfwyEVJAWRjakmucUPMuLxlOWMUQePVZBySdkuUlaeUQevYpeDiZIvLatFhCBLmcjYGvohLbSzMVpbzYfAiAvLrOTwsLwLR"));
    this->FdlNpgKG();
    this->ZMhsoDzspWd(true, false, -515312.04692303477, -514309.9268417929);
    this->OkyBGbWdwve(196127.00887743218, -919351.62137602);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EiNWPeMd
{
public:
    int DaMXerJRQRqDz;

    EiNWPeMd();
    double TOMXOWxCabQQmJH(double GhMgJzTLbDdz, bool kFWemyvo);
    string LbYkGlabDRT(string RVCREmilaLXM, double VDeyfRfCn, string kLhtRRqtSDjVH);
    string QQyKSqVko(int XilzxbnvkaYtDmF, bool FkPqXSVKWyeopAq);
    void NAfIuPV(bool aOHLFFIQH, double RiUECGrKCu);
    bool RezgafVvvubNjE(string KBbcZqJKzcSibv, bool ZoaXxcJorHZKIG);
    bool YxzneaOVwmTBkP(int GZdcAcbYG, double lUAsdmXGGLyofKM);
    string pTVohAJK(string xhuVo, string cudPygdLcWhj, bool TXlQhDE);
    void avfQWwP(bool cCCSoM, int qMhxJ);
protected:
    int WJYyMrKmpuQVUNw;
    int nTVgEXWrpNzr;
    int pvUEduhbYjExxXCM;
    double tMJaXZdrEcTINyKe;
    bool kDfkuYz;
    double OgIVjuGvjqqfcIn;

    int irwCdGTIHisDlxP(bool PzoQuMBIb);
    bool KzfreZKUpnHWX();
    void FjMPGghhBvodSIR(bool ajSptE, bool bNCtsuShEuO, int GhoStqo);
    int mVTyq(bool ibaWH, int LnuXJnCMneJSp);
    string ybpMXW(int nGXhMsMBZyK, bool OyKFfPVLLryEsSBC, double mvbxbNEzVoMRbxx, string LbjkuSBuN, bool YhXOhVsAIwSLcC);
    int ASXwNWfdBfv();
private:
    double yKCckdlrJkAxVVA;
    bool fofzfvDxXJpGr;
    bool glwAHfUoL;
    string xFyenDMVA;
    bool gtJfWTXwlr;

    double cLTnuDUzL(string rSTJqpviCeShB, double ObdHDUPYyRSQuNfb, string cJvugDpNvYVct);
    string UFzedhqVwsf();
    bool xPuCYAACBLYwfEz(int BcIFRHwWdcHGiV, double DzOgoVu, bool SExXAwbgM, bool TRgxmShY);
    bool IBrZVsdr(string QRWzwzOhc, int wLcmurqCOoxspaEy, int SgFiF, int rcVCfV, int DzVUIABE);
    bool NxutWXqtqDPN();
    void jHKdLNBuiuz(bool LrYwUoHm);
    bool HavUTtkawVm(double oZxRkd, int IbxCeglw, int VcvQjyeWoXXEykTo, string XkIrTJCJorObt, string MKgHHTWmf);
    double DxgdIZqokIHPA();
};

double EiNWPeMd::TOMXOWxCabQQmJH(double GhMgJzTLbDdz, bool kFWemyvo)
{
    string wJCGmxHzKMwWy = string("OLyPcjjukNeYrXbeodhpGfonoVbuGQxaAatvuTAujzmtewGgXMOroZwhUlBvFglVHEvtviayZZRTGaVFmGrKOXHWUHfqieyJtzmyFVTvcmvrdmsqhMnirvUVQKxOIhBAwOVPUJqrqrCIzGhDdoJbutGQwWJrCMWmcDfkoHKORNoucy");
    string yJiCDCduZgbdwxQf = string("KBexRsfrVULIXRQQoTcgNLJQkxOtwRqlcuMqZLYNbDPLYCXLmslhclFlRADDeoaDMyComBvniEWBmpjlZeTtTLNXyMAKKncICehtyzZTvqGfaClsXwNulJzryrErouIvGRfZYLqodaeNEeEvPwTltEvBnKiVUxTmtztHnbltipEDBKXRyYrefDKeQtVDIVPDjLSrQFXsOAllBvupxh");
    string snuIOCjWElzZcsf = string("YxZPwZxBLoqcMD");

    if (yJiCDCduZgbdwxQf < string("KBexRsfrVULIXRQQoTcgNLJQkxOtwRqlcuMqZLYNbDPLYCXLmslhclFlRADDeoaDMyComBvniEWBmpjlZeTtTLNXyMAKKncICehtyzZTvqGfaClsXwNulJzryrErouIvGRfZYLqodaeNEeEvPwTltEvBnKiVUxTmtztHnbltipEDBKXRyYrefDKeQtVDIVPDjLSrQFXsOAllBvupxh")) {
        for (int OWtNx = 170229450; OWtNx > 0; OWtNx--) {
            yJiCDCduZgbdwxQf += wJCGmxHzKMwWy;
            wJCGmxHzKMwWy += yJiCDCduZgbdwxQf;
            snuIOCjWElzZcsf += snuIOCjWElzZcsf;
            yJiCDCduZgbdwxQf += wJCGmxHzKMwWy;
        }
    }

    return GhMgJzTLbDdz;
}

string EiNWPeMd::LbYkGlabDRT(string RVCREmilaLXM, double VDeyfRfCn, string kLhtRRqtSDjVH)
{
    double RDeijJIA = -1033004.4612499515;
    double ThIoWN = 931472.4787719797;
    double zIUiXGOPDCzIOSw = 354020.64074006345;
    string ACsSpPmcMKYMVmKo = string("nhQlaxeRaKiydqBorptBZusLjTeKtbouUxoRrPaugQSzZEZGWiLoumdwSYEwDEbAzmnhgSjGRvYfbRwtOGZMwOpLMUjVROlNYOMcDTHQaydhMueVkXXWju");
    bool hFdHk = false;
    double HoUrQasIGYYrzaNI = 974992.5824754498;
    string brExmqZX = string("bFknziLVjlGXZNITtSgTbrxuCrCrTUugWmdZEqagRJLKNeunInLSDeamvHwUrUMmUhtdqslYNIUNSgeHuPLLeynMmYSSTedyfLaoxsSOpxqmokPaRmmwjGBuwbWDOBUGtSCnHPnrWUinprIwSnSqNXmtDpuFicsthEFhRECdtzHRpLxKDu");
    bool xAGQp = false;
    double uVWNdnX = -429592.23242819513;

    for (int ZllDjN = 1361126802; ZllDjN > 0; ZllDjN--) {
        uVWNdnX += ThIoWN;
        brExmqZX += kLhtRRqtSDjVH;
    }

    return brExmqZX;
}

string EiNWPeMd::QQyKSqVko(int XilzxbnvkaYtDmF, bool FkPqXSVKWyeopAq)
{
    int lWSuWm = -2122456923;

    if (FkPqXSVKWyeopAq == false) {
        for (int lXPngCtFb = 246859772; lXPngCtFb > 0; lXPngCtFb--) {
            XilzxbnvkaYtDmF /= lWSuWm;
            XilzxbnvkaYtDmF -= lWSuWm;
            XilzxbnvkaYtDmF /= lWSuWm;
            XilzxbnvkaYtDmF /= XilzxbnvkaYtDmF;
            XilzxbnvkaYtDmF -= lWSuWm;
            lWSuWm -= lWSuWm;
            FkPqXSVKWyeopAq = FkPqXSVKWyeopAq;
            XilzxbnvkaYtDmF += lWSuWm;
        }
    }

    if (XilzxbnvkaYtDmF != -2122456923) {
        for (int OauqlNhVr = 1042203537; OauqlNhVr > 0; OauqlNhVr--) {
            XilzxbnvkaYtDmF /= lWSuWm;
            lWSuWm += lWSuWm;
        }
    }

    for (int QJTdRjVc = 234957171; QJTdRjVc > 0; QJTdRjVc--) {
        FkPqXSVKWyeopAq = FkPqXSVKWyeopAq;
    }

    if (lWSuWm != -2122456923) {
        for (int FdQEA = 917483475; FdQEA > 0; FdQEA--) {
            lWSuWm *= lWSuWm;
            FkPqXSVKWyeopAq = FkPqXSVKWyeopAq;
        }
    }

    if (XilzxbnvkaYtDmF >= -2122456923) {
        for (int WLSNboPurhdRXBzU = 231734944; WLSNboPurhdRXBzU > 0; WLSNboPurhdRXBzU--) {
            FkPqXSVKWyeopAq = FkPqXSVKWyeopAq;
            FkPqXSVKWyeopAq = ! FkPqXSVKWyeopAq;
            FkPqXSVKWyeopAq = ! FkPqXSVKWyeopAq;
            FkPqXSVKWyeopAq = FkPqXSVKWyeopAq;
            lWSuWm = XilzxbnvkaYtDmF;
        }
    }

    return string("ornZspIoDidKYLWISqpsoKGbTKlAtnYrMSgMugnMZlZFraxCwbIaeCrUcjBJsNSSCmhhMQJGCUtytNPvsUcizovfIulDFtPnDPJvsZPnwZV");
}

void EiNWPeMd::NAfIuPV(bool aOHLFFIQH, double RiUECGrKCu)
{
    bool qaDLdphUIDwbvIAd = true;
    string KiwPf = string("hfgsbmpTYpgCW");
    bool eDDubjoZhJAfVNsr = true;
    bool lSGTgDRmOnM = false;
    bool yfbhyfpFY = false;
    bool UJTPkyiGeQGgweT = true;

    if (lSGTgDRmOnM == true) {
        for (int xzZIFtLEenKNfPF = 1330093979; xzZIFtLEenKNfPF > 0; xzZIFtLEenKNfPF--) {
            qaDLdphUIDwbvIAd = ! lSGTgDRmOnM;
            lSGTgDRmOnM = ! aOHLFFIQH;
            UJTPkyiGeQGgweT = yfbhyfpFY;
            lSGTgDRmOnM = ! aOHLFFIQH;
        }
    }

    if (lSGTgDRmOnM == false) {
        for (int QXbyDIylJl = 735858362; QXbyDIylJl > 0; QXbyDIylJl--) {
            continue;
        }
    }

    if (lSGTgDRmOnM == false) {
        for (int zwyPClP = 1874338241; zwyPClP > 0; zwyPClP--) {
            UJTPkyiGeQGgweT = yfbhyfpFY;
            lSGTgDRmOnM = qaDLdphUIDwbvIAd;
            yfbhyfpFY = UJTPkyiGeQGgweT;
        }
    }

    for (int SjiPyERTezI = 488846449; SjiPyERTezI > 0; SjiPyERTezI--) {
        aOHLFFIQH = ! yfbhyfpFY;
        UJTPkyiGeQGgweT = yfbhyfpFY;
    }

    if (yfbhyfpFY == true) {
        for (int efKYeYiTqbVugImv = 1553554980; efKYeYiTqbVugImv > 0; efKYeYiTqbVugImv--) {
            KiwPf += KiwPf;
            yfbhyfpFY = ! yfbhyfpFY;
        }
    }

    if (UJTPkyiGeQGgweT != false) {
        for (int yvDSvz = 512967843; yvDSvz > 0; yvDSvz--) {
            continue;
        }
    }

    if (aOHLFFIQH != true) {
        for (int SbsyenuSwEG = 429538605; SbsyenuSwEG > 0; SbsyenuSwEG--) {
            lSGTgDRmOnM = lSGTgDRmOnM;
            qaDLdphUIDwbvIAd = ! lSGTgDRmOnM;
        }
    }
}

bool EiNWPeMd::RezgafVvvubNjE(string KBbcZqJKzcSibv, bool ZoaXxcJorHZKIG)
{
    int TFMSKXc = 1801861747;
    int BPdXORrzPfi = -872976467;
    string GxPIoSTJkELq = string("EvscvsJdFoMoRSCGZuKGguDbtNSmGxVppghdQSDhepnfEHzRcpafIcKyYzZTpYEKqrPPMOjoWlAnHNfeInstgSQHxjwjtwtSoXODGwevxLuGCdJKsOpVEMmonOBrXagKfVvvIygALkCbkWROUfPLFUfWGDEvAMgXKJrvVNjPMFDaJEFVzQDtClQtShCuAHcbjkLqBABVPccjeXvWyvRMJTyxqSAHnbpAIt");
    bool hTxUIVIXpyGoJ = false;

    for (int rDsxtLlqwKhQzfeX = 1664490960; rDsxtLlqwKhQzfeX > 0; rDsxtLlqwKhQzfeX--) {
        ZoaXxcJorHZKIG = ZoaXxcJorHZKIG;
    }

    for (int BFKYSCt = 1886480849; BFKYSCt > 0; BFKYSCt--) {
        ZoaXxcJorHZKIG = ! hTxUIVIXpyGoJ;
    }

    if (KBbcZqJKzcSibv <= string("EvscvsJdFoMoRSCGZuKGguDbtNSmGxVppghdQSDhepnfEHzRcpafIcKyYzZTpYEKqrPPMOjoWlAnHNfeInstgSQHxjwjtwtSoXODGwevxLuGCdJKsOpVEMmonOBrXagKfVvvIygALkCbkWROUfPLFUfWGDEvAMgXKJrvVNjPMFDaJEFVzQDtClQtShCuAHcbjkLqBABVPccjeXvWyvRMJTyxqSAHnbpAIt")) {
        for (int AdVOhFkaIZTtv = 721741104; AdVOhFkaIZTtv > 0; AdVOhFkaIZTtv--) {
            BPdXORrzPfi -= TFMSKXc;
        }
    }

    return hTxUIVIXpyGoJ;
}

bool EiNWPeMd::YxzneaOVwmTBkP(int GZdcAcbYG, double lUAsdmXGGLyofKM)
{
    bool okhFlkvavDRkaFq = false;

    for (int WbGBYdbBXTtMuFi = 970418414; WbGBYdbBXTtMuFi > 0; WbGBYdbBXTtMuFi--) {
        lUAsdmXGGLyofKM += lUAsdmXGGLyofKM;
        okhFlkvavDRkaFq = ! okhFlkvavDRkaFq;
        okhFlkvavDRkaFq = okhFlkvavDRkaFq;
        GZdcAcbYG *= GZdcAcbYG;
    }

    for (int RgmJX = 1339068230; RgmJX > 0; RgmJX--) {
        lUAsdmXGGLyofKM += lUAsdmXGGLyofKM;
    }

    if (lUAsdmXGGLyofKM < -444717.75339091296) {
        for (int IBmZWqxKN = 177757791; IBmZWqxKN > 0; IBmZWqxKN--) {
            GZdcAcbYG -= GZdcAcbYG;
            GZdcAcbYG *= GZdcAcbYG;
            okhFlkvavDRkaFq = okhFlkvavDRkaFq;
            lUAsdmXGGLyofKM -= lUAsdmXGGLyofKM;
        }
    }

    for (int OfqxfMA = 945960499; OfqxfMA > 0; OfqxfMA--) {
        GZdcAcbYG += GZdcAcbYG;
        lUAsdmXGGLyofKM *= lUAsdmXGGLyofKM;
        GZdcAcbYG *= GZdcAcbYG;
    }

    return okhFlkvavDRkaFq;
}

string EiNWPeMd::pTVohAJK(string xhuVo, string cudPygdLcWhj, bool TXlQhDE)
{
    string xcaVnmOrKQKHwDX = string("cHjQxVJsyOkthgvOQEuqsswSUAfQxdaL");
    bool TWfsQeO = false;

    if (TWfsQeO == false) {
        for (int oQcaKGwYlEHjxzN = 782116285; oQcaKGwYlEHjxzN > 0; oQcaKGwYlEHjxzN--) {
            xhuVo += xcaVnmOrKQKHwDX;
            cudPygdLcWhj += xhuVo;
            TXlQhDE = TXlQhDE;
            xhuVo += xcaVnmOrKQKHwDX;
            cudPygdLcWhj += cudPygdLcWhj;
        }
    }

    for (int szUyEqgFFNT = 1796122410; szUyEqgFFNT > 0; szUyEqgFFNT--) {
        xhuVo += xcaVnmOrKQKHwDX;
        cudPygdLcWhj = xcaVnmOrKQKHwDX;
    }

    return xcaVnmOrKQKHwDX;
}

void EiNWPeMd::avfQWwP(bool cCCSoM, int qMhxJ)
{
    string uciMftHZL = string("ZopQbQBjoXQBoIJWBAPORAGipkjNwzHGmhMDAFePhOnrkjKpgHbWYEPTNgvdicCJIKqqPgYNSNOQSOIzHjyQxyONsvqDTUSRptrpaSDkOhBDntkMjSCBLUjuVNXJtmcllvhrdetZAdmtHTorYmlMnjpPjWIqajHxJquuAJPqDTHiCNPOsrxDXKgDFsmwrvEaDWIX");
    bool aFMSeznUqbULFIVG = false;
    string xNNneKCtdvhsIOB = string("vbJcMtprJNnrmZBQLoGBZHOumRazYcRDjeEILSuRHtliKsMViwMKWRncoBWFVMwzwGBEQPrlRtpzmJLWHAOJEAXjMeIPcDmJqDEoqQGMpmhBUsuPtSAGAZiYtEMUkJOYPdgkJWLuAYfbwPbPPfunWeegVNoMSwQWDbBrSVdysuyRHnxftIzpjMGEJAyvwtHNDfL");
    double sBeyIGHdfxNqz = -403676.11966164625;

    for (int ebTZYyATon = 484669576; ebTZYyATon > 0; ebTZYyATon--) {
        continue;
    }

    for (int YoBdNMAbHxRWX = 1866590615; YoBdNMAbHxRWX > 0; YoBdNMAbHxRWX--) {
        sBeyIGHdfxNqz /= sBeyIGHdfxNqz;
        aFMSeznUqbULFIVG = aFMSeznUqbULFIVG;
    }
}

int EiNWPeMd::irwCdGTIHisDlxP(bool PzoQuMBIb)
{
    double RCQLEobdc = -935866.5089542087;
    double MIFNrTOJxQZDzb = -991958.6591300729;
    string hVosFJFgBLneSD = string("UuvAsuteyfLHOainfRrVWXEeooYmmdLSuXRtIrLQWmNrjMZGmCWfdoPzxaWWtOSilCSmUdFmNuQpdxNRcNNBABvaOHzebDqGNIwbjXMNspvEcPNxuZROtUqOTmJqwNJgKCxrqDzWlLDFjdGEGpRfeWQNKRcudhazBouNiHSmYLWDCTypkwsZIoxAuInXjnnjxktJUYnIClugrGRHVidrhKrsOfFopSIEQAb");
    int cQSMFNS = -3173608;

    for (int CkgtA = 1059360551; CkgtA > 0; CkgtA--) {
        MIFNrTOJxQZDzb += MIFNrTOJxQZDzb;
        MIFNrTOJxQZDzb += RCQLEobdc;
        MIFNrTOJxQZDzb /= RCQLEobdc;
        cQSMFNS /= cQSMFNS;
    }

    for (int ZdKtBSLClJcX = 1131632562; ZdKtBSLClJcX > 0; ZdKtBSLClJcX--) {
        PzoQuMBIb = PzoQuMBIb;
        RCQLEobdc = MIFNrTOJxQZDzb;
    }

    if (RCQLEobdc != -935866.5089542087) {
        for (int LDEnlySp = 1471551253; LDEnlySp > 0; LDEnlySp--) {
            PzoQuMBIb = PzoQuMBIb;
        }
    }

    for (int ZxiUZATXUfU = 1494883129; ZxiUZATXUfU > 0; ZxiUZATXUfU--) {
        PzoQuMBIb = ! PzoQuMBIb;
        MIFNrTOJxQZDzb = RCQLEobdc;
    }

    return cQSMFNS;
}

bool EiNWPeMd::KzfreZKUpnHWX()
{
    bool TYrECLYaN = false;
    string sMXdp = string("nlTQxkWvcZwyNsbrjwKDFBlrUfZVEapOvwalydzcWwsysykGEGhFUCgrXuUmNwpbZDwuzEfAYQHnAkJqymtoUkFTpVDDDvBCIHPiNIjvwqddTVKWnGjLIEZTDoxUPwdgaRSOEGUnxzUQYaruJrOsCAPdvPkbNgxgtDbEUHnHGZfWeKCqKiinHuyNAYyI");
    bool qQAFudZZOsW = true;
    bool PAoArfVYfg = false;
    bool kRrfIsjvhJoxUtqa = false;
    double jFxqwRzWep = -811334.4124750628;

    for (int BabhaIOMBWYjgkjk = 2029479727; BabhaIOMBWYjgkjk > 0; BabhaIOMBWYjgkjk--) {
        PAoArfVYfg = ! kRrfIsjvhJoxUtqa;
        kRrfIsjvhJoxUtqa = ! PAoArfVYfg;
        TYrECLYaN = TYrECLYaN;
    }

    return kRrfIsjvhJoxUtqa;
}

void EiNWPeMd::FjMPGghhBvodSIR(bool ajSptE, bool bNCtsuShEuO, int GhoStqo)
{
    bool MdZInlEePdByVSC = true;
    int WPjODCFaqkt = 2024394214;
    string FiDiCOAGPW = string("rAFGTnBIsiLwmURmeGBYPFLPHDnmgxVQLczPEGbJMHQmocnzqMVjixPSRkjdVILyQovOtTmnofxqDVStTTYQSjbbBQjsHkpEEAxnNXuKxVqNNFVOpepgshHJhWhCExcRLnEjTJTVBYCKvegvpHAaaYKKnMn");
    double uiKeUBi = -577498.6156329514;
    bool sSYkmMsvS = true;
    bool ioNHDlunafAPgA = false;
    bool iCMcgLBQYPIY = false;
    string fBJYdVXjopb = string("SrlfARBWFAIBbRUgrTpAkkCnmyXOEdZOoMeJHxnuYFZLDJFrzEJbcnZVTdBaLUyKJbnHcTDIVbTMRuThRBusjqNwCWGF");
    int LyzpzcEEiSrwZVG = 101636050;
    bool cmpIDQS = true;

    for (int zGILfg = 761932225; zGILfg > 0; zGILfg--) {
        continue;
    }

    if (MdZInlEePdByVSC != false) {
        for (int YfHqCqNsrQRZ = 420734726; YfHqCqNsrQRZ > 0; YfHqCqNsrQRZ--) {
            WPjODCFaqkt = WPjODCFaqkt;
        }
    }

    for (int ZkXxdjBndcdbm = 415347978; ZkXxdjBndcdbm > 0; ZkXxdjBndcdbm--) {
        continue;
    }

    for (int qsUbZwQzlSJRR = 1039970687; qsUbZwQzlSJRR > 0; qsUbZwQzlSJRR--) {
        WPjODCFaqkt += LyzpzcEEiSrwZVG;
        ajSptE = MdZInlEePdByVSC;
    }

    for (int ovgRbkIBfU = 783125988; ovgRbkIBfU > 0; ovgRbkIBfU--) {
        ajSptE = ! iCMcgLBQYPIY;
        uiKeUBi /= uiKeUBi;
        ioNHDlunafAPgA = MdZInlEePdByVSC;
        sSYkmMsvS = ! iCMcgLBQYPIY;
    }
}

int EiNWPeMd::mVTyq(bool ibaWH, int LnuXJnCMneJSp)
{
    bool JkpckWtrtritomU = false;
    bool IBviMe = false;
    double zaRQplLX = -819635.4577396704;
    int yoXfs = 1208458185;
    int IyfBsEn = -317586941;
    bool jCOHyZZ = false;
    bool IJblkhFebPNb = true;
    int qdPRh = -1888526117;
    int vjEeeXjINR = -641125170;
    double cRyArWprgjocg = 329479.81014512625;

    if (JkpckWtrtritomU != false) {
        for (int HRLrSboqQIhroj = 1632209115; HRLrSboqQIhroj > 0; HRLrSboqQIhroj--) {
            JkpckWtrtritomU = IBviMe;
        }
    }

    for (int IXWbtYyLnJguc = 927789838; IXWbtYyLnJguc > 0; IXWbtYyLnJguc--) {
        IJblkhFebPNb = ! jCOHyZZ;
        zaRQplLX -= zaRQplLX;
    }

    if (zaRQplLX != 329479.81014512625) {
        for (int ypApwdiSnMVFMJXA = 1883383545; ypApwdiSnMVFMJXA > 0; ypApwdiSnMVFMJXA--) {
            IyfBsEn = vjEeeXjINR;
        }
    }

    for (int oTuoLwVnkIeDydn = 64488786; oTuoLwVnkIeDydn > 0; oTuoLwVnkIeDydn--) {
        IBviMe = jCOHyZZ;
        yoXfs *= IyfBsEn;
    }

    return vjEeeXjINR;
}

string EiNWPeMd::ybpMXW(int nGXhMsMBZyK, bool OyKFfPVLLryEsSBC, double mvbxbNEzVoMRbxx, string LbjkuSBuN, bool YhXOhVsAIwSLcC)
{
    int NINeK = 228771838;
    string cAdMJjt = string("wouYfpromVdOEwxoMLSfhlWEHuVwWDNCJhOoDSBQcDbVnxamceVDnlLJybbdgYjsjLsFoRmXEhDubZVQwAWpxiUkuWhBEKeDPwImBCNqjeeiOYBUcBHxxStfHxNJYXueVgWOyFZSMRpeDVFzMKvJgeeqAibuRQUwXXokDynZvvCCjqtzZNusoHXpkslSTjzMRTGwtwnNMOMarYSOHimKlusQLWrriMPfbQAMOaThO");
    bool uNSYDSIWWcGReCNh = false;
    string oEKZYne = string("WoBmDINqoZrytwhQRFgT");
    bool tkXOWAGABBsj = false;

    for (int KLhgCddF = 1430879823; KLhgCddF > 0; KLhgCddF--) {
        continue;
    }

    return oEKZYne;
}

int EiNWPeMd::ASXwNWfdBfv()
{
    string wYLCpzebW = string("fXydGKgOoaVRLXFCkLiUUGMJkjaaavLogcWkAbutSwMMdUlvxToZycUlGwnZP");
    int sxKkPUbvmUUxqE = -2036567496;
    bool nhnubRCjW = false;

    for (int ErkEyecNtN = 188419215; ErkEyecNtN > 0; ErkEyecNtN--) {
        wYLCpzebW += wYLCpzebW;
    }

    for (int BOUsnm = 876190950; BOUsnm > 0; BOUsnm--) {
        sxKkPUbvmUUxqE = sxKkPUbvmUUxqE;
        nhnubRCjW = ! nhnubRCjW;
        wYLCpzebW += wYLCpzebW;
    }

    for (int bUqmVaAfoX = 2124046300; bUqmVaAfoX > 0; bUqmVaAfoX--) {
        continue;
    }

    return sxKkPUbvmUUxqE;
}

double EiNWPeMd::cLTnuDUzL(string rSTJqpviCeShB, double ObdHDUPYyRSQuNfb, string cJvugDpNvYVct)
{
    double tvhvKwqT = -410687.8171905931;
    int ZJHkTxrMzd = 975488907;
    bool pCOLxgujCL = false;
    double XYQwAQKrDwHqGwx = 719737.4388625574;
    int CsMFFKVq = 1428235494;
    string PKHtyHdjf = string("LwgKRkWdkPJSKxBQxpIcqHmywxDhTzaZBVYCbAAORaPsLfMeMxNJeNBIwrgJAiRdhccWolAoFRyjrjDTZLhOIRkwnRiJLkKILEeISvAHCCKSahnAAwZfSMgOVIRpQkuFWCVwVaXfzL");

    for (int aBqvABr = 1824470788; aBqvABr > 0; aBqvABr--) {
        rSTJqpviCeShB = PKHtyHdjf;
    }

    if (tvhvKwqT >= 719737.4388625574) {
        for (int IjlKDCfshQ = 506256866; IjlKDCfshQ > 0; IjlKDCfshQ--) {
            XYQwAQKrDwHqGwx /= XYQwAQKrDwHqGwx;
            CsMFFKVq -= ZJHkTxrMzd;
        }
    }

    for (int MadEwOO = 1070834804; MadEwOO > 0; MadEwOO--) {
        tvhvKwqT -= XYQwAQKrDwHqGwx;
        CsMFFKVq = CsMFFKVq;
        XYQwAQKrDwHqGwx *= XYQwAQKrDwHqGwx;
        pCOLxgujCL = ! pCOLxgujCL;
    }

    if (ZJHkTxrMzd != 1428235494) {
        for (int UDVbBBs = 2040180425; UDVbBBs > 0; UDVbBBs--) {
            continue;
        }
    }

    for (int bOARj = 707064531; bOARj > 0; bOARj--) {
        XYQwAQKrDwHqGwx *= tvhvKwqT;
        ObdHDUPYyRSQuNfb *= tvhvKwqT;
        ObdHDUPYyRSQuNfb *= XYQwAQKrDwHqGwx;
        ObdHDUPYyRSQuNfb -= tvhvKwqT;
        ZJHkTxrMzd = CsMFFKVq;
    }

    return XYQwAQKrDwHqGwx;
}

string EiNWPeMd::UFzedhqVwsf()
{
    int YHEBhDkcwv = -1186454461;
    int ZhJJzeTYstCdcGnT = 338530648;
    string xaOyGSezcaA = string("iLrLLSIblKlpxMrqNfTzyaYnWbDHEQujlCIgIihSEVqXOmJyaQSgnSeVOgkjvNZHiohKHYxfTVlnWLoTXIIxuatXsYvxJzwxTXMZKSwLjCbPogpapIlNKBRTeKBqadqlmuqlbhkeZieleEdItypfyOuYHA");
    bool PTVQr = false;
    int Xnjzuthmvbaer = 1776678840;
    bool qztDp = true;

    for (int MAZKpQrWvzaN = 97898462; MAZKpQrWvzaN > 0; MAZKpQrWvzaN--) {
        qztDp = PTVQr;
    }

    if (Xnjzuthmvbaer < 1776678840) {
        for (int ZgvoY = 454637280; ZgvoY > 0; ZgvoY--) {
            Xnjzuthmvbaer -= ZhJJzeTYstCdcGnT;
        }
    }

    for (int wALaVRKEFlbhT = 254203141; wALaVRKEFlbhT > 0; wALaVRKEFlbhT--) {
        YHEBhDkcwv /= ZhJJzeTYstCdcGnT;
        Xnjzuthmvbaer /= YHEBhDkcwv;
        Xnjzuthmvbaer += Xnjzuthmvbaer;
    }

    for (int anDFbZXzWkmZSa = 352349332; anDFbZXzWkmZSa > 0; anDFbZXzWkmZSa--) {
        YHEBhDkcwv *= ZhJJzeTYstCdcGnT;
        Xnjzuthmvbaer *= YHEBhDkcwv;
        ZhJJzeTYstCdcGnT *= Xnjzuthmvbaer;
        xaOyGSezcaA = xaOyGSezcaA;
    }

    return xaOyGSezcaA;
}

bool EiNWPeMd::xPuCYAACBLYwfEz(int BcIFRHwWdcHGiV, double DzOgoVu, bool SExXAwbgM, bool TRgxmShY)
{
    bool LDNkKwRSY = true;
    int jSrGNpvUgYAWep = 1772064391;
    double wDgOHegASrp = -703158.6240022592;
    bool TFjNvksJ = true;
    double OSevrgVbmEVVe = 699812.4691150251;
    int qOUGhDJaT = 309865935;
    string CMGxZjiiV = string("XQyCoOKarsnUJAsUDuWwYVjoIUXwUCpvuCVlHirZMljKKPAcffbolqZFCNjMfZsVlsJFtRQQnuMaOtMpZDuBPtONwwMWfmwQrIeymDsmjmtOSBiMcjHEdwSqDFpLSBBPbQgmpCiDrONTKUTqXEkZSOxFMxYXmxrFgJydhAL");
    bool UzXIbmezXy = true;
    double yAMfXLP = 584456.0981016426;
    double Fruzk = -127616.86028178432;

    if (CMGxZjiiV == string("XQyCoOKarsnUJAsUDuWwYVjoIUXwUCpvuCVlHirZMljKKPAcffbolqZFCNjMfZsVlsJFtRQQnuMaOtMpZDuBPtONwwMWfmwQrIeymDsmjmtOSBiMcjHEdwSqDFpLSBBPbQgmpCiDrONTKUTqXEkZSOxFMxYXmxrFgJydhAL")) {
        for (int ZkMQghelkyS = 1687158560; ZkMQghelkyS > 0; ZkMQghelkyS--) {
            Fruzk += wDgOHegASrp;
            DzOgoVu -= OSevrgVbmEVVe;
        }
    }

    for (int ySBnTV = 1773185452; ySBnTV > 0; ySBnTV--) {
        Fruzk = Fruzk;
        wDgOHegASrp /= wDgOHegASrp;
    }

    for (int CLvXoKXutPZWLe = 1390195100; CLvXoKXutPZWLe > 0; CLvXoKXutPZWLe--) {
        wDgOHegASrp -= OSevrgVbmEVVe;
        DzOgoVu /= wDgOHegASrp;
    }

    for (int aEvji = 786361544; aEvji > 0; aEvji--) {
        Fruzk *= yAMfXLP;
        wDgOHegASrp *= Fruzk;
        LDNkKwRSY = TRgxmShY;
    }

    for (int tXSnxwMbD = 564702637; tXSnxwMbD > 0; tXSnxwMbD--) {
        Fruzk = OSevrgVbmEVVe;
    }

    for (int XEcSIvTPSV = 1432795069; XEcSIvTPSV > 0; XEcSIvTPSV--) {
        continue;
    }

    for (int nrZGpqnMGoKqejG = 81610586; nrZGpqnMGoKqejG > 0; nrZGpqnMGoKqejG--) {
        continue;
    }

    if (yAMfXLP <= -703158.6240022592) {
        for (int cejjPiLcbYORTGH = 1427808793; cejjPiLcbYORTGH > 0; cejjPiLcbYORTGH--) {
            BcIFRHwWdcHGiV = BcIFRHwWdcHGiV;
            OSevrgVbmEVVe += Fruzk;
            UzXIbmezXy = TFjNvksJ;
            DzOgoVu += yAMfXLP;
            Fruzk += OSevrgVbmEVVe;
        }
    }

    return UzXIbmezXy;
}

bool EiNWPeMd::IBrZVsdr(string QRWzwzOhc, int wLcmurqCOoxspaEy, int SgFiF, int rcVCfV, int DzVUIABE)
{
    double vroMBhji = 401307.71926597715;
    double jIzsaLxF = -545466.6315632307;
    bool bwzkTdgmdw = true;
    int ORLHkigdfEq = 1073979153;
    string FVQFBOdVMrTB = string("RXjbodQNOoJbXIqFFotrlTDnxKKxkrGjbgbVHDECvzsAzlvkrzPQtOAzKjLQUsqcQEgwTRFoSSbHmCXEiEhe");
    bool iqGOr = false;

    if (DzVUIABE <= 1400734858) {
        for (int JzUnDJL = 491082467; JzUnDJL > 0; JzUnDJL--) {
            continue;
        }
    }

    for (int qVWBp = 439550437; qVWBp > 0; qVWBp--) {
        ORLHkigdfEq -= ORLHkigdfEq;
        wLcmurqCOoxspaEy = DzVUIABE;
        rcVCfV -= ORLHkigdfEq;
        ORLHkigdfEq += wLcmurqCOoxspaEy;
        ORLHkigdfEq = ORLHkigdfEq;
    }

    return iqGOr;
}

bool EiNWPeMd::NxutWXqtqDPN()
{
    int tRUGzQY = -713675264;
    double vowHKCokvOW = 930659.7421097105;
    string qGffuOzbQaDmFHqB = string("bfZHmCOLgQPKEJOlsReVKCxhrVJmfqJiMvLxvbIpglgOUIvcysPLLdxhDnTbAbSuHeuMSyCxbJRQXdSOfiSQJgGyULqJwEbhEEOtDsxcZejTOqwXLiKoYMRhHbehNIzBfpcgUSRDlvxAQVzWvYDqTaQzVKlDZUwoeUuivbnTtkCrPQtognoDlplkAwPoBRUqGoLLqjYNVlneWYFtHTMxwcmOTAFwVuJxYvvNodtfH");
    int KNSWWSIL = 498407121;
    int ZaCzPbp = 1386502252;
    int fblfmtZGRdKzbEU = 608518498;
    double UPGHLOYqkgqC = -1006374.3932348059;

    return false;
}

void EiNWPeMd::jHKdLNBuiuz(bool LrYwUoHm)
{
    double owgWeBqqpyqBpWK = -706733.4624401473;
    int zjmLP = 2116290828;

    if (owgWeBqqpyqBpWK == -706733.4624401473) {
        for (int eKoOdsklGJgmxP = 826193121; eKoOdsklGJgmxP > 0; eKoOdsklGJgmxP--) {
            zjmLP = zjmLP;
        }
    }

    for (int ALxhBqlYtOp = 1102386798; ALxhBqlYtOp > 0; ALxhBqlYtOp--) {
        LrYwUoHm = LrYwUoHm;
        owgWeBqqpyqBpWK /= owgWeBqqpyqBpWK;
    }

    for (int uDGjNeRF = 1956219868; uDGjNeRF > 0; uDGjNeRF--) {
        zjmLP /= zjmLP;
        LrYwUoHm = LrYwUoHm;
        zjmLP -= zjmLP;
    }

    for (int KKJLtAfPhNmjdfn = 1989651137; KKJLtAfPhNmjdfn > 0; KKJLtAfPhNmjdfn--) {
        LrYwUoHm = LrYwUoHm;
        owgWeBqqpyqBpWK += owgWeBqqpyqBpWK;
    }

    if (owgWeBqqpyqBpWK <= -706733.4624401473) {
        for (int rMsnCCaMkNYKQZ = 1589296976; rMsnCCaMkNYKQZ > 0; rMsnCCaMkNYKQZ--) {
            continue;
        }
    }
}

bool EiNWPeMd::HavUTtkawVm(double oZxRkd, int IbxCeglw, int VcvQjyeWoXXEykTo, string XkIrTJCJorObt, string MKgHHTWmf)
{
    int sXlGZ = 1964619474;
    string UhdKGVQKLrqkqu = string("dwqbRfozeFPoGSzBrqCTLCbLrCUEmYlGnofvWffsTQxeBWWbDbZyALsAGJqJIKMipzFcxKASTtToQcnaxUjhqFzHXlVPNaYtwduVPBfVHbfYMCzYaZNjmomsIhkWkUPRIbjbRhHiy");
    double dpipLx = 518106.5409425027;
    string MQXCMuRrgn = string("TVagGushPbYxsQtjLbrPqQUdVDsMLiubFXATIavwCbepZkCybUOqsSPVRnluQabqNbTkZnkcViRIHAHrHs");
    string xzhVu = string("AUOELmnoMyjfTkghLFiZHfGfLsxOUAaXCNAUBnHKCFZFRDAlMjntsAVpFQJpNgOMuKslNRhySvcMqREiizYaBLdnKDHOGNskkWRJXTBYYLctvrlmSMAhKVUsgPJeZHjHUFZoctkUvZsZoJfHzHOjBTPuEcEtakQysrRPCxWfquYtbR");
    bool DAprwHLJg = false;
    bool ZKkDS = false;
    bool xWRLA = false;
    int UAPIoWcx = -547165248;
    double NySwxmjjTYlfA = 808471.8718178057;

    for (int OYOyuvHlix = 194564017; OYOyuvHlix > 0; OYOyuvHlix--) {
        sXlGZ /= UAPIoWcx;
        IbxCeglw /= IbxCeglw;
    }

    for (int embBXOxW = 613293574; embBXOxW > 0; embBXOxW--) {
        XkIrTJCJorObt = MKgHHTWmf;
        sXlGZ /= UAPIoWcx;
        oZxRkd = NySwxmjjTYlfA;
        VcvQjyeWoXXEykTo *= sXlGZ;
        sXlGZ = sXlGZ;
        XkIrTJCJorObt += UhdKGVQKLrqkqu;
    }

    if (sXlGZ <= -639385601) {
        for (int sATJKS = 1955537206; sATJKS > 0; sATJKS--) {
            continue;
        }
    }

    if (MQXCMuRrgn == string("dwqbRfozeFPoGSzBrqCTLCbLrCUEmYlGnofvWffsTQxeBWWbDbZyALsAGJqJIKMipzFcxKASTtToQcnaxUjhqFzHXlVPNaYtwduVPBfVHbfYMCzYaZNjmomsIhkWkUPRIbjbRhHiy")) {
        for (int XQKchfC = 1214135783; XQKchfC > 0; XQKchfC--) {
            continue;
        }
    }

    if (VcvQjyeWoXXEykTo <= -639385601) {
        for (int gjmiJhJewgdUM = 1859837936; gjmiJhJewgdUM > 0; gjmiJhJewgdUM--) {
            sXlGZ *= sXlGZ;
            UAPIoWcx /= IbxCeglw;
        }
    }

    for (int HDwkx = 1706365895; HDwkx > 0; HDwkx--) {
        MQXCMuRrgn = MQXCMuRrgn;
        IbxCeglw += IbxCeglw;
        oZxRkd += oZxRkd;
    }

    return xWRLA;
}

double EiNWPeMd::DxgdIZqokIHPA()
{
    double MEgWRGKA = -75487.48937181692;
    double SRYMokXyEuhfZK = 83832.71145764434;
    string WhhSLVYpUfnANSo = string("ZzaBWHsTNfjEhwqAxQIFoAdRgeSCkBeJZJcCXdhlfLBnTHGRyzPjOpWFjjGlUMOIojepSEIeBHPSqgdxVbDDcRLaGKfDtjjfuPpDeqfUcDXFnCxApdSWhVRzBkYkiAlTKBgYWCWEVOEICghRHmZFBOashSmJbqkPUPuepynVTBcONjwsHcxbBztq");
    double KikzvQEWfYYiM = 326746.42352840473;
    bool SLMHH = false;
    int jnhvZhmLZzkW = 1770372241;

    for (int fRCSxSfPGDjYj = 2058569730; fRCSxSfPGDjYj > 0; fRCSxSfPGDjYj--) {
        MEgWRGKA = MEgWRGKA;
        SRYMokXyEuhfZK -= SRYMokXyEuhfZK;
        SRYMokXyEuhfZK *= SRYMokXyEuhfZK;
        SRYMokXyEuhfZK /= KikzvQEWfYYiM;
        MEgWRGKA += KikzvQEWfYYiM;
    }

    for (int xbDxG = 1693384437; xbDxG > 0; xbDxG--) {
        MEgWRGKA *= KikzvQEWfYYiM;
        WhhSLVYpUfnANSo = WhhSLVYpUfnANSo;
    }

    for (int FDlOl = 1849154593; FDlOl > 0; FDlOl--) {
        continue;
    }

    for (int shmraTVZOKNcMokM = 1320636199; shmraTVZOKNcMokM > 0; shmraTVZOKNcMokM--) {
        SLMHH = SLMHH;
        SRYMokXyEuhfZK /= SRYMokXyEuhfZK;
        SLMHH = ! SLMHH;
    }

    for (int nhzkTZcYja = 1211715002; nhzkTZcYja > 0; nhzkTZcYja--) {
        continue;
    }

    for (int SOqssBDsep = 1426645467; SOqssBDsep > 0; SOqssBDsep--) {
        continue;
    }

    return KikzvQEWfYYiM;
}

EiNWPeMd::EiNWPeMd()
{
    this->TOMXOWxCabQQmJH(837546.4514787359, true);
    this->LbYkGlabDRT(string("GiRTknhjWwmTeJZxIpRTEeGvDDGbRdVwlkAUSzIAdBtfwlugbnINHPzsMNWRrMrkUmVQHMsACKfKGJcZhTDAfOolHzXGNm"), -728489.9363829371, string("NNAFfTBiVtzfJLpIyLnDMoZsdJkolqCKTCWGhSVPIhLgGbsJaKuKhrwXDYAUecDSYRoJRSLJaQOyKSbcJdYKNLdCpqietzXDd"));
    this->QQyKSqVko(-209330831, false);
    this->NAfIuPV(true, 431815.9613936918);
    this->RezgafVvvubNjE(string("cjNQaToJylDiAcWpyYiKIKONuacMLMYIkTORQeZxnpBTGvTnmkZKCoeGNfAEiqPvKNwxWSeySJqMeIsowWZXiQvK"), false);
    this->YxzneaOVwmTBkP(900362145, -444717.75339091296);
    this->pTVohAJK(string("YaEFMwlQpCwTTBnpprrUwVPQOocARQbOKkBxMsZSdXIYIarlhlYQhKZEmjwcibLHAuoRiOdbJlubuKqZOCsWcfwzpGYiUnMdYOjgGfAywxibIrWVNpuXVNpSAXCZEztkG"), string("TfrzOQPYjzISlfoaqKxOvcDdAXnKqxThaASQHMCHoFDeQEAQHzyWmfBKaHHNnaBMybNtaXtJqbmkHVxmXhGBAzrhHonbnxpoRWknCVXaplOCaQfPLDKynycLBeFEPlGPNBqrBPrZUFdZfvZjgkIblhsKNYbLlGZCaNUNNieCXxPcALrsocCkCqykwbgGSAprOexaJsvaByd"), false);
    this->avfQWwP(false, -249165521);
    this->irwCdGTIHisDlxP(true);
    this->KzfreZKUpnHWX();
    this->FjMPGghhBvodSIR(true, false, 842868569);
    this->mVTyq(true, -1057594977);
    this->ybpMXW(1819613143, true, 202976.05732869174, string("FjhAIyJIzMyFuOEiNNLwpzmMHncXMEB"), false);
    this->ASXwNWfdBfv();
    this->cLTnuDUzL(string("CqHhEHrUAtixbCRyVYXevrkavdpVdNRJfvujjyLrHAhNjajOwSjmzTLidHCfOqBmaTbcTjMZHgCZfrbtbBlOEkPGSsnDPRFpFTrScwQPFjJSgyeKcYCpYZzlnveKZzJIsUXEYXegdYVvOFzmJVLtxFtaMnZtGcRPvhuLIyRyJyTQVILBqvxVBvrvOqCvhUarFQeQR"), -546877.8202635879, string("mTbESWaeovZELTnjoSXAIWhxhsdUmBpYopAETxmMAZSXcZlVxEdYWloSqilLByNgOiWDPcLsVpDbUedlYBzAmsvGWArwlRgfCghwsSwkrgnAxsvBPujwlJgQvVawamLev"));
    this->UFzedhqVwsf();
    this->xPuCYAACBLYwfEz(-907803605, 815049.9363526482, true, false);
    this->IBrZVsdr(string("VVaxbhjUSxG"), 1571795840, 1400734858, 1620415136, 739667708);
    this->NxutWXqtqDPN();
    this->jHKdLNBuiuz(true);
    this->HavUTtkawVm(-721689.1359247669, -639385601, -1319766371, string("VKhiRSRbnykXIdbDOqOKHTWeYrSjlqlyhnDNQQlbdQTWMvqvELhSyUTdFaGutbDSCXeoGhBTchuBKcKRlEWfOyXezcizKtiqWpvIqqGVgrsAHkgMWAhmxCXFgLEEzPBMwzvhwoqVaUjEf"), string("TxxlPgKNbsheUOd"));
    this->DxgdIZqokIHPA();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WlGDWcifrYjUilF
{
public:
    bool OEvknASccwPftpjv;

    WlGDWcifrYjUilF();
    bool EiesvY(string AWltruHnpYP, string HGUWefFLhKlfv, string qmMGgZOIZJQh, string YDtljVPkgPeUpFne);
    void ToAxDS(string YxbJISik, int rpCLHGKQiT, string CaVwnzKury, double CXmcchdZclT, string GefhmfefdZ);
    int jBBRvFbIlGwKDZ(int upesNaon, int VBpNay, string ZpVAWksWZNFchXij, string qJhBlxEdneJecv);
    int WmJyWhQAnd(string NvQpzuvnlHqGl);
    int PqaImv(int jvCorofqYBNaozt, double ypoCcLjQHXYd, double lzSORMeQGG, double WngMMHcZQNe, bool kNDnPpZtKdrDtdPr);
    string feTZmUjUhP(string ulnMyV, bool pyvuTnRZENBLkTg, double jTFyUdTQsenr);
    bool gFMol(bool CYpDW, bool GoDBpAbyBrb, string WbynGqvUxsQNvW, bool wxctasgXSbFvXm);
protected:
    string fcDxNUsyvM;
    int XLHfx;
    int GoUehGtxHmDGptN;

private:
    string ogkFtDUNDegiPUxu;
    bool pXDQCmP;
    double TdXKukR;
    string JUqSZTkyFM;

    void OQOFEdHGXaan();
    int EdyEhBABeTAqr(int jqHJniVR, int mfjnxxHINjKgqSuz, int dsKAeSxbzubBYXzE, int iEPEywAElzjbZ, double bvcMbYyQzE);
    int AYCWo(int rMWBbOeWyClWiT, double SuMOcPLa);
    bool ZEMZVglyoppqdKJU(int KnNsgo, bool vOKsYsZKVjtrkI, string gVRHO, bool pkoUGrtlN);
    double kTXhiavbZqMOzKn();
    string ZvISeTjSoA(string dCelzEcoRgPDF, bool gtfGpmCCtRDgSuM, bool nasOylwoGQHqKrC, string Lxzygt, double uJafCINbU);
    string upKyfJKD(double DNvTBo);
};

bool WlGDWcifrYjUilF::EiesvY(string AWltruHnpYP, string HGUWefFLhKlfv, string qmMGgZOIZJQh, string YDtljVPkgPeUpFne)
{
    string fTauo = string("LjgCSZWAoBtzSwqnbXhHzADFRwCdjTzWYnxvGGVRHPhAcnNOzBylWebSRbMfrfVaUPsPXdDNecaZyFpOmvMiKLmjQftFjNtzNqALebkhjNqwCBWclBaRRfYBrgIzHvzXWIESyMLluFzNOMSqWRAZOYAvXHdDEKDqMjbXuIUmWsVLQOQOYXZPWtRTav");
    int CpvPuZvg = 87363006;
    string YflSLPlCq = string("nsfqyoufBRcdiOxHZiTIkeJMwuFyyjfequZaFCcwBKHzvJGTYHfVTWHXqQYiETGHJJsTALAWMWwJZyukiHGELBxQfHEoYJouFHIhDxNGzWzcLQLVrMbpaYjSDDYAaikrsDxOgSpHrMekzQxgEZhnaRTlPGObNeH");

    for (int IRQFZN = 333054079; IRQFZN > 0; IRQFZN--) {
        fTauo = HGUWefFLhKlfv;
        fTauo = fTauo;
        fTauo += YDtljVPkgPeUpFne;
        HGUWefFLhKlfv += AWltruHnpYP;
        fTauo += YflSLPlCq;
        fTauo += fTauo;
        YflSLPlCq += YDtljVPkgPeUpFne;
        fTauo += AWltruHnpYP;
        fTauo = qmMGgZOIZJQh;
    }

    if (qmMGgZOIZJQh != string("SbYfGLipwEbslNYrrkukpKVGrGGfrUKcbFNwHHtFjNMdamhEWieWJpEKTkOxIBLMaOEyWlKcZUtaSiIOaZhrGlQg")) {
        for (int oCFXU = 2074938636; oCFXU > 0; oCFXU--) {
            YDtljVPkgPeUpFne += YDtljVPkgPeUpFne;
            fTauo = HGUWefFLhKlfv;
            YDtljVPkgPeUpFne += YflSLPlCq;
            qmMGgZOIZJQh = HGUWefFLhKlfv;
        }
    }

    for (int wNJqeejfjjE = 196563974; wNJqeejfjjE > 0; wNJqeejfjjE--) {
        CpvPuZvg /= CpvPuZvg;
        YflSLPlCq = fTauo;
        fTauo += HGUWefFLhKlfv;
        qmMGgZOIZJQh = fTauo;
        YflSLPlCq += YflSLPlCq;
        HGUWefFLhKlfv = YDtljVPkgPeUpFne;
    }

    return true;
}

void WlGDWcifrYjUilF::ToAxDS(string YxbJISik, int rpCLHGKQiT, string CaVwnzKury, double CXmcchdZclT, string GefhmfefdZ)
{
    int OTZaGDIjUFGGO = -1828958196;
    double pNRAQlzovvYPDAmz = 69033.28425788184;
    string fDVRDO = string("EJRKPnSDwLfyeCHfNiaZndumahYYQBsKMOPTPodVEWLQalOYGfowAqPAatNkZzuamDMZJLKZvuLJQRRFEDvyOFohAmzPUmvwyBhcYtpNUbznVMAgWideJjlctDIfYbqUUdwgof");

    for (int iFXuWYALtXKBmlw = 702902213; iFXuWYALtXKBmlw > 0; iFXuWYALtXKBmlw--) {
        fDVRDO += GefhmfefdZ;
        YxbJISik = fDVRDO;
        CaVwnzKury += fDVRDO;
    }

    if (pNRAQlzovvYPDAmz != 69033.28425788184) {
        for (int gpjEsKXmoZs = 1210960999; gpjEsKXmoZs > 0; gpjEsKXmoZs--) {
            fDVRDO = CaVwnzKury;
            fDVRDO += CaVwnzKury;
            CXmcchdZclT -= pNRAQlzovvYPDAmz;
            CXmcchdZclT /= CXmcchdZclT;
        }
    }

    for (int UYEhWm = 1402947313; UYEhWm > 0; UYEhWm--) {
        OTZaGDIjUFGGO *= OTZaGDIjUFGGO;
    }

    if (fDVRDO != string("ARQBtyhqXfiejWBbRTkSltzLZUIYTXVaebzyBTlCUthbTUQEkIIsfOaUeaPtcWOlESOmtgwRUTKZZsSCGKaaxxpyIhtkEeBfgFifOcSVtoFnIGHbBkWXBSKAYTEbCFphvmtRLhfXfmaDucOQuNuHyMjPtEQiUxoxFBVjcJGuWiAqSlUWQrNbkbDdDUlfkoqTlAdCULOSTTFnh")) {
        for (int kEmlhpeVMtA = 1830001839; kEmlhpeVMtA > 0; kEmlhpeVMtA--) {
            fDVRDO += CaVwnzKury;
            GefhmfefdZ = YxbJISik;
        }
    }

    if (fDVRDO < string("GewRkKzLCgHqCUNqLkHEobHfmYAcThEQVTFrbrElrYXMFbnNtzOrBsMhbGgKnrILWGpPaZBDqKLDcfGmFyjlgfUAMQVgfxBqnTgQBZYOYhdSBNxxEvshlVTXkNvutHnQuhOjJcdujkqByKPuvHZTzMGKWIHiNWEPLNnYcjqqc")) {
        for (int slFGggcM = 181945797; slFGggcM > 0; slFGggcM--) {
            CaVwnzKury = CaVwnzKury;
            YxbJISik = fDVRDO;
        }
    }
}

int WlGDWcifrYjUilF::jBBRvFbIlGwKDZ(int upesNaon, int VBpNay, string ZpVAWksWZNFchXij, string qJhBlxEdneJecv)
{
    double btpApltnGG = 529619.3904533429;
    double oqxwCBdTRMdQznZ = 1041543.2562605406;
    bool ygRbrbZTkx = false;
    double SqMnHOvZcLAk = 119502.44117684502;

    for (int nugUXrW = 1668405937; nugUXrW > 0; nugUXrW--) {
        oqxwCBdTRMdQznZ += SqMnHOvZcLAk;
    }

    for (int CroZJsCuiXQiS = 1980801166; CroZJsCuiXQiS > 0; CroZJsCuiXQiS--) {
        continue;
    }

    return VBpNay;
}

int WlGDWcifrYjUilF::WmJyWhQAnd(string NvQpzuvnlHqGl)
{
    double MYMUxTSSfQUbbXrb = 322608.04949609895;
    double eFoqHcqSsyphJPl = 1032662.4906846713;
    string KUWxHzIwWkZGoPgG = string("kNEDNWaJGoewYjTXUiEnqaKindswMxWApXlHq");
    string beRHfhKxFRoAw = string("PVdAWZyPwxoMxyUIuYSmfmwfmnSwDytpijDnzxjixkbZVEecyPWiuaOJWwHLcIfKBjMzDG");
    bool AJhnzOgeBEYi = true;

    for (int aXYacFhx = 1884140258; aXYacFhx > 0; aXYacFhx--) {
        NvQpzuvnlHqGl += NvQpzuvnlHqGl;
        beRHfhKxFRoAw += NvQpzuvnlHqGl;
    }

    return -423440740;
}

int WlGDWcifrYjUilF::PqaImv(int jvCorofqYBNaozt, double ypoCcLjQHXYd, double lzSORMeQGG, double WngMMHcZQNe, bool kNDnPpZtKdrDtdPr)
{
    int JCKagptrnrtmxi = 793983898;
    double AjpgNhJf = -180267.97176228403;
    string keFumc = string("ideIfRauufGYnmVDgwxNPTclwTqNzVXbvHgvfUvVpOJCAnplXKDyKOmNOTHupnPbMfXuFSWeNJ");
    string pUoUvbLiwXNScK = string("IJxAhMKeNmGmqmiREhStIIriNhjNtTSVZnEaRgidFQbWNDjAhaoCbNHfjAkIrOwJGWYxCfxKVGLGtgsWVOjrmlrqyombROEZeiAxaTbIDbmnzNMHNysUzoUPKahIZEVTHALPlfwxJHsRCfQmmmOPfNXOtnkbTwwxrccxuWTSXF");
    string BdAzPptiMVmqk = string("VwBXMcRAolLoHyYHctqpVtLHUCEBJTHKGqIoAZJnhOGgMelkZrOtFdPWZgIAfGycVWdyKjJEfBvXQPDskPObHv");
    double kZTKbY = 656473.5840110236;
    double MqbOnkLgkscA = -986370.1612965224;

    for (int GkqzwAplVB = 888273599; GkqzwAplVB > 0; GkqzwAplVB--) {
        BdAzPptiMVmqk += BdAzPptiMVmqk;
        pUoUvbLiwXNScK = pUoUvbLiwXNScK;
    }

    if (JCKagptrnrtmxi <= 793983898) {
        for (int kzIqKKqz = 722125956; kzIqKKqz > 0; kzIqKKqz--) {
            WngMMHcZQNe *= lzSORMeQGG;
            lzSORMeQGG = kZTKbY;
        }
    }

    return JCKagptrnrtmxi;
}

string WlGDWcifrYjUilF::feTZmUjUhP(string ulnMyV, bool pyvuTnRZENBLkTg, double jTFyUdTQsenr)
{
    string JBgAh = string("VHHYxFBBEFzvAjPUAJrRUZqnyZVtsVFAofWqcapWbDBeINDenVNHScbGszfsrkQlYrVIIntSULolCbjBjtPuWCbjfhsPWmVIpsBzbOuVFnOPNdAcXaAExFifZCAeSICuNBUEzNrzZdPbyjUZXRmSiTntPCGcSmJAnktBhZczoCTOXUk");
    bool oxzwITQnoaFAQA = true;
    string MrGTrltJhon = string("yirLiiswTmIujZtmOnACIQLWeEgjPpzTVkQYPThEWNWmLAosvqPHNeyqmsnkoOsKQXMuOwgRRWiRpwBlgmsdisJTswHAHeDxgPglKgyPqGMynrVoiVVhIgWAMMwqyUYmDYdPsnKRSeCZPHiHRDpOJFOACnTiwiXxdgEjqRRkrtsfdeuFXRJpXhCjiuiQqVkzQftMzhsSwDZfyQuKDcdRUxqWCWbjKWceAb");
    int AsYGJv = 1894748519;
    bool qvHywPaAg = false;

    for (int BJllfyHnwZA = 363977851; BJllfyHnwZA > 0; BJllfyHnwZA--) {
        continue;
    }

    for (int ZXvPKCBgnQHPJ = 1075811881; ZXvPKCBgnQHPJ > 0; ZXvPKCBgnQHPJ--) {
        ulnMyV = ulnMyV;
        MrGTrltJhon = MrGTrltJhon;
        pyvuTnRZENBLkTg = pyvuTnRZENBLkTg;
        qvHywPaAg = ! oxzwITQnoaFAQA;
        oxzwITQnoaFAQA = oxzwITQnoaFAQA;
    }

    for (int PrldCs = 172922812; PrldCs > 0; PrldCs--) {
        qvHywPaAg = pyvuTnRZENBLkTg;
        qvHywPaAg = qvHywPaAg;
    }

    if (ulnMyV >= string("yirLiiswTmIujZtmOnACIQLWeEgjPpzTVkQYPThEWNWmLAosvqPHNeyqmsnkoOsKQXMuOwgRRWiRpwBlgmsdisJTswHAHeDxgPglKgyPqGMynrVoiVVhIgWAMMwqyUYmDYdPsnKRSeCZPHiHRDpOJFOACnTiwiXxdgEjqRRkrtsfdeuFXRJpXhCjiuiQqVkzQftMzhsSwDZfyQuKDcdRUxqWCWbjKWceAb")) {
        for (int lOuHJDG = 964341405; lOuHJDG > 0; lOuHJDG--) {
            ulnMyV += MrGTrltJhon;
            ulnMyV += MrGTrltJhon;
        }
    }

    return MrGTrltJhon;
}

bool WlGDWcifrYjUilF::gFMol(bool CYpDW, bool GoDBpAbyBrb, string WbynGqvUxsQNvW, bool wxctasgXSbFvXm)
{
    string FqqqGlePNP = string("HCkpQJBbwYUkZLBXKHJNSjFhiUhoMIiiyrxrPOyuFPezdDMyAMMyzBySBGqJufuIyeQMgFvdcPhORIhDYjysZHmLoFcpkDRxLeyw");
    double qqKbalQvzfS = 737971.6017172394;
    string SUAvIXqwDYUkIG = string("RCBTrbQqwmYAdrEzvaJEojPZTDjUmHIQCwfIfJGSsVPr");
    bool ZjLYfCVdNgl = false;
    int UMYcThxbvo = 1638740692;
    bool vsQtKtFJn = true;
    double bpxlQwxfr = 635576.6562513569;
    double PkzYXpeVNVMbwuRz = -45245.351691529046;

    for (int qOXIwdNLirO = 1859572217; qOXIwdNLirO > 0; qOXIwdNLirO--) {
        continue;
    }

    for (int iyLhnwuVjNiyMAWP = 720034718; iyLhnwuVjNiyMAWP > 0; iyLhnwuVjNiyMAWP--) {
        SUAvIXqwDYUkIG = SUAvIXqwDYUkIG;
        PkzYXpeVNVMbwuRz *= qqKbalQvzfS;
        vsQtKtFJn = ZjLYfCVdNgl;
        FqqqGlePNP = FqqqGlePNP;
        FqqqGlePNP += SUAvIXqwDYUkIG;
    }

    for (int jTlsXgczeJGjy = 1185032374; jTlsXgczeJGjy > 0; jTlsXgczeJGjy--) {
        bpxlQwxfr -= qqKbalQvzfS;
    }

    for (int LrxidJUXZp = 1564413080; LrxidJUXZp > 0; LrxidJUXZp--) {
        continue;
    }

    if (SUAvIXqwDYUkIG >= string("HCkpQJBbwYUkZLBXKHJNSjFhiUhoMIiiyrxrPOyuFPezdDMyAMMyzBySBGqJufuIyeQMgFvdcPhORIhDYjysZHmLoFcpkDRxLeyw")) {
        for (int nCftPJaMPEA = 3086599; nCftPJaMPEA > 0; nCftPJaMPEA--) {
            continue;
        }
    }

    return vsQtKtFJn;
}

void WlGDWcifrYjUilF::OQOFEdHGXaan()
{
    double uCQTLwm = 328221.99776691187;
    string GGFsGLK = string("jSqMGJFpeKLVNrfdijuWiWGSiJllYqBQMiqBbsaKYWqqwHXCtjuyaEgeWbMSvSKWPUCQVaAikSdQyHdrATiQdUZvHRBZwRRapGHRiklFMsjBhaBGlsAqxdGGIcvVquqrzrkRtYjQfaNkhCsfdUkNyIGuayxyrBdMtyrfarGbvWSWLMNxApyQnxDWzEqCxvkkxPfDfKFhcDziebscpGLZQzmrjntclifypUreugNIliNck");
    double LSBHmC = 169302.55604188002;
    string lzffuRDGlPPAicuv = string("ghAzURXaEBtvDkrtNJao");
    int egXEE = 1975580830;
    double bSiEYojGal = 378453.146373738;
    string taihVUpRVYmmhRQ = string("TSxlpyVnwAbGtYOPCOutKiaeJgrmBmVxEBHdtTforcnZvmcPEx");

    if (GGFsGLK >= string("jSqMGJFpeKLVNrfdijuWiWGSiJllYqBQMiqBbsaKYWqqwHXCtjuyaEgeWbMSvSKWPUCQVaAikSdQyHdrATiQdUZvHRBZwRRapGHRiklFMsjBhaBGlsAqxdGGIcvVquqrzrkRtYjQfaNkhCsfdUkNyIGuayxyrBdMtyrfarGbvWSWLMNxApyQnxDWzEqCxvkkxPfDfKFhcDziebscpGLZQzmrjntclifypUreugNIliNck")) {
        for (int EDwbhodEDL = 1607425801; EDwbhodEDL > 0; EDwbhodEDL--) {
            GGFsGLK = GGFsGLK;
        }
    }
}

int WlGDWcifrYjUilF::EdyEhBABeTAqr(int jqHJniVR, int mfjnxxHINjKgqSuz, int dsKAeSxbzubBYXzE, int iEPEywAElzjbZ, double bvcMbYyQzE)
{
    double GYrYshzCZTE = 383384.49873142963;
    string jkyGJkFQhQhJl = string("XkQJkkTJjusvlRqlLCCJqgqlQSQHcmQoOHrbcwpRmfmUtKNy");
    string cRSlZu = string("uLPpuUuhqzQqqBynlCLVuWrUVMPWwlPmsseGBszfrEnWgRCNObxGxTfCNAJThYLEPtxFCYFpgDtHCnsoSpgxQnYlIRPmdYSKjIMafQqSZIfFiThxOzuXJGlkBDVlZeajLLxv");
    string vCsik = string("KmzVcsjJvcXWSbBqzvVeCEiGoWudpVSfpZmwKJhqqkBXrPuYsSaKBYQEbOSLWbJCgmOrXdXCuFfvgRSYjeIrMkeBkvjrQtQxZUQrsbyJPXrroOjFTcgxaEgROdwJqnCiBENDseCKYSxeJkMtHIrbCPSJlvsIafIQyFLELqEwKVsxTltEmgeCmohPWzeqWGLEgCmUeneDefllfckkNLyXMjdpvxQbnxBQDcAAlPzTJtySqpYqMG");

    if (jqHJniVR == 2136302743) {
        for (int klmDRmNh = 1135868034; klmDRmNh > 0; klmDRmNh--) {
            jqHJniVR -= iEPEywAElzjbZ;
            bvcMbYyQzE -= GYrYshzCZTE;
            cRSlZu += vCsik;
        }
    }

    for (int dgfCKyMijPVO = 1043700252; dgfCKyMijPVO > 0; dgfCKyMijPVO--) {
        jqHJniVR -= jqHJniVR;
        dsKAeSxbzubBYXzE = iEPEywAElzjbZ;
    }

    if (jkyGJkFQhQhJl > string("KmzVcsjJvcXWSbBqzvVeCEiGoWudpVSfpZmwKJhqqkBXrPuYsSaKBYQEbOSLWbJCgmOrXdXCuFfvgRSYjeIrMkeBkvjrQtQxZUQrsbyJPXrroOjFTcgxaEgROdwJqnCiBENDseCKYSxeJkMtHIrbCPSJlvsIafIQyFLELqEwKVsxTltEmgeCmohPWzeqWGLEgCmUeneDefllfckkNLyXMjdpvxQbnxBQDcAAlPzTJtySqpYqMG")) {
        for (int DiDhSvtKYLE = 629456109; DiDhSvtKYLE > 0; DiDhSvtKYLE--) {
            bvcMbYyQzE += bvcMbYyQzE;
            vCsik = vCsik;
            dsKAeSxbzubBYXzE += jqHJniVR;
        }
    }

    for (int AraYbIgvbBH = 2125395865; AraYbIgvbBH > 0; AraYbIgvbBH--) {
        iEPEywAElzjbZ = dsKAeSxbzubBYXzE;
        bvcMbYyQzE = bvcMbYyQzE;
    }

    return iEPEywAElzjbZ;
}

int WlGDWcifrYjUilF::AYCWo(int rMWBbOeWyClWiT, double SuMOcPLa)
{
    string edRwk = string("KIqQttkduywQKWtujsgAMgyXFDsPZlSiWzazbTibIUIJAhguakxRKaqcwYlBAXkDVLimCoNBYtCCqknkQEFiaUmCgxUcWFJomhhRWbKILfn");
    string VkPeNpmwCjVNgG = string("sxtpAtQRQupDePIQPJcgiorzTYJhjTpEFkrDSsCkmapbGEUkyQPwFXhBlMLXnPQURzHahXvFRBCWdHdYwqJOlQIMtkcfFeSGlzfaS");
    int yiEGyP = -1217717693;
    string OrvVqbnSCDoIk = string("tZkXazNojeBhRlojUkljOjTfvtCRxvXYdzQOuArGYYWM");
    string XNRvqBNpbI = string("LLXzalUNEIcLQMqMnbIhKPAMwDJWZUUVtntumTeIrsJeLnSMstocsNxrYFdRssDtEHruItfTFFcrDXnjJYULIjwlfuCjvzypmEwWlkTpFLEItBERzfWvGNqcbZOFwWQKzgFnKnDXyqiXfaWUszRaDEIHWCrvCvVkwKrAcHhuxkPBFTMtySQrnEIgyNZObbEvIEJY");
    int unpSBESIfJy = -1008440038;
    bool mqNBuHqEUw = true;
    double PSDzqasZb = -334889.1327520892;

    for (int lddjj = 1212030692; lddjj > 0; lddjj--) {
        rMWBbOeWyClWiT -= yiEGyP;
        yiEGyP += unpSBESIfJy;
    }

    return unpSBESIfJy;
}

bool WlGDWcifrYjUilF::ZEMZVglyoppqdKJU(int KnNsgo, bool vOKsYsZKVjtrkI, string gVRHO, bool pkoUGrtlN)
{
    string JZGEwl = string("KsjAJSUURniJXQgPDExzZMpmwdgJJjcFScrIVlrCXiIiCduqpnstjVyRMotOyEuGmxFLNzIVhvyAWKWeabuSUfrVXnhbOCbpkrZxeWRC");
    bool vHxjaNpVkRkPLzp = false;

    if (KnNsgo >= 372569382) {
        for (int xTAtTgI = 1322485520; xTAtTgI > 0; xTAtTgI--) {
            vOKsYsZKVjtrkI = vHxjaNpVkRkPLzp;
            vHxjaNpVkRkPLzp = ! vOKsYsZKVjtrkI;
            gVRHO += JZGEwl;
        }
    }

    for (int UTCHxWtmDBufbKc = 567966402; UTCHxWtmDBufbKc > 0; UTCHxWtmDBufbKc--) {
        vOKsYsZKVjtrkI = vHxjaNpVkRkPLzp;
    }

    if (vHxjaNpVkRkPLzp != false) {
        for (int lvPgLK = 877157617; lvPgLK > 0; lvPgLK--) {
            pkoUGrtlN = ! pkoUGrtlN;
            pkoUGrtlN = ! vOKsYsZKVjtrkI;
            vOKsYsZKVjtrkI = vOKsYsZKVjtrkI;
        }
    }

    if (gVRHO <= string("KsjAJSUURniJXQgPDExzZMpmwdgJJjcFScrIVlrCXiIiCduqpnstjVyRMotOyEuGmxFLNzIVhvyAWKWeabuSUfrVXnhbOCbpkrZxeWRC")) {
        for (int diJSzDsbYUdv = 990525611; diJSzDsbYUdv > 0; diJSzDsbYUdv--) {
            JZGEwl += JZGEwl;
        }
    }

    if (pkoUGrtlN == false) {
        for (int APCYzrxlinGGbq = 98715666; APCYzrxlinGGbq > 0; APCYzrxlinGGbq--) {
            pkoUGrtlN = ! pkoUGrtlN;
        }
    }

    return vHxjaNpVkRkPLzp;
}

double WlGDWcifrYjUilF::kTXhiavbZqMOzKn()
{
    string zHLgVMHeoKg = string("guEuYkDcwCWqdHtASjmVCoIfVoAUCXkZwFYinDatVEISsMIBXyEKCjRamWeJHRklERnOInopZttpybMKSrndiYZErKFaRtSHo");
    bool GFmbyRoHHnJjs = true;

    if (zHLgVMHeoKg < string("guEuYkDcwCWqdHtASjmVCoIfVoAUCXkZwFYinDatVEISsMIBXyEKCjRamWeJHRklERnOInopZttpybMKSrndiYZErKFaRtSHo")) {
        for (int VYBCzv = 935669557; VYBCzv > 0; VYBCzv--) {
            zHLgVMHeoKg = zHLgVMHeoKg;
            zHLgVMHeoKg += zHLgVMHeoKg;
            GFmbyRoHHnJjs = ! GFmbyRoHHnJjs;
            zHLgVMHeoKg = zHLgVMHeoKg;
            GFmbyRoHHnJjs = ! GFmbyRoHHnJjs;
        }
    }

    if (zHLgVMHeoKg < string("guEuYkDcwCWqdHtASjmVCoIfVoAUCXkZwFYinDatVEISsMIBXyEKCjRamWeJHRklERnOInopZttpybMKSrndiYZErKFaRtSHo")) {
        for (int ZfXcCvOPCqpOt = 1760284422; ZfXcCvOPCqpOt > 0; ZfXcCvOPCqpOt--) {
            zHLgVMHeoKg += zHLgVMHeoKg;
            GFmbyRoHHnJjs = GFmbyRoHHnJjs;
        }
    }

    if (GFmbyRoHHnJjs != true) {
        for (int HVNNxHArzP = 1527951766; HVNNxHArzP > 0; HVNNxHArzP--) {
            zHLgVMHeoKg += zHLgVMHeoKg;
            GFmbyRoHHnJjs = GFmbyRoHHnJjs;
            GFmbyRoHHnJjs = GFmbyRoHHnJjs;
        }
    }

    if (zHLgVMHeoKg < string("guEuYkDcwCWqdHtASjmVCoIfVoAUCXkZwFYinDatVEISsMIBXyEKCjRamWeJHRklERnOInopZttpybMKSrndiYZErKFaRtSHo")) {
        for (int sGdhjzMJEDgrh = 1214721799; sGdhjzMJEDgrh > 0; sGdhjzMJEDgrh--) {
            zHLgVMHeoKg += zHLgVMHeoKg;
            GFmbyRoHHnJjs = GFmbyRoHHnJjs;
        }
    }

    for (int DVNHFnl = 1071394375; DVNHFnl > 0; DVNHFnl--) {
        GFmbyRoHHnJjs = GFmbyRoHHnJjs;
        GFmbyRoHHnJjs = ! GFmbyRoHHnJjs;
        zHLgVMHeoKg += zHLgVMHeoKg;
        zHLgVMHeoKg = zHLgVMHeoKg;
    }

    return -694858.6981809142;
}

string WlGDWcifrYjUilF::ZvISeTjSoA(string dCelzEcoRgPDF, bool gtfGpmCCtRDgSuM, bool nasOylwoGQHqKrC, string Lxzygt, double uJafCINbU)
{
    string gWZgBRdzv = string("cwqtqoKWrXKIghBwvzWuvDqKHADkXWmBJwExCxbfnUmnkHgXaABOsFwmaNQOVNBrScIpuTSYmzcOGBNJRoqHiGFGTKjmxPaxaGxFdKppoTrIpVGQeoibZJFLNCkZOiMWoTOhtQYTHHGkQQwttXEGiOIsirA");
    bool jiEyGC = false;
    double SdWmX = 431050.4765261503;
    bool MxlbbyZVSQO = true;
    bool WsovcVmJfy = true;
    string odtlI = string("wzoITABpigSJXECchRHBSfIvoAyqCYaQjSWQCdBKQYqrzYmgGjjrtdbFyrnTSGvLfEwHWrCtQwxPxULEFjxAkqktraOvbgQydURgvjpzahpfhszR");
    bool cxQFfbjDOg = false;
    string tHrPyUZONDk = string("lAlQUiWkcQVtxeAjnaexyFZhxuhriPqsDdkAzdbxmZYsSnVDOvZwikZzsMYrxyGjfSGqjCLIfaxyowCOzzAIFtJzYdVKxoiIGKLolJmyepQWMoIEeKdcQKsgDnyKrSoCEWzwxVLTBylQlVBcUSikJFqwYzFXWDHflakgAuPWjAHBpwyTKJTpNDUtBpOTAtsDlZaMlpGBVZdyrHVqLTKpFfWvipudLMirpJKazXahvmWYzSWIGQVZjWAAflPSVv");
    bool BPJtPrTdVIvbm = true;
    string esurEc = string("NsjYUbgGVzPlUYwUqyFHztorWXNEOWLIccLeuQkykyDBOfytnPgFoxPGmFoRBDEioVWdHIqqZOMIMYqbAeSuuIYrGdeLYrCNrsLSaxywlDFmqvWHEWCXIExsedCXnndGLTe");

    return esurEc;
}

string WlGDWcifrYjUilF::upKyfJKD(double DNvTBo)
{
    string JJuvaZFDJCICvd = string("UUDVCaLrbKoknfFbNuCrxnybrIRietkyGXuDqEGXbDrJXVdSdWevjikGVSOLfEcAfnUOXqIzcwDgcfKFkzaR");
    bool lIaAcbB = true;
    string azNjFGoaQGgR = string("CcSUaMXWJEXnLtrTPpSgaaIzdJjxpZwjNuaKvtDITtkczqiwdtthHETamVLXTOxfhABHqBmGmxruZfuEtMzHoCmSMWcGBXqP");
    int DyYPzogGQhhyk = -1371445072;
    string ErCIeGB = string("OoOAtPBTjTlsCPlxqEcYuuOIwhcQOhmIABePAIsEmBgucgHfRaAPIRiPNgXqnvcSYXazrDJXXXtYCbIUKHmcEiqonANyLnPMmEMUjmpeeFOYuwHSvmfNInxnQMWKcCyNmAVleOwnARt");
    double OsgxmqN = -421496.110612942;

    if (azNjFGoaQGgR > string("UUDVCaLrbKoknfFbNuCrxnybrIRietkyGXuDqEGXbDrJXVdSdWevjikGVSOLfEcAfnUOXqIzcwDgcfKFkzaR")) {
        for (int DKgBQx = 1092882423; DKgBQx > 0; DKgBQx--) {
            DNvTBo *= DNvTBo;
        }
    }

    for (int lgOCMECgFtlxwBox = 688801326; lgOCMECgFtlxwBox > 0; lgOCMECgFtlxwBox--) {
        azNjFGoaQGgR = JJuvaZFDJCICvd;
        azNjFGoaQGgR = JJuvaZFDJCICvd;
    }

    return ErCIeGB;
}

WlGDWcifrYjUilF::WlGDWcifrYjUilF()
{
    this->EiesvY(string("LDqepTJjKfAlbFGgSrtzPGPaqQWEchhbmOZYdUgOwamdWbWezVeTJXrDixmvTlPnjflsBJztzoBvOFJDbviG"), string("rcfrhYcyWPUUdwMiYPgiiAkjciKBIghUNmirzbPCzKfFcuZIlVuMcYQOFLCeTAWdYPszhKPUcbYXonDnFYmXswQtDhZJDhWLpgyWndpkTaRAanfVbSzEHnyZAjBqUfEOIzqIqxvBBsNGegehbdUWTroivfIprPA"), string("SbYfGLipwEbslNYrrkukpKVGrGGfrUKcbFNwHHtFjNMdamhEWieWJpEKTkOxIBLMaOEyWlKcZUtaSiIOaZhrGlQg"), string("hy"));
    this->ToAxDS(string("GewRkKzLCgHqCUNqLkHEobHfmYAcThEQVTFrbrElrYXMFbnNtzOrBsMhbGgKnrILWGpPaZBDqKLDcfGmFyjlgfUAMQVgfxBqnTgQBZYOYhdSBNxxEvshlVTXkNvutHnQuhOjJcdujkqByKPuvHZTzMGKWIHiNWEPLNnYcjqqc"), 1607141155, string("ARQBtyhqXfiejWBbRTkSltzLZUIYTXVaebzyBTlCUthbTUQEkIIsfOaUeaPtcWOlESOmtgwRUTKZZsSCGKaaxxpyIhtkEeBfgFifOcSVtoFnIGHbBkWXBSKAYTEbCFphvmtRLhfXfmaDucOQuNuHyMjPtEQiUxoxFBVjcJGuWiAqSlUWQrNbkbDdDUlfkoqTlAdCULOSTTFnh"), -431400.6713758577, string("apRtHBvpexOYpTnNkWUXfwAuhOEUEOWTbN"));
    this->jBBRvFbIlGwKDZ(1062155134, -817142478, string("xuHdowuMWQxJgOFTtQekjTMvJDHYOlSwrfqqZYNbJWYVRWgmARFCXcn"), string("QVcdoCwsuaVmmnAxwWvbwSiRaihXbLrpyDfHgQZuOviAqGGdmYlUwFUKZspREMLzwWPqdYLDVPgYpWwrSONaMHKCJtKyylXQpAlxcjvTYFIICcygfiGIlDYrTmojmkuEAfhhLEAUxvSFylBVrJcrciEeIkSZhLzQzNiIPXdVlfHmWabVvomxGrcCxQddwImTDhIhAYcy"));
    this->WmJyWhQAnd(string("meKAAITbiPDMrQAlRJpFDUWSjWJCQZmeRVolJkajhZSshUXtDvIfNesVznrHrJufcMUdfNRtKilNBuEcqsNmTbYljmepOZROynSHYrGjtQXwDxujmRefMqIlIPscKAvxYlCiGNLvBfisfENSomWfEFEYUfXADyVdtjfiSEoZzzMfAkDxcSBqmIl"));
    this->PqaImv(-1731547796, 893499.7436913655, 827156.5548669485, 983413.9942480752, true);
    this->feTZmUjUhP(string("DWumhWPxGPoFypVwNQCKaWfwjsOHQqHjwnstyOzTFIKGYUEVRymnl"), true, 780519.071608973);
    this->gFMol(false, false, string("cEjHantxVKjQneoimFtTkykdAESIyDRILOpgGZubeEKmDSmRXtAHKGqfWIEelvwzaDMPMbygtmKONCqRHuqOldleOnkmeFUGIwNYd"), false);
    this->OQOFEdHGXaan();
    this->EdyEhBABeTAqr(2136302743, -327942879, -1172002598, 313277109, -120953.40665269272);
    this->AYCWo(357668405, 582712.4784580263);
    this->ZEMZVglyoppqdKJU(372569382, false, string("EmESRBCraWcqoqfCIElPzFNYoSlQbPRqRxwLYiGdmWPNoIjKmIDFYrJpyONZRPLJvVdytODeStARWIyCKhZhWMvrDqODdvEDJdtsTFiLNmoePHgefUhlkVorvoWZHjKedwFpoLEFDCIfcauNTVzHFTDUjfFIXIxPgeOakZdCQfriycGRVEUhYSuuWiHDupVIxGqEwsiireuSwlVdwowzOiYiZQOBKJdSdbgCFnywHuLuWkB"), false);
    this->kTXhiavbZqMOzKn();
    this->ZvISeTjSoA(string("GPaRbCZqRLzAteVwthPOhJXCEqMaAjMgDoaEPjwFeTUnNuoBRAmXKLx"), true, false, string("LxdapkJofsShJwORGZHzfNQqyuyGftJFxKViriogJCibCLZvvyuazWfyFWphcUYgUlQltxHVbuMvKzWfCnjGBsNAKMejOfnRdRmjwRzgqLZTQVDmMtiHOfKbOaCgVVXUqUssdJISYNrJtAaUrDDrmyvRXTWTGGgkfMZhixWNIxBcznZdNiVpJCnCNuxxVBTkqKZrewMNwvUhtCZEJBPvVECrGcLhcjwKUwcJfqYRmIrCZdHKnYl"), 639533.6664373504);
    this->upKyfJKD(1047109.7833887798);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WSELsyJnRy
{
public:
    string lqHBBEG;
    int WqyOgIsuxXIzx;
    bool dXofMTPF;

    WSELsyJnRy();
    string uOJOmQVBWCCChc();
    string MpHktnOghZYG(int JntVM, string gOYcwfTRp);
    string epenpNC(bool GVvnRd, bool epuRduZMLayJst, int qHweCJfeqFrJs);
    double KYmQh(double KIiLiUBdbVJMwR);
    int TrsBNGXlnLW();
protected:
    int cyoJSX;
    bool QyFgOYVasTruB;
    double bBwPelaBb;

    int qUfIhhgDzyJGXEH(string SSvrJPMqBGUzog);
    double nYSnNyUFpQcvPs();
    double azAkURNiUoM(double LfgapGiA);
    string iAIJsWKEGv(bool yJDxaASr);
    void NWMxDoHCoBgIryv(bool IuTsNdaObaQLzk);
    double WoVKdu(double aDwWdEMyVFUr, double nMGyCzOoyG);
    void gRfKFWWtvRVgl(double CNnOgTEBCuJjgXW, bool urYyLmwNmIe);
    void QDKfgVwXPDNTBvwi(double xzIsCPjWA, int cUggM, int OClsp, double aeywmeKedXHXDHEG, int BwaUpuZZIQ);
private:
    double xEPfaiyPzAzHjsc;

    int nnXqCRowU(int NygOSk, double rkEZbrVfWXG, double tgXITCndVeirezs);
    double wxKCyoiPAlS(bool KqmuVMPMniqyPo, double DkqyCIgeAoXzolmK, bool vBAxsRpkRCnmKezs);
    void ClYMjTHOhUFrReu(int MTRtmFVFfMGb, bool tyXudpe);
    int GVcLsx(int dCkWbGn, string XPahAcNSXArhtY, double cVBqm, string wFnnvpOuLyW, int PAaVcg);
    double UvfseAmWsAexxZ(double SxMzxVoYRyDi, double qgztyaQjUnqW);
    string kCKntq();
};

string WSELsyJnRy::uOJOmQVBWCCChc()
{
    int LbAyloyZtoorTK = 710575318;
    string ocvIS = string("npswDdRIBwGOnznOzwcwjCaWyougzYKTAhPbIWzvlaVawfLMnizPRNQCXBeAjgtdPOLIKRgyBhFZaRdDfTPbRmdYherwtHtBJLVkDdcXAjBUBnIzfkqhaahWoukyLgQbUNYlqnBLApJjuScjxPAXxlOeRFtNFrlZLYJaGcDKenJjipxeGQDbFdKqwqhSyxcGDEccESJEaAiJr");
    int YkWWLt = 1087193367;
    string cpXqBWwQ = string("abDQEWCeIODwJTRwYerYYEYJeGnCMioVwNxQKQLZdyptUOJIgQhlRyNIRhHVMUnAqDYyrgqDTpXIIZiEzaBhterrvRlUtykkQDVERkVfQkeykidkmpVSkEbraouvjuHcsbkpEiHOSsjsbRwEkgjOhnIsLeXIUzhdzlElQtDUOnHEmoYkCNBsSnarCnTuabISwLlWXmWiZSKvnNARRQpIZNCssLjaVHSPaEgaZSw");
    bool CukdoQiD = true;
    double mfMsFw = -1014170.2677931963;

    if (LbAyloyZtoorTK > 710575318) {
        for (int ZESHHBYjhXlhFcr = 193910670; ZESHHBYjhXlhFcr > 0; ZESHHBYjhXlhFcr--) {
            continue;
        }
    }

    for (int JrSOn = 326866312; JrSOn > 0; JrSOn--) {
        continue;
    }

    for (int fqKWziQdwdVUOJ = 157369339; fqKWziQdwdVUOJ > 0; fqKWziQdwdVUOJ--) {
        YkWWLt *= LbAyloyZtoorTK;
    }

    for (int ooGZYDPoXvgG = 1396466548; ooGZYDPoXvgG > 0; ooGZYDPoXvgG--) {
        cpXqBWwQ = cpXqBWwQ;
    }

    for (int skRwpdjceX = 789144572; skRwpdjceX > 0; skRwpdjceX--) {
        cpXqBWwQ = ocvIS;
        LbAyloyZtoorTK /= LbAyloyZtoorTK;
    }

    if (mfMsFw == -1014170.2677931963) {
        for (int cClOAzxxhNmTdC = 1853321075; cClOAzxxhNmTdC > 0; cClOAzxxhNmTdC--) {
            continue;
        }
    }

    return cpXqBWwQ;
}

string WSELsyJnRy::MpHktnOghZYG(int JntVM, string gOYcwfTRp)
{
    string PGweHtLxgR = string("gSzhieDiBuYWuKtlKOVQoyeXVTdzbUiZcYRBHBNgAecZuJujOhjwqEwCBwNATICmlsBbkZXSIYyldFWWYjoqiZJAb");
    string YfGfLfsCiys = string("IxQldSGYkabnsZoHnuQyOwRmaYfQCIDqplOVKwBLyfkvVvnatfafHlIAWxyFkAboIUgYNvdSxrTWfnAOyoxQFYgIXrLfFJuWGVhvmgqdmOBOSNlVuRQlRpXonhalXNgctqmYBEOXcEBOLNjpKvIKQNJdzCtlHTNUQxJKviZwhLYFfXLNBmvIkYMuaJARosLVRTDmqowTIoMnLDOzfkHUGNFZiJJuIqFfuKCajBPeSnhYgPzEHiizCOZt");
    bool CICBtn = false;
    int gzWYIuKZZRzrBOnM = -296904565;
    string MPNfINPaYROZbp = string("nfEalNaXQWYecOOZJhPgmJFFtdSxEEqkGFTgJhtlaCvSbzHKZaGKPdxDILeooQWRVLdQokIATt");

    if (MPNfINPaYROZbp < string("IxQldSGYkabnsZoHnuQyOwRmaYfQCIDqplOVKwBLyfkvVvnatfafHlIAWxyFkAboIUgYNvdSxrTWfnAOyoxQFYgIXrLfFJuWGVhvmgqdmOBOSNlVuRQlRpXonhalXNgctqmYBEOXcEBOLNjpKvIKQNJdzCtlHTNUQxJKviZwhLYFfXLNBmvIkYMuaJARosLVRTDmqowTIoMnLDOzfkHUGNFZiJJuIqFfuKCajBPeSnhYgPzEHiizCOZt")) {
        for (int pnzPuGndBBaM = 655199171; pnzPuGndBBaM > 0; pnzPuGndBBaM--) {
            continue;
        }
    }

    return MPNfINPaYROZbp;
}

string WSELsyJnRy::epenpNC(bool GVvnRd, bool epuRduZMLayJst, int qHweCJfeqFrJs)
{
    bool jwCLMAcjfOx = false;
    double tYtqsvWM = -889950.7919961017;
    bool EZzSVkv = true;
    bool ZsXSfXZocctPkil = false;
    bool JVglhakLcjFdwd = false;
    int lqFRSwFOEs = -483262766;
    string khbZaxjmhfLwg = string("vKQQvoZvFiUSPje");

    if (epuRduZMLayJst != false) {
        for (int ZIjuljipHwfZj = 1114509959; ZIjuljipHwfZj > 0; ZIjuljipHwfZj--) {
            GVvnRd = ! EZzSVkv;
            jwCLMAcjfOx = EZzSVkv;
        }
    }

    for (int HNrTGIHcsuLEibQ = 1580435184; HNrTGIHcsuLEibQ > 0; HNrTGIHcsuLEibQ--) {
        continue;
    }

    for (int DkJiOGsyjymGRyM = 209547287; DkJiOGsyjymGRyM > 0; DkJiOGsyjymGRyM--) {
        JVglhakLcjFdwd = ! JVglhakLcjFdwd;
        lqFRSwFOEs /= lqFRSwFOEs;
        JVglhakLcjFdwd = ! ZsXSfXZocctPkil;
    }

    if (epuRduZMLayJst != false) {
        for (int sysHgcEjnC = 2062499115; sysHgcEjnC > 0; sysHgcEjnC--) {
            continue;
        }
    }

    return khbZaxjmhfLwg;
}

double WSELsyJnRy::KYmQh(double KIiLiUBdbVJMwR)
{
    double CBBwHFkJHc = 122559.0539999872;
    string thjmJbTgnh = string("KJYwKQFVVzWmiknSizYhBvuNqFZowSlFqWXiQiEniSualovRtclegXNTGAYjTkxEYaruZvWuHYqvXTVOrvbgsKDaRHdZVtygMAsPAMwZUYYzcIDZxMDyMUDRXUedgRgefSOycUxpnitjJcZGqXYlGWpjjjKexdCVfrOdWIpmlhIsllrtfKCYvazybXctHZJRhrt");

    for (int qqmgW = 1767503176; qqmgW > 0; qqmgW--) {
        CBBwHFkJHc /= KIiLiUBdbVJMwR;
        CBBwHFkJHc *= KIiLiUBdbVJMwR;
        thjmJbTgnh = thjmJbTgnh;
        thjmJbTgnh = thjmJbTgnh;
    }

    if (CBBwHFkJHc == 122559.0539999872) {
        for (int kQPGrUzWu = 1415839084; kQPGrUzWu > 0; kQPGrUzWu--) {
            CBBwHFkJHc += KIiLiUBdbVJMwR;
            KIiLiUBdbVJMwR /= CBBwHFkJHc;
            KIiLiUBdbVJMwR += KIiLiUBdbVJMwR;
        }
    }

    for (int MojJucjufJTxUgr = 1170330484; MojJucjufJTxUgr > 0; MojJucjufJTxUgr--) {
        KIiLiUBdbVJMwR *= KIiLiUBdbVJMwR;
    }

    if (KIiLiUBdbVJMwR >= -775621.5709711193) {
        for (int cHFeLRQrdMJxxcAO = 89196348; cHFeLRQrdMJxxcAO > 0; cHFeLRQrdMJxxcAO--) {
            KIiLiUBdbVJMwR -= KIiLiUBdbVJMwR;
            CBBwHFkJHc /= CBBwHFkJHc;
        }
    }

    for (int vnmpT = 1505887867; vnmpT > 0; vnmpT--) {
        thjmJbTgnh = thjmJbTgnh;
        CBBwHFkJHc /= KIiLiUBdbVJMwR;
        KIiLiUBdbVJMwR = KIiLiUBdbVJMwR;
        thjmJbTgnh = thjmJbTgnh;
    }

    return CBBwHFkJHc;
}

int WSELsyJnRy::TrsBNGXlnLW()
{
    string CbYTdofnsjjZ = string("mlCBxZtNbhZgS");
    bool ySCrCkdOcbLCzJtr = false;
    double SNpYDHoRZawM = 81912.94049685454;
    bool HMMbFftxnLnuu = false;
    bool ybtGHiyYbNmcz = true;

    if (ySCrCkdOcbLCzJtr == false) {
        for (int zUjBff = 1177252561; zUjBff > 0; zUjBff--) {
            ybtGHiyYbNmcz = HMMbFftxnLnuu;
            HMMbFftxnLnuu = ybtGHiyYbNmcz;
            ybtGHiyYbNmcz = ySCrCkdOcbLCzJtr;
        }
    }

    if (ybtGHiyYbNmcz != false) {
        for (int PGtOOatD = 1726328894; PGtOOatD > 0; PGtOOatD--) {
            ybtGHiyYbNmcz = ! HMMbFftxnLnuu;
            HMMbFftxnLnuu = ! ySCrCkdOcbLCzJtr;
        }
    }

    if (SNpYDHoRZawM != 81912.94049685454) {
        for (int VsFKKC = 1238166017; VsFKKC > 0; VsFKKC--) {
            ybtGHiyYbNmcz = ! ySCrCkdOcbLCzJtr;
        }
    }

    return -1924252521;
}

int WSELsyJnRy::qUfIhhgDzyJGXEH(string SSvrJPMqBGUzog)
{
    int vQTJeELDyz = -1311274169;
    int FaXdHAkv = -1160756308;
    string ngbBGpsUVMJIYCR = string("jYLNTDzpGAxCuxLRkKHriKKGHKOHlidVzVIMDursPpdLJYBNwxEvyewiWhCsDLSFEKipJxgcHqEnMAcvIvQnWJouvKhcQZmCMyEcBMeuHiFIxYrwpfrIevhzQgMkOKamHnjBucIBCipEUmXFPUbKIchsxzVuApOnTgxjHzgWbDYGnyrUxtywqMwaCrBsFMQwdOaGMoyHqeKmSo");
    string EzJefQgJGGxIv = string("XiPBIfhKlaOdDKkgCoqTpfccHBMZSmUVeDUmMZEAzfFtAboaKQmOkHCKKLSVZnQvBXuDMFgPdFoFofHGYkBEzSRWxtCYaXDRrTlXDuDeyhQggUuMYoXOFlCPmcSKnWxvNvRhFIbHdyQaDcKLzejSkomotJubuWZKLIYtVheGjXcuDvXgNiLQWHGDELULQdcFpybwhOpDehaQqYqEqEjJaqpblpiwvUrASfqXcFrPgq");
    double wHpkRdPAufRU = -190947.17990657708;
    string MqQbjpRxUlE = string("pjEWO");
    double RjCiIIFFRTLWzW = -617719.9490982869;
    string IRrYYCjYmdGgwKi = string("OMbBrnslcfhIElNfLQyetYkrGJmdnGeduntFxcRzUuylnQSJeUJSbRCbIrAjuqAyClRMZLkaefexbzTGtBnOyIxceVmsRvzhxJqvaudiMnCBFhvyjBycWoUXlXJlPCkBGBUnZZVJhqHDgOZvyPgjEMWFdysqzMJOBcVMUKqHhssfeiMuZSkXooz");

    for (int AZGQdSEntuPr = 1455400155; AZGQdSEntuPr > 0; AZGQdSEntuPr--) {
        MqQbjpRxUlE = SSvrJPMqBGUzog;
        IRrYYCjYmdGgwKi += EzJefQgJGGxIv;
        SSvrJPMqBGUzog = IRrYYCjYmdGgwKi;
        SSvrJPMqBGUzog = IRrYYCjYmdGgwKi;
        ngbBGpsUVMJIYCR += SSvrJPMqBGUzog;
    }

    if (SSvrJPMqBGUzog < string("XiPBIfhKlaOdDKkgCoqTpfccHBMZSmUVeDUmMZEAzfFtAboaKQmOkHCKKLSVZnQvBXuDMFgPdFoFofHGYkBEzSRWxtCYaXDRrTlXDuDeyhQggUuMYoXOFlCPmcSKnWxvNvRhFIbHdyQaDcKLzejSkomotJubuWZKLIYtVheGjXcuDvXgNiLQWHGDELULQdcFpybwhOpDehaQqYqEqEjJaqpblpiwvUrASfqXcFrPgq")) {
        for (int cbRcopzM = 17756048; cbRcopzM > 0; cbRcopzM--) {
            continue;
        }
    }

    for (int VlAfsUPDEKQd = 829312280; VlAfsUPDEKQd > 0; VlAfsUPDEKQd--) {
        ngbBGpsUVMJIYCR = ngbBGpsUVMJIYCR;
        MqQbjpRxUlE = SSvrJPMqBGUzog;
        ngbBGpsUVMJIYCR = IRrYYCjYmdGgwKi;
    }

    return FaXdHAkv;
}

double WSELsyJnRy::nYSnNyUFpQcvPs()
{
    string ekOsQYDoTwqFVE = string("UWpbWrdPnEOiHocbXSicXDjBYXvxkttJHZjUegPDjumbnnjEVWJDsQxRpGAipqEJsWisXbGUAqWyTtVXeEqQaRjQTIGpZQRCfdHCxTmekAIKqHlSLgKlksAtJvMSqKVKJjHfTaNWHUTjuhBJqUNiuL");
    double LxUOitvcfcqxrbn = 492568.76353368495;
    string EyplTnkcVVnD = string("dKRZWsprouCPdGvFGXoErslUtxMyiIuKDCujnCLndUOPvdWhLHmvwMZpnBNxJjnwLofQhxcAMVQNyRToMVkccwjYtoWDzThQWdGsSyppVWMQbTeyFhpZGfNhleOmolTnPiHSEUNux");
    double HKgnCZar = -506745.2310332931;
    int XvDXPyT = -1751132950;
    int JcXrSecTaACnVr = 642764291;
    double hzmwZBaXb = 55094.980484824126;
    string BDydxtjfBeJJK = string("BgFaIAhKBrGCQxOoUaPekDEJDaLsuxcLCQJC");
    bool sRoWXHppR = false;

    if (EyplTnkcVVnD < string("BgFaIAhKBrGCQxOoUaPekDEJDaLsuxcLCQJC")) {
        for (int KIYEOYGapOm = 1000846524; KIYEOYGapOm > 0; KIYEOYGapOm--) {
            ekOsQYDoTwqFVE += BDydxtjfBeJJK;
            LxUOitvcfcqxrbn -= hzmwZBaXb;
            JcXrSecTaACnVr *= XvDXPyT;
        }
    }

    for (int znpCTpoqc = 297446607; znpCTpoqc > 0; znpCTpoqc--) {
        continue;
    }

    return hzmwZBaXb;
}

double WSELsyJnRy::azAkURNiUoM(double LfgapGiA)
{
    bool ETgci = true;
    string HRJXtLFBMXNE = string("jCIEmUvbMJLWeypLDSspqFbrIwutMlVnPzMNHQzBWidgmCriEfPcHFRuOlhLjvsRiSzPYXjZVZKnAYzTslOqEKaukWbQwagvFLTzGnBfZNBmgTfMPUPupwyMRBIvpKhPQnbfTCLaFYHdAWOGYcdopqMQfiozRireMPhdZvajKifKXDVZnyDanLWrGrlEP");
    double NiytfEGwcVHDHf = 10040.327001507183;
    bool tsCgqbLsTTjqmdL = true;
    string PfUifVjDHJL = string("XBKZYynIIgNyvvLJSGIfCIzoPGZqfKmAEpKaMMdagntlVa");

    for (int fRnPRMAUQxyB = 901931147; fRnPRMAUQxyB > 0; fRnPRMAUQxyB--) {
        continue;
    }

    for (int NqRsa = 1077488381; NqRsa > 0; NqRsa--) {
        tsCgqbLsTTjqmdL = ! tsCgqbLsTTjqmdL;
        LfgapGiA = NiytfEGwcVHDHf;
    }

    if (LfgapGiA < -876016.9575965294) {
        for (int IFAcvnhqUr = 422797063; IFAcvnhqUr > 0; IFAcvnhqUr--) {
            ETgci = ! ETgci;
        }
    }

    for (int GTDdwjtGdMcXRLn = 1293338527; GTDdwjtGdMcXRLn > 0; GTDdwjtGdMcXRLn--) {
        ETgci = ! tsCgqbLsTTjqmdL;
    }

    return NiytfEGwcVHDHf;
}

string WSELsyJnRy::iAIJsWKEGv(bool yJDxaASr)
{
    bool kCduYuBEP = false;
    double BaYOVvnFWhCVQvw = 230101.3807430212;
    int iSwaDRktiVJYGAOB = -462369277;
    int hLMLgHxZEYdWnjQ = -393238032;

    for (int wLvadw = 1239876935; wLvadw > 0; wLvadw--) {
        iSwaDRktiVJYGAOB += iSwaDRktiVJYGAOB;
        yJDxaASr = kCduYuBEP;
    }

    for (int qruObqK = 283479288; qruObqK > 0; qruObqK--) {
        iSwaDRktiVJYGAOB -= iSwaDRktiVJYGAOB;
    }

    for (int zZsASYje = 1266317132; zZsASYje > 0; zZsASYje--) {
        continue;
    }

    for (int JPfFFsYc = 1413307673; JPfFFsYc > 0; JPfFFsYc--) {
        iSwaDRktiVJYGAOB -= hLMLgHxZEYdWnjQ;
        BaYOVvnFWhCVQvw /= BaYOVvnFWhCVQvw;
    }

    for (int OOnqGsiYddUY = 583450628; OOnqGsiYddUY > 0; OOnqGsiYddUY--) {
        yJDxaASr = yJDxaASr;
    }

    return string("YCNEyZrmpPgwYqHJTnmdUsijLlyZwWiTQOVQfyNJzevBtZGQgIbehlYbbzyOnVbmvkGVLAJscmDqYqOrFFRSmamFqhZXJLAPawhkQmGdBxdRFBDeXkmVNllBYeYFIZSvvJxBaExrbqTcAoTnTwQZjAFhQUOBSCRVTpEUPGbzcnvzewwWNUtFrsfALBfBUPBWSAmFbsNqlDFja");
}

void WSELsyJnRy::NWMxDoHCoBgIryv(bool IuTsNdaObaQLzk)
{
    double KHZXlYKFaFq = 121142.28556877322;
    bool wemlVLPLtVkqXGR = true;
    string kLqAuV = string("HANdTZMOYusYKGtLZwntmtURbILjLKPLyneInmoXvnXUjbtEiwAYToAgVBLlsozJvPabzehoBmhZEZRPWmXmMQHRJtDvggpjbtFAkjbvnRKKCxzRMjLkLhwwWPiERyoXFhveaCQONnKnRyTHaUQUyjsUgaMGuBPKOaakAMJuuArYJtuCBpiiNcaUAqWGIIVudOKZNe");
    int aaKhCqASXQzxkpMC = -384526848;
    string eUvYTEmqolzTCc = string("NAoUPhFCcAfVQElCELeJJpVIIqtLqIIuSjmJ");
    string XoATCqpZXYNqN = string("GsTpdLxTXdLnoxZmGHuGAKAUYitvZebGfSmMIckcCuvMelMISMymAxZxzHvgdSPwYGmeDFkRvNYxxJgJWAUpRabBktHjoEaHhJplclTGULHFIbOOluuCRIvINSlZiUWewwjOhzjDVvOSaECiUNMtLyIiYgBTxbkANCzdynuNoQQxvxEpgtQZnbhOtLzfguvDPRwJLMbjpULUOwTFYxwRuBjHvbpcRmxffRQfJqxhwmUBwYGzAbnHd");
    int eOnwBiNlAqmR = 1205387191;

    for (int rhDqrAM = 763556111; rhDqrAM > 0; rhDqrAM--) {
        continue;
    }

    for (int MNqwIkIjWoRIly = 1363445293; MNqwIkIjWoRIly > 0; MNqwIkIjWoRIly--) {
        IuTsNdaObaQLzk = ! wemlVLPLtVkqXGR;
        eUvYTEmqolzTCc += kLqAuV;
        eUvYTEmqolzTCc += eUvYTEmqolzTCc;
        kLqAuV = XoATCqpZXYNqN;
        eOnwBiNlAqmR *= eOnwBiNlAqmR;
    }

    for (int fdCnXMYDP = 279219332; fdCnXMYDP > 0; fdCnXMYDP--) {
        XoATCqpZXYNqN += eUvYTEmqolzTCc;
        KHZXlYKFaFq = KHZXlYKFaFq;
        aaKhCqASXQzxkpMC -= eOnwBiNlAqmR;
        IuTsNdaObaQLzk = wemlVLPLtVkqXGR;
    }
}

double WSELsyJnRy::WoVKdu(double aDwWdEMyVFUr, double nMGyCzOoyG)
{
    bool VFMfnMWJDqGPnZz = false;
    double iHwSrOSFFhdRod = -269252.47442543483;

    if (VFMfnMWJDqGPnZz != false) {
        for (int EbhaqurAWfPus = 1429186429; EbhaqurAWfPus > 0; EbhaqurAWfPus--) {
            iHwSrOSFFhdRod += aDwWdEMyVFUr;
            iHwSrOSFFhdRod += nMGyCzOoyG;
            iHwSrOSFFhdRod = aDwWdEMyVFUr;
        }
    }

    for (int yGzYcgjwoIPCN = 744860753; yGzYcgjwoIPCN > 0; yGzYcgjwoIPCN--) {
        nMGyCzOoyG = iHwSrOSFFhdRod;
        aDwWdEMyVFUr += nMGyCzOoyG;
        nMGyCzOoyG -= iHwSrOSFFhdRod;
        VFMfnMWJDqGPnZz = ! VFMfnMWJDqGPnZz;
        VFMfnMWJDqGPnZz = VFMfnMWJDqGPnZz;
        iHwSrOSFFhdRod = aDwWdEMyVFUr;
    }

    if (iHwSrOSFFhdRod < -269252.47442543483) {
        for (int nEdjJvhbVQKXu = 1520673190; nEdjJvhbVQKXu > 0; nEdjJvhbVQKXu--) {
            aDwWdEMyVFUr *= nMGyCzOoyG;
            aDwWdEMyVFUr /= aDwWdEMyVFUr;
        }
    }

    for (int pXdzhV = 219847476; pXdzhV > 0; pXdzhV--) {
        iHwSrOSFFhdRod = nMGyCzOoyG;
        aDwWdEMyVFUr = aDwWdEMyVFUr;
        iHwSrOSFFhdRod += nMGyCzOoyG;
        nMGyCzOoyG -= aDwWdEMyVFUr;
        nMGyCzOoyG /= iHwSrOSFFhdRod;
        nMGyCzOoyG *= nMGyCzOoyG;
    }

    if (nMGyCzOoyG == -651448.511204003) {
        for (int JQerRTSZAWKraZ = 661157912; JQerRTSZAWKraZ > 0; JQerRTSZAWKraZ--) {
            nMGyCzOoyG = iHwSrOSFFhdRod;
            nMGyCzOoyG *= nMGyCzOoyG;
            iHwSrOSFFhdRod *= nMGyCzOoyG;
            aDwWdEMyVFUr *= nMGyCzOoyG;
        }
    }

    return iHwSrOSFFhdRod;
}

void WSELsyJnRy::gRfKFWWtvRVgl(double CNnOgTEBCuJjgXW, bool urYyLmwNmIe)
{
    string HCLnYAseE = string("GgEohPRhctkSlFoglVfXfWyRbaENArfcqwZPxGaRoFjGzuBisxZofhtGncAdRyKmHVajsDbYpVmxxzHGAWHoWDPmQGAlnTiQSjnEfBfIAhmMSJuXSMOZBHonVZDgotBIhjsIlsOpCvLLpjjsfOskAzCbg");
    int CSHKOBgXuQOmHr = 426555189;
    string hYgxmnxYu = string("DttEqnRGZsUQYmWDZFKTEc");
    double yGIliJCpYRwTcg = -136888.93713154964;
    bool QIGNyeUubvYrm = false;
    int iHUXWsMbnoQAThL = -1596890441;
    int PnKMLlDZEtoOR = 318873830;
    double NZmKNpvz = 879961.486116769;
    bool zcJyogpTJmav = true;

    if (CSHKOBgXuQOmHr != 426555189) {
        for (int nuOSyRukxX = 423499643; nuOSyRukxX > 0; nuOSyRukxX--) {
            yGIliJCpYRwTcg += NZmKNpvz;
        }
    }

    for (int XwWMjusfaEgPFZIh = 709551450; XwWMjusfaEgPFZIh > 0; XwWMjusfaEgPFZIh--) {
        zcJyogpTJmav = zcJyogpTJmav;
    }

    if (PnKMLlDZEtoOR < -1596890441) {
        for (int yNfcwKaFsG = 342499008; yNfcwKaFsG > 0; yNfcwKaFsG--) {
            PnKMLlDZEtoOR /= iHUXWsMbnoQAThL;
        }
    }
}

void WSELsyJnRy::QDKfgVwXPDNTBvwi(double xzIsCPjWA, int cUggM, int OClsp, double aeywmeKedXHXDHEG, int BwaUpuZZIQ)
{
    int nnZruP = 1843493672;
    double XwCovkWUfcpuWA = -596881.1205990106;
    bool XNgnwpWp = true;
    string gTlIdSjLPbNjJJF = string("wciJJpmERpWBbviKIaJSEmvwwegxssVyjKssJjwybtdMzRaCeaihzRaBMURqzjydTSqGMISMGIsGRrDjriNmTbblfglkUwKkQGexJrfnekeyNZsxsrZVjaVziHhtBSFQLGRfdj");
    int wRcdjLDRewQyCSbi = -376440088;
    int fhXHgTnhcIUTtr = -294512152;
    bool gXFaqfCprawFcYR = false;
    bool ipBEglgN = true;
    int mZkneRSneItdUK = 319322618;

    for (int yAzEZup = 1847728977; yAzEZup > 0; yAzEZup--) {
        ipBEglgN = ! ipBEglgN;
        mZkneRSneItdUK -= OClsp;
        BwaUpuZZIQ = fhXHgTnhcIUTtr;
        BwaUpuZZIQ *= OClsp;
        wRcdjLDRewQyCSbi -= fhXHgTnhcIUTtr;
        mZkneRSneItdUK += cUggM;
    }

    for (int TaVORqEWd = 2003864457; TaVORqEWd > 0; TaVORqEWd--) {
        continue;
    }

    if (OClsp > -657856951) {
        for (int HgFYtnY = 250386720; HgFYtnY > 0; HgFYtnY--) {
            mZkneRSneItdUK = nnZruP;
        }
    }
}

int WSELsyJnRy::nnXqCRowU(int NygOSk, double rkEZbrVfWXG, double tgXITCndVeirezs)
{
    string tttdbdKvgahQWVIS = string("RaCoypYvuPkrbBDZAJq");
    bool xXHJR = false;

    for (int cqzMtceplaNF = 733646735; cqzMtceplaNF > 0; cqzMtceplaNF--) {
        xXHJR = ! xXHJR;
        tgXITCndVeirezs += tgXITCndVeirezs;
        tttdbdKvgahQWVIS += tttdbdKvgahQWVIS;
        xXHJR = xXHJR;
        tgXITCndVeirezs += tgXITCndVeirezs;
    }

    for (int EoJhJPFnHnVE = 1626332597; EoJhJPFnHnVE > 0; EoJhJPFnHnVE--) {
        NygOSk *= NygOSk;
        rkEZbrVfWXG -= rkEZbrVfWXG;
    }

    for (int QgZVoZNmk = 512024448; QgZVoZNmk > 0; QgZVoZNmk--) {
        continue;
    }

    for (int kOdJaLFwEvyGa = 539942525; kOdJaLFwEvyGa > 0; kOdJaLFwEvyGa--) {
        rkEZbrVfWXG = rkEZbrVfWXG;
        tttdbdKvgahQWVIS = tttdbdKvgahQWVIS;
    }

    if (tttdbdKvgahQWVIS >= string("RaCoypYvuPkrbBDZAJq")) {
        for (int rnsDAJLdatWZf = 631143031; rnsDAJLdatWZf > 0; rnsDAJLdatWZf--) {
            xXHJR = ! xXHJR;
            xXHJR = xXHJR;
        }
    }

    return NygOSk;
}

double WSELsyJnRy::wxKCyoiPAlS(bool KqmuVMPMniqyPo, double DkqyCIgeAoXzolmK, bool vBAxsRpkRCnmKezs)
{
    double ioYjfpIFvwSvAYi = -615349.4939653965;
    string WpxjFLEaVjm = string("NOKguFYNBGBlCSexGvkimCbBQJxqgyCDddQXIynYBdlUcrcnIUtWsemnyaMrAbBFlCfekzqEFkzAyjPqAVQuzFVFDLRXfMfhnrLoHe");
    bool HQlpzpdJOdyV = false;
    double upLywC = -72815.15015339633;
    bool jRHMWGRUurPvmzX = true;
    int kqyCMhxudaRDBic = 699743279;

    return upLywC;
}

void WSELsyJnRy::ClYMjTHOhUFrReu(int MTRtmFVFfMGb, bool tyXudpe)
{
    double GGTIladawjqVnn = -753685.922074779;
    double lArAqqZXmy = 257645.1515116798;
}

int WSELsyJnRy::GVcLsx(int dCkWbGn, string XPahAcNSXArhtY, double cVBqm, string wFnnvpOuLyW, int PAaVcg)
{
    double aQNxUfTL = 854248.2708241509;
    string vpfZEoEnjchG = string("rpFzePedUINiCTTJmjTNxyfEeaKFfLOlzkhzyeBrOoxu");

    if (vpfZEoEnjchG > string("KMfTLBxfhiBpODXIwWZyywFxMonmazUWfOEOqcqlKTDNrSAQOimMERobQYaSIcXHWPloCLSCDnyWQpCKPvhFJWxTSPamuwpmGQCmtzFfkpNRoLWJdVsYAcDycZLjMlTUiWJzXarjdwVxDSoOjXKSXVdsURikTLbxcrubwNtmQkMkAmnOiZybVYpXDzmsItGrjWIkXvcJgAMmzuEADUYGsobnBhwyzedPnAHgkZ")) {
        for (int hCPBmrbhdrdsBrGT = 969938064; hCPBmrbhdrdsBrGT > 0; hCPBmrbhdrdsBrGT--) {
            vpfZEoEnjchG = XPahAcNSXArhtY;
            aQNxUfTL /= cVBqm;
        }
    }

    return PAaVcg;
}

double WSELsyJnRy::UvfseAmWsAexxZ(double SxMzxVoYRyDi, double qgztyaQjUnqW)
{
    double ywNDFMvpYlbXdARA = 383761.14348676364;
    bool dYeFFVKVz = true;
    double NJPLM = -668795.0625229263;
    int GkcjpjaAxHVyTc = -1426496703;
    string dJrLbG = string("cYIISzZNDxbVJCIqrUCBOgrTjXisHgjaNerJBAyQsCBcLHGAIKKAFcnMtBtZTNaTHiLaEEnhZasmnDPWsKdVNtUBMOaGAHRiRiJousdKWTzpGTbYPAWHwLhDqimoxueckQBblurhTrfDCMoIYiOhK");
    bool fMheFQLqqQHIS = false;
    bool ByHlJLlQ = false;
    double iVxIMtaMMMGih = 807344.9366139943;

    if (SxMzxVoYRyDi > 517885.7857176717) {
        for (int cjlNhjIPoU = 1742540284; cjlNhjIPoU > 0; cjlNhjIPoU--) {
            SxMzxVoYRyDi -= ywNDFMvpYlbXdARA;
            ByHlJLlQ = fMheFQLqqQHIS;
            SxMzxVoYRyDi *= ywNDFMvpYlbXdARA;
            iVxIMtaMMMGih += iVxIMtaMMMGih;
            SxMzxVoYRyDi /= NJPLM;
        }
    }

    if (dJrLbG != string("cYIISzZNDxbVJCIqrUCBOgrTjXisHgjaNerJBAyQsCBcLHGAIKKAFcnMtBtZTNaTHiLaEEnhZasmnDPWsKdVNtUBMOaGAHRiRiJousdKWTzpGTbYPAWHwLhDqimoxueckQBblurhTrfDCMoIYiOhK")) {
        for (int UmXKdhScYHYztw = 1584145014; UmXKdhScYHYztw > 0; UmXKdhScYHYztw--) {
            qgztyaQjUnqW += iVxIMtaMMMGih;
        }
    }

    for (int TmaTjjDk = 1427616674; TmaTjjDk > 0; TmaTjjDk--) {
        continue;
    }

    return iVxIMtaMMMGih;
}

string WSELsyJnRy::kCKntq()
{
    int eFkIpKdPw = -258823762;
    bool wIhTGqreziL = false;
    double wJdmufSPlrDtL = 475972.0023089925;
    bool BkNamezo = true;
    string HetwxuoHowcSoe = string("WjLwUzBMbfhWyqQvePfmxsUqemvcTWzvtiGSbsJMZtnIOIqezOzmjduwrNeeFYhlmyyRJMPluKHdkslgWZFwxfcgfiiuqckSEJrqrMlXNLVKJusYhDmWhuvbQGXTkcyAIABgMnvUEbIOUZjYTFqVXQHhIaWfkDFsmQGikpaXtRCHzoDYXzGIatoSw");
    int PjFwHa = 1732258147;
    int ezcqSPwkpnd = 1194468168;

    for (int kutOzfHgwAWZ = 1137867561; kutOzfHgwAWZ > 0; kutOzfHgwAWZ--) {
        continue;
    }

    for (int ukgfONplDCUpMk = 2044368657; ukgfONplDCUpMk > 0; ukgfONplDCUpMk--) {
        eFkIpKdPw += eFkIpKdPw;
        HetwxuoHowcSoe += HetwxuoHowcSoe;
        BkNamezo = wIhTGqreziL;
    }

    if (eFkIpKdPw == 1732258147) {
        for (int CQBJQyekdnczS = 63186058; CQBJQyekdnczS > 0; CQBJQyekdnczS--) {
            ezcqSPwkpnd += eFkIpKdPw;
            PjFwHa /= eFkIpKdPw;
            PjFwHa -= ezcqSPwkpnd;
            PjFwHa -= eFkIpKdPw;
        }
    }

    return HetwxuoHowcSoe;
}

WSELsyJnRy::WSELsyJnRy()
{
    this->uOJOmQVBWCCChc();
    this->MpHktnOghZYG(1409059821, string("qBwjHGZWmNOzpGMcVlKkqGXIAOanwCLsLJWwBcWuAabiKxYRYfeThsTallmpFgAfPGCuEuBOxdKjVRjYerDlfAtQERyZrUusjKRQTXqRLJHYWzBVCpLdIEaXvIWUpptnOrodSyfITDOdBXLTKxdDjyR"));
    this->epenpNC(false, true, -541749951);
    this->KYmQh(-775621.5709711193);
    this->TrsBNGXlnLW();
    this->qUfIhhgDzyJGXEH(string("IzJbDzmlHGHnDqVPhiCLyXpDHrwtPIfHDIRwoxpLwNQJpCGTgrPaVkVAzrTRFAaYfKhiznmwGNwxINcPfgYJkkWGjjv"));
    this->nYSnNyUFpQcvPs();
    this->azAkURNiUoM(-876016.9575965294);
    this->iAIJsWKEGv(false);
    this->NWMxDoHCoBgIryv(false);
    this->WoVKdu(-651448.511204003, 167977.52502178226);
    this->gRfKFWWtvRVgl(407047.03997561074, true);
    this->QDKfgVwXPDNTBvwi(473387.18916287273, 1907282840, -657856951, 975854.8050918352, -1061906275);
    this->nnXqCRowU(896726196, 429706.5413355175, -467734.3642263929);
    this->wxKCyoiPAlS(false, -378079.5895980317, false);
    this->ClYMjTHOhUFrReu(1067609548, true);
    this->GVcLsx(576758880, string("SqpjphAYIWFvsPcZJeXXyusOglCyKJNUdMyQgCDCrMLXIlNvztLBBFejcowCIYWffIzgZINAKAnsGZrwokNjFuFeNftBiIGqwnNnYGpYLtCyUDFOlGLnwtsRy"), -254681.65970127736, string("KMfTLBxfhiBpODXIwWZyywFxMonmazUWfOEOqcqlKTDNrSAQOimMERobQYaSIcXHWPloCLSCDnyWQpCKPvhFJWxTSPamuwpmGQCmtzFfkpNRoLWJdVsYAcDycZLjMlTUiWJzXarjdwVxDSoOjXKSXVdsURikTLbxcrubwNtmQkMkAmnOiZybVYpXDzmsItGrjWIkXvcJgAMmzuEADUYGsobnBhwyzedPnAHgkZ"), -1302773474);
    this->UvfseAmWsAexxZ(-867676.9961764567, 517885.7857176717);
    this->kCKntq();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eOuCwGVcgWCX
{
public:
    bool FqrxWwROtEF;

    eOuCwGVcgWCX();
    double RhxUXEmAwmudzxmd(string dFMZc, string gHieLaW, bool MUpJbYwDtBraRWRx);
    double dlGrfZo();
protected:
    double qLnOJCTTyJdiJby;
    string tzKXZjKscNp;
    double unOBhJiOpeA;
    bool jrIijNUdbo;
    int RfeudXsSPeKfcyH;
    int VwuXTKsCP;

    string chbqeuMvKEPJKys(int dygjWIXyGlxSJ, string ZiubJvVrFNFHvDRK, double hsAJSLE, bool mMIofoQA);
    string cOMzRLQUnPVuJQZS(bool yFgdvptT, double DybvfaUHfNfAI, bool GoPIPrPaVzmH, string DxRHmRIMclL);
private:
    string tIRLg;
    int yDPnEHoJtzaMu;
    double ADbofQtZ;
    bool fyMiw;
    int rjVdjaI;

};

double eOuCwGVcgWCX::RhxUXEmAwmudzxmd(string dFMZc, string gHieLaW, bool MUpJbYwDtBraRWRx)
{
    int pndSDRq = -2086156853;
    double bjGWnotjEcda = -585633.554874064;
    int vFFJSnuYeO = -2135126365;
    string EZuvCvXwjPWaQjWp = string("YwpCsweMcyWJMChSYkPfoAZpFbdTneKTDdAXuDrZMAOaqKLMgpsXSAVesVBXckqWYiYgUGeXDAdcNiinPD");
    double ftOqhLlO = -649600.5856434206;
    double ERmXfEOSmr = 906176.9311327409;

    for (int AzxMyy = 1310900978; AzxMyy > 0; AzxMyy--) {
        dFMZc = dFMZc;
    }

    for (int ssrCXm = 554118412; ssrCXm > 0; ssrCXm--) {
        gHieLaW = EZuvCvXwjPWaQjWp;
        gHieLaW += EZuvCvXwjPWaQjWp;
    }

    for (int EZjzYqFI = 729641780; EZjzYqFI > 0; EZjzYqFI--) {
        bjGWnotjEcda /= ftOqhLlO;
    }

    for (int PImnHUeJRHCX = 473198122; PImnHUeJRHCX > 0; PImnHUeJRHCX--) {
        EZuvCvXwjPWaQjWp = gHieLaW;
    }

    return ERmXfEOSmr;
}

double eOuCwGVcgWCX::dlGrfZo()
{
    bool KbRoGs = false;
    bool yKncphmPpVKjDGml = true;
    int zJtyaMDmUF = 1709806618;
    string bTxspIMoUCcqCwH = string("qJaqAtXbxuGcnHJCPqNAaobcpgxZRboXvhQgUhzLJWvokagnCcijlIhuOAgvHgGGKlWTSlSyMTRAihlchwflTyuhclJlASPwTdbALMHUZInnhmaNKNfGGhieLdlWyBOptWPYxYTiBJxBeIXnmladJOgRsPIIYagYTdqhvvdEgpOLJZQlvJgjIhzQQLcd");
    string bzrtBLJhDwXzKUwz = string("FXrQNMkIJnWUOTKQUpMOZDaYqfOjylDOoBmvOxWxrJuKsBSzuZSxyXYNMxWprgWLCRWjNxeHNZhTwbxIZIKpAYOqusLZGsnzemicOHJgkRwjWuireQrzoPGUjqXicSAqzhYcRVcmxUPjzZrNUWRaqUtuOdJcwINkfCuDliYoQsstZCToglyfFKlazMIosfLxicXbXcRDDvJEkMtXIffmjmoh");
    int OwMbIuZVymOW = -1563409207;
    string MAQpELOzD = string("bbmmgjrDfZLGTJlUObbUOxjcwxpaKWfhlytOgInJqnzVZIVtUIgLIphKtXkCndvZAKXobrarVcEzLHEnxmVbnhyZZxomemeqVJOiKHSFDkmqyBrlHYSAbcQMHjHcvbJwmNqZzdXghlUJHgRoCrbUTLlVvxtXjNbHAo");
    int xdtZNshq = 903462443;
    string PpjmDLFBXCgSTltr = string("pVgDawJKuirwBbHKZIXULqBMZYjJelEFnkgnwoabfRCgDkfXtIoCJICLExddmfbGdMYcJBJjHRmYuootxzkJTVGonbpizRwqLXUFhpWIPojwbOfaYbZuZGVLqnxnsoMSRWjQQtKSbPjpolQIQmnvebzuSTsTJtgkHXEtmL");
    int pAPRMXW = 2078721635;

    for (int tOgTHVci = 1179993429; tOgTHVci > 0; tOgTHVci--) {
        KbRoGs = ! KbRoGs;
        bzrtBLJhDwXzKUwz = bTxspIMoUCcqCwH;
        PpjmDLFBXCgSTltr += PpjmDLFBXCgSTltr;
        pAPRMXW *= pAPRMXW;
        MAQpELOzD += MAQpELOzD;
    }

    return -100818.33694210653;
}

string eOuCwGVcgWCX::chbqeuMvKEPJKys(int dygjWIXyGlxSJ, string ZiubJvVrFNFHvDRK, double hsAJSLE, bool mMIofoQA)
{
    double ctClSBOjT = -710433.9319222581;
    double wKNpZPaBUVtpyb = 986322.0505425829;
    bool CIkPUGXbqmtr = true;
    bool XYHHnmsm = true;
    int HumRWHc = -1760714040;

    if (XYHHnmsm != true) {
        for (int uunNnlTAO = 1680933031; uunNnlTAO > 0; uunNnlTAO--) {
            XYHHnmsm = CIkPUGXbqmtr;
        }
    }

    for (int jTTAQXcTKHnrlLol = 74532039; jTTAQXcTKHnrlLol > 0; jTTAQXcTKHnrlLol--) {
        continue;
    }

    for (int dVXNXveUrM = 2023960078; dVXNXveUrM > 0; dVXNXveUrM--) {
        continue;
    }

    return ZiubJvVrFNFHvDRK;
}

string eOuCwGVcgWCX::cOMzRLQUnPVuJQZS(bool yFgdvptT, double DybvfaUHfNfAI, bool GoPIPrPaVzmH, string DxRHmRIMclL)
{
    double HOBHPqgpRcgxSMGA = -840814.0695001674;

    for (int gnPnJxc = 638841222; gnPnJxc > 0; gnPnJxc--) {
        DxRHmRIMclL += DxRHmRIMclL;
        HOBHPqgpRcgxSMGA *= HOBHPqgpRcgxSMGA;
        yFgdvptT = ! yFgdvptT;
    }

    if (GoPIPrPaVzmH != false) {
        for (int OLcpsjtyWvZFuqn = 281848674; OLcpsjtyWvZFuqn > 0; OLcpsjtyWvZFuqn--) {
            DybvfaUHfNfAI -= HOBHPqgpRcgxSMGA;
            HOBHPqgpRcgxSMGA = DybvfaUHfNfAI;
            yFgdvptT = ! GoPIPrPaVzmH;
        }
    }

    if (HOBHPqgpRcgxSMGA != 702674.3213658677) {
        for (int ukNDy = 561816543; ukNDy > 0; ukNDy--) {
            yFgdvptT = GoPIPrPaVzmH;
        }
    }

    for (int qxXRoStPAP = 1727491858; qxXRoStPAP > 0; qxXRoStPAP--) {
        GoPIPrPaVzmH = yFgdvptT;
    }

    return DxRHmRIMclL;
}

eOuCwGVcgWCX::eOuCwGVcgWCX()
{
    this->RhxUXEmAwmudzxmd(string("MHXWhJkTwHnaJIEktvEzYXhNMKrFIMsTsTAqvOGgQkVtwDWJTizdjbzYCiedHpsTdFCjSTOmVIAxVieimhckrNCvKZWMHSTlePgtSfuSpiyzpZDmbMGuRNYHeRQNGJAIlzUXhQlRloafHAKrsxdgxrqxjTyFgvgkFjPNGUbRaBDbfASxACEpXQbXnOomijgawRliTkNraYPImPivZLFMg"), string("JAhKfjfrvwOmglRvBtfmTHHsqFgVBdS"), true);
    this->dlGrfZo();
    this->chbqeuMvKEPJKys(-1739675502, string("aTQSDAPjsDPWrcBSlPaicwapKXhxdcgUdsiyZVCGlwfgXcaEryJkKTlBLcATKjqnBMjwKGrsjAbvhdofLEGvKiuPjzuPkQWONnOtbedqqWRXDQnifqTDqpcTwVuoclJjFFeSQMmfFAUWSPmlqHA"), -414263.20073812484, true);
    this->cOMzRLQUnPVuJQZS(false, 702674.3213658677, false, string("eEgZuTbwXTXaNPWHrDCXogrRqRgpRHlMoHHFxpPVOlGDuOCkAwGPdFtlZcumsBTWWUJezPbo"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yyzEkJOPMpPdTE
{
public:
    bool WOyVHk;
    bool jnCtYJGddVRkd;
    bool kAoohdzGLXSDhDY;
    int hLAmnjcmEYg;
    bool gtWHVzkfCJf;

    yyzEkJOPMpPdTE();
protected:
    double suTxsloSkUc;

    string COmqsGgPKgTXfRc(int oCMKXZgIbq, bool lGwHCkrAgF, bool kPcXuCbpFsuWi);
    void sBxJlwb(bool NrrAGXKHJI, double TpLDQDkABTzNLxP, int ODOLzYxaU);
private:
    int aKtrTWrmiRIPRb;
    int vQWsYoDNczxulyS;
    bool SWRtInPfrmHHC;
    bool TUSeSSsmHOJ;

    bool NeFXkzLaysNzCue();
    string glkLM(int oNfdh, string CjVPxkxdggmPB, bool EHguV, int YjIvlHIcAMtavlp);
    bool LqQCYU();
    double bGJlEs(double WoGNpUspHwqBJB, bool CpsBFcbjcbvCA, string xOSooyW, int fGLkOmZeVXpUFbhC);
    bool SSoOsdAm(string UbNazXWAyRA);
    string kCgYqBurCypjE(bool MBSoA, string uyddVyYAhgTMOI, int uDPKyEiytx, bool gfBKukpg, double LTYperKbtgk);
};

string yyzEkJOPMpPdTE::COmqsGgPKgTXfRc(int oCMKXZgIbq, bool lGwHCkrAgF, bool kPcXuCbpFsuWi)
{
    double fvrTHL = -1041775.9947605155;
    double nbWsdxBzpD = -184582.35355743108;
    int OMFeOLp = 297570351;

    for (int HRgVqDWJpbDi = 227842310; HRgVqDWJpbDi > 0; HRgVqDWJpbDi--) {
        continue;
    }

    for (int mVSbfDRgTSTP = 1076368908; mVSbfDRgTSTP > 0; mVSbfDRgTSTP--) {
        OMFeOLp -= OMFeOLp;
        oCMKXZgIbq = oCMKXZgIbq;
        lGwHCkrAgF = ! kPcXuCbpFsuWi;
        kPcXuCbpFsuWi = lGwHCkrAgF;
    }

    return string("QEHRgZXTnkHePoeZgIkhrQfZpHnCvWpmWeujWPWnjNuWGwjvUt");
}

void yyzEkJOPMpPdTE::sBxJlwb(bool NrrAGXKHJI, double TpLDQDkABTzNLxP, int ODOLzYxaU)
{
    double LhxhYEiiGjmSp = 1047138.3541437257;
    string KGYMdYImKcRLwbe = string("JkDwJxymOqVPnHQpNTFPKFtzZvBAHabwYiyDHWdhpQpfgUNfenIcszUNyUETeMMdCrQhpncwjmzZhcSugaDzLQGzCaawPJWoMLMlpaJXDzLKKNXSFzMmWhXVwvZhMKzBiliYbuHAorhbvqGFeXhSlutwLFggqgqASrhLDjsRZhTHPDAkHInZr");
    int dFRAvhRvlx = 501716422;
    double CLzERzJERGicIGYe = -302456.53897680464;
    string YPSDumPx = string("aKCrBoqqmdTmNdztSbrrgbRywjIrMoiROfjLgYgLFkrlOVrILKWotZnBmnZBdZYCZEdPwIfHjDjnFwpsRaWduJtRJDIhAvAZbO");
    double tiEGYvD = -628275.5214612937;
    bool ZUvUthVHyKJOLkEg = true;
    bool RlXFilhBNNtEDlU = false;
    bool LgKSY = false;
    string mzKmT = string("UzQffVTPVmfIYOeUfRjShp");

    if (tiEGYvD < 1047138.3541437257) {
        for (int IEeYKfMgpyVmm = 1588847063; IEeYKfMgpyVmm > 0; IEeYKfMgpyVmm--) {
            continue;
        }
    }

    for (int xbPgUjlesBhYS = 2145917324; xbPgUjlesBhYS > 0; xbPgUjlesBhYS--) {
        ZUvUthVHyKJOLkEg = LgKSY;
        ZUvUthVHyKJOLkEg = NrrAGXKHJI;
    }

    if (NrrAGXKHJI != false) {
        for (int nMHXQD = 438037552; nMHXQD > 0; nMHXQD--) {
            continue;
        }
    }

    for (int iOhiUpCCvsLYuP = 873472320; iOhiUpCCvsLYuP > 0; iOhiUpCCvsLYuP--) {
        tiEGYvD -= TpLDQDkABTzNLxP;
        mzKmT += mzKmT;
    }
}

bool yyzEkJOPMpPdTE::NeFXkzLaysNzCue()
{
    double gZQIRwyvQYvMuzgA = -209338.4545390781;
    int vIOcgKKPoKTAI = 1503431509;
    int nCilbIzsfRjDwI = -90656399;
    string XZRElUHnxZmm = string("DuVcHQtnmdljqNAewvOEEZwpWyBagAiaspdJKbfoatcMxKqPBLeopuiWJVGExvsoVwBEHeqCRjFBBQGUEgJbrIZsurWBnClQGeyEvldSRGQNVNVbSDgzDBNYFmQyvioxFQwVqSvtfVgAZYTogykvsSRVGTQeOKYOOBaughxhTKwiWckaBsJOEsVrp");
    double AHmdoOJdJWBR = 654187.6044267511;
    int QZkqLGwIri = 1647768875;

    for (int eQaWWfzQJGFpTVst = 1242406211; eQaWWfzQJGFpTVst > 0; eQaWWfzQJGFpTVst--) {
        QZkqLGwIri += vIOcgKKPoKTAI;
    }

    for (int asqze = 556808959; asqze > 0; asqze--) {
        XZRElUHnxZmm += XZRElUHnxZmm;
        QZkqLGwIri /= QZkqLGwIri;
    }

    if (nCilbIzsfRjDwI == 1503431509) {
        for (int lDCHbiHznEaFgC = 1327287034; lDCHbiHznEaFgC > 0; lDCHbiHznEaFgC--) {
            gZQIRwyvQYvMuzgA += gZQIRwyvQYvMuzgA;
            nCilbIzsfRjDwI *= QZkqLGwIri;
            gZQIRwyvQYvMuzgA /= AHmdoOJdJWBR;
        }
    }

    for (int HpQXBrSmxAPfsyO = 330508691; HpQXBrSmxAPfsyO > 0; HpQXBrSmxAPfsyO--) {
        vIOcgKKPoKTAI /= QZkqLGwIri;
    }

    return false;
}

string yyzEkJOPMpPdTE::glkLM(int oNfdh, string CjVPxkxdggmPB, bool EHguV, int YjIvlHIcAMtavlp)
{
    double QGsfqygXKrdPIUq = 863481.9477707585;
    bool dOIkwSVUK = true;
    bool ymeprdyuXaVnn = true;
    string oNjafGyZ = string("SVouUhtzRuzziOxeECyKJjgOODeuMGbLSehgLcClumTUOKbmcCdbWgXecMlDgGtTLKnmiTcQdjrUPIavsKVpMHpyRY");
    double lZpyxuMNyk = -981145.2887839915;
    int UGOoQ = 791746041;
    int uqrCtXwNUGWBA = -417532373;
    int NxEPRIQgf = 1386987109;
    string ZSMgaEAeYC = string("qebiBqzlwBUMZzYJtYTShPBghXStZWUUbSxCQljtAZVkGVaIoJL");
    string SDbuTCCZwDTbRQj = string("eqOIWIGkyOpSNSkFAKGaZSKQbBpDdancDupAnMPecbxvWZAotrdKytZWcBoUDrtXezAMLETjEIddwkzOhqCvLIbiNvIlPjpQFsWRLSpCudEcrdNVyBzZwKvIYBgMdnKdQTmHRCODMjnIEVRaWRpSbbrFpTTIhnDJnDmsSXkzJptuwinWwUwsqWWxvGMXRMkKiyINfzKNoXLZRtfzBGdSyufuKyNmaQBDTkOQQWcAndpsbAKZcYLggWghUL");

    if (YjIvlHIcAMtavlp > 1386987109) {
        for (int hsgdRvYVC = 911695457; hsgdRvYVC > 0; hsgdRvYVC--) {
            continue;
        }
    }

    if (ymeprdyuXaVnn != false) {
        for (int hQzrBJnoBN = 378007509; hQzrBJnoBN > 0; hQzrBJnoBN--) {
            continue;
        }
    }

    if (UGOoQ != -417532373) {
        for (int rKvCZeOVsSQ = 629955215; rKvCZeOVsSQ > 0; rKvCZeOVsSQ--) {
            CjVPxkxdggmPB += oNjafGyZ;
            dOIkwSVUK = dOIkwSVUK;
        }
    }

    if (oNjafGyZ <= string("eqOIWIGkyOpSNSkFAKGaZSKQbBpDdancDupAnMPecbxvWZAotrdKytZWcBoUDrtXezAMLETjEIddwkzOhqCvLIbiNvIlPjpQFsWRLSpCudEcrdNVyBzZwKvIYBgMdnKdQTmHRCODMjnIEVRaWRpSbbrFpTTIhnDJnDmsSXkzJptuwinWwUwsqWWxvGMXRMkKiyINfzKNoXLZRtfzBGdSyufuKyNmaQBDTkOQQWcAndpsbAKZcYLggWghUL")) {
        for (int egnWvPvlanTkps = 1600181833; egnWvPvlanTkps > 0; egnWvPvlanTkps--) {
            CjVPxkxdggmPB += oNjafGyZ;
        }
    }

    for (int pCuzOpADx = 75443341; pCuzOpADx > 0; pCuzOpADx--) {
        lZpyxuMNyk /= QGsfqygXKrdPIUq;
    }

    return SDbuTCCZwDTbRQj;
}

bool yyzEkJOPMpPdTE::LqQCYU()
{
    int wrVdiFYixaJ = -471963506;
    bool sQiTQkPAeFLFVePA = true;
    string JWvpsmZWLtGIaxnI = string("MgHHvBBWDuYkthOXUwswohmnhfKRnlwHAQtWYnObpuVWWVLJyVfXgupViolYsbjaQwMTkPsxfayyoeEHcqEoASZndabayIFOZcrdijOoWpTqvJnbLFbWfrnedEyGKgawALmFRBx");
    double uURbhJSXbHdTL = 295834.16979348037;

    for (int KNuEUgNXdqwcn = 500502226; KNuEUgNXdqwcn > 0; KNuEUgNXdqwcn--) {
        JWvpsmZWLtGIaxnI = JWvpsmZWLtGIaxnI;
    }

    for (int spQlNefZyhNceRjW = 711620899; spQlNefZyhNceRjW > 0; spQlNefZyhNceRjW--) {
        JWvpsmZWLtGIaxnI = JWvpsmZWLtGIaxnI;
        uURbhJSXbHdTL *= uURbhJSXbHdTL;
    }

    return sQiTQkPAeFLFVePA;
}

double yyzEkJOPMpPdTE::bGJlEs(double WoGNpUspHwqBJB, bool CpsBFcbjcbvCA, string xOSooyW, int fGLkOmZeVXpUFbhC)
{
    double YwDRILAz = -203003.9884100714;
    string apBiKFYTqd = string("aXVTCBWTiaQFnWsnSXQuFcViWZLLrDkidyLwAaxcEuKYZXAUEAjiIRJetzfWQWKmZXGVAwxrOXcswcZZAWOCRS");
    bool BrrOasdWpBtQHaT = false;
    int pqIjrHgCKGPqX = -1450891425;
    bool tvgqWUU = false;

    for (int XQnHJvz = 1007548373; XQnHJvz > 0; XQnHJvz--) {
        continue;
    }

    return YwDRILAz;
}

bool yyzEkJOPMpPdTE::SSoOsdAm(string UbNazXWAyRA)
{
    int LgkbhSpBBBPA = -1288671618;
    string KHSFOX = string("iCeAPufosdXqIcatisddyOJTnhjCCaszZCbglnqmbfTHrSxnpwiVqZeOQnyNfZnzUQJqtzEZGIgFsTSOIergVfnavnaIhhZaflBpwWThcuQBYvzPfNPHGsjLqeWOvGXvenCFHumCudnmJAiCGWPYLSMhrdpxgQBqtzFriuQceKEQ");
    double CvARyTybemqp = -101165.07098729331;
    string CUAgFEikdbJnq = string("ormLqubTYTSVEzGaorIfiThnACjozquFTDTaLuHexTvozRcLioLHdPOMsMDzSIuLmPsJkbkPChhkYxjWYMNhpsQMHfRzprBmLrnaJHLoAgzIyoJHiemlcHMuslZUJImHjEa");
    int igcPLoRvqEuglTl = 1089187761;
    bool YQRwfeIkRbyA = false;

    for (int GqAkWRMGC = 67267380; GqAkWRMGC > 0; GqAkWRMGC--) {
        igcPLoRvqEuglTl /= igcPLoRvqEuglTl;
    }

    for (int psfHFjOJNDlmaeN = 1597745416; psfHFjOJNDlmaeN > 0; psfHFjOJNDlmaeN--) {
        igcPLoRvqEuglTl += LgkbhSpBBBPA;
    }

    for (int KZTngIuvL = 1939583499; KZTngIuvL > 0; KZTngIuvL--) {
        continue;
    }

    for (int AGWxbgrfBwANFgv = 825080044; AGWxbgrfBwANFgv > 0; AGWxbgrfBwANFgv--) {
        CUAgFEikdbJnq = KHSFOX;
    }

    if (KHSFOX == string("iCeAPufosdXqIcatisddyOJTnhjCCaszZCbglnqmbfTHrSxnpwiVqZeOQnyNfZnzUQJqtzEZGIgFsTSOIergVfnavnaIhhZaflBpwWThcuQBYvzPfNPHGsjLqeWOvGXvenCFHumCudnmJAiCGWPYLSMhrdpxgQBqtzFriuQceKEQ")) {
        for (int vJCywuGRgx = 446216238; vJCywuGRgx > 0; vJCywuGRgx--) {
            continue;
        }
    }

    return YQRwfeIkRbyA;
}

string yyzEkJOPMpPdTE::kCgYqBurCypjE(bool MBSoA, string uyddVyYAhgTMOI, int uDPKyEiytx, bool gfBKukpg, double LTYperKbtgk)
{
    bool jGSmkuCgRQGcW = false;
    double OhmTg = 436627.0895670384;
    int iDJJmPOHsUkr = -942375298;
    int IEsitdRMSWhKi = -283732459;
    string rJKFQ = string("MzIzBLRmzPARAwDikespcfuxtvpRoWSirMTLbHVBZkLeluFUxmoQbmOThDDKVSbgoHVsCHENVeuoJMNZqTewlGPRDYIPcScVKNvvtnWaBiYXBRQClQHRUmfkjnyDlWhJwkMzyvnwxjkqweOnDglvZNdySofEnJhJxehOlPCcsRXxDbMuEYPlDISZvWxCwQGZXfeILNsDejrFlZDSWCCYWcmqeOGrvEEdlKb");
    int EpAKhLJa = 952512264;
    double AJnrJa = 527274.6073013148;
    string XbkNxZ = string("NqGauSjCsFKuxImwkoMFuKhElHDKImsKIZYtXwCvMPAXNvHGdNvRsMKeogOtACbvFoCKOXRjCwvdgRQTPzHXyozMhYlsqmpluKyCQOgZNKbuOcZntVJBkBVFbsDkEXSDrGzywmCUVKiuJaOzvNGWWgnwOctLpqlZIvVTLwmXLd");

    for (int DfYcM = 573028857; DfYcM > 0; DfYcM--) {
        continue;
    }

    for (int tvdScpOku = 1853106306; tvdScpOku > 0; tvdScpOku--) {
        continue;
    }

    for (int ZKnDrgt = 27033811; ZKnDrgt > 0; ZKnDrgt--) {
        gfBKukpg = jGSmkuCgRQGcW;
    }

    if (XbkNxZ >= string("NqGauSjCsFKuxImwkoMFuKhElHDKImsKIZYtXwCvMPAXNvHGdNvRsMKeogOtACbvFoCKOXRjCwvdgRQTPzHXyozMhYlsqmpluKyCQOgZNKbuOcZntVJBkBVFbsDkEXSDrGzywmCUVKiuJaOzvNGWWgnwOctLpqlZIvVTLwmXLd")) {
        for (int NSctEsqjgadZj = 1857219227; NSctEsqjgadZj > 0; NSctEsqjgadZj--) {
            continue;
        }
    }

    if (jGSmkuCgRQGcW != true) {
        for (int bYxjBdw = 1009700093; bYxjBdw > 0; bYxjBdw--) {
            uyddVyYAhgTMOI += rJKFQ;
            AJnrJa += OhmTg;
            IEsitdRMSWhKi += EpAKhLJa;
        }
    }

    if (gfBKukpg == false) {
        for (int LGSjxzqdBaoJlq = 2147382346; LGSjxzqdBaoJlq > 0; LGSjxzqdBaoJlq--) {
            MBSoA = ! gfBKukpg;
        }
    }

    for (int kWIoTbVQn = 1065808060; kWIoTbVQn > 0; kWIoTbVQn--) {
        OhmTg *= AJnrJa;
    }

    return XbkNxZ;
}

yyzEkJOPMpPdTE::yyzEkJOPMpPdTE()
{
    this->COmqsGgPKgTXfRc(-1621492529, true, true);
    this->sBxJlwb(true, -691898.6432433552, -111315975);
    this->NeFXkzLaysNzCue();
    this->glkLM(-556256054, string("EkekgIYEtIGxiIBUMkXOOEUSDmHUxnzElwNQWhgAWzxaardUjeGSneLiZXiShSbsLchCwqhpfkVXusCnViobyUtIzBwoeOqJTSAbznUytPXDtUwoiuLa"), false, -2094552206);
    this->LqQCYU();
    this->bGJlEs(-769192.2822640549, false, string("frdzjePEL"), -505389459);
    this->SSoOsdAm(string("VJvYCJGNWumdeYmuvoSHEXNYuyaTpfVTbEWfBwlAjljtbpOszKXfZANBEmYJkxohaggJMiHpzXZRoNbZfMtMSPDfzNJzjGsNcMUKOHzcjFSzoyDquphsQFRDoxnGtvAiMcUQarJ"));
    this->kCgYqBurCypjE(true, string("zVeROfVvFOGjVovCZEIBUsMlMhoctUtcDEhamsHXZtyrWGFUTigHfUBawjpPXFTEMgtChEVuWjpVTQrYfvWndTAnNFkSRTqpeFVNzxGCLyPYpBMSZTXWkwanAMaXKZYCKMqBMvAeYBiwpWCowyKMRwbZrcSPPcscTJIuMkdBpEdLITfsiaDsZLbJTfERjFfPonvWOpXPbTRYGFdWNBSaEVekgZqphSUjhlvTtqPjGFgWzd"), 882996903, true, 44331.97047453954);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hHHBmON
{
public:
    string BQnTITPKlfegQAk;
    bool VfjCdCDOOuBFfeT;
    int rVyazQLqKdyeLG;
    bool NKKxQi;
    bool mMyuzewY;
    string WOgjxNKODQIDlmm;

    hHHBmON();
    bool gJiabrAMOYlAUfBp(double luycLylrLIRfIXP, bool TtqENwLubGwmyjj);
    bool TPqFUttvZLcRKcqS(double AnohZQiArKh, string olrmV, bool kQbEfLZEkOHpnvl);
    void CJHRwZSZHBMjixs(double gFFqljGLWw, double mRuiQWsMfX, string EkrPFGGX, int BFbOBmXh);
    double QIYvyeEL();
    void KOAulzrRFhIDqZ(int OSsDoeTFKoaI, double wAkhHiNab, double RTEfBrMOlUGRHboc, int UlRSjZzyRRl, int HXIJFZlX);
    string okpvErQVvne();
    string POpHQPzXauQsjlD();
    string CxmYWMPrm(bool FpEjbBwRbEcBqq);
protected:
    string kQouSKyBiaWnufKY;
    bool FZwes;
    string AySvEbRxgLS;
    string djuQsDVYzkf;
    double oNuXk;

    double UeopKdvmq();
    string JsxyWnzCpnQ(string tHltBehZqYzFAHWg, double VwYnlAOo, int jWwuMo, string uilCOG);
    int JApDolKmqECKgMBb(int XmbrEwkPuOZiOOd, int XCWXRGaXNWkUTd);
private:
    string zRQWBTZoyqmLg;
    bool gNZrSCEVO;
    double VCuNfMH;
    string yTtkLep;
    string mvyChDvLdkiIAFp;

    string UOfjwOxYsnSWP(double EVQfGkBqnDIsg, bool ERfebWkPbMdtT, bool mlmSyj, bool AdpkCFsn);
    string GWLYeRtZt();
};

bool hHHBmON::gJiabrAMOYlAUfBp(double luycLylrLIRfIXP, bool TtqENwLubGwmyjj)
{
    double TTItfF = 974102.5471257672;
    double JiRsUZFG = 412159.1196817319;
    string zwaHq = string("xakkeJFdGlXqHecMrOQYlSRHisVccKLfeWKPLuQnkjKXzOfgPSyNFbguRzDlzSheYmxtLLfgWsDcGzepbUnfCDaSJqKEApWwABXxXhGtzpqyrQrcNmFZEoGwbvrlRhwlkouXUospvmrmLFGHTkelWITUygopXnhrXvNnaqmsjRWwvtMrLHLbVxbmzGoXqGedfqeeCukbIHibAikFGqXVyzpxsKXrAfTREUVTPhLEnkcZRPlgY");
    double QtjtOznHkam = 360680.91938190215;
    int abKGscygxXi = -1975931475;

    if (abKGscygxXi >= -1975931475) {
        for (int EYgQnhkjOOUht = 1800190007; EYgQnhkjOOUht > 0; EYgQnhkjOOUht--) {
            luycLylrLIRfIXP = QtjtOznHkam;
            TTItfF /= luycLylrLIRfIXP;
            luycLylrLIRfIXP *= luycLylrLIRfIXP;
            JiRsUZFG -= luycLylrLIRfIXP;
        }
    }

    for (int xvLbwiVJU = 1055471815; xvLbwiVJU > 0; xvLbwiVJU--) {
        continue;
    }

    if (luycLylrLIRfIXP != 341470.444961268) {
        for (int CNHzsHXoHTKG = 249913354; CNHzsHXoHTKG > 0; CNHzsHXoHTKG--) {
            luycLylrLIRfIXP -= luycLylrLIRfIXP;
            TTItfF += TTItfF;
            TTItfF = TTItfF;
            luycLylrLIRfIXP -= luycLylrLIRfIXP;
        }
    }

    for (int KgJtoVQBix = 573831479; KgJtoVQBix > 0; KgJtoVQBix--) {
        TTItfF = TTItfF;
        JiRsUZFG += QtjtOznHkam;
    }

    if (TtqENwLubGwmyjj == true) {
        for (int wtUJQclxrtq = 1085697785; wtUJQclxrtq > 0; wtUJQclxrtq--) {
            TtqENwLubGwmyjj = ! TtqENwLubGwmyjj;
            zwaHq = zwaHq;
            TTItfF *= luycLylrLIRfIXP;
            TtqENwLubGwmyjj = ! TtqENwLubGwmyjj;
            TTItfF /= TTItfF;
        }
    }

    for (int itnrKDo = 42171054; itnrKDo > 0; itnrKDo--) {
        QtjtOznHkam -= JiRsUZFG;
        TTItfF = JiRsUZFG;
    }

    if (zwaHq <= string("xakkeJFdGlXqHecMrOQYlSRHisVccKLfeWKPLuQnkjKXzOfgPSyNFbguRzDlzSheYmxtLLfgWsDcGzepbUnfCDaSJqKEApWwABXxXhGtzpqyrQrcNmFZEoGwbvrlRhwlkouXUospvmrmLFGHTkelWITUygopXnhrXvNnaqmsjRWwvtMrLHLbVxbmzGoXqGedfqeeCukbIHibAikFGqXVyzpxsKXrAfTREUVTPhLEnkcZRPlgY")) {
        for (int mCrYyBtEe = 639134305; mCrYyBtEe > 0; mCrYyBtEe--) {
            QtjtOznHkam -= luycLylrLIRfIXP;
            QtjtOznHkam -= QtjtOznHkam;
            luycLylrLIRfIXP /= luycLylrLIRfIXP;
        }
    }

    return TtqENwLubGwmyjj;
}

bool hHHBmON::TPqFUttvZLcRKcqS(double AnohZQiArKh, string olrmV, bool kQbEfLZEkOHpnvl)
{
    string kibnIgocbkqA = string("eNEdstWUAIMOyaJIDQznURzFltaDfEYUNjIVKemGxpldZPcOAPOvWzrJfRfGiIgnycxcNwsavjgEvqRwFOxJlMsMqWjZDYlefXQopllrmfzAgzfnMxdwWYjynkgFzulyoGhxCzfGbNRTnORKJjnoXBasKAvpdJXrHMfDNpJJKIfIeiwLMFGxLJtVeHMeEHvrUUowcmliJsHaUosHcZRqBg");
    double OCpqJdUjTNTV = -781811.9096994237;
    int XEdPdWBZxAHNBxz = 535769057;
    string NIlAQbJ = string("jzLuiasXNkgnURMtLnIGzVCYoftkpwqUudekUcKhUPOgSGAKZgUlvNNgoRKFmbkWguxzITglonnHekMENxFPJVvWKgIgMbUjVGkdYMowkrFzuBCjCJVFJJebtujkbIfqLbmQ");
    double fTjrMToOO = -506371.6196792318;
    double gPUDAoBaGGL = -118555.6320158404;

    for (int aVFKXLEY = 2111666226; aVFKXLEY > 0; aVFKXLEY--) {
        AnohZQiArKh = OCpqJdUjTNTV;
    }

    for (int ZkUANUrOLuVzLKr = 490491611; ZkUANUrOLuVzLKr > 0; ZkUANUrOLuVzLKr--) {
        XEdPdWBZxAHNBxz += XEdPdWBZxAHNBxz;
        olrmV += kibnIgocbkqA;
    }

    return kQbEfLZEkOHpnvl;
}

void hHHBmON::CJHRwZSZHBMjixs(double gFFqljGLWw, double mRuiQWsMfX, string EkrPFGGX, int BFbOBmXh)
{
    double FNRsTYXpskS = -207608.0741722529;
    string SkVQxEWJipX = string("MdiQSDENguBYKejLeEldMUvwFndvdnBbjplTBplwpUauptdXBpQ");
    double JMILRcQTkVIktjfo = 1007461.7279613166;
    int DHPckZYJmwO = 1882907515;

    if (JMILRcQTkVIktjfo <= -207608.0741722529) {
        for (int pVSwJKjWOaAhD = 1408269489; pVSwJKjWOaAhD > 0; pVSwJKjWOaAhD--) {
            gFFqljGLWw *= gFFqljGLWw;
            JMILRcQTkVIktjfo += JMILRcQTkVIktjfo;
            FNRsTYXpskS += gFFqljGLWw;
        }
    }

    for (int gluPItCmY = 704323489; gluPItCmY > 0; gluPItCmY--) {
        continue;
    }
}

double hHHBmON::QIYvyeEL()
{
    string xBadhNJB = string("pZDivhlYjXyzEzuKDHmyoMMGXiaQbMkY");
    bool mwlSYNl = true;
    bool yiAHVDbcYfPTSdW = true;
    bool tgMBgRAoDqAQ = true;
    int BdfZIAv = -1585832288;
    bool FjLKNqzzR = true;

    if (FjLKNqzzR == true) {
        for (int vNKPY = 365863291; vNKPY > 0; vNKPY--) {
            yiAHVDbcYfPTSdW = ! FjLKNqzzR;
            FjLKNqzzR = ! mwlSYNl;
            mwlSYNl = ! FjLKNqzzR;
            tgMBgRAoDqAQ = ! tgMBgRAoDqAQ;
        }
    }

    for (int cvzJYuRWUFhKYUtb = 1037552903; cvzJYuRWUFhKYUtb > 0; cvzJYuRWUFhKYUtb--) {
        xBadhNJB += xBadhNJB;
        tgMBgRAoDqAQ = ! yiAHVDbcYfPTSdW;
    }

    if (BdfZIAv < -1585832288) {
        for (int bIpqxJHRtB = 1330543259; bIpqxJHRtB > 0; bIpqxJHRtB--) {
            tgMBgRAoDqAQ = ! yiAHVDbcYfPTSdW;
            mwlSYNl = tgMBgRAoDqAQ;
            yiAHVDbcYfPTSdW = ! yiAHVDbcYfPTSdW;
            yiAHVDbcYfPTSdW = ! FjLKNqzzR;
            tgMBgRAoDqAQ = FjLKNqzzR;
            mwlSYNl = ! FjLKNqzzR;
        }
    }

    for (int egVDbsJQVbNdl = 413745905; egVDbsJQVbNdl > 0; egVDbsJQVbNdl--) {
        xBadhNJB += xBadhNJB;
        yiAHVDbcYfPTSdW = ! tgMBgRAoDqAQ;
    }

    return -509621.32898948283;
}

void hHHBmON::KOAulzrRFhIDqZ(int OSsDoeTFKoaI, double wAkhHiNab, double RTEfBrMOlUGRHboc, int UlRSjZzyRRl, int HXIJFZlX)
{
    double eXbbLWhCDtQ = -357571.5436166681;

    for (int jUZAwXoprGfWzcdH = 1066474206; jUZAwXoprGfWzcdH > 0; jUZAwXoprGfWzcdH--) {
        OSsDoeTFKoaI += UlRSjZzyRRl;
    }
}

string hHHBmON::okpvErQVvne()
{
    bool QsLCZsIiYmXRh = true;
    bool JrKAPUkVweA = false;
    double lgXsDAXpnkRK = -1022451.1711033054;
    double YORMsvanBCsMcm = 183270.3579430075;
    double ngSBRNNAJvMbD = 518239.14693574473;
    int xBfdg = 1131633756;
    double acVqiJGqtI = -684454.8373663899;
    int WvMIouFgeUbVd = 1736081434;
    double EIdqvs = -453070.8265319109;
    int BLVfnlanrBuMz = 1916417033;

    if (ngSBRNNAJvMbD != -684454.8373663899) {
        for (int kEIFkslpgyzFvC = 2051143657; kEIFkslpgyzFvC > 0; kEIFkslpgyzFvC--) {
            continue;
        }
    }

    if (JrKAPUkVweA == false) {
        for (int GbPLRzZiWmFbNn = 922480532; GbPLRzZiWmFbNn > 0; GbPLRzZiWmFbNn--) {
            continue;
        }
    }

    for (int neZUBoOdCKoaf = 1665687752; neZUBoOdCKoaf > 0; neZUBoOdCKoaf--) {
        xBfdg += xBfdg;
    }

    for (int xdJmFxKIsmCGxXdB = 126977227; xdJmFxKIsmCGxXdB > 0; xdJmFxKIsmCGxXdB--) {
        YORMsvanBCsMcm = lgXsDAXpnkRK;
    }

    for (int JOQnQcBquXuksTRF = 1699203093; JOQnQcBquXuksTRF > 0; JOQnQcBquXuksTRF--) {
        WvMIouFgeUbVd *= xBfdg;
        YORMsvanBCsMcm = ngSBRNNAJvMbD;
    }

    return string("enxBrmfscvStCJgJXDudqImeJOUIWWbOhfSRVXthAYmRipeKfMQmbzcrKVuqGirdCGhyVxhQCqUFMEqWolNBBOikqIaJQLzaqwrHCFHTJHtXdhioMQUdHDPpRdVpETCemWLglBgbZuIXmYIsYFvDXXNyhmLhoIpuPpuBUufdMsRTbPLPelPvtCJpQZHNYKuGIinsfwqKnGNkjbZDvkMsIjLBCXQb");
}

string hHHBmON::POpHQPzXauQsjlD()
{
    double GWfgjCsKYNgQ = 57348.57025626344;
    double rZumQuBQfXqvMSDD = -820843.1713494118;

    return string("qvJHQsswXqOawllpAFmgKgJnVYcXEctcraTNjeueeaCbLfDmEdtbH");
}

string hHHBmON::CxmYWMPrm(bool FpEjbBwRbEcBqq)
{
    double dtKeMR = -254809.5811718199;
    bool TPyBwEnMWyD = true;

    for (int ScIhbEKc = 1678275491; ScIhbEKc > 0; ScIhbEKc--) {
        FpEjbBwRbEcBqq = ! FpEjbBwRbEcBqq;
        FpEjbBwRbEcBqq = TPyBwEnMWyD;
        dtKeMR += dtKeMR;
    }

    return string("qDRFlJMoqFQRTjEMEbZztzdnTzhsPuREumXILCKpAgCnDrSIyHDLZWiMlcQtETrdtQcuVrbSzEhMMFAScjuMMZxoHykSExxiESZ");
}

double hHHBmON::UeopKdvmq()
{
    int ZVbAkxH = -1715602754;

    if (ZVbAkxH != -1715602754) {
        for (int XoCMemIZwcOlzjZK = 884841451; XoCMemIZwcOlzjZK > 0; XoCMemIZwcOlzjZK--) {
            ZVbAkxH /= ZVbAkxH;
            ZVbAkxH *= ZVbAkxH;
            ZVbAkxH += ZVbAkxH;
            ZVbAkxH *= ZVbAkxH;
            ZVbAkxH *= ZVbAkxH;
            ZVbAkxH -= ZVbAkxH;
            ZVbAkxH += ZVbAkxH;
        }
    }

    if (ZVbAkxH >= -1715602754) {
        for (int XtQjCPfLOR = 1479852259; XtQjCPfLOR > 0; XtQjCPfLOR--) {
            ZVbAkxH -= ZVbAkxH;
            ZVbAkxH *= ZVbAkxH;
            ZVbAkxH *= ZVbAkxH;
            ZVbAkxH += ZVbAkxH;
            ZVbAkxH -= ZVbAkxH;
        }
    }

    if (ZVbAkxH <= -1715602754) {
        for (int ABwmQ = 291968169; ABwmQ > 0; ABwmQ--) {
            ZVbAkxH -= ZVbAkxH;
            ZVbAkxH *= ZVbAkxH;
            ZVbAkxH -= ZVbAkxH;
            ZVbAkxH *= ZVbAkxH;
        }
    }

    return -838063.5800411201;
}

string hHHBmON::JsxyWnzCpnQ(string tHltBehZqYzFAHWg, double VwYnlAOo, int jWwuMo, string uilCOG)
{
    bool KJHehWLvBYvGFBbN = false;
    double OquImEZLhRIHUm = -45136.52637068646;
    bool PJYJhXtgcXCVNv = true;
    double mKEHG = -294154.0090999732;
    string OidPffH = string("kkTpkpCAdFoTDjwzBgiXLyxeLrCKNIuzFSgEGrrdzrgqdpCFGenmGBceszdFJbDwObhvDCifnjkCTuyJznLZyZ");
    string euUvJlwLRVDUZqos = string("SEbpfeHVnNvJTuSaMTHbuyYPpMMaAhwCwGicpphxsIbkihjyXDDkEhgPEAeUzcjTCkwTBOHCYAdzPxRXcnmghjmtkTgtHrrrpjKedxeRvsOcVOUrzRMdrGbjUZQyadaSQNTsfLMuxdrmokablEJzpwDkLhcHhZJfThDxbXLeyQXwABMsgUcleVUnLBZlwakwmMmxOfbAsAALVBonfQaOrNLubl");
    int FQcgl = -1990763197;
    int IuYPorUFHoMAtfh = -1304403854;

    if (tHltBehZqYzFAHWg == string("SEbpfeHVnNvJTuSaMTHbuyYPpMMaAhwCwGicpphxsIbkihjyXDDkEhgPEAeUzcjTCkwTBOHCYAdzPxRXcnmghjmtkTgtHrrrpjKedxeRvsOcVOUrzRMdrGbjUZQyadaSQNTsfLMuxdrmokablEJzpwDkLhcHhZJfThDxbXLeyQXwABMsgUcleVUnLBZlwakwmMmxOfbAsAALVBonfQaOrNLubl")) {
        for (int obsjeE = 1140366267; obsjeE > 0; obsjeE--) {
            KJHehWLvBYvGFBbN = PJYJhXtgcXCVNv;
            uilCOG += tHltBehZqYzFAHWg;
            FQcgl += jWwuMo;
            mKEHG = VwYnlAOo;
        }
    }

    for (int OjYGcUtOp = 1826066695; OjYGcUtOp > 0; OjYGcUtOp--) {
        continue;
    }

    for (int uFkXp = 1228666419; uFkXp > 0; uFkXp--) {
        euUvJlwLRVDUZqos = uilCOG;
        IuYPorUFHoMAtfh *= jWwuMo;
        OidPffH = uilCOG;
        VwYnlAOo = OquImEZLhRIHUm;
    }

    return euUvJlwLRVDUZqos;
}

int hHHBmON::JApDolKmqECKgMBb(int XmbrEwkPuOZiOOd, int XCWXRGaXNWkUTd)
{
    string YNBnCnbrJtCmn = string("YqIaynsseYCTmgJjwZtRXsUdUVrGuhNaxKguQggKUmppeyQakfyMRUPhKFRRSXVIlezKrmoQWBzPnLjMvHbCYFtWFuePsZWLQkuvURxEqniytciqMWELLWqcVVdUHpjqNDfcOsdIghpuVERpPioBOHNfTaswaLeoEWpHlIBAeyyfYmLpOXqkyEeLRlnLDeFPoFIyMPP");
    int ehtmdMiGEI = 1964244273;
    double JOlDxZrnP = -185433.32910620043;
    bool UOOyAM = false;
    string iPycWCoyWBFHGqGu = string("GCmFGXJOrsKHvRWPWGCNyecpXLyZJHzhBPBsypzImRgBANjAdmPEGHiggYEjPBpSIFLYWScOEMlRjfCZGymfBThgLaYVjUmnaLUDtsRWDloWVUCpYLWAPNBTLldcgInouBgGGtRAtRveBNbDurexjtFSvaxROHbxgkPbMKPqRkXZuqQAwomwxdNWOxhXnwdiFTCw");

    for (int fgHAiNsm = 508909052; fgHAiNsm > 0; fgHAiNsm--) {
        continue;
    }

    return ehtmdMiGEI;
}

string hHHBmON::UOfjwOxYsnSWP(double EVQfGkBqnDIsg, bool ERfebWkPbMdtT, bool mlmSyj, bool AdpkCFsn)
{
    bool akKRFflFzGv = false;
    int konvziuciQjJd = 2107167281;
    double xYIDaTI = 460639.4028423361;
    int ByQZHgYBbUEdix = 1046202745;
    string CMjsnhUWw = string("qOZkqxBBANdAebFHwfyZrjYamLtOMzOauWOBEuJUQWkIrTTNRElsxxqrkfnAHdgNWyVloApbOpHEIcUUnvMDhzXlRArDtZwraEsVKQQJOKyjUGIfgigXLqwfPLvnUEqbGTsELXGbTLMnCiWpEAoyFSHkJOdtCCowIVZNqabvFuDXsDMVbRVnYeKUJQcMPqBZyBezQPCkWqJYjomuhkpaHTytaMzQQEFlGaqOiQzxCwHkkseefQVj");
    bool EDhVZeKfwtiUNn = true;
    int uriPxUxPIOohPa = 877927555;
    double pswgw = -815544.6591471903;

    for (int axxqWOQmddnnZV = 875604468; axxqWOQmddnnZV > 0; axxqWOQmddnnZV--) {
        AdpkCFsn = ! AdpkCFsn;
        EDhVZeKfwtiUNn = ! ERfebWkPbMdtT;
        AdpkCFsn = akKRFflFzGv;
    }

    if (uriPxUxPIOohPa == 2107167281) {
        for (int tIIPVBAnAZEum = 409609785; tIIPVBAnAZEum > 0; tIIPVBAnAZEum--) {
            pswgw -= EVQfGkBqnDIsg;
        }
    }

    return CMjsnhUWw;
}

string hHHBmON::GWLYeRtZt()
{
    double PbPCbWEASOHnbmFH = -219925.8362873177;
    bool SrjLYfrPRtD = false;
    bool AskQuEUKqoBirIsl = false;
    string dmxSrDBdHdBOLhd = string("SNFBNCEnrXKYpbQkSiiJSNmRicCsLjKQomEiKKLlCrZIpSomNHswypCkDJBjNqNxDKrInPjTokkCcrbMUxruEYllnPsPNVsEhaPg");

    for (int etfWqCiHtH = 1688338026; etfWqCiHtH > 0; etfWqCiHtH--) {
        SrjLYfrPRtD = ! AskQuEUKqoBirIsl;
        SrjLYfrPRtD = AskQuEUKqoBirIsl;
    }

    return dmxSrDBdHdBOLhd;
}

hHHBmON::hHHBmON()
{
    this->gJiabrAMOYlAUfBp(341470.444961268, true);
    this->TPqFUttvZLcRKcqS(-875297.4766061214, string("GMkppBenDCBKRGKHoTXamahcWWhZekTZNrdXhtfmdRMouFfOsobAzxuyTrOyqWryTmNRPXzFSHNWbRKcZwaHWJLTQuoqQpbtblFDUQOPoYCtWBumyEPSGLeJXwsDdcDDrnXDmKJTynDZhtZHeYKOHLCaGWfpOhbcDuEMcd"), true);
    this->CJHRwZSZHBMjixs(880803.6829828394, -986987.5765843343, string("HsVlPgEVUpbjeuwcBbGciqHYGGbvsRpEAaxBePSEhdkCeIOFXxZUvLHMYGmkxNClKpoEPeamcORhyvRRacmeiqDWBpRKGSpaoFh"), 855455843);
    this->QIYvyeEL();
    this->KOAulzrRFhIDqZ(-103850315, -750880.3782899722, -551133.3479222256, 44342547, 1187773335);
    this->okpvErQVvne();
    this->POpHQPzXauQsjlD();
    this->CxmYWMPrm(true);
    this->UeopKdvmq();
    this->JsxyWnzCpnQ(string("zEJIqqoRwnOTtTnPHamHLJjPHWTMCLTqgpeQDmlWGCPnfPBctegsshOFiqbCpCDoAsapFoHXEtnWhGdmOdTJmymifSmxTRnDEVtMAHNsMdhjUaaMFEaSLuxWWOwUkWNpwAbrxTiEkygCTyxqWRIASPfniSxDtrPqaPDvoEyFDQTlLRcfQFtWQGZmWXzCfaAdIvJwqXIZlHvkONcIxgbWpibrJoTwJWLUgEQqVyFJADdow"), 428994.9618579727, 1243110851, string("CztuvrAGhdkYpduIDZVPbCJflQgNVFsfqquhuoPMTpJoSWcduLwCRDUVvZLOuPZIhzXsUPHFjwSYBFOqsIHDwjccGuCdpZOYmetHUACbid"));
    this->JApDolKmqECKgMBb(1195796799, -1698640269);
    this->UOfjwOxYsnSWP(569119.4275667728, true, true, true);
    this->GWLYeRtZt();
}
