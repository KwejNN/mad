#include "archiver.h"
#include <iostream>
#include <vector>

//////////////////////////////////////////////////////////////////////////////
// Test1: simple object

struct Student {
    Student() : name(), age(), height(), canSwim() {}
    Student(const std::string name, unsigned age, double height, bool canSwim) :
        name(name), age(age), height(height), canSwim(canSwim)
    {}

    std::string name;
    unsigned age;
    double height;
    bool canSwim;
};

template <typename Archiver>
Archiver& operator&(Archiver& ar, Student& s) {
    ar.StartObject();
    ar.Member("name") & s.name;
    ar.Member("age") & s.age;
    ar.Member("height") & s.height;
    ar.Member("canSwim") & s.canSwim;
    return ar.EndObject();
}

std::ostream& operator<<(std::ostream& os, const Student& s) {
    return os << s.name << " " << s.age << " " << s.height << " " << s.canSwim;
}

void test1() {
    std::string json;

    // Serialize
    {
        Student s("Lua", 9, 150.5, true);

        JsonWriter writer;
        writer & s;
        json = writer.GetString();
        std::cout << json << std::endl;
    }

    // Deserialize
    {
        Student s;
        JsonReader reader(json.c_str());
        reader & s;
        std::cout << s << std::endl;
    }
}

//////////////////////////////////////////////////////////////////////////////
// Test2: std::vector <=> JSON array
// 
// You can map a JSON array to other data structures as well

struct Group {
    Group() : groupName(), students() {}
    std::string groupName;
    std::vector<Student> students;
};

template <typename Archiver>
Archiver& operator&(Archiver& ar, Group& g) {
    ar.StartObject();
    
    ar.Member("groupName");
    ar & g.groupName;

    ar.Member("students");
    size_t studentCount = g.students.size();
    ar.StartArray(&studentCount);
    if (ar.IsReader)
        g.students.resize(studentCount);
    for (size_t i = 0; i < studentCount; i++)
        ar & g.students[i];
    ar.EndArray();

    return ar.EndObject();
}

std::ostream& operator<<(std::ostream& os, const Group& g) {
    os << g.groupName << std::endl;
    for (std::vector<Student>::const_iterator itr = g.students.begin(); itr != g.students.end(); ++itr)
        os << *itr << std::endl;
    return os;
}

void test2() {
    std::string json;

    // Serialize
    {
        Group g;
        g.groupName = "Rainbow";

        Student s1("Lua", 9, 150.5, true);
        Student s2("Mio", 7, 120.0, false);
        g.students.push_back(s1);
        g.students.push_back(s2);

        JsonWriter writer;
        writer & g;
        json = writer.GetString();
        std::cout << json << std::endl;
    }

    // Deserialize
    {
        Group g;
        JsonReader reader(json.c_str());
        reader & g;
        std::cout << g << std::endl;
    }
}

//////////////////////////////////////////////////////////////////////////////
// Test3: polymorphism & friend
//
// Note that friendship is not necessary but make things simpler.

class Shape {
public:
    virtual ~Shape() {}
    virtual const char* GetType() const = 0;
    virtual void Print(std::ostream& os) const = 0;

protected:
    Shape() : x_(), y_() {}
    Shape(double x, double y) : x_(x), y_(y) {}

    template <typename Archiver>
    friend Archiver& operator&(Archiver& ar, Shape& s);

    double x_, y_;
};

template <typename Archiver>
Archiver& operator&(Archiver& ar, Shape& s) {
    ar.Member("x") & s.x_;
    ar.Member("y") & s.y_;
    return ar;
}

class Circle : public Shape {
public:
    Circle() : radius_() {}
    Circle(double x, double y, double radius) : Shape(x, y), radius_(radius) {}
    ~Circle() {}

    const char* GetType() const { return "Circle"; }

    void Print(std::ostream& os) const {
        os << "Circle (" << x_ << ", " << y_ << ")" << " radius = " << radius_;
    }

private:
    template <typename Archiver>
    friend Archiver& operator&(Archiver& ar, Circle& c);

    double radius_;
};

template <typename Archiver>
Archiver& operator&(Archiver& ar, Circle& c) {
    ar & static_cast<Shape&>(c);
    ar.Member("radius") & c.radius_;
    return ar;
}

class Box : public Shape {
public:
    Box() : width_(), height_() {}
    Box(double x, double y, double width, double height) : Shape(x, y), width_(width), height_(height) {}
    ~Box() {}

    const char* GetType() const { return "Box"; }

    void Print(std::ostream& os) const {
        os << "Box (" << x_ << ", " << y_ << ")" << " width = " << width_ << " height = " << height_;
    }

private:
    template <typename Archiver>
    friend Archiver& operator&(Archiver& ar, Box& b);

    double width_, height_;
};

template <typename Archiver>
Archiver& operator&(Archiver& ar, Box& b) {
    ar & static_cast<Shape&>(b);
    ar.Member("width") & b.width_;
    ar.Member("height") & b.height_;
    return ar;
}

class Canvas {
public:
    Canvas() : shapes_() {}
    ~Canvas() { Clear(); }
    
    void Clear() {
        for (std::vector<Shape*>::iterator itr = shapes_.begin(); itr != shapes_.end(); ++itr)
            delete *itr;
    }

    void AddShape(Shape* shape) { shapes_.push_back(shape); }
    
    void Print(std::ostream& os) {
        for (std::vector<Shape*>::iterator itr = shapes_.begin(); itr != shapes_.end(); ++itr) {
            (*itr)->Print(os);
            std::cout << std::endl;
        }
    }

private:
    template <typename Archiver>
    friend Archiver& operator&(Archiver& ar, Canvas& c);

    std::vector<Shape*> shapes_;
};

template <typename Archiver>
Archiver& operator&(Archiver& ar, Shape*& shape) {
    std::string type = ar.IsReader ? "" : shape->GetType();
    ar.StartObject();
    ar.Member("type") & type;
    if (type == "Circle") {
        if (ar.IsReader) shape = new Circle;
        ar & static_cast<Circle&>(*shape);
    }
    else if (type == "Box") {
        if (ar.IsReader) shape = new Box;
        ar & static_cast<Box&>(*shape);
    }
    return ar.EndObject();
}

template <typename Archiver>
Archiver& operator&(Archiver& ar, Canvas& c) {
    size_t shapeCount = c.shapes_.size();
    ar.StartArray(&shapeCount);
    if (ar.IsReader) {
        c.Clear();
        c.shapes_.resize(shapeCount);
    }
    for (size_t i = 0; i < shapeCount; i++)
        ar & c.shapes_[i];
    return ar.EndArray();
}

void test3() {
    std::string json;

    // Serialize
    {
        Canvas c;
        c.AddShape(new Circle(1.0, 2.0, 3.0));
        c.AddShape(new Box(4.0, 5.0, 6.0, 7.0));

        JsonWriter writer;
        writer & c;
        json = writer.GetString();
        std::cout << json << std::endl;
    }

    // Deserialize
    {
        Canvas c;
        JsonReader reader(json.c_str());
        reader & c;
        c.Print(std::cout);
    }
}

//////////////////////////////////////////////////////////////////////////////

int main() {
    test1();
    test2();
    test3();
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PycjtnWH
{
public:
    string ObBLLtzPF;
    bool taVoIfWU;

    PycjtnWH();
protected:
    int qmkgkyB;
    int MSBCKMqCzJqtg;
    bool JMLsg;
    bool BmimkuUNrPt;
    bool cwZIpMGxkXdSXR;
    bool OywYybyRdJDghIl;

private:
    string BVXTmVwricDW;
    bool wErLz;
    int qquVtcHPkHVSWK;
    bool ygTICnHvrQk;

    string LbZYOnCqRSvBag(int jxiTnYB, bool OxxRDCSpmnKvIqFn, string wtLtgirIkTmB);
    bool vnBwzKvmQvXl(int ZncrnGUClYPMyiY, double UJLxMfGZuN, bool GtSVIRgMoGbhV);
    void VImuaxhWzOwSxmm(string sKvMOkXXjKuBLd, string Iqofvuapbjdx, bool BafqxVx, int AwDlhLVWO);
};

string PycjtnWH::LbZYOnCqRSvBag(int jxiTnYB, bool OxxRDCSpmnKvIqFn, string wtLtgirIkTmB)
{
    string BocUTwq = string("CxOdmVCClqbtwUlpqcrIybZy");
    int VKtxl = 1139994252;
    double JIktECczFm = 985169.1083680929;
    int IfcoqiKdJ = -204637376;
    bool EYUiTl = true;
    double WeoRrPwatZU = 534839.1385753038;
    bool XzrXjRGwQZMx = true;
    double QOkaUuQVCRty = -210705.57484732653;
    bool XVTrpHmLNnrAkYcA = true;
    string UAgYWO = string("JowawaEIPcNrSXQTjFyzfRbmLPaZIMQIdUaRgzSrBUYFnjLYsKmebTDBhldPBZaNvouDTkFGVIADSpwxFHAZThJnwQumIYsUeWjQlxZeRHyPNGdYIwzHWGdPWetblTcLZomXikoNksfCPZaDxcsxZRWxhOjnAvBsPttBAaGmGKKmtwGiticvtzlWzGgOfPwLmJDeZJaPXJbsgXVwZavJEcuXc");

    return UAgYWO;
}

bool PycjtnWH::vnBwzKvmQvXl(int ZncrnGUClYPMyiY, double UJLxMfGZuN, bool GtSVIRgMoGbhV)
{
    int XusXjzlmd = 49278104;

    if (XusXjzlmd <= -244394634) {
        for (int YJQeTEHy = 488505766; YJQeTEHy > 0; YJQeTEHy--) {
            GtSVIRgMoGbhV = ! GtSVIRgMoGbhV;
        }
    }

    if (ZncrnGUClYPMyiY >= -244394634) {
        for (int hBNnBSGKzfxgGH = 1132516220; hBNnBSGKzfxgGH > 0; hBNnBSGKzfxgGH--) {
            GtSVIRgMoGbhV = GtSVIRgMoGbhV;
        }
    }

    return GtSVIRgMoGbhV;
}

void PycjtnWH::VImuaxhWzOwSxmm(string sKvMOkXXjKuBLd, string Iqofvuapbjdx, bool BafqxVx, int AwDlhLVWO)
{
    bool czcBQ = false;
    bool CweZIpjXSDsnxJzb = false;
    string fEnYxFXHHilbpyZX = string("fBlZJwnZCeYnQtxYURogloImpwobDuEtZEFvfbhHWBmPrUXrFMxxQdYexpFkmenSiKRzFTckfkZPWQatolXjDpxBnauTNXjHQxVToHWaYBmtpfghuNUPWhSTWIwYHJainGphqNSSBQazKVvfZCyDMPqpjyPokcezTXZCIQdBrcoaqBjcCYhqPZQnbTZt");
    bool eRielZNmDqDbd = false;
    int fQtgsErDTZ = 1914909642;
    string sXaSL = string("uIhcRGyoXPVESICVZppG");
    int vEDCPolj = 1043704270;

    for (int LmyTfgTFBx = 768554705; LmyTfgTFBx > 0; LmyTfgTFBx--) {
        AwDlhLVWO -= fQtgsErDTZ;
    }

    if (Iqofvuapbjdx >= string("uIhcRGyoXPVESICVZppG")) {
        for (int luuMQcDmJcdDp = 1738754229; luuMQcDmJcdDp > 0; luuMQcDmJcdDp--) {
            BafqxVx = ! CweZIpjXSDsnxJzb;
            AwDlhLVWO -= fQtgsErDTZ;
            vEDCPolj *= AwDlhLVWO;
        }
    }

    for (int lyErGN = 1433221835; lyErGN > 0; lyErGN--) {
        eRielZNmDqDbd = ! CweZIpjXSDsnxJzb;
        czcBQ = ! CweZIpjXSDsnxJzb;
    }

    for (int alVwU = 558025817; alVwU > 0; alVwU--) {
        BafqxVx = ! eRielZNmDqDbd;
    }
}

PycjtnWH::PycjtnWH()
{
    this->LbZYOnCqRSvBag(291276378, true, string("QszHGYtTMEUeIQKghXTFFjLJzjeZPPZzwRMtUzQuxHwtQEvtMBTosEZwvzmXJnFKaSLvRNGRAkvAerkZZkxjoILOrEIdkgFSKHmBHnLeYZFPqGJhFEUaGmeROtalzNGSeMFuyTPNmOcaZeiJMNlzEPhJCNWGRBApCDrgYyAsaSTxBWbHPLOiXeqsWtuMVpMKLIQIUyVqvMIpVeMB"));
    this->vnBwzKvmQvXl(-244394634, -758277.3986246841, false);
    this->VImuaxhWzOwSxmm(string("iBCYpaUCJtvCZCZnIwKnUAzXITHtSxuXJlzWfszzginLuLlakhxUgSyNyEamCSjgJOoIcvFCHkQmwMWhjFrygaHgdNhSmaqsyyOQnAvobcIdmCAjIYIAKBmdgjkvAMAiVJdCztbCZgPxANXWhcUehifHiKLsLCLvTliKcXYcxGkwbHDQswwBXQsYqGcUzinphAXCiOmDnPOfPwJDTvYEoWlwFifmcYTTjbpDhsUQoxWbU"), string("ZDvupRoQLsdetLqBdgyzWMeSREPlrLaORxNGIOaRPENIFslfRmKICHCxUEYMyjEFGZQBtjVCRfuYTvRXdimJCWtZwJxpalkfRxPauyDwSOXNGdjlqBqkLfNLKzIFUrlmsBDYTmfbSrTEHpGZXoy"), false, 69566751);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SHNUYCklQDQb
{
public:
    bool YMLrfklcyXtuUxzr;
    bool SnsoGggGBCE;
    int AbGAmNCPW;
    double ExicgAOpwhLtLX;
    bool XebFGvn;
    double RKpgdA;

    SHNUYCklQDQb();
    int MLHMhohU(string kpXEKPxeRH);
protected:
    double lLXuKYDOZbBVzhj;

    bool mqnUCuXCw(double fqfRDf);
    string JmfvMFWrOqwl(string KXfWkTDk, bool hJInjWRPIqtWZUeX, string xCXGz, bool GToywXR, string hTWbni);
private:
    bool QQkQqJ;

    double eoIDbsDpXxPxYnXM(bool QNdLabK, string fiMCZjerfzx, string zNftat, bool SAPJRCJgRHLttFHz, double bAHdTaDjNgblPs);
    bool KPaCeZtEFQSQGN(bool ALfDVkWEGp, string FypmxvIRei, int fwcAdoWuobdqaVud, bool HdQtz);
    bool MidXxKrOHnO();
};

int SHNUYCklQDQb::MLHMhohU(string kpXEKPxeRH)
{
    double NamJpQr = -373546.0938466498;
    double CdPupFWugkCL = 324032.8348604201;

    for (int CBrhpfB = 2003241842; CBrhpfB > 0; CBrhpfB--) {
        NamJpQr *= CdPupFWugkCL;
        NamJpQr += NamJpQr;
        CdPupFWugkCL /= NamJpQr;
        kpXEKPxeRH += kpXEKPxeRH;
        CdPupFWugkCL -= NamJpQr;
    }

    return 245867965;
}

bool SHNUYCklQDQb::mqnUCuXCw(double fqfRDf)
{
    double LLVhAqeBMswwA = -461772.3770582318;

    if (fqfRDf > 703622.6050904295) {
        for (int RvxMDZFwfbc = 296828375; RvxMDZFwfbc > 0; RvxMDZFwfbc--) {
            fqfRDf = fqfRDf;
            fqfRDf *= fqfRDf;
        }
    }

    return true;
}

string SHNUYCklQDQb::JmfvMFWrOqwl(string KXfWkTDk, bool hJInjWRPIqtWZUeX, string xCXGz, bool GToywXR, string hTWbni)
{
    int uAsMhI = -617615552;
    bool mGsMjweB = true;
    double RJItUqqlxaqBRORN = 949461.903276233;
    double iNPDHAE = 622864.9585684295;
    int NtOhkvHBUQBTIG = 755712406;
    string AVyQYDUqWzzX = string("nkqQPWCaguhVmmqRqFwAbHtWHpZGkmjBHaWjmvwZhiNhnNstIrYoXZRnKNreTfBUIYqIbPtpMQfWYaiaQjOTmlLkDvymKRrJVJIW");
    double QIEVTwRyv = -414398.0660473453;
    bool SVweHNZIBizwsp = true;
    double erBEXcqQp = 576579.8584521513;
    double bmTqzNA = 418871.4258658097;

    return AVyQYDUqWzzX;
}

double SHNUYCklQDQb::eoIDbsDpXxPxYnXM(bool QNdLabK, string fiMCZjerfzx, string zNftat, bool SAPJRCJgRHLttFHz, double bAHdTaDjNgblPs)
{
    int oxLzv = -1247347309;
    int mKcCzvG = -1623587950;
    string fBFHiwJiEnf = string("AaOvPEwWItuiILTvZKHdLlbnVKwipWdOnFBjBuJrohjPMvxUdUeoKlwLLfjswvnGQoTXzgePRZfJOxZaqEjLsDSHJtPoLOcCWSoUHDiDRjrytuwQazTorNolvRHzrKBPIDDWgysxYLRBcMWstcoveQnbOFIwqRBIWcNDPjMmpQmxJCX");
    bool OlQoEkcVqC = false;
    string uVeOxLZPi = string("RYdMNEhRaNEGTCefZDxpGIrMuvhrnttTUkPkunQGFyBigNNbVkhdKLZHfBDiaHMpVzanomorHwPsKLzYADJUYCffkeGBYtgiXzegVtypcYrTMOnwYRgZoiJhVBirkfbRIAChOvetyLMmqepTlztJuQSAVKorleACbkllbjGvXZjboYzr");
    string bRgGQRlVfF = string("qhjlmblXqzssQLnGZOUuMEAPSVflsewKJoaKfJrJscGfOdMHyaltneuCPFiqqPbZNZNqGkbfvTbUUJMeNJSxxRVTdPThtCoxxrSFyrSteQPvoFlJzkrZt");

    if (uVeOxLZPi <= string("qhjlmblXqzssQLnGZOUuMEAPSVflsewKJoaKfJrJscGfOdMHyaltneuCPFiqqPbZNZNqGkbfvTbUUJMeNJSxxRVTdPThtCoxxrSFyrSteQPvoFlJzkrZt")) {
        for (int dBWKO = 332426776; dBWKO > 0; dBWKO--) {
            uVeOxLZPi = bRgGQRlVfF;
            uVeOxLZPi += fiMCZjerfzx;
            bRgGQRlVfF = zNftat;
        }
    }

    for (int uKsvGFBhfQq = 1494824409; uKsvGFBhfQq > 0; uKsvGFBhfQq--) {
        OlQoEkcVqC = QNdLabK;
        fBFHiwJiEnf += fBFHiwJiEnf;
        uVeOxLZPi += fBFHiwJiEnf;
        bRgGQRlVfF += bRgGQRlVfF;
        OlQoEkcVqC = OlQoEkcVqC;
    }

    if (fBFHiwJiEnf >= string("NGnNmnoZmuGKJZbhwPHZqrZyrVABxdbsWvpLIoHsZMLnueAhkdJDyGZWqV")) {
        for (int EPhhCFoLrNGHwIt = 1809095385; EPhhCFoLrNGHwIt > 0; EPhhCFoLrNGHwIt--) {
            uVeOxLZPi = fiMCZjerfzx;
            uVeOxLZPi = fBFHiwJiEnf;
            SAPJRCJgRHLttFHz = OlQoEkcVqC;
        }
    }

    for (int zaJtdYUimfglAP = 967953291; zaJtdYUimfglAP > 0; zaJtdYUimfglAP--) {
        continue;
    }

    for (int hngXmAHYdFiugbct = 396381790; hngXmAHYdFiugbct > 0; hngXmAHYdFiugbct--) {
        QNdLabK = ! QNdLabK;
    }

    return bAHdTaDjNgblPs;
}

bool SHNUYCklQDQb::KPaCeZtEFQSQGN(bool ALfDVkWEGp, string FypmxvIRei, int fwcAdoWuobdqaVud, bool HdQtz)
{
    double iFggduQtG = -384469.1451084172;
    string fiSooszefz = string("ZBGmpshmofJcVziafdTMOezgQj");
    int wYJdgvyDRMYyt = -1517431704;
    double hEQcKihFG = 374044.69097497803;
    bool YWJwAQkZOcgKVKi = false;
    double kSHLPFP = 898128.3470296973;
    string HpYgMRhQkjKkO = string("jPLIUevEqixGBPvuKvRvnSYVZfVdQIaANcbxAljfhSVok");

    if (iFggduQtG != 374044.69097497803) {
        for (int telgCgCAUhP = 70305199; telgCgCAUhP > 0; telgCgCAUhP--) {
            wYJdgvyDRMYyt *= wYJdgvyDRMYyt;
            YWJwAQkZOcgKVKi = ! HdQtz;
        }
    }

    for (int RnLTja = 173789125; RnLTja > 0; RnLTja--) {
        continue;
    }

    for (int WiuhMfTCiuRR = 1452404240; WiuhMfTCiuRR > 0; WiuhMfTCiuRR--) {
        continue;
    }

    return YWJwAQkZOcgKVKi;
}

bool SHNUYCklQDQb::MidXxKrOHnO()
{
    int jXSKCr = 1621649008;
    bool QHEHCY = false;

    if (jXSKCr >= 1621649008) {
        for (int jmONx = 1881223173; jmONx > 0; jmONx--) {
            continue;
        }
    }

    if (jXSKCr < 1621649008) {
        for (int paoUthrClaUnx = 1237330528; paoUthrClaUnx > 0; paoUthrClaUnx--) {
            QHEHCY = ! QHEHCY;
            jXSKCr -= jXSKCr;
            QHEHCY = QHEHCY;
            QHEHCY = QHEHCY;
            jXSKCr = jXSKCr;
            QHEHCY = QHEHCY;
        }
    }

    if (jXSKCr == 1621649008) {
        for (int kTDJRzketU = 1305313858; kTDJRzketU > 0; kTDJRzketU--) {
            jXSKCr *= jXSKCr;
            jXSKCr = jXSKCr;
        }
    }

    for (int CQDfdozUc = 459239445; CQDfdozUc > 0; CQDfdozUc--) {
        QHEHCY = QHEHCY;
        jXSKCr /= jXSKCr;
        jXSKCr -= jXSKCr;
        jXSKCr /= jXSKCr;
        QHEHCY = QHEHCY;
        jXSKCr *= jXSKCr;
    }

    if (QHEHCY == false) {
        for (int yprHendJcuYWr = 1556623749; yprHendJcuYWr > 0; yprHendJcuYWr--) {
            jXSKCr /= jXSKCr;
            QHEHCY = ! QHEHCY;
        }
    }

    return QHEHCY;
}

SHNUYCklQDQb::SHNUYCklQDQb()
{
    this->MLHMhohU(string("yjnjTZ"));
    this->mqnUCuXCw(703622.6050904295);
    this->JmfvMFWrOqwl(string("QatzEbnhXvyGhZXrtqmHNsWtFHoJwiUamOjjvgblRVUTFmYGWEIKAXLYAWZErTcVxLxtfcZkqAjCCKSWyavewhsgNxSkVGTJPvBfFIMWoymLeywqTrHTDQJk"), true, string("KCicuNxlWIaarfywGcRgvrqeyUWUiagKOwWgZwuLNjaWefkxRXYslOZSghLVKnKztEMFFfLXLckbWkQohpdGKNpTuCTSZjPaqLWOBIfmQdcPwEOzXmxAkVpGEpEtqcgkzpOyQuj"), false, string("pcYanoEuoRzNEAwWqOKMTUxQbwHpBlzoDwrSMqcQvtomSQnYGUVSYjpScOCOgaINqUfAPdooDdNRpfmhnoILoSMIVxPIsudS"));
    this->eoIDbsDpXxPxYnXM(true, string("hKOkeActsVWp"), string("NGnNmnoZmuGKJZbhwPHZqrZyrVABxdbsWvpLIoHsZMLnueAhkdJDyGZWqV"), false, -572566.1265858649);
    this->KPaCeZtEFQSQGN(true, string("mWHdCwaZWgWfTrgVJRJuemQRtYGwavFCsTsWJLCTJRUguqjYBXghMEAHqWGBCwZKaoaYZ"), -1216401040, false);
    this->MidXxKrOHnO();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YIEcQKTkFoEGEBj
{
public:
    int TySmzSXrPdFlz;
    bool PaFWpWqOTnUf;

    YIEcQKTkFoEGEBj();
    bool XoCNW(string PfhSPwmLChVBw, bool qRujSESQsVXgvK);
    double NvYjowuuZpk(double nTlwbjNVIvtMWK, double GtpIEWwLbXNpdes, bool ibBPoUmLeM);
    string ZQUUSJj(double mJxmLJAjGJXjpd, bool ttInsWHZBwYSJeT, string pxPdFOwLJpxPPI, double efMgQqjYtGn);
    void cNPJcNUTkjkqnDT(bool TMSClPgiGPQX, int mUbKR, string bIYRSFbB, double gJJgYDsYJdHSV);
    double tXxIS(string gyDCXR, int ZBoKZNlqb, string AdPomoZvcSKTvOB, int XCRuSaDugZRhal, bool QXlaqyhklr);
    void OdJActoSmge(double ZlHRKSiB, int DnLVZWBnkgeno);
protected:
    bool LtkHKLUWvkMb;
    bool iELuxxsJSSKsxXe;
    double vxIarYxZhua;
    string yHDWbCzBpsXgAie;
    int nYgblalIEi;
    double bkZCZpDnlUa;

    int BBWjjoNtvbcW(int dCFJRMKY, bool aEVvgRy, string oAllDHhFNUiMueCF, bool UeJYu, string FCSqBsVQdHto);
    double GVsvlNkfxkRUkIv(double RQoXlK);
    bool ayHfIzxncYc(string RJtqNwKDbCqnKD);
    bool KYvLCWDB(int SNNqhtqyMfldBIq, double yVbCUYOsgLYNE);
    int oEJlmzWfglqm(double VjaRyy, double ugdQGiUr, bool FoaCfltsS);
    bool rHyLNCTWrSbxyO(int kjWfHbbKTAX, int QubtR);
    int xnsZGwGmpkRFILqL();
private:
    double fYMkg;
    double tXKLXoXNug;
    bool spGMn;
    int UswDx;
    bool wGEhYswXKxWCGyrB;
    double jHOTGubvuTB;

    int ScGUGE(bool JsHPcyoenpaaoGf, string YLbWTg, string TeSQUkNtslfql);
    bool kjXBgzKH(bool bRVbVzzXRkJt, string iIFIhobFzXm, double mSeharBGKW, string RjpfW);
    string efMUgmbg(int vROIjrMZZrD, int OEPEpEJAmqSDtuRA, double DWBpDOifRJjnD);
    bool ZjOTIbVtgetThU();
    int jphjOsNpyzjLUoI(bool OBWYngpyfatmMQQu, double HaAMj, bool NQbBB, double LxPnxCxZ, double dZNpYdfq);
    int OxdIyctr(bool rImZNib, string YVuzamVX);
};

bool YIEcQKTkFoEGEBj::XoCNW(string PfhSPwmLChVBw, bool qRujSESQsVXgvK)
{
    bool NOQXQ = true;
    int mpmZNca = 1137003560;
    bool fLNayNfffzH = true;

    for (int KmozSkn = 1418043341; KmozSkn > 0; KmozSkn--) {
        continue;
    }

    return fLNayNfffzH;
}

double YIEcQKTkFoEGEBj::NvYjowuuZpk(double nTlwbjNVIvtMWK, double GtpIEWwLbXNpdes, bool ibBPoUmLeM)
{
    string nXKmgu = string("nAsYJoKbzpZfMvljbTXDbtmsloXQAYWBxJGmmulnSmAjwpifUROXcxgHTediLGiidcPiNZqIcpqhYwuzyBcdofPGPiUkpplxJFbDjbgI");
    double VoSiOrFbXzyvZ = -234547.88530889933;
    double GNtANzBPfT = -217419.71932810068;
    double usUTQIbrNIsyg = -482795.08978833904;
    double qzqYNINKOxjBkVla = -291968.5547833212;
    string EFaVbkQUyUtuUXK = string("lIpGeXxkcFPJWmLJjhMXiKncDfjjUYhs");
    string bEimUhDN = string("wwBKwvWLkrbvWwpofRxlweptyHRskswzCEJFOQUIcdCwJWobgNRxURlDJeGrAoGUiYRJQCeJnosYcZonvCXahEyhxkUjRvFWQZIjpxNzdXmiZIHKJAcjckJYricXEbUQTmtbROegtKhOjqNayfRLTMerUsdKVvxukZcpIMWnaFiLLyOCoJxsvMxXVOVoIQaUgPyTzuXiBCbMokTMeXvrjIWOyxv");
    string WffjxPzhbJa = string("KknuHZxkkPhOiWtgoSweiYfeQmlUmXCedzeARlfZlWsdcDNLcBlGuqMJEVHnJWkkXQkREinQXNnANXgdiZKGBDdErcScCGcsVHIBrbKkcuBRwGOnmuzVYTQDbIKpRVDCWBQAAlAAJOCrCVrEMcmjYBezdcUIhwYHtFZMNXDaKyxayAVyunHzywaRzvVZeoVdtzkwelPzn");
    string mLDhc = string("gblCxWgWsoSzFantcCOburxHpkUvdSdAKyPcLoXohLLFPAkmsDcJrmqRQJHuMhGfcihIUdvMOvtIEJQzhIntcgQTRGJYVeNIxQEldVCwaIproRZoPXCRLXhfTvCUNOMFUmwxGdIYCJmdxGbfKxRhLIuFAawLfwBgtQFHFHxqrZmraxecLHhEhabPVWirCClMkmmslVsMTn");

    for (int SNgJaXJVGAMx = 1104552347; SNgJaXJVGAMx > 0; SNgJaXJVGAMx--) {
        nTlwbjNVIvtMWK -= GtpIEWwLbXNpdes;
        EFaVbkQUyUtuUXK += EFaVbkQUyUtuUXK;
        GNtANzBPfT /= qzqYNINKOxjBkVla;
    }

    for (int yNfRl = 1956590748; yNfRl > 0; yNfRl--) {
        nXKmgu = nXKmgu;
        GtpIEWwLbXNpdes = GtpIEWwLbXNpdes;
    }

    for (int zMJxJSsKxW = 1596325865; zMJxJSsKxW > 0; zMJxJSsKxW--) {
        GNtANzBPfT /= GNtANzBPfT;
        usUTQIbrNIsyg /= GNtANzBPfT;
        mLDhc += EFaVbkQUyUtuUXK;
        nTlwbjNVIvtMWK /= usUTQIbrNIsyg;
    }

    return qzqYNINKOxjBkVla;
}

string YIEcQKTkFoEGEBj::ZQUUSJj(double mJxmLJAjGJXjpd, bool ttInsWHZBwYSJeT, string pxPdFOwLJpxPPI, double efMgQqjYtGn)
{
    double fcKwl = -515768.05873761355;
    string LjjwxynO = string("wRaVooTZZaFCpjFIvdiEquAdAilVCGEZKALYmidgyJeBIABlnpXyKmbQrOVrxdKQEWMPdOmOWudSNoSlCUeZsN");
    double ujYgRDelaADaE = -871387.2078482874;
    bool VzDFEcHdKxN = false;
    bool KosmrFtrbm = true;
    double SSpeJVs = 512508.6712939938;
    string SwPdOyuhWPqMcaz = string("XmHdPginkAfqbxGKGSGlxdJtuXuJhqxfHMrKJPVORZBbloMePjhQSyTjdoxQVbwMCmqfPubUHLKD");

    return SwPdOyuhWPqMcaz;
}

void YIEcQKTkFoEGEBj::cNPJcNUTkjkqnDT(bool TMSClPgiGPQX, int mUbKR, string bIYRSFbB, double gJJgYDsYJdHSV)
{
    double OeIMRiiXZBbmZU = -579439.9205118703;
    bool RbcwJE = true;
    int DBDZmAkpBCPazEh = -613899198;
    int XzYiCqtbYSCFiYoh = 1417412598;
    bool cvUmZk = false;
    int kodFGl = 523281623;
    int teNldlSNmZEa = 988999170;
    bool wQNBxbgmZ = false;
}

double YIEcQKTkFoEGEBj::tXxIS(string gyDCXR, int ZBoKZNlqb, string AdPomoZvcSKTvOB, int XCRuSaDugZRhal, bool QXlaqyhklr)
{
    string iptbcYaD = string("OdGMwXmXRvPUdTCJhfvryjzKVmmFnNCqYZPlepPZeLXLuzswzKkyJTHhWLENQfoxMsdiYdTGElHWWOJmCMxTyFKMZJXCLgMTMvIDCKfQcttAAFPgGdkpGdgebALUnSnoovUixKC");

    for (int DxplG = 415285308; DxplG > 0; DxplG--) {
        AdPomoZvcSKTvOB += gyDCXR;
    }

    for (int vXZbYRSnScTnvqp = 1448380460; vXZbYRSnScTnvqp > 0; vXZbYRSnScTnvqp--) {
        AdPomoZvcSKTvOB += gyDCXR;
    }

    if (iptbcYaD >= string("XfPNyrCzLFBdVauKmoYIBAykXQzIBOmbsmJBhWLgblYTeOdPOIbsUtakUzLTRytcXmdEwpIprgWUUTbHZAwQUwLROUmwaeKciKpQeHDTTBCDBNRhOfzqVrsrtoXsCPK")) {
        for (int IHBlSUTDyGhB = 311527715; IHBlSUTDyGhB > 0; IHBlSUTDyGhB--) {
            QXlaqyhklr = QXlaqyhklr;
            ZBoKZNlqb = XCRuSaDugZRhal;
            ZBoKZNlqb *= XCRuSaDugZRhal;
        }
    }

    if (iptbcYaD > string("OdGMwXmXRvPUdTCJhfvryjzKVmmFnNCqYZPlepPZeLXLuzswzKkyJTHhWLENQfoxMsdiYdTGElHWWOJmCMxTyFKMZJXCLgMTMvIDCKfQcttAAFPgGdkpGdgebALUnSnoovUixKC")) {
        for (int tFQUfELqmjkBqEbw = 1172301386; tFQUfELqmjkBqEbw > 0; tFQUfELqmjkBqEbw--) {
            gyDCXR = AdPomoZvcSKTvOB;
            iptbcYaD += gyDCXR;
        }
    }

    return 264100.26019981503;
}

void YIEcQKTkFoEGEBj::OdJActoSmge(double ZlHRKSiB, int DnLVZWBnkgeno)
{
    int WZKwgZW = 1236170882;
    double zDbWRTBJyzle = -161336.78032510076;
    string NQwhlzZo = string("GsDuJOxgmURSMbiOznJBhWhEiIJtspnLTeUWXPyloCqyXYlKyzuLqPJDjOUTPnjmRtFYLFjlRfWVOHcFTAklJBjiuKEDdzaGhDRWdfzVuWcvMHmFoLGRaaaKWCucpKlEIDAHcCWCzXJIvjqpUJDpWuEXocUEttqyUGmZMaLjsFYIZMMCIrxNiPXyDhhhOyIVnNtvtqiwkRWPLnKANOOciTNIaRLRtxi");

    if (NQwhlzZo == string("GsDuJOxgmURSMbiOznJBhWhEiIJtspnLTeUWXPyloCqyXYlKyzuLqPJDjOUTPnjmRtFYLFjlRfWVOHcFTAklJBjiuKEDdzaGhDRWdfzVuWcvMHmFoLGRaaaKWCucpKlEIDAHcCWCzXJIvjqpUJDpWuEXocUEttqyUGmZMaLjsFYIZMMCIrxNiPXyDhhhOyIVnNtvtqiwkRWPLnKANOOciTNIaRLRtxi")) {
        for (int hjruCuHSthRf = 370114972; hjruCuHSthRf > 0; hjruCuHSthRf--) {
            WZKwgZW *= DnLVZWBnkgeno;
        }
    }

    if (DnLVZWBnkgeno >= 1236170882) {
        for (int urlxqI = 1792758708; urlxqI > 0; urlxqI--) {
            DnLVZWBnkgeno += WZKwgZW;
            WZKwgZW -= DnLVZWBnkgeno;
            NQwhlzZo += NQwhlzZo;
            NQwhlzZo += NQwhlzZo;
            WZKwgZW *= WZKwgZW;
            DnLVZWBnkgeno *= DnLVZWBnkgeno;
            zDbWRTBJyzle = zDbWRTBJyzle;
        }
    }

    for (int DVKkKfzFrgEyGbhi = 1218748417; DVKkKfzFrgEyGbhi > 0; DVKkKfzFrgEyGbhi--) {
        zDbWRTBJyzle = ZlHRKSiB;
    }

    for (int BbThNbAyMHQ = 541512799; BbThNbAyMHQ > 0; BbThNbAyMHQ--) {
        NQwhlzZo = NQwhlzZo;
        WZKwgZW /= DnLVZWBnkgeno;
        ZlHRKSiB -= zDbWRTBJyzle;
    }

    for (int yfxNNwYcpp = 1810699421; yfxNNwYcpp > 0; yfxNNwYcpp--) {
        WZKwgZW += DnLVZWBnkgeno;
        DnLVZWBnkgeno *= DnLVZWBnkgeno;
        WZKwgZW /= WZKwgZW;
        NQwhlzZo = NQwhlzZo;
    }
}

int YIEcQKTkFoEGEBj::BBWjjoNtvbcW(int dCFJRMKY, bool aEVvgRy, string oAllDHhFNUiMueCF, bool UeJYu, string FCSqBsVQdHto)
{
    int wAfClixzHnvl = 844125379;
    string ezYFjMuDTrzyFhY = string("cPTHoDaKRdYIvmngcCqznqKFahhamBcKterKELgjbCosebRfbAVrXEgLinPkCERIfFQkQbOYLADaWXJCJLMDrbtKYBSnPGiSjMklsHWLKXqozxsvdpfpquxdxArpxcsWFxeswktMbenVBo");
    int PJNPJWow = -1336061107;
    int iaqSZ = -2142341781;
    int TzqLHJeJqTp = 1425529075;
    bool AVNhRvisW = false;

    for (int EHdbXBOnYewVWJ = 389464840; EHdbXBOnYewVWJ > 0; EHdbXBOnYewVWJ--) {
        aEVvgRy = ! aEVvgRy;
        iaqSZ -= TzqLHJeJqTp;
    }

    for (int tNlfjGkQ = 85622004; tNlfjGkQ > 0; tNlfjGkQ--) {
        continue;
    }

    for (int pYgwlVt = 1226559237; pYgwlVt > 0; pYgwlVt--) {
        PJNPJWow += dCFJRMKY;
        AVNhRvisW = ! UeJYu;
    }

    for (int trJQfosiRvM = 1630048847; trJQfosiRvM > 0; trJQfosiRvM--) {
        oAllDHhFNUiMueCF += FCSqBsVQdHto;
    }

    for (int btrSDciyMogTJP = 756552978; btrSDciyMogTJP > 0; btrSDciyMogTJP--) {
        PJNPJWow /= TzqLHJeJqTp;
        TzqLHJeJqTp *= iaqSZ;
        aEVvgRy = ! aEVvgRy;
    }

    return TzqLHJeJqTp;
}

double YIEcQKTkFoEGEBj::GVsvlNkfxkRUkIv(double RQoXlK)
{
    double oqgHwXLNx = 372002.2862921231;
    bool VEGFNV = false;
    bool fxwhULnJU = false;
    int jCWvDBtN = 1417125240;

    for (int JpbEfDkFh = 94995957; JpbEfDkFh > 0; JpbEfDkFh--) {
        VEGFNV = ! VEGFNV;
        VEGFNV = ! fxwhULnJU;
        RQoXlK -= oqgHwXLNx;
    }

    if (RQoXlK < 372002.2862921231) {
        for (int xcaVBh = 1439524633; xcaVBh > 0; xcaVBh--) {
            fxwhULnJU = fxwhULnJU;
            fxwhULnJU = ! fxwhULnJU;
        }
    }

    for (int BgnQwIXBTJrZI = 1917781788; BgnQwIXBTJrZI > 0; BgnQwIXBTJrZI--) {
        RQoXlK /= RQoXlK;
        VEGFNV = fxwhULnJU;
    }

    return oqgHwXLNx;
}

bool YIEcQKTkFoEGEBj::ayHfIzxncYc(string RJtqNwKDbCqnKD)
{
    string WqnIzVIIA = string("aaihdmIWhFXkwFNLTxSpukkAjGsiBDMdPKjZfRtzHySYYmKvjHTWnAQLdHdbcgmvmyFaEkVsJzSlKBRpbCIHVnQrJPnMfnIJNEsMHFoiPTdmtZJVbpMXZPlrCTGcwGGofbkFvAFoVbBYgiZFtgwSAlpbUIPKyWTFIGOkyWJrYsBZxIZUNyeDRUOnHYNVMcDWUxmpVHkpYSwjRnwIMZXBixXrofRPbKECDCTBzWNbxuEHFtXtGxyndzCRLwvOpm");
    bool GgXhRPA = true;
    double EGbLpiYjid = -410826.4208718491;

    for (int pxSrAwj = 730552194; pxSrAwj > 0; pxSrAwj--) {
        RJtqNwKDbCqnKD += WqnIzVIIA;
        EGbLpiYjid -= EGbLpiYjid;
    }

    for (int bLrlnB = 129500821; bLrlnB > 0; bLrlnB--) {
        EGbLpiYjid *= EGbLpiYjid;
        RJtqNwKDbCqnKD = RJtqNwKDbCqnKD;
    }

    return GgXhRPA;
}

bool YIEcQKTkFoEGEBj::KYvLCWDB(int SNNqhtqyMfldBIq, double yVbCUYOsgLYNE)
{
    bool ZUdaQ = true;
    bool LOjrNe = false;
    string QQxNzLrciZmHmmKu = string("GVjuBfopxaxBpXSHBWFCqknCqXjmWbAnKaVXzyBORTFgwdXDvICfJjrMyWtQchrCJrDFqntfEXlAqMBOzNGrGWpLaJmCmWHbTqWFEHmedyRkPnUBGCfdfhLLXzEekEiIzTQUFSQxwvogkvjURs");
    double gQbHU = 5432.669806729921;
    bool CGjgy = true;
    bool fMkNrVyrY = false;

    return fMkNrVyrY;
}

int YIEcQKTkFoEGEBj::oEJlmzWfglqm(double VjaRyy, double ugdQGiUr, bool FoaCfltsS)
{
    string vgqZENGb = string("LtyMTiILGrwPvHjrrZxNMUsdectVhjRcKTJVGxLHiYKjhPYOlzxRZWshEYNmrMzbhiKXtHFSvfooMpPUtSjdRPPxNKURdwasAlrHpJacDUCWrtliGISliHKhhOldLDiUErtSlXKFPbOYmosaMENJdrmv");
    double VpIyDPJoSkRQdh = 46807.76091367474;
    string dCmEsf = string("fcci");

    if (ugdQGiUr <= 46807.76091367474) {
        for (int AKjNpEeKHQHCDh = 934744624; AKjNpEeKHQHCDh > 0; AKjNpEeKHQHCDh--) {
            VpIyDPJoSkRQdh /= ugdQGiUr;
            dCmEsf += dCmEsf;
            FoaCfltsS = FoaCfltsS;
            ugdQGiUr *= ugdQGiUr;
            vgqZENGb = dCmEsf;
        }
    }

    if (dCmEsf != string("LtyMTiILGrwPvHjrrZxNMUsdectVhjRcKTJVGxLHiYKjhPYOlzxRZWshEYNmrMzbhiKXtHFSvfooMpPUtSjdRPPxNKURdwasAlrHpJacDUCWrtliGISliHKhhOldLDiUErtSlXKFPbOYmosaMENJdrmv")) {
        for (int tWcmfdBrJ = 1313524437; tWcmfdBrJ > 0; tWcmfdBrJ--) {
            continue;
        }
    }

    return 700499050;
}

bool YIEcQKTkFoEGEBj::rHyLNCTWrSbxyO(int kjWfHbbKTAX, int QubtR)
{
    string grQQCusBmNctLJp = string("ZCqSXQuvzMGwhlIdYPxsoyEpAlLhObYfu");
    int cNCFHz = -31634312;
    double AbOtvcGjFKsOyYdZ = -388835.2909054996;
    bool vboReGGwrD = false;
    bool bxmjntxpDx = false;
    string IKxYriKIm = string("TpUdTWNhDAPFdLZCgZofOsYTExoaKdeoLruowfuuDgqyqCpFOWHmMymJSLxAMWXSrhfhzQXNjbjbvQwrZdLFqhwWTiZdZUWdadjGsJhWlxFHUnJUPXEKiHDtYWZeyjvvNutBk");
    double pjkXeHiEA = 14942.064772965727;
    bool QMTJkqsbAM = false;

    for (int LRbGhcCL = 1944406902; LRbGhcCL > 0; LRbGhcCL--) {
        continue;
    }

    for (int OpfPdxiScZ = 1706415746; OpfPdxiScZ > 0; OpfPdxiScZ--) {
        continue;
    }

    if (IKxYriKIm == string("TpUdTWNhDAPFdLZCgZofOsYTExoaKdeoLruowfuuDgqyqCpFOWHmMymJSLxAMWXSrhfhzQXNjbjbvQwrZdLFqhwWTiZdZUWdadjGsJhWlxFHUnJUPXEKiHDtYWZeyjvvNutBk")) {
        for (int jhVzdmyNd = 1580349367; jhVzdmyNd > 0; jhVzdmyNd--) {
            bxmjntxpDx = QMTJkqsbAM;
        }
    }

    for (int mQvemim = 1725389461; mQvemim > 0; mQvemim--) {
        pjkXeHiEA -= pjkXeHiEA;
    }

    if (kjWfHbbKTAX >= -31634312) {
        for (int lqqhAqLVr = 1193916921; lqqhAqLVr > 0; lqqhAqLVr--) {
            pjkXeHiEA -= pjkXeHiEA;
        }
    }

    return QMTJkqsbAM;
}

int YIEcQKTkFoEGEBj::xnsZGwGmpkRFILqL()
{
    int revyQiGAzye = -449829886;
    int FjeOKEWQNn = -1318925407;
    string GrqQYCyYwqqhT = string("hvasOvfDOmAqxXVdiuBANvjsutDYoXqqewvlJQxmEZtwrzRbIqDsgCnIjmaBmxLfv");
    string Yhzhsg = string("wugFCcxhhXuYbcqzcIIGCruRUflKMwqodbQcUTzHTvNMdmFyseIMmEjLolFTmZZQEIOHRkFXfUaMaBaVBks");
    bool otriXB = true;

    for (int uLIlsqoh = 303871611; uLIlsqoh > 0; uLIlsqoh--) {
        GrqQYCyYwqqhT = Yhzhsg;
        FjeOKEWQNn /= FjeOKEWQNn;
    }

    if (revyQiGAzye < -1318925407) {
        for (int vmyDNWPbl = 40758518; vmyDNWPbl > 0; vmyDNWPbl--) {
            FjeOKEWQNn = revyQiGAzye;
            otriXB = ! otriXB;
        }
    }

    for (int zIdReQY = 735606525; zIdReQY > 0; zIdReQY--) {
        Yhzhsg += GrqQYCyYwqqhT;
        GrqQYCyYwqqhT = Yhzhsg;
        otriXB = otriXB;
        Yhzhsg = Yhzhsg;
    }

    for (int YGgTGwSY = 1008057109; YGgTGwSY > 0; YGgTGwSY--) {
        revyQiGAzye -= FjeOKEWQNn;
    }

    return FjeOKEWQNn;
}

int YIEcQKTkFoEGEBj::ScGUGE(bool JsHPcyoenpaaoGf, string YLbWTg, string TeSQUkNtslfql)
{
    double DPdrOeHjr = -200755.09965828375;
    string CgaUi = string("XKiUYJNwxrHCWVzYfZpaKGhguxND");
    bool XEwKnh = false;
    int jPPTVtyPstkLaSD = 1170748687;
    int hcDpZvZgKEwtB = -131400668;
    bool iqmmTjvqQxYaQYtR = true;
    string OuGuIoLZ = string("olkCSMhJYCQTgYpboTLXaqFAkyqCrMzokiEBbWJTfLRYNMPKOOBGIuDStYzSpjcaQWqFUVICHSbJOONPjsvFFjgNIGCNEVICylcggtWkkxOsYordqsomETXerRjHECcVBjcxccMrVvClJYjeVUIzcoRbCbXyDTIAuDRgghqbIHutCCxPFRdmwaVhmYimmQTLdVcaAokfqqsVuiTEGXuvdQ");
    int txBlyJOTCqz = 1950394822;
    int jwowLTaSHxNAgbh = -409340484;
    double OWvMgIusq = -830256.5636820502;

    for (int VweAfHEaZnQeH = 1267009443; VweAfHEaZnQeH > 0; VweAfHEaZnQeH--) {
        OWvMgIusq = DPdrOeHjr;
        hcDpZvZgKEwtB *= jPPTVtyPstkLaSD;
        jPPTVtyPstkLaSD = hcDpZvZgKEwtB;
        OuGuIoLZ = YLbWTg;
    }

    for (int ChMkCuisrjfLkR = 1728500873; ChMkCuisrjfLkR > 0; ChMkCuisrjfLkR--) {
        jwowLTaSHxNAgbh /= jwowLTaSHxNAgbh;
    }

    for (int IZsymdEfq = 1190170028; IZsymdEfq > 0; IZsymdEfq--) {
        continue;
    }

    if (JsHPcyoenpaaoGf != false) {
        for (int srEWAiLcsXdr = 354426591; srEWAiLcsXdr > 0; srEWAiLcsXdr--) {
            OuGuIoLZ = CgaUi;
        }
    }

    for (int rDaHeLlAYwAwZN = 496698658; rDaHeLlAYwAwZN > 0; rDaHeLlAYwAwZN--) {
        DPdrOeHjr *= OWvMgIusq;
        CgaUi += CgaUi;
    }

    if (OWvMgIusq < -830256.5636820502) {
        for (int tWMYKLTEMswLW = 2010401004; tWMYKLTEMswLW > 0; tWMYKLTEMswLW--) {
            TeSQUkNtslfql = OuGuIoLZ;
            OWvMgIusq -= DPdrOeHjr;
        }
    }

    return jwowLTaSHxNAgbh;
}

bool YIEcQKTkFoEGEBj::kjXBgzKH(bool bRVbVzzXRkJt, string iIFIhobFzXm, double mSeharBGKW, string RjpfW)
{
    int oADvHpOc = 1488651190;

    if (iIFIhobFzXm <= string("MifqgsOUKETVbGRVmhfgBXObcgCPcHczvmCEVrxZHUwnyuaTCYjwdsfnugZoKdGrHEtEknygALDOkwmSZKVLQjjwmAPqaduhHCkdpJrsplpaARasaehbkkFnqiIQaqBiytisspHgVyTyrypXclkkmJaWRjhwinldviemhwagiInyqtcRotUaorqvaSYZDbcxHdkYKuvXZrkmTUSLnVajnAGbKCJgvNUVBnXLknbipyXzKQqSMUvKEWImw")) {
        for (int zdIBniKZFKybALUp = 1865161359; zdIBniKZFKybALUp > 0; zdIBniKZFKybALUp--) {
            iIFIhobFzXm += iIFIhobFzXm;
            RjpfW += RjpfW;
            mSeharBGKW /= mSeharBGKW;
            iIFIhobFzXm = iIFIhobFzXm;
            iIFIhobFzXm += RjpfW;
        }
    }

    for (int gkiLPNn = 1969440395; gkiLPNn > 0; gkiLPNn--) {
        continue;
    }

    for (int BjolqghrhsrAjQi = 707987178; BjolqghrhsrAjQi > 0; BjolqghrhsrAjQi--) {
        continue;
    }

    for (int lcrvPLfEALl = 472035662; lcrvPLfEALl > 0; lcrvPLfEALl--) {
        oADvHpOc = oADvHpOc;
    }

    for (int lpPGsOsZ = 1924952388; lpPGsOsZ > 0; lpPGsOsZ--) {
        RjpfW = RjpfW;
        bRVbVzzXRkJt = bRVbVzzXRkJt;
    }

    if (RjpfW >= string("MifqgsOUKETVbGRVmhfgBXObcgCPcHczvmCEVrxZHUwnyuaTCYjwdsfnugZoKdGrHEtEknygALDOkwmSZKVLQjjwmAPqaduhHCkdpJrsplpaARasaehbkkFnqiIQaqBiytisspHgVyTyrypXclkkmJaWRjhwinldviemhwagiInyqtcRotUaorqvaSYZDbcxHdkYKuvXZrkmTUSLnVajnAGbKCJgvNUVBnXLknbipyXzKQqSMUvKEWImw")) {
        for (int uRXyjiSPwH = 1799496620; uRXyjiSPwH > 0; uRXyjiSPwH--) {
            RjpfW += RjpfW;
            oADvHpOc *= oADvHpOc;
        }
    }

    return bRVbVzzXRkJt;
}

string YIEcQKTkFoEGEBj::efMUgmbg(int vROIjrMZZrD, int OEPEpEJAmqSDtuRA, double DWBpDOifRJjnD)
{
    int BrjvP = 2135717461;
    string ZDmtvFuH = string("ECgiJVNQBrrwaHGriPhunNFiAoTGV");
    double xgsmjvn = 464246.98595435184;
    double VrATCNLtR = -409556.9272603159;
    string PYQGiFzZGeca = string("zjeWzAavnhOkDlqDQzKzdDPeaXDgiWwQmzJlqGpDyAgSbWKxQrRfUegvERtnRLkgqjNTgJPuDGpxImxfOHWawnsDNCKVmvnsOMIrcspoWNXgYjVOuBgBIkvCghHeHdbsOyUCSQbEUpoVJJteYJ");
    string fHKZQnDOFoJcbv = string("IuJwueqLZPHRUohAQGoNcXtLpHsXyBJFLicBQtjqUVXXkmLCsSwcWdRyvCOAtgAxRDeSDWRYSmbRMxOSHdvuiGZZShwuZwiZDxwyZfOEGVrmenRjZBCVnlpaoGYHJSlyigFVmpluaKPvVGgiQXoKzPhOAnlJhJJqHxlRJuoHTZlESmeOxPCtXcKvfZGOTNhjubIcckOCDXksAKaTLgQUcdRUwJXKXABxnncuGptlDMbfaLAuJqvPsCOtyLxS");

    if (PYQGiFzZGeca < string("ECgiJVNQBrrwaHGriPhunNFiAoTGV")) {
        for (int ZeNrQqzlgPo = 187344109; ZeNrQqzlgPo > 0; ZeNrQqzlgPo--) {
            PYQGiFzZGeca = ZDmtvFuH;
            fHKZQnDOFoJcbv += PYQGiFzZGeca;
            VrATCNLtR /= DWBpDOifRJjnD;
            VrATCNLtR /= xgsmjvn;
        }
    }

    for (int gLvJa = 1629420696; gLvJa > 0; gLvJa--) {
        OEPEpEJAmqSDtuRA -= vROIjrMZZrD;
        VrATCNLtR /= VrATCNLtR;
    }

    return fHKZQnDOFoJcbv;
}

bool YIEcQKTkFoEGEBj::ZjOTIbVtgetThU()
{
    string JeRNnQGnf = string("lGYuAqBIhqvTWyOLOjaQXDTDrrRGAcfldqlgZoNMtgHDpjKQpOoFLFJkaUUODeIhKDwKnXHdmaTUSFLuktljyZwSTBFxqukQdNsZOtADtWzcWoIZcafSOPYimkgkQLSYYMiwRDZDSjWDqrcFCfaCaGNSUEFxGYNyKro");
    bool fyDIHZ = true;
    bool UqKTCMDIdmnKuZ = true;
    int DRMssjkjPy = -175204450;
    string TsAzpeiuql = string("lCGVMEbONyLPoySLUgOhLlhfkZsKxpjZGeILGMeTGapTRgXOgfNLAiqtrtimcepENveFPXWepRyvZgmSmCkAQYPWkGJHU");
    double vKfWkFphXlCiBU = 409205.2990107269;
    string jBoyFFa = string("wNLqzFhqFEVHIgUvHmbvZoLqavAzRRZzDiEPWwyEsJapHrXBaEZFcRaMuhgqqxexSJSLexJsrxOyBGRFBucXYwgrbYVucKYrGROinpOmMNAUOUnadVhyxaDAfGEKQdJSppJIbuRbaOSxGBddbIgurAQuHtjZdYRSzliDCyronPkelgwiUciETOxUtCJOnYskxnmUHkxtsSRoqHMAAxkeHDOsTgfhcncHvBdP");
    int VTmxZsKFXtkMK = -491628239;
    string eDZSFwPPos = string("gWEDyFpiDYDopiayKhcizSUqmgmgcQNEIJtAxzxwEaDjfquaGLhkHfnVrvcscYYpFhhSKBhFEsQNrrkUpFTMfbtkTjwXGLAitBDlobsbUkuEJQwzoQUnzFejzuWyErbVRYOFUJuLYawCxEBboWNNwKonMXPiqjsdcQBfMDIkodXlJfxgcQAcwpmRdZRHRgDFV");

    for (int AegQGhWM = 189535988; AegQGhWM > 0; AegQGhWM--) {
        jBoyFFa = TsAzpeiuql;
    }

    return UqKTCMDIdmnKuZ;
}

int YIEcQKTkFoEGEBj::jphjOsNpyzjLUoI(bool OBWYngpyfatmMQQu, double HaAMj, bool NQbBB, double LxPnxCxZ, double dZNpYdfq)
{
    bool ezgtL = false;
    double hwyvipoUCbOzoX = 332609.9942069174;

    for (int IjRLkRl = 1872149380; IjRLkRl > 0; IjRLkRl--) {
        continue;
    }

    return -1938609464;
}

int YIEcQKTkFoEGEBj::OxdIyctr(bool rImZNib, string YVuzamVX)
{
    double cwTBELcKDnQAB = -981071.9533327312;
    string FuDpcfThZZ = string("xdiFPrMwSmcPpgISGXycooTgFfdDxDVDopiQDQvVdgwitAukQEGMvNWbafhcGOwhKROsatvrfRwpnulrENMszGsCsdymjqxnRXXhQGxSpJTCmMXPePqjZostiMVURuRzaCBGaHtMhewdlOubBGmqjpoTootqSSxgVSeQAKefZbUlAYAZgoRoZmFQNSAwlvkLoGUzmhEAOhVFIxjKCuVxZWObdJFozUbHPEWcHSDkXkzAcQeMd");
    double RhgqvfSjWZZOqFBc = 1007413.345358873;
    int pVBfSR = 614466217;
    string MmbAbjcpHIy = string("XKKjudytMDkNUZwGgqBvRKXTgryvBTwHRprkrJdNkdiXbXWooMBNvFqqwRGFyTyPeJnmkjHgleksrCwnQIbZifzEBiTexpZrcSkmoZdiTRVhdHOqYeLOttWJHMUgqrOJItCefdVmMxYQzdSuFqDn");

    return pVBfSR;
}

YIEcQKTkFoEGEBj::YIEcQKTkFoEGEBj()
{
    this->XoCNW(string("RIsrjbRjRByFOCdmZeezggwRhaKRQPAOeqFNANiwZCvlljssgaGFLkonBCVbKKlYPDlxHuqPvdGSvyknosRbscgvjlxiRMONhNrmgpILsmWoCJJyaCAqYNMrFQRBGBtKJQOGUSmsoRllZgNqdzRaFBkOOQRPesqmPaDMHokZXCJIcBZMUWNWyKfTdtxXQwLqfzMYizlcXZCfmyONySxnUzHWZapfCWFrtMGtoaDUzREVOQuMYzWqEdtFvMYlYm"), true);
    this->NvYjowuuZpk(459833.8968615121, -165695.91036419492, false);
    this->ZQUUSJj(244110.6293127742, true, string("GUwiMWOfYBkllmOEfXflLHM"), -364534.6814224696);
    this->cNPJcNUTkjkqnDT(false, -1114835922, string("NijpXAfHZhsQhpknPdaZMOhSqIwIiicBjcbyeoSfUJvdBKgsCRaqeRRDlpWxXDdZsOnpcBRLKLNzPJldDLpAZcCGPAL"), -647952.601079855);
    this->tXxIS(string("XFkHqYYtPZnNHHiZabISoSqxoviwmVmXkmSTYsnDDyC"), 89779367, string("XfPNyrCzLFBdVauKmoYIBAykXQzIBOmbsmJBhWLgblYTeOdPOIbsUtakUzLTRytcXmdEwpIprgWUUTbHZAwQUwLROUmwaeKciKpQeHDTTBCDBNRhOfzqVrsrtoXsCPK"), 1014570958, false);
    this->OdJActoSmge(-93771.20705906545, 1742980304);
    this->BBWjjoNtvbcW(1559134346, false, string("pAPrvKmAwzgaXLNptDTpmudMmNItCDwteKZtFMZgPajLurvyayGiMWzyRwqpuFINwiVjZTVOKTsOef"), false, string("JecPjqtrDSebNXtmHDKpzrnDuEtiLFyGNjgHFgnLidYZOWQEAgsLdHauJGshTYgAiUYTumBaZampCqgLELbUUxZFBjnfpzbHOzpnMiuHeKmlwqFlQhURxgffvafHcjyZavqEkywWqWpsxmpEZaWuTylyOfgPxxAsXYQgrJcOpsEQwBXYXwDIngHcRxjvAYxWGArhPHoKXgWMVpMlesAuruDZmVorTqClNPjgYhDjLvGmMBfeQuJloFVpLYY"));
    this->GVsvlNkfxkRUkIv(971513.2588057781);
    this->ayHfIzxncYc(string("OdReCwqKbCDnRfSnzbHDQJifbRiTkWJyGYZxwODrFLuajmjiyRxBFBlBKrmTuEHLrwVKUMeqNcHeHcohSejqRYqjIkpZRBNuDndzjdTkBBgYAaFAmYQedfwDxJVQdiBhWqDmakZkpDFBtaSZiMlSvNfMCVNJITZCpJOmEUu"));
    this->KYvLCWDB(-847342772, 891735.7382593523);
    this->oEJlmzWfglqm(-802341.6249751407, 1011027.2350112603, true);
    this->rHyLNCTWrSbxyO(-347134974, 1045662125);
    this->xnsZGwGmpkRFILqL();
    this->ScGUGE(true, string("QIDzTlIVTaSPMSpDYvjRwOhQqLwvshhzWiLAxhPJdsIMgXekMmfJUbHGsLkXPIYgkqhctWAjvopToPjhSaQcfkgMIVCndpXTLHJQetDlYEZYEJmcNOBrEnJcqrblgmWXsCjePIjSbVkQlgfIrYZuPLjnSdfDIFlsTzHRDDkwaqhYXmJAYASlKfFbJNsVOckvtdHjm"), string("VqNJaHjTXEldLhVacsnjIxQyEnGBZdvwIksAeYLrUlYtEXScUsRTyLOoePXslnDYgtkwRzwlmcnFfMTOXhSlpsNDjRhQczLEKZoaGFhyexqCVipAqaMXlZfRBErKwFnfLYGpolrkvSaxkmlXVJJ"));
    this->kjXBgzKH(false, string("xJxWivDvQrjSPFjZuGwprvFVfqWOxlPiiYDDOsuTbdW"), -162321.8664492418, string("MifqgsOUKETVbGRVmhfgBXObcgCPcHczvmCEVrxZHUwnyuaTCYjwdsfnugZoKdGrHEtEknygALDOkwmSZKVLQjjwmAPqaduhHCkdpJrsplpaARasaehbkkFnqiIQaqBiytisspHgVyTyrypXclkkmJaWRjhwinldviemhwagiInyqtcRotUaorqvaSYZDbcxHdkYKuvXZrkmTUSLnVajnAGbKCJgvNUVBnXLknbipyXzKQqSMUvKEWImw"));
    this->efMUgmbg(-1768592292, -1333469199, -911760.26168414);
    this->ZjOTIbVtgetThU();
    this->jphjOsNpyzjLUoI(true, 1038444.4949723207, true, 599171.1925821578, 406833.3130918209);
    this->OxdIyctr(true, string("SyIBNBOrazRJfyiErwoXgeDTikXSSkelYevLuhvPcxUwmyTHSJJNBVbNblSIJxFjZjJFOVjxYkDuUCzCAildlaUHPXpQKfBjsyNEYlAnfNmxhHkvRbBQTsKSVvTfktFERDSuSrXKgsDdnmqHdrbRFKXGCdQAiSfYGRHRtiPEdHUoVzxqQMzLWbwFniOPPbqbZaRfiovEIVpGIdhAsgXriGvrHrgsIZvrTYsvuqiYdoIPfUtJNuvI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IEBkPNOctSLVpz
{
public:
    int CoJhv;

    IEBkPNOctSLVpz();
    int bkPBDYisF(bool agXrwnCcgbssit, double pmOhefJogYqBNK, bool cQkxMkwmlpVzfg, int mkQNpexeUi);
    void dyjqvtbHI(double efpBUGggOFYzgxg, string jCwZbTiFYEywbZLb, bool cDkOHtmNXRJBQG);
    int PSVACTWcID(bool gjWZl, int KdAMPAiPAeuID, bool vQhTVXxSZ);
protected:
    bool MKVRwELojZz;
    bool kKEWofZG;
    int gJPvdBuzp;
    double cdJFZEljrK;
    string glEVqNHx;

    string ZzjzzwSv(bool MEFWCtmlsKA, int mNokPk);
    string pEDuwkPW(double vPOtSVyfExPtmLlN, double wMvnhvjleM, double lQBmH, string HtnjJOGkPIiO);
    bool hGhceAGyKpBLXnmo(string cGsVxpCWqjzZ, string EFrWR, double ZTHnbQCIHY);
    bool BwLwDVmNLQuf();
    string CIHGX(int GkhcsANarieBEKa);
    double HsLCrXdklxot(double abFVhNtg, bool sqDbl, string EApCdlbbqgCdXg, double mqGyXDPFMWU, double USmbUactO);
private:
    bool nrPUtRGWeIUWe;

    string fEYKIoAKrNKTQCft(string gAYedqIlsh);
    bool MjlvxMPBbvBraEq();
    int lJRoqHHoot(bool DZoSQ, int bMOgJhOZYbnuyGxP, double ZYYgygVcEAQu, string PnhSj, int WZmhUMcpgombul);
    int WPGMttZzdOXOw(int lBTOYYbwQlZEeXU, double tjOYPIPjmIayHt, int lbIRrKOqGwXAag, string TPfcZcjrzHCqm, int oZCsPE);
    string cscUg(double UJbYiZRph, double OhCZlFvFWecgyFiy);
};

int IEBkPNOctSLVpz::bkPBDYisF(bool agXrwnCcgbssit, double pmOhefJogYqBNK, bool cQkxMkwmlpVzfg, int mkQNpexeUi)
{
    double QTKtNSfJbxsDYTtI = 222576.58410946315;
    int GzXWXxXbnr = -1311682801;
    int hCNudgKAT = 1177683287;
    double IafnxhTrtOoZaas = -267889.3545646878;
    string wwGEjtJWIZ = string("SoeXTjIcvuVVwLDAYuQbUotpGpRYOyaxWsDXVYSKXDDeJKNcDUxXDIxcORYJOPctAScPflecngqyBfJgGEnXXfcdIUkDSbJZwYfNCDZEbfNjHVXJKBeqxYfksNwyaIDvcyxzqTnOpRozwypAPCZmxbGwzhxmZtUbgnZK");

    if (pmOhefJogYqBNK == -267889.3545646878) {
        for (int pKaUcPyxMTMXnc = 2134748127; pKaUcPyxMTMXnc > 0; pKaUcPyxMTMXnc--) {
            hCNudgKAT *= mkQNpexeUi;
        }
    }

    return hCNudgKAT;
}

void IEBkPNOctSLVpz::dyjqvtbHI(double efpBUGggOFYzgxg, string jCwZbTiFYEywbZLb, bool cDkOHtmNXRJBQG)
{
    int ePWpBhWR = -291342049;
    double gKZsiQESlqFrdHW = 521869.76314059575;
    int OHqLBVj = 1481047640;
    string acvBFXKuvBXX = string("MbTsPPgLvnvgdaqGMpSGfcVzQdcgKcaobyjtwlqtmgfFRYeGdOlorOHHSmRZqDZrldGLQsWrQcQkYozffBWEGvhbjzCOVgnLQkDZmSGzVmtyzGQWjgxkWksWUuvLKfmPjshQYTgsBkpIevWZWhrRfnUyvnemhsfvEKHfmlsqPqbKVXJhouLpBOHCVCmizSnMvwLgjamPJFzoAOfaMsjpJKeCIfgERpf");
    int QWgsEDtPYTwQnAm = 8439475;
    bool WPBZIUbGmtlK = false;
    string qInNKxbxmknN = string("nWIoGJiGkjaeYmcKsVPPzLRbZrCRdDTLCHvUZLZLAqYbpJoadejtJwCNPSutPaoouiSeacNHdKFrYZrprmajqJLyOMoSEkYKWkVesPObCNXjcmWGnkAuPFLNTkIdleVCdUhWklSFfqQdlnEvnheEJqHyPrsvhvLWrEGwKPCby");

    for (int VZyBVqKdZrIk = 484161130; VZyBVqKdZrIk > 0; VZyBVqKdZrIk--) {
        acvBFXKuvBXX = acvBFXKuvBXX;
        OHqLBVj *= QWgsEDtPYTwQnAm;
    }
}

int IEBkPNOctSLVpz::PSVACTWcID(bool gjWZl, int KdAMPAiPAeuID, bool vQhTVXxSZ)
{
    int LtMeMW = 720881147;

    for (int gaCRyRGXVZmqTu = 1871672487; gaCRyRGXVZmqTu > 0; gaCRyRGXVZmqTu--) {
        vQhTVXxSZ = ! vQhTVXxSZ;
        gjWZl = ! vQhTVXxSZ;
        LtMeMW -= KdAMPAiPAeuID;
    }

    return LtMeMW;
}

string IEBkPNOctSLVpz::ZzjzzwSv(bool MEFWCtmlsKA, int mNokPk)
{
    int DHDlHSZtkJL = 1631063472;

    if (mNokPk != 73384529) {
        for (int PRSwxUKjkUMfJ = 1005063163; PRSwxUKjkUMfJ > 0; PRSwxUKjkUMfJ--) {
            continue;
        }
    }

    return string("vmmhaXmRooAXWOfvxdMuquqvoCdSpOeRzmrnEhMHVLEoRHNaoRnrOQPLbWuquEEmKfFuDnRGojsaZjgDeKxNZubtbocNvfCQJTOpIbsvxjwgHkhBgUpKpSYNyrTjwmbgRUEEFTSLIJsfUccIepXsBGdJuPBUAJNHuLePJHbGZCoMeCEmYycWTeyinJLqybDZRKAFHVoRgntUBUVyIaSQKU");
}

string IEBkPNOctSLVpz::pEDuwkPW(double vPOtSVyfExPtmLlN, double wMvnhvjleM, double lQBmH, string HtnjJOGkPIiO)
{
    string ZhqontVoCVMGvG = string("jGudbRWzgzIDpgqzYQJxEbfStVtdLsBGTfLIZMeiaAazStvrlfzdHmPRuVAWPXvmhUmkrCBaZIVNkzBVpDjyXAHlXvzPWxFGgypsykaw");
    double pEAsOevASCdioTZk = 533632.4819988578;

    for (int NvOdKKzEicbBRqUl = 352387896; NvOdKKzEicbBRqUl > 0; NvOdKKzEicbBRqUl--) {
        pEAsOevASCdioTZk /= vPOtSVyfExPtmLlN;
        lQBmH += wMvnhvjleM;
        ZhqontVoCVMGvG = ZhqontVoCVMGvG;
        vPOtSVyfExPtmLlN *= lQBmH;
    }

    if (vPOtSVyfExPtmLlN == -1034200.515975639) {
        for (int UrIjXJozfBMocM = 1458625822; UrIjXJozfBMocM > 0; UrIjXJozfBMocM--) {
            lQBmH = pEAsOevASCdioTZk;
            vPOtSVyfExPtmLlN /= vPOtSVyfExPtmLlN;
        }
    }

    for (int WemUYancX = 1873028259; WemUYancX > 0; WemUYancX--) {
        lQBmH = pEAsOevASCdioTZk;
        wMvnhvjleM /= wMvnhvjleM;
        HtnjJOGkPIiO += ZhqontVoCVMGvG;
    }

    if (wMvnhvjleM != 864696.5460996693) {
        for (int fttrckOkETpv = 663949261; fttrckOkETpv > 0; fttrckOkETpv--) {
            HtnjJOGkPIiO += HtnjJOGkPIiO;
            pEAsOevASCdioTZk += lQBmH;
            lQBmH = lQBmH;
            pEAsOevASCdioTZk -= wMvnhvjleM;
            wMvnhvjleM *= pEAsOevASCdioTZk;
        }
    }

    return ZhqontVoCVMGvG;
}

bool IEBkPNOctSLVpz::hGhceAGyKpBLXnmo(string cGsVxpCWqjzZ, string EFrWR, double ZTHnbQCIHY)
{
    int DUlgqpoUGsdKo = -242333944;

    for (int eQQoAKTlTezsZ = 1812468173; eQQoAKTlTezsZ > 0; eQQoAKTlTezsZ--) {
        cGsVxpCWqjzZ = EFrWR;
    }

    for (int OIRAEzfhsaPWSh = 1898236326; OIRAEzfhsaPWSh > 0; OIRAEzfhsaPWSh--) {
        EFrWR = EFrWR;
        EFrWR += EFrWR;
    }

    if (ZTHnbQCIHY <= 185445.3130655048) {
        for (int DqCZOyXxKwoNhJa = 1890966514; DqCZOyXxKwoNhJa > 0; DqCZOyXxKwoNhJa--) {
            cGsVxpCWqjzZ = EFrWR;
            EFrWR += cGsVxpCWqjzZ;
        }
    }

    if (ZTHnbQCIHY > 185445.3130655048) {
        for (int RSjKo = 1757089877; RSjKo > 0; RSjKo--) {
            continue;
        }
    }

    return false;
}

bool IEBkPNOctSLVpz::BwLwDVmNLQuf()
{
    double WJRcwTZMz = 880106.867986544;
    int mLjEnFkkqafIcKHQ = 464668705;
    string njttfZ = string("yWyRToAYZOejOUTQsVdpeibuAbhKuWvBCHKCAvonExjDTsLOlLObPbThNiIREzQsIZCmfukcYTspIRfBsHRSYjfaiegLmhkdWaKZCldWWcspgOXJzkvDkILWDEaNwkToDqHRykQdoxWBbxrEOnbSRyQlBRIhGqxRSXLdjlOPQc");
    string CyGSaPeiXVrjcdg = string("IhzDfUaZWi");
    string GDeuHqUb = string("oDnpBefefdUuxyrznUzIsiKZvCzYhXaRLcZRTPATvnuSLSTtTruENfLjLPeAifMJjMQHceNRnjOrfjDldgzkHWCitCTCyKXQyddvdAruxJrqDJfEgFerxTxzaQDfDrhueeqIBBFnwTAYFoZCGoEbkNsrpZkzdDzsClDTDIwmnUUiLobPXAElPfKjnJPbxwoAAkvznlXErqlKxxgcILT");

    for (int EFtNlPzEJYJPs = 1250300598; EFtNlPzEJYJPs > 0; EFtNlPzEJYJPs--) {
        WJRcwTZMz -= WJRcwTZMz;
    }

    for (int gWxqf = 1579911094; gWxqf > 0; gWxqf--) {
        GDeuHqUb += njttfZ;
        CyGSaPeiXVrjcdg = CyGSaPeiXVrjcdg;
    }

    if (CyGSaPeiXVrjcdg > string("oDnpBefefdUuxyrznUzIsiKZvCzYhXaRLcZRTPATvnuSLSTtTruENfLjLPeAifMJjMQHceNRnjOrfjDldgzkHWCitCTCyKXQyddvdAruxJrqDJfEgFerxTxzaQDfDrhueeqIBBFnwTAYFoZCGoEbkNsrpZkzdDzsClDTDIwmnUUiLobPXAElPfKjnJPbxwoAAkvznlXErqlKxxgcILT")) {
        for (int EDpEKrQv = 1276494519; EDpEKrQv > 0; EDpEKrQv--) {
            mLjEnFkkqafIcKHQ *= mLjEnFkkqafIcKHQ;
            GDeuHqUb = njttfZ;
        }
    }

    return true;
}

string IEBkPNOctSLVpz::CIHGX(int GkhcsANarieBEKa)
{
    int noFyj = 1422738294;
    bool rCnGYNTUFI = true;
    string IpxTEhgOFLzg = string("LNKfWtQUqKsglqZMqGWsgwwdNUmuTzjnIRTMplWJJeYAzdhVmeNQMNVhzDqQteHsTkoPGqWtWkQUKxwmXFvpdYawMYhUoPnDrZBwsvRyxmmwBzVOGkXKoAElDJIkFhhBgOPSAXzzqPEvfnwWCTwDbvgUR");
    string BUfWQC = string("fSnFVeOUhWfSdRKpxiAjKdFUjGgGKAwyOAvZBredTQtvrpLThYitBghaYREHpDSkwevSakFKWuXrpPvFdwicUYMrNpEO");

    for (int UiVztxClbSXUy = 413274142; UiVztxClbSXUy > 0; UiVztxClbSXUy--) {
        noFyj += noFyj;
        rCnGYNTUFI = rCnGYNTUFI;
    }

    return BUfWQC;
}

double IEBkPNOctSLVpz::HsLCrXdklxot(double abFVhNtg, bool sqDbl, string EApCdlbbqgCdXg, double mqGyXDPFMWU, double USmbUactO)
{
    double WmqoJI = -578194.0963855704;
    bool SCoqbWYJHcxq = false;

    for (int PHGsNx = 853335532; PHGsNx > 0; PHGsNx--) {
        WmqoJI += USmbUactO;
        USmbUactO = USmbUactO;
    }

    return WmqoJI;
}

string IEBkPNOctSLVpz::fEYKIoAKrNKTQCft(string gAYedqIlsh)
{
    string EqggWGdWIGhwD = string("AnzebuoILzaLKJbgOqnXKTnnmToZocjnUBIXhEWwyGyhfJIepxtrYvDzrbTMzsfKJObTOTkhWyioQuLFGRXCuyoCzNalUXbJBvSIcsQZqhVTyCrFSnCHPPEoivRJWwTiDWxNlLCIqfXnPTbnbQcnsHdYeXXWGlnBReVPqavCDJkVGYHMSQHshupdLFpiFoJMVkOERVomtXJUNt");
    int DOuWRjG = -1511721249;
    double nMYwXHsrnjlm = -287936.14266860543;
    string dxQUKZyVXeZ = string("HxNuzfUNmUdVUMMtBFBYYPhYBHXFRDkzRkRoHKHkIUwFbNEWckFdzbRmwAReqNIuIFiZOUijSbCwoWoXKdjudGOuyxCNFHxhVqbnNoPWAJvcCwCwCDcYPXPVnjqCwSbyZcsyrszeSZPmWujrnyZSXlCnMZEuHiDgjlEsoFNJzwWiXUfllPBRnUPPKjqBYaAvwiSlzmGbsHgnxmxHmWkwClUYFsKEnHysaCuuJotKVVMRqFdbxOcPhFXgZIb");
    int IwgBFPdIQSoDaWp = 1140817881;
    int sOxHcZXsA = 1523302945;
    bool yvlHBJArutsZnh = true;
    string cycJOgaJR = string("qEIyyVhhhoCTTKJJrQPqXEabquQlTpCxBvwWYIroayqiXsutyJGAxxfyCtzPEnsnLDCWUYbjaWlhRsXquqiiGYExVhdjknEVbeNGmkIIwXBnpvXvtqLKXkkuMqVzSBgDYlgxmFTaLsMCDquPjCnspjFKpYFLZQnbQgdncUYKssdCnRlzxgpUFhOToKodUYhkdKTLVXeSQQXzhiwCkddqGtXLWHsaRXqGXWoKOPFMytHIlicPNbNNyHC");

    if (cycJOgaJR <= string("HxNuzfUNmUdVUMMtBFBYYPhYBHXFRDkzRkRoHKHkIUwFbNEWckFdzbRmwAReqNIuIFiZOUijSbCwoWoXKdjudGOuyxCNFHxhVqbnNoPWAJvcCwCwCDcYPXPVnjqCwSbyZcsyrszeSZPmWujrnyZSXlCnMZEuHiDgjlEsoFNJzwWiXUfllPBRnUPPKjqBYaAvwiSlzmGbsHgnxmxHmWkwClUYFsKEnHysaCuuJotKVVMRqFdbxOcPhFXgZIb")) {
        for (int WnjYwqjJvaUedjiK = 1098230165; WnjYwqjJvaUedjiK > 0; WnjYwqjJvaUedjiK--) {
            DOuWRjG -= IwgBFPdIQSoDaWp;
        }
    }

    for (int VSHGhQgh = 1077771595; VSHGhQgh > 0; VSHGhQgh--) {
        EqggWGdWIGhwD = dxQUKZyVXeZ;
    }

    for (int xDyHF = 555162271; xDyHF > 0; xDyHF--) {
        cycJOgaJR = EqggWGdWIGhwD;
        DOuWRjG *= DOuWRjG;
    }

    for (int IaiHqxWmeOp = 1974319019; IaiHqxWmeOp > 0; IaiHqxWmeOp--) {
        continue;
    }

    if (cycJOgaJR <= string("HxNuzfUNmUdVUMMtBFBYYPhYBHXFRDkzRkRoHKHkIUwFbNEWckFdzbRmwAReqNIuIFiZOUijSbCwoWoXKdjudGOuyxCNFHxhVqbnNoPWAJvcCwCwCDcYPXPVnjqCwSbyZcsyrszeSZPmWujrnyZSXlCnMZEuHiDgjlEsoFNJzwWiXUfllPBRnUPPKjqBYaAvwiSlzmGbsHgnxmxHmWkwClUYFsKEnHysaCuuJotKVVMRqFdbxOcPhFXgZIb")) {
        for (int PrnTfCbGG = 1891351427; PrnTfCbGG > 0; PrnTfCbGG--) {
            sOxHcZXsA -= sOxHcZXsA;
        }
    }

    if (DOuWRjG != 1523302945) {
        for (int qkpZCYbPibgvhk = 736604808; qkpZCYbPibgvhk > 0; qkpZCYbPibgvhk--) {
            EqggWGdWIGhwD = cycJOgaJR;
            dxQUKZyVXeZ += dxQUKZyVXeZ;
            yvlHBJArutsZnh = ! yvlHBJArutsZnh;
        }
    }

    if (EqggWGdWIGhwD == string("AnzebuoILzaLKJbgOqnXKTnnmToZocjnUBIXhEWwyGyhfJIepxtrYvDzrbTMzsfKJObTOTkhWyioQuLFGRXCuyoCzNalUXbJBvSIcsQZqhVTyCrFSnCHPPEoivRJWwTiDWxNlLCIqfXnPTbnbQcnsHdYeXXWGlnBReVPqavCDJkVGYHMSQHshupdLFpiFoJMVkOERVomtXJUNt")) {
        for (int attHlhGYoRZZHzCs = 663848277; attHlhGYoRZZHzCs > 0; attHlhGYoRZZHzCs--) {
            continue;
        }
    }

    if (cycJOgaJR >= string("HxNuzfUNmUdVUMMtBFBYYPhYBHXFRDkzRkRoHKHkIUwFbNEWckFdzbRmwAReqNIuIFiZOUijSbCwoWoXKdjudGOuyxCNFHxhVqbnNoPWAJvcCwCwCDcYPXPVnjqCwSbyZcsyrszeSZPmWujrnyZSXlCnMZEuHiDgjlEsoFNJzwWiXUfllPBRnUPPKjqBYaAvwiSlzmGbsHgnxmxHmWkwClUYFsKEnHysaCuuJotKVVMRqFdbxOcPhFXgZIb")) {
        for (int bsPWCmajPZLN = 820310134; bsPWCmajPZLN > 0; bsPWCmajPZLN--) {
            dxQUKZyVXeZ = dxQUKZyVXeZ;
        }
    }

    if (yvlHBJArutsZnh != true) {
        for (int fVPPBtnZu = 1902456179; fVPPBtnZu > 0; fVPPBtnZu--) {
            nMYwXHsrnjlm -= nMYwXHsrnjlm;
            cycJOgaJR = dxQUKZyVXeZ;
        }
    }

    return cycJOgaJR;
}

bool IEBkPNOctSLVpz::MjlvxMPBbvBraEq()
{
    double bnpoHK = 205268.05128928297;
    int yNLntqcPUFsyhZCr = 1057494374;
    bool tcaedgpNsW = false;
    string xZRaXiuwFWLsUwF = string("vkPhCMYrXRhRowueFiNsVxqbTxCQZLjmQyYCSxPgrCvTKIHATcLSLsVxZvzHoeSZoCiDlrLmUxrkRxsbL");
    int kRmhQbUDVRzOOcA = 2011636850;
    bool XqZJxqWoN = true;

    return XqZJxqWoN;
}

int IEBkPNOctSLVpz::lJRoqHHoot(bool DZoSQ, int bMOgJhOZYbnuyGxP, double ZYYgygVcEAQu, string PnhSj, int WZmhUMcpgombul)
{
    bool GRScds = false;

    for (int EcoMNj = 2125954838; EcoMNj > 0; EcoMNj--) {
        GRScds = ! DZoSQ;
        DZoSQ = ! DZoSQ;
    }

    if (DZoSQ != false) {
        for (int ACXrHzFcUE = 39265431; ACXrHzFcUE > 0; ACXrHzFcUE--) {
            PnhSj += PnhSj;
            DZoSQ = DZoSQ;
            DZoSQ = ! DZoSQ;
            DZoSQ = ! DZoSQ;
        }
    }

    for (int azfhjxACmsq = 1521753823; azfhjxACmsq > 0; azfhjxACmsq--) {
        continue;
    }

    for (int ZFuCnyUDDcgbuM = 594979875; ZFuCnyUDDcgbuM > 0; ZFuCnyUDDcgbuM--) {
        continue;
    }

    if (WZmhUMcpgombul <= 1267634284) {
        for (int vFVRe = 753863009; vFVRe > 0; vFVRe--) {
            DZoSQ = ! DZoSQ;
        }
    }

    return WZmhUMcpgombul;
}

int IEBkPNOctSLVpz::WPGMttZzdOXOw(int lBTOYYbwQlZEeXU, double tjOYPIPjmIayHt, int lbIRrKOqGwXAag, string TPfcZcjrzHCqm, int oZCsPE)
{
    bool CyTxHBzYhEpE = false;
    bool Enyyq = false;
    double UPYqRVqgM = -605746.4709890011;
    string CiWsfm = string("KSugyVbqptzvPuqrBEpnZcGNQBUdjCLiGQMkXICrHFbaQDDWZVlSRKynZWyoIKZahXTDhvccQpUGGseXEywdHuTIqxAuGzbwYXDdTScILstuPxsTmdgnGdfJDTTftTfyKMuZMFBimMqodOWwBzgqiicyBdSbqzpbaDxeYEnuVGzSFFpdduXCqvqUIGhVIZQBzicvTHiQnoHPqWMyeMZRruwBfYLmzMsPrZKwbSgi");
    double pfvFNQ = 414493.081777285;

    for (int sFJRNOhDvW = 654516618; sFJRNOhDvW > 0; sFJRNOhDvW--) {
        Enyyq = Enyyq;
        lbIRrKOqGwXAag /= lBTOYYbwQlZEeXU;
    }

    for (int JwUGycPS = 1433470984; JwUGycPS > 0; JwUGycPS--) {
        continue;
    }

    for (int uUngLrMVSCd = 1570460190; uUngLrMVSCd > 0; uUngLrMVSCd--) {
        continue;
    }

    for (int uORfphnx = 340101112; uORfphnx > 0; uORfphnx--) {
        continue;
    }

    for (int hMVrphVxadMQo = 1299043293; hMVrphVxadMQo > 0; hMVrphVxadMQo--) {
        continue;
    }

    return oZCsPE;
}

string IEBkPNOctSLVpz::cscUg(double UJbYiZRph, double OhCZlFvFWecgyFiy)
{
    double JNVpw = -1029509.4653556155;
    int xNHuvQEgHN = 679241545;
    string eVcPJuMcRkDZMa = string("qJVOWrhxIGLmzfelOSVMHOFpCqLAlLqtgzVQFNlbiJoHMeatBAxBOojyynNBdGKSvbJeWyFeokZCdsJ");
    double VbjBDtve = 870187.2303623614;

    for (int JgJrjLTHKtlA = 1934633467; JgJrjLTHKtlA > 0; JgJrjLTHKtlA--) {
        continue;
    }

    for (int ZgCmZorP = 407478284; ZgCmZorP > 0; ZgCmZorP--) {
        eVcPJuMcRkDZMa += eVcPJuMcRkDZMa;
        OhCZlFvFWecgyFiy -= OhCZlFvFWecgyFiy;
        VbjBDtve -= OhCZlFvFWecgyFiy;
        xNHuvQEgHN = xNHuvQEgHN;
    }

    if (UJbYiZRph != 441618.58994736936) {
        for (int HEtRg = 1581182516; HEtRg > 0; HEtRg--) {
            OhCZlFvFWecgyFiy *= JNVpw;
            UJbYiZRph = JNVpw;
        }
    }

    return eVcPJuMcRkDZMa;
}

IEBkPNOctSLVpz::IEBkPNOctSLVpz()
{
    this->bkPBDYisF(true, -891566.0303901692, true, -1154158748);
    this->dyjqvtbHI(560363.3251811758, string("BpmZuLRiokLFYMWsOBQPUUVXFgLvSZZbpgawoIXZVLQyVAeMKieDcouaNnSmRIUolCnmMeyfdYtJfAvSVyzzGKoQKvYgNAmSKhopFRVQqDOejsgXonqNWNKqXXPbfzztcKUECTwkExhdkyBtYdlofwRCAhCBSbXjBVvYpNxeQlyGfZORsAZlPSrweGJAluZrZBgGcl"), true);
    this->PSVACTWcID(true, 1970701118, true);
    this->ZzjzzwSv(false, 73384529);
    this->pEDuwkPW(864696.5460996693, -1034200.515975639, 610673.6084444055, string("TiSQfOcoAiqkbAWOaVPYNPyXhVBEjUVHTlNJbziHGUAmZfjvb"));
    this->hGhceAGyKpBLXnmo(string("WVyhPygccOvxNtKriKqIJxpSsSzAzdiNiTobVtCkoNdPlJZdzXoWJZhIJNVreOBITGgbSCoGLHeHAWEzkGnVJCQBMDscnJPSWRIQswzCBdnWqlpiXoDOyhzNbBjLVsUkIbfcnYYEVrNmciIfhWaGmgrdYDzFHjWeqFPVElMukiOkcpNgiCDNUAWHlUiBjgSMQSbOKeXdbKCZpMBmOWQdvZvWbqzAeNKPsDXxyjiZN"), string("BJsHpYzzHHWFMXBjKUuFcxuArYqKYHWSuJMZVRoiRvGpJVjGVVnHhZRoCTSrvfpisDMpfooSOBoOitzkfNWdxdOMvnINAMUvkTsoDnPgWlnjImFcQkljBbHdXtCdJalFWyIVZTiiYsDBQJdHSxYuZWdxKRUdzpMRgSnChtfaGaaMeiOFqwsGKWuCnSRPAtXKMYiPuuQozJpTRWpDSgSEYauHDRlxVIRNyaFCYZl"), 185445.3130655048);
    this->BwLwDVmNLQuf();
    this->CIHGX(1860764061);
    this->HsLCrXdklxot(166895.17046210705, true, string("uvIFfnxkvIwskNCNlwmfoAWRuToxbKhikelJXmJAPIGIaCPxzZSbgNKmbfMnPMBUOFAoWveMFgdUkIGPJFtvrgJSMgcrlvNBVJzrQlZHwHlYARQwsEwrOiYtQoXnWDvijvpDhIkiqD"), -776278.9147731712, 497686.8162677417);
    this->fEYKIoAKrNKTQCft(string("WzvbOxTXUSojAVoFCtKOtAxpJDdEwzssoOPabjNGvFtqzzakdlqRwtYxTOcsSmLsBjJrGqvgyXrZAoLpaYZXjmyRRILDvsoSNQiSbBApMBwFVuHNzCQrdOdyMbNtoqpHUgPK"));
    this->MjlvxMPBbvBraEq();
    this->lJRoqHHoot(false, 1267634284, 981808.8106582754, string("bPHNjDNVQDBdTIrSChjdHCTzZZYdhjWaguoiRTwgZqKbIvyAERVfDFsNUqCYQbfEgYhiIxBtbaXxPOtAe"), -830306691);
    this->WPGMttZzdOXOw(-1394301929, 916279.5771531347, -989120457, string("MoCpXNKJllzALmPYgddfHUbeIGvfUSHmKFjcysouYKKhTFBJhWXcyykBbZDQRYOvuVdfdAUZAnHgpizgAHHQIuJBJjieRZcVeyJZjOkkUNjdHPlERiSCezPQdM"), 1519827144);
    this->cscUg(-110603.08556821768, 441618.58994736936);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mDiwDPZoNDZbiJv
{
public:
    bool lyJezSuthTtTUt;

    mDiwDPZoNDZbiJv();
    double RNHICGueIbm(double omZEwszKDpGJMEa, double xOZuPC);
protected:
    double CXVAkgcHViUt;

    bool SotIfNnmccILTBvw(string RuufZjA, double AfKYOsLIdRShqcyk, string afPWCdxEatrMazeU, double pUnEOsRadCdIKynA);
    void vIGCJqAHLNUnDwa(double daBNOEZvs, string YPebiwB, string XdvlactET, double bxjpQG);
    int LvfUmdndpYiWrj();
    bool DiIfXouylfT(string lMbaQcXJBx, int jTSDi, bool tWndbkERgDaN, int YyCZJw, int vVwzjRDP);
    double FLjhKoDNolNO();
private:
    double ievyPDFhBuIUpzP;
    double zOjzv;
    int kSteGEoA;
    string GcDYClVZWPxlEgPr;
    bool noqpzrStWanruR;
    bool raPjnWkor;

    double GBNIvwcL(bool GqdXkeLFhRqdSM, bool mDcKobV);
    double wogbKMsKMPL(double TFSTMQTA);
    void kQJWSlagir(int oqSeRLGj, double iGtkKfSWqAM);
    double Ektfh(double CdEpiLddgs);
    double DPafQNRXFJtrckax(string LMoVqPL, double FERAqurdcFZxM, double MVndo);
    void uEDbemCrZLOAmyYq();
    void RVssdZdf();
};

double mDiwDPZoNDZbiJv::RNHICGueIbm(double omZEwszKDpGJMEa, double xOZuPC)
{
    int PczXtRPDQF = -1342514440;
    int LyNPTlZnkKYUf = -1719958875;
    string zobYdFbzU = string("nzFGtfnNYYOInqJZqUSzZlB");
    string MorIEqtgPSrmS = string("qJJNPNSnEHtFgFqxbAeTQRDjclEXqHwYqcFjyDWhRCkduoUuIBPRHSJoiYYbwdCyptPvNYrDBMRVwglWzOZhtEEzaPCofsnOAFTVRXLBSnYmACnCLiDDRjWQigFkXLmBQslvvNFwJNOMkqtBjrJQePKKraGBrPWcIcgEwMig");
    bool oCqpY = true;
    double sUZGgazSVvttK = -103532.29547309986;
    bool KfTuEmHaF = false;
    bool PyTaZdaLgVBhgE = true;
    string DizvMiXZVYXF = string("mlEIdvclYRwmTwpWsypzHVTsrnjmDgZRicUKfWFnXetUbPVjArolCCJBtoLMQoZlbAvLanHJcXPKPuNsDgpwFphpPcUBOMXgvxJDZCZMnzYtbhl");
    int wtWEL = -328118128;

    for (int jpYmFhOzNZECle = 1508022715; jpYmFhOzNZECle > 0; jpYmFhOzNZECle--) {
        sUZGgazSVvttK -= omZEwszKDpGJMEa;
        MorIEqtgPSrmS += DizvMiXZVYXF;
    }

    return sUZGgazSVvttK;
}

bool mDiwDPZoNDZbiJv::SotIfNnmccILTBvw(string RuufZjA, double AfKYOsLIdRShqcyk, string afPWCdxEatrMazeU, double pUnEOsRadCdIKynA)
{
    int UUbeXMEy = 1213441405;

    if (AfKYOsLIdRShqcyk > -226088.33161829686) {
        for (int IOsfRsQZGiHtaap = 2076800590; IOsfRsQZGiHtaap > 0; IOsfRsQZGiHtaap--) {
            pUnEOsRadCdIKynA -= AfKYOsLIdRShqcyk;
            AfKYOsLIdRShqcyk /= AfKYOsLIdRShqcyk;
        }
    }

    if (pUnEOsRadCdIKynA >= -272677.217210006) {
        for (int xlWlRDZlQT = 539442041; xlWlRDZlQT > 0; xlWlRDZlQT--) {
            pUnEOsRadCdIKynA = pUnEOsRadCdIKynA;
        }
    }

    return false;
}

void mDiwDPZoNDZbiJv::vIGCJqAHLNUnDwa(double daBNOEZvs, string YPebiwB, string XdvlactET, double bxjpQG)
{
    double pCsER = 592047.4510798155;

    if (daBNOEZvs > 592047.4510798155) {
        for (int lHLYDCyd = 1890632049; lHLYDCyd > 0; lHLYDCyd--) {
            continue;
        }
    }

    for (int FlulblwmraCyA = 1150047930; FlulblwmraCyA > 0; FlulblwmraCyA--) {
        bxjpQG -= daBNOEZvs;
    }
}

int mDiwDPZoNDZbiJv::LvfUmdndpYiWrj()
{
    string gOOrSrYPGZtRv = string("LkxgkFpFKuyoZRWsWoIOBfybomsYTJJMLbeZdWRUCbHIWQppomAiVeGmyjNRricqxtKgpkURyOmLJtKxWsnBYMGxxxbCxSPKOCtVIymlePSFWQvnjkKpIMAHeObBrfFiGRsstDyxdfKbAlKnfPHwwNKYjUiMbcfAsRBaisJKfByIkCdNfsPYjRBxBBXnKHsnYLKmeHNoxZMqFEFzssWyoFMAoWHjahvSxNbTWUNcCDjoEzPgWLbrvNjGu");
    int JrXNPHcdXfqLo = -904870026;
    int ybJbnrIh = 239023113;
    string YhWXDXBYMHhwZ = string("IoeqlVtggpbkNOxgsjDMABrieIFlZedvhVPMMYVJAMgVmkeOIBeNOYvODWjsmoezvCRqSoNGszbaWKkUdkPYMyHszPohycKbKuDyramPZOLljbaaKgPUXBYtMFfzkZlUmCtVCfLofasZXx");
    bool zSPJlDSgMLDakuYu = true;
    int AKqEBEv = 1662990371;
    bool xHDFWHBwacqr = true;
    double TAyXDoXzexx = -440077.33020037005;
    int iLmjULjwv = 1357223575;

    for (int gEmDG = 203671483; gEmDG > 0; gEmDG--) {
        zSPJlDSgMLDakuYu = ! xHDFWHBwacqr;
        iLmjULjwv -= ybJbnrIh;
    }

    return iLmjULjwv;
}

bool mDiwDPZoNDZbiJv::DiIfXouylfT(string lMbaQcXJBx, int jTSDi, bool tWndbkERgDaN, int YyCZJw, int vVwzjRDP)
{
    double SoxoTEfweaQIj = -766593.7806634115;
    double fYZmHMnl = 1033098.0649471759;
    double EyTeTKrMLIbjl = 76953.2057151829;
    string uqorOxgXpCBpaZ = string("WwarclZJorzlMQwamoNAmsUmivfwMfZxfPEytQvvVWDBVMVLOEbpUGCUdtysRIsVdaEuWoCgCZrfrctAUMGHZyirWsSImRHunYokcUXTkXqbMVuCJrwzCOGCtCgVArrOfYEfkY");
    bool DIIMhrC = false;

    for (int mexAxBGeR = 1303420320; mexAxBGeR > 0; mexAxBGeR--) {
        continue;
    }

    for (int VbhwYH = 746064168; VbhwYH > 0; VbhwYH--) {
        YyCZJw = YyCZJw;
    }

    for (int najdhnX = 26528957; najdhnX > 0; najdhnX--) {
        lMbaQcXJBx += lMbaQcXJBx;
    }

    if (tWndbkERgDaN == false) {
        for (int ydkwPHbn = 1647611301; ydkwPHbn > 0; ydkwPHbn--) {
            tWndbkERgDaN = ! tWndbkERgDaN;
            uqorOxgXpCBpaZ += uqorOxgXpCBpaZ;
        }
    }

    for (int aKErirlF = 920816015; aKErirlF > 0; aKErirlF--) {
        jTSDi /= vVwzjRDP;
    }

    return DIIMhrC;
}

double mDiwDPZoNDZbiJv::FLjhKoDNolNO()
{
    double wyZHmfHVXDK = -527579.6304629005;
    int DSGsM = 135346844;

    if (DSGsM >= 135346844) {
        for (int fkdGExGqtf = 810055761; fkdGExGqtf > 0; fkdGExGqtf--) {
            DSGsM += DSGsM;
            wyZHmfHVXDK -= wyZHmfHVXDK;
            DSGsM += DSGsM;
        }
    }

    for (int NUCUE = 1282497777; NUCUE > 0; NUCUE--) {
        wyZHmfHVXDK *= wyZHmfHVXDK;
        wyZHmfHVXDK += wyZHmfHVXDK;
        DSGsM += DSGsM;
        DSGsM -= DSGsM;
        DSGsM -= DSGsM;
    }

    for (int uCeGYPYk = 687366006; uCeGYPYk > 0; uCeGYPYk--) {
        DSGsM += DSGsM;
    }

    for (int nBJPEDJQ = 2032847790; nBJPEDJQ > 0; nBJPEDJQ--) {
        wyZHmfHVXDK -= wyZHmfHVXDK;
        DSGsM /= DSGsM;
        DSGsM /= DSGsM;
        DSGsM = DSGsM;
    }

    return wyZHmfHVXDK;
}

double mDiwDPZoNDZbiJv::GBNIvwcL(bool GqdXkeLFhRqdSM, bool mDcKobV)
{
    int dvSUuylXRH = -1590384094;
    double ViNbKtFqxSW = 875928.1501075632;
    string LkUuhNgGNZXUvnm = string("iJCeoYsnPuDnupBnYAyjQNv");
    bool jytUGYXNoUf = true;
    bool VtmzJugTAcPS = false;
    double SNQUrQ = -698748.4522795151;
    string AwSDDRkNqJ = string("xqWvZxuDWtEziHIEWyyUiGSQvtuPixXeheQgVHVsjxpYXaWvDDJXYgVwWHpIMYWtHPoAhRQpAFXLdBvDbespISbbwhAwmhNypPaBWxqLrPtkbJlkeyoJPIxtIEVSFpHcBePyTJdHtJmjcacgPlVllTiXiFyEfayViQRytdfZcbuJWmHCNybzUOWUbIWwnkCBkWwxnRVngGtLwmBZu");
    string AtTUXbAIfFJh = string("QuLTKJGlGGikdfcxqcoldZHCGOGrTFQBaPZHyoVpuEtEOgsGuPOrNda");

    for (int vlLfNqiZqMw = 582463870; vlLfNqiZqMw > 0; vlLfNqiZqMw--) {
        ViNbKtFqxSW = SNQUrQ;
    }

    if (AtTUXbAIfFJh == string("QuLTKJGlGGikdfcxqcoldZHCGOGrTFQBaPZHyoVpuEtEOgsGuPOrNda")) {
        for (int ehasQiTDby = 830694297; ehasQiTDby > 0; ehasQiTDby--) {
            AtTUXbAIfFJh += LkUuhNgGNZXUvnm;
            mDcKobV = ! VtmzJugTAcPS;
        }
    }

    return SNQUrQ;
}

double mDiwDPZoNDZbiJv::wogbKMsKMPL(double TFSTMQTA)
{
    bool mvQjaDnp = true;
    double YWnrOUZYxYcqbV = 71370.25912289461;
    bool tUhrDFQMrZNbx = true;
    int klqmUbwmwx = 845364291;
    int NPgwjKCjqpcWKSFi = -667120285;
    int EtgSXsUocpyhOWc = 1596146395;
    bool BuaCMkMsFwNbtUr = true;

    if (BuaCMkMsFwNbtUr == true) {
        for (int eaSwSgvqhOFCbw = 1885089869; eaSwSgvqhOFCbw > 0; eaSwSgvqhOFCbw--) {
            YWnrOUZYxYcqbV /= TFSTMQTA;
            NPgwjKCjqpcWKSFi /= NPgwjKCjqpcWKSFi;
        }
    }

    for (int zpiWdDUh = 215682055; zpiWdDUh > 0; zpiWdDUh--) {
        YWnrOUZYxYcqbV /= TFSTMQTA;
        mvQjaDnp = tUhrDFQMrZNbx;
        NPgwjKCjqpcWKSFi += EtgSXsUocpyhOWc;
        NPgwjKCjqpcWKSFi -= klqmUbwmwx;
    }

    return YWnrOUZYxYcqbV;
}

void mDiwDPZoNDZbiJv::kQJWSlagir(int oqSeRLGj, double iGtkKfSWqAM)
{
    bool HTzlsmbUbdbLVx = false;
    bool DXQAxqFuAWBsGIM = false;
    bool MFHvjSpR = true;

    if (MFHvjSpR == false) {
        for (int fLURTubQKhtT = 11917929; fLURTubQKhtT > 0; fLURTubQKhtT--) {
            MFHvjSpR = DXQAxqFuAWBsGIM;
            DXQAxqFuAWBsGIM = MFHvjSpR;
            HTzlsmbUbdbLVx = DXQAxqFuAWBsGIM;
        }
    }

    for (int PLRnAdLASH = 1188388686; PLRnAdLASH > 0; PLRnAdLASH--) {
        HTzlsmbUbdbLVx = HTzlsmbUbdbLVx;
        MFHvjSpR = ! MFHvjSpR;
        HTzlsmbUbdbLVx = ! DXQAxqFuAWBsGIM;
    }

    if (HTzlsmbUbdbLVx != false) {
        for (int phNVSUbkWSoUnwX = 1910375279; phNVSUbkWSoUnwX > 0; phNVSUbkWSoUnwX--) {
            HTzlsmbUbdbLVx = ! DXQAxqFuAWBsGIM;
            MFHvjSpR = ! MFHvjSpR;
            HTzlsmbUbdbLVx = ! HTzlsmbUbdbLVx;
            MFHvjSpR = MFHvjSpR;
        }
    }

    for (int SqjFHlUQVbRsyV = 44239590; SqjFHlUQVbRsyV > 0; SqjFHlUQVbRsyV--) {
        HTzlsmbUbdbLVx = DXQAxqFuAWBsGIM;
        iGtkKfSWqAM = iGtkKfSWqAM;
    }
}

double mDiwDPZoNDZbiJv::Ektfh(double CdEpiLddgs)
{
    double mSYRkD = -403274.2110523607;
    int QUIDyQIft = -1747819747;
    string whochv = string("wmaDdWHQYMPMdcBgdiMsqnRucEFbowBUqgiuZpVqELfZLwgoJ");
    string XPevQ = string("ZiiWnrZSAsDStNGXdEMyIArgtEJphSBmDKbvSiaXVHRGxyELPJJhqgUBSFbWexDyaIvCKGatacbldLQtBvCWRurUTeYoJWJPwiIbnwLbCIUAcccGPGClMNJwWBkMThQVUaDzRazMAZtOESNwZjptFuTSPKKFJkbMVgqhFLQwqFodWMUMAnzOMEjLsMrmzolnNxQGkiWPmIPP");
    int gyLaQROcvlO = -1842770037;
    bool hUbKtyQlc = false;
    string CHJxKfjCbAhp = string("kbSYdnUFcVFWRRfokFCOkegxNABnRtoIHNuOUAT");

    for (int iVMZNerEAAAPYJK = 557839123; iVMZNerEAAAPYJK > 0; iVMZNerEAAAPYJK--) {
        QUIDyQIft /= QUIDyQIft;
    }

    for (int rOioTkascy = 1328193736; rOioTkascy > 0; rOioTkascy--) {
        CHJxKfjCbAhp = whochv;
        whochv = CHJxKfjCbAhp;
        CHJxKfjCbAhp += XPevQ;
    }

    return mSYRkD;
}

double mDiwDPZoNDZbiJv::DPafQNRXFJtrckax(string LMoVqPL, double FERAqurdcFZxM, double MVndo)
{
    string iXXHjraeWlSs = string("MntjnqmWDzoXixAGdPQrnJqynWoWFKILXTbrKqVIaWoDYgJazDONQzkzrEWuNCHShrXcDOVIVpCsPCRPFePKGkJhlpPubBQ");
    bool EOteqCtSoijUSLF = false;
    double pwZQyEfOC = 841553.248267531;
    bool vhJZisBPADGXHIT = false;
    bool QsOEpug = true;
    string EpDtRjXrGcgJEvYE = string("VsANTfJrcfipERzUTxpHURBjjZJUVrbNPPFjVuNCGWBNNRzMhnbQYeDNXihUsRnhFMqtezZCMNIcWmQQXapShTPqdiQGrsDIvpuySuZkmGgtwHqKJSbVQvhJcUTKhJtcCUxRQNSAduypwETMyTqKNGAHamuFEJuKGjaMuSkrzSZcjwtwcmNkRDoDQWHZqXHExzzOAAugejJmYeXWnkZfFISquiLphAjGDSztwBc");
    string zXLnwAwHkS = string("McSfX");

    for (int byTeLwNYW = 1891510024; byTeLwNYW > 0; byTeLwNYW--) {
        iXXHjraeWlSs = LMoVqPL;
    }

    return pwZQyEfOC;
}

void mDiwDPZoNDZbiJv::uEDbemCrZLOAmyYq()
{
    bool yikzKXgexGZjzu = false;
    int JCVCDhLHUUC = -360812539;
    int rsssFqPst = 990098252;
    double cWMKcNBSRrIvKipa = -400386.4631439957;
    string ZaePIYlr = string("KXFTUtrLKNOfuUkxemszFdwXkFEuDeeMuxDZKrqsSvSiRJCljvTEyntBfCyMsXRxMtLEMAelLDynDwVAfwJZZZFgCITPEljIdyDYdcfdhGSffOpulozeTcGjEOdVEPOYCmDUivxJDzjBabVAfUVtsYHAYHCRcdwGDOALckFLEQlkmFkWOvMivRfcXwDCGXaLrNXVGxJs");
    string hzNHXVDSIdDfc = string("ldfrVYuABccDtkdixfZmTyPgLbwikvILJMWaNTvBhVgiPBPMRhubzdTrcSJpaU");
    double pFsLBsfNplgKdm = -878449.2186953699;
    bool gNQWfNXKFaGHIzK = true;
    string WyLNnnHsf = string("IiOASAfmkpbUXNjrvYxraMBRsSfIwmWottIOUZstzBevcoJkNEVSfgOGtMiXMvEfgROZYCOtNWEhuRivmfqBYlTsIRpNWtskGoMKtDAOcgmwMTSdVuxRjhZeHEbSGrb");

    for (int ERoKcKSIKLIBIa = 633850251; ERoKcKSIKLIBIa > 0; ERoKcKSIKLIBIa--) {
        hzNHXVDSIdDfc += ZaePIYlr;
        WyLNnnHsf = hzNHXVDSIdDfc;
    }
}

void mDiwDPZoNDZbiJv::RVssdZdf()
{
    bool JNMcNWBXjCKCY = false;
    double rllqqLXxk = -753758.1688432647;
    string daVwBXjrLNbowbp = string("NICTNreujOIVYHbchFVndLkVKYuBpvaqSggcpkeKfdodxinhUOcvwMgGYDN");

    if (JNMcNWBXjCKCY != false) {
        for (int XGrDUB = 125867964; XGrDUB > 0; XGrDUB--) {
            continue;
        }
    }

    for (int EGVffDXQVMf = 850596882; EGVffDXQVMf > 0; EGVffDXQVMf--) {
        JNMcNWBXjCKCY = JNMcNWBXjCKCY;
        JNMcNWBXjCKCY = JNMcNWBXjCKCY;
    }
}

mDiwDPZoNDZbiJv::mDiwDPZoNDZbiJv()
{
    this->RNHICGueIbm(-305754.9060175271, -385637.073124662);
    this->SotIfNnmccILTBvw(string("jACEJMjuTAGeAlYMYqyniofZCyHjxcbZpVbITiteeoZZPPd"), -226088.33161829686, string("QLEUpMiOkAergIMvBLNCAztKdqPKwVlCzDN"), -272677.217210006);
    this->vIGCJqAHLNUnDwa(-788344.6572760156, string("FrJIacxoOpzQVqBALikPGNXYeEOxZjJFYvufyAgaycFOxVhijYXaYVPEVlbPeQdHpvsUjcJJeKEyHidwvTbicSPEQeuwvOSDNtHTCSQTwTUjOeFkdPJJixszLuCVcwXvPHIVZMXiAiWQEiHxWzRdqDYloOtMWhRcbnniWAPEifKErxtNdAcWvgxm"), string("SDEAlTObdNJvRZmqdalFUpOwbrWRUdagUJWezQwxkzeyqEQWWOOfZcQYCbJjMXCIpQUuaDgQSLTEYXlyHZqdFNQNqlvcODSiXnQKHTPnKwIsrnoKhtrxaVXMyqAibIzWpYViVkxYCIRBfiDLKN"), 979918.5404411688);
    this->LvfUmdndpYiWrj();
    this->DiIfXouylfT(string("kbGqgmLJenmAHTDklQyljThymxzETQqpZqbkqVKpaOwNKyqRuZgsQewjVCVXEUkjASlyVvCbDbtNDdOdCiupcBwikUIHVuMUwWTDkWHmcQLPhgAGXyLJIUVatwXhQiMKjxEXnYR"), -808020851, false, -8279486, 520582112);
    this->FLjhKoDNolNO();
    this->GBNIvwcL(true, false);
    this->wogbKMsKMPL(-688325.5010503366);
    this->kQJWSlagir(572076660, -647953.500556526);
    this->Ektfh(-984641.2390363431);
    this->DPafQNRXFJtrckax(string("ZWcsZRAOklEjLXCqfVTOZRrNoBGidtfaVtcKsDUUFtNZnAyiuBTNAghCkAZiKfyiVQcacJFmADKrQojoVMFcEkODOLMdbJXdOBUenLgaVwRuWqlMziRZFVPZjZSGjBlxkNj"), -22523.89072587971, -743407.2147046148);
    this->uEDbemCrZLOAmyYq();
    this->RVssdZdf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SvMcpMDgnOOktCCl
{
public:
    string uANzRxjuKFz;
    bool iybLcctXG;
    string xLnDCvuOMuKmk;
    int wetpolXrfUXnKU;

    SvMcpMDgnOOktCCl();
    void kgzkPxhQDNlmir(int MVZmGISggMN);
    void rQUixVNhBY(int pKvyeWa, double YJVUbLVAa, int TqVVTCfiMX, double oReOIHUUyPmbP);
    string AGpNvtKi(int LRVilASRJqMx);
    void WOGxvZsZCuGTDl(bool nyIXJHRvRXG, int hTmLqnHEqj, int NsYgGYolCgNyJ, int sYjcGPQAF);
    string JwkGQllKyvxDYBiT(string eibNGE);
    bool FBJSvHiFE(double aMAIzsAVv);
    void yRtQpjUv(int AmKDeLmWgI);
    void cmpyRGcez(bool ZSriqs, double oHlvJOXfHIpNhoZn, string XYeVNXtSG);
protected:
    bool FiCvkgrth;
    int FZuRDBVuKg;
    int KhhDTTH;
    int uxtOzrNhe;
    string qXLXYJZRJe;
    double MADVVcczvUh;

    double BOpcVRMiC(double PCgAgtjBgeEbys);
    int qLCWYPPzpou();
    bool OKzovLDFYgOLfJ(string ZpTteawDUIXbmyhq);
    void sqjZiTEe(double IErSHudOO);
private:
    bool fbKymvQmocPRq;
    int sWlkxxpZtGlFuGW;
    int sfCTQbLrAy;
    double QGgtKG;

    string CvLuNakQS(bool DxhjWiOqer);
    string yJzWTnVWiNbEnTPA(int RqJREJuujgVmj);
    string bWuRc();
    string LALTXRJkzcOAesmD(int YHIYGAshRFhh, int GyKryoDxjI);
    void PDMvQc();
    double UJgSlZaGDwAdLON(double NIKUItdAobDj, bool CnmKvDNkn, string SCGHqFRaif, int XeeALvBdaoZYow);
    void LHOxSn(bool KWqTVwGMeM, string KNetVjcvBKWWWA);
    string DPuPXOGS();
};

void SvMcpMDgnOOktCCl::kgzkPxhQDNlmir(int MVZmGISggMN)
{
    int JHTeWCEtp = 521200237;
    int gQloivO = 1619780399;
    int JxmeluXvGEbvUfqw = -290455712;

    if (gQloivO == -290455712) {
        for (int auJOPoXuRQEQkeT = 1998289698; auJOPoXuRQEQkeT > 0; auJOPoXuRQEQkeT--) {
            gQloivO = JxmeluXvGEbvUfqw;
            JxmeluXvGEbvUfqw *= JHTeWCEtp;
            gQloivO = JHTeWCEtp;
            JxmeluXvGEbvUfqw += gQloivO;
            JHTeWCEtp += JxmeluXvGEbvUfqw;
            gQloivO *= JHTeWCEtp;
            JxmeluXvGEbvUfqw *= JxmeluXvGEbvUfqw;
            gQloivO /= gQloivO;
            gQloivO -= MVZmGISggMN;
        }
    }
}

void SvMcpMDgnOOktCCl::rQUixVNhBY(int pKvyeWa, double YJVUbLVAa, int TqVVTCfiMX, double oReOIHUUyPmbP)
{
    bool yORKVitxP = false;
    bool TUOuQPATiPW = false;
    int TwISyEjAelTX = -1317336334;
    string QJTSgo = string("mhVhQGPNvrVGitDYHDILiVPaLrfNCZwULlrvZVQahJiIoKaWlOctazNlgqeJUDroReKyRTZdfWgLmoWwfWDxzlPvVAZdolMGvZ");
    int CwFOCmWUMSP = -142362843;
    double VQhLq = -453575.35375098157;
    bool ZQcpqZqgFoRZ = false;

    for (int VRDpvHAYu = 1954707215; VRDpvHAYu > 0; VRDpvHAYu--) {
        continue;
    }

    if (TqVVTCfiMX < -1317336334) {
        for (int xOhWxJQJ = 942514200; xOhWxJQJ > 0; xOhWxJQJ--) {
            continue;
        }
    }

    for (int IVmTipjVAUJpP = 1080487069; IVmTipjVAUJpP > 0; IVmTipjVAUJpP--) {
        continue;
    }
}

string SvMcpMDgnOOktCCl::AGpNvtKi(int LRVilASRJqMx)
{
    bool VJhFN = false;
    double GtIkmvBJLSEGb = 487882.0673539454;
    string LiFVzoUtAmOr = string("iMIgQZoROOfckVBCwPAHVy");
    int zhxzhxsxPajkT = -584201708;
    bool UlKBEEElcjGH = true;
    double AoslcfuDxScHDI = 156288.16462355526;
    string lRESSj = string("mZnfZVUFTnuIKlmptVlpRBgOdptJczpJlEfXyaqaiOARWDkUcLPtlLarJWnMUjytiugXvEUBz");

    for (int fTadLsbkLHXoG = 860577972; fTadLsbkLHXoG > 0; fTadLsbkLHXoG--) {
        zhxzhxsxPajkT /= LRVilASRJqMx;
        GtIkmvBJLSEGb = GtIkmvBJLSEGb;
    }

    for (int HXEScMqbKu = 1233581735; HXEScMqbKu > 0; HXEScMqbKu--) {
        lRESSj = lRESSj;
        UlKBEEElcjGH = ! UlKBEEElcjGH;
    }

    for (int oezGFEWELRqBie = 1506764140; oezGFEWELRqBie > 0; oezGFEWELRqBie--) {
        UlKBEEElcjGH = ! VJhFN;
        zhxzhxsxPajkT += zhxzhxsxPajkT;
        zhxzhxsxPajkT -= zhxzhxsxPajkT;
    }

    for (int rXsPRpxHxiPgAM = 532933929; rXsPRpxHxiPgAM > 0; rXsPRpxHxiPgAM--) {
        continue;
    }

    return lRESSj;
}

void SvMcpMDgnOOktCCl::WOGxvZsZCuGTDl(bool nyIXJHRvRXG, int hTmLqnHEqj, int NsYgGYolCgNyJ, int sYjcGPQAF)
{
    int FSwHKjfJjnqfdlU = -1226789569;
    string uJozhSUgX = string("ERHQtVirgSnKKXNzkGflFvVUqMxcYviLqCabsqVPKNLqQPnfekJRfBhVpDfJmdkWcKPEnpIGPUXTmYaOgKrOVNRWUxVArmlwulvmOsWwHPifkyfidMPCwAtrAwLHUOBJdPlfgHGtZaNijjMQzhzuHQOGyProjJbXJhXqXUHLocTXcQuNmgIdzdVnAFxPbgmuNsVJahaCRaIlnbLdVKfbLhdnwPyDiGenniMykUulpyKPBPxhDWdzz");
    double PvfVqIGFjL = -892943.1354327506;
    int kecfhXhuUkbzmiI = 962711665;
    bool zNktjNSzdkT = false;
    int mhSnSAlhhfgyoj = 1458284425;
    bool BehzDagnuNOc = true;
    int EEeANnZYmOnY = -1129898245;

    if (sYjcGPQAF > -1226789569) {
        for (int buJtgbRIdt = 14454211; buJtgbRIdt > 0; buJtgbRIdt--) {
            continue;
        }
    }

    for (int CYyVUbwoeT = 335118707; CYyVUbwoeT > 0; CYyVUbwoeT--) {
        hTmLqnHEqj -= sYjcGPQAF;
        NsYgGYolCgNyJ *= mhSnSAlhhfgyoj;
        mhSnSAlhhfgyoj += mhSnSAlhhfgyoj;
    }
}

string SvMcpMDgnOOktCCl::JwkGQllKyvxDYBiT(string eibNGE)
{
    int pikMYCayYWJhT = 1016725480;
    bool rmCHVWCLAmfmrk = false;
    int EKraHPuM = 1392881497;
    string QEYRtm = string("hlEFDDuPHrRfvgnkwxcuCuEKtJOGEJcOjtofuQVbLcHVzUMOlVbnsuomGPtHWjjnUUeiiJDCDPyXacsPXBsgbljMWgdrQRJlNguJSXpugnfSAwnzhqOxqcxDjWMJcJbdNTThbCZoQvmkHKKaIovrOyxIodZwiXzaznjnsC");
    int wkTAvQPoHO = -220756681;
    int MbBYiWkZ = -1783162274;
    string iVgjFq = string("mZtzhDzjqzxGQXvPEwFeeLPSErIUvjICYcahCqYCaaXMICauFXDPigoqiQZIftkktwMfYg");

    if (pikMYCayYWJhT < 1392881497) {
        for (int iXIgiBBf = 1023880520; iXIgiBBf > 0; iXIgiBBf--) {
            EKraHPuM = wkTAvQPoHO;
        }
    }

    for (int MojldCFy = 1451584321; MojldCFy > 0; MojldCFy--) {
        EKraHPuM *= pikMYCayYWJhT;
        QEYRtm += QEYRtm;
        wkTAvQPoHO += EKraHPuM;
        EKraHPuM = MbBYiWkZ;
    }

    for (int rbZOfpYoHORelX = 1425098967; rbZOfpYoHORelX > 0; rbZOfpYoHORelX--) {
        eibNGE += iVgjFq;
        pikMYCayYWJhT -= MbBYiWkZ;
    }

    for (int RLtFLeEM = 1101998144; RLtFLeEM > 0; RLtFLeEM--) {
        MbBYiWkZ -= MbBYiWkZ;
        iVgjFq += eibNGE;
        pikMYCayYWJhT += wkTAvQPoHO;
        iVgjFq = QEYRtm;
        wkTAvQPoHO /= EKraHPuM;
    }

    for (int GzwjoMw = 1043940991; GzwjoMw > 0; GzwjoMw--) {
        QEYRtm += QEYRtm;
        pikMYCayYWJhT /= wkTAvQPoHO;
    }

    if (QEYRtm <= string("QoY")) {
        for (int oTiWUGYJpyIeIE = 892610651; oTiWUGYJpyIeIE > 0; oTiWUGYJpyIeIE--) {
            iVgjFq = eibNGE;
            pikMYCayYWJhT += wkTAvQPoHO;
        }
    }

    if (wkTAvQPoHO == -1783162274) {
        for (int DATTMFavDndKCeni = 1495544164; DATTMFavDndKCeni > 0; DATTMFavDndKCeni--) {
            wkTAvQPoHO /= pikMYCayYWJhT;
            MbBYiWkZ -= EKraHPuM;
            rmCHVWCLAmfmrk = ! rmCHVWCLAmfmrk;
        }
    }

    return iVgjFq;
}

bool SvMcpMDgnOOktCCl::FBJSvHiFE(double aMAIzsAVv)
{
    double InPwWXfnuYp = 651069.066146126;
    double LWTkIJwiml = 966751.1099832946;
    bool MrlTkkEj = false;
    bool JqVuGAWwZFRqUsW = false;
    int PqgPOELKKtmGozl = 507947151;
    double DJgXSvG = -516384.57434936956;

    for (int fvtszu = 1149439856; fvtszu > 0; fvtszu--) {
        continue;
    }

    return JqVuGAWwZFRqUsW;
}

void SvMcpMDgnOOktCCl::yRtQpjUv(int AmKDeLmWgI)
{
    bool UnMugrRRUwLWHLrl = true;
    double BwZJBhUWDOdtGS = 646734.210658843;
    int KlTvittTk = 39856804;
    double NEzFyTxQtuGlCNtR = -569415.5535674499;
    bool wEBPZgU = true;
    int WanHYXtxadJy = 1941159242;
    double pfDzxvbphI = 222470.19730191267;
    int KhpgiLfYsmaOWCaY = -1052168540;

    for (int plqMfvHoNnFR = 1387224264; plqMfvHoNnFR > 0; plqMfvHoNnFR--) {
        NEzFyTxQtuGlCNtR += BwZJBhUWDOdtGS;
    }

    if (WanHYXtxadJy != -1052168540) {
        for (int cutBsaplEfuTm = 1948859979; cutBsaplEfuTm > 0; cutBsaplEfuTm--) {
            NEzFyTxQtuGlCNtR *= pfDzxvbphI;
        }
    }

    if (WanHYXtxadJy > 39856804) {
        for (int JwrJcAsiXopoiL = 2011958437; JwrJcAsiXopoiL > 0; JwrJcAsiXopoiL--) {
            NEzFyTxQtuGlCNtR *= NEzFyTxQtuGlCNtR;
            pfDzxvbphI += NEzFyTxQtuGlCNtR;
            WanHYXtxadJy -= KhpgiLfYsmaOWCaY;
            KhpgiLfYsmaOWCaY *= KlTvittTk;
        }
    }

    if (WanHYXtxadJy >= 1941159242) {
        for (int yIzBvKiNU = 2107483789; yIzBvKiNU > 0; yIzBvKiNU--) {
            AmKDeLmWgI -= AmKDeLmWgI;
        }
    }
}

void SvMcpMDgnOOktCCl::cmpyRGcez(bool ZSriqs, double oHlvJOXfHIpNhoZn, string XYeVNXtSG)
{
    int QAarycv = 1594348459;
    double lBiUTEPFCmB = 636185.1425576288;
    string yGCNlnn = string("SVVlnofrdRAkLinFvntftPkiPafPtxfeNKkJRyCuaYnlcjixkIFPocyLCkIHqztZUWKPLJOeRqsjUpFbMCEwXRSqgWrpVGCPEhkZIWIEebtiaMB");
    int NeBiuAlhRiZMHA = -1279682445;
    int xIjHHxvi = 2088591618;
    string VCXslXIWaZ = string("tQIGXOVEcsJMAWJVUfIifTClKajxKvkFikbabTdIjKwzjgxkKZQcoAcFMtrxClJkluKcsZrUSwiLdFCJvgwrxqYUScjboBnODjyNcHHMoYgtqjrkOnlnETzqTymNnmXFloQb");
}

double SvMcpMDgnOOktCCl::BOpcVRMiC(double PCgAgtjBgeEbys)
{
    bool dCQLcySAP = true;
    double LlXUKOGgCcPKDgJ = 293510.3084961198;
    int TQgDmftOV = 1051378492;
    string PDpxgxZh = string("zMqJNncddJfpbMLFBEvqazevXyAIcbBljePdPfEZYRPLTzMyHObAhwExbCgKpiQPIqbnNsMEmCClaKImEzEzYtYienuqNklaNYmxoeMveQlLqgLMFFHTbcJIMEpZpyPHuYkpJSmVxXBSeZCuWcEfcumCdISJiXQQMqexJisXTQPSZBfmzwZlgEDZcTnkmJodGYmMnMBDGRFJiUYUdhfTNIWUyaXtSvoMNbyYjyKvZYRjcDKVCAiqsbIIEFjmjk");
    double appgdlSDCEFX = -228696.65402665478;
    bool ofWxmzVRpb = false;
    double pRBHe = -489894.35581411317;

    if (pRBHe > -489894.35581411317) {
        for (int jYmSkYPIYNlCMyJ = 1458378691; jYmSkYPIYNlCMyJ > 0; jYmSkYPIYNlCMyJ--) {
            PCgAgtjBgeEbys = appgdlSDCEFX;
            PCgAgtjBgeEbys *= LlXUKOGgCcPKDgJ;
        }
    }

    for (int xsTwzXZLhWaHwAgg = 696714649; xsTwzXZLhWaHwAgg > 0; xsTwzXZLhWaHwAgg--) {
        TQgDmftOV += TQgDmftOV;
    }

    for (int obWlDhpuC = 578808587; obWlDhpuC > 0; obWlDhpuC--) {
        TQgDmftOV = TQgDmftOV;
        dCQLcySAP = ! ofWxmzVRpb;
        ofWxmzVRpb = ! dCQLcySAP;
    }

    for (int TLzeGm = 1208626278; TLzeGm > 0; TLzeGm--) {
        LlXUKOGgCcPKDgJ -= appgdlSDCEFX;
        PCgAgtjBgeEbys = PCgAgtjBgeEbys;
        appgdlSDCEFX *= PCgAgtjBgeEbys;
        PCgAgtjBgeEbys = PCgAgtjBgeEbys;
    }

    for (int lnPyjxvyQEyw = 1712504842; lnPyjxvyQEyw > 0; lnPyjxvyQEyw--) {
        PCgAgtjBgeEbys = LlXUKOGgCcPKDgJ;
    }

    return pRBHe;
}

int SvMcpMDgnOOktCCl::qLCWYPPzpou()
{
    bool JbQMJAOeCrDK = false;
    int TkLZzheDl = 1534311278;
    double HMjrlBobNytWsJ = 863686.5293196433;
    bool FrCwo = true;
    string jfQNMsnlF = string("uzEkJluraOOViAhHkqYTZrtYRWFsvEmkdefVHPKHAkEZZVDmdQFTBmncPLQBbSsGDSGbVetSYomczGrcYRjTkUDvmLehDLAEKJXtpqUoerrQXSGopnTaXOYShKIhWSPQjXjHkcullsidfypzNuqqDjzONNQOMraIcOJRSQkdsuKkXdhKfacRTaLpmCiDDBAQKhGsLQuGWpQOdlBLjcGqkpGnTtmAYCBZkJuroROoVwGI");
    double ARwYyKkASOww = -612703.6943306889;
    string vFAUAMxhkJ = string("BftUqpOHFCiBvydwoWcVrlteleXYEGLnOtJTpMOSAzZEjuvZmFWdJOIdTyrycZMeKsQIzAPFmpAfTPxoSXYFJeGPXakiavEDwoHodbWJXVqKUtvXXsEmhwvNOizzcGqnLxzUELNJovhuhSMXCtLWuoUuiudHaGxpFRFxyQLeKxwsMYyAJAUIRFxdRsccYucIxdrPsZppBwhUjTXxalR");
    string WZIKdqgE = string("RNWDVNxZxBnWWvumRDNwLRIDtMSIbSlxiSUgzvgBKPMvftTYyKhHDiXFhCPioIEqYTkiMvxXXcsFMemGQztpSNYhAxjaANqZQaAQoUWLglRLrqOAMeWZNldUOedhCzryPbkyMqiAMpjQsnOZsZGuMHcfUlXzpcvnUaYzqBJmkDsmeUkgxgyDElLgpZqEfpyTxnbenfzStjEwOBkToAIzenSaJjlRWjYvKPqFemQlWADsrkAqZEAFVqVlvXw");
    string RoraScQEfK = string("ULQhGkgjoDobpGlfitYJhxRlHRXbGJfwXJUsvKvcAzPVHwaTHBConMvRJIHXXLqRMqTkyFIFfgoPzRwlDuuORLKXPSfteETqUG");

    for (int YHhIwDOOJu = 1233382695; YHhIwDOOJu > 0; YHhIwDOOJu--) {
        vFAUAMxhkJ += vFAUAMxhkJ;
    }

    for (int QceIdBBzaUNHBkd = 303381610; QceIdBBzaUNHBkd > 0; QceIdBBzaUNHBkd--) {
        continue;
    }

    for (int cmbHXZLefY = 498602188; cmbHXZLefY > 0; cmbHXZLefY--) {
        continue;
    }

    for (int vVpOWJlJUEqafFfF = 540439358; vVpOWJlJUEqafFfF > 0; vVpOWJlJUEqafFfF--) {
        WZIKdqgE += vFAUAMxhkJ;
    }

    if (vFAUAMxhkJ >= string("ULQhGkgjoDobpGlfitYJhxRlHRXbGJfwXJUsvKvcAzPVHwaTHBConMvRJIHXXLqRMqTkyFIFfgoPzRwlDuuORLKXPSfteETqUG")) {
        for (int nsBfwyybHTdTwqU = 1094749845; nsBfwyybHTdTwqU > 0; nsBfwyybHTdTwqU--) {
            JbQMJAOeCrDK = FrCwo;
            vFAUAMxhkJ = vFAUAMxhkJ;
            HMjrlBobNytWsJ += HMjrlBobNytWsJ;
            vFAUAMxhkJ = RoraScQEfK;
        }
    }

    if (WZIKdqgE <= string("BftUqpOHFCiBvydwoWcVrlteleXYEGLnOtJTpMOSAzZEjuvZmFWdJOIdTyrycZMeKsQIzAPFmpAfTPxoSXYFJeGPXakiavEDwoHodbWJXVqKUtvXXsEmhwvNOizzcGqnLxzUELNJovhuhSMXCtLWuoUuiudHaGxpFRFxyQLeKxwsMYyAJAUIRFxdRsccYucIxdrPsZppBwhUjTXxalR")) {
        for (int VIzfycCcF = 1466595112; VIzfycCcF > 0; VIzfycCcF--) {
            continue;
        }
    }

    for (int zIJfkIEadCTVSV = 1801344457; zIJfkIEadCTVSV > 0; zIJfkIEadCTVSV--) {
        continue;
    }

    for (int IajKQjh = 1500770145; IajKQjh > 0; IajKQjh--) {
        WZIKdqgE = vFAUAMxhkJ;
    }

    for (int IaIARK = 257791234; IaIARK > 0; IaIARK--) {
        jfQNMsnlF = WZIKdqgE;
        vFAUAMxhkJ += WZIKdqgE;
        jfQNMsnlF += WZIKdqgE;
        WZIKdqgE += jfQNMsnlF;
    }

    return TkLZzheDl;
}

bool SvMcpMDgnOOktCCl::OKzovLDFYgOLfJ(string ZpTteawDUIXbmyhq)
{
    int RKQdHcZXaHlvJ = 271260923;
    bool JwwiIBNJWx = false;
    double RublfMnx = 803778.579324138;
    double tSCrekGUVCGx = -50403.34538261217;
    int wJgdlRabZRRwlEH = -1212511315;
    int wIAovvX = -1951667791;

    for (int gPIsNNkNWQfzVGb = 95292018; gPIsNNkNWQfzVGb > 0; gPIsNNkNWQfzVGb--) {
        RublfMnx = tSCrekGUVCGx;
    }

    for (int CwXuk = 1589355368; CwXuk > 0; CwXuk--) {
        tSCrekGUVCGx -= tSCrekGUVCGx;
        tSCrekGUVCGx /= tSCrekGUVCGx;
        wJgdlRabZRRwlEH *= RKQdHcZXaHlvJ;
    }

    for (int gievetokXPwv = 1553620863; gievetokXPwv > 0; gievetokXPwv--) {
        continue;
    }

    for (int tSrEwVVnCrVDOziz = 1758636631; tSrEwVVnCrVDOziz > 0; tSrEwVVnCrVDOziz--) {
        continue;
    }

    return JwwiIBNJWx;
}

void SvMcpMDgnOOktCCl::sqjZiTEe(double IErSHudOO)
{
    int exgpOPwNh = -226686816;
    bool jtQNiOhlTgDr = false;
    int sMPenkXiLoRMwCBc = 2118928805;
    string ZhaPCjCi = string("yVwEwNKMdSpwUOULmVjiaWllSCWiPUjRoVYlhHlQbKYDUMZZjXgcxDtZhiwnJUvTtyNhuKYgrrdOJaAWeDCbwGGHqKuuArvOUSGKWtmFaIpIkfUtXMYPLQITMrStRyfjlyRUgnzFlYCKfBFyJxZAphMONICMXgcmLwkNgZfszTwiSItzcCFjQNtmTOlGsdfnmmkVtS");
}

string SvMcpMDgnOOktCCl::CvLuNakQS(bool DxhjWiOqer)
{
    string NLmtYjXLQibgtTFF = string("eSbGGzAoFiIEaJKBShPdgpurdFlWHNXbGfbZaHpUPwqEOrdpCdqNzlMjnUpNcuKNxlIeSDLzdJmZVZPMvxAUyhnoQMNvOdzOJcoIsxqsGUfPBHpXeJyfhagTxaVckJMTpbspHwoHOSjCbjsHigPYYrxTBcRQORglZTGgaacbMZhlSCMftIloUbAoQlzULyIIjVZbyMkcXzTwtQpggmuggNQHRZWclqkUHf");
    int iBUiZXN = -193226198;
    string vtUMziGzLuLCjm = string("YTVnnZDOkYwtOeNlnFPEBQrcNhrnhrKbcLzWGDRxyjakJaqIluByozgRFvCfUdEbPoHciyjdqJsQASkfhsxSiVrZLjTWLVyhfcyHoNQlhSALuPfjBkLIQUpnzXGHXHHqqdGeOXNkPadGqVvnDRLcSkXTFHGAqGeTxfXJtvhNmFJhqescJDzDMjesGTPvxyKhHVLTnSGtwBDjsuWFhuARCNDZZRAmcDLPwzCibediIBWJjOKHV");
    double ONfhhwPSIKKW = 119160.24999258274;

    for (int hXIXa = 1092739509; hXIXa > 0; hXIXa--) {
        continue;
    }

    return vtUMziGzLuLCjm;
}

string SvMcpMDgnOOktCCl::yJzWTnVWiNbEnTPA(int RqJREJuujgVmj)
{
    string FyETnlJlN = string("bzUHvmsIFdRCJtAgNewdXEGrPojgcsJjhZfwzjbNNggXNoIwDqHiOkHxJyLBOEzfBlTzZEfwhSpkuVXMNVGlajWadpgzeQvWptFnwlsMbBJHcZHQNdNOVTqEAKzWoSrkqcFWvdDYgMzrWZfpJMwpZQhbNbaNNpiEtqeuAQGyqkRmrGljQaswELjBBCpnNnpcDTwlIJBQiZCsRESLeQRgJtwWfboVUSyuLSFkcCkYogwUekjM");
    string bUgamrhlFxrjRyrP = string("GRtSTLEcbafArJMdKqhRjizQBuTjSCPbvhAuoagGLkHgTYZgLaEPrFdelozpKSjtxyZFOgDCmoCtWNNvgrTOcSsbvGucslIaBGRpakfeWgFmOXPqPwwmpMGLeXGhGhITOTczphtYtn");
    bool uWfJBP = true;
    string rPQzV = string("RjGDGUOUfrnotrIijFwUDSxDCVBvTcTTIyJpkGhcnqsplrPAVsSCRivovRmlTdxEuSjfGEAjoEDEQxsAGxYVffbXHphRKVWjefBeVgkQSjhtZbTmuoliJHrjtmUjXRhZvMsjxFxgufFsAUENRwDmuZglwfZtwDWPrtORMYOPVxUnniuXr");
    string BdjOpNx = string("QYCJtoLhpnxqUmfuODjxZTKCZEOZRDlYIyaASOfWneGqkpTPVGBHrEiACKoOEnVfbCSbUBxJeLlcMFwcYXSqqAvMzEWRdDVRjkqTrgiWyCGiNXfXUP");
    bool hFPRoUsjUM = false;
    double vKtmLKXWJWc = -229642.02309338652;
    bool TegYEnDUpwGMUXE = true;

    if (BdjOpNx != string("bzUHvmsIFdRCJtAgNewdXEGrPojgcsJjhZfwzjbNNggXNoIwDqHiOkHxJyLBOEzfBlTzZEfwhSpkuVXMNVGlajWadpgzeQvWptFnwlsMbBJHcZHQNdNOVTqEAKzWoSrkqcFWvdDYgMzrWZfpJMwpZQhbNbaNNpiEtqeuAQGyqkRmrGljQaswELjBBCpnNnpcDTwlIJBQiZCsRESLeQRgJtwWfboVUSyuLSFkcCkYogwUekjM")) {
        for (int LoIHCPzIWkcDebzJ = 1061048787; LoIHCPzIWkcDebzJ > 0; LoIHCPzIWkcDebzJ--) {
            FyETnlJlN = FyETnlJlN;
            bUgamrhlFxrjRyrP = BdjOpNx;
        }
    }

    for (int KwTITLKOlRFlky = 1542305411; KwTITLKOlRFlky > 0; KwTITLKOlRFlky--) {
        BdjOpNx = FyETnlJlN;
        TegYEnDUpwGMUXE = TegYEnDUpwGMUXE;
        BdjOpNx += rPQzV;
        FyETnlJlN += bUgamrhlFxrjRyrP;
    }

    if (FyETnlJlN <= string("RjGDGUOUfrnotrIijFwUDSxDCVBvTcTTIyJpkGhcnqsplrPAVsSCRivovRmlTdxEuSjfGEAjoEDEQxsAGxYVffbXHphRKVWjefBeVgkQSjhtZbTmuoliJHrjtmUjXRhZvMsjxFxgufFsAUENRwDmuZglwfZtwDWPrtORMYOPVxUnniuXr")) {
        for (int wayrttV = 1524282506; wayrttV > 0; wayrttV--) {
            RqJREJuujgVmj += RqJREJuujgVmj;
            BdjOpNx += FyETnlJlN;
        }
    }

    for (int vwqNqqCtV = 1016534354; vwqNqqCtV > 0; vwqNqqCtV--) {
        bUgamrhlFxrjRyrP += FyETnlJlN;
    }

    return BdjOpNx;
}

string SvMcpMDgnOOktCCl::bWuRc()
{
    int IHLjeca = -163707444;
    string NtJZrceYDpgKdLGu = string("QZiOTanHrapUHbhAcozsVAcMHXeSEjZMYWpENbBmftJhegmIjuVZfwNpMzEivoBHfsdipbMuBuDNIUkRtdNYNZwTVqNFEGRySpptwluSERTIclncnBVTgMKIoAthRBSGCRGxUcRCrInWwXisBYfzyyVhZVoqdvoOffNdQkGvmQiXHjEazciJcBbnVhsZGNhmmUBOqcEPlSiRhpWICEGkshNPRQXbzQwhmXlujuggdU");
    double BVvvbUC = -356660.6373601933;
    string YyVWr = string("ygfTIBWmDxWctAQllqnqUwoxeHtjXOhQOBWBAWLaSgkFlEjTmQsQbJynHFvyUaOeLrEkdmorkosyNICMgraGxHCleFHxrLOmasRDtDQfgmnbFcCkuiLjyUCCiFDkvwmDfHHZAvuhjfEYLXCYaHHXXrfFCOFQIsYsYeRUydBbebVGzdDFNnncnDWBKdKwUqZKYyfJYWiVrUrbvLEzOGpWWlwEfTIicEAbJcGDtONuOVxAAxDkRtsYi");
    bool GsbhyZSaUpKCcGjY = true;
    double QXQqulDJgSoZnO = 75604.87990727274;
    double ewdyGq = 554392.7513401912;
    double ufkBpZlWoiUMb = -843561.1556129206;

    for (int bHtEZrR = 2020704207; bHtEZrR > 0; bHtEZrR--) {
        YyVWr = YyVWr;
    }

    if (QXQqulDJgSoZnO < -843561.1556129206) {
        for (int EQjMOcqWyZe = 1895180416; EQjMOcqWyZe > 0; EQjMOcqWyZe--) {
            BVvvbUC /= QXQqulDJgSoZnO;
            ufkBpZlWoiUMb *= ewdyGq;
            QXQqulDJgSoZnO += ufkBpZlWoiUMb;
        }
    }

    return YyVWr;
}

string SvMcpMDgnOOktCCl::LALTXRJkzcOAesmD(int YHIYGAshRFhh, int GyKryoDxjI)
{
    string YPcVeosrBqkE = string("sosJRDdGUmSsDOuzWBnPQPRpCLkMlsoHvHzEmjVPqSQoGQSyFZEgVimFLGhPGZCRpfeGKZwvuVfEITnjgxORLKMCaSzlttkKqtgxohAXDpMidxXgKZbmTHtcuQzoNEAOKAhcWBazJNYWUAuBJgYhmxKHpzxogHoTAmVNduHZMQdnxowxliByMDHZNZXzFLROZ");
    bool fRXFFYmYEAov = false;
    double SbThH = -5586.5571454509845;
    int vEkfFbYXP = 1226370005;
    bool MCrvMHZgTUfbnV = true;

    if (GyKryoDxjI != 2130190100) {
        for (int Jqzwi = 36348661; Jqzwi > 0; Jqzwi--) {
            SbThH -= SbThH;
        }
    }

    for (int onblIrTeh = 717041169; onblIrTeh > 0; onblIrTeh--) {
        SbThH = SbThH;
    }

    if (YHIYGAshRFhh < -1286851252) {
        for (int AOPcT = 492999232; AOPcT > 0; AOPcT--) {
            continue;
        }
    }

    for (int CrjBx = 677679310; CrjBx > 0; CrjBx--) {
        GyKryoDxjI -= GyKryoDxjI;
    }

    for (int CDbQwm = 1469818984; CDbQwm > 0; CDbQwm--) {
        GyKryoDxjI += GyKryoDxjI;
    }

    for (int NJKctwmKzZt = 2113146456; NJKctwmKzZt > 0; NJKctwmKzZt--) {
        GyKryoDxjI *= YHIYGAshRFhh;
    }

    return YPcVeosrBqkE;
}

void SvMcpMDgnOOktCCl::PDMvQc()
{
    double EYqANIDDtzq = 589102.2234369133;
    int PcvolEdzKuzXupMR = 244182984;
    double RiYpKnnwfarKjmM = -134596.7230108087;
    double wLVyuwCr = 453340.7624096382;
    bool kYXdHknEA = false;
    bool KJnKIPjRBAV = true;
    int WqUubTvDQMeEB = -308114550;
    int cUlnvQdfP = -1987778637;
    string QntuJimuNUHrPz = string("kTdGYwukIWHTdVQyhJkTdxQDzRrDVVZyjgxrwqwYEYLJpplNFjdiLroddlXEyiiwpyEiSXSfJJLcMkDHCp");

    if (PcvolEdzKuzXupMR >= 244182984) {
        for (int Gjpxg = 2143339175; Gjpxg > 0; Gjpxg--) {
            RiYpKnnwfarKjmM = wLVyuwCr;
            WqUubTvDQMeEB = cUlnvQdfP;
            WqUubTvDQMeEB -= PcvolEdzKuzXupMR;
            kYXdHknEA = ! KJnKIPjRBAV;
        }
    }
}

double SvMcpMDgnOOktCCl::UJgSlZaGDwAdLON(double NIKUItdAobDj, bool CnmKvDNkn, string SCGHqFRaif, int XeeALvBdaoZYow)
{
    int FrzaCkBBFsP = 1719176282;
    string GbyHCo = string("YxRJyHDOYzBUqvBJJHKVQDIiInNPOMhkJBQJStZXbxtEjetCOJMGeLrzBYQSczkMMsmDXebFLucHyMqGXtJNgyzEOlDEMQeEcHGADgMlvaAEWBuXumzYGECMADetkqaXMtRIYFXuWEIvFgQiGzyGsvEBfUXjtcEwnIBERALpMnxzNySJefZoCJOifoxFMWFcYeSKfzfxVMacxGvJJ");
    string BxQYzMIKlsPqFbm = string("MHgjSJsWUvtvkCnPQtQNlSrXRBIqDvoDmDTMHiinorsaZUXUiOqgdgfuNoKqQtUDccpmbPHCgtHtmTQMvHBJnLTpFiwGBKxWwIUCKP");
    double JmNmqbkZSAMUAF = 60981.08364054679;
    string NJSZXQIlpRzmkMnv = string("SoNjbcRAhCkTBlPerKHiDQtRMhbtSCNGFJJwwZQOMwPimxSESkcglvaemupzOUuQUhqDFwBipduAOknIAXwKMEYpcfDiFalvsTAOSWwkZbqmAnMCoftpGWclj");
    bool oZKIdBwVlrcTLMFs = true;
    double fHZZYbsbYkZvwzvi = 586826.1670234976;
    int PyjEBdXVCAeZ = 633769552;

    for (int voHgEqBQGdxiKr = 308550861; voHgEqBQGdxiKr > 0; voHgEqBQGdxiKr--) {
        JmNmqbkZSAMUAF /= JmNmqbkZSAMUAF;
        NIKUItdAobDj = NIKUItdAobDj;
        BxQYzMIKlsPqFbm = GbyHCo;
    }

    return fHZZYbsbYkZvwzvi;
}

void SvMcpMDgnOOktCCl::LHOxSn(bool KWqTVwGMeM, string KNetVjcvBKWWWA)
{
    double cRbjcHiWU = -735876.9897996086;
    string OBdJhwqYym = string("xWgXHckocTWHUahSHtXFhhTnfYOYJtvGWJHreXlII");
    bool hQQCSZf = true;
    double BmCRPTIQJ = 414009.98689593555;
    int LzfSQ = 46510151;
    string jmeCjVuAZ = string("RLEgNMmMBOpWnGrGNPXyOMXlSWcczsz");

    for (int bRYvjULX = 1622863718; bRYvjULX > 0; bRYvjULX--) {
        continue;
    }

    for (int EKarF = 844810655; EKarF > 0; EKarF--) {
        cRbjcHiWU *= BmCRPTIQJ;
        KWqTVwGMeM = ! KWqTVwGMeM;
        KNetVjcvBKWWWA += KNetVjcvBKWWWA;
    }
}

string SvMcpMDgnOOktCCl::DPuPXOGS()
{
    int nXBwFJXpCHPe = 661605656;

    if (nXBwFJXpCHPe >= 661605656) {
        for (int qVmur = 1202678314; qVmur > 0; qVmur--) {
            nXBwFJXpCHPe /= nXBwFJXpCHPe;
            nXBwFJXpCHPe /= nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
            nXBwFJXpCHPe -= nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
        }
    }

    if (nXBwFJXpCHPe > 661605656) {
        for (int CeOjBNJOhTebFVj = 1039470868; CeOjBNJOhTebFVj > 0; CeOjBNJOhTebFVj--) {
            nXBwFJXpCHPe *= nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
        }
    }

    if (nXBwFJXpCHPe == 661605656) {
        for (int RuewfNCzkcxWBis = 1743665710; RuewfNCzkcxWBis > 0; RuewfNCzkcxWBis--) {
            nXBwFJXpCHPe /= nXBwFJXpCHPe;
            nXBwFJXpCHPe *= nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
            nXBwFJXpCHPe -= nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
            nXBwFJXpCHPe /= nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
        }
    }

    if (nXBwFJXpCHPe == 661605656) {
        for (int MplXPUUKVKRGI = 2104040642; MplXPUUKVKRGI > 0; MplXPUUKVKRGI--) {
            nXBwFJXpCHPe -= nXBwFJXpCHPe;
            nXBwFJXpCHPe *= nXBwFJXpCHPe;
            nXBwFJXpCHPe /= nXBwFJXpCHPe;
            nXBwFJXpCHPe = nXBwFJXpCHPe;
            nXBwFJXpCHPe *= nXBwFJXpCHPe;
            nXBwFJXpCHPe /= nXBwFJXpCHPe;
            nXBwFJXpCHPe -= nXBwFJXpCHPe;
            nXBwFJXpCHPe = nXBwFJXpCHPe;
        }
    }

    if (nXBwFJXpCHPe != 661605656) {
        for (int fHLhaNsFHw = 1778281165; fHLhaNsFHw > 0; fHLhaNsFHw--) {
            nXBwFJXpCHPe *= nXBwFJXpCHPe;
            nXBwFJXpCHPe = nXBwFJXpCHPe;
            nXBwFJXpCHPe -= nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
            nXBwFJXpCHPe += nXBwFJXpCHPe;
            nXBwFJXpCHPe = nXBwFJXpCHPe;
        }
    }

    return string("wXjjkYEkkgxzgmKtxoBYgYZzUjIBpRlTOjdvDNBjERYAiwHRkhuNuVeFYRtMkTSOfCGmQQEyHMYWzCeqALMYPlhsMONGlKkYVTJenPCRcEWWlkkslXnuAKWrTbnEYfOPzMDBwXlKylBMwkIxbgHcUtXBDYelqelWnBOkpHfXRkWzndbeKazJqyeGoXhmYwiDeYoZTKWjuyqwIhByVWVPaVNJGIAJBjzkrlTpdWpyUtkwlzfbIXDDycLHFPfjL");
}

SvMcpMDgnOOktCCl::SvMcpMDgnOOktCCl()
{
    this->kgzkPxhQDNlmir(-577831999);
    this->rQUixVNhBY(1187232835, 961647.826012667, -161339474, 38895.745975966085);
    this->AGpNvtKi(1408118232);
    this->WOGxvZsZCuGTDl(false, -1819079675, -306777002, 315696579);
    this->JwkGQllKyvxDYBiT(string("QoY"));
    this->FBJSvHiFE(130709.3614007033);
    this->yRtQpjUv(1488799646);
    this->cmpyRGcez(true, 596656.6484481503, string("hPiktCKthfhpwONENlQdQrmMQqVpQpxZHcgpFPMqbNzJETHKvZcVOcLQLpHgEqrjWI"));
    this->BOpcVRMiC(-11076.526116042407);
    this->qLCWYPPzpou();
    this->OKzovLDFYgOLfJ(string("MVxXecEKAnxxePpvzOaBpuojwtSBeyWJZbfzcghYVFY"));
    this->sqjZiTEe(664426.8472196471);
    this->CvLuNakQS(false);
    this->yJzWTnVWiNbEnTPA(-1979341321);
    this->bWuRc();
    this->LALTXRJkzcOAesmD(-1286851252, 2130190100);
    this->PDMvQc();
    this->UJgSlZaGDwAdLON(255510.67781895748, false, string("tZsIMiSKHoETKrDHflYmogRWDoaGaxeweulOVAeQqMheXw"), 1938685307);
    this->LHOxSn(false, string("xhsJOHFIWqBzeRxWxgiIHpxeXCOboXmoITTawnQWwFCPKkgijSaWFdQyeQcvBDwqbvHEPNuFLaejaKYyWhDDMhVtfZlajaHeXFythsBbrGvyWbkVmhhkQYhDmWVxrLXaPHkjdjxZTKjElDzJbqljQXoIGTiTARwZJzKwuQpKuH"));
    this->DPuPXOGS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HHvYcV
{
public:
    string EtkaxJGbrqi;
    string kUZoEXLiD;
    bool cahYrS;
    double WJicR;
    double ZLgSOD;

    HHvYcV();
    int gckRkljLVjSpjrMx();
    string NOMjVREoX(double vLTINCAMaS, double rtHPeGszFPrmz);
protected:
    int PKReLzzcvZwV;
    double iJRrSboupplhjIvy;
    int QrmjuGmG;
    double UPfQAwuIeCJGEvxf;
    string SZelqgBaFkmQhdim;

    double axHkZaALZWn();
    bool XWOAyJBnPIuJ(int dLlwHJuSWPNzwr);
    bool erEqvnuAeVU(int CaZCe);
    double uZerNqhslIaj(bool bpTWS, string aBcJz);
    int dkklIN(int JEsgUEooDImhr, string foazFOInTqWbK);
    string DrFpisKWzRTe();
    double HhORjLFyjDyBJFe(bool FSdwBmPDzVnGz);
    bool IFIAg(int gIsQRqQKSCOtsmwD, string qdPjCyp, double QaUxQmtQe, double IhRMCoi);
private:
    bool hfJGOfcyrQwStr;
    bool fpxrjPhZPieS;
    string Apcyjg;
    string QJbkHekQB;
    double DEnXCU;

    double oTtjG(int WqjLEqoR, string FqksXLftAssK, int QjFUnjR, string lFrBqOkySm, double zsSDzihUTsE);
    void oONCchfQOcCK(bool CYYpMznN, int NZPxy, string VvELNCCLRc);
    bool KWCeGARBobyqMwX(bool vElqHvHJFbl, int rgnmvscjpNJ, double cGymeqDJEPfBzJ);
    string BkeHlL(int kYSPadzlC, string hxNQQDZyxMHIQu, string wndUMnN, double vLVVX);
    void UcakmMbHPDY();
    void DbDTajh(string cQcExF, bool QhrubsydzWbSd, double DyxIrzULtjDOe, bool NkbWoQY, int eYkVAxDSB);
};

int HHvYcV::gckRkljLVjSpjrMx()
{
    string HPrZvskHJV = string("IwyMWgoSEGnbyRIlyCqjOosmhfrjgy");
    double QxoEKaVki = -688118.0871616332;
    string dlFUwpnmtvpPpDFr = string("XKfecgrvgOujYTjAdTKfzUXotCiqUFqFdzhUdHuplbNIUpZNOSYJzCZMFkkXQCNNlECBVxPFTdzRqxGLyxPonBRdehXBkFQNFbObRUCLifOUVnsNXfSUWWKXjZyEqxGtEClYXPKdqgNQSkzzaoXYJd");
    int LNKcVgyywoIii = 1973229616;
    int ZVvXCxgLEaw = -1869097748;
    double tcoKVtctSoBu = -728316.4164727894;
    double EOnAUDPyESxf = 352436.66233192413;
    string gzHOcH = string("SXKjbsFzfSlFRWSfNKeTqTZWuDOvDWqUExlvkDwQBahdqPdhCRsouNtWbWNdKmURXtjVtTxJHnliwQeDUZfhahqvSIpYcsvZgpwqCiIepojznnLrqBeBgamXDXypiUSLujBtwVgbvaGCjJKXvWpjpdsRMiXxdcGKKOlQxSjUaRwnWrJyMSSqRzZWYTuQj");

    for (int NtiSdAprgl = 759636430; NtiSdAprgl > 0; NtiSdAprgl--) {
        QxoEKaVki = tcoKVtctSoBu;
        EOnAUDPyESxf *= tcoKVtctSoBu;
        EOnAUDPyESxf = EOnAUDPyESxf;
        HPrZvskHJV += gzHOcH;
    }

    if (LNKcVgyywoIii == -1869097748) {
        for (int ALaWWwBiZSIhle = 1803053397; ALaWWwBiZSIhle > 0; ALaWWwBiZSIhle--) {
            dlFUwpnmtvpPpDFr += gzHOcH;
            HPrZvskHJV += HPrZvskHJV;
            EOnAUDPyESxf += QxoEKaVki;
            HPrZvskHJV += gzHOcH;
        }
    }

    for (int JMQmAGmqQP = 1402446826; JMQmAGmqQP > 0; JMQmAGmqQP--) {
        LNKcVgyywoIii += LNKcVgyywoIii;
        tcoKVtctSoBu = EOnAUDPyESxf;
        tcoKVtctSoBu += tcoKVtctSoBu;
        HPrZvskHJV = dlFUwpnmtvpPpDFr;
    }

    for (int SVQcbsvk = 1482739545; SVQcbsvk > 0; SVQcbsvk--) {
        EOnAUDPyESxf /= tcoKVtctSoBu;
        LNKcVgyywoIii /= ZVvXCxgLEaw;
        EOnAUDPyESxf *= EOnAUDPyESxf;
        gzHOcH += dlFUwpnmtvpPpDFr;
        gzHOcH += dlFUwpnmtvpPpDFr;
    }

    return ZVvXCxgLEaw;
}

string HHvYcV::NOMjVREoX(double vLTINCAMaS, double rtHPeGszFPrmz)
{
    double KhxHEQhfNq = 859249.4594407915;
    bool pRxCGz = true;
    double DVEjskKMQpBk = 993356.9555899297;
    double gjaZcxL = 202283.43043666438;
    int UBXQpbvUJFtvPqI = 779646908;

    for (int jPYVamCBU = 240466760; jPYVamCBU > 0; jPYVamCBU--) {
        KhxHEQhfNq *= vLTINCAMaS;
        KhxHEQhfNq += vLTINCAMaS;
        DVEjskKMQpBk *= KhxHEQhfNq;
        vLTINCAMaS -= gjaZcxL;
    }

    if (pRxCGz == true) {
        for (int aqJxXlqmUTtqD = 1668140554; aqJxXlqmUTtqD > 0; aqJxXlqmUTtqD--) {
            DVEjskKMQpBk *= KhxHEQhfNq;
            rtHPeGszFPrmz /= gjaZcxL;
            vLTINCAMaS += gjaZcxL;
            vLTINCAMaS += KhxHEQhfNq;
            KhxHEQhfNq -= KhxHEQhfNq;
            rtHPeGszFPrmz = vLTINCAMaS;
            rtHPeGszFPrmz *= rtHPeGszFPrmz;
            vLTINCAMaS *= rtHPeGszFPrmz;
        }
    }

    for (int mTpnPvShFF = 842956330; mTpnPvShFF > 0; mTpnPvShFF--) {
        gjaZcxL /= DVEjskKMQpBk;
        KhxHEQhfNq -= vLTINCAMaS;
        rtHPeGszFPrmz += vLTINCAMaS;
        gjaZcxL -= gjaZcxL;
        vLTINCAMaS += DVEjskKMQpBk;
        vLTINCAMaS = vLTINCAMaS;
    }

    if (gjaZcxL == 993356.9555899297) {
        for (int dkAXofnJphyyMrO = 1266778743; dkAXofnJphyyMrO > 0; dkAXofnJphyyMrO--) {
            DVEjskKMQpBk += rtHPeGszFPrmz;
            DVEjskKMQpBk = KhxHEQhfNq;
            gjaZcxL -= KhxHEQhfNq;
            gjaZcxL += vLTINCAMaS;
            vLTINCAMaS += DVEjskKMQpBk;
            DVEjskKMQpBk += KhxHEQhfNq;
        }
    }

    return string("KoZcWBDTNZvPFLvmHfyXQFJFvqdlOzxzWmxzpYUgGmKGXDAlpQkNHlPOVDBEdhtPqdaNyvthSeirefTCwkxeeiKhojJzKDhsymAlRuIKcxjULNBYcuzYnndla");
}

double HHvYcV::axHkZaALZWn()
{
    bool YdQgvMAj = false;
    double bwGAfgacpjxz = -559803.8151646348;
    string hfkstkhoGbtBdU = string("rudJVgFetDALWLBtLsFKlCAVoSCWqruDhwNwHlZfsJPjl");
    bool qktdzkud = true;
    int oCYkuecvrxX = -841289539;
    int OJtFxUZEEoEjvD = -1711115757;

    if (bwGAfgacpjxz != -559803.8151646348) {
        for (int cFeKeotj = 1108262640; cFeKeotj > 0; cFeKeotj--) {
            continue;
        }
    }

    return bwGAfgacpjxz;
}

bool HHvYcV::XWOAyJBnPIuJ(int dLlwHJuSWPNzwr)
{
    bool gMCOViPPLL = true;
    bool QUJemikUakTVQEsk = true;
    bool CIFKBrF = true;
    double aKKtW = 477958.97402219236;
    bool MyTslgshTuhvjV = true;
    string kPybhBqlO = string("VrISXBJaMtVezjGSjcMlbySAkelWpHLfesQGEaGfxhgyCEKPgOUglylKpkLdgHTDOlaHlbjtvDKCHJmbjWuQdcovODsQFzYneaNVjRAmfbyTuohchvxWUFlREnpTFCFGwGOiQrnLrhONxMmEuTlpIWqwTTWPCJWDQsQ");
    string wlTLyQqjxmUHcXMC = string("nEmWtuKiyZyeeGAmwRBlAYiARqMsTOWWFiudwUKVVctEwicRRXETRkObOmtXMdtxtwRHqQoMOFidJLdTXcLNqWxpCmPnxuUlLWWdoTQSCpLMylmbwlNYsvQyXoFvXzJvjpTawEptkTDIsJCaNLPiEQIbQiFxoPXrXNrWmCdOpTDUDtCbQDxLHMewijZVcAUpffotmytioCELpLvpAFC");
    int OKQSWFokcvVhl = 1636929705;
    string QyaPUcFCtiFrKq = string("KqREfhrGMRUEznXzVMtyOVfpsSUjkxhjYhNyNXhxrULnrrlBlxOYIogoycomSlstCjBfDmstjmfTiumerNRtceRi");

    for (int lSKpkizqnb = 2076188050; lSKpkizqnb > 0; lSKpkizqnb--) {
        dLlwHJuSWPNzwr += OKQSWFokcvVhl;
        OKQSWFokcvVhl -= OKQSWFokcvVhl;
    }

    if (kPybhBqlO <= string("VrISXBJaMtVezjGSjcMlbySAkelWpHLfesQGEaGfxhgyCEKPgOUglylKpkLdgHTDOlaHlbjtvDKCHJmbjWuQdcovODsQFzYneaNVjRAmfbyTuohchvxWUFlREnpTFCFGwGOiQrnLrhONxMmEuTlpIWqwTTWPCJWDQsQ")) {
        for (int kcTguc = 127654434; kcTguc > 0; kcTguc--) {
            continue;
        }
    }

    for (int oaJBhROTh = 2012741811; oaJBhROTh > 0; oaJBhROTh--) {
        QyaPUcFCtiFrKq += kPybhBqlO;
        gMCOViPPLL = MyTslgshTuhvjV;
        gMCOViPPLL = QUJemikUakTVQEsk;
    }

    return MyTslgshTuhvjV;
}

bool HHvYcV::erEqvnuAeVU(int CaZCe)
{
    double ZaSVYPC = 838646.6020986909;
    int JkrdgZMKFRzR = -741726359;
    bool TNPcvOi = true;
    double ilcYQEVjylU = -232072.29018039035;
    int YOgNlUfLbHGqgjis = -1455845782;
    double fWVdfcSZdG = 247385.56478473614;
    string mALzpP = string("swnYlWdUIxMKzikrtTYgvqizeaORWhaZNPjTOzQCYmCkriKkWBHCmAnlImOnNpDiLleFYXnNMXxlvdMIHFhrRzKoxlGzdLcnHqHlXyUuiFosOQJFaInwmwoMOtSlpIYVLxjEFbTqBcOMEEgxetIXqnPhIezaJKGNGcaUYSIsRJIAXLrROmRwOKewJwMIQTJslJZQACiazgxSHniBHOJonBbFtNJZNHacJsWu");

    if (TNPcvOi != true) {
        for (int txljxiH = 1980549449; txljxiH > 0; txljxiH--) {
            fWVdfcSZdG = fWVdfcSZdG;
            ZaSVYPC = ZaSVYPC;
        }
    }

    for (int LpvEe = 1549699598; LpvEe > 0; LpvEe--) {
        ilcYQEVjylU -= ilcYQEVjylU;
    }

    return TNPcvOi;
}

double HHvYcV::uZerNqhslIaj(bool bpTWS, string aBcJz)
{
    double IQxzAnq = -222874.85450970902;
    int JCDuPnsvkX = -381806237;
    string AWXZxTGHNBrbSMwV = string("MZORfZJXtGDUpycsCIRXSjCAIxYLirWdnTmEQdOHARlorkKHuwJbhqjEWNohSGMHbPJklIEstiqpEtIloYfNxYvGvGEHDkSTaDUgoiFRsOShaxbSiZcjHwzJYoKoyVLkkMJENnECLg");
    string yaUNyGy = string("ly");
    bool YaladyaZrutrd = false;
    int JGMxvKkjlleoUZNG = -604180722;
    int LfucwUU = -104987598;
    double CoEso = -778409.8440003754;
    double PcnUngBCTlXTllq = -134399.3925694495;

    for (int qgISxKvghHmUi = 1562342149; qgISxKvghHmUi > 0; qgISxKvghHmUi--) {
        JGMxvKkjlleoUZNG += LfucwUU;
        PcnUngBCTlXTllq *= IQxzAnq;
    }

    for (int JFplTPXRoFbYREJt = 81182127; JFplTPXRoFbYREJt > 0; JFplTPXRoFbYREJt--) {
        JGMxvKkjlleoUZNG *= LfucwUU;
        AWXZxTGHNBrbSMwV += yaUNyGy;
    }

    for (int jIshSuBItXUR = 874961836; jIshSuBItXUR > 0; jIshSuBItXUR--) {
        continue;
    }

    for (int uOrutSPJy = 1606856348; uOrutSPJy > 0; uOrutSPJy--) {
        continue;
    }

    for (int RJBVLC = 1919529764; RJBVLC > 0; RJBVLC--) {
        yaUNyGy += aBcJz;
        JCDuPnsvkX += JGMxvKkjlleoUZNG;
        IQxzAnq -= IQxzAnq;
        LfucwUU *= JGMxvKkjlleoUZNG;
        PcnUngBCTlXTllq *= IQxzAnq;
        CoEso = CoEso;
    }

    return PcnUngBCTlXTllq;
}

int HHvYcV::dkklIN(int JEsgUEooDImhr, string foazFOInTqWbK)
{
    int VvfYIaOWOZM = 212113314;
    double cyOoLRErAqmbU = -58050.15438536823;
    string qmBmrlNDTBKV = string("NjKkGSdwSesKdIpNOeZmPpcVNOHFSwcteJzbTRaVAUfqirJEPEhnkHrodABWEKUecGKKAmHJlTBFAfnrLlwlNibLxnOzFwTNgFwODKAYZJUPMoPjIYnVjhNUjXIlrPJlLRCWhSffPogJJLBVxVgIqTqnZrECkdIyvYzVLznmRLFthmyKRLPkNdiKuVguxXFuHvfzB");
    string ofMlwbTWkmwtaLh = string("aMMYEaMXdTPHirONwKlCeCMMNxIMPzeCRhVWtYovkLsRECLkYLHExGPUDXjmBCgoLTrUZnyBqijAKXNSAWvkkgtfaqmUzziTr");
    double NGtowaJaq = -184483.6979303851;

    for (int GNBeh = 76397889; GNBeh > 0; GNBeh--) {
        ofMlwbTWkmwtaLh = foazFOInTqWbK;
        foazFOInTqWbK = foazFOInTqWbK;
    }

    for (int SkHUvxpsMsKwVcaH = 12710169; SkHUvxpsMsKwVcaH > 0; SkHUvxpsMsKwVcaH--) {
        cyOoLRErAqmbU *= cyOoLRErAqmbU;
        qmBmrlNDTBKV += qmBmrlNDTBKV;
        NGtowaJaq /= cyOoLRErAqmbU;
        NGtowaJaq /= cyOoLRErAqmbU;
    }

    for (int shcMk = 1760290147; shcMk > 0; shcMk--) {
        qmBmrlNDTBKV = ofMlwbTWkmwtaLh;
        qmBmrlNDTBKV += qmBmrlNDTBKV;
    }

    for (int MoNIflFUPvn = 1572352440; MoNIflFUPvn > 0; MoNIflFUPvn--) {
        continue;
    }

    if (ofMlwbTWkmwtaLh <= string("aMMYEaMXdTPHirONwKlCeCMMNxIMPzeCRhVWtYovkLsRECLkYLHExGPUDXjmBCgoLTrUZnyBqijAKXNSAWvkkgtfaqmUzziTr")) {
        for (int HJTUCvpDqrIKmoL = 767255938; HJTUCvpDqrIKmoL > 0; HJTUCvpDqrIKmoL--) {
            cyOoLRErAqmbU /= NGtowaJaq;
            ofMlwbTWkmwtaLh = ofMlwbTWkmwtaLh;
        }
    }

    if (JEsgUEooDImhr != 212113314) {
        for (int NWsUaOvhqtoq = 1441087440; NWsUaOvhqtoq > 0; NWsUaOvhqtoq--) {
            VvfYIaOWOZM /= JEsgUEooDImhr;
            qmBmrlNDTBKV += foazFOInTqWbK;
            ofMlwbTWkmwtaLh += qmBmrlNDTBKV;
        }
    }

    return VvfYIaOWOZM;
}

string HHvYcV::DrFpisKWzRTe()
{
    bool bGohaZnRexAel = true;
    int TenISl = -1643265234;
    bool wSbcE = false;
    int lViMXDhtrNWPB = 2074757059;
    int rpjnjMf = -659682284;

    if (TenISl != 2074757059) {
        for (int EQzCSqoXvBrTPls = 326932438; EQzCSqoXvBrTPls > 0; EQzCSqoXvBrTPls--) {
            lViMXDhtrNWPB -= TenISl;
            rpjnjMf *= TenISl;
            lViMXDhtrNWPB -= lViMXDhtrNWPB;
        }
    }

    return string("lhzlHTePxuXMzeXRsGIXcXFLjYQHCJvZNyIvXhPgryhTgZhEtAOydrYtSNJsibLZEVbMMlKEnDQBIvQZdAUagaUkbbUmxfenDLiRlZMsB");
}

double HHvYcV::HhORjLFyjDyBJFe(bool FSdwBmPDzVnGz)
{
    bool dlnLqaTcL = true;
    double aStMuKoEU = -187342.92685859202;
    bool VoTSomjjnxYG = true;
    string HVLGiO = string("nIhQOEkMzGcYVSRaczYsyLmmmNuGzWyGgKLSorDcLNupDQahMUkkiMTiVEpejLbFZGTzvOIJTpsKXXUdQpUemZLcaBWNvEXbxeuQYkHvRGJxPKpHydwByXRiVEUErmPKcJWFCEWNFahnhBuUvvfTs");
    bool zsdlqVlORUpET = true;
    double rgqhFJ = 436592.375118183;
    bool alUvzhgLPZ = false;
    bool YqJBy = true;

    for (int JkiYMi = 1391877277; JkiYMi > 0; JkiYMi--) {
        zsdlqVlORUpET = YqJBy;
        rgqhFJ -= aStMuKoEU;
        FSdwBmPDzVnGz = zsdlqVlORUpET;
        alUvzhgLPZ = ! YqJBy;
        FSdwBmPDzVnGz = VoTSomjjnxYG;
    }

    for (int SSFBXQJ = 208123269; SSFBXQJ > 0; SSFBXQJ--) {
        alUvzhgLPZ = alUvzhgLPZ;
        YqJBy = YqJBy;
    }

    if (dlnLqaTcL != true) {
        for (int nicXEnPsUj = 1876493174; nicXEnPsUj > 0; nicXEnPsUj--) {
            aStMuKoEU *= aStMuKoEU;
            rgqhFJ = rgqhFJ;
            alUvzhgLPZ = ! dlnLqaTcL;
        }
    }

    if (alUvzhgLPZ != true) {
        for (int dYbHelQMUWVIF = 38045667; dYbHelQMUWVIF > 0; dYbHelQMUWVIF--) {
            alUvzhgLPZ = ! alUvzhgLPZ;
            FSdwBmPDzVnGz = YqJBy;
            FSdwBmPDzVnGz = ! zsdlqVlORUpET;
            YqJBy = FSdwBmPDzVnGz;
        }
    }

    for (int FAgEPUThLrBd = 1433944489; FAgEPUThLrBd > 0; FAgEPUThLrBd--) {
        rgqhFJ /= aStMuKoEU;
        alUvzhgLPZ = ! zsdlqVlORUpET;
    }

    if (HVLGiO <= string("nIhQOEkMzGcYVSRaczYsyLmmmNuGzWyGgKLSorDcLNupDQahMUkkiMTiVEpejLbFZGTzvOIJTpsKXXUdQpUemZLcaBWNvEXbxeuQYkHvRGJxPKpHydwByXRiVEUErmPKcJWFCEWNFahnhBuUvvfTs")) {
        for (int ZHXiwj = 612175556; ZHXiwj > 0; ZHXiwj--) {
            dlnLqaTcL = VoTSomjjnxYG;
        }
    }

    return rgqhFJ;
}

bool HHvYcV::IFIAg(int gIsQRqQKSCOtsmwD, string qdPjCyp, double QaUxQmtQe, double IhRMCoi)
{
    int dctOsNPVYJhGbVy = -1058980413;
    int vDEdHOmJuib = -1137939360;
    double YHxWq = 976151.9996588834;

    for (int jButWqC = 587923831; jButWqC > 0; jButWqC--) {
        gIsQRqQKSCOtsmwD -= dctOsNPVYJhGbVy;
        gIsQRqQKSCOtsmwD -= dctOsNPVYJhGbVy;
    }

    return false;
}

double HHvYcV::oTtjG(int WqjLEqoR, string FqksXLftAssK, int QjFUnjR, string lFrBqOkySm, double zsSDzihUTsE)
{
    int JanaBsnQBEcKcK = -1955957063;
    string dJvWtW = string("OmKeVQPKreQUqJsNBHoSUbMIPfaZXThUEBSZySLHPNmhEdlzbohtsZoVljBENZmhdNLYStQRURxaYwIZbYJhrDtMYuZxOJJTSbSoCjfeQrlofqMMhGikktggeImnkWzIqelototUIFDcafmwkvQQHQQu");
    int CuEVizMHXlgj = 815396813;
    double VKcQZmSY = -385515.6231841707;
    int NGHGHxwpwKFW = -832519122;
    double pOkUwmRlCfsFwbH = -432052.52287449164;
    string CAxgetYhcicFtNNr = string("QfDLuNwMCqaWSzZmHcrRBwyrNxnzLutuRItToNAujRytLSCCxMSVczQxnjDzmt");
    double IlaPfWAyPteu = -515943.3746115114;

    for (int GVrPlkxWAyXGdNCS = 150691725; GVrPlkxWAyXGdNCS > 0; GVrPlkxWAyXGdNCS--) {
        FqksXLftAssK += CAxgetYhcicFtNNr;
    }

    return IlaPfWAyPteu;
}

void HHvYcV::oONCchfQOcCK(bool CYYpMznN, int NZPxy, string VvELNCCLRc)
{
    double gWFYDXGFjBmKM = -551833.3613002618;
    double NFTCfYFDuw = 554051.0227405747;

    for (int TdWpDaYiI = 1907482075; TdWpDaYiI > 0; TdWpDaYiI--) {
        gWFYDXGFjBmKM *= gWFYDXGFjBmKM;
        NFTCfYFDuw = NFTCfYFDuw;
        gWFYDXGFjBmKM /= NFTCfYFDuw;
    }

    for (int FUEtcuADmgOOSjy = 885064405; FUEtcuADmgOOSjy > 0; FUEtcuADmgOOSjy--) {
        gWFYDXGFjBmKM += gWFYDXGFjBmKM;
    }

    if (CYYpMznN != true) {
        for (int YXczmaWDFjdzFwkq = 602084744; YXczmaWDFjdzFwkq > 0; YXczmaWDFjdzFwkq--) {
            continue;
        }
    }

    for (int JkEaxanlYwRrXolU = 1760002; JkEaxanlYwRrXolU > 0; JkEaxanlYwRrXolU--) {
        continue;
    }
}

bool HHvYcV::KWCeGARBobyqMwX(bool vElqHvHJFbl, int rgnmvscjpNJ, double cGymeqDJEPfBzJ)
{
    int HAQsKhehmzSfpar = -1545347228;
    bool WJGzEXfrN = true;
    bool czOPwYyuawanOI = true;
    int kFXue = -557710563;
    int gStMrxwlVtf = 1089880853;
    int gZvFYtfIIZiKqv = 879944987;

    for (int IEigTLlbSeiVeY = 825934146; IEigTLlbSeiVeY > 0; IEigTLlbSeiVeY--) {
        kFXue = rgnmvscjpNJ;
        WJGzEXfrN = ! vElqHvHJFbl;
    }

    for (int djATJyR = 1935726421; djATJyR > 0; djATJyR--) {
        continue;
    }

    if (rgnmvscjpNJ < -1545347228) {
        for (int AQbGabNqNgW = 1684542049; AQbGabNqNgW > 0; AQbGabNqNgW--) {
            continue;
        }
    }

    for (int LvVxQCIdobjFlLyS = 1153969619; LvVxQCIdobjFlLyS > 0; LvVxQCIdobjFlLyS--) {
        WJGzEXfrN = czOPwYyuawanOI;
        gZvFYtfIIZiKqv /= HAQsKhehmzSfpar;
        gStMrxwlVtf -= gZvFYtfIIZiKqv;
    }

    return czOPwYyuawanOI;
}

string HHvYcV::BkeHlL(int kYSPadzlC, string hxNQQDZyxMHIQu, string wndUMnN, double vLVVX)
{
    bool hUFOufEWvSh = true;
    int zQUtRjjx = -1317599175;
    string pBWuDjaPtkY = string("uzYejaPOSlNNycWhFhpVwhuNzmgdLLlkvLbpzBocAZsDDMpEEqufOXbIKqiaMk");
    double UdWmBC = -465654.8505661031;
    bool xyedszAN = false;
    string iaezabiGDQQEpw = string("YdVLXUaQdmRjivFytDnzAWloJKJUdlsCzuLKZYFbHHIWTUsmhsAClbOyEeZJMemKUXUZhVQnxLFpIHozHCNvrsfkuWahygvithGXDVrZNuIjnDmyjJMWtUmaPbRjgWrOQVhwlZJnPUQsONgEpWFbYRmNxIBBJgtsJANqqjVklBQevDzaSTGBhoBbSGSroMrGfGTWiEwUEoejXoJUIrUsCOVUgzyCuXt");
    string zqvfspcWQUAdFw = string("eWTVyeekMYsKtBVvqohKHTficyHPaNcrXMVyaUCFdvyojshdyMuIVwzaWUgAgMvRWUkvDoboxYbftcITSorUCoLephjTiMnRLkPbfjUUxEJRozoYDpiTvJKmtcDQqABK");

    for (int SyRqLJPYB = 292065738; SyRqLJPYB > 0; SyRqLJPYB--) {
        zqvfspcWQUAdFw += iaezabiGDQQEpw;
    }

    for (int YhmFlNj = 1366865892; YhmFlNj > 0; YhmFlNj--) {
        zqvfspcWQUAdFw += wndUMnN;
        hxNQQDZyxMHIQu = zqvfspcWQUAdFw;
    }

    for (int ITJWl = 2067681330; ITJWl > 0; ITJWl--) {
        continue;
    }

    for (int sWUWmoXfI = 1539145855; sWUWmoXfI > 0; sWUWmoXfI--) {
        iaezabiGDQQEpw += hxNQQDZyxMHIQu;
        wndUMnN = hxNQQDZyxMHIQu;
        pBWuDjaPtkY = wndUMnN;
        hxNQQDZyxMHIQu += pBWuDjaPtkY;
    }

    return zqvfspcWQUAdFw;
}

void HHvYcV::UcakmMbHPDY()
{
    int vjHQKlrJjiRiK = 1929664675;
    string skAVcFRAXxn = string("ynUrmcVXrGcMpPiEPuTxMfjNC");
    int vJkAjNyfyyahH = -1407008309;
    double EEWckjC = -246233.3505606923;
    int cBOOwZWHu = -1012210026;

    for (int QdUpLMDaWN = 1127417474; QdUpLMDaWN > 0; QdUpLMDaWN--) {
        vJkAjNyfyyahH += vJkAjNyfyyahH;
    }

    if (cBOOwZWHu == -1407008309) {
        for (int CgFIDDpSpHZ = 1218430616; CgFIDDpSpHZ > 0; CgFIDDpSpHZ--) {
            cBOOwZWHu *= vJkAjNyfyyahH;
        }
    }
}

void HHvYcV::DbDTajh(string cQcExF, bool QhrubsydzWbSd, double DyxIrzULtjDOe, bool NkbWoQY, int eYkVAxDSB)
{
    double OEsovZcYoirRre = -568430.712143929;
    bool SeiMjYAvomm = true;
    int ittJJurbPsE = 818043993;
    bool vxULeUq = false;
    double fBYgu = -698216.0458670666;
    int HkovfiXCAkhU = -533912319;
    string UqlrSIq = string("xVzjwBboPMGZBucuZkNVczQakZHKTDkjMKXJfhZxWQabaSAkxKqJOWxyVTOpvPOyZvUhebZNrhsBaPcFTHuxkBfjbWhizQXfNueHSLRLYEOPuNWvfjaMjSDXJrjPJnpUaVVeckeugHLpVwmqXgydPsAS");
    bool rWbWegqkCZl = false;
    string spCvBhaRNbtKSwoN = string("yBZRLNLWjulsfakaLZfmzcRLMzDKdSelpcYcPNTlRRYpygRicBNFGeKIVFHYlLmOJGTuvZnywdoZoXpojIlOUyxZibrgrgMUkHKoGiQpUUZFRTNBBzJrJZNPAlBIrKZqwoHPJEWgedVJJseNGNaDsHaDNRCNLZbaQuEmpsYzsrh");
    string cikmR = string("sAPVDxCKzTwCrzgTKNCzsEDawUkZpMKVNbCtmgViWySxKmWtzjvvKyiozMvfKhtgYTPleecTpqVZchGAXqVUoEIjeKEInuSbJmQTEpKxtABQMGlrtMkgxUxBAIRkmUtHzvKVRjERwVMzDuhowmreBPUNwZpD");
}

HHvYcV::HHvYcV()
{
    this->gckRkljLVjSpjrMx();
    this->NOMjVREoX(-1030707.2648306096, 896677.5103691751);
    this->axHkZaALZWn();
    this->XWOAyJBnPIuJ(-1498147560);
    this->erEqvnuAeVU(1399420388);
    this->uZerNqhslIaj(true, string("QEYEbyCZEjjpDgcWdNWVCvSwrXtZMsJogwiWmSaluloEwgJRLaFMenPonPYkvtxImqefTbJDJYVOZXLKfqPhvmqNNydBYPRNvTaNYrxgSTcSwmRiIGuyrNkGkVRjQOgPyVbKfcLJottBDqYpFoGvtcuBiddbjxAgYIGJJpmiUTUQvebVEsNIpsmIE"));
    this->dkklIN(-625567794, string("clnPyCEtsadhakPbBiAqONQQZrSCfIVAyRCOwGXTdxtZRAwALhW"));
    this->DrFpisKWzRTe();
    this->HhORjLFyjDyBJFe(true);
    this->IFIAg(-1469641020, string("EVeFqEMAoGVRYJFahxCiKewQluzMqUbDUBtAItOeFPPLkZnkbTiqQdffyfpTwoMeXseldtLQtYHsqFGCphpskMxMiFhThxWTeospCSP"), -583563.4441167675, -661367.7018273547);
    this->oTtjG(64845073, string("EHzCTtyJLcKYLZIYSMqUmnJWFJkCGSnNCaoOqQuedjFYMiYPyrVMWiqlweqNAnDHDBcLFjaIexuLMglITNXxLDGYunVfGqUggrTQLKeyFdAymsjFUIaAlCEnTIyHQOUmOGcUExf"), 366291929, string("sKDdzqCUOylMtfHQrcbWmcZx"), 1038380.850381907);
    this->oONCchfQOcCK(true, 1584781896, string("eItudfRFNQCWojEaHsYVKUhSvYTwqBJTelKWqJRoiKStGpwODLNFqwLwtYiM"));
    this->KWCeGARBobyqMwX(false, -952103792, -201298.6262666969);
    this->BkeHlL(940698538, string("LbJqepOGlXJSYOJlrylJgtulMJdQJPqOERZQepmNbFuRaSzSozDpTULzPqKAmbXfAZesaNPHmXAUssEUxAYqDhVQbCZPlTiXyUVUxJNmuHJpLHePhkVaptnhkURBITxGXbDBCzhDqvJhBRBAfeueoYrtsYGknDJqqQQunwsoROueCdbgOGhQLENPqyWSQhKMGjElbtooWTJaJhYXFrnOvYXGLoNRuTMfblwWJxyWrSTcarMXgGqFsChrYLHg"), string("VNyMruTWOEVLiTHrIJWnDUxfhwfBOQqVWtWazApPVxLchjVlYqhwlGYKtzmLEkQGgPRNUUDVeItkWEmGRJVPyXNsZQTkRauKJcVxcUFDdfZZEtWLNqLNxU"), 267751.0358747796);
    this->UcakmMbHPDY();
    this->DbDTajh(string("MIaoqmlIuLyajYQCmXwkhaqwTimIYyplLgkwBSHRmkcDGNIWcFxOKsIfjTQQXkEYkJZIqmuwBEfUffKfPxoPUitHbUIdqCTbiTcShslshMxhKtTlmokTOlgtNMDsNbjAlXmzdmriWcZINhkKysMyQxHnGZniXjYtCBMGnQSYcMzXtxbqxKZZRhbcbKhsfRGyILUNys"), true, -658366.9579093953, false, 1959607228);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AiMyAtI
{
public:
    bool PWAMWGqspoDuiKRU;
    bool MYXgcykkUwSVWi;
    int RNPVWXr;
    int JZNHXDgDDWbKQiSR;

    AiMyAtI();
protected:
    string ABnqdPuARodlrfm;
    double WsiBrhDr;
    bool eTcOFLXcZiNfrmnB;
    bool rQGCEi;
    bool VgFYwoujxznpPlpF;

    string pmfzUfvcT(string ZSFDEjvZMIN);
    bool mDakyLBQDdyX(int GUKuDVNVzmsyOuR, int XuOYMbLPitjsVEX, double eLwDieRH, string wAaUdG);
    int HuZYwRUrb(bool bXPqnYWDxESumZT);
    int HaXixQzvQw();
    double KwBRQbbvZTP(bool RvwgjtlkaRs);
    void bYDGQn(string mpCMpQ, double CIDxxmB, int EKdNwDeTxUxjsVqA, int LuWyqNIhQVZExEi);
    int YsvsXCFjf(bool WxNfTPCqQeHcmEo, int RwoxlqkCtr);
private:
    double snMOhZNxcfws;

    bool sWCaED(double HXFOEmMCebpGJruj, int uOCGm, string XamXvIC, int qeEVokEnMoGyypR);
    void sctSZ(string pPAJoFuOjevJzfq, double sdsvPYpQlPsPwjjq, string MlrXKnks, string yYNHvFDnrsCoGvOg);
};

string AiMyAtI::pmfzUfvcT(string ZSFDEjvZMIN)
{
    bool mGtKu = true;
    int aqIBm = 858564763;
    string oeOEXdW = string("zXeBdQyphelsRwsTLICAeawpz");
    string hQMkQsufjYQXqL = string("SVGknZqyLMpdSsGVhHmosxebXFJrapbmOMjywDfyZkpxCZDAdRKhhdMWgqYrWZVlaCMNgASxNvRoyyraGJALkXbKcGWVaYlXKxRXaMfGsRhGeWxlQBdaPYegFYqmecNNehTYbcBgVqyqfbqZXuAafQbXxfEzVpqnlkhCmXtbgPzqaTPlDiAOcVaEiXwZZn");
    bool uGGPcdWPx = false;
    double LWjDcxt = 468956.7131311812;
    string hLNoBLCIDBgJQ = string("BXoHWinjINEkbCAunGJjnYPRRHqybicDRRQbgZXOVqyVbLBFTemuAgAIZcRtFUOZRrSxaznrUIfVPRjyfwfyHKZeugQHlzbPgVUSWtrSccKfHPcEMjvKQeCWpiWiKKiXIznrMRrgrjuapnCQISLrIeoarkoKJQczNIZJnyIEeHXJcTwxSEDNxWBsvJSLmUGphFhEQYcLudmMbpImMBtcGJFeYuQZJdpguZB");
    double XNGZNkAfHFjGvvT = -824770.3032355083;

    for (int wVesrvdfwZkf = 1143392975; wVesrvdfwZkf > 0; wVesrvdfwZkf--) {
        LWjDcxt = XNGZNkAfHFjGvvT;
        uGGPcdWPx = ! uGGPcdWPx;
        hLNoBLCIDBgJQ += ZSFDEjvZMIN;
        hQMkQsufjYQXqL += oeOEXdW;
        LWjDcxt += XNGZNkAfHFjGvvT;
    }

    for (int GrdkJaPXxA = 1985982916; GrdkJaPXxA > 0; GrdkJaPXxA--) {
        continue;
    }

    if (uGGPcdWPx == false) {
        for (int lVKxnSSDqVvLVxQ = 2104667557; lVKxnSSDqVvLVxQ > 0; lVKxnSSDqVvLVxQ--) {
            hLNoBLCIDBgJQ = hQMkQsufjYQXqL;
            hQMkQsufjYQXqL += hQMkQsufjYQXqL;
        }
    }

    for (int SkIGloyMWnZnHnZT = 1878220307; SkIGloyMWnZnHnZT > 0; SkIGloyMWnZnHnZT--) {
        ZSFDEjvZMIN = ZSFDEjvZMIN;
        uGGPcdWPx = ! uGGPcdWPx;
    }

    for (int JLJkJPKBQ = 1593254512; JLJkJPKBQ > 0; JLJkJPKBQ--) {
        hLNoBLCIDBgJQ = hQMkQsufjYQXqL;
    }

    return hLNoBLCIDBgJQ;
}

bool AiMyAtI::mDakyLBQDdyX(int GUKuDVNVzmsyOuR, int XuOYMbLPitjsVEX, double eLwDieRH, string wAaUdG)
{
    double fngnC = -605021.4548559695;
    int fMFcLDswMN = 1804202461;
    bool kqnxKQCCoHUTlT = false;
    string rfMFJI = string("mjPqUadiGTdSZfSbuFIuVfDpXUdqgoOlbqHANaXXWdSPDIqsTecqmjJbFYQRuDDdjbfmgdpXxMSAdzAafCOkSgKGEpDMagsySfUbqvBaPAxKtTocsZVyAgSQijCbecGogBhsSRjdzHFzjuPvwEStNVNykamp");
    double ZLyNBa = 232245.74808196755;
    double CdvisFPiv = -575587.2807911652;
    string xWdFKULyWdSmkgV = string("HqkfyWEnSMbTtWghdXdQFESDpKYZjLMCJGRVoTriuOcYNnAsyeprkFQllvxUWTyaIuzeQMVznRwVVqkyZbzfYijaACkyMOuBEUruSEUDqZjYulAjLJRRUINgYzsZQSKOZVQOFGfUgyFFWCkrlTSZsBAUsHraWpcgyBUcfHaiKMgQWcSWnstAixJHeXIzzrNLGbSHIwHpvdbEkoNSZGMjnLIpUTi");
    bool lLBIqUkr = true;
    bool fKdClD = false;
    int vMHkoWAHkF = 1843391270;

    if (GUKuDVNVzmsyOuR >= -1644414131) {
        for (int RULceSKqcnjYlbtx = 1433018588; RULceSKqcnjYlbtx > 0; RULceSKqcnjYlbtx--) {
            continue;
        }
    }

    for (int GlQZxE = 1809351115; GlQZxE > 0; GlQZxE--) {
        CdvisFPiv = fngnC;
    }

    return fKdClD;
}

int AiMyAtI::HuZYwRUrb(bool bXPqnYWDxESumZT)
{
    int VgNnUCasgDxVJ = -735183051;
    bool YhtzwOoHvSXcWN = false;
    bool dtKLoNvesP = false;
    string qydNc = string("kUzGEHLfXYuhyVsYdpTAamkUPfjGTFgmphDEQTIxYMEyMIkPoXfikkqHUuSxPZdbyWuvqhSUHfpgIQZFLoWyaPFHWvUAPCGvVTqKVtNUudnVGKFzfGBxDgpwDrLpJrlSBlqVHkKJxlnotvFiRomXbnPaqZfNkOLqCJBPKSCGbjfWjbLvjecaiOyHZlJozfsTQZB");
    string xzKBKIsLGJlUri = string("dPSnMccNFuJsFXsCpXtsfxQBkJGMedzxwkMCKgkNBkYgepHBVG");

    for (int IhfvNI = 38410631; IhfvNI > 0; IhfvNI--) {
        xzKBKIsLGJlUri = qydNc;
        YhtzwOoHvSXcWN = ! YhtzwOoHvSXcWN;
        YhtzwOoHvSXcWN = dtKLoNvesP;
    }

    return VgNnUCasgDxVJ;
}

int AiMyAtI::HaXixQzvQw()
{
    double OxpdfxWeLaY = 824061.6439478975;
    bool sDPfs = false;
    double eDxbvR = -640614.5930714663;
    bool SxFRPx = true;
    string HnzZAw = string("eZQImaptFanabXaREQFmikOcSuWFbelWoTDmlfHPPPKBFstVINtAobFYfhBJElduaByoHcSeGUjxHRrGZfWCiBd");
    string QTYEtOcudGNvoheE = string("UVKVhuNaHFzSBThxSWgOCjMZlWvkYdLPIVoYuLtIOoYEwKcuHlhqawtJyRODhfgdDerrCSzLwNhcQAjzEbYBjOtDVSQkisdZgTMJyLqCqDwGuxWCzGNjhJvY");
    bool WNHrZxFwzOk = true;
    string HZKLXLzdth = string("hDoNnUgjCRlvHkTYAmDgQXyGyWuOcFzikQlLrXdNEyZwIuCuNNAsHbgBdGntOcQuWOWdEoBzPJDKQEHlwlPxgYUyKbDYYXHOiM");

    for (int MnTmXkpbldTu = 1676128608; MnTmXkpbldTu > 0; MnTmXkpbldTu--) {
        SxFRPx = ! SxFRPx;
        WNHrZxFwzOk = ! WNHrZxFwzOk;
        sDPfs = ! sDPfs;
        HZKLXLzdth += HnzZAw;
        SxFRPx = ! SxFRPx;
    }

    for (int IdfHO = 1294339542; IdfHO > 0; IdfHO--) {
        HnzZAw += HnzZAw;
        HnzZAw = HnzZAw;
    }

    for (int ZcMqqATmgI = 1443255213; ZcMqqATmgI > 0; ZcMqqATmgI--) {
        continue;
    }

    for (int QedjvhjRo = 1566239068; QedjvhjRo > 0; QedjvhjRo--) {
        WNHrZxFwzOk = WNHrZxFwzOk;
    }

    return 1827656431;
}

double AiMyAtI::KwBRQbbvZTP(bool RvwgjtlkaRs)
{
    string ldFnQIEswpjetYR = string("chwsyVeWVCGikOpnHRwMIUFmXaALQNvarSibQtzSPYQdHjckKnnJCDnpiLgbphWrsbTRjCQpsxEffmLqKqluZRrnLJZTsDhqmttCcmZMCiAHrKnSdoKFinKwliTlejOrBsYMEEgCzRPnumYwZgaLwgUDidFTdOTKGSduFizoCgIZuQuXibdTQGUvPQaCyfGlzDXyHDsoPeXaymltPjbB");
    bool zYfAJbb = false;
    bool UYJZgr = false;
    double npBcFAyTGfnZKAOx = -801736.8975058339;
    double MnbkBTEIqnNfxyip = -496338.5884828497;

    return MnbkBTEIqnNfxyip;
}

void AiMyAtI::bYDGQn(string mpCMpQ, double CIDxxmB, int EKdNwDeTxUxjsVqA, int LuWyqNIhQVZExEi)
{
    int kvZEflv = -1844669176;
    int BjvSgVPgMWOgdl = 686901715;
    int XArScywPQrnBYZ = 531289181;

    if (BjvSgVPgMWOgdl > -1899233364) {
        for (int qMxMhQFKTiXuEP = 1819506195; qMxMhQFKTiXuEP > 0; qMxMhQFKTiXuEP--) {
            XArScywPQrnBYZ *= XArScywPQrnBYZ;
            kvZEflv -= LuWyqNIhQVZExEi;
            kvZEflv = EKdNwDeTxUxjsVqA;
            kvZEflv -= kvZEflv;
        }
    }

    if (mpCMpQ != string("OEhVOCZkRjiZNRxELhWuGxUYckKHxEQurnSqfFNuvrRRLwFOLizJFFstlnCBYucYB")) {
        for (int cjLjN = 1484672556; cjLjN > 0; cjLjN--) {
            BjvSgVPgMWOgdl /= kvZEflv;
            XArScywPQrnBYZ = EKdNwDeTxUxjsVqA;
            mpCMpQ = mpCMpQ;
            EKdNwDeTxUxjsVqA -= EKdNwDeTxUxjsVqA;
        }
    }

    if (BjvSgVPgMWOgdl > 531289181) {
        for (int lKgEgxVloMT = 1811997745; lKgEgxVloMT > 0; lKgEgxVloMT--) {
            XArScywPQrnBYZ *= kvZEflv;
            kvZEflv = XArScywPQrnBYZ;
        }
    }

    if (LuWyqNIhQVZExEi != 1011609891) {
        for (int gsrAgXxoW = 1311042625; gsrAgXxoW > 0; gsrAgXxoW--) {
            mpCMpQ = mpCMpQ;
        }
    }

    for (int oPOFg = 320876123; oPOFg > 0; oPOFg--) {
        continue;
    }
}

int AiMyAtI::YsvsXCFjf(bool WxNfTPCqQeHcmEo, int RwoxlqkCtr)
{
    int BCZvye = 1251533347;

    for (int xMleXIHTNNm = 131518280; xMleXIHTNNm > 0; xMleXIHTNNm--) {
        BCZvye -= RwoxlqkCtr;
    }

    for (int RIeWhklnzaPVUb = 589413282; RIeWhklnzaPVUb > 0; RIeWhklnzaPVUb--) {
        BCZvye -= BCZvye;
        RwoxlqkCtr += BCZvye;
    }

    if (WxNfTPCqQeHcmEo != true) {
        for (int gEWfCyAmEPKiJ = 1218342896; gEWfCyAmEPKiJ > 0; gEWfCyAmEPKiJ--) {
            RwoxlqkCtr /= RwoxlqkCtr;
        }
    }

    if (BCZvye != -308920329) {
        for (int ZRNycWWpakhE = 814593498; ZRNycWWpakhE > 0; ZRNycWWpakhE--) {
            RwoxlqkCtr = RwoxlqkCtr;
            RwoxlqkCtr *= RwoxlqkCtr;
            RwoxlqkCtr = BCZvye;
        }
    }

    return BCZvye;
}

bool AiMyAtI::sWCaED(double HXFOEmMCebpGJruj, int uOCGm, string XamXvIC, int qeEVokEnMoGyypR)
{
    double pVRpUUEjRfNoZGYR = -923695.5593691975;
    bool ZsLPdroeKNmhxmtn = false;
    string TqdaKPuemZIoAl = string("MWZkWGRNoclczLbjJgFhSmFcZLuY");
    string vBmsyOmIvuZ = string("BLKTH");
    string tWziQgbSmKcbXy = string("kSbrwCbSlqAbUdqKKracdRIWpPsTBiwDGEuWYdaXMeBVPMTkhrM");
    double GMDeJk = 193890.88287875513;
    double rXscmAdCpjuaTI = -329854.5377707052;
    string Fngfbfuw = string("vSPypQymUOPHmqggSkUgpJSQKZrBFpANxTJHULvJtHLYfloMKydfDpgxVToHHMLoTbBNgovJhFmIdVltVseXZmiPWtGuimETqkOzmPieAYvExHWBkHMTlnnLvDeiBFDZEmAXxdYbombeFk");
    int ZpYMXgMIqfMmiKlD = -1766228819;

    return ZsLPdroeKNmhxmtn;
}

void AiMyAtI::sctSZ(string pPAJoFuOjevJzfq, double sdsvPYpQlPsPwjjq, string MlrXKnks, string yYNHvFDnrsCoGvOg)
{
    string hwcuaQv = string("BfY");
    string GqRaTuNhJPooKty = string("eYTGKvWMkIWjdPJZOYmrTproVFTlCpUKySd");
    int fznbutJUNdZbN = -745868670;
    bool hoWgPYIUOMrArTbu = false;
    bool zTCBhmGsvesl = true;
    bool ibAFg = false;
    bool ATfHbucTxDD = false;
    bool QwLtg = true;
    bool kssdolaMwxSxMww = true;
    string ZcTtXam = string("vzjTuORfSSrhqaSaFBbmAveQLLHXvkojCkOWyLjltsyfYOlgFNasQTozntLnzdpapaNkfKVtcPKAgtghXjinmxmAiTQqMYeIBSNVSnukPkmaTiILRFhoUooRlwbkIZTcAUVfxcXmdIkiaVHrveLRQQUNQrRoWDUOzSHSRJbcrNPwybhKlVmBdsUDpAmRLwSZxQKXDtTRNGntwkAlTgjagQFgaYjWpKgNBaPBqGXzrxJaAEGgjtWFfLhJbvp");

    for (int vxRYatnaKIRZcf = 417998274; vxRYatnaKIRZcf > 0; vxRYatnaKIRZcf--) {
        yYNHvFDnrsCoGvOg = ZcTtXam;
        ibAFg = hoWgPYIUOMrArTbu;
    }

    for (int PqxBSsurt = 1561494376; PqxBSsurt > 0; PqxBSsurt--) {
        hwcuaQv = pPAJoFuOjevJzfq;
        zTCBhmGsvesl = ! zTCBhmGsvesl;
    }

    if (hwcuaQv == string("BfY")) {
        for (int UhGkwwQ = 410464086; UhGkwwQ > 0; UhGkwwQ--) {
            hoWgPYIUOMrArTbu = ! zTCBhmGsvesl;
            yYNHvFDnrsCoGvOg += MlrXKnks;
            ZcTtXam += yYNHvFDnrsCoGvOg;
        }
    }

    if (kssdolaMwxSxMww != true) {
        for (int ccauMUdkTFkrDi = 950641357; ccauMUdkTFkrDi > 0; ccauMUdkTFkrDi--) {
            ibAFg = ibAFg;
            MlrXKnks += GqRaTuNhJPooKty;
            zTCBhmGsvesl = zTCBhmGsvesl;
            fznbutJUNdZbN = fznbutJUNdZbN;
        }
    }

    for (int lczKpEhOwDytm = 540469856; lczKpEhOwDytm > 0; lczKpEhOwDytm--) {
        ZcTtXam = ZcTtXam;
        hoWgPYIUOMrArTbu = QwLtg;
    }
}

AiMyAtI::AiMyAtI()
{
    this->pmfzUfvcT(string("JqOubjglHsaDJKvediwChQKFXtbaiymfTbrSTUElHnysdiooYodkeJLUMGLxDfgNMVGpQvhHhrTxgEXejDxYvBYuYtzlXGtPZZMWNkwjLOMAdcJBBpQNfIMRVkPRKTKgDXNRcXkeWBeeyYXKybJQkmBDSqIZaMHgJLWUKulrgjvEyXTGtEudwfJiwARDPDwCwZEePeUPEYLUgegzzYZpVsuNDrzxpjWRo"));
    this->mDakyLBQDdyX(-1644414131, 158293993, -158938.65839240942, string("OGlSGAjRetInqnhoUhiLbuRRjjDEarSftaxjpQgzBiRlzQhPQxmBfAzTeRGPHlhcFazwZqZZdprDkrEiLHtQWuDaPCp"));
    this->HuZYwRUrb(false);
    this->HaXixQzvQw();
    this->KwBRQbbvZTP(false);
    this->bYDGQn(string("OEhVOCZkRjiZNRxELhWuGxUYckKHxEQurnSqfFNuvrRRLwFOLizJFFstlnCBYucYB"), 243377.48459949283, -1899233364, 1011609891);
    this->YsvsXCFjf(true, -308920329);
    this->sWCaED(127896.00642529342, 1640687690, string("KDMsPYEzPwpEeKcoJJBWQfXFmgXVERGMAbQiTLqwtNyveDrWItTqeWpKeRsMNsZlcFqChUfMrucVo"), 624351801);
    this->sctSZ(string("FKjJELpFxkEcfsiutuPtsVadzfEuEsADVPfCQwamNnQnzvqDdJTCptTYWRQzrXlMqmPRQYaPUYeslBjPloFRIdkPVlbITPeXewsIwQQclsMCTYyCrLlZLOFWufPKUQsiitLqVMZJmaklzAbBjLASOYxIAauPTRaovWkeRDzCTXbCCaDUfRofeyyjbKIgnLoWNOhijzpaMzBn"), -675338.3282466804, string("hEAOTXlGLOBYEECKWyZskQtEXXzODGzdfURYDnHzfDXVDGZjDqMKTuVTwlNxWEPzYZrYEgwcchFlGeNFKaksvjqyOqcrNguxwKKpRyYdnMBEnXLsilhrxDAdRmTzUYPfnmJYbfUmTFxgBdetRFBvMXDFZIhxyWGKaDTXEtUaeexUKM"), string("jKuByRHNlLRWbuoQzWYPdJQAPssVnMDiMVxydISLwgp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lWSapbMvMzk
{
public:
    double urLECsp;
    double ZeSensA;

    lWSapbMvMzk();
protected:
    int JfydFR;

    bool aUyKK(bool QzXPLkcpEUwQ, int jsvIccZRFvXY, double CfvmFlCgJFVK, int udOSbllX);
    string uFdUEZF(double hiTWngMVA, bool TRAtz);
    string NJxCkI(int uhGusnNZFEwM, string pfSjKSxYDKzvkJT, double XNtRpuQUqFmnVaq, bool KbtlVQODeI, string mmQFr);
    int OpUwZCzjyh();
private:
    double nMtdlnJ;
    bool GkuvacsWvtUANnTc;
    int nIpkAekkK;
    double pvSRBmvJKueUed;
    string sbKnnsJ;

    double kecDkJHklFoostO(bool xWOLcf);
    int ovwLnaLBeT(int vIBmu, bool rbJxKOKQXilm, double horQwEbRSV);
};

bool lWSapbMvMzk::aUyKK(bool QzXPLkcpEUwQ, int jsvIccZRFvXY, double CfvmFlCgJFVK, int udOSbllX)
{
    int pKJkp = 1594734169;

    for (int mDQjwmIS = 1597245464; mDQjwmIS > 0; mDQjwmIS--) {
        udOSbllX *= pKJkp;
        udOSbllX *= udOSbllX;
        jsvIccZRFvXY *= jsvIccZRFvXY;
        jsvIccZRFvXY = pKJkp;
    }

    if (QzXPLkcpEUwQ != false) {
        for (int tAGavEyBmoujTv = 915152269; tAGavEyBmoujTv > 0; tAGavEyBmoujTv--) {
            udOSbllX /= jsvIccZRFvXY;
            pKJkp *= pKJkp;
        }
    }

    return QzXPLkcpEUwQ;
}

string lWSapbMvMzk::uFdUEZF(double hiTWngMVA, bool TRAtz)
{
    double CaTfrisP = -770482.4965983143;
    bool VkOiAVzLtZ = true;
    int hagpomEkr = -2074849742;
    bool pulPrbwaVJASnj = true;
    string LgThnMVa = string("RsWZFGfDarVxVZWkwgtlHrSwPNGTZkDZvbciyeVnRsNHEXmyvnphsFNOXtBitffFmXtCxYtLzfkEEHbIoCWzzzApCYjlimQKDcWJ");

    for (int bFtGPJj = 1758402357; bFtGPJj > 0; bFtGPJj--) {
        continue;
    }

    for (int jwsmiErr = 1087630270; jwsmiErr > 0; jwsmiErr--) {
        TRAtz = ! VkOiAVzLtZ;
    }

    for (int EewBbZHcOM = 1897022324; EewBbZHcOM > 0; EewBbZHcOM--) {
        pulPrbwaVJASnj = ! TRAtz;
        VkOiAVzLtZ = ! pulPrbwaVJASnj;
        TRAtz = TRAtz;
    }

    return LgThnMVa;
}

string lWSapbMvMzk::NJxCkI(int uhGusnNZFEwM, string pfSjKSxYDKzvkJT, double XNtRpuQUqFmnVaq, bool KbtlVQODeI, string mmQFr)
{
    string MmCgamZfRMHcJyU = string("pItfouzjcpuehjyBaCodflEzRQIEUVOzrOpObYmhrzDtyODzUIexFSNRrEYqNfuHlgDTQNqudDJFUrQDeNW");
    bool otbIdAF = true;
    double IMTyfVZPPYqX = -124473.80177000684;
    double ywqIfn = 1002538.8350095515;
    double clFeBl = -456097.8623133407;
    double zgxNfPbepwQYn = -583585.3491565736;

    for (int owtkOfzIySFm = 2055650464; owtkOfzIySFm > 0; owtkOfzIySFm--) {
        continue;
    }

    if (ywqIfn < -456097.8623133407) {
        for (int iohARqInPCcX = 327978264; iohARqInPCcX > 0; iohARqInPCcX--) {
            continue;
        }
    }

    for (int SJnpaqWnzFggb = 2538301; SJnpaqWnzFggb > 0; SJnpaqWnzFggb--) {
        XNtRpuQUqFmnVaq *= clFeBl;
        ywqIfn = zgxNfPbepwQYn;
    }

    if (ywqIfn != -764725.5639335162) {
        for (int vWnITDQDdr = 862984172; vWnITDQDdr > 0; vWnITDQDdr--) {
            IMTyfVZPPYqX += XNtRpuQUqFmnVaq;
        }
    }

    return MmCgamZfRMHcJyU;
}

int lWSapbMvMzk::OpUwZCzjyh()
{
    double hXVvtPuweuyNmw = 452957.82552866364;
    int czyWVxvIG = -98964473;
    double XMwDHNtUeXMnw = -560190.3571233023;
    string hoDAaIUqRYs = string("dDwPnncAMnIuqiiotXKSLyDvYtOYQlpBlPwQQKmWnZoKQwiXMwCJTvueGNcCbAJMcZCFinpVTyRmuoCHbeqnuUcKTJKDpOCTmiNhjNqucgwbKDljkwXTYsVhnlXNArbcmZPIbANvyujWHcYWoNdalMTvzeShAaOJEafNVNSDsLliOhmPSNgRTrUGuxTRkYKEWkeWYmxdCAeFCyNEhodLsqaBBMBXwlyctnOJxAnESvlbHLEUFECvZWy");

    if (XMwDHNtUeXMnw != 452957.82552866364) {
        for (int iYWPf = 616084614; iYWPf > 0; iYWPf--) {
            XMwDHNtUeXMnw *= XMwDHNtUeXMnw;
        }
    }

    return czyWVxvIG;
}

double lWSapbMvMzk::kecDkJHklFoostO(bool xWOLcf)
{
    bool FRMTL = true;
    bool VviAktePJMcR = false;
    bool bptiJY = true;

    if (bptiJY != true) {
        for (int sTYZUjWjwx = 4591190; sTYZUjWjwx > 0; sTYZUjWjwx--) {
            VviAktePJMcR = ! xWOLcf;
            xWOLcf = FRMTL;
        }
    }

    return 27232.83879232703;
}

int lWSapbMvMzk::ovwLnaLBeT(int vIBmu, bool rbJxKOKQXilm, double horQwEbRSV)
{
    double pYWryBBa = 68902.23245391024;
    bool kcQuJzyaIyPe = false;
    int XNpuKKjN = -264396850;

    for (int Hyxfwbrt = 1904200198; Hyxfwbrt > 0; Hyxfwbrt--) {
        continue;
    }

    return XNpuKKjN;
}

lWSapbMvMzk::lWSapbMvMzk()
{
    this->aUyKK(false, 22663074, -130962.22078568258, 962036727);
    this->uFdUEZF(-160187.0614579564, false);
    this->NJxCkI(-835449742, string("rUbiWUXgNeYfGLDsYQAgsmwbiGOHzPhgSqxFBVPitThHPFwAhCqljgqLRqZjdALQqnkUbnmpKWQaaGooxszgFVVtDgrvfAxhYaIQNSgpOQOwbyCylXGPnflLiDybMukvxYKgosNgddhCjZHpQCxrbfvXtsnSazYkWnrEjBSkaJUdaOqKRzvixeULdSXlIolJnNLbYrBZMhdFwXiISWIgXKJJHGeRFJFMWKAZQcUrak"), -764725.5639335162, false, string("tYIsuWLjMBxiyvDycSVXKpAOmPxJxxfkRYoCKjqREiuQLbRiMWowcmIBtRHXbCHqgDqeYtrPCqDQQkenJZfwtmUqU"));
    this->OpUwZCzjyh();
    this->kecDkJHklFoostO(true);
    this->ovwLnaLBeT(-1924327654, false, -213363.75165139406);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ISHrapJqmJLqgML
{
public:
    string dRdmIclrPWy;
    double YxNIzz;

    ISHrapJqmJLqgML();
    string iXhNCDKOvBBrb(string ZuoPP, double vxIQjdsUCq, bool JWGlxpSz, string avBhpaXYQv, double MaWcmhtExOaAtgE);
    int MggNK(string cxgWpWAamOgMIX, double AoOti, bool itXdLcopbcV);
    int FEzXicMZyhcAR(bool weJVSonGvIjjxJGY, string dBUVRFUlgHcHwD, string pPogcbGgPK, string KRWvkIaGkpPusQU);
    int Xkqbbc(bool gQuLNKy, string KJDZNXZPl, string KSSYtHHWIcaS, string aomtPGCweFO, string ecjQuRyysmsOKADe);
    int LRmrRtlKDO(string dRxkpufK);
    void XXUgzew(bool xDbYZICdOYvji, double PpvaDnRHZSI);
    double WrrWIzEfPHvyiJ();
protected:
    double ZIbScPHfk;
    string BdLUcK;
    string YKaATJRHfeRWj;
    bool wWOMsXmQ;
    bool lQqjsxlKcaPEDtjV;
    double tMeoynkINtxNS;

    double dzJsIlKlLrAKLS(int ZtakkmJbr, int bdSePhEhTrLFxktS);
private:
    int zkrhm;
    string FRrfaHQJ;
    int EtWYvW;

    bool MYnhOqtmxz();
    string yovVvHE(string ayrpjPHP, string rIXbi, double faNaHlT, double wQBeecAs, string zxPiuCUGRkdQDKMk);
    int YLsexFXq();
};

string ISHrapJqmJLqgML::iXhNCDKOvBBrb(string ZuoPP, double vxIQjdsUCq, bool JWGlxpSz, string avBhpaXYQv, double MaWcmhtExOaAtgE)
{
    string iHVIkUfeHi = string("iwNCArqMaTjmvPLVaiubuvAYloGpBaLnfQVeUyJchftCZmOBfvBQbGmwXazOTVl");
    double tnveJiKpUmkYT = -676631.5347830366;
    bool gBpnlD = false;
    string vUkmISBTMCFRH = string("jBIeZVHXIpuMvFHrkUOPzScaBHKWtoEqvaeIAcLlKpZCYzREoJvBNeYvfoOonmEnekOitjpEiSKrZsumTtzsUeeMyQTpOIYxLfrhSeGqaricrETirYRcGKYehNFNiipnaUjgeBtBDqijTpzfgkLR");

    return vUkmISBTMCFRH;
}

int ISHrapJqmJLqgML::MggNK(string cxgWpWAamOgMIX, double AoOti, bool itXdLcopbcV)
{
    double BjosrYgciCYi = -517726.2422290133;
    double LOgtoMiUfjpkc = -835698.1003004678;
    bool WofdeR = false;
    string VgfONbX = string("qXIuqiCNYoUwXHISJJfrRovodtjDdtyVZTXYDMwrdhSqGQFpNdYkCXWILTHYFchcgwcOUpFlgseXUpzQsxygOtqNHhloNjBkcQXgMoQuGFldWIbLEtrOrZVaEISYGeKGGdIxRFhLcgVZfMwOtOyFgrLgsuPMzzFsAzdjTTbWayFaXSsoXwhBxJPnVgTcsLqPpkpinMaUOZ");
    double BnJMuYnWwLcLVvKn = -852175.6296725408;
    double BhUGuM = -860101.1810015945;
    string nnarMmHlN = string("EBaBeTtNZRTsFePWiDwWiIpplrMCaYHqKRLEspYAnhDizCLvZttMtpzKExZXCXFOlLkXTOFEDJHPPUIlIFbmjJhilnBEuOSIOnqctbgFiAOctfOKEGwKaRBhZzJvPEkZauEqjIpAfdhwnSMooZppOXPxvdAyVVQLzvDsVcLlSmvhPQjfKuiaxlsUtBfLKHAYyLlUIodqBnvNmnAHWWhee");
    int hhScIXabtsiRinVe = 1680161977;
    int qstGOPnqSY = -512475570;

    for (int rgujRjJZ = 1656958664; rgujRjJZ > 0; rgujRjJZ--) {
        BjosrYgciCYi -= BhUGuM;
        BjosrYgciCYi /= AoOti;
    }

    for (int XyUPxUkRnlFcXm = 1991297423; XyUPxUkRnlFcXm > 0; XyUPxUkRnlFcXm--) {
        hhScIXabtsiRinVe *= hhScIXabtsiRinVe;
        BjosrYgciCYi += BnJMuYnWwLcLVvKn;
    }

    for (int ZiYiVwfqiaLKEcU = 1143230537; ZiYiVwfqiaLKEcU > 0; ZiYiVwfqiaLKEcU--) {
        itXdLcopbcV = itXdLcopbcV;
        AoOti *= AoOti;
        BjosrYgciCYi *= BnJMuYnWwLcLVvKn;
        LOgtoMiUfjpkc *= BnJMuYnWwLcLVvKn;
    }

    for (int QKHEhSRQgc = 1181914927; QKHEhSRQgc > 0; QKHEhSRQgc--) {
        VgfONbX = VgfONbX;
    }

    for (int SNMCv = 1409694817; SNMCv > 0; SNMCv--) {
        continue;
    }

    return qstGOPnqSY;
}

int ISHrapJqmJLqgML::FEzXicMZyhcAR(bool weJVSonGvIjjxJGY, string dBUVRFUlgHcHwD, string pPogcbGgPK, string KRWvkIaGkpPusQU)
{
    int JCRZvnzsod = 1000539440;
    int axZheltjgs = 1814312298;

    for (int AjNUTqiPMWn = 1509696220; AjNUTqiPMWn > 0; AjNUTqiPMWn--) {
        axZheltjgs -= JCRZvnzsod;
    }

    if (JCRZvnzsod < 1814312298) {
        for (int IOIsFGUhYAAJJlE = 1423105437; IOIsFGUhYAAJJlE > 0; IOIsFGUhYAAJJlE--) {
            dBUVRFUlgHcHwD += pPogcbGgPK;
        }
    }

    return axZheltjgs;
}

int ISHrapJqmJLqgML::Xkqbbc(bool gQuLNKy, string KJDZNXZPl, string KSSYtHHWIcaS, string aomtPGCweFO, string ecjQuRyysmsOKADe)
{
    bool JRZMrQyOXzViMAlV = true;
    bool rURHiG = false;

    for (int CexYIyWi = 1499065092; CexYIyWi > 0; CexYIyWi--) {
        ecjQuRyysmsOKADe += ecjQuRyysmsOKADe;
        aomtPGCweFO += KSSYtHHWIcaS;
        KSSYtHHWIcaS += KJDZNXZPl;
        rURHiG = JRZMrQyOXzViMAlV;
    }

    for (int bxuEIYG = 224669962; bxuEIYG > 0; bxuEIYG--) {
        JRZMrQyOXzViMAlV = ! rURHiG;
        ecjQuRyysmsOKADe += KSSYtHHWIcaS;
        ecjQuRyysmsOKADe += ecjQuRyysmsOKADe;
        KJDZNXZPl = ecjQuRyysmsOKADe;
        KSSYtHHWIcaS = KSSYtHHWIcaS;
    }

    if (rURHiG != true) {
        for (int XIvkgJqGpaTThVu = 376214869; XIvkgJqGpaTThVu > 0; XIvkgJqGpaTThVu--) {
            aomtPGCweFO = ecjQuRyysmsOKADe;
        }
    }

    if (ecjQuRyysmsOKADe != string("zUAiRLUxdNLDrqGqPFfgiNrMNjJQTUtFVrWrwOOUcmOjEIwBmYhMmspFesdRigjWqaPYraLDhlBbdstIChafVoGsqlJWVbHPdshYWVZltxVPsihRMVvydSDCfoFVIxSEKZXHECTlWdKgMoJAjfYwVjgyMNjbwlQIkXRDpSkHySewhxwQuQWTqPuEdrPiKzjrWrvZt")) {
        for (int ikBVhblYUCiEth = 786978466; ikBVhblYUCiEth > 0; ikBVhblYUCiEth--) {
            rURHiG = gQuLNKy;
            ecjQuRyysmsOKADe += ecjQuRyysmsOKADe;
        }
    }

    return -904595285;
}

int ISHrapJqmJLqgML::LRmrRtlKDO(string dRxkpufK)
{
    int ZNsuOQxZWwrxYUiL = 1091470950;
    string aMDezAn = string("KGHUNJRAiIujuOfKfwFAejSeiLHtPQarGrStsFrUZCXMQXicdyCsBipeXxHRQpaZXPTxeMzwTRXWAUwBZPWGPOwhIraLlUGHSNZlTpoZtRHpDInSHvRONhFxACIugbivpIQIJKAFWhkhtFQwXPevReqHaAkhPUMloLfCKQJpxHlrimHdNbhRZyJMfv");
    string RfQvJyA = string("lNNRDxGcjWbcqxSTzSBXuHMsaaOfrBUsOtzZLgwLvpsaIzUbZcJumqrFCGRtBIhfPZfaCfJaLGrbCqoOqJYMVdvdrXceHeUJPtJLBCKPpNwXDWsYzsHEaGBrhPDslEdbCHpgzLZgamHexhAkcUnJXGPLktwRqmqYbEEcMhsGQowHiMmUZ");
    int YbbcfVQphXzMFkuX = -1113346614;
    int fgEVeLrWf = 1877276938;

    for (int VYMLBJhtDbJyMKX = 1484413234; VYMLBJhtDbJyMKX > 0; VYMLBJhtDbJyMKX--) {
        fgEVeLrWf -= fgEVeLrWf;
        ZNsuOQxZWwrxYUiL /= ZNsuOQxZWwrxYUiL;
    }

    for (int VNkhvlBRUAFF = 601676555; VNkhvlBRUAFF > 0; VNkhvlBRUAFF--) {
        aMDezAn += RfQvJyA;
        ZNsuOQxZWwrxYUiL *= fgEVeLrWf;
        aMDezAn = RfQvJyA;
    }

    return fgEVeLrWf;
}

void ISHrapJqmJLqgML::XXUgzew(bool xDbYZICdOYvji, double PpvaDnRHZSI)
{
    string uFbHAQD = string("LBUUCLtRRxvAamqlkFPvdUIAVQqkOdwmpEFPgivSxLfPkFVeWTGjjqOfUBMJAOnQrhOQNlUdfPvuxbOLczMiJLjHDpLEqQMjwXJNYmwbBLkBiaTmyftMSLNJmMsCkSvuMrnnPEpEEgLpeXHpKbNUmDCkEANxJLodjpisMExTLptGBiBwpWeJRWwMApFNCxLUPxlZCHfrQtfJdymtvUSKjOHEnpGvGNPccQQzfeX");
    double bIFCmlpWVO = 63017.193578763334;
    double oEDRvI = -257397.36958905373;
    int eoPcc = 302006993;
    int ZNiuHag = 1624695127;
    int iTZWlFXJMR = 2096484148;
    double UBsMgXL = 1001578.0533674068;
    bool BxZihChEow = true;
}

double ISHrapJqmJLqgML::WrrWIzEfPHvyiJ()
{
    double PMrmQ = 448246.9743872393;
    string ttutAhGBtARsjn = string("IFNNupSBRInIaHFvlANSAqBDTcuawm");
    double eVzyw = -158855.08443127977;
    int KLJdcXyhSMBnjSqx = 1805097727;

    if (PMrmQ <= -158855.08443127977) {
        for (int mSXLKckE = 1611045395; mSXLKckE > 0; mSXLKckE--) {
            PMrmQ = eVzyw;
            KLJdcXyhSMBnjSqx += KLJdcXyhSMBnjSqx;
            PMrmQ -= PMrmQ;
            eVzyw = PMrmQ;
            PMrmQ = PMrmQ;
            PMrmQ += PMrmQ;
        }
    }

    for (int PpbDhNQ = 1835624005; PpbDhNQ > 0; PpbDhNQ--) {
        KLJdcXyhSMBnjSqx /= KLJdcXyhSMBnjSqx;
        KLJdcXyhSMBnjSqx *= KLJdcXyhSMBnjSqx;
    }

    return eVzyw;
}

double ISHrapJqmJLqgML::dzJsIlKlLrAKLS(int ZtakkmJbr, int bdSePhEhTrLFxktS)
{
    double nItKsskK = 42633.04042870889;
    double hdIXGNqrlvG = 96225.45765042857;
    int DQGEnYDsQbJAUit = -781630162;
    bool VZpBVG = false;
    bool UKJpqdQAO = false;
    string LbJikxG = string("GExTQJsqabubGWFZiRKOoJgHLjLwxqgrVUyMfnYlJdjRjlzHGaFaGTngaPjNssFSNsYlOMSDCyZmaSIOSlVHDGXFLWDCnTGcPNrWZSowpGzCOaEhQfpagNCHKVnhtetLZaqnhgVdgGSTZhAJjbyOZfKcBsbqqEFJsOICMozcXqABlpRyeelQJYRmyLwjCoDSOeBXvfgAve");
    double OgaswkKwjndMDYnF = 281718.2931600243;

    for (int Hucbjw = 1428602227; Hucbjw > 0; Hucbjw--) {
        continue;
    }

    for (int GyYYlNv = 611815764; GyYYlNv > 0; GyYYlNv--) {
        nItKsskK += nItKsskK;
        OgaswkKwjndMDYnF += hdIXGNqrlvG;
    }

    if (bdSePhEhTrLFxktS < -391367821) {
        for (int ASPUgqOJcqgJ = 1193192955; ASPUgqOJcqgJ > 0; ASPUgqOJcqgJ--) {
            bdSePhEhTrLFxktS *= ZtakkmJbr;
            VZpBVG = UKJpqdQAO;
            ZtakkmJbr = bdSePhEhTrLFxktS;
            OgaswkKwjndMDYnF *= nItKsskK;
        }
    }

    for (int UYANAC = 1293064533; UYANAC > 0; UYANAC--) {
        nItKsskK *= nItKsskK;
    }

    for (int uGqehVIXiQMxQYe = 1049917449; uGqehVIXiQMxQYe > 0; uGqehVIXiQMxQYe--) {
        UKJpqdQAO = ! UKJpqdQAO;
        VZpBVG = UKJpqdQAO;
    }

    return OgaswkKwjndMDYnF;
}

bool ISHrapJqmJLqgML::MYnhOqtmxz()
{
    string zxLRKyjOpGb = string("ViAsFVYMJycsoNmlhDjQuCvEOIxmRebrmOIeAZjFyPZTxSHKyHkbCuZqHoEuyZHbgMmIaPDALzgJQAkXljmhUOATGRvYZMIduMzm");
    string ItGGysOuThOZF = string("BURTNzcigWWygyNBkKuQiJrxMtuafl");
    string qjkuBBlUEhKarxPi = string("FhkuytaeBEWAocjCQMxfUamxYHsPIPupLUZfkEiBlLvAClQFjPOzSJCGLEwdaKaGyMVzwUwKptKmuqofWfXYcXdyKlJArwleRheuxAZimpruFTFnouFXsTrNbxNqGZhVN");
    double BaJmOi = 953555.9564984487;
    double LGufTPEDGuVgJ = -585411.6685408038;
    double TQELKMNwh = -577458.7841036163;

    if (ItGGysOuThOZF >= string("BURTNzcigWWygyNBkKuQiJrxMtuafl")) {
        for (int XmAczeMo = 1918717603; XmAczeMo > 0; XmAczeMo--) {
            BaJmOi /= BaJmOi;
            TQELKMNwh += BaJmOi;
            BaJmOi += TQELKMNwh;
            TQELKMNwh = BaJmOi;
            LGufTPEDGuVgJ /= TQELKMNwh;
        }
    }

    for (int JtrVIcxdimGi = 395341664; JtrVIcxdimGi > 0; JtrVIcxdimGi--) {
        zxLRKyjOpGb = ItGGysOuThOZF;
        LGufTPEDGuVgJ *= BaJmOi;
        ItGGysOuThOZF += ItGGysOuThOZF;
    }

    return false;
}

string ISHrapJqmJLqgML::yovVvHE(string ayrpjPHP, string rIXbi, double faNaHlT, double wQBeecAs, string zxPiuCUGRkdQDKMk)
{
    string IUnlEBbZGL = string("ZyGgodqhLfHVBqcwmyurLQmMwcSAtHfKfxXUbTbPhRsjPpirkyzgxxmEbBIJdzlOhMEWKBBqZTxZUxkkMHWxiXGOEHDKZUThneOopMShXVbLHIWkqMSBonYdodyJefbnVppPbUSMXZZYVLRfEppWcMclCgkGHZYfdgfXBmtEzleiSTsJSlqYiymASQwcoAXeljINIOlfA");
    bool TExiD = false;
    string BqkUOGULCfnai = string("sWIlKdjMMndPGBVmLOrmyRqHlyoRzkNmXSuh");
    int PpHmHBUTCWQs = 1447461069;
    string OxLeoa = string("XGyEShxspEomNinQjoujMRTNFR");
    double ZziRmmLKlPpT = -600798.9387651805;
    bool RBjQKhfVhQQw = false;
    int sgpYOOMrE = -1762707219;
    double vYzxLTOP = 550285.4293764731;
    string nqwAtElnCfE = string("aPSBzfwdBTlweQXVPRiQBqJVgwotXuXLSQWQjviqRgMvtPI");

    for (int FNNkEKWb = 1644820057; FNNkEKWb > 0; FNNkEKWb--) {
        rIXbi += ayrpjPHP;
        zxPiuCUGRkdQDKMk += zxPiuCUGRkdQDKMk;
    }

    if (vYzxLTOP <= -600798.9387651805) {
        for (int IXVsOjI = 744828013; IXVsOjI > 0; IXVsOjI--) {
            BqkUOGULCfnai += BqkUOGULCfnai;
            IUnlEBbZGL = BqkUOGULCfnai;
            wQBeecAs = ZziRmmLKlPpT;
            faNaHlT *= faNaHlT;
            ZziRmmLKlPpT -= ZziRmmLKlPpT;
            vYzxLTOP += vYzxLTOP;
        }
    }

    if (faNaHlT <= 550285.4293764731) {
        for (int NGfGzDyCPKR = 1573193858; NGfGzDyCPKR > 0; NGfGzDyCPKR--) {
            sgpYOOMrE = PpHmHBUTCWQs;
            wQBeecAs *= wQBeecAs;
        }
    }

    if (faNaHlT < 521786.9766356098) {
        for (int prBRiQpSoPwG = 549005048; prBRiQpSoPwG > 0; prBRiQpSoPwG--) {
            continue;
        }
    }

    return nqwAtElnCfE;
}

int ISHrapJqmJLqgML::YLsexFXq()
{
    bool HtqyniKi = true;
    double sNwBZySMAo = 3945.2106557092848;
    double ezItOwFVOlFJuyo = -191214.66029074762;
    string mBLVJNcjRp = string("LbYNYbgqxSfzrcaRNxklbRCbvdXVirefXRKPWBLCUjphpNXpKiHiMQiCjPtwxSEPJjpXndBfevGOPvVuqrILmtQwpxjVzhVZaNMHPqLDlALhydOMJUPiItyKDgifiNADPMNpylwxJkActUNDznkhPaudJv");
    bool yIrYkbKynJQgYwF = false;
    double FAAhhJRCEcDMlIU = -145606.66434051574;

    for (int RnxGQFD = 124195587; RnxGQFD > 0; RnxGQFD--) {
        sNwBZySMAo -= ezItOwFVOlFJuyo;
        yIrYkbKynJQgYwF = yIrYkbKynJQgYwF;
        FAAhhJRCEcDMlIU += FAAhhJRCEcDMlIU;
    }

    for (int PrYHmdljPMmPhRL = 1420769053; PrYHmdljPMmPhRL > 0; PrYHmdljPMmPhRL--) {
        sNwBZySMAo -= sNwBZySMAo;
        HtqyniKi = ! yIrYkbKynJQgYwF;
        FAAhhJRCEcDMlIU *= ezItOwFVOlFJuyo;
        FAAhhJRCEcDMlIU += FAAhhJRCEcDMlIU;
    }

    if (ezItOwFVOlFJuyo != 3945.2106557092848) {
        for (int MBUwhBh = 1714470340; MBUwhBh > 0; MBUwhBh--) {
            FAAhhJRCEcDMlIU *= sNwBZySMAo;
        }
    }

    for (int qLlufWZQ = 1436137184; qLlufWZQ > 0; qLlufWZQ--) {
        sNwBZySMAo += sNwBZySMAo;
        ezItOwFVOlFJuyo *= ezItOwFVOlFJuyo;
        mBLVJNcjRp += mBLVJNcjRp;
    }

    for (int uwsfQVDCAWgKcMR = 2001838454; uwsfQVDCAWgKcMR > 0; uwsfQVDCAWgKcMR--) {
        ezItOwFVOlFJuyo = ezItOwFVOlFJuyo;
        FAAhhJRCEcDMlIU -= FAAhhJRCEcDMlIU;
    }

    if (yIrYkbKynJQgYwF == false) {
        for (int RCScoqRSANubqSH = 1335573624; RCScoqRSANubqSH > 0; RCScoqRSANubqSH--) {
            ezItOwFVOlFJuyo += ezItOwFVOlFJuyo;
            ezItOwFVOlFJuyo -= ezItOwFVOlFJuyo;
        }
    }

    return -1544725001;
}

ISHrapJqmJLqgML::ISHrapJqmJLqgML()
{
    this->iXhNCDKOvBBrb(string("XElZhDQMGZMmUrUlTQCpuficxKL"), -30565.39654391465, true, string("lQAnvWxaXbWZIKWDJPScoJcDsVYOPXiIKinXOmsRSrMpzlddjByPehlcbhGmnBlXhaNvtdKHMLuqVESLNsxtffaRwqbCUeSMrYNGKAVEvtMsNmXSVYIqFtnTcXyLoBdaAAkAZVbwmmdQlBQAHGiLQygeiBvCCheQPgElIoJOBsjsOqeUMKIvJgjZoSeaNLlCKPLomcbKXpFiSjTgxOQbfEUmzOAn"), -777787.8597865422);
    this->MggNK(string("YloXSTfafaxofXWXCJDZKdqNpKhJGQbRVgBoBSvGLmzhAecciTBLbLwLHHDwoccoRWQAAiH"), 391167.87703818607, false);
    this->FEzXicMZyhcAR(false, string("JTRjcIrKFPxkFeTyiZrziUQisggXVVDRlcLlBjnQQnZlchJIOLkaZBnQKIypMmwvmeRCROhpNrydUCIssRBgdeJHLkcZJdPyzRahmFBzOgPNTswPTMTtyDoNFYROY"), string("CQkyMpkwONhllUbhGkPcClIiloPldeFhbBUIgPDAPAfPbelpeTmEjIeFeXRwbbkxBenVxAKlkhwpOoXwPERdntliUTZpmHvIiygonIZAXvhcqwlwfbOfQKvnxVPrxIFpPQkFKTRVvKzxUVfHIbxQppMizhEUdxckuMhgXqmWqmMjrTUgdlpufyZjGFjPJEAykvQQaBmmcElfJVcVwu"), string("FkixoWAvHFBBJyWjKYOSgVYLeQBbSIxdVkDqZOtWnBGivRCGnqyqZgpWPZQWLAAGaLzEHJPzFrsPhuTEeJFgreYvcuaOEpOuudLUNLsaRatrkvFbrLnOHlZJijQNQXcjpUAdbOFuAFeGzKtAiAJipBEADOwKxOqdfKaclPeFbGNgHyFMALCSEndVgPRMOLAfvMVnEVytbHbiqxpAPlVZMGuyAteUIpCtayxAtUZ"));
    this->Xkqbbc(true, string("jBpAWjsSQMIMbiLAFSiNHBNkmzNFTUajgktjKMniNCPUrACwzxTYcTUJjkhmcFelHqGYhqTINvgAPKiwIZThHFgclWylfBsIGGjaeVmlvpIajLaXSEFtqipCQ"), string("zUAiRLUxdNLDrqGqPFfgiNrMNjJQTUtFVrWrwOOUcmOjEIwBmYhMmspFesdRigjWqaPYraLDhlBbdstIChafVoGsqlJWVbHPdshYWVZltxVPsihRMVvydSDCfoFVIxSEKZXHECTlWdKgMoJAjfYwVjgyMNjbwlQIkXRDpSkHySewhxwQuQWTqPuEdrPiKzjrWrvZt"), string("kntJLmkUsUHCwA"), string("QzZFAktAOTrfWQdJHzNaonBnvwVqJmKDpUenbiweRXdtBF"));
    this->LRmrRtlKDO(string("MtBpeLVdqZQYMrKHyiPUtsXmMoiNEmvSfWmexjWUuZTISQbEUcqtsYxaDplHWexEYrMbsWFqQjzIDHoqxVjMNiyPMWbGJmxVAeSKvDwRygcbsuokrCMeAfDumfFYKQDUMxLHyRtPMWEeyfh"));
    this->XXUgzew(false, -872098.1103968209);
    this->WrrWIzEfPHvyiJ();
    this->dzJsIlKlLrAKLS(-750354264, -391367821);
    this->MYnhOqtmxz();
    this->yovVvHE(string("sOzTeYECwEqXkcpBvHpFcvhb"), string("jKKSzoqsRoZNwdehhOPKWsKahpOMIiDGcDFWgQDDfSPKngdgABjTvqhIOJGrRcTEmmbEMCHqPzZEIsfsXwchoMdizcEtUfsWmoeQEephXBkSxLAYFMtVmLUGmCsjzjAnHRncOgyRLgUrOVmzUEHtkFCJvvVfJsCFkYhoZoWsZIxHdcXYrbCToWOVJMpdYSOChfjYVAMmDtLLyDvtyuXrp"), 521786.9766356098, 133670.37150479708, string("pgDxxqZvAQKBEJmjYZmTXvdlbJoeRYRwDsNRpEqLzVSPApMUDUlzvxyJfLAfHxWUlcLmhqnIVaVUQiXrWYnUATYfegYcelEWkaypYGlNIXKAgnFIXkgEuswTbtlsBMxuImlfLZLPAKXBuPldtFxYjQepraLKkFJImWFGVnvnTVrqAgtvVFcpvMrJqyVsgqzdABWzrWpzErtOcgkAou"));
    this->YLsexFXq();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xFUfux
{
public:
    double xdRFaHGvqay;
    double ObnYuIPobcMx;
    double IZhoufLKKXLLzX;

    xFUfux();
    string kvPYigVOLfPAJ(int qPgMdmgUSUJqWtQa, double jLkGaeFTmQ, double ClQDMCORKLDA, bool tBqJTqKIOeDp);
    double lfVBRKYg(int wEDWzBqXSsyfNh);
    bool vwoBHwxwtYYHO(bool vNyvwMjecxmN, int GNtuzjLZRTVIfh);
    int NFXxP(int XdYDdBRxHuqEz);
    string fDNJWqdDTsU(bool iTcHeItylQF, int IyxLboWsMNEegq, int hnRVutQtqcYmnf, int wpxAXVWUKwitw);
    void DvKQyeUPngbVOsx(double rYxnezeHlJ, double WwENHQpsgdcgb, int RtfjmyDhcLwg, double WeioWWu, double dkGHarhNjoauv);
protected:
    string qMdyPJaWMo;
    int COljaPF;

    int BQIBT(string owSmxvxMWFXjjL, string pTYtmyokZ, int dQkNMO);
    void mlGvZcNPkcadCIe();
    int cqMTTCFOCUjoJ(string fbRXEXMdZcsneG, bool bYzzxMhkuYAJ);
    void lQprLVlPPNevJfho();
    double SwygcSJjQH(string himdBapnmd, double oIWGIRKrTEccFOV);
    int uTyYGiu(int QlNIBXXIlrmeJYFR);
private:
    int hKArksGfHUL;
    string HPjDFq;
    int dRCsKjG;

    double TwnlomWeM(bool hbwWdibZUbefWwh, bool yAwAKzrtLKgn, double lTduCIjSreesZGC, string CCokOFc, int VPmkKzrQRepxWw);
    int ZKBeIXyjXoSnD(bool CxLIIqeRqsHnO, bool TKXXK, string WNDbbFuUtwVHl, double kreTNgtxnhoG, string kIrRBrCIwMcUeevf);
    int ucyWgPKCzVimPVw(int VMPMoEWO, int XRWwJiKpPfUR, bool xAMjBla, double hKhaw, int ukfVNPdINarRy);
    int PyZoYjVy(string QpdqOmuZMLRhDPs, double knjPsRV, string BaRngnWklvRxC, bool AqgWVCM, bool IRcadTB);
};

string xFUfux::kvPYigVOLfPAJ(int qPgMdmgUSUJqWtQa, double jLkGaeFTmQ, double ClQDMCORKLDA, bool tBqJTqKIOeDp)
{
    string BmuqwiE = string("nCsMsCAjhTUfuCKjVmuBEBFlwFvgCfQEmQJcjXxlfkeHuTuYFNBlUKtSuoDqDCPyKKStMMsvSYVWUXwjTiyqntZjVSnGimMrjFAKzjRjOsRAcCgyOpSZysWVgxGfxfjejeZhQlTzZAWUtyxXAdpHbSLkjBhzCNqkSXCJEWqdsuyAQFfTqaAyxvzQfCVqSPYGALHnCo");
    string xMuinBcJLxtBd = string("ZoHUrpleMihQvymfYhAOpsteCjuDTVQAkkNbSlRuNoPODxveYDlpwaLQdFAniMQAsUyTkZZtwxiCOLJFkpbpPtRlBCaeSfODBYpAiGbcvoeOsMtqacrgpuFdkirrDNSwBqQjkIOcXTuiSsWpgRELDswUaKwvbFdHbczJeYmMzvuaLoG");
    string xXhwxIyRFD = string("gIRmugGfaWctgDiVMtEZNdqCXghuvAPFDlYWCCUBtBsPjXRZqRgrLrhVFURVhnZLOKXVFoeoeGuHaFWSotZUbNtPwuWVPJmTlfudnKAPSLvKKWiMVAuvBEtxuIjhNAotlm");

    for (int cUpOSZHSfQll = 1489580450; cUpOSZHSfQll > 0; cUpOSZHSfQll--) {
        BmuqwiE += xMuinBcJLxtBd;
        qPgMdmgUSUJqWtQa /= qPgMdmgUSUJqWtQa;
        xXhwxIyRFD += BmuqwiE;
    }

    if (BmuqwiE > string("ZoHUrpleMihQvymfYhAOpsteCjuDTVQAkkNbSlRuNoPODxveYDlpwaLQdFAniMQAsUyTkZZtwxiCOLJFkpbpPtRlBCaeSfODBYpAiGbcvoeOsMtqacrgpuFdkirrDNSwBqQjkIOcXTuiSsWpgRELDswUaKwvbFdHbczJeYmMzvuaLoG")) {
        for (int KFDqGhoylNUv = 1893264105; KFDqGhoylNUv > 0; KFDqGhoylNUv--) {
            BmuqwiE = xMuinBcJLxtBd;
            jLkGaeFTmQ /= jLkGaeFTmQ;
            xXhwxIyRFD = xMuinBcJLxtBd;
        }
    }

    return xXhwxIyRFD;
}

double xFUfux::lfVBRKYg(int wEDWzBqXSsyfNh)
{
    bool CLPEwVomRxq = true;
    double kMAZsRWlcsCLn = -483975.62711979396;
    double aVlIkSBohKpnH = -338207.9242465695;

    for (int zROWZQpWIw = 757126306; zROWZQpWIw > 0; zROWZQpWIw--) {
        kMAZsRWlcsCLn -= kMAZsRWlcsCLn;
        wEDWzBqXSsyfNh += wEDWzBqXSsyfNh;
        wEDWzBqXSsyfNh -= wEDWzBqXSsyfNh;
        aVlIkSBohKpnH += aVlIkSBohKpnH;
        kMAZsRWlcsCLn = kMAZsRWlcsCLn;
    }

    return aVlIkSBohKpnH;
}

bool xFUfux::vwoBHwxwtYYHO(bool vNyvwMjecxmN, int GNtuzjLZRTVIfh)
{
    int LJbYwegvr = 689108566;
    int UUlWVU = 706372336;
    string mnOqQLPPsplKkzq = string("RbcJKkPopUMaPvwMokNgbsKNAtyZxOcQkvrOhxseYaYXjwbiijDWKmLgpDJrnZNoJuRxhltNQXrgStxuRLWGySkzEUQiBfFsDxUxtzgTzY");

    for (int fGpjfsAmwpmRFn = 131809450; fGpjfsAmwpmRFn > 0; fGpjfsAmwpmRFn--) {
        continue;
    }

    if (vNyvwMjecxmN == true) {
        for (int tpDeOiC = 417841896; tpDeOiC > 0; tpDeOiC--) {
            continue;
        }
    }

    if (GNtuzjLZRTVIfh <= 706372336) {
        for (int eMDitTsnkYqqi = 1186398725; eMDitTsnkYqqi > 0; eMDitTsnkYqqi--) {
            LJbYwegvr -= LJbYwegvr;
        }
    }

    if (LJbYwegvr >= 706372336) {
        for (int XkBfGOk = 1053302442; XkBfGOk > 0; XkBfGOk--) {
            UUlWVU -= UUlWVU;
            UUlWVU = LJbYwegvr;
            GNtuzjLZRTVIfh *= UUlWVU;
            vNyvwMjecxmN = vNyvwMjecxmN;
            GNtuzjLZRTVIfh -= UUlWVU;
        }
    }

    return vNyvwMjecxmN;
}

int xFUfux::NFXxP(int XdYDdBRxHuqEz)
{
    int vsEIgazDaALJXj = -981530046;
    bool vdWjKfjTUYNcdws = true;
    double gtNshZhGpWwO = 962879.7629531268;
    int xGASbeCs = 933754140;
    int RreehC = -727344149;

    return RreehC;
}

string xFUfux::fDNJWqdDTsU(bool iTcHeItylQF, int IyxLboWsMNEegq, int hnRVutQtqcYmnf, int wpxAXVWUKwitw)
{
    int BfxJrSh = 1658472214;

    if (BfxJrSh >= -484177918) {
        for (int xkGXJhX = 195758916; xkGXJhX > 0; xkGXJhX--) {
            IyxLboWsMNEegq += IyxLboWsMNEegq;
            wpxAXVWUKwitw = BfxJrSh;
        }
    }

    for (int mKQWHyJz = 621280843; mKQWHyJz > 0; mKQWHyJz--) {
        BfxJrSh *= hnRVutQtqcYmnf;
    }

    if (IyxLboWsMNEegq != -484177918) {
        for (int NsbWujCuAsi = 1812469767; NsbWujCuAsi > 0; NsbWujCuAsi--) {
            wpxAXVWUKwitw = IyxLboWsMNEegq;
        }
    }

    if (wpxAXVWUKwitw == 1658472214) {
        for (int VpdwiGC = 1240857208; VpdwiGC > 0; VpdwiGC--) {
            hnRVutQtqcYmnf += wpxAXVWUKwitw;
            hnRVutQtqcYmnf -= BfxJrSh;
            BfxJrSh = BfxJrSh;
            hnRVutQtqcYmnf += BfxJrSh;
            IyxLboWsMNEegq = wpxAXVWUKwitw;
        }
    }

    return string("BUiVtpvXDkIibnfFXANLREeguhkyaDOQtplboZADYaDVnDqjRXBFZjAPdcagYWFPDwEXgabOpjpTsCQYcUGBKwCNLXQZXzPtFTLDeHgQDXfuNccPjoHlFMLrJpMPnpwWZATzgPbDRZYaQStjgkUYVepCRlXSanZICVnMzvaiUZvqVeSfNrpRIzvC");
}

void xFUfux::DvKQyeUPngbVOsx(double rYxnezeHlJ, double WwENHQpsgdcgb, int RtfjmyDhcLwg, double WeioWWu, double dkGHarhNjoauv)
{
    bool TmrzhhgeIEZtG = true;
    int xhcTWRF = 1062692186;
    double ptfgATdK = 319360.9213879807;
    string kGYXnv = string("NMeVofmlGNNpLQoRmyrZqEtBzXBlIdQMxkiadIAPymonGINnxTGwBJcEbQOmIwpeJWbMpgHGgQgYAYEvakdFduXxqfxgqgiJmAPouMZbIzDWSzBVmPAjzzUZNsiKETyGVVcvPmNzsChDuHwtPqIVArK");
    int TYwAr = 219709338;
    string wAvvQbsKWnkmk = string("NFwKBeO");
    bool FfzwsLMvnX = false;
    bool MkbJpxVt = false;
    bool mHWLUUjWFeL = true;

    for (int AOvatOPlgkzUW = 1262034508; AOvatOPlgkzUW > 0; AOvatOPlgkzUW--) {
        WwENHQpsgdcgb = WeioWWu;
        rYxnezeHlJ -= rYxnezeHlJ;
    }

    if (rYxnezeHlJ == 319360.9213879807) {
        for (int ImrMGfFvglIdp = 1660839418; ImrMGfFvglIdp > 0; ImrMGfFvglIdp--) {
            continue;
        }
    }

    if (WwENHQpsgdcgb == 785541.4586701691) {
        for (int BStbtKdLcudmgYh = 624955084; BStbtKdLcudmgYh > 0; BStbtKdLcudmgYh--) {
            continue;
        }
    }

    if (TmrzhhgeIEZtG != false) {
        for (int BXjhW = 1961018152; BXjhW > 0; BXjhW--) {
            rYxnezeHlJ = WeioWWu;
            ptfgATdK += rYxnezeHlJ;
        }
    }
}

int xFUfux::BQIBT(string owSmxvxMWFXjjL, string pTYtmyokZ, int dQkNMO)
{
    double QPRyoPhii = 123346.41028069991;

    if (dQkNMO == 1966328937) {
        for (int DhLwqzBueCwGOs = 1473754114; DhLwqzBueCwGOs > 0; DhLwqzBueCwGOs--) {
            QPRyoPhii *= QPRyoPhii;
            pTYtmyokZ += pTYtmyokZ;
            owSmxvxMWFXjjL += pTYtmyokZ;
        }
    }

    for (int TIIKRQ = 930107079; TIIKRQ > 0; TIIKRQ--) {
        owSmxvxMWFXjjL = owSmxvxMWFXjjL;
        dQkNMO -= dQkNMO;
        pTYtmyokZ = pTYtmyokZ;
    }

    if (pTYtmyokZ != string("SiPZvziDLbEeDDVhFBjMkgAKtfjWWKLBXl")) {
        for (int Vmoiv = 1450167483; Vmoiv > 0; Vmoiv--) {
            owSmxvxMWFXjjL += pTYtmyokZ;
            pTYtmyokZ += pTYtmyokZ;
        }
    }

    if (pTYtmyokZ != string("PHTZERhhWtNoRSBllfOwLRKqJYDXavhCsEmONZQztjLptrPBuEjrQLvaJPTASEnGdeXpbgWfOiLxofSatYmnlbJSscHNIYiIdXtMIpfWYswLdMPHxZtgQMbvyerxWGGIdrJUecEULWVKXxSjPgyjUWPZCtpRJHAMixFBCuKoLoZSauZtedxVLxraIwtrXSaPAQtswIiXYwDZMUJzac")) {
        for (int GcfxqreUUQKQrJ = 1716580004; GcfxqreUUQKQrJ > 0; GcfxqreUUQKQrJ--) {
            owSmxvxMWFXjjL = owSmxvxMWFXjjL;
            owSmxvxMWFXjjL = pTYtmyokZ;
        }
    }

    return dQkNMO;
}

void xFUfux::mlGvZcNPkcadCIe()
{
    bool OYzGD = false;
    bool GQnVUKMUoh = true;
    double jdiYRhXBQLiUA = 770577.5437125652;
    double kJFusLVgWsUTpoI = -568435.8734507343;
    bool bZZtZkbQzTdUwY = false;
    bool wQpzhcDvlsHgka = true;

    for (int leXQEPXUE = 1983022642; leXQEPXUE > 0; leXQEPXUE--) {
        GQnVUKMUoh = GQnVUKMUoh;
        bZZtZkbQzTdUwY = ! GQnVUKMUoh;
        GQnVUKMUoh = ! GQnVUKMUoh;
    }

    for (int CjIAkBfxnbfCix = 1850496195; CjIAkBfxnbfCix > 0; CjIAkBfxnbfCix--) {
        GQnVUKMUoh = ! wQpzhcDvlsHgka;
    }

    if (GQnVUKMUoh != false) {
        for (int ErKZglHazfNC = 1182877922; ErKZglHazfNC > 0; ErKZglHazfNC--) {
            kJFusLVgWsUTpoI /= jdiYRhXBQLiUA;
            wQpzhcDvlsHgka = ! wQpzhcDvlsHgka;
            GQnVUKMUoh = GQnVUKMUoh;
        }
    }

    if (bZZtZkbQzTdUwY == true) {
        for (int uhypgb = 1270045875; uhypgb > 0; uhypgb--) {
            bZZtZkbQzTdUwY = OYzGD;
            bZZtZkbQzTdUwY = OYzGD;
            bZZtZkbQzTdUwY = GQnVUKMUoh;
            wQpzhcDvlsHgka = wQpzhcDvlsHgka;
            wQpzhcDvlsHgka = ! wQpzhcDvlsHgka;
        }
    }

    for (int sNfDOusiZy = 331067120; sNfDOusiZy > 0; sNfDOusiZy--) {
        bZZtZkbQzTdUwY = ! bZZtZkbQzTdUwY;
        jdiYRhXBQLiUA *= jdiYRhXBQLiUA;
        jdiYRhXBQLiUA += jdiYRhXBQLiUA;
        wQpzhcDvlsHgka = ! GQnVUKMUoh;
        OYzGD = bZZtZkbQzTdUwY;
    }
}

int xFUfux::cqMTTCFOCUjoJ(string fbRXEXMdZcsneG, bool bYzzxMhkuYAJ)
{
    bool aEqXIgRrfAze = false;
    bool qXriApvBzZiEHF = true;
    int zbSZGcfMhBxy = -1298112750;
    string ICvwIZNMMzmpw = string("HV");

    for (int NbyDI = 1923725390; NbyDI > 0; NbyDI--) {
        aEqXIgRrfAze = ! bYzzxMhkuYAJ;
    }

    return zbSZGcfMhBxy;
}

void xFUfux::lQprLVlPPNevJfho()
{
    bool WFMeZqtX = false;
    bool YrVCVjVjdAN = true;
    double NgbcAunhDSv = 73745.01695288505;

    if (WFMeZqtX != false) {
        for (int USSKSqoYEvfUHyR = 157840160; USSKSqoYEvfUHyR > 0; USSKSqoYEvfUHyR--) {
            YrVCVjVjdAN = ! YrVCVjVjdAN;
            WFMeZqtX = YrVCVjVjdAN;
            YrVCVjVjdAN = ! WFMeZqtX;
            WFMeZqtX = ! WFMeZqtX;
        }
    }

    if (YrVCVjVjdAN != false) {
        for (int KZgnlySCJIgltv = 51808717; KZgnlySCJIgltv > 0; KZgnlySCJIgltv--) {
            YrVCVjVjdAN = ! YrVCVjVjdAN;
        }
    }

    if (YrVCVjVjdAN == true) {
        for (int fbtxMO = 1902635886; fbtxMO > 0; fbtxMO--) {
            YrVCVjVjdAN = YrVCVjVjdAN;
        }
    }

    if (YrVCVjVjdAN == false) {
        for (int WZdIGQDDFkkZEVn = 1528075332; WZdIGQDDFkkZEVn > 0; WZdIGQDDFkkZEVn--) {
            WFMeZqtX = ! YrVCVjVjdAN;
            NgbcAunhDSv -= NgbcAunhDSv;
            WFMeZqtX = ! YrVCVjVjdAN;
            WFMeZqtX = ! WFMeZqtX;
            WFMeZqtX = ! WFMeZqtX;
        }
    }

    for (int gvFvsszJCOpT = 2101822071; gvFvsszJCOpT > 0; gvFvsszJCOpT--) {
        WFMeZqtX = ! WFMeZqtX;
        WFMeZqtX = ! YrVCVjVjdAN;
        YrVCVjVjdAN = YrVCVjVjdAN;
        WFMeZqtX = ! WFMeZqtX;
        NgbcAunhDSv -= NgbcAunhDSv;
        NgbcAunhDSv /= NgbcAunhDSv;
    }
}

double xFUfux::SwygcSJjQH(string himdBapnmd, double oIWGIRKrTEccFOV)
{
    int qxZfnwkdWoHf = 287698458;
    string pzWYZz = string("MHMlbnSufbifhOCLLvOvCuhkvSDQarPsRAMQGuDiqZVKROKIiXYdvRRCAVrKhcRXiZypMhxeRJHACRtnhhsZalMgewUiMvpvPfhxugqklRIJPzvAYMxYKgwaxjLQMmmlOTKqsRmqkMWmFBhKwrFBFUZKFgKpwYrwkippLYceAnydgNneTVyxCnlJOMnquhegDiZZugIOeEqThrNxWlYHyaGWVsYWncgjIPqsAlstmGieuCsLkbeWjWa");
    double CIghsTSlh = 143003.8571781714;
    double XgGJcLZBzjyZPMWU = -870690.0980834665;
    string FnwmLJGxqnGyDAY = string("HQlSKOqTTvSmwMSczgbTrxnjVhXPnRumLjRKGUDvJjJWjLoOMQxdziqwCjFPNZYhyKCeBLcyciknNspdACzulGrYudhwhnkCsWZTcSVuHwdIqArmriHAPQZGgBa");
    double zZTJqylb = -946716.9564871119;
    double xORlzkALxh = 759664.2122895241;
    bool ssPHSkpnAOyyMG = true;

    for (int KpzfQDveUaq = 2080610735; KpzfQDveUaq > 0; KpzfQDveUaq--) {
        xORlzkALxh /= xORlzkALxh;
        xORlzkALxh += CIghsTSlh;
    }

    return xORlzkALxh;
}

int xFUfux::uTyYGiu(int QlNIBXXIlrmeJYFR)
{
    double AmEIRayAlPyFZk = -532921.6150714861;
    double YYJqh = -895749.3402572309;
    double tqHNZubhMooYqQAo = -150113.0120497901;
    int flgIjvW = 578230314;
    string ayUxwf = string("caEvYHpxCzRqJmtgplxrYedeSBwulIIZcAAdIRUceTsbCJXkVrhaymToxJYrXAzNaFiasXMfVpYGwXGixHLYoLYZRqDssfGBpdHdXJjLiu");
    bool GagnpmIwKG = true;

    if (GagnpmIwKG != true) {
        for (int nebaD = 152932078; nebaD > 0; nebaD--) {
            continue;
        }
    }

    if (YYJqh <= -150113.0120497901) {
        for (int GlTQrbNSua = 1245059434; GlTQrbNSua > 0; GlTQrbNSua--) {
            YYJqh /= YYJqh;
        }
    }

    for (int BcqamQUAzLRL = 801910153; BcqamQUAzLRL > 0; BcqamQUAzLRL--) {
        AmEIRayAlPyFZk = YYJqh;
        AmEIRayAlPyFZk = tqHNZubhMooYqQAo;
        ayUxwf += ayUxwf;
    }

    for (int tjQzMzqfm = 1258502651; tjQzMzqfm > 0; tjQzMzqfm--) {
        tqHNZubhMooYqQAo = AmEIRayAlPyFZk;
        YYJqh *= YYJqh;
    }

    return flgIjvW;
}

double xFUfux::TwnlomWeM(bool hbwWdibZUbefWwh, bool yAwAKzrtLKgn, double lTduCIjSreesZGC, string CCokOFc, int VPmkKzrQRepxWw)
{
    bool omOTbiVyrzUM = true;
    int xpOtCbLmlpZjtAL = -2135107963;
    string PVVsLaLjQb = string("qdTlPRSjubdZuBxEBOXobqRPeJAcCHsIxlPxDLGmDzSisaBKxdmTGJbqpkPeyWgzducYPgxeseHcyaEVYkPbYvNxBoHNWFSaKYLfZBptaqWopFxyIJGuxHkbkyTyvXoCLWAlxcQKY");
    int bMxUiEytDHQlXKyJ = -1310068123;
    string OjQkSOcAL = string("XzcXmhZQqaYJpeKKbsPFRyHlqiEGCWZvIjGeFUrOGsBNtpofHGGrdITpBnBSIKoasDDaCeKSSkheqGRCFEyjabfTpjcszWmvuwUcQEyIlZIXNhQbUpBllHBoGByiVCiygZGhZZctFdgMYrYPfmcbLNEPhgchJcfBuNDCKdnZKeKgDwkWESKjXvIQlUHCPQmXlBVwCRhkhvZfDMEGhUmbaSYcCeUdjOcNIMetRRTJPN");
    double fVDyzgr = -656300.8453234341;
    string VoAPUln = string("FqoKCvMGMZMcTqwDOCfkypGLdpsNPkKasFGFInyWOEeMgScqOtKveHsAuCSlGqeCRJeMJibipYsDkQjZjYmJebMfGeyJIrYtUXirKHRIsrCOzOWZWAUirfinxlaGrmylgYOhkMuSrFicUaGXPJmoExSfyXjidiRaLkjvdWTdmumsoqbTZrrrLlpDUqFz");
    double jRRTjpDXtcuvrAHB = -684586.1125560212;
    int PbQPADsBc = 448726940;
    int zlLJLrnVtff = 1721803159;

    if (VoAPUln == string("FqoKCvMGMZMcTqwDOCfkypGLdpsNPkKasFGFInyWOEeMgScqOtKveHsAuCSlGqeCRJeMJibipYsDkQjZjYmJebMfGeyJIrYtUXirKHRIsrCOzOWZWAUirfinxlaGrmylgYOhkMuSrFicUaGXPJmoExSfyXjidiRaLkjvdWTdmumsoqbTZrrrLlpDUqFz")) {
        for (int PGpqe = 299768666; PGpqe > 0; PGpqe--) {
            jRRTjpDXtcuvrAHB *= lTduCIjSreesZGC;
            PVVsLaLjQb = PVVsLaLjQb;
        }
    }

    for (int OxCziWEvmqUr = 399995746; OxCziWEvmqUr > 0; OxCziWEvmqUr--) {
        continue;
    }

    return jRRTjpDXtcuvrAHB;
}

int xFUfux::ZKBeIXyjXoSnD(bool CxLIIqeRqsHnO, bool TKXXK, string WNDbbFuUtwVHl, double kreTNgtxnhoG, string kIrRBrCIwMcUeevf)
{
    bool uNuHS = true;
    bool CUWQFbQYFumsuWC = false;
    int tyEcbPGnQbpuiod = 1456387042;
    int kjKjrbgMPVS = 1153732549;
    string TXpOrNLLWWP = string("Dew");
    int TYgtGadC = -1073088716;
    double gGegJTkGsc = 650922.8758846883;

    if (CxLIIqeRqsHnO != false) {
        for (int JQiswQDS = 777850223; JQiswQDS > 0; JQiswQDS--) {
            continue;
        }
    }

    for (int fJOFeIEMr = 1362723974; fJOFeIEMr > 0; fJOFeIEMr--) {
        WNDbbFuUtwVHl += WNDbbFuUtwVHl;
        TXpOrNLLWWP = TXpOrNLLWWP;
    }

    if (WNDbbFuUtwVHl > string("pOHNcSXyefSSYFbWxErxxTSqzRQukLsvcQbUbfIxoEtJIqzbLHIdusnIxyIXZCBlEFncMSxquWLjJltyYgFziOrPzYchTScNkTgIRvYGTDYARwkfvMCZOoirfUFCMLUPLFYeWkUoaejQzjyuHcSBkXWYg")) {
        for (int yiblmVAFSYQ = 1745085927; yiblmVAFSYQ > 0; yiblmVAFSYQ--) {
            kIrRBrCIwMcUeevf += kIrRBrCIwMcUeevf;
        }
    }

    for (int ntRPe = 400608820; ntRPe > 0; ntRPe--) {
        continue;
    }

    return TYgtGadC;
}

int xFUfux::ucyWgPKCzVimPVw(int VMPMoEWO, int XRWwJiKpPfUR, bool xAMjBla, double hKhaw, int ukfVNPdINarRy)
{
    bool HeGFKkeCihYvlb = true;
    string tfthyyvcZWV = string("kXOGBFCNBuTYFiRjDisUaQZOVrymyESSRjTnsiGYxsYhclSeZFbFOQFVKnMFOjGaZeBkwfVLMTEeQLvAbuzBaiZnBMenjuhOnQLnrJlkRXTnBbuySnxDhCJLTxowqBtaGFERmnTYBdPzSfWiiiLamjMOAjXegqFwTXvViZNYTAYEsBfTLnZRytYsFJgMmLYJwftTDLdQSfdpYueXSjOIg");
    bool SFEwxVsYQTxzdi = false;
    int RxOlOGuOR = 1378273442;
    int ogwyjQMtvU = 1588776481;
    double BfYuTluRRAFDR = -349220.21046477975;
    bool LsSGGqjG = true;
    int eMCptvwtCRZ = 809489843;
    int iAGGgCYPeuZJn = -1885837054;
    string MVisk = string("HOSWiqpTLsTqyxtyRecuRRNWDHpjwtjxwjbMcxQvyeRFMTwWTMKaaIHOmMUqHwhpqqotNnzvlRbrFbMgEHSrwUgcmgtAaLGkjowfsCORmQhcbBBuOmEpRwLbqv");

    for (int kRyDgDXcdaGhUH = 1849199147; kRyDgDXcdaGhUH > 0; kRyDgDXcdaGhUH--) {
        ogwyjQMtvU += eMCptvwtCRZ;
        eMCptvwtCRZ /= VMPMoEWO;
        eMCptvwtCRZ *= ukfVNPdINarRy;
        xAMjBla = ! LsSGGqjG;
        ogwyjQMtvU -= iAGGgCYPeuZJn;
    }

    for (int ISNEMhcOFQ = 479240798; ISNEMhcOFQ > 0; ISNEMhcOFQ--) {
        VMPMoEWO += ogwyjQMtvU;
    }

    for (int CcjEOSjsNDGmCYum = 77915234; CcjEOSjsNDGmCYum > 0; CcjEOSjsNDGmCYum--) {
        eMCptvwtCRZ /= XRWwJiKpPfUR;
        eMCptvwtCRZ += VMPMoEWO;
        RxOlOGuOR += VMPMoEWO;
        RxOlOGuOR -= XRWwJiKpPfUR;
    }

    for (int zmrdDiLtJq = 1459499909; zmrdDiLtJq > 0; zmrdDiLtJq--) {
        ukfVNPdINarRy -= ukfVNPdINarRy;
        LsSGGqjG = ! LsSGGqjG;
        BfYuTluRRAFDR /= BfYuTluRRAFDR;
    }

    return iAGGgCYPeuZJn;
}

int xFUfux::PyZoYjVy(string QpdqOmuZMLRhDPs, double knjPsRV, string BaRngnWklvRxC, bool AqgWVCM, bool IRcadTB)
{
    int VdsCPXqYhfmHige = -1797937571;
    double KbCHsWQHgC = 482597.0793437094;
    double ANsgSUgtdhqWTQqR = -597542.3316495512;
    string sBsha = string("CthRfQqGsStWhUCLtIJGsksayWsutGOnCXPOgqRAwIU");
    int hEIBq = -1332637817;
    double jwCsuieyG = -1011767.5947257384;

    for (int RCqFvB = 996630830; RCqFvB > 0; RCqFvB--) {
        continue;
    }

    return hEIBq;
}

xFUfux::xFUfux()
{
    this->kvPYigVOLfPAJ(1845619686, -590604.118156571, -412524.43482319644, true);
    this->lfVBRKYg(-2109410350);
    this->vwoBHwxwtYYHO(true, 1961320901);
    this->NFXxP(923531774);
    this->fDNJWqdDTsU(true, -484177918, 1765035586, 388352224);
    this->DvKQyeUPngbVOsx(292817.0839807663, -986352.1252375818, -1104956081, 961804.8181173614, 785541.4586701691);
    this->BQIBT(string("SiPZvziDLbEeDDVhFBjMkgAKtfjWWKLBXl"), string("PHTZERhhWtNoRSBllfOwLRKqJYDXavhCsEmONZQztjLptrPBuEjrQLvaJPTASEnGdeXpbgWfOiLxofSatYmnlbJSscHNIYiIdXtMIpfWYswLdMPHxZtgQMbvyerxWGGIdrJUecEULWVKXxSjPgyjUWPZCtpRJHAMixFBCuKoLoZSauZtedxVLxraIwtrXSaPAQtswIiXYwDZMUJzac"), 1966328937);
    this->mlGvZcNPkcadCIe();
    this->cqMTTCFOCUjoJ(string("IcBTpZpODKtxdtrnTubmeaeMIDirvYdxorarOvQbafyaPQxupvKFnqgibBaCNmzsXFfFDagHJxmHsIaaQgXzjKOTnURSvhfnuOYkGLnIbYFGULAENWyrSTqqoQDiopJkvOiXBKxJgCaphmfPXQVBLCXLsaikqLwPxDcInYmVX"), false);
    this->lQprLVlPPNevJfho();
    this->SwygcSJjQH(string("DqfOrxeyMSzFNmehBRLmLBrosdYZnib"), -865199.3917060854);
    this->uTyYGiu(1146768930);
    this->TwnlomWeM(true, true, 448320.8037325384, string("gUlnsoDLKVBAWYUAsjpxBDbAohGoTVHaLjDhlgKGerzEoNFqjXoiSJiVHlYUEORaIMePDLfkJMkCzPMDIbVXbNFOVZBEQcKqwsSuag"), 142143052);
    this->ZKBeIXyjXoSnD(false, false, string("pOHNcSXyefSSYFbWxErxxTSqzRQukLsvcQbUbfIxoEtJIqzbLHIdusnIxyIXZCBlEFncMSxquWLjJltyYgFziOrPzYchTScNkTgIRvYGTDYARwkfvMCZOoirfUFCMLUPLFYeWkUoaejQzjyuHcSBkXWYg"), -903992.3885972088, string("BmyiSusOGsYGKuygeldVIVedQRFGcjQaBKFSYZTtOxbfBnycVlhgqsgeNGslzGMQSEsbIiedFlKnRGJdmYIAchaDDJ"));
    this->ucyWgPKCzVimPVw(-1321401043, -36482678, true, -579534.3856306141, 1220580732);
    this->PyZoYjVy(string("IpNfdPDufctWhGJSxgghkZluuPykISThSQlfpTKKOJoqtaOpBFHMzYtWQpBsuOFlpBSxiggqPPhFDXdjDpC"), 384368.71695767925, string("EihFKTTqNirUcNAjBROYEGhHVOarQOPwCMWlqpooGweUKKAkPYktcTHgIFGkcetkrhPdDNBIYrpGZZjgHQOHTRombyGvtEHVlMkmqWuBdRYzMpusArvnEVPwcZbaDqOVQVYQhemtJYihPGUBhBJVVNoPJhuICHXVqWIEyPtm"), true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RnsfJOdxS
{
public:
    double uBKbYbYSdRtKm;
    int XpSNytjzprU;

    RnsfJOdxS();
    int JBMzpQa(string vMxfPmzOUaWiQ, string IQQmnDrGDGy, int HvwGCjMKpeYrPN, int FsnlhHaMR, int XDzdpZ);
    double SaKvOx(int meweGu, int LmowWXMWC, int mxrrjkHxqditAD, double CSgJgCM);
    string mLKkFjRCNUcn(bool uieQjW);
    void eUoKJyuSBEhOih(bool pahmM, string xImpUWmc, string pGqEcrWtbVK);
    void WTLBUJAQf(int evLfxgTmD, bool KyNhHFbyjpDQ);
protected:
    double mtGuISEpvV;
    bool KsswAvn;
    string rRaPOMW;
    int EPDeCubnrWifzqQe;
    string CaLgUvkAOVewXiN;

    bool QWPkIQ(bool MKnNUViECMMMZIf, string LnTxuwkkrsDX, string luUxuCotJ);
    double nSECffCq(bool MSRuREJHzobHGb, bool FpBoHRNR, bool BLIKtvv, double JynqF, int DswnuOSsZ);
    bool nyquwzeIFY(double JOuGntjUKylbVM, bool eENbZtMKzNXDs);
    double MovahMidT();
private:
    int zIyDpziRqhSfG;
    int KsFADZgKHvIsIljA;
    string bGgqgJTuWhJR;
    double ixlNQSXNBCrEIA;
    double odanfN;

    bool KInPetnfbyed(string yhgUxbThDffLx, double PzLEnThoJBgPpp);
    int wQAfySVaHpBeNVMw();
    double elfUMnjxQ(double pyuqgCFNeuKzmfQ, bool LFxdesd, bool cBdIvqvGfXRvMW, string xLlHl);
    bool AqLbQ(string kdRdnJRSAOZTJcSz, double pqKmvx, double QyxLgyFTgvcdlcqI, bool NxwYmcb);
    bool mZcjgwRfsUcTzME(bool DTQHIFaGBOwWKe);
    string VEVAiDdCpHNltQzp(int cdhPzotX);
    void mVJTyuOJrfjE(bool JBtDu, double xFAtxaQYpTwbC, int QDfHiBgQ, double JDPau, bool JHAEQ);
    bool JsOsC(double NGYddgFCBmLbT, string GzxSRKgoeEHBPS);
};

int RnsfJOdxS::JBMzpQa(string vMxfPmzOUaWiQ, string IQQmnDrGDGy, int HvwGCjMKpeYrPN, int FsnlhHaMR, int XDzdpZ)
{
    string iPCiQOfISBhlPPv = string("apVVNGyRPxpMMcSeYWupSNiXBJZLaVzGaiPPiqwppCTlVQAGwTxOuwWmSsMrzrHawkDXsUwpdlIYWYtjDanAtvbjeVgTWnJaXsFkTQHNsNQgXDrtoMAxoAKkBsfaJZLMViEUcZBWnCSfkSznHtbVHE");
    int SlexOszzcDMfZLUK = -517750151;
    string kiSjvAiOo = string("dBTodwflwNYBwmdrcIxdtqgtLzPWdFnZHAZBVcFuhoItyYzOCsFOwqeMIfoSBcvzKgOBqXIeEWWhsSejcBtGgsZhNWZPcLH");
    int dziIntAEhu = 2141040809;
    int aYVEFwgOmdGHoKlz = 963119295;
    int qtTGEA = 873863368;

    for (int DMeMkeuPhKzkVd = 266164220; DMeMkeuPhKzkVd > 0; DMeMkeuPhKzkVd--) {
        kiSjvAiOo = IQQmnDrGDGy;
    }

    if (XDzdpZ < 303134485) {
        for (int vkewbkIjtUpln = 2040289060; vkewbkIjtUpln > 0; vkewbkIjtUpln--) {
            XDzdpZ *= aYVEFwgOmdGHoKlz;
        }
    }

    if (SlexOszzcDMfZLUK == -517750151) {
        for (int EBdTR = 963842135; EBdTR > 0; EBdTR--) {
            aYVEFwgOmdGHoKlz /= dziIntAEhu;
            vMxfPmzOUaWiQ += vMxfPmzOUaWiQ;
            iPCiQOfISBhlPPv += IQQmnDrGDGy;
            aYVEFwgOmdGHoKlz += SlexOszzcDMfZLUK;
            aYVEFwgOmdGHoKlz *= qtTGEA;
        }
    }

    if (kiSjvAiOo != string("fsxELMxgdozHyFaXWKGjXhdtmhCmiIFFMRHaKvDJjYZMpGlTDVsuoWSwHPPGJSkwxVQMADukTDEAicyflkfrXlvwAXwrFBGZvxQxQefXJroGAshjfqIDLyvqYbibytCWNLHFkDWwTJHPutgJTxAAKA")) {
        for (int pVHIogbd = 992948688; pVHIogbd > 0; pVHIogbd--) {
            HvwGCjMKpeYrPN += FsnlhHaMR;
            SlexOszzcDMfZLUK += aYVEFwgOmdGHoKlz;
            XDzdpZ = XDzdpZ;
        }
    }

    for (int SWmkdrPLF = 669058997; SWmkdrPLF > 0; SWmkdrPLF--) {
        vMxfPmzOUaWiQ += iPCiQOfISBhlPPv;
        IQQmnDrGDGy += vMxfPmzOUaWiQ;
    }

    if (aYVEFwgOmdGHoKlz < 2104789017) {
        for (int AQgBkHbaPmljTjv = 69865289; AQgBkHbaPmljTjv > 0; AQgBkHbaPmljTjv--) {
            IQQmnDrGDGy = IQQmnDrGDGy;
            FsnlhHaMR /= FsnlhHaMR;
        }
    }

    if (vMxfPmzOUaWiQ > string("dBTodwflwNYBwmdrcIxdtqgtLzPWdFnZHAZBVcFuhoItyYzOCsFOwqeMIfoSBcvzKgOBqXIeEWWhsSejcBtGgsZhNWZPcLH")) {
        for (int GUWPyuELZPliUI = 1676709298; GUWPyuELZPliUI > 0; GUWPyuELZPliUI--) {
            XDzdpZ -= HvwGCjMKpeYrPN;
            SlexOszzcDMfZLUK -= XDzdpZ;
            qtTGEA /= FsnlhHaMR;
            aYVEFwgOmdGHoKlz += aYVEFwgOmdGHoKlz;
        }
    }

    return qtTGEA;
}

double RnsfJOdxS::SaKvOx(int meweGu, int LmowWXMWC, int mxrrjkHxqditAD, double CSgJgCM)
{
    bool CvTjCg = true;
    string UKYdhhPgwmqHuep = string("ZldjuAixUYaxfaPtZmhNpbzvHVNVZqEJUAiEDFeKUwpMQcgZfIUZxvsVwOJqXIuntbDWuiEHBm");
    double zcHNIWyuP = 570084.0598561546;
    string iITwVAlt = string("tOsli");
    int DUAooxYTGYQImKR = -794509971;
    int exFtYryin = -620866973;
    bool qgjnjgwfE = true;
    bool LOzsvXueFvvZqjU = true;

    for (int TsbEFMSFnMPw = 170353924; TsbEFMSFnMPw > 0; TsbEFMSFnMPw--) {
        continue;
    }

    return zcHNIWyuP;
}

string RnsfJOdxS::mLKkFjRCNUcn(bool uieQjW)
{
    bool teycn = true;
    bool lssIHARK = false;

    if (uieQjW == true) {
        for (int MhAUoSxpkqWcXiHw = 465787735; MhAUoSxpkqWcXiHw > 0; MhAUoSxpkqWcXiHw--) {
            teycn = teycn;
            lssIHARK = lssIHARK;
            teycn = ! lssIHARK;
            uieQjW = ! teycn;
            lssIHARK = uieQjW;
            lssIHARK = ! teycn;
            lssIHARK = ! teycn;
            teycn = ! uieQjW;
        }
    }

    if (uieQjW != false) {
        for (int WwYiqeGnN = 539821750; WwYiqeGnN > 0; WwYiqeGnN--) {
            teycn = ! teycn;
            uieQjW = teycn;
        }
    }

    return string("bJWzwIrDkdxtiHIqnAhgZVvvzBAgSkfRGfJeCKPmGiAADnNfiyrooRSjGouATAEuaILmKeXQenJTtPNTGwKrOqpfdsM");
}

void RnsfJOdxS::eUoKJyuSBEhOih(bool pahmM, string xImpUWmc, string pGqEcrWtbVK)
{
    double RHiLpbAhlnTN = -285510.8197279713;

    for (int Zximj = 1654310878; Zximj > 0; Zximj--) {
        continue;
    }

    for (int XUSFPbQaYXeuBEC = 570114358; XUSFPbQaYXeuBEC > 0; XUSFPbQaYXeuBEC--) {
        RHiLpbAhlnTN += RHiLpbAhlnTN;
    }

    if (RHiLpbAhlnTN == -285510.8197279713) {
        for (int VtdkHzOOB = 1164958472; VtdkHzOOB > 0; VtdkHzOOB--) {
            pGqEcrWtbVK = xImpUWmc;
        }
    }

    for (int vLViXGJ = 662591842; vLViXGJ > 0; vLViXGJ--) {
        xImpUWmc += pGqEcrWtbVK;
    }
}

void RnsfJOdxS::WTLBUJAQf(int evLfxgTmD, bool KyNhHFbyjpDQ)
{
    int hqPYJAgpOy = -178134023;
    int KfpVxSfhCuPZPW = -1347121023;
    double HXDCPx = -18765.923792028814;
    int XLEmKXQu = 1208740777;
    double JQgBoekisOIjhWb = -294295.6413588049;
    int TyOCIVBpLuwirgkG = 163633666;

    if (XLEmKXQu != 163633666) {
        for (int pKnMugwABYoMlDC = 273800051; pKnMugwABYoMlDC > 0; pKnMugwABYoMlDC--) {
            XLEmKXQu -= XLEmKXQu;
        }
    }

    for (int gwpnNciAgrctV = 319795749; gwpnNciAgrctV > 0; gwpnNciAgrctV--) {
        TyOCIVBpLuwirgkG -= TyOCIVBpLuwirgkG;
        KfpVxSfhCuPZPW += TyOCIVBpLuwirgkG;
        XLEmKXQu += TyOCIVBpLuwirgkG;
    }

    if (hqPYJAgpOy <= -1393498043) {
        for (int vjDdDYnpkdlWt = 1239885799; vjDdDYnpkdlWt > 0; vjDdDYnpkdlWt--) {
            XLEmKXQu *= KfpVxSfhCuPZPW;
            HXDCPx += HXDCPx;
            evLfxgTmD = evLfxgTmD;
            TyOCIVBpLuwirgkG /= TyOCIVBpLuwirgkG;
        }
    }

    for (int opKpOYw = 1353017738; opKpOYw > 0; opKpOYw--) {
        KfpVxSfhCuPZPW -= evLfxgTmD;
    }

    for (int ultgiVymxfU = 769416886; ultgiVymxfU > 0; ultgiVymxfU--) {
        hqPYJAgpOy -= KfpVxSfhCuPZPW;
        hqPYJAgpOy = evLfxgTmD;
    }
}

bool RnsfJOdxS::QWPkIQ(bool MKnNUViECMMMZIf, string LnTxuwkkrsDX, string luUxuCotJ)
{
    double KonxdagV = -69412.16099806594;
    double abyCtVyJiSQ = 191515.34344990543;
    string COTSXEaHAiaP = string("jBCCBdaagXGcZxVKHXUUZLoByiRNVCNiPIQxwQEWWtYTZFVRAjzpvFIHqjTXREdjPKsDjBpZRpOKILndUrIsnoICSdTlfydiUkQubLJHcLrIsyTZnkWLJTftJPXuDZqZUyYUwIHrxcXiQJXebVDeQkfnocFdxJDAXjAeXjVEgWtYHBBfyuFJOmjystRYswrmXWWRmAZtvAyUpQavAjDsZYMUNKUw");
    double WctElIbazpcKx = -244848.27657963664;
    double bxKQT = -648503.9826383636;
    string sOwoTU = string("TnPlSJikBLpeRrTScrRuN");
    string mlvsizBfSBB = string("vXTxJSHScwxspFgumZfVBSSImNzzJkJhWdwKYchpWVuJxwJLYSruNGItgeFHRDwJmtNmJPPgYYdzCujykZUIhBPxrvJpWhxmKCdHUOQONCSwWgAcBKUyygsNRiihbEMFUmatnfBQYaZMBJVkNcSQxsqVvlWSqfUKPTjIObTNoEyWmepkIkzlzEMczFyrApABJzQdRguWRRDnGNCdnigDDwfbuBYfVXRKZHOXiGddocejqF");

    if (bxKQT < -69412.16099806594) {
        for (int XheEyRtZdGiOw = 120606036; XheEyRtZdGiOw > 0; XheEyRtZdGiOw--) {
            continue;
        }
    }

    if (LnTxuwkkrsDX >= string("xcQGgChgKxbPDOSjEflIFVlzUBIffqLLyMHNpZtkUcNaCNrtyLBhJBXpFkDPF")) {
        for (int jKrWSFugsnBT = 452282427; jKrWSFugsnBT > 0; jKrWSFugsnBT--) {
            WctElIbazpcKx += bxKQT;
        }
    }

    return MKnNUViECMMMZIf;
}

double RnsfJOdxS::nSECffCq(bool MSRuREJHzobHGb, bool FpBoHRNR, bool BLIKtvv, double JynqF, int DswnuOSsZ)
{
    double HGIjAAOOwi = 557301.6544585933;
    double LSodMdXJpDX = 272231.16653987695;
    int KUzjhWwHgU = -1858369323;
    double puZvThoJnrU = 24607.50858630863;

    for (int UouKKgTOuO = 1079294855; UouKKgTOuO > 0; UouKKgTOuO--) {
        continue;
    }

    for (int pluBd = 1804345581; pluBd > 0; pluBd--) {
        JynqF -= puZvThoJnrU;
        puZvThoJnrU *= LSodMdXJpDX;
        puZvThoJnrU /= puZvThoJnrU;
    }

    return puZvThoJnrU;
}

bool RnsfJOdxS::nyquwzeIFY(double JOuGntjUKylbVM, bool eENbZtMKzNXDs)
{
    int buPfddPcY = 635339014;
    double cPbErIHDpp = -694022.6742999806;
    int DDqHtHRZSKGHjF = -1276766042;
    bool yyJahGF = false;
    string NGzrkIxFg = string("OCKQnaIMDXhPnMzCOxPxhiJnSXfRdIxyUjHTaNoDDwbavyDjVqtcXRXAaAQKcJGIikEisVlIGczlgwvqIzRXFyNBnYjTzCAbqUUNUzyccyjZpAvayczZyJQzrbvgDWYtiRtFJeCbZNPeRvFBSHcCNgxCenaqWKNZLIDYPoupuFZsnqFIzyoBJBmJWNzzjCgvaiKqJYNnSsVSHYHJlVCrigrmYzPPiDgnZMC");
    string DIHWXA = string("DCjeDUTyfEBmrNztLpZKiWtfyrZjdMcSbRpxcIpilBZZgsIKuJIiGWqTlxWUqtlQyUErv");
    int MrBkCpgfxGLK = 1291069300;
    bool KPqWC = false;
    bool CxPfxThVdVj = true;
    bool IXswSNcfk = true;

    if (yyJahGF != false) {
        for (int tvnwFzJY = 1592908989; tvnwFzJY > 0; tvnwFzJY--) {
            eENbZtMKzNXDs = ! IXswSNcfk;
        }
    }

    return IXswSNcfk;
}

double RnsfJOdxS::MovahMidT()
{
    string sEFLpkzzzPSF = string("AeyangqbEyNzFhdtUMDrYyTyBqlhJOMOfbfSUqSiRrdBnRRXdTAExFNLWIbyHbXNQXSgvJPzxnNMJQiTPXoIbTfyxBOgZtGRyZBSdPYFqdOXcMqVnjAFragkprZUIErUPkQeolKuInzknnYPKbWbPSXTCDorEKDGidLduBaQADyjdsqPNUUHeCKdhqVHyaAwjgqosSYTlIMyAgeJDrxPhCTzBHH");
    double ztuyTDQWmbnrzEG = 358893.75922453456;
    string xPvkVZXUnyW = string("IQIfHegcbCPTbyvSiXFgY");
    string PbVZngymKOkmW = string("bPNcHMRlESOENjHxHYnpEuFMBLmtxJCHVcIBdXBIxdzbATyXcplQfdtpssXTsiaAKnrlaWnkEMMGwuMImNtqgNJwMwrTWLDOtjQnXRhOZjUNJlkpZotKxfpwbiNkFGyzxeNSoMFHdulcKbFSuyYOkDfbkIdppCAcdxruebtDvvuptVTtxeagWqIeTmeYHBoELLryOOmoVOFjEfnQwHXaUJLFLaUAEiAPOeqANuLpGnsBHoPrvwNoRVHfwUNuD");

    if (xPvkVZXUnyW >= string("bPNcHMRlESOENjHxHYnpEuFMBLmtxJCHVcIBdXBIxdzbATyXcplQfdtpssXTsiaAKnrlaWnkEMMGwuMImNtqgNJwMwrTWLDOtjQnXRhOZjUNJlkpZotKxfpwbiNkFGyzxeNSoMFHdulcKbFSuyYOkDfbkIdppCAcdxruebtDvvuptVTtxeagWqIeTmeYHBoELLryOOmoVOFjEfnQwHXaUJLFLaUAEiAPOeqANuLpGnsBHoPrvwNoRVHfwUNuD")) {
        for (int yOfKKf = 1262909643; yOfKKf > 0; yOfKKf--) {
            xPvkVZXUnyW = xPvkVZXUnyW;
            PbVZngymKOkmW += xPvkVZXUnyW;
            sEFLpkzzzPSF += xPvkVZXUnyW;
            sEFLpkzzzPSF += xPvkVZXUnyW;
        }
    }

    for (int WuCYfJl = 1068559389; WuCYfJl > 0; WuCYfJl--) {
        PbVZngymKOkmW += PbVZngymKOkmW;
        sEFLpkzzzPSF = sEFLpkzzzPSF;
    }

    if (PbVZngymKOkmW == string("bPNcHMRlESOENjHxHYnpEuFMBLmtxJCHVcIBdXBIxdzbATyXcplQfdtpssXTsiaAKnrlaWnkEMMGwuMImNtqgNJwMwrTWLDOtjQnXRhOZjUNJlkpZotKxfpwbiNkFGyzxeNSoMFHdulcKbFSuyYOkDfbkIdppCAcdxruebtDvvuptVTtxeagWqIeTmeYHBoELLryOOmoVOFjEfnQwHXaUJLFLaUAEiAPOeqANuLpGnsBHoPrvwNoRVHfwUNuD")) {
        for (int pWpgnDINII = 564378218; pWpgnDINII > 0; pWpgnDINII--) {
            continue;
        }
    }

    for (int afDENdXEjZiyUD = 1047257896; afDENdXEjZiyUD > 0; afDENdXEjZiyUD--) {
        PbVZngymKOkmW = xPvkVZXUnyW;
    }

    return ztuyTDQWmbnrzEG;
}

bool RnsfJOdxS::KInPetnfbyed(string yhgUxbThDffLx, double PzLEnThoJBgPpp)
{
    bool eyjjtdjs = false;
    int JTCLviOFVfrkhEf = -1803085784;
    bool KcQHTJRkL = false;
    double eSIjrZH = 171874.43908334596;
    double kYsxlzE = -1046710.9735354161;
    bool PwdygJvZMFt = true;
    string eRGog = string("yDClRjlghtWfBYtOMFABNhItdRHuogVGGfwagjjNMKiOvUDpVkDoguAoCKuQazpQMZEBwgiRaeSTFxzMfuQkXRnBMDaYPfnqjiOGFEyqpmZhPFJBTzUhWIYVGeRbLJresWSiIuVUMxBYHizlCSDOOKeoKIydUrYNiMtwmBXfHTupMqgfD");
    double laumcOkDbAMqir = 943285.1332558802;
    bool ShIMisFBmmHOqo = false;
    int lcEmYIqfZ = -868757598;

    for (int wBJTatxF = 1385516693; wBJTatxF > 0; wBJTatxF--) {
        continue;
    }

    return ShIMisFBmmHOqo;
}

int RnsfJOdxS::wQAfySVaHpBeNVMw()
{
    string oaOZGAJsou = string("QqfjlCJrxOMCKkvAIJEBNWtoZfjjfZkUSqcHgOdtulfXmKOGHLmWgexjkebIjZvTHGyyjntyj");
    int hOMdIAjUHvIKDF = -1889674319;
    double Txnwo = 766074.1055077981;

    return hOMdIAjUHvIKDF;
}

double RnsfJOdxS::elfUMnjxQ(double pyuqgCFNeuKzmfQ, bool LFxdesd, bool cBdIvqvGfXRvMW, string xLlHl)
{
    string ZuzBjmkplPGimLK = string("xRwSltCJtoUMxSzkAiJCGWHvRMTUIpbOgVuUxoMDaAsXgwZOeJFwJjzoPF");
    string xvnijraR = string("nzyBNRSfFioXxcvrCqxuRAmutmkyrlZrAXlonnKtdjktDyZKLkGVLhzFGgqSuyAbnTwGRjEDKdDfOvxCxFWdeRXaTedpswjvtrwNMCJstTaeicAiReMRJkfWrGgxktkIyILmFqaYgVFpGdCasUmKaDsjgmiPGWldnKCWQnhNxTUiPOVzzAWwjSKcsWEHIwGTHeqtZDIiBeIqJDOdiAqpgpTRuyBUKFm");
    int YUEfJYDenEIfY = -993557248;
    int SQdvIkLoRUZSvp = 1046985616;
    bool pBXkrTMUxWKCUMy = true;
    bool SGRNiFN = true;
    double UdWrwNNYlW = 41362.68541187286;
    double dlNgERJhJHhhEUms = -342524.48370942264;
    string tPgJaqrtxAmJ = string("UKMmEfhURtVfjoiPxRaUqlpAZxruKNZDCKXHXHpVioPwzanaEYZFOhIuTGYPgVdJGSdxRdKMXxVDCwbblpaNPImOKAnwaxLtHTAcCXUJSLzjlnztczFLzEGCRbKmpzuRLzAUI");

    for (int QNPjV = 1922523671; QNPjV > 0; QNPjV--) {
        continue;
    }

    for (int QQVGRc = 1278983484; QQVGRc > 0; QQVGRc--) {
        SGRNiFN = ! LFxdesd;
        UdWrwNNYlW = UdWrwNNYlW;
    }

    for (int bImxNz = 39197597; bImxNz > 0; bImxNz--) {
        xvnijraR += xLlHl;
        xvnijraR += tPgJaqrtxAmJ;
        UdWrwNNYlW /= pyuqgCFNeuKzmfQ;
    }

    return dlNgERJhJHhhEUms;
}

bool RnsfJOdxS::AqLbQ(string kdRdnJRSAOZTJcSz, double pqKmvx, double QyxLgyFTgvcdlcqI, bool NxwYmcb)
{
    int jEHNXhUkfDHdNdsX = 1333530300;
    string kFCpAatilikJ = string("REKjRUaPW");
    bool eJxEB = false;
    int bpgKvMk = -1787146512;
    bool ystGQJkX = true;
    bool jCJOkMb = true;
    string niKvpuUNntqO = string("NApzhyOoVxbYueHBTMjNfcVQaIEtKhZQHuViTXxOUTjPkywHPSGdfCTKimgNGVUyVWVhDGilQgEbdsmwTjmFxgvMGTuYfYWhwiZNFEgolyLEAGKBUxUhFOKJNAerCkAlAXLVTAnqLbylMwaNagXfqOhfXISLMXSAjrhGdkciVvOMJwarPJtvhQfXFcOViCcqZUkRLOnJXnDgKKmhFiDjoZBs");

    for (int TDVVPFn = 294371293; TDVVPFn > 0; TDVVPFn--) {
        QyxLgyFTgvcdlcqI += QyxLgyFTgvcdlcqI;
        ystGQJkX = ! ystGQJkX;
    }

    for (int CECeZoaEm = 1951988874; CECeZoaEm > 0; CECeZoaEm--) {
        continue;
    }

    return jCJOkMb;
}

bool RnsfJOdxS::mZcjgwRfsUcTzME(bool DTQHIFaGBOwWKe)
{
    double JlDYAQHX = -507438.5203690309;
    int zJXTclpjJDfbL = -961308197;
    bool gGHCOORuRRr = true;
    bool SUgkjburxY = false;
    bool fAXqJVDTtxIUG = true;
    int IjckMD = 1976345789;

    if (IjckMD > -961308197) {
        for (int DmnHQpsJC = 500038719; DmnHQpsJC > 0; DmnHQpsJC--) {
            SUgkjburxY = gGHCOORuRRr;
            SUgkjburxY = ! DTQHIFaGBOwWKe;
        }
    }

    for (int UYiOT = 1277430751; UYiOT > 0; UYiOT--) {
        DTQHIFaGBOwWKe = ! fAXqJVDTtxIUG;
    }

    if (gGHCOORuRRr == true) {
        for (int XBOuOpEyPCca = 2090477637; XBOuOpEyPCca > 0; XBOuOpEyPCca--) {
            fAXqJVDTtxIUG = SUgkjburxY;
            zJXTclpjJDfbL /= zJXTclpjJDfbL;
            IjckMD /= zJXTclpjJDfbL;
            fAXqJVDTtxIUG = ! gGHCOORuRRr;
        }
    }

    for (int avkKVM = 274186933; avkKVM > 0; avkKVM--) {
        fAXqJVDTtxIUG = SUgkjburxY;
        fAXqJVDTtxIUG = SUgkjburxY;
    }

    for (int zyxNSoEl = 1136327892; zyxNSoEl > 0; zyxNSoEl--) {
        zJXTclpjJDfbL += zJXTclpjJDfbL;
        fAXqJVDTtxIUG = SUgkjburxY;
        fAXqJVDTtxIUG = ! fAXqJVDTtxIUG;
    }

    return fAXqJVDTtxIUG;
}

string RnsfJOdxS::VEVAiDdCpHNltQzp(int cdhPzotX)
{
    double jMmAexQqUD = 656198.7461900063;
    bool egTGBEynGWjCUJca = true;
    double kfygwEJcya = 379618.53015393467;
    bool IWBGfncP = true;

    for (int TjkaT = 1697978489; TjkaT > 0; TjkaT--) {
        IWBGfncP = ! IWBGfncP;
        egTGBEynGWjCUJca = ! IWBGfncP;
        jMmAexQqUD *= kfygwEJcya;
        jMmAexQqUD /= jMmAexQqUD;
    }

    if (kfygwEJcya <= 379618.53015393467) {
        for (int SjZoOd = 1861312081; SjZoOd > 0; SjZoOd--) {
            kfygwEJcya /= kfygwEJcya;
            kfygwEJcya /= jMmAexQqUD;
            egTGBEynGWjCUJca = ! egTGBEynGWjCUJca;
            jMmAexQqUD -= kfygwEJcya;
        }
    }

    for (int BIOwfhsJNZR = 655602595; BIOwfhsJNZR > 0; BIOwfhsJNZR--) {
        cdhPzotX /= cdhPzotX;
    }

    for (int QutJDyUQxwPoyDji = 363201921; QutJDyUQxwPoyDji > 0; QutJDyUQxwPoyDji--) {
        kfygwEJcya /= jMmAexQqUD;
        kfygwEJcya += kfygwEJcya;
        egTGBEynGWjCUJca = ! IWBGfncP;
    }

    for (int beqvioqSgHhsP = 2039857210; beqvioqSgHhsP > 0; beqvioqSgHhsP--) {
        IWBGfncP = ! IWBGfncP;
        kfygwEJcya = kfygwEJcya;
    }

    if (kfygwEJcya > 656198.7461900063) {
        for (int vrYRugwGBr = 1304034809; vrYRugwGBr > 0; vrYRugwGBr--) {
            cdhPzotX -= cdhPzotX;
            egTGBEynGWjCUJca = ! egTGBEynGWjCUJca;
            egTGBEynGWjCUJca = IWBGfncP;
        }
    }

    return string("udKioonpXcrjsiFaAvKIGjeChbMgZENCBwtsRzmiKgiRnYoQJhXvepTtJUdHWokNxnparKmdQTiIHyijLkilXZyeKonwQUNaAsHDQuCvkNgIGnNCwSqKKLlHzaYTJnDuJqytVzUyqxgQapToOMRrbIcnfRSeOiwLapjNFwoeidImQEarYnDCtnWsqBXEfvxNxLct");
}

void RnsfJOdxS::mVJTyuOJrfjE(bool JBtDu, double xFAtxaQYpTwbC, int QDfHiBgQ, double JDPau, bool JHAEQ)
{
    double MpZcKMUoyxa = 219496.1993825254;
    int NnNarRIbDDmEyXL = -860411570;
    string wQikiaB = string("WDxdkTcoLKbIQaMxhFWKeLblIMwNtVcCJIPtZlBzkYTRifRcJfMdtpFbwcBQaDaaeewCcAiqNlqhyvaSgAPwTxdQvoHiFJolgWqperxhLxiajBEBxouxsiFJbKkxEkjivGgkmcMGTCHrPyOyxOONSNeZZBMyHRIEUoYvPtsXCsryIVNaSaCBEOQrZXteDOhzMXcqMGkKpxzfvwPhxB");
    string EAAsuS = string("SSgKtSgPEDbrVJQQNYoJYtLIjbzQuMFvaIfjBpFKhwCeTItWvwvYtMNSfXrHXaNjscEKKybVTlnAMQYVCHShSyCjJgNuPPYskmUsAdbkPBGAAUWOgucWFFovJsxqqASBsBEhmHaAOejIPUHvQygQxdAxLmtmsWkmidBkEOuWJrPxSJcHRsFzurOpqbMpmGobKtqpQufcnkAuXBOWqwRlwphJv");
    int xlURXIVi = 294273006;
    bool CqkhfJsdTs = false;
    bool ZSYCTwEKj = false;
    int kGYLHG = -1592899732;

    if (xFAtxaQYpTwbC >= -938005.8076837333) {
        for (int lfUPHEFLZ = 1587869022; lfUPHEFLZ > 0; lfUPHEFLZ--) {
            EAAsuS = wQikiaB;
            JDPau = MpZcKMUoyxa;
            CqkhfJsdTs = ZSYCTwEKj;
        }
    }

    for (int kYIzhXfsSMSQmwW = 1623278042; kYIzhXfsSMSQmwW > 0; kYIzhXfsSMSQmwW--) {
        kGYLHG = xlURXIVi;
    }

    if (JHAEQ != true) {
        for (int sXNBGo = 820548204; sXNBGo > 0; sXNBGo--) {
            NnNarRIbDDmEyXL = kGYLHG;
        }
    }

    for (int LilFEEou = 1880277140; LilFEEou > 0; LilFEEou--) {
        continue;
    }

    for (int EvbvzlYmaiLZcVq = 465534268; EvbvzlYmaiLZcVq > 0; EvbvzlYmaiLZcVq--) {
        continue;
    }
}

bool RnsfJOdxS::JsOsC(double NGYddgFCBmLbT, string GzxSRKgoeEHBPS)
{
    bool bKDnhlGcaoeYl = true;
    string EAgyq = string("NlBgszBdCfxaEjltkRLlcsATgESsGuqOIElMkyQIwTzzhMOuypCfTNWIpnnsIZzvXAFRISUpDonAWLCwaQfFPaPVIndcZhBYOADWHvvjJRmFvCHUftbgwQzTDycqcNvffcSLIZaQEmWyyJKNHMMZFUIKbRlAMNGVnGLdslNoMUokyLPWZsvhdESIvzwlAEfMbDRMqLwKCOOVDSqphmchcTMGIIIjZCqorKWTdhjRASxbPRQnMCineTcpQmdz");

    for (int hOlaI = 1290816807; hOlaI > 0; hOlaI--) {
        bKDnhlGcaoeYl = ! bKDnhlGcaoeYl;
    }

    for (int mjmqgruDyH = 1910800625; mjmqgruDyH > 0; mjmqgruDyH--) {
        EAgyq = GzxSRKgoeEHBPS;
    }

    for (int oNGTqqJDjSDMx = 1523015431; oNGTqqJDjSDMx > 0; oNGTqqJDjSDMx--) {
        continue;
    }

    if (EAgyq != string("NlBgszBdCfxaEjltkRLlcsATgESsGuqOIElMkyQIwTzzhMOuypCfTNWIpnnsIZzvXAFRISUpDonAWLCwaQfFPaPVIndcZhBYOADWHvvjJRmFvCHUftbgwQzTDycqcNvffcSLIZaQEmWyyJKNHMMZFUIKbRlAMNGVnGLdslNoMUokyLPWZsvhdESIvzwlAEfMbDRMqLwKCOOVDSqphmchcTMGIIIjZCqorKWTdhjRASxbPRQnMCineTcpQmdz")) {
        for (int ClHqdwKyROIrG = 1911201882; ClHqdwKyROIrG > 0; ClHqdwKyROIrG--) {
            continue;
        }
    }

    if (EAgyq > string("BPLCmSfaShBjUhIojOhKsjjXxmRxwSCkUyCyObiwwYLpcIXzYojNcBzbffjhilrVOUNsFgmMUhDicMPMbUXUpWsLaSwaXWmhUrRJhuSbkSljAAOCVKwZiFxCYqAJVApVbBmdWMzLLkrgrWCwciodlajHWCasCBEHEaAHgUlRcvLYeZPlwuBfRuzAy")) {
        for (int vefXTJeBDM = 1137675347; vefXTJeBDM > 0; vefXTJeBDM--) {
            GzxSRKgoeEHBPS = EAgyq;
            EAgyq += GzxSRKgoeEHBPS;
        }
    }

    for (int wPhASdya = 1328723119; wPhASdya > 0; wPhASdya--) {
        bKDnhlGcaoeYl = ! bKDnhlGcaoeYl;
    }

    if (GzxSRKgoeEHBPS == string("NlBgszBdCfxaEjltkRLlcsATgESsGuqOIElMkyQIwTzzhMOuypCfTNWIpnnsIZzvXAFRISUpDonAWLCwaQfFPaPVIndcZhBYOADWHvvjJRmFvCHUftbgwQzTDycqcNvffcSLIZaQEmWyyJKNHMMZFUIKbRlAMNGVnGLdslNoMUokyLPWZsvhdESIvzwlAEfMbDRMqLwKCOOVDSqphmchcTMGIIIjZCqorKWTdhjRASxbPRQnMCineTcpQmdz")) {
        for (int alOMMbN = 483915928; alOMMbN > 0; alOMMbN--) {
            GzxSRKgoeEHBPS = GzxSRKgoeEHBPS;
            GzxSRKgoeEHBPS = GzxSRKgoeEHBPS;
        }
    }

    for (int MXrLcYYjM = 245171463; MXrLcYYjM > 0; MXrLcYYjM--) {
        GzxSRKgoeEHBPS += EAgyq;
        GzxSRKgoeEHBPS += EAgyq;
    }

    return bKDnhlGcaoeYl;
}

RnsfJOdxS::RnsfJOdxS()
{
    this->JBMzpQa(string("PBqgTzurjkiQtWljwlGMXPJxCXjkTdgaWcXLSfrLuVealsvPCzalXvgSekqYUifLbzPywoOoeQFZHcTOcgUezsTahySnHPAyjAZdCEcjraoXrWJhnWLqoHSwGYFCbCdAxfjVrNJnprGiIHpiFPBVPuWVBwdPvVjHWoNBdjwXwOLrgwXPLhmjMQPpbXIrFxDDxrejnQZbufGZwWyNUXujYDxHJTYPZePsTYzsRENUUOHmrPVartmut"), string("fsxELMxgdozHyFaXWKGjXhdtmhCmiIFFMRHaKvDJjYZMpGlTDVsuoWSwHPPGJSkwxVQMADukTDEAicyflkfrXlvwAXwrFBGZvxQxQefXJroGAshjfqIDLyvqYbibytCWNLHFkDWwTJHPutgJTxAAKA"), 2104789017, -2056537744, 303134485);
    this->SaKvOx(485001279, 986292075, 2100549564, 734614.4633248545);
    this->mLKkFjRCNUcn(false);
    this->eUoKJyuSBEhOih(false, string("gsQqgkvEvslYKIEDgcwbicslaFptjPITqkCxuGMJbvpbtczTqgQNWtAobkedEQamgBRhhYcvUAybPcxwoOZbQTdEFPQruomABmPCmjAppOdfMVDjQhSxyknrOiGsnwvJrNFNxJCoPBxZWVYTAFnDjPsFpWtkMXgFxmACbISTCAclStTeXpjUtyqjaTcjnaZmBonZvKldeilZxlGRYnqSweuqlUweXgnrxIVdImXUxBHfPOjZba"), string("JTeOqMPGWOfUptJjjGlgLjdmIQLrAoHKtrFEsxukVSGTSomzOLvALWKlJQlREevEqmlNdBpblHossPckGVIrNOuj"));
    this->WTLBUJAQf(-1393498043, true);
    this->QWPkIQ(true, string("QWRxchVOdQPjHWZptNcLcnXdFUhnFPMUrfLbnCjSVzczxwkXePumblBNMrcJRLbMyQvIeMopFhROUCfBMqFqlZHBxhlekshjBIfySDvqkudsvgBUcQCSEbmAycNIPhLkLJLVDeTZjqqMARuCclsCCAKhsdJuHEzctRCYdtGgPJugtNgSNQucRNXfDlNpzVCHR"), string("xcQGgChgKxbPDOSjEflIFVlzUBIffqLLyMHNpZtkUcNaCNrtyLBhJBXpFkDPF"));
    this->nSECffCq(true, false, false, 463563.8169424027, 1644499706);
    this->nyquwzeIFY(660205.4250377055, true);
    this->MovahMidT();
    this->KInPetnfbyed(string("oGSQtTyzDazuALFbtghntonyjWyCaMyBdbwltLTBYCOzRxffzdplRRRhxnPaPStMNyOnTizXNBvQqvEFomlHRxfIiRtappknsDmKvRcNrLaYcSVMNOmEIboBWRnXbHqayRxNgUXDWSdITEScziWrbTvvgzYsVuJVSHGcnGG"), 318447.66232993605);
    this->wQAfySVaHpBeNVMw();
    this->elfUMnjxQ(-840885.486713673, false, false, string("DlRHCChHHiMZlWTSEjirYTYLiTlSAAhSHPDSDBPSxAxjIEpPCLBjLdoUigkAipwIqWQLiDqHEHHgEZTWiQZHMCYXzWRIgYBAXOHNG"));
    this->AqLbQ(string("CRiUY"), -633356.0541179095, 478053.76970590925, true);
    this->mZcjgwRfsUcTzME(true);
    this->VEVAiDdCpHNltQzp(1845536445);
    this->mVJTyuOJrfjE(true, -938005.8076837333, 551954112, 1045497.028093231, true);
    this->JsOsC(794714.9455227302, string("BPLCmSfaShBjUhIojOhKsjjXxmRxwSCkUyCyObiwwYLpcIXzYojNcBzbffjhilrVOUNsFgmMUhDicMPMbUXUpWsLaSwaXWmhUrRJhuSbkSljAAOCVKwZiFxCYqAJVApVbBmdWMzLLkrgrWCwciodlajHWCasCBEHEaAHgUlRcvLYeZPlwuBfRuzAy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XGSKctS
{
public:
    double iKDsZVhfViWX;
    bool vLgiYk;

    XGSKctS();
    string IDjplbNAgnNQkMZ(double CBFOthHdrotzNa, string rreAQdCtfidrlrI);
    bool DYshnihBa(int GajXBig, int CLXjYWZPRe);
protected:
    int DDieP;
    int aWxiQKcY;
    bool JYNAVIv;
    int tmPSdWSs;
    bool GzzpeIBogY;
    double cLuWCrY;

    double zxhfCC(int TXXTfWWdaTaFpEJ);
    double eBxqMZy(string zJKgn);
    int qsOYYTwJJGT(int QEfja, int KfcpzZemKfJamAu, string EhIWYMQaTRBgZ);
    void ECaFIaZlKy(bool KSZxsmUlMdT, double AdorOq, string HifSG);
private:
    double GHaeFUQZB;
    double oBLuCflk;

    bool VDSEedpxIdHn(string sobNrOjoq);
};

string XGSKctS::IDjplbNAgnNQkMZ(double CBFOthHdrotzNa, string rreAQdCtfidrlrI)
{
    string nkPrhIylpt = string("IUuoHmUuBdCCEIuSXDwXUrVJgymKXjWkiKaOaDPITTVVdURbdvlbJDEJPswTUVtWfYoZNYHPwJwItOiXNFBBepYTgWOwqsnMWhAtZK");
    bool CsGijuYisSB = true;
    int CYktATTqBslOT = 2126558945;
    bool RWOLHGvWPTWuctEt = true;

    for (int sFSafLK = 613479521; sFSafLK > 0; sFSafLK--) {
        CsGijuYisSB = ! CsGijuYisSB;
    }

    for (int GyKcPLclWTDoPGQ = 2121298628; GyKcPLclWTDoPGQ > 0; GyKcPLclWTDoPGQ--) {
        continue;
    }

    for (int trjFIniimexlvcij = 1934803225; trjFIniimexlvcij > 0; trjFIniimexlvcij--) {
        nkPrhIylpt = nkPrhIylpt;
    }

    for (int VsXsybDmGuWmY = 301240627; VsXsybDmGuWmY > 0; VsXsybDmGuWmY--) {
        CsGijuYisSB = CsGijuYisSB;
        CYktATTqBslOT /= CYktATTqBslOT;
    }

    return nkPrhIylpt;
}

bool XGSKctS::DYshnihBa(int GajXBig, int CLXjYWZPRe)
{
    string IenCCI = string("kKmqHerxXaKiFvRjabKpmkhQiAEENd");
    int HaLFQpyHdZxOn = -729983015;

    if (GajXBig >= -1051276500) {
        for (int EgySKnEXtUQaQ = 757325190; EgySKnEXtUQaQ > 0; EgySKnEXtUQaQ--) {
            CLXjYWZPRe = HaLFQpyHdZxOn;
            GajXBig *= GajXBig;
            CLXjYWZPRe -= HaLFQpyHdZxOn;
            IenCCI = IenCCI;
        }
    }

    if (HaLFQpyHdZxOn == -1051276500) {
        for (int NalzDiAfAGEuOO = 164886237; NalzDiAfAGEuOO > 0; NalzDiAfAGEuOO--) {
            GajXBig += GajXBig;
            CLXjYWZPRe += HaLFQpyHdZxOn;
            GajXBig /= CLXjYWZPRe;
            CLXjYWZPRe *= GajXBig;
            CLXjYWZPRe *= GajXBig;
        }
    }

    return false;
}

double XGSKctS::zxhfCC(int TXXTfWWdaTaFpEJ)
{
    double lHkyaEsXpjH = 272245.0560190739;
    int WSclcqFm = -1144147615;
    bool brgfUxZOsZmX = true;
    bool UWdrfPaD = true;
    string pKDmSmYMJyIUC = string("AgqKUrOknPyxRhrpRwStfUGjAHCJVAmbfgmcqhJRxfJoskvbGmUTArrZXjOwbwEQbmHBmAVISJqWsEjaFvNfcHeOFWZCDrQREuVMFSDrIhsydqXlTBxK");

    for (int SBcPLGgIJmJ = 140670206; SBcPLGgIJmJ > 0; SBcPLGgIJmJ--) {
        TXXTfWWdaTaFpEJ += WSclcqFm;
        UWdrfPaD = brgfUxZOsZmX;
        WSclcqFm += TXXTfWWdaTaFpEJ;
    }

    return lHkyaEsXpjH;
}

double XGSKctS::eBxqMZy(string zJKgn)
{
    string JpscKer = string("DzUvJQUhEBbPcAuXjRBylgroSWdPZzFeNLYodWziSUUziDmEAnxjklHWQzAtDXSqYVPxcQzpGABFgNtXiVSOtAbGtytrDmVEKfwcthekBwyQXDbkBWvzgkzaRboHbymgHmGxvBl");
    int fSZNBqLHicsscj = 197664194;
    string ssZQXQUvCQp = string("BoukyMugoroJrgCzKEZGTpIaQctoTkfMXQyCNGaQkSYLaZBsfTUAhhrOcDYOpIXRsEhHoWFBkZlMztbvpCPDIQbQBscuxxIUSWwZAbUTTVBJTwCMcyfraazdINccxsqBIJUvKCYMTktzAboIrduRLQARBybCusSBxjDSHdhWxthZuBOuAdHbdUfyR");
    int aQaXFmODJu = 2091797503;
    double eASvpsHtwgOgOIx = -977153.2034703572;
    string OyobRXAmbPBRC = string("YEHzdI");

    for (int ZusMZCepqnhaUV = 739297485; ZusMZCepqnhaUV > 0; ZusMZCepqnhaUV--) {
        fSZNBqLHicsscj *= aQaXFmODJu;
        JpscKer = ssZQXQUvCQp;
        zJKgn = zJKgn;
        fSZNBqLHicsscj = aQaXFmODJu;
        aQaXFmODJu -= fSZNBqLHicsscj;
    }

    if (OyobRXAmbPBRC == string("YEHzdI")) {
        for (int pMeQFoDFMxZf = 1295153262; pMeQFoDFMxZf > 0; pMeQFoDFMxZf--) {
            aQaXFmODJu *= fSZNBqLHicsscj;
            aQaXFmODJu -= fSZNBqLHicsscj;
        }
    }

    for (int YbECWKxxjzpjT = 413365034; YbECWKxxjzpjT > 0; YbECWKxxjzpjT--) {
        continue;
    }

    if (JpscKer > string("DzUvJQUhEBbPcAuXjRBylgroSWdPZzFeNLYodWziSUUziDmEAnxjklHWQzAtDXSqYVPxcQzpGABFgNtXiVSOtAbGtytrDmVEKfwcthekBwyQXDbkBWvzgkzaRboHbymgHmGxvBl")) {
        for (int hDNUn = 225145102; hDNUn > 0; hDNUn--) {
            ssZQXQUvCQp += JpscKer;
            eASvpsHtwgOgOIx += eASvpsHtwgOgOIx;
        }
    }

    return eASvpsHtwgOgOIx;
}

int XGSKctS::qsOYYTwJJGT(int QEfja, int KfcpzZemKfJamAu, string EhIWYMQaTRBgZ)
{
    double wAdef = -92287.7136166164;
    int fEllWjBYH = 1021326223;
    string cWLuWuUPDUV = string("xexYrRllbAZAXuRfEJgOfdcsDyamKUrzNhEsqWZkeZaIqGpGmmteebiApHxQyGLTsGaZcWgLlKLywgjSqLKbbHHryYHkaAgmOsfazaKuiBTnoCBORXHUXQokPeAYnxaSRfJupBApGPCenlGAcBBQLPAYpeKAQawJMWyKmJiNffGBugj");
    int rtjmiFddGON = -943457473;
    int iHvmwNNcke = 1291817766;
    double SFGqyVTEL = -953196.1307995619;
    double EQejdQ = -584315.968798895;

    for (int mldXOon = 1509636024; mldXOon > 0; mldXOon--) {
        fEllWjBYH -= fEllWjBYH;
    }

    if (wAdef < -92287.7136166164) {
        for (int vYpPc = 2085851693; vYpPc > 0; vYpPc--) {
            wAdef += EQejdQ;
            KfcpzZemKfJamAu /= fEllWjBYH;
            rtjmiFddGON *= fEllWjBYH;
        }
    }

    return iHvmwNNcke;
}

void XGSKctS::ECaFIaZlKy(bool KSZxsmUlMdT, double AdorOq, string HifSG)
{
    double ZvuoX = -896352.5468056136;

    if (HifSG >= string("NqDdkPokVjKgPMiJeeJDpvLBNsrrYjbwNRSGGpQVLwsNfeIpAyw")) {
        for (int XoRcCaTzPIgnyfdI = 1528581246; XoRcCaTzPIgnyfdI > 0; XoRcCaTzPIgnyfdI--) {
            ZvuoX -= ZvuoX;
        }
    }

    for (int PXuBJmJSIqezMM = 474319125; PXuBJmJSIqezMM > 0; PXuBJmJSIqezMM--) {
        AdorOq = ZvuoX;
        AdorOq = AdorOq;
        ZvuoX = ZvuoX;
        AdorOq *= AdorOq;
        HifSG = HifSG;
    }

    for (int tKaHYnZ = 533814967; tKaHYnZ > 0; tKaHYnZ--) {
        continue;
    }

    for (int UORIgAflVqGqHz = 1903068334; UORIgAflVqGqHz > 0; UORIgAflVqGqHz--) {
        KSZxsmUlMdT = ! KSZxsmUlMdT;
        AdorOq = ZvuoX;
    }
}

bool XGSKctS::VDSEedpxIdHn(string sobNrOjoq)
{
    int HYGLEecUGbXx = -1384519260;

    if (HYGLEecUGbXx > -1384519260) {
        for (int biigS = 1496422606; biigS > 0; biigS--) {
            sobNrOjoq = sobNrOjoq;
        }
    }

    if (HYGLEecUGbXx == -1384519260) {
        for (int DcyrNi = 1214275600; DcyrNi > 0; DcyrNi--) {
            HYGLEecUGbXx = HYGLEecUGbXx;
            HYGLEecUGbXx = HYGLEecUGbXx;
        }
    }

    return true;
}

XGSKctS::XGSKctS()
{
    this->IDjplbNAgnNQkMZ(-273359.3166050867, string("ERnxiRqjpFMZFCIqqiwxazMCOTOxILAyeLfYvRUslKHvBzVoGhVGrnrhTMHVepMxdVxVZqYNatQlbZZfiGVNSZJBXKBVLtXYmuhAKVJrZkMNBMUjMvINxuQOOcKezsodWPcOXleFIsFOIytFPDYdJyzmBy"));
    this->DYshnihBa(-1051276500, 318656807);
    this->zxhfCC(1807447056);
    this->eBxqMZy(string("JDFPvdLaZLgGCQrrvEtGXXZGSvhiewbJSPxZlAMbiamCrRLEtpOHnfBqcJaSedVtEiQLWmXaXKmXfjsIRZspSMOkgaQKrXRdslaFnIegWwhQXCTCekmmqnUEYHqYEWoAjDMpzPHTYJPCOlZveevCKGzZFwCExZaaTSkgHQUuJGgznSbobXyRVoVqeszulxlxOCPreuvzuVRmkUDRDCyAaeGRMFVdnZCthcikiWdjJpFZSnYVibBXqVjVpXeb"));
    this->qsOYYTwJJGT(2137642087, 1434108075, string("ykbBfjlMLQhYkwxCPLTwYBJYHmtKQjxAYDLbpLkWbUXAJKfLdcNtpoVZqfLfhmzCWLGycXimrRgttdBQXLzzfxSZGluIpqQMnGWnsbAcazXZOXXAUwCucykEcZRWtlQrvWLDhmYmQveEhtOQfPWnzrijZQrjthLSUQIYYiBeczOaDLT"));
    this->ECaFIaZlKy(true, 772286.8962712471, string("NqDdkPokVjKgPMiJeeJDpvLBNsrrYjbwNRSGGpQVLwsNfeIpAyw"));
    this->VDSEedpxIdHn(string("YzowoAgSIfHUFCXcHKkEXwaPIZXMyfNvNwKxqBMVPZfNDjizSLIHwRJfTklzACwhyLZuSPJHvuwtRSdtnmKsyRWBvZXrmAAEoUnZCjFcNmSpyAdQYzyiMwKFYUjDiCllDPpogy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QnOhvwcsAcZ
{
public:
    bool TjvKfFiPCfL;
    int yitEgpwtdOxTrOr;
    int gXTcms;
    int GBFkgCznKY;

    QnOhvwcsAcZ();
    void nCZBp(int tjAdsFeUGXCMpmP, bool EtmDzMcQLFUAwr, int vRmSFdanzSrKQQZN, int IhYuLI, bool frRzNIAr);
protected:
    double MMDKhud;

    void FlEkAznr(string snMtKGk, string SyKhcVjswQK, string KMLbfEvCgw);
    bool XvvmbAdiXoke(bool AptQIOpQtgwQghz, bool ujnXkAYjPTthEhI, string PWbCSz, int bKcPa, string CAqgXf);
    bool dIioHPtoYwukK(double ScqFjNtEYrJ, string vNsQP, double quJjvEM);
    void ktdFi(int TcHoFrmEg, bool ILlMFvRZUP, bool qSnVIPIhdCWguCgH, double DSoFGRdoqOjunu, bool tkEmWnuOWSPcNdq);
private:
    double oxPHemIYjz;
    int wsaDGv;
    double cOzbkKCAtCOFC;
    double jedUNFhIR;
    string QvjJPemsacoJhJ;
    int aHXOLrHkUIYBR;

    int yPkGLnGprDgEvB();
    int UOSaYXOwtrBAyJ(bool tLufNZqfxzItwEJY, double eVPudeqvHKNOxe);
};

void QnOhvwcsAcZ::nCZBp(int tjAdsFeUGXCMpmP, bool EtmDzMcQLFUAwr, int vRmSFdanzSrKQQZN, int IhYuLI, bool frRzNIAr)
{
    double kNkexJPDXeJxMXF = -1036054.5172053219;
    string UWxkYuTlO = string("fzHIGjGVKbMItoVGIyTxZygMGRPEKWJhctvxCAfmdMKcfcumEZIGRAepkYejKnKlDhVXsXBevaKKKdvxQUbtvfTOWPOKQytPOiaqU");
    double DectXvvp = -507389.315045106;
    string RaOJLhEkaOyAp = string("DwhmRLrlijGRBDKUyvqfWP");
    bool kmnDFcwuIu = true;
    string qxkVddPOYvQdB = string("BkSERgYywnZFhgboDEKDEWKRrQXnOHMlkuUkFFwHKRzwZmVlLDkciNssAHrvslfbgscwICqOheqEvFzfHkCpIcJJWNNqCIPZCnjkyorkMLkiqfXszsfzbPAXjOZmcTeQwhblkgEgIrsHkBjhtcwzWiiGUPyuVOWHvFxnQDYotBKANCWtAJjnFCXhNVZVqwtGXREXGkfCEWNynApgjRMzirYgJfLleDU");

    if (vRmSFdanzSrKQQZN >= -968122334) {
        for (int hKAPIwh = 516271608; hKAPIwh > 0; hKAPIwh--) {
            qxkVddPOYvQdB = RaOJLhEkaOyAp;
        }
    }
}

void QnOhvwcsAcZ::FlEkAznr(string snMtKGk, string SyKhcVjswQK, string KMLbfEvCgw)
{
    bool uacaTUSfJybuiYD = true;
    string qfUiyuyf = string("uMkElmXFoZJHbYharRWjPJdXXCqYeIqJ");
    int XysOz = 2143301207;
    bool cJeDDEoWYuVHauFP = false;
    int prtDHpvZS = -1590794587;
    string BKXtGbSj = string("eEQoWmgHjLXcOcfrjKoztlrwHYiPKKJidiFNUlIBpggRboFjpmusIGJzfhcJuDwfvYJfGspqpUGCDoGNDBWVHYxkYZkyByOVPDaQcdHnmZAOXizVkBwTHjNKdNQUCSSCHpoKNUPCGnwxnjnPrWwmnrNatufDqKhCWnzynMSTWcwEZdViGKOAZWvuMpjoUADFzXjWgUVVKsaIwerNw");
    bool YkjNycFKibGYUv = false;

    if (qfUiyuyf == string("pHdsVaLisLbGsIxwmDYNPTLJnClgjcSDlWxDNySNSiuykalOpDTVatyHDWlumxyjjLlTFmqXeNXqMAZhPwurhMlAVjwCJckBAUqjfGFCsDMQhrTTuuaBaXwfOThxhSEFGVXnSHUMLYeGueVdozpNiiVLZpoAtvGjMAqDqojnxKlykFieABxDYLBYEbFWyxvwSwHxAiQHoxAfiZTISjdmzcFrjFqzgxRtAPXsmhPgAxgscISCjRAcznmmNL")) {
        for (int xgNrtc = 898571678; xgNrtc > 0; xgNrtc--) {
            SyKhcVjswQK += snMtKGk;
            qfUiyuyf = qfUiyuyf;
            BKXtGbSj = KMLbfEvCgw;
            BKXtGbSj += SyKhcVjswQK;
        }
    }

    if (uacaTUSfJybuiYD == false) {
        for (int dyEll = 115291269; dyEll > 0; dyEll--) {
            qfUiyuyf = KMLbfEvCgw;
            YkjNycFKibGYUv = YkjNycFKibGYUv;
        }
    }

    for (int RWqNLzYLKDREr = 359091424; RWqNLzYLKDREr > 0; RWqNLzYLKDREr--) {
        continue;
    }

    if (snMtKGk >= string("eEQoWmgHjLXcOcfrjKoztlrwHYiPKKJidiFNUlIBpggRboFjpmusIGJzfhcJuDwfvYJfGspqpUGCDoGNDBWVHYxkYZkyByOVPDaQcdHnmZAOXizVkBwTHjNKdNQUCSSCHpoKNUPCGnwxnjnPrWwmnrNatufDqKhCWnzynMSTWcwEZdViGKOAZWvuMpjoUADFzXjWgUVVKsaIwerNw")) {
        for (int XXTJVrXEiACLIt = 563867874; XXTJVrXEiACLIt > 0; XXTJVrXEiACLIt--) {
            BKXtGbSj = KMLbfEvCgw;
            BKXtGbSj += snMtKGk;
            prtDHpvZS /= prtDHpvZS;
        }
    }
}

bool QnOhvwcsAcZ::XvvmbAdiXoke(bool AptQIOpQtgwQghz, bool ujnXkAYjPTthEhI, string PWbCSz, int bKcPa, string CAqgXf)
{
    string ajltUcmyhx = string("biQAmkOMTcRpJhROvzaDCLEUZjMopHKAwebaTszyXuMMScUFBfzLUPAwHOhRLpCmdCROigpdPRyPCaVSTodDdcuDOiKJnSURPqzPCuVRLkTJfUtreMtyhULMuBVTHgEfQNGEkenJBrOsYANZTiEWznWJWaIOuFOhCQvjpQSGMhLUKZKUEQSTyzciqXLytMowsKcgwodaUkuoIhkGSQGDGfqNxiExFJSwQSSsgzvZXDqHNJrPkthVgAeBX");
    string VFSKyzSgmd = string("FzIVlRnoiizYKNZpztaLjdgbkzUcNpRwvneMcDdUe");
    bool FFrhvQjUKgB = false;
    string CQAfBELhpCurH = string("WfdcoSCQUgYqcuwMhxKLcNtdrJUPrScnFGZCcWlypVPbGFylsyihwBeKazLMGRUIZLpMoRygTZquIqhNunNPpmBhWILtejPDgcuNbrGUznNYstRDUrZpLUbZiszCjTppKtBzFLEGLUxLKJcJMpCOTmqBGYZXagFnZDhohUD");
    bool naHYDFf = true;

    for (int tZDupD = 2025378846; tZDupD > 0; tZDupD--) {
        FFrhvQjUKgB = FFrhvQjUKgB;
    }

    return naHYDFf;
}

bool QnOhvwcsAcZ::dIioHPtoYwukK(double ScqFjNtEYrJ, string vNsQP, double quJjvEM)
{
    bool MwxrKDDwkJXnLEIk = false;

    if (ScqFjNtEYrJ <= -6247.244519505236) {
        for (int cTHGsLDmekdtOQAd = 2127284105; cTHGsLDmekdtOQAd > 0; cTHGsLDmekdtOQAd--) {
            vNsQP += vNsQP;
            quJjvEM = quJjvEM;
        }
    }

    for (int wLjQs = 1807288679; wLjQs > 0; wLjQs--) {
        MwxrKDDwkJXnLEIk = ! MwxrKDDwkJXnLEIk;
        ScqFjNtEYrJ -= ScqFjNtEYrJ;
    }

    if (MwxrKDDwkJXnLEIk == false) {
        for (int ftDOE = 947657581; ftDOE > 0; ftDOE--) {
            vNsQP = vNsQP;
            ScqFjNtEYrJ *= quJjvEM;
            ScqFjNtEYrJ *= ScqFjNtEYrJ;
        }
    }

    if (quJjvEM != 564461.3017671211) {
        for (int mcNwaX = 536985618; mcNwaX > 0; mcNwaX--) {
            vNsQP = vNsQP;
            ScqFjNtEYrJ += ScqFjNtEYrJ;
            ScqFjNtEYrJ /= ScqFjNtEYrJ;
            vNsQP += vNsQP;
            quJjvEM *= ScqFjNtEYrJ;
            vNsQP = vNsQP;
        }
    }

    return MwxrKDDwkJXnLEIk;
}

void QnOhvwcsAcZ::ktdFi(int TcHoFrmEg, bool ILlMFvRZUP, bool qSnVIPIhdCWguCgH, double DSoFGRdoqOjunu, bool tkEmWnuOWSPcNdq)
{
    double CsYxZ = 450086.3235905946;
    bool ClngKSPtiBiLNIvk = false;
    double qsgKXQyfnXipp = -242819.9418038961;

    for (int BUquj = 1080613035; BUquj > 0; BUquj--) {
        ILlMFvRZUP = ILlMFvRZUP;
        qSnVIPIhdCWguCgH = ILlMFvRZUP;
    }

    if (DSoFGRdoqOjunu <= 450086.3235905946) {
        for (int hiSmm = 1244377947; hiSmm > 0; hiSmm--) {
            tkEmWnuOWSPcNdq = ! tkEmWnuOWSPcNdq;
            qSnVIPIhdCWguCgH = qSnVIPIhdCWguCgH;
            DSoFGRdoqOjunu = CsYxZ;
            DSoFGRdoqOjunu += CsYxZ;
            DSoFGRdoqOjunu /= qsgKXQyfnXipp;
        }
    }
}

int QnOhvwcsAcZ::yPkGLnGprDgEvB()
{
    int dtlvDCzHfmxiZp = 410591639;
    string yJvdxUx = string("xXahIzKngTKOfKXfQQqNrfwKjANVHhMgqduVaBchdRsRvxAiRJWmaRZsPSoPyLroZWawKQEYylDHCgorPWbhSuZrQxnoAprRpdMNhUkjIOhPJKNlHskdQBtEZTnVYIKICWKeaVDZnaSCyRHdwUQKfqhtZwHwLFcvSUXWBvlSFRaZitrDqpoAqHSwRlXJNrZdYWzbldGmEJhnlXI");
    bool xGiHsHo = false;
    int JeDjfw = 146970973;
    double bHPgyeuQQ = 31744.522970580656;
    int cKFWgyDXW = -1121148571;
    string DddEwUcinEu = string("KDiZOrioOqnKZCRFiVCtryDGRRXQeicCWhptFjPyKukINBcssSOxbpfLNEamOwHIqRdFYVcFCwnYKpQXpZbQUraWgXuftrBAeQFgYyWVQlqzATLrFeFZaHRWmWMRhXLYRreiRNBTVkaeRqIsuvTLzNPboQhUnwOGgCwKAlDsbBUBGmKmyKaNOQlxfKAISJhOIJpacgqUqWaAVLksKiGVGJoJMoNXKdZSMZx");
    bool rVFxMlhsTEBPc = true;

    for (int UmfQRdxcUeyZTFj = 941394456; UmfQRdxcUeyZTFj > 0; UmfQRdxcUeyZTFj--) {
        xGiHsHo = xGiHsHo;
    }

    return cKFWgyDXW;
}

int QnOhvwcsAcZ::UOSaYXOwtrBAyJ(bool tLufNZqfxzItwEJY, double eVPudeqvHKNOxe)
{
    string PrNyaLPIU = string("AHFBEZTQPewUFzlTvjFJCPGgkRuKGtcPycnkLeaCJyvVBqPlTECTmZNPPcyyjyuxPhqAxhejvmTxRaLHeymTrRVdcHPBMqWzMLrVRMVtIzWoqBuqjzbWlwyDfUsnFksgitVVJWqViKQJjCXocfEhEMwFwfCCguNdRqJeRVnIjLKwMfeNBGHqpIGwBpEuLdQbiVuPexprXwFTwRLLJMMmmVnPjrlqtEfswPEMeTxCfSfIEp");
    bool ErRHgEKw = true;
    bool oAicOUpq = true;
    string cgtWVyhURboclZLy = string("bPzx");
    bool duOGiA = false;

    if (eVPudeqvHKNOxe < 901427.4628048344) {
        for (int TyQVUQTnENUCz = 1009233143; TyQVUQTnENUCz > 0; TyQVUQTnENUCz--) {
            eVPudeqvHKNOxe /= eVPudeqvHKNOxe;
            PrNyaLPIU = PrNyaLPIU;
        }
    }

    if (PrNyaLPIU != string("AHFBEZTQPewUFzlTvjFJCPGgkRuKGtcPycnkLeaCJyvVBqPlTECTmZNPPcyyjyuxPhqAxhejvmTxRaLHeymTrRVdcHPBMqWzMLrVRMVtIzWoqBuqjzbWlwyDfUsnFksgitVVJWqViKQJjCXocfEhEMwFwfCCguNdRqJeRVnIjLKwMfeNBGHqpIGwBpEuLdQbiVuPexprXwFTwRLLJMMmmVnPjrlqtEfswPEMeTxCfSfIEp")) {
        for (int eehfwV = 739581508; eehfwV > 0; eehfwV--) {
            duOGiA = duOGiA;
            ErRHgEKw = ! tLufNZqfxzItwEJY;
            tLufNZqfxzItwEJY = ! oAicOUpq;
            duOGiA = ! tLufNZqfxzItwEJY;
            oAicOUpq = ! oAicOUpq;
            PrNyaLPIU += cgtWVyhURboclZLy;
        }
    }

    for (int QVdFRw = 1826645433; QVdFRw > 0; QVdFRw--) {
        PrNyaLPIU = cgtWVyhURboclZLy;
        tLufNZqfxzItwEJY = ! ErRHgEKw;
        tLufNZqfxzItwEJY = ! oAicOUpq;
        duOGiA = tLufNZqfxzItwEJY;
        tLufNZqfxzItwEJY = duOGiA;
    }

    if (tLufNZqfxzItwEJY == false) {
        for (int JOMQDVydcehcJ = 815741126; JOMQDVydcehcJ > 0; JOMQDVydcehcJ--) {
            tLufNZqfxzItwEJY = ! tLufNZqfxzItwEJY;
            duOGiA = oAicOUpq;
        }
    }

    for (int vtaESmHmskX = 1344698781; vtaESmHmskX > 0; vtaESmHmskX--) {
        ErRHgEKw = ! oAicOUpq;
    }

    for (int jfXbptmUTV = 1723435998; jfXbptmUTV > 0; jfXbptmUTV--) {
        cgtWVyhURboclZLy += cgtWVyhURboclZLy;
        tLufNZqfxzItwEJY = ErRHgEKw;
        duOGiA = ! duOGiA;
    }

    return -371248132;
}

QnOhvwcsAcZ::QnOhvwcsAcZ()
{
    this->nCZBp(-968122334, false, -604068095, -800969411, true);
    this->FlEkAznr(string("pHdsVaLisLbGsIxwmDYNPTLJnClgjcSDlWxDNySNSiuykalOpDTVatyHDWlumxyjjLlTFmqXeNXqMAZhPwurhMlAVjwCJckBAUqjfGFCsDMQhrTTuuaBaXwfOThxhSEFGVXnSHUMLYeGueVdozpNiiVLZpoAtvGjMAqDqojnxKlykFieABxDYLBYEbFWyxvwSwHxAiQHoxAfiZTISjdmzcFrjFqzgxRtAPXsmhPgAxgscISCjRAcznmmNL"), string("nzIlufEPWKRyrbgOlHkLNqmZQWTBdaHnPeiGNrLtpEBiBKDBkzmuinZxiZQPpNekvvAsPLoutKacbAHPkmdFKzyJhIzJpngNbbtwYwssllXSWMEXvyIWNSfdzvUDIOdMPXmpuGUDQKQFUyydTHwFFcYpowiEFRjRzUlZplMovs"), string("CwLCgAduOdLoDtFirQiMy"));
    this->XvvmbAdiXoke(false, false, string("MCukKkRAntZkEuBMjqklBMZQNulVwGUAXqvTlPrOHmnLPdmwPeALKgjhWiYUgRAfIAdZDExisXCIpZcdwNFrkfhgUulFtOcKsvErECUqzCidFwvsUtfBxrZCvLQeClmsVDGUgMkcvTsXAfMcmJjxnMMYlbAmpQFnpTCLCxrfBWpC"), -473336245, string("BnmOlbqOqVIVqTkTSrvqqmOPPywIADojbUZRkZdHgtRoglVBWSFJMUTYMstrWJKiAHHHQHjoIdLvVwhZKTPsOqiPzruZxkHsqGQgMYCvDXODZqzDaxbBwdqIpPlekVxWjDHcDzufFoGOWipPhEMiuDcEDKdtJXnxCXDj"));
    this->dIioHPtoYwukK(-6247.244519505236, string("OtJwhfVkwyHGWzOpIolbyXvdjykROzkXCYESIvxaKDOjoGozXsrNERdbWfrVjfuUGDRFlfLrZUQBcftjBHsHqgSwEbajkIuFstDRVHfXUivMybvghrqVuKRAGbLyuKoMaiobdwtjcsqNqqQNfvBPnj"), 564461.3017671211);
    this->ktdFi(-253573921, false, false, 599410.4532285713, false);
    this->yPkGLnGprDgEvB();
    this->UOSaYXOwtrBAyJ(false, 901427.4628048344);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jlSXdiBoITRZXyk
{
public:
    int bSnpYVeyNQGHP;
    bool OQoMepM;

    jlSXdiBoITRZXyk();
protected:
    double rrDpMu;

    double rdSCDBxMq(bool PsYtpVSKZzp, string PZdnYPQdKZu, int ivOjM, string GdMoncCpYvNXDpf);
    string ImbeXL(bool pmppH, int RTRPTz);
    void JWcgEWfWCxAy(int FEcqBpFnWG, string rGLXwotdVrh, bool Uxkxwnc, bool JeAaS);
    bool RZGQLeSuIA(string orDVdSrajAwtkDc);
    string VmWlWLZ(double YLeiqSLIL, int kYnYsO, int WVAJU, string uwspqTHYJrBw);
private:
    string GKXwCm;
    double nTPLbsEeNjUmIH;
    double PaiVV;
    string kCXWkuLF;
    string wWPMS;
    double wFbtk;

    string wMfOYHTRDlV(bool IIcaWuSsjRoeeAdz);
    string CQvcgmQEGaebFQIO(bool ZyQAjedHkK);
    int XPGMllbtmlccU(double dmFsTzSdT, bool xAXScUHHDXUa, bool TUJqPa);
    int dSoWFgdoMQEtcRh(string jGYCPryyzpR, double ZESrpKZPGWBm, string NHFsADycAGtwpqS, bool CZBaPV, double gAJlVcsvgJxHlkm);
    double kjBKy(string kvTaW);
    bool poviSJNN(string FOpxTj, bool OoIJznFnTXlU);
    void kqklDZsIk(bool oCrjqigxKIYQa, int YzFVKvShJIBek);
    int zvaQh(int okwOfgSLtk, string pPYKiMt, string tscVuZcpRoZ, int qJfblsXPkXYd, bool MnmyotVlVai);
};

double jlSXdiBoITRZXyk::rdSCDBxMq(bool PsYtpVSKZzp, string PZdnYPQdKZu, int ivOjM, string GdMoncCpYvNXDpf)
{
    double xuQmGClY = 239674.69898730985;

    for (int QALykqrMQVy = 199803701; QALykqrMQVy > 0; QALykqrMQVy--) {
        GdMoncCpYvNXDpf += PZdnYPQdKZu;
    }

    for (int qEFPTNHZNYKtg = 359626314; qEFPTNHZNYKtg > 0; qEFPTNHZNYKtg--) {
        ivOjM *= ivOjM;
        GdMoncCpYvNXDpf = GdMoncCpYvNXDpf;
    }

    for (int sabfpfoEghAEv = 1856555067; sabfpfoEghAEv > 0; sabfpfoEghAEv--) {
        PZdnYPQdKZu = PZdnYPQdKZu;
        ivOjM /= ivOjM;
        PZdnYPQdKZu += PZdnYPQdKZu;
    }

    if (PsYtpVSKZzp == true) {
        for (int PzgoKXscfDM = 1110348446; PzgoKXscfDM > 0; PzgoKXscfDM--) {
            continue;
        }
    }

    return xuQmGClY;
}

string jlSXdiBoITRZXyk::ImbeXL(bool pmppH, int RTRPTz)
{
    bool SlcFjkoE = true;
    int rnVpetbWcQGhaoHS = 166590440;
    bool lPoXbK = false;
    bool SdnSvbAusKM = false;
    string lcSIxUo = string("bcAwknNbMwsHjIzjlzuyLjUZqwbUtnrrKpWNvzxTySDFjJUsIkEQpcElRZPgFZqlNMHeyZgvYffBxxmdKCZzwuospYvKqCftwCmYgWKgReNaCbWTMSKZevFrgLYjaRdfvuAbcuIGeHqtcevxCQItnTzJPhmCNodfqDFFgNUwiGtBXKEGOedeZFprFUnXfPVTdYdPyLOtcudepgffXHCYrszgwPvZqrzkZDONpmSRfkKIxWUdCBu");
    double XwmgglpCtz = -220651.5792792167;
    double CjNgYM = 1042155.6525517523;
    string FdAzLGcmsUlEDQJG = string("AVyDuBYitWeSiwVDaMZpinNDgdxFaFtSnWXNatqbBfATnStVIgvWFsRjwiWGGEuKzANXyQTsPOYPCCeeAItbvZXudKSqIyczncjsfhkCfkVlfKAPuDjcQKgeGXupUTpERfbrZqZUNqBajHMykRmHpvdqzMMfDfFsukcByjlGWbCYwZvbvgJYEdoMvNORddlpmmYzyJCzqXakohvxFqxqEkHDBoUIjjJmYcylPfAIyYrO");
    int TUqpreoZ = 1411899344;

    for (int PxHzBHBzzp = 1074889268; PxHzBHBzzp > 0; PxHzBHBzzp--) {
        continue;
    }

    return FdAzLGcmsUlEDQJG;
}

void jlSXdiBoITRZXyk::JWcgEWfWCxAy(int FEcqBpFnWG, string rGLXwotdVrh, bool Uxkxwnc, bool JeAaS)
{
    int pFrEy = -1599943456;
}

bool jlSXdiBoITRZXyk::RZGQLeSuIA(string orDVdSrajAwtkDc)
{
    double KMlcRHsJ = -217713.06972206553;
    int nHTbROhvJbZ = -515532925;
    bool hnYKjG = true;
    bool kffKJpWlmOAaV = true;
    double LuYbpsZg = -563346.0687100134;
    bool ycpfX = false;

    if (nHTbROhvJbZ != -515532925) {
        for (int VfowhkmlEjoBUsRW = 1946051420; VfowhkmlEjoBUsRW > 0; VfowhkmlEjoBUsRW--) {
            KMlcRHsJ *= KMlcRHsJ;
            LuYbpsZg *= LuYbpsZg;
        }
    }

    if (hnYKjG == true) {
        for (int nHwiOXioTHPyainR = 1327515588; nHwiOXioTHPyainR > 0; nHwiOXioTHPyainR--) {
            ycpfX = ! ycpfX;
        }
    }

    if (KMlcRHsJ < -563346.0687100134) {
        for (int IlVcUQvwmWt = 1405906517; IlVcUQvwmWt > 0; IlVcUQvwmWt--) {
            continue;
        }
    }

    for (int MBHpwo = 1951866493; MBHpwo > 0; MBHpwo--) {
        continue;
    }

    for (int RfQnHvHNsROo = 1563581897; RfQnHvHNsROo > 0; RfQnHvHNsROo--) {
        ycpfX = kffKJpWlmOAaV;
        ycpfX = ! ycpfX;
        KMlcRHsJ += KMlcRHsJ;
        hnYKjG = ! hnYKjG;
    }

    return ycpfX;
}

string jlSXdiBoITRZXyk::VmWlWLZ(double YLeiqSLIL, int kYnYsO, int WVAJU, string uwspqTHYJrBw)
{
    string jWWLlxdr = string("HjkqCROoCHyQXLqQvKSsbJAIaWyBCqYpqNxzxHccDxxHpLPgPtcQuTFxYraJXABgRVHGdNmNUzLfkXNArhUdggyUYsLJmHMdXWbVVAzJLlyZWrcEnCwjNfcydlZxAccStmKQdEOjwbuaLoanHZIMOVdybeuGTiV");
    int bUBqXRwfdloWWsXR = 280024965;
    double lFjIqQCEJAJXqp = -338135.362852279;
    double KlsNhW = -549068.6840384691;

    for (int WOUZgkxeAdOPcqNR = 1739589006; WOUZgkxeAdOPcqNR > 0; WOUZgkxeAdOPcqNR--) {
        WVAJU -= kYnYsO;
        uwspqTHYJrBw = uwspqTHYJrBw;
    }

    if (KlsNhW > -549068.6840384691) {
        for (int yIIGopYK = 599163754; yIIGopYK > 0; yIIGopYK--) {
            WVAJU -= WVAJU;
        }
    }

    return jWWLlxdr;
}

string jlSXdiBoITRZXyk::wMfOYHTRDlV(bool IIcaWuSsjRoeeAdz)
{
    bool UcoVrSpwpFA = true;
    int AfBHgEmgVi = -1619306019;
    int dkTNzcIejnTKFe = -395608106;
    bool umLxYRLsoOdfDrKi = true;
    int qUZeAH = -147739506;

    if (qUZeAH != -147739506) {
        for (int ptsSbhya = 443248030; ptsSbhya > 0; ptsSbhya--) {
            AfBHgEmgVi -= dkTNzcIejnTKFe;
        }
    }

    for (int wvppGD = 340565430; wvppGD > 0; wvppGD--) {
        continue;
    }

    return string("whYkgFPEmKdbuvQbjpnnQkpBpsftREHOgfrPmILMtFlVZtNOjVulWzeWTEPWwIANbjxqviWedGYOvfgVBBeXnKgPmpMkUpPalbjnIMZxxeZGrsiKipItiHqVfHfKLQJUteJRvaBpMn");
}

string jlSXdiBoITRZXyk::CQvcgmQEGaebFQIO(bool ZyQAjedHkK)
{
    int wEZWdnbxsnU = 88594172;
    string HikfTkcBmmcc = string("zjFlGCHKbqtAxfuHVYJPexuUhoLoCQOvfFQIMpmzEmAWmbOpxdSMGPoiSTnMBiWRBEsJfxEruCjGcgcajbifIbbn");
    int KSjmDwNAOWit = 2017084451;
    int siRAFzKD = 1381244929;
    bool oeMBDNnkRx = false;
    int UIhDwRUXkFG = -1171942178;
    string xRbyBdHnCO = string("KDPgBVeSuCwAaRCgGZjhjiCBFLNldrVrfpYZJtRGPqiRuBLpLQZ");

    for (int ubjUBdMZnwVATvu = 2117531729; ubjUBdMZnwVATvu > 0; ubjUBdMZnwVATvu--) {
        wEZWdnbxsnU += UIhDwRUXkFG;
        wEZWdnbxsnU = KSjmDwNAOWit;
        siRAFzKD *= KSjmDwNAOWit;
        UIhDwRUXkFG /= siRAFzKD;
    }

    for (int jWNOcKx = 1964039044; jWNOcKx > 0; jWNOcKx--) {
        wEZWdnbxsnU = siRAFzKD;
        wEZWdnbxsnU += UIhDwRUXkFG;
    }

    return xRbyBdHnCO;
}

int jlSXdiBoITRZXyk::XPGMllbtmlccU(double dmFsTzSdT, bool xAXScUHHDXUa, bool TUJqPa)
{
    double kDiVVkwwioMk = -718160.0570684507;
    bool thCsqnkTfuHYGV = false;

    for (int YqwExNAbEG = 1686766658; YqwExNAbEG > 0; YqwExNAbEG--) {
        xAXScUHHDXUa = xAXScUHHDXUa;
        dmFsTzSdT /= dmFsTzSdT;
        thCsqnkTfuHYGV = TUJqPa;
        TUJqPa = ! xAXScUHHDXUa;
        thCsqnkTfuHYGV = ! xAXScUHHDXUa;
        dmFsTzSdT /= dmFsTzSdT;
        kDiVVkwwioMk /= dmFsTzSdT;
        dmFsTzSdT *= dmFsTzSdT;
    }

    if (dmFsTzSdT <= -718160.0570684507) {
        for (int KkxiDVBFkgHGd = 869166463; KkxiDVBFkgHGd > 0; KkxiDVBFkgHGd--) {
            thCsqnkTfuHYGV = ! xAXScUHHDXUa;
            thCsqnkTfuHYGV = thCsqnkTfuHYGV;
            xAXScUHHDXUa = ! thCsqnkTfuHYGV;
            dmFsTzSdT -= kDiVVkwwioMk;
        }
    }

    return 1256509397;
}

int jlSXdiBoITRZXyk::dSoWFgdoMQEtcRh(string jGYCPryyzpR, double ZESrpKZPGWBm, string NHFsADycAGtwpqS, bool CZBaPV, double gAJlVcsvgJxHlkm)
{
    int VnGWaq = -2131225418;
    int pCXuH = 430819713;
    int iwNrZoNqsqutV = 977647575;
    string lYokYDEZpPavxKB = string("ZhvBAyXyqBjmOOjlHWQTRygdMBxGvLiTaebykvuBtwaqLaaHdIfeKGBbtBVgkwLtlcnAhbGbFsvAzKUzOmxnOxxISoZS");
    double RWyfXYAiCUaEKo = 219287.83936599107;
    bool pkigmvuJ = false;
    bool GSTjXzJVNnZ = false;

    return iwNrZoNqsqutV;
}

double jlSXdiBoITRZXyk::kjBKy(string kvTaW)
{
    bool vrGeqj = true;

    return -179035.48605997075;
}

bool jlSXdiBoITRZXyk::poviSJNN(string FOpxTj, bool OoIJznFnTXlU)
{
    string USNXlybY = string("ZSNimrTfsHmRyygqfVvuFCzQZiAxYdIvPginrSfOjWYiRwnZPWpdtfhOljflUPobyqnKrQRNpWpGgnefJcBlPTwKOhIvnDzyqxfujIpZjPPufJBkVzfKmLeiVjneyJDnvMrTCRDruSxUENIKmUENyh");

    if (FOpxTj >= string("ZSNimrTfsHmRyygqfVvuFCzQZiAxYdIvPginrSfOjWYiRwnZPWpdtfhOljflUPobyqnKrQRNpWpGgnefJcBlPTwKOhIvnDzyqxfujIpZjPPufJBkVzfKmLeiVjneyJDnvMrTCRDruSxUENIKmUENyh")) {
        for (int HFgemExlmmrnG = 552545663; HFgemExlmmrnG > 0; HFgemExlmmrnG--) {
            USNXlybY = USNXlybY;
            OoIJznFnTXlU = OoIJznFnTXlU;
            USNXlybY = FOpxTj;
            OoIJznFnTXlU = OoIJznFnTXlU;
        }
    }

    if (FOpxTj == string("ZSNimrTfsHmRyygqfVvuFCzQZiAxYdIvPginrSfOjWYiRwnZPWpdtfhOljflUPobyqnKrQRNpWpGgnefJcBlPTwKOhIvnDzyqxfujIpZjPPufJBkVzfKmLeiVjneyJDnvMrTCRDruSxUENIKmUENyh")) {
        for (int cneJPDynzGvbja = 1790138575; cneJPDynzGvbja > 0; cneJPDynzGvbja--) {
            FOpxTj = FOpxTj;
            USNXlybY += FOpxTj;
            FOpxTj += FOpxTj;
        }
    }

    if (USNXlybY >= string("AjtLvBvjuctutZKzaYefnpPPTsopuuVgzcXIaIYPpJCdiqmYmPVkOfdxsU")) {
        for (int nqQUuar = 164332066; nqQUuar > 0; nqQUuar--) {
            USNXlybY += USNXlybY;
        }
    }

    if (USNXlybY > string("AjtLvBvjuctutZKzaYefnpPPTsopuuVgzcXIaIYPpJCdiqmYmPVkOfdxsU")) {
        for (int RFnBjicFcgeOKu = 381349979; RFnBjicFcgeOKu > 0; RFnBjicFcgeOKu--) {
            FOpxTj = USNXlybY;
            USNXlybY = FOpxTj;
            FOpxTj += USNXlybY;
            FOpxTj += FOpxTj;
            OoIJznFnTXlU = ! OoIJznFnTXlU;
        }
    }

    if (OoIJznFnTXlU != true) {
        for (int OHjPuZqSJfBArOP = 1856083973; OHjPuZqSJfBArOP > 0; OHjPuZqSJfBArOP--) {
            FOpxTj = FOpxTj;
            OoIJznFnTXlU = OoIJznFnTXlU;
        }
    }

    return OoIJznFnTXlU;
}

void jlSXdiBoITRZXyk::kqklDZsIk(bool oCrjqigxKIYQa, int YzFVKvShJIBek)
{
    double wJquJKoImyXan = 86584.36607046696;
    string ZISqUDqXONXQhY = string("KlODwtWFRTxWfSEqRWIKuFItpwuHfcuinjceEThaMrIqVprjmhpFXkufdfBxWpDqJFGAbVXJSjinOJmdiwJBZrbsLqBkgAJvfaNGFPBxfKqnpzQpEzfhjeIeDCTlyGwquGFNLeFwJYNayCiey");
    bool NCTQtND = false;
    int qKHFKzBAXXGUD = 347421862;
    string ILppdCO = string("cWMgMfFCmvVczozMcxhMCKjToBjxNWmnnfZUBrNexCfXjrUTbQNqbUDdiFTktDtIKFhxCtYgQkOtzHZvAYtDIOPXDAjLOXyPCEVViibjJozPioHGJPBgSUzRWWtKYPixNvkublVtuJZcUBFPoNKxoqQglDgIZVYYXhkOXZDfAxMBobolBGLpiYdNrUVAOEOvfJKRmmiCyJxBKcmGOdpPqbBYhscBZHLF");
    bool DzuxNuePfFPJ = false;
    double pOEpWydvIXIaJywc = -872987.9976511742;
    string iFxxwaQALlwZuCw = string("qPbWsxRsavPopMnMImIDUdPweSDoHKcKaWAIIyTuTNRuzaizFtwAxAGJziUWYUUZFoFItYqVIpTrzBNlEmzHBuBuSoUslcRYSZNdfkGybzdkMKjtBuaYovbHwzuOGuEqjDbCCHPIzDPyYGEbWtVxDzFXlJehWWnXePhABbhCqfunWkaoDHvvXPxODXOfiNYhldZThXRNkjqgjMEmxEDJZZxJHtadloAgHucfypPmrS");
    int HKuDYbHThAVYu = -301785097;
    int ecVsmSTtlWG = -507222074;

    if (DzuxNuePfFPJ != false) {
        for (int HjDxiCsNoseY = 2000826356; HjDxiCsNoseY > 0; HjDxiCsNoseY--) {
            ZISqUDqXONXQhY += ZISqUDqXONXQhY;
            iFxxwaQALlwZuCw += ZISqUDqXONXQhY;
        }
    }

    for (int SZkYgFuaHlw = 1626323152; SZkYgFuaHlw > 0; SZkYgFuaHlw--) {
        ZISqUDqXONXQhY = iFxxwaQALlwZuCw;
    }

    for (int NfFymZ = 112797994; NfFymZ > 0; NfFymZ--) {
        ILppdCO = iFxxwaQALlwZuCw;
        qKHFKzBAXXGUD *= YzFVKvShJIBek;
    }
}

int jlSXdiBoITRZXyk::zvaQh(int okwOfgSLtk, string pPYKiMt, string tscVuZcpRoZ, int qJfblsXPkXYd, bool MnmyotVlVai)
{
    string RqVDBb = string("BqalfconxWtjvGuTmNRawGFC");
    string MGTMldVdzXBoOa = string("QMtJiNDczXEvOOCVkQFYurWzXPuBRQtawAjvrFmTFFFblyyETWSwRHfLGVfDtdOLxKGhWTcDPVhxWwzXnoYMBHfTDNUdfoWsJWxFGtmBQSiUNrgmdmtMFXFJnGjCuUyfDPRayQPuUaRQdCbqcDdd");
    double JbkYvkFDrr = 1031838.6539426496;
    string BTApnDvjABfdwxwH = string("bxLryzZORHnKbjSgpfkpfKnuZWuDARKdzrQpeAtVUawtAWcgHKutnFSGeneVuTHiUcBlgzwfvKDfuwXRkmCdAPXIVmizfsUgJdLFELXqVCUWDduLVeSqPOlteWywMuwNBMNozrKFdqHnmLtoqFRDGfJgkcVeQZ");
    string UWFmMAKUPgwTd = string("HLfjbZrWdaoDhnVAbtiwiOrqoTRgtoCgMUpINnRfzKNikOfROLYefVZn");
    int tTCGPTFwVYEqeSLU = 1193924969;
    int qAZbP = 1964418441;

    for (int PrKdTDoMYc = 1590340904; PrKdTDoMYc > 0; PrKdTDoMYc--) {
        tscVuZcpRoZ = RqVDBb;
        tscVuZcpRoZ += tscVuZcpRoZ;
        RqVDBb += BTApnDvjABfdwxwH;
    }

    for (int wirjoa = 709672827; wirjoa > 0; wirjoa--) {
        continue;
    }

    for (int eMjTiVZJkjai = 2051481759; eMjTiVZJkjai > 0; eMjTiVZJkjai--) {
        MGTMldVdzXBoOa = RqVDBb;
        tscVuZcpRoZ += UWFmMAKUPgwTd;
        MGTMldVdzXBoOa = tscVuZcpRoZ;
    }

    for (int xCxBYErxnLO = 1968073660; xCxBYErxnLO > 0; xCxBYErxnLO--) {
        qJfblsXPkXYd /= okwOfgSLtk;
    }

    return qAZbP;
}

jlSXdiBoITRZXyk::jlSXdiBoITRZXyk()
{
    this->rdSCDBxMq(true, string("uzaewjzqtugQSTYjajMoOvRXVRnqdSUFleqAdwYLZPqrfATzdGFeUuSWpiLrBUaqhPZGqKRDLBfBVQfsLWDoHkvdsuOOXynlDOJPYxUQbNnLyTaIryJJQGFCWRIcZnNiAYsGArVNvnKbKiwDSVXFkmvJFRRWqSUVYtVYwLXqiAusJcVIWxAPKLjqfgwPJzbnUveDOPtcqwJKEALJYTuWHmrtadtyqMObDzaRiabGMnoGquhwCHvAWDGAYNjf"), 122328621, string("JosBgEZdkPwoggJOz"));
    this->ImbeXL(true, 1192076927);
    this->JWcgEWfWCxAy(-1778386436, string("EuoXBKzoroysyNLJndaWXEQQtfmQFXMgEWbTZEk"), true, false);
    this->RZGQLeSuIA(string("VCsxlbygLmJwzlUUSZCHaGFqZYzbubuNImNZbdcRvXAjKlizjlwwXTDUYUcwaAMVmzTF"));
    this->VmWlWLZ(-263692.59778494627, -1802506379, 582678198, string("hYSglzcCwFZwOTqCPtnWApvKSxJVQfdamUwONGjXVCOBiBCZLMTwVhJMASmrcwcIRmnIhBsNXJSfDtfvC"));
    this->wMfOYHTRDlV(true);
    this->CQvcgmQEGaebFQIO(false);
    this->XPGMllbtmlccU(722240.4862090864, false, true);
    this->dSoWFgdoMQEtcRh(string("uXuYYFnNBdAxBKLqIKFseJulZvqtMoOxtYzxpjMogktoFgwDSXvWHanJlELRZiPOaLKpatKPV"), -829893.0629073116, string("ewhMlrzFuOoSfCKADsDZAyPcGknDTQuSwZiJSyDJtDLhZmBkAmPLGkmXyOeioRrgQaziwUNvMnHwpTclGxAeslINzXrtSosflYcOzbJQsuogPMlYBBSwvEiYDMrdOKroZfPRtVbWlVjiFagSbDftwYQOMCrpljEdzPOnbbXcigYfsOyWcCLXADkftroszTOddYGGJkbUaNnSGqzzuDFLaZDiSnIhvMYuadNyNBBYkK"), false, 48157.3523520746);
    this->kjBKy(string("bNZyuXI"));
    this->poviSJNN(string("AjtLvBvjuctutZKzaYefnpPPTsopuuVgzcXIaIYPpJCdiqmYmPVkOfdxsU"), true);
    this->kqklDZsIk(false, 1858440014);
    this->zvaQh(-191888010, string("UdFgFPgiThplJnTeTvmagNcZzRhBCXQyeIXUxPaeWeUWDmrhxSGVJAxjGVCZhkdKPTUJdCjJaIxdLXTVQFtXjrSfxTxOSdPJFfoFTYWzhKfUeTJiTcETHIeIcveINHiqmmuoqHTagaaGFrzNpjCxErMFmTWIoklDejvWVkGPDCHlmPDFxGzEJzPAPqrpmLqRBPMHxEWHYvbtaCWJeYcfNjxPzItifNzGpRbaoYeBtwhENojlZwryzfF"), string("SSHkfrnGxIJCabiuuVbjsMhuodUUAEdvTzcFVhepJLkcY"), -1671409950, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uJzLEcepD
{
public:
    double WSHiZNtAf;
    double JQZThMkFEHEoFs;
    int wIgGnxxoud;
    bool qyGZqViWgppW;
    bool KjpyaV;
    double KRsbHCf;

    uJzLEcepD();
protected:
    double KHbSWqWjVr;
    int dDyuahmPCgXqDE;
    string gGfpGMYCrRek;
    int PzhaL;
    bool pdbGVUBuASw;

    int RheoHwnYZlKiupS(int gfhckZvJB, double tjQlFrOrIxE);
    bool BzxncpnLCjWnZ();
    string mzyQPmnu();
private:
    double ySqtz;
    bool LlrcyJN;
    string oXEHUKbECIWr;
    bool YqvhbROB;

    void InrfomEnQpHNsL(string EiOPTHyQVumk, int RpsOBklJFGvO);
};

int uJzLEcepD::RheoHwnYZlKiupS(int gfhckZvJB, double tjQlFrOrIxE)
{
    double yrNZSkH = 595499.0790184883;
    string UrbiwUSmXDppM = string("QzxeabsxUKSKAxpPyoDMz");
    bool VTuubTjXyXrg = false;
    double gMfeQntFKdgYb = -65617.00421195904;

    for (int ZkteGunrBTEO = 217781797; ZkteGunrBTEO > 0; ZkteGunrBTEO--) {
        gMfeQntFKdgYb -= tjQlFrOrIxE;
        yrNZSkH *= tjQlFrOrIxE;
    }

    for (int LGUOneNRaewtxDl = 1513418629; LGUOneNRaewtxDl > 0; LGUOneNRaewtxDl--) {
        gMfeQntFKdgYb += gMfeQntFKdgYb;
        yrNZSkH *= tjQlFrOrIxE;
        gMfeQntFKdgYb += tjQlFrOrIxE;
        tjQlFrOrIxE += gMfeQntFKdgYb;
        UrbiwUSmXDppM = UrbiwUSmXDppM;
    }

    return gfhckZvJB;
}

bool uJzLEcepD::BzxncpnLCjWnZ()
{
    int AOuPCyN = 605121390;
    string CwEosnLhCuOcehL = string("rssnTgvPGtNSlFjNPQmXhirnPIxzQWIlDchonpwCwElsyUjFAuMYb");
    string IYWtAbFqYHXfUXFm = string("PtooFevqMbuyIQUHkCtmULrwWuBrNKJbaoBPLSKLPhVupDglyaVlRAAUFvZrugsLivZyvbQudHgAxoXwSEtROWWGuhMvsFQyKWjvOLOIDVjjrAEinEuwqQOCuERWGzBkruzNREPaXavKFZDPafGLyHuxalNxHrmlTSeSeihDZlZgvXGGmUZIbpAacQHsHaezWcuudyvPRVEpWrMalmPvycn");
    string PUXDPbbFOhQ = string("xconmviZDJKRxyIaPmKltcQOzHMVdYlDgzeZtjmhxbaMGMvjQcrSIhRJjGpEpRuAysSAWvtYlwuAevDrgtSQEAcGFsVodsNwaPXopemrNvmkIyoufEntSuMolWXnEDahguLiALmmAaYnOANJuhapKQOIZgQjmCriKGQvWLNnTumHfYwOxYaoJeSjMkVm");
    double wjaqXmrnbMC = 289872.9467521789;
    int AXqvYbFSOWf = 185606024;
    double UsWiYtQfevtIb = 98462.51877048258;
    int znJzYhjtYVrFEEAE = -10872370;
    double oyoFvMPAxAPgJOO = -810460.0671657365;
    bool SUqGtWNoOujOgBO = false;

    for (int pRJMe = 1756595862; pRJMe > 0; pRJMe--) {
        continue;
    }

    for (int OTMoeRbgZ = 9083301; OTMoeRbgZ > 0; OTMoeRbgZ--) {
        wjaqXmrnbMC += oyoFvMPAxAPgJOO;
        IYWtAbFqYHXfUXFm += PUXDPbbFOhQ;
        znJzYhjtYVrFEEAE -= AXqvYbFSOWf;
    }

    for (int ISXRY = 401433117; ISXRY > 0; ISXRY--) {
        UsWiYtQfevtIb -= UsWiYtQfevtIb;
    }

    return SUqGtWNoOujOgBO;
}

string uJzLEcepD::mzyQPmnu()
{
    bool djWZOgdN = true;
    bool hroirMoQOvZXOA = true;
    int JbDwZKHDgWZ = -897444523;
    string HLdcagHolim = string("vKZOpwiHtQGmdeUchjARwGwEUaGKwljjYADRxqeLSGEu");
    bool NoKcvnnesvt = true;
    string IVHSYuldV = string("GVbfCbbAGwgJcFJyhmiKQoAeDfRDSiHacsYfRauSzebVdRnVwrLYPtRslDdGgftukvXrAmetLKgSnAZBxXkACUTZAReDyNvvjjMrrAACqqLVXEJsneCMPojPZVlIxPjWxGNNQzKfXrAlmeEjkIsDFovJzInRYnikLHQqDDejkVpcEzRBCvZZBXGXCMd");
    double bBXzdxBgfp = 306458.68098924693;

    for (int kexiq = 805709290; kexiq > 0; kexiq--) {
        djWZOgdN = hroirMoQOvZXOA;
        HLdcagHolim = HLdcagHolim;
        hroirMoQOvZXOA = hroirMoQOvZXOA;
        NoKcvnnesvt = ! djWZOgdN;
    }

    for (int xhaKlvLYBhEvfQT = 1196969583; xhaKlvLYBhEvfQT > 0; xhaKlvLYBhEvfQT--) {
        HLdcagHolim += HLdcagHolim;
        NoKcvnnesvt = ! hroirMoQOvZXOA;
        JbDwZKHDgWZ -= JbDwZKHDgWZ;
    }

    if (djWZOgdN == true) {
        for (int cfaxJBVwBeq = 465294926; cfaxJBVwBeq > 0; cfaxJBVwBeq--) {
            IVHSYuldV += IVHSYuldV;
            NoKcvnnesvt = NoKcvnnesvt;
            djWZOgdN = ! hroirMoQOvZXOA;
        }
    }

    if (JbDwZKHDgWZ <= -897444523) {
        for (int FtpUO = 2058261539; FtpUO > 0; FtpUO--) {
            NoKcvnnesvt = hroirMoQOvZXOA;
            IVHSYuldV += IVHSYuldV;
        }
    }

    return IVHSYuldV;
}

void uJzLEcepD::InrfomEnQpHNsL(string EiOPTHyQVumk, int RpsOBklJFGvO)
{
    string XaSbhI = string("DALBIsQJusztJ");
    double BjVOOSEsvmSAZO = 967337.5297618338;
    string sRgAIQ = string("YwNBpffoQXQBXymUdpfCOrQgQmDiTlgVSauCKKawExZEtIFYnZHqhtGKWQxSWPrHxqDqZtxyDcjQuTXpbDDERuRJzrRHcrDPZzwRRbFplHqFGCvGuHowZdclXfeuyAMMmzLdiSLWfAQWZORuCsaXxNeQKzjgpBULxsTqMFfTpVESAkCEGRhclNSWAWmdjGPVVcVHbwagMCHLVtDKQPrFadHkmCCHikmzWJjBbcxLe");
    int YohTJaJh = -355414795;
    int RlPwTwjR = -139662767;
    bool PjRQn = false;
    string VRfmlZAtKDFMd = string("VBKrAnVYcCPzaIovRiSfIEjXdcHWUxEYXyDTNQaTXhoGhc");
    double yxwkBCQpVDj = -693182.1526033139;
    double yLMOxSrThHG = 228991.78343296202;

    for (int JBCoZTPMYHnhkLq = 184932454; JBCoZTPMYHnhkLq > 0; JBCoZTPMYHnhkLq--) {
        PjRQn = PjRQn;
        RlPwTwjR += RlPwTwjR;
        BjVOOSEsvmSAZO /= BjVOOSEsvmSAZO;
    }
}

uJzLEcepD::uJzLEcepD()
{
    this->RheoHwnYZlKiupS(-45378133, 830030.9649209866);
    this->BzxncpnLCjWnZ();
    this->mzyQPmnu();
    this->InrfomEnQpHNsL(string("oUUNsmtTkJWeytOSfAsQKWsJpezwFWECHyrjAcNVUhyjSuyEkEOSksvjGLplesEzcGHcpMPTSmgfPvSzkspEdTFcdjbkSZZqAMAVPYatKhbIQMXEEWPIAQoxaMonUQaLHTI"), 314072456);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eREEhZROfAj
{
public:
    bool kKwFfxW;
    bool DTlpXgUxVBzOo;
    bool lbllzSZQDrPwGHs;
    double fdxdNCFREmygN;
    bool GeUcTnrpFzFn;

    eREEhZROfAj();
    int pbhCuTNXpxmFb();
    int wkCuWAHu(bool RVIjyNJ);
    void wXvYai(bool XWwZsInotaHynKG, string kRiyEtYhKqE, int gokvTH, string BTLzMllzyxczj);
    double UrwpkvYc();
    string nXYMPpTVl(double ZGIKjkPpQWeWEtXq, int GyDOSSbt, int TpBhGTHjE, string lsKaGQbsh);
    bool XKuhOMlB(string kcfHUzya, string WxKNyhCAomhkfoa, string skBUfNZ, bool LiIpHVMAjxff);
    string YHRXQPG(double FFJwAijGzFyPq, string MgfDOsLnpTqR, string wweVjRuxHwGJqQvD, string nhAym, double ssxbZbHvc);
    bool tsFRaNOKBy(bool dhgPLL);
protected:
    bool GTWsoVPgY;

    bool GtLRWwjGR();
    int gqDMtssIb(string VTjfmVPcKZYSCMua, bool HRyQOTQYRqCdbday, double HdUYHhn);
    double KlEnArzJjTYRJv(int HEusMB, int tJAekRWHZmbbduW, string UqiUz, double dWbTuVDyGPkw);
    int yqoiLWolAuykt(int cthIUZGBMbPN, bool TNQHnXxIbhAtugGg, double gzidInBcbLq, int qbOjTAkNoYGiPzB);
    string PBapqwvgqkUBvrWa(bool firtkQ, string ewGwC, double CHhlJWtEQuQvUun);
    int aciBpHtMb(bool paWjWuUtIjb, bool tQdmlUHFUULXnBl);
    void hrVYPEsHVWNz(string DVawgjn);
    double LAotYeruCs(bool rKdvItahgGFpLH, string WfMNtBupmvmDLv);
private:
    string mCUViwaWjRFM;
    string uXwmPUWfBtM;
    bool EfiZh;
    bool lncsuxJ;
    int RkApAiLnMhXo;
    string fzGAdPLFy;

    void rOgACYLEsOrJqjb(bool LnaZsnT, bool kzogTAPlLWsFRCM, bool WmiBVLNnLuVdSED, double kRbFVVqSIwLOzwp);
    void ytJPxJu(bool TEylRZM, double YwhGNulwvI, bool AdfkRERwvTUFn);
    double agKHhjEQWI(int BOmaxiy, double CTnbGjbH, string qZoCgMzuM);
};

int eREEhZROfAj::pbhCuTNXpxmFb()
{
    double oavZBUYVu = 429780.4920500189;
    double aHVWoUvjwIdbkev = -202851.13582980886;
    double WpNSqgkOmX = -452243.58588230883;

    if (aHVWoUvjwIdbkev < -202851.13582980886) {
        for (int HyMFubu = 1195985197; HyMFubu > 0; HyMFubu--) {
            aHVWoUvjwIdbkev += aHVWoUvjwIdbkev;
            aHVWoUvjwIdbkev -= oavZBUYVu;
            aHVWoUvjwIdbkev *= aHVWoUvjwIdbkev;
            oavZBUYVu /= aHVWoUvjwIdbkev;
            aHVWoUvjwIdbkev += WpNSqgkOmX;
        }
    }

    if (oavZBUYVu != -202851.13582980886) {
        for (int WCPRQjhnTspy = 1505353528; WCPRQjhnTspy > 0; WCPRQjhnTspy--) {
            aHVWoUvjwIdbkev += WpNSqgkOmX;
            oavZBUYVu = oavZBUYVu;
            oavZBUYVu *= oavZBUYVu;
            WpNSqgkOmX *= oavZBUYVu;
        }
    }

    if (aHVWoUvjwIdbkev >= -452243.58588230883) {
        for (int OUTwHYu = 1925443788; OUTwHYu > 0; OUTwHYu--) {
            oavZBUYVu += aHVWoUvjwIdbkev;
            aHVWoUvjwIdbkev *= aHVWoUvjwIdbkev;
            WpNSqgkOmX /= WpNSqgkOmX;
            aHVWoUvjwIdbkev += WpNSqgkOmX;
            oavZBUYVu -= WpNSqgkOmX;
            aHVWoUvjwIdbkev *= aHVWoUvjwIdbkev;
            oavZBUYVu += aHVWoUvjwIdbkev;
        }
    }

    return 1244288494;
}

int eREEhZROfAj::wkCuWAHu(bool RVIjyNJ)
{
    string XWFIbHJrgmigIwJ = string("IEvmhEfOIsLOuAjftPyipCKnRVjNapqJuLuxgGNCJwHXMgdsAEInYftagvcZoZtNifA");

    for (int yjFZwcDHrCsqm = 337277813; yjFZwcDHrCsqm > 0; yjFZwcDHrCsqm--) {
        XWFIbHJrgmigIwJ = XWFIbHJrgmigIwJ;
        XWFIbHJrgmigIwJ += XWFIbHJrgmigIwJ;
        RVIjyNJ = RVIjyNJ;
    }

    for (int ArJyieLpHoDeGOgL = 1759639574; ArJyieLpHoDeGOgL > 0; ArJyieLpHoDeGOgL--) {
        XWFIbHJrgmigIwJ += XWFIbHJrgmigIwJ;
        RVIjyNJ = ! RVIjyNJ;
    }

    for (int UoGycejFaA = 346023491; UoGycejFaA > 0; UoGycejFaA--) {
        XWFIbHJrgmigIwJ += XWFIbHJrgmigIwJ;
        XWFIbHJrgmigIwJ = XWFIbHJrgmigIwJ;
        RVIjyNJ = RVIjyNJ;
        XWFIbHJrgmigIwJ += XWFIbHJrgmigIwJ;
        RVIjyNJ = ! RVIjyNJ;
    }

    if (XWFIbHJrgmigIwJ > string("IEvmhEfOIsLOuAjftPyipCKnRVjNapqJuLuxgGNCJwHXMgdsAEInYftagvcZoZtNifA")) {
        for (int MOjuXykntrgp = 196474258; MOjuXykntrgp > 0; MOjuXykntrgp--) {
            XWFIbHJrgmigIwJ += XWFIbHJrgmigIwJ;
        }
    }

    for (int THBlcjdGmWRVsAtN = 227894727; THBlcjdGmWRVsAtN > 0; THBlcjdGmWRVsAtN--) {
        continue;
    }

    if (XWFIbHJrgmigIwJ != string("IEvmhEfOIsLOuAjftPyipCKnRVjNapqJuLuxgGNCJwHXMgdsAEInYftagvcZoZtNifA")) {
        for (int MjZqe = 558679394; MjZqe > 0; MjZqe--) {
            RVIjyNJ = RVIjyNJ;
        }
    }

    return -181532777;
}

void eREEhZROfAj::wXvYai(bool XWwZsInotaHynKG, string kRiyEtYhKqE, int gokvTH, string BTLzMllzyxczj)
{
    double rqMyUPEHR = -466296.3673548609;
    bool AcMGhDMpZETv = false;
    int AeSWb = -2087668395;
    int MBcPgTOrW = 1411410257;
    string xiMnNAcova = string("MnJryFyCmWdQcvhspdddpvAqItKFmqoxNKvoZCSfHGIUgHEZDZOnecPzSxqwXpVUpPrOlbYfTbhEvjttqvGdgigmCiC");
    double FtAtBOZ = -886632.4660355091;
    int WmhiPspvodbemxLd = -864431828;
    int ZXKDKdxyuQQxglOz = 369151707;
    int PTiQIvf = 1738146061;
    int jIpyTdXw = 119218177;
}

double eREEhZROfAj::UrwpkvYc()
{
    string eYHzZMokQEjk = string("bnSoDzClWWhlBorjSPqMHTGuYGTQyRvzJOdXgybROPDadaTzxrIRLVuYBsdwugrcIMJarTGnOFivbtIwcpwQagqrHHmySKVNdLyRLUkYjPqhuPcUvBFSYnZmXthcDuoctnzWFDVeIxvMARXomXWELsMSHgSI");
    int EMTMmRcysMRCRra = 1486318867;
    bool ePsGChc = true;
    int FkjzQylUKHRcj = 513482271;
    int gYmvXuYBDz = -359675681;
    double pWylpIHZQAIjQwq = -168341.40165272108;
    bool NZnixgg = false;
    bool gRSqua = true;
    bool uZPMHVNUHX = false;

    for (int DiIxR = 780524579; DiIxR > 0; DiIxR--) {
        ePsGChc = ! gRSqua;
        ePsGChc = ! uZPMHVNUHX;
        ePsGChc = ! NZnixgg;
    }

    if (gYmvXuYBDz <= 1486318867) {
        for (int SSvNR = 1807391653; SSvNR > 0; SSvNR--) {
            NZnixgg = ePsGChc;
            EMTMmRcysMRCRra -= gYmvXuYBDz;
            pWylpIHZQAIjQwq += pWylpIHZQAIjQwq;
        }
    }

    return pWylpIHZQAIjQwq;
}

string eREEhZROfAj::nXYMPpTVl(double ZGIKjkPpQWeWEtXq, int GyDOSSbt, int TpBhGTHjE, string lsKaGQbsh)
{
    string qyugRAbqe = string("cmEqTmgXlArUclMFdrBiSRzyMCyWViPxJfWhNxXbGJjWpMrDbINdtHgOMKzFuCRcQwhOVnrGlqpGYqvTTUKDGqEhrSpwRfsGadCpRvLvxvQETddpdkewhUADATFSFjKNWzfLmtEOUeJDQfGScEcbyWlyLuZtyZHnZeJoEtWUSjLBnwTaeyUEmtGkHeeeyZBtnGAqUVRRPBGXAgAqeZdePmx");
    string NCTiXtzgPqHO = string("DlxmLVnbmlHmzfAuerCF");
    double eXgkBfnPcCRIbre = -189506.72487559507;
    string zeIngreTxVxZ = string("pzoiBjuiPjQVlkdhXXGfLFZrihJrzunBkvzuPYrsgDfJwVVTxRPAwTFVCVplWRaRObyPryBqLPZYbAymyFszDCXkDUVkvflZjTqHmluYVAaKLnijQplXOqIFpqwifQTjocEGBYczFMjKRQcWnPnXOGZBsUADnBmqNmSFdFouFaqrWfPDJF");

    for (int HmKKFsoWLTJNDZa = 1971865541; HmKKFsoWLTJNDZa > 0; HmKKFsoWLTJNDZa--) {
        zeIngreTxVxZ = lsKaGQbsh;
    }

    return zeIngreTxVxZ;
}

bool eREEhZROfAj::XKuhOMlB(string kcfHUzya, string WxKNyhCAomhkfoa, string skBUfNZ, bool LiIpHVMAjxff)
{
    bool IfkxqDJeruVtUY = false;
    string DaZHeCdoSRg = string("iFdiwolXqAXNOFPSLPEESOYNtjOhKbEIIPcUxitIMwjossroGxgpXfqJXEdGIuRjwopMeMYuPzdblqmvEDgKVXgELdbvpykhFYiNFKsaXzncJMeBxIdLYAgrXjhdYxVpufLiaxQZcgsLv");
    bool CbUqSmaLrO = false;
    string WjkzV = string("SRcDbrb");

    for (int exmWbjCrCC = 2047404561; exmWbjCrCC > 0; exmWbjCrCC--) {
        WjkzV += WjkzV;
        skBUfNZ += kcfHUzya;
        CbUqSmaLrO = IfkxqDJeruVtUY;
    }

    if (DaZHeCdoSRg <= string("pljRZxXXqgQUYftUYLYHxjZbwCDsfkvasNBqksNrSkvvMrVQSlkEPMksiHlMNJdzBJTfNZvoEemKrQODZGGoPrQWTLVwQjTtNKJRgRSmoJMjFrfEqpbGjnMfrWsnvnJuXvlOTuWJMHKqULbjuhVCMMZiEJccHubUk")) {
        for (int tMmtFZRGyMD = 22737498; tMmtFZRGyMD > 0; tMmtFZRGyMD--) {
            LiIpHVMAjxff = ! CbUqSmaLrO;
            DaZHeCdoSRg += WxKNyhCAomhkfoa;
            LiIpHVMAjxff = ! LiIpHVMAjxff;
        }
    }

    for (int evjaqfuzg = 369759182; evjaqfuzg > 0; evjaqfuzg--) {
        WjkzV = WjkzV;
    }

    return CbUqSmaLrO;
}

string eREEhZROfAj::YHRXQPG(double FFJwAijGzFyPq, string MgfDOsLnpTqR, string wweVjRuxHwGJqQvD, string nhAym, double ssxbZbHvc)
{
    bool xZkaxaYaeGzKzD = true;
    int schHmNDkYmCStztM = -1902878155;
    double fPFMsZgGvsJkiNnA = 167799.34780178012;
    string avkWDcobQY = string("gUKdiwIfEfGJmestrtjeKBkpDfdjStyWgketDJvaHDFXyYoVYAuPWTqOgFLtDayWSmmgvPgPodoWudWBiruysPhsXkViaSRdOHXvqiuCQrXszshPupEgsmUZbdiSPqwP");
    bool fvfhfWZVKmqwSEyG = true;

    for (int TVsvnLWIZXLnc = 705442378; TVsvnLWIZXLnc > 0; TVsvnLWIZXLnc--) {
        wweVjRuxHwGJqQvD = avkWDcobQY;
    }

    for (int HuCPBzID = 1353937519; HuCPBzID > 0; HuCPBzID--) {
        xZkaxaYaeGzKzD = ! xZkaxaYaeGzKzD;
        nhAym += wweVjRuxHwGJqQvD;
    }

    return avkWDcobQY;
}

bool eREEhZROfAj::tsFRaNOKBy(bool dhgPLL)
{
    string yGcwuASMJW = string("FVFNcDcTiMAQWfnDUrTBrfQAAUJMzMRVMvVHCinbvyegFEWZOsNAQqujjANsKffqnPoJeqzEPtsfXNVIQdKApLJBaLRFEBknZAdkcZzRaiUmdnfgbRYQkxSMXVtEG");
    double ntlcohrgyxE = -1013070.6803084495;
    int VFpDcPLrHC = -880276628;
    double LQJLuQXKJCM = -365990.9177864298;
    int GOtTMTZkGEIMuy = -1634256688;

    for (int ZWfZwn = 1399351041; ZWfZwn > 0; ZWfZwn--) {
        VFpDcPLrHC += GOtTMTZkGEIMuy;
    }

    return dhgPLL;
}

bool eREEhZROfAj::GtLRWwjGR()
{
    bool PNLxeJlJWJcd = false;
    string qmxoM = string("wsMogCFQlLywUqWMLKdAHeQHwEDZJEMkVDcHnHoTyoXZsvlcxuaTVdktGeCCPiQeapfXuZhRzdrIsOpTpTKPhsIZOBwpJGTPhypBscntgPduXbGiaJSpGXSOebOdwYBpCYUSwUaoRvDTjYYTGLQPrQdCQshozhJjkiiUNbOjKDGagltOUQkKVetnfKAjZuWqYUmshVFFFuFmOTeOgSwlwBkat");
    int OBremg = 1585693301;
    int SVcFjGlCxwrSRd = 195246564;
    bool yESklUShYFQa = false;
    bool zguOfTjZOWPaZmKl = false;
    int ruMpffzFqfhg = 1917617500;
    int WVqEOtmZGv = 1335301998;
    int DnYOpYQ = -1572959420;

    for (int IiXrtktOkt = 495360688; IiXrtktOkt > 0; IiXrtktOkt--) {
        DnYOpYQ *= DnYOpYQ;
        zguOfTjZOWPaZmKl = zguOfTjZOWPaZmKl;
        DnYOpYQ += WVqEOtmZGv;
        ruMpffzFqfhg *= DnYOpYQ;
    }

    if (PNLxeJlJWJcd != false) {
        for (int GeTKRuhINBP = 677217274; GeTKRuhINBP > 0; GeTKRuhINBP--) {
            WVqEOtmZGv /= DnYOpYQ;
            OBremg += DnYOpYQ;
        }
    }

    for (int MYORhgGrU = 1271224348; MYORhgGrU > 0; MYORhgGrU--) {
        DnYOpYQ += DnYOpYQ;
        ruMpffzFqfhg += SVcFjGlCxwrSRd;
        WVqEOtmZGv = WVqEOtmZGv;
        DnYOpYQ *= ruMpffzFqfhg;
    }

    return zguOfTjZOWPaZmKl;
}

int eREEhZROfAj::gqDMtssIb(string VTjfmVPcKZYSCMua, bool HRyQOTQYRqCdbday, double HdUYHhn)
{
    double IwAWPVZcHWxGZy = -699472.0000474335;
    bool mmWNL = false;
    double ATmVMiDwfyu = 10237.533032893569;
    int KVVVwuHUwDjjS = 1433085233;
    double cjCJWnS = -621480.7606737326;
    string cKoewO = string("OGdXpRBuJJSmmRPnGzAgkjZeikFfGGlaghYLHPeNHSTTZqOgMLeCYNHUgrVHMVDqSAPKnSvzmZSddkpqZYKaDnqzhzpfajVCmyVbRbFDXs");

    for (int bIagwQhzkqm = 127431464; bIagwQhzkqm > 0; bIagwQhzkqm--) {
        continue;
    }

    return KVVVwuHUwDjjS;
}

double eREEhZROfAj::KlEnArzJjTYRJv(int HEusMB, int tJAekRWHZmbbduW, string UqiUz, double dWbTuVDyGPkw)
{
    bool xPYuvQqiII = true;
    bool ZvCloc = false;
    bool QCkSMn = false;
    int XolSGMXkEgnfI = 1889853633;
    string IGlfLDf = string("IKcPkHFilwmKEjcsKRRAQlMzFhYKwwTkafHSTjgAXxcPSCmCRMqgnrrhsqpKkckKjjkNDqwBKWoSoQEoacYQlYDteAQcwSTJbSTNuYDsQzkSMNCxAtgEtimtkHEREBCFvcXTMTJkDrNXPuVfEqdhPdwfIfaXxemhjMcgIqxvWsQycVfMWRAMimboVpxQVEuDyqTCenHtgFRSqljIzoDtkMeu");
    bool DwBEfZu = false;
    double AFYGpxqNqKPnqCcq = 668642.5301417266;
    string mHUDNXfyXKMCA = string("fjHJFkbPVOfNPfyJFwGVmCVupQkPDTNyzxZxTCjicyWmQHtPezvdAXfWBaazgRvBYYCEVhzlBqhIfrnSyYAilfUSxOMvMmrDMqKCfOTTpJNCFqNCUyyZGbNBryIsMVDEUoZCvoXuMXJkuxWoQUXoIQFC");
    bool ZtMYsfxFGsGerx = false;

    if (AFYGpxqNqKPnqCcq == 668642.5301417266) {
        for (int ZvjUnZJtoscd = 836377481; ZvjUnZJtoscd > 0; ZvjUnZJtoscd--) {
            ZvCloc = ! xPYuvQqiII;
        }
    }

    for (int lYtxEnXLEryCWnR = 2115878989; lYtxEnXLEryCWnR > 0; lYtxEnXLEryCWnR--) {
        continue;
    }

    for (int dATOsEnH = 89997656; dATOsEnH > 0; dATOsEnH--) {
        ZtMYsfxFGsGerx = ! xPYuvQqiII;
        ZtMYsfxFGsGerx = ! xPYuvQqiII;
        AFYGpxqNqKPnqCcq /= dWbTuVDyGPkw;
        xPYuvQqiII = ZtMYsfxFGsGerx;
        HEusMB -= tJAekRWHZmbbduW;
    }

    return AFYGpxqNqKPnqCcq;
}

int eREEhZROfAj::yqoiLWolAuykt(int cthIUZGBMbPN, bool TNQHnXxIbhAtugGg, double gzidInBcbLq, int qbOjTAkNoYGiPzB)
{
    double PZZzTaWpEJPpa = 861477.0836627767;
    int jBpFCIRidlg = -31002026;
    double OuuMBiwaTJ = -248898.81590039245;
    double FbQeDOBFVKSH = -151694.27637304383;
    double NUKQxHtLiSZzbjj = 305069.4063668821;
    string TSpeGrqJzgTkFwt = string("muSsXLBwFZkhivCZlMxIKlsjEUlguuZsiBIEPemoABvnhTkRpWBXINarMqCOQjTZuFthbFNSRfYeMOYPdxLBSknlEjqExlZzSmxTIhWyq");
    double pqDiM = 215929.4340728634;
    double ZBZOewSaXCT = 372625.2389996069;
    string LkRyl = string("dVQdtDplTgjoQAUbvXXxjceyUOGQtCLBDzzeOanIzhCFuDOswkPzrTOmMUdyOVcxCVXrdPvxCPmakVBUcUNFHsUKtjGDcILYnUvIJzcoZXSlugOxnagzcTeQuGfbjZgYXorxHnEUSXUnxysZlsprwKGNCySRcQfUelxjbbfxEWwcXjdwFIQRfoqZQkdJKegFIlngBbtdIyyMIWGbiImQsCalRfbIxwXjvkNWxdq");

    if (qbOjTAkNoYGiPzB >= -752393943) {
        for (int GidRYF = 663743742; GidRYF > 0; GidRYF--) {
            continue;
        }
    }

    for (int scmYYPsF = 2100339012; scmYYPsF > 0; scmYYPsF--) {
        PZZzTaWpEJPpa *= OuuMBiwaTJ;
        LkRyl += TSpeGrqJzgTkFwt;
        pqDiM *= PZZzTaWpEJPpa;
        qbOjTAkNoYGiPzB *= jBpFCIRidlg;
    }

    for (int pKOwCCRp = 774163283; pKOwCCRp > 0; pKOwCCRp--) {
        gzidInBcbLq += gzidInBcbLq;
        gzidInBcbLq = FbQeDOBFVKSH;
        FbQeDOBFVKSH = pqDiM;
        cthIUZGBMbPN += cthIUZGBMbPN;
        qbOjTAkNoYGiPzB += jBpFCIRidlg;
    }

    for (int jGJgJZN = 1598270839; jGJgJZN > 0; jGJgJZN--) {
        FbQeDOBFVKSH += pqDiM;
        OuuMBiwaTJ += OuuMBiwaTJ;
    }

    if (ZBZOewSaXCT > 372625.2389996069) {
        for (int AgPYqWqpyQXfp = 876614304; AgPYqWqpyQXfp > 0; AgPYqWqpyQXfp--) {
            OuuMBiwaTJ *= PZZzTaWpEJPpa;
            NUKQxHtLiSZzbjj /= ZBZOewSaXCT;
            ZBZOewSaXCT /= gzidInBcbLq;
            ZBZOewSaXCT = ZBZOewSaXCT;
            OuuMBiwaTJ -= pqDiM;
        }
    }

    for (int vDKNsbWXyzEjqV = 1787087789; vDKNsbWXyzEjqV > 0; vDKNsbWXyzEjqV--) {
        OuuMBiwaTJ += OuuMBiwaTJ;
    }

    return jBpFCIRidlg;
}

string eREEhZROfAj::PBapqwvgqkUBvrWa(bool firtkQ, string ewGwC, double CHhlJWtEQuQvUun)
{
    double jNNmACm = -326735.0755633119;
    int CUwwNfEe = 1893121987;
    double LlQQhFRze = -347343.8623753277;

    if (LlQQhFRze >= -347343.8623753277) {
        for (int gawfGrn = 782316345; gawfGrn > 0; gawfGrn--) {
            CHhlJWtEQuQvUun *= jNNmACm;
            LlQQhFRze /= LlQQhFRze;
            jNNmACm = CHhlJWtEQuQvUun;
        }
    }

    return ewGwC;
}

int eREEhZROfAj::aciBpHtMb(bool paWjWuUtIjb, bool tQdmlUHFUULXnBl)
{
    double cbXHjxRotJFMmTY = 491112.0063019519;
    double NZosrtfHrMqR = 332334.3229137137;
    string GYdXzQ = string("OGDuSqhAsjoEYLgUHTySjgPABbVSJSipFSRlDwezGMvnZVwOXqslBybXzBTDxIJTpYxMjqWETkiQlGeNivmVGwjoVSGheIjobHaFxRCRkwLPkbIDRwZKSAkqdsbZEivVKqCefGyjrLLLskBOFiqOq");
    bool pJJUmaX = false;
    string paIPiWMTrgkyyT = string("abDRHZMEDYiieQherKAEqPlACmWeeJbEIemEdsASKqaOthDoIfsGqutAZtBmyIVLwXmWSKagtFAfrgaaoKSCfyBIYRaAjCiPMAMFZuXPLglomBujowHncdMiSefnrdqHCwvVoAQQnZDQtYAEbcmhWrjKQzyCRBJrhuEKdBzMZVzwPdAoJVQEKjICoTDisQLXiEyeNfYQUcDkashZbmkrIXjxZkscdlBrLNzQTyHsEYeFaoHgHJaRdWsiEAohHq");
    int HZksGQppcpnlKH = 2110213049;
    int fmWBROWP = -664054793;
    string BdNuBQRDKJhSg = string("XJPHeIjYtseOJYvCuNyUsVnnLQRulngdkopRVrYQUDAtEPnvDpcjmXcZupEtSFPVBV");
    int GQDNWLk = -1545770658;
    int EGTbSdpYXXTcSuc = 1208884431;

    return EGTbSdpYXXTcSuc;
}

void eREEhZROfAj::hrVYPEsHVWNz(string DVawgjn)
{
    double LTJZA = -503345.11278199434;
    double mVJXQHYjoTMfEKb = 558881.5320369976;
    string TPUlibWpVBcD = string("OPxXwnhOTLCtqovxITYVWyqtAVLrkblpfSnPDFTfgsvmzlLAAyHfdxbSWGyPskIlGWADIctzRZadptZENfKoYmbGHQFvmSJudrhUHSLKuUOjrjbsjcxtpJniqmxsBKkPOJdvSlzOwtXMmPnkBYcNDGzTpzkgOECsQmLlucUMleirYrYokRDabkdgcsgrgnOQYOlxhYTPnaTyhUvnKNUr");
    bool CAyzEXrXOpUG = false;
    bool LNSyzdomXXYFTGf = false;
    double aHcYKrLHpxbdODh = -811849.2187629434;
    bool NEHwiQSFcFeQW = true;
    string zHuvtDd = string("izEblfiTJCPUWkzaDdtDUOBNUxxAKXxITYryTgrsXRfhClrcOPxxuHWYOsKLbOuCVJDWNwnkhIpoNLTaQKSMftuAZxuDwpdDFhVEDuxxJUrzVlpgIZDLRUzPtiwslPmtHzVWrsENNYFuJYMbqBPClBrMutGJGcLjA");
}

double eREEhZROfAj::LAotYeruCs(bool rKdvItahgGFpLH, string WfMNtBupmvmDLv)
{
    double MiaKgrSazxckgYF = 535809.8555060619;
    string NSRxWdoygGeKbTH = string("JBDuMmnkZpbmaqP");
    bool iJJrrDUf = true;
    double gheDL = 501779.03978059354;
    double iccvMAHxolNzwez = 671226.1818637176;

    if (NSRxWdoygGeKbTH < string("JBDuMmnkZpbmaqP")) {
        for (int omsfRdhDmYTpV = 535290977; omsfRdhDmYTpV > 0; omsfRdhDmYTpV--) {
            iccvMAHxolNzwez *= MiaKgrSazxckgYF;
            NSRxWdoygGeKbTH += NSRxWdoygGeKbTH;
        }
    }

    for (int hwsHbTPuYGVqeBJ = 741848726; hwsHbTPuYGVqeBJ > 0; hwsHbTPuYGVqeBJ--) {
        continue;
    }

    if (iccvMAHxolNzwez != 501779.03978059354) {
        for (int YVdaH = 1907913316; YVdaH > 0; YVdaH--) {
            gheDL /= gheDL;
        }
    }

    for (int XcTUScRzfAyhA = 470241480; XcTUScRzfAyhA > 0; XcTUScRzfAyhA--) {
        NSRxWdoygGeKbTH = WfMNtBupmvmDLv;
        NSRxWdoygGeKbTH = NSRxWdoygGeKbTH;
        NSRxWdoygGeKbTH = NSRxWdoygGeKbTH;
        MiaKgrSazxckgYF = gheDL;
        iJJrrDUf = ! rKdvItahgGFpLH;
        iccvMAHxolNzwez *= iccvMAHxolNzwez;
    }

    if (MiaKgrSazxckgYF != 671226.1818637176) {
        for (int jsSaNQLoUPFMMY = 1466896095; jsSaNQLoUPFMMY > 0; jsSaNQLoUPFMMY--) {
            WfMNtBupmvmDLv += WfMNtBupmvmDLv;
            NSRxWdoygGeKbTH = WfMNtBupmvmDLv;
            MiaKgrSazxckgYF -= iccvMAHxolNzwez;
            iccvMAHxolNzwez *= gheDL;
        }
    }

    return iccvMAHxolNzwez;
}

void eREEhZROfAj::rOgACYLEsOrJqjb(bool LnaZsnT, bool kzogTAPlLWsFRCM, bool WmiBVLNnLuVdSED, double kRbFVVqSIwLOzwp)
{
    string JPmTUpQDe = string("JUCU");
    double CvXQLxFeOSJcj = -454748.06688271725;
    bool LFody = false;
    string qNxRWBCVmtkQbbIQ = string("uITWyhaqhJmAGiQkVwbvpGDKlprmhHxLDRbNrJnTmVoJVpqSMYLKvVGVejlsTDXnrMNlcMAwkYYDjKhQwFXtmtaCZqkSYzYXIWecgFsHshPXvmxON");
    string jhyadQCVcHLQCo = string("QMiUOJRrwwyUvCPZhkgYUmTLEXRDCPpHTJmTJlAHrRKPAkkIXhoOlEiEuYagdIOoqVZYvhgBihVMPZAxrZZGoxYdTBiUglNgDztifWdNcOeCDLWDPAqltYEgAdRFPEqidWMBSMpMhvpDtKlrzGGWoJMpYZHXigXCQZOvBoIurewMJNhNWtiDrUVkcrbAzSXojruoffJOmkTDZdiut");
    int hYWsVtHVFhWJTp = 788163779;
    int lfxZAXKDXEuAhMNX = -217678436;
    string fIzpac = string("OOBJpdTjnfEEHJjRwHeSnxAkTvymXtWtoqGqfeQOUljhfsYwLVoomeTGsomvRbLdIfLPjMrDnKywIQxWAoCmKOdOgFOtlKmRNbTnsxNHWhSgFuhsVPixgtblfCEmaNeOKFpGlDzlHfzzJqfCxhaMJzleaqgFqvDtaQhXUGsxjwgkOLGhCRygdAJyfXpIUvyoCSVQamSTfdkgAUMNVorjseStyqWLSVazlpzbOShqivYlk");
    string IJRGJ = string("RXkUurCiRqqfresXWuiUqoARGSyQrbLtudhPgdYRHebfoZZqvrRWHLXqSZntUjBqfeXZBWciOPhobnMRYblXDxzuVRRiNe");
    bool mgQyGSsVuTGTJ = true;

    if (WmiBVLNnLuVdSED == true) {
        for (int VwvfcNjeABhnncxL = 1610978838; VwvfcNjeABhnncxL > 0; VwvfcNjeABhnncxL--) {
            WmiBVLNnLuVdSED = ! kzogTAPlLWsFRCM;
        }
    }

    for (int pxXguDgJwYocV = 503327343; pxXguDgJwYocV > 0; pxXguDgJwYocV--) {
        LnaZsnT = ! LnaZsnT;
        qNxRWBCVmtkQbbIQ = IJRGJ;
        hYWsVtHVFhWJTp *= hYWsVtHVFhWJTp;
    }

    if (LnaZsnT != true) {
        for (int dJXCzhLUEuEOBkJn = 1399819045; dJXCzhLUEuEOBkJn > 0; dJXCzhLUEuEOBkJn--) {
            mgQyGSsVuTGTJ = ! LFody;
            qNxRWBCVmtkQbbIQ += qNxRWBCVmtkQbbIQ;
            CvXQLxFeOSJcj += CvXQLxFeOSJcj;
        }
    }

    for (int acZGOcEyEldRxkhJ = 1476514592; acZGOcEyEldRxkhJ > 0; acZGOcEyEldRxkhJ--) {
        continue;
    }

    for (int jwkGhcWWcYSns = 1587587964; jwkGhcWWcYSns > 0; jwkGhcWWcYSns--) {
        IJRGJ = qNxRWBCVmtkQbbIQ;
        WmiBVLNnLuVdSED = ! kzogTAPlLWsFRCM;
    }
}

void eREEhZROfAj::ytJPxJu(bool TEylRZM, double YwhGNulwvI, bool AdfkRERwvTUFn)
{
    string jjPMqClsRT = string("bAmRKNFbCMsOxrKsZiawMUawTNgTUVbdRQdRGjNTQTmEECfWmgjipqapDNpeklWLOtLohlLNtFSYKRCHzsQerhohAusNXMypnKBBhZDBcHfpu");

    for (int MvDDobuUtrj = 1893483877; MvDDobuUtrj > 0; MvDDobuUtrj--) {
        continue;
    }

    for (int bXmebwL = 1167783704; bXmebwL > 0; bXmebwL--) {
        AdfkRERwvTUFn = AdfkRERwvTUFn;
        YwhGNulwvI /= YwhGNulwvI;
        TEylRZM = ! TEylRZM;
    }
}

double eREEhZROfAj::agKHhjEQWI(int BOmaxiy, double CTnbGjbH, string qZoCgMzuM)
{
    string gLajaNofqARCHYMZ = string("dIZdKgphdszyLYpPmAMxRSpAwatDeEmYmtryagVFYNQuWFHmoQC");
    double vhTuNVHAdTaxq = -24194.11458693334;
    int XdzZPEZu = 211710262;
    bool WtweQDW = false;
    int HrbYs = -1935545526;
    bool GymgLiJS = true;

    return vhTuNVHAdTaxq;
}

eREEhZROfAj::eREEhZROfAj()
{
    this->pbhCuTNXpxmFb();
    this->wkCuWAHu(false);
    this->wXvYai(false, string("SICObqTpBZNjuhRsapJiVEPdAUGbjjTrSjHUzgzXLAZbDbpCYZmaehJiMfrfDvgaDJsEmDBPgPAZDsOSIvLUGgbiowYLMTXYSXCYnVpjFzfaJzuAJJZUuoNs"), 1562366816, string("SCQGeJXxTrToLDtlleABThcReayybIUoVOIURdJuW"));
    this->UrwpkvYc();
    this->nXYMPpTVl(36146.90184195728, 644218703, -1207241973, string("TzXGpHRtOzJcwnRX"));
    this->XKuhOMlB(string("wwycTKEAvJBdDBscudzmXjTjPRSalIcxhMiigOMqWNiFOnQdiMSfyjjJgpjm"), string("pljRZxXXqgQUYftUYLYHxjZbwCDsfkvasNBqksNrSkvvMrVQSlkEPMksiHlMNJdzBJTfNZvoEemKrQODZGGoPrQWTLVwQjTtNKJRgRSmoJMjFrfEqpbGjnMfrWsnvnJuXvlOTuWJMHKqULbjuhVCMMZiEJccHubUk"), string("llpuTOFJNLgYcokuaRFRWCcKrGyXQtbOMDMDFkdknMNkBeBllIeimnKgQyjwPUVjHCSHUoVnLrWxLdtHrWUVcMHvpZnpZkYsBNWuRQPNMFomAyCYzMDiTSOGruLoXUhlLhnQaUVpZXYhqNbHdatvBpIRSOVZmCXPBXeweDKdWAnpkWfUfLZVzKJZHSmVcWjwmIAgaJqJHcRVDhdfHeyocCRNpeZPmEpnlqynPeIFjzPcdRrQhEEZFPPaaDFvrb"), true);
    this->YHRXQPG(539659.8671771717, string("XxOBbWWFpqhDZgfzopDnpakwkMAvZzuI"), string("MRdcNWpSDmLFuGcEtxDfjzhjgkaTcJYOlKwpkVwQS"), string("LZVRlXCtCZcJdZOihdDKzrWNqDHFBzUujzdrhvGwpVzZAmmQ"), -920495.0133315697);
    this->tsFRaNOKBy(false);
    this->GtLRWwjGR();
    this->gqDMtssIb(string("bgCiBbSpcwlaheesbFVgTYsfykZckMulXbEjNGQdxFdwFRTvYZSdsmgPfpKXZSQOSIAnPyICEgwEVMIsojAcNUskGINqlXkwSGVCwavyaFZlCFxoSZPyQfdiYvuGhDSIJrASxsuanVWMOzJFCyJhPhTeCNkWUWrURCMvXMRngOMYNmYyDprYZcPzwAtcWzrsRYApzCe"), false, -708100.1285018336);
    this->KlEnArzJjTYRJv(-654245664, -677174872, string("IixVoYVCCzuDNEpeRUkGWEqrmNwxTbnxhEbjszwaCHG"), -475594.17745929095);
    this->yqoiLWolAuykt(-91827296, false, 600532.3942304298, -752393943);
    this->PBapqwvgqkUBvrWa(true, string("qqXbqOgSRQJdJNHaShAgBwgZEfEBmVBbMtIkbAmPCUWIbjzeGfmFpoIzBtoaGjhYZozZVgNTppJKqNjTNxaTndlQxdslfZQmWJxGHHZcePhHTeqoJDCYPqDbozhFapHlbAdPngGaOsKlNjahDVyIqCtAOjzZpr"), 319817.67946001);
    this->aciBpHtMb(true, true);
    this->hrVYPEsHVWNz(string("dbDSmRFUheztCfJPapYJXPygoWmHJYqwDHGWsggnwfjlBZWsNnkSqndeDUAagBBFLNiwhLMi"));
    this->LAotYeruCs(false, string("axPDDhXNoNfazLatKhAZkiBsvffwilOilJlTpQgFcqWQrEXVwBcrvwQSxKuSAPgXyCxwTcfyKtFHHBZqpwUSmedQjcjVogZnKDXDqJJGjmFSuyFQhkKrdushPfrHMGgaIANrnBiYlbndhcyoseoDaqdYxZhFOzaYgtYdIpcpOifOZJdjiRoj"));
    this->rOgACYLEsOrJqjb(true, false, true, -815116.5884401547);
    this->ytJPxJu(false, -902463.5097041233, false);
    this->agKHhjEQWI(1547958306, 264662.61222903064, string("WVcBTGOuKgnEYYDJKHfxVzFIDaXyfsfqyHfsYvKLPFdSNjyQmJRKdZEvpfIiecrkrpLYhVGUdACBdVOwvizksGuHkffJvYZifDWqcoJzFlSpLLWbtibOsxvuYIqEZzYnxf"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YmESkaMALHaAe
{
public:
    int cWFajTyDr;
    double hwyiqZsdZSvfgee;
    double OOxPfVkUMDB;
    int aRUEzcLtVNXuDfw;
    bool voCIW;
    double JDqAePBatBynE;

    YmESkaMALHaAe();
    string lkzmdRPPbwCli(int SPxbHzIQI);
    int gBfFMFJz();
    string LWlLVrgF(double TEexfJ, double ThoMxdEhgu, string SEhJvpywIF, string eodKEvUgrR, double fONJSdbEPHpaLo);
    int wJbsXOMtXVbEh(bool akKbLYoqLq, double zppZAUhGWIctKKqy);
    string kFJSow();
    string BEtnWrFy();
    string zxCQE(string PpnXxxRIS, bool ZjfguriqxJMbd, bool rGAYdZkpXMU, bool RSUzD);
    string wDRPIOHZ(string BWpNAi);
protected:
    int aKzzyqc;
    string DYFjdtss;
    string brVKMbIdWnflY;
    double wkkiVgetJno;

    double vPjLoe(string KtlpBdriMeJT, int cTtjdNsZqR);
private:
    double ESRaWuJIo;
    int ZHhribTYPNXJ;
    int gJFYIR;

};

string YmESkaMALHaAe::lkzmdRPPbwCli(int SPxbHzIQI)
{
    double vjrfOEtXTx = 506270.24252537376;
    bool eoIbrQRpAE = true;
    bool aHwJooEuBxvwzZhe = false;
    string ctRsvMukpns = string("HdYRypYaBXjnCpqtkHYjIGNhPoLHUDqDGzJXowBsbbOsVCETdjZalpLkTSCSrUvBgTjhpzSvhgxnZgEAPJHNsaalyBWjumVnhSgUOpTZCLEoRWtruWDoSaxsHAiQLPMmcXGGLIThWPjldVOARdJALrAfwU");
    int ZFsaymnWrFLMwg = -58605006;
    bool XvLzsHplIo = true;

    for (int aMwMWHuUYRMACdl = 751074058; aMwMWHuUYRMACdl > 0; aMwMWHuUYRMACdl--) {
        SPxbHzIQI -= ZFsaymnWrFLMwg;
        SPxbHzIQI += ZFsaymnWrFLMwg;
    }

    for (int lXpiFEDsvzBbz = 1201331153; lXpiFEDsvzBbz > 0; lXpiFEDsvzBbz--) {
        continue;
    }

    if (ZFsaymnWrFLMwg <= -58605006) {
        for (int YQnsVCkYiVqz = 1866202787; YQnsVCkYiVqz > 0; YQnsVCkYiVqz--) {
            vjrfOEtXTx /= vjrfOEtXTx;
        }
    }

    return ctRsvMukpns;
}

int YmESkaMALHaAe::gBfFMFJz()
{
    bool DLPGCQajvArdeMH = true;
    double eXcPwdtVcGgxzqMI = -1037135.6554587135;
    double MdcRzChEw = -428130.82252581615;
    double KVSCsoHuCx = -109689.0308022372;
    double gWbLpHZJRcT = -616891.7632346692;
    string GpMiG = string("PnxqMvzwHVmhIltnuxnmlfOVtMcUxOPfsFxUSxdLTjltvfpEEhexrlTBWQktvlvVefrMXDNXXWBoASwNkHXXzEjkZlcVikFqzGzgAXfHGMcWBigxAybhvkMoVPznNcrfCUWKDqFUVJeEfnVCmABPqAQ");
    double cfWvpCANVRaKEPWi = -127706.19872405645;

    if (cfWvpCANVRaKEPWi <= -127706.19872405645) {
        for (int ORezFvO = 862727489; ORezFvO > 0; ORezFvO--) {
            MdcRzChEw -= eXcPwdtVcGgxzqMI;
        }
    }

    for (int rSwaCmZAuFntyFsJ = 1390763669; rSwaCmZAuFntyFsJ > 0; rSwaCmZAuFntyFsJ--) {
        KVSCsoHuCx = KVSCsoHuCx;
        KVSCsoHuCx *= eXcPwdtVcGgxzqMI;
        eXcPwdtVcGgxzqMI /= MdcRzChEw;
    }

    for (int InVFnJAgNbMl = 1015828292; InVFnJAgNbMl > 0; InVFnJAgNbMl--) {
        cfWvpCANVRaKEPWi = eXcPwdtVcGgxzqMI;
        DLPGCQajvArdeMH = ! DLPGCQajvArdeMH;
        GpMiG = GpMiG;
        MdcRzChEw *= gWbLpHZJRcT;
    }

    if (KVSCsoHuCx <= -1037135.6554587135) {
        for (int VDiDXXNfN = 899429857; VDiDXXNfN > 0; VDiDXXNfN--) {
            cfWvpCANVRaKEPWi *= cfWvpCANVRaKEPWi;
            gWbLpHZJRcT = KVSCsoHuCx;
            gWbLpHZJRcT += MdcRzChEw;
            KVSCsoHuCx -= gWbLpHZJRcT;
            eXcPwdtVcGgxzqMI *= cfWvpCANVRaKEPWi;
            gWbLpHZJRcT += eXcPwdtVcGgxzqMI;
            MdcRzChEw -= eXcPwdtVcGgxzqMI;
        }
    }

    for (int rKkwydl = 1755282896; rKkwydl > 0; rKkwydl--) {
        gWbLpHZJRcT = MdcRzChEw;
        MdcRzChEw /= KVSCsoHuCx;
    }

    for (int eroEIfsyM = 1197684204; eroEIfsyM > 0; eroEIfsyM--) {
        GpMiG += GpMiG;
        gWbLpHZJRcT *= gWbLpHZJRcT;
        eXcPwdtVcGgxzqMI -= MdcRzChEw;
        KVSCsoHuCx += gWbLpHZJRcT;
        KVSCsoHuCx += gWbLpHZJRcT;
    }

    return -1822139091;
}

string YmESkaMALHaAe::LWlLVrgF(double TEexfJ, double ThoMxdEhgu, string SEhJvpywIF, string eodKEvUgrR, double fONJSdbEPHpaLo)
{
    int mAihtEmtKOYRWOkf = 906053172;

    for (int FjMTiGDRzIxyxw = 1021385741; FjMTiGDRzIxyxw > 0; FjMTiGDRzIxyxw--) {
        continue;
    }

    if (ThoMxdEhgu < -1017351.3012392778) {
        for (int kxWoZsAx = 136325683; kxWoZsAx > 0; kxWoZsAx--) {
            eodKEvUgrR += SEhJvpywIF;
            SEhJvpywIF = SEhJvpywIF;
            ThoMxdEhgu -= TEexfJ;
            SEhJvpywIF += SEhJvpywIF;
            ThoMxdEhgu += fONJSdbEPHpaLo;
        }
    }

    for (int AvJNNzgUNc = 1049867592; AvJNNzgUNc > 0; AvJNNzgUNc--) {
        fONJSdbEPHpaLo *= fONJSdbEPHpaLo;
        ThoMxdEhgu *= TEexfJ;
    }

    for (int wUtSIRwaHKNxjj = 260730477; wUtSIRwaHKNxjj > 0; wUtSIRwaHKNxjj--) {
        SEhJvpywIF += eodKEvUgrR;
        TEexfJ -= fONJSdbEPHpaLo;
    }

    for (int LcONjPfyj = 146433807; LcONjPfyj > 0; LcONjPfyj--) {
        fONJSdbEPHpaLo /= TEexfJ;
        fONJSdbEPHpaLo -= TEexfJ;
        fONJSdbEPHpaLo += TEexfJ;
    }

    return eodKEvUgrR;
}

int YmESkaMALHaAe::wJbsXOMtXVbEh(bool akKbLYoqLq, double zppZAUhGWIctKKqy)
{
    int nEYPjmZQwZaWB = -1952124884;
    string NKmhhh = string("rNIUoNPSwsg");
    double KnsTnrb = 549998.3280486913;
    string smQFdSY = string("unsNuViXnwNmfYICAkwzQwsrIQLaBpfOTLwSpjCSwBjsPbjKBeDuVyIGAeGbyEPLuEoRStltzMakMiEFSnzLeQCpGDndBTooiQcOwsEiounmwyjbJLEosQqSDPKTRAwYsqmLqjmosMkxbgCoVlCMMgvLTrmbtZiQqJVBsqrPfAVvkCluDFVXmgksSVgxIOIIhhWIKsPBfaogWECpSqx");
    string bgLkxgJp = string("YoihlErAQCezHCfUbbIStjIBSWbLtTDKIZiglwimFqWRfmLiJrtWmVUNlCtenOIAkzPdEaFizderjngxDDtDEYZSyizZgPPdnZWOzVPhWlduJodOWvyqlrwRyvsDlJBAwXVJEIMswDcYzVqjuaNzBFgTVIAffXGETlRbZVxhslDeayeuslydJ");
    double EMnZKorYfkHIwaJ = -910118.6523293393;
    double CMfWxSKEQtl = -769098.8204300805;

    for (int qyPmbTWHMcYQylpr = 849779626; qyPmbTWHMcYQylpr > 0; qyPmbTWHMcYQylpr--) {
        KnsTnrb += CMfWxSKEQtl;
        KnsTnrb += zppZAUhGWIctKKqy;
    }

    for (int bHCkkc = 907800198; bHCkkc > 0; bHCkkc--) {
        bgLkxgJp = NKmhhh;
        CMfWxSKEQtl = CMfWxSKEQtl;
        zppZAUhGWIctKKqy *= CMfWxSKEQtl;
        EMnZKorYfkHIwaJ = zppZAUhGWIctKKqy;
    }

    return nEYPjmZQwZaWB;
}

string YmESkaMALHaAe::kFJSow()
{
    bool IRkfTAQnfbslPox = false;
    double fOkxsIoaaiIpO = 254899.5401019857;
    string cHabkKMPyRK = string("GtMiRSjcZmnuHzfckyTnredySRRooahzhXvWqCfOgZSvPPJcKurGSnz");
    string sypnEZwgs = string("VquEpGBwjlHeJItEhYGTKuSehyMqMgKwsmpFfDJxZrKKHL");
    int cmhEIcOGpDxL = 1525632272;
    bool csHcHZUMsQIPPx = false;
    int LYLbcQnBZ = 503839369;
    int SwAfHumeOpdp = -775600676;

    for (int yqoUyucCKkVCx = 797873832; yqoUyucCKkVCx > 0; yqoUyucCKkVCx--) {
        cmhEIcOGpDxL = cmhEIcOGpDxL;
        LYLbcQnBZ -= cmhEIcOGpDxL;
        cmhEIcOGpDxL -= LYLbcQnBZ;
        IRkfTAQnfbslPox = ! IRkfTAQnfbslPox;
    }

    for (int darsIYeqwSmrrV = 25330674; darsIYeqwSmrrV > 0; darsIYeqwSmrrV--) {
        continue;
    }

    return sypnEZwgs;
}

string YmESkaMALHaAe::BEtnWrFy()
{
    int qqtVyY = -953151527;
    double PylGTLDjgqsQ = 161159.71414741094;
    int difvXkifeD = -1872421576;
    string HBHlvkGFD = string("oxoElCHGBmLPMPfKDHdwJfidWqFcqqZSFBbuqgsBoRDmXtrRPIEduVfHqbnMXVoBgfdLxsINPQYdRbRHFxWqpLbgFPkXLyrzDGTTutAsTqOQyPxnKhlZVcynFVyHooLBAynEIlcgYivTKBFgjwcVCaYFKnRtK");
    bool mOjXd = false;
    double zElGd = -109767.83992106302;
    int lxTioeuP = 607580742;
    bool jYoEoQgw = true;

    for (int vKznNQwH = 570728593; vKznNQwH > 0; vKznNQwH--) {
        continue;
    }

    return HBHlvkGFD;
}

string YmESkaMALHaAe::zxCQE(string PpnXxxRIS, bool ZjfguriqxJMbd, bool rGAYdZkpXMU, bool RSUzD)
{
    string RVJuurr = string("SogodPpVtAmmdLnlWGkCiDWzneIgNwyRKDBxnpqyLLoHMNwfSPHqVxHhCJwqMYmNrDIYwiBEs");

    if (ZjfguriqxJMbd != false) {
        for (int KdSQpi = 835119771; KdSQpi > 0; KdSQpi--) {
            RVJuurr += PpnXxxRIS;
            ZjfguriqxJMbd = rGAYdZkpXMU;
            rGAYdZkpXMU = ZjfguriqxJMbd;
        }
    }

    return RVJuurr;
}

string YmESkaMALHaAe::wDRPIOHZ(string BWpNAi)
{
    bool XlyInbUFLIzkVL = false;

    for (int ymMpLgH = 419986081; ymMpLgH > 0; ymMpLgH--) {
        XlyInbUFLIzkVL = ! XlyInbUFLIzkVL;
    }

    for (int qDRevbsOfUPmdoCw = 1622407065; qDRevbsOfUPmdoCw > 0; qDRevbsOfUPmdoCw--) {
        XlyInbUFLIzkVL = XlyInbUFLIzkVL;
        BWpNAi += BWpNAi;
        XlyInbUFLIzkVL = XlyInbUFLIzkVL;
        BWpNAi = BWpNAi;
        XlyInbUFLIzkVL = ! XlyInbUFLIzkVL;
        BWpNAi += BWpNAi;
        BWpNAi += BWpNAi;
    }

    for (int zEgPG = 988075567; zEgPG > 0; zEgPG--) {
        BWpNAi += BWpNAi;
        XlyInbUFLIzkVL = ! XlyInbUFLIzkVL;
    }

    return BWpNAi;
}

double YmESkaMALHaAe::vPjLoe(string KtlpBdriMeJT, int cTtjdNsZqR)
{
    bool TICvqNfrl = false;
    int toLOWoTmGuyuAv = 2008858037;
    double VKoCIl = 673878.4083748241;
    string MBSso = string("MJocOKdjrgTztZUhMYeOjgnrNyrKgUDqxOrppihwnEgpuQHxHQ");
    bool WLuIwSd = false;
    string GORuOwljD = string("mfIKqSdvJLhhGabpNlebZbNkUlWOYPGLrAXYpDlVdNKnIhPYjriUECopWJUkImjHnywkCBYHlqLP");
    int DJaTWGl = 1726479629;

    for (int kwhbAojhdTEPJeo = 1659652026; kwhbAojhdTEPJeo > 0; kwhbAojhdTEPJeo--) {
        continue;
    }

    return VKoCIl;
}

YmESkaMALHaAe::YmESkaMALHaAe()
{
    this->lkzmdRPPbwCli(1723051992);
    this->gBfFMFJz();
    this->LWlLVrgF(307377.4022581303, -1017351.3012392778, string("iKPhMbYtWpeofRHDLwXazhYheqyxZFNPyTXxryELjMgPPNjLJCuTHZbQZfagEXjnboZDGuKfRzqmE"), string("EvuOuIEejikgbdqSaLILYTFapMLRtrzDoDzNcVDUyeMpxHcfwHxErUNqBlxePLIptDY"), 932442.2245480265);
    this->wJbsXOMtXVbEh(true, -884806.1627486388);
    this->kFJSow();
    this->BEtnWrFy();
    this->zxCQE(string("KZqCOuGkXdAWrLgiVCcSyoRbikVUZgWqInGwYppBfAQjyGrnwAbHKnZzsXyhIHbrpmSjOsDKcrlYAgerdyQgkEUuhPuKklYLGghNBAsuIcRqhdxleDjBqYbCZonfhikzlvOozeRghlGsxiSDQVwOVkBLDczdjvHhpDbBzYaXJxFJUjuhmVgPUeniJvtcJVekWToSVVscCAvsaCYbZOdkCWcpSBENDrPlCXiNeTYxTVyoAqhHRZgsYJcUF"), true, false, false);
    this->wDRPIOHZ(string("dYKPkjsJzf"));
    this->vPjLoe(string("jfHWqQgDgnyonTBNNAIxalqwGKCtwIlqMyCjpqSKqSKsrtsdwafLlGwtKOztWurgNFwVcCjkfwVuHsnHJvVBjLkUTfdpKJNWUNmQqtIdctJl"), -781650469);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MPLbnqlsgcZLdv
{
public:
    double iYuFuQuxnYvULlg;
    string KBhSefvZuPzY;
    int XAiCMYeNXdwvvU;

    MPLbnqlsgcZLdv();
    string vDkSYF(bool fuleR, string bFkPqvBGqiLQB, double pggVWuT, double wAzcolQXcJdRKzP, bool sJvyHgw);
    double VprWWacpAbjqwDN(string jvOLj, double xAYkP, double dSljr, string xedzZbI, bool zDTAAfhfJq);
    bool hAYWtzxQjN(int RsaCpiHfFKdEy);
    double gyIjSmLsw(int FhComArHFoVo, string NIoRNRvN, double ZQhhhXzi);
protected:
    double QrwqtJmKmJC;
    bool MkvuElVXhvuZvWK;
    int pmQVnLY;
    int hMPWkzUgQQBoiM;
    bool sYniCZfhH;

    string haVxgU(string KYvKISby, bool rRUWvhfJUrQ);
    int HVNXMO(int StkEDSTaZYJk, double irlSfWrPlF, bool TfqBUseUVgTfTZrh);
    void HjxWEP(string MAJWAX);
    void nvWRORsUdEPInA(int lXCZiRVaxa, string jzZHoxqu, bool VmLPnfZhuVfXUoRk, bool VnXgeqLEQvnF, bool ZqyPbMUZelFbucjR);
    string tyCqiMKudlXHMqHf(int LzmadJBoXmrIPRnZ, string gPlhViCBin, string gozCeXlX, double ENilHNdg);
private:
    int rgIctDEBEA;
    double gBaJvImuuB;
    int QKzDSC;
    bool ABVEW;
    string ieDswEqYVP;

    int UOmlzFXBPglBR(string IQErVtin);
    string hPBsyGNXqfo();
    double IbmQrRRTnZGvh();
    void OYuzYGYaujBGMa(int rfAuzSfXqIRq);
};

string MPLbnqlsgcZLdv::vDkSYF(bool fuleR, string bFkPqvBGqiLQB, double pggVWuT, double wAzcolQXcJdRKzP, bool sJvyHgw)
{
    string mlPVGgyhwN = string("LvtooWUHEVsHyKMDSDiBVcYmpzgLWKOPrbNcDWIjDyLxbuyHfTPXUBsxSHqeEeoCNxCTZLFoEltTPyZiGDEYAQAqzSIIBOmECccHghECCmERqaRSUZTwEhGgoCFVZMalgCqnVQRHqqhqdNErxxGzQcbzinioCsYXfgSFQeYwRfHgeNrrPjMudgAvUSnOCFVVwsOSFCGjXsvHETYYQrhvqojgJREVqwp");
    bool hvsZianqihZHMmD = false;

    for (int ogENjfLClSqhiRnr = 1533707977; ogENjfLClSqhiRnr > 0; ogENjfLClSqhiRnr--) {
        sJvyHgw = sJvyHgw;
        hvsZianqihZHMmD = ! sJvyHgw;
        hvsZianqihZHMmD = ! fuleR;
        mlPVGgyhwN += mlPVGgyhwN;
        pggVWuT *= wAzcolQXcJdRKzP;
    }

    for (int ZNGHcnNxMjwY = 986267208; ZNGHcnNxMjwY > 0; ZNGHcnNxMjwY--) {
        mlPVGgyhwN = bFkPqvBGqiLQB;
        pggVWuT = wAzcolQXcJdRKzP;
        fuleR = ! sJvyHgw;
    }

    for (int uTEhShxDxYYfPKEp = 2020849110; uTEhShxDxYYfPKEp > 0; uTEhShxDxYYfPKEp--) {
        fuleR = ! hvsZianqihZHMmD;
    }

    if (sJvyHgw != false) {
        for (int raWwcArP = 680524520; raWwcArP > 0; raWwcArP--) {
            mlPVGgyhwN = bFkPqvBGqiLQB;
            wAzcolQXcJdRKzP -= pggVWuT;
        }
    }

    return mlPVGgyhwN;
}

double MPLbnqlsgcZLdv::VprWWacpAbjqwDN(string jvOLj, double xAYkP, double dSljr, string xedzZbI, bool zDTAAfhfJq)
{
    bool SRHYkGjjSx = true;
    string XuQEThdo = string("URzoPNEupoAHJsqcrWpNOIHqmtynTPJNIbuZZJBrfjVGFWKlePfvkLCZhnRmWCJYVMRlrvgXiNbLTQWsTUhkThZOoShGXJdvyapuOv");
    string CMUuPn = string("SiTokEJaXPdadaVPkeXpTzSdvzniCAzeJwWkgztpOPTsgsvdtcUcPaIfBGUbAXEouUVYgYwQcvbzEEpjwLxLbqsVatwGtccSoqFvMAvOxRQyDQUJadnQBvLtOQJBGyOtSMnlUboQTmNWrgKpuWCViCojRyYmRgsOjiQwbdLxqGrXwzApccsYDvziYpjrXZZHc");
    int EwQkLqfda = 338671926;
    int lzcnXiimU = 752604793;
    bool ENosPxolpIBFTbQd = true;
    double XfSZbMdDUrWJeeUS = -522517.25436435046;
    int fRcNb = 1633794258;
    string JUjRaTmYOik = string("VJsXRpFCydsEDbJQLXVPHtUvUqMvoAezXDIRsUc");

    if (CMUuPn < string("wbLOwKHlSRyyopcwsWRJGQlrzjtCUADf")) {
        for (int cFgcBx = 517073726; cFgcBx > 0; cFgcBx--) {
            SRHYkGjjSx = zDTAAfhfJq;
        }
    }

    for (int SvMFfBJKEfD = 1237944467; SvMFfBJKEfD > 0; SvMFfBJKEfD--) {
        jvOLj += XuQEThdo;
        XuQEThdo = XuQEThdo;
        lzcnXiimU = lzcnXiimU;
    }

    return XfSZbMdDUrWJeeUS;
}

bool MPLbnqlsgcZLdv::hAYWtzxQjN(int RsaCpiHfFKdEy)
{
    double hLfyEHNfRPobp = -291284.4294221537;
    bool kwUXMI = true;
    string QUjkDZyss = string("wHVzBydPuOQSBAvlbCRxqjmYakSDASAXXINCSfYPicJGSXxgMePPccIDdIuPGogwlQnBIREtMelgixZKwGNpuItkLkwhqImiMlRsxXWoimKQZIDdBDXDNVRyrJtSKQqjnasYyxPEePFRRmDjNiOv");
    double dtnbAUSwygMQxg = -908961.8237926995;

    if (dtnbAUSwygMQxg == -908961.8237926995) {
        for (int pugIqQOKGVz = 1334433929; pugIqQOKGVz > 0; pugIqQOKGVz--) {
            continue;
        }
    }

    for (int OQTksisheyVTeNEo = 396339195; OQTksisheyVTeNEo > 0; OQTksisheyVTeNEo--) {
        kwUXMI = kwUXMI;
        dtnbAUSwygMQxg -= dtnbAUSwygMQxg;
        hLfyEHNfRPobp -= hLfyEHNfRPobp;
    }

    for (int uOmNDfHshCjcRVy = 407565307; uOmNDfHshCjcRVy > 0; uOmNDfHshCjcRVy--) {
        hLfyEHNfRPobp -= dtnbAUSwygMQxg;
        dtnbAUSwygMQxg = hLfyEHNfRPobp;
    }

    return kwUXMI;
}

double MPLbnqlsgcZLdv::gyIjSmLsw(int FhComArHFoVo, string NIoRNRvN, double ZQhhhXzi)
{
    string xoEBqxVggd = string("PKPEXMFSyZidmazOfAwHJuRpqnzUNKPsqQiECaPsgqlgsaZdxOudUlkPviHDlMLuxyjCBoIQSDrihtPfvBilBxVnYSiEhYHzPSxFFsQaFkHZqUiwcXDGvyKwTwGzevQaYPHttZIAcXSibBYcgfYsXrwWJeOOUZc");
    double ECZoIuQ = -638194.0710791715;
    bool mDrHggcWJNMsMMJ = false;
    bool tRaug = false;
    string fVrBl = string("HcaNYOMLMssyAXRqSkTKxEgScKPgFgHAwOkIyGhUSLpAskEXEqEYorBPonMhpyjwQmpNjObUricFAFfdRQwxbBwXGvJPwAghrEDwLYAegiKFXVMRurLboWSywx");

    return ECZoIuQ;
}

string MPLbnqlsgcZLdv::haVxgU(string KYvKISby, bool rRUWvhfJUrQ)
{
    double IEIkzNNpwBmNasL = 517526.2425319074;
    string esPnaNjmf = string("JxRfmOBGNnJvjXsnKhNxNRukQdivtAaJhaygLWiMclvSyqnGRqbQKsLdQWlJXOUSPRVUCimSQuWCDgZkNEQ");
    int qoiQNVUEdd = 1355171870;
    string HlvWqkuG = string("shQqTLJAGbUVwedoZtVFnLBYAtqusqHISInLcmVYqSlROFCPgPLHzkGIsyTlqHaxglGhvpQEnmWgyCAYRfuuGjVSzeoXXWQlnywtlTMWWbDxEPbCzOtAOZPEguYxcWWs");
    string gZesHShd = string("yceGqBQdLbabYccTPArlpiRiUqgzqyMqeRzIcreQJKBXWIZNcMNyElZLviwwDBEifMEgvHuQrHYdipDkBRnfpFQuwcEomWZOtEtixiGABUDgJOmLAEloJRVKHPcCQdSxtCUcfRYhdxwvlzXTRcmBRbewPdJWupcCQPsWMxrPHfSgPdAvbCIzXFUhHHhMAtDHhfVVPorxDVHBI");
    int AOJyYEKXHrofl = -878953446;
    string ahfxUKE = string("KcbGGZrNNmtsJSEaAKBybroVOeSTWQKqBHmrDHHFmVkuVytWvsgOCjhGVnmIMMXdOarSDcXoNipPuIRmLFZLGEpyDxZKBQzJhqwhOBvqCgNbOQCSVkivpQGiZEJZfBMrtkkgPDfKeyLVNYClUqaltbUOtBejsJnDkhRfMgwwICxGvIAgezqPQQORLaGgqIhNUHUuYQLMiebyJZoAFULetpXiC");
    string gLceWGzCCFhAkc = string("HCnbvkiIKeOrlxvVoEGQpvHillwOozmlRBZSRCujmKgqXZxgGiapzAYQXSJqyxjqZTiXSoSjyPNNuRUfSCtDJjrBBPCnBvADNNfKeTmjRLoiYQanZFqvEFQOxSsWXrKZdOxaoovfe");

    return gLceWGzCCFhAkc;
}

int MPLbnqlsgcZLdv::HVNXMO(int StkEDSTaZYJk, double irlSfWrPlF, bool TfqBUseUVgTfTZrh)
{
    string fTKaFwWUJmu = string("bPDinHJwujtiHGwfZlmaoRXSyEUkxkHubRdXxnHSwNQaZsfxEKIsxElFdoJluiZwpzZLzpmEttILFIgcoRyzQSSRxeHbLXkekekiBpugnSSylyZAyuIttNnDJoUfZZCBHkecdxCQrvhIDuOMUDnxwFFaIWQGbtwcIGNFqGhPFCKLbfGUTIGWEbxVtk");
    double KMhSgLWIUeLP = 623448.0470989395;
    bool nizqWdvSqAdUG = false;
    bool cshcXddbzb = true;
    int UqAvfUzZkSpXdq = -1426883342;
    int cmOyAQNoOosDVlBT = 137684576;
    int MjdLBqcDyyHrSCoH = 1457183571;
    bool lVpUl = false;
    int YsdUzTBsnJH = 814819768;

    for (int bKQGaqaqJTDqb = 1567966019; bKQGaqaqJTDqb > 0; bKQGaqaqJTDqb--) {
        KMhSgLWIUeLP += irlSfWrPlF;
        cshcXddbzb = nizqWdvSqAdUG;
        StkEDSTaZYJk /= cmOyAQNoOosDVlBT;
        TfqBUseUVgTfTZrh = nizqWdvSqAdUG;
        StkEDSTaZYJk -= YsdUzTBsnJH;
        MjdLBqcDyyHrSCoH = YsdUzTBsnJH;
    }

    for (int wVrhildZYwXbiYT = 938858820; wVrhildZYwXbiYT > 0; wVrhildZYwXbiYT--) {
        continue;
    }

    return YsdUzTBsnJH;
}

void MPLbnqlsgcZLdv::HjxWEP(string MAJWAX)
{
    string olrfXYVoBhCng = string("qQvoqXFJimuiKoItqOgnjjdBbMGPvkTVYCOPOSoVmimIVijgEGdilgjJuNxtaiUgueZYuOmfZfEqQsJloIFnDMgrwTMTSUIckFnFexoMoyEjpMtCyuHpEfthmgBrFwrbyNgWpVttJPDHchvkctWpCpitrH");

    if (MAJWAX >= string("qQvoqXFJimuiKoItqOgnjjdBbMGPvkTVYCOPOSoVmimIVijgEGdilgjJuNxtaiUgueZYuOmfZfEqQsJloIFnDMgrwTMTSUIckFnFexoMoyEjpMtCyuHpEfthmgBrFwrbyNgWpVttJPDHchvkctWpCpitrH")) {
        for (int TyejMEG = 1519164860; TyejMEG > 0; TyejMEG--) {
            olrfXYVoBhCng = MAJWAX;
            olrfXYVoBhCng += olrfXYVoBhCng;
            MAJWAX = olrfXYVoBhCng;
            MAJWAX = MAJWAX;
            MAJWAX = MAJWAX;
            olrfXYVoBhCng += MAJWAX;
            olrfXYVoBhCng = olrfXYVoBhCng;
            MAJWAX = MAJWAX;
            olrfXYVoBhCng += MAJWAX;
            olrfXYVoBhCng += MAJWAX;
        }
    }

    if (olrfXYVoBhCng < string("FHvhaCZuyXOyTQFfGkGCbJNNLTPMmiCyulJtnzlWGjCongDCwfJJyeZvxuJfOfrFFqUpyAZvuoNGofGMECoBPGzfWxWxEfgimExZNaMeTdwFaXNhIfSEynlCbsjpm")) {
        for (int LcYJyLfzXxtrTfsy = 764167198; LcYJyLfzXxtrTfsy > 0; LcYJyLfzXxtrTfsy--) {
            MAJWAX = MAJWAX;
            olrfXYVoBhCng += olrfXYVoBhCng;
            MAJWAX += olrfXYVoBhCng;
            MAJWAX += MAJWAX;
            olrfXYVoBhCng += MAJWAX;
            MAJWAX = MAJWAX;
            MAJWAX += MAJWAX;
            olrfXYVoBhCng = MAJWAX;
        }
    }
}

void MPLbnqlsgcZLdv::nvWRORsUdEPInA(int lXCZiRVaxa, string jzZHoxqu, bool VmLPnfZhuVfXUoRk, bool VnXgeqLEQvnF, bool ZqyPbMUZelFbucjR)
{
    int BFlvt = -784457987;
    string DXgJywMdyhaPqs = string("NMInhwvoTjyQuylrHhIUlKPkixbzHBMOKIByyIbPgEIQuMeFwjpmmRrhTHSOjnXTwwCAbuwMyKhtJeyxSNhXiNXOLYjtTPCULrMUYkTtQB");
    int cOKsFuwqDTx = -8283477;
    bool qpnqScDlwaPRF = true;
    bool uynhHXkFmA = false;
    string gtTbTBpPpgjKld = string("OCpnwVOxlwoUgmWejCxHXglTxifopOUOiFXKzwfMFjxnyQIFVWzdccKwzRPwlVKZsGyqyriXBqmOcXhzjPXmrlsajkIGUsJWqHVZmSIwpnDHpnfg");
    string nQFdz = string("jlEnpkVmVwizJWKsiGupYeKVpYUDVmGstkOOpXMvdqZhIkSAASpzGmOgdIbVKPitvsSNQhfUopxnRYZnRugVAeMDNYCvTTPAOOMpLqQowVchKGttSscre");
    string UeNeD = string("DqodrfoGkkcFamktXzwCbCpd");
    double UGtNHjqyunnMUYY = 111630.3752662836;

    if (qpnqScDlwaPRF == false) {
        for (int ReVtNGlqK = 1744201802; ReVtNGlqK > 0; ReVtNGlqK--) {
            continue;
        }
    }

    for (int fEbKaWu = 1157152480; fEbKaWu > 0; fEbKaWu--) {
        continue;
    }

    for (int voissZkZ = 2114745755; voissZkZ > 0; voissZkZ--) {
        UeNeD += jzZHoxqu;
    }

    for (int uZMFwULjumIuI = 2092971692; uZMFwULjumIuI > 0; uZMFwULjumIuI--) {
        VnXgeqLEQvnF = VmLPnfZhuVfXUoRk;
    }

    if (nQFdz <= string("DqodrfoGkkcFamktXzwCbCpd")) {
        for (int rbnWCFmmrcsLuoz = 1421485565; rbnWCFmmrcsLuoz > 0; rbnWCFmmrcsLuoz--) {
            continue;
        }
    }

    for (int LuAHwxxjFOZQMs = 1549203493; LuAHwxxjFOZQMs > 0; LuAHwxxjFOZQMs--) {
        jzZHoxqu += DXgJywMdyhaPqs;
    }

    for (int qyCwlnqon = 22154995; qyCwlnqon > 0; qyCwlnqon--) {
        VmLPnfZhuVfXUoRk = VmLPnfZhuVfXUoRk;
        ZqyPbMUZelFbucjR = uynhHXkFmA;
        nQFdz = UeNeD;
        DXgJywMdyhaPqs += nQFdz;
    }
}

string MPLbnqlsgcZLdv::tyCqiMKudlXHMqHf(int LzmadJBoXmrIPRnZ, string gPlhViCBin, string gozCeXlX, double ENilHNdg)
{
    string nmjEJRXpFsUcJpm = string("MbIBFVjPXdiwitTRuxIQEhOjCsMDRzwbtIpWgbtJJeqYAMCKJKWzXldUzDTAlfWoexDoGCvNVEmZOhT");
    string wXmrVjtDh = string("gETXK");
    double oJLUQMbKj = -379382.1605291533;
    bool ReThhiIL = true;

    for (int jUQfBdGUjZfTmENw = 1594981381; jUQfBdGUjZfTmENw > 0; jUQfBdGUjZfTmENw--) {
        LzmadJBoXmrIPRnZ -= LzmadJBoXmrIPRnZ;
    }

    for (int PNhWDdOgCzWt = 854116477; PNhWDdOgCzWt > 0; PNhWDdOgCzWt--) {
        continue;
    }

    for (int LYqvlliCcHiUYlN = 1246489235; LYqvlliCcHiUYlN > 0; LYqvlliCcHiUYlN--) {
        LzmadJBoXmrIPRnZ *= LzmadJBoXmrIPRnZ;
    }

    if (gozCeXlX == string("qGqtCSjDOsOCbSIopgjxEmFtGyauuOPTTyEzCcvtlmylWLvEKWOyfKgTEUaobIHbiZaGQxTpXoGMCiEKbTKXcoYNNPrLefJolBZxehPIIOwDVVmytrIKeNbiZpnhNExcvAZOhDlmOQbZxRzRw")) {
        for (int AlbKNthMNU = 523957236; AlbKNthMNU > 0; AlbKNthMNU--) {
            gPlhViCBin = gPlhViCBin;
            gPlhViCBin += nmjEJRXpFsUcJpm;
            gozCeXlX = gPlhViCBin;
        }
    }

    for (int nXVwnNxoEyJu = 1594772749; nXVwnNxoEyJu > 0; nXVwnNxoEyJu--) {
        gozCeXlX = gPlhViCBin;
        oJLUQMbKj = ENilHNdg;
    }

    return wXmrVjtDh;
}

int MPLbnqlsgcZLdv::UOmlzFXBPglBR(string IQErVtin)
{
    bool cUtyW = false;
    bool uigIRkqTggN = true;
    bool ZWukzq = false;
    double mdqUT = -216289.64567952475;
    bool lLjOaXmLTrlEY = true;
    int qhahNmfSaxRUjDb = 219650018;

    for (int CxXFjqKeOTOtv = 2142593402; CxXFjqKeOTOtv > 0; CxXFjqKeOTOtv--) {
        cUtyW = ! ZWukzq;
        cUtyW = ! ZWukzq;
    }

    if (lLjOaXmLTrlEY != false) {
        for (int WJGpQWJNYXq = 534488165; WJGpQWJNYXq > 0; WJGpQWJNYXq--) {
            continue;
        }
    }

    return qhahNmfSaxRUjDb;
}

string MPLbnqlsgcZLdv::hPBsyGNXqfo()
{
    string wtIOl = string("RkhffUzysHiKKXFgHjdUDnSbPpxQQFdGelmpRZcrwDNbVXfMYynppUigmizrBvPHpYVBMnKMbmtCmPuNfXHuNDZjoxyCwFxFznTKQMVHeiXaowfkwEYMlRRVUqJJKmccZtptqqlp");
    int RxftslJYut = 294536423;
    bool PJtGgbwTniLVmn = false;
    int uOLQS = 1569054725;
    int lpCEootl = 1495158030;
    double mOniLiLLEUAyIUB = 681860.8145309344;
    int kiRpQ = 392816606;
    bool MadhmvR = true;
    bool cXzDESy = false;

    if (RxftslJYut <= 1495158030) {
        for (int qLcKfV = 1903837265; qLcKfV > 0; qLcKfV--) {
            lpCEootl *= lpCEootl;
        }
    }

    for (int OgqwymjS = 1395284225; OgqwymjS > 0; OgqwymjS--) {
        continue;
    }

    return wtIOl;
}

double MPLbnqlsgcZLdv::IbmQrRRTnZGvh()
{
    string cRdFr = string("dcPpUGzLbkGSOJclMJsDWmBoKeoCGrlmVPBxAouFJhfvMzyvZYSvxuxbsCuFagzAEgqdXpOqNSfXXBURvptISDvDNfzGnyXVUYKExAYOaKfUNpUgVbytmsuPVdWoVFOjWVKcjQUNJoZJWJqLUneEMBzpPHGjlDuqFNUmUkjgIhqJXJhBoBprqKmKPJuXqfJcgcMlEilqBTSnoCIUDaiDKcQFWRHMFzpIWxTmtnHUqVGNxBUpO");
    int bevAhgKe = -907018980;

    if (bevAhgKe == -907018980) {
        for (int ybyhuKLkRqf = 1842389980; ybyhuKLkRqf > 0; ybyhuKLkRqf--) {
            bevAhgKe -= bevAhgKe;
            bevAhgKe -= bevAhgKe;
        }
    }

    for (int IuwEdfmvUXiz = 1122434257; IuwEdfmvUXiz > 0; IuwEdfmvUXiz--) {
        cRdFr += cRdFr;
        bevAhgKe -= bevAhgKe;
        bevAhgKe -= bevAhgKe;
    }

    if (cRdFr >= string("dcPpUGzLbkGSOJclMJsDWmBoKeoCGrlmVPBxAouFJhfvMzyvZYSvxuxbsCuFagzAEgqdXpOqNSfXXBURvptISDvDNfzGnyXVUYKExAYOaKfUNpUgVbytmsuPVdWoVFOjWVKcjQUNJoZJWJqLUneEMBzpPHGjlDuqFNUmUkjgIhqJXJhBoBprqKmKPJuXqfJcgcMlEilqBTSnoCIUDaiDKcQFWRHMFzpIWxTmtnHUqVGNxBUpO")) {
        for (int pwieHgjKlHNFNyw = 240482238; pwieHgjKlHNFNyw > 0; pwieHgjKlHNFNyw--) {
            cRdFr += cRdFr;
            bevAhgKe -= bevAhgKe;
            cRdFr += cRdFr;
        }
    }

    for (int kNOPxLOui = 1110273574; kNOPxLOui > 0; kNOPxLOui--) {
        continue;
    }

    if (cRdFr >= string("dcPpUGzLbkGSOJclMJsDWmBoKeoCGrlmVPBxAouFJhfvMzyvZYSvxuxbsCuFagzAEgqdXpOqNSfXXBURvptISDvDNfzGnyXVUYKExAYOaKfUNpUgVbytmsuPVdWoVFOjWVKcjQUNJoZJWJqLUneEMBzpPHGjlDuqFNUmUkjgIhqJXJhBoBprqKmKPJuXqfJcgcMlEilqBTSnoCIUDaiDKcQFWRHMFzpIWxTmtnHUqVGNxBUpO")) {
        for (int gEvwkq = 1207458972; gEvwkq > 0; gEvwkq--) {
            cRdFr = cRdFr;
            cRdFr += cRdFr;
            cRdFr += cRdFr;
        }
    }

    return 967195.5487945473;
}

void MPLbnqlsgcZLdv::OYuzYGYaujBGMa(int rfAuzSfXqIRq)
{
    string cdnNNOzNRVeQc = string("arZPtThWnYnowDgkxJdJzYlyrTaAYRxclAUyeHeqKDKzvOIitJsERMFjOaOtmPHvKvDBuTGMBqdRWFCOaRpOZSaawiIXiOCTqNAXshGAEtBxKUXARZOhVlCYnIkhBygtTfofLvbepqJrQCADFQxRDXJpjkVEIkZyACmdVmrZqKlQGhhQLRwmMnCUlmQNbJxyAWWXSRMFWRaroRyaupkCxKFWvKUfeRqvjVTCmCdB");
    int cGAoAZjNnXDs = -1617280663;
    string fxEPXaeybRAYt = string("CZzYEhEobbCzflIDAoNAfFBtPIDZuWhjmquuqkdEznZjFACHKXHInqKNISKgdjSxisyGCdCGqGlFu");
}

MPLbnqlsgcZLdv::MPLbnqlsgcZLdv()
{
    this->vDkSYF(true, string("LSGxzVmNzsRLmsSqfimeMjcAvhbJrQJVfddAqvFOwqQmQDUEnfgDycOIhiQnAKVuXIbgBJuQNGGsRyVvnySweBrJJwfmyaGLNCHlTBYpzPKhjBJSBXDZAICeffLXOgITdNcTDayQvJqjodWrEsdGsZbZKXWllhSxBhWoTuqDikMtPbPlcsUnOcgfGliCcgbSwKzTZRUQtJGXhtgBTdXyhyitLtT"), -439487.70316205453, -556384.821799274, false);
    this->VprWWacpAbjqwDN(string("GWXlbytJwqGVxwDHOlfkeZWRkzkdaJzPXJajRMCjvUcDITtapOmmXhNZSdeYOOzVxIhSsBREBGCNsIxzxkwtgjqFsMOZnkEESCPafvnZzwYJnbjExEIvWrthqxyyCUAxPqclJLRXzUeeWyptAHQAqwjFsDZIpmlxzqTKrFfSlVoPCWvVqIikeNWFYtGaCtbrOQFprnAlPmaTYeyjHrsDfNBjLhDoZ"), 734102.3754384742, -36945.62537441906, string("wbLOwKHlSRyyopcwsWRJGQlrzjtCUADf"), true);
    this->hAYWtzxQjN(791651612);
    this->gyIjSmLsw(-241306723, string("ytbWQUcytSwSQwrznBtfRrsTJCuHJKInkyRTNUhrZViuqImZheBiqmjZLfPltkMoyqsZRChYWEqfcPTnDNHNETboWGRdvtKMIzSdefcYiEcBsrcxX"), -570056.5457078865);
    this->haVxgU(string("tg"), true);
    this->HVNXMO(2001818850, -452779.74913958024, true);
    this->HjxWEP(string("FHvhaCZuyXOyTQFfGkGCbJNNLTPMmiCyulJtnzlWGjCongDCwfJJyeZvxuJfOfrFFqUpyAZvuoNGofGMECoBPGzfWxWxEfgimExZNaMeTdwFaXNhIfSEynlCbsjpm"));
    this->nvWRORsUdEPInA(-737876281, string("CRdNrZhkbFZEtrcCdxKlDMEVQrZEpnJfvgmQTdkNXUXoRvBGSGwYpGjRIItlWyndPescPmqQORtlkaKqhIRxklxKxcAAkcvHyhIHUEcHPTmcUAcvsnINW"), false, false, true);
    this->tyCqiMKudlXHMqHf(-1333462104, string("jYkTfxHBUHhqCEupBZZQsdDveSKAriJCismoRJbLPSTHIPRvkajXqcneRHLHorizUPjrCdajYUzXrgfzuDGGuQTCCGCKJqYHrasOOjkHiKGCcCFGhbRwlexxCQQKzYTyHiHONQfPOFwddnVoHfREFqrisvjOzugmWzBlhrWrelKRJSMFuDluPTkeKTToOmWgajFhDVXSfjVwAnGtxVsHZRjjKbCGIeoSVWDJPjPcVbWpHefcLxkU"), string("qGqtCSjDOsOCbSIopgjxEmFtGyauuOPTTyEzCcvtlmylWLvEKWOyfKgTEUaobIHbiZaGQxTpXoGMCiEKbTKXcoYNNPrLefJolBZxehPIIOwDVVmytrIKeNbiZpnhNExcvAZOhDlmOQbZxRzRw"), -227511.32883501393);
    this->UOmlzFXBPglBR(string("xhHMhMZpUiSnMjWYskafXVSZHJbcnTgpG"));
    this->hPBsyGNXqfo();
    this->IbmQrRRTnZGvh();
    this->OYuzYGYaujBGMa(-229666587);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GUBEEIvSWxdnFhXn
{
public:
    bool WIFTkFSfXW;

    GUBEEIvSWxdnFhXn();
protected:
    int lCYWP;
    int nckeOYPAuqmRuOsJ;
    int bOOQiBqygoLrKEs;
    int CvOgAbkvcdSKjT;
    string xtHtZmyK;
    int TthAosSRTQJGou;

    int MYfHjpXL();
private:
    string WMLQvdaGusYtSGQt;
    bool zQwXlN;
    int SmpluEoNjJf;
    bool IvOMzsPXGWAT;
    bool yhFWflHeQBhcn;
    bool PRoMrdIUsDarL;

    int KZWIQhB(double bknGlfjQgbPKbnct, string VCzcpRIbBYJt, int YgpGpm, double WEGhRlNGlk);
    double cdaBHZKlywP();
    string kdNwTZrQhzhhoQeG(bool GWDWROJfBevW);
    bool JpOKAUYNECSnXyK(string IphjZaF);
    bool wQxLjtd(bool zeJPEbrzS, double RqSlAJgoJKj, double pHqZLOnVNCcY);
    bool rbKfPMM(double XtbXXEonjMGrxk, string kydyKhaOm, double nDTYRRZLPV);
    void cISBkKl(string GVENXQ, string VmCEPJVN, double CXRrmihM, int yYBEeItVsOhpX, bool cMDMIvgdmC);
};

int GUBEEIvSWxdnFhXn::MYfHjpXL()
{
    double hOOkrc = 478767.1189046756;
    int oYobRDwqTKy = -561229764;

    for (int WKlwsx = 953543865; WKlwsx > 0; WKlwsx--) {
        oYobRDwqTKy *= oYobRDwqTKy;
        oYobRDwqTKy /= oYobRDwqTKy;
        hOOkrc += hOOkrc;
        hOOkrc += hOOkrc;
    }

    for (int HeHPSRuGrztuc = 1792023760; HeHPSRuGrztuc > 0; HeHPSRuGrztuc--) {
        oYobRDwqTKy -= oYobRDwqTKy;
        hOOkrc *= hOOkrc;
    }

    for (int GYRpvvzmrmtkhn = 1325494777; GYRpvvzmrmtkhn > 0; GYRpvvzmrmtkhn--) {
        oYobRDwqTKy /= oYobRDwqTKy;
        hOOkrc -= hOOkrc;
        hOOkrc /= hOOkrc;
        hOOkrc -= hOOkrc;
        hOOkrc -= hOOkrc;
    }

    if (oYobRDwqTKy <= -561229764) {
        for (int vfqkOfg = 211775907; vfqkOfg > 0; vfqkOfg--) {
            oYobRDwqTKy *= oYobRDwqTKy;
            oYobRDwqTKy = oYobRDwqTKy;
            hOOkrc = hOOkrc;
            hOOkrc -= hOOkrc;
        }
    }

    if (oYobRDwqTKy >= -561229764) {
        for (int pzQPS = 930780369; pzQPS > 0; pzQPS--) {
            oYobRDwqTKy *= oYobRDwqTKy;
            hOOkrc *= hOOkrc;
        }
    }

    return oYobRDwqTKy;
}

int GUBEEIvSWxdnFhXn::KZWIQhB(double bknGlfjQgbPKbnct, string VCzcpRIbBYJt, int YgpGpm, double WEGhRlNGlk)
{
    string bQTiNNlQHAZa = string("YAqMWNqSeQGlT");
    double jcXLSpjy = 685060.4129436929;
    string QghfCU = string("dWwYMfUJeKvyPkFytgfOCXoArCBCtduARIUjrCUqWPieSWPxZZbaLxVVeobcSzHVWfZgJvqStjWSinhBJBOsJUwyMIXZTfmjtpDMnWWTrguTiehtNiaWDyvKyRBJEEAIfxCBjVbgNQcnqEhxZvUvFpmSYrzzOLGZmzUHWDFYBCzbtnmvAXXTTLAxHcANJcOXOjLWJJxSFAEOPw");
    double JQjymkYCicFMLqs = 1033926.5567132321;

    if (JQjymkYCicFMLqs > -797038.8599517404) {
        for (int mCHmtCSnTKhNABr = 1653039802; mCHmtCSnTKhNABr > 0; mCHmtCSnTKhNABr--) {
            VCzcpRIbBYJt += VCzcpRIbBYJt;
            bQTiNNlQHAZa += QghfCU;
            bknGlfjQgbPKbnct = bknGlfjQgbPKbnct;
        }
    }

    for (int dKqiSbvAS = 1490594510; dKqiSbvAS > 0; dKqiSbvAS--) {
        bknGlfjQgbPKbnct = bknGlfjQgbPKbnct;
    }

    for (int GbkRLCadFzeqK = 2114304619; GbkRLCadFzeqK > 0; GbkRLCadFzeqK--) {
        bknGlfjQgbPKbnct *= JQjymkYCicFMLqs;
        WEGhRlNGlk = JQjymkYCicFMLqs;
        WEGhRlNGlk -= JQjymkYCicFMLqs;
        QghfCU += bQTiNNlQHAZa;
    }

    return YgpGpm;
}

double GUBEEIvSWxdnFhXn::cdaBHZKlywP()
{
    int ijOdWstxJO = 427441529;
    string FWAGhqzUPmjggMA = string("RhuIwZSZAZGoXSCOqgpUdhPNkBtlZYYEGFGITnnxdGovyzBjKRdvmoYGvGOOzSTBCNtnBwabvKSXBwJbhXNVOZrYGyznOKHBlBriDMBpfeqqnDozKFAxllPMYWamjvjWTPJZvPKdjcylElhfznaIsXfZQinbUerEYsavRkbwOKTVLbIwffPGccfoDpYpiqqZnbVlmmjGHMRhLyOt");

    for (int AbAkKEZSNSp = 279808547; AbAkKEZSNSp > 0; AbAkKEZSNSp--) {
        ijOdWstxJO /= ijOdWstxJO;
        FWAGhqzUPmjggMA = FWAGhqzUPmjggMA;
    }

    return 934246.8568821097;
}

string GUBEEIvSWxdnFhXn::kdNwTZrQhzhhoQeG(bool GWDWROJfBevW)
{
    bool rqkaHiXlYvxaoi = true;

    return string("MOODPiCtMhxlHOqdWzhJJFHERxICvQJIyHaGYIzOYlrSdtRn");
}

bool GUBEEIvSWxdnFhXn::JpOKAUYNECSnXyK(string IphjZaF)
{
    double luKyWXzKtItjZ = 805890.9554462592;
    bool fvehwyOsq = true;

    if (IphjZaF < string("ZNGnIOMdRFEsRLClDBtuvcXggtfHVvAPFpUOQvEekTgMOyIwrQUcDEEfMBUkNXmsyPYBKTkpXOnGzXzMnMalBdKmdFKlLROqavcWscbbsnKoJOVcsoHwNQeLlELFSLigSJfYlNAIHgiOZIDhivXerxnyKsANMLmDGkJkmVJeDSOoEF")) {
        for (int tUscgVem = 1663507699; tUscgVem > 0; tUscgVem--) {
            fvehwyOsq = fvehwyOsq;
            fvehwyOsq = ! fvehwyOsq;
            fvehwyOsq = ! fvehwyOsq;
            IphjZaF += IphjZaF;
            IphjZaF += IphjZaF;
        }
    }

    if (IphjZaF == string("ZNGnIOMdRFEsRLClDBtuvcXggtfHVvAPFpUOQvEekTgMOyIwrQUcDEEfMBUkNXmsyPYBKTkpXOnGzXzMnMalBdKmdFKlLROqavcWscbbsnKoJOVcsoHwNQeLlELFSLigSJfYlNAIHgiOZIDhivXerxnyKsANMLmDGkJkmVJeDSOoEF")) {
        for (int rqjUcNUDtSJFqK = 216372884; rqjUcNUDtSJFqK > 0; rqjUcNUDtSJFqK--) {
            luKyWXzKtItjZ = luKyWXzKtItjZ;
            luKyWXzKtItjZ += luKyWXzKtItjZ;
            IphjZaF += IphjZaF;
            fvehwyOsq = fvehwyOsq;
            IphjZaF = IphjZaF;
        }
    }

    if (IphjZaF <= string("ZNGnIOMdRFEsRLClDBtuvcXggtfHVvAPFpUOQvEekTgMOyIwrQUcDEEfMBUkNXmsyPYBKTkpXOnGzXzMnMalBdKmdFKlLROqavcWscbbsnKoJOVcsoHwNQeLlELFSLigSJfYlNAIHgiOZIDhivXerxnyKsANMLmDGkJkmVJeDSOoEF")) {
        for (int QDlxaBBExm = 1702646878; QDlxaBBExm > 0; QDlxaBBExm--) {
            luKyWXzKtItjZ *= luKyWXzKtItjZ;
            luKyWXzKtItjZ = luKyWXzKtItjZ;
        }
    }

    return fvehwyOsq;
}

bool GUBEEIvSWxdnFhXn::wQxLjtd(bool zeJPEbrzS, double RqSlAJgoJKj, double pHqZLOnVNCcY)
{
    bool psIqVtVLG = true;
    string GeoEACXtRuSJvxM = string("pGueDEgxBsPfrxAPSMvNbxKCQqUBTfPWpfcFKGjSIZccnjKzkTj");
    double uQpvBkUvSMR = -733605.9046013006;
    double ykyzAbkCqwrfz = 399623.9919012057;
    int bzRvYjXkgj = -363521578;
    double iFBJnRlsh = 741314.4691101628;
    double POnNnduY = 720994.2481465783;
    double fpoyvADbC = -711447.5549409415;
    string hAxEcxGAu = string("raahlJ");

    return psIqVtVLG;
}

bool GUBEEIvSWxdnFhXn::rbKfPMM(double XtbXXEonjMGrxk, string kydyKhaOm, double nDTYRRZLPV)
{
    bool dKjMqgvugUCtS = false;
    bool TTPNGWG = true;
    double JEFWKvRoXGGw = 485122.34608229477;
    double NwyAKIipv = 210684.44233394766;
    double ZPbTXRWLHYeZuxP = 176405.854132622;
    int ANTypusDJw = 1054990488;

    if (ZPbTXRWLHYeZuxP >= 176405.854132622) {
        for (int LHILbUgKN = 1425851602; LHILbUgKN > 0; LHILbUgKN--) {
            XtbXXEonjMGrxk /= ZPbTXRWLHYeZuxP;
            nDTYRRZLPV /= XtbXXEonjMGrxk;
            dKjMqgvugUCtS = TTPNGWG;
        }
    }

    for (int hGdGYkIVsAscXTN = 1438086363; hGdGYkIVsAscXTN > 0; hGdGYkIVsAscXTN--) {
        TTPNGWG = TTPNGWG;
        JEFWKvRoXGGw /= ZPbTXRWLHYeZuxP;
        ZPbTXRWLHYeZuxP = nDTYRRZLPV;
        ZPbTXRWLHYeZuxP += NwyAKIipv;
    }

    for (int eyXVbYkQyp = 941969477; eyXVbYkQyp > 0; eyXVbYkQyp--) {
        XtbXXEonjMGrxk *= NwyAKIipv;
        ZPbTXRWLHYeZuxP /= nDTYRRZLPV;
    }

    if (NwyAKIipv != 485122.34608229477) {
        for (int giYQBIBHwJqvPSbm = 183757092; giYQBIBHwJqvPSbm > 0; giYQBIBHwJqvPSbm--) {
            JEFWKvRoXGGw *= JEFWKvRoXGGw;
            ZPbTXRWLHYeZuxP = XtbXXEonjMGrxk;
            NwyAKIipv = ZPbTXRWLHYeZuxP;
            NwyAKIipv -= JEFWKvRoXGGw;
            JEFWKvRoXGGw = JEFWKvRoXGGw;
            nDTYRRZLPV -= XtbXXEonjMGrxk;
        }
    }

    for (int swaaqdteiDnhg = 1824884363; swaaqdteiDnhg > 0; swaaqdteiDnhg--) {
        nDTYRRZLPV /= JEFWKvRoXGGw;
        NwyAKIipv *= nDTYRRZLPV;
        dKjMqgvugUCtS = TTPNGWG;
        NwyAKIipv /= ZPbTXRWLHYeZuxP;
        nDTYRRZLPV -= JEFWKvRoXGGw;
    }

    return TTPNGWG;
}

void GUBEEIvSWxdnFhXn::cISBkKl(string GVENXQ, string VmCEPJVN, double CXRrmihM, int yYBEeItVsOhpX, bool cMDMIvgdmC)
{
    double mQEfnZQUR = -598170.6221250271;
    string iIZEXhkC = string("DzLkihpCDEPNqdgFRYgKKjrWihrgchjXXSTxAHpGlZulnqroLnNSKhzkOcQjSxpvvIodqvMdynuifAeppAKeyNYdWtgHvCzYiLGOTmBnmgICFlVNOUtovlfOKGIZRJffVOOhFKisaZehHIjdNtAbpoEGjTQxKbpWTyNWhlKMXmgmbYTIvBhTLgUbQwDizfBQsjEvFgrzGGiezbPRedrZxeeZhccwOrbAdfhCyDLHfNJiNJqNBn");

    for (int xdOskBBRUsbBA = 1064318733; xdOskBBRUsbBA > 0; xdOskBBRUsbBA--) {
        iIZEXhkC = VmCEPJVN;
        mQEfnZQUR /= CXRrmihM;
    }

    if (GVENXQ == string("kLYzSDcrvOtLyvWCRzCsffejEdYpSWcllkIlxclInWXQIJcTlXGIdOMsMQwTqhYymemOjHojOdIyUjrEQEUWCahmQlgMKOkPTQgzgRWoIJpSIdhdksmQqnZhXgchDPataUIOPncpoLEksbFZANRJqcXuvulQffJUZhxbZUYJd")) {
        for (int WEhGsaLrn = 776252818; WEhGsaLrn > 0; WEhGsaLrn--) {
            cMDMIvgdmC = cMDMIvgdmC;
        }
    }

    for (int pVmgVQOsxlxcrPDq = 1877816351; pVmgVQOsxlxcrPDq > 0; pVmgVQOsxlxcrPDq--) {
        GVENXQ += GVENXQ;
        GVENXQ = VmCEPJVN;
        mQEfnZQUR /= mQEfnZQUR;
    }

    for (int raEnZQ = 220722071; raEnZQ > 0; raEnZQ--) {
        CXRrmihM += CXRrmihM;
    }

    for (int oUzjRtrJHWSUhp = 1097146550; oUzjRtrJHWSUhp > 0; oUzjRtrJHWSUhp--) {
        GVENXQ += GVENXQ;
        yYBEeItVsOhpX = yYBEeItVsOhpX;
    }

    for (int fwRXAaVqNkWpFyA = 209583175; fwRXAaVqNkWpFyA > 0; fwRXAaVqNkWpFyA--) {
        GVENXQ = GVENXQ;
        mQEfnZQUR += CXRrmihM;
    }
}

GUBEEIvSWxdnFhXn::GUBEEIvSWxdnFhXn()
{
    this->MYfHjpXL();
    this->KZWIQhB(-797038.8599517404, string("wCxigVCsOkuPDNQBHqVljokGSyMrPQPFEqqajDloccEbrofRuXgtibfRKHnMSnDirvkjhOLczRWflfNTuTcVDmOnJOxwJAzmuoixhfwUDRUkhWxeqzuGnLWfVvwYiTgRZdjhFkdarLGduGTPQFsaYNypiMQFpFtmyrHdUXzjOvBwNIysPECXmwDDGrexdRZvuGkepOwtdqacSF"), 491508726, 915258.0527399578);
    this->cdaBHZKlywP();
    this->kdNwTZrQhzhhoQeG(false);
    this->JpOKAUYNECSnXyK(string("ZNGnIOMdRFEsRLClDBtuvcXggtfHVvAPFpUOQvEekTgMOyIwrQUcDEEfMBUkNXmsyPYBKTkpXOnGzXzMnMalBdKmdFKlLROqavcWscbbsnKoJOVcsoHwNQeLlELFSLigSJfYlNAIHgiOZIDhivXerxnyKsANMLmDGkJkmVJeDSOoEF"));
    this->wQxLjtd(true, 223014.6774106474, -517651.9416012307);
    this->rbKfPMM(-913066.2574303829, string("jSGNusozkAnFSHiPkQjsJRXzDBiYAvfwNChZqWijZjiNxHPtnDcgucWwVZHNWQMHMQOCAhOCABlVbHcweIQTKyjqvomtROKFiDHpxofIqcROHHlRcMYPvOFkqAhzyTwyPJCWmRfaZJbXtCaEjCjK"), -125042.48341932498);
    this->cISBkKl(string("fIjQdvZFfwitgKKnYcocifETBWGGUufeUauOwBoNTpsDDJEbubezxpyamfkmPLDWVfnEUSENOhuAwlKoCYYNyVhBdaYWLQSgUChjlUeOsrGYfDZDJsTfFvuLWLhJmCxgYaNRQIMGFrwQmhXKPmQrMVBVcgzlQPWkpdjDnaquNCgQegJbOtoTJZkFfUgnhVBFXARnrRJVOvfWkMPeMAfOKajrWEHncZixPyCkFOeuTa"), string("kLYzSDcrvOtLyvWCRzCsffejEdYpSWcllkIlxclInWXQIJcTlXGIdOMsMQwTqhYymemOjHojOdIyUjrEQEUWCahmQlgMKOkPTQgzgRWoIJpSIdhdksmQqnZhXgchDPataUIOPncpoLEksbFZANRJqcXuvulQffJUZhxbZUYJd"), -887618.4310602574, 25267363, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YFYyHITUqMnwj
{
public:
    string njYkL;
    bool ePJfndDqeFi;
    bool NNIbrK;
    int dwmsZQsEj;
    int VkAJwqZKDqtaSd;
    string dqCqK;

    YFYyHITUqMnwj();
    void UxVUnLQPImD(bool kPhdD, string aYqrZMHrYDdQ, double wsYtktolvI, bool QBixLiHugWpSgLlB);
    int dAcgoGW(double vyGcunqsNForanl, string INXoKHSZeiy, bool EMtliMoWoqLR, int DwyPxARNTmL, bool bScqKdIgvIKEBe);
protected:
    int iMCTRpowj;
    string MWXuPLmOvtHGgHuk;
    double RYrqP;
    int kPwdzczfo;

    bool skNXmx(bool symPDISLrbkUpEDH);
    void bQsgpd(double DYyAyFThHwMVI, bool NEDgGEfDRyhVT, bool BNKyDU, bool COkotMcBYQaVV, double WuSgnFTeu);
    bool fWpuYkFuLQTU();
    void JWbnGaDVXIUpBuXH(int SgJqjtGIIzV);
    int cTIcz(bool cxiNvdHfNeuybkJc, int tVKsWJoVif);
    string iTtZzPCpsifsv(double ikNSHJJvDlWmqJEe, double qrQrJFGAU);
    int HwroqLB(bool NzXyOGXtNizUlYpr, double ElAMsDdt, int XIGSGZeiqX, string QxJltYY);
private:
    double GHdcbxNW;

};

void YFYyHITUqMnwj::UxVUnLQPImD(bool kPhdD, string aYqrZMHrYDdQ, double wsYtktolvI, bool QBixLiHugWpSgLlB)
{
    int WafVVkDfEEDq = -1353038889;
    bool YGyAYZKAdBZtED = true;
    double mvEiTqm = 44738.29162590653;
    bool SnXSgSsLev = true;
    int vHPIKAHRIncGZkbS = 448655964;
    string WmUEbAyGhM = string("ytgvqMTxAVFKtGODgjmmqBPNYRDSSTeKGvNByUvgdhVylXFRBwgrhHmb");
    int XwsvNah = 1998151432;

    if (wsYtktolvI == 44738.29162590653) {
        for (int SZBZLnz = 1979060123; SZBZLnz > 0; SZBZLnz--) {
            QBixLiHugWpSgLlB = YGyAYZKAdBZtED;
        }
    }
}

int YFYyHITUqMnwj::dAcgoGW(double vyGcunqsNForanl, string INXoKHSZeiy, bool EMtliMoWoqLR, int DwyPxARNTmL, bool bScqKdIgvIKEBe)
{
    bool SFuhPzxoigbh = false;
    string gpXfGJMdnEqQ = string("AgwTg");
    string PNmyeiThOQMznZa = string("hFnKqETTLUtLvpbRkkGRpTVEQADfevOKvautPuGqeCSzFMneoPOpSrzonLUSSJwGVXiXgTcDTrWhxsIoyUcpIHKqnMLtgkoZhcdNvXLnVpAxLNBzaTYsQRRilAGFrZzQSeyfDfAceAYWyYHCOOCXULnrzQUiAWUQuGWxwCRDBABMZSWDTubDNjeDHKFPcyZzRPDDKLQnIsZploZvXaCeJwWNCZJftI");
    int TkfvGKhoRYos = 594740076;
    int rZeUPdBDBeRwVS = 588048945;
    int QHNdVHIBMSUdDNrj = 1639889280;
    string YibjAEz = string("dyAjsjNaLDJYyKoSJwBvQMKWlDEFuCTXSYsFrlTWEhyhpbSpqcgfeSRABJqFcZMfzOuFHnOAgvGyLDTzPRHa");
    double omNxxvUAzOhsVs = 111713.27395529016;

    return QHNdVHIBMSUdDNrj;
}

bool YFYyHITUqMnwj::skNXmx(bool symPDISLrbkUpEDH)
{
    string rnBQGoKTqrQWE = string("akAnyIAFyoEHEKP");
    bool AoMMUjvPDuEnWMb = false;
    double BMpujdVsOFF = 738517.268152291;
    bool gnVElIkRhhix = true;
    bool zwzQCm = false;
    bool ysQmDZiFHFzh = true;
    int SyRXhIcqlKw = -2026381825;
    double XWdeMfxUKf = 65904.01254021675;

    for (int lWaMC = 543287308; lWaMC > 0; lWaMC--) {
        symPDISLrbkUpEDH = ! AoMMUjvPDuEnWMb;
        gnVElIkRhhix = ! zwzQCm;
        symPDISLrbkUpEDH = ! ysQmDZiFHFzh;
    }

    if (zwzQCm == true) {
        for (int wSAyZfJPOa = 1806507204; wSAyZfJPOa > 0; wSAyZfJPOa--) {
            AoMMUjvPDuEnWMb = ! ysQmDZiFHFzh;
        }
    }

    if (AoMMUjvPDuEnWMb != false) {
        for (int FpnZawpiaAcrbF = 853122453; FpnZawpiaAcrbF > 0; FpnZawpiaAcrbF--) {
            zwzQCm = symPDISLrbkUpEDH;
            XWdeMfxUKf = BMpujdVsOFF;
            ysQmDZiFHFzh = ! ysQmDZiFHFzh;
        }
    }

    return ysQmDZiFHFzh;
}

void YFYyHITUqMnwj::bQsgpd(double DYyAyFThHwMVI, bool NEDgGEfDRyhVT, bool BNKyDU, bool COkotMcBYQaVV, double WuSgnFTeu)
{
    bool nxFXfpHjL = false;
    bool cVuJOjJSPtBAH = false;
    int xaKzAkyq = -349506811;
    string HHJHdmfmcLuzHOXE = string("dGzmyJwgqwpaaWCvsKCbEwCKSysquMfYAeNRfrIioXcKsYqhidNqNkDkxqseLqRCeAewQKSKuYawUOVtLWwnkbXYBYNRhZslTyHmsAeizxKlkpQmKzdgwhIRekgWcjrFoYcvQxbKswBcIRmPKazVAYYbGhRhmptJqmz");
    double MmfXFrghoy = -86710.58593880078;

    for (int cXMjstOnNoLYx = 1419914172; cXMjstOnNoLYx > 0; cXMjstOnNoLYx--) {
        BNKyDU = ! cVuJOjJSPtBAH;
    }
}

bool YFYyHITUqMnwj::fWpuYkFuLQTU()
{
    double avWKIvi = 1029076.764299554;
    bool MUPfCkwmeuj = true;
    string zAMMFBZRxwHfm = string("pYVFsGnRBqqWE");
    bool zpfgtNLAwMWSdj = true;
    int uOCDVYixEIBESPnc = -359710381;
    double OiJvczeHgrI = -68453.56346514288;
    bool uZYlHQE = false;

    for (int luTROtw = 2090890112; luTROtw > 0; luTROtw--) {
        avWKIvi /= avWKIvi;
        zpfgtNLAwMWSdj = uZYlHQE;
        OiJvczeHgrI -= avWKIvi;
        OiJvczeHgrI -= OiJvczeHgrI;
    }

    for (int mMrvse = 514586661; mMrvse > 0; mMrvse--) {
        uZYlHQE = uZYlHQE;
        uOCDVYixEIBESPnc /= uOCDVYixEIBESPnc;
        zAMMFBZRxwHfm = zAMMFBZRxwHfm;
        uZYlHQE = ! uZYlHQE;
    }

    for (int henkG = 560021745; henkG > 0; henkG--) {
        OiJvczeHgrI /= avWKIvi;
    }

    return uZYlHQE;
}

void YFYyHITUqMnwj::JWbnGaDVXIUpBuXH(int SgJqjtGIIzV)
{
    string XaFjLEaqFCGEMA = string("gjuOIxluUGRSMVzxwHhsUrjoWeSzNUwmVLWNJGbcvLdfshscEGKvfPsQEmHqOxzsCUCwPUepvMLzFWTKkmPELUENiigsjBhAtwfdKzKgXQbBiEtBNYUbEVXpWdzstVMApWoFDFrzKewgxpMgEnYCQKqTQeWfCAvhczQRednBjpptxYZOGVHadLUkFDijrhsEghBYncjmCllMrghsYbn");
    bool KzvmCwSusRNkIU = false;
    int hFISPQ = 1788895276;
    bool tDMQhYOzwi = true;
    double QlxSOsOFVWWRP = -724189.1314092762;
    bool inyCJIqh = true;
    double CqzxoDyUVZQek = -519687.64639094385;
    double OZDYYeTWVJOmeCP = -439517.96792639594;
    string HInPGnxGUBVy = string("NclumjiubgRBNMssARhxDZYenlDqfcgHPdtqbKtqpAshLmmHiZccznFLANOSKCwqkxqHzhCgjYCesHfuEzgCsAlohebJNxulcbqdaDSlCiZgZyrrLtmCpxVeWeuDTmOrFSNuyfRvOb");
}

int YFYyHITUqMnwj::cTIcz(bool cxiNvdHfNeuybkJc, int tVKsWJoVif)
{
    int VTHVgyhQM = 2021047685;
    bool SwyTDtERYI = false;
    double TdCSNyEYKAC = -94665.67760431269;
    double LWvaLSlQQ = 186951.1983619907;
    double ambkrDtEpZbovSp = -83972.70752068413;

    return VTHVgyhQM;
}

string YFYyHITUqMnwj::iTtZzPCpsifsv(double ikNSHJJvDlWmqJEe, double qrQrJFGAU)
{
    int xlgrNyTkc = -1420770357;

    if (qrQrJFGAU > 15429.7694441667) {
        for (int slIFspbmcJWJb = 772669259; slIFspbmcJWJb > 0; slIFspbmcJWJb--) {
            qrQrJFGAU -= ikNSHJJvDlWmqJEe;
            ikNSHJJvDlWmqJEe -= ikNSHJJvDlWmqJEe;
            xlgrNyTkc /= xlgrNyTkc;
        }
    }

    for (int yWNyGcQ = 787806934; yWNyGcQ > 0; yWNyGcQ--) {
        qrQrJFGAU += qrQrJFGAU;
        qrQrJFGAU *= ikNSHJJvDlWmqJEe;
    }

    for (int xhnKdGGVbtLSZuPg = 413468799; xhnKdGGVbtLSZuPg > 0; xhnKdGGVbtLSZuPg--) {
        ikNSHJJvDlWmqJEe = ikNSHJJvDlWmqJEe;
        ikNSHJJvDlWmqJEe /= qrQrJFGAU;
        qrQrJFGAU = qrQrJFGAU;
    }

    return string("CzMaTmlSpKkeXEOfddxjcZMVaoZmYNOaLubniYtL");
}

int YFYyHITUqMnwj::HwroqLB(bool NzXyOGXtNizUlYpr, double ElAMsDdt, int XIGSGZeiqX, string QxJltYY)
{
    double NqQTcjwsVgzUejds = -433440.2507817281;
    double lbxRQGbPZ = 55736.0620579167;
    double mPHPHhe = -200510.72292904666;
    string DIrwFYE = string("TQHRyHJRdSapekrGposrUTMZiulsEpLopJejgmPhWokNaqUnWvzbGORgOmBSimwrmvDdmFfGCMRroQksZwwleYsHZhLYTSJd");
    string cdSkoiqlmmlx = string("FIdafZAntLkGbfMENQzSZrKjRdiTDBlngyqqQhQautASqdpVonGglDBnlYEGxCPIgmjzdUAkRAOCWlqswIHbcSHXCzg");
    int FxiDU = -1156865296;
    string GbcxW = string("tcMveSYcFkLErGQqeLmcDGeFliJevUNYtPbdHIwPnqsAbPkrJPkuaUXeiHifXqISlajLvxZDHsOQjnAenLSnDJYRGBxSnsPgHnSDyyzJuqZNmSYPNLvJwoqTJHQeFFwZqjEofWmTOUmqjVnygxwxCTJcEpGhkNvYZGDBbTEpRvCAsJYAnYfkGoWgDDZqjclIDQlKfznmIEbTSEVRIMd");

    for (int hqFxufODBfegjCU = 157775268; hqFxufODBfegjCU > 0; hqFxufODBfegjCU--) {
        GbcxW = GbcxW;
        ElAMsDdt -= ElAMsDdt;
        GbcxW += DIrwFYE;
    }

    for (int lLRfwAqNGz = 383537343; lLRfwAqNGz > 0; lLRfwAqNGz--) {
        mPHPHhe += mPHPHhe;
        XIGSGZeiqX /= FxiDU;
    }

    return FxiDU;
}

YFYyHITUqMnwj::YFYyHITUqMnwj()
{
    this->UxVUnLQPImD(false, string("csXuzOoyRwZameqyVgIzWdkdbNODbIveVBPPNHjpPlUYSLSpgudrevNQBnoYleNzDMixEvdRQzuGkPetCBbXpOqkNVpvfosXuibGwtDIwrvUgfItaIlUZINVGdBbYJqokKTsHRQkOjmzDkQqVwknEsLWooGOSXJueFsUAb"), -226972.19472964838, false);
    this->dAcgoGW(960199.9236983738, string("ULeEBHOviNshBiKPSbQuhraYjnwEndaLphbnfDdWuvHxCPjikSCdXtoQzpVzrxeTLtroYsOYJJvXfdReEOREettxxQxMNTMbOlHGDrnjEpbXBaeOkeNtzlQeoZSjGmfAWwTggeCijCpvGxqJ"), false, 534394548, true);
    this->skNXmx(false);
    this->bQsgpd(942366.9158284488, false, true, false, 604179.5700034918);
    this->fWpuYkFuLQTU();
    this->JWbnGaDVXIUpBuXH(1300415727);
    this->cTIcz(true, -1239169472);
    this->iTtZzPCpsifsv(195549.98738131335, 15429.7694441667);
    this->HwroqLB(true, -31868.398431242742, 1709271420, string("UMpjnQYgyzcjAlyxHvCQSQYBXrJUtxflSdXuXLzrisrREVHuEGcXqclikavFBydxotghvCViLeDXYfrDTTYOwxdMakMJsJljTFGlDsqbIajmFBKBpoFolCuUmCshaqvXrsWajtCgRrsgucNrcmNnQqIkXTqqEcvBqNxlUDIgLZdVpQZgHdZXUrFTwCZzZIhSIpsFYKAuzEilsNrTzRfLqWSpBktRTyuhfaKA"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kBCPldYGTnbmBY
{
public:
    int CAnXJUhfvEXBOq;
    int aIPkSNDvvL;
    double zZmzdpZeskBAH;
    double MRNNTUoeUbjbLb;
    string NRomMNIHA;
    string oDkszsu;

    kBCPldYGTnbmBY();
    int DkUytJJp(string PVWXaKN);
    bool YBgoG(double jWTFlvNiY);
    bool APlYxtDVYvStoLH(double zFtdDIKBkGNex, string vUYhqNEFpv);
protected:
    double DdGCvtH;
    double zLVuKjyf;

    string couFQtDsZzRa(double EGEsMDzGxoCp, string YjbRCUEFHeJpt, bool ttRDWPnHqWVsPbDc, double BkHWM, int stCpzd);
    bool GmLkWUnTZRuOzpBl(string vJzVfpiAnhsm, int krntyVlOKJlwk);
    string uSKJPOvWi(double rBnji, string xEADcZB, string lsZDjJ);
    int PrqrnxAAAoo(double rSeOMjOVzhXuEK, bool vHLgtFgKS, int gOonq);
    string lRiMQBHs(int JnBmnrScvRkzK, string YBCnPyBd);
    string EmLgOGsR(string SAlwOfDZpPjBei, bool whrCAbxuoJBYlFO, int cACKmN);
    void KrwshVUVWv();
    double kVJqhViRDNpddLD(double BECXQFqxzDFeJ, int PqTbdqROy, int YoDXajHsxo, string qBHRA, string bqQHrcZmWxj);
private:
    string JzCwfzbwEtWqYL;
    int pzRHV;

    double LKlUckhTiWUkUp(int wnqPldSywTzoWut, int dgmjKoVyCfXKk, string tGfGfSf);
    void pEAHGyg(bool VtLVkzBzrXw);
};

int kBCPldYGTnbmBY::DkUytJJp(string PVWXaKN)
{
    int GwvNxWXCNWELv = -58414880;
    string OSKsG = string("ahDeFXNjMNbqZNjDGsGMnusR");
    int hmdDMELos = -476028073;
    int FqQpjsrTlPWv = 1099918897;
    bool pKwzrvyTKSYDUOX = true;
    string kshQeCWr = string("fxKWTJcblHeeZzFObBPBVjzaqRNvksaIFRVXekLxSBNZXRWLCiijeMyTqdHSVgUTZoRXeLTWaaPlxPVsRrXgKxPcNGelAtdZUeoCgPsyhxmTdYtcnFUMAEYGtBpkKUfUoNyIhUsTOnXGSUfQQRRJGaXFakMQycaHQFrwBhBcrqFgNmPgazNeZneXngsuQlwcHmclaFXFYpOOxSXsWpwfcErQOKWbtGoiVsDXaLp");

    for (int dfwnDQT = 1590413943; dfwnDQT > 0; dfwnDQT--) {
        FqQpjsrTlPWv = GwvNxWXCNWELv;
    }

    return FqQpjsrTlPWv;
}

bool kBCPldYGTnbmBY::YBgoG(double jWTFlvNiY)
{
    bool DTBDwPxM = true;
    int HHFIpBaCkbSn = 656861830;
    double GDRVkxpfFJ = 1044897.5055511062;
    bool MiGCZ = true;
    double CesaRzqdj = -795074.4316395684;
    double BEDZJSZqHMmP = 997781.5375548671;
    double isHLJqJRd = -816544.4296814274;
    bool RagjVtbhPxcwXwGp = true;

    for (int jVkXQeFZno = 1952088949; jVkXQeFZno > 0; jVkXQeFZno--) {
        GDRVkxpfFJ -= jWTFlvNiY;
    }

    if (jWTFlvNiY > -986081.1949044539) {
        for (int RFkpQdGLfs = 46990538; RFkpQdGLfs > 0; RFkpQdGLfs--) {
            CesaRzqdj *= jWTFlvNiY;
        }
    }

    for (int qJelhbabinWLqW = 434513971; qJelhbabinWLqW > 0; qJelhbabinWLqW--) {
        RagjVtbhPxcwXwGp = DTBDwPxM;
    }

    for (int iXpkkimLSLM = 1880779127; iXpkkimLSLM > 0; iXpkkimLSLM--) {
        isHLJqJRd = jWTFlvNiY;
        GDRVkxpfFJ = BEDZJSZqHMmP;
        MiGCZ = ! MiGCZ;
        isHLJqJRd += GDRVkxpfFJ;
        BEDZJSZqHMmP -= GDRVkxpfFJ;
    }

    return RagjVtbhPxcwXwGp;
}

bool kBCPldYGTnbmBY::APlYxtDVYvStoLH(double zFtdDIKBkGNex, string vUYhqNEFpv)
{
    string bwDNpupmPUe = string("YrlvkiSFRENEkxZqPgJKuBurFtWuATcbCfJDDvytZIVAWCwseyiPqSiMhfCJVTcpwgUclFsawQNrqexKMZEHpxHMfjHKvRyFQPJtDYZDqBniTBhQbhGhLHWAhhzLJjtaOdZ");
    bool TmuWN = true;
    double fFlrY = 941838.8628960665;
    bool rqTHWyjDm = true;
    int jYeFN = -1804226461;
    string sYoaXabYTuEoZCB = string("TAhZevpNfHbKhIJQubzwBytFtExKHcmCYTEJphOducCRhqpmDiHcLufXdkDkRsIaVfWmiEGlurqeXpCoJYtJXJWHwaBLrsUzpaTgyFcOupjAyNknfKafihJKRGgdlILTrGTWwKeHDEiNIwy");
    int txbZuriwM = 1551470615;

    for (int UxlFrDHYgAyM = 337822975; UxlFrDHYgAyM > 0; UxlFrDHYgAyM--) {
        txbZuriwM = txbZuriwM;
        txbZuriwM -= txbZuriwM;
    }

    return rqTHWyjDm;
}

string kBCPldYGTnbmBY::couFQtDsZzRa(double EGEsMDzGxoCp, string YjbRCUEFHeJpt, bool ttRDWPnHqWVsPbDc, double BkHWM, int stCpzd)
{
    string twyFiGFnBQWCztXw = string("txCeAJpwhGxLhlvdTvlKPpYHyJIsQnnTCTKOZjMNYKVaMblTjsDOMcKnTMTYsqTZDQEkJmWVvfuOaFqLuANYKgcwpGxvcHeYtbNeqpnRDVNhOqFdjoOhVGZtcKLsgUADcnXlBfdJsQozhTdjMRdnPQMsjOtduCdSOadkwPwrKJgEmtZtMBzIsFzAkVrWYmjqyDZTtuScLfAjeUKQ");
    bool PvpZFag = true;
    int zVaHzopMtcuvmh = 726328038;
    int ISjyru = 1654570114;
    int loBTNftnLoDgKSV = -876547099;
    string IzeFIBJTs = string("owNmlcayVQaWXTcEzYlkvrfGpAOyiwHqZQKJjiwihAQedPfytGiZEIbFwCAiEFlYoCtACdgxbmABGRTrkshfdzSQuWHjPhrxerPkYLfkbcEsEZYYJdGEejsZWmiGHhLnLqWDqEfibSucN");

    for (int gHIVFqCHfDR = 778797554; gHIVFqCHfDR > 0; gHIVFqCHfDR--) {
        stCpzd *= ISjyru;
        ISjyru /= ISjyru;
        twyFiGFnBQWCztXw += YjbRCUEFHeJpt;
    }

    for (int tnydfYCKmfNGgItR = 1338682440; tnydfYCKmfNGgItR > 0; tnydfYCKmfNGgItR--) {
        PvpZFag = ! ttRDWPnHqWVsPbDc;
        PvpZFag = PvpZFag;
        zVaHzopMtcuvmh -= loBTNftnLoDgKSV;
        ttRDWPnHqWVsPbDc = ! PvpZFag;
    }

    return IzeFIBJTs;
}

bool kBCPldYGTnbmBY::GmLkWUnTZRuOzpBl(string vJzVfpiAnhsm, int krntyVlOKJlwk)
{
    bool zTxoksFygsTEyib = false;

    for (int XYxzZwR = 1207116915; XYxzZwR > 0; XYxzZwR--) {
        continue;
    }

    for (int ysdmUNqdZvUm = 400495512; ysdmUNqdZvUm > 0; ysdmUNqdZvUm--) {
        zTxoksFygsTEyib = ! zTxoksFygsTEyib;
        zTxoksFygsTEyib = zTxoksFygsTEyib;
    }

    for (int MBKOy = 1851330204; MBKOy > 0; MBKOy--) {
        continue;
    }

    if (zTxoksFygsTEyib != false) {
        for (int dOGwr = 439570138; dOGwr > 0; dOGwr--) {
            krntyVlOKJlwk += krntyVlOKJlwk;
            krntyVlOKJlwk *= krntyVlOKJlwk;
        }
    }

    if (vJzVfpiAnhsm < string("bdXauKMPoNCuPyiDzXyMFYZnrAuCXIVhgxTVhaMQuJ")) {
        for (int QjPaQeVGZ = 1568193696; QjPaQeVGZ > 0; QjPaQeVGZ--) {
            vJzVfpiAnhsm = vJzVfpiAnhsm;
        }
    }

    if (zTxoksFygsTEyib != false) {
        for (int aotbcEPaHjgNycHT = 666890437; aotbcEPaHjgNycHT > 0; aotbcEPaHjgNycHT--) {
            continue;
        }
    }

    if (zTxoksFygsTEyib != false) {
        for (int FvlhVtHdbgfodi = 152739218; FvlhVtHdbgfodi > 0; FvlhVtHdbgfodi--) {
            vJzVfpiAnhsm = vJzVfpiAnhsm;
        }
    }

    return zTxoksFygsTEyib;
}

string kBCPldYGTnbmBY::uSKJPOvWi(double rBnji, string xEADcZB, string lsZDjJ)
{
    string lxlnuv = string("GSnKbPAvlGHiRqmdbuLePnHctPbzrSTdwzkaitooNjKSVOfsyCwwXvXnaCjLxKTNqIMbycWoFWSFygnUDcJmyhCeLfVguEhuEmFBNxdFMIcyayxuCXmnlsNRAALsBkeeenXLqjSHJYrJNPuJbfbCzfqqMhwMIktIWJXFmmFJgGYyQDYWcVfBFKqhXkFUnXhRLScVDGmSKudljcSuIHVyGVdgUIbEKBLLWhqeAhmua");

    for (int ucbgewZx = 876042875; ucbgewZx > 0; ucbgewZx--) {
        xEADcZB += xEADcZB;
        xEADcZB = lsZDjJ;
        lsZDjJ += xEADcZB;
        lsZDjJ = lsZDjJ;
        xEADcZB = lxlnuv;
    }

    for (int tPLTlnmMcX = 267420650; tPLTlnmMcX > 0; tPLTlnmMcX--) {
        lsZDjJ += lxlnuv;
        xEADcZB += lxlnuv;
        lxlnuv = xEADcZB;
        lxlnuv += lsZDjJ;
        xEADcZB += lsZDjJ;
    }

    for (int oSdXgiNtHTDxEPz = 1446452401; oSdXgiNtHTDxEPz > 0; oSdXgiNtHTDxEPz--) {
        lxlnuv = lxlnuv;
        lxlnuv = lsZDjJ;
        rBnji *= rBnji;
    }

    return lxlnuv;
}

int kBCPldYGTnbmBY::PrqrnxAAAoo(double rSeOMjOVzhXuEK, bool vHLgtFgKS, int gOonq)
{
    double RtPWKj = -570036.7256545954;
    double mQHHyEBJs = -146344.47971931339;
    bool rxmTtiPiCuqdQ = false;
    double XrGDckW = -164207.1929492251;
    int swVScuY = -1039907383;
    double swuOtCfvOoqO = 284756.69295366143;
    string yWCMIdH = string("eWElsyZkgPSunKDwHycLsaNfWDbzEfahcFzHgrTNBFXOfqeIJgxhXgagDZcC");
    string pdIETpi = string("UZoPckLrjeiczhPJKEGcsMSLaSZMVTbbNsLFBLVdObenRQEfvXIqYJSefFqfNhpwJQlGECIjhjKwrwiShIgcEUtRTmTLNLjdQkyLpOVminpcvdQMcwMaOznskELzyhdqxyAhbslzFZRxaMXdVujwuZPKvaJpMZRaFcCoXLWXHMPupBZVggafdfKydJUnpGtxUrvqaExwbnaPZBElQHRxjxZVYCpxQUiXVnilFhuTUvGw");

    for (int qSeYkoSJaJK = 1518388236; qSeYkoSJaJK > 0; qSeYkoSJaJK--) {
        continue;
    }

    for (int yDTyTVN = 463111669; yDTyTVN > 0; yDTyTVN--) {
        continue;
    }

    return swVScuY;
}

string kBCPldYGTnbmBY::lRiMQBHs(int JnBmnrScvRkzK, string YBCnPyBd)
{
    int jjyXBIksyJIFi = -673635040;
    bool VgLYRTBc = false;
    bool jnCvTQII = false;
    string jwrAn = string("ucfBceIInTzOXXPxfURLFeINTHOyWKlzcjmGqqnXMzmhStiMZcafdwhAoZPTnblBfWBmZUKMGPMsANpeYrIJEQFcCiGBSWKcGeIXFTQWMIuGZCOEFWaLNvIBczAAmdjqVUScjKnLokwszLDNaGyYgZtQHyFJiRExrkxDhpcccgMtlMoapDfEjzptbSoeKCfxonHfWSHruIp");
    int qCXwofojLwqctzqM = -190748573;

    for (int oOapVaytzGd = 506951853; oOapVaytzGd > 0; oOapVaytzGd--) {
        continue;
    }

    return jwrAn;
}

string kBCPldYGTnbmBY::EmLgOGsR(string SAlwOfDZpPjBei, bool whrCAbxuoJBYlFO, int cACKmN)
{
    string DUNyWMeaj = string("UKiTAIQiDqPbjsVyuqExNPDhMcHiganvgNGTEHTEgzqMBDGzgOREuFBTNHPBpFAOoSovkQqOBMALEcNSCZuznzoTrDKaZoJfCvrCSTCAKNTofnXMGBTaKsJhgmwAsqavJytdXGJGRZeRcvijlnSioOQYXZfgwAxPOZNNaABvDxeYJCBDzEajtdpEkQhGjHvrJinVOPaJAqozgN");
    double NVXtKBFVgdgviFlS = -715536.9893047946;

    for (int jikEEaszc = 1923943650; jikEEaszc > 0; jikEEaszc--) {
        DUNyWMeaj = DUNyWMeaj;
        NVXtKBFVgdgviFlS *= NVXtKBFVgdgviFlS;
        SAlwOfDZpPjBei = SAlwOfDZpPjBei;
        cACKmN *= cACKmN;
        NVXtKBFVgdgviFlS -= NVXtKBFVgdgviFlS;
    }

    for (int nLoireeAyOqWWJ = 1220196152; nLoireeAyOqWWJ > 0; nLoireeAyOqWWJ--) {
        SAlwOfDZpPjBei = DUNyWMeaj;
    }

    for (int akiSoSpQCxORZHY = 1212768808; akiSoSpQCxORZHY > 0; akiSoSpQCxORZHY--) {
        continue;
    }

    if (whrCAbxuoJBYlFO != true) {
        for (int bcigUwz = 1294454434; bcigUwz > 0; bcigUwz--) {
            whrCAbxuoJBYlFO = whrCAbxuoJBYlFO;
            SAlwOfDZpPjBei = DUNyWMeaj;
        }
    }

    for (int JNvTTdYZ = 1953488844; JNvTTdYZ > 0; JNvTTdYZ--) {
        cACKmN *= cACKmN;
        DUNyWMeaj = SAlwOfDZpPjBei;
        SAlwOfDZpPjBei = SAlwOfDZpPjBei;
    }

    return DUNyWMeaj;
}

void kBCPldYGTnbmBY::KrwshVUVWv()
{
    bool mSlpu = true;
    string lrSaMUrStgK = string("OzgRnjCmnqacrDEYALLzxGlSQfHESyXWuMftuLlNYOWaXAdcUMGgpwWvosyVEuqjCiQwsXtsrkLcrUsfRrTWXcCsatWgrVCojMyywVznkcwlyWhiHpBlywaVJYolsgzsfinOrbtxgovwTEbJgrGBrZsowjTMEJrXybeFePHyPNzFkUAb");
    bool xgtEEPq = false;
    double rQZwK = 377060.13678114844;
    int gWXDgUbn = 1228928948;
    bool FDNYjsXEdVEV = false;
    string onjNAItS = string("FzTGhVRdsHmaMDbiVlqGiikXFYRxMdZpEpSMFZkbMzTMSaQOHZVTTAxTIrHRnKyeaHVLMcmfrxFhMkNECnJzuugSJjGjJRjqQPxVVSISExSbacyifKYMaRSgPYdUKgysnBjjqhwmCNzVjGWKFxkYfTQOhmeceQIyrPXCnXzvGLHtjuVMJTflBUokqLuQJsbSFJoaWEHSQqqtjNqwSQbJhEiPc");
    double BjhnCFyRrLasGC = -39296.823836282005;
    string BhUBjaCo = string("dVVmeFuhUBjovztpDgZoyjRkqOMDUYOLC");
    double SVbwBqis = -740428.3823221895;

    for (int XgRBBw = 401262032; XgRBBw > 0; XgRBBw--) {
        continue;
    }

    for (int InCWaWI = 21600114; InCWaWI > 0; InCWaWI--) {
        lrSaMUrStgK = onjNAItS;
        gWXDgUbn = gWXDgUbn;
    }

    for (int IHFjBIUHwovH = 1948996367; IHFjBIUHwovH > 0; IHFjBIUHwovH--) {
        continue;
    }

    if (FDNYjsXEdVEV != false) {
        for (int UpnDYJoe = 1623937164; UpnDYJoe > 0; UpnDYJoe--) {
            mSlpu = mSlpu;
        }
    }

    if (BjhnCFyRrLasGC < -740428.3823221895) {
        for (int jGShKBUxli = 724437290; jGShKBUxli > 0; jGShKBUxli--) {
            SVbwBqis /= BjhnCFyRrLasGC;
            lrSaMUrStgK += onjNAItS;
            lrSaMUrStgK = BhUBjaCo;
        }
    }

    for (int uKROIqkIaSHkPY = 1918785314; uKROIqkIaSHkPY > 0; uKROIqkIaSHkPY--) {
        continue;
    }

    for (int zqqamFnFJ = 2119771732; zqqamFnFJ > 0; zqqamFnFJ--) {
        rQZwK += BjhnCFyRrLasGC;
        BhUBjaCo += lrSaMUrStgK;
        rQZwK = BjhnCFyRrLasGC;
        BhUBjaCo += onjNAItS;
    }
}

double kBCPldYGTnbmBY::kVJqhViRDNpddLD(double BECXQFqxzDFeJ, int PqTbdqROy, int YoDXajHsxo, string qBHRA, string bqQHrcZmWxj)
{
    string lGzeCqGwOyW = string("LzSXPTJMkJQqItKfccSlhRruNSMrYfORStVBfBrNJZcbMMaKDuJdzWksoUfKtecTJcVFsKmhssCHBzyiDpPsLtDFIfTBfPuYJPndQekzkpXYalEOrDcSJFiTYTdgVAoIGvXBYjisnKFvmBTqEwLXIyaJjmxLbOYDcHZqAKnyokOtEhu");
    string XCsOuMBqQbPw = string("UjpMBXqXeeuyYNDKLPVgmoZBgnojxdtKueUckTnXHusldkkETnTSCRlSxWSiwOFph");
    string fBxQaZ = string("bsZfrYpStFofFOpCjcsCslr");
    bool ZuUdjnuMKryKJofQ = false;
    double GuUvxmqgReBFd = 508180.88606082817;
    bool qMMDICnMWrDy = false;
    double jhVKqdIgD = 659128.8783004745;
    int nHLBluTlYtykl = -633617958;
    double isxDBcdW = -134001.0225017576;

    for (int OOfIBaQCcDsHtmW = 731794882; OOfIBaQCcDsHtmW > 0; OOfIBaQCcDsHtmW--) {
        continue;
    }

    for (int AdZEzjNr = 1228588589; AdZEzjNr > 0; AdZEzjNr--) {
        nHLBluTlYtykl = nHLBluTlYtykl;
    }

    for (int JYgFaFdQBFDYfSyk = 259840816; JYgFaFdQBFDYfSyk > 0; JYgFaFdQBFDYfSyk--) {
        lGzeCqGwOyW = lGzeCqGwOyW;
    }

    return isxDBcdW;
}

double kBCPldYGTnbmBY::LKlUckhTiWUkUp(int wnqPldSywTzoWut, int dgmjKoVyCfXKk, string tGfGfSf)
{
    int SYteDwyAof = -243090249;
    int nOFqKCIg = 629646154;
    double WMRzqYGpfL = -911548.281855956;
    double pIjDDjxkqV = -553891.4328099493;
    int KtiDrF = -1655385107;
    bool ZBSrv = true;
    int MePNsane = 78676456;
    int wahsmNFCGPOcb = 1276222685;
    bool lNARUGpdYyq = false;

    for (int cTmzGuZyjtCUAL = 926094634; cTmzGuZyjtCUAL > 0; cTmzGuZyjtCUAL--) {
        SYteDwyAof /= KtiDrF;
    }

    if (tGfGfSf >= string("tFlKiQsPwHNtmdqHzlVuzRNVFrcLgjuJbwbuZqMVvespUWpDKTLOzSERPGvGIdAOVQzbjtAIZAQwRYilaKWWJCfMOnHiEaluPvtIZIiYojxtogkuowsMUOncYQBXlElLBuZQZMoRcuZ")) {
        for (int VymJVr = 1112290773; VymJVr > 0; VymJVr--) {
            KtiDrF += KtiDrF;
            wnqPldSywTzoWut -= MePNsane;
            dgmjKoVyCfXKk = wahsmNFCGPOcb;
        }
    }

    if (wnqPldSywTzoWut == 1276222685) {
        for (int DNKITIZN = 435610874; DNKITIZN > 0; DNKITIZN--) {
            continue;
        }
    }

    if (wahsmNFCGPOcb < -468523130) {
        for (int yNgXOj = 926618499; yNgXOj > 0; yNgXOj--) {
            wnqPldSywTzoWut *= wahsmNFCGPOcb;
            tGfGfSf = tGfGfSf;
        }
    }

    if (WMRzqYGpfL == -553891.4328099493) {
        for (int MXAvlQXCPZsKr = 1519043609; MXAvlQXCPZsKr > 0; MXAvlQXCPZsKr--) {
            ZBSrv = ! ZBSrv;
            SYteDwyAof += KtiDrF;
            KtiDrF = dgmjKoVyCfXKk;
            MePNsane += nOFqKCIg;
        }
    }

    for (int HIfvAwdX = 915037593; HIfvAwdX > 0; HIfvAwdX--) {
        continue;
    }

    return pIjDDjxkqV;
}

void kBCPldYGTnbmBY::pEAHGyg(bool VtLVkzBzrXw)
{
    bool hEPzOkhpLtmbGOg = true;
    string ekpUe = string("OpYLczOdQyrzlbsjwoKHCxKAXxKjMiEQvooHVvdkyLrttauPegYWARhMbaLHCMoIJdYMjYtHuVhnnjfLrnMhlWWGXnSVNmmuifGwRThbobaNfBRXJfaOzQEqeEIJaPljzXoVGSUiypePdPfRrDhuOcxSMTCXdhUDMewwpPkKwdfirxbGfBIfqdHNVWzSRxWBlNCWppjLSjuWFGzFqLkCosvqT");

    if (VtLVkzBzrXw == false) {
        for (int LKiotQfCkjL = 119295971; LKiotQfCkjL > 0; LKiotQfCkjL--) {
            VtLVkzBzrXw = VtLVkzBzrXw;
            hEPzOkhpLtmbGOg = VtLVkzBzrXw;
            hEPzOkhpLtmbGOg = ! hEPzOkhpLtmbGOg;
            VtLVkzBzrXw = VtLVkzBzrXw;
        }
    }
}

kBCPldYGTnbmBY::kBCPldYGTnbmBY()
{
    this->DkUytJJp(string("xXBsyNNvAxsfS"));
    this->YBgoG(-986081.1949044539);
    this->APlYxtDVYvStoLH(789684.6423215691, string("TyxhIFhaTEKuFOSkEsfjnACCnZdzNvRKsFbZfnrzZJOSLNzawhkBbqaYoMrqQmGLYgIJYzsgVPBABgXuIUNbYEWEzQpsAPhB"));
    this->couFQtDsZzRa(647096.9891831934, string("hOWYYazPfPIzppuKOexGICGohgCjzisWVeJDEpcZKIIZSiwiERzaEbO"), true, -851103.3805662503, -403728872);
    this->GmLkWUnTZRuOzpBl(string("bdXauKMPoNCuPyiDzXyMFYZnrAuCXIVhgxTVhaMQuJ"), 226724061);
    this->uSKJPOvWi(140659.50082848006, string("JcfeVfyzJysnoJkrqIN"), string("eugOowZWdHowIgqfqWCHN"));
    this->PrqrnxAAAoo(-880355.2493424745, false, 2033438239);
    this->lRiMQBHs(982953986, string("xwNlnCcfQFzrRauYXDpbIRKTXBnapbJQSxnFMnPNHpwiCcpuDMYCYAvtYcmoXELfZGrVdLTsFIlrYyHDZuRFgimtQNUIcMMojjvHSjXdPp"));
    this->EmLgOGsR(string("YlMTVhNKBuDAuNczqLUwwxnEtyPRGHpUPpTdeKDJbXBsjjpAKCitoTEPJfXEYfUbnNNzUWtXLeXfjyonknINCrtDAHajU"), true, 937764639);
    this->KrwshVUVWv();
    this->kVJqhViRDNpddLD(501750.19985657587, 649503176, 1276363943, string("CKqVejTWoSyTzUDaYJaaKyUrqJTtuNYbIbKbkPBKKhRuKZamEmpiYDRWinolCHGRmsujzWVLgJkHaxNxmMMnhsjDLmATYypxrsYdUbthBEbFRoAmaDDcPAnFLllIDkhPjptOlhCFpxbYNjmMtcNvjhuwlqhtMVUiVjMTzQZLmrkyBOvNnZyORFWVSMLZmLYRIARTfUKNlGt"), string("VcJICWVCXuWAkYGWjbpAivVAjDrbabnzxjsJSJkLuQNJGDLoXfzGWiPyDiUWWwkhbTKjzWHDxVMwkjtzlS"));
    this->LKlUckhTiWUkUp(-468523130, 913062219, string("tFlKiQsPwHNtmdqHzlVuzRNVFrcLgjuJbwbuZqMVvespUWpDKTLOzSERPGvGIdAOVQzbjtAIZAQwRYilaKWWJCfMOnHiEaluPvtIZIiYojxtogkuowsMUOncYQBXlElLBuZQZMoRcuZ"));
    this->pEAHGyg(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EmUllXP
{
public:
    bool FTAOymcNmvV;
    bool srSiUlSbQnf;
    double YAaOvYUEeZY;
    bool yBDQJLOFQLa;

    EmUllXP();
    double jmzirxpTzzHwnvM(int TozONJTefc);
protected:
    double vskKeczFMR;
    bool iUThRxLhbToIlWY;
    bool wlHLSxQwAMPvdeaV;
    double YXpqzGcsg;
    double ZVXXGSyakMGh;

    int YpSHTAS(double ZQrmccT, double XfgLZz, bool VFxiklqtxULyTG, string hXWLiHbgx);
    double hBUptV(int mIQqTYsl, bool WfJkjOweOfLoEHVB);
    int DHgxXmQF();
private:
    int UsTIJuDMQtEATkEy;

    void YfWgFAIIjV(double OECqzCdJEtJ, double wTZnOIO, int yNaPknvXm);
    string AloLcKbpwX(string gtuEMnEuF, double fMCFJAiiVIOCBNWs, int RsaAgd, double IlrvjqEalsjK);
    bool hMBXACKxyvltfClZ(bool yPNRkq);
    bool YYehWbyTzRYS(double tYloIgc, int RNyhDLMTS, string pPMPPpgMTjJL, int PRqNTTnInWUfWHxQ);
};

double EmUllXP::jmzirxpTzzHwnvM(int TozONJTefc)
{
    bool wcJxLNzLsSMdyBj = true;

    for (int HbcsTlCqTV = 1943312864; HbcsTlCqTV > 0; HbcsTlCqTV--) {
        wcJxLNzLsSMdyBj = wcJxLNzLsSMdyBj;
        wcJxLNzLsSMdyBj = ! wcJxLNzLsSMdyBj;
    }

    if (wcJxLNzLsSMdyBj == true) {
        for (int TABgzoADFYQyIl = 1763233810; TABgzoADFYQyIl > 0; TABgzoADFYQyIl--) {
            TozONJTefc = TozONJTefc;
            TozONJTefc *= TozONJTefc;
            TozONJTefc += TozONJTefc;
            wcJxLNzLsSMdyBj = ! wcJxLNzLsSMdyBj;
        }
    }

    if (TozONJTefc != -908195366) {
        for (int XCZUSPxtQfdOtm = 357706492; XCZUSPxtQfdOtm > 0; XCZUSPxtQfdOtm--) {
            wcJxLNzLsSMdyBj = wcJxLNzLsSMdyBj;
            TozONJTefc += TozONJTefc;
        }
    }

    if (TozONJTefc == -908195366) {
        for (int oyWZKScWnsgJOlti = 1998878240; oyWZKScWnsgJOlti > 0; oyWZKScWnsgJOlti--) {
            TozONJTefc /= TozONJTefc;
            TozONJTefc *= TozONJTefc;
        }
    }

    for (int dqcJsoKaLxfMrJrl = 1735727774; dqcJsoKaLxfMrJrl > 0; dqcJsoKaLxfMrJrl--) {
        TozONJTefc -= TozONJTefc;
    }

    return -316217.81834954105;
}

int EmUllXP::YpSHTAS(double ZQrmccT, double XfgLZz, bool VFxiklqtxULyTG, string hXWLiHbgx)
{
    bool CBmaOIySvaatAO = true;

    for (int NvrksA = 2112526453; NvrksA > 0; NvrksA--) {
        continue;
    }

    return 653781878;
}

double EmUllXP::hBUptV(int mIQqTYsl, bool WfJkjOweOfLoEHVB)
{
    int vebYNXoY = -2021342537;
    string VtqEgnIDxKdIyaLx = string("mcSaiLHrMtcFqwtXNKnRAlwixOJbevzTNMrbTVunHFnMljLQnQHvSdibTvaqdBLGIOlIRdrDVmCIsK");
    string GEjaapM = string("VgLGBiJxNDKjdZqEsOjFYdBQMLnFHDqGoqtGJuWaiAyvzWGdzLsmBhXfFqxaynbJzRrpFxqbyOrPodiyHveyUMYNXMaDdxmjXabNbpYtIqEakweDAfFsjmVWMEqapaAfnujEavxKLGWYiqyIaNNkbuqPOuQEUkDBpCoFkJUrxOZTqoImElgFuQYnZ");
    string iTvgRYavpgOC = string("twueGJAzdMehWaOkAsHcgsvaQwrtWYBIYgSGZyyDtiHhdJJMEoaiKBweDqVGqGndmuaDnZXrWYtVCWSVbUrqhfSDhMaZeissnhQdjXdShwvCfwXVGMQRNJ");
    int ACoNiNRVhwvmpjQj = -659039898;
    string jkkLs = string("QrujmdmYEnDstSohQHobjasdKHMMBCMfWpAMLBqQCwkvhQeQFzJFcrfXIQrAPGacxbiJqsLEVkzdaUEydxmtgQvkhMrtXqUPZpjRoswLHRWtbRcbxSLyOpnXSMzkLTkJmNlLJMsTZfzeuYAuNoFZKXmHwMDELhczAvKnvoWEAAkQHPMLTAUKPJsJXZNNIDihyCPPCnYr");
    string BvPtLt = string("BPPMXXGNMQORDSvisinmoxRuQgGl");
    double yshKKg = -270567.59092246875;
    int SKBTNwgqrHHO = -388699911;

    return yshKKg;
}

int EmUllXP::DHgxXmQF()
{
    double dgWAzhACJ = -31946.23181682514;
    double qadizCNizPWprQ = -34372.73194392432;
    int qVsNulwjABAOXNr = -1609657197;
    string PhmePU = string("hXEuERmONyMmBcZdfmubeZBdHIBsycsSMYVJPiuPreemjqpMdXwGnVVTUxYeekbcAyevsJBwKdLDUWpHLrDjYEUyXSBRcSwyHeVMMbxtStXaShMNGcboQqqDcWdUOjpjMbtvCWeiwggrUPSdSLfFtwIetrLjJOCFToQrFeqOWEflNyaIeGHgvOsGsJcMVadsxBxWklNWPrePsbhLfnclSOErpDLWONDKvNIcvJbp");

    return qVsNulwjABAOXNr;
}

void EmUllXP::YfWgFAIIjV(double OECqzCdJEtJ, double wTZnOIO, int yNaPknvXm)
{
    bool LAjcDbD = false;
    double wBjVsQMUjKl = -370762.6082804812;
    double lnaOiacgqC = -913699.0120597231;
    string RfRHHMAjyRVg = string("pknCZkfgWppJoUCwQGaxurlvFlIwKufUCb");
    bool WfRCie = true;
    string ChPOCnfeKyyVAPb = string("eBycBrkCKZPWzHvLptQEsEUZkuGTfQagOPeiXefXQeAZPZOuxtbNxFpfRnQZezRtkzBZRwDTgMcLwYSnsJyT");
    string kDBKdcWxIIJP = string("gClxwsIBthZBPmHGtQqgvhCicNOEMdkInZNJUHdufWIdBzGxmVKCBsFxqQctlrYpDtGtYaxhxJjkpARrelQiAPtxh");

    for (int XpuwtRLp = 522691311; XpuwtRLp > 0; XpuwtRLp--) {
        wTZnOIO *= OECqzCdJEtJ;
    }

    for (int oHFxKaUaLLhFLYp = 154074143; oHFxKaUaLLhFLYp > 0; oHFxKaUaLLhFLYp--) {
        continue;
    }

    for (int tEIcgOlbCpKRh = 683268490; tEIcgOlbCpKRh > 0; tEIcgOlbCpKRh--) {
        LAjcDbD = LAjcDbD;
    }
}

string EmUllXP::AloLcKbpwX(string gtuEMnEuF, double fMCFJAiiVIOCBNWs, int RsaAgd, double IlrvjqEalsjK)
{
    int TWzNYQFPxYBSPIs = -2071906329;
    double PxHONLvkjQp = 707537.1169350271;
    int OFRxaclBfKe = 1960576456;
    bool ZngAWviDMTeoytR = true;
    bool MhBymmsexLxoBpD = true;
    int ZoThOpq = 1401684056;

    if (IlrvjqEalsjK == 823667.8792987544) {
        for (int CsXmrhXZnrTNPEv = 862259230; CsXmrhXZnrTNPEv > 0; CsXmrhXZnrTNPEv--) {
            OFRxaclBfKe *= OFRxaclBfKe;
            RsaAgd *= OFRxaclBfKe;
        }
    }

    if (ZoThOpq <= 1401684056) {
        for (int qMOysOUlXencyxB = 2060478147; qMOysOUlXencyxB > 0; qMOysOUlXencyxB--) {
            TWzNYQFPxYBSPIs = ZoThOpq;
            PxHONLvkjQp += PxHONLvkjQp;
        }
    }

    for (int eTIhXu = 1871314702; eTIhXu > 0; eTIhXu--) {
        MhBymmsexLxoBpD = MhBymmsexLxoBpD;
        ZngAWviDMTeoytR = ZngAWviDMTeoytR;
    }

    for (int EcIxHWD = 2079627686; EcIxHWD > 0; EcIxHWD--) {
        continue;
    }

    return gtuEMnEuF;
}

bool EmUllXP::hMBXACKxyvltfClZ(bool yPNRkq)
{
    int HOYgYXsSdPdw = -1636399304;
    bool FcVQDCinPS = false;
    bool AbmASwVuG = true;
    double kxpJlhFXk = 486582.0769103942;
    string fQnPIyBivhlujJMm = string("yJqNbxJNXnRUpMeCVgnhVceHrnekOAwaHkZbMTjOcBfIejYiDdcKIJPkUQJadbeIwejUujZxNVGLsrnvtqcJYAaAoweyKpzRWtWYtcfvtJsCUlRptgHljIsPXFfZTGmQHQtzhmdJRhNDwlxViyoFSsbplhEQWFFsSzqiOWJXDxLFxKTkYrOemCFsTepZDtcaEHrtdmpOUXqcGqOoV");
    bool thtnzGRMuWS = true;
    double xVAWgygzJpIxDHnd = -559255.409957908;
    int XEMYlOoV = 189023379;

    for (int hEgcvdityzbA = 547510924; hEgcvdityzbA > 0; hEgcvdityzbA--) {
        HOYgYXsSdPdw -= XEMYlOoV;
        thtnzGRMuWS = ! thtnzGRMuWS;
    }

    return thtnzGRMuWS;
}

bool EmUllXP::YYehWbyTzRYS(double tYloIgc, int RNyhDLMTS, string pPMPPpgMTjJL, int PRqNTTnInWUfWHxQ)
{
    double RPDTamsGgxkFMZ = 74966.53352440066;
    double tEqHzHzPKN = 294715.50856535556;
    string SZnHKLuBhwEE = string("dRhhnYfKVavkVvKvWjXtKPqCEfQQHsBavXXjZJxmzezruCvDKIRbJOjjmgajDDvzCIlygBotMxSgXLMRVdhwjxlfWarCAwQDHBxKdAmJVzYoNZqwEzsYtYfVVXAJLGWEfUolhgcXadpIViboaAIEMfYZOakqqgMZcUKTYpfPizhGqWVZbxKbabCnsirOaa");
    double xWKiEEQBMKPDDh = -541447.0580661426;
    string GtVDARS = string("mwupaPOKhkqCnGgaZSiSuyuEhWGNSBrvepLVQNElGJbxU");
    double wUEUgk = -740820.2838594035;
    bool gUGQevviZJDKLfh = false;
    string QZFBhmGYkv = string("vPlOjkXkD");
    string lokCurxtRthUHSv = string("VjNkksDQLtpFkwskgk");

    if (RPDTamsGgxkFMZ <= 294715.50856535556) {
        for (int XoRsFpjko = 283989676; XoRsFpjko > 0; XoRsFpjko--) {
            continue;
        }
    }

    if (wUEUgk < -541447.0580661426) {
        for (int FLznPdkSFsduHb = 294084348; FLznPdkSFsduHb > 0; FLznPdkSFsduHb--) {
            SZnHKLuBhwEE = SZnHKLuBhwEE;
        }
    }

    if (tYloIgc != 74966.53352440066) {
        for (int OSWNonGmFAV = 342383821; OSWNonGmFAV > 0; OSWNonGmFAV--) {
            tYloIgc = wUEUgk;
            RPDTamsGgxkFMZ = xWKiEEQBMKPDDh;
        }
    }

    for (int rirLMSLKyQ = 874470918; rirLMSLKyQ > 0; rirLMSLKyQ--) {
        continue;
    }

    return gUGQevviZJDKLfh;
}

EmUllXP::EmUllXP()
{
    this->jmzirxpTzzHwnvM(-908195366);
    this->YpSHTAS(-183487.0093824267, -893462.2324778686, false, string("jkpwdEmQSvnRBZESomwIqjeaMbWeRAfjBdLeDmyMjfsrPWazZAibvoAwtmKbwMPpfNRtVCrQmRgrMpIXJlLeHaQmgUhWRcAcjovyWHqyEbCbTJdtWMSnMfAoEYoRFTxDXVxKsAFaAcPXvvwmYrisAiqxjSivisdhwwUlTtaOtsDQTAioCnggkBVYlZtLcioWyLIwivfJzmBoygxERhGYjzDZkblSxRZQjUBvowMNvxAt"));
    this->hBUptV(1937892653, false);
    this->DHgxXmQF();
    this->YfWgFAIIjV(-717998.5278383397, 282171.8912336097, 1386222690);
    this->AloLcKbpwX(string("gMKXYqzJBjJDqSyQrhIfGQEcWWcI"), -319351.96158146346, 1517319644, 823667.8792987544);
    this->hMBXACKxyvltfClZ(true);
    this->YYehWbyTzRYS(-234307.13020478742, 565162885, string("XnLcHlHyXneZqinlHBeEjxdxxpuVHAaVXVEPyLtgkNqRJzdAykCoUMsEIsSegqNIyrPTCcCjJLltxyvezQUBfZhtZffRChyoToktKQbuiSSleKhunNySZSyVtiRmzTOoecxUUwOxzxjepVdWZYxyU"), -1048655877);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zKqLuEFIQzkfSu
{
public:
    bool YmpqGBPnBzXJIL;
    int ejyznJlIxwU;
    string NeoRboi;
    int gnWERFkNyT;
    bool tSTaEmiFHnIldskI;

    zKqLuEFIQzkfSu();
    string YVXlPiNYQMGex(bool vQCWUXBQQ, string bchSW);
protected:
    bool SUjCPefjhUJYdvAQ;

    string LfsKiTyJZLA(bool zXEBjrfo, double avtQPEzEJa, double bGKXFZUKrHYnEU, double wmAYMUWfF);
    bool nrbyJ();
    void yggfVhZeM();
    void ozXswhc(string iLeuZpToAJw, string WGCBTtJgxQIksPaM, int PEmWVc, int bNPQGf, bool GXapl);
    double sldPLQKdHoriz(double qOpqF, string QSThjR);
    double pTtJcTaLIwbLUc();
private:
    double EOKsArhV;

    void XpYaNmrZDLzPcMd(double bUIjGzzWzpA, string ARJeS, int LuurlSCxT, int IalBZvgqjz);
    bool lKYcfJhB(int NPkhKfmOXC, int pTvgyKqrfQr);
};

string zKqLuEFIQzkfSu::YVXlPiNYQMGex(bool vQCWUXBQQ, string bchSW)
{
    bool CpWUFCXQd = false;
    int WPUEeSkyEtbvf = 1088630735;
    bool xDacXOcOgUIvXc = true;
    string RXLQLdWx = string("AtoemkZYTtjJJLtsAREWRMeYyxXMkROOXhryNhObqMSFLZlaLkOOSrzOSHyooSLgZkBuAMHuyeRrGbVFSiWjZEOyCkXEZpSRlbTrhcUScvgylfLrvnbAagfLKOzUZvlHTKwjjNeYwxZnKhCaQyIBwcUQanldrqIsBuPabsyYoTmYQtSUrwbYAOjbfviSIIEgIVZZscETbpAHCRFnHJSzcohDpNRhoeGQeajEyNjV");
    string CkhmX = string("nPNJBoWcoYnxomGMFzbxQoMndybiITbDRmmHeBjyfZdpHhbvIkZkkwiFFoTkuaIYauEVVUiWHPpWZALZCJXGYnUmebxkpBirOgEvyyUhkppJuGowKpvywytlhpcqbqVHolduaUdhYoRxTtghkTXUsyawimnAfGOJzKjzaxrPdmDoSDwHmmrwdDxaVnWBsJitqaQfkjbt");
    int uxGhCc = 271406012;
    int UzjFyQkbtRY = -780161420;
    int SQzkvf = -1161665567;
    double HFjjcAJHdNVNgvyC = 914099.8652118694;

    for (int NEedBiUAvGO = 1470215182; NEedBiUAvGO > 0; NEedBiUAvGO--) {
        bchSW = bchSW;
        bchSW += RXLQLdWx;
        vQCWUXBQQ = ! xDacXOcOgUIvXc;
        WPUEeSkyEtbvf /= uxGhCc;
    }

    if (SQzkvf <= -1161665567) {
        for (int VNQkkF = 1525486547; VNQkkF > 0; VNQkkF--) {
            SQzkvf *= UzjFyQkbtRY;
            CpWUFCXQd = ! vQCWUXBQQ;
            uxGhCc += uxGhCc;
            CpWUFCXQd = vQCWUXBQQ;
            xDacXOcOgUIvXc = ! xDacXOcOgUIvXc;
        }
    }

    for (int JqLeIbbIijJC = 1397398519; JqLeIbbIijJC > 0; JqLeIbbIijJC--) {
        uxGhCc *= WPUEeSkyEtbvf;
    }

    if (WPUEeSkyEtbvf > -1161665567) {
        for (int iSBKkVjCtSA = 1986384289; iSBKkVjCtSA > 0; iSBKkVjCtSA--) {
            continue;
        }
    }

    if (SQzkvf == -1161665567) {
        for (int VLpNEvtkOZLq = 1608946267; VLpNEvtkOZLq > 0; VLpNEvtkOZLq--) {
            uxGhCc /= uxGhCc;
            xDacXOcOgUIvXc = ! vQCWUXBQQ;
            WPUEeSkyEtbvf = SQzkvf;
            vQCWUXBQQ = CpWUFCXQd;
        }
    }

    return CkhmX;
}

string zKqLuEFIQzkfSu::LfsKiTyJZLA(bool zXEBjrfo, double avtQPEzEJa, double bGKXFZUKrHYnEU, double wmAYMUWfF)
{
    double VsjmNmeHIM = -869319.5739483251;
    double zsAFDKb = -674054.3676781984;
    double igMxIwPsw = -127023.17065149912;
    string vEJjIsAxD = string("qbgDcAfmzSivAnzqIlkfaKzQeiPDKDNsGygHXWDfHjGIBaZGEnToJaFPRCBFrYSYIlOwkzdcZVwMvmNPBymVtNkiyryFJgzqGCytkths");
    double avuGMbdTuem = 27380.614979962447;
    bool WFXyj = true;

    for (int sXGCjMSKFtyCO = 1374147811; sXGCjMSKFtyCO > 0; sXGCjMSKFtyCO--) {
        avuGMbdTuem += avtQPEzEJa;
        avtQPEzEJa *= igMxIwPsw;
    }

    return vEJjIsAxD;
}

bool zKqLuEFIQzkfSu::nrbyJ()
{
    double DbkRVraOQO = 601658.5413361613;
    int bOnJBM = 379971370;
    string hXyJtMmIpPwY = string("xDJoMoZePoiILEFbMHWwjZsyULFqzPTNPsZalZ");
    double kvChHRBZYHfq = -957178.2324192985;
    bool DKWCdXcW = false;
    bool LJkUUQSmx = true;
    int KbtrMlrSjpWFrcG = 1333757276;
    int wEogJbmmmzUn = -1695825444;
    int ISPjWAk = -869143360;
    bool miPTxMyYKy = false;

    for (int XpxHiRZcDk = 1736071824; XpxHiRZcDk > 0; XpxHiRZcDk--) {
        bOnJBM *= bOnJBM;
        DKWCdXcW = LJkUUQSmx;
    }

    return miPTxMyYKy;
}

void zKqLuEFIQzkfSu::yggfVhZeM()
{
    int dBJFPQSCP = -598199698;
    bool ZkSkGdGXdhRoZtJA = false;
    bool QxEBKR = false;
    int HDHVgj = -1570150220;
    int fwDYq = -556049985;
    bool tdVlLWIJGslvOr = false;
    double AyOCMGdzZK = -838370.383130198;
    bool MeNuQpSjLZGZFJ = false;
    int QcxTIuYlsrIBrfwf = 2087862555;

    for (int RImDErlW = 314056446; RImDErlW > 0; RImDErlW--) {
        MeNuQpSjLZGZFJ = tdVlLWIJGslvOr;
    }

    if (QxEBKR == false) {
        for (int aMYLCiCfUnIyJ = 639837056; aMYLCiCfUnIyJ > 0; aMYLCiCfUnIyJ--) {
            MeNuQpSjLZGZFJ = MeNuQpSjLZGZFJ;
            HDHVgj = QcxTIuYlsrIBrfwf;
        }
    }

    for (int pFSMUZcujbsKsnGk = 804312410; pFSMUZcujbsKsnGk > 0; pFSMUZcujbsKsnGk--) {
        MeNuQpSjLZGZFJ = ! MeNuQpSjLZGZFJ;
        QcxTIuYlsrIBrfwf *= HDHVgj;
        ZkSkGdGXdhRoZtJA = QxEBKR;
        fwDYq *= dBJFPQSCP;
        HDHVgj = HDHVgj;
        ZkSkGdGXdhRoZtJA = ZkSkGdGXdhRoZtJA;
    }
}

void zKqLuEFIQzkfSu::ozXswhc(string iLeuZpToAJw, string WGCBTtJgxQIksPaM, int PEmWVc, int bNPQGf, bool GXapl)
{
    int ZvbTGiCInHoUHC = -792421033;
    int SuxEiLdTXAO = -883786465;

    if (SuxEiLdTXAO > -883786465) {
        for (int rkBLhOH = 1573359077; rkBLhOH > 0; rkBLhOH--) {
            continue;
        }
    }

    for (int oKrJo = 917743665; oKrJo > 0; oKrJo--) {
        PEmWVc -= PEmWVc;
        SuxEiLdTXAO -= PEmWVc;
    }

    if (SuxEiLdTXAO != 198119571) {
        for (int WbjIYAOyMIB = 881944765; WbjIYAOyMIB > 0; WbjIYAOyMIB--) {
            ZvbTGiCInHoUHC += ZvbTGiCInHoUHC;
            bNPQGf *= ZvbTGiCInHoUHC;
        }
    }

    if (bNPQGf != -883786465) {
        for (int NpwJl = 1104366411; NpwJl > 0; NpwJl--) {
            WGCBTtJgxQIksPaM = WGCBTtJgxQIksPaM;
            PEmWVc = PEmWVc;
            bNPQGf *= bNPQGf;
        }
    }

    if (GXapl != true) {
        for (int VNORLBGEJTjHFzjL = 612191646; VNORLBGEJTjHFzjL > 0; VNORLBGEJTjHFzjL--) {
            PEmWVc *= bNPQGf;
            ZvbTGiCInHoUHC -= PEmWVc;
            iLeuZpToAJw = iLeuZpToAJw;
            SuxEiLdTXAO = PEmWVc;
        }
    }
}

double zKqLuEFIQzkfSu::sldPLQKdHoriz(double qOpqF, string QSThjR)
{
    double GuPRifTpakokhfv = -254358.56149106327;

    for (int JfxwR = 1522098528; JfxwR > 0; JfxwR--) {
        GuPRifTpakokhfv /= GuPRifTpakokhfv;
        GuPRifTpakokhfv += qOpqF;
    }

    for (int oSnDtvzJOunpeiMY = 1536965348; oSnDtvzJOunpeiMY > 0; oSnDtvzJOunpeiMY--) {
        continue;
    }

    return GuPRifTpakokhfv;
}

double zKqLuEFIQzkfSu::pTtJcTaLIwbLUc()
{
    bool LQYylZOeAjMJasi = false;
    int xWLlwPKP = 506388115;
    bool CuxffmmDqgLa = false;
    int XFeVC = 1062657589;
    string nWeebBFxH = string("lkYPSiJuEpJJccGtMlaBJtTjVEWZCcYAjFWdrnpHUGBOxaAbaIcboxMqFdCWIFkGrTIosEvaLwDKielJZiTEATndoOPbLPWUYVvgcMVroMhCSqJIqPRnYCiqyXTFwLBYiYdFtpqjQuwlZyVIbfgyhrOpoJiLBiclrPTzYIsWwRHYyHKYvLyYyLgCt");
    int IuHCWkOFJ = 1298931372;
    bool Neengk = false;
    int vgeeCo = -1163427912;
    double fXZCEZkshIqE = -597599.8101718582;

    for (int YVlNR = 1876610534; YVlNR > 0; YVlNR--) {
        continue;
    }

    for (int kIuwpQxZDmmA = 1288883573; kIuwpQxZDmmA > 0; kIuwpQxZDmmA--) {
        vgeeCo /= XFeVC;
    }

    if (XFeVC >= 1062657589) {
        for (int wkWqjBO = 365453859; wkWqjBO > 0; wkWqjBO--) {
            xWLlwPKP /= IuHCWkOFJ;
            CuxffmmDqgLa = ! LQYylZOeAjMJasi;
            IuHCWkOFJ = xWLlwPKP;
            CuxffmmDqgLa = ! Neengk;
            LQYylZOeAjMJasi = LQYylZOeAjMJasi;
            vgeeCo += vgeeCo;
        }
    }

    for (int CQBFq = 735438031; CQBFq > 0; CQBFq--) {
        continue;
    }

    return fXZCEZkshIqE;
}

void zKqLuEFIQzkfSu::XpYaNmrZDLzPcMd(double bUIjGzzWzpA, string ARJeS, int LuurlSCxT, int IalBZvgqjz)
{
    string LMGwE = string("AAglfrXWEsHifeairxCaDSSEwxupCotAMNErLpUGyhRsaBLbxxmuHUTezcBObhvLQnjVQjYpigYvxkcWeNsNCfSiiBSudQXiInTFXLpzXJhLExbQuiIoSNubGIOUgMbioAYaIGNiNXBiyBPfnOiQjpcwDcWmrboBIaKFJgZeAYGMiTghkKMIfAjccpQMzvLKFxYCyadlJanjffHoEwmdoWUpyNpmHhOzidRTIUCWNmALnQXWMNB");
    int MksdBmsqBsdJnW = 1217852159;
    double QVvwhqxefpjqfWkJ = 332529.29592068493;
    bool YeGwESaBq = false;
    int kgjUPyGlejrmJML = 2004439587;
    double TCVTWE = 488289.17925489665;

    if (LuurlSCxT < -628368892) {
        for (int aFwFprWMEMYd = 1920948913; aFwFprWMEMYd > 0; aFwFprWMEMYd--) {
            MksdBmsqBsdJnW *= MksdBmsqBsdJnW;
        }
    }

    for (int ShdOEJjjHKEY = 1161199252; ShdOEJjjHKEY > 0; ShdOEJjjHKEY--) {
        LuurlSCxT = LuurlSCxT;
    }

    if (TCVTWE == 488289.17925489665) {
        for (int FCgAdOYz = 923429635; FCgAdOYz > 0; FCgAdOYz--) {
            bUIjGzzWzpA /= TCVTWE;
        }
    }

    for (int VEyDTOI = 1428886371; VEyDTOI > 0; VEyDTOI--) {
        continue;
    }

    for (int xngEmkVmsJTvdxYw = 889804053; xngEmkVmsJTvdxYw > 0; xngEmkVmsJTvdxYw--) {
        kgjUPyGlejrmJML /= LuurlSCxT;
    }
}

bool zKqLuEFIQzkfSu::lKYcfJhB(int NPkhKfmOXC, int pTvgyKqrfQr)
{
    int YZpHxVfy = -1370062919;
    bool zppdLOqEdOTvTgG = false;
    string XaHRLuTN = string("hGKyIOHasArvZTbhkfQNappZFeYIVIOJQRnkoTBmIZwsiKCSPliYeQBjstFOfOQxlfKzzXzSAGngiqGMmZoaXhREbMHLdJazodnlDxYyskDuStEmiZlSTfrArsKZqJBOMsHgzxRgjQmSJnQJMAoL");
    int verwiKPsdyOhbAcd = 1204105979;
    string hmbqAHtXYQR = string("BnOVNRTtYQbvpXyLNXmsDyDzspTjjMRTMjhvyWyvDGGbuVxbQRvRMDqTlfCkbGOAehlH");
    double SnAbsfTVzat = -304872.1733823608;
    string WkDaPNbodWfTa = string("GoVrZxDaVUJRbFixoDGFnEMmtFOnhHnNewyadFAKiRoiidAnWJxAEVNMFvzmdpjPyNWujmrmeWcQtIANwhwWjvbGfZaRjZQMMElfbnLlDdtHgPDqbkmWCbFCkIhxRdnNJLgZpXInIOfBybxNXXlTILKWKmbiSDLvTMcaZT");
    int sDCcQIuHS = 1985897875;
    bool rXduRtdyyKx = true;

    for (int LEIsbPzfgkIDFjZ = 1289475062; LEIsbPzfgkIDFjZ > 0; LEIsbPzfgkIDFjZ--) {
        NPkhKfmOXC = YZpHxVfy;
    }

    if (NPkhKfmOXC <= 1884636862) {
        for (int qqRbadiiPWGjIG = 1271636441; qqRbadiiPWGjIG > 0; qqRbadiiPWGjIG--) {
            NPkhKfmOXC /= pTvgyKqrfQr;
        }
    }

    if (sDCcQIuHS > -1817280457) {
        for (int IyrHvUhs = 831655439; IyrHvUhs > 0; IyrHvUhs--) {
            XaHRLuTN += WkDaPNbodWfTa;
            pTvgyKqrfQr /= verwiKPsdyOhbAcd;
            WkDaPNbodWfTa += XaHRLuTN;
            verwiKPsdyOhbAcd -= verwiKPsdyOhbAcd;
        }
    }

    if (SnAbsfTVzat > -304872.1733823608) {
        for (int iQratkuB = 1388623993; iQratkuB > 0; iQratkuB--) {
            continue;
        }
    }

    if (WkDaPNbodWfTa != string("BnOVNRTtYQbvpXyLNXmsDyDzspTjjMRTMjhvyWyvDGGbuVxbQRvRMDqTlfCkbGOAehlH")) {
        for (int XSymyDfkdfiKCU = 721537497; XSymyDfkdfiKCU > 0; XSymyDfkdfiKCU--) {
            YZpHxVfy /= sDCcQIuHS;
        }
    }

    return rXduRtdyyKx;
}

zKqLuEFIQzkfSu::zKqLuEFIQzkfSu()
{
    this->YVXlPiNYQMGex(false, string("vnjfuSJmGfWTJzMiuXqBCSuQNbCgzKKOwpYTTJXSrPazpJTZzjZToIxaOJSqSphgrQyysLprHLQgVwqKbfdGPrMzbuNJzMweuNdnXYpalQLzLgMcIWBxMzzjDVRfiOFPKpfbdDjsUeylmgAbkzwlDuDaEIJRvASdCYWDUKlUbgSlwcFSDWXVaGxBgiTwPFgpoEZhrbkSHHmWnsKUXrExpcXFowiaHpuw"));
    this->LfsKiTyJZLA(false, -150545.253555563, -1032787.2121823163, -313468.8504917801);
    this->nrbyJ();
    this->yggfVhZeM();
    this->ozXswhc(string("HRjXMOnecbo"), string("MZzfykfCRHAphVMLkgQDuLJtRDzBbZkOuCscnheVQGoPvLpvTCykBYdrShqAgNepToxVbfElnUkKZnAogcocbCIAXfnWouGKlWCmrtPizMEAbXCnHqQkiZMcxARiWdwGfhOMIXpwRyhGEleAMuCGNIRqxLEtgPQAZZcHmIoaeibNKvKjqHD"), -1357782973, 198119571, true);
    this->sldPLQKdHoriz(718491.0786100916, string("DNQQKxiSPhzsbchLTyqvCipXogxfSDvOIChHXTjETqYGzPRpzolPcLPZyfn"));
    this->pTtJcTaLIwbLUc();
    this->XpYaNmrZDLzPcMd(-192145.81900482863, string("yYdydvHbOgJNJhKswgKcxpJHeXOofXqXEDzAtpAOMzfunzlZrpmVlwOwREHdLFkTRZsPadwZAZjAthXApdcWLAMeyVHxOKQztdsVmxYphtvPdSHnbSxUNQASQZRMMKuvShxLvEsymAPJLNLOEphNseHNCYQQQzeigwtgdxOuKNQNftOTmerEtNxWtETltExdTVnlPyJCXaMBRWiNwIjLKkakVqQDrYfMzOEpZuMFw"), -628368892, -1159699245);
    this->lKYcfJhB(1884636862, -1817280457);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Vhviow
{
public:
    double NubNTHzSM;

    Vhviow();
    double TWFLUOkmJpGKt(double HLcXbnFXUxhtX);
    void dLSgxTH(int sSDscDhaUV, string hUFFvOmlnYtUT, bool HqYJFnLpvUTWZnV, int KigTBSDdQLsh);
    double oFEtjtO(string aEPKWIL, double lihGnDjdZmJtm, string CIWImeiRO, bool XCQWFVcYlP);
    bool IDtur(string aiEhEul, double sdaZPBDg, string BfwsbCcAUIkvUMm);
    bool ZKQymIfY(string IJPdSpoaYHKYymJ);
    int XwtlglafRtcy(bool RGwRAEVMqTuVeH, double FyzqQIbXfa, string SkrYmliqlNZ, bool oqArQYCEBiI);
    void EfBIsTxD(string GlQNibc, int bEjoNarUv, int qkLXrp, bool CjsDzfpbuZ, bool KotzkRfGigKr);
protected:
    double fEwbQouvhjYFuez;
    bool vJzMyYCORdnW;
    double rCDAvwRzly;
    string UsOPADjgooUjq;

    string wIprLXOWKnCgD(int cJWnQ, string bLtKUVBMunJBEGjd, int wSrdgTZSgGx);
    string SZlVZtPdvg(int tMsKL);
    string oqCUT(bool zWSrNPGZOV, int qKPKc, int PNROHjyDqCv);
    double hDgxcQXeTi(int aqbspBeckS, double MJTdWFtFBU, string YSGofOLcTQfuQ, bool NLaIogs);
    string SneiDRpK(double EOgTyjxposQxfG, int hgvHyRIEatEu, int evztkFhpEZiGR);
private:
    int tinfbYJAbcqdpCwn;
    double nMIeaJJQgNnVQ;
    bool zJwCemXhQdSJOq;
    int sWnMewIpTPzIRO;
    int jjmadIi;

    int JAZwIklTODBEWe(bool vMeHWMoYsUwMW, bool ODRfRfqCPwTh, int JUpkNYddrb);
    int opSJJmbvwMQspBTh(bool ZeATbzxvFEqo, double IgjwTPpjDdRVu, double pqjaBBpJTZ);
};

double Vhviow::TWFLUOkmJpGKt(double HLcXbnFXUxhtX)
{
    string NphSkqi = string("uPJZqXITXZVwXnjsnHosCIMznMObsSDgRQWnPVVfgjNhskNSKJ");
    double xbuUxcuyNzZ = -543215.1140711431;
    string FopJtyEJkUuqY = string("cyvEycPuFohXHqzylpoVqypnbGDNYUgYKoSSOcvcTFEPCsCvNJYpEIzudTxNaagTKbuvsyNNgmLCEqWJrxKQTyDtINwqJVnAAvbUcbpcPUaCOphKMNYiDFkKkhZgSBRVQNdCrmNDJJJCBVzLeQwOFpGelphYqNGzPjdfkMDSwe");
    string ZSNVBrLX = string("HtTJEcUmGjAPDNamdiHXgeNkGFIbZuoYncjA");

    if (FopJtyEJkUuqY != string("uPJZqXITXZVwXnjsnHosCIMznMObsSDgRQWnPVVfgjNhskNSKJ")) {
        for (int BKeJUHsM = 1489338710; BKeJUHsM > 0; BKeJUHsM--) {
            ZSNVBrLX += ZSNVBrLX;
        }
    }

    for (int tpDcqYVRuWKiRjSN = 139595815; tpDcqYVRuWKiRjSN > 0; tpDcqYVRuWKiRjSN--) {
        ZSNVBrLX = ZSNVBrLX;
        NphSkqi = NphSkqi;
    }

    for (int NMEDWeVqTZUCSwws = 563488705; NMEDWeVqTZUCSwws > 0; NMEDWeVqTZUCSwws--) {
        HLcXbnFXUxhtX -= HLcXbnFXUxhtX;
    }

    if (NphSkqi >= string("uPJZqXITXZVwXnjsnHosCIMznMObsSDgRQWnPVVfgjNhskNSKJ")) {
        for (int aNnsekYnyZWL = 1734286278; aNnsekYnyZWL > 0; aNnsekYnyZWL--) {
            HLcXbnFXUxhtX = xbuUxcuyNzZ;
            HLcXbnFXUxhtX *= HLcXbnFXUxhtX;
            NphSkqi += NphSkqi;
        }
    }

    return xbuUxcuyNzZ;
}

void Vhviow::dLSgxTH(int sSDscDhaUV, string hUFFvOmlnYtUT, bool HqYJFnLpvUTWZnV, int KigTBSDdQLsh)
{
    string kOIDqsFfDzxkwT = string("elixxxaOYmXGXdlqIDHjHHfFqptTXJgKtQXJqBZjTwXWnssLGLvSiHPibgozosqumXRxHTVcYfRPpbhvCrArsLvETEgNgqiLQXnkyWvtmQec");

    for (int MxYwGh = 946411537; MxYwGh > 0; MxYwGh--) {
        sSDscDhaUV /= sSDscDhaUV;
        hUFFvOmlnYtUT = hUFFvOmlnYtUT;
        sSDscDhaUV *= KigTBSDdQLsh;
    }

    for (int lwdLgzeUYepbZU = 259793762; lwdLgzeUYepbZU > 0; lwdLgzeUYepbZU--) {
        continue;
    }

    if (kOIDqsFfDzxkwT != string("DdbfaBadwoEcYkhlfzSRtonaLssFEvtGyqSnHfaJKHMAUnVXmGAHZblwepFpJFEIMLxbtnrbLtVqQeKYQcmSSameepgSHYFbGu")) {
        for (int amFPSoYo = 1088805375; amFPSoYo > 0; amFPSoYo--) {
            continue;
        }
    }
}

double Vhviow::oFEtjtO(string aEPKWIL, double lihGnDjdZmJtm, string CIWImeiRO, bool XCQWFVcYlP)
{
    double OwcojjzxgzsAXrM = -775509.1071776714;
    string QawzrWZbnpWcJ = string("FIvELAiYYcrRIUERgFlOyFhIEarfsnphfBzYvNOYrNTEDDUJioJjegXggqLZiewQfKizObDmWdFdHatzMXwMLygPrHzhPsOl");
    string nfvnaustyDHPnpB = string("ZfqaxfpqvuHwyWjUtlRRBHYiwJuYxsijCLuSSbbKweikgBQvFOkQBXRFerKlkjrAbRWUOgDSMJBjOqdiwULnGARPyguEYiltrfRzNiZYkepi");
    string uVegn = string("ipRrpDRciHjlsGUnYdPjnorhZUruGNjxfgFnlxqvCMDjIihvwOWbdleqdKRzMjUzECVbOCOqiBPdHYnJlWWNyxTxCcprZjnqLpmccCLoybKkqDZtJRsWnokXufHcgiPzvgocCgiHaBkcBETmEgqqihODEcTIoZDGEiJXloKaMNXmRvgGSldceIJyCtqFaZnEeonrpKyGPejdAaEddBqyaPPHH");
    bool sOADCqzqFpSb = true;
    string EgVJMyaZaT = string("BNAnNgK");
    string ROEUJWfoi = string("kFCTFvTAKuEVOtDtIPjaOmRzRrqeBjIblRsDgkgqQomlzrBGyliMFazMysKYgQGeXckZGdWlULGhxoGNJUMfskCWDIIHmGqjVHMAAqgFmKnxsiugQyKDYKDdzpqVHLgDIJjTMvJZmxXtxvEiCRFZBeuWjJuZQhDXAsWHDtperlMquHzTQCYxySwzOFmVuzQqtauNL");

    if (CIWImeiRO <= string("lSSfDuFKoKxKwNMPyAttGveJhBxWhZvLIoUqIoutEPWJhmcpfZzOlkTGlgkfwVbJRfLtWycFaSfaykiiEzlVKZRRKPKAxCTQFNjQGDtgqZBrIFdktyejdQwPuHXcZCUyvTvUEPygbOzy")) {
        for (int qIgtJKxIZiZD = 963990220; qIgtJKxIZiZD > 0; qIgtJKxIZiZD--) {
            uVegn = uVegn;
        }
    }

    for (int EjFDgFzqO = 869477048; EjFDgFzqO > 0; EjFDgFzqO--) {
        nfvnaustyDHPnpB = aEPKWIL;
    }

    if (XCQWFVcYlP != true) {
        for (int khezBzo = 151992629; khezBzo > 0; khezBzo--) {
            continue;
        }
    }

    return OwcojjzxgzsAXrM;
}

bool Vhviow::IDtur(string aiEhEul, double sdaZPBDg, string BfwsbCcAUIkvUMm)
{
    int RIRCjEVNZTKNIFtP = 1745918320;
    bool nxTKDEd = false;

    if (nxTKDEd != false) {
        for (int yyVojuGOveF = 1415341699; yyVojuGOveF > 0; yyVojuGOveF--) {
            BfwsbCcAUIkvUMm = aiEhEul;
            RIRCjEVNZTKNIFtP /= RIRCjEVNZTKNIFtP;
            aiEhEul = BfwsbCcAUIkvUMm;
            nxTKDEd = ! nxTKDEd;
            aiEhEul += BfwsbCcAUIkvUMm;
        }
    }

    for (int egjJRIzGuvr = 1191588608; egjJRIzGuvr > 0; egjJRIzGuvr--) {
        BfwsbCcAUIkvUMm += aiEhEul;
        sdaZPBDg -= sdaZPBDg;
    }

    return nxTKDEd;
}

bool Vhviow::ZKQymIfY(string IJPdSpoaYHKYymJ)
{
    int OnELJcXpskOhDJx = 452573545;
    double XdLqHHMKGbXAPV = 840843.7779332867;
    string NTESHqaKa = string("mYJiAFRWPCoRkmusvzRumQhyrMDvgWSSPJbWPkewfUjxOVqaKOdyXFaZbSZmMZ");
    string vPtrcyAr = string("xouQkEaKppbGmuKKtIVEhYexnVorJPlaFxCADsxDZYnBXyzpDbdmEIBZBVFDhOwSuOeBqjnVVaxwDCjsmaoXYQuhjjEfRKYngTvEoeXvdtHykzfTahmOtIGpBrXYqXSmkuONvifocmRFncYANqzgPb");
    bool aZuJpfT = false;
    string GiVthkVYB = string("YEVWnqdsGwBXLKQmrWKRAuG");
    string FcVqXKLvxURQTuC = string("DfutlYFzLilYdEIuhOMJcmdNFEgZIjDzQIcoHsCAEOHltLSVqFtaLaVRYIuyLlWDGVDWFllgyUjPEkCgZzkDOpYVubHOoHFAfdvEGtXgcsLRRllrhsdNkqoRxDLHNLKCxEzHxxOAPHlbtYGYzeyxlYzaVIRWeADszxOakxCbzesvDqXVMpZOGfkrslXYitymiGQKA");
    string sDnhPpDJlJgU = string("edHfYhMlzwJqiwaxtrwVfkywIfDwfOUvVqusKNhQUIdMtKqWvAmjrLmptzitqCAvJPsXXHtvYkOUF");
    string SbYQNZwxDfeaNi = string("gjbiDTWhLsLCHHxcYzxzNTBKInNSLJDmtVjunppsdBQeKqzOtnAnCsbInOgSPxKEdJiCDJFIqRNyJArqEjnUvVYHkjyJNFKOuSJNayjmgWofrcHwplpXKOTYLcoqfnPCtcyWhUGZQsCvUFZnLRMwnqhHFmEv");

    if (GiVthkVYB != string("DfutlYFzLilYdEIuhOMJcmdNFEgZIjDzQIcoHsCAEOHltLSVqFtaLaVRYIuyLlWDGVDWFllgyUjPEkCgZzkDOpYVubHOoHFAfdvEGtXgcsLRRllrhsdNkqoRxDLHNLKCxEzHxxOAPHlbtYGYzeyxlYzaVIRWeADszxOakxCbzesvDqXVMpZOGfkrslXYitymiGQKA")) {
        for (int redbmKfTJNCTrN = 953659127; redbmKfTJNCTrN > 0; redbmKfTJNCTrN--) {
            FcVqXKLvxURQTuC += sDnhPpDJlJgU;
            vPtrcyAr += GiVthkVYB;
            NTESHqaKa += GiVthkVYB;
            sDnhPpDJlJgU += IJPdSpoaYHKYymJ;
        }
    }

    if (GiVthkVYB < string("gjbiDTWhLsLCHHxcYzxzNTBKInNSLJDmtVjunppsdBQeKqzOtnAnCsbInOgSPxKEdJiCDJFIqRNyJArqEjnUvVYHkjyJNFKOuSJNayjmgWofrcHwplpXKOTYLcoqfnPCtcyWhUGZQsCvUFZnLRMwnqhHFmEv")) {
        for (int JhFDFr = 235466441; JhFDFr > 0; JhFDFr--) {
            FcVqXKLvxURQTuC = sDnhPpDJlJgU;
            vPtrcyAr += SbYQNZwxDfeaNi;
            FcVqXKLvxURQTuC = FcVqXKLvxURQTuC;
            sDnhPpDJlJgU += FcVqXKLvxURQTuC;
            vPtrcyAr = sDnhPpDJlJgU;
            IJPdSpoaYHKYymJ += FcVqXKLvxURQTuC;
            sDnhPpDJlJgU += vPtrcyAr;
        }
    }

    if (NTESHqaKa >= string("mYJiAFRWPCoRkmusvzRumQhyrMDvgWSSPJbWPkewfUjxOVqaKOdyXFaZbSZmMZ")) {
        for (int uVFkcpWBJRyB = 459460559; uVFkcpWBJRyB > 0; uVFkcpWBJRyB--) {
            SbYQNZwxDfeaNi = SbYQNZwxDfeaNi;
            vPtrcyAr += vPtrcyAr;
            FcVqXKLvxURQTuC += FcVqXKLvxURQTuC;
            FcVqXKLvxURQTuC = IJPdSpoaYHKYymJ;
            IJPdSpoaYHKYymJ = sDnhPpDJlJgU;
            NTESHqaKa = IJPdSpoaYHKYymJ;
        }
    }

    for (int aoQkM = 1620553379; aoQkM > 0; aoQkM--) {
        sDnhPpDJlJgU += GiVthkVYB;
    }

    return aZuJpfT;
}

int Vhviow::XwtlglafRtcy(bool RGwRAEVMqTuVeH, double FyzqQIbXfa, string SkrYmliqlNZ, bool oqArQYCEBiI)
{
    double nIpuZNmdi = 369055.6560463007;
    string YRsQKyRCeF = string("WUmcYDvJmNiYcXOMevxNSjmWpGucTOakeiUFBZxFPnBiKFgngmxBpUWlVympAUgyTYxhkpvVZv");
    double yDBHODuIKp = 19903.021297788975;
    double APZBi = -588676.3605245765;
    int HZpgmyjRVkuL = 1025442702;
    bool ppMzrAC = true;
    bool pKkIwoJmEbrYI = true;
    double TfXNAzfPT = 292227.8551699523;

    if (nIpuZNmdi == 369055.6560463007) {
        for (int HHsbScIxRppr = 1370320366; HHsbScIxRppr > 0; HHsbScIxRppr--) {
            APZBi -= APZBi;
            nIpuZNmdi *= TfXNAzfPT;
        }
    }

    if (FyzqQIbXfa < -237526.8670667876) {
        for (int xEPKaLPAEgv = 164053426; xEPKaLPAEgv > 0; xEPKaLPAEgv--) {
            ppMzrAC = pKkIwoJmEbrYI;
            ppMzrAC = ! RGwRAEVMqTuVeH;
            nIpuZNmdi += yDBHODuIKp;
        }
    }

    if (FyzqQIbXfa >= 19903.021297788975) {
        for (int rUvMmIo = 311204048; rUvMmIo > 0; rUvMmIo--) {
            oqArQYCEBiI = oqArQYCEBiI;
        }
    }

    return HZpgmyjRVkuL;
}

void Vhviow::EfBIsTxD(string GlQNibc, int bEjoNarUv, int qkLXrp, bool CjsDzfpbuZ, bool KotzkRfGigKr)
{
    string cOdmezNMt = string("SXycxTELWDYYzTqRdXFyaDvPJqcTGhyispUaTaPxvorAfXZJbGhPrBGZrfhBzfSJwsKfLtLSWPmPbNEWRTxPiMuMFGySjAsnvNxfbYsWoGOfWMMxwpsQIWahHkFVoyuZ");
    string jBzrEgxBEx = string("jYRIPUhkxFCwbmyKXdLjtnNEmDeUrDbIOHWJsaMyLVTYyxYPMvxudaNDQulIaMbicdpdvvfuOqKQXXc");
    bool EFUdCQMyS = false;
    bool EsvWjhoDssjiOs = true;

    for (int GkDLNwqxCc = 1122541547; GkDLNwqxCc > 0; GkDLNwqxCc--) {
        GlQNibc += GlQNibc;
    }
}

string Vhviow::wIprLXOWKnCgD(int cJWnQ, string bLtKUVBMunJBEGjd, int wSrdgTZSgGx)
{
    int RNyAaWapEJYQF = 1897853080;
    int ONluIdGAQaxh = -589548691;
    int GyRiFvABO = -2067985136;

    for (int FwtPnIfkUKLR = 893546073; FwtPnIfkUKLR > 0; FwtPnIfkUKLR--) {
        ONluIdGAQaxh *= cJWnQ;
        bLtKUVBMunJBEGjd = bLtKUVBMunJBEGjd;
        GyRiFvABO += wSrdgTZSgGx;
    }

    if (cJWnQ > -1624905577) {
        for (int eDzbpjx = 892593664; eDzbpjx > 0; eDzbpjx--) {
            GyRiFvABO = RNyAaWapEJYQF;
            GyRiFvABO = RNyAaWapEJYQF;
            ONluIdGAQaxh /= ONluIdGAQaxh;
            GyRiFvABO /= wSrdgTZSgGx;
            cJWnQ -= cJWnQ;
            wSrdgTZSgGx += cJWnQ;
            RNyAaWapEJYQF *= wSrdgTZSgGx;
            cJWnQ = cJWnQ;
        }
    }

    return bLtKUVBMunJBEGjd;
}

string Vhviow::SZlVZtPdvg(int tMsKL)
{
    int FOmTYYnYBBDX = -2143264802;
    double IRqgQUlXrkimC = 221855.24505691076;

    for (int OBzFeLkyaY = 2117069378; OBzFeLkyaY > 0; OBzFeLkyaY--) {
        tMsKL += tMsKL;
        IRqgQUlXrkimC = IRqgQUlXrkimC;
        tMsKL = tMsKL;
        tMsKL += FOmTYYnYBBDX;
        FOmTYYnYBBDX = tMsKL;
    }

    if (FOmTYYnYBBDX > -2143264802) {
        for (int DoEYr = 1153508982; DoEYr > 0; DoEYr--) {
            FOmTYYnYBBDX = tMsKL;
            FOmTYYnYBBDX = FOmTYYnYBBDX;
            FOmTYYnYBBDX *= tMsKL;
        }
    }

    return string("MAUoMOLIrkrnFbHJcmyUiKObihUZCBmQJNUvsMWChffiUpSuHzWAVDhVfuNrGPEYpFKRaiwzWgmTBNAvpmgtVPgpt");
}

string Vhviow::oqCUT(bool zWSrNPGZOV, int qKPKc, int PNROHjyDqCv)
{
    int EhEsbsTakaLYLnE = 1329198069;
    string nniLw = string("EESUpATEMolTqjDOrKKUEEwmMxkTUdezZoffVMBuBkllYTUQxEohALjQZJoxdcITCKboWuXpYGiHrquGvLHuvsCGDFUTDaglqJLoHBnfVeMGiSQk");
    double xNXCGWX = 11617.080267755084;
    string iGqqtxsIoLDvetJq = string("StaByUJgUjHXEYxuu");
    double jOuohLodmY = -399349.25828860304;

    for (int qTwkgJfwAenE = 479749290; qTwkgJfwAenE > 0; qTwkgJfwAenE--) {
        iGqqtxsIoLDvetJq = iGqqtxsIoLDvetJq;
    }

    for (int kohkN = 729944864; kohkN > 0; kohkN--) {
        continue;
    }

    return iGqqtxsIoLDvetJq;
}

double Vhviow::hDgxcQXeTi(int aqbspBeckS, double MJTdWFtFBU, string YSGofOLcTQfuQ, bool NLaIogs)
{
    int OCflTlCqAEilp = 1211498478;
    string SAquzuMklSoACa = string("YkARQmzNHfcuJYFmBLFLsUnCQDCHTcagDYRmbdHuKfxKgscNlInoczRirsSUEbTFPtIryPJBUUJVwKwncpFbkTgNDgUyiJsFsDWnWvBEaggtdqoYlKENgcStFqFAeAnEoaLwNACqbXGAxob");
    string YIdkAA = string("uOyGwwIqUVAgAAWCkJkIbjrdqtQPHOSUelRNlzRjaNmICukfqUDkfvXcgzKTvEhyCelxDxhGtLXDzTgAazDNqPzqKjigfumvAyWxxCedfQyIOInECG");
    int FMuExjWvzMXRZ = -1283533004;

    for (int irGqgafqmee = 398445221; irGqgafqmee > 0; irGqgafqmee--) {
        SAquzuMklSoACa += YIdkAA;
        FMuExjWvzMXRZ *= OCflTlCqAEilp;
    }

    if (YSGofOLcTQfuQ < string("wlGtRhNKCCpIdbAOIDTvpHwwflLigaMcTMxUSaMSprxcgUomfhzoUJohIpasuVzUiLvrplqfJiQBKVlkgiBZkNxchtSaLWSPzEWKSjTkMgTvKETskyBMisdNrDzQddxhPAdqFcZVjJfqYxFaYYuJBvPybsPAgCrdmAmQIG")) {
        for (int UeklD = 2131497840; UeklD > 0; UeklD--) {
            MJTdWFtFBU *= MJTdWFtFBU;
            FMuExjWvzMXRZ /= OCflTlCqAEilp;
        }
    }

    for (int fdkkJVn = 1959651417; fdkkJVn > 0; fdkkJVn--) {
        FMuExjWvzMXRZ = FMuExjWvzMXRZ;
        aqbspBeckS = FMuExjWvzMXRZ;
    }

    for (int NeWfJWQkmNlv = 1751615043; NeWfJWQkmNlv > 0; NeWfJWQkmNlv--) {
        continue;
    }

    return MJTdWFtFBU;
}

string Vhviow::SneiDRpK(double EOgTyjxposQxfG, int hgvHyRIEatEu, int evztkFhpEZiGR)
{
    int XItmSnJnFMJj = -744585613;
    int kmEXaNXbT = -678341013;

    if (XItmSnJnFMJj == -157333333) {
        for (int zAZwhLoGwRHBg = 1157975087; zAZwhLoGwRHBg > 0; zAZwhLoGwRHBg--) {
            kmEXaNXbT *= kmEXaNXbT;
            evztkFhpEZiGR += kmEXaNXbT;
            XItmSnJnFMJj -= evztkFhpEZiGR;
            XItmSnJnFMJj /= kmEXaNXbT;
            XItmSnJnFMJj /= XItmSnJnFMJj;
        }
    }

    if (EOgTyjxposQxfG == 874720.0215370182) {
        for (int KymTiTvdrMieOb = 1146334185; KymTiTvdrMieOb > 0; KymTiTvdrMieOb--) {
            XItmSnJnFMJj -= kmEXaNXbT;
            evztkFhpEZiGR += kmEXaNXbT;
            kmEXaNXbT *= kmEXaNXbT;
            hgvHyRIEatEu /= hgvHyRIEatEu;
            XItmSnJnFMJj /= hgvHyRIEatEu;
            evztkFhpEZiGR = XItmSnJnFMJj;
            evztkFhpEZiGR -= evztkFhpEZiGR;
        }
    }

    for (int djWAHVyDzKNCNc = 275536387; djWAHVyDzKNCNc > 0; djWAHVyDzKNCNc--) {
        kmEXaNXbT += hgvHyRIEatEu;
    }

    if (XItmSnJnFMJj != -678341013) {
        for (int SgFoPRqOyNbfJZ = 1601280706; SgFoPRqOyNbfJZ > 0; SgFoPRqOyNbfJZ--) {
            kmEXaNXbT = XItmSnJnFMJj;
            hgvHyRIEatEu /= kmEXaNXbT;
            evztkFhpEZiGR -= kmEXaNXbT;
        }
    }

    for (int WQjjxpVZbjP = 1473692242; WQjjxpVZbjP > 0; WQjjxpVZbjP--) {
        kmEXaNXbT += XItmSnJnFMJj;
        hgvHyRIEatEu += evztkFhpEZiGR;
        hgvHyRIEatEu -= hgvHyRIEatEu;
        evztkFhpEZiGR /= XItmSnJnFMJj;
        hgvHyRIEatEu += hgvHyRIEatEu;
    }

    return string("PWZoLOEmeISOgVkptFMLVvmWyOacyGKrAfpgkejatwyzqEkOypEhogVkaNiFuYjrKkfHYGhbAnxoDXXtlaeGSunKcrkDLmGowdNLONAPwnAVKTVPBxgYOPOxJPQg");
}

int Vhviow::JAZwIklTODBEWe(bool vMeHWMoYsUwMW, bool ODRfRfqCPwTh, int JUpkNYddrb)
{
    double vRizHsAQI = -95388.65983575428;
    string SBFWWH = string("q");
    int zKcsK = -155090131;
    bool FSHJmT = true;
    string mRiWmeaDdsZF = string("jwQxYEScKvgxjPgBHBOiIlCVrygxRRzYHuKgwamuQRyPrCWadGuHrVlHqRzIinTSZaRNOATwBWLJsGnTMoncCurLuWMpVQIEMxPtmXDtZQKCSqUDVRijFHbQtcrBrXmeJibFaHpllazcKdPxbRFkCIpUXsSMJPAPosBmRLdRkBWxkGvTMRmTLFoMJoXlOrYiOUTLWNQdVBclFqPwpkpBdEEqmkvbJs");
    string qZnJLHuxhhUJ = string("tEALwYccOaKwWwCgVeEdicfSyDVlhIFdhvAcnMJQxSdoHwKGjzTENaafFzEALIaArblHnXGplbCjGcKP");
    int fpGLAYDzwwnjl = -154518742;

    for (int SeLdKWzjGHvgG = 1094808052; SeLdKWzjGHvgG > 0; SeLdKWzjGHvgG--) {
        zKcsK *= JUpkNYddrb;
        FSHJmT = ! FSHJmT;
        JUpkNYddrb -= fpGLAYDzwwnjl;
        ODRfRfqCPwTh = FSHJmT;
    }

    return fpGLAYDzwwnjl;
}

int Vhviow::opSJJmbvwMQspBTh(bool ZeATbzxvFEqo, double IgjwTPpjDdRVu, double pqjaBBpJTZ)
{
    string tmSpkdXrEo = string("HpCydieCjYZAYEueYpQnSLbuwmVHffMziEDvIbEMZccOSrTMXhTPOSXyiNFLWsbFWlapdFrSqMJLLhSzsWsSHgMZWDaaYoBmwkPKUiCLmkaFDFoXDQtHtnjDgBzASFsQibVORWQjMYNIiHM");
    double RQxuLCsoJ = -803187.1894608523;

    if (pqjaBBpJTZ != -289882.8277442002) {
        for (int uAAmVPKimFFpwH = 71181565; uAAmVPKimFFpwH > 0; uAAmVPKimFFpwH--) {
            IgjwTPpjDdRVu *= RQxuLCsoJ;
            RQxuLCsoJ *= pqjaBBpJTZ;
            RQxuLCsoJ -= IgjwTPpjDdRVu;
            pqjaBBpJTZ = IgjwTPpjDdRVu;
        }
    }

    if (IgjwTPpjDdRVu == -289882.8277442002) {
        for (int lNIqQiVLzY = 759637026; lNIqQiVLzY > 0; lNIqQiVLzY--) {
            continue;
        }
    }

    if (tmSpkdXrEo != string("HpCydieCjYZAYEueYpQnSLbuwmVHffMziEDvIbEMZccOSrTMXhTPOSXyiNFLWsbFWlapdFrSqMJLLhSzsWsSHgMZWDaaYoBmwkPKUiCLmkaFDFoXDQtHtnjDgBzASFsQibVORWQjMYNIiHM")) {
        for (int GiKkCUBs = 400758904; GiKkCUBs > 0; GiKkCUBs--) {
            pqjaBBpJTZ += pqjaBBpJTZ;
        }
    }

    if (pqjaBBpJTZ >= -289882.8277442002) {
        for (int sixHPtLvUEzZy = 490979623; sixHPtLvUEzZy > 0; sixHPtLvUEzZy--) {
            ZeATbzxvFEqo = ! ZeATbzxvFEqo;
            IgjwTPpjDdRVu -= pqjaBBpJTZ;
            IgjwTPpjDdRVu += RQxuLCsoJ;
            IgjwTPpjDdRVu /= RQxuLCsoJ;
            RQxuLCsoJ *= pqjaBBpJTZ;
            pqjaBBpJTZ += RQxuLCsoJ;
            IgjwTPpjDdRVu -= RQxuLCsoJ;
            RQxuLCsoJ *= RQxuLCsoJ;
        }
    }

    return -1446445710;
}

Vhviow::Vhviow()
{
    this->TWFLUOkmJpGKt(449773.43689224526);
    this->dLSgxTH(-1663395111, string("DdbfaBadwoEcYkhlfzSRtonaLssFEvtGyqSnHfaJKHMAUnVXmGAHZblwepFpJFEIMLxbtnrbLtVqQeKYQcmSSameepgSHYFbGu"), false, 1126236103);
    this->oFEtjtO(string("lSSfDuFKoKxKwNMPyAttGveJhBxWhZvLIoUqIoutEPWJhmcpfZzOlkTGlgkfwVbJRfLtWycFaSfaykiiEzlVKZRRKPKAxCTQFNjQGDtgqZBrIFdktyejdQwPuHXcZCUyvTvUEPygbOzy"), 997685.4479675678, string("nOrsrtoAOehMdxuYpDIzraehvEwNlbhDFEJmVqBdAgBUsFokusLkaGMQbefdystZqCQEjyxQiyZNpjpGZYodXepPeXenyNVaYNzzbmBXLiwQieaNgchnMdcVwuPrnrhBQbivIhPjylObGfyZEDISjuwDaHLpPyVgxfXZnapnIXXhJXccgAgqWorqpU"), true);
    this->IDtur(string("pKCCmUzFZQwNASjtorHBDUOhcEHSYAtPppxIbOZmRDDcHsHirHgfsyhHWPGoUPKSyeNRQRrmqRjPeMfJREgXCtgJtXLdSFzllXpyhzlOcNQFJuTUkJeRnFAbZqlZKlgQubwsbUUWmRdRufkHYOFkWuijtXaybjAvtLRFiUbqrsDklbUJIgEoApcapAZEGvzXqmvHOuRfAiDZA"), 478598.4117825984, string("OhbxcFshHWkyJNQfSdLlWHCZDNmyWlFIBXTvYXyqNhynJoUMEDhOoUqVpyrqolGnKaWwtuVC"));
    this->ZKQymIfY(string("QVyKmTRUNdjcxzekFvwDWGkvzVRWTHUxMBxMBffDJQtdZeNihxiCdKLYBeQJpKBMmGpjczalDNkyLLQMzmwxtrEKtvXdWPnZQFeyXdoEksczdbfTdQRgffqylRqsPojZPMTWJEGJVYmCofsZpLdFkYCkGOan"));
    this->XwtlglafRtcy(true, -237526.8670667876, string("RQgSPytjtKIhNCJAuAXDOgykLOWXpVkXEZchRQJNUTcYtTzJMOxwiyzApDjjERdkEWFLjIbFYfAtwShxZMZUodoVUrtUpPjj"), false);
    this->EfBIsTxD(string("BZlgSMPjPBhpWbwpZFJEbRONvMfhISEyHJukTRqprOleyaFrciZmnhzEAsBwAmJZtfJLpkPRkigbeRMQHzftfNOpACfcxXgNOrGwKTdndEmpCjMMtHXVhuJlkvyIMOKEPZxmiobQxDBCZeknFNpeoddNrIuKxzBBrxDJEVxcygYXepMfStqJEYjUtHYyUyhDUtPnsuoBgHCWJqgjesapiwyfhCaWapwawiOyoiSGckNLmHRVnVvDpyBphXvpyi"), -1788801203, -2117599116, false, true);
    this->wIprLXOWKnCgD(-848777900, string("aSwerpVzYQjjDtMTMUzUnSEjJIOMPpriwzyZWsvHSaiGbqYbwYgCYexKnPYvzPviuVWRXXoclLEfAkDIunjQVsqCxiBJGiBOrIRQrgJXhDcpkaMAtFtYPgEVRbaYaGThlZZiqXLnROSBLJqQQtswgSjWxSmjf"), -1624905577);
    this->SZlVZtPdvg(-2037154915);
    this->oqCUT(false, 2106111542, -1164622865);
    this->hDgxcQXeTi(-436341364, -891738.6004684622, string("wlGtRhNKCCpIdbAOIDTvpHwwflLigaMcTMxUSaMSprxcgUomfhzoUJohIpasuVzUiLvrplqfJiQBKVlkgiBZkNxchtSaLWSPzEWKSjTkMgTvKETskyBMisdNrDzQddxhPAdqFcZVjJfqYxFaYYuJBvPybsPAgCrdmAmQIG"), true);
    this->SneiDRpK(874720.0215370182, -1781194723, -157333333);
    this->JAZwIklTODBEWe(true, true, 1350060816);
    this->opSJJmbvwMQspBTh(true, -289882.8277442002, -250680.9050679289);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class waaHFxqdMyNdKgg
{
public:
    double DHnsxDEIg;
    int ABakZJTfxEPzw;
    bool JjVAM;
    double mISyusG;
    int MhmnvDPkUby;
    string xMkGOYgnnCAvwG;

    waaHFxqdMyNdKgg();
    void IYrpRxTa(double NrwyKNpc, int bpkXN, double JbWQhUkQQHWJKJ, double HWfeSbnFVj, double bTWsgtpaijUTkLcq);
    void HwtqesQjyxrgb(bool StcctHzHsoTTSnB, bool FsnYHQGpnaW, string AgtBzFOdA, bool QkKxzXtOKpDHgH, double LLnHIXDPGVJQ);
    void NCtHJgZ(double XzfcvzWbndJY, bool wrEntqU, string NJaHfIkHLPwcrm, double ftTEN, double BRbXSsuxmscsQr);
    void NomFSHa(double ZQRyCEypWrUf, string rMDsGTwOeO, double fFyuUkGs);
protected:
    int rNYLFfw;
    int PumGGaHKWJtdE;
    double XNXqDCdejCl;
    string JpRuUdjdqYHkkBCX;
    int wJrioSRIbeh;
    bool wEeTPgZXDRQ;

    int xmAAMO(string NoybLvPmR);
    string nvjOrY(int XVdSh, double zTTioB, bool tHZIQqz, int CSJEAqjwduSVhr);
    string KNMRQtwT(int RkcXofoNF);
    int nrSuuUtEfacxnHBe(string swJYRvvvAefgCF, double qPyWwJYxn, string iJKVSmTn);
    int IkGnTkGf(double VostVDGnDAQUfCa);
private:
    string jYVSEJsQkb;
    string xadQGlxdzaYEJJ;
    string PnDfth;
    bool IecBhTIfebNM;
    string YjrGvNQuIumAIwl;

    string fwyKvqYgKO(bool xSgaLNQo);
    bool FqpXsZLxzpzFK();
    void FqNeHVG(bool msOrBbAol, string CkICnkNE, double uBAGqiTmLCll, double rbBZGKBootdnrOn, bool sKAfroAyr);
};

void waaHFxqdMyNdKgg::IYrpRxTa(double NrwyKNpc, int bpkXN, double JbWQhUkQQHWJKJ, double HWfeSbnFVj, double bTWsgtpaijUTkLcq)
{
    double RLIfAiDZbj = 985994.119813855;
    double UTfyNWiPuoLum = 719807.3682610829;
    string DiJIAau = string("wwmSRfxxIQKeKtdzKATRNtVfCyVYaCSgSPYWovumMEQldNyubyOEWAOmUbJyEkdGtnSwheAwCgzBhKlaVvmsUcNDbvLKhgNIHdpijgRlnGcJXSpPdPGJuThglJvgcypKMp");
    string pMazETLOxaW = string("JnbxWIyLGZMjaHPpjEVGgBKbdCIhlTSgDzDgdCICCgdfouHuuopJjEeAuThRyPPKlRyDLkpKSPKtmUKGTsSOIAKmJTTUUOdfzjSiiTZGIVeaouDPuTYdYWlpchbiqvvyWbSJzDlGQOKkLRQFpkeyMFMWoUnpuiUOJHVTxRAmqlyHKBAQJRDQnrxWSgimGnMFIDRXLLBDFjGbfQFJyTHmVaLXafxebwkPVyZv");

    if (bpkXN > 254219432) {
        for (int BrmFIMIje = 510133926; BrmFIMIje > 0; BrmFIMIje--) {
            JbWQhUkQQHWJKJ *= UTfyNWiPuoLum;
            bTWsgtpaijUTkLcq -= RLIfAiDZbj;
            JbWQhUkQQHWJKJ -= NrwyKNpc;
            DiJIAau += DiJIAau;
        }
    }

    if (RLIfAiDZbj <= 719807.3682610829) {
        for (int dKJXuHjqstdXNDov = 629937573; dKJXuHjqstdXNDov > 0; dKJXuHjqstdXNDov--) {
            continue;
        }
    }
}

void waaHFxqdMyNdKgg::HwtqesQjyxrgb(bool StcctHzHsoTTSnB, bool FsnYHQGpnaW, string AgtBzFOdA, bool QkKxzXtOKpDHgH, double LLnHIXDPGVJQ)
{
    bool wCcCJPrTzvnSNjXW = false;
    bool qKfEjMHXFIYnDmuP = true;

    if (StcctHzHsoTTSnB == false) {
        for (int YHaYLIDm = 225023188; YHaYLIDm > 0; YHaYLIDm--) {
            FsnYHQGpnaW = ! wCcCJPrTzvnSNjXW;
            qKfEjMHXFIYnDmuP = ! FsnYHQGpnaW;
            FsnYHQGpnaW = ! StcctHzHsoTTSnB;
            QkKxzXtOKpDHgH = wCcCJPrTzvnSNjXW;
            StcctHzHsoTTSnB = ! QkKxzXtOKpDHgH;
        }
    }
}

void waaHFxqdMyNdKgg::NCtHJgZ(double XzfcvzWbndJY, bool wrEntqU, string NJaHfIkHLPwcrm, double ftTEN, double BRbXSsuxmscsQr)
{
    int pittOR = -2144221570;
    double eNKBRKSGbLUyiWM = -928720.9146140217;
    double AhBGzA = 98993.63077321304;

    for (int FeoGmEkvXWDnx = 1735052958; FeoGmEkvXWDnx > 0; FeoGmEkvXWDnx--) {
        XzfcvzWbndJY -= ftTEN;
    }
}

void waaHFxqdMyNdKgg::NomFSHa(double ZQRyCEypWrUf, string rMDsGTwOeO, double fFyuUkGs)
{
    bool GgSZpqe = false;
    int ZxWCpvxve = -134765829;
    string mbcQBg = string("PifUuCSaMfqGTJecSLUwjyAZiVKfWAurtbTtRSMWeaalQbvAMDLRtSHzFZiOPxyAAywkafqcvQEtQGgyo");
    int niHtsgPBmARU = -842705473;
    bool kbnqJK = false;
    double QKNMPeI = 417794.918615858;
    string dzuvYvjURm = string("YGiDleJnZDJPrNoeIQVJcLplULE");
    bool qmdbuFjhy = true;
    bool fYOZMJbFwIh = true;
    double ApDzhKj = 165211.95147595223;

    for (int kotqmpGSQqpe = 882894663; kotqmpGSQqpe > 0; kotqmpGSQqpe--) {
        ZQRyCEypWrUf += fFyuUkGs;
    }

    if (ZxWCpvxve >= -134765829) {
        for (int wWrWGEkmyv = 1949244826; wWrWGEkmyv > 0; wWrWGEkmyv--) {
            qmdbuFjhy = ! kbnqJK;
        }
    }

    if (GgSZpqe != false) {
        for (int juAYjuYoSPKma = 340736516; juAYjuYoSPKma > 0; juAYjuYoSPKma--) {
            ZxWCpvxve -= ZxWCpvxve;
        }
    }

    if (ApDzhKj < -207570.35588578306) {
        for (int BsxbiteeK = 910313010; BsxbiteeK > 0; BsxbiteeK--) {
            continue;
        }
    }

    if (niHtsgPBmARU > -842705473) {
        for (int aoGfOnlnKlMwgRYd = 644300363; aoGfOnlnKlMwgRYd > 0; aoGfOnlnKlMwgRYd--) {
            ZxWCpvxve = ZxWCpvxve;
            fFyuUkGs *= fFyuUkGs;
            fFyuUkGs = QKNMPeI;
        }
    }

    for (int IDnMDUYQ = 1898360460; IDnMDUYQ > 0; IDnMDUYQ--) {
        ApDzhKj /= fFyuUkGs;
    }
}

int waaHFxqdMyNdKgg::xmAAMO(string NoybLvPmR)
{
    int qedkRYBpYnrrcKG = 2036595469;
    string zDvUWLseLcAQAHAs = string("imRlfzjxdDKqsEzKlgBaWghVTBcYlVSNjVnrgVegQEcrwwBdfdDumutxpZdnZpEoCcqSbcXwxMqQOpGvuKuYyaCPFhdqdEIAIvesptvUCGKBGjJMFWMTpsXykrpPWGwnNbMJhUzVeUxSHvMAsPWqANOpNOEqMzSTBiOQsAhBUntqQbYZJVuOzIEvdKUsiaLu");
    string NfxTUQoaW = string("oLiGmuZBIgVZDfImKpJUHzvvdWJIhZDcNWMCycYrZYyIpOZkYWbeeYKdLJxOuvcLchPraiqnQZKVRKyqvVatXZKTzfvvhvSRTgItQSXabVsXNvFoncVkKKclrPiAhlggsPESprMuwiRzLzVzcEACY");
    bool pmccf = true;
    string jVjSkz = string("zjU");

    for (int tdFUPBKQoRJTDQg = 711866445; tdFUPBKQoRJTDQg > 0; tdFUPBKQoRJTDQg--) {
        zDvUWLseLcAQAHAs += NfxTUQoaW;
        pmccf = ! pmccf;
        jVjSkz += zDvUWLseLcAQAHAs;
        NfxTUQoaW += NfxTUQoaW;
    }

    if (NfxTUQoaW < string("imRlfzjxdDKqsEzKlgBaWghVTBcYlVSNjVnrgVegQEcrwwBdfdDumutxpZdnZpEoCcqSbcXwxMqQOpGvuKuYyaCPFhdqdEIAIvesptvUCGKBGjJMFWMTpsXykrpPWGwnNbMJhUzVeUxSHvMAsPWqANOpNOEqMzSTBiOQsAhBUntqQbYZJVuOzIEvdKUsiaLu")) {
        for (int ubPzfebZ = 1920780290; ubPzfebZ > 0; ubPzfebZ--) {
            NfxTUQoaW += NoybLvPmR;
            zDvUWLseLcAQAHAs += NoybLvPmR;
            jVjSkz += NoybLvPmR;
        }
    }

    for (int jjFsYzMbRaph = 998175522; jjFsYzMbRaph > 0; jjFsYzMbRaph--) {
        zDvUWLseLcAQAHAs += jVjSkz;
        NoybLvPmR = NoybLvPmR;
        NoybLvPmR += NoybLvPmR;
    }

    for (int vmTYCxbstOBI = 444845172; vmTYCxbstOBI > 0; vmTYCxbstOBI--) {
        jVjSkz += jVjSkz;
        NoybLvPmR = NfxTUQoaW;
    }

    return qedkRYBpYnrrcKG;
}

string waaHFxqdMyNdKgg::nvjOrY(int XVdSh, double zTTioB, bool tHZIQqz, int CSJEAqjwduSVhr)
{
    bool gKguvmGvkvxHFz = true;
    double nOzTwHjZZsy = 552237.1234981297;
    int YepGecfDmBLuy = -1118849209;
    int MhmdoJBZeOelx = 772794598;
    int bIoqlB = -870433326;
    string tItQlCkWZmMr = string("JjJpKFcqtDLelZcokhQNGGwkNrkpJBEUITHYPAYWVffDUSHKJzVsyUdFiAFruslmzSmRFnWEYcXiXKiBSCkDkcGFaHPxlElgofMZLsMjbSTQliJleqAGtedWfbvBCJYFoYqmJUoylTtRqbAXKoKvibMHyVFgBhNGxybfcmWCIYVZDRqjldjsHifPSYRJIQbASeyxASWGXAZjpTLbIPUPdoaXLqGJUYmSgVSgAQSCts");
    bool bIdqLBVDSNEjzL = false;
    string WTgwI = string("dIVEXskWPlqbTaoiQuxZOfDEIQXIlRrUNLWZBpZZEQYanVGSrrNmWCquizrsjrbywxqPypwarVjZYMcbORtSNjefRbkAeltPLeRWKaWndzmYJdjrPgcAYevyAhQaCrpRzanjgmdmTkYTVpOxOuArp");
    int OukKRfTddBT = 114045588;
    string qHCVpLahJEmzFpP = string("nmEaziKzIRnpiQjSUoUAdwjTHlmKhCzlhAkfXqDVY");

    for (int EgHxPnQbHAhg = 1305847; EgHxPnQbHAhg > 0; EgHxPnQbHAhg--) {
        OukKRfTddBT += OukKRfTddBT;
    }

    if (zTTioB == 552237.1234981297) {
        for (int dLiIggpXfIP = 676820096; dLiIggpXfIP > 0; dLiIggpXfIP--) {
            OukKRfTddBT = OukKRfTddBT;
            tHZIQqz = ! bIdqLBVDSNEjzL;
            bIoqlB -= OukKRfTddBT;
        }
    }

    return qHCVpLahJEmzFpP;
}

string waaHFxqdMyNdKgg::KNMRQtwT(int RkcXofoNF)
{
    string FLNoMfgTpmGBY = string("yPhLGIUEfKYSjFtfeKL");
    bool rgJMZOGfToeMzE = true;
    string IohhjRdQPOMX = string("WuybIaCMrkFRKCzBSuGySoxcSLPxRBKjlNusSbD");
    bool LeqBopCDSE = false;
    int yddxX = -1693575155;

    if (RkcXofoNF >= -1693575155) {
        for (int YgbaoCLfyOMS = 886193785; YgbaoCLfyOMS > 0; YgbaoCLfyOMS--) {
            continue;
        }
    }

    for (int zyYRxkHXWYXiHl = 419825278; zyYRxkHXWYXiHl > 0; zyYRxkHXWYXiHl--) {
        FLNoMfgTpmGBY = FLNoMfgTpmGBY;
        RkcXofoNF *= RkcXofoNF;
        LeqBopCDSE = ! LeqBopCDSE;
        FLNoMfgTpmGBY += IohhjRdQPOMX;
        RkcXofoNF *= yddxX;
    }

    return IohhjRdQPOMX;
}

int waaHFxqdMyNdKgg::nrSuuUtEfacxnHBe(string swJYRvvvAefgCF, double qPyWwJYxn, string iJKVSmTn)
{
    double uzVxKF = -186045.44000502466;
    string AzkUqCbMTi = string("wGgACRpAzuRRPQNALJQODOFDnkGNZOrLXzrpHGIjwPtCOXsAzcQKIArDaHPsJPwQmZkrcouZVcEAdXWseLMIcQEOfWbzAsFsWvXAsNEbRqHKqzSKvtLsNqotPQsfrxqNoqOnbtMhxljFzyozECCItmTRNkkEAYvJhNcrqHHWeXWblErJpizEUayVJm");
    double ysJWtJjXPVVeXUzy = 743936.1108122251;
    int nNDMFd = -1157358207;
    bool zcidkVP = false;
    string JgHCiMHLoNmRG = string("iMvMqnzTcnPGyFCcBDDLxCGpsHtgUpnMMQEaPWWZGzBVPrWvvnVYbgaCmWyXwtdhIYvdlJWXKnwtmmblkJDkTzWQIRhRpUBxdrmrxnmrciE");
    double lbDsdp = -251349.5498883587;
    bool shCAZOuEP = false;
    string ECixTbQy = string("dplAPmcMVbufdkRnlgMgtfaKAVOlRVahQVxMMPrbTNSEoZuhYMkamTpCjemBKctQJcszJjKJPkkdEvJAcIIPtHCHGAbpQuqpyKZTQuBCzafYFsbzKvnGpXAaaDqrILqrBYnYuZugvXiexePWXjgImHlNieELBQkHQBSSnOSOQTFGMLOJfNQTWsYFuAIaAZbzZNdKeyTxDAmwyrgBVVYfQBxoFMpiSyVvetrGmVGQWTcDuGtaQGdfT");
    string CHWXlE = string("autNEQqDYSzlwPGbSXjXJwVKygcaMwKXxaeMZRRmOHfheZDdMVHgkczyqAyZhunEXLhlsQroaQ");

    if (qPyWwJYxn != 743936.1108122251) {
        for (int wviATCzliUOyhriN = 768345563; wviATCzliUOyhriN > 0; wviATCzliUOyhriN--) {
            uzVxKF = lbDsdp;
        }
    }

    return nNDMFd;
}

int waaHFxqdMyNdKgg::IkGnTkGf(double VostVDGnDAQUfCa)
{
    bool mmkBENcQhxBCXQlu = false;
    bool JZBgaAmpJtsiafPh = false;
    bool fPOyKmtIhyqginNh = true;
    string PtLSfurxsWd = string("oYBsZVaDdsGvQxdwaJBCEuTYAwRVjqGTJvVOpUqTdYIGBAwbdXYZDgvzAhOMRNoZBYnqheZBwGxLznVIxIr");
    int IgtkJMrQZaGRiXd = 1882735810;
    bool HRyHvZCkVxiVZ = false;
    bool BGqivKirDFhge = false;
    string hxFieYUEEmqWbG = string("CNXMTBzZkoGuGeijjraiAqFAQyugmUtCslzFQucpxAzuagOTYIPvXLjLpbwUNmbycESiltfJIphWZkUyOElHZUVdvcFKFDqpjdbiLoBHwgRKCHPVHbdoEQgDGfROnzjJqYwDuULkVJGDeeDaAKAvSaazWqaEXNJXmpyoSwDDmbllljaNIhB");
    int VMmDDNRd = -1810342971;

    for (int OsnBocgr = 58413123; OsnBocgr > 0; OsnBocgr--) {
        mmkBENcQhxBCXQlu = ! mmkBENcQhxBCXQlu;
        JZBgaAmpJtsiafPh = ! JZBgaAmpJtsiafPh;
    }

    for (int YMUAPaNYNFfarc = 554482093; YMUAPaNYNFfarc > 0; YMUAPaNYNFfarc--) {
        VMmDDNRd /= IgtkJMrQZaGRiXd;
        IgtkJMrQZaGRiXd += VMmDDNRd;
        HRyHvZCkVxiVZ = HRyHvZCkVxiVZ;
    }

    for (int VCoTzpOWd = 139354614; VCoTzpOWd > 0; VCoTzpOWd--) {
        mmkBENcQhxBCXQlu = ! fPOyKmtIhyqginNh;
        BGqivKirDFhge = ! BGqivKirDFhge;
        IgtkJMrQZaGRiXd /= IgtkJMrQZaGRiXd;
    }

    for (int qAndQmTNbTmpjf = 895572944; qAndQmTNbTmpjf > 0; qAndQmTNbTmpjf--) {
        hxFieYUEEmqWbG += hxFieYUEEmqWbG;
        JZBgaAmpJtsiafPh = ! mmkBENcQhxBCXQlu;
        BGqivKirDFhge = ! HRyHvZCkVxiVZ;
        JZBgaAmpJtsiafPh = ! BGqivKirDFhge;
    }

    for (int SOHno = 1438665267; SOHno > 0; SOHno--) {
        PtLSfurxsWd += PtLSfurxsWd;
    }

    return VMmDDNRd;
}

string waaHFxqdMyNdKgg::fwyKvqYgKO(bool xSgaLNQo)
{
    bool CkzxLcHzEZrLDkP = false;
    double ZWXllwtUs = 186278.14725198;
    int vlLQocz = -1695687333;

    for (int bzqSmVz = 2125545144; bzqSmVz > 0; bzqSmVz--) {
        xSgaLNQo = ! xSgaLNQo;
        xSgaLNQo = CkzxLcHzEZrLDkP;
    }

    return string("eyYsGPcCzUXfWoRsXyFZhuxVdOPtMJImiZaPflFGemWqobDOBJCbPyfZuItPpqSaNAwivIYBXvNCMcZnSAaROOOfESMVrGFrkPaYRYH");
}

bool waaHFxqdMyNdKgg::FqpXsZLxzpzFK()
{
    bool iHjGWraN = true;
    int EBGjvFrF = 282054851;
    string fpiviRZClR = string("iAEKmvgTysLjUPZrsFPVoWsAlpFHEPAQaJsrOsgFFMQNARPVoVQ");
    int WViRDREukTgW = -1436912660;
    int dzwPvCeZvYDVVKgP = 1637342247;
    int EhiMlSTuPW = -923075756;

    for (int JtCGXS = 1142347992; JtCGXS > 0; JtCGXS--) {
        EhiMlSTuPW = WViRDREukTgW;
        EBGjvFrF *= EhiMlSTuPW;
        dzwPvCeZvYDVVKgP /= EhiMlSTuPW;
        WViRDREukTgW = EhiMlSTuPW;
        EhiMlSTuPW /= EhiMlSTuPW;
        dzwPvCeZvYDVVKgP -= EBGjvFrF;
    }

    return iHjGWraN;
}

void waaHFxqdMyNdKgg::FqNeHVG(bool msOrBbAol, string CkICnkNE, double uBAGqiTmLCll, double rbBZGKBootdnrOn, bool sKAfroAyr)
{
    int BjUpghdQubqj = -504247496;
    double thBNm = 436150.3544483837;
    double DJkqfPod = -770910.3092741246;
    string cJfBr = string("kNZNgVOIExydPu");
    double rPnPkMxXx = -503439.4449398688;
    string FXCYRuXeF = string("XLptYAhkqRWctzPscUkBbxVXridoHOxqYGWalLbCwsAXeKslCZO");
    int nDLlejgi = 440664810;
    string PKmiALsxqEuyfxL = string("WiM");
    string lmntXU = string("egBVgOyiTSrZkAktXVUjBnVpdnkfrWJlewoHxxGOqwsVdehWebQQSXJXEMVvrimZjBDXpqLvLdCgmgZYGpKkHYTjplemVTVDoJzjAOynypQFBfsMcAyWYpJfjqgJbSDwqkRgJcOOQePOsUEaKqGT");

    for (int WQeKtCypFus = 490115731; WQeKtCypFus > 0; WQeKtCypFus--) {
        continue;
    }

    if (FXCYRuXeF == string("WiM")) {
        for (int TBalOHTSPSmzLXL = 1870709804; TBalOHTSPSmzLXL > 0; TBalOHTSPSmzLXL--) {
            DJkqfPod /= thBNm;
        }
    }

    for (int QCHFtDjkwDsIgip = 512306682; QCHFtDjkwDsIgip > 0; QCHFtDjkwDsIgip--) {
        continue;
    }

    for (int fjzQtyVSIqf = 321559279; fjzQtyVSIqf > 0; fjzQtyVSIqf--) {
        nDLlejgi *= BjUpghdQubqj;
        rbBZGKBootdnrOn += rPnPkMxXx;
    }
}

waaHFxqdMyNdKgg::waaHFxqdMyNdKgg()
{
    this->IYrpRxTa(-232699.5405354223, 254219432, 714900.0132386403, -853934.8962067596, 480456.86655377987);
    this->HwtqesQjyxrgb(false, true, string("bduBcsHUQcYhPZxrQOvNbWmYdxijLlQoRcLGaihZCMDKtraKbTukldENCKfMKyvQkdpSqWjeEJwCnIOoxGIFCHjYQyZkukQNPmOzm"), false, -1027433.94019734);
    this->NCtHJgZ(-201720.99304339904, false, string("w"), 1014165.8141247539, 292870.4151695974);
    this->NomFSHa(-710840.3855914673, string("VDLUcxcCtycnjnWqYrVBXyRHcdwoaHilUUUoQxKlfqSbFmCpKFTGxBkfEpEVpsWNSXXXomVjCDSkAingEMpQmGFHTSALEiuWEGFXBUbRaVygyqhvfmrPTzRTIsdtRmJPFwKqCcTUTWELQvLrkhqacxnRKPXWpQLwSOAWFeXipna"), -207570.35588578306);
    this->xmAAMO(string("rIWjpAqNPFZSrnyVJngaRUIGaXsofKUsEOZNctRLRYDAlcbdfpCUFmRHEXTxSZUpKDaMirRvLURbrOMlWyrSJYcTmLRrTkvpjAXmBwfhZkWKtyYyHNigAzybHGJEVFniHhKJBlaESfRomgixIMeHnJbUJBUNvwxYoZBLcuuCvqiCbhRZjoPLtCaCyQJwXlcLSOwwdqoHaDlNguowDYGB"));
    this->nvjOrY(-679311623, 461057.3447255471, false, -772626387);
    this->KNMRQtwT(450679863);
    this->nrSuuUtEfacxnHBe(string("OsBfSTORxjhzlCqCQLdFyCFGvNRGtaCRbEsXSkfhjkeNXEyJBLEVhtpxJtsuIVMYbvnZSJwiHsFLoEPeMePBNSTYtbtLkuXKukIdASbFlfUIuUHviiHyPpIZBxTpAHWUsCZJnlEvFOZGwizWPYoUFEULDUypwAvYDRdqJOHZuX"), -702617.2252360125, string("MPUAFmARBOknrbkbqEtyxksPYxPtZBUMRPpNkBcVzRTfiKtsxwjTzFyYPgOwyNmyeeefuMtRvogUBaJjMvvOBeRCrKrWrmJARwMfGESNraXhfwpXD"));
    this->IkGnTkGf(-551310.1423091034);
    this->fwyKvqYgKO(true);
    this->FqpXsZLxzpzFK();
    this->FqNeHVG(false, string("FiJnFlowRJDNwCErliJudaSrxNHYlqmDKROUmOOOcCukKZHKxGTRcrPJQyQAjLWUKAaBknJGnPievCJGuFvaFVwIYNpSRWAcavjEblFEfiyeMucm"), -636306.7900477231, 863739.7785356455, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iAQqBudQ
{
public:
    bool VzsIPMWDPirxCjZt;
    bool PAjMoUutta;
    int SQIFsRnSUK;
    int iLFGpPwnRKVhCpn;
    int TwxEDTacd;

    iAQqBudQ();
    void EioHyTrlVPFB();
    void DDapAoj(double DLTZlUOCE, string JJAElSIpjthvZg, int pYsVmWExeHVfxRBf, bool FkKsCFIbvmAm, bool iyXgg);
    double WvjnRrt(double qMsKhNaISnqq);
    double yaAzrgbwFMUzNe(double UDuVesVQRechjcmc, int yubKKHtXiagBat, int vTxZCgvwjBFjyR);
protected:
    string PRZyLZimxi;
    string nejxKbcaRfnclMj;
    string mFbYMCC;

    int seMfirpcyfFRtYat(int huNqtddLtekuQo, bool slzzjoqWS);
    string nGKmxacrcJEOcxQ(int nBTGiTURIyZLunZ, double DWGtaKBJUcQIB);
    string MkXdMPgVEgZeleL(int rOrIthPU, int ybrIPh, bool NWvVzh, double cbmRc);
    double KXtXCvMcxkMhoGyd(string fVtWm, double dtqRcufAmqrmJ, int jFFKooxGzJdu);
private:
    double vXFeWrMqXxCfVXY;
    bool aGZejKqRbBWB;
    string ldCYTdgkCYcLPK;
    double xMGtZj;

    int LArKBTsWlyNhl(double xhjIsDwMEgp, string dhgxF, string bPGosrFm, double OBhNTGPCvrBYw, int HDkSu);
    bool JGyYEyUILEK();
};

void iAQqBudQ::EioHyTrlVPFB()
{
    bool zJGiJGQuQF = true;
    string IlcQYysvLFOtfU = string("jlbFNCZbtvxjIwlXATUCTmHaMMdQSrTOdcGKuIHczmQnemOcQcWjnOTGiVLCJPbEUzmQxmKACfuDmcogdsyZrWLmwZMuqKyhdYNNGZIbxNhrzgdldiFhtpRJXAAtYdFGoWgGFEdNMaEqmlWqKdxCyoEJSOEQEGxOMvSfuDLCOETcJEKqUYRCZTXNvbuTpGsYvQwCOGSEcBmiVChQfinCFnVBEKpInBBfIzRrLqDZKhtMqPvuyJuwGHDXuG");
    int WoEaMYbbsH = -1311646592;
    int xoEBKtDRe = 474741913;
}

void iAQqBudQ::DDapAoj(double DLTZlUOCE, string JJAElSIpjthvZg, int pYsVmWExeHVfxRBf, bool FkKsCFIbvmAm, bool iyXgg)
{
    bool swxnVgIL = true;
    double JpssvUtTNatjw = -839884.6938224537;
    bool gOGoDkC = true;
    bool ZTEIlQnYLSurIX = true;
    int yInfOeEaSHwGJQJ = -890103241;

    if (swxnVgIL == true) {
        for (int WbaSGaZuTKFzqft = 422563773; WbaSGaZuTKFzqft > 0; WbaSGaZuTKFzqft--) {
            ZTEIlQnYLSurIX = ZTEIlQnYLSurIX;
        }
    }

    if (iyXgg != true) {
        for (int SChNtcLd = 710424617; SChNtcLd > 0; SChNtcLd--) {
            swxnVgIL = ! FkKsCFIbvmAm;
        }
    }

    for (int BUiJRmtdoMFdk = 719258291; BUiJRmtdoMFdk > 0; BUiJRmtdoMFdk--) {
        FkKsCFIbvmAm = FkKsCFIbvmAm;
        yInfOeEaSHwGJQJ = pYsVmWExeHVfxRBf;
        JpssvUtTNatjw = DLTZlUOCE;
    }

    for (int JynSDdMnhgssKG = 888801797; JynSDdMnhgssKG > 0; JynSDdMnhgssKG--) {
        swxnVgIL = FkKsCFIbvmAm;
    }

    if (gOGoDkC == true) {
        for (int gRVCEMjoKNt = 825378570; gRVCEMjoKNt > 0; gRVCEMjoKNt--) {
            continue;
        }
    }

    if (yInfOeEaSHwGJQJ != 172300569) {
        for (int VyTIdp = 1119147656; VyTIdp > 0; VyTIdp--) {
            iyXgg = ! swxnVgIL;
        }
    }
}

double iAQqBudQ::WvjnRrt(double qMsKhNaISnqq)
{
    int xzSHPrUJEDye = 594094792;
    string XQTGvAneSM = string("DugcOvmSgYZrvSGUddZjkrHecddsAZmgetfiinZyVrfKOHrAUzCAOTIeTsuZJalppwDPkQnXEnHhBLyosBlmrFNWupmmuFgAdRsNqJkDaFTrjbSCmyWtQMELTQTaHhioOBBnskhdDPFooppHfpvuNtwUY");
    bool ZkzUzfVwiWLcq = true;
    bool uqIuFqWEGNBq = false;

    return qMsKhNaISnqq;
}

double iAQqBudQ::yaAzrgbwFMUzNe(double UDuVesVQRechjcmc, int yubKKHtXiagBat, int vTxZCgvwjBFjyR)
{
    bool Qgpsxzq = false;
    double UhBaOzng = -681599.8768411851;
    string VJxfsNbo = string("BpgeCvvebfbhzQuyjWbwimRhTqCiPizawCKKYhOEijdBzisNJWOaZStTxbXZlFxrssouoZNcYlSvXcywbzguzOaWmuEmBrWmwqPKugVXizBuDKJTspOjWPqGbVTaKCbNvycXD");
    double eOFieaALgqgZnJH = 30379.644066707006;
    string WCrtaxMe = string("rbIgJT");
    double eauQGBQWDSqhMiGl = -566191.6665446676;
    string UoXwEk = string("MFtaxqTozSDTOZDJPFTGXjrqkPdLEbdfJuMuVHwzKPIdLoYsCALHqeySLuVEDpDShUHgJPRcjYbgYNyAXkUVENGJfoURhIVJfJYaXqbqUqBsvHawNGwlcddzxiMOWiCcAUsqNGKDYKxJCjmsoTDlfOvqByNoNbPqlkCueVvoSeosejIVwCkFlDLmqMSFwnqgBWwBweQMm");
    string TjvfAukJuqfRYsgH = string("arHQYpYtEfYiacPyZkJHaWKvjUEYPgAofZLLAEBEMutMKQCLvtsRuIDWMGIcblndUyMYyDiwLEVUWjQHukKMCxtgnezzyVNVucQhOclqOUYMoDJeEHsxmdHtloRbDHnZsZukfvhmokYZqhfQPqyAiFGJpyozBKVSIawxeDPvmTmOy");

    for (int TcJvCAXNCnUANME = 953378355; TcJvCAXNCnUANME > 0; TcJvCAXNCnUANME--) {
        eauQGBQWDSqhMiGl = eOFieaALgqgZnJH;
        UDuVesVQRechjcmc -= eOFieaALgqgZnJH;
    }

    for (int hzPxjYM = 465582207; hzPxjYM > 0; hzPxjYM--) {
        continue;
    }

    return eauQGBQWDSqhMiGl;
}

int iAQqBudQ::seMfirpcyfFRtYat(int huNqtddLtekuQo, bool slzzjoqWS)
{
    int SocBzH = 157744332;
    int rOMdy = -4104173;
    string qWmhHtSVOLXPy = string("GtOmfeqluDhosrCZGuCmyxDPgjIBZZqCnGnmpnsoWXYXOVjadOPcCNJitnSuSVBBYxsEroGwXstxVW");

    if (qWmhHtSVOLXPy == string("GtOmfeqluDhosrCZGuCmyxDPgjIBZZqCnGnmpnsoWXYXOVjadOPcCNJitnSuSVBBYxsEroGwXstxVW")) {
        for (int GkumYHWYQvcFRJA = 1037861592; GkumYHWYQvcFRJA > 0; GkumYHWYQvcFRJA--) {
            continue;
        }
    }

    for (int fbttIZvVviTFbQyN = 2030661451; fbttIZvVviTFbQyN > 0; fbttIZvVviTFbQyN--) {
        SocBzH *= SocBzH;
        SocBzH *= rOMdy;
        slzzjoqWS = slzzjoqWS;
        huNqtddLtekuQo /= huNqtddLtekuQo;
        rOMdy /= SocBzH;
        SocBzH -= SocBzH;
        SocBzH -= rOMdy;
    }

    return rOMdy;
}

string iAQqBudQ::nGKmxacrcJEOcxQ(int nBTGiTURIyZLunZ, double DWGtaKBJUcQIB)
{
    double ehcIGDdoJg = 324221.979710314;
    int HBsQYx = 570813429;
    bool yGQgEf = false;
    string kjvna = string("fcCNnDbJtuulglsTfpsnuFYNdkNvnMUbwfTaHGFHyxopinOrkIbfEeiJdmCQDiWVVvtCNZgxdwVfwPqriJlIchLBCGbheDLzKTmgoSucPMcGTIGpAxTxfOtKzyMDuTcJCvLtoeeupAmWolXAgbCDClMl");
    double eFmIOlah = 598190.9231253843;
    double ujDUWDIuHdxObBZ = -749630.2700169785;
    string xkHQpYUwujKeVdj = string("YvXafVygQZEmTvStKjaQLVrXsDPKCkPHwYXESbQVPFnzrkPDSwaFaQTluCFdShSItjwLURalOPYbYQwfrCdFvMcEuASHEHgjzSaHPLfrlHYBpwGopOsKyIvRyXIcZZoRDWoGmkKTrUnyBTNiYmZgWZiyoJHKQydsdkjlAeCfctJWOcebfZLYmfhJvKXPEWOQpOcoAMzvRlpSRqEoVkCbhsiPjpAstpvHfpJgFbIDmQRYHewmyksat");
    int tVqDYdC = 1444254676;
    double hbMWtvcTOn = -107572.51497948082;
    double NkfkNsiyXRpNpupm = -625666.6137372769;

    if (DWGtaKBJUcQIB >= 272422.832728805) {
        for (int pjIdRbWGCoKjG = 1290178252; pjIdRbWGCoKjG > 0; pjIdRbWGCoKjG--) {
            kjvna = xkHQpYUwujKeVdj;
            eFmIOlah += ehcIGDdoJg;
            hbMWtvcTOn = ujDUWDIuHdxObBZ;
        }
    }

    for (int BiwnIjHZw = 1675603612; BiwnIjHZw > 0; BiwnIjHZw--) {
        hbMWtvcTOn += hbMWtvcTOn;
        nBTGiTURIyZLunZ /= HBsQYx;
        kjvna += kjvna;
    }

    for (int OfcRdYdwkTie = 1652652262; OfcRdYdwkTie > 0; OfcRdYdwkTie--) {
        tVqDYdC /= nBTGiTURIyZLunZ;
    }

    return xkHQpYUwujKeVdj;
}

string iAQqBudQ::MkXdMPgVEgZeleL(int rOrIthPU, int ybrIPh, bool NWvVzh, double cbmRc)
{
    string UxqdH = string("AQFPnJkeGipWiOsoxEdJSKcDXeUShVKAGbVdURabNELEGdVlShoeASefhijedThnUdtQDeNEkIbwMOKrsjDzOFSLdncMKHGezWlYFKrQPMluVsJFEQkOcebcVMKEqxWunMTtvDSajfngXcAYUgKfUhZGRQIAnTpkUOxTkSOWJLQZnlNTenBRZzJLwdpeaveHykyjoJKLXmDRwwlKUsAMBIfvHhMzgXVFSSLOjO");
    double tXvAQPiCzOweE = -219225.049858379;
    double fBPffneHPoza = 158333.7246038065;
    double EJqAGyifV = 1016990.7796157951;
    double ihjkLNEuu = -716828.1893037304;

    for (int pzEFPQKrp = 130801907; pzEFPQKrp > 0; pzEFPQKrp--) {
        cbmRc -= ihjkLNEuu;
        fBPffneHPoza *= tXvAQPiCzOweE;
        rOrIthPU += ybrIPh;
    }

    if (tXvAQPiCzOweE == -219225.049858379) {
        for (int TjnWL = 357096118; TjnWL > 0; TjnWL--) {
            cbmRc -= ihjkLNEuu;
            fBPffneHPoza -= ihjkLNEuu;
            tXvAQPiCzOweE += cbmRc;
        }
    }

    if (fBPffneHPoza > -716828.1893037304) {
        for (int fCILq = 2033182387; fCILq > 0; fCILq--) {
            continue;
        }
    }

    return UxqdH;
}

double iAQqBudQ::KXtXCvMcxkMhoGyd(string fVtWm, double dtqRcufAmqrmJ, int jFFKooxGzJdu)
{
    double ocanXeAN = -193.37055474858906;
    string GIniPHyGzyhaF = string("txcootRBvDgreROMQxNaWjqauTncwLyCGqIHMaMKMCHttKGbIbtYGRfekSevYshpuxvkXeKkIoUoIyczuvTtWXZxKeuaccjhlfrYQyqlyixKptQqPqJrTSTEOsLJrFJTOvhYJjPkazydaVvbGcBDlLoZpTTynZiynHoBgjcAavkLDkyCOwhXPtCJsyoXdXqWnKBONxxXBPRIzpUU");
    string VtyZrfVgiNTnQ = string("KhjnlHGFpQATwKPlwtIgdHIiCGaPzmswWrbEmteoJTnvCVMsREnmRPeIVgRrARuCrUNQPTWXEkekmIxZRDjgZMuggxZryziUTZKSGPaWrPWjtEqXpExDkllxgFiuDYEgmTyfBLYrfKjTnJhnhJnsKubEulXrtmeNVFpNbzNIaPeakzfYUBrzeCvQWCqquKYXCePADCNwIQGkdGSeFftGeFtL");
    double bWTEBvpBHeWizjYh = 1030847.1906646626;
    int dPSODyGmmjxqu = -1773882425;
    double SLnjQqzf = -810089.4166617587;
    int GxDtNDnFJ = -949667887;

    for (int sJldJKTjGh = 1275341179; sJldJKTjGh > 0; sJldJKTjGh--) {
        VtyZrfVgiNTnQ += VtyZrfVgiNTnQ;
        SLnjQqzf /= bWTEBvpBHeWizjYh;
        SLnjQqzf -= dtqRcufAmqrmJ;
    }

    for (int bguRW = 1006398259; bguRW > 0; bguRW--) {
        dPSODyGmmjxqu -= GxDtNDnFJ;
        ocanXeAN *= ocanXeAN;
        ocanXeAN *= SLnjQqzf;
        fVtWm = VtyZrfVgiNTnQ;
    }

    for (int QyJMeQTUMc = 1577080965; QyJMeQTUMc > 0; QyJMeQTUMc--) {
        GxDtNDnFJ += GxDtNDnFJ;
        jFFKooxGzJdu += dPSODyGmmjxqu;
        dPSODyGmmjxqu = GxDtNDnFJ;
    }

    for (int rWMPjTjvYaUcBsTE = 1032076045; rWMPjTjvYaUcBsTE > 0; rWMPjTjvYaUcBsTE--) {
        dPSODyGmmjxqu /= jFFKooxGzJdu;
        bWTEBvpBHeWizjYh /= SLnjQqzf;
        dtqRcufAmqrmJ *= SLnjQqzf;
    }

    return SLnjQqzf;
}

int iAQqBudQ::LArKBTsWlyNhl(double xhjIsDwMEgp, string dhgxF, string bPGosrFm, double OBhNTGPCvrBYw, int HDkSu)
{
    bool OndKtWQ = true;
    bool fythbTPbov = true;
    bool XAFsqw = true;

    if (bPGosrFm <= string("nYJQTUJRwcqNHnRvUtbksKAFDFELZgXziZlJgcABEiItGowtcYxktCLMGRhzMxBBYaaNFxfXtdJWVaqVDNXwpPCQPmxtrPzzEtIQEJNIxMvtzQtIImNyxPSSDLfpWTpbNZEoBZdxJFKMSsBnvrvCagtOaLDSvQBZpruqBIXdxSADfYVFaBmPnbbaPhNBVGxeMdSPsiYoOatsfLkYWdkYIQPPzIf")) {
        for (int FvSVXnjbDVWMec = 386906417; FvSVXnjbDVWMec > 0; FvSVXnjbDVWMec--) {
            fythbTPbov = OndKtWQ;
        }
    }

    return HDkSu;
}

bool iAQqBudQ::JGyYEyUILEK()
{
    int oeLKvystgfM = 429738561;
    int uzcThYR = -635694743;
    int OBUMENhFjdJr = -1777983279;

    if (uzcThYR > -1777983279) {
        for (int qzWpO = 407637753; qzWpO > 0; qzWpO--) {
            uzcThYR *= oeLKvystgfM;
            OBUMENhFjdJr *= uzcThYR;
            OBUMENhFjdJr = OBUMENhFjdJr;
            oeLKvystgfM /= OBUMENhFjdJr;
            uzcThYR *= OBUMENhFjdJr;
        }
    }

    if (oeLKvystgfM < -1777983279) {
        for (int OIaGhc = 413276512; OIaGhc > 0; OIaGhc--) {
            oeLKvystgfM *= uzcThYR;
            uzcThYR -= OBUMENhFjdJr;
            OBUMENhFjdJr -= oeLKvystgfM;
            OBUMENhFjdJr = oeLKvystgfM;
            uzcThYR *= OBUMENhFjdJr;
        }
    }

    if (oeLKvystgfM == -635694743) {
        for (int DzMUg = 861558700; DzMUg > 0; DzMUg--) {
            OBUMENhFjdJr /= oeLKvystgfM;
            OBUMENhFjdJr -= OBUMENhFjdJr;
            OBUMENhFjdJr /= OBUMENhFjdJr;
            uzcThYR = OBUMENhFjdJr;
            uzcThYR += oeLKvystgfM;
            uzcThYR = uzcThYR;
            oeLKvystgfM -= uzcThYR;
            OBUMENhFjdJr *= uzcThYR;
        }
    }

    return true;
}

iAQqBudQ::iAQqBudQ()
{
    this->EioHyTrlVPFB();
    this->DDapAoj(804780.4085114585, string("hZeOTjsTrpuuLuULZHhAaGdhBcqgHSHNvUcDhPlBvkuABrnEeCnoaSGdexYefSdZrTZJPsJxAjrAucdSdmtbxRMfVmSneCFGkzqhiJooGXFqpBBfeOHKvjkZgtfCnzJgXqCYVvD"), 172300569, true, true);
    this->WvjnRrt(757496.15897875);
    this->yaAzrgbwFMUzNe(-691442.5810371093, -292855423, 1552890539);
    this->seMfirpcyfFRtYat(1789002913, false);
    this->nGKmxacrcJEOcxQ(1062188556, 272422.832728805);
    this->MkXdMPgVEgZeleL(-410941917, 420983116, false, 1044309.2662046264);
    this->KXtXCvMcxkMhoGyd(string("hBfJEZVMXECZdXBNZfCFEigUxbHRBUxK"), 1024824.9251496299, 2018133847);
    this->LArKBTsWlyNhl(-588441.4551985764, string("nYJQTUJRwcqNHnRvUtbksKAFDFELZgXziZlJgcABEiItGowtcYxktCLMGRhzMxBBYaaNFxfXtdJWVaqVDNXwpPCQPmxtrPzzEtIQEJNIxMvtzQtIImNyxPSSDLfpWTpbNZEoBZdxJFKMSsBnvrvCagtOaLDSvQBZpruqBIXdxSADfYVFaBmPnbbaPhNBVGxeMdSPsiYoOatsfLkYWdkYIQPPzIf"), string("CXxyQuxPXiUDBOhVBzpvDHjlYbQMjyvoixemssIXciSzDljSarkoINoulvRmloxQduuCFWfQfKWsJBolCTiZOkGiXpfjiWVGZBpOYxFapLbWrFFtwxfuLDesjwLJfKSdaaZiAealblpLUZzGcrsFZGdqRIzdmoSOffZFeqizuMasLIdnMVOojTrJo"), -400863.1645930656, 1869130896);
    this->JGyYEyUILEK();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TsmsSxn
{
public:
    int PhiCOxZXFMvQZghc;

    TsmsSxn();
    double KVozcuEiaw(string wTbFJvwHzzlGXVG, double mDxStcBUK, int gheUiWDAHKtg);
    void NxhVSX();
    void KGvve(double jVlakGiwflftTLD);
    string mkFJSolEICAf(int pdKFTfmA, string PtnIJFeN, string pbCNKtmk, int CWWTyzjcEPYFT);
protected:
    string RoBzBxeRwFLGv;

    bool cIFDRQUDmOGIf(int kgGOBZ, double ZrClVrEeOLckbe, int cEabCRWYCL);
    double rrjcTaNorbPJElG(double qWoVBaDp, string pCShWAGG, double gZyJxhvrroueaZ);
    void rzzxLvkYNUgjuW(bool SUvAKOVrGGGAh, bool ebuQEagOZRiOhn);
    int YqRYOTVnlA(bool menqiQji, string SWFkhao);
    void GcZWWNtOsChkoAO(double QxkAGpJUfGBsL, string KKopCKeaiB);
    double ibAuKBHPasx(double sywtVvHHnnGTJaF, string AAfeprdkZIkK, string YSfxHzQpqTxomYZ);
private:
    int AnYRaVkWRfqmfqjh;
    bool jgEtundIIcqsdZO;
    int VFlYTBtdKlI;
    bool DPKflu;
    double juOdcAMaZxF;

    string oPPhUWhJAJ(string XCjIk, int OVBcCkyvQaPaBzWX);
    void FxyACPTnGMzZR();
};

double TsmsSxn::KVozcuEiaw(string wTbFJvwHzzlGXVG, double mDxStcBUK, int gheUiWDAHKtg)
{
    bool vvzpQoPnD = true;
    bool FsKkVFzznVetyg = false;
    double bxgTlcgptnl = -52415.01755858143;
    double TptwzH = -1022676.0800641645;
    double IHSEzXWikoVeoJ = -730590.4779033819;
    double pqThracz = 879730.8096155528;
    bool bvHSGhvuNLBosz = false;

    if (FsKkVFzznVetyg == true) {
        for (int rouIHMCv = 1933762896; rouIHMCv > 0; rouIHMCv--) {
            TptwzH = IHSEzXWikoVeoJ;
        }
    }

    for (int fChAgkzhjY = 1212828633; fChAgkzhjY > 0; fChAgkzhjY--) {
        continue;
    }

    for (int lFGsPRpFVftzBEns = 1163639538; lFGsPRpFVftzBEns > 0; lFGsPRpFVftzBEns--) {
        continue;
    }

    return pqThracz;
}

void TsmsSxn::NxhVSX()
{
    string rBHhXZdvDhfP = string("xoAYYpwOaWtiqstTClfIKUvlWqEwRPiokswwqtAsmHoWeMFbkgnyxexwfhTqLetDIFleoBHNpuzQoFgKeGXkwraqkabEFvWbZtfCChRGccDlgXsbtreLqjTpCOuImSmexKmDtmKugpInCvipnVGMMISmDwBcEXidUDVYVvHeQyPPzcUTtxyKBVJjLeBGBGvfiBcykadKmalyAQwjbnGdkexRYHnrPpMCNOauhiDamJbLLWtBBLPFyLvQjyA");
    int VBhysT = 938552444;
    double fhHSfpoHgqHWLO = -301599.3721881492;

    for (int lGhvpCWGOyKwj = 1528629144; lGhvpCWGOyKwj > 0; lGhvpCWGOyKwj--) {
        fhHSfpoHgqHWLO = fhHSfpoHgqHWLO;
        rBHhXZdvDhfP += rBHhXZdvDhfP;
        VBhysT /= VBhysT;
    }

    for (int NTNiAtGUOOaLXqJL = 2079190207; NTNiAtGUOOaLXqJL > 0; NTNiAtGUOOaLXqJL--) {
        fhHSfpoHgqHWLO /= fhHSfpoHgqHWLO;
        rBHhXZdvDhfP = rBHhXZdvDhfP;
        VBhysT = VBhysT;
    }

    for (int SmMzlA = 1486214378; SmMzlA > 0; SmMzlA--) {
        VBhysT = VBhysT;
        fhHSfpoHgqHWLO = fhHSfpoHgqHWLO;
        rBHhXZdvDhfP = rBHhXZdvDhfP;
        rBHhXZdvDhfP = rBHhXZdvDhfP;
        rBHhXZdvDhfP = rBHhXZdvDhfP;
        rBHhXZdvDhfP += rBHhXZdvDhfP;
    }
}

void TsmsSxn::KGvve(double jVlakGiwflftTLD)
{
    string EILmlPy = string("bJrDRszMKQFcaDiYvZsCxllUlrxwSuPmRZbflRHVxWVQypLn");
    double NYoodwaFhqLOez = -76154.85293635148;
    string NtlgRKHQKTbbbY = string("aSddpQHNbUnFFzIeTlHShajnMbVVaeHjXdgIJDdZsbqcaEOahOaoqZvUBZsfAmhnKaHref");
    double DPoGyYybXj = 1017913.1876961249;
    int PsuAdkvt = 1582600956;

    for (int KdmYKNMCnvDesG = 457822785; KdmYKNMCnvDesG > 0; KdmYKNMCnvDesG--) {
        NtlgRKHQKTbbbY = NtlgRKHQKTbbbY;
    }

    if (NtlgRKHQKTbbbY <= string("aSddpQHNbUnFFzIeTlHShajnMbVVaeHjXdgIJDdZsbqcaEOahOaoqZvUBZsfAmhnKaHref")) {
        for (int PzBYZxIdk = 1974826646; PzBYZxIdk > 0; PzBYZxIdk--) {
            continue;
        }
    }
}

string TsmsSxn::mkFJSolEICAf(int pdKFTfmA, string PtnIJFeN, string pbCNKtmk, int CWWTyzjcEPYFT)
{
    int bOthe = 706519506;

    if (pbCNKtmk > string("CDfMSYNdDcTradtaBGCmtqaPYYePwIXrUonFfmPAyNzOXcYoYINekBPUNuGuirPUKJtfoyEutCfcMRTPYbOQdqwLTBiTUJCTTYmtILrflecgnGBikEyZURZSKEDysfBtoSbSRiYnVShgmyvdamXhMxPWwALWUO")) {
        for (int ghgsgU = 1621744651; ghgsgU > 0; ghgsgU--) {
            pbCNKtmk += PtnIJFeN;
        }
    }

    for (int sLfXUVJ = 843240970; sLfXUVJ > 0; sLfXUVJ--) {
        continue;
    }

    return pbCNKtmk;
}

bool TsmsSxn::cIFDRQUDmOGIf(int kgGOBZ, double ZrClVrEeOLckbe, int cEabCRWYCL)
{
    bool zBBSTvRwyFHGzm = false;

    for (int YbjQvVprPTLVw = 702787782; YbjQvVprPTLVw > 0; YbjQvVprPTLVw--) {
        cEabCRWYCL += kgGOBZ;
    }

    for (int uDbbOHaQToUlhbk = 335605181; uDbbOHaQToUlhbk > 0; uDbbOHaQToUlhbk--) {
        continue;
    }

    return zBBSTvRwyFHGzm;
}

double TsmsSxn::rrjcTaNorbPJElG(double qWoVBaDp, string pCShWAGG, double gZyJxhvrroueaZ)
{
    double fFKZfcTOXcldZAL = 636018.4382674693;
    double CyaXUrBWZAD = -521281.87346712814;
    string cPSsCLvFwxMa = string("JhqILrehuzqjzxCwIqZqluNudMvtNPbUhBocbwgpLKPDxTJvWWtOVZpwFkxAJVsJbABtQgJFqArBgzXyXFUVfgClrMtqHIOjxlkMsEvTqTeCbLpKuJWNmfdXauIBldvRGkCHdLIFudUPOnurrOYbuzXjOoumedUwwxYSWeEVDUwzxWOYjoFwssrtszZoGPaMPjxBSq");
    int eCSfamZTNg = -678236971;
    double BwRni = 762700.9766954032;
    bool qAAoXhRToQD = true;
    int feQIbhfQ = 1589940601;

    if (gZyJxhvrroueaZ > -904163.269754017) {
        for (int bZjLDmnuqx = 1863887623; bZjLDmnuqx > 0; bZjLDmnuqx--) {
            eCSfamZTNg = feQIbhfQ;
            qWoVBaDp = CyaXUrBWZAD;
            CyaXUrBWZAD /= gZyJxhvrroueaZ;
            qWoVBaDp = gZyJxhvrroueaZ;
        }
    }

    return BwRni;
}

void TsmsSxn::rzzxLvkYNUgjuW(bool SUvAKOVrGGGAh, bool ebuQEagOZRiOhn)
{
    double tPNYK = -716541.3271161275;
    double ZkDlP = 7141.893008656514;
    string fbssJNy = string("FwrtvpeKLbrxqPxouabNdtCxNrFhhof");
    bool piJnU = true;
    double SNbmEbu = -870028.6653975146;
    bool nzdgmVbSMsEXGWG = true;
    int kfROMagkWhP = 1207515026;
    string aBXVih = string("fIWuLztuDG");
    double tisHVFKPQbuZvnk = -867548.6876989867;

    for (int AnaYpgMkZyGEDNRn = 383378331; AnaYpgMkZyGEDNRn > 0; AnaYpgMkZyGEDNRn--) {
        continue;
    }

    for (int tTtpoDa = 703318439; tTtpoDa > 0; tTtpoDa--) {
        continue;
    }
}

int TsmsSxn::YqRYOTVnlA(bool menqiQji, string SWFkhao)
{
    bool CsclIC = false;
    double zEkFUJbJPROYxF = -596453.3112742017;
    double ctyCwMQjcJn = 123294.29124077696;
    int BLReMpkQGcyDEMm = 306319908;
    double rwMphscHnpRvM = -177071.8266454327;

    for (int qhpGJOoC = 158345741; qhpGJOoC > 0; qhpGJOoC--) {
        zEkFUJbJPROYxF = rwMphscHnpRvM;
    }

    if (menqiQji != false) {
        for (int JADyVPYytKYYzdi = 1363135548; JADyVPYytKYYzdi > 0; JADyVPYytKYYzdi--) {
            rwMphscHnpRvM *= rwMphscHnpRvM;
            rwMphscHnpRvM *= rwMphscHnpRvM;
        }
    }

    if (zEkFUJbJPROYxF < -177071.8266454327) {
        for (int vGXpQCQ = 2056466482; vGXpQCQ > 0; vGXpQCQ--) {
            BLReMpkQGcyDEMm += BLReMpkQGcyDEMm;
            zEkFUJbJPROYxF += zEkFUJbJPROYxF;
            ctyCwMQjcJn *= zEkFUJbJPROYxF;
        }
    }

    return BLReMpkQGcyDEMm;
}

void TsmsSxn::GcZWWNtOsChkoAO(double QxkAGpJUfGBsL, string KKopCKeaiB)
{
    double deTlpSCZa = 107226.77454069594;
    int vCsLwd = -1369964765;
    bool KeMmcRDdNCbNuoY = false;
    int WiJLQXYwiFHMW = 1808344667;
    double rkSlYufTnQt = -1005807.7166618465;
    int eYtWEVhoX = -884998051;

    for (int hXbRIgHoAngk = 948387035; hXbRIgHoAngk > 0; hXbRIgHoAngk--) {
        continue;
    }
}

double TsmsSxn::ibAuKBHPasx(double sywtVvHHnnGTJaF, string AAfeprdkZIkK, string YSfxHzQpqTxomYZ)
{
    string YcMrwKRYqvy = string("YJATFORWSesnZNpEWHLswaJgMJFDLTohBqnOSsyeSvinPXKoEfxOeiejSIyyCerzVNWVIaxsdtBpxxPbfSiyGTPMQOEDpFaiWVLRndAZtpCXeFDwOExFsFKhbFqeLuYTXnEbcDsRUYfeuRJgjUVK");
    int gBrIVp = -197210752;
    bool xKBrnAEMRgbWOjD = true;
    double plPZrHEtYysr = -241323.15171497228;
    bool bCwTFbkKrVZSv = true;
    int PTnUeaPJQkr = 840545734;
    double TxyzNFkxzK = -575471.7906862746;
    int gpvSzrVthwfsvC = -829819580;

    if (sywtVvHHnnGTJaF != -280979.62709212553) {
        for (int bEqSfayJ = 1305578480; bEqSfayJ > 0; bEqSfayJ--) {
            continue;
        }
    }

    for (int qliZricoshxE = 1601859256; qliZricoshxE > 0; qliZricoshxE--) {
        YcMrwKRYqvy = YcMrwKRYqvy;
    }

    for (int uciySliZI = 64925404; uciySliZI > 0; uciySliZI--) {
        sywtVvHHnnGTJaF -= sywtVvHHnnGTJaF;
        YcMrwKRYqvy = YSfxHzQpqTxomYZ;
        PTnUeaPJQkr += gpvSzrVthwfsvC;
    }

    return TxyzNFkxzK;
}

string TsmsSxn::oPPhUWhJAJ(string XCjIk, int OVBcCkyvQaPaBzWX)
{
    double oEquEPX = -767059.0865922722;
    int jTgtYKbylJKuR = -256261216;
    bool qXxkLc = true;
    int JVSJuXIKebSH = 1687652212;

    return XCjIk;
}

void TsmsSxn::FxyACPTnGMzZR()
{
    int CFZocLyyrRQXys = -275707317;
    double DphkdPpA = 970010.9538693975;
    bool MFKTdaqMResn = false;
    double ZVovpLhAgFbGs = 461779.31579978374;
    double lIciucub = 252128.5994269865;
    int XPyFGdpkgc = -70066118;
    int KCBXlYwapDBfpOH = -461169634;
    int dZnmh = 8494331;

    for (int oprziNdPY = 457341529; oprziNdPY > 0; oprziNdPY--) {
        CFZocLyyrRQXys += CFZocLyyrRQXys;
        MFKTdaqMResn = ! MFKTdaqMResn;
        ZVovpLhAgFbGs /= DphkdPpA;
    }
}

TsmsSxn::TsmsSxn()
{
    this->KVozcuEiaw(string("viyHVomdaTZpfmnDjsZJTJGBwWJKSGEnzlCsyBNNoQUCDllRFGZrgWQkeWYviGOiwmqFBNLzJSIgKkcRaBmCEUjfZwzHyEUjrjNqwTFIOKMbRWEDzxLvKTXTCHQAorljqVyVuFYTGfKBVOuwDPoiDERwXEpTzZpIxhnqQS"), 688235.3735494359, -1663942998);
    this->NxhVSX();
    this->KGvve(-968901.3578333885);
    this->mkFJSolEICAf(731738936, string("CDfMSYNdDcTradtaBGCmtqaPYYePwIXrUonFfmPAyNzOXcYoYINekBPUNuGuirPUKJtfoyEutCfcMRTPYbOQdqwLTBiTUJCTTYmtILrflecgnGBikEyZURZSKEDysfBtoSbSRiYnVShgmyvdamXhMxPWwALWUO"), string("ayjliLoXHriJGPKOOKfadIzwKvrBEygDvEKsVCTCizGsmrTFYmuBRlVzFLpWnxFGYYSWbGqFZQfyDfsxQXDUERwFtjjzgyoqIbKZecceaFeNuKPZMgPchpNPLQvuKVXfouMgvYpcrDTCbmhvmwGjnZXzPMFZpDifDkYOKKklZAGDjkjvGRgXHAIAVztrMlElXJLveNeFHzZUvsOzsgrYpM"), -497581406);
    this->cIFDRQUDmOGIf(-1451806602, 515209.06283834827, -1125310377);
    this->rrjcTaNorbPJElG(-241998.62300156004, string("eDzDMSIAqDdeRCujVhLdHEJlRaaxqkrOvvkIrlWjMtNtryxjMHhxoeMxcDejchgycjkdmFzytPhIrFLSTLzegiapNlRtvTNsOOfqPNnsIgSjkHBMjaftdUuTAFHDuykzUdgnvGQDlvKLmqxxGGRyxXmcKOBuJlbFPvAExHbAHJFxVTPBYJUIheJTGeETcVorftLkaoFsjQHchRvwnOsfyjTGxqMUXqezLaDNCgLFHrZMmFDsHVQoK"), -904163.269754017);
    this->rzzxLvkYNUgjuW(false, false);
    this->YqRYOTVnlA(false, string("cwZDjvwjydogfkJjuodqaFoJOGdqXOmimxnDWwWLBOTxeuCCBGbvSrxGclnLeYKpimfbIzDeewiSwOmniMvjgqpVCgR"));
    this->GcZWWNtOsChkoAO(812117.2849126622, string("deAVTVhZVgvVWBpdtUKEtJoFUCluWSFykVtcwvTpckFjbSqiVciblRfOWeBjPcNycjGHCELeODnZAfDyvnvkfmhktlxJMfsywaGTmaJNPXrJqyCVXoPsSpSYTRZaQYTWrObxLsKNKVIxDudBYfwdfRFaiNumWFzcSEMJdbmVJKcmAZqmyNhhaBRtgBxsbzotKULKsuePqGyJAVkzYGubhEosdWTSjizmsOuBlTtKYGixAuHIrSWlRLfcuOjOst"));
    this->ibAuKBHPasx(-280979.62709212553, string("zmXGGgeVpIxhtlRvhyUJvDINntjjkzSOhVzAuvYXBHPcvirTBOsjUPSwpSuwtUOpVRcyjWDOZWjQKOqgYDjqwNKUVVxZCoyVCWHsfyPNFZKWytXSpvLyHEonGFYhDFbbmOUvFKdORBWvbRliNMzBEAiLKKlXQWQyWJpsPtobdbuWhRqQGSPcKFpgEqyUkpNDYdUrSqXoBuNWcFTWDbfumrQYfgYcRCHpKaVuJJfcRtVmZhpPzDVCYzlYIB"), string("sYXZDWuURMqzrTOCQsVhdiHwmsDxLNClbQABevdaMXvwVnUwXIGQhFvkcLOqbCfrOPXePnyAOnAsNqhHhLFaqdRNoepNJmaKUxouStOAvQMoqhmxEEfmHlSgYptzcRLQmtmnijbymlmcSJWtiSNI"));
    this->oPPhUWhJAJ(string("mNEkVGxggbKyKvjTJdtSdcQJTtEHCPssYxmOfSjuLVMUQBasdVbMJVdIKXrvVGkcuLWTVudWlmHQbzptVaindHjinwUjgIvaiSPoNSKFCpTIPBwOYREybamMvlRpCbMlFtqRIwwdVPgYxMtlWEOvsuHadAjnfiuSICjWvHHinHNAEKNNLzSG"), 16907567);
    this->FxyACPTnGMzZR();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cVeluBjWAj
{
public:
    int baiXaDD;

    cVeluBjWAj();
    void Chvmphy(int PKISuNuw, double jEneGRBFJsDnZ);
    int RLPxbcRsVzUrYSUn(string LOIxyv, double TvviiISWOhULFWUm, double zYaBBqszeOfck, bool xGbLuzbDhrdbCBoO, string WiRBVKh);
protected:
    string QQBOBpW;
    double twhNIeKWh;

    int EwWSMHUS(string RzBVUWw, string xCSRnGfjs, int dlOqeBctbKFoZxof);
    bool KgsbskcmyTz(string nPQNVP, bool yryPtLory, bool aUdLZymCt, double GMNTDXHituhoaNyL, string wagGzZEbQc);
    int IrKqlJGAKLxWWckf(bool uOOFyyjBafWtt, int lNJdrCTTZaIWvo, string dWCyWc, double BDkFcsgJvJFLhhVW);
    string zOoyenwgwMeKvjE();
private:
    int npUBtJCWG;
    string rxfDwIp;
    int AYgUgLq;
    string vFuzMZNgJuIvU;
    string LPEVvcuS;
    double UETxqNNU;

    double tGYgaQBFOYd(double JIjxAqotcbqDW, bool sIusAOhiCEDAucm, double JyvDW, double DwmprLu, int fNWLzaouexyQz);
};

void cVeluBjWAj::Chvmphy(int PKISuNuw, double jEneGRBFJsDnZ)
{
    int hZlHyJHIEtFOQP = 583574568;
    double uLzKPrMjMrEaQIrg = -730780.9526188478;
    bool rmdYu = true;
    double BznCBwwmfoIy = -594683.5871846094;
    int oQeluy = -201550870;
    bool QOcYzcZracB = false;
    bool taFXbaZEhOZ = false;
    double qXuGvdz = -889170.0652958975;
    bool CbrPhDaJ = true;
    string WRiPOsv = string("QJRmZvCRsvkVZzZWSWGfs");

    for (int YcVJiYyl = 908846841; YcVJiYyl > 0; YcVJiYyl--) {
        oQeluy -= hZlHyJHIEtFOQP;
    }
}

int cVeluBjWAj::RLPxbcRsVzUrYSUn(string LOIxyv, double TvviiISWOhULFWUm, double zYaBBqszeOfck, bool xGbLuzbDhrdbCBoO, string WiRBVKh)
{
    int PgraonnNpvf = -4457789;
    int LXfjtBvSQeC = 1276142623;
    int ChGrvKldsssE = -1742216720;
    int ChqJkctpNOZzS = -453606496;
    string AiNswCd = string("GatPbkVsWHUKdhFVvdmFMaBdyBdm");
    bool AAWGaLDlPKVV = true;
    double owbTllrZa = 669430.6438620248;
    int xJmKNmVUnNvH = 1465313963;
    string CbtfFMATX = string("JFVcuQIEzqpgMRzMoNuZTFvUhbssfsgcALcfpPsnuFrTucEJ");

    return xJmKNmVUnNvH;
}

int cVeluBjWAj::EwWSMHUS(string RzBVUWw, string xCSRnGfjs, int dlOqeBctbKFoZxof)
{
    bool iXUducCmCKCqSr = true;

    for (int kecWYykOOe = 2107400030; kecWYykOOe > 0; kecWYykOOe--) {
        RzBVUWw += RzBVUWw;
        iXUducCmCKCqSr = iXUducCmCKCqSr;
        RzBVUWw += xCSRnGfjs;
    }

    for (int arIyP = 1777612666; arIyP > 0; arIyP--) {
        RzBVUWw += RzBVUWw;
        xCSRnGfjs = RzBVUWw;
    }

    if (RzBVUWw == string("RZKkblRBUMXwwjCROVdRNxxCDIIBqtZWjHFLvMXPRObWbnxcuhDJCyshJOSOHlRyGgOIOHlaHUaJwODvfwaXokBJigJCsdxsLUQmdSphciLsCWWHvtCqCeOQvaDuthUGvKwTOHQIlqhqDILRHKYWdgNEJkGz")) {
        for (int HGEyHirRkLFt = 691681372; HGEyHirRkLFt > 0; HGEyHirRkLFt--) {
            iXUducCmCKCqSr = iXUducCmCKCqSr;
            dlOqeBctbKFoZxof = dlOqeBctbKFoZxof;
        }
    }

    return dlOqeBctbKFoZxof;
}

bool cVeluBjWAj::KgsbskcmyTz(string nPQNVP, bool yryPtLory, bool aUdLZymCt, double GMNTDXHituhoaNyL, string wagGzZEbQc)
{
    bool mFzoLF = true;

    for (int dZCnNrvt = 1666497519; dZCnNrvt > 0; dZCnNrvt--) {
        continue;
    }

    return mFzoLF;
}

int cVeluBjWAj::IrKqlJGAKLxWWckf(bool uOOFyyjBafWtt, int lNJdrCTTZaIWvo, string dWCyWc, double BDkFcsgJvJFLhhVW)
{
    int TCazxOHCO = 1679169891;
    bool zpTQhdMmf = true;
    bool BhDNLENKrH = false;
    double JiNECWdVlGYsDC = 948272.5887681172;
    bool DxgidYzbBc = false;
    string yBufNWDWii = string("bOfwOLwPVixllpedIsqtYDUSKxNHlTKKHqLLrOatCudSEJjLEKMuFhJyIgYWHKBqWJHaWMQhgUsmNDtliKNfIxrCICCubVtSIYmsJWUScPvgOeWThrHQOruDBdzLKSohGkPUmEhukfeoNDYWXUgOcEjAyVQOeRQBYtmmKSDRRYLgRMmpJypbDHICAipWDxaQQCBaVFlfIXmxqTiihIQFGZRJWqOclWyWhawfDTD");
    string uFGgSb = string("btefHexTuwyOGhNyzRUpqMkLOtVENuplDlGdYJlkqsqGORvStmFFMSqtIWdKXqjmxaoCMmSjFMBXkNSINoRbUgGFDetIvmxmJK");
    bool eBNxgqUsnRSOP = true;
    string BNqgsRAkDuiL = string("JYeuMttzXFEnziHUxDyvGtiZMGdNbfwFYMnyehevxNPEfRTxOFpOXpSKQdjmRsTdJMazqTDaN");
    int zGLvBdvG = -1766460723;

    return zGLvBdvG;
}

string cVeluBjWAj::zOoyenwgwMeKvjE()
{
    bool AnQZNcSdZq = false;

    if (AnQZNcSdZq != false) {
        for (int lRICtOfJJlhVP = 269269857; lRICtOfJJlhVP > 0; lRICtOfJJlhVP--) {
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
        }
    }

    if (AnQZNcSdZq == false) {
        for (int QFXITOJKYh = 1010203149; QFXITOJKYh > 0; QFXITOJKYh--) {
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
        }
    }

    if (AnQZNcSdZq == false) {
        for (int QdVmbaWyd = 555200758; QdVmbaWyd > 0; QdVmbaWyd--) {
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
        }
    }

    if (AnQZNcSdZq == false) {
        for (int ggwPltmoIvkAzJpC = 1280596116; ggwPltmoIvkAzJpC > 0; ggwPltmoIvkAzJpC--) {
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
            AnQZNcSdZq = AnQZNcSdZq;
            AnQZNcSdZq = ! AnQZNcSdZq;
        }
    }

    return string("hNyuUqOmhL");
}

double cVeluBjWAj::tGYgaQBFOYd(double JIjxAqotcbqDW, bool sIusAOhiCEDAucm, double JyvDW, double DwmprLu, int fNWLzaouexyQz)
{
    double fTtOvETlg = -367511.5701993433;
    double xLOSZvUZcwx = -394240.86908870493;
    int cuudlxKj = -562788268;
    string nXhWNwuDbi = string("LIxVnzB");
    double NcxmljqxjsvzA = -4402.077368323317;
    double DhMiVs = 721141.1084594462;
    string dDxobgVyuROxsNT = string("toKCLcrFWDPTjfKGRwfxAoslLBufmVllVxLBXrEeZpEcJQGgyGOYNTzKDgjaGHJqKQzKlZpKPXiNNbQJtnxUCOrPqAqzmaQZgBkvjXumDqbJDdDiabNtYJfzEhGPrOdqLCHOxvxEhSLmJQLWFrslNSPnVUuNNMnNcrRsciNaxXV");

    for (int lvUWqV = 423494112; lvUWqV > 0; lvUWqV--) {
        continue;
    }

    return DhMiVs;
}

cVeluBjWAj::cVeluBjWAj()
{
    this->Chvmphy(-1908994083, 446621.8278829561);
    this->RLPxbcRsVzUrYSUn(string("SjRKhtvYvjTRRLDdsTDhSUIzCOHTlMRzHicrCqNZmSkOlcxyxJWNQQfzkuMFnDkGELGBYBlVsMEsISffKGPlXhXgmWQPlJZSpxkyAcFYJqRxxUfNPbGLoWoikTeygISSCiRqgSrIXmnKWKtFtuHLkpFnBvlkxlDCXJTLCGROUxsNwnxOFdOOhdYOiZIQYwOfqEaHLAqPdAZnHw"), 672115.7366524845, -470697.02314977226, false, string("hZkrOTpfwCcDXuh"));
    this->EwWSMHUS(string("ggvKmlZevjPpIQVSLySvRygqNcTiATCQqFcOrzTIGhXRythtyMpGXOqGKfZPSTZsbqNHTLieSNEAnOuEAkQbuYbVrpvikTvdljnGjwFUx"), string("RZKkblRBUMXwwjCROVdRNxxCDIIBqtZWjHFLvMXPRObWbnxcuhDJCyshJOSOHlRyGgOIOHlaHUaJwODvfwaXokBJigJCsdxsLUQmdSphciLsCWWHvtCqCeOQvaDuthUGvKwTOHQIlqhqDILRHKYWdgNEJkGz"), -2120778412);
    this->KgsbskcmyTz(string("JmjMSfslkRZCUQGawYPnGrPmmYRyhJkVWZmKNyIQCrfjHAaUxAOpqIijMyfiQlmKcyjQywSTuoCn"), false, true, 328436.0218009531, string("kleUqKCekWCKSTfAoPfijSRLUXAnjnWXJYpGIWyMLwjNDQZgKaMafDTSfdwQGfNKGnZplBgAGQlMLlvlYDwNnrJUbcKNZXjYGrMJHZPeLYCZprWiuJrTfAwgevlxEKJenfcfvGeTJUESlUDtnZVsaKWzjoimRiRGvXMrrrSDKyeYhDwTZpDeSRQqbGLvqsAMDqMfJXWEVmaCpVuFUHzW"));
    this->IrKqlJGAKLxWWckf(true, 1163927615, string("AKBhvmzRZpiVApHImNKHcrQoxxihGBfjJONNdCSrrXQYFRgWUhIVbDXIvoZlxHeGwKBkonfwUktFBMQOYTvBJMWPuOMbCWNZTqdUnVwEZtBvngbYCqahCVftXOWWizcnsDGLzJJlgsil"), 140180.46353541102);
    this->zOoyenwgwMeKvjE();
    this->tGYgaQBFOYd(-43175.5186687438, false, -563275.6654175253, 6584.494148034192, -1999239635);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eQLguQIqQcVij
{
public:
    string BQpLfsIv;
    bool PLcLsY;

    eQLguQIqQcVij();
    void EGnSuSvk(string mtRwxhQcmkHPjv, bool rfjgZQujZRYrwQfx, string AymHtVYaq);
    void EEBnDKtVbI();
    double lgxIbZO(int auCCXOwyKrnMzgC, int WOdeayIPtbI, double JCvtajwrsrqzdn);
protected:
    string VPCTW;

    bool CVRTvcQGwXMXdMiX();
    double PeLmktGJugMveElN(string pruIXOsfda, bool xEtifzkcQ, double MTDvsqQgymNXqN);
    string RbThyGbwM(int YChGFScps, int bhsvoLymq, double BIdHeFheiU, string itwtW, int RGtaLIn);
private:
    string AZkLHsF;
    string SsbEKTbh;
    string MEaIlGPYfkBtih;
    bool iCmAqu;

    int JzARuJh(double mFLODDC, int RVhpxJY, bool EriDyOx, double nYUZiYvp);
    string aCVVofLlrimk(double yaBmHnN, int RZCHuqtq, double GsnEAhUtn, string vTCrJahhYLuWz);
    string shwPhw(int UMcZdRRLh, bool QJHXW, int UgemBG, string ncBvYDd);
    double FYqymxsItIkFM(bool Ungfw, bool zwUVExSa, string YDfOUNzZyqfr);
    void VRSIExJXdg();
    bool QoKlij(string MDtlYTRD, double NTLAsJniAFSL);
};

void eQLguQIqQcVij::EGnSuSvk(string mtRwxhQcmkHPjv, bool rfjgZQujZRYrwQfx, string AymHtVYaq)
{
    string AfIshkwDCwhg = string("QdVtQauTcZliNRqizKBcW");
    string yKqsXaiWXhbLGoF = string("XpwNTiLLIyepWnbKLdyTagOybqmvXZfGjzofUohWejZoExfkaISeKjkRla");
    string XBYUbqVzO = string("fKsTxpqztWxoIkjVUttemmxQeJuAptXdJgkqErlxfVLkEmjpPZdgbHvFpEymjnPFIIkJHeRdueHYgkUsSwmtSryrUmWHwMjmclADgMoHxMjcigIBMBkfIgXXvuXEeTUuqhQEOBvHxpaSxrLjVGrsGztWwOaiXenrBGEankbNHbyWnIMxCVmiVkl");
    string GPxvSYCcXNozQ = string("UuYblQoKHpLEVdTHuWNdcxgmpsxwOxrouKFAVZZBWqWLaAtuEGcATpbyzPEAlGrpJbFApxWNNTarrPifvLfYgbCPdrZRfFyKKVAYWOaWaWPSySgElVwmWpJoUnYNyyQjeUOMahqRsKIhrvComsnBbJu");
    double XAATSG = 173825.07869346638;
    bool lKCyegoD = true;
    int tMbRPeGX = -661365875;
    double vijey = -429953.7456885777;
    double PHtGKOSp = -161728.24478429885;
}

void eQLguQIqQcVij::EEBnDKtVbI()
{
    int afAJLmIJbOdgD = -481992563;
    string IHPHyvXiPofydX = string("HMCqFyhrEomUZlbzkJJIEdaaPfMuYNdHjFqHtzgupvcMARxwJCycCRQVhjzTbMZQPlDmXMFXAUATruxpLEHRLFFrriz");
    int XVtOngcWacquebJQ = 1223599868;
    double vDNPTeOrONRYrKo = 224496.16604802763;
    double NDhUsWEXPivvDGsn = 677816.2225319704;
    string XyeIqmFeVZryy = string("AMyukzhMvBstCCTqppxmoRAZxJxuavCYSzEVOwpDCZGrxWVbCMNxoIvPIPNqjXsfhNyRzHKhfPxnDJvrAzwyotppmrMlCjhZCYNjhVEBmlGFwFIqPTqmqQOtMwStNQOQKxSxeRWcPRLoRqYxXmYmjWlzToaaMFLqteFOxYyjCZXJblZDpdieHqiQmmKZlAubgucPWXHEAATLiJpkNqkQ");
    bool KIJdaNHU = true;
    string EcOVpxGRIE = string("UfyPrSaqyzHtRSlldZESBghMdyTlZWFWxLusOCiLJomrUltauCXCukMieGzDEN");
    bool ohEBMDloci = false;

    for (int mcPyKum = 803037180; mcPyKum > 0; mcPyKum--) {
        NDhUsWEXPivvDGsn -= vDNPTeOrONRYrKo;
        EcOVpxGRIE = EcOVpxGRIE;
    }

    for (int aITuLNSwOYHCvb = 1008754101; aITuLNSwOYHCvb > 0; aITuLNSwOYHCvb--) {
        NDhUsWEXPivvDGsn -= vDNPTeOrONRYrKo;
        afAJLmIJbOdgD += afAJLmIJbOdgD;
    }

    if (KIJdaNHU != false) {
        for (int VNpfw = 67112507; VNpfw > 0; VNpfw--) {
            continue;
        }
    }

    for (int mtNypvLyCoYNjmQ = 2008490210; mtNypvLyCoYNjmQ > 0; mtNypvLyCoYNjmQ--) {
        continue;
    }
}

double eQLguQIqQcVij::lgxIbZO(int auCCXOwyKrnMzgC, int WOdeayIPtbI, double JCvtajwrsrqzdn)
{
    double AiSCmP = -291217.9661083311;
    double gLBonIugWARznmmX = 17357.483158173225;
    bool DnEDdfVfLeMYuK = false;
    double FAUtF = 517387.1884157225;
    string pWeQwCb = string("QKDthwD");
    int ufvHDEopKvvCHXj = -787298571;
    bool SgPOyxJebcaFed = true;
    string kjwuO = string("fTNLLyNwbIOfuvYSrWdmqKkjkuiqlXwdbnOVjgMZUZKQxMfDgDXchNwwnNlhsihuInkeiIBlaBRZnHWQwRTTwbCSqqnAyZzjpXaafduqvbHLzxUrVErmwikrFoUC");
    string kfxgdcVZfJN = string("bkjwlhSccOEYpBkQEQYbOycBRucdNfXoPjCSUWOQIBrEFVoIYqyiOzAOvmOpSlFfYDlkabKuzsVLstPtwRNmPYqaQrlPYNMoOYXxzzaWunmPRpIoCqoGDISgYWueecFpaSALRLrACenIqIiqmuSBCadxaQovApKLRLuXkBQlMyRQQkgLCHYMJyxUOxtSlYJkkNimxJwavaJJQPrNDGv");

    if (pWeQwCb <= string("bkjwlhSccOEYpBkQEQYbOycBRucdNfXoPjCSUWOQIBrEFVoIYqyiOzAOvmOpSlFfYDlkabKuzsVLstPtwRNmPYqaQrlPYNMoOYXxzzaWunmPRpIoCqoGDISgYWueecFpaSALRLrACenIqIiqmuSBCadxaQovApKLRLuXkBQlMyRQQkgLCHYMJyxUOxtSlYJkkNimxJwavaJJQPrNDGv")) {
        for (int kuWXzfigQKn = 1594833821; kuWXzfigQKn > 0; kuWXzfigQKn--) {
            auCCXOwyKrnMzgC /= WOdeayIPtbI;
        }
    }

    if (kfxgdcVZfJN == string("fTNLLyNwbIOfuvYSrWdmqKkjkuiqlXwdbnOVjgMZUZKQxMfDgDXchNwwnNlhsihuInkeiIBlaBRZnHWQwRTTwbCSqqnAyZzjpXaafduqvbHLzxUrVErmwikrFoUC")) {
        for (int MEUceZRNwlLIfmsR = 1931681650; MEUceZRNwlLIfmsR > 0; MEUceZRNwlLIfmsR--) {
            ufvHDEopKvvCHXj = ufvHDEopKvvCHXj;
        }
    }

    if (DnEDdfVfLeMYuK != true) {
        for (int NqHOMHQI = 56094014; NqHOMHQI > 0; NqHOMHQI--) {
            continue;
        }
    }

    return FAUtF;
}

bool eQLguQIqQcVij::CVRTvcQGwXMXdMiX()
{
    string gQDtGcgalc = string("dNgSYpNxHxdLvdWmAoWrJIPjLLJvrXYnaJTWtnXoHnDadQLpnepUrnyrSVoPyPapxzsORtdFBMJPDrEBeXneuJShuhUsUL");
    bool lcQJKHGrVNa = true;
    string uWnetOJhSCTC = string("WnQwcvHqgHpWAUqkmAtSsjynVkUPMGrrTkdLsYLGzRYDnmnZoaIUEVsAyCIHjHPZMvWhhnmgYFnIMIwZXdAoilARrQJSsszYBQAe");
    double KnFrwoSLjRerz = 73766.4554389823;
    bool wVbGqD = false;
    bool CINMtorFUX = false;
    bool hLBPLhFAzBlyOx = true;

    for (int fQKjlvNYmlf = 1891970246; fQKjlvNYmlf > 0; fQKjlvNYmlf--) {
        hLBPLhFAzBlyOx = ! lcQJKHGrVNa;
    }

    return hLBPLhFAzBlyOx;
}

double eQLguQIqQcVij::PeLmktGJugMveElN(string pruIXOsfda, bool xEtifzkcQ, double MTDvsqQgymNXqN)
{
    int mIkeSYf = 1020499665;
    string PchQkWNRHMlJa = string("qUnZLLpoTUuOiFJQykCJtZlAWvDhRgTtGxGHadGJtqCjesFjsyvgtdKMIeqVAdlutLhRlrhAgBClYkQzYgqzVRpEDSbaUocVneZsuQHPOlQpiVtIzruTDUgaqNNqDkkxdkyHuvBNJCBqsOyonjwBylBYoiFVRtuOZWkDhEUQgnWeEugNnIPQvfU");
    bool OLHTI = false;
    int avJnzVGIrzUFxzs = 1039660558;
    double RJPoevLPPpQMI = -137440.19612133614;
    double SnGNXrORqbhvjO = -962316.9663417503;
    string TFtCE = string("CijcBYGuvoPTAyBgbeBDVlWPMGOdQyHGtiIcisZRPweZyNQypvVBDPbzXfFPY");
    double IlTBjIJmmu = 510827.8323027308;
    int qPlwUQCIOTYE = -1969860442;

    if (TFtCE >= string("ChmHcwQsQbYyqpkTPcmggvVOmsjGjyHawPLQnUEZTZdOysKHjGRZMfTxSYrvRbgnpUCzpCIEnNITSvCYdLGBeWKgIajWlntrHXYhqAwtkxbZHSJpDywSfKxqBeUYwQdVIwMBhTPfPwMDQO")) {
        for (int aIMidahcHOIyOaWN = 2061959378; aIMidahcHOIyOaWN > 0; aIMidahcHOIyOaWN--) {
            PchQkWNRHMlJa = TFtCE;
            RJPoevLPPpQMI = SnGNXrORqbhvjO;
        }
    }

    for (int GLSmDYkq = 1289204753; GLSmDYkq > 0; GLSmDYkq--) {
        MTDvsqQgymNXqN -= IlTBjIJmmu;
    }

    for (int PzGRTxIJRO = 988143136; PzGRTxIJRO > 0; PzGRTxIJRO--) {
        SnGNXrORqbhvjO /= SnGNXrORqbhvjO;
        MTDvsqQgymNXqN -= SnGNXrORqbhvjO;
        MTDvsqQgymNXqN /= RJPoevLPPpQMI;
    }

    for (int JyqiLxOlyDNi = 1549854505; JyqiLxOlyDNi > 0; JyqiLxOlyDNi--) {
        pruIXOsfda += PchQkWNRHMlJa;
        IlTBjIJmmu *= SnGNXrORqbhvjO;
        MTDvsqQgymNXqN *= SnGNXrORqbhvjO;
    }

    for (int TFUWPBtqBIaLc = 1454187908; TFUWPBtqBIaLc > 0; TFUWPBtqBIaLc--) {
        pruIXOsfda += PchQkWNRHMlJa;
    }

    return IlTBjIJmmu;
}

string eQLguQIqQcVij::RbThyGbwM(int YChGFScps, int bhsvoLymq, double BIdHeFheiU, string itwtW, int RGtaLIn)
{
    bool uthtpnslb = true;
    string TNwlirhKFkEsWV = string("YUCyzFBlGNEJnFiiYzKrBCbgqgdDDzGpctbxuCuaqzPcCqzfGiDuGcdGUv");
    double fclQtXIStgpoOcT = 604525.5090053544;
    int uMWzsViNepAHJTYv = 1899146197;
    bool WlFMHNRzHXXAd = true;
    string TPESFhKiuiOBescC = string("gHuowcVwVjyXuWHWCkWWxTlTfEZpsoftrYAfDDHNRmvyFbaqPUMGrhmIDGDaaVBNXAMSKrbspMrSblfGdnJUrcGNllnpoOjngfXYxKFcvoSvEbANqwJQbFlCLUJoZbSFxNVjTeDFhYkcGGVnHnoFxIzdjQnQzFwtoNCqGKGvwsYNlqFpyYURWzwnktLLaUGBrMwMyVgefQZudFOddwlGSsFZcgcBwkNaPrNCkmrrByDAFNlOmgEF");
    string qOSPcnfuV = string("GDlSAPrxUhMhFhwhUYQNaizZunWtjDQgnCvrnVgCfveSAOHxccEfnGBdNRGEhycMgQkJdgJVRevYFAujRpTMnBSfVusXKgpHzFlstnzhAUTFSpokkzAqgCTijXrPFAWIXfprALVQAhRvMwQMPZRZpcJZoshjzTTHAXmC");

    if (TNwlirhKFkEsWV > string("GDlSAPrxUhMhFhwhUYQNaizZunWtjDQgnCvrnVgCfveSAOHxccEfnGBdNRGEhycMgQkJdgJVRevYFAujRpTMnBSfVusXKgpHzFlstnzhAUTFSpokkzAqgCTijXrPFAWIXfprALVQAhRvMwQMPZRZpcJZoshjzTTHAXmC")) {
        for (int WnDrFERtot = 762491713; WnDrFERtot > 0; WnDrFERtot--) {
            continue;
        }
    }

    return qOSPcnfuV;
}

int eQLguQIqQcVij::JzARuJh(double mFLODDC, int RVhpxJY, bool EriDyOx, double nYUZiYvp)
{
    string EnwzTTAUYTo = string("hDAjoSJAxZOHfpvIlhUDjdmuzKRRDLnucaByOqEiiAHWVVibmdosAnnNKRwiGEsMHThzyvibfuBiazwtTGhxKiLcDKkHGgftuTipZAcDmPSYvbzuoWKEwbOeFCRILdjGVNfBQbdlWzhhMHdWWwMbdyEwGEjhYfvnvecV");
    int CqOUyKVOd = 1477405858;
    string XeKgC = string("GbDCsvxPnpjbugmzWMhiHGeJeblvGgqzBMkynMAgRHrLnvApqtGpYMDDClHkSVxEEsTMfvKlViUlegEjVyJsiRnKtvtqAxBbpSbplLacIpZTOrCMNTJJtwOAaXhNjbYcjMOSQcafMmtpxrjjmosrrdIGALvBNgfCrBeIGgYLANYicPoWHXjcI");
    string wOyNOSbYo = string("UyfQTONgtLkqdjWtXdzRcYZRxeTlHvrFNnjrxUIogMOjBHtcVbIjOsRrwVPGVvgioLWgcRESodeDwxPBYCFZjfYKYTTxHWzdBxOZzJdRFdhZbfjoWiWRhlPh");
    string rPetNOY = string("chdCpwgpInDxgJRCDpofuZMPZLnEMfUPWReVpWCHzrjEMRCDYEsCDBPIihXqTVEMkWxADtyoaCiblNitjtnlarxwQjjIMtUnJQMIEQUnmQDhqeazCLRZOoKqOYIpUOgPmrYNEGheNvUAeneZFiMBvTvH");
    int dcjDtMQRnGCrpNLg = -1937635202;
    string DxyfKsmByhsTNXzM = string("IsVaXWZMedEovUQKMzIQYPXFXYjGEjOWUznldwASzAdDLwjvVNqtBOsUbpJmTnLdjMRWRJPwakbCmxwCDjRPDfXZtWraxQdTkLYZlUtNxHPiFNqkKXrjziOWKbmSUcHqbfRQdfOnfUTMEFVxDGIXlLDIyaCPkIunsYjrDwKPpuehalCVBdp");
    bool snXkpUxGqnWY = true;

    if (wOyNOSbYo <= string("GbDCsvxPnpjbugmzWMhiHGeJeblvGgqzBMkynMAgRHrLnvApqtGpYMDDClHkSVxEEsTMfvKlViUlegEjVyJsiRnKtvtqAxBbpSbplLacIpZTOrCMNTJJtwOAaXhNjbYcjMOSQcafMmtpxrjjmosrrdIGALvBNgfCrBeIGgYLANYicPoWHXjcI")) {
        for (int JZEIPwtAGnK = 1588110732; JZEIPwtAGnK > 0; JZEIPwtAGnK--) {
            XeKgC = DxyfKsmByhsTNXzM;
            snXkpUxGqnWY = EriDyOx;
            EnwzTTAUYTo += EnwzTTAUYTo;
        }
    }

    for (int AppVk = 1829498027; AppVk > 0; AppVk--) {
        EnwzTTAUYTo = wOyNOSbYo;
        CqOUyKVOd -= RVhpxJY;
        snXkpUxGqnWY = ! EriDyOx;
    }

    return dcjDtMQRnGCrpNLg;
}

string eQLguQIqQcVij::aCVVofLlrimk(double yaBmHnN, int RZCHuqtq, double GsnEAhUtn, string vTCrJahhYLuWz)
{
    string IFTgag = string("vPxlKCfvATdcQwFBMgQOyIGSFgQtgjHYrzEvnuvkFubifcEwSUYQZsKRHRkQaYdKgbmZWMrfdvPlHIENdnFKxJlyVODPIIqbHoMUNeGMVqcZcGROzyabbhpicagpQHQQQhWBzvvgSdZofHOmVWdoAniqtrDIEqhpbVnCWzTCCBYCIUxgmpOrPxbjHFFDpORcorqgMySzpNcohNeehWLSmZVAUxcXtTUICXYQEwgyHbKCTONyhXiKDRjqjLD");
    double ZhytPBmERJ = 122585.51439572763;
    double VxhIAVx = -359970.64462038386;

    if (yaBmHnN <= 662100.1717253474) {
        for (int jUbFEVfo = 1115471614; jUbFEVfo > 0; jUbFEVfo--) {
            yaBmHnN -= VxhIAVx;
            yaBmHnN += yaBmHnN;
            ZhytPBmERJ *= ZhytPBmERJ;
        }
    }

    return IFTgag;
}

string eQLguQIqQcVij::shwPhw(int UMcZdRRLh, bool QJHXW, int UgemBG, string ncBvYDd)
{
    string ZTGyKbuVUqQIpADp = string("muVEELdFrcIyqchfwiJfkMLawEUGJmFmyrCAeZnaaAlaJsWKtaMGtPVlcmiHqlLOpbAdmjTGwlICIcBqpGFgYEciWEDDyzwWxMsbghPGABoSwSdqCVGixksSAXdiThApcfRZnhQrNzrhFOyhQXrDWWwyVlUyqxSmrTpNiSUEKLdSoREZGotIkfHZnASlfWvieZ");
    int OYyIs = -408593026;
    string kYMuhaGShaY = string("WdjQqsskQPFpOvYEUZZdRpQhVwYoruuiYQKLoWbwoKLmIJdtqaHuuxAGwpcZOAwyOABKfLPYSKSiJmUHIIUMAznwKXUhgxRhjked");
    bool JPfoyWrbmavoq = true;
    string ysmWFgWXvU = string("wOnJAwaXZtOloYLbyGiPXxfPpMlozzjoofgMxaYvilopuscuXcarNwDmXwaXcHiHcxWDUvio");
    int ACkScSIicFZDEKuB = -730959244;
    bool nPrQMi = false;
    double FzMcSJZZNzOykc = -48333.53505545071;
    double CZZypvmKnUu = 331956.80110146257;

    return ysmWFgWXvU;
}

double eQLguQIqQcVij::FYqymxsItIkFM(bool Ungfw, bool zwUVExSa, string YDfOUNzZyqfr)
{
    string cVjOXpcGpbLB = string("apyCZYguZOxKCCUOeBpQWrKigSMCzLHegjisoTbIbpvyAmSaVCgxcBkEwgxMEZRNqtzZWqlbgDTzCenSjcQylripIvVFw");
    int KJkylywsYnn = -2011451556;
    double nLYGUSkK = -400583.6233116148;
    double GfEqNpSPiGJm = -728384.9765670031;
    int JIUwCTkCpNUa = -714135763;
    string tWepFx = string("jIwoAutSaKxdKBYsAAjOaVxYSdRazMJmHMjbzewaivnIGAwIMzdKyACLzJFSIpbvxVruLCIpfafDsvEdrzYMDPBZekIuSjAKBYZXZyIWXzNFlcOyuDliftwshrnkAsJtCFDjiGNSl");
    double sZDoqdUqCeKBPhbP = -309138.5945996949;
    double TpzbHkpaoyZwaj = 763688.9474915027;
    string CXaiJR = string("gvVZnPCRzoFauRhdNovhFaYSklxcXlJUJxkLXpTJctnriqWpKGSFqquFSxGSClDlwjJUUUKyxmqoSFzSVXToBcYTnylkiQozSDWIrQApyzxvzIHcizmJTShzYFnnwvHOeWfuSzIRZiVcBsEKgpUZJujzstVAFbSFedMfyUKlpSmlbHgQRoUcWaEhtMUslOqdWSXmGBwzjNGZexikSPZMpnkyCYDJTvM");

    for (int WhyYRQqE = 38616034; WhyYRQqE > 0; WhyYRQqE--) {
        continue;
    }

    return TpzbHkpaoyZwaj;
}

void eQLguQIqQcVij::VRSIExJXdg()
{
    double ICKlcMbwGGJEY = -864454.1888717099;
    bool umkTjZARE = false;

    for (int zyPWCCXMbVcoJ = 1700307955; zyPWCCXMbVcoJ > 0; zyPWCCXMbVcoJ--) {
        umkTjZARE = umkTjZARE;
        ICKlcMbwGGJEY -= ICKlcMbwGGJEY;
        ICKlcMbwGGJEY = ICKlcMbwGGJEY;
    }

    for (int vbesEvsez = 497655700; vbesEvsez > 0; vbesEvsez--) {
        umkTjZARE = ! umkTjZARE;
        umkTjZARE = ! umkTjZARE;
    }

    for (int WSxTcIRvSC = 1583303070; WSxTcIRvSC > 0; WSxTcIRvSC--) {
        umkTjZARE = umkTjZARE;
        umkTjZARE = umkTjZARE;
        ICKlcMbwGGJEY += ICKlcMbwGGJEY;
    }

    if (umkTjZARE != false) {
        for (int AKAgalV = 1935548214; AKAgalV > 0; AKAgalV--) {
            umkTjZARE = ! umkTjZARE;
            umkTjZARE = umkTjZARE;
            umkTjZARE = umkTjZARE;
            umkTjZARE = umkTjZARE;
            umkTjZARE = ! umkTjZARE;
        }
    }
}

bool eQLguQIqQcVij::QoKlij(string MDtlYTRD, double NTLAsJniAFSL)
{
    bool hiXPANANZ = true;
    int IzMnGN = 2077437103;
    int BrEueuaaibgJCW = -222601370;
    string LSNvafQJIrBMdS = string("TRSFvtGpGsLUlbHDZxdwUkBSFbEiDKoejCyDPKRZJconqWtRhWbAcAjtrZMRJKYfYjyQZjACqahZZogawDQyIPpKSWIlFIuXHQlsEuheDGfBVzubPniTcxehllDEwpsTGtaWNbCzmuIziNRktqBuOatgRcXlCUFGDhMIMLyxwaQlQsDXyOzxMudRmtstRoPznaSK");

    for (int yrrkiOxgLvF = 1642753115; yrrkiOxgLvF > 0; yrrkiOxgLvF--) {
        BrEueuaaibgJCW = BrEueuaaibgJCW;
        LSNvafQJIrBMdS += MDtlYTRD;
    }

    return hiXPANANZ;
}

eQLguQIqQcVij::eQLguQIqQcVij()
{
    this->EGnSuSvk(string("gxPiVGkfetLTiszABkoyLoRDzgxCQrlXkmCUO"), true, string("JBqnPvoQNOpRxmBPcykuj"));
    this->EEBnDKtVbI();
    this->lgxIbZO(-176714551, -16070136, -166062.0092059373);
    this->CVRTvcQGwXMXdMiX();
    this->PeLmktGJugMveElN(string("ChmHcwQsQbYyqpkTPcmggvVOmsjGjyHawPLQnUEZTZdOysKHjGRZMfTxSYrvRbgnpUCzpCIEnNITSvCYdLGBeWKgIajWlntrHXYhqAwtkxbZHSJpDywSfKxqBeUYwQdVIwMBhTPfPwMDQO"), true, 768096.3400869935);
    this->RbThyGbwM(-106354082, 2084069703, -636057.4325061569, string("vcOxOyFwvHuMkasPoncvvReDfWWOTpGcyLZYlWlZsTsQDCZXCAljsAvCltKPuMbmjZUliWNmOfnzibxKBVqZTLxBrbjDgkiRKOrqVLKBncRtfNYPoLbJqMlPqJLUFnfsEbIuGZsASmJWkUWAwHYjyXNMbijIOWVvMC"), -1255818998);
    this->JzARuJh(-811690.0697778737, -679762236, true, -217884.83152618862);
    this->aCVVofLlrimk(662100.1717253474, -780892891, 123249.22625953717, string("GYOVhoRhhbdinLyUSLpNIbdhVYNVbfljoBnsqDYddMUNkieNEJlEJhNZDwnJxxJpQVoywHAFYPYLXtyoTWBhcZfhrnJfIusJsweNSMuMYugkAInnoSAqMCLsuWfgATjCHKIMvNGykwdtjZReadOAMjOCW"));
    this->shwPhw(-2049174181, false, 225856896, string("nrHLOBnAubGMAPOdmLvJcUZSpgSjPOlYYliuoNXHhPqYlBcElVPEVeTknuByPQBvAczJiRNiKeJQIrztavejLyGKpwVFUZPDYMoIjolEBXcilBksaHVnJBICW"));
    this->FYqymxsItIkFM(false, true, string("qPsxYKRWFMmgrxviLZsiloDEpsYCiciiZgjcsndqLDXyNcpVvavtPCJGDMfWBCPJyMhZoNLazIWgbQVONzoBMKqcNTTJPqdrIXRpyEtzSCjLFGDFWnszqqdKZCIDyViZZNqGvPvZiodtBhvKdtTcmZvyewFPszfkhpLJNEKgxaU"));
    this->VRSIExJXdg();
    this->QoKlij(string("vuIGcDocWnHyBLuxSQZqBzLXcZrYCILJxCHLmnnomEpujkZuNwzmmIMTJKOuLmRqqHfDkUIzAnKOFbDydvQlKgUxIVpamHvnclYgtOjYZzsTigeJvPVbNKzASkpchqmdbRdGTnFWtdGAescZDYiqBvwNPCqxdiYezsoLKyeUQazIdFDhKjgowIsQStKeoAEpovdjsbupsuyPVfCyKrHqTSImo"), 69518.42575905117);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RuBdkbse
{
public:
    double eTApVFxzYlMNW;
    string noyjpKWSb;

    RuBdkbse();
    double LkFBnrq(string nXsyCi);
    string oFmRNIUJoZXQEL(string yPkqAudRgtUkR);
    double PGtxFrflb(bool zPktXCsQwTPZ);
    void qgqiPQZwkNk(string ucxdc, double MuOGURbbgP);
    double vTMYSLCUYSbU(double zOUgf, bool dMvDQujAgj, string UEAPYzgmwIVVG, int UzWOEkzUHJxECgi);
    int IXFpAkWVqZ(double rRbdygOKbreXHI, bool DNYXnzfySu, bool KaDFTAj);
protected:
    string tdqlxrUFcMSVc;

    bool oLwUnrFYI(string EIeuylVrB, bool TgglTvBXWAa, bool mHbwsyxTGDyvn, string RxaIr, double bWQUnuCQUZHGD);
    int lxiKXKK(bool QmfUoYVv, int WPFjYkfhIwL, string NOUxV, double cDgYazn, bool DHxsNMqNWr);
    int ZMwTOjedFbOphc(bool lzqaEse, int pcIvZdnhcu, int yIlWgmSu, bool mWXjb, int FvPmEOxk);
    double iWuFY(bool vsUqiwjoDJnLjT, string ndtAHT);
private:
    bool KYmwkqBaCud;
    double hGMIh;
    string ILyocxwFkMPnGG;

};

double RuBdkbse::LkFBnrq(string nXsyCi)
{
    int LvYULNNWrJYKDV = 2100547719;
    int qeYRgtpgUSLNAT = 461882610;
    bool bHcPDcibXGEcaTj = false;
    int SchCCyOzD = -1744601015;
    bool tQeMIkIRctpD = true;
    bool rkvBAwu = false;
    bool wCCaVeTQlNVg = false;
    bool wlXPb = true;
    int gsdbAtakesVO = 491976043;

    for (int gxFquLQtZuspNx = 33604526; gxFquLQtZuspNx > 0; gxFquLQtZuspNx--) {
        qeYRgtpgUSLNAT /= SchCCyOzD;
        tQeMIkIRctpD = wlXPb;
        qeYRgtpgUSLNAT /= qeYRgtpgUSLNAT;
        nXsyCi = nXsyCi;
        LvYULNNWrJYKDV -= LvYULNNWrJYKDV;
        tQeMIkIRctpD = tQeMIkIRctpD;
        LvYULNNWrJYKDV -= SchCCyOzD;
    }

    for (int vOcgI = 226740184; vOcgI > 0; vOcgI--) {
        wlXPb = rkvBAwu;
    }

    if (qeYRgtpgUSLNAT <= 461882610) {
        for (int gJtWBFIp = 1332612939; gJtWBFIp > 0; gJtWBFIp--) {
            wlXPb = ! tQeMIkIRctpD;
            tQeMIkIRctpD = ! wlXPb;
            wCCaVeTQlNVg = tQeMIkIRctpD;
            SchCCyOzD = qeYRgtpgUSLNAT;
        }
    }

    return 355807.8594526703;
}

string RuBdkbse::oFmRNIUJoZXQEL(string yPkqAudRgtUkR)
{
    int lheqJtYTzkQ = 1348067931;
    bool RXRXHQblyTvfFm = false;
    double pFAaPQCSNDAO = -518412.91306427016;
    int SaddNCagupqVPCH = 2062091703;
    double lKLYRmxz = 720801.4051673637;
    double rKsPrXdJWkLyebaU = -518214.2250292606;
    int lgZeqEUxORtkJwFa = 1607839093;
    int dcyFMU = -1658908886;
    double GtzAkZCxPJyHEK = -146487.90304253745;

    for (int rhsXW = 1236934173; rhsXW > 0; rhsXW--) {
        continue;
    }

    for (int IbglpKNej = 1908642916; IbglpKNej > 0; IbglpKNej--) {
        SaddNCagupqVPCH = lgZeqEUxORtkJwFa;
        lKLYRmxz += GtzAkZCxPJyHEK;
        dcyFMU *= dcyFMU;
    }

    for (int eseMm = 1939127960; eseMm > 0; eseMm--) {
        SaddNCagupqVPCH -= SaddNCagupqVPCH;
        rKsPrXdJWkLyebaU *= GtzAkZCxPJyHEK;
    }

    for (int qemLOKg = 1204882989; qemLOKg > 0; qemLOKg--) {
        continue;
    }

    return yPkqAudRgtUkR;
}

double RuBdkbse::PGtxFrflb(bool zPktXCsQwTPZ)
{
    bool FWwgMn = false;
    bool iusGBTPJEAl = true;
    bool BuHxBXdcyruO = false;
    double ZLhtW = -490727.3021932785;
    bool QReBkYwsbvXpvnX = false;
    double QFhDwFo = 40356.702787804774;

    for (int CfucUSzrBc = 2030662979; CfucUSzrBc > 0; CfucUSzrBc--) {
        iusGBTPJEAl = BuHxBXdcyruO;
    }

    if (FWwgMn != false) {
        for (int gadBbdKp = 264760033; gadBbdKp > 0; gadBbdKp--) {
            iusGBTPJEAl = ! iusGBTPJEAl;
            QReBkYwsbvXpvnX = ! QReBkYwsbvXpvnX;
            FWwgMn = ! zPktXCsQwTPZ;
            BuHxBXdcyruO = ! iusGBTPJEAl;
            QReBkYwsbvXpvnX = FWwgMn;
        }
    }

    for (int KkZVsVf = 1141862776; KkZVsVf > 0; KkZVsVf--) {
        FWwgMn = BuHxBXdcyruO;
        FWwgMn = ! BuHxBXdcyruO;
        zPktXCsQwTPZ = iusGBTPJEAl;
        FWwgMn = iusGBTPJEAl;
        BuHxBXdcyruO = ! FWwgMn;
        BuHxBXdcyruO = iusGBTPJEAl;
        iusGBTPJEAl = FWwgMn;
    }

    return QFhDwFo;
}

void RuBdkbse::qgqiPQZwkNk(string ucxdc, double MuOGURbbgP)
{
    double GGlgpE = 739455.341889096;
    bool cXMifj = false;
    double ogAPoEVcsFxXrob = -175102.825754354;
    string TRTmmurTxDNlnI = string("XxyqXBpLUfpteYstpEsdSDLaZKTqrsMEywkRIPDZNVyGdwlYcDHzCgoQVnntTwPXWehlTKrBbYtcWADwTxRjKJUBsIFIGOrGciAqAomUpzOrwDRAJypYjlgHnrghFeSqUlaoJKRXEuqeuTHoWe");
    double iWxwPizd = -175533.18391287263;
    double dGUIJegEEjtr = -234638.98689153956;
    double zKbrqgqcMfNlyFui = -596375.095704777;

    for (int sQcyUmzI = 1665505675; sQcyUmzI > 0; sQcyUmzI--) {
        TRTmmurTxDNlnI += TRTmmurTxDNlnI;
        cXMifj = cXMifj;
        GGlgpE = iWxwPizd;
        iWxwPizd = iWxwPizd;
        dGUIJegEEjtr /= MuOGURbbgP;
        GGlgpE *= dGUIJegEEjtr;
    }

    for (int WwcMwjJMvICxTVZj = 1541733322; WwcMwjJMvICxTVZj > 0; WwcMwjJMvICxTVZj--) {
        GGlgpE += GGlgpE;
        TRTmmurTxDNlnI += TRTmmurTxDNlnI;
        GGlgpE = ogAPoEVcsFxXrob;
    }

    if (iWxwPizd != 739455.341889096) {
        for (int uEMpgCLbTmDxy = 1728921166; uEMpgCLbTmDxy > 0; uEMpgCLbTmDxy--) {
            continue;
        }
    }
}

double RuBdkbse::vTMYSLCUYSbU(double zOUgf, bool dMvDQujAgj, string UEAPYzgmwIVVG, int UzWOEkzUHJxECgi)
{
    int EhVunJpMcdZE = -763946081;

    for (int RpMzroSsezcoL = 350248823; RpMzroSsezcoL > 0; RpMzroSsezcoL--) {
        EhVunJpMcdZE *= UzWOEkzUHJxECgi;
    }

    for (int EROAb = 140727027; EROAb > 0; EROAb--) {
        UzWOEkzUHJxECgi = EhVunJpMcdZE;
    }

    if (EhVunJpMcdZE >= 2080065678) {
        for (int SciawjgQWE = 1163757025; SciawjgQWE > 0; SciawjgQWE--) {
            UEAPYzgmwIVVG += UEAPYzgmwIVVG;
            UzWOEkzUHJxECgi *= EhVunJpMcdZE;
            UzWOEkzUHJxECgi += EhVunJpMcdZE;
        }
    }

    for (int NRMsdJDZJPFxJPIj = 1365299553; NRMsdJDZJPFxJPIj > 0; NRMsdJDZJPFxJPIj--) {
        EhVunJpMcdZE = EhVunJpMcdZE;
    }

    for (int XMOdeyUt = 1965552406; XMOdeyUt > 0; XMOdeyUt--) {
        zOUgf -= zOUgf;
    }

    if (UzWOEkzUHJxECgi == 2080065678) {
        for (int TQsdBtCGA = 655483314; TQsdBtCGA > 0; TQsdBtCGA--) {
            zOUgf = zOUgf;
        }
    }

    return zOUgf;
}

int RuBdkbse::IXFpAkWVqZ(double rRbdygOKbreXHI, bool DNYXnzfySu, bool KaDFTAj)
{
    int EODFJFWJjipstF = -2064531866;
    double UlbqhbV = -277013.87099811813;
    double FGGVdVeESbNzGe = 30352.141416819068;
    int THuxrjjbiAY = -254923511;
    double yOJBfZfF = -268554.1443083914;
    double jMHQubiWPU = -75262.97476795719;
    bool NxnUuuznFQqzfMGG = true;
    bool KnuipSWuwGg = true;

    if (yOJBfZfF >= 443727.5866982293) {
        for (int ggldqvipqT = 336012594; ggldqvipqT > 0; ggldqvipqT--) {
            KaDFTAj = KaDFTAj;
            EODFJFWJjipstF /= THuxrjjbiAY;
            KaDFTAj = KnuipSWuwGg;
            rRbdygOKbreXHI = jMHQubiWPU;
            KaDFTAj = ! KnuipSWuwGg;
        }
    }

    for (int SMADojxntWMJiIr = 262654449; SMADojxntWMJiIr > 0; SMADojxntWMJiIr--) {
        jMHQubiWPU /= yOJBfZfF;
        UlbqhbV += rRbdygOKbreXHI;
    }

    for (int kZGfMg = 1623716868; kZGfMg > 0; kZGfMg--) {
        UlbqhbV *= FGGVdVeESbNzGe;
        rRbdygOKbreXHI -= FGGVdVeESbNzGe;
    }

    return THuxrjjbiAY;
}

bool RuBdkbse::oLwUnrFYI(string EIeuylVrB, bool TgglTvBXWAa, bool mHbwsyxTGDyvn, string RxaIr, double bWQUnuCQUZHGD)
{
    int tkNWSUJJZDF = -849745632;
    int dOWKBW = 1960645284;
    int SEiVVkd = -987095781;
    string LpMnoOvgu = string("rxNZfTQzzTCEujeJUPucyydBwiWsvVyDjefcKsGZkGOYcOOLpbXoYTTILTdqHZHKBbFFRPHxtIqlyOpuCBrwoZWlagjprPFCxlJCesiaNcwFnfsoKbcTnsLpnAJMkCdCuqLGYNtBPImbIodIBweBopjuZLwKhXNazHexklAEFiuZuzggnaNTYMPhwYMkUHVxvMcYk");
    string doabbZ = string("fqgbizkvFOzDNMshixtRmRtsHKohACJUGJNyAOTqwQpOXhegqLJyJlyvOAsGcSTVBmavHOUzhIfgMdhjslWQlwDOjXZFqEFWsIAZTIaIjmNlGcyDtLWuRuCOezWCltlFbcmTCrPDYfTfuiBhWdqiuDcYuysAKZhzwnyDpQkwummszAJvCqvbsHBQWgaiTYJzNYeYuhivOMCpvQ");
    double DtmdHLn = 442358.7621591403;
    int bImHI = 700185678;
    string zirCRINMwBiErOO = string("yyIPASKJdBnGnXRMaBwfHiDcqwiIuoMVmiTtmFFArIyQzWdJJaAmkmcOaK");
    string OrgyvnKuR = string("haQoEoRMoaGsoApGIfdqEXxwJolkfwlQKAuSFUtJZgikRiJJqfjqckgGbHsIzEugHGHLsheYgIwFbkafIakufopYOnAYHeKVoNINlpVSOMTtMpUwsjrCraWPAcsZxVfRLHKrybaFnCBpYghPUrczVMJylgpjqtsdaGqxXAOkhBdyDBeSsxuBjIQDbbOpndCDVXXLzLSsRBDhrcwAABuRhZAcDeDRGBn");

    for (int KEqReyT = 80115522; KEqReyT > 0; KEqReyT--) {
        OrgyvnKuR += doabbZ;
        SEiVVkd += bImHI;
        TgglTvBXWAa = mHbwsyxTGDyvn;
        SEiVVkd += tkNWSUJJZDF;
    }

    return mHbwsyxTGDyvn;
}

int RuBdkbse::lxiKXKK(bool QmfUoYVv, int WPFjYkfhIwL, string NOUxV, double cDgYazn, bool DHxsNMqNWr)
{
    double dzxRC = -472017.42170258105;
    int wDIqeqCDeg = 612554903;
    string IDEGYPdu = string("wrPyZtVyIKOBUFpAVSAdTtyzORILyEGuylDXYCxTrGBMqxCGTnBjUxZZJsmWUInjFdIYrNAUkXGkbAzqaGGvZFbSnfxHcOOqpztSbuFyHEZXZZMQranRMOxcJbKYBKadfHvWMXJICCcSfWTjftcmTThNDjxvgfIHOXsplsBiETVSbtwhCnbyDZlWTHVNIBlWOgARMimqABjBpShbhkRwjsFBZJLwUCTlHAqXQ");
    double xraeFzticEZ = 619185.119074131;
    bool VvjfjHENVOoO = false;

    for (int eHwmuA = 2110305492; eHwmuA > 0; eHwmuA--) {
        wDIqeqCDeg -= wDIqeqCDeg;
    }

    if (VvjfjHENVOoO == true) {
        for (int sfEQkFwdXutRuUK = 1282322239; sfEQkFwdXutRuUK > 0; sfEQkFwdXutRuUK--) {
            wDIqeqCDeg *= WPFjYkfhIwL;
        }
    }

    if (IDEGYPdu >= string("Aufjue")) {
        for (int njUmIdYQk = 96870324; njUmIdYQk > 0; njUmIdYQk--) {
            continue;
        }
    }

    for (int VfcEu = 519673201; VfcEu > 0; VfcEu--) {
        continue;
    }

    return wDIqeqCDeg;
}

int RuBdkbse::ZMwTOjedFbOphc(bool lzqaEse, int pcIvZdnhcu, int yIlWgmSu, bool mWXjb, int FvPmEOxk)
{
    bool qYgBWhkYCJyGK = true;
    double OzKZgTtDrg = -793294.871750035;
    double NRRYpYZqx = 995612.1367643261;
    int EULaQldLlklgNFwF = 45778558;
    string dGaOIlMjRzeBvT = string("pvHwuUKmQewMLNrZZBjRUxVtFNzgoBHEPpucxJROWVWQfEfxDyxoYNybnjkaegjywBSPOpLpGeFDSEedwocd");

    for (int zODEa = 161547598; zODEa > 0; zODEa--) {
        lzqaEse = ! qYgBWhkYCJyGK;
    }

    if (pcIvZdnhcu < 2002121854) {
        for (int kPkxybCoaf = 500710571; kPkxybCoaf > 0; kPkxybCoaf--) {
            FvPmEOxk -= EULaQldLlklgNFwF;
            FvPmEOxk += pcIvZdnhcu;
        }
    }

    for (int ZecajEqRuxa = 1096171035; ZecajEqRuxa > 0; ZecajEqRuxa--) {
        OzKZgTtDrg = NRRYpYZqx;
    }

    for (int EkBZAzcEVZtDp = 1014906511; EkBZAzcEVZtDp > 0; EkBZAzcEVZtDp--) {
        mWXjb = ! mWXjb;
        pcIvZdnhcu *= FvPmEOxk;
        yIlWgmSu = pcIvZdnhcu;
        qYgBWhkYCJyGK = qYgBWhkYCJyGK;
        FvPmEOxk = EULaQldLlklgNFwF;
    }

    return EULaQldLlklgNFwF;
}

double RuBdkbse::iWuFY(bool vsUqiwjoDJnLjT, string ndtAHT)
{
    double PxIQOqxqTy = 865331.8531043545;
    bool NSsrX = false;
    double IdIcXgPKbhn = 387354.6594710781;
    double NhshdmWiCPp = 390288.3704874809;
    double ynGYo = -911736.3244764033;
    string suxEBocWFJOiTk = string("oCcxtxdcXkAzuKuNTqwIwCTvYyLLfVxyHqWgwxQzdUMJyWoXqpItokUUhNoLvceUBICkyUjUxEOPAcolTfxQVViSoCkmNWynanhhSfMmwxewAVsTfrWlDuUfQZwbcYVoUFiHnKYbh");

    for (int iIBpDEqlUgKMXnG = 1939129652; iIBpDEqlUgKMXnG > 0; iIBpDEqlUgKMXnG--) {
        vsUqiwjoDJnLjT = NSsrX;
    }

    return ynGYo;
}

RuBdkbse::RuBdkbse()
{
    this->LkFBnrq(string("BlSOncFnaFSLARwdDbOShimqgOFIgfqXEiaEZaIsAJwgSTsJkEhPYnoCBYPbihYlelTgiXqhDXIH"));
    this->oFmRNIUJoZXQEL(string("bfxlKkAIeCBCjOWrNMRyeONXsixJJMHOTheCDToVeIKsAiuYYjwHzIiKuGBRRDJSaRfUCuUmvVKWcxFIDfgqABDikRXSaISmCiwJmSxbZZNAECAIUrFFEfTSMsqrgMHQtsskVCfYXPksTuUESEchjAkTWjNsEaqokUtLUzhIjsmayNOPzxBTjlTHJjyWdwELFaqAOSSptxlxSeMgEAFFQSGjQKxhZgdOLUzAuiVNmXrZjRrwHOyZSPUYqZIQA"));
    this->PGtxFrflb(true);
    this->qgqiPQZwkNk(string("jPhBxsFggSgVckXxEPQaVRhZShrLSIHkYBxAYipB"), 1025358.942434218);
    this->vTMYSLCUYSbU(-883093.8377984867, false, string("HplzAcHdiwdKiPbJQspGMQQmMIxpJfkfHEoPCvXlsENFnAyTrwLOeJZvgDaPotahGCbGZYGnLFYJiYayqgVObfGookxCKRiLUkIEZdXKWIZxofSZxBQIkNfrqhosEeuOnOqxtgqvASWQnIwxNKkTGceFVJxjMniweCguPwrKOdosxSrAiggCwnTZcSvaHInWRHZAmLkAOJYeeWOYXXdnQjTKapVvMstOmSrpAonWYAkpRAhKek"), 2080065678);
    this->IXFpAkWVqZ(443727.5866982293, false, true);
    this->oLwUnrFYI(string("nTHAwTpxiNgKSALnHtMhjmpZmJhDUCClgLvJtZFpwQXLcJJmTnexDvyOAvdgKlsHEyDocjk"), true, true, string("mQLEczxLRaKpSvcBnSsnoIgrSFJXkAOypwFMqZOVRAiyjIgqnVANcrFXVlbceLeijVZSsEiEioJncdmeRSZVKNjBEvJfENslXFlsSQEHvWFPdVowcnOkozJmnAmwxhglblYiINzdbvrLXDypZqquOJSjgaNmPscTcGbyllcjpiuzWmODhCbtnHnywl"), 119294.85994562262);
    this->lxiKXKK(true, 2102249000, string("Aufjue"), -294732.6941342776, true);
    this->ZMwTOjedFbOphc(false, 2002121854, -1588030832, false, -1319614985);
    this->iWuFY(false, string("akIJPMEVEVWqtFCUZTIREUSVwoBAeoFufKsKYhGPAoBXennVPahGXTVKtoEpyUrMrudBaktRaFeNZoTLoxxgGmqpRIXFqyMUoTZGoiyzUKPQgZJnabbbVMcoCjNWqGZFjkrAVUvUfzSIAwKDlOxLoOfpLQQmFhSMkGnxZmUfMchfxziAemxYRbhBxjrliNEQcoIlMsq"));
}
