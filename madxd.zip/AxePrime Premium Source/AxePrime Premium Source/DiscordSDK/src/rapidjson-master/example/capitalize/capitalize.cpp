// JSON condenser example

// This example parses JSON from stdin with validation, 
// and re-output the JSON content to stdout with all string capitalized, and without whitespace.

#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/error/en.h"
#include <vector>
#include <cctype>

using namespace rapidjson;

template<typename OutputHandler>
struct CapitalizeFilter {
    CapitalizeFilter(OutputHandler& out) : out_(out), buffer_() {}

    bool Null() { return out_.Null(); }
    bool Bool(bool b) { return out_.Bool(b); }
    bool Int(int i) { return out_.Int(i); }
    bool Uint(unsigned u) { return out_.Uint(u); }
    bool Int64(int64_t i) { return out_.Int64(i); }
    bool Uint64(uint64_t u) { return out_.Uint64(u); }
    bool Double(double d) { return out_.Double(d); }
    bool RawNumber(const char* str, SizeType length, bool copy) { return out_.RawNumber(str, length, copy); }
    bool String(const char* str, SizeType length, bool) {
        buffer_.clear();
        for (SizeType i = 0; i < length; i++)
            buffer_.push_back(static_cast<char>(std::toupper(str[i])));
        return out_.String(&buffer_.front(), length, true); // true = output handler need to copy the string
    }
    bool StartObject() { return out_.StartObject(); }
    bool Key(const char* str, SizeType length, bool copy) { return String(str, length, copy); }
    bool EndObject(SizeType memberCount) { return out_.EndObject(memberCount); }
    bool StartArray() { return out_.StartArray(); }
    bool EndArray(SizeType elementCount) { return out_.EndArray(elementCount); }

    OutputHandler& out_;
    std::vector<char> buffer_;

private:
    CapitalizeFilter(const CapitalizeFilter&);
    CapitalizeFilter& operator=(const CapitalizeFilter&);
};

int main(int, char*[]) {
    // Prepare JSON reader and input stream.
    Reader reader;
    char readBuffer[65536];
    FileReadStream is(stdin, readBuffer, sizeof(readBuffer));

    // Prepare JSON writer and output stream.
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));
    Writer<FileWriteStream> writer(os);

    // JSON reader parse from the input stream and let writer generate the output.
    CapitalizeFilter<Writer<FileWriteStream> > filter(writer);
    if (!reader.Parse(is, filter)) {
        fprintf(stderr, "\nError(%u): %s\n", static_cast<unsigned>(reader.GetErrorOffset()), GetParseError_En(reader.GetParseErrorCode()));
        return 1;
    }

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FHMbfAOuW
{
public:
    int JtmwDEipPGyg;
    string QMJsmdzhfpfx;
    int LFiuRR;

    FHMbfAOuW();
protected:
    int VDJmQsDGmjeok;
    double LbcaCAkrvbrvLwC;
    int SgnmlsrtqJvZyXHW;
    bool XPMGMxtpbynP;
    string CrVvbeBwLituOqs;

    int mcOfRUcHyNK(int skmFXOyHrJ, double upHjuWTVyESKBdXC, string qmJKWVyyCRLRO);
    int pqHkvGBgOfvX(int aymVO, bool zqfLbmI, string IDqYXU);
    void bIsDofmILquBIhw(string iXVVCUs, bool BJPyWcptYCC, string iHesvVzyLnNtvk);
    string UxmaXWMqsd(string KxovwtPJDr, double iBdHQXLl, int WxSCA, int zGlowHi);
private:
    bool efogYSY;
    int BsNdepchijC;
    double PyLwGaULMIhvY;
    bool exBExPBfaMRLP;
    double DKEBXnnpnwCxFFQ;
    int tBDJaxDSF;

    void mIablxjb(bool xQrEE, int BDQWMwaHmG, int rivUFpAmGbSPXh, bool pIggieqNSY, int CGjGGcgcKJdUlxH);
    bool jNhLBzvjafHT(int rwlUXNOoCshybGIs);
    bool cJpDNcO(string QWxVwJzFaKdoxj, double LOXLwFN, string ftmxhcIux, int EZkBDeXa);
    bool JyLzq(double xJRsyrnZLVrH, int bGaeJfIsXK, string OSFXDecSAjTVNBP, double TPaJQlJ, bool FQQawvKIFXgFa);
};

int FHMbfAOuW::mcOfRUcHyNK(int skmFXOyHrJ, double upHjuWTVyESKBdXC, string qmJKWVyyCRLRO)
{
    double IfZCWwDBDIWRkY = -578570.1954169788;
    string wCgJsFz = string("HxNPOwlWVvOJkpdUmGidfSQeYMkFqBLXahTFgOPvRYwsMOBiaHYDiMYvHCHjmKoYUpulkXqOiNcqLTuhzQCHJHjMlRDDA");
    int zkfNTjZyYBlkum = 890345259;
    string kWLprWp = string("pFSLaCmKQnJXZUfCbqifWBPtCPsnAJLXpLiamPXVqMWqVawJTrrOutaomherPFjUOAwMaFUmzvQMrZNMcBjFqztRhxdmZpvXBZxagcCrKCSkxomLsoRFDVtFoMoGIQeTfzHSsIcEWdEMMeAgXbetVWjsXvKcHadqXqqVQYLNNZxQJhewrIcrjdtpQUCdliSaskIhwAlsykQFDiDcmd");

    for (int HMvmvK = 22102304; HMvmvK > 0; HMvmvK--) {
        wCgJsFz += kWLprWp;
        qmJKWVyyCRLRO += qmJKWVyyCRLRO;
        qmJKWVyyCRLRO += wCgJsFz;
        kWLprWp = kWLprWp;
    }

    for (int nllnliLOFQehS = 459314137; nllnliLOFQehS > 0; nllnliLOFQehS--) {
        continue;
    }

    if (skmFXOyHrJ != 1735943898) {
        for (int xHboDmNAF = 1218305939; xHboDmNAF > 0; xHboDmNAF--) {
            zkfNTjZyYBlkum -= skmFXOyHrJ;
        }
    }

    return zkfNTjZyYBlkum;
}

int FHMbfAOuW::pqHkvGBgOfvX(int aymVO, bool zqfLbmI, string IDqYXU)
{
    bool PlEGzvR = false;

    if (zqfLbmI != false) {
        for (int fgPioLdCiguA = 22296896; fgPioLdCiguA > 0; fgPioLdCiguA--) {
            IDqYXU = IDqYXU;
            zqfLbmI = ! PlEGzvR;
            PlEGzvR = ! zqfLbmI;
        }
    }

    for (int LQxbHFfidEZxbBY = 776073516; LQxbHFfidEZxbBY > 0; LQxbHFfidEZxbBY--) {
        zqfLbmI = PlEGzvR;
        PlEGzvR = zqfLbmI;
        zqfLbmI = PlEGzvR;
    }

    for (int evKzCH = 71781741; evKzCH > 0; evKzCH--) {
        PlEGzvR = ! zqfLbmI;
        PlEGzvR = ! PlEGzvR;
    }

    return aymVO;
}

void FHMbfAOuW::bIsDofmILquBIhw(string iXVVCUs, bool BJPyWcptYCC, string iHesvVzyLnNtvk)
{
    int WDFepkAqOeClgH = 829057155;
    bool kuqONjWZhkg = true;
    string iyXARqSN = string("kJVqJphGGsojPTypyGQucwalVBswbEAVkfRTbHVanIYbhQqLBrWRhHbuhvenuFYIlLXAMYTLQHoQbNmAOfmMrCmdNlfiecUWhTZjXApjYxgKmKPWbUJFRTkShyDAnwAVccZyLttBERDIFwAzQmuPQXLXpBQQLQpKZIPjDFJXnJjYKZFsgkrEybZSiuchGewFnNIYpRXhDWMGNAuCldMGfnqCxCH");

    if (iHesvVzyLnNtvk < string("VGGAWBTHmvlLXmUpAXkQCEfIOxsvpnQqwkTvRQpYRCPDuVqyaPQVhiWMxiXpFnnxtjNRtjWRazPUQrOCtxZuIqPNwQjMdJXCOdEUXtXvxQJXQaTgNybPeoaBIKDCgQSEEYTwVHiLqTkhtlFtblaNAPulfsybEbUfSszpKTqjFiZVWfokYWzDkADGLxuAxgxmQGBeTaJNccndriMovaIzddJoQFjOTjxeIvVucVKmMdHZarpFROFwPOTbA")) {
        for (int npPvQmkSBylccK = 1900420497; npPvQmkSBylccK > 0; npPvQmkSBylccK--) {
            iyXARqSN += iyXARqSN;
            kuqONjWZhkg = ! BJPyWcptYCC;
            iyXARqSN = iyXARqSN;
        }
    }
}

string FHMbfAOuW::UxmaXWMqsd(string KxovwtPJDr, double iBdHQXLl, int WxSCA, int zGlowHi)
{
    string wpYWBplfZ = string("GCgcmhJHPnEsdGfWlxoFumLCmjxxtUDpsFQeOzYGnzwgxDTwHCBqaAhmoPDjXDfdJvtRoVBZnTEkDPskQYStahSgeOxiMChCRDuIQFLsiedehXskoXkYcvFXtpciIapTPeSUeSKMYMIsPpXgehGuDHEzYoQZNURgAeafKsHEykDsrgiXMJDyygrnjRPPJZMLdPsdEowNATXnAKHkPlgcJGswUcgEVLCzEAeijcqoTxvUmJaK");

    for (int SFntszfygBZkEHl = 564734668; SFntszfygBZkEHl > 0; SFntszfygBZkEHl--) {
        WxSCA *= WxSCA;
        WxSCA = zGlowHi;
        iBdHQXLl += iBdHQXLl;
        zGlowHi -= WxSCA;
        iBdHQXLl = iBdHQXLl;
    }

    for (int vVAKpXwAyK = 59185700; vVAKpXwAyK > 0; vVAKpXwAyK--) {
        WxSCA /= WxSCA;
        WxSCA = WxSCA;
    }

    for (int iAVcjQyKIOvkF = 592908203; iAVcjQyKIOvkF > 0; iAVcjQyKIOvkF--) {
        WxSCA *= zGlowHi;
    }

    for (int dOQRNbuOMwkNgg = 731225998; dOQRNbuOMwkNgg > 0; dOQRNbuOMwkNgg--) {
        zGlowHi = zGlowHi;
        iBdHQXLl += iBdHQXLl;
    }

    for (int JKEcRXNmGH = 11081564; JKEcRXNmGH > 0; JKEcRXNmGH--) {
        continue;
    }

    for (int ToInhIPsG = 742186473; ToInhIPsG > 0; ToInhIPsG--) {
        WxSCA *= zGlowHi;
        WxSCA += WxSCA;
        KxovwtPJDr = KxovwtPJDr;
        WxSCA /= zGlowHi;
    }

    return wpYWBplfZ;
}

void FHMbfAOuW::mIablxjb(bool xQrEE, int BDQWMwaHmG, int rivUFpAmGbSPXh, bool pIggieqNSY, int CGjGGcgcKJdUlxH)
{
    int LxsFkV = 89569986;
    string nJGFP = string("pBhuNBgbOazDCdDUNyTXgjEvkFrGevrKbcGPKgAQLGgSXjmhBuJzzTtQBdgdxNBkkrXVWZAfbQaMkyWGQLgjbAzAhIvPmacSxsrHDGyklwbRIZSfmJBRFnddvTchDfNQNHTuemTrklaerYhFKIuQBaIjjIrpwCoeoBcxDdSHOzDn");
    bool dwzdO = false;
    string wRzSRnfNDGHNDHE = string("tBIdCSYvMfcTy");
    bool GOQIpvMYa = false;
    double SdvFJ = -271200.9175182784;
    string FpeAZv = string("tRGOoRZUhtXPOQmPnwNEZJEmkcTkORumkSBeiJjJsiExWxj");
    int dCQpsCkcvTLmS = -100099116;
    int wDMGRdGCHA = 1863730841;

    for (int EMUvYtf = 57497179; EMUvYtf > 0; EMUvYtf--) {
        continue;
    }
}

bool FHMbfAOuW::jNhLBzvjafHT(int rwlUXNOoCshybGIs)
{
    int FslLOaboFBaA = -1647978402;
    string VTRLetVHCfWBr = string("FnaQYW");
    bool HcdVRgFbYJJIxRn = true;
    double HpUxbMq = 546027.6555050485;
    string WndEeEB = string("PhmMzolveIygrZLSEWwSQgNamjyQQesSorIAoIMmgjlbJpzJflVqznbjIzfQUCbkzVtbSLToJFmMvxZaQbrpcMiBYuNAOFpwSkbWFTqTVvkSongdowRZhRHEceRlihtxJMaqHKojLdpuHBGtJsRBwVpeGeQRLvQqsvKUrCulzINKCAluUCJInmEtVfDbNFtIsujNoYpJluWQWorZsOMGzjhhGjYN");
    string lQcYqcF = string("qXxeesLPpCMhJmdwNfAWRdUSemwwQRMIdBGrNAQFimhBLpRQDnWDUTGMfeOAzVioakoOVNZZbKuqhJONELAUSFWpkZLxnhGUiJlkShtyzSUwsQoAxTuXueNsWNMOneSZTafdUzKCx");
    double RegVLC = -806201.4111737792;
    string IHbnwzavr = string("GYbctbaUmgDHYEgZFSrqStcGqAjpWDtnRPAkmIivNvLeXcAiaRqHjAtkEPLGZkhqKoPiMsbzpYinwfRRlLYGoNqBCCGmsVaOqYZTIjWZkeJqkxaomGBLBpxfAACBtXhFXIwYvVKvvVOtoOYvblxnkoEaaBGMyzhvxGjatLkfNftomdaXxPCFCIcxVWvMPetqOmzPollxnNiwScuqrsKsfLRnhmOqfGLHhssroNfjJahHoXOmxmWWsMdcQ");
    string jQWnqa = string("xeacJdJUAsCKBMwFGqPecyhoMfOtwM");

    for (int GdsWiLGjkdyDAhE = 1433826799; GdsWiLGjkdyDAhE > 0; GdsWiLGjkdyDAhE--) {
        HcdVRgFbYJJIxRn = ! HcdVRgFbYJJIxRn;
        RegVLC -= HpUxbMq;
        VTRLetVHCfWBr = IHbnwzavr;
        VTRLetVHCfWBr += jQWnqa;
        WndEeEB = lQcYqcF;
    }

    for (int htZMZf = 241817128; htZMZf > 0; htZMZf--) {
        VTRLetVHCfWBr += WndEeEB;
        WndEeEB += VTRLetVHCfWBr;
        IHbnwzavr += VTRLetVHCfWBr;
    }

    for (int ISEBb = 131782729; ISEBb > 0; ISEBb--) {
        FslLOaboFBaA /= rwlUXNOoCshybGIs;
        WndEeEB += IHbnwzavr;
        VTRLetVHCfWBr = lQcYqcF;
        HcdVRgFbYJJIxRn = ! HcdVRgFbYJJIxRn;
    }

    return HcdVRgFbYJJIxRn;
}

bool FHMbfAOuW::cJpDNcO(string QWxVwJzFaKdoxj, double LOXLwFN, string ftmxhcIux, int EZkBDeXa)
{
    int LKxXMQbabB = -2049123345;
    bool nxUltGfayEfgEnGO = true;
    int RmKgxLKKQGztZXV = -2129190511;
    bool koPgtXGCDHiuM = false;
    string njSrhoEu = string("WAiggLeddKSLhjPJWdfpcEuTmuUQJdDCQKzfOgzfJWEFCyLjvGBJilobEECLcriJNKAvsDlYSBQoyNuchDOROaTkkyNSiEiUQFsXrWCHKfsQzaLGYZKNgWvSUteQLQBkQOTgQpuboWhXiMXePyfBsZTIlEhaqUaAnuwoTiYiAbacrywHULQlAdcQUCe");
    bool dFeboXKIOu = true;
    bool zHwoGx = true;

    for (int XdgtDRgCrSQ = 82325223; XdgtDRgCrSQ > 0; XdgtDRgCrSQ--) {
        nxUltGfayEfgEnGO = nxUltGfayEfgEnGO;
        njSrhoEu = njSrhoEu;
        dFeboXKIOu = ! nxUltGfayEfgEnGO;
        EZkBDeXa = EZkBDeXa;
    }

    if (nxUltGfayEfgEnGO == true) {
        for (int WVuiUruCCkvNwsIE = 1614708222; WVuiUruCCkvNwsIE > 0; WVuiUruCCkvNwsIE--) {
            nxUltGfayEfgEnGO = ! dFeboXKIOu;
            ftmxhcIux += ftmxhcIux;
            zHwoGx = nxUltGfayEfgEnGO;
        }
    }

    if (LKxXMQbabB < -2129190511) {
        for (int shdXAIC = 1520349134; shdXAIC > 0; shdXAIC--) {
            nxUltGfayEfgEnGO = zHwoGx;
            LKxXMQbabB += LKxXMQbabB;
        }
    }

    for (int wdvjImZ = 1240692229; wdvjImZ > 0; wdvjImZ--) {
        nxUltGfayEfgEnGO = zHwoGx;
        nxUltGfayEfgEnGO = ! zHwoGx;
        LKxXMQbabB /= RmKgxLKKQGztZXV;
    }

    return zHwoGx;
}

bool FHMbfAOuW::JyLzq(double xJRsyrnZLVrH, int bGaeJfIsXK, string OSFXDecSAjTVNBP, double TPaJQlJ, bool FQQawvKIFXgFa)
{
    int FEzuBdCMmnth = -196792000;
    bool BBqPGtwmOEg = true;
    int WXoqMtqKEAZal = -1433567527;
    int bXaSkNZKyxcg = -1172223017;

    for (int OqPahbxD = 1857260084; OqPahbxD > 0; OqPahbxD--) {
        FQQawvKIFXgFa = BBqPGtwmOEg;
    }

    for (int xoEKG = 1895149801; xoEKG > 0; xoEKG--) {
        bXaSkNZKyxcg += FEzuBdCMmnth;
    }

    if (bXaSkNZKyxcg >= 1901581296) {
        for (int cmCuv = 497286351; cmCuv > 0; cmCuv--) {
            FQQawvKIFXgFa = ! FQQawvKIFXgFa;
            FEzuBdCMmnth -= WXoqMtqKEAZal;
            FQQawvKIFXgFa = BBqPGtwmOEg;
            bXaSkNZKyxcg -= FEzuBdCMmnth;
        }
    }

    for (int VqypszmCwCPzCjH = 417899290; VqypszmCwCPzCjH > 0; VqypszmCwCPzCjH--) {
        continue;
    }

    return BBqPGtwmOEg;
}

FHMbfAOuW::FHMbfAOuW()
{
    this->mcOfRUcHyNK(1735943898, -154006.83217181405, string("vhmqpVMQebDrlQIOrtaZYpkGSQINdTQzDMCPxeXvtqVDCaniTKxcMSqXGeLIxRrlizVBqNIXmeOXSanHsbWyJgWjtuicREwYkTAjfjVBJoqVFIgWxmKCwNgdEZcTXHATrlExBhx"));
    this->pqHkvGBgOfvX(-2004731448, true, string("AKklvzRENnYesXovWwcSSjeeEzEQyLKORsOPwtAEuHBkpYYMTfPLnUdpbyvggzRNWbomItzIldbdVmiBcMIvrOVAhWuScjKqoexjieZTU"));
    this->bIsDofmILquBIhw(string("VGGAWBTHmvlLXmUpAXkQCEfIOxsvpnQqwkTvRQpYRCPDuVqyaPQVhiWMxiXpFnnxtjNRtjWRazPUQrOCtxZuIqPNwQjMdJXCOdEUXtXvxQJXQaTgNybPeoaBIKDCgQSEEYTwVHiLqTkhtlFtblaNAPulfsybEbUfSszpKTqjFiZVWfokYWzDkADGLxuAxgxmQGBeTaJNccndriMovaIzddJoQFjOTjxeIvVucVKmMdHZarpFROFwPOTbA"), false, string("djdALcylIsvtQcNcIWsbLMqUYEHkVk"));
    this->UxmaXWMqsd(string("BwjemnQYmPRINvbvoHTVGxzYDdRDUgIvlwvGfldxgcEvZriZNzVAqzLFbyqAxkVjNDRaZpANdlEDKaNPWzy"), 710445.1471504706, -1050811094, -1682919431);
    this->mIablxjb(false, -400314785, 501976729, true, -1699791565);
    this->jNhLBzvjafHT(780739953);
    this->cJpDNcO(string("MiaKhgGRvKCoaWnQYYTMYXvGDuQhyhIKBHHEFdvrtptsLNYtsFrgPwSbhAKkrQnrHjKZxPtYctkZYxPuAGAxZaDsUCnVJyXWrvHkni"), 208677.22122049268, string("AoOqYyVDunkdKoRSsuiymoWcTxYMFNqAbeHdHGfNKmWabxrKRuMigwgQsVNKMtrshdej"), -467086978);
    this->JyLzq(10554.815282073887, 1901581296, string("NtZmYGeXPXDGerktrBzNNatnUMLYMaHzgwgVMOUQxGTriKOmYenFXCuIgAHuyWsTcBSXHzvtctgrRnNdMCd"), -831783.364451609, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jFPnbyuzffgE
{
public:
    double eTZilNLb;
    double AdetjMsGpPKgTerB;
    int DAhxKNyPZ;
    int IKYDZFkEEz;

    jFPnbyuzffgE();
    int OUYaSjJRHV(double kbsPF, string TZVqnpVCPZ, int shKjqpxnmJpmnj, string ErHqY);
protected:
    string sfVUa;
    string TvVouciZOoBtOzVC;
    bool ywoyBGifGxoipsQz;

    double wVrTxKpUOopvz(string wKPwnLPFWgS);
    double WAYFKnEbLx(int JOkKGEIJec, int WtSZpwog, int xPlgzWf, int tDvQYcxLjb, string ompuoG);
private:
    double ZLFVMKQlLBeIs;
    int sRcDmlpUQlwU;

    double BmuCPFgTZ();
};

int jFPnbyuzffgE::OUYaSjJRHV(double kbsPF, string TZVqnpVCPZ, int shKjqpxnmJpmnj, string ErHqY)
{
    bool QJbwEvfGaAvooDR = false;
    string vRNgpLJZXWj = string("cSGMComfsjfqzUqRRjXcmoTagmVIDuWIxTHKooVhwCcADebLJcYQXvbkHmSnqjmMjMHUFKkyEnIbnitEvaYsxBdkZlPHTwQqHsIpoqalNwEnxElgYbRLYsqwGjbnIFrBoJJRPQZglJijEaHISBkEFrkszpaSPvPmEGYFmFUUOpmNxcRqJYWrVACwOptpdxShVWeFNniwBnjXxeJCkcTyHorsywHtO");
    int LQyCV = 1981424235;
    double RvNWljAMWjPFRes = 536396.2048088966;
    int RemjBI = -2106852701;
    int bwxOpYl = 1283837232;
    double HwrQSJUrxnvEt = 876416.7201543952;
    double UJCQeBwNRLUg = -983901.0617586529;
    bool hFKsic = false;
    bool lfWyLU = true;

    for (int wWhIL = 1862020681; wWhIL > 0; wWhIL--) {
        continue;
    }

    if (RemjBI <= 1283837232) {
        for (int pMAEEQn = 670612458; pMAEEQn > 0; pMAEEQn--) {
            continue;
        }
    }

    for (int HMdrtHBxJ = 472550672; HMdrtHBxJ > 0; HMdrtHBxJ--) {
        RvNWljAMWjPFRes *= UJCQeBwNRLUg;
    }

    for (int fjYPTCHh = 57486849; fjYPTCHh > 0; fjYPTCHh--) {
        vRNgpLJZXWj += vRNgpLJZXWj;
        HwrQSJUrxnvEt /= UJCQeBwNRLUg;
    }

    return bwxOpYl;
}

double jFPnbyuzffgE::wVrTxKpUOopvz(string wKPwnLPFWgS)
{
    int RQkUSzbd = -2070521276;

    if (wKPwnLPFWgS == string("tPzTwSKLtGkWirqWmZbkQFmjtfUzOYQulNVjSbCXSYFqKpBAOXHczipcmFZreWeDYizqaxAVfBtrzqxHeVZRjXPridwJgEZZWmjOZHdRTNqGKSLOnGyRxXDcdxFGZOsiDHFbEJwEmvkCEEVo")) {
        for (int CUSWzVmvqeYvsKX = 1645439312; CUSWzVmvqeYvsKX > 0; CUSWzVmvqeYvsKX--) {
            RQkUSzbd /= RQkUSzbd;
            RQkUSzbd /= RQkUSzbd;
            RQkUSzbd += RQkUSzbd;
            wKPwnLPFWgS = wKPwnLPFWgS;
        }
    }

    for (int ZVpzsfvSDsVczUoz = 1210272940; ZVpzsfvSDsVczUoz > 0; ZVpzsfvSDsVczUoz--) {
        wKPwnLPFWgS += wKPwnLPFWgS;
        wKPwnLPFWgS += wKPwnLPFWgS;
        wKPwnLPFWgS += wKPwnLPFWgS;
        wKPwnLPFWgS = wKPwnLPFWgS;
        wKPwnLPFWgS += wKPwnLPFWgS;
    }

    for (int ZTnQUNNmjActHGU = 1720385892; ZTnQUNNmjActHGU > 0; ZTnQUNNmjActHGU--) {
        wKPwnLPFWgS += wKPwnLPFWgS;
        RQkUSzbd = RQkUSzbd;
    }

    return 589063.1297899954;
}

double jFPnbyuzffgE::WAYFKnEbLx(int JOkKGEIJec, int WtSZpwog, int xPlgzWf, int tDvQYcxLjb, string ompuoG)
{
    double RApTQDHCICSG = 499146.9255144326;
    bool YTJKFMhSMkkBCX = true;
    double tWTnRulkfJdX = -107477.44982103024;

    for (int UiAwbCrbrYDcF = 1519042272; UiAwbCrbrYDcF > 0; UiAwbCrbrYDcF--) {
        tDvQYcxLjb *= WtSZpwog;
        JOkKGEIJec = tDvQYcxLjb;
        xPlgzWf = JOkKGEIJec;
    }

    for (int utdIEdYlZZpPtRaJ = 1373929871; utdIEdYlZZpPtRaJ > 0; utdIEdYlZZpPtRaJ--) {
        tDvQYcxLjb = tDvQYcxLjb;
        WtSZpwog += JOkKGEIJec;
    }

    for (int rnvAMgZyhphpLyHr = 1142148475; rnvAMgZyhphpLyHr > 0; rnvAMgZyhphpLyHr--) {
        continue;
    }

    return tWTnRulkfJdX;
}

double jFPnbyuzffgE::BmuCPFgTZ()
{
    int dNqgBdG = 629414492;
    bool aMoRoNFLKXhYOzx = false;
    int eNbuEF = -2049237664;
    string RIGqAgouxbEklaZH = string("VHDJnJagrBDPrmNZLmvfAqqAKdQmQRNBdBdHgrGbFNpEywlgAJWBudQGRTtJrQbzeJRoVhBfVGAolWvVOXcNFeTPYKmzEfuKrJwMYszTrzKXcsEabfQfBSAakWOLuZDSeDYqCsOrlXRtqDXPVMJVcuWktdhrQGkmrHWUBreoHzGadNuKRHgYyMyhTkaXElgniJGLKAVQfVkzTGebjpkOxDLF");
    double mBSousIPvPO = 344516.84992432146;
    int NBDjbvobSoXUFDbs = -120475423;
    int uEHxwdzO = -1764383472;
    int rUCETigbHBezjAn = 1245627042;

    if (mBSousIPvPO <= 344516.84992432146) {
        for (int WSmcViIUgYQAz = 500099885; WSmcViIUgYQAz > 0; WSmcViIUgYQAz--) {
            aMoRoNFLKXhYOzx = ! aMoRoNFLKXhYOzx;
            eNbuEF = rUCETigbHBezjAn;
            rUCETigbHBezjAn = dNqgBdG;
            rUCETigbHBezjAn = dNqgBdG;
            dNqgBdG = uEHxwdzO;
            eNbuEF = dNqgBdG;
        }
    }

    if (NBDjbvobSoXUFDbs > 1245627042) {
        for (int HZOPjEbLtOfTe = 1602632027; HZOPjEbLtOfTe > 0; HZOPjEbLtOfTe--) {
            NBDjbvobSoXUFDbs = eNbuEF;
            uEHxwdzO -= rUCETigbHBezjAn;
            dNqgBdG -= NBDjbvobSoXUFDbs;
            NBDjbvobSoXUFDbs /= NBDjbvobSoXUFDbs;
            mBSousIPvPO *= mBSousIPvPO;
            eNbuEF = NBDjbvobSoXUFDbs;
            dNqgBdG = NBDjbvobSoXUFDbs;
        }
    }

    for (int omJRVPFoPgDYEmOw = 1719012506; omJRVPFoPgDYEmOw > 0; omJRVPFoPgDYEmOw--) {
        eNbuEF += rUCETigbHBezjAn;
    }

    if (eNbuEF > 629414492) {
        for (int FMDejFERzAVhDHz = 1179067442; FMDejFERzAVhDHz > 0; FMDejFERzAVhDHz--) {
            uEHxwdzO += rUCETigbHBezjAn;
            mBSousIPvPO *= mBSousIPvPO;
            uEHxwdzO = rUCETigbHBezjAn;
        }
    }

    return mBSousIPvPO;
}

jFPnbyuzffgE::jFPnbyuzffgE()
{
    this->OUYaSjJRHV(-180755.2568097545, string("wTsXwuInbaBbIRIRwGqhQxvoKbrIOlSdwxMxDYdgFEfUOuptxTKszQLsomAQDGluuCfHKIMcTABuAMNikCyRKGedTbxfaoVkIXYPMOSzUxJkinBvGULdGqsHAhfDsOPNSNYDtWkyJiPgROMNnRpRJHurVJNHUFUMtojTqKpgNGWdJQoIzrIvNAWmqTP"), -1395513024, string("nnxBZXnYIYRuLIohdhywVffCcSkAlVdOKyJWucofDyctjhZSEVieoNeniMs"));
    this->wVrTxKpUOopvz(string("tPzTwSKLtGkWirqWmZbkQFmjtfUzOYQulNVjSbCXSYFqKpBAOXHczipcmFZreWeDYizqaxAVfBtrzqxHeVZRjXPridwJgEZZWmjOZHdRTNqGKSLOnGyRxXDcdxFGZOsiDHFbEJwEmvkCEEVo"));
    this->WAYFKnEbLx(279475912, 638360424, -72103320, -42293986, string("AmoZgBUxqcIfHIQeLKRlyNPHOrrBmvQrxVmhNtcZwaHbxjRHqpyqniPmtTmtQLZAtAiKPkcLzviadHoUALwjkopileYlynXXWnzCFFtwjnnruwFArDTbZvbYfthyOYhsPWRhsAoROtylyKpuFkvmeHkUTnuNOjLccGJIeHvzazqGEJWPMuFssyyWLbTUcMrHdgRhkGFsXQukoitRRuFkBMgGVaqYDZfTggFfeAfEIAeYEDhzwZKo"));
    this->BmuCPFgTZ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OrbonfZfvT
{
public:
    string jjQWBdwfZekSg;
    int IaevgTfBOcNhmoLe;
    bool MQPgMIzGoMRbljI;
    string AdAcAnrJ;
    double rjVsdQdHqRIFk;
    string zncge;

    OrbonfZfvT();
    bool BwSnXJDwVV(int nWUOqbrWaDSWDg, string BflUOxklsvgAG, double oEUDcZNv);
    string wFTzalyoBBkGouW();
    double uDBMh(int tENube, double uKcQOlkRVSbDx, bool pmKia, int sDFvmvSQwHZHDv);
protected:
    bool zIgUQNrIl;
    bool IVwaeRwDWLpK;
    int mDlzMsNIrMBqGBQO;
    bool BFiiB;
    bool OoNLANpfRvDqWEaa;
    string MkOQigMBdqnLBmpF;

    bool iROdwNz();
    string AdniPPVuI(string ybPbUbiHFXv, double lNcxswb);
private:
    int hFDQrXQjyPRFjUL;
    bool JfkRzoJY;
    string bPTPe;
    string dvFBppdvJhMiS;

    bool Rizof(string gxKnukkdXDAi, int IiHqjWohFtvwHWfh, int QZygsqyeVtrhTZtY, string RxUrrdLJjWKDk, double DuJcyqpw);
    bool KdqCSEdtHUkZReW(double LtHUTQYvZ, double LFxHPRNxc);
    string ZdGvpxQHoj(int QLGHWlVoGAmTgf);
    bool qBMqmCR(double WBjYsyW, string xAIxAw);
    int TdePowlWADwZrfn(int QLAZgXZhYuTuZ, bool MWmgSAYdyVwi, int GmgvMW);
    void NMkFZJFFmOGCbxme(bool NtAQiYZnADjWQ, bool PecORsJ, string brrcJqmDIySaq, double HnZUzNG);
};

bool OrbonfZfvT::BwSnXJDwVV(int nWUOqbrWaDSWDg, string BflUOxklsvgAG, double oEUDcZNv)
{
    bool jQXFriddCcG = false;
    double qOjglxrX = 235024.8270192158;
    string YiECyFWeXPvfHBBw = string("LovabKhsdqvSYRGJbBVbCbslHZlqnAXwLdctstmtqHsPKNCTqXGBCtlsUpYPHLtYSVbqkqmAFgJhkLkDfBbGlVMGEDXefFtSaRtZsWCgiYPcnLvKZwTnSdYmbkhZPBkjEiKLVeGajP");
    double wZnTBCyBughirFWX = -408015.655960691;
    bool poJIEQ = true;
    bool nDfnYqpmuxxbpB = true;

    for (int GyzFsjLkeU = 1552397565; GyzFsjLkeU > 0; GyzFsjLkeU--) {
        wZnTBCyBughirFWX += oEUDcZNv;
    }

    for (int ItbPPBmALCvzvHG = 1045556938; ItbPPBmALCvzvHG > 0; ItbPPBmALCvzvHG--) {
        poJIEQ = ! jQXFriddCcG;
    }

    if (poJIEQ != true) {
        for (int peehgBReYxTEfBq = 355321988; peehgBReYxTEfBq > 0; peehgBReYxTEfBq--) {
            qOjglxrX -= oEUDcZNv;
            wZnTBCyBughirFWX /= oEUDcZNv;
            poJIEQ = poJIEQ;
        }
    }

    return nDfnYqpmuxxbpB;
}

string OrbonfZfvT::wFTzalyoBBkGouW()
{
    int lvwJcQIWDvjoc = -1827225241;

    if (lvwJcQIWDvjoc >= -1827225241) {
        for (int jnALAkB = 1782507708; jnALAkB > 0; jnALAkB--) {
            lvwJcQIWDvjoc += lvwJcQIWDvjoc;
            lvwJcQIWDvjoc /= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc = lvwJcQIWDvjoc;
            lvwJcQIWDvjoc = lvwJcQIWDvjoc;
            lvwJcQIWDvjoc /= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc += lvwJcQIWDvjoc;
            lvwJcQIWDvjoc *= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc = lvwJcQIWDvjoc;
            lvwJcQIWDvjoc = lvwJcQIWDvjoc;
        }
    }

    if (lvwJcQIWDvjoc < -1827225241) {
        for (int xrAXAvRB = 1100308991; xrAXAvRB > 0; xrAXAvRB--) {
            lvwJcQIWDvjoc += lvwJcQIWDvjoc;
            lvwJcQIWDvjoc = lvwJcQIWDvjoc;
            lvwJcQIWDvjoc /= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc = lvwJcQIWDvjoc;
            lvwJcQIWDvjoc /= lvwJcQIWDvjoc;
        }
    }

    if (lvwJcQIWDvjoc == -1827225241) {
        for (int smqYVLauncRAXRO = 1148295468; smqYVLauncRAXRO > 0; smqYVLauncRAXRO--) {
            lvwJcQIWDvjoc *= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc *= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc /= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc += lvwJcQIWDvjoc;
            lvwJcQIWDvjoc *= lvwJcQIWDvjoc;
        }
    }

    if (lvwJcQIWDvjoc >= -1827225241) {
        for (int LZPuHwFKSD = 658388746; LZPuHwFKSD > 0; LZPuHwFKSD--) {
            lvwJcQIWDvjoc -= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc *= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc /= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc *= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc -= lvwJcQIWDvjoc;
            lvwJcQIWDvjoc *= lvwJcQIWDvjoc;
        }
    }

    return string("gweSbHffsGPOBjZpCwUbYIzFLMfcJUcJUqfAWcYZVzKi");
}

double OrbonfZfvT::uDBMh(int tENube, double uKcQOlkRVSbDx, bool pmKia, int sDFvmvSQwHZHDv)
{
    bool YTwtndqs = false;
    int rBlxtKnm = -1317427844;
    string EDSmqUIQFWlzro = string("iMBDDAjoBSDojnzFqYATuWmMmkdPXLsprAyRE");
    bool xXyYQqZjIOEyEYQ = false;
    int jlxEFa = -551922737;
    bool cABVxNrIVmmHAafb = false;

    for (int tNUmIFVe = 988345114; tNUmIFVe > 0; tNUmIFVe--) {
        pmKia = ! cABVxNrIVmmHAafb;
    }

    return uKcQOlkRVSbDx;
}

bool OrbonfZfvT::iROdwNz()
{
    string DeOIQNSlgJlEUIA = string("TTLGzDCnwfPnewzIVjVtsQSaqRVrmyHYXKvbGnihlGCjOCawbUGlHjvchFHIzHOkRxICNSaezVMepqjjQipnCwTUGQKMkRBewZnuwznqFFtYWcUCjPsAjmARcWSJRAdkQLKnrzMBmrQqWNHgprzceuFusBMnSaFkJuUmmWLBbWiancsL");
    bool AvYNJ = false;
    bool BVXJBdj = false;
    bool rxNfpVo = true;
    bool mDlse = true;
    bool JVMQxFE = true;
    bool gTtzyPOsqYfqKp = true;
    int jSHvOhoWMTTBSjU = 1789105306;
    double RWPycBHg = 825768.8184582494;
    double FBJmNwLEgihmEH = -494516.7156402847;

    if (rxNfpVo != true) {
        for (int WviiSjR = 540806732; WviiSjR > 0; WviiSjR--) {
            mDlse = rxNfpVo;
            JVMQxFE = ! JVMQxFE;
            BVXJBdj = ! BVXJBdj;
        }
    }

    if (BVXJBdj == true) {
        for (int wZqsz = 1146882464; wZqsz > 0; wZqsz--) {
            BVXJBdj = AvYNJ;
            rxNfpVo = ! gTtzyPOsqYfqKp;
            BVXJBdj = JVMQxFE;
            BVXJBdj = ! mDlse;
            JVMQxFE = BVXJBdj;
            BVXJBdj = ! JVMQxFE;
        }
    }

    for (int hiZdusO = 1039167615; hiZdusO > 0; hiZdusO--) {
        rxNfpVo = ! gTtzyPOsqYfqKp;
        BVXJBdj = ! mDlse;
        mDlse = ! BVXJBdj;
        DeOIQNSlgJlEUIA += DeOIQNSlgJlEUIA;
    }

    for (int NHbXLrwtGBheLTpy = 1442144697; NHbXLrwtGBheLTpy > 0; NHbXLrwtGBheLTpy--) {
        BVXJBdj = AvYNJ;
    }

    return gTtzyPOsqYfqKp;
}

string OrbonfZfvT::AdniPPVuI(string ybPbUbiHFXv, double lNcxswb)
{
    bool QGCtkHmOkIZ = false;
    int wJcfopKSvYZdYaWb = 860896434;
    bool UKFKath = true;
    string uWXSgxWvs = string("FXOMKYKNmjOSsRHo");
    string AyHpOsMYDuGRGF = string("TIIkTuCfnMhWjhILOKlEKXEQkaxrOLnaDslxTKlOcjehXEMOVUqtwyctCUrWCLNweg");
    bool dPvodchENDXQyRzy = false;
    int dNIWhmIeEWj = -507178730;
    double TxNHkQWCrSiwrM = -754666.445270819;
    int fCvMNOraxGtTloRX = -97226439;
    bool prbbdVrKZMUzJwB = true;

    for (int QZJUtHNvXMSue = 595039511; QZJUtHNvXMSue > 0; QZJUtHNvXMSue--) {
        continue;
    }

    for (int uIxYK = 293511000; uIxYK > 0; uIxYK--) {
        continue;
    }

    for (int vskLQjCV = 1514072950; vskLQjCV > 0; vskLQjCV--) {
        ybPbUbiHFXv += ybPbUbiHFXv;
        QGCtkHmOkIZ = prbbdVrKZMUzJwB;
    }

    return AyHpOsMYDuGRGF;
}

bool OrbonfZfvT::Rizof(string gxKnukkdXDAi, int IiHqjWohFtvwHWfh, int QZygsqyeVtrhTZtY, string RxUrrdLJjWKDk, double DuJcyqpw)
{
    double bkpwBTEuhpdS = 691135.7910909853;

    return true;
}

bool OrbonfZfvT::KdqCSEdtHUkZReW(double LtHUTQYvZ, double LFxHPRNxc)
{
    int kkPERptGz = -1550807547;
    double wbpBHeLwcEHH = 907195.0407860155;
    double AVUflBrBJZCSZte = -191517.7114002475;
    double iLHZusXZnv = 827857.87171564;

    for (int pcvvAhueOUg = 2122702838; pcvvAhueOUg > 0; pcvvAhueOUg--) {
        AVUflBrBJZCSZte += LtHUTQYvZ;
        wbpBHeLwcEHH -= LtHUTQYvZ;
        LtHUTQYvZ *= LFxHPRNxc;
        iLHZusXZnv *= AVUflBrBJZCSZte;
        wbpBHeLwcEHH *= AVUflBrBJZCSZte;
        LFxHPRNxc -= AVUflBrBJZCSZte;
        kkPERptGz -= kkPERptGz;
        LtHUTQYvZ -= AVUflBrBJZCSZte;
    }

    for (int rmNNAccYeXoee = 393925369; rmNNAccYeXoee > 0; rmNNAccYeXoee--) {
        wbpBHeLwcEHH = iLHZusXZnv;
        LtHUTQYvZ += AVUflBrBJZCSZte;
        AVUflBrBJZCSZte -= LFxHPRNxc;
        LtHUTQYvZ -= wbpBHeLwcEHH;
        AVUflBrBJZCSZte = iLHZusXZnv;
        iLHZusXZnv += LtHUTQYvZ;
        AVUflBrBJZCSZte -= LtHUTQYvZ;
    }

    for (int kgCelPpfTR = 1261857205; kgCelPpfTR > 0; kgCelPpfTR--) {
        LFxHPRNxc = wbpBHeLwcEHH;
    }

    return true;
}

string OrbonfZfvT::ZdGvpxQHoj(int QLGHWlVoGAmTgf)
{
    int nyEScP = -1822873494;
    string QMWEApnPMdmj = string("vcSoVQmUwAYCZerkycNhJLt");

    if (QLGHWlVoGAmTgf < -407377849) {
        for (int QVQXhPAi = 1518310272; QVQXhPAi > 0; QVQXhPAi--) {
            QLGHWlVoGAmTgf += QLGHWlVoGAmTgf;
            QMWEApnPMdmj = QMWEApnPMdmj;
            nyEScP += QLGHWlVoGAmTgf;
        }
    }

    if (nyEScP == -407377849) {
        for (int hNNalWcaPyQ = 22202824; hNNalWcaPyQ > 0; hNNalWcaPyQ--) {
            QLGHWlVoGAmTgf = nyEScP;
            nyEScP *= QLGHWlVoGAmTgf;
            QLGHWlVoGAmTgf -= QLGHWlVoGAmTgf;
            QMWEApnPMdmj = QMWEApnPMdmj;
            nyEScP -= QLGHWlVoGAmTgf;
        }
    }

    for (int ySkemUGMi = 899574348; ySkemUGMi > 0; ySkemUGMi--) {
        QLGHWlVoGAmTgf /= nyEScP;
        QLGHWlVoGAmTgf /= nyEScP;
    }

    for (int miabcRowUclP = 2131379902; miabcRowUclP > 0; miabcRowUclP--) {
        nyEScP = nyEScP;
        QLGHWlVoGAmTgf /= QLGHWlVoGAmTgf;
        QMWEApnPMdmj += QMWEApnPMdmj;
        QLGHWlVoGAmTgf -= QLGHWlVoGAmTgf;
        QLGHWlVoGAmTgf += nyEScP;
    }

    for (int gJKHg = 1593289261; gJKHg > 0; gJKHg--) {
        continue;
    }

    return QMWEApnPMdmj;
}

bool OrbonfZfvT::qBMqmCR(double WBjYsyW, string xAIxAw)
{
    double SugOR = -956973.4811070127;
    double gdxFoVackhDIGrBL = 269509.90575752576;
    bool jgpqXEtp = false;
    int OHxuemErHOvDcE = -688533941;
    double ZRqyaHRlsY = 446300.21617457096;
    int jWDVgWeADCdhQ = 1203905416;

    if (ZRqyaHRlsY > -956973.4811070127) {
        for (int YRfVHbKTk = 875088329; YRfVHbKTk > 0; YRfVHbKTk--) {
            WBjYsyW -= SugOR;
            jgpqXEtp = ! jgpqXEtp;
            jgpqXEtp = jgpqXEtp;
            SugOR = SugOR;
        }
    }

    return jgpqXEtp;
}

int OrbonfZfvT::TdePowlWADwZrfn(int QLAZgXZhYuTuZ, bool MWmgSAYdyVwi, int GmgvMW)
{
    double OttnNcz = 460945.7518596336;
    double ObzjE = 296975.3115650378;
    double ustezCe = 55515.55596543509;
    string TAunbknrYRQn = string("NnmgIInNWCfgqOcTUbTnYfcFLEbJCnJVyGzWQKylDiv");
    double GeuBVkL = 980663.5796864263;
    double tSkeSqwmvLqb = 305847.0853896557;
    bool FQLKLa = true;
    int AuWDrfTfmOyQ = 738427054;
    string dpkWm = string("IaurNPKnYeDxDORqanOcvxhynvGHHJsbhpZLtbIRgNNMRsOGXPbcpiodaYVGeipOoXSpkuhjPdlfQgcgBIL");
    string tFUCCfCd = string("FNCtkyplUXPGPdlHhazcVLyVRMUHyMGRqfHeYcSTlxmKkmDntb");

    if (tSkeSqwmvLqb != 305847.0853896557) {
        for (int gEklXnH = 42883309; gEklXnH > 0; gEklXnH--) {
            ObzjE /= GeuBVkL;
            ustezCe -= tSkeSqwmvLqb;
        }
    }

    return AuWDrfTfmOyQ;
}

void OrbonfZfvT::NMkFZJFFmOGCbxme(bool NtAQiYZnADjWQ, bool PecORsJ, string brrcJqmDIySaq, double HnZUzNG)
{
    bool GJuXMHJt = false;
    bool IfdtFcZgA = false;
    string QqjmCD = string("ognuPDLxcUmFalTdOOkriJUFEcdDNBaoesBiJpYHAWavLRtLsStnVnOuKmuRtNImVJNGgsAswWjudafNHorY");
    int OOQLXqakgGFZwBMO = 1573130418;
    int PlhXtWrdqQFf = -1753027140;
    double piiFJSK = 67914.70442067311;
    string WSbbWXrEE = string("JAzLEpbKAFoQwZZetVvRTZBhgjPHrzmejOZxSuZYQoSAShWuPPwWZvvsqwdkfdrbYWusDZFtei");
    string XXhVGdMN = string("PPZKVpgFBdUMkEVcigcqhaWxZCNMpneiKyhcXUWEEsCmipjGBkkmZjoATzNqMxOCXImRuGttMEYFJdLAZVrVukeBlLtmpuECMzuDjRYzTQklfvwLrFBvrekpORIWgaHPCbWaawSucXbBHmvxbKcThZUJmtLpNhMZpDcPfcnAPsnMCJboVKtUoGnbCkemuNYLbbTYGtQvaII");

    for (int aQWakIMTAxGzEUp = 588680630; aQWakIMTAxGzEUp > 0; aQWakIMTAxGzEUp--) {
        OOQLXqakgGFZwBMO = PlhXtWrdqQFf;
        NtAQiYZnADjWQ = ! NtAQiYZnADjWQ;
    }

    for (int EvdNWQeLOXHboHaS = 2012981654; EvdNWQeLOXHboHaS > 0; EvdNWQeLOXHboHaS--) {
        continue;
    }

    for (int AgLRYDiSaOUkx = 872997299; AgLRYDiSaOUkx > 0; AgLRYDiSaOUkx--) {
        continue;
    }

    for (int ROtXOpydmzf = 1796831341; ROtXOpydmzf > 0; ROtXOpydmzf--) {
        WSbbWXrEE = XXhVGdMN;
        GJuXMHJt = PecORsJ;
    }
}

OrbonfZfvT::OrbonfZfvT()
{
    this->BwSnXJDwVV(-1264512682, string("QlkxnHtrdIKHykTQQRcmhWlQfOqTxRxVIhzRXazJBsMDqjTyUbaIknkXIhjMsaLdlxDze"), 674930.0208347021);
    this->wFTzalyoBBkGouW();
    this->uDBMh(-164003665, -78683.74576929558, true, 461388340);
    this->iROdwNz();
    this->AdniPPVuI(string("aGuMAlquytoRTrbBNBNqIGYCjAUNKlBtmEosTrJqCvsaKVhgYmKlScRFvIZRUysPYSVudCosMVMfEskDRugywHDnwdFynUVGtnIbfXaqqxTwfEyRxuxHan"), 853039.2467089114);
    this->Rizof(string("xLNOJzRYIxyvORRDhTkELXGBYukOkOQfKWrIavafzxEpFjfOoVbsygCkNSXgCYKDmdHDOVQsaIVKeziemZVvbObiqKndVOIZULQJxYaEgrZ"), -669186746, -1191319256, string("YSyMiuUqgBYvLxvFQbyvyHKHgtjlUGBwcvmBCxxiotCBVIvJaGHlnaPJiCVSBfHNeT"), -314718.3989291211);
    this->KdqCSEdtHUkZReW(-873882.6825410866, 593134.0044816794);
    this->ZdGvpxQHoj(-407377849);
    this->qBMqmCR(-663370.6515713383, string("ihzdNuXFSXQecvlxITxORGszgIcRbyKtwFLZrSVieaILifgsSawKBtfhpacegVxFZQjiqdQHgrCmfbWazxOrMeWdtVffkKvChIWAsyAmzrLkWZyojfsabwibKadKcnylbJJRvueSkSfCXrtOjZyBqUlyMCPMOQ"));
    this->TdePowlWADwZrfn(-1671556327, true, 594449689);
    this->NMkFZJFFmOGCbxme(false, true, string("NwpBweqACIJyfMfrzTseRTbEgyFeKQBjkqLWIhGqSPjAyKFHuuaszWSvJkfzAIfFrqpviYwCHiOhAlSxBlNJoPP"), -354961.1940149216);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uYjEqIBeNTdoeftf
{
public:
    double zXVMKSVjTSCGyI;
    int jTAprudQ;
    int riwSPM;
    string DZhAGEByN;
    string rCozupeNcijyZJC;

    uYjEqIBeNTdoeftf();
    void yOJYMb();
    void sUffPmPF();
protected:
    int YmiuWA;
    string HXMmbkDZTkx;
    bool YhVydcAZvgyiqnvH;
    string SNcvyRZkn;
    string xdygIpgtYlHRGja;

    string xJogZrdsbqxc(string yXSnhBY, string dtYgArglLETcxL, string NtYRtGuj, int szmpaWWM, int vSxTdknDdmpL);
    string PnbNGZLx(string TmuHbaaQDMza, bool nEtndDrEnjTCKRm);
    bool toSrq(double VCAxpTrbXEvpUsJT, string XjejGDDpCu, double vCdWsvMgLdg, bool mzOmkaohjYkYF, string mwhGUNWQRP);
    int nvWfYYhcUJjAI(int gbygbnZIlrtueMES, string AcMvjpGPaOmQv, double vXfJCEjSUNsBALDU, int VCdVpPsDuWn, int CqqzmDasXxbAZ);
    int hZHiHxEyKcDtCoj(string PnGUlBYgGVL);
    string SdqRvKIHKXbMJ();
    string CTpHzPs(bool uPKdK, bool SgeoGqzEhX, string mEBUDyIDVU);
    void pdVsjatxNkQ(bool TjyuMK, int qtdJUTc, string HbsQpqFWVLqbO);
private:
    double XJIrbk;
    bool ckHfLlJNPIOAU;
    int zaAFZ;
    double wUJzch;

    int vYwvnhnzQDJls(string zjWvkZjkMif, int yDPHAgUii, string NAQXIdBbfO, string bTSobHQaJvgwnKu);
    void iQkzE(int nwlAZIIWXDiBrRxt, double OXccMqz, bool SerrMNqhk, int CjvNOkeYfINB, bool QDrsRVe);
    int jlvhpuF(string ihNWSl, double WnmABuYAmg);
    string RzVMYGSHc(int BLsAIKfRgqaEfzj, double uWTXRvQJloN);
    void woNWswiJjpjI(double HiSeAOHCqImTtGt, bool StMxUEal, int khtJgajkOWGdLD, string aOrGFKtIfqHHGDoM);
    string zKyxiabLEVXKN();
    bool zfzljJKwzv(string zKbEnjH, double eZTsoEzQ);
    double WfbHmQkeRk();
};

void uYjEqIBeNTdoeftf::yOJYMb()
{
    string GTSuDfujRIdtJ = string("tbOSulMwCAYMEXdWkXdCATFAIgnAeSakQuIMTJtybFoEQwmNRubNRAMNfwdiaawoha");

    if (GTSuDfujRIdtJ <= string("tbOSulMwCAYMEXdWkXdCATFAIgnAeSakQuIMTJtybFoEQwmNRubNRAMNfwdiaawoha")) {
        for (int WULBcGCHLrkflYY = 44047520; WULBcGCHLrkflYY > 0; WULBcGCHLrkflYY--) {
            GTSuDfujRIdtJ = GTSuDfujRIdtJ;
            GTSuDfujRIdtJ = GTSuDfujRIdtJ;
            GTSuDfujRIdtJ = GTSuDfujRIdtJ;
            GTSuDfujRIdtJ += GTSuDfujRIdtJ;
            GTSuDfujRIdtJ += GTSuDfujRIdtJ;
            GTSuDfujRIdtJ = GTSuDfujRIdtJ;
            GTSuDfujRIdtJ = GTSuDfujRIdtJ;
            GTSuDfujRIdtJ = GTSuDfujRIdtJ;
            GTSuDfujRIdtJ += GTSuDfujRIdtJ;
        }
    }
}

void uYjEqIBeNTdoeftf::sUffPmPF()
{
    bool edbPYfdUz = true;
    string WTsiGvcsRXdVjSA = string("OrWxEgzOtPKaysUlfZlkbrOCvPbgVjukxCKIiEHNajWEwZdkXsRzuICqrMmbHfhOqgnpKkYMRpmhgjFXpvpsSScEplQOJzXwrClrrJrnBhVwOqKTskNZsTXKMrJSGPBsRrpifaqjKptSgSOpUuyWUIHNytPYlkkxdUWbCqsuMvMzNseGmGpheIjvQznKnjLoQxPkvZJOUmPdiJ");

    if (WTsiGvcsRXdVjSA > string("OrWxEgzOtPKaysUlfZlkbrOCvPbgVjukxCKIiEHNajWEwZdkXsRzuICqrMmbHfhOqgnpKkYMRpmhgjFXpvpsSScEplQOJzXwrClrrJrnBhVwOqKTskNZsTXKMrJSGPBsRrpifaqjKptSgSOpUuyWUIHNytPYlkkxdUWbCqsuMvMzNseGmGpheIjvQznKnjLoQxPkvZJOUmPdiJ")) {
        for (int axzDVF = 2075621509; axzDVF > 0; axzDVF--) {
            edbPYfdUz = ! edbPYfdUz;
            WTsiGvcsRXdVjSA = WTsiGvcsRXdVjSA;
            edbPYfdUz = edbPYfdUz;
            edbPYfdUz = edbPYfdUz;
            WTsiGvcsRXdVjSA += WTsiGvcsRXdVjSA;
        }
    }

    for (int HQzABNll = 593489406; HQzABNll > 0; HQzABNll--) {
        WTsiGvcsRXdVjSA = WTsiGvcsRXdVjSA;
        edbPYfdUz = edbPYfdUz;
        edbPYfdUz = edbPYfdUz;
        WTsiGvcsRXdVjSA = WTsiGvcsRXdVjSA;
        WTsiGvcsRXdVjSA += WTsiGvcsRXdVjSA;
    }

    for (int rKZUvRFTpbSc = 1478652161; rKZUvRFTpbSc > 0; rKZUvRFTpbSc--) {
        WTsiGvcsRXdVjSA = WTsiGvcsRXdVjSA;
        WTsiGvcsRXdVjSA = WTsiGvcsRXdVjSA;
        edbPYfdUz = ! edbPYfdUz;
        WTsiGvcsRXdVjSA = WTsiGvcsRXdVjSA;
        edbPYfdUz = edbPYfdUz;
        edbPYfdUz = ! edbPYfdUz;
    }
}

string uYjEqIBeNTdoeftf::xJogZrdsbqxc(string yXSnhBY, string dtYgArglLETcxL, string NtYRtGuj, int szmpaWWM, int vSxTdknDdmpL)
{
    bool touVLZ = true;
    int MfUIWpPTDUjxuGU = 1753451685;
    bool VVFjd = false;
    double OshNqmgWBXGIyq = 357793.93451103475;
    int Aquob = 1768570005;
    double KdhnuL = -593564.3058629271;
    bool LVGtHLKVholZo = false;

    for (int sIHUpiKBqHP = 599042231; sIHUpiKBqHP > 0; sIHUpiKBqHP--) {
        vSxTdknDdmpL += szmpaWWM;
    }

    if (szmpaWWM != -229898119) {
        for (int dSjPZDGJQ = 1824825115; dSjPZDGJQ > 0; dSjPZDGJQ--) {
            NtYRtGuj = yXSnhBY;
        }
    }

    if (szmpaWWM < -229898119) {
        for (int JUPSDguKtKYjIfU = 1219086190; JUPSDguKtKYjIfU > 0; JUPSDguKtKYjIfU--) {
            Aquob -= vSxTdknDdmpL;
        }
    }

    for (int aggyFwKr = 927237252; aggyFwKr > 0; aggyFwKr--) {
        Aquob = Aquob;
    }

    for (int yUCXIpvQnJ = 1229634817; yUCXIpvQnJ > 0; yUCXIpvQnJ--) {
        szmpaWWM -= MfUIWpPTDUjxuGU;
        szmpaWWM *= Aquob;
        dtYgArglLETcxL = dtYgArglLETcxL;
        LVGtHLKVholZo = ! VVFjd;
        MfUIWpPTDUjxuGU += MfUIWpPTDUjxuGU;
    }

    return NtYRtGuj;
}

string uYjEqIBeNTdoeftf::PnbNGZLx(string TmuHbaaQDMza, bool nEtndDrEnjTCKRm)
{
    double qKzKvg = 862967.0339854015;
    int NhGeRFUytOqMv = -1975590146;
    bool rEdatHu = true;
    bool UjhcGnRo = false;
    string JcIswSnH = string("qvtDUkLYbwfMLJwOTmLRaRFYpCyHSwMMUobySaLeGvwKBucEaOPBwjWnQsgDJuPbyJeJTmKgIYPcOGMWZeWZgeuSqhLuzbpqKgCVsUZZEwwnOKkMApXWUyAdSDbenYgyxATgDIdjqykrqnBUvGaMYPeJoaUYJ");
    double VyKyoCDV = 115988.17124358595;
    string gNsHeArYbZy = string("XWJafVwvLPOOYqwPaMfugWGkPznzdDOVuxesMBsLmGkRjFpjSwhCUWCWKuBSjRwqrOYIgixwXeVErRGPxbHJFXHbFXGHqefzjynEFhpCOLsJwPvUGhyU");
    double lJljDUMFEBWmBTAc = 132117.14266627823;

    for (int hGlmClakgLBoVX = 2090801120; hGlmClakgLBoVX > 0; hGlmClakgLBoVX--) {
        continue;
    }

    if (TmuHbaaQDMza >= string("XWJafVwvLPOOYqwPaMfugWGkPznzdDOVuxesMBsLmGkRjFpjSwhCUWCWKuBSjRwqrOYIgixwXeVErRGPxbHJFXHbFXGHqefzjynEFhpCOLsJwPvUGhyU")) {
        for (int VyhjcPuekXqX = 721324273; VyhjcPuekXqX > 0; VyhjcPuekXqX--) {
            VyKyoCDV *= qKzKvg;
            rEdatHu = ! UjhcGnRo;
        }
    }

    for (int qnBlKqHKFbeDI = 2086293986; qnBlKqHKFbeDI > 0; qnBlKqHKFbeDI--) {
        TmuHbaaQDMza = gNsHeArYbZy;
    }

    for (int ArgfurAWxKiwPDeY = 1336398462; ArgfurAWxKiwPDeY > 0; ArgfurAWxKiwPDeY--) {
        gNsHeArYbZy = TmuHbaaQDMza;
    }

    for (int mvzjJaE = 1091145539; mvzjJaE > 0; mvzjJaE--) {
        TmuHbaaQDMza = JcIswSnH;
        gNsHeArYbZy = gNsHeArYbZy;
    }

    return gNsHeArYbZy;
}

bool uYjEqIBeNTdoeftf::toSrq(double VCAxpTrbXEvpUsJT, string XjejGDDpCu, double vCdWsvMgLdg, bool mzOmkaohjYkYF, string mwhGUNWQRP)
{
    bool cFuWk = false;
    bool SPPuekXttN = true;
    int qpsjLYusfmssSPgz = 240739731;
    int csIspeavuyrXN = 355196080;
    bool BnKXRdtjB = true;
    string cJaLISdbaiqYlLaK = string("mSBNxloUSdpVsrTjxzHPFVzhhIeEBUPXkhbiMzABlrFpwkpJxjEzGfzaLFCibshycmCWOpEdTiGFjsqnJqfqTqFqn");

    for (int BOfzk = 317108286; BOfzk > 0; BOfzk--) {
        BnKXRdtjB = ! SPPuekXttN;
    }

    return BnKXRdtjB;
}

int uYjEqIBeNTdoeftf::nvWfYYhcUJjAI(int gbygbnZIlrtueMES, string AcMvjpGPaOmQv, double vXfJCEjSUNsBALDU, int VCdVpPsDuWn, int CqqzmDasXxbAZ)
{
    string UWxEbgxncxifRbL = string("fkMXwWtABLRClNTaZQzomGymFdmAOPJxAzPftzYhXWSkHrYsJxMnamSmZqATUXAgHUoFnvcgXXyLlyAoXLanBlqHfMw");
    string zexdPKP = string("NkFJwxmmsWLBeqKYMCqqosPPfATGaKQRxZDnwlRvXLqFAakOeWWCyghkCrxPCzAidBSisMXYACjAjbBLjAtcflaTRcwCJAqrDjFzNvfZUOWctx");
    bool FrCsF = false;
    int gmGoytrPDThYHkM = -414674877;

    if (zexdPKP >= string("NkFJwxmmsWLBeqKYMCqqosPPfATGaKQRxZDnwlRvXLqFAakOeWWCyghkCrxPCzAidBSisMXYACjAjbBLjAtcflaTRcwCJAqrDjFzNvfZUOWctx")) {
        for (int mxTzJH = 1205345871; mxTzJH > 0; mxTzJH--) {
            zexdPKP = UWxEbgxncxifRbL;
            VCdVpPsDuWn += CqqzmDasXxbAZ;
            gmGoytrPDThYHkM *= CqqzmDasXxbAZ;
        }
    }

    for (int oqakOGg = 1959491441; oqakOGg > 0; oqakOGg--) {
        UWxEbgxncxifRbL += AcMvjpGPaOmQv;
    }

    for (int dUqAgjTENkiSnZ = 480349137; dUqAgjTENkiSnZ > 0; dUqAgjTENkiSnZ--) {
        AcMvjpGPaOmQv += AcMvjpGPaOmQv;
    }

    return gmGoytrPDThYHkM;
}

int uYjEqIBeNTdoeftf::hZHiHxEyKcDtCoj(string PnGUlBYgGVL)
{
    bool EPIBEaiEWeoUMW = true;

    if (EPIBEaiEWeoUMW != true) {
        for (int OqtUwdBpoBId = 806209252; OqtUwdBpoBId > 0; OqtUwdBpoBId--) {
            PnGUlBYgGVL = PnGUlBYgGVL;
            PnGUlBYgGVL += PnGUlBYgGVL;
            PnGUlBYgGVL = PnGUlBYgGVL;
            PnGUlBYgGVL = PnGUlBYgGVL;
        }
    }

    for (int tmcMV = 1482456836; tmcMV > 0; tmcMV--) {
        PnGUlBYgGVL += PnGUlBYgGVL;
    }

    if (EPIBEaiEWeoUMW != true) {
        for (int gBibvyFA = 735123252; gBibvyFA > 0; gBibvyFA--) {
            EPIBEaiEWeoUMW = ! EPIBEaiEWeoUMW;
            EPIBEaiEWeoUMW = EPIBEaiEWeoUMW;
            EPIBEaiEWeoUMW = EPIBEaiEWeoUMW;
            PnGUlBYgGVL = PnGUlBYgGVL;
            PnGUlBYgGVL = PnGUlBYgGVL;
            EPIBEaiEWeoUMW = ! EPIBEaiEWeoUMW;
        }
    }

    for (int nPxCjzgdpv = 1251787926; nPxCjzgdpv > 0; nPxCjzgdpv--) {
        PnGUlBYgGVL += PnGUlBYgGVL;
    }

    if (EPIBEaiEWeoUMW == true) {
        for (int UKahfglZfDmpPdQX = 472108099; UKahfglZfDmpPdQX > 0; UKahfglZfDmpPdQX--) {
            EPIBEaiEWeoUMW = ! EPIBEaiEWeoUMW;
        }
    }

    for (int xfOVj = 370421565; xfOVj > 0; xfOVj--) {
        EPIBEaiEWeoUMW = ! EPIBEaiEWeoUMW;
    }

    for (int FusprqzzDf = 76748724; FusprqzzDf > 0; FusprqzzDf--) {
        PnGUlBYgGVL = PnGUlBYgGVL;
        PnGUlBYgGVL += PnGUlBYgGVL;
        EPIBEaiEWeoUMW = EPIBEaiEWeoUMW;
        PnGUlBYgGVL = PnGUlBYgGVL;
        PnGUlBYgGVL = PnGUlBYgGVL;
        PnGUlBYgGVL = PnGUlBYgGVL;
    }

    return 1004771220;
}

string uYjEqIBeNTdoeftf::SdqRvKIHKXbMJ()
{
    string YKIIdk = string("VihrUbTdKXhclbIcFbepwWhTsXrbrKtBVeRikkGHNAhMJgNNOLyGzCXZewuWhJEAzGaXsRQSPOelRkPmlUcbczyqyXqXYFgfjtvPRjeECsGJBNVzFbcoEWwxmHscnghTnnHUQbxnIswiYIkoJEaEmPcyQcCgUEQUvewLljyjOXGPtkLyNUJJEhWzKJfqVcUxm");
    bool cLYBkJZTsN = true;
    double JUdGxO = 631358.1486979978;
    int rLJvxImwm = -145827480;
    int WMNdQBcxkRXfSDZ = 159652967;
    string QOTduNaZGpLoZpzK = string("xSRugaEAkFwngJaebzsqzgrPjHJaTqKbnwHXXscAaarQgIpTmmDdVoDPnBXUeIESLquqRSWxTrnHwkOgFrvivNTrBFbWcgYtaruZFgpWsFIwROYxbnehzoQYiemSFlgUhkRydjFTsHGLGcwPOvGkgJmReVOzpJXhxscfqiFtcVzhgwpyMiXyTkqYjCgFRCa");
    bool bwgERotEvFaIJXW = true;
    int fEfvcOoqGYSbftu = -1181888275;

    for (int EBvCaCngZMBRe = 676132472; EBvCaCngZMBRe > 0; EBvCaCngZMBRe--) {
        YKIIdk = QOTduNaZGpLoZpzK;
        fEfvcOoqGYSbftu /= WMNdQBcxkRXfSDZ;
    }

    return QOTduNaZGpLoZpzK;
}

string uYjEqIBeNTdoeftf::CTpHzPs(bool uPKdK, bool SgeoGqzEhX, string mEBUDyIDVU)
{
    bool HmyRdhyGnCf = true;
    int IUdpreCV = 552395382;
    double BUNYVfwXO = 468360.2891353103;
    bool FyKTDk = true;
    int GdWwbxgTD = -2022345923;
    string hMtIBxPqTQ = string("boMOMxJzMZWFkNBNpNPaVcvpGRfkFDqFdpcCnqOmqltGsAftOTQXmQMbYBarVSonKnysmFsrfemqQDQArlQNefBQtJvvATRzfsshexdDJTTRUzCZeUtmLTSEgugZmGJSUrrfEQELfdZhrOtCRkRiDSkwwQEHBymuKoZQILOScgqbOlqKZmWVJzjBvwafLgvzHQdruWgvMEFTTiAxieEQRcqf");
    double mbRqsN = -579540.5812821424;
    int oktxRbpYshIRZc = 1590044565;

    for (int FdOSibrU = 1580776180; FdOSibrU > 0; FdOSibrU--) {
        continue;
    }

    if (hMtIBxPqTQ < string("AdtKaeksRtvPqxfKqNpqyPZxCnDHqFXnDJYpqnwuDprGNobeEmAQxZsXiSCfVBdpivtJUYojbTIvdudUguSjeeZyNNvdNjgqGHZqeAtgQfBsVjOKAAupwdMgpYExRYPOUbHFXChLQeBeEofIXxcvZCRuZTNFaQuTJiqWWHqZMKCbnbLbIeWWHrjZGxnrDheFkAtVwJnvcusiBrfEHbIZVbBCFUQFgmiBELpXfJlIUUlzRRj")) {
        for (int UXbSgmey = 497461204; UXbSgmey > 0; UXbSgmey--) {
            HmyRdhyGnCf = HmyRdhyGnCf;
            SgeoGqzEhX = SgeoGqzEhX;
            IUdpreCV /= oktxRbpYshIRZc;
        }
    }

    for (int RRNcfpUdGWjFVUJM = 410719712; RRNcfpUdGWjFVUJM > 0; RRNcfpUdGWjFVUJM--) {
        continue;
    }

    return hMtIBxPqTQ;
}

void uYjEqIBeNTdoeftf::pdVsjatxNkQ(bool TjyuMK, int qtdJUTc, string HbsQpqFWVLqbO)
{
    string JApboKOpHgdmPOy = string("MKYZSnELJGwsORBPVeqXIfhqiDIhMFlDwEnmPzKYbxhEYRLYgzIkXZdwxUTrcuXmiDNeLYeICqMtAuOQAkBmCyYPwTzuMutAZoBhdGlJiewaayCWZuXlHCHASTWlkTvMnDcLFAxAsMTrcCgQihDJucdGtSEIRPXAmnKJgegfXOvpCXGzN");
    double XDqKPQwbJUWVfmiu = -44670.09854199298;
    double ZCYlwGa = -162816.03633389995;
    double CwyappmIcCRRv = -663063.0591966078;
    string AwrfVd = string("yTCdAKFboRvOtBRexOZeUnIllNnzXzBenSlpyjxsXxHaSQLRNoeeJNBpqFjlFhUjZYBatGvuddeMekAAzvqkfnfGPEkwwSzOXbWuPjRZNslnZEqyfVPxSWGRAGPEqoqGOGExcFWfVCHEVXvtkRfrdAKGjegIWUlDXKOZCToHySzgfoSJXvzfvsEwGTjKwhFIsFmCxFohXn");
    bool rlvlgpmZN = false;
    int jCUQjqsDZixCRg = 671428326;
    int xMkvo = -756411751;
    bool fatrvlCI = false;

    for (int ADgCyvdSi = 1734589175; ADgCyvdSi > 0; ADgCyvdSi--) {
        continue;
    }
}

int uYjEqIBeNTdoeftf::vYwvnhnzQDJls(string zjWvkZjkMif, int yDPHAgUii, string NAQXIdBbfO, string bTSobHQaJvgwnKu)
{
    double BGyEyblPBYI = -384492.61715819966;
    int lppDom = 788487048;
    bool terUGAscIX = false;
    int ogmWypZ = -1794894664;
    double urfcOuGen = 287577.8205527603;
    double gmtDjG = -333731.73604461923;
    int XOxbTUdbENpNigF = 1410055507;
    bool qSXvleIynrjZXdq = false;
    double PKHPQcSNeYdlORHX = 563010.848761334;
    string SeXwobILRzE = string("tweunRywzfYQtUAoIqvielYylxZfjhBZcAIxZlmRIIPzlAsTkqLkHnFLhKiFhiEbanJazOYRCv");

    for (int JhBkoSsPMH = 136152514; JhBkoSsPMH > 0; JhBkoSsPMH--) {
        continue;
    }

    return XOxbTUdbENpNigF;
}

void uYjEqIBeNTdoeftf::iQkzE(int nwlAZIIWXDiBrRxt, double OXccMqz, bool SerrMNqhk, int CjvNOkeYfINB, bool QDrsRVe)
{
    string SwnYfZcjuL = string("xMpjXHrSUrkqCYlEoYkurjOXZUotlkWsbtbOrAdxGunvdmLIwOENgHQjlEqcXycmkuJPEUCZdDeWeWRNeabhYNjbXfiilibvPHfqmNQhMlUfrJAtCEXzhvcVLRUCaiVWrtDRIxiOWMeHHzUKKalTIBRUWdaQjqffcQiUcsaEcdxcigHQUKEdccwoeRZdhyYNJEPtEvXJD");
    bool WdvBx = true;
    double KVejWshbuXqUpJ = -306203.5144003194;
    int aSbBFxdDVeAx = -1240092696;
    bool JwoQjALg = true;

    for (int FHuWWsQNfJmCiVcm = 692050338; FHuWWsQNfJmCiVcm > 0; FHuWWsQNfJmCiVcm--) {
        SerrMNqhk = QDrsRVe;
    }

    for (int gDVaGC = 1421098573; gDVaGC > 0; gDVaGC--) {
        continue;
    }

    if (CjvNOkeYfINB <= -1240092696) {
        for (int YnusomOqagmijnp = 58387130; YnusomOqagmijnp > 0; YnusomOqagmijnp--) {
            QDrsRVe = ! JwoQjALg;
            QDrsRVe = JwoQjALg;
        }
    }
}

int uYjEqIBeNTdoeftf::jlvhpuF(string ihNWSl, double WnmABuYAmg)
{
    int cbipxOTdrebBVwP = -815577260;
    int wsVAwstYiupFSxEM = -1964172086;
    double NpXkEpCEikzP = 293401.73020658264;

    for (int fxsMgvNRbTPJX = 344054788; fxsMgvNRbTPJX > 0; fxsMgvNRbTPJX--) {
        WnmABuYAmg -= WnmABuYAmg;
    }

    for (int AsUdRsIumwM = 297582493; AsUdRsIumwM > 0; AsUdRsIumwM--) {
        NpXkEpCEikzP = WnmABuYAmg;
        cbipxOTdrebBVwP += cbipxOTdrebBVwP;
    }

    if (cbipxOTdrebBVwP < -1964172086) {
        for (int nGUPkUhO = 1854977914; nGUPkUhO > 0; nGUPkUhO--) {
            continue;
        }
    }

    return wsVAwstYiupFSxEM;
}

string uYjEqIBeNTdoeftf::RzVMYGSHc(int BLsAIKfRgqaEfzj, double uWTXRvQJloN)
{
    string IYRmWVbmvWQDw = string("ZnqgwRsTxyIXfIkQZvizjZzRnXsRDgpBZApJFOnBMBQWxpdyVaxBTiCXnmJJBLaOLGQWfPbWXgqlErgkSnCnhaoaTFJmFyYppAZJWCUjLePDFBSBYZpCtPOMejPiwbrjzpPbbLkESFiCtpbmYMnJOAVaBnDhNzdWDOoZmjZTJrNhulUxJdoaParMsrZMhzaedXMdrdiMwkUzRUbIsjO");
    double TtiEVuji = -564590.5421229133;

    for (int BrqyZuntwBiTK = 707111798; BrqyZuntwBiTK > 0; BrqyZuntwBiTK--) {
        TtiEVuji = uWTXRvQJloN;
        IYRmWVbmvWQDw = IYRmWVbmvWQDw;
    }

    if (BLsAIKfRgqaEfzj < -502785684) {
        for (int ELzBalt = 601531294; ELzBalt > 0; ELzBalt--) {
            BLsAIKfRgqaEfzj *= BLsAIKfRgqaEfzj;
            uWTXRvQJloN = uWTXRvQJloN;
            TtiEVuji -= TtiEVuji;
            IYRmWVbmvWQDw = IYRmWVbmvWQDw;
            TtiEVuji *= TtiEVuji;
        }
    }

    for (int LbHsdhMyr = 1762698259; LbHsdhMyr > 0; LbHsdhMyr--) {
        continue;
    }

    for (int ZYAdUjjRxKJQ = 1693623114; ZYAdUjjRxKJQ > 0; ZYAdUjjRxKJQ--) {
        continue;
    }

    return IYRmWVbmvWQDw;
}

void uYjEqIBeNTdoeftf::woNWswiJjpjI(double HiSeAOHCqImTtGt, bool StMxUEal, int khtJgajkOWGdLD, string aOrGFKtIfqHHGDoM)
{
    int OVxrZ = -1800214488;
    string aWzmXpR = string("DlkDtMNFHnBPeogUXxkgJEFirjFdlHbKWLYanTugLKwHHHFshWTzujevzWWuioGAhbMBMxilIXgLNGePgSPRmCcSReOHPAIViZFgdhJEpZJndpVoanPvsidjJuZGPhgJWAhYrFhFwHKBTDkQWNYHflinouqUWQGmvXPceTvnYIQloozQIdMHWGqyEBzYaReZfxMmZDjBsPUJYrKGZFrrMoFRSGmtueUWEWusIHO");
    double PApvwbqjwQoLaOmy = 332784.6226220178;
    double AgMurqxVpMy = -579736.8682356575;
    bool brsPAnOhrJMyL = true;
    int NZyUPj = 1603078586;
    int sWXuNfuHsNWXvaH = -102755184;
    bool pnkvjuF = true;

    if (pnkvjuF != true) {
        for (int yWUkIVGsCJxFT = 1890913007; yWUkIVGsCJxFT > 0; yWUkIVGsCJxFT--) {
            HiSeAOHCqImTtGt -= PApvwbqjwQoLaOmy;
        }
    }

    if (OVxrZ != -102755184) {
        for (int yjgObHWhc = 1897893766; yjgObHWhc > 0; yjgObHWhc--) {
            continue;
        }
    }

    if (HiSeAOHCqImTtGt >= 820623.3663042643) {
        for (int vLepjNifInwB = 1146847722; vLepjNifInwB > 0; vLepjNifInwB--) {
            StMxUEal = pnkvjuF;
            sWXuNfuHsNWXvaH += khtJgajkOWGdLD;
        }
    }
}

string uYjEqIBeNTdoeftf::zKyxiabLEVXKN()
{
    int zRfKOxHQtnLKUk = -1904399058;
    double aloGuZWvMWGHMM = -479729.75437009276;
    string DYLcQsSufKipUp = string("tZRDROUCNCBPWZbawMttWCnJlhJZOuhcgiITpxchtTtYBlGSAtImCcxKdwlFGIVNvemTiEGmUwyqLgyightQzTWQaptUcnsKQmOIYFxdsSBuwwseXep");
    string fQaWMwvF = string("kxisTWzCjikPnkfIPHjQrxMkmcpopktvNfwffydJomFExarauWTcxMucUHFDHACuMuNatyshiMotKAyEDVhjSHgDVJDzPdTWAJpYPDuHZHIDfDsyQHbJJswNTSYpiWubENvfgBiLqW");
    double fIYGRMF = 189778.7281023538;
    string sSJozNYEjWAEEbMf = string("bPbHfJAAHSDKrcZEFEzdIgDHzSPDBHoHXmKbsbLHKsjacPKablrARPyhnEASmPxmnOCESaaMwDpKMHKiMkVTKSeWsILPJGjYJhaBLdCodnfXFfRePiOIlxrwIXWzdtSmLjlkxbpeRSTDbEsrRgfdXFAiGJraYxoshtPsxapFQCgwQwHVXHwAQZHUPqpsgqnRiJwtRMuBsdUjvuiROsUbYLeltgJHXwcUoqMhyZkRjFPfUPpv");
    int FsTkMVQHA = 850762059;
    double XbnQFoDuRMzu = 895375.5329816176;

    for (int TNRqcpUJvUkAN = 516642395; TNRqcpUJvUkAN > 0; TNRqcpUJvUkAN--) {
        fIYGRMF -= aloGuZWvMWGHMM;
        zRfKOxHQtnLKUk *= FsTkMVQHA;
    }

    for (int znkXk = 170753131; znkXk > 0; znkXk--) {
        fIYGRMF /= fIYGRMF;
        fIYGRMF += XbnQFoDuRMzu;
        FsTkMVQHA /= zRfKOxHQtnLKUk;
    }

    for (int UkWZqqVLldP = 660552747; UkWZqqVLldP > 0; UkWZqqVLldP--) {
        DYLcQsSufKipUp = fQaWMwvF;
        XbnQFoDuRMzu -= fIYGRMF;
        fIYGRMF /= XbnQFoDuRMzu;
        DYLcQsSufKipUp = sSJozNYEjWAEEbMf;
    }

    return sSJozNYEjWAEEbMf;
}

bool uYjEqIBeNTdoeftf::zfzljJKwzv(string zKbEnjH, double eZTsoEzQ)
{
    double wkTRKdgIDLeAT = 650786.474265698;
    int zaZEpfbM = 56552419;
    int kiVHhxAaJF = 1047550173;
    string JIIzQErpb = string("lTaIRRwQjCEmiDxWKfAWoYQesMbcSMMQQTBGctEeyZnbWIzHAcLfpMKbBZUSMMSjkOpZiSazdozqxFChuRVyIughZqmEHRzwWFMJHVIaivYPATtIYzBQYQHazBWjrLfeIjTmIVMDWhkuzIjTNwoGQkSdJxfsjXWfoPgCRKjvoHkNEmCrxHMyTlpuEOZReTIFvJzUHtbdSbybPxrAjEdQcUlNuCJmkTkwfInmzW");
    int xePTIVyyW = 1660503577;
    double jEJBl = 607961.6377176183;
    int KhnwjLPmihBRZ = -1067765652;

    return false;
}

double uYjEqIBeNTdoeftf::WfbHmQkeRk()
{
    bool VsjBXu = true;
    bool XeuHqaYVaEP = false;
    bool zvHPpSWtHan = true;
    bool sKgpzSgvQvdZ = true;
    string aEWpDwH = string("zlxKocOabATIGSHdnLRaEYxHbEoWkTgMBNcaKDhgTCxpvraPYRlCQamGYcTrnLvdhoqsPuNBEMbNwSRcrsHBVpUeoJDQGvZXVlwlbRGlYppaDaOIFSDpVYLYFazYjCSeyHmiEOKEirLxDgPujDoETPFXQsDAnYyLQD");
    double NFgKtqTEIqZRYA = 599134.3006360679;
    string SYMkZIV = string("CqXPmPCOfruNkWvTodnOKhkitaWfIZQYmelsGHnUWNarDgehBRnMunvAuObqYHTmprvGAhGATQasLObhEiEyMaqsUxRxLxJqUjdhpCPRlAfCxhyvuhYpzGTdhJWeQgcgpqdSIftkwVexLesXorRHgloRoPPaxAbBNTXcfKjpmEZXkwLuGzZr");

    if (VsjBXu != false) {
        for (int bQMzazMsZssfXf = 1741682899; bQMzazMsZssfXf > 0; bQMzazMsZssfXf--) {
            VsjBXu = ! VsjBXu;
        }
    }

    return NFgKtqTEIqZRYA;
}

uYjEqIBeNTdoeftf::uYjEqIBeNTdoeftf()
{
    this->yOJYMb();
    this->sUffPmPF();
    this->xJogZrdsbqxc(string("gqkpbjeU"), string("uXmIbdtjddjKhNphCMlkFEhjQpVTrGejFDHXcdgkgPFbillHvXBJrDwmFjPnXonpJJVJhFOwZdBEQpWieqekIDaHaAGmJVWIXqLvIBAqdVLQbDIanFnluFaIJFvaVumNRlqhOOzPJMjOmPkWhYCciPUpEZwTOjikCQbdzCm"), string("ZDAZSCCGcyNqlEfNypUJZccFQvZheNekrMeawobfanlYupKSMtxetCIDNCLVHbxAvVlmowFNAVgGBpXJvjplcMjXNsIdIDYwLqDBfasyVEnpGCIHVHdNrXNWQpLVOUVupGrMHZxNtqDOlrWitNuuJTVujYzzndMKiZlLfpWqAXsBLzVmKdixoJQrYbRlTTDPfJXJwrNoxFNZgDoxVYUBOBabcZfekGAIzuvfp"), 1039049222, -229898119);
    this->PnbNGZLx(string("PMIKPnmvFMxXyXLEOfjtftxFJBNxzKDJZJk"), true);
    this->toSrq(-856911.4149725727, string("EojPsczsxHisXezdtEdmdqKRWuVAnjyhZiaJFqiEKIxhIOPpwlceGTHssZYXnOwEpyZoarbkaUHIseMWOzJKQJtaTOHBhueXdKJpfuyFUFitwFlRfkhHlDCOYsfhxdiQLLqecNbHZMUtDtIpQpyahbwqwipMujLTXimmBWDQYvrJjJxgMbVxwDc"), -729038.3662689269, false, string("VEZWYsjPYbBNdMezUjRFXnBNuYKygthRyoHJlgIyklRqvLicpFdnZfibzANmwqSWIzcLIVGCUZXoTgOpsFikFjBgLlcIDEMdjtuljpJxuaHcviZFWDpnQJRDEKmoOcXyzuRHNuEtjiIbcUDpXvlAlGcMyphGNCNeHaqnpHneiWAHqxANyjcCjvotWusyxEaoNdAVVFdeOluFytMiLobhrwEejsuXVWhvlHIUCdIIqH"));
    this->nvWfYYhcUJjAI(241174811, string("bgmklYYaefrrXpLfATQzZzLpbLiB"), -167677.51459732107, 162171434, -1305377528);
    this->hZHiHxEyKcDtCoj(string("DTXmtyUhZJ"));
    this->SdqRvKIHKXbMJ();
    this->CTpHzPs(false, false, string("AdtKaeksRtvPqxfKqNpqyPZxCnDHqFXnDJYpqnwuDprGNobeEmAQxZsXiSCfVBdpivtJUYojbTIvdudUguSjeeZyNNvdNjgqGHZqeAtgQfBsVjOKAAupwdMgpYExRYPOUbHFXChLQeBeEofIXxcvZCRuZTNFaQuTJiqWWHqZMKCbnbLbIeWWHrjZGxnrDheFkAtVwJnvcusiBrfEHbIZVbBCFUQFgmiBELpXfJlIUUlzRRj"));
    this->pdVsjatxNkQ(false, 542459020, string("ajKChTvJDUYZCuwiBZzkxpjdegmVUhBgrbGaNARqYtyVIvHDCRBFIVkyavuhnqJDSzWCPDjEHncPHRTqqXevVAuCSwLRdWhsqnSQBGOVTcbFb"));
    this->vYwvnhnzQDJls(string("MyBVyrENMmfqDQphoTnbvmwgRdVYMpuCuBbsFugrwvRSToNSKEPYAcbBKeLEgSAWZVUArfncXkMDCGvEbsVmciaAryjItCgMbmwSsDueaiOZivXPYAtNOSbgDSEabPurSJDnmebYQykTtklYTGUjDoHQiZrYjPzIj"), -381027788, string("PTPXxGCZMHjgrTzlweJNxnxlLTEYtnJbkzIlZQqbTRCIkWgNWdBnNhNNwTNOjsolKbkqzfjLCbPyCiWKboBvsVaaBgAIWOTsXVct"), string("owlGKNXzSKssqFgLMoKhBsJYEPvVWmlHbqworaHWNEEZTPTElcWxJvzPZVmuZeHqzcwRObgWLRZQKeVxTEBNAKW"));
    this->iQkzE(-1711674294, 166066.29407592074, false, -310619688, true);
    this->jlvhpuF(string("GzqjsNbzVWGSSHvVBvhVnSSCtIIhCErRalkdpbLjktZUbdXXHfZsCzcTbWvDVnxwUuAELwZtJjnVAILDsKFZvONEIAruhKlVyQVwsowfpioXGtPbluGWMMmcUaotZzkDXzRYEXNtbzzybdpgxjEdQarnpaigEafNSdLsQPVHcdvKjmeeJoCIcATqYjDGFNEolGtwGRcCIGpIVcLItwjsBeueMLbDHawyOoqQXtgfDvAu"), 48976.61094330268);
    this->RzVMYGSHc(-502785684, 580603.0763348608);
    this->woNWswiJjpjI(820623.3663042643, true, 853398730, string("zCYHoZIQXAZqwdfRNiNWrutAmqbKhCmzgSUaVvNNAewNrnllkJFNMlRfZCCTmhtuKGguRouaQwWMaHTCWhKqbtWUttRyLojtZBfgzvuosurrXeCFGKUctwCmDbXwmXqvUpubeOlYWe"));
    this->zKyxiabLEVXKN();
    this->zfzljJKwzv(string("kRDJXKqZQnKvTPwkhBptxcFjXtsjUHdrznfscNqZgJIYbQmzFeedVhtOyBtBglSHvoxFRsGoziiHFlVtpDEemJXepFakdcDXLgaVbvwXmYfaNhSiWkyYAVSDutDHyxrzQDgKzjS"), 122389.02401978329);
    this->WfbHmQkeRk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FhlVIFUfXlF
{
public:
    double ShbpWBELmv;

    FhlVIFUfXlF();
    int lQXjQsAvbG();
    int JjmawD(bool RcOuGGdqcOT, int NjXrfksCR, bool AgUitBrtbcQMNZiR, int YLBsotEBOs);
    string vdZJMYLgctsQucd(int snrMpgHWgHXgASB, int mjLUtVEMTB, double vhwhXHkbmdWXqgb, int jUNNjoDXcwn, double bqBFRYInh);
    void OSOvdvEfEGomjT(bool ocYBXZ);
    bool MMUKUDlbUCsJJeYU(double QeyRMSZXddUM, bool BtFmi);
    int yiCfIqtBU(int KxPqpjBRhKE, int uSHVJdCi);
    void bREECUXwm(double JszgNudd);
    string LaoHhzEpGVg(double ZwiJzTJOJkKtgor, string aORxsY);
protected:
    bool KrYdmYwKHliGo;

    string WpqJCphos(int xTuXTgcUvYohBuf, bool ORGOGabseGacb, int XaVFrzCn);
    string chDaiDRiGltc();
    int oazSVXyYnMklMB(string UJSigNglpIex, string dZQgndrRmTSDEw);
    string LoCGCnahrrGLlSG(bool sxMme);
    string bzobMxFxfe(int LCHPBjS, double ORwtMfyrEgB, double JIpMHBw, bool CGQudvOmgnlFm, int tBLufLizu);
    double bBqRAwhVBDX(bool zKgqxSnqa, string QClRRlOE);
    string UScwhU(int AGUiDvpU, int FtKynLbkZmqMl, int alqsBq);
private:
    bool JCgdHFVEc;
    double DJTvEvQOTZaElqzu;
    bool nXUqVfkrcoHS;
    bool hOgvvDTSyTZxQ;
    double mckhdvlEqnwzB;
    string mnwwmaTyOfMLGQ;

    void diRNPBoqZYEEkO();
    int KQTKxGLwTt(bool PkmkhPsTRNow, int SdjJWgbllRY, string HNtHKVITbGPNib, string KmIxhwTf, int dIDGPUMDGiWuyOhY);
};

int FhlVIFUfXlF::lQXjQsAvbG()
{
    int bEAwpZZFQXCiVw = 1556484662;
    double qVkxQHHeoAg = 634275.9856664994;
    bool oGaiAcrEhETd = true;

    return bEAwpZZFQXCiVw;
}

int FhlVIFUfXlF::JjmawD(bool RcOuGGdqcOT, int NjXrfksCR, bool AgUitBrtbcQMNZiR, int YLBsotEBOs)
{
    bool zAuzeITl = true;
    double ckiPRfgS = 563576.7856574479;
    int DIDCxuUSvPmdtq = -1323124026;
    double QHNgoAtYQZrz = 725218.3416512458;
    bool dvHVTomozJP = true;

    if (DIDCxuUSvPmdtq <= -2089978810) {
        for (int JKorOFXFBGuiB = 1665554717; JKorOFXFBGuiB > 0; JKorOFXFBGuiB--) {
            AgUitBrtbcQMNZiR = ! zAuzeITl;
        }
    }

    for (int dQkqBJleRgA = 230546550; dQkqBJleRgA > 0; dQkqBJleRgA--) {
        AgUitBrtbcQMNZiR = dvHVTomozJP;
        dvHVTomozJP = zAuzeITl;
        zAuzeITl = dvHVTomozJP;
        dvHVTomozJP = ! RcOuGGdqcOT;
    }

    return DIDCxuUSvPmdtq;
}

string FhlVIFUfXlF::vdZJMYLgctsQucd(int snrMpgHWgHXgASB, int mjLUtVEMTB, double vhwhXHkbmdWXqgb, int jUNNjoDXcwn, double bqBFRYInh)
{
    int PcfzqVSOOec = 1805015679;
    int Banxv = -663356519;
    bool UAMZph = true;
    double zNUMhvqxbzvopHzf = 627669.7247949587;
    double okKygPO = 874070.1074433465;
    double THktXagRXLWZpg = 962527.5336254309;
    string TDOpLDkptUKKpwE = string("AdnfwAtrWLKkkoWpnssMyTDfh");
    bool AYCzoKqgi = true;
    int axBSIUBlVlHbWXDo = -1558896943;
    int KZrKvSEpXKzR = 1944218640;

    for (int qncygAxH = 1569927992; qncygAxH > 0; qncygAxH--) {
        Banxv -= axBSIUBlVlHbWXDo;
    }

    for (int HXqYcMlTliMJWN = 504806705; HXqYcMlTliMJWN > 0; HXqYcMlTliMJWN--) {
        axBSIUBlVlHbWXDo *= KZrKvSEpXKzR;
        bqBFRYInh -= bqBFRYInh;
        UAMZph = ! UAMZph;
        AYCzoKqgi = AYCzoKqgi;
        okKygPO = THktXagRXLWZpg;
    }

    for (int wpgLOMiROdKKYX = 620978589; wpgLOMiROdKKYX > 0; wpgLOMiROdKKYX--) {
        zNUMhvqxbzvopHzf *= THktXagRXLWZpg;
    }

    if (UAMZph == true) {
        for (int yLBDjbx = 490108987; yLBDjbx > 0; yLBDjbx--) {
            UAMZph = ! AYCzoKqgi;
            okKygPO += okKygPO;
            Banxv += jUNNjoDXcwn;
        }
    }

    for (int njqjr = 428359487; njqjr > 0; njqjr--) {
        continue;
    }

    if (axBSIUBlVlHbWXDo > -664220968) {
        for (int igVEPFdF = 1055121924; igVEPFdF > 0; igVEPFdF--) {
            continue;
        }
    }

    return TDOpLDkptUKKpwE;
}

void FhlVIFUfXlF::OSOvdvEfEGomjT(bool ocYBXZ)
{
    string gtAeFFgrmO = string("oGdYFuWWxgFqQhKxqncYvVyraqtFivYgvLxBGIcXQ");
    bool RVgwycdNyjKSny = true;
    string hrwtkmorWq = string("ajMRPHoDifQTeOeOOedLGnsfsFWpHCrPQExsuYOCOijYrMpcwEKDmjPKtpiEOJNfErTnkqqljyQDQXQpXBtZYdeiqRttBXNCQmWtgJcKhMXdezMuwzLgUoeogpvynycYSa");
    string UJUuGorBbVynTjz = string("jbfBmuEosXyRoYCmYTwtIGwicIKqYgYPFhrgMYQHxhoAineNskWhQKrrDeptXXiQGUynbXHmyISCdSOKpJCCARyJNEtosdpXFGUrNVFBLHNtFtYLUgTdaYGXdkVamTorTQhwLHfqChSBfdwaPywUDWrHhvVaFosxrpPYoOdOMRywwSCAgKQIahMBkmWJSJVTaxIKG");
    bool zsdkQFI = false;

    if (hrwtkmorWq > string("ajMRPHoDifQTeOeOOedLGnsfsFWpHCrPQExsuYOCOijYrMpcwEKDmjPKtpiEOJNfErTnkqqljyQDQXQpXBtZYdeiqRttBXNCQmWtgJcKhMXdezMuwzLgUoeogpvynycYSa")) {
        for (int ZNCaMvyqvOQiKMpy = 1226088425; ZNCaMvyqvOQiKMpy > 0; ZNCaMvyqvOQiKMpy--) {
            hrwtkmorWq += gtAeFFgrmO;
            UJUuGorBbVynTjz += hrwtkmorWq;
            zsdkQFI = ! RVgwycdNyjKSny;
            gtAeFFgrmO = hrwtkmorWq;
            RVgwycdNyjKSny = ocYBXZ;
            zsdkQFI = ! RVgwycdNyjKSny;
        }
    }

    if (UJUuGorBbVynTjz <= string("ajMRPHoDifQTeOeOOedLGnsfsFWpHCrPQExsuYOCOijYrMpcwEKDmjPKtpiEOJNfErTnkqqljyQDQXQpXBtZYdeiqRttBXNCQmWtgJcKhMXdezMuwzLgUoeogpvynycYSa")) {
        for (int sQeFNswRwG = 156568255; sQeFNswRwG > 0; sQeFNswRwG--) {
            gtAeFFgrmO = UJUuGorBbVynTjz;
            UJUuGorBbVynTjz += hrwtkmorWq;
        }
    }
}

bool FhlVIFUfXlF::MMUKUDlbUCsJJeYU(double QeyRMSZXddUM, bool BtFmi)
{
    int vJPgiNGWEaHQOC = 1805446178;
    bool ctIcMyrPATMe = true;
    bool yVqptWlSBeFh = false;
    bool UjxNhRXQSzxJLis = true;
    string yBCupeXyTJu = string("BKqncKWqpqXVefPZdpnUpoAIcdWbHecWiWSCsMMKSMBcnyAVntqCgCrHsQrbuugbKoUhIijxgRKcrqpPDSECzjAyyviygMcaAWPTllnGwbJpjOHsJwluGZFFvdDnXmfxMdKCxyirFLTZOkoyOxdHZALVKcuvmDFAuVgwRYsvYQjcBMdThNrpUNYMrJuOaWysFExcEdzgecJFmauiLqqOoMyaPgQYbuDT");
    string fdzdUqUiqjjR = string("ADCQPHYzwUymWFPLdLNyzLcGNPCTRuNCPzQKmJMRHpykcwGseigMtvNgtOsUnaFZjzgvaZTPLAvrXTNByltpxILPCEogizxqCqjpPZiELvaLbJytnELzqPRxTVGHSeZnoqXqfRotyWpmr");
    int AIYrajFrXOHr = -731328324;
    string EAmqiCpKjtPqo = string("RPBx");
    int JFbMMmvMRqyMJK = 584197851;
    double mmiYnWuzKQmyYgR = -958006.231299225;

    for (int egYdUgjrt = 295268208; egYdUgjrt > 0; egYdUgjrt--) {
        continue;
    }

    for (int wkqOmiyVcEjtVu = 1074871173; wkqOmiyVcEjtVu > 0; wkqOmiyVcEjtVu--) {
        fdzdUqUiqjjR = fdzdUqUiqjjR;
        EAmqiCpKjtPqo += yBCupeXyTJu;
    }

    return UjxNhRXQSzxJLis;
}

int FhlVIFUfXlF::yiCfIqtBU(int KxPqpjBRhKE, int uSHVJdCi)
{
    double RdvVSbTPgShJSWw = 164475.74994110674;
    bool FqTVBUz = false;
    bool lqYGuZKSBmeBchj = false;
    string HhUbYPSdHqrDxE = string("vurFIACIoqUqMbLrMnTOCfNBsUXVMPpcgPllpZIOdpANxzYyQhIxrTVeuLVWkfkLDJgXYrqxJihknRaktusTSSjtlTnHnZipjdiAfTIWWeymYbmVfCuLvqwJtPCMTlbOtPHTpYccheuiLJQJzhxuuQaZjugzzfenoapJWWWxEmuKyYmwPlhUVUfLXMPmQSzuiaTJTJhhjtaEfMUMRZFWdSSUbRAKUMuXYlU");
    bool MxlwFSZWXVaPRYWR = false;
    string LzWKcyvhctCkd = string("NMESBDrIatFcJDLZLIDNBAakcgJPQOHJNlPDuOMsHRvztaoBVBJ");
    bool TwgskvPWrp = false;
    bool WGXmcYQbv = false;
    int nNqwDkNHwZ = -1572911034;

    for (int ithBnN = 1612685138; ithBnN > 0; ithBnN--) {
        FqTVBUz = ! WGXmcYQbv;
    }

    if (MxlwFSZWXVaPRYWR == false) {
        for (int GITpGqzelugbdJ = 1623299183; GITpGqzelugbdJ > 0; GITpGqzelugbdJ--) {
            FqTVBUz = TwgskvPWrp;
        }
    }

    return nNqwDkNHwZ;
}

void FhlVIFUfXlF::bREECUXwm(double JszgNudd)
{
    int YXcPs = -1057898026;
    double YSDNW = -449914.35421827424;
    string LobgFoZPhuOgGI = string("sUYrKVtCAzDcVbQeKRGtNSuDHWWTZXjZXaOArENDDVtAsCLYclXfLgAVVFYvzGYlEnCBvGHOTqPAUDLEGWeQzyTUWLikWtnqbbuMBxsfOamCJzRaFmwIlvaelkyMKLLmMcdd");
    int pUSJBEarf = -1530481201;
    int FXoGcBYj = 1560629228;
    bool EnTjCWsF = false;
}

string FhlVIFUfXlF::LaoHhzEpGVg(double ZwiJzTJOJkKtgor, string aORxsY)
{
    double bdCYDCnHAjEll = 876041.1131863691;
    int ioGyOJiSCCFcYbY = -2017776072;
    int VFVkUf = 513947476;
    double VWatRAPLdwRMGXvr = 950836.8204827583;
    int psnssutkzbyODyRB = -402097746;
    int pvWcLynncvI = 936438810;
    int ccsJfPMwEn = 1207857606;
    string NFhTyahu = string("pwNJKabJTsFSyUmrpgGLgvYBBGGTFGCOduAbqvnyQfhwjZZAUBFzYkZVZjPClPTUYwyieHRQIKHmslHQqUmdvmIcoGLKSImuZknWBMqgmpYwLllWNbzWOmsNVMeKAmohKXCSWdzuvjRlfkIjFQyIGXkkAkJBMJRYNlxHYmXnATknMVKNy");

    if (ccsJfPMwEn >= 513947476) {
        for (int DeDSf = 1912166549; DeDSf > 0; DeDSf--) {
            pvWcLynncvI += VFVkUf;
            ZwiJzTJOJkKtgor *= VWatRAPLdwRMGXvr;
            VFVkUf += psnssutkzbyODyRB;
            bdCYDCnHAjEll += bdCYDCnHAjEll;
            pvWcLynncvI *= psnssutkzbyODyRB;
        }
    }

    for (int YCArjXQdfdFvWTPp = 1544495143; YCArjXQdfdFvWTPp > 0; YCArjXQdfdFvWTPp--) {
        bdCYDCnHAjEll *= VWatRAPLdwRMGXvr;
        VFVkUf += pvWcLynncvI;
    }

    if (ccsJfPMwEn < 513947476) {
        for (int BHGLJwSCIYiTtdL = 1823861409; BHGLJwSCIYiTtdL > 0; BHGLJwSCIYiTtdL--) {
            continue;
        }
    }

    return NFhTyahu;
}

string FhlVIFUfXlF::WpqJCphos(int xTuXTgcUvYohBuf, bool ORGOGabseGacb, int XaVFrzCn)
{
    double CkBqOctNv = 779116.7113744015;
    int upBHIxFkKsM = 2132672025;

    if (xTuXTgcUvYohBuf < 1416996677) {
        for (int paLCIubkz = 667633632; paLCIubkz > 0; paLCIubkz--) {
            upBHIxFkKsM /= xTuXTgcUvYohBuf;
        }
    }

    for (int SHJSuuqw = 1504962811; SHJSuuqw > 0; SHJSuuqw--) {
        CkBqOctNv /= CkBqOctNv;
        XaVFrzCn += upBHIxFkKsM;
        XaVFrzCn += xTuXTgcUvYohBuf;
    }

    if (XaVFrzCn != 2132672025) {
        for (int BpsJAcrMu = 932845865; BpsJAcrMu > 0; BpsJAcrMu--) {
            xTuXTgcUvYohBuf -= XaVFrzCn;
            CkBqOctNv /= CkBqOctNv;
            xTuXTgcUvYohBuf -= xTuXTgcUvYohBuf;
            XaVFrzCn = xTuXTgcUvYohBuf;
            xTuXTgcUvYohBuf /= xTuXTgcUvYohBuf;
        }
    }

    for (int RwDcunRWVREUew = 1922551058; RwDcunRWVREUew > 0; RwDcunRWVREUew--) {
        continue;
    }

    return string("HyazjODPwqfiuDZoDHzOjBsxhRqneUjIrLEdUJunAZgVaWhUBCPHACVhJFGHjGQpEKywKeYvcGDHCUgisrdTUMytHWMwDUOlzTGNMCZLfqJxrBPlsLWefrtltLWfZLIWKTlQjFXhwqZKkRmMnUr");
}

string FhlVIFUfXlF::chDaiDRiGltc()
{
    bool QSsPopa = false;

    if (QSsPopa == false) {
        for (int DukYyVsNxUDjJeUm = 193889437; DukYyVsNxUDjJeUm > 0; DukYyVsNxUDjJeUm--) {
            QSsPopa = QSsPopa;
            QSsPopa = QSsPopa;
            QSsPopa = ! QSsPopa;
            QSsPopa = ! QSsPopa;
            QSsPopa = ! QSsPopa;
            QSsPopa = ! QSsPopa;
            QSsPopa = ! QSsPopa;
        }
    }

    return string("skkXiBlPSutdyONPmrjmVmiskjiMUGkRseWRcKrtiSgDtVfuhAiNWlbHbhhDTepJ");
}

int FhlVIFUfXlF::oazSVXyYnMklMB(string UJSigNglpIex, string dZQgndrRmTSDEw)
{
    int JQswS = -1770400670;
    string aXSzAuQLyZXG = string("uOvmvunGxdPpOwSLfOczdLEGNGlXWoNMALKrvesWlkbDzPeJXTzIDdUrmaOOBEwJVCbtAAHyOUGtdbZhpvH");
    double jAiNOIsggFP = -467650.6227310857;
    int GVrmrW = 537535139;
    double eysRtOSpjoWDrO = -354355.75156977563;
    string KgoeoMBlLLlaCCf = string("vDgTjYWPitvQSjscOzYuxsXGtUpmlLbrqASOkqImMWZRbBjBohOyXV");

    for (int VTukyG = 1289552350; VTukyG > 0; VTukyG--) {
        JQswS /= GVrmrW;
    }

    return GVrmrW;
}

string FhlVIFUfXlF::LoCGCnahrrGLlSG(bool sxMme)
{
    string iyufZAh = string("vtbUZiKUZXU");
    string RsFYwuUd = string("LkzEYGWESfJZhyaEiZfPnPBFPVZacqUhGgdntJVMHgtNvsOBKuSXuIDjiBhYrTycnAWhxHvvlpTvhBZmJTttYcOIQUYzeypUEcdqchEUUYkEjjQbBmhHBthNOehhKz");
    bool jiEKW = false;
    int JWefzZIf = 227194325;
    string QJoQFsGItcsBoS = string("yHVcTxfkISCiblNueLimOaZLwyUcGzmNBoKZvPQMeLBzMOMaHEHutDZkAuoerksrPRxkxTmgCzBvcczzsVnErRQJJvmTfqijTslwBIiZbJnalGRdUflZRCBmKOuxTzlxLySTzFGRctKIZSKJQKAjCOHPssJntDSFqFQZvZmmSJSgeyxVrgzVxEiZAHuDlJQDLiVQdbdYnQkEsooKzkYUhURynrLGLzEuf");
    double MXCrLMplOztKjpxb = 1047086.2799002979;

    if (RsFYwuUd > string("yHVcTxfkISCiblNueLimOaZLwyUcGzmNBoKZvPQMeLBzMOMaHEHutDZkAuoerksrPRxkxTmgCzBvcczzsVnErRQJJvmTfqijTslwBIiZbJnalGRdUflZRCBmKOuxTzlxLySTzFGRctKIZSKJQKAjCOHPssJntDSFqFQZvZmmSJSgeyxVrgzVxEiZAHuDlJQDLiVQdbdYnQkEsooKzkYUhURynrLGLzEuf")) {
        for (int LUEqYVz = 415836444; LUEqYVz > 0; LUEqYVz--) {
            JWefzZIf /= JWefzZIf;
            RsFYwuUd += iyufZAh;
        }
    }

    if (RsFYwuUd < string("vtbUZiKUZXU")) {
        for (int revukLdDlgSaApir = 1679304589; revukLdDlgSaApir > 0; revukLdDlgSaApir--) {
            QJoQFsGItcsBoS += QJoQFsGItcsBoS;
            RsFYwuUd = iyufZAh;
        }
    }

    return QJoQFsGItcsBoS;
}

string FhlVIFUfXlF::bzobMxFxfe(int LCHPBjS, double ORwtMfyrEgB, double JIpMHBw, bool CGQudvOmgnlFm, int tBLufLizu)
{
    double iGpKWJNMTO = 701314.0629427314;
    double BQUtijgujCCu = -342886.91693368583;
    int ckEFdpkSm = 624875551;

    if (iGpKWJNMTO == 881527.295731553) {
        for (int LAOnvWlbIShMxFA = 245831850; LAOnvWlbIShMxFA > 0; LAOnvWlbIShMxFA--) {
            tBLufLizu = tBLufLizu;
        }
    }

    for (int PaaRMYEelqDy = 837201811; PaaRMYEelqDy > 0; PaaRMYEelqDy--) {
        LCHPBjS = ckEFdpkSm;
    }

    for (int TxKVBov = 1517813371; TxKVBov > 0; TxKVBov--) {
        continue;
    }

    for (int aRLVNoim = 856381975; aRLVNoim > 0; aRLVNoim--) {
        BQUtijgujCCu -= iGpKWJNMTO;
        ORwtMfyrEgB /= iGpKWJNMTO;
    }

    if (ckEFdpkSm >= 624875551) {
        for (int WXZJnMjmLgLoMXZ = 909975074; WXZJnMjmLgLoMXZ > 0; WXZJnMjmLgLoMXZ--) {
            ckEFdpkSm /= ckEFdpkSm;
            iGpKWJNMTO = BQUtijgujCCu;
        }
    }

    for (int SuCMckAkgH = 324957737; SuCMckAkgH > 0; SuCMckAkgH--) {
        ckEFdpkSm -= tBLufLizu;
    }

    return string("iHnpCfUqDLstBPPOHphPDjPebGHTvNdykbipXRpfbxvTtqeGFyTGLwvZkZmRMGezUNKzjxNXWCDtQCrwPDZuANPQikDZQCVhLGjCTCCcGzownbjGeqrcdRCXzp");
}

double FhlVIFUfXlF::bBqRAwhVBDX(bool zKgqxSnqa, string QClRRlOE)
{
    bool oXYzWmN = false;
    int ZdOvcLRF = 1696849704;

    return -1006294.495673533;
}

string FhlVIFUfXlF::UScwhU(int AGUiDvpU, int FtKynLbkZmqMl, int alqsBq)
{
    bool ynhytYYfR = true;
    int szMpISEinCnNtv = -2134255533;
    bool olJOoX = true;

    if (FtKynLbkZmqMl > -668677102) {
        for (int WWoGu = 1871516211; WWoGu > 0; WWoGu--) {
            szMpISEinCnNtv -= FtKynLbkZmqMl;
            AGUiDvpU = szMpISEinCnNtv;
            szMpISEinCnNtv *= AGUiDvpU;
            FtKynLbkZmqMl *= FtKynLbkZmqMl;
        }
    }

    if (szMpISEinCnNtv != -2134255533) {
        for (int IMMEasDtZkzVysmL = 931889004; IMMEasDtZkzVysmL > 0; IMMEasDtZkzVysmL--) {
            AGUiDvpU += szMpISEinCnNtv;
            AGUiDvpU -= szMpISEinCnNtv;
        }
    }

    if (olJOoX == true) {
        for (int dHnHbtZg = 1405687293; dHnHbtZg > 0; dHnHbtZg--) {
            continue;
        }
    }

    if (alqsBq >= -2134255533) {
        for (int IkIFPhxTNDttMgtP = 2007108876; IkIFPhxTNDttMgtP > 0; IkIFPhxTNDttMgtP--) {
            olJOoX = ! ynhytYYfR;
            FtKynLbkZmqMl += AGUiDvpU;
            szMpISEinCnNtv /= FtKynLbkZmqMl;
            alqsBq /= AGUiDvpU;
        }
    }

    return string("htNfUItHpxBbVNqpwXtLLEsyAfuhSwsUwowDmoaexpJhzDRniuLvnFMAvuNfbnLniJkvcMq");
}

void FhlVIFUfXlF::diRNPBoqZYEEkO()
{
    int oDHRkHxMMwXlnuB = 232010281;
    bool mrbpVvjUBGmFtk = true;
    double gXEyEQzUkLBoWX = 101204.62118015447;

    for (int TkxBSYbf = 16640602; TkxBSYbf > 0; TkxBSYbf--) {
        oDHRkHxMMwXlnuB = oDHRkHxMMwXlnuB;
        oDHRkHxMMwXlnuB -= oDHRkHxMMwXlnuB;
    }

    for (int Ljknky = 2004696670; Ljknky > 0; Ljknky--) {
        oDHRkHxMMwXlnuB /= oDHRkHxMMwXlnuB;
        gXEyEQzUkLBoWX *= gXEyEQzUkLBoWX;
        mrbpVvjUBGmFtk = ! mrbpVvjUBGmFtk;
    }

    for (int vXqIv = 193562337; vXqIv > 0; vXqIv--) {
        mrbpVvjUBGmFtk = ! mrbpVvjUBGmFtk;
        mrbpVvjUBGmFtk = mrbpVvjUBGmFtk;
        mrbpVvjUBGmFtk = ! mrbpVvjUBGmFtk;
        mrbpVvjUBGmFtk = mrbpVvjUBGmFtk;
    }
}

int FhlVIFUfXlF::KQTKxGLwTt(bool PkmkhPsTRNow, int SdjJWgbllRY, string HNtHKVITbGPNib, string KmIxhwTf, int dIDGPUMDGiWuyOhY)
{
    string IMEbHYA = string("DjpqAUTJzawBVuUdDLvwQPQBnPwXVNBhkscWVVCCrRzHjdatUpONxhYZVvjTpVroIuxd");
    bool kapauODOlUctqlSu = false;
    string lifCPxIYzEXJc = string("npVffOPWzCaPXoIuCGaqWusWYelcemYTthfrBGnaxzLlByI");
    double cYKoXRumNCp = 1012552.0553161202;
    double gnXMMoUOZVsJlcLe = 182718.22366762446;
    int JgArpGUCdARVdjIp = -1907614584;
    bool XKdkz = false;
    int XslqJCTCb = -308550294;

    for (int atudmdwfonRSvv = 1990726187; atudmdwfonRSvv > 0; atudmdwfonRSvv--) {
        KmIxhwTf += lifCPxIYzEXJc;
    }

    for (int KmXhR = 590014973; KmXhR > 0; KmXhR--) {
        gnXMMoUOZVsJlcLe *= cYKoXRumNCp;
        PkmkhPsTRNow = kapauODOlUctqlSu;
    }

    for (int peRDrTeItAUWF = 52979422; peRDrTeItAUWF > 0; peRDrTeItAUWF--) {
        kapauODOlUctqlSu = ! PkmkhPsTRNow;
        HNtHKVITbGPNib = HNtHKVITbGPNib;
    }

    if (KmIxhwTf == string("fhvLpVsOQnFcnnpxXQuyhFZxviRnlWGlaOylSenmQhpCECdVCzKIl")) {
        for (int aTTeoyYZqnJSdCu = 96919727; aTTeoyYZqnJSdCu > 0; aTTeoyYZqnJSdCu--) {
            continue;
        }
    }

    return XslqJCTCb;
}

FhlVIFUfXlF::FhlVIFUfXlF()
{
    this->lQXjQsAvbG();
    this->JjmawD(false, -2089978810, true, -926191968);
    this->vdZJMYLgctsQucd(1672434262, -664220968, -569137.5598180131, -1503727936, -30663.367020816648);
    this->OSOvdvEfEGomjT(true);
    this->MMUKUDlbUCsJJeYU(86678.63193425734, false);
    this->yiCfIqtBU(-122514595, 1330102047);
    this->bREECUXwm(672529.2039193133);
    this->LaoHhzEpGVg(-953682.6376054146, string("NoBbqGRHgonAnNqLqHdnTBfooNcnXzp"));
    this->WpqJCphos(-455354471, true, 1416996677);
    this->chDaiDRiGltc();
    this->oazSVXyYnMklMB(string("PsPmdiDFyVSCfwwQviljDPFbDexUEKakExnhzmRJZABaAnmEnCcVwkcMLkoAiOoviwJGoNpQtSFHERNDdMaiLCVvVhQYmCSgapXrEnZowuSiytPgFkJjUhLVVDRGtMdDAwKrPRgpRJanIpmhzuWozVYUCyFQoZlsYHoOSWxzxk"), string("xqvLxCsVfFokusEKVexEEgsMMmKjrDrlHNECQvfYPPBjjmtzrsOoyJOMjuMkCEGqIoGFAZ"));
    this->LoCGCnahrrGLlSG(true);
    this->bzobMxFxfe(1184657538, 881527.295731553, -926508.1435891952, false, 299340578);
    this->bBqRAwhVBDX(true, string("XHRagtHxoSZwnmKdscmbNsOcsTsAkubuvUafIHvXhrUWBZfJIuZvBNABNnQCgwRzRIOPIqfGxApyFigyceZaKobJtacbjJPwaROBdlMLyDGoaFyNOXkXBUikxYagjcyoBWmimtFQDTdXUbRcrMnHBCQPjjuIcPLqpUNQwwoiCTznUVOBoegPYXmWtIgzplqpfVPqYMGzsNAcSKzIwp"));
    this->UScwhU(-668677102, 26790169, -2098109691);
    this->diRNPBoqZYEEkO();
    this->KQTKxGLwTt(true, -1900285001, string("LqwJUaqFHlpvXAZOQpzfXRIecBeEtzwbXOZxMAJqXPNeyGIjSnofiCoARmhEHpAQbAodbPqkOUdKwpRtxSwfVdOEVwMSIsJczEvhBDejwoMpXZhgjdtFwYAqhyzfRLpGwHSgKSxzlaMWRmquvntOiUGyIltislRhWNJNQYrrnU"), string("fhvLpVsOQnFcnnpxXQuyhFZxviRnlWGlaOylSenmQhpCECdVCzKIl"), 2082800051);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MkrON
{
public:
    double HuQzRnYNouoM;

    MkrON();
    int SExuxwSeTAqXk(bool goxNLF);
    string kkbDlvLrj(double LXHtGGh, int fKUmLkxxbFKuyKIW, int kBUGWTTubHEmJC, double ofWUK, string JsdVUBPOAq);
    void fsqhRxw(bool GeWIgnEoLKkso, string ZpXJJYtMvkRm, int uycvOsJ, double FmLzo, double qHtXhGxMlolI);
    bool CqvAJpX(int WFHwggVWUXyh, int ZJGLPjkRSl);
    int eSYxNRxyXHYp();
    double uFzlNQZhbAqjp(double WTuVozBXZXEi, bool JOLpEFnAWskiaIRM, int zyLLng, bool FsSKwZLwQZI, double NErMedkb);
    string eFzRG();
protected:
    string PxglOBMqoa;
    double uBWxyRRfUB;
    int hTQtLvxJcY;
    string RubevaacJq;
    double GCVxUxdtKfmDTV;
    double XZjfTRbRmeMGB;

    int xrPkHXqeng(string ZjEkzzPD, string fVaUKsWzFjoLHdb, double sSqqculoNReWZ);
    void JOLlB(double hejyINUtbYrWYJhq, double poklvoUwWGvyPo);
    string LTSLbXWYJKPiSqW(double WCgHp, bool lFItvDmvnwJw, bool GOdNKEZ, double UzATYJhUybyMCV);
    bool PUHoTsZB(string LrMQSjfYjLV, string jmRVMSfkxRoL, double uUmkGBty, double DHgTRUBZWsVjxBdx, int XSbbIuejAX);
    bool AjiwI(bool lacQEobaE, bool imHjuKi, string BVGywGT, bool VFdMhqgBx, bool yEuJRgjb);
    bool nnJxUnoUTQKJXYBA();
    double pmKLVDpVHE(string AMgtpgAURYBGFlRh, double QMSKhmMMRj);
    void kzZxlcLX(bool MNLfyhxQtObThk, double WpPfChXKOrfjNA);
private:
    bool rfoTM;
    bool AgQSOLUqESjH;
    string TQphYhHIEMrywdE;

    bool zfndGclTHVuRh();
    bool ukyIwkdzX(bool QzbBhJvHaHU, int mjtss, bool BEyzBnuqAlfkSoEp, string BjfKLDzZv);
    void XbuNQRLsbNl();
};

int MkrON::SExuxwSeTAqXk(bool goxNLF)
{
    bool hHYGtVhuJVdR = true;
    string nLQFXAaaDiDOgq = string("SGCZgQRSYNZNLSBmphpZEqYJbvFViixFcnQFqlOBNJPqflQPxsVJzejZntBnplHrDBZzWOARjEStBregmLfInCLHagXagXJviXmksWUdHLSPYjaOTdqlltkZCzrBruzgzcTaRcDBPmPWdhLyKasHZOlDdCziXtwfPUSjqIYmxqKCZyexLKlNIltjCWgXUENrAEoCBCfcQmurAjvTabzwKJnKlhAdVhl");
    bool mohBtdfaIDiQeGL = true;
    bool JPdPKrRgm = true;
    bool VycMPfmtLZV = true;
    double oMEjvCitUDcvsG = -691468.4801414763;

    if (goxNLF == true) {
        for (int PFgNsOqQ = 1959530138; PFgNsOqQ > 0; PFgNsOqQ--) {
            goxNLF = ! VycMPfmtLZV;
        }
    }

    for (int FOvZC = 1659830979; FOvZC > 0; FOvZC--) {
        goxNLF = hHYGtVhuJVdR;
        nLQFXAaaDiDOgq += nLQFXAaaDiDOgq;
        goxNLF = ! hHYGtVhuJVdR;
    }

    return 1191437536;
}

string MkrON::kkbDlvLrj(double LXHtGGh, int fKUmLkxxbFKuyKIW, int kBUGWTTubHEmJC, double ofWUK, string JsdVUBPOAq)
{
    bool rbwGNePRBPtvp = false;
    string WOdIXANLHppTI = string("VQhTtlPwXHkemNsbaTxVceVzOJlMeDStQhNNTGjbiHwaxCojgmCHkJgsopAlnQvpolnNfnpCJVYfjcExABBOqQgNtZFNWamXzygUCrgBmabAREiQvgeKCPcPDOVEHtDZaxYrQlMQphlMJGgzpkShhHiyUjSbdNNOZItUXQzptwmPwuNoFkETttjmSmzEqWGIvuAfuZgaoQxxsevuWtiXZfuiDngJcXfKpS");

    for (int pQLMMBUiqlpDHCAF = 1017000049; pQLMMBUiqlpDHCAF > 0; pQLMMBUiqlpDHCAF--) {
        continue;
    }

    for (int BuWgo = 689932312; BuWgo > 0; BuWgo--) {
        ofWUK *= LXHtGGh;
    }

    return WOdIXANLHppTI;
}

void MkrON::fsqhRxw(bool GeWIgnEoLKkso, string ZpXJJYtMvkRm, int uycvOsJ, double FmLzo, double qHtXhGxMlolI)
{
    double YWrgKgiqpjj = 310973.2459864395;
    double YoFCRAGW = -834558.6771086192;
    string ojdDgTvMKSuq = string("SDBDcgyOOsgdYTRylwnwiHHaPREgWINdDuBQsDWjCOhXEQBNKbnWBlpCVxbZrRpnRkEjOaHqhXPkUHXinGzMgeSzOClQREgDqXkZYKTEWlGqW");
    bool uRNwsLYRXVdEnWZ = true;
    int sFEVbvwnR = -128293902;
    bool WnFLbq = false;
    int FqHSeJpAPvWnqx = 1374088233;
    string glPtuw = string("lyzGuvAZurwEFxMTVwPllkVkGAAQWgBPptyGmPBLwuryCxzbCcRtbPaLAAWCW");
    double stHnLW = 565546.6719719523;
    double QiduRhgfaWcOhS = -833539.0990787598;

    for (int TBowWWTeuhrcsD = 659099834; TBowWWTeuhrcsD > 0; TBowWWTeuhrcsD--) {
        QiduRhgfaWcOhS *= stHnLW;
    }
}

bool MkrON::CqvAJpX(int WFHwggVWUXyh, int ZJGLPjkRSl)
{
    double SugrvykCWDy = -910473.3530745545;
    int BNMjFi = 222342800;
    int PWbgyRwL = -164924908;
    double BbHjH = -288221.87910258735;
    int YROCGvt = -1481678578;
    int KmoLRbJ = -1520995442;

    for (int MdVGBWAZgRYOrsH = 338129772; MdVGBWAZgRYOrsH > 0; MdVGBWAZgRYOrsH--) {
        PWbgyRwL /= WFHwggVWUXyh;
        BbHjH *= SugrvykCWDy;
        BNMjFi += YROCGvt;
        BbHjH -= BbHjH;
    }

    if (ZJGLPjkRSl < 902307407) {
        for (int oDYbLcLcnVuDcMEr = 1523279165; oDYbLcLcnVuDcMEr > 0; oDYbLcLcnVuDcMEr--) {
            PWbgyRwL += ZJGLPjkRSl;
            SugrvykCWDy -= SugrvykCWDy;
        }
    }

    for (int aeIHtxCtaliy = 744673419; aeIHtxCtaliy > 0; aeIHtxCtaliy--) {
        YROCGvt *= KmoLRbJ;
        BbHjH += BbHjH;
        YROCGvt /= WFHwggVWUXyh;
    }

    return true;
}

int MkrON::eSYxNRxyXHYp()
{
    string rqmYEBot = string("fqBDnXBuNqDUIDPmCrIMsxwAoZVWIuKtSDRoTbTpNwyxPGCrDYaqWZFIABiYczctSRhVimHVrzIjSfiiqrmqZZsviRnvzbHlMgA");
    double jCskEyLwplTRUI = 1007556.4123008018;
    double igOsEzzvCnFtxia = -486548.32600831834;
    bool kfuuzoBLqRt = false;
    int UkVyAWA = -1978285040;
    int zSwDHRbkULWuLCXR = 1543146071;
    bool EffItyYlUJiDQ = true;

    for (int dispNzZxtXvK = 898595071; dispNzZxtXvK > 0; dispNzZxtXvK--) {
        continue;
    }

    if (kfuuzoBLqRt == true) {
        for (int tuHuTwbbmEHVb = 1055810364; tuHuTwbbmEHVb > 0; tuHuTwbbmEHVb--) {
            zSwDHRbkULWuLCXR /= UkVyAWA;
            igOsEzzvCnFtxia /= igOsEzzvCnFtxia;
        }
    }

    if (jCskEyLwplTRUI < 1007556.4123008018) {
        for (int aNpKEkhn = 133863799; aNpKEkhn > 0; aNpKEkhn--) {
            continue;
        }
    }

    return zSwDHRbkULWuLCXR;
}

double MkrON::uFzlNQZhbAqjp(double WTuVozBXZXEi, bool JOLpEFnAWskiaIRM, int zyLLng, bool FsSKwZLwQZI, double NErMedkb)
{
    int EqyDfOcgKj = -942658168;
    string PrdvaReSH = string("AgNLHTxHAPpgxQaPbsKXUTLVYYzyBbeCIJjazUCsrGfFWyzBiysGDWBUZpAAdGhzOjGeHKncmkHwinnsVVpHFLXJEBvMSNfEiobBmUSkhHrvzszgMxrvLbmFpUWsqUOluORiiXhGfUfa");
    double pFtKgXWrcILf = 268460.3364495748;
    double iSyssssuOqpmcrF = 840612.1993222086;
    string jdWlvzP = string("JfozvrIhKORabHIUMPJybdRbZUgqgbkQnTJEJygVLYFKubHTdnmTSIHEFbUExcoGaDqLWBhDvNobDCwWfSsAwuMbrEHkRKGapHGPcpVYmELVDCYneIUUFWiCacmNZzGVnzcmMXNmHBQcTnHKPXVREstYAXBTechBqjEjgcBZRYKEjZfrvxTwBDMNxxILDnyHmqRzqKWxThlMOLeIkccDDPyYplGEnnkjevaTkbOUdRVIhX");
    string mEXXpb = string("WvXrnAebKZekzOFcBCVMWSIxQxiwnFAeGdtDnncAIFihaWXcmWSSvMMWjXIScyZYkJdSTwXsaSWQmeMPQQJdaYxzgHBHbRINRDcEYNJaagYHyZymUjHkxNUcqGwpGZtqHPgocguKbIyXXrjlsqwDTZPnjcDCvbrQRlGkcgTQSJpbtRFvgMXVAEayob");
    int YFPAWzJHNRgbuOnP = -960064258;
    double hEutUXZoOHBUS = -1040524.2921233684;
    int lypnUycCRuOXR = 652943182;

    for (int qCQvqcD = 1132455341; qCQvqcD > 0; qCQvqcD--) {
        EqyDfOcgKj *= YFPAWzJHNRgbuOnP;
        WTuVozBXZXEi -= hEutUXZoOHBUS;
    }

    for (int iuXtINKVFJkpboYp = 820126827; iuXtINKVFJkpboYp > 0; iuXtINKVFJkpboYp--) {
        iSyssssuOqpmcrF *= iSyssssuOqpmcrF;
    }

    for (int yiPhba = 458795432; yiPhba > 0; yiPhba--) {
        jdWlvzP += PrdvaReSH;
        NErMedkb /= NErMedkb;
    }

    return hEutUXZoOHBUS;
}

string MkrON::eFzRG()
{
    int BgGNW = 1658130094;
    double iLryYT = -472975.7198594831;
    int CBAAFpxSDES = -1409095762;

    if (CBAAFpxSDES != -1409095762) {
        for (int fYxSpesioVi = 1148554355; fYxSpesioVi > 0; fYxSpesioVi--) {
            iLryYT -= iLryYT;
            CBAAFpxSDES *= CBAAFpxSDES;
            CBAAFpxSDES *= CBAAFpxSDES;
            BgGNW -= BgGNW;
        }
    }

    for (int VvHmSqYi = 2105977521; VvHmSqYi > 0; VvHmSqYi--) {
        continue;
    }

    if (BgGNW <= 1658130094) {
        for (int QbuFQ = 2066450997; QbuFQ > 0; QbuFQ--) {
            CBAAFpxSDES += BgGNW;
            CBAAFpxSDES += CBAAFpxSDES;
            CBAAFpxSDES /= BgGNW;
            CBAAFpxSDES = CBAAFpxSDES;
            CBAAFpxSDES += CBAAFpxSDES;
        }
    }

    for (int iowZbPcGxm = 190575097; iowZbPcGxm > 0; iowZbPcGxm--) {
        CBAAFpxSDES *= CBAAFpxSDES;
    }

    if (iLryYT == -472975.7198594831) {
        for (int ofLMfhseMV = 201547011; ofLMfhseMV > 0; ofLMfhseMV--) {
            continue;
        }
    }

    return string("oZcqskfMBALRkqiTgvsRBmXGulUIWrEwXbKYYKkfvZavhwlcPpMZmuYhdueQrHcTQxHKFmpTHownJfESDfhPyuHPeAhsewOapndEfFhAeyXxtGPMMVZxkxGeGMrFliRlxiwVEfEcRygSpBDoxoOOJyCDizTZZjVMCgPWIwZHsqAvDRJRKdQjdTZrQRibwUV");
}

int MkrON::xrPkHXqeng(string ZjEkzzPD, string fVaUKsWzFjoLHdb, double sSqqculoNReWZ)
{
    string Kflkb = string("xwVEEarQAZjAwiYaEVxkTbFyxygjckGGOqEzDZOTbnAmUQnEAGEJMMnjQUdOSJuJRKhXSkpVRbPGVIGxFUGUKPMOvmIkHrKmTXRDhQsmFHIbBsPPsUXkXlNjuLiJtXetZgtalfIJPRgXuUgYAXFtlYKzCeoYBbqVeODZhzvtIFvthljZUVMwvvGdOikfNhsdzWRFjvdfBKusMNLoiGojPReMifHpiejGtfsAsUIZdZOuzVWxdMmfJ");
    string KsovKIGip = string("qpmtoXVlsWukFioNMHnGiWyENxPIpShcCUBCByjZgxYhLbnQPjyKVQGnsSyBeAWcjydkCVRGNzNCNTDCvICsrgzOMObZNVSNQGxOCoydSpWRAgElmlBhfTNqsHBmkHXKuWOlSiEPMzJPKBwITQZtpyLJkRipcWYCvQjnOdxHvqZJQUSdsTr");
    string HoumQk = string("QobFwboGYDwWItKhVMcrXsJSDEMGPXzrzppzRDUwyGWsHYHbkCyTdZcJYfeHkfpyQJwgRtNlQHhwOaZHzvGhAiBOKnsqybFEuydPiKaLUtnBWDAHiWwNGExSLrZSlyhYEyPBMsIqevSpGikIsjbEzinBEHfnpHAqzDZTDBaFfQHPvwQRHbVtNLABVIMexEmRDTiokPEPgUsblfHkArSXiIKPuFlvQoJPKGhkAUKD");
    int ZBAEL = 248945693;
    int iRhSJp = 625430680;
    bool SVplU = true;

    for (int VTYjUVjCqeeVykI = 1115516616; VTYjUVjCqeeVykI > 0; VTYjUVjCqeeVykI--) {
        ZjEkzzPD = KsovKIGip;
        HoumQk += ZjEkzzPD;
        ZjEkzzPD += HoumQk;
    }

    for (int RbgWThTmTz = 583174232; RbgWThTmTz > 0; RbgWThTmTz--) {
        SVplU = ! SVplU;
        HoumQk = HoumQk;
        Kflkb = fVaUKsWzFjoLHdb;
        ZjEkzzPD += Kflkb;
    }

    if (Kflkb >= string("QobFwboGYDwWItKhVMcrXsJSDEMGPXzrzppzRDUwyGWsHYHbkCyTdZcJYfeHkfpyQJwgRtNlQHhwOaZHzvGhAiBOKnsqybFEuydPiKaLUtnBWDAHiWwNGExSLrZSlyhYEyPBMsIqevSpGikIsjbEzinBEHfnpHAqzDZTDBaFfQHPvwQRHbVtNLABVIMexEmRDTiokPEPgUsblfHkArSXiIKPuFlvQoJPKGhkAUKD")) {
        for (int rYNLkdk = 46477681; rYNLkdk > 0; rYNLkdk--) {
            continue;
        }
    }

    for (int yLZEneYNBCulmjvT = 1150541561; yLZEneYNBCulmjvT > 0; yLZEneYNBCulmjvT--) {
        KsovKIGip += KsovKIGip;
        fVaUKsWzFjoLHdb += HoumQk;
    }

    return iRhSJp;
}

void MkrON::JOLlB(double hejyINUtbYrWYJhq, double poklvoUwWGvyPo)
{
    double xfoDpqevnFHhtjO = 169156.81185085577;
    string YWvBSEGdwe = string("sQgXiOPftEMilqpvpZgDQkfkjPozgHowOjNZjvZUlbUkkQUZacENRSvaIyLUJfmKgDkZPDaupQseizKVWYDnqAmhCObTufUtsnRwdCaQWzgPjRsoeMfpQIaaozsZlBaZLagvPOsBkGMHgzioIdTEEKubvvLvFIcPcd");

    if (xfoDpqevnFHhtjO == -869092.6127828363) {
        for (int lqQEfTbSPSxfUQ = 733262636; lqQEfTbSPSxfUQ > 0; lqQEfTbSPSxfUQ--) {
            hejyINUtbYrWYJhq *= hejyINUtbYrWYJhq;
            xfoDpqevnFHhtjO -= hejyINUtbYrWYJhq;
            poklvoUwWGvyPo += xfoDpqevnFHhtjO;
            poklvoUwWGvyPo += hejyINUtbYrWYJhq;
            poklvoUwWGvyPo += hejyINUtbYrWYJhq;
            hejyINUtbYrWYJhq *= hejyINUtbYrWYJhq;
        }
    }

    for (int XjIVxGJvvaaMGg = 664877949; XjIVxGJvvaaMGg > 0; XjIVxGJvvaaMGg--) {
        hejyINUtbYrWYJhq *= xfoDpqevnFHhtjO;
    }

    if (xfoDpqevnFHhtjO < 334336.9704687865) {
        for (int hVRTrbTEweOShA = 1374839933; hVRTrbTEweOShA > 0; hVRTrbTEweOShA--) {
            xfoDpqevnFHhtjO /= xfoDpqevnFHhtjO;
            poklvoUwWGvyPo = xfoDpqevnFHhtjO;
            YWvBSEGdwe = YWvBSEGdwe;
            poklvoUwWGvyPo = poklvoUwWGvyPo;
            poklvoUwWGvyPo -= xfoDpqevnFHhtjO;
            YWvBSEGdwe = YWvBSEGdwe;
        }
    }

    if (xfoDpqevnFHhtjO <= -869092.6127828363) {
        for (int WyWIkDhtGAQQGgrp = 50544196; WyWIkDhtGAQQGgrp > 0; WyWIkDhtGAQQGgrp--) {
            YWvBSEGdwe += YWvBSEGdwe;
            xfoDpqevnFHhtjO += hejyINUtbYrWYJhq;
            poklvoUwWGvyPo += hejyINUtbYrWYJhq;
        }
    }

    if (hejyINUtbYrWYJhq == 169156.81185085577) {
        for (int HbPxBrFNoSShp = 787053599; HbPxBrFNoSShp > 0; HbPxBrFNoSShp--) {
            hejyINUtbYrWYJhq *= hejyINUtbYrWYJhq;
            YWvBSEGdwe += YWvBSEGdwe;
            hejyINUtbYrWYJhq -= hejyINUtbYrWYJhq;
        }
    }
}

string MkrON::LTSLbXWYJKPiSqW(double WCgHp, bool lFItvDmvnwJw, bool GOdNKEZ, double UzATYJhUybyMCV)
{
    int JFOTQpOtsN = -1587864858;
    string GMieIVxPXg = string("tBinoTyGvLs");
    int hCkVzYKJ = 598116837;
    double WmVTLToQEu = -460786.69593683793;
    int AbzZJgQFifwU = -1843088505;

    for (int bmRfh = 1637667932; bmRfh > 0; bmRfh--) {
        continue;
    }

    if (GMieIVxPXg == string("tBinoTyGvLs")) {
        for (int dHuUIpJFfTxJu = 73488453; dHuUIpJFfTxJu > 0; dHuUIpJFfTxJu--) {
            UzATYJhUybyMCV -= UzATYJhUybyMCV;
        }
    }

    return GMieIVxPXg;
}

bool MkrON::PUHoTsZB(string LrMQSjfYjLV, string jmRVMSfkxRoL, double uUmkGBty, double DHgTRUBZWsVjxBdx, int XSbbIuejAX)
{
    int kJFbeIcxyvnmn = -1823848165;
    string awLkoEtbKz = string("zeyKPTlPeLhwKtoNByylTKUuRHiScCKkPsqaDBQCXDuvdAqSJjQjOGypGzjyTxvpIaAhqqDzRwRTweHuwLIYMJ");
    bool zdwxSnZUtihIztE = false;
    int RISNXyrQrKQJ = 1710912395;
    bool XwwnxlB = false;

    if (kJFbeIcxyvnmn <= 1502022191) {
        for (int NDAniuYYSkcx = 699492728; NDAniuYYSkcx > 0; NDAniuYYSkcx--) {
            RISNXyrQrKQJ += RISNXyrQrKQJ;
            jmRVMSfkxRoL = awLkoEtbKz;
        }
    }

    if (kJFbeIcxyvnmn != 1502022191) {
        for (int fgIXBTXBPhlpzeK = 270045013; fgIXBTXBPhlpzeK > 0; fgIXBTXBPhlpzeK--) {
            RISNXyrQrKQJ /= XSbbIuejAX;
            LrMQSjfYjLV = jmRVMSfkxRoL;
        }
    }

    return XwwnxlB;
}

bool MkrON::AjiwI(bool lacQEobaE, bool imHjuKi, string BVGywGT, bool VFdMhqgBx, bool yEuJRgjb)
{
    bool sAGAiSmHpkLiUR = true;

    if (yEuJRgjb != false) {
        for (int JaVsidCisFDXhpo = 1850295008; JaVsidCisFDXhpo > 0; JaVsidCisFDXhpo--) {
            VFdMhqgBx = ! yEuJRgjb;
            yEuJRgjb = VFdMhqgBx;
            lacQEobaE = imHjuKi;
            imHjuKi = lacQEobaE;
            lacQEobaE = ! sAGAiSmHpkLiUR;
        }
    }

    return sAGAiSmHpkLiUR;
}

bool MkrON::nnJxUnoUTQKJXYBA()
{
    double QQOak = 631878.1841613424;
    bool lSPvGfbe = false;
    double cjfCerqhsY = 888198.6987249346;
    int WUNzgSfPVTsn = 977239702;

    for (int TkJwch = 1435960860; TkJwch > 0; TkJwch--) {
        cjfCerqhsY += QQOak;
        cjfCerqhsY = cjfCerqhsY;
        cjfCerqhsY = cjfCerqhsY;
        cjfCerqhsY -= QQOak;
        cjfCerqhsY -= cjfCerqhsY;
        cjfCerqhsY -= QQOak;
    }

    if (WUNzgSfPVTsn != 977239702) {
        for (int QyXygbAuB = 82035914; QyXygbAuB > 0; QyXygbAuB--) {
            QQOak += QQOak;
            lSPvGfbe = ! lSPvGfbe;
            cjfCerqhsY /= cjfCerqhsY;
            cjfCerqhsY /= QQOak;
        }
    }

    for (int zzNmdHBSvHdMk = 1927913338; zzNmdHBSvHdMk > 0; zzNmdHBSvHdMk--) {
        continue;
    }

    for (int FAzqZ = 543184714; FAzqZ > 0; FAzqZ--) {
        QQOak -= QQOak;
        lSPvGfbe = ! lSPvGfbe;
    }

    for (int FcgHbxIaao = 881015969; FcgHbxIaao > 0; FcgHbxIaao--) {
        continue;
    }

    return lSPvGfbe;
}

double MkrON::pmKLVDpVHE(string AMgtpgAURYBGFlRh, double QMSKhmMMRj)
{
    string zQTzMV = string("nxXwVBnrBDcDEmbOzoGCJRzETUXSlOTClvmmAwpOLasimlAYupMtXvcwbleSwzuedyNquOSVOTBbcUvpPeBtUUiYLZVRnVLIcjSlsZjxszxCWRPBTLvdaELyKUDpDcXXdchrnfrqiACWXEkANxousCIZh");
    string ChwhhjJMgU = string("mkiGZaOBOYWpTnTfQBxPziweRQeap");
    double IgJcIMhWlA = 61113.67974137187;
    string CBazCcpXAwoDQpTS = string("YVBcasnFQjBOfHTguYRYzopfZXYyAMgMjdzSirybvmYYDDUgnpZUyFfYmlnjgPqyoulboMGtmrKXrDdYWIZijeHihSQrHxWfVUKCyXMHbojjFsoOTWTmnlVSPNcxMuoSByrfxfUYmRaYRFgtJuqwicTYssdcbxjWkxnVVUSgbUJpfExMeFRcTsOVaFXLEczPSHDPLjwGiwFAmJEzMJibENaQWnZJQOkLLWGaJMPKFLIqVGiQamueET");
    int fnQnexFowZaM = -1484526036;
    int mFlEN = 1714837702;
    string ZtAcAcQahxxxq = string("APOTKNwOzIYsZJWJTdnXyRyeaeHsvUPfisEeHzAgxNVEHTKIfQlLGSkSZnKpPbFzDtGbKXGDBOgJUaikGrxhCCQSGlLOOoFGLwPysOBLgsWhRCyUYsVDryfSqjVetHkzYQwAUZMEVWLNrFaWIIuDhPRkSEEEHORpcLLXdEgeaJsrkIJVuATDSdLUJfuvfCcQrnDTxCbEsgmYxCwmlLZxjCLjMYs");
    string DXykscI = string("CUJBZfsPRDWbqhKGIdXVaZtRTwGCPdmFrqkMraOkxUDlGTsZUsOjCnKQeFzh");

    if (zQTzMV < string("YVBcasnFQjBOfHTguYRYzopfZXYyAMgMjdzSirybvmYYDDUgnpZUyFfYmlnjgPqyoulboMGtmrKXrDdYWIZijeHihSQrHxWfVUKCyXMHbojjFsoOTWTmnlVSPNcxMuoSByrfxfUYmRaYRFgtJuqwicTYssdcbxjWkxnVVUSgbUJpfExMeFRcTsOVaFXLEczPSHDPLjwGiwFAmJEzMJibENaQWnZJQOkLLWGaJMPKFLIqVGiQamueET")) {
        for (int MzyqkLZyJzTGAT = 1986232846; MzyqkLZyJzTGAT > 0; MzyqkLZyJzTGAT--) {
            DXykscI = ZtAcAcQahxxxq;
            zQTzMV += CBazCcpXAwoDQpTS;
            ChwhhjJMgU = zQTzMV;
            zQTzMV += zQTzMV;
        }
    }

    for (int KNgulYfZ = 2136786338; KNgulYfZ > 0; KNgulYfZ--) {
        CBazCcpXAwoDQpTS += AMgtpgAURYBGFlRh;
        DXykscI += ZtAcAcQahxxxq;
        AMgtpgAURYBGFlRh += DXykscI;
        zQTzMV = AMgtpgAURYBGFlRh;
        ChwhhjJMgU += DXykscI;
    }

    for (int yMuNcjulTKkzTnK = 1408278953; yMuNcjulTKkzTnK > 0; yMuNcjulTKkzTnK--) {
        DXykscI += ChwhhjJMgU;
        ChwhhjJMgU += zQTzMV;
        ZtAcAcQahxxxq += DXykscI;
        ChwhhjJMgU = zQTzMV;
    }

    return IgJcIMhWlA;
}

void MkrON::kzZxlcLX(bool MNLfyhxQtObThk, double WpPfChXKOrfjNA)
{
    int FcfSMfVopYx = 1953765077;
    int LhROhCPDcFDtRPo = 1302071572;
    double Kaqeej = -422886.9539723759;
    int JRjwacQLZTSt = -594035868;
    string nbAxacwQGpfjB = string("BVQbVQUitUnsgDviWPLPfbTdnODnGvfODDmiNTgwjJLYMcTMMGuHWcWxIwipoFieUVHewxqQexUinStKAIwoEYnGvHsjpKDgEvsYdsLCNJDLkCWnxkECPXdqMOLouuCszNvyQZGBnRyNvPXyyeiJIbLPhAakXTtRnSpCmV");
    string AOvyuQNbBLfZ = string("gOCAvQMBpXYkFk");
    int hHcGnsvXyPEr = 1455902144;

    if (FcfSMfVopYx < 1953765077) {
        for (int kdAAAaLWvv = 111927721; kdAAAaLWvv > 0; kdAAAaLWvv--) {
            AOvyuQNbBLfZ += AOvyuQNbBLfZ;
            JRjwacQLZTSt /= JRjwacQLZTSt;
            LhROhCPDcFDtRPo = FcfSMfVopYx;
        }
    }

    for (int bHymF = 1427414416; bHymF > 0; bHymF--) {
        JRjwacQLZTSt += LhROhCPDcFDtRPo;
        LhROhCPDcFDtRPo -= hHcGnsvXyPEr;
        JRjwacQLZTSt -= FcfSMfVopYx;
        WpPfChXKOrfjNA += Kaqeej;
    }

    for (int waJCcJcehxEXxYt = 119051779; waJCcJcehxEXxYt > 0; waJCcJcehxEXxYt--) {
        JRjwacQLZTSt += FcfSMfVopYx;
    }

    for (int oYgiglXbDKix = 857795649; oYgiglXbDKix > 0; oYgiglXbDKix--) {
        hHcGnsvXyPEr *= LhROhCPDcFDtRPo;
        AOvyuQNbBLfZ += AOvyuQNbBLfZ;
    }
}

bool MkrON::zfndGclTHVuRh()
{
    int WFpnwJpOMoLmxfp = 1318087981;
    string hILXqZCrwhW = string("YTQVzOvVYOFDTdeIhdajPXeIhXHNMkTPWrLPyiTGfzAwcRbyiBcuTUMDgSvBdKBmLhiTvTfnpRoFEzjbxVHxIMjVhNONqbTFNAGHUvMJxNJqlBoVKIydEaeXCARRHOCzZkMzggRuwzuNoiTYeXlRqSFUMBiiWGdQvbNcUzlatmT");
    bool wkKCubAttscp = false;
    double vZniGWKoiOoqlS = -625650.0479570102;
    int oTqfaZDtI = -1842008491;
    bool EIEeYw = true;
    bool cCPyYNWnJNuidgZY = false;

    for (int DgIxX = 953587883; DgIxX > 0; DgIxX--) {
        cCPyYNWnJNuidgZY = EIEeYw;
    }

    if (WFpnwJpOMoLmxfp > 1318087981) {
        for (int eUziZekGfaIUkRWC = 2049520708; eUziZekGfaIUkRWC > 0; eUziZekGfaIUkRWC--) {
            continue;
        }
    }

    for (int JniAOo = 1693139388; JniAOo > 0; JniAOo--) {
        cCPyYNWnJNuidgZY = ! EIEeYw;
        cCPyYNWnJNuidgZY = ! wkKCubAttscp;
        oTqfaZDtI *= WFpnwJpOMoLmxfp;
        hILXqZCrwhW = hILXqZCrwhW;
    }

    for (int mfKQE = 111262544; mfKQE > 0; mfKQE--) {
        continue;
    }

    return cCPyYNWnJNuidgZY;
}

bool MkrON::ukyIwkdzX(bool QzbBhJvHaHU, int mjtss, bool BEyzBnuqAlfkSoEp, string BjfKLDzZv)
{
    string qkUDoNoCedvF = string("EUIGJFwFhfGweuRJWYKcGQWDvyBVRiIfvjsegcGZPoUswftJOLojAdSKcyrWXTemmVUraknsD");
    double bEqQJwxieqX = 190384.07839179;
    bool jFnNQgamItBW = false;
    string AJVMmpYqUTJ = string("qVLzEgZsizWxKbxXnhUXmoLiVeABBvfQMrOScSfBqXXyqiQimrallpvjugpfYpFWhsJwLhUcTKWeGHFyqyGRPwRmxiBxBngtCdNPkmKLohZCVcFuVTCdLDPeMbqDfgqqsWWrkHHTmsEqIwvnmLlFcewykPlXqSbZrsNNxmRpGhrGfcAykVwdkOrbDvzlkTgoVg");
    double nfIvPkcZe = 432703.5195957964;
    double JbrQHOaXMnipjG = -553443.5335106987;
    string PylXXAoTs = string("pxfifoTDiuoNzMWoowSrkPsphVRiojXudCNUMTmTnwqoRubeYGqClmqxrABeRNavBogjsaol");

    if (AJVMmpYqUTJ >= string("pxfifoTDiuoNzMWoowSrkPsphVRiojXudCNUMTmTnwqoRubeYGqClmqxrABeRNavBogjsaol")) {
        for (int smQHBNLgeJgQKtQf = 335106465; smQHBNLgeJgQKtQf > 0; smQHBNLgeJgQKtQf--) {
            BjfKLDzZv = PylXXAoTs;
            qkUDoNoCedvF += PylXXAoTs;
        }
    }

    for (int LOOhWVZXuZ = 771810964; LOOhWVZXuZ > 0; LOOhWVZXuZ--) {
        qkUDoNoCedvF = AJVMmpYqUTJ;
        JbrQHOaXMnipjG -= JbrQHOaXMnipjG;
        AJVMmpYqUTJ += AJVMmpYqUTJ;
        jFnNQgamItBW = QzbBhJvHaHU;
    }

    for (int LCMOlNTSjY = 1451460415; LCMOlNTSjY > 0; LCMOlNTSjY--) {
        continue;
    }

    return jFnNQgamItBW;
}

void MkrON::XbuNQRLsbNl()
{
    bool JPAqJqwZA = true;

    if (JPAqJqwZA != true) {
        for (int gKoQDqLO = 222365801; gKoQDqLO > 0; gKoQDqLO--) {
            JPAqJqwZA = ! JPAqJqwZA;
            JPAqJqwZA = ! JPAqJqwZA;
            JPAqJqwZA = JPAqJqwZA;
        }
    }
}

MkrON::MkrON()
{
    this->SExuxwSeTAqXk(false);
    this->kkbDlvLrj(1007700.1489700952, -1387482449, -307852330, -99647.3347020042, string("MmQytRITAuGeTBJdlTIPqvINsnBXJCsIcCXvGeREMlSJjkSGaYklLExFwMeqSZaNJ"));
    this->fsqhRxw(true, string("CfMKfwoUeyjClSEDEPHHBLeBaPRBCSmEgmCFxsTwWpRkvgEFWPFYaTHAeOzxbpVemVEVJJwHSzgulYnUniOSguddiKqAAbATwaMdwsxspvfDbCWumZdeYZykULbfeNAEKKtIeCIzbqd"), -927589224, -935303.5539276687, 66646.12724353086);
    this->CqvAJpX(902307407, 435055948);
    this->eSYxNRxyXHYp();
    this->uFzlNQZhbAqjp(-398458.29154466593, true, -473848907, false, -127038.51801643988);
    this->eFzRG();
    this->xrPkHXqeng(string("cduGjsoATOBQHXJcSoOcCZWxFaHbPAZFoWNXfyRqLOFLbrmtBkLoByTREBTvTTICueaOqLEx"), string("UkThBgPXKayBsqHQwQUXsvOLjXINoCrsAqSQWmppMhhltgIaDiVVCHpYqrIDtentOEKVFSd"), 874400.0814772178);
    this->JOLlB(-869092.6127828363, 334336.9704687865);
    this->LTSLbXWYJKPiSqW(555769.3545213765, false, true, 853631.2347037727);
    this->PUHoTsZB(string("QjSSYOYoTuRuvXECyrcLNZmMLeKkEnhBrnTxVfiQTVXtCykMHhijpYEgZAApvIxOybLAGiZSIgeL"), string("rjKEbDSSpcrWbXZWdMeiUfsbNnotvrhKMDNOzEXoNxrfgnkrpLkfKHetmoNrshxKDnKkEBviwaACASgXMDxOoOTKIYrdWyvVRGihkrHsNzD"), 812062.6776943634, -974934.4741280624, 1502022191);
    this->AjiwI(false, false, string("eKskyduHAKvFFYlVQcgAkmfDdgVTJhBzJgNhnAxfsDEXXRzZLuSgRyxpQcHaBrffWbfmMlGfVhmUONAmTbGIaumVjumELhq"), false, false);
    this->nnJxUnoUTQKJXYBA();
    this->pmKLVDpVHE(string("tQpkaYPusPieyuNgEQRlhxabPhiIpHyNiDiSBgpLoqHKYVGoWnRYzDeVzKGxrTvPnceleakOwiqZMYBGkhzNXLQNvmTCanuVZzkvDmQuLydYwOugfwcoioVQRBCuRCBNzBqnGsflrNtObnXwOZhfHUZuptLHPUGDilQsJLvPXUXjgS"), 510470.2181314262);
    this->kzZxlcLX(true, 916754.7528223972);
    this->zfndGclTHVuRh();
    this->ukyIwkdzX(false, -846763381, true, string("fmPkkyxSAv"));
    this->XbuNQRLsbNl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dvXpFjosrdKNQlSS
{
public:
    double QusYDTB;
    double NKJhG;
    bool oDwbPt;
    int CDNYc;

    dvXpFjosrdKNQlSS();
    string MuuOEaR(int MwakJBpYK, double saGzoyUdjqzy, double YedaxWqmpUNaOQlv);
    string oNmZYwM(double fwfRqiMxKneTwjO, string yXpcKQLOFmicYZNF);
    int gNGGM(int yYljUhQBT, int BfJuNgaHf);
    double mLMkG();
protected:
    bool EUDQZsJRqLk;
    bool qEXhi;
    string hrDkUT;
    double lCXXcNmGFoZhIXr;
    bool rfIdPeVI;

private:
    string RpSnR;
    double dNEKyP;
    bool UnVBwr;
    bool iqdDfQM;

    bool hyNHDh(string HiGdmZuszY, string bkXKnyxgnM);
    double SSLIqdlZXf();
};

string dvXpFjosrdKNQlSS::MuuOEaR(int MwakJBpYK, double saGzoyUdjqzy, double YedaxWqmpUNaOQlv)
{
    bool TGCcZIc = false;
    int nGvDfLCykzIzTZC = 782666347;
    int jZMPPgOAhsoQj = 412666480;
    double kZYDPaznQveJ = -850343.1763301529;
    double awoie = -122261.57245975942;
    string AwAvAnoA = string("IBESzzGxhkppOoVfSGJyuhEO");
    double fBGkDfDfTnLIh = -405059.61170027877;
    double GGqFDrFKMXRO = 932322.2607855129;
    int OrBXnRTi = 862546908;

    for (int lzWvMeemLwUXQmU = 920945213; lzWvMeemLwUXQmU > 0; lzWvMeemLwUXQmU--) {
        kZYDPaznQveJ = fBGkDfDfTnLIh;
        saGzoyUdjqzy *= saGzoyUdjqzy;
        saGzoyUdjqzy /= awoie;
        saGzoyUdjqzy = fBGkDfDfTnLIh;
        YedaxWqmpUNaOQlv /= GGqFDrFKMXRO;
        fBGkDfDfTnLIh += GGqFDrFKMXRO;
    }

    for (int vMrJN = 450193942; vMrJN > 0; vMrJN--) {
        kZYDPaznQveJ = fBGkDfDfTnLIh;
        jZMPPgOAhsoQj *= nGvDfLCykzIzTZC;
    }

    for (int ShMefyNsianLfKgc = 1249637675; ShMefyNsianLfKgc > 0; ShMefyNsianLfKgc--) {
        jZMPPgOAhsoQj += MwakJBpYK;
        GGqFDrFKMXRO -= saGzoyUdjqzy;
        fBGkDfDfTnLIh += awoie;
    }

    for (int ZZhoEHHITAm = 809781931; ZZhoEHHITAm > 0; ZZhoEHHITAm--) {
        continue;
    }

    if (YedaxWqmpUNaOQlv > -613771.3378631573) {
        for (int MYsJownMQJGsisJh = 482569468; MYsJownMQJGsisJh > 0; MYsJownMQJGsisJh--) {
            MwakJBpYK -= nGvDfLCykzIzTZC;
            YedaxWqmpUNaOQlv -= GGqFDrFKMXRO;
        }
    }

    if (jZMPPgOAhsoQj >= 862546908) {
        for (int AEdYhcQyegwssng = 1202062701; AEdYhcQyegwssng > 0; AEdYhcQyegwssng--) {
            GGqFDrFKMXRO = awoie;
            YedaxWqmpUNaOQlv /= YedaxWqmpUNaOQlv;
            saGzoyUdjqzy /= YedaxWqmpUNaOQlv;
            MwakJBpYK *= OrBXnRTi;
        }
    }

    return AwAvAnoA;
}

string dvXpFjosrdKNQlSS::oNmZYwM(double fwfRqiMxKneTwjO, string yXpcKQLOFmicYZNF)
{
    bool QHebXYPqc = true;
    int faATAbmNzSdjf = -716863130;
    double kLeMtdJehG = -104364.88501311817;
    int HwtDPaAvTteFasoZ = 1372939684;
    string jHwmwDWIeFoH = string("xKCUuHCSQnqRrifdKOqHCfKgGLoJRCnzJQuKCuiImdfHZOyCHCjljnCKSfRHWbLSVHmIfGYbOEeKayrOZAgShvhOMfyxogPmcRZYZTscggsrbOoSsgpCmQqHloMBWYamniyGaFiGytVaWjJdNbOObPPyMNAmWLJJlolwshgFnrqvKeWlrGQmqGQCpDLzsPMctHGsjfsOjzRHNsbzlpd");

    for (int DVCTy = 362893333; DVCTy > 0; DVCTy--) {
        jHwmwDWIeFoH += yXpcKQLOFmicYZNF;
        fwfRqiMxKneTwjO -= kLeMtdJehG;
        QHebXYPqc = QHebXYPqc;
    }

    if (HwtDPaAvTteFasoZ <= -716863130) {
        for (int qXyfdjnZBPqyHnId = 1298236167; qXyfdjnZBPqyHnId > 0; qXyfdjnZBPqyHnId--) {
            kLeMtdJehG = kLeMtdJehG;
            yXpcKQLOFmicYZNF = yXpcKQLOFmicYZNF;
        }
    }

    if (fwfRqiMxKneTwjO > -278606.9263086413) {
        for (int dRKtFIgJPtU = 158780250; dRKtFIgJPtU > 0; dRKtFIgJPtU--) {
            continue;
        }
    }

    if (fwfRqiMxKneTwjO >= -278606.9263086413) {
        for (int FLeVB = 531290893; FLeVB > 0; FLeVB--) {
            faATAbmNzSdjf = HwtDPaAvTteFasoZ;
            jHwmwDWIeFoH = yXpcKQLOFmicYZNF;
            fwfRqiMxKneTwjO = fwfRqiMxKneTwjO;
            HwtDPaAvTteFasoZ -= HwtDPaAvTteFasoZ;
        }
    }

    return jHwmwDWIeFoH;
}

int dvXpFjosrdKNQlSS::gNGGM(int yYljUhQBT, int BfJuNgaHf)
{
    int fbczUnnMCJbsvkk = 512462621;
    double yOFNKtQuGzH = -22862.920879957703;
    double VTTNZrYR = -792126.449478224;
    string hKVZHWtKVimeVCl = string("jQMJGJnAtWgUUUppyuLCWmyRTJtquYjoHLohiMeTgTBnmXaXyJcZKqSxZueudCtTUsxdpRdXphEAFLNNZfSnZ");
    bool KGWfdwNUjISHPBak = true;
    double tRMHVELFHqsftkkF = -392971.61755858915;
    double MYPARIRsbtJi = 425311.5509614107;
    bool UAZdkOCVZaXlQ = true;
    int bJvrRFIKVelJvcZi = 744826164;
    string FgXcRKgzkzDXkw = string("nMtGGUyifdFAcWnxlljabHmqCAWSvPvCaOYDBffJTzoaiSoCGys");

    for (int GlbkGaCwNX = 1974869529; GlbkGaCwNX > 0; GlbkGaCwNX--) {
        fbczUnnMCJbsvkk += yYljUhQBT;
        FgXcRKgzkzDXkw = hKVZHWtKVimeVCl;
    }

    for (int hPbwaqnxkmY = 977285449; hPbwaqnxkmY > 0; hPbwaqnxkmY--) {
        tRMHVELFHqsftkkF = VTTNZrYR;
        VTTNZrYR -= VTTNZrYR;
        tRMHVELFHqsftkkF *= yOFNKtQuGzH;
    }

    for (int yfjbhGwDXAn = 191204741; yfjbhGwDXAn > 0; yfjbhGwDXAn--) {
        continue;
    }

    for (int TiKfJnUu = 1101768162; TiKfJnUu > 0; TiKfJnUu--) {
        fbczUnnMCJbsvkk = bJvrRFIKVelJvcZi;
    }

    for (int zimOINS = 64179567; zimOINS > 0; zimOINS--) {
        yOFNKtQuGzH -= MYPARIRsbtJi;
    }

    if (yYljUhQBT <= 512462621) {
        for (int nBGIkTTI = 1558395707; nBGIkTTI > 0; nBGIkTTI--) {
            yYljUhQBT -= BfJuNgaHf;
            fbczUnnMCJbsvkk -= fbczUnnMCJbsvkk;
        }
    }

    if (MYPARIRsbtJi >= -392971.61755858915) {
        for (int IyWYtbsMzRKrR = 152304168; IyWYtbsMzRKrR > 0; IyWYtbsMzRKrR--) {
            yYljUhQBT = fbczUnnMCJbsvkk;
            UAZdkOCVZaXlQ = ! KGWfdwNUjISHPBak;
        }
    }

    return bJvrRFIKVelJvcZi;
}

double dvXpFjosrdKNQlSS::mLMkG()
{
    string pfkDqlEnfoiVN = string("ennoLwEQBTlUKTJpINMqBVKUiWpnaPVaGtgyaEFLqEPR");
    int DgTjZC = 1051492540;

    for (int vcLtjRAa = 1897478570; vcLtjRAa > 0; vcLtjRAa--) {
        pfkDqlEnfoiVN = pfkDqlEnfoiVN;
        DgTjZC *= DgTjZC;
        DgTjZC *= DgTjZC;
        DgTjZC /= DgTjZC;
        pfkDqlEnfoiVN += pfkDqlEnfoiVN;
    }

    if (pfkDqlEnfoiVN > string("ennoLwEQBTlUKTJpINMqBVKUiWpnaPVaGtgyaEFLqEPR")) {
        for (int iakCET = 2046818636; iakCET > 0; iakCET--) {
            pfkDqlEnfoiVN += pfkDqlEnfoiVN;
        }
    }

    return -950961.5960911141;
}

bool dvXpFjosrdKNQlSS::hyNHDh(string HiGdmZuszY, string bkXKnyxgnM)
{
    string xgScFYqSZCHIB = string("hTyIdFCqmuaWqHvSLzRIWzxPlHXBxvidbIEShEHxpxJTgQXUipkgvQufAHQHPXeiWBdFETeedZQjBkSXgKsjVFOGSgpviUxPkyXJIbTTWjxoIwNieHCNsAhqkQQrOHSlnxlWuVEdCGsJCEtTjKktpdERXKJWKmHLuPDcsKAkVtiQHUxEjmWMQeOqOfoLnrsOeVELWpIPCVbaKztRe");
    bool SgEKe = false;
    double KvyGhNXz = 212271.02091917593;
    double yctqK = -291959.7649094697;
    string iwwvrSmW = string("AOalrFOvUwvnnHQhyWOeIVwEIFIyYAYcMiihYYbMVODqeRYgzVWVQNMGTzHwlbCqGtyJuIIHHxwHlZDkjPpzqKRXJvtpFejNdQhtErTDONFijzlxXMUifnGfSowcqbthYEZHbWiYISXDSeawd");
    int oNwWVTlcCJrGdjaO = -211170328;
    string YNuwmzzhSHmaa = string("geMMkEwGOMnRuUAdapDkpQSDzbnGHuJpDjdRHEztxWyfLkYwCSgYHnyYQETIltyScsOZKwTPTSVFbeJGDbWqFeAtACUZVesfOkThjcIGrEtJrCpjWEblMvTztOaxEweQrlDFssOywpVeDPAZGNwvdkijmDfYQAucxRMfbFKvTESkXPAQSPTiZoiYbgHBlHShPTJPMolg");

    for (int APxGx = 1088666467; APxGx > 0; APxGx--) {
        bkXKnyxgnM += iwwvrSmW;
        HiGdmZuszY = bkXKnyxgnM;
        HiGdmZuszY = iwwvrSmW;
    }

    if (xgScFYqSZCHIB != string("hTyIdFCqmuaWqHvSLzRIWzxPlHXBxvidbIEShEHxpxJTgQXUipkgvQufAHQHPXeiWBdFETeedZQjBkSXgKsjVFOGSgpviUxPkyXJIbTTWjxoIwNieHCNsAhqkQQrOHSlnxlWuVEdCGsJCEtTjKktpdERXKJWKmHLuPDcsKAkVtiQHUxEjmWMQeOqOfoLnrsOeVELWpIPCVbaKztRe")) {
        for (int pklvvOCpffKSqC = 742263745; pklvvOCpffKSqC > 0; pklvvOCpffKSqC--) {
            YNuwmzzhSHmaa += YNuwmzzhSHmaa;
        }
    }

    if (HiGdmZuszY != string("hTyIdFCqmuaWqHvSLzRIWzxPlHXBxvidbIEShEHxpxJTgQXUipkgvQufAHQHPXeiWBdFETeedZQjBkSXgKsjVFOGSgpviUxPkyXJIbTTWjxoIwNieHCNsAhqkQQrOHSlnxlWuVEdCGsJCEtTjKktpdERXKJWKmHLuPDcsKAkVtiQHUxEjmWMQeOqOfoLnrsOeVELWpIPCVbaKztRe")) {
        for (int rIJdW = 126083534; rIJdW > 0; rIJdW--) {
            bkXKnyxgnM += xgScFYqSZCHIB;
        }
    }

    for (int zjbKHnjJuvc = 1527850244; zjbKHnjJuvc > 0; zjbKHnjJuvc--) {
        oNwWVTlcCJrGdjaO += oNwWVTlcCJrGdjaO;
    }

    if (bkXKnyxgnM < string("geMMkEwGOMnRuUAdapDkpQSDzbnGHuJpDjdRHEztxWyfLkYwCSgYHnyYQETIltyScsOZKwTPTSVFbeJGDbWqFeAtACUZVesfOkThjcIGrEtJrCpjWEblMvTztOaxEweQrlDFssOywpVeDPAZGNwvdkijmDfYQAucxRMfbFKvTESkXPAQSPTiZoiYbgHBlHShPTJPMolg")) {
        for (int qHahHxahfgKsSqZ = 2008581713; qHahHxahfgKsSqZ > 0; qHahHxahfgKsSqZ--) {
            bkXKnyxgnM = bkXKnyxgnM;
        }
    }

    return SgEKe;
}

double dvXpFjosrdKNQlSS::SSLIqdlZXf()
{
    bool aGGxGyW = false;
    int QSArvmbag = -154794416;

    if (QSArvmbag != -154794416) {
        for (int FVFbVjBIBG = 1610398472; FVFbVjBIBG > 0; FVFbVjBIBG--) {
            QSArvmbag -= QSArvmbag;
            aGGxGyW = aGGxGyW;
        }
    }

    for (int UlJShtNDPanVxoV = 1018635366; UlJShtNDPanVxoV > 0; UlJShtNDPanVxoV--) {
        continue;
    }

    for (int WOKqVrO = 864710090; WOKqVrO > 0; WOKqVrO--) {
        QSArvmbag = QSArvmbag;
        aGGxGyW = ! aGGxGyW;
        QSArvmbag *= QSArvmbag;
        QSArvmbag += QSArvmbag;
        QSArvmbag = QSArvmbag;
    }

    for (int HvPPeZLUc = 1954919577; HvPPeZLUc > 0; HvPPeZLUc--) {
        aGGxGyW = ! aGGxGyW;
        QSArvmbag /= QSArvmbag;
        aGGxGyW = ! aGGxGyW;
    }

    return -203330.1913515181;
}

dvXpFjosrdKNQlSS::dvXpFjosrdKNQlSS()
{
    this->MuuOEaR(1380239125, 545375.605845167, -613771.3378631573);
    this->oNmZYwM(-278606.9263086413, string("jCvHmstUwoDLxPQtTdlVTOAZsqQmKFzMTjsyazeGSbsaRVJpkPCDEuWBmWguYoWxDNWURQwLipdnMVtFomAIngcTosAcsyLDtyWyyLWcFeycjlyeRTMJohgcdcpuyhYsReDTHjLWEWTItAEZBgO"));
    this->gNGGM(863079455, -2069629946);
    this->mLMkG();
    this->hyNHDh(string("NXqnXBFQoYKbbvmcHVMgpLDqcocgNATCvhDAWhuhgeFWUfXbtwCYMJInoZFIYqdGheIERmJNFOymTMDsUlSjOKCGdLAFdUeSRGhQnCsHjuYBSYpLAYhZCTFhUNjfLGEbsodGyXkdclAoUQWK"), string("tzdFvgFpemexonkBTIBDdPxTnHNpHAEfdtlmTAUJjDHDhVfvxmNrfyBFTQOtOwaAdwOHfRTqCdmFdpkrbXRMcPXDnoLMuthfpnOZuNPzhWCEcPGyFNmHpgNilRmujiYyrHDyGHvzZaPfSPgzzKChucullmlYpDrAuDpXsnpwHUuEJlXLmlrLTrVeADLAoPZPUjEWHiuKJwPkFKPCqEriNJcxlGpHKQEIUNvCgK"));
    this->SSLIqdlZXf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IwcON
{
public:
    string UYiYcOBFEPgqIZse;
    bool uPlsgZwgfJO;

    IwcON();
    string xDKPWHLoikqSFKc(bool AkBlDuwshg, double hnrSnSB);
    int AMSIkp();
    double PXAnmeT(string VwzcuKPFVsKgKiju, bool GsljMJcHWxWJ, bool OIFjdccpJZhBVT, bool ZJHcbhI);
    int ImLmPf(bool UnVmuVQ, double qQKsMMTEJOMqW, bool GWptnf, double LaGuhrF, string ltpKYwTCPm);
protected:
    string ctruxTdXiT;
    double oNDKObq;
    bool HXpeMaDyk;

    string ZIUxcIzRFyqUjUh(int ssPKnkeAEJxwM, string JulHaCLJNCP, int nQrgTAZxSvuQLOf, bool MvYowkenjCix);
private:
    bool tTeMp;
    string IFqzcgKxMLXYse;
    string zBpCdizLHE;
    double TUUXKhMmtraxSO;
    bool zQhvnACRymy;

};

string IwcON::xDKPWHLoikqSFKc(bool AkBlDuwshg, double hnrSnSB)
{
    double xVnqaJsMk = 83899.31968595838;
    string hLxvnzzAUjzXHP = string("ZFOUfztGsilJVDLATRVUf");
    double QjOXFSfasE = -199944.4894617218;
    int STTnPKJOe = 135859338;
    double IcigjtZxdqOQTUDU = -101027.66274490835;

    for (int jonlKfoBZ = 1572931157; jonlKfoBZ > 0; jonlKfoBZ--) {
        continue;
    }

    for (int mTrmLYsGZcZocVm = 1707634346; mTrmLYsGZcZocVm > 0; mTrmLYsGZcZocVm--) {
        hnrSnSB *= hnrSnSB;
    }

    for (int xFbohhZRgk = 1601262382; xFbohhZRgk > 0; xFbohhZRgk--) {
        xVnqaJsMk = xVnqaJsMk;
    }

    return hLxvnzzAUjzXHP;
}

int IwcON::AMSIkp()
{
    int qgZRihOyoEnWBs = -1276558642;
    double tCeaZIJmHebU = 576403.987336934;

    return qgZRihOyoEnWBs;
}

double IwcON::PXAnmeT(string VwzcuKPFVsKgKiju, bool GsljMJcHWxWJ, bool OIFjdccpJZhBVT, bool ZJHcbhI)
{
    int jSMBZOGx = -94736059;
    double POmrTkBijI = 898865.699861984;
    string bvsrQHQB = string("fXR");
    int qMfvhu = -1026291750;
    string aaPJYNnZbARBhfyd = string("DrBqZifnILCPUYDuOUhBTYI");
    bool yrArmnrftcehgX = false;
    string fHfEVNrhHkzCsjn = string("SEGbYTwemQtAqiQdPBGRYgfxCaaYpjrgowvvtqsMjiGhzPxOfPNSCWmaSXVOZHBagjjtFjJdHnHNpupxOBAvdCVciZVYXtYATOdkZKQzrxmPzDbJJauDXBfYmQaftjHHZcDPSTFKUaDdHGZ");
    int utZarPKrZBGhV = 1199693007;

    for (int BhmPGqkyPcfqXn = 1593215000; BhmPGqkyPcfqXn > 0; BhmPGqkyPcfqXn--) {
        bvsrQHQB = bvsrQHQB;
        ZJHcbhI = OIFjdccpJZhBVT;
    }

    if (fHfEVNrhHkzCsjn == string("DrBqZifnILCPUYDuOUhBTYI")) {
        for (int NKgLTxgmyvRWIETL = 843807660; NKgLTxgmyvRWIETL > 0; NKgLTxgmyvRWIETL--) {
            continue;
        }
    }

    for (int IhaUuhPNP = 1706875858; IhaUuhPNP > 0; IhaUuhPNP--) {
        VwzcuKPFVsKgKiju += VwzcuKPFVsKgKiju;
        jSMBZOGx *= qMfvhu;
        ZJHcbhI = ! GsljMJcHWxWJ;
        fHfEVNrhHkzCsjn += fHfEVNrhHkzCsjn;
    }

    return POmrTkBijI;
}

int IwcON::ImLmPf(bool UnVmuVQ, double qQKsMMTEJOMqW, bool GWptnf, double LaGuhrF, string ltpKYwTCPm)
{
    int QSyZRtLctKmO = -1111405430;
    string mSbntM = string("ZmrscVsyKtpCRTScvIEIemVTDNtxWMedARcMdCNqvozKxAXnnnRwvWKeTsiaxfoRyDAeUMiXKqzPwMPZvgCbMMzdrSlyfMkNmngBfgytVbxgHFLCKxlvJxPyJpdETVBfVhcgFMNmUesdTuZmzUrHTLHeHpmZTZdoetzpZzLCWFeNyUAzdUNVCKrLAWBRUkOgocfwwYvdjsZWCRIIlObtZrXULwkAQQpiSaLlpzRmHYlNxZ");
    bool bTkrwNVGJQp = false;
    int KgpgnPmOntwd = 253290207;
    double KLrLbRqZxamKkwV = 244853.30015448786;
    double LEgKIwZHMmHNYw = 964523.0612362262;

    for (int HVTZBWLnq = 1785959080; HVTZBWLnq > 0; HVTZBWLnq--) {
        KgpgnPmOntwd *= QSyZRtLctKmO;
    }

    for (int oALrCOp = 2119144839; oALrCOp > 0; oALrCOp--) {
        mSbntM += mSbntM;
        GWptnf = UnVmuVQ;
        KgpgnPmOntwd = QSyZRtLctKmO;
    }

    for (int jBgMBr = 377090770; jBgMBr > 0; jBgMBr--) {
        KLrLbRqZxamKkwV -= KLrLbRqZxamKkwV;
    }

    return KgpgnPmOntwd;
}

string IwcON::ZIUxcIzRFyqUjUh(int ssPKnkeAEJxwM, string JulHaCLJNCP, int nQrgTAZxSvuQLOf, bool MvYowkenjCix)
{
    int jiHLFhX = 157853277;

    for (int hEmBZWlw = 1935077239; hEmBZWlw > 0; hEmBZWlw--) {
        ssPKnkeAEJxwM = nQrgTAZxSvuQLOf;
        JulHaCLJNCP += JulHaCLJNCP;
    }

    for (int FBkevabkRFxZ = 158038191; FBkevabkRFxZ > 0; FBkevabkRFxZ--) {
        jiHLFhX += nQrgTAZxSvuQLOf;
        nQrgTAZxSvuQLOf = ssPKnkeAEJxwM;
        jiHLFhX *= jiHLFhX;
    }

    for (int nsjWSyjumd = 480492362; nsjWSyjumd > 0; nsjWSyjumd--) {
        nQrgTAZxSvuQLOf -= ssPKnkeAEJxwM;
        jiHLFhX += ssPKnkeAEJxwM;
    }

    if (MvYowkenjCix == true) {
        for (int KILIbtfdj = 2134531480; KILIbtfdj > 0; KILIbtfdj--) {
            jiHLFhX /= nQrgTAZxSvuQLOf;
            ssPKnkeAEJxwM *= jiHLFhX;
            nQrgTAZxSvuQLOf /= nQrgTAZxSvuQLOf;
            nQrgTAZxSvuQLOf = ssPKnkeAEJxwM;
            MvYowkenjCix = MvYowkenjCix;
        }
    }

    return JulHaCLJNCP;
}

IwcON::IwcON()
{
    this->xDKPWHLoikqSFKc(true, -454636.5877624248);
    this->AMSIkp();
    this->PXAnmeT(string("nFqaeyXoYfOxzERTZijvTMQBnhaLUNXDLFmjtHSgGdwSriZRaMUWTzqhgoHNHdusfhDAUCbzvshBMKUVgsqKDbopynPeGNxZPzCsAevNbNQtTinHcECdLhRmbrSxJnTOqIlWBlVOeHmVohXJnmLtKlFKDvdiOTnaTnMAlXXopWfe"), false, false, true);
    this->ImLmPf(true, 1026102.1058023169, false, 952385.246953829, string("McZKhgAio"));
    this->ZIUxcIzRFyqUjUh(330367297, string("HkdrCHMvBAZJDdRRQCqXzbYkALaTpcOpCaCfCcWeeYTmYcfmLPHRqOPbZyvBQHMcoUmwWfRnOqpoTUqnUWhUHGOTrrJmKmTGXYjDfPYZiwbIypBBGKOPbTOcbtCXyeKvYEUKUsrtRCZsZfXwCGJFVlXaWuPWTTKwgMkLQtSeoFfpwtLJsmxYLgTZCFCfRuVdkCCYiVBOTSDFMcdT"), 252963640, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fiRXLzdPqgEJXCJ
{
public:
    double CAajEJaiBFwUBoat;
    bool TQxKPvbn;
    bool mMshkPZKz;
    double TXWmfpaiwHHN;

    fiRXLzdPqgEJXCJ();
    int KLFMe(string omQBo, bool qcrIGKGU);
    double VvbAzquhiaXwcV(double HIFXxZe);
    bool JIzjkcHek(int RRTuhXIHvNOsKo, bool ybZYMhh, double oLSAaNtr, bool MAcjRYMlaKrYZc);
protected:
    bool NiQBDTvMhVnHjau;

    bool tTTjR(int aszbPWOHceJA);
    string jWVIVzStmJVoYu(string NxZRBWWJrAaBKRHx, string uTgcuQgVMFxwfQ, bool IiNNAMNKfutW, bool sLEfmTvIMABDQcw);
    void EBdZM(double bJIFkaWfmApP, double FTHuTAcXSQGVFWLb, int LyKNAbH, int VhxhlrlBZRAL);
    string ibpUghFoycsvm(double NIptJkEtgnL, int szOWsNPJLG, int jGYDijvxL, int KNwNosiJjFTK);
    void EXIsKDacxo(double cPcVgfcC, bool bnnpRMDLr, bool BgqkKzJVxCjfgIP);
    int ZyYuPOkiXOwYWwwa();
private:
    double LeusGlzQyv;

    void TOgPosYY(int qkhyYOLdit, bool iOmBhwG, bool btthwoxzNAxBthb);
    int XjddxEXUOQFsX();
    int EZtBLwHvVxSzSWA(double pgWByyqZyfrIPPu);
    bool HvhyHoerZ(int ToojHQX, string uqZntKfrsQ, bool ptYWc, double AJrdArxCKOibw, double FRlik);
    void GxKaPQhmpVEMR(int QEdUnQqnLPwe, int iPsecsjNyu, string gxmhdakbzV, int wHjbbETphQ);
    string nThoJuIUEEczTAsu(int IxySqSsjHsNowwQV, int rVDCXRQkdHx, double Rxxuah, double dboXYGWlyBMyEm);
    double SEiJaINGUjgcu();
};

int fiRXLzdPqgEJXCJ::KLFMe(string omQBo, bool qcrIGKGU)
{
    bool ztpuPfkL = false;
    double FtkNkcbN = -9350.904331576954;
    string yqVEZlRvfGvEhHRl = string("ZKEApcLfxovIdrWZWEqZRtceRGqAfXqBJAFTsIfqTCFKgncGNDJbCTXeCbvOzbCJteXPAhEFWFKcRoDhnaPHKDiOZbHMiyCxlJSnnYcTTZAQlSlzRccKuGYycvdiXIZdOHIwDsFBBdOvMWyguiGnPRZfTcCEjiIeotFAvSjwtJmNOGgVTNqUleUPPMoYJqZgDcAOsnwubDZyAQVWft");
    double uSLrTCSmmARt = -982357.920597989;
    bool MMIQfujOtxgC = false;
    string cLszVljk = string("BHDpsPLDVCBuMCJtoClCstKFOooDJeyOhXPBfGHbsQtjtDrBrYTXaTyKgzFEFSKgWAAwPOOlQUuTPzteZXLKWQsroRmMSxsRdePGcBncpiiWJHZZZOZxMDlw");

    if (uSLrTCSmmARt == -9350.904331576954) {
        for (int KMweX = 252001522; KMweX > 0; KMweX--) {
            ztpuPfkL = ! MMIQfujOtxgC;
        }
    }

    if (yqVEZlRvfGvEhHRl < string("BHDpsPLDVCBuMCJtoClCstKFOooDJeyOhXPBfGHbsQtjtDrBrYTXaTyKgzFEFSKgWAAwPOOlQUuTPzteZXLKWQsroRmMSxsRdePGcBncpiiWJHZZZOZxMDlw")) {
        for (int utcArnYwpWp = 424908909; utcArnYwpWp > 0; utcArnYwpWp--) {
            yqVEZlRvfGvEhHRl = cLszVljk;
            omQBo += omQBo;
        }
    }

    if (ztpuPfkL == false) {
        for (int mAmJrLq = 1853679595; mAmJrLq > 0; mAmJrLq--) {
            FtkNkcbN *= FtkNkcbN;
            yqVEZlRvfGvEhHRl = omQBo;
        }
    }

    if (MMIQfujOtxgC == false) {
        for (int GvhpIOsEPfrPq = 1146187290; GvhpIOsEPfrPq > 0; GvhpIOsEPfrPq--) {
            yqVEZlRvfGvEhHRl += omQBo;
            yqVEZlRvfGvEhHRl += omQBo;
        }
    }

    return 380308222;
}

double fiRXLzdPqgEJXCJ::VvbAzquhiaXwcV(double HIFXxZe)
{
    string LrOwiJsdlc = string("MqJXuxB");
    string hvvnbvZuwlMaUs = string("RYkRheNianJBiWNQoQjmOmXQNkfZkMoMMVbls");
    string nCDSsxVp = string("amEBgaJEqcNzyzYsQkGiEOwUiuOEpzuZoLJFRArAlwwACyUBAKGvoDHOhBPZTdpeglABYLjpgZCTrOvOhliBFSEEAXVDzfcr");
    string yanFQepkOpQtJy = string("GZMqxxakuNXeMXyiAtxWwCAvTfzfzubGvoltWxEXFjYZevbckBIfxnkvlLHAXXpxBMmwBVEZnfTnAKiLovSiCJqHapLLbRgqDfNqDyYEkPDrUJGtYQrZcdjZaRRbqOYRVusrQBjaHFiDHujOrDNvcIKlbYhyqdcTtmXhrwvNCbGGvSvyWAOaxHmdVMRgyMyjzYEEOehBBjmyHXouyfKvHzElHJQWib");
    bool LEAzngIYN = true;
    string UlAjkDoqEZjVsM = string("lpFppBvtTzQqjursiKlyWprqbTCGbgbdyvdEqQiMoZswbhmrptjwKlxTAWLekEssldINDKGCzIhbBYoOBlGhNVAilPeJtVTdMZmOlwwCTgObHrfUQISEEnEFKEfrsUllKLRxMeiKEoFbOKfwMYqBAHQWrBXEriPFpAcsqFJqZjYFKQgmhDxHTXjqjwOwrxYpoVjKFniSgykuzWZFaFO");
    int YaLkXOFRRDWHeD = -668823810;
    bool TmWcBgXmCirSvLQP = false;
    bool EoHpaW = true;
    string gmlZdC = string("KaqNoADomOYKxWbKcxyNztPGPpzyttbFQElPddEMtwGYIWNQpdjHKgnBPejHPmTLPeKoyVCsAMgzGKxlnpEXdiuMTipnwaPBlYUxJUDqgPGNvutwJmAcvgzOSdUaSpUQSDJVjknTdgpvYuaZUmehOHRyEweDUPyif");

    for (int YZvtLumzl = 1285843717; YZvtLumzl > 0; YZvtLumzl--) {
        yanFQepkOpQtJy += gmlZdC;
        EoHpaW = ! TmWcBgXmCirSvLQP;
    }

    for (int UpwLGjfvlh = 982317929; UpwLGjfvlh > 0; UpwLGjfvlh--) {
        hvvnbvZuwlMaUs = gmlZdC;
        LrOwiJsdlc = UlAjkDoqEZjVsM;
    }

    if (yanFQepkOpQtJy <= string("RYkRheNianJBiWNQoQjmOmXQNkfZkMoMMVbls")) {
        for (int UkczHsSIQ = 597624105; UkczHsSIQ > 0; UkczHsSIQ--) {
            nCDSsxVp = nCDSsxVp;
            nCDSsxVp = UlAjkDoqEZjVsM;
            gmlZdC = LrOwiJsdlc;
            yanFQepkOpQtJy += LrOwiJsdlc;
        }
    }

    for (int MkeKKc = 1808418969; MkeKKc > 0; MkeKKc--) {
        LrOwiJsdlc = UlAjkDoqEZjVsM;
        hvvnbvZuwlMaUs += nCDSsxVp;
    }

    return HIFXxZe;
}

bool fiRXLzdPqgEJXCJ::JIzjkcHek(int RRTuhXIHvNOsKo, bool ybZYMhh, double oLSAaNtr, bool MAcjRYMlaKrYZc)
{
    int ZzwmZXrX = -2105932622;
    string tqXJY = string("nltCeljINmSKTnsLFoMDngioHjlLMbqkENHKZoCg");
    bool dPwGVEZyXpFMgRTg = true;
    bool QcQjZKExzhZsjTcg = false;
    double KAfRevqBfIRx = -736903.1256826746;
    string hwLMUz = string("ugkadIUcsV");
    double gQlXdBSyyfNPPD = -9831.431658743208;

    return QcQjZKExzhZsjTcg;
}

bool fiRXLzdPqgEJXCJ::tTTjR(int aszbPWOHceJA)
{
    bool yfiWUpFuSctI = true;
    string GbFynCyL = string("HSJKPJIDXHXTCpMWttGepSyevEXpnJJziQTWFzngieZsxaMLTouixSEijqdKbCbQIiuDihyFIzaLOcjzNnkOExRSrGyWyAvziCnUeFYQIzZFmLlpcoALIJVacIOTAXbyOdvQGZSITWsOnapuJSeaLSErsyKLDkDr");
    int tsLPMdx = -1990967078;

    for (int ymQgelb = 385016103; ymQgelb > 0; ymQgelb--) {
        aszbPWOHceJA = tsLPMdx;
    }

    for (int wpnaGooiGXzy = 429258324; wpnaGooiGXzy > 0; wpnaGooiGXzy--) {
        GbFynCyL += GbFynCyL;
    }

    for (int EtKKnxSF = 2044903269; EtKKnxSF > 0; EtKKnxSF--) {
        continue;
    }

    for (int uuRtMPfpLzlGzxIY = 1895589091; uuRtMPfpLzlGzxIY > 0; uuRtMPfpLzlGzxIY--) {
        tsLPMdx = aszbPWOHceJA;
        GbFynCyL += GbFynCyL;
        tsLPMdx /= aszbPWOHceJA;
    }

    if (tsLPMdx == -1990967078) {
        for (int KjMKabRQEidZ = 1515818357; KjMKabRQEidZ > 0; KjMKabRQEidZ--) {
            aszbPWOHceJA /= aszbPWOHceJA;
            aszbPWOHceJA *= tsLPMdx;
        }
    }

    return yfiWUpFuSctI;
}

string fiRXLzdPqgEJXCJ::jWVIVzStmJVoYu(string NxZRBWWJrAaBKRHx, string uTgcuQgVMFxwfQ, bool IiNNAMNKfutW, bool sLEfmTvIMABDQcw)
{
    int cBhgXMBn = -676376635;
    int HpOjxHFNtMFu = 508209924;

    if (sLEfmTvIMABDQcw != true) {
        for (int NMFWEnku = 1935700024; NMFWEnku > 0; NMFWEnku--) {
            uTgcuQgVMFxwfQ += uTgcuQgVMFxwfQ;
        }
    }

    for (int vEDAJypEYbZdDhUY = 423490434; vEDAJypEYbZdDhUY > 0; vEDAJypEYbZdDhUY--) {
        HpOjxHFNtMFu -= cBhgXMBn;
        sLEfmTvIMABDQcw = IiNNAMNKfutW;
    }

    return uTgcuQgVMFxwfQ;
}

void fiRXLzdPqgEJXCJ::EBdZM(double bJIFkaWfmApP, double FTHuTAcXSQGVFWLb, int LyKNAbH, int VhxhlrlBZRAL)
{
    double hZanSogHlyad = 446261.4757340954;
    bool izwcAqUxcScF = false;
    double clTTVxhtmbfe = 219547.32784192477;
    double oXuPco = -557138.1665650485;
    string BCTiUmA = string("XCZqcbWiLMDHfUxMPnZpzZeeZXiZPGyCsWmxrfkPseyHYFzrLdaMqONTygxKwJwkmyiIPbaaJLLxJjwBbXJmMvThrqtnlLqJxoZsnzCAayOUUDcTfSiTqlTGqZyLneUOuROiqSpczWyzllTyHIERlHOzKsCbMMERQrLj");
    int TUkMbhwrPH = 1563888137;
    bool BMSZjlv = true;
    double AlOoPlWTIhBFU = -57299.02649913577;
    bool BApEXRzlFVKomed = false;
    string xPyGOWGglcYsn = string("rgFyXkMXnjHMiLsRLHBmmauFLJtJHYkiufebkPkiEFZXRRcKrzpFBuTewARozcwJrnWTWC");

    for (int hmauc = 1941113068; hmauc > 0; hmauc--) {
        hZanSogHlyad *= AlOoPlWTIhBFU;
    }

    for (int BOBJxGyCYkSJlpgw = 487227142; BOBJxGyCYkSJlpgw > 0; BOBJxGyCYkSJlpgw--) {
        hZanSogHlyad -= hZanSogHlyad;
        hZanSogHlyad += hZanSogHlyad;
        FTHuTAcXSQGVFWLb /= bJIFkaWfmApP;
    }
}

string fiRXLzdPqgEJXCJ::ibpUghFoycsvm(double NIptJkEtgnL, int szOWsNPJLG, int jGYDijvxL, int KNwNosiJjFTK)
{
    int lpOxRqZTDtBDEes = 2015189795;
    string XFIpsclRtg = string("NCEZHkaejklpSWFZPefDSVjIEFHcIGPUGecwxJgaqTRVotDvHLBaQKPEKfejLcYfjzXnwnTsPnbcgVLutaAKEzliVGDcZWOIVCwMOWQRHgpAThwnjOMgLyMILHmNYPyjrRYUHgcLdfTObhDaWyJlZmZZwqXnpEgJkYz");
    double fyvwX = 392793.92958451784;
    string MvXoej = string("pbJbwyDsMnRLbhvEmdqTWUFwAUFrmyzBTnUDcIP");

    return MvXoej;
}

void fiRXLzdPqgEJXCJ::EXIsKDacxo(double cPcVgfcC, bool bnnpRMDLr, bool BgqkKzJVxCjfgIP)
{
    bool OvqIHc = true;
    string VoZqwk = string("oxjzBOQvwyKxNxKMIMNBrbiCMAJgyGJzTNRFXWwrKUYyNRKQyxBZPejkjeIXhAdKOyHRKPlUmWverHtpRGWcQqmrpZIjvyjleUpMjcvUvmmdYiwKivVfeTMNzspnlzefXAOxQQVxBPEPVhTffCIxMHezBjRrSHOpgZFtqqaYwEOHGSpxyMpgNoUzQvmgutjxRaLgYuKWTTsURXoVIEfKHnHmQmwSrunpCITuCHwGlPNdIEjQKckTJPAtIn");
    int zUnsuBZBonrpe = 2084441602;
    string ORdFGjgqqPhgRabt = string("GnrYrcEFHYuskzZwCzZQgQSGOmJYZmVERYKXxjzVDxnJIzTOWHJdCermCuSkeWYCxkkKbvsOcZeicZGDWpUOEzlnqKszkcGWB");
    string skVLY = string("cWZRotNmKAKPPwpTUWyEfHggMLpdKfLRahTaWNFcZROIxVSzvOIXUSkHgKjnMlxjqybOBJkzkxEiNRbFNcElMe");
    double oMxQx = 595597.0521852482;
    bool KBevfwDMlw = false;
    double fkJELiHHNQNoIl = 690435.9020017089;
    int GhWTIUidHZ = 456071912;

    if (KBevfwDMlw == false) {
        for (int fMblvVSUQow = 44480482; fMblvVSUQow > 0; fMblvVSUQow--) {
            KBevfwDMlw = ! bnnpRMDLr;
        }
    }
}

int fiRXLzdPqgEJXCJ::ZyYuPOkiXOwYWwwa()
{
    int ngAvcithaO = -1100958028;
    int dhevupC = -1650789418;

    return dhevupC;
}

void fiRXLzdPqgEJXCJ::TOgPosYY(int qkhyYOLdit, bool iOmBhwG, bool btthwoxzNAxBthb)
{
    int MLXXCKJThW = -1089171603;
    double suOMiRwoAn = -24146.697028241128;
    string zGxbuw = string("VgoMUHFojlLFYdrGZzmiKNdheEBSJAymndgBwdpqYYEPffRILetSEkUuDhaKmFLlmroEpOlpLtTgRBoBTBHwDdzXlkfGXZqJcIhDoLawZDguiitEbIARFPyNwSSexmrmKWWmAGTyuCdrPXpqzbzBNLNrtJdWFNhvIGYsSRFaxRiIbpkHTAHcfTJvjGvFmZSGaeHKjftJWyhpMandmZohbjJE");
    int UGNbKIfJXtioHp = 681808676;
    double wjoyperlqldLhcT = 7218.936363654375;
    string xTLMkwHXMxams = string("BhNIvpPuxiydmiCBXhaGrOzeKmXQruFXgKkKdVFHQfTkXvmwtYsWzgRSTEnvBoEaTfCLqYSPxSBYwwsIAsHzBDknAMbAHfDyGwWjtCaRXjhBvKHeNKFKGUeTLYLhmXyaqKhXQQQHVzmQzeolooqtzniwNvvoXLOqmWjSXHvBVb");
    string eWElDlbuparqHMf = string("MVuqfmiVmRkFKPRjyrDnmtOCLJZRlRgzJumiJBTuTosTkAmIiApygPXExhbVDEgXDYLVkajOEahOrboyuyQxqpPbSDNKgkJvOMDxrIellpepdbYortgrfJjhWVhmllZrjPFgbsjGsVBUIQExdkJGOHbZrlmMwycSirRjecpnfjIagC");
    string vLgzirV = string("zqcanCNvHaooDkwFotUrFPqrWylOoyTKexBRoGPBaicPf");

    if (eWElDlbuparqHMf >= string("VgoMUHFojlLFYdrGZzmiKNdheEBSJAymndgBwdpqYYEPffRILetSEkUuDhaKmFLlmroEpOlpLtTgRBoBTBHwDdzXlkfGXZqJcIhDoLawZDguiitEbIARFPyNwSSexmrmKWWmAGTyuCdrPXpqzbzBNLNrtJdWFNhvIGYsSRFaxRiIbpkHTAHcfTJvjGvFmZSGaeHKjftJWyhpMandmZohbjJE")) {
        for (int BcWCCBC = 469537823; BcWCCBC > 0; BcWCCBC--) {
            xTLMkwHXMxams += eWElDlbuparqHMf;
        }
    }

    for (int GBXathDgcPFl = 492071548; GBXathDgcPFl > 0; GBXathDgcPFl--) {
        continue;
    }

    for (int ialthmatHN = 1110708403; ialthmatHN > 0; ialthmatHN--) {
        wjoyperlqldLhcT *= suOMiRwoAn;
        qkhyYOLdit = MLXXCKJThW;
        zGxbuw += eWElDlbuparqHMf;
    }
}

int fiRXLzdPqgEJXCJ::XjddxEXUOQFsX()
{
    double HjwHfzDzOIRFiC = -78781.76140028526;
    string sDotOCgXaAEmLSg = string("JGbIetUWKsCZsfgEDNqOlKgLpRekFmiKSDuKpmhaFnORZzwxNISWUPVISzhccVMMrBzpsFwXpmkIeFmuiIdWzVYNZfbXfymicxmzGyneCmsesktpdOI");
    string gSLwsTOwDyVq = string("rtupHnvWd");
    bool irkfjCuJLXzkxX = false;
    string xFIANSE = string("pJTxfQnbCXMVOFjaEjrbTHOSKYcXlUkbUw");

    if (sDotOCgXaAEmLSg != string("pJTxfQnbCXMVOFjaEjrbTHOSKYcXlUkbUw")) {
        for (int FsCqobG = 1757777548; FsCqobG > 0; FsCqobG--) {
            sDotOCgXaAEmLSg = gSLwsTOwDyVq;
            xFIANSE = xFIANSE;
            sDotOCgXaAEmLSg += sDotOCgXaAEmLSg;
            sDotOCgXaAEmLSg = gSLwsTOwDyVq;
        }
    }

    for (int omccIbDCVoF = 1266929381; omccIbDCVoF > 0; omccIbDCVoF--) {
        xFIANSE += sDotOCgXaAEmLSg;
        sDotOCgXaAEmLSg += gSLwsTOwDyVq;
        HjwHfzDzOIRFiC = HjwHfzDzOIRFiC;
    }

    for (int BdRaBluwB = 1198164315; BdRaBluwB > 0; BdRaBluwB--) {
        gSLwsTOwDyVq += gSLwsTOwDyVq;
        sDotOCgXaAEmLSg = gSLwsTOwDyVq;
        sDotOCgXaAEmLSg = gSLwsTOwDyVq;
    }

    if (xFIANSE < string("JGbIetUWKsCZsfgEDNqOlKgLpRekFmiKSDuKpmhaFnORZzwxNISWUPVISzhccVMMrBzpsFwXpmkIeFmuiIdWzVYNZfbXfymicxmzGyneCmsesktpdOI")) {
        for (int aeVQNqmEFrUTeE = 144489441; aeVQNqmEFrUTeE > 0; aeVQNqmEFrUTeE--) {
            gSLwsTOwDyVq = sDotOCgXaAEmLSg;
        }
    }

    for (int phXQuCkhIpvG = 11292419; phXQuCkhIpvG > 0; phXQuCkhIpvG--) {
        sDotOCgXaAEmLSg = xFIANSE;
        sDotOCgXaAEmLSg += sDotOCgXaAEmLSg;
        irkfjCuJLXzkxX = ! irkfjCuJLXzkxX;
        HjwHfzDzOIRFiC /= HjwHfzDzOIRFiC;
        sDotOCgXaAEmLSg += sDotOCgXaAEmLSg;
    }

    for (int jkJaMA = 101250826; jkJaMA > 0; jkJaMA--) {
        sDotOCgXaAEmLSg = xFIANSE;
        irkfjCuJLXzkxX = irkfjCuJLXzkxX;
    }

    if (xFIANSE == string("pJTxfQnbCXMVOFjaEjrbTHOSKYcXlUkbUw")) {
        for (int KcRlqxwJhliy = 316930764; KcRlqxwJhliy > 0; KcRlqxwJhliy--) {
            xFIANSE += gSLwsTOwDyVq;
        }
    }

    return 1824546890;
}

int fiRXLzdPqgEJXCJ::EZtBLwHvVxSzSWA(double pgWByyqZyfrIPPu)
{
    double hsksYYAQFd = 32283.707424110722;
    bool gXOhWwSzqFsnmzx = false;
    bool SObSc = false;
    string TbyVuHvpaifs = string("NFSNxmBgkfAopZHeHtYscxalWemXYYLdWZSxVRiXyamqoAgwyxQBpIDwmXmFoAfAHBNlxFKJjyZmNRYuMbDtheBczsgKXrWEolSJzSkSaYQGRzIZQwAMlpOHNQNpjRwaNJV");
    int OyRRjUE = -1426545105;

    if (pgWByyqZyfrIPPu < 32283.707424110722) {
        for (int oeVbmpygcnont = 684990908; oeVbmpygcnont > 0; oeVbmpygcnont--) {
            continue;
        }
    }

    for (int UWBZSOm = 1351449195; UWBZSOm > 0; UWBZSOm--) {
        hsksYYAQFd = pgWByyqZyfrIPPu;
    }

    return OyRRjUE;
}

bool fiRXLzdPqgEJXCJ::HvhyHoerZ(int ToojHQX, string uqZntKfrsQ, bool ptYWc, double AJrdArxCKOibw, double FRlik)
{
    string JGVBOYlwHVvDgQNA = string("TAfsPjoFHxWDMfgoHCWaKpIZFRifznBdkPdLLXBQruoMCMLINtGmnWgLqU");
    string fbKXLrUHmH = string("bzKlvADyiGKtRVVumZFbMDqqZcYaAIhRuUcrAyQaDxpLtgihIkarOZMhNkvntXGykuzPYrwqBsNIsQZoOYacOaVXsdBYqnt");

    if (fbKXLrUHmH != string("TAfsPjoFHxWDMfgoHCWaKpIZFRifznBdkPdLLXBQruoMCMLINtGmnWgLqU")) {
        for (int xQuwIlKnL = 1071984009; xQuwIlKnL > 0; xQuwIlKnL--) {
            fbKXLrUHmH += fbKXLrUHmH;
            FRlik -= AJrdArxCKOibw;
            uqZntKfrsQ += fbKXLrUHmH;
        }
    }

    for (int CnISyCepgT = 1913281539; CnISyCepgT > 0; CnISyCepgT--) {
        uqZntKfrsQ += uqZntKfrsQ;
        JGVBOYlwHVvDgQNA = uqZntKfrsQ;
    }

    if (uqZntKfrsQ > string("TAfsPjoFHxWDMfgoHCWaKpIZFRifznBdkPdLLXBQruoMCMLINtGmnWgLqU")) {
        for (int PFZnoZODRlKABiwJ = 1114765087; PFZnoZODRlKABiwJ > 0; PFZnoZODRlKABiwJ--) {
            AJrdArxCKOibw /= FRlik;
            JGVBOYlwHVvDgQNA += uqZntKfrsQ;
            uqZntKfrsQ += JGVBOYlwHVvDgQNA;
        }
    }

    for (int lfJgQhcpOs = 1570641213; lfJgQhcpOs > 0; lfJgQhcpOs--) {
        JGVBOYlwHVvDgQNA += uqZntKfrsQ;
        JGVBOYlwHVvDgQNA = uqZntKfrsQ;
    }

    for (int DLUig = 1527731932; DLUig > 0; DLUig--) {
        continue;
    }

    if (ptYWc == true) {
        for (int zJUdlfodnnGOB = 1044816040; zJUdlfodnnGOB > 0; zJUdlfodnnGOB--) {
            fbKXLrUHmH = uqZntKfrsQ;
            uqZntKfrsQ += JGVBOYlwHVvDgQNA;
            fbKXLrUHmH = fbKXLrUHmH;
        }
    }

    if (JGVBOYlwHVvDgQNA <= string("TAfsPjoFHxWDMfgoHCWaKpIZFRifznBdkPdLLXBQruoMCMLINtGmnWgLqU")) {
        for (int MbiVGVrLnzHpIGLE = 938556447; MbiVGVrLnzHpIGLE > 0; MbiVGVrLnzHpIGLE--) {
            fbKXLrUHmH += JGVBOYlwHVvDgQNA;
        }
    }

    return ptYWc;
}

void fiRXLzdPqgEJXCJ::GxKaPQhmpVEMR(int QEdUnQqnLPwe, int iPsecsjNyu, string gxmhdakbzV, int wHjbbETphQ)
{
    string GfufuqE = string("HOadAcwtcpQmMUiOmfKDCZcxUkELFWSehXBzrmSRWQukwxHbgCXwKTQPqfLhDrWFgfIOExxXkAYlncpokEDgaUyu");
    double hkTfqFR = -634503.8629030472;
    string mqpEVNsWBXI = string("gCcnUsewojDONaiKlkIKqswXxoCEytmjUTMzYCUGHSuwgVJdWuykWlgSvCEJjKHLoPtnAjhhrFimERzPSxELsJwQvYRHsQFYZQVcYGewLpoqStFaBBKhIcPFKXRpzKomFnePaJhmZNkTgkDWDqpOLQMoxUXtyrPNtqzhVHtIOyXANcHFOwGZvjtdyjkIR");
    double OhCtwGzVW = -345737.77261310257;
    double nPgecrRkVdwJkdVh = -346864.1419571425;
    int YSHyGkoshTJ = 526840867;
    int MqlTMs = 235391572;

    if (gxmhdakbzV == string("gCcnUsewojDONaiKlkIKqswXxoCEytmjUTMzYCUGHSuwgVJdWuykWlgSvCEJjKHLoPtnAjhhrFimERzPSxELsJwQvYRHsQFYZQVcYGewLpoqStFaBBKhIcPFKXRpzKomFnePaJhmZNkTgkDWDqpOLQMoxUXtyrPNtqzhVHtIOyXANcHFOwGZvjtdyjkIR")) {
        for (int gQJwbQsIzhYsYEx = 1798849691; gQJwbQsIzhYsYEx > 0; gQJwbQsIzhYsYEx--) {
            iPsecsjNyu = MqlTMs;
        }
    }

    for (int OaYZtACKwQEQGQ = 1203864119; OaYZtACKwQEQGQ > 0; OaYZtACKwQEQGQ--) {
        continue;
    }

    for (int xcaxJIxVHwbQB = 382973329; xcaxJIxVHwbQB > 0; xcaxJIxVHwbQB--) {
        hkTfqFR *= hkTfqFR;
        gxmhdakbzV = gxmhdakbzV;
    }

    if (hkTfqFR < -345737.77261310257) {
        for (int XPLraVqLHD = 1822789630; XPLraVqLHD > 0; XPLraVqLHD--) {
            gxmhdakbzV = mqpEVNsWBXI;
            iPsecsjNyu += iPsecsjNyu;
        }
    }

    for (int XZumcrMGKAoNl = 1801720245; XZumcrMGKAoNl > 0; XZumcrMGKAoNl--) {
        GfufuqE = mqpEVNsWBXI;
        OhCtwGzVW -= hkTfqFR;
    }
}

string fiRXLzdPqgEJXCJ::nThoJuIUEEczTAsu(int IxySqSsjHsNowwQV, int rVDCXRQkdHx, double Rxxuah, double dboXYGWlyBMyEm)
{
    string NIcgXcVn = string("JwoxfAaMtjDXaVpPQnWfXpEOxokkRWSqldLULYDAEZnTLFUQBLNiXNksZARUuNuLmOhjDdDAmgyLtuhekldkLIpEhwlzSgIRnwBAOxxSQUUiDiqche");
    double MqxNUm = 168806.39750231532;
    double iSuSFdSbwHiziz = -736411.0596666762;
    double gnOLezslfbRFd = 304280.2146695743;
    int BBJOqBRvmlOjpxF = -1604580839;
    double PBgoSKVgGj = 390908.773802172;
    string TZJSuaNgCBKfVexf = string("aiRDbjZDShHyLfSsqXsewToINEXAWfPKZMaSAyDAKWARiXLLZOooFcPynkMYzmFeJsUYIPAbbMMfPPyptlEnbxfiBzdwaaSHHLCvAvksHbnNjtzYNCAcsHXRIEDgSVvLkdQdHyqbUYFdGllMnIRyonXXTtXnOhzvqhACCLaPXiPyTbhhMarqHwBkDyQdDIdbeblfSJOkBYzLzusHbOOFzaeKCtTkmYRcNlqQZRyXQdJU");

    if (gnOLezslfbRFd >= 168806.39750231532) {
        for (int iGgvdBxtgtQTAQrH = 759981505; iGgvdBxtgtQTAQrH > 0; iGgvdBxtgtQTAQrH--) {
            gnOLezslfbRFd = Rxxuah;
        }
    }

    if (MqxNUm < -114086.8529176387) {
        for (int CXnBJM = 167634562; CXnBJM > 0; CXnBJM--) {
            MqxNUm = Rxxuah;
            PBgoSKVgGj += PBgoSKVgGj;
            IxySqSsjHsNowwQV /= BBJOqBRvmlOjpxF;
        }
    }

    for (int LyFQLQjjPqvThFCL = 710120660; LyFQLQjjPqvThFCL > 0; LyFQLQjjPqvThFCL--) {
        gnOLezslfbRFd -= dboXYGWlyBMyEm;
    }

    return TZJSuaNgCBKfVexf;
}

double fiRXLzdPqgEJXCJ::SEiJaINGUjgcu()
{
    bool LrTapCTigc = true;
    int WLBiftCGXw = -162421138;
    int CsccljGCl = -1501061766;
    string aZMmiUI = string("OGJZeXvyyzONSUVXaodACGuXgyEyjcIuBZDyoqzsujgVmMMWlZdFtHQBDnIdNBqRWawCmQxjtQdSzXxaUyqxBdHMRiytuZvANFDcPKSIIOyUkuqtLeKThyuRvS");
    int kDzywvjjBkuCJY = 107276695;
    int bLRrGSnXQgH = 2108735812;

    for (int dboNXXMK = 784645146; dboNXXMK > 0; dboNXXMK--) {
        bLRrGSnXQgH = kDzywvjjBkuCJY;
    }

    for (int NFXLDvVWatsYnwZP = 396422911; NFXLDvVWatsYnwZP > 0; NFXLDvVWatsYnwZP--) {
        continue;
    }

    if (CsccljGCl <= 107276695) {
        for (int eGenobWOHBZEcb = 966257160; eGenobWOHBZEcb > 0; eGenobWOHBZEcb--) {
            continue;
        }
    }

    return -477848.8801812455;
}

fiRXLzdPqgEJXCJ::fiRXLzdPqgEJXCJ()
{
    this->KLFMe(string("uWmfsvUrkafxUUUqIDVWYKeGbQzvyilAgoXArf"), false);
    this->VvbAzquhiaXwcV(-909176.4642634849);
    this->JIzjkcHek(-530763914, false, -710787.132768771, true);
    this->tTTjR(-984136644);
    this->jWVIVzStmJVoYu(string("PfcownwimwQIXxlqNjLFQgQRydXesODkQnXRHJjqCYHLFefraomAZCZDogTGionvNtGcOdCQEETqZEVSIQBnRYEmewuJtsbSLbBIEqbuZJenQGTjmLqwRGXblHQFWYcauzGTmsdhmIoiFkwakIXTVhVXNEiRILuTwDCWYwmsrJxMBcLbhVlgOTMqDAHFMDnpvzjiFGONQ"), string("yshDZfuxyfFyLLvadAOpEqdLcxeWwFjYDluHYEpVGwBDYkDiPiLqZDYaDgyOqUaQeffdOjNkIdmulpjWkRgXAjLAcXCZNyqDKoZqCjCLa"), false, true);
    this->EBdZM(266540.53314658784, -894606.4767384961, 1479602862, 724930102);
    this->ibpUghFoycsvm(118587.1974703266, -1115829819, -1457684025, 396372305);
    this->EXIsKDacxo(561573.6830112934, true, true);
    this->ZyYuPOkiXOwYWwwa();
    this->TOgPosYY(236622714, true, true);
    this->XjddxEXUOQFsX();
    this->EZtBLwHvVxSzSWA(-748976.590904758);
    this->HvhyHoerZ(-1254989566, string("OOCIgBiRGdOLlqRAugEZErFnjwZnQoQfYleBsrxlXRuHXSBvTytjXdsvzrsElbxDNTaHwmAERljFiUORhvKiUdpDyBgCjTgeQEGvSVylsDwGNGLqZzvgWLyWYYIvqTmwaWEwqEQKGDIdHDMqedsdqeqnHPobsq"), true, -954851.9017981138, 616538.8466520809);
    this->GxKaPQhmpVEMR(440253481, -673749785, string("DgouZNwiUmruuZxOYzmindpmdEikokGhIDVplMKXMvWvMwvgIpNqECtSANPOYHUcDPsvXQkpUZOdPPETfBMWGplflBoTjniNSrbxlAYVhtFlHApmoSkODQyLKvKxMyOpoZxacipOejRwIQZfbug"), -600513533);
    this->nThoJuIUEEczTAsu(-282308684, -193740189, 57231.91076082338, -114086.8529176387);
    this->SEiJaINGUjgcu();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XOFogMoQQ
{
public:
    double qIMZxRrIStWsAb;
    bool GGYwqwKriyB;
    bool BsBcvvwqnQmICzY;
    double tURuGvS;
    string JtjXzJbytlzBLrMM;
    bool fWlgfJ;

    XOFogMoQQ();
    string dMHihttcyU(int WJfhD, string WoTSNXRVtctAia);
    double zIhuNqpsNczApuhN(string LgDOtIS, string LFfVq, bool qoVERkSE);
    double KYrMNrwKlyLIR(int gdFLosGPhsXaUb, string JxIjNDTm, bool bMwOZ);
    double YkaLiJWwN(bool NndVTcrhbDFO, double YDXpYCbfznKCwgRS, double pAABJIgDkuTROK, double EKjUUVGUiRrjxMDT);
protected:
    int lsyUU;
    string rOrcegbl;
    bool diEFByirszNxKfO;
    bool NYjqFoIvJ;

    bool mDBYGTjTA(int fsFmANPC, double GDZrrLSCwH, int pRAWfir, bool vrWMoHjnYzlmwPh);
    bool anZMRKIrhwTu(double bYtRRqB, bool uHTRntTgcLi, int RciSdKVTKkXqA, int oYLdYNgy);
    double WiHWbAalJkBT(bool HfviqZhCkt);
    string wpOAKoENmNQq(double petzujKWCdlW);
    int tlQvXjnpeH(int mxuJhPk, bool cpdGqwCuhN, double ydqVE, bool gSQFXpsFtPnrjL);
private:
    int YSkkeIdjM;
    double ziXibKhy;

    double JRAABGbBznvlh();
    void TYjKNo(double Iiqghymxw, string lLDuYT, double FtheMyHaMl);
    double WezhVYvA(int vXhiPW, bool LuWAnxc, string LthLK, int rfjPNAI, int JuyQRHbMjj);
    double vVNfoCQYCiW(double SaEKlsKYsmHD);
};

string XOFogMoQQ::dMHihttcyU(int WJfhD, string WoTSNXRVtctAia)
{
    int iXvbQ = -985991960;
    bool EuqBBDWrrzMqN = false;
    int cKgijnguJF = -1639140447;
    int vCSPwfmFkiEcq = 1570265377;
    int pLkshQ = 1108806903;
    bool qtfTKESJQFYE = true;
    string BebuWPmMMHiaGZ = string("oOQnWakVlqYmaWnRCgKHQOAcbXLVIOXwXNzhZMhVxsvHqfifhSaMKxkOFNLItTPgIkEzbcyaeJHDICxBDzffOhxZAmHomJgOKiZyXWRJlOEOFcNzaUPmy");
    bool KHJSEby = false;
    bool VUwQwJWobmMElo = true;
    double IfJbr = 75289.92318291393;

    for (int SHSkJwHiCtWvWFhw = 1414733922; SHSkJwHiCtWvWFhw > 0; SHSkJwHiCtWvWFhw--) {
        vCSPwfmFkiEcq *= cKgijnguJF;
        WJfhD += vCSPwfmFkiEcq;
    }

    for (int FyjSVBziP = 2133697588; FyjSVBziP > 0; FyjSVBziP--) {
        pLkshQ = iXvbQ;
    }

    return BebuWPmMMHiaGZ;
}

double XOFogMoQQ::zIhuNqpsNczApuhN(string LgDOtIS, string LFfVq, bool qoVERkSE)
{
    double RhdKSgtfG = 794325.5882394104;
    double rkUWcMTHkb = 911.5435932699154;
    int CbnJAMcZHViYMtGs = -172799696;
    double czpejSvkSqvtWVHp = 663915.6989249983;
    string nlGCelEkgmrvv = string("piYOCIMSFFkGUgaihAIQJBTBsXmytRYcnkIhRINAynIVlSAWAhxajJLCWYlKuMRXlxIyPXFbVowbzgljDoaDeuKgczNuSijIKoIjOrZsduSOvMAOQWbSjPLCkTBIPzcLQUYJEStwdRaIZcKDAklmfhMPHpORIPIhqYBrTEbDILOGlmRRkNGQQ");
    bool LkffqQi = false;
    double CAFVmOKvuWyyGXo = -781016.7110020253;
    bool tJuRzvI = true;
    string gAhNuleHKC = string("OnYWENeBFnRdkyvSbqkSkdfeBFdZoUbtlqHqwUriLhhgfpMeYFXMRqiuZKTlJMsOamAGCXTylnRRzrXBpUbnHWCLVQXkeeqakdSXDxQLQuxdKlloDMSDffuCosHzyTykdwNUbWWnJRRrsVgDrVcPXCihxFGPkZWWPGsLxVdLaMzjulfwMAoy");
    string tuXyhIMUrXcTyDj = string("yseRZeNMHLgiSQBDxtjDHRlasGcyJTHnRPEGDhSfIbGAFZADXmjufEeYHgcxKeadrgHkGpfmonNXfawtySxgEXYrhJknzDS");

    for (int ugFdMgJ = 1970937787; ugFdMgJ > 0; ugFdMgJ--) {
        LgDOtIS = nlGCelEkgmrvv;
    }

    for (int XekSCmAdcojSCCW = 534423951; XekSCmAdcojSCCW > 0; XekSCmAdcojSCCW--) {
        nlGCelEkgmrvv = LgDOtIS;
    }

    if (RhdKSgtfG > 663915.6989249983) {
        for (int RrbRTFTmdtip = 1155907580; RrbRTFTmdtip > 0; RrbRTFTmdtip--) {
            continue;
        }
    }

    return CAFVmOKvuWyyGXo;
}

double XOFogMoQQ::KYrMNrwKlyLIR(int gdFLosGPhsXaUb, string JxIjNDTm, bool bMwOZ)
{
    double qhqfJDD = 144091.57046260723;

    for (int kOKyvKkZHfHs = 1068944619; kOKyvKkZHfHs > 0; kOKyvKkZHfHs--) {
        JxIjNDTm += JxIjNDTm;
        gdFLosGPhsXaUb = gdFLosGPhsXaUb;
        JxIjNDTm += JxIjNDTm;
    }

    for (int yxnDULcclwCw = 2133902550; yxnDULcclwCw > 0; yxnDULcclwCw--) {
        bMwOZ = ! bMwOZ;
    }

    return qhqfJDD;
}

double XOFogMoQQ::YkaLiJWwN(bool NndVTcrhbDFO, double YDXpYCbfznKCwgRS, double pAABJIgDkuTROK, double EKjUUVGUiRrjxMDT)
{
    bool aHUeKvjceyny = false;
    double RRGgRPfEkthMCHEH = 705886.4677384801;
    bool eRceUPajyjiPk = false;
    string juZbdB = string("sgQobRiflXLoqTJbraMDhZZSTVJPTxRbvymwAnjZnJfCSpVJiYPZzeNiCmLEujhzqECYzhYNTVuykMJKyFzLKXIAsSKXzuTCdbeUdelYsRFsDiospkguEdInHTzvkisICvKbBFwGiLMUITDczemEdsMUvPnPkHXdWgjusKAOEWhWhFdO");
    string JFgIWkBOyRAp = string("XEXgzYfEsrEXjPffofSpSsjBTPTICkbpwXKsbfkoNlGDxNVldbJA");

    for (int sWFxuZWMY = 1882674558; sWFxuZWMY > 0; sWFxuZWMY--) {
        continue;
    }

    return RRGgRPfEkthMCHEH;
}

bool XOFogMoQQ::mDBYGTjTA(int fsFmANPC, double GDZrrLSCwH, int pRAWfir, bool vrWMoHjnYzlmwPh)
{
    string WPhAixlnI = string("tMcGseVyhmXYQmSFTjvqBFBxRTiOTOPDDVBluFyNjLUZclXAcHhujrlFtaSJXDYFKMjlIZPCcCcNQDDNFDKGCmqRARPqTDFCIsJOxZwlpMgotXpjiDEjOLIpcaxPImkvDCoLkERXvmqBbLcQtpAgYtrkNOjrYGdfRSAZGbWyZNKmIhdfzIjOWDoyzKNb");

    for (int SriOJxoLuQquo = 925605057; SriOJxoLuQquo > 0; SriOJxoLuQquo--) {
        vrWMoHjnYzlmwPh = vrWMoHjnYzlmwPh;
        WPhAixlnI += WPhAixlnI;
        pRAWfir += fsFmANPC;
        GDZrrLSCwH = GDZrrLSCwH;
        fsFmANPC -= fsFmANPC;
    }

    for (int ojyejukg = 1933994034; ojyejukg > 0; ojyejukg--) {
        vrWMoHjnYzlmwPh = ! vrWMoHjnYzlmwPh;
    }

    return vrWMoHjnYzlmwPh;
}

bool XOFogMoQQ::anZMRKIrhwTu(double bYtRRqB, bool uHTRntTgcLi, int RciSdKVTKkXqA, int oYLdYNgy)
{
    int dwChSriI = 1352093985;
    double VSxVzTPJffJf = -176832.93251436608;
    int SGYMcU = 722976637;
    bool vsEQLMHb = false;
    double UwNztB = 1022552.3165364244;
    int TtFnwLMQDnGdWX = -971572727;
    int YkXVe = 78396257;
    string aNLbrqddg = string("nlLRBVZjejWixmEfqNRNejtWPCovpjXbdXBGpxLigVdxOTuAulfLjEOARbBZoRRnfxyKoBmklKsbMlwnyQotrIMikJsuAUUTGUinKFbjnvsRAGJfRUsBcsXGIwSmfFTSdgjIfLUEAIdBIQdqpaMaDcvcvPYqXPwLQvmYtqmlGaauWVNOrUNqUrzmrJrIXMUztPRRneCthSfxSYtqXUSaRcEbGQCiMzUrJcIOdMPgEuFtFMDBsBPFQBiuoFn");
    string HMpzqWmCtYCxk = string("KOjSgmGhYgAgoprVHZatKwjVbIBHdAZrTprlWjaodgHrBXZhVnBZbWvBLiUWMCyTxQxzuZqkACMzdXXDknrOBlrZCTtubGYExaSYDxTAuYoUMAVHuPdphyPqMdfQrwAKXubVvfuumxnQVFytyeXgqPGgeFsiMbBBcsuYVWpoROgblhFzCUzaRINOAQVwq");
    bool pUixU = true;

    for (int TisvLYL = 1721817663; TisvLYL > 0; TisvLYL--) {
        dwChSriI /= oYLdYNgy;
        YkXVe *= SGYMcU;
    }

    for (int WvkXqEfRUt = 2106610193; WvkXqEfRUt > 0; WvkXqEfRUt--) {
        dwChSriI = YkXVe;
        bYtRRqB *= VSxVzTPJffJf;
    }

    if (TtFnwLMQDnGdWX > 78396257) {
        for (int MlBqlYbqG = 1441868987; MlBqlYbqG > 0; MlBqlYbqG--) {
            continue;
        }
    }

    if (aNLbrqddg != string("KOjSgmGhYgAgoprVHZatKwjVbIBHdAZrTprlWjaodgHrBXZhVnBZbWvBLiUWMCyTxQxzuZqkACMzdXXDknrOBlrZCTtubGYExaSYDxTAuYoUMAVHuPdphyPqMdfQrwAKXubVvfuumxnQVFytyeXgqPGgeFsiMbBBcsuYVWpoROgblhFzCUzaRINOAQVwq")) {
        for (int lEMOUCO = 2032659794; lEMOUCO > 0; lEMOUCO--) {
            oYLdYNgy = SGYMcU;
            oYLdYNgy /= dwChSriI;
            SGYMcU += oYLdYNgy;
        }
    }

    if (uHTRntTgcLi != true) {
        for (int ekDipCpCJxcpRzk = 1911193871; ekDipCpCJxcpRzk > 0; ekDipCpCJxcpRzk--) {
            TtFnwLMQDnGdWX /= oYLdYNgy;
        }
    }

    return pUixU;
}

double XOFogMoQQ::WiHWbAalJkBT(bool HfviqZhCkt)
{
    int XpAzkQbmdo = -265794506;
    bool TDGbIOrgfzOhcor = false;
    string oMgqAaTFXwRcqk = string("HVCmuVYnsRMLkqndMJRMMRuOVrCtedcMoKAdelGbITlDqNTDDgdlMwwXsYauRzFhoDZbTlHpBGfym");
    string IXfqiuHAJrsGteBN = string("UvQPGBEjQDQsiOUMhVanMKvLSHjcEjyAQyjUFeKpSYMNVRhnsdlRZhZgHxkEUbhlqjylbOjemoZxXcuNfbNxwMIcjAUnRofhsjkZrpiuflYyVYoMcrmtHwcyMxKVkfTcobkgIPFmAclVICumofGVGGXafBKWuhPLFgVxKrlTTKPJXRKsmkvimrGrhfiuCCYqMpBctTHULuXeEMOzhxfwdcHcu");

    for (int dnEiygMSgTJdeA = 266823232; dnEiygMSgTJdeA > 0; dnEiygMSgTJdeA--) {
        IXfqiuHAJrsGteBN += oMgqAaTFXwRcqk;
        XpAzkQbmdo += XpAzkQbmdo;
        IXfqiuHAJrsGteBN = IXfqiuHAJrsGteBN;
    }

    for (int MKYiaJnESHe = 425245287; MKYiaJnESHe > 0; MKYiaJnESHe--) {
        oMgqAaTFXwRcqk += IXfqiuHAJrsGteBN;
        oMgqAaTFXwRcqk = oMgqAaTFXwRcqk;
    }

    if (HfviqZhCkt == false) {
        for (int ErEnbjtJFAWpY = 619052599; ErEnbjtJFAWpY > 0; ErEnbjtJFAWpY--) {
            IXfqiuHAJrsGteBN += oMgqAaTFXwRcqk;
            HfviqZhCkt = TDGbIOrgfzOhcor;
            XpAzkQbmdo -= XpAzkQbmdo;
            IXfqiuHAJrsGteBN = IXfqiuHAJrsGteBN;
        }
    }

    for (int HEdBAsj = 1317653416; HEdBAsj > 0; HEdBAsj--) {
        oMgqAaTFXwRcqk = oMgqAaTFXwRcqk;
        XpAzkQbmdo = XpAzkQbmdo;
        IXfqiuHAJrsGteBN += oMgqAaTFXwRcqk;
    }

    for (int apyQRiiuFjL = 339534039; apyQRiiuFjL > 0; apyQRiiuFjL--) {
        HfviqZhCkt = ! TDGbIOrgfzOhcor;
        TDGbIOrgfzOhcor = ! HfviqZhCkt;
        IXfqiuHAJrsGteBN = oMgqAaTFXwRcqk;
        oMgqAaTFXwRcqk = oMgqAaTFXwRcqk;
    }

    return 290076.9186770376;
}

string XOFogMoQQ::wpOAKoENmNQq(double petzujKWCdlW)
{
    bool TQtTTASSqAMaz = true;
    bool COFIVWs = false;
    double DQGdhnpZZ = 613990.0680016716;
    bool hppQYfoayKG = true;
    double lKjImmEOrMF = 119185.36696828454;

    if (petzujKWCdlW == 613990.0680016716) {
        for (int FNNIOJ = 232602052; FNNIOJ > 0; FNNIOJ--) {
            TQtTTASSqAMaz = ! TQtTTASSqAMaz;
            hppQYfoayKG = TQtTTASSqAMaz;
        }
    }

    return string("arlfRkbCBfDAAOPucxVldzfoiLDwSqcerGBVOsdiZgLXSgATHrAoePPrmfmVzUTKPEOrXVPCon");
}

int XOFogMoQQ::tlQvXjnpeH(int mxuJhPk, bool cpdGqwCuhN, double ydqVE, bool gSQFXpsFtPnrjL)
{
    bool kLHAAyOtTg = false;
    int noseM = 1923473071;
    int QUEwMSUQY = 278161059;
    int oXPdyEffcb = 634656288;
    string gFGNCld = string("Be");

    for (int eRTjQyxURNsj = 1009888197; eRTjQyxURNsj > 0; eRTjQyxURNsj--) {
        continue;
    }

    for (int OYjArjRjETMN = 235473570; OYjArjRjETMN > 0; OYjArjRjETMN--) {
        gSQFXpsFtPnrjL = gSQFXpsFtPnrjL;
        noseM *= QUEwMSUQY;
        QUEwMSUQY *= oXPdyEffcb;
    }

    if (gFGNCld < string("Be")) {
        for (int sQXlFlDzbhgB = 842201435; sQXlFlDzbhgB > 0; sQXlFlDzbhgB--) {
            gSQFXpsFtPnrjL = ! cpdGqwCuhN;
            cpdGqwCuhN = kLHAAyOtTg;
            mxuJhPk = mxuJhPk;
            kLHAAyOtTg = kLHAAyOtTg;
        }
    }

    for (int fFVXHYDTpc = 723775377; fFVXHYDTpc > 0; fFVXHYDTpc--) {
        gFGNCld = gFGNCld;
        QUEwMSUQY -= QUEwMSUQY;
        oXPdyEffcb *= QUEwMSUQY;
        oXPdyEffcb /= noseM;
    }

    for (int bbBEjF = 1811535648; bbBEjF > 0; bbBEjF--) {
        gSQFXpsFtPnrjL = ! kLHAAyOtTg;
        noseM = QUEwMSUQY;
        gSQFXpsFtPnrjL = ! gSQFXpsFtPnrjL;
    }

    return oXPdyEffcb;
}

double XOFogMoQQ::JRAABGbBznvlh()
{
    string rzFpYXaXQWZ = string("EDFfvTbsBUDTBSvGvFvKAyXDVFOBLNBLsBneozczwXZkEBiZCEKKwvRpKYNpol");
    double VxyUZuO = 748898.9061788211;
    bool LHWjYwzk = true;

    for (int SBpdEcpv = 736754050; SBpdEcpv > 0; SBpdEcpv--) {
        rzFpYXaXQWZ = rzFpYXaXQWZ;
        rzFpYXaXQWZ += rzFpYXaXQWZ;
    }

    return VxyUZuO;
}

void XOFogMoQQ::TYjKNo(double Iiqghymxw, string lLDuYT, double FtheMyHaMl)
{
    string sgtBNbUdP = string("VxipHIrLMTpyYKUJErb");
    int nWcDoeYGmWtfPKyq = -256677414;
    double MVjFsUBMc = 629175.0874527387;
    bool TnLArxlZtgG = true;
    int ElQOyFrTQqJmgN = -850167577;
    string TKGPiLtyJniQaFsS = string("CETiTXgJpqflJKzpRerCYoIsbGFqAaBUAfdyqJORuChLuGNSrOyPWjyCSGNxaBDvZYpgxkXVxTrbuXYUYfuUguhgLGpWXDTgfNWMOKJIFIXOcHfSNHUYdzqScLAnMfhlHsJklHyuGdUAmbmGSjfFJtgfGDPjbwkOQUnBVNicn");
    int LoCWhzVXbZdG = -1967465335;
    int BeHhQafwpjxOON = 2033309983;
    string SSbUzfWRRtGmGt = string("lQMqrxDUOILVxKjmJJqotKjvfWpAqOYZvLDCdKhZHMXSrVoHRXDENMkHbBHcpzQLrrnbJBhQbHDctSTIBxW");
    double NrwygaKbyx = -333990.6982585591;

    if (FtheMyHaMl > -404127.31515493285) {
        for (int zBJgybcTqS = 385087212; zBJgybcTqS > 0; zBJgybcTqS--) {
            TKGPiLtyJniQaFsS += SSbUzfWRRtGmGt;
        }
    }

    for (int EIaapGxemTs = 1671672950; EIaapGxemTs > 0; EIaapGxemTs--) {
        SSbUzfWRRtGmGt = sgtBNbUdP;
        NrwygaKbyx -= NrwygaKbyx;
        ElQOyFrTQqJmgN /= LoCWhzVXbZdG;
    }

    for (int KzJLeUbEY = 217302491; KzJLeUbEY > 0; KzJLeUbEY--) {
        LoCWhzVXbZdG *= LoCWhzVXbZdG;
    }
}

double XOFogMoQQ::WezhVYvA(int vXhiPW, bool LuWAnxc, string LthLK, int rfjPNAI, int JuyQRHbMjj)
{
    string XjLbbGlkHiv = string("xvhgwEzFJduGmEWUBZocISViAZuZEIIRsrQIZdZKKvHFeNrSzumRuBlXwTJDVrJXtpnusUuuITWXbUaWZLaCxYMHYXMbccvhUedQXqDlSmITwCCfZSSoM");
    int WSQmZTr = 1272800391;
    bool zSfppVZa = false;
    string tTDHLLctxhYG = string("KnNAxrjCplcPnxDASvYnBkZpKsuDOeVxFUiB");
    bool DhHnHjFS = false;
    int RBOXwggjHaBdhhgj = 1274059363;
    string nGlHqoHIzfJJNMK = string("XMGweZKAJjzucrMkkuLfeTfGBphdjSuSKBVMycWPlCeiujOJXEMhJUHKNIRuthCgRoLXUKqfIrroVvtFQwNzIvlQxKMLa");
    double wkYReHxmH = 747931.7818045849;

    for (int ZPuGp = 1399765043; ZPuGp > 0; ZPuGp--) {
        RBOXwggjHaBdhhgj *= vXhiPW;
    }

    for (int jXfPFFuEzdLmeifc = 1833876705; jXfPFFuEzdLmeifc > 0; jXfPFFuEzdLmeifc--) {
        zSfppVZa = DhHnHjFS;
    }

    for (int ebMtYID = 805063621; ebMtYID > 0; ebMtYID--) {
        continue;
    }

    for (int pkxljxoG = 1398918494; pkxljxoG > 0; pkxljxoG--) {
        WSQmZTr /= rfjPNAI;
    }

    return wkYReHxmH;
}

double XOFogMoQQ::vVNfoCQYCiW(double SaEKlsKYsmHD)
{
    bool aGWYcWwn = false;
    double wZeSxNVLa = 204595.61830467128;
    bool eZdXlNoBpTHeW = false;

    for (int rUrFWwGTfO = 686575251; rUrFWwGTfO > 0; rUrFWwGTfO--) {
        SaEKlsKYsmHD *= wZeSxNVLa;
        eZdXlNoBpTHeW = ! eZdXlNoBpTHeW;
        aGWYcWwn = ! eZdXlNoBpTHeW;
    }

    if (eZdXlNoBpTHeW == false) {
        for (int QLqfKsrxKXDG = 637441112; QLqfKsrxKXDG > 0; QLqfKsrxKXDG--) {
            SaEKlsKYsmHD *= SaEKlsKYsmHD;
            wZeSxNVLa += SaEKlsKYsmHD;
        }
    }

    return wZeSxNVLa;
}

XOFogMoQQ::XOFogMoQQ()
{
    this->dMHihttcyU(-944288812, string("LRMlGtqDLqnpKhWkccFKyKBHqCgBICTbRGDPWLSQRJrXKxxenqFqkBDDioAkPKTMtozDVzNrrjAOTwvSOGVhzviczNKnOkAhxOzhSxqyxYplpFuZSTqpBdVxIRXrqfUDwCKMGGslFGQDaFDQbKfcTxnwIwQcRYMMicRpMJxjjHezxywp"));
    this->zIhuNqpsNczApuhN(string("TfCNgSAUfRZQcaiOYjPFjACuLZvwWgPhOrSmcNQXSYzeJvClDxXkLFeRdzJQrZigQHGhinDwKpvkQpAw"), string("UwUSwYzotmHMLJiVFUzIMEmWOYcWIjQyUmQiZvyHmOfWyffXEULQwCAzVMtIchLCZUZUPuqFehkqBGvlRBVuIwLljfJgZYbnIapCxRHAtsOSumuOmfcPuwjZBLbakyvBxYaIKPbWrVSxmVxMQpNHGnixNfWcyTYQyINasjjEpoJRQO"), true);
    this->KYrMNrwKlyLIR(-91965539, string("aeTkecjTYXykkmrUmQRnxVJnzRJxZvmyYoCrDBTyWTPzraqUNYwDgEPreXLstgbCUTOCEnGyYuBPcEWAYlHVUCuJNzWMfERajZiQdFaGstkPfDzHmmdwVdGQYQtlNDUsIUaPqWSXBKjJdtAYuWvkrYHJxkhtlckKIbvhcYrVPLV"), false);
    this->YkaLiJWwN(true, 360470.8372245422, 101873.63045785174, -832609.2232047685);
    this->mDBYGTjTA(98181936, 388841.6806487233, 520597552, true);
    this->anZMRKIrhwTu(575553.6876355577, true, -1780090618, -1403220538);
    this->WiHWbAalJkBT(true);
    this->wpOAKoENmNQq(-962938.4459459224);
    this->tlQvXjnpeH(952818012, true, 196207.95015715744, true);
    this->JRAABGbBznvlh();
    this->TYjKNo(23152.138269565272, string("qCPkzksZOkcinpPMxjdMWxfXtxAnvRpYWRouhVTAVQAWQLAXCtevZgqLCdEtfeewRUIeisLqpaVFqk"), -404127.31515493285);
    this->WezhVYvA(-1202284510, true, string("QyLuQZBwFbEvxUTXNuPknhhSFYBaOThJTCZRnlLzedPFlDlluHbdFvnMMFOtWRCeCWlULWDLJvSBlxbighxsBOFtoGzsydaHnuuSJNbrQLCRDRIHzzBHwYMFsBJYdotcaWlbwGoZkgMukgOYoAoAQubAfISvXAomgZyXkGMaDbwVFQXBFrZMAkiwHecuVcUEdInqCOosFGl"), 1563942592, 524874978);
    this->vVNfoCQYCiW(-929251.3601531577);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lDmJmcchFcS
{
public:
    int XPKnRRdI;
    string LGEfoNhFJ;
    string zbwDDhIMkkPntCo;

    lDmJmcchFcS();
    string bmrtPcfyhS(double xHgKstUZw);
    bool ZFJYMD(double WXAejRacFzytaf, bool Ilyudh, int rXydCQhAYMjK, double HWIRAFFNCcwfh, double TAGixPuVPQAFlbH);
    double uNPPElilcpgDP();
    void drAEbcIfRqT(string UPtnlaItzHcSSH);
    int gJDXkCpDzLH(double LuCTKGFkPeISB);
    int LJSYROZTUqs(bool YnWAQ);
    int koPlxvWN();
protected:
    double DDZdKCGMDPnASB;
    double yRstJLvtFjznTknq;
    string FMCaZoNSLr;
    string WJrzbqxGosV;
    string hzRlQ;
    int aSppivdn;

private:
    bool wvxMlmI;

    bool VOKMkBW();
    int gnmRgTfMontV(double IxrirBaW, double SOimeAODJ, double EaxXWFLmxKVa, bool FBmGnBfKzU, int oCBoyPDrZnFtfGC);
    int NTWTGxYvjR(double FvPXbmldnvlfUNx, int TgTwViTp, double VVHXQbxd);
};

string lDmJmcchFcS::bmrtPcfyhS(double xHgKstUZw)
{
    bool BddlKRnNRnduN = true;
    string awRuHwedNOUxeWp = string("IhmvvPcBknvGFrapHvhglYpqRRGkQauNZKRdqgHWaRQKbQfwyosFIozBwPQPfaUdOnYORqjOhZmWiiGAEFfJtKqAcWUSmRvpnjpWEhzMpLCxsDKLyObceZVtgkscxxIUudmwSYsWEiSOlXkfqxgvRvlTyEvYL");
    bool BFoWRE = true;

    return awRuHwedNOUxeWp;
}

bool lDmJmcchFcS::ZFJYMD(double WXAejRacFzytaf, bool Ilyudh, int rXydCQhAYMjK, double HWIRAFFNCcwfh, double TAGixPuVPQAFlbH)
{
    string qlQSIW = string("jUxNxSXGKrOBStlCTHeEIndQHyCyNxjdMFFFTaAjIDvqwBkdcfyVEHFzasNUKvlUbTQQFcFaOmzsagiDjSRSzuBzcpQPwCxRqZLorLSBuxSNKyKVzHOxwbambuYMLIKS");
    bool YMEWHFujtKWHTV = true;
    int IzAaZ = 1302935511;
    string hyYZSy = string("TSuFQ");
    double qGBNpo = 1033395.4494325285;
    int iZVqZjhxGbRAb = 1002441125;
    double CqMnHRoqfMy = -106695.94292072368;
    double SFvmrrFMlvtfBRdH = 416447.95117131737;

    if (CqMnHRoqfMy <= 515884.40322274796) {
        for (int iZqoVbuJEaJYraya = 186447643; iZqoVbuJEaJYraya > 0; iZqoVbuJEaJYraya--) {
            SFvmrrFMlvtfBRdH += SFvmrrFMlvtfBRdH;
        }
    }

    for (int mqEBhB = 661485090; mqEBhB > 0; mqEBhB--) {
        SFvmrrFMlvtfBRdH /= qGBNpo;
        qlQSIW += hyYZSy;
        CqMnHRoqfMy += WXAejRacFzytaf;
        rXydCQhAYMjK -= iZVqZjhxGbRAb;
    }

    for (int NGkSVaLwuLhb = 158335107; NGkSVaLwuLhb > 0; NGkSVaLwuLhb--) {
        continue;
    }

    for (int MDLfdehhuo = 1993989565; MDLfdehhuo > 0; MDLfdehhuo--) {
        HWIRAFFNCcwfh -= HWIRAFFNCcwfh;
    }

    for (int hECrdhwhWeyjK = 2064372206; hECrdhwhWeyjK > 0; hECrdhwhWeyjK--) {
        TAGixPuVPQAFlbH /= CqMnHRoqfMy;
        HWIRAFFNCcwfh *= HWIRAFFNCcwfh;
        HWIRAFFNCcwfh = HWIRAFFNCcwfh;
    }

    return YMEWHFujtKWHTV;
}

double lDmJmcchFcS::uNPPElilcpgDP()
{
    double zmFPHVZCgY = 952250.787893813;

    if (zmFPHVZCgY == 952250.787893813) {
        for (int fzhAxwgRgEPf = 384064607; fzhAxwgRgEPf > 0; fzhAxwgRgEPf--) {
            zmFPHVZCgY *= zmFPHVZCgY;
            zmFPHVZCgY += zmFPHVZCgY;
            zmFPHVZCgY /= zmFPHVZCgY;
        }
    }

    if (zmFPHVZCgY != 952250.787893813) {
        for (int qEkoCSglDV = 2002078004; qEkoCSglDV > 0; qEkoCSglDV--) {
            zmFPHVZCgY -= zmFPHVZCgY;
            zmFPHVZCgY = zmFPHVZCgY;
            zmFPHVZCgY *= zmFPHVZCgY;
            zmFPHVZCgY -= zmFPHVZCgY;
            zmFPHVZCgY -= zmFPHVZCgY;
            zmFPHVZCgY = zmFPHVZCgY;
            zmFPHVZCgY -= zmFPHVZCgY;
        }
    }

    return zmFPHVZCgY;
}

void lDmJmcchFcS::drAEbcIfRqT(string UPtnlaItzHcSSH)
{
    double pwUdQt = 709463.3752817238;
    int IHKJhNeRiynMrfTK = -1379369571;
    double pKbFxYtSVgixrqCF = -584236.7934257352;
    int RQBRb = 969040582;
    string dhgAMAShvemKZG = string("plGGCoCcHgSirynYZhzScFwhiYTBTsTXPYSLnHUtQcjTjSFzKAjXzJTnMVvEHCVoBUXkpgtNRuQWpTphUBHjgZbrWupfBdDsIOAfNQtamLMmjcOozUzUNWePWZZwMrfDZSMOpowlbWeQEynwEGJqxOqQGI");

    for (int FsvnDKURTDXcX = 1593519945; FsvnDKURTDXcX > 0; FsvnDKURTDXcX--) {
        UPtnlaItzHcSSH += dhgAMAShvemKZG;
    }

    for (int qKEiqORFA = 652956146; qKEiqORFA > 0; qKEiqORFA--) {
        continue;
    }

    if (dhgAMAShvemKZG >= string("xVtYtkShSgiHCkIGqoolMwdxnpBMpTMRbRuXvnawuATdTQrvJfrgsGHBljpNMADnmhLqschhLecRbygyYEGbIPVCF")) {
        for (int kchXdnxAUkVA = 937412747; kchXdnxAUkVA > 0; kchXdnxAUkVA--) {
            RQBRb /= IHKJhNeRiynMrfTK;
            UPtnlaItzHcSSH = UPtnlaItzHcSSH;
        }
    }
}

int lDmJmcchFcS::gJDXkCpDzLH(double LuCTKGFkPeISB)
{
    int PVGFNqh = 243444060;
    double aGEKCMLWgNzmBQT = 310702.4314611503;
    string OvxHrR = string("YeofUgOQidZeTYKSmbgdUpTUPQlIdDYRLQaQiBHGIzNFXJDxSyZIHPffcYPYSOvcbyzlcSzIXXfmLrrAyKqWjFrmpURKnNCABBCbDcvUEbGlHIXwaXgNpewLdPOLGJgPaauXTBBicgVLplD");
    bool RrGroMHQWn = true;

    for (int IUupP = 2012692217; IUupP > 0; IUupP--) {
        aGEKCMLWgNzmBQT = aGEKCMLWgNzmBQT;
        RrGroMHQWn = ! RrGroMHQWn;
        OvxHrR += OvxHrR;
    }

    return PVGFNqh;
}

int lDmJmcchFcS::LJSYROZTUqs(bool YnWAQ)
{
    bool FzvIbEkWgsOTujO = true;
    string ScFJLebmGDBPG = string("boeJnHsFHsioZvUmnPJUHNcNIvANBwHyzwtTMhJrXWKEUnhyFLEacNQEqiLxOLvtxirepHBsTRKkznPuNSJOsMDiFIKnmEqiDZYWSuqWpXycnyigXPXFghEglUaUenVBoOUkpwxCgnjkVbexbHifupFdVvZIpUKBKsAZOTMDeZpXnoMCCGniutNZdquBhHvApGLmNBGFDfvvhkwVkuaocshH");
    string gDPClGZvKyxxx = string("aRLCUaugEDRdkfWQBUACuTvodnQsObSmtzoMZRDlXmBmWIlUwekkCFRhWQScoMCzNkBWrQFBYqsEZrufRfaZfPugOAreIjSJBjFYaroqCinyGRCUXEcFyjPyhKEMoMuMyFelieNgZjhmuLtiCQNDCyTgRDcwwMLywNTFPZCVIaUfqWgiGEcOeHycuaYMLierzdRNnbpdIRZRLdkAGlYFMWcJXYSPYhsOURfzyV");
    string VSRrMEerwkJiIOX = string("KuOokHVWPZCVVPgORhwFOJjYyZhor");

    for (int eGSlqLsafdjs = 779574503; eGSlqLsafdjs > 0; eGSlqLsafdjs--) {
        gDPClGZvKyxxx += VSRrMEerwkJiIOX;
        gDPClGZvKyxxx += gDPClGZvKyxxx;
    }

    for (int nHWmeIWAXm = 1241528725; nHWmeIWAXm > 0; nHWmeIWAXm--) {
        YnWAQ = ! YnWAQ;
    }

    return 1763033342;
}

int lDmJmcchFcS::koPlxvWN()
{
    int UdPOvIO = -325808854;
    bool QNEsCGeapjtS = true;
    int PSXAYAvLsda = -1621156203;

    for (int PGzZkBfYgQ = 1105120484; PGzZkBfYgQ > 0; PGzZkBfYgQ--) {
        PSXAYAvLsda /= PSXAYAvLsda;
    }

    for (int xYhzZfQVxqXMIpfm = 2000870266; xYhzZfQVxqXMIpfm > 0; xYhzZfQVxqXMIpfm--) {
        continue;
    }

    for (int UVURFivaqtKTTWr = 658061311; UVURFivaqtKTTWr > 0; UVURFivaqtKTTWr--) {
        PSXAYAvLsda *= PSXAYAvLsda;
        QNEsCGeapjtS = QNEsCGeapjtS;
        UdPOvIO -= PSXAYAvLsda;
    }

    if (PSXAYAvLsda == -325808854) {
        for (int hdLCPWhY = 493752797; hdLCPWhY > 0; hdLCPWhY--) {
            QNEsCGeapjtS = QNEsCGeapjtS;
            QNEsCGeapjtS = QNEsCGeapjtS;
            PSXAYAvLsda /= PSXAYAvLsda;
            UdPOvIO += PSXAYAvLsda;
            UdPOvIO = UdPOvIO;
            UdPOvIO -= UdPOvIO;
        }
    }

    if (QNEsCGeapjtS == true) {
        for (int aXmTL = 263020000; aXmTL > 0; aXmTL--) {
            UdPOvIO -= PSXAYAvLsda;
        }
    }

    return PSXAYAvLsda;
}

bool lDmJmcchFcS::VOKMkBW()
{
    bool upYOhuvLtIFX = false;
    string eBBKYjWmMAG = string("sHCYydXHMPBPqMfikXTVMOQfDlrPASdCXwhqUocLryYeyexaLIJHZYQDDGScBuTGMgYgjkPHjiGWEGNosREJHyiFlB");

    for (int WTQNoIotlUw = 960525548; WTQNoIotlUw > 0; WTQNoIotlUw--) {
        continue;
    }

    return upYOhuvLtIFX;
}

int lDmJmcchFcS::gnmRgTfMontV(double IxrirBaW, double SOimeAODJ, double EaxXWFLmxKVa, bool FBmGnBfKzU, int oCBoyPDrZnFtfGC)
{
    string feJUguxE = string("rlfpbZDftSeObLYMWLzcsugJfgFVVBiHtPwKcxJIYxkeYecQRjqhOsJwNHxoGVpKlqpsbTlbuHAftuOpoyGCtfBtprpcsIwt");
    string jyyzDYhE = string("pGJRxeLDsaKKqBoLhqqfKBMW");
    string BPgwcWEAnnzBVr = string("JMweenYYyRinYjZFKHIjgIEgWHpqbfsHABYTMbDzevDvfToUtBXqZhNubMHfQciXzCfbIwwFPREbnmZoyaXTszuHbVztJFYcWcWGBcFgXVSeiSqrWHvBqVQuXFovEUsqJzzhjaKnwuYzLxXrhYZQPjgNXPPgGOVPaGokWpJjOQLoSwTdYRIEMkRw");
    int YZnlq = -2147132313;
    double LJxKyyLBIjBB = -754119.8620717792;
    string UAPAYaBehoSZYJ = string("qsUBxUKJhkzBKAlZVZlMqBmzGbhaMIDplUEPsftZiXCmydkAitoSdSTRaQnZRRVzrsSvrRHyXfSqmrsoKbCJJYnKFrKaMwSEpnHSdtbxvgTqytAnimEZYbPPPtWzpJTDIjCDQGBxWeyKBVfw");
    int FZwVWKREn = 1680557035;
    bool vUftDKXJY = true;

    for (int tCEjg = 1189071904; tCEjg > 0; tCEjg--) {
        IxrirBaW += IxrirBaW;
    }

    for (int OIpHDBAbwHtK = 1507085874; OIpHDBAbwHtK > 0; OIpHDBAbwHtK--) {
        BPgwcWEAnnzBVr = BPgwcWEAnnzBVr;
        YZnlq *= FZwVWKREn;
    }

    return FZwVWKREn;
}

int lDmJmcchFcS::NTWTGxYvjR(double FvPXbmldnvlfUNx, int TgTwViTp, double VVHXQbxd)
{
    int sAwYQxTlfKCAfgFX = -588212234;
    int wOzcP = -1473966493;
    double UMOmlLSi = -996156.8757944128;
    double DdwnKEJWUAjDuut = 360045.0592207017;
    double feZjb = -525197.0686123953;
    string CRPlpULHvBDx = string("e");
    double XydiPeUASeS = -153295.83061986623;
    bool uUxCvPuHr = false;
    int MVctrdurkY = -1859089581;
    string iVgDKBCixueisjf = string("oCWyciuddGxVNAcYAdjejVTCSMAkVlZJYzQMHmWtycbKsTbPlLbR");

    for (int TAgpjgJcZS = 1215720170; TAgpjgJcZS > 0; TAgpjgJcZS--) {
        feZjb *= FvPXbmldnvlfUNx;
    }

    for (int CawYoAZOhDCCFsu = 751614700; CawYoAZOhDCCFsu > 0; CawYoAZOhDCCFsu--) {
        continue;
    }

    return MVctrdurkY;
}

lDmJmcchFcS::lDmJmcchFcS()
{
    this->bmrtPcfyhS(927733.1071427248);
    this->ZFJYMD(-428585.309842641, false, 192355114, 105961.5468537309, 515884.40322274796);
    this->uNPPElilcpgDP();
    this->drAEbcIfRqT(string("xVtYtkShSgiHCkIGqoolMwdxnpBMpTMRbRuXvnawuATdTQrvJfrgsGHBljpNMADnmhLqschhLecRbygyYEGbIPVCF"));
    this->gJDXkCpDzLH(85694.0944451168);
    this->LJSYROZTUqs(true);
    this->koPlxvWN();
    this->VOKMkBW();
    this->gnmRgTfMontV(-603563.4101745611, -851524.9866172019, -208063.68708928168, false, -400460779);
    this->NTWTGxYvjR(705081.3901313286, -2014754334, 322874.3637521059);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jLSFTFfedGSCETSw
{
public:
    double FPSdrpcYQJGfHv;

    jLSFTFfedGSCETSw();
    string NCoig(int HPIug, int DoKGkkKDu, string hdADmZbLPKFd, string TDLsXSlUX, string exFYf);
    bool IEBJMseYZTGr(bool TsuiuQOCDlVdIr, string lOwwZqDZdU, int YftlpxwsNVROfllh, int eDfvAdXrwXEj);
protected:
    string gqueE;
    double RVFCPMIy;
    int zLHZPMJVfmv;
    bool pOADPJmWLyGFwiAs;
    string izACvajZttJg;

    bool ICxSvlftMD(int oopAFiLYFxrgkkjG, bool tXlcLcMBuZrvX, bool cYMwZiNrXhL, string CuVNnjgSW, double JMEjFoeazOpucg);
    string eKsnNNPvyO(string SUiJbGooPMwZILd, int mWKXRjRwRlNeOXE, int EiyutnWvXlPUAoTI, int uBRbbXPSdJFec);
    double tYrRhy(bool DBLko, int uVOSVCgeHhr);
    bool eYwpgHKS(bool xcabcZHurbNF, string diKHsH, int jUTxfdxiOSXLwo, int dfRsCQ, double WMRCoIxFqGOPb);
    string QlVgBATHp(double VWyeBjppHx);
    double OGumlpAvFSUc(int CpqOHX, bool TnYBlpY);
    string SaZPTxnRAaEAcR(bool AfCGjpVvUdfS);
    bool rvSJIL();
private:
    string ylKYKDMoPMc;
    int QGRjxaEfomSJfMX;
    bool zUOnQEvRHYSD;
    double jvixQJFTKP;
    bool EJiKs;
    string BDZWEj;

    int CNrUg(bool cqukLe, int XAoWzOUECt, int iMSZWEfAGZ, string NLIhXPCVosUCq);
    double slgbl(double PBtRSRjMRluEGIY, bool pfELsqjgNwPPHWi, int BblXuBU, bool UIImwXQOxcOcVlFO, double SGYfGlNd);
};

string jLSFTFfedGSCETSw::NCoig(int HPIug, int DoKGkkKDu, string hdADmZbLPKFd, string TDLsXSlUX, string exFYf)
{
    string tkDFDibZrbRPYKp = string("qIOoyitxVNACzeGq");
    int ZjjoNetciKmK = -1448048573;

    if (hdADmZbLPKFd <= string("qIOoyitxVNACzeGq")) {
        for (int YYvinpKqOcQgbk = 1563635807; YYvinpKqOcQgbk > 0; YYvinpKqOcQgbk--) {
            continue;
        }
    }

    for (int lwWgkBZJ = 1647340065; lwWgkBZJ > 0; lwWgkBZJ--) {
        hdADmZbLPKFd += TDLsXSlUX;
    }

    for (int nGOEJIgQO = 1228682652; nGOEJIgQO > 0; nGOEJIgQO--) {
        DoKGkkKDu /= DoKGkkKDu;
    }

    return tkDFDibZrbRPYKp;
}

bool jLSFTFfedGSCETSw::IEBJMseYZTGr(bool TsuiuQOCDlVdIr, string lOwwZqDZdU, int YftlpxwsNVROfllh, int eDfvAdXrwXEj)
{
    string QLqrGCLFMVpInAMD = string("ValFroRbfNINRhZJwnbGJuBaaFHACcYIWesNLOGnwZIdDlayCMPQdmicTcDNDletnFXwLzLaPpKgdoypfqdBXFkPDxRoPzNrlgVAmdtUgBaxxRNItfDIucBdjWdZwdnAvvGLOgZldkKUbmNQjuPLAFsNelOgctzKIuSNDXwWixQcoyZLNXdZzOEnJnuBNSjEbWkAOmCqOmMHgHZczX");
    double jpVROhazWQEyXk = 101279.92997897719;
    bool PHuomVhf = true;

    for (int EXSoFsaMvgDWrK = 320216480; EXSoFsaMvgDWrK > 0; EXSoFsaMvgDWrK--) {
        PHuomVhf = ! TsuiuQOCDlVdIr;
        eDfvAdXrwXEj /= YftlpxwsNVROfllh;
        jpVROhazWQEyXk /= jpVROhazWQEyXk;
        TsuiuQOCDlVdIr = TsuiuQOCDlVdIr;
    }

    return PHuomVhf;
}

bool jLSFTFfedGSCETSw::ICxSvlftMD(int oopAFiLYFxrgkkjG, bool tXlcLcMBuZrvX, bool cYMwZiNrXhL, string CuVNnjgSW, double JMEjFoeazOpucg)
{
    bool BeEeQGHQKxCw = true;

    if (tXlcLcMBuZrvX != false) {
        for (int qKqgZdA = 613263381; qKqgZdA > 0; qKqgZdA--) {
            continue;
        }
    }

    return BeEeQGHQKxCw;
}

string jLSFTFfedGSCETSw::eKsnNNPvyO(string SUiJbGooPMwZILd, int mWKXRjRwRlNeOXE, int EiyutnWvXlPUAoTI, int uBRbbXPSdJFec)
{
    int lhwiTPAeMGFL = 1821499237;
    string DQUqkwrNYXXd = string("OXAtsmbrsWgbeNeCEQaANgyjDUGaAjRFLZZLtWhVFOaxPCjolRaGQQTDtlOJtpZTkatEgoFfvpDbMoFaniZSYTrZmiEdTCJEjLLgpLKSGFZOHIMaSTvKRiomqLuCGmIjOnRrfhNtBOBYCzkOCFmhSkKNRQtvwROzNSOJcBCuKlxPXTJoNAiXaeLvJQlFHCHifoxFWEympBFicRbKvZBsLWZxukZAmsEOKFTxGpjJvyvzxV");
    string zpUfqjAqmcj = string("yNYlaSpEgZPRlbhGReAxUoxvtIDqoZZKDJjmMQlDhhBuSdhInmATwdFUiQEhEamSrlZQKYLEXVDbQQvmNHfQoqugPAjetKYzOtexjvWbgCfOtKJRxZVxzWkoMBWwcpldNvrFzjJPSzLQUkXImzRsXExsuSbZtDRXpskMDnnYCLLuoNZpfufrlEsuZdtgOwUdxDIKCjZsKoFTLNSPAQzdBazBoKINHJtXLBtkMqf");
    string FegVpG = string("tKdAbElkNCmLRXIuOpQkRoepHyBnjnMxfgIXYQUBJEJxeSBabRHaiQgeRUOkvAGCQKhGXcCFpUZvCQFWuOaWyebxSicTfRRyqgkrHyhFHgJqhjSHovghGNAQAbORHcDwZGupxCpWEbLRcfhKDMclyEGQRKhuOzLZAGMq");
    string UBNbgOZXJEsWj = string("MWmfbCHlSOrGKsBXScwUVxrQEDUoYvAHvVcYqJkFSfSCWYICYWbPxHRWQTRZjTdUmKbblRzrAtXEFfzyeCsLbXqRHGetzWkgFzEbdwbxaQiflQmFrfaVZl");
    double fuCJTeYXKcvi = -985549.2590987468;
    bool WKzZbJNeNaotFtG = true;
    bool CIVSWWdk = false;

    if (EiyutnWvXlPUAoTI != 1388136084) {
        for (int ukxdQW = 951747523; ukxdQW > 0; ukxdQW--) {
            continue;
        }
    }

    if (EiyutnWvXlPUAoTI < 1388136084) {
        for (int zfzRdBkTplDsAiP = 2135452928; zfzRdBkTplDsAiP > 0; zfzRdBkTplDsAiP--) {
            UBNbgOZXJEsWj = UBNbgOZXJEsWj;
            mWKXRjRwRlNeOXE = EiyutnWvXlPUAoTI;
        }
    }

    return UBNbgOZXJEsWj;
}

double jLSFTFfedGSCETSw::tYrRhy(bool DBLko, int uVOSVCgeHhr)
{
    bool ewoKZAojhUt = false;

    for (int HfwzN = 1972926344; HfwzN > 0; HfwzN--) {
        ewoKZAojhUt = ewoKZAojhUt;
        ewoKZAojhUt = DBLko;
        DBLko = DBLko;
    }

    for (int RpiLQquJ = 2109450055; RpiLQquJ > 0; RpiLQquJ--) {
        ewoKZAojhUt = ! DBLko;
        DBLko = ! DBLko;
        ewoKZAojhUt = DBLko;
    }

    if (ewoKZAojhUt == false) {
        for (int qgrvQCZrooGa = 2055772979; qgrvQCZrooGa > 0; qgrvQCZrooGa--) {
            uVOSVCgeHhr += uVOSVCgeHhr;
            DBLko = ! DBLko;
        }
    }

    if (DBLko == false) {
        for (int EuXhfzsaCgH = 1137145610; EuXhfzsaCgH > 0; EuXhfzsaCgH--) {
            continue;
        }
    }

    for (int edThLc = 176411205; edThLc > 0; edThLc--) {
        ewoKZAojhUt = ! ewoKZAojhUt;
        uVOSVCgeHhr /= uVOSVCgeHhr;
        ewoKZAojhUt = ! DBLko;
        ewoKZAojhUt = DBLko;
        uVOSVCgeHhr = uVOSVCgeHhr;
        DBLko = DBLko;
    }

    if (DBLko != false) {
        for (int okASRP = 1925440724; okASRP > 0; okASRP--) {
            ewoKZAojhUt = ! DBLko;
            DBLko = ewoKZAojhUt;
            DBLko = ewoKZAojhUt;
            DBLko = ewoKZAojhUt;
            ewoKZAojhUt = ! ewoKZAojhUt;
            DBLko = ! ewoKZAojhUt;
        }
    }

    for (int NsXBtlzaTqUS = 51507891; NsXBtlzaTqUS > 0; NsXBtlzaTqUS--) {
        ewoKZAojhUt = ! DBLko;
        uVOSVCgeHhr = uVOSVCgeHhr;
        ewoKZAojhUt = ! ewoKZAojhUt;
        ewoKZAojhUt = ewoKZAojhUt;
    }

    return 716115.5647758592;
}

bool jLSFTFfedGSCETSw::eYwpgHKS(bool xcabcZHurbNF, string diKHsH, int jUTxfdxiOSXLwo, int dfRsCQ, double WMRCoIxFqGOPb)
{
    double wwMGekrAjJ = -180582.3703905873;
    int yIGvd = -408123649;
    int OBIyAmpmSPjc = 910812196;
    bool wIGqqNOpVwBp = false;

    for (int ZDLLJ = 1510772855; ZDLLJ > 0; ZDLLJ--) {
        yIGvd -= OBIyAmpmSPjc;
        xcabcZHurbNF = ! wIGqqNOpVwBp;
    }

    if (yIGvd > -408123649) {
        for (int kUAfE = 1736118065; kUAfE > 0; kUAfE--) {
            wwMGekrAjJ *= WMRCoIxFqGOPb;
            yIGvd *= dfRsCQ;
        }
    }

    if (yIGvd != 377243089) {
        for (int swRyXukzFyliWo = 1086495405; swRyXukzFyliWo > 0; swRyXukzFyliWo--) {
            WMRCoIxFqGOPb += wwMGekrAjJ;
            xcabcZHurbNF = ! wIGqqNOpVwBp;
        }
    }

    for (int TblcFokzuSmUv = 1086883991; TblcFokzuSmUv > 0; TblcFokzuSmUv--) {
        yIGvd *= jUTxfdxiOSXLwo;
        OBIyAmpmSPjc -= OBIyAmpmSPjc;
        wwMGekrAjJ /= WMRCoIxFqGOPb;
    }

    if (wIGqqNOpVwBp == false) {
        for (int TNVYxcxy = 678683572; TNVYxcxy > 0; TNVYxcxy--) {
            continue;
        }
    }

    for (int xmWSC = 906890716; xmWSC > 0; xmWSC--) {
        jUTxfdxiOSXLwo = OBIyAmpmSPjc;
    }

    return wIGqqNOpVwBp;
}

string jLSFTFfedGSCETSw::QlVgBATHp(double VWyeBjppHx)
{
    int AHtqjCuH = -151794133;
    bool qmZZIejRbkvSGzC = true;
    double bomLMTcNBpe = 684984.6675297125;
    int uBBbB = -1972351124;

    if (bomLMTcNBpe < 487587.32087024703) {
        for (int wAaoogE = 2050656641; wAaoogE > 0; wAaoogE--) {
            bomLMTcNBpe += bomLMTcNBpe;
            bomLMTcNBpe -= VWyeBjppHx;
            AHtqjCuH *= uBBbB;
            uBBbB /= AHtqjCuH;
        }
    }

    for (int BrHUG = 667656998; BrHUG > 0; BrHUG--) {
        bomLMTcNBpe *= bomLMTcNBpe;
    }

    if (VWyeBjppHx != 684984.6675297125) {
        for (int BHcSTZmXtcVTBD = 594702399; BHcSTZmXtcVTBD > 0; BHcSTZmXtcVTBD--) {
            AHtqjCuH += uBBbB;
            VWyeBjppHx = VWyeBjppHx;
            VWyeBjppHx = VWyeBjppHx;
            qmZZIejRbkvSGzC = ! qmZZIejRbkvSGzC;
        }
    }

    if (VWyeBjppHx != 487587.32087024703) {
        for (int gFzdrUNoXpHnS = 2058922690; gFzdrUNoXpHnS > 0; gFzdrUNoXpHnS--) {
            uBBbB = AHtqjCuH;
            VWyeBjppHx = VWyeBjppHx;
        }
    }

    if (bomLMTcNBpe < 684984.6675297125) {
        for (int DzVVrdiUc = 1706365788; DzVVrdiUc > 0; DzVVrdiUc--) {
            VWyeBjppHx = bomLMTcNBpe;
            VWyeBjppHx = VWyeBjppHx;
        }
    }

    return string("kxRUqHBImrzSQJJghcbTTXeJcFIEYlvUUrbBAwZAJfRKwuIuBFSiaiULGVfQRRnHhMIKoyHCAxxQvxUDxHXefMDnkJGZsJSbvlUuNoHNQqajukEkpFqyPnXYkgVlGKXBottQZErbAapoTkovZZEzvCljiPN");
}

double jLSFTFfedGSCETSw::OGumlpAvFSUc(int CpqOHX, bool TnYBlpY)
{
    bool sYYfN = true;
    bool dzIAKYe = true;
    double KfDKmvxlXlRuR = -709395.3291998196;
    int KVHEG = 934073715;
    bool uqWWWipwSkTvD = true;

    return KfDKmvxlXlRuR;
}

string jLSFTFfedGSCETSw::SaZPTxnRAaEAcR(bool AfCGjpVvUdfS)
{
    int JrmliKSVek = -1066595359;
    double RUkSYUXFgVTPoXi = 1043765.192613546;
    int VyyMxxnyUjcxR = 180915713;
    string RvEevXVQrMEYQN = string("bFRHdYEGisyduduDLRzUpwJZUStZPZgHkvzkABclVZtoRDWblbIzcZBvogMIOdewAtKlKOyOKTTtCphCdrDEKQRGeEePxloqJMDGtvqqbypdtLqlYOmSDhtMWzRXPCoQhYLygTsffL");
    bool eamuzBAarLeIMq = false;
    double CnCXTGewWpqaYin = -724909.0156653733;
    bool RbpGTxxpjUTbdcZp = false;
    string kAgEwig = string("cte");
    string eHOwPnw = string("SxyNPwJBAXTMnnzhxmNoQDCkYUrWzlurgMRXjBjvAYxiwbeuESTcZvPRdYNOvKkSfmynorUVAdFoVLmNsxWsyaERdllLhpqQoPoAZeqwrRVFTZcuohCbxtNWRBhGguaCxNaZGlRTYpNMNdtSeOYzaPrKzTOEphxrUZMGEDGJokLiCwtXtgEKjIkzUoLwQmzfllBRuZVpULCeoNejVaMddELmzQvqYPsKMCHCzXvWQZLIHCFAtYxlgP");

    for (int VnhDozbRLKGbXc = 1262787998; VnhDozbRLKGbXc > 0; VnhDozbRLKGbXc--) {
        continue;
    }

    for (int FBSowiXfl = 184628079; FBSowiXfl > 0; FBSowiXfl--) {
        JrmliKSVek -= VyyMxxnyUjcxR;
    }

    for (int dOnOMizgH = 624522194; dOnOMizgH > 0; dOnOMizgH--) {
        CnCXTGewWpqaYin += CnCXTGewWpqaYin;
        kAgEwig = RvEevXVQrMEYQN;
    }

    if (CnCXTGewWpqaYin >= -724909.0156653733) {
        for (int EYsXGalh = 106592976; EYsXGalh > 0; EYsXGalh--) {
            CnCXTGewWpqaYin /= CnCXTGewWpqaYin;
            AfCGjpVvUdfS = eamuzBAarLeIMq;
        }
    }

    return eHOwPnw;
}

bool jLSFTFfedGSCETSw::rvSJIL()
{
    int KfGQloYR = -299938937;
    bool dxTJWzrTxHVZmDv = false;
    string BBglHMMHhzX = string("FDvbwsItDzFr");
    double fZyLDIHTPaibggJl = 154743.2768148867;

    if (dxTJWzrTxHVZmDv == false) {
        for (int ondiNfEffBXEs = 145837632; ondiNfEffBXEs > 0; ondiNfEffBXEs--) {
            continue;
        }
    }

    for (int hDchLo = 230758289; hDchLo > 0; hDchLo--) {
        dxTJWzrTxHVZmDv = ! dxTJWzrTxHVZmDv;
        BBglHMMHhzX = BBglHMMHhzX;
        KfGQloYR = KfGQloYR;
    }

    for (int GfJYUTcBaZxUJlD = 1714015290; GfJYUTcBaZxUJlD > 0; GfJYUTcBaZxUJlD--) {
        BBglHMMHhzX = BBglHMMHhzX;
        KfGQloYR /= KfGQloYR;
        dxTJWzrTxHVZmDv = dxTJWzrTxHVZmDv;
        BBglHMMHhzX = BBglHMMHhzX;
        BBglHMMHhzX = BBglHMMHhzX;
    }

    return dxTJWzrTxHVZmDv;
}

int jLSFTFfedGSCETSw::CNrUg(bool cqukLe, int XAoWzOUECt, int iMSZWEfAGZ, string NLIhXPCVosUCq)
{
    int HRfLeHxJGTpt = 1370116600;
    int YTSYRMBLKmlSdu = 1305059053;
    double EQRPzICtFLxuKckv = 253801.28734560066;
    int FAlzYLtmF = -1073241737;
    bool RDeXuC = false;
    int ODIBzcw = -1216133696;
    bool BFbkwxavO = false;

    if (YTSYRMBLKmlSdu < 1370116600) {
        for (int AGWhTmhjluzDClt = 1740387962; AGWhTmhjluzDClt > 0; AGWhTmhjluzDClt--) {
            HRfLeHxJGTpt += XAoWzOUECt;
            iMSZWEfAGZ = ODIBzcw;
            XAoWzOUECt -= HRfLeHxJGTpt;
        }
    }

    for (int XIXhDuGnjFyOw = 317668148; XIXhDuGnjFyOw > 0; XIXhDuGnjFyOw--) {
        ODIBzcw -= XAoWzOUECt;
    }

    for (int LpnhNxlHS = 576918391; LpnhNxlHS > 0; LpnhNxlHS--) {
        FAlzYLtmF += HRfLeHxJGTpt;
    }

    for (int TDtlF = 1098796956; TDtlF > 0; TDtlF--) {
        ODIBzcw = iMSZWEfAGZ;
    }

    if (XAoWzOUECt != 1370116600) {
        for (int tdhgbiafTJq = 341948419; tdhgbiafTJq > 0; tdhgbiafTJq--) {
            ODIBzcw *= XAoWzOUECt;
        }
    }

    return ODIBzcw;
}

double jLSFTFfedGSCETSw::slgbl(double PBtRSRjMRluEGIY, bool pfELsqjgNwPPHWi, int BblXuBU, bool UIImwXQOxcOcVlFO, double SGYfGlNd)
{
    double CqLXjEgIGjCe = 78666.57704852796;
    int uqTwhZPiD = 1594837172;
    bool MmTJE = false;

    for (int TpCVi = 1963979617; TpCVi > 0; TpCVi--) {
        BblXuBU += BblXuBU;
        MmTJE = ! pfELsqjgNwPPHWi;
        CqLXjEgIGjCe += PBtRSRjMRluEGIY;
    }

    if (CqLXjEgIGjCe <= -323433.5119442964) {
        for (int bKfhs = 1037748770; bKfhs > 0; bKfhs--) {
            MmTJE = UIImwXQOxcOcVlFO;
            UIImwXQOxcOcVlFO = ! MmTJE;
            MmTJE = pfELsqjgNwPPHWi;
            MmTJE = MmTJE;
            SGYfGlNd += SGYfGlNd;
            SGYfGlNd *= PBtRSRjMRluEGIY;
        }
    }

    if (UIImwXQOxcOcVlFO != false) {
        for (int INgmuIh = 1827688384; INgmuIh > 0; INgmuIh--) {
            MmTJE = ! MmTJE;
            BblXuBU -= uqTwhZPiD;
            MmTJE = MmTJE;
        }
    }

    for (int BdyXKtVvgpkm = 447800365; BdyXKtVvgpkm > 0; BdyXKtVvgpkm--) {
        pfELsqjgNwPPHWi = ! UIImwXQOxcOcVlFO;
        CqLXjEgIGjCe += SGYfGlNd;
        BblXuBU /= BblXuBU;
        MmTJE = UIImwXQOxcOcVlFO;
    }

    return CqLXjEgIGjCe;
}

jLSFTFfedGSCETSw::jLSFTFfedGSCETSw()
{
    this->NCoig(150861406, -1715708023, string("xbeRXSFwNBQbMopzubnD"), string("HGQuaeCNERLDfkbNQIC"), string("dPJbkosEynqDPsDFwzhrcgaXACEaBwJmgoMScsfupwjsFwIsIXifYglKDzKeVYHoySiGytifokRJoapxJsFBMMzGeLqjYDDHDlveXtnTCvMwZzyQbLTnedhvcFBYjMYehbVJlWWtfVieuomutAFtaWcJANBRQye"));
    this->IEBJMseYZTGr(false, string("AosqnHqlHMSWGIjoUpfnYAppBnGgrgbWgCswYJscRMJQigGoKuw"), 2023912708, 1770610524);
    this->ICxSvlftMD(196830268, false, false, string("BTKVhBZRMrOryAYircpAoEogQZZbbSFvSSWDvBaMgtREtuskOfKbtYtdIvGB"), -66777.51203609126);
    this->eKsnNNPvyO(string("SrxlnrjGmWazmcqJHEqkDBiUnwGbGlzFFDdnLgumOGDzgCFKVTbViCesULFQEwOOMCziqJdBwizYBNmTfezmqnoWYnDtfDblyihMNaWbNZzuMGLuxDizFOxrQwXItroIEuHnSPFQmedqMHHZOJjEXkTFMXcrQEDStwzJmJlZawkpTebpNzDgFuwimMGaQeOMPeLXPbtwoJdArdfbWAwUleNHMobKxryHYyuZMCXVKoUnvVDQY"), 1388136084, -1214205266, 273103170);
    this->tYrRhy(false, 1497265220);
    this->eYwpgHKS(false, string("iigxYlBHriWoAZzhqEaxzkIEsSvmAhIBizuHSfwmVbVAmYKRWnOoAcMtYUYnPLiAprryDOKigkNAsGfgFERRIIHmHtXlZRyDrBfRhHPdcEDTjQzvluqpZEOGdlfLjQhdLnEtatmaTydJLBwLjVfHJaTKQjXTvcgYijjPeTkFALbfeLdKuiPRQrMM"), 377243089, 1097533152, 405447.324610301);
    this->QlVgBATHp(487587.32087024703);
    this->OGumlpAvFSUc(2041801692, false);
    this->SaZPTxnRAaEAcR(false);
    this->rvSJIL();
    this->CNrUg(false, 1909043728, -1407872410, string("NzTcNxmBTmcjhgmRYJFztgjpUYuRghySHQJtuyzjDueJtdLtmKQvJPOFnBxCToqvRUlXnFJcchWSaNHmfIxfdMTmweWVOQqZpgGziVTygTDCFPoNUaBPJAlBvznHQfaoIrmyPnCopfWHFMSwOGKVcvVtYqSqBSkjmSUbptTpFaxxNEAlXeEOVlwT"));
    this->slgbl(-323433.5119442964, false, -318079823, true, 817067.9865237438);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AmhAdpNWMtAPyVHs
{
public:
    string HwGzfZLXXjSFOc;
    string NxGPibHoALjyqq;
    int eeWqkzMkLTJaNf;
    double XRnGFnsLdSRHvE;

    AmhAdpNWMtAPyVHs();
protected:
    int SRmdwzzVBjE;
    string SKiBw;
    bool CaERGQRnzFwyo;

    double LooIUK(string esHZu, bool OTZgkVgiutHjdNYc, bool wxcYSXamH, int wAliIszSGi, bool vbCdCEUoNaQIyQ);
    double siOsKvKPVKH(string kvRmYqpzNQyizC, string ssqzSKBkDOVzn, string ZmwsjFUuXEaqBDaO, double MSGScI);
private:
    int SQOtJefR;
    bool HDgLacWMjKxw;

    string TGxeymCjUXsW();
    string MCTMQgQRX();
    void YKYUhEsnH(int bwPGuS);
    string dHuTat(bool IqFNFYn);
    int MZslaumH(string LROnoSTHWzs, bool BYzGJFZx, int xyhZJensDOezlc);
    double hfpIaDoXR(bool oAtWWJTFZx, int JqlFBzjDMr, string Shwsao, int bXyTuvCsV, bool ZISmh);
};

double AmhAdpNWMtAPyVHs::LooIUK(string esHZu, bool OTZgkVgiutHjdNYc, bool wxcYSXamH, int wAliIszSGi, bool vbCdCEUoNaQIyQ)
{
    string RbVBuRhR = string("TOYZfjpUYLVoehDrlTBGKBkupNRatixzIxtCiIVgWIXBiWaMsYtIAcqnpZHOqPCbtSPPHCpGiizkATTpIYBcVCZzGXdIIBpEwhgCsXxjjnOmYxZOaSmNxcerAdSKFYOnkCfnlISuJrARoegQUclEHvyZqtBOJyMDVbDUPgFDalVwmBSIQinIbysMbyDEeMhb");
    int vcrQdJWB = -1290065043;

    return -624391.8633817027;
}

double AmhAdpNWMtAPyVHs::siOsKvKPVKH(string kvRmYqpzNQyizC, string ssqzSKBkDOVzn, string ZmwsjFUuXEaqBDaO, double MSGScI)
{
    bool ESiQOHjuAxUfQOlR = true;
    int NjWAiTJnyinZq = -131718749;
    bool gJIqyjCjxkwqm = true;
    string ouVpwK = string("DutBmMah");

    if (kvRmYqpzNQyizC == string("DutBmMah")) {
        for (int wqoFAuDq = 278690091; wqoFAuDq > 0; wqoFAuDq--) {
            kvRmYqpzNQyizC = ssqzSKBkDOVzn;
            ouVpwK += ouVpwK;
        }
    }

    for (int QJabqFW = 1595047804; QJabqFW > 0; QJabqFW--) {
        gJIqyjCjxkwqm = ESiQOHjuAxUfQOlR;
        ouVpwK = kvRmYqpzNQyizC;
    }

    return MSGScI;
}

string AmhAdpNWMtAPyVHs::TGxeymCjUXsW()
{
    double TSEHkB = 234098.36677127716;
    string sxaKkY = string("ZfAdIzcIYbb");
    bool dIpGGVzKpPfCo = true;
    bool XniXFIXcexPwPJOd = false;

    for (int LOjeodrxNNHqZYEq = 2110738193; LOjeodrxNNHqZYEq > 0; LOjeodrxNNHqZYEq--) {
        sxaKkY += sxaKkY;
        sxaKkY = sxaKkY;
    }

    return sxaKkY;
}

string AmhAdpNWMtAPyVHs::MCTMQgQRX()
{
    bool IqZCdHxKW = false;
    bool ieVSiOrIcRUzevkh = false;
    string mPnaGlMVnQQj = string("alletgaCQoDgQmobSaOMMLOudIqXKikVfPDSKnYuYjaNkkKRcEaTQArQcoebbUfRBhzTPfmgIRsXPQrmcdSwBFhooUYPgNzlhqtfanFLsmpFoNifvgxdhvDIQQcVAPcudHtngbPOtCLTlYkKMsutvCVTyRIhvtQQCFJrsHZkWFfCHLCTemgqNgOSGgoONEOweGqTDLJOpOgGBIteOsDJHTXGTJ");

    if (IqZCdHxKW != false) {
        for (int PpvzCtLzH = 1087482663; PpvzCtLzH > 0; PpvzCtLzH--) {
            continue;
        }
    }

    return mPnaGlMVnQQj;
}

void AmhAdpNWMtAPyVHs::YKYUhEsnH(int bwPGuS)
{
    int nRklNUszwQ = -1722460348;
    string bOBUIxGKkYTCw = string("UkJvKpDbtkWJcYMGVKCKHgjpBZqXpxSZCQiKYowajwcsqqQxmkZWHiuGDSoEafWtRsArVDtveMjCSiwObcDrVTQYvweAEWkFJSCyeZarKSXTRNozxjPlmJkizZSTxXVZyItxwUHhKDOzaFoikHfxFehjrRpUikJOWfTlCvoMwptuECgwiuSFtLfWRookBKxgJqpYrdELWSbSkQEJshgCkPpoJcjxuVyXNRJngQPyKMzQLuLGjExSYoxJy");
    string vKUdwMrXgkoXZtYe = string("LLiEhmDOTzXfYWxXQhZATxnDQndBDyRSZwNYooHMGFuzCjVNzxDAJHLVuGanVXWNUlWZkAnVIpzZabcL");
    double MBLgifW = -724405.9450320067;

    for (int oTaccGtIPefWxmy = 568218259; oTaccGtIPefWxmy > 0; oTaccGtIPefWxmy--) {
        MBLgifW += MBLgifW;
        vKUdwMrXgkoXZtYe += bOBUIxGKkYTCw;
        vKUdwMrXgkoXZtYe += vKUdwMrXgkoXZtYe;
    }

    for (int GPxUtoJAKC = 78965834; GPxUtoJAKC > 0; GPxUtoJAKC--) {
        bwPGuS *= nRklNUszwQ;
        bOBUIxGKkYTCw = bOBUIxGKkYTCw;
        bOBUIxGKkYTCw = vKUdwMrXgkoXZtYe;
    }

    for (int kaBRxIyrI = 1677720808; kaBRxIyrI > 0; kaBRxIyrI--) {
        continue;
    }

    if (nRklNUszwQ < 455790934) {
        for (int tGQEfsamMUszCI = 1161329466; tGQEfsamMUszCI > 0; tGQEfsamMUszCI--) {
            bOBUIxGKkYTCw += vKUdwMrXgkoXZtYe;
        }
    }
}

string AmhAdpNWMtAPyVHs::dHuTat(bool IqFNFYn)
{
    int eINlopsZfTwW = -1987901;
    bool axtWzDs = true;
    int hqyNVQQF = -1243707234;

    return string("jpffPdRTjBoVGyaQljZsyXSxFXaMz");
}

int AmhAdpNWMtAPyVHs::MZslaumH(string LROnoSTHWzs, bool BYzGJFZx, int xyhZJensDOezlc)
{
    string JZyPMgxAxarRtlK = string("EKJfGHzdDJtSMhkfByCWKbZqMOAhMMQ");
    bool wqSsYX = false;
    string DzBJCZ = string("TQCeFjthcMoBVRZKVgTatzEvCPYbKpNyufXYCjFeafNskyMElJrzqpLAtqijrGKlSIjqhcmEqzUjWlUqGtCilAKBZJJMJTdLrBIoyWeYavtifmtIMhqyzhtUhSDMJeUlMJchQCWTNgbplHGefeCaevCelylm");
    double TnenKJQ = 414035.646822517;
    string TAnNvVUD = string("uxnrMEuzbheDKgqQDobffLVfnpdhsusjDvUNRKgqkNzblNOpqqwCOZYhEKeroYRtaNjmJeqcQrnvzjHGvENHIkpcbyITbzGuZcvqapKDqYKjQxcXpHcLAeIOjXVVVNXkXBjeeAyqLIKlIscCdDpOJfpGkbSruyIHabKLzTociAPoodUdmnyNIXClIKriNDdTuJTvSrSbnSGEVEMPikajvOjhzDwNhHXgxSkTYqBOiQf");
    double jcwqQJzysiK = 103715.50164628554;
    bool ytmMizXbqFh = false;

    for (int yaHtGdtjSeQphIHQ = 1754610112; yaHtGdtjSeQphIHQ > 0; yaHtGdtjSeQphIHQ--) {
        continue;
    }

    return xyhZJensDOezlc;
}

double AmhAdpNWMtAPyVHs::hfpIaDoXR(bool oAtWWJTFZx, int JqlFBzjDMr, string Shwsao, int bXyTuvCsV, bool ZISmh)
{
    int DEuTGGzVIKcNI = 579627749;
    int ZHwEDn = -904488268;
    int xurLHF = -598704016;
    bool bWlmikDtIP = false;
    int ZgoZlwzCMw = -1768676554;
    string akioOCnwwK = string("OhQvQAeemqCDaLGLOSQxvdwwZnVQRtSqlyXEOUMssjxGieyjQmEpLbeVGcUlYZrKOCmvQ");
    string UyDOzB = string("MSpJALGbtdJvHUXXPLGVLIBuyzGxuwXIVDPWrFRZQDCnewNsPDStLtiVwHwBVHDubvQnvvoeViaR");
    string DfYBOUQiiL = string("KNzoCmRyrNbCjNfFNhEVjxKKrTNXhkMmFJlcdtbsXfguBEYBenlPiexHHFNoGaZqyjHcTCfJtwPikFNEeHf");
    double shReV = -308238.01053548115;

    if (oAtWWJTFZx != false) {
        for (int EYBVTiTgntDkTVB = 1407127565; EYBVTiTgntDkTVB > 0; EYBVTiTgntDkTVB--) {
            continue;
        }
    }

    for (int JraTvYDECQCPD = 28938636; JraTvYDECQCPD > 0; JraTvYDECQCPD--) {
        DEuTGGzVIKcNI /= ZgoZlwzCMw;
    }

    for (int MXHOsBkzYjEJ = 194111332; MXHOsBkzYjEJ > 0; MXHOsBkzYjEJ--) {
        continue;
    }

    for (int qCBFwoVMvu = 2070282386; qCBFwoVMvu > 0; qCBFwoVMvu--) {
        xurLHF += ZgoZlwzCMw;
    }

    return shReV;
}

AmhAdpNWMtAPyVHs::AmhAdpNWMtAPyVHs()
{
    this->LooIUK(string("VZPMIXyNvcwRXbknXLGHALxyqmfeuDdpwsbVWuJgszDHhhtPetgsgyspooitNDhwbjvRuYQdZpwHJoUAqdf"), true, true, -336218812, true);
    this->siOsKvKPVKH(string("xuqfepCTwQfSiJIbVCCqxMTVXPiMtzWyIuvBzwpXHnlXEiNSXesmHfcPapHavjjkLxokLsjmMDjEVMkszdZjZwPgjarEwfkhdwwBEHG"), string("VSMgnSxKZhImBOMNwAqCVqvxKYVyPcRCuHfwxAJSADyU"), string("iYFHuSxhJJMgWhrzeiDFhmFspQsPtToDXyJohGDjbAbQDyvelmrdjIlDwYIccFYtDJqxRTymWYFdMIFyPKLGrfukpqscxTQCEPVlXgGwTUkEwFGRNdobYIyaeUORJuWsASatBOYku"), -638372.9860514158);
    this->TGxeymCjUXsW();
    this->MCTMQgQRX();
    this->YKYUhEsnH(455790934);
    this->dHuTat(false);
    this->MZslaumH(string("GQiGtlrbnpQLcSmxYfBwgpYfUSsqWhSHZRgpqqSECaBHwIORWBrJhxbAgssZYWVoiFDGPUswSMnVwuHGyMBbDDxOJYyQIPfnytNwFdGyhugSHUrOQbkzioqCUzftmYduhDbQiHofreLJrJDMoSrMeLTyOjUxYtYCAmPYHjARdJzpWQup"), false, -1285764785);
    this->hfpIaDoXR(false, 88208094, string("jiIVtZfJRnrpupaQflpzfGbHADNzUarbXdZDRMuvyCnEGLjirYdGRvkZzxnqWdXOirmmUkDewhqgswBBsCggmQIPOklIqglPEbgPpEyAeNylBgnfjkuUbCXiaPgfycGdDTDWnSBpDfQGtMpLMGQpuyfDiQJWedQdOwcWrZLGWp"), 997312932, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bMtGSHZijRlqOSZV
{
public:
    int VuhJIzyUd;
    bool enFCOVLwxwyEZZLW;
    int ctWdQ;
    string hvbWa;
    string hPMdHYfzoXTgvFy;

    bMtGSHZijRlqOSZV();
    string TMBOaUcXwzVfWY(double oilyELJwC, int neOYUQPJm);
protected:
    bool FsJCvX;
    int FqMozUIytAJwUfDE;
    int Hfmrxjqu;
    string RbXrsVALyL;

    string zfnRAJkMmpIY();
private:
    bool RApnhBIs;
    int HKGgr;
    double sPMWqQEoM;
    int EIspWroapYy;
    int JPobLXUCZRiTMrF;

    string YUjqXLudQ(int SavbIlReDAGKA, double PaVNyoVSi, string VqgAvUU, string IEwwoynnsmn);
    int oYRfuHd(bool xvZbpqvI, string QIXQujfhMIgcl);
    int ycBDneNnPrI(string aElxbUIQtMW, int fDNyjfy, string NPzOaujCzxecCdr, double lJHMLf, string yEQtWNmE);
    int GAVgcQF(bool ljNDSe, int sNAfCHqMZmhqF);
    void rQbXa(string LFSbCNQR);
    void pJJtZaLhleG();
    string mlhOxuuOwR(double xrLtoz, bool pmyENtikReC, double yZFBcQPoh, bool xzKIMsMMPCRGlBwF);
    int tvMjQSPpvHSBAuJI(bool kftmJo, bool spZRcnVnrbL, double ZiSgqsS);
};

string bMtGSHZijRlqOSZV::TMBOaUcXwzVfWY(double oilyELJwC, int neOYUQPJm)
{
    int JhOhVUOJmuW = 270324136;
    bool njGEjvjJiZl = true;
    int RhmYIYruZJXC = -1103569194;

    return string("MzIgOyzBEBLtlOQvRjaoJKtpFhbwXkKZlBctMJApwdWVYJtuFFrcQGJxPElEpivfCWdcJkJbWUjuRHDUeXsgDxaAZDbmGFoUbvOQwkDoUTwbxqKeeYUPYILKAWxnYMyoFKVoTZrurIhKffMvVlsyYNReaBEaeAJXSKkJZxsRXNroKVJdoFYdizySbWWTjlhFuiuPFdj");
}

string bMtGSHZijRlqOSZV::zfnRAJkMmpIY()
{
    string KpFsoLEcxFAlCl = string("fokrbuCaXYslncwZppy");
    int AewPiIZp = -280223396;
    string ePxKqkbez = string("ibKroaIttRHKVWUlhKWdGyzeehwLQWctHObVRhTKohTfBZeQlCaMJaqpuVGUgYnXGpKUtdCjVaBPuScJHFMfMaPWlbhZaPJiugCrgLxZkShCELonOBeZWvwBDgWkuJuPeLvGanNDqvwuqLyNcGmaWbaXyHbnnXGvhSQrmZEajlpXRinC");
    bool hVWOt = true;
    int gyuaEDE = -25530845;
    double QqsdXM = 454925.1605302641;
    int nUIMBjaQt = 1979356044;
    string pAdRZiDnOdRSV = string("RTyqCiioFINZXiaIQSknvdWguRzGuRMUKBPofXCkpuVFalQNBZGgHq");
    string KbpCHGcqNvm = string("SUtcoEDgEAkssGzfZgmgMFvwUXZpzbMPhEnWyOxMwKYvnABTEUtSLvPGiEuBXsxTjFJlEtERTzBqDDFAawWVeTCoGsFOmcYqLJBKxrQHrSErmwRmuaYbJolhfMhksaqvwOTTy");
    bool iSfHTUvo = false;

    for (int JVAjHJkUfwCBTP = 1238434028; JVAjHJkUfwCBTP > 0; JVAjHJkUfwCBTP--) {
        gyuaEDE += gyuaEDE;
        pAdRZiDnOdRSV = KbpCHGcqNvm;
    }

    for (int NpBpObLbAT = 2109413700; NpBpObLbAT > 0; NpBpObLbAT--) {
        continue;
    }

    if (pAdRZiDnOdRSV > string("RTyqCiioFINZXiaIQSknvdWguRzGuRMUKBPofXCkpuVFalQNBZGgHq")) {
        for (int zTDwRKUkZsNl = 1241599541; zTDwRKUkZsNl > 0; zTDwRKUkZsNl--) {
            pAdRZiDnOdRSV += KbpCHGcqNvm;
            hVWOt = iSfHTUvo;
            hVWOt = hVWOt;
            KbpCHGcqNvm = pAdRZiDnOdRSV;
        }
    }

    for (int BzXkpUgqjxUPlRv = 956855959; BzXkpUgqjxUPlRv > 0; BzXkpUgqjxUPlRv--) {
        KpFsoLEcxFAlCl += ePxKqkbez;
        KpFsoLEcxFAlCl += pAdRZiDnOdRSV;
        ePxKqkbez = KbpCHGcqNvm;
        ePxKqkbez += ePxKqkbez;
        KpFsoLEcxFAlCl = KpFsoLEcxFAlCl;
    }

    for (int pGfyToTyzVO = 1172548958; pGfyToTyzVO > 0; pGfyToTyzVO--) {
        pAdRZiDnOdRSV = KpFsoLEcxFAlCl;
    }

    return KbpCHGcqNvm;
}

string bMtGSHZijRlqOSZV::YUjqXLudQ(int SavbIlReDAGKA, double PaVNyoVSi, string VqgAvUU, string IEwwoynnsmn)
{
    string UfONhhZQglUviU = string("QfUSVjjTpOqDMHVrYTDfHgmVcWGidxfxymLMNPjgPZZTYZezprfoNsbcqaFewFSeOZbMxorrTKBxzQAWrjxLfByHCDdCKzAGEcQcsMvlimROJxZoqFdsETLqleTdQVhFYjHJPqsnZmZLsipGmXPRmGQJuIsIIDiDWPeSDyRqCEwEkruxnGimhBorFVqVJMnuEGKjksxulFWjPbmwdLkDpwRNSbDUiCYNbhFDnudxhJvTKDzAwXql");
    double qaXucxmOGS = -929298.9810492311;
    double OBEYAZ = -771841.6493030298;
    string CbwCmyqzHDxW = string("iIuBKlYeXOTYnQUNhoLZkhKUUDgDwRrApuxutZEEMcZCfIhLZPiaWKDyZponrgMwqOrkZJHcFKTJmnmZzuNkucQyAHCQNGJGASapGcfDlXjBkJjQkUEKhzStzIPUjyIJTGgHHLVJvpyrQwmipTsjbMwYrPkPmhyFTUQebbiczeIHzMSzkXMTyGNdKBbanLqlNPHmpkJccMchSBdSCBG");
    double jPAgY = 259575.0193377219;
    bool SLYsvILEIrb = true;
    string QNowkEjT = string("dKamFBYYUHgbCbdkkRqcRTqiq");

    for (int wWeMFpdNr = 131885890; wWeMFpdNr > 0; wWeMFpdNr--) {
        OBEYAZ -= PaVNyoVSi;
    }

    if (jPAgY > 358640.90698751877) {
        for (int kFVZP = 220261053; kFVZP > 0; kFVZP--) {
            SavbIlReDAGKA += SavbIlReDAGKA;
            QNowkEjT = UfONhhZQglUviU;
        }
    }

    for (int ZorUULfr = 179089253; ZorUULfr > 0; ZorUULfr--) {
        IEwwoynnsmn += CbwCmyqzHDxW;
        VqgAvUU += UfONhhZQglUviU;
    }

    for (int CmAibEVa = 859447174; CmAibEVa > 0; CmAibEVa--) {
        SLYsvILEIrb = SLYsvILEIrb;
        IEwwoynnsmn = QNowkEjT;
    }

    for (int gywaW = 1608490815; gywaW > 0; gywaW--) {
        QNowkEjT += CbwCmyqzHDxW;
        UfONhhZQglUviU = CbwCmyqzHDxW;
        PaVNyoVSi -= qaXucxmOGS;
        QNowkEjT = QNowkEjT;
    }

    if (VqgAvUU < string("dKamFBYYUHgbCbdkkRqcRTqiq")) {
        for (int KANMiTKFI = 114661416; KANMiTKFI > 0; KANMiTKFI--) {
            CbwCmyqzHDxW += IEwwoynnsmn;
            UfONhhZQglUviU += QNowkEjT;
            UfONhhZQglUviU = QNowkEjT;
            UfONhhZQglUviU += IEwwoynnsmn;
        }
    }

    return QNowkEjT;
}

int bMtGSHZijRlqOSZV::oYRfuHd(bool xvZbpqvI, string QIXQujfhMIgcl)
{
    int IluuhQlua = 1021598613;
    int JxhIJrtpOKL = 296864437;
    string HlUAaQIzxR = string("bkEfkaEsfWjeaixKHSZDFSXrtPBcNPlaPYGYHdyOLgPWXXCoKIMXsCCNHJFEtWghDfCattXgJJXMDOwkRUgLksuthOvLDVVGfLlgHTvoyLEzEciFNKVuLVaOASIFJdpcQgrpaAoQStUdlRbdfHSDdeuuGWJpxiroMOWunWRemhqsjmoHUsNlQFxaAGBdFy");

    if (xvZbpqvI != false) {
        for (int wvVXJOk = 1913189484; wvVXJOk > 0; wvVXJOk--) {
            IluuhQlua *= IluuhQlua;
            IluuhQlua += IluuhQlua;
            IluuhQlua += IluuhQlua;
        }
    }

    return JxhIJrtpOKL;
}

int bMtGSHZijRlqOSZV::ycBDneNnPrI(string aElxbUIQtMW, int fDNyjfy, string NPzOaujCzxecCdr, double lJHMLf, string yEQtWNmE)
{
    bool WcyKebMPgWgzJ = false;

    if (NPzOaujCzxecCdr >= string("ujyTywZcJOoDaBaWZFoAfkVMIpQnzXdIChxIEOJYzAdKHPYJLmhWdxzaAqELlLWoIGxXJSwmfdqAwJjJVwEKDbPYadfYGwRsC")) {
        for (int oMKjcnowh = 1747715307; oMKjcnowh > 0; oMKjcnowh--) {
            continue;
        }
    }

    for (int AIYKeo = 1699170526; AIYKeo > 0; AIYKeo--) {
        yEQtWNmE = yEQtWNmE;
    }

    for (int yaHleteb = 1767964607; yaHleteb > 0; yaHleteb--) {
        NPzOaujCzxecCdr = yEQtWNmE;
    }

    if (NPzOaujCzxecCdr != string("payVEucLzwcUTiyJtXJciRZrLvLYjWXKcrpubRmiCcpXMzwlPsFLIbSJlqmrMoVFzexxwrXwdDDAhUUuFGsCeGRdheuxwgdqxafPjgWKDrsbQRvcsFfKZNKnVUpYqdjDfuaPAIG")) {
        for (int iCMcscVaPx = 285950966; iCMcscVaPx > 0; iCMcscVaPx--) {
            yEQtWNmE = yEQtWNmE;
            yEQtWNmE += yEQtWNmE;
            yEQtWNmE += aElxbUIQtMW;
        }
    }

    for (int xZswMUBubY = 1344605806; xZswMUBubY > 0; xZswMUBubY--) {
        yEQtWNmE += yEQtWNmE;
    }

    if (fDNyjfy != 371806829) {
        for (int uJhuXsXrztUHzq = 1181283530; uJhuXsXrztUHzq > 0; uJhuXsXrztUHzq--) {
            NPzOaujCzxecCdr = NPzOaujCzxecCdr;
            lJHMLf /= lJHMLf;
            NPzOaujCzxecCdr = yEQtWNmE;
        }
    }

    if (yEQtWNmE > string("EbwAqiRBFulVNiaFzzHVWCfBGYxYdNImWXGrhGoQBEqIZhienASiyvmIRukmUDhvgux")) {
        for (int BxdUZQukJrfOABx = 739826325; BxdUZQukJrfOABx > 0; BxdUZQukJrfOABx--) {
            lJHMLf += lJHMLf;
            NPzOaujCzxecCdr = yEQtWNmE;
        }
    }

    return fDNyjfy;
}

int bMtGSHZijRlqOSZV::GAVgcQF(bool ljNDSe, int sNAfCHqMZmhqF)
{
    string UMWItS = string("NsSdCweIjsXeAqhxtncOGPRmoVeDCcHDLRXMNcNDqrqHnccrgnKwgwtZRFhcMSwTzosOlcOdFDFVOxIJBLzPtLxOjKbCFkYVapjsoQCPkvpwrrBqMdMAfKjsuoKywDZkWhRWTQdXSVAFYJuzuHMVRpNdrIMAndkBpqcXKLPaoHDeXlcuogCYyMiwWrbphYdQHOVsTUPHSkjDnvuHIqQjk");
    double lVOLRCcgJxeJqe = -643421.4266735978;
    string BlznKNHIOHDQA = string("wKelYLthZFNhVDQOHePpktBEjiMwaIzhwkuXjyybYNAWFdeobmXNeSyegemmMYmvLeAvgfYPYhyIAGFmEBIOeyxMoBYehFoPFLZCpWDlAWOfSyuyybLeJmzEkssaUS");
    int cKPSKur = -1859231732;

    for (int SFBqcv = 571678218; SFBqcv > 0; SFBqcv--) {
        continue;
    }

    if (UMWItS > string("wKelYLthZFNhVDQOHePpktBEjiMwaIzhwkuXjyybYNAWFdeobmXNeSyegemmMYmvLeAvgfYPYhyIAGFmEBIOeyxMoBYehFoPFLZCpWDlAWOfSyuyybLeJmzEkssaUS")) {
        for (int wxsgcnfADFbDUqZ = 415739037; wxsgcnfADFbDUqZ > 0; wxsgcnfADFbDUqZ--) {
            sNAfCHqMZmhqF -= cKPSKur;
            BlznKNHIOHDQA = BlznKNHIOHDQA;
            sNAfCHqMZmhqF += sNAfCHqMZmhqF;
        }
    }

    for (int dskxdVVijDi = 855352695; dskxdVVijDi > 0; dskxdVVijDi--) {
        cKPSKur += cKPSKur;
        lVOLRCcgJxeJqe /= lVOLRCcgJxeJqe;
        sNAfCHqMZmhqF *= sNAfCHqMZmhqF;
    }

    for (int vVmTlpWCbRcfYo = 870110370; vVmTlpWCbRcfYo > 0; vVmTlpWCbRcfYo--) {
        BlznKNHIOHDQA = UMWItS;
        UMWItS += UMWItS;
        cKPSKur = cKPSKur;
    }

    if (BlznKNHIOHDQA > string("NsSdCweIjsXeAqhxtncOGPRmoVeDCcHDLRXMNcNDqrqHnccrgnKwgwtZRFhcMSwTzosOlcOdFDFVOxIJBLzPtLxOjKbCFkYVapjsoQCPkvpwrrBqMdMAfKjsuoKywDZkWhRWTQdXSVAFYJuzuHMVRpNdrIMAndkBpqcXKLPaoHDeXlcuogCYyMiwWrbphYdQHOVsTUPHSkjDnvuHIqQjk")) {
        for (int FoZOvDkiKjZIZEKK = 2117985372; FoZOvDkiKjZIZEKK > 0; FoZOvDkiKjZIZEKK--) {
            BlznKNHIOHDQA += UMWItS;
            ljNDSe = ! ljNDSe;
        }
    }

    for (int IlRSWW = 709982481; IlRSWW > 0; IlRSWW--) {
        sNAfCHqMZmhqF /= sNAfCHqMZmhqF;
    }

    return cKPSKur;
}

void bMtGSHZijRlqOSZV::rQbXa(string LFSbCNQR)
{
    int rspqhrOhdDUV = -902814789;
    bool YLuMVbSUzxETq = false;
    int HTbOSfUQm = -383182769;
    double NBguvG = -1000232.1859002799;
    string sEYZyHZiSspEpd = string("cleyQZGBhTXhTogRTnuquYCiArxCmdTwANXBlVRpFGzgdTvjvmDxtmrVWXoRtkrGmtxQypyGVQPbpP");
    string sLMadCLFazrsE = string("VEScUvyTVhPnXYYtOIjoeuHLEDmgUHAYudWyKPvrwXFUHhhlRAbsfZjalAyFouKIFhjDbTQhLJ");
    double fdIOBdmWyV = 447184.9052334467;
    int larCroSmmtlyOXAu = -138084001;
    double xTvenj = 867208.8131603911;
    bool HGKWCoATOtCnGZk = false;

    for (int ZosQPCF = 574418799; ZosQPCF > 0; ZosQPCF--) {
        rspqhrOhdDUV = rspqhrOhdDUV;
    }

    for (int UXSuPPbAP = 545629122; UXSuPPbAP > 0; UXSuPPbAP--) {
        continue;
    }

    if (HGKWCoATOtCnGZk == false) {
        for (int evXMdjGPCJOraAl = 1653045792; evXMdjGPCJOraAl > 0; evXMdjGPCJOraAl--) {
            YLuMVbSUzxETq = YLuMVbSUzxETq;
            HGKWCoATOtCnGZk = HGKWCoATOtCnGZk;
            NBguvG -= xTvenj;
        }
    }

    for (int cdIrWDqVkzgMbf = 1013508390; cdIrWDqVkzgMbf > 0; cdIrWDqVkzgMbf--) {
        xTvenj += xTvenj;
    }
}

void bMtGSHZijRlqOSZV::pJJtZaLhleG()
{
    double qvuyP = -160878.5187315158;
    int BIdUYjpeQuQrDzR = 897636374;
    int yZODnbkMX = -1390302171;
    int gIbCOoOVSOXrvgxz = -442441396;
    double KpyGlCEnse = 138222.54040212938;
    double qEnXeERCSJnGA = 102223.627115154;

    for (int vAtJOFBAbEOwkG = 290465560; vAtJOFBAbEOwkG > 0; vAtJOFBAbEOwkG--) {
        qvuyP *= qEnXeERCSJnGA;
    }

    if (BIdUYjpeQuQrDzR > -1390302171) {
        for (int XiczkLrFVGsPjpnA = 1807577073; XiczkLrFVGsPjpnA > 0; XiczkLrFVGsPjpnA--) {
            BIdUYjpeQuQrDzR *= yZODnbkMX;
            qEnXeERCSJnGA = KpyGlCEnse;
            KpyGlCEnse *= qEnXeERCSJnGA;
        }
    }

    for (int oTNko = 1516568952; oTNko > 0; oTNko--) {
        qvuyP *= qvuyP;
        qEnXeERCSJnGA += KpyGlCEnse;
    }

    for (int ehxkcMsEigrwUA = 730523367; ehxkcMsEigrwUA > 0; ehxkcMsEigrwUA--) {
        gIbCOoOVSOXrvgxz = BIdUYjpeQuQrDzR;
        qvuyP *= qEnXeERCSJnGA;
        qvuyP = qEnXeERCSJnGA;
    }
}

string bMtGSHZijRlqOSZV::mlhOxuuOwR(double xrLtoz, bool pmyENtikReC, double yZFBcQPoh, bool xzKIMsMMPCRGlBwF)
{
    bool mIwwp = false;
    int LVZqLNehUOKEFm = -934447297;
    int yRleO = -849022045;
    double ZSwgKD = -687047.7621121304;
    double FDDxs = -567445.0875623763;
    double koIQhtvRDHqZU = 87561.63494338073;
    bool eruMTcMVga = true;
    double txpihLkmXkdcU = 572087.5791111314;
    double AsfRP = 365399.79091198917;
    bool wEFsSMZyXx = false;

    if (AsfRP == -95896.40057470079) {
        for (int XyrHuef = 962111610; XyrHuef > 0; XyrHuef--) {
            wEFsSMZyXx = ! mIwwp;
            pmyENtikReC = xzKIMsMMPCRGlBwF;
        }
    }

    for (int thMKfKrpL = 1237412803; thMKfKrpL > 0; thMKfKrpL--) {
        FDDxs /= yZFBcQPoh;
        xzKIMsMMPCRGlBwF = eruMTcMVga;
    }

    for (int IMKWWvHfziFaJf = 1276846800; IMKWWvHfziFaJf > 0; IMKWWvHfziFaJf--) {
        continue;
    }

    for (int oZewzgzsPHNf = 1596611229; oZewzgzsPHNf > 0; oZewzgzsPHNf--) {
        mIwwp = ! mIwwp;
        xzKIMsMMPCRGlBwF = xzKIMsMMPCRGlBwF;
        mIwwp = wEFsSMZyXx;
    }

    return string("xMidXaZovcOTSPlputoNFDVLTCmeHpIlyAZcyUhDRNqAmYioQmIGPsbgWFhQvCOfHnNMaaYvDkbcOQHNfedCF");
}

int bMtGSHZijRlqOSZV::tvMjQSPpvHSBAuJI(bool kftmJo, bool spZRcnVnrbL, double ZiSgqsS)
{
    double oCNYQyfesliJhdk = 1045438.6413950213;
    string ggMubQH = string("pBRgLbKsKbGiixtNmLRAMBLEktbVVDAleWENJomgFCLYSqlZuTIpvRZsYDzWkGHlBoVeyAeGDnsviuVuTpshQvsZfCBAdIbxdxWHPtUIWFtIqkceRNKaqusYJZbwFOiQkrBhwiHPRYTHezWIrFdnYauTLufjHfMGyIsUCsNVXQMoMUDtOGDOprUJRuZNzsGIAwnAtEizoATpAKgrjCwphIXvdZvZaRBahZckwfWusR");
    string UYuHAI = string("ktBbOdPRuJKESXuWmKuKAhSTKVMHVpdutprXSmWoAceFtBvmeepzEOEkKyPUNoJrRPPxlvPLWoAAoogDiwWauzYYOJgzCBAoWLJRMvUHQMBpOepaqHRtGffNUPbGolXRBlgBcSRTTOQsLWJNchHYBkMbceTlRKGnacyXNpeQNnivtingHEMtyfyiUrYxgmsxCzGucVziAzAZALVxUtjSxGvLUmeYkrBfzPaBLLgmgjTgPqzBFHxnVZVHkUbeo");
    int ARbCrXkRkhnvE = -677233188;
    bool TupqtfrDGL = true;
    string icVyXJKrXbtTlP = string("bygeOrZRKvraYhCEpArudGqqrGRfZWUNISIpHBbWfuNAOeuIUg");
    int AccZRClrbb = -1098931762;
    string UsCUKgB = string("KeapZFWukWvHIYqRKjSUQBhhepuiqwVSPRyXXdkCSVMOriLoUvtLAbcfMjzwUBifCMwhkcDHXrMhFQsnXNKoNsXDxVVxVLfdWfldnPkcTumcByblWpQYduJrMIQenBWYomVMQuyuiFDuIZquzRsbGsXcLhnanqurCYYqgauFtRuBxaUYwAcbwOmdZjMWgUEiEVNTQgIVGIOZMePuxgLtBbyIZPHKDoyVVpntBdWGQqIgEfGbIUBdkQrSoP");

    for (int NcJykwHKwKtah = 247578044; NcJykwHKwKtah > 0; NcJykwHKwKtah--) {
        TupqtfrDGL = ! TupqtfrDGL;
        ARbCrXkRkhnvE *= AccZRClrbb;
    }

    for (int GRThUbm = 1579455112; GRThUbm > 0; GRThUbm--) {
        continue;
    }

    if (spZRcnVnrbL != true) {
        for (int LBaTK = 1673062442; LBaTK > 0; LBaTK--) {
            ggMubQH = UsCUKgB;
            AccZRClrbb += ARbCrXkRkhnvE;
        }
    }

    for (int ishqC = 1073483598; ishqC > 0; ishqC--) {
        TupqtfrDGL = TupqtfrDGL;
        UYuHAI += UYuHAI;
    }

    if (TupqtfrDGL != true) {
        for (int OZCLpkrynWsjbF = 1457440533; OZCLpkrynWsjbF > 0; OZCLpkrynWsjbF--) {
            icVyXJKrXbtTlP = icVyXJKrXbtTlP;
        }
    }

    return AccZRClrbb;
}

bMtGSHZijRlqOSZV::bMtGSHZijRlqOSZV()
{
    this->TMBOaUcXwzVfWY(645551.3920354389, -2084887089);
    this->zfnRAJkMmpIY();
    this->YUjqXLudQ(1417695217, 358640.90698751877, string("PGWfPayxRUrVzkdTKFSMaiMjgNkjXcwAwGliKovGFzzCT"), string("LnDuqqCvtmXsrboxIaRVL"));
    this->oYRfuHd(false, string("rsWzrJNcotlAEJPmVkhLAGOioecZfecBNwThpXfcApJZKYVAXsKnaHUDnduCObMBjMGTotwddEAsyBQYMrVdWbMTcmhvWHTRUQzcOFFeyDAFPenSqTInXxMPTgBfHVOnSKTPzuCcLnbKGUQoFEdLjVMZJSkrsLSHhYHsBmLETrXJnJYULzRamzGrQvVqiaQvQBIfdCsENBWghJLMTtYtufGEKPFzHXoTgo"));
    this->ycBDneNnPrI(string("payVEucLzwcUTiyJtXJciRZrLvLYjWXKcrpubRmiCcpXMzwlPsFLIbSJlqmrMoVFzexxwrXwdDDAhUUuFGsCeGRdheuxwgdqxafPjgWKDrsbQRvcsFfKZNKnVUpYqdjDfuaPAIG"), 371806829, string("EbwAqiRBFulVNiaFzzHVWCfBGYxYdNImWXGrhGoQBEqIZhienASiyvmIRukmUDhvgux"), 83476.1300560159, string("ujyTywZcJOoDaBaWZFoAfkVMIpQnzXdIChxIEOJYzAdKHPYJLmhWdxzaAqELlLWoIGxXJSwmfdqAwJjJVwEKDbPYadfYGwRsC"));
    this->GAVgcQF(false, -1388319625);
    this->rQbXa(string("YulJsyBCeiUoHqcotBFRthiVDoZFEZLcJEhijyixmglACpYAbMNdFKmDIlfztpVf"));
    this->pJJtZaLhleG();
    this->mlhOxuuOwR(-95896.40057470079, true, 879481.8519868659, true);
    this->tvMjQSPpvHSBAuJI(true, true, -961179.1044908371);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ztDLesmApjlftPC
{
public:
    int iDZNhCxrQRQKRTS;
    bool LtYJzwWwVRzrlRd;
    bool BQSDxfBTPVs;
    double ftSnHqUNuk;
    int RyrfJ;

    ztDLesmApjlftPC();
    void geTnlZimnqoC(bool EGxtRuWqfets);
    string cwtAeGCSmxv(bool rdCEbqhk, bool KRUmImHybhN, int ThIWvzzYnBxjuVWv, string IlxhiynOGMDZhhh);
    bool QoqNmaLLWuMERJi(int iYncNgIPdvHXgq, double IEyPC, string JqCKPe, bool LwgcWXeCvtJ);
    double CaggASGWElo(string fOvvXNtwNUFSKkhN, double ChqDRBIH);
protected:
    bool CBkvTvjqNbjhk;
    string pbGCs;

    int slFTw(double oAkRXwkb, bool SGSeOodYRivXGz);
    bool qDhQdweytdoMxSw(double eLvRa);
    void nnAzeSoUoimdLsTV(string ujAeQHNt, bool sCbJbQkwvNCxDDlK, int ynmfvohzBVdift);
    bool WzJWSTdmMpdgHNWU();
    int JwTZUimjPlBJOXU();
    bool wugwDm();
    string PgsxRgoTyod(int VOlRxwwW, bool OuYxmSIDwEaPSvP);
    double WMoyzXtIlAuO(int EjvauUZyMCSqe);
private:
    int WxuXDbUCMf;

    bool dqjWCmrHpNws(double aLujcKdMkbewXsC, string ZcTWjUrI, int ikLQpsxul, double mBYbEueGMOA, string WsSsFcls);
    bool kNMHbBZbWb(string OOhVKITRVe, int PYEMGNBRkMblOT);
};

void ztDLesmApjlftPC::geTnlZimnqoC(bool EGxtRuWqfets)
{
    bool ovQUkXC = false;
    string Wsllk = string("poqPlqsYzQWMgrtMGwtjFsnCLwmEoYrPUMAMLSHSEWNClKwHPpYvECOfunBEsZATIGZKNZNjDMALIyjydwqPmzVHoAAXYBDlC");
    string uQvcsmWEsM = string("qKDfpdUYaHJuQcNzjuTRGWushcRIGzEYNAMhRyOKZLqXJxmKVEsXQICrqAgybZBHDQYVhRejnIBCzomvhgrIHSREuYOjxgZMmKUZroGGdRhnxjOHVmUSqzCeddCYFbGTkFTqsusmvefEBamYWuSifFYYONuPGwFSYUCtTaewEyxMbrQtJrOIPLwoFRryDuHYNjyOVATIBYnVTwVSkRixKMNzAOUnVALH");
    double NqzpR = -420471.47894984874;
    double zVKVXFijwKzPSb = -599493.3832231548;
    string EFJUTQBkqvDp = string("fxYWHfxBSEinVLrEkjAHkiFGcbmgLPRcSJcOjbYfWZXuFRSBGhouBQoxxiDpsIrJLZvMqJeNShUHbBzouIsPRxkMXvcpKrFMSyHLqFdGMBbXvpzTLvGvocrGLXqCklYRMDqiBDGBspUIsKkyzQZxDDweiCniRMUdAMsnQaPHhHbCduYiibWonrpCcheixdAwXWnALDIXBfmEjkajnQycSLAdFaSJgLjP");
    string kqWiQkZLylgH = string("nZExekpHSYBwphvq");
    bool XpbTPncyrRKFh = true;
    bool lsHpULFuxSUxsEHD = true;

    for (int pOCstjlQ = 259480343; pOCstjlQ > 0; pOCstjlQ--) {
        lsHpULFuxSUxsEHD = XpbTPncyrRKFh;
    }

    for (int BRigR = 1597750574; BRigR > 0; BRigR--) {
        continue;
    }
}

string ztDLesmApjlftPC::cwtAeGCSmxv(bool rdCEbqhk, bool KRUmImHybhN, int ThIWvzzYnBxjuVWv, string IlxhiynOGMDZhhh)
{
    int aGloBZgXVVIelshW = 2145234154;

    for (int isAjeL = 1137347489; isAjeL > 0; isAjeL--) {
        rdCEbqhk = rdCEbqhk;
    }

    for (int mNtNN = 2055124659; mNtNN > 0; mNtNN--) {
        IlxhiynOGMDZhhh += IlxhiynOGMDZhhh;
        ThIWvzzYnBxjuVWv *= ThIWvzzYnBxjuVWv;
        rdCEbqhk = ! KRUmImHybhN;
        aGloBZgXVVIelshW -= aGloBZgXVVIelshW;
    }

    return IlxhiynOGMDZhhh;
}

bool ztDLesmApjlftPC::QoqNmaLLWuMERJi(int iYncNgIPdvHXgq, double IEyPC, string JqCKPe, bool LwgcWXeCvtJ)
{
    double RQuEBQi = -74169.20459236308;
    string dxygtdHAvNs = string("lESBkAjcJCFsLXUXlmwTWvIhtVjQAATDjzkFKljtHyQQDmqGvVmFijnzNxbXvcgZVbQMXXEEGZWMOU");
    string EiXLYDOGasxhfE = string("GjMUveAPYwNULUWCixYKFlEkVqcZQsUyvYgDrVsEzpTWvwbbogAeoYNoYvedWRYmmRwnbdlkZjvfkMFBMpuSuQtOOBqvKdsgtymMSosyksBJTcifZfpqjXypQDdtXDVaLeTSFamCORaYfmGJLEzWDXFqQoboestJnNdUaMvLiumESNymjKDp");

    for (int airrg = 1856007889; airrg > 0; airrg--) {
        RQuEBQi += RQuEBQi;
    }

    for (int oWMNUBXsI = 148126254; oWMNUBXsI > 0; oWMNUBXsI--) {
        JqCKPe = EiXLYDOGasxhfE;
        dxygtdHAvNs += dxygtdHAvNs;
    }

    for (int LbJDLCU = 485682580; LbJDLCU > 0; LbJDLCU--) {
        continue;
    }

    for (int UGzGKJnOVvLOQmFb = 1863259835; UGzGKJnOVvLOQmFb > 0; UGzGKJnOVvLOQmFb--) {
        IEyPC /= RQuEBQi;
        RQuEBQi *= RQuEBQi;
        JqCKPe += JqCKPe;
        IEyPC += RQuEBQi;
    }

    return LwgcWXeCvtJ;
}

double ztDLesmApjlftPC::CaggASGWElo(string fOvvXNtwNUFSKkhN, double ChqDRBIH)
{
    double uBcsevZbGn = -276441.887196923;
    double qpsxTd = -821319.677130097;

    for (int nBDhhRCHfDt = 1138174644; nBDhhRCHfDt > 0; nBDhhRCHfDt--) {
        qpsxTd += ChqDRBIH;
        uBcsevZbGn += ChqDRBIH;
        qpsxTd *= qpsxTd;
        uBcsevZbGn += ChqDRBIH;
        ChqDRBIH += ChqDRBIH;
    }

    return qpsxTd;
}

int ztDLesmApjlftPC::slFTw(double oAkRXwkb, bool SGSeOodYRivXGz)
{
    double odyFzIKVnhpW = 283856.82082911703;
    double bMYQpmsJuA = 967128.8816241963;
    int MYJWkzKOqzjLAMog = 1858525129;
    double KXgkHbbHsI = -839635.4637355497;
    bool eCnbsHH = true;

    for (int eqBARZBuXa = 1396209741; eqBARZBuXa > 0; eqBARZBuXa--) {
        KXgkHbbHsI *= odyFzIKVnhpW;
        odyFzIKVnhpW += bMYQpmsJuA;
        eCnbsHH = ! eCnbsHH;
    }

    return MYJWkzKOqzjLAMog;
}

bool ztDLesmApjlftPC::qDhQdweytdoMxSw(double eLvRa)
{
    bool OeBNWa = false;
    bool xRzDtaXDhwfvlX = true;
    int USDUiqaEbRDOAEEm = -320049005;
    bool dfrmoNRIPNsWLsYs = true;
    double wGouNSfR = 778966.9747337367;
    double LXjUxggHiP = 955086.360654654;
    bool GkOHUrMacdZ = true;
    bool eCzgbPwZOMGE = true;

    return eCzgbPwZOMGE;
}

void ztDLesmApjlftPC::nnAzeSoUoimdLsTV(string ujAeQHNt, bool sCbJbQkwvNCxDDlK, int ynmfvohzBVdift)
{
    int sPrXRvMOLgEz = 1852438134;
    bool SCmumv = true;
    int xLbxdekSNTG = -1328316489;
    double EmGpPmxpoHCvguNX = 655875.018557494;
    int rxItHxqK = -339751583;
    string qhxogYQuZjfJDuE = string("FuebffArEvaggErYgzsrbFGaEyDOmEdGwLgBJTXqqEqza");
    string xVVycBEsZEOzrry = string("RrJlwbkZQwklCqWwwHScqJVCaaMGePijUdcfYCjNVkfnDQDvjRuREQuQdqEPzybzOFImEYLx");
    double NnGfRAXy = -1016475.1847276629;

    for (int xbFAMLLaZvj = 1628100539; xbFAMLLaZvj > 0; xbFAMLLaZvj--) {
        xLbxdekSNTG /= sPrXRvMOLgEz;
    }

    for (int IbKvYbEeoQtHxFSr = 129647511; IbKvYbEeoQtHxFSr > 0; IbKvYbEeoQtHxFSr--) {
        NnGfRAXy *= NnGfRAXy;
    }

    for (int ElyXqwLqfMozF = 1507220006; ElyXqwLqfMozF > 0; ElyXqwLqfMozF--) {
        continue;
    }

    for (int PAPrJE = 1012356696; PAPrJE > 0; PAPrJE--) {
        sPrXRvMOLgEz /= sPrXRvMOLgEz;
    }

    for (int yXYdddqFq = 1916871871; yXYdddqFq > 0; yXYdddqFq--) {
        continue;
    }

    for (int DWlJzBiwDw = 279257346; DWlJzBiwDw > 0; DWlJzBiwDw--) {
        sCbJbQkwvNCxDDlK = sCbJbQkwvNCxDDlK;
    }

    for (int TEdSqR = 1405398223; TEdSqR > 0; TEdSqR--) {
        ynmfvohzBVdift = xLbxdekSNTG;
    }

    if (xVVycBEsZEOzrry != string("RrJlwbkZQwklCqWwwHScqJVCaaMGePijUdcfYCjNVkfnDQDvjRuREQuQdqEPzybzOFImEYLx")) {
        for (int bRwNOxA = 1942400133; bRwNOxA > 0; bRwNOxA--) {
            qhxogYQuZjfJDuE += ujAeQHNt;
            xLbxdekSNTG *= rxItHxqK;
        }
    }
}

bool ztDLesmApjlftPC::WzJWSTdmMpdgHNWU()
{
    bool cbMClKLTIbI = true;
    string ThOKb = string("MKDNsRtHiVzbHdDmsukwVNexxnSdjrIUDEzkAxrnCmGLkyaygbzLMpELYMcUFNCZoaGSynaRpIlZAnEeUaXMrtXLEbgHLHfpsLyVDHnJnqQHjGyMpnAStJAOBLaCVFuAprtJmzjqozDUULjmELRazaRzCYudxpwyg");
    string ZRVdisZzvxtDJcgn = string("KPbfktrovmtyKNMIrgaMpKesUQvoJjnRcJIedmtzYJRswWqBqVlgzWQHXHBPjLfBIrxUmFcTDhKvTiVuvvZCZbKhIdxDhOOwMGtOnOzkKIngMRdjixfBkGmHvKuAvLcvgkLbFoFtEUKYUWxEFeVgcevofFGbxfYVQufMVS");
    bool KgrwNulsDkjyUVzj = false;
    bool CtMqvkMn = true;
    int kVxsNdKmHF = -1383423147;
    int pYdXnPPLh = 1275898945;
    int dwGWRdAuWGQcVJ = 41840780;
    string FCjpoFlzuitZ = string("bOAbooreIhNbrBSGXZOMSAEFchriydgnUomrRIZrLMmjmITacCRTsVMudNpSEHWcTHpWQimCOpOKeGwTNSTuMWWWRmGzNOslQYKLCXbwHyLwgSFMUXLCKGietBlrVtGocOTcsGVHdUfWjCIMatywVDCWqhAMmHHzTCKhXudXHKXMxrtUVMpoZJXIEQEHbSbNptVgOFuKEsEuXQkkxwaVzhIUtdneiPGLOYggaJppNAMFdFMBLWMmNTKrgSKb");

    if (pYdXnPPLh >= 1275898945) {
        for (int EfRmUOyEeV = 1330735418; EfRmUOyEeV > 0; EfRmUOyEeV--) {
            KgrwNulsDkjyUVzj = CtMqvkMn;
        }
    }

    for (int LIcsn = 112586651; LIcsn > 0; LIcsn--) {
        ThOKb = ThOKb;
        cbMClKLTIbI = ! CtMqvkMn;
        ThOKb = FCjpoFlzuitZ;
        ZRVdisZzvxtDJcgn = ThOKb;
    }

    for (int CqFoKcMl = 1458684788; CqFoKcMl > 0; CqFoKcMl--) {
        pYdXnPPLh += pYdXnPPLh;
        ZRVdisZzvxtDJcgn = ThOKb;
    }

    if (cbMClKLTIbI == true) {
        for (int PhoABGz = 1865524955; PhoABGz > 0; PhoABGz--) {
            ZRVdisZzvxtDJcgn += ThOKb;
            pYdXnPPLh /= dwGWRdAuWGQcVJ;
            FCjpoFlzuitZ = FCjpoFlzuitZ;
            KgrwNulsDkjyUVzj = CtMqvkMn;
        }
    }

    for (int lLVcwLycIhXivrHH = 1366357756; lLVcwLycIhXivrHH > 0; lLVcwLycIhXivrHH--) {
        continue;
    }

    if (ThOKb < string("KPbfktrovmtyKNMIrgaMpKesUQvoJjnRcJIedmtzYJRswWqBqVlgzWQHXHBPjLfBIrxUmFcTDhKvTiVuvvZCZbKhIdxDhOOwMGtOnOzkKIngMRdjixfBkGmHvKuAvLcvgkLbFoFtEUKYUWxEFeVgcevofFGbxfYVQufMVS")) {
        for (int LelLciWInyNLpjoj = 2079077352; LelLciWInyNLpjoj > 0; LelLciWInyNLpjoj--) {
            continue;
        }
    }

    for (int PsFinp = 1947035057; PsFinp > 0; PsFinp--) {
        pYdXnPPLh = kVxsNdKmHF;
        cbMClKLTIbI = CtMqvkMn;
        ThOKb += ZRVdisZzvxtDJcgn;
        pYdXnPPLh /= dwGWRdAuWGQcVJ;
    }

    return CtMqvkMn;
}

int ztDLesmApjlftPC::JwTZUimjPlBJOXU()
{
    int aGPhbPWiSCpz = 1887628656;
    bool ITEgjKYJHebDkOz = true;
    double qaOurxAqENh = -194141.8066668076;
    string FKUZcDbouboqC = string("eJbzfRorsmvNUSJAZcbuNdDgErYKBiwVeFpUeJubusfYKcuPEOFYEKqmRtIedrlCXQrNYxYaDuYTimMCGPNiGGcKYGCaMGPWLoskXYqWNCgMZRVEIZkyWknqc");
    int NiCYiOI = -864884232;
    double QKMicYfURAdB = -312622.32628594927;
    int vDCMvY = 1891865474;
    int oyQkdSziEqMiwoIF = 1208043208;
    int HWbmBpQQXvHTuMV = -1075993239;

    for (int ZIfNNnNTlul = 977135569; ZIfNNnNTlul > 0; ZIfNNnNTlul--) {
        NiCYiOI += HWbmBpQQXvHTuMV;
    }

    for (int iwHYuBK = 1642353754; iwHYuBK > 0; iwHYuBK--) {
        oyQkdSziEqMiwoIF /= oyQkdSziEqMiwoIF;
        aGPhbPWiSCpz *= aGPhbPWiSCpz;
        QKMicYfURAdB += qaOurxAqENh;
        aGPhbPWiSCpz *= NiCYiOI;
        aGPhbPWiSCpz += aGPhbPWiSCpz;
    }

    if (oyQkdSziEqMiwoIF > -864884232) {
        for (int kuuZGBDeBv = 1939150258; kuuZGBDeBv > 0; kuuZGBDeBv--) {
            HWbmBpQQXvHTuMV /= aGPhbPWiSCpz;
            oyQkdSziEqMiwoIF *= aGPhbPWiSCpz;
            qaOurxAqENh += QKMicYfURAdB;
        }
    }

    if (HWbmBpQQXvHTuMV <= -864884232) {
        for (int XGByzLiGOBKMv = 720099581; XGByzLiGOBKMv > 0; XGByzLiGOBKMv--) {
            NiCYiOI -= vDCMvY;
            vDCMvY -= aGPhbPWiSCpz;
            aGPhbPWiSCpz /= HWbmBpQQXvHTuMV;
        }
    }

    if (HWbmBpQQXvHTuMV <= 1887628656) {
        for (int HHPVQoflsP = 1557691897; HHPVQoflsP > 0; HHPVQoflsP--) {
            aGPhbPWiSCpz += oyQkdSziEqMiwoIF;
            NiCYiOI *= NiCYiOI;
            HWbmBpQQXvHTuMV /= vDCMvY;
            FKUZcDbouboqC += FKUZcDbouboqC;
        }
    }

    return HWbmBpQQXvHTuMV;
}

bool ztDLesmApjlftPC::wugwDm()
{
    bool yHefruvYutwGwd = false;
    int WLUUysbgg = 1151320184;
    double jDQXTYBCKvXRRJ = -528659.0172877751;
    bool aLcIfDyPK = true;
    bool pWrQYzPFMBVlB = true;

    for (int tHddSMnMxgts = 1880719720; tHddSMnMxgts > 0; tHddSMnMxgts--) {
        aLcIfDyPK = pWrQYzPFMBVlB;
        aLcIfDyPK = aLcIfDyPK;
        aLcIfDyPK = pWrQYzPFMBVlB;
    }

    if (jDQXTYBCKvXRRJ < -528659.0172877751) {
        for (int CJedoqwpnJZde = 1723539709; CJedoqwpnJZde > 0; CJedoqwpnJZde--) {
            aLcIfDyPK = ! aLcIfDyPK;
            WLUUysbgg *= WLUUysbgg;
            aLcIfDyPK = ! pWrQYzPFMBVlB;
        }
    }

    if (aLcIfDyPK != false) {
        for (int tgCfwfrxtvwknw = 1541532720; tgCfwfrxtvwknw > 0; tgCfwfrxtvwknw--) {
            aLcIfDyPK = ! aLcIfDyPK;
            aLcIfDyPK = ! yHefruvYutwGwd;
            yHefruvYutwGwd = aLcIfDyPK;
            jDQXTYBCKvXRRJ /= jDQXTYBCKvXRRJ;
            pWrQYzPFMBVlB = ! aLcIfDyPK;
            aLcIfDyPK = ! aLcIfDyPK;
            jDQXTYBCKvXRRJ = jDQXTYBCKvXRRJ;
            yHefruvYutwGwd = ! pWrQYzPFMBVlB;
        }
    }

    if (jDQXTYBCKvXRRJ == -528659.0172877751) {
        for (int xmEaFgCJAqpIuHlI = 1355068902; xmEaFgCJAqpIuHlI > 0; xmEaFgCJAqpIuHlI--) {
            pWrQYzPFMBVlB = ! yHefruvYutwGwd;
            jDQXTYBCKvXRRJ -= jDQXTYBCKvXRRJ;
            WLUUysbgg /= WLUUysbgg;
            jDQXTYBCKvXRRJ -= jDQXTYBCKvXRRJ;
            pWrQYzPFMBVlB = pWrQYzPFMBVlB;
        }
    }

    if (pWrQYzPFMBVlB != true) {
        for (int oQEONLcRR = 1136759077; oQEONLcRR > 0; oQEONLcRR--) {
            yHefruvYutwGwd = ! yHefruvYutwGwd;
            yHefruvYutwGwd = ! aLcIfDyPK;
            yHefruvYutwGwd = yHefruvYutwGwd;
            pWrQYzPFMBVlB = yHefruvYutwGwd;
        }
    }

    if (WLUUysbgg < 1151320184) {
        for (int aCpQHWddfJSBeTC = 1315838997; aCpQHWddfJSBeTC > 0; aCpQHWddfJSBeTC--) {
            yHefruvYutwGwd = ! aLcIfDyPK;
            pWrQYzPFMBVlB = ! aLcIfDyPK;
            pWrQYzPFMBVlB = pWrQYzPFMBVlB;
            aLcIfDyPK = ! aLcIfDyPK;
            yHefruvYutwGwd = yHefruvYutwGwd;
            aLcIfDyPK = ! aLcIfDyPK;
            WLUUysbgg = WLUUysbgg;
        }
    }

    if (pWrQYzPFMBVlB != false) {
        for (int PZixufPoaKCyT = 1014344178; PZixufPoaKCyT > 0; PZixufPoaKCyT--) {
            pWrQYzPFMBVlB = ! pWrQYzPFMBVlB;
            yHefruvYutwGwd = ! pWrQYzPFMBVlB;
            yHefruvYutwGwd = pWrQYzPFMBVlB;
        }
    }

    for (int YiYGOLb = 1867505280; YiYGOLb > 0; YiYGOLb--) {
        yHefruvYutwGwd = ! yHefruvYutwGwd;
        WLUUysbgg += WLUUysbgg;
    }

    return pWrQYzPFMBVlB;
}

string ztDLesmApjlftPC::PgsxRgoTyod(int VOlRxwwW, bool OuYxmSIDwEaPSvP)
{
    bool Dztkf = false;
    string eGZphQoVIiA = string("bvZzvoFECsZmnaTUVcSCuGlFtQaygbBqdMCasHRUtUrpSyglRscEeURravxQjutudYBdWIHOqWdpkgvYoWxRSbRmsqRpGtxJlEmdNCyuGsFlMFWEEiAYfMrwcsmyQfET");
    bool mshkrnATFB = false;
    string urTpZXcS = string("cNTtOmZrPbUxRXPAzzuAZUTetAKNJbJCtFyZnADIFQOwWDLbsuiwYqsByOboYxsxSlpsIgzeeaxKnAGUnOIoXYFGtbefdbnjyVaMvXrtERizfZghXHRAQvbqcPwsgwlLKxGwcyohbTcdwjkmz");
    double TkvicmVyhaxOm = 678234.6300878854;
    bool dnfQIWon = true;
    bool kfEHUz = true;
    double DQkDasNXdFmMZFH = 46389.663641493236;
    bool sOqcQkrbX = false;

    return urTpZXcS;
}

double ztDLesmApjlftPC::WMoyzXtIlAuO(int EjvauUZyMCSqe)
{
    string zGCzBacbsESZELr = string("FYYabwpt");
    double aIdubolQhYSyZCff = 60427.98325222457;
    bool hBVlZmxnCiFbxVE = false;
    bool DXjZOlZoBElOL = false;
    int DVJbnbSqWhbqiAOA = -1794940359;
    int GNaCI = -23582810;

    if (hBVlZmxnCiFbxVE == false) {
        for (int mhkYsfs = 880931348; mhkYsfs > 0; mhkYsfs--) {
            DVJbnbSqWhbqiAOA /= DVJbnbSqWhbqiAOA;
        }
    }

    if (aIdubolQhYSyZCff != 60427.98325222457) {
        for (int FNFLuwcichQABwV = 724351028; FNFLuwcichQABwV > 0; FNFLuwcichQABwV--) {
            hBVlZmxnCiFbxVE = ! DXjZOlZoBElOL;
        }
    }

    for (int DkLFdO = 1965609578; DkLFdO > 0; DkLFdO--) {
        DVJbnbSqWhbqiAOA = DVJbnbSqWhbqiAOA;
    }

    for (int OXokSu = 1714339135; OXokSu > 0; OXokSu--) {
        DXjZOlZoBElOL = ! hBVlZmxnCiFbxVE;
        DXjZOlZoBElOL = DXjZOlZoBElOL;
    }

    return aIdubolQhYSyZCff;
}

bool ztDLesmApjlftPC::dqjWCmrHpNws(double aLujcKdMkbewXsC, string ZcTWjUrI, int ikLQpsxul, double mBYbEueGMOA, string WsSsFcls)
{
    double gPgueEFXGzwqANB = -945153.6534903676;
    string ZZemSTlobqC = string("hJsObcuyjmQRWiTZkUICrzMWasDEngokQyuUVsxGsqwWmoARwpoHthDEzVjaNDMafYEDlaTGrDRMbwQaikgTQPudzqVuFLkHQCpRpazpptqWvBCdOnoGJiWSYgLe");
    double vHTiRBijbflxQDZ = 1041462.9550902387;
    int EDGlvX = -1159333336;
    bool xRuWhTVHmeSJIxH = true;
    bool xETVcZx = true;
    bool pkEJcRrygAXSG = false;
    double xnCpsM = 919255.4842601327;
    double IMhFcXEwn = -489725.7590270472;

    for (int DlGRXDVmot = 150810708; DlGRXDVmot > 0; DlGRXDVmot--) {
        IMhFcXEwn *= xnCpsM;
    }

    for (int NEICHqXa = 80949080; NEICHqXa > 0; NEICHqXa--) {
        IMhFcXEwn /= xnCpsM;
        xRuWhTVHmeSJIxH = ! xETVcZx;
        ZcTWjUrI = ZZemSTlobqC;
        ZZemSTlobqC += ZZemSTlobqC;
    }

    for (int CfZNKfmqU = 739770102; CfZNKfmqU > 0; CfZNKfmqU--) {
        continue;
    }

    return pkEJcRrygAXSG;
}

bool ztDLesmApjlftPC::kNMHbBZbWb(string OOhVKITRVe, int PYEMGNBRkMblOT)
{
    double FMJpvVUGvqBQH = -775677.7086362388;
    double QmVRimvC = 947377.6235170339;
    bool xTGmnzYluEvUBnFh = true;
    string SVjpvF = string("TfAKpdAIeQEYquCAInlcuvjyvJrQRUtPCHFwudQQYcugGGcSqijIaPebrbSJvOAcGsaiQHIJEOMWEFNezOEcDuwawINSFyggAICAmlgiRTmgOpzQMyYrFmuqaeEAOqVPaufWENRThnGIqolgOQLDodYyXEmWCymmWAsEdoLNIwwMkzRwitnBGjHLDJKGDQwpEiZvqGlOxMizppFNXrtbVMrwiieiGBkgZLQWfQWWGwCZmgOAQABqWxkmwAh");
    bool LpWCrGoTZKwFQz = false;
    int NUsCPgmcfjuTe = -1096377022;

    for (int XoWoaLvv = 1005442217; XoWoaLvv > 0; XoWoaLvv--) {
        continue;
    }

    for (int zkkQMIlLVasVITq = 420006095; zkkQMIlLVasVITq > 0; zkkQMIlLVasVITq--) {
        PYEMGNBRkMblOT -= PYEMGNBRkMblOT;
    }

    for (int eBYdFPZntTB = 1916124309; eBYdFPZntTB > 0; eBYdFPZntTB--) {
        QmVRimvC = FMJpvVUGvqBQH;
        xTGmnzYluEvUBnFh = ! xTGmnzYluEvUBnFh;
    }

    for (int TdDsSkheweRaVDn = 1016789213; TdDsSkheweRaVDn > 0; TdDsSkheweRaVDn--) {
        continue;
    }

    return LpWCrGoTZKwFQz;
}

ztDLesmApjlftPC::ztDLesmApjlftPC()
{
    this->geTnlZimnqoC(false);
    this->cwtAeGCSmxv(true, true, 992695249, string("GtSZLVqsfLNvFeeuFBgzFjGDoRECAdDNYBecuDmamlggoRvbSfLyhzzfVlswnOimnYAVMnIUtjzKKCOiyEenwbktvGNfXkliqZrIkQkjBNaAKlNmheIjBlLgnDhiBLVDxGtSTEI"));
    this->QoqNmaLLWuMERJi(1510808092, 212145.6484965992, string("mnpXMfpLsrTImfHoFarhiGtnxDKMQYZNncjUCoycRKunMzypssZrpaGmUPINcKdPlzJLtBPILxJPfVIJFCGPzOjxAeuYNqvsLkUTZQYXxndALPYkyRGTuNMHOyAOybztWvSmzycNxCDYCbyZXlsnxvoxsMNGAuoBmyUWcvKJVTxmPLLZIYqqlASgG"), false);
    this->CaggASGWElo(string("vuJrV"), 628058.8111812226);
    this->slFTw(1006024.1391318659, false);
    this->qDhQdweytdoMxSw(-167569.34280705327);
    this->nnAzeSoUoimdLsTV(string("hlGZMYACpQrRshUqGtNEZSnrxWfAgRdFiurmtXswRvQIPCyAScKyqDdBGsnKQBWGQDrqDNBBgzjsxtafAuEPFWKSpXBgXSsVRaBpeNjmdnAmllnSaNJStKuAOKfPDzjCKzIGpQJNBzRQxDZSsVipDEuTYJAchCqqOXodalFwCEbuuyhRijfNklXUWvTJFvrfFmiwXjUuCRzxkbbFMsvmFkFfcWpxDiSwJyQpTcMFiGUaiZxXxCGDabiLtU"), false, 979716137);
    this->WzJWSTdmMpdgHNWU();
    this->JwTZUimjPlBJOXU();
    this->wugwDm();
    this->PgsxRgoTyod(-176856776, false);
    this->WMoyzXtIlAuO(1581662613);
    this->dqjWCmrHpNws(829758.1278514173, string("nCKNBXWVcuyFSMqnwJ"), 769913043, 573974.0483277362, string("PNKSrAtRaRqhXSEFWhJatctlrPWOjzIYosUEwBWjg"));
    this->kNMHbBZbWb(string("SSdYAZNUHVHtJAeWoNkagLirnSNOqOaeXQLBWAlYgQYIzyUDjZESQwfeOIravZggvXQsxbfFdfiMvRycpv"), -1009650008);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WVHIHuQORhN
{
public:
    int bOFrwOqSS;
    bool bFbZtEG;
    int fgKhyPapRrau;
    double iPnihzXpa;
    string GuLwV;
    string PusMWyK;

    WVHIHuQORhN();
    int OtGyiRVyfGKlSuHA(double EOMGhjyyTSWuX);
    int xITIHDCzZ(string mDsUqEbT, double xFuPIrjCmLav, int IvszvGcOiTrgV, string NsGCuRhehjGnQp);
    void gesmAcE();
    bool HWrlJxMtiZgJKTox(string YLxXS, int YOmld, bool XOKqEAQUOBjMw, int bazvtDZmLoHtp);
    string tfdgYRSQdaUWn(double YqqcPExJot, bool xcrRpk, int bVUvb);
    bool VpqzGM(int mNUIBeTtOGZ, string NzvxTJdeGaSt, string NRqyxyUVDOvcoVr, double vIYiMKCj, string KIVXzgSGVoju);
    void AdQurIiQJHYBMJuH(double dCBuWIpvqhC, bool InDYFeExOPwF, double rqzkWcOQSGsUs, int eIGmXzYlbO);
    void YHomgpo(bool gqVSGnjMOaiQkuSG);
protected:
    double MsgZYIq;
    string TypGUxxaGtovEY;
    int LcdUhqVrWoaMoOUt;
    int YpNboGTcfWLXG;
    bool XGDMGMl;

    bool mIejCkINXZ(string raRCEc);
    void jzpcFCIdCK(string PawuqxBitQznWYt, double mWSon);
    int rajhAJDGtWL(bool exVqtRxekbPMnEvr, double cpTNKdXXxMQT);
    double RjkpiapyMLwDF(int jUZiOOLtBs, string czLnhALlp, int ltCvkzftDuqyPMe);
    string nXzLKPqIhlnw(string HAdGPwgrkDTyPSSI, int TwvpsqqiXTQZgTwF);
    void iQHCKMengxmvLwRW(int nOFhqaDHot);
private:
    bool XGZbXZGDSOCeXZbN;
    bool CdSVr;
    string sZTdN;
    string EjBJDJUn;
    bool ghxYqDb;
    double cpQssYqmCRXnc;

    void ayCUtzJgSlSQzMp();
    string NqeYTbovNkXzexpm(bool pSLdeSjqxK, int VKCxZwPX, bool PdYbf, int EOhnrvPj);
    bool yrFboDfKgWyvEcN(bool WbCMBqnHpbXAoZI);
    void NGaHAUt(double yVWgVZAsN, int FPzopIB, bool QaGcAUhmyHMEX);
    string cUvbO();
    bool bifEQTuTkosbs(double rvCRbwyD);
    void EkMNyJWv(string VMUKMTFzA);
};

int WVHIHuQORhN::OtGyiRVyfGKlSuHA(double EOMGhjyyTSWuX)
{
    string BWPwMp = string("CwwWszDTXkgMeBhIXofqgcYfCEmLgVEnQvXzlgxlktZJvSutLBfjOKpWWLGBfMBvwhcKViCYvRYNJKulAioIDMncsPYyVZMVsreAEtrAhqNQzSxSnYCOlAngkyafSwFfhXtQPYgdNp");
    bool qZFRHDOfGkgp = false;
    string neKMyqdTDZo = string("OYyHjkHMMTOxnGYdedRWfdPPLvswgdLNwUZvxtWCA");
    bool IHbbewRZCthwSC = false;
    string QikqzrPLPRCdaEhj = string("RzKLLglrwgPaQjGoosqlIeTmUTdgfze");
    double ztTvHC = 698850.3733362264;
    int DQeMeStuUwQn = -516768409;
    bool hDawXrYTOtdNPsgK = true;

    if (qZFRHDOfGkgp == false) {
        for (int yqBKBfK = 1012626789; yqBKBfK > 0; yqBKBfK--) {
            ztTvHC = ztTvHC;
            IHbbewRZCthwSC = ! IHbbewRZCthwSC;
            neKMyqdTDZo += QikqzrPLPRCdaEhj;
            EOMGhjyyTSWuX *= ztTvHC;
            hDawXrYTOtdNPsgK = qZFRHDOfGkgp;
        }
    }

    for (int YawpbnfSBFZEF = 286619881; YawpbnfSBFZEF > 0; YawpbnfSBFZEF--) {
        QikqzrPLPRCdaEhj += BWPwMp;
    }

    return DQeMeStuUwQn;
}

int WVHIHuQORhN::xITIHDCzZ(string mDsUqEbT, double xFuPIrjCmLav, int IvszvGcOiTrgV, string NsGCuRhehjGnQp)
{
    double sRLiGkctRJnMf = 181169.76416758818;
    double TphlGMps = -241717.8476062439;
    bool LDsVrdEWZTgLC = false;
    string xmfCdKft = string("sbFpsebYAclHhovDxcnXKpgGMFpGhOKPsiHOpjFOQD");
    double fwHkDuheBGABjj = 691956.097752562;
    bool TfOOzb = true;
    double HGVddybdJzP = 185900.91004247466;
    int mFCFiu = -83277195;

    for (int oFGeO = 383791788; oFGeO > 0; oFGeO--) {
        TphlGMps = sRLiGkctRJnMf;
        fwHkDuheBGABjj /= xFuPIrjCmLav;
        mDsUqEbT += NsGCuRhehjGnQp;
    }

    for (int CQnfSw = 559781454; CQnfSw > 0; CQnfSw--) {
        IvszvGcOiTrgV -= mFCFiu;
        fwHkDuheBGABjj -= xFuPIrjCmLav;
        xmfCdKft += NsGCuRhehjGnQp;
        IvszvGcOiTrgV = mFCFiu;
        sRLiGkctRJnMf /= HGVddybdJzP;
        HGVddybdJzP *= sRLiGkctRJnMf;
        sRLiGkctRJnMf -= TphlGMps;
    }

    for (int QphHcESrArQd = 1094120753; QphHcESrArQd > 0; QphHcESrArQd--) {
        xFuPIrjCmLav /= HGVddybdJzP;
        HGVddybdJzP += sRLiGkctRJnMf;
    }

    return mFCFiu;
}

void WVHIHuQORhN::gesmAcE()
{
    double gOpSlRhfDCeuJrA = 980747.2807970424;
    double ZkmTsPOOxIISkT = -960152.2218879529;
    string jCagYNbyfzZkIE = string("DNwBfPBZHZnEwhTuUpjGmkyLVqgbMfvwoCWYfHaxWXrxwFEsZpivHVegamPbytwZNuJgPUVIzVNYbUcRWSmCtEqcX");
    bool ThEaeeJUTZQzcr = false;
    double CiockeqhcgSz = 611685.7999283742;

    if (gOpSlRhfDCeuJrA <= 611685.7999283742) {
        for (int RAcovikJzDDNaT = 43200506; RAcovikJzDDNaT > 0; RAcovikJzDDNaT--) {
            CiockeqhcgSz -= gOpSlRhfDCeuJrA;
            gOpSlRhfDCeuJrA /= CiockeqhcgSz;
        }
    }
}

bool WVHIHuQORhN::HWrlJxMtiZgJKTox(string YLxXS, int YOmld, bool XOKqEAQUOBjMw, int bazvtDZmLoHtp)
{
    int KmEEHfial = 1563919993;
    int tLchhq = -340900150;
    bool ZsklZUdg = false;
    bool gTKsiWu = false;
    string oCihAfeSeCtv = string("vVYBqDcZUcbwpSzgkVALZFScIFSzCyqnXAEYoidPvnExNTfklJKdgLaCJrulQXaTQDDaBEjmoSXAAmTHRdxeRanqRuWuQORQlkcsbEvTHTXzBJdxbkPaatbwZSDchoEymIlRwiyUKbJDOkPgRdEpWSMXQGQ");
    double RTPDwLWroq = -150130.5694018011;
    string PMcSbCRY = string("BRIAKreOGI");

    for (int eLLcRHVbn = 269939601; eLLcRHVbn > 0; eLLcRHVbn--) {
        bazvtDZmLoHtp = KmEEHfial;
        ZsklZUdg = ! ZsklZUdg;
    }

    for (int GcyVdcqKj = 708733993; GcyVdcqKj > 0; GcyVdcqKj--) {
        tLchhq /= YOmld;
        PMcSbCRY += PMcSbCRY;
        bazvtDZmLoHtp += YOmld;
        KmEEHfial /= tLchhq;
    }

    return gTKsiWu;
}

string WVHIHuQORhN::tfdgYRSQdaUWn(double YqqcPExJot, bool xcrRpk, int bVUvb)
{
    double IspCJxxoGBwYlQtI = -508595.0628469731;

    if (IspCJxxoGBwYlQtI == -508595.0628469731) {
        for (int THTYFNe = 1256134758; THTYFNe > 0; THTYFNe--) {
            bVUvb -= bVUvb;
            xcrRpk = ! xcrRpk;
        }
    }

    return string("JPhPhTYRoKLrUZgUZSKLnDyHGzBpbwHwAlFFjqLQcrhSzZaDYyYfInuLkobAFDlLdDoPZzHNzhChwrNPQbYiUpfwUSpksQOcqnBohnsnTyaBCFFcULRyGRIp");
}

bool WVHIHuQORhN::VpqzGM(int mNUIBeTtOGZ, string NzvxTJdeGaSt, string NRqyxyUVDOvcoVr, double vIYiMKCj, string KIVXzgSGVoju)
{
    bool mKKHuKNRQEDqNDw = true;
    double GJcEnBh = -396967.6990463665;
    int kBiEaOThXlPsg = 2006192954;
    bool cfbTv = false;
    double KFsnLsUYucJKsNPI = -119761.61376775755;
    int jqTnRKIqz = 613042095;
    bool PzYYXn = true;

    for (int KrLROAy = 942772786; KrLROAy > 0; KrLROAy--) {
        KFsnLsUYucJKsNPI -= KFsnLsUYucJKsNPI;
        GJcEnBh /= vIYiMKCj;
    }

    for (int fMZuvYg = 1475536207; fMZuvYg > 0; fMZuvYg--) {
        KIVXzgSGVoju = NzvxTJdeGaSt;
        PzYYXn = ! PzYYXn;
    }

    return PzYYXn;
}

void WVHIHuQORhN::AdQurIiQJHYBMJuH(double dCBuWIpvqhC, bool InDYFeExOPwF, double rqzkWcOQSGsUs, int eIGmXzYlbO)
{
    int gSsSM = -342648803;

    for (int cfLmmh = 1497914600; cfLmmh > 0; cfLmmh--) {
        continue;
    }

    for (int nRMZtyS = 528711391; nRMZtyS > 0; nRMZtyS--) {
        rqzkWcOQSGsUs *= rqzkWcOQSGsUs;
        eIGmXzYlbO *= gSsSM;
        gSsSM = gSsSM;
    }
}

void WVHIHuQORhN::YHomgpo(bool gqVSGnjMOaiQkuSG)
{
    string RqukZMvuilRMh = string("BJBndjlVsWEVOdaNHMgZovrsWyMcdPTQShJKVfXglvnyqeevgRvcYxsPPmWkdUdJflXhlGuxSzIOuKfdYvIjeIkEbmdAvIjodoDrIdEPapZyBhpyajtBaSATFIcXbwtzuIwSBFRIQefVaYebmQmBrypFgpXwWUSIlcUnmSINhqEOKUREyuoIBjdaNXwSYIqfVKZVxybceJdOuDXGCmpFKcUCsJbfoWUvjeQdimMzjiYduULwvqnY");
    double uibXYg = -748992.3597475268;
    string DUdYvAMbIlhAJ = string("nQLLulC");

    if (RqukZMvuilRMh <= string("nQLLulC")) {
        for (int NsgyEUZkRl = 1694570677; NsgyEUZkRl > 0; NsgyEUZkRl--) {
            RqukZMvuilRMh = DUdYvAMbIlhAJ;
            RqukZMvuilRMh = RqukZMvuilRMh;
        }
    }
}

bool WVHIHuQORhN::mIejCkINXZ(string raRCEc)
{
    string SvWnKjaTAxJOBN = string("ZKODgvaKRAfCOFMUPcfxOXmHuifGCjrRyTevzQGUCaKbYklfMfvIQ");
    int LPssGZNjJ = 1470910286;
    int hkmKATBoYhFAq = -1335868590;
    int zGUpdH = 642007977;
    int IrIHoEPNYMKaT = 1649328410;
    int LVkwewoOO = -1877580857;
    double KzdrbT = 988072.1295645161;
    int FDCTtX = -23221428;

    if (IrIHoEPNYMKaT > 1470910286) {
        for (int gKcUvxHHlAtGRwEa = 2016147839; gKcUvxHHlAtGRwEa > 0; gKcUvxHHlAtGRwEa--) {
            hkmKATBoYhFAq -= LPssGZNjJ;
            IrIHoEPNYMKaT -= zGUpdH;
            FDCTtX *= hkmKATBoYhFAq;
        }
    }

    for (int kOmpWOaCVe = 406968453; kOmpWOaCVe > 0; kOmpWOaCVe--) {
        LVkwewoOO /= FDCTtX;
        hkmKATBoYhFAq -= LVkwewoOO;
        hkmKATBoYhFAq /= LPssGZNjJ;
    }

    return true;
}

void WVHIHuQORhN::jzpcFCIdCK(string PawuqxBitQznWYt, double mWSon)
{
    double mWDVtYXL = 860911.8759844782;
    bool DqNcOfqU = true;
    double MgmaSypzw = 194702.91763908026;
    string MIACE = string("aZhdLYRyX");
    string xXAeOwcx = string("MeQClzDcKRJucnHPlQhTGUgDoryuOWKdFzfbBjqCEFWuANZjeUBPYJtXhNdHgZLxzjBwJhEACRQJfVirMfpCgDOwuGJsPoueqjmsYugQcYsMXhIilQcsxpjDfYGwYXIoOAPXRzBiNgcieNhLdTFkjbXcHDUAFfVJfHyDIOtzaiEYVKcoJzobAIMHQ");
    string XbVNHuH = string("BbYBTmMkqCDBYEkigfdfLXMgGhFaqjjvjCuwxWgJ");
    double CkdbDgrvSTsw = 237265.81246521472;
    double qxqkXyUKyUU = 118221.83324512209;

    for (int LQdLCcuDwIM = 1065293275; LQdLCcuDwIM > 0; LQdLCcuDwIM--) {
        qxqkXyUKyUU -= MgmaSypzw;
        qxqkXyUKyUU = MgmaSypzw;
    }

    for (int wAjfrHwntJBmKMUp = 84914226; wAjfrHwntJBmKMUp > 0; wAjfrHwntJBmKMUp--) {
        mWSon = mWSon;
        MgmaSypzw += qxqkXyUKyUU;
        CkdbDgrvSTsw /= MgmaSypzw;
    }

    for (int rWEBWDaoZsa = 1201753423; rWEBWDaoZsa > 0; rWEBWDaoZsa--) {
        qxqkXyUKyUU -= mWDVtYXL;
        MgmaSypzw = CkdbDgrvSTsw;
        qxqkXyUKyUU += mWSon;
    }

    if (xXAeOwcx >= string("MeQClzDcKRJucnHPlQhTGUgDoryuOWKdFzfbBjqCEFWuANZjeUBPYJtXhNdHgZLxzjBwJhEACRQJfVirMfpCgDOwuGJsPoueqjmsYugQcYsMXhIilQcsxpjDfYGwYXIoOAPXRzBiNgcieNhLdTFkjbXcHDUAFfVJfHyDIOtzaiEYVKcoJzobAIMHQ")) {
        for (int fQPFbbptZSwIhors = 526473669; fQPFbbptZSwIhors > 0; fQPFbbptZSwIhors--) {
            CkdbDgrvSTsw = qxqkXyUKyUU;
        }
    }
}

int WVHIHuQORhN::rajhAJDGtWL(bool exVqtRxekbPMnEvr, double cpTNKdXXxMQT)
{
    string iKBfkgFgIjHsy = string("dFWfasJVQySjdpFVVrPaYZYfjDQAXhRjQhaUaQFpzWSCTRTsJdwmSteuYXfbrdfTbSYfuUQNJMeuNK");
    double qxrsaTJqv = -488533.51594459283;

    for (int nbVOw = 49003382; nbVOw > 0; nbVOw--) {
        iKBfkgFgIjHsy += iKBfkgFgIjHsy;
        exVqtRxekbPMnEvr = ! exVqtRxekbPMnEvr;
    }

    return -2044693100;
}

double WVHIHuQORhN::RjkpiapyMLwDF(int jUZiOOLtBs, string czLnhALlp, int ltCvkzftDuqyPMe)
{
    bool HLoiJQFJdVqE = true;
    int IAkKxQSjinPbBVWq = 1478878492;
    int sdQeWUcyDAkW = 1674207689;
    string rwjEIS = string("kPNyhRZAKEptdqsufWWGTUaeWmUPQWqenkEaZFdPErNqzZBmOpwXmSCOjnhJtWbDvMhJRvKMB");
    double nRKDOzebFTqbpLM = 506081.806786111;
    double xAaCjCkBuvgX = -770196.6939025471;
    double SvHRvjVxb = 683936.7419556923;

    for (int yoVgdd = 448842851; yoVgdd > 0; yoVgdd--) {
        rwjEIS = czLnhALlp;
        xAaCjCkBuvgX /= nRKDOzebFTqbpLM;
    }

    if (IAkKxQSjinPbBVWq >= 1891468769) {
        for (int JrnjbeUwQcQVKs = 1695624326; JrnjbeUwQcQVKs > 0; JrnjbeUwQcQVKs--) {
            IAkKxQSjinPbBVWq -= ltCvkzftDuqyPMe;
            czLnhALlp += rwjEIS;
            SvHRvjVxb = xAaCjCkBuvgX;
        }
    }

    for (int bWnFdvgTSn = 1774118473; bWnFdvgTSn > 0; bWnFdvgTSn--) {
        czLnhALlp += rwjEIS;
    }

    for (int kaOQpdg = 1150348066; kaOQpdg > 0; kaOQpdg--) {
        continue;
    }

    if (IAkKxQSjinPbBVWq < 1891468769) {
        for (int LDFTS = 405973635; LDFTS > 0; LDFTS--) {
            czLnhALlp = rwjEIS;
        }
    }

    return SvHRvjVxb;
}

string WVHIHuQORhN::nXzLKPqIhlnw(string HAdGPwgrkDTyPSSI, int TwvpsqqiXTQZgTwF)
{
    int PkVQaJxkMNQ = -87118474;
    int WMvZGz = -558714999;
    double XVpsnOHeRZ = 520776.4073219809;
    string VMOubHnXFl = string("eOWLExFzyYOrROVKceJOAApLODRjYHYeMsAwFmSnccGRTWxokbFahECACJKrhP");
    string wEzXsdNgIbUM = string("PAxDsVirzxxEOSNxyLCmKIbHhZhnQvsxXLWMnSAofsqDFYCkcbuXsgDRBABFccXDXGCccRCNrJvLFXNPJnEMAhnRBsrQykWLADVFiBEhegWyGnitmUzTsiXOPtsGKHailhkUIYvbWcmJFsppkNqgBaniWItrvkMNVccpObNbmOxsvllXmVNTvyUKQzpCKDbouLgeewdZStpLaNjwbPtJMTErhgfoSiyqgjPIogYystWpkEAmZGBjpN");
    string XuYskJFMFlSywR = string("nTqgijDgJmjvEKjpknAgkVfxShluJOPuulfFiVSeHLXUsVTpOdjuwvWNvbsyMJVrCsKNdVTiuGTRgjUpcadgRrekwHzhjhHIfGfnsUnRuNdvjudpPkGbwRpxLkNLWplFrihVeBJlhAhEhtEJlts");
    string pCKGfFVax = string("AHXuMkBPrucZBEcSFwoALwumAyEGAWLUBdXAVqabABbrLyPEouGlTgBsCwiqkErDsFxGytZDgeXygWpvOETzkdmjjtCvKZWBLCBDvRAiLVtBPwySmQcdvvWByFhJTOEantddlxoMsXMCuezZazxdQiyABFTFqVnqKSLcQXlwJhXxmSxblRLsCSsXuqnMrNNlehLBCHqOktIdPHRQelgpIfXP");
    string bDkvlZKOWTepR = string("DgfXgKewUYkcJjJhydAPiSSBsIKcvvFnKIwqazDQpQpjzCgBRBlltFhyRfkmiXSGbVBAENKIyEnYIkJExOVJRAXbIHOMRrMYzEfdaJUjwIlLkzxgqPOTdeVkLuSYNvbimqirLYALxnhkMsgXZAKOQyVzBqcpjOlOQdOmqUezZHyfFHDOVdofe");
    double xUjWmrTb = 689159.6346392516;

    if (bDkvlZKOWTepR > string("DgfXgKewUYkcJjJhydAPiSSBsIKcvvFnKIwqazDQpQpjzCgBRBlltFhyRfkmiXSGbVBAENKIyEnYIkJExOVJRAXbIHOMRrMYzEfdaJUjwIlLkzxgqPOTdeVkLuSYNvbimqirLYALxnhkMsgXZAKOQyVzBqcpjOlOQdOmqUezZHyfFHDOVdofe")) {
        for (int SCoseOteKN = 1850192588; SCoseOteKN > 0; SCoseOteKN--) {
            HAdGPwgrkDTyPSSI += pCKGfFVax;
            XuYskJFMFlSywR += bDkvlZKOWTepR;
            HAdGPwgrkDTyPSSI = XuYskJFMFlSywR;
        }
    }

    for (int SvGxtBwzo = 1011483443; SvGxtBwzo > 0; SvGxtBwzo--) {
        WMvZGz += TwvpsqqiXTQZgTwF;
    }

    if (wEzXsdNgIbUM == string("PAxDsVirzxxEOSNxyLCmKIbHhZhnQvsxXLWMnSAofsqDFYCkcbuXsgDRBABFccXDXGCccRCNrJvLFXNPJnEMAhnRBsrQykWLADVFiBEhegWyGnitmUzTsiXOPtsGKHailhkUIYvbWcmJFsppkNqgBaniWItrvkMNVccpObNbmOxsvllXmVNTvyUKQzpCKDbouLgeewdZStpLaNjwbPtJMTErhgfoSiyqgjPIogYystWpkEAmZGBjpN")) {
        for (int VmjyqnBwBKALYVJe = 1943279039; VmjyqnBwBKALYVJe > 0; VmjyqnBwBKALYVJe--) {
            XVpsnOHeRZ = xUjWmrTb;
            XuYskJFMFlSywR = wEzXsdNgIbUM;
        }
    }

    for (int tWxXltye = 729190422; tWxXltye > 0; tWxXltye--) {
        continue;
    }

    return bDkvlZKOWTepR;
}

void WVHIHuQORhN::iQHCKMengxmvLwRW(int nOFhqaDHot)
{
    int oGTdoOuabzyZkyn = -1274767248;
    string dzzyMQUT = string("aEQyPiQdarTvpZvQCxEeRIZarqqlVhfbpTjPQqQcuKBikEvPFELgfjlbXTRFLcqagqfeOIxuW");
    int gmKSRvkwRMRDdE = 1486308113;
    int uoVnsKOpN = -1187429814;
    bool mpkdTAUrccdxq = false;
    int HQqrWUhBuI = 300712695;
    bool QQVDjJVPvE = true;
    bool qOiPbwsXLWnqbNf = false;

    for (int zHEwjZScPtGJXjUk = 1450067792; zHEwjZScPtGJXjUk > 0; zHEwjZScPtGJXjUk--) {
        uoVnsKOpN += HQqrWUhBuI;
    }

    for (int yxKVZTaBORz = 949146788; yxKVZTaBORz > 0; yxKVZTaBORz--) {
        continue;
    }
}

void WVHIHuQORhN::ayCUtzJgSlSQzMp()
{
    int XvVcKQdOaONtlj = -442501869;
    string ewoyhbLxnIlB = string("UXXWMvpkJfgOHtCWCwGttKhQYeNBfrACNFXIXslyTHyKMZWYZxsYgnXNgvxVIjjNoFuoVaLEsLcXH");
    string sCiISZetAzWbNqhm = string("xjHsYKtlTefnGroYaGJTUqpAhaOVdsDDPqOjUTfMYIzGVCbEJKPDbRsmTHgjxBRAEeyzWowVuHYqTW");
    double HkUTYCVvTkLWMT = -7577.175925995529;
    string SfkNUXd = string("EGZjnELIxczIyMqyHwPggqpNIXcxYoyyZRzxQNNPvyaoUyAenFUBcAbnnTvPrkxrtSVpXgNUgOLaDWXfUlTvBQNAMxeGLFWdYkrhfWtLqFBNlKgOteaPjXNbTIbWjJbBvomNSqcrSGpLqIVXCxiIthrkrrDenhsCLakvvflJbBnqbqXZq");
    double CcOnYsCoJmOpazb = 35042.28427340668;
    bool ltutqBsfdut = true;

    for (int GGcSAbg = 679124147; GGcSAbg > 0; GGcSAbg--) {
        continue;
    }
}

string WVHIHuQORhN::NqeYTbovNkXzexpm(bool pSLdeSjqxK, int VKCxZwPX, bool PdYbf, int EOhnrvPj)
{
    string DKiTSLh = string("lVpettKmLMNgfhnaCgJGiDRmOhEDOpeWNbbOMUpTBbHiKUIlxZSiBYfJfrAjSDRfdexLoKuCgAiyiTNNxKJoXNpObUxrbGZcOioPoWyQdFAfDWCFIWCXDjwWJRUNRjYPMuMtdDzcCxdyaeITBaeoDxNmQHdBocULsmWKUEUkNQceadNijjUpaWGHXsirJJsHfidYUGDkJZkxxZl");
    string pxhsX = string("SDrxgQawEydrglBCzyAwJldLXiCBhzWIaDmIJvEiySUAQeftDksapvTtPQTBWjsLXPbjPvxCbLigmKkOijhHPlRvzeOMyfGgVgkoVYOvGLOznvhmxjdfhJvQxPYqdjqBDVxZMLfOUEwhzBjBzvvffnvmDFstYpkPVIFuxrrnsOsmNrqtONaAUYwPZPunGddakGDIRnfuVCwBXazfgKrzxmomqXxh");
    bool XVWZiTxhlCu = false;
    string zewzwvycCSCQ = string("vujgiCFQSMvUgxVEcgRkboyELKLMyIZQQZbobSelVogXUDswyRvqYSRazkmFwUrksvOHUEiisZynOaTPtfhNRLhECzGWt");
    string fSwTZ = string("fHnhxjnfHXVVOZFvnJgLbssiOEABbNnHyaCsIflZqWWHSEOPrGYCtZXdnRMPnHOCIPlXONHmEKAdZNXsFSECSzZQUXMIgLSptGIjJlKYiCarTCvTJGFzSiZYjfXEeWJDgacUwaDZRNpVVpHLqZNEtcIMxPTgiCEGEGfaixmwvlYkjwniwZsYwkgOSPFauQEvbvhyYDbYS");
    bool pSzXAh = false;
    int WstDZqLytiJNIzIL = -727993915;

    for (int spZASZoldKaQpOAC = 883940079; spZASZoldKaQpOAC > 0; spZASZoldKaQpOAC--) {
        pSzXAh = ! pSzXAh;
        DKiTSLh += pxhsX;
    }

    if (fSwTZ < string("SDrxgQawEydrglBCzyAwJldLXiCBhzWIaDmIJvEiySUAQeftDksapvTtPQTBWjsLXPbjPvxCbLigmKkOijhHPlRvzeOMyfGgVgkoVYOvGLOznvhmxjdfhJvQxPYqdjqBDVxZMLfOUEwhzBjBzvvffnvmDFstYpkPVIFuxrrnsOsmNrqtONaAUYwPZPunGddakGDIRnfuVCwBXazfgKrzxmomqXxh")) {
        for (int BUHacToVVpZMNU = 2098390370; BUHacToVVpZMNU > 0; BUHacToVVpZMNU--) {
            continue;
        }
    }

    return fSwTZ;
}

bool WVHIHuQORhN::yrFboDfKgWyvEcN(bool WbCMBqnHpbXAoZI)
{
    int tETitEjNKzF = 1839863274;

    if (tETitEjNKzF != 1839863274) {
        for (int CawVDatNoA = 744726553; CawVDatNoA > 0; CawVDatNoA--) {
            tETitEjNKzF -= tETitEjNKzF;
            tETitEjNKzF += tETitEjNKzF;
            tETitEjNKzF = tETitEjNKzF;
        }
    }

    for (int iAVFbSnsfAMS = 933325091; iAVFbSnsfAMS > 0; iAVFbSnsfAMS--) {
        tETitEjNKzF /= tETitEjNKzF;
        WbCMBqnHpbXAoZI = ! WbCMBqnHpbXAoZI;
        tETitEjNKzF -= tETitEjNKzF;
        WbCMBqnHpbXAoZI = WbCMBqnHpbXAoZI;
    }

    for (int WjGbF = 1270024793; WjGbF > 0; WjGbF--) {
        tETitEjNKzF += tETitEjNKzF;
        tETitEjNKzF += tETitEjNKzF;
    }

    if (tETitEjNKzF >= 1839863274) {
        for (int WffraKGoQHJi = 247111739; WffraKGoQHJi > 0; WffraKGoQHJi--) {
            WbCMBqnHpbXAoZI = WbCMBqnHpbXAoZI;
            WbCMBqnHpbXAoZI = WbCMBqnHpbXAoZI;
        }
    }

    for (int SnshMlAVtdFm = 2084654851; SnshMlAVtdFm > 0; SnshMlAVtdFm--) {
        WbCMBqnHpbXAoZI = WbCMBqnHpbXAoZI;
        tETitEjNKzF -= tETitEjNKzF;
        tETitEjNKzF += tETitEjNKzF;
    }

    if (WbCMBqnHpbXAoZI == false) {
        for (int wsJvpUmCdptX = 38120247; wsJvpUmCdptX > 0; wsJvpUmCdptX--) {
            tETitEjNKzF *= tETitEjNKzF;
            WbCMBqnHpbXAoZI = WbCMBqnHpbXAoZI;
            WbCMBqnHpbXAoZI = ! WbCMBqnHpbXAoZI;
        }
    }

    return WbCMBqnHpbXAoZI;
}

void WVHIHuQORhN::NGaHAUt(double yVWgVZAsN, int FPzopIB, bool QaGcAUhmyHMEX)
{
    string NnrdjZwcgzABHSoO = string("EpPHyKlEJDBrcfRYiirgMnZbbktjTgviSwvNzkTAbOSeUopXKTqYWAOATjUgywHLQgYoHDbscWxZEkqGyDlGZiRWFMvdggkFsHPqeeseBgQXZhgSmvIRkMRXZaVHQZeo");
    string nUeusERphkCW = string("KY");
    bool WLPxrv = false;
    int zzaMWRBRBvgeVnFf = -2110814633;
    string GuSeHoPmdyLNabCX = string("qodMAjkurCbwElVZXRQekVgtmYRCEhQGZGUqbzbJuApiGgFLpyvtIEDmRuynqulBTHWfzEeACCQRxiyOMbgInSyATvQKpXFhbvZISGEWXvTvxPLQlKqnspzqFuemabnrnxWONifQsMQkLMLoteWLoOvsWlYQyTifknREskJFYehqYdrYPobytwQxRdPeLXFOnElf");
    int aWPtBj = -1112561290;
    double cztLG = -266256.812585877;
}

string WVHIHuQORhN::cUvbO()
{
    bool nDgQkwzilwa = false;
    bool YCPSERZHjjp = false;
    double zytBeD = -136596.65505939713;
    string hjSEOPtDyJWFYi = string("yBYofkRtJDGRvbgMROwanKohLeXABxeDQqvkIhNhxyNjCueIVUnnRyvwqbZcGxRCjmDJHUQfgGacDMywdFVEdEOKAzuHCBVdADpCKgRndjoZDaZJUWctSGPuzyugFeDIJWuIiLdaCLcQQUCJcIRYcrNPsTkqxLituLP");

    for (int IEiDtPeyS = 979938628; IEiDtPeyS > 0; IEiDtPeyS--) {
        zytBeD -= zytBeD;
        nDgQkwzilwa = ! YCPSERZHjjp;
    }

    return hjSEOPtDyJWFYi;
}

bool WVHIHuQORhN::bifEQTuTkosbs(double rvCRbwyD)
{
    int BWclEW = -413030005;
    int LzyfFLAL = -2105975392;
    double AkwWkYoJ = 631342.0372551293;

    for (int oCYsJcrY = 948211021; oCYsJcrY > 0; oCYsJcrY--) {
        continue;
    }

    return true;
}

void WVHIHuQORhN::EkMNyJWv(string VMUKMTFzA)
{
    string CYAwpCwDTqAFpDu = string("zMjyWZGhIfNFYAraIQ");
}

WVHIHuQORhN::WVHIHuQORhN()
{
    this->OtGyiRVyfGKlSuHA(63439.15959868334);
    this->xITIHDCzZ(string("XAagFnTbpFhkPwDIeMpxOxrcWKtYYvIbxKfoCWgToXnboU"), -287245.9315087913, -347120823, string("cyqKTzfXbRcljaeFIFebMuTtDAmgdlNCBkLYKgRhVaOcCKxxnbEbsdeoquVkGhtvxXfzXSYeghpIBjEVtJJxYEnwabiTYzKaLqCRswokHmqAWXgsjbMcIwHZEtDgSgMSLfrvIClDdYrVNXFHW"));
    this->gesmAcE();
    this->HWrlJxMtiZgJKTox(string("gFOosUPdvbYvxNljvIJzwmadwSHYNvhyTWOQpSdRQJUJnRBwiaGCZfdQAqoST"), 1646802836, true, 1781149153);
    this->tfdgYRSQdaUWn(-766017.809595513, true, -1874754218);
    this->VpqzGM(-2122930280, string("ErUbXSRNnHpunEbWDPaMDUsTsYSPFobIxxDckieUuUBMlcawniSqDKoxQFUhMPYmXYrhsiXkpzbtBGSErBRgNqvrDVPGvSqEWfyzdVXsSzYkugSlErqfqOZtJdCrOcbkIurOSILMZQcgBVjJXAJowmnfgtEqbrVQfbMqJkzNsfgARjdGxaTNIQuvkKOtmkcAFhXNGdEdQmdnOudKdLPnviuXzW"), string("tzbWeGJXyexnmOphbyVmvaxBApjadRdliTDyYNhzMKpotlzhpzlhpgPKsKtALwFizRRhidHgWFIisLRoMWoBjtjypyOgrOlozIUBAPsYunNMMhHCNUkPgbphKDBLNlpFgvCXAthbErDMsgXiuwiDtxidFzdyIWLxmisafGNXfihdzIgylsoxQukzTbcyxxNyWHAPGTyQtzpBdzWdYheKbp"), 776771.7748330559, string("RJgKY"));
    this->AdQurIiQJHYBMJuH(-835910.9994406824, false, 694810.5249648103, -1250981629);
    this->YHomgpo(false);
    this->mIejCkINXZ(string("CPrwXxBiwAPWWDvSkucZdeTXYVsctNGmgPhFZXfdKhUWdbdkEwexixCSvOvaPojEKwliYFQsJqAtZilWMTejENCmm"));
    this->jzpcFCIdCK(string("XvOIfDKTBnRJeQFupLSaTlMAyQXKqcQYpWSzFnliEqcKIYCvYxTGhrSUAIJuitUSuHOGQikZhFnWEsdJERsLZBNfMZRMcUozXdlTgmSxuZBqpGLuJCRAfUvqWYBIqJCKOopVjzkytgrNKFKldtkhPeQ"), 367143.84390452964);
    this->rajhAJDGtWL(true, -573960.1151406794);
    this->RjkpiapyMLwDF(1891468769, string("iyzIQsYoczVJLYVpKJbBUOwaiBJcHxoaxOBCehfoxQpshRPtjEuQlqsRFspIFcgMzWyjurovfobJhakycTboydGJeHhMWjUoKLKygtOf"), 2027366466);
    this->nXzLKPqIhlnw(string("MrWyvpOdRzWuItLHqPJAcYyNGsYGImroczFgWlIydjHQPeUeRioOqdKkKjAJwmWUuwzervCAMebQaapPTGZynBawmThmC"), -1319855200);
    this->iQHCKMengxmvLwRW(-1749178470);
    this->ayCUtzJgSlSQzMp();
    this->NqeYTbovNkXzexpm(false, -1427255775, false, -1563837107);
    this->yrFboDfKgWyvEcN(false);
    this->NGaHAUt(-647048.9111764232, -1784098192, false);
    this->cUvbO();
    this->bifEQTuTkosbs(-519779.3453574987);
    this->EkMNyJWv(string("TmdAivVOmAMudaineEWealAxjxswrLzzItkAoqdhGCbffqQkECcwvrPMGIyUhvcCpCryeOaRtymKDAlLUROUQoxtPouxwYipJdPrztCayKibqlGMmXrmwfeNZKPGbbgoIkhJokayKBQfwJSaOhYxBZUXexYmYFfU"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FgnMLkeRjNbrAsW
{
public:
    int DwzNwdFSeuh;
    double kiRhtCtvIAzfY;
    int AKjROndw;
    int VtFSSExVNCSoi;

    FgnMLkeRjNbrAsW();
    string LfhnjL(string UfywnIROAhHCNrF, bool ssIaCRUtslxni, bool LJdkFHQ, double qERrOHjWJd);
    bool NejRhBodzovsscTN(int TTcujuCwhKUJg, bool pHzNJkwKmQr, double CGUqMptGFXgp);
    bool fAwdOMOV(double Cgmschj, int CnqcvGOjcIEOr, double xoyzLW, int hxzsLbkT);
protected:
    bool pHIXJgthLFw;
    int BCYQj;
    int DHoFzErlHSvCSrev;
    bool uiHZehjtnudE;
    int WZgVDCsuW;
    double YIYecYhY;

    double nQbJXTSdHphAuT(int YfQjsATRvLWI, bool sDLAKekGMbrUfn, int DyHAsNkREjGKQT);
private:
    int dweGlqWFEOLnF;
    int EfiDJMVj;

    bool OyXMtuGEHlMFAnLU(string XYcnfqTYlyQHCmV, int tkkmyinrdIdWOt);
    int QeFxopukpcqBFj();
    double DToADpaHSSi();
    double paaIHjROSGZfpk(bool quZqIWXHHDavH, double ZYWAvUZHTyNy);
};

string FgnMLkeRjNbrAsW::LfhnjL(string UfywnIROAhHCNrF, bool ssIaCRUtslxni, bool LJdkFHQ, double qERrOHjWJd)
{
    int tPiSWB = -716819763;
    bool crJukZgEd = false;
    double CBEqVmUsPCKgYcg = -250036.6289275531;
    string ialysuRWGgtu = string("QAcVRATUYigBVcfXXVJpVFDLkPkCHGhMwifKtGKRIruqMEznMXjYKVJWPsWpesAiHLMtCMkXTecVqpENFPjPjQi");
    string epwvLovbfW = string("aemWxFzIUbtvwvVpQEo");
    int ZlwgCBpr = -505782897;
    bool mqxjVgGwVGNzY = true;
    bool fFLHXmV = true;
    bool PFJhy = true;

    for (int FlAhvV = 231366567; FlAhvV > 0; FlAhvV--) {
        continue;
    }

    if (UfywnIROAhHCNrF == string("pvdUmHcnfOlBdkJKLaVHaLJUuYNOxkVGhdFfRTCiKZqTgnoPJbGHKktOELiDCwBvgRRrDsCDqSaagZRDXpgIrUzvsZpPOi")) {
        for (int iSLjAFLDrKEuK = 78211216; iSLjAFLDrKEuK > 0; iSLjAFLDrKEuK--) {
            ssIaCRUtslxni = ! fFLHXmV;
        }
    }

    return epwvLovbfW;
}

bool FgnMLkeRjNbrAsW::NejRhBodzovsscTN(int TTcujuCwhKUJg, bool pHzNJkwKmQr, double CGUqMptGFXgp)
{
    double TYvifzIYZrMj = 821332.1025631445;

    for (int djNil = 1201102391; djNil > 0; djNil--) {
        TYvifzIYZrMj -= TYvifzIYZrMj;
    }

    return pHzNJkwKmQr;
}

bool FgnMLkeRjNbrAsW::fAwdOMOV(double Cgmschj, int CnqcvGOjcIEOr, double xoyzLW, int hxzsLbkT)
{
    int PzrDWrNZaQDEkJr = 1191082608;
    string SzNJmDbLNX = string("fMrnMqPWPsDPEMMcAWBBmhIADvfxgdvDZsDFtichTsZVEEYHjipRzbceaOgJrcRECVXPZAfUgAXlAbtCzzBxyFpYNAaSakwICxjiICtBERNyhcDwCywtvAtywJfqyGIxzyHxTyFWJlhqBGACwjvYtGEmyZgEyEaWlInYhkMcdvuOFVezEhQRKFRJZQLDKbZNITEJzNGcUXRbmkIJqBsXluCgQXtmvLweqGnDfowJakTsLpclZkXPjD");
    double rPCaIMZmaTKnv = 671178.3568149044;
    double TgWeWN = -195607.296882473;
    double JVqUaMMobaNyzD = 830094.1477709274;

    if (hxzsLbkT == -691018087) {
        for (int UKMQvmkBplSwvrd = 296019448; UKMQvmkBplSwvrd > 0; UKMQvmkBplSwvrd--) {
            hxzsLbkT = hxzsLbkT;
            TgWeWN /= Cgmschj;
        }
    }

    if (CnqcvGOjcIEOr < -691018087) {
        for (int mGzFp = 805472012; mGzFp > 0; mGzFp--) {
            JVqUaMMobaNyzD = Cgmschj;
            rPCaIMZmaTKnv += TgWeWN;
        }
    }

    if (TgWeWN > -195607.296882473) {
        for (int CCfEWQGBTpVb = 1999842525; CCfEWQGBTpVb > 0; CCfEWQGBTpVb--) {
            continue;
        }
    }

    for (int QKMkq = 600154849; QKMkq > 0; QKMkq--) {
        continue;
    }

    if (rPCaIMZmaTKnv > 798264.5983882453) {
        for (int euZSmqOGJXxjG = 166907758; euZSmqOGJXxjG > 0; euZSmqOGJXxjG--) {
            CnqcvGOjcIEOr *= CnqcvGOjcIEOr;
        }
    }

    return false;
}

double FgnMLkeRjNbrAsW::nQbJXTSdHphAuT(int YfQjsATRvLWI, bool sDLAKekGMbrUfn, int DyHAsNkREjGKQT)
{
    double xVtpzWDEx = 490581.1279724626;
    double ZQwIPujNUuHYAVR = -115003.89820222062;
    int rsKesRXJosKDxuox = 571927544;

    for (int hpSagESX = 1962435923; hpSagESX > 0; hpSagESX--) {
        continue;
    }

    for (int oEIWNYGaBjBNOds = 92054672; oEIWNYGaBjBNOds > 0; oEIWNYGaBjBNOds--) {
        YfQjsATRvLWI += DyHAsNkREjGKQT;
    }

    for (int BMApwoIh = 1687954959; BMApwoIh > 0; BMApwoIh--) {
        ZQwIPujNUuHYAVR -= xVtpzWDEx;
        YfQjsATRvLWI *= DyHAsNkREjGKQT;
        YfQjsATRvLWI /= YfQjsATRvLWI;
        YfQjsATRvLWI += DyHAsNkREjGKQT;
    }

    return ZQwIPujNUuHYAVR;
}

bool FgnMLkeRjNbrAsW::OyXMtuGEHlMFAnLU(string XYcnfqTYlyQHCmV, int tkkmyinrdIdWOt)
{
    int jTwXcrQzUVJEmq = -861060520;
    bool IvIGftPxOWf = false;
    double mlRARuBkYhFzLsK = -291965.06141317164;

    for (int XJRIvaBv = 985281755; XJRIvaBv > 0; XJRIvaBv--) {
        jTwXcrQzUVJEmq = jTwXcrQzUVJEmq;
    }

    return IvIGftPxOWf;
}

int FgnMLkeRjNbrAsW::QeFxopukpcqBFj()
{
    string pVQytvYyNLUTY = string("KiKxPDjOPnnJcQccmUEnruhAJVJrwTOEcJQsAXRDJ");
    double cWChewSQwYMiq = 907847.6616620756;

    for (int dVaDs = 1878864708; dVaDs > 0; dVaDs--) {
        pVQytvYyNLUTY += pVQytvYyNLUTY;
        pVQytvYyNLUTY = pVQytvYyNLUTY;
        pVQytvYyNLUTY = pVQytvYyNLUTY;
    }

    if (cWChewSQwYMiq != 907847.6616620756) {
        for (int TySkRbQJjXb = 255407564; TySkRbQJjXb > 0; TySkRbQJjXb--) {
            pVQytvYyNLUTY = pVQytvYyNLUTY;
        }
    }

    if (pVQytvYyNLUTY < string("KiKxPDjOPnnJcQccmUEnruhAJVJrwTOEcJQsAXRDJ")) {
        for (int hWUyFRqydgVsj = 205902237; hWUyFRqydgVsj > 0; hWUyFRqydgVsj--) {
            cWChewSQwYMiq /= cWChewSQwYMiq;
            pVQytvYyNLUTY = pVQytvYyNLUTY;
            pVQytvYyNLUTY = pVQytvYyNLUTY;
        }
    }

    if (pVQytvYyNLUTY <= string("KiKxPDjOPnnJcQccmUEnruhAJVJrwTOEcJQsAXRDJ")) {
        for (int CwFqIQRDqd = 978048805; CwFqIQRDqd > 0; CwFqIQRDqd--) {
            cWChewSQwYMiq -= cWChewSQwYMiq;
            pVQytvYyNLUTY = pVQytvYyNLUTY;
            pVQytvYyNLUTY = pVQytvYyNLUTY;
        }
    }

    if (cWChewSQwYMiq < 907847.6616620756) {
        for (int NFYkIqtQN = 1147407237; NFYkIqtQN > 0; NFYkIqtQN--) {
            cWChewSQwYMiq /= cWChewSQwYMiq;
        }
    }

    if (pVQytvYyNLUTY <= string("KiKxPDjOPnnJcQccmUEnruhAJVJrwTOEcJQsAXRDJ")) {
        for (int elydaVF = 1071478158; elydaVF > 0; elydaVF--) {
            cWChewSQwYMiq *= cWChewSQwYMiq;
            cWChewSQwYMiq /= cWChewSQwYMiq;
            cWChewSQwYMiq -= cWChewSQwYMiq;
            cWChewSQwYMiq = cWChewSQwYMiq;
            cWChewSQwYMiq += cWChewSQwYMiq;
            pVQytvYyNLUTY += pVQytvYyNLUTY;
            pVQytvYyNLUTY = pVQytvYyNLUTY;
        }
    }

    return -160168700;
}

double FgnMLkeRjNbrAsW::DToADpaHSSi()
{
    int IhYYeDYIPP = 563922948;
    bool AXEjPvjm = true;
    int rjccRuuqqqPCRKui = -365508759;
    double QAqsrF = 564097.4048750307;

    for (int GvlEGYii = 1248406625; GvlEGYii > 0; GvlEGYii--) {
        continue;
    }

    return QAqsrF;
}

double FgnMLkeRjNbrAsW::paaIHjROSGZfpk(bool quZqIWXHHDavH, double ZYWAvUZHTyNy)
{
    double FIhyhjiP = -344295.38808509585;
    bool KwmBmgVhnD = false;
    int iRejoyGrmqVZW = -1659095030;
    double WIjoYLmskbGtWFf = -547422.3494239037;
    bool daPQaOhINtrBlGMh = false;
    string bUMOAIjeZj = string("ThAlesJLCpdxcvMLceYOiiKizxLcLEbEAivRvlIsihJQTgiFFhPtpvzAMDzGUPjbPPDpmhhTKpoOIJuIOPIeeTaCwXybQhXJTmCdsFlJccIoTtWLbpVpQIWwqgtmqquJKExgwFDgSHpxVAlnrZfKiJTchzgwSELovXyTCgbeTXpRGCKGaOzZIytrkyOkhUINFWvLcxjTWBZo");
    int AcVwVeYSTguSM = -1158228779;
    int bzPOuZKNcnxr = -1196874660;
    double GByYS = 223043.39937718253;
    string jkwSSqSYVylb = string("dYKsTaWCfFACemecTkcvuyOVIapxnChLRhsynhVeqehMPPuImobBpXVBYigXcnyxgNhUVQRRLCZbTLYvSOVsCQBuUVhyenLKjkoGFQJFaVtkQfMipjVvSPYjcDQdAWxGVt");

    for (int NuJMAairgBo = 302745425; NuJMAairgBo > 0; NuJMAairgBo--) {
        FIhyhjiP += FIhyhjiP;
        iRejoyGrmqVZW /= bzPOuZKNcnxr;
        quZqIWXHHDavH = daPQaOhINtrBlGMh;
    }

    if (jkwSSqSYVylb > string("dYKsTaWCfFACemecTkcvuyOVIapxnChLRhsynhVeqehMPPuImobBpXVBYigXcnyxgNhUVQRRLCZbTLYvSOVsCQBuUVhyenLKjkoGFQJFaVtkQfMipjVvSPYjcDQdAWxGVt")) {
        for (int qVtGArBMovzNOS = 1137406070; qVtGArBMovzNOS > 0; qVtGArBMovzNOS--) {
            ZYWAvUZHTyNy *= FIhyhjiP;
        }
    }

    if (KwmBmgVhnD == false) {
        for (int yDeMJ = 1219768302; yDeMJ > 0; yDeMJ--) {
            FIhyhjiP += ZYWAvUZHTyNy;
        }
    }

    for (int SvERlkbUTGUB = 1597615875; SvERlkbUTGUB > 0; SvERlkbUTGUB--) {
        FIhyhjiP /= WIjoYLmskbGtWFf;
        iRejoyGrmqVZW *= AcVwVeYSTguSM;
        WIjoYLmskbGtWFf -= WIjoYLmskbGtWFf;
    }

    return GByYS;
}

FgnMLkeRjNbrAsW::FgnMLkeRjNbrAsW()
{
    this->LfhnjL(string("pvdUmHcnfOlBdkJKLaVHaLJUuYNOxkVGhdFfRTCiKZqTgnoPJbGHKktOELiDCwBvgRRrDsCDqSaagZRDXpgIrUzvsZpPOi"), true, false, -661185.5459825905);
    this->NejRhBodzovsscTN(688133910, true, -826336.9446659457);
    this->fAwdOMOV(-866634.1068696114, -691018087, 798264.5983882453, 1060466891);
    this->nQbJXTSdHphAuT(903789112, true, 1024774732);
    this->OyXMtuGEHlMFAnLU(string("WFIfCvlqGRESZLMPIYrvLxzLoTKLwebPfUDeCWiDaEbqFiEbHhtjmNSeGjoPWMhtBlnXAMLYNEzjrfgbXJnxxxHFhWgpTvJVwLSuOFfiyjldZwZfFAktCAObFhuguIOBgcDInR"), -617254074);
    this->QeFxopukpcqBFj();
    this->DToADpaHSSi();
    this->paaIHjROSGZfpk(false, 864633.8072311998);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MBPiYloVCIY
{
public:
    int YeGxXBYQr;

    MBPiYloVCIY();
    int yIUiGMBRPvFEy(int vJLclHy, double hLxSMLR, double ahyuUSxiZui);
protected:
    int EagacjhswSKP;
    string teCoqMz;

    bool kjgJJTs(string ugYeRd, double HcyItqCQ, int qnjomnoNsZWB);
private:
    double dWzDtOMcKJ;

    string eTLhWZ(int FGyWHtBLFIyMXKqv, string QAKpYOQllBMbc, double kZsfQVC, string IzXUaOyZOVwP, bool XJoVAglVbdU);
    double qvZOpMNjVnWgj(double InefjA, bool BsTntcNvtAtuun, double tIcBiUFC);
    int etSRMMNYBveaU(string XfuBzvnZHHLJAWV, string IUatZbpa, bool ATjnyPTSu, bool HVEesxPZJuEng);
    string vRQePrALeEVZPIs(int eChplGvFKaYWu, int opVYfeZ, double CHMyGZswshOWSBQ);
};

int MBPiYloVCIY::yIUiGMBRPvFEy(int vJLclHy, double hLxSMLR, double ahyuUSxiZui)
{
    bool PkjTpXtUzqZglG = true;
    string UGydGULH = string("JpCUFrVjUoiOrwydKSFeAISfmisfGQPICSeqqfPUWyyLnUlrncFMfXZxoFqmfeKnzb");
    int KoDXyXmGXJJpmnE = 1977997550;

    for (int OReQKYpTZQsRW = 1976348162; OReQKYpTZQsRW > 0; OReQKYpTZQsRW--) {
        KoDXyXmGXJJpmnE += vJLclHy;
        vJLclHy -= vJLclHy;
    }

    if (ahyuUSxiZui >= 338590.43645310437) {
        for (int yvJIyd = 1953567247; yvJIyd > 0; yvJIyd--) {
            vJLclHy -= KoDXyXmGXJJpmnE;
            vJLclHy /= vJLclHy;
        }
    }

    for (int HwrPwu = 2103942018; HwrPwu > 0; HwrPwu--) {
        UGydGULH += UGydGULH;
        KoDXyXmGXJJpmnE /= vJLclHy;
    }

    return KoDXyXmGXJJpmnE;
}

bool MBPiYloVCIY::kjgJJTs(string ugYeRd, double HcyItqCQ, int qnjomnoNsZWB)
{
    bool xhyolS = false;
    string VCnJc = string("wKQAKgepHXpSHpanveaOEsJHcmLhFIpsSAzgSeddTmZobQTEQUVQclIdowlQAxgZJplSfLMoHXPnPvYdXxAOyLTfmYOYDRdSQxwVYXnrwMhKjDvWJUPFfy");
    bool MNXOAUvQLPfiA = true;

    return MNXOAUvQLPfiA;
}

string MBPiYloVCIY::eTLhWZ(int FGyWHtBLFIyMXKqv, string QAKpYOQllBMbc, double kZsfQVC, string IzXUaOyZOVwP, bool XJoVAglVbdU)
{
    int alKEZWaYCdNGo = -464533738;
    string AiiGMILojiGYfg = string("buUNsujXHWiHpMRqmSfOeJzNyxrppJGEbgqPUmMWtWQjAPjaQeTvCeAgljIhQvlLtMErWXELfqGpYFpKvLaKhEhwtLEKeCZeJxmBwcebLHjaDbWubjDGAwWbDKsHZoGwOIFmGdfOcOfnlKkUrKdbijfuxKMYzHaSzbQNPGSbO");
    bool aVsWVDPLiAfpfyM = true;
    string xaXER = string("fmsQEpaQ");
    string ZyczIZYZaPMKpdlX = string("iqzVsAJPJkbPPVaGbjDnZwEFIuWiMruZhtTUKoiuxnShKqpAwPyWJGGcONYdLIebdOsrgzTnzFzaWgYHDGyiWvHiRQSFvqFfpQAhenbPpHGDJoSKrwMvkNMDDxqIWvsLyRlJABZoZgHHrCERDIZZodAPVyFqDzKeGlLLwhnceBHbfRGwJPsyEqDKqSIzziaTwVNoZtpHZrviJsEfRJxIUJEjXRpaOaWCYK");

    if (AiiGMILojiGYfg <= string("fmsQEpaQ")) {
        for (int dLLaJfTcRpGcoD = 696537374; dLLaJfTcRpGcoD > 0; dLLaJfTcRpGcoD--) {
            IzXUaOyZOVwP = IzXUaOyZOVwP;
        }
    }

    for (int RxWaNEfRpBpnyyG = 1311292506; RxWaNEfRpBpnyyG > 0; RxWaNEfRpBpnyyG--) {
        AiiGMILojiGYfg += QAKpYOQllBMbc;
    }

    return ZyczIZYZaPMKpdlX;
}

double MBPiYloVCIY::qvZOpMNjVnWgj(double InefjA, bool BsTntcNvtAtuun, double tIcBiUFC)
{
    double CBtwjXhYdT = 826235.1845793874;
    double smialT = 866211.2257778253;
    string YZfgmzPADjLinAF = string("KpXcAJOMfLdNIeOakJGabOgbebuwkQvuTHxTVJoJwUtSncnwTGxpApNrDyVVgjRnBYWtyJLebDZLXmHMAboslbQRfgeGVylukSxSEADDiVYaufrIfZESlwXedWKnrVzCxBPhJlnpSUKpXCnwajyUaEqFzHxAJyON");

    if (smialT > 866211.2257778253) {
        for (int UsizFTfaJXPmzou = 1873718356; UsizFTfaJXPmzou > 0; UsizFTfaJXPmzou--) {
            CBtwjXhYdT /= CBtwjXhYdT;
            CBtwjXhYdT *= CBtwjXhYdT;
        }
    }

    for (int vniTAbDSZYyD = 1328591181; vniTAbDSZYyD > 0; vniTAbDSZYyD--) {
        tIcBiUFC -= InefjA;
    }

    for (int mNpFiiDKlUqERzLC = 889110209; mNpFiiDKlUqERzLC > 0; mNpFiiDKlUqERzLC--) {
        smialT += CBtwjXhYdT;
        InefjA *= InefjA;
        InefjA -= tIcBiUFC;
        CBtwjXhYdT += smialT;
        CBtwjXhYdT -= CBtwjXhYdT;
        tIcBiUFC *= InefjA;
    }

    for (int wjZSVEXLRelQwL = 1085145564; wjZSVEXLRelQwL > 0; wjZSVEXLRelQwL--) {
        smialT *= smialT;
    }

    for (int ipgIFvuUwJ = 1999991493; ipgIFvuUwJ > 0; ipgIFvuUwJ--) {
        tIcBiUFC /= smialT;
    }

    return smialT;
}

int MBPiYloVCIY::etSRMMNYBveaU(string XfuBzvnZHHLJAWV, string IUatZbpa, bool ATjnyPTSu, bool HVEesxPZJuEng)
{
    double hYuPysDLna = 742827.0534312248;
    string cTSPYmEhQuCCbQzs = string("bFvEnnmAbjwgbaDaNbOlyeEagNmvmbuMzezLCQNOaiHkqbgywsLwmCfqfKBabwJPdhfQWYgkgJpNreMYtWIHAMUDVZJuHvujgXaRMQMBjBpGyoqzSEIZfgFihzdoOuNVxgTzNNxfRmWqKbwuTPFFAMedSakeopCwATheiomyjH");
    int tYOBZKFnBeXcabyB = -1449519091;
    int OqcKOlVmbGo = 465568187;
    int EjdsJcqZDwdjoMyr = 599633078;
    bool tPkxSHZvQqt = true;
    double GHklCna = 750816.0562650313;
    string RPeAYLIutqBZNDu = string("ahVvIDZUVMoqnaCdPnCGVpuHZwCjLiEGApUmcvHsIzPWKRdhoPaTDisKjiBmiLLeIMfAuUmGCuPxQgrqORiJIhbppbsjeqjELDD");
    double qNGJzgAQfbL = -588781.6266574331;

    return EjdsJcqZDwdjoMyr;
}

string MBPiYloVCIY::vRQePrALeEVZPIs(int eChplGvFKaYWu, int opVYfeZ, double CHMyGZswshOWSBQ)
{
    string EaxKtSe = string("iXMZoLIOADxkhgDklHRrTSEWWdTDAxyvurbcVDmQHQujAteqajvLKjxHvUDbJIHSwQAr");
    bool gevgownmgL = false;
    string CTUYBphIqlTP = string("yczjPjSUaDJJtYSBpxVFLzvwkKwjKBtlWvDGAlQWhhCwXxGXyVYqWvIjnpxYVivSqTph");

    if (eChplGvFKaYWu <= -1334618839) {
        for (int xOehWWVAujV = 1203198634; xOehWWVAujV > 0; xOehWWVAujV--) {
            CHMyGZswshOWSBQ /= CHMyGZswshOWSBQ;
            eChplGvFKaYWu *= eChplGvFKaYWu;
            eChplGvFKaYWu += eChplGvFKaYWu;
        }
    }

    for (int dzjOtwabzyjDPbVx = 1072478690; dzjOtwabzyjDPbVx > 0; dzjOtwabzyjDPbVx--) {
        EaxKtSe += EaxKtSe;
        opVYfeZ *= eChplGvFKaYWu;
        EaxKtSe = EaxKtSe;
        gevgownmgL = gevgownmgL;
    }

    for (int VmfOOjRTPUGGCy = 1217935256; VmfOOjRTPUGGCy > 0; VmfOOjRTPUGGCy--) {
        continue;
    }

    for (int bQuTpbzXppc = 36439708; bQuTpbzXppc > 0; bQuTpbzXppc--) {
        eChplGvFKaYWu /= eChplGvFKaYWu;
        eChplGvFKaYWu += eChplGvFKaYWu;
    }

    for (int qWaiVVkuaFNsNX = 298566599; qWaiVVkuaFNsNX > 0; qWaiVVkuaFNsNX--) {
        CTUYBphIqlTP += CTUYBphIqlTP;
        EaxKtSe += CTUYBphIqlTP;
    }

    return CTUYBphIqlTP;
}

MBPiYloVCIY::MBPiYloVCIY()
{
    this->yIUiGMBRPvFEy(591594535, 338590.43645310437, 660230.209455928);
    this->kjgJJTs(string("sJIZRCMlBoeJAeusfLoriUpoODtzgSoetYqfoGmSObVIKJXynoOmJOKHKFhpIsMwmZhzELtQsFBOferaNHpsZlhVQSgtynFzutcUoJraSpRpcBEIxZOAgvxxmpITlyCirMJOPbNdfDkiryFTyBByAWTlYYwZeVWNbEVCmSstaaUzVqzgqgEqeeJIcnQOtQKMDpSGGhGSvpkYkOUlFPWMrW"), -736077.9393766632, 1692146438);
    this->eTLhWZ(-1428167209, string("kRYbACmEhhwMVqGSgjiifgJSwLauCMmnVhImPKWyhTCAKtUJjiABdeSqtxwJPjexUufZYJivTkDJgrClVmmwmGgPGxkhEHCRsvTyfzOWrMHnvljOTJqBDoNCcwalPUaFHYJJUSTOtxByvsxBBntwWodmkOUrmTKRZWEzrJMeDDTk"), 996934.4673686422, string("FZXSCNCzItWGOAAhaXAaEHxHGpXKHCUTvIbGUIpzWkSnweCuidryIdooxEkOiudlIwNtoiHKWROdDgICjUIMvwWicHxmcvwqsYjgnpPoWQcVlZwZjHJjnb"), true);
    this->qvZOpMNjVnWgj(-883860.5056719756, false, -159072.4833461822);
    this->etSRMMNYBveaU(string("tMAQMQGDHqffJRrFaXStwPeFzlNwoBZzoDISFGfQMGHGoNTmdjpbAgjqpKNINKXLgeokAyrDtfENkxDoYxZyidjNtXyeNJzlrZwkEHEmHUxyCjmmCveqdtNAuQgbqYNuxNNaOpgLkHgxYwLfgsKXYYTYluyrLBAzboEIFOEGeGEAgHUsbDefYtUT"), string("sASJHlSJBYvKpYYWWmAWCAiNhxgEWQBHLAbuUUZCoblGBlpxcMJlFiIHxkGTFimcIbaugdwDqQhgtDqpUytTJkOjzRfOnGoLOLCnYhgdHGdduDryUUwZyBmUSLdleRgJaLeHTSkIDjSxfeSRYKxKOasUKPknjbfxMxnQUkMflLBWGvtayHyXpvIKbWBpcowHhuMmoYpeRujRbJYHAxSQsWIgHtWrLByMrKpoaclUY"), false, false);
    this->vRQePrALeEVZPIs(-1334618839, 1816240305, 525812.4409811365);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZTbnCbISBGDrdG
{
public:
    bool SMGtJkyIleyZIHL;
    string eqWxjpohGoxl;
    int TXYXJpMbMHmMHcv;
    string jkCUxCXkFyIBFH;

    ZTbnCbISBGDrdG();
    double zCbhCrFZk();
    bool VPQhCTwhBk(int XioQv, double eKbsflgvU);
    double PPSVSYS(int bZHnBgWSGSSDW);
protected:
    bool PUvGWtCXErZYWX;
    bool cBpnI;

    string iJhqIOrdDgPDbdH(string pNZfmQGRpHIJ, int eDvcqg, int pZrXwPIP, int qilTWZuZki);
    int bkXeWXAdtsnow(int GfbbgoOlTT, string gFUpEzTnhlrzUV);
    void GzyszowrKLBqym(bool BlDkqRiJNdSCUSe, int CTKiZwmBlwsc, bool nDdLenBUyQLwvN, int VFPvzIZ);
    bool VTiomg(bool irkBEdbLzyd, string kTVsgyTCVluqiHAg);
    double xPDiIQyDr(string LTIUcQobNLFDlXE, int smkUeGXQxWbUQrmd);
    double rbKMKTrfISjid(double RTsaV, double jmsYKXWqPiTKOH, bool uOSGSLONErKh);
    void xFOpjF(bool bqWfmGEIY, int QSKrmGS);
private:
    string BaKVKvbNF;
    double hjuUwDO;
    string RYqzUfRFTvw;
    int jEGarpnkkry;

    void VNCegFzwjQ(bool zXogRCEhnruo, double cGZOKKk, double NqCwYDoBXw, int HGsNogAVLTET, double couTCqjok);
    bool GFKwFuJiirxu(double khlgfI, int UbNxffUkjQMxoTWB);
    double QDtSDcXXl(double zRmrYFTALaTwG, int ueKcY, bool AZtEoAoQHb, double qRYumOZLUBNbaH, int ZQZISWKMbSbv);
    double zxhfDVPDe(double jMCGeyW);
};

double ZTbnCbISBGDrdG::zCbhCrFZk()
{
    string VlfoQYSX = string("gMkBqISTrNxyhAdrADFpQYrHeknkkwzaTAOASvpgyduxKWDNPqIhjEwprrmTAMuhQZwGovSTjWXPIFWMjYcKyZhwgAofyRlPYzdlImTGNqTlttyYAvdWzygCXYkVlLGFDyNqTVPxCFEyImzJpSuFrscZuFTgYgnAsRINRINNnuhHeAzIQRDevWOrUysRyjlaKgOvGPztPbDyfUePrClgfLRTDlNDKyYEBpGXdLqzeFfjmRjZTMfFAL");
    string HOmhGuaC = string("WXrIqGtiinASCPHmGTDtBxXJvYrkEsJSqypzkUMDmxnAuQkcGNgGqjMpMblKeMggjPBlvRqKblqbFt");
    int ymVZYl = -183869609;
    bool gGsLHgFPiorEEA = true;
    bool STcdfNw = true;
    string DzFCZeplepa = string("JoHOkyzVidHcyYvYmsSnHJcIPpRmTJuQpgIOGkZjeScvbXxSlbjfyndDkzsDwajeEKvcBIgrZBnJnyMjMfAJVbwgzYHihgIbEJqDuiORKdSDZpIjliAuRKDgzqFtyQMvompHfiyoAyhAF");
    bool ahhaMxoP = false;

    for (int ZOYBTlD = 1270774511; ZOYBTlD > 0; ZOYBTlD--) {
        ahhaMxoP = STcdfNw;
    }

    if (gGsLHgFPiorEEA == true) {
        for (int rRjOoEtBQrdtMHuz = 1866610094; rRjOoEtBQrdtMHuz > 0; rRjOoEtBQrdtMHuz--) {
            gGsLHgFPiorEEA = ! ahhaMxoP;
            STcdfNw = ! ahhaMxoP;
            VlfoQYSX = VlfoQYSX;
        }
    }

    return -725882.7838125998;
}

bool ZTbnCbISBGDrdG::VPQhCTwhBk(int XioQv, double eKbsflgvU)
{
    int JtjicxxwAClT = 1876084549;
    string FPchMMYUGqjIjf = string("ulFODoxDsBCkihbnexdMJihBNMSVFIitYRrToetCiCOOtcURCMRHrIejzpSVIczsRW");
    int BiojdDiS = -115799261;
    bool BuaDcOEEclfLktPn = false;
    bool KLbqBBMUHOpfEU = false;
    double TZZxneVy = 433969.7422424321;
    bool QTVcJjMJuhhM = true;
    int MrkcnqsH = 1330927643;

    for (int gtGaGUqdLKdM = 618309952; gtGaGUqdLKdM > 0; gtGaGUqdLKdM--) {
        continue;
    }

    for (int wQFqKFgVCDGH = 1322120213; wQFqKFgVCDGH > 0; wQFqKFgVCDGH--) {
        MrkcnqsH -= JtjicxxwAClT;
    }

    for (int ZTpjVhtSajRnHAA = 1970249276; ZTpjVhtSajRnHAA > 0; ZTpjVhtSajRnHAA--) {
        QTVcJjMJuhhM = ! BuaDcOEEclfLktPn;
        JtjicxxwAClT *= JtjicxxwAClT;
    }

    for (int WqjayvKULDYrntY = 1894012314; WqjayvKULDYrntY > 0; WqjayvKULDYrntY--) {
        MrkcnqsH -= MrkcnqsH;
        QTVcJjMJuhhM = BuaDcOEEclfLktPn;
        XioQv /= XioQv;
    }

    for (int RZhhGvcYoW = 1729909811; RZhhGvcYoW > 0; RZhhGvcYoW--) {
        continue;
    }

    for (int HZkfgeVG = 2136108013; HZkfgeVG > 0; HZkfgeVG--) {
        XioQv /= XioQv;
    }

    return QTVcJjMJuhhM;
}

double ZTbnCbISBGDrdG::PPSVSYS(int bZHnBgWSGSSDW)
{
    string dbPkFQHkhLYwD = string("eUDnBDapjhLhFIzazaCiSiAlMIRCiLAzovBRojFhaLavkLbBjFAjgXNnSUBhpDIDivcTVXHBtdcfczWCBLfACVgGrBnCPIBHxQFDWioKjdMDjoPUXtUrtMcDilZFOWMLmbCvHyKwTueIlZsEyfPlasHVxwEKzSngvxkRLauuKFKFlKmvpaNPwtAuGnQPHFYyvsnWnwnvYZPXmIBUkzzJqtpaFiuBUPIDWMaDuNrayLMGOUiUC");
    double TdApLVtluytJ = -35240.43164208599;
    double tNBgFSD = -987042.7181195269;

    for (int kzkizWxzZvQMGMYU = 1312160941; kzkizWxzZvQMGMYU > 0; kzkizWxzZvQMGMYU--) {
        tNBgFSD *= TdApLVtluytJ;
        TdApLVtluytJ /= tNBgFSD;
        tNBgFSD = tNBgFSD;
    }

    return tNBgFSD;
}

string ZTbnCbISBGDrdG::iJhqIOrdDgPDbdH(string pNZfmQGRpHIJ, int eDvcqg, int pZrXwPIP, int qilTWZuZki)
{
    bool cKYztylx = false;
    bool BDmPSILwPIvkQrd = false;
    int jxuplqp = -848309187;
    double asZvQn = 962837.5959395482;

    for (int AfDkLMpaHmD = 1467884515; AfDkLMpaHmD > 0; AfDkLMpaHmD--) {
        pNZfmQGRpHIJ = pNZfmQGRpHIJ;
    }

    if (pZrXwPIP != -37590229) {
        for (int lNpLAiJPKrNTX = 1063278483; lNpLAiJPKrNTX > 0; lNpLAiJPKrNTX--) {
            cKYztylx = BDmPSILwPIvkQrd;
        }
    }

    if (BDmPSILwPIvkQrd == false) {
        for (int wzhrVrnHiVKMgebc = 1858232995; wzhrVrnHiVKMgebc > 0; wzhrVrnHiVKMgebc--) {
            pZrXwPIP *= jxuplqp;
            qilTWZuZki -= eDvcqg;
        }
    }

    return pNZfmQGRpHIJ;
}

int ZTbnCbISBGDrdG::bkXeWXAdtsnow(int GfbbgoOlTT, string gFUpEzTnhlrzUV)
{
    bool wEGEKcwL = false;
    string PJdkEMojn = string("veScWXVTzZEmAdEylFWCswulbsXaRqUIcCMIQCmcdIJsvcqtWfjfSLSOdChrevlTYxIjuciVMFblNqIVcsCXgYCGpTWdomLoGyHjUWPeuAiVzsgaRLwGlDHHWnbNXwyVeAdjEWOHNSvVUPyQkYmVSIQodCmxawPtIQlfiCwhgGPJvKYEEXVUuCM");
    string pdbMk = string("kwqCqRDYjAdQGMWGkhTTAqzFoemLsQLBGUBUWuOuxTrvvNr");
    double UFGiObzJy = 220832.18259758133;
    bool bOwiVYhnLnX = true;
    string hkPCzenCjg = string("XjGcjVATqjqfuxLmMXrIOqMlrFDUJDJeUafeCqXBJRQvfXFKYPZYMABYjUszwVIOOymfcZXWgHtIqNXvkhlMEMcWIUEdnXHwPYHqkhbfDwofJuITxuJtPoWXFdRDCtLPyHScyptPrVLHMAUqVHitXPLeNxCAYcpXZcgCrNBfecMZhKUYgDwlFbLxiRvlrACeugkqyOQKIfnPsoqrchcaPGulvnxZJQYCvKpfR");

    if (hkPCzenCjg < string("XjGcjVATqjqfuxLmMXrIOqMlrFDUJDJeUafeCqXBJRQvfXFKYPZYMABYjUszwVIOOymfcZXWgHtIqNXvkhlMEMcWIUEdnXHwPYHqkhbfDwofJuITxuJtPoWXFdRDCtLPyHScyptPrVLHMAUqVHitXPLeNxCAYcpXZcgCrNBfecMZhKUYgDwlFbLxiRvlrACeugkqyOQKIfnPsoqrchcaPGulvnxZJQYCvKpfR")) {
        for (int VjhREgITbpA = 490303841; VjhREgITbpA > 0; VjhREgITbpA--) {
            continue;
        }
    }

    for (int pGVvTnYoUNTIhEdG = 2117194565; pGVvTnYoUNTIhEdG > 0; pGVvTnYoUNTIhEdG--) {
        pdbMk += gFUpEzTnhlrzUV;
        pdbMk += pdbMk;
        pdbMk += pdbMk;
        bOwiVYhnLnX = ! bOwiVYhnLnX;
        bOwiVYhnLnX = wEGEKcwL;
        hkPCzenCjg = pdbMk;
        wEGEKcwL = wEGEKcwL;
    }

    if (PJdkEMojn >= string("kwqCqRDYjAdQGMWGkhTTAqzFoemLsQLBGUBUWuOuxTrvvNr")) {
        for (int TKkVXiNw = 842290305; TKkVXiNw > 0; TKkVXiNw--) {
            pdbMk += PJdkEMojn;
            gFUpEzTnhlrzUV = hkPCzenCjg;
            gFUpEzTnhlrzUV += PJdkEMojn;
            bOwiVYhnLnX = wEGEKcwL;
            bOwiVYhnLnX = ! bOwiVYhnLnX;
        }
    }

    return GfbbgoOlTT;
}

void ZTbnCbISBGDrdG::GzyszowrKLBqym(bool BlDkqRiJNdSCUSe, int CTKiZwmBlwsc, bool nDdLenBUyQLwvN, int VFPvzIZ)
{
    string KgFPHjRHxllFuIF = string("PAUlZXmWZkgSnHXCZAAsNCJXcaqZbybohMpMIaPqJbJRyfbTZCdSBdzserauUqdiQXvbMzZJnnSzDYLTmyliUpfzeZjkHtAWYXTOdIhQeHEquoVVCQpnrmjUIpidkyWdGpTDcGwShpfcHzBBkvnJvftdgi");

    for (int OGeExxpiqzQiQJpx = 299952536; OGeExxpiqzQiQJpx > 0; OGeExxpiqzQiQJpx--) {
        BlDkqRiJNdSCUSe = ! BlDkqRiJNdSCUSe;
    }

    for (int UpcZcf = 735718289; UpcZcf > 0; UpcZcf--) {
        VFPvzIZ = VFPvzIZ;
        VFPvzIZ = VFPvzIZ;
        nDdLenBUyQLwvN = ! BlDkqRiJNdSCUSe;
        nDdLenBUyQLwvN = ! nDdLenBUyQLwvN;
        BlDkqRiJNdSCUSe = ! nDdLenBUyQLwvN;
    }
}

bool ZTbnCbISBGDrdG::VTiomg(bool irkBEdbLzyd, string kTVsgyTCVluqiHAg)
{
    int oMrkMg = 1957493280;
    bool VfKHNkIKzW = true;

    if (irkBEdbLzyd == false) {
        for (int pwpltUYJLs = 1660814528; pwpltUYJLs > 0; pwpltUYJLs--) {
            VfKHNkIKzW = ! VfKHNkIKzW;
        }
    }

    if (VfKHNkIKzW != false) {
        for (int efkFdIzFEf = 560466048; efkFdIzFEf > 0; efkFdIzFEf--) {
            oMrkMg += oMrkMg;
        }
    }

    if (irkBEdbLzyd != false) {
        for (int pqBkQa = 217579666; pqBkQa > 0; pqBkQa--) {
            VfKHNkIKzW = VfKHNkIKzW;
        }
    }

    if (VfKHNkIKzW != true) {
        for (int AvvnU = 1483184482; AvvnU > 0; AvvnU--) {
            irkBEdbLzyd = ! VfKHNkIKzW;
            oMrkMg = oMrkMg;
        }
    }

    return VfKHNkIKzW;
}

double ZTbnCbISBGDrdG::xPDiIQyDr(string LTIUcQobNLFDlXE, int smkUeGXQxWbUQrmd)
{
    bool pUdJNtkSHIiRpUkg = true;
    int pXxhssdEQxDXixv = -1925775087;
    int VyDltpdclqmXYFJ = -381548283;
    int RlAGFeMMMZuBCG = -1152287294;
    double eWitZYOXtai = -1004226.1105233697;
    bool LlrslJpec = false;
    int rfhMibDRdjFtdOwy = 1007332127;
    int qvyHbszOmdhF = 462158233;
    bool kBTyqdk = true;
    string KbOTsK = string("gmmDcauOAPSRlVnfdKSHkvOZWJbnyluylUcOCQeQqRgYgGXsJPHSpDiOXZuKPjGkOajYQAxiipuviuXlYITVnBggEjfrCrEIOzHzZWyfdbChWZIVUlvfwDqbHYTvepFGwZLX");

    for (int VujvibJMCdni = 1259556755; VujvibJMCdni > 0; VujvibJMCdni--) {
        pUdJNtkSHIiRpUkg = LlrslJpec;
        kBTyqdk = ! LlrslJpec;
        pXxhssdEQxDXixv = qvyHbszOmdhF;
        eWitZYOXtai += eWitZYOXtai;
    }

    return eWitZYOXtai;
}

double ZTbnCbISBGDrdG::rbKMKTrfISjid(double RTsaV, double jmsYKXWqPiTKOH, bool uOSGSLONErKh)
{
    string HBhWBkTIGlWysf = string("XoHbKFsZKcwxNmoDTrMIpktOCEMVoVEcPvtHhZjjdnlkREbvTnCBeJocvqFKcskWhKBuwQPHXVcssWIbTQzzmXhBHKhcMFPuHcPtnVqvNINeWAdBczizsbBOJWUbFXAQEqnhWURFTcppLIlaXJxVRwJIUkazFOzSzYJQKxIic");
    string JGoaquwNbF = string("OoIVbaNvJmOAGuibZDCypJKNatYktGnQvkPcujNBNdylCzpDIsEZfDZOmjCgaxgUeCWyujoDSnmrzVbMozPuQpwfkNdgndYvJptFKvATUnEhyPskxTvrJBNlSjDnPVUXesfWLripQoFcjivFfYUrvbSoGuCdGFszwToAAQYpCXurllbggfavmWzixhw");
    double VCnTzZS = 313704.1482965226;
    bool kAYUbzJqJm = true;
    bool wXmXJQg = false;
    double yYKvwftcO = -14314.884486744757;
    double wZfzphqIctbrgd = -138818.0359676357;

    if (uOSGSLONErKh == true) {
        for (int GsBIccVnRmM = 456189582; GsBIccVnRmM > 0; GsBIccVnRmM--) {
            VCnTzZS = yYKvwftcO;
        }
    }

    for (int iyrNhEpU = 1442846948; iyrNhEpU > 0; iyrNhEpU--) {
        wZfzphqIctbrgd *= yYKvwftcO;
        VCnTzZS *= yYKvwftcO;
    }

    for (int FmzcI = 1869305363; FmzcI > 0; FmzcI--) {
        jmsYKXWqPiTKOH -= RTsaV;
        wXmXJQg = kAYUbzJqJm;
        yYKvwftcO *= RTsaV;
    }

    return wZfzphqIctbrgd;
}

void ZTbnCbISBGDrdG::xFOpjF(bool bqWfmGEIY, int QSKrmGS)
{
    bool IzkOnF = true;
    bool cXvPVBBRL = true;
    string uoZTvUBmsk = string("YXlCYYcMnFVhFGYbymduqShpOmMXDxuPiXHGgMbUyUEuHeXfL");
    bool rKbJA = false;
    int nSFfbeQ = -1602779560;
    int JtctifSAbNSCbLDN = -510676692;
    bool SrWqwwzevZBjJa = true;

    for (int RcKJDYlyNfRbAC = 139376009; RcKJDYlyNfRbAC > 0; RcKJDYlyNfRbAC--) {
        rKbJA = IzkOnF;
        IzkOnF = ! cXvPVBBRL;
        IzkOnF = cXvPVBBRL;
        bqWfmGEIY = bqWfmGEIY;
        IzkOnF = SrWqwwzevZBjJa;
        SrWqwwzevZBjJa = IzkOnF;
        cXvPVBBRL = IzkOnF;
    }

    if (SrWqwwzevZBjJa != true) {
        for (int PlMBqZmLpQOcTXh = 2006966592; PlMBqZmLpQOcTXh > 0; PlMBqZmLpQOcTXh--) {
            cXvPVBBRL = ! rKbJA;
            cXvPVBBRL = SrWqwwzevZBjJa;
        }
    }

    for (int pcXiZERADqsUZJg = 839856192; pcXiZERADqsUZJg > 0; pcXiZERADqsUZJg--) {
        rKbJA = ! IzkOnF;
        rKbJA = ! IzkOnF;
    }

    for (int NmIJLdB = 987758369; NmIJLdB > 0; NmIJLdB--) {
        SrWqwwzevZBjJa = ! SrWqwwzevZBjJa;
        SrWqwwzevZBjJa = bqWfmGEIY;
    }

    for (int GeOTBkiFV = 1213876264; GeOTBkiFV > 0; GeOTBkiFV--) {
        JtctifSAbNSCbLDN += nSFfbeQ;
        SrWqwwzevZBjJa = ! bqWfmGEIY;
        SrWqwwzevZBjJa = rKbJA;
    }

    for (int WEMePSleplS = 1519560980; WEMePSleplS > 0; WEMePSleplS--) {
        continue;
    }
}

void ZTbnCbISBGDrdG::VNCegFzwjQ(bool zXogRCEhnruo, double cGZOKKk, double NqCwYDoBXw, int HGsNogAVLTET, double couTCqjok)
{
    bool YgKTpnPTlR = true;
    bool yRcxvfuQCltbwEBL = true;
    double zhCYquVUG = -122467.80299684888;

    for (int aCXpgFywK = 1262556799; aCXpgFywK > 0; aCXpgFywK--) {
        yRcxvfuQCltbwEBL = zXogRCEhnruo;
        YgKTpnPTlR = zXogRCEhnruo;
        zXogRCEhnruo = zXogRCEhnruo;
    }

    for (int RlcHGGvUiIhel = 529064773; RlcHGGvUiIhel > 0; RlcHGGvUiIhel--) {
        zXogRCEhnruo = ! yRcxvfuQCltbwEBL;
        NqCwYDoBXw /= NqCwYDoBXw;
    }
}

bool ZTbnCbISBGDrdG::GFKwFuJiirxu(double khlgfI, int UbNxffUkjQMxoTWB)
{
    double ECLSvsLaE = 319327.9501265364;
    string HMhRatviHByiHXH = string("MqZgWmRwegIYjxFWOtqEPrkVhCExgWhIhzXPfvmdIyUncpOKzWRpLMyOrAHyDrxfgLMUHuNgFlUgGPMppZJyFSQOEFAXQFCDMrfowOSTkJmhmkxLxuFkXCMZNJhYvKsVkzOdzKGqahVbqdTCczoZFmIBIquyYLXBfykaQkahqwfmJIaefzYFRvAYP");
    string rJVuofOAMxuNfWuh = string("TvcwmbOsHjQmzuembrTzVsWIbgIBthVlyUIxMmQswZvWNgLLNmBNWLRemcVhQKrShMgpHOoGDhXpdHRzpDtKQhuhOHrFSsPBziTubgQbzVeKSygPsKP");
    bool oBIabwNoWK = false;
    double NtbAcFXtaEY = 893940.2405488533;
    string JpuIgP = string("jDKrcDetgcmwfuBWnKzbbpuVslLcasFUgNSKxYJKaZwKCIeqGPqSFemrhFsSUtEyEBhAyIiXjdgFWduZkNEmcPRffYyQwaGcuXxGyvKYncVDZngHEBJbCLXCrNaYdunsClRyYpbEzNEZqblpUsAOPtyTrGIYuGWLulPtLxIfYUxMfhheDFAqMyBwmNpDBGzFgvhCJbdyDkcBaNdZsKjpwTwExWEsApLH");

    for (int FNEfbCBdMrfm = 1080981091; FNEfbCBdMrfm > 0; FNEfbCBdMrfm--) {
        continue;
    }

    for (int LkEwjqzVgKVVeqpS = 275816691; LkEwjqzVgKVVeqpS > 0; LkEwjqzVgKVVeqpS--) {
        JpuIgP += HMhRatviHByiHXH;
    }

    for (int EvXSTQSYxwlI = 558884412; EvXSTQSYxwlI > 0; EvXSTQSYxwlI--) {
        khlgfI -= khlgfI;
    }

    return oBIabwNoWK;
}

double ZTbnCbISBGDrdG::QDtSDcXXl(double zRmrYFTALaTwG, int ueKcY, bool AZtEoAoQHb, double qRYumOZLUBNbaH, int ZQZISWKMbSbv)
{
    bool ZWHOZSZ = true;
    string YUCvcoFjxwJEaCi = string("mwYGafVVzUiVyCVVwUHjBsQfULtouChFBGjtqEvzeuhMMACVJEqgllOqtFoHWNhjloXJsuSnwSMXuAgUoyZAXOJYIYpvvrFOhPLfnXaFevoQElPWzrpbchmPHagPCeEhJDOCECsmpiMMjIMnVXrElCoyLnfIKyRMAhiOrNpbxzArlryyKjFXMhzyvKdGmGDNVIjrYs");

    for (int VVOpUzPz = 1257095524; VVOpUzPz > 0; VVOpUzPz--) {
        AZtEoAoQHb = ! ZWHOZSZ;
        qRYumOZLUBNbaH -= zRmrYFTALaTwG;
    }

    for (int sVlTrzQoeDEFh = 1783534975; sVlTrzQoeDEFh > 0; sVlTrzQoeDEFh--) {
        ZQZISWKMbSbv += ZQZISWKMbSbv;
    }

    for (int aMBhuFjrPseBnou = 1447257478; aMBhuFjrPseBnou > 0; aMBhuFjrPseBnou--) {
        continue;
    }

    for (int HvDVoQ = 620133346; HvDVoQ > 0; HvDVoQ--) {
        qRYumOZLUBNbaH -= qRYumOZLUBNbaH;
    }

    for (int OEYXNyDeaLIfitz = 758491518; OEYXNyDeaLIfitz > 0; OEYXNyDeaLIfitz--) {
        ueKcY /= ueKcY;
    }

    for (int wqYzP = 1576029141; wqYzP > 0; wqYzP--) {
        continue;
    }

    for (int hgsRs = 1551363308; hgsRs > 0; hgsRs--) {
        continue;
    }

    return qRYumOZLUBNbaH;
}

double ZTbnCbISBGDrdG::zxhfDVPDe(double jMCGeyW)
{
    int WBrcrfeC = -655256961;
    bool uEzsLQzisW = true;
    int KcopgkuLYXM = -433979088;
    double xjvYMGTrO = 897090.8281445546;
    double gnsALzwFyttHH = 41909.24532808828;

    if (gnsALzwFyttHH != 41909.24532808828) {
        for (int PwfvknRcVyhsaZ = 885954262; PwfvknRcVyhsaZ > 0; PwfvknRcVyhsaZ--) {
            continue;
        }
    }

    if (xjvYMGTrO <= 41909.24532808828) {
        for (int fXiBxLF = 897130453; fXiBxLF > 0; fXiBxLF--) {
            uEzsLQzisW = ! uEzsLQzisW;
            WBrcrfeC /= KcopgkuLYXM;
        }
    }

    return gnsALzwFyttHH;
}

ZTbnCbISBGDrdG::ZTbnCbISBGDrdG()
{
    this->zCbhCrFZk();
    this->VPQhCTwhBk(-964280753, 297243.43965853855);
    this->PPSVSYS(-710469205);
    this->iJhqIOrdDgPDbdH(string("uIOCShASaBTdnQqlcUZFjhSoumQIyrsrkTBrOgFUosroxPefwqECetRDvhUHYWjXvCKLbbbZGDIGVoIfFQcvUQWSWYZOVgNtggDpBxPrSeZESoUQlSSRVAcLpzTWcVJFvyTckjlubnYXOvFIEOvFbIgExTHDJxiBcqyMyRaJzWxiylQAWRuwBFjdsgmyUbajrgDmAkxKWaPEweYfvMERjfSgvkNdaFAJWZqtjOakbP"), -37590229, -525811016, -879164544);
    this->bkXeWXAdtsnow(-594107616, string("IonGkAvjHLtIiXXSVxXmyKlENfKzSXCiDACqiaDkiNdvyIzYcyNRpGAtJrCJdlfWBRzNitAjcKOAEdnwxfQMonOAYSQzmUYcrRNqMSgjAgkKmomPHHdaKomQmBgqWHdrPBLnHegTXssqRBRCUIYNnJBxWvJBCzjeSWRUd"));
    this->GzyszowrKLBqym(true, 1431446046, false, -1116775132);
    this->VTiomg(false, string("fiDQEQDbHEdfupkcLkdorHcuFpCdixVsCAMgAIjGwSLgpxIqTxtqWMpZfZfgwjVHUFyYoWUmUOkSorAWwLLVhDXTOCLPsIOxrjcUEztOGRkPDKpGYGpjmGQGShcVbKWOBEFlOhnUkGRbnQWJEqwNUQIDWzAPmYyYwt"));
    this->xPDiIQyDr(string("mwnXw"), -1815102146);
    this->rbKMKTrfISjid(749333.6992120061, 858766.2993441803, false);
    this->xFOpjF(false, 68062201);
    this->VNCegFzwjQ(true, 910803.4652753897, -1008252.4539984107, -1354084509, -747581.587273015);
    this->GFKwFuJiirxu(-659763.0078832353, 734772762);
    this->QDtSDcXXl(-1001652.2730091504, -1582534887, false, 916726.5803009528, 1731170740);
    this->zxhfDVPDe(570976.6488950028);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ytBjNzfblN
{
public:
    int SUEmQFIXwHcYDy;
    bool gNYaOLyATlffinGN;
    bool uOgebllQQxlMf;
    int zZpkxuOi;

    ytBjNzfblN();
    double dKcsOVa();
    double HnuyCqFinOPzJMC(int KeRSJZrwwO);
    int ZiYlLsKHREstPJpY(bool XNJMluWCKgdIq, bool LzWVJpaNBnZojYu, int wAsFQDjRlmbQM);
protected:
    int zIDHKL;
    bool AimwnCh;
    bool CUdlb;
    bool JrzqTsqEjKRQlZM;
    string FmxyckQSpKzP;
    string dQoeb;

    string ZvsQcMJrbDMKSru(double QPxxMaF, double BfqxNIkiYwaD, double lfmPkdWn);
    void tEMRR();
    bool TRbyVGSQKyAcuf(string qAdDzyvOAwLv);
private:
    bool DhDeA;
    string SogwoHENTkSH;
    bool PZBdHIbhSiR;
    int iYWwraZFMpYXBeA;
    bool VZMksiGFszxgr;

    string ubFjsTO();
    double XssqbNF(double cshWQNwxXQyZLAf, string CFFnVez, int eLrrM, int tehHGQSGJGzQvI, double NWAiyKzhvkRT);
    double jslrfB(int IqzWrQQrMsfXOTx, double GDKovbIsHgx, string zLxfVYSsua);
    bool oVQUbxaDrgDV(int wXCVnwtqz, string KaOtOZ, bool hHwSzgStkh);
    void QgwjYgtXF(int vEtMbYrPwwpWAl);
    void OpINBXjLn();
    string azYjVCYdI();
};

double ytBjNzfblN::dKcsOVa()
{
    double XQPGzDwMS = 86715.01614050768;
    double AdARdiH = 249430.20936055953;

    if (AdARdiH < 86715.01614050768) {
        for (int RNPioyaRzH = 1115769831; RNPioyaRzH > 0; RNPioyaRzH--) {
            XQPGzDwMS *= AdARdiH;
            XQPGzDwMS = AdARdiH;
            AdARdiH *= AdARdiH;
            XQPGzDwMS -= XQPGzDwMS;
        }
    }

    if (XQPGzDwMS != 249430.20936055953) {
        for (int uaklRcTmmDGS = 1635951420; uaklRcTmmDGS > 0; uaklRcTmmDGS--) {
            XQPGzDwMS /= XQPGzDwMS;
            XQPGzDwMS += AdARdiH;
            XQPGzDwMS = XQPGzDwMS;
            AdARdiH += AdARdiH;
            AdARdiH *= XQPGzDwMS;
            AdARdiH *= XQPGzDwMS;
            AdARdiH /= XQPGzDwMS;
            AdARdiH -= XQPGzDwMS;
        }
    }

    if (AdARdiH == 249430.20936055953) {
        for (int ePAVVkqEuDjyw = 1026671936; ePAVVkqEuDjyw > 0; ePAVVkqEuDjyw--) {
            XQPGzDwMS *= XQPGzDwMS;
            XQPGzDwMS /= XQPGzDwMS;
            AdARdiH /= AdARdiH;
            XQPGzDwMS += XQPGzDwMS;
            AdARdiH -= AdARdiH;
            XQPGzDwMS = AdARdiH;
        }
    }

    if (AdARdiH < 249430.20936055953) {
        for (int FKqaNpGYpBevRjL = 1219948365; FKqaNpGYpBevRjL > 0; FKqaNpGYpBevRjL--) {
            XQPGzDwMS += XQPGzDwMS;
            XQPGzDwMS *= XQPGzDwMS;
            XQPGzDwMS += XQPGzDwMS;
            XQPGzDwMS /= AdARdiH;
            AdARdiH += XQPGzDwMS;
            AdARdiH *= XQPGzDwMS;
        }
    }

    return AdARdiH;
}

double ytBjNzfblN::HnuyCqFinOPzJMC(int KeRSJZrwwO)
{
    int WChYXkRIJUzBgGIF = -1569971709;
    int khOpYYu = 1194477743;
    double jOavBkOoYWCePW = -780996.0367041955;

    if (WChYXkRIJUzBgGIF >= 1194477743) {
        for (int NzrPugpGR = 1485870649; NzrPugpGR > 0; NzrPugpGR--) {
            WChYXkRIJUzBgGIF = WChYXkRIJUzBgGIF;
            WChYXkRIJUzBgGIF *= WChYXkRIJUzBgGIF;
        }
    }

    if (jOavBkOoYWCePW != -780996.0367041955) {
        for (int FIbRMaRmceLHoGDD = 1177372590; FIbRMaRmceLHoGDD > 0; FIbRMaRmceLHoGDD--) {
            khOpYYu -= WChYXkRIJUzBgGIF;
            KeRSJZrwwO += WChYXkRIJUzBgGIF;
            WChYXkRIJUzBgGIF += WChYXkRIJUzBgGIF;
        }
    }

    return jOavBkOoYWCePW;
}

int ytBjNzfblN::ZiYlLsKHREstPJpY(bool XNJMluWCKgdIq, bool LzWVJpaNBnZojYu, int wAsFQDjRlmbQM)
{
    double abUySMUCeBuplOk = -593448.09923997;
    double vSoyolCvGUTpoRHe = -576754.3275770862;
    string IuvRyqCvwNgQcaI = string("dhqPYnJbYjmqrCJyOGflSke");
    double iOoQbMHuydxNm = 246044.623155597;
    double VNewLDBSAv = 139350.1057596185;
    double iqcjMeHdwFGLKJ = -242687.9172542915;

    for (int OHrDsJBUoOG = 1348004674; OHrDsJBUoOG > 0; OHrDsJBUoOG--) {
        iqcjMeHdwFGLKJ /= VNewLDBSAv;
    }

    if (vSoyolCvGUTpoRHe < 246044.623155597) {
        for (int fflyGnnPUfrCaxnw = 1690288964; fflyGnnPUfrCaxnw > 0; fflyGnnPUfrCaxnw--) {
            vSoyolCvGUTpoRHe /= vSoyolCvGUTpoRHe;
            LzWVJpaNBnZojYu = ! LzWVJpaNBnZojYu;
            vSoyolCvGUTpoRHe = iqcjMeHdwFGLKJ;
        }
    }

    return wAsFQDjRlmbQM;
}

string ytBjNzfblN::ZvsQcMJrbDMKSru(double QPxxMaF, double BfqxNIkiYwaD, double lfmPkdWn)
{
    string NYOwYivCJdsVAY = string("fzgeHpvsMQsJCJcsHxtBDUnbdtOtazooUELUTbvtRIXXTMomPCPUDTEXhFRxzKvWhFMccLevTuRiuPYVWOnLjcWMZiGyZbjTrXXRUGbicIrHWCRDDOSxdUEPYRmodpCvFeBwPlJyGyxancMktIuSviJHONNNpSbJXfTqAZSPElqFwJVBeKUlRztHRmvtsvMbTeaXXsiizQYqQGQmyqRNFRAwOCzHDlvxgcogHinQ");

    if (QPxxMaF > 592394.0618602617) {
        for (int TdeSnjpJpuweUcY = 2041941374; TdeSnjpJpuweUcY > 0; TdeSnjpJpuweUcY--) {
            QPxxMaF *= lfmPkdWn;
            lfmPkdWn = lfmPkdWn;
            lfmPkdWn *= lfmPkdWn;
            QPxxMaF *= lfmPkdWn;
            QPxxMaF /= QPxxMaF;
            NYOwYivCJdsVAY = NYOwYivCJdsVAY;
            lfmPkdWn *= BfqxNIkiYwaD;
            BfqxNIkiYwaD += BfqxNIkiYwaD;
        }
    }

    return NYOwYivCJdsVAY;
}

void ytBjNzfblN::tEMRR()
{
    int nvqbjPbtvewrkb = 1880035128;
    bool GiyavSQqBhm = false;
    bool RBFGwDEVz = false;
    int QheQheZWqEeFdFJ = 1947118873;
    int YeeRdQQgccUzotw = 959883100;

    if (QheQheZWqEeFdFJ == 1880035128) {
        for (int xxFBZiyJSDMmkq = 234464134; xxFBZiyJSDMmkq > 0; xxFBZiyJSDMmkq--) {
            nvqbjPbtvewrkb *= QheQheZWqEeFdFJ;
            YeeRdQQgccUzotw += nvqbjPbtvewrkb;
            QheQheZWqEeFdFJ /= YeeRdQQgccUzotw;
            YeeRdQQgccUzotw = QheQheZWqEeFdFJ;
        }
    }
}

bool ytBjNzfblN::TRbyVGSQKyAcuf(string qAdDzyvOAwLv)
{
    bool YRmPwn = false;
    bool KScESlxFCdRe = false;
    int VLcCZWZgmGM = 1511297481;

    for (int xzneq = 31156561; xzneq > 0; xzneq--) {
        VLcCZWZgmGM -= VLcCZWZgmGM;
    }

    for (int cRXhiFhcEGtDay = 1264669471; cRXhiFhcEGtDay > 0; cRXhiFhcEGtDay--) {
        YRmPwn = KScESlxFCdRe;
    }

    return KScESlxFCdRe;
}

string ytBjNzfblN::ubFjsTO()
{
    double SOdUAoxGKPeBih = 657311.9845166183;
    bool NVkzv = true;
    int lOVjAdz = 1981503930;
    string FBXWhNPoFaLZyY = string("SOZMDDrASWYzbiYYZiCwdpzZddcJwqBvqIargFxXblObHiWxkURSX");
    bool gWZIKvYKrWII = false;
    bool IzQXcyc = true;
    bool okEILDyirQkDMB = false;
    int kHYdPdNsHhReBz = -988559499;
    string vtdprQwxw = string("nPtpZzDpggA");

    for (int KqgLBNlw = 963397301; KqgLBNlw > 0; KqgLBNlw--) {
        gWZIKvYKrWII = IzQXcyc;
        IzQXcyc = gWZIKvYKrWII;
        kHYdPdNsHhReBz += kHYdPdNsHhReBz;
    }

    for (int hQjdktacXNci = 1514995720; hQjdktacXNci > 0; hQjdktacXNci--) {
        continue;
    }

    return vtdprQwxw;
}

double ytBjNzfblN::XssqbNF(double cshWQNwxXQyZLAf, string CFFnVez, int eLrrM, int tehHGQSGJGzQvI, double NWAiyKzhvkRT)
{
    double niNdLnOtykKTuESn = 606119.383872983;
    bool TBHrMkNyBWh = true;
    int dOdDA = 735689975;

    if (tehHGQSGJGzQvI >= 735689975) {
        for (int EbqYzKSNeQxDfOm = 94495137; EbqYzKSNeQxDfOm > 0; EbqYzKSNeQxDfOm--) {
            NWAiyKzhvkRT += cshWQNwxXQyZLAf;
        }
    }

    for (int SisvhuhrPfdVx = 1497703008; SisvhuhrPfdVx > 0; SisvhuhrPfdVx--) {
        tehHGQSGJGzQvI += dOdDA;
        NWAiyKzhvkRT += NWAiyKzhvkRT;
        eLrrM /= dOdDA;
    }

    for (int yyuVBHxicZzDsd = 511693213; yyuVBHxicZzDsd > 0; yyuVBHxicZzDsd--) {
        continue;
    }

    for (int WGgEnxWZTyibkU = 224332231; WGgEnxWZTyibkU > 0; WGgEnxWZTyibkU--) {
        tehHGQSGJGzQvI *= eLrrM;
        NWAiyKzhvkRT *= NWAiyKzhvkRT;
    }

    for (int wEmhOjxAqo = 647290151; wEmhOjxAqo > 0; wEmhOjxAqo--) {
        niNdLnOtykKTuESn -= cshWQNwxXQyZLAf;
        niNdLnOtykKTuESn += cshWQNwxXQyZLAf;
    }

    for (int ffZBaRvmVHI = 1362787816; ffZBaRvmVHI > 0; ffZBaRvmVHI--) {
        NWAiyKzhvkRT -= NWAiyKzhvkRT;
    }

    for (int zNMrObqcwPQeKmkb = 2082620230; zNMrObqcwPQeKmkb > 0; zNMrObqcwPQeKmkb--) {
        continue;
    }

    return niNdLnOtykKTuESn;
}

double ytBjNzfblN::jslrfB(int IqzWrQQrMsfXOTx, double GDKovbIsHgx, string zLxfVYSsua)
{
    bool KMPZMvz = false;
    string ULwPao = string("jvUYHZmmcaEbKctlrNiJUulIeRkYfWXrHhZdOBnzrtDCzzGfQBpzfxEOXVWolUoXmEsOssIxicVuOXpvYdtsooE");
    bool DMZKeJYOjfMDTgT = true;
    string ybNwPzyKnorqUg = string("CsqrzfBrlRYSaIQXhRIPPTRVafxjFiXgdoFcpLGGtViNICZCxCjVNYlWFuIzkhJgxQPoEnmPkeLuklQEEBExTes");
    string PKPEEK = string("ItSYmIENzhpWPSqXawKAzMcdEmmDTiJLYGCKTfnAflWIyyxeoBQuRAOqDXBUlKUqSvWBmkxPFiGEFcXHndLiQWwTLuxRdRPWxSDqKPLUCynJdEJLvwPMwIJdXaJIKGlTAUeVzcutAUmjHPMnUeDYViuUleTAcDHDILHrLCMiUvdIqaUKqDPaFzHMwGJIvZqMQXBWyWCxiREFAWwQNICbDtyAGogjcrsXjkWZiJfGsncVcgAeGVCDNLDEzs");

    if (zLxfVYSsua == string("ItSYmIENzhpWPSqXawKAzMcdEmmDTiJLYGCKTfnAflWIyyxeoBQuRAOqDXBUlKUqSvWBmkxPFiGEFcXHndLiQWwTLuxRdRPWxSDqKPLUCynJdEJLvwPMwIJdXaJIKGlTAUeVzcutAUmjHPMnUeDYViuUleTAcDHDILHrLCMiUvdIqaUKqDPaFzHMwGJIvZqMQXBWyWCxiREFAWwQNICbDtyAGogjcrsXjkWZiJfGsncVcgAeGVCDNLDEzs")) {
        for (int MltOpaXAvLa = 760108712; MltOpaXAvLa > 0; MltOpaXAvLa--) {
            ULwPao += ybNwPzyKnorqUg;
            ybNwPzyKnorqUg = PKPEEK;
        }
    }

    return GDKovbIsHgx;
}

bool ytBjNzfblN::oVQUbxaDrgDV(int wXCVnwtqz, string KaOtOZ, bool hHwSzgStkh)
{
    int JoeINR = -677172881;
    int rfDHjvoEbzFbt = -253060287;

    for (int XeHNRMnbfq = 964615935; XeHNRMnbfq > 0; XeHNRMnbfq--) {
        JoeINR += JoeINR;
    }

    if (JoeINR > -677172881) {
        for (int eTtnoWONybMA = 1273574628; eTtnoWONybMA > 0; eTtnoWONybMA--) {
            wXCVnwtqz += JoeINR;
            JoeINR *= rfDHjvoEbzFbt;
            JoeINR -= wXCVnwtqz;
        }
    }

    return hHwSzgStkh;
}

void ytBjNzfblN::QgwjYgtXF(int vEtMbYrPwwpWAl)
{
    string gTEVFPHdd = string("MaOAwLCOeYNVonGrNIlnUvCezwIRFKQRnPDCgrzwqxgKYBamRNOwibiQiFnyXRVafcSCKEnVxFZVgEGUbyHzKAvOOOsmHoMwXpBhYAWbtqEhVQpAEbobjQASBoHoJMTtILTnPgEHyzaCqqHubzPodZvwZsTwfeLMnxENdYKVZqxarxrh");
    int TDDqxdA = -1794452891;

    if (vEtMbYrPwwpWAl < 1393708805) {
        for (int mpKscPFuYKU = 581370561; mpKscPFuYKU > 0; mpKscPFuYKU--) {
            gTEVFPHdd = gTEVFPHdd;
        }
    }

    if (TDDqxdA > -1794452891) {
        for (int GWdCuEDm = 1033783717; GWdCuEDm > 0; GWdCuEDm--) {
            TDDqxdA -= vEtMbYrPwwpWAl;
            TDDqxdA = vEtMbYrPwwpWAl;
            gTEVFPHdd += gTEVFPHdd;
            vEtMbYrPwwpWAl *= TDDqxdA;
        }
    }

    for (int AtJnPqwtWO = 1092916863; AtJnPqwtWO > 0; AtJnPqwtWO--) {
        vEtMbYrPwwpWAl /= TDDqxdA;
        vEtMbYrPwwpWAl += vEtMbYrPwwpWAl;
    }
}

void ytBjNzfblN::OpINBXjLn()
{
    bool QMnrEgrdDi = true;
    int rwbzDeBZXmsra = -264637909;
    int lkRMKqOpnWj = -249982728;
    int RoUIhbjSPOLdX = -559601413;
    string MRCYnUksvvVCs = string("SJPRsclJTJdriJgPtoItCRSmdwYAakdzGfruTNxJSZGoEqFEOIDVDyVCZ");
    double ZJtJXdw = -463026.54076075833;

    for (int TyDrysWLkqzlH = 1906816988; TyDrysWLkqzlH > 0; TyDrysWLkqzlH--) {
        continue;
    }

    for (int fCJwbnemw = 2009984220; fCJwbnemw > 0; fCJwbnemw--) {
        lkRMKqOpnWj -= lkRMKqOpnWj;
        lkRMKqOpnWj *= lkRMKqOpnWj;
    }

    for (int ZLbbG = 1098135020; ZLbbG > 0; ZLbbG--) {
        RoUIhbjSPOLdX += lkRMKqOpnWj;
        lkRMKqOpnWj *= rwbzDeBZXmsra;
        lkRMKqOpnWj = lkRMKqOpnWj;
    }
}

string ytBjNzfblN::azYjVCYdI()
{
    double WkRKQkuqZ = 241616.38761543654;
    bool YAzUQkhQttTmhsbW = true;
    int EPVwBfgJpzhGvI = -569898121;
    int YYmkc = -2058722549;
    string cVQpF = string("MPLMMDNlLynBSXOOBZFKxFQSpxgoxmQIeacZvPDAKPrEyDvFVsrDpFUilqmQfBzJmOjFXAuLvhMPsbInRxewGZSFfrVmbFZwOfigdCqVYxKscKudAXtBCansTUwRvmocjHCewgTWxUePcuTBNIpODCYLDBkpKmkgmbtQgMzDMeywCDxP");
    bool vALCWChKDBAmvGw = true;
    double NAdYo = -382003.8470898945;
    double eHZpreaaF = -838421.9772841283;
    bool bSwxbHXpBhCf = false;
    string Taaik = string("dgGBtfKmMWZlLCOdvwlWdRXLNzVQXdTLWgHnSjyujNnzlTNncmPMjufUiLXSIzYsAjPwdVOdZkbHSXQwuAQAZTqXZlFneqLFaSuCpKhkGtajJUKr");

    for (int VoqFqCkI = 285233698; VoqFqCkI > 0; VoqFqCkI--) {
        NAdYo *= NAdYo;
    }

    return Taaik;
}

ytBjNzfblN::ytBjNzfblN()
{
    this->dKcsOVa();
    this->HnuyCqFinOPzJMC(1487997891);
    this->ZiYlLsKHREstPJpY(true, false, 1011338663);
    this->ZvsQcMJrbDMKSru(-425623.57743131823, -895152.0863554124, 592394.0618602617);
    this->tEMRR();
    this->TRbyVGSQKyAcuf(string("QOKjpgVkRCDxGBIqSNpLjDiYcqkLYlPJcqhLoXkGWQlbWtskeknAxFTdUcBkxtINzCZFeZqvVFEiZcxAGVYDCRTnbMFwplllzyAWkxeGuxSsJsbNGUimnlyhrcOlwdRGJIQebkHSjXHOKUAiLyyPBhiBnsbUzavdRAMshymVREqeYYNPbgCYcxVhDjgBkbMsmqXCqOVRMdRnAvuKO"));
    this->ubFjsTO();
    this->XssqbNF(-958427.8269674891, string("HAvXBiCxEKAxvSThhMVbauPINJskzDTVcGzHQgOCBUCWIjmpg"), 19485933, -1249225045, 323165.71907181566);
    this->jslrfB(-775564972, 294259.63709156186, string("GtxAwFxkqwiZDYQgZwTdPPHXxzFapNuDtULoLBYhHQXSyJdtTndIptYrxOjttlzJxpjHldYjBuFXUEzsblUMiIvNhEaKWDVOJGiMlwehbrXFCtVYeMymEleIHQZgrpvWrZUoWKJaoZeBxNPDxMJAtBwbzIAJZRFjNsaOYknAkLvrxuzFaKawJJQvdjjbVXyjAmBD"));
    this->oVQUbxaDrgDV(154012843, string("MLVljjPobHjDXvyFPWNpCtuElhycPHiysQNFrlAnkPGXiHLKXpLVemphQVvdSCUPeSvoHFbdbpUBefkRlhQhBcWdQfAlmBvgOcKcTQxklGRSROIdKUqOAtZQJtWnhKZrkMTKChBJSVervubkLRIIeZWhDgnpDCooLeFrEAUVUAe"), false);
    this->QgwjYgtXF(1393708805);
    this->OpINBXjLn();
    this->azYjVCYdI();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ILuJtO
{
public:
    string jfrLQCIxoykmRTvL;
    string EJZRU;
    double LXiOoKF;

    ILuJtO();
    string BepTTfSuyC(int DSFReGCscxfnxr);
protected:
    int zaDJomqxy;
    double SSmvL;
    bool hDjDRSf;
    string IRSiTLnzIF;
    double meoWonsSabj;

    double AvwuFaHfOU(string fkNyVVdRpkTDTv);
    int NRNDdqb();
    string LpjLkTuJUhQLqUz(double FBRSdVzIp, string VACtYSfqedDf, double bThMjCnYMTgDn, string qarVbIvqhMtvCr, double kOehudnBOHajExpQ);
    string wahQBMoQHugxW(int KAxFtorLlwvEoRUu, bool nUaDSpF, int RFMPvePpObzq);
    double yoxwDiFbVGs(bool gcFiLcMjxue, string uBjrHBSmf, double QuNPkoqARhAEof, string rqcmP, int iYfejMUhKvNgyaE);
    void nvdQNwHTObKnyX(int mNvpegHMOaeBXh, double VWPgS);
private:
    bool ofudhbPxDsGZ;
    bool PrAoFmQlvB;
    double CtadLMH;
    int tcuhLjmVDj;

    int KfbWnZefo(int HbGfJMqduysnql, bool IpcIdaxHzFvBNTc);
    int CoZbIx(double VKkMGAMliwMNFy, double bPOxNEDyNdQLGg, bool ZkUxmQOIXbQxWi, bool eBFvztVKAxP, int lSUXAeaob);
    bool ouMGquwZp(bool ZNZzYytvw, int DoFEMtYa, int zfZfGQsxigzepjns);
    void IlVXzVRdSOQ(double wPvPZG, bool sElECOd);
    string daGhtKOgKqGJcCC(int JfiOV);
    bool LztlC(bool aeRzxzkwVZPdb, int uzjrJmL, bool pjgmCqVHqSAdInlr, string PPzkNL, bool MJZkSIwfPMvWhvo);
};

string ILuJtO::BepTTfSuyC(int DSFReGCscxfnxr)
{
    double tgvVlNlvPZMK = 118365.43689325849;
    double rZHcIGaEcDWwqMX = -328326.0939739921;
    bool fZUyKBlPwIr = false;
    double JBJDeoogIw = 139543.01825292752;
    string zucgWqpviE = string("pUMmxTTPZNFSMPdsudYlRhfTcQtNJGRqkPTvKildeANRIzVMEVlyMBFxWdNeHjKQyoDlOKSxyeTnEiNzEuuAUbPzVuagetqvFHPEQeqXTvujlYfXEoBUyIEUOsKouxQWUJGWgoHEaQeyAUUnwREyPCGkfxZVqexseBBlIzBZNXLNlAreZVkZa");
    bool TFlnE = true;
    string LjLEnsDVWffFcZN = string("NldJvQZfSWNtORCPglgHszJkvlEZqoCGRLTgmuFSmcdlYtrzfzVAcCbOoQfASkYMXgefSOiUvFBngbdfBvbVUYMseoKCUKCXyOzlULQAJVNCHkbBOLOKffwzVtSvPotgUWLXgKerPizxEfPCpQjDZLcbQRJMnuUFenuNPrhnzwZvdyzRvmPpSjdDiCUbkaQcvMuEwxjNNDkjRwRRWOHfMStReQdCObbxfrgIDRftZonpOJ");
    double Hiuvtri = -563394.1443764034;
    double bGvFmingMtQCx = 273699.8264795943;

    return LjLEnsDVWffFcZN;
}

double ILuJtO::AvwuFaHfOU(string fkNyVVdRpkTDTv)
{
    string VrqnlI = string("cQPOiSTFrozGveJUkZMZxoTornawihFMCmlnPnEFWJnegeIotoufIKuZcxXLMxZyDxMKMGIUOKHAfJsSjVSLSsMMfpiiPwusrTePqyWjsNvRfxIUcoUDJBFXUZdSQRKbLVNHnb");
    double kzhupFalNg = 217439.7248748953;
    string aSEpJQbCt = string("yvwaCRiAmpKkeRVoKqIkdApGeTYLFpCTyroAEpcKDKMteSkgEqnzaVVsOtHFlgaisTfNNrtunfSwVqbtlwzQIAZyGdzMjkqZVmrPkANUWpayoZRxlPLJXMMEQvfXIdpHooENILkPoklqOsYELWXesIxBFpIfCuDnZnfqksw");
    string vIlxEGsaljoqHE = string("ACmGIdVFAFJjVGzrYlXNPdXKukYJSUtQjaQeumYCfuxnsCzLZItYngsKedUhbUBbsfPOlFRvDsAwpccpbjlIytkgfheMAwkCMUJLDoezzspjcxYtajmejPmRWYsBfspMHDeeSJcghyDZoeEwhMMZpNkKzFzokheRVqFfWTAdVByUaDY");
    string PgWBeVSAhCrJFJ = string("GpWUxMwKgIqMYQiNXPXmWyvFgaVxTYfZZLbkoUURvlqVWAlgHsJKpzoDlfuuqGGPRGqePXLONstlZMudfeRNjdOHwXzKdVgvMSbrIOOFtJcRpGJSCMgXiRTArRRnHhbgJfMYnpMzdzffGNEADe");
    string nuvnLFAUT = string("aBHSuIQ");
    int wEpZu = -1691040870;
    double nmAmaIZIGtuH = 472552.68337899656;
    int CruwQluODwGEmiuk = -1664671045;

    if (CruwQluODwGEmiuk < -1691040870) {
        for (int yriJYIbyZFs = 1282530298; yriJYIbyZFs > 0; yriJYIbyZFs--) {
            continue;
        }
    }

    if (nmAmaIZIGtuH <= 217439.7248748953) {
        for (int leoNvICvNaMr = 1195526277; leoNvICvNaMr > 0; leoNvICvNaMr--) {
            nuvnLFAUT += vIlxEGsaljoqHE;
        }
    }

    if (vIlxEGsaljoqHE > string("yvwaCRiAmpKkeRVoKqIkdApGeTYLFpCTyroAEpcKDKMteSkgEqnzaVVsOtHFlgaisTfNNrtunfSwVqbtlwzQIAZyGdzMjkqZVmrPkANUWpayoZRxlPLJXMMEQvfXIdpHooENILkPoklqOsYELWXesIxBFpIfCuDnZnfqksw")) {
        for (int vXIjEWZFmo = 423706947; vXIjEWZFmo > 0; vXIjEWZFmo--) {
            aSEpJQbCt = fkNyVVdRpkTDTv;
        }
    }

    return nmAmaIZIGtuH;
}

int ILuJtO::NRNDdqb()
{
    int lgtwBfJnZ = 1260455037;
    int XJDEQcbUCVJqmvuv = 2143350245;
    bool vUlCkFw = false;
    bool kUKkXQmWwh = false;
    bool OLdOUpZOLTq = false;
    int BPaybiexYM = -1169627540;
    string KqNtJGtzPnr = string("rhLJcQFvVcAfZBptdyHWJIYYOEskrgvgkwYKoadNizLhXbidoYsmSgRhnbaUBJSozyRjHwvmlCgAkekslliEesypkcxeSXGftQUNiPcJBvrMGCTXrsfBDzDSlUapievjQGCjcpqGaMvzxZRdTJiSETGRxWSGCWzVFAbMRHAUkgRJXhvJssFEZxIgRYKGTMSsEpQxKKYuwXVcVBaKgHKOnCjaVKKLgoerWWbYaQXQXcYUPQBkgUpawCjjBolcp");

    if (lgtwBfJnZ <= 1260455037) {
        for (int zHuuQPJJjy = 2119214071; zHuuQPJJjy > 0; zHuuQPJJjy--) {
            kUKkXQmWwh = vUlCkFw;
            kUKkXQmWwh = ! vUlCkFw;
            XJDEQcbUCVJqmvuv /= XJDEQcbUCVJqmvuv;
        }
    }

    for (int LHloJfwrcNtuln = 1958725407; LHloJfwrcNtuln > 0; LHloJfwrcNtuln--) {
        OLdOUpZOLTq = vUlCkFw;
        lgtwBfJnZ += lgtwBfJnZ;
        kUKkXQmWwh = ! OLdOUpZOLTq;
    }

    for (int gEXrHgxXWcpZJho = 1434633731; gEXrHgxXWcpZJho > 0; gEXrHgxXWcpZJho--) {
        continue;
    }

    for (int sNvPf = 1401636918; sNvPf > 0; sNvPf--) {
        vUlCkFw = kUKkXQmWwh;
        lgtwBfJnZ = XJDEQcbUCVJqmvuv;
        kUKkXQmWwh = OLdOUpZOLTq;
        XJDEQcbUCVJqmvuv += XJDEQcbUCVJqmvuv;
    }

    return BPaybiexYM;
}

string ILuJtO::LpjLkTuJUhQLqUz(double FBRSdVzIp, string VACtYSfqedDf, double bThMjCnYMTgDn, string qarVbIvqhMtvCr, double kOehudnBOHajExpQ)
{
    string ZSrMGiK = string("povuYoIAjCpHqpiqiWxUjOeLymWrZwszPuvnXmXlLKVHnCisfSrOgieZCKTeJZVypgwUEOOXLjPJHcscJPXEPFWR");
    string nWOSQfg = string("bJdXTccewKgiAtaBkdjTkqsFHDYxXcnrsZblWPlOxsBosvvK");

    if (nWOSQfg <= string("aBqsUkxxdOUOCzofEfdWYvKDHHuJioTFkRSQNXpbsHIelfiiJzYECfUECepkUcbFCMLemxOsQaGmocNHUsCtTheiLqmYsVmituzFAMhCeSYiaUDFUJmAgomaivcUgGlTcxSLFvLaYioJTYsZCqHNkogXrEUjInfRWkOytMAEIuknqLfqIXjp")) {
        for (int nyBvnnzVdOYFtodA = 518835943; nyBvnnzVdOYFtodA > 0; nyBvnnzVdOYFtodA--) {
            kOehudnBOHajExpQ -= bThMjCnYMTgDn;
            ZSrMGiK = nWOSQfg;
        }
    }

    if (ZSrMGiK == string("povuYoIAjCpHqpiqiWxUjOeLymWrZwszPuvnXmXlLKVHnCisfSrOgieZCKTeJZVypgwUEOOXLjPJHcscJPXEPFWR")) {
        for (int UQJImtg = 822662590; UQJImtg > 0; UQJImtg--) {
            nWOSQfg += ZSrMGiK;
        }
    }

    for (int lbwYBDLVaDNw = 441849252; lbwYBDLVaDNw > 0; lbwYBDLVaDNw--) {
        qarVbIvqhMtvCr += ZSrMGiK;
        VACtYSfqedDf += VACtYSfqedDf;
    }

    return nWOSQfg;
}

string ILuJtO::wahQBMoQHugxW(int KAxFtorLlwvEoRUu, bool nUaDSpF, int RFMPvePpObzq)
{
    double QpGQs = -641112.892447638;
    bool MHdLnq = true;
    string VvpJlxchwOpq = string("ugSygrsmSJyuCavOwdkMNquWOTiHWjfBuimxSvwkTyYMsCpQoKMXbsgtWBVJmTNZntUEtXInGwwGZRBVbQCKgDrkhOcdjIcNShmpQARTigJXiNbmMQguRsudvgGIQLlxxBWKGhsVTkSsPCBtpADUPRgNxbEQAKtxKdicGL");
    string TnheHgniYYuVZmv = string("Jk");
    string sQYfdNocHlJo = string("VBiVrgHywzlMpGCbqqXIQBOejtkfEEAnuFhnLjJLEkxF");
    string CKtuEtdBxA = string("GjudpyAjzzrPMgeHtEiCiukCjgSdnlQWYMhucJeyNLLWSdcTTblxFRKscxsQeELuAIQLakXjNMzLUgqCVedAECSPvrDEqjPvHtLpquewVEuiosIYsPHXQkjtqxOlENxefpGALL");

    for (int xSUuqLjtajnKj = 1681014387; xSUuqLjtajnKj > 0; xSUuqLjtajnKj--) {
        CKtuEtdBxA = VvpJlxchwOpq;
        nUaDSpF = ! nUaDSpF;
    }

    return CKtuEtdBxA;
}

double ILuJtO::yoxwDiFbVGs(bool gcFiLcMjxue, string uBjrHBSmf, double QuNPkoqARhAEof, string rqcmP, int iYfejMUhKvNgyaE)
{
    bool XBxKtMJyQbvUeV = false;
    bool ZksvlGBpma = true;
    double NrheLrXZXyYie = 14636.649514248622;

    for (int tCqxK = 222883460; tCqxK > 0; tCqxK--) {
        XBxKtMJyQbvUeV = gcFiLcMjxue;
    }

    if (QuNPkoqARhAEof < 14636.649514248622) {
        for (int BysBjTUfBrSKkr = 1851374314; BysBjTUfBrSKkr > 0; BysBjTUfBrSKkr--) {
            QuNPkoqARhAEof /= NrheLrXZXyYie;
            gcFiLcMjxue = ZksvlGBpma;
            gcFiLcMjxue = gcFiLcMjxue;
            gcFiLcMjxue = XBxKtMJyQbvUeV;
            QuNPkoqARhAEof = NrheLrXZXyYie;
        }
    }

    for (int AwJRFaOPKLec = 1136550483; AwJRFaOPKLec > 0; AwJRFaOPKLec--) {
        uBjrHBSmf = rqcmP;
        uBjrHBSmf += rqcmP;
        uBjrHBSmf += rqcmP;
        XBxKtMJyQbvUeV = ZksvlGBpma;
        iYfejMUhKvNgyaE *= iYfejMUhKvNgyaE;
        gcFiLcMjxue = gcFiLcMjxue;
    }

    return NrheLrXZXyYie;
}

void ILuJtO::nvdQNwHTObKnyX(int mNvpegHMOaeBXh, double VWPgS)
{
    double RWphp = -461847.3280683356;
    int EopsvhmflE = -1283718208;
    int ribFTPmpRZurJf = 1424738843;
    bool BLBOyrirLeaG = false;
    string SZqVDviEkDIhG = string("wJBUzkyeQAcWLIyDyMUfMVZzDlAexHyuFpIUoeLqaUPBrqytnKKUTDcarGxcjOqOaDlHIFAseHpcurpPirqTvnGKgsvlsJZZlxJSYlIvXVKcvxHzGJFsIuLsHvsEJAviZFXGVPrIbmZlXgHTSYFgrSbJGfKHAYRGxCYEHnVOOjEuNNGRwJKrdbvcidryqSFyMCGzleUXRGXilIPZAUIMlZvcUbNjrMUZ");
    double OjwMzfijOrYGe = 957533.3048407338;
    double sRMpI = -1000593.293961581;
    bool dCDJCZTfXp = true;

    if (RWphp <= -1000593.293961581) {
        for (int wUlIgNdBEtxL = 1324008784; wUlIgNdBEtxL > 0; wUlIgNdBEtxL--) {
            RWphp = VWPgS;
            SZqVDviEkDIhG += SZqVDviEkDIhG;
            BLBOyrirLeaG = ! dCDJCZTfXp;
            EopsvhmflE /= ribFTPmpRZurJf;
        }
    }
}

int ILuJtO::KfbWnZefo(int HbGfJMqduysnql, bool IpcIdaxHzFvBNTc)
{
    int iLgRYXDRW = 298757010;

    for (int awffFuNmovbjhcl = 946701011; awffFuNmovbjhcl > 0; awffFuNmovbjhcl--) {
        HbGfJMqduysnql -= iLgRYXDRW;
    }

    if (HbGfJMqduysnql < 298757010) {
        for (int fnkRXuxPLajAzLA = 1972301583; fnkRXuxPLajAzLA > 0; fnkRXuxPLajAzLA--) {
            iLgRYXDRW /= iLgRYXDRW;
            HbGfJMqduysnql -= iLgRYXDRW;
        }
    }

    return iLgRYXDRW;
}

int ILuJtO::CoZbIx(double VKkMGAMliwMNFy, double bPOxNEDyNdQLGg, bool ZkUxmQOIXbQxWi, bool eBFvztVKAxP, int lSUXAeaob)
{
    string bmEeqx = string("nykXhbderdYBbkwwnrrpcWZzsGVpzrKEZmdHzLDhwjEzKKHYDiGTR");
    int BCVbiykKIxEieh = -1023764257;
    string TeyFqVmTtrXVyi = string("OTSzUNzFsCDeENKJBeKpYBPQlLoZEssFWKFCBMOuKoskMBncmFjTYjVNVoljez");
    string jyRzQrTjWgmqBH = string("wDIDAjOHQKaTnDGYBEDqJaKNuQSywHykUhAPhECYThmccSnxKibmO");

    for (int IohUPImxJK = 1648336964; IohUPImxJK > 0; IohUPImxJK--) {
        TeyFqVmTtrXVyi = TeyFqVmTtrXVyi;
        TeyFqVmTtrXVyi += TeyFqVmTtrXVyi;
    }

    return BCVbiykKIxEieh;
}

bool ILuJtO::ouMGquwZp(bool ZNZzYytvw, int DoFEMtYa, int zfZfGQsxigzepjns)
{
    int vuLxgnfIRrZxH = 2119811249;

    if (ZNZzYytvw != true) {
        for (int eYtjkfTGRl = 388723885; eYtjkfTGRl > 0; eYtjkfTGRl--) {
            DoFEMtYa += zfZfGQsxigzepjns;
            ZNZzYytvw = ! ZNZzYytvw;
            vuLxgnfIRrZxH /= zfZfGQsxigzepjns;
            ZNZzYytvw = ZNZzYytvw;
        }
    }

    if (DoFEMtYa > 2100231325) {
        for (int cspndlphd = 1305304575; cspndlphd > 0; cspndlphd--) {
            vuLxgnfIRrZxH /= vuLxgnfIRrZxH;
            DoFEMtYa /= vuLxgnfIRrZxH;
            DoFEMtYa *= vuLxgnfIRrZxH;
            zfZfGQsxigzepjns *= zfZfGQsxigzepjns;
            DoFEMtYa *= DoFEMtYa;
            DoFEMtYa += vuLxgnfIRrZxH;
        }
    }

    if (vuLxgnfIRrZxH != 575383623) {
        for (int hXpLPYPSKl = 1813346275; hXpLPYPSKl > 0; hXpLPYPSKl--) {
            DoFEMtYa += vuLxgnfIRrZxH;
            vuLxgnfIRrZxH += DoFEMtYa;
        }
    }

    return ZNZzYytvw;
}

void ILuJtO::IlVXzVRdSOQ(double wPvPZG, bool sElECOd)
{
    int shOJGTZWnlXCW = -1211874564;

    if (sElECOd == true) {
        for (int vXiyQTnfGNMEiil = 686958631; vXiyQTnfGNMEiil > 0; vXiyQTnfGNMEiil--) {
            continue;
        }
    }

    for (int mDJcnceHiaYMnvdT = 1976761526; mDJcnceHiaYMnvdT > 0; mDJcnceHiaYMnvdT--) {
        continue;
    }
}

string ILuJtO::daGhtKOgKqGJcCC(int JfiOV)
{
    double VjkwJPH = -429718.0463069954;
    string lLcMmPIIrBRtnD = string("QznhklMtgoyeTNwCBsLFcFfrBGKavakUtbTyLDifouYzJFYBEMGJEZwIzby");
    int AzFHfieRBHnXfe = 726470456;

    for (int ivkqHWfPirh = 330208789; ivkqHWfPirh > 0; ivkqHWfPirh--) {
        JfiOV *= JfiOV;
    }

    return lLcMmPIIrBRtnD;
}

bool ILuJtO::LztlC(bool aeRzxzkwVZPdb, int uzjrJmL, bool pjgmCqVHqSAdInlr, string PPzkNL, bool MJZkSIwfPMvWhvo)
{
    double kslGAIGOAmRaB = -11511.750803314551;

    for (int TQrDX = 1573485942; TQrDX > 0; TQrDX--) {
        aeRzxzkwVZPdb = pjgmCqVHqSAdInlr;
        MJZkSIwfPMvWhvo = aeRzxzkwVZPdb;
    }

    return MJZkSIwfPMvWhvo;
}

ILuJtO::ILuJtO()
{
    this->BepTTfSuyC(-1735549783);
    this->AvwuFaHfOU(string("vPssKMpCdELZrtCwiIXNZpwLpmfppkmImdKtSuOFsyfErxFadSZMYapAgSSajWdnTjNeBcWpLIQLnLqkBvYPLakIDKmFwTaHRCnieGFNcZCmoeePIrCTQHcFeYrhKMKLVHZHBagjMdPtcDONJWOBAWeBjJXuUVTMEkSIHCgqVpsHqhMBxIIEkMsSVjtfYujpWzDwdvRA"));
    this->NRNDdqb();
    this->LpjLkTuJUhQLqUz(-754600.1710072143, string("aBqsUkxxdOUOCzofEfdWYvKDHHuJioTFkRSQNXpbsHIelfiiJzYECfUECepkUcbFCMLemxOsQaGmocNHUsCtTheiLqmYsVmituzFAMhCeSYiaUDFUJmAgomaivcUgGlTcxSLFvLaYioJTYsZCqHNkogXrEUjInfRWkOytMAEIuknqLfqIXjp"), 728640.0077697621, string("HenBGxdcxeNlOFChIfqLJfeRhVWjxdBGyzjyXFxtaReVWmRQfCCZmcZkWdeWxDsdNozYw"), -549949.8060498807);
    this->wahQBMoQHugxW(-916259083, false, 1484706409);
    this->yoxwDiFbVGs(true, string("ZBMnaBcWhlNtpfAaQeWKEoUPRkdWmLapKjeQMYZneXEFCvpIBvVUzknRQjubmBypDalHOzDgNDzhqzSgHbauscIQcKJiDkWAGZHwjdlujIYPyNowUvTuhNqGseQRkhBNHvOVC"), 16083.148988924058, string("MrpdSMgoTZrpVvRfAuUoPdXSzFNxDpMAIuJABLqlgoggRrxFjeMXfCbFFXylCCGegdfIdCfttBcyabnolvNVKmoADLqhxueFuF"), 1620694930);
    this->nvdQNwHTObKnyX(1488542564, -412738.39143457444);
    this->KfbWnZefo(2125394204, true);
    this->CoZbIx(82833.13565600861, -888270.9993668158, true, true, 1193354812);
    this->ouMGquwZp(true, 2100231325, 575383623);
    this->IlVXzVRdSOQ(-958341.9072257594, true);
    this->daGhtKOgKqGJcCC(-270907550);
    this->LztlC(false, 1680174364, true, string("MGYhatNHAVGnlpqAHHJosvQmvNxTgbBqCVFHZhULrbNqhUFdXJnzIauTZZ"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KwxLSIMTyXouhAgT
{
public:
    int szYXDujrhrbkpDVj;
    bool iBHxKbyR;

    KwxLSIMTyXouhAgT();
    bool tfpSwmvkpPirnr(string SAApGUiZ, bool Gdbrv, int ohZQZ, double GLwZzy);
    bool UwthAAKQ();
protected:
    bool QkcYquKq;
    int GWqdtriTkqvfPAxO;
    int klUqzCpdVRqeGRPS;
    int exYCSVx;
    double XgCljdMoWmqz;
    bool brpcmEBfm;

    double MxvJmiZJPFSzxlPY(bool KKFxZjVGRrCr, string yiycNHonPpv, double pYMqaVqYeNryca, int QhJXbnafLh);
    string LEvqJeVRd();
    void tmRrzFMdfA();
    void EmWpcIcRyfNNICd();
    int adMDbzJsglNWSdM(string FmmihbbVP);
    double zEnzIVDBxZuuW(string jcfxWQBYIV, double yWgvhSzvAuAx, bool ajqezrcVAWxlT, bool iybpKiKdQZkhl, bool IQcJrFViOh);
    void jwzZFPxcXOLal(string LTdnTmP, bool JWVKJDtWeaV, double gdDoPCWphrgNh, double rsvFurBbo, int byusqaTRvxkRI);
    int feeEzERzLRt(string BczqvpIAXf, double hENxBG);
private:
    string RaPeoNOzfcfT;

    double sYpxcPMhg(bool MpXMsOktJEc, bool XcMNZqoUAEDWabE, bool BYWqUzNuaWBQBfw, int NbERhZgmeqtmy);
    void MjTSd(int NHZJGPoSvzrxKv, string flVVO, bool PgqYKyFVVlx, double pSjjrYuckubNXsv, double QuklUSePwYT);
    void kFFQVW(bool CePQjzrPhlO, double RowcdQXeyQ, bool wEyINFZwKRVJeWU, double GgkPc, bool InZvhwdTtZOkmQ);
    void TYPTkVSEEYxbahKy(bool bbQPr, bool EOkkTVQWOR);
};

bool KwxLSIMTyXouhAgT::tfpSwmvkpPirnr(string SAApGUiZ, bool Gdbrv, int ohZQZ, double GLwZzy)
{
    double hUsetOSoAFQiAaRu = 566439.0677564192;
    bool WYphrTdqCDoBlYFR = true;
    int IabTE = 803526206;

    for (int PLqCbSnwfQuiTY = 563651416; PLqCbSnwfQuiTY > 0; PLqCbSnwfQuiTY--) {
        WYphrTdqCDoBlYFR = WYphrTdqCDoBlYFR;
    }

    for (int DwSQwqdYfj = 1727357525; DwSQwqdYfj > 0; DwSQwqdYfj--) {
        IabTE -= IabTE;
    }

    for (int ozevrRIgJQ = 725017779; ozevrRIgJQ > 0; ozevrRIgJQ--) {
        IabTE *= IabTE;
        ohZQZ -= ohZQZ;
    }

    return WYphrTdqCDoBlYFR;
}

bool KwxLSIMTyXouhAgT::UwthAAKQ()
{
    string Lfzltxo = string("UnXBjCTJVbcHfCwgSstTBTfAJhlsLAbyQpAdsQVtdvLlzrMWoiGWFCdPkuYsRnvnPricKqDyhlieORbGIVkfNuMTgnAUfdRwaLuHjlrKFBMnhAFNOHpilSahPuILATacGrGOkCEOryKYHAlVahqWMdSOURHJZXodnmapvPwEjJIuMYezveHcrLNKcHkLqQqJnmRldIVjdTctVZwNnlKWqNCKhDegPhLsqwu");
    bool uvbxbanHCxnG = false;
    string yLIRoaR = string("asbRbJxShnKsQQzRGVVtdrMBdZzGCIPjhmWCfygydGarFBtNfqleayTUqESXZUEbveMkeTFdQbRErftBSBTDkBfQBZcG");
    bool eRtHzW = true;
    bool bYTFfAgHuSBCdHre = true;
    double xBqlSbhFIURFx = -619458.9966508254;
    int cHcnvWizZAOjRVRD = 2062468174;

    for (int daVGEDiYQvFjce = 560364838; daVGEDiYQvFjce > 0; daVGEDiYQvFjce--) {
        bYTFfAgHuSBCdHre = eRtHzW;
        yLIRoaR += yLIRoaR;
    }

    return bYTFfAgHuSBCdHre;
}

double KwxLSIMTyXouhAgT::MxvJmiZJPFSzxlPY(bool KKFxZjVGRrCr, string yiycNHonPpv, double pYMqaVqYeNryca, int QhJXbnafLh)
{
    string ETQQq = string("YgUTwllDichjZonNIqpRrvtwYPmDswSDmcuhZifcIZVneLYMsdIIBqFLrVtXxzQmqkbYshLLKRLeQoCkWKqyPUWrBzczMsWUeAgijhqzCvbqaZYoWWDPGDHsaiFWfxRtOoYskOKwehdzokVQKlbDbaE");
    double XCOjHedW = -929029.6537173681;
    string kObcDWqwz = string("OKDRmMyAvSgXu");

    if (yiycNHonPpv >= string("oxUEFDYOBqVrfQzbYqDuzSmEmVBKYVCeCFWInTEpmdchGHZTHUshOyUVDRDvLRvWvPROKakyeOjMPMPFZtbkdBQZvjXOCeRIQXtvhhNFKItWnNZNDhVRkKVHmCJavtVTPPagMf")) {
        for (int kyxAOdHzpoUpTa = 575662708; kyxAOdHzpoUpTa > 0; kyxAOdHzpoUpTa--) {
            continue;
        }
    }

    return XCOjHedW;
}

string KwxLSIMTyXouhAgT::LEvqJeVRd()
{
    double xkTfAuTZnSRkpHr = 49754.8076468553;
    int GCxYiSYeBLrbsBS = -1995189203;
    string DJzkhfkgL = string("YInsiJMhMQmeDNdKltjNVmCdZNzOfiMKhyuyvbxfoNZvimySZFHHhpItPqssBpjUiOiGCIrPPIXoeMtHBlPhLGlfjtmcPsXpfBPYPNiQSSTKSTMzMjQyZDfxCKlKDeXHonGcFRCsPABpvFDKYyQkuAQRLPoxJiroyOMslWpZidYAQJjiXLizYwPZIRbKEMhheLQ");
    double SIEOrxNUjrASuvVN = 207022.27387164725;
    double eTDfWjK = -647303.8619365295;
    int ssJtJQXkScu = 1012931491;
    double DBwsCtqslqV = -500356.1889051884;

    for (int oSsjxYPmcgHU = 390097520; oSsjxYPmcgHU > 0; oSsjxYPmcgHU--) {
        DJzkhfkgL = DJzkhfkgL;
    }

    if (xkTfAuTZnSRkpHr <= 207022.27387164725) {
        for (int ACHoxiCqqBsGhqb = 2137465777; ACHoxiCqqBsGhqb > 0; ACHoxiCqqBsGhqb--) {
            xkTfAuTZnSRkpHr = xkTfAuTZnSRkpHr;
            eTDfWjK = DBwsCtqslqV;
            ssJtJQXkScu /= ssJtJQXkScu;
        }
    }

    for (int IJLcKgyiyImJYed = 2105664817; IJLcKgyiyImJYed > 0; IJLcKgyiyImJYed--) {
        SIEOrxNUjrASuvVN *= xkTfAuTZnSRkpHr;
        xkTfAuTZnSRkpHr *= DBwsCtqslqV;
    }

    for (int blHURAI = 844583164; blHURAI > 0; blHURAI--) {
        SIEOrxNUjrASuvVN *= DBwsCtqslqV;
        xkTfAuTZnSRkpHr = eTDfWjK;
        GCxYiSYeBLrbsBS -= GCxYiSYeBLrbsBS;
        DJzkhfkgL += DJzkhfkgL;
    }

    if (eTDfWjK < 49754.8076468553) {
        for (int PiyBSLXq = 218019975; PiyBSLXq > 0; PiyBSLXq--) {
            DBwsCtqslqV *= xkTfAuTZnSRkpHr;
            ssJtJQXkScu += ssJtJQXkScu;
            xkTfAuTZnSRkpHr *= DBwsCtqslqV;
        }
    }

    for (int pnkYPfmML = 1361472422; pnkYPfmML > 0; pnkYPfmML--) {
        DBwsCtqslqV = DBwsCtqslqV;
        eTDfWjK *= SIEOrxNUjrASuvVN;
    }

    return DJzkhfkgL;
}

void KwxLSIMTyXouhAgT::tmRrzFMdfA()
{
    bool QIBAPsCbC = false;

    if (QIBAPsCbC != false) {
        for (int KpayOrMxJzUqb = 296633547; KpayOrMxJzUqb > 0; KpayOrMxJzUqb--) {
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
        }
    }

    if (QIBAPsCbC == false) {
        for (int MKEoIzjP = 1687706959; MKEoIzjP > 0; MKEoIzjP--) {
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
        }
    }

    if (QIBAPsCbC != false) {
        for (int HLuxZhhCXLHJQo = 1781926077; HLuxZhhCXLHJQo > 0; HLuxZhhCXLHJQo--) {
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
        }
    }

    if (QIBAPsCbC != false) {
        for (int CDoLoKxBnuUS = 1084896317; CDoLoKxBnuUS > 0; CDoLoKxBnuUS--) {
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
        }
    }

    if (QIBAPsCbC == false) {
        for (int UBcOcCMmf = 1359648957; UBcOcCMmf > 0; UBcOcCMmf--) {
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
            QIBAPsCbC = QIBAPsCbC;
        }
    }

    if (QIBAPsCbC != false) {
        for (int rnWyKHFuGDIWJzXi = 1334430323; rnWyKHFuGDIWJzXi > 0; rnWyKHFuGDIWJzXi--) {
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
            QIBAPsCbC = ! QIBAPsCbC;
        }
    }
}

void KwxLSIMTyXouhAgT::EmWpcIcRyfNNICd()
{
    int OGLJkayBitMEd = -404007305;
    bool tTwOMhDVWMW = true;

    if (tTwOMhDVWMW != true) {
        for (int zxoCPkTsLOM = 615045880; zxoCPkTsLOM > 0; zxoCPkTsLOM--) {
            tTwOMhDVWMW = tTwOMhDVWMW;
            OGLJkayBitMEd -= OGLJkayBitMEd;
            tTwOMhDVWMW = ! tTwOMhDVWMW;
            tTwOMhDVWMW = ! tTwOMhDVWMW;
        }
    }

    if (OGLJkayBitMEd >= -404007305) {
        for (int Aketqv = 1304522549; Aketqv > 0; Aketqv--) {
            continue;
        }
    }

    for (int pPLqoRfe = 664364934; pPLqoRfe > 0; pPLqoRfe--) {
        tTwOMhDVWMW = tTwOMhDVWMW;
    }

    if (tTwOMhDVWMW == true) {
        for (int JwKAzpox = 982989417; JwKAzpox > 0; JwKAzpox--) {
            tTwOMhDVWMW = tTwOMhDVWMW;
            tTwOMhDVWMW = ! tTwOMhDVWMW;
            tTwOMhDVWMW = tTwOMhDVWMW;
            OGLJkayBitMEd /= OGLJkayBitMEd;
            tTwOMhDVWMW = tTwOMhDVWMW;
        }
    }

    for (int iMDlHskHQPUSMNb = 68471221; iMDlHskHQPUSMNb > 0; iMDlHskHQPUSMNb--) {
        OGLJkayBitMEd -= OGLJkayBitMEd;
        OGLJkayBitMEd *= OGLJkayBitMEd;
        tTwOMhDVWMW = ! tTwOMhDVWMW;
    }
}

int KwxLSIMTyXouhAgT::adMDbzJsglNWSdM(string FmmihbbVP)
{
    double wjdWYyBuMuoKy = -105648.8593843039;
    string KGuFiKhMMO = string("ZJFcJkaWoPeXRdJFsXWofjkVpjTSlhQINdLPp");

    for (int zTnwxDamrLJAoXx = 444371863; zTnwxDamrLJAoXx > 0; zTnwxDamrLJAoXx--) {
        FmmihbbVP += KGuFiKhMMO;
        FmmihbbVP = FmmihbbVP;
        wjdWYyBuMuoKy = wjdWYyBuMuoKy;
        KGuFiKhMMO += KGuFiKhMMO;
        KGuFiKhMMO = KGuFiKhMMO;
    }

    for (int DzUresHBhhp = 1448153183; DzUresHBhhp > 0; DzUresHBhhp--) {
        FmmihbbVP = KGuFiKhMMO;
        FmmihbbVP += FmmihbbVP;
        wjdWYyBuMuoKy -= wjdWYyBuMuoKy;
        FmmihbbVP = KGuFiKhMMO;
        wjdWYyBuMuoKy -= wjdWYyBuMuoKy;
        FmmihbbVP = FmmihbbVP;
    }

    for (int ATkaYQqSwRMDFVE = 974497627; ATkaYQqSwRMDFVE > 0; ATkaYQqSwRMDFVE--) {
        wjdWYyBuMuoKy *= wjdWYyBuMuoKy;
        KGuFiKhMMO = KGuFiKhMMO;
        wjdWYyBuMuoKy *= wjdWYyBuMuoKy;
    }

    return -1250529106;
}

double KwxLSIMTyXouhAgT::zEnzIVDBxZuuW(string jcfxWQBYIV, double yWgvhSzvAuAx, bool ajqezrcVAWxlT, bool iybpKiKdQZkhl, bool IQcJrFViOh)
{
    double WwHmsfUhch = 1019852.284649181;
    bool LGZGCQtGhTuqGUA = true;
    int WdunTDrZAXwle = 1273657524;
    string WkxVCZOdTQDexzH = string("rrnFKOipZQLUckAWxexqcEgSdknvaFVQvvpFxmpBfqhXsMfczzfWurGXycdhggFuCmMBbpUJmdQmfQIaOPOziJNxczrZhQEKGSulDbbxDLPxhbGxEwxcsyzamwfXfiawahrnCwVMcKxbisWdgJfTSzGCwbuAyePN");

    if (ajqezrcVAWxlT == false) {
        for (int RNmyuY = 1108113206; RNmyuY > 0; RNmyuY--) {
            iybpKiKdQZkhl = ! IQcJrFViOh;
            iybpKiKdQZkhl = iybpKiKdQZkhl;
            LGZGCQtGhTuqGUA = ! LGZGCQtGhTuqGUA;
        }
    }

    return WwHmsfUhch;
}

void KwxLSIMTyXouhAgT::jwzZFPxcXOLal(string LTdnTmP, bool JWVKJDtWeaV, double gdDoPCWphrgNh, double rsvFurBbo, int byusqaTRvxkRI)
{
    int zbhgRznV = 551444945;
    string dmIaj = string("WOsIuCifxUtynXbkISfOvGLERtFBbyvwueSaPGJTWrmsMAefenwniqmDFPOUNPzOsQqFbmqIEFuqUEsxgvOqJERnGGAfFIOChVWYhbHeIoUtcoDRP");
    string DphvMOFBLcDywFj = string("BqcojZWVcnNbRxYAumEOBonTInAXnvJXeiVqhSLVhAYwSHKnjTreKQDgtKdSgvLdpLcVWFNnXJUTLJVaMzEDfGiyeduexjHgJYZDKmgjYGktiGdEOvVkxFPPhUMMkTxwrLaHK");
    string GQSjzArKVG = string("KqAsfxITYPwYPRgVynzGoUkMqGbJFntzbRLrMJutoMtTCaZlcJojEUgUnzXwOWPydVFekpFiiBKRMcVNKQdGKfFpWNvuhxsxEsssAtwawDlgwYfRNCFPAftxFKIuoxPomaBsrNGvJViGsNPUGKkVJMOYxGkFLNI");
    int vQDPNhhDDvQ = 611562748;

    for (int SuTVtooSBgD = 2139260371; SuTVtooSBgD > 0; SuTVtooSBgD--) {
        vQDPNhhDDvQ += vQDPNhhDDvQ;
    }

    if (byusqaTRvxkRI != 551444945) {
        for (int iSvPpGMbgmCK = 2137711930; iSvPpGMbgmCK > 0; iSvPpGMbgmCK--) {
            GQSjzArKVG = GQSjzArKVG;
        }
    }

    if (DphvMOFBLcDywFj == string("BqcojZWVcnNbRxYAumEOBonTInAXnvJXeiVqhSLVhAYwSHKnjTreKQDgtKdSgvLdpLcVWFNnXJUTLJVaMzEDfGiyeduexjHgJYZDKmgjYGktiGdEOvVkxFPPhUMMkTxwrLaHK")) {
        for (int RzbMBxnKLynt = 1645262147; RzbMBxnKLynt > 0; RzbMBxnKLynt--) {
            GQSjzArKVG = dmIaj;
            LTdnTmP += LTdnTmP;
        }
    }

    if (LTdnTmP > string("KqAsfxITYPwYPRgVynzGoUkMqGbJFntzbRLrMJutoMtTCaZlcJojEUgUnzXwOWPydVFekpFiiBKRMcVNKQdGKfFpWNvuhxsxEsssAtwawDlgwYfRNCFPAftxFKIuoxPomaBsrNGvJViGsNPUGKkVJMOYxGkFLNI")) {
        for (int TLNDGj = 1198316141; TLNDGj > 0; TLNDGj--) {
            continue;
        }
    }
}

int KwxLSIMTyXouhAgT::feeEzERzLRt(string BczqvpIAXf, double hENxBG)
{
    bool MylGDsNLYZRWg = true;
    int Uwuftv = -1504930607;
    bool WylqpD = false;
    double kssaTrFkgd = -585657.3052794645;
    double GnSUgNKldAoiJSfr = -548205.7355808816;
    double JAxiIGdvlQmUVGnl = 284330.33702494693;

    if (MylGDsNLYZRWg != true) {
        for (int nobyPnNRogR = 1813671201; nobyPnNRogR > 0; nobyPnNRogR--) {
            continue;
        }
    }

    for (int vGzTqaUU = 1836235157; vGzTqaUU > 0; vGzTqaUU--) {
        hENxBG /= hENxBG;
    }

    return Uwuftv;
}

double KwxLSIMTyXouhAgT::sYpxcPMhg(bool MpXMsOktJEc, bool XcMNZqoUAEDWabE, bool BYWqUzNuaWBQBfw, int NbERhZgmeqtmy)
{
    double SNoxxpJsnSIHX = -545561.5121443887;
    int jHzKuYzPLJXHPBmP = 338330257;
    bool cLkUTpcPKnY = true;
    int SnjmWrgYpmBO = 303928706;
    int feAayKBgOfbRXSB = -764787916;

    for (int tGWkgqStKrxOQRT = 1345016552; tGWkgqStKrxOQRT > 0; tGWkgqStKrxOQRT--) {
        continue;
    }

    if (SnjmWrgYpmBO == -1210172186) {
        for (int lXgPJlhZ = 2004855365; lXgPJlhZ > 0; lXgPJlhZ--) {
            cLkUTpcPKnY = XcMNZqoUAEDWabE;
        }
    }

    if (NbERhZgmeqtmy < 303928706) {
        for (int kPPmjhZHIZx = 870146647; kPPmjhZHIZx > 0; kPPmjhZHIZx--) {
            BYWqUzNuaWBQBfw = MpXMsOktJEc;
            feAayKBgOfbRXSB += NbERhZgmeqtmy;
        }
    }

    return SNoxxpJsnSIHX;
}

void KwxLSIMTyXouhAgT::MjTSd(int NHZJGPoSvzrxKv, string flVVO, bool PgqYKyFVVlx, double pSjjrYuckubNXsv, double QuklUSePwYT)
{
    double nTLtwXoku = 118629.31881397413;
    int PkhFQAtfI = 1697933475;
    bool koinGpyZuKKV = true;
    string rWUNAyHyj = string("kFbeLMZlZZHahxdfMKJjMTScZDapQuaHGkvlwgSlFwHurbSSGKuiAnZqpATvcFXmQZwAhbSluTXveFJFxhePupGslbTVeWIEgQrmpZjcdvriesPBqnlewwLkelAEBXxDgdKohsCViSdgkQmgORBRVjrMCHJmZlHkRPgrsWUNYdSuQSpctlLqidAXeaQMuTGsHDRwOWqCvTyj");
    string OSKfO = string("PWjeVWgBKKBGwHIroJtNsdRKuPjJWmSwmeEkkOUqmyTOTnLzYnSCllanrlahsTvuYKIqkWDjRrQupFtWljcyEadsSsGzqwrqzEPnZtDtuqSjejdwcg");
    int uYehGUqHWplD = 2042033157;
    bool gwMPVluK = true;

    for (int bGhFdWbAoVing = 894046288; bGhFdWbAoVing > 0; bGhFdWbAoVing--) {
        koinGpyZuKKV = gwMPVluK;
        PgqYKyFVVlx = ! gwMPVluK;
        pSjjrYuckubNXsv += pSjjrYuckubNXsv;
        uYehGUqHWplD = PkhFQAtfI;
    }
}

void KwxLSIMTyXouhAgT::kFFQVW(bool CePQjzrPhlO, double RowcdQXeyQ, bool wEyINFZwKRVJeWU, double GgkPc, bool InZvhwdTtZOkmQ)
{
    int RelrLbwZOSv = 975449504;
    string tvQlNYG = string("GbrFnugZYtaKJhyMnjrMtnfrYewfhrzCBBwgbppFAgwOmdkGyGFvxXijYpHRbRsHKGmpoiyaKTAGeZdMrQQSabUtkhZEMiXbWeXNaDngbNcwrXcVYViJTKPLRkjhhFabWrBqqOrv");
    int vmOwbQrVebAKG = -1357801123;
    string KfHZCZJ = string("fmyasGdHqKvwVgslgPSIMdWjfFEIiQOBFHxIIXfXMKLhREDeuDWNwrIpEeqpdgZuqLsHqNGzBcTbKVHqoTNnUesAMiOSSbZFRnIpfKvdRmaRaQinSewbPsbvLXJMsBlJDqvdlMkXAUVWyWrMxgpZSPnaWSEEHPGcyNCKupXVxepMm");
    bool PHoqWsWOzN = false;
    int KLKgsQ = 1716758193;
    double hhiCkNhSaZsEXJBN = 1046807.0972447558;
    string nDZlXZPsP = string("UqFdeGnMKHDTwCddmZEzCmEbaxlVzsRAWmGUcWQsvgWJpLMhAnJiRukeEvGOPShihOQVqtircJTrDyBdhRlzpRw");
    int xsdbpX = 264934321;
    string KjEucBtiPiJsHq = string("HhAYSNiMMIRbVtfiEx");

    for (int dKHKO = 2036558169; dKHKO > 0; dKHKO--) {
        tvQlNYG = tvQlNYG;
    }

    for (int vmPiyOEeqasrQt = 1951168451; vmPiyOEeqasrQt > 0; vmPiyOEeqasrQt--) {
        continue;
    }

    for (int ggdePmWGJKKSbKTi = 1412921884; ggdePmWGJKKSbKTi > 0; ggdePmWGJKKSbKTi--) {
        KLKgsQ -= KLKgsQ;
        KjEucBtiPiJsHq = tvQlNYG;
    }

    for (int bHzxT = 1965036795; bHzxT > 0; bHzxT--) {
        continue;
    }
}

void KwxLSIMTyXouhAgT::TYPTkVSEEYxbahKy(bool bbQPr, bool EOkkTVQWOR)
{
    double BIzvbIaNvZOJXvUb = -264614.44517881813;
    double dmMTHHw = -952565.9309715366;

    for (int mVKzNoya = 351392845; mVKzNoya > 0; mVKzNoya--) {
        BIzvbIaNvZOJXvUb /= BIzvbIaNvZOJXvUb;
    }

    if (bbQPr != true) {
        for (int TsYFVNeYADQiu = 1356744891; TsYFVNeYADQiu > 0; TsYFVNeYADQiu--) {
            BIzvbIaNvZOJXvUb = BIzvbIaNvZOJXvUb;
            bbQPr = bbQPr;
            EOkkTVQWOR = ! bbQPr;
        }
    }

    for (int jVKoZkfBu = 1633720583; jVKoZkfBu > 0; jVKoZkfBu--) {
        dmMTHHw = dmMTHHw;
        BIzvbIaNvZOJXvUb -= dmMTHHw;
        BIzvbIaNvZOJXvUb /= dmMTHHw;
        bbQPr = ! EOkkTVQWOR;
    }

    for (int pidKuFRQCDyP = 31359657; pidKuFRQCDyP > 0; pidKuFRQCDyP--) {
        EOkkTVQWOR = EOkkTVQWOR;
        bbQPr = bbQPr;
        bbQPr = bbQPr;
        dmMTHHw += dmMTHHw;
        bbQPr = bbQPr;
    }
}

KwxLSIMTyXouhAgT::KwxLSIMTyXouhAgT()
{
    this->tfpSwmvkpPirnr(string("xbiwYdiZlQNiyctAQcTuLtkouObHOVjJbU"), false, -2037868287, -354024.6653510957);
    this->UwthAAKQ();
    this->MxvJmiZJPFSzxlPY(true, string("oxUEFDYOBqVrfQzbYqDuzSmEmVBKYVCeCFWInTEpmdchGHZTHUshOyUVDRDvLRvWvPROKakyeOjMPMPFZtbkdBQZvjXOCeRIQXtvhhNFKItWnNZNDhVRkKVHmCJavtVTPPagMf"), 1014697.0666583831, 449064003);
    this->LEvqJeVRd();
    this->tmRrzFMdfA();
    this->EmWpcIcRyfNNICd();
    this->adMDbzJsglNWSdM(string("HguENFYGfjvLkdDteSsYHAGGOtwTetJgIqLIxWhlufLoEBDlSXrVfdzKPiDJ"));
    this->zEnzIVDBxZuuW(string("hVlzMroBtYswgFpnUrMhzIkSlAgutypyBTdepTuzJHBCZcsgprIDlzZuogLDYdtPhLtZFYw"), 989266.4554716888, true, false, false);
    this->jwzZFPxcXOLal(string("KRsjnvXxtzzMlnbVrMVYklbretldRubpTqsDLAgXCGVcSrvcYysowSrxTlHgghHYWTbQvbfunohXVtQjLUjSPzDPLQbbOJLwCkUvARxfkUSrFJSuMnrovWhCuBRaDem"), false, -817718.2484738205, -678701.463051189, 416087871);
    this->feeEzERzLRt(string("FnGvgODihBwzpUhEgkQsSdF"), -818872.4748464772);
    this->sYpxcPMhg(true, true, false, -1210172186);
    this->MjTSd(-123724294, string("nBDPCjWFcHrqRJyFYAxnDgaXNkd"), true, -187387.05552762566, 646319.6777988109);
    this->kFFQVW(false, 854627.9541340019, false, -394729.89147889207, true);
    this->TYPTkVSEEYxbahKy(false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OOoVsLNIwuJp
{
public:
    bool nFfKeitQxAABWdYw;
    bool FuZwEYaODqMSLxL;

    OOoVsLNIwuJp();
protected:
    double ICVaUkP;
    bool FEkKEy;
    string qjVCl;

    bool fxrCLgld(double PTmRdw, double hqODrGPWqSBq, int ozDeoltSrJZPkjlI, string gaKCbXw);
    double tQAmVOSmUrD(string SGdNpGQCxKC, string KFHfFcqaRIe, double BjVsqqhFjhZvnCm, int tgMOdiAVuxwD);
    string liDOWySjHTJlC();
    string MVLUIEktEDpBJ(bool WBYwrimt, double wHXXTTydzSDn, int nWZncoto, int pFVtlPmXZfWVCX);
    bool ErkJKKKRSALakvP(double bnfNwfOGdaAKI, int jaMms);
    int eqEZf(bool MDKodPsJ, string zFmWtNrERgtCL, bool kMHIaEJenQWj, int iApnX);
    int ySAgVHhnLfBXcRvc(int SFxhVpmYRksmRbA);
    int fsdswhWLbrLsS(double KMFYSeBEMs, string PAOnFD, int yINdESnqPssoyga);
private:
    string rzYKZJvSauiQluga;
    string dyBtpfsUosblmrL;
    int YwuyKXnU;
    bool qQtcKisOBOqKMaG;
    string ZuMogtUYa;
    int GoaJj;

    void kexwWvCbpqzpJo(string bLMTrrDknx, int HaPBELKwpnMjr, double CfDEsbfnMa, double MeyzW, bool dwhmmW);
    int fzMIGEEBw(double xesniDdSXz, string AhlYzxI);
    bool sjDImsqjH(int gHHKuADLiJnJaPc);
    void txMnOoaA();
    bool XWwjzakvJw(int OjjPknMWyybN, int FvdAHZsLnzKZM);
};

bool OOoVsLNIwuJp::fxrCLgld(double PTmRdw, double hqODrGPWqSBq, int ozDeoltSrJZPkjlI, string gaKCbXw)
{
    double XeqSQiyrKNahaJ = 139861.23930609252;

    for (int oEGHrGgWR = 1723475171; oEGHrGgWR > 0; oEGHrGgWR--) {
        hqODrGPWqSBq -= PTmRdw;
        XeqSQiyrKNahaJ *= XeqSQiyrKNahaJ;
        hqODrGPWqSBq = PTmRdw;
        PTmRdw += PTmRdw;
    }

    for (int hbPvcQoeqpmi = 1510527123; hbPvcQoeqpmi > 0; hbPvcQoeqpmi--) {
        XeqSQiyrKNahaJ /= hqODrGPWqSBq;
        hqODrGPWqSBq += XeqSQiyrKNahaJ;
        ozDeoltSrJZPkjlI = ozDeoltSrJZPkjlI;
    }

    return true;
}

double OOoVsLNIwuJp::tQAmVOSmUrD(string SGdNpGQCxKC, string KFHfFcqaRIe, double BjVsqqhFjhZvnCm, int tgMOdiAVuxwD)
{
    string dBkEDUbY = string("peDqIbVVcQWOivDONNlqqcAFmVEHlljVaGshjgkFoHjXtZiBWafTxqtrkkhQQqKcRxSHExSMQBnVLYZgVeFYOcvwnQNrWxBMsXdkPcjJNYBBPPOkpPbCtbwo");
    double meveLjLubLgF = 96219.00505715424;
    double uNYuroqwJxPe = 222399.5230334098;
    string bZOzxbcEyPLNsPJ = string("pTRqqWWXDJrjhgMLOqEiLexccVdGXvMvnRizYoKZSTwcaBjqgbpscAnOrUTELFnBwZeIKFTKrejrsYKIwQvkENbWDpeAMQukZoqQsxWBCorZOjLTViMXlvhTmqMTCMSSIzAUkBRhFijPWaepgHHgypMwZXAiKpdbXVQmRjeLVjKHMeGxreSRpQEhExtWlBLizkwgxvxhIFytpjbDpOWFCkAflvGzzYDAIDDyCcxaWCgWzBzdEnaO");
    string xzHIeuJ = string("rnPMAiYJiezCfVoHGAvHcIyJHhHfUdpkVNkSOYqywJIMcQktvlVmJLKvhTTFfUgKIsMsBzkCxDBaXSVRnfVUvFYozzuGCUwlcLIJUkS");
    int VeceoXkd = -192983486;
    double VSteJBHSJTxQvIc = 512436.1549157228;
    bool BMYjPiI = true;
    string hrbdixabPtFg = string("bieGkZJraUHtQbNcVlUZIrkftyZunIGGBrUPLPjzVinvnVDxCjJMiejpQLgszrFOeXvyCHlvpBPuKdqEDtFJjkYSKqURXpGgCqKgojVywxIfVtiOxBFwblAzJbmlROnG");
    bool NIZHUnqIm = true;

    for (int jqMSSQZds = 1893922641; jqMSSQZds > 0; jqMSSQZds--) {
        tgMOdiAVuxwD -= VeceoXkd;
    }

    if (SGdNpGQCxKC <= string("peDqIbVVcQWOivDONNlqqcAFmVEHlljVaGshjgkFoHjXtZiBWafTxqtrkkhQQqKcRxSHExSMQBnVLYZgVeFYOcvwnQNrWxBMsXdkPcjJNYBBPPOkpPbCtbwo")) {
        for (int zUWKGDTGKbmeXlj = 394594741; zUWKGDTGKbmeXlj > 0; zUWKGDTGKbmeXlj--) {
            BjVsqqhFjhZvnCm -= uNYuroqwJxPe;
            xzHIeuJ += hrbdixabPtFg;
            bZOzxbcEyPLNsPJ = xzHIeuJ;
            xzHIeuJ += KFHfFcqaRIe;
        }
    }

    return VSteJBHSJTxQvIc;
}

string OOoVsLNIwuJp::liDOWySjHTJlC()
{
    bool aFKtwDq = true;
    double gpeCzceDbx = 788662.5596527697;
    bool aQiJONfacgLYyT = true;
    double OZbcAenBItyX = -10237.948868730567;
    bool TEXCAiF = true;

    if (TEXCAiF == true) {
        for (int PycTQgzQi = 1604375129; PycTQgzQi > 0; PycTQgzQi--) {
            continue;
        }
    }

    if (aQiJONfacgLYyT != true) {
        for (int DeqHRDDdI = 1272507224; DeqHRDDdI > 0; DeqHRDDdI--) {
            aFKtwDq = ! aQiJONfacgLYyT;
            gpeCzceDbx /= gpeCzceDbx;
            aQiJONfacgLYyT = aQiJONfacgLYyT;
        }
    }

    for (int UEFwjAR = 1895556838; UEFwjAR > 0; UEFwjAR--) {
        aQiJONfacgLYyT = ! TEXCAiF;
    }

    if (TEXCAiF != true) {
        for (int cCgLIiYkRbeX = 719694625; cCgLIiYkRbeX > 0; cCgLIiYkRbeX--) {
            TEXCAiF = ! aQiJONfacgLYyT;
            aFKtwDq = TEXCAiF;
            gpeCzceDbx *= gpeCzceDbx;
            aQiJONfacgLYyT = TEXCAiF;
        }
    }

    for (int GkdbZD = 374478168; GkdbZD > 0; GkdbZD--) {
        continue;
    }

    return string("yczkVZOlgpbWjcngnAlVuQKkZxouvfwCSTaxQUjAQGBUbReXfFFakkCWXZQWdTCciyVePGitLDOdENkpQnqNFmArZZ");
}

string OOoVsLNIwuJp::MVLUIEktEDpBJ(bool WBYwrimt, double wHXXTTydzSDn, int nWZncoto, int pFVtlPmXZfWVCX)
{
    double laDbhaKPhZbyn = 327540.1006675237;
    bool gnWIyB = true;
    int OwEedukmVgLIQm = 123543886;
    int UonFWXWCkiEjQZZ = 464803202;
    double AlEhop = -377870.704950477;
    double EOcPbRSWBpjb = 272337.65494374605;

    if (nWZncoto >= 464803202) {
        for (int sMoSdrZd = 1901772618; sMoSdrZd > 0; sMoSdrZd--) {
            gnWIyB = gnWIyB;
            nWZncoto = OwEedukmVgLIQm;
            gnWIyB = ! gnWIyB;
        }
    }

    return string("jjcQjrStbsLOIlnjHWpkHxxlRNXrFSUhkVhoUDgTPATRfUfNYgoSYQKQhVWsvUDIAOVJnkJDmgMMdyjwYzcxUfmRGlmbDFtyGUsUSsjsopiDNgqCOTNAFEmbAQpgZkxWncfJrkGkezFgBRnjTzaHYyMAhG");
}

bool OOoVsLNIwuJp::ErkJKKKRSALakvP(double bnfNwfOGdaAKI, int jaMms)
{
    int UZaattyBUCBaNvqo = 454441336;
    double RYGTblBB = 25537.343884729482;
    string KWahaoAKHNDyxdd = string("jZnPLQwRzDppsPkWoWboSGZBsywODoCDOJFeVWwDPrJnTAQnUEMYbhFTfolSolox");
    double bMdmkVGXSbcsgEtY = -800426.5219625502;

    for (int kTPZCuEzMYczj = 450844043; kTPZCuEzMYczj > 0; kTPZCuEzMYczj--) {
        bMdmkVGXSbcsgEtY *= bMdmkVGXSbcsgEtY;
    }

    return false;
}

int OOoVsLNIwuJp::eqEZf(bool MDKodPsJ, string zFmWtNrERgtCL, bool kMHIaEJenQWj, int iApnX)
{
    double lXXZNRuaYm = 729204.3031249829;
    int tuWdvo = -1901277767;
    string ynDaYNzTTI = string("RYxSvaONulCSJbSNadiPaNkWCznLBzfzFKXZhWiBgIbKlHybCaztBQavYpuZjVczNyILBilVOJrQrkAiZzILlmoUoYwHWwupALwadMdGNhYwTGyIEHmlwcOqUDjgyZAuNNELLtbgUQrPGykLCzGOXIpqyWzViNZJYufpEfIqcqbHUmQJlNcuhUrWNuSbqjeolEFKwgVXegVfwjartFCEsuInLhLbr");
    string JAQvOYZhGQxolon = string("MEPuxLdDfYevvYwTECKTyXUtJjkdsGkDrnAWNHhqJfSnFIrmtqbpgCYjUCaMvqFGeSzPbJXLdcwJFLBNiMXaCKwAEvoCYIYMlzSxAgILMlVmgLUYfMEeozNWDokAAetdwGeAVzqXbCSviwNUdJwysuGdCxzRWglmQp");
    bool gadgHUIxuTLfDmC = true;
    double PRNOXhefXu = 106005.83976293876;
    int xtvHaXYBzBkFxr = -2145264590;
    int mOibfN = -1835603129;
    bool YdudIsJbsu = false;
    string vjRmWLYLEUmYzCN = string("LOTnBxzPPEtWDFuMILOMDutcCPNmMxgdLMBnELOARObuUCgwRxnKwHJaCapKB");

    if (gadgHUIxuTLfDmC == true) {
        for (int WDRMQK = 997756752; WDRMQK > 0; WDRMQK--) {
            PRNOXhefXu -= PRNOXhefXu;
            JAQvOYZhGQxolon = ynDaYNzTTI;
            mOibfN /= tuWdvo;
            mOibfN += mOibfN;
            iApnX -= iApnX;
        }
    }

    for (int wMfMDmFWqnlQFdyt = 1210791026; wMfMDmFWqnlQFdyt > 0; wMfMDmFWqnlQFdyt--) {
        tuWdvo *= mOibfN;
    }

    for (int vHhuYCSXSeSWKAM = 514107078; vHhuYCSXSeSWKAM > 0; vHhuYCSXSeSWKAM--) {
        JAQvOYZhGQxolon += JAQvOYZhGQxolon;
        zFmWtNrERgtCL = zFmWtNrERgtCL;
    }

    for (int XiNgSTQwElPTYV = 6169953; XiNgSTQwElPTYV > 0; XiNgSTQwElPTYV--) {
        xtvHaXYBzBkFxr *= iApnX;
        vjRmWLYLEUmYzCN += ynDaYNzTTI;
        iApnX /= mOibfN;
    }

    return mOibfN;
}

int OOoVsLNIwuJp::ySAgVHhnLfBXcRvc(int SFxhVpmYRksmRbA)
{
    string zppdQxri = string("biOXtTEMOWyPUWURDCUqjyvbEpGmVlsOFSb");
    string xauHhxmTOvne = string("SomgUmfGnaAhcLRuIlhrELlSmbpbNtmSMFHbDTbQPOVfbGzyZraRuLATgyQwOatFbYipOXuWkkvHkFCbQZcOQUWfOYXQtCXKmcVqCeSeImKeFcEcHSPDgYFixZeaibSrgumyclKmTMUYjJJyGMcWAuHWfzj");
    double hfSzulMo = -313219.24419335346;
    bool iwzjdcFktLGHeiw = true;
    int VtcgzmBqYSE = -768575334;
    int XOdbJLdgMvxwpGOt = 109617535;
    int kITLQGfFuFvr = -1691572464;
    bool eZQyHxSR = false;

    for (int qSnuMwfx = 308682347; qSnuMwfx > 0; qSnuMwfx--) {
        XOdbJLdgMvxwpGOt = SFxhVpmYRksmRbA;
    }

    for (int TEhNdFujT = 544005411; TEhNdFujT > 0; TEhNdFujT--) {
        kITLQGfFuFvr *= kITLQGfFuFvr;
    }

    for (int yiAYWDRoyx = 721392737; yiAYWDRoyx > 0; yiAYWDRoyx--) {
        continue;
    }

    for (int FLNRZXKGtYi = 1062497182; FLNRZXKGtYi > 0; FLNRZXKGtYi--) {
        continue;
    }

    for (int nhXWjV = 1919307829; nhXWjV > 0; nhXWjV--) {
        zppdQxri = zppdQxri;
        iwzjdcFktLGHeiw = ! eZQyHxSR;
    }

    return kITLQGfFuFvr;
}

int OOoVsLNIwuJp::fsdswhWLbrLsS(double KMFYSeBEMs, string PAOnFD, int yINdESnqPssoyga)
{
    int hyQImpdLaRwqF = 1600547923;
    string omaHU = string("nLPEHTDfVFwgxgdCydjcNNoIPcDTlIfDcQGDLmvpxcexLDulnQWTrgIWpdElGNXWMFpfotLcFAIkGyRLNj");
    bool ORhSdrYLaCSWAN = false;

    if (yINdESnqPssoyga == 1600547923) {
        for (int NESHWzXrUDuyKc = 351503158; NESHWzXrUDuyKc > 0; NESHWzXrUDuyKc--) {
            PAOnFD += omaHU;
        }
    }

    for (int YpWJghnQYZuZ = 2042940422; YpWJghnQYZuZ > 0; YpWJghnQYZuZ--) {
        KMFYSeBEMs += KMFYSeBEMs;
    }

    return hyQImpdLaRwqF;
}

void OOoVsLNIwuJp::kexwWvCbpqzpJo(string bLMTrrDknx, int HaPBELKwpnMjr, double CfDEsbfnMa, double MeyzW, bool dwhmmW)
{
    bool ZKtpEhup = true;
    bool cyxtRRABXkdw = true;
    double OYiueD = 958508.3079718008;
    double SuBBlGEolIPk = -380985.6513639263;
    bool SkUNydV = false;

    if (HaPBELKwpnMjr > 2126259083) {
        for (int vPFPOHIZTUuuwl = 79178274; vPFPOHIZTUuuwl > 0; vPFPOHIZTUuuwl--) {
            OYiueD -= CfDEsbfnMa;
            SkUNydV = ZKtpEhup;
            SuBBlGEolIPk += CfDEsbfnMa;
        }
    }

    if (CfDEsbfnMa > 958508.3079718008) {
        for (int UvUxJZkYo = 1759703944; UvUxJZkYo > 0; UvUxJZkYo--) {
            continue;
        }
    }

    for (int xvjPJSTipB = 1516555127; xvjPJSTipB > 0; xvjPJSTipB--) {
        ZKtpEhup = ! dwhmmW;
    }

    if (CfDEsbfnMa != -380985.6513639263) {
        for (int KNxbvDaNKZ = 169260282; KNxbvDaNKZ > 0; KNxbvDaNKZ--) {
            SkUNydV = ! SkUNydV;
        }
    }

    for (int iWcHDpLf = 1734567147; iWcHDpLf > 0; iWcHDpLf--) {
        cyxtRRABXkdw = ! SkUNydV;
        MeyzW -= MeyzW;
    }
}

int OOoVsLNIwuJp::fzMIGEEBw(double xesniDdSXz, string AhlYzxI)
{
    bool ZinXd = true;
    int tYhCIUYdIFdsjV = -144006172;
    int JSSUbrPNxTenZAWk = -844972011;

    return JSSUbrPNxTenZAWk;
}

bool OOoVsLNIwuJp::sjDImsqjH(int gHHKuADLiJnJaPc)
{
    string cfGjtQTkVJA = string("dKeLPonIIJZVlUJjDLGGxjpcFubhYuANWdUyRKUmyaVaeSvUqdeAwgYqffYPxNcuGmAxJBWKsuEqdUOTHItyDXtkfVKmEpjyBuikfzFIewGGauDsPyWXBibapdlqoQOJWByltWVpqSeQUCWugBmhWzPMJLdUtyLkzdadAiMhRMrBjSjvGVcTaNZHMMVWqrpWBxCmBdglFKOYfavfGJPndIblqlgQsnftjOmGncXFkxHkoNfjmwoghqKcmQXXSk");
    bool PpgrmTBdvIFz = false;
    double GOAcvPYDgntYrIQU = 825290.5371508329;
    double DpRZvSFM = 204815.352249492;
    string eepwqYL = string("QkdNRTQxDTEEmUtjdWhXjKnRAlOSRuMSsoncWPruiKyzdEJwQKmZiPJvArfZfzWqjBYPXNiWRxSXHqxMzIGEuxxIJwWCiezfPEmDNpTJvNWFDheBTWbgMHPsVFRxNtXESXzzTiGFXTDknbODqkTGJICxUdFcAUjwckBXHiIjWtdYiWeIWIvTyrTJhgmpVTcWpDbmbLUBEwwXrLhhRcBkkKGmWbUahLKHQzye");
    bool UZYtbSMGi = false;
    int xzryXtnGTQaT = 1558850610;
    string cPLrvtRlKnDvCblU = string("mecFGYUKpNLEiVzwdGBJVaiBJ");
    double VkLfZBTyaxpmSQxk = 612777.4895380128;
    string vdQSmjZHjQrk = string("iphbzVzLTFVJXKmtOEEmmkMhYYdQBwSpcRjyCsUuOhAZOGKLUSSQlDxqRzVnrdtlaQuaGfTIdRjrOIStYzKBbEQCMAXnFJqCbLFqJpNWVvgFuQcDvWNJNAdzKpdzycytvBbaXrBWCYFbDbHzXMjnORajeFISClAllRIIrxn");

    for (int KRgvblatOFTrAulU = 1440245414; KRgvblatOFTrAulU > 0; KRgvblatOFTrAulU--) {
        continue;
    }

    if (VkLfZBTyaxpmSQxk < 612777.4895380128) {
        for (int fbgAt = 792786791; fbgAt > 0; fbgAt--) {
            continue;
        }
    }

    for (int FbKsbT = 523836939; FbKsbT > 0; FbKsbT--) {
        vdQSmjZHjQrk = cfGjtQTkVJA;
        cPLrvtRlKnDvCblU = cPLrvtRlKnDvCblU;
    }

    if (GOAcvPYDgntYrIQU > 204815.352249492) {
        for (int AprSZm = 1433995819; AprSZm > 0; AprSZm--) {
            cPLrvtRlKnDvCblU += cfGjtQTkVJA;
        }
    }

    if (eepwqYL == string("QkdNRTQxDTEEmUtjdWhXjKnRAlOSRuMSsoncWPruiKyzdEJwQKmZiPJvArfZfzWqjBYPXNiWRxSXHqxMzIGEuxxIJwWCiezfPEmDNpTJvNWFDheBTWbgMHPsVFRxNtXESXzzTiGFXTDknbODqkTGJICxUdFcAUjwckBXHiIjWtdYiWeIWIvTyrTJhgmpVTcWpDbmbLUBEwwXrLhhRcBkkKGmWbUahLKHQzye")) {
        for (int tTtiOy = 1853959522; tTtiOy > 0; tTtiOy--) {
            gHHKuADLiJnJaPc *= gHHKuADLiJnJaPc;
            cfGjtQTkVJA = cfGjtQTkVJA;
        }
    }

    for (int ARnrSjSY = 607780400; ARnrSjSY > 0; ARnrSjSY--) {
        cPLrvtRlKnDvCblU = vdQSmjZHjQrk;
        GOAcvPYDgntYrIQU /= DpRZvSFM;
    }

    return UZYtbSMGi;
}

void OOoVsLNIwuJp::txMnOoaA()
{
    double GWNNtYC = -228591.12603284564;
    int EgZIoSPUMwcxxalA = 1074999078;
    int ZbJqfdnDAlBmtFFm = -1697880821;
    bool sfIQvkzbMFsL = false;
    double xIDQcvwychAZKUWq = -876336.1223046986;
    string flacWmVUSNBhdPv = string("EVrQToGwEJhKKhHsXGyLkRMRIzAPbaHROfVWiXwWQfJzcsyTlmrCtRGwxiDpzwvSAExKFHBdyIraAzkMyYjFTpYPezoLqQIEUFibmWICtdSfROoUUNLZYFbkwrElaLBncCKbgRfFOnBxSYUxjzsbeVfhsQuIIuysAVFPlBKa");
    double WgCxJMLweTuY = -882125.7950001903;
    int NJBIMYlSEIiZgAF = 347684296;
    int RFrqZjJOO = -698255873;

    if (WgCxJMLweTuY != -228591.12603284564) {
        for (int yocmUxybIKBHYvTe = 455057387; yocmUxybIKBHYvTe > 0; yocmUxybIKBHYvTe--) {
            NJBIMYlSEIiZgAF -= ZbJqfdnDAlBmtFFm;
        }
    }

    if (WgCxJMLweTuY != -876336.1223046986) {
        for (int MWIPnn = 1279220934; MWIPnn > 0; MWIPnn--) {
            NJBIMYlSEIiZgAF /= NJBIMYlSEIiZgAF;
            GWNNtYC /= GWNNtYC;
        }
    }

    for (int HNMQWiNMiaiTH = 2031843035; HNMQWiNMiaiTH > 0; HNMQWiNMiaiTH--) {
        sfIQvkzbMFsL = ! sfIQvkzbMFsL;
    }

    for (int XGssPCVCfVrDuJ = 521767819; XGssPCVCfVrDuJ > 0; XGssPCVCfVrDuJ--) {
        continue;
    }
}

bool OOoVsLNIwuJp::XWwjzakvJw(int OjjPknMWyybN, int FvdAHZsLnzKZM)
{
    string ZPJyK = string("duYYwygmqQOEMfeNrogntUWpYtwBUZTKGAzxGLqubQCaIYGrCRhzXbpADIbfyIBiKUknKsTxrDlWFEHhARfCJoshRXQroYoMufeCrMuZKvSAMuOcMzphACWDZsfsbjmhcsoegtEwwHotMEKGGBhYkNMHBYYsyhxxTsfJfDhZGSQoPkngKhDiYYNAoCmHmNSEbEDTlFovWePCvxaaFGdDUkXFPSNCH");
    double kgDXESGBjpQYm = 641656.0109296872;
    bool fpzphYOnfS = false;
    bool sfHwqM = true;
    bool RfVLDKdzjwKKkiwk = true;

    for (int qeeiIPVNrmAIsPyn = 276563179; qeeiIPVNrmAIsPyn > 0; qeeiIPVNrmAIsPyn--) {
        continue;
    }

    for (int XnFXxcBoBI = 1916654829; XnFXxcBoBI > 0; XnFXxcBoBI--) {
        RfVLDKdzjwKKkiwk = ! sfHwqM;
    }

    for (int ecWEqGLYg = 878264613; ecWEqGLYg > 0; ecWEqGLYg--) {
        continue;
    }

    if (FvdAHZsLnzKZM > 626049818) {
        for (int SeGKwUA = 937733779; SeGKwUA > 0; SeGKwUA--) {
            RfVLDKdzjwKKkiwk = fpzphYOnfS;
            kgDXESGBjpQYm -= kgDXESGBjpQYm;
        }
    }

    return RfVLDKdzjwKKkiwk;
}

OOoVsLNIwuJp::OOoVsLNIwuJp()
{
    this->fxrCLgld(976033.4853984347, -764764.9180912568, 1625431507, string("diAKalpsUQhKwUThaOsVFDBPzDRRzxFCjLgiPaIrVugHrbwfBOvIfURcNztDsDXnmsufFQWZEhDnyihEZgcwAPWrTCuItSPSGrZSzuIFpqwvZaKkzdSkaLYGanprJYzphituLCeUdVjyVpsBzxBmFmNwJRlTcakegCUJVFJbUXfLAcgkzQkJZUrNdGBIacBurTTamM"));
    this->tQAmVOSmUrD(string("FvDOpbdonGCPpicibIDeupgPblABkbwaiBQYZpUvhqNNTORyyRQSRWWIVDHUoftDTYAFtiiBDDWMlsboNUZMKruVfTyhnFcmqDPiQWvSzVRlcxJriiFAXxOzKuyaElAwxcWoLjrVr"), string("LDbKOyCoEhCIrVtIOUPnPGBzivbopIAGIFTOAnVqzNTPgBTKFtSqWNaeWtBTdKJHPuxQOFEwtGpFNGewYJMtTMqIdEztARwieUcWhKNgENoKScmYJTWjNfzrqdPva"), -130082.37216156982, 887639786);
    this->liDOWySjHTJlC();
    this->MVLUIEktEDpBJ(true, 423001.4449612411, 4358972, -670323476);
    this->ErkJKKKRSALakvP(1022333.768970724, 1951392983);
    this->eqEZf(true, string("xoFzmWNzZyLaYxcVRQDiVYyOxTDdzYekdRDJpDbYlrZZcoLpniJNoXkRHgrTkSrNxmVatZNILDBUzjviYEIaArabQeTVRuRSPATTtfWfNLtfzIwyoUUydJNgkyqYfKYhJzgZyFnbKWYyOQeZqDIyDkjiOSHPetFmXdexnzuirAHcjsPgdYQaauIgvhHxzzUniTksKJlnCmwgrYCrnqrFRpPyImrBqoqEKGPaxgexmrjMbAhawUqGvhLShSK"), false, -570409142);
    this->ySAgVHhnLfBXcRvc(267467848);
    this->fsdswhWLbrLsS(-185953.19557939668, string("yAqtGnddpJuEWGBUlgKWaUVKGyuumQXhIIhhYFkHboEXQmzcCftizucsEuqbOjsJalYNMlOJoItAiYehBeVBXRlYMilkcyzbeAtWGeDFkwGfekeRqZXcGzqMStMKrrgAfAQEeeQhnLppbxJBWGWgNmI"), 500121441);
    this->kexwWvCbpqzpJo(string("gJAYjHukKPgzeCjqQdJNzcLVFYvcaJaOfNfpFpagAihxyrpFTSLskwmIfqSHcfrPSAqJWEkGILLjhzMKGgfSUHkSczvrtWnwsazlwpIwHbcNuIPWNJnwljJKaheMKWbSipPTIWxkCyCWGaAfgGrpjEZgeyIitJZIrcDLDduWRGzaatklSBJsoGJJbwWZkbRiVkQsHIYXCAQw"), 2126259083, 614746.4465346865, -515992.16248249594, true);
    this->fzMIGEEBw(948889.1112223152, string("UwiwzgvPgqwbpRsmVgshioBEVzBADvKjqtDQdFlALNUlplfkITejnOiCMNzUuauVLRHaKSMngFnjZSQRxTzUHvTlNHBCQzeAAPrYnSpyiAmyrwTKZomVwkiswBSlPXYZMXnoeqmLCFUQHAAVTrhBeitEIHPmxTKFoqLHWogRHwBzoJKGeOrbQYWXIednMWliJgbRDJTiUhHOcXEFLAkHpVB"));
    this->sjDImsqjH(1896981075);
    this->txMnOoaA();
    this->XWwjzakvJw(670831057, 626049818);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hIXnZkdmaZzTQTdl
{
public:
    string fOroksRMCBbfCUVo;
    double UytGOHha;
    string yMOHtafejHz;
    bool EhZeZSembQoyWl;
    string biFuRcRii;

    hIXnZkdmaZzTQTdl();
    string CJsbbblXzHvR(bool WktDGHOQftpAjS, double eniRRJCldUT);
    string EJOoMHHUJv(string pwbZs, double PQjXoqYSDtNvI);
protected:
    bool aZXEoalJNGX;
    double XuoUiqRcE;
    double SdnbJH;
    string DaRFSyspleCuV;
    bool tkOReEwandURrRlz;
    double AlBDBAbU;

    bool EirAs(string EdZhqO);
    string tTkKgFrhgz();
    string fpufArDe(bool pNYfqOqxuVA, bool PXLNZNWpLDwZ, int IxhuCECUxfVVJhqr);
    int ghUkTMXA(int kHlJqzaaYD, double BxshCVXojZR, double MxgkJ);
    string qYbqlSYdgWVw(bool GEIZHWWtzXeB, double HApYcFnlNVrfF, bool MkPqiSAgzl, bool pvjsqJCFctun, double ANRCTucTdXCrb);
    bool DoEBjStoSDDpUSgP(int EkwVnnocYsaKZu, string yVdYs, bool ypHbWJBORjwlN, string bLKjtilCRaQ);
    double JFZNqqqfAwddXX(string FmnEpwyWJLvI, int eMkroXoKZT, int pNZZMsZf);
    int qDWWrtzdLWL(string WzkuA, bool mLYHUvSopwPehu, string BOBkXQxNwoWB);
private:
    int GNVdneGQosDZ;
    double zGtexHcadfcshdj;
    int iBqBgGwEnnQGE;
    string kBRdO;

    double HUtgWcYSuzAUS(double uuNuDeJElK, string TGpmopdPhyX, bool OjRrcndrHA);
};

string hIXnZkdmaZzTQTdl::CJsbbblXzHvR(bool WktDGHOQftpAjS, double eniRRJCldUT)
{
    string DHsLKpYYrTWJ = string("nYFmvstTwthTAcHIvrtLWywJXAKkYhTbZCptNZMtzPVwjyolIaROlwlCDHXAwQSMPDukncYGJdAWPisWEKteKsIJBbgXhntAwmEAdGiusaKpPjiKWEetQxBnUVSdHUKHgrkEQebcHzBIHPjsjoElwhumPGdURaZGlrZyRWBhPxKSpmbkzwqnuclakTxsARsqbIBMWFGmiBkFBBxSiOrtemyZTLolFddDIYStxF");
    int KkNhBgUJne = 2099209119;
    double NYUIeeRsagm = -889314.5140472527;
    double FwoFqzwpGuBqc = -173670.48268446772;
    string cisaFQ = string("JexfJirZEscEfkLFjeFNfaAueHDmlUSLFpvrSPRpDZNOssIImUQfOGLDHTWzrxgwtLERkZUxGmwMSbfRxcWLTtzzRCVWXAUaKbjABpehJlhDYRaXKVbpKvvfCTwPcfhlFpWCCzdFZwNASW");
    bool FqbPPohra = true;
    string vnyrSKnlwtoISL = string("uKcrkXBtOZlWCJdZdlyVjbssVcRpfoXJqRRTKZQQKzfisEirxldKTntkXiVpRZlmTpHeuPAAHZToqcEIajzJePtNjmbNvbTjQabgBcuPmwSPnxlHNniDTSagLcJWvVSUTxeLf");
    string KWzeWNRSCv = string("ThpArkfrswbQbZFAEZgcIimLhOMtkPIOuepieTsJNGGjJmXspUhGpignGmpsLROOvlFDnGUdlyIqabPJTmZajDIHomWAxumXtyfBVExAFMYLMmqZQMrxgObVGYWQaDDXVnfhebiKqJDHHPdjazgrgYhGIo");
    string bspjMGUhUZXgE = string("xcWZeuAeJtTVqNWMJMocBYIKzUBeEslDOTwVoKgbopvtzc");

    if (vnyrSKnlwtoISL <= string("uKcrkXBtOZlWCJdZdlyVjbssVcRpfoXJqRRTKZQQKzfisEirxldKTntkXiVpRZlmTpHeuPAAHZToqcEIajzJePtNjmbNvbTjQabgBcuPmwSPnxlHNniDTSagLcJWvVSUTxeLf")) {
        for (int oOkeUfCvDOsEqpPU = 1239659085; oOkeUfCvDOsEqpPU > 0; oOkeUfCvDOsEqpPU--) {
            vnyrSKnlwtoISL += KWzeWNRSCv;
            bspjMGUhUZXgE += KWzeWNRSCv;
        }
    }

    for (int PmHdE = 1582602765; PmHdE > 0; PmHdE--) {
        cisaFQ = DHsLKpYYrTWJ;
        NYUIeeRsagm = eniRRJCldUT;
    }

    return bspjMGUhUZXgE;
}

string hIXnZkdmaZzTQTdl::EJOoMHHUJv(string pwbZs, double PQjXoqYSDtNvI)
{
    int MEQSvpGmid = -765593244;

    if (PQjXoqYSDtNvI <= 587870.4701115252) {
        for (int thYjUD = 674896184; thYjUD > 0; thYjUD--) {
            MEQSvpGmid += MEQSvpGmid;
            PQjXoqYSDtNvI = PQjXoqYSDtNvI;
            pwbZs = pwbZs;
        }
    }

    for (int IROForztxCCaZYR = 1575575701; IROForztxCCaZYR > 0; IROForztxCCaZYR--) {
        pwbZs += pwbZs;
        PQjXoqYSDtNvI -= PQjXoqYSDtNvI;
    }

    if (PQjXoqYSDtNvI >= 587870.4701115252) {
        for (int xEpLKMFgoPZuZgYe = 111312582; xEpLKMFgoPZuZgYe > 0; xEpLKMFgoPZuZgYe--) {
            continue;
        }
    }

    for (int kaYQOCG = 883450949; kaYQOCG > 0; kaYQOCG--) {
        pwbZs = pwbZs;
    }

    return pwbZs;
}

bool hIXnZkdmaZzTQTdl::EirAs(string EdZhqO)
{
    bool EiKnzQdCNhun = true;
    string hiFcqBkDzV = string("VCIljBsnhQClMXYofwUcedBlyRsQOhaeCePaqRhpsXzNLyEZrmyHzwCwkNyMDKPoKexsVQJSOQqwgtygFDSSxeOKBpjVQpYoFKTtAqpFVYMVXWFXDlTrLbFd");
    int MQMLGIzt = 1548330390;
    int IVRTjALLLcbObY = 1092036151;
    string zNtRv = string("gZcVSLjkjBCUexpHwHCREucNNmhxeHLGgbPpECMiMAqHcEktBgSHFnklysWvbKvSxFqFiVxWmIgRYPLgRxPbyxiCzNEgnmTmDbeYTSXowKoAUmlmtLyKvFKqeCrVIIbYuktbiJcilOGoCdgrEFdeFzaZHpiJHjGmgYmkSGoAMNEoD");
    string myyMJI = string("CPxCAjCfEiAXQYgQBIinmdqXSQyrMIhoENVMbCabIbQLggrvPGZHfWnDJujbHnsqKkVZOFlFAYaANdPeZrXnuJeyMajvfETiPhrnggRkVAbdFRgPzUCMWSbMJNEHjWw");
    bool tUyPiajLXhwbvLb = false;

    for (int SCRRJIcFRBYZmJd = 975017833; SCRRJIcFRBYZmJd > 0; SCRRJIcFRBYZmJd--) {
        EiKnzQdCNhun = ! tUyPiajLXhwbvLb;
        EdZhqO += zNtRv;
        EdZhqO += myyMJI;
    }

    for (int IOOEcxfnL = 1221595018; IOOEcxfnL > 0; IOOEcxfnL--) {
        MQMLGIzt *= IVRTjALLLcbObY;
        EiKnzQdCNhun = ! EiKnzQdCNhun;
        zNtRv += EdZhqO;
        EiKnzQdCNhun = tUyPiajLXhwbvLb;
    }

    for (int NKewA = 624628281; NKewA > 0; NKewA--) {
        EiKnzQdCNhun = ! EiKnzQdCNhun;
        zNtRv = hiFcqBkDzV;
        MQMLGIzt = MQMLGIzt;
    }

    for (int bBgBUzXTph = 1585198419; bBgBUzXTph > 0; bBgBUzXTph--) {
        myyMJI += hiFcqBkDzV;
    }

    for (int VpyPcsb = 1995104722; VpyPcsb > 0; VpyPcsb--) {
        MQMLGIzt *= MQMLGIzt;
    }

    return tUyPiajLXhwbvLb;
}

string hIXnZkdmaZzTQTdl::tTkKgFrhgz()
{
    string hdJzOknGM = string("WmtciEACXgPXSlIccVCdutlNSPDrNRchiEWkRVqYDBIlZBczughynDTzSgi");
    string PdgQNxw = string("NaIKDgspQQSVYGSrBxtsZbQRiykleIHfNoOvccqnyzkwMvpZrmoCVPGr");
    string TfOiLRIdK = string("KQ");
    int QDniwYBK = -1142968725;
    string LGDRYB = string("zmJYSNaRBNuBjWcqUcYpxOTECiVTBiA");

    if (TfOiLRIdK == string("zmJYSNaRBNuBjWcqUcYpxOTECiVTBiA")) {
        for (int jsTfjQGhEUBoyF = 941289652; jsTfjQGhEUBoyF > 0; jsTfjQGhEUBoyF--) {
            hdJzOknGM += PdgQNxw;
        }
    }

    return LGDRYB;
}

string hIXnZkdmaZzTQTdl::fpufArDe(bool pNYfqOqxuVA, bool PXLNZNWpLDwZ, int IxhuCECUxfVVJhqr)
{
    string VLyOE = string("ImLOcpPLFUEyEqWVdIHSqycqZdiyYBAAOekOfRhRORqRYhWULiEqhbeXSqXAUBmZlXLjJJQPFkjoqkUiPVbcGZpjiRYdCLVTwORhBaIsDPFPgZAZHPsoaieHtTQOdPbVRXpbIpVUsNukljIPTRDzFUOrxdNTvtgXqutLxrJcSNipKYHmlosVVUszlMaXOHalchbbImrjfFRffkNnobJvEcs");

    for (int XFSnKMQnq = 246585537; XFSnKMQnq > 0; XFSnKMQnq--) {
        PXLNZNWpLDwZ = ! pNYfqOqxuVA;
        PXLNZNWpLDwZ = ! PXLNZNWpLDwZ;
        IxhuCECUxfVVJhqr -= IxhuCECUxfVVJhqr;
    }

    for (int eRDBQZHBtEKCOTS = 1955051123; eRDBQZHBtEKCOTS > 0; eRDBQZHBtEKCOTS--) {
        PXLNZNWpLDwZ = ! pNYfqOqxuVA;
    }

    if (PXLNZNWpLDwZ != false) {
        for (int iDhjCt = 1610734494; iDhjCt > 0; iDhjCt--) {
            IxhuCECUxfVVJhqr *= IxhuCECUxfVVJhqr;
            IxhuCECUxfVVJhqr *= IxhuCECUxfVVJhqr;
        }
    }

    for (int BnocgLFqtQf = 1213936413; BnocgLFqtQf > 0; BnocgLFqtQf--) {
        PXLNZNWpLDwZ = ! pNYfqOqxuVA;
        pNYfqOqxuVA = ! PXLNZNWpLDwZ;
    }

    return VLyOE;
}

int hIXnZkdmaZzTQTdl::ghUkTMXA(int kHlJqzaaYD, double BxshCVXojZR, double MxgkJ)
{
    int bDDxOsqffbNSxAzM = -603329537;
    bool LPxiv = true;
    int mpDAvZiI = -1182519081;
    double djDHuWRzkdjqGgLh = -220675.316961228;

    for (int CRVazlgZNDcaSZ = 1972529269; CRVazlgZNDcaSZ > 0; CRVazlgZNDcaSZ--) {
        BxshCVXojZR = BxshCVXojZR;
        bDDxOsqffbNSxAzM /= mpDAvZiI;
        mpDAvZiI /= bDDxOsqffbNSxAzM;
        djDHuWRzkdjqGgLh /= djDHuWRzkdjqGgLh;
    }

    if (kHlJqzaaYD == 1439738936) {
        for (int mnpWy = 46633943; mnpWy > 0; mnpWy--) {
            mpDAvZiI -= kHlJqzaaYD;
            MxgkJ *= BxshCVXojZR;
            bDDxOsqffbNSxAzM -= bDDxOsqffbNSxAzM;
            mpDAvZiI /= bDDxOsqffbNSxAzM;
        }
    }

    return mpDAvZiI;
}

string hIXnZkdmaZzTQTdl::qYbqlSYdgWVw(bool GEIZHWWtzXeB, double HApYcFnlNVrfF, bool MkPqiSAgzl, bool pvjsqJCFctun, double ANRCTucTdXCrb)
{
    string LAVlxf = string("SIqPBJivXPjBjCCFYdGsOQohn");
    bool UZoyuFKC = true;
    int oeWxLGqERxWv = -869219935;
    int DrBJOmzBDBY = -1558211977;
    int zJlGP = 1982877414;

    if (UZoyuFKC == false) {
        for (int ApxbpQpE = 2061949697; ApxbpQpE > 0; ApxbpQpE--) {
            continue;
        }
    }

    return LAVlxf;
}

bool hIXnZkdmaZzTQTdl::DoEBjStoSDDpUSgP(int EkwVnnocYsaKZu, string yVdYs, bool ypHbWJBORjwlN, string bLKjtilCRaQ)
{
    int GauHhweoEByyaRc = 1759101343;
    int tMSLC = 1640403367;
    string zjQirIrTVcOE = string("hCNmkIgwfIXFdzWbaeNbIYDPsGXuzTTcsyZqLApmrCQkIycWBTmcBfyRydhztQlUDyfngqocbukMEzBhpVQFGzpGipFRYooOeZyVuwIoQWPjVpRt");
    bool RRmYtIEl = true;
    int tVwHI = -1908447063;
    int JHeBadQccugmXiR = 795376295;

    if (EkwVnnocYsaKZu > 1640403367) {
        for (int lrJaW = 1802272164; lrJaW > 0; lrJaW--) {
            GauHhweoEByyaRc += JHeBadQccugmXiR;
            GauHhweoEByyaRc += tMSLC;
        }
    }

    for (int TdgWoi = 1061378219; TdgWoi > 0; TdgWoi--) {
        yVdYs = yVdYs;
        yVdYs = zjQirIrTVcOE;
        JHeBadQccugmXiR *= tMSLC;
    }

    for (int mjZKSIvop = 1554863023; mjZKSIvop > 0; mjZKSIvop--) {
        tMSLC *= tMSLC;
        bLKjtilCRaQ = yVdYs;
        bLKjtilCRaQ += yVdYs;
    }

    return RRmYtIEl;
}

double hIXnZkdmaZzTQTdl::JFZNqqqfAwddXX(string FmnEpwyWJLvI, int eMkroXoKZT, int pNZZMsZf)
{
    double VvqBEtHKNndNG = 857539.7846915898;
    double aOeDNJmK = -814634.2848859444;
    int hISbkXzoUafG = -155221244;
    bool uvNtyOCiEBChlo = false;

    if (eMkroXoKZT <= -1175884068) {
        for (int cHGiXgWj = 375663304; cHGiXgWj > 0; cHGiXgWj--) {
            continue;
        }
    }

    for (int iqTDWXpwHvgSUz = 1430287623; iqTDWXpwHvgSUz > 0; iqTDWXpwHvgSUz--) {
        continue;
    }

    for (int PvkARkbA = 1660056269; PvkARkbA > 0; PvkARkbA--) {
        continue;
    }

    return aOeDNJmK;
}

int hIXnZkdmaZzTQTdl::qDWWrtzdLWL(string WzkuA, bool mLYHUvSopwPehu, string BOBkXQxNwoWB)
{
    bool nGVOHaamLEWjdd = false;
    double bRsofxIl = 429945.24240704125;
    string swlExRMVJrbxnFy = string("rOqbWTMkoBqnJvZVzdaIJ");
    bool GfIIlpBNbgMe = false;
    double kxtbNx = -1044466.1654407105;

    for (int howpUktWw = 600361850; howpUktWw > 0; howpUktWw--) {
        kxtbNx -= kxtbNx;
        GfIIlpBNbgMe = nGVOHaamLEWjdd;
    }

    if (swlExRMVJrbxnFy <= string("XtLCfokMiyUBiqEstkYQKTPttGRQpdcBklwuJLrMEwZGtCRWFxHEkylrJZrqaDavuDHnjQJpZbyDmSjOyhFkbJXBlAbLxGQDBHbLAuuPnjYMcfHUTZNsHLUnDGuVxiRpVSssIpAMU")) {
        for (int ohjDzMo = 800658396; ohjDzMo > 0; ohjDzMo--) {
            continue;
        }
    }

    if (mLYHUvSopwPehu != false) {
        for (int EpmSMwxnKNwfw = 317089957; EpmSMwxnKNwfw > 0; EpmSMwxnKNwfw--) {
            mLYHUvSopwPehu = mLYHUvSopwPehu;
            BOBkXQxNwoWB += swlExRMVJrbxnFy;
        }
    }

    return 1154699159;
}

double hIXnZkdmaZzTQTdl::HUtgWcYSuzAUS(double uuNuDeJElK, string TGpmopdPhyX, bool OjRrcndrHA)
{
    bool dqmzESgJdvIui = false;
    bool qnDrTPlUd = false;
    double RMHFbCJ = 130324.46551456793;
    string oKrvUFZwffcel = string("wmzvMnljQJSxAwKJsvnjCdarFIdAdGHJuaNBWFZkSnKkgDNYYCDjUaSqGQDgUXizeOzqEIyvYBNDevjPNPSMKoujuGAaxXikJZyCJvNzqXulyuAOYcChiKOnHWGmZFCeuRdRCIJdPEiZsNCuLcEqbTzlWIuDGKjfWOEvKpyUIUOMKwXJIXyrdVPpnlOPuMnlDUWyLpVbwFBSRwwF");
    string XdVcY = string("URGSzspZhtFjAKkFJuTxGZlvUQYsuqJpDsVGqdNJvsTT");
    string UhlpPfQgMedam = string("nnLoPIWgGiefNUCaiSxpXxYoyICQQWmqIecJUmQUqFW");

    for (int CTOWTlbzxkkls = 102685887; CTOWTlbzxkkls > 0; CTOWTlbzxkkls--) {
        continue;
    }

    if (oKrvUFZwffcel > string("nnLoPIWgGiefNUCaiSxpXxYoyICQQWmqIecJUmQUqFW")) {
        for (int fULYQaUjcDWOgH = 1912270942; fULYQaUjcDWOgH > 0; fULYQaUjcDWOgH--) {
            uuNuDeJElK /= RMHFbCJ;
            XdVcY = TGpmopdPhyX;
        }
    }

    return RMHFbCJ;
}

hIXnZkdmaZzTQTdl::hIXnZkdmaZzTQTdl()
{
    this->CJsbbblXzHvR(true, -187795.87195331493);
    this->EJOoMHHUJv(string("vrKOkOumQlEDQNagkkiWraHwMEIYmCvtXUXZyHUwfKXccKqDsethgDdAyXGDyDAMtovboWimSrqcNdfrgexvuyTDEClchgIBJUEsukBgmGRvkKitYGxAfNhjrRIzGGMIedPFjAoAYpfDu"), 587870.4701115252);
    this->EirAs(string("rctnyYIoDieAWDfPVvmmJhJQubakzmtMsBLQEUDaWcXHMfTkusEJaPJGGCfHuTEUnGyYujLfALUNOLPluDYtkfgbYIMQLuXiRCFcRCsCRnhnRALRDAlirMrQmDtOhcqzQjflNnTteqVLKBSZNpBLoEYwaHfuyQwEPgwSanFyABVobexlahDBMveiQObAwLimawcutwAuZxxxjDhPbs"));
    this->tTkKgFrhgz();
    this->fpufArDe(false, false, 696588496);
    this->ghUkTMXA(1439738936, 391494.84192554944, -789478.7543731339);
    this->qYbqlSYdgWVw(false, 1020752.1934807178, false, true, -242520.0432616225);
    this->DoEBjStoSDDpUSgP(1122353793, string("PmxzZlDduNTgUffofExjJoBNqOqrrXNWDyXTvKrHTrczttFFVGWuPtTyCzcNuuvZYtonPdXdMgCrpiPjNXBbuSXdrBljZovDNIYwefJUHomVMNQHYjiFELwKoaOGbBBvaRKSymHcSYClxVukoZYqfUtUSvlvjvJWQMHpxpPtUSpTdRtNdiDyxalpUzOzKNHdFTTNzLOSHXLUStnAqbzCy"), true, string("oSyeIAtdiOuSMYlULmOkVJhbIkVEfznYDWpVGXgLXhVV"));
    this->JFZNqqqfAwddXX(string("MZcTkqwRWSVrjrEzsYzNBlWOkhhQyOQnCROVOLCvbDDdmAKgJrdaAJmFWIcLOViISjkJBuqgdMkuypegHUXYergvSjKLDXHVsZAxlWcxgFANiyShinBuHgvyzxPxyCsvLNsmYiOvTSYRrtoNRfhGPxzSqFRbChMpLpgrfSmAFhiiHdacoZqjPneadNnamjw"), 510797323, -1175884068);
    this->qDWWrtzdLWL(string("C"), false, string("XtLCfokMiyUBiqEstkYQKTPttGRQpdcBklwuJLrMEwZGtCRWFxHEkylrJZrqaDavuDHnjQJpZbyDmSjOyhFkbJXBlAbLxGQDBHbLAuuPnjYMcfHUTZNsHLUnDGuVxiRpVSssIpAMU"));
    this->HUtgWcYSuzAUS(122943.48577176839, string("pJYrUstPEHTMNdOSbJzaOnfudWpUkbxWvDJwDEokYBEcOgNyBZAXiHhnctePvdgJwGZhWb"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PYYTpobHrpJaTWA
{
public:
    double biHpXcTMQZum;
    string yJlXncWBzLL;
    string dZWuxSquyAh;
    bool EFbNkcOqUNpgrrsn;

    PYYTpobHrpJaTWA();
    string ItbPOdVR(double tBFefMUPRN, string vDiePxZbM, bool uAUZILFjlrk);
    bool yEjfmqSYcIf(string XTHxgbcxoXCBYVY);
    double cYREvDG(bool kahiZAZlXEbYXw, string xRnhC, double XHkxwOk, double PnCOirsUtfv, bool TigAoEmgc);
    bool rcQNapr(double gOskuBKWb, int kTdcEqzVDipGXDSq, string NaznHfnWs);
    bool hWlJdln();
    bool EZkjn(int ehryDis);
    int VlLZkT(bool hCLPPK, int DnhpurTdkU, bool QFERPKUPknnl, bool trjEYr, int YhlQbTjmbU);
    bool folrMJsH(double xzLBByaUi, bool MjZImClmAReIhDl);
protected:
    string tzfwCnaFAXM;
    double zoBekEnELrxDKrj;
    string Wkuvd;
    int udnKzjghfjoQKwDS;
    string lSusqM;

    bool rdDMDpL(bool DrRTdfNchdDjX, double LtYVso, double ONYXdPnKKbibtF);
    int wvvALS(string eEPJLbKtK, int lePQjXQx, string znQPLu, bool gqBxfvRUVTmtterf);
private:
    double lTwswXxNQZG;
    double AEYJhS;
    string qGdwKADvw;

    bool mKmHqu(int ZqOxdgKvtKuO, double ruVndgrlNV);
    double XTbfxxFN(int xuODbbWgZ, double NHedVWE, int lVFqgjNfMopFWnt, string GYgCkPfODSt);
    int wIANRH(int wCeNWmfJyN, double loLuB, bool zjPnC);
    void bnFJSjlmOIsrQ(string dbNAQ, string OlmkLCWhtXtMh, bool soinLYtqFkMqiL);
    double wTbXnsqTZVtE();
    string aJuGZiMttYnYvroS(int mrpjEAiGwHc, int fvhDtFGLCkWLXG, bool uxxdbjMgEUE, int JaeuBfXBdoGO, string kKWCUstLYr);
};

string PYYTpobHrpJaTWA::ItbPOdVR(double tBFefMUPRN, string vDiePxZbM, bool uAUZILFjlrk)
{
    bool LzcNkGapKMcASLD = true;
    string ZHputBLOXN = string("deTBbHhQByJXJcKbXOmjFUTpvcojHTzyIDPuPBuvCNyaSdeGqqoKMJqwUtpCuLAUQJhIjAKgyivqgeUnzqdOyawCezpWQRqfmelBoaARBkofpVgzsHWGJoyFxuuOwcybOGchnUOulWMAxxSLrBcrFAZPzKYIDOHvtucUAYIUphBroBGeNMdPyYMivyeYttx");

    if (vDiePxZbM == string("deTBbHhQByJXJcKbXOmjFUTpvcojHTzyIDPuPBuvCNyaSdeGqqoKMJqwUtpCuLAUQJhIjAKgyivqgeUnzqdOyawCezpWQRqfmelBoaARBkofpVgzsHWGJoyFxuuOwcybOGchnUOulWMAxxSLrBcrFAZPzKYIDOHvtucUAYIUphBroBGeNMdPyYMivyeYttx")) {
        for (int qCPLlula = 893628716; qCPLlula > 0; qCPLlula--) {
            ZHputBLOXN = ZHputBLOXN;
        }
    }

    return ZHputBLOXN;
}

bool PYYTpobHrpJaTWA::yEjfmqSYcIf(string XTHxgbcxoXCBYVY)
{
    int icBoClmRamRNlWx = -1294686180;

    if (XTHxgbcxoXCBYVY != string("PrHtsFuzIRBtXlBQnCEbhtTTMlmpLuwWWzsXdbsSGtqkMifwNPjKlIvrvRpQYxhCbmAiRubFmxeLVtzkozfOFUSlbSOjXIKFrkBubahCrcEpiuACMXTazTJPijWMwJxmCntlFcUHyzeeUQyoiTVBBTHoIKIohOiLSZUwDGnvNWUOUlFLNiQQbavozJFObtxZMEStIRp")) {
        for (int bawYdd = 789056373; bawYdd > 0; bawYdd--) {
            icBoClmRamRNlWx -= icBoClmRamRNlWx;
            icBoClmRamRNlWx -= icBoClmRamRNlWx;
            icBoClmRamRNlWx -= icBoClmRamRNlWx;
            icBoClmRamRNlWx += icBoClmRamRNlWx;
            icBoClmRamRNlWx = icBoClmRamRNlWx;
        }
    }

    for (int QitCfS = 1582033079; QitCfS > 0; QitCfS--) {
        continue;
    }

    for (int VHNRwSET = 1820215906; VHNRwSET > 0; VHNRwSET--) {
        icBoClmRamRNlWx -= icBoClmRamRNlWx;
        icBoClmRamRNlWx /= icBoClmRamRNlWx;
        icBoClmRamRNlWx -= icBoClmRamRNlWx;
        icBoClmRamRNlWx /= icBoClmRamRNlWx;
        icBoClmRamRNlWx = icBoClmRamRNlWx;
    }

    for (int ERUbWUjCtxpq = 521063091; ERUbWUjCtxpq > 0; ERUbWUjCtxpq--) {
        icBoClmRamRNlWx += icBoClmRamRNlWx;
    }

    return true;
}

double PYYTpobHrpJaTWA::cYREvDG(bool kahiZAZlXEbYXw, string xRnhC, double XHkxwOk, double PnCOirsUtfv, bool TigAoEmgc)
{
    bool SWSQdJht = true;
    string wIxmcRcq = string("abWxkNzUwoCTfSFvNBrAgNOYClMPYvXVuXkGAoeErHghzXzISINQpyySimZunxrSKRJKxEyoLoDVeBXexthRGahlsJngMdcheKWcMhrJhsfwFQOohkItKPAkrvmnwPCvJDhNYEplUdoVIKTrPvkEzBtAwOHGSskjYxeVJUJZfyhyeJqJEtRupHzKLnaHAEknnoAruPyPtUPyIyMBQQfuTsYshcCK");
    string vYjzmJnA = string("KBCIbeaMcqIvhrEJjafzwoTCWvamwCAuPihJpHlWmNhBInlKkrpNhJIYreYisOkgHZXYKxDXpOWNbsCNDmVcoWIDvfkrrOjeKYmnRkOdtlQoSKSanOdBgqoBWDEMBBAGPFaNJZQARUykWYNFBvfqUoTTKHJiciMHpdJJetKdQsTpCYXntPQDBATnjYgPbjPZvkEvvhAKAcQYmZfv");
    bool xuJNctBMyk = true;
    bool eASUBgJA = true;

    for (int WuYknd = 1322574050; WuYknd > 0; WuYknd--) {
        xuJNctBMyk = xuJNctBMyk;
        eASUBgJA = kahiZAZlXEbYXw;
        kahiZAZlXEbYXw = xuJNctBMyk;
        eASUBgJA = xuJNctBMyk;
        kahiZAZlXEbYXw = ! TigAoEmgc;
    }

    for (int eMWqKxm = 1995205719; eMWqKxm > 0; eMWqKxm--) {
        xRnhC = wIxmcRcq;
        eASUBgJA = ! kahiZAZlXEbYXw;
        SWSQdJht = TigAoEmgc;
    }

    for (int ebZmeNX = 64051609; ebZmeNX > 0; ebZmeNX--) {
        SWSQdJht = SWSQdJht;
    }

    for (int xGQGeq = 1939492379; xGQGeq > 0; xGQGeq--) {
        xuJNctBMyk = TigAoEmgc;
        SWSQdJht = ! TigAoEmgc;
        eASUBgJA = ! xuJNctBMyk;
    }

    return PnCOirsUtfv;
}

bool PYYTpobHrpJaTWA::rcQNapr(double gOskuBKWb, int kTdcEqzVDipGXDSq, string NaznHfnWs)
{
    bool CKeaenTdgleLn = false;
    bool qWnhquxuSdYim = false;
    bool puonyYMHJ = true;
    string xTbdftTLpL = string("czHtaBlJQOnxTSZoXiANOgEvfJImgiRGfhWNyudmdFWiTqQCCUojmIDBHryzstfEaSGhfgRkdthMjIEGdqZJaKXnSZaHkwIJDuutIZYuxvkSCyazmkrAuAXVhbRisMlQPfHFSTKaRwFDhpguFIuczWhtYANtvuxx");
    string teQRNvCrqaYUA = string("UQYPICQCUnXqwyFMSXapiOkgXHLXQvWKZBrnYpzUjdtxLyXgzvKmNtcHcStRuVAGUqHyLLZGhrZBTWDtkYYiVFOcFNXnSqCByWLGOuAZXGOcUhDitbkpvdnJXXTfjubRDSdlVakIxZIbBMVhEIYmkzyK");
    bool VkOSxKvUpuOC = false;
    int XfAGBybDQJNhf = -1995064168;
    double RggcwVJxheDTY = 562223.0883232217;
    bool nfKrUYtfq = true;

    for (int AuMQhSNo = 1738909248; AuMQhSNo > 0; AuMQhSNo--) {
        VkOSxKvUpuOC = puonyYMHJ;
    }

    return nfKrUYtfq;
}

bool PYYTpobHrpJaTWA::hWlJdln()
{
    bool oTHwFNdWrgzSYB = true;
    double ptaYLOud = 503778.283981855;
    bool UxUdwKFRj = false;
    string AzPEwWu = string("LjhCEhaJjIGBuoUiIaQnVVrjtPvIXVXQdjzVAthmglLmlCqxgOGpScAMtrZeeoxeIspJqNDuGzVuHSGksBLSZGwMLwZKFWuIUlPsWapqYifexDWvHOkfRbSE");
    bool FbeQAjXadrQCSA = false;
    string ExBJgTAI = string("YJJQPLtRoyEefqacGkAxydjrzMtQcjOUjnuZerOwJdlfWpOMuMwBZvmQjQkoAzcSvQBylweiSiCrPEzvRNQDjukAkyLjClcRfDNodEynbmabAmnuFYfoOCAxsRxzVakpGOeuWVnEuIeeUQSAwbKzqCvWiteBqduZxITTqmEwSUnNlgsdzEbsNtfHvevvaPvtuQWcdaQRmEznLAFzYK");
    string CJlpyz = string("fWxwdjTZDRAEyKbsYLNfassMEQKEuTBmRKHVzzolIBRonknVDKsiisccgYGVsOMHOhKtRkJCGbXjDyJgVMNJEhQKxLYtGuKpwDXtMtVSbeCKFXndAuNMWmGpboPBnMTAFwvQxnNxcSfXwyAhVGgkrBWPFwMRHDOvznZQpjphUMaJzPBnh");

    for (int qMoTbftx = 199888575; qMoTbftx > 0; qMoTbftx--) {
        AzPEwWu = ExBJgTAI;
        FbeQAjXadrQCSA = ! FbeQAjXadrQCSA;
    }

    if (FbeQAjXadrQCSA == true) {
        for (int PupkEJcAZPmoYFL = 1542107422; PupkEJcAZPmoYFL > 0; PupkEJcAZPmoYFL--) {
            continue;
        }
    }

    return FbeQAjXadrQCSA;
}

bool PYYTpobHrpJaTWA::EZkjn(int ehryDis)
{
    string IXxlAwuAnYKc = string("RldaeLQVyTFVFVAGKEyNBiBKKLbcycECNupMRQOxKuogKLYNzYfBVzqaLPyFPylESBQuIEIFWRNDB");
    bool ZlhKoeOiuNMl = true;
    double QpHYrKeGexUTREv = 782915.1089668438;

    for (int mIrDuEdhWLYkgag = 1970905350; mIrDuEdhWLYkgag > 0; mIrDuEdhWLYkgag--) {
        ZlhKoeOiuNMl = ZlhKoeOiuNMl;
        IXxlAwuAnYKc = IXxlAwuAnYKc;
        IXxlAwuAnYKc += IXxlAwuAnYKc;
    }

    if (QpHYrKeGexUTREv == 782915.1089668438) {
        for (int KNlqYWUVyKWFI = 1861483891; KNlqYWUVyKWFI > 0; KNlqYWUVyKWFI--) {
            ZlhKoeOiuNMl = ZlhKoeOiuNMl;
        }
    }

    for (int Gsbeu = 955923970; Gsbeu > 0; Gsbeu--) {
        QpHYrKeGexUTREv = QpHYrKeGexUTREv;
    }

    if (QpHYrKeGexUTREv >= 782915.1089668438) {
        for (int NHRokFaMTtpI = 892119241; NHRokFaMTtpI > 0; NHRokFaMTtpI--) {
            IXxlAwuAnYKc = IXxlAwuAnYKc;
        }
    }

    for (int jeZnZyFZBlyJ = 1314372403; jeZnZyFZBlyJ > 0; jeZnZyFZBlyJ--) {
        IXxlAwuAnYKc += IXxlAwuAnYKc;
    }

    for (int AwzxaEmaNokqUy = 458623534; AwzxaEmaNokqUy > 0; AwzxaEmaNokqUy--) {
        continue;
    }

    return ZlhKoeOiuNMl;
}

int PYYTpobHrpJaTWA::VlLZkT(bool hCLPPK, int DnhpurTdkU, bool QFERPKUPknnl, bool trjEYr, int YhlQbTjmbU)
{
    string UDtCFoXGbxiGs = string("FpYEeopJPPnxQoSNVpFMDpfMWpwnTrwPGtdDZHRmdWCenettUQIofjNKkOVaJDvPBnnzfZoDtsCnhYxfqJBxKWhRzdaHqhNKxUOQyvGTXVsra");
    int HWxiEjyNjNKPHnt = 1855219140;
    double LVrdBCPBywOc = 568837.7082084683;
    string XKcRGpXB = string("LnGiTLeqqhECXjHcdvFJVBVYBtJtlMWyeMJGhQlnFrTDOVmGfngIrrhmeGgytGNMYJpZWmpAdRXBtOvenPctOMDcCaSvougGiLvckYjkysoagofAVkAMqsZpxpnnbBTkypNFtghxstoaGgdZTSxMCjfzihLEHrzzxrTSmATyB");

    for (int YQwebQg = 1747442967; YQwebQg > 0; YQwebQg--) {
        XKcRGpXB += UDtCFoXGbxiGs;
        XKcRGpXB += XKcRGpXB;
    }

    if (hCLPPK == true) {
        for (int xPdRAUmNvrSwuFJ = 324010688; xPdRAUmNvrSwuFJ > 0; xPdRAUmNvrSwuFJ--) {
            YhlQbTjmbU -= YhlQbTjmbU;
        }
    }

    for (int hiPrQO = 346421803; hiPrQO > 0; hiPrQO--) {
        YhlQbTjmbU -= DnhpurTdkU;
    }

    for (int hBBKJXOvUOs = 1211395991; hBBKJXOvUOs > 0; hBBKJXOvUOs--) {
        DnhpurTdkU -= DnhpurTdkU;
    }

    for (int AQYUA = 1342303213; AQYUA > 0; AQYUA--) {
        trjEYr = QFERPKUPknnl;
        DnhpurTdkU *= DnhpurTdkU;
        LVrdBCPBywOc /= LVrdBCPBywOc;
    }

    for (int hsXLrPiNXxFYJ = 1110914565; hsXLrPiNXxFYJ > 0; hsXLrPiNXxFYJ--) {
        DnhpurTdkU *= DnhpurTdkU;
    }

    return HWxiEjyNjNKPHnt;
}

bool PYYTpobHrpJaTWA::folrMJsH(double xzLBByaUi, bool MjZImClmAReIhDl)
{
    double vzUrypdTBpNsnY = 684379.3985847839;
    int hYaZPItDCqvXrcJx = -1920776982;
    double cxYiUjjeJMcI = 952360.893752652;
    double LBRjQ = -488331.21075574704;
    bool rWtBKHmmPMkMQ = false;
    string hYtdFF = string("EOZGBoWiCmFlavYSGgHmzKiohPmiWawDkTAskuXxtvFXDeEBGKTVnwhk");
    double UcXxCCNfrnGGO = -929634.4006093048;
    string QDzEEqKNnpXHSY = string("ARzUnSywNg");

    if (cxYiUjjeJMcI > 684379.3985847839) {
        for (int cHJYa = 1889017461; cHJYa > 0; cHJYa--) {
            vzUrypdTBpNsnY -= UcXxCCNfrnGGO;
            cxYiUjjeJMcI -= LBRjQ;
        }
    }

    for (int PsaurnVpjzdq = 871095246; PsaurnVpjzdq > 0; PsaurnVpjzdq--) {
        continue;
    }

    for (int SFtqqZZchygiqImk = 597066461; SFtqqZZchygiqImk > 0; SFtqqZZchygiqImk--) {
        MjZImClmAReIhDl = MjZImClmAReIhDl;
        UcXxCCNfrnGGO += cxYiUjjeJMcI;
        cxYiUjjeJMcI += UcXxCCNfrnGGO;
        LBRjQ /= vzUrypdTBpNsnY;
        hYtdFF = hYtdFF;
    }

    for (int SdkwaAKOXYyCIUZc = 2115328561; SdkwaAKOXYyCIUZc > 0; SdkwaAKOXYyCIUZc--) {
        cxYiUjjeJMcI /= UcXxCCNfrnGGO;
    }

    return rWtBKHmmPMkMQ;
}

bool PYYTpobHrpJaTWA::rdDMDpL(bool DrRTdfNchdDjX, double LtYVso, double ONYXdPnKKbibtF)
{
    int tNNrtxLkhsrzGjlC = 1199780596;
    string YFBNRWdpsDGz = string("YpwmxnnpnI");
    int QsWisnnQVl = -1690376020;
    double eHiCYeGZIwp = -81795.86458737073;
    int WWVMrCsDfBnevXot = -491421991;

    for (int uiKQVTKTc = 401250456; uiKQVTKTc > 0; uiKQVTKTc--) {
        DrRTdfNchdDjX = DrRTdfNchdDjX;
        DrRTdfNchdDjX = DrRTdfNchdDjX;
        DrRTdfNchdDjX = DrRTdfNchdDjX;
        LtYVso = ONYXdPnKKbibtF;
    }

    return DrRTdfNchdDjX;
}

int PYYTpobHrpJaTWA::wvvALS(string eEPJLbKtK, int lePQjXQx, string znQPLu, bool gqBxfvRUVTmtterf)
{
    bool OxDFBObnKhUtDevY = false;
    string lvHAVhhRfgpJu = string("pMNQCnJDMOAreVQUtyajl");
    int cxeISmIN = 1079326886;
    int bYClGZIxbq = 1093802639;
    int UQksiTmRMcz = -797592924;
    string ojfPurwOYGHovTbd = string("eVccRPVfbIgtjPJEZWjIkvIiuqLsLbfOcgPsKyBkENUxCspYjxpiUoOBbQOECjxzevSbXdlfuFABtWWXqZlDhdWvsOHMsPuqEIwpUfYvdxONPHWRkjFOOKqJVghDvNtiVbipdcswvUnzaNuPMIfOugZsMMKzxDAirjZqHldQiGCC");
    double gVGOyYCmH = -693932.7228840564;
    double qrOnzuiKlsdeMJ = -174904.20098260723;

    for (int oCGbPHmUE = 1182306106; oCGbPHmUE > 0; oCGbPHmUE--) {
        ojfPurwOYGHovTbd = eEPJLbKtK;
        gVGOyYCmH *= qrOnzuiKlsdeMJ;
    }

    for (int QIXiAGqljtqGcGer = 1448063740; QIXiAGqljtqGcGer > 0; QIXiAGqljtqGcGer--) {
        ojfPurwOYGHovTbd += lvHAVhhRfgpJu;
    }

    for (int hIDZFZjdjNJ = 429866812; hIDZFZjdjNJ > 0; hIDZFZjdjNJ--) {
        ojfPurwOYGHovTbd += znQPLu;
        lvHAVhhRfgpJu = znQPLu;
    }

    for (int NpmNhLApMGPAXANS = 1459755228; NpmNhLApMGPAXANS > 0; NpmNhLApMGPAXANS--) {
        znQPLu += ojfPurwOYGHovTbd;
        bYClGZIxbq *= cxeISmIN;
    }

    return UQksiTmRMcz;
}

bool PYYTpobHrpJaTWA::mKmHqu(int ZqOxdgKvtKuO, double ruVndgrlNV)
{
    double wlVrkINja = -515529.355775453;
    int epbXn = 12293664;
    double jhNQjhgbipig = 552142.3404459241;
    string XXwBykkKmQieQNxV = string("mpySdhaMsMedNiljJTYlRzhfOlylDXOBnjfCkzKfFOYrdUKRrqPSVuTgd");
    int kRLlGuC = -1003026333;
    int TNIOSWs = 469728618;
    bool qnktAjVrChybKaF = false;
    string JzFUTUzJoFbcA = string("CAcJfSQFlmokPKWQAemybvfkgBFptwLPbLKheJOPcsfq");

    for (int lXgdrAXJ = 1557185611; lXgdrAXJ > 0; lXgdrAXJ--) {
        continue;
    }

    for (int dcjwdzzRG = 1388871322; dcjwdzzRG > 0; dcjwdzzRG--) {
        ruVndgrlNV /= jhNQjhgbipig;
    }

    return qnktAjVrChybKaF;
}

double PYYTpobHrpJaTWA::XTbfxxFN(int xuODbbWgZ, double NHedVWE, int lVFqgjNfMopFWnt, string GYgCkPfODSt)
{
    double WaixFEHybIDza = -682456.7568411201;
    int QmhUlu = -1814451407;

    for (int hQdQcdukCEmDxG = 493220517; hQdQcdukCEmDxG > 0; hQdQcdukCEmDxG--) {
        lVFqgjNfMopFWnt /= lVFqgjNfMopFWnt;
        xuODbbWgZ *= QmhUlu;
        WaixFEHybIDza = WaixFEHybIDza;
    }

    if (QmhUlu >= -1547683348) {
        for (int unIxAmZWfvTuBCPz = 288251488; unIxAmZWfvTuBCPz > 0; unIxAmZWfvTuBCPz--) {
            continue;
        }
    }

    return WaixFEHybIDza;
}

int PYYTpobHrpJaTWA::wIANRH(int wCeNWmfJyN, double loLuB, bool zjPnC)
{
    int KSyyYwCuHBLnnckA = 1748004480;
    bool JNdGJwJ = true;
    double qPTZQcKYYAoMoS = -571848.0546658915;
    double gTykprS = 937372.7838261847;
    int hQpgllHOD = -973989972;
    string WqYMMlfWrYn = string("qgbmCJBXUQKXeyBTvQnrpIynMxdnAbiCpUgeQiYpAAPkymSPdSexUkSEmkCEJlhJzcwGmpGAyqhWeKJMvkLxjaepQlZxHoaIYUoTPJIwwSUqzjRYsOMYwhitGnxFwZnRJtWGdJJGDcBghCrqFCFJQZmuPMCFQTmXqMdjfPVlbzlowARWQijJgyNPxKyjI");
    string ihGwBqSGOj = string("tfYKSbkbYkktZkRLaDXOnpeozGqFBPRpMWLyqEJuTABECPhZotItj");
    bool yxRUJWF = false;
    bool RJbBS = false;

    for (int qZNJmPrpdsH = 443208584; qZNJmPrpdsH > 0; qZNJmPrpdsH--) {
        continue;
    }

    if (wCeNWmfJyN <= 120576644) {
        for (int UArgrxJTIE = 2042452432; UArgrxJTIE > 0; UArgrxJTIE--) {
            zjPnC = RJbBS;
        }
    }

    for (int FYvRI = 646652638; FYvRI > 0; FYvRI--) {
        zjPnC = ! zjPnC;
        zjPnC = RJbBS;
    }

    if (zjPnC == false) {
        for (int DnroMVVZlQx = 1675288493; DnroMVVZlQx > 0; DnroMVVZlQx--) {
            loLuB = qPTZQcKYYAoMoS;
            loLuB -= gTykprS;
        }
    }

    if (yxRUJWF != true) {
        for (int wEaRJBWPiEhze = 872517087; wEaRJBWPiEhze > 0; wEaRJBWPiEhze--) {
            qPTZQcKYYAoMoS /= loLuB;
            ihGwBqSGOj += ihGwBqSGOj;
            yxRUJWF = ! yxRUJWF;
            ihGwBqSGOj += WqYMMlfWrYn;
        }
    }

    return hQpgllHOD;
}

void PYYTpobHrpJaTWA::bnFJSjlmOIsrQ(string dbNAQ, string OlmkLCWhtXtMh, bool soinLYtqFkMqiL)
{
    double hvWKvsMDmjPbchZ = -570257.9700982433;
    string RKVLBxxNuTGOP = string("XXbAHtLMllSsPVMvrdtvMbXSeTjGOGeDlvpKMwkBDvVmtiehLOXggpaIGzJBxdhxPihfXiJppcurZRRBILSwJvHazXyyrDcApKJxuGOjeaFxGYWkGtZvESBnSlnPvQJCJiYUyFLgFffXRblxvEEZVbpWhAVPtOKOnmCbusvqwyDklNaGyFNdLARgyyNDpSdHdWjwvumjmWNjEhEraLEJwMzwjrEX");
    string WVeqIXkHaOIQl = string("QqhpPzBeRUDidalMeJCIbknsxInrLQISaJznFoKDbtlUhoqCTJHUaFhlJIzelhybzuSHXrjZNuGzaXSdSUMOfVxYqDUgwWSCEuFTBNHudfoZgjpRsoiblHIAVYNtmspMhCDkyvyEdywmIJPakuXvQjAIpnysZIeerbynWJsVtwRLVRMHZhudpNxcyUVlSIZCWtpNxnnlXKcsMunzJTDpEucFNgdlS");

    for (int FvVDipMoq = 2014029941; FvVDipMoq > 0; FvVDipMoq--) {
        dbNAQ += dbNAQ;
        RKVLBxxNuTGOP = OlmkLCWhtXtMh;
        dbNAQ += OlmkLCWhtXtMh;
    }

    if (dbNAQ > string("wsZvFSHBMLYzToRWwaZUHgzPnzdhYuafsQmDCmzGSjiycbJSJNic")) {
        for (int FOjQwBv = 1371135798; FOjQwBv > 0; FOjQwBv--) {
            OlmkLCWhtXtMh = RKVLBxxNuTGOP;
            OlmkLCWhtXtMh += RKVLBxxNuTGOP;
            WVeqIXkHaOIQl = RKVLBxxNuTGOP;
        }
    }

    for (int sxpKygJnbYAh = 2112154864; sxpKygJnbYAh > 0; sxpKygJnbYAh--) {
        WVeqIXkHaOIQl = OlmkLCWhtXtMh;
        soinLYtqFkMqiL = soinLYtqFkMqiL;
    }

    for (int wflTKjQGcPmSWhCb = 1670651536; wflTKjQGcPmSWhCb > 0; wflTKjQGcPmSWhCb--) {
        WVeqIXkHaOIQl += WVeqIXkHaOIQl;
    }
}

double PYYTpobHrpJaTWA::wTbXnsqTZVtE()
{
    bool mKoCANEAjLjP = true;

    if (mKoCANEAjLjP != true) {
        for (int WFNOcR = 1766826857; WFNOcR > 0; WFNOcR--) {
            mKoCANEAjLjP = mKoCANEAjLjP;
        }
    }

    if (mKoCANEAjLjP == true) {
        for (int bmOcVw = 64892896; bmOcVw > 0; bmOcVw--) {
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
        }
    }

    if (mKoCANEAjLjP == true) {
        for (int MHvOqffyXyO = 394417531; MHvOqffyXyO > 0; MHvOqffyXyO--) {
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
        }
    }

    if (mKoCANEAjLjP == true) {
        for (int RKcFbj = 199783282; RKcFbj > 0; RKcFbj--) {
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
        }
    }

    if (mKoCANEAjLjP == true) {
        for (int eqBXZKsyLhphCqsP = 1990033272; eqBXZKsyLhphCqsP > 0; eqBXZKsyLhphCqsP--) {
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
            mKoCANEAjLjP = mKoCANEAjLjP;
            mKoCANEAjLjP = ! mKoCANEAjLjP;
        }
    }

    return 708077.6580504067;
}

string PYYTpobHrpJaTWA::aJuGZiMttYnYvroS(int mrpjEAiGwHc, int fvhDtFGLCkWLXG, bool uxxdbjMgEUE, int JaeuBfXBdoGO, string kKWCUstLYr)
{
    bool PijepDBoPqXZd = true;
    bool DhLnrQNMtltuuGe = false;
    string XejiB = string("YodyfOqyVYJXAtqYvzNQpFpgliTfVYIWUOmFZCBSiRheXNJDhnGnmMyPwqJWhUufcyBBsymWwckoRyldwCnemxWqFVvqp");

    for (int qrqJkBkumTvmXpy = 1573892886; qrqJkBkumTvmXpy > 0; qrqJkBkumTvmXpy--) {
        JaeuBfXBdoGO *= JaeuBfXBdoGO;
        uxxdbjMgEUE = ! uxxdbjMgEUE;
    }

    for (int YWGFwW = 835881957; YWGFwW > 0; YWGFwW--) {
        XejiB = kKWCUstLYr;
        JaeuBfXBdoGO /= JaeuBfXBdoGO;
        uxxdbjMgEUE = ! DhLnrQNMtltuuGe;
    }

    return XejiB;
}

PYYTpobHrpJaTWA::PYYTpobHrpJaTWA()
{
    this->ItbPOdVR(-1007353.8275140604, string("pHOJVeLBYSIZNeqhXeftYmUniTAHcqIrOjSRDblFMNAZwFDAounPmaAXlQxFpjzfJAfNQHGLTPxzbzQJUhAQhabrBtYkCjOgtpvwDeuigJwdNHuzZVzzcCICEHSqkxNqXBVPz"), true);
    this->yEjfmqSYcIf(string("PrHtsFuzIRBtXlBQnCEbhtTTMlmpLuwWWzsXdbsSGtqkMifwNPjKlIvrvRpQYxhCbmAiRubFmxeLVtzkozfOFUSlbSOjXIKFrkBubahCrcEpiuACMXTazTJPijWMwJxmCntlFcUHyzeeUQyoiTVBBTHoIKIohOiLSZUwDGnvNWUOUlFLNiQQbavozJFObtxZMEStIRp"));
    this->cYREvDG(true, string("FORvBgPmVbtbPldSaIMKXJMDgwBhKjSHxjClXiEktePkpsHtKzrBjIF"), -115174.92701884682, 371782.73374058324, false);
    this->rcQNapr(762799.0748455011, 396692045, string("uvqsESYSMXMlwJCSyBsupMmRhQbmnzYoLmDyvoSlBDqEYKZhYAhKdDTqpCJfRBxixJxeGYNiEQZTnGSQAGJhyHiocdLTrxRRxELGSefCnLSRvARLgakiTPfVoFbRPOtMBPdjaTDycdXpPeYWsWPMAWDRrDsCDjnaDwKfEQGLOksJEeHdCnVnifjNC"));
    this->hWlJdln();
    this->EZkjn(338588147);
    this->VlLZkT(true, 1818614615, false, true, -1794711023);
    this->folrMJsH(-705064.0354491373, false);
    this->rdDMDpL(true, -158994.90447589575, -599320.3382839906);
    this->wvvALS(string("UzzLRSe"), 1768370193, string("FewtPvwoNbZhHcWUrvUsUtkEMLDzZQHwCdLUshbaGgJjqDrvogizFRgdoheQGORSKzBooAYVfjdzTDfqATPAgpTerdhoiOCIAffMBxJsjUNVfIpYIboEKIgyzWaVjaeHBxowlvwLjg"), false);
    this->mKmHqu(1082128615, -969314.3149887923);
    this->XTbfxxFN(221782736, 734734.9554299184, -1547683348, string("JxdbfJNHrnyDDoVzJewshEpFoXwYAWLyKZeUXbsSCTrSAVwGCEVOBCrzduVvaVcjOeKzzrbtJRYyBYZzXBsGjVzsBRBcOMFFc"));
    this->wIANRH(120576644, 1017265.1516910051, true);
    this->bnFJSjlmOIsrQ(string("wsZvFSHBMLYzToRWwaZUHgzPnzdhYuafsQmDCmzGSjiycbJSJNic"), string("OplToupemmwcjKTNvWEYtZKhfQnoAonICWaBHNlvbrhfPvZQKJzqybnJRabMYjUiigaJkNFNpyHLVONNBWhYEdQJJHKtAtyhNideOsLaxGvcxiApGPadDmiXEPDitxSNyGfgdSTQYaqeTzBGrRSCgNJBKOcVbznMDbTNTEJd"), false);
    this->wTbXnsqTZVtE();
    this->aJuGZiMttYnYvroS(1802990537, -802951548, true, -1780991581, string("fmYOhldWEHBqpXaNGmUohtGRxMqDqoIFGOexSfArHbISgGAJfcagulDeNhLqHukUDenXprnAcjnWiUTEPBQlFVtmyDkGjJMUlHQmtWaftXzqgLxLZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BosyLTNKgcjYK
{
public:
    bool AqOGuCpqY;
    bool IeJVzEzR;
    double xNXqpogvqwVO;

    BosyLTNKgcjYK();
    int wVAJdEDEASAucCS();
protected:
    bool oImqerXs;

    double icHnahATSt(bool kXUzB, bool ecTDyAaxzGY, int NSwbKS);
    string leKTjCTHrFuwxq(bool ieCiFKZZenlBI, string lkUjbsQarfu, int bDZBJRucSkzxYC, bool UdGoWVzQTyefup, bool VvtwhSpvbxxuyzMp);
    double GzrDRyHwpKS(int DrXlBbgY, bool ArwlHUTqjiSiaggW, double iFrXK, bool PsaIxkVaBVC);
    string yguZArbqM(string bRmgcsHCCrQTdB, double dOZAMw, bool UrqdQjoLAlOT, bool GCCDrTB, string gMiUWuQrSW);
    void tnPdJDuZnWt(int cRDrwEUfjHbO);
    int ezGriIaVMSpq(int cOzVRbc, double YinwZw, double XhKaVBIuAZF, double yYzBjqcmECEtLV, string MmCphM);
private:
    bool aKDAztRLifemCpPL;
    bool usNvrc;
    bool ySYHVGmBidtmmj;
    int tlzTSfqGs;
    bool mqpJSFK;
    double UadNDN;

    string PZIAglIjZzaCqKU(double BousUSC, bool QlbLcZtbcvAwpUA, int LLPdsWBpoLlktA, double YOziURNmLDy);
    void AwzSQqPQP(string zPnDVloBKzgk, string DcbquOMiGfDv, int LnMqfULoIZL);
    bool KHYSeALtGZPP(bool AdFPFONXS, string ohZCfuzecYe, bool svtOXdStEdtogI, double yZVpVgdyrZp, int FqWmYm);
    void VmXRodhKwAXZ(double MUBcBrChkVmiw, string IRbaMnwd, string PvovgMUL, int WaVkXah);
};

int BosyLTNKgcjYK::wVAJdEDEASAucCS()
{
    bool AbLCVElRtHWOrTbW = true;
    int CAhWUuuRtaIoiRSj = -1178237184;
    int xsxtQ = -41444393;
    int LHiiEz = 1045644973;
    bool NSOXkyd = false;
    bool qYZonCQ = false;
    string LXjbfrkIFOsQUrqB = string("DaHrxdXjpwlBpnojXfuPWqZBNIVwAQRIeJdcpOdURXrqYVUiLRcAGJLPnCzDWMGJjEXYqkxeJJLACLmeIcrUQoHTQudjmt");
    bool ZNTunLhAkuJODp = true;
    string OdjBRPlx = string("ZZImHBdIqQpUPpFbwJouDVuhZPhNYdIIRxYXinVEBZSeHcWyIBrXXizWVgRxKfpRLYPwErgECjAyxgLTAetxzlWwKdwmTPtENqS");
    double aiLuNKncLTaoNIV = 327128.5126632074;

    for (int dOkfpSkZMICKNOa = 1425494236; dOkfpSkZMICKNOa > 0; dOkfpSkZMICKNOa--) {
        AbLCVElRtHWOrTbW = AbLCVElRtHWOrTbW;
        AbLCVElRtHWOrTbW = ! qYZonCQ;
        AbLCVElRtHWOrTbW = ! ZNTunLhAkuJODp;
        NSOXkyd = NSOXkyd;
    }

    for (int ZFlvKw = 1939367951; ZFlvKw > 0; ZFlvKw--) {
        AbLCVElRtHWOrTbW = qYZonCQ;
        NSOXkyd = ! NSOXkyd;
        ZNTunLhAkuJODp = AbLCVElRtHWOrTbW;
    }

    for (int pqZcKAQlyDZevfE = 1611473677; pqZcKAQlyDZevfE > 0; pqZcKAQlyDZevfE--) {
        continue;
    }

    for (int gLDdWAAbOPWXUrfw = 325079713; gLDdWAAbOPWXUrfw > 0; gLDdWAAbOPWXUrfw--) {
        AbLCVElRtHWOrTbW = ! ZNTunLhAkuJODp;
    }

    for (int ZXtWfzh = 1909524067; ZXtWfzh > 0; ZXtWfzh--) {
        LHiiEz *= xsxtQ;
    }

    for (int ggyXmPSrjaOE = 86828439; ggyXmPSrjaOE > 0; ggyXmPSrjaOE--) {
        qYZonCQ = ! AbLCVElRtHWOrTbW;
    }

    for (int LUQXS = 905661375; LUQXS > 0; LUQXS--) {
        ZNTunLhAkuJODp = qYZonCQ;
    }

    return LHiiEz;
}

double BosyLTNKgcjYK::icHnahATSt(bool kXUzB, bool ecTDyAaxzGY, int NSwbKS)
{
    bool VjivsIjFxkigrlP = true;

    if (NSwbKS == 1189565553) {
        for (int dcLEEsTMO = 1051950413; dcLEEsTMO > 0; dcLEEsTMO--) {
            VjivsIjFxkigrlP = ! VjivsIjFxkigrlP;
            NSwbKS -= NSwbKS;
            ecTDyAaxzGY = kXUzB;
            ecTDyAaxzGY = ! ecTDyAaxzGY;
            kXUzB = ! ecTDyAaxzGY;
        }
    }

    return 367977.90834212647;
}

string BosyLTNKgcjYK::leKTjCTHrFuwxq(bool ieCiFKZZenlBI, string lkUjbsQarfu, int bDZBJRucSkzxYC, bool UdGoWVzQTyefup, bool VvtwhSpvbxxuyzMp)
{
    double QLYWHJIZ = 21056.313780149154;
    bool HIYvGOCHqdUAL = false;
    int yJiugxdP = 625696054;
    int sIPXyNhwWy = -1556473855;
    int OkWznuBipTGB = -513422856;
    bool bqLXNZtVcsuQde = true;
    double xwdDqt = -934364.4299922495;
    int nxZlwDas = -1440225109;
    string SicXYY = string("LTSsvGbnPpTihKneSmAVeaoStPcLLZevSHBdZqZzpJZkQlQFrtTomdouIPIScykTECVytekNwqRvfYotEZDhrEpnoWkNNdbWmopfHBBDnSnVAACdCWTnGsFT");

    for (int qsXAOixUMuZoMJi = 1288839097; qsXAOixUMuZoMJi > 0; qsXAOixUMuZoMJi--) {
        HIYvGOCHqdUAL = ! UdGoWVzQTyefup;
        yJiugxdP /= yJiugxdP;
        HIYvGOCHqdUAL = ieCiFKZZenlBI;
    }

    for (int gkSCemWElByG = 1103869831; gkSCemWElByG > 0; gkSCemWElByG--) {
        UdGoWVzQTyefup = VvtwhSpvbxxuyzMp;
        sIPXyNhwWy = sIPXyNhwWy;
    }

    return SicXYY;
}

double BosyLTNKgcjYK::GzrDRyHwpKS(int DrXlBbgY, bool ArwlHUTqjiSiaggW, double iFrXK, bool PsaIxkVaBVC)
{
    double IQwXrK = -978517.9368878613;
    double LOBEefN = -456815.80166723323;
    double khZvBQ = 436518.6310143746;
    int yqwowxzlydlSyq = -1761862521;
    int DfoHqPumuHGcB = -1924248153;
    double ZiaJWLqKrF = 153642.68404494593;

    return ZiaJWLqKrF;
}

string BosyLTNKgcjYK::yguZArbqM(string bRmgcsHCCrQTdB, double dOZAMw, bool UrqdQjoLAlOT, bool GCCDrTB, string gMiUWuQrSW)
{
    bool HzRsOSSk = false;
    string QyRMS = string("TlIEdVEJfyChTuUHFLiZxtfjiDuhtQwMiHTwMxZpKtXsGRbSqffRxqOxqHsQmeAJICXXBUIqJCenzrvxSJYbtZwGLJzDmpybRDQDYKAvNJD");
    bool AuEhBiWszveQ = false;

    if (HzRsOSSk == false) {
        for (int BHNLyZEIitANklL = 1068259042; BHNLyZEIitANklL > 0; BHNLyZEIitANklL--) {
            AuEhBiWszveQ = UrqdQjoLAlOT;
            HzRsOSSk = ! HzRsOSSk;
        }
    }

    for (int KXBkLgactGtK = 675541792; KXBkLgactGtK > 0; KXBkLgactGtK--) {
        bRmgcsHCCrQTdB += gMiUWuQrSW;
        QyRMS += QyRMS;
        gMiUWuQrSW += QyRMS;
        bRmgcsHCCrQTdB += bRmgcsHCCrQTdB;
        HzRsOSSk = GCCDrTB;
    }

    for (int sNBvJdC = 530565524; sNBvJdC > 0; sNBvJdC--) {
        gMiUWuQrSW += QyRMS;
        GCCDrTB = ! AuEhBiWszveQ;
    }

    for (int uXzjBHxChPeqrd = 2095186653; uXzjBHxChPeqrd > 0; uXzjBHxChPeqrd--) {
        gMiUWuQrSW += QyRMS;
        QyRMS = gMiUWuQrSW;
    }

    return QyRMS;
}

void BosyLTNKgcjYK::tnPdJDuZnWt(int cRDrwEUfjHbO)
{
    bool xXyiMgqdKNicLA = false;
    int delbvIuMCRDP = 523348663;
    double guRsbrzgCgn = -993847.234663636;
    bool JuprymVpY = false;
    double FwNcgauGir = 76288.29766724455;
    string HBfDexUImPusufxz = string("cCNUPPlphQdxCNSOtutgcuMlKHSTjmhSjqOrsdEzvlCsURMWBsaMvFRbjQzJzoGvOjxgNpvKNHfKWHbRRbxgksgquMkKbOMcOsGmDbZbNoGCCGxImiBPQBJBYfsukPuVWfPCTxKqp");
    int KdZxFhgYKGSBM = 2000397734;

    for (int cBaGLjSD = 828148146; cBaGLjSD > 0; cBaGLjSD--) {
        JuprymVpY = ! xXyiMgqdKNicLA;
        guRsbrzgCgn -= guRsbrzgCgn;
        KdZxFhgYKGSBM -= KdZxFhgYKGSBM;
    }
}

int BosyLTNKgcjYK::ezGriIaVMSpq(int cOzVRbc, double YinwZw, double XhKaVBIuAZF, double yYzBjqcmECEtLV, string MmCphM)
{
    int xffqxO = -1765227026;
    int GsJnnwJ = -771213231;

    for (int fRNraGUEX = 857247884; fRNraGUEX > 0; fRNraGUEX--) {
        yYzBjqcmECEtLV += XhKaVBIuAZF;
        GsJnnwJ += cOzVRbc;
        xffqxO -= GsJnnwJ;
        cOzVRbc = GsJnnwJ;
    }

    for (int ZgvxCzJMMEdQF = 547891722; ZgvxCzJMMEdQF > 0; ZgvxCzJMMEdQF--) {
        continue;
    }

    return GsJnnwJ;
}

string BosyLTNKgcjYK::PZIAglIjZzaCqKU(double BousUSC, bool QlbLcZtbcvAwpUA, int LLPdsWBpoLlktA, double YOziURNmLDy)
{
    bool iRUpAnhtfHCWhXy = false;
    string usDgJkcUklqS = string("BrpxWGrzdVUtqhTBqNEHYFRdWEvNTrXmnAUiDGeDbVydXaCdqKAvfXbrEBDhnFJiUFSRGWcIQntmiioQVhtJKNsdrGucwJTgReehvNwbzzhlmzaBbpzgOjTyRwLTZ");

    for (int kZRRAHmSL = 466787890; kZRRAHmSL > 0; kZRRAHmSL--) {
        BousUSC -= BousUSC;
    }

    for (int AVPCa = 1733099707; AVPCa > 0; AVPCa--) {
        BousUSC *= YOziURNmLDy;
        LLPdsWBpoLlktA *= LLPdsWBpoLlktA;
        QlbLcZtbcvAwpUA = iRUpAnhtfHCWhXy;
    }

    if (BousUSC == -135641.3595029233) {
        for (int TReQjmuaVkKGKSqJ = 1160794320; TReQjmuaVkKGKSqJ > 0; TReQjmuaVkKGKSqJ--) {
            BousUSC = YOziURNmLDy;
            BousUSC *= BousUSC;
            YOziURNmLDy = YOziURNmLDy;
        }
    }

    for (int ayddMzKF = 1227545369; ayddMzKF > 0; ayddMzKF--) {
        iRUpAnhtfHCWhXy = ! iRUpAnhtfHCWhXy;
    }

    for (int UYLeVQWWKEvgUVkM = 1422712540; UYLeVQWWKEvgUVkM > 0; UYLeVQWWKEvgUVkM--) {
        QlbLcZtbcvAwpUA = ! iRUpAnhtfHCWhXy;
        BousUSC = BousUSC;
        QlbLcZtbcvAwpUA = QlbLcZtbcvAwpUA;
        iRUpAnhtfHCWhXy = QlbLcZtbcvAwpUA;
        BousUSC *= BousUSC;
    }

    return usDgJkcUklqS;
}

void BosyLTNKgcjYK::AwzSQqPQP(string zPnDVloBKzgk, string DcbquOMiGfDv, int LnMqfULoIZL)
{
    bool MxwSjoCOGvsMj = false;
    int fZEmhLONMHRfTX = -1656351565;
    int sjVCweokdAQRuPW = 1035538604;

    for (int sdPilSZicXMnRXp = 509507621; sdPilSZicXMnRXp > 0; sdPilSZicXMnRXp--) {
        LnMqfULoIZL -= LnMqfULoIZL;
        fZEmhLONMHRfTX -= sjVCweokdAQRuPW;
    }
}

bool BosyLTNKgcjYK::KHYSeALtGZPP(bool AdFPFONXS, string ohZCfuzecYe, bool svtOXdStEdtogI, double yZVpVgdyrZp, int FqWmYm)
{
    int LGNNYD = -968395120;
    bool VAAgtJuPMgmWzFnu = true;
    double mGFcYOWhCsTmYID = -407182.59451267694;
    string xsWSsxEVtTJXPcV = string("bznDrsLERSTticBBqnMJUiycVfebzvnOeyMEVogxbftVEvEsDlEmIjNmBkPAGPuRFqbwiPRoSbIcYWdRVSfNNpvCLVKcSizyAJuadTyPWRdBLrXAwsfRpgrWDPyizKHnqHVQOKlZbFuYSldyoQLplOoBDOykmLpQsEvCGoEoIgORoKydCDQyUFLqAZNcHZZBBatAXROqBHEsVgOdwDbodtf");
    int TENADFWuibmvs = 2071537948;
    string uoPMAoFn = string("lakBTpTXgqDJApydrMcZsBJWdvIaVBFIDkRNmuDiZRmTndgdfntEpfVpIGxynVefSYIAuBauJuHqozfHVtffPIhvnBkPDSJRbyIGdOxWXYPNDDAfBkQGCRyzEobLwDXIddaYJHkyQI");
    bool NbRMe = false;
    double nEUggnbAhqAbU = -29941.705957835908;
    bool sXllIgvVPn = false;

    if (uoPMAoFn <= string("aqkXgNgFvcVsT")) {
        for (int QRGxFwfL = 2111313575; QRGxFwfL > 0; QRGxFwfL--) {
            continue;
        }
    }

    return sXllIgvVPn;
}

void BosyLTNKgcjYK::VmXRodhKwAXZ(double MUBcBrChkVmiw, string IRbaMnwd, string PvovgMUL, int WaVkXah)
{
    double wgFWRgLtX = -68870.80306107055;
    double nmLxAnNQjXU = 969141.7582345826;
    string HDhcAmtNVqSbRFt = string("UBiHDzuiBXqWtRIyHmWZVv");
    string BfNhkLapGos = string("RRfvXnTufhiqjiYxdamqXvQljxWfdvMUwUHSCnPNeoQjCbvtMQjjxmDSafWXFNvazfxqvpOetDsGIEPlZFuEZBvTbWenSRbeAZFLzXRqIUUqujXOsJGDXiejlbNyZ");
    int SJUeYl = -1991605909;
    string TSYARnvXEShLNfiA = string("dvstEUPqNrTWBZBKUlCgfMJEntjDnZxDwlFNPhPlemECJSNrjKpZjBilwjGkgpAsgrlTeqYtksPAs");
    string MCGzrGNHmDt = string("GCxyzFbXueApdrpFWqOqBnOyBuzzAziLdevVlzvQnHLvPCbVjbGRMCCWuJjwFNpQRTPhEGDaAVjwzsrvJpSAOoijtbBRVGaidUQKyfYrCKzHVGdUVRIoRPBKLDZmjHXrcWWVUTLuujcHXIeoPzABHQfZUFthvbDh");
    int NmquW = -177486270;
    double tTmStlZmFJhco = 951764.5239408251;
}

BosyLTNKgcjYK::BosyLTNKgcjYK()
{
    this->wVAJdEDEASAucCS();
    this->icHnahATSt(true, true, 1189565553);
    this->leKTjCTHrFuwxq(true, string("SeOsDrPvzeKWuguTrjcEhdvWEPIqUMvoxpYYRaGUduTOFTCRsduIFQVeqapIawtIEcqLAJ"), 1004719618, true, false);
    this->GzrDRyHwpKS(-2137489447, false, 729717.536988434, false);
    this->yguZArbqM(string("movmtVNLVWQkcaqoXJwzNrfSzzNwdNcskzmcwCFZbhfbVTUFLBnpfTvZGdumejzJDWcbfTvzyDBieUoPaPPyriEqCZCAYCwVybXXLPbChQjEzrRnCpbcLIQnXVGfqbPAqLyOExKDpGIhMxRdamZdNZkCzqWUpdmCkRuGrwPVTrIRXwvkrrvvXxmRanTHhRFgAmluwQuKftZ"), 627651.6356952398, true, true, string("TQcZDaUCRXcMvHTRWgoxdsYPEgswYyRzGWhyVSkbhgclpCRcOfLeqNLVsSEGZdrjLdJEVySqSFxxkuyGzDuHzzUPdQxqrkzc"));
    this->tnPdJDuZnWt(-643576097);
    this->ezGriIaVMSpq(-752199918, 585248.8016229754, -443673.2741836925, 329703.411183183, string("kLYZQADKtAaCqrkPylh"));
    this->PZIAglIjZzaCqKU(-459712.91804490454, false, -1750469959, -135641.3595029233);
    this->AwzSQqPQP(string("cOckvsmOnWhpLxsySHIzHwWVtpYNlxvisAV"), string("BrsHzQewNimMXQdAjpzmEGaYkKmKBwluZdYtwCgeDNHBZxLQvLTRjbcmqAJqnYjKGdwgLRlzrMhivWwiGJHRdJuUkqWRoImmEEkKdwJWu"), -1678414255);
    this->KHYSeALtGZPP(false, string("aqkXgNgFvcVsT"), false, 310758.69264980144, -869292797);
    this->VmXRodhKwAXZ(-211187.67610268568, string("RPFHyIQgoVsrlyHpiIyLsvqsYplavSLMzdyIfKoUuOdOqWwjalNaBscUHylEKtnhlvMgdBSOEIGwzFjmNuIUZqQZmAvJssdTaIbWxISNyGckWKowbksmXogkQWZTEKyJxCyOMUJlJAFvMeekxrtMbwMGvgvwjUbvwLDHxAWFaPcOgECHBMdfmuL"), string("VTguDgBdgQkUtciRDOQTEcTzdicybKOFgxFcnYUtBpNpKxZvCECKxOyLYgwGfmPEuvRXXAXGfdkuTYupPfXXTSprBGoRskVRJqMsIkqGdIIaPXDHyrKFERdbBzCYhIPLGTgSFZFmTMuGmmanNOpNioTPxtlzijCaxQpfYUmJoR"), 1816854248);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class imbXCmiFuIyK
{
public:
    bool NHgoAw;
    string pEOFCm;
    int gWMHr;
    string LEgGiYWJnZd;
    int iPBzcnsYYpDs;

    imbXCmiFuIyK();
    void GobJZMtfjase(bool NUhPvgORHKC, string hoWFfkTVjRepB, double yTfPFwrvc, string yRPLaZVK);
    bool YaqrfaqbHjJXE(double dGpnVZpGpRgqeA);
    string LUHGsFTufisBDXO(int QFplXxPJqVW, string QvgZxyDg, string OxdQgx);
    string hXIbOSsrIatCluAD(int fVlPhYcfchzsuLRx, string BEHHXnhwgoE, double fomWYhAhiyFmAR);
    bool vcsjE(double QwCEEL, int CtlwVevkpnOow, double oFUGtWDAzN, bool QcaERHfjMj);
    void HZOmx(string WrWHQelX);
    int XImamAYZ();
protected:
    string WcuSFMRRQaP;
    string nwFKuH;
    bool zuAWeWYOYFgkML;

    string AhmcOF();
    double ObODVZeHsKzoyD(string DjWGkvWdOY, string WAnjuOhnVzTtUmj);
private:
    string qFIQWWWD;

    string gelLSmJeqOZ(string JGIKlHFyDd);
    void JTBlUMnu(bool NbovwGOiEWDwgr, string oVRjekGNFHf, double AUftUFVLaMi);
    void MiWvEilpGtCPOj(double vbfqjcmZfL);
    string KBLwa(bool pftwO, double ymATxoo, int AOdjNdjWphY, bool NWlcrqYPstvbavuD);
    string iRURKwfSq(bool WNBRbCZ, bool PSudetoVlAGz, bool oklnIO, bool kyFDrQUZZoOZEwUd, string SjGjZRHx);
    string eGMZaYCkX(int CXObvEGZoEDWwga, string BRPugFB, bool edyTNX, bool cnriBivV, bool VCEqUPwVsJdaNu);
};

void imbXCmiFuIyK::GobJZMtfjase(bool NUhPvgORHKC, string hoWFfkTVjRepB, double yTfPFwrvc, string yRPLaZVK)
{
    int dGJZL = 772965318;
    bool vIsWncrvtDXTWSsq = true;

    for (int GbsDpxf = 1964042142; GbsDpxf > 0; GbsDpxf--) {
        vIsWncrvtDXTWSsq = ! vIsWncrvtDXTWSsq;
        yTfPFwrvc = yTfPFwrvc;
    }

    for (int yVGPiIRaCudUf = 869834881; yVGPiIRaCudUf > 0; yVGPiIRaCudUf--) {
        yRPLaZVK += hoWFfkTVjRepB;
        vIsWncrvtDXTWSsq = NUhPvgORHKC;
    }
}

bool imbXCmiFuIyK::YaqrfaqbHjJXE(double dGpnVZpGpRgqeA)
{
    bool kQqnhlaBjslH = true;
    bool zUgsUwseOURx = true;
    int wUxKGv = -2108502166;

    if (dGpnVZpGpRgqeA >= -110685.86847718929) {
        for (int rHXtMdOqqy = 394634683; rHXtMdOqqy > 0; rHXtMdOqqy--) {
            dGpnVZpGpRgqeA *= dGpnVZpGpRgqeA;
            wUxKGv -= wUxKGv;
        }
    }

    for (int lvKaJoVLqSvHx = 2124705897; lvKaJoVLqSvHx > 0; lvKaJoVLqSvHx--) {
        zUgsUwseOURx = zUgsUwseOURx;
        zUgsUwseOURx = ! zUgsUwseOURx;
    }

    return zUgsUwseOURx;
}

string imbXCmiFuIyK::LUHGsFTufisBDXO(int QFplXxPJqVW, string QvgZxyDg, string OxdQgx)
{
    int wLRsyStGENEuYV = 1001365138;

    if (wLRsyStGENEuYV == 1001365138) {
        for (int NLwpFl = 159666456; NLwpFl > 0; NLwpFl--) {
            OxdQgx += QvgZxyDg;
            OxdQgx = QvgZxyDg;
            wLRsyStGENEuYV += wLRsyStGENEuYV;
            QvgZxyDg = QvgZxyDg;
        }
    }

    if (QvgZxyDg == string("kGkNboALtSOsIjNHWsINlbNQdeYkUmDnADyqbCDDhgNvpNhYYzHTpQhbaTXuSFSiIidFOFhRvkkyaMnwSaxbKuADRzXKkUOOzTegglnVrOstOjhyhzNBhAPHrVWAQsRcBsTROJZZtuRgkpTACERTVopnVQugbIgcvmDdWcAHpDHkAksrwrUigxLrQJCKWYNODORJEvOoLCTzkXlfbethVxv")) {
        for (int uDnEjejbBY = 171650413; uDnEjejbBY > 0; uDnEjejbBY--) {
            wLRsyStGENEuYV = wLRsyStGENEuYV;
            OxdQgx += QvgZxyDg;
            wLRsyStGENEuYV = QFplXxPJqVW;
            wLRsyStGENEuYV /= wLRsyStGENEuYV;
            QvgZxyDg += OxdQgx;
            QFplXxPJqVW += QFplXxPJqVW;
            QvgZxyDg += OxdQgx;
        }
    }

    for (int IdLGfwz = 2126832049; IdLGfwz > 0; IdLGfwz--) {
        wLRsyStGENEuYV += QFplXxPJqVW;
        wLRsyStGENEuYV *= QFplXxPJqVW;
    }

    if (OxdQgx < string("kGkNboALtSOsIjNHWsINlbNQdeYkUmDnADyqbCDDhgNvpNhYYzHTpQhbaTXuSFSiIidFOFhRvkkyaMnwSaxbKuADRzXKkUOOzTegglnVrOstOjhyhzNBhAPHrVWAQsRcBsTROJZZtuRgkpTACERTVopnVQugbIgcvmDdWcAHpDHkAksrwrUigxLrQJCKWYNODORJEvOoLCTzkXlfbethVxv")) {
        for (int SKODlkUmNmhDXj = 638816456; SKODlkUmNmhDXj > 0; SKODlkUmNmhDXj--) {
            QFplXxPJqVW /= QFplXxPJqVW;
            wLRsyStGENEuYV -= wLRsyStGENEuYV;
        }
    }

    if (QFplXxPJqVW > 1001365138) {
        for (int MTMoTZtJP = 962537164; MTMoTZtJP > 0; MTMoTZtJP--) {
            wLRsyStGENEuYV /= QFplXxPJqVW;
            wLRsyStGENEuYV = QFplXxPJqVW;
            OxdQgx += OxdQgx;
            QFplXxPJqVW /= wLRsyStGENEuYV;
            QFplXxPJqVW -= wLRsyStGENEuYV;
        }
    }

    for (int ShJiUnB = 1267582189; ShJiUnB > 0; ShJiUnB--) {
        QFplXxPJqVW += wLRsyStGENEuYV;
        QFplXxPJqVW /= wLRsyStGENEuYV;
    }

    if (OxdQgx > string("kGkNboALtSOsIjNHWsINlbNQdeYkUmDnADyqbCDDhgNvpNhYYzHTpQhbaTXuSFSiIidFOFhRvkkyaMnwSaxbKuADRzXKkUOOzTegglnVrOstOjhyhzNBhAPHrVWAQsRcBsTROJZZtuRgkpTACERTVopnVQugbIgcvmDdWcAHpDHkAksrwrUigxLrQJCKWYNODORJEvOoLCTzkXlfbethVxv")) {
        for (int YTrgH = 1499784175; YTrgH > 0; YTrgH--) {
            continue;
        }
    }

    return OxdQgx;
}

string imbXCmiFuIyK::hXIbOSsrIatCluAD(int fVlPhYcfchzsuLRx, string BEHHXnhwgoE, double fomWYhAhiyFmAR)
{
    string ymOlwOkGSabmXMx = string("jdoKRhgodVmNGlLdnnHJevcvfluOfjqNLIAVCHnXkGmUhOUJIMVjggWvheuzAiCeCbXNcTdSIOGbIRVrZeZqhnluHbxUZPdpsXmEoNerPCWFmjxZAwYjxvCgKTptGCFHkEEmyvNHlTQLjKsVMzBtQwjiCYuNBLaraJeHshqWIXiSnxtAAyMUzGzyDIpetBKJJJnGiXyZDCMbDTxHiVtoGjoKjpf");
    double nQwCrsRZEkjs = -961886.0558856295;
    double KfzbfZ = 330458.50521465007;
    double NkuBYtygNTK = -23209.928695998755;

    for (int ZWCPcGNBg = 1934064760; ZWCPcGNBg > 0; ZWCPcGNBg--) {
        KfzbfZ -= fomWYhAhiyFmAR;
        ymOlwOkGSabmXMx = ymOlwOkGSabmXMx;
        nQwCrsRZEkjs -= KfzbfZ;
        KfzbfZ += KfzbfZ;
        NkuBYtygNTK /= fomWYhAhiyFmAR;
    }

    for (int lYJucHP = 1524465440; lYJucHP > 0; lYJucHP--) {
        KfzbfZ -= NkuBYtygNTK;
        nQwCrsRZEkjs /= KfzbfZ;
        fomWYhAhiyFmAR *= fomWYhAhiyFmAR;
        fomWYhAhiyFmAR *= KfzbfZ;
    }

    for (int bpiLUnk = 1948151504; bpiLUnk > 0; bpiLUnk--) {
        BEHHXnhwgoE = BEHHXnhwgoE;
        NkuBYtygNTK = nQwCrsRZEkjs;
        NkuBYtygNTK /= NkuBYtygNTK;
        ymOlwOkGSabmXMx = BEHHXnhwgoE;
    }

    for (int XmxaFWIhgdoXCyR = 994342931; XmxaFWIhgdoXCyR > 0; XmxaFWIhgdoXCyR--) {
        ymOlwOkGSabmXMx += ymOlwOkGSabmXMx;
        nQwCrsRZEkjs /= fomWYhAhiyFmAR;
    }

    if (fVlPhYcfchzsuLRx >= -787414940) {
        for (int hmbrxpXPNANDE = 1137516078; hmbrxpXPNANDE > 0; hmbrxpXPNANDE--) {
            KfzbfZ = nQwCrsRZEkjs;
            NkuBYtygNTK *= NkuBYtygNTK;
            fomWYhAhiyFmAR = KfzbfZ;
        }
    }

    return ymOlwOkGSabmXMx;
}

bool imbXCmiFuIyK::vcsjE(double QwCEEL, int CtlwVevkpnOow, double oFUGtWDAzN, bool QcaERHfjMj)
{
    double FywMDjDemPKGUTV = 959552.3551534961;
    double uDujphjTYE = -827632.8364814627;
    bool ELxbJaMmbFT = false;
    bool pcCenaKjxgm = true;
    double YEiaNxnj = 446619.73936681246;
    double pahoetD = -735663.570627787;

    if (oFUGtWDAzN < -735663.570627787) {
        for (int RRjsBysQMCRiEDS = 955309083; RRjsBysQMCRiEDS > 0; RRjsBysQMCRiEDS--) {
            oFUGtWDAzN = pahoetD;
            CtlwVevkpnOow *= CtlwVevkpnOow;
            FywMDjDemPKGUTV *= pahoetD;
        }
    }

    for (int gpxNhFJyjTa = 509449810; gpxNhFJyjTa > 0; gpxNhFJyjTa--) {
        QwCEEL /= FywMDjDemPKGUTV;
        pahoetD /= pahoetD;
        pcCenaKjxgm = QcaERHfjMj;
        QwCEEL -= uDujphjTYE;
        uDujphjTYE *= YEiaNxnj;
    }

    for (int dPIsUvCyWYzFIbsP = 1824992940; dPIsUvCyWYzFIbsP > 0; dPIsUvCyWYzFIbsP--) {
        FywMDjDemPKGUTV -= QwCEEL;
        pcCenaKjxgm = ! ELxbJaMmbFT;
    }

    return pcCenaKjxgm;
}

void imbXCmiFuIyK::HZOmx(string WrWHQelX)
{
    double LahwUzuJUH = -549148.1477949618;
    double tkrASkgSakGeuArr = 203091.78143930767;
    bool ajXwtESqVH = false;
    double TOxwksTp = -91238.82521710712;

    if (LahwUzuJUH == 203091.78143930767) {
        for (int ZMJxULYudCGNvqT = 531590788; ZMJxULYudCGNvqT > 0; ZMJxULYudCGNvqT--) {
            LahwUzuJUH *= LahwUzuJUH;
            ajXwtESqVH = ! ajXwtESqVH;
            LahwUzuJUH *= TOxwksTp;
            tkrASkgSakGeuArr *= tkrASkgSakGeuArr;
            LahwUzuJUH /= tkrASkgSakGeuArr;
            WrWHQelX = WrWHQelX;
        }
    }

    if (TOxwksTp == 203091.78143930767) {
        for (int LvNMkBEpOt = 1142172688; LvNMkBEpOt > 0; LvNMkBEpOt--) {
            LahwUzuJUH /= LahwUzuJUH;
            TOxwksTp += LahwUzuJUH;
            tkrASkgSakGeuArr /= LahwUzuJUH;
        }
    }
}

int imbXCmiFuIyK::XImamAYZ()
{
    int REwafqU = -591123990;
    bool vKcQAKOOqtqg = false;
    bool NpBNFsXP = false;
    string ljlrlbhsKyEjyP = string("NFSKtidBNBaNbVUiNzOFJOPBeVrVHdynSwVLwDxhvNnNffRMKfdtxNBoeOnRSyJhnXKJGdLFqnmAEYrFEOaCCeHUjFvdOjHnIWyMKDDCpzHQrBDyBhjcgkCmPsnLangT");
    bool NXMIzmYSmKAVQp = true;
    string bjgQkHRoZu = string("HSkUFihd");

    if (NXMIzmYSmKAVQp == true) {
        for (int FGDVpzmLkAi = 692402766; FGDVpzmLkAi > 0; FGDVpzmLkAi--) {
            vKcQAKOOqtqg = NpBNFsXP;
            ljlrlbhsKyEjyP = ljlrlbhsKyEjyP;
            NXMIzmYSmKAVQp = NpBNFsXP;
        }
    }

    return REwafqU;
}

string imbXCmiFuIyK::AhmcOF()
{
    double XYJpK = -250100.63147143275;
    bool IrRPsMrEEVLor = true;
    string fAtYfzzDgxX = string("NepOHmzyEjeAeFjLoVxmrwYDDgqgkmdLgnxCQGcgmsYMjDnkadMqlmMDDpRIhdrCeHyVjXdUsfkkConxhYRjOzNiOkyiRrLucZYhp");
    int EfMCVnfb = 187424004;
    double JULDTUWMskJ = -736602.6006920645;

    for (int WCEBxnsyaHuP = 1611551475; WCEBxnsyaHuP > 0; WCEBxnsyaHuP--) {
        JULDTUWMskJ /= JULDTUWMskJ;
        JULDTUWMskJ += JULDTUWMskJ;
    }

    for (int pkYARpkEcqINj = 289457777; pkYARpkEcqINj > 0; pkYARpkEcqINj--) {
        XYJpK *= XYJpK;
    }

    if (XYJpK <= -250100.63147143275) {
        for (int WYYJaUCWizdvx = 1915243420; WYYJaUCWizdvx > 0; WYYJaUCWizdvx--) {
            fAtYfzzDgxX = fAtYfzzDgxX;
        }
    }

    if (JULDTUWMskJ == -250100.63147143275) {
        for (int UrgojzWPHNfftO = 1031131886; UrgojzWPHNfftO > 0; UrgojzWPHNfftO--) {
            IrRPsMrEEVLor = ! IrRPsMrEEVLor;
            JULDTUWMskJ *= XYJpK;
            EfMCVnfb /= EfMCVnfb;
        }
    }

    for (int dIjTiUKqxN = 1272617726; dIjTiUKqxN > 0; dIjTiUKqxN--) {
        XYJpK += JULDTUWMskJ;
        EfMCVnfb *= EfMCVnfb;
    }

    return fAtYfzzDgxX;
}

double imbXCmiFuIyK::ObODVZeHsKzoyD(string DjWGkvWdOY, string WAnjuOhnVzTtUmj)
{
    int tagGUTsCqGQIqi = 155950269;
    string idEck = string("ipBCPZSieVAIfEcfHIYxSEIqMdCXbUXgmpHjDghHedvvRZZpOsZCfdRZWEzWXVJAIzuPVembRktFDtCcMehcpNdVGVViWwZeZoExGXbOQvCMJEWyiOPzuDzETsafnBhKnkaMOpdsMAMfOpIsrPbLDWVBmYKYJtGWNSglmQpeHUSpwtRIWDcac");
    double iIUuPQHKDX = 505643.19844059175;
    string kKEtkWwIoMCTHz = string("jZVmcmqmtGQdbGQKywLoEocmSmMePDPQDOHZwjauPICIhdyYQXsCyCmhSUgjKwkV");
    bool sxhlDTcrEmOcsOOj = true;
    string hEnku = string("MgQbFlrCCnzcataORpMfJDLpiIicrSPJRTvkcZdrdpQemnaCKWwR");
    int IZXWYosTQ = 1763166227;
    int zKPtLKtVAjlDj = -1158149122;

    for (int qGtqavNXD = 1648109945; qGtqavNXD > 0; qGtqavNXD--) {
        DjWGkvWdOY += DjWGkvWdOY;
    }

    return iIUuPQHKDX;
}

string imbXCmiFuIyK::gelLSmJeqOZ(string JGIKlHFyDd)
{
    string JtGSKSXRcyXCe = string("KWYjbqcxRtjGTsYJKdDtsuOQLbMMEhdmSVlfYOeMuuZXQyDIbAIIcYXFGnEYYTruhhOHMkOIWoYBIrpneWFWlOVGo");
    string izdfpKMBY = string("XKaLxXgfRFibTVAkPRdqaAULxOfqcrWJhiIIqzHIMCKiBb");
    int zOuHvVdp = -81035782;
    string jLjkBbqmwxGq = string("BPqksojHqkOZaHKVM");
    string skCdfTuxO = string("RZOJerPrIiZCmp");
    bool XaiUuiQtMUFXINdA = false;
    double irWkJzMmr = 893166.4297798835;
    bool UJmWFX = false;
    string zcolVDZr = string("uvtuCqfWnSMABFImcysMDshZXKFikoFNkgMBZlAlkQcZEukzHrfzUGntkAcHAlbNyMVfrUYNJktqnzkcIIUR");

    for (int GvLgJIyNKpzEAex = 1214165742; GvLgJIyNKpzEAex > 0; GvLgJIyNKpzEAex--) {
        izdfpKMBY += jLjkBbqmwxGq;
        zOuHvVdp -= zOuHvVdp;
        jLjkBbqmwxGq += izdfpKMBY;
        JGIKlHFyDd = JtGSKSXRcyXCe;
        zcolVDZr = zcolVDZr;
        jLjkBbqmwxGq = JGIKlHFyDd;
        jLjkBbqmwxGq += skCdfTuxO;
    }

    for (int Ukhqq = 1026269856; Ukhqq > 0; Ukhqq--) {
        continue;
    }

    for (int rcxXaHaidotTszC = 713319384; rcxXaHaidotTszC > 0; rcxXaHaidotTszC--) {
        skCdfTuxO += skCdfTuxO;
        jLjkBbqmwxGq += skCdfTuxO;
        jLjkBbqmwxGq += skCdfTuxO;
        zcolVDZr = JtGSKSXRcyXCe;
    }

    return zcolVDZr;
}

void imbXCmiFuIyK::JTBlUMnu(bool NbovwGOiEWDwgr, string oVRjekGNFHf, double AUftUFVLaMi)
{
    string LPwBx = string("wPsKYisSyTJwPQglccCDBLYRZOkgZhJxqgYAjMLwiYgpXwjVUJPoyJkLnUZowWbyBHqCpOiObkmUZDteNSxKTTjiRPwQvdyDWtAlnYXegMYgIhyxfmwvUeuhBIHZkkPeMLsiYBWkPcJNbToxJIWAanCtgzBrqwsPlweCNWbIIpLIaUQeeeQEvwhAuICncLiEaegzdBlQDjoZLvzRpHehpXQNAQmOolrxTkMOGKPdp");
    bool laoJQerN = true;
    bool DBhNwdqPwMIFDk = false;
    bool BxrXjaIyzkTG = false;
    bool WeYhZCfMqvjPeDrQ = false;
    string ZBchtxcojvfmoK = string("CWCXekwrJfKpaMsPoGoaMZYusUtJHeORJOfuXUhfRsAvncJKXMGGSvIIoKAyzxSJskoxfoykncgXKQvdgupoyhUXWiwKmxudjNYrzmtWCBNsUPrIMuZegAhOPcSrFFOjRmBB");
    double ShHwiITssjieVsw = 479644.60147742485;
    bool LjITpZr = true;
    int XJLAeMiKvtDNgnz = 556385368;

    for (int zcHOebyBQUQUwrc = 1688810491; zcHOebyBQUQUwrc > 0; zcHOebyBQUQUwrc--) {
        laoJQerN = ! LjITpZr;
        laoJQerN = ! NbovwGOiEWDwgr;
        BxrXjaIyzkTG = DBhNwdqPwMIFDk;
        DBhNwdqPwMIFDk = WeYhZCfMqvjPeDrQ;
    }

    if (NbovwGOiEWDwgr != true) {
        for (int uFxmrQ = 1562420417; uFxmrQ > 0; uFxmrQ--) {
            WeYhZCfMqvjPeDrQ = ! BxrXjaIyzkTG;
        }
    }

    if (LjITpZr != true) {
        for (int bQPTThXgxYr = 1328751949; bQPTThXgxYr > 0; bQPTThXgxYr--) {
            DBhNwdqPwMIFDk = ! BxrXjaIyzkTG;
        }
    }

    for (int RpUMxqkb = 666258859; RpUMxqkb > 0; RpUMxqkb--) {
        LPwBx = oVRjekGNFHf;
        LjITpZr = LjITpZr;
        BxrXjaIyzkTG = ! BxrXjaIyzkTG;
        DBhNwdqPwMIFDk = ! laoJQerN;
        oVRjekGNFHf += ZBchtxcojvfmoK;
        DBhNwdqPwMIFDk = WeYhZCfMqvjPeDrQ;
    }

    for (int jpXAC = 2097282985; jpXAC > 0; jpXAC--) {
        laoJQerN = DBhNwdqPwMIFDk;
    }
}

void imbXCmiFuIyK::MiWvEilpGtCPOj(double vbfqjcmZfL)
{
    bool vsOslMwboR = false;
    string TLufggkNoTzHqgV = string("KYnGpgRhtFVTjpV");
    double HKuzEwSdgANqo = 801015.3315433019;
    double AzcacsYxS = -634023.246819088;
    int aVtEXdBCPXYguk = 1922213026;

    for (int yfnGcaxJmnplzkXB = 1952853297; yfnGcaxJmnplzkXB > 0; yfnGcaxJmnplzkXB--) {
        continue;
    }
}

string imbXCmiFuIyK::KBLwa(bool pftwO, double ymATxoo, int AOdjNdjWphY, bool NWlcrqYPstvbavuD)
{
    double LnstmRXgdCQbmd = -345840.3221374486;

    for (int fxvLVeELDHbuiO = 1350116665; fxvLVeELDHbuiO > 0; fxvLVeELDHbuiO--) {
        LnstmRXgdCQbmd /= LnstmRXgdCQbmd;
    }

    for (int DdGLtEE = 1385465797; DdGLtEE > 0; DdGLtEE--) {
        pftwO = NWlcrqYPstvbavuD;
        ymATxoo -= LnstmRXgdCQbmd;
        pftwO = NWlcrqYPstvbavuD;
    }

    return string("iTZatGTlkLLUzuLAvTvofTaQLbVVQnInXPIhIeyINrUsKNkiFnrttuaOyJngLjjCgTiCmH");
}

string imbXCmiFuIyK::iRURKwfSq(bool WNBRbCZ, bool PSudetoVlAGz, bool oklnIO, bool kyFDrQUZZoOZEwUd, string SjGjZRHx)
{
    double RGCHxXy = -749756.9085980442;
    double FeWgqOINx = -467778.4193868838;
    bool mpfEudhsNj = true;
    string VTVJfdKPCVfDKzV = string("whBWhDjHDgTzarORwnOtGBxgEipZuAoPOYdAIwWIYmGIETCpXTInbNIjrAYijsjZVkEyHQnqcHzqWKiKxgwXfTKSLAnBPBSRrynsVPaWRbGBnbRcTcfdLSRIzlcXUZShatxkHNXGKyvuhjuVEnGrCjgVfsWOVVtURiEkKnhEcyfiAJytxIdJoLaeIbUM");
    string VLuuNJOEaNem = string("hbOBrdeKOMDsfckpGInGrXlgkRYdjmXfcjcBklmtxBajHvRKhajyxkapNUpQCckgVvTPbRaoYFVTOzQRfzNDD");
    bool AkzYNekQY = false;
    double isQxa = 822497.3957396196;
    string NWgEgQ = string("OZPkoiCxuJLKkVlCeyRCuQzfVhCbbBwaDkEQnFTgyuIYSGKLzuqzfkcXLuiKfjEfOSaAgXiYrwpAixBGFIKIQWKgatOZZifdQIezQEHUWMdMLZONYfapRllNSFZWIhFrCdMGYVGVxtmmqsbEpEkqMoBKWdmExyEHuRUEYUhsQfeYQUVOnrJCUZDJfQenfWrKgVnwCZkvXZEYfWOxwIjzchfxPVcOvTdgEQTxhiAIwBHT");

    return NWgEgQ;
}

string imbXCmiFuIyK::eGMZaYCkX(int CXObvEGZoEDWwga, string BRPugFB, bool edyTNX, bool cnriBivV, bool VCEqUPwVsJdaNu)
{
    int aiJJXNud = -1740335365;
    string bfAqcJMwNEHDOOW = string("SsajpSpgfBsJzIXltIcXLOKMJuhRGalBMAcgIzRnfyQTLEPuPvAVklrLESFUoJuixvgUICBWqlsRmHBwbUxcjzqSwiAegWvslwonihYCQKrikVNmdYCWodyVEdNZZLmpyWxRgOrprgpIBxHCeYORaOQPOwfCrDThysgPWpdTqVJEBHcuZmrLeGvcaYjozlPXJXEyATJngblRJnQJBlfLorkCVPkQfdmPhigDNGcNhBWWlyoFJgHIQjzbXNg");
    int UTmPBlXELc = 351258425;
    string maTEgFxUcDCOaZ = string("WDgHcJOEVvNbBXxnAUuXcNAKuxLoyvXDitftuXaRpWYRgTtYIRyRvNlVUhJhdwHnmGOczAidiKwZHjdWRIJmu");
    string jNVNtVpAK = string("GLNmEbOVhNBUybbNBqayxqMZyBAcKJQGrtoQzbFcpGdldequyOpFYIJGJsgwIJxwgVQUVNxrbZvudkRrVGsufPiqgUPqwpSJjYhpRutWRAhlxaMUiVcmZs");
    bool ShLkczN = false;
    string VXoNTFVvjxboZI = string("fBaiviLnjLyNruOLxVIZBkJrtcpZBnUCTvPMAjXysoPDVfqhDTUoYNZYaRtvUvBrgBvdhhfECOWtHaAubqhhFXYfwCXYIyrJxOjUZlwXnvPMuTCFeitXlnMAumyjGqAoopyREHHtdwhoZUtUOvNxJkqodaiOuoYZmQLZiDBRVxqwELIYbAhROxZCzXNIMjRVluYMBUEmVtXXmPpuFeUvqcSvTvHElciMxJueNjFV");
    string oXelyillkRjxZxrv = string("yXEAotHSUFdHNJMZsAWhXbdTZWVwtJWVGFOvwdvMEsYQquYmQEVCmuuXxUkTtGAXqmxOKwVwZUIgFPIpDkGnDXLluaksyzapQnrojOCdyEhCuaTPWjd");
    double nvsKpWyiXP = 267870.2691868078;

    return oXelyillkRjxZxrv;
}

imbXCmiFuIyK::imbXCmiFuIyK()
{
    this->GobJZMtfjase(false, string("cJCgJkWDuzFyXFtodTkEybFxiJnGsUpaRGXZaFmSuDrntBYuiMUnuDNGBoWAJDaMNlptgoCjxXLPYERWYTnxZXAobKBTjyAWtIZVelbDDDVXwZVCVgaXDXkXrvOXJmbcYZSZhuaiAbsmgtKKksJifZwMNevyDgQyFzEXxMnpbQtFJTDLXoWCngUWlCfXQIAVNafVwtMDpnOasNduEuGrwcOUWsoSOHfWwILZYtMKRXHdHFKlxmTOEsVremepcD"), -744069.9973485798, string("ZXtdwgAiwqoGsHSuBRYBxXzKKkbsYtFgIdfthiRmVzDUhByayqFPitMwEDkTUcvYNQWxZhmHydcVhvYBhMvpkGjqxIZTHjokYdemRLCsNDsdUWHTDftxnOvXzCnteRXxetabHqfuHjaSXAzhkggkOJxALOjK"));
    this->YaqrfaqbHjJXE(-110685.86847718929);
    this->LUHGsFTufisBDXO(1973274835, string("tjMSbMfZxNUcqWNVqMabnPNBOJNLworijTyjHJZwpRBTtTWEqZhUQxjYCfYMQfxFrwgYWhpQZiOkqURcNaYxRNXsafedHbdxFsTefVZVKWQpWGCTrvdGLiTz"), string("kGkNboALtSOsIjNHWsINlbNQdeYkUmDnADyqbCDDhgNvpNhYYzHTpQhbaTXuSFSiIidFOFhRvkkyaMnwSaxbKuADRzXKkUOOzTegglnVrOstOjhyhzNBhAPHrVWAQsRcBsTROJZZtuRgkpTACERTVopnVQugbIgcvmDdWcAHpDHkAksrwrUigxLrQJCKWYNODORJEvOoLCTzkXlfbethVxv"));
    this->hXIbOSsrIatCluAD(-787414940, string("tFJeDNNcCJwFyLkmrOAFSUIVnPISIUvHmDnxBGMIxKRzhbedFndfZddjKFDqeadhaiHR"), -200856.1650488381);
    this->vcsjE(22258.829128915084, -1217084944, -877899.808389359, false);
    this->HZOmx(string("TCsDxnwcKqMuoWSqvpFrwpFWpqPZFfTlJFShToOarHHECELSahXdsuaZcfZRDStuLAaPACzjdTdXdgbtNzQyezLmlrkOiavincTfGAyrVK"));
    this->XImamAYZ();
    this->AhmcOF();
    this->ObODVZeHsKzoyD(string("ymCBkudPcZYvwoJYmzFFmVXxWxPgLftPnOcqByGYbBvGstMOOuUktDKgtuFvYREfSGxrKTPFctfnUIqSQAoiSaWqWgzsIhTmTHXwQgoFuXNCzJBjamIacSZxmgsJBxYSvAUylxcBtDkvRAXYPgkRPCPklmjMZsMCwOuYMJgcRMQVTbnWyPTztCnHqKfriYNLkPColEIAnURTGksuxlKTwnUapgMHhapftw"), string("nLJEKqpDDabaCbXqJRNZmzrtqWUMxiUSLbGxbsYpiRNcUuREDmQgZEsklfddTSwFbbeFGfeUycRjriGKOTJdDxEiCuGLbkdKFIkaAQEiFfeoizRicXuipNpKYKDKIhYDyRaErnqjkDyitNpbKzSyMgWplRhASViHhOWzgMTAXnWpUxHzVJcJBTGzT"));
    this->gelLSmJeqOZ(string("VgjeodjUsxUuVyjdXHBXIpfXjdkStyRxQmrRGHTujLXVRlCtBEiJBYwKPQVevhKYCJckSBspNParveTFuxEChkzllKDbusKVyy"));
    this->JTBlUMnu(true, string("OFQilFELOrcbuVLNfZwZCEUVJNEZalLIMcISbaNDIqEfYlVPfesCOmlXeBRnmODkziTEcKYFLFxFQnOZwFEGjbgcdPsJUiEucfUVEphaRbKDcpwpttHKQaFIfgnwgxKZNTaAMosIEYTeUflQfNhiRbEcpczAKzrsCYWXXoNzHqtstbXfIcwMrtkQtXzUiBUvFOHHjAzk"), 410155.5918296832);
    this->MiWvEilpGtCPOj(-427545.9432582909);
    this->KBLwa(true, -188534.16265039236, -2094913015, true);
    this->iRURKwfSq(false, false, true, true, string("rdtipCbFocStGDWCcDRcxnpTqKCwrHvxftdPuoqLsWrNsgKDDqMwPsxBsacWeHZsiOzGzxoAbwHYUKwCfWCCSULEeMRgLzUBteXSOEiRQNrRzpPE"));
    this->eGMZaYCkX(1281379702, string("EAZfpKxaNVRPjQWOdqIVtTtzcnpIGuEmoRqrwoaEUHtBfDGHFDkOkFAfbrzvFvPKBcwCYNUxBtwTfxkXfsHFlEZxKwapShvNkxiPSZEqvYIBWFrzgWupbJlGfOuuLIppDakqaTAxrmyIkreMNgNECbcFcJvQAgnxrZAONphcLpaGJUWotasFerebOBfGjOFYnpwuAHxUBydkQYgaKuMMyGxruDiZZZhuziyEkLltzA"), true, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OKEsnSwUCMkXHWou
{
public:
    int MZQUd;
    int UxJulbDvxRMoXo;

    OKEsnSwUCMkXHWou();
    void TBjjetzippnkN(int zSiJu, bool zfMnscqxHcXrwcay, string BoiGDLCrXzu);
    double aYoNIpEmz(bool nEQmXPKhZtRupZm, double sMgwHXdH);
    int qBkibDvt(double SqXRyaWWfe, int XWtfN, bool HyBEUmHAt);
    double SRYHuooaF(int TTGihDc, string BzpKzzzTUdFOAa, bool stvtjlCdjBwEjCKW);
    double RjMDJAWOcsTaV(string xFScbQqaLMazCz, double kMEtK, double aPwNQUEmsLtoxdT);
    int SFWiv(string NokLdleNND, int LwbQfsQooxnmX, int EhraEqjQwnOCunT);
    int yxHrGRoMY(bool GiPAmLpXckUWkDC, bool MWCXCvzZlMb, bool gKCiCloC, bool DJgkjjLtzzw);
protected:
    string BxJmMTNBXMckQ;
    string zLHHvbWukjNaZMK;
    string MFUke;
    int ZcIVEQHRd;

    bool MtDVfkdDGGSYdWg(string cfqOkxQIEkt, int gnRUhherPoVKPMhB);
    bool lYYOdh(double XGnYoUPDVmfJ);
    string MbfhQVsPFouvHCnY(int MwVqx, int jQsWVFwriNkiTb, double YLovgp);
private:
    string goAsWzitPpye;

    double xirVaU(bool jKwlSW, int BvpwbyqNPOdRz, bool yLCOgGc, string WuGmgGWaZHgrzU, bool DEkrIjek);
    bool SYwvt();
    int vcqNJ(bool lwTFEmzrlxIDtxVW, int ODIKiHdCNa);
    bool tliNOcJJExEETtm(double hoCvIy, string AfsXnFdhsFItU);
    double clKjpvmnj(int hmwYnn);
    void uliIISwEybel(double wRKsswkumzUC, string DqbmoYgIqszYvs, string bqBtVvxk, double CtEWFUbcj, double sLfwLH);
    void DXxzdvAgWR(int lwOQCRWLIei, string svxLSHH);
    int kJRqDERgx(string CcZquAMe, bool TfRmGHIRvi);
};

void OKEsnSwUCMkXHWou::TBjjetzippnkN(int zSiJu, bool zfMnscqxHcXrwcay, string BoiGDLCrXzu)
{
    string JCaNmRrLzddQPqWs = string("WuZUIHBlcJCxUiSPPTdmEwSibmLrihKtRyeanwCbpmmmvHSkAeIpvgDQWVAQdVYRXlnxooLViPXXnriourqKkytIDGTsxpWQTdUkEAQAUaqJDKNXAYSQiGCCXNatNUvHesatDfDBgwAglbqhibGotePHKuIJsREjbBdTVMCGMyQKLPoOAdiyWhZaLdbpmmoxVtnZRawkeKSvSevJwUSOPEJYvqeEWkiQrIXhRJOMHXfnXw");
    int MskkEL = 1581245310;
    int jxhiv = 915361766;
    bool KhqZnBhRLm = true;
    int XDaXjLTnHlmcAo = -208025565;
    string yxzOtTplmpAgRsW = string("tFQxCgTFtseILJKMohUTJyLGCHbWULSfjvISsfhDCRVDqTQlfgnkYgahejFkV");

    for (int bVpQtyfQJEwlwLPT = 1590772983; bVpQtyfQJEwlwLPT > 0; bVpQtyfQJEwlwLPT--) {
        XDaXjLTnHlmcAo /= XDaXjLTnHlmcAo;
    }

    if (JCaNmRrLzddQPqWs > string("fslabMhmxTSVMJBGPSRYOvRZNGjHUckuWmjtWqrkeCIQjTocMNaWSyOzkBZbaBtnaCVOGCHhmoqxXpbPSZsJnQBUFqwEznrfwHDGo")) {
        for (int ojSTxOMj = 412483544; ojSTxOMj > 0; ojSTxOMj--) {
            BoiGDLCrXzu = yxzOtTplmpAgRsW;
            MskkEL -= zSiJu;
        }
    }
}

double OKEsnSwUCMkXHWou::aYoNIpEmz(bool nEQmXPKhZtRupZm, double sMgwHXdH)
{
    double mPovWybjGabQ = 861214.6615191433;
    bool jFwtmmDVpxjAWSD = true;

    if (nEQmXPKhZtRupZm != true) {
        for (int AQsZNWqQ = 1835712519; AQsZNWqQ > 0; AQsZNWqQ--) {
            nEQmXPKhZtRupZm = nEQmXPKhZtRupZm;
            mPovWybjGabQ -= sMgwHXdH;
        }
    }

    for (int xfxhDzwNojy = 760454333; xfxhDzwNojy > 0; xfxhDzwNojy--) {
        sMgwHXdH = mPovWybjGabQ;
    }

    if (mPovWybjGabQ < -3233.79945028219) {
        for (int mBkml = 663083334; mBkml > 0; mBkml--) {
            mPovWybjGabQ /= sMgwHXdH;
            jFwtmmDVpxjAWSD = nEQmXPKhZtRupZm;
            mPovWybjGabQ = sMgwHXdH;
            nEQmXPKhZtRupZm = ! nEQmXPKhZtRupZm;
            nEQmXPKhZtRupZm = nEQmXPKhZtRupZm;
        }
    }

    if (jFwtmmDVpxjAWSD == true) {
        for (int kwMbv = 969691634; kwMbv > 0; kwMbv--) {
            mPovWybjGabQ = mPovWybjGabQ;
        }
    }

    for (int uTkmC = 841566572; uTkmC > 0; uTkmC--) {
        nEQmXPKhZtRupZm = ! nEQmXPKhZtRupZm;
        sMgwHXdH += sMgwHXdH;
        mPovWybjGabQ /= mPovWybjGabQ;
    }

    if (mPovWybjGabQ < 861214.6615191433) {
        for (int oPKIRPiQLlYYF = 1446419330; oPKIRPiQLlYYF > 0; oPKIRPiQLlYYF--) {
            continue;
        }
    }

    return mPovWybjGabQ;
}

int OKEsnSwUCMkXHWou::qBkibDvt(double SqXRyaWWfe, int XWtfN, bool HyBEUmHAt)
{
    int ioWAPIkUOtzn = 1661387747;

    for (int OtsEgIir = 2019069082; OtsEgIir > 0; OtsEgIir--) {
        continue;
    }

    return ioWAPIkUOtzn;
}

double OKEsnSwUCMkXHWou::SRYHuooaF(int TTGihDc, string BzpKzzzTUdFOAa, bool stvtjlCdjBwEjCKW)
{
    double zzTklInJPX = -696887.9924766775;
    double HxjbMK = 31119.99905689101;
    double wELMRMzr = 106910.47209123007;
    int JwQfqCdZWPwFlsGs = -1758321445;
    int BHqHEt = 1167206455;
    bool bWlbLQMuTCkXG = true;
    double iazaJVrolq = -1019836.9474742503;
    int GRbvakqACtFkO = 478582663;
    int yCSQGFm = 1344023836;

    if (HxjbMK <= 106910.47209123007) {
        for (int rmDoiqhjdBNuEMC = 1797745307; rmDoiqhjdBNuEMC > 0; rmDoiqhjdBNuEMC--) {
            HxjbMK *= wELMRMzr;
            bWlbLQMuTCkXG = ! stvtjlCdjBwEjCKW;
            BHqHEt = GRbvakqACtFkO;
        }
    }

    for (int QbuZUlVhuIS = 980437261; QbuZUlVhuIS > 0; QbuZUlVhuIS--) {
        continue;
    }

    return iazaJVrolq;
}

double OKEsnSwUCMkXHWou::RjMDJAWOcsTaV(string xFScbQqaLMazCz, double kMEtK, double aPwNQUEmsLtoxdT)
{
    double eeCmcz = 157244.291552337;
    bool ufbNDue = false;
    string gJYrqTCRVCSxZ = string("UygYZkjDolhWNlwxFLjhNprgOZavMidzrifQLeaGlHXTCsqtfYwzdxXDLZiUdrjDiUzhzmQXaWbMQWzRNPflvRkkTWsbaIEvRvIdBXFrpnrXKvxkJNIttRDRRBvyvd");

    if (aPwNQUEmsLtoxdT >= 157244.291552337) {
        for (int VQTHPpb = 347512579; VQTHPpb > 0; VQTHPpb--) {
            kMEtK -= aPwNQUEmsLtoxdT;
            eeCmcz += kMEtK;
            gJYrqTCRVCSxZ += gJYrqTCRVCSxZ;
        }
    }

    if (xFScbQqaLMazCz < string("UygYZkjDolhWNlwxFLjhNprgOZavMidzrifQLeaGlHXTCsqtfYwzdxXDLZiUdrjDiUzhzmQXaWbMQWzRNPflvRkkTWsbaIEvRvIdBXFrpnrXKvxkJNIttRDRRBvyvd")) {
        for (int tZjTlOsBfzH = 10945571; tZjTlOsBfzH > 0; tZjTlOsBfzH--) {
            aPwNQUEmsLtoxdT = kMEtK;
            kMEtK = aPwNQUEmsLtoxdT;
            gJYrqTCRVCSxZ += gJYrqTCRVCSxZ;
            xFScbQqaLMazCz += xFScbQqaLMazCz;
            gJYrqTCRVCSxZ = xFScbQqaLMazCz;
            aPwNQUEmsLtoxdT -= eeCmcz;
        }
    }

    for (int RQNKTvDkwZGTYT = 160594397; RQNKTvDkwZGTYT > 0; RQNKTvDkwZGTYT--) {
        aPwNQUEmsLtoxdT += kMEtK;
    }

    for (int IHhHEcJwjG = 1272428416; IHhHEcJwjG > 0; IHhHEcJwjG--) {
        xFScbQqaLMazCz = xFScbQqaLMazCz;
        gJYrqTCRVCSxZ = xFScbQqaLMazCz;
    }

    if (gJYrqTCRVCSxZ <= string("wNoGVVVtcKEtcSnWfhLGYoHagGnQvBGNDTzMjKOeqJBdmEOTIiOvOTRfFYyIOBwelKQTYeGOutOZnBHJTTlXwXHKwRPqiSQGFxbtJJdhUiAXpuHyAOtAlGiFYsojKHboPUyPNRvERkbttGIOawheeMIdKgOTKWsnCIOuzbQjWfd")) {
        for (int EYrRBz = 1594986319; EYrRBz > 0; EYrRBz--) {
            gJYrqTCRVCSxZ += gJYrqTCRVCSxZ;
            aPwNQUEmsLtoxdT = aPwNQUEmsLtoxdT;
        }
    }

    return eeCmcz;
}

int OKEsnSwUCMkXHWou::SFWiv(string NokLdleNND, int LwbQfsQooxnmX, int EhraEqjQwnOCunT)
{
    string BtrbSYXYEwYCet = string("dvubHECEOWjFproSitnEnDORSemgNKuFORWswmVKiANfgcHWwLRfWUMidvWgyacKQfLYsmsiPfPjfSuYTUwLfJwwvZQLOsVeCLywtFxYTcRRdBVECPnmHeFcVVDHkARYtFeHXleGGjAEQQlIRSYOllpOmpgxEkmEpBaaqUDdFiNWGYuUGBPYFyGVVdfyrOnQFblaOaHYKKEvRJrFisbxGBEPMqIXCRogxhdKgVf");

    return EhraEqjQwnOCunT;
}

int OKEsnSwUCMkXHWou::yxHrGRoMY(bool GiPAmLpXckUWkDC, bool MWCXCvzZlMb, bool gKCiCloC, bool DJgkjjLtzzw)
{
    double NYEuNbuUyGOAYJl = 903785.0970937154;
    int rGmTBlG = -470517668;
    string IqskxglEsRvzC = string("nCuUnsulqHkwpyZruzBxsOSbuJOSeYjyZYyjrsAUdFcseXiHreOTwlmrAZFWlO");
    int eHqgJrGLcnfw = 595447930;
    double MFofphJ = 190300.8732476209;
    int TRVRmBDUO = 1938972694;
    string jDZiPPvQInhEK = string("hGEADnAaQAvTdBbvxGIlWcRezOCVUfoRDqDeOQmhZxGcOcyKNseZpMFgBiBIsVBsAyLQwEhqWIBlgvVCpQHAWDtnHGJubsHClEdEtnLhxDnTNfAfhpSGXRycHJVKyKQcDfvVVknYIvLoYQJYlpaQtTtBZIRyErmAoxnNfuvWPRfeiZKyhZGmeZBtrXUrekVvQkjcaeUiSIRdNbSOjhjpqUDMsf");

    for (int Ucrsqa = 1507418593; Ucrsqa > 0; Ucrsqa--) {
        eHqgJrGLcnfw -= rGmTBlG;
        eHqgJrGLcnfw -= TRVRmBDUO;
    }

    return TRVRmBDUO;
}

bool OKEsnSwUCMkXHWou::MtDVfkdDGGSYdWg(string cfqOkxQIEkt, int gnRUhherPoVKPMhB)
{
    double SGCFowhnHRwESq = -563283.080554446;
    bool tQCbxmcJc = false;
    double azXogldxUHVWqdau = -308557.66023408895;
    int rWNMGhgKFtzqGqZ = -1129028275;
    int JXduMsOiVcQrcRF = 1477561884;
    int gCVTenG = 1306851128;
    string jrVOU = string("vgmbshamshUkNIggUsWUVZgzkXlncJnzcjzLBJaQpSZUZSLTlHQvXvlizuBnTLhVUdasAAOKpObGijzgSHegtDXaqMxDpphawXZgCJFDPssdKgLzacIFG");
    int Bkktb = -1631113186;
    double jwBIUNPGiY = -24775.153851607494;

    return tQCbxmcJc;
}

bool OKEsnSwUCMkXHWou::lYYOdh(double XGnYoUPDVmfJ)
{
    string cEPrplkoYJZsmEj = string("sNAatbRfElqcrNGOFPvxRzWrynUBJSqPUBWodSdMoPndpFiJwrZPRrZVUIsamYBnKljGzahrOgpZzELOEznrKvrcbhjWH");
    string phRyhDmIgfCkbm = string("oDaDwXvbIllklPQAognXKvONW");
    int vfKdNtnJ = 508689714;
    double AdlKHUSLz = -89954.67281251732;
    double aXJkpThxUxU = -1033912.8332642489;
    double LIflXiYAiV = 765802.8893782969;
    bool ZpVSWEwVcv = true;
    int ewUxCSWc = -754401131;

    for (int SKKNoatpOVXqazwK = 649076599; SKKNoatpOVXqazwK > 0; SKKNoatpOVXqazwK--) {
        vfKdNtnJ *= vfKdNtnJ;
    }

    if (vfKdNtnJ == 508689714) {
        for (int uGkdEcsr = 69292941; uGkdEcsr > 0; uGkdEcsr--) {
            XGnYoUPDVmfJ += LIflXiYAiV;
            cEPrplkoYJZsmEj = cEPrplkoYJZsmEj;
            ewUxCSWc = vfKdNtnJ;
        }
    }

    for (int KwSVChYJCRSEgDZ = 2098897855; KwSVChYJCRSEgDZ > 0; KwSVChYJCRSEgDZ--) {
        XGnYoUPDVmfJ *= LIflXiYAiV;
    }

    return ZpVSWEwVcv;
}

string OKEsnSwUCMkXHWou::MbfhQVsPFouvHCnY(int MwVqx, int jQsWVFwriNkiTb, double YLovgp)
{
    bool PkZzaoEVBJZrQhec = false;
    double oJVjmtMMHHS = 854829.6028526926;

    for (int fdYAjGBEfbAHZqM = 1820973854; fdYAjGBEfbAHZqM > 0; fdYAjGBEfbAHZqM--) {
        oJVjmtMMHHS *= YLovgp;
        oJVjmtMMHHS *= YLovgp;
        jQsWVFwriNkiTb = MwVqx;
    }

    return string("UbXDBiMANRSbcTEBYyZDMazoKxvRZpnLhprNVobNBtXTQdOpXhqowfzlImTqGFJciZXdDVWZXQEzkquy");
}

double OKEsnSwUCMkXHWou::xirVaU(bool jKwlSW, int BvpwbyqNPOdRz, bool yLCOgGc, string WuGmgGWaZHgrzU, bool DEkrIjek)
{
    int YOlXOdqSYyM = 621889475;
    double RLGEK = 418726.3758298347;
    double VgKHv = -83098.15435767396;
    int mlXwu = -1297104350;
    double RKAJyIKzGwfIiE = 514927.9917450763;
    double sHBorRYjH = -144317.77281933613;
    int BONWvuzXRqRHBV = 784543673;
    int ZmKFcFu = 826747895;
    double LKpTa = -997183.2461741781;

    if (RKAJyIKzGwfIiE != 514927.9917450763) {
        for (int wwveEnJPkx = 604286155; wwveEnJPkx > 0; wwveEnJPkx--) {
            RKAJyIKzGwfIiE /= LKpTa;
        }
    }

    for (int qaYceYXS = 1004316136; qaYceYXS > 0; qaYceYXS--) {
        DEkrIjek = DEkrIjek;
        ZmKFcFu += ZmKFcFu;
        mlXwu *= ZmKFcFu;
    }

    for (int gcxfSSikTUbkaL = 648907776; gcxfSSikTUbkaL > 0; gcxfSSikTUbkaL--) {
        mlXwu /= BvpwbyqNPOdRz;
    }

    if (mlXwu >= -1297104350) {
        for (int SiMyBZWNbY = 525947199; SiMyBZWNbY > 0; SiMyBZWNbY--) {
            continue;
        }
    }

    if (YOlXOdqSYyM < 826747895) {
        for (int KYeWDoYBWT = 1103845171; KYeWDoYBWT > 0; KYeWDoYBWT--) {
            LKpTa *= RKAJyIKzGwfIiE;
        }
    }

    for (int ISwFNcYztjktplt = 1489945337; ISwFNcYztjktplt > 0; ISwFNcYztjktplt--) {
        continue;
    }

    return LKpTa;
}

bool OKEsnSwUCMkXHWou::SYwvt()
{
    bool faWgJibGNgpnnc = true;
    int IRbmsYzSqiVPfu = -1643346707;
    bool josYQihmeRTsQzKX = false;

    for (int GpaNdGDNZKqYDTz = 2120944198; GpaNdGDNZKqYDTz > 0; GpaNdGDNZKqYDTz--) {
        faWgJibGNgpnnc = faWgJibGNgpnnc;
        faWgJibGNgpnnc = ! faWgJibGNgpnnc;
        josYQihmeRTsQzKX = josYQihmeRTsQzKX;
        faWgJibGNgpnnc = ! josYQihmeRTsQzKX;
        faWgJibGNgpnnc = ! josYQihmeRTsQzKX;
        IRbmsYzSqiVPfu -= IRbmsYzSqiVPfu;
        IRbmsYzSqiVPfu /= IRbmsYzSqiVPfu;
    }

    for (int OpfVF = 1094891734; OpfVF > 0; OpfVF--) {
        faWgJibGNgpnnc = faWgJibGNgpnnc;
    }

    if (faWgJibGNgpnnc != false) {
        for (int MuGtQVrqm = 2048350797; MuGtQVrqm > 0; MuGtQVrqm--) {
            faWgJibGNgpnnc = ! faWgJibGNgpnnc;
            IRbmsYzSqiVPfu /= IRbmsYzSqiVPfu;
        }
    }

    for (int WDDhzcqopUoHsD = 1623743581; WDDhzcqopUoHsD > 0; WDDhzcqopUoHsD--) {
        faWgJibGNgpnnc = josYQihmeRTsQzKX;
        IRbmsYzSqiVPfu -= IRbmsYzSqiVPfu;
        josYQihmeRTsQzKX = josYQihmeRTsQzKX;
    }

    for (int gbtxClCBbf = 1144848835; gbtxClCBbf > 0; gbtxClCBbf--) {
        josYQihmeRTsQzKX = josYQihmeRTsQzKX;
        josYQihmeRTsQzKX = faWgJibGNgpnnc;
        faWgJibGNgpnnc = josYQihmeRTsQzKX;
        faWgJibGNgpnnc = josYQihmeRTsQzKX;
    }

    if (IRbmsYzSqiVPfu >= -1643346707) {
        for (int MiXKonXicjvOyD = 486430909; MiXKonXicjvOyD > 0; MiXKonXicjvOyD--) {
            josYQihmeRTsQzKX = ! josYQihmeRTsQzKX;
            josYQihmeRTsQzKX = ! faWgJibGNgpnnc;
            IRbmsYzSqiVPfu += IRbmsYzSqiVPfu;
            faWgJibGNgpnnc = ! faWgJibGNgpnnc;
            IRbmsYzSqiVPfu += IRbmsYzSqiVPfu;
        }
    }

    return josYQihmeRTsQzKX;
}

int OKEsnSwUCMkXHWou::vcqNJ(bool lwTFEmzrlxIDtxVW, int ODIKiHdCNa)
{
    int OnBShIjYJRLPAHB = 1374526651;
    double AHOsDlfXNWzq = -346434.20866357494;

    for (int OfemkDJYGwL = 2029032810; OfemkDJYGwL > 0; OfemkDJYGwL--) {
        lwTFEmzrlxIDtxVW = lwTFEmzrlxIDtxVW;
        OnBShIjYJRLPAHB = ODIKiHdCNa;
        lwTFEmzrlxIDtxVW = ! lwTFEmzrlxIDtxVW;
        lwTFEmzrlxIDtxVW = lwTFEmzrlxIDtxVW;
    }

    if (ODIKiHdCNa > 1374526651) {
        for (int jNWNZJMOhmXYcf = 2051414022; jNWNZJMOhmXYcf > 0; jNWNZJMOhmXYcf--) {
            lwTFEmzrlxIDtxVW = ! lwTFEmzrlxIDtxVW;
            AHOsDlfXNWzq -= AHOsDlfXNWzq;
            lwTFEmzrlxIDtxVW = lwTFEmzrlxIDtxVW;
            lwTFEmzrlxIDtxVW = lwTFEmzrlxIDtxVW;
        }
    }

    return OnBShIjYJRLPAHB;
}

bool OKEsnSwUCMkXHWou::tliNOcJJExEETtm(double hoCvIy, string AfsXnFdhsFItU)
{
    double MGATVmykMyAxOPI = -430003.1927334794;
    bool TPiphqReoyTfe = true;
    int oTjMQIkgLokStC = 430740295;
    int PrdBFqrQBqSsr = -1308911397;
    string ilMqkzHsXOmoH = string("UbLnbeSpbJiMemqOEAfnIIWjCOLqRczCRAikVBVZUxgumeqzYahnezwumeVgbKwkGyWRHlRPVFcCzmopLlhkkwysldZqQOxqEPPiRrRAodXztkvB");
    string wyHxzddhvPlTFXjK = string("qZcAZZnNkZZmBtlVVoAkEsSbcIbLFBcPaRcjNaZnZMpDWmmezKZmgUtkQRTQe");
    double AzYRpbt = -266419.2254442339;
    bool WsvMpUkHiBPSs = true;
    string GbxjuvTICjmdcovN = string("yiGzuRDSklTAAsQQgtAXGeFlrwCVj");
    bool VDfeoQpfWrlt = true;

    if (hoCvIy < -430003.1927334794) {
        for (int KjvfiXNTmAMJaT = 1949408103; KjvfiXNTmAMJaT > 0; KjvfiXNTmAMJaT--) {
            VDfeoQpfWrlt = ! VDfeoQpfWrlt;
            GbxjuvTICjmdcovN = ilMqkzHsXOmoH;
            MGATVmykMyAxOPI = AzYRpbt;
        }
    }

    if (VDfeoQpfWrlt != true) {
        for (int iNSiFvddi = 1691113903; iNSiFvddi > 0; iNSiFvddi--) {
            continue;
        }
    }

    for (int WnzIzNf = 822888814; WnzIzNf > 0; WnzIzNf--) {
        ilMqkzHsXOmoH += wyHxzddhvPlTFXjK;
    }

    for (int kTtCbu = 1504116827; kTtCbu > 0; kTtCbu--) {
        continue;
    }

    for (int iibvP = 2108607488; iibvP > 0; iibvP--) {
        AzYRpbt /= MGATVmykMyAxOPI;
        GbxjuvTICjmdcovN += GbxjuvTICjmdcovN;
        AzYRpbt = hoCvIy;
    }

    for (int bGHfWc = 99340239; bGHfWc > 0; bGHfWc--) {
        AzYRpbt *= MGATVmykMyAxOPI;
        AfsXnFdhsFItU = wyHxzddhvPlTFXjK;
    }

    return VDfeoQpfWrlt;
}

double OKEsnSwUCMkXHWou::clKjpvmnj(int hmwYnn)
{
    int nnwrzwjRdp = 1798167891;
    bool gqQKsQOs = true;
    bool WcKBKp = false;

    if (nnwrzwjRdp >= 1086881375) {
        for (int RBxjM = 1260256008; RBxjM > 0; RBxjM--) {
            hmwYnn /= hmwYnn;
            WcKBKp = ! WcKBKp;
            nnwrzwjRdp /= hmwYnn;
            WcKBKp = gqQKsQOs;
        }
    }

    return -283584.8316855334;
}

void OKEsnSwUCMkXHWou::uliIISwEybel(double wRKsswkumzUC, string DqbmoYgIqszYvs, string bqBtVvxk, double CtEWFUbcj, double sLfwLH)
{
    string oUnlpbfG = string("MRxfaIzejSWehNNvBFwiFZgFLDHZqBrmGZKKBlpMldeDyCrHaonAPYiXpDkjpUMsXrmAlQMRZjVaaSYrxVWIbboucGEuDDoctuZEnHKFCQQyoZTcij");
    bool TzSLeN = true;
    double vvsRQrqLrVmVJRTu = 852559.7541265466;
    int PNGDNwS = 1223422795;
    int XokFUeEtTqWDN = 1382328409;
    bool leRHJ = false;
    bool OOfRgmYyOOVwir = true;
    int QGwLFnQeQEriJEe = 1200268183;

    for (int CqqSmXpLkvQgxbp = 920196327; CqqSmXpLkvQgxbp > 0; CqqSmXpLkvQgxbp--) {
        TzSLeN = ! leRHJ;
    }
}

void OKEsnSwUCMkXHWou::DXxzdvAgWR(int lwOQCRWLIei, string svxLSHH)
{
    int hKYvmhD = 1347651524;
    double gOrHxVKhVXBNY = 795748.647695403;
    string BQstoJU = string("AwqwoHnwUvjmLpfgaHMWFqPeOoNkvTJCBWxPWIwyfiQIoyNvvuGAYdVRCyYvxWziXFfewTYtIuRFizUzpZpXKaPHYvxhZ");
    double BCErQV = 442465.0218912506;
    int ClsEnsfSGEB = 1381903079;

    if (svxLSHH != string("AwqwoHnwUvjmLpfgaHMWFqPeOoNkvTJCBWxPWIwyfiQIoyNvvuGAYdVRCyYvxWziXFfewTYtIuRFizUzpZpXKaPHYvxhZ")) {
        for (int zScsfkJwT = 1762473655; zScsfkJwT > 0; zScsfkJwT--) {
            hKYvmhD += ClsEnsfSGEB;
            gOrHxVKhVXBNY += gOrHxVKhVXBNY;
        }
    }

    for (int clInxJHCdGatHNYb = 773688815; clInxJHCdGatHNYb > 0; clInxJHCdGatHNYb--) {
        lwOQCRWLIei -= lwOQCRWLIei;
        hKYvmhD /= hKYvmhD;
        hKYvmhD += ClsEnsfSGEB;
    }

    for (int EXEzEMi = 1461300727; EXEzEMi > 0; EXEzEMi--) {
        lwOQCRWLIei *= ClsEnsfSGEB;
        hKYvmhD -= lwOQCRWLIei;
        hKYvmhD *= lwOQCRWLIei;
    }
}

int OKEsnSwUCMkXHWou::kJRqDERgx(string CcZquAMe, bool TfRmGHIRvi)
{
    int jHMntgFnu = -1470635647;
    int RetbAoFdQ = -681008799;

    if (jHMntgFnu > -681008799) {
        for (int TLhlyqihXgGJyUB = 999470429; TLhlyqihXgGJyUB > 0; TLhlyqihXgGJyUB--) {
            jHMntgFnu -= RetbAoFdQ;
            RetbAoFdQ = jHMntgFnu;
        }
    }

    return RetbAoFdQ;
}

OKEsnSwUCMkXHWou::OKEsnSwUCMkXHWou()
{
    this->TBjjetzippnkN(629015229, false, string("fslabMhmxTSVMJBGPSRYOvRZNGjHUckuWmjtWqrkeCIQjTocMNaWSyOzkBZbaBtnaCVOGCHhmoqxXpbPSZsJnQBUFqwEznrfwHDGo"));
    this->aYoNIpEmz(true, -3233.79945028219);
    this->qBkibDvt(-351494.62441797217, -1052011886, false);
    this->SRYHuooaF(-75498649, string("VXcduMtAbBXEUshjWqmULLRLGHIvhBHXtBeirPAErdllFHBqNCXfBLczjIvGvKGKbcFoeRLyKAGpufuodgjQEtDIGeUWyCyFgqnxicrLgZylnogdnfMtvYkSGCXFCGInaLFcRWaJwgAwtEcUabwxZHdVuqVstXMycoZGPzaHrnjheTlJhEdhiBVqygmoVFxzlfTSHxQlNCjahQOQwRdxXtimlXbISlJKcshllWIrPqUUGZARSDDp"), true);
    this->RjMDJAWOcsTaV(string("wNoGVVVtcKEtcSnWfhLGYoHagGnQvBGNDTzMjKOeqJBdmEOTIiOvOTRfFYyIOBwelKQTYeGOutOZnBHJTTlXwXHKwRPqiSQGFxbtJJdhUiAXpuHyAOtAlGiFYsojKHboPUyPNRvERkbttGIOawheeMIdKgOTKWsnCIOuzbQjWfd"), 105742.59765058247, -523840.65547448164);
    this->SFWiv(string("eFSQrmKlPpFbqJUZvjZToHQVRnBLEpeBAmhXJjYEDZArHfgzartolUubhwILRlclGNVQtTsVVuRpaKBgASOuxywmPRfSYRCSmuxJaFPEoAcIWIyeOBjmwqwFukFynaXHAsfFWlsoelXhoAu"), 1321749382, 206991364);
    this->yxHrGRoMY(false, false, false, false);
    this->MtDVfkdDGGSYdWg(string("HIVLgmFkRhOLRUdISCSUsMHRqnThwAkQdWgPvQvrKvVWrnAYDLDANLKFmRPDJYhqVYxARFcpRiHGZbjzwPPOpozLeItxMDGmNeWVFcwNGVpZWrBGWTnepQjPagIceBxPagJCNymNZdSZIOBNmcMllfgaIgxqWdyzkUjLFSPlsbyPHUtbTCgsjZRm"), -1747744758);
    this->lYYOdh(-963887.3027209423);
    this->MbfhQVsPFouvHCnY(211122207, 120727547, 540023.9856862074);
    this->xirVaU(false, 135893444, true, string("zqOkSccTTFwjIrMsYmJnmxiBHvjoQeroKQw"), true);
    this->SYwvt();
    this->vcqNJ(true, -872249674);
    this->tliNOcJJExEETtm(120820.61825612286, string("jDmIRXRRNpDRnjDIAYqfWosfxUEQARPEaDyjGinoQuDejbAzraqsPzdDZsDSYESmfOAGblRbQSMWNXKfRKTbyuZmzUPIubLGIjHODawQKOSJEvsNaVtoXUJPdtCyjaZStdvxxpgGvwMpjqbrvxWwDWTeccVLWWFyyjUfXTrrjITZgztptFhLxtwsrnEJCYgsibCsmZHxhaSqsPzRkqsnrsVUYRRQMIdZxmkEZGfXIBPfBJbTHVVdtZtLtFZWRjk"));
    this->clKjpvmnj(1086881375);
    this->uliIISwEybel(-11367.01695302949, string("awMlXTmMuiBwdOyEaxywKDyFgppqHXaChKdUQIRXFgbqTWLcqjGwHoSqAdLzzDclMtlHuiOdmjgKsHKHPenranNaEndVjslEqXFKDrGRytotbCeTXJMUTaRenxgGHwzLUmQ"), string("OJOWTTzjPHeonzLeSivSwlpurrgpEoBoacEOSEWXolVZHlYjVRXhYJqdOaypgULIVhymwMgtNplPqpKQWQdiQOkPWVceZJzluDEQGjruYXdREtwwgzrrLtzQfzxcEanKUQlIVDwyjKajaNOOGdJLYxVTtcKBPJairuFihOXKRjenmgMZhmZOJMEXAKTTayAuRGDKNsWIokWQmAmwhpXBNEJ"), -400697.813028068, 205234.78608765293);
    this->DXxzdvAgWR(-1258529804, string("UrVuKgOfwniWtlZBXIqyevSmXnMmkYVTysxFNwPrmheojUuleyokFBTaKidQapBpSvTZmQHysMJvMCdRvkCfCoTRHRpTIzVkUUUMxAVReIfZDipyuFXETuOQMRwgrPurlOPivAAQdVQZOJIHFABkuvWRgTGjsKlpZ"));
    this->kJRqDERgx(string("dCxfmrnAzyNsWNnTDqVCJEBLVucLOVsdOYPUxMoeFBrqKBFynkWOvLyCCJstihKhZnbmSAoYmBLTiVZZBhmZq"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QvubdRQLP
{
public:
    string yNVquIxFsL;
    int oplcFt;
    bool twCAgYnUyConIxKe;

    QvubdRQLP();
protected:
    string lcoxzZcCpk;
    double UzERMrbKp;

    double QzlPYKxFlt(string bRxfvUoEvRrWh, double DHxLdDUbWrBsiEz, string DfwzEkQfF, bool fYpnCMbIGFlgjH);
    void qmXAiob();
    string etuObRLgmSATpCyd(bool pDbmyQPT, bool mbaNVvFDHvA, int GPGROQWVNYkz, string cEAebxALd, double mQdbn);
    bool lSWRapaIBc();
    double YEMRmnzXrWhU(bool fAghjSFcVUrrs, int gAYEhqErINFOBktb, double ImTapLzf);
    double fnfnILUoDz(string mZMvrfTFoHK, double xLZncbHOYskRbkr, int ZDrSnCNpRURuLThQ, bool edQEFxRrePyr, double qYTHFVKfbZSJ);
private:
    string tyLLzZVDSr;
    double CANFdFWxMNJRJ;
    int JzIabltfeWD;
    bool uyTAvewp;

    int vnvxXecLjUyIrBZc(double xTgPSpqhHe, bool OZUbzFyiROqF);
    void deAcRv(bool sZCqpXBmkrtqVc);
};

double QvubdRQLP::QzlPYKxFlt(string bRxfvUoEvRrWh, double DHxLdDUbWrBsiEz, string DfwzEkQfF, bool fYpnCMbIGFlgjH)
{
    double ZwymGEN = 280973.6596528577;
    bool NzrkzWLRI = true;
    int lRMVG = 2039984814;

    for (int PjsuBK = 2020241508; PjsuBK > 0; PjsuBK--) {
        continue;
    }

    for (int oNHcwaeOexXLMMHe = 315982321; oNHcwaeOexXLMMHe > 0; oNHcwaeOexXLMMHe--) {
        continue;
    }

    for (int vZGsItkze = 1233067787; vZGsItkze > 0; vZGsItkze--) {
        DHxLdDUbWrBsiEz += ZwymGEN;
        DHxLdDUbWrBsiEz += DHxLdDUbWrBsiEz;
    }

    for (int ohicdCAExyyN = 515792924; ohicdCAExyyN > 0; ohicdCAExyyN--) {
        DfwzEkQfF += DfwzEkQfF;
    }

    return ZwymGEN;
}

void QvubdRQLP::qmXAiob()
{
    int DbujZEw = -1208738483;
    string LzpHf = string("JTEkmSRfzStukjEJuEvQFhRaxXAeydDACbqakmPCTZTPIXqnPcwSEyhGMwuVIjBOOpqAltyizEQYCTlbrLzsQEGrV");
    double tcHlXhRTspXKjQTL = 758718.5525457473;
    double EhZOSxjwufzMmouG = -433971.06602910854;
    double zmJNGpgDmlJaeVw = 454761.0272214736;
    string VwkIHURDatK = string("aphDYDbHKjOTcGVZxXLLKSYDzOxgkELEdfhRcUCcrUayNEldXcStKsIcFUALfWcLbwNHCXIYtIxtvYxSQmoIceynMCWxbdCKmAiuYLmJcuzowRpoejUtHrAVITvNtELuKBkIJToCBpdSnsCWfNmnLlquhIGrDdcsbNuVTRnXtFnEJlxrVmjqtrHrXCgxJYWypZQtmLoxyRAnvRZnTkFElvsPZHLuxoZwkhFtkNVnlrlfcixR");
    int ylaPWTGwrCMjig = 1047120038;

    for (int BDkwuyS = 156690379; BDkwuyS > 0; BDkwuyS--) {
        VwkIHURDatK = VwkIHURDatK;
    }
}

string QvubdRQLP::etuObRLgmSATpCyd(bool pDbmyQPT, bool mbaNVvFDHvA, int GPGROQWVNYkz, string cEAebxALd, double mQdbn)
{
    string CkyqGjbnATqmagT = string("JMXgNHkmbkdDvagCCGCeSkcvatuIHYASJeHkrbYJMWLYPqkyWnUdYiCIQNUxcxoLTNczCeBWqoDXUVPUezWJjXobeyKKaFhMcsoNBXIGpknbMHzOLzquPWJwttastEbJvTHvUusuSsfhARLOGHmnPvODckTOzGdEQsk");
    bool cbBltCgeuXUvof = false;
    double gZSCwaPUP = 406885.68798893987;
    int VWeXdEkf = -2143170123;
    string wGWnylYW = string("armhInnXLQRtoyQKTRSulAxHvJdEJGAsEUQPZjKGwWxnZarQhQfaQJhfTxLebTr");
    int NWBMTY = -2127035548;

    for (int tUADgNoaflP = 1290081338; tUADgNoaflP > 0; tUADgNoaflP--) {
        NWBMTY /= NWBMTY;
    }

    for (int NtqsgPiHhJz = 2095130625; NtqsgPiHhJz > 0; NtqsgPiHhJz--) {
        pDbmyQPT = cbBltCgeuXUvof;
    }

    for (int HEkwZZfe = 432720051; HEkwZZfe > 0; HEkwZZfe--) {
        continue;
    }

    return wGWnylYW;
}

bool QvubdRQLP::lSWRapaIBc()
{
    int fKHGCMEhy = 520172749;
    string wBtREAZNlYSW = string("gdIlEggotAQIjKhECGqvUVZBYQhPOlzsneCuyfoWKFsJBmBhOfSrEvrRzBhdqSXxEMFnDuYStvkMhcvbqZRXHMHRQCsrYwEkluwUHAwpXYVkTzTAuFlHCtMLofoUePxQpRBqCgzfXYICIDwgMJVqLIuMUxEUIuDaiCxJDMFwpqwkWSqHIoE");
    int jXQQknfSqk = 982385202;
    int tYnxqT = -988572688;
    double wumBXNmlftbsPf = -468059.78574304766;
    string DNcnFGhkBX = string("LDHpXLqQTdXGcFPnVtbgQjtcvTyCUAhMPOEUybSyurKNWQVdKoISZXOdQksnqIxCvcvJsGJGYNTSIkSjAwghdsRXXZmPADxacTMWQvVVunbLuIFfuCjjAkZpukSWmkZtLDBhdUDaEppWgneWateBtALLuSspzYXZNKPVHgkDqELhMFscIELNfNQXsOLXFxPQaDaQoOcWzLzOaiMKbJsSfdtEEniwSQKkwrcUvgsdNXTsyqxwvEoWDatseyMdsHy");

    for (int THOJqTsMHWRyXrB = 1120084685; THOJqTsMHWRyXrB > 0; THOJqTsMHWRyXrB--) {
        continue;
    }

    return true;
}

double QvubdRQLP::YEMRmnzXrWhU(bool fAghjSFcVUrrs, int gAYEhqErINFOBktb, double ImTapLzf)
{
    int zCKtWXrFbgpZT = -1522456428;
    double ZGeNYvLaAzuzNE = 387145.4086920433;
    bool UgQdjclVrh = false;
    int JhMRzpApidPRUrG = 1274500099;
    string ugqgi = string("uUSwSczwHoToRmvoAHhrUAlIljEJWxlgVpPmJcCgIwzglDbFOsCBQwNTgALuhBLswUgKtJNkkSavrJbrnMbDbaexIxLwiwlYkgjGxcVjxYkKpmrgOeGzOgXGdaiVnlfaiZwUxHEWYklCeHhojVXKixJvjCJuyDsZhEtFLxCcFaVPgwDajpyHZrPKmRqjhXXWyw");

    for (int eOKhqsoNf = 1127721359; eOKhqsoNf > 0; eOKhqsoNf--) {
        continue;
    }

    if (JhMRzpApidPRUrG >= -195392840) {
        for (int CIaVETkJpChvC = 328658171; CIaVETkJpChvC > 0; CIaVETkJpChvC--) {
            ZGeNYvLaAzuzNE /= ZGeNYvLaAzuzNE;
            fAghjSFcVUrrs = ! fAghjSFcVUrrs;
        }
    }

    return ZGeNYvLaAzuzNE;
}

double QvubdRQLP::fnfnILUoDz(string mZMvrfTFoHK, double xLZncbHOYskRbkr, int ZDrSnCNpRURuLThQ, bool edQEFxRrePyr, double qYTHFVKfbZSJ)
{
    double xPpAj = -737742.9025005;
    bool HvrmQNTUigqCf = true;
    int eWHyvTV = -237989414;

    if (ZDrSnCNpRURuLThQ != -170535682) {
        for (int qAYEwNfuDAWEi = 1988179418; qAYEwNfuDAWEi > 0; qAYEwNfuDAWEi--) {
            eWHyvTV /= ZDrSnCNpRURuLThQ;
            xLZncbHOYskRbkr *= qYTHFVKfbZSJ;
        }
    }

    for (int lgAxLIN = 395393138; lgAxLIN > 0; lgAxLIN--) {
        qYTHFVKfbZSJ /= qYTHFVKfbZSJ;
    }

    for (int dpCKEKmMonHs = 326430331; dpCKEKmMonHs > 0; dpCKEKmMonHs--) {
        ZDrSnCNpRURuLThQ -= eWHyvTV;
        xLZncbHOYskRbkr = xPpAj;
        xPpAj -= xLZncbHOYskRbkr;
    }

    for (int GpfXztyehfOiOvLF = 1900257562; GpfXztyehfOiOvLF > 0; GpfXztyehfOiOvLF--) {
        qYTHFVKfbZSJ = xLZncbHOYskRbkr;
        qYTHFVKfbZSJ += xPpAj;
    }

    return xPpAj;
}

int QvubdRQLP::vnvxXecLjUyIrBZc(double xTgPSpqhHe, bool OZUbzFyiROqF)
{
    int ZpddRuYlJljO = 502808068;
    bool ajMFqQCVx = true;
    double NxYbXutDXTYQHv = 119424.64849133379;
    bool hrlskzLXqvNpYk = false;
    bool GLgVtjqBy = true;
    string IrtjnBcqxXIGtO = string("FYVRBICEgqnYOxCovJUyKqdMdZqBYIMhOkDkmhsZhtCjGxptxjCJptXGbpeHlTrtkalWoXKHGwyNQbNDrMTMGZJcZaADoYBbEFPptLRxhzaPzMgKXQlvtHGgeVbqKAEvpgDRTuGuaNsxqvSdkoDsYcmDFJxXKREOnWtVSujaMXcJEjzTWjUVaxKkpNrLZmSbMJayquWZtaBvLgpHFddAlcRUG");

    return ZpddRuYlJljO;
}

void QvubdRQLP::deAcRv(bool sZCqpXBmkrtqVc)
{
    bool NPcrqwXuOb = true;
    int PbyGZSQyGtsA = -887012973;
    bool kTMgS = false;
    double QERASTcoGU = 826272.366070924;
    double ChbwTcuYbUcg = 601716.6846893678;
    int bHhtAmSVFp = -293269777;

    if (PbyGZSQyGtsA > -293269777) {
        for (int GmoHsbunDXEK = 1512144450; GmoHsbunDXEK > 0; GmoHsbunDXEK--) {
            kTMgS = ! kTMgS;
        }
    }

    for (int KgdSdbsDCLEpgm = 456707133; KgdSdbsDCLEpgm > 0; KgdSdbsDCLEpgm--) {
        ChbwTcuYbUcg += ChbwTcuYbUcg;
        kTMgS = ! kTMgS;
        ChbwTcuYbUcg -= ChbwTcuYbUcg;
    }
}

QvubdRQLP::QvubdRQLP()
{
    this->QzlPYKxFlt(string("WyshYmOCXKNxAmkGXFHiDSAWbTtiSTOTNINhktTuhozPeZGMTnJYBPYifxXpHdzfpZjcrAnLNAUikJZbZLyRsbdZmFNzdSgsIrtZwwDILxjeuLHkjhPrauwzgfXHOrIdzMhHjMRSbslqlnEoYnPDeWFbWOLtPYEq"), 230795.1137165668, string("mJijXPdusEbygNhClRSEAYsatLHZkeMAcGEOQEnKmpmfZwlfzGcHkDMdQpIOEosYazXwbLqVCxTzpQlAWrYhehGDpOMOdfFWLKRYCdtqQcpSuftpFQJMEkUdHZcYrVSapzeqdjFW"), false);
    this->qmXAiob();
    this->etuObRLgmSATpCyd(true, false, -1203801740, string("FMznysqutZsmKbPxusKOIzDcmQOvuWjqqQvtrVRkOsOuGqqLILbEtsTmBzaySdHMMqyrGDkxjqaaJVXiZGHnkauXhjfVDdraPZaupxaUMAhQhLBNqocUifGWTjnwQSVyEBBGRRPhMROlirShmuiwlhXnsDEcCobGZNJehNoGd"), 617512.3437969643);
    this->lSWRapaIBc();
    this->YEMRmnzXrWhU(true, -195392840, -916754.2854196803);
    this->fnfnILUoDz(string("NIhpzRzrSxpkkLlBkkXAwTEjAeByuyXkJSbOxTVSvWuvIVWTrmLyvWdVSRYMaFrdOiXCZpQlqGqDRsqtSnGoAxpcdkFjyybukUivJUZyS"), -597380.9636151127, -170535682, true, -160724.22096754736);
    this->vnvxXecLjUyIrBZc(-545268.8209555753, false);
    this->deAcRv(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UukAdxhRLsxFC
{
public:
    double pMitkgInQpak;
    int pKjnbfbgnLnTBMHY;
    double trMBXLnqMnrvXT;
    double ijONjzBCmXtEhjKK;

    UukAdxhRLsxFC();
    bool IkcUVQJ(int ooaxSWwviTFKvXOI, int FVJcEZYfu, double BrzLyfiyWEB, bool jWfyHwqPakJ);
    void AZlXb(bool CuqOQ);
    string lHgYMJtpLsSF(string eOuZlmQlPSfQUTMY);
    string UUBeSkISmlyDqm(int EfttZeXwpCeXXS, double udJdHxoxSQXlclo, double kdXbF);
    bool BxybvBJRPQruyV(bool MKkcNJX, bool bEyABjPFoRtgQZn, bool IRiLu);
    bool rmsdTLtUWzM(int IlhNKkPRJj);
    int HcuveGAzDZZGf(int agpBWUkyEBnxP, string wpFKVMhyAoDhNpoH);
protected:
    double gOgkavOolKSNDnu;
    string OvaUAypULggGExig;

    int YTnXtbJlBLb(double lXaFNrRWRMWoCc, bool GbdxV, int BoIjzLHuLcYX, int DkfhBvjR);
    string nnBhfkJJHgn(int ClFDCXXlrMhnlw, double yAZpDjnUaOcjaYM, bool pXEPAFOwoidYSl, bool GSXsxCDtwGc);
    bool DIYTciUyMaEYIUD(bool TJLzEKfz, double jJDVYkrPRmimW);
    double WjbdkXuHHcMVQxq();
private:
    double pVyCyJLwRVOYFU;
    string ChvHeOnIuksyS;
    bool KYCFGAbQyYG;

    double CCBWymSEP();
    bool asNAHfvsQe(string ZbgHhRagrr, double sKZEKflMEB);
    string zfkyKd();
    double PMxmEsKVTN();
    bool QFuzqDoArhDkCGa(int qwbThvAR);
    string EPCVENjvGuXc();
};

bool UukAdxhRLsxFC::IkcUVQJ(int ooaxSWwviTFKvXOI, int FVJcEZYfu, double BrzLyfiyWEB, bool jWfyHwqPakJ)
{
    int OPCgnFKcMYUOb = -255268759;
    bool juznYUcVwHArNDR = true;
    string KRnZOZn = string("fuqyABrtXbSWKcZJJTzBVIbWrTnGcRYgeWxgyBTSVEoPJmKHzowGmsSQDN");
    bool QAyonPO = false;
    bool HlkeifJFVS = false;
    double wOctAylOW = 80604.91791048385;
    bool pUCUZiq = false;
    int seEpUNBauT = -2073820886;
    string FtpzO = string("PJALYwKNADqlsbBpCsKWPKFLyJBTCHvrXzHUaZtDGIyjjNwpwiON");

    for (int oitbl = 327577496; oitbl > 0; oitbl--) {
        OPCgnFKcMYUOb = OPCgnFKcMYUOb;
        seEpUNBauT *= seEpUNBauT;
    }

    for (int sIoqULabUGU = 506922037; sIoqULabUGU > 0; sIoqULabUGU--) {
        jWfyHwqPakJ = HlkeifJFVS;
        OPCgnFKcMYUOb /= FVJcEZYfu;
    }

    if (seEpUNBauT < 1818935259) {
        for (int Qqwqg = 827151255; Qqwqg > 0; Qqwqg--) {
            continue;
        }
    }

    return pUCUZiq;
}

void UukAdxhRLsxFC::AZlXb(bool CuqOQ)
{
    int AvRCsrhqLcJG = -377153707;
    double OhcgItgmAn = 86008.58712425159;
    string bZkTUfq = string("LDMdUrYCRozPxdhrWT");

    for (int CNHXCZpQveBz = 573737277; CNHXCZpQveBz > 0; CNHXCZpQveBz--) {
        AvRCsrhqLcJG *= AvRCsrhqLcJG;
    }

    if (CuqOQ != false) {
        for (int qvXBtJsPyn = 1594996383; qvXBtJsPyn > 0; qvXBtJsPyn--) {
            continue;
        }
    }

    if (AvRCsrhqLcJG >= -377153707) {
        for (int yAsIZyhjbn = 2127998170; yAsIZyhjbn > 0; yAsIZyhjbn--) {
            continue;
        }
    }

    if (CuqOQ == false) {
        for (int OIICpiiwcum = 238259093; OIICpiiwcum > 0; OIICpiiwcum--) {
            OhcgItgmAn -= OhcgItgmAn;
        }
    }
}

string UukAdxhRLsxFC::lHgYMJtpLsSF(string eOuZlmQlPSfQUTMY)
{
    int uxOVMgpWtAqxY = -1649672658;
    bool sYocKVzOh = false;
    double JWtXsRxSEdm = 300930.7459372573;

    for (int zUBjzezQcn = 1575993562; zUBjzezQcn > 0; zUBjzezQcn--) {
        continue;
    }

    for (int VTAmRHTTlFhcGFy = 1037088565; VTAmRHTTlFhcGFy > 0; VTAmRHTTlFhcGFy--) {
        JWtXsRxSEdm /= JWtXsRxSEdm;
        JWtXsRxSEdm /= JWtXsRxSEdm;
        eOuZlmQlPSfQUTMY += eOuZlmQlPSfQUTMY;
    }

    for (int zcPdYkDbn = 988387795; zcPdYkDbn > 0; zcPdYkDbn--) {
        JWtXsRxSEdm -= JWtXsRxSEdm;
        sYocKVzOh = sYocKVzOh;
    }

    return eOuZlmQlPSfQUTMY;
}

string UukAdxhRLsxFC::UUBeSkISmlyDqm(int EfttZeXwpCeXXS, double udJdHxoxSQXlclo, double kdXbF)
{
    string sHxSZQog = string("dsimrglrLIEWvdZiBqIFUmofXGoMOMXkAXLwfrFCOlPAiJyPqJHkSJWdtcImrwECjhVtMdsEQemOwijibJxUCiBfOUXegWXilltNVZLfdOdTJrqfcJNqrlqPrVoKoFERUdsvXfRqHZADNuWOrnftSSpUoOGsloFjiMAaqnSnzMakpDRKLty");
    double VCeAku = -862607.1904443579;
    double XPDuDWPT = -148195.87408047917;
    int OnMsFs = 2026813139;
    bool mBbNoXpQKYRd = false;
    bool MaNBmCaojFTBVhx = false;
    int zeyaDxEBtXpKr = -1166477640;
    int MFfLozaBjkWZMBD = 386934699;

    if (kdXbF > -267947.4088104646) {
        for (int wPqoWD = 768633990; wPqoWD > 0; wPqoWD--) {
            XPDuDWPT -= udJdHxoxSQXlclo;
        }
    }

    if (XPDuDWPT > -609431.6753575766) {
        for (int eOCjhVMlQ = 12268356; eOCjhVMlQ > 0; eOCjhVMlQ--) {
            continue;
        }
    }

    for (int iwpBhuxpoePE = 1886524203; iwpBhuxpoePE > 0; iwpBhuxpoePE--) {
        udJdHxoxSQXlclo *= kdXbF;
        XPDuDWPT /= VCeAku;
        zeyaDxEBtXpKr += EfttZeXwpCeXXS;
    }

    if (MFfLozaBjkWZMBD != 386934699) {
        for (int jFUXEjAvicxYz = 1416248738; jFUXEjAvicxYz > 0; jFUXEjAvicxYz--) {
            MaNBmCaojFTBVhx = ! MaNBmCaojFTBVhx;
            udJdHxoxSQXlclo = udJdHxoxSQXlclo;
            XPDuDWPT = VCeAku;
        }
    }

    for (int SJyBhJhgVpQpT = 341259921; SJyBhJhgVpQpT > 0; SJyBhJhgVpQpT--) {
        udJdHxoxSQXlclo *= udJdHxoxSQXlclo;
        MFfLozaBjkWZMBD += zeyaDxEBtXpKr;
    }

    if (mBbNoXpQKYRd != false) {
        for (int TnhKKfvQdLToUji = 436996699; TnhKKfvQdLToUji > 0; TnhKKfvQdLToUji--) {
            continue;
        }
    }

    for (int dtQtW = 1928242459; dtQtW > 0; dtQtW--) {
        MFfLozaBjkWZMBD += zeyaDxEBtXpKr;
    }

    for (int XTFRhGZgorJkPq = 926083221; XTFRhGZgorJkPq > 0; XTFRhGZgorJkPq--) {
        EfttZeXwpCeXXS -= EfttZeXwpCeXXS;
    }

    return sHxSZQog;
}

bool UukAdxhRLsxFC::BxybvBJRPQruyV(bool MKkcNJX, bool bEyABjPFoRtgQZn, bool IRiLu)
{
    double VOoLVcqyGXJfWZBV = -572828.4915105542;
    string bryrYaZw = string("FpUpeGqHFDkqPxEpGCfdejgGzWryjylfnloCrfYjhrWOpmYlclhibweYKFSEhnZDCQJzBwXTESFCMiFaaosmcnPTxEjjzUUSHjuVIVBsXFDquQhtvyJSVISyZwpRmVJpashRuTFLWEqYEioxbUGVJxAoaXoBXumqlMLXjwUOPMQYwxYzCywpOqPFRlojNbiGwNtB");
    string tCuQemZCwkZrwE = string("jpABWQRPCvBzbZkYYCPsGnwoJJbvjSLelKUYgrNBoekNWYDvNGLvShHZeuvDIfQeLtoDYUGEjjHziHuxJgOKYRLLLryctEzpTBavfHMBIWtNrXFBzwZELsahXhXYOdJjPcngUeTqsOUbZxvcWNpXUlLQLzzXFkwmMa");
    int rcFMOsMiWKRMxBVU = 538369700;
    double oOOjReFers = -536054.1917142528;
    int McnfUKfcFNcg = -365393918;
    double GhnMhK = 436853.433603088;
    string FtZBStyKiN = string("stpYgMucSBeKSnrjQlwohBISlNLOSEkxmhxrRDpslavfcwVIrkEqWZlegtqyPUDLHu");
    double jaMrxxYpmrjP = 752060.1083105284;

    return IRiLu;
}

bool UukAdxhRLsxFC::rmsdTLtUWzM(int IlhNKkPRJj)
{
    bool GrmcUcVFmqwTInNY = false;
    double SrXzjEXvjoRp = 159736.69340382898;

    if (SrXzjEXvjoRp > 159736.69340382898) {
        for (int wvtZpfwEiVH = 1813106917; wvtZpfwEiVH > 0; wvtZpfwEiVH--) {
            SrXzjEXvjoRp *= SrXzjEXvjoRp;
            IlhNKkPRJj /= IlhNKkPRJj;
            SrXzjEXvjoRp /= SrXzjEXvjoRp;
            GrmcUcVFmqwTInNY = ! GrmcUcVFmqwTInNY;
        }
    }

    return GrmcUcVFmqwTInNY;
}

int UukAdxhRLsxFC::HcuveGAzDZZGf(int agpBWUkyEBnxP, string wpFKVMhyAoDhNpoH)
{
    double ezilVwhG = -390689.37607582804;
    double TLHFNeg = -375323.7917966088;

    for (int yjujRM = 1159271244; yjujRM > 0; yjujRM--) {
        wpFKVMhyAoDhNpoH += wpFKVMhyAoDhNpoH;
        TLHFNeg -= ezilVwhG;
        ezilVwhG /= ezilVwhG;
    }

    for (int OrJvN = 907913374; OrJvN > 0; OrJvN--) {
        TLHFNeg /= ezilVwhG;
        TLHFNeg += ezilVwhG;
    }

    if (TLHFNeg <= -375323.7917966088) {
        for (int LSXsMFS = 1410658923; LSXsMFS > 0; LSXsMFS--) {
            ezilVwhG *= ezilVwhG;
            ezilVwhG += TLHFNeg;
            agpBWUkyEBnxP /= agpBWUkyEBnxP;
        }
    }

    if (TLHFNeg != -375323.7917966088) {
        for (int UuBNRqfHjxR = 289868087; UuBNRqfHjxR > 0; UuBNRqfHjxR--) {
            agpBWUkyEBnxP = agpBWUkyEBnxP;
            wpFKVMhyAoDhNpoH += wpFKVMhyAoDhNpoH;
        }
    }

    if (ezilVwhG == -390689.37607582804) {
        for (int OonMeGd = 112266716; OonMeGd > 0; OonMeGd--) {
            TLHFNeg -= ezilVwhG;
            agpBWUkyEBnxP += agpBWUkyEBnxP;
            agpBWUkyEBnxP /= agpBWUkyEBnxP;
        }
    }

    return agpBWUkyEBnxP;
}

int UukAdxhRLsxFC::YTnXtbJlBLb(double lXaFNrRWRMWoCc, bool GbdxV, int BoIjzLHuLcYX, int DkfhBvjR)
{
    double TfiNMQC = 347642.1448996397;
    int Wyalhw = 1617819942;
    string KaAybqDkpepEEb = string("TmTWotVUuXqHFfoWMZqwYUrCuwJrnxKjtGkrYDFPRtoTAfEaPxwXRaRMkvPzncNWPXRSDGfvAaZfocWWoSBUGGJNaDLvvARhHxEcbJszjIDGaoGwEVQpqdzBEgADzuDGtQslJSreXsHMazZCXZdrznJiSabZS");

    for (int CNfsGsczjqlWEAD = 1190989638; CNfsGsczjqlWEAD > 0; CNfsGsczjqlWEAD--) {
        lXaFNrRWRMWoCc *= TfiNMQC;
    }

    for (int DrjeCuAxkz = 548074120; DrjeCuAxkz > 0; DrjeCuAxkz--) {
        TfiNMQC /= lXaFNrRWRMWoCc;
        Wyalhw += DkfhBvjR;
    }

    for (int cfhioMkwMLgKPLAd = 1426346344; cfhioMkwMLgKPLAd > 0; cfhioMkwMLgKPLAd--) {
        KaAybqDkpepEEb += KaAybqDkpepEEb;
    }

    for (int PPLKsOcLyP = 119022070; PPLKsOcLyP > 0; PPLKsOcLyP--) {
        DkfhBvjR -= DkfhBvjR;
    }

    return Wyalhw;
}

string UukAdxhRLsxFC::nnBhfkJJHgn(int ClFDCXXlrMhnlw, double yAZpDjnUaOcjaYM, bool pXEPAFOwoidYSl, bool GSXsxCDtwGc)
{
    bool vzXwhextwFaEMA = true;
    double WxhOrkhAjIh = -247258.61103880373;
    string JfkosoZ = string("KUXFvNwyJfDbZBLSg");
    bool ISFGIjNLtPn = false;
    double uedCGNPpSQfwMs = -2691.094418737035;
    bool QCsSFu = true;
    string kFkpqrreRLKsZxJS = string("JwdUfVwwDueYxWDnBfcONNThcotADdhwXMJXFYKSsVjsxtvEuNoNvVGnaQcrDmRcRXwAvJXmUqfkwKhFtsooDFcMUUjpZrzAdbZahIoYIBVuiSKTxRzuFVEnEEZiiRLnKiVjPvaJMkSbJroRIWExbSgCuXEPYMykVgspsdxhHiKLJTpTyByYXiflWsMVKSQAByzhxyWL");
    string LPYaphywxLnq = string("JgBkUkZcuMsxKFxQpTJOqzWYBvBFEUtfIMBjRySGLQlNGuersUGWqH");
    string ILSJDu = string("bFSiKsPSnGgallSIPcmMfpCUxcuAIrAwydKWByVWXqaWERJYEIzHCSbAFzvugGhbrPlO");
    int TMCBMJWKfxHwSSp = 508853861;

    for (int FgLXBXg = 65290491; FgLXBXg > 0; FgLXBXg--) {
        ISFGIjNLtPn = GSXsxCDtwGc;
        GSXsxCDtwGc = GSXsxCDtwGc;
    }

    for (int QwgDZMaUhZfR = 1255561264; QwgDZMaUhZfR > 0; QwgDZMaUhZfR--) {
        continue;
    }

    for (int cENDrrdBpQWK = 189921209; cENDrrdBpQWK > 0; cENDrrdBpQWK--) {
        continue;
    }

    for (int WJMTJXJNxmt = 1772270648; WJMTJXJNxmt > 0; WJMTJXJNxmt--) {
        WxhOrkhAjIh *= uedCGNPpSQfwMs;
    }

    return ILSJDu;
}

bool UukAdxhRLsxFC::DIYTciUyMaEYIUD(bool TJLzEKfz, double jJDVYkrPRmimW)
{
    bool cyeEicbgRxt = false;

    if (cyeEicbgRxt != true) {
        for (int oMSAyugWWs = 710807620; oMSAyugWWs > 0; oMSAyugWWs--) {
            cyeEicbgRxt = ! cyeEicbgRxt;
            TJLzEKfz = ! cyeEicbgRxt;
        }
    }

    return cyeEicbgRxt;
}

double UukAdxhRLsxFC::WjbdkXuHHcMVQxq()
{
    bool NHekpPIr = true;
    int LQfvGIn = 1703437947;

    for (int DJfBQDEJwY = 1465950332; DJfBQDEJwY > 0; DJfBQDEJwY--) {
        NHekpPIr = ! NHekpPIr;
    }

    for (int IJzCOvzCgH = 1851488504; IJzCOvzCgH > 0; IJzCOvzCgH--) {
        LQfvGIn = LQfvGIn;
    }

    if (LQfvGIn > 1703437947) {
        for (int VvzTS = 796167175; VvzTS > 0; VvzTS--) {
            LQfvGIn = LQfvGIn;
            LQfvGIn /= LQfvGIn;
            LQfvGIn = LQfvGIn;
            NHekpPIr = ! NHekpPIr;
            LQfvGIn -= LQfvGIn;
            NHekpPIr = ! NHekpPIr;
        }
    }

    if (NHekpPIr == true) {
        for (int VvDveltKcCiMSnM = 511751766; VvDveltKcCiMSnM > 0; VvDveltKcCiMSnM--) {
            LQfvGIn += LQfvGIn;
            NHekpPIr = ! NHekpPIr;
            LQfvGIn *= LQfvGIn;
        }
    }

    for (int ZDxNe = 1440550811; ZDxNe > 0; ZDxNe--) {
        NHekpPIr = ! NHekpPIr;
        NHekpPIr = ! NHekpPIr;
        NHekpPIr = ! NHekpPIr;
        NHekpPIr = ! NHekpPIr;
        LQfvGIn = LQfvGIn;
        LQfvGIn += LQfvGIn;
    }

    if (NHekpPIr == true) {
        for (int BqlDamg = 714313306; BqlDamg > 0; BqlDamg--) {
            LQfvGIn *= LQfvGIn;
            LQfvGIn /= LQfvGIn;
            LQfvGIn = LQfvGIn;
            LQfvGIn -= LQfvGIn;
        }
    }

    if (NHekpPIr != true) {
        for (int ETGoZNSewRuXEKz = 1907683473; ETGoZNSewRuXEKz > 0; ETGoZNSewRuXEKz--) {
            LQfvGIn += LQfvGIn;
            LQfvGIn = LQfvGIn;
        }
    }

    return 1018073.108157006;
}

double UukAdxhRLsxFC::CCBWymSEP()
{
    int ROjpAQ = -852461807;
    int SygtvgCjGBlP = -843012978;
    int rRIELrtJDesp = -1247981438;
    string aNmIr = string("fweYYcjbklzMjvcojoolRjqjkffYAilfgiqaWYBxeRhVVoZJNpyRHPzVVQBlrSAFRzBtAZsQhdNQLLJnkgwlqUDRgsxmkKYXOOjYxYDZaMVFXitdJooxznBVgdSaPeoiHBwlODCWjPFWInFVGXOEhhxNxbPTSjVtBIcgLmNJimkbzOglQTtLrSbgOLkPlGgGtGioyQhEDge");
    string WfOshMSNqpKwCq = string("pSaVWXqrIGJGpEXSMSNOxhGZYDfwkzKfxxogNESNxoGClrpdqylDdoFmgxogqMTJRQrGsFNNQQoWVTROFGepNvbSVNyMCdFQTIEvFTUGfRGghuDwogSUHxjUhKlMHxGtjeH");
    int Qoyuo = -1663034945;
    string kPvWHWQLsbGRFjvk = string("mfzKirtwNlEuENMwMDytNNPCIuNmOArPXZEexNrbUNgKXsYSdRhWeakoZULmWVOAtionivOcgNxeAMaytVkUPpRnrrbtdlVXPybEYeHtqREgprqTFeVnhDSjaZdOiSgAddPjKzMKgrEcOxSVzBjQHF");
    string abIjbwKXEjXDy = string("tcuqVzYrEsYpHryNZujOgGHqkyDTTFxDYLUmaExZLBgPLBoDUgNnVlVZHwKpwGjXtyeaDuvCNXIkgIqynrIouvzndZzNWkFdYmIrWQUXthZAEXTxJwkyTmYhLyYJfaEXrELWBybOnQeSHPWFOoXTVpAUpuuwxmwLJFNSvUfQegtGZgiiyDRMxGbCejTifnDoLNYvfsBREqlOEMbSxBUSZikeJmKlJKwjgwclgyIVWbnegfxQB");
    int BISSrBoUHekDCBn = 1582116117;

    for (int QOTxiCPyOZAl = 642621118; QOTxiCPyOZAl > 0; QOTxiCPyOZAl--) {
        kPvWHWQLsbGRFjvk += kPvWHWQLsbGRFjvk;
        ROjpAQ = rRIELrtJDesp;
        ROjpAQ /= ROjpAQ;
    }

    return 801080.1727978516;
}

bool UukAdxhRLsxFC::asNAHfvsQe(string ZbgHhRagrr, double sKZEKflMEB)
{
    double lVYgCZwwZPaidGR = -345966.57779645675;
    double maTkPweiALY = -676571.8538793969;
    bool tTjYHxz = false;
    bool aOhtzrtSpwwBu = false;

    for (int EkPpeURWpozhM = 753723437; EkPpeURWpozhM > 0; EkPpeURWpozhM--) {
        sKZEKflMEB -= maTkPweiALY;
        tTjYHxz = ! aOhtzrtSpwwBu;
    }

    for (int iJqrGXxCiDif = 1773843513; iJqrGXxCiDif > 0; iJqrGXxCiDif--) {
        tTjYHxz = tTjYHxz;
        tTjYHxz = ! aOhtzrtSpwwBu;
        sKZEKflMEB -= sKZEKflMEB;
        sKZEKflMEB += maTkPweiALY;
    }

    if (tTjYHxz == false) {
        for (int fCHue = 1073434035; fCHue > 0; fCHue--) {
            ZbgHhRagrr = ZbgHhRagrr;
        }
    }

    return aOhtzrtSpwwBu;
}

string UukAdxhRLsxFC::zfkyKd()
{
    int dawitxejVQOuGTm = -865974537;
    bool FnsGhSLuVFA = false;
    int sHmBWLtQRz = 823022212;

    if (sHmBWLtQRz != -865974537) {
        for (int xCSjtNGASsIBC = 838810948; xCSjtNGASsIBC > 0; xCSjtNGASsIBC--) {
            sHmBWLtQRz *= sHmBWLtQRz;
        }
    }

    if (dawitxejVQOuGTm != 823022212) {
        for (int AniKpLlNC = 1143295568; AniKpLlNC > 0; AniKpLlNC--) {
            sHmBWLtQRz *= dawitxejVQOuGTm;
            sHmBWLtQRz /= dawitxejVQOuGTm;
            FnsGhSLuVFA = ! FnsGhSLuVFA;
        }
    }

    for (int DLqtKlLKUTE = 936771515; DLqtKlLKUTE > 0; DLqtKlLKUTE--) {
        dawitxejVQOuGTm = sHmBWLtQRz;
        FnsGhSLuVFA = FnsGhSLuVFA;
        sHmBWLtQRz *= sHmBWLtQRz;
        sHmBWLtQRz -= dawitxejVQOuGTm;
    }

    if (dawitxejVQOuGTm <= -865974537) {
        for (int BWVIgLKDQrIYqPQ = 2004910608; BWVIgLKDQrIYqPQ > 0; BWVIgLKDQrIYqPQ--) {
            FnsGhSLuVFA = ! FnsGhSLuVFA;
            sHmBWLtQRz = sHmBWLtQRz;
            dawitxejVQOuGTm /= dawitxejVQOuGTm;
        }
    }

    if (FnsGhSLuVFA != false) {
        for (int sKoCKwsSDdNrv = 795279216; sKoCKwsSDdNrv > 0; sKoCKwsSDdNrv--) {
            dawitxejVQOuGTm /= sHmBWLtQRz;
            dawitxejVQOuGTm -= dawitxejVQOuGTm;
            FnsGhSLuVFA = ! FnsGhSLuVFA;
            dawitxejVQOuGTm /= sHmBWLtQRz;
            dawitxejVQOuGTm -= dawitxejVQOuGTm;
        }
    }

    return string("oZtzXflNDHUAIEuwIhDYDnBmtqxuUTSLpFvxebZfpCvOzbWyIyMHaYPGfeSPDxLrsQRWyKVlRybwnNOhdbCxsHmHKVUrXoSzdzBFNwRFTozCDXhvvLRioObfniCAThtsNEuqzd");
}

double UukAdxhRLsxFC::PMxmEsKVTN()
{
    double NLUleEMMkli = -737358.6136875197;
    int ovkuNiNKXneWRpl = -1350092640;
    double HKlZkRW = -62336.16567802233;
    int jiOMCohtipOWYP = 1976025921;
    double foNliRbKEo = 531585.3410137915;
    string JEvsgU = string("LpWecnBPiuQDYCblHFOiefAfs");

    if (HKlZkRW != 531585.3410137915) {
        for (int EWvkryqtzmf = 486915294; EWvkryqtzmf > 0; EWvkryqtzmf--) {
            NLUleEMMkli *= foNliRbKEo;
            jiOMCohtipOWYP = ovkuNiNKXneWRpl;
        }
    }

    if (foNliRbKEo > 531585.3410137915) {
        for (int NcIVGCd = 697656203; NcIVGCd > 0; NcIVGCd--) {
            NLUleEMMkli -= HKlZkRW;
        }
    }

    return foNliRbKEo;
}

bool UukAdxhRLsxFC::QFuzqDoArhDkCGa(int qwbThvAR)
{
    string UqxbDXTENRZJ = string("IsWNTrkSziuzKExQlDDYGPhlUxBWdbNUgulQtBzlGEprxCamUgTLRedpnztZiRfdpvSbFQANrzsCMyPPfLlFnMXGGbMoRDIvGRecpwyErBaZOer");
    int WtDplzqBRy = 949673141;
    bool IwdJO = true;
    double GNuLCPLEktkMLmZ = -943235.4182113736;
    double pEhPsPzkfXUaXFb = 944819.3166567849;
    int KBWXpOVamW = -1816651583;
    bool COtJcXd = true;
    int CkWRYits = -602150013;
    double ZfoblGpli = 239273.24977562495;
    bool HILoZNzS = true;

    return HILoZNzS;
}

string UukAdxhRLsxFC::EPCVENjvGuXc()
{
    bool nrMIumXU = false;
    double fPOQzPpVqhEbZL = -688328.9858239057;
    double NOQiNeiuJnkVAmHm = 1377.0918050833377;

    return string("zyqamJSZpApxReAWhOrolIfnRcVuzNdOClVUzqJyAcfsIhYaHTpZbpeccbXPKFbaTJvuaupylnsmXhdvmmNUaXxqPgCHDUCZiqDFMOQDmfksDcbystwMwFrIlsuFBUouZlcoehUmhXutvnhdrsCbcUtVhztsxCrCVgfJfsLSoGQmFWLmIZaAKYsKqfBcSpPBzQpTXBNCNSHdPRkuwdiQMpKkDuHqkhpMQtaEHmiKnFycuRJQWoCvzVNxoSk");
}

UukAdxhRLsxFC::UukAdxhRLsxFC()
{
    this->IkcUVQJ(1818935259, 1922654333, -1010566.4010868823, false);
    this->AZlXb(false);
    this->lHgYMJtpLsSF(string("dXIsgSjRVnkcTMKowYAfDjWneFJDXGEzqACaEZWSdxtlcBvgahPQXACExmQIZQaXCFtLNtzNGcwoBfHYHWYMTflKKdcnFQQotrbhjblJgygqMElrMRrripzPEjgrrevCjVUEetkXmoOEUZagNlFzBNWmDwUBoFVPPQoxcBHgoRUZeGPR"));
    this->UUBeSkISmlyDqm(1528245360, -609431.6753575766, -267947.4088104646);
    this->BxybvBJRPQruyV(true, false, false);
    this->rmsdTLtUWzM(-1404287897);
    this->HcuveGAzDZZGf(-332859827, string("ltzhBuCtpUYsWPlHarkJGAVuVSoczOFtyVoIinWdMNexlxEOCCJnqSmNfuDSwBkYOAxLwcTnAlZIzObQJunYLUthuUrLRKFVwnyRsqhsLiQIkmhKeHuCldYKnfNfilHIBTPkGokCqBpzYAffkoJvImkbAgUYSSNCwOHoCuBFomQkfvYaTFOsjKpfPIjXRJKbatKWBcsIheaAGdSzMxMZrQh"));
    this->YTnXtbJlBLb(-710376.7641684884, true, 66947517, -75244730);
    this->nnBhfkJJHgn(-1926575770, 663985.9942179938, false, true);
    this->DIYTciUyMaEYIUD(true, -76982.02896681272);
    this->WjbdkXuHHcMVQxq();
    this->CCBWymSEP();
    this->asNAHfvsQe(string("OkdSVEYTXVuTwcdHuamSLVbNbZFrtPPvbzbJRwqhqbtexOVYHJSRXdFlpiipfOPmDJncHiHDHUNDETyspk"), -1014935.756783461);
    this->zfkyKd();
    this->PMxmEsKVTN();
    this->QFuzqDoArhDkCGa(-9941456);
    this->EPCVENjvGuXc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SqHxTWWiyor
{
public:
    int NkxLTtZQX;
    int rBLudp;
    double VjLdUcjswr;

    SqHxTWWiyor();
    bool ctbjLMrAl(bool pNKHhZuQ, bool LWOCxeyLRaC);
    bool kCcCeml(int nDRbGwq, int VuueIek, int aIYZmhwDFkG);
    double zkXYOJdsib(double ozgngqDHch, string FUsIoxtnTrSI, int bffVLOTHh, double oiLtXVgwlgdTd, double KxysdgzeYvUpOEe);
    int nJzaepYs(int DuUlqMiDEFg, string WSRfGXOvhdmuZkV, string mNbIaeBLD, string kpkwvmqhIMFxpt);
    bool hJtypdPuanHCAv(int gUZulueCgyE, string koNeNJtZintkwxE, double sSuQvjUvqgAOUJMX, string tqSUFmkWhgdPJNgX);
    double ggUTak(bool PGHsxkSXyZinx, bool WYeVcadYsu, string exuVRFzJNPTttAz, string GSVcfckjEMDEx);
    int KzCScYMsmGapzoMp(int LKAlvUJYeRsx, string qIHeXzXqlLjNTE, int LlYwHtcR);
    string JgLxZdyMBBnkxp(string XegHwIxqeDyKLWIw, double XUAzYJVVWfAOAjAH, int UCZZoTtVPIpMk, double xfRmdggXTYAbC, double oOGTNSQfbpTgR);
protected:
    bool fahmdXFYQOIay;
    double HGLbmspaTSvsu;
    double KtjtEbySolSKq;
    bool gLvtbqCMJEmCKNc;
    bool DMfVRJdXy;
    bool RMBQkItbf;

    double wWWlhKXhoBPlj();
    string EbAktpBT(int QBEJyGksTAvO, double vvaJgvDgvMDcXei);
    string zzBctYLloO(string lXSFp, string SIEyfQHTkiHEbMfc, double iEeHNMdgADJPeQvB, string WefdqBxE, double LOhyqIf);
    bool AnMZPFfGFXv(int DhQMr, int XlwoUURdNAuprUC, string lWrMUeBkweYjEKlm, bool pVAHgAQtVShoQnB, double dNcTbmQgfKhXSB);
    int syrdpk(bool fexPqLr, double qHtnwirqNFPDWa, int DIpnpU);
private:
    double mtkFyhDaNAVmyxuo;
    double jErKTRbwz;

    bool kaMwrJhJifR(bool OBsHWUWPnjaJYAS, string ByGYpRq);
    int BJjZwxRjQzYlR(double XpvrYwc);
    string dpWPE(bool UcoFX, double nTdReUNssff, bool jWGlfgrV);
    double dRUbWgWiAlyG();
    int zyDeOwgaSgO(bool qadkmodTMxUd, double rTXJczPwVUR, string aaNeTWdgmnz, string sHUiPFTHNpxsHOW, int YdTGpZVild);
    string WsIzfyeWqOA(string uKdWPgnW, string vtleGuFg);
    int KEnom(bool HEyeTfSuAQi, bool GGoCLIQcS, double jhWbsUgx, string IMdAcQaAevCAdS, int jZOlTPkAmzFdj);
};

bool SqHxTWWiyor::ctbjLMrAl(bool pNKHhZuQ, bool LWOCxeyLRaC)
{
    bool KnidkYzFiRMAzwz = false;
    double sAbkSvXNCA = 379589.8999852723;
    string uUOCXseg = string("qjrHNKbaEJQPGLQcTCPQsKSDvBiwyvibIzRuKYfDbaNMXovjmGkgJDxEsgyjZqFwhrzThWiQDpnweNAyixp");
    bool aqhRjneiVsOLLvqd = false;
    int AVpgXpKEOtHgM = -1786276184;
    int ugRjXJKqJkrwat = -1385370706;
    bool ZbBZtLDHBfsbpO = true;
    double aeYGzpv = -45046.31317764715;
    double DkVTWjNqcwigLQH = 92924.28367482749;
    double SpBDzzG = 873850.3954010267;

    if (ZbBZtLDHBfsbpO != true) {
        for (int VJfonA = 1055542916; VJfonA > 0; VJfonA--) {
            ZbBZtLDHBfsbpO = pNKHhZuQ;
        }
    }

    if (KnidkYzFiRMAzwz == true) {
        for (int hrEODlZ = 802102193; hrEODlZ > 0; hrEODlZ--) {
            LWOCxeyLRaC = KnidkYzFiRMAzwz;
        }
    }

    if (sAbkSvXNCA <= 873850.3954010267) {
        for (int JLLSBflwXyOjJzrH = 1814937247; JLLSBflwXyOjJzrH > 0; JLLSBflwXyOjJzrH--) {
            LWOCxeyLRaC = ! pNKHhZuQ;
            AVpgXpKEOtHgM *= AVpgXpKEOtHgM;
        }
    }

    return ZbBZtLDHBfsbpO;
}

bool SqHxTWWiyor::kCcCeml(int nDRbGwq, int VuueIek, int aIYZmhwDFkG)
{
    bool htuOfJ = false;
    double OJSmmZVyYFrF = -586807.963135371;
    string vejGHOrDOngXWzXL = string("rnvWFjTUexoCuRlMGGzzZVvLTuhXhLFDIVZKfxyobPseHQxTFFUUyMVfXOfKPjspPhfvkKRPxoNADyzUEzuRTdVyUUWvLcoJhomjhpdEdORrXnDnMyKHOOViZZPUhEJuHmEWDBEwntOPtmZHCLtQaMdSMvRcxrAnInmvgqQNAvMfTEaTWTlvMgYyhrPejvDPPsmzLxbWgKFTxQvmdtdutpPKgKQfyHGmRamYFGruuurIfFYogHKNBLUhqhVcps");

    for (int dsgwROUewKY = 686274193; dsgwROUewKY > 0; dsgwROUewKY--) {
        continue;
    }

    for (int OmnUrRoyphRr = 237859404; OmnUrRoyphRr > 0; OmnUrRoyphRr--) {
        nDRbGwq -= VuueIek;
        nDRbGwq /= VuueIek;
    }

    return htuOfJ;
}

double SqHxTWWiyor::zkXYOJdsib(double ozgngqDHch, string FUsIoxtnTrSI, int bffVLOTHh, double oiLtXVgwlgdTd, double KxysdgzeYvUpOEe)
{
    bool LbotxG = false;
    bool XiAnKbxArcMWL = false;
    double NysSPEoWu = -1047253.7138128842;
    int gtwwaxHUmOmSSO = 1402587569;
    bool ReIwj = false;
    bool ncVbyNaoBsOwtk = true;
    string ZApUduZboGllBPH = string("aGZGlaOCsVnBttIBMazFegwdVVSdbsentZsCtRlizBcQsQUXhWnoyhbcAlgolVFCsiVwFCUMljaMAWGztMjkJyscdLZFUJoXsZatADqPhvzAghqUeURcQfxokSTOGrEjfZWixPZ");
    double BeXULSUdqiRTu = 699894.0290874201;
    string IIToIfeS = string("DiGImAgfLNzYqQcHvMBYsPCmBxAJHkWOcirNCzISVNrIAkwYBoGuixrUudRphHcjaNqCtNXaxPBjxzSaIzpwxVxXphosCFUpCNGCsfdMJUzzEQNcDOZEsztZxlfZEDiwwGiNYjMVWZOndbOdkaJqsfCTgBmkomqFxIvAborzFaDSPPhRZLbEZluboIWdAHputEuffAPMUYyBWTUFusYw");

    if (BeXULSUdqiRTu <= 29209.54251926205) {
        for (int uRKfAszqbLxaWJ = 477067656; uRKfAszqbLxaWJ > 0; uRKfAszqbLxaWJ--) {
            NysSPEoWu /= ozgngqDHch;
        }
    }

    return BeXULSUdqiRTu;
}

int SqHxTWWiyor::nJzaepYs(int DuUlqMiDEFg, string WSRfGXOvhdmuZkV, string mNbIaeBLD, string kpkwvmqhIMFxpt)
{
    bool AYQhQkukeDVGE = true;
    bool dcBysYM = false;
    bool cKIgwLYyEeDOvKjj = false;
    int pGWUc = -2120901058;
    string QjfDnSvDYhmS = string("XfFJqkgDyemgsrVbBnbbcjxiJacxroJpNerYCMvBRRwHoEByvLnhwXjhsJo");
    int OaEBWrzEVS = -368093160;
    double yDYuCGxdLm = -834659.4988444041;
    double ejThQZoWgCvNx = 1007692.3040036804;

    for (int MIYdMFVxRj = 1443707701; MIYdMFVxRj > 0; MIYdMFVxRj--) {
        AYQhQkukeDVGE = AYQhQkukeDVGE;
    }

    return OaEBWrzEVS;
}

bool SqHxTWWiyor::hJtypdPuanHCAv(int gUZulueCgyE, string koNeNJtZintkwxE, double sSuQvjUvqgAOUJMX, string tqSUFmkWhgdPJNgX)
{
    bool zExwjYDcxbqnZ = false;
    string tIKUissImY = string("JuEcDDXNvtbHskSnWqpoIorgVrAtJlwajkGFiCWGRCczFoLHYHzxMgnanQqDBYeuOioVVxcEJzMjrpkbhDAmofkDGiwSsGzTQblQqikvgIOQzpRXUAfHFJtibvQPhgwgdancUXOmNecmYSjZlHvjKSUNcsNbknRXdwUjVkGXRXaSdSFqlBVvOjVcwkxDarZGlMsgsRCRxvPKRsVgmEXKYvizxNXGonwbNsismLfrxmeNAg");
    bool WDQXoOnsbCTxTZ = true;
    double lGIRFfvgMeozv = 145784.87803248886;
    string RQJyiMDblM = string("mQMRYmjafftstZczNyvZqUTZTZuqxqhVLkMpPtTgTflgxXmtRbpCeNxusLLHCStzsHSPpkZJgyPxIjfKvJiAuKAVxFceXDFvGxtkBQatsjcmTLBdbusDnUgmpZQbgLeFHodYcfHXqLnrGvtJck");
    bool FqEhvEseY = false;
    int FRTbsgXbNqbNHPFs = 79718490;
    double xCyYaz = -868672.7978351823;
    bool VjRtvrDm = false;

    if (FqEhvEseY != true) {
        for (int eheRVmQ = 632260780; eheRVmQ > 0; eheRVmQ--) {
            RQJyiMDblM += tIKUissImY;
        }
    }

    return VjRtvrDm;
}

double SqHxTWWiyor::ggUTak(bool PGHsxkSXyZinx, bool WYeVcadYsu, string exuVRFzJNPTttAz, string GSVcfckjEMDEx)
{
    bool gCXzbbOUpZlFnd = true;
    string LWXgYLCgo = string("OIfkAxtwTlUQEiLOqhkCtqLpQRZwpyhuPQmETrlOXygPAzAMUMRZqzlzojQmlWzzKJSJxCyDDohiVJjRZPhKWRdKLybjSpc");
    string ivARrFNUNIF = string("BXeIeAoYbIqVUTwRFvxXeKLPcutaIJPXfhVhqmhQEDhDByIocPBWyngsVYRJPiQVCwprwuJKAoVlkaxzNlnSdiKDYQxaTycQtxvHizuqlTxYGQJtuarKQAQRcATlRQcotEgGomuHIKbdyFNrZGaEsCYdrSEjspprtMXeMJDCLBmfzdVGT");
    bool DKPqnVpngllRMfp = true;
    bool wSFkaQGmpxM = true;
    bool pmLhbASJO = false;

    for (int phKQH = 268454872; phKQH > 0; phKQH--) {
        LWXgYLCgo += ivARrFNUNIF;
        WYeVcadYsu = ! PGHsxkSXyZinx;
        WYeVcadYsu = DKPqnVpngllRMfp;
        LWXgYLCgo += ivARrFNUNIF;
    }

    for (int BhbKXM = 286161382; BhbKXM > 0; BhbKXM--) {
        DKPqnVpngllRMfp = gCXzbbOUpZlFnd;
    }

    if (DKPqnVpngllRMfp != true) {
        for (int qlupvnJJWwCaBVXr = 837228139; qlupvnJJWwCaBVXr > 0; qlupvnJJWwCaBVXr--) {
            ivARrFNUNIF += ivARrFNUNIF;
            PGHsxkSXyZinx = ! WYeVcadYsu;
        }
    }

    if (ivARrFNUNIF >= string("kXLdUePjCwtttBGiBoTYSfBddlLLvFGaBtTnJHreInKhQUoltODWuv")) {
        for (int jsvWZpz = 1966065737; jsvWZpz > 0; jsvWZpz--) {
            PGHsxkSXyZinx = WYeVcadYsu;
            PGHsxkSXyZinx = ! pmLhbASJO;
            WYeVcadYsu = ! WYeVcadYsu;
        }
    }

    if (pmLhbASJO == true) {
        for (int YLxkrgaAlqvo = 1066556660; YLxkrgaAlqvo > 0; YLxkrgaAlqvo--) {
            gCXzbbOUpZlFnd = gCXzbbOUpZlFnd;
            WYeVcadYsu = PGHsxkSXyZinx;
            wSFkaQGmpxM = ! DKPqnVpngllRMfp;
            gCXzbbOUpZlFnd = pmLhbASJO;
            exuVRFzJNPTttAz = LWXgYLCgo;
            GSVcfckjEMDEx += exuVRFzJNPTttAz;
        }
    }

    return -653602.0912173735;
}

int SqHxTWWiyor::KzCScYMsmGapzoMp(int LKAlvUJYeRsx, string qIHeXzXqlLjNTE, int LlYwHtcR)
{
    double FEZmWJD = 879763.0323725449;
    bool rDimXbgGBKsqB = false;
    double qIpYgYhkc = 347688.1730941661;

    for (int ClXgQnHoBXwSCPG = 668750420; ClXgQnHoBXwSCPG > 0; ClXgQnHoBXwSCPG--) {
        FEZmWJD = FEZmWJD;
    }

    for (int cXPDNhcX = 1587625721; cXPDNhcX > 0; cXPDNhcX--) {
        FEZmWJD = FEZmWJD;
        qIpYgYhkc /= FEZmWJD;
        qIpYgYhkc -= qIpYgYhkc;
        qIHeXzXqlLjNTE += qIHeXzXqlLjNTE;
    }

    return LlYwHtcR;
}

string SqHxTWWiyor::JgLxZdyMBBnkxp(string XegHwIxqeDyKLWIw, double XUAzYJVVWfAOAjAH, int UCZZoTtVPIpMk, double xfRmdggXTYAbC, double oOGTNSQfbpTgR)
{
    string IbWuvYBNhB = string("ohtoxeHOlDJwizXOflXBQMtlkTMMtTckVJduiSySaDJTgjRchjzvTtBQvqNpbDleeFobvZuIYRFDhqnLBiDsLCYsWjVGYlFQxOPXkkeqAlFEPCWZqKVgzsZopMEvxCKbtLQFmmSopYAFFiNBAQXbkGCyhIlrnCssPfEBkcJRTdgMvmXpfReJCAbSxREVjzvmHphGXjuKdfepiDkMVzDizhCcwe");
    int WnhrazCTWj = -1782946537;
    string nGgTZqCbcjRy = string("lqsUVjHtIlkhMrWfIlVYRgQAhXCqcxkirNhbtSBoSGwKvQtcIVnVzKsTctDkKdwwDABeLCGPtdneuvBWeMfZPuNeikwiXGhjvaQTeYoHhJcNeweTvbGeUTiAuTzAsERoVRZyltkvHoKbIQFgbLdWovkAtkioXVPQdazvRjKlKLrNjJQvCxKQWnLPEScFUDWxCCyxYlqC");
    bool cMsYwmbHNRffyVvZ = false;
    int ECbTRootxwH = 2082469971;

    for (int TFhALjskVgpXw = 944988837; TFhALjskVgpXw > 0; TFhALjskVgpXw--) {
        continue;
    }

    if (oOGTNSQfbpTgR == -350429.7956950771) {
        for (int GuVtHiQnPN = 1130882397; GuVtHiQnPN > 0; GuVtHiQnPN--) {
            ECbTRootxwH -= UCZZoTtVPIpMk;
        }
    }

    return nGgTZqCbcjRy;
}

double SqHxTWWiyor::wWWlhKXhoBPlj()
{
    string etSXKsUMpOU = string("ClYmPpLfxVfMvsUnubgJEiQNIquqAsUWXJMpwyUqlKFfpupJwEunelpKojQkNadTMJGQHlJhRLeaCJofmYhaBmaJmNZPbFWjavoSfPveXKlCsiapWyGGcjdnmrDUysyhEbujRkCkdiXcdbpeiLJgDFTKWMqdWCDBGNlcVgLceyedeyXzSzFmQAoOZbQKAbGMOWsBkqFxrXONnxlOLpckmOmXTkYwijFTQkKNjKrYuSoAroGLzKuHV");
    double zLfayEAtzfK = -82603.02363044741;
    string ZNwKFNakPW = string("GJGacZOiQOzhtZpmLqyzzvGPVMeOpTnSjHsxtbjMSOYtmiDBatXEvtwtbiLMUmuEbtCqnWjTZDWwNUndlWawmQgCyplaloZuqLMboWPdIXTIgLrXshrMKFjcQrWyTcmXoARtfcJkdTyvcxOmXjXDoazmNEDYH");
    double nLDQOMQA = -944622.8675726089;
    double ahmbBYJyNvKCwfdT = 753203.2661738502;
    string krdQgMoju = string("NbvKqrJbahAHdBSVyyLAVpsaqdGaBeRIpYnjOtkHtLKcUTqJYPYLIIewtMBooSdYQegMd");
    int fLIYfpn = 1866768748;
    double ItAwRwq = 374537.5890928185;
    bool fuixYsX = true;
    bool VScArBNKla = false;

    for (int ctGeW = 702419940; ctGeW > 0; ctGeW--) {
        continue;
    }

    if (etSXKsUMpOU <= string("ClYmPpLfxVfMvsUnubgJEiQNIquqAsUWXJMpwyUqlKFfpupJwEunelpKojQkNadTMJGQHlJhRLeaCJofmYhaBmaJmNZPbFWjavoSfPveXKlCsiapWyGGcjdnmrDUysyhEbujRkCkdiXcdbpeiLJgDFTKWMqdWCDBGNlcVgLceyedeyXzSzFmQAoOZbQKAbGMOWsBkqFxrXONnxlOLpckmOmXTkYwijFTQkKNjKrYuSoAroGLzKuHV")) {
        for (int NaNBbePzRzmsqCE = 501559278; NaNBbePzRzmsqCE > 0; NaNBbePzRzmsqCE--) {
            continue;
        }
    }

    for (int wHXRBZSSBFzaJ = 2116791269; wHXRBZSSBFzaJ > 0; wHXRBZSSBFzaJ--) {
        continue;
    }

    return ItAwRwq;
}

string SqHxTWWiyor::EbAktpBT(int QBEJyGksTAvO, double vvaJgvDgvMDcXei)
{
    bool emDnHivUkuEmG = false;
    double GLfou = 937204.7484671385;
    bool LsWfKyRyrfZaqBCW = true;

    if (GLfou > -630469.7624312495) {
        for (int DOjqmLGFAKo = 2099519370; DOjqmLGFAKo > 0; DOjqmLGFAKo--) {
            GLfou -= GLfou;
        }
    }

    for (int ydjAvgxzUxfT = 1250772856; ydjAvgxzUxfT > 0; ydjAvgxzUxfT--) {
        vvaJgvDgvMDcXei = GLfou;
    }

    return string("bZptuIBuCbXbAHIrbqridpItvcJbRgPUJsLOfRFPuALnlTtdrIzWeSHYxOwLMVAixswtSfobZmpZjtzbBoSZORcznWojuhLXrVsJBUnUyYDSekQpWzRZCmyNjaSXXPjMIGQXtFhUPRmQdDANajLGDbepVVxhXLfwoCOoSRhkqJAyql");
}

string SqHxTWWiyor::zzBctYLloO(string lXSFp, string SIEyfQHTkiHEbMfc, double iEeHNMdgADJPeQvB, string WefdqBxE, double LOhyqIf)
{
    bool PEzYdE = false;
    string qwVXJlcWYSzUbhA = string("kHZhbkqFiLnADybAFC");
    bool awIwCES = true;
    int PWgpx = 67057691;
    int IcsrOTplkJRDcs = 718179007;

    for (int jisLxqFPH = 1304743489; jisLxqFPH > 0; jisLxqFPH--) {
        continue;
    }

    if (qwVXJlcWYSzUbhA <= string("kHZhbkqFiLnADybAFC")) {
        for (int MOpOxZFvkvUycr = 628851993; MOpOxZFvkvUycr > 0; MOpOxZFvkvUycr--) {
            qwVXJlcWYSzUbhA = SIEyfQHTkiHEbMfc;
            qwVXJlcWYSzUbhA = lXSFp;
            SIEyfQHTkiHEbMfc += SIEyfQHTkiHEbMfc;
            qwVXJlcWYSzUbhA += lXSFp;
        }
    }

    if (qwVXJlcWYSzUbhA == string("KSokOztapuaVBfaKGkaWeYucRyZowLLDsnmPTguSNBAbulyLzDxiNDeJNhXzKrHdxzZzvqtNPIBJfyqjxVaoPasvNHCAnZgJyToQcOIhhupeBnffhpNOUwJBZCqigYqCBnPqGsRpUabKDhyTBhotJxHskFyxKOrCnYlCpAGtMjqCvaEyTveuXdGJHuspGaiRWGdcawIHaLjyGNOXLtkMIpcgRTLHktAgFBtIcjwpVHVVkz")) {
        for (int CNrjhaezKRY = 1940770487; CNrjhaezKRY > 0; CNrjhaezKRY--) {
            continue;
        }
    }

    for (int mOZRasWdoXSCNwz = 1038374986; mOZRasWdoXSCNwz > 0; mOZRasWdoXSCNwz--) {
        WefdqBxE += lXSFp;
    }

    for (int RQVLNEDyDNKSPjq = 530321848; RQVLNEDyDNKSPjq > 0; RQVLNEDyDNKSPjq--) {
        continue;
    }

    return qwVXJlcWYSzUbhA;
}

bool SqHxTWWiyor::AnMZPFfGFXv(int DhQMr, int XlwoUURdNAuprUC, string lWrMUeBkweYjEKlm, bool pVAHgAQtVShoQnB, double dNcTbmQgfKhXSB)
{
    int YdiKhNgWThntcm = 1292739709;
    bool EpUKukr = true;
    int ePFaJ = -604020833;
    double rewQvPcJY = 806307.914251802;
    int gsKkOKpmXkvrAG = 1078216049;
    string YHVYvMX = string("flTkWATiuzXKgHkaMZFshPevtDTNgPccphSktQdWGNlXCbnaIrTDNOOlbRainKtWHQKGEGAhrrEJjXGYptSWLUJPrJGvtRyFPJDvTmIpADDypTuAALaZqJVlzMsOgTfMF");
    int kCrfGUmIwwoiD = -1865910438;
    int AjWrKJqlg = 124133622;

    for (int lDHqFPlmNe = 1619734578; lDHqFPlmNe > 0; lDHqFPlmNe--) {
        lWrMUeBkweYjEKlm = YHVYvMX;
        XlwoUURdNAuprUC *= AjWrKJqlg;
    }

    for (int EaAucVV = 1683757831; EaAucVV > 0; EaAucVV--) {
        DhQMr = ePFaJ;
        rewQvPcJY += rewQvPcJY;
        kCrfGUmIwwoiD += YdiKhNgWThntcm;
    }

    for (int IiPTEUycFHxTXe = 2061072575; IiPTEUycFHxTXe > 0; IiPTEUycFHxTXe--) {
        pVAHgAQtVShoQnB = EpUKukr;
        AjWrKJqlg /= ePFaJ;
        XlwoUURdNAuprUC = kCrfGUmIwwoiD;
    }

    if (YdiKhNgWThntcm >= -604020833) {
        for (int pZopgUdVczzU = 1007294819; pZopgUdVczzU > 0; pZopgUdVczzU--) {
            XlwoUURdNAuprUC *= YdiKhNgWThntcm;
            YdiKhNgWThntcm += kCrfGUmIwwoiD;
        }
    }

    if (YHVYvMX != string("flTkWATiuzXKgHkaMZFshPevtDTNgPccphSktQdWGNlXCbnaIrTDNOOlbRainKtWHQKGEGAhrrEJjXGYptSWLUJPrJGvtRyFPJDvTmIpADDypTuAALaZqJVlzMsOgTfMF")) {
        for (int IxaDPGeSAfpIzbh = 1286492389; IxaDPGeSAfpIzbh > 0; IxaDPGeSAfpIzbh--) {
            lWrMUeBkweYjEKlm += lWrMUeBkweYjEKlm;
            ePFaJ += AjWrKJqlg;
        }
    }

    return EpUKukr;
}

int SqHxTWWiyor::syrdpk(bool fexPqLr, double qHtnwirqNFPDWa, int DIpnpU)
{
    bool RwuMR = true;
    string LJKVLFynHILkux = string("awDfIEEaGbeXnCmvWvoGdNtYkGLxATgmXYlEUCuGavXCbFTfvmXybfLkuuEmyYDKIcCRWvZadlxvaBUMfReAToYNOwocAHBjEkTMnnjCHuXfkhpEiPxgstvqDwJAzCbvdLmENwBFAbWyksMskHiNyqgJAVkAXEOxCPRrzycIslTgmAUcke");
    string ZzxihMWfroc = string("jBsieznYvRcnGrAYNFBGxJHfaCRGnMD");
    int bYyeHUUfcWIrMWjI = 1611793437;
    bool scVQqVEPzqiVLpf = false;
    int KYvAPg = 293614440;
    string PQmjEAFLSsTuv = string("GVYlIwBwAXagWvwCxFFgiVTiMjmcReqTzdEuGaGLXPkchNQsboGkOQjsVIpgFzqftvzsyaYXGgnBjRpRkVuWqxOnsYOVIKXPALuYEpjAgaagcKCWaZswzzAsLAsIkUEFsVMTGgrzIcPmoVhncVVoCwHKZAmAEjEDvEfQYbQSElRNVMxXriqxqCjAXBDLXhzrRffsZNOqBWfPHPlEGwtIWIXbKWsHyLEbrHuczcMwnWIfKqqpVDFkXmoxyS");
    int iJHAzWaZ = -1699944037;
    bool ymesz = false;

    for (int HupaOHHkTkmSXDG = 1215574947; HupaOHHkTkmSXDG > 0; HupaOHHkTkmSXDG--) {
        RwuMR = ! ymesz;
        DIpnpU *= iJHAzWaZ;
    }

    for (int khdOSM = 646356678; khdOSM > 0; khdOSM--) {
        continue;
    }

    return iJHAzWaZ;
}

bool SqHxTWWiyor::kaMwrJhJifR(bool OBsHWUWPnjaJYAS, string ByGYpRq)
{
    string hqsSbXdzoyUfW = string("ufgrhaAyKdSCgBZvEjMKDVJCEcXkNxKAIuHPRpHFBBZfkAJjoWFhmWMJDVsNLLpjelYVIZDRQVSMrzLkskhDKMGidiAnMabKQTygSfUCUOAvzFKcmvQJlHeDKqXrqNYspFCIZypxVqZnGdoQrFqjRiHirWwTFQwwZdClqLhVOUsUWqsYjwnkhZEPmVXXFIjaTgwxvsOpIrUTQCVSDcImZcKhlAihJQPg");
    string PUMwIvOqU = string("VlnjSMGYPzlbomsnZikUQTZfaiDsbzaTesIKJyOTNYPFhtvPJjEubWblblXDWOsOwsKSdHcVBLodxYYmPdbTsIAHkyPVuQfBXAMrQHrkojhbkPkuEDOUkPf");
    string rlgdOwF = string("kADSXsoBBjbIhToTPcHEadaLyjXzeAhbKuGNyfJQzc");
    string cNcfqBye = string("qDYgtxEcBsGtRITIQXAHTPrtZqEuhsBogGJNSMEdIRVpNVPTgYqKeSqhhHiKeCyqBBiYcknSyktyUGnvpTJIMwKlLDQxIKCOLxMebMIQBWNlpYoZMdNMQnywYSusmwnlcgDrQWDtGsSmjKOzXWvSumXfyRfjXbXlkUKhdHieosrxLQMIUSScVkPlDhiuKlVvrRlAVYAgbZVJkErVWqTcZjpemHjm");

    for (int YcBxvA = 355393127; YcBxvA > 0; YcBxvA--) {
        rlgdOwF += rlgdOwF;
        PUMwIvOqU = rlgdOwF;
        cNcfqBye = rlgdOwF;
        cNcfqBye += rlgdOwF;
        hqsSbXdzoyUfW = ByGYpRq;
    }

    if (ByGYpRq != string("ufgrhaAyKdSCgBZvEjMKDVJCEcXkNxKAIuHPRpHFBBZfkAJjoWFhmWMJDVsNLLpjelYVIZDRQVSMrzLkskhDKMGidiAnMabKQTygSfUCUOAvzFKcmvQJlHeDKqXrqNYspFCIZypxVqZnGdoQrFqjRiHirWwTFQwwZdClqLhVOUsUWqsYjwnkhZEPmVXXFIjaTgwxvsOpIrUTQCVSDcImZcKhlAihJQPg")) {
        for (int SfAJSOfALGS = 658613909; SfAJSOfALGS > 0; SfAJSOfALGS--) {
            OBsHWUWPnjaJYAS = ! OBsHWUWPnjaJYAS;
            hqsSbXdzoyUfW += rlgdOwF;
            OBsHWUWPnjaJYAS = OBsHWUWPnjaJYAS;
            hqsSbXdzoyUfW = hqsSbXdzoyUfW;
        }
    }

    return OBsHWUWPnjaJYAS;
}

int SqHxTWWiyor::BJjZwxRjQzYlR(double XpvrYwc)
{
    int OngZpjQdBXt = 1697445499;

    for (int FckPTlWBIgGCvTq = 951612653; FckPTlWBIgGCvTq > 0; FckPTlWBIgGCvTq--) {
        XpvrYwc += XpvrYwc;
        XpvrYwc -= XpvrYwc;
        OngZpjQdBXt /= OngZpjQdBXt;
        XpvrYwc = XpvrYwc;
        XpvrYwc = XpvrYwc;
        OngZpjQdBXt -= OngZpjQdBXt;
        XpvrYwc /= XpvrYwc;
        OngZpjQdBXt -= OngZpjQdBXt;
    }

    if (XpvrYwc >= 352340.39089033275) {
        for (int EfAFbgY = 516772731; EfAFbgY > 0; EfAFbgY--) {
            XpvrYwc *= XpvrYwc;
            OngZpjQdBXt /= OngZpjQdBXt;
            OngZpjQdBXt *= OngZpjQdBXt;
        }
    }

    if (OngZpjQdBXt > 1697445499) {
        for (int HDAvKFFVna = 1069286832; HDAvKFFVna > 0; HDAvKFFVna--) {
            OngZpjQdBXt += OngZpjQdBXt;
            XpvrYwc = XpvrYwc;
            XpvrYwc = XpvrYwc;
            XpvrYwc *= XpvrYwc;
            XpvrYwc += XpvrYwc;
            XpvrYwc /= XpvrYwc;
        }
    }

    return OngZpjQdBXt;
}

string SqHxTWWiyor::dpWPE(bool UcoFX, double nTdReUNssff, bool jWGlfgrV)
{
    bool rCtDFysNor = true;
    int rGuhyFhHQFsSpq = 1552153487;
    bool ObqRqYFQ = true;
    bool qUwLApjBwwm = false;
    bool jdaSaVzHLj = true;
    bool QJYkTBvgVdlt = true;
    string blHEiSyYG = string("a");
    int OrUMa = -1479000528;
    string SeitU = string("QsPNcfheLDbHPufCZYvlpPohZqAyMZlFNrXjwCeXjGNQcBlkzBJrQxANLapFPRXwbXyMansWyTwjRnXpBzussTLaxlHOYvdKurBCgYjhBPFRvUmRsRtgbdkSeyULXzRQmvFTrRoBgLeEfndUMtYPyuphlYcxgVBuSWepYzUFIQYspfSwKQWmJyEVOtTItfLhsIhsMdOCRcjudTXiGIXqtFgDjVwMRNVZbNkhsThQNyqeGUpURkNDzsNEp");
    bool dObBVNVDnDaFU = true;

    for (int qsZKILwoIDaDfab = 622395318; qsZKILwoIDaDfab > 0; qsZKILwoIDaDfab--) {
        rCtDFysNor = jdaSaVzHLj;
        QJYkTBvgVdlt = QJYkTBvgVdlt;
        UcoFX = dObBVNVDnDaFU;
        ObqRqYFQ = ! QJYkTBvgVdlt;
        dObBVNVDnDaFU = ! qUwLApjBwwm;
        UcoFX = ObqRqYFQ;
    }

    return SeitU;
}

double SqHxTWWiyor::dRUbWgWiAlyG()
{
    string hTAjcgtWzMX = string("IzMhLklWJrpUvTcGvdNDCNjcjjZjjgSoxPvlegnuYzlZNfxocCOJgnZJpqQitEFIuEJcykAlRGgoYPKHMmFjCGGGoZgQSPaFdVCmaDjvSbsHcTsQCackoFKPpKTPaPHqEFGnbsQDBmnaMmpGvugqWmMdIpiyFmIcrxLxKNnKgnbkfwOKdKEDNGbfeZADHjMWzRWyaSrOTItzQnFUiNwfFujeGDQrBPFLfs");
    int kJnxOMYZtD = 1052129107;
    double azlwgzZDoRFMrj = -531496.1234358916;
    int wWPAxvxr = 1324855897;
    bool FkOndHrimrSWoJW = true;
    string qXWBsy = string("zQQruUYSVyATvYGT");
    bool QwePCuUH = false;
    bool ATjmuNhQFetIY = true;
    double YHCeeEluzYrKSce = 898585.819380938;
    int LlUSk = 701720592;

    for (int RybyXJGQaGN = 1057965632; RybyXJGQaGN > 0; RybyXJGQaGN--) {
        continue;
    }

    for (int morQzVtsKnUMtbHb = 35314045; morQzVtsKnUMtbHb > 0; morQzVtsKnUMtbHb--) {
        continue;
    }

    for (int JsfEYetKnGraZSXw = 1885290510; JsfEYetKnGraZSXw > 0; JsfEYetKnGraZSXw--) {
        FkOndHrimrSWoJW = ! QwePCuUH;
        azlwgzZDoRFMrj *= YHCeeEluzYrKSce;
    }

    for (int dmRhET = 1830692054; dmRhET > 0; dmRhET--) {
        QwePCuUH = ! FkOndHrimrSWoJW;
        ATjmuNhQFetIY = ! ATjmuNhQFetIY;
    }

    return YHCeeEluzYrKSce;
}

int SqHxTWWiyor::zyDeOwgaSgO(bool qadkmodTMxUd, double rTXJczPwVUR, string aaNeTWdgmnz, string sHUiPFTHNpxsHOW, int YdTGpZVild)
{
    string NrtvgCV = string("eZSWDeoynWdribApQDgYiEmouGseooCcedZvDQnhQxLOCPIpWfnuuWrzgeHsXrLAmKQZfmJHBrzXfEXrSrlrmGSlcKPttrIbaGXLqZYJeBzlHcLNLKwuEfVvwEPKUeogDSsBdGKqXBxrYtGJNKYhUZWassDNUQGRlaTsUVhGAXBIlZmICcKKkOJSyvEMGIZPpOwEeaXSRqVbAHsiTxFtW");
    double BMBzcVPG = -636310.7075388243;
    double ZuhNViwh = -932378.695635284;
    bool wMkxOAecLnBs = true;
    double pDtMcE = 965774.5469122125;
    int loiNGMsxmnaKnk = -925848267;
    string ulDnUwdA = string("VqHVYqJTrRQAivUGKaEbICVabWpLuHXaDudvxrqTNKcYJcBFjRZsPKIZiEtfoqMzgksVhtigZkVBxOkQSFEwZUaoqqAfWPEPSahBsRFwokAejpbdEgidMOoqsAwShXPmjrucanbSoRoJaISpcBhBbMSbJQKpsxpuGiwmghAeKmnyuHdTvKTqJiSlmXWodgOMzHBeWyngrdzPXpmYzcZuFMSADkof");
    int RRvfpguq = 795645309;
    int XHVdcjJf = -2038232208;

    for (int wPXcuPsh = 2143763635; wPXcuPsh > 0; wPXcuPsh--) {
        sHUiPFTHNpxsHOW = ulDnUwdA;
    }

    for (int OncPUD = 242443051; OncPUD > 0; OncPUD--) {
        YdTGpZVild = YdTGpZVild;
    }

    for (int ussRXPukuaCa = 1916905639; ussRXPukuaCa > 0; ussRXPukuaCa--) {
        continue;
    }

    for (int oNqQISiANo = 592546014; oNqQISiANo > 0; oNqQISiANo--) {
        NrtvgCV = aaNeTWdgmnz;
        pDtMcE /= BMBzcVPG;
    }

    return XHVdcjJf;
}

string SqHxTWWiyor::WsIzfyeWqOA(string uKdWPgnW, string vtleGuFg)
{
    double sUjNDjlpOuuUxg = -751415.8420806156;
    double OGGitVY = -31503.62563226433;
    string ijiMyVcgUoDH = string("AtUTkMwGxTQJhMrDkZqxToEAPvJhZybtpQiMDXCxLrzrYgAcXtGLwdfStYqHiZNhufgnEzIUHAlcrgAdcCMfYQbfnVljOBjUUyqYUOpanTJwgjMKltIgVMcsSIyJTfhWUDBfCcIqWgyYGgtZcRwObmgZcTcVAIYGfDjppnEzWzUOUpfjCJCEXJlElYeHUlHyepwPCwoMaqQfCHrlHVaBLqznplMrPWRnIFUG");
    bool XYHvzi = true;
    bool uHmWDCBnZkVZhfMR = true;

    if (vtleGuFg < string("nKkxdrvgirRtBxaQAbdFMeVqCdMErCDXKILHqJrMqQeEoRMpqdDwnUHxkAPmjAkjhzkGXHsADSUVtqQuPetfzhVZDf")) {
        for (int wZroXSPlAOyxr = 1214910227; wZroXSPlAOyxr > 0; wZroXSPlAOyxr--) {
            sUjNDjlpOuuUxg *= sUjNDjlpOuuUxg;
        }
    }

    for (int ACbecgR = 1519820104; ACbecgR > 0; ACbecgR--) {
        vtleGuFg = ijiMyVcgUoDH;
    }

    for (int NfXmaoNRMug = 1975411576; NfXmaoNRMug > 0; NfXmaoNRMug--) {
        OGGitVY /= sUjNDjlpOuuUxg;
        XYHvzi = ! uHmWDCBnZkVZhfMR;
        XYHvzi = ! XYHvzi;
        ijiMyVcgUoDH += uKdWPgnW;
        OGGitVY *= sUjNDjlpOuuUxg;
    }

    for (int zRKCN = 424344045; zRKCN > 0; zRKCN--) {
        uKdWPgnW += ijiMyVcgUoDH;
        uHmWDCBnZkVZhfMR = ! XYHvzi;
        uKdWPgnW = vtleGuFg;
    }

    return ijiMyVcgUoDH;
}

int SqHxTWWiyor::KEnom(bool HEyeTfSuAQi, bool GGoCLIQcS, double jhWbsUgx, string IMdAcQaAevCAdS, int jZOlTPkAmzFdj)
{
    double eGnlu = -968012.332325247;
    string nnfon = string("GuroaaWbbCAleibvwZrfMZMLVufljHSAyOLoJYowTgLUEEEhksYYoBUjkKsBuenZnbclfpBwloCZRtCMnBsuCHBnWqnKzcPttZROTcRrHynBGnJPkxJGTXBUcBZOBclVhWdXsKjUVfGmvwkTjSeRGqPpXWXekgcWxAVVRkYMiNmDDPpbzSahAeebbqNvyCYoLKhHVjVjtjgGrf");
    double GguAh = 889911.7268956717;
    bool BveyyEGMzot = false;
    bool EpkhEcXtqX = false;

    for (int SXGPASAqD = 1307845540; SXGPASAqD > 0; SXGPASAqD--) {
        EpkhEcXtqX = BveyyEGMzot;
    }

    for (int gOKTfu = 1877943367; gOKTfu > 0; gOKTfu--) {
        eGnlu /= jhWbsUgx;
        nnfon += IMdAcQaAevCAdS;
        eGnlu += GguAh;
    }

    for (int GUzPFWKoCNSOQIOx = 2078552335; GUzPFWKoCNSOQIOx > 0; GUzPFWKoCNSOQIOx--) {
        GGoCLIQcS = ! EpkhEcXtqX;
        BveyyEGMzot = BveyyEGMzot;
    }

    return jZOlTPkAmzFdj;
}

SqHxTWWiyor::SqHxTWWiyor()
{
    this->ctbjLMrAl(true, true);
    this->kCcCeml(287043162, -161632638, 157231059);
    this->zkXYOJdsib(351093.75581050466, string("PmwupWPZjjWN"), 2021898463, -13028.505679411668, 29209.54251926205);
    this->nJzaepYs(-1324697576, string("pfHftqwhshiBhrzKbjYXnCkCIbhtVTrbkeCxrVbsEduevLEoaQBsAlKayQqFFF"), string("DldUmxYAOKonzPyDqUClvkohZYLedFXrZVcRDuTWZkZhIqCSTzqxbenn"), string("KrfrjDduOpUXexXHnpHw"));
    this->hJtypdPuanHCAv(133498406, string("ExXfqrjhVEEiCdSrZZjerSQPjcgxzknNCczUHNEUyKuBAoUKHkgVTYhcAvPawsRngMOhngEuZfMvdcnrMnVdDyNNqxltAlbOttNgyGFGEJjnsnUXGTEDmOEEkdXGSCOdUjIlFuHCRBoFRfgFXlldqXXgPCryMlfFUopnXxDLaCuFZVgFDFljelzfBXjVZTaTwuXWVUOsxYwRDxqLBPvVUjLGVuUyUmoWMKQEldACCzqmWwa"), -435877.0589928981, string("NPsRMYlOuPxvYVvRFPLHTLJHlQRjCXDCSqBoeRJtIzTMCipKKbAoMcOnXa"));
    this->ggUTak(true, false, string("kXLdUePjCwtttBGiBoTYSfBddlLLvFGaBtTnJHreInKhQUoltODWuv"), string("cuCUHKTRhjVQCxCPOWSFFHfuRwnjiAvFxLZpfkvDenWD"));
    this->KzCScYMsmGapzoMp(1552825186, string("iZPcFrMrEthxZjQysqbTctwGvZwDygUsyHmXpeYCvazbFhIPrvPnciFrwloGnDFQduwoUtBAuExvWTEpoUgkhAclLYlotaXCazttfppvCFWkFCBbYLanTxbQvpHkYMoqAFxDfirghvvOZYOlXzDyJbUieMZXtjLwUOyZugRmjFJIAlfmCU"), -819598644);
    this->JgLxZdyMBBnkxp(string("sxwfyfmBVvIROZIvkWQClsPdxLPMqDfkkAQzwIuAqGebErypgAmrNGuCsAeEEmPSZzsRCPjfgvFtVqHhFLEJNwqInXofwQxTYZjlSFwUEFHaGXJRgkB"), 821879.3744121486, -45590804, -350429.7956950771, -747320.8849435222);
    this->wWWlhKXhoBPlj();
    this->EbAktpBT(-1767517245, -630469.7624312495);
    this->zzBctYLloO(string("rTAJktENdTSCCLiUmkgKprWTLWKUFZwHYchkkOrTKErdwbOBXuzCpfFfjSNtjIEVrScWzaykmiOlsGfSqzKpgOkfycWYLlExkVWcqsSeajreDLzmRRmoapDRxVvdIovkUWgtfagZMXBGZWfjqtaxNkEcKCTJVnbgwIpZtmNbJGswSYlSJEJFWPOwcwLtADxhON"), string("KSokOztapuaVBfaKGkaWeYucRyZowLLDsnmPTguSNBAbulyLzDxiNDeJNhXzKrHdxzZzvqtNPIBJfyqjxVaoPasvNHCAnZgJyToQcOIhhupeBnffhpNOUwJBZCqigYqCBnPqGsRpUabKDhyTBhotJxHskFyxKOrCnYlCpAGtMjqCvaEyTveuXdGJHuspGaiRWGdcawIHaLjyGNOXLtkMIpcgRTLHktAgFBtIcjwpVHVVkz"), -86114.97113253744, string("qUdHyBOMLXTkmQQmqJzBriAILnoaQUZmPyLaDXNfppPvQMvzLEsWuDBAWGNpIupNzDSfQGbJfcAzByIzkbHyUVtQEADa"), -68835.12076418626);
    this->AnMZPFfGFXv(-956955070, -512875844, string("vSHSsgCshzprXLUpwLFLhlnM"), true, -479545.8757724734);
    this->syrdpk(false, 478017.5481099929, 1918051802);
    this->kaMwrJhJifR(false, string("rsFFxCuIFEeWXTbfvRhhdjTMmJAlAFAsRmOYyYebdYJIrygrpTZeqHUHfbvIgwyFlzTFggnnSpQyKdshGFP"));
    this->BJjZwxRjQzYlR(352340.39089033275);
    this->dpWPE(true, 579889.3769153091, false);
    this->dRUbWgWiAlyG();
    this->zyDeOwgaSgO(false, 233324.4458227463, string("ceFBNgUfKDMkprkYbiFcHQkvDGohxTNEEfAYQOKWzfHKSMeffIQKnlwKMQXeXXFIwkfOtYRDlDxMKmDigITftUYPzDUMjctvifJeheSyiAeTzEkUdloKkbOgxDFfbbzZxEouCsKghkVcMvreJZEkqbWdWazhLnFonaTfJXuqbHWjzU"), string("bopcnispJkFaUjxwPtFsyozIVlScderfgOUItZlMAzwmTKPcYRAtZzTQtLzNVeywYyiASxAcrMRUPJtbaFMsqDRNMzNvugdGvosVTabACUMKADuviWyGvdARYvLHtyvEweInwevLjYRzMQjuAPDygANrQTaWdaQrrLKeiGqoZESTFbNAdcFnCABMlGtoBfNPUuVYRHsSkZtfiFBjcJv"), -1833882770);
    this->WsIzfyeWqOA(string("nKkxdrvgirRtBxaQAbdFMeVqCdMErCDXKILHqJrMqQeEoRMpqdDwnUHxkAPmjAkjhzkGXHsADSUVtqQuPetfzhVZDf"), string("EIzYWIvntOxcZlrzlEcdxgBqngPOcBDdUfYuwJEvrPkwohTOBNPlLefNNfVbaQYjXcMQQQkmNlKisUpumvIrAlLSrVuGBGMlWetaaHjtHcjdrryIYtfZmZQtQeNEkdsEOTCezlXltdaOChFbiIGFGbmfzmDqrimxKvZkbuDnQZYeqaJwcMthpvimsNSiHxecKoIqQFRsmzkiOzLdaBtEEnXjzFEAGYKdCmoLRmcgeBQvkVsHrnCmPgedU"));
    this->KEnom(false, true, 984148.0442297955, string("XpFawFXWlqTKZHGwjrZTzjZVACvtTCJzxTK"), -797351771);
}
