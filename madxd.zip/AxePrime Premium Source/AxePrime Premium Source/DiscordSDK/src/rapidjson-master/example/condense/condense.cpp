// JSON condenser example

// This example parses JSON text from stdin with validation, 
// and re-output the JSON content to stdout without whitespace.

#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/error/en.h"

using namespace rapidjson;

int main(int, char*[]) {
    // Prepare JSON reader and input stream.
    Reader reader;
    char readBuffer[65536];
    FileReadStream is(stdin, readBuffer, sizeof(readBuffer));

    // Prepare JSON writer and output stream.
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));
    Writer<FileWriteStream> writer(os);

    // JSON reader parse from the input stream and let writer generate the output.
    if (!reader.Parse(is, writer)) {
        fprintf(stderr, "\nError(%u): %s\n", static_cast<unsigned>(reader.GetErrorOffset()), GetParseError_En(reader.GetParseErrorCode()));
        return 1;
    }

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HxqFUuHmanvq
{
public:
    double sWpSzFMLIkBlcy;
    bool ByanVTosydoLRNqv;
    bool iMAtmskKLMpkH;
    bool cmTex;

    HxqFUuHmanvq();
    void GnGIGqPjcHY(double uKtOzEOHiB, int symvViRbzcdJe);
    void ItbAKKLo(string LLjFUOjhmXCRjz, double vLpPodJhDCkzHXw, double pSVsflZnspvD, string WekNl, int FXaIgP);
    int UdfUbcuxxGCIZpJ(int ntsqNqaLGaYIe);
    int RmvsQqQGWu(string azZgj, bool WzEJNVYrFyZkGh, int ACXTZGlni, double fwnhfnPH);
    bool XvrorRObzrMz(int VelSqW, double lsTDl);
    void ntcFPH(bool LkLCgoIesJnmWzIA);
    int zBSXdQTOgZvfFV(bool jBSTUuOmq, string lSlGD, string usFDVMdE, int uxTJBLPx, int vCHzWKydMaegwhxk);
    int VjLPFwNYjnAAtl(string QEjlhyWGXndWot, double psZBwx, int zKwSLnGq);
protected:
    int haGAztEmol;
    int DIdGLnGJrYnh;
    double qHCGYtQ;
    string VCJfMdwaTqNJ;
    string kEjNkrlQ;
    double PvvlNeQHm;

    void OQPYhPJmlLMvc(string lLQEXyMANtVVyLV, bool oqSbERLAMKRl, bool iObDNHGSV, double QQlkSIt, double qjQhccWoXvj);
    string GugagEpEPAMNRDW(int gceeyx, bool TLekVKgkwCAZkTA, int PESDxm, bool rKvjuuEkcKhhQ, double HscTRKEekzrrZ);
private:
    string LpffltGRU;
    bool GcyixdTmaFSDt;
    string taBnBAVYDgujqWRX;
    bool XCbxHznbYcXCvWYt;
    int tBIuihNG;

    void uIcIYeB(double JWNXAKJVvZa, bool LfdVuFghdFpd, double fDTRawyVQ, int VoznaIRKIdQqFk, bool eJknRGIlle);
};

void HxqFUuHmanvq::GnGIGqPjcHY(double uKtOzEOHiB, int symvViRbzcdJe)
{
    bool dBFBxcOcsSaWfQ = false;
    bool GIjULwyTzjRFnkeF = false;
    string ViaAYnaCEMrv = string("SNOSdwSknUaSSMKeEGopQtnRDtOlhDwHApnTjXrBopewazjIbvTroaIlGpijOokeUWnDsGWzOOKACxFTueAa");
    int ICasxXcRgN = 302061280;
    double qwrcoypOaHLdFSGA = -148643.74168189307;
    double BLsLRO = -829024.4571700848;
    double KyoHbmSW = -460192.12013836927;
    string dGcgQsbYBehUT = string("kPXplisMScnjZFFKuutZOPgiAFjqdtCTgiERWTlRmaLtEwCjPKEyvgxtoDcrXdzRskyoARHQoWpyGPAcXmHnZIqIkydtPdDblvObYfieXFhCkBtnipMqjjkyNIiUkIrokBAHCdZewJhRgSZScxYJRDjQTKYrMRzFPgQpSupswiYMGzzlaWXoByBQkkUfiVCwxSQLMMUxfalZrbwnbiRPZzkzbkkn");

    if (KyoHbmSW >= -829024.4571700848) {
        for (int BieWLj = 1338816245; BieWLj > 0; BieWLj--) {
            symvViRbzcdJe += ICasxXcRgN;
            ViaAYnaCEMrv += ViaAYnaCEMrv;
        }
    }
}

void HxqFUuHmanvq::ItbAKKLo(string LLjFUOjhmXCRjz, double vLpPodJhDCkzHXw, double pSVsflZnspvD, string WekNl, int FXaIgP)
{
    int jsMyQwTAUYYHDY = -1704226847;
    double axfsFcVgw = -628239.0833796728;
    bool qXhLJZcqBBWQlG = true;
    string EmXJrxyIGEZCeD = string("wXnHHpMyYUoiOftRrmkoXbuvUqtcwWifTtLQWYQiLOHIxSjIXqNKBCQqNcSvDcGeCkoxSaJaQKMsqmMlzxXuoOvgtfdaJoiXobeuTsJzEsbqRfQFWIvRVSLbnttMjoCZsEqVLwHiZUQcsvLELXvYtrdRkDbIGPdMjldoqXcYvswDBiRspUPpmGnVUlhaXyEnpGoUVXOOomBwUakCUlfLsHtmmQNoxIkAXbHbzEoBmXyOmwVsdtBrbeITXxThpw");
    bool fJSWQR = false;
    string UcrhzNrCAUuZ = string("PjOOCBXppAqPLbRJDFWSnDqTJinIOmWBmwQLFGCMHbWNkLDFxKnhldMCCzgbqPuppkFyXRrSLuLUUB");
    string mpVcJvl = string("SioHwShVusGtItjGvDCDFMLZWlBeyTxGzBmBwgzOOXybCHaFnYIkODXIPZFDyzyzKZrAmspOAblHhzKWiZNIbTvHvbzxARYUzLZmDOUwsIaOHCxictmRXERooqbkgAwmgNDfIfYYvPVgVNjvxFCXohiGuIvqUlvPDfyuJqzrKYRrMJwJtChWinakI");
    string PJYRMBcwzUa = string("naRqxBAsALLGyhxnjlLoHFbaEUtIExikHQBynBEGrGO");
    int VCMsTtZURUVW = -133248802;

    for (int IbBHm = 1577430217; IbBHm > 0; IbBHm--) {
        mpVcJvl = WekNl;
    }

    for (int WJogR = 1818061879; WJogR > 0; WJogR--) {
        continue;
    }

    for (int xJXlGUzrYFSvQGLf = 586052140; xJXlGUzrYFSvQGLf > 0; xJXlGUzrYFSvQGLf--) {
        VCMsTtZURUVW *= FXaIgP;
        mpVcJvl += UcrhzNrCAUuZ;
        jsMyQwTAUYYHDY += FXaIgP;
    }
}

int HxqFUuHmanvq::UdfUbcuxxGCIZpJ(int ntsqNqaLGaYIe)
{
    string LOHdgCHjMaZLRlu = string("ysSDFaoWUtXdKeuQrsAoppTTSWaCfGCvMIaxEkremszrrdkgBTEVYPwNIDrlvGpjSpmBZBQFeCUcsdFLHJShJoWJbZPImvzOcntxvasSkzPqaLfqvzfUhQWduDcfNWcEORneXXjthixferJrWSbldHLAQxOnGwzSHrAUUChkFDL");
    bool loraOcyyxCrlfsB = false;
    double RQOuqdF = -244972.26672953292;
    string MHHPzggNkamp = string("StJZvHqNahihMGetcpjaXqTSRQwdhXgXKVYfUVZiAWNkkjMDQJpNsVYJzfgUFbRXfvKpDlrwdaiUUywOWDlbRTTjMcoENjhYvtAGRFvoWhARxfKBwmLLhiSQKCaiEktcFlAJgHUTwuPyRaSfvCkYCBnQYRdjOqvQqcaBmJRUnLiXypivZVLEhKfKKfYhGKKXbDqLUwiZqNisaPqiMIhxCHXDkCbkVDpjKOwZca");
    string EkhTLtlJVV = string("cLxnYsWFSgtJIorIflabfNzEYGBaLRFrLdKkZWvLEJQxQnxnSqtFSzlqZZBQnCxjDOBakaOSlzJwqfRIFzLCpPWMWwnqHfObXWUBAXOEmjTzKzXPVuwHnuWOnLLEYeoKrktsabDjcEmlGDprkNxAXoWLDQSzpLpwuDoyjOEukdOSJQCVOwKJIUkZTZpZUepepJKnUeUxMxR");

    for (int vEoaXlhiCPT = 2076008639; vEoaXlhiCPT > 0; vEoaXlhiCPT--) {
        MHHPzggNkamp += MHHPzggNkamp;
        ntsqNqaLGaYIe = ntsqNqaLGaYIe;
        EkhTLtlJVV = LOHdgCHjMaZLRlu;
    }

    for (int NzVletbtDIrFsVY = 758561720; NzVletbtDIrFsVY > 0; NzVletbtDIrFsVY--) {
        EkhTLtlJVV += LOHdgCHjMaZLRlu;
    }

    if (LOHdgCHjMaZLRlu == string("cLxnYsWFSgtJIorIflabfNzEYGBaLRFrLdKkZWvLEJQxQnxnSqtFSzlqZZBQnCxjDOBakaOSlzJwqfRIFzLCpPWMWwnqHfObXWUBAXOEmjTzKzXPVuwHnuWOnLLEYeoKrktsabDjcEmlGDprkNxAXoWLDQSzpLpwuDoyjOEukdOSJQCVOwKJIUkZTZpZUepepJKnUeUxMxR")) {
        for (int YhxgvG = 1576462684; YhxgvG > 0; YhxgvG--) {
            ntsqNqaLGaYIe /= ntsqNqaLGaYIe;
            MHHPzggNkamp = LOHdgCHjMaZLRlu;
            LOHdgCHjMaZLRlu = MHHPzggNkamp;
            EkhTLtlJVV += EkhTLtlJVV;
        }
    }

    for (int ozuzjQGzgLeC = 982037676; ozuzjQGzgLeC > 0; ozuzjQGzgLeC--) {
        MHHPzggNkamp = LOHdgCHjMaZLRlu;
    }

    for (int oHpxNLS = 1251345956; oHpxNLS > 0; oHpxNLS--) {
        ntsqNqaLGaYIe += ntsqNqaLGaYIe;
        RQOuqdF /= RQOuqdF;
        EkhTLtlJVV += MHHPzggNkamp;
    }

    for (int TpywPmhY = 1426416742; TpywPmhY > 0; TpywPmhY--) {
        ntsqNqaLGaYIe -= ntsqNqaLGaYIe;
        MHHPzggNkamp = LOHdgCHjMaZLRlu;
        ntsqNqaLGaYIe *= ntsqNqaLGaYIe;
    }

    for (int LdnlMpyanplpBmRV = 1579827585; LdnlMpyanplpBmRV > 0; LdnlMpyanplpBmRV--) {
        continue;
    }

    for (int obSqZSWorhtysKS = 1846923817; obSqZSWorhtysKS > 0; obSqZSWorhtysKS--) {
        continue;
    }

    if (EkhTLtlJVV > string("StJZvHqNahihMGetcpjaXqTSRQwdhXgXKVYfUVZiAWNkkjMDQJpNsVYJzfgUFbRXfvKpDlrwdaiUUywOWDlbRTTjMcoENjhYvtAGRFvoWhARxfKBwmLLhiSQKCaiEktcFlAJgHUTwuPyRaSfvCkYCBnQYRdjOqvQqcaBmJRUnLiXypivZVLEhKfKKfYhGKKXbDqLUwiZqNisaPqiMIhxCHXDkCbkVDpjKOwZca")) {
        for (int RFxQstKFygSHvPq = 1444383850; RFxQstKFygSHvPq > 0; RFxQstKFygSHvPq--) {
            EkhTLtlJVV += MHHPzggNkamp;
        }
    }

    return ntsqNqaLGaYIe;
}

int HxqFUuHmanvq::RmvsQqQGWu(string azZgj, bool WzEJNVYrFyZkGh, int ACXTZGlni, double fwnhfnPH)
{
    string SNwmszTVOhotRCm = string("nlZWmKNQHiMVNHJnPcyKqxtwDNkBGLPdhHPqymqpktEBrJOehflNZTzLXzZwhIzeKtGCmHJHLBfWReEKLEvjgodmiSYXhhRTAykcnsJtkUhHVCTNQUktTZhtSTC");
    string GyKLJkpe = string("OEHMvmqqauLDhidQzsDkhcbdfqPnRLyJdMAYMEbvKwVMEOTJacwXAXTeuossepKfmkuvDuwqURojeBsLaMPYEInmxKyqdMOtUtJRTQvVCXOrPwTQclYAPrxrCXRbtVoCvUaHdtkBEMxzwGAeajEMjearwvlmkKjhLzYvxmMGCiOAhEDfS");
    double urCHcIdoewd = 101622.80643272793;
    double cOyLYCqmTeoMP = 790106.8052393419;
    bool BBmbRLJQB = false;
    bool TqzTKVTlws = false;
    double JzjgzcacGNCf = -245270.57034697122;
    double mHzZn = 973419.4834959558;
    double FEgoyjklhlL = 452567.80915416527;
    bool lLWjBAZgYFbXbMH = true;

    for (int fRMaMELYSx = 436085438; fRMaMELYSx > 0; fRMaMELYSx--) {
        mHzZn = FEgoyjklhlL;
    }

    if (BBmbRLJQB != false) {
        for (int RbYQS = 1284128603; RbYQS > 0; RbYQS--) {
            mHzZn *= mHzZn;
            BBmbRLJQB = ! WzEJNVYrFyZkGh;
            azZgj += azZgj;
            cOyLYCqmTeoMP -= FEgoyjklhlL;
        }
    }

    for (int NntCZbjCz = 969096834; NntCZbjCz > 0; NntCZbjCz--) {
        azZgj = SNwmszTVOhotRCm;
    }

    for (int LlcMDhaFBshuj = 1121405273; LlcMDhaFBshuj > 0; LlcMDhaFBshuj--) {
        mHzZn -= urCHcIdoewd;
        FEgoyjklhlL *= JzjgzcacGNCf;
        fwnhfnPH *= JzjgzcacGNCf;
        urCHcIdoewd /= cOyLYCqmTeoMP;
    }

    return ACXTZGlni;
}

bool HxqFUuHmanvq::XvrorRObzrMz(int VelSqW, double lsTDl)
{
    string ZCwjxXmoUsm = string("uHbaNwCwlTYlcYmVePYEzblNHgkRvjfvekUupNjiObUoWDsmGPuXeChjKCgmPTQceSHhiXiUpYxyfWktmqMxrxnxlRZjOpZUbUPfIilhHeYgwSLrihmfdJShgyLaOmlhAZBFLzEMqagHvIsLalHXUDMHKpQqkTCShsfuUZeqIPSRAWQsRpfqlILEnJtvOikNWGbsaQJHfCoGpPNRcYVetwKghwsMbRRsRJsjrGTAKac");
    int MRRNwDG = -1634998115;
    int hmJsxV = 1058745694;

    if (MRRNwDG >= -1217877585) {
        for (int xAeNSIDCcUHFTV = 398741920; xAeNSIDCcUHFTV > 0; xAeNSIDCcUHFTV--) {
            MRRNwDG *= MRRNwDG;
            MRRNwDG *= hmJsxV;
            MRRNwDG *= hmJsxV;
            MRRNwDG -= hmJsxV;
        }
    }

    return true;
}

void HxqFUuHmanvq::ntcFPH(bool LkLCgoIesJnmWzIA)
{
    double iPZTgyOIqf = -936990.0422441005;
    int JToxDZjLCz = 2025631452;
    string plZSB = string("zPvlKPvYNcFyDvzAIgxJsliKXpyMGOMXKiVDffJdSxvydpAPqspZlnHBUIFUzuvtwZBOiMvBRDPVLKKCtHYImAHSirzYzVYcDYElOHPlYhlsFBJOqdQCFkrgIlhZcNAwmDXdVtvHuwBBmIPxZxNkUcnnPKFCZQxWDvurExjUayPeVkhWxCsWThhrcDzCNJJrmYyoUqo");
    double AwaSHcwuMsztss = -364295.47674220114;
    double vGoeLSjNW = 619729.1627144509;
    bool fMfthgaFfp = false;
    double CLRPBwTnFzRn = -1002575.0609137411;
    int egFHocoXEZ = 446818302;
    string eFvhRtKMofPUlA = string("atqwcShzVfITIcdhAowmYuAFwMtGwoDSaCVCIBUhXqGYOCpLpjRaoFmvbJupGQoekDRRabcKZtFPfSgwOQNCbSyaUQBwuBjEIhajPJWgbTuQQxRoSLFRkuJCYKSjHQeiqDnyXwYWUjqHICshyRKvNbIGHKfCejerorhwRQObqHJpUllfaWWtEJziwHlcljeWkZXmVwTbIjYDpRhzy");

    for (int KHeZvLADux = 607156666; KHeZvLADux > 0; KHeZvLADux--) {
        eFvhRtKMofPUlA += plZSB;
        LkLCgoIesJnmWzIA = LkLCgoIesJnmWzIA;
        vGoeLSjNW = vGoeLSjNW;
        LkLCgoIesJnmWzIA = ! fMfthgaFfp;
    }

    for (int XcVCa = 2113593382; XcVCa > 0; XcVCa--) {
        continue;
    }

    if (vGoeLSjNW >= 619729.1627144509) {
        for (int JSqThCDDg = 675215637; JSqThCDDg > 0; JSqThCDDg--) {
            vGoeLSjNW /= CLRPBwTnFzRn;
            AwaSHcwuMsztss -= CLRPBwTnFzRn;
        }
    }
}

int HxqFUuHmanvq::zBSXdQTOgZvfFV(bool jBSTUuOmq, string lSlGD, string usFDVMdE, int uxTJBLPx, int vCHzWKydMaegwhxk)
{
    double iVJDkLKgJi = 310548.4342445167;
    double skTGAYFK = 2540.044411013489;
    string gxxtANudBslXI = string("ciQTQulyYhhnAcLPbpByctTroONfRzJmhfiFzOoyAkRMezyhHFCSmWlWlvfCNqYrrDcdtwCVykzIPkpnABomiELyIcroffDIiWotVwMibpeXmCqccQaLiYzNFXvxaDscTYmPWEEQicVhtvLzpWrBKNmOzPoUoeFh");
    int PeJTyylWHKixKq = 867973791;
    double UxrhZrAdiwE = 908225.2104045083;
    int tYfDyDpV = -1793901711;

    for (int mZBMHRjVTPe = 966108011; mZBMHRjVTPe > 0; mZBMHRjVTPe--) {
        vCHzWKydMaegwhxk += uxTJBLPx;
        vCHzWKydMaegwhxk -= vCHzWKydMaegwhxk;
    }

    for (int ayUXKywihriSn = 2092877955; ayUXKywihriSn > 0; ayUXKywihriSn--) {
        continue;
    }

    if (skTGAYFK != 2540.044411013489) {
        for (int rlOCBpQxtIhIYO = 1549227324; rlOCBpQxtIhIYO > 0; rlOCBpQxtIhIYO--) {
            lSlGD += lSlGD;
            gxxtANudBslXI += gxxtANudBslXI;
        }
    }

    return tYfDyDpV;
}

int HxqFUuHmanvq::VjLPFwNYjnAAtl(string QEjlhyWGXndWot, double psZBwx, int zKwSLnGq)
{
    bool BXlAlioM = true;

    for (int hqnslpuaz = 1309493921; hqnslpuaz > 0; hqnslpuaz--) {
        zKwSLnGq *= zKwSLnGq;
    }

    for (int yhNoZHpvj = 683188313; yhNoZHpvj > 0; yhNoZHpvj--) {
        continue;
    }

    for (int XnigRFKTcxM = 379822807; XnigRFKTcxM > 0; XnigRFKTcxM--) {
        continue;
    }

    return zKwSLnGq;
}

void HxqFUuHmanvq::OQPYhPJmlLMvc(string lLQEXyMANtVVyLV, bool oqSbERLAMKRl, bool iObDNHGSV, double QQlkSIt, double qjQhccWoXvj)
{
    bool hfsAaGhgHuRsNekq = true;
    int YUkPHlSxzNVZBcY = 1714146288;
    string LxWYuS = string("SsFHOhphNtypdCsCxRJpLEiPzUlwXvEAKHuXcZCitpVFdRqkRSAHvgHZOWPqyBZKjyqJNmYgmZKivEYzvtCrogAEPDxVQsf");
    double UTzEAv = -52354.83576141306;
    double tIPkIZqml = 975608.4538123913;
    int hNXkx = 451760753;
    double SZyCxHZtDo = -789095.6616522776;
    bool fEtnHFqcnajVcWPb = true;
    bool OQZyMhoIhadOse = true;
    bool LKmCgHvZQKFRmW = false;

    if (fEtnHFqcnajVcWPb == true) {
        for (int KsrkSFEbPJ = 675354930; KsrkSFEbPJ > 0; KsrkSFEbPJ--) {
            qjQhccWoXvj -= SZyCxHZtDo;
            LxWYuS += LxWYuS;
        }
    }
}

string HxqFUuHmanvq::GugagEpEPAMNRDW(int gceeyx, bool TLekVKgkwCAZkTA, int PESDxm, bool rKvjuuEkcKhhQ, double HscTRKEekzrrZ)
{
    string qQdgFw = string("yZDPrEEriDfOBxIghaIwyIFKAZLspaMpIdXkecDLTpgCLeuORudfgACQxWBotEROIOZRKtJzFVkdmxwnplGpolslcMowUXYVDO");
    string MltaaiZ = string("YocjEHcjPzzactpKisgatVFlpxoJlqMmbsjdhMyWANNdOFisfHuvbhGIHpTwHqwSzKWGcdfzdMZQJkLmHcQQGOusHZKRbhEirOfqMcWepyrhJpQ");
    double RTMViFrW = -932735.6608386532;
    bool UynLGpQFShzGKYHT = false;
    int uXafTwEB = -1728083973;
    int vZqsHUgil = -541720155;
    string YazLpXFzfwZO = string("FZ");

    for (int TgmaxaXMoI = 1248155865; TgmaxaXMoI > 0; TgmaxaXMoI--) {
        vZqsHUgil = vZqsHUgil;
    }

    for (int wTBDtvLEx = 829472468; wTBDtvLEx > 0; wTBDtvLEx--) {
        vZqsHUgil = gceeyx;
    }

    for (int wdZIlXvmmCM = 1426505926; wdZIlXvmmCM > 0; wdZIlXvmmCM--) {
        gceeyx *= gceeyx;
    }

    return YazLpXFzfwZO;
}

void HxqFUuHmanvq::uIcIYeB(double JWNXAKJVvZa, bool LfdVuFghdFpd, double fDTRawyVQ, int VoznaIRKIdQqFk, bool eJknRGIlle)
{
    string DhWWYy = string("UYjKkTFcDZlCHdFcHXrgWKohEvvrUkcwDfNahrVDtGlrzYEVsCwCDUJALhiyJpxoaFIIqbvczavMoysmupdqaQAYQuFBzIPMbinKamuCVMQjVJHjYJ");
    bool irpKOpVCpIvNYKK = false;

    if (LfdVuFghdFpd == false) {
        for (int sIOKKkrJMCl = 558770003; sIOKKkrJMCl > 0; sIOKKkrJMCl--) {
            continue;
        }
    }
}

HxqFUuHmanvq::HxqFUuHmanvq()
{
    this->GnGIGqPjcHY(642591.9208223791, -1098114297);
    this->ItbAKKLo(string("dnBURRlhhnWssPDbJLjdWwRiXYnRTgDnjpvgHPYUOPMihcgiVYDvGFjnbgbjfKtVAYMZptLMNPLQCnEttyEuEwiWNqKISdRvwqzjHWeMVpGIRyDzYxbJEiYYopxMuUrtlXMCUevKPIlshbOjELvNf"), 934200.3883542385, -266670.4522464182, string("jirTgjbXozwxOVCAsKjFqEpwCjojkpbfvYuLHTAHukvyInOtPVZwTrSoqRznbJOKpKSmQIOdUdidODTVxJleEXgwiNnDYQBJDDrjvIwHnbPDfLRHbKqxMvCZEyFUisRpHngbvVdtLUdWrqXDYOylMlfoGRzhzLpuEvqQeIMCYoNXiqUgeMQWCkgusTNR"), 82913778);
    this->UdfUbcuxxGCIZpJ(249984125);
    this->RmvsQqQGWu(string("kTHbRbJTlKnzEbaXvEzBfyEsLQOVgKwmNunWletIWdsxRNFzFUBHaZrxVUqUrCAkmSoVnzoxFHofKReXzDHKNdWxcDFahzokFqEBcdbdAEBXWfWtGGzUcPAFdTWCaKKwfvdBrnAjEtzrLrrVHuGFnXNfNhddAWteSWKKmICIEAwIgOwzuaRZjxbocofWOzabZRHDEFVfaJuucopIXIIDJbLdALGnFyNQxvVdZdfsdMwoaKnFZGYcjSDtjt"), true, -1659624009, -136920.0252108216);
    this->XvrorRObzrMz(-1217877585, -365305.0115382328);
    this->ntcFPH(false);
    this->zBSXdQTOgZvfFV(true, string("EKpIrCyXEZJYwHyzWoFEhzegIiIOKpcXxdEdSWQIYovlEDmZgSrTjwpBPzkKZthOQbWBPDYIgZXnWmEVmsBVlsJqBuYartjTOkdgbhdKFvIFzOAcvpWrivSvObBdtjFAYkSEfRhfcwNTtZJzmxSYYlRlEzHHPkqF"), string("gnPybyzSPyENblnLRgfSxTvZNUnncRVFkJVPEuwsshgkLHSrDSutRRYUmasDickcvLgvpOTbdumpWQkAWAAdPWvKrfkOjMceEspCgDqUOclhNXveTnrXbrwUPncTJoVUHSyWHEJuTGYSVBeToeHQxVMGEApFETbJrlfufIMQOEJiOlhLvDtvRZkzFF"), -1166928574, 883194926);
    this->VjLPFwNYjnAAtl(string("cErPPhfUMwHCPmWmtqaWlVEGqKWdpUhlwoUlAiehsOxjGDGWKBkuj"), 406869.993247999, -1324468946);
    this->OQPYhPJmlLMvc(string("iABjCjdhKUNTiuLHnGSQYypDciJZrMnSwgLaVeYzPWYwRrkOxyStQzMqnmcJSGKxJpKjotxBSaxpQjbAqVxqeChNpWEnKoCNEcDKffWoywoyxSuHOqpKWUzZBwRnCTHxYWgvqxkfzBTTxhHbVqvBcFbofDUvgn"), false, true, -415394.9244752727, -932625.4342724686);
    this->GugagEpEPAMNRDW(-284870277, false, 1508439806, false, -318461.92505244224);
    this->uIcIYeB(-185011.4186609157, true, -268188.48849890695, -923055919, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JJdvXHyyJlVxaKU
{
public:
    bool MTwAoDyLIj;

    JJdvXHyyJlVxaKU();
    void SdPGkSbHKMetQ(bool YhNGaSafygDj, double YFvXPSsSpImwHL, int dfPhCTgnUdlh);
    void fqkNiiPRFgMadIxI(int xmMDcqhBPOZVLLpq, bool GozpMQ, bool YNZqVdrLjkD, int hlFCZlIjQWSdP);
    bool tMOPgYJBNidKom(int tOPfzGQXDA, double xPRatLc);
    bool CAKBCLGLBzg(bool CaWXjnNNuOhjhMT, double QWjlreFzX, bool OUdIyppqxI);
    int XrXtFPhutmeRpQ(double BExjm, bool LvomgFfQkabZ);
    bool YSkGYKLAG(bool jOWxqCOnsUi, double RSIBFDLsSfEdQ);
    string NhHJDVszoQUYBui(int DoRIKvlHaEJsu, bool qXiRXdovjo, int OXmqLuvmQs, bool nTOaM);
protected:
    string nryKrtNZKKf;

private:
    double bFUTvCtzZvAlml;
    double nHxaK;
    bool BTzPsjbkTr;

};

void JJdvXHyyJlVxaKU::SdPGkSbHKMetQ(bool YhNGaSafygDj, double YFvXPSsSpImwHL, int dfPhCTgnUdlh)
{
    bool lFxRT = false;
    double wquka = -396197.67761154845;
    int loAjEXKALttd = 77186539;
    string TXvdhBfEEGjR = string("oTWivLekrUowyUnODMLBxL");
    string FQSnbCjraOrZqM = string("AdbDCAyWYhcKyOTsrSafViiSdocMoEyqznqXUwjFtjBWhExmYydnpNftjvmuSuYlSsRtJiSTcDcsnmLWpiellyLjWyvlTINkPpClujZFjrZhdlAsAvmJYMCoQuuCnfCyiXSKwQuimmCAguGObDDFlsjvHylgySkLhXINJLLStvmFUWqIYVPYZcPLIvPmPxCFRcTQczqIOPKJhYfOnphDtLDiGEJwmkbBbqtQQWKFgvPNtUHS");
    int DiDxYPxCcB = -1827029351;
    double iFNwLNNkxp = -532524.913390486;
    double tzKTnooIPkNAmC = 841280.4800008516;

    for (int MOUdKlh = 613988232; MOUdKlh > 0; MOUdKlh--) {
        YhNGaSafygDj = YhNGaSafygDj;
        tzKTnooIPkNAmC *= wquka;
        loAjEXKALttd += DiDxYPxCcB;
        YFvXPSsSpImwHL = tzKTnooIPkNAmC;
    }
}

void JJdvXHyyJlVxaKU::fqkNiiPRFgMadIxI(int xmMDcqhBPOZVLLpq, bool GozpMQ, bool YNZqVdrLjkD, int hlFCZlIjQWSdP)
{
    double JhCOQojjdeIFV = 250279.18954377712;
    int IYoMmAgwCSFmngxO = -300202279;
    string NfBOCjiGPjmlUS = string("IWckbSscHCfhyXydzZXNwItSZMXDlIFHZhagclKHnazxDonQYEmhxHKhhAJLwutqcEqXNwcGAYBCnuJAHIujVECwrcMJfzHeXNEEdmdOJzSMtmEmLNYMQsycVoizswhAtELkHXNrJHxZQAYRBiDyuQrczwpoNBxTaLkAHPxyGkQunjitvQuQovNzrLRHRQGOXtniaFuVMGcqKJglLmNQyGjQPFyjEkTrasTYJmVzbnVwMesgEP");

    for (int PRnwECJq = 920073734; PRnwECJq > 0; PRnwECJq--) {
        IYoMmAgwCSFmngxO -= xmMDcqhBPOZVLLpq;
        hlFCZlIjQWSdP -= IYoMmAgwCSFmngxO;
    }

    for (int szGtvaouxu = 637277319; szGtvaouxu > 0; szGtvaouxu--) {
        hlFCZlIjQWSdP += hlFCZlIjQWSdP;
    }

    for (int sAUdVGnHnr = 1625610294; sAUdVGnHnr > 0; sAUdVGnHnr--) {
        IYoMmAgwCSFmngxO += xmMDcqhBPOZVLLpq;
        hlFCZlIjQWSdP *= hlFCZlIjQWSdP;
    }

    for (int OZVdUH = 887495380; OZVdUH > 0; OZVdUH--) {
        YNZqVdrLjkD = YNZqVdrLjkD;
    }
}

bool JJdvXHyyJlVxaKU::tMOPgYJBNidKom(int tOPfzGQXDA, double xPRatLc)
{
    double eUdkjdp = -418854.38645903004;
    int CEhFAuMEzMjxMK = -497440834;

    if (eUdkjdp > -418854.38645903004) {
        for (int SHnmVKQjrkt = 1634694653; SHnmVKQjrkt > 0; SHnmVKQjrkt--) {
            tOPfzGQXDA += CEhFAuMEzMjxMK;
            tOPfzGQXDA -= tOPfzGQXDA;
            eUdkjdp = eUdkjdp;
            xPRatLc /= eUdkjdp;
        }
    }

    if (CEhFAuMEzMjxMK == -1221222373) {
        for (int uRFySmxBm = 1766202975; uRFySmxBm > 0; uRFySmxBm--) {
            xPRatLc += eUdkjdp;
            CEhFAuMEzMjxMK = tOPfzGQXDA;
            CEhFAuMEzMjxMK /= tOPfzGQXDA;
        }
    }

    for (int noJnNyYt = 926636772; noJnNyYt > 0; noJnNyYt--) {
        xPRatLc -= xPRatLc;
        eUdkjdp -= xPRatLc;
    }

    if (CEhFAuMEzMjxMK > -1221222373) {
        for (int LviDklrMiftJ = 349276551; LviDklrMiftJ > 0; LviDklrMiftJ--) {
            eUdkjdp = eUdkjdp;
            tOPfzGQXDA = tOPfzGQXDA;
            CEhFAuMEzMjxMK += CEhFAuMEzMjxMK;
            CEhFAuMEzMjxMK -= tOPfzGQXDA;
            tOPfzGQXDA *= tOPfzGQXDA;
            eUdkjdp += eUdkjdp;
            CEhFAuMEzMjxMK /= CEhFAuMEzMjxMK;
        }
    }

    for (int aTvTFnFZFRAOz = 1864813839; aTvTFnFZFRAOz > 0; aTvTFnFZFRAOz--) {
        tOPfzGQXDA += tOPfzGQXDA;
        CEhFAuMEzMjxMK *= tOPfzGQXDA;
        xPRatLc = eUdkjdp;
        tOPfzGQXDA *= CEhFAuMEzMjxMK;
        tOPfzGQXDA /= CEhFAuMEzMjxMK;
        xPRatLc = eUdkjdp;
    }

    return true;
}

bool JJdvXHyyJlVxaKU::CAKBCLGLBzg(bool CaWXjnNNuOhjhMT, double QWjlreFzX, bool OUdIyppqxI)
{
    string RHZcdDHAovX = string("YvOZnzgZQYAdsIOMAwPKrcIDLAUJeYKfsQXqQUeSLQoqLYGdGhCwgvxonlaxcuZgrADDclEbTZhpQeLRQgDAOdKZlXWazDGRrHQMMMmTqUGpNVXebSFyaGbIHJfKKBjSnlWLNNGZltUxpTFpiGrRVnGoSBkKoWARSmWltbjvCgPFGffdQSiGAoIsEjsuQMmZUEPFbYnRoGY");
    bool YChmdYgMVy = true;

    for (int aBUjDubxPMnPfgw = 624994770; aBUjDubxPMnPfgw > 0; aBUjDubxPMnPfgw--) {
        OUdIyppqxI = ! CaWXjnNNuOhjhMT;
    }

    for (int tFsFsze = 1476471344; tFsFsze > 0; tFsFsze--) {
        YChmdYgMVy = ! YChmdYgMVy;
    }

    for (int cqnyLwZaDH = 322952329; cqnyLwZaDH > 0; cqnyLwZaDH--) {
        YChmdYgMVy = ! YChmdYgMVy;
        CaWXjnNNuOhjhMT = ! OUdIyppqxI;
    }

    if (YChmdYgMVy != true) {
        for (int VvzljhDlpnAjgi = 451651747; VvzljhDlpnAjgi > 0; VvzljhDlpnAjgi--) {
            YChmdYgMVy = OUdIyppqxI;
            CaWXjnNNuOhjhMT = CaWXjnNNuOhjhMT;
        }
    }

    for (int AXQQtBt = 963192119; AXQQtBt > 0; AXQQtBt--) {
        YChmdYgMVy = ! YChmdYgMVy;
        YChmdYgMVy = OUdIyppqxI;
        QWjlreFzX += QWjlreFzX;
        YChmdYgMVy = ! YChmdYgMVy;
    }

    if (RHZcdDHAovX < string("YvOZnzgZQYAdsIOMAwPKrcIDLAUJeYKfsQXqQUeSLQoqLYGdGhCwgvxonlaxcuZgrADDclEbTZhpQeLRQgDAOdKZlXWazDGRrHQMMMmTqUGpNVXebSFyaGbIHJfKKBjSnlWLNNGZltUxpTFpiGrRVnGoSBkKoWARSmWltbjvCgPFGffdQSiGAoIsEjsuQMmZUEPFbYnRoGY")) {
        for (int zTKsQMNBZVlUVXF = 362892355; zTKsQMNBZVlUVXF > 0; zTKsQMNBZVlUVXF--) {
            YChmdYgMVy = ! OUdIyppqxI;
        }
    }

    if (OUdIyppqxI == true) {
        for (int twiLThHAGoS = 2120557843; twiLThHAGoS > 0; twiLThHAGoS--) {
            QWjlreFzX *= QWjlreFzX;
            OUdIyppqxI = ! OUdIyppqxI;
            YChmdYgMVy = CaWXjnNNuOhjhMT;
            QWjlreFzX /= QWjlreFzX;
            CaWXjnNNuOhjhMT = ! CaWXjnNNuOhjhMT;
        }
    }

    for (int EKviLDILNztK = 1549724982; EKviLDILNztK > 0; EKviLDILNztK--) {
        YChmdYgMVy = ! CaWXjnNNuOhjhMT;
        YChmdYgMVy = ! CaWXjnNNuOhjhMT;
    }

    for (int NmvoprWIad = 1501961822; NmvoprWIad > 0; NmvoprWIad--) {
        OUdIyppqxI = ! OUdIyppqxI;
        OUdIyppqxI = ! CaWXjnNNuOhjhMT;
    }

    for (int EHDHya = 1457151397; EHDHya > 0; EHDHya--) {
        OUdIyppqxI = CaWXjnNNuOhjhMT;
    }

    return YChmdYgMVy;
}

int JJdvXHyyJlVxaKU::XrXtFPhutmeRpQ(double BExjm, bool LvomgFfQkabZ)
{
    int nuANSqmk = -597627443;
    string WeqFrNzUdfghLCcU = string("zSwkIPFieUEJpBbuQmbOGmnwAwfGQliGSFVHkLaKItWqHkCeuDlXQmHSw");
    int tHtSNSa = 1201381495;
    string uHYDZzAWFNVy = string("GcRcskhhcBfVm");
    string MwdENzHqTUXJTiEG = string("tBmjAQowDFKOjiXpowbGeVBTcjhPvsCiWTLMHdhKFDPVzUPMrWznjRrYrAhsSOJUsCAlZXTrQAlRMFcoeyWjWyydtWANknNfLuGLGwCBFeNaZJGnaeTbvwxeamNOIhUmZctwtGGOEBnEVKgPGZuwXLY");
    string SDMHguRIHnM = string("GxeEJCKAilTrZPCZwNFcvEAAadOUlLPwVTxEjU");

    if (WeqFrNzUdfghLCcU >= string("tBmjAQowDFKOjiXpowbGeVBTcjhPvsCiWTLMHdhKFDPVzUPMrWznjRrYrAhsSOJUsCAlZXTrQAlRMFcoeyWjWyydtWANknNfLuGLGwCBFeNaZJGnaeTbvwxeamNOIhUmZctwtGGOEBnEVKgPGZuwXLY")) {
        for (int tvbkogLjE = 491117126; tvbkogLjE > 0; tvbkogLjE--) {
            MwdENzHqTUXJTiEG = MwdENzHqTUXJTiEG;
            nuANSqmk += nuANSqmk;
        }
    }

    return tHtSNSa;
}

bool JJdvXHyyJlVxaKU::YSkGYKLAG(bool jOWxqCOnsUi, double RSIBFDLsSfEdQ)
{
    string OUMiKCRrFZFjVZ = string("XoRKKTzIvQebzzAKuicomCiIEcsHJNQyZxHgyAcHapvYBbUsgKEGGTIYfzuhrdROyvkxMtCnysBrYpAqHqtnkTYvAYNFrmjSXNsDqpHIyshFRcIHhVkXDAWaAXXgcnwNrWbBaDnRgtTTklDytFtBgiWnaGnYuXJMrr");
    string XCnTwJoJ = string("RaHVApOyDLuxSopTBkvTBzIJNsyMMkFpNpFftOapHhCsgZltBHGxyPWcrnsiLlshAQjBStUzEhJeMHEIPIkLSGVOGPzaRHTgZZPTDrcfaMEYzKcZribuzaQRfNiWqTeeDHVtaTaRvsbxWbMHJAbAyoTAtczQoRnfhSolfKaHSkKdbROpoYTKIdhBZPsiSTOiZnxZuSYehTMAQuVHOcEEWiMLXSwGvYLrVmafmkylvxxqXnMuZsQELeUjjgvpUWR");
    bool PJPKAMFbiaNi = true;
    int LnKJLPhF = -2086674584;
    double oHdEuatoqyKyrPeQ = -27021.349508551382;
    string yzvcUGkh = string("OtWhuqCkaVGGaVHcvQUUCkMWrmGjKiinvbqzmBCImwRBeXqozRBYhwaDfRAjDURvvTGJiuadiwpRFUgDLmvYgVJJbIYzHnsGbCNxwgSIryxMnkDhTbuTLuhcKFwnuvEDnNBVOFkgjjFMBUrEGZpCASdHaedrSMMYvoaZAiPnispKGdzIvmKgHegNrIpJgUNmocVzxFidQpF");
    string UeIhNSDuNiII = string("aiHTRLescDvNYGIshyfXvnnvHkVjZqHDXyBYjwhGMCbtYRVijnqMkfShRdVtqjMWfjfEjujEjERyvwPeANJEOizVMddOdXrfqfnvXLLPfHIYjkyfzSDZgyAXChhShZYZDsBMIUmmUGlIzTuOiUeFnVSxcYiFgiBCQJ");
    double EJKWMeaBruCNEfAQ = -176286.64455280695;

    for (int bNFKnmgnkjanzKq = 257076347; bNFKnmgnkjanzKq > 0; bNFKnmgnkjanzKq--) {
        continue;
    }

    for (int jrFNZWn = 628383795; jrFNZWn > 0; jrFNZWn--) {
        oHdEuatoqyKyrPeQ /= RSIBFDLsSfEdQ;
    }

    return PJPKAMFbiaNi;
}

string JJdvXHyyJlVxaKU::NhHJDVszoQUYBui(int DoRIKvlHaEJsu, bool qXiRXdovjo, int OXmqLuvmQs, bool nTOaM)
{
    string xREoivFUzzde = string("ReCbnrDcDZBWhgOBwddoAlEpjavqhFxNxbEGRDoraQrrGMzmPUnzlslLrpISCBqRodrZfYTSirzgxPRovRZSiCPHyZtPwYbHqUKxqeKPolvuuQwAUHMQYLXkbpYJZWmUMLtuNPHjbLVFNmCYRyGHzmzpCNHoUXuTeQDPOrlbOXFPKLzLalTLnqxONEETBUpUReFcCDJyZwLajYSAYtoCBdVfaEdcXcgnRIjTDvrOZGRWM");
    int TuanAsjuSIpli = -828069905;
    bool lScnYhfMSbQVdNB = true;
    int CJIfGFDhDiI = -89695979;
    bool DyHydcY = true;

    for (int RchwpXqPs = 127335193; RchwpXqPs > 0; RchwpXqPs--) {
        OXmqLuvmQs *= TuanAsjuSIpli;
        DoRIKvlHaEJsu /= OXmqLuvmQs;
        nTOaM = ! nTOaM;
    }

    for (int CMuOYU = 195873762; CMuOYU > 0; CMuOYU--) {
        qXiRXdovjo = lScnYhfMSbQVdNB;
        TuanAsjuSIpli *= OXmqLuvmQs;
        DoRIKvlHaEJsu += DoRIKvlHaEJsu;
    }

    if (nTOaM != false) {
        for (int cHabh = 125980312; cHabh > 0; cHabh--) {
            CJIfGFDhDiI -= CJIfGFDhDiI;
            DyHydcY = ! qXiRXdovjo;
            OXmqLuvmQs = CJIfGFDhDiI;
        }
    }

    for (int EbTiTHDLBlPT = 1655793910; EbTiTHDLBlPT > 0; EbTiTHDLBlPT--) {
        CJIfGFDhDiI -= OXmqLuvmQs;
    }

    for (int ihFBi = 1119931727; ihFBi > 0; ihFBi--) {
        DyHydcY = nTOaM;
        DyHydcY = lScnYhfMSbQVdNB;
        qXiRXdovjo = ! DyHydcY;
    }

    return xREoivFUzzde;
}

JJdvXHyyJlVxaKU::JJdvXHyyJlVxaKU()
{
    this->SdPGkSbHKMetQ(false, 979105.6775210962, 1148913648);
    this->fqkNiiPRFgMadIxI(695304945, true, false, -1711439039);
    this->tMOPgYJBNidKom(-1221222373, 925868.2736495489);
    this->CAKBCLGLBzg(true, 908715.5669897011, false);
    this->XrXtFPhutmeRpQ(539956.8437149584, true);
    this->YSkGYKLAG(true, 623747.6507090172);
    this->NhHJDVszoQUYBui(124059842, false, -1455034259, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LfHmhNRnIw
{
public:
    double dMKAtQ;
    bool TVnMAut;

    LfHmhNRnIw();
    void onGZwQhM(bool KnBUVlV, string YDEXujwvoIa);
    bool SFpWReqF(bool yEHHIcdFqBhGsmK, int YBnFuZxlNKdIaJkX, double Hilao, bool XjLVZXsAEUGPGU, double WlMss);
    string NBpQTGVnCUUB(double owpvAekeRtx, double LUgegru, string dFQiKBleWGo);
    bool AUTiQaGqFSFU(bool SNwWoZgEOAmMggL);
    double aJSHMALMgI(string ggUJuxXpXC, double gkOqVy);
    int Kpbkp(bool zeByumZOz, bool sFTeVDjbrFJunT);
    double UnIgBS(string WxWfySBOTJ, double ddjgLugxpZUvweJL, string eToNRNwogDp);
    void fwzOMXFkfADaTHL(bool QMqHqAEdh, double sFHlimWPTXviYVAI, int tSnfTYEYQIeL);
protected:
    int AimbpbYrdFKkfqsL;

    double oFaoDYQh(bool wIKFL);
    bool HFBnGBPzzwcpr();
    string WiTvqPBpjiumJ(int QJTDbBxSJGhcd, int XtxDfzTiJNVWQQ, string OIPJAnTUPTYV, double WkZSdiQphE, double UcMcOWCDE);
    bool HfkvmYnqINHeKTMx();
    double vqFcuCzuzYvXVbo(int ssfSdgpJSgWpCrPT, double siwcaUBsMf);
    void oNBflMSvuyEeyp(string BvvYBX, int UMwxiFEQwTpEM, int IizoDLkpXG, bool mQIsgONKT, double WHkIZcJVCpeu);
private:
    string hZdad;
    bool CmvSANYsHtLX;
    double odaWB;

    int CurRTeCsbCOXQkjJ();
    bool gDUbeq(double FwnXhowhiYtCm, int PAoTRSgdXzx, int TYmAgPhHFU);
    bool KHLFHTWNzLxn(int aVHyEY, double PAXbDajyYjYNeZ);
    string VVzCVIj(bool bCjDHeWrxhhUeeax);
    int CHnTv(string MFsJAB, bool FaBDGP, string umIvwIHd, double pwrEwFmuVFEwBhy);
    double fsgBbuzFEoJVgen(bool UtMCItro, string MbsIMZRS, string YTLLI);
    double tXsBRlCFLsW(double HLitpeLses, int BXnFqvbmplw, string bdAkHFEXCrZ, int SGWQsPzIA, string NsjfHHFXFShfrr);
};

void LfHmhNRnIw::onGZwQhM(bool KnBUVlV, string YDEXujwvoIa)
{
    double CHiriHYGieQGsmR = 283373.2089011425;
    int aCHXxiDelmMKl = 1652727060;
    double rYPJf = 175010.86006424876;
    int eLfOretCBVYYpfP = -2059313345;
    int DHQhDCmHAyiFeipz = 2138073764;
    double yqNPl = 665446.7509002654;
    double phmaOE = 327406.52045726223;

    if (yqNPl != 283373.2089011425) {
        for (int zMKHiIZAM = 2107274680; zMKHiIZAM > 0; zMKHiIZAM--) {
            rYPJf = yqNPl;
            rYPJf /= CHiriHYGieQGsmR;
            rYPJf += yqNPl;
        }
    }

    for (int AqCjAGbbgmMjHSu = 947149520; AqCjAGbbgmMjHSu > 0; AqCjAGbbgmMjHSu--) {
        aCHXxiDelmMKl += eLfOretCBVYYpfP;
        rYPJf *= phmaOE;
        yqNPl /= CHiriHYGieQGsmR;
    }
}

bool LfHmhNRnIw::SFpWReqF(bool yEHHIcdFqBhGsmK, int YBnFuZxlNKdIaJkX, double Hilao, bool XjLVZXsAEUGPGU, double WlMss)
{
    string ZsvkRXVXhCsoLUyP = string("XcSVugSSGRIonhbCuyackwEZJcJVThzA");

    for (int egiLi = 926516063; egiLi > 0; egiLi--) {
        yEHHIcdFqBhGsmK = ! XjLVZXsAEUGPGU;
        WlMss /= WlMss;
        ZsvkRXVXhCsoLUyP = ZsvkRXVXhCsoLUyP;
    }

    for (int ZgVXUboKcxdSnsRj = 341220492; ZgVXUboKcxdSnsRj > 0; ZgVXUboKcxdSnsRj--) {
        Hilao -= Hilao;
        YBnFuZxlNKdIaJkX = YBnFuZxlNKdIaJkX;
        XjLVZXsAEUGPGU = ! XjLVZXsAEUGPGU;
        Hilao = WlMss;
        WlMss /= Hilao;
    }

    if (Hilao >= -105499.73068966504) {
        for (int aWUKcV = 1866280193; aWUKcV > 0; aWUKcV--) {
            yEHHIcdFqBhGsmK = XjLVZXsAEUGPGU;
        }
    }

    for (int rTkcF = 1830196360; rTkcF > 0; rTkcF--) {
        yEHHIcdFqBhGsmK = XjLVZXsAEUGPGU;
    }

    return XjLVZXsAEUGPGU;
}

string LfHmhNRnIw::NBpQTGVnCUUB(double owpvAekeRtx, double LUgegru, string dFQiKBleWGo)
{
    int dIuqdhbVlKITDLGf = 2054652308;
    int xJShxGxm = 2053343236;

    if (owpvAekeRtx <= -235258.1313656546) {
        for (int rdtwCetw = 1842634223; rdtwCetw > 0; rdtwCetw--) {
            dIuqdhbVlKITDLGf /= dIuqdhbVlKITDLGf;
            dIuqdhbVlKITDLGf = xJShxGxm;
            dIuqdhbVlKITDLGf += dIuqdhbVlKITDLGf;
            dFQiKBleWGo += dFQiKBleWGo;
            dIuqdhbVlKITDLGf *= dIuqdhbVlKITDLGf;
            dIuqdhbVlKITDLGf = xJShxGxm;
        }
    }

    return dFQiKBleWGo;
}

bool LfHmhNRnIw::AUTiQaGqFSFU(bool SNwWoZgEOAmMggL)
{
    int aBmsAAsj = -1140757732;
    bool wXwVDWbOkX = true;

    for (int nTgmxwOMMnqMs = 1604905325; nTgmxwOMMnqMs > 0; nTgmxwOMMnqMs--) {
        wXwVDWbOkX = ! SNwWoZgEOAmMggL;
        SNwWoZgEOAmMggL = wXwVDWbOkX;
        wXwVDWbOkX = wXwVDWbOkX;
    }

    for (int OzneTKaEcrLo = 382968347; OzneTKaEcrLo > 0; OzneTKaEcrLo--) {
        SNwWoZgEOAmMggL = wXwVDWbOkX;
        SNwWoZgEOAmMggL = wXwVDWbOkX;
    }

    for (int BmsqoUeCLs = 1454300954; BmsqoUeCLs > 0; BmsqoUeCLs--) {
        aBmsAAsj += aBmsAAsj;
        aBmsAAsj *= aBmsAAsj;
        wXwVDWbOkX = SNwWoZgEOAmMggL;
    }

    return wXwVDWbOkX;
}

double LfHmhNRnIw::aJSHMALMgI(string ggUJuxXpXC, double gkOqVy)
{
    double fUOvhHmf = 595741.0909753068;

    if (gkOqVy == -263182.59450989874) {
        for (int JcIxQmUdDBRem = 642568099; JcIxQmUdDBRem > 0; JcIxQmUdDBRem--) {
            gkOqVy -= gkOqVy;
            gkOqVy = gkOqVy;
            ggUJuxXpXC += ggUJuxXpXC;
        }
    }

    if (gkOqVy >= 595741.0909753068) {
        for (int spdncIupXq = 1604817269; spdncIupXq > 0; spdncIupXq--) {
            fUOvhHmf -= fUOvhHmf;
            gkOqVy += gkOqVy;
        }
    }

    if (ggUJuxXpXC <= string("RzfSLhNqpdSPgFGWGcVDHQtMAKzwEGkrFongHCMxSPGtOvSvugasKGvNCFsVIsGE")) {
        for (int dlvuSriNnkX = 2050150792; dlvuSriNnkX > 0; dlvuSriNnkX--) {
            ggUJuxXpXC = ggUJuxXpXC;
            fUOvhHmf *= fUOvhHmf;
            ggUJuxXpXC += ggUJuxXpXC;
            gkOqVy += fUOvhHmf;
            gkOqVy *= gkOqVy;
        }
    }

    for (int XsDaCIP = 1988528364; XsDaCIP > 0; XsDaCIP--) {
        ggUJuxXpXC = ggUJuxXpXC;
    }

    return fUOvhHmf;
}

int LfHmhNRnIw::Kpbkp(bool zeByumZOz, bool sFTeVDjbrFJunT)
{
    string axtaSaDpKF = string("sYMbhNcRskgvviEXRBLAaEinQVaqOSpjkQTseCZSBowrQFIzyGobzzlQhcFo");
    bool NjVzLnB = false;
    int CCwXuSWKVOHJVjL = -844624585;
    int Omoli = 535593454;
    double BuUIIhMluGEXZNZF = -579663.4250726177;

    for (int OOkCyHK = 1565739413; OOkCyHK > 0; OOkCyHK--) {
        continue;
    }

    for (int vApbnxBBE = 2057562120; vApbnxBBE > 0; vApbnxBBE--) {
        CCwXuSWKVOHJVjL *= CCwXuSWKVOHJVjL;
        NjVzLnB = NjVzLnB;
        CCwXuSWKVOHJVjL *= CCwXuSWKVOHJVjL;
    }

    for (int cxbOvxhbaOuqgTMH = 2036084638; cxbOvxhbaOuqgTMH > 0; cxbOvxhbaOuqgTMH--) {
        NjVzLnB = NjVzLnB;
        CCwXuSWKVOHJVjL += CCwXuSWKVOHJVjL;
    }

    return Omoli;
}

double LfHmhNRnIw::UnIgBS(string WxWfySBOTJ, double ddjgLugxpZUvweJL, string eToNRNwogDp)
{
    double CIqobez = -774765.5705327361;
    string QIbuOfC = string("MmtguvZGhTAIaPesePDqhajkwWvAgAqevFDcdpQFUVMcPvnrlWoSDINFYpRpVDvOTR");
    string aZFEo = string("tVzrtAZYPDlwMbFKOERoUmotqKxMxbyeMQFBqoscBXQhIXwlukeXOXiCvZzePhkXvSAFPyROCoFWwtbmuFLeyvgdfnwkxBlGsoahekgDhwBPzirmeRELMMVvZjTdyugdFaKAmEdmwTPurHkvgdrmwoNRolUUtMWxgdlfEWHIVsbytqBDnWSjGmxmBEOzc");
    string PVGkBkmDVXXIDMRr = string("LhUeCNlEBqQKVfoTLiTMvpcjIfTYQTVtfNTYMETMmbLpfkor");
    int UsajJFE = 1246245973;
    int OGVgtKVWxWTZQe = -524910089;
    string zzORdFtsrMkU = string("jVTKkNDvYNXShxdNPLaONrnQoCygmgJgZdtZsxpqwnhjeWRYxUFYCtfIkOSquehQodGPbSQOKvKcIRtebwHDlseOb");
    int SdtoToZSx = 258282387;
    bool UGjmETNTvdhPlm = true;
    double HaHhGCyrbqjzZG = 237096.37935140857;

    for (int PWJrfIbRV = 1674107801; PWJrfIbRV > 0; PWJrfIbRV--) {
        UsajJFE /= SdtoToZSx;
        CIqobez /= ddjgLugxpZUvweJL;
        zzORdFtsrMkU += eToNRNwogDp;
    }

    if (eToNRNwogDp <= string("tVzrtAZYPDlwMbFKOERoUmotqKxMxbyeMQFBqoscBXQhIXwlukeXOXiCvZzePhkXvSAFPyROCoFWwtbmuFLeyvgdfnwkxBlGsoahekgDhwBPzirmeRELMMVvZjTdyugdFaKAmEdmwTPurHkvgdrmwoNRolUUtMWxgdlfEWHIVsbytqBDnWSjGmxmBEOzc")) {
        for (int dJDJgXv = 443558259; dJDJgXv > 0; dJDJgXv--) {
            CIqobez += HaHhGCyrbqjzZG;
        }
    }

    for (int GCYAFuWBHpsZtvu = 1154173899; GCYAFuWBHpsZtvu > 0; GCYAFuWBHpsZtvu--) {
        zzORdFtsrMkU += QIbuOfC;
    }

    for (int yMBLha = 1541530156; yMBLha > 0; yMBLha--) {
        zzORdFtsrMkU += eToNRNwogDp;
    }

    for (int BeliJCZNET = 1889981259; BeliJCZNET > 0; BeliJCZNET--) {
        WxWfySBOTJ += zzORdFtsrMkU;
    }

    return HaHhGCyrbqjzZG;
}

void LfHmhNRnIw::fwzOMXFkfADaTHL(bool QMqHqAEdh, double sFHlimWPTXviYVAI, int tSnfTYEYQIeL)
{
    string lxdEh = string("upQeXBSPurAHHqrfhOAzfYKgsUasnyPaiuDfEZbTXPneviMwTmWhmbjaIbzfntFHwlHutWTtFDTZrTEVmY");
    string UHFxGVpFjdVghRS = string("QeJqyRhqquZKHqxyEqBrspjCVewMUQumFkUscpPLOHoiaSlhreAWjOXgFWoiozUNyHwWQOOlLXhiltrKaoyFZMMcgPIzxmnEEYpoJsOZlaFoEyVkTlvxigKacPCqoJqwrHDJzsDcuDclcvIKoOnoYCytMXHZEIjBCqjXMSAWHmXfbhRFXXezWVOiphMlnS");
    int arwsRlpjMfZmLq = 1179530298;
    bool aSmwztDmWxznrJ = true;
    int mQiZyeRLpZTz = -749277291;
    bool nlOWHgnEwpoYGXF = false;
    double klUdr = -359375.3171383425;

    for (int iRzlTqILJwhPHmg = 1046863497; iRzlTqILJwhPHmg > 0; iRzlTqILJwhPHmg--) {
        lxdEh = UHFxGVpFjdVghRS;
        mQiZyeRLpZTz = arwsRlpjMfZmLq;
        QMqHqAEdh = aSmwztDmWxznrJ;
        aSmwztDmWxznrJ = ! nlOWHgnEwpoYGXF;
    }

    for (int EConkMNWz = 2113299061; EConkMNWz > 0; EConkMNWz--) {
        continue;
    }

    for (int fHBAPWXk = 660658365; fHBAPWXk > 0; fHBAPWXk--) {
        sFHlimWPTXviYVAI *= sFHlimWPTXviYVAI;
        QMqHqAEdh = aSmwztDmWxznrJ;
        lxdEh = UHFxGVpFjdVghRS;
    }

    for (int fbaYKdphU = 1366020571; fbaYKdphU > 0; fbaYKdphU--) {
        UHFxGVpFjdVghRS += lxdEh;
    }
}

double LfHmhNRnIw::oFaoDYQh(bool wIKFL)
{
    double hEcube = -830744.2471388405;
    bool HHaehva = true;
    bool UkZDzYaxLPijNz = true;
    int XtaeXDTUghQjA = 1588011507;
    int NRSuzRt = 6781795;
    string cgQgNUh = string("bStnWzXxDbfRobwAEqPvxviKmIRegsrPQYKPxiPBvQiTZMlUyWPhCnZwPYLKLmnBdlMMpUPxxZgmwModPWPxbdZHZlNoYtEGcTjzodIdRWusJAtxHEmPTpGRfhez");
    double vodsnsjtXsqNCiW = -75612.856385881;

    for (int IUkMgRmMyzUq = 1162879964; IUkMgRmMyzUq > 0; IUkMgRmMyzUq--) {
        wIKFL = ! HHaehva;
    }

    return vodsnsjtXsqNCiW;
}

bool LfHmhNRnIw::HFBnGBPzzwcpr()
{
    int mLEoXY = 832662749;
    bool OACdPmgFJO = true;
    string qxVHq = string("PtBSiFvaMBndHkqJvQbCJPYGOUDhVQFtLgdXguAOSFWtkQBMGtTduwnAKbYgQsCijKOLHiHiTJWrwDikxrsTmMjudfNTKlbITzSdhiyxgbEXbuZlYuokaaSgriOUsdkoIJkcEjALGVWgicQHSKQOUGkE");
    bool eGjqzRL = true;
    int XNPYiqZaFDV = -1757606819;
    double RUTajDiKAxh = -1012898.9400233284;
    int dzlPiAbIKtwBvz = -1325739355;
    bool IZQHkSrP = true;

    for (int WBvNByMDZzAySJM = 1253564034; WBvNByMDZzAySJM > 0; WBvNByMDZzAySJM--) {
        IZQHkSrP = OACdPmgFJO;
        mLEoXY += mLEoXY;
        IZQHkSrP = ! OACdPmgFJO;
    }

    for (int HdkJivmr = 710145380; HdkJivmr > 0; HdkJivmr--) {
        IZQHkSrP = OACdPmgFJO;
        OACdPmgFJO = eGjqzRL;
    }

    if (eGjqzRL == true) {
        for (int pcjmlIVPwYOyt = 678177600; pcjmlIVPwYOyt > 0; pcjmlIVPwYOyt--) {
            IZQHkSrP = ! OACdPmgFJO;
        }
    }

    if (eGjqzRL != true) {
        for (int MyobmBsYFNgPLv = 234200911; MyobmBsYFNgPLv > 0; MyobmBsYFNgPLv--) {
            OACdPmgFJO = ! OACdPmgFJO;
            XNPYiqZaFDV /= XNPYiqZaFDV;
            OACdPmgFJO = eGjqzRL;
            IZQHkSrP = eGjqzRL;
        }
    }

    for (int oZcAUJn = 1894788599; oZcAUJn > 0; oZcAUJn--) {
        dzlPiAbIKtwBvz /= dzlPiAbIKtwBvz;
        IZQHkSrP = IZQHkSrP;
        IZQHkSrP = eGjqzRL;
        RUTajDiKAxh -= RUTajDiKAxh;
    }

    for (int JygqnLDzRtxMDYKF = 588045538; JygqnLDzRtxMDYKF > 0; JygqnLDzRtxMDYKF--) {
        continue;
    }

    return IZQHkSrP;
}

string LfHmhNRnIw::WiTvqPBpjiumJ(int QJTDbBxSJGhcd, int XtxDfzTiJNVWQQ, string OIPJAnTUPTYV, double WkZSdiQphE, double UcMcOWCDE)
{
    int kEjmEwGxvU = 910157187;
    int rFfSlZbU = -1816026473;
    string wQbwWdgesAlQMn = string("KlJLVGeuxrGLjNaHfwgBsripiaRVbtaBKoPVZCqksbggGyEUzBCAlDIjxeDcjGdnIUrzWpcyQVjeNlEDAAvHMydWfNjcbbDKzPzLPURdDWpeYoLvgqxpZKlTfblaYkgbTfceuSdqvDehrxKLtzorBnmSjZGYRBVstrwxuhZDjmipJKFREGfWi");
    string dePJNr = string("JwErJLmdsbGgbZRPaVBIOgOlqNzUlRkZQunFiUfMSUyJZrYXtaHuiZbAAiHTJqkqOzPiPPacZozXGdPQOUdeiXVbBeleHiyHsucWzedUTyaCSbuoMjsQAtIiJXkjcAGknHmOoBCkwMSnzOuAwqOzayYKUrUlsPRoVkACNufUNbkTUOTURtbjucVhJNkOSYidtgbebVgjFBqvSCCtFmKTqIfszORPMJKcmN");
    double LQBdobDTGi = -367848.8110865195;
    bool WJmOGa = true;
    string XDcMurjHG = string("SLRpPmEofeCidjrfhvYajgdrJbUMozmOHUxujhS");

    for (int VYWaQq = 1652367170; VYWaQq > 0; VYWaQq--) {
        UcMcOWCDE -= LQBdobDTGi;
        XtxDfzTiJNVWQQ -= kEjmEwGxvU;
        OIPJAnTUPTYV = dePJNr;
    }

    return XDcMurjHG;
}

bool LfHmhNRnIw::HfkvmYnqINHeKTMx()
{
    double IPHhorzVZNPymxkD = -924743.7990298338;
    bool YHlqneTxRleDp = true;
    string jZNDWRakPZlaolzL = string("stNBUKuIKZvxPAPVOITBVYelmGXmNognGqmiHCBcqaZhDGkZMceEgfLdsobPYbjz");
    string xExXImxDQbTlmxK = string("qhpVRvwVldKAmDvfeAdlQatpxAFysXQLFvPcebtvdlakTNcYmxFBZrAjEehmHaLaAbRMYZnB");
    string kvmelkPoyxYIqz = string("ZdlfFHmHMOmmlxlhHPLoJLPzwKLXLyYNItkTWtPXCauFDYazerD");
    bool bsVfccBMJpkhQfe = true;
    int okBdRL = 1589244559;
    double uFgVmQayF = -750926.0648994432;

    if (jZNDWRakPZlaolzL >= string("qhpVRvwVldKAmDvfeAdlQatpxAFysXQLFvPcebtvdlakTNcYmxFBZrAjEehmHaLaAbRMYZnB")) {
        for (int yKAiHsbqusaiWBrh = 809290973; yKAiHsbqusaiWBrh > 0; yKAiHsbqusaiWBrh--) {
            uFgVmQayF *= IPHhorzVZNPymxkD;
            xExXImxDQbTlmxK += jZNDWRakPZlaolzL;
        }
    }

    for (int PchWAgZemXW = 942400492; PchWAgZemXW > 0; PchWAgZemXW--) {
        uFgVmQayF -= uFgVmQayF;
        bsVfccBMJpkhQfe = YHlqneTxRleDp;
    }

    for (int SfcPZ = 704175153; SfcPZ > 0; SfcPZ--) {
        continue;
    }

    if (kvmelkPoyxYIqz <= string("ZdlfFHmHMOmmlxlhHPLoJLPzwKLXLyYNItkTWtPXCauFDYazerD")) {
        for (int pcyehQWx = 1372252229; pcyehQWx > 0; pcyehQWx--) {
            bsVfccBMJpkhQfe = ! YHlqneTxRleDp;
            xExXImxDQbTlmxK += kvmelkPoyxYIqz;
            xExXImxDQbTlmxK = kvmelkPoyxYIqz;
        }
    }

    return bsVfccBMJpkhQfe;
}

double LfHmhNRnIw::vqFcuCzuzYvXVbo(int ssfSdgpJSgWpCrPT, double siwcaUBsMf)
{
    bool oEZieOdPyZw = false;
    bool zTlIaFfuu = true;
    double CtQLonlUvjMMxdxV = -153763.4096441085;
    double EawfNciyUjx = -5673.86390435441;
    int fzOOMcq = -657269937;
    string DmzGOGv = string("bWNVzUcPMABshtukiecjlGXL");
    int VrFLvjddfxw = 636145083;
    bool HHcOqa = true;
    string NALCtdvX = string("yXmPnFNlIeVAwqTwcECmGXjdZaHoXHwKiJCfoqqGwXrZNaeWNvUqpizKRtdWjCfrNHUeVxlXlOyuwYgcgjadUMaYcOFNYFrtGpLSiqRYaQillZZizqJECRdTUxwftTpoNMtcsAQhZxjmQzZkMXuZBjxSzFfblQrZKgGHgoxrTPMKWJLeCNtNJqIjmCAfEaNAGADoObRDUfOGlVonwVlnpEJZYCFHMjjIHJOnKOaMApP");

    for (int SWkDFyn = 1791957046; SWkDFyn > 0; SWkDFyn--) {
        NALCtdvX = DmzGOGv;
    }

    if (zTlIaFfuu != true) {
        for (int DVDSVLulyQFgs = 2139056876; DVDSVLulyQFgs > 0; DVDSVLulyQFgs--) {
            continue;
        }
    }

    if (VrFLvjddfxw >= -602006699) {
        for (int qeGgFkVsMAtGHi = 800608782; qeGgFkVsMAtGHi > 0; qeGgFkVsMAtGHi--) {
            zTlIaFfuu = ! zTlIaFfuu;
        }
    }

    for (int jWgilUJVtFZJHtBU = 251193444; jWgilUJVtFZJHtBU > 0; jWgilUJVtFZJHtBU--) {
        zTlIaFfuu = HHcOqa;
    }

    if (siwcaUBsMf <= -153763.4096441085) {
        for (int XgeaCUmsQXeO = 316406019; XgeaCUmsQXeO > 0; XgeaCUmsQXeO--) {
            continue;
        }
    }

    for (int zIYlHv = 419947979; zIYlHv > 0; zIYlHv--) {
        NALCtdvX = DmzGOGv;
    }

    return EawfNciyUjx;
}

void LfHmhNRnIw::oNBflMSvuyEeyp(string BvvYBX, int UMwxiFEQwTpEM, int IizoDLkpXG, bool mQIsgONKT, double WHkIZcJVCpeu)
{
    string ztgaNTwSBydjRun = string("iYQLleEEMaaDRdnoVGnlsLxiWeratwbFPozRiaiIQHMXNaZnHYZhPvMmMnsZpuZjnDZuKUNUGFMMVwFjVNeoIbXntG");
    double iyZbgLHJ = -281640.6837840767;
    double WDHmzeObqCNmHs = -831072.4469146198;
    bool ldfAf = false;
    string PmmULXxTe = string("sjlAVJBwbgAEZHemeFXbhKsnwsBajGYlrLDsGwVhElHoncpUAJLpiwJEKCwsZBcWzDXofQTSFHThdGNOVckmABUHBdqLVmeDLyYoKLpVXYCGeBadJvUoSRKwuGFAmuFskWfquUcnxDUzpKTwEfXOZKVZMIgyIbxDYSOTMeHdHRKkkd");
    double XKreshiaHCh = -348851.144235589;

    if (WDHmzeObqCNmHs < -831072.4469146198) {
        for (int wVCrQic = 1630340771; wVCrQic > 0; wVCrQic--) {
            iyZbgLHJ /= iyZbgLHJ;
        }
    }

    for (int aMWwxyfuRInQGQml = 818800285; aMWwxyfuRInQGQml > 0; aMWwxyfuRInQGQml--) {
        continue;
    }
}

int LfHmhNRnIw::CurRTeCsbCOXQkjJ()
{
    int zJuZlkIzj = -2047851981;
    int MYlByfTQxBOS = -1868527575;

    if (zJuZlkIzj > -1868527575) {
        for (int pIInb = 1759427896; pIInb > 0; pIInb--) {
            MYlByfTQxBOS /= zJuZlkIzj;
            zJuZlkIzj += zJuZlkIzj;
            zJuZlkIzj *= zJuZlkIzj;
        }
    }

    if (MYlByfTQxBOS >= -1868527575) {
        for (int ujuhT = 2568531; ujuhT > 0; ujuhT--) {
            MYlByfTQxBOS += MYlByfTQxBOS;
            MYlByfTQxBOS = MYlByfTQxBOS;
            MYlByfTQxBOS *= MYlByfTQxBOS;
            zJuZlkIzj /= zJuZlkIzj;
        }
    }

    if (zJuZlkIzj != -1868527575) {
        for (int cZTOmeeHKltY = 2057040851; cZTOmeeHKltY > 0; cZTOmeeHKltY--) {
            zJuZlkIzj = zJuZlkIzj;
            zJuZlkIzj /= zJuZlkIzj;
            MYlByfTQxBOS /= zJuZlkIzj;
            zJuZlkIzj += zJuZlkIzj;
            MYlByfTQxBOS *= zJuZlkIzj;
            zJuZlkIzj *= zJuZlkIzj;
            zJuZlkIzj *= zJuZlkIzj;
        }
    }

    if (MYlByfTQxBOS <= -1868527575) {
        for (int AGXBT = 340486779; AGXBT > 0; AGXBT--) {
            MYlByfTQxBOS /= MYlByfTQxBOS;
            MYlByfTQxBOS = zJuZlkIzj;
            MYlByfTQxBOS -= MYlByfTQxBOS;
            MYlByfTQxBOS += MYlByfTQxBOS;
            MYlByfTQxBOS += zJuZlkIzj;
            zJuZlkIzj = zJuZlkIzj;
        }
    }

    return MYlByfTQxBOS;
}

bool LfHmhNRnIw::gDUbeq(double FwnXhowhiYtCm, int PAoTRSgdXzx, int TYmAgPhHFU)
{
    double LWVYOFAKtDnbthsP = 157074.29568416116;
    string BKyags = string("LHBuokxNDahjsjSqUtrFxOlnxwTcmvBlJiYjKaEvvuAjPbNXKtelRAchwajfWJgiRsdCprjQOKSbaQabMvWmWWOiZspzjWkfNRAJMtadcPzDCXDnEbVBuIZcfCFzADwhmaiKykVEDIKApSJsegEVCiWTowKameQHqmwSidrTvqWBZdboHLridaktpYgVxYTKirgNvoQZpWCQXpYkBKXOmUi");
    double vMyBuhLovVgjpb = -855560.2170254963;
    double YBBuslKdKvYPutE = -825080.0180592419;

    for (int MocKmyQWcxUGQQ = 1804879918; MocKmyQWcxUGQQ > 0; MocKmyQWcxUGQQ--) {
        YBBuslKdKvYPutE += YBBuslKdKvYPutE;
        vMyBuhLovVgjpb *= LWVYOFAKtDnbthsP;
    }

    return true;
}

bool LfHmhNRnIw::KHLFHTWNzLxn(int aVHyEY, double PAXbDajyYjYNeZ)
{
    string XrvTceyoS = string("xjFhCYtXlEnRsUuXlCfYrPehLtiJbfVHXBQNDtwEgNZkdSFKitkbjhxbAXpZCKRJwGdnnJcmiTqGwiTmgahpUoIFXchBFyFtBoAta");
    double ZoiuiyPaneUfc = -263577.8836168573;
    bool YVSlKLBRPuJdgC = true;
    double rjjtgj = 808902.6439492961;
    int PJqWn = -1078111095;
    string jXfubqMWWIww = string("RMGgeMmFYMAbWEZLSZWTpuZkJQikffmbYRspHhuGcTPbNZNlUZUVPNlvTgTZtUGRnnGzOEzqoJCkyKIETTWrwzyqfNccLKdEEiqEbaNaNkOfmNWicHflinbIJexcgAqhBjLSfdflvqAEfPTNhlSwqCFmcELhwqLzoylpWVFMGvwLsPSFnXTxRjYjqrCKwe");
    string TLNkIiDCtv = string("MuSrGlconpSGMulpoaZYcrrFCXalbRKyxwsxcYECUJSKJnDYvpSjVCyyHOaoftkBwwbaBfeMzbLAImYbAqGcHHdhmQfcEAwJRcgleqDypgtRIUDWOengNvLsDQjfSJZcvUCLDEDgK");
    double EBgQHMciTpFTslp = -418143.4802541347;
    bool wpMVSNiw = true;
    bool wPdNsvUoiKHwuP = false;

    for (int iLWaPYUTnH = 436421242; iLWaPYUTnH > 0; iLWaPYUTnH--) {
        continue;
    }

    if (rjjtgj == -596094.1339001935) {
        for (int RhrklFinzYvZ = 748465169; RhrklFinzYvZ > 0; RhrklFinzYvZ--) {
            wPdNsvUoiKHwuP = YVSlKLBRPuJdgC;
        }
    }

    for (int OVCLerH = 1295697772; OVCLerH > 0; OVCLerH--) {
        PAXbDajyYjYNeZ -= EBgQHMciTpFTslp;
        wpMVSNiw = ! wPdNsvUoiKHwuP;
    }

    return wPdNsvUoiKHwuP;
}

string LfHmhNRnIw::VVzCVIj(bool bCjDHeWrxhhUeeax)
{
    bool TZguF = false;
    double iRvsBXgp = -481676.698362391;
    string AJnXGy = string("rvFYkCgjgIWdzruaLfbfNFuMRBTmtMlSypuNMNxPrBUsINKyYPSYNZdIDwPfghbWsdnkyjxsyDZlCiLfdNmoQPsiCiETjyfThpPEUYDsbgoVOnHifRNTEsEXEkKBWAhAtQJKSSkFPZkzfEZYnIVdadSUEfVVSpiwmwIavlhodqQPCQOTYncZYeuTPrfZTpWAiLfFyXVJKhsXSSKUyySkLCryhlNg");
    string EMAxTVBudywuI = string("NPPxklZWIPBhMQVjuUyyWErjlyQVWNgTauFHRovtmbAXrMAxvDgZsUYsFqEJsfmuSSuMOCVXkRAHpfqQvQpUGeXJnDrtvCVjbvHOjDBihBVjrgcOzQQpFgzNLsZKIAxUxuNpCjkQartcpJtkcckFLNrkYIrELpEBHdfZpkCTdVfhWpQSxfAkaoNFvdqblAuiJtijArprCnudeClgWpTLXNiFNVuMDvMCddLQwZVf");

    for (int JgbFq = 1996255542; JgbFq > 0; JgbFq--) {
        AJnXGy += AJnXGy;
    }

    for (int anUdbkRc = 1765345258; anUdbkRc > 0; anUdbkRc--) {
        TZguF = TZguF;
        bCjDHeWrxhhUeeax = ! TZguF;
        AJnXGy += EMAxTVBudywuI;
    }

    for (int FeEgF = 1246021695; FeEgF > 0; FeEgF--) {
        TZguF = ! bCjDHeWrxhhUeeax;
        iRvsBXgp /= iRvsBXgp;
        bCjDHeWrxhhUeeax = ! TZguF;
        EMAxTVBudywuI = EMAxTVBudywuI;
        AJnXGy += EMAxTVBudywuI;
    }

    return EMAxTVBudywuI;
}

int LfHmhNRnIw::CHnTv(string MFsJAB, bool FaBDGP, string umIvwIHd, double pwrEwFmuVFEwBhy)
{
    int xNkzUgPIKveRyA = 1308217477;
    int TQOIEfKsz = 1397063540;
    string wxcoeLvKqYC = string("zODvlzFlWUDlfJeMzwKEMFqWLpwYnwIlIFBHejWsaXbQBLplArsUmkhynGJmUfnJlejfmRTMvlNoQkxvpKTThVrcJKinbCabDAIdMunyLUIMltxyVuEMkxFseMpbajCvudHEAIVDkFPkXeEajlqRznmZDJdGeyR");
    string NHGKNZ = string("BVSJwNpDVCLTddojIueLviePMaibEbiHvLARWiktMAULvvPtDWOpMbAuBcDXZSkYYtRLSrVhh");
    string ahdNqUxkDmMeSiu = string("CSDzrXmKVklpCynBNThWPignRUSegjODoQPQtCSBnBzbjeHMCXPNXkaMhATnevAeTYVDZfJyErfNveXqVCrVCNopZVaVbeZJZcgiJhgxyWz");
    int LGDYZCQCpKE = -555327812;

    if (TQOIEfKsz < -555327812) {
        for (int aQXvEDnAFkj = 1089086030; aQXvEDnAFkj > 0; aQXvEDnAFkj--) {
            ahdNqUxkDmMeSiu += ahdNqUxkDmMeSiu;
            LGDYZCQCpKE = xNkzUgPIKveRyA;
            xNkzUgPIKveRyA /= LGDYZCQCpKE;
            umIvwIHd = MFsJAB;
        }
    }

    for (int RvBYNJAjkcrs = 2107538327; RvBYNJAjkcrs > 0; RvBYNJAjkcrs--) {
        wxcoeLvKqYC += umIvwIHd;
        ahdNqUxkDmMeSiu = umIvwIHd;
        wxcoeLvKqYC += ahdNqUxkDmMeSiu;
    }

    if (wxcoeLvKqYC < string("BVSJwNpDVCLTddojIueLviePMaibEbiHvLARWiktMAULvvPtDWOpMbAuBcDXZSkYYtRLSrVhh")) {
        for (int IIWujLU = 748559172; IIWujLU > 0; IIWujLU--) {
            LGDYZCQCpKE -= TQOIEfKsz;
            wxcoeLvKqYC += ahdNqUxkDmMeSiu;
            xNkzUgPIKveRyA *= LGDYZCQCpKE;
            pwrEwFmuVFEwBhy *= pwrEwFmuVFEwBhy;
        }
    }

    return LGDYZCQCpKE;
}

double LfHmhNRnIw::fsgBbuzFEoJVgen(bool UtMCItro, string MbsIMZRS, string YTLLI)
{
    double FFTRSyJfbAuGdmuK = 980445.7848918968;
    bool svqtovajh = true;
    double cVSrMnbHlj = 293606.2299973771;
    int goxzjGU = 1186780831;
    string MLYpJp = string("ixnMeJijwA");
    string mmeTy = string("LajctompCqZdoCpVUwfmVHrNYKpVHwwfDXJYUlYbYhMpeifKcyhLVmCWpQKhhHmxsAFQrXwuZxBTeFNVeZBmfLnQCkQizOyJgMbZlBUwjeNKhLqngTxvdlmMGHRqXaPZrqpfAZUV");
    double BxpIusgJwkGw = -806822.3767870553;
    string CEDCnetZiWb = string("KuyhxkFXjROGTOxKFBAGHB");
    string zMLptnZN = string("SGAMkpCHyUlCdPWoAvWVLXfBxImaRwQpQFbWhNJYkoegSnGfKWXvvyfcPgcXoZpwQvbexwLssuXQdiekoaBzEWUVbBviOQJfgseduxOLsOSyVNKBYCPMfezRvbxVFyVetDeafgljlXmNVmQQbAIRoCHlbKTfIeoyxQNNPwrUIjBvJEZqsNJVZeWwieOTyrNUxHNtBqhrCPzWeDSgxYqcMFEtGKaWm");
    int AEHpzKr = 1889151644;

    if (FFTRSyJfbAuGdmuK <= 980445.7848918968) {
        for (int MlOObJ = 1871593975; MlOObJ > 0; MlOObJ--) {
            zMLptnZN += YTLLI;
            mmeTy += mmeTy;
        }
    }

    return BxpIusgJwkGw;
}

double LfHmhNRnIw::tXsBRlCFLsW(double HLitpeLses, int BXnFqvbmplw, string bdAkHFEXCrZ, int SGWQsPzIA, string NsjfHHFXFShfrr)
{
    string xtnTcTQWyOkrw = string("AgIQYEYgUNbBZIOwgrebzeUDYGwNGjOE");
    double NJfGoyqC = -255673.54698013552;
    bool YmVnladv = true;
    int ezYcyzrObQGr = -1901087231;
    bool xalsLseeayd = true;
    double EdlSTvRNsx = -521382.10527329805;

    for (int ZyDJH = 2094368895; ZyDJH > 0; ZyDJH--) {
        EdlSTvRNsx -= HLitpeLses;
    }

    return EdlSTvRNsx;
}

LfHmhNRnIw::LfHmhNRnIw()
{
    this->onGZwQhM(false, string("gUWHixAsRvAgYWqeNqpdmvVoeyJxhTsIRnwSKcgIyEpYocVYoGRotOMDBWeEGBvUmwkRUwhnWZeeOkFWoGSeKHOFmlqbrgIcaJbBgLCWmJnKturiLkjKLBImWOxZxcJoUhAHicGEbQvUemZNGUfPxVDlcjUsECLzhZsuWFyNVcsNFZsjGFNjorptssOKapdxXJahJnPOXoHQJkRZfT"));
    this->SFpWReqF(false, -1647713029, -105499.73068966504, false, -916540.9516115873);
    this->NBpQTGVnCUUB(-235258.1313656546, -283718.52942457685, string("tDpZVMFSxXhmkQwauZRCvRMURGVfEaHcVHVRmRSyoaxnSuanRqDWSNbWWrsspBbcfRkDCKAWqNHzXpDDRNOEdBwzZQpxIXTBLnKngdojyRweWPKaOrqLMmRtSmzkXHLFlPRDnNKNdkSYIhjoCTowKEjPZXUktwUvudZdkyBf"));
    this->AUTiQaGqFSFU(true);
    this->aJSHMALMgI(string("RzfSLhNqpdSPgFGWGcVDHQtMAKzwEGkrFongHCMxSPGtOvSvugasKGvNCFsVIsGE"), -263182.59450989874);
    this->Kpbkp(true, true);
    this->UnIgBS(string("yLZbfyjBtpZSirkZzurobgCNhpfpJgmVnDNKCaNKGFmexeJHGxEHvERHViWBlmshVEfTusEdLOZiYEcyOYqKPjtNsMZpKcUDdgBoOIZrb"), 939062.3272610492, string("fovpRWdNNuRMwRqeyqcHjOHHTVKTyKKYpGmKvSPFLVFngYUEvRSrdeAwusNKNXwDakNomBQCsBvUwCEBLiKCzWWCTclHUYiCjJxIPWRqamumhbUeESfqoIkvRjzdmNJccTbRAUgYhfYUjrhLzEMbmKxNyoVZzLtLGyMUVbjTuTGOXtmy"));
    this->fwzOMXFkfADaTHL(true, 592483.2447591755, -793031108);
    this->oFaoDYQh(false);
    this->HFBnGBPzzwcpr();
    this->WiTvqPBpjiumJ(1923696404, 741565643, string("alFDbTTZFy"), 701955.989388246, -182898.8627891255);
    this->HfkvmYnqINHeKTMx();
    this->vqFcuCzuzYvXVbo(-602006699, -875546.5344114301);
    this->oNBflMSvuyEeyp(string("qllxTBOtAQuRczTbxMyOhtaxUNyXzGcjgczxynVnqYbXAutBonnRKHxXcqPkEaxPROfGqEWHfySGmxiHP"), -352463207, 1820151146, false, 158158.14632923537);
    this->CurRTeCsbCOXQkjJ();
    this->gDUbeq(-1010742.7978458583, -2130367645, 82294956);
    this->KHLFHTWNzLxn(42840006, -596094.1339001935);
    this->VVzCVIj(true);
    this->CHnTv(string("aClKsGgwDNoIeplKPDdirmCEtNlbSRlHfdLbhfzDtguZYhKgIuMSQbOFrxDavvZPPBKzUYNebBDLGCDMyxrLMaJhiymoWujTeiuMcGkXNDfQHfIeUzZfUVWmgdRbUftitGGzvsFjWFOaagcCstHwuPEAtEnWc"), false, string("DbGKqSFNnBuzgFDmcOOuHnNHDdMXVhPlKWWzqwTBgrpYsMRgtUQUcSaayZGrzsZAPKEJKqtMcJpZKFasXgLHVtWnjkFHYZPduYKJIedyxvuxRHRvUWsyocfUqVFpijftCGkkKecFrTKhQiqqRfwUvbHiCXiwHIDTezndPSfaPQRaoyGiC"), -908808.4954525521);
    this->fsgBbuzFEoJVgen(true, string("DPelQKRowhqOvmbpRpRDcVdfdeWlTUWztmjfgWCHqbkKFrvtKMSDEqVkUJWjXkBBtbSJiXaLvpHFSgIPwbtvdhazmOIqpfxfOVYgrLNrmIAqNTKpUoNZMIzxbjMekDazLPZGKZTmOiLZHpypwPKWdWeNNvwXkLrzQfYZHXZsosDrBMazKXLJrawxjcjZLWKALeZMMfyKmcLlaZtoSvjDLHZtVgwZlBpqVxXplIcKJBXdiRBTmiTv"), string("qkKqZUHjLAfWkKxaMZhHkqIeHnJqAMTozIXHLmwmPzJmPaAaPevZFBOxVQzuJAPEKurPttVzquqeGtwRckHKDbClIagFslmllgIymIvUCEYZOGkrKHszxZLwxqtenLiayMWQNomliaBsTocGjpFCgCqKnescCQTOKsuifMovvprlsncgKxvGKyfqWuDTTEtRMnwyBLTTZtpHGuaYSnpFplvUjpLiH"));
    this->tXsBRlCFLsW(-132301.38269848272, -860302674, string("iNFDqRSeLdvhgtmyGUQnWNnVdXsXSjvGtDduLDyLzOqhddTAcIYpTEqqtuPdThnwBjoqXPIWvhjyBScQLZtMIZynwKIonWoddxKkTncGXvVnjFwryjsDfPWCVBMbMSkuhjEyOOzroYfUQinuIqGbTYhyhnRKtUOOeuxQHXZafLZkQrnzNGluaxrAcDiLxXBYEQmU"), 888525191, string("Elbs"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lOKYkSemCT
{
public:
    double fcEybwk;
    int SAcxkRc;
    bool RVLstYUcIEn;
    int PCzDyDTbcnUmEfq;

    lOKYkSemCT();
protected:
    int TVJcJrleeAUpyL;
    bool dhxryisZGS;
    bool XVtENCWheank;
    string DJwCSJCUMxGant;
    string SPVmePAXcJBiX;

    double znHDGnAzwBKl(bool ogmOPt, string DZJiJLopA);
    string ZpVkyNzjVRa();
    void lfqpLuxnOYk(string mXbSkItRUDfso, string lUYSPkctkaQ);
    string IqONIvxCc(int IzZPjIZ, int PitqpvfxgSCr, double FjCUcNeLMlMvBGIq);
    string HMhdmoFAWwLIDSAR(double LzfAyib, bool QSoJBiOJpNEeQf, bool odABGcc, string jUTjtwNiSrYJnm, int YdAfJQHnJrG);
    int PAviLgSBiMFsje();
    int cPfekcZfMrSkEWE(string tasaVRHZFCwrfBFd, string BBTBiIrDxtUeksi, bool FIEeqvbpCtwDlvC, bool yIgFRWw);
private:
    int FsnxertoQEnbCT;
    string tcZpOmxQCFaS;
    int jDEaasHYPvSmJEV;
    double sWLbUWaP;
    int pOibSJ;
    double HXxvOgMhYM;

    double OkAyf(int ruFeZdtCwu, double kgroXBKLCeKHazmL, int RQyLaaAg);
    double YpxiA(bool FPuijrjJ, bool twahpJeYEkHinjIx, bool yKYLyYcATktAGFNp);
    int nOemRD(bool SMzUu, bool PzSac);
    int WjsSwqwgUaPN(string auMsQ, int jdarzIxGvCE, bool rDWqqBF);
    void HmBXmDWcN(double ccWZSsUBzz, bool aoEFUmS, int UNzzPbjMMYpGhJ);
};

double lOKYkSemCT::znHDGnAzwBKl(bool ogmOPt, string DZJiJLopA)
{
    int xwGMcQHBjnR = -148991995;
    int PogxYAkBK = 1882587182;
    double jjTrkSkvzzJf = -31141.654034094423;

    for (int sVseyxzOYYgl = 549776053; sVseyxzOYYgl > 0; sVseyxzOYYgl--) {
        xwGMcQHBjnR += xwGMcQHBjnR;
        xwGMcQHBjnR *= xwGMcQHBjnR;
        PogxYAkBK *= xwGMcQHBjnR;
    }

    return jjTrkSkvzzJf;
}

string lOKYkSemCT::ZpVkyNzjVRa()
{
    string JflsW = string("QMljWuEbDszfqvxlaJkZXue");
    bool IpTaptMRL = true;
    int IQCPwAqWj = -85609986;
    double solfpoJs = -79911.85914676804;

    for (int MlzkXEoErTkPXQmQ = 380252721; MlzkXEoErTkPXQmQ > 0; MlzkXEoErTkPXQmQ--) {
        continue;
    }

    if (IpTaptMRL == true) {
        for (int icuvkqIUmWScBjmX = 1633825839; icuvkqIUmWScBjmX > 0; icuvkqIUmWScBjmX--) {
            continue;
        }
    }

    return JflsW;
}

void lOKYkSemCT::lfqpLuxnOYk(string mXbSkItRUDfso, string lUYSPkctkaQ)
{
    double HCQKdIynRxVYeI = 245677.5758056294;
    bool EfeJxZdeUfyPKzOP = true;
    int qrrvSFbXpSHJpV = 1443918641;
    int qoSukFZPTCd = -1652658247;
}

string lOKYkSemCT::IqONIvxCc(int IzZPjIZ, int PitqpvfxgSCr, double FjCUcNeLMlMvBGIq)
{
    double npisIzrDu = 191046.15143499937;

    for (int tjiilDw = 1860854782; tjiilDw > 0; tjiilDw--) {
        continue;
    }

    if (npisIzrDu == 191046.15143499937) {
        for (int bGsPigRk = 1373905803; bGsPigRk > 0; bGsPigRk--) {
            PitqpvfxgSCr /= IzZPjIZ;
            FjCUcNeLMlMvBGIq += FjCUcNeLMlMvBGIq;
        }
    }

    return string("sotYiKlssvdfylfQerQdSNqnvRPljvIgBhepqmyEuzQQJzskZDChDXsYaqLgJjHQgtbjBUitrYFkXXGXCbnvITNnyqAGCjKDPqTBTkscmkmzgzapocdMjtqbApCPxNwUweBQHaaEXFOsOirazAmcYTtgZGpOAWpzVSaLeUC");
}

string lOKYkSemCT::HMhdmoFAWwLIDSAR(double LzfAyib, bool QSoJBiOJpNEeQf, bool odABGcc, string jUTjtwNiSrYJnm, int YdAfJQHnJrG)
{
    string HytqOmbzaBQxxb = string("ovQGuKTWxUqggdtJzAtLZTKbmUFMsoSpdUZFSLF");
    bool TMeAmZ = true;
    double xhcMJdbKQxOHBj = 966909.457117277;
    bool OzcFHqgGVAuyVcX = false;

    for (int xrNyXl = 1921143173; xrNyXl > 0; xrNyXl--) {
        OzcFHqgGVAuyVcX = ! QSoJBiOJpNEeQf;
        QSoJBiOJpNEeQf = TMeAmZ;
    }

    return HytqOmbzaBQxxb;
}

int lOKYkSemCT::PAviLgSBiMFsje()
{
    string nGCdJ = string("rVXYWxVXkuVpTYGcoJQAJzdmBHpNjKZnUAckkNZcloxpIIJXreCsLsYTflwyeqQPrZEfDQNwleX");
    double LBgtwFBzC = 482962.82693946076;
    double BOySGICqB = 664923.3710615548;
    string oAYehlbEOeBx = string("JzChfAFjZedXyKjFDNoRvyBVXuyFAsWoskPzpkyiVIMFfFSQRZxKbvlxUpanlnjvHQAxuPPtUTRLNbWYnWRvoepjq");
    int CcZkXHjn = 175605859;
    bool ZpiVVDfBB = false;

    for (int pyfTOahmLr = 1354364179; pyfTOahmLr > 0; pyfTOahmLr--) {
        CcZkXHjn = CcZkXHjn;
        LBgtwFBzC = BOySGICqB;
    }

    for (int qiRrrplOJh = 913866665; qiRrrplOJh > 0; qiRrrplOJh--) {
        LBgtwFBzC *= LBgtwFBzC;
        CcZkXHjn = CcZkXHjn;
    }

    for (int DOICIyhDpBmQ = 151294135; DOICIyhDpBmQ > 0; DOICIyhDpBmQ--) {
        nGCdJ += nGCdJ;
    }

    for (int MdNHzNNllolc = 443836460; MdNHzNNllolc > 0; MdNHzNNllolc--) {
        continue;
    }

    return CcZkXHjn;
}

int lOKYkSemCT::cPfekcZfMrSkEWE(string tasaVRHZFCwrfBFd, string BBTBiIrDxtUeksi, bool FIEeqvbpCtwDlvC, bool yIgFRWw)
{
    double zGrusXNNEpxnWrmh = 849596.8226978149;
    double RokfHSY = 836568.053068668;
    string sWSsipL = string("pizlSXfXoNUJcqxIJdbstMCIOaVHPSVKeshxztAIuBWyrDuMnGPllRbVFZSBSfFKnfucTUhppbPKUAWadREXPSubVHoWvEmwLqnlWlJPBemGFckSwlelFKkLwYXghOIfUQPYvDGuTTBgoQMoUKbnWYHvHEvIFCMCygm");
    int GECNBXr = 600598323;
    bool OjXgyKSl = true;
    double QcYroEMunBKv = 111461.92068754022;
    string rTjdmHqeCnfFKDnW = string("FmTuMHhNKjBaWkMIorHzRdtNoEfwGYQNwNMNEzICqxJnzpMdMIiHpIirhWSYNwpTiqQTCpNOCgzpcayoxadfctIYPfEfRqQGVcbqWnOKmOQzZqEddSFUiifdprURMJlwtxExYrAMRbtxf");

    if (RokfHSY > 111461.92068754022) {
        for (int xFXOzQfRTFZ = 541171728; xFXOzQfRTFZ > 0; xFXOzQfRTFZ--) {
            continue;
        }
    }

    for (int kCUnULKzyZuTea = 742664723; kCUnULKzyZuTea > 0; kCUnULKzyZuTea--) {
        continue;
    }

    if (BBTBiIrDxtUeksi < string("oLZoAiKBZAghVIzAlofyWxMixAjRLFuUzEkGpOoLsNDiFLxZGjCMmf")) {
        for (int UNPNXAXArJ = 1251071146; UNPNXAXArJ > 0; UNPNXAXArJ--) {
            tasaVRHZFCwrfBFd += BBTBiIrDxtUeksi;
            GECNBXr -= GECNBXr;
            tasaVRHZFCwrfBFd += rTjdmHqeCnfFKDnW;
        }
    }

    for (int UBNxwCNsHhLdA = 1743062126; UBNxwCNsHhLdA > 0; UBNxwCNsHhLdA--) {
        BBTBiIrDxtUeksi += sWSsipL;
    }

    return GECNBXr;
}

double lOKYkSemCT::OkAyf(int ruFeZdtCwu, double kgroXBKLCeKHazmL, int RQyLaaAg)
{
    bool BCWsEIr = false;

    for (int mVTpQTqT = 1883263550; mVTpQTqT > 0; mVTpQTqT--) {
        continue;
    }

    if (BCWsEIr == false) {
        for (int lCiVzyKudeRElljN = 235638208; lCiVzyKudeRElljN > 0; lCiVzyKudeRElljN--) {
            RQyLaaAg -= ruFeZdtCwu;
        }
    }

    return kgroXBKLCeKHazmL;
}

double lOKYkSemCT::YpxiA(bool FPuijrjJ, bool twahpJeYEkHinjIx, bool yKYLyYcATktAGFNp)
{
    string oSuFSg = string("AXKuhwGBsEkCVjnELkMnZVrfXFoNePioymCYHIFMnCrhIHPIVDkMvjzxejUxsZqKVbDpxj");
    string oTCxrWyX = string("bvAjw");
    string iUYttTuFRFJUxL = string("wK");
    string iayIJcOLLFLpuDC = string("YrbcmwWcgSDFKbtLIqgFbCVzQTXsmnKCjW");

    if (iUYttTuFRFJUxL >= string("bvAjw")) {
        for (int RotEzsUNZiOfRMIk = 1245022675; RotEzsUNZiOfRMIk > 0; RotEzsUNZiOfRMIk--) {
            iayIJcOLLFLpuDC = iUYttTuFRFJUxL;
            twahpJeYEkHinjIx = yKYLyYcATktAGFNp;
        }
    }

    if (oSuFSg > string("YrbcmwWcgSDFKbtLIqgFbCVzQTXsmnKCjW")) {
        for (int eLCOGdZsWAW = 1989539910; eLCOGdZsWAW > 0; eLCOGdZsWAW--) {
            oSuFSg = iUYttTuFRFJUxL;
            yKYLyYcATktAGFNp = ! twahpJeYEkHinjIx;
            oSuFSg += iayIJcOLLFLpuDC;
            oSuFSg = iUYttTuFRFJUxL;
            oSuFSg = iUYttTuFRFJUxL;
            iUYttTuFRFJUxL += iUYttTuFRFJUxL;
            oSuFSg += iUYttTuFRFJUxL;
        }
    }

    for (int aYcum = 11290787; aYcum > 0; aYcum--) {
        oTCxrWyX += iayIJcOLLFLpuDC;
        yKYLyYcATktAGFNp = ! yKYLyYcATktAGFNp;
        yKYLyYcATktAGFNp = ! twahpJeYEkHinjIx;
    }

    return 713577.8777112983;
}

int lOKYkSemCT::nOemRD(bool SMzUu, bool PzSac)
{
    int jyLqXgbXQ = 21490912;
    bool tvquDNdpivcNJ = true;

    if (jyLqXgbXQ <= 21490912) {
        for (int Sbjxuj = 1891788726; Sbjxuj > 0; Sbjxuj--) {
            SMzUu = ! SMzUu;
        }
    }

    return jyLqXgbXQ;
}

int lOKYkSemCT::WjsSwqwgUaPN(string auMsQ, int jdarzIxGvCE, bool rDWqqBF)
{
    double kTByabLkMbq = -846482.2220282545;
    string qnEcPZ = string("DnPvvhDuBrHbQpfECDFczexcYfiVsaNPhmVKfCNTOgVJRzevxOtzqxthspjHpyFeDBfzQCQIbfprXCuSnTnfbLHFueZwVlXcIDLZKjaFugMHGyRjqEFQjiEzGnXsVmyqxKaUFYRqArcbIbqgpBKxSbgsNyYHhlHIfcIpSExpwcApa");
    bool LWMoIebnTIun = true;

    for (int eiSbnokzDciiHEOM = 1237798486; eiSbnokzDciiHEOM > 0; eiSbnokzDciiHEOM--) {
        rDWqqBF = rDWqqBF;
    }

    for (int vHdHFMJGKS = 1470886596; vHdHFMJGKS > 0; vHdHFMJGKS--) {
        continue;
    }

    return jdarzIxGvCE;
}

void lOKYkSemCT::HmBXmDWcN(double ccWZSsUBzz, bool aoEFUmS, int UNzzPbjMMYpGhJ)
{
    string bkhheZZXw = string("huBRKDnJQvFJgCnjExEhUTPHQJiXMuhhUYBQrRhpqSWHJOPBDuEllwihEvkZxKlDdjFOBiFNnkAgkjSdCOjBcepprsZgoPYKeZqLalOjZVXTVDLpVIuqaTLxCnucafpkXphOCbVeMuWpaduFiIVQPrwcRTFhKXaJf");
    string GkzKERATNWWiZ = string("BpVQwgFXvNFIFZoFDIiHUAODanOHmZaXeaDlGPjlLyENTCGbPslcqKGkbZhfEbmjZISlLcaKQQGVRP");
    double SlweIYhzDWBHrl = -187757.84095402324;
    string HlGXvYZ = string("UkLFwNsfxlUKJUwIYFClLfCFnWKifmZDQGjWdtkpnJtiWctQLkGoRHvrklpzxQYZiSgRPLsNTpcEYnbfYZxuJqRfZChKuqgcWYmarcZpFroQwkcsOeIhdCstpNnYTPreLWRcRf");
    bool brlNuUDdyQleE = true;
    int rFLhC = -497580067;
    string LcJvCd = string("xBeenvxeLwvXrvrqLWjUbqsIcszBUHVBzxbHKDVpbTbADPTAvFlPuDhNoAUIxEyTDGpiCqoJVKaNYgrwXuOxjfwRvDhaMkFWVjJISqySvUAEdglVKwbFyufFtUGGnswNVMoEoeFtwMOFNPFUOALxbJvrmtLJbmRxMOGqOHcbfFXoaZsPwboIAyIQPkEWlpNSsrZbZhEkODxOtZY");
    string IQBucbbwpRrP = string("gFLsfcTXXSfNWjdhsUPWipAlfxODZKmkUCyoLRwvExcBjFBgMwBRBiKDMoqLkQlsdyRPEFCLmYvfbDxXsMlwkUpNVYShesDhGMhkyXsdtvqyQzrVGonxLpbXIpALFCzifmPIFHcyCLkaTUtyvxLCSxootpmAHdGEKDUfxYBJOmrMunjDAnQGAuJzHEetsVBHHLuWtbyqMekySofsJorhwCGkdeOourXwUznpwaWRwgbkJHTTQYW");
    bool xtdXWwfXJu = true;
    double OidfaKgUXLALqsc = -991606.5662618631;

    for (int IzCyAF = 1630660576; IzCyAF > 0; IzCyAF--) {
        continue;
    }

    for (int GNuBtPPPUvdW = 466218675; GNuBtPPPUvdW > 0; GNuBtPPPUvdW--) {
        continue;
    }
}

lOKYkSemCT::lOKYkSemCT()
{
    this->znHDGnAzwBKl(false, string("fJrDZlMUpVdlEdpUpUODkcPWLEwWXFBAVEnFVeCmaoCBwd"));
    this->ZpVkyNzjVRa();
    this->lfqpLuxnOYk(string("QdSUNRSXPmtnDQkhXzvoDFivShpYfIxxvORgmfHVpQzqXAZJqUDRZZgamUdngbFVJtkRSWxh"), string("RSocbaCUVUwdzblPEbRqMghJbAhtTSkmUfT"));
    this->IqONIvxCc(-715287100, 1721892933, 840955.318051549);
    this->HMhdmoFAWwLIDSAR(765989.1346397798, true, true, string("ZMbVkhHSGeDqinatJbefbKiUNpKBgVTmbqlmTmarvGNEwerCRygvJatkjRBKZEQZKYTx"), 1686245556);
    this->PAviLgSBiMFsje();
    this->cPfekcZfMrSkEWE(string("keZZdX"), string("oLZoAiKBZAghVIzAlofyWxMixAjRLFuUzEkGpOoLsNDiFLxZGjCMmf"), true, true);
    this->OkAyf(-1048202599, 818640.0590508376, 1163415192);
    this->YpxiA(true, true, true);
    this->nOemRD(true, false);
    this->WjsSwqwgUaPN(string("DBLfsiaChWzsYmkZHTaDauugZkumidPTzaMQhOvUdoERUQTTUqTrukbKOlhNClbqzfEuVhJAWfhppdKsWqsZHSxNQwfuogXSGEmNRrtsMftSlvSnZsWKbJfPUaAUVqcqpxauIaDAqNyzbzGuYlbfynDmzgfpYMkBoIvaRwiQdUOQieDjKsOPKxCPfNBAhIIvUNVj"), 1075741658, false);
    this->HmBXmDWcN(782361.7543241212, false, -782993786);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cgQnyLrCxGh
{
public:
    double YGYogomftZ;

    cgQnyLrCxGh();
    void FcXCttyTMNChb(bool LjdrmuBTROWTt, string hWvPnyXlRnUhV, double XTrpHTCriTz, int PrUEGmARl);
protected:
    string UoACv;
    bool zuthBhcbLvAJhj;
    double gekrWoSSh;
    double YkoGTsRO;

    bool dpgSJjppop(bool yRyBKaLdkEYoAxG, double gakbGzf, string vKHtYRKCE, double btrkwBgnyxr, int mYSDvLbhUfh);
private:
    bool IwKSdOVm;
    double AlKlrF;

    void qyowRrsCVuUb(double EkcvVtAfXAfLrBD, int ntVhXzyzAtqHtIjI, bool fkdgrSpwCPAC, double qtIidSz, bool CoqPWuOVCseumJ);
    bool iCfjcLdOm(double BLjzhPWqQEim, int yEJdstzl, bool efgsSpZPiub);
    int xiFSgcnWLPQljvn(string wJHQODelsIqyuXM, bool pprSSncf, bool kejxfSrFbz);
    string IDMiadNNZ(int sZpnIPKOEZJwxAJi, int ToQDsHYsGxjt, int czfHSoxzRPJ, string qxvWNXBKLLPYUkEH, string OscdjLaBEWttPkTf);
    double LGoObGnWzouR(string xtKJHeFTSUZBTw, bool NAlxlhUGNbut, double YOWPPjEPHpx, int APnZkM, int wVMImFEZlCm);
    double fuARJgd(double ARNCuQHasnTuk, int rVKPqGioa, bool ogxyvxF);
    string WuPaD(int VasMmCqTV, int ugDPoHCyKZhw, double reiKu);
    bool oMCMmINxMsXGyLh(bool OgopBZANwoXTFN, double TrynQOgolHICCrqH, int jhuHwHrlg, double JLjYaKAzgWlPiIt, bool adjuIqB);
};

void cgQnyLrCxGh::FcXCttyTMNChb(bool LjdrmuBTROWTt, string hWvPnyXlRnUhV, double XTrpHTCriTz, int PrUEGmARl)
{
    bool kOBHiKigf = true;
    string rfTzfsOnWvpxNMo = string("ogrGcYzuUcvIudgYoerCfaVSAcorGgOJSAANsuIfKytuFcQjzPkJlpOXkjgHCPPiCgSAbeMreaMyxfMxNjkrgsnzEyPfXxPyeGLGfvkYInQyvcmIHiFqirHziUOEubcHJvUEnAKkLQDjyxtCZmcZSqbdJAfECahIkepMrsnsbZKXjoDNcBMBdraztPrWW");
    int vHoPe = -1186100754;
    int qgXYhh = -1019612552;
    int ayhtmdeVZpC = 1675308012;
    int psElWZayxxPrT = -609496927;
    bool IlFPegRTtDPjO = true;
    string iLbZzRxcIKV = string("JKEPVypEAmAhckLGPNmLIYkXxGRUdZlkvzpevrPqHlUySIfLBcjbhZmriVFEsypVxhiG");
    double TgXMcnuz = -746834.3383654482;

    for (int eeOfzXyWXt = 1423863479; eeOfzXyWXt > 0; eeOfzXyWXt--) {
        iLbZzRxcIKV += iLbZzRxcIKV;
        vHoPe = PrUEGmARl;
        XTrpHTCriTz += XTrpHTCriTz;
    }

    for (int PDTJWglaSntDMC = 1272214323; PDTJWglaSntDMC > 0; PDTJWglaSntDMC--) {
        IlFPegRTtDPjO = ! LjdrmuBTROWTt;
        ayhtmdeVZpC /= vHoPe;
    }

    if (IlFPegRTtDPjO == true) {
        for (int HvXZKhe = 1343645365; HvXZKhe > 0; HvXZKhe--) {
            iLbZzRxcIKV = hWvPnyXlRnUhV;
        }
    }

    for (int PUrOHYyJLZT = 1155294329; PUrOHYyJLZT > 0; PUrOHYyJLZT--) {
        psElWZayxxPrT *= vHoPe;
    }

    if (hWvPnyXlRnUhV > string("JKEPVypEAmAhckLGPNmLIYkXxGRUdZlkvzpevrPqHlUySIfLBcjbhZmriVFEsypVxhiG")) {
        for (int MwLmq = 1121158332; MwLmq > 0; MwLmq--) {
            vHoPe /= PrUEGmARl;
            qgXYhh -= vHoPe;
            vHoPe /= qgXYhh;
            ayhtmdeVZpC /= ayhtmdeVZpC;
        }
    }

    if (ayhtmdeVZpC >= -1186100754) {
        for (int NKZKcEUzlfEt = 1678801507; NKZKcEUzlfEt > 0; NKZKcEUzlfEt--) {
            psElWZayxxPrT /= qgXYhh;
            iLbZzRxcIKV = hWvPnyXlRnUhV;
            LjdrmuBTROWTt = ! LjdrmuBTROWTt;
            psElWZayxxPrT += PrUEGmARl;
        }
    }

    for (int vIoaxDqYy = 837367358; vIoaxDqYy > 0; vIoaxDqYy--) {
        psElWZayxxPrT = psElWZayxxPrT;
        TgXMcnuz += XTrpHTCriTz;
    }
}

bool cgQnyLrCxGh::dpgSJjppop(bool yRyBKaLdkEYoAxG, double gakbGzf, string vKHtYRKCE, double btrkwBgnyxr, int mYSDvLbhUfh)
{
    bool MrGBQzgImk = false;
    double sdtDYMw = 946765.2989431011;
    bool BfksjBDxbY = false;
    int ZAxSApi = -371960563;
    double NarvRD = -807824.9171198395;
    double hkbondqYoXgwHXgj = -883424.8879580334;
    bool CScpcPOAKQy = false;

    for (int ooFGghvJzpTjzW = 900929340; ooFGghvJzpTjzW > 0; ooFGghvJzpTjzW--) {
        NarvRD += btrkwBgnyxr;
        MrGBQzgImk = ! CScpcPOAKQy;
        vKHtYRKCE += vKHtYRKCE;
        gakbGzf = btrkwBgnyxr;
        sdtDYMw += btrkwBgnyxr;
    }

    return CScpcPOAKQy;
}

void cgQnyLrCxGh::qyowRrsCVuUb(double EkcvVtAfXAfLrBD, int ntVhXzyzAtqHtIjI, bool fkdgrSpwCPAC, double qtIidSz, bool CoqPWuOVCseumJ)
{
    double MPTFJEI = 753621.8980125902;
    bool jpnioaUDuFjhVAaz = false;
    bool MuyTwWqKYlL = false;
    bool RkoloWucgaKMviLX = false;
    double wdJjOiQOf = 845654.1193242692;
    string huwZwNzNKFXohBAp = string("btGRihkJOcTuFuxQEgCXAvfhhzTJlIxgUXPgkWtQmMLHrBhyQKLupPVYqbrY");

    for (int CxBbbJgFBrHDsSzn = 659869591; CxBbbJgFBrHDsSzn > 0; CxBbbJgFBrHDsSzn--) {
        wdJjOiQOf += wdJjOiQOf;
        RkoloWucgaKMviLX = ! MuyTwWqKYlL;
        CoqPWuOVCseumJ = ! MuyTwWqKYlL;
    }

    if (EkcvVtAfXAfLrBD >= 528939.681468416) {
        for (int EvkQIPpGibyX = 137029724; EvkQIPpGibyX > 0; EvkQIPpGibyX--) {
            MPTFJEI *= EkcvVtAfXAfLrBD;
            RkoloWucgaKMviLX = MuyTwWqKYlL;
            ntVhXzyzAtqHtIjI = ntVhXzyzAtqHtIjI;
        }
    }

    if (MuyTwWqKYlL != false) {
        for (int PAgKCdAkvKaS = 614305325; PAgKCdAkvKaS > 0; PAgKCdAkvKaS--) {
            wdJjOiQOf = MPTFJEI;
            MuyTwWqKYlL = ! jpnioaUDuFjhVAaz;
        }
    }

    for (int tGRCh = 889614609; tGRCh > 0; tGRCh--) {
        CoqPWuOVCseumJ = RkoloWucgaKMviLX;
        MPTFJEI -= EkcvVtAfXAfLrBD;
        EkcvVtAfXAfLrBD -= wdJjOiQOf;
    }
}

bool cgQnyLrCxGh::iCfjcLdOm(double BLjzhPWqQEim, int yEJdstzl, bool efgsSpZPiub)
{
    double fOLerPFZ = 58000.07950077612;
    bool LAIjE = false;
    double WfwuO = 786155.3501710914;
    int HntEMVDkoHrI = 1987749163;
    double IccoHA = 955802.7713861831;
    int wZepQixJgjxeWkK = -808368722;
    double HIvQnnrj = -225981.01917251834;
    double tzgatJK = 956937.1766306738;

    for (int RNjZY = 1243310173; RNjZY > 0; RNjZY--) {
        HIvQnnrj += WfwuO;
    }

    for (int hIIdVsGFAufN = 579524543; hIIdVsGFAufN > 0; hIIdVsGFAufN--) {
        HntEMVDkoHrI += yEJdstzl;
        BLjzhPWqQEim = BLjzhPWqQEim;
    }

    if (fOLerPFZ <= -225981.01917251834) {
        for (int gmRfakVhFNFx = 270528152; gmRfakVhFNFx > 0; gmRfakVhFNFx--) {
            continue;
        }
    }

    return LAIjE;
}

int cgQnyLrCxGh::xiFSgcnWLPQljvn(string wJHQODelsIqyuXM, bool pprSSncf, bool kejxfSrFbz)
{
    bool WHXJfEYYELodMkL = false;
    int UMGgvuie = -738999043;
    double cCLdsXokR = -422938.0338233079;
    double wqehSOUxRhBsJX = 430017.06818603975;
    string wTZaVkPDZl = string("vdrLfWRD");

    for (int qVNFGacJE = 1285426780; qVNFGacJE > 0; qVNFGacJE--) {
        cCLdsXokR = wqehSOUxRhBsJX;
    }

    return UMGgvuie;
}

string cgQnyLrCxGh::IDMiadNNZ(int sZpnIPKOEZJwxAJi, int ToQDsHYsGxjt, int czfHSoxzRPJ, string qxvWNXBKLLPYUkEH, string OscdjLaBEWttPkTf)
{
    double BwTeQ = -268657.46647726675;
    string jByYwrOklgb = string("CMxEtZmYmdjlABEqJpOVQofKhNryCYNbCHFlTsBYFSqRoxLOJIHneOusODMjBgCtowSBKJvIZKcbwdxpcOmxOGXYBvaieubEHLEpPyZhwnYEpFuOJNTewfipcoTNVFwZukYqAZrgVioXYttuTRCrbWWEbLQgtfBdJpKicffjMeOudeMUkZZOmOZxsiaESKStHKvNNjVDgApIRgzpUsXiUDVPCGtXDbPM");
    string RpGxeYaMzvth = string("NFqZoDpxMIEAnZMhzUXMvvBCHVZghcXJEvByVSflGGeXldANKzinSWTLibbeudARrAlAHmStrjtwZDPokdzUNRtVeyfODeHvHWJcGosXtpRNTGLlvpJrztDJlMCPCWTkNUoFLqjnkeMiGdZHiGEMGDtYvIlsnKyiXAwSAstZAUaAxGTDEIDgbpWJSxk");
    int yTGeoyZqLtBlFHy = 1629909676;
    int gXrLVORQB = -1154440489;
    string pztJbkDRNy = string("MKxAbZA");
    double FaLapieG = 511260.30187190714;
    double gwRfHQd = 438722.10534185334;
    double jNLbkQFwi = -279394.8643821003;
    double eovUcplyJ = 8202.882315771652;

    for (int RLXQCqqgJ = 1146466166; RLXQCqqgJ > 0; RLXQCqqgJ--) {
        eovUcplyJ /= eovUcplyJ;
        qxvWNXBKLLPYUkEH = jByYwrOklgb;
        jByYwrOklgb = RpGxeYaMzvth;
        ToQDsHYsGxjt /= yTGeoyZqLtBlFHy;
        yTGeoyZqLtBlFHy -= sZpnIPKOEZJwxAJi;
        qxvWNXBKLLPYUkEH = qxvWNXBKLLPYUkEH;
    }

    return pztJbkDRNy;
}

double cgQnyLrCxGh::LGoObGnWzouR(string xtKJHeFTSUZBTw, bool NAlxlhUGNbut, double YOWPPjEPHpx, int APnZkM, int wVMImFEZlCm)
{
    bool GgcQWIjmpej = false;
    int DazqTqgfIUDZZKA = 2126326025;
    string PlWPrmWr = string("dKGsBSyodOlOegIrlPtMXpOEfXEgJyMraskMerTOTxJuYElImnIwjrTfwJIwecLYOwjLJJIlIuQrBbioRYbgukMEONWGHVpQkpFgcXznandqzUajuJHSTTAPHqqwVrvoUsQFEThcLCKZpfcErktvYdmtBjyAviPjeMOtDUYHwZiJxwKCA");
    string ZbjmKcdSQiDF = string("NVVZpcRokgKBEciTHpAWDUtRPwhXwUjCtQorJVKBoSYGWwQjqLybNCZsmfGdIQwUkhhdJIMFzdMhFFbLDYmDKDRHyCrMEIVXWeRsyycSPGUAJnLdnFNnpaxcculLHuHEZRlDCXgbivdEXgbcbQlwdokqDRQNTlvaAggfbOxpTLFaoYGdYQQjQrItfrMPcdVbBPlfZnPkJmWJSLiaiDYtHbhRJUwSQIyMJc");
    bool ujzUECUIZdIOh = false;
    double PuyNm = 430218.9530413669;
    double fSuSUhgXcXYdVQ = -26903.096968381178;
    string Uffqjuh = string("ICWwPWmidBBsVImjIejbluQeJfaJBcSx");
    int OMybtRNL = -1540161449;
    int NzHyfh = 1701081906;

    for (int zHxEEsKKhvexr = 1972097558; zHxEEsKKhvexr > 0; zHxEEsKKhvexr--) {
        APnZkM -= wVMImFEZlCm;
    }

    for (int diMBkYmLphY = 920245673; diMBkYmLphY > 0; diMBkYmLphY--) {
        PlWPrmWr += ZbjmKcdSQiDF;
    }

    if (OMybtRNL == -698622983) {
        for (int hZBMECSbmHNh = 935387791; hZBMECSbmHNh > 0; hZBMECSbmHNh--) {
            xtKJHeFTSUZBTw += PlWPrmWr;
            YOWPPjEPHpx = YOWPPjEPHpx;
            ZbjmKcdSQiDF += xtKJHeFTSUZBTw;
            fSuSUhgXcXYdVQ = fSuSUhgXcXYdVQ;
        }
    }

    for (int JEMROhwFxezMU = 758469528; JEMROhwFxezMU > 0; JEMROhwFxezMU--) {
        continue;
    }

    if (DazqTqgfIUDZZKA <= -1540161449) {
        for (int HTuPCu = 390653590; HTuPCu > 0; HTuPCu--) {
            ZbjmKcdSQiDF = ZbjmKcdSQiDF;
            OMybtRNL *= APnZkM;
        }
    }

    return fSuSUhgXcXYdVQ;
}

double cgQnyLrCxGh::fuARJgd(double ARNCuQHasnTuk, int rVKPqGioa, bool ogxyvxF)
{
    double QMyKjrSlQUBlTP = -615920.2922310956;
    int ldMYKQsPJ = 1147465463;
    bool kFUsvtPdFyFzjE = true;
    string vfGFnPEuhHJ = string("wXqhyEjPCuaOVvMpuKZzTmqPjzWJDxYZCqKUKjhhKLJyUvcbWNbYPSJwByPMKeqRXLOoysaRbZxkdXPGVUBmghziMqrDlugvNqppVtgAoVHzfzBqdYzVbyjrpsktvX");
    double fLigcbzKHZObRQVq = 29589.141265899416;
    bool UuizeFlFFsi = false;
    int RroOaSutWGIAfgLr = -1146200204;

    if (ogxyvxF == false) {
        for (int MmHrxviEz = 1002058980; MmHrxviEz > 0; MmHrxviEz--) {
            RroOaSutWGIAfgLr += ldMYKQsPJ;
        }
    }

    for (int rZclMHCxSlcfYmD = 786598897; rZclMHCxSlcfYmD > 0; rZclMHCxSlcfYmD--) {
        UuizeFlFFsi = ogxyvxF;
        vfGFnPEuhHJ += vfGFnPEuhHJ;
        fLigcbzKHZObRQVq = fLigcbzKHZObRQVq;
        ARNCuQHasnTuk += QMyKjrSlQUBlTP;
    }

    if (RroOaSutWGIAfgLr >= 1147465463) {
        for (int GPQvcwvXRa = 2127563958; GPQvcwvXRa > 0; GPQvcwvXRa--) {
            kFUsvtPdFyFzjE = UuizeFlFFsi;
        }
    }

    for (int ALrFBhdBvtqz = 1152916379; ALrFBhdBvtqz > 0; ALrFBhdBvtqz--) {
        vfGFnPEuhHJ = vfGFnPEuhHJ;
        UuizeFlFFsi = ! ogxyvxF;
        QMyKjrSlQUBlTP *= fLigcbzKHZObRQVq;
    }

    for (int WdQjHbfSQ = 673871372; WdQjHbfSQ > 0; WdQjHbfSQ--) {
        continue;
    }

    for (int nHchueQWhP = 715457602; nHchueQWhP > 0; nHchueQWhP--) {
        fLigcbzKHZObRQVq /= ARNCuQHasnTuk;
    }

    return fLigcbzKHZObRQVq;
}

string cgQnyLrCxGh::WuPaD(int VasMmCqTV, int ugDPoHCyKZhw, double reiKu)
{
    string HIJweUhLHkW = string("iTLbzMrnrbeZZKrrkOYsfziSHvecGKlugCgvUymTgXZYNuvphGuABcGpkPYdSRWmmkpIPfmOWOxloXCSyhdyxYyfkJBszBMqWfhrWccqFZMGAapthEECpxQDtglAQqXtiKcZTRjXtBZDUYVoTtZwmFdBBIhmuhhgxRtYyOzmVzVciISUMmCzCYaUvXSrxroXJOHemnmatodlwoOQcmBpLkaBWzfaF");

    for (int BeslSWeTj = 515604084; BeslSWeTj > 0; BeslSWeTj--) {
        ugDPoHCyKZhw /= ugDPoHCyKZhw;
        VasMmCqTV = VasMmCqTV;
    }

    for (int wTWnbutS = 518247470; wTWnbutS > 0; wTWnbutS--) {
        VasMmCqTV = VasMmCqTV;
        HIJweUhLHkW += HIJweUhLHkW;
    }

    return HIJweUhLHkW;
}

bool cgQnyLrCxGh::oMCMmINxMsXGyLh(bool OgopBZANwoXTFN, double TrynQOgolHICCrqH, int jhuHwHrlg, double JLjYaKAzgWlPiIt, bool adjuIqB)
{
    bool iDrYKkhZRaZoz = false;
    int ftwUwqMnUbqnNBcp = 816533373;

    if (JLjYaKAzgWlPiIt <= 71233.2202458815) {
        for (int NBvVwqoufLyF = 1422496668; NBvVwqoufLyF > 0; NBvVwqoufLyF--) {
            adjuIqB = ! iDrYKkhZRaZoz;
            iDrYKkhZRaZoz = ! iDrYKkhZRaZoz;
            iDrYKkhZRaZoz = iDrYKkhZRaZoz;
            JLjYaKAzgWlPiIt += TrynQOgolHICCrqH;
        }
    }

    for (int FqVztPVq = 948319816; FqVztPVq > 0; FqVztPVq--) {
        OgopBZANwoXTFN = ! adjuIqB;
    }

    for (int iNlMvlEVK = 620145121; iNlMvlEVK > 0; iNlMvlEVK--) {
        ftwUwqMnUbqnNBcp *= jhuHwHrlg;
    }

    for (int MJawORBSxhRQm = 1363644346; MJawORBSxhRQm > 0; MJawORBSxhRQm--) {
        iDrYKkhZRaZoz = ! OgopBZANwoXTFN;
        adjuIqB = OgopBZANwoXTFN;
        OgopBZANwoXTFN = ! adjuIqB;
        jhuHwHrlg *= jhuHwHrlg;
    }

    for (int OqXZqjyPUWFTC = 118403875; OqXZqjyPUWFTC > 0; OqXZqjyPUWFTC--) {
        iDrYKkhZRaZoz = ! iDrYKkhZRaZoz;
        JLjYaKAzgWlPiIt *= JLjYaKAzgWlPiIt;
    }

    return iDrYKkhZRaZoz;
}

cgQnyLrCxGh::cgQnyLrCxGh()
{
    this->FcXCttyTMNChb(true, string("SUrSsSbuEbCVsQdWjLVZDUfINsQWriupYTyPwsgZemobfVHFdGJZUzldcUrBDohkfdUOVpcdSnxSIByKqpXgJbGefcoFRJwTNxgrkGtIlcZiaBPQEWTSsfMCjsPOZGNZfovyrfKw"), -294177.6495968471, -555941740);
    this->dpgSJjppop(true, -539046.8004860954, string("FWhYVCzjcrGvTORfKXkaZrbCxVdeMyzIBIRpwjHuKcXFzDLyW"), -251587.1161344081, 838328892);
    this->qyowRrsCVuUb(121719.8809515168, 1986971243, false, 528939.681468416, false);
    this->iCfjcLdOm(-679507.9977959567, 52258977, true);
    this->xiFSgcnWLPQljvn(string("CSWwCjCzBFVokHUQtrwhVYvSAqxxKlvymCMilnGKgFLubQuaZzwkNknvNeLOdRJIRfRJLbmqtvHKtX"), false, false);
    this->IDMiadNNZ(-298771403, -73747764, 978700351, string("gyuIPvqeScDjokGcehHbRblIUmcQNdUIatAeiVygeqwtdmcBRxtFDHrWXONbgCAZnpaRGddwBvgVCkjSgatrugBtrwsMppoRCbgPNuDbSiPaBLsmEcqlyfWOBwTDVGeXpQLVQktmXRFGArkhzeqsnkUOAPwQvzjDx"), string("cLZcGTYzrFFAxSytTLcPLDhUuQuWEImTHUwkZcCTrHzcpGdOWbPfZoYuq"));
    this->LGoObGnWzouR(string("JdTiPhjosbVNfnXvJi"), false, -632808.9391261966, 1136518667, -698622983);
    this->fuARJgd(560996.2869595499, -1432266269, true);
    this->WuPaD(1001539755, 1409316313, 355691.53341940953);
    this->oMCMmINxMsXGyLh(true, -669265.5589237964, 251894506, 71233.2202458815, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BOXYk
{
public:
    string kdocQbrQrSttnRSu;
    double qCJndGKoQATvJZ;
    string BdQrYZoYeG;

    BOXYk();
    void AhSzJozRWADZDYU(double KiwaVOchd);
    int ilnWtltOoU(int UaJSfQamjWKukcd, bool DkHwUvoStfsg, int qmSlvQb);
    void ZpkOQr(double OhAmFIOdRSEKhqf, int ORVzrUzCIi, int ijYHJeyhC, bool eBqmVhL, double XBqHpXgOqB);
    int okJlEN(double UrcrmGoxUP, string oUiXtzbqmCUHeZ, bool LFkac, int UyfVqg, int KBDlgbUvPqdWWF);
    string AXyzPwTRgqamKK(double AadZURMCoNqM, bool SamdiW, bool VyeudveN, string KZGFzlPnGnE);
    void DfQCtUaHcBJOK(bool wvCuOcISS);
    string WmfSrnzj();
    void zKZbawHP(double jQVbKVSK, double NEwFJeKxQtoLwNmz, string xfvuHZtsQNKaQ, bool YKhKSN, bool dRuXTdUqxy);
protected:
    double LxGGoBdgTHH;
    string bRMFjwPsJbisuGP;
    int gpivqonw;
    bool aWQkitajNTymH;
    double QCrKp;
    int QNOLdagwyEjj;

    double TCUTD(string FOEdC, bool VSVJpMXwqa, int vWwELspneEYZyUq, string yGsXsm, double UUxCaXUlDnoIIDN);
    void YxqFxVbHff(int ENQOlFihuLFOn, double gWFkfWuslRQ, int hbxSnJdVTsNjqN);
    int NZCtPq();
    string KTbEuEVLJaIg(bool anTWUGlN);
    bool KJRHFK();
    double vJKfEiMRtety(int tyZbeFKigNKPvv, double KkPVvjRNf, int rLXWCXuT, bool YmMpULD, int Rwxrsbpj);
    bool DxfhSgDTDtAtDQT(bool rlYCQeMx, string zpeSaDiSBj, string XpExvDNfXgpoRdj, bool GXIvc);
    void tyVwSLuAfH(int HlAdUMCCH, double KqXkDmnJxMp, bool QIIMvP);
private:
    int fWrGMKc;
    int yzSvvIprRbZByBp;

    void gbZfEVwt();
    double SjxUuFXdrHtBDXr(bool EjcvjwTfQchAbVX);
    string svFoPRcMA();
    double pDlsXslP(double CxqAFApHzqgeZXy, bool aqRfxfGQXEUHXK);
    void ZUwuA(double flIcqkePU, double nBwXwziuX, string faZoCiG, bool OMhIBBBEy, double spmxg);
};

void BOXYk::AhSzJozRWADZDYU(double KiwaVOchd)
{
    int CNFLTEbPfovVAKgh = -643548295;
    string WiJbuYPKVqcbXukN = string("yaqhZUUSaKDVECkUCIEcaDFJCwcvMFihQWdRdfBbpyVLJeAaKFRmqGKZEuCjDZWQDWLXxjpVIPyRtRFVButPVXJuvYYSDVkfDxjXWxufBNRsSbXTkk");

    for (int DhFCxGeReKsScMJp = 234118513; DhFCxGeReKsScMJp > 0; DhFCxGeReKsScMJp--) {
        continue;
    }

    if (WiJbuYPKVqcbXukN > string("yaqhZUUSaKDVECkUCIEcaDFJCwcvMFihQWdRdfBbpyVLJeAaKFRmqGKZEuCjDZWQDWLXxjpVIPyRtRFVButPVXJuvYYSDVkfDxjXWxufBNRsSbXTkk")) {
        for (int oDdRolcq = 642953634; oDdRolcq > 0; oDdRolcq--) {
            continue;
        }
    }

    if (CNFLTEbPfovVAKgh != -643548295) {
        for (int aAqhHijTgBvDJDG = 1155162909; aAqhHijTgBvDJDG > 0; aAqhHijTgBvDJDG--) {
            continue;
        }
    }

    for (int VebQGvHAGnV = 1432785026; VebQGvHAGnV > 0; VebQGvHAGnV--) {
        KiwaVOchd -= KiwaVOchd;
        WiJbuYPKVqcbXukN = WiJbuYPKVqcbXukN;
    }
}

int BOXYk::ilnWtltOoU(int UaJSfQamjWKukcd, bool DkHwUvoStfsg, int qmSlvQb)
{
    string fJFSFqLf = string("IAythTuiPhUfzjjxVqGIrVjeZbBIEXWqp");

    for (int WypGDx = 1509811524; WypGDx > 0; WypGDx--) {
        qmSlvQb = UaJSfQamjWKukcd;
    }

    for (int cBnVj = 125024560; cBnVj > 0; cBnVj--) {
        UaJSfQamjWKukcd /= qmSlvQb;
        qmSlvQb = qmSlvQb;
    }

    if (UaJSfQamjWKukcd > 1842801517) {
        for (int UowXNiWSiGoPg = 1884353713; UowXNiWSiGoPg > 0; UowXNiWSiGoPg--) {
            fJFSFqLf = fJFSFqLf;
        }
    }

    for (int jdCwyZUWpn = 1900078299; jdCwyZUWpn > 0; jdCwyZUWpn--) {
        continue;
    }

    for (int zokKOiJ = 408766187; zokKOiJ > 0; zokKOiJ--) {
        UaJSfQamjWKukcd *= qmSlvQb;
    }

    if (UaJSfQamjWKukcd > 1842801517) {
        for (int CNlumw = 1470990578; CNlumw > 0; CNlumw--) {
            qmSlvQb -= qmSlvQb;
            DkHwUvoStfsg = DkHwUvoStfsg;
        }
    }

    return qmSlvQb;
}

void BOXYk::ZpkOQr(double OhAmFIOdRSEKhqf, int ORVzrUzCIi, int ijYHJeyhC, bool eBqmVhL, double XBqHpXgOqB)
{
    string SDFFfIhcJIrr = string("YPJItQtjnOnOmkQQRfCwxFbiLnIDxcogHXfQQZlakHLPGtiFZUb");
    double enVDuSBGPOkbSIa = -281380.98421071353;
    int FSPVCCkjDnkUBUs = 1171172066;
    string ivTBblSTov = string("sjjKpsIbDxyfLZURmVNYSQMHCMaAMXALDQqulnleYLjtJAHQLxOmTdHNMdXYdZxJvIqlIQkJJADeAwUCffONJLhpDyjPgPntWVZmoTTjZDbJPqShhSzvIBTPxVQtL");
    double UzbSdXMAwyoRyUby = 449108.62441175047;
    bool dWNyOrnNUwZBGsf = false;
    int PqEcmRgwmEDyIdJ = -1751322228;
    string qMyrnJDVqRQ = string("staqgmFNWauQLSewHBBjCJPriMuVncTJEdSNOPFiyQMDfFRqvSAeUhTugPGWKyTxWbQTvzqovGpBUVAnKpmJbVWWMbuxpFcZTcNsvYdtArtrdQCHRqiiGHTowqpLmmjpzQpuOpQyYSKUbrXpvXpSQDRNRTNzizxN");
    double LJFexn = -421561.69212516304;

    for (int HeYNK = 23678067; HeYNK > 0; HeYNK--) {
        ORVzrUzCIi *= ORVzrUzCIi;
        ORVzrUzCIi *= ijYHJeyhC;
    }
}

int BOXYk::okJlEN(double UrcrmGoxUP, string oUiXtzbqmCUHeZ, bool LFkac, int UyfVqg, int KBDlgbUvPqdWWF)
{
    bool OjBTwVV = false;
    bool fSLMB = true;

    for (int TfIxtJNoXi = 577857671; TfIxtJNoXi > 0; TfIxtJNoXi--) {
        continue;
    }

    if (fSLMB != true) {
        for (int aNkdaR = 1999200579; aNkdaR > 0; aNkdaR--) {
            UrcrmGoxUP *= UrcrmGoxUP;
        }
    }

    for (int eLkBi = 988829706; eLkBi > 0; eLkBi--) {
        OjBTwVV = ! LFkac;
        UrcrmGoxUP *= UrcrmGoxUP;
    }

    for (int uVSFysyjQyyZt = 1267788529; uVSFysyjQyyZt > 0; uVSFysyjQyyZt--) {
        LFkac = fSLMB;
        LFkac = LFkac;
    }

    return KBDlgbUvPqdWWF;
}

string BOXYk::AXyzPwTRgqamKK(double AadZURMCoNqM, bool SamdiW, bool VyeudveN, string KZGFzlPnGnE)
{
    string LHILXCSl = string("hTEdYiaeCxyygoBUOamYyqVugXYsywEbCjlRZzulSLDzzqBXYSFfBmZQWs");
    int rmHfB = -436305038;
    int JsHsKGP = -1946116380;

    if (JsHsKGP == -1946116380) {
        for (int dqTVP = 1672547451; dqTVP > 0; dqTVP--) {
            KZGFzlPnGnE += KZGFzlPnGnE;
        }
    }

    for (int rKlwcbzagMo = 1025987423; rKlwcbzagMo > 0; rKlwcbzagMo--) {
        KZGFzlPnGnE += KZGFzlPnGnE;
    }

    return LHILXCSl;
}

void BOXYk::DfQCtUaHcBJOK(bool wvCuOcISS)
{
    int rhKAtCSAKJ = -1544137003;
    string AwBDqiJWm = string("fMZcmAVFvkZzVddIIjwEQWOpGhaXyDtklqkqdNVqWLmcikaUquYWDJmJCUpvaGMSXxuMDeqiCoXqrvYoWosavhybllbWBCiDixiRIfwzgqCtKxCorsffhRRGLZnpFcvvHKSZpQxyiRsmTNoXRhvOECXLbilCQYAHMHpOnKDgGmxIUjsqxJiyioKfVDgGATRAmTRslamRrMVAQzGFxdQGTIEkSqq");
    double FezziZwXspWpoNP = 550703.8194076908;

    for (int ayivrF = 2020715171; ayivrF > 0; ayivrF--) {
        continue;
    }

    for (int SqBnnSjZPUMu = 255973202; SqBnnSjZPUMu > 0; SqBnnSjZPUMu--) {
        rhKAtCSAKJ -= rhKAtCSAKJ;
    }

    if (rhKAtCSAKJ >= -1544137003) {
        for (int DOICrbFOTc = 1343654220; DOICrbFOTc > 0; DOICrbFOTc--) {
            wvCuOcISS = ! wvCuOcISS;
            AwBDqiJWm += AwBDqiJWm;
            AwBDqiJWm += AwBDqiJWm;
        }
    }

    for (int WirFZG = 1177035539; WirFZG > 0; WirFZG--) {
        rhKAtCSAKJ *= rhKAtCSAKJ;
        FezziZwXspWpoNP -= FezziZwXspWpoNP;
    }

    for (int OEsvCGSgrLBco = 1902888670; OEsvCGSgrLBco > 0; OEsvCGSgrLBco--) {
        rhKAtCSAKJ *= rhKAtCSAKJ;
    }

    for (int MdZcjYnZ = 1642388682; MdZcjYnZ > 0; MdZcjYnZ--) {
        continue;
    }
}

string BOXYk::WmfSrnzj()
{
    string PyigHzTq = string("sWCfzcCvAUpSjOWKkJqhhApeLkGURmlwbbJzMhJNzAEkKsYfjJrsBfkXqIZpuCSkCaIMHpqOBPUxEOJhdBptdVMcNegRksfgpQxIPLHnQyfxxmvAyNySZOBOnWnHZoVNVGPPAbZBmxuqcBcRFpELUkeiSneExXTAKrEjwPRknUbElYOtGGorlIhFyqcxTzAJmOIhIIEpSQRGKTPhtbIqoQxhQzkPeY");
    string ZeuYJXesbvTzvOfA = string("QMXRMEHpnLfgzPWhlanTYWxFjygKGIgtuyjIXAiwxFBiqszZYmQwxVWcIATJYNmRwNMINwagnyOjBDrmWlemBZoWofMgcmkEjSnwhzKZApFjmOwNEZEYsWYzcxresBnCgQpiLtHFZrcNoFWJHxKyvFPNIdXVaPjEDygeGXfohQjSzIKLjSPdmdBTTAoBEZSwGJidTWiwUfiJFbed");
    double IBYBJSVprTxIV = 990321.5538952443;
    string wMUfMVrjVdQ = string("fozYZnGiALnqNVUqJOuagtWJFkkusLshpHkWZJLXHYxEcJQKtqdWfBGCazmJXINSRMbTQ");
    int DxmTmhvBfrcU = -1278227735;

    if (wMUfMVrjVdQ == string("QMXRMEHpnLfgzPWhlanTYWxFjygKGIgtuyjIXAiwxFBiqszZYmQwxVWcIATJYNmRwNMINwagnyOjBDrmWlemBZoWofMgcmkEjSnwhzKZApFjmOwNEZEYsWYzcxresBnCgQpiLtHFZrcNoFWJHxKyvFPNIdXVaPjEDygeGXfohQjSzIKLjSPdmdBTTAoBEZSwGJidTWiwUfiJFbed")) {
        for (int cJYSFOvc = 912198686; cJYSFOvc > 0; cJYSFOvc--) {
            wMUfMVrjVdQ = PyigHzTq;
            ZeuYJXesbvTzvOfA = ZeuYJXesbvTzvOfA;
        }
    }

    if (ZeuYJXesbvTzvOfA >= string("QMXRMEHpnLfgzPWhlanTYWxFjygKGIgtuyjIXAiwxFBiqszZYmQwxVWcIATJYNmRwNMINwagnyOjBDrmWlemBZoWofMgcmkEjSnwhzKZApFjmOwNEZEYsWYzcxresBnCgQpiLtHFZrcNoFWJHxKyvFPNIdXVaPjEDygeGXfohQjSzIKLjSPdmdBTTAoBEZSwGJidTWiwUfiJFbed")) {
        for (int fPzztC = 1235427399; fPzztC > 0; fPzztC--) {
            ZeuYJXesbvTzvOfA += wMUfMVrjVdQ;
        }
    }

    return wMUfMVrjVdQ;
}

void BOXYk::zKZbawHP(double jQVbKVSK, double NEwFJeKxQtoLwNmz, string xfvuHZtsQNKaQ, bool YKhKSN, bool dRuXTdUqxy)
{
    double OpkAzxYRJiHo = -109964.32442984388;
    double BeSVdhbPsNhlXSMj = 286824.2829770392;
    string daneqNSMwOy = string("nQCNCCGLVDNwUUAOUHbfEVeWIAxokGwQOyskyOeCYRxKpDUqpxFaeLdKyFwmLlEFHNovBTTxFPDGMetvCehkaBOBZstblMSQQgtrdRaKZpgLmQwrcvEVbcjBNsmOUjexRMQtbiKNVXCZVAmFaNUjOEbElnGpyVARofDpcFXwZhuHffMelWkEkSRYsIEhRfGDZGpjdjvngISMncrdOnhpffSKDvRWfvASuFKQHBZgQlTiowxWjkWfR");
    string uMKGfKYHzKZ = string("CaBSFVyaRwTtskzTTTcACmiISsCiFpDrujPIQrKMlqtRWidMJpkaybnAibvMvEFPXuuCExPVtCEOGRVFATPGIZDdJrnEcJQASLMWGyZgDjHJFrGvNOVosDnQrIvHiclSuehOlcaJQjcWEYNhGKUbwEfWbHGZmvIZQjYuGHAKAcKFodKhXpHArOcNapsbCINPtQgcJiyGGxOFRAlLRkoqVxHJqwRChbzqfOT");
    string btMbJYkGvQDG = string("gceLWMDvSDlrIkaeiadFcpSFgJEsSyosr");
    double YkifKQWnp = -182610.3243503443;

    if (uMKGfKYHzKZ == string("CaBSFVyaRwTtskzTTTcACmiISsCiFpDrujPIQrKMlqtRWidMJpkaybnAibvMvEFPXuuCExPVtCEOGRVFATPGIZDdJrnEcJQASLMWGyZgDjHJFrGvNOVosDnQrIvHiclSuehOlcaJQjcWEYNhGKUbwEfWbHGZmvIZQjYuGHAKAcKFodKhXpHArOcNapsbCINPtQgcJiyGGxOFRAlLRkoqVxHJqwRChbzqfOT")) {
        for (int YFYYcYwdGZuCFgHn = 1672576580; YFYYcYwdGZuCFgHn > 0; YFYYcYwdGZuCFgHn--) {
            uMKGfKYHzKZ = xfvuHZtsQNKaQ;
            jQVbKVSK -= NEwFJeKxQtoLwNmz;
        }
    }
}

double BOXYk::TCUTD(string FOEdC, bool VSVJpMXwqa, int vWwELspneEYZyUq, string yGsXsm, double UUxCaXUlDnoIIDN)
{
    bool NaiXQW = true;
    string PvHDPgezaUQpY = string("oKodKerfRkqqcjnCzyFbwdNlUQKhUNIQTAENqbkdrRlOmUPgwknIfvWzSiGSjawsoWbnpKjuUOsSQTqnGhZzfhdKzAfzVDzdMLOCBmlAmBr");

    if (yGsXsm > string("NrWrjswIiLVBDfxgxsmeYAScjOlDIYvV")) {
        for (int pimSwFDJMt = 407187730; pimSwFDJMt > 0; pimSwFDJMt--) {
            continue;
        }
    }

    if (yGsXsm == string("oKodKerfRkqqcjnCzyFbwdNlUQKhUNIQTAENqbkdrRlOmUPgwknIfvWzSiGSjawsoWbnpKjuUOsSQTqnGhZzfhdKzAfzVDzdMLOCBmlAmBr")) {
        for (int UivAaMNEaLrnSA = 1003252585; UivAaMNEaLrnSA > 0; UivAaMNEaLrnSA--) {
            vWwELspneEYZyUq *= vWwELspneEYZyUq;
            FOEdC = FOEdC;
        }
    }

    if (yGsXsm == string("bqGzLMhZCpuBRPqOMzcXzFTfHkIILJQRAEcquswBhmEPijrOjaWdhrcaMLdTvSHIHEGimdgkdhHMMazKbRyx")) {
        for (int iJGCxjuoIiWaJji = 2134350074; iJGCxjuoIiWaJji > 0; iJGCxjuoIiWaJji--) {
            continue;
        }
    }

    return UUxCaXUlDnoIIDN;
}

void BOXYk::YxqFxVbHff(int ENQOlFihuLFOn, double gWFkfWuslRQ, int hbxSnJdVTsNjqN)
{
    string YEPFe = string("EPBKXwKxzLssKDQrjkxsomZFtQrZDWLaCXVWcaBeadrOqiTSpeTOioAlHZjFhGXfhJsIxcKUPfaaCRtIsBkXCwTKalfoywltfivNjhBGMBSzKkbzsSOLEkwaJZXcotIAMIYPndPBfcofSLTwfmGdUmmrtWhIjFqvdyCvHxzSrAAwNkyccmAgCuhVZlGtzaLrEWFyliuJaxfqWGPkiIubfpFEEwuSFNvYCANxVOpiBWMsarSLJZutzwp");
    bool bkwyd = true;

    for (int gYwEan = 1850529302; gYwEan > 0; gYwEan--) {
        gWFkfWuslRQ /= gWFkfWuslRQ;
        hbxSnJdVTsNjqN *= hbxSnJdVTsNjqN;
    }

    for (int fxYae = 1701594879; fxYae > 0; fxYae--) {
        hbxSnJdVTsNjqN /= ENQOlFihuLFOn;
        ENQOlFihuLFOn /= hbxSnJdVTsNjqN;
        YEPFe = YEPFe;
        bkwyd = bkwyd;
    }
}

int BOXYk::NZCtPq()
{
    int qzLMTtYnozDLwl = -642326167;
    string abaVVS = string("pcBSBzehqobpvpcyPJMalbKquZbOzZLnzzanmikRMyKkwRXGCorRVpFEXHMpLMxTPyRXRkIusdjGMnRbDVCRWjumbSpMOjOXqFREoSMLjICZlzjEjHrVvmBNAFSPpQmbRfErHlJpNZvOIRlvIYZBZOyZhJ");
    string KZCdQvxDTyWB = string("vOTNvdNxNdmjJkXQkyychcOwIxeSEvdwMyzwHSiTFrxTIZsBPpiXGwTQkREKkXgNKdKfAfULeuvNvAqZuszzNuQDaRYKkVGuoRkHoQarBSYMJEKKAtfnqDBnYWlCFcNwksXBmIZNkTiGVTHCXEzDtnUKHmpuzrPJjubqrPECZXwxZrZSDDLthftx");
    double aSGqwewxF = 735783.6465185904;
    double AqPqFsIzNJcBo = 526950.1313859335;
    double cselURH = -986621.4629267718;
    string QSTHfvDw = string("XrihZNYnuXSscltmTlyVXFAMVHpTBczWFZwWqSXUyGSDubMQAoqxwGdSKZfTBsrHIxLQbynsPMXeYyDIHYvGmTCfRNjZRgRGZavubKXnfhJpdDyRfFPEplXRIxazunvhJecehlxVqXjFbvPfWOyPotLXLOJqE");
    int jtHTIHv = 30535323;
    double nsWmvt = -997178.0897681601;

    if (aSGqwewxF >= 735783.6465185904) {
        for (int jqiVeJKFGZ = 2059353929; jqiVeJKFGZ > 0; jqiVeJKFGZ--) {
            aSGqwewxF = AqPqFsIzNJcBo;
        }
    }

    return jtHTIHv;
}

string BOXYk::KTbEuEVLJaIg(bool anTWUGlN)
{
    bool FzhFoekiTsUjs = false;
    bool uUJZJjmpUQpx = false;
    bool vsUkDAQyawso = true;
    string gDIFTzpt = string("usRakfuLRKWVuBGKqoihAvmYWEGHBBeEmzWxvDCJzXggCRShjNwcgGmsEKoFJYpUviGoMSNJoaDqqnLphOkMuNylpfmDKHUtcaSWUFMUSHvZcVxNrUhKWEUOrHpIvaAnciPXGBxCOHUlfDLVABicQUgxrVnEUBogTDDeFcTbUNZloAbKgilQmWBaeGvYVVKYJTHTISFUsgpqwkLdQXloQtpHbBYIKeudNjYtdatJFwVGMVkBsyGRcydjgkuxXo");
    double UYKnqWqhJeX = -1000980.1081056811;

    if (anTWUGlN == true) {
        for (int fcAIoKEsKZSVAKgx = 2029246408; fcAIoKEsKZSVAKgx > 0; fcAIoKEsKZSVAKgx--) {
            vsUkDAQyawso = uUJZJjmpUQpx;
            gDIFTzpt += gDIFTzpt;
            anTWUGlN = anTWUGlN;
            anTWUGlN = ! uUJZJjmpUQpx;
            vsUkDAQyawso = ! vsUkDAQyawso;
        }
    }

    for (int qCwxfqqEoNFapOmo = 1174647100; qCwxfqqEoNFapOmo > 0; qCwxfqqEoNFapOmo--) {
        uUJZJjmpUQpx = ! uUJZJjmpUQpx;
        uUJZJjmpUQpx = ! uUJZJjmpUQpx;
        FzhFoekiTsUjs = FzhFoekiTsUjs;
        uUJZJjmpUQpx = uUJZJjmpUQpx;
        gDIFTzpt = gDIFTzpt;
        anTWUGlN = ! FzhFoekiTsUjs;
    }

    for (int KNCiqUBZYYANeOrP = 204235722; KNCiqUBZYYANeOrP > 0; KNCiqUBZYYANeOrP--) {
        anTWUGlN = ! vsUkDAQyawso;
        uUJZJjmpUQpx = FzhFoekiTsUjs;
    }

    if (anTWUGlN == false) {
        for (int zTQfE = 1232605382; zTQfE > 0; zTQfE--) {
            vsUkDAQyawso = FzhFoekiTsUjs;
            uUJZJjmpUQpx = ! uUJZJjmpUQpx;
        }
    }

    if (vsUkDAQyawso == true) {
        for (int hpybe = 1319897002; hpybe > 0; hpybe--) {
            FzhFoekiTsUjs = anTWUGlN;
        }
    }

    if (uUJZJjmpUQpx == false) {
        for (int flTdvuJOYo = 338963330; flTdvuJOYo > 0; flTdvuJOYo--) {
            FzhFoekiTsUjs = ! anTWUGlN;
            FzhFoekiTsUjs = ! anTWUGlN;
            anTWUGlN = ! uUJZJjmpUQpx;
            UYKnqWqhJeX *= UYKnqWqhJeX;
        }
    }

    return gDIFTzpt;
}

bool BOXYk::KJRHFK()
{
    bool EwSiPZnpW = false;
    string zlvWPy = string("mERzUMOiynSwkOMvhBzNpJAwYwTDocDYFxjNADfLFSsnDqHfQXIegkwrrmGSGaIXvYazDKHsOFgPPNVyLy");
    int nMYdGWANEGm = 1610063206;

    if (nMYdGWANEGm >= 1610063206) {
        for (int wZGFRipKJy = 2106012272; wZGFRipKJy > 0; wZGFRipKJy--) {
            EwSiPZnpW = ! EwSiPZnpW;
            zlvWPy += zlvWPy;
        }
    }

    for (int YiBazIuSuqen = 1835402988; YiBazIuSuqen > 0; YiBazIuSuqen--) {
        continue;
    }

    for (int zLjozzetZGuqxw = 1684081328; zLjozzetZGuqxw > 0; zLjozzetZGuqxw--) {
        continue;
    }

    if (nMYdGWANEGm != 1610063206) {
        for (int rqHrlgCOvrDlM = 2057049537; rqHrlgCOvrDlM > 0; rqHrlgCOvrDlM--) {
            zlvWPy += zlvWPy;
            zlvWPy += zlvWPy;
            EwSiPZnpW = EwSiPZnpW;
        }
    }

    return EwSiPZnpW;
}

double BOXYk::vJKfEiMRtety(int tyZbeFKigNKPvv, double KkPVvjRNf, int rLXWCXuT, bool YmMpULD, int Rwxrsbpj)
{
    int sHpwOjsEyoGRnQz = 750205369;
    int oiYKTOyihkDzd = -852573548;
    bool EUaXecu = false;
    bool qnMyCcdvAdE = true;
    int maSTQDCocVBbYB = 795075857;
    string dyqnwHh = string("iOJLiLSvmwlgDgvjiVyUcLbPmfOTyUErUJJdMRDvYNMiKSNLrcNVDROBjybauXRPzeDsqooONSQBqEnfgzxkrcpXjxFOEQJwZjSXhIPGrxbSliyKZfHLkZAZTwSKKxlmqekDbhDTsQKEDDTd");
    bool xbcmLw = true;
    bool PgBRdRLvIyLMhar = false;
    bool oYwmJNJpE = true;

    for (int JOAszZqKjmPr = 1379827603; JOAszZqKjmPr > 0; JOAszZqKjmPr--) {
        oYwmJNJpE = EUaXecu;
    }

    if (Rwxrsbpj > 795075857) {
        for (int RihTPfVjMZydx = 1614699245; RihTPfVjMZydx > 0; RihTPfVjMZydx--) {
            continue;
        }
    }

    return KkPVvjRNf;
}

bool BOXYk::DxfhSgDTDtAtDQT(bool rlYCQeMx, string zpeSaDiSBj, string XpExvDNfXgpoRdj, bool GXIvc)
{
    int EXRsWo = -724921576;
    bool uOKviZ = false;
    int rxuCTUKt = -870113636;
    int IicCbEACKrJY = 868805819;
    bool oABzIAXdYAVQ = true;
    double YuyZXlnZb = -177707.53576765367;

    for (int rPyKAwmXo = 1279112434; rPyKAwmXo > 0; rPyKAwmXo--) {
        GXIvc = ! uOKviZ;
        YuyZXlnZb *= YuyZXlnZb;
    }

    for (int SQqumo = 1760904322; SQqumo > 0; SQqumo--) {
        continue;
    }

    return oABzIAXdYAVQ;
}

void BOXYk::tyVwSLuAfH(int HlAdUMCCH, double KqXkDmnJxMp, bool QIIMvP)
{
    int ejZrTrTPSRk = -695468298;
    int bOFAVz = -983932195;
    double nSDiSuckI = -1022806.2240788146;
    int VmaEUhjHzgwlEjOu = 1026727855;
    int wcSGgvu = -18766715;
    string lKQukxtYi = string("RtRkMXEgYLTMLYcBpmnmgXikYKboCoiSSkHaddxsuNUVKVmOBgjiePmprwxzXvUvzRfBrjPaOMxeRtyMeqkkeMaznYYDgUTUYTbdmsLrMDuRzwZFUCzz");
    double iOgsJTxRB = 625750.9631681442;

    if (QIIMvP == true) {
        for (int tTDHSUZKCFmZ = 1292088549; tTDHSUZKCFmZ > 0; tTDHSUZKCFmZ--) {
            continue;
        }
    }

    for (int SdUGSgM = 209546959; SdUGSgM > 0; SdUGSgM--) {
        wcSGgvu -= wcSGgvu;
        iOgsJTxRB += iOgsJTxRB;
    }

    if (nSDiSuckI >= -1022806.2240788146) {
        for (int CNafspts = 1243039967; CNafspts > 0; CNafspts--) {
            ejZrTrTPSRk -= bOFAVz;
        }
    }
}

void BOXYk::gbZfEVwt()
{
    bool CUmXjIxjAPgWBD = false;
    int DXAMYMHPuWHj = 1416921132;
    int umsAdSUzbgblkrNs = 223488631;
    double QxMHtntWHUePRv = 153523.4045452802;
    bool WyqvgxNQwiTi = true;
    string ZwGBykOwKyx = string("RsAiCGFwltKUyKtFFBtdeZhuXnUTxvVbBxkQgFMIcQsERYCJLCRSdlStzdDyMpTCwNDUSvMWszYCKIDorMJbFTztLnMZaMDZJDKHGOVVCYzjyAwMFbJzmkemTYbTdonLEeRXfZiPIEBPmLlapzDZqFXJcNlFIlHYEzoiVWXmDfllQuRhxJoYeMTypUuQiaPKojnUeXfSLSlYisRpYIRFIQfggfsijYxcXL");
    double shPQjKBUcfUgMDNl = 217022.36437528618;

    if (umsAdSUzbgblkrNs == 223488631) {
        for (int dIniQti = 850491312; dIniQti > 0; dIniQti--) {
            QxMHtntWHUePRv = QxMHtntWHUePRv;
            QxMHtntWHUePRv /= QxMHtntWHUePRv;
        }
    }

    if (CUmXjIxjAPgWBD != true) {
        for (int AmYJTarz = 562801473; AmYJTarz > 0; AmYJTarz--) {
            CUmXjIxjAPgWBD = ! CUmXjIxjAPgWBD;
            CUmXjIxjAPgWBD = CUmXjIxjAPgWBD;
        }
    }

    for (int KhfDcc = 945921113; KhfDcc > 0; KhfDcc--) {
        continue;
    }
}

double BOXYk::SjxUuFXdrHtBDXr(bool EjcvjwTfQchAbVX)
{
    bool JwSIzJUZ = true;
    double zgNwpXC = -259047.47936777043;
    double LYGElEvretrvly = -196092.87176805746;
    string kQPbfEWVja = string("eUnhOvMksls");
    double SmEPIXrkehKsQv = 531941.9178641548;
    string lkBoAUZaOSflmTFF = string("fVZOYNkCyVZfXSoitRgqBxKuwaKlMhjAWdmHIVmGKrbDcZfUpmorZfyKMgURnXQPIqUaqVmHshYFxNNqMqxUhMqKyovbCDWIjDYiUbeekkCwieSbJsMsYuGvXYOSBLWxXoXhGuXyhDLgzIitVlJsEEoZJvTEBxUAqCKvfrrIPVwAuxmvlfZvqtemyvwsiQZrLQASXQpLuhDD");
    int fpcCYFbtaPoRQkR = 97661312;
    double EvtpwYanZs = -231641.82669700804;
    string aBxKipUWRrOHYO = string("BBMmPDfXYtwxnXBNqTORyutLgHlTpDCDGUsoQSPRXkPymakJKHDmnJAAwShhWturFtEdkDqzwEFeutNJor");

    for (int hHWEw = 1436387178; hHWEw > 0; hHWEw--) {
        continue;
    }

    return EvtpwYanZs;
}

string BOXYk::svFoPRcMA()
{
    bool whbsEiYfnoVpzu = false;
    bool MDUgnUmHU = true;
    double YSdKQsCGVQCzNayO = 577019.2165893449;
    int gRAiCLuyoCyKDYli = 1350979553;
    double jrpgSrkLFkgwWk = -148557.44714094634;
    bool MTSYrJU = true;
    double eczeCBCfDikytSs = 645160.7138605358;

    if (MDUgnUmHU == true) {
        for (int YTUJUxoYBfded = 310489377; YTUJUxoYBfded > 0; YTUJUxoYBfded--) {
            MTSYrJU = MTSYrJU;
            eczeCBCfDikytSs /= jrpgSrkLFkgwWk;
            jrpgSrkLFkgwWk *= YSdKQsCGVQCzNayO;
        }
    }

    for (int wlOUusXUXDglAJRk = 53142917; wlOUusXUXDglAJRk > 0; wlOUusXUXDglAJRk--) {
        eczeCBCfDikytSs -= YSdKQsCGVQCzNayO;
        MTSYrJU = ! whbsEiYfnoVpzu;
    }

    for (int giUSGiaG = 1973108756; giUSGiaG > 0; giUSGiaG--) {
        jrpgSrkLFkgwWk -= jrpgSrkLFkgwWk;
        MTSYrJU = ! MDUgnUmHU;
    }

    return string("sOcepbwJxVhjiOPljhJPQTAQxJClxnhceCuGuykVLIltRrTKQiDGtjauTKLAtZSASKBelrxvqduYRxgZyEyrNfYrTfEaUgsLCqmgynbBAvBzvcPXAjsdKibFzNqEMfVNOflfjNaSTeEjDHgzxXDxCmHVggiyAVHXGOluUmwIIsBUMGIYZGOjrOZyXSbJdcckywmHWTfqKxGouEOZSJZSoFQKRRttcaGWYTuvorSLiGnFuRyJrqgM");
}

double BOXYk::pDlsXslP(double CxqAFApHzqgeZXy, bool aqRfxfGQXEUHXK)
{
    int TtstLlfeSxlWnnV = -96722746;
    int zdhbeCyQQze = 1362623040;
    string joefYIpSES = string("uJhcTxPfWMHDQcMuJiIoniPQKPLzyAFSBcaDogceTlCJRZoSWGFfjTBTNHaPplxOhqzVwGfvaIROhriTTyWTimejBiScEJKUYixCYGXaiYFkWRPqBDDBOYNNwXnhPDGee");
    string AknFbslXVuKwZlhY = string("KpDVuyRFsQegVZzyzybNwqrMnShDINzIFfqDyDhUktZwfkKBpLqoiiIDaJJnXFFHpHOvVgGNAVEqOU");
    double jFzHGcryIhxhNR = 417925.84458045545;
    int COWCgDXMVff = -2025833127;
    double SUxtvfbnXeVbO = -527198.6826077629;
    int qSAKkAlhdjliR = -1493906299;
    string tLirO = string("XKnfuNBptRCsHtfjytWaknutsgUSUIrDVaVFuMEbUkGBLxEsDcRFcfLNnjvzKdqWavcWVgidQWwnyZKunIiljXvIZBjgRqlLzleeEQScmmfkvhDXXXBottqKqEiJWitEjtOJfahALNTWxqUcnytaBaVFQYMaSblmIuRKJhJXAwDQNmcWtPIBOYjzqWxPdEXVSEKvjgbjcgBdjODCXcEMvfJgNKnnuiAkGzIiPs");
    double fBeUqeLnsDhU = 417864.21821145527;

    for (int syDAWZOzhhcvCKw = 1937125914; syDAWZOzhhcvCKw > 0; syDAWZOzhhcvCKw--) {
        tLirO = tLirO;
    }

    return fBeUqeLnsDhU;
}

void BOXYk::ZUwuA(double flIcqkePU, double nBwXwziuX, string faZoCiG, bool OMhIBBBEy, double spmxg)
{
    string VIhfdEKTJjqvbIKx = string("XtyMxmpucYWDeyfHetJMCCFis");
    double swzUzSRdF = -517233.0813480674;
    string jWIWEDlloMLXLSA = string("HrPIwKDWcVaKtRBmrDQAwfkGjZHHIxQrqmdAgzBIRxyBAgUmooJwroqtJcSFXjhUPjxGVXzuaxKdPphqpZNSKPOtEIAWOQYynfAbgtNYOngxSpvibUmZTlNPIPZBetCTQuFAkYYHdPsFfztSaYLZYjfzmCIOapWXQiKhUrRvVczkhupYWcdWwvISXnmAZUEgBYfCAIiPIIqtpDxiQlBHSMwGFUKdlVswJapAVHQnjy");
    double qRxrnnW = -551800.5088401362;
    double EGvQtizzUgGFkXY = 604970.2182117311;
    bool yKvJJFMIPlWs = false;
    string XSjLX = string("jcMUuNGsQIwPgsybmyAnMCVnpcelfJghKQfuuYMZkkEzzlnevAaTxWnfkJoGnMZaONXaeLbppfIvMGcAYNEWrUBEfWzRjQQunmkVKPbiuwqOdUqNWDXowYwLsJRFhYZztLmPUQgPNQNUemhvKLdEHvTESEKqJKrmGuGziIyCojUgpNBVhXOUInbaTzKvjBMROxlROtjveRLcmNjkVBZtgmbiidDHVc");
    bool gdWOpSOZfm = true;
    string aYySDfwGiQKRt = string("QeGZAYCpF");
    double KoOryZbQq = 872907.350181673;

    for (int ujOWWgtEkWHqBrWi = 636894057; ujOWWgtEkWHqBrWi > 0; ujOWWgtEkWHqBrWi--) {
        faZoCiG += aYySDfwGiQKRt;
    }

    for (int zOedvRNjpZdC = 165415342; zOedvRNjpZdC > 0; zOedvRNjpZdC--) {
        swzUzSRdF *= KoOryZbQq;
        aYySDfwGiQKRt = XSjLX;
        qRxrnnW -= swzUzSRdF;
        swzUzSRdF += spmxg;
    }

    for (int VdRFZnRO = 1618140479; VdRFZnRO > 0; VdRFZnRO--) {
        nBwXwziuX += spmxg;
    }
}

BOXYk::BOXYk()
{
    this->AhSzJozRWADZDYU(426108.0531301156);
    this->ilnWtltOoU(1177181606, true, 1842801517);
    this->ZpkOQr(-528219.6932080984, -74860000, 628101346, true, -307689.1615424204);
    this->okJlEN(-569818.6983451269, string("nLndKYfuieTeeqlikdgbSAQeArlnQQklSAxlGXYKhRvpZSVQcLcQNwTOaAxVNHbxnOdrTmdchqpbbpvxDlpJAaPFMMBPBLoBwcFyKgdHLvkwYoTlyWrIEPseCsRWQOWYLrGYADyadDFziJeJJAqOFIHRZkMnorGeZibVvPbjnBjfGPrBpLJWexBHsZgdZxxifYoSKigYNXhbCKqIPYSRcZaBOqkQWlWLcOYPqkDoYLsJncPhfVf"), true, -1342108592, 740859727);
    this->AXyzPwTRgqamKK(586204.4451294637, false, true, string("cUjLZbZnXBNUDMLKgRxsokYthBZSXEXoUAhEgGNKPWVLxYIPxPHxbZubLvlUjrTmMpGqpObERmVJvgdVJlqqNEkqKxYbArrQeVHklcHiGnrNKqZmAdVEbNLgXrVTlAZCENjzldZmnIyIKJoEdJbiRbCfxwdyIfGUYSslCWGvphkx"));
    this->DfQCtUaHcBJOK(false);
    this->WmfSrnzj();
    this->zKZbawHP(-16242.738693295318, 941167.7134778921, string("XhkzDCmzsDmOlOyZkXBCHPHKxSUiwVGNYRnQESqpDZIKQKBQRayzrFhBGOaRJCGtuZfRKBHmjsyVQXveuaCLAqOzOZLdgfyrKuZTuwjswzUHSJW"), true, false);
    this->TCUTD(string("bqGzLMhZCpuBRPqOMzcXzFTfHkIILJQRAEcquswBhmEPijrOjaWdhrcaMLdTvSHIHEGimdgkdhHMMazKbRyx"), false, 135447135, string("NrWrjswIiLVBDfxgxsmeYAScjOlDIYvV"), -107323.51752553167);
    this->YxqFxVbHff(-1765549644, 967772.8200555122, -421099961);
    this->NZCtPq();
    this->KTbEuEVLJaIg(true);
    this->KJRHFK();
    this->vJKfEiMRtety(106157047, 517791.2121941328, -708124524, true, -1488580493);
    this->DxfhSgDTDtAtDQT(true, string("zPXnGACEIhiTewEGQbITCGjcBLFabmMQZUsPejyyTXlgkrYvzUpELRmbJqRVXRfraAMZWkobMVduPEGdBmDcjhVqVewjpJIexmNBBCQbQCyPPPMSfGRQZbLACfZqeZEQhJnKUrjPHnyrAVwFAQlImTygrrzWLvXyetqTQZROlWYYibpqXucXHJtwTXCaWPaTKKAPpQBjJTZvTMWOeJmZvAwvNttqxBdVoFCjBWOnYXmhIiqzFJxHTESuldh"), string("bvwqXzbxJrNuNOocAJQmqYzBlSdOkVTyraWlhiqHGBZgnoQvJOghPMlJlKFrKLsNICTGUJBplCfIqWqSVOvEoJQmBufIbnSWEzsesKybXZXkjeECxelCyyQmSbODLwUHnyWUiamaiemGLagYIZBpeWUdbOVhtCsatXVtRxcZYaecsEblLqFLnjewaMfOGXOjkrftGvBIMSyHwhuNyudyEGLxcuQmqYrDgujbllYAvwXfeEPKdu"), false);
    this->tyVwSLuAfH(1658178293, 848352.5859643803, true);
    this->gbZfEVwt();
    this->SjxUuFXdrHtBDXr(true);
    this->svFoPRcMA();
    this->pDlsXslP(144208.35248289886, true);
    this->ZUwuA(133616.12777623878, 127103.27592969571, string("CoSvELVkgaOwbtMxxbtOPjPwpODkobQSApHPUDoAOxBcqAPxLwzODkNJBQtjWHRIDADlOAclxKnbZoVeKHGGbdrGkATBycoHqAimcmYEEvhvWkZTLJbtmZxCFWIZISKXNYCHkREQRKKguoThiuKbYVBOAGOvKDPVofogMdKYBXnHdxLwQImQEPAlbuIHNvFtNjftTRRRmCIAnTChdJENhUUKxsDJKCHd"), true, 97739.01760531927);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class biOBPcSCMTxWp
{
public:
    double WqUExssUOVCs;
    int pDTUPshYWRZQGWqe;

    biOBPcSCMTxWp();
    string TArIrOlDG(string hIOeovCzopP, bool oMgtVoKjJU, double iOeNxusjbRg);
    double ydWWCwsMo(int gfOppslZRqHQQOfz, string PKMBQckNRCANFL);
    int XCsSOnVEezFkvx(string cOcAwoX, bool LQJCrHfAfK);
    int KxFjSsQV();
    double ahakZNmSC(double eyTyMtZtnbHC);
    void rOxxbCFj(string XXceAnXUKPL, string AkiFRC, string UCdmdPtzNNCUFGs, double tQTQyp);
    string cTJHkUOX(double LBcSGfZaxI, bool KlBHgtUemgw, int wsjuYIhyRHKrHIq);
    int ywYgusz(int MZXyAJLBzf, string NMowrPDS, bool WKsCcxkMFaMqrN, double TPLgOVCVDmAiIXz);
protected:
    int ukHAFOCHeRiEXE;
    double EuzCUytncXV;
    int SpDPzMYuUCxoHqp;

    string bhKnOfSRfHGmI(int WQJbyrrQih);
private:
    double QxxuGNvmry;

    bool sFuhBfJSkSxH(string aUVTVcvaAeipX, bool TVDMot, int fvjmnAnoK, string zNkWt);
    void BWgFt(string wiQIGJJD, string LgaTRhARAqrgSwb, double fJnWOtEAn);
    bool cSPiavxWHpkhu(double EHSKxfIg, int yUJtUzHubQRn, int YTLQhqlVrNGhzin, double MjnoPojhKydxTq, bool qOTsehrR);
    bool MMSrT(int eibcFVWarjRP, string yRMYkoEEpsHSWAna, bool YzuuBc);
    double lQJKxm();
    double pRfKyASUdk(bool BWJgxGgOmVxz, int yFHuzxViPZ);
    double LkrHtTdIy();
    void rhBjSoSrRFRYxzL(string uuYhENKKziirx, bool bOSSEy, bool lleIfxHyPdeArTHT, bool HwhKDTqvAPGwU);
};

string biOBPcSCMTxWp::TArIrOlDG(string hIOeovCzopP, bool oMgtVoKjJU, double iOeNxusjbRg)
{
    string ifuEtaIAZKEcbgMG = string("EGhhmSqmUnccApCAqbRKlLTBvCvOwfNcQmGQolvlyenJqVBYiivlCjkFiWNVjcwsbhXrcYGf");
    double QTRfMQumrdkBmna = -545936.7293640415;
    double XwLnPJCdm = -985119.1980656654;
    int zLfNpQvFaQczRH = 2028779699;
    double mnlThThIKeqdauWc = 697205.8794823954;
    int QjljeCsQTefoztsT = 1825221121;
    double vPCYi = 358486.4056919333;
    double TCPQXBXXfFpEmTh = 792542.5242410379;
    int HftLRjDait = 2029291033;

    return ifuEtaIAZKEcbgMG;
}

double biOBPcSCMTxWp::ydWWCwsMo(int gfOppslZRqHQQOfz, string PKMBQckNRCANFL)
{
    string PVAZzlSdKHPULLY = string("tbeFftokkVSyMltJVXuaMUlaCVoKYmFwStBepzBvUyFGpO");
    double SLzwxGVbjaZzt = 363835.43861815456;
    string RyESJOXnW = string("KKcZzRXsovAzmTsSpEQfQePOHcrOzccaF");
    bool TxhosoQyvgIfiC = false;
    string CSKvCtEgOzb = string("ZaqjQsyItIhtypfaCUWmKBERCiEKHvvHfithNyHbIEaTMnOsKcwBrEWxpherVWgZceisTxAjwCwIXbWrUIozllXvMrBCfwrqHVUcAgKSSPgHwausvPNlaryIMxLzzByucBecOfarZzraeQdWnlOuWFiOangjEbZEGLgOIzfbHXpJyEWreKxgGCbHqKuYCXvzIAzJby");
    int ELUnuKpsCsbT = 1183298395;
    bool HfKosjs = false;
    bool bmXuGNThR = true;
    double kpHRCWsVORHSB = -263402.40712453576;
    bool VWsKDICtyxWvld = true;

    for (int drNPJwguKgoT = 1441597207; drNPJwguKgoT > 0; drNPJwguKgoT--) {
        TxhosoQyvgIfiC = HfKosjs;
        VWsKDICtyxWvld = HfKosjs;
    }

    for (int rgessqbQCDcGYDAB = 37446125; rgessqbQCDcGYDAB > 0; rgessqbQCDcGYDAB--) {
        continue;
    }

    for (int MJkuKIMnoOWWznU = 1829206104; MJkuKIMnoOWWznU > 0; MJkuKIMnoOWWznU--) {
        SLzwxGVbjaZzt *= kpHRCWsVORHSB;
        CSKvCtEgOzb += PVAZzlSdKHPULLY;
    }

    return kpHRCWsVORHSB;
}

int biOBPcSCMTxWp::XCsSOnVEezFkvx(string cOcAwoX, bool LQJCrHfAfK)
{
    string QQnZDXenxRVJpjl = string("WRWBTFVfdSjgEuPfWwsdhtwRodknocqaeafrIGzybALklzvhdTdwBIlMatZjBaiQliQyDpRFexguRxiUeZqttdgnxxjzcNyRcOkbTlVnnxitHCWjONECZRSIgUPkdifyOwWYFYHlRVEbjVwUPhrtPxegeKxBHathJWGSrxTaukSEuusEcvugFcNheCuZpLERz");
    int SulXe = -1727669732;
    string VVEVXDNOXEt = string("xrKdUPVbUkslIMFJCxGhspPZJKbqElVyrBOPMegwtTEjWrHdwVTZDNutlsZSmUFtcpduevEumYRAZKdlwzANSBjPFwCgwxyNnxqQSKOccEwTkiIHWvcLRChpFYlgrxYt");
    int EvUFREFLrEgVdl = -1343699203;
    bool alJajwQ = false;
    string mkeCZZxmYL = string("AWZGhGmvblv");
    double hiqLyvQYeGegQ = 528085.970014216;
    double IZBRnyE = 261614.69340347144;

    for (int zjSGA = 964430903; zjSGA > 0; zjSGA--) {
        SulXe += SulXe;
        alJajwQ = alJajwQ;
    }

    for (int IrnxR = 1315463472; IrnxR > 0; IrnxR--) {
        QQnZDXenxRVJpjl = cOcAwoX;
        QQnZDXenxRVJpjl = mkeCZZxmYL;
    }

    for (int OpgyLbJqiT = 1129081079; OpgyLbJqiT > 0; OpgyLbJqiT--) {
        cOcAwoX = cOcAwoX;
    }

    if (QQnZDXenxRVJpjl <= string("SDTTdUwT")) {
        for (int coEKxPkiv = 843222661; coEKxPkiv > 0; coEKxPkiv--) {
            cOcAwoX += VVEVXDNOXEt;
        }
    }

    return EvUFREFLrEgVdl;
}

int biOBPcSCMTxWp::KxFjSsQV()
{
    double KAsWehEHdFa = 224101.04010381625;
    bool XTcXXlaHQhxKbaKl = false;
    bool jqOwoM = true;
    int nTRwSujxfA = -1957663817;

    for (int syxLWlQulQUC = 696706907; syxLWlQulQUC > 0; syxLWlQulQUC--) {
        KAsWehEHdFa += KAsWehEHdFa;
        jqOwoM = ! jqOwoM;
        nTRwSujxfA /= nTRwSujxfA;
        XTcXXlaHQhxKbaKl = ! XTcXXlaHQhxKbaKl;
    }

    for (int ncRzslQGWAMb = 688285435; ncRzslQGWAMb > 0; ncRzslQGWAMb--) {
        XTcXXlaHQhxKbaKl = XTcXXlaHQhxKbaKl;
    }

    for (int XARWFQ = 204576037; XARWFQ > 0; XARWFQ--) {
        jqOwoM = ! jqOwoM;
        nTRwSujxfA += nTRwSujxfA;
    }

    if (jqOwoM != true) {
        for (int QroCgrRwBRr = 252622379; QroCgrRwBRr > 0; QroCgrRwBRr--) {
            continue;
        }
    }

    for (int kxXQgkVXIcE = 1710056906; kxXQgkVXIcE > 0; kxXQgkVXIcE--) {
        jqOwoM = jqOwoM;
    }

    for (int REooLMOO = 1654013960; REooLMOO > 0; REooLMOO--) {
        KAsWehEHdFa -= KAsWehEHdFa;
    }

    return nTRwSujxfA;
}

double biOBPcSCMTxWp::ahakZNmSC(double eyTyMtZtnbHC)
{
    string bJYGdsblrsjPjky = string("KoyXgEgNNsTaPkuVIRgKxooStXWCoyDsUvqITTWIrvvoUYCJTQdZloknhNCxNbVKHAFMeMmrEdKMDhAAovHCjieGGqhaAlmbsVRmlrbFBJiLQiqWLzWtsfwKKEPIMvVeKunrQprhzMvOuHGGPWQgLqvpDsiGiDWTKVtyeKoIcHrGdZDzAsvzyhLpfbLD");
    bool oZJTkcDpqJGQX = false;
    int KyQuC = -471517811;
    int bYuKkvsCj = 591341921;
    string kmBTLuDXXYMb = string("JnJCaIjeQQhNrcAZfDCTZAuECixJPvCotAYPclIGlEVHfDQnrSxKzcbE");
    int BRSYOASF = 1279809251;

    return eyTyMtZtnbHC;
}

void biOBPcSCMTxWp::rOxxbCFj(string XXceAnXUKPL, string AkiFRC, string UCdmdPtzNNCUFGs, double tQTQyp)
{
    double eacgGFnelPGDltak = -967515.8493626049;
    string qwilbpu = string("DEsijhPPJvuLyCPmwClyjImvKdYoemXSFLCmPLVejuXTRrJBJPTIMHadSXzrDuanRsviIlQKFHBlhOEImDeRtKCupAiGNvhJAvjcQHGpwbhURrWjRHwAfXVUMrzJjVODourZeTXYklTKaVvQjlqongVCnpFinFKfMuiLwofKTCYBBJnhukPxxCrhGpsYnT");
    int QxWlYGj = 1391394247;
    bool BrAzKXdOPNof = true;

    for (int CxVuvfvrB = 524043304; CxVuvfvrB > 0; CxVuvfvrB--) {
        UCdmdPtzNNCUFGs += XXceAnXUKPL;
    }

    for (int WwTIqbFvDHo = 106483395; WwTIqbFvDHo > 0; WwTIqbFvDHo--) {
        qwilbpu += UCdmdPtzNNCUFGs;
        UCdmdPtzNNCUFGs += qwilbpu;
        XXceAnXUKPL += XXceAnXUKPL;
        AkiFRC += qwilbpu;
    }
}

string biOBPcSCMTxWp::cTJHkUOX(double LBcSGfZaxI, bool KlBHgtUemgw, int wsjuYIhyRHKrHIq)
{
    string gtSUiR = string("jMvQRdXnAJDedMumVxvVEYdVKQLwgmoTMshtUhGoJtOErVVAmwQYNfYWFmDw");
    bool wmtvANWNsm = false;
    bool tVQDjLuP = true;
    double KSHRbWgKLCKQzTu = 693380.8933309439;
    double fFHPpygcP = -64488.645359389746;
    bool jYvTnVJmHavZQnsq = false;
    int vDEAmCjsF = -1760112924;

    for (int IrQqxUnLD = 1683052949; IrQqxUnLD > 0; IrQqxUnLD--) {
        continue;
    }

    return gtSUiR;
}

int biOBPcSCMTxWp::ywYgusz(int MZXyAJLBzf, string NMowrPDS, bool WKsCcxkMFaMqrN, double TPLgOVCVDmAiIXz)
{
    bool QIljQg = true;
    double dvMgmEABwyfNS = 839606.8121736107;
    double KxOPJJPHZAlxs = 378090.2297268961;
    string MzMPhTQdcxU = string("LYeIFmYzOjIutlAyJwamTJgkUaBSpALLDfsTfiHjqoxjAtaUXDDbMOzmzvTgpNeMFIhtNPVuLCZRWrawQjdqyxdFEuyXwtKzXJScImtcxlyeWFwmaJaGCjafeNscKkKGKebdUFDvwuLDzJBbEhsnQemJGtWCFjyrdObwJwVeERcdApTcwZZvZAjJXCLbwZpurKiStHTwBBRyOQxiotJUxi");
    double JHqDrhe = 85198.35220900195;
    int ckNNiCDzozgBmc = 2081460118;
    double BZAFJFxElIEzV = 633437.1215013897;
    string JJNtmDfvpPbwB = string("bUMfxqrWxOpRchYveznryQbjQkzsRQdsjAgwVwHQTPYFfHgQAbpyyXkrRWckJAVQMI");
    bool QowsvfUYw = false;

    for (int nNHvLcAX = 896632052; nNHvLcAX > 0; nNHvLcAX--) {
        continue;
    }

    if (JHqDrhe > 85198.35220900195) {
        for (int mmpbfxjLXOdhIQk = 75271618; mmpbfxjLXOdhIQk > 0; mmpbfxjLXOdhIQk--) {
            KxOPJJPHZAlxs += KxOPJJPHZAlxs;
            NMowrPDS = NMowrPDS;
        }
    }

    for (int rtXXQVFTZjhkn = 567635175; rtXXQVFTZjhkn > 0; rtXXQVFTZjhkn--) {
        continue;
    }

    return ckNNiCDzozgBmc;
}

string biOBPcSCMTxWp::bhKnOfSRfHGmI(int WQJbyrrQih)
{
    double PymHD = 530453.0928090909;
    string sliQBufOjj = string("BFxvZjePVoWYBwkiVbKHRjUJBWFvKkFLhbuFXunaaFwfPRRQOAInAChCcunMEUmGRvRmZoDWzVjBdiVngvTwgFZPSEBGWuIVlVavSMHaiLojXEWsavPHgadnEtGwJhEqhQEuujRkanbEzpcJfncNHnwBucqPoUSASTvqfSzEJzeUyFUDRtsAKEEkiCMeJkFMfEyBDmrXPZqsZqQXjGCJBMjLSUmNgmYqSFt");
    double XSpBvMhKMxQMx = -809508.1765695696;
    int mFxgSVcXHwv = 849132174;
    bool OkiicgBdsHLphv = true;

    for (int wGiWrh = 1956364143; wGiWrh > 0; wGiWrh--) {
        XSpBvMhKMxQMx -= PymHD;
        PymHD /= PymHD;
        PymHD += XSpBvMhKMxQMx;
    }

    for (int rQSkujmXoEQ = 559161006; rQSkujmXoEQ > 0; rQSkujmXoEQ--) {
        continue;
    }

    return sliQBufOjj;
}

bool biOBPcSCMTxWp::sFuhBfJSkSxH(string aUVTVcvaAeipX, bool TVDMot, int fvjmnAnoK, string zNkWt)
{
    string NhURONnEMBcItB = string("qGHeXdJxkTTOFwWmRCcjlrHGbCVMPbaiLWSGqizWHrSJlOImFBPTbBxLlyRoMwbbDsOhyvHyfjwzMYVBCtJyWDEYTyqMvPVRdytDNfcCmqlmTzgXunXwDWcraywyfjcMVakxGOxpNigzxTlROqnUuouKNgPLatLNHhwKoyspGgSkoDFSPwDLaAVtNLzMxOjyFtzUBtuYAardGiQyotgpeSWdKtGRJChGTZRcapNkkvyLSLQMtbKzBkElZ");
    double aPNnldLHPTsiDyEf = 1039583.4245764283;
    bool jUOTmZ = true;
    int vFzgncKsUP = -1859571337;
    int dmiHbbGKuJxzKQ = 1942371012;
    double IMYsFb = -1021924.8651565192;

    for (int uyNQxPpi = 852126223; uyNQxPpi > 0; uyNQxPpi--) {
        jUOTmZ = ! jUOTmZ;
    }

    return jUOTmZ;
}

void biOBPcSCMTxWp::BWgFt(string wiQIGJJD, string LgaTRhARAqrgSwb, double fJnWOtEAn)
{
    string zTViwklXQcREfm = string("SRxeRASEfryeYOczXikfIhWUdQvmrfTEqlAvaWrqWBWcThIMbjJKXbWsEmLxKDYTUeFoEgcDEwFPGtQUIcuWqGOZmRZTcdnweDpqbUuvflwebLGsHOtmgGcMPOmYMeiaNrapaKfKvlOqGIWbrrzFYjnMuDopHtfyDvWTaMbbygKUzDsufDHERhLoWbBNXSCDYXGCKGugBnqRqYMSrcmROssTxrFEqZomoHZNoJveihKTXYUIMlfajyZlG");
    bool jHfMMDhmXMuR = true;
    bool UJoFnamTjAlfC = false;
    bool TCWcnTtOQ = true;
    string nwuKNAH = string("nUATsawPlHEmoQMtufbMxoKJFZNxANb");
    int yWzaYxWdNYVaZs = 594273013;
}

bool biOBPcSCMTxWp::cSPiavxWHpkhu(double EHSKxfIg, int yUJtUzHubQRn, int YTLQhqlVrNGhzin, double MjnoPojhKydxTq, bool qOTsehrR)
{
    bool nRsopYDfOmiDnLD = true;
    int wtFTpmafnZmvKs = 729303413;
    int cvCebUwXz = -707733478;

    for (int GmHTeTFJtmH = 732077655; GmHTeTFJtmH > 0; GmHTeTFJtmH--) {
        wtFTpmafnZmvKs = YTLQhqlVrNGhzin;
        YTLQhqlVrNGhzin /= wtFTpmafnZmvKs;
        EHSKxfIg -= MjnoPojhKydxTq;
        EHSKxfIg -= MjnoPojhKydxTq;
        YTLQhqlVrNGhzin += cvCebUwXz;
    }

    for (int ndaBPWoRNxPbvEN = 1393900005; ndaBPWoRNxPbvEN > 0; ndaBPWoRNxPbvEN--) {
        nRsopYDfOmiDnLD = nRsopYDfOmiDnLD;
        qOTsehrR = nRsopYDfOmiDnLD;
        YTLQhqlVrNGhzin -= yUJtUzHubQRn;
    }

    return nRsopYDfOmiDnLD;
}

bool biOBPcSCMTxWp::MMSrT(int eibcFVWarjRP, string yRMYkoEEpsHSWAna, bool YzuuBc)
{
    bool DcYJVVZpM = true;

    return DcYJVVZpM;
}

double biOBPcSCMTxWp::lQJKxm()
{
    double TCrRcs = -610213.9329937081;
    int hDyelUpbU = 960444078;
    int qFBMYLTpofmhloZ = -1533241006;
    int BXhGVcAMLYl = 234953537;

    if (BXhGVcAMLYl >= 234953537) {
        for (int DvFHQWr = 728709751; DvFHQWr > 0; DvFHQWr--) {
            continue;
        }
    }

    if (BXhGVcAMLYl != 960444078) {
        for (int GopmEOa = 145572716; GopmEOa > 0; GopmEOa--) {
            BXhGVcAMLYl = BXhGVcAMLYl;
            BXhGVcAMLYl -= qFBMYLTpofmhloZ;
            BXhGVcAMLYl -= qFBMYLTpofmhloZ;
            BXhGVcAMLYl += BXhGVcAMLYl;
        }
    }

    for (int yBIttzlxVSszAoZp = 1354524177; yBIttzlxVSszAoZp > 0; yBIttzlxVSszAoZp--) {
        BXhGVcAMLYl *= qFBMYLTpofmhloZ;
    }

    return TCrRcs;
}

double biOBPcSCMTxWp::pRfKyASUdk(bool BWJgxGgOmVxz, int yFHuzxViPZ)
{
    bool UGirhFdEhMhZa = false;
    int oriUrT = 802735717;
    int GCEofvttQVSJ = -1983293334;
    bool YIdzkatLBju = true;
    string ESZChieBy = string("aUNQMSeGIWyhDqGDcTCvcJeRhDGnDXFNpzWQbnYgALbmmFuYlSPrrQhNXvsgCPIWBUiDCkXbctpDwEUVeJyC");
    bool JFDxpl = true;

    for (int KkEqR = 447381832; KkEqR > 0; KkEqR--) {
        UGirhFdEhMhZa = ! JFDxpl;
    }

    for (int mZiOGMyrakr = 2144764321; mZiOGMyrakr > 0; mZiOGMyrakr--) {
        oriUrT -= oriUrT;
        GCEofvttQVSJ -= GCEofvttQVSJ;
        BWJgxGgOmVxz = ! UGirhFdEhMhZa;
        BWJgxGgOmVxz = ! UGirhFdEhMhZa;
        yFHuzxViPZ -= yFHuzxViPZ;
        GCEofvttQVSJ -= yFHuzxViPZ;
    }

    for (int AoEzFtUeyyoUdHVJ = 1709740166; AoEzFtUeyyoUdHVJ > 0; AoEzFtUeyyoUdHVJ--) {
        YIdzkatLBju = JFDxpl;
    }

    if (UGirhFdEhMhZa == true) {
        for (int KNgnpBMgCeE = 1450818467; KNgnpBMgCeE > 0; KNgnpBMgCeE--) {
            UGirhFdEhMhZa = YIdzkatLBju;
            JFDxpl = UGirhFdEhMhZa;
            oriUrT = GCEofvttQVSJ;
        }
    }

    return -874298.0974705234;
}

double biOBPcSCMTxWp::LkrHtTdIy()
{
    double zqcQRhtOTyM = -477377.68244405027;
    int AKOHREXpjfhoOZ = 1775668901;

    for (int xiOJrC = 1148428062; xiOJrC > 0; xiOJrC--) {
        zqcQRhtOTyM /= zqcQRhtOTyM;
        zqcQRhtOTyM /= zqcQRhtOTyM;
        zqcQRhtOTyM = zqcQRhtOTyM;
    }

    if (zqcQRhtOTyM <= -477377.68244405027) {
        for (int JbPlnBfXxZnvQN = 739327057; JbPlnBfXxZnvQN > 0; JbPlnBfXxZnvQN--) {
            AKOHREXpjfhoOZ /= AKOHREXpjfhoOZ;
            AKOHREXpjfhoOZ = AKOHREXpjfhoOZ;
            AKOHREXpjfhoOZ /= AKOHREXpjfhoOZ;
            zqcQRhtOTyM = zqcQRhtOTyM;
        }
    }

    return zqcQRhtOTyM;
}

void biOBPcSCMTxWp::rhBjSoSrRFRYxzL(string uuYhENKKziirx, bool bOSSEy, bool lleIfxHyPdeArTHT, bool HwhKDTqvAPGwU)
{
    int qCjQIKqPoOD = -71466658;
    double RchTOlBmLTrdGd = 660390.7845387659;
    double AMbyXY = -526344.187109444;
    int PfAnLdq = -1967141484;
    double VRlWlYpwuiJuHmV = 767929.7399518838;
    bool XMFGbEAg = true;
    bool aJdIDsqrGBQE = true;
    string mzDyzUCuDkMFKwo = string("JMGWpSwrBywAMRQNsfTyGhkaBLVhjelgUQItIjFiDfScOGrVVFbnvxipDPNipVOY");
    string KgisGOFxpULlMUj = string("kMkgnABVUgUVVmcacOpeqjbdzbAwAwYJPdEEsYWFxLrsvRjdPCZvFYNZSuyBtVlOjSWgicDAhhBONWhQxDPmdaGKnNDuIYZSYaUzmkAHkiCfRJmYVDRrpbiujuARrqLWfMuLIqMSqvw");
    int yZKSVpRdlKEAf = 413742522;

    if (lleIfxHyPdeArTHT == true) {
        for (int ZdGRWNokddMMw = 310999854; ZdGRWNokddMMw > 0; ZdGRWNokddMMw--) {
            RchTOlBmLTrdGd -= VRlWlYpwuiJuHmV;
            aJdIDsqrGBQE = ! aJdIDsqrGBQE;
            RchTOlBmLTrdGd /= RchTOlBmLTrdGd;
            RchTOlBmLTrdGd /= RchTOlBmLTrdGd;
        }
    }
}

biOBPcSCMTxWp::biOBPcSCMTxWp()
{
    this->TArIrOlDG(string("yXASvGYiucjAXCYYSXbdfMohDhIewANbmfrqLnuU"), true, 2577.6126698853345);
    this->ydWWCwsMo(-1014372871, string("LaNTnVVpxMuXflBVbGUtrcrayEdfmcavgXRwiiSewQeYOLLCUWkkayqcZKkjZDCVCiAMyiqQKqzGlZnKnrisQZYndGWjUXyDLdXdRYvEJEfrKgjsRVrZTPlxzsSXcYlNsVrXabhoCpnR"));
    this->XCsSOnVEezFkvx(string("SDTTdUwT"), false);
    this->KxFjSsQV();
    this->ahakZNmSC(726665.647705343);
    this->rOxxbCFj(string("vCrmzOdGfNCytTaoVHKxFFjJsArFydYBgEGBJRDGDjdstgrtwiWKbbXDPmxZnQFuQavWjZQJkOVncJzbJCYVqUVMjpqVVKZrSdmgEaZGZPBKowdbUFUFhLYhJKIpyRWJPtbCvuRGALXQFdTTIWMwYDhalmGYLoaogXFFettVrqVTOKuuDGHTUMrOKekrWwTAQPXKKsMEuBGEVpzQqHDct"), string("WpxYnlsJYnUWZLRnKoMmDnEqpfGiwkvyeIOLaehYCUqTBwytVkUkwxkgBNHntZEhOMkPOBDqtecsFBViUkiwdcvfBxOagvjCGRgPWensBmLgNAZfWzhrldPeDmdGZcxnMDwntSZCfOnHBGlfzxYDOmCsHLCNJmJwSnQKFpCROeLqbUwHNgPLQzpBfMaoqYHqMhdqjrFVzjXcvOlpzBwlZdTqSyLKJLQwJQEVCJoUHTyltCcNdIEUPapXdRYxDRJ"), string("IWWctzgeDqgQzRNDghBVNMnNwvWEzSWGSBrCqMYJHiZmSk"), -602221.6448388888);
    this->cTJHkUOX(99031.88878528912, false, 469975008);
    this->ywYgusz(1444293420, string("VTLLDHUwdwCFrbYmuFunkgCknTGAUbdeOKZkpErQKDAefIxglNeNJHwXOzAEtfThQkzmLpCYyIsPvOWeqMqSoxImWtsSNUSDwvIywqqcjcREqlZhjVfwqsOPAZfsuquIuCZztLyCXmAptcNcAnhYzHMQDuBdFZWIsAoVKmCzigpiZLvKqecMBjBWzCMiAXYyg"), true, 53071.68898667544);
    this->bhKnOfSRfHGmI(-928764501);
    this->sFuhBfJSkSxH(string("NYK"), false, 1970555210, string("YcFGIxrvHcyLgBnSthHS"));
    this->BWgFt(string("dUhcowPdYdFvfuAWgawgOnzasgUgQGTlxoHgBGOWcJSkYougmHCHMxYpWCfEDPSpwvnyWoEbukGSkWuYpewWtfLInKkBcSjoOKlJHQoyabAjJdzoNophGKqtHfQGeNvHSeySNHsFTvBmNyDMlhZUyLmujcDUZNTkYgkglQogvHCJmghjjhSbEVwrXucpGNwxrTDfsSyFUORhAGwvdBfgQqfuVaAOoJlaZMTWrLkbvQZMLJdfWHQSc"), string("AOjzTFmGJHwfGsSjJyEtKCdojxHWsVeGnGlWOqAyqo"), -479134.8475650457);
    this->cSPiavxWHpkhu(9975.540896244005, 1559930942, 1504355592, -317625.0259817058, true);
    this->MMSrT(1613260855, string("VjMkTSGUXBTNloFtxkBFjPTLWJeKPfoCskZBBvSUlcnxFZTYlbsPuwFoVpNacTVeFCFbKszcWAiNhXysjvAOjnHzrkmKkYykaFUihcbeLdqUjfuynfLqSFoIXmWVOgcftvBWNdIDkTxNtXoOohGYCHPatgikKEuskoMvwQCrujnCgfEFwXOrTOuaIviCTmzqoSiygnWzzIgRqHoPktItDif"), false);
    this->lQJKxm();
    this->pRfKyASUdk(false, 1473259587);
    this->LkrHtTdIy();
    this->rhBjSoSrRFRYxzL(string("cqjdZtxOjtBdoaOqfolOZHFjsHTqOARvecEPnkJDBDcUpfQGTzgrLvnYbJcFseHsnXSTHBNxlxdvooSyIZwDuoYSVBjBMDnnOPNZOUXjaPQIKaSvNclQlYlMVCdsHrazlCsYSCRjRVBqrHUBoxlTQgWPKBZuNsDMvLtyAGQqynqqJBfIrKXYQbfncFSlbatQARTKvtITEfpRenkYaPeIGlEebyZiXWAjOBNqMwOVaqYfGIwnidabpbt"), true, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DoGMLYnwdXBnX
{
public:
    int KYSFmCraaTT;
    string uchvgPVUksNi;
    double ZXkdpbEGHV;

    DoGMLYnwdXBnX();
    void ifqucfcYndyC();
    string GKwrDKLqxbNZ(string SGkYApFjAWtFAv, double aagAyZEmXNSvv, bool rghmDqNCRawgf);
    double kZKIf();
    double mCnonDpwb(bool ZyAilGqGgQSEIl, int wcWPgsZLhaGMUEY, int oxLVrBEDVCDk);
    string VofjoHHwXRUJaB(double jjrvpcVGkItZeZ, int mYErLtlKEkCxfBo, double xexmujTb, int WUvNViqJBJvuB, string vluLDkZskILNMrL);
protected:
    int wfOmLSvRwVOtJ;
    int YUlJWHlybwic;
    bool cIGZQvZ;
    int QursufQR;
    string uHNjofILlYzH;

    double ZGPduCPJGIkHo();
    string tvETuJ();
    void vVTvvGGaqkUXli(int llctZWiigdIaDttu, double NCmzCNr);
private:
    bool EgFLAicWUwbgWdE;
    bool UXowaf;
    bool BxoQNar;
    string WDRNbrTCEGdvl;
    bool LNabjqUC;

    double UXZHKYCkSlP();
    double ByyAX(int aMLJjhfzC, int OTtWTnmSWq, string ILdytgJczffUxZJ);
    void mkNSlALgFHRpFs();
    bool lVgmj(bool ZnkhgKMDPcIABlo, string LJHVhTfGdaRlMYK);
    int nRaYyMxencez();
    string FgWEUAdV(double WiBYUn, string BZEvhWQSb, int EtMOEtaO, double eQdzi);
};

void DoGMLYnwdXBnX::ifqucfcYndyC()
{
    double FXvax = -853068.9634646572;
    bool dHVWVVYJbyFk = false;
    double umHRkVuQmumJ = 454987.4592544053;

    for (int PiQriDTm = 2115468620; PiQriDTm > 0; PiQriDTm--) {
        FXvax *= FXvax;
        FXvax = umHRkVuQmumJ;
        FXvax -= umHRkVuQmumJ;
    }
}

string DoGMLYnwdXBnX::GKwrDKLqxbNZ(string SGkYApFjAWtFAv, double aagAyZEmXNSvv, bool rghmDqNCRawgf)
{
    int VEEtwBWmBCJ = -2080974655;
    double CzswMOGnHpav = -695760.0912078405;

    if (rghmDqNCRawgf == true) {
        for (int QSRVxvrGWBy = 1127769333; QSRVxvrGWBy > 0; QSRVxvrGWBy--) {
            continue;
        }
    }

    for (int sUVVuMFRb = 1709196436; sUVVuMFRb > 0; sUVVuMFRb--) {
        aagAyZEmXNSvv *= aagAyZEmXNSvv;
    }

    return SGkYApFjAWtFAv;
}

double DoGMLYnwdXBnX::kZKIf()
{
    string zdEFHqhNYb = string("OoZjHbanFhzPOBVnLZzapwmBoJxtgMNJRroYbFAOBDkRSSkPMRmpcqdORTgBhkUVDsZRSmhQTROzmUBzqUYbMqFPgljmNIOXcKGScAqcZYTSPoKTPGFNADmirSzFtwetDpxcexdFehL");
    double ZHGrgKIfpMpRPLuP = 401747.1310694227;
    bool EytZJCwmBIefGyE = false;
    int rJfkSGeKIzrIZ = -1887235526;
    double XTjxczkuHAZB = -17946.131452307593;
    double dPGnas = -921527.4127444458;
    string EnUaRZnmABJiZHxf = string("LlmpOhRpAoMXVxiFpNBAORHyslZkkLREiEJsvcdpRncdndXjYHpBeHAcwQtBZNnxTsHCGUcPwryEilUeUxxcNRxyTlqgMTPgbLRhzWGyLeZwjxQmnvfLhisoAQhaxpXbxHoJNcXCwVikrGVtrRXuGflFdRgQnyvdNeejvqJlnMu");
    double vNUUwjkKakKlvyx = 836593.6130401364;
    double PZkvoaNmgJOUs = 789564.1798201015;
    string SsOqljITjiJtVd = string("acoWpzRQnaspcCpRyiKwmieLFVjPJoWXfjYuNkzHPmRnYVIzdfSiLWdQarsgCxWdqqKUFQEfiGgjMMaOrmZKnwnDvetqmrKTozEJttWhovDRwvsDIcsxXxCtNfVccYPDynLnlFJJVgTtTaSwxJnxxopNSrZdPlJOfrCWxtTpMlnheuhrowQyRyHPsGbhmjkjDQiojSsOrYu");

    for (int FyqzfKpmyCVV = 1287848011; FyqzfKpmyCVV > 0; FyqzfKpmyCVV--) {
        SsOqljITjiJtVd = EnUaRZnmABJiZHxf;
        XTjxczkuHAZB += dPGnas;
    }

    for (int JHPLYnZEtODy = 1035425774; JHPLYnZEtODy > 0; JHPLYnZEtODy--) {
        continue;
    }

    if (PZkvoaNmgJOUs > 836593.6130401364) {
        for (int gxjizcI = 1506290121; gxjizcI > 0; gxjizcI--) {
            dPGnas /= XTjxczkuHAZB;
            dPGnas -= dPGnas;
            SsOqljITjiJtVd += EnUaRZnmABJiZHxf;
            ZHGrgKIfpMpRPLuP /= vNUUwjkKakKlvyx;
            XTjxczkuHAZB /= vNUUwjkKakKlvyx;
            SsOqljITjiJtVd = EnUaRZnmABJiZHxf;
        }
    }

    for (int fBkLoj = 2129666254; fBkLoj > 0; fBkLoj--) {
        ZHGrgKIfpMpRPLuP *= PZkvoaNmgJOUs;
        vNUUwjkKakKlvyx += vNUUwjkKakKlvyx;
        SsOqljITjiJtVd = EnUaRZnmABJiZHxf;
    }

    return PZkvoaNmgJOUs;
}

double DoGMLYnwdXBnX::mCnonDpwb(bool ZyAilGqGgQSEIl, int wcWPgsZLhaGMUEY, int oxLVrBEDVCDk)
{
    bool BkZqXPlmDSw = false;

    for (int dRAQquxcSBNy = 490932475; dRAQquxcSBNy > 0; dRAQquxcSBNy--) {
        oxLVrBEDVCDk += wcWPgsZLhaGMUEY;
        ZyAilGqGgQSEIl = ! ZyAilGqGgQSEIl;
        BkZqXPlmDSw = ! BkZqXPlmDSw;
        wcWPgsZLhaGMUEY += wcWPgsZLhaGMUEY;
    }

    for (int QVGrMRNm = 564739178; QVGrMRNm > 0; QVGrMRNm--) {
        BkZqXPlmDSw = BkZqXPlmDSw;
        ZyAilGqGgQSEIl = ZyAilGqGgQSEIl;
    }

    if (BkZqXPlmDSw != false) {
        for (int aQILBuBzu = 1062659077; aQILBuBzu > 0; aQILBuBzu--) {
            wcWPgsZLhaGMUEY *= wcWPgsZLhaGMUEY;
        }
    }

    if (wcWPgsZLhaGMUEY != -1035825418) {
        for (int OYMqGi = 559787510; OYMqGi > 0; OYMqGi--) {
            wcWPgsZLhaGMUEY += wcWPgsZLhaGMUEY;
        }
    }

    for (int YVvFMpxFAlCsK = 1563006952; YVvFMpxFAlCsK > 0; YVvFMpxFAlCsK--) {
        oxLVrBEDVCDk = wcWPgsZLhaGMUEY;
        BkZqXPlmDSw = ! BkZqXPlmDSw;
        ZyAilGqGgQSEIl = ! BkZqXPlmDSw;
        ZyAilGqGgQSEIl = ! BkZqXPlmDSw;
        oxLVrBEDVCDk -= wcWPgsZLhaGMUEY;
    }

    return 404304.2603301368;
}

string DoGMLYnwdXBnX::VofjoHHwXRUJaB(double jjrvpcVGkItZeZ, int mYErLtlKEkCxfBo, double xexmujTb, int WUvNViqJBJvuB, string vluLDkZskILNMrL)
{
    int hABMwDFue = 405722751;
    double fhGvxgXqar = -297810.51270541083;
    bool VzXcHGjMCUn = false;
    bool EMrqRg = false;
    int WJeSgqBAkc = -1485957253;
    int xKJEdFmoX = -1637936728;
    string LdZflweXbWJVJvm = string("JXQVZyjKWbiAZboAsNSyUiLFAxYUMluZXVCNmpCCwJFAWSfZrtWHlXnmCMYQTmnVDfkirTMHcpGWhnZuPgGLFR");
    bool ndMfJLfUcu = true;

    for (int LXXaZrnjtqw = 823217886; LXXaZrnjtqw > 0; LXXaZrnjtqw--) {
        xKJEdFmoX = xKJEdFmoX;
        xKJEdFmoX = WUvNViqJBJvuB;
        hABMwDFue += xKJEdFmoX;
        ndMfJLfUcu = ! ndMfJLfUcu;
    }

    for (int evoST = 369231485; evoST > 0; evoST--) {
        hABMwDFue -= WJeSgqBAkc;
        hABMwDFue = hABMwDFue;
    }

    for (int WpMPf = 1541199971; WpMPf > 0; WpMPf--) {
        EMrqRg = ! VzXcHGjMCUn;
        ndMfJLfUcu = ! EMrqRg;
    }

    for (int mPujaW = 2015164739; mPujaW > 0; mPujaW--) {
        mYErLtlKEkCxfBo = hABMwDFue;
    }

    if (WUvNViqJBJvuB >= -1637936728) {
        for (int UvSpOIjv = 91003950; UvSpOIjv > 0; UvSpOIjv--) {
            ndMfJLfUcu = ! VzXcHGjMCUn;
            jjrvpcVGkItZeZ -= jjrvpcVGkItZeZ;
            VzXcHGjMCUn = ! EMrqRg;
            WJeSgqBAkc /= mYErLtlKEkCxfBo;
        }
    }

    return LdZflweXbWJVJvm;
}

double DoGMLYnwdXBnX::ZGPduCPJGIkHo()
{
    string fefNDUUJN = string("CXkDxknfXQLyJudEabiSQngYqmQQheiJsJEotUmjJvoTdsbEyVIBiKUaxfTyZwWWDncUtpXiUBRSgMVPtmPoYyCghqabZYwbBtUqIfkhyugAimdbcgkZkNkFYssOoumtvZuWSHULtOxwAFevZfwquZDWyNnfJYzlYrvLHeSGLgFSTVsrcBPbjjFOtQqOXUEGRgrCZRcoZlTIsWBjcefqfzwwKVXaCDLabPADWxRiHHsPx");
    string LkKpKAkoFs = string("ALSSRhhNByLJpwnhEcHpsFREdnTQkQDexlXQhMSPpBWnDccZRBZBmAMIJUNIipcTALcfOPFVJdTVmNnRixdSbVLmDJWWGmTLUPYKyyELOipzqiIkFGOgUlSUwPO");
    double gbtAx = 652620.5559573497;
    int NstWAjiYbQbEttPZ = 75154934;
    bool SVOqVjpCNpKayBzf = true;
    bool hVuqsQuL = true;
    bool TtzdvqxERdsL = false;
    string ueqFgQCtmSVv = string("ohpDiJXtaIUIwNXMGuKSeBtupFnLBTnqVFYvKZNRffdxSVpYOWk");
    int TJVZAI = -923946162;

    for (int OycMKGwgZ = 187121972; OycMKGwgZ > 0; OycMKGwgZ--) {
        fefNDUUJN = fefNDUUJN;
        NstWAjiYbQbEttPZ -= TJVZAI;
        SVOqVjpCNpKayBzf = hVuqsQuL;
    }

    for (int WRhezsrbWJEMUN = 1236368723; WRhezsrbWJEMUN > 0; WRhezsrbWJEMUN--) {
        TtzdvqxERdsL = ! SVOqVjpCNpKayBzf;
        fefNDUUJN += fefNDUUJN;
    }

    if (ueqFgQCtmSVv >= string("CXkDxknfXQLyJudEabiSQngYqmQQheiJsJEotUmjJvoTdsbEyVIBiKUaxfTyZwWWDncUtpXiUBRSgMVPtmPoYyCghqabZYwbBtUqIfkhyugAimdbcgkZkNkFYssOoumtvZuWSHULtOxwAFevZfwquZDWyNnfJYzlYrvLHeSGLgFSTVsrcBPbjjFOtQqOXUEGRgrCZRcoZlTIsWBjcefqfzwwKVXaCDLabPADWxRiHHsPx")) {
        for (int kxqkaqxppRjPKn = 1243725597; kxqkaqxppRjPKn > 0; kxqkaqxppRjPKn--) {
            continue;
        }
    }

    for (int brWvDAPwugLWJW = 1417237369; brWvDAPwugLWJW > 0; brWvDAPwugLWJW--) {
        gbtAx += gbtAx;
        SVOqVjpCNpKayBzf = hVuqsQuL;
    }

    if (LkKpKAkoFs == string("CXkDxknfXQLyJudEabiSQngYqmQQheiJsJEotUmjJvoTdsbEyVIBiKUaxfTyZwWWDncUtpXiUBRSgMVPtmPoYyCghqabZYwbBtUqIfkhyugAimdbcgkZkNkFYssOoumtvZuWSHULtOxwAFevZfwquZDWyNnfJYzlYrvLHeSGLgFSTVsrcBPbjjFOtQqOXUEGRgrCZRcoZlTIsWBjcefqfzwwKVXaCDLabPADWxRiHHsPx")) {
        for (int QfyOfoCKuzucJF = 1113004802; QfyOfoCKuzucJF > 0; QfyOfoCKuzucJF--) {
            continue;
        }
    }

    for (int HwzOdl = 52840576; HwzOdl > 0; HwzOdl--) {
        continue;
    }

    if (TtzdvqxERdsL == false) {
        for (int ALiPfOJoQx = 824951030; ALiPfOJoQx > 0; ALiPfOJoQx--) {
            TtzdvqxERdsL = hVuqsQuL;
            TtzdvqxERdsL = ! SVOqVjpCNpKayBzf;
            fefNDUUJN += LkKpKAkoFs;
        }
    }

    return gbtAx;
}

string DoGMLYnwdXBnX::tvETuJ()
{
    int qqtGsfSORBIJXC = -754137880;
    double sfXor = 857295.447670062;
    bool MqduNKIgxRBYjJxR = false;
    bool PohkSbNrEkyY = false;
    double TYrHEipdZX = 51605.64061351191;
    int PRMfafjKdYfmrS = 69042531;
    int HKeIvdKrpONNU = -1195036362;

    for (int WkMScWkHYJsZqse = 1737287297; WkMScWkHYJsZqse > 0; WkMScWkHYJsZqse--) {
        HKeIvdKrpONNU += HKeIvdKrpONNU;
    }

    return string("iyibmeYplQtCOtQjXEhlXclMPcmaPEQnYsjmSINhzHvYbeWzHYOidzSRFBtuiddRaPuwjDxGNSeegYMHgVlxNPLiNbcSBDBiVNKPzrGoSvQkIvYyyXataFUQsLoNKbRPCuTFTEQOfSrLXkWxyUWjbtbsoHaHT");
}

void DoGMLYnwdXBnX::vVTvvGGaqkUXli(int llctZWiigdIaDttu, double NCmzCNr)
{
    string EpkLPKil = string("tePqcwQcPXZElwiXIWeznQYYkeBCHgHmiEjlOwkTQhFxAziqOSIKkiFBhKEVVBtJAGnRZuCEZKDzUKdNiiNclJtJIzrRvvuOslujmBQsthTEmtwaFcJgomxPSLppOfHHrjGtaYEuySNKqHnmfXeddFXqZTtCviHzdNBCMQgAVedOhQdCERQGFQNMCGdPDtbvncsgxMXtoMuHiBjFXYHYeHvNMhRkdggZdjQMROVXdISVQXesWqqGekmHrDsRubq");
    int NWxzlgy = -1336685055;

    for (int biJQLNGteoyY = 1430945400; biJQLNGteoyY > 0; biJQLNGteoyY--) {
        continue;
    }

    if (NCmzCNr > -908293.9410628683) {
        for (int KcuYZcWsCvyRkzV = 205801105; KcuYZcWsCvyRkzV > 0; KcuYZcWsCvyRkzV--) {
            continue;
        }
    }

    if (llctZWiigdIaDttu < -627703010) {
        for (int AbBipGfmq = 1306725931; AbBipGfmq > 0; AbBipGfmq--) {
            NWxzlgy -= NWxzlgy;
            llctZWiigdIaDttu *= NWxzlgy;
        }
    }

    for (int pnndTEqUdq = 57038123; pnndTEqUdq > 0; pnndTEqUdq--) {
        llctZWiigdIaDttu /= llctZWiigdIaDttu;
        NCmzCNr += NCmzCNr;
    }
}

double DoGMLYnwdXBnX::UXZHKYCkSlP()
{
    bool NXGtpgSO = true;
    double JDTByclsDRWYUP = 227717.61089424358;
    bool ybunysThd = false;
    int PTCsRwl = -1215349338;
    double shpwMQPLKtxnwxs = -542867.6896498025;
    bool JkAPGlQ = false;
    int tRqQc = -1112793653;

    for (int dIDSMDU = 1189573276; dIDSMDU > 0; dIDSMDU--) {
        JkAPGlQ = ! NXGtpgSO;
    }

    for (int HmTPyUkezaMiHG = 1955049906; HmTPyUkezaMiHG > 0; HmTPyUkezaMiHG--) {
        shpwMQPLKtxnwxs -= shpwMQPLKtxnwxs;
        shpwMQPLKtxnwxs /= JDTByclsDRWYUP;
    }

    return shpwMQPLKtxnwxs;
}

double DoGMLYnwdXBnX::ByyAX(int aMLJjhfzC, int OTtWTnmSWq, string ILdytgJczffUxZJ)
{
    string mYznoaQEjyDVcNj = string("QOoDizMZheqcyIePUCWvgFijTCAKunOglFcRayFmQBpHMadPRnJXKKcvHfJNqiNFZgAwGyOvfJQPUCUrvAEibEKlEbFTekHTubTUpmcfWDtJXFSOxJGrOcvJrYhCeNhfKCiKxhCWHlqQZYIaNHVQRjiUycYhMiFsEzeFNPftCDuKoumJWYvzKNLddYcEcEZtrgkPaaUBafaFbcVIuxTZRSZHS");
    bool aYCbHEMihOai = false;
    bool rbUppRqQOLGlZcd = false;
    double uaPLiTeoNRTbRxT = -725258.9475587376;
    double YtsRgstUsnKjfH = 471092.9064230304;
    string joNcM = string("HwOfggpRLJkOHTdqgtXeaUnZhwjVfsFnliCjJNTvYcMmGiPlJqFZmZCHvLATSHhPccRnNwYsUFKkJZXVkHRARreEPdsJYAoDoDIzzRRBQIhSzJhLvQIGDhgyOLYwhoRPMBXqzxqAkILWgiqdtKPxxlOsxwhMEHdfYnRqeQFsOXVPTISecCkksW");
    bool jGVMfspYbMSsKAqI = true;
    int ecsYEsSIhBYiKbns = 641951249;

    if (jGVMfspYbMSsKAqI == true) {
        for (int crRFsMEfryfWzyxr = 123607276; crRFsMEfryfWzyxr > 0; crRFsMEfryfWzyxr--) {
            continue;
        }
    }

    for (int ZfYLtNlsbd = 1263415601; ZfYLtNlsbd > 0; ZfYLtNlsbd--) {
        uaPLiTeoNRTbRxT = uaPLiTeoNRTbRxT;
    }

    for (int xSbRTQuXfZB = 30989502; xSbRTQuXfZB > 0; xSbRTQuXfZB--) {
        rbUppRqQOLGlZcd = jGVMfspYbMSsKAqI;
    }

    if (ecsYEsSIhBYiKbns < -1430681021) {
        for (int zoRnKqiNKrxq = 501231556; zoRnKqiNKrxq > 0; zoRnKqiNKrxq--) {
            ILdytgJczffUxZJ += joNcM;
            ecsYEsSIhBYiKbns -= aMLJjhfzC;
            joNcM += ILdytgJczffUxZJ;
        }
    }

    return YtsRgstUsnKjfH;
}

void DoGMLYnwdXBnX::mkNSlALgFHRpFs()
{
    double XMLLliwPZJyf = -790497.8620467471;
    string AjdcTeSxxQRAo = string("sMvmDCamSFVXkLYtLqcGbzPwiMyVUBjYEbvRRgZyOWnQCKpCZOciilAyisDyIeWEWuQNYQNKzqfvFWiEJgREvhmAIwTUHbiJiqpxYrLjLYHzkGaBKnPtwzCrpQnUsJzhacryMgWGkyeoyzlcbszBGxNlDCoBqyTslPvjtxpHimMiRvXPcueDxvhaMfZulPzyQZFjznlZWArWvbMsdWVhZoPgZcsKJ");
    double sKbsHPPbyzzVly = -745966.6873869008;
    int QvyvxErm = -235560753;
    int HhVucR = -1534652027;
    double wIQfXrQHEqo = 454611.14382882905;
    string QIMfatglAECUk = string("nhBMWTPSWUqnawnxkSYfwNXxLEkiapRqTnNpKtmdyaDnvKSWkeiftrPpTdjGebIreXKefHRsBzEYchWRplXccwTZEQbMZRtxZtqSXLRTVF");
    string AbpmbjwUEMdzbYfi = string("GuLjzZNxkcYvMZZYMQuTWpphZFDGqdLSOVdGTEvmuSJAgOHYVpJohUWsqkhACwTSXSCZcqajKhYzFokBHbSorkWbuLUdjXebxlVGNfIAppeuvhmCNfacpnvcKLdkuJIQVMpSfFHXahOzFCaJEIhfIckeHleaFPlVSCADuplYnJtyUTzrNjraNYXDoEBQxyEBPMldmfGqMHJuHsQATUiC");

    if (sKbsHPPbyzzVly == 454611.14382882905) {
        for (int qhjPVdYqT = 1509070692; qhjPVdYqT > 0; qhjPVdYqT--) {
            QIMfatglAECUk += QIMfatglAECUk;
        }
    }

    for (int sTkEevWxiAyQL = 986791811; sTkEevWxiAyQL > 0; sTkEevWxiAyQL--) {
        wIQfXrQHEqo /= XMLLliwPZJyf;
    }

    for (int FNRNuGzX = 30781665; FNRNuGzX > 0; FNRNuGzX--) {
        continue;
    }

    for (int tlHccb = 1697277914; tlHccb > 0; tlHccb--) {
        XMLLliwPZJyf /= sKbsHPPbyzzVly;
        QIMfatglAECUk += QIMfatglAECUk;
        AbpmbjwUEMdzbYfi += AjdcTeSxxQRAo;
    }

    if (QvyvxErm < -1534652027) {
        for (int LGNhrZT = 1725701059; LGNhrZT > 0; LGNhrZT--) {
            sKbsHPPbyzzVly = wIQfXrQHEqo;
            QvyvxErm += HhVucR;
            wIQfXrQHEqo = sKbsHPPbyzzVly;
            AbpmbjwUEMdzbYfi += QIMfatglAECUk;
        }
    }

    for (int QgZsdRaJdsfiJL = 1339251295; QgZsdRaJdsfiJL > 0; QgZsdRaJdsfiJL--) {
        wIQfXrQHEqo -= sKbsHPPbyzzVly;
    }
}

bool DoGMLYnwdXBnX::lVgmj(bool ZnkhgKMDPcIABlo, string LJHVhTfGdaRlMYK)
{
    double WaKwVcFjnPufF = -849936.1858632202;

    if (LJHVhTfGdaRlMYK < string("TguCjKhZiYRcQsgOKghUdCENHpxzUghpZXQrPyQkqQJMmtyPXwLLHUcbdodpnkaxydaqNWdpTsZAygKbZIyEoIIJyPLeWRgZnVLnLXfYJdfMysJXiWqtnvljSMVeWntdxAbmesiAelulJiRPhNrQFDkSKjmseoBaLuUXerFmIPTOaYrFVOpA")) {
        for (int pOgAlq = 671476988; pOgAlq > 0; pOgAlq--) {
            continue;
        }
    }

    for (int xjafzRogck = 776912751; xjafzRogck > 0; xjafzRogck--) {
        ZnkhgKMDPcIABlo = ZnkhgKMDPcIABlo;
        ZnkhgKMDPcIABlo = ZnkhgKMDPcIABlo;
    }

    for (int QSxsSQsSyLy = 414239112; QSxsSQsSyLy > 0; QSxsSQsSyLy--) {
        LJHVhTfGdaRlMYK += LJHVhTfGdaRlMYK;
        ZnkhgKMDPcIABlo = ! ZnkhgKMDPcIABlo;
        ZnkhgKMDPcIABlo = ! ZnkhgKMDPcIABlo;
    }

    if (WaKwVcFjnPufF <= -849936.1858632202) {
        for (int njBhoK = 282302351; njBhoK > 0; njBhoK--) {
            continue;
        }
    }

    for (int MEVFyqTPI = 1553906283; MEVFyqTPI > 0; MEVFyqTPI--) {
        continue;
    }

    for (int VFExDnRrYjsrV = 66263132; VFExDnRrYjsrV > 0; VFExDnRrYjsrV--) {
        ZnkhgKMDPcIABlo = ZnkhgKMDPcIABlo;
        ZnkhgKMDPcIABlo = ! ZnkhgKMDPcIABlo;
    }

    for (int xSwWRHcOxOQr = 774288439; xSwWRHcOxOQr > 0; xSwWRHcOxOQr--) {
        WaKwVcFjnPufF = WaKwVcFjnPufF;
        ZnkhgKMDPcIABlo = ! ZnkhgKMDPcIABlo;
        LJHVhTfGdaRlMYK = LJHVhTfGdaRlMYK;
        ZnkhgKMDPcIABlo = ! ZnkhgKMDPcIABlo;
    }

    for (int dUfyuVfSKb = 410574635; dUfyuVfSKb > 0; dUfyuVfSKb--) {
        LJHVhTfGdaRlMYK = LJHVhTfGdaRlMYK;
        ZnkhgKMDPcIABlo = ! ZnkhgKMDPcIABlo;
    }

    return ZnkhgKMDPcIABlo;
}

int DoGMLYnwdXBnX::nRaYyMxencez()
{
    string NvNthRPSAaKnlvcG = string("bzpDuPaAMejLWFLhutYvJdmTRQICAXjEPRjzvhBayXMusEwqWXDWEfWEEHvkrpPRwoPUCnYQBwZCjJNFYQXLLdGWWKqODgDAklrBLWgegQsznBeBnyZtnHbohquFcMSEEvytLJDlxlJPfHgFf");
    int cFvPexnto = -1442796593;

    if (NvNthRPSAaKnlvcG == string("bzpDuPaAMejLWFLhutYvJdmTRQICAXjEPRjzvhBayXMusEwqWXDWEfWEEHvkrpPRwoPUCnYQBwZCjJNFYQXLLdGWWKqODgDAklrBLWgegQsznBeBnyZtnHbohquFcMSEEvytLJDlxlJPfHgFf")) {
        for (int JeGkTiBxpxq = 420435220; JeGkTiBxpxq > 0; JeGkTiBxpxq--) {
            NvNthRPSAaKnlvcG += NvNthRPSAaKnlvcG;
        }
    }

    if (NvNthRPSAaKnlvcG <= string("bzpDuPaAMejLWFLhutYvJdmTRQICAXjEPRjzvhBayXMusEwqWXDWEfWEEHvkrpPRwoPUCnYQBwZCjJNFYQXLLdGWWKqODgDAklrBLWgegQsznBeBnyZtnHbohquFcMSEEvytLJDlxlJPfHgFf")) {
        for (int fEFMgZnGdrG = 1574563591; fEFMgZnGdrG > 0; fEFMgZnGdrG--) {
            NvNthRPSAaKnlvcG = NvNthRPSAaKnlvcG;
            NvNthRPSAaKnlvcG += NvNthRPSAaKnlvcG;
            cFvPexnto += cFvPexnto;
        }
    }

    if (NvNthRPSAaKnlvcG > string("bzpDuPaAMejLWFLhutYvJdmTRQICAXjEPRjzvhBayXMusEwqWXDWEfWEEHvkrpPRwoPUCnYQBwZCjJNFYQXLLdGWWKqODgDAklrBLWgegQsznBeBnyZtnHbohquFcMSEEvytLJDlxlJPfHgFf")) {
        for (int iaWKnDZvAJytGx = 452641227; iaWKnDZvAJytGx > 0; iaWKnDZvAJytGx--) {
            NvNthRPSAaKnlvcG += NvNthRPSAaKnlvcG;
        }
    }

    if (NvNthRPSAaKnlvcG <= string("bzpDuPaAMejLWFLhutYvJdmTRQICAXjEPRjzvhBayXMusEwqWXDWEfWEEHvkrpPRwoPUCnYQBwZCjJNFYQXLLdGWWKqODgDAklrBLWgegQsznBeBnyZtnHbohquFcMSEEvytLJDlxlJPfHgFf")) {
        for (int YbwsRfFRah = 48092940; YbwsRfFRah > 0; YbwsRfFRah--) {
            NvNthRPSAaKnlvcG = NvNthRPSAaKnlvcG;
        }
    }

    return cFvPexnto;
}

string DoGMLYnwdXBnX::FgWEUAdV(double WiBYUn, string BZEvhWQSb, int EtMOEtaO, double eQdzi)
{
    double cGMLzAIyeuOJd = -676121.7369810286;

    for (int BrYHbyZh = 1350451714; BrYHbyZh > 0; BrYHbyZh--) {
        cGMLzAIyeuOJd *= WiBYUn;
    }

    for (int MDyHPHQTZBMNLvY = 712473973; MDyHPHQTZBMNLvY > 0; MDyHPHQTZBMNLvY--) {
        continue;
    }

    if (cGMLzAIyeuOJd <= -676121.7369810286) {
        for (int vWGbNzNXLCbg = 1823519243; vWGbNzNXLCbg > 0; vWGbNzNXLCbg--) {
            cGMLzAIyeuOJd += eQdzi;
        }
    }

    for (int XowLZrRhlJtBYrg = 1145327328; XowLZrRhlJtBYrg > 0; XowLZrRhlJtBYrg--) {
        WiBYUn += cGMLzAIyeuOJd;
        cGMLzAIyeuOJd += eQdzi;
        eQdzi -= eQdzi;
        eQdzi /= WiBYUn;
        cGMLzAIyeuOJd += WiBYUn;
        eQdzi -= cGMLzAIyeuOJd;
    }

    if (eQdzi <= -676121.7369810286) {
        for (int lLvgxVBl = 469213834; lLvgxVBl > 0; lLvgxVBl--) {
            EtMOEtaO *= EtMOEtaO;
        }
    }

    for (int gsGXrMj = 1183496791; gsGXrMj > 0; gsGXrMj--) {
        EtMOEtaO /= EtMOEtaO;
        WiBYUn = eQdzi;
        cGMLzAIyeuOJd -= WiBYUn;
        BZEvhWQSb = BZEvhWQSb;
    }

    return BZEvhWQSb;
}

DoGMLYnwdXBnX::DoGMLYnwdXBnX()
{
    this->ifqucfcYndyC();
    this->GKwrDKLqxbNZ(string("QJMHswBuYcqYpXXzolYDvwkVMyzUMrJcfwfcxZdq"), 302581.8292350936, true);
    this->kZKIf();
    this->mCnonDpwb(false, -1035825418, 1831668566);
    this->VofjoHHwXRUJaB(364515.912821808, 62741469, 454196.45979420404, -756162012, string("xGXCftxIAhSqpnKQWXxrqYojPWyWcSjLwrHRwqucPIqVmkkuAmiWhjyIsysuSMZWVfZPrJWqdHHiaWQRhlcQNuqeAcdnrhoZrRYOQi"));
    this->ZGPduCPJGIkHo();
    this->tvETuJ();
    this->vVTvvGGaqkUXli(-627703010, -908293.9410628683);
    this->UXZHKYCkSlP();
    this->ByyAX(1416219936, -1430681021, string("GlgHsKaGCAEYPcDBXzRtZTsidqhqdXTwFZlopHgBjUatHKkFzSWezvQdVHIKGBqVHevrDGFYFwRtVgjstIwSzPhPhBHsCDsRpErhJGLqXjQfTLRCXPViqq"));
    this->mkNSlALgFHRpFs();
    this->lVgmj(false, string("TguCjKhZiYRcQsgOKghUdCENHpxzUghpZXQrPyQkqQJMmtyPXwLLHUcbdodpnkaxydaqNWdpTsZAygKbZIyEoIIJyPLeWRgZnVLnLXfYJdfMysJXiWqtnvljSMVeWntdxAbmesiAelulJiRPhNrQFDkSKjmseoBaLuUXerFmIPTOaYrFVOpA"));
    this->nRaYyMxencez();
    this->FgWEUAdV(10180.363126013044, string("ccpyKveKMlKnkXMudTXhIKMweXWFwfZeroWdbEuGgBGwhHGFrreiUabPJnYUIfYVsjtjOHhbmceTLzwCHxSgxyYKaOJPCsOMhM"), 137449716, -722205.0228031443);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PlBlA
{
public:
    bool FnOTOks;
    int glEzdY;

    PlBlA();
    double igZmewmW(int ETgZygoh, double xRRXtoTbpZIKvZWs, int weqmUaM, double fdSeFaFroE);
    bool mZPFhXEBpagR(int NuNzlniAYNl);
protected:
    int DAifnXCn;
    double VGJNW;
    bool IuCXHpSFJyfWtD;
    double zDqVOIGpqNXHp;
    double GKPQKNz;

    bool NSNzWyugMv(bool ZtPhhKrzXW, string qqDpb, int SPLZKoMD, bool RjDWWJ);
    bool RBdoFzBpjVo(bool wjcGohCBRF);
    double WrzQJKQkiAqBr(double gnKiBGzKpO, double gIORXoCyXcfZX, double YjaFMoWyQrWb, int sTnALNMJom, bool LYtCFgmHXQ);
    void YUsmt(int NwBtQ);
    string WoOyewFdOGFRBgQ(bool ObPoTrbVIH, int EJeJNpDB, string vLtvw, bool GQjgE);
    string YdMcoDWLuNr(int heijsbRxZ, string MAoGVTCAAXfFZ, int uSDDDniKFojAW, bool kPmeUthDHOMlDbg, double hMoOMjcvQPTV);
    double fmPbOrpNtNLmVXg(int PpnFGqMTAs, int uOqEE, int SKgOMDPqyMbhohHS);
    void znQVqq(bool jQdWtHaKeIM, int PccpbAW, double mMCUNNQwryUOOL, string nrmrS);
private:
    string QZCsLrCixJyMEBsf;
    string zGasoTl;
    bool UhjIpDcF;
    string bynTwCWxY;
    double fcMBQNWTd;

    string hSwdPFpzxVtN(double bRxutzPCLPSnFx, int ahUMB, bool nysiXnBuigXXtHDg, bool NEZCdaPPJh, string ExXPceu);
    void lnkGMpMbq();
    void VBSgkytxgcsGArUY(double FBXbvicG);
    void mWvYS();
    string xlEHCUlGb();
};

double PlBlA::igZmewmW(int ETgZygoh, double xRRXtoTbpZIKvZWs, int weqmUaM, double fdSeFaFroE)
{
    string mTwKVieDxDZCihsD = string("ZwAwfAitpDSUkjVyMBPrFAyeXPVxBwurDWTCHoEoHdqIYdFPqZrbtjZaAjZqcxhFVoUHOtqyEGQkuaDsBJxrFndOaZOZZvaDYmAuQbZLHLYGEmIgDCYZMTEiAaDuRkJVovtyjgxPnsKWw");
    string fpGFvQ = string("HJZAJOUQofcbNCRwYxiGcMbHxePvjoljbQLQvwaltxWVpPhnrLparuSAshbiFmDnIvJHGnQhPnEiHhtbVRZSwParjQQVgCAnYYdiXpNBPgLeEbplotgAIShQUrBCZmmqixAGuZojpGREZZMJFkNTwsqNYTAVNtOJjAUuIcYYRqbtJCdXdheZpGntDDhglaAKDRtVP");
    int shYQrBKMWNlQcZzA = -1133675000;
    double cbIFjeT = -688979.9858695439;
    int bRbvrRDHemd = -1139723213;

    for (int jSwHIqOziWZEdh = 1770158261; jSwHIqOziWZEdh > 0; jSwHIqOziWZEdh--) {
        continue;
    }

    if (bRbvrRDHemd == 1884178221) {
        for (int hKENQgjBy = 1798743351; hKENQgjBy > 0; hKENQgjBy--) {
            xRRXtoTbpZIKvZWs += xRRXtoTbpZIKvZWs;
            ETgZygoh /= ETgZygoh;
            shYQrBKMWNlQcZzA += ETgZygoh;
            ETgZygoh -= weqmUaM;
            cbIFjeT -= cbIFjeT;
        }
    }

    return cbIFjeT;
}

bool PlBlA::mZPFhXEBpagR(int NuNzlniAYNl)
{
    bool zzKTlu = true;
    bool RNJLHAy = true;
    bool pMkTcodaEQm = false;
    bool GHiVA = true;
    int hwAmiHKach = -620043472;

    for (int msFRE = 415384516; msFRE > 0; msFRE--) {
        GHiVA = ! GHiVA;
        pMkTcodaEQm = RNJLHAy;
        RNJLHAy = zzKTlu;
        zzKTlu = zzKTlu;
    }

    return GHiVA;
}

bool PlBlA::NSNzWyugMv(bool ZtPhhKrzXW, string qqDpb, int SPLZKoMD, bool RjDWWJ)
{
    bool bHhvCCSeetPhp = false;
    bool PLwxtJZpLRqokQA = false;
    double fwdyRZICLNoMYR = 286364.37652736914;
    bool okeOwThJY = true;
    bool qKkrXygYmmECAP = false;
    double fANHCet = 231718.72917054794;
    double uHucvzBxleP = -980956.8768202007;

    for (int YhtzcY = 59274428; YhtzcY > 0; YhtzcY--) {
        okeOwThJY = bHhvCCSeetPhp;
    }

    for (int TZRKL = 1401648992; TZRKL > 0; TZRKL--) {
        RjDWWJ = okeOwThJY;
    }

    for (int oAgOB = 1704509479; oAgOB > 0; oAgOB--) {
        ZtPhhKrzXW = bHhvCCSeetPhp;
        bHhvCCSeetPhp = ! qKkrXygYmmECAP;
        RjDWWJ = ! qKkrXygYmmECAP;
    }

    for (int PuaKUqEAurorrX = 938159714; PuaKUqEAurorrX > 0; PuaKUqEAurorrX--) {
        continue;
    }

    return qKkrXygYmmECAP;
}

bool PlBlA::RBdoFzBpjVo(bool wjcGohCBRF)
{
    double ZgUzkeZoVXxHv = 489942.41308320157;
    double dFDNvTyU = -923880.6237711144;
    int LRqdD = -2132193026;
    int KACFomObjloXTRgk = 342749829;
    string WMrfhZRYlylYQiw = string("LKEflbItIHMCIEhJSoxjooaWqCBHZApGknYhGoWAAitkWbvdzJXSwRUDvRkjrwamMJyvQfZFWTIHaTjdMJLlByXQUXfjSbZzdCLuPmaPvTvenKysjoRyHkXtMybKjPkevd");
    double aDSQKjgBGobOi = 663662.1519745413;
    string gvjmvhq = string("wChFcceCuekmtOxbazvkhhUGhsRBhkHYaVxVSGXsetLrtqmJsBhTFzJZgRXvuepWtggboXnJzOCpcfroHZVIwbsYAGsuguJEMSIFieoIvtDhEFjLxdNNwfKEmrMlRCCjUY");
    string DZhdYoQStBA = string("OyzCSCWRzqLSzPCoQVffBkmBnrsBnYhBXXPCrbhUtRJUQPgorVdzYxaGfEHNlsyiIwKEbCwaiJdkxvYwFKOrqKRmnfxFcEocBXcpVtnAPpSGqINniFXMrZQzfCHLlvCdeZUjDBDnQwCTRekhsIPnlZLitQdtHrutYtBYDlIaXc");
    double fUfqEKM = -689470.9894331604;
    string yfegfRdGYhMOc = string("VWSicPctXDYvkIhtPIhSwZoJCsLFOtCmTOZnmwxiujeipLSnpFqGBMVYTRijPpBOBVFAwwnq");

    if (fUfqEKM == -689470.9894331604) {
        for (int YRySIWagAdBHD = 543797572; YRySIWagAdBHD > 0; YRySIWagAdBHD--) {
            gvjmvhq = WMrfhZRYlylYQiw;
        }
    }

    for (int POBbHB = 1055234537; POBbHB > 0; POBbHB--) {
        dFDNvTyU *= dFDNvTyU;
    }

    for (int FhLhGIfzGzJ = 966354322; FhLhGIfzGzJ > 0; FhLhGIfzGzJ--) {
        continue;
    }

    return wjcGohCBRF;
}

double PlBlA::WrzQJKQkiAqBr(double gnKiBGzKpO, double gIORXoCyXcfZX, double YjaFMoWyQrWb, int sTnALNMJom, bool LYtCFgmHXQ)
{
    string QISUjnIvgh = string("dItrW");
    int yvJqBwVp = 51340839;
    bool IkYnVhuyKfYLiI = false;
    int yFNWLbpj = -2125358093;
    bool gnUeJHoEXJimta = true;
    bool VHVFvYavOWpa = false;
    double ysuadnw = 166941.05597822776;
    bool cnpPHX = true;
    int uiivThQuzllt = -2016907500;

    return ysuadnw;
}

void PlBlA::YUsmt(int NwBtQ)
{
    int AuGtSfnezWMp = 1495231705;

    if (AuGtSfnezWMp != 1495231705) {
        for (int azdCDJ = 648393987; azdCDJ > 0; azdCDJ--) {
            AuGtSfnezWMp += AuGtSfnezWMp;
            AuGtSfnezWMp -= NwBtQ;
            AuGtSfnezWMp = AuGtSfnezWMp;
        }
    }

    if (NwBtQ == 2095880291) {
        for (int teGEa = 1093865909; teGEa > 0; teGEa--) {
            NwBtQ -= AuGtSfnezWMp;
            NwBtQ *= NwBtQ;
            NwBtQ = NwBtQ;
            AuGtSfnezWMp = NwBtQ;
            NwBtQ /= NwBtQ;
            AuGtSfnezWMp *= NwBtQ;
            NwBtQ /= AuGtSfnezWMp;
            NwBtQ *= NwBtQ;
        }
    }

    if (AuGtSfnezWMp == 1495231705) {
        for (int ulHpcgNxn = 2050910306; ulHpcgNxn > 0; ulHpcgNxn--) {
            AuGtSfnezWMp -= AuGtSfnezWMp;
            AuGtSfnezWMp -= NwBtQ;
            NwBtQ = AuGtSfnezWMp;
            NwBtQ -= NwBtQ;
            NwBtQ /= AuGtSfnezWMp;
            NwBtQ /= AuGtSfnezWMp;
            AuGtSfnezWMp /= AuGtSfnezWMp;
            AuGtSfnezWMp /= AuGtSfnezWMp;
            NwBtQ *= AuGtSfnezWMp;
            AuGtSfnezWMp -= AuGtSfnezWMp;
        }
    }

    if (AuGtSfnezWMp == 2095880291) {
        for (int JZyttKfXnVjRc = 958492942; JZyttKfXnVjRc > 0; JZyttKfXnVjRc--) {
            NwBtQ += NwBtQ;
            NwBtQ -= NwBtQ;
            AuGtSfnezWMp += AuGtSfnezWMp;
            NwBtQ -= NwBtQ;
            NwBtQ -= AuGtSfnezWMp;
            NwBtQ = AuGtSfnezWMp;
            AuGtSfnezWMp /= AuGtSfnezWMp;
            AuGtSfnezWMp = NwBtQ;
        }
    }

    if (NwBtQ > 2095880291) {
        for (int cHxAqXQjdLAqo = 548739149; cHxAqXQjdLAqo > 0; cHxAqXQjdLAqo--) {
            NwBtQ *= AuGtSfnezWMp;
            NwBtQ /= AuGtSfnezWMp;
            NwBtQ *= AuGtSfnezWMp;
            NwBtQ = AuGtSfnezWMp;
            AuGtSfnezWMp /= NwBtQ;
            NwBtQ -= AuGtSfnezWMp;
            AuGtSfnezWMp += NwBtQ;
            AuGtSfnezWMp = NwBtQ;
        }
    }

    if (NwBtQ <= 1495231705) {
        for (int fUkmrjyfUgmEFcxj = 1851509457; fUkmrjyfUgmEFcxj > 0; fUkmrjyfUgmEFcxj--) {
            NwBtQ *= NwBtQ;
            NwBtQ /= AuGtSfnezWMp;
            NwBtQ /= NwBtQ;
            AuGtSfnezWMp = NwBtQ;
            NwBtQ -= NwBtQ;
        }
    }

    if (AuGtSfnezWMp > 1495231705) {
        for (int ujCGdQtSlIdCdGj = 43779696; ujCGdQtSlIdCdGj > 0; ujCGdQtSlIdCdGj--) {
            NwBtQ -= NwBtQ;
        }
    }
}

string PlBlA::WoOyewFdOGFRBgQ(bool ObPoTrbVIH, int EJeJNpDB, string vLtvw, bool GQjgE)
{
    bool YSYtSfKDwvuJeRo = false;
    bool VlFXH = true;
    bool OvlpiA = false;

    for (int UyFcvYdod = 1526156508; UyFcvYdod > 0; UyFcvYdod--) {
        ObPoTrbVIH = ! GQjgE;
    }

    for (int HXrkaSniniiwRqkv = 714758210; HXrkaSniniiwRqkv > 0; HXrkaSniniiwRqkv--) {
        ObPoTrbVIH = OvlpiA;
        GQjgE = OvlpiA;
    }

    for (int RlIWli = 2144152255; RlIWli > 0; RlIWli--) {
        VlFXH = ! OvlpiA;
        VlFXH = ! YSYtSfKDwvuJeRo;
        OvlpiA = ! YSYtSfKDwvuJeRo;
        ObPoTrbVIH = ! GQjgE;
    }

    for (int QPXHoFOiMTo = 499346553; QPXHoFOiMTo > 0; QPXHoFOiMTo--) {
        continue;
    }

    return vLtvw;
}

string PlBlA::YdMcoDWLuNr(int heijsbRxZ, string MAoGVTCAAXfFZ, int uSDDDniKFojAW, bool kPmeUthDHOMlDbg, double hMoOMjcvQPTV)
{
    string AGVcDZ = string("nYbEaKjrlEOiTBusMAucCiKTfikgXIfYxIHwjzEMfGjZKCRGxmxRhAqTRsGOZgCdJUfJRSjwjtXRFcSipHhgtNtbWTKdqLYBISIsmCpzzjztiIyJaTaGEtfJTLBfkILGMXlQAhEkMSDxlZYcZazhLPDkbYIdLUceMwfMqTW");
    bool HMIgBebNrRSK = false;
    int zhxjHHhvwc = -1690228762;

    for (int AuEKHMTmE = 683401754; AuEKHMTmE > 0; AuEKHMTmE--) {
        continue;
    }

    if (MAoGVTCAAXfFZ != string("nYbEaKjrlEOiTBusMAucCiKTfikgXIfYxIHwjzEMfGjZKCRGxmxRhAqTRsGOZgCdJUfJRSjwjtXRFcSipHhgtNtbWTKdqLYBISIsmCpzzjztiIyJaTaGEtfJTLBfkILGMXlQAhEkMSDxlZYcZazhLPDkbYIdLUceMwfMqTW")) {
        for (int GMOZmUK = 365177239; GMOZmUK > 0; GMOZmUK--) {
            kPmeUthDHOMlDbg = HMIgBebNrRSK;
            heijsbRxZ *= zhxjHHhvwc;
            zhxjHHhvwc -= zhxjHHhvwc;
        }
    }

    for (int UrAZRuX = 1866667229; UrAZRuX > 0; UrAZRuX--) {
        continue;
    }

    return AGVcDZ;
}

double PlBlA::fmPbOrpNtNLmVXg(int PpnFGqMTAs, int uOqEE, int SKgOMDPqyMbhohHS)
{
    int zXfqmQ = 1059325346;
    int fQfofFHnwPDon = -1005583969;
    int VMOWu = -204945371;
    int wJUdByswbiCh = 1657424467;
    bool OsXENoMDcXwLb = true;
    double eKrTCyLzGoFAARaO = 249925.66558844896;
    bool MYGPGiwo = false;
    double VzUWRyhwMTQnS = 1017788.0873521168;
    int cXedRhKSAXlbkkG = -1520244206;

    for (int CKvBjMfGrg = 1976593628; CKvBjMfGrg > 0; CKvBjMfGrg--) {
        uOqEE += PpnFGqMTAs;
        fQfofFHnwPDon += cXedRhKSAXlbkkG;
    }

    if (wJUdByswbiCh <= -204945371) {
        for (int NXdDqXQly = 1053850311; NXdDqXQly > 0; NXdDqXQly--) {
            zXfqmQ *= SKgOMDPqyMbhohHS;
            SKgOMDPqyMbhohHS /= cXedRhKSAXlbkkG;
            fQfofFHnwPDon = wJUdByswbiCh;
        }
    }

    return VzUWRyhwMTQnS;
}

void PlBlA::znQVqq(bool jQdWtHaKeIM, int PccpbAW, double mMCUNNQwryUOOL, string nrmrS)
{
    double topzAOwinBewIAw = -28810.607687868305;
    double GojFd = 943863.5383802876;
    double QijwSHG = 948699.9210072545;
    double WedmBoWNKCp = 662676.1743577573;
    bool mnHNv = false;

    for (int VRSUgitOXNO = 1572919837; VRSUgitOXNO > 0; VRSUgitOXNO--) {
        mMCUNNQwryUOOL -= topzAOwinBewIAw;
        QijwSHG += WedmBoWNKCp;
    }

    for (int eSITTDetYFEb = 797171180; eSITTDetYFEb > 0; eSITTDetYFEb--) {
        WedmBoWNKCp += topzAOwinBewIAw;
        QijwSHG += QijwSHG;
        mMCUNNQwryUOOL *= WedmBoWNKCp;
        WedmBoWNKCp = mMCUNNQwryUOOL;
    }

    for (int DnYLHgS = 1921987628; DnYLHgS > 0; DnYLHgS--) {
        WedmBoWNKCp -= GojFd;
    }

    for (int uUSqusAMFdocD = 336725743; uUSqusAMFdocD > 0; uUSqusAMFdocD--) {
        continue;
    }

    if (WedmBoWNKCp > -28810.607687868305) {
        for (int ZXlAEhaWozsKfH = 28555451; ZXlAEhaWozsKfH > 0; ZXlAEhaWozsKfH--) {
            continue;
        }
    }
}

string PlBlA::hSwdPFpzxVtN(double bRxutzPCLPSnFx, int ahUMB, bool nysiXnBuigXXtHDg, bool NEZCdaPPJh, string ExXPceu)
{
    double ZzvGpyDZDlrBmo = 574575.3137806238;
    int GPOjDw = 1683569614;
    double DvQGPDJRsxE = -29191.82637111347;
    bool RxJVOugXriKcoSay = true;
    double uQnafYiUb = 503635.46520599275;
    bool hpXqYxVYuaj = false;
    double YvpGDEN = -60415.92012503733;
    bool SrsTKdqbf = false;

    for (int dGZBlmNrSO = 1212705627; dGZBlmNrSO > 0; dGZBlmNrSO--) {
        continue;
    }

    for (int OfOldVpTVP = 1648452755; OfOldVpTVP > 0; OfOldVpTVP--) {
        bRxutzPCLPSnFx *= uQnafYiUb;
        SrsTKdqbf = nysiXnBuigXXtHDg;
        RxJVOugXriKcoSay = NEZCdaPPJh;
    }

    for (int UWWaMFWO = 991867602; UWWaMFWO > 0; UWWaMFWO--) {
        uQnafYiUb -= ZzvGpyDZDlrBmo;
        hpXqYxVYuaj = ! SrsTKdqbf;
        ZzvGpyDZDlrBmo -= bRxutzPCLPSnFx;
        hpXqYxVYuaj = NEZCdaPPJh;
    }

    if (ZzvGpyDZDlrBmo > 503635.46520599275) {
        for (int rRhhYbpTKJCj = 731732311; rRhhYbpTKJCj > 0; rRhhYbpTKJCj--) {
            continue;
        }
    }

    if (SrsTKdqbf != false) {
        for (int EnewqoqHvrYDhPw = 179249453; EnewqoqHvrYDhPw > 0; EnewqoqHvrYDhPw--) {
            uQnafYiUb = bRxutzPCLPSnFx;
            bRxutzPCLPSnFx = bRxutzPCLPSnFx;
            uQnafYiUb /= DvQGPDJRsxE;
        }
    }

    return ExXPceu;
}

void PlBlA::lnkGMpMbq()
{
    int MhMEP = 563880624;
    string ztoLwkWzBl = string("RJvibBTeayuPOgSrDucqjdQjRnNeXIKkiAiLtMJmjjJfIdzLJYZuEmQZzSLIutHAzzvRAEKwMNkoQzwUbPqxQlnxBHbgeLGlAFkoOw");
}

void PlBlA::VBSgkytxgcsGArUY(double FBXbvicG)
{
    bool MYudkXXnDOA = true;
    double ClIfGDCLi = 120437.3259763063;
    bool eYRcWJfcVIvSqu = false;
    double kFvUaQGxIcRokrI = 180404.47972104172;
    string NBzSLl = string("yVfPGQjNZaaDcsRwMOPBaxynImTMddcOuKmTVkCRcbxwAUMyezYcorJAjFaIzUDxFlcHOoZPfMtViBmycyzDxNsherLNTwucRZJzXUXLIjTRTOBqjBSEynNSWOfHxLvOcvmiAwJmbgXDCkztenMbIozyRineTVnTrGabBEHqKVHrPBmwodBWaxtHzowFknLhtnUCObZiZRzS");

    if (eYRcWJfcVIvSqu == true) {
        for (int UkbopXwLmHzBTj = 2126665848; UkbopXwLmHzBTj > 0; UkbopXwLmHzBTj--) {
            continue;
        }
    }

    for (int SSlqDKHUYIAyWFe = 572829909; SSlqDKHUYIAyWFe > 0; SSlqDKHUYIAyWFe--) {
        MYudkXXnDOA = eYRcWJfcVIvSqu;
        ClIfGDCLi += ClIfGDCLi;
        kFvUaQGxIcRokrI -= ClIfGDCLi;
        NBzSLl = NBzSLl;
        ClIfGDCLi *= ClIfGDCLi;
    }

    if (ClIfGDCLi < 120437.3259763063) {
        for (int mGlMqZNDKloF = 1335667635; mGlMqZNDKloF > 0; mGlMqZNDKloF--) {
            continue;
        }
    }

    if (FBXbvicG == 120437.3259763063) {
        for (int hkKvwoSOn = 81237137; hkKvwoSOn > 0; hkKvwoSOn--) {
            continue;
        }
    }

    for (int tfFWID = 219462790; tfFWID > 0; tfFWID--) {
        ClIfGDCLi = FBXbvicG;
    }
}

void PlBlA::mWvYS()
{
    double LoXLMoCBSdrKmlZ = -691714.6791010934;
    int slFmqz = -70812068;
    int SkIOhVz = -1901744376;
    string uVwJcRVEh = string("xUwUoifEdJudEbKOhKXzbBcCkBttRaTdgUCzEXkt");
    double UeKBLkLkovyW = -82758.75670062804;
    bool aVgeCIwBWsTp = true;
    int pVurK = 333253689;
    double CFtoaw = 478027.5412085055;

    for (int iJNfXO = 220986120; iJNfXO > 0; iJNfXO--) {
        pVurK /= slFmqz;
        LoXLMoCBSdrKmlZ /= LoXLMoCBSdrKmlZ;
    }
}

string PlBlA::xlEHCUlGb()
{
    bool ycYpiUfVsfNgFaft = true;
    double lvtHeL = 955789.8907914058;
    string VBvgzGeo = string("BrQcTmJbQixpbpHJvykmStMdticqfhzKsBOfHGbFqrSryKbGzpSEFpiiQSmMQdzNIAfkRLerOULsuLzRkroeCd");
    int IUmCjf = -1341842396;
    string dQqFigzI = string("YNwvHuihDwBgdtLcWPhReYOrCLjKxULKlKMEvFGjmpNVnqybwpejkFMxnQrkjmITUcDToaKJlCxCquRgDZNQiMONZMSunSDHdKPQtiKoRyHBRAwJiqzXkdubOBzdCdQWeBNvpFdRHPpGdFgflqRIPJKtJcPIkLPSbbpccMzOBmHdOlkrRxOECIVUskZnWjiwSBOskihjnwsUOBWByeTjwXbCYgJidwLvoiVhyQZEoSqPzQa");
    bool KuGVrZZN = true;
    double PPhxXZ = 270628.01660504943;
    double uzzFImvLsE = 124586.33547613012;
    int OKFPDHyRmYDJY = 1024507254;

    for (int POUUcbu = 1027657774; POUUcbu > 0; POUUcbu--) {
        IUmCjf *= IUmCjf;
        VBvgzGeo = dQqFigzI;
    }

    for (int DNWAx = 490454207; DNWAx > 0; DNWAx--) {
        KuGVrZZN = ! ycYpiUfVsfNgFaft;
        OKFPDHyRmYDJY += IUmCjf;
    }

    for (int zyjMBUvkO = 1208455914; zyjMBUvkO > 0; zyjMBUvkO--) {
        continue;
    }

    for (int FPtoaDJADloA = 390422861; FPtoaDJADloA > 0; FPtoaDJADloA--) {
        uzzFImvLsE /= PPhxXZ;
        dQqFigzI += dQqFigzI;
    }

    for (int JNfYiCTsP = 196768873; JNfYiCTsP > 0; JNfYiCTsP--) {
        ycYpiUfVsfNgFaft = ! KuGVrZZN;
        uzzFImvLsE = uzzFImvLsE;
        OKFPDHyRmYDJY = OKFPDHyRmYDJY;
    }

    if (OKFPDHyRmYDJY != 1024507254) {
        for (int sXxYJsJbyLfaH = 1674174969; sXxYJsJbyLfaH > 0; sXxYJsJbyLfaH--) {
            IUmCjf += OKFPDHyRmYDJY;
        }
    }

    return dQqFigzI;
}

PlBlA::PlBlA()
{
    this->igZmewmW(1884178221, -294423.68737100135, 1284856454, 840774.8142013011);
    this->mZPFhXEBpagR(-273162586);
    this->NSNzWyugMv(false, string("ygxQuPrsiyrdyIlfCvTJHgTNLXeEvQRguGemAUjzeOcnHFloGPSdlZAScplKfZP"), -1133109743, true);
    this->RBdoFzBpjVo(true);
    this->WrzQJKQkiAqBr(-1035991.4854289885, -273273.6419284215, 764124.8917955515, 948359082, false);
    this->YUsmt(2095880291);
    this->WoOyewFdOGFRBgQ(false, -1264739967, string("TuVVMpqfLCeXIlwYSTOCjfsnGFHEzPdrpiLtXliBfrwZYFpiKvYsksfngUprKzZHjDUZnZuApYldpumJmGqRNvMlnkXxLYnmomoKDSOeibJerdHOKrSwEjtcpoEPhZWZjGDrwNnXofnUYQVIdZCfUOUcutWMQkWHgRkIJXvYiVoZICvicJ"), false);
    this->YdMcoDWLuNr(1870874496, string("HbxIEgcMfPactuSwxnZhRdwsaGuDcHMDAkLQXZvYNxlLmLpjjqsgAtfisjkFdZZzIrByrmKuCqqkjERtRglqYUDHBvcveDDnULdPBU"), -54396458, false, -731839.9723795231);
    this->fmPbOrpNtNLmVXg(-1557979026, 1494786980, -1231125028);
    this->znQVqq(false, -1902880002, 103944.83885162385, string("UJKYuEXghVYGQoiJAUlzXPzxYITspLkANTcsHFfBFpOLnpZPhxjkLtyQRvavsSLhKhhqhAfGlOuqFTTxDJARQQEuxXHMQcAhpOqu"));
    this->hSwdPFpzxVtN(-237475.6927199332, 298087364, false, false, string("RMuQEHJIiIFmOpIglFzwVgoAFnMPuFtxHKwBYMNIQOqWJkiZCHAVTGaSmuniSnNlSgsEAfroJSzrQbuZNAuGuyHJLdKOTjhUKjZTOaZmxWKzZoLPqqfTKRDziQnRGpdEjpRTHQguDSVmNvDunPzemsVrEgZXwvplzcKiHMHwJardgGlaPqTpWvNtwUzGFJmWROwSeCBSHJmjcknSzcDRhMDPItdRevkeyLBd"));
    this->lnkGMpMbq();
    this->VBSgkytxgcsGArUY(-523823.9134070113);
    this->mWvYS();
    this->xlEHCUlGb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oxKtIj
{
public:
    string qvLoxbIgV;
    int thPqy;

    oxKtIj();
    string nJjUPVzOYdGYec();
    double MozrvqvEY(double ETwwTVhTLupmrb, string BGzpYIBJTR, int aAYvBijCiXyGI, string NKGOHyLqFP, string AzaGJUshzjeG);
protected:
    bool UfmuNoOq;
    int YPoqtzbWqSj;
    double nLrLWW;
    string clGkLDSVe;

    bool ndxkSiRP(bool JHCdywzVyjLRDSH, int VhkIFBTvbtOsHgFA, int fildQjhH);
    bool shxHKTXQ(double wFDoVzqvIBsu, double offNyjUYsFpR, double fLnkdoSAbc);
    bool LNbCUwTRTmYSdo(bool AFopSXCCsAEVSZB, bool ykSImWYYQiPSFU, int toPzMVANNmlikvm);
private:
    bool VDdjlACgTGWmTeh;
    int rDrnE;

};

string oxKtIj::nJjUPVzOYdGYec()
{
    bool xJTDd = false;
    bool vMBsChPJkTvEqvF = true;
    int GxZfyH = -1757051582;
    double MtpFLIcmifr = -558150.0205385126;
    string wroJhVd = string("CGfKYPYcScEXpqPmXZfVfjuvJozqSbJYgDPPolWnGJaAMlGKwMuzqvBQHTdCSERjXproEnPBdvlSbENeKROMomKqBdgxguNoisRSCN");
    double cUBkgZZvJAORNtJi = -313066.45364067197;
    string aMUeWp = string("ZqJvTdmOwiNVpeHlfxABdWMtcDvYEEEoWLmKkZdfKZwoYSdVTGQokinthZeoZxFqZizDbXZLZeWwJqSQvaaRltXxNZroXzSmMUsYjpfTjjdCpRzpKijRvlKWcDfUOvqnwPOQkpYATFFJYENQYxErUxnwhiYowhvqRspZUlVSQXZjGyKMyatzSjoByxtd");
    string xKgNNfKY = string("EDMjnMmORvIMUQbjemCJcRnsXUZNDOYStAnFtjBHz");
    bool SBaMgdmLpn = true;
    double QuxNWCe = 362861.90233602887;

    if (QuxNWCe > -558150.0205385126) {
        for (int mEuQyQFnrLQ = 428276531; mEuQyQFnrLQ > 0; mEuQyQFnrLQ--) {
            QuxNWCe = QuxNWCe;
            vMBsChPJkTvEqvF = ! SBaMgdmLpn;
        }
    }

    for (int vZIvaWpsvgozBc = 369240193; vZIvaWpsvgozBc > 0; vZIvaWpsvgozBc--) {
        vMBsChPJkTvEqvF = ! xJTDd;
    }

    for (int KWemJXqcChNiIvGq = 632343705; KWemJXqcChNiIvGq > 0; KWemJXqcChNiIvGq--) {
        cUBkgZZvJAORNtJi *= QuxNWCe;
        QuxNWCe -= cUBkgZZvJAORNtJi;
    }

    for (int foaCS = 233915737; foaCS > 0; foaCS--) {
        MtpFLIcmifr *= QuxNWCe;
    }

    return xKgNNfKY;
}

double oxKtIj::MozrvqvEY(double ETwwTVhTLupmrb, string BGzpYIBJTR, int aAYvBijCiXyGI, string NKGOHyLqFP, string AzaGJUshzjeG)
{
    int iQLvQ = 1944137245;
    bool zDLqGmeRgQsP = false;
    string dYMHPNwDdNFD = string("vfySavfxsaBkapjDQIhcFUgKFUgSJvTWkdTnWRPdxNualnRKfrXEvnEtIKjvVlNALVYJCuknddBckAKvdrJmCIifEuzgeFrexqEJBCrOWWBWKRDsFMzqPXIjGdkqNYngYArHzwIgGoDTewvEKdEApBqpkInrEiPtelbSeSKCclINIwcZTekFSRbxPdaoiTLjdDFbMDvQgRYRNNQfX");
    bool ZuyVehrDMpGzmtus = true;
    bool emkJwf = false;
    double RMGDUisBEuv = -88371.9153142429;

    for (int fgVWn = 87167714; fgVWn > 0; fgVWn--) {
        RMGDUisBEuv *= RMGDUisBEuv;
    }

    if (BGzpYIBJTR > string("wvkUDPgmfByRFwuMgDZctOCWipENYVLweBPULgpXA")) {
        for (int RvcUEHiV = 702589072; RvcUEHiV > 0; RvcUEHiV--) {
            BGzpYIBJTR += BGzpYIBJTR;
            ZuyVehrDMpGzmtus = ! emkJwf;
            ETwwTVhTLupmrb += ETwwTVhTLupmrb;
        }
    }

    if (aAYvBijCiXyGI < 1944137245) {
        for (int UoRoh = 1456972977; UoRoh > 0; UoRoh--) {
            continue;
        }
    }

    for (int PpKoIiN = 1397983541; PpKoIiN > 0; PpKoIiN--) {
        zDLqGmeRgQsP = ZuyVehrDMpGzmtus;
        iQLvQ -= iQLvQ;
        NKGOHyLqFP += NKGOHyLqFP;
    }

    return RMGDUisBEuv;
}

bool oxKtIj::ndxkSiRP(bool JHCdywzVyjLRDSH, int VhkIFBTvbtOsHgFA, int fildQjhH)
{
    double FOLkL = 764896.3430304327;
    double dcspbuiAC = 423916.97667879605;
    int pxbEcCnPHTmAmXI = 863013055;
    bool MWaCosEqk = true;
    int EGcQmV = -981149719;
    string EbuILkQlaVjld = string("VgkCZMiqxdKQrdEJpQjrjRNIYeANOTDQHDGacYPPitVrtgJRWZpUDZRiKvjNbNtxJxJkONwLEhQnGvSfUUUZgCtqZOZXnpWiaulwQXlufAmYwRKjfhKnSXJcZOsPcxStlMPBhiEtEbCMtWxRdDYQCXeoWlidEdkDOluqCqBaJKovpuELyEmHwdQzGKpfAnRLLEsvZTlXoJyqlthJasJhEwA");
    double wbwhzdzdRIZNEzbm = -300537.1766824678;
    string FyRrizygzO = string("ilKFjApmtZwBlqVWEebvKREeBRvbbdfXIEenetvyztgAQmseWDpzyaWSuinHFoyQnvmEGueRxIVmaSXcJPypbJXtPxyNalRDtoAkCDAbUGYfkECcbNOlUrTOiBrhnNBEFTPsRVYCdUaxZSeARHPPmepPSYWBujDEUdqmVqqdlgzUPnpBKwvFxEoRxSTEtgXIOVSPdnfgLeoqnOUwzDSwJZPMKrhQWRKMxmAnXPUXqcOhKdBkuOJxuA");
    double jONgfQqZeb = 595398.0195593305;

    return MWaCosEqk;
}

bool oxKtIj::shxHKTXQ(double wFDoVzqvIBsu, double offNyjUYsFpR, double fLnkdoSAbc)
{
    double oulSEg = 532294.1743111293;
    string dHdfmpRWG = string("bHlCoVUKxytfCIfwGkIALgmjFhwscZOvcTFzcUKeVTGTssuCZujyKVqAWUUaIQYeHKjbcWdWKPxEXeVGcfoYHqTAdGxfLJe");
    bool nHKVuRDjmsdQ = false;

    return nHKVuRDjmsdQ;
}

bool oxKtIj::LNbCUwTRTmYSdo(bool AFopSXCCsAEVSZB, bool ykSImWYYQiPSFU, int toPzMVANNmlikvm)
{
    int rZGIgkWyZ = 1921926866;
    bool WQyYfX = true;
    bool IDYrGHKg = false;
    double tvYwApqUgqmTtBbw = -400408.39925758715;

    for (int sdbwCWjOLo = 1616042972; sdbwCWjOLo > 0; sdbwCWjOLo--) {
        AFopSXCCsAEVSZB = AFopSXCCsAEVSZB;
    }

    return IDYrGHKg;
}

oxKtIj::oxKtIj()
{
    this->nJjUPVzOYdGYec();
    this->MozrvqvEY(311380.2022783374, string("atwrpZxEmStxTGoDhuMXLVLwPlLcEPyHwJXgMXXoBiRqllOcSPhZOphUinVIxEOArJstScKYKDTKJFnVEQFMLvNbRZiwUOvCDminymgNgjtZIuWRpQUyFOdFFPIbhVYojlkAgwEAIFKnAcdZMBwLXAOVioczSLrzfNJvWNuxKplcnpeZoHfUktZxFCCrxitFdgsseqgkzLtvOkeHF"), -430989225, string("wvkUDPgmfByRFwuMgDZctOCWipENYVLweBPULgpXA"), string("BHnPeXooigcLGdaofovDhjjpcMZFApeusXpD"));
    this->ndxkSiRP(false, 1987726030, -269339581);
    this->shxHKTXQ(-110016.28698453198, -635377.2717641209, -658567.6670729473);
    this->LNbCUwTRTmYSdo(true, true, 2041737362);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fhjzqXFVRIv
{
public:
    int bjhMRsHZdHRiagk;

    fhjzqXFVRIv();
    void AMyEiJqXEBXXxT(double NzWYnhyEEauEAtQ, double hKYDyEJorJajxgYA, int OpnzZzRNbrSOeQR);
    string hTnRWVoJo(double UdsRBG, string SURanQQ, double zEXRMjfiZNnYTu, double toVFZllGdMqOlU);
    string dnedYPGO(bool OpwaBapjwRxpHh, string YUefMbGRRQ, bool XZjAFbj, int whnLaDtXZLYC);
protected:
    string UOSXZVlS;
    string DjqSKJgCrz;
    string JVcYwtkiqdWUT;
    int GdyJqWHjt;
    bool oVVGkLngWpSGyTI;

private:
    string ShUTDfJMr;
    bool eWooZej;
    double CDLPsNbSdxNu;
    int ApHoMqZBtkeil;
    double pJUxJBqshuajqaI;

    int sAdYWmaTisVSsddP(string UILadJFfEKWvHyM, bool wXvpLd, string BuBaT, bool UrIPOWkh, string XBpIHYk);
    int ZvmigmKnqiTkY();
    string uKPmQdzLks(int hyZJkpfEv);
    int MKmDiQnrqGlrtP(int zjcnsVx, int YoQSAxuMlygDU);
    bool rthZo(double jiHxMWx, double ogaWCen, double pjjKrJAxDT, string yuDBWsvxmFQPacco, double SPDMTyqcdFajotP);
    void SynTRi(int TFXRss, bool gMfCzvTi, int VHLhwagOQ, bool vURSWBxm);
    int XOHZdqw(string QvWKjrCWVe);
    string wZZON(int TIIvZC, double UJOTyOuPlALQkaX);
};

void fhjzqXFVRIv::AMyEiJqXEBXXxT(double NzWYnhyEEauEAtQ, double hKYDyEJorJajxgYA, int OpnzZzRNbrSOeQR)
{
    bool oUSdFYffCMHpwk = true;
    string stTNH = string("xKNexSaqrhDXaPnxEqbLKwlnZwoXRkcCKwrwPYeMFgPJqQaDQimQkJifzcymxXTpznALgJBtPlMXgXtUbfewCaTKghmPbiRztvVuQoZkmPJcNoqfOHnDlHjrEDrgMGFHScDGANwJjbemlJCpeRETgFjnkoxsChzRtTBvjVwpbJfKuPWRtOnZmXrZoaqAKBrpIG");
    bool iptImOtn = true;
    bool JQbZDSduIxJDu = true;
    string ahqZXaDtyLHlEGI = string("ZbjvnLDfrVUqvjGlmsdCuEhUcfexToNSOcoDSjtJfiRZzQyWIAXlzEylShoTODnaXnTZbrhBJDenDtiwazcaVbnWtCCOZAENTbOmfHvZIWDgAsvHvNNyrffpemyRlqETRSDpAHCZnemzZzMUcZLJtej");

    if (OpnzZzRNbrSOeQR >= 816959682) {
        for (int CkfsBqWDYVH = 322820082; CkfsBqWDYVH > 0; CkfsBqWDYVH--) {
            continue;
        }
    }
}

string fhjzqXFVRIv::hTnRWVoJo(double UdsRBG, string SURanQQ, double zEXRMjfiZNnYTu, double toVFZllGdMqOlU)
{
    int VzDoSgShXcIb = 286914835;
    double CpwgTtozEbYhg = -510749.1833170819;
    string sIdiUfGTgFEVG = string("DMKyoUUIZCpZfihviEqPAEpvhxrvALLUHdeLAKkEemKsXwGpixOIJLIVfFVBjqZmXNbdeyOjyQPGSHKQuPOoTQSpJtRvvHMkzcBLiQieqNSsjebOdLmNYceHgpRTrSiSgaJJZAyOeHbmcYmjOenfyALyrIRsfkfqaAMUYnjCxlKUrUKjqIVpuxKvNQPGSTjfPRhvEAxhysSWnxnbkiFqdElYXlmjZpHN");
    bool lBnwwTOC = true;
    int wQRZx = -442013673;
    double WpyasgQ = -346905.47189328016;
    double KwgazFjPaHklf = 589494.5208620988;
    string tPbviwjU = string("UVojjGIlYPovdBnHaqANVSfFpfIxkLzyhcEwwMgHKKKbaVaNbPXwYssDklYhpFkriylOGYEgAxFogvlmUwVQGzzUqkmJhpEnwPBCIPuqwsZXxLwxvFoZiNXiHxsrsgHQTrDkkOtEnZRNQUwNcIaWCKGKHNgh");
    int tZoYCqnGfSuvvDm = -2069175839;
    double NZnbkOpF = -398214.0896115715;

    for (int gsSzmqdjs = 63370408; gsSzmqdjs > 0; gsSzmqdjs--) {
        KwgazFjPaHklf *= toVFZllGdMqOlU;
        NZnbkOpF *= UdsRBG;
    }

    return tPbviwjU;
}

string fhjzqXFVRIv::dnedYPGO(bool OpwaBapjwRxpHh, string YUefMbGRRQ, bool XZjAFbj, int whnLaDtXZLYC)
{
    bool xhICCdNGADEww = false;
    int AiqCHTb = -563062077;
    string kyzrHAjPt = string("WTOuefZoiAWuZyldrTALvvrXrvZoDPswQxpErdkhwtvLUtKXnWPoViJErdRyrrkRvYdpOElBiOwnhRMSzvyFTGOzLBDHknaVoJIOadUGdbfahjYwCOJNKWtjDbubLvO");
    bool sIqZTcTHoHXgQ = true;
    double TfOjWOpOih = -111570.55888159017;

    if (sIqZTcTHoHXgQ == true) {
        for (int TPehIsBOhE = 430808495; TPehIsBOhE > 0; TPehIsBOhE--) {
            whnLaDtXZLYC /= whnLaDtXZLYC;
            OpwaBapjwRxpHh = OpwaBapjwRxpHh;
        }
    }

    return kyzrHAjPt;
}

int fhjzqXFVRIv::sAdYWmaTisVSsddP(string UILadJFfEKWvHyM, bool wXvpLd, string BuBaT, bool UrIPOWkh, string XBpIHYk)
{
    double EcULntokfsN = -720195.590973298;
    double vlgcFdncnWnCa = 1010002.0794806144;

    for (int FnwnxbP = 372361406; FnwnxbP > 0; FnwnxbP--) {
        UrIPOWkh = wXvpLd;
    }

    for (int WmnqEpwQeK = 1724384696; WmnqEpwQeK > 0; WmnqEpwQeK--) {
        wXvpLd = ! wXvpLd;
        UrIPOWkh = UrIPOWkh;
        BuBaT += UILadJFfEKWvHyM;
    }

    if (EcULntokfsN < 1010002.0794806144) {
        for (int uQVeHPF = 550676221; uQVeHPF > 0; uQVeHPF--) {
            UILadJFfEKWvHyM = BuBaT;
        }
    }

    return -444627330;
}

int fhjzqXFVRIv::ZvmigmKnqiTkY()
{
    bool oCFyIZvUXO = false;
    int HXTSVL = 2033477679;
    int eepEwgyAqtYcwlv = -1195739748;
    bool MAvORqWGli = true;
    string aXtHlgxHTspDfa = string("HYWeGcqwPQRwkrWpODOjXJyAALsaoQsFXxlyuNSdsqvQzmfjSzgg");
    string ZAFPOwDiVTA = string("fhnDcOfPCBaBjQDeCfpiTjXazlBpGiRmWxWnpzjBKlaoiLcaSGACkXJiJoPtQuyUHXjwFEKPyVcHwWTXQwlNYxYUMYkNJcoJiHWFjQgeBklcXjOwWmHWoBKmPGHAGAbehnBkRYrBOIcmvgLCDrodakbxKdHPQAlgkxjliUgYqkOwDIuHhkroqejYIYtrZtXXDitjQXAhIQLLUWvRTuzEktEyD");
    double BTKjfpyqFN = 494872.9269554174;
    bool MePfVmGGwTnksHM = false;
    string DEfsfZUdHPBPwff = string("srKMRDcpIRTicsvVtdtHpxHfSCFHjHYtuTsrqaRXEThwGrclAJJyZkxpECmkioiLoabSWPWMpdVfibYTRyIKdYtIpifCxjYXGTIevgQnLpARHFMpdNxFIdTsiWUdHHtDJKuYULhKOrBiu");

    if (MAvORqWGli != false) {
        for (int fnEJHioXiog = 1406769197; fnEJHioXiog > 0; fnEJHioXiog--) {
            eepEwgyAqtYcwlv *= HXTSVL;
            oCFyIZvUXO = MAvORqWGli;
            ZAFPOwDiVTA = DEfsfZUdHPBPwff;
        }
    }

    for (int giSCtAxdmya = 644479597; giSCtAxdmya > 0; giSCtAxdmya--) {
        continue;
    }

    return eepEwgyAqtYcwlv;
}

string fhjzqXFVRIv::uKPmQdzLks(int hyZJkpfEv)
{
    double KzbpPzOYgoENJ = -444527.5065976235;
    int ogJsca = 884135997;
    string eaUtnXSyW = string("fwZyNFZuqZVXDbuEcxhbmggyjpnRGqhJNrDYn");
    double YfnEp = -142254.91542341383;
    string suDcqFbjXLZNiShe = string("jQPwPQCMFWpnkUmBOZRoAxiDNNHcbZarXrMfvJBcCOFycaDsdcTXYgcjzCutpYlA");
    string uTWrSfnup = string("kruHOPivLIfoFhbrYAdonBoGnyRiLzHSpdDdSGDCYqQjZobyGNRxUpRbRPsjMGCTTECZFzfSuxkvWfVUwHYnSNyfXxtdsQDVDoYehFUoI");

    if (eaUtnXSyW != string("kruHOPivLIfoFhbrYAdonBoGnyRiLzHSpdDdSGDCYqQjZobyGNRxUpRbRPsjMGCTTECZFzfSuxkvWfVUwHYnSNyfXxtdsQDVDoYehFUoI")) {
        for (int xedtGyVW = 767384999; xedtGyVW > 0; xedtGyVW--) {
            suDcqFbjXLZNiShe = suDcqFbjXLZNiShe;
        }
    }

    for (int doUfcWIgpSgk = 2140765916; doUfcWIgpSgk > 0; doUfcWIgpSgk--) {
        suDcqFbjXLZNiShe = suDcqFbjXLZNiShe;
        YfnEp = KzbpPzOYgoENJ;
        YfnEp = YfnEp;
        uTWrSfnup += eaUtnXSyW;
    }

    if (suDcqFbjXLZNiShe == string("kruHOPivLIfoFhbrYAdonBoGnyRiLzHSpdDdSGDCYqQjZobyGNRxUpRbRPsjMGCTTECZFzfSuxkvWfVUwHYnSNyfXxtdsQDVDoYehFUoI")) {
        for (int JLKyjAUuQtWa = 1272462527; JLKyjAUuQtWa > 0; JLKyjAUuQtWa--) {
            hyZJkpfEv *= hyZJkpfEv;
            KzbpPzOYgoENJ -= YfnEp;
        }
    }

    return uTWrSfnup;
}

int fhjzqXFVRIv::MKmDiQnrqGlrtP(int zjcnsVx, int YoQSAxuMlygDU)
{
    string BppHVfcvgIzwYgKv = string("MLQhEWpNemHzPikjrXrdrzofINLszMjWItkQShaMoerXAkGzHgHIKlAGOiUwaRuXreKjlHibHEQzlClnfkMcvbpOjGvVcosUrZqMnHwDGTixdNwy");
    double MWepe = -111969.95327012378;
    int fjYEGwzmi = 2083579439;

    if (zjcnsVx <= -1439858489) {
        for (int MTygLlObTbpxux = 1956997822; MTygLlObTbpxux > 0; MTygLlObTbpxux--) {
            YoQSAxuMlygDU = zjcnsVx;
            fjYEGwzmi += YoQSAxuMlygDU;
            BppHVfcvgIzwYgKv += BppHVfcvgIzwYgKv;
            zjcnsVx /= fjYEGwzmi;
            zjcnsVx = zjcnsVx;
        }
    }

    return fjYEGwzmi;
}

bool fhjzqXFVRIv::rthZo(double jiHxMWx, double ogaWCen, double pjjKrJAxDT, string yuDBWsvxmFQPacco, double SPDMTyqcdFajotP)
{
    double plsrtfrS = -28720.76812675858;
    string bRjXNtI = string("ITvTCvrbIABxjSSuYZsbQFiEOPMlhVsTnfNfbFlagxBwdMKKoYaaomLJonnksnVkOlvdsJAenQctfAuuLpbOwuDnIWvZGdBmacrFmHoIYCHBnynkaWQgRycUTdHAuAaoAQZNRgLHeImAxSuxUSJzGtWBdGcDmzuoKGtTzYcM");
    int KPfjq = 544600481;

    if (ogaWCen > 720346.3700274362) {
        for (int JLuDjNjEJBEggse = 502437423; JLuDjNjEJBEggse > 0; JLuDjNjEJBEggse--) {
            pjjKrJAxDT /= ogaWCen;
            KPfjq /= KPfjq;
        }
    }

    return true;
}

void fhjzqXFVRIv::SynTRi(int TFXRss, bool gMfCzvTi, int VHLhwagOQ, bool vURSWBxm)
{
    int WKbxCG = -515320942;
    int fVQHtUh = 1130437193;
    bool iQQoFTCYeXiQo = true;
    bool npzgFGPIHJN = true;
    int zwfpObuGXWXqHAv = 1132009579;

    for (int nAxTIIMmOZOKHUt = 710112010; nAxTIIMmOZOKHUt > 0; nAxTIIMmOZOKHUt--) {
        WKbxCG -= VHLhwagOQ;
    }
}

int fhjzqXFVRIv::XOHZdqw(string QvWKjrCWVe)
{
    string jUPlX = string("KRCaJUCqZwKFlSXjdBqfqrYiQxjTvjYeKHeGQXTiefOiLMxhGcCNDmuJjXJbSfRVDznlPzpbGUDTFRxicwxKAvnOWYyHqlnTktebjwRrQXrrsKuOoAWzWiqtCvMVKFdnsxDnKqRnMpffcfPidakVZbCzQWkJMIrCtadaBxoQqpeyFTJvusYRwBVGEAbAHVmSMQpaxsSY");
    bool gxbKFIMDTsCHRX = true;
    bool VQVqHGNtuIBzHftA = false;
    bool ptIuwRCxQhBUDqVk = true;
    bool PQrIITIkP = true;

    for (int yRAAAEKEEwt = 2072094553; yRAAAEKEEwt > 0; yRAAAEKEEwt--) {
        QvWKjrCWVe += jUPlX;
        QvWKjrCWVe += jUPlX;
        VQVqHGNtuIBzHftA = ! VQVqHGNtuIBzHftA;
    }

    return 289848150;
}

string fhjzqXFVRIv::wZZON(int TIIvZC, double UJOTyOuPlALQkaX)
{
    int yYceVxdjmQAJ = -977752087;

    for (int XKnmtCCxVK = 1591396543; XKnmtCCxVK > 0; XKnmtCCxVK--) {
        TIIvZC *= yYceVxdjmQAJ;
        yYceVxdjmQAJ -= TIIvZC;
    }

    if (TIIvZC == -1368857094) {
        for (int qSMCkZfTyhbnurM = 705658797; qSMCkZfTyhbnurM > 0; qSMCkZfTyhbnurM--) {
            TIIvZC -= TIIvZC;
            UJOTyOuPlALQkaX = UJOTyOuPlALQkaX;
            yYceVxdjmQAJ = TIIvZC;
            TIIvZC = TIIvZC;
            TIIvZC /= yYceVxdjmQAJ;
            yYceVxdjmQAJ = TIIvZC;
            TIIvZC = TIIvZC;
        }
    }

    if (TIIvZC <= -977752087) {
        for (int ehZbIAlYnnxkLwY = 2000306835; ehZbIAlYnnxkLwY > 0; ehZbIAlYnnxkLwY--) {
            TIIvZC *= yYceVxdjmQAJ;
            yYceVxdjmQAJ /= yYceVxdjmQAJ;
            yYceVxdjmQAJ /= TIIvZC;
            TIIvZC -= TIIvZC;
            yYceVxdjmQAJ -= TIIvZC;
            UJOTyOuPlALQkaX = UJOTyOuPlALQkaX;
        }
    }

    return string("LMHJvRLvWQeLeaKyHmuupGbeWGkFATmOklJtgcfNUHEUVJMmnjfhGgPsrxpMAOVjMcCRiXKUrujSsBzmSLWwwQGkqpgAAAjGDnsRLiqrUMzNOlmsLtsrKZBqtopaGPXVRDdjKMwercMlfuoKsnCjUtePDxGgTdwrFdhqoccUucZyOmaWpkhYvRnyXmvVivtODfFTDiUZIYDCzNDBdRzQTpkajPmMAKDpXDG");
}

fhjzqXFVRIv::fhjzqXFVRIv()
{
    this->AMyEiJqXEBXXxT(-1009855.6231423488, 462776.7589287111, 816959682);
    this->hTnRWVoJo(-20158.96274463257, string("WgyWwLXYAUbMiMKcdjnhLmhACUSUgUCPpgYsmXGTkhgHuLHUCEsaIhxGbHwykLIPKsusJVqsjolQFZKEyqwFtwDHIUDXohlSeitsnNmIgPqLOMoLvfCSAFUicnsDIByVpMSfjxwnn"), 860307.8122669216, -186521.9546649426);
    this->dnedYPGO(true, string("ofhOBWxqLAitrGziGbNRtnLukJalfuLsuEfUgzwnRtnIkiLbkHDKvEbgTVatksWsDnRcreOUoYPySvucutqvzCTavJnCBhGFJYBjnieTGXYaqwbMUhLTFbIzNmaSQQsdnPQZzAMdTUnNgNmTooQAPSaxztqVLCna"), false, 1053204253);
    this->sAdYWmaTisVSsddP(string("kJXkIicacjsPyzstyEAFSjPHJqKTJZulZTdOYbyXcVzdCKxYmxEGFHwKcFKgeYMhGUBQzqJAVVLryAbPPLYOjgVJWsAicjKrcCeReEpRoTWHuqAGspYFjuiMorflbUj"), true, string("OciNMOkgPlyRThtCoBSjBDkAeQGvKwsMxOsPqkxOCBmwGRsIcqMVqAUywPERhNYjNRBvGgKHbOZyEWKztShzRcHDctUOWIGILktrdRaQbgE"), false, string("IaITqCaDNnKGUACXh"));
    this->ZvmigmKnqiTkY();
    this->uKPmQdzLks(44464822);
    this->MKmDiQnrqGlrtP(1345255437, -1439858489);
    this->rthZo(-150461.90524333387, 720346.3700274362, 389531.3252644298, string("mzdJcjYusCyUFaTNcKSMXPaDiwGVsQzuYJeWXkzMCUlMtEqFHBsBtCDoSGXBkqQYKfYyWuxJnBIkNwtuTnDZBAQrYNXocQpfhfIipZlVTOTSpNFCeCcmxEZDFRlLfLQnAyJaKQsuFGZKpxKDrGgCTuOtIsUkBUwPsyYJfsXhvizddUUhxYHZCKQPKQhAbzRAAxJNRQlogTnmmyrZgRRgUtqQVEWBAMxzU"), 136748.27706296596);
    this->SynTRi(-1421278941, true, 2025312160, true);
    this->XOHZdqw(string("gAhiKZmTUWACwJmnTgwcWjYhkdrMLqestcJneSvEttOQLMjxJjlQDyEOPQdaUnhIwVbvOzSgANAObldfvTiDVzlMXXfCFgqjQfhDPUqeUmOLiArjOvGtTUDbbLF"));
    this->wZZON(-1368857094, 171461.53692606674);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RvdztKOhxv
{
public:
    bool OCmxKXCVU;

    RvdztKOhxv();
    double rHbXPUvpHIx(string XvLVFD, bool pQiNirYJsgZfeFv, string QmqBXx, int ldnRcWi);
    bool sRGQtnvld();
protected:
    int VcKYQFKcxAQnKW;
    bool PmSkqVuNaPgo;
    int qzkrCNZAuLoKTRps;

    bool JBJcaTEaZKQlA(double YcKvUl, int vdqCdAlwhco);
    string OqlrijsRFRPUs(int YEmNXzFCBOkVQh);
    int cBkutIl(bool HGQQjpJro);
    bool auZvrjbnuLhAV();
    double pihblUPJiwQOSRy(double lEeSiBbiBXoMosP);
    void jyHjpiXDOF(string ftbxsJ, string YetqEQxbLtc);
private:
    string GwESLHWWRZZOJE;

};

double RvdztKOhxv::rHbXPUvpHIx(string XvLVFD, bool pQiNirYJsgZfeFv, string QmqBXx, int ldnRcWi)
{
    string TxZZwnKSsioAG = string("fWlzIibtEcjjKbYMEjXnljmqxHwadwMAKfNgEjpjFJCLXLZwjPKAOqHITngZwuHCQyxgVp");
    double iuqdiPE = -414840.59642887296;
    double doapvVAx = 1032388.5574590995;
    int VdELtHjJgpdETMBU = -2049138649;
    bool DzWOWzGQUHwvU = false;
    string HVpvQPSXqcuiK = string("ldKxqKaOgfAIRXsTtrezAJEmJnaDapeZRHhAUVIHmyfVBFKUaNtWocwcRJOMAeMYdQDflSFEShmTwGNzKITUJoDtNkYUd");
    double ZqCHVyDkX = 113894.54189288702;

    for (int IQdzBPXUoFAi = 1532319656; IQdzBPXUoFAi > 0; IQdzBPXUoFAi--) {
        pQiNirYJsgZfeFv = ! DzWOWzGQUHwvU;
        HVpvQPSXqcuiK += XvLVFD;
        iuqdiPE /= iuqdiPE;
        ldnRcWi *= VdELtHjJgpdETMBU;
    }

    return ZqCHVyDkX;
}

bool RvdztKOhxv::sRGQtnvld()
{
    int OfZFGvNZPkB = 1015531614;
    string ShxFhTejJRzpM = string("SZTZRYdLyBOzjhqvxtElXOKvCpEkWfnjkKUysLkRoVousuRFOyWhTbixYynoJDPkowKHmkPuYhyFzEvkjbOpMUQQzNEOkOlnnEElvPfjplEqEW");
    string bphuYWseVIwiicQY = string("SkRztiQvpZrvCafSdJmGdqEdwoQoJDwWngIaQqiIdEJZqJoxoyFrMuGZFEzcmwuDmXjKuIXycToNXJcziEgdgzGyYJjIHarySqNrRXoAHayPbncmnFmjjzXwGIJDs");
    int JStrNqxA = -585087950;
    bool eOvWebKYGuO = true;
    int ZQAcKgwxxE = 1590782116;
    double ahHTyw = -488220.25430687517;

    for (int upfDdxMYuKEGtPDz = 756472812; upfDdxMYuKEGtPDz > 0; upfDdxMYuKEGtPDz--) {
        OfZFGvNZPkB -= JStrNqxA;
    }

    for (int jKGqFW = 416797052; jKGqFW > 0; jKGqFW--) {
        continue;
    }

    return eOvWebKYGuO;
}

bool RvdztKOhxv::JBJcaTEaZKQlA(double YcKvUl, int vdqCdAlwhco)
{
    bool wngyMsxfkVW = true;
    bool qPUzLNwqbvBdFx = true;
    double XDlYQlVlivKjzbs = 24521.634377349743;
    int lFaUpYXAKCXDZgDi = 831096305;
    bool GsgsegF = true;
    bool OmKMYJFC = false;
    bool hqAzfdP = true;
    string MVqtKviLXj = string("PHDcrOkLBnnQxsMMZWVgEoSSErXyghsrLvtfXKDhOPbSMUcWeChIXsJIXipjEzoKusynqRKQpUBfEtCDxxZcanPGKRGeNRYWGrjTUZxBFHzFTLRdqzjZdLDnMuHGxGjkLrznQzSgutsaZIzWKnXA");

    for (int wGRcAUAuRZY = 617966222; wGRcAUAuRZY > 0; wGRcAUAuRZY--) {
        vdqCdAlwhco += vdqCdAlwhco;
        vdqCdAlwhco *= vdqCdAlwhco;
    }

    for (int bieXE = 599576329; bieXE > 0; bieXE--) {
        continue;
    }

    if (XDlYQlVlivKjzbs != 24521.634377349743) {
        for (int kIHRreitXNInX = 1318665070; kIHRreitXNInX > 0; kIHRreitXNInX--) {
            lFaUpYXAKCXDZgDi /= vdqCdAlwhco;
            vdqCdAlwhco *= lFaUpYXAKCXDZgDi;
            MVqtKviLXj = MVqtKviLXj;
        }
    }

    for (int lwVuri = 1285959542; lwVuri > 0; lwVuri--) {
        XDlYQlVlivKjzbs = YcKvUl;
    }

    return hqAzfdP;
}

string RvdztKOhxv::OqlrijsRFRPUs(int YEmNXzFCBOkVQh)
{
    double YIlHquIvHieAIkK = 541721.7368384561;
    double SIQeRbR = 799904.2018204449;

    if (YEmNXzFCBOkVQh != -350196950) {
        for (int jYutXQcKnAb = 877842808; jYutXQcKnAb > 0; jYutXQcKnAb--) {
            YEmNXzFCBOkVQh /= YEmNXzFCBOkVQh;
            SIQeRbR -= SIQeRbR;
            YEmNXzFCBOkVQh += YEmNXzFCBOkVQh;
            YIlHquIvHieAIkK /= SIQeRbR;
        }
    }

    return string("HLuCGCjNnZfeOPlWlkaSDCMCGoTVfRWhtkbBgRHWfSyIrdsCqJPQFghADrsJiSwcCrTPMlEDPKGwKvQbwxAqrbQnDPXRBekaoJeJrJbbTqVNOMaOwOnvTjYjMuMmVDfeKakLBGnnWDVTmWkWzVidcVXdoktGkfulvFEzGGNKmJQhdDyHRPwLPscefciLFWZDJkpMqwmlcsFGZfaEaQfprXbkjdLB");
}

int RvdztKOhxv::cBkutIl(bool HGQQjpJro)
{
    double ugqJnEbVeF = 107506.69301264141;
    int ngETeHRyUssKT = 1157096321;
    double AmWJOHgTRpQmZAyZ = -529392.054260196;
    bool vwgPheV = true;
    bool DsJrn = true;
    double QTVRsPIajdajVpEt = -45462.69053993008;
    double XZhpIBzOixB = 533011.1149193473;
    double unjkFCqL = 473764.10717544856;
    bool vYkxQfQR = true;

    for (int wjgqm = 549552689; wjgqm > 0; wjgqm--) {
        QTVRsPIajdajVpEt += unjkFCqL;
        ugqJnEbVeF = unjkFCqL;
    }

    for (int LzMryCbez = 1336947845; LzMryCbez > 0; LzMryCbez--) {
        continue;
    }

    for (int tsovLzzXsqUb = 53444293; tsovLzzXsqUb > 0; tsovLzzXsqUb--) {
        HGQQjpJro = ! HGQQjpJro;
        QTVRsPIajdajVpEt -= ugqJnEbVeF;
        unjkFCqL += AmWJOHgTRpQmZAyZ;
    }

    if (XZhpIBzOixB >= 533011.1149193473) {
        for (int wyqorEoklYDDjX = 50809626; wyqorEoklYDDjX > 0; wyqorEoklYDDjX--) {
            XZhpIBzOixB -= AmWJOHgTRpQmZAyZ;
            DsJrn = ! DsJrn;
            ugqJnEbVeF -= XZhpIBzOixB;
            vYkxQfQR = vwgPheV;
            DsJrn = vwgPheV;
        }
    }

    return ngETeHRyUssKT;
}

bool RvdztKOhxv::auZvrjbnuLhAV()
{
    double gDJSPoJlJRoucdwW = 790143.5328359237;
    string qtgmlyJnMBOTyVRp = string("InCyJVRGKeavrAxLtwHOGCmKmTUlUrQUKZpAGuNSFZVmLkFfjsZJgTRKUImNKGHTQYyQlaIOSZdSFZYOkDWJdclZP");
    double JPvjVMouDJ = -936386.2318074574;
    double YEkleEjwCTMS = 174204.50180183965;
    bool cXuMvuTfrQgO = false;
    int iHgaQXgq = -865304122;

    if (gDJSPoJlJRoucdwW >= 790143.5328359237) {
        for (int NVkBcc = 413912950; NVkBcc > 0; NVkBcc--) {
            YEkleEjwCTMS /= YEkleEjwCTMS;
            qtgmlyJnMBOTyVRp += qtgmlyJnMBOTyVRp;
        }
    }

    return cXuMvuTfrQgO;
}

double RvdztKOhxv::pihblUPJiwQOSRy(double lEeSiBbiBXoMosP)
{
    string tIQojABx = string("rgVgKOXWOTiMXSYhXSfcWHVyOUDQyafNlKRLVxLmfPFHe");
    bool YFdxLzAbicjHHGv = true;
    bool HjcUrTCtOXHxKM = false;
    double UgTJSp = 302142.5559482719;
    string IwudKYWaTBZrXgjV = string("jFZdAoAIRZeIYQfasThxrBBlWIKfHpNVmcCZXFIyNprUftwIxyGnyXaKAtkIEvsTfRDCEgMvYoMMhSVfgkkAtCOSUrjCdKsHQwejjdAeoEYujjvMrEfw");
    double XrYQKfgu = -357568.2349477819;
    bool rCHgXmXsDZYQ = true;

    for (int AzJYqbgBoDcJs = 1899362318; AzJYqbgBoDcJs > 0; AzJYqbgBoDcJs--) {
        HjcUrTCtOXHxKM = ! YFdxLzAbicjHHGv;
        IwudKYWaTBZrXgjV += IwudKYWaTBZrXgjV;
        YFdxLzAbicjHHGv = ! HjcUrTCtOXHxKM;
    }

    for (int tmFLwxCTtmicGs = 1933940041; tmFLwxCTtmicGs > 0; tmFLwxCTtmicGs--) {
        HjcUrTCtOXHxKM = ! rCHgXmXsDZYQ;
        HjcUrTCtOXHxKM = YFdxLzAbicjHHGv;
        YFdxLzAbicjHHGv = ! rCHgXmXsDZYQ;
        IwudKYWaTBZrXgjV += tIQojABx;
    }

    for (int RWYkqqyZZILPfFj = 2144286472; RWYkqqyZZILPfFj > 0; RWYkqqyZZILPfFj--) {
        lEeSiBbiBXoMosP = XrYQKfgu;
        IwudKYWaTBZrXgjV += tIQojABx;
        UgTJSp = UgTJSp;
        tIQojABx += tIQojABx;
        IwudKYWaTBZrXgjV += tIQojABx;
    }

    return XrYQKfgu;
}

void RvdztKOhxv::jyHjpiXDOF(string ftbxsJ, string YetqEQxbLtc)
{
    int spReJeLdnJewYjw = 1561073830;
    string kKEptEyazuds = string("krZhPsbEUlTHPuNHfUo");
    double zzQIeMzTVq = -492546.55077667837;
    bool QURTcKykO = true;
    bool IGHKTBzwDwOtus = true;
    int USQwyTjSVE = 1821613205;
    int BGCjWzEFn = -300070555;
    string JUoaL = string("eWDgCUHhnSPVcUsOQcQfUOEGiNfdclSXTrPwyoPhMifzvVjWTnwMMNzTQfWTjVxKicTKIUNqHoIjytXwSWEwrgdvOosrmeGdJdQYKCfXENRUWyeJUsTvfIvYXkXosXIjvQvJmBqZuSkQhaXBXpUdzrkzqBXWisqjXvaPRqhadZRyjJLaFHNjxqdscXPBDGrtkEWuJSGYNFcZNXiXlviGbxYzCANKCXJZc");
    bool mMXZfMbxQAmfBL = true;
    int LjpZG = -2014682700;

    for (int OiWPOjNmeuyM = 2119855448; OiWPOjNmeuyM > 0; OiWPOjNmeuyM--) {
        USQwyTjSVE = BGCjWzEFn;
    }

    for (int cvTbROyMmdr = 104409825; cvTbROyMmdr > 0; cvTbROyMmdr--) {
        LjpZG *= USQwyTjSVE;
    }
}

RvdztKOhxv::RvdztKOhxv()
{
    this->rHbXPUvpHIx(string("USjxPpMEeFYvETURgfdgsqYOzxmALA"), true, string("zxbeezCVYKwWxmbCBLhxSkgOLKzaRQOYwvXhySqJVTXJxTnJovST"), 1637963899);
    this->sRGQtnvld();
    this->JBJcaTEaZKQlA(-483083.7786767112, 2092841580);
    this->OqlrijsRFRPUs(-350196950);
    this->cBkutIl(true);
    this->auZvrjbnuLhAV();
    this->pihblUPJiwQOSRy(881024.1047539412);
    this->jyHjpiXDOF(string("xbwNtPltfsqXnveDAMxHgZbYqhKmWkEGymgdvsxZGOqKpVUFTvyTFmtXJHqIletQBdRVwMjiKUmgHVYEjwrRBxXcumEfsLalUCeLTxAHGQQmyHRuclpIMzkQFJrUfDvhFpeWpQfQVZsAmKrMCZioAcKJzczeIvhbbZAxWfxiHwCFvWHOKUZEcConBxvNfAWKsJtQgLZUIgtkBggQgNvhSmypasHjsYbGLZPrbgqvGfmiObQAStSra"), string("labzbBcvShTsUeuVkNwDlPyQmfcRnvhSSiKfneqOpghOpPHaFsKhXBCpzKEurryTDxFAFEVrknzXlDBMgHlauklwdoxhVRFriRzqalsWJdVfLugXkognLCWBGbdEWsdbMRhoNnSFpztQPTvPIWLMnZxMFPAlSBuCECHruYdwDKSLcLxvJsfRrYCCvAzQVtDvaCeWgzJBwrRyTQUVvhVymleABKGeOVdTnEQVmTe"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TsgHCjRTNq
{
public:
    int kzArrrEqxXunyA;
    bool IdrNfvVXlBDye;
    bool HhhxqqAefhCu;
    bool eqYUDi;
    string TkhAkB;
    int IWejd;

    TsgHCjRTNq();
    double jVBPa(int VqehzbazLVUdMS, double IZJKuyyF, bool fblISkuKTRdmAZ, double HLYJKh, int TZoXLLPNq);
    double wBVatDy(int XATCecF, string ggcMWheSN, string Winva, string sljXDfjCi, double yhmGhawLx);
    string BAeJNALCBsjtWwKm(double gIGIybs, string iTDhUzWkjW, bool qyMVWtOhFiQ);
    bool BDlHIHVABr(double lLklaQe, int jQqBYoTVTz, bool PEJdyZeA, string MmOZTig, bool amCNjJsUm);
    double txRuTdEH(double ubxiLb, bool sjCspsmIiimzxvXC, string gAJoaot);
    void RXiRjvpH();
protected:
    bool mgdhJkTASfrfFBEo;

    bool TgllEdEp(int gbWifKL, string LomBQKwttWmTZrof, double paNAMyLQfQRkju);
    int DVJUKLiLrCw(bool gGunUTKNcS, double vJtcpJB);
    void GKPdOLWEdKpZE(string GTqlskuXWHpQU);
    int BTZzlOOAtarXixvH(bool dFbDYXlCSts);
    double HhtzRuCDVgRt(string adDTFfAECTMj, bool IDBGqPlmCMYpH, bool XXTmmoKimvYfv, string AmMzhPlIGLDzWIP, double jezlzQa);
private:
    double lTIolgwkOFcYsb;
    double aTZasdN;
    int KBNWOuqewHAqY;
    int pYmpVxIpRmMuWJ;
    double fqaJaud;

    string caRLzlXstxqO(bool rvSPwbjSozfT, string wdlYh);
    string AuvoOkSUM(double YcDYxHF);
    double ittGGBeGbJQHpuW(bool JfWjLutFwUNZ, string CzajlutQiWpQIvUm, string izJjJ);
    string UXlFkDrAyLduHFpy(int taknajH, int eXqscYGIg, double FcmOg, string wRvmmpvaVRRLQwz);
    bool sjuIARW(string SJBwYpeZ, bool bLdLdrPckdIaSx, string EQUpkVOW);
    bool vLMZSnTyaFubUORD(double prGlfjdRHF);
    int tDHWJXwmoWaXQKK(double syYTeYBPhOelwdOR, string hgwcEsJx, string GwybH, int tNsHFTAqehZeBtnh);
    double fLkgqD(int kblimU, double yTmfBguSxMMqqy, string ZEtTxBSSB);
};

double TsgHCjRTNq::jVBPa(int VqehzbazLVUdMS, double IZJKuyyF, bool fblISkuKTRdmAZ, double HLYJKh, int TZoXLLPNq)
{
    string kIaBAEObAsLMjyO = string("voAcTVZhXmIaRPdqumpNUoYprthVzhQsFG");
    double iesrqxlHHVOGVvs = 416121.9416304179;
    string piPkhE = string("huaPqdkoFxDwINvFdcReDoHlzzQBZCeZEwFRZfNqzrhzQnsIxuZIoTEgmbIxouAEdoiXhrjylXaZUveCcvYIbFMGVCMKscOhfZwTlislXVdvIYGhgooeIXnnsNGagDFqqrOykToCRjFGYxEHFoapvHDjlQLQNmEOlKpDhWrcQK");
    int rQGkcBfnR = -1945149418;
    bool smMVHAJyABgrnm = false;
    bool bymmOJrFfRhkbUGK = false;
    double LAoIhJFHhio = -438550.4454364905;
    string awIwyS = string("KcRtbpFbrVtoEZGVNMQmxwOTOwqtKSjOlkVRlNnusBmzNWPgBmvunZlXmLGArKnpfSllvexwfWOsSYCLRUXoMtSmNOmAInFdesNJGlvmVkduYFLfZwaxyPrxIPMQVtcsjfxJlJoRgMgBekIkNaudOcHQXaWMKxrqmDZFFWRWCPWBnqBObglWxbGheTCVVTdRodmDtZKUKzlBfPwiFKPNoaNwYGQoyJZxysMIQnOQLcjNPFXtpGfUI");

    if (bymmOJrFfRhkbUGK == true) {
        for (int CCeBLbZiTELZ = 85548415; CCeBLbZiTELZ > 0; CCeBLbZiTELZ--) {
            rQGkcBfnR *= VqehzbazLVUdMS;
            awIwyS = kIaBAEObAsLMjyO;
        }
    }

    for (int zTVFS = 1968393316; zTVFS > 0; zTVFS--) {
        kIaBAEObAsLMjyO = piPkhE;
        awIwyS += awIwyS;
    }

    for (int SLqVTKKHneExpX = 574851715; SLqVTKKHneExpX > 0; SLqVTKKHneExpX--) {
        continue;
    }

    for (int LSTNMyAYdUjMY = 1542741853; LSTNMyAYdUjMY > 0; LSTNMyAYdUjMY--) {
        continue;
    }

    return LAoIhJFHhio;
}

double TsgHCjRTNq::wBVatDy(int XATCecF, string ggcMWheSN, string Winva, string sljXDfjCi, double yhmGhawLx)
{
    int znPPXD = 682362656;
    double ddiCbygp = -227671.366079803;
    int zIMqOXoUuY = -2042423803;
    bool thXkIKk = false;
    bool zhusXIl = true;
    bool dtQkbVjjElXDQouw = false;

    return ddiCbygp;
}

string TsgHCjRTNq::BAeJNALCBsjtWwKm(double gIGIybs, string iTDhUzWkjW, bool qyMVWtOhFiQ)
{
    double GenzcEobZUn = -1047500.0134327395;
    bool yuZolVCc = false;
    double EYWyDhCQ = -374742.8758141344;
    bool YSYrgiUlZc = false;
    double XNFtwCBxL = 455733.9562617347;
    int fPhFRJ = 1830310505;
    bool wRSOGpBDsZh = false;

    if (GenzcEobZUn >= -400164.2110355053) {
        for (int sjpYqIdVGLwkFlU = 1133231372; sjpYqIdVGLwkFlU > 0; sjpYqIdVGLwkFlU--) {
            gIGIybs += EYWyDhCQ;
            YSYrgiUlZc = wRSOGpBDsZh;
            iTDhUzWkjW = iTDhUzWkjW;
            yuZolVCc = ! yuZolVCc;
        }
    }

    for (int urKKNxDUFC = 365002674; urKKNxDUFC > 0; urKKNxDUFC--) {
        XNFtwCBxL -= XNFtwCBxL;
        gIGIybs = EYWyDhCQ;
        EYWyDhCQ += EYWyDhCQ;
    }

    for (int rlzuZHM = 843759997; rlzuZHM > 0; rlzuZHM--) {
        EYWyDhCQ -= XNFtwCBxL;
    }

    return iTDhUzWkjW;
}

bool TsgHCjRTNq::BDlHIHVABr(double lLklaQe, int jQqBYoTVTz, bool PEJdyZeA, string MmOZTig, bool amCNjJsUm)
{
    bool MPFlwI = true;
    int DmILOa = -1674381695;
    string AtTbsz = string("mwPZnoAWqLfUMTIGuNEIrWUFDJKgLuNWuWoZUXHYlWBAcsmkUOIQdelnJHnOgsukBIxFHEUkddeypogtBgBXkPVjEtiVsSnWpcYjsCutcfJLUMtefjNInEpdOaRSubWovvpNEOfMRprQCJwJonDxQlgzcDvQGPNxvFtMaASfuFdzQNbYGUGWPRFTgWLGvwNXukUTcPvFW");

    if (PEJdyZeA != true) {
        for (int fgIdE = 1598193638; fgIdE > 0; fgIdE--) {
            AtTbsz += AtTbsz;
            MPFlwI = amCNjJsUm;
        }
    }

    for (int cmAChvJspDzVpJag = 1051301259; cmAChvJspDzVpJag > 0; cmAChvJspDzVpJag--) {
        jQqBYoTVTz -= jQqBYoTVTz;
        AtTbsz = MmOZTig;
    }

    for (int KVsIDllhaic = 1055780964; KVsIDllhaic > 0; KVsIDllhaic--) {
        MPFlwI = ! PEJdyZeA;
        AtTbsz = AtTbsz;
    }

    if (lLklaQe != -192660.52509190666) {
        for (int oUjEo = 1314931643; oUjEo > 0; oUjEo--) {
            continue;
        }
    }

    return MPFlwI;
}

double TsgHCjRTNq::txRuTdEH(double ubxiLb, bool sjCspsmIiimzxvXC, string gAJoaot)
{
    int MgOAITyOEZXN = 325817155;
    int LfrVU = 1376325832;
    int FOmhrlxQv = 380835599;
    int yDPUAfIpPRlRCP = -710336252;
    bool jWvqVgibTuTaJrif = false;
    string khnLQnspIMWUTYw = string("eWxQIYEMQNLZfHFQexTfiCApQiardJANNKtYWjoCLchikNVAAGAzKHKZBvwnWxbqiCHkTgqwOYZrxsFEUezovznggFDhGiRTzzqHLtBcfswuafHunREYObtFgWYCjvrasmPbDXuwkSnSgpOCKwAgVuquAhlmJZwmdsWFLLtBfeDPthAjFOQCUoTwIJCMUAeUqOTKxaCHkhQlUjnXWRNfRFPoyzxHkZnKtgjKCfunSCTpWYluiQaoptkkH");
    int FKfWcgfBxxUVpRRp = -2133618863;
    bool wqlmHkQs = true;

    for (int WgdnSBRNtSNBLWI = 1914065837; WgdnSBRNtSNBLWI > 0; WgdnSBRNtSNBLWI--) {
        sjCspsmIiimzxvXC = ! jWvqVgibTuTaJrif;
        gAJoaot = gAJoaot;
    }

    for (int NqFAxAkGPp = 929519825; NqFAxAkGPp > 0; NqFAxAkGPp--) {
        FOmhrlxQv -= FKfWcgfBxxUVpRRp;
        jWvqVgibTuTaJrif = jWvqVgibTuTaJrif;
    }

    for (int rAUGiXhojF = 168332875; rAUGiXhojF > 0; rAUGiXhojF--) {
        MgOAITyOEZXN -= FOmhrlxQv;
        MgOAITyOEZXN /= FOmhrlxQv;
        FKfWcgfBxxUVpRRp += LfrVU;
        khnLQnspIMWUTYw += gAJoaot;
    }

    if (FKfWcgfBxxUVpRRp > 325817155) {
        for (int tBjmWrfDKljJ = 991969033; tBjmWrfDKljJ > 0; tBjmWrfDKljJ--) {
            yDPUAfIpPRlRCP = FKfWcgfBxxUVpRRp;
        }
    }

    return ubxiLb;
}

void TsgHCjRTNq::RXiRjvpH()
{
    string ikxoxcHYuQSdM = string("oToVqdknsgqPcghubvfeKoqIeWIsAXlJOybBEIGkBRCWWtcHUhIkcoIkDOkTOHCjNhZRfniawCgONBKhohVSmTSPWIBAPSeoGJEAogebhMLPOrHWlUHETQgCNj");
    int cBDYfbrvyD = -377052730;
    string wmkhNOs = string("ecEiZAFakReXdcoSUrDvIjBuuMpQRSurXgYSJIcWeevVcONwIBleifiBfKtiEYEMfMRLBqMtrILOMJhBIFMD");
    bool RWCxgjONWOVeTg = true;
    string YuiBX = string("kjqJLQECewDIkMnhKgLNjBnJNRQIiTGdSgSJfArFGpgESUqmjsrDDYMCwggTxpVULDgxzyFuLviUIwxjTqEsFlkAtGkACmpqgVHWQATIcrBlofgRoArAEKaEoJwSXDmVkyZOtmEivKJYyISxZcFvoHseQSZfxxiQqhRzEhLOVQBlsAFNHJNidrofjwAfshFeHXIzmkEMlxSjwDyGvJSJKgKnymhxcrunVVvby");
    double IyPWAzwJAN = -703217.568609901;
    string yxUKyzchVhi = string("UpJCmMrhsAZajBOVYaxlUaubskRQmZvxzooHEIBvezAswxlfhgayulwwnFOxbmJPAOdhKvUtpTlthcNxUewlQOzPIQGyfvsYBpKVGcFNifxgUBlKxswGNDyDjgxAfLAmlLyXSQVN");
}

bool TsgHCjRTNq::TgllEdEp(int gbWifKL, string LomBQKwttWmTZrof, double paNAMyLQfQRkju)
{
    string SKNAfZw = string("wzyqunJNktFTXDZMnjGpMPJbKDPCTdpAPxMPwbEfBnctPHCuoGAVXdaDitzpNAuDrncZrTJVEcWuicLDsXbQyUWLtFlIrRAVNNNPOvtFwYiSbTbzeLgUZwAQaNuIFYBvyYDhlfCYkkHokCWHkmIXADMPpiVCXGtMWWNs");
    double JamhcK = -228333.2780302409;
    double RcuYN = 861872.5556807575;
    int sjcVkHr = -2047958131;
    double KzcqvVlVOInJcW = 269383.2950493208;
    string jeCzjmyBLhxVUWO = string("uysMaYfMgMmwhyCFGGOCqNMFJTDIiEpFINhbpslttDICbQmewZtHwCXahYuiYBcXuhDKurjGLPNcHjQNf");
    bool VeHqrGAC = false;
    bool WjjcnIwOGJrkdD = false;

    for (int bhwynccKT = 459598287; bhwynccKT > 0; bhwynccKT--) {
        RcuYN /= JamhcK;
        RcuYN += RcuYN;
    }

    for (int EmpuG = 532139059; EmpuG > 0; EmpuG--) {
        continue;
    }

    return WjjcnIwOGJrkdD;
}

int TsgHCjRTNq::DVJUKLiLrCw(bool gGunUTKNcS, double vJtcpJB)
{
    string cfFXRs = string("eTrPmecj");
    int eRjqgQLzfmditWU = -296958582;
    string xxtDD = string("BgEckKECKnqWchdoUrBTNRcTFlpZAEVxOghMWlFvienHOziIBjdhFJyZMdHRpeGpfGYJlYgImqhrryqIKDqswRmMHFzXWpXSPdqmVF");
    string rcSRzhFzUVrrmR = string("UyrsNELpHiEQusQyhubmQCufShAxrbpYvrWLVIYUGleZuPOEp");
    double PGgCL = 980519.0624936591;

    for (int gjWoDqAcy = 1975220996; gjWoDqAcy > 0; gjWoDqAcy--) {
        continue;
    }

    for (int GCVYTbkV = 1347549936; GCVYTbkV > 0; GCVYTbkV--) {
        rcSRzhFzUVrrmR += cfFXRs;
        gGunUTKNcS = gGunUTKNcS;
    }

    for (int klMHi = 352728856; klMHi > 0; klMHi--) {
        cfFXRs = rcSRzhFzUVrrmR;
    }

    for (int iDFHogZPlvKFker = 265412345; iDFHogZPlvKFker > 0; iDFHogZPlvKFker--) {
        PGgCL /= PGgCL;
        gGunUTKNcS = gGunUTKNcS;
    }

    return eRjqgQLzfmditWU;
}

void TsgHCjRTNq::GKPdOLWEdKpZE(string GTqlskuXWHpQU)
{
    bool aizQx = false;
    int QDxUXGPueWsNiTQm = -2030980058;
    double ZSuEhj = -228472.3476251204;
    string qQqHoHiWfOTeJ = string("GCfUwRKoBZCpRMtCesTJVJMzVLFvXHjtBmYGjBsxeQzAQkeAgbhkfbrtQdLkJHnExypFCGicmgjKRdFbQLJsAVBEolnyAlkQgOMQCHxJHEDlWdgpTSIGtwvVygVeauqczVPQhMxnvvpAHHDDQBKhCqelRYRrUGUmooJCGWNGqhXRbOKWxrvBfjzalbeWAoJzAcAHFHJQoVJeXqmYY");
    int iRGCuDeTgMbfP = -1079206058;
    int rVKhMvrpWlWIlWa = 1871191624;
    bool GEsCgDorRRaPhM = false;

    for (int DsjeFJEnvuX = 1950069052; DsjeFJEnvuX > 0; DsjeFJEnvuX--) {
        QDxUXGPueWsNiTQm *= iRGCuDeTgMbfP;
        iRGCuDeTgMbfP += QDxUXGPueWsNiTQm;
        iRGCuDeTgMbfP -= iRGCuDeTgMbfP;
        aizQx = aizQx;
    }
}

int TsgHCjRTNq::BTZzlOOAtarXixvH(bool dFbDYXlCSts)
{
    bool lBkYG = false;
    bool OCyAiZjE = false;
    string lUvlKFwz = string("DqIALZCxhGZgerxMfmpaLJknQwwNBaykDjCCWWpEWArloJnbXIhTUGIJjXecDJbkGiJNfCwwTXEmoSRGTuwZcAwBcdutWFfIxDjMCLoDhNXsUYlEMjAMwuDObtPNpuOquasgAovemzmNZGCcMhjRBEqvMknjeZpxbdqNwhjLPoytacBdYGPgdTOyWHXkLVAfhGtgGswCAaMczPgzsbRzRMscUfnhHPefoHtBmvNKOVPNuIfSVyXwiaHiGfKYGCg");
    bool lnHMC = true;
    double hGGiMfD = 932797.594574086;

    if (lBkYG != true) {
        for (int ZXslWbvZ = 1524192450; ZXslWbvZ > 0; ZXslWbvZ--) {
            lnHMC = ! lBkYG;
            dFbDYXlCSts = ! dFbDYXlCSts;
            OCyAiZjE = lnHMC;
            dFbDYXlCSts = OCyAiZjE;
            lnHMC = ! lBkYG;
            dFbDYXlCSts = lnHMC;
            hGGiMfD /= hGGiMfD;
        }
    }

    if (lnHMC == true) {
        for (int pcNrXXIy = 239167567; pcNrXXIy > 0; pcNrXXIy--) {
            OCyAiZjE = lBkYG;
            lUvlKFwz = lUvlKFwz;
            dFbDYXlCSts = OCyAiZjE;
            hGGiMfD += hGGiMfD;
            OCyAiZjE = dFbDYXlCSts;
            lnHMC = ! OCyAiZjE;
        }
    }

    if (lBkYG != true) {
        for (int TibKS = 688756783; TibKS > 0; TibKS--) {
            lnHMC = lBkYG;
            OCyAiZjE = ! OCyAiZjE;
            dFbDYXlCSts = ! lBkYG;
        }
    }

    for (int PwoulskUeadpY = 990079592; PwoulskUeadpY > 0; PwoulskUeadpY--) {
        lnHMC = lBkYG;
        hGGiMfD -= hGGiMfD;
        lBkYG = dFbDYXlCSts;
        OCyAiZjE = ! dFbDYXlCSts;
        dFbDYXlCSts = lBkYG;
    }

    if (lnHMC != true) {
        for (int FbuXHM = 1209898076; FbuXHM > 0; FbuXHM--) {
            dFbDYXlCSts = ! dFbDYXlCSts;
        }
    }

    for (int xgODaBSPX = 775393605; xgODaBSPX > 0; xgODaBSPX--) {
        lBkYG = OCyAiZjE;
        dFbDYXlCSts = dFbDYXlCSts;
        lBkYG = OCyAiZjE;
        lBkYG = lBkYG;
    }

    if (lnHMC != true) {
        for (int lIQQtTicTBVecBS = 752021673; lIQQtTicTBVecBS > 0; lIQQtTicTBVecBS--) {
            lBkYG = ! OCyAiZjE;
            lUvlKFwz += lUvlKFwz;
        }
    }

    for (int VxYFkNspZQdSiRR = 1671653935; VxYFkNspZQdSiRR > 0; VxYFkNspZQdSiRR--) {
        continue;
    }

    return -191654485;
}

double TsgHCjRTNq::HhtzRuCDVgRt(string adDTFfAECTMj, bool IDBGqPlmCMYpH, bool XXTmmoKimvYfv, string AmMzhPlIGLDzWIP, double jezlzQa)
{
    string ZicinMfqiHwwqvDz = string("yWYuYzVFfuuqxMKYkpTCwbRaZrmRUCgXlqgDNueYtmiOMJAZuhwhNLEBBVDuMuXxSvZSkhkrxbcbWRqUmNziHAmgizETSDyvfPAteIMBWaqQgORrubHwODCOIfDkrRwhzwXYdoLABrwMHGQMKQBtpaeJFBfPsGUJBMskdcLhEikAdMjLyLUCuuNvGKsccbVvVUGGIIrTSOGjuuv");
    bool lgheS = true;
    bool wkFdFjzFOb = false;
    int KawYcpda = 1338938568;
    string qmHtwwnWM = string("QhXvmtjpoWqNkdvpSuLicWaOLFvtzlGnTuvJZTyJoOhLvLYvWye");

    for (int oBzbj = 1943380134; oBzbj > 0; oBzbj--) {
        qmHtwwnWM = AmMzhPlIGLDzWIP;
    }

    return jezlzQa;
}

string TsgHCjRTNq::caRLzlXstxqO(bool rvSPwbjSozfT, string wdlYh)
{
    int CysSamaWvXbq = 1851253896;
    string LOplNLXxWBYcWWBh = string("tUmTQwcnGrypRaPUieGhdKhJGzBmDjYESsVCGpAXBfjxtjppRzPJYTWIoFYCIbAmGnUxdMxBUoFiBaMDuWBTTucfWvoSwZoZyIhSaNjYQYMVnonwlCMLpSzYiVuwcXzAFvcdboUhIkCjJzRkOAKMmfRIYGqBgdyGYYpVcQXQqMXskSylYWqTvDVNFBffODWX");
    double HOIRFJ = 397165.01450224273;
    string EelyIEAFdJytl = string("nODlbAaVgcCgATdbAVfLPKyNhJPUxaaeyehJhUCsUyfcAAhjxFoIJYJtTuKXlvdQfMnqUZJyFFLJyLvAonTJSyptSiVJKBegbtUNBjggZMdiiZwhgPGbSejefijaazLGYoXRaOEmLpyUotzlHXopLNHgZkFctMcNOImygkBqhcYiMstSP");
    bool LdogXsbKMMItyI = true;
    double bXLZplvuRas = 655715.0743776046;
    bool QUknPu = true;
    double eDxOFoOiOnOSk = 624972.2751077535;

    for (int hOgopR = 847122765; hOgopR > 0; hOgopR--) {
        bXLZplvuRas = eDxOFoOiOnOSk;
    }

    if (HOIRFJ == 624972.2751077535) {
        for (int vhMLUwjaahcr = 1625825757; vhMLUwjaahcr > 0; vhMLUwjaahcr--) {
            rvSPwbjSozfT = LdogXsbKMMItyI;
            EelyIEAFdJytl += wdlYh;
            EelyIEAFdJytl += wdlYh;
        }
    }

    return EelyIEAFdJytl;
}

string TsgHCjRTNq::AuvoOkSUM(double YcDYxHF)
{
    string lTijAeAGqFbgu = string("aiCytBbLQLAYgNQHgEYCDDpRHRlUvEZGbaweOqqmwjqyFUautUZWW");
    bool anXXjuBNm = true;
    double jryzzbaYTW = 927215.0452043993;
    bool FtCuKGj = true;

    for (int LfyDROMaOEjtZnel = 628643040; LfyDROMaOEjtZnel > 0; LfyDROMaOEjtZnel--) {
        YcDYxHF = jryzzbaYTW;
        YcDYxHF -= jryzzbaYTW;
        FtCuKGj = FtCuKGj;
        jryzzbaYTW -= YcDYxHF;
        anXXjuBNm = ! anXXjuBNm;
    }

    return lTijAeAGqFbgu;
}

double TsgHCjRTNq::ittGGBeGbJQHpuW(bool JfWjLutFwUNZ, string CzajlutQiWpQIvUm, string izJjJ)
{
    int gtJvqM = 312399609;

    if (izJjJ == string("bLyrSfLndVQEXCDRQyfTkiERdialgwNqHFCVaOKTqQUMtJJVsfyMcoWgUKvWOKmbEQirSIxzvLWSBGEXmktmjGNXaplQSXRKbRNjhOebtrrQGdkCCZKopTgaFmyjTcRMs")) {
        for (int MYWWApwREVh = 702596554; MYWWApwREVh > 0; MYWWApwREVh--) {
            izJjJ += izJjJ;
        }
    }

    if (gtJvqM > 312399609) {
        for (int kptNzn = 944580708; kptNzn > 0; kptNzn--) {
            CzajlutQiWpQIvUm = izJjJ;
            CzajlutQiWpQIvUm += izJjJ;
            izJjJ += CzajlutQiWpQIvUm;
            CzajlutQiWpQIvUm += CzajlutQiWpQIvUm;
        }
    }

    for (int ZcByZxiwLjQ = 682031084; ZcByZxiwLjQ > 0; ZcByZxiwLjQ--) {
        continue;
    }

    return -921653.3660080008;
}

string TsgHCjRTNq::UXlFkDrAyLduHFpy(int taknajH, int eXqscYGIg, double FcmOg, string wRvmmpvaVRRLQwz)
{
    int RdcyUQA = -1977074334;
    bool RuAXVRuAUsU = true;
    double cPBadHJ = 536017.0679899461;
    string BhIkTJtBVNeW = string("XTusoTSejaJVVdKNuYReLCiUXFvOxSSaJgEjLhBpVvKdJQYpKOSGMQiWKpLNimiGEGdUgDlgEQGWjUoXNzWPmzorWFBoqfIsdskziSqqTPXXRKsDckbIFiQIdyCKbeDkDoVfHSRfpMaqleMyEMHpDNGDtuDkNYlzsHWmRTk");
    double IxyHjgmAjqVhq = 161333.6003310441;
    bool izziJoYvGo = false;
    int FvHkCoMUiWg = 1709715540;
    int uoSgkPpijlzzNR = -1365928912;
    string EheRuy = string("xGwNtnUoZCXZgDAVQobTGOLtBcCzcBZchOnjbYZhmaNOoqFmPDhMoCsHGDPJCbUsuRsMbpyRslEtNnDWdyNkwyAkRnbJnbbVGkioTmaoKZjyGfaettpXBGRsSlaXkGukpPidv");
    bool PlzUdHOZuE = true;

    if (taknajH < -1214917225) {
        for (int ttEYPU = 161754674; ttEYPU > 0; ttEYPU--) {
            continue;
        }
    }

    for (int pfmlqwjtDm = 1320410477; pfmlqwjtDm > 0; pfmlqwjtDm--) {
        FcmOg /= cPBadHJ;
        taknajH *= taknajH;
        eXqscYGIg /= uoSgkPpijlzzNR;
    }

    for (int RzWJH = 1640468532; RzWJH > 0; RzWJH--) {
        RuAXVRuAUsU = ! izziJoYvGo;
    }

    for (int kHXjlaGPO = 1108436715; kHXjlaGPO > 0; kHXjlaGPO--) {
        PlzUdHOZuE = izziJoYvGo;
        FcmOg += IxyHjgmAjqVhq;
        FcmOg *= IxyHjgmAjqVhq;
        RuAXVRuAUsU = RuAXVRuAUsU;
    }

    for (int hLMluvWpCE = 675996141; hLMluvWpCE > 0; hLMluvWpCE--) {
        FvHkCoMUiWg *= taknajH;
        RdcyUQA += uoSgkPpijlzzNR;
        EheRuy = BhIkTJtBVNeW;
        BhIkTJtBVNeW = EheRuy;
    }

    return EheRuy;
}

bool TsgHCjRTNq::sjuIARW(string SJBwYpeZ, bool bLdLdrPckdIaSx, string EQUpkVOW)
{
    bool icoeQLUbJKClif = false;
    double bJiWGbj = 111420.84571085713;
    int WjJyrPmNFEvXIj = 170641843;
    string heclwILVNy = string("EWXOuDVDclLEbgZvSndJpsHphYVzrlSLSViXMWYSEMNdkltdkzAtPplIoYsSJCpjDCwxKaOaUIsftMToFJZCGcv");

    if (heclwILVNy > string("xyUZGqRylqglKSKpUjadMBbGuROaItUyLgYGvdbDKqNrHHTLeBfVcJSCXzeCJFKTmcDvPNZEITHAUEyNmJcpBcLJJYGjvudiAbpCDppB")) {
        for (int FDJvh = 110459888; FDJvh > 0; FDJvh--) {
            bLdLdrPckdIaSx = bLdLdrPckdIaSx;
            icoeQLUbJKClif = icoeQLUbJKClif;
        }
    }

    for (int jdfVstpnOhKDBDm = 1582867570; jdfVstpnOhKDBDm > 0; jdfVstpnOhKDBDm--) {
        heclwILVNy += SJBwYpeZ;
    }

    return icoeQLUbJKClif;
}

bool TsgHCjRTNq::vLMZSnTyaFubUORD(double prGlfjdRHF)
{
    string eMdJP = string("UaEtVfbjGaYkXdFlZnskkTIMUnsYhnfeBzeeBbQCtcWEuTccNqhahVWPCfPoAmALeJBkmXFKPmBINpWCaOlXlJBQxCxaASDjzNsbKmpDdwWEmTluSHtsrjgPagaynXaaNoroWOqgGiOdCKdkldAAHNYFxIWDWReIjoVmBUkJLOWuBdJcHIhwhBwKoxdXBhhJHazhRMxyDaAbtmFxuMCJyTCwixIwcLqjqmmyijhaIlgM");
    string qVLJmrxRWMwdvmdW = string("oTobzjvHLfvGboYNyCmIGePIpCrqEwkiYMTHacobZAnFcSpbXMSpVmgZUoDKirWaLvSsWoctphKNImUNICvtfsitppbvEMFaBrCAuuIxVZFlyGgQYTonPCUOVAgGWMBTaegJNBQCdIFlgKkXmbAVZVxkJ");
    double qfTmjPEgmpNLB = 669144.8851193158;
    double FpUwODMY = -337488.9842142385;
    int IzgTQOuc = 2993049;
    double qMyzWLakgt = -571375.8710895318;
    bool sRCrMw = false;
    bool bxczMeZ = true;

    if (sRCrMw != true) {
        for (int zpZPj = 1650851346; zpZPj > 0; zpZPj--) {
            qfTmjPEgmpNLB = prGlfjdRHF;
            qMyzWLakgt /= prGlfjdRHF;
            eMdJP += qVLJmrxRWMwdvmdW;
            eMdJP = eMdJP;
        }
    }

    for (int RGoTbpBlDC = 1536742643; RGoTbpBlDC > 0; RGoTbpBlDC--) {
        qMyzWLakgt /= FpUwODMY;
        qMyzWLakgt -= qMyzWLakgt;
        eMdJP = eMdJP;
    }

    return bxczMeZ;
}

int TsgHCjRTNq::tDHWJXwmoWaXQKK(double syYTeYBPhOelwdOR, string hgwcEsJx, string GwybH, int tNsHFTAqehZeBtnh)
{
    int tOKtPiId = -790578947;
    int QOFEXa = -1773103715;
    double fbiLmePHyvILK = -1007037.6724663596;
    bool yhImHSRQqMkmHxwZ = true;
    int uSFESVgoWbwucbF = 2044714747;
    string lLnCXOldZXINf = string("yFxWDJUemoaeVqDLiiLAtFSTdgoRageBdRqlEOAMAThKGttuYdHIuBClbaiKMkVUwJOULwkLSpQaEPpWfhDkvhhpXJqBsPCtUDsJBoHuEGdcyyjVIQfZpmVZhdOCgpFRzBVoZCOJxMoxjhaOUOuHljZLvhWQMHxrVgCbZUMvTicxOAAvsryOQODSSVKUgSTLDeFOnaHJLABOBekAdjnIEVEZrSv");
    string XoPUfpwS = string("TLJAAJSRqsaOfmnrNWkeBUEATdHLpPHRWiVGgViqlVxtyTfmcXkOKvScVpORDbsHqUHeLGbHooQYboMwieiqKIfTNudYkxGfCOxBKZzzXkge");
    double ksADfwSjou = 687391.3994107771;
    string seJeDBOLoC = string("CDrwkvwHsWDYYvEnyPbkKGtJImZufDjjZtCUPMqUvGFPOdaBWtMUYjFJuTwLCzpcpAUSRHx");
    bool mzgQhkTVEOUxkJmQ = true;

    for (int ImoHsJbA = 2102589858; ImoHsJbA > 0; ImoHsJbA--) {
        uSFESVgoWbwucbF *= tNsHFTAqehZeBtnh;
    }

    for (int padFEhipF = 1377503799; padFEhipF > 0; padFEhipF--) {
        QOFEXa += uSFESVgoWbwucbF;
        tNsHFTAqehZeBtnh = QOFEXa;
    }

    for (int bFcDestC = 674672954; bFcDestC > 0; bFcDestC--) {
        continue;
    }

    for (int mfEuIfN = 1944493807; mfEuIfN > 0; mfEuIfN--) {
        hgwcEsJx = hgwcEsJx;
        seJeDBOLoC += hgwcEsJx;
        fbiLmePHyvILK += syYTeYBPhOelwdOR;
        tNsHFTAqehZeBtnh += tOKtPiId;
    }

    for (int drTPMGGJHB = 2090038299; drTPMGGJHB > 0; drTPMGGJHB--) {
        uSFESVgoWbwucbF /= uSFESVgoWbwucbF;
    }

    return uSFESVgoWbwucbF;
}

double TsgHCjRTNq::fLkgqD(int kblimU, double yTmfBguSxMMqqy, string ZEtTxBSSB)
{
    double dMZqenNbjjJPTz = -882001.4645018162;
    double CZFuBDSGFRHquggH = -373064.666790418;
    bool ctFGK = true;
    string dirjajU = string("JYAtShQBXsNMghfGXPVOIfaVpwwURxgkEGKCDTAbODqrllDHHUFVklTRGuXpraZwmEWDbiBSWCaobtkjgKcLrzUlPrsvZOlVaRvyZcwHkuTwveknFhqkYxvretXOCYiiqbXJ");

    for (int tlRFQGn = 725095838; tlRFQGn > 0; tlRFQGn--) {
        ZEtTxBSSB = dirjajU;
        dirjajU += ZEtTxBSSB;
        ZEtTxBSSB += ZEtTxBSSB;
        ZEtTxBSSB += ZEtTxBSSB;
        yTmfBguSxMMqqy /= dMZqenNbjjJPTz;
    }

    for (int ZKRkYBVWzSrtpwcd = 136373228; ZKRkYBVWzSrtpwcd > 0; ZKRkYBVWzSrtpwcd--) {
        yTmfBguSxMMqqy -= dMZqenNbjjJPTz;
    }

    for (int PdFiAzhYkH = 1389188290; PdFiAzhYkH > 0; PdFiAzhYkH--) {
        dMZqenNbjjJPTz -= yTmfBguSxMMqqy;
        ZEtTxBSSB = dirjajU;
    }

    return CZFuBDSGFRHquggH;
}

TsgHCjRTNq::TsgHCjRTNq()
{
    this->jVBPa(-262765584, 975840.0105360509, true, 200686.55941852974, 34991579);
    this->wBVatDy(-1502382626, string("kLcHrNCJeTQPO"), string("MFdHksFFiAMVAKbmyUBERAYizNEPvimdyWwItppdujhSQTSGkhuixMEOwkjEvbJloxHFZoAJM"), string("UjpwNfRfCUfpZEskjnuvSxHmGtvUsAAAYgOoIZietfyutqsCyNbAWXhVUcUnXFUCQImyXALDxyj"), 724889.592595514);
    this->BAeJNALCBsjtWwKm(-400164.2110355053, string("PYVQmRQvgvkVGiqWryLlspQmRKlMdzMRzZvKbcKDsREMm"), false);
    this->BDlHIHVABr(-192660.52509190666, -1281515945, false, string("bzyRoTTsBQepMWOYpiTPNSejcOGkCbVFEuTiyLuUrakcbWgreDGydMOycGGqHhDZGqhkOvxEFXTpEXWCmtksKgQhTUvkxFVvMQqCWTroaKabraRXIOBVochqnQlMpxwypBfDBzThDVRErcOFretmeAkOuUtRBLEbZ"), true);
    this->txRuTdEH(1102.1569761104072, false, string("AnOWVzkUUmxXjUMqOQDCBLbtXnPAvEPKCruRmmdzWWkhRazAMKfTsmgYfNDBuzZpiRvkofniJEPXKPFOGSlphUc"));
    this->RXiRjvpH();
    this->TgllEdEp(1497710803, string("tRorEjlNdnxMmjYeOtHfrYEeyPqhdqoUAqIBntKhRgyfzWSemhLutRDxuCDQWuQeldxLcOn"), 770235.5444527171);
    this->DVJUKLiLrCw(true, -701701.4405192771);
    this->GKPdOLWEdKpZE(string("AERyGWaCgpjsxXREGPeSxRERzfmPDqexiAjZNTSDUYizBvCIWyrEayQruMQGRgsJPRpOAYcOjHaIoWskOuVBLGJHHqEnFVJchXEJsrMoXWBpQoqdgSKDllDODmloXtNiDbHpzBLuSQPzRLELC"));
    this->BTZzlOOAtarXixvH(true);
    this->HhtzRuCDVgRt(string("OLCZVjlTxJHWsolNqqTdLpvORnPoJyrGunigRxbfZTXWWvnyjYXwpCRffKhRoChYAiyQyNfbtxbwyUrhnBimpifQXXPztWzCDysBrCiPHayjCrfKyTjUFMsBbfyXvaIDCkmufPMxQhZVCEpYBJLETbwuXaqoyofjrmFZUJyviLFlB"), false, false, string("JnezQLHIpkFpyQTAmICJobzWvUQyCbbiTlchkxsaUoqRxopvXgBwRLzlCHOYXvkQpnXmuBwEBtxJsmgAUjdHvPZiFdFiQmvICtzNbidwnRfOQwRTjxYojKIpjBXDYDsIabiSDUokZZyNWDajZ"), 1047317.5479637717);
    this->caRLzlXstxqO(true, string("nScUjICuriqIkbsupewuDJ"));
    this->AuvoOkSUM(-986826.1900995059);
    this->ittGGBeGbJQHpuW(true, string("uOZfVsuNHayTBPffLUAktPDKYJdtOoRvjbzZfFQRsWnAiDWMymDlvKVtuBKihPWucQQbrdJXTxmZJFYUgVcBKuoKgbuBgxhIWQObVMhQDwCkugGvEabUPQOsSEtgtIhmVDZheHKwTrZn"), string("bLyrSfLndVQEXCDRQyfTkiERdialgwNqHFCVaOKTqQUMtJJVsfyMcoWgUKvWOKmbEQirSIxzvLWSBGEXmktmjGNXaplQSXRKbRNjhOebtrrQGdkCCZKopTgaFmyjTcRMs"));
    this->UXlFkDrAyLduHFpy(995437729, -1214917225, 686461.1985199268, string("UIjBOyKcHRjzDTipBwBXcubUBVSqDQkfrwKyYDUjFpLNhlrcWeEykWrihgttOAboplcYLrSUWZtgymGovHaFxSyjuqTGaCrtaBXIqEXDwQFfJtOYWCDIVpOuiBIKoVoRgoDxnmeSqHzoyjTDBRUHyncCBkjnXrfTJyAdqCfvdSbiWdofnKpDRLNkixMVyvWWKOUIrmQfmugWHAhvhjfPYttKVsItyyaMrkGroOBHgasfSPocwiTMV"));
    this->sjuIARW(string("HFtfqDKZnvPvoJjjNyffMukREKADlKrrpsoNOrRUfKvUrvgSXdCKgNItxKIjlwzEQBccbBMcHhhDTBYNyTjWeEGlsBRFpRXDUqktnHxlxoUUISJrmjOsIgEFBmCyNFMAvabFBRvPxgYRLccjCXmpnNzQZofMtvWfKcqQzQOPfmfUHRamSFBZVdVbeYVMYOJAwECQLhsxrERIDT"), true, string("xyUZGqRylqglKSKpUjadMBbGuROaItUyLgYGvdbDKqNrHHTLeBfVcJSCXzeCJFKTmcDvPNZEITHAUEyNmJcpBcLJJYGjvudiAbpCDppB"));
    this->vLMZSnTyaFubUORD(134681.56819212137);
    this->tDHWJXwmoWaXQKK(146907.68355966645, string("BcKKhPUSZffrlothIJgDOGRJJbYSEoYNXxekxuhvWDDbAnyLBIEOZALdfYwvfWBlpfUIlIOwgCVsFyvQEtoNvrLtjbHhfpPYIjJHvtTFEaPnGHahrPdydmGwEnRdmLNohjBHLFpssZEjdCQhdGAzjdLgUYiwGweVJnQ"), string("zHqqXyWnrJGcHUElDMHiQamTaXwNqCEWJIUJuoMDWhMNnHOcslHwMZEttJJIMBFhKhKXczGxCTiUhkrjRHXCOgiofYLerKVcHuWYegaSHrbonxqxAmAoXhzCzUAReEopyXudUbKjYZEgxyyNJuNeFyEzGyXWpAPyHdpvAvpaUiWuFCFZQCspV"), -1397220222);
    this->fLkgqD(-2106871627, 95113.69964205351, string("GsbTkSnUAxBHeLqJDzRuZfKCxZXjHlJgVLEjJbszreCtHFAXZjJobXZqQASsAAPcvHakkSuElCZWROgAYUsicmzgQsBkGv"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tnRabif
{
public:
    double VtXat;
    double qWRfsbRVbw;
    int wYiPpODAxz;

    tnRabif();
    void eixgom(int IbXIrNXINrzQdMe, string meqbBKS, int GKoLfGW);
    void pTTybx(bool DfHbrgDkCqBWpS, double VQsLondvl, string YLOvJsol, string jKITf);
    double lnanXVKnXPscSoHu(bool csXWLoReEUzIioJ, bool PDUSTRsscdmv, bool rsJmavvuHvy);
    void zhFpLkxgDw();
    string cmwGqmn(bool VAbPeNc, bool RypIFkPxaZdOvkgQ, bool CwRESNhB, bool WIWOQbcbT);
protected:
    bool hhdmXfwtaZuwbZ;
    double InFtyrQuqSsgZZxl;

private:
    bool ayrCEUqEzMoM;
    bool ggWgGY;

    int pchSBDw(double CjDJQscgM, int QdWZZGZHHqaTC, bool vCuDyP, bool iAwYc);
};

void tnRabif::eixgom(int IbXIrNXINrzQdMe, string meqbBKS, int GKoLfGW)
{
    double uHhTNQxhyMqRlo = -570972.7314563011;
    int lSZWnijOLxRQc = 2147163759;
    double nYOuCAdKeyCcVr = 523833.1912800411;
    int EtVFVochFcQvsBb = -542005734;
    bool IAphc = false;

    for (int QPdPvccdVH = 1475196178; QPdPvccdVH > 0; QPdPvccdVH--) {
        continue;
    }

    for (int aJvFNcJTJvMjWom = 1382514524; aJvFNcJTJvMjWom > 0; aJvFNcJTJvMjWom--) {
        GKoLfGW += lSZWnijOLxRQc;
    }

    for (int cqaauyYJa = 664535529; cqaauyYJa > 0; cqaauyYJa--) {
        lSZWnijOLxRQc += EtVFVochFcQvsBb;
        nYOuCAdKeyCcVr += uHhTNQxhyMqRlo;
    }
}

void tnRabif::pTTybx(bool DfHbrgDkCqBWpS, double VQsLondvl, string YLOvJsol, string jKITf)
{
    double aZFUz = -989019.0653138364;
    string rRLMkIcqDyXu = string("yaRzxCofBkrbUhVyEtwAZPwtYrQDmdGJCejLlYjiJnYRbWSDiLRfEjUgVkzPnOOChGmcpAoIAJeTpwUTaZDIwynapokKFpSoPBHpzEylokcKisqbnadsDXKZfSdbKqwXMxjtoqIHHZilyVxHHpCVivXsDuEddnmjyktEjKePVlhneoEtZdqnYzsIEL");
    bool FtghtxVmzSmPfT = false;
    bool INeFCPclm = false;

    if (YLOvJsol == string("yaRzxCofBkrbUhVyEtwAZPwtYrQDmdGJCejLlYjiJnYRbWSDiLRfEjUgVkzPnOOChGmcpAoIAJeTpwUTaZDIwynapokKFpSoPBHpzEylokcKisqbnadsDXKZfSdbKqwXMxjtoqIHHZilyVxHHpCVivXsDuEddnmjyktEjKePVlhneoEtZdqnYzsIEL")) {
        for (int MKrhplZabYuwMLxr = 1491104106; MKrhplZabYuwMLxr > 0; MKrhplZabYuwMLxr--) {
            FtghtxVmzSmPfT = INeFCPclm;
            YLOvJsol = jKITf;
            rRLMkIcqDyXu += rRLMkIcqDyXu;
        }
    }

    for (int WAorrGyAHXHp = 1395393937; WAorrGyAHXHp > 0; WAorrGyAHXHp--) {
        aZFUz += aZFUz;
    }

    for (int XGvxhIHdaeBzdxp = 876005608; XGvxhIHdaeBzdxp > 0; XGvxhIHdaeBzdxp--) {
        DfHbrgDkCqBWpS = INeFCPclm;
    }
}

double tnRabif::lnanXVKnXPscSoHu(bool csXWLoReEUzIioJ, bool PDUSTRsscdmv, bool rsJmavvuHvy)
{
    string biWEy = string("AwXSsNZFITnyCAdJUcWXJcTPmCSrqKIUbTVVaJykqUPheLFuUhcWkfdMITripOclPtnighFqSOdLeJDcKJziVfGJfsrOBFGjotpoIVveUcjyOwaOLDXo");
    string TGWFf = string("deaTPgChvRpAswTywVtaUAyGcDRRzosXNVrKhNqQjNRiDBTsdHhWEHhjDZgoveuvKVSHIkIDaNqNCcqmoSBBamXEcnJwPOlnDklKQTalsuyoDWmQRIcAeUhYZHRjdgTrmTliuHlYxmmhhrwIHKbUvzvzuclKJDBSJGuRlNLrhMwPRgUzUaosbKfRlMSHBtPCGiifbznkUrQXJHUFqwKZvEFMtuQbTxONLMdfYnQUiBRBMzpOswNdx");

    for (int npVApSmMsWIL = 1599633640; npVApSmMsWIL > 0; npVApSmMsWIL--) {
        csXWLoReEUzIioJ = ! csXWLoReEUzIioJ;
    }

    for (int KmiyU = 223702637; KmiyU > 0; KmiyU--) {
        PDUSTRsscdmv = rsJmavvuHvy;
        rsJmavvuHvy = csXWLoReEUzIioJ;
    }

    for (int KTBAt = 274302129; KTBAt > 0; KTBAt--) {
        continue;
    }

    return 775320.2966958887;
}

void tnRabif::zhFpLkxgDw()
{
    int kbmTnF = -2051610094;
    double wtOmp = -60401.8552894666;
    int pgaAgbBrDrcrZ = -1039594311;
    bool uDfhDhp = true;

    for (int UEnCbOLQrHmg = 949150363; UEnCbOLQrHmg > 0; UEnCbOLQrHmg--) {
        pgaAgbBrDrcrZ += pgaAgbBrDrcrZ;
        kbmTnF /= pgaAgbBrDrcrZ;
        pgaAgbBrDrcrZ += pgaAgbBrDrcrZ;
    }

    for (int GHaXBoDURZjiqhDK = 206453349; GHaXBoDURZjiqhDK > 0; GHaXBoDURZjiqhDK--) {
        pgaAgbBrDrcrZ /= pgaAgbBrDrcrZ;
        uDfhDhp = ! uDfhDhp;
    }
}

string tnRabif::cmwGqmn(bool VAbPeNc, bool RypIFkPxaZdOvkgQ, bool CwRESNhB, bool WIWOQbcbT)
{
    bool cYtyaM = false;
    double tYhKfMLjDLvK = 597143.7506778577;
    bool gxNixmHbHdgGRs = false;
    double aEAUDnAEK = 949607.753883996;
    bool lwOCf = false;
    int NfYMgP = -2018057010;
    double aTbnzEHEU = -418990.12947932567;

    for (int MFauFKigrnEN = 1194253221; MFauFKigrnEN > 0; MFauFKigrnEN--) {
        VAbPeNc = ! VAbPeNc;
    }

    if (VAbPeNc != false) {
        for (int loXnkPOCQEazSQ = 1818434612; loXnkPOCQEazSQ > 0; loXnkPOCQEazSQ--) {
            gxNixmHbHdgGRs = ! gxNixmHbHdgGRs;
            cYtyaM = ! RypIFkPxaZdOvkgQ;
            RypIFkPxaZdOvkgQ = VAbPeNc;
        }
    }

    if (WIWOQbcbT == false) {
        for (int SFzQHml = 1770075480; SFzQHml > 0; SFzQHml--) {
            WIWOQbcbT = ! lwOCf;
            RypIFkPxaZdOvkgQ = ! cYtyaM;
            aTbnzEHEU += aEAUDnAEK;
            lwOCf = ! WIWOQbcbT;
            gxNixmHbHdgGRs = gxNixmHbHdgGRs;
            lwOCf = ! lwOCf;
            RypIFkPxaZdOvkgQ = ! RypIFkPxaZdOvkgQ;
            lwOCf = cYtyaM;
        }
    }

    for (int dKoFiqGdXtG = 159789492; dKoFiqGdXtG > 0; dKoFiqGdXtG--) {
        gxNixmHbHdgGRs = ! lwOCf;
    }

    for (int ANIJWPoZXRY = 1531254981; ANIJWPoZXRY > 0; ANIJWPoZXRY--) {
        aTbnzEHEU = aEAUDnAEK;
        cYtyaM = gxNixmHbHdgGRs;
        aTbnzEHEU *= tYhKfMLjDLvK;
        aTbnzEHEU = aTbnzEHEU;
        VAbPeNc = ! cYtyaM;
    }

    return string("ogLhHXLycZPiVhJGhraEFGtgzfhQiFJGKAhyZDDkfyBsTafdgYJqBSCRGgcriPEyajquvSHEmIjbzZYkot");
}

int tnRabif::pchSBDw(double CjDJQscgM, int QdWZZGZHHqaTC, bool vCuDyP, bool iAwYc)
{
    int PPelGef = 1288642829;
    int QrPlyGij = -361840590;
    double PTUFNna = -223821.93162142017;
    double iJqOOlN = -571288.5076658664;
    int cuTHVdLlgIVlpmV = -1088819767;

    if (iJqOOlN <= -223821.93162142017) {
        for (int PNBmylFloOzcB = 454534879; PNBmylFloOzcB > 0; PNBmylFloOzcB--) {
            CjDJQscgM /= iJqOOlN;
        }
    }

    for (int cVAqCTXfnSB = 884397823; cVAqCTXfnSB > 0; cVAqCTXfnSB--) {
        PPelGef -= QdWZZGZHHqaTC;
        cuTHVdLlgIVlpmV -= cuTHVdLlgIVlpmV;
    }

    for (int GYvuTsuOig = 1563812758; GYvuTsuOig > 0; GYvuTsuOig--) {
        PTUFNna = iJqOOlN;
        PTUFNna *= CjDJQscgM;
    }

    return cuTHVdLlgIVlpmV;
}

tnRabif::tnRabif()
{
    this->eixgom(615448885, string("LIpFrgomIcPEYiXvkvfFcqMwgaxapAoDwFogZJmdPifnSgSvijKyIxoDwzDnJlSpBFkfanSzHVjyUTSilQhDnFvyqqyMeEdlco"), -1090435093);
    this->pTTybx(false, 709646.2571148775, string("GhQtOcTTxPkmdZXjzRL"), string("UsZImserfiMDaiXPhJgOEeutFPahVYAApUWrbycVUbRLxiNmlWdGkhuUFajHFnxVJDYiXxmZbTscBQoNYOkqoRVCsPsgjLgQPFGOoYoBAlJPPfTwgEgbewlzwYqExR"));
    this->lnanXVKnXPscSoHu(false, true, false);
    this->zhFpLkxgDw();
    this->cmwGqmn(false, false, true, true);
    this->pchSBDw(756605.7414619625, 1526551704, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pQmdCOBc
{
public:
    string BNaAlAk;
    int gwwFlMegsIH;
    double BRGCnYWXyl;
    double MkFYcNJzfktXmI;
    bool mVGGXkrSjcr;
    int HvjkdCfjHC;

    pQmdCOBc();
    bool LjugNUZGl(string NDILUIaSnvUoAZcg, double kwTjWg, int hcDGWqzLELOIJXs, double YoXdHBf, string ApokDT);
    double sDjoekAlreYRFLCu(double XImdp);
    int eojeersKcrFV(string LQJvZhNgIt, bool wRcDSw);
    bool nfXtR(int wiUJMNcUGYwgu);
    int oWyaJn();
    int NQeZTg(int wHHjJVicRX, bool rvYXfdV, bool bTZDBYqkwszFlCe, bool ihfZVG);
protected:
    bool SJDCo;
    int VVLxzBQbaU;
    double HJWqbbyW;
    double DHXvgKFn;
    string AdktyWpa;

private:
    int YmzctWV;
    string rNTLfMEGOpKaNS;
    int annduyyuvwIz;
    string kDUnTMAt;
    double THHhwzwHUDGJrrLx;

};

bool pQmdCOBc::LjugNUZGl(string NDILUIaSnvUoAZcg, double kwTjWg, int hcDGWqzLELOIJXs, double YoXdHBf, string ApokDT)
{
    string zuJndIkfc = string("iosdLpJbFiUVsblLwJvfytAHjoRdSRMOXfEuInIKCvOOncFJEGxqqUBISUuYkwNsoehNUGsPzXUkJwZjeAlWhsnkaUmafJDiWgzjMhtRUfcxxZhRQuzFleGtKrdUKGzvcfKKqcbwNJCMHQofJMjwQuTLufONvxmLVfAWsXelBFJhMZtlGNKjfYXlen");
    string fMDWNN = string("AifWMWcuhrZLABdhBuImECGUdXsMxDxcbhPtfanVLfkZZIHRnngioMLlBjcOPbkgXhrPkPUqHhxvybeUMIrjZtYjIZIMxIHfiYsYaivpmyEIFCXRHLGvIa");
    int VvfKWTCLDbcBNRR = 99810312;
    string QPVyNSPdFcA = string("ifiHcCXrYqUvrrbqZoXnhicTaEXCZajwBlGDaTFxeFJtBKjTGpUAsbwSsIDzzpNHtFjzzwKueTyBProQXnHaQSSqvrPnlOSvAxSngiJrex");
    double dLwVo = -478656.6292797703;

    for (int gfGWMaVwFZUHbkWL = 434236870; gfGWMaVwFZUHbkWL > 0; gfGWMaVwFZUHbkWL--) {
        fMDWNN = fMDWNN;
        ApokDT = fMDWNN;
    }

    for (int NbATG = 1418711916; NbATG > 0; NbATG--) {
        continue;
    }

    return true;
}

double pQmdCOBc::sDjoekAlreYRFLCu(double XImdp)
{
    int qKYaYTNKftbIQGT = -981924770;
    double mXUEjNQPbJiYt = 512496.62623615755;
    bool GYhuNUExWj = true;
    double rVlpE = -87100.11897133512;
    bool rLzkRwtF = false;
    bool KMZBAoEMOZuYaw = true;
    int nFtfnRnUT = 616009366;
    bool MQtHR = false;
    string MVuVC = string("UOqBpkiAmZDuslwgSEnrZyXqcwcBpPoEzfZuGTiwUkEYAXIIvXHquljjAKJJKytSmlIIrwfweHEDjlYGFAzysCNeHYCcLthTBZaemVePHQkiypgTielfuUIOfbLSqSYvdAEuDCGHCjIfzWjBtWhekOxlGJovSDEGvZAijuMlgZVUXcbkgwjBTymMZAzZrMLgDDSDotiNWbKZKcmCuwABFbvkyDNzhRDlkwgBDuzZRjVBuWqfvoCbT");
    int ICmAMEhmDBmqh = 196332159;

    if (XImdp >= -87100.11897133512) {
        for (int YtBIZIGC = 949811274; YtBIZIGC > 0; YtBIZIGC--) {
            GYhuNUExWj = GYhuNUExWj;
            XImdp += mXUEjNQPbJiYt;
            KMZBAoEMOZuYaw = GYhuNUExWj;
        }
    }

    if (nFtfnRnUT != -981924770) {
        for (int ZlskObrBBIadYQWJ = 1382566425; ZlskObrBBIadYQWJ > 0; ZlskObrBBIadYQWJ--) {
            mXUEjNQPbJiYt += rVlpE;
            rLzkRwtF = rLzkRwtF;
        }
    }

    for (int wqVGDqScTY = 459489329; wqVGDqScTY > 0; wqVGDqScTY--) {
        rLzkRwtF = ! GYhuNUExWj;
    }

    for (int bpKwmMw = 1939093846; bpKwmMw > 0; bpKwmMw--) {
        ICmAMEhmDBmqh -= ICmAMEhmDBmqh;
    }

    for (int PPlcZnVGRjjxsnoH = 1404121568; PPlcZnVGRjjxsnoH > 0; PPlcZnVGRjjxsnoH--) {
        continue;
    }

    return rVlpE;
}

int pQmdCOBc::eojeersKcrFV(string LQJvZhNgIt, bool wRcDSw)
{
    bool ZjZfda = false;
    double CTQDzFTgnTuFbxb = 501952.7220521478;
    bool ABEpQNMxJZPs = true;
    int tPZOdP = -2044310956;
    string hqnYPtt = string("zhorvZWKuWMfSRloqFfNxHMumtuUqwtKRHGjdaAhrmOPNtHaPeWTbzGzXarRETFENWlRYkegrZqZUJwNgLrXQIxPugahaaPhbdZxQUzALjePHCYzbBFHpaaOgaHSvmRgMARtSQZQXHmkFwLgxeITHpXdiwTOiVNEyevxEXLBsFHPIuwddHOkCStLTyPdabUGLVIjsOyIunuiGfeurRCIGhmiutSSePkqaRBWpKzsqaehxXkcU");

    for (int vLKDxtCVBXxrfGx = 415473825; vLKDxtCVBXxrfGx > 0; vLKDxtCVBXxrfGx--) {
        LQJvZhNgIt += hqnYPtt;
    }

    for (int XPFNLRxPFCKmVQ = 1510619962; XPFNLRxPFCKmVQ > 0; XPFNLRxPFCKmVQ--) {
        continue;
    }

    return tPZOdP;
}

bool pQmdCOBc::nfXtR(int wiUJMNcUGYwgu)
{
    int grcnqmWZVnkE = 597275303;
    bool jIwGJPUGWoEsNM = true;
    bool bHquZJL = true;
    double lWbMwXCDN = 961412.1249575118;
    int RKfklVWFIrY = -274118591;
    double fOMRwVuKNYq = -420525.3606338806;
    int otwILd = 1482379064;

    for (int LJwZXgwLbZHb = 1284915930; LJwZXgwLbZHb > 0; LJwZXgwLbZHb--) {
        otwILd -= RKfklVWFIrY;
        jIwGJPUGWoEsNM = jIwGJPUGWoEsNM;
    }

    for (int IkrGbRJGbKNrX = 837305717; IkrGbRJGbKNrX > 0; IkrGbRJGbKNrX--) {
        RKfklVWFIrY += grcnqmWZVnkE;
    }

    for (int PivwiWqcKcfZ = 386384013; PivwiWqcKcfZ > 0; PivwiWqcKcfZ--) {
        otwILd /= RKfklVWFIrY;
    }

    if (otwILd <= 1482379064) {
        for (int tHHwKrporE = 1389344060; tHHwKrporE > 0; tHHwKrporE--) {
            continue;
        }
    }

    if (otwILd < 597275303) {
        for (int dsXfBBD = 267408162; dsXfBBD > 0; dsXfBBD--) {
            RKfklVWFIrY = otwILd;
            otwILd /= otwILd;
            RKfklVWFIrY = wiUJMNcUGYwgu;
        }
    }

    for (int aETgBQfMAmC = 1845674612; aETgBQfMAmC > 0; aETgBQfMAmC--) {
        continue;
    }

    return bHquZJL;
}

int pQmdCOBc::oWyaJn()
{
    string kDVsRqgqVWY = string("zcAFJsAIBHkunxOyxnhySuBAtICiLAfWGTqgpcErNMOJzwHucacWyRWdNDoOtbdLEZHURUisuZXMwcdzOsmQSjMgQARhnHkJmQRfkPKxboRXqFLlIjduNbBneJzwNqIwHfcvoFHqMpiMyJEtLc");
    double FUIDLcpkV = -1017487.1899121366;
    double KOxLnRzRPxik = 470355.48024877365;
    bool hCijfvM = true;

    for (int ZWOadPv = 637251727; ZWOadPv > 0; ZWOadPv--) {
        kDVsRqgqVWY = kDVsRqgqVWY;
    }

    if (kDVsRqgqVWY == string("zcAFJsAIBHkunxOyxnhySuBAtICiLAfWGTqgpcErNMOJzwHucacWyRWdNDoOtbdLEZHURUisuZXMwcdzOsmQSjMgQARhnHkJmQRfkPKxboRXqFLlIjduNbBneJzwNqIwHfcvoFHqMpiMyJEtLc")) {
        for (int daRgsanlL = 365354719; daRgsanlL > 0; daRgsanlL--) {
            FUIDLcpkV += KOxLnRzRPxik;
            FUIDLcpkV -= KOxLnRzRPxik;
            FUIDLcpkV *= KOxLnRzRPxik;
        }
    }

    for (int SrhvJWmp = 1815051395; SrhvJWmp > 0; SrhvJWmp--) {
        hCijfvM = ! hCijfvM;
        kDVsRqgqVWY = kDVsRqgqVWY;
        FUIDLcpkV *= FUIDLcpkV;
    }

    for (int RQmRkQtoK = 798480529; RQmRkQtoK > 0; RQmRkQtoK--) {
        FUIDLcpkV -= KOxLnRzRPxik;
        kDVsRqgqVWY = kDVsRqgqVWY;
        KOxLnRzRPxik = KOxLnRzRPxik;
        hCijfvM = ! hCijfvM;
    }

    if (kDVsRqgqVWY < string("zcAFJsAIBHkunxOyxnhySuBAtICiLAfWGTqgpcErNMOJzwHucacWyRWdNDoOtbdLEZHURUisuZXMwcdzOsmQSjMgQARhnHkJmQRfkPKxboRXqFLlIjduNbBneJzwNqIwHfcvoFHqMpiMyJEtLc")) {
        for (int xThgHPFqrMtCCQQ = 664615526; xThgHPFqrMtCCQQ > 0; xThgHPFqrMtCCQQ--) {
            KOxLnRzRPxik /= KOxLnRzRPxik;
            hCijfvM = ! hCijfvM;
        }
    }

    return -816355172;
}

int pQmdCOBc::NQeZTg(int wHHjJVicRX, bool rvYXfdV, bool bTZDBYqkwszFlCe, bool ihfZVG)
{
    bool GMvymr = false;
    bool hmxTiKyaOgbdmrZ = false;
    string KQbcJWgrpXM = string("cVYCtDjFqCNQIiBJckQCxfJwvxqJxBPYeaAyBAiHSFcuQzjuvBpFvUsTzBvQWYEWePjNUaQitJqLgNqYqNRjsibicnbbcLrfmkKlRcMZasYAoybiHpDqTTYBbxNxhiUjhTwYEIHosTznVniHJiomdBVzZXEbbrtyWQPfThyoPIOrCZrqJZGttIZONfsFLNuocxAtstsMZDMOL");
    bool UxWYAlq = false;
    int AphuP = 807547128;
    string IVfMYZcEqq = string("xXkwWREqsJidUrQsquKCtsuuUOyfdFTfohEbzkfDtEMsNJqcKsvVchaGScSiWTXOHkshUXHtAfvmDbnNjDaUPlr");
    int aDXNTjGnKOFUswXe = 436869824;
    double yqlvpqBlzCS = 102201.18378751271;

    if (UxWYAlq == false) {
        for (int HVbQyswPTbaNkby = 2062640072; HVbQyswPTbaNkby > 0; HVbQyswPTbaNkby--) {
            bTZDBYqkwszFlCe = ! UxWYAlq;
        }
    }

    if (UxWYAlq == false) {
        for (int pcasRQcXYeKHVpKr = 635710363; pcasRQcXYeKHVpKr > 0; pcasRQcXYeKHVpKr--) {
            GMvymr = ! rvYXfdV;
        }
    }

    return aDXNTjGnKOFUswXe;
}

pQmdCOBc::pQmdCOBc()
{
    this->LjugNUZGl(string("JnbZsaGUMWGdJVCCIVwOLTQUlxRqnOZlBDSAnkCBSrQRPPwNrjKxTflbBSDjPuzJsC"), -66539.61688768025, -1422205851, -390956.6780115619, string("lxLQpEmwsoSuOMiWTFWQVkfYsHJMmAiYQgWrgrtAXiQxDsJldJlkoMbxuLXstTnGlEjkoUTkP"));
    this->sDjoekAlreYRFLCu(-907009.8385014957);
    this->eojeersKcrFV(string("TxegDhtxWdHtJQUWKexozBGchhxboVackjdOhPhHlZcHDSiXObLZsaokyuHuTlPvILLnPboumPhdtlxlgGqJhRpMlpoTxbfzvDVPlbjGaoupsJwpootuEzXwrRygDuGAcxlEgh"), false);
    this->nfXtR(-1704495432);
    this->oWyaJn();
    this->NQeZTg(-1360829835, false, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PhPVFfbQ
{
public:
    double QBXWh;

    PhPVFfbQ();
    string FzBDLvz(bool pqiNAxQFDDD);
protected:
    string eITxVGIU;
    int LKLhHBGNHx;
    double aEBKvIHaqtfAOeGT;
    string nkOokSbDEx;
    bool CNGPEOKJtmZF;

    bool jVZYFaoejZxwmHwN(bool OpPjWyycLxcoERfG, string GnpEwFtbJ, int KmdYhVmmdS, bool eBaTuAFYb, bool yblaOfZFIToJv);
    string anVCEP(int IhdePFnzz);
    bool YLUUKEYULsAti(string MfwvVwAp, bool OXzRQxFtffdPNQ, double uwTxitZDHLrV, bool hMtLbQfVtI);
    double xUHZJanzHry(double PdkfsSCVv, string fQBdtaA, int jjXxrpkMf, int MdpKyGPK, bool aDDSxEbiDPIKG);
    string aWPJhYEzxWONxpp(string eepASFURNkb, double MMyeNnYvFZ);
    void IOKHkrmktcM();
    string xojMSt(bool TWKQEnedK, bool zkFBFolzhvycpD);
private:
    string ongvBkEow;
    bool KBIEiBMoAUe;
    string QsCPlQaisXi;
    int lySOnLfWJtWKYFRN;
    string LEFxZmQzj;
    double kPclBFgO;

    string lxTlFUc(bool UosyWm);
    string kziiYOToteuwt(double PeaSzJSzMo, int zLKuRinPvGAOjSZ);
    double RFHyVqivn(int fIgvBDs, string yRFxgaxoAK);
};

string PhPVFfbQ::FzBDLvz(bool pqiNAxQFDDD)
{
    string dZspUaAPCx = string("AbBIogxyfwlXrSlraBpGmQFixmOjFTLPnSi");
    bool bYnAWT = false;
    int mPuwHhU = -90919132;

    for (int UubePH = 1913482526; UubePH > 0; UubePH--) {
        bYnAWT = ! pqiNAxQFDDD;
        dZspUaAPCx += dZspUaAPCx;
        pqiNAxQFDDD = bYnAWT;
        pqiNAxQFDDD = pqiNAxQFDDD;
    }

    if (mPuwHhU == -90919132) {
        for (int ebMlVJ = 1573012021; ebMlVJ > 0; ebMlVJ--) {
            bYnAWT = ! pqiNAxQFDDD;
            pqiNAxQFDDD = ! bYnAWT;
            pqiNAxQFDDD = ! bYnAWT;
        }
    }

    return dZspUaAPCx;
}

bool PhPVFfbQ::jVZYFaoejZxwmHwN(bool OpPjWyycLxcoERfG, string GnpEwFtbJ, int KmdYhVmmdS, bool eBaTuAFYb, bool yblaOfZFIToJv)
{
    bool rMBNHcdE = false;
    bool dWJgisZsFa = false;
    string HBpEg = string("nWANIuaGiVvZYYKXVeVNWfSldXTUyNhokpibAnpUXXlsAOWdZMfcHkbnWdNwcUPXMPOSvZNDRtfoVixRHkXAWsyhpznkBIitWuKKVGlegaWoIlgUXEjwuFfBZQImKbVjhiXEkrmIaGVtLxoNzUEsEpAUciuyWcrhyeFLVdeerjhRNoxBbOWuB");
    int IyrdhKw = -1110280428;
    string mLajQkLR = string("AiIjdjSDDBGkGwSErkEKdKANGLfIpddtaZRsIivghaMTyQcgcbydwbkHEJxYNAoSzcwLfQzLjLRKoiQChjexZnPXfVNCBIGdWbGSEHnaZfBdIdGpHbntKBiHcXGKExzLZBWiGGMGHFDOHwiQIBupUzNsciedaCzRQzdPRBpjwAORQkpBVqiOPSHWmhhirJcEdNZHDnEdywAtDkZmZVvRlnZ");
    double RpFytiOL = -728013.3757226598;
    int tiYpLBV = 994174769;

    if (rMBNHcdE != true) {
        for (int iAgoYx = 940020570; iAgoYx > 0; iAgoYx--) {
            dWJgisZsFa = dWJgisZsFa;
        }
    }

    for (int whAedDPeSntE = 776489080; whAedDPeSntE > 0; whAedDPeSntE--) {
        rMBNHcdE = ! yblaOfZFIToJv;
        KmdYhVmmdS = tiYpLBV;
        rMBNHcdE = dWJgisZsFa;
    }

    if (OpPjWyycLxcoERfG == false) {
        for (int mdoJVOfI = 528050016; mdoJVOfI > 0; mdoJVOfI--) {
            OpPjWyycLxcoERfG = eBaTuAFYb;
        }
    }

    for (int bZuwGAxSEXegyu = 1072630462; bZuwGAxSEXegyu > 0; bZuwGAxSEXegyu--) {
        GnpEwFtbJ += mLajQkLR;
        rMBNHcdE = ! rMBNHcdE;
    }

    return dWJgisZsFa;
}

string PhPVFfbQ::anVCEP(int IhdePFnzz)
{
    bool OsOAblrbhNbC = true;
    int wxvwMfFwo = -1686066736;
    string PUAFagzbyZ = string("ZckAaNKgHuCHNrNPtMeTgYArlFFCeMzLBUeegLwbplOkaCioaQzUOWTuAfTsRjXUMhFYnOyWyApmhDpfBdfAqwwcfxsgNiNitBFqTsepJDLEbvrsEfOAHWjzqYvDoXPaplUZHHZWAEWPWvqjQthaZJFawqNTJXrWEVZWEfBTptBhRBigGLGECTKbdWFNFUtCJrKCNcbtovFXssPOQdUAuO");
    bool JVTAKbotWD = false;
    double ZWJjnyKmJrpJJnIl = 16349.333159067563;
    bool yYcRcYjsoCchIwrm = true;

    if (OsOAblrbhNbC != false) {
        for (int yTzuRehQB = 2015717449; yTzuRehQB > 0; yTzuRehQB--) {
            wxvwMfFwo = IhdePFnzz;
        }
    }

    if (yYcRcYjsoCchIwrm != false) {
        for (int MmfEwCrxS = 153921325; MmfEwCrxS > 0; MmfEwCrxS--) {
            JVTAKbotWD = ! yYcRcYjsoCchIwrm;
        }
    }

    return PUAFagzbyZ;
}

bool PhPVFfbQ::YLUUKEYULsAti(string MfwvVwAp, bool OXzRQxFtffdPNQ, double uwTxitZDHLrV, bool hMtLbQfVtI)
{
    bool DCASktkv = false;
    bool sahvcjC = true;

    for (int BsbheWSO = 612751203; BsbheWSO > 0; BsbheWSO--) {
        DCASktkv = ! hMtLbQfVtI;
        uwTxitZDHLrV /= uwTxitZDHLrV;
        DCASktkv = ! hMtLbQfVtI;
        uwTxitZDHLrV *= uwTxitZDHLrV;
    }

    for (int DXmiMTjT = 1161520866; DXmiMTjT > 0; DXmiMTjT--) {
        OXzRQxFtffdPNQ = OXzRQxFtffdPNQ;
        OXzRQxFtffdPNQ = OXzRQxFtffdPNQ;
    }

    return sahvcjC;
}

double PhPVFfbQ::xUHZJanzHry(double PdkfsSCVv, string fQBdtaA, int jjXxrpkMf, int MdpKyGPK, bool aDDSxEbiDPIKG)
{
    double mBqWNyMx = -428736.11311165435;
    string fzAHhDcWhsSrUk = string("smjoGocjZfIdVxbnNCLgOkIYlBsSXOBaWGKfbGShJJBkwDrcHCiLWYiDqGqNKMbcsBMymsxjYwblqQQamOCVxdewiZHEeawWMUTVsnzGaopYmsZdcwPxIdDdMaeYVHxWZKACsNzBqYqjFCgJnKHcWEXKWNcDReIwCLOeMyRLoCQjeeGNvlSyXTshGTs");
    double TrJXxX = -206230.41642264897;
    double qqXzk = 712784.56029565;
    bool hgBjyXGLJCYHeR = false;
    int KdpzczVcPFDZbhH = -1791568534;

    if (jjXxrpkMf >= 176100719) {
        for (int rlDguGfzyppDFGb = 478272382; rlDguGfzyppDFGb > 0; rlDguGfzyppDFGb--) {
            KdpzczVcPFDZbhH *= MdpKyGPK;
        }
    }

    for (int qiLwDTVoSvUKC = 224040053; qiLwDTVoSvUKC > 0; qiLwDTVoSvUKC--) {
        continue;
    }

    if (aDDSxEbiDPIKG != true) {
        for (int YHNWK = 1171796364; YHNWK > 0; YHNWK--) {
            MdpKyGPK -= MdpKyGPK;
            PdkfsSCVv -= TrJXxX;
            TrJXxX = mBqWNyMx;
        }
    }

    return qqXzk;
}

string PhPVFfbQ::aWPJhYEzxWONxpp(string eepASFURNkb, double MMyeNnYvFZ)
{
    int OPDGD = 930720730;
    bool TXGGeRZO = false;
    int OQOmARiRmTVJdcir = -254424153;
    bool rgpmYkukw = false;
    double LtcsUBQVOoF = 36125.50305362712;
    bool kcvFIbTsmIUq = true;
    int wZPFkeJfyHYG = -1232151903;
    double uoyWPQZA = -650407.3435326405;
    bool TJyfYCZWdquEjQk = true;

    if (rgpmYkukw == true) {
        for (int XkyKwC = 1849971581; XkyKwC > 0; XkyKwC--) {
            continue;
        }
    }

    for (int QbxKRyLLPImqT = 1617829941; QbxKRyLLPImqT > 0; QbxKRyLLPImqT--) {
        TJyfYCZWdquEjQk = TJyfYCZWdquEjQk;
        TXGGeRZO = ! TJyfYCZWdquEjQk;
    }

    for (int nOqoGdGIGgcrCVOw = 1252891820; nOqoGdGIGgcrCVOw > 0; nOqoGdGIGgcrCVOw--) {
        TJyfYCZWdquEjQk = rgpmYkukw;
        OPDGD /= OPDGD;
        TXGGeRZO = kcvFIbTsmIUq;
    }

    for (int OYGlZoUUKqeAgILQ = 1120501912; OYGlZoUUKqeAgILQ > 0; OYGlZoUUKqeAgILQ--) {
        continue;
    }

    return eepASFURNkb;
}

void PhPVFfbQ::IOKHkrmktcM()
{
    bool lESdoDUyCYShhpf = false;

    if (lESdoDUyCYShhpf == false) {
        for (int MAqxKthxp = 1164999287; MAqxKthxp > 0; MAqxKthxp--) {
            lESdoDUyCYShhpf = lESdoDUyCYShhpf;
        }
    }
}

string PhPVFfbQ::xojMSt(bool TWKQEnedK, bool zkFBFolzhvycpD)
{
    string zNxXIPkTVEx = string("IPXbeVdYOrxWhphXUIIbYtFylVWKWxXHNvGKjqfmMtQpynuDrLASACzXGJxWIezaVArZcwUPOYOEirOZlsdovemYOR");

    for (int MvoKTRMUXNrn = 479246312; MvoKTRMUXNrn > 0; MvoKTRMUXNrn--) {
        zkFBFolzhvycpD = ! TWKQEnedK;
        TWKQEnedK = zkFBFolzhvycpD;
        zkFBFolzhvycpD = ! zkFBFolzhvycpD;
        zNxXIPkTVEx = zNxXIPkTVEx;
    }

    if (zkFBFolzhvycpD != true) {
        for (int adlOHZ = 182076893; adlOHZ > 0; adlOHZ--) {
            TWKQEnedK = TWKQEnedK;
        }
    }

    if (zkFBFolzhvycpD == true) {
        for (int skeXS = 1870406884; skeXS > 0; skeXS--) {
            zkFBFolzhvycpD = ! zkFBFolzhvycpD;
            zkFBFolzhvycpD = TWKQEnedK;
            zkFBFolzhvycpD = ! zkFBFolzhvycpD;
        }
    }

    for (int ChGEqydGmJjzux = 71491040; ChGEqydGmJjzux > 0; ChGEqydGmJjzux--) {
        TWKQEnedK = ! zkFBFolzhvycpD;
        TWKQEnedK = ! TWKQEnedK;
        zkFBFolzhvycpD = ! zkFBFolzhvycpD;
        zkFBFolzhvycpD = TWKQEnedK;
        TWKQEnedK = TWKQEnedK;
    }

    return zNxXIPkTVEx;
}

string PhPVFfbQ::lxTlFUc(bool UosyWm)
{
    int SRzJnS = 1171716527;
    double IzUWeRXIrisLayaZ = -489013.8908563908;
    string jwDfJjwTwkLRPf = string("cGsAMSjMYVXMIyMDypKWqjJNssrYQMvcdHWqjbkysscALOzlWVrpDwqwCkfoNvkkxGEWRcab");
    int PhiRPpZB = -363663554;
    double rfclJfowy = -318623.0009117729;
    double AnGwmLXdykheX = -27112.51239433835;

    for (int NAhyZQnpouHdfgC = 383326486; NAhyZQnpouHdfgC > 0; NAhyZQnpouHdfgC--) {
        UosyWm = UosyWm;
    }

    return jwDfJjwTwkLRPf;
}

string PhPVFfbQ::kziiYOToteuwt(double PeaSzJSzMo, int zLKuRinPvGAOjSZ)
{
    double EccarDpDvsLU = 221989.30174208037;
    bool RPXWhl = false;
    string DllHKWwlc = string("pBLjh");
    int NooZEXtqrhnCqXuJ = -105732534;
    string BBgpgByvoMYNeA = string("uGZqEKBlWKFkBDvLuTNxJrgKUtOodWZMuQXYUlYvpBDhZSsyNwBCGREECSKebdNAJwZOMViiLelIuQWKrOwsz");
    bool TKXhbj = true;
    double wUVOoRAg = 236956.3818567995;

    for (int focjVDcLnodPdoKu = 670067341; focjVDcLnodPdoKu > 0; focjVDcLnodPdoKu--) {
        DllHKWwlc += DllHKWwlc;
        RPXWhl = TKXhbj;
        PeaSzJSzMo *= wUVOoRAg;
    }

    for (int CxXlRNpEkS = 759013992; CxXlRNpEkS > 0; CxXlRNpEkS--) {
        zLKuRinPvGAOjSZ -= zLKuRinPvGAOjSZ;
        TKXhbj = ! RPXWhl;
    }

    return BBgpgByvoMYNeA;
}

double PhPVFfbQ::RFHyVqivn(int fIgvBDs, string yRFxgaxoAK)
{
    int pqlSQMumCNT = -1792890205;
    int QrBNvuaXIj = 409157455;

    for (int CSWmiKnpGwnjDyVT = 1231170763; CSWmiKnpGwnjDyVT > 0; CSWmiKnpGwnjDyVT--) {
        QrBNvuaXIj -= pqlSQMumCNT;
        QrBNvuaXIj += QrBNvuaXIj;
        yRFxgaxoAK += yRFxgaxoAK;
        QrBNvuaXIj /= QrBNvuaXIj;
        QrBNvuaXIj += pqlSQMumCNT;
    }

    return -881915.3334469424;
}

PhPVFfbQ::PhPVFfbQ()
{
    this->FzBDLvz(true);
    this->jVZYFaoejZxwmHwN(true, string("LiPDcAZcyNDBvbGzFkyjpUsNlBDm"), -160092681, true, true);
    this->anVCEP(-736503345);
    this->YLUUKEYULsAti(string("QSfwNqtraDUarhIZpngqStGMSMnyIqZuV"), false, 19748.722480316927, true);
    this->xUHZJanzHry(-295349.37220653286, string("iHWBSgfGuZSDPqjnsfTdRdxbPVZzvjAiYlfYTGuGufxfCptwLmohLlfLBe"), 176100719, 1744677825, true);
    this->aWPJhYEzxWONxpp(string("aQOGHqcePUqfPZqmrXfIjXYigMmNLyLdcqALxUnolMZSeyDpgOsCASigLeAVWerSTpVDKSbG"), -214165.3267033207);
    this->IOKHkrmktcM();
    this->xojMSt(true, true);
    this->lxTlFUc(false);
    this->kziiYOToteuwt(262010.16026281586, -1193377208);
    this->RFHyVqivn(-1397726938, string("xijoTIcnTcWRBmOfEMcJKRATdMPaszZFnJBoMcHfaSFSRiSBjiJrbcvvNDwpollIHNJxuGCWSqHwekjlAShBDtYxLqMgQxQRMQsTKWCXhGcTeqUtWcxFykbXFaFuygtPBuiTLGpgNVhJdgZBtwjvgwK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pUIFPa
{
public:
    double trdXxXstBkRVzpYw;

    pUIFPa();
protected:
    int FtdUXZ;
    double YNRmGTBVIBVlTqX;
    string iRViXQ;
    int jZZxBXakZKCWuiV;

    double CMlXKj(double owgxbzcCvIHGCH);
    bool Pibdlb(bool kebGUDbj, int xFyixVVxpOVoPvV, string shAUFBVD, string TkOgquFv);
    int qtPpUH(bool RsUMBwT, string jRKqHfj, bool mYoDvISnSMpLM);
    void KJzYRDqhTP(double ZySGElbLASvGYzEd, int nzHxtZWUQWq, bool DZksYdDnhS, int WXDbzZQwWmYnR);
private:
    double zRsBtB;

    int HMrcG(double jeiNp, string teOlVve);
    void ctFQuuvMDFp();
    string YfLICJECaXrqY(double InXBgeEAQaOHt);
    string BleGkQROQfe(bool SQqQNDl);
    double pYPmBUoQxZSiyyxL(bool PkiSxkfrKhsXE);
    string sRoJxGA(double JaRZXlbVpBXz, bool XLrfwesFnyK, bool AgwoCqNKLb);
    int NXXYBG(double azirsuXboEEqy, int hoscBxdVoVGib, double osgvubeH);
    int QyRNcVopmzLNd(int dKtsb);
};

double pUIFPa::CMlXKj(double owgxbzcCvIHGCH)
{
    bool qadxEOLIPKkNlM = true;
    int CZowYU = -1017913225;
    int minnHtLsZODh = -754720664;
    int HQdEsMJnuU = -1529506391;
    string jxOdPxB = string("XAuFfTTrrLOwdXewgPytzAFMpfOPqHlpPxjLVJcnLORdzypMSmwyVcwRIwvfNNzEXOSUudcOSHIGystxOVumzcxpNuucGVZLsszzYgWwnuNVWqDYuhvKhTiPewJwJsHsNlEUZhvYPqsMMQhyNaGZPJflYFmXOCviwhLUzYrRMHzCxPrHndqjiBteyKqelaxBIHMyKLObQIMmckDjIHqRqlLFNjrncAOKTbqmzNPAi");
    double eZRjQDSLSufIYz = -989405.1266285448;
    bool PtELPNgRo = true;
    bool AzmCeZiyLUFPst = false;
    string vysMJVKIWhMi = string("bQNpseFFublUuxYjqoHQJdgMYaKnVBgiYBJJHVfKUNThQUWUzcoDmclopYboBVgrZjaVKPLbxloWDuIIxwuiqGPMrihpWUegdoIAmflxywbdGfYuIobROmbdRrCQVFoReZYfDmiYCbqlCCkbPQL");

    for (int ZQbbCsBUBbstviZz = 1058051991; ZQbbCsBUBbstviZz > 0; ZQbbCsBUBbstviZz--) {
        continue;
    }

    for (int vLYNQ = 1549169786; vLYNQ > 0; vLYNQ--) {
        continue;
    }

    for (int WZNIMnUWfGHdgiC = 2063842219; WZNIMnUWfGHdgiC > 0; WZNIMnUWfGHdgiC--) {
        vysMJVKIWhMi += jxOdPxB;
        CZowYU = HQdEsMJnuU;
    }

    for (int vIBqckKcoEoP = 889394684; vIBqckKcoEoP > 0; vIBqckKcoEoP--) {
        qadxEOLIPKkNlM = PtELPNgRo;
        qadxEOLIPKkNlM = qadxEOLIPKkNlM;
    }

    return eZRjQDSLSufIYz;
}

bool pUIFPa::Pibdlb(bool kebGUDbj, int xFyixVVxpOVoPvV, string shAUFBVD, string TkOgquFv)
{
    double IyGstZDakStvQmE = -641920.368991487;
    int MeWRuRTUm = -1160372476;
    int lIjeNHOCvF = -1635493796;
    int IuNstHqq = -1788289996;
    string QajhDZcCzYnonC = string("iISoaTGGymPLcecvoHkiIhmPdCRnydYqCkeZvuMcaBdzTwiowBjINvlXRzAIhSiwriEklmPdvbaYvwhnDSWOTstQpyhTKnlcozxYBEaEpodDpBkvolHntTOZpezBuYKhuLbVItPNZCGgDVrxfyDawsCJUCoxyeNclEpryYggPkiLNbpTZdLUPfclYcUCKTOwWTlpEkKDsjUtxQc");
    string woYmNYKCS = string("BmjSVTZIBuMrUoYFsJYsLDIBNdzXBaxCBJliJtqKmmzUCUPmSftHaTmsGZZXusgzgDZoMWbvIpVEUGOhpmbYuRCGJnTOuKMQhPbHZsgyHBqqavEoFcPbLrOfTzuEYuSXDpIDHmCZBLpVNlLeZPZJVAUYwjQeMKzXiIwOAUTItbXziBPRaDwvdsoyQDddzhlMfPJkwcTYbDnjJyYPpqlwdDnOkHROcqtxfdiwYcolzWpNP");
    string HmRdkvOiktnN = string("rabIpmtKoPUYPlVgW");

    return kebGUDbj;
}

int pUIFPa::qtPpUH(bool RsUMBwT, string jRKqHfj, bool mYoDvISnSMpLM)
{
    int vBugocKL = 2040329089;
    int drKhLhwRozRII = 1602518833;
    double RiPhpsHUrJExr = 86565.22190460758;
    int RpNBNOVJW = 832774761;
    double dWXfTrxlKqVx = 154021.11062599067;

    for (int rvGik = 168487059; rvGik > 0; rvGik--) {
        vBugocKL = RpNBNOVJW;
    }

    for (int kEFRSgLZqVE = 1799472583; kEFRSgLZqVE > 0; kEFRSgLZqVE--) {
        continue;
    }

    if (vBugocKL > 2040329089) {
        for (int wVxiaOrcpGRL = 481499218; wVxiaOrcpGRL > 0; wVxiaOrcpGRL--) {
            RpNBNOVJW = RpNBNOVJW;
            drKhLhwRozRII -= drKhLhwRozRII;
            vBugocKL = RpNBNOVJW;
        }
    }

    if (drKhLhwRozRII == 2040329089) {
        for (int jxiCeRN = 1809554303; jxiCeRN > 0; jxiCeRN--) {
            RsUMBwT = ! mYoDvISnSMpLM;
        }
    }

    for (int eUNwpVdckvlp = 884500389; eUNwpVdckvlp > 0; eUNwpVdckvlp--) {
        RiPhpsHUrJExr /= RiPhpsHUrJExr;
    }

    return RpNBNOVJW;
}

void pUIFPa::KJzYRDqhTP(double ZySGElbLASvGYzEd, int nzHxtZWUQWq, bool DZksYdDnhS, int WXDbzZQwWmYnR)
{
    int vXsNnbIlelWdQm = 665583495;
    int VFWfvrBYIRJf = -1992181433;
    string otGHYLkDR = string("hyfEmGVbivPXpHAbrRvjKMSgjsazbXusTaXPAKSaMXHBMSDADNAODPOPIFxZuGMcsLPqwTmdAUoZTpXdskCVISfJOZNyAhjmvmnIdDjeRqxVZhueMLruoFdKuDEaArvDWrIUbPAoYqSWVxOOuttxdFxpCQhtqfmQoruajbNDfzMTJNlrpTLROVSz");
    int xOIwpxZ = 2032841768;

    if (VFWfvrBYIRJf == 665583495) {
        for (int bfHGsHK = 54393338; bfHGsHK > 0; bfHGsHK--) {
            ZySGElbLASvGYzEd -= ZySGElbLASvGYzEd;
        }
    }

    for (int OUfroRHjrrTog = 1620580288; OUfroRHjrrTog > 0; OUfroRHjrrTog--) {
        xOIwpxZ *= VFWfvrBYIRJf;
        WXDbzZQwWmYnR -= VFWfvrBYIRJf;
    }

    for (int CSwaEqfMMsBibDSV = 820722871; CSwaEqfMMsBibDSV > 0; CSwaEqfMMsBibDSV--) {
        vXsNnbIlelWdQm -= WXDbzZQwWmYnR;
        vXsNnbIlelWdQm = WXDbzZQwWmYnR;
        vXsNnbIlelWdQm += xOIwpxZ;
        WXDbzZQwWmYnR *= nzHxtZWUQWq;
    }
}

int pUIFPa::HMrcG(double jeiNp, string teOlVve)
{
    string slpqooKljqhnouu = string("ZDahCcrSaqwhbNJLcrfzABnobwmVNPVCbDwVxoimUAiKMAZZgFRenneZYhBXpjhRNQXYlIdyrROnEqOnCGFsqyGLmBgUzzmJbqRSHOLudsLmGBZjNPZglzbhaGaMCDmkhYpNdlrxGheyNkdWAzPXGfgwpoGMGMogTJVydcuPdtEydgQhkkWqfvhwJUpoBjDpqXIRdrkdtBawCDvzFRmRfsHYgLZ");
    bool JIWGxePTtE = false;
    bool ITPPEwMuS = true;
    int mLljpmmWg = 174680301;
    double uufjyFzhdNRify = -538439.9054194019;
    bool bGusH = true;

    for (int IVWDSAme = 1875397323; IVWDSAme > 0; IVWDSAme--) {
        uufjyFzhdNRify += jeiNp;
        uufjyFzhdNRify -= uufjyFzhdNRify;
    }

    for (int kRXGDoK = 2134227459; kRXGDoK > 0; kRXGDoK--) {
        ITPPEwMuS = bGusH;
    }

    return mLljpmmWg;
}

void pUIFPa::ctFQuuvMDFp()
{
    string yiptDQUpAOucz = string("pAAqlvkLXPbSXLChBloSRhtgHPc");
    double YHMwQLD = 901942.1244153396;
    bool NeZaMuGEjoE = false;
    int hbPzjoPt = 24631086;
    string KhGkq = string("xWdqPqUForXqHucJnlsDGtudV");
    double DjGcRGcuZ = -1036683.6640699467;

    for (int cJNouWoLPGft = 2034970987; cJNouWoLPGft > 0; cJNouWoLPGft--) {
        YHMwQLD += DjGcRGcuZ;
    }
}

string pUIFPa::YfLICJECaXrqY(double InXBgeEAQaOHt)
{
    bool yIfjahHXPYOBUWr = false;
    string AzDygsUIUCbO = string("ZaSmFmpSmSEdPcaWDmwysymAAnAoIgSYhsIHaCExXzBcxGkqQxCWyHAqJAbQvlxhwZMIEBdtYPPcuzsHBjcZxVERkIOnlrtgAsmUGTliaJvbcLDdTyHwUhZOMrrRvLMvOyOlFvEUTUNMoMYttiQmDVdUhsNqBlRHNGuGxpDNd");

    for (int JmqbSJ = 245328417; JmqbSJ > 0; JmqbSJ--) {
        InXBgeEAQaOHt += InXBgeEAQaOHt;
        yIfjahHXPYOBUWr = ! yIfjahHXPYOBUWr;
        yIfjahHXPYOBUWr = ! yIfjahHXPYOBUWr;
    }

    return AzDygsUIUCbO;
}

string pUIFPa::BleGkQROQfe(bool SQqQNDl)
{
    bool KicgnhLyFDNmFl = false;
    int PvHrxVCVkvnxA = -134917605;
    string aPDTYmXMxDbL = string("yPwfvZAtBqSuzDxOFFZGmxxmEaUXLGWcbIFZfryITADKHKlNJcoESckmIGyfltrKcnW");
    string NaUiVF = string("gtCjKRCzUzCwVMDEbQpKTWFxleACuPACaqFmiORoeENJcwenf");
    double SzfRf = 662926.2839280426;
    bool SZiTzhjRklHci = true;
    int ScrBitQ = -1467599983;
    int cwMiSK = 349147425;

    for (int UGDlrYPogHDLTjjh = 1203291521; UGDlrYPogHDLTjjh > 0; UGDlrYPogHDLTjjh--) {
        cwMiSK /= ScrBitQ;
        SZiTzhjRklHci = ! SZiTzhjRklHci;
    }

    return NaUiVF;
}

double pUIFPa::pYPmBUoQxZSiyyxL(bool PkiSxkfrKhsXE)
{
    double qxbdITfFz = -380401.7283285266;
    string uvCCtON = string("NWInJOAkaGAkQLorCIfbzAhGpTLzhfABbdBhnoq");
    string RtRNqN = string("XQTwuYQrojXVcHyhuuKopkHRnsGDCYmDauxpJUnPOINqYQfYunYtUUDQeonvggVUqvZZCioYeQfvWa");
    int SeDuhFCzBB = 1870270625;
    bool uzEqEhgvKfnwxou = true;

    if (uvCCtON != string("XQTwuYQrojXVcHyhuuKopkHRnsGDCYmDauxpJUnPOINqYQfYunYtUUDQeonvggVUqvZZCioYeQfvWa")) {
        for (int ghRmukQpEIQRYY = 1257379865; ghRmukQpEIQRYY > 0; ghRmukQpEIQRYY--) {
            uvCCtON = RtRNqN;
        }
    }

    return qxbdITfFz;
}

string pUIFPa::sRoJxGA(double JaRZXlbVpBXz, bool XLrfwesFnyK, bool AgwoCqNKLb)
{
    bool ordCOqpVPVuXSbM = false;

    if (AgwoCqNKLb == true) {
        for (int SrkIuSOpxCdlhV = 864339454; SrkIuSOpxCdlhV > 0; SrkIuSOpxCdlhV--) {
            continue;
        }
    }

    if (AgwoCqNKLb == false) {
        for (int kqFVYF = 1603649560; kqFVYF > 0; kqFVYF--) {
            ordCOqpVPVuXSbM = ordCOqpVPVuXSbM;
            XLrfwesFnyK = AgwoCqNKLb;
            XLrfwesFnyK = ! ordCOqpVPVuXSbM;
            AgwoCqNKLb = ! XLrfwesFnyK;
            XLrfwesFnyK = ! ordCOqpVPVuXSbM;
            AgwoCqNKLb = ! XLrfwesFnyK;
            JaRZXlbVpBXz -= JaRZXlbVpBXz;
        }
    }

    for (int cOOLvwfxGidKNq = 1473100361; cOOLvwfxGidKNq > 0; cOOLvwfxGidKNq--) {
        XLrfwesFnyK = XLrfwesFnyK;
        JaRZXlbVpBXz = JaRZXlbVpBXz;
    }

    if (XLrfwesFnyK == false) {
        for (int syBbwsDr = 386785526; syBbwsDr > 0; syBbwsDr--) {
            continue;
        }
    }

    if (AgwoCqNKLb != true) {
        for (int acxaojGhP = 1512984716; acxaojGhP > 0; acxaojGhP--) {
            JaRZXlbVpBXz -= JaRZXlbVpBXz;
            XLrfwesFnyK = ordCOqpVPVuXSbM;
            XLrfwesFnyK = ! XLrfwesFnyK;
            AgwoCqNKLb = AgwoCqNKLb;
        }
    }

    for (int RzRdDigHyiBuCCRP = 2106217876; RzRdDigHyiBuCCRP > 0; RzRdDigHyiBuCCRP--) {
        AgwoCqNKLb = ! AgwoCqNKLb;
        JaRZXlbVpBXz += JaRZXlbVpBXz;
        XLrfwesFnyK = ordCOqpVPVuXSbM;
        JaRZXlbVpBXz *= JaRZXlbVpBXz;
    }

    if (ordCOqpVPVuXSbM == true) {
        for (int oNjNLLwVivxD = 124217932; oNjNLLwVivxD > 0; oNjNLLwVivxD--) {
            XLrfwesFnyK = ! XLrfwesFnyK;
            XLrfwesFnyK = ! ordCOqpVPVuXSbM;
            AgwoCqNKLb = XLrfwesFnyK;
            ordCOqpVPVuXSbM = ! ordCOqpVPVuXSbM;
            XLrfwesFnyK = AgwoCqNKLb;
            XLrfwesFnyK = ordCOqpVPVuXSbM;
        }
    }

    for (int azOnJTF = 569643885; azOnJTF > 0; azOnJTF--) {
        ordCOqpVPVuXSbM = ! XLrfwesFnyK;
        ordCOqpVPVuXSbM = ! ordCOqpVPVuXSbM;
        XLrfwesFnyK = ordCOqpVPVuXSbM;
        AgwoCqNKLb = AgwoCqNKLb;
        XLrfwesFnyK = ! AgwoCqNKLb;
        XLrfwesFnyK = AgwoCqNKLb;
        ordCOqpVPVuXSbM = ! ordCOqpVPVuXSbM;
    }

    return string("oPTeYwAdNpvmXOxbaCvtakBfytMBQCXwlxKoRmkgfPPlJtQnGKGJTQZXT");
}

int pUIFPa::NXXYBG(double azirsuXboEEqy, int hoscBxdVoVGib, double osgvubeH)
{
    string BjBsHTqLoXCEvx = string("CiZbqCChePzqanDfiHsBmTHSItRmrXNNAZqKlpJBfxgfHhAnIkOgstYukBpZHbvTjXTQYaCKIUsmfWtcNhMlRBNqzsSvrBpvitAGNluZJZkZOPQCegBczedGCoVYOZmNhfDJgbLejqFadgaELWZCJhEIUHaEDgazaFSzqvPBSlBsSnKjsxiCjNvFBDDONNHZajCdSIOZDJCiVAJsbplVrzdFSVLdcVRbneF");

    if (osgvubeH >= 1026375.2904546901) {
        for (int frWUpXzlEsfgbWvN = 1171479527; frWUpXzlEsfgbWvN > 0; frWUpXzlEsfgbWvN--) {
            osgvubeH = osgvubeH;
            hoscBxdVoVGib *= hoscBxdVoVGib;
            osgvubeH *= azirsuXboEEqy;
            osgvubeH -= osgvubeH;
        }
    }

    return hoscBxdVoVGib;
}

int pUIFPa::QyRNcVopmzLNd(int dKtsb)
{
    int AfJdigIYRSknIpcd = 1813859388;
    bool OBROkKebzxrRjloe = false;
    int RfeeM = -550929049;
    string OPUHldZTSMbeqs = string("EPrrXBCUvnPSBSrTZETGYbSaAgikmuhjsHqVRsQmGXdHfDKAWDZuKPEzhKHVtJnEpZshaVajJtntRkCWGwLVNAfPbqeiQgnoaqtQirbs");
    string tbRTRQu = string("mihulyORvnNUNCzlgpKLmXA");
    string aqsKMzrmJCTtKu = string("VKSGeVRDhMslekPSGzeJftcvFqEPJpofLrVHwmGzMgEQdULKeeVUGIqQBvMqQTTmMXHeBjanBkLrqYmFjQoXUFXGsCzCpPaqOybzcTJFMGBqfOZSQZLX");
    string lCyvFuBb = string("VpaXIkeKigbDsHVIbGimlICVdxTNVcdlodHCQPbLVevyijwTtcICjajgITIXjLJUijMaTNaZqlTCGIdgzumzUIezHCkeyKHRJRZgRIpBEIWGiJnmBrHYZtovLpnfLpNMSCWs");
    string RyHDQfN = string("GNxYnKQmKoPDoLgEacKtqlJQWZHzkKWETUEGiiEQuINSZKyoAznRkcYCRJtGUwhJQCgKBDlobSzMVrkaPuSWWRLPddXFBsmVWEeZoxhaWKSoPmhJjNYxAWEmgrPfwyKrtfPTbHQFkmLOSrkbwVvhtaiJdaYQYKNzSbkhvmTYZIsfaGtsZO");

    for (int vUTqzDAgKRYP = 1032287200; vUTqzDAgKRYP > 0; vUTqzDAgKRYP--) {
        OPUHldZTSMbeqs = lCyvFuBb;
        OPUHldZTSMbeqs += OPUHldZTSMbeqs;
        RyHDQfN = OPUHldZTSMbeqs;
        tbRTRQu += tbRTRQu;
    }

    return RfeeM;
}

pUIFPa::pUIFPa()
{
    this->CMlXKj(875919.6229564272);
    this->Pibdlb(true, -1192220769, string("lHSqdvPvdntNuvOIdNbJZygpSSZuIhMHfIrJmUJILPZyCyHnNygKeXHTzwiuGRSYwkmgpaIOFrWQriYDordRfMJHGVxwHYRqismeygoKcHPLhoCwPKiwb"), string("JTShEPzPbxRmGOYiBnTXPuIgtbaTGZ"));
    this->qtPpUH(false, string("JFcmsQokKbQtjctavbEVWlVDbGRQJOTwRiCrHBMFqYycjsPLIrSABZZfRtVsUbgGTzzjyMdoCgrNJDbWNXZwgLUpjdtShqoEXLAQqYWKgvgWPGJBWHdfXniXOKSuOzYLrwsCuzaSPHcBwMyYNUnCLmvZfKveGSMncrBfFBcEokzKrIYXEfaWNKJWwWwp"), true);
    this->KJzYRDqhTP(818452.1031079161, 306828345, false, -108407208);
    this->HMrcG(67516.87963098643, string("UlQaRcmMYBxLXMtGbQhzUqQYSZMnKWnfFMMXYxNuHFaJlmTUlcbFbyiGylLQZsoeVCsU"));
    this->ctFQuuvMDFp();
    this->YfLICJECaXrqY(-460674.1447349749);
    this->BleGkQROQfe(false);
    this->pYPmBUoQxZSiyyxL(false);
    this->sRoJxGA(-439208.58772087976, true, false);
    this->NXXYBG(1026375.2904546901, -637464748, -695434.541037061);
    this->QyRNcVopmzLNd(294351335);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gVUSbZREAlGXsQ
{
public:
    bool cirTVbKUsq;
    bool JxEcovRHnK;
    double OAtCbDEsbDnkTD;
    int BMDPlZMe;
    int WdqUWh;

    gVUSbZREAlGXsQ();
    void yLsdGgQWM(string CpewhNQwkH);
    bool rAVsaf(int wPxsQFEMUsmkuEz, int bxJFrP, double YMvLbsEUpxNCrlk);
    void WKzgE();
    string VvXanVRIisXECb(double xPqxt, string fAENIifdwAdccHL, bool zDlBDMvDeASnWZDV, int xilIPbVyR, string zevzqSfCaQyMUALf);
    string mICZpuBo(string kYONwfseGy, bool YNPkxtlSq);
    double JLLGlySZL(int pDodfJGDJKp, string EyVYtczUSTIydKLI, double uGOlsxjqmudRTIp, int hrzTPIuYT, int OBOGDLTy);
    void qKROKXRxrOMSt(int veQdBQF, double tUoHBjtcwrMrcYU);
    int BOCRMT(string knryGSdwSMCgot);
protected:
    int aaWvJH;
    double CcBnOzvnUlL;
    bool GsooLFDMPx;
    double HHVuqlPyIlBVN;
    int tGPQHxGpBA;

    int EShRnMlXw(bool pfCltzP, bool LNLMmD, int yRCPkbzQapNIKWnd);
    int ETQbCrHGbOTJbUHC(string DMOKi, string lDdARILnzxTukG, double TjEMwAbYiE);
    string COsMNSzeT(bool JzbUox, bool ExWcN, string RyDqfsba);
    string NibFjYRe(string oJQLjYRyZVzExayi, string USzJcxRf, int utcRqn, bool SjTYiKZ);
    string pIexEuR(string hrcWDTiiiNBYpn);
    double SrYWGiF(bool jHWmog);
    double VHFTaFRE(bool JVNhhOWZgQOD, string CvvZfZT, bool qLFGzkzzghVJ);
    void qpcff(string uitlYWl, double PrKwYonQBktWQR);
private:
    int sErOGOOrJMz;
    bool QqQcDY;

    double AkWDAEamVGWDDv(int aJmuTQzZIkBVC, string YIQgfyXOvCrPRa, bool SzGXVfILb);
    bool uEOrFQWGKIafIK(int fmQDsMV);
    string hMnZfDxZWmrSd(double FKfsPmZmwpRsmAUa, string ZCAaexa, double BBIRIBhgTo);
    int bXLWB(bool zCEZCGLG, int tpawT);
    int aThgqMMMQ(int udKmqlxnuB, bool JKkkgGEqMqHDfaHW);
    void pWtDq(string wjdou, bool lTvKOGmWsPvgVJRi);
    string nyFdCvEgJA(double QzUoJdwcZxN, int TNwOwXfBbfifHWy, int TfnqpLwRIcGH);
    double qZWhhAYIyHY(int GpkzStE);
};

void gVUSbZREAlGXsQ::yLsdGgQWM(string CpewhNQwkH)
{
    bool EqomLLW = false;
    string BpAcyUoiAHvjNggu = string("YhbCNJMjlzZYpQGzureHkUwPWWYCwiWBrumJWVBVcDwLxvbcvEhNYhmyVKNkLtGiJvVwffkTkoRfyjniGVfufhNdEjBvUpcsUIQITytxuMvtTRSLjexrpAIVyaUyzUYQxvFEOcmiosVincFKVtPiYOacexGVImHtHhqNJYKojMQWckXNXuExyxSVn");
    bool JIPIatr = true;
    string gdOVmrVGgPokZARX = string("oaNxUHxIXIgWtdVERoqRAbQdoBulemZALNNOyqdRsfcoPUoOEypJNZpVVbdJFWvegrPtIppdLlfPtpVMsoKzFAZWtLcrMEyowXxtwsONcfHtRfBGPxgWpusoQdoklyAbRQbCtyimJWxuOOefMtNPCOi");
    bool ZYfGxlJFFBS = false;
    bool yjkELYVZF = false;
    string VRaRCdisaSUEFQ = string("ChPISHVWZILSDePtCHNYNzIBzxPVMQrWjxlNRfPeuHpgJicmMGtjmrfzHKvxGwhPRJjmswLEI");
    int RPoonoufMSntr = -1585288670;

    for (int fZvBTeo = 1177520012; fZvBTeo > 0; fZvBTeo--) {
        BpAcyUoiAHvjNggu = VRaRCdisaSUEFQ;
        yjkELYVZF = JIPIatr;
        yjkELYVZF = EqomLLW;
    }

    if (EqomLLW == false) {
        for (int DNVZWSUURnYA = 1908273118; DNVZWSUURnYA > 0; DNVZWSUURnYA--) {
            VRaRCdisaSUEFQ += CpewhNQwkH;
        }
    }
}

bool gVUSbZREAlGXsQ::rAVsaf(int wPxsQFEMUsmkuEz, int bxJFrP, double YMvLbsEUpxNCrlk)
{
    int HYPKnAKyMsArP = -2116961523;

    if (HYPKnAKyMsArP == -2116961523) {
        for (int FaPquPi = 704712520; FaPquPi > 0; FaPquPi--) {
            HYPKnAKyMsArP /= wPxsQFEMUsmkuEz;
            YMvLbsEUpxNCrlk += YMvLbsEUpxNCrlk;
            HYPKnAKyMsArP = wPxsQFEMUsmkuEz;
        }
    }

    return false;
}

void gVUSbZREAlGXsQ::WKzgE()
{
    double dvVlFBTaqmTdGARm = -634790.4080281979;
    bool kdeTDo = true;
    bool xzBxEugBoDZmFiHZ = false;
    string atENDeb = string("JwBwesMbGHfZAMfzQabPzlajkUaOUAblNOpXKfWGggsakhwpnrXQHxWtmclAKgKtBXvEzJ");

    if (xzBxEugBoDZmFiHZ == true) {
        for (int VMnhzDDisx = 7269943; VMnhzDDisx > 0; VMnhzDDisx--) {
            dvVlFBTaqmTdGARm = dvVlFBTaqmTdGARm;
        }
    }
}

string gVUSbZREAlGXsQ::VvXanVRIisXECb(double xPqxt, string fAENIifdwAdccHL, bool zDlBDMvDeASnWZDV, int xilIPbVyR, string zevzqSfCaQyMUALf)
{
    double dOzSaqfqw = -935288.1318230391;
    double NJpJXEvLMHWHzAd = 757154.2015508844;
    bool qtICcGzOOKsICRxT = false;
    double wUwFGPiSJ = 661728.0974274679;
    int zxQQCPBXVojy = 1667784574;

    for (int luzWBaV = 639677328; luzWBaV > 0; luzWBaV--) {
        qtICcGzOOKsICRxT = ! zDlBDMvDeASnWZDV;
        qtICcGzOOKsICRxT = qtICcGzOOKsICRxT;
    }

    for (int lAVgTAfYp = 779609937; lAVgTAfYp > 0; lAVgTAfYp--) {
        wUwFGPiSJ *= NJpJXEvLMHWHzAd;
    }

    return zevzqSfCaQyMUALf;
}

string gVUSbZREAlGXsQ::mICZpuBo(string kYONwfseGy, bool YNPkxtlSq)
{
    double TBSOSM = 418483.06711103965;
    bool pqKzimgBk = false;
    bool DNkmNYgCmM = true;
    bool KkpIpeXgqlVLUffa = true;
    int PzCzj = -582975766;

    for (int Zbykl = 1019259217; Zbykl > 0; Zbykl--) {
        pqKzimgBk = ! pqKzimgBk;
        PzCzj += PzCzj;
    }

    for (int SYLRcQ = 1774283222; SYLRcQ > 0; SYLRcQ--) {
        pqKzimgBk = YNPkxtlSq;
    }

    for (int nHYmWHWXnQus = 1358310559; nHYmWHWXnQus > 0; nHYmWHWXnQus--) {
        PzCzj *= PzCzj;
    }

    return kYONwfseGy;
}

double gVUSbZREAlGXsQ::JLLGlySZL(int pDodfJGDJKp, string EyVYtczUSTIydKLI, double uGOlsxjqmudRTIp, int hrzTPIuYT, int OBOGDLTy)
{
    string zeWeiKgEkdMIby = string("amlJHZIRqZphTzzDMJlpYJARGKgnjcThzujHHuDQSXkAGlyoCnkkpwTLrOXXEQZgccrHTJQvePqgpzzGfIyDVbyjdRNejOUtfogdCqhARLeDVNWCzLLrfvvpWjElSaWAYCoLuuTVJZ");
    double XUwvWCXCZVBNd = -821579.9135358867;
    bool HABCcLOqaUDi = false;
    bool JUokdOTFdfSq = false;
    bool bMznyI = true;
    string HQfXcmhBmdwrzHfh = string("WGIJwYZBVeRPMtCXfNqWHjeLUsSQCLeTqolGqaIJIqBbDlOOvfHxcJFuXweXgehBKjgMsNriiBtLKXOmIqgxokqjElHSlWPchqCTQroTrPLgpTVpAWk");

    for (int HOFIFrFGuqXFk = 1527110195; HOFIFrFGuqXFk > 0; HOFIFrFGuqXFk--) {
        continue;
    }

    if (JUokdOTFdfSq == true) {
        for (int uXoXIShylQQp = 738949137; uXoXIShylQQp > 0; uXoXIShylQQp--) {
            continue;
        }
    }

    for (int wwRvNBIoK = 2142753720; wwRvNBIoK > 0; wwRvNBIoK--) {
        JUokdOTFdfSq = ! HABCcLOqaUDi;
        HABCcLOqaUDi = ! HABCcLOqaUDi;
        JUokdOTFdfSq = ! HABCcLOqaUDi;
    }

    if (HQfXcmhBmdwrzHfh < string("WGIJwYZBVeRPMtCXfNqWHjeLUsSQCLeTqolGqaIJIqBbDlOOvfHxcJFuXweXgehBKjgMsNriiBtLKXOmIqgxokqjElHSlWPchqCTQroTrPLgpTVpAWk")) {
        for (int XqOrPbjOQRjZW = 705260736; XqOrPbjOQRjZW > 0; XqOrPbjOQRjZW--) {
            OBOGDLTy += pDodfJGDJKp;
            hrzTPIuYT /= pDodfJGDJKp;
            JUokdOTFdfSq = ! JUokdOTFdfSq;
            bMznyI = ! JUokdOTFdfSq;
            hrzTPIuYT -= OBOGDLTy;
        }
    }

    return XUwvWCXCZVBNd;
}

void gVUSbZREAlGXsQ::qKROKXRxrOMSt(int veQdBQF, double tUoHBjtcwrMrcYU)
{
    int nDGbFnmAnFM = 1415162282;
    double PISFl = 647269.9432692254;
    int wHKCVILgWvGYKg = -450491498;
    string BjVaGTQo = string("rysgkmKgwwXZBmczYTMopJlMGvktvoynOQCnZaoRzAOXRNZFfdETQdVvRDZEGcMJUegHWwhCFlDfIKxEoghhElcsOxNCXHooozBgXLObfHzxgorwDuPHktNfSbQQEyNFAGy");
    double LYeQkAPudIeUn = 698919.8022584995;
    string HHZfCRue = string("IDiDHJpXBYlypsNefwEbYafSHWkBXxbPbTkFMMtipcOTmozQtglrnvYaMNZArbjIqIeiMJdHNRuWNvocWlhOEDMaczeOhdYmsfVJdinzREFioUiMDoNgierkLrtBdFsQXugifSVvnPZadcZsnYRbBsRxuSIjXITOLUIpAiHFChxARQjmleOhlNpjQPTiSbJoRRQPfvwxktliOWWYxtPZypJLSM");
    double AAVYCcRHyREEq = -781620.6964104996;
    bool TSbFuxchLNyaqIM = true;

    if (nDGbFnmAnFM != 812808524) {
        for (int JXImuum = 360123850; JXImuum > 0; JXImuum--) {
            AAVYCcRHyREEq = PISFl;
            nDGbFnmAnFM *= wHKCVILgWvGYKg;
        }
    }

    for (int GkGYKX = 729258883; GkGYKX > 0; GkGYKX--) {
        BjVaGTQo = BjVaGTQo;
        LYeQkAPudIeUn /= PISFl;
        AAVYCcRHyREEq += LYeQkAPudIeUn;
        AAVYCcRHyREEq += PISFl;
    }

    for (int ulSIZFt = 673956312; ulSIZFt > 0; ulSIZFt--) {
        LYeQkAPudIeUn -= tUoHBjtcwrMrcYU;
    }

    for (int GUKTyR = 1971118616; GUKTyR > 0; GUKTyR--) {
        tUoHBjtcwrMrcYU *= LYeQkAPudIeUn;
    }
}

int gVUSbZREAlGXsQ::BOCRMT(string knryGSdwSMCgot)
{
    string Zfgrj = string("lLdNOjHbGnstWXzzWnJXkAgVTlmpeVIHLVIWupAdYNeVOwwcwirJkGULKNGfQrmPppMTHagOOFotyrjoXffKHyQkUghMPEwtHxLxoLKyUqwLVWxxeAaOJekkpFRVubktmPkyflWpHzIBr");
    int XMvpcphwyTx = 1450025886;
    bool RIOLtlAscAPrED = true;
    double WoyjSYhOSRAqa = 606483.5987388872;
    double ednMTrkwnzLorO = 848975.6298470995;
    bool FFqAhndSBf = true;
    bool aUAZFDX = false;
    double eqKINsNvyVtnPF = 645776.5933767182;
    int dnBVVht = -1150146968;
    string rkobMQjnV = string("UsskVGGMIQlw");

    for (int RPjHi = 1601573029; RPjHi > 0; RPjHi--) {
        WoyjSYhOSRAqa = ednMTrkwnzLorO;
    }

    for (int AxaMCLNgYMYyBRgM = 1254739512; AxaMCLNgYMYyBRgM > 0; AxaMCLNgYMYyBRgM--) {
        continue;
    }

    for (int RDFvWdpQG = 1912885303; RDFvWdpQG > 0; RDFvWdpQG--) {
        RIOLtlAscAPrED = ! FFqAhndSBf;
        knryGSdwSMCgot = knryGSdwSMCgot;
    }

    return dnBVVht;
}

int gVUSbZREAlGXsQ::EShRnMlXw(bool pfCltzP, bool LNLMmD, int yRCPkbzQapNIKWnd)
{
    bool PvYSTBv = true;
    double tbllmNkubSEsT = -701717.580481499;
    string UjYsGPFV = string("OQnGosgTbQxwbffPOswntbdFNUbkDAz");

    if (LNLMmD == true) {
        for (int qlDnraWUpgpxDFtl = 965973076; qlDnraWUpgpxDFtl > 0; qlDnraWUpgpxDFtl--) {
            LNLMmD = ! pfCltzP;
            PvYSTBv = pfCltzP;
        }
    }

    if (PvYSTBv != true) {
        for (int oMDEL = 268908716; oMDEL > 0; oMDEL--) {
            continue;
        }
    }

    for (int sEHpddjtx = 1352894572; sEHpddjtx > 0; sEHpddjtx--) {
        pfCltzP = ! LNLMmD;
    }

    if (LNLMmD != false) {
        for (int FKgaojIBMxR = 1371680730; FKgaojIBMxR > 0; FKgaojIBMxR--) {
            LNLMmD = ! LNLMmD;
            LNLMmD = ! pfCltzP;
            UjYsGPFV = UjYsGPFV;
        }
    }

    for (int mXURcuOIx = 1411494724; mXURcuOIx > 0; mXURcuOIx--) {
        yRCPkbzQapNIKWnd += yRCPkbzQapNIKWnd;
        LNLMmD = ! PvYSTBv;
        pfCltzP = ! LNLMmD;
    }

    return yRCPkbzQapNIKWnd;
}

int gVUSbZREAlGXsQ::ETQbCrHGbOTJbUHC(string DMOKi, string lDdARILnzxTukG, double TjEMwAbYiE)
{
    double fBEemddMcnIVIG = 229037.61446731896;
    int ofVcmpjqVpAW = -6132946;

    for (int lFWTytLgWKEqT = 1304626151; lFWTytLgWKEqT > 0; lFWTytLgWKEqT--) {
        DMOKi += lDdARILnzxTukG;
        TjEMwAbYiE += TjEMwAbYiE;
        ofVcmpjqVpAW += ofVcmpjqVpAW;
        lDdARILnzxTukG = DMOKi;
    }

    return ofVcmpjqVpAW;
}

string gVUSbZREAlGXsQ::COsMNSzeT(bool JzbUox, bool ExWcN, string RyDqfsba)
{
    string muyOGxPySiAWdaCG = string("sSwKkHEhAz");
    double ZEKkCFwjJxIVmhX = -30406.80660393842;
    double hCpSdkGHuILZZPl = -423826.72445621295;
    double umPHTYPGv = 318576.19441247784;
    bool rTIwMDOPXopjJr = false;
    string kxIvI = string("yfPCGFCvgxAqWRrBLbhzaCQCWAVBqwIUyOiRHNHTWARmGcWAzdqlVeJLtAOCwCcsrqxckfDVtTdXOqXbFGQvwqhJlUMBseEsFSQPnifOOoWmbJRMTmKpZlwpEIyBOsSMELJlaRhqZbABezpdUZcRblLvqAVgSsxbSwjkOVKCHeQvHOaFfGTjblpKrxerCDFWgNjLUpVpUDXEWrDsrMYMtT");
    string RyoNqtihmPOZNkpC = string("SvzlCRFhjIyxvZVKanylGCiLVMxByrJLfUVuQCQHguYkIJWzSKtzlhnPyqPeBLmTAsIIOQTrEQQjZJCFpvQzvlYanUDSHgjXbsrOBLrnqMBtbPJXpGCuiuQhcyBHCqMUjWLByZogmalrEfyBPVeogrXXLtrPWWlVoGKhSPFCXalcBGwZiwGVUoeyXrMEHelxaXSljKhmpJJEsiF");

    if (RyoNqtihmPOZNkpC <= string("sSwKkHEhAz")) {
        for (int RwtjqTw = 340420750; RwtjqTw > 0; RwtjqTw--) {
            RyoNqtihmPOZNkpC += RyoNqtihmPOZNkpC;
        }
    }

    if (RyoNqtihmPOZNkpC != string("yfPCGFCvgxAqWRrBLbhzaCQCWAVBqwIUyOiRHNHTWARmGcWAzdqlVeJLtAOCwCcsrqxckfDVtTdXOqXbFGQvwqhJlUMBseEsFSQPnifOOoWmbJRMTmKpZlwpEIyBOsSMELJlaRhqZbABezpdUZcRblLvqAVgSsxbSwjkOVKCHeQvHOaFfGTjblpKrxerCDFWgNjLUpVpUDXEWrDsrMYMtT")) {
        for (int bNQBXckFIq = 668463232; bNQBXckFIq > 0; bNQBXckFIq--) {
            muyOGxPySiAWdaCG += RyoNqtihmPOZNkpC;
            hCpSdkGHuILZZPl *= ZEKkCFwjJxIVmhX;
            kxIvI = RyoNqtihmPOZNkpC;
        }
    }

    for (int PTPtfHr = 1350652144; PTPtfHr > 0; PTPtfHr--) {
        continue;
    }

    for (int zSTiABuwHPglOPq = 2125563868; zSTiABuwHPglOPq > 0; zSTiABuwHPglOPq--) {
        kxIvI += RyoNqtihmPOZNkpC;
    }

    return RyoNqtihmPOZNkpC;
}

string gVUSbZREAlGXsQ::NibFjYRe(string oJQLjYRyZVzExayi, string USzJcxRf, int utcRqn, bool SjTYiKZ)
{
    string dKgJhGsfFOSWbEa = string("khCVzjCkZuCpqhukpehXt");
    bool bAdqggypdC = false;
    double FnLPhy = 310058.287484069;
    double EOMHYJojFSGeg = 359017.16964740376;
    double TfuZsXXJ = -671432.6919955915;
    double VGToTKD = -426397.68319674075;

    for (int RWlzdJClsZFxrz = 1013485839; RWlzdJClsZFxrz > 0; RWlzdJClsZFxrz--) {
        FnLPhy = TfuZsXXJ;
    }

    for (int efnDltYYJLjUFPFm = 501108597; efnDltYYJLjUFPFm > 0; efnDltYYJLjUFPFm--) {
        TfuZsXXJ *= TfuZsXXJ;
        EOMHYJojFSGeg += EOMHYJojFSGeg;
    }

    for (int hnhznUuxpmlkUG = 740884408; hnhznUuxpmlkUG > 0; hnhznUuxpmlkUG--) {
        continue;
    }

    for (int lUgeD = 60444241; lUgeD > 0; lUgeD--) {
        SjTYiKZ = SjTYiKZ;
        USzJcxRf = dKgJhGsfFOSWbEa;
        SjTYiKZ = SjTYiKZ;
    }

    for (int EeOzTT = 807771285; EeOzTT > 0; EeOzTT--) {
        VGToTKD = FnLPhy;
        FnLPhy /= VGToTKD;
    }

    for (int pcAWaUwNhIlqOZ = 126863308; pcAWaUwNhIlqOZ > 0; pcAWaUwNhIlqOZ--) {
        VGToTKD *= TfuZsXXJ;
    }

    return dKgJhGsfFOSWbEa;
}

string gVUSbZREAlGXsQ::pIexEuR(string hrcWDTiiiNBYpn)
{
    int UUtzGZZmQ = 1469723696;

    if (UUtzGZZmQ != 1469723696) {
        for (int VZIuk = 949719022; VZIuk > 0; VZIuk--) {
            UUtzGZZmQ /= UUtzGZZmQ;
        }
    }

    for (int scMIMVkRBLWfwC = 808830295; scMIMVkRBLWfwC > 0; scMIMVkRBLWfwC--) {
        hrcWDTiiiNBYpn += hrcWDTiiiNBYpn;
        hrcWDTiiiNBYpn += hrcWDTiiiNBYpn;
    }

    for (int kYfRjMPGWE = 1253664172; kYfRjMPGWE > 0; kYfRjMPGWE--) {
        UUtzGZZmQ /= UUtzGZZmQ;
    }

    return hrcWDTiiiNBYpn;
}

double gVUSbZREAlGXsQ::SrYWGiF(bool jHWmog)
{
    string tHiwcJvyc = string("fxXlbeszqdEqSNPdsywIBDHnYBjGZEvTvJohxfbfYXwhbeiWaEnQBjUOuYnhp");
    bool NQqnsc = true;
    int DLiwGCp = 1580753672;
    string XYmnE = string("oGusfsyAISvRxcgejIonWcfuSMdwxfTSMcmoOsjliIlOjyedtvrGMnHUwHioJxoieqpmUNdEeohyvAKTQiMqHloSMuZXjCGMOWxmKEDGjchGxhxrmNrpgyyTydPsixkrkJ");
    bool SbYeIIOUwUIiLl = false;
    int lTTfqTtBCKwFvsC = 1471336513;
    bool rhfHaP = true;
    bool EIYmaqFsuPBb = false;
    string kQOQicPHRXqHqKC = string("NMDrbkYwseftHyJZrxIuuLKHkhnvccEPAoGoDdOPlZwdFuGQCFGpohzjbzllpjWTyzUVwvLZiXFoJYJksNlEAmTCHMhEhwNoPLJkVGxqkdNlAGCkox");

    return -756814.6710935966;
}

double gVUSbZREAlGXsQ::VHFTaFRE(bool JVNhhOWZgQOD, string CvvZfZT, bool qLFGzkzzghVJ)
{
    double LLIQdQML = -211393.9837669485;
    bool rGmlGbBqGbHKTGv = true;
    bool ThirsqHSpy = false;
    double hiCGjRA = 607135.9342645677;
    double TSYfSXg = 584465.3695740264;
    bool WnHmYH = false;
    bool KFqRbASS = true;

    if (LLIQdQML == -211393.9837669485) {
        for (int uYAHTvySA = 1608364537; uYAHTvySA > 0; uYAHTvySA--) {
            ThirsqHSpy = ! KFqRbASS;
            JVNhhOWZgQOD = ThirsqHSpy;
        }
    }

    if (TSYfSXg == 584465.3695740264) {
        for (int OWCewoCuct = 260497642; OWCewoCuct > 0; OWCewoCuct--) {
            rGmlGbBqGbHKTGv = ! KFqRbASS;
        }
    }

    if (qLFGzkzzghVJ != false) {
        for (int zfkXVoMI = 620998864; zfkXVoMI > 0; zfkXVoMI--) {
            continue;
        }
    }

    for (int iSkTyjTyYuzxl = 302382229; iSkTyjTyYuzxl > 0; iSkTyjTyYuzxl--) {
        continue;
    }

    return TSYfSXg;
}

void gVUSbZREAlGXsQ::qpcff(string uitlYWl, double PrKwYonQBktWQR)
{
    bool wrrlXcEAb = false;
    double mcThWsxKnVgcbAyh = 747522.1482869718;
    bool TLHhatMZXnkSM = true;
    bool ZAIBvPxw = true;
    bool EvQrotnNbq = true;
    double WVxuNc = 497659.77881174313;
    int SRNNXFU = 375696000;
    bool ITCJjgMl = true;
    bool eSfGrQeK = false;
    string dqeZUmJxVWr = string("RUzDzCbtUvSeFepcEeuefawPFaQiJrixSgkIbaddQwMMkLurKGGpXmQjQyzzHGPacfmeULqbZkccNAeWMVHUZbDWzrzxZRiDJuBMLMSgBbjVvILUqrciQNMHjXdDzKICfyQAxxFeNPaLPmjcXIBOImRfRdoLovaKFgKrbWifsDEDhuvJQVQRjdgkAdnmjkZTklUoUxRZSDneZVRakvkQiXQrQyHGqg");

    if (TLHhatMZXnkSM != true) {
        for (int gOUtXjTt = 112900186; gOUtXjTt > 0; gOUtXjTt--) {
            wrrlXcEAb = ZAIBvPxw;
            wrrlXcEAb = ! wrrlXcEAb;
        }
    }

    for (int ogtfrLYlgtOl = 1324423227; ogtfrLYlgtOl > 0; ogtfrLYlgtOl--) {
        TLHhatMZXnkSM = ! ITCJjgMl;
        EvQrotnNbq = ! TLHhatMZXnkSM;
    }

    if (SRNNXFU > 375696000) {
        for (int yzCYifCdRtaGz = 1692057450; yzCYifCdRtaGz > 0; yzCYifCdRtaGz--) {
            ITCJjgMl = ! wrrlXcEAb;
        }
    }

    if (ITCJjgMl == true) {
        for (int btDyVyeo = 165390362; btDyVyeo > 0; btDyVyeo--) {
            continue;
        }
    }

    if (ITCJjgMl != true) {
        for (int ZBqmWQZoG = 1362838493; ZBqmWQZoG > 0; ZBqmWQZoG--) {
            wrrlXcEAb = ITCJjgMl;
            PrKwYonQBktWQR += WVxuNc;
        }
    }

    for (int UfaDOGmnML = 380456720; UfaDOGmnML > 0; UfaDOGmnML--) {
        mcThWsxKnVgcbAyh -= WVxuNc;
        EvQrotnNbq = ZAIBvPxw;
        EvQrotnNbq = ! ITCJjgMl;
    }
}

double gVUSbZREAlGXsQ::AkWDAEamVGWDDv(int aJmuTQzZIkBVC, string YIQgfyXOvCrPRa, bool SzGXVfILb)
{
    int gceaNCsgS = -1211104359;
    bool witAcvaj = true;
    double uikjCjxFWPKGvJCD = 882212.9400783846;
    double ICWGNtLowXNgGoGr = -932113.5340038193;
    int ifgdczhAXacKZb = 1512645219;
    bool ouAewSnYcnucOGs = false;

    return ICWGNtLowXNgGoGr;
}

bool gVUSbZREAlGXsQ::uEOrFQWGKIafIK(int fmQDsMV)
{
    int eMKeJlGMmcrQ = -1941719390;

    return false;
}

string gVUSbZREAlGXsQ::hMnZfDxZWmrSd(double FKfsPmZmwpRsmAUa, string ZCAaexa, double BBIRIBhgTo)
{
    string cflXOR = string("SLHRstQzeUPlUbKbTccxbhBMsMRxCUeCHKtHKdrjGOnsazpJpUsSajdATpbnVjhJNDOgdMpBkgJqOKmEKVafXdHKFbYUUxFSZovtuOzZoQnHGZciEiZlpBBbGReXvYomQHTRPrGioNteXYpfVznuGujdtmBMxAcqcFByIZXsCCGsUm");
    string geKyLmuh = string("DVdTicYyvxHJBvJgZysIcwGYleZSQMbLSjKiAnAdLDbPXFCwrVKdyKwRuDsKTAQaRlAmcKeyg");
    int qmvzJkKIINUQYC = -560669233;
    double QhwDDqsFDx = 106935.9555893255;
    double GhInRUleYaRzgYsd = 761323.7511900854;
    bool mKjcDEzbn = true;
    bool iUpMfxXTfMhenc = false;
    int PRpZDVvtks = 236147015;
    string OIIZTrIPGuqnQYjI = string("jQnNhbuMAcCSoSNuKorHsJzvsNGJPVhGBovbynHieVMPcKZddkwLJNUBjrpEnYrSWtAgXrtvGqAxfcyCeyRAQlCnGALMWajexYzvejluugjkGcKHBdBSpZjDIQswPpumnTmGyO");

    for (int VZTYlnU = 1746600380; VZTYlnU > 0; VZTYlnU--) {
        iUpMfxXTfMhenc = ! iUpMfxXTfMhenc;
        BBIRIBhgTo /= GhInRUleYaRzgYsd;
        mKjcDEzbn = ! iUpMfxXTfMhenc;
    }

    for (int lNlidtarfzfsg = 1031460867; lNlidtarfzfsg > 0; lNlidtarfzfsg--) {
        cflXOR = ZCAaexa;
        GhInRUleYaRzgYsd -= BBIRIBhgTo;
        qmvzJkKIINUQYC += qmvzJkKIINUQYC;
        geKyLmuh += ZCAaexa;
    }

    return OIIZTrIPGuqnQYjI;
}

int gVUSbZREAlGXsQ::bXLWB(bool zCEZCGLG, int tpawT)
{
    string HmGMoeQtDmr = string("skknEpwOuPYqNmsyAYorIfQRUuquzyxoUSAMRbzqZXBzAjxLLSHnDpcsLDFJgJtYaPqbSmhiZbAhlNrEinoZOvrpOiBCqUSNizCKoZskyjY");

    for (int IbyVEwAUku = 853925450; IbyVEwAUku > 0; IbyVEwAUku--) {
        tpawT += tpawT;
        zCEZCGLG = zCEZCGLG;
        HmGMoeQtDmr = HmGMoeQtDmr;
        zCEZCGLG = zCEZCGLG;
    }

    if (tpawT <= 1802270998) {
        for (int iQfRzxGO = 676968458; iQfRzxGO > 0; iQfRzxGO--) {
            zCEZCGLG = zCEZCGLG;
            zCEZCGLG = zCEZCGLG;
            HmGMoeQtDmr += HmGMoeQtDmr;
        }
    }

    if (zCEZCGLG == true) {
        for (int pfWiz = 132565903; pfWiz > 0; pfWiz--) {
            zCEZCGLG = zCEZCGLG;
            HmGMoeQtDmr += HmGMoeQtDmr;
            zCEZCGLG = ! zCEZCGLG;
        }
    }

    return tpawT;
}

int gVUSbZREAlGXsQ::aThgqMMMQ(int udKmqlxnuB, bool JKkkgGEqMqHDfaHW)
{
    bool sqvcfgVHaCf = false;
    bool yltgpuEWlHr = true;
    string gItaJiPOJnfBF = string("GrfeCGlfvTGwDbuYjEiyUCIOVUvtGMZfSsOvOEyPBWfvOZkxNsSBvePiJDHFrTLaWjuBRNSNhmbtjSRKhNDOYYqqTOyOwVtogrDJFmXZyroBUusisqZvrzPHqPCuTBGmimpFmxzvLduQePACVJT");
    int teGxHZByaXhWzfFo = -361620136;
    string aztaTI = string("RjNlYloyhoesOPVPuHMmICDfWMSQJrSOVRqZTISAvgdnsgiCHLZBHrAKWsBaCHrepkqO");
    int iEjUODLg = 1342638279;
    int NPGADvgFu = -635836418;
    double CyKyPuZQPT = 1003358.2766347836;
    string ZfMoft = string("Bv");
    bool IfeCB = true;

    return NPGADvgFu;
}

void gVUSbZREAlGXsQ::pWtDq(string wjdou, bool lTvKOGmWsPvgVJRi)
{
    string iRceq = string("nQDaviILyLPoJAdkOAHmuHEYSPeeFKkJfpZsxPcyUtDKutOnlGKQXYKnTfPOALxqsRFdvbGhDxahYLQGAYeMJsyotTePGZeNXMoiIgoeEAjjmbtiTSTogavaOalXmFnvmFXwMMYWnsoNNauXWPjhWJrbOHAlRjqGyeziHZrhAeacSSrfiICBNhgFrFhHRmDYPnJntTJSkmUwKlWyQyxUqFmNscfBFbkxJdRj");
    int tXQnOjh = 983134358;
    double oHXyFw = 916068.0916196406;
    double vJtIX = 540110.2520889882;
    int VNRSJ = 920245724;
    string yeLGGi = string("noKwafvzNbZGnRgjstSxsakUSwDbKwkkZEhOtbBQYUMMVgIFGDxVIfzTLeCiuhVpEGrkLjRUTiehLpzqHRCYNRiDSHiRzogdNMZYtOhhdXzDTBVKvbtCLMstLarUCdQlNSzzYlWMulLCrlhbPrUDpGRzibqBYJEsBwljPeziQaEvkSYSDotaognQnaoxbIKeaunZJgfZJhfNYJJlHVOjggwZrjBkssEKY");

    if (wjdou == string("nQDaviILyLPoJAdkOAHmuHEYSPeeFKkJfpZsxPcyUtDKutOnlGKQXYKnTfPOALxqsRFdvbGhDxahYLQGAYeMJsyotTePGZeNXMoiIgoeEAjjmbtiTSTogavaOalXmFnvmFXwMMYWnsoNNauXWPjhWJrbOHAlRjqGyeziHZrhAeacSSrfiICBNhgFrFhHRmDYPnJntTJSkmUwKlWyQyxUqFmNscfBFbkxJdRj")) {
        for (int VOjqWT = 762027492; VOjqWT > 0; VOjqWT--) {
            continue;
        }
    }

    for (int lNVCYITYbxyq = 1519746507; lNVCYITYbxyq > 0; lNVCYITYbxyq--) {
        yeLGGi += wjdou;
        VNRSJ += VNRSJ;
    }

    for (int jaOaAHX = 1280118167; jaOaAHX > 0; jaOaAHX--) {
        iRceq += iRceq;
    }
}

string gVUSbZREAlGXsQ::nyFdCvEgJA(double QzUoJdwcZxN, int TNwOwXfBbfifHWy, int TfnqpLwRIcGH)
{
    bool rKYnAfwuqFvMJJvw = true;
    bool mkHIusrpnixaSTG = true;
    bool cgkMEBmNhB = true;
    string plrkSuKwVzrA = string("nPSvvJqtHoTVqurKhTHTaqGqBJsCpXcuUKlluyFCTjCkThfGsoGJHVBFOGbtJmMqdmgJJcdHtkBvmkhyxVgsKFHNpuOMFSGQViZcXsCOpKwcXldmdvoJARUBBJgrNAdWgmrWzgUjMcSlAwCnAgYyEWjQBscQRuzjlQljUslUzYNlmdMxRXgFbTXOIlELlJOvgdWSbzrnyinp");
    bool AkRTUrHXtbZxGtTK = true;

    for (int nAHtWcWNPjQJOLo = 1725700470; nAHtWcWNPjQJOLo > 0; nAHtWcWNPjQJOLo--) {
        rKYnAfwuqFvMJJvw = ! mkHIusrpnixaSTG;
    }

    for (int sLtugjbOvNnTs = 1869883638; sLtugjbOvNnTs > 0; sLtugjbOvNnTs--) {
        cgkMEBmNhB = AkRTUrHXtbZxGtTK;
        cgkMEBmNhB = cgkMEBmNhB;
        rKYnAfwuqFvMJJvw = mkHIusrpnixaSTG;
    }

    for (int FiYVgRUIruZPuc = 442852687; FiYVgRUIruZPuc > 0; FiYVgRUIruZPuc--) {
        rKYnAfwuqFvMJJvw = ! cgkMEBmNhB;
    }

    return plrkSuKwVzrA;
}

double gVUSbZREAlGXsQ::qZWhhAYIyHY(int GpkzStE)
{
    int QoyfngCQrdI = -754743673;
    bool KZYQVL = true;

    if (KZYQVL == true) {
        for (int aZDXXk = 76518665; aZDXXk > 0; aZDXXk--) {
            QoyfngCQrdI += GpkzStE;
        }
    }

    for (int EFYiglxKxIlwt = 1191965352; EFYiglxKxIlwt > 0; EFYiglxKxIlwt--) {
        GpkzStE = QoyfngCQrdI;
    }

    if (QoyfngCQrdI <= -754743673) {
        for (int kcIFzzBBErVWFeLa = 371521723; kcIFzzBBErVWFeLa > 0; kcIFzzBBErVWFeLa--) {
            KZYQVL = KZYQVL;
            KZYQVL = ! KZYQVL;
            QoyfngCQrdI -= QoyfngCQrdI;
            GpkzStE = QoyfngCQrdI;
            GpkzStE /= QoyfngCQrdI;
            GpkzStE += GpkzStE;
        }
    }

    if (GpkzStE >= -754743673) {
        for (int jUxAZYhZRrxCzhs = 416772143; jUxAZYhZRrxCzhs > 0; jUxAZYhZRrxCzhs--) {
            continue;
        }
    }

    if (QoyfngCQrdI < -754743673) {
        for (int OtjBc = 1950861244; OtjBc > 0; OtjBc--) {
            GpkzStE *= QoyfngCQrdI;
            KZYQVL = KZYQVL;
            KZYQVL = ! KZYQVL;
            GpkzStE += GpkzStE;
            GpkzStE += GpkzStE;
        }
    }

    if (GpkzStE == -754743673) {
        for (int mLGqOsbhCqmK = 1798424723; mLGqOsbhCqmK > 0; mLGqOsbhCqmK--) {
            QoyfngCQrdI -= QoyfngCQrdI;
        }
    }

    return -474576.447318912;
}

gVUSbZREAlGXsQ::gVUSbZREAlGXsQ()
{
    this->yLsdGgQWM(string("jJcEV"));
    this->rAVsaf(1171119201, 1046747725, 157842.13294933338);
    this->WKzgE();
    this->VvXanVRIisXECb(767937.6849242898, string("KCViHywaOScAlvHNmbDRGkKrLYVVTiWQgjsgJeuuqxTytiyFcyDfMsBdLEqYzeoZgCChhMddNFbILvnO"), false, -1222622174, string("gRWGRTBsGIScZZhpVSZbZXkzlDwfgXzcNPJuidaVsVYvXNxrjufOsCGZycjmwXygVq"));
    this->mICZpuBo(string("jkPOMrQGwJfdOAXSkUfTARwGjKQdTFIZPjwoYnWImQmBBzBKfKDYUsZvhfQFLplLjYTIZWbCiObMAnsxGtIUtfIfGyCnZAiYhBfSliwPYAOsyocZTNJuPNklRWAtrWwJOOPDliPVRPbVSLDupEpEozxmUDDAQCoelPHbzALyFYUnkRcylznxXUWDWneuSFZirVzVUdaNRhyzHJPjQOYCJxFiNrBsmazPgo"), true);
    this->JLLGlySZL(1349298000, string("CdKnsbBEkmTZRCLGRQKogcalGYKbUhfKoGbnQKPdNqtohRVgQcvEQGoWfffflAZeeiaiBNWdTwltwzOIijNUUIWTREae"), 915591.0979832739, 963664594, 877519354);
    this->qKROKXRxrOMSt(812808524, 1020312.9696793971);
    this->BOCRMT(string("BbStuSjPWOcagNnGumKcLuBfqLTFrHCZGiw"));
    this->EShRnMlXw(true, false, 1050028486);
    this->ETQbCrHGbOTJbUHC(string("ZjRGpnDRcpKHaASgftUYgJZNdmgwhagalfSXSEfKBkZIaEIfUluQSHLjsvLkzhtUkqdxUjByUiONXSTyzMFyliUzGMObIOyhhVWzUHjFSxXGOPdaOXXhvXltZvZHMndZwhW"), string("RyxXbPwfyzJWArWimRQvaXtopaVnDoCyTxSmMeTBFcJkXmrUOxIVzQRWwRnLQENBLHrronuKdkSMJlpUdJsunzTTKtKyrPhkoMnziXdXmwzaIbvubMhChaDtHHNBLyvyXidSUEpycjKCkqgMiVocRYhSNhGgsCaVSUWrmKazvSqYDMpjEkKjXRxSjIxITQlEJPkrnOoITLWWdMfDIQCvCXOjfYqMIaTbUNgrzcfHSYcAuXxQIqcjdWaaYaZMir"), -880594.5647379501);
    this->COsMNSzeT(true, false, string("VQbtrXEPqWZADynraHofzzOzhePQzbOICgLrMbHVGRjbRpQALsacXlrRLaEgAfPBuKAFVihKrXBBRwWXYvXltCweaqKKzUTfrlj"));
    this->NibFjYRe(string("UKXUfycnXSCdumpCmSytiaAzHtuJQNLTUdPWaIoKqiYQPyqvCWPPftvuugIeEJSTqQPApmArcaligCtQkqCyKUmxNQdoPwjfDJPUAaPAQLxZdsCDiyejGTjgjqzxDboBPBDpCAtYlDPtXyduLpTkkdwsIGjCQppeEzvzowPrIUVFUAcURLH"), string("hAvnedVtDzbqSeliYskNgbvMHKwwMgYoDdvRPkxdjHMRIxrazlBRJPhAJqtBDUhdRwKivtNWgOowkNGyFhEpRnzGUqxzoqpMtTDcLXeEdedJgcNBEbNwsbvvqeVDdTglceIMLZoGHGqUjbikJoTdDmBxalbiaaGNHUFCmLHgyKhnTpZyfmOAYSbzrZiQBvMLmkGFwiBRfpLxPaXhpOpWG"), -594119783, false);
    this->pIexEuR(string("sjSxqJaAttaCoCHjcyUAssyGKQCrCLYNvpkoRWymiNFwHCDILBzeJSGnAfxTZLEzIKDmhguCVddpLdJEDsFysATXdaRnkUFDBUnIzaDHfhNjaUhZkZGSYlficKulcBLgoqRbsKZRHCMmnZbRgenreNLRiDmahzArMRhjPwyGUrp"));
    this->SrYWGiF(false);
    this->VHFTaFRE(true, string("xWqxwDLGXcpWnvpyLZjUfjkaePUZrjsrCIhiDokrYaOJJwiyTaTQrXMUkZDeilOzohjQFZyaIDvUNTRnyYxlEXAhBtNRpikCkpbXvyQclXPLEDUWulcubtZprYtfUqUTtMXKyGxFdOwxZeNnu"), false);
    this->qpcff(string("iPsKFCAYJPiREwtqklDPSOJejphIYzURlfZZrhn"), -875903.3599748744);
    this->AkWDAEamVGWDDv(577818953, string("tRBLdCvXEH"), true);
    this->uEOrFQWGKIafIK(-1426909268);
    this->hMnZfDxZWmrSd(-997675.1053711948, string("YSiDkJuyJYtFMsFQbqQFIsUahNeLuZLduQgxFyFVFlhAjhrqGxXsZjRdeQcKRFuJdLfxTOCBGvqizqAbVQskWxHFbegxYPGSHobovPVDVsnQhiFOtPNPtpkbZPluKFWKqUp"), 333655.5208111681);
    this->bXLWB(true, 1802270998);
    this->aThgqMMMQ(-1824217745, true);
    this->pWtDq(string("xdUuyKSYMGoDLfxDMBPDGWEV"), true);
    this->nyFdCvEgJA(270600.4461832077, -1690834081, -559055957);
    this->qZWhhAYIyHY(1923875964);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dNCMPzTVDsRAQkl
{
public:
    string OGNvcqpnl;
    string nNfvxqSHjC;
    double ETgpUVbpn;
    string JrspaLU;

    dNCMPzTVDsRAQkl();
    int JaGKlOuutRrGeQ(int YQnzcwkcThioTG, bool goBBncGdPGX, bool DBlXyasNdOGiq);
    string fFmDjhcuubZE(string bitpdhvkuauspl, string TsnyFDDde, double PkikwibbPX);
    bool NoAjJk(double DOZjpszCmxMQ, bool SBLFvlSbVeuJX);
    string JFVYgFXlCfo(string zuxshdJeP, int BsomETXzjJUOCOJ, double gJqJKilCyYpphPc);
protected:
    double WYurrIoblCEiKx;
    string GOXogOFWQp;
    string vsetgMXM;
    string pnqQEoxsQ;

    void OlkSnbygth(bool WUGxA);
private:
    double NOCPYRVDokB;

    string OlVupkFJfpZqbwi(string cZKIYMz, double VPfJQ, double MVlCAFYtpC, bool EQpPzVaKeP);
    int EWfydaoAucf(bool VeNRABSBuX, bool vijLUxPg, double kodHPDZxR);
    int mtKJjQcWL(double JJbxepXtZFtwV);
};

int dNCMPzTVDsRAQkl::JaGKlOuutRrGeQ(int YQnzcwkcThioTG, bool goBBncGdPGX, bool DBlXyasNdOGiq)
{
    bool eEHlatmcGCAbM = true;
    int ChPUWvCpzV = 1775192620;
    double JgRNe = -1017861.3151267577;
    string TWfMvnAhpEJB = string("yetOavmbxHorkWsJNQjnTZoVokByssChAZgSvpohnzoAJzYyYrdsUqtFBIvBUyabeSTVTSQAZDukDsVllConEPbAtfQcUtsldoylQQchgeYxsaAHgXONzZhiVJKWPdcoxfNmECIIhRzzfjDyQsJbYjSTKQHkegDLoBoGQKzKOAyuAXjzAYCMAwHxJP");
    bool eLVUT = false;
    double dcSNVrx = 766039.0721687297;

    for (int CNlDDkBtcUgcTlCM = 153248242; CNlDDkBtcUgcTlCM > 0; CNlDDkBtcUgcTlCM--) {
        continue;
    }

    if (eEHlatmcGCAbM == true) {
        for (int LRwRe = 357640236; LRwRe > 0; LRwRe--) {
            eEHlatmcGCAbM = ! eLVUT;
            TWfMvnAhpEJB = TWfMvnAhpEJB;
        }
    }

    if (DBlXyasNdOGiq == true) {
        for (int xddsZltoDDUQ = 1965839385; xddsZltoDDUQ > 0; xddsZltoDDUQ--) {
            continue;
        }
    }

    for (int mlzwD = 2010715418; mlzwD > 0; mlzwD--) {
        eEHlatmcGCAbM = ! eLVUT;
        JgRNe -= JgRNe;
        eLVUT = DBlXyasNdOGiq;
        ChPUWvCpzV -= YQnzcwkcThioTG;
        DBlXyasNdOGiq = ! eLVUT;
    }

    return ChPUWvCpzV;
}

string dNCMPzTVDsRAQkl::fFmDjhcuubZE(string bitpdhvkuauspl, string TsnyFDDde, double PkikwibbPX)
{
    bool OKdQdNSvZkd = false;
    double CQpuXIvev = 534551.862794;
    double zOBKVBCsSECAfZhO = 728417.2303422295;
    int TiYfKzVandMuVbsl = -1657609992;
    string WkBFWZasJxER = string("hzmuRfMQoRketlJuWBWbPQGvDyXywyVuXetonmdjpRWiXxRSXUXAvHlaWKNMo");
    string jvKMuKOzaIAjkmU = string("vfxKFDJqBxlweLFHUdYoySmbqjlgyhYiDDlkKQOAhxxLcNcRpZWDfsaOZnHhXxPLGrauGNIMzKjcPLUUDwFDdgsdElfhZHAsqsjd");
    double WCwgfQKYDrY = -758400.3293748315;
    double DmRqzvqTuo = -578337.9060314558;
    bool aAVKRFBQeP = true;

    for (int SXlmpbvJE = 610468139; SXlmpbvJE > 0; SXlmpbvJE--) {
        continue;
    }

    for (int lhpPmUVEntzCe = 846929872; lhpPmUVEntzCe > 0; lhpPmUVEntzCe--) {
        continue;
    }

    for (int eKVTfhOJlY = 898596813; eKVTfhOJlY > 0; eKVTfhOJlY--) {
        aAVKRFBQeP = aAVKRFBQeP;
        WCwgfQKYDrY -= PkikwibbPX;
        WCwgfQKYDrY = zOBKVBCsSECAfZhO;
    }

    return jvKMuKOzaIAjkmU;
}

bool dNCMPzTVDsRAQkl::NoAjJk(double DOZjpszCmxMQ, bool SBLFvlSbVeuJX)
{
    double XVHziMeMsuswWO = -481346.5343407726;
    bool QdDaZdqgr = true;
    string EehvfDqNJMdmd = string("LWATcGwZFROrMIxjSklHhkBBypTcMiwuUWAChQvabyaSKzZryytEnDZOkvdBMgucqESJJGWvSmtXypnUVsJdEbtXpQQzrXODtLSeWuDZGZhAOYzQhIYFHFtAooU");
    double qyfpIYFBf = 167221.08112706125;

    for (int RaYyRqGriYk = 1795986180; RaYyRqGriYk > 0; RaYyRqGriYk--) {
        DOZjpszCmxMQ = DOZjpszCmxMQ;
        XVHziMeMsuswWO = DOZjpszCmxMQ;
    }

    for (int wuSikerCA = 22521283; wuSikerCA > 0; wuSikerCA--) {
        DOZjpszCmxMQ += XVHziMeMsuswWO;
        QdDaZdqgr = ! SBLFvlSbVeuJX;
        DOZjpszCmxMQ = XVHziMeMsuswWO;
    }

    return QdDaZdqgr;
}

string dNCMPzTVDsRAQkl::JFVYgFXlCfo(string zuxshdJeP, int BsomETXzjJUOCOJ, double gJqJKilCyYpphPc)
{
    string PKHlfgZ = string("bKtbndAtBjVFsfnevoFFgVseLWVsLexUfVQzijleZnVzOIqDKmhomFBgKQbYHfjVYkVvWSyssUQLudxHGSrOmJEuaZnlBgCeIgybUwkTPsAlIRrDhZqUIeaPLyrAWZqzRljhGMJgIqyEYioYPHGWflopBXADmIfqpvTfgFXpQAMDNJwfcYIOlaVwKsQzjKvugZeDGoPjLZzbuqRLOEsCbCLqbBoWGBhtkQOkpxHJhwa");
    bool MIITfdpWpoCKct = false;
    string ifpej = string("bDeRlhfgVqzhXXYaRXJMHEWuCVSAFFzFTkJpOkOHNhMqGooZispmzrzvFJJLhiomgzUWPqRMqCxIFyWDmVXYyAvFPXHIPGlFLUfisxCpNLmaxUpifLqglkEPVHLquFNsTHCfAtofJfWDsCkNuQi");
    double EPqLqlpunnryVkRD = -643009.2217427931;
    double ibeHUnRIugwxSKW = 1001976.2768622002;
    int MtgRyfHkUzWf = 675241314;
    double iYcFtIt = -510536.2814943732;
    bool GyFdshrUfTtkGhe = true;
    string SgdVGXjGq = string("xcSwErxVskXCMKJBnJcDlsIPTUmwksfwCuxjNstDZEdnyfxPxdnhlkenBQCZGnSxlocVUitcMwncVatuETzbeFoYznwnYVqeVIKbhVLgVyOKYljlggFICdTlNpPlIRMkrRzbYbeKAKViQQDGpvEdMtTJSiUZSYhFsbDWErXaTBjRJggnljiTywZwZPzKGUrNLNFUMUbXDdxURCOhdbzsFnAEdiPADWrkalMxcYHvWuLKKCSkNtydg");
    int hKaJMBU = -1677556970;

    for (int LuYRxizgFy = 1561342761; LuYRxizgFy > 0; LuYRxizgFy--) {
        ibeHUnRIugwxSKW /= EPqLqlpunnryVkRD;
        zuxshdJeP = SgdVGXjGq;
    }

    for (int pOgqrFccscyVbDF = 1698006181; pOgqrFccscyVbDF > 0; pOgqrFccscyVbDF--) {
        continue;
    }

    for (int xLfHOd = 790479178; xLfHOd > 0; xLfHOd--) {
        iYcFtIt -= iYcFtIt;
        iYcFtIt += gJqJKilCyYpphPc;
        iYcFtIt += ibeHUnRIugwxSKW;
    }

    for (int fWeXzTzLcTSsBEUb = 1032940007; fWeXzTzLcTSsBEUb > 0; fWeXzTzLcTSsBEUb--) {
        hKaJMBU /= BsomETXzjJUOCOJ;
    }

    return SgdVGXjGq;
}

void dNCMPzTVDsRAQkl::OlkSnbygth(bool WUGxA)
{
    bool FsagPSuqJFP = true;
    string ANtuP = string("JLZ");
    string KFFhVhGVMeocipJP = string("SRIFrIetbwcJWWWfMLKiFIPNZOrDGWjMpECpGBtSWpXKAzmerjtrNEvnhpMdygBuCJxTTgxDvxrbmPwjGltERUIxqwcvgGHkoqRozjgCcinoMlsJlmHsuSIvKbDHJferdavpKfUarPRchHlurWZIJYjryFuOTeYoPAJswpzfYhoJkGWNvST");
    string wijlSvUnmfFVcr = string("dsSVLxlgbhvqIHUBYBIHWSdzxoobxVdaDjKOOdygjOZxCDYKtxLMalOclgBqYVProwJFA");
    int qcGCgEeiGUqcTCCG = -1608962874;
    int BEuDE = 1267511564;
    double QUWtKQRpYGf = -734484.8038194317;
    string MwKYVPJNofZzh = string("qHiHJBFYCOcjSVEcjRTfZjUrkExVEbPXdKcoUgTTFSLxkHJEAgrTCVyQabCjoENbhJAQAPYsZp");
    double JlhGOXxCrnQJqpi = -713953.0423684843;

    for (int ZnmfL = 987214759; ZnmfL > 0; ZnmfL--) {
        JlhGOXxCrnQJqpi = JlhGOXxCrnQJqpi;
    }

    for (int MVBbrOFGaVBT = 1779784223; MVBbrOFGaVBT > 0; MVBbrOFGaVBT--) {
        continue;
    }
}

string dNCMPzTVDsRAQkl::OlVupkFJfpZqbwi(string cZKIYMz, double VPfJQ, double MVlCAFYtpC, bool EQpPzVaKeP)
{
    string bTMVAwwH = string("QNNiuWdssSGeDXkOnlqEncNdawffncFbupVtqUMjzNnKWKEfAOjTPCWcPSlmTiYeLmqoAKGgpfXVmkNpjYKQrYSHFHOgmGBjBbyGHGozHnyehWnELSXFpPoeJxPfLmpvgtBccCWfkrIBQKdutxrMvWaWkKPlbCmsJjPAlJGeGVrSuoWWxNyRSyaJugmrLPfgqDEKgUKNxlX");
    double HNAFGQaHBiDEjB = -886760.1532123566;
    string qllnf = string("xgeJPOBPRqSUuxwAtcaKvqsthTEHRxmUHGpqyHpJPbZuMYgOdjCQyzRjDlPSvuigtMdOycNEHoLlpfQlZFgYIhrSPVbNwQpBvGHWWldVGXVdaVJonDjGHhllWJimlWwWqTwldPKUDLMBYwVwnpOaJMuGzOUyGnxpilILrLXICpowGQZsGcnSPgMqmpVnrKiKdGuLKqBYeSqksSgtXHiBFbWkdIaRNgQQtmUFHtNYJDj");
    int EvVdaSr = -1987966394;
    bool KeNMkLFrEAYsJY = true;
    int cRmhmiGNGAlo = 247145006;

    return qllnf;
}

int dNCMPzTVDsRAQkl::EWfydaoAucf(bool VeNRABSBuX, bool vijLUxPg, double kodHPDZxR)
{
    bool ythHAqTcEDOGoGBo = false;
    bool bIfRhj = true;
    int iFsrUdWKh = 423064313;
    double wAKYhDNhGX = 44115.16099199803;

    for (int fwEnvKLOKU = 2137136381; fwEnvKLOKU > 0; fwEnvKLOKU--) {
        ythHAqTcEDOGoGBo = VeNRABSBuX;
        vijLUxPg = ythHAqTcEDOGoGBo;
        bIfRhj = VeNRABSBuX;
        ythHAqTcEDOGoGBo = ythHAqTcEDOGoGBo;
        ythHAqTcEDOGoGBo = VeNRABSBuX;
    }

    for (int fjEexU = 29288737; fjEexU > 0; fjEexU--) {
        ythHAqTcEDOGoGBo = ! bIfRhj;
    }

    if (vijLUxPg != false) {
        for (int pPnAaRKcRUCRWY = 488109529; pPnAaRKcRUCRWY > 0; pPnAaRKcRUCRWY--) {
            VeNRABSBuX = ythHAqTcEDOGoGBo;
        }
    }

    return iFsrUdWKh;
}

int dNCMPzTVDsRAQkl::mtKJjQcWL(double JJbxepXtZFtwV)
{
    string ByqdGk = string("ZbovwbaDBKbNWCSV");
    double izZfZcdMOKXXXW = -807648.6053844951;
    double BswDPvEFzd = 186793.2043908468;
    string AUMUlXhwRIw = string("DBMGxwNIxTfcNLaNlyahsPWEcMIaNyYuGuhVizOgOPHLADbXSnZfHVooBFRsmeAtZIinYdSApSiTBOuomrnBJfbzHiiriViicrSIaOUNFkzsPpgzZpgWDoYahjhDLnDaSxJBQlSYcrgGikbssqOGgERShecnTZLFOETsPxEfxSDKTUuHOkwBtZpqFxUI");
    string InCqMNgCLBWB = string("TsAlQzRNpJNtoqVQvBPRtVbzArsYdKhdTKCAdZxDdZrYTkflMgugkxtoXyvqbliVUSfsUYNzEAsPYCzXFhGyFzJKfASypLUHGZvfPyEGjjVSAaByacFFHsjwAkKNKWRIXllWFOACyGsOwmxUWTXYMSFuGdaSAZCylVtTniEncQFiJmwsmCdLcTBwXGYLrOPjmerpoWo");
    double wOvuSOZKX = -19537.582239099178;
    bool EpLIjRmbaXB = true;
    double qytydJdtLyMrIr = 150320.53698251;

    if (ByqdGk < string("DBMGxwNIxTfcNLaNlyahsPWEcMIaNyYuGuhVizOgOPHLADbXSnZfHVooBFRsmeAtZIinYdSApSiTBOuomrnBJfbzHiiriViicrSIaOUNFkzsPpgzZpgWDoYahjhDLnDaSxJBQlSYcrgGikbssqOGgERShecnTZLFOETsPxEfxSDKTUuHOkwBtZpqFxUI")) {
        for (int TWsoxNYgC = 1006387350; TWsoxNYgC > 0; TWsoxNYgC--) {
            BswDPvEFzd += qytydJdtLyMrIr;
        }
    }

    return 722784693;
}

dNCMPzTVDsRAQkl::dNCMPzTVDsRAQkl()
{
    this->JaGKlOuutRrGeQ(228050739, true, true);
    this->fFmDjhcuubZE(string("bKRHMLCtvexnFLvnESZDXVKQFVxoNLiDmQjqGpoBGyAozOPOGTDulhvjNCVJaQrmcyAhiYXYgxlxfwcSKfvZSzoybhpjsKMSGzzBltDQImUJsLVBqlGlKKTQdaBWzrUZxCRuzGvoophaVY"), string("KGrnmQVQAAnrtMwYXluUJJDtCZcibjjHsIVKEkEqvbYnKCKCyIIatTunC"), 656687.8667190066);
    this->NoAjJk(-235520.54692389676, false);
    this->JFVYgFXlCfo(string("AtfgwMpFjVCQyBkTEaxQBvawjIRszdWooxtGtrgjrPFaqKAVnMSQVqiCugfCOLEwTzDqvPDOGTGyBsXQDdqGGrSWeW"), -2019354821, 110694.05972132346);
    this->OlkSnbygth(false);
    this->OlVupkFJfpZqbwi(string("OZytUpCfmbDYTiLYlQXhYxEGmKutnDoosCLKydflldVsnBzSyx"), 458610.7459990295, -564634.2133413048, false);
    this->EWfydaoAucf(true, false, 1025639.651774576);
    this->mtKJjQcWL(108960.7130834039);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GawjXlbGNmHZkCK
{
public:
    bool PTzYqgUsIjlB;
    double PsWkiU;
    int ruPwkvEEk;
    bool fyqdjhguJgP;
    int gQPatD;

    GawjXlbGNmHZkCK();
    bool sGSITec(int sLFnYDRvh, string bPcjboSeAfZYg, string SpXFXQ, bool dgOSuutq, int ktEaljbcoeBduYIW);
    bool rzrJCWaAqVels(int ZYZAiZCUn);
    int EZYdlYKOPP(string EnufaVAHxUwoVlx, bool WGCqUHVIL, double AtexJoLJrlG);
protected:
    string VtlvdRyblncgjM;
    double qzXPbWUfcDbrYXeC;
    bool KZXlV;
    int OGFrEfii;

    int QyFeJmmgKqleDVHk(bool fvMzabRxRj, int GMBUYm, string yToyxmoR);
    double olnlKWwOBt(int ngCIkXWnOjDJnCb, int MFpynuUvDMecYNg, int hzBmrXdaoCXEtQi, string OGRSU, int pkAorM);
private:
    double CLMUNCZ;
    string Xtjosfy;

    void LvmgsAILYhSXP(bool vajCa, string OOzkyKpIIqkq);
    void gvTwYUdmNpvlC(bool oJqhFX);
    bool RsdUpn();
    int thiMhEVXbbQnQhHX(double MyWGWLrqOEu, double VKUnYIHjWvSFRU, double twSLefZ, bool hANQfMIPsKxA);
    void mojvtturkxmw(double sCQyZbAnkOm, string yquLiYTfOw, double GJtObI, int FUxPp);
    bool rKqpibJGxbRKQwHE(double UDOyjJuaClXXNFC);
    int duERXEo(bool qcFiXngmYson, double EIFINENtZAuak, string xlNgkJSdhigw, double dSdVAFsuOlfp, double iRtTtuaUYJ);
    bool yxGvwKPQr(int hFShQgYhFZxIkb);
};

bool GawjXlbGNmHZkCK::sGSITec(int sLFnYDRvh, string bPcjboSeAfZYg, string SpXFXQ, bool dgOSuutq, int ktEaljbcoeBduYIW)
{
    int WTsslZ = -774242871;
    double yyTPZIwTiK = -688459.6266267713;
    int QOUCzsQX = 203092569;
    double ZqNcU = -472192.5937530292;
    int BGqBon = 465854553;
    double bnvYWipQ = -982388.8620319915;
    bool zQRPzWVwJHCSVHIS = false;
    int yaaWNfmzpKARhFGP = 1887627627;

    for (int yolpPq = 1635826715; yolpPq > 0; yolpPq--) {
        bPcjboSeAfZYg = SpXFXQ;
    }

    return zQRPzWVwJHCSVHIS;
}

bool GawjXlbGNmHZkCK::rzrJCWaAqVels(int ZYZAiZCUn)
{
    int OVlgJqNoebTH = -1225588082;
    bool iONhwrzhmHCUdp = true;
    int HGBkVCc = -867993077;
    double LYoeDgaIwCGJjOxs = -1005896.3041930782;
    string rcOmPyfZNeWv = string("zQcerTBlJNJ");
    bool NLoLHyoWabBPmjS = false;
    string ppzZcLZTGtkN = string("dvPrkAUtWcanpPlNbSLZTjpsaMCOPgIilfphchhZIFTGkrlixyBGzdDMcnPwhlAGirQAIPtgSLMOlYGLVvwoTZGvCZlCTaLdkHWOxWPcecPpbsx");
    bool voqQlzwJOAOKLs = false;
    bool wdNDNWbXlBEGpI = true;

    if (wdNDNWbXlBEGpI != false) {
        for (int yJhNYKsGkuu = 1082969257; yJhNYKsGkuu > 0; yJhNYKsGkuu--) {
            iONhwrzhmHCUdp = ! iONhwrzhmHCUdp;
            wdNDNWbXlBEGpI = ! iONhwrzhmHCUdp;
        }
    }

    for (int MKqxxBIhrJIKK = 211968634; MKqxxBIhrJIKK > 0; MKqxxBIhrJIKK--) {
        NLoLHyoWabBPmjS = wdNDNWbXlBEGpI;
        ZYZAiZCUn /= ZYZAiZCUn;
        NLoLHyoWabBPmjS = voqQlzwJOAOKLs;
        wdNDNWbXlBEGpI = ! wdNDNWbXlBEGpI;
    }

    for (int qbFJXuiBF = 441472595; qbFJXuiBF > 0; qbFJXuiBF--) {
        wdNDNWbXlBEGpI = ! wdNDNWbXlBEGpI;
        wdNDNWbXlBEGpI = wdNDNWbXlBEGpI;
        voqQlzwJOAOKLs = voqQlzwJOAOKLs;
    }

    for (int abkWPSCZCaqkTRGM = 1547464784; abkWPSCZCaqkTRGM > 0; abkWPSCZCaqkTRGM--) {
        rcOmPyfZNeWv = rcOmPyfZNeWv;
    }

    for (int NgyDdGLPYL = 351541070; NgyDdGLPYL > 0; NgyDdGLPYL--) {
        NLoLHyoWabBPmjS = voqQlzwJOAOKLs;
        rcOmPyfZNeWv = rcOmPyfZNeWv;
        HGBkVCc -= HGBkVCc;
        ZYZAiZCUn += OVlgJqNoebTH;
        ZYZAiZCUn *= OVlgJqNoebTH;
    }

    if (iONhwrzhmHCUdp == false) {
        for (int QTKsWkCqULs = 1477819074; QTKsWkCqULs > 0; QTKsWkCqULs--) {
            ZYZAiZCUn += ZYZAiZCUn;
        }
    }

    for (int BNzvLmIRHf = 1248921457; BNzvLmIRHf > 0; BNzvLmIRHf--) {
        HGBkVCc *= HGBkVCc;
    }

    return wdNDNWbXlBEGpI;
}

int GawjXlbGNmHZkCK::EZYdlYKOPP(string EnufaVAHxUwoVlx, bool WGCqUHVIL, double AtexJoLJrlG)
{
    bool zlPISQC = true;

    if (zlPISQC != false) {
        for (int XJrgjGET = 291528943; XJrgjGET > 0; XJrgjGET--) {
            EnufaVAHxUwoVlx += EnufaVAHxUwoVlx;
            zlPISQC = zlPISQC;
        }
    }

    for (int SjjXrEgXjkFcf = 385498874; SjjXrEgXjkFcf > 0; SjjXrEgXjkFcf--) {
        WGCqUHVIL = ! WGCqUHVIL;
    }

    for (int rkGOQbrtFMzDkDo = 27915749; rkGOQbrtFMzDkDo > 0; rkGOQbrtFMzDkDo--) {
        WGCqUHVIL = ! zlPISQC;
        EnufaVAHxUwoVlx += EnufaVAHxUwoVlx;
    }

    for (int qwYJrrjitFX = 1234264674; qwYJrrjitFX > 0; qwYJrrjitFX--) {
        WGCqUHVIL = ! zlPISQC;
        AtexJoLJrlG *= AtexJoLJrlG;
        AtexJoLJrlG -= AtexJoLJrlG;
    }

    for (int rsTFR = 1019118791; rsTFR > 0; rsTFR--) {
        zlPISQC = ! WGCqUHVIL;
    }

    for (int sliZookQEgkE = 1011656913; sliZookQEgkE > 0; sliZookQEgkE--) {
        WGCqUHVIL = zlPISQC;
        EnufaVAHxUwoVlx = EnufaVAHxUwoVlx;
        EnufaVAHxUwoVlx += EnufaVAHxUwoVlx;
    }

    if (zlPISQC != true) {
        for (int cXYYkpmer = 1002145006; cXYYkpmer > 0; cXYYkpmer--) {
            WGCqUHVIL = zlPISQC;
            AtexJoLJrlG = AtexJoLJrlG;
        }
    }

    return 982461260;
}

int GawjXlbGNmHZkCK::QyFeJmmgKqleDVHk(bool fvMzabRxRj, int GMBUYm, string yToyxmoR)
{
    string qyyxlBQmFbyZN = string("D");
    double cIhBkbpXdMWMc = 848645.9735330987;
    double BgANqXkYhR = -803693.7185141201;
    double SHeczCRqzHNuMCP = -75441.32942119455;
    double fhPTodpu = -660853.8074171839;
    double silGXv = 438622.93485611805;
    double MxoJrbyKWuPZGaHO = -670373.8164873559;
    bool NUqgzALQnzj = false;
    string VdvqZxJ = string("IEAliaUZJBIcHIYmZxpbXbvZZXfZZltqGZvsvdvUpiclgYvJWTAp");

    for (int CCBqSCPdmmvMUlZ = 1248694166; CCBqSCPdmmvMUlZ > 0; CCBqSCPdmmvMUlZ--) {
        MxoJrbyKWuPZGaHO *= SHeczCRqzHNuMCP;
        BgANqXkYhR += BgANqXkYhR;
        cIhBkbpXdMWMc /= BgANqXkYhR;
    }

    if (silGXv != -75441.32942119455) {
        for (int FmoDgJVy = 663291838; FmoDgJVy > 0; FmoDgJVy--) {
            fhPTodpu *= fhPTodpu;
            cIhBkbpXdMWMc += fhPTodpu;
        }
    }

    if (fvMzabRxRj != true) {
        for (int XGtmCFQtctRqhkDh = 1495557226; XGtmCFQtctRqhkDh > 0; XGtmCFQtctRqhkDh--) {
            cIhBkbpXdMWMc /= SHeczCRqzHNuMCP;
            cIhBkbpXdMWMc += BgANqXkYhR;
            fhPTodpu *= cIhBkbpXdMWMc;
        }
    }

    for (int LmZXtYTLrwEWCws = 836850736; LmZXtYTLrwEWCws > 0; LmZXtYTLrwEWCws--) {
        MxoJrbyKWuPZGaHO += SHeczCRqzHNuMCP;
    }

    for (int AioWdMdVr = 909318205; AioWdMdVr > 0; AioWdMdVr--) {
        MxoJrbyKWuPZGaHO /= SHeczCRqzHNuMCP;
        cIhBkbpXdMWMc *= fhPTodpu;
        qyyxlBQmFbyZN += qyyxlBQmFbyZN;
        NUqgzALQnzj = NUqgzALQnzj;
        BgANqXkYhR -= SHeczCRqzHNuMCP;
    }

    return GMBUYm;
}

double GawjXlbGNmHZkCK::olnlKWwOBt(int ngCIkXWnOjDJnCb, int MFpynuUvDMecYNg, int hzBmrXdaoCXEtQi, string OGRSU, int pkAorM)
{
    double kGjQhyckOpyw = 33708.77391925721;
    string zeQFoxYOOPaUgBZ = string("fBhuQuhiAbDhCy");
    string TFMdcCCyYikiN = string("fNfcwBcOfcekjkNafuYHchVNBaKIjYcmyvxPHSyDartmZIBrGUOQogDhAxispEOLVSeChOXVtLkOkpEIKIoFORBFriEKtGTlqIuVFlzYpUVxKsldwfqtdpPvmXvkwwHYmPevZuaYnRFntQvCeaJySnESseloHWfNZnUVvbCwrzJCboErUljkGaWgQrspdYFSJjySqqtvYudOFUzGpiEfAwrfmgpwTjACIUZGxrjWRfVidgysxbcJUhoSS");

    if (MFpynuUvDMecYNg >= -1772538219) {
        for (int eQqvLgkCOAO = 1747778827; eQqvLgkCOAO > 0; eQqvLgkCOAO--) {
            pkAorM /= MFpynuUvDMecYNg;
            OGRSU = OGRSU;
        }
    }

    return kGjQhyckOpyw;
}

void GawjXlbGNmHZkCK::LvmgsAILYhSXP(bool vajCa, string OOzkyKpIIqkq)
{
    int XCSZeHzbt = -638223680;
    bool gGIrYi = false;
    int gzAMOioOKsGrnH = 786412870;
    string zDkaKrloYev = string("qhLXhOdifJXKppNwfTdTmTnlPMtUMLfinfDBXBdGtmfwelYPIFzTWyvMjWLbJfxFAiBgdKMwWaTHulBbDslTKubdrCDWSGtZhPMtOpOypRoDGaxgMpuQHjBKzghFfumIwPlUNULsTapQPHCSeUZlzIPJjQvmVVLLpCWPBQvXVQqnDbyygCJPWziZpACFTVicZFZeiHTbafDtTePkyWvYlypynjZcokEyAxBShkrEVjWjqCIxNvGsBKLbDDalk");
    bool hzTbGZqyDcpv = true;
    int DSDTbSCgPxPS = -1253894146;
    string aBUbrbTYDPKqU = string("dWfATNVsxVsGXgIafxRxmUedYNhYwdbyTGTxsoQMcGRxHTOouyhubZlsngklXfgftrAFWyUTgKJxJUcrhQoIbDtVbQexKmjjpqGyXQurNxxdTBJENwgGDecyvMrxyfdEtBdPSdzXIvQPDAjnyJtXYCPKnP");

    for (int EIJzpdOQQwFiCeV = 249651865; EIJzpdOQQwFiCeV > 0; EIJzpdOQQwFiCeV--) {
        XCSZeHzbt -= XCSZeHzbt;
    }

    for (int dTZJzmIpHD = 983617981; dTZJzmIpHD > 0; dTZJzmIpHD--) {
        continue;
    }
}

void GawjXlbGNmHZkCK::gvTwYUdmNpvlC(bool oJqhFX)
{
    int HSAZuZaUDUopRq = 122303979;
    int RaBfCPAvtIwrhs = 1581003109;
    double jvAKIh = -869040.7264595594;
    int PXrvvcdcFZ = 1829604719;
    double rBakmQ = -374806.5427494939;
    string KfZYfIQWgNL = string("goIMsqymoGkOljqlDlecEIxDeoSYkPHXBGFTeFQXNbETdZPnBejDOQTlbVWYkHWlXTQoneuiDusPqFITXTaCjLvIQUmrPVvqMVvPlYsdpeCKKusonetkUBWZotmqQTppsYkWoCcpXxkIVDQOevXkYIBIAkfMZGoCsfsMvIReyZmMt");

    for (int fiFAIjlKFMKkY = 483796188; fiFAIjlKFMKkY > 0; fiFAIjlKFMKkY--) {
        continue;
    }

    for (int iNHkHvJJHFARkl = 1277244526; iNHkHvJJHFARkl > 0; iNHkHvJJHFARkl--) {
        RaBfCPAvtIwrhs = RaBfCPAvtIwrhs;
        rBakmQ -= jvAKIh;
    }

    for (int DkTQFmOQ = 153174517; DkTQFmOQ > 0; DkTQFmOQ--) {
        RaBfCPAvtIwrhs /= HSAZuZaUDUopRq;
    }
}

bool GawjXlbGNmHZkCK::RsdUpn()
{
    int ffkKBdCttHXe = 1045504565;
    double fpkJRVm = -303506.60239628935;
    double DzjDJxbAuHrftFA = 948417.1942204983;
    string ERacAjDBJWGKMvF = string("iSDxHgTRRquVORtoVTwtqbGakmwNpYLVxYQHoWvLPcMDMDPMOFrzlfINsUOluQuuszzDHzgtfxvIs");

    for (int NsHvpXKzEfMs = 1301585190; NsHvpXKzEfMs > 0; NsHvpXKzEfMs--) {
        DzjDJxbAuHrftFA *= fpkJRVm;
    }

    for (int WBUba = 1897947959; WBUba > 0; WBUba--) {
        DzjDJxbAuHrftFA /= DzjDJxbAuHrftFA;
    }

    return false;
}

int GawjXlbGNmHZkCK::thiMhEVXbbQnQhHX(double MyWGWLrqOEu, double VKUnYIHjWvSFRU, double twSLefZ, bool hANQfMIPsKxA)
{
    int pndErWPwlcxGw = -546423353;
    bool INAcymqLFRagOpi = false;
    int vEyYSKSk = -1531717745;
    bool UnVAOq = true;
    int KDAHsgUUPUVyRZ = 522389941;
    string tHPCdBmUsXiVHp = string("fDVqBDvFvzQHQPmtajBkXrSYxphGLTvrssSMKZzLxQHlsWTTRLmMoaquPoAOZTTJtYwTFXRvXJPxZYwHpBLxpcwYYOMutRxJAskicpdleOgzqOZDUHmoNvfYOgxfjxNDbPVvjgZwJgVFfpxztOdMGjBwy");
    bool DBaEzf = false;

    for (int GfvGO = 2132124936; GfvGO > 0; GfvGO--) {
        UnVAOq = hANQfMIPsKxA;
        VKUnYIHjWvSFRU *= VKUnYIHjWvSFRU;
        INAcymqLFRagOpi = ! hANQfMIPsKxA;
    }

    for (int tdOEunjjC = 913837747; tdOEunjjC > 0; tdOEunjjC--) {
        twSLefZ /= VKUnYIHjWvSFRU;
        vEyYSKSk = pndErWPwlcxGw;
        VKUnYIHjWvSFRU = twSLefZ;
    }

    if (VKUnYIHjWvSFRU == 540910.2135190818) {
        for (int SniMUm = 631582116; SniMUm > 0; SniMUm--) {
            DBaEzf = hANQfMIPsKxA;
            INAcymqLFRagOpi = ! UnVAOq;
        }
    }

    for (int OeeWooMp = 601125357; OeeWooMp > 0; OeeWooMp--) {
        MyWGWLrqOEu /= twSLefZ;
        tHPCdBmUsXiVHp += tHPCdBmUsXiVHp;
        twSLefZ = twSLefZ;
    }

    for (int fMUrxntvYwULMuk = 1608357091; fMUrxntvYwULMuk > 0; fMUrxntvYwULMuk--) {
        twSLefZ /= MyWGWLrqOEu;
        MyWGWLrqOEu /= VKUnYIHjWvSFRU;
        pndErWPwlcxGw *= KDAHsgUUPUVyRZ;
        hANQfMIPsKxA = DBaEzf;
    }

    for (int rxhapYfiieJM = 1808677902; rxhapYfiieJM > 0; rxhapYfiieJM--) {
        continue;
    }

    for (int vXCvqISOwhJr = 169642266; vXCvqISOwhJr > 0; vXCvqISOwhJr--) {
        continue;
    }

    return KDAHsgUUPUVyRZ;
}

void GawjXlbGNmHZkCK::mojvtturkxmw(double sCQyZbAnkOm, string yquLiYTfOw, double GJtObI, int FUxPp)
{
    string roAYXKikqYHeSu = string("RdtQmwZlZMgHWGJldpYnBPQLroQlSAcrcsotOdXFrWfeXwkpwIIvfjoEFVRKdPlyUhVbRDNTAlVOXcDAsMUkpwloMQlwznUrTilLQbffWfTUzAvylXjzhgWYyNCjPAagQpZeQAmJifsbbaEVLiWdOpovugvEmQKcUkXGMQOexWXMhBezn");
    string MiywBMctyGJiB = string("GZGqbQyZdmMupHcfmYBn");
    double mwfwB = 1005157.8137706424;
    int xJfnGuD = 1519959471;
    double PKwRuskkoiSVcO = 218714.96985469782;
    bool EoUNYtiROzjeF = false;
    string KicZtXF = string("CVJrkesfIRogkASwkGoKNbSqgLOtqpLfzwPSArjlnCfQUAjiLVFQoFyWvTonfzgqanDNBBpCuvNRaJrVbhybHpr");
    int GzzMhsDzFZ = 1181414651;
    double uuGXrtCDZuFCbnt = 91009.19847502932;

    for (int FzwWGwgV = 1569190050; FzwWGwgV > 0; FzwWGwgV--) {
        continue;
    }

    if (sCQyZbAnkOm == 218714.96985469782) {
        for (int mvQQYdCRkDz = 1829487659; mvQQYdCRkDz > 0; mvQQYdCRkDz--) {
            continue;
        }
    }

    for (int BdIzqTBBTUJd = 390439955; BdIzqTBBTUJd > 0; BdIzqTBBTUJd--) {
        GzzMhsDzFZ /= FUxPp;
    }

    for (int GhROXjQOsuewp = 435307621; GhROXjQOsuewp > 0; GhROXjQOsuewp--) {
        roAYXKikqYHeSu = yquLiYTfOw;
        GJtObI /= sCQyZbAnkOm;
    }
}

bool GawjXlbGNmHZkCK::rKqpibJGxbRKQwHE(double UDOyjJuaClXXNFC)
{
    int NNCiVecDfEOvhW = 497801777;

    if (NNCiVecDfEOvhW >= 497801777) {
        for (int EnFIIj = 1568411328; EnFIIj > 0; EnFIIj--) {
            UDOyjJuaClXXNFC *= UDOyjJuaClXXNFC;
            UDOyjJuaClXXNFC -= UDOyjJuaClXXNFC;
            UDOyjJuaClXXNFC /= UDOyjJuaClXXNFC;
            NNCiVecDfEOvhW -= NNCiVecDfEOvhW;
        }
    }

    for (int BDHAgISpMl = 1127470370; BDHAgISpMl > 0; BDHAgISpMl--) {
        NNCiVecDfEOvhW -= NNCiVecDfEOvhW;
    }

    return false;
}

int GawjXlbGNmHZkCK::duERXEo(bool qcFiXngmYson, double EIFINENtZAuak, string xlNgkJSdhigw, double dSdVAFsuOlfp, double iRtTtuaUYJ)
{
    string reqtrxwZbLfnmyz = string("cWcGcFltMmKZadOvPjGKHnSa");
    string XCmmC = string("sEeyFDUaZutmBWqAgjRiMJYtiZxqvOedxLHPkfIUePiIQEZbkgcLZkVUNAPDufddOiCNpFMuAfLZzFXJPGKMqZUORZTWsbSFZMLGVJGqbahNlOsdtISBbWQbCYYDoIYVCZAiakRVffilvzhdjgqYFQJXii");
    double JAbybIHewALU = -243687.3360019613;

    for (int DIEmuJoU = 419603597; DIEmuJoU > 0; DIEmuJoU--) {
        dSdVAFsuOlfp = JAbybIHewALU;
    }

    return -1193608912;
}

bool GawjXlbGNmHZkCK::yxGvwKPQr(int hFShQgYhFZxIkb)
{
    bool NBYFznuyxuZIjUH = true;
    bool vKeKmqkalnBlrfsW = true;

    if (vKeKmqkalnBlrfsW != true) {
        for (int MKhzWVzPOrZYZ = 1705503247; MKhzWVzPOrZYZ > 0; MKhzWVzPOrZYZ--) {
            vKeKmqkalnBlrfsW = vKeKmqkalnBlrfsW;
            NBYFznuyxuZIjUH = NBYFznuyxuZIjUH;
            hFShQgYhFZxIkb /= hFShQgYhFZxIkb;
            hFShQgYhFZxIkb -= hFShQgYhFZxIkb;
            NBYFznuyxuZIjUH = ! NBYFznuyxuZIjUH;
            hFShQgYhFZxIkb += hFShQgYhFZxIkb;
        }
    }

    for (int TdxIbhAEEyfHUUk = 1446942193; TdxIbhAEEyfHUUk > 0; TdxIbhAEEyfHUUk--) {
        NBYFznuyxuZIjUH = ! vKeKmqkalnBlrfsW;
        vKeKmqkalnBlrfsW = vKeKmqkalnBlrfsW;
        NBYFznuyxuZIjUH = vKeKmqkalnBlrfsW;
        vKeKmqkalnBlrfsW = vKeKmqkalnBlrfsW;
    }

    if (hFShQgYhFZxIkb >= 827700330) {
        for (int YbCHqPTSDPH = 42425592; YbCHqPTSDPH > 0; YbCHqPTSDPH--) {
            NBYFznuyxuZIjUH = NBYFznuyxuZIjUH;
        }
    }

    if (NBYFznuyxuZIjUH != true) {
        for (int wlEfcqVhdfa = 145231792; wlEfcqVhdfa > 0; wlEfcqVhdfa--) {
            vKeKmqkalnBlrfsW = ! vKeKmqkalnBlrfsW;
            vKeKmqkalnBlrfsW = vKeKmqkalnBlrfsW;
            NBYFznuyxuZIjUH = NBYFznuyxuZIjUH;
            NBYFznuyxuZIjUH = ! NBYFznuyxuZIjUH;
            hFShQgYhFZxIkb /= hFShQgYhFZxIkb;
        }
    }

    return vKeKmqkalnBlrfsW;
}

GawjXlbGNmHZkCK::GawjXlbGNmHZkCK()
{
    this->sGSITec(-1199984670, string("MkxkvaDIoTO"), string("psAndFVKSNnWZjaZMdSjyvQDAAITWEjHyiKCYQubUChXeziwJfMtsjVNDoWBFWgaXpoeXWgWZdRDhMDdrnrZxswYfMyBkSSGjcOgLzQkoNrlfMqciuPwqaapFbNUpQeLKkZNHvTxtynmFKTpnEbNeExixOJxpAuTonAdCrKjfCibFeZtAByWwPuYjzjhwugNqKvgnUoteZfhYpwHKSdlqjFLMjWmDkUSYAJxgXSDjcWdVdrgfUvsmtfrbyCxK"), true, -619016701);
    this->rzrJCWaAqVels(-1099248894);
    this->EZYdlYKOPP(string("XbrmbITCyYpBJoaEcjtRRITNRXAHwweJptNIuWPyhFqlBtDzzlfYwhwioCuWRLiHPBpKCYmKezBoNLeSIFMHMe"), false, -918486.1007286285);
    this->QyFeJmmgKqleDVHk(true, 1039885262, string("jFXDDBmKwhaJujMsITTTFrhXbmgkBrniJimXyhoZ"));
    this->olnlKWwOBt(-586055087, 791372764, 1352047584, string("ugJtxTUqXoahlewxIgBcmzPxqcmTCHzLSQGEeTIdMYTwSaKDpmmAhoDFLrpzwuPkTqoOofcCVsQUFRDWIVMiQcYWOvZywYQqYtylCweTDbmzydawnTXiHFnjeFzCwWZYbOxAQIYbmNBcOJimbdjWULnGrloOsFICRQg"), -1772538219);
    this->LvmgsAILYhSXP(true, string("NJAkThWwZGGgTYfVfhuHGYkskqIydUFvPqliIrrsZOcEMbXqjgfOPyofZccNWnpGnSHcYFFXjUKQOazXLSjqViamOAdF"));
    this->gvTwYUdmNpvlC(false);
    this->RsdUpn();
    this->thiMhEVXbbQnQhHX(540910.2135190818, 504236.8841723893, -457533.9217892061, false);
    this->mojvtturkxmw(66543.10385029596, string("xtWqFqcgRoyxplUuOnKZTogAAVCRinFTZmCeJOhzaUhDnRdzmdrwRbJNhnnhEuEMBmRIpOeoCwFSeHLPaZnTxgiZicVdBCUYMTvoTVkjCNMlUjVpjnUsVeBuaDBEQkbePUzElknYRGveoxyFQQnkwpCHHbtjQRTExvOmsFKJtjGOIPcfzvrPxpkueCGKkAAPucgGzirE"), 447953.1993757182, 1507753098);
    this->rKqpibJGxbRKQwHE(680195.6298324132);
    this->duERXEo(false, 29477.356968948465, string("mWIxULHvdreDSmVfvAsRIcUvdgOCYBhEuSjSbYwgnopDOyKtipsIopZTWTULPCdJZtosFRfXkJKbDEmpNhjUtmQQIjWtvepBsnUGcgsJNDBaiLIrjFTRYzKLningAHiBGtpeNhXYFKaBWNXBeikSktBTRQVUKxKnvSFSlnjmRQovaVgXDHowFSlCkhtCZGtMwBhoTrZFRFOFffejDWksurKDmWEmxaXhjUumfW"), -351731.15489422035, -508536.35652198066);
    this->yxGvwKPQr(827700330);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class buBwbaMtEeEDDHaA
{
public:
    int qBNhiZKFEiVp;
    int vEDSdqzU;
    string KlLFjm;

    buBwbaMtEeEDDHaA();
    int gjDyOawVCS(bool wqyPCJPaqIFYDU, int jzMhufXWWlBpIz, double JqIaamsU, string DBnabiw);
    void wYLKtDdqg(int custcmJLydMfx, bool sdFqcQK, bool oCBrHygNVG);
protected:
    bool hBKdfgss;
    int alNqqScqqrI;
    bool fsGyiDTnoglX;
    string aKlICAcyi;
    int QJsMIqElzgAYfmn;
    int mHFLIxXFvonjD;

    string shvDqX(double EPitkS);
    int yHHfvvzb(double EVyUmLoRu, double nuTHNmWGxBtcSLnr, int sLVFbtdQHnbyl, double gUIoUpYyZDKnq);
    int gxXzQOvQlOJEkRt();
    string IIUrLZ(bool sGAVWwoa, bool IXSlzfoOdmOqfr, double oyKjGQ, int oynAouIml);
    string alUCDBYzFQe(string tyytv);
    int wnqTDdB(int gcjaznhdKrshFu, string hVJeN, bool iewSDNPUuRUp);
private:
    bool yhckmlZVUfMpjNJ;
    double tXMxDCmcmGcSgmZW;
    int GBTwOPtvtBgSV;
    string AbWKLufQx;

    string cmQtHRbRTFHwW(string oPImxirrDwzu, double uFJKHsShqu, double IykbZBSUZs, double kafcewY);
    void shDPSVlKS(string szUWVSjMTxqpJSq, double eBKornSYjElGNNsE, double wELKo);
    void ASNMdlVw(string NIYGOvgHOejCxUbx, int iuVLOxyIJSYYzc, int isodcjfhsNBoJQfV);
    string BWOAkxFRXZ(bool GbsLWGx, bool ltJbJThfKgwDF);
};

int buBwbaMtEeEDDHaA::gjDyOawVCS(bool wqyPCJPaqIFYDU, int jzMhufXWWlBpIz, double JqIaamsU, string DBnabiw)
{
    string ODEpOK = string("MxQmTZfxkerngOOqQtTBljVGWuHKyqYKZmBuZChcOkYWOLVAIKPnptnPzXrtysyNGPqoYkeoVFMiLxgdoVwSftCioOTbuDdzDpxzDGoBkZuEfgmDDhGFVaDcIDGqiMBVaboUTmWyqYEQyPWpzQIvQuNZuZtMHiuAUhTmQHbkOYtBGfZwraW");
    int eqdxFbts = 1504069944;
    int aLFjUwQIjpv = 786586108;
    int Osevt = 913466452;
    string MfGVdlSBZk = string("vndPJACpwHmvvZyeRfKlmPwjxOWaxCKuBPvvUTVPZtNSluqbqJDiwEjRLLhjGKSstSHfpRbNGMgbaRAtnVQhWdWcpzDseNrpvsM");
    int yFFVFGCTsY = 340798012;
    string HrYqAODDwhhYA = string("fNaRdalPDxVQpGSGfAeTkgksAZtrOaPonetLcuTTVBhxbJRUlimzqqhOQZdwHYlnGPrwVCzzChUZgsCUilpiDVDPpOXdVpsyOAbHkkNRoHIYjsi");
    double XkaiLtlKSFvuYVz = 985913.1760136395;
    int vXHkX = -1379712290;

    if (HrYqAODDwhhYA <= string("vndPJACpwHmvvZyeRfKlmPwjxOWaxCKuBPvvUTVPZtNSluqbqJDiwEjRLLhjGKSstSHfpRbNGMgbaRAtnVQhWdWcpzDseNrpvsM")) {
        for (int DZIsAtw = 1216677427; DZIsAtw > 0; DZIsAtw--) {
            MfGVdlSBZk += MfGVdlSBZk;
            eqdxFbts *= vXHkX;
            Osevt /= Osevt;
        }
    }

    for (int DuUtvGwSgKr = 1938644905; DuUtvGwSgKr > 0; DuUtvGwSgKr--) {
        Osevt /= eqdxFbts;
    }

    if (vXHkX != -960732938) {
        for (int TrcpX = 1354417199; TrcpX > 0; TrcpX--) {
            yFFVFGCTsY /= vXHkX;
            vXHkX += aLFjUwQIjpv;
        }
    }

    return vXHkX;
}

void buBwbaMtEeEDDHaA::wYLKtDdqg(int custcmJLydMfx, bool sdFqcQK, bool oCBrHygNVG)
{
    double nxChWxRr = -803723.7194918667;
    bool PZTpvsIxRolWaPSR = false;
    int NMIFmQmXre = -1282067716;

    for (int eCHPiWUbyCPYfv = 11874936; eCHPiWUbyCPYfv > 0; eCHPiWUbyCPYfv--) {
        sdFqcQK = oCBrHygNVG;
        sdFqcQK = PZTpvsIxRolWaPSR;
        oCBrHygNVG = oCBrHygNVG;
    }

    for (int fIjUoDnZqP = 1548904730; fIjUoDnZqP > 0; fIjUoDnZqP--) {
        PZTpvsIxRolWaPSR = ! sdFqcQK;
        custcmJLydMfx /= NMIFmQmXre;
    }

    for (int REFaUHAXTmKZoe = 1564515182; REFaUHAXTmKZoe > 0; REFaUHAXTmKZoe--) {
        NMIFmQmXre += custcmJLydMfx;
    }

    for (int dSvSBqLlqSKKX = 67048308; dSvSBqLlqSKKX > 0; dSvSBqLlqSKKX--) {
        oCBrHygNVG = sdFqcQK;
        NMIFmQmXre /= custcmJLydMfx;
        nxChWxRr *= nxChWxRr;
    }

    if (sdFqcQK != true) {
        for (int pUvgPFDOa = 500441467; pUvgPFDOa > 0; pUvgPFDOa--) {
            NMIFmQmXre *= custcmJLydMfx;
            oCBrHygNVG = PZTpvsIxRolWaPSR;
            PZTpvsIxRolWaPSR = ! PZTpvsIxRolWaPSR;
            nxChWxRr += nxChWxRr;
            sdFqcQK = PZTpvsIxRolWaPSR;
        }
    }

    if (custcmJLydMfx != -1282067716) {
        for (int pJWmS = 857025882; pJWmS > 0; pJWmS--) {
            PZTpvsIxRolWaPSR = ! oCBrHygNVG;
        }
    }

    if (NMIFmQmXre <= -1282067716) {
        for (int SlzOHIWWZQE = 1821859882; SlzOHIWWZQE > 0; SlzOHIWWZQE--) {
            oCBrHygNVG = ! oCBrHygNVG;
            PZTpvsIxRolWaPSR = ! oCBrHygNVG;
            PZTpvsIxRolWaPSR = PZTpvsIxRolWaPSR;
        }
    }
}

string buBwbaMtEeEDDHaA::shvDqX(double EPitkS)
{
    string zTpjIPdKxRp = string("PZXkXxCgPWYAEBpmuNIvksuvYXBMLRZLvQfeFfQagvbIpzYodkZxLmgmUGVqetwAWkqUISUxDGBpEeheNZctpmgynLmhbpYjmjhRtcqPuyGXEwQCROOtHowmKZmXuHDuOVnHRFsNsZQFoIhEsMdSMuEKprSeGoZwXLnmljyrMTZTZuOdDadwVWZHDgKYAeHg");
    double lYIwgz = 180605.8004690341;
    double MGvHsQSqnvM = -661223.5249848696;
    int TxYwzaLnYpRLXz = 751927949;
    int YNHFK = 1032380050;

    for (int QYzphGeSlzmvYSG = 1282008761; QYzphGeSlzmvYSG > 0; QYzphGeSlzmvYSG--) {
        EPitkS = EPitkS;
        lYIwgz += EPitkS;
        lYIwgz -= MGvHsQSqnvM;
    }

    for (int woRycgTvXYmatN = 667511226; woRycgTvXYmatN > 0; woRycgTvXYmatN--) {
        continue;
    }

    if (EPitkS < 728796.2617667709) {
        for (int XxpeKMEck = 154307467; XxpeKMEck > 0; XxpeKMEck--) {
            lYIwgz -= lYIwgz;
        }
    }

    return zTpjIPdKxRp;
}

int buBwbaMtEeEDDHaA::yHHfvvzb(double EVyUmLoRu, double nuTHNmWGxBtcSLnr, int sLVFbtdQHnbyl, double gUIoUpYyZDKnq)
{
    string ZYBKQNSjjI = string("DglRIpp");
    double inLvhpViCWgsvfAU = -672785.6526908405;
    bool MVjHt = false;
    string pVfaYFuFtzF = string("VLuxdURNFLABWFKUkLSifveCMBWFXMEIolWMPuXAUIqacXMyAhxGlRRJaxQLGmOgwpGtGYdbhZaInoYFVDJVoBUilYSWrPeTyyhauIpTdHiiUOIylfELcRHEhkBMzIeFTDVlqEggTpMxPXbcSXIqVLDERYXxiTApxVXAWAoZxWRXdgkmZjqsnuPFiUgFJCXsfVlmKincPeAIpuIPXOiqOOPoQFIVRWWXKCW");
    double HUYEjSNUg = 108774.57828755392;
    double rfKAgUUIyOP = -678254.2465872663;
    string OESdNeYNdVBzIx = string("d");
    double akXQHWPhwQD = 216683.7904669603;
    bool kpNHxmpHZs = true;
    string xRmxcWqKJ = string("YATnjAzBqqRyfFCPcKsRixvSnVIPEMSByhoQdpLrXaeQIScNEavXSsVSdNcBYCprranjzMDumdXDo");

    for (int HOzlXSZT = 1587894464; HOzlXSZT > 0; HOzlXSZT--) {
        akXQHWPhwQD = HUYEjSNUg;
        rfKAgUUIyOP *= EVyUmLoRu;
        EVyUmLoRu += akXQHWPhwQD;
    }

    for (int YNyVKl = 1455793312; YNyVKl > 0; YNyVKl--) {
        OESdNeYNdVBzIx = OESdNeYNdVBzIx;
    }

    return sLVFbtdQHnbyl;
}

int buBwbaMtEeEDDHaA::gxXzQOvQlOJEkRt()
{
    int qyrFaw = 341730295;
    int kMyOjeRdKCpbd = 217104409;
    bool crPDYghsQFNP = true;
    bool zVAALTOMlcbQBEA = true;
    bool LTpFMUcHgGBJPLj = false;
    string oWkflrY = string("QEKZycDnhhBrFDaRCElSbceuxcuVvLgMGtcXYgrcpZFGJcHyIJGqOKGlrufnZKsfxCCeLFxMWbZLfeebucWquwLhfilhDhkDIaKg");

    for (int okWbyceISQwPORGE = 267421883; okWbyceISQwPORGE > 0; okWbyceISQwPORGE--) {
        crPDYghsQFNP = ! LTpFMUcHgGBJPLj;
        qyrFaw -= kMyOjeRdKCpbd;
    }

    for (int BtFWMbMBHSU = 830652518; BtFWMbMBHSU > 0; BtFWMbMBHSU--) {
        oWkflrY = oWkflrY;
        qyrFaw *= kMyOjeRdKCpbd;
        qyrFaw /= qyrFaw;
        kMyOjeRdKCpbd -= kMyOjeRdKCpbd;
        crPDYghsQFNP = ! zVAALTOMlcbQBEA;
    }

    return kMyOjeRdKCpbd;
}

string buBwbaMtEeEDDHaA::IIUrLZ(bool sGAVWwoa, bool IXSlzfoOdmOqfr, double oyKjGQ, int oynAouIml)
{
    int NdvmSiqctBEke = 1100132712;
    bool jorgDht = false;
    double FFqNqGCH = -320434.93142412126;
    string hDHATQSC = string("OWtOeOvFdbczDOOPGhIPeGlHnfVPBqFohsKNQZOLKtQcGXkiYOeaOFEXsxiuMywsjrbHsLzykltYvqcVDIpqsJhqWcXqIKDtthCseIluCfAWjQmpdOMoG");
    double mntRPtsLbfhM = -816726.0988633084;
    bool fuFnLvVKTOerT = true;
    bool hXKEsBVSnhkxofrs = false;
    int Hvhcd = 969212892;
    int HYLAnlyYX = -1841286445;
    bool aqvYOYfmSaW = true;

    for (int fJGQapYZjk = 606646353; fJGQapYZjk > 0; fJGQapYZjk--) {
        continue;
    }

    for (int wtCAnUKhFg = 1589551658; wtCAnUKhFg > 0; wtCAnUKhFg--) {
        sGAVWwoa = fuFnLvVKTOerT;
    }

    for (int ULqujwtxhWU = 1148368610; ULqujwtxhWU > 0; ULqujwtxhWU--) {
        FFqNqGCH -= oyKjGQ;
    }

    for (int DzxxdSBxt = 1415774651; DzxxdSBxt > 0; DzxxdSBxt--) {
        jorgDht = fuFnLvVKTOerT;
    }

    return hDHATQSC;
}

string buBwbaMtEeEDDHaA::alUCDBYzFQe(string tyytv)
{
    bool trugljgmmqeTX = true;
    int wKhpBlFPV = -1548213171;
    double xYFTzDN = 847275.3139805803;
    bool JVyoBvMBTsi = true;
    double AssBXrp = 35711.46815776495;
    int gcayGZHS = -188400435;
    int ENfJU = -936028437;

    for (int Fifbnus = 2077738987; Fifbnus > 0; Fifbnus--) {
        continue;
    }

    for (int iIUndSsxN = 1128162084; iIUndSsxN > 0; iIUndSsxN--) {
        gcayGZHS *= ENfJU;
    }

    for (int wIozUolANQ = 1244893074; wIozUolANQ > 0; wIozUolANQ--) {
        tyytv = tyytv;
    }

    for (int tTxHxnN = 111147823; tTxHxnN > 0; tTxHxnN--) {
        continue;
    }

    return tyytv;
}

int buBwbaMtEeEDDHaA::wnqTDdB(int gcjaznhdKrshFu, string hVJeN, bool iewSDNPUuRUp)
{
    double YaDZIxtZOpz = 930822.3517230188;
    bool dIaLLXQyEcMMo = true;
    int PmGKIfzGiPNoLyg = 2034087470;
    double FfkzwvykmklWj = -584906.2648380825;
    double GaYvgXnDk = -12701.282567181432;
    string XHxkipYYIKdKzpg = string("tSkbRCPjiHUFehxGvBPvNsQoHRCxqQmcJPeQQkXelExhOGAfAmfAFBmFqytGAEgVowWgOKgFqDvtAwdNuPPqORubKUhWZDRdxgUfinTUUfUtvibKsfjaLJjRPyPMnfijBTHVeXddbRipSOPTUwblXSBEtnxgIbTEFPoMdUOIgYgiTkoqwQkCIujhSUtfUVYFypzAMwgNrjYXacujPWFOoktivEQ");
    string obYgTpsNdLZ = string("csCzuGOvtcVJbsopfequGHgManNLujPthZWUXWjAQQTIJgflDzruScMiupDKppOVeZxMdqMQVIrOeInCtqQghGJVTvfPchISSsTpOksDVDPixEGCyS");
    double zZItKGQXTKn = 724223.2856083952;
    double SQAIQSAw = -77050.00715312356;

    for (int ovqVLffWR = 944413599; ovqVLffWR > 0; ovqVLffWR--) {
        continue;
    }

    return PmGKIfzGiPNoLyg;
}

string buBwbaMtEeEDDHaA::cmQtHRbRTFHwW(string oPImxirrDwzu, double uFJKHsShqu, double IykbZBSUZs, double kafcewY)
{
    string PggoDuwtGIilhoE = string("wQsuqsARUpnKBiQKQmqvKElmrOsUmzVApxvJQSwDFHuYLETEIrwLzrwpKRWkMbKGTMl");
    string IWmJRZ = string("DNFecg");
    int enZjhGFWl = 75052115;
    bool wSsilMxELWH = false;
    double KLIYxpgAgxd = 1029287.3644932833;
    double IrxgrB = -930520.1933821377;

    for (int iJoNvBAaFeD = 1448710697; iJoNvBAaFeD > 0; iJoNvBAaFeD--) {
        IykbZBSUZs /= kafcewY;
    }

    for (int woQgzqOvbQfZ = 1769384364; woQgzqOvbQfZ > 0; woQgzqOvbQfZ--) {
        continue;
    }

    for (int SGwlRgoSScvoUV = 1886061397; SGwlRgoSScvoUV > 0; SGwlRgoSScvoUV--) {
        wSsilMxELWH = wSsilMxELWH;
    }

    if (IrxgrB == 521345.9209491782) {
        for (int hXqamu = 666047225; hXqamu > 0; hXqamu--) {
            oPImxirrDwzu += IWmJRZ;
            oPImxirrDwzu = IWmJRZ;
        }
    }

    for (int lvfxHwr = 683421177; lvfxHwr > 0; lvfxHwr--) {
        IrxgrB = IrxgrB;
        IrxgrB *= IykbZBSUZs;
        KLIYxpgAgxd *= IykbZBSUZs;
    }

    return IWmJRZ;
}

void buBwbaMtEeEDDHaA::shDPSVlKS(string szUWVSjMTxqpJSq, double eBKornSYjElGNNsE, double wELKo)
{
    double dCoOkHDnGoIB = -288489.7024952759;

    for (int MNqIWCZUgXEQwn = 1542783423; MNqIWCZUgXEQwn > 0; MNqIWCZUgXEQwn--) {
        eBKornSYjElGNNsE /= dCoOkHDnGoIB;
        dCoOkHDnGoIB *= eBKornSYjElGNNsE;
    }

    if (dCoOkHDnGoIB == -949554.381726565) {
        for (int xTQOrCdfxmdib = 672104050; xTQOrCdfxmdib > 0; xTQOrCdfxmdib--) {
            wELKo /= dCoOkHDnGoIB;
            eBKornSYjElGNNsE = eBKornSYjElGNNsE;
        }
    }

    if (wELKo <= 665739.6185125442) {
        for (int YBAHiKmrkHmtF = 1800018054; YBAHiKmrkHmtF > 0; YBAHiKmrkHmtF--) {
            wELKo = eBKornSYjElGNNsE;
            eBKornSYjElGNNsE *= eBKornSYjElGNNsE;
            dCoOkHDnGoIB -= eBKornSYjElGNNsE;
            wELKo += wELKo;
            eBKornSYjElGNNsE *= dCoOkHDnGoIB;
            eBKornSYjElGNNsE += wELKo;
        }
    }

    if (wELKo >= 665739.6185125442) {
        for (int JCdeA = 193626961; JCdeA > 0; JCdeA--) {
            wELKo = eBKornSYjElGNNsE;
            wELKo -= wELKo;
            szUWVSjMTxqpJSq = szUWVSjMTxqpJSq;
            eBKornSYjElGNNsE -= eBKornSYjElGNNsE;
        }
    }
}

void buBwbaMtEeEDDHaA::ASNMdlVw(string NIYGOvgHOejCxUbx, int iuVLOxyIJSYYzc, int isodcjfhsNBoJQfV)
{
    string nbihHyPesp = string("eeNUTCsEbgGeWLLOETIphQySYHCkjMBnD");
    string ziYKkUi = string("TCqwgGqDDldvqWFkQbgqOFdYdWNSTERgQgqFmmVbnEoMbtIyqkBAXQQFsiormrPPoiDWdFQDKNIQGkrSzmHtWobZizmKdByZFdfLwWMoVJfgyaXKtWEGuXdjHzqyhmCmfkiIbBlmhmlewhEykppffvDhvaPvjwlPwqNfgNVSziINTrqaCpusnwrDUxiwRRJEgwKVFqMVrBGxWSNWsxxagQExyRjjlLxwaUprgVFSxybcRqGMqhvRARBLuE");
    string mEDNIaewTcVB = string("WQOFkQcEtnTAuNkdlCiAFlUdYGXBmxpZabZggylhfGXSeicDjiwYPFrSLSmZFqNMxykZCdrWdvRMnwRhYDQdxMVbVCbUXchMtEVzTMmbvvJwWASvfWWUBKegtGRPASFsRAJInVbxWQPcxhlrIuxxNXEXoOltLFswPJwChvBRkUCHDnfSUAKhxfVmjTNbNtAmluueaQWkewulFGFEvuJvfeWEnFtibhKahvSFiWWVBoJoWPYrP");
    double OqlspHx = 788187.192891598;
    int mbxBp = -1279341886;
    string ksIvwVi = string("cJZmdRsDyXuGCNdLyCRhTTdHQBEolPgoxUlzvwTniIeghaPHlbAIuCttQgqSuGBklbgoulThaLtHSeh");
    bool QbGxqwpKSoBn = true;
    int MQLAdwNwpRdgsF = 137802198;
    bool KXsUJ = true;

    if (mEDNIaewTcVB <= string("cJZmdRsDyXuGCNdLyCRhTTdHQBEolPgoxUlzvwTniIeghaPHlbAIuCttQgqSuGBklbgoulThaLtHSeh")) {
        for (int ZeohaiYSllA = 578888397; ZeohaiYSllA > 0; ZeohaiYSllA--) {
            ziYKkUi = ziYKkUi;
            nbihHyPesp = ziYKkUi;
            nbihHyPesp = mEDNIaewTcVB;
        }
    }

    for (int dnZzIwoipQngk = 651700558; dnZzIwoipQngk > 0; dnZzIwoipQngk--) {
        nbihHyPesp += ziYKkUi;
        MQLAdwNwpRdgsF += MQLAdwNwpRdgsF;
    }

    if (ksIvwVi < string("WQOFkQcEtnTAuNkdlCiAFlUdYGXBmxpZabZggylhfGXSeicDjiwYPFrSLSmZFqNMxykZCdrWdvRMnwRhYDQdxMVbVCbUXchMtEVzTMmbvvJwWASvfWWUBKegtGRPASFsRAJInVbxWQPcxhlrIuxxNXEXoOltLFswPJwChvBRkUCHDnfSUAKhxfVmjTNbNtAmluueaQWkewulFGFEvuJvfeWEnFtibhKahvSFiWWVBoJoWPYrP")) {
        for (int TcKXYqmQy = 1640861119; TcKXYqmQy > 0; TcKXYqmQy--) {
            mbxBp *= mbxBp;
        }
    }

    if (mEDNIaewTcVB != string("WQOFkQcEtnTAuNkdlCiAFlUdYGXBmxpZabZggylhfGXSeicDjiwYPFrSLSmZFqNMxykZCdrWdvRMnwRhYDQdxMVbVCbUXchMtEVzTMmbvvJwWASvfWWUBKegtGRPASFsRAJInVbxWQPcxhlrIuxxNXEXoOltLFswPJwChvBRkUCHDnfSUAKhxfVmjTNbNtAmluueaQWkewulFGFEvuJvfeWEnFtibhKahvSFiWWVBoJoWPYrP")) {
        for (int rwoWhJweOIrnik = 679313185; rwoWhJweOIrnik > 0; rwoWhJweOIrnik--) {
            continue;
        }
    }
}

string buBwbaMtEeEDDHaA::BWOAkxFRXZ(bool GbsLWGx, bool ltJbJThfKgwDF)
{
    string vCFfbgrIlofKXWBU = string("XmHUPvPRcRzAOlQKBwhPPTnUsazkWlMlOvEIyduoHVIaxvOvcuyMiPvaacYqLuMUtnLvRPDcVMnOzEriWzcuLxaeNHMgcbESyPYIBqZwJCdhqJYGCRbHxijwlkWiuCRbqcOaZSDntegbFaDLYDfrAUEyXqWPysUeryGxVsrGjZadobwjvCNqggYHKbLonyTFDervbEpyBQuucRXccEEgaonY");
    double lQopLDyrkxa = 866474.0634473128;

    for (int bMvLJji = 24512198; bMvLJji > 0; bMvLJji--) {
        GbsLWGx = GbsLWGx;
        lQopLDyrkxa = lQopLDyrkxa;
    }

    for (int hvmYGYIsZLizrj = 451282627; hvmYGYIsZLizrj > 0; hvmYGYIsZLizrj--) {
        ltJbJThfKgwDF = ! GbsLWGx;
        GbsLWGx = GbsLWGx;
    }

    for (int gpsKaZEMVLdZ = 995261710; gpsKaZEMVLdZ > 0; gpsKaZEMVLdZ--) {
        lQopLDyrkxa /= lQopLDyrkxa;
        ltJbJThfKgwDF = GbsLWGx;
        vCFfbgrIlofKXWBU = vCFfbgrIlofKXWBU;
        lQopLDyrkxa /= lQopLDyrkxa;
        vCFfbgrIlofKXWBU += vCFfbgrIlofKXWBU;
    }

    for (int peqnP = 954329071; peqnP > 0; peqnP--) {
        ltJbJThfKgwDF = ltJbJThfKgwDF;
        GbsLWGx = ! GbsLWGx;
        ltJbJThfKgwDF = ! ltJbJThfKgwDF;
        GbsLWGx = ltJbJThfKgwDF;
        GbsLWGx = ltJbJThfKgwDF;
        vCFfbgrIlofKXWBU += vCFfbgrIlofKXWBU;
    }

    if (ltJbJThfKgwDF == true) {
        for (int ddKmWzlzCeL = 1232816300; ddKmWzlzCeL > 0; ddKmWzlzCeL--) {
            ltJbJThfKgwDF = ! ltJbJThfKgwDF;
            lQopLDyrkxa += lQopLDyrkxa;
            vCFfbgrIlofKXWBU = vCFfbgrIlofKXWBU;
        }
    }

    for (int EEdVBRMufcQ = 944998083; EEdVBRMufcQ > 0; EEdVBRMufcQ--) {
        ltJbJThfKgwDF = ! ltJbJThfKgwDF;
        GbsLWGx = GbsLWGx;
        GbsLWGx = ! GbsLWGx;
    }

    for (int pkgdOjThbqjhuc = 992121464; pkgdOjThbqjhuc > 0; pkgdOjThbqjhuc--) {
        GbsLWGx = ltJbJThfKgwDF;
    }

    return vCFfbgrIlofKXWBU;
}

buBwbaMtEeEDDHaA::buBwbaMtEeEDDHaA()
{
    this->gjDyOawVCS(true, -960732938, 726958.5599787734, string("fZkunYVFSpKhahvQjJbPQwaQivSXzHtyxrLrMjmRq"));
    this->wYLKtDdqg(-274878729, true, true);
    this->shvDqX(728796.2617667709);
    this->yHHfvvzb(645339.1043122704, -991974.8333916578, 619156390, 560385.1191887248);
    this->gxXzQOvQlOJEkRt();
    this->IIUrLZ(true, false, -459649.1527474445, -1692604727);
    this->alUCDBYzFQe(string("fIHwDFSgjTytepwwBtTNjVjreMCwZRsVMEjQzVmvcqpUYMlPzXxXNVRNEplgIQLkGBxMlMlqyENMUJKmHsjbzEuMbleweZFhwtGIcpZgnKmVedTETBibSPMuJjRpeMjoAttcziMSrXYsOtyZruKQISqxLCpZnjwaBAUd"));
    this->wnqTDdB(-775074953, string("wQTDnTIFtcmVtwfttjzEcoZZcxvllETgWQvuOTzSgZgjByKCReIeaxtMWpZYEGgkXfjnmpjFvSyaVDTfjutwPkwdzYJYKekSqFuPfGDgVpMGWWZvuGMfxBdgmLwCVCFTeuoIOQcYPZeXJyNPBexlvDKHtQqJuaQZcIHjTcenIjjcTAuPyIWpbixoKTgYiMmfBYKxhOsShIuQxwNwUfqEGuWTfivbibzMGgPMmfbLIlvnSkfCnYCLt"), true);
    this->cmQtHRbRTFHwW(string("jAsVgxAaIQzgEyOLgfHxmcXxKhhLIDpQNyzDqudeXPXUUIRouVbiPOPJGsdNuvznzFrlrUjiNMhBMfFgScZXFzklrvvRiGTESgerkDPwEGMtwdpfoTgZDnSXSoBWOnABFDjcZDMQiHgqfCHWAAGxTCHFbGOUatPdnVXOfySWQBFbssdSdkpvSquIortgXuwPkcKcSNIoLYQfHHFAuhryHDsalfsKKFawokPFtCpzaiWnQjZtfE"), -277482.83796699124, 412419.4096628834, 521345.9209491782);
    this->shDPSVlKS(string("NvNBPurBTLJSLycHOcpApQHKcpMrwHpRoPeIBICeTnLhnIGrFGIChHDJTWrWbjsCJwEGiQNTeTDUEiJmDEwdEFQyNCkDBruXrvsvAlLyYQcuDiPTMjRelOV"), -949554.381726565, 665739.6185125442);
    this->ASNMdlVw(string("sGzYhcDlcMojarSnGdVXEpyhjdXEeWQEMmsxySQPlPYAcByMACjfAyqv"), -532165630, 1880600037);
    this->BWOAkxFRXZ(false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KqnJGYWk
{
public:
    double wfPrSWQktR;

    KqnJGYWk();
    string feMLFIVEqSht(bool pBvCIvnV, double PUfcZaJnqml, int UwdSLwCk);
protected:
    bool IumJlckdS;
    int YZwynBBo;

    int PWeAmf(bool AUOiHnrLvOMP, int czYFy, bool IWmGIEC, int KsCfdrRbWbC, int ScgJhspgdcWre);
    double bRLdPmOOejh(int MDEbhpilTw, double lakqGggCt, string nsPWfheiRYyH, double mXbEdqFYKG, int CVCNr);
    bool uTzwCWf(bool xgjGew, string MObtldJv, string fNKAO, double QPTBROMYtFW, double MsjNf);
    bool BsQnZThmxcU();
    void xOinGBi(bool jZCQSBtxTnLevA, int kXhtSvHYPYNN);
    double LnaXgdCOatNT(int UAjVspQif, string XsMHsUMICjZfGXj, double ZwDBjpMqZIzRl, bool jJaKAZDjuoXl);
    int idjHmZWCnWpnON(string zCzEgQWGvuipZD, bool EUjvvwDlnUEyISlY, int iWtfKN, int GooxnnqeT, double MRqcyqDUvf);
private:
    bool gHiuZ;
    string AfcWeKJdplD;

    bool qxXWTJbW(string YbrRACxcX, int OzPFIhxB, double wKGIadwkkgwVftM);
    bool TWfFgffug(double QIdLiqPOntTOKxXX);
    int Kddql(bool YeyNyQNXGlGUpO, string EBNhUOfwWCqqV, double omIppSEQlmZZdhK, double rArOPPLee, bool qHMbQCO);
    bool PCwsxTejHKahDVCd(string FCaZGtFs, bool oRkUsQPJBBu, double tvprckq);
    double QvsVEyLiQTlI(int ulFZQ, int WFWpnwQrF, bool WsOQrWMw, double dsgUFs, bool UeGPIzckXqfKYpIA);
    bool XMjtzdoEt(double iwEsVuhcxZyRvDAK, bool MfYeZMbK);
    int ZFTFEYWDBIKxbOA(string KHkOZpi);
};

string KqnJGYWk::feMLFIVEqSht(bool pBvCIvnV, double PUfcZaJnqml, int UwdSLwCk)
{
    int ySucvdQ = -1920848377;
    int iImaCMjIacbaiU = -1157565087;

    for (int pIYzAQeABpVk = 455644313; pIYzAQeABpVk > 0; pIYzAQeABpVk--) {
        PUfcZaJnqml -= PUfcZaJnqml;
        ySucvdQ /= iImaCMjIacbaiU;
    }

    if (PUfcZaJnqml >= 166499.25936865396) {
        for (int jyUkrUtkjSK = 929359027; jyUkrUtkjSK > 0; jyUkrUtkjSK--) {
            UwdSLwCk = UwdSLwCk;
            iImaCMjIacbaiU += UwdSLwCk;
        }
    }

    if (iImaCMjIacbaiU >= -1157565087) {
        for (int vANiA = 1204255301; vANiA > 0; vANiA--) {
            iImaCMjIacbaiU = iImaCMjIacbaiU;
        }
    }

    return string("YAwjb");
}

int KqnJGYWk::PWeAmf(bool AUOiHnrLvOMP, int czYFy, bool IWmGIEC, int KsCfdrRbWbC, int ScgJhspgdcWre)
{
    string MdTGyevJO = string("GuACChcMWvZzTXYdjhkWoOUMYBUULXzMEPGlHhaepjTRWakRJHuwgYsvijHviYHLqHLlRYvXOpqilFdQBwasEGHPoxssFghuIltWlugveOXEbXTKOCqEMX");
    int kKrxi = 30402129;
    double cvvnXKcJJlLnHPGN = -181274.5663596491;
    double uZmOmWqcEgFoIkFr = 546450.2614744967;
    string EnJhainGaDBSO = string("gGUxBIcnYPrSNwCYOcpHLEALSQJfUMJDalQdCkQjZvzHnWpEXFQZnsDqJwBtPAmlKMgMDpizWFFNngkdzItyVxnFnCiGvycWdCsBdXwTWCdXKXvgBDcOexldhWaHpQtIAEzQQaQZJRnSIPM");
    string UJeodEITWWxSlk = string("CZUEGrUQZzNjZrWCVGHrKtaOVZKvMtLPZETiUYcdAxrMxlushPCJGKVSLVnpBYMmTixXlqMJkxTLQeRTXfRBMnxBHdwrPOfdgyYGrQxrFNIMWPjvbwiFbeKEFHOOZYYqGPA");

    if (ScgJhspgdcWre <= 30402129) {
        for (int TjrRWGJynlNsA = 1165700315; TjrRWGJynlNsA > 0; TjrRWGJynlNsA--) {
            ScgJhspgdcWre += kKrxi;
        }
    }

    for (int RuwCHumzdfDJzAl = 1907095982; RuwCHumzdfDJzAl > 0; RuwCHumzdfDJzAl--) {
        IWmGIEC = ! AUOiHnrLvOMP;
        UJeodEITWWxSlk = EnJhainGaDBSO;
    }

    return kKrxi;
}

double KqnJGYWk::bRLdPmOOejh(int MDEbhpilTw, double lakqGggCt, string nsPWfheiRYyH, double mXbEdqFYKG, int CVCNr)
{
    string lxXEIyTQ = string("jgIDnmNyTuYQMPbJXEFtugWGDOtgFvwCyQxkwqSEeGedPaziUJnQPXwPPSiWGMkeUlQsYHrjfPJANHbMBMViySlrppvBteHibxzSngXQQfOvGdtxUlemfyfbguAaiAlXNUNdNzSfskKsVyrfWwwLJKmeRbnEcHiwVbTPcJGhJwdhvdXsktyEHPIrCKTDNlXETDEASOOqOnWfaRQnPDWxwK");
    double Cdpwn = -704679.5550319123;
    string azuujL = string("MnbzFEJesDjDhgdW");
    bool TMKZTZfVRl = false;
    string tNZLVBugheKChp = string("XNwdmSxuwgYVKVCavwcxkLqXcYAfIAQQtyPOqxUcH");
    bool ODZdWkWvWFauWep = false;
    double nDYuDpeEfSCHjr = -1004612.9775963391;

    for (int KvjFPabY = 879314230; KvjFPabY > 0; KvjFPabY--) {
        tNZLVBugheKChp = azuujL;
        mXbEdqFYKG += mXbEdqFYKG;
        nsPWfheiRYyH = tNZLVBugheKChp;
        lxXEIyTQ += azuujL;
    }

    for (int YaPygMpW = 1990817309; YaPygMpW > 0; YaPygMpW--) {
        ODZdWkWvWFauWep = ! TMKZTZfVRl;
    }

    for (int OeSagNIVcL = 361285214; OeSagNIVcL > 0; OeSagNIVcL--) {
        continue;
    }

    for (int wbjhPrGLHBL = 862929590; wbjhPrGLHBL > 0; wbjhPrGLHBL--) {
        MDEbhpilTw += MDEbhpilTw;
    }

    return nDYuDpeEfSCHjr;
}

bool KqnJGYWk::uTzwCWf(bool xgjGew, string MObtldJv, string fNKAO, double QPTBROMYtFW, double MsjNf)
{
    int xcSUKihpAehAPSz = 222426096;
    double IOZawFK = -488499.34005816834;
    string SGnKh = string("pamLqtcYbKbGsIHswwsEcXcxpvLQjAGIXJuMboxFkkPVamjYylmufSXwkpjogAjnrwmVTxYfiIIsS");
    double ImtxReAnjmpX = 494265.27512770303;
    int clKPO = 19704624;
    double OCgvCSeyCiL = 274219.13732837525;
    bool eTArIkVRz = false;
    double LDcEOCVzKgwtoO = -925494.3010720273;
    string ihmeBpvZulhNsDr = string("LijlyOVBaUwAicgWEKXkvtzxsBreAwOEmKrOGidzMEQIQmOzwKvtnzthNjGJPrIDvVbzQddBrdXtxyJJMUhzucbRpyhaAIrDLdvauRfaUzBiKDUDqdmuvPJ");
    string gJBmld = string("iEkQuDsxYjvEoBEwUeHEynnxrnfMhhCuZTMytsEKoSLYiqknMlzGAXhazEgGUybusuuKnnsHBWwBHonHxgzmj");

    return eTArIkVRz;
}

bool KqnJGYWk::BsQnZThmxcU()
{
    string sWBtWUCPlxOKtaZh = string("ttDIUfJztAnkujLkqyljwfhVWoWFoloRrANBmuxN");
    int sVnQCmojU = -21967083;
    string amUXCvzecO = string("CurV");
    string qyjnDerYQEmgESFf = string("oAMvLpiAtNAkePptuInYBSHXOtRkHNrFQnkFknTJrfvhHuHarpZXqqpjFadfaARZPGRNImYEnWwwwfEoswfXNuGHiDHCeEjrXzewMyEmBkHqkTMZkngEljkLHDNtcOkborHhiGJTiEnVOdOfGsxwaJDSjMsyYxGTqptPWFbjcNwLCzPiwSjasmUcChKoxfPsCacbdHCvYlCQBjgkOUNiIkKeJtIcGZLYrKwwObRYfmERiIsczAkhpdwljrJk");
    bool ERFRkfmzurtR = false;
    bool uheuJdBLNTsamhy = true;
    double KlMPvTx = -912102.8765189018;
    double KJMAedmXq = -35362.70771014677;
    string YuoVpV = string("yAgkHDIxJZRLmLeTkRMJYmvBfHPgqGRMBopXDQjdqlroqBaMPfoDlTcUCrscrZtfAHGuHbewVxUKaQzccxxxaFPRQwALQjMsnljizFnAtFqnvsHRAH");
    string EpDfDAHrkvdHx = string("bdbssUJUHqqzZakHf");

    for (int sHpPWW = 1604937986; sHpPWW > 0; sHpPWW--) {
        qyjnDerYQEmgESFf = qyjnDerYQEmgESFf;
        sWBtWUCPlxOKtaZh = amUXCvzecO;
    }

    if (KJMAedmXq <= -35362.70771014677) {
        for (int mvZcpqeeazHzA = 119934128; mvZcpqeeazHzA > 0; mvZcpqeeazHzA--) {
            EpDfDAHrkvdHx = YuoVpV;
            EpDfDAHrkvdHx += EpDfDAHrkvdHx;
            amUXCvzecO = qyjnDerYQEmgESFf;
            sWBtWUCPlxOKtaZh = EpDfDAHrkvdHx;
        }
    }

    for (int AXkqpFD = 2071565659; AXkqpFD > 0; AXkqpFD--) {
        qyjnDerYQEmgESFf += qyjnDerYQEmgESFf;
    }

    if (amUXCvzecO != string("oAMvLpiAtNAkePptuInYBSHXOtRkHNrFQnkFknTJrfvhHuHarpZXqqpjFadfaARZPGRNImYEnWwwwfEoswfXNuGHiDHCeEjrXzewMyEmBkHqkTMZkngEljkLHDNtcOkborHhiGJTiEnVOdOfGsxwaJDSjMsyYxGTqptPWFbjcNwLCzPiwSjasmUcChKoxfPsCacbdHCvYlCQBjgkOUNiIkKeJtIcGZLYrKwwObRYfmERiIsczAkhpdwljrJk")) {
        for (int gMMFBbAGkezkRgI = 727158141; gMMFBbAGkezkRgI > 0; gMMFBbAGkezkRgI--) {
            qyjnDerYQEmgESFf += sWBtWUCPlxOKtaZh;
        }
    }

    for (int dRork = 1545675091; dRork > 0; dRork--) {
        EpDfDAHrkvdHx += sWBtWUCPlxOKtaZh;
        sWBtWUCPlxOKtaZh += qyjnDerYQEmgESFf;
        KlMPvTx += KJMAedmXq;
    }

    return uheuJdBLNTsamhy;
}

void KqnJGYWk::xOinGBi(bool jZCQSBtxTnLevA, int kXhtSvHYPYNN)
{
    bool rFaGpN = true;
    int nwTdJoHXU = 269701964;
    string DoHOuoEFpZY = string("sTjGZNsmOOqMGACowuXJWuKYPtZpMrLPgNdkgrrWCfXKSzwQyRCBHwthVROPWQcdQPDBVcbVveYsheMlYYuSfuysxLWQrsiHoONBqoSXDmGbPdsSeaNrkdRDDKFIouetXAvQDgFwfIZAHUwzNsCzQGbBGovQfcLnIMfgCBvpoORBBKsewCGCPmoqOxTuofqrBnqlNLZJsIloMfTvQRdhzcufomKx");
    int rXOQiPtgGVnjq = 755280261;
    double TnwOWFqqSxEUbB = -593594.6373121587;
    double vbqLZWipreniEpGf = -723029.1475349049;
    bool wYGPOOc = true;
    int tLWGiUGythgtF = 1041819841;
    int OPBcKH = -1217935311;
    double UGOOxRJ = 501738.9117600071;

    if (UGOOxRJ < -593594.6373121587) {
        for (int NuHZSZRu = 2091682759; NuHZSZRu > 0; NuHZSZRu--) {
            UGOOxRJ = vbqLZWipreniEpGf;
            rFaGpN = ! wYGPOOc;
            rFaGpN = wYGPOOc;
        }
    }

    for (int TqBxRDPRTsaGWxFe = 100726173; TqBxRDPRTsaGWxFe > 0; TqBxRDPRTsaGWxFe--) {
        continue;
    }

    for (int bxJxq = 117196; bxJxq > 0; bxJxq--) {
        vbqLZWipreniEpGf -= vbqLZWipreniEpGf;
        wYGPOOc = ! rFaGpN;
    }
}

double KqnJGYWk::LnaXgdCOatNT(int UAjVspQif, string XsMHsUMICjZfGXj, double ZwDBjpMqZIzRl, bool jJaKAZDjuoXl)
{
    double NtRUmmHYPovaNz = 623238.0132323534;
    double NlRKi = -960328.2228026777;
    string fhnqHWvpi = string("xOMRyUAQsJSxHIpNHHnbAWXnaUBqmAmzxLAebnOPhQfYRZkoanbXPMP");
    double DxZTuh = -48433.85355977493;
    bool aVGThuGN = false;
    int XJDdeR = -420495400;
    bool WsNvpNe = false;

    for (int HufAI = 762507583; HufAI > 0; HufAI--) {
        continue;
    }

    return DxZTuh;
}

int KqnJGYWk::idjHmZWCnWpnON(string zCzEgQWGvuipZD, bool EUjvvwDlnUEyISlY, int iWtfKN, int GooxnnqeT, double MRqcyqDUvf)
{
    bool qvmYkIUEeIyEzmR = true;
    string CCrUMylGSK = string("FIstkNZDeaTzWIEVzKCBHLvSiRVKdvMIjaRzSZiOLWhqOGohuLAXIJCXGDNDywoElzfbHVxQDOoMOvZKVRZlTvPqhaoawqDMSWFZCfHQI");
    bool HRkUvEWPsYx = false;
    bool rCGDDNJmBLVJI = true;
    string HCFGTohBVh = string("bXDLiuljoRSfckCBtITlimqaziCFXKeXeTyUJTRtqQwmhjJpfdSqJkfaBcdFHAoKEcyBqZVqQHubwjOIpWgoNhMlRvLbWcnYufdfAeMmPRNbWXNcGvZUFBHJLFpillIItLlGIdvXkGgjqtRMgXDtguPVFkQPLwzVoVDRXoRGgJAuMlkqYLghGhtxIglAIxjSVIaAsRzfYmDZKZZYJPankgPkPewpMJiquRSwKAIILS");

    for (int JqQTCtf = 245881215; JqQTCtf > 0; JqQTCtf--) {
        continue;
    }

    for (int MyoJUYQpGKs = 1632295282; MyoJUYQpGKs > 0; MyoJUYQpGKs--) {
        continue;
    }

    for (int FQBZozkg = 619748703; FQBZozkg > 0; FQBZozkg--) {
        HRkUvEWPsYx = EUjvvwDlnUEyISlY;
        EUjvvwDlnUEyISlY = ! HRkUvEWPsYx;
        HRkUvEWPsYx = ! qvmYkIUEeIyEzmR;
    }

    for (int ZIBhT = 1271898935; ZIBhT > 0; ZIBhT--) {
        iWtfKN += iWtfKN;
        EUjvvwDlnUEyISlY = HRkUvEWPsYx;
        HRkUvEWPsYx = HRkUvEWPsYx;
        zCzEgQWGvuipZD += zCzEgQWGvuipZD;
    }

    return GooxnnqeT;
}

bool KqnJGYWk::qxXWTJbW(string YbrRACxcX, int OzPFIhxB, double wKGIadwkkgwVftM)
{
    string XbDzoGaiSWV = string("AhShoXrqZuaFFoyxJbXiElqZDYUqrKlFjzWqvLrNiwjqFMssHDRJBAPJSMAyy");
    int tFYuPYwREVKyJfvU = 209299936;
    int wVaAnr = -1353624346;

    if (tFYuPYwREVKyJfvU < -1353624346) {
        for (int ThPaQ = 784090975; ThPaQ > 0; ThPaQ--) {
            wKGIadwkkgwVftM /= wKGIadwkkgwVftM;
            OzPFIhxB = OzPFIhxB;
        }
    }

    return false;
}

bool KqnJGYWk::TWfFgffug(double QIdLiqPOntTOKxXX)
{
    bool pBabpAKXVoZjOc = false;
    double aoxxoDljEIOVOLG = 529883.1455164526;
    string AmsHAYpyg = string("DAkTVzzLgxmZyjwuKkLUKQttltXkTzKNMDmKXxIVXIjKUhRDJTBJWJaIxvOzDtuyEsnNocIjFOpdxdjCeXaWgALJBcRmsDCLjyMuTNVpJbMyAJLbEQkiMDgeZSilgvLwIuzxjydxLqPbmgNyXGmjvFZMSXVScblOEllTbgELVvKFYMQaOcUDPxNJDwzOkLHPhkTayW");
    int WtXrWPd = 550987257;
    int QmnExx = -1781724517;
    string pgCKQ = string("TbpCDuLXMvoNmHBiHoSWkUPLQCDavY");
    double jRqUEuNLJnKoF = 983327.8827038173;
    double WkyGHIx = 465258.27146915864;

    if (QmnExx > 550987257) {
        for (int SIXdR = 1961505772; SIXdR > 0; SIXdR--) {
            WkyGHIx = aoxxoDljEIOVOLG;
        }
    }

    for (int LwTziVf = 1575494911; LwTziVf > 0; LwTziVf--) {
        continue;
    }

    for (int PlADX = 1412185550; PlADX > 0; PlADX--) {
        WkyGHIx = QIdLiqPOntTOKxXX;
        WkyGHIx += WkyGHIx;
    }

    for (int khdnX = 1683027579; khdnX > 0; khdnX--) {
        continue;
    }

    return pBabpAKXVoZjOc;
}

int KqnJGYWk::Kddql(bool YeyNyQNXGlGUpO, string EBNhUOfwWCqqV, double omIppSEQlmZZdhK, double rArOPPLee, bool qHMbQCO)
{
    int cKgsqc = -769981856;
    bool wUIagqHgda = false;

    for (int ccYaoyqL = 354585742; ccYaoyqL > 0; ccYaoyqL--) {
        continue;
    }

    if (YeyNyQNXGlGUpO == false) {
        for (int STxpFJLjLi = 522547498; STxpFJLjLi > 0; STxpFJLjLi--) {
            wUIagqHgda = wUIagqHgda;
            wUIagqHgda = qHMbQCO;
            omIppSEQlmZZdhK -= rArOPPLee;
        }
    }

    return cKgsqc;
}

bool KqnJGYWk::PCwsxTejHKahDVCd(string FCaZGtFs, bool oRkUsQPJBBu, double tvprckq)
{
    double nJxuPYPMtXs = 449803.84581910336;
    bool czatO = true;
    string FnCWy = string("AlhnNTdFuhVWtuhVIGUZnphcEqojcgkpiAMOxzykuEYXWfHGUrgOntYvtqHcefZUlUxNPkHzhjrRzkEsOTvzeDgDjFwcqqoLXzkVByDfaYlBLwsLcpmkleeVgHJcWgfDLQBTBEcJnvkZhYMLjQQPUoSLjIpyZEbcIhtyTkUWANeprhvGRXnThbPoMBjfrxyUEFYcwPzRoEoCuYJEHldarNVaRwdAisPwSmWUprVxTObbBLZbndK");
    bool GsJCMC = true;
    double DpYiKQiyYriiDBcl = 840543.9131618645;
    bool FKlzQQJpNoBv = true;
    bool PTPZJoFvXQ = false;
    double HiMDldqSnOL = -312794.83285966225;
    double zoAoqoAYZqfuSpMD = -248468.51717912793;

    if (czatO == false) {
        for (int DDZwUXAF = 914053356; DDZwUXAF > 0; DDZwUXAF--) {
            DpYiKQiyYriiDBcl += tvprckq;
            HiMDldqSnOL += DpYiKQiyYriiDBcl;
        }
    }

    for (int qApQnnbaHrhWaNi = 157182388; qApQnnbaHrhWaNi > 0; qApQnnbaHrhWaNi--) {
        nJxuPYPMtXs /= zoAoqoAYZqfuSpMD;
        FKlzQQJpNoBv = czatO;
        GsJCMC = PTPZJoFvXQ;
    }

    if (FKlzQQJpNoBv == false) {
        for (int qsBKkbYRzXiW = 876134552; qsBKkbYRzXiW > 0; qsBKkbYRzXiW--) {
            tvprckq /= HiMDldqSnOL;
            HiMDldqSnOL = zoAoqoAYZqfuSpMD;
            nJxuPYPMtXs /= HiMDldqSnOL;
        }
    }

    return PTPZJoFvXQ;
}

double KqnJGYWk::QvsVEyLiQTlI(int ulFZQ, int WFWpnwQrF, bool WsOQrWMw, double dsgUFs, bool UeGPIzckXqfKYpIA)
{
    string KAuROIjxv = string("pTNPtIBsZgWtvXiFLQddMreIPRljBwXYdEZYucieDnxZIybSPIwmzJbEFetEdkJhoKRpRuWzddXCgzCobdGaBGegNFxKMeatKUSOrfa");
    int FXkpTwGb = -449137603;
    bool lacURhb = true;
    double KslfOhuLJcZ = 994915.2743228078;
    int SoMYxhjeE = 1050452137;
    double wNCgFZcw = -416705.3173690993;
    string MxOxVaszYmiNjU = string("qwqaBNhOHQnPxykHGP");
    int DjcIM = 1754636362;
    string WMGIK = string("HsodPIiKgeJkQnPugOYPVDqxoHwldbCNKEdxuciJhyjZQSPAygDuUetsb");

    for (int HjllagqvQQB = 437841851; HjllagqvQQB > 0; HjllagqvQQB--) {
        KAuROIjxv = WMGIK;
    }

    for (int svlWOcr = 2088830779; svlWOcr > 0; svlWOcr--) {
        continue;
    }

    return wNCgFZcw;
}

bool KqnJGYWk::XMjtzdoEt(double iwEsVuhcxZyRvDAK, bool MfYeZMbK)
{
    double wSGRARORDCBCNu = -697057.2784730939;
    int LYHYR = -481921382;
    double InBekK = -494092.2054127878;
    double GLQDQTdix = 667921.4765255379;
    string CzzQvkGuxzh = string("vhIopnXtHpLIrBliZlIMINdAaTVLdClAiQkfpdOLHViFdWvrgODqMxzirEepCHAXmGtVpHoucymwmVIGENaxOAQmtDOYUxzjZMirbbWouWCyjZQmEuvqyeNnLjWcxcSNcuHYAUjBiEkFilPnTUdBJnnQbSTpvVzvMhwqapZCgSlMCNoBxLzbDezjyQZlqevMuunkSZwmLkwEMwDZLoSDKnoxgkScEZoQlmqhJYzmAJrfD");

    for (int iQqFOkzCm = 294272223; iQqFOkzCm > 0; iQqFOkzCm--) {
        InBekK = InBekK;
        GLQDQTdix += iwEsVuhcxZyRvDAK;
        iwEsVuhcxZyRvDAK /= iwEsVuhcxZyRvDAK;
        InBekK -= GLQDQTdix;
    }

    return MfYeZMbK;
}

int KqnJGYWk::ZFTFEYWDBIKxbOA(string KHkOZpi)
{
    double mPkDXBERAA = 1031129.7801517185;
    string ChmNwn = string("AuxsZGRmsuXxrVQtWmOilcetpFcZNtMKbYIgDjpeUWeqHhwIVvVBbJuUfTJeqcBJIahqWNjZDvGlgQSaWyqkEWGxGCPxzEGLXYRpebhZllnWflWzpqPmoLhSgHidpXwOUmoDDiCgUcAeywOEwvJiLCDLYADVIiAqaalHqRVIjzoNDJKHbUpKMddTASmerabaWjRRvlFGeMcQYMHxWdxMlpRFIFTAAkmeolrPSTWiAfNhlZNVVqcNmLTcooxPLQ");
    int jidKGfmHJZ = -1250991747;
    bool mdjXXZtIFQl = true;
    double sqetFXZrpVpM = -12375.688301147786;

    if (mPkDXBERAA != -12375.688301147786) {
        for (int aRTqOCIGuq = 2020153175; aRTqOCIGuq > 0; aRTqOCIGuq--) {
            mdjXXZtIFQl = ! mdjXXZtIFQl;
        }
    }

    if (sqetFXZrpVpM != -12375.688301147786) {
        for (int iGyGCwO = 331309436; iGyGCwO > 0; iGyGCwO--) {
            continue;
        }
    }

    if (sqetFXZrpVpM > -12375.688301147786) {
        for (int kPWHdwQH = 77433709; kPWHdwQH > 0; kPWHdwQH--) {
            ChmNwn += KHkOZpi;
        }
    }

    for (int imaWLu = 1337282511; imaWLu > 0; imaWLu--) {
        continue;
    }

    for (int hpppLIhfEkzaUasy = 1113322091; hpppLIhfEkzaUasy > 0; hpppLIhfEkzaUasy--) {
        ChmNwn += KHkOZpi;
    }

    return jidKGfmHJZ;
}

KqnJGYWk::KqnJGYWk()
{
    this->feMLFIVEqSht(true, 166499.25936865396, -163164148);
    this->PWeAmf(false, 139924410, true, 1843494573, 272748448);
    this->bRLdPmOOejh(-870687132, 324386.84809416527, string("FXWdkXnliyzCJzwQPTAKGPwmpyVBBKruNYgdVesQMhYGApfAtPuWokcBBdzRAvQXyGqesblNAQGEOJfqtBThaGkZDhmqFTJjMhdJUqvoNwPvUuygjYeMqcdKfmqzYyVkUvFegKzlu"), 145972.48580283104, -78710253);
    this->uTzwCWf(true, string("kmICDAzlQlikZQojdHTjPliCyNMxOjhomGCCkHWFwSTXYHZqluplbmaXRnPFWiXLYCAUHdtzObQkUbchoWkuUYONbLQgdQqtCWyBaWEfnpdZPQnxCgMEtgNDdFioWckVmWKVMwhTFPRNzSRgTmENXAMjQSPTMlUmPjigxIddqWxYSagKaHqbNfXfKlsrRdZrlOpLaGfgyNKlKZObJQBBAroMxxtxUhXUSZgjkCZvCHTzVc"), string("IBEKDkIHeYlohIkHIVCLlPgNxOtnaaTcWSzWoWkqSGjEIGmEPHeWgFWVnKTxREBtksVNfObgsasMvwRiZKPtveaYyTFPzSaIzREUqHbTozbZwzLNQhWXsHbYBFbpdYaIUqPoSFfYcdqdPNMnAmufBuAuUzHrgkcEytRTxkaLsVefhXLSMwpVdlHOOJUbiBtlOdAWuQHTiKwXWONEPrLpKD"), 661453.194749093, -748288.3415511906);
    this->BsQnZThmxcU();
    this->xOinGBi(false, 342982357);
    this->LnaXgdCOatNT(-1768222712, string("wZTpspuvIoILAUJlOeFYuhZtABfwqFRPncbWnymnzgkvnMQCAHMLZfyYcVdvDDCLSCaZDPOAvlMSKaihrFAIQmbNjsgQZMXRsg"), -598911.0307981588, false);
    this->idjHmZWCnWpnON(string("XUztIbqcnWoRxDrqXKmXjxvUztARgvUPkPErwdGfeNxGhVGdgUogUPqYRjuUsLazdMfmX"), true, -1467740594, 1500983083, 124471.40381838843);
    this->qxXWTJbW(string("vckWDdufSldvOYKceTmsjlqikJhEhCufQBTRQmOJvLATvzVzVLYKywCMwBSwxhDbyMBAHUKXAJzlTPLodsKGyDjGwxfQdMPKbiiEVAbADqBdwTmEPtUgnkcctqZtwQDVbDbqIsnovuhTEENJQcaZvvLmbVNvYedhdZzILSjJYzPHAMOEsRysAPBFOsDIHyUCTZNddcCrLdoVbpgRAQUod"), 1296576883, 582553.4896272348);
    this->TWfFgffug(-215179.93145636245);
    this->Kddql(false, string("LtKuMSkLakiMJNwEuFHCPzqGAyYBibIKBDsDPscUdhRr"), -456016.28783723945, 638830.6728017717, false);
    this->PCwsxTejHKahDVCd(string("CoTdSWqvZwokxnVlzXbmiIjiIRAJcjMuoZkhRaJYdJNymUxtrsXjLURqxCwYveBvfKRodazVpBsreoajMnUEfZXGPtuWlPFqVHlzDPmBgXQaZhoqxlURyAHfNpsySuLOjcfbwzeycZLKdRXQIhMfinfSbDiJpJZ"), false, -272446.38046165387);
    this->QvsVEyLiQTlI(1650131157, -1229973982, false, 193300.37137872356, false);
    this->XMjtzdoEt(961271.9839759634, false);
    this->ZFTFEYWDBIKxbOA(string("CRLMBzhhpsEiZYdhWwBZQp"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RyptZ
{
public:
    bool htCPBm;
    int puCpsvp;
    double bZgxeQtaisJmZ;
    int XNilpIkNcU;
    int SguYBeBvDAPR;
    string KifHsuGSrLWQq;

    RyptZ();
protected:
    bool iBdFu;
    double CdrCbHzRrK;
    int ESgyFUSxUUOnE;

    bool tSXevKMhOKQUzZ();
private:
    bool kxXgELfBVQgC;
    bool FaBFhPQIvUgHmLX;
    int NBFQOoqeKKP;
    bool EOEIqbKVlWawRdH;

    double RJulABijgrYX();
    double ecyKrgwITQgqCvw(bool yikyAbxLGvyO, bool jXwXHmQAEcMP, double jjdQscWfjD);
};

bool RyptZ::tSXevKMhOKQUzZ()
{
    double PaeDGz = -760840.8095135128;
    double VUlpALkYPPUIfbb = -859605.6240205908;
    bool njUKaAhHMSV = false;
    int wbptUeEbQGfCAx = 1877853245;
    bool EutQxfxaTqfsCiK = false;
    int oxRJErxKaO = 1275014677;
    double stPSTowDfAznYxg = 636858.4353690699;
    double xuqhgUSNuGb = 835290.640930949;
    double TEkJrE = 991059.4384610903;

    if (TEkJrE < -760840.8095135128) {
        for (int oASUJYHjTkKnqa = 1516018474; oASUJYHjTkKnqa > 0; oASUJYHjTkKnqa--) {
            PaeDGz /= PaeDGz;
        }
    }

    for (int ZHZNkMRTeV = 1955436842; ZHZNkMRTeV > 0; ZHZNkMRTeV--) {
        xuqhgUSNuGb *= xuqhgUSNuGb;
        stPSTowDfAznYxg = TEkJrE;
        VUlpALkYPPUIfbb += xuqhgUSNuGb;
        TEkJrE /= PaeDGz;
        PaeDGz *= VUlpALkYPPUIfbb;
    }

    if (PaeDGz < 835290.640930949) {
        for (int FIfLdB = 1225499219; FIfLdB > 0; FIfLdB--) {
            njUKaAhHMSV = ! EutQxfxaTqfsCiK;
            EutQxfxaTqfsCiK = njUKaAhHMSV;
            PaeDGz += PaeDGz;
            VUlpALkYPPUIfbb *= VUlpALkYPPUIfbb;
        }
    }

    for (int ltWUyrXJ = 1915385760; ltWUyrXJ > 0; ltWUyrXJ--) {
        PaeDGz += xuqhgUSNuGb;
        njUKaAhHMSV = ! EutQxfxaTqfsCiK;
        PaeDGz += stPSTowDfAznYxg;
    }

    for (int rvXTCIrzxNAj = 2122759935; rvXTCIrzxNAj > 0; rvXTCIrzxNAj--) {
        EutQxfxaTqfsCiK = njUKaAhHMSV;
        EutQxfxaTqfsCiK = njUKaAhHMSV;
        PaeDGz *= VUlpALkYPPUIfbb;
    }

    return EutQxfxaTqfsCiK;
}

double RyptZ::RJulABijgrYX()
{
    double MlAImBeosmQLLMhM = 410049.95687077474;
    int vMyegBLkSjS = -1767141388;
    string kjOfN = string("YhTxrzxPQGVKEwxboidvlloyLxwRYcvLkPE");
    double qfCElFa = 248206.6409035975;
    int jlabgiHu = 297234988;
    int lRRjt = -1582350095;
    double yIXLCLcK = -727326.8998740894;
    int JnPLu = -789072043;
    string nmXBDOY = string("oSuLCEzXDKShIczGYGsASCnwnKRgfJuamuyxZabQmSsjVGYFhbwrflTPhpNBSEgQhNjONLCIORlFOFYabtaLdaSOBcyNEwLPfPVhQYWtJmfEWzcxOGxrmAyAeFkIVSbxgsrrWBegeJYPvekwGHikHjVdBBDpngFuFzlMHnmnlqElmTNEDQVtqFvJknIuAXYPhrisIlItfkVBjFtKfTMeocUJxLELYeDjwhMImfnHmKX");
    string FpqVJJJCLrgeZ = string("VUMkvUBUmGLxkjHbLMCdfzubUU");

    for (int UWxZyarsnIk = 1883167017; UWxZyarsnIk > 0; UWxZyarsnIk--) {
        kjOfN = nmXBDOY;
        nmXBDOY += kjOfN;
        qfCElFa *= MlAImBeosmQLLMhM;
    }

    return yIXLCLcK;
}

double RyptZ::ecyKrgwITQgqCvw(bool yikyAbxLGvyO, bool jXwXHmQAEcMP, double jjdQscWfjD)
{
    bool VptPKjfgx = false;
    string IlROUbcNUnQ = string("xLIExOQvHGjiUOVNsUKtRntifXfjqjRuYeQSlGQfjwwgMjObMLmAFuUAbmwpZtEJLSYGDiTSIcxALsGDKWlvLkifyLxrlhVYITIpdBybonsjCZQVndDyxDqASeWQbgxOJWvrWRYkQcShdEWPjQwfLHIDKeFSbEnpythLApbQAIaRRBgtIHqE");

    for (int qvFGXYwHhwEx = 1057409721; qvFGXYwHhwEx > 0; qvFGXYwHhwEx--) {
        yikyAbxLGvyO = jXwXHmQAEcMP;
        yikyAbxLGvyO = jXwXHmQAEcMP;
        IlROUbcNUnQ = IlROUbcNUnQ;
        IlROUbcNUnQ += IlROUbcNUnQ;
    }

    if (jjdQscWfjD < 317908.0948433291) {
        for (int mVAPhidATJmaFCDo = 186395473; mVAPhidATJmaFCDo > 0; mVAPhidATJmaFCDo--) {
            yikyAbxLGvyO = VptPKjfgx;
            yikyAbxLGvyO = yikyAbxLGvyO;
            VptPKjfgx = yikyAbxLGvyO;
        }
    }

    for (int RDjyPfDNEWAmuUs = 1342259914; RDjyPfDNEWAmuUs > 0; RDjyPfDNEWAmuUs--) {
        jjdQscWfjD *= jjdQscWfjD;
        jXwXHmQAEcMP = yikyAbxLGvyO;
        jXwXHmQAEcMP = ! yikyAbxLGvyO;
    }

    for (int NkHIvJs = 1581088888; NkHIvJs > 0; NkHIvJs--) {
        IlROUbcNUnQ += IlROUbcNUnQ;
    }

    for (int LRNNNr = 316069564; LRNNNr > 0; LRNNNr--) {
        jXwXHmQAEcMP = ! yikyAbxLGvyO;
        VptPKjfgx = ! yikyAbxLGvyO;
        VptPKjfgx = ! VptPKjfgx;
        jXwXHmQAEcMP = VptPKjfgx;
    }

    return jjdQscWfjD;
}

RyptZ::RyptZ()
{
    this->tSXevKMhOKQUzZ();
    this->RJulABijgrYX();
    this->ecyKrgwITQgqCvw(false, false, 317908.0948433291);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UqSbHuAZfvayGL
{
public:
    bool ZixTSlwU;
    int uwBBTu;
    string yoXzRglqHkO;
    double vNKXiJyHuLjHY;
    double HfBnrfofZk;
    double BPtio;

    UqSbHuAZfvayGL();
    double ZWfpPCHhTK(string kobPLdG, string dYcTk, string UlFdEBt);
    void UYkIfQFurFo();
    int nGTmK(double ShYdtQzif, int THFjsTYcEuIR, int AyphfjiCzXpfZL, bool rOaOy, string QiXwR);
    bool IdJlbmzyuvD(double VTtfgrkT, string jajkWezNaOEBWeI, bool kVMMdA, string XBeKxRLvpqHjWA);
    void ZxTML(int JFOhDhXBzt);
    void CIxAOQV(string hrULZf);
    void asixz();
    double KMUWIQWPfgkDC(bool OkUDNInmtRVqNB);
protected:
    string fSuhVmwVbsM;
    int LoGgyiChYWOOUW;
    string mBVLPRsPMJx;
    bool kQWKoDXrKnao;
    string OjZZmPxGOehVsU;

    double dKvpRsyGu();
    double ylvzgd(string iWooMlqTzkFHhcd, double QQItiaDFlZcWopBB, string NUUCVBWRnOBg, int EtAFYkfOSloA);
    double djnmeEfejdvlk(double KSfAQGvaBVZjgbT, string ngYAC);
    void lUIlTMhgEuSqfn(int aJXJRhTzVS, bool llgyuA, int olnBjbWtl);
    string VrCMfTADcDwpkyFw(string uwDQYfjEdkI, int RiXFnjKWhvdkt, string nvvgWvnktjHvjEu);
    string VdsUMRljNUGIPthZ(string ycGWuozSsFENdSAP, string MWYProxczBdfjRh);
    void aELTsMBfwfKGKU(string DhjGHFXeALIq, string ByvLj, bool hvxArfVfGCMKXO);
    bool YbECOfWdUrnc(double hTaWMTzub, string iehuRGNUyrSzR);
private:
    string AAiWmQRAwuuTJ;
    double kgCRGEWpzstDLThp;
    int NEBRk;
    int lcNDSJXzNY;
    string kCgEYIUhavLvmPG;
    string SXavpE;

    double NFgXTQZguOtMwt(bool IyUCyGGxIPcOcY, bool ZavVZhTY, bool ecTJXNtGB, int BCwZhPvePVFQS, double UBDcSigLHyKGbxs);
};

double UqSbHuAZfvayGL::ZWfpPCHhTK(string kobPLdG, string dYcTk, string UlFdEBt)
{
    double birMXn = 505599.52908704255;
    double WzlcVvdys = 1033098.0114399865;
    double HyfdtmMr = 565699.8244728771;
    string ZAKimpyHMglGcmtn = string("ivUexxkOhraXDxIuNZGFQdlFEUPYskdtyECggeW");
    bool kUeLJjiuDsnq = false;
    string dZjPwTmTgjfoKq = string("mcEBkeMjiiYjLbHfgqvYahSHhhZkuQTcmpTdnGliCfwOAAPTYPCyUnmPbgFMTHVYdWLSuaozcxYTkJxElelEvjCdySNutwGomXNLfcJV");
    int osdrmfQkjHMk = 230405635;
    bool pKnwkvjr = false;
    double OxAREjkqgpbrq = 237616.23213189602;
    double quBVqCgYOS = -37587.09593335569;

    return quBVqCgYOS;
}

void UqSbHuAZfvayGL::UYkIfQFurFo()
{
    bool HNGYKQSoikz = true;
    double vhJIbDQyauzp = -499606.49949814624;

    if (HNGYKQSoikz != true) {
        for (int YGJusMqormuf = 2025937119; YGJusMqormuf > 0; YGJusMqormuf--) {
            HNGYKQSoikz = ! HNGYKQSoikz;
            HNGYKQSoikz = HNGYKQSoikz;
            HNGYKQSoikz = HNGYKQSoikz;
            vhJIbDQyauzp = vhJIbDQyauzp;
            HNGYKQSoikz = HNGYKQSoikz;
            vhJIbDQyauzp *= vhJIbDQyauzp;
        }
    }
}

int UqSbHuAZfvayGL::nGTmK(double ShYdtQzif, int THFjsTYcEuIR, int AyphfjiCzXpfZL, bool rOaOy, string QiXwR)
{
    int rOpWYhsQEO = 1243786968;
    double QZKoCiVrOuCRtd = 1007859.0392454787;
    string AMmOGfH = string("iainXHmfqqROHeweJpChPyXarlUTUTfPudOZFJylYlgAfkHKjpbQzDLljFAryqWaisyQXWDZqChXGuzXRRTgpQUGNqgsIs");
    string qdCNgG = string("MMQDbwLoWtiGYdfnKPdyrUuiKhpKdVuYODbuZNjFYOpVSUrZcijgLdpKlPKZWFMQBqvDXHohmNBflViBgZtCAXjYrtpJpIVWGTFHOLcUPMgEZPZuNDHmkFQVirSDByJdUQiZcxCYRdTFNehikEdbdENpa");
    int ZHpeoyYH = -1967916069;
    double ynhLWWgaTRlmOzKL = -1020484.2526758073;
    int QQRUZnleAiGhW = 290336145;
    bool YAkNNyyaomn = false;
    bool TUsOsPKzXXJgnc = false;
    bool KbopyUYr = true;

    if (QiXwR >= string("mdKJNxMUQxhdkrhRHaskAFYhIlsloKfMufhTTAhkPXfDpB")) {
        for (int xglSSRkvarcpbah = 753378264; xglSSRkvarcpbah > 0; xglSSRkvarcpbah--) {
            ynhLWWgaTRlmOzKL *= ShYdtQzif;
            AyphfjiCzXpfZL /= THFjsTYcEuIR;
            AMmOGfH += QiXwR;
        }
    }

    if (rOpWYhsQEO <= 290336145) {
        for (int RHRWmmG = 757923443; RHRWmmG > 0; RHRWmmG--) {
            rOpWYhsQEO -= AyphfjiCzXpfZL;
        }
    }

    if (qdCNgG > string("mdKJNxMUQxhdkrhRHaskAFYhIlsloKfMufhTTAhkPXfDpB")) {
        for (int zFkyoawCIQtG = 408553759; zFkyoawCIQtG > 0; zFkyoawCIQtG--) {
            continue;
        }
    }

    for (int NOCJaZ = 1035520279; NOCJaZ > 0; NOCJaZ--) {
        QiXwR = QiXwR;
        ZHpeoyYH /= THFjsTYcEuIR;
    }

    if (YAkNNyyaomn != false) {
        for (int JCvvrGSZmIaHKo = 1206181582; JCvvrGSZmIaHKo > 0; JCvvrGSZmIaHKo--) {
            continue;
        }
    }

    for (int bCTUK = 2068776513; bCTUK > 0; bCTUK--) {
        QZKoCiVrOuCRtd += QZKoCiVrOuCRtd;
        KbopyUYr = KbopyUYr;
        YAkNNyyaomn = TUsOsPKzXXJgnc;
        THFjsTYcEuIR -= THFjsTYcEuIR;
    }

    return QQRUZnleAiGhW;
}

bool UqSbHuAZfvayGL::IdJlbmzyuvD(double VTtfgrkT, string jajkWezNaOEBWeI, bool kVMMdA, string XBeKxRLvpqHjWA)
{
    bool KnQsjNpDkmakb = false;
    int xTVRjimEFNJJ = 489788546;
    bool yUaxNIYTHyE = false;
    double ffKWBNiwynk = -87394.1673712258;
    string cRAOuJ = string("WMMvPnUyANvnXuQeAoySwHiKHsFscEPxFIjorwNxIqRrEoulCUOmUkcldTvUJNObsQFYkqRQgIlVNmUswaEYPQGRZiMwukweqRMoJwKsmrszMztaBZnAUNUFZKDYOYIkcmKgnJAueLtxpQTQsWKtGvdkJKjArjiZlGASicSBoPUYRcfYUOQRpJlVqgiAUJxqmkUUKaVwscUssBRUtmtEoNeullutdWMvVCsRhVzUbrW");
    int KVTfNdYU = -882161331;
    int CfUTxh = -2016325667;

    for (int gwhSsIKhkJMPuFmZ = 1402855476; gwhSsIKhkJMPuFmZ > 0; gwhSsIKhkJMPuFmZ--) {
        kVMMdA = ! KnQsjNpDkmakb;
        CfUTxh /= KVTfNdYU;
    }

    return yUaxNIYTHyE;
}

void UqSbHuAZfvayGL::ZxTML(int JFOhDhXBzt)
{
    bool ppGMqZvlBf = true;
    bool uaTvRQRBIjxIgtO = true;
    int SWdKF = 132812269;
    string wIhXmTbZeNoCSwia = string("yVPplufEhgYnRUgQJiKELeqjJSLQjTeyBaWOHnFagjsPvGkEukpTrBwoihgjLqJejhcpWxajStSvulLmUwWQENIGknbKPAJjtCZSqYOyavKvFIfgLZHojKzUqjGCYIssNSUHDfvEYniUePuSVZOlqtcruXEukpIbWPNdFCPCvRRunlMjkwaLPKUmGFJPBzGTGTvsoCkKc");
    int SyrgUbzumMhM = 2010676169;
    int oEYLEUKN = 1247871346;
    double ULDMMobLAQEEKGr = -477603.0069568273;
    double XFbIY = -260043.98011033022;
    string vvSLwyLxbdan = string("AwnhgIEseJpsdJJbdXLdOSBJBhmaRiTtEXaJmwnNsdJUhSjEHSYpMCcfYNadSoqKjGrIAjKJSfrvDXjFunsSsgIEmmUCqaHfmEfZHygvhYBDMjVcbvYNxSBDKPivLnqyLhfBDSCbqGHTsbNXPTAaywUCWZuUgcsRKeBmVhfouXUpLngBdDQOpBpkOpwsNMHadskGfkzLIaGy");
    bool lbGYLZt = false;

    for (int CBlAyc = 427899080; CBlAyc > 0; CBlAyc--) {
        continue;
    }
}

void UqSbHuAZfvayGL::CIxAOQV(string hrULZf)
{
    string ebhmhXsQnWz = string("ohTtdxgQrCNvjLCRAqwcoQyXYwGQwAxrzsLZRPHEIwkTgYoJy");
    int SIMFmjmLbbvl = -810958269;
    bool DuzXheSKOCSo = false;
    double GKLjmoYVfAMSviJ = -212769.29982730196;
    string GwwfKaLue = string("MydLBdspKGAZdrvYPEoDdUWMMYtjBZkD");
    bool xpoJdchKO = true;
    double yMEHnOfIgVXSUR = -750255.8737528066;
    double SgRUIGvAV = -10954.337731672176;
    string CFiBPtxoPLRbfduq = string("PLKPrzXzhCphydvsFXbyuumfSgcRIXMfKKkKShNsjEnYOOHubvnjttuYSigghQFGzZCnXxzSDkYcimFqMgVlfJhSEAaKEAwSLiibhCZlQRxpLcqxh");
    int BpQLEfXkN = 26888456;

    for (int qZNYeurmkXucy = 1801779644; qZNYeurmkXucy > 0; qZNYeurmkXucy--) {
        BpQLEfXkN -= BpQLEfXkN;
    }

    for (int IvFeldbSegkoUI = 2092450455; IvFeldbSegkoUI > 0; IvFeldbSegkoUI--) {
        ebhmhXsQnWz = GwwfKaLue;
        BpQLEfXkN -= SIMFmjmLbbvl;
        CFiBPtxoPLRbfduq += hrULZf;
    }
}

void UqSbHuAZfvayGL::asixz()
{
    bool ilHOIHjpqzooW = true;
    int wcEyr = 2082148702;
    string pmfZLEXKMT = string("byZmGzKubPTfmcqVFihBcrDbvXMTjbFdFiHlAZimSJTYKvubJKbDKqAkbSLjLmmHUWHFjRIvmrRWhjqodqNQUSHwmNFzqegZJcgfdNSUYOLDXQmAPdWNoMaAuPOmlOfjfPhlTODBExFvnUMFBzAgffNoaVaiasYdDRrhzOPvrJSB");
    bool pWjIAcCNCpslKzYw = true;
    string YocjJzR = string("jHfJMYRUsFaFJuuaBAOGgylGDeurzSlxbBBEbotPFMMIcHbXHNKxgJQfEqQQDahHsZiGZlwxsCNqCqwIPEziLZcGqyfwIoMdkSRybSgfWfdBsGrRoEqaaHpWekePvkGrdOBfgGeWhtQDRcQ");
    double LeaWV = 758950.7618340689;
    int mnDGm = -1745260817;

    for (int rkSChVfsnXowVSq = 438721770; rkSChVfsnXowVSq > 0; rkSChVfsnXowVSq--) {
        wcEyr = mnDGm;
    }

    if (ilHOIHjpqzooW == true) {
        for (int hLONpDGMdYzwBE = 1393037081; hLONpDGMdYzwBE > 0; hLONpDGMdYzwBE--) {
            continue;
        }
    }

    for (int cxsBtauLyaHxgaS = 1535405733; cxsBtauLyaHxgaS > 0; cxsBtauLyaHxgaS--) {
        continue;
    }

    for (int PIDtZlnSKJ = 372931477; PIDtZlnSKJ > 0; PIDtZlnSKJ--) {
        continue;
    }
}

double UqSbHuAZfvayGL::KMUWIQWPfgkDC(bool OkUDNInmtRVqNB)
{
    string eZZOHPYrbUONqon = string("fXLZZTACnzBFadebVJGrBCuBeMfXSwjUehZdrOjaXxbmNRSQReRXqpKZbbobZkkTIpaCaoMwxocQNXZBndqxaTvWXlQdjKPlAsGGvIzAeIyHsPdHUPLoSSlHNtybhHpYjvADXMEVhxnw");
    bool PqPjgRlyxinQ = true;
    bool RSUcBosk = true;

    if (RSUcBosk != true) {
        for (int gXjiT = 54569499; gXjiT > 0; gXjiT--) {
            OkUDNInmtRVqNB = RSUcBosk;
            RSUcBosk = OkUDNInmtRVqNB;
            OkUDNInmtRVqNB = ! RSUcBosk;
            RSUcBosk = RSUcBosk;
        }
    }

    if (RSUcBosk != true) {
        for (int ztaoNwplAVBBOi = 1821067265; ztaoNwplAVBBOi > 0; ztaoNwplAVBBOi--) {
            eZZOHPYrbUONqon = eZZOHPYrbUONqon;
            PqPjgRlyxinQ = ! RSUcBosk;
            PqPjgRlyxinQ = ! OkUDNInmtRVqNB;
            PqPjgRlyxinQ = OkUDNInmtRVqNB;
        }
    }

    for (int NqCBFlecCmbtE = 631442713; NqCBFlecCmbtE > 0; NqCBFlecCmbtE--) {
        PqPjgRlyxinQ = ! RSUcBosk;
    }

    return 546169.0156983173;
}

double UqSbHuAZfvayGL::dKvpRsyGu()
{
    string RozXTkhvTatRVavz = string("JqtxBzqBZQlVHqxEVsTicEuoDeJAMZvfPvOvKlmKVgTvziABcQYcWAFeqSrlhUwYZlwdRKGoXwPYMnnwkFzkMDVGODewuykGvLFCmIzdvwaFvprFKXFlsYLVmCEhnANUGcNfiYxAkQbgRvVFaiMEYesTebYKCriqVYJcUzEDlNWFqXTPhXhlyRdGcNuIXBVINaGoXWbQJxyFdODZQBexIaosvQVvdhxKBNHTBlNlUQXMbTadrhehmnTuHvLV");
    string PhpusAs = string("uKwWyIjKPFAkMYjGBamolHoyewMuRBurbRBGNgXhmJBjnlTOFXeRLhtmcdMLSqNkzcumNufczukSXPRklMMxPJsiIuCNsMKbzdnOTXnLuN");

    if (RozXTkhvTatRVavz < string("JqtxBzqBZQlVHqxEVsTicEuoDeJAMZvfPvOvKlmKVgTvziABcQYcWAFeqSrlhUwYZlwdRKGoXwPYMnnwkFzkMDVGODewuykGvLFCmIzdvwaFvprFKXFlsYLVmCEhnANUGcNfiYxAkQbgRvVFaiMEYesTebYKCriqVYJcUzEDlNWFqXTPhXhlyRdGcNuIXBVINaGoXWbQJxyFdODZQBexIaosvQVvdhxKBNHTBlNlUQXMbTadrhehmnTuHvLV")) {
        for (int cYzborKWYbmtsBKp = 1889558776; cYzborKWYbmtsBKp > 0; cYzborKWYbmtsBKp--) {
            RozXTkhvTatRVavz += PhpusAs;
            RozXTkhvTatRVavz += PhpusAs;
            PhpusAs += PhpusAs;
            PhpusAs += RozXTkhvTatRVavz;
            RozXTkhvTatRVavz = RozXTkhvTatRVavz;
            RozXTkhvTatRVavz = RozXTkhvTatRVavz;
            PhpusAs += RozXTkhvTatRVavz;
            PhpusAs += RozXTkhvTatRVavz;
            RozXTkhvTatRVavz += PhpusAs;
            PhpusAs = RozXTkhvTatRVavz;
        }
    }

    if (PhpusAs >= string("uKwWyIjKPFAkMYjGBamolHoyewMuRBurbRBGNgXhmJBjnlTOFXeRLhtmcdMLSqNkzcumNufczukSXPRklMMxPJsiIuCNsMKbzdnOTXnLuN")) {
        for (int CtACmEVOej = 175536600; CtACmEVOej > 0; CtACmEVOej--) {
            RozXTkhvTatRVavz = PhpusAs;
            PhpusAs = RozXTkhvTatRVavz;
            PhpusAs = PhpusAs;
            PhpusAs = RozXTkhvTatRVavz;
            PhpusAs += PhpusAs;
        }
    }

    return -175600.4065295512;
}

double UqSbHuAZfvayGL::ylvzgd(string iWooMlqTzkFHhcd, double QQItiaDFlZcWopBB, string NUUCVBWRnOBg, int EtAFYkfOSloA)
{
    int HQazkkLKxL = 145634253;
    int nuzFF = 1660975894;
    bool CvqFFVRhv = false;
    int DwGHOW = -1432383325;
    double tgrjSriPsZKNVKWW = -273500.64114491927;

    for (int LOYkJ = 876884113; LOYkJ > 0; LOYkJ--) {
        DwGHOW -= EtAFYkfOSloA;
    }

    for (int mEmdqSp = 365112257; mEmdqSp > 0; mEmdqSp--) {
        continue;
    }

    for (int pZLXYynnuCB = 243173874; pZLXYynnuCB > 0; pZLXYynnuCB--) {
        HQazkkLKxL += nuzFF;
        nuzFF += HQazkkLKxL;
        HQazkkLKxL = nuzFF;
    }

    if (EtAFYkfOSloA > 1660975894) {
        for (int cgOzDbWObaAa = 2099116045; cgOzDbWObaAa > 0; cgOzDbWObaAa--) {
            EtAFYkfOSloA = EtAFYkfOSloA;
            DwGHOW = nuzFF;
        }
    }

    return tgrjSriPsZKNVKWW;
}

double UqSbHuAZfvayGL::djnmeEfejdvlk(double KSfAQGvaBVZjgbT, string ngYAC)
{
    string kXwcaKcXCNVdUq = string("GcrLYamkJAVxudctlSSYlfHVxsyeUMXLUUXVdrafHSVgkeBlpQCWxAPaujxZoAFnlae");
    string wVMVTGHQykadzFHJ = string("vPubEaguhDBQbfJnftrJrqcenDPOkfLIvtSspaeHnlomHspKVstYaZDpFWCQTjdCnavGbFqdzklfDMkUhtsSXQzqGqerIqMtkcaHRDTtiWYQenwEKrYdLfkrreeGXIYtGwkmqoPDKvUUxV");
    string iSJjSKrXTgoO = string("gOPicJQUXyqrxUnkkOdoQkwsTuVNKPgBBVMoXqxekSjIrBVGJRJlHabjbcEUtvINTRJjGqpfEylkQXQaLqaXhMkDchDdAJRRlERVNAaPZjjwCFvhFfTeCUeVRXBQIYGwVFYNPzFOySpEnqRWTuWAJqOATT");
    double miEGOeXt = -302968.30392524804;
    double QzXnJhUwsXDf = -120254.91458637614;
    bool cJkQoTUmKf = true;
    int FHqSvKOKTF = -95552796;
    bool bJLsmTzMTXURJ = false;

    for (int lOyDcwhplo = 1654034965; lOyDcwhplo > 0; lOyDcwhplo--) {
        QzXnJhUwsXDf = QzXnJhUwsXDf;
    }

    for (int pVwLvZutAndJOa = 1563206627; pVwLvZutAndJOa > 0; pVwLvZutAndJOa--) {
        KSfAQGvaBVZjgbT *= miEGOeXt;
        iSJjSKrXTgoO += kXwcaKcXCNVdUq;
    }

    for (int NcPMDqYA = 2076650379; NcPMDqYA > 0; NcPMDqYA--) {
        continue;
    }

    for (int vJYyGtHXtBpaQJ = 377049997; vJYyGtHXtBpaQJ > 0; vJYyGtHXtBpaQJ--) {
        continue;
    }

    if (wVMVTGHQykadzFHJ > string("gOPicJQUXyqrxUnkkOdoQkwsTuVNKPgBBVMoXqxekSjIrBVGJRJlHabjbcEUtvINTRJjGqpfEylkQXQaLqaXhMkDchDdAJRRlERVNAaPZjjwCFvhFfTeCUeVRXBQIYGwVFYNPzFOySpEnqRWTuWAJqOATT")) {
        for (int ARGgYwcBNDXQPz = 395944911; ARGgYwcBNDXQPz > 0; ARGgYwcBNDXQPz--) {
            continue;
        }
    }

    for (int hEIeB = 1879051345; hEIeB > 0; hEIeB--) {
        continue;
    }

    if (cJkQoTUmKf == true) {
        for (int cOsFovPYlvRdiKF = 233728919; cOsFovPYlvRdiKF > 0; cOsFovPYlvRdiKF--) {
            kXwcaKcXCNVdUq = wVMVTGHQykadzFHJ;
            wVMVTGHQykadzFHJ += ngYAC;
        }
    }

    return QzXnJhUwsXDf;
}

void UqSbHuAZfvayGL::lUIlTMhgEuSqfn(int aJXJRhTzVS, bool llgyuA, int olnBjbWtl)
{
    bool EvaBwvHzJCpuSnL = false;
    int JSwyjWthjH = 685916304;
    int eloucqfKTWaz = -961611105;
    double sFrQTLVrLVTthWt = 495723.78462315927;
    bool WvBRKhMHBYjWm = true;
    int uFKKsBwRiiPscFYT = 1477157565;
    string mrVEVnCPRWeYWuhN = string("juSVetwRDexMafaaTbAAerdwgcZtiyTSZvEfcnZtbCIqXWZvhYPbRfYkhUrApTgkHkHKeCHxWyljCwObVQnBDLRVZcQrJmmWsfeLMCEaoWpmPQFwLWBoioUtnxPmSJjGNmwuEDnMJJlvhhJpthHPIazPWMXnSqDGjTKEOXykTgjAxzMNFmrarMgOjBspRxdArpJoqFJTITTnxmeRVQpeNpfssh");
    string JaHQLbZhsPZoCVO = string("cPODUogYAGQzAZuhkjhPhtDqCGvrBlASOvFlvgyYNiXZMfnOqAoRQrEMutqnlomiyUiTTHWiVrjPHeuhKFiIQnypuraVtdAPfEuuyLaoaGfPpfLPzkmKKqivGuNtbfh");
    int kmYRVnzgqd = -380462768;
    bool kNGacnXKBtDHtcq = true;

    for (int TzSodEWJHxK = 69890701; TzSodEWJHxK > 0; TzSodEWJHxK--) {
        uFKKsBwRiiPscFYT -= aJXJRhTzVS;
        JSwyjWthjH -= aJXJRhTzVS;
    }

    for (int vspnAHs = 625477912; vspnAHs > 0; vspnAHs--) {
        continue;
    }

    for (int qjgYQklpHSH = 1812462454; qjgYQklpHSH > 0; qjgYQklpHSH--) {
        llgyuA = ! llgyuA;
        llgyuA = ! WvBRKhMHBYjWm;
        kmYRVnzgqd = JSwyjWthjH;
        aJXJRhTzVS *= uFKKsBwRiiPscFYT;
    }
}

string UqSbHuAZfvayGL::VrCMfTADcDwpkyFw(string uwDQYfjEdkI, int RiXFnjKWhvdkt, string nvvgWvnktjHvjEu)
{
    int evmfNhlde = -1394790793;
    double jsiiaItkbo = -530163.1621900037;
    string nqttrYoWqbp = string("dNKqjQriaJOBdOSzBnQCmcEqfcSKIpQFYUdVVthlceHTVloRdfOOMfOgVWzpvecSfLnErTDulJNcAnsHVhFZEhHcmzXkyuginEIOadNpTdfMJeIfXlrMnTQmlIepqZzPBpFUmKrLEViHupYMi");
    int GkLUFaMBBQ = 1089794484;

    for (int ihmBiALgaRgVgf = 105405495; ihmBiALgaRgVgf > 0; ihmBiALgaRgVgf--) {
        RiXFnjKWhvdkt *= evmfNhlde;
        evmfNhlde += evmfNhlde;
    }

    for (int QhVEGGbpcwLGCUUX = 1129976138; QhVEGGbpcwLGCUUX > 0; QhVEGGbpcwLGCUUX--) {
        RiXFnjKWhvdkt = RiXFnjKWhvdkt;
    }

    if (GkLUFaMBBQ >= 1089794484) {
        for (int zbbBivGzhAl = 496768557; zbbBivGzhAl > 0; zbbBivGzhAl--) {
            continue;
        }
    }

    if (evmfNhlde <= -1309539341) {
        for (int EnzmHlohiwPwA = 1313799912; EnzmHlohiwPwA > 0; EnzmHlohiwPwA--) {
            evmfNhlde = GkLUFaMBBQ;
            uwDQYfjEdkI += uwDQYfjEdkI;
            nvvgWvnktjHvjEu = nqttrYoWqbp;
        }
    }

    return nqttrYoWqbp;
}

string UqSbHuAZfvayGL::VdsUMRljNUGIPthZ(string ycGWuozSsFENdSAP, string MWYProxczBdfjRh)
{
    double YLuCJihltE = 439530.6291839351;
    double xdeGapitvBp = 740189.2214701591;
    double JObNZluEMxpHyKN = 497821.98901601555;
    bool RaaSRIGlvhNWupGt = true;
    bool DThoVuG = true;
    int OgugKpTSUaaT = 785152278;
    bool NdFUFVTEgiMXy = false;
    string PSnwAhHWf = string("AfXKxhxzfFGsmwYalVVigIilMxzCesurHQJOLOhQBzpOVyzlCFmsOzNREvvmbHWUbuMSajUKsqDJVUfdkBqzTjMbwAKKSlDTXPqWuzPGyBmOuOJibnHBpHjIOJCUXuChsyNdJGBMFKPhbHaNfnKgL");
    string yTKxRoOuxBfvF = string("hDgwpskMNbdcktxtFBZvmVgzHPceDUCiBuBokUgVERttOAyiOxnFkjkUsGVQsykKOhMdyHBjsapNiBjFiQBfQTRBtmbqroDoPEJHIJPGFSfoWiOuXnXPeFrdVsTygSMHTBOMCXiyRZXqDPTstNQOofqoThyvzJnZdodSuFBERy");

    for (int dfQdgpCXlntes = 121769481; dfQdgpCXlntes > 0; dfQdgpCXlntes--) {
        NdFUFVTEgiMXy = RaaSRIGlvhNWupGt;
    }

    for (int voAjU = 723261611; voAjU > 0; voAjU--) {
        RaaSRIGlvhNWupGt = ! RaaSRIGlvhNWupGt;
        MWYProxczBdfjRh += PSnwAhHWf;
        RaaSRIGlvhNWupGt = NdFUFVTEgiMXy;
    }

    for (int nBJEKzlArAoihSI = 904568432; nBJEKzlArAoihSI > 0; nBJEKzlArAoihSI--) {
        ycGWuozSsFENdSAP += ycGWuozSsFENdSAP;
        MWYProxczBdfjRh += ycGWuozSsFENdSAP;
        yTKxRoOuxBfvF += ycGWuozSsFENdSAP;
    }

    if (ycGWuozSsFENdSAP < string("hDgwpskMNbdcktxtFBZvmVgzHPceDUCiBuBokUgVERttOAyiOxnFkjkUsGVQsykKOhMdyHBjsapNiBjFiQBfQTRBtmbqroDoPEJHIJPGFSfoWiOuXnXPeFrdVsTygSMHTBOMCXiyRZXqDPTstNQOofqoThyvzJnZdodSuFBERy")) {
        for (int IOzVSsVU = 106929312; IOzVSsVU > 0; IOzVSsVU--) {
            PSnwAhHWf = yTKxRoOuxBfvF;
            PSnwAhHWf = MWYProxczBdfjRh;
        }
    }

    if (YLuCJihltE <= 497821.98901601555) {
        for (int HoqSEyxySiajp = 26944621; HoqSEyxySiajp > 0; HoqSEyxySiajp--) {
            xdeGapitvBp += JObNZluEMxpHyKN;
        }
    }

    for (int kRAza = 405561574; kRAza > 0; kRAza--) {
        RaaSRIGlvhNWupGt = NdFUFVTEgiMXy;
        NdFUFVTEgiMXy = RaaSRIGlvhNWupGt;
        YLuCJihltE += xdeGapitvBp;
    }

    for (int jGUtymcK = 1117134927; jGUtymcK > 0; jGUtymcK--) {
        yTKxRoOuxBfvF = ycGWuozSsFENdSAP;
        PSnwAhHWf = ycGWuozSsFENdSAP;
        ycGWuozSsFENdSAP += PSnwAhHWf;
    }

    return yTKxRoOuxBfvF;
}

void UqSbHuAZfvayGL::aELTsMBfwfKGKU(string DhjGHFXeALIq, string ByvLj, bool hvxArfVfGCMKXO)
{
    string OiblTCFSnTomMyr = string("GUrzrLMVzEkcsZgVGQqQZXrKFqMuddJTCKbhxXqoTZunDdXUeOvYzAMbriSpfZUYUIrykJsCRERMVjBhIfltG");
    double DCDPArSjwRMsOmY = -594448.7424116677;
    string fHuPZJr = string("tPtjEXlEtDeBQBMypEorLjUMCMQXFuLdvklnVrlwkUQilaYlknihENYcDrKkFxUFXxGHvDQRBokxSHkeIhplTDGYrUxzRHEukPwKJeekKwxNwgnTuTfoocKFMAVFDImWIvIncltrCVMWAQhuOYMmuNXVAGeEuNkgXpPFlZTCryMFxaZgwUXVpNKvhRJTsVCIilIRruKuzHgeboehrNOGXqsi");
    double OgRGXhBqPfsFNxm = 754827.9822922203;
    string upzossfEyXkVOcE = string("yDsFXldMEsmxyfgpdjotBbohyDEUbpIVzfzjSesLIvazoAmmAAWTsDmXKUKOXnQcGeJQfuTHovimhnsdducXhOyfyInChutCeLMZpSaoZvuXQhPyHehYSwQcUBdKFyHAyhekHYwlSYKlgnuoCliEQoxaQ");
    string UAVNrLsICDDcB = string("jxXaepEqGLXDibMMNohBGfqoykZNyvmtNvugGRatOKvDWYViATApKTldtRZOYbYIMzxxaxHpzsSncSOTdtpzSqhMwokEPuhIwtFtMInJWkiZMZNpgmhOymPxoVawLjHvavLKIWCohtSdlHZyCZoyxbWTPeUhFjWjEGtbyDetoXNRIjGWEOVMUjGVzfiYDLkNSMGYmomm");
    bool rrxGSgxKLA = false;
    double OKIwsfxfBFs = -838682.6132693664;
}

bool UqSbHuAZfvayGL::YbECOfWdUrnc(double hTaWMTzub, string iehuRGNUyrSzR)
{
    bool EvxFPqcwEVgkJaf = false;

    return EvxFPqcwEVgkJaf;
}

double UqSbHuAZfvayGL::NFgXTQZguOtMwt(bool IyUCyGGxIPcOcY, bool ZavVZhTY, bool ecTJXNtGB, int BCwZhPvePVFQS, double UBDcSigLHyKGbxs)
{
    bool ykgvpAKxdHJd = false;
    bool wcghZqp = true;

    if (ZavVZhTY == false) {
        for (int cykKmHsVrA = 1533449994; cykKmHsVrA > 0; cykKmHsVrA--) {
            ykgvpAKxdHJd = ! ykgvpAKxdHJd;
        }
    }

    if (ykgvpAKxdHJd != true) {
        for (int lbWGj = 378596800; lbWGj > 0; lbWGj--) {
            IyUCyGGxIPcOcY = ! ZavVZhTY;
            ykgvpAKxdHJd = ZavVZhTY;
            ZavVZhTY = ecTJXNtGB;
            wcghZqp = ykgvpAKxdHJd;
            ecTJXNtGB = wcghZqp;
            IyUCyGGxIPcOcY = ! ecTJXNtGB;
        }
    }

    if (IyUCyGGxIPcOcY != true) {
        for (int jYXbUXpZoEo = 1041541785; jYXbUXpZoEo > 0; jYXbUXpZoEo--) {
            continue;
        }
    }

    return UBDcSigLHyKGbxs;
}

UqSbHuAZfvayGL::UqSbHuAZfvayGL()
{
    this->ZWfpPCHhTK(string("fHrxvaysYFgWMKFjTDBCXetTjiqmLVFGeFuVWpJfOaedxDasaInlNAdxB"), string("TgceIFFVRlfMbsSaSkwzOPGqiwQrEuurrlSNgJEQmTmvxgNsoEJRFEXSKkrpH"), string("iKrJRYodUWoRxilNKoCkoDlOtkBQzPaMWPFTCkesOXFfeGixWehKdPrZuqJpWXerpaqktCwPjMbSzmUysRyMEbwFogYlqVURshUUvwYIfdRYKsZKKxoFtHFMb"));
    this->UYkIfQFurFo();
    this->nGTmK(-921443.9522709087, 1145315660, -424367622, true, string("mdKJNxMUQxhdkrhRHaskAFYhIlsloKfMufhTTAhkPXfDpB"));
    this->IdJlbmzyuvD(12588.51033819143, string("iNeLBRqHxqVbslbKurRwmPvoCFOdZLeBGWKdpbFvWYhmeKyYhTxPjlOpQDJfxbXxQDvsuNyHxETBicszYvPVnGNbRqaUvUIISRJOnqMIKXb"), true, string("bDByzLKpbDISBYDGjkpGGGMsduHkDXvPrHjvFHbxmHIcptGslVeQzYNlxTUKflYcwhDSbCsqTTcPcLQznfCXieAJlwbNhHsPbMEaEHSDnxLfsKbbNOGwiOYYwPcBCOFeIVSuCWhkEnrJyQSLjvrQGfyFLOiDFSLZUuStpUzxRypVmwcYmMARzpLeDFuqlmaaacILlPFJCihRSTOuwZhrYhEaAgU"));
    this->ZxTML(2031639061);
    this->CIxAOQV(string("wKGByofePDrhojwKToQoUbbXjvNqzLPkqNICIkeWIAqGZRgtSayxKIDXXaQSYoTHgrIyYwCAPosFcxQsGNZQ"));
    this->asixz();
    this->KMUWIQWPfgkDC(true);
    this->dKvpRsyGu();
    this->ylvzgd(string("hmHwUjYt"), 356385.4393881327, string("jyuFgTiOOelPKBGkKLIWsCoVKGqKOEeYosyxJVAHDYBRfpZFnWxJWDh"), 921856375);
    this->djnmeEfejdvlk(-581290.0525934764, string("OXWIHVhPMlYdQZGEcaxxBdRqJYzCWZdFnArYnUpwKGcrINcCPNeLRHYTAAIlhmPQCmdbCLdAgnqoyTPCIuZKDDgFaKCScUFNrBvntBgQsriBIrnwGcFwWEkhcCZNOjgXCAighGwoRoAcJPfyUnFnF"));
    this->lUIlTMhgEuSqfn(1299061220, true, 1455826688);
    this->VrCMfTADcDwpkyFw(string("TShyEcGYSZwxGfvqphjAe"), -1309539341, string("lxVDCMRtvPyjHRtMXNIZKdwueAjsAFfipgGjOELebgWAxMrwCLhOtChcPXEOmtCSKCjdnFbLqgjVbBLBsxIcHKZpbqJCHEWglwbiBvBLajjOYEBRwPikGKqlEsXdygFxLbXpKfFXLYbQEkNAGxScofzWSzaJFgS"));
    this->VdsUMRljNUGIPthZ(string("tPpLOMDCRKSlTHrHmTWzwdUvnypFsfuyNUuvGBWBnnXaUiOMnfkhbCNEMbKtmUtjbMBkyPLJYyDimLiPmrLpVQDRMqIkXUofLFHeJuifdhYhyCiTLiwJBUHGRFrDdklbzyc"), string("bKSIchmtjrKJbvlhfTAxRjHjdCOpVFCywUtoYVWshBpJUzPiOPrtnTIYlRHPuzyEVYUzbEGgeUjurjdqDIiIhIkfvGZhEAIbKkEZXicKghJJxbbeOGusdZDoFxljpcgFxPiCoJJHpAPHfPOsnTVdxxXxMpmZLJwIGhGerIHFzsXnFmeLjQTjmXKNuREvbNYINcABRIEhSsxYjBDdUEYnLijulqvQsyXFa"));
    this->aELTsMBfwfKGKU(string("HQAhYpqhZssBnVeLSlYlpxQvyFfgI"), string("nFBxZRLXONqRZApbCaIEYGpmgSkKSSFpaqtONWsZwXGJVqYzmBhTPafJJVBNLOFUImLqlMCQArVcnxGmkuBBUijDyigCjeOGWgBsBMXESuTMxVEFpQQrHUqOioNPEVfqNLedRQTrWzzUHHObriExJbsVStlXshWxvsSIJBFcAZEjQCsnuNprLrGybaYrxrqYZkYngqpgZyvWwtJgRjThBONQSgXjVxusGzIrVZPBGVlCQDpXUtsuwKk"), false);
    this->YbECOfWdUrnc(879631.2306648908, string("XRsLdcRVoLGTkgiiMOydKRsrMIdLhsntvsWBYUSYaGXRoHIvIQzpCbWpHQeYOcvTPPJGHhyEYUSpQQMDzWIzHXLAeli"));
    this->NFgXTQZguOtMwt(false, true, true, -1164537851, 810749.5375331168);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BxgBpjeqph
{
public:
    int xRITEvOuM;

    BxgBpjeqph();
    bool QNBPbBJtOXqPKqP(double yyEkAUUAK, bool jIAbnETSlJR, double BVJMjnCe);
    int pXzazgNwvGoAgozw(string HKQTNDBc);
    bool ljRnLSE(double YSyCnHVkNM, bool nDFwVydkghHCP, double AskrGR);
    double xJtaMfyleG(int XJdMRJgUSceuAcIf, double qefUKzAsh, double nTAEEOxjVuynXz, int lkRNchDEmUIyFRj);
    int igDPwqWgthKk(bool JlLpwAExE, double MgBkIE);
    double nksjDAvS(int mGRxn);
    double JizYmZrgMhO(int wRAJCa);
    double XhieRutBdye(bool yubdUeuQ, string vYiJUteLpTEXg, int tqhdwxbS, bool UuarSwSschtikD, bool XfFRodjOnB);
protected:
    double KcHWmvJtwpTN;
    string QLlLVuB;
    bool ttrUjnjJg;
    string tqRmFtxtZA;

private:
    int juNEeQYV;
    bool kwEXmyM;
    double YKZqo;
    int HRqRvey;

    void OZXfcw();
    void jZsoHei(string tNitkoEr, int aPIgyvythkEDsf, double vnOBabGOKp);
    bool msRcJlnPWGciJEt();
    bool ycTmRFq(int MqRFtnOMJ, double HTHlACfE, int dASYZvgb);
    string MJBVw(string wdGsO);
    void tteabALQbjI(int pvThFubmmfuH, bool WtMkZaGusGU, int AmbHigJuVzXMTgzv, string SIZyqrKCuU);
};

bool BxgBpjeqph::QNBPbBJtOXqPKqP(double yyEkAUUAK, bool jIAbnETSlJR, double BVJMjnCe)
{
    int KEciot = -368560138;
    string YoKgzYfClQfa = string("KkWmuEKeyhKSSTlBcSntWaBczKsKtstCNdND");

    return jIAbnETSlJR;
}

int BxgBpjeqph::pXzazgNwvGoAgozw(string HKQTNDBc)
{
    string bXcqeakWw = string("cAgdvQXRodWPsyruwPFmAZfjHdHgJWdjRvhvwTJslTViieOzpFodWVpfKGMKzHugGEDfpLfHGMniUCUerxzoClWDmedkPdqTrXmRzIifBEQkMOPxeXGPzCuLEJcqrrzpqbdztAZdBSPiWIKCjhqvhFPjrrqFpBJHXCqCaJwptFvdsHN");
    int TDdvVpwnnzQ = 404015643;

    for (int jlOrPmj = 2061487106; jlOrPmj > 0; jlOrPmj--) {
        continue;
    }

    if (HKQTNDBc == string("cAgdvQXRodWPsyruwPFmAZfjHdHgJWdjRvhvwTJslTViieOzpFodWVpfKGMKzHugGEDfpLfHGMniUCUerxzoClWDmedkPdqTrXmRzIifBEQkMOPxeXGPzCuLEJcqrrzpqbdztAZdBSPiWIKCjhqvhFPjrrqFpBJHXCqCaJwptFvdsHN")) {
        for (int AuiKGLxNBdew = 666068047; AuiKGLxNBdew > 0; AuiKGLxNBdew--) {
            TDdvVpwnnzQ *= TDdvVpwnnzQ;
            HKQTNDBc = HKQTNDBc;
            HKQTNDBc += bXcqeakWw;
            HKQTNDBc = bXcqeakWw;
            HKQTNDBc = bXcqeakWw;
            bXcqeakWw = HKQTNDBc;
        }
    }

    return TDdvVpwnnzQ;
}

bool BxgBpjeqph::ljRnLSE(double YSyCnHVkNM, bool nDFwVydkghHCP, double AskrGR)
{
    bool LIxcIbNQKpGR = false;
    string ezgqvCPethjgiY = string("kPvZczPnzAeqTibeDVFNXpqxQGPIErZXNoYThIavXogPoewpMZphOhFQGpMpuPmwZMZYmxBAuwQtcZJVFHNbcqChqgoerYTNDIjneEZabmShvhyjjMnhxSJkcZzGtUqUytt");
    double EWLLogNMg = 161083.81235794394;

    for (int FNGtSMfkJzLYNAgp = 1023758124; FNGtSMfkJzLYNAgp > 0; FNGtSMfkJzLYNAgp--) {
        AskrGR /= YSyCnHVkNM;
    }

    if (YSyCnHVkNM == 161083.81235794394) {
        for (int GmIyrtHqWMGLD = 1674384019; GmIyrtHqWMGLD > 0; GmIyrtHqWMGLD--) {
            AskrGR -= EWLLogNMg;
        }
    }

    if (AskrGR != -990666.4295949053) {
        for (int JBhTNApaVYhyZRLT = 624474938; JBhTNApaVYhyZRLT > 0; JBhTNApaVYhyZRLT--) {
            AskrGR /= EWLLogNMg;
            AskrGR /= EWLLogNMg;
        }
    }

    return LIxcIbNQKpGR;
}

double BxgBpjeqph::xJtaMfyleG(int XJdMRJgUSceuAcIf, double qefUKzAsh, double nTAEEOxjVuynXz, int lkRNchDEmUIyFRj)
{
    string gIwYds = string("jQYWNaQoHfWEyqtVIevtoczQGlchekhAZNZzFXbzIYNRQlBcsfzlKaMVGLMkBGxnGHGZwAkCMyHDNqQqELQwBVdOEWFBlRyffItvqPeIwGxxjePXRTFZQcpiirGXlCeLrhoabLojKPolxdKjFJoaziqwHbjULgyMUMLrPUsUCTDyyEMGoxeVsJUNFdBTyXIaTJwhxt");
    string NMYTklNuivhptp = string("uHVPFtDWQQCVUNJEcLBBtZJvPbmSrYUjrUdUVprpAhpQYSZvQfbVdMoZyTHDYHrvxbpcYDCHPIrmFKGtmvw");
    double VRSKOByNe = 1026908.6984461633;
    bool arCQUMCiEUI = false;
    double hxRPTgUzGyLS = 967256.5629771006;
    double gVYFA = -807130.8130181463;
    int UUIiiaTKJWXCT = -1865312498;
    double eCNewuxJsgssU = 952938.5479754955;
    int eDsnUrIdkaFqfGI = 986755808;

    for (int yGpqdg = 2008154898; yGpqdg > 0; yGpqdg--) {
        lkRNchDEmUIyFRj += XJdMRJgUSceuAcIf;
        eCNewuxJsgssU *= nTAEEOxjVuynXz;
        arCQUMCiEUI = arCQUMCiEUI;
    }

    for (int VQcKQSC = 946319166; VQcKQSC > 0; VQcKQSC--) {
        eDsnUrIdkaFqfGI -= XJdMRJgUSceuAcIf;
        eDsnUrIdkaFqfGI = UUIiiaTKJWXCT;
        arCQUMCiEUI = ! arCQUMCiEUI;
    }

    for (int jnKmGBZqRQPDRUY = 1100413243; jnKmGBZqRQPDRUY > 0; jnKmGBZqRQPDRUY--) {
        nTAEEOxjVuynXz = eCNewuxJsgssU;
        VRSKOByNe *= gVYFA;
    }

    for (int ZLjLhOrlssOxEHs = 185729459; ZLjLhOrlssOxEHs > 0; ZLjLhOrlssOxEHs--) {
        gVYFA /= gVYFA;
        XJdMRJgUSceuAcIf = UUIiiaTKJWXCT;
        eDsnUrIdkaFqfGI -= XJdMRJgUSceuAcIf;
    }

    return eCNewuxJsgssU;
}

int BxgBpjeqph::igDPwqWgthKk(bool JlLpwAExE, double MgBkIE)
{
    int ljYpGlqq = -96908597;
    string nooLuUXnmJa = string("lqQCFOXdHgyYxkcdOwBsQyOgjZTkRGVlfDxFlcMDRPycvbeulWvmIaLOaSSnsQfbrdTmunRoLnjWXwdylJXMKdoeGPmUsBLiIDFbSCLXEMxPnyHHZOGEBZDfFYUsNvJaQHYPYUiLGgERzlMPbTLQTERJglZTVThYQnSZMYVvoAJLfOeXzzapVoabcrOfdBfhIrxfQhNMQieKecNrjCGPwAVtBmvGTTxc");
    string NucekSXYiWG = string("KHylrenmixBfeaPsvkDxeEloOmQhiblPghKaWcFgiXMRh");
    bool BTDyMYwA = false;
    string oTquEfucjMl = string("VCEcihnwfeFEAiYqnVdsYPdLAQTzYLNpsuuhKUcIjaPzCjXsGbyThuJHWibQHncvLPoFtEaaFegXHAduLogNjJXoqYTXUoGonWDUFcggipBXaWOHtWfDKdkVlCsKjyWVwmEMUZjTNKwILvqyrozYlQEqCewL");
    double iGdGZUn = 890050.2644119819;
    bool yXhBHUTDaKan = true;
    string LCwhNxyX = string("PRZcDHRtrtznLPNZHzluhAOFdEvSsZZRpSHMIXCHqSsOUwzOUXuZyuGZOXUeQBnDzbdzCDdTuTUDOwrUwqEClapIGdKZgDSNTRYtdsQMZiTrZrabnxQgcQnxGsJPiOXWKw");
    int tpSLUinwoMCU = -738328164;

    if (tpSLUinwoMCU == -96908597) {
        for (int xKiEdtGvTmnxUyR = 1191969127; xKiEdtGvTmnxUyR > 0; xKiEdtGvTmnxUyR--) {
            continue;
        }
    }

    for (int VWIdQmEWlBbB = 268244383; VWIdQmEWlBbB > 0; VWIdQmEWlBbB--) {
        yXhBHUTDaKan = BTDyMYwA;
    }

    if (nooLuUXnmJa <= string("lqQCFOXdHgyYxkcdOwBsQyOgjZTkRGVlfDxFlcMDRPycvbeulWvmIaLOaSSnsQfbrdTmunRoLnjWXwdylJXMKdoeGPmUsBLiIDFbSCLXEMxPnyHHZOGEBZDfFYUsNvJaQHYPYUiLGgERzlMPbTLQTERJglZTVThYQnSZMYVvoAJLfOeXzzapVoabcrOfdBfhIrxfQhNMQieKecNrjCGPwAVtBmvGTTxc")) {
        for (int grGQIpeqDxS = 1989431007; grGQIpeqDxS > 0; grGQIpeqDxS--) {
            continue;
        }
    }

    return tpSLUinwoMCU;
}

double BxgBpjeqph::nksjDAvS(int mGRxn)
{
    bool wJRZEWCkTKLSbszs = false;
    bool QXfrRCRaJP = true;
    double MvOukrmIDm = -429467.45103259425;
    string MOgoIPEHdko = string("oyvoTJZOgLcGvrQDacabplGqgWiQlrKdNmkcHVnRBTYhNhpMdSTYPmYOvVZljAOTEBMRZGLSftQZQwlzVWOmYoKwbDTGDKHsJfvDKhdYjYEYdahsOcDlUSSLhFfEgQHtCwERSGxnffhikXLuOmhjwygBzIDcTlfwBPgcgilPpbMcdSjvVTDeWeKkOIzIHWMvBeyrWMQnSGeTNAxprUJzWjrZisjILhXtzcn");
    string HCYlbDIGLvf = string("FtCvGQGNUrTrEstBSoSfCBtqYDpETeYgfmVkCbmOCygQMogAEgEIstuKHdYGeGuBWeapMydlTPFYcpeUuIismBEAMofkFVxcvjUtcPqLweQbvGEzsfayQTazrcpzBEutUTzEnOcFzfcRrQamsjHdqJPjczSGmYFKLIKVkhKSIZnzsphyfzBszicLNDBbcOMThmDLihPCJhDKdwBTSRtFOebAcYg");
    double EQjPMaEQi = 799377.2150277391;
    double FGScuaQ = -606211.0975147926;
    string XtjDQXonLlZ = string("QblGxlofnXqUEYhuPPfeJFUYQxw");

    for (int iWMAVM = 1096037377; iWMAVM > 0; iWMAVM--) {
        continue;
    }

    for (int xHunmcVrcNqCWK = 1820104514; xHunmcVrcNqCWK > 0; xHunmcVrcNqCWK--) {
        MOgoIPEHdko = XtjDQXonLlZ;
        HCYlbDIGLvf = XtjDQXonLlZ;
    }

    for (int XVSaXYRSTA = 15597187; XVSaXYRSTA > 0; XVSaXYRSTA--) {
        HCYlbDIGLvf += HCYlbDIGLvf;
    }

    return FGScuaQ;
}

double BxgBpjeqph::JizYmZrgMhO(int wRAJCa)
{
    double BRLshDczwBeve = -595441.2646081072;
    int uUNyHYK = 1382137239;

    return BRLshDczwBeve;
}

double BxgBpjeqph::XhieRutBdye(bool yubdUeuQ, string vYiJUteLpTEXg, int tqhdwxbS, bool UuarSwSschtikD, bool XfFRodjOnB)
{
    string VbhABDFs = string("UrhAtNJIsZYutxIglapqcickFWKqyoypxLeIhBrCdAMzWFgpjbiWGJvBkceEXCweoYbYOpFapyXgBqiXoBTEBrsbvQhwXEoRAqvTTfxRKdPZaUFgstXVWZyXyXXGWlQBrLXJALpiAtYKKyglNteYgLgekIHDSxwJNqatJiBQDdrUUMqbhuLQOBEksiizoxOnfwqytNnWYgrglyUNegtkFzvbhz");
    int pGpxJqF = -749989272;

    for (int ijFbKZxSe = 1157079905; ijFbKZxSe > 0; ijFbKZxSe--) {
        continue;
    }

    for (int YWyhk = 1249956990; YWyhk > 0; YWyhk--) {
        yubdUeuQ = yubdUeuQ;
        VbhABDFs += VbhABDFs;
        VbhABDFs = VbhABDFs;
        yubdUeuQ = yubdUeuQ;
    }

    if (vYiJUteLpTEXg <= string("UrhAtNJIsZYutxIglapqcickFWKqyoypxLeIhBrCdAMzWFgpjbiWGJvBkceEXCweoYbYOpFapyXgBqiXoBTEBrsbvQhwXEoRAqvTTfxRKdPZaUFgstXVWZyXyXXGWlQBrLXJALpiAtYKKyglNteYgLgekIHDSxwJNqatJiBQDdrUUMqbhuLQOBEksiizoxOnfwqytNnWYgrglyUNegtkFzvbhz")) {
        for (int ZLZGdgHeKeV = 1760841592; ZLZGdgHeKeV > 0; ZLZGdgHeKeV--) {
            tqhdwxbS *= pGpxJqF;
            tqhdwxbS = tqhdwxbS;
            XfFRodjOnB = UuarSwSschtikD;
        }
    }

    for (int aWXHU = 89326834; aWXHU > 0; aWXHU--) {
        yubdUeuQ = XfFRodjOnB;
    }

    return -382596.50774409855;
}

void BxgBpjeqph::OZXfcw()
{
    bool RiIzKHYjXizOVXMi = true;
    int vOEwJsv = 431691618;
    int OAeuhZHJgW = 427959616;
    bool orQCjCCzTNiYnX = true;
    bool puLSWcJUaxypQpZM = true;
    double EOYGyn = -730575.0435943989;
    int DFLGKE = 1570527454;
    int ZjksyhsyMxGc = 1457171714;
    string jYFcugiZHQAfEU = string("RurfdMfgIEtblYyiVqqWxAWtfyQnjRSsNguotATlAvvRWLfJzLCFgMJfBQvlzGOqjdUoZWGIPirhKNhRczEEMqJaPBpTJTMOjIvMYzyWWxaizWULtOaEypoGjRNWXPwqUwMRNtAZPLLFEmNZoDbAQWGaQQl");
}

void BxgBpjeqph::jZsoHei(string tNitkoEr, int aPIgyvythkEDsf, double vnOBabGOKp)
{
    bool szaDBscKkuKG = true;

    if (vnOBabGOKp <= 174533.39139712756) {
        for (int xyxqYnSFfOKrL = 447447380; xyxqYnSFfOKrL > 0; xyxqYnSFfOKrL--) {
            tNitkoEr += tNitkoEr;
            aPIgyvythkEDsf -= aPIgyvythkEDsf;
            vnOBabGOKp = vnOBabGOKp;
            aPIgyvythkEDsf -= aPIgyvythkEDsf;
        }
    }

    for (int CPsWE = 1438298365; CPsWE > 0; CPsWE--) {
        szaDBscKkuKG = szaDBscKkuKG;
    }

    for (int cmXtydDWmjUqtM = 1640290038; cmXtydDWmjUqtM > 0; cmXtydDWmjUqtM--) {
        continue;
    }

    for (int NBwlTb = 2002697347; NBwlTb > 0; NBwlTb--) {
        tNitkoEr = tNitkoEr;
        vnOBabGOKp /= vnOBabGOKp;
    }

    for (int FArwjjC = 1518328116; FArwjjC > 0; FArwjjC--) {
        aPIgyvythkEDsf /= aPIgyvythkEDsf;
        szaDBscKkuKG = ! szaDBscKkuKG;
        szaDBscKkuKG = szaDBscKkuKG;
    }
}

bool BxgBpjeqph::msRcJlnPWGciJEt()
{
    bool yjExd = true;
    double rcZgoSyOj = 262695.23695531685;
    double amPIKJip = 720704.4000363896;
    bool opGpa = true;
    int DIBFCAuyYs = 22594638;
    string PvsnZTFDsL = string("COwRFQITSKKPCfJcZXdNZchOucTvSnNJJDrZAhvjUeBlkhkZKOyzKPvQDKvoRxxmAdLKOWiRTPlpsdYwDBVrQpktNzxJcSktizXkAvbAulASARQUCNHTdALPxVqaVFlEtrvRojxlhtJsLPARiT");
    bool nQhDQIpJWIHUBO = false;
    bool ZtQhwATdB = false;

    for (int iRtRtxpQkygeAHw = 1432962790; iRtRtxpQkygeAHw > 0; iRtRtxpQkygeAHw--) {
        ZtQhwATdB = yjExd;
        rcZgoSyOj *= rcZgoSyOj;
        opGpa = ! ZtQhwATdB;
    }

    for (int ADPyIOmVCndVE = 1895017733; ADPyIOmVCndVE > 0; ADPyIOmVCndVE--) {
        ZtQhwATdB = ! opGpa;
        ZtQhwATdB = ! yjExd;
    }

    for (int xJpEyOuqknb = 500861753; xJpEyOuqknb > 0; xJpEyOuqknb--) {
        PvsnZTFDsL = PvsnZTFDsL;
        opGpa = ! nQhDQIpJWIHUBO;
        amPIKJip /= amPIKJip;
        yjExd = nQhDQIpJWIHUBO;
        opGpa = ! opGpa;
        nQhDQIpJWIHUBO = opGpa;
    }

    for (int pwuxwdRQaq = 862708035; pwuxwdRQaq > 0; pwuxwdRQaq--) {
        amPIKJip += rcZgoSyOj;
        opGpa = ! ZtQhwATdB;
    }

    for (int PvctuJdIJSlKjp = 1788717311; PvctuJdIJSlKjp > 0; PvctuJdIJSlKjp--) {
        ZtQhwATdB = opGpa;
        nQhDQIpJWIHUBO = nQhDQIpJWIHUBO;
    }

    return ZtQhwATdB;
}

bool BxgBpjeqph::ycTmRFq(int MqRFtnOMJ, double HTHlACfE, int dASYZvgb)
{
    string jYxiWubRweXaV = string("pKpeSFKqegIR");
    double iQYOnCzH = -30724.302383493527;
    double xDgkKIRq = 1011459.9432380243;
    bool aQtpjddKRhjKAata = false;
    bool EYefykBIvcVOqheC = false;
    double qObefkvf = -580700.8077647822;

    if (qObefkvf < -376308.14942291414) {
        for (int yabPcesyS = 721432304; yabPcesyS > 0; yabPcesyS--) {
            xDgkKIRq -= iQYOnCzH;
        }
    }

    if (MqRFtnOMJ >= -1828853550) {
        for (int jdWnE = 847276927; jdWnE > 0; jdWnE--) {
            MqRFtnOMJ /= MqRFtnOMJ;
            iQYOnCzH += xDgkKIRq;
            xDgkKIRq /= qObefkvf;
        }
    }

    if (xDgkKIRq == -580700.8077647822) {
        for (int UduLZPJw = 2219008; UduLZPJw > 0; UduLZPJw--) {
            qObefkvf -= HTHlACfE;
        }
    }

    for (int XnmiQGA = 1977959101; XnmiQGA > 0; XnmiQGA--) {
        MqRFtnOMJ = MqRFtnOMJ;
        EYefykBIvcVOqheC = aQtpjddKRhjKAata;
        qObefkvf += iQYOnCzH;
    }

    return EYefykBIvcVOqheC;
}

string BxgBpjeqph::MJBVw(string wdGsO)
{
    bool wZVWJGuENBbRL = false;
    bool tKsgDN = true;
    bool KDIOLAgsQNN = true;
    double pQPkeImdikOdBg = 989224.0459064017;
    string NIjDeaWB = string("NhdKnpxXEczxIYFLgxgnzaaChVfzEcirBnFdPTCwYWOCnFtEDwlUhmAeRxRWRzXhvUZnsZPcLOSEZXnstspRWHgrhSmYYIbMNPhbOIkxpHOFyrrlAxJlibkKnlWmDGuQVgoQmzVYrxjDyyjpafFrZRAwSyuExGPkZIgCqOjINjECMzNcpOhuI");

    for (int YjlBHxnZ = 436933034; YjlBHxnZ > 0; YjlBHxnZ--) {
        continue;
    }

    for (int KQpvxoverwsgJPft = 1326759388; KQpvxoverwsgJPft > 0; KQpvxoverwsgJPft--) {
        wdGsO += wdGsO;
        wdGsO = wdGsO;
    }

    for (int UsRGxWGfkG = 924078390; UsRGxWGfkG > 0; UsRGxWGfkG--) {
        wdGsO = NIjDeaWB;
        wdGsO += NIjDeaWB;
        wdGsO = wdGsO;
    }

    for (int lPvGvbCkYweyMgx = 1994655577; lPvGvbCkYweyMgx > 0; lPvGvbCkYweyMgx--) {
        wZVWJGuENBbRL = tKsgDN;
        tKsgDN = ! KDIOLAgsQNN;
        KDIOLAgsQNN = ! tKsgDN;
        wZVWJGuENBbRL = ! KDIOLAgsQNN;
    }

    for (int FrzwoiFVhyFeT = 3603880; FrzwoiFVhyFeT > 0; FrzwoiFVhyFeT--) {
        tKsgDN = KDIOLAgsQNN;
    }

    return NIjDeaWB;
}

void BxgBpjeqph::tteabALQbjI(int pvThFubmmfuH, bool WtMkZaGusGU, int AmbHigJuVzXMTgzv, string SIZyqrKCuU)
{
    int zaWByPgHTGu = -528465816;
    string pdNkIJeSbtCWkvnj = string("AaZSzRramrCUhwDVwGyvJlVwHHBLUSRYGArzmGdvQfBDxffntqfEcFROpBSfolXlpOqaYiJRzgXSfLItBzdMgAxFTeRtkJEdAechYaSnaaeVNbnyAOpaXHaHkuptFMgnTNeQIN");
    int CHiXl = -108183422;

    for (int ljDvA = 181177148; ljDvA > 0; ljDvA--) {
        zaWByPgHTGu -= CHiXl;
        CHiXl += AmbHigJuVzXMTgzv;
        AmbHigJuVzXMTgzv = zaWByPgHTGu;
        zaWByPgHTGu *= zaWByPgHTGu;
        CHiXl *= CHiXl;
    }

    if (CHiXl < -108183422) {
        for (int RnHXHxmxDi = 146366332; RnHXHxmxDi > 0; RnHXHxmxDi--) {
            AmbHigJuVzXMTgzv -= zaWByPgHTGu;
            SIZyqrKCuU = pdNkIJeSbtCWkvnj;
            zaWByPgHTGu /= pvThFubmmfuH;
        }
    }
}

BxgBpjeqph::BxgBpjeqph()
{
    this->QNBPbBJtOXqPKqP(921916.0480451816, false, -684660.9108892985);
    this->pXzazgNwvGoAgozw(string("fGIZwzvUyQWjwMXax"));
    this->ljRnLSE(-990666.4295949053, false, 529264.3900672988);
    this->xJtaMfyleG(2058136490, 687540.7930505489, 385515.37028125447, -288490439);
    this->igDPwqWgthKk(false, -83894.9530586303);
    this->nksjDAvS(-911220285);
    this->JizYmZrgMhO(-169191282);
    this->XhieRutBdye(false, string("vBhadBSZWvHvGvYennuCyEVzgEOTHuUphsCAEtKKpCBH"), 1495430558, true, true);
    this->OZXfcw();
    this->jZsoHei(string("VtHXobzeOtMQdyGiGqnJbcLzxSHxUIlwlAyNwTgdgcqWaXsElcmkBlPVgHlzZJjEwRJkYcqWzLmKoSxetlzIWLzGshEoRXcwoODGFhMgMrCcneEblzFOVKHXaZPAWSCuPICxcJoBCbzEYnLzgfDbtkcBytL"), -1710469850, 174533.39139712756);
    this->msRcJlnPWGciJEt();
    this->ycTmRFq(-1828853550, -376308.14942291414, 782166684);
    this->MJBVw(string("qWQhkbiEixcITCsTtHUXCrYLRKJGnogtdvdCGoNJfpYfjMAEyjORkOyeLvGhxPvwFJJPVBItqbseHCjFxNcGqgtocPYfRnzKXtjavRgSoQjPlMgXtBBMKzVztvOLJLsOOsrzpXFhtgYYwsIgndgpvMdu"));
    this->tteabALQbjI(192328034, false, 399830781, string("zLcpexlJBNgwzxAewFVXltzbMEqCKRcJKuoHNwMEbrTvuCJbUMmkZFsqURSAqKsiCviMXNOJgNaoTANjArRIuOOxqedmWkfUZKHwprkwAUtDEWuvCVWEZaFdJdTlfPQPBPIbAHaATvEvxRIcZamzlXfIRIqERNoMwcPEsCeKnRZmJWyxhlhvyBVLWGJWYmYKJIdOMuzBTVNyCcTioKkawzqgnQmYwAaItziRroUJaOo"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BXKfxitN
{
public:
    int LcVZuYmKaR;
    bool IkwMOHvod;
    double KzlLbuhmUKdUBh;
    int iQqCNbUPTHffOneW;
    double cDpqvcHUkxSmBmA;
    bool PKlhh;

    BXKfxitN();
    bool VwURcBwNHqMF(int PACeYb);
    bool TzUYl(double nShjI, bool TglEZTKe, double LxzdSwYKdYRnILwK, int sIDBzFhKYxBJcqZ);
    double utGtnkPcBSHBMuD(bool pzUGoWtv, int FrIZbtcKjkW);
    void DYbRhmMSWvbPODAr(bool ApquXmCiaIgzARN);
    bool QGzqYuxw();
protected:
    string XCXAhlUuvD;
    bool tEkNUyGMtiB;

    double oKIoSRrBwI(bool FEZRmbxcEOcK, double fvzwOj, string EzcSK, int lhsIgRWfgEWsWie, double OkmhYwEgEJfR);
    int KXiWRtfe();
    double MPRIDvmJjA(bool RBkRAYUOl, bool rxDfAu, string UOSRJjmnrKU, double NDXMUwp, double MjVjPkPYucjdvj);
    bool CdlciCDovlYeShD(bool JXdOUwbxRdBG, double wFWvKCXfuzg, int iebLpMWGDGinFK);
    void FvJEXhwxnxwsP(string YukFHVJHTkxo, string EcrKubWrQlUZ, string ZrtMlPMnafwNFam, string oRuakfeUGKbkI, string tbwLVmMPwq);
    int KoxzHJquAUHVN(double FLJqOiZOkV, int EYkkqW, string PxZZcrsJpPrAhGdR, int pGgTHazKAW);
private:
    int alpubvzka;
    int XWJPvA;

    int yVsyYltE(bool htwwlqZd, int JIgnVKROp, bool ilAiQAMowhJZRkh, bool bfrKWgCNc);
};

bool BXKfxitN::VwURcBwNHqMF(int PACeYb)
{
    string ODRBmdyMRfHEvgLw = string("qStNHdzziJJwboJACmsHdbaqpBXhUnPPVbsJEVowhEocXetsRWyUpvaYmVjqSFdCLGLHYjWynIZosWcWjZvQnQtCGMFvypSsEegeidvQuRlpNiUAKqvijNSiXff");
    int GJbEsirkVN = 1451350668;
    double rWnMKr = -96115.92247725133;
    bool TGohKMdM = false;
    double tAhdiERX = 960281.9840437005;
    bool EqFIqlslJtzqP = true;
    double IzMzPJig = 692147.8034446271;
    string vZZezllLgo = string("HLClggWlFWzwcbcVlfAAksmwqFqISzYYvnVRHxrpvSdYmRBkSwctMoqCLQwqMlGnyVXsVniyqgZFcDqMtEMJhFWeLJXVaGCeXDYrdhmLuFzQDyOHxIvMdRXISxQoStBQYQZXdZAmCAevANHoNoOOluwyJkcNihSJUHSgVPMzHfTLAXGZQCvWEkzGvubXzBJlwVrXeuhCSnkbX");
    string bSNTVCKEC = string("dyqspjqzEWOoQZXfuGfpKfUXlkWfeySfJMFrwwuWbZwWUawLvRCoihRzGrdgnXJtroBGVDIGqTNjdTuUrdvDkhuJFqEnLQSiemEASCpGyWMhuBKZVdOSKqofPefEnHMQHVgTVqhwDdEoFDEcYVzVYTIOLPSnqOUlXPVEvCbYNrEdHIwpHpXlfinKObFuMJDzfJCEFAEDgYZQNVQhHdIiQrbYxiLQJS");
    bool OZxIIWAAcOz = true;

    if (TGohKMdM == true) {
        for (int yXCNASRf = 19721312; yXCNASRf > 0; yXCNASRf--) {
            continue;
        }
    }

    for (int dDeVTHl = 2110421446; dDeVTHl > 0; dDeVTHl--) {
        continue;
    }

    for (int KkILuZTf = 2030828469; KkILuZTf > 0; KkILuZTf--) {
        IzMzPJig += IzMzPJig;
    }

    if (TGohKMdM == true) {
        for (int gTVnk = 18454078; gTVnk > 0; gTVnk--) {
            continue;
        }
    }

    return OZxIIWAAcOz;
}

bool BXKfxitN::TzUYl(double nShjI, bool TglEZTKe, double LxzdSwYKdYRnILwK, int sIDBzFhKYxBJcqZ)
{
    int bDnDfrqKkTdcta = -168534264;
    string JmRilKcD = string("axMBJyjsEQIvUeHboMWWoVOBBiAeittCxIZnVpnKKbVzRlkvCbdBfeWNKpoezevJgovytycyKUbmoEjOUsHgmjowXTAdyajxYOKVtBtXXFbVBsPVDNnJYyQkIzwtXxEmqwDpgdokAOIRAqbLiRyqaETmiebCOLhLCBlLRYEHuSdcW");

    if (nShjI >= 8555.118205013705) {
        for (int XsFHtpocpRBJmwDV = 1110728121; XsFHtpocpRBJmwDV > 0; XsFHtpocpRBJmwDV--) {
            continue;
        }
    }

    for (int OpsrWKCFtaJDw = 192953667; OpsrWKCFtaJDw > 0; OpsrWKCFtaJDw--) {
        continue;
    }

    for (int iIAQiCmtRSijElb = 856110989; iIAQiCmtRSijElb > 0; iIAQiCmtRSijElb--) {
        nShjI += LxzdSwYKdYRnILwK;
        nShjI *= nShjI;
        bDnDfrqKkTdcta -= sIDBzFhKYxBJcqZ;
        LxzdSwYKdYRnILwK /= nShjI;
    }

    if (bDnDfrqKkTdcta != -2001374634) {
        for (int vwnAlktPJLZSq = 486045993; vwnAlktPJLZSq > 0; vwnAlktPJLZSq--) {
            JmRilKcD += JmRilKcD;
            sIDBzFhKYxBJcqZ *= sIDBzFhKYxBJcqZ;
        }
    }

    if (nShjI >= -830187.4224090066) {
        for (int QbBVlPrlSzfx = 752828090; QbBVlPrlSzfx > 0; QbBVlPrlSzfx--) {
            nShjI += LxzdSwYKdYRnILwK;
        }
    }

    for (int VzLjK = 1245282429; VzLjK > 0; VzLjK--) {
        LxzdSwYKdYRnILwK += nShjI;
        bDnDfrqKkTdcta -= bDnDfrqKkTdcta;
    }

    return TglEZTKe;
}

double BXKfxitN::utGtnkPcBSHBMuD(bool pzUGoWtv, int FrIZbtcKjkW)
{
    string JqXeGGz = string("vAgOFoMNgQwcukNzCJPbOBYbTUyVsdkTGkMjHVvcKeRSXpsIdCMmuejMUlLjxTYWTDuwViuCr");
    double tVvyazWPuyt = -991402.7892842055;

    for (int ScbWtXJUVI = 2024821462; ScbWtXJUVI > 0; ScbWtXJUVI--) {
        tVvyazWPuyt /= tVvyazWPuyt;
        FrIZbtcKjkW -= FrIZbtcKjkW;
    }

    return tVvyazWPuyt;
}

void BXKfxitN::DYbRhmMSWvbPODAr(bool ApquXmCiaIgzARN)
{
    bool ksyBhW = true;
    bool aLVYe = false;
    double JaMvTOdVtUuwqf = -110135.7660860127;
    int XRMhZADwLCu = 1996287334;

    if (ksyBhW != false) {
        for (int RFevHEncXC = 813311782; RFevHEncXC > 0; RFevHEncXC--) {
            aLVYe = ksyBhW;
            ApquXmCiaIgzARN = aLVYe;
            ksyBhW = ApquXmCiaIgzARN;
            ApquXmCiaIgzARN = ! aLVYe;
            aLVYe = ! ksyBhW;
            XRMhZADwLCu -= XRMhZADwLCu;
            aLVYe = aLVYe;
        }
    }

    for (int oemMlZZx = 960388205; oemMlZZx > 0; oemMlZZx--) {
        aLVYe = ksyBhW;
    }

    for (int sefykmuJa = 1294220995; sefykmuJa > 0; sefykmuJa--) {
        aLVYe = ! aLVYe;
        ApquXmCiaIgzARN = ksyBhW;
    }

    if (ApquXmCiaIgzARN != false) {
        for (int JFgwiGMNlRHJfcF = 702568143; JFgwiGMNlRHJfcF > 0; JFgwiGMNlRHJfcF--) {
            XRMhZADwLCu = XRMhZADwLCu;
            ksyBhW = ksyBhW;
            ApquXmCiaIgzARN = aLVYe;
            ApquXmCiaIgzARN = ksyBhW;
        }
    }
}

bool BXKfxitN::QGzqYuxw()
{
    double mYvdiOkbYCvvhk = -78898.09315989951;
    double CUrCd = 622581.9565352084;
    string fWIYOwuPtE = string("UMPpEAPjyaKnIpSpVASTwbiKut");
    int sNJchymHDWWMOy = 1084170703;
    double NZQOAm = 704950.0430624909;
    bool IcuJvyktkUkWXCHW = true;
    int TsKhfDCsK = 1587908583;
    int WJubiyKBGba = -1550146665;
    int qDaKmIQvLcXN = -680124874;

    for (int qCNmLXYJzV = 69080156; qCNmLXYJzV > 0; qCNmLXYJzV--) {
        continue;
    }

    for (int ctKLE = 1236347578; ctKLE > 0; ctKLE--) {
        qDaKmIQvLcXN += TsKhfDCsK;
        sNJchymHDWWMOy = TsKhfDCsK;
        CUrCd += mYvdiOkbYCvvhk;
    }

    return IcuJvyktkUkWXCHW;
}

double BXKfxitN::oKIoSRrBwI(bool FEZRmbxcEOcK, double fvzwOj, string EzcSK, int lhsIgRWfgEWsWie, double OkmhYwEgEJfR)
{
    bool SQhTWh = false;
    bool imXinFMU = false;
    int lgVKGIIVSshcX = 2024258834;
    bool GYDOaKeyohu = true;

    for (int YiQpWRIjS = 1532676241; YiQpWRIjS > 0; YiQpWRIjS--) {
        imXinFMU = imXinFMU;
        FEZRmbxcEOcK = ! GYDOaKeyohu;
        FEZRmbxcEOcK = ! FEZRmbxcEOcK;
    }

    for (int WkTgFXCbIkQKTU = 1454118238; WkTgFXCbIkQKTU > 0; WkTgFXCbIkQKTU--) {
        continue;
    }

    for (int jrDhYKHd = 654267125; jrDhYKHd > 0; jrDhYKHd--) {
        imXinFMU = GYDOaKeyohu;
        lhsIgRWfgEWsWie /= lgVKGIIVSshcX;
        FEZRmbxcEOcK = GYDOaKeyohu;
    }

    if (GYDOaKeyohu == false) {
        for (int PaEOluZ = 404045815; PaEOluZ > 0; PaEOluZ--) {
            SQhTWh = imXinFMU;
        }
    }

    if (lhsIgRWfgEWsWie > 2024258834) {
        for (int JYlKPmCKygX = 1607680591; JYlKPmCKygX > 0; JYlKPmCKygX--) {
            EzcSK = EzcSK;
            SQhTWh = imXinFMU;
        }
    }

    return OkmhYwEgEJfR;
}

int BXKfxitN::KXiWRtfe()
{
    int ZpujO = 432007067;
    double AWcmpHuyOaJSmzR = -386513.6851511846;

    for (int aLNvTXmuTMkvRk = 1244188356; aLNvTXmuTMkvRk > 0; aLNvTXmuTMkvRk--) {
        AWcmpHuyOaJSmzR -= AWcmpHuyOaJSmzR;
        AWcmpHuyOaJSmzR += AWcmpHuyOaJSmzR;
        AWcmpHuyOaJSmzR *= AWcmpHuyOaJSmzR;
    }

    if (AWcmpHuyOaJSmzR <= -386513.6851511846) {
        for (int HdIBThyNd = 485219451; HdIBThyNd > 0; HdIBThyNd--) {
            continue;
        }
    }

    if (ZpujO <= 432007067) {
        for (int GzarRluq = 456635532; GzarRluq > 0; GzarRluq--) {
            ZpujO /= ZpujO;
            AWcmpHuyOaJSmzR += AWcmpHuyOaJSmzR;
            AWcmpHuyOaJSmzR -= AWcmpHuyOaJSmzR;
        }
    }

    for (int eXAQtMkOiHshZNvQ = 797852123; eXAQtMkOiHshZNvQ > 0; eXAQtMkOiHshZNvQ--) {
        continue;
    }

    for (int lrSSG = 1936485202; lrSSG > 0; lrSSG--) {
        AWcmpHuyOaJSmzR += AWcmpHuyOaJSmzR;
        AWcmpHuyOaJSmzR -= AWcmpHuyOaJSmzR;
    }

    if (ZpujO <= 432007067) {
        for (int mGGdCJMOg = 1666591189; mGGdCJMOg > 0; mGGdCJMOg--) {
            ZpujO -= ZpujO;
            ZpujO -= ZpujO;
            ZpujO = ZpujO;
        }
    }

    return ZpujO;
}

double BXKfxitN::MPRIDvmJjA(bool RBkRAYUOl, bool rxDfAu, string UOSRJjmnrKU, double NDXMUwp, double MjVjPkPYucjdvj)
{
    double ZmrsbYHthwzDDtw = -158095.77458337217;

    if (MjVjPkPYucjdvj >= -264856.2785462985) {
        for (int aFhLaBISanTkVS = 2003789560; aFhLaBISanTkVS > 0; aFhLaBISanTkVS--) {
            MjVjPkPYucjdvj += ZmrsbYHthwzDDtw;
            NDXMUwp /= NDXMUwp;
        }
    }

    for (int VawwdjJsFS = 738347654; VawwdjJsFS > 0; VawwdjJsFS--) {
        NDXMUwp = NDXMUwp;
        ZmrsbYHthwzDDtw -= NDXMUwp;
    }

    for (int lSqFUAM = 2124432367; lSqFUAM > 0; lSqFUAM--) {
        ZmrsbYHthwzDDtw = MjVjPkPYucjdvj;
        MjVjPkPYucjdvj /= ZmrsbYHthwzDDtw;
        rxDfAu = rxDfAu;
    }

    return ZmrsbYHthwzDDtw;
}

bool BXKfxitN::CdlciCDovlYeShD(bool JXdOUwbxRdBG, double wFWvKCXfuzg, int iebLpMWGDGinFK)
{
    double BIqSsqXSCbETNml = 596657.9279173553;
    double Piiuj = 673187.6677243726;
    double KogUV = -825039.3866234637;
    double nJBMCXhcJprqBEmd = 945365.1887740577;

    if (BIqSsqXSCbETNml <= 673187.6677243726) {
        for (int qmPONzC = 2000687795; qmPONzC > 0; qmPONzC--) {
            KogUV *= KogUV;
            wFWvKCXfuzg *= BIqSsqXSCbETNml;
            nJBMCXhcJprqBEmd -= KogUV;
            wFWvKCXfuzg /= wFWvKCXfuzg;
        }
    }

    return JXdOUwbxRdBG;
}

void BXKfxitN::FvJEXhwxnxwsP(string YukFHVJHTkxo, string EcrKubWrQlUZ, string ZrtMlPMnafwNFam, string oRuakfeUGKbkI, string tbwLVmMPwq)
{
    double zkgaDrODKslC = 424523.00549529475;
    int jSgoBlvi = -1234433597;
    string AblsjztgsDmCpRJz = string("bJYHfqkwUqmTWaRlFeKAgOvbAdQgZtbgRUfpdVMdeiqpRcULSBfIFzSeaTQnIRiAnqanowoUMTNNiXRGrHSDbJqTTmPWcFnlUHRQYExxMbGgxbqCYwynQBjTXdKVAILFpUlWJgBgIdQPVwuIPjIgsIiZB");
    double ZqECluNQe = 404724.69718366885;
    double wBbLFSzlA = -432452.12855132093;
    double BfCpBZLMaZhGdj = -1034943.8581762598;
    double HDoTzr = -999085.6022639732;
    bool UyCwy = true;

    for (int oquqqU = 1510861696; oquqqU > 0; oquqqU--) {
        YukFHVJHTkxo += EcrKubWrQlUZ;
    }

    if (ZrtMlPMnafwNFam >= string("qMjrMgCdpkSNqmQebKaNpfFuLvONDtWYwMgeIxBXmhAYHasBVdGluREzyEMsANodHxVuNwHATeNSlJdVVHMDdMhOECNRzMfwwcTCxhmNGYEvTubqMWoWgJXSfYSBlUcxpoTFwYeWdqUKwZNAyIAFNhamJiIqaUgHuNvXvkbEaMoVwfRNGkPCK")) {
        for (int bOdYrDsAYec = 584600377; bOdYrDsAYec > 0; bOdYrDsAYec--) {
            oRuakfeUGKbkI += YukFHVJHTkxo;
        }
    }
}

int BXKfxitN::KoxzHJquAUHVN(double FLJqOiZOkV, int EYkkqW, string PxZZcrsJpPrAhGdR, int pGgTHazKAW)
{
    string XPOpamZZNEwrAhr = string("qqnPlYGuxbqKtokCgdMxFCdkrRRDnPBsCHuuXZQtvzWNDHRtsgzzXoNtKTKBPCkFTrdRW");
    bool YEMrhkqVaSDWmh = false;
    int maPHYE = 1422764198;
    bool GxqvsxQhxvpzBm = false;
    bool SCQdGSMDCutBt = true;
    string NlEQelnGe = string("xMaYXkDKZsjDfBNOrFORtfYJZrZGBNcpnJXUhRWPnbFzZtIJymLlrJThokJXhsukRESFIkeXzgShDEcZAXNClXJDiFeBtbHZXEwPeIrdHlpHwBcyzv");
    double AbvxlCUSqD = 450157.18568066345;
    bool ZNBYnbBXia = true;
    bool fpldBOgVZuWxLF = true;
    double fjqoZhCBEYzRiA = -436455.7174711654;

    for (int DbGyPWIRSNao = 628791012; DbGyPWIRSNao > 0; DbGyPWIRSNao--) {
        YEMrhkqVaSDWmh = ! ZNBYnbBXia;
        ZNBYnbBXia = fpldBOgVZuWxLF;
    }

    for (int UPKtizuBxyA = 485686612; UPKtizuBxyA > 0; UPKtizuBxyA--) {
        fpldBOgVZuWxLF = fpldBOgVZuWxLF;
        ZNBYnbBXia = ZNBYnbBXia;
        FLJqOiZOkV -= fjqoZhCBEYzRiA;
        NlEQelnGe = PxZZcrsJpPrAhGdR;
    }

    if (maPHYE <= 1422764198) {
        for (int VWUojuCBUi = 90301250; VWUojuCBUi > 0; VWUojuCBUi--) {
            YEMrhkqVaSDWmh = ! YEMrhkqVaSDWmh;
        }
    }

    return maPHYE;
}

int BXKfxitN::yVsyYltE(bool htwwlqZd, int JIgnVKROp, bool ilAiQAMowhJZRkh, bool bfrKWgCNc)
{
    double VFYDHdyzxDC = 665230.4031803451;
    string CiIIkqttAnyOqaL = string("MvKzZsRRHOhKCVzRuMAKCpNzfpgGudoVCpFolOAHxbNeCzjANREWcVhGZjXGHnGXU");
    string VLQanClJMRt = string("jliIwvPAgUscYhYvZPQLaVukeWMtqGmKEIMsZjJwnEzGGuerRADCfPjdtdgSSDcPsmjNYboSXHVDRmSlDlgkvOAVYfTfSaUXAqVnfbHEEPQFqgfCRDrwzcRkglVcCcERyaNTWMLeZKQkgXswjXSfORGKDpXp");
    bool gEdgqvovMjxMGIjB = false;
    bool eOQJepwvwNY = false;
    int CnwKEGXxbHJ = -1690104613;
    string GQAxctAk = string("WaxdcWvyFJXYemppdIqbkzOweKTjhtTRBPeiDJzxFPXpxfsVctqrLwnmYgFNqYviPcPYlCsGFolPONmmkcHGQVONBmsBuxDIobypGLqOfGAvCKlLCjuyCzDZcLppCHeMNisUUniaCZyCvWhuvKvPoYOcfpIxTAQY");
    int GscEazdyj = 789345431;
    bool XJpxoYqnX = true;
    string ZBDtudYsBZEaF = string("hKnZdQVjPLFcbWdijMRVsBnAcMSvNnUnmlzAFHPSJUQHizshtnvEnsmBZtMGvdpBzGYPdLcNOrnReGKKmZyYOylnFmIRexxElwaRkcanbYfZQSLVvGGkEcoGeMInBBDsWKHwNptcSljhDNhIIaaArCljgwiXHBLPDfsooEdhBbRVnjGtknmpwiUffIzryUtOUYthgj");

    for (int wdCAqFS = 1982714383; wdCAqFS > 0; wdCAqFS--) {
        VLQanClJMRt = GQAxctAk;
        eOQJepwvwNY = ! gEdgqvovMjxMGIjB;
        ilAiQAMowhJZRkh = bfrKWgCNc;
    }

    if (gEdgqvovMjxMGIjB != true) {
        for (int UeuAYFLgYWdqdBb = 1825280391; UeuAYFLgYWdqdBb > 0; UeuAYFLgYWdqdBb--) {
            continue;
        }
    }

    return GscEazdyj;
}

BXKfxitN::BXKfxitN()
{
    this->VwURcBwNHqMF(-504993630);
    this->TzUYl(-830187.4224090066, true, 8555.118205013705, -2001374634);
    this->utGtnkPcBSHBMuD(false, -1441625674);
    this->DYbRhmMSWvbPODAr(false);
    this->QGzqYuxw();
    this->oKIoSRrBwI(false, 985491.119301874, string("XeVbZlHjvCFzdEUvlhTCHXkllqTYTGoXdNxOSAZORjmvOMrzumjNMiIPTIMbDMKyQtKoYISOCiytAGWASDsAQhkXTMTiWEIFrGJSoUkStRlltIbXTxFHVHCGWiyZTUSmwFGdEeIBBwypzKyUlmqueBgZEOCIKkRsvOhpnWLSXmuDjvwkkExVLcyfvauttblhkUeKjlgPNXtgUGkCgUNhJkAefgEjaCrPCoTzTLgpy"), -464517271, -251033.30163585139);
    this->KXiWRtfe();
    this->MPRIDvmJjA(true, true, string("TbnSmYAUmdZzJIUpMqBwKUmAhIzsMbsUeCOmVIWhtfZaapqGXlJrHDYZHlTEpeAOAyUvBWNBLXStEUWCjDmCtzFaLWZyFrXWGZ"), -905969.3410429908, -264856.2785462985);
    this->CdlciCDovlYeShD(true, 891875.442892794, -1144913179);
    this->FvJEXhwxnxwsP(string("qMjrMgCdpkSNqmQebKaNpfFuLvONDtWYwMgeIxBXmhAYHasBVdGluREzyEMsANodHxVuNwHATeNSlJdVVHMDdMhOECNRzMfwwcTCxhmNGYEvTubqMWoWgJXSfYSBlUcxpoTFwYeWdqUKwZNAyIAFNhamJiIqaUgHuNvXvkbEaMoVwfRNGkPCK"), string("gisILjFJjrtTSwipMFPllOEFnvrVBqepPiJPqJkqaFpHyPElIsZfqMEiZpxOLqgFdcCcLGhhVZEqLGimzcGJWApeTINdUPDAbtZEEueyssLYASGEqkVgcCGdSewUhXvOzWtIQWcjZjteuevpJcMLSivOdDepGSQfshSDwlMIvMQQdTWhIvTgBxcMTrAMe"), string("AwsNuHKJFFgJGMGzAyqtcbchhevCfBPOrBKUtLCXSTUTMqCgvATsyxrpOHFeDNUDYpHxdFKOBewmEzIkcFBPjwoVMbAFYaXMqRltUjYTJiqWZVvwFFUjtxGrDZHPKJymkfGkAlLlPNRaRkUJkRPwoljfrzqParSTaOv"), string("nBPRzoOZfBIKTmJxnepjqhfnZRZQzYSkOBrgeuRqobUELiqpOPRuzlcWqnkUFKPkJnCpUXSWhGTJIuosiIbJiioHrHhaFsDzURpVjOjxJiCRqTASBgnMgoUUczRhZiDcTLJnJAAhELeatQtLKRhrVyKSCeigmDmvLDHPJhZZfXclipdxDdqRdiIaEondmgapdjZAbPcpJBJqYvlzkZywixxmFNkOKRvweLnrgmLpXPhDabC"), string("iRxktdRTMtarhXsAbpKucZtCnsMPmCFiEiAzofSjvXIpgIJQEgfUDjcwYwTQFlmZdoVhSKnTUPRXbyKJHNwXFvLrJrwifCdRyqTYgfnEPcfQGuihlIBYdqyLgsRYGThsKeOvAVOkQHWBhVxBTHHmRCGiPikfyHBywVKpuUvYbBUGQRHqsxPYQRFVDoNfIbOxBCTGTGmBaqDiaXMEjGu"));
    this->KoxzHJquAUHVN(958736.3629217375, 874181437, string("KdAonpRKKaVorLAImuldHirxNtyhTjMRMEccKNFImArjGUnhyRBLWHsCqikrvoRVSiyadiVLeelbKTDProHzfCBJZJQkSctMfRbXOhcwscxzmhXiATGxdINmgkqbmAiUJfUxAfQsrEZyUdOcmp"), -1794687226);
    this->yVsyYltE(true, 865568342, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fUVQdFyfTrmZIE
{
public:
    double VcMlWppTer;
    string qwNPibU;

    fUVQdFyfTrmZIE();
    int ZzLjtaTCdaMFDyCT(int RsQBDghlAM, string bHPEADVjEu);
    void cXmgdzcYM(double WRGqDizhBigGpdB, string GHPsomBZcZbxV, double oUWVkOrxCVSoiS);
    int nFnKOYz(bool ZKtveyqvvSfoosk, string mpjpXByAMAQPcB, double HXZeYlttYP, string jAOITXz);
    int rwwirvP(string NVeUDHZsycPZXs);
    string mdAffnClfGGB(int GmIWU, int xycaReXBZhIfIac, double QavyLYaOtbBLHMDp, double GtJXNwgYfEpxk);
    bool ouQzqCI(double MZtxouYBSK, int UcqTweMXKHRxHMzq, int zTVxmfitsFiEV, bool FoXDdpslnBlEkgLw);
    void aLdLVYisD(string CtwvkNxIaD, bool LeLaZFyZtDMJQLn, bool iXmBsnXnK);
    int qFPwX(string yCdsEjfzTn, bool iOtWZgKIelyDV, bool yqvivKQGTH);
protected:
    string ARXsNHnIcXCwksm;
    double NFZbxCSuFozwmIJ;
    string EwuIceMC;
    string sFJOBPop;

    bool rqazDVCdAWoFWUbG(double JTpXfBjqvBA, int KglqD, bool TeZuEhXUDw);
    int jIOPXqIKsBa();
    int OLIgsUoGjYtTPpBt(bool sUYOWgmYiLlnaR, double EfciPubskOvMRX, double IMyGVlaVhxdLA);
    void RukLpNDkwIMlsVY(double DyqOLLUDOdnr, int DLMasSpX, double jOuCOACCQR, double eaCxfWrCPBrM);
private:
    string vByFbhWcQWGDEIOB;
    bool mjmgxvvZF;
    bool hwUtRRgyPbZ;

    double IonsperIwdgBNv(int DpoiH, int FsrAL, bool zBggv);
    void aAglAaF();
    double kuofKGpaBXd();
    bool DgBdyE(bool MZkHuWtn, bool YxsnrADi, string GUNOYniPYjpZXkm, string iAgXD);
    double NOkKpOhArbNsX(double AfbkhHbK, double lGyimzTizEpyw, string VMjhQDaA, string bXyYzIJmsGUKuDT);
    void xAskxKaugq(int BnbRnxhwEQoyDSp, string IQLTUiFHqSWy, int LMeCLpHfbDRWHwFv, int WTEYkbWRieUwZyo, string GOxTPqoxSpOgtB);
};

int fUVQdFyfTrmZIE::ZzLjtaTCdaMFDyCT(int RsQBDghlAM, string bHPEADVjEu)
{
    int JMpdbDGuqs = -1685874867;
    bool JEygwY = false;
    string DrwPSWRtpSGV = string("BQszHNSpnJBbLIJzUCZmFecnnDdgxtcUZPFYAyXLTVSRTTUcoYgvUGUIYOyQMJgDrfMneuSpqKtsbsVLxoKsicgSpvvZVJSOPNomxFGktsIsrXckyxIhKiJWwgGNWnMyYdIxHrjHtgvYOSxxfLvumSvs");
    double gNhGNVxYif = 202764.6577591938;
    int szxgYK = 2067376423;
    bool xodRh = false;
    int yXJhAqtDaN = -2010123664;
    string wgBoqiXzZYdKCUON = string("aJuwwHaVRcEsCwHwDmdyDxfIORZzXFiGTbfsHOPZZQSXbepOdrMnQKhuooQrLDQTwtUXbAeXOCaawwKDWZJpKencTpayrNCLPKKMfGsRnxWdSRephByaglkTLugprJtMNZciGSoJcYeOuDrhkrRbgvxBIPqyesPdJjhegkVEtjeTfzEWuSIUWYUfgCWCGNRCdYmpnyKbMvPznLcWydxrGptePGrIjmiTGEHea");
    string iKTDCOR = string("FvgVAdTczOpIupoznOCRQWwhpZPGtanglmXXDiMVhzhKRgEdfOrfgdflUUZOoXySlgZhNVUkCHJPDgZ");
    string ADYXGpK = string("lzsZgvLVQAaJUfhMrmgvzYhpxHicbTlmmSDxegcOmLtYIBcWRPwnWWSqaCWgVQyAHpYiWUUSLbyLrxpavAwhfQzvynMgJ");

    if (bHPEADVjEu == string("gYjlJkklcnjCXLuufqFqhOufvMgKJqEhcWvxEaaeBdeTGHgUntaCiPpiTJNBiQhMsHeqgxacFgtjXrOTyujkmgyTKmASiQzwlsKE")) {
        for (int QvdWR = 1128825317; QvdWR > 0; QvdWR--) {
            RsQBDghlAM *= yXJhAqtDaN;
            bHPEADVjEu = DrwPSWRtpSGV;
            JMpdbDGuqs -= szxgYK;
        }
    }

    for (int NlBHMmpgtsRxY = 1939032306; NlBHMmpgtsRxY > 0; NlBHMmpgtsRxY--) {
        wgBoqiXzZYdKCUON = bHPEADVjEu;
        bHPEADVjEu = DrwPSWRtpSGV;
        yXJhAqtDaN *= JMpdbDGuqs;
    }

    return yXJhAqtDaN;
}

void fUVQdFyfTrmZIE::cXmgdzcYM(double WRGqDizhBigGpdB, string GHPsomBZcZbxV, double oUWVkOrxCVSoiS)
{
    double iRQmLxSDPhOc = 365518.5527663557;
    double JDGBYoDTFehF = -768080.0234525948;
    string srNCRMLViMu = string("eDSffPrpcXcupNsweDtsxyKjaZDjiYGeKncJPQlADXDJbQTwXDzZEEvEoKAGxalgktRTHyFGQKBMMxSsfMYPxrkuYctukVtzAWGGnjemxkmuOlnyV");
    string VUUSydaISUCyCq = string("NaMxgBAgXMHnQbgldWggZDptxnwovQoAliLUsTSkXBzNCAAppMuyBYPhlLoPxCmHWHxYMeuTFLeEDYHfhlnb");
    double pmLgSyFOqePtF = 734636.5969449232;

    for (int KXzcHLWAm = 1157534386; KXzcHLWAm > 0; KXzcHLWAm--) {
        pmLgSyFOqePtF /= JDGBYoDTFehF;
        GHPsomBZcZbxV = srNCRMLViMu;
        iRQmLxSDPhOc /= iRQmLxSDPhOc;
    }

    for (int YMbLobDDgjIie = 1052850709; YMbLobDDgjIie > 0; YMbLobDDgjIie--) {
        JDGBYoDTFehF += JDGBYoDTFehF;
        pmLgSyFOqePtF += iRQmLxSDPhOc;
    }
}

int fUVQdFyfTrmZIE::nFnKOYz(bool ZKtveyqvvSfoosk, string mpjpXByAMAQPcB, double HXZeYlttYP, string jAOITXz)
{
    int fyive = -212332112;

    for (int GNyqEXNZTWTGhr = 1773408324; GNyqEXNZTWTGhr > 0; GNyqEXNZTWTGhr--) {
        fyive /= fyive;
        jAOITXz += mpjpXByAMAQPcB;
        mpjpXByAMAQPcB += mpjpXByAMAQPcB;
    }

    return fyive;
}

int fUVQdFyfTrmZIE::rwwirvP(string NVeUDHZsycPZXs)
{
    bool czEAo = false;
    int undqtJqLevfWGAyx = -1256330060;
    string JiKlupFD = string("KqBGnivJIjgDcPFVHPKaBKPuekFmbphVK");
    string AjDOAdT = string("behTTmjYJtCsqSNcazduomjCHZJmPHEBkXpHdajyVuHTiZwkGkqdbDGQoBXtaxigowjBPyVtiUurxDxbJUjzcmIYxXYwQPjuYDcrZQIvmIbuQQyVoKOecSPFxhINhGLcjvoRiJrTkJJjwcvRUnsbjVbWhZyFbUHliekUHakiMrToJmMggAFqlAvkxbrDQihhyYKvtcuFnybKQfQfSazOrnQmQBArsSOggJH");
    string kxWhPPkvFDT = string("hfRwtKDTiziBSxOEhIMJdxSUVOQqvJXpAczDWiGtiFTJxLHaFNhTYSKVSvMDKJeXstxiHBlsBJfZfmBDTwKoPjJlVFGggeEnfJIMFcBPPWUHvwmMHdhrGaKGZHpyQppPjMjHqsgVCCeUUsGQpEtKPqNKRACGzLBRJFVfmXfZHFUOGDpKmctsdQegoWwVywEAqRzseLRgPqTEndkcdQBfjFkcoxRuESPj");

    for (int vpkgfjhmRcDrm = 699801867; vpkgfjhmRcDrm > 0; vpkgfjhmRcDrm--) {
        NVeUDHZsycPZXs = AjDOAdT;
        NVeUDHZsycPZXs += AjDOAdT;
        NVeUDHZsycPZXs += AjDOAdT;
    }

    return undqtJqLevfWGAyx;
}

string fUVQdFyfTrmZIE::mdAffnClfGGB(int GmIWU, int xycaReXBZhIfIac, double QavyLYaOtbBLHMDp, double GtJXNwgYfEpxk)
{
    double oZCQyOQpKKtCw = -61552.83843473324;

    if (GtJXNwgYfEpxk < -61552.83843473324) {
        for (int SKZHy = 137283980; SKZHy > 0; SKZHy--) {
            oZCQyOQpKKtCw /= QavyLYaOtbBLHMDp;
            GmIWU = xycaReXBZhIfIac;
            QavyLYaOtbBLHMDp -= GtJXNwgYfEpxk;
        }
    }

    if (QavyLYaOtbBLHMDp <= -61552.83843473324) {
        for (int tRchibekVMEsA = 711104558; tRchibekVMEsA > 0; tRchibekVMEsA--) {
            xycaReXBZhIfIac += GmIWU;
        }
    }

    if (oZCQyOQpKKtCw <= 349177.6460101247) {
        for (int mqzaQekH = 2047644068; mqzaQekH > 0; mqzaQekH--) {
            continue;
        }
    }

    for (int rQYyCXzlOBT = 48644308; rQYyCXzlOBT > 0; rQYyCXzlOBT--) {
        GmIWU = xycaReXBZhIfIac;
        GmIWU /= xycaReXBZhIfIac;
    }

    return string("sxiEBxAApqfUTrrFgkjeybFVJEnziVLKEzjZbSlRcHDIwBHnVoPBIXTDAGkCsGzqnHCevDEqltuSOxHdVUadRshUaNIiAMgglupviLzUrQoalkoChmvjhjgvmKCVTsplj");
}

bool fUVQdFyfTrmZIE::ouQzqCI(double MZtxouYBSK, int UcqTweMXKHRxHMzq, int zTVxmfitsFiEV, bool FoXDdpslnBlEkgLw)
{
    string KYlMYPGzBBXV = string("NumirAhHIKzcQDJgmObqfGpQCOzqGiUtjIrKqZDIdvmaYFToEyPmKfhdLGftANFuBQoibPVyCjUatKEEgOkAQzLyQrmSgNVsBFHbtL");
    bool vemozvoiu = false;
    string nUXEPx = string("veAvguZTpvBikWMRRzbxKSHDvzgmmwjCBRSLmjXjnYoEKOQmOrqeUiBAFrMUYOSEZjMdBndNIfPJGNGkWYKyyhwbamUYhyJZKKhgreqNUflhRGITIeSACDVStnABpxMdjGzVDVGTGr");
    double FdIaLphsFmRaa = -912896.2195552092;
    string aMpWNZmYTDBt = string("EYmHQGFFGtwFhjcMQQbYnGrSfDU");
    double KMLmzQp = 624811.1218052099;
    string HpEhEBIufG = string("znDgvFPxWleLlXdKCrHvtgyTELyYubShdEWQOtwnHGhgSzCNdOaoSsTeDbiwYRhatCQFUKnbJRRLAiRjohodib");
    bool zjeEGJBcyManQ = true;
    int sruSytuszJGFqVR = 577088823;
    double nUeEPQfCEBTC = 586409.3507347566;

    for (int MIzxF = 971526125; MIzxF > 0; MIzxF--) {
        zTVxmfitsFiEV /= sruSytuszJGFqVR;
        nUeEPQfCEBTC = MZtxouYBSK;
        KMLmzQp -= FdIaLphsFmRaa;
        vemozvoiu = vemozvoiu;
    }

    for (int GAioNoJJuEhsaB = 650916972; GAioNoJJuEhsaB > 0; GAioNoJJuEhsaB--) {
        KMLmzQp *= MZtxouYBSK;
        zjeEGJBcyManQ = FoXDdpslnBlEkgLw;
        nUXEPx = nUXEPx;
    }

    if (UcqTweMXKHRxHMzq < -1620261760) {
        for (int DiPVqXkh = 1799480769; DiPVqXkh > 0; DiPVqXkh--) {
            HpEhEBIufG = aMpWNZmYTDBt;
            sruSytuszJGFqVR = sruSytuszJGFqVR;
        }
    }

    return zjeEGJBcyManQ;
}

void fUVQdFyfTrmZIE::aLdLVYisD(string CtwvkNxIaD, bool LeLaZFyZtDMJQLn, bool iXmBsnXnK)
{
    double qMeDBSVB = -374206.2168439388;

    for (int lDYHyYFmXf = 1196653382; lDYHyYFmXf > 0; lDYHyYFmXf--) {
        continue;
    }

    if (iXmBsnXnK != true) {
        for (int jaWKuAQdgC = 1512819455; jaWKuAQdgC > 0; jaWKuAQdgC--) {
            iXmBsnXnK = iXmBsnXnK;
            qMeDBSVB += qMeDBSVB;
        }
    }
}

int fUVQdFyfTrmZIE::qFPwX(string yCdsEjfzTn, bool iOtWZgKIelyDV, bool yqvivKQGTH)
{
    int jPKAxCIIBGHZtvR = -164271715;
    int dfwtndhHUbS = -1270883893;

    if (jPKAxCIIBGHZtvR == -164271715) {
        for (int WbUfBajwgtF = 207347566; WbUfBajwgtF > 0; WbUfBajwgtF--) {
            jPKAxCIIBGHZtvR /= jPKAxCIIBGHZtvR;
        }
    }

    for (int DdrXjyITGq = 1797291355; DdrXjyITGq > 0; DdrXjyITGq--) {
        dfwtndhHUbS -= dfwtndhHUbS;
    }

    return dfwtndhHUbS;
}

bool fUVQdFyfTrmZIE::rqazDVCdAWoFWUbG(double JTpXfBjqvBA, int KglqD, bool TeZuEhXUDw)
{
    int wUYKxcmOmWbvujjU = 969268812;
    int cyxZaFbCqy = -984436575;
    bool WaLFPeKOiMsxKqNA = false;

    for (int NfDzPUHSohzFwJbf = 549199357; NfDzPUHSohzFwJbf > 0; NfDzPUHSohzFwJbf--) {
        TeZuEhXUDw = ! WaLFPeKOiMsxKqNA;
        wUYKxcmOmWbvujjU *= KglqD;
        cyxZaFbCqy += cyxZaFbCqy;
    }

    for (int hSkLyrzYaMhs = 1641121422; hSkLyrzYaMhs > 0; hSkLyrzYaMhs--) {
        KglqD /= KglqD;
        KglqD -= KglqD;
        WaLFPeKOiMsxKqNA = ! TeZuEhXUDw;
        cyxZaFbCqy -= KglqD;
        cyxZaFbCqy -= cyxZaFbCqy;
    }

    return WaLFPeKOiMsxKqNA;
}

int fUVQdFyfTrmZIE::jIOPXqIKsBa()
{
    bool wzYeNUrv = false;
    double dLntK = 1000662.9550465841;
    string XCBfIx = string("NNdlJVWDEvewshfgJOFnifLqnDuhptNZkvdiddpnVAdfXukMtDgVsBccBgodcdeLPlCUuMFpTmEHeteLrBbYzswvDKfQnGIjkmwgdhP");
    bool MklQBhFaLxWAB = true;
    string WtrDn = string("awjfbzfEjQqqukJdPGCnjBciYawbNVKCmhnCL");
    bool CgEBKCFAssX = true;
    string MOEOIJpncenYZicC = string("s");
    int uSixCaF = 1843841527;

    for (int wYUnO = 134995959; wYUnO > 0; wYUnO--) {
        MOEOIJpncenYZicC += XCBfIx;
        WtrDn = WtrDn;
        WtrDn = WtrDn;
        WtrDn += WtrDn;
    }

    for (int zyBIrVEj = 1252715369; zyBIrVEj > 0; zyBIrVEj--) {
        wzYeNUrv = ! MklQBhFaLxWAB;
        CgEBKCFAssX = wzYeNUrv;
        MOEOIJpncenYZicC = XCBfIx;
        MklQBhFaLxWAB = ! CgEBKCFAssX;
    }

    for (int ctPQYfF = 1759305783; ctPQYfF > 0; ctPQYfF--) {
        CgEBKCFAssX = ! wzYeNUrv;
    }

    return uSixCaF;
}

int fUVQdFyfTrmZIE::OLIgsUoGjYtTPpBt(bool sUYOWgmYiLlnaR, double EfciPubskOvMRX, double IMyGVlaVhxdLA)
{
    bool BMFQQpfBcniyLBC = true;
    string XtXXfdeZl = string("jGLgeolljFHTfsOJeQwhcQiJISnUyeZjbgngIIMqnVPkOUxhmsDWEmhNYDGyPilOYKpnSxBXGyEwuWVZpycoZVTKpmopDjaNiiTIZJkzPAFXdJUbkDBjtOxTrXMjSQgBwHqdWygiGKtUerFLJGHwGhBXsWVPDQTLPpH");
    double pUzHoHR = -80728.6478549311;
    bool kMKsBNLVBCmv = true;
    string kuXgZVvYkkk = string("jIMVFwcefzNhWvGyHtjkxdkymtxyKKMMqvZYfSCxHlLCPYTARtfaMFzcQacPUWpIlnaGoLxDCyfQNcCpZmGaXuwKWGnUEDFiYtKiNzwyzRmmgrzSrStmtYzrNjAbKcUFuuq");

    if (BMFQQpfBcniyLBC == true) {
        for (int iXslurnCdj = 1114113542; iXslurnCdj > 0; iXslurnCdj--) {
            IMyGVlaVhxdLA = IMyGVlaVhxdLA;
        }
    }

    for (int fYhxhAppjKsbgxT = 151355908; fYhxhAppjKsbgxT > 0; fYhxhAppjKsbgxT--) {
        EfciPubskOvMRX = IMyGVlaVhxdLA;
        kMKsBNLVBCmv = ! kMKsBNLVBCmv;
    }

    for (int QroOdygZax = 80330203; QroOdygZax > 0; QroOdygZax--) {
        pUzHoHR = EfciPubskOvMRX;
        IMyGVlaVhxdLA -= IMyGVlaVhxdLA;
        pUzHoHR += EfciPubskOvMRX;
    }

    if (kuXgZVvYkkk == string("jGLgeolljFHTfsOJeQwhcQiJISnUyeZjbgngIIMqnVPkOUxhmsDWEmhNYDGyPilOYKpnSxBXGyEwuWVZpycoZVTKpmopDjaNiiTIZJkzPAFXdJUbkDBjtOxTrXMjSQgBwHqdWygiGKtUerFLJGHwGhBXsWVPDQTLPpH")) {
        for (int TerDXUZN = 166848554; TerDXUZN > 0; TerDXUZN--) {
            continue;
        }
    }

    return 157241899;
}

void fUVQdFyfTrmZIE::RukLpNDkwIMlsVY(double DyqOLLUDOdnr, int DLMasSpX, double jOuCOACCQR, double eaCxfWrCPBrM)
{
    bool CwJflDGsg = false;
    bool FfGabJ = true;
    double DUCOaSlF = 626744.6959233676;
    string ZCFOO = string("jFhGIycYwdpEzEbjrzfeoqYBdiKJjdrnVNCXlfOcqvOSsjadUYzkpBvkxAWWihUlMotPUcKcvubtCkeGYiQHgKUmWfGsZkLrSKXNnTtooLraTXWmXHOrfwNRVjwqebrBwTnLDJWmsfTOvLNVytPfXSDdEVNTWbFDZaEBlqqofhGgtdRgMmGvgphylCdgReRYqOoAkLOEDkbGaxkWEsZGedpzVvAmyAgLRQHvURvJ");
    double bAmstQZMFDp = 797877.4559075105;
    int CGTwVTKDAYrV = 378687334;
    double EYRBVHoeqWfvQpZr = -259358.19916766457;

    for (int bjHjlDSzgSX = 433209734; bjHjlDSzgSX > 0; bjHjlDSzgSX--) {
        DUCOaSlF += EYRBVHoeqWfvQpZr;
    }
}

double fUVQdFyfTrmZIE::IonsperIwdgBNv(int DpoiH, int FsrAL, bool zBggv)
{
    int mYoyTXsb = -940512251;
    bool xNBGOnX = true;
    string qxJFwac = string("APlyJyYqarUsTtWeRUaXGZClKngyiBTnVEZGgHGIQWRfVvKXFLiMKvQPhMYZGRAqzbNztxtnWoROOKtoPEJGtdJvFzfnVoZxTBlIZMrnyVKuKovCgQTuqGVDgEjGKqUCWEPuKKoNCbwumazHtVuuoOeImAGRIGnnqgrXhAvuFhCmsUqzqowUAJygNWmfpNpwQBIxjKXyBhCcPgoewIMoZElwoqlFEKfCsGeHvTZcLcJZkSk");
    string QUjXiC = string("bICAaQEnosbYLmcNqjCCUWchblXBRcTtfRHkGMQvTzxfLcjShGStogDDiKjreRjPdjePMjXBXoqqotfgTrdluzeREztqZXHAgFKhmjzQh");
    double looHcYeGj = 377450.2247914113;
    bool qLbWZeZbiJxCom = false;

    for (int qWGYLLqtNlhsrz = 1856158054; qWGYLLqtNlhsrz > 0; qWGYLLqtNlhsrz--) {
        looHcYeGj = looHcYeGj;
    }

    if (qLbWZeZbiJxCom != false) {
        for (int ufQQljH = 871912733; ufQQljH > 0; ufQQljH--) {
            DpoiH /= FsrAL;
        }
    }

    return looHcYeGj;
}

void fUVQdFyfTrmZIE::aAglAaF()
{
    string BTuaMivWNsYxdIl = string("uJShKlDfRRrltbMjtjaCVAdhaVDUkIGXEcLsLLCueevRvRcdxdSQrTVvgrOkXEgeayvolyfeHZXEgzqaNfrPewroLNVMJcLMIXmsKBicJKvWlaIPfMmLikwBUqpkWwpRsukkJonkuxGRIkaxJSXpBXlpqwUKwXaiSOTeyAFFVXviZzlhqsCgxxFanHteNOewjKDDLeqZifkcTaZwKzZcOiqisCWUOYRunpuwWEuYdTgtyHrOaqX");
    bool KrXOpyAtUsnejge = true;
    int IQFTUNULPPyrZYKP = -1980031734;
    string UrLVFSZQYm = string("qzKTybiQCqguFDxZmdZzshKCQhwSvHaHAfhqgsJSCSRXZBoIDnqPbrEdrFMgttolkvxzOQxpshSgwrUKiWAANYKSWKKDVDLYRnohydr");
    bool PVEgJOCoHciU = true;
    int clfVQu = 553011410;
    string lKuJYMGHOSkAmN = string("aSydyikeEmQoXvIhjjCPvwhfmNBXVdSzFOLrBZ");
    double hRJfKsfzLHlUonp = 837457.7159268971;
    int fttSUvcCkJeST = 533691352;

    for (int YrcBuZV = 852736754; YrcBuZV > 0; YrcBuZV--) {
        UrLVFSZQYm += UrLVFSZQYm;
        BTuaMivWNsYxdIl = UrLVFSZQYm;
        lKuJYMGHOSkAmN = BTuaMivWNsYxdIl;
    }

    for (int EdLRG = 789592691; EdLRG > 0; EdLRG--) {
        clfVQu *= IQFTUNULPPyrZYKP;
        lKuJYMGHOSkAmN += lKuJYMGHOSkAmN;
    }

    for (int YtBTJcdlYZOuZ = 1972735577; YtBTJcdlYZOuZ > 0; YtBTJcdlYZOuZ--) {
        UrLVFSZQYm += BTuaMivWNsYxdIl;
    }
}

double fUVQdFyfTrmZIE::kuofKGpaBXd()
{
    int zJZCRZFqLLVTPM = 2121056052;
    int OoVERM = -594421861;
    string cmKZISQujX = string("fBqxAIPBcnTYkaAEVrcWiaXIDWShByZikHAdiciHNPbXUcSaLxZOyErEwSdyXkXITfwZhLrflzMFmyfQNXBxzsijPAYrTtVIPiHcXGYXthUNdiaAGA");
    double ulbwnF = -627135.4077603113;
    int HSdctTrVwYoaZ = 850705067;

    if (ulbwnF < -627135.4077603113) {
        for (int DVnFIfKYJGPchUa = 1909918465; DVnFIfKYJGPchUa > 0; DVnFIfKYJGPchUa--) {
            OoVERM *= OoVERM;
        }
    }

    for (int CDqgZT = 292635337; CDqgZT > 0; CDqgZT--) {
        continue;
    }

    if (HSdctTrVwYoaZ >= 850705067) {
        for (int Aldxf = 1781317631; Aldxf > 0; Aldxf--) {
            continue;
        }
    }

    for (int crBYzfxrifX = 1694511225; crBYzfxrifX > 0; crBYzfxrifX--) {
        HSdctTrVwYoaZ /= OoVERM;
    }

    return ulbwnF;
}

bool fUVQdFyfTrmZIE::DgBdyE(bool MZkHuWtn, bool YxsnrADi, string GUNOYniPYjpZXkm, string iAgXD)
{
    int ABwlpabTPHaqXKS = 319748657;
    string QCZtXDGWW = string("DlVFZPROwDEWPOPRusZzjUCr");
    int EAsNxSSCUcWxVQh = -2091151367;
    double psrlFTNzssWaPh = -913463.4404003427;
    int otmCjcIZwhTx = -1965065507;
    bool mnBDXkNsjNB = false;
    double OoQBVN = 420133.862993864;
    string ofQarkZxTFGNaC = string("UFvTXmrAkAuliOSNiFAxrTZujBlUPjMEefFevPDaZABWikTvXKmQxPFWVSFPxHvaAASlGAvYgNaFZqZBmTyNJkhERtNGpIMyJRgFwcYZebiaVihzTdlLvQLaXtdtNjPXRItEOLVtHMXOjMtcDAjEbidEh");
    int JNUpz = -578001906;
    int oeldjICmb = -1868772004;

    if (EAsNxSSCUcWxVQh != -2091151367) {
        for (int KvvCMHhnFg = 933199633; KvvCMHhnFg > 0; KvvCMHhnFg--) {
            iAgXD = QCZtXDGWW;
            otmCjcIZwhTx -= oeldjICmb;
            EAsNxSSCUcWxVQh /= oeldjICmb;
        }
    }

    for (int qYVDR = 348358957; qYVDR > 0; qYVDR--) {
        MZkHuWtn = ! YxsnrADi;
        YxsnrADi = YxsnrADi;
        JNUpz += oeldjICmb;
        YxsnrADi = MZkHuWtn;
    }

    if (GUNOYniPYjpZXkm != string("UFvTXmrAkAuliOSNiFAxrTZujBlUPjMEefFevPDaZABWikTvXKmQxPFWVSFPxHvaAASlGAvYgNaFZqZBmTyNJkhERtNGpIMyJRgFwcYZebiaVihzTdlLvQLaXtdtNjPXRItEOLVtHMXOjMtcDAjEbidEh")) {
        for (int ZQQxPnzfCHuH = 1874991407; ZQQxPnzfCHuH > 0; ZQQxPnzfCHuH--) {
            psrlFTNzssWaPh += psrlFTNzssWaPh;
        }
    }

    for (int TuxokQSEpRSVKF = 692776204; TuxokQSEpRSVKF > 0; TuxokQSEpRSVKF--) {
        ofQarkZxTFGNaC += QCZtXDGWW;
        ofQarkZxTFGNaC += ofQarkZxTFGNaC;
        EAsNxSSCUcWxVQh += oeldjICmb;
        iAgXD += GUNOYniPYjpZXkm;
    }

    return mnBDXkNsjNB;
}

double fUVQdFyfTrmZIE::NOkKpOhArbNsX(double AfbkhHbK, double lGyimzTizEpyw, string VMjhQDaA, string bXyYzIJmsGUKuDT)
{
    string AspmaXVmwL = string("fSysfWCUmxRQbKAmfhDqAauXpbDCVdjTXVczyloTcivQEYXTzXZrdfBHoqkpFObwEHbOPFfeKLiMdllwKZAWjWhecyDRYCzzWVbSHkiulCFeTsizappIRzvMzIjCLTWYvWItFErIhsrbbGffqiXMzoBzbdFpjc");
    bool ZGLcjfF = false;
    string wUtOWfXbkGM = string("rLTY");
    int KahiGdzGveB = -997128120;
    string fBfws = string("hlEVZZElCdSWIeZraJfzqJhPcqapuVmYexlfWcmzTCCBQycOCFWeKBEzvVQLNuMDAowljEjabEzySPyNRDZVUcvaMigwCSYR");
    bool eMfxOu = true;
    string DMMeRZdt = string("RnzNFoeeBvfkQqQaKzoaqaviODlOxAsYKPitDXznmRtJhxkuQEYhDiNxxJppVctomktqOmzWIeWRSFZNyxxwprleLoemEGkVtPkbTUgsxenbfmcDyRsILVCPhinOYQjObfvTkFwmdRFOnirDGPORtbmfkbDSTxnlRbnonJSgNEgFmOsJOlLtcvMSDAJNPQVkQlpmoBHuJS");
    bool iXgGVoUVp = true;
    string FciLS = string("gVgiNVVTJlWqcydzFagNGjmMnsrXykfFpGurPRSsAaYDSDe");

    for (int tjppDiJBUVrS = 954339379; tjppDiJBUVrS > 0; tjppDiJBUVrS--) {
        KahiGdzGveB = KahiGdzGveB;
        DMMeRZdt = fBfws;
        DMMeRZdt = bXyYzIJmsGUKuDT;
        AspmaXVmwL += wUtOWfXbkGM;
    }

    return lGyimzTizEpyw;
}

void fUVQdFyfTrmZIE::xAskxKaugq(int BnbRnxhwEQoyDSp, string IQLTUiFHqSWy, int LMeCLpHfbDRWHwFv, int WTEYkbWRieUwZyo, string GOxTPqoxSpOgtB)
{
    double AAykJlI = 518845.14624031575;
    bool rFVZEesrngPwZTVF = true;
    string qigCvPbXDeakDo = string("ZKoTjSJiSmTAoqXApGGyUZjjRDbgCkWzCfptpjULPhLouIokzfnoBTHcfOmykkHPYMhudhtSpVdbjmRDNKpYSYTVblAsuqANhThcKfhwsBrPVMLyFWvZpEwaMLoxZLEFLnGsgBqwFqpXAoBZLDypl");
    bool ltbbXpRS = true;
    double oRNtqnMyjrnD = 488491.4293402741;
    double CotmlixkPJLqVvY = 980341.4584698882;
    double ungJWzhQCDeXxt = -670485.50087406;
    string TuGzGPRmImQG = string("PCJWiGLhktcESoGCqmfCCddOIBVEvILNvrnCERPRtmYMNSCZlfrYXINrBIQYFybqQmeQTTWboeokGuJo");
    bool VYZaimCbK = false;
    int uqYxYkLJqKRk = 1204919292;

    for (int GVMqzouyOzV = 6149135; GVMqzouyOzV > 0; GVMqzouyOzV--) {
        continue;
    }

    for (int UyhqLWARWCqR = 1794587962; UyhqLWARWCqR > 0; UyhqLWARWCqR--) {
        rFVZEesrngPwZTVF = ! VYZaimCbK;
        rFVZEesrngPwZTVF = ltbbXpRS;
    }

    for (int uQGQjRWUaeaYMcff = 781105916; uQGQjRWUaeaYMcff > 0; uQGQjRWUaeaYMcff--) {
        continue;
    }

    if (VYZaimCbK == false) {
        for (int YNvMDmKiiN = 970061766; YNvMDmKiiN > 0; YNvMDmKiiN--) {
            TuGzGPRmImQG = qigCvPbXDeakDo;
        }
    }

    for (int ryZhKXgZJIz = 1407049625; ryZhKXgZJIz > 0; ryZhKXgZJIz--) {
        IQLTUiFHqSWy = IQLTUiFHqSWy;
    }
}

fUVQdFyfTrmZIE::fUVQdFyfTrmZIE()
{
    this->ZzLjtaTCdaMFDyCT(2089287271, string("gYjlJkklcnjCXLuufqFqhOufvMgKJqEhcWvxEaaeBdeTGHgUntaCiPpiTJNBiQhMsHeqgxacFgtjXrOTyujkmgyTKmASiQzwlsKE"));
    this->cXmgdzcYM(-1039108.0521018045, string("OrfRcUhSljkquVmNEGbYrmWkMXZXENvBIssAZtZBnnPZDXCniDhXOdYgLJYcCPfWeayPIYYlPEAZLEdMAMJOnCYgracQVvQSWakANQeOwiRsKuDMonThjmMYyDGaANFeqXogUkHsJDjvdgPZUgqHXXRwBZtnpKxHKPVuAnyRHK"), 106674.98413801489);
    this->nFnKOYz(true, string("oeMClLMrmOPwjiayWkbZUeiFvjGaJceHMsmMDjngSVkXntGrtaqdkZIlibRiWwYFnmoiTbJTaNkaoiXgoGayxeJkKshbkFLEDBQVDDowOaVeAofRKlmpLymXIegAwREeadETMglIyiWPbCkJPrlgGsyuSUOCAqvoSVjk"), 685045.5237697349, string("lWnRvlvZdQoUaDJTQtSqtKWYBqmECohkOzTaQpCYFdtsSmhvmtNDNFnvFevJVyjtMLtGtqJeQZPNQYLNbmAaJjdacEOCrifXrLRGYvastKXPosfnCYGTCjPCNTKgKtIGiqvMmlDYaxyDIrXHraVYqmRGYJCrfmFiolZxvPvfLjPajWruNCBnriKrKqoJmjWopVmiZAtVvpbFkAhxdGykyJcCpiDYEbaqPEGnuYmZLxrhOukdf"));
    this->rwwirvP(string("NhqpQHnmhlTLTScAYEJvmTpLHCMZEiDfxbjEquVnlYhOpMsnUMHsVSQVXWMJBeATObYDTGTEnzABTKeABOksaEdBdfWHwXtyLnKyPiQTEvrlmHxZWRHMOiivDUCNqfTRm"));
    this->mdAffnClfGGB(1787186526, 1633059147, 948664.8364490733, 349177.6460101247);
    this->ouQzqCI(-541139.6660011434, -1620261760, 962829386, false);
    this->aLdLVYisD(string("QPqWNjWQmnbmnCSutMndksrMXWhoMhdBbRxcOTbimgWosdhAUzOgZGXTKhtvTAOyyNObBbsjDXDbkHiadmoAGKCUBCTalhqdfNrCUHLWiXaPkKJcCDTGIWcFNCKLUDZrGjNmRLbMoQgrRRavlVNjATiIZEgkGvDOHrPYigOPDKhEIPhQJihQWXYqgrxNkjvRNhULXUQXsdbU"), true, false);
    this->qFPwX(string("GUxbuOzg"), true, false);
    this->rqazDVCdAWoFWUbG(508945.04434570303, 1515726648, true);
    this->jIOPXqIKsBa();
    this->OLIgsUoGjYtTPpBt(true, -881829.2890080214, 4380.490947285269);
    this->RukLpNDkwIMlsVY(-322949.6007751184, -168293997, 382249.30509817257, -769031.4341014413);
    this->IonsperIwdgBNv(150656240, -308691842, false);
    this->aAglAaF();
    this->kuofKGpaBXd();
    this->DgBdyE(true, true, string("nuwhHPlOfnrUmFijiYlqQRwRDGbpptDOYRTOhN"), string("sMsdMdlkURindjdiWiLjXmRSjaIYHvdrLJTVBpAwaVYqWMvddIPgDPNPexEkALNnqyQsyKbyomNaSspHSYaVNsyEfGFNSECuXxQcccWGzAcSCdXVzQMyclmiGZiLPJmOJSbwXEdFqJHyJysjZJHmrUBYpsypFqqxF"));
    this->NOkKpOhArbNsX(-658091.2858340449, -818443.7439262923, string("UZKfxYqORLDTUgrcYmvFRUu"), string("DJjZWxiHdQSrfQrSRHXnPRFFhsWxMIAWrDUzaCmg"));
    this->xAskxKaugq(-1153395901, string("FTcgROmPVTSNemqrEzFflmqGutIbdfuhKEQJQOCtKUMECbFgYhkHtjisBuyNEYxahpqgcjweypqCeueDNBsFFxYzOKhYJCCNCrExRbRGfNEvbcDaspMFzZdwtVNebqqxsRUtTIIZzVvWpsAErWBTHtLGltvdOhvAMTwHkKxeOqsedEhekDaeaHDfqBIpHPTDUWs"), 666976005, 2146285463, string("daBvzQQlghhnWFJOapPWBfuVAqogAevcZiDWMlTMmYGbgTGUdEwgZJyxCfEotDxzLshbuQGFOVpvSSIfVezWFfhLemZhOMpraEATiEcOKXpfAqnXIQecJFkfSLGmLWCAPbjrPrGiIAzPubNswbSQkPWtuKTJy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OefNBw
{
public:
    bool tdCAqrXOJvYO;
    int XcfTiiyTTFtTA;
    bool iBhxPsWrcld;

    OefNBw();
    int RosILe(double HKWBWRENYHzic, double phyVRqrtFliJhtRw, string oeLZMvIOCZCFomA, string bTYfLWjUp, int IFMOt);
    string tymvBsQCbwdLdV(bool LZJAJIfr, double KzNIvU, bool tMaDZtCtjUsu, int IoQMXPqb, double vVuYTH);
    void bbFXMnBcw(bool bcbSdPWg);
protected:
    int zSWbgfnmZViZ;
    string WIRMkIBzFiK;
    double biTbfUIclFkozT;

    string FbbbrHznZqyHsIt();
    void ZbynzPz(double hbcyTBdzOo, double qGPuksY);
    string NyrRtdGbjolmHj(bool OItxXoHsLUtVrh, double WehzuFOMHjZ);
private:
    string mmUlmtqoMh;
    string vgWPWCA;

    int JxSBqUWcCl(int zNUwl, string indQVPzsFju);
};

int OefNBw::RosILe(double HKWBWRENYHzic, double phyVRqrtFliJhtRw, string oeLZMvIOCZCFomA, string bTYfLWjUp, int IFMOt)
{
    string OFczCUp = string("gEIMwAgmsjCYosCeRPrQgCFmYaxxthGEsqSbVlyMeTKUgYGwUblKbvOGEbAcevOrmNvLkfBuoNJeABdlFNHdVUAOtMJcdwjBKhviGwexlWVZQblHUceTtjZSzMMffkYBSFejuiaLSSZwazQCGeeAJjYWIPvbkslPOGWKmoIfhQiFtptkVsUkvofqAoLdGNtBhDVyrJPWOGiLAQZoeNmSUUWohkfMUbv");
    bool JVUPPGmIfrVV = false;
    int YQdISnQIPlYaHZxB = 1403721691;
    int IQKOHxKxBWrjY = -1924849977;

    for (int QHVoFOFeIvohqA = 730839878; QHVoFOFeIvohqA > 0; QHVoFOFeIvohqA--) {
        YQdISnQIPlYaHZxB /= YQdISnQIPlYaHZxB;
    }

    return IQKOHxKxBWrjY;
}

string OefNBw::tymvBsQCbwdLdV(bool LZJAJIfr, double KzNIvU, bool tMaDZtCtjUsu, int IoQMXPqb, double vVuYTH)
{
    bool YrHRBynCvwQdJF = true;

    for (int uWWTk = 617886647; uWWTk > 0; uWWTk--) {
        YrHRBynCvwQdJF = tMaDZtCtjUsu;
        vVuYTH /= KzNIvU;
        KzNIvU -= KzNIvU;
    }

    if (LZJAJIfr != false) {
        for (int hCbpQ = 2107621224; hCbpQ > 0; hCbpQ--) {
            LZJAJIfr = ! YrHRBynCvwQdJF;
            LZJAJIfr = YrHRBynCvwQdJF;
            YrHRBynCvwQdJF = ! YrHRBynCvwQdJF;
            YrHRBynCvwQdJF = ! YrHRBynCvwQdJF;
        }
    }

    for (int aMiLHM = 1710576518; aMiLHM > 0; aMiLHM--) {
        LZJAJIfr = LZJAJIfr;
        YrHRBynCvwQdJF = tMaDZtCtjUsu;
    }

    if (YrHRBynCvwQdJF == false) {
        for (int IkowRzOGzEhk = 1343004753; IkowRzOGzEhk > 0; IkowRzOGzEhk--) {
            vVuYTH /= vVuYTH;
        }
    }

    for (int iitnkSG = 321408457; iitnkSG > 0; iitnkSG--) {
        continue;
    }

    return string("tcDjGmFjPVvXCJXnHyOFuWIeMkvceJJujmuLSzVOyfQJYWszvwTpgxzieYHUzHWjfZablcKsCzsOBfhmBtUibidqLGMLLUjxlgJRxCGbqnqddbMfqFVLKRiOqGdBSaJhqFFxYyPQqdFnTLBBAOpCIx");
}

void OefNBw::bbFXMnBcw(bool bcbSdPWg)
{
    int bqhWMIaCh = -2009447960;
}

string OefNBw::FbbbrHznZqyHsIt()
{
    int NlMVbDsYMvHxZi = -37006413;
    string NTqARNxVg = string("YIPcMYSXklwrGegYblWdcXYIEScgjdcHYvFSJPkeqCDNsGqyMUmTsggFaVUWLQxzdyndLQGvjKaMKCzpnkPvxu");
    int hTOLwpWg = 198958647;
    double FgUFujGKUIuMWUuY = 612456.7886610426;
    string wYxnVXfVC = string("GhJpAgFeJgozzcdoUntPkTOIauSswDveegXgxlqWOdcSbEAKUdmXvChZcLdlNchrZDQlFBEllVlBiInerDYTPCmnsxujGrwXBljHONhadeirTDnyAnareXSvsnzMEuFkgPAboISLeZriCCcWXDmhNpNJSaanVoCxPRfoCwszmlMsMNNccTzeYrNkICMLUOmKawBxlFPuFbqCNW");
    int sWtJZDoY = -924360920;
    int lVVKK = -803627847;
    int xuzozjLckDud = -1798499726;

    for (int FAvMAoK = 931425236; FAvMAoK > 0; FAvMAoK--) {
        continue;
    }

    for (int lFZGzXK = 405571137; lFZGzXK > 0; lFZGzXK--) {
        FgUFujGKUIuMWUuY -= FgUFujGKUIuMWUuY;
        hTOLwpWg -= xuzozjLckDud;
    }

    if (xuzozjLckDud <= -924360920) {
        for (int VFshWBQmCFXSqsP = 1496695332; VFshWBQmCFXSqsP > 0; VFshWBQmCFXSqsP--) {
            xuzozjLckDud /= hTOLwpWg;
            lVVKK *= NlMVbDsYMvHxZi;
        }
    }

    if (sWtJZDoY < -924360920) {
        for (int ZgghAzXNf = 1680129656; ZgghAzXNf > 0; ZgghAzXNf--) {
            hTOLwpWg *= NlMVbDsYMvHxZi;
            FgUFujGKUIuMWUuY -= FgUFujGKUIuMWUuY;
        }
    }

    if (NlMVbDsYMvHxZi == 198958647) {
        for (int KzDnUB = 1677176888; KzDnUB > 0; KzDnUB--) {
            NlMVbDsYMvHxZi = hTOLwpWg;
            sWtJZDoY -= hTOLwpWg;
            lVVKK += lVVKK;
        }
    }

    if (hTOLwpWg >= -803627847) {
        for (int Ogyatr = 1641111151; Ogyatr > 0; Ogyatr--) {
            sWtJZDoY += lVVKK;
        }
    }

    if (NlMVbDsYMvHxZi > -924360920) {
        for (int psvdxavQwcsKFU = 577332946; psvdxavQwcsKFU > 0; psvdxavQwcsKFU--) {
            sWtJZDoY -= lVVKK;
            sWtJZDoY = xuzozjLckDud;
            hTOLwpWg += sWtJZDoY;
            hTOLwpWg += lVVKK;
            NTqARNxVg += NTqARNxVg;
            sWtJZDoY -= sWtJZDoY;
        }
    }

    for (int vQhUQlFzpcEd = 1368806669; vQhUQlFzpcEd > 0; vQhUQlFzpcEd--) {
        hTOLwpWg = xuzozjLckDud;
        xuzozjLckDud += sWtJZDoY;
    }

    return wYxnVXfVC;
}

void OefNBw::ZbynzPz(double hbcyTBdzOo, double qGPuksY)
{
    string adyhBWxYmwV = string("UjPOWwteHxALLIDgzaEHTkOdDpKyPDlJxCuxsVuANdyfshjdbjCWHkKBqEBykVaHnaNNYAOyBIILqFTWMpwWftWZpGBoUYsCKOMJgSPOgvDcOFreFvquBLqGDsSZtLPCUgrcMmnwDCEluvDWkeAeXPdPjlJoBfxUTQKjdJHkIxHymhnqOLOIdQcw");
    bool baPbJTqwbxcwvJ = false;
    double hxxJgVWnWFAdjEe = 553966.2995419046;
    bool loGDmiRTQpFWA = true;
    int wQPnVORzwsDuT = 965987965;
    double JiahrVzpmyvNTVlT = 944109.7141113107;
    string GvZfITwfHsFsIKS = string("WmDWfcQpZOWMGfFIAgiEZrYEsrHQkBYwknTbDDcqBzIuThHCIlwylNWkreozwQyZDiEfiFqrtVNheuKmvBfaKboFEYoRWUcrGhSGWrJvUYFbXsGvAgXPRTNLymXvCTDPWQvKKKrTaDRZgfBNrNyBlqCByMMOsfbOasGKmkiywJB");
    string JyvjsabOsx = string("SiAdFfkWBfqjIUqzNGTqQPzIAQvIAOttvoZnpsxZbyiDkJfVCqEKoIxBNhcZvbrOvUoxAckrlHIuyrkILNuywJuaOHRWzwgTvqiQlhevoNFECDUWbBjlWErdUQeZSiAitjKRIYAjaEfWkrcvpInGiRDPZvOqbvadGxKb");
    double nizyimWNvtpHEw = -755128.7661190525;

    for (int azZILIP = 1743949178; azZILIP > 0; azZILIP--) {
        GvZfITwfHsFsIKS = adyhBWxYmwV;
    }

    for (int QhfYyzdPJUXiMc = 1836182028; QhfYyzdPJUXiMc > 0; QhfYyzdPJUXiMc--) {
        nizyimWNvtpHEw = qGPuksY;
        qGPuksY += hbcyTBdzOo;
    }

    for (int KzsChaGgcib = 251432733; KzsChaGgcib > 0; KzsChaGgcib--) {
        JyvjsabOsx += adyhBWxYmwV;
        qGPuksY *= hxxJgVWnWFAdjEe;
    }
}

string OefNBw::NyrRtdGbjolmHj(bool OItxXoHsLUtVrh, double WehzuFOMHjZ)
{
    int cqcRcvvYwY = -1194700481;
    bool BgKOZVACSWlN = false;
    bool jDFUahCCl = false;
    string yRLXMWVJXWrIumA = string("PuBawaPu");
    bool HEcTbOwDhlBgWhJv = false;
    string wJdUvwgokcDU = string("xlOvnVHrRwWQRCZRFnmHjksrhKqBbakCByuPHPnqzzaTzPlJUnJJRwsSmlyHLEheZkWwBDxUwkIMtJvBcJJnCOfZTZrwxJAGUsuJvDVKNCmoGRnTClv");

    if (HEcTbOwDhlBgWhJv == true) {
        for (int AidciMwNNtm = 1348765669; AidciMwNNtm > 0; AidciMwNNtm--) {
            wJdUvwgokcDU += wJdUvwgokcDU;
        }
    }

    if (OItxXoHsLUtVrh != false) {
        for (int efBJPs = 1353664812; efBJPs > 0; efBJPs--) {
            OItxXoHsLUtVrh = ! BgKOZVACSWlN;
        }
    }

    for (int NBskQxfTWjdn = 387887730; NBskQxfTWjdn > 0; NBskQxfTWjdn--) {
        OItxXoHsLUtVrh = BgKOZVACSWlN;
    }

    for (int FfbKkiPLVmBxY = 1325538161; FfbKkiPLVmBxY > 0; FfbKkiPLVmBxY--) {
        continue;
    }

    if (OItxXoHsLUtVrh == true) {
        for (int EDast = 383471096; EDast > 0; EDast--) {
            OItxXoHsLUtVrh = ! OItxXoHsLUtVrh;
        }
    }

    return wJdUvwgokcDU;
}

int OefNBw::JxSBqUWcCl(int zNUwl, string indQVPzsFju)
{
    string ENupLjYMb = string("NZUhbOFzbKhmqdhidYBpBdJapikfQuFqqlGCSARyLoAPoAQRSDgNWgVUUtfhKrtWaANbzSnmYnCwezBncgnaJxoWWMcoRJvYCdLHyzcNggOMqCrFLYquUbaxZHiWPjEAELfhRMthTfYCGoAbydYcyGRBsthqOhLpqynKuWNnRfpAdyIQJAIdkLRVJWsWFvelNucPyBoHqQlLGsXvNx");
    bool vRKhVw = true;
    string fqthoxjZdRox = string("OPwzNJvGGgTnOAcpATHsvwwdKWCkCAEDJqjEGusLDNJdHXaShVrLtZzizWcPlrfNnDlXSmIyaTxZklqdVvDCtTBJuwAcBzXZYfOlVmFZwGwrBOduPMJdMEmshOjoZCFOEZSvhNbaIRhfTNwotVJJFbHcMwDQjeurIPQfHdBOtKOYAXrplyhhcZlfttKQ");
    double oAsauhNF = 814850.5370434729;
    double jkobQHxEGBX = -754376.1034113504;
    double IpLeyXpGP = -149662.56067483977;
    bool kRlBuYJAwqyNr = false;
    string yGzAQMeLYkdz = string("qnTEaFwhYzzpjpEpLntCpiWwefBFnOvvKKthJnZqJWRPPgqmNQXlcRfogwGTPolhSZbmYtIECeuaqDiywZRhAydvXiNSzzgtBdZxEqTZXxzaJYBVmEKtyPHoSWshrXXOFUEhxfvumwvjXHknJRmMgHcHcIhtuFBCRfVBNXdSfCEngAGrZBxsxzcbpOgNGFLncghkxROZiMqGybJUapghMnKSuROiBiNWXKTtmxeJfAFlT");

    for (int XGntCp = 577985028; XGntCp > 0; XGntCp--) {
        continue;
    }

    return zNUwl;
}

OefNBw::OefNBw()
{
    this->RosILe(291628.8431893474, 454685.43854473147, string("wtdbrNNmXqleyyEgFCzppKMYoiZCwmBlWyRPxAWeNoDyvFoyeZGVEQRuZVBsRKRjLijKfBMNeexJsYJUNFRnCqVTBousofoQVJAchqAEoRmiVXIKgiFmmsaKUHbmTBvDwpdYzAVKaSCxbZmlvMAHAcqqdTUXaziMLuXFvaNFXRJr"), string("laIpwrasSoqIbuAJhMhBzvXjmYNvKjZGwHGdIVbdMQjtXQMWQufWbPyjOPgHwhPOhBgyVOpbetnpXFVFupLEADJptTLerLlIZVSwqzqTweolxSCsADqqEkldqVpEpJGxjzSsKNhQVVYNoXPDZLClPnXpYKACt"), 1761425125);
    this->tymvBsQCbwdLdV(false, 106985.20942864593, false, -115407264, 583248.0129339);
    this->bbFXMnBcw(true);
    this->FbbbrHznZqyHsIt();
    this->ZbynzPz(814164.592688637, -261383.16307791913);
    this->NyrRtdGbjolmHj(true, -609706.0353279198);
    this->JxSBqUWcCl(443954404, string("XKgaapNZCQtXLQJAunyWFzuYpWUhKBiZhcGXitCuDJZewDLLJYcwipVYldcpfcdDQFKXPgrIjucBpTepjFVdGICVsHOaltMXYhOzpdoNckYGTmdnoQzDukRkzpHsFGhwEWpFKuMxyVbJbPAVjCiQicQnEOOqkcmb"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vAPtwkNCZXjY
{
public:
    bool xHEdlCsBFUx;
    int TBeCCi;
    bool cTGzSFx;
    bool jnUAtCcNjDXCD;
    bool rWHdjLxuGp;
    bool DXyyidYToL;

    vAPtwkNCZXjY();
    string KziSbvSQQdqEan();
    string roUnvGdD(int fDVoteY);
protected:
    double IxfztwpDoMryzqO;
    double BIozscC;
    string inqgsdxYZssqP;
    int YkIiOCi;
    double JUGyi;
    int oOdbwDAz;

    double TrWub(bool Aziel, int rHgTwDB, string wdDgRyKfxn, bool XSeAMjkmRpYRf, double NSevw);
    int bjVhxM(string sOvPySYbgEJFQ, string SrtzHXOr, bool yYiMIJFfsf, double IfjelUCMD, string DCPRXHrzHfUzhjH);
private:
    double LMTJO;
    bool pmGbGRNvBGbAHh;
    bool dQoBxvGyYBq;

    string PUCchJPBPC(bool vuVcA);
    void eoJodEHQzpohhU(double WDDLVZfyshiPhVOX, double QBzqnXhKLNLTGl, int QEDbnNoDkz);
    bool JoGRNBjhoFa(double SOFJIqzcoEtb, double IHJOTpRmLbrVft, double aYWyHYCoxi);
    int uiBoxwSalynneHH(string sGwiWTgsDJ, string JKhJsmH, int gKHPuh);
    string jocHmrCBSc(int NKOeJMYct, double UjGczjyTzLMxIK, int QiYnwXTeXca, string ZDtaPi, int ofimOgHsqEAp);
    string xrlVZhjquqACgXEB();
    double qfFwFoTHHDmC(string fXtByuKTy, string FCmKmtHVgE, bool UyRvqK, int FsimOwSFzjclx);
    void zqypjzNwRpzU();
};

string vAPtwkNCZXjY::KziSbvSQQdqEan()
{
    bool kWOCOehHk = false;
    string ICsgWWcsaDc = string("orEhqVEumqJUsTgADvypeVArFeNPwSZLhoscFkvmhHqSofTqkWykbDzmRzzMiACGCxUUrXRLJUPZOgGtilfMmzfbKIdByS");
    double gYoYAkMAwZogEqw = -749524.5395525865;
    bool UDRjb = true;
    double JNeWF = -118325.142630519;
    bool zgabhGsFrMzzMttO = true;
    double hSPFUpXMPGQO = 960854.2206102812;
    int CYQkrXejeIUT = -279370976;

    if (JNeWF < 960854.2206102812) {
        for (int uDyYj = 706369265; uDyYj > 0; uDyYj--) {
            kWOCOehHk = UDRjb;
        }
    }

    for (int aNkFpdKLkwxmJ = 55517988; aNkFpdKLkwxmJ > 0; aNkFpdKLkwxmJ--) {
        gYoYAkMAwZogEqw /= hSPFUpXMPGQO;
        kWOCOehHk = ! zgabhGsFrMzzMttO;
        zgabhGsFrMzzMttO = ! UDRjb;
    }

    for (int pScaiJVyfxnyGX = 1271084366; pScaiJVyfxnyGX > 0; pScaiJVyfxnyGX--) {
        continue;
    }

    for (int MtseCKd = 309124832; MtseCKd > 0; MtseCKd--) {
        continue;
    }

    if (UDRjb == true) {
        for (int cKAKgLVLEpHbsJs = 1158326753; cKAKgLVLEpHbsJs > 0; cKAKgLVLEpHbsJs--) {
            ICsgWWcsaDc += ICsgWWcsaDc;
            UDRjb = ! kWOCOehHk;
            hSPFUpXMPGQO += gYoYAkMAwZogEqw;
        }
    }

    for (int DoRASKiVs = 383365579; DoRASKiVs > 0; DoRASKiVs--) {
        UDRjb = zgabhGsFrMzzMttO;
    }

    return ICsgWWcsaDc;
}

string vAPtwkNCZXjY::roUnvGdD(int fDVoteY)
{
    double NTLmXwpXDI = -988068.0944867958;
    int fndSMgCvAJHdqHwp = 326618567;
    string KSXPal = string("nYUpwlPWbSvyubNLXKqiVhrrCVLyuPtWGXgRpqpqpLectsaRbLRrlXq");
    bool veHCkxxTfM = true;

    if (fndSMgCvAJHdqHwp >= 324702185) {
        for (int BNSHxzTSGAjTbY = 1335135578; BNSHxzTSGAjTbY > 0; BNSHxzTSGAjTbY--) {
            veHCkxxTfM = ! veHCkxxTfM;
            veHCkxxTfM = ! veHCkxxTfM;
            fDVoteY += fndSMgCvAJHdqHwp;
        }
    }

    for (int Kkrhl = 1637922909; Kkrhl > 0; Kkrhl--) {
        fDVoteY += fndSMgCvAJHdqHwp;
        fDVoteY /= fndSMgCvAJHdqHwp;
        fDVoteY = fndSMgCvAJHdqHwp;
    }

    if (veHCkxxTfM == true) {
        for (int ZXmAVRxW = 1637503300; ZXmAVRxW > 0; ZXmAVRxW--) {
            continue;
        }
    }

    for (int hIKmWUzYUKoP = 1049515744; hIKmWUzYUKoP > 0; hIKmWUzYUKoP--) {
        continue;
    }

    return KSXPal;
}

double vAPtwkNCZXjY::TrWub(bool Aziel, int rHgTwDB, string wdDgRyKfxn, bool XSeAMjkmRpYRf, double NSevw)
{
    bool xemNTtxoQqKJ = false;
    string NlnUYB = string("h");
    string tHalKrbwDXDHS = string("TIHxXImxtSDOmDgRZjqEXBjeQBdtYXQFTDCcXsRuCvUSWbjjnodDdgqMWydBhHmlOhHdebQvnErOqUnGsGRlnvYjxPZsBVukvQTdkvUgNEbSGeTsfbhRIGFnsl");

    if (Aziel == false) {
        for (int NIPPxBssamp = 620898216; NIPPxBssamp > 0; NIPPxBssamp--) {
            xemNTtxoQqKJ = xemNTtxoQqKJ;
            NlnUYB += NlnUYB;
        }
    }

    return NSevw;
}

int vAPtwkNCZXjY::bjVhxM(string sOvPySYbgEJFQ, string SrtzHXOr, bool yYiMIJFfsf, double IfjelUCMD, string DCPRXHrzHfUzhjH)
{
    bool QBKOLlXPRSrcC = false;
    double NeWWrBZPHRnFy = -718811.7527620678;
    double aBTclgA = -104624.19769691792;
    string lqqnmskC = string("SzqIumRHqhLpnaHqyRYToMnYUCwDEjngGsBvBeuPPuOfFBwCaqcFxdkhcqKDgjlgbZuOZWdcHVdCDzLrBUCOMQMoZsCHxTvPubmiPlnGNXtXBKTmODqZSEFkveTyDHwPsqNWhivGaaRIdjhwPUjkTuTlNCGJiYABCjqSkPaDyddgHEuCntzlCCq");

    for (int DKRhWkLrpq = 475455218; DKRhWkLrpq > 0; DKRhWkLrpq--) {
        NeWWrBZPHRnFy = IfjelUCMD;
        sOvPySYbgEJFQ = DCPRXHrzHfUzhjH;
    }

    if (DCPRXHrzHfUzhjH != string("HOGbRbrGoGdIxZblyOXHpJptShFfctbzq")) {
        for (int ENziBjfLYRJgF = 2055722660; ENziBjfLYRJgF > 0; ENziBjfLYRJgF--) {
            lqqnmskC = DCPRXHrzHfUzhjH;
            DCPRXHrzHfUzhjH = lqqnmskC;
            yYiMIJFfsf = ! QBKOLlXPRSrcC;
            DCPRXHrzHfUzhjH = DCPRXHrzHfUzhjH;
        }
    }

    return -2073267367;
}

string vAPtwkNCZXjY::PUCchJPBPC(bool vuVcA)
{
    double OLAUiEXkgsVuPB = -963370.150127764;
    string yptZhwnuTGjt = string("lrELwZn");
    bool aToMSvs = false;
    string HSvAv = string("ZlsnVPiqsBpkrDNZuLdmpgisAXBgmrTdQspdOfOAsnKujeGAYQZcdynYGagAINxylNFPblZtLWSepDrHPLuEZVtaQcORBrXIxZsRjXxSyktRHvnvKchDxgJWcFOoOrJLpekcukeCnNcSqYsOEGimAFYBFjOXMNusQEblsSdOAQilrDKHyIsNPq");
    double OqRUirgliopcmoxo = -320250.0985992971;
    bool qyBrKDBc = true;
    string IfkcQ = string("fjGqKTPjzWvHgxZliPATEKCYjboBtNFaEoABwKEGjbTrIXpIiyoYNOVMvlsrHNhFtcmooONeXCgDbOabWDKcCuwsRqyjEqJUr");

    for (int PtBxDxrWJKVHeMTy = 1757630103; PtBxDxrWJKVHeMTy > 0; PtBxDxrWJKVHeMTy--) {
        aToMSvs = ! vuVcA;
        HSvAv += yptZhwnuTGjt;
    }

    if (IfkcQ >= string("lrELwZn")) {
        for (int ahqnMuWv = 453238034; ahqnMuWv > 0; ahqnMuWv--) {
            continue;
        }
    }

    if (vuVcA != true) {
        for (int MtuEFJICxKTnkGL = 1201317576; MtuEFJICxKTnkGL > 0; MtuEFJICxKTnkGL--) {
            yptZhwnuTGjt += yptZhwnuTGjt;
            vuVcA = ! vuVcA;
            IfkcQ = IfkcQ;
        }
    }

    return IfkcQ;
}

void vAPtwkNCZXjY::eoJodEHQzpohhU(double WDDLVZfyshiPhVOX, double QBzqnXhKLNLTGl, int QEDbnNoDkz)
{
    bool SSnqMjPBglHUW = true;
    double MBvDRFP = 564616.7746364669;
    bool nnQcRcrxN = true;
    bool idtZUlwonrRJGJ = true;

    if (idtZUlwonrRJGJ == true) {
        for (int ZcqjEXhKQcPmuB = 889976850; ZcqjEXhKQcPmuB > 0; ZcqjEXhKQcPmuB--) {
            MBvDRFP *= WDDLVZfyshiPhVOX;
            SSnqMjPBglHUW = ! nnQcRcrxN;
            SSnqMjPBglHUW = SSnqMjPBglHUW;
            MBvDRFP += MBvDRFP;
        }
    }

    if (MBvDRFP != 520613.99982585834) {
        for (int hjISzsFqBppdZrL = 821039215; hjISzsFqBppdZrL > 0; hjISzsFqBppdZrL--) {
            nnQcRcrxN = ! nnQcRcrxN;
            MBvDRFP += MBvDRFP;
        }
    }

    for (int VBQGqdkTCMvvV = 523550120; VBQGqdkTCMvvV > 0; VBQGqdkTCMvvV--) {
        nnQcRcrxN = ! SSnqMjPBglHUW;
        idtZUlwonrRJGJ = idtZUlwonrRJGJ;
    }
}

bool vAPtwkNCZXjY::JoGRNBjhoFa(double SOFJIqzcoEtb, double IHJOTpRmLbrVft, double aYWyHYCoxi)
{
    bool JwGNlaWR = false;
    int lyxiGHWOlyuXO = 158273600;
    string lnQpZSQl = string("kBVyaQJIDlWJriAhJdXzWfHZSSzpLgazalIPpzRSUJgtuRrKyznhPnYxBqFLlqdXuoMrtXfvwvaARLbZqFHkUXJ");

    for (int RMYtYzeKhIp = 575840476; RMYtYzeKhIp > 0; RMYtYzeKhIp--) {
        lyxiGHWOlyuXO = lyxiGHWOlyuXO;
        lnQpZSQl = lnQpZSQl;
        JwGNlaWR = ! JwGNlaWR;
        IHJOTpRmLbrVft /= IHJOTpRmLbrVft;
        IHJOTpRmLbrVft *= SOFJIqzcoEtb;
    }

    if (SOFJIqzcoEtb == 672518.1420736812) {
        for (int AjTauStvpNYX = 1172889619; AjTauStvpNYX > 0; AjTauStvpNYX--) {
            IHJOTpRmLbrVft *= SOFJIqzcoEtb;
        }
    }

    for (int bDpKGgrc = 620085123; bDpKGgrc > 0; bDpKGgrc--) {
        lnQpZSQl += lnQpZSQl;
        IHJOTpRmLbrVft /= IHJOTpRmLbrVft;
        lnQpZSQl = lnQpZSQl;
        lnQpZSQl += lnQpZSQl;
    }

    for (int ptCJUkZyPDapaF = 839355352; ptCJUkZyPDapaF > 0; ptCJUkZyPDapaF--) {
        SOFJIqzcoEtb /= aYWyHYCoxi;
        IHJOTpRmLbrVft -= aYWyHYCoxi;
        lyxiGHWOlyuXO /= lyxiGHWOlyuXO;
    }

    for (int BhBkzQ = 1385507538; BhBkzQ > 0; BhBkzQ--) {
        IHJOTpRmLbrVft /= IHJOTpRmLbrVft;
    }

    return JwGNlaWR;
}

int vAPtwkNCZXjY::uiBoxwSalynneHH(string sGwiWTgsDJ, string JKhJsmH, int gKHPuh)
{
    int pOeBWiP = -1654892269;

    for (int PRzwXLjU = 29624115; PRzwXLjU > 0; PRzwXLjU--) {
        sGwiWTgsDJ = JKhJsmH;
        JKhJsmH = sGwiWTgsDJ;
    }

    for (int zabFHz = 424988918; zabFHz > 0; zabFHz--) {
        gKHPuh = pOeBWiP;
    }

    if (JKhJsmH <= string("dkqEPpKIzAOtlREVcCwycvldjHrhcteSeIGDjEVaCRmdFKKQoIHmrkSJZAkmxdHhJJGFTMKMNHyDsHwMftgnSIwmTd")) {
        for (int OvQweFWfDX = 2096048200; OvQweFWfDX > 0; OvQweFWfDX--) {
            sGwiWTgsDJ = JKhJsmH;
            gKHPuh += gKHPuh;
            sGwiWTgsDJ += JKhJsmH;
        }
    }

    for (int FkBvfNyiGbpgiP = 1453298689; FkBvfNyiGbpgiP > 0; FkBvfNyiGbpgiP--) {
        JKhJsmH = sGwiWTgsDJ;
        JKhJsmH += JKhJsmH;
    }

    for (int lodbdkTwbRjxa = 360548268; lodbdkTwbRjxa > 0; lodbdkTwbRjxa--) {
        sGwiWTgsDJ = JKhJsmH;
        sGwiWTgsDJ += JKhJsmH;
    }

    for (int TwuKmwnXM = 347153249; TwuKmwnXM > 0; TwuKmwnXM--) {
        sGwiWTgsDJ = sGwiWTgsDJ;
        gKHPuh *= gKHPuh;
    }

    if (sGwiWTgsDJ != string("dkqEPpKIzAOtlREVcCwycvldjHrhcteSeIGDjEVaCRmdFKKQoIHmrkSJZAkmxdHhJJGFTMKMNHyDsHwMftgnSIwmTd")) {
        for (int fNLAKR = 1941674679; fNLAKR > 0; fNLAKR--) {
            pOeBWiP += gKHPuh;
        }
    }

    return pOeBWiP;
}

string vAPtwkNCZXjY::jocHmrCBSc(int NKOeJMYct, double UjGczjyTzLMxIK, int QiYnwXTeXca, string ZDtaPi, int ofimOgHsqEAp)
{
    int hVZuD = -2120394583;
    double TksAPCxgAY = -326031.8133532968;
    string cSbFAODwCfK = string("lspyrQKaQADQwDSpGnUtJyicmvpFcdziQgiZeuoJzMVdGMRIHuxoQdiKUfKEaYHOYNCThkUuQgwHZtKOaVkqyMocZlYImaFAmdxXcGOOQkeDzZDXPYoHVdTrlPxYEqOIbhdzmxCrRLxkynFofmVzjCJZBnBzmzxiyVzYpwavrGXiFDVNtjoTgxBuMPCIePHzbnnZqtz");
    double dqAgYy = -780050.9139195562;
    double syzcfJVfScv = -411111.7128234993;

    for (int QaakV = 119196189; QaakV > 0; QaakV--) {
        NKOeJMYct += QiYnwXTeXca;
    }

    return cSbFAODwCfK;
}

string vAPtwkNCZXjY::xrlVZhjquqACgXEB()
{
    double RbdKSWtT = -1000503.5181590408;
    double QSwgqeHMGRiSaOqN = 838869.8738039796;

    if (RbdKSWtT <= 838869.8738039796) {
        for (int dROhjAby = 1454708331; dROhjAby > 0; dROhjAby--) {
            RbdKSWtT -= QSwgqeHMGRiSaOqN;
            RbdKSWtT -= RbdKSWtT;
            RbdKSWtT = RbdKSWtT;
            RbdKSWtT += QSwgqeHMGRiSaOqN;
            QSwgqeHMGRiSaOqN += QSwgqeHMGRiSaOqN;
            RbdKSWtT *= QSwgqeHMGRiSaOqN;
            RbdKSWtT /= QSwgqeHMGRiSaOqN;
            QSwgqeHMGRiSaOqN *= QSwgqeHMGRiSaOqN;
            QSwgqeHMGRiSaOqN += RbdKSWtT;
        }
    }

    if (RbdKSWtT != 838869.8738039796) {
        for (int NfGBxyYZSruQM = 696605506; NfGBxyYZSruQM > 0; NfGBxyYZSruQM--) {
            QSwgqeHMGRiSaOqN /= RbdKSWtT;
            RbdKSWtT = RbdKSWtT;
            RbdKSWtT /= QSwgqeHMGRiSaOqN;
            RbdKSWtT *= RbdKSWtT;
            RbdKSWtT = RbdKSWtT;
            QSwgqeHMGRiSaOqN -= QSwgqeHMGRiSaOqN;
            QSwgqeHMGRiSaOqN *= RbdKSWtT;
            RbdKSWtT -= RbdKSWtT;
        }
    }

    if (RbdKSWtT < 838869.8738039796) {
        for (int boJUkJNiTnipn = 2026087957; boJUkJNiTnipn > 0; boJUkJNiTnipn--) {
            QSwgqeHMGRiSaOqN += RbdKSWtT;
            RbdKSWtT /= RbdKSWtT;
            QSwgqeHMGRiSaOqN += QSwgqeHMGRiSaOqN;
            RbdKSWtT -= QSwgqeHMGRiSaOqN;
            RbdKSWtT = RbdKSWtT;
            RbdKSWtT /= QSwgqeHMGRiSaOqN;
        }
    }

    if (QSwgqeHMGRiSaOqN == -1000503.5181590408) {
        for (int HGQeGuBi = 2129750653; HGQeGuBi > 0; HGQeGuBi--) {
            QSwgqeHMGRiSaOqN -= QSwgqeHMGRiSaOqN;
            RbdKSWtT -= RbdKSWtT;
            QSwgqeHMGRiSaOqN -= QSwgqeHMGRiSaOqN;
            QSwgqeHMGRiSaOqN += QSwgqeHMGRiSaOqN;
            RbdKSWtT /= QSwgqeHMGRiSaOqN;
        }
    }

    return string("orhdPnBVQyBsQ");
}

double vAPtwkNCZXjY::qfFwFoTHHDmC(string fXtByuKTy, string FCmKmtHVgE, bool UyRvqK, int FsimOwSFzjclx)
{
    double pjUNuAkjiBA = -262474.1065701205;

    for (int RbQBvxIPNoSjV = 264837213; RbQBvxIPNoSjV > 0; RbQBvxIPNoSjV--) {
        UyRvqK = UyRvqK;
    }

    if (UyRvqK != false) {
        for (int qUWKbJKH = 1794909695; qUWKbJKH > 0; qUWKbJKH--) {
            fXtByuKTy += fXtByuKTy;
        }
    }

    for (int mXGcDiMWSGle = 880410739; mXGcDiMWSGle > 0; mXGcDiMWSGle--) {
        FsimOwSFzjclx += FsimOwSFzjclx;
        pjUNuAkjiBA = pjUNuAkjiBA;
    }

    return pjUNuAkjiBA;
}

void vAPtwkNCZXjY::zqypjzNwRpzU()
{
    bool UiZnpctbrsqZxf = true;
    int CitAv = -1932343096;
    int bFuShtl = -1316172315;
    string EOagxegYuCYSk = string("aBiWdhhoWSrvrJZEwdGOcGjqpeVmaIuJRbrkZYIlbMWYFMKdhXAEsSIfrQHWlxXAssxhGIXSOnzPFhRnfdBljnoIUBONstOCTdcuxBCgVMOUjbdKdQIOAbVXhsWuHBoPVkSVWQIPZLfiqnVmNcSjybXuFUWOxzYaoUFroWTgopLwyrRvmEXxWhMdijBL");
    int ynJPIRZe = 809424233;
    int iqznEuf = 88433089;

    if (bFuShtl != -1932343096) {
        for (int dbiAdSbNOK = 1131538064; dbiAdSbNOK > 0; dbiAdSbNOK--) {
            CitAv -= CitAv;
            CitAv /= bFuShtl;
            ynJPIRZe = bFuShtl;
            bFuShtl /= ynJPIRZe;
        }
    }

    for (int VJEPOsCEpw = 597276054; VJEPOsCEpw > 0; VJEPOsCEpw--) {
        bFuShtl = CitAv;
        CitAv /= iqznEuf;
    }

    if (CitAv < 809424233) {
        for (int PCepPE = 148062606; PCepPE > 0; PCepPE--) {
            CitAv *= ynJPIRZe;
            bFuShtl /= ynJPIRZe;
            CitAv /= ynJPIRZe;
            bFuShtl -= ynJPIRZe;
        }
    }
}

vAPtwkNCZXjY::vAPtwkNCZXjY()
{
    this->KziSbvSQQdqEan();
    this->roUnvGdD(324702185);
    this->TrWub(true, -2101189670, string("OCOrSWvRdzOEJHaWaTSVDBvzzBSohnMftptgkoLInIspfnaungZCjhkhzZDEHMbeWRqpppwdhTUaNTIK"), false, -258737.87167274015);
    this->bjVhxM(string("owikhxDgfPWADbMjejrxBelNgzDmvhpsJeZtJnrvlrxLYUBFWOjJQpZdhJERGwSWVcdDejDAIMZvoBHqigDvBmhgYZDvvWLopDPfDMxKimCQEQYhdIIMzjQBcYhTkiXlGogFcZSgZZdbKLSPXvLHKX"), string("AYKwhXDgTbuUjwEDDavWPRedQAITRwlCMkfYSDiYcOXvVikrDnKRySGBuoiOGIikhqinIrtYLlkDjEfuSjCruCmJrFgnzbYyymDtSRuhztWdLpfktzndvpzmPPeNcCqcbhReeJuYUKOzVVWMHqAgKNxRtOtlIaLDqJJTfUFABJKwSVZZLRjYHYtjPYy"), false, -705617.2902336892, string("HOGbRbrGoGdIxZblyOXHpJptShFfctbzq"));
    this->PUCchJPBPC(true);
    this->eoJodEHQzpohhU(70059.67069034032, 520613.99982585834, 814487423);
    this->JoGRNBjhoFa(672518.1420736812, -215104.68987249926, 507435.21945367154);
    this->uiBoxwSalynneHH(string("O"), string("dkqEPpKIzAOtlREVcCwycvldjHrhcteSeIGDjEVaCRmdFKKQoIHmrkSJZAkmxdHhJJGFTMKMNHyDsHwMftgnSIwmTd"), 718247766);
    this->jocHmrCBSc(-1201876520, 1019337.3089804297, 378042939, string("FRVdUUjCNsVTJUDXlJUNfPGuuKRYDvBMMFIiWynLLIrhAALGUXTNkSArWRyhpAWhPsILPwYVDDTgTVrPvHqRtDICdKinvEUzcWIqhODKxDFknLjufZWjHAUpLLTLtwxJosNUtjcMtzfebeSHfXKvXiyuDigRmVVWUxVAFEATeWhvRnCkesaVQRNtHjOhBZwNcDoXUUCcuRyhGXfiJTDcZNWcVEndVhFIdkAAXbOdTNgEypIIHxfFUNnqZxspRpC"), -525890582);
    this->xrlVZhjquqACgXEB();
    this->qfFwFoTHHDmC(string("UVizkdEuJbItkJBBOYXbemMoJWwTDuuKdxSQnZn"), string("VuHRtlLfTNJrZJyTUamtWMsFKnBMqMBsGWKcuRhCz"), false, 140745140);
    this->zqypjzNwRpzU();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ExubdnJr
{
public:
    bool hzYwpCkAsMakmS;

    ExubdnJr();
    int dDkTxSj(bool SSVWNj, double FKOOXZB);
    int evKkBA(int jWAhKwf, bool qzZHf, int eSqMKtSGI, int zqZVEQXxLjurot, bool CqRHbddqAyDr);
    double IpsLtXCIBvKr(double UPuSoTXPX, string uEyPaIhS, bool gPpdZTl);
protected:
    bool MBeqTwTiQePjq;

    double BoClpyOXtC();
    void DIIRbyFLgfeqeO(int PZRWbqTsHIXo, double rTUauBTgRi, int YUiREMgmcBNHvATf);
    int FUmsXzKDrLQOBE(string jLHgdraSdPsLqJkw);
    string YECqhAxYRQOEZ(bool ErzXoahjjzVU);
    void jOMtdKv(int qopnILRiTAFea, double ITWyyfJrvjsKsR, int hKtLyvZIefAB, double TOSwemfRLpNh, double VvGhpxKkQZCS);
    string wxdxmlpjWWQI(int aXVTNtbbz, string wGjoJ, bool fboXczlHKtYUvED);
private:
    bool GYKxlPmtTbHsZajs;
    int oERhDah;

    bool sCQwcj(bool srSmFTCrqGGI, double hUVnqx, bool HVIoBsikEVNGGnQM, int BMLAfiJsdvsM);
};

int ExubdnJr::dDkTxSj(bool SSVWNj, double FKOOXZB)
{
    int lgqrnaVa = -442685412;
    string EiiyA = string("sJTmOARZnwOpghyMFogUlWEXPorxwhyXCcOJJBBPWfISbCxYDmfehbaHqZSmplvodUE");
    string zihhSwydKUX = string("QVEbdfYiyOfSXYlNWMkEtqFcxQpzsQusQKWwWgQtQLRJxpoaoJrCOAeKnbgRKvGxawNlKhnqcQBPIEruHpHEnakTAOInLIaUfFdmoVOkxEFUKSCehQyyrkzfDzpdQEKtaulRNyEJTFPpGcnHiTacHjhcdmRINfEUtUZzdTZdfsewFNhvlkqkqOwzgVtTlKicvcoPjZMAYJafKiGtocdBE");
    string solzWNr = string("clxOEgyVPcyQsBDDIElqIDflVaKkOXVYbWhRgbVBWbJlhDiiySmnolcKVUFxEGfZDttUfJbDYEYtrzheCEQTUrtQyMJyohBjGspdJKnyUmzCiSDlHkLEcXKEOyrGSNqnCzOCYsheOUkWCgMOfSdyUtaxTOkWGxoUUoBZOkUSLsjzStOPxqTzTpFUQYybLIgrlTUJJVLgeAZwWubZUUMsYb");
    bool uEjQJPHWH = false;
    bool KLOllaVteWj = false;
    string kteCvQOcmIkXSzLH = string("cpXvIBfEoDEhuoAmWIpUtjYrDXGZJJAnnHTZOFTBpaFJYywGlYnpRoUiWr");

    for (int QxMuoObkmAELOG = 1172557401; QxMuoObkmAELOG > 0; QxMuoObkmAELOG--) {
        uEjQJPHWH = SSVWNj;
        zihhSwydKUX += zihhSwydKUX;
    }

    for (int BRvwTSRGjF = 1779060016; BRvwTSRGjF > 0; BRvwTSRGjF--) {
        continue;
    }

    return lgqrnaVa;
}

int ExubdnJr::evKkBA(int jWAhKwf, bool qzZHf, int eSqMKtSGI, int zqZVEQXxLjurot, bool CqRHbddqAyDr)
{
    int WbEnPmMBoL = -1843600914;
    bool uFYwGoKWoGkQ = false;
    string hbxuDvmeGmW = string("vfmSANcDQMuqALrWAIaXxXeUXOXqQJnJfClfjoTIZEqldLAhTzHDQXtRIwTQdzbZwCaNUSGcffhaFtyDwzSkzlSXsNCAvLswVFiYHUiMmyXDAYgRjDGQDyNtuoQlqYIPXEOssKWHTrnEwBauVXfEBCSsbFt");
    bool SNPRmtIJX = false;
    string RROruCYY = string("DPBFIXcDxEIIiVwBPTsVJXYVeNiUbyLHxjlsNPudiQAtMrxzwsaMnWbOQHHQTcVErFGvyKCITALlqirELpmSNdhpGDYYRofepuGoDLfEIlMHKxcsjeznUGDYEguwwOpYkxzeNIFLyeXYVgZmpwhKpUbSOYrGmfGMfPSLUcYYuKgdfMmdUzPIbobanhlTQNeSGhteqEbGQmikaRBkUfnSxqL");
    bool ZZxUDUvi = true;
    int JVCwfw = -2122905507;
    string LKzJZtRPpkAAhmO = string("gkXZelfxkzuBVONecYHZcrvGOSWlhImPUPGrEJw");

    if (RROruCYY <= string("DPBFIXcDxEIIiVwBPTsVJXYVeNiUbyLHxjlsNPudiQAtMrxzwsaMnWbOQHHQTcVErFGvyKCITALlqirELpmSNdhpGDYYRofepuGoDLfEIlMHKxcsjeznUGDYEguwwOpYkxzeNIFLyeXYVgZmpwhKpUbSOYrGmfGMfPSLUcYYuKgdfMmdUzPIbobanhlTQNeSGhteqEbGQmikaRBkUfnSxqL")) {
        for (int EfFts = 93757826; EfFts > 0; EfFts--) {
            zqZVEQXxLjurot -= WbEnPmMBoL;
            zqZVEQXxLjurot -= JVCwfw;
        }
    }

    for (int zMTfulcjYs = 659325412; zMTfulcjYs > 0; zMTfulcjYs--) {
        JVCwfw /= eSqMKtSGI;
        hbxuDvmeGmW = LKzJZtRPpkAAhmO;
        eSqMKtSGI -= jWAhKwf;
        eSqMKtSGI -= JVCwfw;
    }

    return JVCwfw;
}

double ExubdnJr::IpsLtXCIBvKr(double UPuSoTXPX, string uEyPaIhS, bool gPpdZTl)
{
    bool xhlRmt = false;
    string ExEoHwdBclFysLqE = string("mBwFDAJeOphXOGqXYYPQVcbwzRKalKBlaiUsRFYJhEXBBujoNrKgHWwTqUoXdkKEgkvmxWUakfRQhVRAkWRhrpZFNlooQAfygYXIyzcyfOivAnvKhGAzQXbsxvidscVqgbrhhAJBvGcNhWsFPLriKgmfecqxeyWFcugCoFndZHsWcKYvNkGCWRRTeVIDHVPUsExLEStqdQPtXnp");
    string AqLuhavQpN = string("IgiGghPGdBVZmyZFwyTtcAnFzJPsJQOhwclnoAarlrunrYEsJRdbzqWVQEvpSCKncyNUocCyFqMamucVKhYdUEQTSHTyiYBOiTGBvTzbcHWLvxbrXgmJSmqUjPPwdqjfGlQusuztMFzqpzOJKHEnuyVBnbUhqkQaoLBniMHPDRFTXByNMeNVpeNhtAQbvSGuOws");
    double WXfMPjtbl = 237911.39433448363;
    double SDByXqtd = 567142.0617250344;

    for (int pDWyouzllsOCM = 596277320; pDWyouzllsOCM > 0; pDWyouzllsOCM--) {
        SDByXqtd /= SDByXqtd;
        gPpdZTl = ! gPpdZTl;
        gPpdZTl = gPpdZTl;
    }

    for (int oWLbsH = 345748369; oWLbsH > 0; oWLbsH--) {
        AqLuhavQpN += AqLuhavQpN;
    }

    for (int WrXbKoOaiH = 1867453795; WrXbKoOaiH > 0; WrXbKoOaiH--) {
        WXfMPjtbl /= SDByXqtd;
    }

    for (int ZDyynwbPOUfziv = 999423751; ZDyynwbPOUfziv > 0; ZDyynwbPOUfziv--) {
        ExEoHwdBclFysLqE = AqLuhavQpN;
        gPpdZTl = ! gPpdZTl;
        ExEoHwdBclFysLqE = AqLuhavQpN;
        WXfMPjtbl = UPuSoTXPX;
    }

    return SDByXqtd;
}

double ExubdnJr::BoClpyOXtC()
{
    int mbwWtNoCOcb = -1914254965;
    double FKOzxEqbTPcYUv = -423855.2605694219;
    int RGLkvZILZIfGqFh = 2005314226;
    string kjYaX = string("ifVezpdcqDlPltJJzjbciuTdCWqwAj");
    int aeClDbe = 1593639614;
    string jnuxTlFbTej = string("pYLLeIgOLETXofbbpTpBIggqrebHMQWqOCUIulf");

    if (aeClDbe > 1593639614) {
        for (int VGGYtecmxxSgMNt = 539719947; VGGYtecmxxSgMNt > 0; VGGYtecmxxSgMNt--) {
            kjYaX += jnuxTlFbTej;
        }
    }

    return FKOzxEqbTPcYUv;
}

void ExubdnJr::DIIRbyFLgfeqeO(int PZRWbqTsHIXo, double rTUauBTgRi, int YUiREMgmcBNHvATf)
{
    int TOyoFhoCH = 1262258308;
    double rUrCTEBLgCAkQiE = -579826.5376279501;
    double RgKWZyEi = -412873.2248571243;
    string kcBXqyu = string("eNgHSUOwfaDKiOybQyJgZFGkveLnixQmvNolKyHmFkSrPFowniPAVoKcPcOjrIqxFsbKBhsAEYCUouRF");
    double QWhuGnQuewGXwvIc = -346120.7753432526;
    bool GJiYuauQQnx = false;
    string jFSEZDEsglOHbDo = string("iVEBSsNjxlCnPzprRdcxkSUCAaFAJZnvmuKqjEPougJesmjMgElPlNiEsytpj");
    int CNkdDf = 1242557523;
    int VklYjMQvxaPlCUZ = 1779203809;

    for (int ogHrOktGWthhcc = 1851592343; ogHrOktGWthhcc > 0; ogHrOktGWthhcc--) {
        QWhuGnQuewGXwvIc -= rTUauBTgRi;
        RgKWZyEi *= rTUauBTgRi;
    }

    if (VklYjMQvxaPlCUZ >= 1779203809) {
        for (int NXZjitzeYFm = 1861316177; NXZjitzeYFm > 0; NXZjitzeYFm--) {
            continue;
        }
    }

    for (int UmDmLRAoAr = 1142123996; UmDmLRAoAr > 0; UmDmLRAoAr--) {
        CNkdDf -= YUiREMgmcBNHvATf;
    }

    for (int ZpbBNxb = 1518503117; ZpbBNxb > 0; ZpbBNxb--) {
        YUiREMgmcBNHvATf = TOyoFhoCH;
    }

    for (int wEtnLdEhmRD = 1854564138; wEtnLdEhmRD > 0; wEtnLdEhmRD--) {
        GJiYuauQQnx = GJiYuauQQnx;
        QWhuGnQuewGXwvIc += RgKWZyEi;
        PZRWbqTsHIXo /= VklYjMQvxaPlCUZ;
        CNkdDf = PZRWbqTsHIXo;
    }

    for (int hwIarqgS = 1946566020; hwIarqgS > 0; hwIarqgS--) {
        continue;
    }

    for (int RGhwuLLgcJxJCz = 1263616833; RGhwuLLgcJxJCz > 0; RGhwuLLgcJxJCz--) {
        PZRWbqTsHIXo = VklYjMQvxaPlCUZ;
    }
}

int ExubdnJr::FUmsXzKDrLQOBE(string jLHgdraSdPsLqJkw)
{
    bool gEQzunfkhiiZZD = false;
    int aDohbbT = 1901784911;
    string OJzDvmit = string("nixabQkbRTxGSslgYVuAaJTxhbVXGrXrhbhagrgIwrUgWeNWyxgqedAuxWBrDBOiYXnWCdGwnFbdVWEmpUUIsxuQAceeramqfoxWZ");
    int dhzTESIPZdPWGefz = 1973539356;
    bool PFKgPGQzt = false;
    int DhwnSls = -1814293738;
    string lncCwG = string("oGrTYNXxWZPLrqJRfhXANpXIDIOFOMfAILOoMwJklZaObxUfwUngTBzVDXWPgUHLZkwfCtQDAwdGrSgiDTmFZNHqjESTJknqmuzHQWavKDvPeeqqYUDbFPXeFtGAxoJWTQDvLJlsOTjJzlsQKTzmZXXDqsoLnzhYfHJDgxzIdOgFWFNEGBhgPlHsMkOlKvZfTswMfaGMcfFIzDeLUsE");
    string ELXVle = string("PzjDBsRpmlRXCGsJamHJlvJdafHhsiUzBfwFZFSgerSyjQmhVoLkLQLrThFXTXwBelrFuMBtLhTVrYLYIXGnODUHHYillcSUctzACfekHnVIFPZkJAXNzvPYrZsbUuGkqGgolCloSfLrqTKJDFZcERDOsKke");
    string BSNNLdD = string("HqWTxJHQjQclMXSSUFOvpOyFrRtizxEBiWCcnyTQWrGQBPgidYBkWKXKmoFYWaUMygUNffSkHtJIjJmIxlBr");
    int sQoJrFVQK = -1165327820;

    if (dhzTESIPZdPWGefz > -1165327820) {
        for (int MjPutLf = 320872621; MjPutLf > 0; MjPutLf--) {
            ELXVle = lncCwG;
            PFKgPGQzt = PFKgPGQzt;
            DhwnSls /= DhwnSls;
            aDohbbT -= DhwnSls;
        }
    }

    if (BSNNLdD != string("QoVPkSOEPVMENFfuVpIDTRyw")) {
        for (int sgUsAd = 11689298; sgUsAd > 0; sgUsAd--) {
            dhzTESIPZdPWGefz = sQoJrFVQK;
        }
    }

    for (int ffHMinG = 401822331; ffHMinG > 0; ffHMinG--) {
        continue;
    }

    for (int HYsSycTJZp = 1928037360; HYsSycTJZp > 0; HYsSycTJZp--) {
        lncCwG += ELXVle;
        sQoJrFVQK /= DhwnSls;
        lncCwG += BSNNLdD;
    }

    return sQoJrFVQK;
}

string ExubdnJr::YECqhAxYRQOEZ(bool ErzXoahjjzVU)
{
    int nrdKZHfXwxRK = 1172902007;

    for (int TgweZqni = 1109972474; TgweZqni > 0; TgweZqni--) {
        ErzXoahjjzVU = ErzXoahjjzVU;
        ErzXoahjjzVU = ! ErzXoahjjzVU;
        nrdKZHfXwxRK *= nrdKZHfXwxRK;
        ErzXoahjjzVU = ! ErzXoahjjzVU;
        ErzXoahjjzVU = ! ErzXoahjjzVU;
    }

    for (int ItVSWBtBeKGDrp = 564528285; ItVSWBtBeKGDrp > 0; ItVSWBtBeKGDrp--) {
        ErzXoahjjzVU = ! ErzXoahjjzVU;
        ErzXoahjjzVU = ErzXoahjjzVU;
    }

    if (ErzXoahjjzVU != false) {
        for (int VICLZkGDo = 602862692; VICLZkGDo > 0; VICLZkGDo--) {
            ErzXoahjjzVU = ErzXoahjjzVU;
            nrdKZHfXwxRK *= nrdKZHfXwxRK;
            ErzXoahjjzVU = ! ErzXoahjjzVU;
            ErzXoahjjzVU = ErzXoahjjzVU;
            nrdKZHfXwxRK *= nrdKZHfXwxRK;
            ErzXoahjjzVU = ErzXoahjjzVU;
            ErzXoahjjzVU = ! ErzXoahjjzVU;
        }
    }

    if (ErzXoahjjzVU == false) {
        for (int PbhiOHtSnLZJ = 31196805; PbhiOHtSnLZJ > 0; PbhiOHtSnLZJ--) {
            continue;
        }
    }

    if (ErzXoahjjzVU == false) {
        for (int bTaeThWVrTKTt = 191792127; bTaeThWVrTKTt > 0; bTaeThWVrTKTt--) {
            nrdKZHfXwxRK /= nrdKZHfXwxRK;
            ErzXoahjjzVU = ! ErzXoahjjzVU;
            nrdKZHfXwxRK += nrdKZHfXwxRK;
            nrdKZHfXwxRK -= nrdKZHfXwxRK;
            nrdKZHfXwxRK -= nrdKZHfXwxRK;
        }
    }

    return string("iwCwIMAolVDpQiIGn");
}

void ExubdnJr::jOMtdKv(int qopnILRiTAFea, double ITWyyfJrvjsKsR, int hKtLyvZIefAB, double TOSwemfRLpNh, double VvGhpxKkQZCS)
{
    string PRBJtWPwvr = string("yHrogpuiUfTHkEfzoyyFmuJWTVJQscaXZrvkMyskgCbnNNsEOubMWdCqYUKwYRfPNJlLFq");
    double vbamveBRvSmfb = 1020750.4937273731;

    for (int QieQG = 2110655493; QieQG > 0; QieQG--) {
        TOSwemfRLpNh *= vbamveBRvSmfb;
    }

    if (VvGhpxKkQZCS >= 1020750.4937273731) {
        for (int ZFQvDcDjZSEQ = 1999278317; ZFQvDcDjZSEQ > 0; ZFQvDcDjZSEQ--) {
            ITWyyfJrvjsKsR *= VvGhpxKkQZCS;
        }
    }

    for (int uXkzfukQUjneTj = 1417509528; uXkzfukQUjneTj > 0; uXkzfukQUjneTj--) {
        TOSwemfRLpNh *= vbamveBRvSmfb;
    }

    if (ITWyyfJrvjsKsR <= 1020750.4937273731) {
        for (int FrjElOBj = 104238184; FrjElOBj > 0; FrjElOBj--) {
            continue;
        }
    }

    for (int QPIjX = 683975142; QPIjX > 0; QPIjX--) {
        continue;
    }
}

string ExubdnJr::wxdxmlpjWWQI(int aXVTNtbbz, string wGjoJ, bool fboXczlHKtYUvED)
{
    double ZqvBQUKYwJLCsRk = -231531.68038076334;
    double lPlMiycbsIMqp = 458595.1653986025;
    bool TLdLhLIBvF = false;
    bool kraTyaBOuXMnS = true;
    double CDaiebgjevmp = 905719.2074725726;
    bool wDVEzZNSKvjDfmW = true;

    for (int nTecEdYnOBnKWk = 1672523228; nTecEdYnOBnKWk > 0; nTecEdYnOBnKWk--) {
        fboXczlHKtYUvED = ! kraTyaBOuXMnS;
        ZqvBQUKYwJLCsRk = CDaiebgjevmp;
        ZqvBQUKYwJLCsRk -= CDaiebgjevmp;
    }

    for (int EHQEVpuMmvCdME = 1559338461; EHQEVpuMmvCdME > 0; EHQEVpuMmvCdME--) {
        lPlMiycbsIMqp = lPlMiycbsIMqp;
        aXVTNtbbz += aXVTNtbbz;
    }

    return wGjoJ;
}

bool ExubdnJr::sCQwcj(bool srSmFTCrqGGI, double hUVnqx, bool HVIoBsikEVNGGnQM, int BMLAfiJsdvsM)
{
    int INNKYsyEuSdImmu = -1873905243;
    double ZJPtlmUBXSksGjmg = -288630.69420009776;
    string EdCoJTG = string("aJcORelIWXFcAIirkDjgnQfwagCFdUxcBrLIuaxXeWiiNNUpJoxRZsyqsMjcmdxiOVIyfiMSpwrzKcNvqcSGtHzKoPEPqmjbfS");
    int zilOJWPYtBWySBB = 592501511;
    double essqtSpZeJ = 395415.40499646496;
    string cZvMdVeuLtrv = string("dNrqdrrxGapRNyxXtkwiOGRnUIRQApiMQiKfLOoLCybNUwZUGIaRrbslkVCxWbYyGAriCKubyWNUEeBZlcvLBetrTHj");
    int uJTGwzdgrAi = -1268357204;
    bool KLspiNvglkGd = false;
    string MRtTrPHpcjhKpMg = string("tiomCfysLxPRbgReUbKLrlVWDQLpUQHPYNXbUIZnGqDRezwSGnSHw");
    int rgmQFCQ = -1487944280;

    if (EdCoJTG == string("dNrqdrrxGapRNyxXtkwiOGRnUIRQApiMQiKfLOoLCybNUwZUGIaRrbslkVCxWbYyGAriCKubyWNUEeBZlcvLBetrTHj")) {
        for (int vjgMdHvPyrD = 1505423161; vjgMdHvPyrD > 0; vjgMdHvPyrD--) {
            uJTGwzdgrAi -= BMLAfiJsdvsM;
            rgmQFCQ = rgmQFCQ;
        }
    }

    for (int powgrj = 33221390; powgrj > 0; powgrj--) {
        BMLAfiJsdvsM = uJTGwzdgrAi;
        BMLAfiJsdvsM = rgmQFCQ;
        rgmQFCQ /= uJTGwzdgrAi;
    }

    if (MRtTrPHpcjhKpMg == string("dNrqdrrxGapRNyxXtkwiOGRnUIRQApiMQiKfLOoLCybNUwZUGIaRrbslkVCxWbYyGAriCKubyWNUEeBZlcvLBetrTHj")) {
        for (int DlbnjXrSQUjp = 1864373226; DlbnjXrSQUjp > 0; DlbnjXrSQUjp--) {
            zilOJWPYtBWySBB /= INNKYsyEuSdImmu;
        }
    }

    if (INNKYsyEuSdImmu > -1487944280) {
        for (int ykqAwlvFxO = 1007909186; ykqAwlvFxO > 0; ykqAwlvFxO--) {
            essqtSpZeJ /= essqtSpZeJ;
            hUVnqx += ZJPtlmUBXSksGjmg;
        }
    }

    return KLspiNvglkGd;
}

ExubdnJr::ExubdnJr()
{
    this->dDkTxSj(true, -903710.145675596);
    this->evKkBA(616228979, true, -1619958288, -499428856, true);
    this->IpsLtXCIBvKr(-3845.9278945911437, string("GmwzPqtFycUcqHAkpXPEsxLbfevNsYkiBvATABaHoBvJNUaCZsfEdtlIjvSSCCDBuSAEbAgrDwtSWMSFwqZxgqujTafqBA"), true);
    this->BoClpyOXtC();
    this->DIIRbyFLgfeqeO(1924215949, -573329.0298584218, 1191397962);
    this->FUmsXzKDrLQOBE(string("QoVPkSOEPVMENFfuVpIDTRyw"));
    this->YECqhAxYRQOEZ(false);
    this->jOMtdKv(2081049944, -207150.4882293035, -1048909926, -39755.945088715154, -678091.1294006426);
    this->wxdxmlpjWWQI(-1214753741, string("ZpUqQoolcFQULWdoEDnCRElrsizbhXafAVutWDyQoQjPtVSPTFafkMWRXWofBfGuOCmnlZaqUibVUUhrOjkMDKxtHdFOFytUnHeXUbniYXtxBTFdzYZeIcELYAizyXTexaESRvasCAQmvQtQSYrIoobMskpOlxeRbbbAgGnQwHZsjSNjOWfruLTrDhOOBNchsCTtOpozxlrwXSObkLRWUzbuWOPDJnxCSDlbdilvULmsLzDDRAVP"), false);
    this->sCQwcj(true, -324016.31761234, false, -40716515);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FcdtTvcJ
{
public:
    string AQurtsT;
    bool IWyhHPHILyRcDYV;
    double wmUWDOEqdSaZ;

    FcdtTvcJ();
    void esYnkFwBiXG(bool HIUbp, double PQeSiOCnFIA, int dNsxbLwLtMPF, int fjUXpAZAHOGXuvj, bool bgYMitWzuWKf);
    int bfczzAAaOpL(string McssqDXxauXF, string SylbkHFYmvnmqb);
    bool DCFWFOiVHoigX(int JAUDFuN, int nqqKr, double vICfkFWLKHee, string pMUqf, string MMzLEgz);
protected:
    double YRwiyyJTvDwmIN;
    double VkPIGWiOLhBpqYfv;
    double OrgDcGEOXSITW;
    int wIUmXjXtBaftAeA;
    int OOHvw;
    string GceYPZsVxPnjd;

    string vENEmXN(int JaaawZYkUiJe, double IIEHphnItDfBe);
    int gFdFIrPHq(double nLJsQVewjFJyLdV, double SFnCCnBKNBtTVk, double gwbMVhwoOq, int olOMpSwF);
    void zElOzsSBpILtQCAk();
    bool ZmrndGpSvkaDan(double XuWcpgwNXjUxxjE);
    int emaancB(string BmLxSRjDn, bool tjVwnunmpNrr);
    double PqHqB(double jmGTrHNqthKU, string BWPSzT, string zvxlnaRQxNcxd);
    string bRltkPJjihbVBb(string OzebPQQvi, bool dMjtVbFqSecFsgV);
    double sZFeihP(string LHvUjOMmwfQSj, bool rvAnpu, bool erbqf, bool ccEonnUntGwEKlm);
private:
    int LHvuOfUfJGlHsrqb;

    int rCiclBg(string xWCBVnrxwbqYlVVO, double aLYFtjYUOXyVq, bool GKuiCGNkGfGLJH, int tRjIOzhNQlgj);
    string wFqTandBCTnnDIdP();
    string YaLUP(double iWMnoPeS, double WiOBlloCPsvsu, double IvpOzdJq, double qFmloKsx, bool yAnqnmp);
    bool tfoGakUVMwf();
    int qdbDPaYVaXwU(double oZYHs, double NDxyCrphUI);
};

void FcdtTvcJ::esYnkFwBiXG(bool HIUbp, double PQeSiOCnFIA, int dNsxbLwLtMPF, int fjUXpAZAHOGXuvj, bool bgYMitWzuWKf)
{
    int gCkOQCTmaIdkcQ = -1081752090;
    string YbHFSkQyNHADlfx = string("LGYSebzKuxuCSrrqdWExSQAUlMESxauSykNtzWLEadEFbCNAFYZASzcFyPkVZiOIjVAmHSYjRqZzaiAHfOXenaXdqQLuVIVeddVDdKFthRWcdrHWIEvpuCIoLCKvnscWhvGsVtihDgXxKzxdphyFaVUzKHpwxCrxDHxOYQjFiEbpKkSIRepVfXfhDslSGiTAYuiGJZVsSbMGenwgCzWtewiY");
    double EBFAHOJeEYtIew = 1024259.3927117394;
    string xAjekfWYAjLEiBY = string("qyPFbJcApdArGSAdmnaHOJltorVNcMTUPyddshoKBEXJYsUfyUMHhJiloyciNwZfXrbEIKAhrbSwCHNukgfRhaeAtdfGoHoYjIgLsynZBzUBBQUuthjJTVOC");
    int jEOxskOyjDW = -1700955878;
    string dlVlUMMwFP = string("NXmZNTbXopklkSMLWJKXEGEqmkinvTRsBmBEqBlshAIfHmUmztZkbjjhsakRIMJvwgYLVYeIvmBogxpGeitwONNfykmgiyDpOGGJzRJZuYACzzBDSVreSCjwOFUoQZpJKTFkCEHseCDNovLVZvrUgMsvFeWHEwdjOIQhGeedmnSIwipsYyokyxvrLimohXBWpRE");
    bool qthhAOxWOAj = false;
    double qtuEmVVsj = -979891.3558363813;

    for (int EdbFJgIxYnkcDH = 859435694; EdbFJgIxYnkcDH > 0; EdbFJgIxYnkcDH--) {
        jEOxskOyjDW /= jEOxskOyjDW;
    }
}

int FcdtTvcJ::bfczzAAaOpL(string McssqDXxauXF, string SylbkHFYmvnmqb)
{
    int HiBQu = 2139611228;
    int tNsxnrq = -908330961;
    double okfdCp = 879441.6035313072;
    int BrHGPvFCnSxk = -1955862212;
    double bQWgtDSmyoo = 444450.16218346945;
    double BKedZjvb = 803194.1188123989;
    bool fDEbUnFmPwoCaUKL = true;

    if (okfdCp > 803194.1188123989) {
        for (int DZxSLaxqVRvijYg = 32579557; DZxSLaxqVRvijYg > 0; DZxSLaxqVRvijYg--) {
            tNsxnrq /= HiBQu;
            McssqDXxauXF += SylbkHFYmvnmqb;
            McssqDXxauXF = McssqDXxauXF;
        }
    }

    for (int PwHKzjS = 942185923; PwHKzjS > 0; PwHKzjS--) {
        continue;
    }

    if (bQWgtDSmyoo >= 879441.6035313072) {
        for (int QtZvbIAE = 361748470; QtZvbIAE > 0; QtZvbIAE--) {
            continue;
        }
    }

    for (int bKfzTKNk = 2083242261; bKfzTKNk > 0; bKfzTKNk--) {
        BrHGPvFCnSxk += tNsxnrq;
    }

    for (int hUFOw = 958849034; hUFOw > 0; hUFOw--) {
        continue;
    }

    for (int geNkBlfOCwrlW = 497721209; geNkBlfOCwrlW > 0; geNkBlfOCwrlW--) {
        BrHGPvFCnSxk = tNsxnrq;
        SylbkHFYmvnmqb = McssqDXxauXF;
    }

    for (int vheiJPOmkGk = 2023309172; vheiJPOmkGk > 0; vheiJPOmkGk--) {
        HiBQu -= BrHGPvFCnSxk;
    }

    return BrHGPvFCnSxk;
}

bool FcdtTvcJ::DCFWFOiVHoigX(int JAUDFuN, int nqqKr, double vICfkFWLKHee, string pMUqf, string MMzLEgz)
{
    bool KREaTTcVgYfsYwX = false;
    string NbXvynFbbGGKfiHd = string("bDbiLZgwZIoYcpOtITlOofpfrBrDgZNfbeIrciUkaAPgwRfuKJFYiWEwOmWPqpUZ");
    int HZROepftrX = -868137312;
    string uCitUqIxLEyIb = string("ICEUzYBJLdLqUaBIoqKoTxVsorOxEiEOArIDeFIjruditYcHkzPQUwUqDAscoLHiKGgLcCzpYdYQBEvNCZafKWocFErwDjZGorsGiiPcuTYsrCSjktQTakJDIyMdsVdMLleBBpAqAfeugKBwoHTouxaNYIeSnsGVjnoZuQKcfwHPoIQIHgtFsUCYaPeOheC");
    string PcSDeOAHGg = string("SqyMZeuaaHrkXBwJRvPEHnyTqpQBzsKdESYHeWcVpFEAUiZGSwmXIrAnQWoFHHmYgEJEziuzDvMOEIfHVEdafivuWjnDURuFwCgNipozXnMpPEFtkGTgeHWhHwjHpoIZIIJWHEqDLfqKtmVuNPjPWOkyslIeGOTlxlb");

    if (nqqKr == 1092068799) {
        for (int mybOPjkZdFUqM = 1530642831; mybOPjkZdFUqM > 0; mybOPjkZdFUqM--) {
            JAUDFuN *= nqqKr;
            NbXvynFbbGGKfiHd = NbXvynFbbGGKfiHd;
            NbXvynFbbGGKfiHd = MMzLEgz;
            NbXvynFbbGGKfiHd += MMzLEgz;
            MMzLEgz += NbXvynFbbGGKfiHd;
        }
    }

    for (int tWsqvpaAuRjM = 1443228531; tWsqvpaAuRjM > 0; tWsqvpaAuRjM--) {
        vICfkFWLKHee = vICfkFWLKHee;
        PcSDeOAHGg = pMUqf;
        MMzLEgz += MMzLEgz;
        pMUqf = MMzLEgz;
    }

    if (MMzLEgz >= string("GsRPyjnjpunMz")) {
        for (int gwUnrliZ = 965398291; gwUnrliZ > 0; gwUnrliZ--) {
            uCitUqIxLEyIb += pMUqf;
            HZROepftrX -= nqqKr;
        }
    }

    return KREaTTcVgYfsYwX;
}

string FcdtTvcJ::vENEmXN(int JaaawZYkUiJe, double IIEHphnItDfBe)
{
    bool STIqOmDOrT = true;
    double ygxsnCGgu = -3509.54075564564;
    double sFWwrfGeLR = 201903.33053817973;
    double XxQmpW = 809942.9805474409;
    int geAMdlZp = 1580069755;

    for (int YoYhngJZURvV = 287964548; YoYhngJZURvV > 0; YoYhngJZURvV--) {
        continue;
    }

    for (int qoJVX = 63858850; qoJVX > 0; qoJVX--) {
        IIEHphnItDfBe *= ygxsnCGgu;
    }

    if (IIEHphnItDfBe > -39649.88069953919) {
        for (int AIGROyGJrvCfPUT = 1184533636; AIGROyGJrvCfPUT > 0; AIGROyGJrvCfPUT--) {
            sFWwrfGeLR /= IIEHphnItDfBe;
        }
    }

    return string("ANTKSACMcbMiEvCmZXchETpDWgzpBaeXIHkPdbiPzqingdPsJoKVyngMhnDHzcdUhOVnASuFdtvcBpZjyCLPkkXFUqwCOsnMsiiFanUIBwcgzjcBBvIsombTQuIme");
}

int FcdtTvcJ::gFdFIrPHq(double nLJsQVewjFJyLdV, double SFnCCnBKNBtTVk, double gwbMVhwoOq, int olOMpSwF)
{
    string ePacHSTdab = string("PYQcejziceIKhOerwFtpPzDNUXnoaSsffMNYPXDEssWHZHsPXJSjGXkjnUCsZrbbOCRkPnfomtsfCpUeRoCFopjGLCZVWrfbcWulRkwdjqnTjuPgMpiUiqtKmdpZeseyIlYKKEXLBzc");
    int PPdYcsBP = 1954268920;

    if (SFnCCnBKNBtTVk < 695408.4155480366) {
        for (int FkoyoSs = 87202501; FkoyoSs > 0; FkoyoSs--) {
            ePacHSTdab = ePacHSTdab;
        }
    }

    if (gwbMVhwoOq <= 695408.4155480366) {
        for (int YXoMggtSsJKHJuT = 1957951430; YXoMggtSsJKHJuT > 0; YXoMggtSsJKHJuT--) {
            gwbMVhwoOq -= gwbMVhwoOq;
            PPdYcsBP /= PPdYcsBP;
        }
    }

    return PPdYcsBP;
}

void FcdtTvcJ::zElOzsSBpILtQCAk()
{
    double kaQEoBnrNOmFlsU = 443191.03439214826;
    string VwOAJxYY = string("kSSpOVBXboNHrIORVNEzQJkunpEKETwvTXktkYcmUqauzNdSebdVggDTBYZxhlCxzhYZiVBaUAJoiZXhOFoMeuEzzQqaLaBLXIIfHHjsvauCTTmAU");
    string IpoPVYXhIjRKgE = string("CCpFGwbUPomqdFxnDzNgZpSyVqctUrrisAhikraZAihzMSwbHogZvFiYBgWjihKUZgovCAlAjopzpYxSYZloJNvqCpPZwAzVFCjrxBCieukrqpdUsIMBnazSzXFjoohTtVJ");
    bool SwIZGHBV = false;

    if (IpoPVYXhIjRKgE == string("CCpFGwbUPomqdFxnDzNgZpSyVqctUrrisAhikraZAihzMSwbHogZvFiYBgWjihKUZgovCAlAjopzpYxSYZloJNvqCpPZwAzVFCjrxBCieukrqpdUsIMBnazSzXFjoohTtVJ")) {
        for (int RUpsdfLb = 1365555806; RUpsdfLb > 0; RUpsdfLb--) {
            kaQEoBnrNOmFlsU -= kaQEoBnrNOmFlsU;
            IpoPVYXhIjRKgE = VwOAJxYY;
            VwOAJxYY = VwOAJxYY;
            kaQEoBnrNOmFlsU /= kaQEoBnrNOmFlsU;
            IpoPVYXhIjRKgE += VwOAJxYY;
        }
    }

    for (int tTrpju = 838292486; tTrpju > 0; tTrpju--) {
        SwIZGHBV = SwIZGHBV;
    }

    for (int VVXdGaFifX = 2067853390; VVXdGaFifX > 0; VVXdGaFifX--) {
        IpoPVYXhIjRKgE = IpoPVYXhIjRKgE;
    }

    if (SwIZGHBV != false) {
        for (int WcBRsCcJihvz = 1442554604; WcBRsCcJihvz > 0; WcBRsCcJihvz--) {
            IpoPVYXhIjRKgE += IpoPVYXhIjRKgE;
            VwOAJxYY += VwOAJxYY;
            IpoPVYXhIjRKgE += IpoPVYXhIjRKgE;
        }
    }

    for (int raSZZsjPoWWpoOmF = 386268949; raSZZsjPoWWpoOmF > 0; raSZZsjPoWWpoOmF--) {
        IpoPVYXhIjRKgE = VwOAJxYY;
        SwIZGHBV = SwIZGHBV;
    }

    if (VwOAJxYY > string("CCpFGwbUPomqdFxnDzNgZpSyVqctUrrisAhikraZAihzMSwbHogZvFiYBgWjihKUZgovCAlAjopzpYxSYZloJNvqCpPZwAzVFCjrxBCieukrqpdUsIMBnazSzXFjoohTtVJ")) {
        for (int XKKAeAHZjm = 399900592; XKKAeAHZjm > 0; XKKAeAHZjm--) {
            SwIZGHBV = ! SwIZGHBV;
        }
    }
}

bool FcdtTvcJ::ZmrndGpSvkaDan(double XuWcpgwNXjUxxjE)
{
    string fcLVQUyZCRGMLca = string("fQTPANcDkgkLmuvoOsMRbUQAxrbuioiXFqTZXXyaggjNrhVCDFgcAfBcSKIuzCdHztKJRHEpEbjFQrhabBPXojYltrabcZqHXFbzHVCmDsUpDSWXzfdTZdtjabOgELGJbIVOacklVraehYYZnopqWCVLKHBazJBLcDNTDgiYrRQvXIlYZllCvntJHsD");
    int zKCtumxL = 1772326477;
    bool vZlIFkIpJXEoIwyp = false;
    string FBwRQYLwNTtb = string("yKfScHmFLhkzAsZwsvJkoIPyLohyqehXClChIMIYyNeqnzvAvhksiXLfCncSzSJrSVjtOQxea");
    string YFRGUbBoyOxTcdZ = string("jPqaWvnEcykOyCgLLDbuTniyfFj");
    int xVNcdCDiVF = -1202521791;
    string oJdgyzQiNaE = string("DiBqmKoBvPNueyZpXkXhOlHbqzgdtIWEFltxqqicbONKxSgreHtyHSOSsVEhixnmeGnhboFoybkokhYGyVAqxwVBnsf");
    string GggXsHxxmzceLaU = string("mnZxrXNYMigickIjFsXgRusmfqBavQclrfNfxxAsfzNBkueYrHacoVOyuCIuJPwkmUrvyUZffiqjMcInCEbRYMLvSbmexUMuirgfVgmKxudtasnRRmmurhmAbdNIXWCMdkPhxuARXSsMGofUq");

    if (FBwRQYLwNTtb == string("DiBqmKoBvPNueyZpXkXhOlHbqzgdtIWEFltxqqicbONKxSgreHtyHSOSsVEhixnmeGnhboFoybkokhYGyVAqxwVBnsf")) {
        for (int fWaqtDgTEDQFpwM = 352583293; fWaqtDgTEDQFpwM > 0; fWaqtDgTEDQFpwM--) {
            fcLVQUyZCRGMLca += fcLVQUyZCRGMLca;
        }
    }

    for (int SyXIAdTjsJweC = 1522216655; SyXIAdTjsJweC > 0; SyXIAdTjsJweC--) {
        YFRGUbBoyOxTcdZ = GggXsHxxmzceLaU;
        YFRGUbBoyOxTcdZ = GggXsHxxmzceLaU;
    }

    for (int mkitZCBikEpoYwT = 1957655102; mkitZCBikEpoYwT > 0; mkitZCBikEpoYwT--) {
        fcLVQUyZCRGMLca = oJdgyzQiNaE;
        vZlIFkIpJXEoIwyp = ! vZlIFkIpJXEoIwyp;
    }

    for (int XQXLaYYlDKn = 586031036; XQXLaYYlDKn > 0; XQXLaYYlDKn--) {
        xVNcdCDiVF += xVNcdCDiVF;
        YFRGUbBoyOxTcdZ = fcLVQUyZCRGMLca;
        xVNcdCDiVF += xVNcdCDiVF;
        fcLVQUyZCRGMLca = GggXsHxxmzceLaU;
        vZlIFkIpJXEoIwyp = vZlIFkIpJXEoIwyp;
    }

    for (int PJzKZUgUGgitg = 630932967; PJzKZUgUGgitg > 0; PJzKZUgUGgitg--) {
        GggXsHxxmzceLaU = FBwRQYLwNTtb;
        xVNcdCDiVF /= xVNcdCDiVF;
        FBwRQYLwNTtb += FBwRQYLwNTtb;
        oJdgyzQiNaE = FBwRQYLwNTtb;
        FBwRQYLwNTtb = YFRGUbBoyOxTcdZ;
    }

    return vZlIFkIpJXEoIwyp;
}

int FcdtTvcJ::emaancB(string BmLxSRjDn, bool tjVwnunmpNrr)
{
    bool rcecaXCQs = false;
    string kEuVytAA = string("MaAAyfBijiVxgaZhXmgBXsmUnBfNDVDQgVKdRwmbtdqyaoEjJadoCrJT");
    bool XoENZdUx = false;
    int wOqoTDdngk = 1419617215;
    string wDexLARSCDX = string("AfVfUdaiFQdjnYyjnRueanrbwtkpoDgebBjZEhhUGJEFPGidHrhwoWBqEzjJWUeaYsfFg");
    bool gTAjvQRguldhXny = true;
    double IHEamM = -437653.24722057994;
    double nTjmuRN = -256514.67742536124;

    return wOqoTDdngk;
}

double FcdtTvcJ::PqHqB(double jmGTrHNqthKU, string BWPSzT, string zvxlnaRQxNcxd)
{
    int ubOiJd = -1876574876;
    string FBZQlRGGiNF = string("aozFWE");
    string wyqnyVCHDngojR = string("jsqigRtmdWKySRoZadDoiXFshataVsZasYTvHpBcioXybLkbVeVdMjyJCBeZECKOJNLCsoVzjuLVUGEoYrIsrKaSCbdCAURqULIJgIbTKoQmZPBzyidEsIiiEwkNISQRhUgaphZcljJKCicPdGEQJBZyHkQfWihrnlYrczuNgGAqK");

    for (int rNqEgdGSKC = 970359369; rNqEgdGSKC > 0; rNqEgdGSKC--) {
        BWPSzT += wyqnyVCHDngojR;
        ubOiJd -= ubOiJd;
        wyqnyVCHDngojR += zvxlnaRQxNcxd;
        zvxlnaRQxNcxd = wyqnyVCHDngojR;
    }

    return jmGTrHNqthKU;
}

string FcdtTvcJ::bRltkPJjihbVBb(string OzebPQQvi, bool dMjtVbFqSecFsgV)
{
    int DyVXjTiSiqJitwd = -770032089;
    bool nCbda = true;
    bool smxmY = false;
    string jZuVn = string("lHaGbcER");
    string GPKjSXDfMngWK = string("ltSmYxSaXMPFMiLFvTRvQUdKggRdZluVBVipCPzdwVNVQtHopvoMovahGXvtMtSMxfHyeVHlALBcXsSwoipWeuyqpXOnKfQILOZHYnmGUKZr");
    int ChuGYoCFDgVMbL = -1109479713;
    int PYmfSuS = 301348198;

    for (int DdvZXBJrGHSS = 2142249799; DdvZXBJrGHSS > 0; DdvZXBJrGHSS--) {
        OzebPQQvi += jZuVn;
    }

    for (int JPatD = 239409835; JPatD > 0; JPatD--) {
        dMjtVbFqSecFsgV = nCbda;
    }

    if (dMjtVbFqSecFsgV == false) {
        for (int aOsitjJtbarNuGK = 58123989; aOsitjJtbarNuGK > 0; aOsitjJtbarNuGK--) {
            dMjtVbFqSecFsgV = ! dMjtVbFqSecFsgV;
            OzebPQQvi += jZuVn;
            dMjtVbFqSecFsgV = ! nCbda;
            nCbda = nCbda;
            nCbda = nCbda;
        }
    }

    for (int TjtwhyE = 59636859; TjtwhyE > 0; TjtwhyE--) {
        GPKjSXDfMngWK = jZuVn;
    }

    if (nCbda != true) {
        for (int ZxWTAvOurgW = 841940620; ZxWTAvOurgW > 0; ZxWTAvOurgW--) {
            continue;
        }
    }

    return GPKjSXDfMngWK;
}

double FcdtTvcJ::sZFeihP(string LHvUjOMmwfQSj, bool rvAnpu, bool erbqf, bool ccEonnUntGwEKlm)
{
    double TsdWA = -413246.99221922056;
    bool matWheuwfmYEz = false;
    int oxlUK = -474069885;

    for (int GJdeBz = 1543099032; GJdeBz > 0; GJdeBz--) {
        ccEonnUntGwEKlm = matWheuwfmYEz;
        rvAnpu = ! matWheuwfmYEz;
        ccEonnUntGwEKlm = erbqf;
    }

    for (int OFKBE = 1525362834; OFKBE > 0; OFKBE--) {
        matWheuwfmYEz = matWheuwfmYEz;
        rvAnpu = erbqf;
        ccEonnUntGwEKlm = ccEonnUntGwEKlm;
        erbqf = ! erbqf;
        erbqf = ! erbqf;
        matWheuwfmYEz = ! erbqf;
    }

    return TsdWA;
}

int FcdtTvcJ::rCiclBg(string xWCBVnrxwbqYlVVO, double aLYFtjYUOXyVq, bool GKuiCGNkGfGLJH, int tRjIOzhNQlgj)
{
    bool FjKDH = true;
    double VjSNligkqLXSqY = 1045316.515903672;
    double VhYCtr = 611076.9351652922;

    for (int snbUKIAXxMmEQUU = 1367473681; snbUKIAXxMmEQUU > 0; snbUKIAXxMmEQUU--) {
        VjSNligkqLXSqY += VhYCtr;
    }

    return tRjIOzhNQlgj;
}

string FcdtTvcJ::wFqTandBCTnnDIdP()
{
    double DPMzeCoDC = -430778.33755121473;
    string TjPKTYPtMLoFt = string("acvFvnOIcUOdgH");
    string qSIZcEPNyuXyq = string("vSrvEWYnsCJqGYecdYqAZQRWVymQmpqYfCrhKyuwnBIOjvmhYpEzTOMYIUZVkvbKVZaRdlySrooAtyiKKJPubWygUsMboHaiOyctGHvKmEQvSOJRszsEifJGQHaLjDguwwzklTuXrnenqkcdNYVkxqbCVVtgBmMDlvDIBkgBFmqgfGXhgoYJuTpaGKfQKQWvSuGAyjOJjEzdwPtTawgcmjDcjOgYflytciIOebBHEPl");
    string xPXbJzbuKnEVYVh = string("kiAtXGkMaiZgZVfyotSMHSgZgmWFYmkoBFNSzTBdunBHYGIVEaQuTZLttemwbEbeTzuCmsWfZHNXVYDMKWjpGXzspaBxrOWOzyKeOLviBkxJhMRkyPSmuhYysdyVPwcOHyUXvINRXzeoxdVaMKSNQxcuYFQbpGoFOdYayFBwpkNLvrMRCqxjotcXKp");
    string uPDFzVumjStfMQI = string("MIATZKYbYMhTqXPiITwuepsxRfBsRZxMNPAslfkgLqeeAeUMcAbMuOGOLeofDXDnLMWledmDyYxdEGbeMiEQDjEBgspTmuUeulKACBNYDbJViGWiuJVltwIUBlAAIKgXWWXnAaQKxZEmCO");

    for (int cbXqqenzYYF = 1762328901; cbXqqenzYYF > 0; cbXqqenzYYF--) {
        uPDFzVumjStfMQI += qSIZcEPNyuXyq;
        xPXbJzbuKnEVYVh = qSIZcEPNyuXyq;
    }

    if (TjPKTYPtMLoFt < string("MIATZKYbYMhTqXPiITwuepsxRfBsRZxMNPAslfkgLqeeAeUMcAbMuOGOLeofDXDnLMWledmDyYxdEGbeMiEQDjEBgspTmuUeulKACBNYDbJViGWiuJVltwIUBlAAIKgXWWXnAaQKxZEmCO")) {
        for (int LaRTwalXCvI = 1988266939; LaRTwalXCvI > 0; LaRTwalXCvI--) {
            TjPKTYPtMLoFt += uPDFzVumjStfMQI;
            qSIZcEPNyuXyq = uPDFzVumjStfMQI;
            uPDFzVumjStfMQI = qSIZcEPNyuXyq;
        }
    }

    return uPDFzVumjStfMQI;
}

string FcdtTvcJ::YaLUP(double iWMnoPeS, double WiOBlloCPsvsu, double IvpOzdJq, double qFmloKsx, bool yAnqnmp)
{
    int ohvPCJYFQcUIqYE = 1392434531;

    if (WiOBlloCPsvsu > -561656.6904584924) {
        for (int GoFuUO = 1838835749; GoFuUO > 0; GoFuUO--) {
            qFmloKsx -= IvpOzdJq;
            qFmloKsx -= qFmloKsx;
            iWMnoPeS += WiOBlloCPsvsu;
        }
    }

    for (int QtuZqzEtN = 676875029; QtuZqzEtN > 0; QtuZqzEtN--) {
        IvpOzdJq /= iWMnoPeS;
        IvpOzdJq += IvpOzdJq;
        WiOBlloCPsvsu = IvpOzdJq;
        WiOBlloCPsvsu /= qFmloKsx;
    }

    return string("DTIESHGvpbXgkXyMzuBpvQqQVOhRApLCItzGvrDeTZuZzGyVHOEJVmdpYldoRxvtLjDqiGBVPNCzteApKEUdxhvalAeeNhjniOHMOWOYeFigDSyavNZqVopNfUslJRSjeeLSBhyImbHjxaxqRGYesRplsVGLuWOoYvRRPvFwelQSXaGnNzSpneFFElnCstTjyHbJVYvKzXRdoMjUE");
}

bool FcdtTvcJ::tfoGakUVMwf()
{
    string rrMDfFFVyBfttkd = string("MscOfyhrONzMORMsDRJvSqhesDdBSvhVKLGmNEenHZWSQrfQTMNbYlVFmHQTSVenHRsNbfBTFwtgABmkieHxrTMqPNRPAJTQKwUoYQkdvFhkBMnXZAjAQkOdILoNmqNIUzKWBdBeAWIaIBOtDrJJDdicYDXUmnxQEJWlkFKtXp");
    string vxTkeoKju = string("mJkTSJsrOBkWTDlGUOnavGvlByynpioceqaqAgajHyJocOITKoQsPwbXPJmDEDYyHzsIzGjyyPdqbqVRprNTuvikwqipJYdEyKGZZQuWwqcmAVysCVuaEyeJWxsaCUfrgEziHMvxjcoiiigCjbLGFBdojoWnQLndaKIAjY");
    bool XaBDkQNNDwzR = false;
    int vgoKuGQXvyDwFcj = -1552796791;

    for (int tyETKxGgLnjc = 357214333; tyETKxGgLnjc > 0; tyETKxGgLnjc--) {
        vxTkeoKju += vxTkeoKju;
        vxTkeoKju += vxTkeoKju;
        rrMDfFFVyBfttkd = vxTkeoKju;
    }

    return XaBDkQNNDwzR;
}

int FcdtTvcJ::qdbDPaYVaXwU(double oZYHs, double NDxyCrphUI)
{
    int adEDfGpeiZbjIJTW = -1464832976;
    double lxqIeTFrhHlScYm = -765079.1267783758;
    bool EQsYxUMMpPrIsEdl = false;

    for (int mlpCEIdlAO = 1650239708; mlpCEIdlAO > 0; mlpCEIdlAO--) {
        lxqIeTFrhHlScYm = oZYHs;
        EQsYxUMMpPrIsEdl = ! EQsYxUMMpPrIsEdl;
    }

    for (int VpMMWobxenfwlp = 1367666299; VpMMWobxenfwlp > 0; VpMMWobxenfwlp--) {
        lxqIeTFrhHlScYm *= NDxyCrphUI;
        NDxyCrphUI -= oZYHs;
        oZYHs *= lxqIeTFrhHlScYm;
        lxqIeTFrhHlScYm /= oZYHs;
    }

    if (NDxyCrphUI > -988239.3832841534) {
        for (int RBOhLeRAD = 653366522; RBOhLeRAD > 0; RBOhLeRAD--) {
            oZYHs = NDxyCrphUI;
            lxqIeTFrhHlScYm = lxqIeTFrhHlScYm;
            adEDfGpeiZbjIJTW = adEDfGpeiZbjIJTW;
        }
    }

    if (adEDfGpeiZbjIJTW != -1464832976) {
        for (int jLrWg = 920747787; jLrWg > 0; jLrWg--) {
            NDxyCrphUI = NDxyCrphUI;
            oZYHs -= oZYHs;
            adEDfGpeiZbjIJTW -= adEDfGpeiZbjIJTW;
            NDxyCrphUI += NDxyCrphUI;
            NDxyCrphUI = NDxyCrphUI;
        }
    }

    return adEDfGpeiZbjIJTW;
}

FcdtTvcJ::FcdtTvcJ()
{
    this->esYnkFwBiXG(true, 392422.19482861145, 1043526570, -550855792, true);
    this->bfczzAAaOpL(string("qpfPAkvqjtUYOiPhHeasppkZckHYXJSBQGriCDiSudLhKKfXnSrHTdJzuOuAyNQIIXviH"), string("CRtQuwnpIYVMPwEuhYYUhLQkRhlSrDsfENtikPbQIzDiNBkciMYwDHlubbbKCYXYQOawwdSaazhKjUgpnQyRghkIujCvhJKxdHVLQGMgsOPSdK"));
    this->DCFWFOiVHoigX(1092068799, -1417524888, 385940.5709452893, string("GsRPyjnjpunMz"), string("tazknZRfNAvjWaYjCBHDJSaQsuKgUTNgDUYLAsDSYhqMenPKKkAniXkqXgVGuBAnXuXhOnwfFvrJPdmGrpeVDuDxdzPcaBNlbpSIgfowRaJxIdRjlInWhlRYDnyNrjxNGKGaAWScPIFUSQMnzabGzgNHBZnOqUNITWtukIlMHBIsfJleJfYGkOMSXFNXghswtAohxwPaESdGusKGzLYCjzWbvRglItOetdNQahFaSffbmqRHoeVhnISWMbBy"));
    this->vENEmXN(-1568985969, -39649.88069953919);
    this->gFdFIrPHq(-155413.90649503501, -917423.6161314881, 695408.4155480366, -1639991406);
    this->zElOzsSBpILtQCAk();
    this->ZmrndGpSvkaDan(-584066.635115112);
    this->emaancB(string("Xf"), false);
    this->PqHqB(-947717.0127791099, string("tOhDn"), string("rofbVQWxdrtnMh"));
    this->bRltkPJjihbVBb(string("nrEpketmHxW"), true);
    this->sZFeihP(string("WtNWxRvmgCaEjrRIbWmIHCqkXoYmzRPakKcMvsCDyGnGfarPAxkrVwBC"), false, true, false);
    this->rCiclBg(string("MvrdYTLOFyuNCjfBdYnKAffGlVbfalxNtISeGtFsDWkWGBtnKycPHyIRouGZorGPsqEgmuwseEsqTIQWKvEXIztVJhrwhdXQYyTNvAMvvDNJLkOGaPdVyZuZTCnxVLuAKopVObSCSIQLOaDn"), -107854.95787832055, true, 1851155107);
    this->wFqTandBCTnnDIdP();
    this->YaLUP(-313481.0617732725, -561656.6904584924, -618629.790186243, 171823.78414918875, false);
    this->tfoGakUVMwf();
    this->qdbDPaYVaXwU(-413710.0292382217, -988239.3832841534);
}
