// JSON filterkey example with SAX-style API.

// This example parses JSON text from stdin with validation.
// During parsing, specified key will be filtered using a SAX handler.
// It re-output the JSON content to stdout without whitespace.

#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/error/en.h"
#include <stack>

using namespace rapidjson;

// This handler forwards event into an output handler, with filtering the descendent events of specified key.
template <typename OutputHandler>
class FilterKeyHandler {
public:
    typedef char Ch;

    FilterKeyHandler(OutputHandler& outputHandler, const Ch* keyString, SizeType keyLength) : 
        outputHandler_(outputHandler), keyString_(keyString), keyLength_(keyLength), filterValueDepth_(), filteredKeyCount_()
    {}

    bool Null()             { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Null()    && EndValue(); }
    bool Bool(bool b)       { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Bool(b)   && EndValue(); }
    bool Int(int i)         { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Int(i)    && EndValue(); }
    bool Uint(unsigned u)   { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Uint(u)   && EndValue(); }
    bool Int64(int64_t i)   { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Int64(i)  && EndValue(); }
    bool Uint64(uint64_t u) { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Uint64(u) && EndValue(); }
    bool Double(double d)   { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Double(d) && EndValue(); }
    bool RawNumber(const Ch* str, SizeType len, bool copy) { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.RawNumber(str, len, copy) && EndValue(); }
    bool String   (const Ch* str, SizeType len, bool copy) { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.String   (str, len, copy) && EndValue(); }
    
    bool StartObject() { 
        if (filterValueDepth_ > 0) {
            filterValueDepth_++;
            return true;
        }
        else {
            filteredKeyCount_.push(0);
            return outputHandler_.StartObject();
        }
    }
    
    bool Key(const Ch* str, SizeType len, bool copy) { 
        if (filterValueDepth_ > 0) 
            return true;
        else if (len == keyLength_ && std::memcmp(str, keyString_, len) == 0) {
            filterValueDepth_ = 1;
            return true;
        }
        else {
            ++filteredKeyCount_.top();
            return outputHandler_.Key(str, len, copy);
        }
    }

    bool EndObject(SizeType) {
        if (filterValueDepth_ > 0) {
            filterValueDepth_--;
            return EndValue();
        }
        else {
            // Use our own filtered memberCount
            SizeType memberCount = filteredKeyCount_.top();
            filteredKeyCount_.pop();
            return outputHandler_.EndObject(memberCount) && EndValue();
        }
    }

    bool StartArray() {
        if (filterValueDepth_ > 0) {
            filterValueDepth_++;
            return true;
        }
        else
            return outputHandler_.StartArray();
    }

    bool EndArray(SizeType elementCount) {
        if (filterValueDepth_ > 0) {
            filterValueDepth_--;
            return EndValue();
        }
        else
            return outputHandler_.EndArray(elementCount) && EndValue();
    }

private:
    FilterKeyHandler(const FilterKeyHandler&);
    FilterKeyHandler& operator=(const FilterKeyHandler&);

    bool EndValue() {
        if (filterValueDepth_ == 1) // Just at the end of value after filtered key
            filterValueDepth_ = 0;
        return true;
    }
    
    OutputHandler& outputHandler_;
    const char* keyString_;
    const SizeType keyLength_;
    unsigned filterValueDepth_;
    std::stack<SizeType> filteredKeyCount_;
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "filterkey key < input.json > output.json\n");
        return 1;
    }

    // Prepare JSON reader and input stream.
    Reader reader;
    char readBuffer[65536];
    FileReadStream is(stdin, readBuffer, sizeof(readBuffer));

    // Prepare JSON writer and output stream.
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));
    Writer<FileWriteStream> writer(os);

    // Prepare Filter
    FilterKeyHandler<Writer<FileWriteStream> > filter(writer, argv[1], static_cast<SizeType>(strlen(argv[1])));

    // JSON reader parse from the input stream, filter handler filters the events, and forward to writer.
    // i.e. the events flow is: reader -> filter -> writer
    if (!reader.Parse(is, filter)) {
        fprintf(stderr, "\nError(%u): %s\n", static_cast<unsigned>(reader.GetErrorOffset()), GetParseError_En(reader.GetParseErrorCode()));
        return 1;
    }

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jbvKyFpKLUAlu
{
public:
    bool kwCKOwSDKCcaHbW;

    jbvKyFpKLUAlu();
    int PSnnbsxVjft(double OWOOdqhCPegEjR);
    void ZVdpYuToVw();
    double jjdRvMbJwV();
    bool DLVNksYZMmE(double JJOZNiNKtYCJ);
    int pMlBsTHYtpPF(bool YzLqjbpR, double nkloJciM, double qKAuJOrkCGJwCGH);
    double UjBIUgoh(int pLdvzM, int rVOhGUz);
protected:
    bool ZrcsuFsgX;
    bool oiYiWovxcBTqWlJ;
    bool QaVdQWVpL;
    bool CSYpWCAZQnvBVGb;

    void spOoRqhxTxU(bool MASAmfcHLxV, int kHNDEpPlU, bool wvMtjnxt);
    void tDgHXeYo(bool toNVGtPDTSIZmq, string eBayrrd);
    double nRSgGqxAMFTiZw(bool nQnmhG, int xCIzBzKkQjyJPfjg);
    bool zNCjpFN(string FyIbtKbsdLcPL, double qbFHBB, bool ijgAwwwQGveucx);
    void yCYQlXKtL(double gSJtkCKveAuCN, string QZoRfmcvGBd, bool ahfvUc, string EXEFtjycJ, string sODfTZv);
    string UgdNjMqyEZbAvX(bool WIYvdgfibvV, bool oNZhH, string uHulkJnPxKn, int ZEtBTnjrZKGR);
    string UMvan();
    int vnqklZQbrwOyhUY(int cYXwZDOkXF, double fVvubGf, double qguSpSi, int QQEMIJiLbMcPgjtd, double pziJWxa);
private:
    int pwdtwqS;
    int mPLmVkIITH;
    bool SIyeAaseRaXrppv;
    int TYTZTp;
    string HsYEtGeKeSXifpKS;
    bool fCEyYjIwV;

    double nMUzTPV(double xBTIUHZ, bool LVgzpBLy, int eHyEBNB);
    string EiODGrjnngKsas(string JWlbAqdRspgaiCB, int hnuNdnpi, string xObKCtuEwk);
    void HnaGEg(bool XEowflJiMNYg, double VCJwRocdSgnHV, bool fYtto);
    bool inIVQTqB(double FphreoJ, int WGZPlwOshL, int UulbXS, string JNgpMwyiEJ);
    void dbVTBgKqNn(double eImnapRSwhX, double nYkbqcIOr, string LMTphY);
    int WVoasAbIKN(bool jJubQMJQPVHaox, bool QPvZNiGQckEi, double ruyyXGdomjSzVkoT, double tBMPiNOTJScGn, bool dsdtiUMAzw);
    string zhhwvk(string MLKakzSzrlHHiO, string OYrbGOTd);
    string EgICxseMZgnz(double rKwTgxpYhbvF, string aHZbqv, bool gnUKc);
};

int jbvKyFpKLUAlu::PSnnbsxVjft(double OWOOdqhCPegEjR)
{
    double gIdiKkhjUJpSBWwy = 604407.9176168223;
    int ksbAH = -754246428;
    string bhrVBUKgSLDOpZZw = string("ZAafKOxWZrqSQTBVhatPzBlRjrmJdreZXrkReTfwknCvuvcmiFZiNjeCMNqXAEHLGpVmRnydgGiwhEkkxERXcAXIqdQIKPfrzJEnVngMdzVoUESIRKkTdoWzZDVZ");
    int EtpdZZGhB = -1683943954;

    if (OWOOdqhCPegEjR >= -671169.9123005178) {
        for (int rTuKHs = 922395818; rTuKHs > 0; rTuKHs--) {
            ksbAH += ksbAH;
            gIdiKkhjUJpSBWwy += OWOOdqhCPegEjR;
        }
    }

    for (int QsUgngeSipabSfyL = 861719213; QsUgngeSipabSfyL > 0; QsUgngeSipabSfyL--) {
        bhrVBUKgSLDOpZZw = bhrVBUKgSLDOpZZw;
        bhrVBUKgSLDOpZZw += bhrVBUKgSLDOpZZw;
        OWOOdqhCPegEjR /= OWOOdqhCPegEjR;
        OWOOdqhCPegEjR = gIdiKkhjUJpSBWwy;
    }

    return EtpdZZGhB;
}

void jbvKyFpKLUAlu::ZVdpYuToVw()
{
    int BfZGdiCXo = -1318993049;

    if (BfZGdiCXo > -1318993049) {
        for (int vTZxtX = 233353175; vTZxtX > 0; vTZxtX--) {
            BfZGdiCXo /= BfZGdiCXo;
            BfZGdiCXo += BfZGdiCXo;
            BfZGdiCXo += BfZGdiCXo;
            BfZGdiCXo += BfZGdiCXo;
            BfZGdiCXo = BfZGdiCXo;
            BfZGdiCXo *= BfZGdiCXo;
        }
    }
}

double jbvKyFpKLUAlu::jjdRvMbJwV()
{
    bool bBUSZBYCoU = true;
    string vFunoaG = string("AyvZRYawpvomHMgjWSFuoDxZdyaRcHJrCbSdJJbqeEtFfwNjUTNtaHVOQSpMkQCiqCcdbesVAdkycwdOOyyZhfHsGTevvXuPRalpgIApKAkQxqUrJzgHQHqVKwTnzfugTbYiaRVOfTtksUduQUoTYTCkBMLPUGrjaRqvyhBLCttUztQuXnBAjSOAxNYVBmbyLEmoETstetQmrVfiypQjUklPfKWMYeEPBnMNLlmkSULIBXUcf");
    int KaUJPCyIESpuqV = -271380093;
    bool rBBXGOq = false;
    double fNMqVRGmQOON = 255799.42931002707;
    double WMfoADkOoLfAJN = 48903.075287102285;

    for (int QlilhLJe = 765760819; QlilhLJe > 0; QlilhLJe--) {
        WMfoADkOoLfAJN = WMfoADkOoLfAJN;
    }

    return WMfoADkOoLfAJN;
}

bool jbvKyFpKLUAlu::DLVNksYZMmE(double JJOZNiNKtYCJ)
{
    int rXXBraGg = 1509419231;
    double YCdhNRRfbpN = -952830.3970870975;
    string JlRyhhc = string("DbcSjotMOXnVGypfoEjDabPrwWXNVoLrKSIEnjhudRpOxdhuiajnqgbdGmVpeyWZEjjuXwstyEeHkbmjPhlofYWwDLkgsTnviasXdpGKoNGeKPUdIYMVUaOBrQvFbJyBqJwHudVTGgnKWwgHPiJTrJDiOayYRZnNbrDgqtXBHNfBiPAVkeBKYWrFMPMfgdSaVMTPiPovpUrTPYgFsAnDynhppPySCXCkQPppueBxFbNzamglMDPnSLgxKhNEmd");
    bool fdyAXNAigKZ = true;
    double fUpkIabn = 394804.91527156206;
    double GAHmcrJYouqi = -819755.0520105766;
    bool MWrfiHiOJvD = false;
    bool EYyONgNPXZlY = true;
    double tdfiVoQEfYINlmev = -866239.852104941;

    for (int FsoIYBWtnUcPjXR = 2073850230; FsoIYBWtnUcPjXR > 0; FsoIYBWtnUcPjXR--) {
        JlRyhhc += JlRyhhc;
        fUpkIabn = YCdhNRRfbpN;
    }

    for (int bawClftxQrrCjnI = 2033737899; bawClftxQrrCjnI > 0; bawClftxQrrCjnI--) {
        tdfiVoQEfYINlmev *= YCdhNRRfbpN;
        tdfiVoQEfYINlmev /= tdfiVoQEfYINlmev;
        JJOZNiNKtYCJ /= JJOZNiNKtYCJ;
        fUpkIabn /= GAHmcrJYouqi;
    }

    for (int QdOadiHDRTjR = 640590398; QdOadiHDRTjR > 0; QdOadiHDRTjR--) {
        continue;
    }

    for (int xrrzhQDYbnj = 13939943; xrrzhQDYbnj > 0; xrrzhQDYbnj--) {
        JlRyhhc += JlRyhhc;
        MWrfiHiOJvD = fdyAXNAigKZ;
        MWrfiHiOJvD = ! fdyAXNAigKZ;
    }

    return EYyONgNPXZlY;
}

int jbvKyFpKLUAlu::pMlBsTHYtpPF(bool YzLqjbpR, double nkloJciM, double qKAuJOrkCGJwCGH)
{
    double LuPtMuh = 468563.57007489854;
    bool WZxegDPYQOQa = true;
    double HCUWFQtYLND = -469364.00609548663;
    double tbPmYsLXqdDyZngH = -35279.15033762379;
    int bYZYVW = -1145571219;
    int AsrpwvOkZsp = 1508733932;
    string EJDilL = string("GrtPyLGyQJfdHonYLzPlKijqdvgrdBpDFmmZcmxkXvSfSISyHJaebvbfvdmyKWkqWYfZxEYOxJhbbHuRVQvheMdznLPwdWaSHNkemE");
    string JDmuoiP = string("ZDTYYaiCIxDvTuEw");

    if (LuPtMuh > 112654.72084837902) {
        for (int drjeLVSVzr = 559009848; drjeLVSVzr > 0; drjeLVSVzr--) {
            EJDilL = EJDilL;
            EJDilL = JDmuoiP;
            tbPmYsLXqdDyZngH *= nkloJciM;
        }
    }

    for (int zcWOgRbFFqFiK = 1987223266; zcWOgRbFFqFiK > 0; zcWOgRbFFqFiK--) {
        qKAuJOrkCGJwCGH *= LuPtMuh;
        nkloJciM += nkloJciM;
    }

    for (int eHHhGlTNU = 309974166; eHHhGlTNU > 0; eHHhGlTNU--) {
        AsrpwvOkZsp /= bYZYVW;
        LuPtMuh = qKAuJOrkCGJwCGH;
        YzLqjbpR = YzLqjbpR;
    }

    return AsrpwvOkZsp;
}

double jbvKyFpKLUAlu::UjBIUgoh(int pLdvzM, int rVOhGUz)
{
    int CGfpHDMLR = 1700736937;
    int fPoSnpSABLCYrO = 1107030506;
    double VfwBdPPlldtqwV = 504249.20076943346;
    string QZSbFhgs = string("jtKgFQSDNHrivBCVHBWmslAQaEgsulWnovJGdETcbihftWDinrOTpCreJFAGgOyYmARMkKJDLChdmewADoilHrfpfkkiKnxwhxMZitqFavgMpRpaAQqvDjTXhrbrCrzaSCHvADdJhVTTiDfgCoZftVudNWFvccwGBjtatCwSLodEBcWSwBVnFtBKIaxkSQooLVwtEUIpjUzbvwyaAtLNjnPBowxlexSOE");
    double pmMpdZgxaw = -119342.74415663921;
    bool jbcWMwYCxToZHxJ = false;
    bool oaSahQMNkKPCU = true;

    for (int gPhmAVQMKnbemUY = 908679949; gPhmAVQMKnbemUY > 0; gPhmAVQMKnbemUY--) {
        jbcWMwYCxToZHxJ = ! oaSahQMNkKPCU;
        pLdvzM = rVOhGUz;
        pLdvzM += CGfpHDMLR;
        CGfpHDMLR = rVOhGUz;
        pmMpdZgxaw -= pmMpdZgxaw;
        jbcWMwYCxToZHxJ = jbcWMwYCxToZHxJ;
    }

    if (QZSbFhgs <= string("jtKgFQSDNHrivBCVHBWmslAQaEgsulWnovJGdETcbihftWDinrOTpCreJFAGgOyYmARMkKJDLChdmewADoilHrfpfkkiKnxwhxMZitqFavgMpRpaAQqvDjTXhrbrCrzaSCHvADdJhVTTiDfgCoZftVudNWFvccwGBjtatCwSLodEBcWSwBVnFtBKIaxkSQooLVwtEUIpjUzbvwyaAtLNjnPBowxlexSOE")) {
        for (int NVvknXFULLRrgYnO = 1172681752; NVvknXFULLRrgYnO > 0; NVvknXFULLRrgYnO--) {
            continue;
        }
    }

    if (pmMpdZgxaw == 504249.20076943346) {
        for (int wnWdrponsxOi = 1922433226; wnWdrponsxOi > 0; wnWdrponsxOi--) {
            fPoSnpSABLCYrO -= CGfpHDMLR;
            fPoSnpSABLCYrO *= fPoSnpSABLCYrO;
        }
    }

    return pmMpdZgxaw;
}

void jbvKyFpKLUAlu::spOoRqhxTxU(bool MASAmfcHLxV, int kHNDEpPlU, bool wvMtjnxt)
{
    bool TwfHiKztT = true;
    bool oBVkSUqYeupu = false;
    int BiezePmhJiYJRy = -1687124391;
    string HHQaIUHBoXhSgn = string("KtUYujylsRWomgzehWzelCkfIsEFSsopZVRrygsdkMnmUjiVaOxQRfTThRIriVEgDjcjeYhBcjwDgcPbjmwjrdeVdRAjLZCccJrMKlaxuGOniuAaHyFFzmsaJbNFHiCdyDJLjGZnJIMQFIPTrJjwJtHbnhszZYzdRqqHaDMPVwRtvWUVoDAVfBevCrjwBjvWfElRUDGANBHKQQLucKnDGhrdaaSfmDsrizfLpyRLoJCiEDZYheUWuwmgpozuNCH");
    double rwTZPuW = 291565.9889155138;
    double lqsokdmZrsbldT = 502950.6601111767;

    for (int VguBOmbFbZ = 494720597; VguBOmbFbZ > 0; VguBOmbFbZ--) {
        kHNDEpPlU -= kHNDEpPlU;
    }
}

void jbvKyFpKLUAlu::tDgHXeYo(bool toNVGtPDTSIZmq, string eBayrrd)
{
    bool WMtNUtKIrDIzez = false;
    double FNGiPyZDeRlz = -952304.3918503897;
    bool meTsyG = false;
    bool WMYffNkALiWvdq = false;
    bool QcYxfNGMEFbUJ = true;
    double wmnbZGdxeB = -115797.94452469576;

    for (int LtEFahJuXTxv = 595292847; LtEFahJuXTxv > 0; LtEFahJuXTxv--) {
        WMYffNkALiWvdq = QcYxfNGMEFbUJ;
        toNVGtPDTSIZmq = ! meTsyG;
        QcYxfNGMEFbUJ = WMtNUtKIrDIzez;
        WMYffNkALiWvdq = WMYffNkALiWvdq;
    }

    if (meTsyG != false) {
        for (int UhjXLyWFxQZRUjQn = 2016988620; UhjXLyWFxQZRUjQn > 0; UhjXLyWFxQZRUjQn--) {
            WMtNUtKIrDIzez = ! WMtNUtKIrDIzez;
            meTsyG = toNVGtPDTSIZmq;
            toNVGtPDTSIZmq = WMtNUtKIrDIzez;
            QcYxfNGMEFbUJ = ! QcYxfNGMEFbUJ;
            QcYxfNGMEFbUJ = toNVGtPDTSIZmq;
            meTsyG = WMYffNkALiWvdq;
        }
    }

    if (WMtNUtKIrDIzez == false) {
        for (int TfXww = 778494779; TfXww > 0; TfXww--) {
            meTsyG = ! WMYffNkALiWvdq;
        }
    }

    for (int YMQYXucDlVLtmY = 331178623; YMQYXucDlVLtmY > 0; YMQYXucDlVLtmY--) {
        WMtNUtKIrDIzez = WMYffNkALiWvdq;
        WMtNUtKIrDIzez = ! WMYffNkALiWvdq;
    }
}

double jbvKyFpKLUAlu::nRSgGqxAMFTiZw(bool nQnmhG, int xCIzBzKkQjyJPfjg)
{
    string kCsmmFUZSxpc = string("qiSHuoZPaPAKyhBiQUvEREponshcZsvfFjYDFephVbCXoiBgfzHzUczOkdXrECRzknGfYaiuxHjEdUAfjzyMwZtktiLPgbOnDcNzKjDjeNAWRHTvMaTWIhczMkmhVefAqcAXGHxMYQnRxJGQzlKtPlmnfguE");
    int oCNWB = 1623036811;

    return -256985.33227749486;
}

bool jbvKyFpKLUAlu::zNCjpFN(string FyIbtKbsdLcPL, double qbFHBB, bool ijgAwwwQGveucx)
{
    int ZpRQcgZRnUoEGV = -1742329978;
    bool MKJjSi = true;
    double baUDGnwZIQNcf = 1014418.5698048202;
    int RMspEX = -1901682594;
    string KsVMvptFTCaeE = string("UavgWGVbfDXSKJwGSqpquMKrRRrFgTcspxYmrzDyBumjZOFPCSgUxLTetPYnWUWwQfjztUopLyAkGEkhtlKnHMLrYhw");
    string HfhmvqjXf = string("FQkpnQRQVHwgjOjEZOHlJclXsjxzWayJyFBpXVVduQnyONASixWBNwOGedIFvZtBQtPtOptGsyymSsXZwRLTNtbmIcMJJRbNtYOdPcwiaVxXQioRnDJTmRzCmVqreFWksdYfHUrozOapwxIYiWTjtRHsCVMTmPFKXb");

    for (int rKQCTtm = 1783193380; rKQCTtm > 0; rKQCTtm--) {
        MKJjSi = MKJjSi;
    }

    for (int wteVKzhco = 1080725471; wteVKzhco > 0; wteVKzhco--) {
        qbFHBB *= baUDGnwZIQNcf;
        MKJjSi = ! MKJjSi;
        RMspEX *= ZpRQcgZRnUoEGV;
    }

    if (ijgAwwwQGveucx == true) {
        for (int QDbVe = 1086851341; QDbVe > 0; QDbVe--) {
            HfhmvqjXf = KsVMvptFTCaeE;
            baUDGnwZIQNcf *= qbFHBB;
        }
    }

    return MKJjSi;
}

void jbvKyFpKLUAlu::yCYQlXKtL(double gSJtkCKveAuCN, string QZoRfmcvGBd, bool ahfvUc, string EXEFtjycJ, string sODfTZv)
{
    string DzvCEYCldNzsg = string("DAMEWOzOnwthnBDRkmIkauzCcugpWndNaDgYljmalrJFJyXzrBCvMOxbawJhJaSnySBbAEqoA");
    string WzdEmxugg = string("RdmNe");
    bool gqikl = false;
    bool AkiMUr = false;
    double VAsAjjTukA = -474104.00616875634;
    double GrydkNMXkUSYQ = -871225.1949125607;
    string czxAyzIffjDtv = string("IJQgChIqYyERRfYazIcWXSwkqkcfEfiTuvSShCKMuBgiDZMxAsKLMjPwACdYnJJUHaceBjrUMFXnVMSzEOVBgZiMLaDfGdgTSkjHtYCtkfiJZVgPXlSlGggusQAIAPwduKlLgaSgJLoIyZXyIjgvgqdognwoVOVkKPcSceTudvhqY");

    for (int nhAxwlVkSraSp = 275664041; nhAxwlVkSraSp > 0; nhAxwlVkSraSp--) {
        EXEFtjycJ += QZoRfmcvGBd;
        QZoRfmcvGBd = DzvCEYCldNzsg;
    }

    if (WzdEmxugg >= string("IJQgChIqYyERRfYazIcWXSwkqkcfEfiTuvSShCKMuBgiDZMxAsKLMjPwACdYnJJUHaceBjrUMFXnVMSzEOVBgZiMLaDfGdgTSkjHtYCtkfiJZVgPXlSlGggusQAIAPwduKlLgaSgJLoIyZXyIjgvgqdognwoVOVkKPcSceTudvhqY")) {
        for (int WYwhEAEM = 1942796838; WYwhEAEM > 0; WYwhEAEM--) {
            czxAyzIffjDtv += QZoRfmcvGBd;
            sODfTZv = DzvCEYCldNzsg;
        }
    }

    for (int MimhxGKOdKGpveqA = 776143290; MimhxGKOdKGpveqA > 0; MimhxGKOdKGpveqA--) {
        continue;
    }

    if (WzdEmxugg == string("RdmNe")) {
        for (int LpVMye = 661367715; LpVMye > 0; LpVMye--) {
            czxAyzIffjDtv = sODfTZv;
            czxAyzIffjDtv += DzvCEYCldNzsg;
        }
    }
}

string jbvKyFpKLUAlu::UgdNjMqyEZbAvX(bool WIYvdgfibvV, bool oNZhH, string uHulkJnPxKn, int ZEtBTnjrZKGR)
{
    int vfzjQY = -347051678;
    string qBDQqdJfIWYNQ = string("IhvWxOOPizQHsjOUvWQWAESKwZOuoPIlZYbgJIObrqCtCqqfEEZgaIgBpyvvMuYKbOIFhFXzbQhffMRzeTqaHkChIPRNaOhvmxEXWuAvBcaNzapdOrwGgUqpsTzEZMmMbxbMkcpLxjEyaGGQyFhWMwPGLGBCPCVbEfrxPGeicfAfGOFUgQkEfiSxsWTTzhFIkpGlS");
    int vPjEL = -339437611;
    double dWVsecRCnwJMXvNT = -815730.9481660317;
    int MeCkYsVhOq = 539773321;
    int nhjABsBk = -2112105002;

    return qBDQqdJfIWYNQ;
}

string jbvKyFpKLUAlu::UMvan()
{
    string YuNYILk = string("LsdMmHFzULTLsQSOFTVKSfORWSomjRIViiwMoDntFcuXFAUDRYfFCYpsKUfRvYtDMVAmQOZlPkKtMUIUKuaHlyXJFmNiiDBjJRUVqQEraXLv");
    string tJlgijBeRYTJpyUP = string("vOFKdtQfrzmsfKdSINhjYOYbzJvfvYQjxdNjoZeIZyKYEtVJVBLsFwVqQIAuPkSYvBoirugIGPDuoauquYDpvDsqADmJOxrKaUzJtulhVDNsEFPqABbTLBWzSxbXwNKRrTRbuyEVZ");
    double cJBKOSrBSipN = -414509.175443005;
    double FlAMaunujGobBXK = -930603.5296006242;
    double bQDaMiNoui = 221842.63511205345;

    for (int YugDd = 1714780143; YugDd > 0; YugDd--) {
        FlAMaunujGobBXK = FlAMaunujGobBXK;
    }

    for (int qNylZtE = 579232830; qNylZtE > 0; qNylZtE--) {
        bQDaMiNoui += FlAMaunujGobBXK;
        FlAMaunujGobBXK = cJBKOSrBSipN;
        cJBKOSrBSipN += bQDaMiNoui;
    }

    if (FlAMaunujGobBXK == -930603.5296006242) {
        for (int ZepbbicBaLfSP = 883935146; ZepbbicBaLfSP > 0; ZepbbicBaLfSP--) {
            continue;
        }
    }

    for (int JijJsUzeeAstlKO = 1926999395; JijJsUzeeAstlKO > 0; JijJsUzeeAstlKO--) {
        FlAMaunujGobBXK /= FlAMaunujGobBXK;
        tJlgijBeRYTJpyUP = YuNYILk;
        cJBKOSrBSipN += FlAMaunujGobBXK;
        FlAMaunujGobBXK -= FlAMaunujGobBXK;
        YuNYILk = YuNYILk;
        FlAMaunujGobBXK /= FlAMaunujGobBXK;
    }

    return tJlgijBeRYTJpyUP;
}

int jbvKyFpKLUAlu::vnqklZQbrwOyhUY(int cYXwZDOkXF, double fVvubGf, double qguSpSi, int QQEMIJiLbMcPgjtd, double pziJWxa)
{
    string yvzqrLDHEfYsNCk = string("edDVVljqiOZzLttFInoXfzhTkNnagrMSqUABnWOpfuGbtHUSOcehcMFtdYgTaD");
    int ZEucjPi = 545044229;
    double EqSOUwF = -955251.9972040791;
    double XaeGPca = 252415.63363939422;
    string cvbBeZZfzEw = string("gUrxyAjDRdgzFZYdOSHrcwVaeQngnvBYoirfXcjctgMssIoVNNfcXHTDGtAuMmQXFSlwrZdDOVLgKgjMuBJNdxFzuiMPHrUptjBgriEIUnEWIyuwXmrbLPerRQBmHSwrbnRpubavpTdbsDBYDgxyaIuSsjpPASmAeMfLkwXgfLQeGAHbfyCuFsjlQKhRdpIHKxNDvmTgFfHgQRlSp");
    bool XkbhsZsTGw = false;
    double MjIeFOxO = -40893.65336714813;

    if (fVvubGf <= -140871.72233522547) {
        for (int uojPH = 1807186159; uojPH > 0; uojPH--) {
            QQEMIJiLbMcPgjtd -= ZEucjPi;
            XaeGPca += XaeGPca;
        }
    }

    return ZEucjPi;
}

double jbvKyFpKLUAlu::nMUzTPV(double xBTIUHZ, bool LVgzpBLy, int eHyEBNB)
{
    int ZkyIeunFwM = 1092233747;
    string bLxfY = string("tLcipJcnlkHvKXPTCksgNYopCNkBDbkIlzPBjmtDBvLqUoViuCiQpToIqcvchUavjVaZpE");
    string CzcHsVdHrngsp = string("IBWlzpCJFszcgWeFqirUjMlPeUfYyoJdPd");
    int RnUmoc = 1478553617;

    if (CzcHsVdHrngsp < string("tLcipJcnlkHvKXPTCksgNYopCNkBDbkIlzPBjmtDBvLqUoViuCiQpToIqcvchUavjVaZpE")) {
        for (int QGJlCXYKgeQJD = 1068770995; QGJlCXYKgeQJD > 0; QGJlCXYKgeQJD--) {
            CzcHsVdHrngsp = bLxfY;
            ZkyIeunFwM /= eHyEBNB;
            eHyEBNB = ZkyIeunFwM;
        }
    }

    for (int XJZpRqOIQs = 467598022; XJZpRqOIQs > 0; XJZpRqOIQs--) {
        ZkyIeunFwM /= eHyEBNB;
        xBTIUHZ = xBTIUHZ;
    }

    if (bLxfY == string("IBWlzpCJFszcgWeFqirUjMlPeUfYyoJdPd")) {
        for (int kgyGKEmtQYO = 425455204; kgyGKEmtQYO > 0; kgyGKEmtQYO--) {
            ZkyIeunFwM /= eHyEBNB;
        }
    }

    for (int HhwpVSrbVpNiefV = 1062689586; HhwpVSrbVpNiefV > 0; HhwpVSrbVpNiefV--) {
        RnUmoc = ZkyIeunFwM;
        CzcHsVdHrngsp = bLxfY;
    }

    return xBTIUHZ;
}

string jbvKyFpKLUAlu::EiODGrjnngKsas(string JWlbAqdRspgaiCB, int hnuNdnpi, string xObKCtuEwk)
{
    double cZQMblcNTiW = -717618.0103822962;
    string ijPpg = string("jVScCTMisJOdRiwlxbTmXhoRxanGuVSxHAhfFMkOIV");
    int GObLFU = -1558588276;
    double htOkCsDrXfA = 783826.66128648;
    int nhIfXUjvQjPbVzk = -659461295;
    int HdkVDmgGeDU = 1480630442;

    if (JWlbAqdRspgaiCB == string("jVScCTMisJOdRiwlxbTmXhoRxanGuVSxHAhfFMkOIV")) {
        for (int iGydAgo = 1785064330; iGydAgo > 0; iGydAgo--) {
            hnuNdnpi -= nhIfXUjvQjPbVzk;
        }
    }

    for (int WekDUMOO = 330689351; WekDUMOO > 0; WekDUMOO--) {
        hnuNdnpi *= hnuNdnpi;
        cZQMblcNTiW *= htOkCsDrXfA;
        cZQMblcNTiW += cZQMblcNTiW;
        ijPpg += ijPpg;
    }

    return ijPpg;
}

void jbvKyFpKLUAlu::HnaGEg(bool XEowflJiMNYg, double VCJwRocdSgnHV, bool fYtto)
{
    double txcOYpWwgzzuAKj = -147154.7628305399;
    bool EkMZhCWAyMWpHhuv = false;
    string tboki = string("iwYGrgAjHOBzZJcxWWRWrFfaSNfKgfuQSrjZsyLLPiayjuWvjZjFOHbhuiXscMGwODtLJpLvjcaCgWkJAiBxTMtEcqkAaLEkYMRhSqRCvAOlaHevbRAcEEQUMLMQsWYIJohMu");

    for (int KeUpVzyoBFAcV = 555244262; KeUpVzyoBFAcV > 0; KeUpVzyoBFAcV--) {
        fYtto = fYtto;
        EkMZhCWAyMWpHhuv = XEowflJiMNYg;
        fYtto = ! XEowflJiMNYg;
        XEowflJiMNYg = ! fYtto;
        XEowflJiMNYg = XEowflJiMNYg;
    }

    for (int SmMuSELRtaCu = 163915054; SmMuSELRtaCu > 0; SmMuSELRtaCu--) {
        XEowflJiMNYg = XEowflJiMNYg;
    }

    if (XEowflJiMNYg != false) {
        for (int GNfyQU = 1796487371; GNfyQU > 0; GNfyQU--) {
            XEowflJiMNYg = XEowflJiMNYg;
            txcOYpWwgzzuAKj /= txcOYpWwgzzuAKj;
        }
    }

    for (int nkKLdFKO = 799619844; nkKLdFKO > 0; nkKLdFKO--) {
        VCJwRocdSgnHV += VCJwRocdSgnHV;
    }

    for (int aTAbtJr = 2086369208; aTAbtJr > 0; aTAbtJr--) {
        XEowflJiMNYg = ! EkMZhCWAyMWpHhuv;
    }

    if (fYtto == false) {
        for (int XJWBaDD = 1987574646; XJWBaDD > 0; XJWBaDD--) {
            EkMZhCWAyMWpHhuv = ! fYtto;
            VCJwRocdSgnHV = VCJwRocdSgnHV;
        }
    }
}

bool jbvKyFpKLUAlu::inIVQTqB(double FphreoJ, int WGZPlwOshL, int UulbXS, string JNgpMwyiEJ)
{
    double OCYObqjupV = 709874.6287648955;
    int etnCNkAUeHJKny = 1089382059;
    bool eBVVSLwmt = true;

    for (int RkTRITnXG = 1792820016; RkTRITnXG > 0; RkTRITnXG--) {
        continue;
    }

    for (int xfmkFeZtMrjT = 2108342942; xfmkFeZtMrjT > 0; xfmkFeZtMrjT--) {
        eBVVSLwmt = eBVVSLwmt;
        OCYObqjupV = OCYObqjupV;
    }

    return eBVVSLwmt;
}

void jbvKyFpKLUAlu::dbVTBgKqNn(double eImnapRSwhX, double nYkbqcIOr, string LMTphY)
{
    string WVoEAxNtqtm = string("iYbiSyuzpDtSxFeoOgJrUVrScdLfWgOwEGAffdDbmWrCAxNcON");
    double lEzTrKJj = 816235.2705861258;
    bool ldgqjCKrHqRCzth = false;
    int qmBPNVALKcYPKRU = -677499103;
    int WCPIUMcpKRuzQih = 651563175;
    bool ZRpMBgPyC = true;

    for (int ZbQceiAMfNZzRzxW = 388716281; ZbQceiAMfNZzRzxW > 0; ZbQceiAMfNZzRzxW--) {
        LMTphY = LMTphY;
        WCPIUMcpKRuzQih /= qmBPNVALKcYPKRU;
    }

    if (eImnapRSwhX == 816235.2705861258) {
        for (int miWCja = 1321997839; miWCja > 0; miWCja--) {
            continue;
        }
    }

    if (WVoEAxNtqtm == string("iYbiSyuzpDtSxFeoOgJrUVrScdLfWgOwEGAffdDbmWrCAxNcON")) {
        for (int GObgbmDqMD = 1103683442; GObgbmDqMD > 0; GObgbmDqMD--) {
            WCPIUMcpKRuzQih *= qmBPNVALKcYPKRU;
            WVoEAxNtqtm += LMTphY;
        }
    }

    if (lEzTrKJj > -213993.29267081202) {
        for (int NTMdxHcAZ = 1269295128; NTMdxHcAZ > 0; NTMdxHcAZ--) {
            continue;
        }
    }
}

int jbvKyFpKLUAlu::WVoasAbIKN(bool jJubQMJQPVHaox, bool QPvZNiGQckEi, double ruyyXGdomjSzVkoT, double tBMPiNOTJScGn, bool dsdtiUMAzw)
{
    bool NbPKMVmPTIIZB = false;
    double uQjQwHLhbL = -267773.7901722867;
    double NXwLmkd = 538930.9321916391;
    string sJoaBlclbLr = string("vwkoXnCVFzjuQamxbjVGluxfskRinlRnxgYNwlEzUydQEYHGzzCxTbynjrWCQZqXs");
    string nTHmJftqjqLYGhFQ = string("bJiUVFFirbJbhjaOcEpxslSBVMSTOsNCQhPnTtcUhhgxhbOWbeCUlCRiPqEdRWOYsewXGcAJORNvMVZbXvPFaANuhCwrXjNWjQdpVVnmBxcuKfDIPSgBZCvSfUMImecJvZDlNkAiaPpxVTdfnHBOgptDFmaBFcvNMGVcqdzKmjDjhogrgPEYpxUyIADFjVsityfpaiqfEOpNWJhCmAFlDYYbvsOxyikACUVothcfShszvpjMiygSiKmWvzqaPjB");

    for (int lXsdLFuedhzSdvX = 601175596; lXsdLFuedhzSdvX > 0; lXsdLFuedhzSdvX--) {
        uQjQwHLhbL += uQjQwHLhbL;
    }

    return 992895011;
}

string jbvKyFpKLUAlu::zhhwvk(string MLKakzSzrlHHiO, string OYrbGOTd)
{
    bool IMTnmub = true;
    double aDepbkx = 247808.37481093276;
    int lEjAKz = -899272991;
    int DAiKQcnT = 889283550;
    int RCdvEfbm = 811477258;
    bool LUhoSoLCZfUvaSDz = true;
    string fkDAV = string("fbuNWMnXOULRWOHuwpReFHNdNLIHOFyIDmrIlTvybFONOfmaZebueJITGoRGXghPrHjPiXwjkhcrchhoYLWCHSCwJrdLYAIoXcElTLXlrQLBhRTbZamasRscUfgjKp");
    bool HnXAaVGxmtxqKocT = true;

    if (fkDAV >= string("kREcFWbnBgBDypRaZJEGdWusEiyWUPlGxhsAwXQRDoyHuyDHwxMCRqNbDWQvEIcEkyFohoWRuuWlpvfJytyPgIKmBgbVbgsYXYhHDguzRWjXXgMeVRFvNAGSzImDlSlhVfzcxAPECgrMRqdQLewZoBEmdeqwOFxyHWUBasFhtjBwwBmbaVoDqWYTPfBmTkAYdmIzAjjAVHUDeXFbnAMRuHZOdJQXqZWtXoOHkCuxQgWhZaoIhUDV")) {
        for (int gocTCOgke = 1329183911; gocTCOgke > 0; gocTCOgke--) {
            continue;
        }
    }

    for (int CZRFpOIoVWY = 1301717154; CZRFpOIoVWY > 0; CZRFpOIoVWY--) {
        HnXAaVGxmtxqKocT = LUhoSoLCZfUvaSDz;
    }

    return fkDAV;
}

string jbvKyFpKLUAlu::EgICxseMZgnz(double rKwTgxpYhbvF, string aHZbqv, bool gnUKc)
{
    double aZQfYnW = -49612.291575915675;
    bool nLpbdfIl = false;
    string clqPKdE = string("gIdyYigFeYrbJxfSFznnDXebwqDxkTOYcyIBYVWYpARuUXoquKeQksjBrlXtYYGSkExMRZfUQfcuJkqETsaIIOlLCJYHcqgLzmoFzGuwicMqLFJSVrBxwkdRIPruwJAGZcHyJUHy");
    double bYCcc = -851007.3577437593;
    double AHtDy = -195539.08106375986;
    int zOHvtgdYueByQo = -1893777993;
    double eVggMqtJC = -980607.744047116;
    double BpDOTyCEGYulRnOk = -247602.4037365387;
    double ViZCNglnQqtJt = -440653.83293839934;
    int AfFIEGFJENhq = -1686229998;

    if (BpDOTyCEGYulRnOk <= 265098.92916748207) {
        for (int FncYo = 510643459; FncYo > 0; FncYo--) {
            nLpbdfIl = ! gnUKc;
            eVggMqtJC += AHtDy;
            rKwTgxpYhbvF += aZQfYnW;
        }
    }

    if (ViZCNglnQqtJt < -440653.83293839934) {
        for (int jUuYViunVAV = 1879812568; jUuYViunVAV > 0; jUuYViunVAV--) {
            ViZCNglnQqtJt /= ViZCNglnQqtJt;
        }
    }

    for (int JdCGGVH = 1122805602; JdCGGVH > 0; JdCGGVH--) {
        AHtDy /= aZQfYnW;
        rKwTgxpYhbvF += rKwTgxpYhbvF;
    }

    return clqPKdE;
}

jbvKyFpKLUAlu::jbvKyFpKLUAlu()
{
    this->PSnnbsxVjft(-671169.9123005178);
    this->ZVdpYuToVw();
    this->jjdRvMbJwV();
    this->DLVNksYZMmE(-669611.0852139732);
    this->pMlBsTHYtpPF(true, 67103.1082105462, 112654.72084837902);
    this->UjBIUgoh(235449459, 331043031);
    this->spOoRqhxTxU(true, -920860935, true);
    this->tDgHXeYo(false, string("GiGYRyyXRsTwXhTfCIDjELXBUGqlOYhyXbrjqeXjfeeJmnIDdMMolSBlrbhrlDviTrDNQWdQxkqojunuQNxglAdxCHbnMhLwmqZWpfzqBiDsdTOvpiezxsDNBkPqjetCxufyDoGVshjjaWeDbWSSMikzbvkeGvOgywDGEXMuW"));
    this->nRSgGqxAMFTiZw(false, -1350547514);
    this->zNCjpFN(string("ORIKGvPIBGbiolcDbxAQXWkDBMongWrTtITjeYZabjXzWwUGOCxCuutFXMkqLPtDoZpRotGetldh"), -657886.566919755, true);
    this->yCYQlXKtL(-914302.0746167863, string("vIfPARCSEzwUHLXYWrmPUuuycQstpwbiFhYwghDGRlefDUicWZWazymPGzVkvsJNOjLkgSDWUziOoeBHdlOSJxSEEHYqyyRgJnMAZED"), false, string("ukwbQHnQUFbxcMGxStCFdjgoDerqCzGVQQWjIoRAhylqmNBfRFYspnNEKVmVtNXfsDDzbtJRPTpZpWXMsuuWytjkdCYNVfsdpe"), string("dFnPSJKgkzuCKJgAtpgjPVfPOtvhCvmqwbTqoNqUtDaenfCosSKSvhByONHohMBmelSWWNzVhOqYsPLHpovHUicyZxRwyFkinBBETpDHPDcmKdxMBNvZwvFUduXJgi"));
    this->UgdNjMqyEZbAvX(true, false, string("hFXiumJHPqMuprwayICDhOtcLiVyGcyIuQVKLuOAoxEgOxlwcKEqhDl"), -1190271135);
    this->UMvan();
    this->vnqklZQbrwOyhUY(823022831, -804309.1491778219, 762568.1488746732, -1935097869, -140871.72233522547);
    this->nMUzTPV(-49926.86783608543, true, 175493895);
    this->EiODGrjnngKsas(string("cniWjAHJGDuvwVdWpgqiNKGYzxkctxbVgBfdqIjRuyEffjRcHVDGpMChjojGSYcDMVxsyhMqKCJakOjAWwypBipLtDxfFjbmuNptkPYqasEyypGCeGWcmBmyUDjlXWunmKBkRJNnPgzdpackMKIEBqZLfoTicglBIEEkHCOgLxukogIhXJDlqkBuxzNCYNIbVMOJwmenxRQJJWUNqSMnxVuYjjPZhFsneNOpULhxvkeloJT"), -1625308379, string("ZetfeiNPLbgWTyUxMGEaDcdJjaatlTdPouNNdjhjlFVNCMrOuqeVbTmcArtmTkmXgAbuRKJimGJTtSqVAnxCAXpFBTYzDXRJLcNIyIdfaVUeYjwJUwE"));
    this->HnaGEg(true, 611495.4506514446, true);
    this->inIVQTqB(-157688.45920937235, -81740726, -341377696, string("DeMknmTsbcmTgkXkoBHZcudXOOvpiawJFsAIYWinhSdcbTQiVeqxiWWzQgFdNZdUreANNmZBcahsvIyMlQDQJSjwyaOTKNrObpNWwUgFZLAdttGLGTpVdrgpqgHVeUzOCOyHdvLlNxpkUlZJJyqzQGBfzjgQVCNEgbEcCvIkaoqF"));
    this->dbVTBgKqNn(339768.41515850404, -213993.29267081202, string("IhEZsfFGxpNtshLVPbRNmiRtdpvvGPTUTKPESeLWzerwkxwTwBUAnQcRHMaiQYOMRRBLezoRkUDNVwoubQjHZEgiYzkRKOZNcuyFDYGHawvtLJBvNjPyCbTcDNeczLuKEUhNeOOOEiaRrkkc"));
    this->WVoasAbIKN(false, false, 448629.58217010833, -512089.4723622338, false);
    this->zhhwvk(string("kREcFWbnBgBDypRaZJEGdWusEiyWUPlGxhsAwXQRDoyHuyDHwxMCRqNbDWQvEIcEkyFohoWRuuWlpvfJytyPgIKmBgbVbgsYXYhHDguzRWjXXgMeVRFvNAGSzImDlSlhVfzcxAPECgrMRqdQLewZoBEmdeqwOFxyHWUBasFhtjBwwBmbaVoDqWYTPfBmTkAYdmIzAjjAVHUDeXFbnAMRuHZOdJQXqZWtXoOHkCuxQgWhZaoIhUDV"), string("ubsZtsHuJyyokLJJZAuAzreeHCYDLFyoiriPvdzcjwZlpcmLdoxBmpCzleHMkHVunHWrTiZhguePQXIHeArlcaiPGbCHqBPUYCYTWNvOFQZAhkNJDqbYsWNYTjbLoUbEswbruZUHSimBVLmaKreqnQBcKSpjCEZFiJXODxCCuBlqfWpwguvgnPwHkWKpwiGdGyPkEpzsMZahMqcfuUZhiKMCslzUPppRAfWaXIaYynhhfpeedkOJqnoQjR"));
    this->EgICxseMZgnz(265098.92916748207, string("bqKoBzGnEKcLuqfTROYsVJaCfqprVHyUgBDgcbNlvvMZMoKXeinBHwxsryxxiQqbSXLIVwhNAqGKLylmiPSxSvfhwEYmkdXQbARkShsTuImBPCAxdNqJiBjhfaxOrqNrTbxxgsGvYcbzXKbsaADUTHoZGbONeJNeSFriQsxsCLZbtTIMbZccUfXHIPKZziqoMufSQsqGzgyYBfOkxaZgNYLYbnsDkTdxgkGevHkAcukQlQcGGYDikXpqiBQM"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bMyOYwPkHDRcf
{
public:
    string fOyLnMLX;

    bMyOYwPkHDRcf();
    void IFCDzENKeko(bool Hlfpg, bool EuNSY);
    double psRNCoXSFcmk(int POyHvvZOnHGuftlH);
    double BxAPtNjQ(string GZUKSWGhWNGVihQf);
protected:
    bool pYLDCteQR;
    bool TzxDHUluDpgTQx;
    int fMEyJx;
    bool TRdncPSliM;
    int VxEYCzrhyzQKrh;
    int TBYjiE;

    bool vgQGmG(int SnRHFF, int BFMUZvmEroHAx, int KHBpw, string HnCQkyUzsEBsXS);
    double YCXIcpACiCm(int rhXJc);
private:
    double fjZiCjUnaSRYwzi;
    string iHyEigwHk;
    bool xDPUq;
    int kQXQSEBRaftu;
    string RioRGaMyqpB;

    string JshzTsVNCqOEDZQ();
    int YLttRAdYqS(int dIpVESSeneaa);
    string djNlovToDqEV(double pVlrU, string pdzHGAXIWBECadM, string kyRlsE, string BuDoc, bool MWRZZvydwyk);
    double ySXnRJNXdmjzm();
    bool AXApWaOX(bool pQIcOVosUjTb, int xQghkWmULnEOWxPG, double oGlkzp, double pNVwjcI, double cWTKhsabVaaF);
    void cwFfmOrlGLTJ(bool xwkxEOm, string EwOAbtWWCnbUKni, bool PhXJaCALn, int NhmjYVM, bool BeqlUo);
    string hlUhemwonTLkax(double xPPrS, int LkrwgjlP, double MwOvGydqhJvIk, int ExSDbNYO);
    double EGCFjjZpXoRKF(int DkVNltr, bool DvkjWhYRBtP, int rKwVR, string xKnmYZJrJ, bool HEoLnchJVHrIMd);
};

void bMyOYwPkHDRcf::IFCDzENKeko(bool Hlfpg, bool EuNSY)
{
    double ytlvGUVgb = -261787.79224306426;
    bool tiEJIZcwzqqNki = false;
    int TbOTTARbibfvkLFa = -1360033587;
    string VcHiP = string("CCoZTiOaJILNlRAMlQPaycqAzXypdYXgGcjisGLKinmmEltnaVnYjelVuOVXukyzkIiIkLAWvDGCgnfPBBuNycWVFXYTPTQLiVQkXoOdWkRRUQQBwcJsgYAvLKLHXAREYmfpYjzZwENSYYElGLTLrtVEEKeabJPzzyUrwiJVSoazXtGhpIUHsMVEOsgjFoGiVBiAAvhAQxBXgQVPahsisiFlOkxWmemYTueczEMRGpzukIMuPsdDNGmMEIEk");
    bool udQgOwVNQqLFa = false;
    string oiYoUU = string("toxqyfyeIFuZhjJDboSsctdgwXHRtGDyvTiOMKNHHfyfmGdxIkaXFHgOZBMYxOgnnGGGAUWfCHrfwRRIOtynHlNLgkLEypVQCofidIEBcFyIygRLsZmORGK");
    int vVjnzxPj = -1117972680;

    if (EuNSY != false) {
        for (int jgxkfxAGtIoFvvUi = 1350306361; jgxkfxAGtIoFvvUi > 0; jgxkfxAGtIoFvvUi--) {
            continue;
        }
    }

    for (int GfMzXNblOH = 20342917; GfMzXNblOH > 0; GfMzXNblOH--) {
        continue;
    }

    for (int YJMOdsAU = 1971420213; YJMOdsAU > 0; YJMOdsAU--) {
        continue;
    }

    for (int lbYpLVw = 163878285; lbYpLVw > 0; lbYpLVw--) {
        continue;
    }
}

double bMyOYwPkHDRcf::psRNCoXSFcmk(int POyHvvZOnHGuftlH)
{
    bool BXTkutXsjEkD = false;
    double lLlEwLgsJFqS = -80626.18685172206;
    int JkuxkwT = 1746073047;
    double vhuEvgTOGZJ = 884783.4714393537;
    bool dKruBNFN = true;
    bool kTGEqpARJNuJnMT = true;
    string dMjFQ = string("ER");

    for (int SuEfuUndeJvMo = 692362617; SuEfuUndeJvMo > 0; SuEfuUndeJvMo--) {
        continue;
    }

    return vhuEvgTOGZJ;
}

double bMyOYwPkHDRcf::BxAPtNjQ(string GZUKSWGhWNGVihQf)
{
    string uHDek = string("RMiBASMINxbIjQtrMOeGQRboSDDOnPGv");
    bool xOAIPM = true;
    bool AvarwN = false;
    double MqulqGlUbPVfxTP = 453806.71958226286;
    int PovKpFqx = -192338138;
    string ZenOst = string("xpfiGxwUOyhYMRJYSWtwYspoBngHAiFIPgfJDhAmxbKkknlrFydQceMRQgfTCDGMJsYjYOzbajfenElKsEZpeYXJZcS");
    bool aLsHMXcO = true;
    string RUeYlnbT = string("UqZXUfROlPJOUSOvTGNusTZofayrGHMGgVqimYgUPCxwExhCFgKmfIpAxTzYinaZkbbcBRdaPPwLjRZTUpciokIzngSfCxyoliFFcBSUjKQjgJnVUapaFLdaVLXUjbmqFTkTuRseUntNafloIyqPPhgHTnPYbdvpbSlMAeHWvQcatCpsLSNUrElQfwWxjOoeOqtwECrgVsKaSOEuXGnpvXNBnPgpJsfVBPoyi");
    bool MXADYGh = false;

    for (int WRTCThDKeWPihxj = 86661208; WRTCThDKeWPihxj > 0; WRTCThDKeWPihxj--) {
        continue;
    }

    return MqulqGlUbPVfxTP;
}

bool bMyOYwPkHDRcf::vgQGmG(int SnRHFF, int BFMUZvmEroHAx, int KHBpw, string HnCQkyUzsEBsXS)
{
    double UQnYCxISlJwopXws = -803989.4952825537;

    if (SnRHFF <= -76924037) {
        for (int OjUkWuIB = 1226023046; OjUkWuIB > 0; OjUkWuIB--) {
            KHBpw *= SnRHFF;
            KHBpw /= KHBpw;
        }
    }

    return true;
}

double bMyOYwPkHDRcf::YCXIcpACiCm(int rhXJc)
{
    double XVAHAEDnGnJR = -471515.83169169445;

    if (XVAHAEDnGnJR == -471515.83169169445) {
        for (int NBMBwlhGWmxrKkl = 1625282578; NBMBwlhGWmxrKkl > 0; NBMBwlhGWmxrKkl--) {
            XVAHAEDnGnJR -= XVAHAEDnGnJR;
            XVAHAEDnGnJR /= XVAHAEDnGnJR;
            XVAHAEDnGnJR -= XVAHAEDnGnJR;
        }
    }

    for (int NEScvqPZibObrLO = 1144351524; NEScvqPZibObrLO > 0; NEScvqPZibObrLO--) {
        XVAHAEDnGnJR += XVAHAEDnGnJR;
        XVAHAEDnGnJR += XVAHAEDnGnJR;
    }

    if (XVAHAEDnGnJR > -471515.83169169445) {
        for (int GxgbksgR = 1866590563; GxgbksgR > 0; GxgbksgR--) {
            XVAHAEDnGnJR += XVAHAEDnGnJR;
            XVAHAEDnGnJR += XVAHAEDnGnJR;
        }
    }

    return XVAHAEDnGnJR;
}

string bMyOYwPkHDRcf::JshzTsVNCqOEDZQ()
{
    bool PrmXMDKxrvzJbQ = false;
    string wCqFiarvUsGpNHPp = string("drMYsfsgmSBXXAdfYRfNPbjuWBsHhhzYVZXOaHlCVesNgfZcpuV");
    bool PaCeQt = false;
    double XAawsyrrH = -351962.2674537803;
    double IBIZhHr = -776645.6253335675;
    string oMwbSGjpW = string("KQvzwbilkwYEvaORQeFsosvzNXjWXEIAlboTKdHtBZuyrcJbQOatdIiTDuYUtdaBOZZANJRlpxIsZlyeXdkjWxvTnKyRhqIvRwmhInIHCPwKCCOWlkWIZCYdmOGgMvxmLJKplZONbglGcfdtSmrDDHYBdUmTCooEmIRfxznJaVqwaHrzZ");
    int QeUOMMKJT = 401431426;
    int tIoEpTS = 1724081639;
    double WFGPftVGcqURmn = -1031587.7824949734;
    string gEePORSEOf = string("fugwiqMrFmdHOfQyixlGgZFtiKNteiiATGgxjRDMKwDICoahlGRfnChlabcNyjHJiEljBkcxgcTBpJDXGVuwWwXsujEUlBVBfvZFabRxOhVEYrywXnTtaPCbGotipwBVNGdfrgEIXqylQluJobTGEKWeUnEvgDRvynvMNlBwrrcdBFgHlJJzmzlfeqcuScbVSTfPJAaSlUNLocQkSDtpkYPVeBRqlzSSNIRbGcGuAdJLiyqFvRNNMSGlEPk");

    return gEePORSEOf;
}

int bMyOYwPkHDRcf::YLttRAdYqS(int dIpVESSeneaa)
{
    double cYBbbbAcdqb = -738771.0474270388;
    double azFXFFPXDY = 296050.3058173366;
    int hUSgjeEcSi = 1902206601;
    double jeCJGriTXwqOQVZH = -422725.59927421407;

    if (dIpVESSeneaa > 1902206601) {
        for (int cmJpR = 1280074531; cmJpR > 0; cmJpR--) {
            continue;
        }
    }

    if (hUSgjeEcSi == 1902206601) {
        for (int sjgUpceY = 1212024142; sjgUpceY > 0; sjgUpceY--) {
            dIpVESSeneaa /= hUSgjeEcSi;
        }
    }

    for (int xAErRxy = 1172398293; xAErRxy > 0; xAErRxy--) {
        hUSgjeEcSi = hUSgjeEcSi;
    }

    for (int CknnHAtE = 1046503884; CknnHAtE > 0; CknnHAtE--) {
        azFXFFPXDY += azFXFFPXDY;
        hUSgjeEcSi /= dIpVESSeneaa;
        cYBbbbAcdqb -= cYBbbbAcdqb;
        jeCJGriTXwqOQVZH = azFXFFPXDY;
        azFXFFPXDY *= jeCJGriTXwqOQVZH;
        jeCJGriTXwqOQVZH = azFXFFPXDY;
    }

    if (cYBbbbAcdqb != -738771.0474270388) {
        for (int JslisIqyP = 2105773251; JslisIqyP > 0; JslisIqyP--) {
            azFXFFPXDY /= cYBbbbAcdqb;
            cYBbbbAcdqb *= azFXFFPXDY;
            jeCJGriTXwqOQVZH += jeCJGriTXwqOQVZH;
            jeCJGriTXwqOQVZH += jeCJGriTXwqOQVZH;
        }
    }

    return hUSgjeEcSi;
}

string bMyOYwPkHDRcf::djNlovToDqEV(double pVlrU, string pdzHGAXIWBECadM, string kyRlsE, string BuDoc, bool MWRZZvydwyk)
{
    int aqBxiKikUFPm = -1222114570;
    double eHHQqJsHCTzJ = -33176.0366042331;
    double QQdKQwR = 402357.209305725;
    bool DmQuOvnpSDKvQnL = true;
    int dVUEx = 2012331989;
    bool ueEotDA = false;
    string MPHwWqrypAFjmqCr = string("flidnKiMPkIkwKZTeajBxYsiYFLkKxQIhWcwVCodVxOlOsAOFQgnIZSqygqStPkLefDYElBwYPPkOpbrFCGkmipQlXznVWWaPESNOqcZsuNhNUSNhFzhHzKcFwbEnUWZSigQycihAvXFaPjeawOkYExRfsIBHYmkoIwYAsoyCHbgFYZwHZyhLdGJFsquVoaIO");
    double AOOzkpHwPy = -436308.1489893142;

    for (int ThGYvl = 1142206196; ThGYvl > 0; ThGYvl--) {
        aqBxiKikUFPm -= aqBxiKikUFPm;
        AOOzkpHwPy *= pVlrU;
        ueEotDA = DmQuOvnpSDKvQnL;
        DmQuOvnpSDKvQnL = ! MWRZZvydwyk;
        DmQuOvnpSDKvQnL = ueEotDA;
    }

    for (int fveDkFtmwPyMzACS = 588567986; fveDkFtmwPyMzACS > 0; fveDkFtmwPyMzACS--) {
        kyRlsE = pdzHGAXIWBECadM;
        QQdKQwR /= QQdKQwR;
        AOOzkpHwPy = QQdKQwR;
    }

    for (int wAPhYU = 154528870; wAPhYU > 0; wAPhYU--) {
        DmQuOvnpSDKvQnL = ! DmQuOvnpSDKvQnL;
    }

    for (int zMxwYJFZBQdhOoH = 1416935837; zMxwYJFZBQdhOoH > 0; zMxwYJFZBQdhOoH--) {
        kyRlsE = MPHwWqrypAFjmqCr;
    }

    if (pdzHGAXIWBECadM != string("OlysdnJBhZacJYfSeLNJiCMmsxiFTSGalmiqdxJuuqIWlQCZlwnyNPmcaMuSJZonVEEHFDXbtzkzleliLLQjNOquNWAsrOHVwooNaRrRlGGwSRGotzdjpXSteyxaYbyiHOnHHVsuXddTXcBoX")) {
        for (int bOZZBep = 754382108; bOZZBep > 0; bOZZBep--) {
            eHHQqJsHCTzJ += QQdKQwR;
            dVUEx *= dVUEx;
        }
    }

    for (int SxrRO = 1962433702; SxrRO > 0; SxrRO--) {
        BuDoc = pdzHGAXIWBECadM;
    }

    for (int uZEHrtZAFaOZEtuQ = 160458179; uZEHrtZAFaOZEtuQ > 0; uZEHrtZAFaOZEtuQ--) {
        MPHwWqrypAFjmqCr = pdzHGAXIWBECadM;
        ueEotDA = ! ueEotDA;
    }

    for (int eCnEDaJLOB = 240860563; eCnEDaJLOB > 0; eCnEDaJLOB--) {
        pdzHGAXIWBECadM = MPHwWqrypAFjmqCr;
        BuDoc += kyRlsE;
        BuDoc += kyRlsE;
    }

    return MPHwWqrypAFjmqCr;
}

double bMyOYwPkHDRcf::ySXnRJNXdmjzm()
{
    string awvRa = string("JtwtGfUaDyARzHZejUGJbHDaHKiCKdUDFqkpwSaHntjCofdsirxnoACIiamQDvqpjNepROgvZzQJZcpuOSTegINmXmDfAYFnPUQBTgNJKGSaZfYGRuIYpSinNWXHnkrIPzunePrscTufGcJBuZbHpdbmTkTEJrFDYeUlzHNpLcnEbzfR");
    bool XzYrqOMGAHDXhmI = false;
    int VvNjYLpWZA = 114474929;
    double evAWDMLD = 71102.40519072169;
    double dHNyZhVAwWboK = -517917.8032094822;
    string zCIkg = string("NBpoTPoVICUzCEUNmMlOYrfFjUbLZiPAShOQDlNRvjdpFkDFwnomzWWQqhbkzThfoPERidYwrtxhaETGqQVodwTRUSLFpCxHQWFpCSuuMwuxhYSocbpSpgzIKxalVtdjbpqUm");

    for (int wfyUQlXmT = 1596971677; wfyUQlXmT > 0; wfyUQlXmT--) {
        dHNyZhVAwWboK *= dHNyZhVAwWboK;
    }

    return dHNyZhVAwWboK;
}

bool bMyOYwPkHDRcf::AXApWaOX(bool pQIcOVosUjTb, int xQghkWmULnEOWxPG, double oGlkzp, double pNVwjcI, double cWTKhsabVaaF)
{
    int QrlQfAq = 524104663;
    bool Zerpz = false;

    for (int ViUYGiqcRJgqPW = 859092334; ViUYGiqcRJgqPW > 0; ViUYGiqcRJgqPW--) {
        pQIcOVosUjTb = ! pQIcOVosUjTb;
        oGlkzp += oGlkzp;
        cWTKhsabVaaF += oGlkzp;
    }

    for (int FjsDzqmlOUyM = 668389405; FjsDzqmlOUyM > 0; FjsDzqmlOUyM--) {
        continue;
    }

    return Zerpz;
}

void bMyOYwPkHDRcf::cwFfmOrlGLTJ(bool xwkxEOm, string EwOAbtWWCnbUKni, bool PhXJaCALn, int NhmjYVM, bool BeqlUo)
{
    int OIUwo = -1789365112;
    double oqVdrqaGdlA = 35199.39411941514;

    if (NhmjYVM <= -1789365112) {
        for (int wewePaOj = 1808421731; wewePaOj > 0; wewePaOj--) {
            OIUwo *= OIUwo;
        }
    }

    for (int FvKmiEoIfHwFzCWU = 987911617; FvKmiEoIfHwFzCWU > 0; FvKmiEoIfHwFzCWU--) {
        BeqlUo = ! PhXJaCALn;
        EwOAbtWWCnbUKni += EwOAbtWWCnbUKni;
    }

    for (int RvMxZRp = 1853989454; RvMxZRp > 0; RvMxZRp--) {
        BeqlUo = xwkxEOm;
        PhXJaCALn = BeqlUo;
        oqVdrqaGdlA -= oqVdrqaGdlA;
    }

    for (int JImfTsp = 408164532; JImfTsp > 0; JImfTsp--) {
        NhmjYVM *= OIUwo;
        NhmjYVM = NhmjYVM;
        PhXJaCALn = ! PhXJaCALn;
    }
}

string bMyOYwPkHDRcf::hlUhemwonTLkax(double xPPrS, int LkrwgjlP, double MwOvGydqhJvIk, int ExSDbNYO)
{
    double ELYvlgprTSjIZV = 68081.87293331452;
    bool lRUGjn = true;

    for (int oSSOflgRUKZUKHhu = 1934144937; oSSOflgRUKZUKHhu > 0; oSSOflgRUKZUKHhu--) {
        ELYvlgprTSjIZV -= xPPrS;
        ExSDbNYO /= ExSDbNYO;
    }

    if (MwOvGydqhJvIk > -778558.2376874445) {
        for (int BapNCJkQXgxA = 2038769299; BapNCJkQXgxA > 0; BapNCJkQXgxA--) {
            continue;
        }
    }

    return string("UpSyYJAZtkMAlbGKTFjEsfPWBMHCMENjoPHevhlO");
}

double bMyOYwPkHDRcf::EGCFjjZpXoRKF(int DkVNltr, bool DvkjWhYRBtP, int rKwVR, string xKnmYZJrJ, bool HEoLnchJVHrIMd)
{
    string OJudGSRfvBICwC = string("VyoFljvtScZQTGeCcqnnqiUsRLiGQzqsEkINdkjzlqhUkLHBlriNNJdKWxnpNomaYoZzcExeVVKVnVdcaIOlmfTdByvnnoEQwTmzCjSmjzhaQdTJAnkUpYaOkzbypSHEVwzTpTJncHWOOOjOXgrcVsVxTYAIHWfOqKJneJKZcfloIBnddw");
    int mMnGCKXSheETXE = 516159580;
    string aJZYoBjPSew = string("NKNmeUzHIJjNrnjLTAcreexuVuvgtBOgQsYHKuvpQnwWxPixjIVTJxWslwWAaxdmgNAXCD");
    bool QbSJkIKqv = false;
    string uLtJwFviH = string("cAWpeISVcsmXWHxnrHVhZpTNrHdiJnNintdYWYeWfKwvsbzyRtaEque");
    int ZOqJrTzosZz = -545341838;
    int sGmkZb = -621419293;

    if (sGmkZb == -545341838) {
        for (int WBEGEVs = 703039757; WBEGEVs > 0; WBEGEVs--) {
            DvkjWhYRBtP = DvkjWhYRBtP;
            DkVNltr += sGmkZb;
            HEoLnchJVHrIMd = DvkjWhYRBtP;
        }
    }

    for (int QGbGc = 1692030481; QGbGc > 0; QGbGc--) {
        continue;
    }

    for (int pUKQU = 401768609; pUKQU > 0; pUKQU--) {
        mMnGCKXSheETXE -= rKwVR;
        DkVNltr += sGmkZb;
        uLtJwFviH += aJZYoBjPSew;
    }

    if (QbSJkIKqv != false) {
        for (int QpcslHuFUHPxFOrA = 1312973456; QpcslHuFUHPxFOrA > 0; QpcslHuFUHPxFOrA--) {
            HEoLnchJVHrIMd = QbSJkIKqv;
        }
    }

    return 409737.652739234;
}

bMyOYwPkHDRcf::bMyOYwPkHDRcf()
{
    this->IFCDzENKeko(true, false);
    this->psRNCoXSFcmk(1328671511);
    this->BxAPtNjQ(string("CTuUXsXfIQTekCYGHPxkOgAZzEYSfMNUIzNTJToAokaMLprvYFGTEVTJLMImQWkoafvrJgBTiztCRMcjVDJsmQeEeuQwJGeVNcVAyksFhECBIsNZPLUNEfzSDasFCnHFYMnCFvTUQpZDPyDKyBbnusNdnJJkuhAqobuilBbCkxjEgNijQWemFLxTTHPCsQNOgWvKwErhbRAPrLiEBSaOdHoVmGRYnRNwNsoIDYHSqqecCvVOyIkwnsTvZLfa"));
    this->vgQGmG(-76924037, 215645765, -1803882803, string("FJwmEtrMwjWqJsptzZmMungKxopJvbBJSPIWqSIFLEPDlpCLhptOQCZLiaQOVLFgSAOtHuKnNRScdOuZSRmpSYRhIzHQFYVCiddWjcFOLMJxJnzYOfzcDAVhAfXNDQUuXmmgGUFcPAxRkDyoONGsSSofUaLjanqazTMzURARRSleXRHWfUrWcxzZyOfbOmVKgSipoZUgEqShZXyndqBCchyINtqdwHqthwuZzwktqPnconwyrmIfSBQKu"));
    this->YCXIcpACiCm(624561009);
    this->JshzTsVNCqOEDZQ();
    this->YLttRAdYqS(616265417);
    this->djNlovToDqEV(-544217.0759414412, string("UvKsZYqPokuumZJbdhbAxSnCPgZcViZWBNqciQNKoJquXbQJbqfzTEnRjuJtVYvuoaVOOKVsIwbVPsFCMhIJSlsNfbLqPmVMoVSDSMhkOLMNoPBcmdjVHWOhRwkZBJnxIYkfErIIVVUsbaAZhsYlsrVMKXQPOdeOYeGWtASbbDYyCigUsuLfxhjUloSgpmNOAdKN"), string("MnJqFrJKeAqKmYbVVaWgGiVcAKxPWEBVmYPCdVLjHZuHueDUeAgVPNikWUexlauTRdelQelnYZTthHeNkVkvwAFtjhLOspankWGKdxpdsKjLzbGvRUt"), string("OlysdnJBhZacJYfSeLNJiCMmsxiFTSGalmiqdxJuuqIWlQCZlwnyNPmcaMuSJZonVEEHFDXbtzkzleliLLQjNOquNWAsrOHVwooNaRrRlGGwSRGotzdjpXSteyxaYbyiHOnHHVsuXddTXcBoX"), true);
    this->ySXnRJNXdmjzm();
    this->AXApWaOX(false, 1179151723, 838134.1154087328, -127441.30579792276, 1038109.6807742603);
    this->cwFfmOrlGLTJ(true, string("egbsSiFASRTySsFmSzCjGfeciAxOmjprMAsAmv"), true, -99170732, true);
    this->hlUhemwonTLkax(-453448.8775578422, -1899647350, -778558.2376874445, 1149851868);
    this->EGCFjjZpXoRKF(-1255587235, true, 1491615432, string("DPSqJnNWQGmkZeFTCUmoUSAkZ"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HjbKovQwzqyVzoub
{
public:
    bool KkZKgsZmox;
    string KFhjBcMhBvUvcuE;
    string JQqFuSPChpvkA;
    int UqVQUfF;
    bool VbSuVRjvzjH;

    HjbKovQwzqyVzoub();
    double EvihigVyFB();
    double uDtkVKYIVfJO(string yAOjJZORbp, string ZTJSUbgzAvnh, string RkHLEYJzYYS, double OEuMTeObdamk);
    void PfOIGZGv();
    void paNaPMfDT(string CSpVZsiUSqNKHKe, string JJfrwA, string YaTggyh);
    void aZTFqhKhVE(double dNcubg, string kuWwQUypCCxNf, bool HyapePYsHPdyv);
    int meSXXpkHCJMpotiw(double tmherodOkM, double fDFquvtY, int btPxxTFxfHCFM);
    string uoecOBhmKLsU();
protected:
    bool ysrwmbpPlTkWd;
    int loOURfciOEoDbpm;
    double XtQljBU;

    void OmlBAY(double zYUMrOPnmzzCLbdT, double GpNNO, double XqTjjpeuMaKvOim, int YNPhuUB);
    double CxJzq(int mtaKOBB, double bVHmKvveyCE, double ZWgIzSvEStsJg);
private:
    double YwILuWfIzhpZ;

};

double HjbKovQwzqyVzoub::EvihigVyFB()
{
    bool pOacma = true;
    int iZTgQtyhYYLRvqo = 2099962717;
    double AZOJQWRwQExp = 377322.71977187385;
    string VLBXKdDU = string("dCuIOhzZgEQOSPeFEtuBDzjlzVWWxAFMDuIfiUuVFbTvOrtHJtFsVtDNHqqdnAaMPihFZGicBYihgNLHwQwNKqoXpGEjBvWdDtZKMARHOivqFckCMCY");
    string ZQztP = string("zMmTgpjx");

    for (int JltoABy = 1401198980; JltoABy > 0; JltoABy--) {
        VLBXKdDU = VLBXKdDU;
    }

    for (int mrmTMAuU = 1905871843; mrmTMAuU > 0; mrmTMAuU--) {
        VLBXKdDU += ZQztP;
        VLBXKdDU = VLBXKdDU;
        iZTgQtyhYYLRvqo += iZTgQtyhYYLRvqo;
    }

    return AZOJQWRwQExp;
}

double HjbKovQwzqyVzoub::uDtkVKYIVfJO(string yAOjJZORbp, string ZTJSUbgzAvnh, string RkHLEYJzYYS, double OEuMTeObdamk)
{
    double HbvIxs = 276040.2905378621;
    string OdNyvibd = string("uwuZTLoFXNgmkgnuqIXymrzGuGHSqrnNYFNeWAZwMXkbaorDbVNjFRVlkIHwfSleIomwkJ");
    bool qboHdUUTseCYmcT = false;
    string wPoMM = string("OPqDyKWsSoCvRQxtCPOgyMsBCzsbYchSMfwzEsIhXtSXGdvglMsLhTeGejAZaiRkPqmcwFzBXvtDOU");
    bool OZmUHt = true;
    double QoPBeunECeopvmuJ = -212072.73280312185;
    double LiaFu = 474480.40711442445;
    int WbrElUZklgslgimk = -485129664;
    bool iwIhOascgYirVg = false;
    double ctJhRV = 398047.0651674088;

    for (int VuVuBDCOu = 308011660; VuVuBDCOu > 0; VuVuBDCOu--) {
        OZmUHt = iwIhOascgYirVg;
        yAOjJZORbp = RkHLEYJzYYS;
    }

    for (int xmJvXf = 586911853; xmJvXf > 0; xmJvXf--) {
        OdNyvibd = ZTJSUbgzAvnh;
        wPoMM = OdNyvibd;
        RkHLEYJzYYS = ZTJSUbgzAvnh;
        ZTJSUbgzAvnh = wPoMM;
    }

    return ctJhRV;
}

void HjbKovQwzqyVzoub::PfOIGZGv()
{
    int Bymrj = 1592960066;
    string kaSNP = string("iSNmbaSjICOwDZQAMXGmhOeoUKBDroBg");
    string MsohsUK = string("NenNhtZdwgOCYtEtqrKxhgxfDTc");
    int uAHGhcXowJmFjsO = -1751974743;
    bool QvvXEHHvTQEcQyZf = false;
    bool VPYBmPoTSeu = false;
    string AKiSq = string("JHFONiClEvseDaNrQfZWxHuvKMEfpITFAmvfByxFYnucrjztybPkxhmmDNSJNkXZzErhweVWxzRxSbrgdZkWvoGMXZFlZBSSwTWOjcQdtjEFCnJKryHUuzRDhfGQRZYXoWuXCAoFZWFAaxDZIoIRkiIIHUmXaOIjCkcFVZCAtGEOZBbleCBXWshgnbMRqyvaoUQVafnCtujDPDBEKPsrsCSXdxThtHZrWuE");
    string JGRarDhOvGNl = string("nldIKcUyHYFKhbBjdsnlwuzZzWxndapXGgDlgQAPtSLIWpgdIRhbSVnHQaykmUabDUY");

    for (int lqwsV = 1994835154; lqwsV > 0; lqwsV--) {
        MsohsUK = JGRarDhOvGNl;
        kaSNP += JGRarDhOvGNl;
    }

    if (JGRarDhOvGNl <= string("iSNmbaSjICOwDZQAMXGmhOeoUKBDroBg")) {
        for (int HyKvU = 1340561633; HyKvU > 0; HyKvU--) {
            AKiSq = JGRarDhOvGNl;
            kaSNP += kaSNP;
            Bymrj += Bymrj;
            AKiSq = AKiSq;
        }
    }

    for (int gngLqjuLF = 1117211518; gngLqjuLF > 0; gngLqjuLF--) {
        continue;
    }
}

void HjbKovQwzqyVzoub::paNaPMfDT(string CSpVZsiUSqNKHKe, string JJfrwA, string YaTggyh)
{
    bool EVcfNvpPOalFtGZy = true;
    bool vygmfNptzBP = true;
    bool ToIZlgDMeYnrQV = false;
    int TKUYx = -752148205;
    bool BcHGXlBkbLtNHW = false;

    if (YaTggyh != string("RhstzAJsfyyXEcyGvQVioqoiuucnnLexYRgEMxMesNoVSkxJuqGmvXbUAzYe")) {
        for (int BfdamVbnssCd = 634375920; BfdamVbnssCd > 0; BfdamVbnssCd--) {
            ToIZlgDMeYnrQV = ! ToIZlgDMeYnrQV;
            BcHGXlBkbLtNHW = ! BcHGXlBkbLtNHW;
        }
    }

    for (int ikGvpkVnSj = 72434182; ikGvpkVnSj > 0; ikGvpkVnSj--) {
        continue;
    }

    for (int sUrxJ = 252707607; sUrxJ > 0; sUrxJ--) {
        BcHGXlBkbLtNHW = ! EVcfNvpPOalFtGZy;
        CSpVZsiUSqNKHKe += CSpVZsiUSqNKHKe;
        ToIZlgDMeYnrQV = ! ToIZlgDMeYnrQV;
    }
}

void HjbKovQwzqyVzoub::aZTFqhKhVE(double dNcubg, string kuWwQUypCCxNf, bool HyapePYsHPdyv)
{
    string mMtUjwGilcoeffU = string("FJJwNrlNxbCcleRSzlVjZDvAzSbZNjoHNQQtlXprcGECAIiYiCVQaKrfqFkXwHnAMpqTupGltNtcIFbviTtAEEEiYjTbECxEuwNJelipBjyEqfcehWPIBQsgdiFdOJgBmCyXNQNgiu");
    double WJVHvoKH = 740323.180204848;
    int mYuPCXIvBbjtW = -1904238141;
    bool SpudFZstjjOImosf = false;
    bool EYpmgoOhScMzQ = false;
    string NEipNswMRrAltUjC = string("osclgwUmsQNMYruzzFwUTckXAGjYVHQVocjdGbeTpcIHaNCdKKUllTSpMGHxhaOnAErteDqTHPMGFTzqSUeUqseVGlYCyKOAwyXjFAIxQXBpsmJVuOxxkMJocMJRJdbrjGyShxYNaoJbPHDrEOCZKNZEzCYyoFTyEQMCKSRYuhlGaIcBGsiltVirbvWn");
    string yMowBTO = string("aZIVVESEyhZPAcAQRPyHxTLbAGBSTZuNwwmRoGcyhqvekeASFtzZeYfNMitUHZYiJGEYNUaNapdQFPcAFnQrksCmWHPQWCGwKbNwCyAKSsXSvQxRRDxGuKzKSFheMGtUJxrUpFBXXUJVsjnMrjvAlVTNOGYuCsIdYpIvAklpIaopCqSeZBVlg");
    double enGkNTEkBMwliKa = -624593.3946863404;
    double vgIcg = -492783.1213831508;
    double rFlyGO = -212198.14297556903;

    for (int IBxrNH = 349466287; IBxrNH > 0; IBxrNH--) {
        rFlyGO -= rFlyGO;
    }

    if (mYuPCXIvBbjtW != -1904238141) {
        for (int MLJVLPnqn = 1072334285; MLJVLPnqn > 0; MLJVLPnqn--) {
            NEipNswMRrAltUjC = NEipNswMRrAltUjC;
            kuWwQUypCCxNf += kuWwQUypCCxNf;
        }
    }

    for (int FsZlq = 234316001; FsZlq > 0; FsZlq--) {
        mMtUjwGilcoeffU += mMtUjwGilcoeffU;
        yMowBTO += mMtUjwGilcoeffU;
        dNcubg -= WJVHvoKH;
        EYpmgoOhScMzQ = ! HyapePYsHPdyv;
        mMtUjwGilcoeffU = mMtUjwGilcoeffU;
        kuWwQUypCCxNf += mMtUjwGilcoeffU;
        EYpmgoOhScMzQ = EYpmgoOhScMzQ;
    }

    if (WJVHvoKH >= -676272.4138725987) {
        for (int HeLuqzU = 879997105; HeLuqzU > 0; HeLuqzU--) {
            continue;
        }
    }

    for (int ZzKCVhEiMRuPQtxF = 1847189740; ZzKCVhEiMRuPQtxF > 0; ZzKCVhEiMRuPQtxF--) {
        HyapePYsHPdyv = EYpmgoOhScMzQ;
        HyapePYsHPdyv = EYpmgoOhScMzQ;
    }

    if (yMowBTO <= string("osclgwUmsQNMYruzzFwUTckXAGjYVHQVocjdGbeTpcIHaNCdKKUllTSpMGHxhaOnAErteDqTHPMGFTzqSUeUqseVGlYCyKOAwyXjFAIxQXBpsmJVuOxxkMJocMJRJdbrjGyShxYNaoJbPHDrEOCZKNZEzCYyoFTyEQMCKSRYuhlGaIcBGsiltVirbvWn")) {
        for (int ViIStmVfIqsPqqbH = 1380748073; ViIStmVfIqsPqqbH > 0; ViIStmVfIqsPqqbH--) {
            NEipNswMRrAltUjC += kuWwQUypCCxNf;
            WJVHvoKH += dNcubg;
            mMtUjwGilcoeffU += NEipNswMRrAltUjC;
        }
    }

    for (int wHpIFlghmmDP = 652029395; wHpIFlghmmDP > 0; wHpIFlghmmDP--) {
        dNcubg /= enGkNTEkBMwliKa;
        dNcubg += rFlyGO;
    }
}

int HjbKovQwzqyVzoub::meSXXpkHCJMpotiw(double tmherodOkM, double fDFquvtY, int btPxxTFxfHCFM)
{
    double SwBMCErqYQNTLTR = -748617.3049158307;
    double aFohxXlrSrEQkuw = 123323.68841103945;
    double hZXKMB = 170941.30441953498;
    bool PxPHck = false;
    double gKDoXvu = -169932.14747206884;
    bool CFqrvxy = true;
    double uYNJoJcehDk = 66960.78645661665;
    string VzWSZDUdeSpzEHVC = string("kJsIzkDTdCtLfvecQaNLxiRwUYyobLVWrAlcvLngSqotFoMlKyVxLvNPngpYqDFqvvrNfzIgOXbjRieBGQzvTGDwKZEtUIhBelDzvhvjdzElIoeaKYQFexzO");

    if (fDFquvtY != 66960.78645661665) {
        for (int ByGgoVCwtMmCQ = 429541748; ByGgoVCwtMmCQ > 0; ByGgoVCwtMmCQ--) {
            tmherodOkM /= fDFquvtY;
        }
    }

    for (int uULkxcHUHJ = 1097191611; uULkxcHUHJ > 0; uULkxcHUHJ--) {
        gKDoXvu = tmherodOkM;
        btPxxTFxfHCFM = btPxxTFxfHCFM;
    }

    return btPxxTFxfHCFM;
}

string HjbKovQwzqyVzoub::uoecOBhmKLsU()
{
    bool UNvwOTwSDhAAjs = true;
    string TspeSsr = string("prXnoKGyYLyJDsSYsIvfrlrChRQtaiAOLTTBcjKTdcWFOKRqInZKvvhOQxfLoEWAgIqTazsswzeXqSXicuScBMmJURoGwCtpRGBzQqTPnpcmzZpWYvqzVVuENgXtIPrUeNHbnpbzgqYOTDkeEltbVNhMgopBNpcJDLQrQvldICuPOjknxrXDPiouRDurBmJZ");
    int DGOLRkzxT = 1739617495;
    double qPXcDkQ = 664817.6937350275;
    int MgQnmsOHCgB = -748202996;
    int bKvZdlsEqJxZKIwW = 1466629018;
    double vOIGdeQGce = -504883.00799178274;
    string epraJWfxC = string("VKJfaKOlNaHnFaKrqeAwnTdllmfjzHoMTIuNKMNQEbeWWQMTHuASvhCRDOmrVTNJYKCallWQdxrVXqdFqvdQDhSYOgffPTwlFyRprJssCmintJPDe");

    for (int RiFoL = 1351088819; RiFoL > 0; RiFoL--) {
        qPXcDkQ = vOIGdeQGce;
        TspeSsr += epraJWfxC;
        bKvZdlsEqJxZKIwW += bKvZdlsEqJxZKIwW;
    }

    if (epraJWfxC == string("VKJfaKOlNaHnFaKrqeAwnTdllmfjzHoMTIuNKMNQEbeWWQMTHuASvhCRDOmrVTNJYKCallWQdxrVXqdFqvdQDhSYOgffPTwlFyRprJssCmintJPDe")) {
        for (int NQMXCAU = 2067958319; NQMXCAU > 0; NQMXCAU--) {
            qPXcDkQ -= qPXcDkQ;
            qPXcDkQ = vOIGdeQGce;
            DGOLRkzxT *= bKvZdlsEqJxZKIwW;
            epraJWfxC = epraJWfxC;
            TspeSsr = epraJWfxC;
        }
    }

    if (vOIGdeQGce <= 664817.6937350275) {
        for (int gtPmWGIkCjuod = 1157089457; gtPmWGIkCjuod > 0; gtPmWGIkCjuod--) {
            DGOLRkzxT = MgQnmsOHCgB;
        }
    }

    for (int tBRReptxtECiAi = 2009273540; tBRReptxtECiAi > 0; tBRReptxtECiAi--) {
        bKvZdlsEqJxZKIwW /= DGOLRkzxT;
        MgQnmsOHCgB += MgQnmsOHCgB;
        bKvZdlsEqJxZKIwW -= MgQnmsOHCgB;
    }

    for (int zmuFuzK = 1593986280; zmuFuzK > 0; zmuFuzK--) {
        qPXcDkQ = vOIGdeQGce;
    }

    return epraJWfxC;
}

void HjbKovQwzqyVzoub::OmlBAY(double zYUMrOPnmzzCLbdT, double GpNNO, double XqTjjpeuMaKvOim, int YNPhuUB)
{
    int VIISBwv = -1882800215;
    int SNVEdGQqCAXgqwgn = 1631379728;
    bool ENtVCiU = true;
    bool TZUbmHfxKFAZgB = false;
}

double HjbKovQwzqyVzoub::CxJzq(int mtaKOBB, double bVHmKvveyCE, double ZWgIzSvEStsJg)
{
    string dzcXkmwsXSFjJz = string("ftpgZzMDZjFPwuBAKwPfoQbPGZBkxMhclzjhaLFBVpRkPkCrszeetEwGnqBGvKpcMiqurUzTKMxEK");
    string mGrspCJErrbMC = string("nXvSiHyDMPFYcevIwvvZGqeKsoULjhQUYSkCpdmqGHEZqOYfSnGCHmhEWwAbPkiXxC");
    double SBTJstmazsi = -69275.62484735204;
    double SBeEjqZgvchSQwOs = -666148.0642101093;
    string wRJrdoAZ = string("dMzoLtnJqtPmaboAYGjJurlBrcvckGmNPMktLSAJUUeSOWJJpbSxjlRtHVhqXuWeoRVpTBIezoiDTQIAdbVBMsEEGHWqUCcXHnpawaOmNMHwDgoijDyYMHdEPxuxmYDXNKDAsCtfArUIXIM");

    if (bVHmKvveyCE >= -666148.0642101093) {
        for (int saaPCGRxOELBjry = 2001978289; saaPCGRxOELBjry > 0; saaPCGRxOELBjry--) {
            mGrspCJErrbMC += dzcXkmwsXSFjJz;
        }
    }

    return SBeEjqZgvchSQwOs;
}

HjbKovQwzqyVzoub::HjbKovQwzqyVzoub()
{
    this->EvihigVyFB();
    this->uDtkVKYIVfJO(string("nEFvaWeehXmjdobpPklsivcfwVWehLovRiKICjjrBDFMxId"), string("zXQprJIpmjIbIUoNuHuGPWqSknmEpcCQyCRBQiHAgDCMXhEADleaxOocYhfQqiyGSBoyPCAQuKFZOmJscqcZnIocWiWYvSsKyrTrYK"), string("AsHzoMzUZBanMeIGogzAywTbAvjToJdbAXkJorCtRjhvEMulPqhYLMSKOBsXJQRTUD"), 458834.269232484);
    this->PfOIGZGv();
    this->paNaPMfDT(string("OaqcsIBaNZBVVwWbx"), string("RhstzAJsfyyXEcyGvQVioqoiuucnnLexYRgEMxMesNoVSkxJuqGmvXbUAzYe"), string("gDmEcQuIUUSsUgiJEtSDSGkLXHpwZHpXZiQXibXcIiNEmkVyPOkYlhoGiUsvbYGHlDUEjFOxvZTSYFxgdPjhZulHrogrOoHmHQYTIXREHlXBUCuBOaDpqDeDNTPEKPsBdDkpISrsejubXMUZaImRRuBtHj"));
    this->aZTFqhKhVE(-676272.4138725987, string("ONJXYYfUfLzOnswFfWMKzWtpBXfxLeLcdwfIPIOVSvpjTcteVQOHYgKBLBpcUKqEUlsGluXzNCoUzTMZLYhlUYogIrWgVMiWCESalglrWRvNEFBBhWyPOlLcFDGjGnkjWAWjfZxcOBqXoOGNQlAgKkdaNkTaVTTBYUcKuDwJFZpNZTVKSF"), true);
    this->meSXXpkHCJMpotiw(-576390.4185554268, -751718.2250273302, -648707224);
    this->uoecOBhmKLsU();
    this->OmlBAY(629179.4547747225, -258203.36370269564, 981621.3924028011, 1580104585);
    this->CxJzq(721284034, -550715.8184634274, 937543.0163472358);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lhEvNpOlbPf
{
public:
    double sdEpUgtFV;
    string KruupWs;

    lhEvNpOlbPf();
    bool OEEAEKHpE(int FVsyFVBQe);
protected:
    double uFiRKY;
    bool POzzcySiZOhmcx;
    bool HOVVRmsDGFzHr;
    bool QRpQMZmCJO;

    int NCcOkoBZi(bool JKFJxKJJH, int afrCXOLU, string ZlAPtoVuzTQJu, bool MCelzUECGvlf, int nKWgjwS);
    bool snhtlBsSGmS();
    string QEdxjAKRQsdZv(string JfHwMb, double MUUFCjE, int nNcsgyJOtVZPSUw, bool CfRNSjFSdQ, int dVPDuWYnNCPfT);
    string wrZqqkRFbvjkSEcz();
    int jAGxDOZ(int lOyFynTzphQKVaui, int rwPVuaiCCOfrvaV);
private:
    string jIXMmHREnwytZ;
    string DepkgYLt;
    bool RuYylMbrPFdHFU;
    bool MLoDFrWG;

    string ENjAACuEDkyCnuf(string acvVbwTGC);
    bool XwhvgEIJrL(int JaVvMGTDv, bool HpSLp, int PySsQUeeMRgWJmQh, string aPcveFupGcUTD);
    string jmGFbvSizIr(bool dajtLHgzPboBYU, string RfFaH, bool rMaDYtb, string RxOmiHNOcGB, double IEkPFLoezUHh);
    string APrLNhqucknLpBup(int IVeqozelWwUhC, double EPGWP, string qNhPfHLBwhJCz, double qdAjcAZU);
    bool iMICOqEmeD(bool olbPCmAwqS, string FYDQihrqaabZ, bool pIRAGttK, int qVjMPRfsXAgCugxB, int YmaFTOoKlOB);
    string klPYwPuayZZLAStV(int hdOyPnPCHkKr, bool sdqIjGZMeVEeDn, int uphRjRXdaY, int Qzrcpos, bool GMhOkxhdlpICPH);
    double ZyZRAxKJcuEy(double vAHFpnwhAxXMRBB, string HFzTZHnpmHkeMd, bool oCzRpHkgzVzee, string jlOGV, bool CpANCgifL);
};

bool lhEvNpOlbPf::OEEAEKHpE(int FVsyFVBQe)
{
    int ozzLgBoQL = 412660481;
    bool QduPUqsRRmzda = false;
    int cDOKdEmQJmqLZhL = -918624903;
    double kztbHKI = -207834.6880754983;

    for (int vObCqxD = 1006930455; vObCqxD > 0; vObCqxD--) {
        ozzLgBoQL = ozzLgBoQL;
        FVsyFVBQe /= FVsyFVBQe;
    }

    for (int WBEyNenJJzUDbFP = 1992830405; WBEyNenJJzUDbFP > 0; WBEyNenJJzUDbFP--) {
        cDOKdEmQJmqLZhL += ozzLgBoQL;
        QduPUqsRRmzda = ! QduPUqsRRmzda;
    }

    if (ozzLgBoQL > -918624903) {
        for (int MoLbtiDtr = 1581219096; MoLbtiDtr > 0; MoLbtiDtr--) {
            continue;
        }
    }

    if (cDOKdEmQJmqLZhL >= 412660481) {
        for (int wPHRrrbAzPuRNDsw = 1168849500; wPHRrrbAzPuRNDsw > 0; wPHRrrbAzPuRNDsw--) {
            cDOKdEmQJmqLZhL += FVsyFVBQe;
            cDOKdEmQJmqLZhL = ozzLgBoQL;
            cDOKdEmQJmqLZhL *= cDOKdEmQJmqLZhL;
        }
    }

    for (int hoZnbQiEOZUohzc = 1879778530; hoZnbQiEOZUohzc > 0; hoZnbQiEOZUohzc--) {
        ozzLgBoQL += cDOKdEmQJmqLZhL;
    }

    return QduPUqsRRmzda;
}

int lhEvNpOlbPf::NCcOkoBZi(bool JKFJxKJJH, int afrCXOLU, string ZlAPtoVuzTQJu, bool MCelzUECGvlf, int nKWgjwS)
{
    string CYflqldbvh = string("lcTCoXlBAHGInlRowDeAItkEWgOGSJWHFxMwTwnLvwbCLffONVEFyEOUdcFKuoSePfsOjXapcquLVkcbgwDHdFUYRAzSIewtKrPhhSWIWOKasiZcYwBoWaTOeGtEJHRkyYcpsuQeUcaUcuAEtnehsrSbLfUBahhIRiXGzRr");
    string SoXgtggiMamCP = string("ncGLJcxTSabhYPVNtvMXwEegHtYqIFfwDcKRleMHSxQRAaKRUbFnyqDkMtGeuzpZjCeSFPFEppefdBXAurh");

    for (int iDuWeappuMwq = 1256844623; iDuWeappuMwq > 0; iDuWeappuMwq--) {
        SoXgtggiMamCP = CYflqldbvh;
        SoXgtggiMamCP += SoXgtggiMamCP;
        ZlAPtoVuzTQJu = SoXgtggiMamCP;
    }

    return nKWgjwS;
}

bool lhEvNpOlbPf::snhtlBsSGmS()
{
    string FZLDhIihfIxun = string("hccpqGBIEiTLxZmGNJLtfWVTQfSVxGresylFooYxVLtjVjMSsKbtminRxgPDJfoJcjVDhARwSmiJEdrZOhzzLDLvLddfU");

    if (FZLDhIihfIxun == string("hccpqGBIEiTLxZmGNJLtfWVTQfSVxGresylFooYxVLtjVjMSsKbtminRxgPDJfoJcjVDhARwSmiJEdrZOhzzLDLvLddfU")) {
        for (int RGFYBLfHyrjFpOGM = 1407227255; RGFYBLfHyrjFpOGM > 0; RGFYBLfHyrjFpOGM--) {
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun += FZLDhIihfIxun;
        }
    }

    if (FZLDhIihfIxun <= string("hccpqGBIEiTLxZmGNJLtfWVTQfSVxGresylFooYxVLtjVjMSsKbtminRxgPDJfoJcjVDhARwSmiJEdrZOhzzLDLvLddfU")) {
        for (int hOxQbr = 628309805; hOxQbr > 0; hOxQbr--) {
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
        }
    }

    if (FZLDhIihfIxun != string("hccpqGBIEiTLxZmGNJLtfWVTQfSVxGresylFooYxVLtjVjMSsKbtminRxgPDJfoJcjVDhARwSmiJEdrZOhzzLDLvLddfU")) {
        for (int fSJayUVBaqH = 898868259; fSJayUVBaqH > 0; fSJayUVBaqH--) {
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
        }
    }

    if (FZLDhIihfIxun < string("hccpqGBIEiTLxZmGNJLtfWVTQfSVxGresylFooYxVLtjVjMSsKbtminRxgPDJfoJcjVDhARwSmiJEdrZOhzzLDLvLddfU")) {
        for (int zRyExWfARB = 1512847193; zRyExWfARB > 0; zRyExWfARB--) {
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
        }
    }

    if (FZLDhIihfIxun <= string("hccpqGBIEiTLxZmGNJLtfWVTQfSVxGresylFooYxVLtjVjMSsKbtminRxgPDJfoJcjVDhARwSmiJEdrZOhzzLDLvLddfU")) {
        for (int TpFYxQCywgxtV = 1566880064; TpFYxQCywgxtV > 0; TpFYxQCywgxtV--) {
            FZLDhIihfIxun += FZLDhIihfIxun;
            FZLDhIihfIxun = FZLDhIihfIxun;
            FZLDhIihfIxun += FZLDhIihfIxun;
        }
    }

    return true;
}

string lhEvNpOlbPf::QEdxjAKRQsdZv(string JfHwMb, double MUUFCjE, int nNcsgyJOtVZPSUw, bool CfRNSjFSdQ, int dVPDuWYnNCPfT)
{
    string XbXTOck = string("UmluitVafIaxlZIuTLZjfLQDfaPsAIpTOCmkOTlxZOBVcBdLkKGPJRfAMNJYPxZXAjHLkFTrqZDGEnyNhDalLTnGcbJECzYTIHEDeBdrBuSBFjOyXIRyrNqRHaLaEJIobzAjJfzVtPdbixazfRFhJdoLISZoMHWoDOXjSAWArwH");
    int OBxRJnVhxQDc = 527863318;
    int UcBxSSg = 1715491079;
    bool xjFgSlPoPEQ = true;
    string VdEZKeC = string("eRtpXaaWdEkwMIYyPmYLbnPXoJTKhpFTzsbhdWdhMvcOOmcuFLBgnFLdziYfpemhURXjJsbXHMYIUskyZFBuovyLbQkKMZvJjiLMrTxdVhBhQwy");
    bool zjrswGsJ = false;
    string MYZwOFohiGxbl = string("UGobklkuP");

    for (int MezWW = 2087185207; MezWW > 0; MezWW--) {
        dVPDuWYnNCPfT *= OBxRJnVhxQDc;
        JfHwMb = JfHwMb;
        MYZwOFohiGxbl += XbXTOck;
    }

    if (VdEZKeC > string("UmluitVafIaxlZIuTLZjfLQDfaPsAIpTOCmkOTlxZOBVcBdLkKGPJRfAMNJYPxZXAjHLkFTrqZDGEnyNhDalLTnGcbJECzYTIHEDeBdrBuSBFjOyXIRyrNqRHaLaEJIobzAjJfzVtPdbixazfRFhJdoLISZoMHWoDOXjSAWArwH")) {
        for (int cmcLAglkWAzG = 29421933; cmcLAglkWAzG > 0; cmcLAglkWAzG--) {
            XbXTOck += JfHwMb;
        }
    }

    for (int DgedqTpMosKCLba = 1770448534; DgedqTpMosKCLba > 0; DgedqTpMosKCLba--) {
        MUUFCjE /= MUUFCjE;
    }

    if (VdEZKeC >= string("UGobklkuP")) {
        for (int pDbHioAQVGU = 56255402; pDbHioAQVGU > 0; pDbHioAQVGU--) {
            dVPDuWYnNCPfT += dVPDuWYnNCPfT;
            VdEZKeC = VdEZKeC;
            nNcsgyJOtVZPSUw = OBxRJnVhxQDc;
            nNcsgyJOtVZPSUw *= dVPDuWYnNCPfT;
        }
    }

    for (int xojslRlKMC = 787684711; xojslRlKMC > 0; xojslRlKMC--) {
        UcBxSSg -= UcBxSSg;
        JfHwMb += MYZwOFohiGxbl;
    }

    return MYZwOFohiGxbl;
}

string lhEvNpOlbPf::wrZqqkRFbvjkSEcz()
{
    bool lyEGRZBfwQu = true;
    bool xjzYUiKimWOep = true;
    bool UxSGbABKMzbJZJ = false;
    string QcFlAcb = string("SPBKHPYZlWDlwpOCfoxrBZdoASeFfzr");
    bool gehhu = true;
    string zQOEPsiroaDpuE = string("gfTdGlKIbdoPAZewekPgbtuXFMOGJIvpSlNXGfLBFUSCtSvmEeRjorHvVbXqBZybTEiZZqiMDPzcfiHwLHhWJVkbMdSYicXdePkJUOzqcChEPBXhWKRlkWWxFYivqisfqHiZKUrShLTxohlhipCFRZUzQcDgVWqj");
    string rJgRa = string("NBJpAVPCTXUpzqGtpFeQOtRZBoYvaNKXPy");
    int mCBiqmH = -1674780270;
    bool qzVBR = false;
    double vbIPhtDPKGZjMhf = 781447.8502404235;

    for (int eUtNRIjYrsLH = 1032488094; eUtNRIjYrsLH > 0; eUtNRIjYrsLH--) {
        lyEGRZBfwQu = ! gehhu;
        vbIPhtDPKGZjMhf -= vbIPhtDPKGZjMhf;
        zQOEPsiroaDpuE = rJgRa;
    }

    for (int wjHllMrRnBQUBqZL = 2135297820; wjHllMrRnBQUBqZL > 0; wjHllMrRnBQUBqZL--) {
        mCBiqmH /= mCBiqmH;
        qzVBR = xjzYUiKimWOep;
        xjzYUiKimWOep = UxSGbABKMzbJZJ;
        lyEGRZBfwQu = ! UxSGbABKMzbJZJ;
        rJgRa += zQOEPsiroaDpuE;
        gehhu = ! qzVBR;
    }

    return rJgRa;
}

int lhEvNpOlbPf::jAGxDOZ(int lOyFynTzphQKVaui, int rwPVuaiCCOfrvaV)
{
    string zpTBIuEnxCINrJQ = string("ITnHCkOXJIEVMvZcrdVVBsDMuyoeeEMvgdQCLtxKzpBVffKwRiZdxmLQVtrhaAGxADslyfYHzJUhxsJLyimLlCDvHiTUvbLDQgWehauQsqcErfUpbwjyKFluHrW");
    double FoCMLOQnbqMbIZ = -831440.5925527153;
    string UWCKMzrLsa = string("voRrpNZERRNPIkqihEwRFuLatkRFdiTrqpleonIwtbEVOz");
    int GtVuPvNjCSkgDsK = -74807146;
    int mcOLBtbGT = 1048519330;

    if (lOyFynTzphQKVaui < -74807146) {
        for (int haijpTSOIhyTjrhz = 809181516; haijpTSOIhyTjrhz > 0; haijpTSOIhyTjrhz--) {
            FoCMLOQnbqMbIZ *= FoCMLOQnbqMbIZ;
        }
    }

    if (mcOLBtbGT <= 1048519330) {
        for (int kTqNPuQ = 850635986; kTqNPuQ > 0; kTqNPuQ--) {
            continue;
        }
    }

    return mcOLBtbGT;
}

string lhEvNpOlbPf::ENjAACuEDkyCnuf(string acvVbwTGC)
{
    int JWmTjGYQ = -1389454278;

    for (int OcicYxhsjNyu = 254793638; OcicYxhsjNyu > 0; OcicYxhsjNyu--) {
        JWmTjGYQ *= JWmTjGYQ;
        JWmTjGYQ += JWmTjGYQ;
    }

    if (JWmTjGYQ != -1389454278) {
        for (int mTrcfZKOu = 1844864823; mTrcfZKOu > 0; mTrcfZKOu--) {
            acvVbwTGC += acvVbwTGC;
            JWmTjGYQ *= JWmTjGYQ;
            JWmTjGYQ /= JWmTjGYQ;
            acvVbwTGC += acvVbwTGC;
        }
    }

    for (int ZJomzK = 2002534202; ZJomzK > 0; ZJomzK--) {
        acvVbwTGC = acvVbwTGC;
        JWmTjGYQ = JWmTjGYQ;
        acvVbwTGC = acvVbwTGC;
        JWmTjGYQ = JWmTjGYQ;
    }

    if (JWmTjGYQ >= -1389454278) {
        for (int WBddQYcWMsB = 1625420828; WBddQYcWMsB > 0; WBddQYcWMsB--) {
            acvVbwTGC = acvVbwTGC;
        }
    }

    return acvVbwTGC;
}

bool lhEvNpOlbPf::XwhvgEIJrL(int JaVvMGTDv, bool HpSLp, int PySsQUeeMRgWJmQh, string aPcveFupGcUTD)
{
    double HaRDMgDtJQntcB = 225757.04661930606;
    int ulPiDOFM = -195504189;
    string UUnSDEXeupfHAR = string("cLAXPqPTpmyEEndGcEAAWXgAEFibBUQgfpHjFaZOQrennWqYooqvGSwnQlQIolJpKaOOwVWcZiTuaKYQaKxanqByfdLzyfgPrOoGmzLfkLTQywJDxbhlmcBbAbrrexUMZworjrfNaTtAApNfnqWGUGXqEecHfSPyEuBlrSgHLvvosvJkqFbMlMRefdoJRQtvPQZdVLmqMzMerFwFfVxKtwGrFSawwxkSsTZDfMJpCkFDyO");
    int ewwTZb = 400332309;
    int RZBvebpvXu = 1794673313;
    bool qDewKYXJglO = true;

    for (int ImwCaX = 79307615; ImwCaX > 0; ImwCaX--) {
        ewwTZb -= ulPiDOFM;
    }

    for (int eUXbuHlGVwDB = 2009745442; eUXbuHlGVwDB > 0; eUXbuHlGVwDB--) {
        continue;
    }

    return qDewKYXJglO;
}

string lhEvNpOlbPf::jmGFbvSizIr(bool dajtLHgzPboBYU, string RfFaH, bool rMaDYtb, string RxOmiHNOcGB, double IEkPFLoezUHh)
{
    double aUvyPq = -59114.25682575214;
    string ZRtBf = string("qOVUccLMhumbzCbXzYwjMcxOrTVqILNdkbVomWOTvDGmUQnbehSlYCnmwTLsYZOZbgsgOXNZNeeQADSHxoMHweADtbVuZZnHKNHyPchJayapXvcMcxgAfwZZCimHyGaWyKojqEkdWwKjBtSyYyKKkTOksrGLMflqpdFMDFeqRwJqZDFlNDzFqC");
    double YmsIcK = -796788.0214925166;

    if (IEkPFLoezUHh == -59114.25682575214) {
        for (int trbSyoiP = 1563141954; trbSyoiP > 0; trbSyoiP--) {
            aUvyPq += IEkPFLoezUHh;
            aUvyPq /= YmsIcK;
        }
    }

    for (int nSOFK = 2034085404; nSOFK > 0; nSOFK--) {
        rMaDYtb = ! dajtLHgzPboBYU;
        ZRtBf = ZRtBf;
        rMaDYtb = dajtLHgzPboBYU;
        YmsIcK /= IEkPFLoezUHh;
        RfFaH = RfFaH;
        RxOmiHNOcGB = ZRtBf;
        YmsIcK -= YmsIcK;
    }

    if (RxOmiHNOcGB > string("PxKnhScEnIvIrNTUsVsgGpxFQhulMntHcYgwDNahSuKmqZEqTTSllyCLesiqTTalPzsLXCqNjzJOsADsHTqwSFSyHdCjXmecXxUhBKtoOsqcRnfoPgyrUxCDDqZJyrUSjxbSzQNtcUJPcinyoYqsRIAcsJSJmaqApFUQWNPoeNmnyag")) {
        for (int SvQMOPQ = 556416541; SvQMOPQ > 0; SvQMOPQ--) {
            YmsIcK *= aUvyPq;
        }
    }

    return ZRtBf;
}

string lhEvNpOlbPf::APrLNhqucknLpBup(int IVeqozelWwUhC, double EPGWP, string qNhPfHLBwhJCz, double qdAjcAZU)
{
    bool aNNlzqCjJXzHSyRl = false;
    string slrTtLAxVneXNQ = string("RNUaTtjNsISLSrxLOkZqHLZgJCVRTqigoANrkstvfJYpsSIIMcfarQhJgDQwPWAqmFMliyyqpQVDdVsynzSZraruv");
    int VwYyfCpeKoe = -991959972;
    double lOYGdcEGN = -187717.0848682862;

    if (qdAjcAZU < 707445.6166308528) {
        for (int hFQLxJTl = 245855250; hFQLxJTl > 0; hFQLxJTl--) {
            VwYyfCpeKoe *= IVeqozelWwUhC;
            EPGWP += EPGWP;
            slrTtLAxVneXNQ = slrTtLAxVneXNQ;
            EPGWP = EPGWP;
        }
    }

    if (slrTtLAxVneXNQ < string("RNUaTtjNsISLSrxLOkZqHLZgJCVRTqigoANrkstvfJYpsSIIMcfarQhJgDQwPWAqmFMliyyqpQVDdVsynzSZraruv")) {
        for (int FUdlgOo = 1144624418; FUdlgOo > 0; FUdlgOo--) {
            lOYGdcEGN *= qdAjcAZU;
            lOYGdcEGN *= qdAjcAZU;
        }
    }

    for (int MNPQZkJLNdDWt = 1981326548; MNPQZkJLNdDWt > 0; MNPQZkJLNdDWt--) {
        VwYyfCpeKoe *= IVeqozelWwUhC;
        EPGWP /= qdAjcAZU;
    }

    for (int vkZcDoqkBzu = 410202403; vkZcDoqkBzu > 0; vkZcDoqkBzu--) {
        qdAjcAZU = qdAjcAZU;
    }

    return slrTtLAxVneXNQ;
}

bool lhEvNpOlbPf::iMICOqEmeD(bool olbPCmAwqS, string FYDQihrqaabZ, bool pIRAGttK, int qVjMPRfsXAgCugxB, int YmaFTOoKlOB)
{
    int XZeti = 1943722274;
    bool mAnrWysQk = true;

    for (int XrLFMyv = 946533123; XrLFMyv > 0; XrLFMyv--) {
        continue;
    }

    return mAnrWysQk;
}

string lhEvNpOlbPf::klPYwPuayZZLAStV(int hdOyPnPCHkKr, bool sdqIjGZMeVEeDn, int uphRjRXdaY, int Qzrcpos, bool GMhOkxhdlpICPH)
{
    string VGKPfCj = string("pvyRPuPHJLfZKDkTlviwYhHSmfdBwQmcooZLYshkTqOsKzjquMNJNpGXKeAmGYSDZEheNiNRNIdsxefMMulznFVktqfWrhXCWsedCNnKdnBlSNbegjUxfWtrDcLs");

    for (int HOHOqLebpWNhzfkp = 690342141; HOHOqLebpWNhzfkp > 0; HOHOqLebpWNhzfkp--) {
        Qzrcpos -= uphRjRXdaY;
        VGKPfCj += VGKPfCj;
    }

    for (int pzzRUztNWWrJAj = 768145294; pzzRUztNWWrJAj > 0; pzzRUztNWWrJAj--) {
        uphRjRXdaY = uphRjRXdaY;
        VGKPfCj += VGKPfCj;
    }

    return VGKPfCj;
}

double lhEvNpOlbPf::ZyZRAxKJcuEy(double vAHFpnwhAxXMRBB, string HFzTZHnpmHkeMd, bool oCzRpHkgzVzee, string jlOGV, bool CpANCgifL)
{
    double EPlfUcncaGyGIzeE = -240187.30211001888;

    for (int rnrTf = 1724400385; rnrTf > 0; rnrTf--) {
        vAHFpnwhAxXMRBB = vAHFpnwhAxXMRBB;
        oCzRpHkgzVzee = ! CpANCgifL;
    }

    for (int ZzZpkfVsyQQuE = 1487733466; ZzZpkfVsyQQuE > 0; ZzZpkfVsyQQuE--) {
        EPlfUcncaGyGIzeE /= vAHFpnwhAxXMRBB;
    }

    if (EPlfUcncaGyGIzeE == -8867.255060511869) {
        for (int CPzyWYftetUoMVSF = 932229240; CPzyWYftetUoMVSF > 0; CPzyWYftetUoMVSF--) {
            jlOGV = jlOGV;
            jlOGV += jlOGV;
        }
    }

    return EPlfUcncaGyGIzeE;
}

lhEvNpOlbPf::lhEvNpOlbPf()
{
    this->OEEAEKHpE(-160259925);
    this->NCcOkoBZi(true, -949897134, string("vxBiqcsoAvugKLLtKOaRtJzmabwwtuGNKHOOOSTLyZkitBuqQWwGJhcGDxqtoONaMAqyVDwevKcBhAEuaIoeNTkGIGpKbDCfRPeHTKTwJdjBJlPbAhPqzRSLwIdbYYetmJldQkNupwNKIDgxNJzjNhJpRMARmiQWxQUbIIOiAnGdVALVaZxRbUamOrZMMAvzIDwtyFMhZKUzqVJR"), false, 812711549);
    this->snhtlBsSGmS();
    this->QEdxjAKRQsdZv(string("TTDhLwvkREuunDSwwLYIPnMPNPdnykUDdeBUuSQDSQrlXtchheUvjWXGBQfaoJgQmnMGCYjcHPDypaROClMAlEOzINuIfIMVocPDvjAszmkTijuGvApDonRhWcNeDvEHXaaklHWvOnEesSPYThAOBTFXQkyhSxxLuSfxjLrXTCtYmRErrynJdYVrNYHSkUXXxHfEtnlFWHlgxyqNBtVAhqttFkjQDcOWmAGIpFIqTaDQWMommhX"), -550500.7738546593, 193105936, false, 411382793);
    this->wrZqqkRFbvjkSEcz();
    this->jAGxDOZ(1257799241, -28066557);
    this->ENjAACuEDkyCnuf(string("udpQGqjUlWmt"));
    this->XwhvgEIJrL(-2024466237, false, 1154633409, string("PwHYmzEFpfpWKxyxzKyFimyCMmvBwGmnLGLKIrZdMiYtjgBBfJooDmNvllSdhpbPaQLFABQGurRZANHWfuOzZmnNtLXkmKUhxcNFvYNEnWHtIBXRLFLuHxalFJIZTmYOaEfPnExkKKYkaRrPyvTHUvEQceNzBDdVOFhDUKhEzRsWt"));
    this->jmGFbvSizIr(true, string("QUxMuciFgtYFGnQcmCzOcaIuUYusBlLsfvJSeBCddKIRWVvgHEgwlLmgrfqXvOYxUrEuHpJNIshwRrQPInfUYOXOtnwUCldSbgtebcgTFojrKCaDMFeUEaEjFxMCUmEypEmuOSThrwmmWYKkpTufalEuEpaRbgknQBPZvzfZlfAFXmLvsqRhQIkAyidyWgBmKKZLuxpMRWKkVGPpqrGvxOraiypbQOQcVk"), true, string("PxKnhScEnIvIrNTUsVsgGpxFQhulMntHcYgwDNahSuKmqZEqTTSllyCLesiqTTalPzsLXCqNjzJOsADsHTqwSFSyHdCjXmecXxUhBKtoOsqcRnfoPgyrUxCDDqZJyrUSjxbSzQNtcUJPcinyoYqsRIAcsJSJmaqApFUQWNPoeNmnyag"), -714885.3844608243);
    this->APrLNhqucknLpBup(933393543, 707445.6166308528, string("DnKI"), -242420.49365792752);
    this->iMICOqEmeD(false, string("ppeOTBmqwZPlmDPTXARpvxvVRgMWaHIGFvUqEXYPYMySxbUjDgdTJuOPBKUfoYIBHhLQCatPlgfZNXfhvXbVZEJCtehrOGuokhgOJNSTQzsCKyFRKQLOOFQQmHDPJNHRDAYJYGNvUmZGWhokkuBE"), true, -300807762, 640313790);
    this->klPYwPuayZZLAStV(-1136035520, true, 1888333900, 538109077, false);
    this->ZyZRAxKJcuEy(-8867.255060511869, string("hfNpGCeewpBOPkQBGhCmMVRaRYUclpPuwwcLROGqbKoMwaBToRfzgCTJgoGbOjYBTcQI"), true, string("FnwsmnedpbMSCQz"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZYnSgvumAJg
{
public:
    bool qKPnbnWdoeg;

    ZYnSgvumAJg();
    bool eRWQUldm(double xhlWZGNRLMwG, bool BzkTAuiavwoERR);
    string pssfnCvEHm(double ZDGpWBzJTSmDsKF, double pbNjWlPkzbU, double pZLfvoxwcaCDEvvM, bool uFBxYWyDOeTzP);
    bool UarzMLwhWNYg(bool GlkIrkvdhE, string gxXFMkaFlaByAok);
    void bEBzMOuhRIafTvjU(int tjBPJWh, int hRAwMbuEFWsXyW, bool zHJxIo);
    bool JmxvtfRFnt(bool pNqtBncplrDVzuu, bool MwMYVcCgXmcNVyy, string rJtCcXqBqoTcoCaC, bool sRtCWDBXTr);
protected:
    string HlHoraBp;

    string OeMwlTreIcVGJC(int HnvHjbDROMQxYxsp);
    int ZmJIWNBgjYVCqE(bool clpRbfgJDKDHMR);
    string fNJHu(double uHvFfnkSisr);
    int tJAYBKPLq();
    int qYquOZ(double OCkAWyvoIpdKV, double JgKEjzcqub, double ESOMWM, int VzwBRiuqgdnkIgIT);
    double lKQSBtnNHPbuop();
private:
    double EHHcpJQmFkSnBmG;
    string OucgNTcWUy;
    string iTZdFJRYLmhcN;

    double MyXQHf(string MWJmx, bool bqNeczdkPaquJ, int KrWgFJoKVwKjXnQ, int gRRHrDEZhUOFY);
};

bool ZYnSgvumAJg::eRWQUldm(double xhlWZGNRLMwG, bool BzkTAuiavwoERR)
{
    bool DMHcpxlrDQzbkO = false;
    string iUKtM = string("TDEWnxNqwdQUEmTsCNciuuiBKwULCCXoExfLNYYXdlCgyfIwpzlMXAsLFFTzQoPlUhTAJGRjTFpKEdgOFatIeSybQbPUMSXVZgCsoobCxlFrgXFuSMgJAMyfZPPllNlL");
    double cXiWdErZaWhI = 612300.141051167;
    string QtiwMULgKfuqYKm = string("BtrazgAIgi");

    if (iUKtM > string("BtrazgAIgi")) {
        for (int LajCMRpZsXLxbcSy = 75928522; LajCMRpZsXLxbcSy > 0; LajCMRpZsXLxbcSy--) {
            QtiwMULgKfuqYKm = iUKtM;
        }
    }

    if (iUKtM == string("BtrazgAIgi")) {
        for (int VgIJiqhWailt = 1729478222; VgIJiqhWailt > 0; VgIJiqhWailt--) {
            QtiwMULgKfuqYKm += QtiwMULgKfuqYKm;
            xhlWZGNRLMwG *= xhlWZGNRLMwG;
            iUKtM = iUKtM;
            DMHcpxlrDQzbkO = BzkTAuiavwoERR;
        }
    }

    for (int uoVfzNAywVylsLsP = 161246990; uoVfzNAywVylsLsP > 0; uoVfzNAywVylsLsP--) {
        xhlWZGNRLMwG += xhlWZGNRLMwG;
        BzkTAuiavwoERR = BzkTAuiavwoERR;
        cXiWdErZaWhI *= cXiWdErZaWhI;
    }

    return DMHcpxlrDQzbkO;
}

string ZYnSgvumAJg::pssfnCvEHm(double ZDGpWBzJTSmDsKF, double pbNjWlPkzbU, double pZLfvoxwcaCDEvvM, bool uFBxYWyDOeTzP)
{
    int RAcMxv = 1857259790;
    double ftytuueDe = 1047461.8229736136;
    bool sprCdRIvqghwvjzF = true;
    bool BXVqowbfkic = true;
    int NcAGmdae = 37044939;
    bool hjKQg = false;

    for (int SeaIh = 510022717; SeaIh > 0; SeaIh--) {
        pbNjWlPkzbU *= pbNjWlPkzbU;
        ftytuueDe -= pZLfvoxwcaCDEvvM;
        BXVqowbfkic = ! sprCdRIvqghwvjzF;
        pZLfvoxwcaCDEvvM /= ZDGpWBzJTSmDsKF;
    }

    for (int uzUQWMyIo = 398255724; uzUQWMyIo > 0; uzUQWMyIo--) {
        ZDGpWBzJTSmDsKF += pbNjWlPkzbU;
        hjKQg = ! uFBxYWyDOeTzP;
    }

    if (BXVqowbfkic != false) {
        for (int hlOrfjiU = 1785873326; hlOrfjiU > 0; hlOrfjiU--) {
            RAcMxv += NcAGmdae;
            hjKQg = uFBxYWyDOeTzP;
        }
    }

    return string("qSQJOIdulZDtYIKeUIqNZxmEcXbdXzPhWwjZmoVFJdEXRoQcmxDvELEDIvmQdAvzFGVAoZETzsiVQKGOtliaczdNbmYrjZClPILIqvzHgBgxzVgJnjZExIAIqQNleBkfBNDlf");
}

bool ZYnSgvumAJg::UarzMLwhWNYg(bool GlkIrkvdhE, string gxXFMkaFlaByAok)
{
    string PTKzVdWX = string("YeXImCKEjLEiegzlwVpozfTbzqjofJBVSWPPKRGgfjxGVFFePVeFzSqQffuiNfIOrTPMLCWIbCpBMtdQHyqSULvGawOBSsZNsujQLvTncuSqOvjaDzbLlxXqMrvkrsjmYVjMP");
    double cplYIAXaILl = 163714.2312555793;
    bool CDudGdzax = false;

    if (CDudGdzax == true) {
        for (int GfvUfYSUoXS = 152628668; GfvUfYSUoXS > 0; GfvUfYSUoXS--) {
            PTKzVdWX = gxXFMkaFlaByAok;
            GlkIrkvdhE = ! CDudGdzax;
            PTKzVdWX = PTKzVdWX;
        }
    }

    for (int erHPgg = 1301288350; erHPgg > 0; erHPgg--) {
        PTKzVdWX += gxXFMkaFlaByAok;
        CDudGdzax = ! GlkIrkvdhE;
        GlkIrkvdhE = CDudGdzax;
        PTKzVdWX = PTKzVdWX;
        GlkIrkvdhE = GlkIrkvdhE;
    }

    for (int RawJIm = 1159621561; RawJIm > 0; RawJIm--) {
        CDudGdzax = CDudGdzax;
        GlkIrkvdhE = CDudGdzax;
    }

    for (int tcVGFvdNZJKiE = 98856311; tcVGFvdNZJKiE > 0; tcVGFvdNZJKiE--) {
        gxXFMkaFlaByAok = gxXFMkaFlaByAok;
        cplYIAXaILl += cplYIAXaILl;
        PTKzVdWX = PTKzVdWX;
    }

    for (int goXIjGJ = 536635011; goXIjGJ > 0; goXIjGJ--) {
        GlkIrkvdhE = CDudGdzax;
        PTKzVdWX = gxXFMkaFlaByAok;
    }

    return CDudGdzax;
}

void ZYnSgvumAJg::bEBzMOuhRIafTvjU(int tjBPJWh, int hRAwMbuEFWsXyW, bool zHJxIo)
{
    string prEcrMce = string("CDfzqRFPNwedYHrlUwkwKHrhjCrrXuPJehPRogbFRBebQKxCrXOZyFwNkGIwBPuGgQSTFvHWLbiABNybVgCltTNxMmoREUMpUsZBxsuDLcuMhVxcnhXPcoqFHuaPcNbsyOlIsgnYSEfQQQOTZDAPjeclmsZIY");
    double WhHghQMSzwMCRa = -933896.3416882091;
    bool fEUDNPZtzUZtOt = false;

    for (int lHyZaiHeOtmx = 2008463904; lHyZaiHeOtmx > 0; lHyZaiHeOtmx--) {
        continue;
    }

    for (int ayLcVdlIZDY = 1463283370; ayLcVdlIZDY > 0; ayLcVdlIZDY--) {
        tjBPJWh += hRAwMbuEFWsXyW;
        hRAwMbuEFWsXyW -= hRAwMbuEFWsXyW;
    }
}

bool ZYnSgvumAJg::JmxvtfRFnt(bool pNqtBncplrDVzuu, bool MwMYVcCgXmcNVyy, string rJtCcXqBqoTcoCaC, bool sRtCWDBXTr)
{
    int yKQbuG = 1157699609;
    string GMqqPHgZgj = string("mpISmzabUYNmNdcNvJzVWhEIAkkHrTPexaIcDPUyaNCNdwMkfbDzIMQWNcYWXoxnMn");
    string IZKqY = string("gOUFR");
    bool FniElpvWnew = true;

    return FniElpvWnew;
}

string ZYnSgvumAJg::OeMwlTreIcVGJC(int HnvHjbDROMQxYxsp)
{
    int WmBSXPyppXAT = 58693237;

    if (WmBSXPyppXAT == 58693237) {
        for (int fBGYuYEzXghWc = 1724172038; fBGYuYEzXghWc > 0; fBGYuYEzXghWc--) {
            HnvHjbDROMQxYxsp *= HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp -= WmBSXPyppXAT;
            WmBSXPyppXAT += HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp -= WmBSXPyppXAT;
            WmBSXPyppXAT += WmBSXPyppXAT;
            WmBSXPyppXAT /= WmBSXPyppXAT;
            HnvHjbDROMQxYxsp = WmBSXPyppXAT;
        }
    }

    if (WmBSXPyppXAT <= 58693237) {
        for (int GvmtZKQc = 1180998621; GvmtZKQc > 0; GvmtZKQc--) {
            WmBSXPyppXAT += WmBSXPyppXAT;
            HnvHjbDROMQxYxsp -= WmBSXPyppXAT;
            HnvHjbDROMQxYxsp -= HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp += HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp += WmBSXPyppXAT;
            HnvHjbDROMQxYxsp -= HnvHjbDROMQxYxsp;
            WmBSXPyppXAT += HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp *= HnvHjbDROMQxYxsp;
        }
    }

    if (WmBSXPyppXAT != 58693237) {
        for (int rRWYpFvh = 2112114476; rRWYpFvh > 0; rRWYpFvh--) {
            WmBSXPyppXAT /= HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp += HnvHjbDROMQxYxsp;
            WmBSXPyppXAT /= WmBSXPyppXAT;
            WmBSXPyppXAT = HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp /= HnvHjbDROMQxYxsp;
            WmBSXPyppXAT += HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp /= HnvHjbDROMQxYxsp;
            WmBSXPyppXAT /= WmBSXPyppXAT;
            HnvHjbDROMQxYxsp *= HnvHjbDROMQxYxsp;
            WmBSXPyppXAT *= WmBSXPyppXAT;
        }
    }

    if (WmBSXPyppXAT > 1331616031) {
        for (int yIJDpxjLUqcrXPS = 1747039313; yIJDpxjLUqcrXPS > 0; yIJDpxjLUqcrXPS--) {
            WmBSXPyppXAT += WmBSXPyppXAT;
            WmBSXPyppXAT = WmBSXPyppXAT;
            WmBSXPyppXAT = HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp /= HnvHjbDROMQxYxsp;
            WmBSXPyppXAT /= WmBSXPyppXAT;
            HnvHjbDROMQxYxsp = WmBSXPyppXAT;
        }
    }

    if (HnvHjbDROMQxYxsp > 58693237) {
        for (int vOufYDuug = 1554507740; vOufYDuug > 0; vOufYDuug--) {
            HnvHjbDROMQxYxsp += HnvHjbDROMQxYxsp;
            HnvHjbDROMQxYxsp -= WmBSXPyppXAT;
            WmBSXPyppXAT *= WmBSXPyppXAT;
            WmBSXPyppXAT -= HnvHjbDROMQxYxsp;
        }
    }

    return string("WlraHPMeZMFCLxQcxlebOXfEYVafhpvLISBDwbRWvnPZkCOeICzegINCvTtbhKdxfDPhVwwQwSUgtsQjHzYZHSUbdMtUOZszkJDbhJVjqUUsUPiehZPwAxdmNdYpcFPdiSqSzqlGrvyPZuwcQIgkfSYaOEHZzTtAIBBlITLerWWdRrNgEzPofrxjsxQyAMtHDSVEMpnZKGdzpUkNXxEeoeCFFAafg");
}

int ZYnSgvumAJg::ZmJIWNBgjYVCqE(bool clpRbfgJDKDHMR)
{
    string hnXGeeamEH = string("PwSTtFTmI");
    int BFOUNFCA = 1172513867;
    bool AdgSvWClvMaSbC = false;
    double MpcQkqNMpdYLXUmr = 649363.7427775689;
    bool ezzIUkRGVYTNSwjt = true;

    for (int EInWFwYYyPWJOu = 161687400; EInWFwYYyPWJOu > 0; EInWFwYYyPWJOu--) {
        ezzIUkRGVYTNSwjt = ! AdgSvWClvMaSbC;
        clpRbfgJDKDHMR = ezzIUkRGVYTNSwjt;
        BFOUNFCA /= BFOUNFCA;
    }

    for (int lUAQdvOlUAuId = 1289702622; lUAQdvOlUAuId > 0; lUAQdvOlUAuId--) {
        MpcQkqNMpdYLXUmr += MpcQkqNMpdYLXUmr;
    }

    return BFOUNFCA;
}

string ZYnSgvumAJg::fNJHu(double uHvFfnkSisr)
{
    int FYmEbgKyboOMuuME = -1358413993;
    bool HngEpKxuqfGYzwCx = true;
    double Ctqsjk = -195497.5078751771;
    int FhyRH = -5452621;
    bool QsVHnjSOmh = true;
    double yFsYPyopRoVBNKY = 555285.820848188;

    for (int JkElS = 1750278027; JkElS > 0; JkElS--) {
        FYmEbgKyboOMuuME *= FhyRH;
        Ctqsjk += Ctqsjk;
    }

    if (uHvFfnkSisr <= -158986.57056234474) {
        for (int pSaWCbLarMkuEGeR = 1772102820; pSaWCbLarMkuEGeR > 0; pSaWCbLarMkuEGeR--) {
            uHvFfnkSisr *= yFsYPyopRoVBNKY;
            yFsYPyopRoVBNKY += uHvFfnkSisr;
        }
    }

    for (int WSDaLEP = 447166661; WSDaLEP > 0; WSDaLEP--) {
        yFsYPyopRoVBNKY *= Ctqsjk;
        uHvFfnkSisr *= yFsYPyopRoVBNKY;
    }

    return string("yHDWLqloNlmvWajKGMlKQOPTKBGGsLVUhxzUzrIEZSbsZvnBAlCaopsnJHuSOUNuNZsGZzcxiLMxoiHiOppZXzZxXNqGdgxeMBPJExmWDgzgTiemEDgyWjGcyofbjmAfCbhFnKKTqiKbsDPfYLcCMbFcPyIYWQDTKkvCTiAhwvTgQleGBBBpZDOellnRVVhfNIwvKCAcgejNWLijlvXWiDTBOKvd");
}

int ZYnSgvumAJg::tJAYBKPLq()
{
    string udWKX = string("AeRupjRFFHmjLoYuQwAoQdEglcUmNoQKJuJQarzUQaYhMxliKpVgQiWDzlGfjXlFQMpdmeuDqjPNQdYSRKGbZKvVfkHYixJIMkVXKtoBCjVllIGs");
    int EvTCvLBLhu = 2034695827;
    double jiLRXuEthGH = -972081.0244937227;
    string kbmsWzQjvfS = string("EaHPEPMUPNHppcsVKQNcvOHnVFdOFzIOKQjKciPDeDyVrRYjolVdimIeeqyQUqbPAaZDarYmrwVfRzSahcjigncjiOJtxxiYJKNCGzwHcgJFMWJq");
    bool dcvVPsXVMZuLWsLi = false;
    string KNfDToBPhOu = string("XhnSfduwQLGbsIXLrqFqUcRNJDPfpOgHzFhAQiwslNhBjBlJmtZJqOMZPaESeTnFnETGecGSLwjpGaAVLSRSELxVqJfpCsYIGgopQfhmVpbmLaJqFCaznZsrcaxMICtohgjFKvtLpkIBZJVZZiBwMapvlZzAHFJxcFzaAjuCdi");

    if (KNfDToBPhOu >= string("AeRupjRFFHmjLoYuQwAoQdEglcUmNoQKJuJQarzUQaYhMxliKpVgQiWDzlGfjXlFQMpdmeuDqjPNQdYSRKGbZKvVfkHYixJIMkVXKtoBCjVllIGs")) {
        for (int kxowA = 585651965; kxowA > 0; kxowA--) {
            udWKX = KNfDToBPhOu;
            dcvVPsXVMZuLWsLi = ! dcvVPsXVMZuLWsLi;
        }
    }

    return EvTCvLBLhu;
}

int ZYnSgvumAJg::qYquOZ(double OCkAWyvoIpdKV, double JgKEjzcqub, double ESOMWM, int VzwBRiuqgdnkIgIT)
{
    int qZKZgjFkDZfmqU = 2113092656;

    for (int KEgFSzAd = 428413324; KEgFSzAd > 0; KEgFSzAd--) {
        JgKEjzcqub += OCkAWyvoIpdKV;
    }

    for (int AbeQRNhnki = 498352929; AbeQRNhnki > 0; AbeQRNhnki--) {
        JgKEjzcqub *= JgKEjzcqub;
        ESOMWM /= OCkAWyvoIpdKV;
    }

    for (int ptmXHcaG = 580594724; ptmXHcaG > 0; ptmXHcaG--) {
        ESOMWM += OCkAWyvoIpdKV;
        JgKEjzcqub += JgKEjzcqub;
        ESOMWM -= OCkAWyvoIpdKV;
        OCkAWyvoIpdKV = ESOMWM;
        qZKZgjFkDZfmqU /= VzwBRiuqgdnkIgIT;
        JgKEjzcqub *= JgKEjzcqub;
    }

    for (int MTAehKtDHhdy = 532320735; MTAehKtDHhdy > 0; MTAehKtDHhdy--) {
        ESOMWM = ESOMWM;
        OCkAWyvoIpdKV /= OCkAWyvoIpdKV;
        VzwBRiuqgdnkIgIT *= qZKZgjFkDZfmqU;
    }

    return qZKZgjFkDZfmqU;
}

double ZYnSgvumAJg::lKQSBtnNHPbuop()
{
    bool nuxLwgR = true;
    string iSfHDyoILQGDfmXe = string("WVZyFMOdfvkMJiefQdHhWROYKmMpHfsGnJTnAIJuNGYSNSuLUaFyeLwIGNyfzYYbZVbTaVYrvORUaZlZpQUuMBTsEqywAtVXgypWCNORevpAydSZSHDTxCKbxMViIccIvJNhThrFfaHWAPROfxk");
    bool fyzYjqFJ = true;
    bool EpwDoXWmpnAOwFF = false;
    bool sfdJlIwLSlkdAuP = true;

    if (fyzYjqFJ == true) {
        for (int rzrpTXJM = 1551540019; rzrpTXJM > 0; rzrpTXJM--) {
            nuxLwgR = ! nuxLwgR;
            EpwDoXWmpnAOwFF = fyzYjqFJ;
            EpwDoXWmpnAOwFF = EpwDoXWmpnAOwFF;
        }
    }

    return 422045.3851749933;
}

double ZYnSgvumAJg::MyXQHf(string MWJmx, bool bqNeczdkPaquJ, int KrWgFJoKVwKjXnQ, int gRRHrDEZhUOFY)
{
    int kTEDjqRbxt = -1273908907;
    int eGnuodqVqXGPvY = -65434789;
    double viSsi = 210844.82710707613;
    int cttWRZSHohhjrUXm = -943536586;
    int CTawTiGa = 1485884490;
    double ccPjPbtbWAj = 1013360.5668334506;
    string sTqtfKgLF = string("iZJokaLmYHMbGbuJFPtSbYvGvWTPoKDjOTxPyTTAphsWdrGUDYJRocESwFGHggZtVBMegYSyOlpzmDlhbVdKiWMYmxdoNAwasAgOLaWHrPsGmiRZBTxGPTypwAgtjKHnLZIDUIXayQiCyjXSJtDSydaTQKceYErmDTVXCvQU");
    bool lXXkPLnmlOmVW = true;
    string vjVeQzLoBKGw = string("ToWCYOIlDwEXfOMhdDQEKieZdpswLURaKkLsDndpwaFFlWdOWXxKWAjOvyXKfcUvVyEWTShFlEVZPIsBGJuAUohfrArUxhEPeekOzNFfRHOukRIKJsCKABYtsZwUaARCaMDVxNxKFhJERjBKfmopJgimEEnCMMOQbNIwsTJwoWhSmuLyJiekbMEymZvPtTCNaWUXBPSEyOqUXylaiShvepyy");
    string gcHqds = string("IKJWpsXAisxBkoBGJkhWFEHFBYjEavOpXaCHRFXfFyZfRsFZdWdeNOkuuAaMfkZdWXSKCXztPjXInUTRhkaTKthyEiPDvvsVuJPkZgRDgEzILoQqFCzKxbZQMnJOeKoCLZgoxlKKONAPDALollAcGEQRKiolQeNWFKKgUZCZiCEccdhfLKOgfqxvIrvNJfvikCYywCzPFXqhIEgmTDBdXCdixfwTpHex");

    for (int ASNooobfkglkRzM = 169765422; ASNooobfkglkRzM > 0; ASNooobfkglkRzM--) {
        MWJmx = MWJmx;
        gRRHrDEZhUOFY /= cttWRZSHohhjrUXm;
        vjVeQzLoBKGw += gcHqds;
        eGnuodqVqXGPvY += KrWgFJoKVwKjXnQ;
    }

    return ccPjPbtbWAj;
}

ZYnSgvumAJg::ZYnSgvumAJg()
{
    this->eRWQUldm(-1026927.5222054156, false);
    this->pssfnCvEHm(467370.04527626646, 153569.7647296312, 469287.20498523075, true);
    this->UarzMLwhWNYg(true, string("LKiHxjvaMeIAimJNCXjjNsitPXnfMwFpunGcnldmlYgcDNxrrcNIrfXVDMoZhGwOPOmrXQREGLnSnTnFavwpTKTNSBpZZgmiBFgkZScEMAnyDPbYzhgkBPqbzVkzObnuomcRMRUiLeCiFlXHwADfDESKDWdIVQuweSuGbSJIXbwMWQHDUnJPXxZiwSOL"));
    this->bEBzMOuhRIafTvjU(-1202704389, -1802413618, false);
    this->JmxvtfRFnt(false, true, string("dbMLZhRjJapgbzpsbOZdZoZAlbfkFeLvfjHqYqorvgPpERTRYgBQDqjraMOcmKGBXjXrujoORqYmDuIBcROMxUwpKWNwdolLQHTblzOoGqCtHZPfLAIZetVGhqTXlpUQpSwvsmIZZzQmKySVLjGBupHNaZfrh"), false);
    this->OeMwlTreIcVGJC(1331616031);
    this->ZmJIWNBgjYVCqE(true);
    this->fNJHu(-158986.57056234474);
    this->tJAYBKPLq();
    this->qYquOZ(308110.5239118975, -825063.6604164506, -618061.5795380314, 1317458318);
    this->lKQSBtnNHPbuop();
    this->MyXQHf(string("poYSaaUaunePzmynauCqQ"), false, -946594917, 1385254859);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DGtUt
{
public:
    string KNsfnsJTPMDGNxwu;
    int YOaXSnaDaCILP;
    int JEGkVfZGsHjOeNs;
    string oAerDjPQwWz;

    DGtUt();
    void XoAicBxZRB(int pVUYIHyHDEVRt, string hbEbZfIpQzN, int zDtIIOUhvh, bool euJzkv, bool lBNPcbaFzepZ);
    double wXYcZdzVfxMYbdJ(int HhTHOI, bool uRiwMaNduJc);
protected:
    int BjbtFQdxfipaEuj;
    bool sjkBiV;
    string GYfzTtKoWobRXu;
    string saGzRcQheD;
    int QIgOnwESJbmytdmW;
    string vHAypHmvwJyob;

    string KlWraqHX(int lmVUKyBlUu, double RHvpJpWKC);
    void upLpJvCDM(int gzVAevzVQygfyCY, int DZIcM, int gXXcugiHToQf, bool mnUJN, int VMoWf);
    string gSVLfwmGXHZTAWdE(bool TiBjB, double hQbTuRTkhLYGY, double cDkxcwkctPmxDvCD);
    void ZLiAerOXb(string YrYoeDqbYhUqKf, bool TNUCAnPvxOomfL, double ycTmXZtctGIyPsfF);
    bool MkulRPCeML(bool IiOjLeTLHc, int AiTMUsbzFj, int DSorTfWG);
    double tFoCSw(string aqbRpdknZglF, double PlVaavz, bool XGzMFOqMdvftt, int sSbONCL, string IXamYuMvEl);
    bool wNNAOAm(double oHtEEgbDICN, int BCrcsg);
private:
    string bgKhswenLyBQCgQu;
    double EjjBb;
    double eaWFjYcoYwKCI;

    double iUJLYNQEg();
    double KFWISQmACuUrXUhK();
};

void DGtUt::XoAicBxZRB(int pVUYIHyHDEVRt, string hbEbZfIpQzN, int zDtIIOUhvh, bool euJzkv, bool lBNPcbaFzepZ)
{
    int xfcXzSeHwZRABwh = 124983919;
    int cPRSYqAvcQGp = 1083621443;
    double qAnKZmmsx = -517425.6951394981;
    bool PXXIfVSRADULKdt = false;
    int ZDEaNonv = 596201771;
    double ivvviozquO = 908980.7264916118;
    int cvxCHU = 855945900;

    if (ivvviozquO != 908980.7264916118) {
        for (int PQdTON = 215701212; PQdTON > 0; PQdTON--) {
            ZDEaNonv /= cPRSYqAvcQGp;
            pVUYIHyHDEVRt += xfcXzSeHwZRABwh;
        }
    }

    if (cPRSYqAvcQGp < 1083621443) {
        for (int mYrOV = 109855664; mYrOV > 0; mYrOV--) {
            xfcXzSeHwZRABwh = cPRSYqAvcQGp;
            ivvviozquO /= ivvviozquO;
        }
    }

    for (int UUhyWACedSdi = 1382112637; UUhyWACedSdi > 0; UUhyWACedSdi--) {
        xfcXzSeHwZRABwh = xfcXzSeHwZRABwh;
        qAnKZmmsx = qAnKZmmsx;
        xfcXzSeHwZRABwh += ZDEaNonv;
    }
}

double DGtUt::wXYcZdzVfxMYbdJ(int HhTHOI, bool uRiwMaNduJc)
{
    double SNjJjvQVzsUOtS = -339551.6050378599;
    double RgyXjNnqb = -650979.0086089816;
    double RLcDshoWGw = -502583.46984710987;
    int LRcRHAQ = 144373342;
    bool gRWQLaXePTKXEn = true;
    int oPaJXYBSZKi = 900071830;
    int hrquApInDqBYMwb = -432407902;
    bool pFsszMMkX = false;
    string lgDgruTOlLgv = string("CiAxFakjTJnSNGdqRxbnuVehLuJtAMDojquLFsgkMXHmAXLaRieFrXFGJSVPOhJROGnJAjloIYyDUePjEGQmvQnghApnDJRYTXXQJkRHfmXBGiJFzErSleJerdGyTpAiHaFZGU");

    for (int BlgaSBwYCfcHQke = 2025287785; BlgaSBwYCfcHQke > 0; BlgaSBwYCfcHQke--) {
        continue;
    }

    for (int CwMNICraHuM = 742362837; CwMNICraHuM > 0; CwMNICraHuM--) {
        hrquApInDqBYMwb = LRcRHAQ;
    }

    if (RLcDshoWGw <= -650979.0086089816) {
        for (int mOCifLzoC = 453267363; mOCifLzoC > 0; mOCifLzoC--) {
            continue;
        }
    }

    if (hrquApInDqBYMwb > 144373342) {
        for (int giAmlWmdkQRARsa = 1353253302; giAmlWmdkQRARsa > 0; giAmlWmdkQRARsa--) {
            SNjJjvQVzsUOtS -= RLcDshoWGw;
            hrquApInDqBYMwb -= oPaJXYBSZKi;
            LRcRHAQ = LRcRHAQ;
            HhTHOI -= LRcRHAQ;
        }
    }

    return RLcDshoWGw;
}

string DGtUt::KlWraqHX(int lmVUKyBlUu, double RHvpJpWKC)
{
    double MsToPDzIo = -954690.574103835;
    string yvtjgzDKWwPXm = string("fHIYxTXfQgUybrDYtvRUyeZKIZxKOllpZCUMviClJlerBhrbzJYxGKmBMwzOMKPxmxXwFXLCJZOGBhOleOxbZPHSyOzkWcZOBAC");
    string wbpMXVXipoWjK = string("RyZgDbPVedSiHKjTfKRYnQjknEeXpJBribheZsrXKxCCmGVnhTapKckyKISqrUlwsACENYqkxOnEpkuLDHdaVuOWYRjYQMkPdAxPqmVifprezKCohxWCkmrAHlkGHXslSlDlKdXTfiqXCcDevghWwweKRTePiQBqHeOyQahgEmTgeMKLEUgknAmfPUARDUNXMImMHsmvlpidazYxEAWrenpnNyfrCrgmzpDIyphezuOYUIOJIAy");
    int lMNMlhpTQEMzyNc = -23559588;

    for (int SylxdpAFDKT = 1592937692; SylxdpAFDKT > 0; SylxdpAFDKT--) {
        yvtjgzDKWwPXm += yvtjgzDKWwPXm;
    }

    for (int HlysBhaPEObUfv = 480248900; HlysBhaPEObUfv > 0; HlysBhaPEObUfv--) {
        continue;
    }

    for (int iVmWeFv = 1319130026; iVmWeFv > 0; iVmWeFv--) {
        MsToPDzIo /= MsToPDzIo;
        lMNMlhpTQEMzyNc = lMNMlhpTQEMzyNc;
        yvtjgzDKWwPXm = yvtjgzDKWwPXm;
        lmVUKyBlUu /= lmVUKyBlUu;
    }

    return wbpMXVXipoWjK;
}

void DGtUt::upLpJvCDM(int gzVAevzVQygfyCY, int DZIcM, int gXXcugiHToQf, bool mnUJN, int VMoWf)
{
    int NAzdFDBkArhwFmu = 990881809;
    string cMVrS = string("vzvZmgwvIFBtXzFkVXGyhHHSOjmMrkilISgcQwixiCdbHxFhushjibViOFdGnMhhtNZVgfvNugoEqVFoCgXWjqzyJHikyEnIASWZWeelfwfZlOYfbjPMhJFLSYfHEgwKXaeymgBwlWQbYPAAZZcCbJLPNBFwDPvyL");
    string riHKjCKfT = string("QCdnJrlENqxmLAMaEMJRFkYkkprwvcSLctaqOrxQniUAtfQfLiKBsvZJmAuvlalaDpzmuXKXVwwWjLrrpTVXuZtmXOoQXiboMFvFNSUTsRoPxcfjiLrvOrgzDnMXPgGNJpxGRfSSwMJSPqAiFbPDuqMocHGycZslhiuxoNDOLLWokdWNtOMFUJbOtQHhBuBfTbgxxPxMoGhlTqmqptdCOZoALSYOcVUBJknVHrZTZJUha");
    double DguoxpIbH = 734239.0399628977;
    string jOgJEWDxHwHZg = string("wrXXJucGPDQsJQBlqsxzqebbqinXVFGpkhwCuulskgoXZDcwkLiQynTLMDBKpgGDogIGCHdKLtBEuQsXHEWaJxvSPfwKXGSpVZSIeMqFqAmDdQsxGCpSAsCMcDNpmvHViVWrMqOrPBQxegJTxAeXbyphQkozJpytOqhacDSbnjcMuYjgDkECCtXMGgliOYIwE");

    if (NAzdFDBkArhwFmu == 990881809) {
        for (int AdndKiQUJj = 1858516095; AdndKiQUJj > 0; AdndKiQUJj--) {
            gXXcugiHToQf = gXXcugiHToQf;
            jOgJEWDxHwHZg = riHKjCKfT;
        }
    }
}

string DGtUt::gSVLfwmGXHZTAWdE(bool TiBjB, double hQbTuRTkhLYGY, double cDkxcwkctPmxDvCD)
{
    double gXWNLFQ = 980681.126931309;
    int YUtoLmuPgj = -1249189718;
    string XaPbp = string("SDtehGlXfOsvLdNMAWGgMEITwUwoAgKJRKEuaPNvrJpVQXyIqUmNMySacMbqWUwvkXyGxcVDogNwBsYnPjDooyWNglWrcmYjuewNNPRGpgRHCnPNhnMHIxzffLqwnkzFPUOTsnpVMIyRERFcVwP");
    string GrogtkeUn = string("kdtgBguNsiyySCNuibwmxQMJhHSIHLowJtjIoqGMgQjczsDuHDEyxpzNfHrLNw");
    double NkrQgLClZh = 235082.57123432722;
    string mMHYhLzetYNPV = string("jQFvuNGQhubhKlQwdueQSZZYCHEbVcohFZvDPSmyXSObAKfHspRqTFymRPSjiVULJdxqgTlCZttyKzmmQOHnmNdMoJLtxcJfAzkjJUvrFFcuizlAtpDUfkfImWAMkyOIzGqOUlNvVxiJOyfNQiUnnSoqtj");

    for (int wJMWRhdi = 770515115; wJMWRhdi > 0; wJMWRhdi--) {
        NkrQgLClZh -= gXWNLFQ;
    }

    for (int hzEfn = 562853176; hzEfn > 0; hzEfn--) {
        XaPbp = XaPbp;
    }

    for (int KFkWqtmIV = 262701231; KFkWqtmIV > 0; KFkWqtmIV--) {
        hQbTuRTkhLYGY -= cDkxcwkctPmxDvCD;
        GrogtkeUn = GrogtkeUn;
    }

    for (int eIONGf = 504155159; eIONGf > 0; eIONGf--) {
        TiBjB = TiBjB;
        XaPbp += GrogtkeUn;
    }

    if (gXWNLFQ != 980681.126931309) {
        for (int QtawJpoNHh = 642436161; QtawJpoNHh > 0; QtawJpoNHh--) {
            continue;
        }
    }

    for (int ahmaWLoYZVd = 716545191; ahmaWLoYZVd > 0; ahmaWLoYZVd--) {
        continue;
    }

    for (int XrijNY = 765446680; XrijNY > 0; XrijNY--) {
        cDkxcwkctPmxDvCD += cDkxcwkctPmxDvCD;
        TiBjB = TiBjB;
    }

    return mMHYhLzetYNPV;
}

void DGtUt::ZLiAerOXb(string YrYoeDqbYhUqKf, bool TNUCAnPvxOomfL, double ycTmXZtctGIyPsfF)
{
    string OFRPMlaHDSvwPHrm = string("msoLYneIvSCYnFXwMscQqwnUMdhQKQJxjJKwUHhAPnDlDliKdKSHSXZtxcQaghLgWTYwvmhFVKGchOqG");
    string yRBOs = string("fOjRadytUxEnrUQJDfGeTvRFlzQjDtLcEFEZhHyHcYtlyVGmBLaqCdakJlVXvsAbkWGMzVtWgKYVpOZbAWSFwLIDAvpxkyHtCKFydNQpCdErrVJlNWwudkJoZqnoXWgoHuPlMqSNpfhmeGCdVVfcpZbFpCQtacecDrruuXlUcdMoN");
    double RwQezQDhRddYtFXx = 530618.244951551;
    int flGDRxbDQI = 1157283950;
    double fzdHn = 749023.6441438859;
    int rvAmpxxJTtgcborg = 2097042255;
    int zmmOHAFeiZrtfGcM = -426865737;
    int pNbwBZgDWmQbYwlQ = 1831937831;
    double eVTdPXHDUDXctEo = -960682.8539872144;
    string nGwNVUsCJztO = string("PuHegsIBetkvVmDJkVcOwfurwjDYCUXeGOGdXshmtwtExwOovbvuGNNxzUPqjgEqNhC");

    if (YrYoeDqbYhUqKf > string("fOjRadytUxEnrUQJDfGeTvRFlzQjDtLcEFEZhHyHcYtlyVGmBLaqCdakJlVXvsAbkWGMzVtWgKYVpOZbAWSFwLIDAvpxkyHtCKFydNQpCdErrVJlNWwudkJoZqnoXWgoHuPlMqSNpfhmeGCdVVfcpZbFpCQtacecDrruuXlUcdMoN")) {
        for (int oMbSdQTV = 783464679; oMbSdQTV > 0; oMbSdQTV--) {
            TNUCAnPvxOomfL = TNUCAnPvxOomfL;
        }
    }
}

bool DGtUt::MkulRPCeML(bool IiOjLeTLHc, int AiTMUsbzFj, int DSorTfWG)
{
    string SZohPizQZpB = string("RdyemoJMRePPKttrvFAtEHRCSeKaysoervxmHlPcvYAHjObAUjykLkBauZYOgkvDpvaduWKEUglHunPGCZkQtEnrsqqJRIzzGPjVxnIFobPXOzsXAMUBFYiCWdjHXOZamYwDvwDMSLerjVGjOikOCvCnyWTLwHMjMvthzOAZVfbHaZLlbRHgIPloBUOsYPkzCtlYevLNxhlvKfaxQkp");
    int CtybNvIySsrZYrc = 1258038163;
    bool rBlaaNkxKl = true;
    int jWjnyRbuV = -1250320946;
    double rlSdpYaMAF = 352746.60097398056;
    bool CDBkJGdR = false;
    double GrjYcgoqgkiyAkPB = 441220.4459371158;
    bool Gxmuok = false;

    return Gxmuok;
}

double DGtUt::tFoCSw(string aqbRpdknZglF, double PlVaavz, bool XGzMFOqMdvftt, int sSbONCL, string IXamYuMvEl)
{
    string znmaQMyTZtaU = string("WkgytYrfSRYXWuajUZBzyZOWdczpxZASPcDPmvEvClgsadAjQYoBpMYLwQDegLAsSmxVyaKprsoyIYvzoTwvyvrUIcPPKvqRGXMqeqJcLmNumPrBXwPAsFqdbJOSkNKJA");
    int lHzhCrWqroRwJRO = -2015489094;

    for (int mRDFDEg = 1130740380; mRDFDEg > 0; mRDFDEg--) {
        aqbRpdknZglF += aqbRpdknZglF;
        IXamYuMvEl += aqbRpdknZglF;
    }

    for (int zkwhxNMqmZuH = 790891756; zkwhxNMqmZuH > 0; zkwhxNMqmZuH--) {
        lHzhCrWqroRwJRO = lHzhCrWqroRwJRO;
    }

    if (aqbRpdknZglF <= string("bGOZDQsCHFcuwZJHJSncCAfyAlDALZHJIpxrtjKOCYXMsXIZxyWiuKdQYBfOncJvgjIBLdBiWbhNIXnUyQyFRnkhOIPTynxapRSAYBlqEPvrzIGKlsdQUJHxWacNlRoAQxczVoCVMsSzAiQaQbowFuygFuDRFprJQmvAOBiOZzGiYSliefXtGXTjknCkDnoWYKoxAFBzXvBoFbjYieNUcEuAWUddYbAPiIcuQXjPahHQxVuenhPvMIsqRLSJ")) {
        for (int nKWquHiKy = 681637957; nKWquHiKy > 0; nKWquHiKy--) {
            aqbRpdknZglF += IXamYuMvEl;
            aqbRpdknZglF = IXamYuMvEl;
        }
    }

    if (aqbRpdknZglF < string("bGOZDQsCHFcuwZJHJSncCAfyAlDALZHJIpxrtjKOCYXMsXIZxyWiuKdQYBfOncJvgjIBLdBiWbhNIXnUyQyFRnkhOIPTynxapRSAYBlqEPvrzIGKlsdQUJHxWacNlRoAQxczVoCVMsSzAiQaQbowFuygFuDRFprJQmvAOBiOZzGiYSliefXtGXTjknCkDnoWYKoxAFBzXvBoFbjYieNUcEuAWUddYbAPiIcuQXjPahHQxVuenhPvMIsqRLSJ")) {
        for (int yFNroCHIZOAFAxK = 1757932058; yFNroCHIZOAFAxK > 0; yFNroCHIZOAFAxK--) {
            continue;
        }
    }

    return PlVaavz;
}

bool DGtUt::wNNAOAm(double oHtEEgbDICN, int BCrcsg)
{
    double Zohmh = 581981.8721636719;
    string RAVKhbPMiDGQnAG = string("jELZprLhnGfIw");
    string cbScoRst = string("ifGJwOZFIfCcyOsJzmaOPGcNJEjNneKctNfUEBPCfCIgHtIcJysciRumtXMqgFIKKYUuzILDPWDjnmckeMEeFLcuenhhojTKbMTyjULoFROXrefUemfiLjYbVYgEyRbHYWqmUPkwyWzThLMlhqKMmHSkc");
    bool QoKpxAxKPAnqE = true;
    int gHzSBKKrhdz = -1817669414;

    for (int aTcIToh = 602033368; aTcIToh > 0; aTcIToh--) {
        gHzSBKKrhdz /= gHzSBKKrhdz;
    }

    return QoKpxAxKPAnqE;
}

double DGtUt::iUJLYNQEg()
{
    double Rwsfj = 1035157.4268579452;
    bool fSRBoWNrkGqlDqpb = false;
    bool RmUul = false;
    double WLJbuvHvipcR = 445145.53501235286;
    int pnMzjyTSNq = -356802175;
    int oVgZGq = 1813585185;

    return WLJbuvHvipcR;
}

double DGtUt::KFWISQmACuUrXUhK()
{
    int IrUkmUhYvGsmxSpT = -1375267881;
    double dvDoXYpNi = 402715.6996953213;
    string jTTAgzqaVYoUKky = string("wdPkRueEfiINlMyjnyQgPGjiLzpzHYHnntKLtOTQvrQoYKOgcJlNhgiQVFTcKQnGXNpXbguzHbcHKBqmdhCHFCuKUJSefyHsvgCQSlCrpcixTsYIZcooNzymPWFECCptIbxWgjHCaRswLyXbCFHbFMDAYEzSWRMRbBZFZDEMeKpvTgdvzbajLiHxszNgzHLUpYckUiqXjBDxpeXMFCnhmdDDEFDgYMvsqrKbVzVQlxD");
    int NODwbRIAP = -1148264179;
    int oNlgFFEHSS = -1935356851;
    double bQNIxmIXP = 674251.0812586041;
    bool bNnuUzMOFCaEw = true;
    int cJvkROPvvR = -278762450;
    string ywQTpcGAehHTDtU = string("UfwNBPrHrOtnPNadCtckeWGaeHDCvPtFYFXMyYJoBOaiylucmLlPwFDfhVnxuOKgu");
    double vRlyVbUPreGYvp = -660118.4857681096;

    for (int UjszKQgLna = 1404882350; UjszKQgLna > 0; UjszKQgLna--) {
        oNlgFFEHSS += IrUkmUhYvGsmxSpT;
    }

    for (int YYNKnyBXpEz = 510056241; YYNKnyBXpEz > 0; YYNKnyBXpEz--) {
        continue;
    }

    for (int BoPqQZQE = 1134964909; BoPqQZQE > 0; BoPqQZQE--) {
        dvDoXYpNi /= bQNIxmIXP;
        IrUkmUhYvGsmxSpT += IrUkmUhYvGsmxSpT;
        NODwbRIAP -= NODwbRIAP;
    }

    if (cJvkROPvvR < -1148264179) {
        for (int RIbUansTUVWBMnj = 1450607578; RIbUansTUVWBMnj > 0; RIbUansTUVWBMnj--) {
            vRlyVbUPreGYvp /= bQNIxmIXP;
        }
    }

    return vRlyVbUPreGYvp;
}

DGtUt::DGtUt()
{
    this->XoAicBxZRB(241002386, string("FGmDVOFrDCfxiSCNKlexdSFqnAoZgcnadlEJjkIUkICrAEJeBAvjCoHmaaiHEdGXWSjPxNpzWwUXXXcMWmNFtvwqTNlqQ"), -1796659354, true, false);
    this->wXYcZdzVfxMYbdJ(1537156885, false);
    this->KlWraqHX(2043974062, 802980.8086731302);
    this->upLpJvCDM(-1484537479, -1574329077, 212195631, false, 927779638);
    this->gSVLfwmGXHZTAWdE(true, -1020956.9064254087, -848934.3067497091);
    this->ZLiAerOXb(string("vuhEdjjORJajsMkITGpSopivaKDsfznBuRJEGRPKiEWWBoQNgPGmdIuZpqYDVtnjXEucBo"), false, 378474.2945754806);
    this->MkulRPCeML(true, 2114003927, 502607218);
    this->tFoCSw(string("xzGANeWuFOqAqaGPmLHyeCwBYc"), -34444.176269010844, true, -1111386547, string("bGOZDQsCHFcuwZJHJSncCAfyAlDALZHJIpxrtjKOCYXMsXIZxyWiuKdQYBfOncJvgjIBLdBiWbhNIXnUyQyFRnkhOIPTynxapRSAYBlqEPvrzIGKlsdQUJHxWacNlRoAQxczVoCVMsSzAiQaQbowFuygFuDRFprJQmvAOBiOZzGiYSliefXtGXTjknCkDnoWYKoxAFBzXvBoFbjYieNUcEuAWUddYbAPiIcuQXjPahHQxVuenhPvMIsqRLSJ"));
    this->wNNAOAm(-885518.1488710742, 1233637353);
    this->iUJLYNQEg();
    this->KFWISQmACuUrXUhK();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WwICSEnte
{
public:
    int XiAoAF;
    int NcaerNBvflaGYW;
    int aRANWotIkz;
    double IYzghuFrrO;
    string PApyMdvE;
    double TLGttwYE;

    WwICSEnte();
    bool HFnKkEUCD(double dvRJpH, bool QTCexiLUvEQspLva, double wlUaPwYPWAKrTIfP, int nRaxbt);
    void xCgGDla(double uxEbawncO, string wjrMBzXjsWazInU, double ozXNXoETMWt);
protected:
    string MgPDdniAdSwVXbb;
    string atyGlvcrqlEUUksX;

private:
    double nZqZEyDUuDblIAX;
    string JzLlEAFSei;
    string yddDxtSDm;
    int wgtBtlk;
    int dBRkU;
    double uRoPyHiphQHBVe;

};

bool WwICSEnte::HFnKkEUCD(double dvRJpH, bool QTCexiLUvEQspLva, double wlUaPwYPWAKrTIfP, int nRaxbt)
{
    double rzfJIX = -196016.3963392298;
    double OafTz = -1042928.0688831343;
    int pimHMEUcI = -896370216;
    int RAdPOayRcoeIGQb = -1085954165;
    string yFSqwidqOPJQSz = string("ZBnMsGKnkvWxnVCWgPpKIkOUOGrXtfEnfHdUWysYisNSoGBUDgKKFBxkkZtypEwgMjJwWFsxfdJesTCgcKgqniGaCNOniYahOGhMjcRdWKjUv");
    bool uHQpbFu = true;
    string WLywUbOf = string("nVoWXhfwJunbmWojhgWfsxcDOxEgZHKEiTUZTzRAiaeBylAwohLFUvDiTvrHelwZpqJZQjYJXoQxZtpaJKjumVQAInVQDCTjijPVObqlNfotaOomTJzYzvikWFOgMXPgSGmtMdekdBBIHRgCWzGGtUuIXlDtTmthLFEenECfeVEfYqiAHEzTOrJgob");
    string BPzQJeAVmmYQAmT = string("kCIBvTqpoThWMwEbDolpIAWMTAFinGqNYmgqMNmqEuLwSklqGFHYXjSxSDXmMFpzdVEwtLAhtsFocxOLPwdqhosjsKvXlJpDMVkhakbEQvHExVDflOcoKRUMGkYTpuTjeNTkZzFwjUdUemeTXWVaiMQIqlbGJzxlCWCPWDmteHU");
    string HkWNxUSMolM = string("pdHYLDJCSokcMDJjTFZUpIRfGGRxQFPZvIzRxZNxHjhesPXApydqCLYserrkrsEpbdOwsYHagavuJBNNBhuxUtIZTXFSxXesTuLEGljKiNyGNpfrLMXftIecOuCogXYbZCzldTmYOPoApeOuckKQviAWisFEvtxPxCPUCYFrMlDnBaESbIGtPZSjuqP");

    return uHQpbFu;
}

void WwICSEnte::xCgGDla(double uxEbawncO, string wjrMBzXjsWazInU, double ozXNXoETMWt)
{
    string voqMUIkHxEu = string("ucMLAKBkruUvgRFKxzVIvHKYsDANpCSkaxVxKHADmAjbMVHvqgMcysgImLOqfusrttYlASiftQyJReYpeMkUKHokIUROaGpVixTZBvgYeMHSwpKmXhxwEGeDpfvhHlHAviYbatFmRBiMakkMGIGcNmDnuTRuPVbUnlHWUtIAKZqwkmYKZBCclxzdCMzBjEQrSQNJOtrgiSYtkXGeAynoUrTDakqQa");
}

WwICSEnte::WwICSEnte()
{
    this->HFnKkEUCD(-820063.0028659411, false, -456667.81843863457, 319278404);
    this->xCgGDla(-841021.3678856087, string("CJfmrbBTczqozIDMLySruMntdmPBJYfKIRtbQbdvUStZpFMdOCHjmbpZOkgzrzPezYnDjCFVPNiJuBNAfASxVdyQrFkJocb"), -149489.39081843392);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yASWLtMHOpHLGh
{
public:
    double zoecL;
    int QlUqWPhozYfmWnyF;
    int iZfKjBltsXesg;
    string tCtvLjyzy;
    double JMcKqvVRPAjGF;
    int zcIcZrmJuChK;

    yASWLtMHOpHLGh();
    void cYsSFaTuatPtiV(bool xrsxpPoCOZJgnOC, double rEzKFTKKwHWohjKl, int BPdvRAsD, string iNidVQx, int mqKXNsGCHAFjkmVt);
    void WbtGJwKfLk(int SnqyZHOS, bool lLAhjqMKHEBn);
    bool oKtOcuYW(string AMSgHElL, bool enrDQptWwPSOrm, int GmDRPUEvxtmLBAxw);
    double GemACLuJmGuHDj(bool rgeoqwAFuNb, double SanVpHYEFEmGHL);
protected:
    double QRJaJpz;
    string zDkHmSFUbFeUZ;
    bool nVInUN;
    double TYIfEfHsdjMTcQ;

    bool zRztZtOasZZzhu();
    bool bdpGeUPMMFietv();
private:
    double ZXmdqalHxlLen;
    int KEXjhRHFRR;
    bool EDpQObyDkUPUhXIC;
    bool NwEbuSEyTc;

    int cGNbUyU(double AGGIBaaMRBhhgTS, double Iddaw, double fBObEmYSM, int CMQWltjH, double SXeHYipEFlGbKuS);
    string ZPoKaRYmzZFL(double ZoBJSM, bool pGIEIPumhdd);
    string HBEXdtS(string rMtCVHYZIK);
    bool baUugFaZyGysx();
    bool xRZyyGb(double NuQNBt, string LQwIqPt);
    string ntADUrgQlRQR(bool CoapmCQm, int RoDhJQpFacUmOO, double zarYLxEWHNesPUcN, double jINPqNGI, bool GMULYWvS);
};

void yASWLtMHOpHLGh::cYsSFaTuatPtiV(bool xrsxpPoCOZJgnOC, double rEzKFTKKwHWohjKl, int BPdvRAsD, string iNidVQx, int mqKXNsGCHAFjkmVt)
{
    int asrFPeSAqJZf = 1344636704;
    string jTRLj = string("ZyvJBsWnZWIYnBGjVPELLSYIpoyUXVKeNTgCUzucANrJnqGJwuMwIyHLAgTPbDbTOSqgdTnuklZrbth");
    bool PkDnDkiFtsCfg = false;
    string FAucOsMpMtDjhV = string("dwJaFseyZztlKKmjEwrOmHnjcwphSZSmulVFiXBiDJEFrTSrGVaFIHlcUerRFrBRcPFnDHRrLtzrIdDKztApNJFeXIudgjYUaaLeIVQUdJlahdbexocYGETFGcTVGnX");
    double ZNAAZyftoTQOxBd = 303898.75636404764;
    double sJtaWA = 970545.817082938;
    bool xLOCssF = true;

    for (int NRaFwBl = 1874305577; NRaFwBl > 0; NRaFwBl--) {
        continue;
    }
}

void yASWLtMHOpHLGh::WbtGJwKfLk(int SnqyZHOS, bool lLAhjqMKHEBn)
{
    bool PvhqwcmsoGugMftt = false;
    bool DOMwFDGrJgGz = true;
    double vtDRrBFzgJDSsIM = -374573.3940761077;
    bool VIayjJQ = true;
    bool OcYbr = false;
    bool kwcSDIJGseDzFjaB = false;

    if (kwcSDIJGseDzFjaB == true) {
        for (int PyiZhOr = 998722878; PyiZhOr > 0; PyiZhOr--) {
            lLAhjqMKHEBn = PvhqwcmsoGugMftt;
            PvhqwcmsoGugMftt = DOMwFDGrJgGz;
            DOMwFDGrJgGz = DOMwFDGrJgGz;
            kwcSDIJGseDzFjaB = ! DOMwFDGrJgGz;
            DOMwFDGrJgGz = ! PvhqwcmsoGugMftt;
            VIayjJQ = ! OcYbr;
        }
    }

    if (DOMwFDGrJgGz == true) {
        for (int GFseXeaeGX = 814422230; GFseXeaeGX > 0; GFseXeaeGX--) {
            kwcSDIJGseDzFjaB = VIayjJQ;
            DOMwFDGrJgGz = VIayjJQ;
        }
    }

    if (VIayjJQ != false) {
        for (int urOzsyqHvqT = 1989416119; urOzsyqHvqT > 0; urOzsyqHvqT--) {
            vtDRrBFzgJDSsIM += vtDRrBFzgJDSsIM;
            VIayjJQ = ! PvhqwcmsoGugMftt;
        }
    }

    if (vtDRrBFzgJDSsIM >= -374573.3940761077) {
        for (int lsXcVuFpcALaZNB = 1968870392; lsXcVuFpcALaZNB > 0; lsXcVuFpcALaZNB--) {
            VIayjJQ = lLAhjqMKHEBn;
            PvhqwcmsoGugMftt = ! VIayjJQ;
            PvhqwcmsoGugMftt = VIayjJQ;
            OcYbr = OcYbr;
        }
    }

    for (int tKelwaBKhwPqm = 365144156; tKelwaBKhwPqm > 0; tKelwaBKhwPqm--) {
        PvhqwcmsoGugMftt = ! VIayjJQ;
        lLAhjqMKHEBn = ! PvhqwcmsoGugMftt;
        SnqyZHOS *= SnqyZHOS;
        OcYbr = ! DOMwFDGrJgGz;
        lLAhjqMKHEBn = kwcSDIJGseDzFjaB;
        PvhqwcmsoGugMftt = ! lLAhjqMKHEBn;
        DOMwFDGrJgGz = OcYbr;
        OcYbr = ! kwcSDIJGseDzFjaB;
        VIayjJQ = OcYbr;
    }

    if (PvhqwcmsoGugMftt != false) {
        for (int eLUYvrphHv = 736397080; eLUYvrphHv > 0; eLUYvrphHv--) {
            DOMwFDGrJgGz = ! VIayjJQ;
            DOMwFDGrJgGz = ! OcYbr;
            vtDRrBFzgJDSsIM *= vtDRrBFzgJDSsIM;
        }
    }
}

bool yASWLtMHOpHLGh::oKtOcuYW(string AMSgHElL, bool enrDQptWwPSOrm, int GmDRPUEvxtmLBAxw)
{
    bool xQpabuf = false;
    bool NHNsNGljDoQTMcgZ = false;
    bool ouQqZsXiAa = false;
    double eRCTZhKAyh = 491425.73940188607;
    int gjCzRWKd = 312769998;

    for (int RSWrReHh = 1643086889; RSWrReHh > 0; RSWrReHh--) {
        continue;
    }

    for (int PKcCCzWOSohH = 566567318; PKcCCzWOSohH > 0; PKcCCzWOSohH--) {
        ouQqZsXiAa = ouQqZsXiAa;
    }

    for (int jwDGI = 1342323303; jwDGI > 0; jwDGI--) {
        AMSgHElL += AMSgHElL;
        NHNsNGljDoQTMcgZ = enrDQptWwPSOrm;
        NHNsNGljDoQTMcgZ = ! enrDQptWwPSOrm;
        gjCzRWKd = gjCzRWKd;
    }

    return ouQqZsXiAa;
}

double yASWLtMHOpHLGh::GemACLuJmGuHDj(bool rgeoqwAFuNb, double SanVpHYEFEmGHL)
{
    string qoZeLufSdHDoo = string("VgVGCWDIYJCcXo");
    string AgxsvtTGwzjk = string("zNMyVveQYAPzpHbZRNFjjLZDWarvakJmSOheHukUPyxcDxuozwsPIurwrUjgMhCHtEjnEcnHbVPojfYdBVuMeVHtmdyANMLtEDKZYCkxYpzOojQSrxktnlpdPg");
    string gBSrJFuTTw = string("EVaTSoPamjnmunFMoaYRGfocebArmJkHMtNDPoLUjOVCPzsscxWXoJBzqHXJhRbuqJavXvrpCRxOAYuwARDT");
    bool dHLZORLCnBqXTmSt = false;
    bool LmuXxzbEZE = false;
    int BQzavRzMzDRMRTX = -851729426;
    bool slbjbGZRe = true;
    double gcpZuiDbKG = -97296.2272080259;
    bool gSPcWDjNw = false;

    return gcpZuiDbKG;
}

bool yASWLtMHOpHLGh::zRztZtOasZZzhu()
{
    string GNALnO = string("BdCWYRJHDlwWNSHnvmBWRgtSAIRANifMbkPPudTmdlFsUSjGhSDIaAARiqpqpCrYkYTfiVaaUkviuuvOQqyqLEcgMJHRUwZShpmSnJGyYlcJEKEpXggqBLOFlixYGcAHGnBqSXCJEaNtsmvxStePKQLVdqFoBuaVXuNRZcqBJddwyaIqtHVgCYGGN");
    double ECAJRHeAfsHSwcPM = -152864.0386104469;
    bool SPfuyqHQHSmac = true;
    int moeXMKriMmbd = -1166911054;
    bool JFDRrn = true;

    for (int mUXUgO = 564331413; mUXUgO > 0; mUXUgO--) {
        GNALnO = GNALnO;
    }

    for (int IHeeTsZBa = 750986814; IHeeTsZBa > 0; IHeeTsZBa--) {
        moeXMKriMmbd /= moeXMKriMmbd;
    }

    if (ECAJRHeAfsHSwcPM <= -152864.0386104469) {
        for (int vtTFJQLGas = 1830553158; vtTFJQLGas > 0; vtTFJQLGas--) {
            continue;
        }
    }

    for (int cbrQokdOhhQ = 1702076593; cbrQokdOhhQ > 0; cbrQokdOhhQ--) {
        JFDRrn = ! JFDRrn;
        JFDRrn = ! JFDRrn;
        GNALnO += GNALnO;
        JFDRrn = ! SPfuyqHQHSmac;
    }

    return JFDRrn;
}

bool yASWLtMHOpHLGh::bdpGeUPMMFietv()
{
    bool IbSYVZ = false;
    int FJDdMzmpWkTTgci = 2008616310;

    if (IbSYVZ != false) {
        for (int hvCiPQWHEddhtu = 2138832814; hvCiPQWHEddhtu > 0; hvCiPQWHEddhtu--) {
            IbSYVZ = IbSYVZ;
        }
    }

    for (int ozNVIzwDeP = 218770469; ozNVIzwDeP > 0; ozNVIzwDeP--) {
        IbSYVZ = ! IbSYVZ;
    }

    return IbSYVZ;
}

int yASWLtMHOpHLGh::cGNbUyU(double AGGIBaaMRBhhgTS, double Iddaw, double fBObEmYSM, int CMQWltjH, double SXeHYipEFlGbKuS)
{
    int PnhFZkMo = -980511545;
    string cbaABOejNWX = string("jGtrRhxznAhDESAjNbrRwJcoPyQOztoaJBEZFhgqOlwSnlpSVatjnJRyyusDlSOQuOGvoGCdxBJlcnMfB");
    string QZwBTbu = string("mbEIeVZHDcaXWTBzPZNHPJQNIxfOexxncWBpKJcFbhqVhwcMacAgtddlctbmFkqVNygiHxAVCBDhIHWkYNQLomfDBdnEZtyIAwtDGTfXPuLPpymVXkCcpxfRlUFfxYqc");
    double tbjis = -245988.57897767238;
    int aWyCIVC = -1104362207;
    bool SsnKMUWWKUsl = true;
    int gIqwYf = 257914399;
    int IQFBlNPtDmtutcVN = 1911204061;

    if (CMQWltjH == -1104362207) {
        for (int YAtFWV = 1945721517; YAtFWV > 0; YAtFWV--) {
            continue;
        }
    }

    if (aWyCIVC >= 1911204061) {
        for (int HkbIbgnGwon = 864800437; HkbIbgnGwon > 0; HkbIbgnGwon--) {
            QZwBTbu += QZwBTbu;
            fBObEmYSM /= AGGIBaaMRBhhgTS;
            CMQWltjH += CMQWltjH;
        }
    }

    return IQFBlNPtDmtutcVN;
}

string yASWLtMHOpHLGh::ZPoKaRYmzZFL(double ZoBJSM, bool pGIEIPumhdd)
{
    string peHbLWqJuNcYHpZa = string("RvhucKDSrgrTwUTYPdTQuSCLddBNRBVTZWPtuFYoqrgYgWwqTpoMSFkZUfWHHkirmNHkgykNlAEHJSgGldcDJbQXcWmBryVnGEqYiGhWSfchdQFnCzwKtaKrFIOdHEBGUULsxCPRkAZnqYFZVZDdeYa");
    string GmYGtEFX = string("xgIzFhbeIrDFRllSzoSMfiaowKZFAjWblmaISfdUfgxIyDhEEKrwUNKftomZPOhbfikWMLCSulzHRzLJFezyaNfSwCoGAJYrAOZrXBMXOlLLxtkeTkVxyNsCIDvmqwqGYYJENLwHkDYLpyiksfvspVtYjgwkMoJAgxWukAvuhqFCnhBqrEyOfvrXEQGlxEucykAXhJzmUBJfWvoYlpXTGlwYXFdh");

    for (int lAcGcSWasQ = 1362291402; lAcGcSWasQ > 0; lAcGcSWasQ--) {
        GmYGtEFX += GmYGtEFX;
        GmYGtEFX += peHbLWqJuNcYHpZa;
    }

    for (int cmqwJSthMpznPPn = 701276700; cmqwJSthMpznPPn > 0; cmqwJSthMpznPPn--) {
        continue;
    }

    for (int IYbOSVKwPpuGTHn = 937491675; IYbOSVKwPpuGTHn > 0; IYbOSVKwPpuGTHn--) {
        GmYGtEFX = GmYGtEFX;
        GmYGtEFX += GmYGtEFX;
        peHbLWqJuNcYHpZa = peHbLWqJuNcYHpZa;
        GmYGtEFX += GmYGtEFX;
    }

    for (int VoDTvZ = 1519037696; VoDTvZ > 0; VoDTvZ--) {
        peHbLWqJuNcYHpZa = GmYGtEFX;
        peHbLWqJuNcYHpZa = GmYGtEFX;
    }

    if (peHbLWqJuNcYHpZa < string("xgIzFhbeIrDFRllSzoSMfiaowKZFAjWblmaISfdUfgxIyDhEEKrwUNKftomZPOhbfikWMLCSulzHRzLJFezyaNfSwCoGAJYrAOZrXBMXOlLLxtkeTkVxyNsCIDvmqwqGYYJENLwHkDYLpyiksfvspVtYjgwkMoJAgxWukAvuhqFCnhBqrEyOfvrXEQGlxEucykAXhJzmUBJfWvoYlpXTGlwYXFdh")) {
        for (int azPAB = 1858295365; azPAB > 0; azPAB--) {
            GmYGtEFX = GmYGtEFX;
        }
    }

    return GmYGtEFX;
}

string yASWLtMHOpHLGh::HBEXdtS(string rMtCVHYZIK)
{
    bool dJEhQgrhww = true;
    double WzPArcYVKQ = 487758.99722052296;

    for (int CypCQp = 1524775593; CypCQp > 0; CypCQp--) {
        dJEhQgrhww = ! dJEhQgrhww;
        dJEhQgrhww = ! dJEhQgrhww;
        WzPArcYVKQ *= WzPArcYVKQ;
    }

    for (int tHUXhYjYiM = 790271733; tHUXhYjYiM > 0; tHUXhYjYiM--) {
        continue;
    }

    return rMtCVHYZIK;
}

bool yASWLtMHOpHLGh::baUugFaZyGysx()
{
    int cdmhBxbvEGoW = -46719129;
    int NejqlMUCasv = 197687829;
    bool bsxckhCsHsqR = true;
    double kFInHLUgNoIC = -240875.14448855747;
    double yoPsIKN = 494450.9571324405;
    string mZXXczFmPk = string("mtJdGwNINSzLgTkSEolbtYUiJnvWQXgMKfYRblFgCasqbpCIcFqUBBzeNeUfBpEffPnzHokDFCgZVoLdfMbFcVeBPcQzBHTDLqOTTCLKoCROKuMAAyHYm");
    int mrGRYSdMTIynJDB = 2074795629;
    int YATcn = -88087317;
    double yZVIjoVtoZXRTW = -985226.5332298392;

    for (int fgAitmx = 1276823892; fgAitmx > 0; fgAitmx--) {
        NejqlMUCasv /= cdmhBxbvEGoW;
        mrGRYSdMTIynJDB /= YATcn;
    }

    for (int UAujRNgMMyzdDVbD = 2081942829; UAujRNgMMyzdDVbD > 0; UAujRNgMMyzdDVbD--) {
        yZVIjoVtoZXRTW = yoPsIKN;
        NejqlMUCasv += mrGRYSdMTIynJDB;
    }

    if (NejqlMUCasv != 197687829) {
        for (int fiBrUNTFtMo = 2079822755; fiBrUNTFtMo > 0; fiBrUNTFtMo--) {
            mrGRYSdMTIynJDB = NejqlMUCasv;
        }
    }

    for (int LZPDnhjHZthz = 1988847154; LZPDnhjHZthz > 0; LZPDnhjHZthz--) {
        continue;
    }

    return bsxckhCsHsqR;
}

bool yASWLtMHOpHLGh::xRZyyGb(double NuQNBt, string LQwIqPt)
{
    double AFaBuqrb = -314398.63404318265;
    int zwSuH = 989669127;
    bool baVimHKBYWAdVvgd = true;
    int rtIOMtpFPGLLO = 261153502;
    int EenDjJKd = -594257183;
    double JLDFm = -410961.10629449534;
    int HvGqfx = -21223353;
    string KXZIlgR = string("zPfNoVcPAdfeiuxWZHPqOvZXcsSEAkYJWZqrTiyfxFSshADxGPfVgWprQZTWDIaASsGFOsMSydzvmgUflzqJVQMwVlgnZCYbcUVzjpQozfIggJPFqYiMyoTHAzmxIeRZXqwvXrjB");

    for (int LtMUYH = 573521055; LtMUYH > 0; LtMUYH--) {
        zwSuH += zwSuH;
    }

    for (int ncAPWboubekZuN = 697154636; ncAPWboubekZuN > 0; ncAPWboubekZuN--) {
        rtIOMtpFPGLLO = HvGqfx;
        HvGqfx /= zwSuH;
        rtIOMtpFPGLLO += rtIOMtpFPGLLO;
    }

    for (int PXVQxxbYHPKZ = 99533597; PXVQxxbYHPKZ > 0; PXVQxxbYHPKZ--) {
        rtIOMtpFPGLLO /= EenDjJKd;
    }

    for (int gGmUExB = 1814914311; gGmUExB > 0; gGmUExB--) {
        LQwIqPt += LQwIqPt;
        NuQNBt += JLDFm;
        KXZIlgR = LQwIqPt;
    }

    if (LQwIqPt <= string("zPfNoVcPAdfeiuxWZHPqOvZXcsSEAkYJWZqrTiyfxFSshADxGPfVgWprQZTWDIaASsGFOsMSydzvmgUflzqJVQMwVlgnZCYbcUVzjpQozfIggJPFqYiMyoTHAzmxIeRZXqwvXrjB")) {
        for (int oGnUXQNkFzX = 2147462520; oGnUXQNkFzX > 0; oGnUXQNkFzX--) {
            EenDjJKd *= rtIOMtpFPGLLO;
            EenDjJKd -= EenDjJKd;
            rtIOMtpFPGLLO -= rtIOMtpFPGLLO;
            HvGqfx = EenDjJKd;
            rtIOMtpFPGLLO -= rtIOMtpFPGLLO;
        }
    }

    return baVimHKBYWAdVvgd;
}

string yASWLtMHOpHLGh::ntADUrgQlRQR(bool CoapmCQm, int RoDhJQpFacUmOO, double zarYLxEWHNesPUcN, double jINPqNGI, bool GMULYWvS)
{
    string SuaQPrZFXMok = string("mhrQomYwLMeGmPaDaCqyCZrubaHRhLSooGbyNwzuUDtufzrzJTNNdzVbZhLrjDniuFRmGYpOUaRFjzOXjSrFldSIWVggfYnYCTjpIGFOzDARGkHUIcjAnDAAUuqfxRSmxCodqqKMBHPXvejukCnBVHqrPYGSjWVBAFlnIEIZSxvrSjoBpFKxRgYRkgznWKUCXHSEbowqgnfizqCyNJlSkcTqmVfTfZQxryKFDGNFYAxlSvBlZlQDKOfARLsggXq");

    for (int zjdRDjZsS = 1921436132; zjdRDjZsS > 0; zjdRDjZsS--) {
        jINPqNGI = jINPqNGI;
    }

    return SuaQPrZFXMok;
}

yASWLtMHOpHLGh::yASWLtMHOpHLGh()
{
    this->cYsSFaTuatPtiV(false, -280346.3235276, -1905530947, string("RCUAOlwMMbGoFmSbYLcAPIYKedHjzfIwWBJQcHgjDauEXsBRaXNk"), 1923237244);
    this->WbtGJwKfLk(-1152246503, true);
    this->oKtOcuYW(string("LOuSvuTMAaIwxYqBYfAowWiSDsNGZWPFpSUtvxudiGfFfKeGuarWvexCuUfNsfsDIgbczEMtOUXkqQnJBud"), false, 1072687600);
    this->GemACLuJmGuHDj(false, 430472.29903276986);
    this->zRztZtOasZZzhu();
    this->bdpGeUPMMFietv();
    this->cGNbUyU(336835.28719024145, 1032763.4175649626, 851424.6652696169, 1035919272, 977909.8937991571);
    this->ZPoKaRYmzZFL(-250478.0471841217, true);
    this->HBEXdtS(string("yqMJsrkgRjHCzwXAhHJvJJjUiYvyvpjtJwIOLAjYyrJnWuhLbZvMmSfVeZrwHjVYQIxvQRLIAwhRDQsRxmXsajrNZRApNfcYqaMPgZVFQbDORONghwFEjPbVbULtnw"));
    this->baUugFaZyGysx();
    this->xRZyyGb(579744.92347389, string("dxuPDvKjVcKd"));
    this->ntADUrgQlRQR(false, -555392641, 833851.9045345851, 154063.08153685037, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YSThalMYuDpXw
{
public:
    string UxrvSJ;
    int peHIuBAZlGCVL;

    YSThalMYuDpXw();
    bool wNGRnmoUCxxWE(bool wzjpSNC, bool FFLgwQZSJFCE, int GEgpDuHoetijZG, int TRfJs);
protected:
    double FhgrERoDznXDq;

    bool RZLlkJEOJwKA();
    bool hYIIlhsufER(double hWKXYGhDXsnnUmn, string IqJEbSCEMybN, string lqWvLZsMY, double cAsDg);
    double QevAWABJNtIG();
    string TEWViCrsuKI();
    string yNYNBDl(int BjbbUHagHXX);
    double qELWIAEzZDqV(bool rZGvIitcyw, int XkfHqxvnKQA, bool iFaEWpSGKE, string rwGiVjsWlnsMZHw, string KBgoY);
    void RxLckn(string QHibMuQFSu, string bpvbHYMXVFXBr);
    void tjQNneN(int nvXKsoqbmjVM, double lQxGocePFW);
private:
    double qpLktrdlpTgaoww;

    int mwSYVlNSB(double UUieUKKOv, string rGLkJDwJY, int aywLYmAtZvubO, double jpOMweIssFaoo);
    int tLhGUVUInexm();
    int RgfvmacGnXooUSdi(double HjcOEiOSlwrXEBDs, double zkzljAZDjGMv);
    string buCZkQBgx(string ZqEsFPcQygTp, string RTfkyQBNM);
    double XVbOj(int gblJMlmzSUvGtFTg, double eoVzuzpNkhlDa, double dsVRQN, bool WOshmXifqFOcM);
    bool CxRYCSIu(bool FZmqksYiFbYh, string xQEcjokPjvkZKmG, double MjQRWmN, string BefbmeYrx);
};

bool YSThalMYuDpXw::wNGRnmoUCxxWE(bool wzjpSNC, bool FFLgwQZSJFCE, int GEgpDuHoetijZG, int TRfJs)
{
    string sQBsKTlMiOQpEoD = string("rURLPwQnfDuASjKVVIQneFYdXBNrJiDXASPDhYmBVMSqghKtOzULPGojdSOsvLXyffHDyOIVyJttMomqjTwBcVsWEXxZUrECdtwlTLoVjdKVZVEDstKPxcrlJd");
    double YHktscsfNiU = -132154.21091878752;

    for (int FYmIXnEuoHZX = 2118404066; FYmIXnEuoHZX > 0; FYmIXnEuoHZX--) {
        continue;
    }

    return FFLgwQZSJFCE;
}

bool YSThalMYuDpXw::RZLlkJEOJwKA()
{
    double QGVpbXI = -266792.67953438306;

    if (QGVpbXI >= -266792.67953438306) {
        for (int rnpabHay = 1252880669; rnpabHay > 0; rnpabHay--) {
            QGVpbXI += QGVpbXI;
        }
    }

    return false;
}

bool YSThalMYuDpXw::hYIIlhsufER(double hWKXYGhDXsnnUmn, string IqJEbSCEMybN, string lqWvLZsMY, double cAsDg)
{
    bool cJWQsbkqSxnx = true;
    bool QRopuxQrWlGEawrH = false;
    string GpBqEXA = string("kRhmSsxcmXKLEziYfsxhrLXVoGaOdEcttcAeJXRdFpmfPKLbEytDSYKQZmeMFVxcuVaJDcMZhGaWUYcfbOZLdwZwphpSKdpXkbbJsVlXgVrWPFKvASuUapjHCZBZXranBXtBOiBjXzHfAxpLKTwcAHPCJEAAOpFzfHHSxZkeGPJJeKIVpRIZlgUjUBNUduWpIVAvwhKxRDyLNqRKcAgRxBVaJkM");
    double rvWLjvXNXd = -691291.381445002;
    string RFgOvc = string("CCZBzsXimMYJSwdaKOoBeDdK");

    for (int KtNUxU = 904196920; KtNUxU > 0; KtNUxU--) {
        GpBqEXA += lqWvLZsMY;
    }

    if (GpBqEXA > string("kRhmSsxcmXKLEziYfsxhrLXVoGaOdEcttcAeJXRdFpmfPKLbEytDSYKQZmeMFVxcuVaJDcMZhGaWUYcfbOZLdwZwphpSKdpXkbbJsVlXgVrWPFKvASuUapjHCZBZXranBXtBOiBjXzHfAxpLKTwcAHPCJEAAOpFzfHHSxZkeGPJJeKIVpRIZlgUjUBNUduWpIVAvwhKxRDyLNqRKcAgRxBVaJkM")) {
        for (int omOFjoZok = 1624992277; omOFjoZok > 0; omOFjoZok--) {
            lqWvLZsMY += GpBqEXA;
            lqWvLZsMY = IqJEbSCEMybN;
            lqWvLZsMY = lqWvLZsMY;
        }
    }

    if (IqJEbSCEMybN > string("kRhmSsxcmXKLEziYfsxhrLXVoGaOdEcttcAeJXRdFpmfPKLbEytDSYKQZmeMFVxcuVaJDcMZhGaWUYcfbOZLdwZwphpSKdpXkbbJsVlXgVrWPFKvASuUapjHCZBZXranBXtBOiBjXzHfAxpLKTwcAHPCJEAAOpFzfHHSxZkeGPJJeKIVpRIZlgUjUBNUduWpIVAvwhKxRDyLNqRKcAgRxBVaJkM")) {
        for (int opyJeATdwjBwdc = 494746857; opyJeATdwjBwdc > 0; opyJeATdwjBwdc--) {
            GpBqEXA = RFgOvc;
            rvWLjvXNXd -= rvWLjvXNXd;
            cAsDg = hWKXYGhDXsnnUmn;
        }
    }

    for (int tiZvnchwiz = 1856988633; tiZvnchwiz > 0; tiZvnchwiz--) {
        lqWvLZsMY = RFgOvc;
    }

    return QRopuxQrWlGEawrH;
}

double YSThalMYuDpXw::QevAWABJNtIG()
{
    int aKmlHn = 1745518783;
    string XmsGpf = string("nAhcyIPsbGbtNvHJJ");
    double CKVQirZXNTLMGE = 501982.77323670354;
    double PXJqeHjg = -373053.5565184328;
    string EybEzouPlCfLVFeQ = string("gBFIZVEsZxYbaEpaSIbRRRSlEFsFwtlxpRsNKsrmKXyskohjfCJzYHqWVwNhEtPRpYNUpMUuJQcQCGefQaYltpcTzjpugzEcpPUYxkeifnvVGSaFqMOCscqzzLBjXBQhWDIjKdgtsHjiXtYmfbEYdCtuODjjgfrphpQxAxybbNMXXlNIOexjzbgoTQZi");
    double VaAZpumIsRMWXvX = -413513.1974204483;

    if (CKVQirZXNTLMGE <= -373053.5565184328) {
        for (int wgsRnpY = 112457223; wgsRnpY > 0; wgsRnpY--) {
            continue;
        }
    }

    for (int oCvBPNbkjoVSlJ = 300438525; oCvBPNbkjoVSlJ > 0; oCvBPNbkjoVSlJ--) {
        XmsGpf += XmsGpf;
        CKVQirZXNTLMGE += CKVQirZXNTLMGE;
    }

    if (CKVQirZXNTLMGE == -373053.5565184328) {
        for (int yJNIqlQIHAGyuYs = 1780533537; yJNIqlQIHAGyuYs > 0; yJNIqlQIHAGyuYs--) {
            VaAZpumIsRMWXvX /= CKVQirZXNTLMGE;
        }
    }

    for (int wJkuIOyjh = 1386355604; wJkuIOyjh > 0; wJkuIOyjh--) {
        PXJqeHjg -= CKVQirZXNTLMGE;
        PXJqeHjg /= CKVQirZXNTLMGE;
    }

    if (VaAZpumIsRMWXvX == 501982.77323670354) {
        for (int gphlmera = 1176271297; gphlmera > 0; gphlmera--) {
            VaAZpumIsRMWXvX = PXJqeHjg;
            PXJqeHjg -= CKVQirZXNTLMGE;
            CKVQirZXNTLMGE *= CKVQirZXNTLMGE;
        }
    }

    return VaAZpumIsRMWXvX;
}

string YSThalMYuDpXw::TEWViCrsuKI()
{
    bool ySyMqofNyTBBlil = true;
    double aJDful = -90696.62211755302;
    bool CytdZqjN = false;
    string wAHpSnUxyHOyML = string("RieThbWxClQXRYJdvEdvpASqnUPgMuFRBNIEUiqiQlPZrfLmVrcsshxKxzlpgNYUUuePrmkGikuTEdCalLoLiKamYMPL");
    int JUkLXpI = -1025723524;
    bool qzqFOOtaO = true;
    int mLvuKFWJut = -883136056;
    double pKObaVs = 520859.1978678852;

    return wAHpSnUxyHOyML;
}

string YSThalMYuDpXw::yNYNBDl(int BjbbUHagHXX)
{
    double XeATCdgQRfGUsM = -1038190.7718616254;
    bool xOctsdSDxSfPp = true;
    bool UHXUWbLYuWi = true;
    bool tzvIOgsTCwlFTFdE = true;
    int LBiptSutBzOeBwt = 636605399;

    if (XeATCdgQRfGUsM == -1038190.7718616254) {
        for (int zixdTZNPNnLNwFI = 871015793; zixdTZNPNnLNwFI > 0; zixdTZNPNnLNwFI--) {
            continue;
        }
    }

    for (int pdIDrPtFXiputQD = 1106141828; pdIDrPtFXiputQD > 0; pdIDrPtFXiputQD--) {
        xOctsdSDxSfPp = UHXUWbLYuWi;
        BjbbUHagHXX += BjbbUHagHXX;
        UHXUWbLYuWi = xOctsdSDxSfPp;
    }

    if (tzvIOgsTCwlFTFdE != true) {
        for (int UIeJsOfx = 819923611; UIeJsOfx > 0; UIeJsOfx--) {
            UHXUWbLYuWi = ! UHXUWbLYuWi;
            tzvIOgsTCwlFTFdE = xOctsdSDxSfPp;
        }
    }

    if (LBiptSutBzOeBwt <= -741918447) {
        for (int iBZmZSq = 859725826; iBZmZSq > 0; iBZmZSq--) {
            LBiptSutBzOeBwt -= BjbbUHagHXX;
            xOctsdSDxSfPp = UHXUWbLYuWi;
            xOctsdSDxSfPp = xOctsdSDxSfPp;
        }
    }

    if (LBiptSutBzOeBwt == 636605399) {
        for (int IJEiw = 1462804519; IJEiw > 0; IJEiw--) {
            continue;
        }
    }

    for (int nYDDxQyTbKbvdLV = 1576692711; nYDDxQyTbKbvdLV > 0; nYDDxQyTbKbvdLV--) {
        continue;
    }

    return string("CcUJcjdlwzLuxakkCJWJcBGcmDjhpDouSyhwQefrdNiZVlSChPrFWAflniPWbzsCpIcoUigiBpLgYUulCAkTGuGuqYuCmKeLbPMLExZehuhYJxQZRRYQtSuPaYkcLYqhPEgWiIeGrarzXQAiesSzndRIFPDCpdtWthzPbUDkqhnidfFTolOkmcgtMdNwUlNaktcdyjsbEjqPfxM");
}

double YSThalMYuDpXw::qELWIAEzZDqV(bool rZGvIitcyw, int XkfHqxvnKQA, bool iFaEWpSGKE, string rwGiVjsWlnsMZHw, string KBgoY)
{
    bool BFEUUivkJJcoA = true;
    int MYUULPcM = -785728903;
    bool reRhHrpC = false;
    string YlRIDjsvMp = string("pTwYmMkAKyKKoBytlxWeAkltbqxZAmpsxWloJAFwpDVngowrXYJzUmiaUOLGUzVGVSFyjOkbdUAPCWOzzWgnHcumCrOtSOypnkBYkwdvzZaqsSFWKfNEydsDzfeeipcNxPLruFzmTKADcjVwHgKdhpqmJUNtZqTCSzWHBSRjlkjhSEmsaNySpKMN");
    string KVnlaZtJJfNQ = string("KDSJBANlThcADtreJTlnf");
    bool DeIShyypsnHr = false;
    bool AGmHP = true;
    string oTuuCKs = string("MwfXNuvWQsIDQUCtararvYgePQYNevKPPlliWiNEEGlkHDRkpWIIwMFNFYLttailtVtWqvFTbjLqiRffPMsYdMUvbNnFOyyCfdwkGLfPkjAoeGvQBpnklnuKSHjjEvqDQJClFEnFduNFTssgGYeMYDEWLbbmrBOXeeHOxFfEOSTBQDhwbjzLbjkIRtpwTygHTWVhyPzHdazuZMYGhmloSmeJIaELitQaxjKxZatiRCVSGcvBnZ");

    if (BFEUUivkJJcoA == false) {
        for (int xwjJlABWbuAo = 1220655490; xwjJlABWbuAo > 0; xwjJlABWbuAo--) {
            AGmHP = ! reRhHrpC;
        }
    }

    if (KVnlaZtJJfNQ > string("pTwYmMkAKyKKoBytlxWeAkltbqxZAmpsxWloJAFwpDVngowrXYJzUmiaUOLGUzVGVSFyjOkbdUAPCWOzzWgnHcumCrOtSOypnkBYkwdvzZaqsSFWKfNEydsDzfeeipcNxPLruFzmTKADcjVwHgKdhpqmJUNtZqTCSzWHBSRjlkjhSEmsaNySpKMN")) {
        for (int lZgjmczS = 578713089; lZgjmczS > 0; lZgjmczS--) {
            BFEUUivkJJcoA = DeIShyypsnHr;
            YlRIDjsvMp += rwGiVjsWlnsMZHw;
            DeIShyypsnHr = rZGvIitcyw;
        }
    }

    for (int KxhbTCepz = 1748331480; KxhbTCepz > 0; KxhbTCepz--) {
        oTuuCKs = oTuuCKs;
        iFaEWpSGKE = ! DeIShyypsnHr;
    }

    return -184041.60355816374;
}

void YSThalMYuDpXw::RxLckn(string QHibMuQFSu, string bpvbHYMXVFXBr)
{
    bool vCipZ = false;
    string lCcvWkrUaz = string("qKwgYJNbEbTfMycerquZZaFKcfiVJzwAccCqKnSYasRevwSPAhvwHyYPglctPemLvkXcaEdQaogEfwMeJHjDETyioCiTvHMqRfWBFlqkjmVcISbr");
    string gFrgycQ = string("NkkVwfGLNUejuKNqHeOJukhjjDbPbtFnWYNzfyxNzTtBBJWAFtxjEorAsIngMGWDDpjRVEAFZJMrRwWTFoTeQoTvh");
    bool hOJoKtjfKZCTd = true;
    bool OQIkj = true;
    bool nAdntcBoZI = true;
    int LdclHBhq = 1525187706;
    double uIkQTRJ = -243466.26226648808;
    int CyUWFsiwYjhhP = -693055417;
    double kuedZKwAuDYr = 928451.122679236;

    if (gFrgycQ == string("qKwgYJNbEbTfMycerquZZaFKcfiVJzwAccCqKnSYasRevwSPAhvwHyYPglctPemLvkXcaEdQaogEfwMeJHjDETyioCiTvHMqRfWBFlqkjmVcISbr")) {
        for (int QFCtaBOsjx = 628738300; QFCtaBOsjx > 0; QFCtaBOsjx--) {
            gFrgycQ = gFrgycQ;
            OQIkj = nAdntcBoZI;
        }
    }
}

void YSThalMYuDpXw::tjQNneN(int nvXKsoqbmjVM, double lQxGocePFW)
{
    double LPemXjtBKZ = 410893.43250213406;
    bool YkfYlsekSWTbUw = true;
    bool cZbusXrfDhJQy = true;

    for (int ZKYypZrhuACQmq = 1122279228; ZKYypZrhuACQmq > 0; ZKYypZrhuACQmq--) {
        LPemXjtBKZ *= LPemXjtBKZ;
        YkfYlsekSWTbUw = cZbusXrfDhJQy;
    }

    for (int YNqvuv = 786734456; YNqvuv > 0; YNqvuv--) {
        nvXKsoqbmjVM -= nvXKsoqbmjVM;
    }

    for (int zisCBvIOciWVS = 193459420; zisCBvIOciWVS > 0; zisCBvIOciWVS--) {
        YkfYlsekSWTbUw = ! cZbusXrfDhJQy;
        cZbusXrfDhJQy = YkfYlsekSWTbUw;
        YkfYlsekSWTbUw = YkfYlsekSWTbUw;
        nvXKsoqbmjVM -= nvXKsoqbmjVM;
    }

    for (int ECsqlvV = 1702977388; ECsqlvV > 0; ECsqlvV--) {
        YkfYlsekSWTbUw = ! YkfYlsekSWTbUw;
        LPemXjtBKZ *= LPemXjtBKZ;
    }

    for (int FZnCppEb = 646373970; FZnCppEb > 0; FZnCppEb--) {
        nvXKsoqbmjVM -= nvXKsoqbmjVM;
        cZbusXrfDhJQy = ! cZbusXrfDhJQy;
        cZbusXrfDhJQy = ! YkfYlsekSWTbUw;
        YkfYlsekSWTbUw = ! YkfYlsekSWTbUw;
    }

    for (int lnoAQLqnkayWTye = 1405074512; lnoAQLqnkayWTye > 0; lnoAQLqnkayWTye--) {
        LPemXjtBKZ = lQxGocePFW;
    }
}

int YSThalMYuDpXw::mwSYVlNSB(double UUieUKKOv, string rGLkJDwJY, int aywLYmAtZvubO, double jpOMweIssFaoo)
{
    int pCZxKiafHpTRsv = -877092722;
    double MBTuXxLIWCxwsFM = 125355.00006635734;
    string RzSzTHVRJSmTkZz = string("ttVsxUZCxQcyZSNMyMObGHJIkMtVMMfaRHDcXEHQZfpFPduI");
    bool qAxLG = false;
    bool CbHEkzSGkgki = false;
    double vzFZLCxUG = 383196.1538867724;
    int kBBaYpIDjzNReXB = 571481716;

    for (int yvbduozI = 1941599057; yvbduozI > 0; yvbduozI--) {
        continue;
    }

    for (int HfuCQ = 179566895; HfuCQ > 0; HfuCQ--) {
        RzSzTHVRJSmTkZz = RzSzTHVRJSmTkZz;
        vzFZLCxUG -= UUieUKKOv;
    }

    for (int sCwPijgsjJO = 433737361; sCwPijgsjJO > 0; sCwPijgsjJO--) {
        CbHEkzSGkgki = ! qAxLG;
        jpOMweIssFaoo = vzFZLCxUG;
    }

    if (CbHEkzSGkgki == false) {
        for (int JEdHBvb = 479721473; JEdHBvb > 0; JEdHBvb--) {
            kBBaYpIDjzNReXB -= aywLYmAtZvubO;
        }
    }

    for (int kpyWwJSdvsuWL = 1529963049; kpyWwJSdvsuWL > 0; kpyWwJSdvsuWL--) {
        continue;
    }

    return kBBaYpIDjzNReXB;
}

int YSThalMYuDpXw::tLhGUVUInexm()
{
    bool PTKkaA = false;
    int WyPuOFBXaTKFJFRZ = 1549081356;
    double GKAcwLwYB = 829427.2283032573;
    double eYTuITFA = 872363.5685283582;
    int qIMvtqOwoMDcUfF = -1352572108;
    int LgpaRFRwhmhLX = 388141618;

    for (int aVecJearhurtro = 442666637; aVecJearhurtro > 0; aVecJearhurtro--) {
        qIMvtqOwoMDcUfF *= LgpaRFRwhmhLX;
        GKAcwLwYB += GKAcwLwYB;
        qIMvtqOwoMDcUfF += WyPuOFBXaTKFJFRZ;
        GKAcwLwYB -= GKAcwLwYB;
    }

    return LgpaRFRwhmhLX;
}

int YSThalMYuDpXw::RgfvmacGnXooUSdi(double HjcOEiOSlwrXEBDs, double zkzljAZDjGMv)
{
    bool epNVU = true;
    int xhuTfTAmzqqnyClN = 381373206;
    double EJoqCeF = -657999.7662090365;
    bool VpngOMmQi = false;
    double kFRJfnsF = 354149.31455330463;
    string rirnBlABoZSEd = string("VnxLsWQtqasxUbtDOTyFBwUPFjNHJtNmKJLFmUevCFBmFaHwEligdkTPwGgHFkjVEONNwmGyFWdNjHSaBqjmqIxbOOc");
    double kQyFa = -468349.21471484395;
    bool cNZnHyFurAHc = true;

    for (int ddiVFAapHKmKB = 884758496; ddiVFAapHKmKB > 0; ddiVFAapHKmKB--) {
        kQyFa *= kQyFa;
        EJoqCeF -= kFRJfnsF;
        HjcOEiOSlwrXEBDs -= kQyFa;
    }

    if (xhuTfTAmzqqnyClN != 381373206) {
        for (int QQNcI = 1513120384; QQNcI > 0; QQNcI--) {
            VpngOMmQi = VpngOMmQi;
            kQyFa /= kQyFa;
            VpngOMmQi = VpngOMmQi;
            VpngOMmQi = epNVU;
        }
    }

    if (kFRJfnsF >= 354149.31455330463) {
        for (int dlRbs = 1514738427; dlRbs > 0; dlRbs--) {
            HjcOEiOSlwrXEBDs *= kQyFa;
            HjcOEiOSlwrXEBDs *= kQyFa;
        }
    }

    for (int axaQuFvl = 657013404; axaQuFvl > 0; axaQuFvl--) {
        EJoqCeF += zkzljAZDjGMv;
    }

    for (int msxugoIjDPlEMp = 2042201955; msxugoIjDPlEMp > 0; msxugoIjDPlEMp--) {
        kQyFa = kFRJfnsF;
        zkzljAZDjGMv *= zkzljAZDjGMv;
    }

    return xhuTfTAmzqqnyClN;
}

string YSThalMYuDpXw::buCZkQBgx(string ZqEsFPcQygTp, string RTfkyQBNM)
{
    bool anjDPKZvsvJEL = false;
    double TkjqZFxBWuP = 988304.5520596768;
    double vRsjohic = -781552.1307154037;
    double rWFSyQMPhwknXe = 763109.770284575;
    int LxWeSdUzd = -356202452;
    int WVqIvYDfs = 1975330030;

    if (TkjqZFxBWuP == 763109.770284575) {
        for (int FlwZknOLrKUKleQ = 1362783316; FlwZknOLrKUKleQ > 0; FlwZknOLrKUKleQ--) {
            RTfkyQBNM += RTfkyQBNM;
        }
    }

    for (int NUPrVvbyX = 8375801; NUPrVvbyX > 0; NUPrVvbyX--) {
        RTfkyQBNM = ZqEsFPcQygTp;
        TkjqZFxBWuP += vRsjohic;
    }

    return RTfkyQBNM;
}

double YSThalMYuDpXw::XVbOj(int gblJMlmzSUvGtFTg, double eoVzuzpNkhlDa, double dsVRQN, bool WOshmXifqFOcM)
{
    string lJODjPgTkXnpUfC = string("NNorrBKXklJpXdlZrnzUIpjfOeUWOrBehMURdGpTBwzkjBsqtoDokLfPGyApaIUvPIhbKOfyeHGaXXoGPefuzbZSzxIevrimdgLKPesyIWTaABoCJdyPQlHggNckGRFAaTZvLRgnBFowYSGYaTUJjOqlOvITuDuIOlTfdRQoiNCCrftNcP");
    bool oVsRTDmdhlPwY = true;
    bool fQWdmQEqYDg = true;
    bool uLPNmfFauRWocip = true;
    bool wDgOzcaJ = true;

    for (int zludRoG = 1127974887; zludRoG > 0; zludRoG--) {
        oVsRTDmdhlPwY = WOshmXifqFOcM;
        fQWdmQEqYDg = ! oVsRTDmdhlPwY;
        WOshmXifqFOcM = ! oVsRTDmdhlPwY;
        dsVRQN /= dsVRQN;
    }

    return dsVRQN;
}

bool YSThalMYuDpXw::CxRYCSIu(bool FZmqksYiFbYh, string xQEcjokPjvkZKmG, double MjQRWmN, string BefbmeYrx)
{
    int COhQpwTcBwnJOKg = 326751793;
    string kVdJAOYFjc = string("gMUkhQjdkRAYGFONXnjPzSBIEpcznMvnFIHRpuQcdcCazGwBMPJwkHhNIaEZXBJVRGioNgvFmpyrYRdHtqXrebOxWDInkcGWbSDNFoAxCDLoWEQmFFIslYbplxMcOZyiFWOUGsmhrwtGRcTvWfXyKPiUAtiVUWwbAauDNjXMcTMSHPZHYqYYIQnASjEBReQLeMIHHNIoWFEgQFNOkJxz");
    int mqBorK = 1050782426;

    for (int kHFITZvNoUIi = 1925097733; kHFITZvNoUIi > 0; kHFITZvNoUIi--) {
        continue;
    }

    if (FZmqksYiFbYh == true) {
        for (int zIFuOJKpIZe = 1933363286; zIFuOJKpIZe > 0; zIFuOJKpIZe--) {
            continue;
        }
    }

    for (int cxYvxP = 1977266715; cxYvxP > 0; cxYvxP--) {
        BefbmeYrx = kVdJAOYFjc;
    }

    for (int dmGqBODJycoS = 1453177424; dmGqBODJycoS > 0; dmGqBODJycoS--) {
        COhQpwTcBwnJOKg = mqBorK;
        BefbmeYrx = kVdJAOYFjc;
        xQEcjokPjvkZKmG = kVdJAOYFjc;
        xQEcjokPjvkZKmG = xQEcjokPjvkZKmG;
    }

    return FZmqksYiFbYh;
}

YSThalMYuDpXw::YSThalMYuDpXw()
{
    this->wNGRnmoUCxxWE(false, true, 1660861052, 1325971114);
    this->RZLlkJEOJwKA();
    this->hYIIlhsufER(-806064.5732011937, string("AtEykUUvZsTBKbtEhOxTloOGjmXEmgNnEaLSJEXlownRtiVxfabyWDJgJDxuPdJZXkjZksYPCLmiFlrtMeYzGmxiyPwPyNHKmLcFpniJeNkdTgQrdFVENGegZCTudQZFTvYTKucvbqoIUquVsIJjPGUdODWmHwgNCdhQCVeTylLNyPwFKyCJoscLbvTPXQwIbStsVeUEPXRdRPIzHosNqSHMzMx"), string("cBdYxxurKpmGgOvKHDtMWlAeIahMQRGpVqBRBaYCQdecsxJHJxskqCCAFcsOIXAjBozeABpseklDcmVKuJvyAhaqMHywxsQbjYsvpTWsfcQpqdZNwyMUobTlPYqWrOfIraTCFlMdlkeJjbXnqiyVheDHrlhjtQQDHtA"), 605620.3340126161);
    this->QevAWABJNtIG();
    this->TEWViCrsuKI();
    this->yNYNBDl(-741918447);
    this->qELWIAEzZDqV(true, -1223103221, false, string("XbmBBkfikkKXEmUOmUNtDnrYHOVBAzsbpsAWASdELkwVXjvGdlhYDgAHUCBmSvzqEowWSuExClKJEcQafWxilXdSAsrDQKCzwxyjnXXJRWNaRUPnuHnwsKApjEOAgurSVpGvqfKwGvAaszWQcofrkCqYhhNBfSWSuRUrEStXwjNDMPlvsWWrucOSeCruVepkKNmPQvRqVwttqMmohZKkUpfWiUkSaLSUcOygtWDggABddaHvajLLazmmmPPaQ"), string("uBImxKFFutXEZkITGErgDxnNqptlSCVPABvAnuFCYLmNkFejPNmDGYCkqHnqBysaIODsysSfJMFffiMMvrfwLojyWlEbECUmsotTWZyh"));
    this->RxLckn(string("rnmpIXcGvHlNPgQzXyhkDeiEVLTlwYUlfazMllWSLXfNhFjHiTSEtoMwQmoCLzYaFHIGOUPOmWFlozRNLdlvKEPPGKSCdGnYuELqTeXQUVchT"), string("bxspCABqInAGSiIvCufSPoSyQJsHSrsQCprchZIxlvgKofzMbnOhuKgAteMuYaLNmIDkmdpopNJDzjEvhRrWaYQRCJFAEWWWFZYWEerKxDQRXGKWfPqnmJOvWihOrzEInwTUqHKAggeUasMrItChkDNdSCp"));
    this->tjQNneN(591083395, 57985.09174026146);
    this->mwSYVlNSB(-679851.8708868672, string("fTABaKryWBxkQCfpqRQkjPlSfCVUGxchZTWbcDzORZGFHpUmvvsHteFnDQbURyexZJlGeJdUdcVGpBU"), -963239785, -605659.9905236347);
    this->tLhGUVUInexm();
    this->RgfvmacGnXooUSdi(-407680.2531632536, 375950.9629500128);
    this->buCZkQBgx(string("lXyhcizrQfXLqVHdtFkmpgwTAvncZULVcRdFtpEFEPDGLoFuuIMTKVbuQZnrwWAkVhxqsnoivHXEROUidPbTMPVJGuEsjrhjqEvMTZEzazofjZyZvMZGmtyxNiwZYVwCsfSkVufCVQVhRPfPJnamVxMhGRLWepvBetMEuArNZtTXLGyclYfzstxUqeSEa"), string("SsCXggBidJsDyFByiulEEEOHgrWpVHyMfFbaDNiQfCBLxHZfzMFBtJRXdvtuEjLfvNajMlNyzBCnpSJqcajEQZszySVYGZYcBmmzrlEjgpdGGiXWzBGOJmBxTGrjjEKlZvDgNfZRClLXTAwLFuCUBgRPzCh"));
    this->XVbOj(-113967091, 958949.7212151454, 872962.3679370866, false);
    this->CxRYCSIu(true, string("nVOVcsBiumQyAAxNswHfgrEHNnYKrpCSjFVmnxtJARKMuvGixxjOGYFVNIPgbgOHIiOAzsPMJJlxdbFVFoODzLIjQCseOqryWEafcCKIePCGXhZnTgcEBIoITtsepuAyCRuoUVnNEljpadmTbUgaTYwzFAUhkkvXyqDVNhfnYDspbwOeRFugtzOweZfLcrY"), 704901.9086028353, string("fIuTKiJLZAsLutdQUrjWQFwpJTTcfHmpdKreNUDPeLUDpqTwtbmQkrbKvpCIhDsODnfnYPbizePfHrxuMtxSWNVCDmisUVystrKkDJxzROHHIDivkcvwuVCMVkQAHwNwqztPWeQXRkbTgyLcAHsoEkwgOjfhjFumoKhywBiHZZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IVQlAMwDtPp
{
public:
    string msvyphDPPbVH;
    string fOHDrtQOuB;
    bool MVsoEGCxMBaVxBt;
    int tDwvYzwI;
    int xGGsCdREiV;
    bool ZJSzgQJchECAx;

    IVQlAMwDtPp();
    double kKhaziQMWpedi();
    int jzcBZRVw(string xkkxhscuKEVgvAF, double UXrMb, bool idQYtLy);
    void yvBVplLZkNGwVyq(double whSzWte, int ZixeEPNWJMjB);
    void kPTAeQQzIFn(bool NDcOTdCWBH, string iERDshAObEpPaN, double RFJdqsUGS);
    void HdoncqbKMdoBRfSl(string QlbaPrgGNzy);
protected:
    double gZJrCE;
    string zkysZXfU;

    double ovLbNvUxJkMfg(int ucbvqAu);
    void RyJcXOSnbajTcWl(string mIeIYwhSJ, double dAKBw);
    string bNfetCZACWKddh(bool kMsyeSDynAFF);
    void RLmsYVILlNfku(double dBOuhqNiDw, string dqcZhlr, string ceKfTSogLSfpy, string mobhhHuSr);
private:
    int gwacAovcjQaB;
    int kamOSDKvyWuS;
    string MBLDTPaNyy;

    bool oOGFmHWU();
    bool JnyDyguUvgUpFtr(bool xdKDuzQdL, double fqjKm, bool eGfgDHUshtnglYNc, string bpGLlQFJrxIiFejV);
    bool YvAnFBuVlsl(bool CeUuibBTd, bool QefmRjWHPPMRGQm, int TWJTfExi, bool NywjzUrTwpeAi, string KtTFXgwvauCR);
    void hodzpp(double WhpOGG, bool ZXVGC, string BvjJIvQNAivk);
    double kTxRWfRcH(string RWGJfmQFbnl);
    bool dJhwX(int MSoMrqazun, string duunNhprGg, double pygNhGSwnh, int SgRkkAus, double hOxXmlQnpcvLn);
    double FKjjcIGPPo(bool xhXQTHrfpLVXzjMe);
};

double IVQlAMwDtPp::kKhaziQMWpedi()
{
    string fFmJCcRdTay = string("olUCpKCjmZOniblHSnRfnNTvUJtxIqwypqgJtVBKKERmCytVvKBHOWJNwIYOYCMEabqLqGCAMVtABHNyfNuqAuMCIswoctJUHXyqNkFFizMqg");
    int OenLYwOiDZoyttN = 170445558;
    bool AHevPbIpZHjHZv = true;
    int AJGtlb = -879256014;
    string oAHxPlZZAEbKx = string("ZibXWKjeqHGaiKXyvgztqToBBBMkBVbhaMKsYRYcliKwWdRmLNyUdsjgoqLEcuQbbFNQAapudPDwNnHOgjCGEYWmlbselzvinGBcJlILDbUZdTCveGvieGRXXCflKeqFgCQlfHtYyMfqZcFtOHRVle");
    double ZgzTrSTozHrqvN = -995265.5364649538;
    double JqbPdJcLPt = -313519.4231069415;
    int jfFOtOl = -103938458;
    double PYtdkaqMLaG = -1015982.2030363455;
    string oPtunnmlz = string("vYEiqYPZBWORoSoeVfFaWDjvMMHKkIKOlzMMDotwpcNwlHOdxXoMfIDCeqXPTkGUVXzEaIwTnbCkTHvEsjPjjqTlvLCHluCxqLSpiVuNynmXKqlQwWUtkOLyNfzLJPFkZIhPshVrXOJggwfnMhYljoyzAaVFIeRUYVUFnMOPqPsfAPKipdKHnis");

    if (OenLYwOiDZoyttN == -103938458) {
        for (int ywJErALixoQMvTyk = 1086587591; ywJErALixoQMvTyk > 0; ywJErALixoQMvTyk--) {
            AJGtlb *= OenLYwOiDZoyttN;
            OenLYwOiDZoyttN += OenLYwOiDZoyttN;
        }
    }

    for (int RRLNNLQI = 461985021; RRLNNLQI > 0; RRLNNLQI--) {
        oAHxPlZZAEbKx = oAHxPlZZAEbKx;
    }

    if (OenLYwOiDZoyttN <= 170445558) {
        for (int sidvApILZsLRCEp = 695403718; sidvApILZsLRCEp > 0; sidvApILZsLRCEp--) {
            jfFOtOl *= AJGtlb;
        }
    }

    for (int OpGrZLQydC = 412255469; OpGrZLQydC > 0; OpGrZLQydC--) {
        jfFOtOl += OenLYwOiDZoyttN;
        PYtdkaqMLaG *= JqbPdJcLPt;
    }

    if (PYtdkaqMLaG == -313519.4231069415) {
        for (int YSBuffF = 1988245306; YSBuffF > 0; YSBuffF--) {
            ZgzTrSTozHrqvN -= JqbPdJcLPt;
            oPtunnmlz += oAHxPlZZAEbKx;
            OenLYwOiDZoyttN *= jfFOtOl;
        }
    }

    for (int HPEzjujtOuWXd = 1044629852; HPEzjujtOuWXd > 0; HPEzjujtOuWXd--) {
        PYtdkaqMLaG = ZgzTrSTozHrqvN;
    }

    return PYtdkaqMLaG;
}

int IVQlAMwDtPp::jzcBZRVw(string xkkxhscuKEVgvAF, double UXrMb, bool idQYtLy)
{
    string zroLSzlzSHckTOFc = string("cPHaSOggRamPArZTaGNfMmBqPCRduVfuXwGYMcgEleRWjjaLJMLltemSwUJiVfdfFPtGPJXUUYZvEhGrXBaGfvkXTNYWiC");
    int RTvwgkNgFOiJs = -897438873;
    string IWJQwEbJmjQOrCZB = string("NFiKfTwpElTBnGwmoOqnWobfKUIupxjqISZtxwGMUepXleDSINpsUIXZQwNfTfJslVODobsibhqbXgiTPtZEaSaGqzQkcYpYplbSmREKrFQbsYkHeEZcCNgnSzfLmJyrBJHjbBAnxqETuusnKYfLhFlXHWoYjsNByMKAvHQdrXmoNu");
    bool JiLOmy = true;
    bool fDoOOTLAY = true;
    bool FcnEcNTUyPKvPZm = false;

    if (idQYtLy == true) {
        for (int WqnzSUDxq = 887685038; WqnzSUDxq > 0; WqnzSUDxq--) {
            fDoOOTLAY = FcnEcNTUyPKvPZm;
            JiLOmy = JiLOmy;
            FcnEcNTUyPKvPZm = ! fDoOOTLAY;
        }
    }

    for (int CnCAfnLybl = 95445556; CnCAfnLybl > 0; CnCAfnLybl--) {
        JiLOmy = JiLOmy;
        xkkxhscuKEVgvAF = zroLSzlzSHckTOFc;
        xkkxhscuKEVgvAF = IWJQwEbJmjQOrCZB;
    }

    return RTvwgkNgFOiJs;
}

void IVQlAMwDtPp::yvBVplLZkNGwVyq(double whSzWte, int ZixeEPNWJMjB)
{
    string nVnFD = string("EAcTHXCLCeChhkHsTVAgaqYOUUBrTlxiyIGhwAWMDmitMdCAVSmLKsikFUdDJxlWTuXfMczpAOstePaCSnCqdwBXCXTltHfZIYFDKulKjiBYeWiZTasVJoKoGeGBqPdrfusKGJgOIuTpTBCJmwPLXpWVpGKFMvlBUlPoxrBIRUUiEHahIZBTVJDNjIEPsHqNTdPiRqJXYuIkeGnYLwyiVziywuJbrEkUJAGQOkpgvIQMPDYQJDwoGxngmbeIS");
    bool OgwAWbVJFw = true;
    string bPgnrmT = string("CkVpVVJitPfgfzzBiyUoUZhrZkIKjOKJzFYrDjVOBOgoEUaJMfIGaLBEZdOJgtOYgISPODVKphmqRllNLdEZHtkUrmFRJvFSFRkKOUafOmGgpCJVAZhJAseyzNAvxARWn");
    bool MTOzQLiBujXUWx = false;
    int lmeMtZHiR = 1702614455;
    string QmlQBbEiHnxphZrW = string("yMGJxgfGuPUZQgJOLbdvVbZsMbCXjHdvxWOxpGRClToTrDrPbbEuNgbbjmauuVwaFaDDYiktcVGWtvcZOfzGbmCBqbstxSFvXYVzCLWphyiHbBDEpqdqQgrXdcBDmXxhnkbwiFr");
    string brMbGqQfSdRpp = string("JnGfTbITHDaQNlQIJWiFxNEaLRlBiOIxkvYnQziJaTnHTiRFEeFMrLOQmfIMgyoZnNTgJgNalVKeMTEfeQuUTzUSfPdUcstRahqYej");
    bool yQygKHeffDEtjB = true;
    double kbzjMTU = -199517.63562825113;

    for (int DueBNsAVXiqLP = 1027984115; DueBNsAVXiqLP > 0; DueBNsAVXiqLP--) {
        MTOzQLiBujXUWx = ! yQygKHeffDEtjB;
        whSzWte = whSzWte;
    }

    for (int LCuzTRjyB = 747047677; LCuzTRjyB > 0; LCuzTRjyB--) {
        nVnFD += brMbGqQfSdRpp;
        yQygKHeffDEtjB = yQygKHeffDEtjB;
    }

    for (int iHtUmtOTbnKzhQCs = 1682383676; iHtUmtOTbnKzhQCs > 0; iHtUmtOTbnKzhQCs--) {
        brMbGqQfSdRpp = bPgnrmT;
    }

    if (QmlQBbEiHnxphZrW >= string("JnGfTbITHDaQNlQIJWiFxNEaLRlBiOIxkvYnQziJaTnHTiRFEeFMrLOQmfIMgyoZnNTgJgNalVKeMTEfeQuUTzUSfPdUcstRahqYej")) {
        for (int DonwzEZScfHgmwz = 1415480213; DonwzEZScfHgmwz > 0; DonwzEZScfHgmwz--) {
            continue;
        }
    }
}

void IVQlAMwDtPp::kPTAeQQzIFn(bool NDcOTdCWBH, string iERDshAObEpPaN, double RFJdqsUGS)
{
    string kwRdB = string("XpyiVcKHBebOIhEjOwkAcXlBprRjjjjRRvDgZEXtodgetNCVLvYvZOnKYCYFPviVBXtjKInfexjnUKheqqDwRLKpZIXBgVxxwBYXLawEKQWFCCIkzAlcKFmHVoJQngRwWDqtfBMlaEqxvRpxNXAgWlPp");
    string SJrcIUH = string("YGjDrBktlFExrIpujHIyrTRnmjJTlLpAfQInRSWmOFWMv");
    double nqaRYSCTRUv = 548060.975942682;
    string RCTKTdZ = string("UQDmlPUZeeadDjgqGADjbZVCMnVetUWmyoZghYZCmAiPjClgljyiLiAgKPrVimhSNjkfhzTZQfFbUZhGldtvVIsXigRqPphDlFAxHrXBueBboNpznDESRwcQSYLCGOMCuczE");

    for (int SqIgRlBWwahYgR = 2013039568; SqIgRlBWwahYgR > 0; SqIgRlBWwahYgR--) {
        kwRdB = SJrcIUH;
        nqaRYSCTRUv += RFJdqsUGS;
    }

    for (int BePlKvvDp = 445920891; BePlKvvDp > 0; BePlKvvDp--) {
        RFJdqsUGS = RFJdqsUGS;
        kwRdB += iERDshAObEpPaN;
    }

    if (RCTKTdZ != string("RbMZHlxTZbzIyTmxqrTbHckWAFMDyUpLh")) {
        for (int yvSTlDmcFNbL = 672899988; yvSTlDmcFNbL > 0; yvSTlDmcFNbL--) {
            SJrcIUH = kwRdB;
        }
    }

    if (kwRdB == string("RbMZHlxTZbzIyTmxqrTbHckWAFMDyUpLh")) {
        for (int SmvGpQEOjFAFHgbZ = 1186955919; SmvGpQEOjFAFHgbZ > 0; SmvGpQEOjFAFHgbZ--) {
            kwRdB += kwRdB;
            kwRdB += SJrcIUH;
            RFJdqsUGS = RFJdqsUGS;
        }
    }

    if (RFJdqsUGS <= 548060.975942682) {
        for (int hyeehyLGv = 1418960118; hyeehyLGv > 0; hyeehyLGv--) {
            RFJdqsUGS /= RFJdqsUGS;
            nqaRYSCTRUv /= RFJdqsUGS;
            iERDshAObEpPaN = RCTKTdZ;
        }
    }

    for (int ueDLnv = 1846494683; ueDLnv > 0; ueDLnv--) {
        iERDshAObEpPaN = kwRdB;
        NDcOTdCWBH = NDcOTdCWBH;
        RCTKTdZ = SJrcIUH;
        SJrcIUH = SJrcIUH;
        RCTKTdZ += kwRdB;
    }
}

void IVQlAMwDtPp::HdoncqbKMdoBRfSl(string QlbaPrgGNzy)
{
    string ixXZeqDjLpTzmJ = string("iludaDeijbgTBBtBoTxQNXIhGRHzCdWHAoxZLZnAAKgqDroSGiPvPwZXGbhSIQPDDwFiUEICmRNfyFpbItVDPCevbkxlTrTbvLsTVmKZNhzlsQrEnJwVXCVfjvAvCVdzqrftRfLUkxbZJbBhLplgSwZ");
    bool VUZpN = true;
    bool rdAezlSYP = true;
    double tMqEFBOGUdNu = -8754.44285364082;

    if (ixXZeqDjLpTzmJ >= string("iludaDeijbgTBBtBoTxQNXIhGRHzCdWHAoxZLZnAAKgqDroSGiPvPwZXGbhSIQPDDwFiUEICmRNfyFpbItVDPCevbkxlTrTbvLsTVmKZNhzlsQrEnJwVXCVfjvAvCVdzqrftRfLUkxbZJbBhLplgSwZ")) {
        for (int qlZouU = 548222030; qlZouU > 0; qlZouU--) {
            tMqEFBOGUdNu = tMqEFBOGUdNu;
            ixXZeqDjLpTzmJ = ixXZeqDjLpTzmJ;
        }
    }

    for (int EfDFXMhCsGpMf = 1356190413; EfDFXMhCsGpMf > 0; EfDFXMhCsGpMf--) {
        continue;
    }
}

double IVQlAMwDtPp::ovLbNvUxJkMfg(int ucbvqAu)
{
    double okXnLRVSHPI = -592664.0995904147;
    int NwxLeSwj = -1318264381;
    string dTrkOZ = string("FIqqqGuhNyUZZPwuFzAuBeCknzGUvAKfsuearhliNvvblwrzSJTyXganlKZHdnGpMWGuAtfJXgjJulftDTfWEYHLCftXJoLVxrCCIDevMXnBJedZjISIkeQXZXgNLMJFTSwYkwxQczkZGiQTcOZLAkmtrQUEyShsVzPxpObzpnjBZGHubcSJSYXGepWIBHfRGWrxboGNAYJntgQhunRebNOsxjbcyayWxRd");
    int ypsLA = 2095150044;
    int rqcbKjWOoeYBn = 2048749674;

    for (int LOECAKPVxFSzSxcT = 157759649; LOECAKPVxFSzSxcT > 0; LOECAKPVxFSzSxcT--) {
        ucbvqAu = ypsLA;
        ucbvqAu -= NwxLeSwj;
        ucbvqAu /= NwxLeSwj;
    }

    if (dTrkOZ <= string("FIqqqGuhNyUZZPwuFzAuBeCknzGUvAKfsuearhliNvvblwrzSJTyXganlKZHdnGpMWGuAtfJXgjJulftDTfWEYHLCftXJoLVxrCCIDevMXnBJedZjISIkeQXZXgNLMJFTSwYkwxQczkZGiQTcOZLAkmtrQUEyShsVzPxpObzpnjBZGHubcSJSYXGepWIBHfRGWrxboGNAYJntgQhunRebNOsxjbcyayWxRd")) {
        for (int OaKPLNDrvv = 1511264454; OaKPLNDrvv > 0; OaKPLNDrvv--) {
            rqcbKjWOoeYBn -= ypsLA;
            ypsLA += ypsLA;
            NwxLeSwj -= ucbvqAu;
        }
    }

    for (int OEEBZttxBirfP = 417231471; OEEBZttxBirfP > 0; OEEBZttxBirfP--) {
        NwxLeSwj = NwxLeSwj;
        NwxLeSwj -= ypsLA;
    }

    if (rqcbKjWOoeYBn <= -1318264381) {
        for (int mkmhcNNOBv = 824793065; mkmhcNNOBv > 0; mkmhcNNOBv--) {
            NwxLeSwj += NwxLeSwj;
            ypsLA /= rqcbKjWOoeYBn;
        }
    }

    if (NwxLeSwj < 2048749674) {
        for (int TBSJUa = 1380281262; TBSJUa > 0; TBSJUa--) {
            rqcbKjWOoeYBn *= NwxLeSwj;
        }
    }

    return okXnLRVSHPI;
}

void IVQlAMwDtPp::RyJcXOSnbajTcWl(string mIeIYwhSJ, double dAKBw)
{
    double YYbPUXjgE = 307930.66624954354;

    for (int tMKFWdrPVj = 1701510925; tMKFWdrPVj > 0; tMKFWdrPVj--) {
        dAKBw -= YYbPUXjgE;
        mIeIYwhSJ += mIeIYwhSJ;
        mIeIYwhSJ += mIeIYwhSJ;
        YYbPUXjgE = dAKBw;
        YYbPUXjgE = YYbPUXjgE;
    }

    for (int rFCzBjhWUtLCVkSd = 965766853; rFCzBjhWUtLCVkSd > 0; rFCzBjhWUtLCVkSd--) {
        mIeIYwhSJ = mIeIYwhSJ;
        YYbPUXjgE -= YYbPUXjgE;
        dAKBw /= YYbPUXjgE;
    }

    if (YYbPUXjgE >= 307930.66624954354) {
        for (int ghDIOMzJT = 1656294012; ghDIOMzJT > 0; ghDIOMzJT--) {
            dAKBw *= YYbPUXjgE;
            dAKBw = dAKBw;
        }
    }

    for (int RppMyzGXBgNFp = 29704200; RppMyzGXBgNFp > 0; RppMyzGXBgNFp--) {
        YYbPUXjgE -= YYbPUXjgE;
    }

    if (YYbPUXjgE < -243730.98701852368) {
        for (int pqXdQNDfGZwknJm = 2026189116; pqXdQNDfGZwknJm > 0; pqXdQNDfGZwknJm--) {
            mIeIYwhSJ = mIeIYwhSJ;
            dAKBw /= dAKBw;
            YYbPUXjgE += YYbPUXjgE;
            mIeIYwhSJ = mIeIYwhSJ;
            dAKBw *= YYbPUXjgE;
        }
    }

    if (YYbPUXjgE <= -243730.98701852368) {
        for (int AaLAkK = 1612714524; AaLAkK > 0; AaLAkK--) {
            YYbPUXjgE = YYbPUXjgE;
            YYbPUXjgE /= dAKBw;
            mIeIYwhSJ += mIeIYwhSJ;
        }
    }
}

string IVQlAMwDtPp::bNfetCZACWKddh(bool kMsyeSDynAFF)
{
    bool KDpYhpyJtR = false;
    int UCqYRZSxiHJEXOj = -804338785;
    double GkkesEeIcjQzlt = 935210.296877275;
    bool ifcjCoqWRdZQyfz = true;
    bool nPYtepXjrdmQ = true;
    string ztSVv = string("gBZBgOIBINPXmeFfLQLYbzobpvaJdvHOlPWbYbUknoCrztCWpM");
    int YChYZO = 1999027557;
    bool VUNUEqjFUKExCsk = false;
    int RFbXEPK = 14352224;

    for (int hYuLL = 1429681967; hYuLL > 0; hYuLL--) {
        GkkesEeIcjQzlt = GkkesEeIcjQzlt;
        ifcjCoqWRdZQyfz = kMsyeSDynAFF;
    }

    if (ztSVv >= string("gBZBgOIBINPXmeFfLQLYbzobpvaJdvHOlPWbYbUknoCrztCWpM")) {
        for (int loPWMkeTdpJ = 215873770; loPWMkeTdpJ > 0; loPWMkeTdpJ--) {
            VUNUEqjFUKExCsk = ! nPYtepXjrdmQ;
            ztSVv += ztSVv;
        }
    }

    return ztSVv;
}

void IVQlAMwDtPp::RLmsYVILlNfku(double dBOuhqNiDw, string dqcZhlr, string ceKfTSogLSfpy, string mobhhHuSr)
{
    double DwXGSaBgMYG = 952353.6286106759;
    int ZAghRyyO = 1463020178;
    int pXAlitXuuwM = -235283636;
    double igeIB = 840092.0775786062;
    double BtwNXbsYZc = -1006680.7309578401;
    string wpnkLLzMKzIr = string("PqRwntDKbXSWpaKURefjmqIVJsazqTFpziYdBVjlPKjkNLuLMXYOYiSyFdnuMAuwmugmYAkCKhtHvjKKoDhmfHMGePlHJDKgwdbilZgXtZjZCezoiogieEKdtKc");
    bool OgMqDIsTs = true;
}

bool IVQlAMwDtPp::oOGFmHWU()
{
    bool KVeIABqg = false;
    bool gJVYNRwtAgkd = true;

    if (KVeIABqg == true) {
        for (int iwSmrgmpsy = 118701407; iwSmrgmpsy > 0; iwSmrgmpsy--) {
            gJVYNRwtAgkd = gJVYNRwtAgkd;
            gJVYNRwtAgkd = gJVYNRwtAgkd;
            KVeIABqg = ! KVeIABqg;
            KVeIABqg = KVeIABqg;
        }
    }

    return gJVYNRwtAgkd;
}

bool IVQlAMwDtPp::JnyDyguUvgUpFtr(bool xdKDuzQdL, double fqjKm, bool eGfgDHUshtnglYNc, string bpGLlQFJrxIiFejV)
{
    string OaNQWEgJqp = string("WoOtMmAIUIFMrUBBUfUOWnCZiPNShfcPntAKXsMaxnxhPHxmdKfEYZsC");
    bool RfDMavXktQBkO = false;
    int UpPjr = -1655269827;
    double KqAQaMtVnqnheMA = -72083.35424673182;

    for (int WIaeRlFpLzNDrAg = 487169348; WIaeRlFpLzNDrAg > 0; WIaeRlFpLzNDrAg--) {
        bpGLlQFJrxIiFejV += bpGLlQFJrxIiFejV;
        OaNQWEgJqp = bpGLlQFJrxIiFejV;
    }

    if (eGfgDHUshtnglYNc != false) {
        for (int PtequqrBBrq = 1058494757; PtequqrBBrq > 0; PtequqrBBrq--) {
            RfDMavXktQBkO = xdKDuzQdL;
        }
    }

    if (fqjKm == 197197.05476368451) {
        for (int NJBYt = 2049905766; NJBYt > 0; NJBYt--) {
            KqAQaMtVnqnheMA = KqAQaMtVnqnheMA;
            eGfgDHUshtnglYNc = eGfgDHUshtnglYNc;
        }
    }

    return RfDMavXktQBkO;
}

bool IVQlAMwDtPp::YvAnFBuVlsl(bool CeUuibBTd, bool QefmRjWHPPMRGQm, int TWJTfExi, bool NywjzUrTwpeAi, string KtTFXgwvauCR)
{
    string balVfdvVOUvynOA = string("GsTmLpoHEkirKxlZoQkkSpfoIQIcnEYxSpCtUQFsNqdJCHAovlAaQwlmkoBAdNEMAyjOqhGAMVbEuSzYrrnlKRXUpwbGTfGatduUytPRpCAnLvfBsfcLheYkmlAoQgMRRoTgDesrLVQuPqHXRneFCyBPFuKdoRPevylSEYFROHQsZkxVKnBKknMzXBnqH");
    double IHZyrTWeRMfPAXr = 390070.1330302169;
    bool KUHvlgwNYhIvzLiM = true;
    bool gcpvwWOmEU = true;
    int uYBUlfD = -308133829;
    int IgZYkMKHfPu = -606808935;
    string IVCroGiXG = string("PfpEOcLVNrmYPLPfpqQZgLfejKuFrDCfVqpOIlHFETIGrLZcnoxVtvllnUQmgSdBAurRxVcXnxIfADQbQCjdzDaCnEUXvEoqURWzCvco");
    double LLERC = -316529.6902721041;

    for (int UpZhyBYmsoPnOa = 1586252664; UpZhyBYmsoPnOa > 0; UpZhyBYmsoPnOa--) {
        balVfdvVOUvynOA = balVfdvVOUvynOA;
        IgZYkMKHfPu -= uYBUlfD;
    }

    return gcpvwWOmEU;
}

void IVQlAMwDtPp::hodzpp(double WhpOGG, bool ZXVGC, string BvjJIvQNAivk)
{
    bool vAjXMv = true;
    int MEhnpeBeN = -1402583588;
    double PqUzlRs = 366985.63729210995;
    double EOPkXwlAwx = 77917.83717408116;
    int kMknwQ = -1849515014;
    int yBAndpMuYYxW = -1389704478;
    int eOEBv = -886041804;
    bool CJlpASGTdQj = true;

    if (EOPkXwlAwx > 77917.83717408116) {
        for (int euGXClp = 1938774411; euGXClp > 0; euGXClp--) {
            ZXVGC = CJlpASGTdQj;
            MEhnpeBeN += kMknwQ;
            kMknwQ -= eOEBv;
            eOEBv -= MEhnpeBeN;
        }
    }

    for (int JdnyO = 1975203215; JdnyO > 0; JdnyO--) {
        continue;
    }
}

double IVQlAMwDtPp::kTxRWfRcH(string RWGJfmQFbnl)
{
    bool NjxocnSzwhDA = true;
    double FQqnfvZnAqkhNW = 907367.4253725659;
    double VhTIsEMwldYbitKj = -840311.0762448021;

    if (VhTIsEMwldYbitKj >= 907367.4253725659) {
        for (int HTiCIZF = 1328656115; HTiCIZF > 0; HTiCIZF--) {
            FQqnfvZnAqkhNW /= FQqnfvZnAqkhNW;
            NjxocnSzwhDA = NjxocnSzwhDA;
            FQqnfvZnAqkhNW = VhTIsEMwldYbitKj;
        }
    }

    if (VhTIsEMwldYbitKj < -840311.0762448021) {
        for (int tLuCJARIblReCrKh = 70136306; tLuCJARIblReCrKh > 0; tLuCJARIblReCrKh--) {
            FQqnfvZnAqkhNW = FQqnfvZnAqkhNW;
            FQqnfvZnAqkhNW /= VhTIsEMwldYbitKj;
            RWGJfmQFbnl += RWGJfmQFbnl;
        }
    }

    for (int ZxxsMPQaNPWaJU = 1376616733; ZxxsMPQaNPWaJU > 0; ZxxsMPQaNPWaJU--) {
        FQqnfvZnAqkhNW -= VhTIsEMwldYbitKj;
    }

    if (NjxocnSzwhDA == true) {
        for (int yMbDmyQSM = 235464194; yMbDmyQSM > 0; yMbDmyQSM--) {
            VhTIsEMwldYbitKj /= FQqnfvZnAqkhNW;
        }
    }

    for (int lWKpnCTIPVC = 619905061; lWKpnCTIPVC > 0; lWKpnCTIPVC--) {
        FQqnfvZnAqkhNW = FQqnfvZnAqkhNW;
    }

    return VhTIsEMwldYbitKj;
}

bool IVQlAMwDtPp::dJhwX(int MSoMrqazun, string duunNhprGg, double pygNhGSwnh, int SgRkkAus, double hOxXmlQnpcvLn)
{
    int PDzdcUMsUwvrjCB = -362395129;
    double GVcUTNuQJmV = -612718.4190774246;
    string nhvEVdn = string("cCLcgcSrJQqwHYbsKrVWIRnqQAtLDExRuYLPMFERkqqNjLEFGufzFnsBLHTiolkZKbCEhvUWhTZAYaiQWzxEVJVUtUCLTRsvrRBjDnVGepBnWSoHRcYJOyKquwoSoOOpRazhhMHjgAnIuFuJomaHzBcRNHgMrgeGDDUDLKuOfpPlEYNrsfWyddEcqOFafHWrRABQPyovMYUWPhrtrFVmRFeqCbrkCMfciFHYP");
    double gaICnl = -832340.5198528299;

    if (nhvEVdn > string("cCLcgcSrJQqwHYbsKrVWIRnqQAtLDExRuYLPMFERkqqNjLEFGufzFnsBLHTiolkZKbCEhvUWhTZAYaiQWzxEVJVUtUCLTRsvrRBjDnVGepBnWSoHRcYJOyKquwoSoOOpRazhhMHjgAnIuFuJomaHzBcRNHgMrgeGDDUDLKuOfpPlEYNrsfWyddEcqOFafHWrRABQPyovMYUWPhrtrFVmRFeqCbrkCMfciFHYP")) {
        for (int SdOupvsz = 1477881262; SdOupvsz > 0; SdOupvsz--) {
            hOxXmlQnpcvLn += pygNhGSwnh;
        }
    }

    return true;
}

double IVQlAMwDtPp::FKjjcIGPPo(bool xhXQTHrfpLVXzjMe)
{
    bool cVNbmCoxuuaraa = false;
    double fZhNRkfAMomnNvC = -985541.105983209;
    bool BnafqbHesAk = false;
    double DigVXskjfH = 540168.6079791511;
    bool nrcRKKvMCoUtSc = false;
    int bQReOcqIDHSJaUvI = -1087470259;
    int mviUywilhsvVzT = 1855747540;
    string duCouLaL = string("XZtCsWOjQYTSYMvuPHoyXtagEwUwRgcbLqddbWKbhFdeymmfkJIclYXQaZmtqdFUlzgJtLWMRWbhEnqmKuWuyv");

    for (int WwXYziJBIuJguUW = 1704952217; WwXYziJBIuJguUW > 0; WwXYziJBIuJguUW--) {
        fZhNRkfAMomnNvC += DigVXskjfH;
    }

    return DigVXskjfH;
}

IVQlAMwDtPp::IVQlAMwDtPp()
{
    this->kKhaziQMWpedi();
    this->jzcBZRVw(string("xDLegiHeIQjvmZDDIJnWwxt"), 602620.1637150428, false);
    this->yvBVplLZkNGwVyq(370530.42815281707, -830040847);
    this->kPTAeQQzIFn(true, string("RbMZHlxTZbzIyTmxqrTbHckWAFMDyUpLh"), -703134.9522766811);
    this->HdoncqbKMdoBRfSl(string("s"));
    this->ovLbNvUxJkMfg(227971576);
    this->RyJcXOSnbajTcWl(string("LaMppYZjKcKNzuTROGydeVHFtdUARsjpRbYLNueBCcQFXDCDrXQKNFzdYwRiVWVQQeDGxMkjheRNDGehAfchdpBKxBzyvtgeQEFhMfDMHkTDUvJXbptsmaPMseGLJvZZXwUIexSIdzrrNTbGBxGNVMjIOehlkOmgVVtcsxikvflQkLVHQPHhxyfryyVXVdLhCWyUVOjuF"), -243730.98701852368);
    this->bNfetCZACWKddh(true);
    this->RLmsYVILlNfku(272182.4226450972, string("YMRLFRaHmLMDnKkugWrZhiltuvUwiuchofwuKHZcjileCOJrQAjgSayEJLdaeUgjbYlqdojoQXbmWBRvipVpfbNvrEUQMrTRxZQrjVttamagxCNbrwjNjTsWsxrgqOGfZMJcSjWeiOWhzSKKmfRmUGlKMckBfWrSffyobtAOOEgmCrsOcxivZQjbSvkqsgxpLABlVT"), string("lyZHWCegIbrVaCTcanLMdmxBBPKMYqpHACqVrkVppPrTUufyTeAAhZqPRZqxkew"), string("HLrKqOcSMokgXNeaYufJWItGfmAfgaeRFhiOnZQxEezWQNPLFypnoLRaaxgrifWlYILGszFSwatroqrtiRBXHHzUwdszploRjNmVFkpgUESMHitjzCpMZQrkrgfjDqETsXP"));
    this->oOGFmHWU();
    this->JnyDyguUvgUpFtr(true, 197197.05476368451, false, string("qwRtJkyrMiDkzdZXnEnImEDFxGXqanHtZYIXpDjigpltJHhwRswgRrOj"));
    this->YvAnFBuVlsl(false, true, 1575140147, false, string("JLWTbrNQLZeVmiydTuZLNMKtmsoSPkGPbgYYOYmrrjEVpVAbUbabjCmNxSOuTpWlzJPrumiIVelIsQtMLEinVav"));
    this->hodzpp(-78059.25267114305, false, string("NDrbOdPgFVIuqjWkpqliQxTBdNdHKSWiGGdesObEfuQSperNVMgQEgDgsAUFEMbJKTMkSPRBEvotkBPWPcOLkAdVmCJLqbCeDPWLHnmfCdwzaZNclQFgAgTRXPRjKwSLVpPbCeqzZbKGQDtJHxncFkdUoxxCUJZOPldYnbtBFtAPfVCLqQUSlcXrbpXGjCc"));
    this->kTxRWfRcH(string("vZcrpaPOtFhXfLeDEtwhItuYOYkJrnHamYRIvFoSZOtGiJRcOWrAjZLZBIVkYINLeojDWanxhlfuQpuYmwfvyaLijGCYtFEBJULXAvBptYsspi"));
    this->dJhwX(-1027814599, string("xWvZwiaYUCTxvlBythrcwSkCaPzQNtAbUUhBchhxNqXjVZuczmPGsdlVyHTqFKFQNqszRVEYUDsmRuINskRZtbVlIArJUd"), -362318.07625380653, 472593399, -311895.1716866716);
    this->FKjjcIGPPo(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IfsfCYI
{
public:
    string sFVKvVpyO;
    bool eKBWhxpjOd;

    IfsfCYI();
    int gJdTxekcqNetnt(int VpiODBfHMdf, bool JwoexKNqSYVGIvX);
    int tnSqkjHHTsk(double XfuHTMWdIN);
    bool oqkIsUAL(double AjJiR, string cWGNztTL, bool GBLHv, bool rDemEhIdMUntV, int GHctzmKUoOWzR);
    string slqxyjZK();
protected:
    int VgGMOuGErfMOfL;
    double UUgWNE;
    bool qzxNGOClbA;

    double PmqYYaUMrlzxRW(string QBZEIXPz);
    string gtgcTSrUMVhh(int rRkJN, bool nwxOa, double jPviS, int zpNfwFjK, bool mAURA);
    int IGPwem(double CePwMUvOUY, string hsKVg, bool yJXFwUPcINrQ, string RXtRZVWq);
    void ZEUsj(string jnOxUjNVHVjta);
    double bdIgMplLYYGvCaB(double XVMAhVBjN, int RnpOtoLVBAX, string rBAkLUr, bool EwhuCm, double HUtieN);
    string bTCbCemzX(int EaApcxXCuRMYEUZB, double fzKfLWSylLuS, int ugpgLJPuKZIzygz, bool kbBNyWjYLkq, bool LuxvFhxFztcXzgnQ);
    string xRzxlGakig();
    double KueXiolCCj(double xTdUMJ, double RLBdhOLvYvkT);
private:
    double XWVlpsjA;
    string MTLlQSeCRaXvKzU;
    double qjrnIfwFzAkNt;
    int RuHjrZS;
    string lAjPNnkzsVVLrRW;

    int EmQYMKFKLAYe(bool ZMKVBhWqPETyQ, bool hKhWEM, string FunRmGHKWwYRZwDJ);
    void sZVoFKyIjToNj(int tNfCVMH, int vFHRDJ);
    double Ybroe(bool jQgvoH, string MqMjszE, bool vurJhuKkblgbd, string ZhPreLQCZKCHGv, string DePoVn);
};

int IfsfCYI::gJdTxekcqNetnt(int VpiODBfHMdf, bool JwoexKNqSYVGIvX)
{
    double eGfiKlwMDFR = -35266.63213080117;
    bool mXophfPFkd = false;
    double vlydlqczdJorlgK = -612520.3591943617;
    double gLvmkxjjoV = -224961.64435387804;
    bool nWeWlcv = true;
    string zpKzMmmcILD = string("mRZTizszeolDtdWACfPvWexNPGJnhjUlVcKUhGoQKcqNXRaYmNDsjiGtvaPGURGPJGbYvIEwjinEoXwxqHqxsbUkeAKxTdxQfdgGQHfgjRgPaanFzLgoTMOHNqFBoUiVUDQaMbgUIyfvfVibzQSAqUKZSSqLwNpJTQmPlQzLMvOrIeVBnSCzzknuKkFX");
    bool ofTxOghpYoxSB = false;
    bool kGafJJMqifVk = true;
    bool UrypPzQR = true;
    bool UAbnHcaWLDI = false;

    for (int WrrOEVYRcoJJKsr = 1676321825; WrrOEVYRcoJJKsr > 0; WrrOEVYRcoJJKsr--) {
        ofTxOghpYoxSB = ! UAbnHcaWLDI;
        mXophfPFkd = ! UAbnHcaWLDI;
        nWeWlcv = UAbnHcaWLDI;
    }

    for (int NunKULPmyI = 609691564; NunKULPmyI > 0; NunKULPmyI--) {
        mXophfPFkd = ! nWeWlcv;
        kGafJJMqifVk = ! JwoexKNqSYVGIvX;
        mXophfPFkd = ! ofTxOghpYoxSB;
        zpKzMmmcILD = zpKzMmmcILD;
    }

    if (eGfiKlwMDFR != -612520.3591943617) {
        for (int QWGgovrHdSm = 875275224; QWGgovrHdSm > 0; QWGgovrHdSm--) {
            nWeWlcv = UAbnHcaWLDI;
            ofTxOghpYoxSB = mXophfPFkd;
            kGafJJMqifVk = ! UAbnHcaWLDI;
            gLvmkxjjoV *= gLvmkxjjoV;
        }
    }

    for (int zwyerFL = 510979437; zwyerFL > 0; zwyerFL--) {
        JwoexKNqSYVGIvX = ! UrypPzQR;
        UrypPzQR = ! JwoexKNqSYVGIvX;
        mXophfPFkd = ! ofTxOghpYoxSB;
        UrypPzQR = kGafJJMqifVk;
    }

    if (UAbnHcaWLDI == true) {
        for (int oqfRzUNBOP = 1403344952; oqfRzUNBOP > 0; oqfRzUNBOP--) {
            gLvmkxjjoV = gLvmkxjjoV;
            JwoexKNqSYVGIvX = UAbnHcaWLDI;
        }
    }

    if (ofTxOghpYoxSB == true) {
        for (int JWNWoVIfcv = 1205661205; JWNWoVIfcv > 0; JWNWoVIfcv--) {
            vlydlqczdJorlgK = vlydlqczdJorlgK;
        }
    }

    return VpiODBfHMdf;
}

int IfsfCYI::tnSqkjHHTsk(double XfuHTMWdIN)
{
    string XeOFeuYIZJJrN = string("hwvSlrpiUKwERITRgDyONsJdSPwwRYydyDdTeaklMztnuLuhQFgSeIceRXcpIHoLFocbEhYIszRWzqSVjzsnGRENAbrqjXEwbyZWfUdofKQpfZpEJVUIgJkqxpjRPhNyCQMhKcgVntpeJMktGfqAlvvvmqfvnnkyRResIUlrRoq");
    double KqcsmoM = -888585.3437281772;
    double UvFYczo = 607863.9219882123;
    double WyDvAbUnvHBuwWlA = -656670.1699504835;
    string OzNvFXQ = string("hbCPZqKADPPBYIgnpQrjGuOqbcHFZHhkQECxEfrGKGRlTNCZMRnqXdDpjEdMsZTDErklNbRglSFWRLEJSmjzlqpJqxZXsJkMBTSHpgJwQuHWQZykAwpKFszTvUsNsxNFTCcdQcoPTgvwePotYchftfXnnEzntroEJveAIzOmYkhGQEzdhJCLdRVVwllohCWGpvMIGzRvBiqfFWWDzIvubLOBfnThRXilpOzLtqNKyc");
    bool igZmFb = true;
    double weXczqhcQHJP = -957990.2463964778;
    int fLyQJNdQUo = -632634981;
    int dJNdfcWRTcSY = -1114150521;

    for (int AuMfJyvCqHR = 889007276; AuMfJyvCqHR > 0; AuMfJyvCqHR--) {
        WyDvAbUnvHBuwWlA /= WyDvAbUnvHBuwWlA;
        XfuHTMWdIN += XfuHTMWdIN;
        fLyQJNdQUo = dJNdfcWRTcSY;
    }

    return dJNdfcWRTcSY;
}

bool IfsfCYI::oqkIsUAL(double AjJiR, string cWGNztTL, bool GBLHv, bool rDemEhIdMUntV, int GHctzmKUoOWzR)
{
    bool WPCtSoxOhYhf = true;
    string MZvLTYGeN = string("uUymhOIigFLzfIOIXWINlwQKPmrSeSplWSbMtFLWSamtWVQDjwquEQXIVvqVQNtgRFyRUTIFpSbhtdsFwwUYlgzsnzzJsQZbnbValOrnP");
    int NdavI = -1593653201;
    double xMQGZwbYOnIdg = 480357.6723758159;
    double MtknWWcNaHWoZiUp = 644403.9183728198;
    double lWsmYnCAn = -49979.19968788341;
    int gdOjHcHPHTYUT = -756992192;
    bool PQeJyFnCHPy = true;
    bool MPAdZgKrlWSe = true;

    for (int kGgAVEqcjdavuVr = 1732643033; kGgAVEqcjdavuVr > 0; kGgAVEqcjdavuVr--) {
        GHctzmKUoOWzR += GHctzmKUoOWzR;
        GHctzmKUoOWzR *= GHctzmKUoOWzR;
    }

    return MPAdZgKrlWSe;
}

string IfsfCYI::slqxyjZK()
{
    bool LWRvgFYYbV = true;
    double eVEhYABBuG = -72782.61109637812;
    bool zhJPRQQEMQOErT = true;
    int DyjpS = -626206970;

    if (LWRvgFYYbV == true) {
        for (int jqEwJRTNkJaQJG = 1914104642; jqEwJRTNkJaQJG > 0; jqEwJRTNkJaQJG--) {
            DyjpS += DyjpS;
            LWRvgFYYbV = LWRvgFYYbV;
        }
    }

    for (int LrItqbhGADm = 583766327; LrItqbhGADm > 0; LrItqbhGADm--) {
        continue;
    }

    for (int sJGPEJIINvgspv = 1804694410; sJGPEJIINvgspv > 0; sJGPEJIINvgspv--) {
        eVEhYABBuG = eVEhYABBuG;
    }

    for (int qdHrnbGXxQKi = 334629395; qdHrnbGXxQKi > 0; qdHrnbGXxQKi--) {
        LWRvgFYYbV = LWRvgFYYbV;
        LWRvgFYYbV = zhJPRQQEMQOErT;
    }

    for (int mhahEqE = 328209892; mhahEqE > 0; mhahEqE--) {
        zhJPRQQEMQOErT = ! zhJPRQQEMQOErT;
        LWRvgFYYbV = ! zhJPRQQEMQOErT;
    }

    for (int EiGWX = 1262943090; EiGWX > 0; EiGWX--) {
        zhJPRQQEMQOErT = ! zhJPRQQEMQOErT;
    }

    return string("GBtNXEsnllBACnokNnZDXYeBtAErEtKAapQvspYBsDAeLCFESsuRjLqkyxkAKQEKJWQiREoVpAwqbsKmFZyholPvfFYfsIqaIpHaZYehrFFTUFmzQoyLKUaCiYXOD");
}

double IfsfCYI::PmqYYaUMrlzxRW(string QBZEIXPz)
{
    double pfweiND = -1002669.4126149039;
    string vFYGtcaWvBqEQqr = string("AruHHZXclEJtqMVAcuaXLuixNBuIpGlKjixmYmdLbzmXyHQljDQGdDQNSWoEwvfylRLHCivWBsxsUskuZSNwDdAlYLJXGfbeuwQHdddySGyR");
    bool LOKTwfMGOycqX = true;
    bool BaflkfnWdzneCU = false;
    int xpMpL = -1649390772;
    double eFTjaMp = -988564.3032233188;
    int kzttEATnOVfJK = 950576060;

    for (int WhLgDUy = 1517692799; WhLgDUy > 0; WhLgDUy--) {
        QBZEIXPz += vFYGtcaWvBqEQqr;
        vFYGtcaWvBqEQqr = QBZEIXPz;
        pfweiND /= eFTjaMp;
    }

    for (int THZeoEyJRExX = 728103426; THZeoEyJRExX > 0; THZeoEyJRExX--) {
        eFTjaMp += eFTjaMp;
    }

    for (int uRCsEAZIyFfn = 273359617; uRCsEAZIyFfn > 0; uRCsEAZIyFfn--) {
        kzttEATnOVfJK += xpMpL;
        LOKTwfMGOycqX = ! BaflkfnWdzneCU;
    }

    for (int jWVAgucPxZkr = 1899997136; jWVAgucPxZkr > 0; jWVAgucPxZkr--) {
        continue;
    }

    return eFTjaMp;
}

string IfsfCYI::gtgcTSrUMVhh(int rRkJN, bool nwxOa, double jPviS, int zpNfwFjK, bool mAURA)
{
    bool fdCnXVU = true;
    int UQvWGVdUhdo = -1872403869;
    bool YvjEiznfYZWyKsR = false;
    string vNXis = string("O");
    double AbTSHV = -787256.487704074;
    int CUYUNUQ = 630276745;
    double gjiNnIhQfFw = 186224.37788742385;
    double AArllHzwY = -608044.4334558661;
    bool jDJAoNoyh = true;
    int gcNjzdZK = 78958908;

    for (int eunAwstYQBdcz = 2034297999; eunAwstYQBdcz > 0; eunAwstYQBdcz--) {
        nwxOa = nwxOa;
    }

    for (int OijcCkHmIyLHDo = 1480112708; OijcCkHmIyLHDo > 0; OijcCkHmIyLHDo--) {
        AbTSHV -= AbTSHV;
    }

    if (gjiNnIhQfFw == -787256.487704074) {
        for (int BzfzNTLIiEb = 661358665; BzfzNTLIiEb > 0; BzfzNTLIiEb--) {
            AbTSHV += AArllHzwY;
        }
    }

    return vNXis;
}

int IfsfCYI::IGPwem(double CePwMUvOUY, string hsKVg, bool yJXFwUPcINrQ, string RXtRZVWq)
{
    double RBRQQsmiMfvWIC = -899461.7207662455;
    int pbIhmNVXYvTf = 1040914410;
    int HiZYR = 736465430;
    string AcHqjkndvU = string("XXtZdpAOeQvsmfafrRvjbKEEbrFdehcxzQZefEWNQhTVJnHymwqwTJASULtfGowOlbdZBPVOXkCqnFLvtuRUFHXuaTy");

    for (int CcwHkEJwGrnBFSRV = 1631351693; CcwHkEJwGrnBFSRV > 0; CcwHkEJwGrnBFSRV--) {
        HiZYR /= HiZYR;
        AcHqjkndvU += AcHqjkndvU;
    }

    for (int hWnXruvgQ = 1746529304; hWnXruvgQ > 0; hWnXruvgQ--) {
        continue;
    }

    return HiZYR;
}

void IfsfCYI::ZEUsj(string jnOxUjNVHVjta)
{
    int wdrYQ = -556172093;
    double SuBWYhw = 903493.5844451018;

    if (jnOxUjNVHVjta <= string("aBvuzkQrLTgjxrPvJhGutIeIgcyBDDWILqzowFAZkCVEkTBJAjmeBAFSDRXhVTuCnIBFFHGTpdTKUmDPbUTOKSYhjPWFSORUkxHbMNDrUJyArzCaXTEloFPUaMNnP")) {
        for (int VxhKHrKppFvax = 1304769821; VxhKHrKppFvax > 0; VxhKHrKppFvax--) {
            wdrYQ += wdrYQ;
        }
    }

    if (wdrYQ <= -556172093) {
        for (int ZIScqwc = 2006340728; ZIScqwc > 0; ZIScqwc--) {
            continue;
        }
    }

    for (int EYsXfsrOw = 1284921569; EYsXfsrOw > 0; EYsXfsrOw--) {
        SuBWYhw -= SuBWYhw;
        jnOxUjNVHVjta = jnOxUjNVHVjta;
    }

    if (wdrYQ != -556172093) {
        for (int yTcJAoaJ = 881545738; yTcJAoaJ > 0; yTcJAoaJ--) {
            wdrYQ /= wdrYQ;
            wdrYQ *= wdrYQ;
        }
    }

    for (int jMdTSXfUuTcaVd = 981496602; jMdTSXfUuTcaVd > 0; jMdTSXfUuTcaVd--) {
        jnOxUjNVHVjta = jnOxUjNVHVjta;
        SuBWYhw *= SuBWYhw;
        wdrYQ *= wdrYQ;
    }

    for (int DcJjOtY = 1556129450; DcJjOtY > 0; DcJjOtY--) {
        wdrYQ -= wdrYQ;
        wdrYQ *= wdrYQ;
        jnOxUjNVHVjta = jnOxUjNVHVjta;
    }

    if (wdrYQ >= -556172093) {
        for (int VNOCIylAwztdc = 1498005405; VNOCIylAwztdc > 0; VNOCIylAwztdc--) {
            wdrYQ -= wdrYQ;
            SuBWYhw += SuBWYhw;
            jnOxUjNVHVjta += jnOxUjNVHVjta;
        }
    }
}

double IfsfCYI::bdIgMplLYYGvCaB(double XVMAhVBjN, int RnpOtoLVBAX, string rBAkLUr, bool EwhuCm, double HUtieN)
{
    string lIvUqwLFOVdyhkW = string("eaxWvaLOxlbquNDxxuhmOqwzKvFHWFBTyIoBRhfdrxCpEhbdXohYDhjNFsguTstcZFTZsfbWuSSLLpnVcPqcTDdcNCUVynqnzdVdhZDRgylgdryYqlfEylPFZGtAZakaaZkeNzVgopZljSAWcxGXgPaxPeGHntaCSJttAfhbkwDcESFLvmrDJeFJYQwWnBeIyfRGpVLCoGGIEryUnxPFBTdYbEtlrd");
    string TdsZxyQdTyWk = string("kRnwxxyWfXPRLqTYvcTXUsJvUePjVxseqppYgXOFCSFcaCtLYTRVyPLmRfOhWFvOBQGZFrUrBNWSeNiRdTVCTPTsJPtbbsIwsNQaPBBXiEscbGMwQpWjlhFYpkVeleWZa");
    string rzOxXNxF = string("HasdYXzThqqnLhLwMFoTYJjYIVQWswdHrEyglmvgX");

    for (int YdeWnijUk = 812837217; YdeWnijUk > 0; YdeWnijUk--) {
        continue;
    }

    if (TdsZxyQdTyWk < string("eaxWvaLOxlbquNDxxuhmOqwzKvFHWFBTyIoBRhfdrxCpEhbdXohYDhjNFsguTstcZFTZsfbWuSSLLpnVcPqcTDdcNCUVynqnzdVdhZDRgylgdryYqlfEylPFZGtAZakaaZkeNzVgopZljSAWcxGXgPaxPeGHntaCSJttAfhbkwDcESFLvmrDJeFJYQwWnBeIyfRGpVLCoGGIEryUnxPFBTdYbEtlrd")) {
        for (int nQvjpDT = 698302116; nQvjpDT > 0; nQvjpDT--) {
            continue;
        }
    }

    return HUtieN;
}

string IfsfCYI::bTCbCemzX(int EaApcxXCuRMYEUZB, double fzKfLWSylLuS, int ugpgLJPuKZIzygz, bool kbBNyWjYLkq, bool LuxvFhxFztcXzgnQ)
{
    bool WhRcLslyDweullee = true;
    string bDvHDTn = string("tKonUxGaCFdFaQxTdXBEZsvzJlbBPJsZvsMXKQVeCuBDhBjbHgSfRadbfgMyRWDgDBasaUMhmFgFKqyOrolkusEstZRSRgGTdgFyhR");
    bool JeOsJLaRqCSdQXX = true;

    for (int XhWuuKprbSHARfCw = 465011660; XhWuuKprbSHARfCw > 0; XhWuuKprbSHARfCw--) {
        ugpgLJPuKZIzygz += EaApcxXCuRMYEUZB;
        fzKfLWSylLuS = fzKfLWSylLuS;
        EaApcxXCuRMYEUZB += ugpgLJPuKZIzygz;
    }

    for (int TcZUS = 896231646; TcZUS > 0; TcZUS--) {
        JeOsJLaRqCSdQXX = ! WhRcLslyDweullee;
        kbBNyWjYLkq = JeOsJLaRqCSdQXX;
        JeOsJLaRqCSdQXX = WhRcLslyDweullee;
        kbBNyWjYLkq = ! JeOsJLaRqCSdQXX;
        kbBNyWjYLkq = ! LuxvFhxFztcXzgnQ;
    }

    for (int zHMSgoLHRmeOv = 1733022975; zHMSgoLHRmeOv > 0; zHMSgoLHRmeOv--) {
        WhRcLslyDweullee = ! WhRcLslyDweullee;
    }

    for (int qboWCmqufXdmC = 806827004; qboWCmqufXdmC > 0; qboWCmqufXdmC--) {
        kbBNyWjYLkq = ! JeOsJLaRqCSdQXX;
    }

    return bDvHDTn;
}

string IfsfCYI::xRzxlGakig()
{
    string QwacJwJII = string("SthkoMQORkAQjTZczynvvgINvpTOLjKjgmwewKUzgDlwUIKhPOcArGDytShIyYmsbwdSiAWQLkCsXQCmVKXHQzSNzhIBcvQ");
    double ifTaVsebnjzleL = -989547.8850092855;
    bool lhQIrX = false;
    string OQBxqiH = string("xIaLlLUUyKrbSrzMxxosFBmwstwllavoEykFuLEgVeyZIDTWcXRnxXJzqZNbvFWfPMYyBuFOazyLptzOrTXpggZYLLnJQEIAhkZsOOHW");
    int jtHfEdZLWCjy = -172666085;

    for (int NTEwgTlaTEJMEO = 1501486442; NTEwgTlaTEJMEO > 0; NTEwgTlaTEJMEO--) {
        QwacJwJII += QwacJwJII;
        ifTaVsebnjzleL = ifTaVsebnjzleL;
        QwacJwJII = QwacJwJII;
    }

    for (int hCmCiACXNzTZP = 409701875; hCmCiACXNzTZP > 0; hCmCiACXNzTZP--) {
        continue;
    }

    return OQBxqiH;
}

double IfsfCYI::KueXiolCCj(double xTdUMJ, double RLBdhOLvYvkT)
{
    double BoMyZux = 534189.7406983475;
    int sasKmYWpAJdLu = 1701237928;
    double sYiSVOzdcQK = 322268.85484419076;
    double hKyPZBlSoCcvVvK = -593315.6626155803;
    int GGWitgZsd = -1792054747;
    int JymaJAvExHtp = 1385846641;
    double sLNsXpUzPgonU = -391654.0070414389;
    bool gNRMVFmBFpi = false;

    if (JymaJAvExHtp >= -1792054747) {
        for (int JSSOD = 1714412035; JSSOD > 0; JSSOD--) {
            xTdUMJ += sYiSVOzdcQK;
            BoMyZux += BoMyZux;
            hKyPZBlSoCcvVvK = BoMyZux;
        }
    }

    if (GGWitgZsd <= -1792054747) {
        for (int ZWxVBSEJvAB = 1174326645; ZWxVBSEJvAB > 0; ZWxVBSEJvAB--) {
            sasKmYWpAJdLu /= GGWitgZsd;
            hKyPZBlSoCcvVvK += RLBdhOLvYvkT;
            RLBdhOLvYvkT = RLBdhOLvYvkT;
            JymaJAvExHtp *= GGWitgZsd;
        }
    }

    for (int rSAGIJOhSdqCrJ = 510060765; rSAGIJOhSdqCrJ > 0; rSAGIJOhSdqCrJ--) {
        xTdUMJ /= xTdUMJ;
        RLBdhOLvYvkT *= sLNsXpUzPgonU;
        sYiSVOzdcQK /= sYiSVOzdcQK;
        xTdUMJ -= hKyPZBlSoCcvVvK;
    }

    if (xTdUMJ < -1017148.2458102107) {
        for (int QoPQria = 1103985694; QoPQria > 0; QoPQria--) {
            continue;
        }
    }

    return sLNsXpUzPgonU;
}

int IfsfCYI::EmQYMKFKLAYe(bool ZMKVBhWqPETyQ, bool hKhWEM, string FunRmGHKWwYRZwDJ)
{
    int UidJrSwL = -493595194;
    int iCcdmEVWaSAhD = -210225967;
    double wYedGG = 189567.883372386;
    int zVvtDkZvgQkTEem = 1175158008;
    int tNdsnijN = 719512199;
    bool EFMAvecfW = false;
    string XGhyqrIPCKw = string("uIZXsaaljrIxbdiubpeHzSiupUWzIZpLIsERPifJQFSNSgeThDQfJGfBXfdWVwmhDBbOCRcaRQDMBhNKrfYmanMGKwTjQxvtYMVIFSrZWonYIUVTVwGBiXWhaajrHdWHPpMLwSchSwbcCQTYROIOETQfMa");
    bool gvgtrwGxocm = true;
    bool fjrSAdqYfoW = true;
    bool hlDsGmqYu = true;

    for (int wfDrhyXJhIu = 1500013361; wfDrhyXJhIu > 0; wfDrhyXJhIu--) {
        EFMAvecfW = hKhWEM;
        fjrSAdqYfoW = ! hlDsGmqYu;
    }

    for (int WALEYzzBXDXOxh = 554143130; WALEYzzBXDXOxh > 0; WALEYzzBXDXOxh--) {
        gvgtrwGxocm = ! fjrSAdqYfoW;
        fjrSAdqYfoW = ! ZMKVBhWqPETyQ;
        gvgtrwGxocm = ! EFMAvecfW;
        gvgtrwGxocm = hKhWEM;
    }

    for (int ISksPVVkDM = 1293310157; ISksPVVkDM > 0; ISksPVVkDM--) {
        continue;
    }

    for (int eHIIKxNjSdl = 1257919796; eHIIKxNjSdl > 0; eHIIKxNjSdl--) {
        fjrSAdqYfoW = fjrSAdqYfoW;
        tNdsnijN *= zVvtDkZvgQkTEem;
        zVvtDkZvgQkTEem /= UidJrSwL;
        ZMKVBhWqPETyQ = ! hlDsGmqYu;
        iCcdmEVWaSAhD -= zVvtDkZvgQkTEem;
    }

    return tNdsnijN;
}

void IfsfCYI::sZVoFKyIjToNj(int tNfCVMH, int vFHRDJ)
{
    string yEHLuhRCxGYhhi = string("ZXRBFlsckLBjdFKgYnUhsrWXoMBjbgWrrQJXVmeoyWJTEIwvHoZYIzuxSOMukUpAjMocbzrytgBMOEPgxZPPxsdwTjiQKp");
    int uYpcyG = 983157237;
    double wfsUYTZS = 612618.49996659;
    int VaFKrRbVdkt = -1279896974;
    string ONWUzTh = string("NIXBPtQnuXAIMFwTatCAx");
    int UKYQQRi = 420956111;
    string BfkiRUxrWl = string("WAqOEGzVtamxTsclvafoyZRLINrJgGMMKTYMojFElMidYQqmiWytZpgulIuBEqeRJchVpz");
}

double IfsfCYI::Ybroe(bool jQgvoH, string MqMjszE, bool vurJhuKkblgbd, string ZhPreLQCZKCHGv, string DePoVn)
{
    string rtCVarhqKugiwM = string("aEocIoOwGUdbYzayHgFNSOCKZFSfsIDLvjyrbfJCLGuEehNDwfGusvuIhlEGrXExdGuUwKwXHUpATsJTviLyyzMiZBSySIMutatGlbSdYmnGxHuXwbKuBaYpQKSUuUagqzdtYRyoaGPjXxYFyeZKUeoXNHvYWi");
    bool EFdCIHph = false;
    bool SiyjMZHCFnH = true;
    bool wneepDZfj = false;
    string hbEVP = string("crNmpfbktbBVKxmjoDeNmxskifmHzHMjmPcbxmQSmEBjyBrYxIzfzhrktULtyqfXkESMMcZCMmousahfXPWKmXtRJyIrpQqVYkqHvTfdQZohCjvBfkiqSBCmzmTPCmsqZ");
    string lugQNaXa = string("EuOjCPPaIJqgJvwEGoqQUkRnmAUqmlYcYkrQqIeKlQyDVwrbrmgYizBcjuChqIMCBWCNBCNWUQYEyLYBKFNeLIBODpcwgafjKXYmoAlwLXIMEBfyCPUBvMeoNSw");

    if (DePoVn >= string("sZwivcQVckjwHmNTAOzgRegRq")) {
        for (int csdylVqrII = 2079087538; csdylVqrII > 0; csdylVqrII--) {
            DePoVn += DePoVn;
            MqMjszE = ZhPreLQCZKCHGv;
        }
    }

    return 848911.9237745081;
}

IfsfCYI::IfsfCYI()
{
    this->gJdTxekcqNetnt(1961252182, true);
    this->tnSqkjHHTsk(412690.2058887337);
    this->oqkIsUAL(-801417.8743244039, string("zjXlrsBwtwebNjlFogiKQGnzfxdzZAcullFFBeOezVbQFRRokjBvhxSdkyVFwCAeBAwHCaYBPllmXJWjdvnZnAMCanBXpkWDmeyYieyrflusmLcLlocaMNoZEjmjYeArBYuDIloFkGxcFlwRDKHiyItQOosUnRLYnTaXJphGyTbxEgbMyIKhuiqlHZbdlHRdATQXdCYSoSvKVWOxVNiisUN"), true, true, -738899412);
    this->slqxyjZK();
    this->PmqYYaUMrlzxRW(string("bZvUAbmBmwIYmzhuUUkiPPNVvNlhRPQBQZdBCahfBzsEYMSjpjMUKUfYXuOxmKtDmRatoWmGRZEAnChONGMCCUtvuTHNAIlAtpCZBtdDOvdGoAnfZBGfGIPFCsiEpsyTfObPDQqWPvuTHuqPIvCd"));
    this->gtgcTSrUMVhh(208729884, true, 466196.2886646013, -1236962839, true);
    this->IGPwem(136394.26699706374, string("JNrIMloquvTijwQwsFsuCGavvrQSDSQlJnfvNeKIFLqVAnivauIRBzfJmxngFlWFTfrURDjZPrSmnqZbrPulXnLlhOpfzTZOAgftnMcmGQTapknIRTQAArhclCpwQfBEKCjmGAZPqGCDyfJsJVpprPEGqHdmSyFfuNZDSjf"), false, string("UqjXgNxdZymiJDqqgiozWbBrdXcehbNcKkJZYxKBCdRbSFxSSeHRopFCWhaFfRjGCANmlSGbYXEGAGDrmXvluEWHUcQbgoGrhzsPKBSEGxQAwaTZhSRkfPZAVyMbtNMepTzmgZwcuhPRRHNTGLZAsIihvuPNmwmVfSbZZtlyPvHLLiERtB"));
    this->ZEUsj(string("aBvuzkQrLTgjxrPvJhGutIeIgcyBDDWILqzowFAZkCVEkTBJAjmeBAFSDRXhVTuCnIBFFHGTpdTKUmDPbUTOKSYhjPWFSORUkxHbMNDrUJyArzCaXTEloFPUaMNnP"));
    this->bdIgMplLYYGvCaB(-378792.26203509467, 1416390774, string("Gn"), false, -808347.717850168);
    this->bTCbCemzX(-455279308, 242426.84112742342, -1534360925, true, false);
    this->xRzxlGakig();
    this->KueXiolCCj(608447.8217776594, -1017148.2458102107);
    this->EmQYMKFKLAYe(false, true, string("kROz"));
    this->sZVoFKyIjToNj(1697603272, -1720426713);
    this->Ybroe(true, string("MPgYjfAbVwCSFhZYcaadDhorkurwRYbWBrUiRJhyoGlgqXAjhParqjUiQtavOLcBbGAZsajKXznqcoZGLihMlZhRwtKoVhTmnfdIhAYYnroTiaCowMqFQAcujhrnUGkjXANKPAHdmaAyyzTbIsmHvibZEOwNCabZOoztNPAmOgjHixqwnnGttlOCPxmXChvwdBNUPjxojjpu"), false, string("AnKavYMyxNpzvcRwTNxmTkZNruuwiQNPGuCqmCmsPDbQbBMiRserWzXFQYBTwxRISjhpWQATCDzXkSnphBoREsvMUrDcnwYOdWQrjSwMXmOcjJJJlvYJQmXazmXjlgvVkZOrTqlbMvqUABrIbXLLYVgeaNprmgnmpkfBbRXOrsTxuScxcBbhPWGxTlmFADfyKGu"), string("sZwivcQVckjwHmNTAOzgRegRq"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ixbWdaEfWZAM
{
public:
    double qxjJKOqbVq;
    string mqngFqd;
    double KfdaVIvff;
    int LjslGYMRDDCcxiZJ;
    int Ioonb;
    string xcRFQhtp;

    ixbWdaEfWZAM();
    string zedwwzyOYD(int bogycoRpQfvNy, string rZgSfGUb, int ARzquWITxfKy, double CBRGj, string KTdjJMUFK);
    double elaJkXB(string TEkNigfthXuZr, int bEAHbVarfuCKREH, bool jDuYExUQ, string vAMLLRudjJYCQ, double GhpaUpxQTJNcFYiW);
    string HlMOmH(bool sMFWTQyjf, int SWsNBMvnhVOhMMqG, bool skjEUjIuERd, double jatdRvsVjdLGokgm);
    void NWRbkonG(double FGGfAxhIBKxhCRd);
    bool jRlLJlVcGyuqRoIQ(double ycQAXn, double pqvlZJkbnhhBuDTp, int ALNlIhiawT, double hgcWDNHAuuENx);
    int WQTjyUzpN();
    void oUVmxDy(int QAfjWqXrCSThrZ, string WWgXGjHxLtcio, double oYsGd, bool UoxUId, double iLXQbL);
    string MpVxDPq(bool BUgowIOsyaBVh, string dIcksNam, bool LsiAsluRquzMC);
protected:
    bool YUTHBlUcZVbynPos;
    string eUMvxzPT;
    string dDUDsDioWg;
    int xEFHlbhaSvddSMX;
    double xHqWhpQyfp;

    void ZmtLkEe(string wKlcpPjYiof, string YoJYfEhIF, int BfjBIIMhJStbeoYo, int yRWkq, string qrYeuVxoXmuuMi);
    void PfuZCXFJafdBzb(double OUaXrJuQEIKNQQ, int nNXYCXlwVPRJwL, double gFbBONFr, int SDRRNGPSNMBuf, string BtITjcUzHUcAxdp);
    void OTEPJiAf(int dkNuq, bool nImnXvFmMsDgDcF, double wCssKIMb, bool zysCtUAAyZovrm);
    bool QxxxbXVciAdV(bool dMNhy, double boZgAeY, int ACzwwGL, int hJcwLpBFe);
    bool MnXxTmltITxzyPwo(string UuyrrJFWkHlCUMiZ);
    int VXUlP();
    string STLVfTppiqJwyl(bool lNdDvKtAV, string lzbVmVuYAwUzf, int XfRpFZPKXQnXYgT, int yHWxaSgWMqPPK, string yBfTMfIjC);
    bool qpbaIN(string FarplmUDycIZ, string fxxPz, double kkfRnz, double XtRmPgCLCpt);
private:
    bool LBUelJNWGBAlCxUE;
    bool ekHZEsHstfxtaPAd;
    string WgBlrFwmTg;
    string FiKWpLzALumN;
    int oJZdNKivtqAlWXuK;
    int zQYghIJ;

    int JXwPBet(bool WNWFezVoV);
};

string ixbWdaEfWZAM::zedwwzyOYD(int bogycoRpQfvNy, string rZgSfGUb, int ARzquWITxfKy, double CBRGj, string KTdjJMUFK)
{
    bool PNczJZFrZhuCH = false;
    string ZWkNWQfSLxOoiOC = string("LOQrKnFSyhJLbTxcNXtxJkmaxcSTRVCaOKFFGCJywCxWOGaOXsNjGcXUmlAYNtJhVatUZmBocWsBHNXYBWndnIsxQvzYSEkAWsmGBMvuDiKUSCRbKZPyrHnAfUreZtciSwtgVuDFNrXubuxLKijvgxQMmSMUJYo");

    if (rZgSfGUb <= string("XYApQHntfavisfPbQfvlsVFIrSYyyyjkIBDkAXpZBNiJlghTqAjyIwnnGwBvYPtSlONBxipCROBsYJMaajCGvGNUHoWHqWoDcddeCV")) {
        for (int rwRuzD = 2121380308; rwRuzD > 0; rwRuzD--) {
            continue;
        }
    }

    for (int eEYjeqhIIkwPG = 1807999156; eEYjeqhIIkwPG > 0; eEYjeqhIIkwPG--) {
        rZgSfGUb += KTdjJMUFK;
        KTdjJMUFK = KTdjJMUFK;
        ZWkNWQfSLxOoiOC += ZWkNWQfSLxOoiOC;
    }

    return ZWkNWQfSLxOoiOC;
}

double ixbWdaEfWZAM::elaJkXB(string TEkNigfthXuZr, int bEAHbVarfuCKREH, bool jDuYExUQ, string vAMLLRudjJYCQ, double GhpaUpxQTJNcFYiW)
{
    double aEVbwWDOCEqJFl = 733003.7761716782;
    int dKUiJFKFS = 1988420720;
    bool WsTtA = false;
    double nQhHAkTw = -162820.20172770382;
    double gzQdovXTKFJIxH = -325445.68627676734;
    string exEkLzTWmsmm = string("ObzqvWMLLZPgkhECraaEljzUgfhxsksHiGPSeCpJaTFCHpdhquLfxZOmpCBqiNsHMiFfKZrFSQZIasOniEcQVDlJnYRBKiPEqwJCCAdjJkDPtygslaZwePsQZatgQjyzkOPOdLHiXReEwFvhKEdpidRxhrgCVDMnAbFqhNQKxoplYykqxWJdDPiireOdTaqLyekpOqIfeRevnOzzqXGkQwhwd");
    int lMIqYUn = -734882486;

    return gzQdovXTKFJIxH;
}

string ixbWdaEfWZAM::HlMOmH(bool sMFWTQyjf, int SWsNBMvnhVOhMMqG, bool skjEUjIuERd, double jatdRvsVjdLGokgm)
{
    bool KaPZmcaxpLaH = false;
    double YggcSpPFy = 240015.1078315975;
    double rPrFp = -465321.05318107514;
    double QevaNAvi = 140137.28807877813;
    bool NVjuEbT = false;
    bool gfDhihpODOjeFYmo = false;

    if (sMFWTQyjf != false) {
        for (int vnHlqyEjvgayAFtB = 738884011; vnHlqyEjvgayAFtB > 0; vnHlqyEjvgayAFtB--) {
            continue;
        }
    }

    if (QevaNAvi == -465321.05318107514) {
        for (int VHlVnhoPJfSZediS = 1427999484; VHlVnhoPJfSZediS > 0; VHlVnhoPJfSZediS--) {
            continue;
        }
    }

    return string("iqNyqlRmIFiWPzNFMtyjdcUsmEEnOycAkiGoXlqoYdnpwPwirSGDSpESmWVoyLOcHlMyDlQEiTcyOJeDbHMfUeEJMEpXiAyoeHjNxIzkWTIlGPZeyrKUKWhJaTSIbgfFoXtqotsAtqLLYo");
}

void ixbWdaEfWZAM::NWRbkonG(double FGGfAxhIBKxhCRd)
{
    int IybdWhkpDYltzaBx = 1419027227;
    bool tVRdqGEDMjlSIcYN = true;
    double dsSzHuTBA = 358175.1218123717;
    double sEAWf = 525904.4180427332;
    string BYIvKILm = string("MjmXwRKPSCebuwAGoYjvLVKXifkFRvrEdGFgcmcVdDCJKhUJkfmQqlwaZYrEHLPFzbGxGQyNogXhYoFacwcTffSxLawwKbQIoDuzXimIqNuJeVczDzUUJwyABGTnYaycPwzQmFzOkmRxKzyRzSPdpgUrmsnndLalyfzTbBedFDhUyDGVZYcXhJVOhDWBLlPHKTNhSGnXiOoJ");
    string NUXckOJGayjILn = string("zdWLZnXTYcRftuYETYhcQesJcREWOSWeJtzPzXWckNtiBbdcqrzPZkHMZAvkHneGKsZxNexPiUnQVQrrrvepytHtRMRFsGKmlPIWIEzXrkAEnacGsUHiaSAURkVMisxlaLOblovtJnBoMerhExkmZMPMeZAgayIgBGtbMMsEayfqQOQzJzfokQbKFVMSNGzpdzdkdFZrJlkOlrKDWgIrmrdFzQoDAbDoNLTfGZaTvIFoBbZ");
    int WQRkpwUfnUSSSU = 1512843309;

    for (int TxkuoJ = 1459495403; TxkuoJ > 0; TxkuoJ--) {
        WQRkpwUfnUSSSU -= WQRkpwUfnUSSSU;
        tVRdqGEDMjlSIcYN = tVRdqGEDMjlSIcYN;
    }
}

bool ixbWdaEfWZAM::jRlLJlVcGyuqRoIQ(double ycQAXn, double pqvlZJkbnhhBuDTp, int ALNlIhiawT, double hgcWDNHAuuENx)
{
    double hiWzVRGwPUFBq = -85680.47938565136;
    double EmBgl = 857934.0924236492;

    if (pqvlZJkbnhhBuDTp == -85680.47938565136) {
        for (int ZbIgZYtHYMdzQDrt = 138302374; ZbIgZYtHYMdzQDrt > 0; ZbIgZYtHYMdzQDrt--) {
            hgcWDNHAuuENx = ycQAXn;
        }
    }

    if (pqvlZJkbnhhBuDTp >= -1028149.4658283367) {
        for (int aYjbRWnnoKpWhNvz = 1515603793; aYjbRWnnoKpWhNvz > 0; aYjbRWnnoKpWhNvz--) {
            EmBgl += hgcWDNHAuuENx;
            hgcWDNHAuuENx *= EmBgl;
            hiWzVRGwPUFBq = hgcWDNHAuuENx;
        }
    }

    if (EmBgl != -1028149.4658283367) {
        for (int GODErhLzpGydnw = 1036203992; GODErhLzpGydnw > 0; GODErhLzpGydnw--) {
            pqvlZJkbnhhBuDTp = ycQAXn;
            EmBgl /= pqvlZJkbnhhBuDTp;
            EmBgl -= hgcWDNHAuuENx;
            ycQAXn -= hiWzVRGwPUFBq;
            hgcWDNHAuuENx -= pqvlZJkbnhhBuDTp;
        }
    }

    if (pqvlZJkbnhhBuDTp >= -1028149.4658283367) {
        for (int eGgZxBsOkO = 414885735; eGgZxBsOkO > 0; eGgZxBsOkO--) {
            ycQAXn -= pqvlZJkbnhhBuDTp;
            pqvlZJkbnhhBuDTp = pqvlZJkbnhhBuDTp;
            EmBgl -= EmBgl;
            hgcWDNHAuuENx *= pqvlZJkbnhhBuDTp;
            hiWzVRGwPUFBq += pqvlZJkbnhhBuDTp;
            ycQAXn -= hgcWDNHAuuENx;
        }
    }

    if (EmBgl == -534755.5000275502) {
        for (int izRdSYoaQCt = 1164839375; izRdSYoaQCt > 0; izRdSYoaQCt--) {
            hgcWDNHAuuENx -= hgcWDNHAuuENx;
            EmBgl /= hiWzVRGwPUFBq;
            EmBgl -= ycQAXn;
        }
    }

    return false;
}

int ixbWdaEfWZAM::WQTjyUzpN()
{
    int SfTKDt = -1453412786;
    string wjZNRNGjueqVE = string("QSVuDNRkMTQUuHxDuyXrHObzwysaKTORMoUwyHoxjtkmxELKNyNHxeqZboTPsInrQUdgWKbbxdbMsrZKAUXqmJcqTbGuFODzxZHkCdcxchHwDlLfcgFdbcEPQNUSDBjXTjbZpeeewFDRZilmRNhRWHAdNWDPiBswJSI");
    int LLQSTUprJNQAfZAc = 1506526063;
    int ecqPkFlHdFBf = 1032390634;

    if (ecqPkFlHdFBf == 1032390634) {
        for (int dsCnzCIOLiKZMkB = 2098090998; dsCnzCIOLiKZMkB > 0; dsCnzCIOLiKZMkB--) {
            ecqPkFlHdFBf /= LLQSTUprJNQAfZAc;
            SfTKDt += SfTKDt;
            LLQSTUprJNQAfZAc -= ecqPkFlHdFBf;
        }
    }

    if (LLQSTUprJNQAfZAc != 1506526063) {
        for (int POYgBvUnoOKj = 1664041624; POYgBvUnoOKj > 0; POYgBvUnoOKj--) {
            continue;
        }
    }

    if (SfTKDt > 1506526063) {
        for (int fjYHyeBzNvm = 1205624948; fjYHyeBzNvm > 0; fjYHyeBzNvm--) {
            ecqPkFlHdFBf *= SfTKDt;
            LLQSTUprJNQAfZAc -= ecqPkFlHdFBf;
            SfTKDt *= SfTKDt;
            LLQSTUprJNQAfZAc *= ecqPkFlHdFBf;
            LLQSTUprJNQAfZAc *= LLQSTUprJNQAfZAc;
            ecqPkFlHdFBf /= SfTKDt;
        }
    }

    for (int UAFLtEg = 519774624; UAFLtEg > 0; UAFLtEg--) {
        SfTKDt += LLQSTUprJNQAfZAc;
        LLQSTUprJNQAfZAc /= ecqPkFlHdFBf;
        ecqPkFlHdFBf /= LLQSTUprJNQAfZAc;
        ecqPkFlHdFBf *= ecqPkFlHdFBf;
    }

    if (wjZNRNGjueqVE > string("QSVuDNRkMTQUuHxDuyXrHObzwysaKTORMoUwyHoxjtkmxELKNyNHxeqZboTPsInrQUdgWKbbxdbMsrZKAUXqmJcqTbGuFODzxZHkCdcxchHwDlLfcgFdbcEPQNUSDBjXTjbZpeeewFDRZilmRNhRWHAdNWDPiBswJSI")) {
        for (int ndxrHSCpYjCX = 1889808723; ndxrHSCpYjCX > 0; ndxrHSCpYjCX--) {
            LLQSTUprJNQAfZAc = ecqPkFlHdFBf;
            ecqPkFlHdFBf = LLQSTUprJNQAfZAc;
            LLQSTUprJNQAfZAc += SfTKDt;
            ecqPkFlHdFBf = LLQSTUprJNQAfZAc;
            ecqPkFlHdFBf += LLQSTUprJNQAfZAc;
        }
    }

    return ecqPkFlHdFBf;
}

void ixbWdaEfWZAM::oUVmxDy(int QAfjWqXrCSThrZ, string WWgXGjHxLtcio, double oYsGd, bool UoxUId, double iLXQbL)
{
    int iKXdioD = 711990294;
    double zeUbPmTnJp = 34185.12908550649;
    double FBpwu = 295952.0898242102;
    string laaoKAkJNKVzIot = string("BbivQdqYGeTOgRejeLZuoxNODrAeFvSNWweZyFYGHHNZJLz");
    double BoSGDPez = -783245.1879697415;
    string jOiEPZnZQrBhhlbe = string("qnIBOQIbdwFwLTFYuEHVOZw");
    int RchJvBOuoywUfrro = 1090723808;

    for (int Luvyzmm = 1513258926; Luvyzmm > 0; Luvyzmm--) {
        iLXQbL = FBpwu;
        iLXQbL -= FBpwu;
    }
}

string ixbWdaEfWZAM::MpVxDPq(bool BUgowIOsyaBVh, string dIcksNam, bool LsiAsluRquzMC)
{
    string qnbmupQRfnTZMYG = string("URfxADaIaposBLhSGqFKovzuVqNvfGGRRrvCjnLhKoIMHRdlSrXBJNVrIiqxDvHhujOYpHNeaWjXfYUiDqmIjXAEOGxnBFUib");
    double ZHWoZcB = -700162.5722123815;
    double acZdXKnkXGh = -303750.5385949898;
    bool NTWseWOK = false;
    double yKmRwfK = -750911.7986520125;
    bool TRCwuIioZKGYp = true;
    string CjQEDZPS = string("WquqKKksH");

    for (int aBCWqRjDuCQ = 1873541130; aBCWqRjDuCQ > 0; aBCWqRjDuCQ--) {
        continue;
    }

    for (int KtHqtO = 632574158; KtHqtO > 0; KtHqtO--) {
        yKmRwfK += yKmRwfK;
    }

    return CjQEDZPS;
}

void ixbWdaEfWZAM::ZmtLkEe(string wKlcpPjYiof, string YoJYfEhIF, int BfjBIIMhJStbeoYo, int yRWkq, string qrYeuVxoXmuuMi)
{
    string geIrwJHMzkf = string("OhnlWZkMKKtplwHroHFBqZSMjHtAhMboFnkNgxmzOtBSFWIgHyLYvzdnOKJUSdtieoEQkHsrOaHOGhQDnqUtQY");
    double xcoLuQWfytbEEs = 71175.12030356452;

    for (int rcuJKnFoDFW = 897399856; rcuJKnFoDFW > 0; rcuJKnFoDFW--) {
        yRWkq = yRWkq;
    }

    for (int ybKGOBPVrOVH = 136611963; ybKGOBPVrOVH > 0; ybKGOBPVrOVH--) {
        yRWkq -= BfjBIIMhJStbeoYo;
    }

    if (wKlcpPjYiof >= string("lJitptuVgmSFFoZigTHJwGZesUNdfRIMGhuazVGyTMCZNYqztlMvxPTXELmBTcvbGejdnSsINopCKQtkNosKvPwdxVSIVISSgVWADCeybUaCEYmlLWkgixCsA")) {
        for (int ZAqOzz = 116156734; ZAqOzz > 0; ZAqOzz--) {
            continue;
        }
    }

    if (YoJYfEhIF < string("OhnlWZkMKKtplwHroHFBqZSMjHtAhMboFnkNgxmzOtBSFWIgHyLYvzdnOKJUSdtieoEQkHsrOaHOGhQDnqUtQY")) {
        for (int wbRMgoIetS = 1699419585; wbRMgoIetS > 0; wbRMgoIetS--) {
            geIrwJHMzkf += geIrwJHMzkf;
            wKlcpPjYiof = YoJYfEhIF;
            yRWkq = BfjBIIMhJStbeoYo;
            wKlcpPjYiof = YoJYfEhIF;
        }
    }
}

void ixbWdaEfWZAM::PfuZCXFJafdBzb(double OUaXrJuQEIKNQQ, int nNXYCXlwVPRJwL, double gFbBONFr, int SDRRNGPSNMBuf, string BtITjcUzHUcAxdp)
{
    string UORLKVQ = string("yWwEIEsbWRbCmDrGKtXAPqMPJUBiwwHGboFpUBWsboxbIqoIXDipywFMuDddSCAlBgtRIm");
    string kJsYJHa = string("dWNdYDtkvdvxxBvypQhXfbuEFvSUccmkQtIhonpTwuTbMylPgUKsQkTzxWpAqIyLD");
    string iwzVkVBCWp = string("maBCyoUcJsGuzyLOmwFcjKIptQGpXRiigjYaaOfeKiHuWudDyVgFJIAzzlnMtIgjLFrPDmgJmUjriBtWFLgtnIBYEtcwmVUpMjVBazoDvQoEKddZkiHAqPyKnlnnpxSfljppuMGyXvMxmtSetJyMtANzCTTiZchkjGQzdZugUKshWTwCMueWQEDghtLQ");
    double wbObcbsmdpwFvGQ = -82016.42490055224;
    int HzjzHtikL = -2034962489;
    double dACMrBpBQrMKSwS = 555495.1676605773;
    double lEwJGXAse = 632053.5974260132;
    string mlwYrgZMIbAvrio = string("KgeZbbPrBjwYYQRjrv");
    string YDEcMBOAOLwgoN = string("JSSyILkbQmVuuhsGyYWErLaiFlHrEUejQdKbvRRpSiflHOVcQYNWKfYTguTWjrbbzeihsDEYLJmFJUfnFGOpQznyCKgzInJKnjFwvgJXIpqFtBdUeuCDxHPEuSKxplTVaAOnbAKRBcMtaPBpZYPBbXoTUOYsxGdp");

    for (int LeeVzpkKP = 2034534610; LeeVzpkKP > 0; LeeVzpkKP--) {
        continue;
    }

    for (int lmDMMojbC = 1520787363; lmDMMojbC > 0; lmDMMojbC--) {
        continue;
    }

    if (iwzVkVBCWp != string("KgeZbbPrBjwYYQRjrv")) {
        for (int nHcBl = 80761913; nHcBl > 0; nHcBl--) {
            dACMrBpBQrMKSwS = dACMrBpBQrMKSwS;
            iwzVkVBCWp = UORLKVQ;
            kJsYJHa = mlwYrgZMIbAvrio;
        }
    }

    for (int wsrstCr = 707874810; wsrstCr > 0; wsrstCr--) {
        BtITjcUzHUcAxdp = UORLKVQ;
        gFbBONFr /= wbObcbsmdpwFvGQ;
        HzjzHtikL += nNXYCXlwVPRJwL;
    }

    if (UORLKVQ == string("lXHXBmsBjOVtrpEvzTEmunUBOlOPpKnfNhxrIKmJxSXCSqQqiWUuLOXhyNqEmfDXAKgdQupnOxApTSeFnStWYridcXHJGgXscdRaFWUCKoDOWwsIayIiopFQvwJGCZDMuZzgkfcnRBjxfDDrLqHZaPRrpjyVPFnSbrVXWooRRVidolJQsAPKiWsNZegYrhBahTyyOlOwWjqRPJizBYseCHLvxctwNEVfElCaifYwVovPuQCyMLHXAxTYVKXd")) {
        for (int ROCcBDIIqYvk = 184309082; ROCcBDIIqYvk > 0; ROCcBDIIqYvk--) {
            lEwJGXAse *= wbObcbsmdpwFvGQ;
            BtITjcUzHUcAxdp = mlwYrgZMIbAvrio;
        }
    }

    for (int gJXYTGGeQqHexO = 1224075047; gJXYTGGeQqHexO > 0; gJXYTGGeQqHexO--) {
        HzjzHtikL -= nNXYCXlwVPRJwL;
        UORLKVQ += UORLKVQ;
        BtITjcUzHUcAxdp = mlwYrgZMIbAvrio;
        gFbBONFr *= wbObcbsmdpwFvGQ;
    }
}

void ixbWdaEfWZAM::OTEPJiAf(int dkNuq, bool nImnXvFmMsDgDcF, double wCssKIMb, bool zysCtUAAyZovrm)
{
    int bhSTqcuKJjfkbTx = 1707939044;
    int QRAmO = 1851727679;
    bool nYQrgdppJms = true;
    bool fyvzegR = true;
    int oBaqDKfesrM = 817376809;
    int yIzoOysdFIPn = 853131605;
    int WvCwjMlI = 1874787948;
}

bool ixbWdaEfWZAM::QxxxbXVciAdV(bool dMNhy, double boZgAeY, int ACzwwGL, int hJcwLpBFe)
{
    double HWCxMVmMXhwR = 788591.9716111245;
    bool FuQxCjOvd = true;
    int ycEUeZ = -1344560818;
    bool bugxQPpBC = true;
    double SMDvAzOGIVlGZ = -954720.8379088914;
    double kReDh = -688863.0033607277;
    int IWaGQpyRt = 641616039;

    for (int DrcPFHRxvXPscgk = 1337546743; DrcPFHRxvXPscgk > 0; DrcPFHRxvXPscgk--) {
        ycEUeZ /= IWaGQpyRt;
    }

    for (int hNexcclAwyqtFI = 1956545753; hNexcclAwyqtFI > 0; hNexcclAwyqtFI--) {
        continue;
    }

    return bugxQPpBC;
}

bool ixbWdaEfWZAM::MnXxTmltITxzyPwo(string UuyrrJFWkHlCUMiZ)
{
    int tozQVmi = 1694289610;
    int GKvJnjdFZhblDYSN = -830546067;

    for (int IhJYPrchCv = 406385009; IhJYPrchCv > 0; IhJYPrchCv--) {
        tozQVmi = GKvJnjdFZhblDYSN;
        tozQVmi = tozQVmi;
        tozQVmi -= tozQVmi;
        UuyrrJFWkHlCUMiZ = UuyrrJFWkHlCUMiZ;
        UuyrrJFWkHlCUMiZ += UuyrrJFWkHlCUMiZ;
        tozQVmi /= GKvJnjdFZhblDYSN;
    }

    for (int UZiZfpQPiyvzTbJP = 777560862; UZiZfpQPiyvzTbJP > 0; UZiZfpQPiyvzTbJP--) {
        GKvJnjdFZhblDYSN -= GKvJnjdFZhblDYSN;
    }

    if (tozQVmi != -830546067) {
        for (int RlgRXHTq = 158421802; RlgRXHTq > 0; RlgRXHTq--) {
            tozQVmi -= tozQVmi;
            GKvJnjdFZhblDYSN -= tozQVmi;
            tozQVmi = GKvJnjdFZhblDYSN;
            GKvJnjdFZhblDYSN /= GKvJnjdFZhblDYSN;
        }
    }

    if (GKvJnjdFZhblDYSN >= 1694289610) {
        for (int EfbRvdFnCeSER = 1208911978; EfbRvdFnCeSER > 0; EfbRvdFnCeSER--) {
            tozQVmi /= tozQVmi;
            tozQVmi += tozQVmi;
            GKvJnjdFZhblDYSN -= tozQVmi;
            GKvJnjdFZhblDYSN /= tozQVmi;
        }
    }

    for (int IBCUS = 1323501421; IBCUS > 0; IBCUS--) {
        GKvJnjdFZhblDYSN = tozQVmi;
        tozQVmi -= tozQVmi;
    }

    if (GKvJnjdFZhblDYSN > -830546067) {
        for (int bnnBShViikeUXui = 1222926561; bnnBShViikeUXui > 0; bnnBShViikeUXui--) {
            tozQVmi -= tozQVmi;
        }
    }

    return true;
}

int ixbWdaEfWZAM::VXUlP()
{
    double SNjgdF = 628595.5370839799;
    string PNKRlPDnAi = string("ctYUqWqyayuUcvfHNjhRClKhLNafLupFRVfJnxoRTSODJYcgpskpMMlIsarMrUioawPsrmfHhaFKdNdygYEgKlqGGRcCdMsKoiZtBIkRRgKFtWzhuXvvxkfdHuoZxvIAJkjoxcSCXfWoCUufjutDCSnUvGzDyTvUALrNPVWQLyrIsHziEavdFhYGzEnGbGTBXYaehMIjXHEWeaFEOQDCcQfJf");
    int IcWGVRoUAG = -1731273339;
    double YOhzZEYXc = 633068.3450767803;
    double ZJQrTqgM = -79360.66163406681;

    for (int zlOJfdPC = 253625775; zlOJfdPC > 0; zlOJfdPC--) {
        ZJQrTqgM += YOhzZEYXc;
        ZJQrTqgM = SNjgdF;
        SNjgdF *= YOhzZEYXc;
        YOhzZEYXc = ZJQrTqgM;
    }

    if (IcWGVRoUAG >= -1731273339) {
        for (int inpQIhccuDAYmEh = 1925259003; inpQIhccuDAYmEh > 0; inpQIhccuDAYmEh--) {
            SNjgdF /= YOhzZEYXc;
            YOhzZEYXc = ZJQrTqgM;
            ZJQrTqgM = SNjgdF;
            SNjgdF -= YOhzZEYXc;
            YOhzZEYXc += ZJQrTqgM;
        }
    }

    if (ZJQrTqgM != 633068.3450767803) {
        for (int EukLzwaSBe = 1113321095; EukLzwaSBe > 0; EukLzwaSBe--) {
            continue;
        }
    }

    for (int UibCBVIUjQLr = 1710775725; UibCBVIUjQLr > 0; UibCBVIUjQLr--) {
        SNjgdF = ZJQrTqgM;
        ZJQrTqgM -= YOhzZEYXc;
        IcWGVRoUAG = IcWGVRoUAG;
    }

    if (ZJQrTqgM != 633068.3450767803) {
        for (int YHlYXbFifHIitwOF = 1851529162; YHlYXbFifHIitwOF > 0; YHlYXbFifHIitwOF--) {
            SNjgdF += YOhzZEYXc;
            SNjgdF = ZJQrTqgM;
            SNjgdF -= SNjgdF;
            ZJQrTqgM += YOhzZEYXc;
            PNKRlPDnAi += PNKRlPDnAi;
        }
    }

    if (SNjgdF < 628595.5370839799) {
        for (int nGEyhfp = 505006105; nGEyhfp > 0; nGEyhfp--) {
            PNKRlPDnAi = PNKRlPDnAi;
        }
    }

    return IcWGVRoUAG;
}

string ixbWdaEfWZAM::STLVfTppiqJwyl(bool lNdDvKtAV, string lzbVmVuYAwUzf, int XfRpFZPKXQnXYgT, int yHWxaSgWMqPPK, string yBfTMfIjC)
{
    double kEnaJzE = -902848.0447751071;
    int xuNwHHXZrXuJyFuT = 12042725;
    bool bPsuVPFkmIV = true;
    string TzEBoetPLU = string("eLpqVEWEHzuvwguPpvcxVFgRKOeurXYRWDGmYlwjkRopIklJRjvGnlNk");

    for (int XZlMyAgmhgNO = 1271227146; XZlMyAgmhgNO > 0; XZlMyAgmhgNO--) {
        TzEBoetPLU = yBfTMfIjC;
        bPsuVPFkmIV = ! lNdDvKtAV;
    }

    for (int SgWbpGOeqG = 1318943863; SgWbpGOeqG > 0; SgWbpGOeqG--) {
        lNdDvKtAV = lNdDvKtAV;
        lzbVmVuYAwUzf += TzEBoetPLU;
    }

    for (int CwdFOPJNS = 625323992; CwdFOPJNS > 0; CwdFOPJNS--) {
        continue;
    }

    return TzEBoetPLU;
}

bool ixbWdaEfWZAM::qpbaIN(string FarplmUDycIZ, string fxxPz, double kkfRnz, double XtRmPgCLCpt)
{
    int bqKNYmC = -116168700;
    int AGsvQWIsv = -1708591791;
    string okGBkJWOvqytyIZ = string("CZjPyTpBNdzJoNFkWspkYsagqAPdXsvRpKevIPwFHTIzZMwVthqUdppBEZuwYtnEtclZMKhLbyzdNcFRTaFBCExRwpPEcGkDXDIInBQafJoFPYybMymAwJIyYpER");

    for (int XbwMLSS = 1257553841; XbwMLSS > 0; XbwMLSS--) {
        continue;
    }

    return true;
}

int ixbWdaEfWZAM::JXwPBet(bool WNWFezVoV)
{
    double ANtmBpPqeQKeiFD = -220653.05092611854;
    double qpUFVHxZeWS = -854717.3550823184;
    int TzFEFtNbV = -1657495177;
    int edNalpdRjcjhkMno = -1991053301;
    int rqDbvsFDUsYQ = -488891354;
    int QZpeVKEirPzv = 1964916879;
    double PQstCuxHonLPlYeU = -697031.4897010663;

    if (ANtmBpPqeQKeiFD > -220653.05092611854) {
        for (int nmogIqVeTOsAyYgM = 236341071; nmogIqVeTOsAyYgM > 0; nmogIqVeTOsAyYgM--) {
            QZpeVKEirPzv -= rqDbvsFDUsYQ;
            TzFEFtNbV = TzFEFtNbV;
            edNalpdRjcjhkMno /= edNalpdRjcjhkMno;
        }
    }

    return QZpeVKEirPzv;
}

ixbWdaEfWZAM::ixbWdaEfWZAM()
{
    this->zedwwzyOYD(-1979567175, string("yScBDCTMteoxkjOlgtfnfmeExikJMsULzuKnYWrJciH"), 1199391725, -232646.8780656056, string("XYApQHntfavisfPbQfvlsVFIrSYyyyjkIBDkAXpZBNiJlghTqAjyIwnnGwBvYPtSlONBxipCROBsYJMaajCGvGNUHoWHqWoDcddeCV"));
    this->elaJkXB(string("PdMFRvBZjqxEZseXHZQWnQLCjrlWnirhKLgbUDVmctDvcWzBhRuFAiKwPiGggbbZXjsWTdRNLiJKRZOMyHRrtiVLRoRXy"), 1111687811, false, string("XMQiGqXNIAKHAN"), 398524.1166481534);
    this->HlMOmH(false, -47413723, true, 913486.7662991531);
    this->NWRbkonG(-474563.1304557316);
    this->jRlLJlVcGyuqRoIQ(-820545.1490524668, -1028149.4658283367, 246072472, -534755.5000275502);
    this->WQTjyUzpN();
    this->oUVmxDy(-465380567, string("TqryfXrjDSEriS"), 35185.23278739823, false, 570895.2390828676);
    this->MpVxDPq(true, string("ptmXZqJwAsewCOduNKMIiVEaIjvfJTnePBwUPVEduLJdRDGoBbbxoohQmzDwiXAmgNpJebjHLlQJZOPQTgCTWYgbVyRsHtKYujIXEWnGMPUSTPNzOWEjvWZxrAsVPQfPNxdYSkibIVaIoqjKZulpzLrQgqnZisCfjSlnJjaClSQHlWuTNrChbKlsfwNsABtho"), true);
    this->ZmtLkEe(string("lJitptuVgmSFFoZigTHJwGZesUNdfRIMGhuazVGyTMCZNYqztlMvxPTXELmBTcvbGejdnSsINopCKQtkNosKvPwdxVSIVISSgVWADCeybUaCEYmlLWkgixCsA"), string("fSocgavGaMIkAQqvHRJaGdYZldDjebjV"), -57904452, 1468436992, string("DfCFXsAvuoWHEcvznkbkXGbeglOcFYqdfnvzKrlXYfwYBPogCcpvCtoHmyneJYMnTgktmouyeboGPDdkWVaKJjGHfHHwzUPaRsXvSHHPEgsbLENsIQIvWcnjrTPzrCNnLUvrCQMTIVhnWdFgoa"));
    this->PfuZCXFJafdBzb(-412956.85317395924, -529422622, 993893.43834572, 2050882156, string("lXHXBmsBjOVtrpEvzTEmunUBOlOPpKnfNhxrIKmJxSXCSqQqiWUuLOXhyNqEmfDXAKgdQupnOxApTSeFnStWYridcXHJGgXscdRaFWUCKoDOWwsIayIiopFQvwJGCZDMuZzgkfcnRBjxfDDrLqHZaPRrpjyVPFnSbrVXWooRRVidolJQsAPKiWsNZegYrhBahTyyOlOwWjqRPJizBYseCHLvxctwNEVfElCaifYwVovPuQCyMLHXAxTYVKXd"));
    this->OTEPJiAf(-1220094293, false, 722368.2604009149, true);
    this->QxxxbXVciAdV(true, 621060.2539120866, 578800446, -1003654350);
    this->MnXxTmltITxzyPwo(string("gWJmbRVoFPDlgoJSuFNlUbEykTpSliGQsAwnfymCdiqZbIMpsqUlRBSLpOeMcTmFIVCcYrsQtCeRBIq"));
    this->VXUlP();
    this->STLVfTppiqJwyl(false, string("jybuPxFxdPQJEHkJfdOTwRKZhxHwxGdxtYEGqcbvViQBJqgyxGEdGQGMezHfecLdYLMUAfyHr"), -71263358, -499010868, string("GcuNKozjtlCWjdfyLSpaFLPIGajsQBAiZFEwZpfQaiyUcdQLDbZqQsljaOtvGWfxCCXfKojDLxugMJkdel"));
    this->qpbaIN(string("LtdRyqYetyiEUHQHhZImKtAhttcN"), string("ZvtNMxhiYXuipHdfQmTzTFpBUSlxVbkuCUsgQypKCpRbXAaUSyGMZYRtqfkapXupridJcDNqfUXObUwwtVYtgRWtZfLgxtbHOhHpOtcQjXCDzMgpqlUYtkJfLgbmZzhVSAkQsPzFHderlpGXxNVGhQwjyxraWgDawsycGQCXIu"), 610237.84957794, -1019349.4214096006);
    this->JXwPBet(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bgcghpwXOg
{
public:
    bool FWRFyEtRAq;
    int gXgBGVyQZ;
    bool qnDPwhQiOW;
    bool qkFIoY;
    int QTsDdzG;
    int orAWFAhQguYjXm;

    bgcghpwXOg();
    string pPaelNsdcOSYfobM(bool qFBdWztZmc);
    void prrxXjjQpTCjLLL(string Cjtrluy);
    string DhEhrvNxDQWr(bool wDkCsx);
    bool rwcWhLK(int hlsjbOvnzyRVon, bool YCJNuxcYAdAQjn, double ISQqP);
    int rjduqhsJhlxP(int ouFKKwKFylS, string beaTbNXkiPiZx, string GjPYJ, bool EoDJlhoNYZ, bool KUTGJKAiMofycZUn);
    void yUrUS();
    double xndxQTuDdXaTQjOT(bool IlRkE, int NQuWYpEtkjFKiHnA, bool QyZxyaCBLJ, double ByLFMCpiC, string SoyuKNmQVbZ);
protected:
    int NeaqOGKECdfsTeo;
    string SNCAqCJiPgrebuOk;
    int qxMTVxwOt;
    double rgYTplQWZgasyV;
    bool LGVHyG;

    void aNadTYxkJd(double XUszsUDBUSoBLmSF, string yCigjQVdNCd);
    bool qZpIGfKwTRe(string apwbGxJcXboPNdLn, int LBGZUwLwMAGF, double pymOgIanGsAPGmM, int MbMceV);
    string qSneL();
    int LKxfEUJASJyu(bool iCsaXpcWqaLhuzK);
    double mGjokoy(int EvDSFY, bool CMMyf);
    void nnElheSAGbbiqjw(int qJBtmaXiNKnzif);
    string SNKqr(double IVBInCDxNOP, int DTAFV);
private:
    int GbnEK;
    int nZlUKGykYPMsAjw;
    string vbKfjo;
    bool HdqDXCIrWxObGOrB;

    bool EKVNXZS(bool WGdgsBYkP, bool PDuGsGFJByWOfs, double sWPGvaWRv, int YkQuNyojm, bool wQIDGStCAD);
    bool ifSTZA(int ZTtmeLo, bool dowxDvZsBcTsoh, int XkhbcZHmqPmgIY, double uhhFbaRiH, bool PveEU);
    double ZcLZYJvMBlKVEZ(double TAjJFOLOhyvCUh, bool bhtkarwMsCiX, bool ZSmUB, double rYhWQcah, int iuIYYJBtRDPCJ);
};

string bgcghpwXOg::pPaelNsdcOSYfobM(bool qFBdWztZmc)
{
    double OyToJAEhNDJtzSj = -245363.7812927842;
    double sRCgMh = 1008267.6109110636;
    double uwkbXhpv = -279154.20830957434;
    double qZEHDuRNtPpJbQUo = -965315.9950335012;
    int rdFFp = 424867657;
    bool kSLTbtSV = false;

    for (int neTfNkw = 995068561; neTfNkw > 0; neTfNkw--) {
        qZEHDuRNtPpJbQUo -= uwkbXhpv;
    }

    for (int qJaEjXsqARzpN = 805603000; qJaEjXsqARzpN > 0; qJaEjXsqARzpN--) {
        OyToJAEhNDJtzSj *= uwkbXhpv;
        kSLTbtSV = qFBdWztZmc;
        sRCgMh = uwkbXhpv;
    }

    for (int WBfcOp = 379105745; WBfcOp > 0; WBfcOp--) {
        uwkbXhpv -= uwkbXhpv;
        qZEHDuRNtPpJbQUo -= OyToJAEhNDJtzSj;
    }

    return string("EVEvWYtvwLtRBZIsyalLobKtkQjZnAtzhDMbntPgJBMf");
}

void bgcghpwXOg::prrxXjjQpTCjLLL(string Cjtrluy)
{
    bool VvWMNBqCKFWbma = false;
    string PlvYvukwjmFhvU = string("MJZlEtIVEKfpXZOJsjjEADbmKxwqAuCrajfufkJePBVENcBKDYqKQdikapOqZTfyNaLrSbPPVESmExPpgQemhqORoNrMEbJHODReLmeaNBHEnEkGZTDrBotOEmPdMSFtlaugKLiuroKYbkIBagdMVpJcniqfwTCZVfOQsoNTntNCdokpGeIgstgxwFGWHGuffWKxzmtZPVrIxEClRkBGaMIMx");
    double KLrqOGYVReGJSYW = -1015064.2361341873;
    string RabSnVZFEB = string("WkrdfBUdybvQBdkQGGQvryvWjlFycozLvNWoDITvNKxOTPCEHxZJaJoYrWUdpXvPMKrSKVuxhnQGFjIDoDjvvcjiqPJoOKtwlJmspwhAATgvHwMkKZVrjIrLSHEjEdKXzXcnEvAfpZxCVsNehicTiAsXCMrXOdmUQcimitQNpOKEEXNOXbRzhCfgGDedoavJWVj");
    string uMKHCXx = string("VnESyXeIimLtaentHPTftGJxOfvVZhuIZdjnRLsajrBFVKQhHmXAYcGikkUsDDOgPmvbQnpuQbeezdctsEUVtPqqGcnKWWEWXUlgBGAMHZjiRWzocENtVIelZchwJDJcwQpTPiIioPVGmBHfrSBFIeuszJRmRiuIVDanQkNGBvtdLHwVtBCweOPVFezhHNAirkZ");
    bool PLuZPsWe = false;
    int bxNeQSkW = 150896509;

    for (int MauaMDtepk = 906563989; MauaMDtepk > 0; MauaMDtepk--) {
        RabSnVZFEB = PlvYvukwjmFhvU;
    }

    for (int wPZocawDLlNQ = 2037924401; wPZocawDLlNQ > 0; wPZocawDLlNQ--) {
        uMKHCXx += RabSnVZFEB;
    }

    if (bxNeQSkW <= 150896509) {
        for (int oCTvnpTZWg = 629957398; oCTvnpTZWg > 0; oCTvnpTZWg--) {
            uMKHCXx = uMKHCXx;
        }
    }

    if (PLuZPsWe != false) {
        for (int cOIBIbePyA = 895504839; cOIBIbePyA > 0; cOIBIbePyA--) {
            PlvYvukwjmFhvU += RabSnVZFEB;
        }
    }

    for (int GoWlaf = 971557936; GoWlaf > 0; GoWlaf--) {
        Cjtrluy = RabSnVZFEB;
        PlvYvukwjmFhvU = RabSnVZFEB;
    }

    for (int kASrNgHNqaqwEncD = 1550997057; kASrNgHNqaqwEncD > 0; kASrNgHNqaqwEncD--) {
        PLuZPsWe = PLuZPsWe;
        PlvYvukwjmFhvU = Cjtrluy;
        Cjtrluy += Cjtrluy;
        RabSnVZFEB += uMKHCXx;
        uMKHCXx += Cjtrluy;
    }
}

string bgcghpwXOg::DhEhrvNxDQWr(bool wDkCsx)
{
    bool rICahxTj = false;
    int DKtvyCQKQ = 826255847;

    for (int RSinrcTwumm = 647357557; RSinrcTwumm > 0; RSinrcTwumm--) {
        wDkCsx = rICahxTj;
    }

    if (wDkCsx != false) {
        for (int VKEUbEk = 959989049; VKEUbEk > 0; VKEUbEk--) {
            wDkCsx = rICahxTj;
            wDkCsx = ! rICahxTj;
            wDkCsx = wDkCsx;
        }
    }

    for (int asXoqLLNrJglIzj = 518901036; asXoqLLNrJglIzj > 0; asXoqLLNrJglIzj--) {
        wDkCsx = ! wDkCsx;
        rICahxTj = ! rICahxTj;
    }

    for (int vDjHW = 882805436; vDjHW > 0; vDjHW--) {
        rICahxTj = ! wDkCsx;
    }

    return string("hSniVdbmhnDqxXepLyJiqfg");
}

bool bgcghpwXOg::rwcWhLK(int hlsjbOvnzyRVon, bool YCJNuxcYAdAQjn, double ISQqP)
{
    int BOOeBmpCHK = 1403875686;
    double PdqrC = -894649.6303448838;
    string WWRXluyfSO = string("YoLphUNpDrfvivoPFGSFJLAMeJBQdPVUOYyC");
    string CNoEU = string("xiZUmYlLMuCcsIlzJIjLRAtIfLWrmxPrkjTsmcmkWcjJtdNnjrWSHidfIYfkuvGTCwBCnhLtNaWpKPmprwWXCXFqSuGMsYSmczZEtUIvvvoCEIHd");
    bool gbzvnZwwmeJYl = true;
    string BcTruCmnXZw = string("DPwPKzEjzTIpNaRpfzqzgFIeonQLwkROuGyuwKsLGXORzvXxqxJh");
    int jiQFlf = 1918449412;
    double WoiiEsRbHlEjCFyU = 816623.4854475987;

    for (int TVxbkqpDmyaDJjuX = 846590057; TVxbkqpDmyaDJjuX > 0; TVxbkqpDmyaDJjuX--) {
        hlsjbOvnzyRVon *= hlsjbOvnzyRVon;
    }

    for (int tekyDyGLS = 1364775974; tekyDyGLS > 0; tekyDyGLS--) {
        BcTruCmnXZw += CNoEU;
        BOOeBmpCHK = jiQFlf;
    }

    for (int CjwJPJ = 534561577; CjwJPJ > 0; CjwJPJ--) {
        ISQqP = WoiiEsRbHlEjCFyU;
        WoiiEsRbHlEjCFyU = ISQqP;
        WWRXluyfSO = WWRXluyfSO;
        BOOeBmpCHK = BOOeBmpCHK;
        jiQFlf -= BOOeBmpCHK;
    }

    return gbzvnZwwmeJYl;
}

int bgcghpwXOg::rjduqhsJhlxP(int ouFKKwKFylS, string beaTbNXkiPiZx, string GjPYJ, bool EoDJlhoNYZ, bool KUTGJKAiMofycZUn)
{
    string daTJhGOZz = string("qlUEqtrTCNtAXTGBvwksKTrYxgiBRVdGEdroFQpgWAcgnCTWxhfYJlTpqjnARplnkfASgyncsUMRJlEhWRyyjJFrqOSxMmdPCaLDrzGiHSJZasHeiLjIn");
    double ZJzNOUerlk = 38053.78923633196;
    string gNtJtuhwduXE = string("WUvyWfsaphXJYNAhoHFTlEwBOkrhdtZjLQVqxVkTQrHyLRsEoxyCWyhYRnizUnLpXOnTOJhgXgUjFPGxeBLlJizwHpcSRhnBYPeVUDGuEWYaIfGsjOVGyTtTyRortqAoCnehyecAAIYWBsfipaUDWyLgkKrRZNoMbVIIlxzvQkYdJc");

    for (int xIcApi = 1566032132; xIcApi > 0; xIcApi--) {
        GjPYJ += GjPYJ;
    }

    for (int uazzQXLOr = 360670547; uazzQXLOr > 0; uazzQXLOr--) {
        continue;
    }

    return ouFKKwKFylS;
}

void bgcghpwXOg::yUrUS()
{
    bool AIpUNA = true;
    double yFKsCWCKK = 921293.8237269075;
    bool aNfUloNsVFkgp = true;
    double CpkWmWJok = 609085.3481632086;
    double YvJJXkGeBRptLs = -942738.7640982751;
}

double bgcghpwXOg::xndxQTuDdXaTQjOT(bool IlRkE, int NQuWYpEtkjFKiHnA, bool QyZxyaCBLJ, double ByLFMCpiC, string SoyuKNmQVbZ)
{
    double KCZCVaHwOHpZYYc = -620651.9426232075;
    int LFPiUETdkRPBW = -966832691;
    int LSvevdDOKISSKakr = 1782609314;
    bool ffqfoEy = true;
    double bIkMOZSvuhde = 384644.67703796015;
    bool JWSDUeNbpLXYaF = true;
    double gZgEEfnSd = -66943.2388511227;
    string XkZNOOYvhOJyqV = string("ybXinQAdMVxkxJExktHcjgCHOyDWNqTxqBnzMJyhrFIyDHXLncvvbcxDlnNGOKRTcbtxcCNytkKyvxPVfEqHeWHsPmaZFXm");
    int LSDMqNvWgNeSYqjR = -1930559450;

    for (int RfTrdXUzPmjjjWp = 1753938497; RfTrdXUzPmjjjWp > 0; RfTrdXUzPmjjjWp--) {
        continue;
    }

    for (int KxdtlqRssWZVIWXB = 2039832297; KxdtlqRssWZVIWXB > 0; KxdtlqRssWZVIWXB--) {
        continue;
    }

    if (LSvevdDOKISSKakr != -1224845719) {
        for (int pNXiwkynSWPxbg = 604850873; pNXiwkynSWPxbg > 0; pNXiwkynSWPxbg--) {
            LFPiUETdkRPBW += LFPiUETdkRPBW;
            LSvevdDOKISSKakr += LFPiUETdkRPBW;
        }
    }

    for (int VBXztyEZUxwqYqja = 688637121; VBXztyEZUxwqYqja > 0; VBXztyEZUxwqYqja--) {
        LSvevdDOKISSKakr += LSvevdDOKISSKakr;
    }

    return gZgEEfnSd;
}

void bgcghpwXOg::aNadTYxkJd(double XUszsUDBUSoBLmSF, string yCigjQVdNCd)
{
    double jMFkuahq = 1043139.3588097964;
    string EWGnrPG = string("fyWounoLJiZDIzNUZqykLxuMzDTGxJjFpzQSDvXCRWrevVvPzYsoMsrHgWYViPDYyLTKSLaysnlxnORUFNNmrCZsUqcfuYhiEnHjAiRXpmipQjUVTWxkvGFdxzNKlsWVFipIMaNPPDFhpH");
    string UwwMEo = string("wKMXznyFjRWZquZEviBUWdZhRHuzkmejfJgQGssMRTMMlxfJxIXkdvwFeEpkIrgkPiwyDaRqGYDsltPONoeHYxTOamUXpHaXgnMFrMzqkiZObJQFpGbTSEdmWMZBfPQAhLMgbIJeJUc");
    double ZJOvikHTIF = 1033378.2841114451;
    double kJmOHOTcPVrOiOTw = -910988.27467087;
    int npYepuFuVd = 643333187;

    for (int kKnJKXEmKdadvG = 1776100677; kKnJKXEmKdadvG > 0; kKnJKXEmKdadvG--) {
        XUszsUDBUSoBLmSF *= jMFkuahq;
        UwwMEo = EWGnrPG;
    }

    if (npYepuFuVd == 643333187) {
        for (int mRVqLLsMI = 794782449; mRVqLLsMI > 0; mRVqLLsMI--) {
            XUszsUDBUSoBLmSF *= ZJOvikHTIF;
            ZJOvikHTIF *= kJmOHOTcPVrOiOTw;
            XUszsUDBUSoBLmSF /= jMFkuahq;
        }
    }
}

bool bgcghpwXOg::qZpIGfKwTRe(string apwbGxJcXboPNdLn, int LBGZUwLwMAGF, double pymOgIanGsAPGmM, int MbMceV)
{
    bool xvHQtPjm = false;
    double gVzmhrINDYlMRZnQ = 97386.42391036142;

    return xvHQtPjm;
}

string bgcghpwXOg::qSneL()
{
    string YtaWILli = string("HRonPWktvbOiqBmFAomwzgChBbZwMtNuejUHNmZrvpQdcPylTZNrmeZoBPavPwZtIiKIjPyRgNtACMKYdaggRRaGTYFRtzcBvhFOoAxYllMUMTBhvHrXzinGwSKNwqDWinpIOdPBJsILEyFHtqQdzOijzaAQJoGwfYPDIcUVoBDvNBSZLmChtivoNBdMMTYreLZbNZdgtioxMMRYefc");
    string QadaGA = string("fiBpeWKxdOezcERuIXjrMUxAvVExMFBspneAZiptKZMKShCbpbpguTbTn");
    int kfIcqNlwSagt = 911080748;
    string zFXOKqVvlYNxxK = string("qDCwASYziMHYaCXliuTNkrchZKlSJFiwRxvEMakTgYhaBHgmFGaLsxQFwLPXyZuYRQkYAoMuHVyYMFyRgWtBUazrd");
    bool mcPrI = true;
    int xoZkIOckquv = 1362058415;
    double sIUUPmPUVbOK = -276581.0772926315;
    string wjErrrdoCHnWe = string("UfPYRuHKNnmSEaQbhLGEGMaSvtDxBCdPUciONdmLPQUiPAiqQQYDwIlNaYRsprZcUMpdeTVkQAcpdIvpboPXybBgLuVpZvcwwUxLKzNm");
    int hDWBCgOQAinVk = 737301906;

    if (zFXOKqVvlYNxxK > string("HRonPWktvbOiqBmFAomwzgChBbZwMtNuejUHNmZrvpQdcPylTZNrmeZoBPavPwZtIiKIjPyRgNtACMKYdaggRRaGTYFRtzcBvhFOoAxYllMUMTBhvHrXzinGwSKNwqDWinpIOdPBJsILEyFHtqQdzOijzaAQJoGwfYPDIcUVoBDvNBSZLmChtivoNBdMMTYreLZbNZdgtioxMMRYefc")) {
        for (int pHuTVI = 574295831; pHuTVI > 0; pHuTVI--) {
            kfIcqNlwSagt /= hDWBCgOQAinVk;
            YtaWILli = QadaGA;
        }
    }

    if (QadaGA < string("fiBpeWKxdOezcERuIXjrMUxAvVExMFBspneAZiptKZMKShCbpbpguTbTn")) {
        for (int aEJcJP = 1066200734; aEJcJP > 0; aEJcJP--) {
            hDWBCgOQAinVk += kfIcqNlwSagt;
        }
    }

    if (wjErrrdoCHnWe >= string("qDCwASYziMHYaCXliuTNkrchZKlSJFiwRxvEMakTgYhaBHgmFGaLsxQFwLPXyZuYRQkYAoMuHVyYMFyRgWtBUazrd")) {
        for (int sDuILAi = 433111625; sDuILAi > 0; sDuILAi--) {
            wjErrrdoCHnWe = QadaGA;
        }
    }

    for (int xSZQGOMAZkVLp = 1355952461; xSZQGOMAZkVLp > 0; xSZQGOMAZkVLp--) {
        YtaWILli += QadaGA;
    }

    return wjErrrdoCHnWe;
}

int bgcghpwXOg::LKxfEUJASJyu(bool iCsaXpcWqaLhuzK)
{
    string PrtEyYTA = string("SzSgZbxoQusRTAUzVutZRUWrxsyoUAjklnBwXBfRKinlCk");

    for (int eeOIZwLbQzl = 98355687; eeOIZwLbQzl > 0; eeOIZwLbQzl--) {
        PrtEyYTA = PrtEyYTA;
    }

    for (int ijBnO = 2012414015; ijBnO > 0; ijBnO--) {
        iCsaXpcWqaLhuzK = iCsaXpcWqaLhuzK;
        PrtEyYTA += PrtEyYTA;
        PrtEyYTA += PrtEyYTA;
        iCsaXpcWqaLhuzK = ! iCsaXpcWqaLhuzK;
    }

    return -1863067227;
}

double bgcghpwXOg::mGjokoy(int EvDSFY, bool CMMyf)
{
    int VjkWyRmylv = 1030039984;
    bool mNHkXRchRCvn = false;
    int hZDVHuBVXUELSvUw = -1518370612;
    string SeyNMnqrkOgBR = string("aSstXNigDhhCppRKBvpCAChJLgwAWAbkMqbszYZyTJLJUHJYTxByv");
    bool ayqvEQ = true;
    int kQnoE = -1650682499;
    double hmchQaDKmFFpas = 892353.7370784156;
    bool MlFqluVoPhx = true;

    for (int hhPeRTuu = 1035831407; hhPeRTuu > 0; hhPeRTuu--) {
        mNHkXRchRCvn = ayqvEQ;
        ayqvEQ = mNHkXRchRCvn;
        mNHkXRchRCvn = mNHkXRchRCvn;
        CMMyf = MlFqluVoPhx;
    }

    if (EvDSFY <= -1650682499) {
        for (int hVleJwoS = 1356294600; hVleJwoS > 0; hVleJwoS--) {
            hZDVHuBVXUELSvUw = hZDVHuBVXUELSvUw;
        }
    }

    return hmchQaDKmFFpas;
}

void bgcghpwXOg::nnElheSAGbbiqjw(int qJBtmaXiNKnzif)
{
    int MsEKivcXV = -1816737527;
    bool UYgPji = false;
    string REXubzFokJBZJfPT = string("msdJiqEUEV");
    int sgObqfKcGAQ = -308965759;
    string oMiYPfbYK = string("TMKLCCODBhUtDMVxJbyRspnwwyzEjNAJcrgdSIYUTJgrGxmVyTxyVGtmRfacpJPBqlLKGYZCtYTqXuRxkZkfnfNyUcGHKUViSnbDuqejNqWTsczkVhhyEAhWMgXZHyqOBXoWsIRyZTWEgtV");
    int klHJlEfQIQTQfV = 2102150143;
    int iwrjb = -1615738793;
    string mRzilvaJKd = string("uFCvQbwqmbiOdGbokmHHlWBhYvWwSLbrNpzAuDPwkwalfyNylgbRhkyVTKeRZDSArBNIgxzQlcEoFPtUxjmoleNJVUKueIVHufKnzDMFUdfBkudpzNtDMsIQkHOlwBFjAqYxdVQwcPpbkdtpbgruSCGxoDddFPSCjeNzpd");
    double FdzGsmlWlb = -94610.85588694164;
    int vkzMMMzfwgJkezXr = 1638554301;

    for (int CzTatE = 1365458618; CzTatE > 0; CzTatE--) {
        sgObqfKcGAQ /= vkzMMMzfwgJkezXr;
        sgObqfKcGAQ -= sgObqfKcGAQ;
        mRzilvaJKd = REXubzFokJBZJfPT;
        sgObqfKcGAQ -= MsEKivcXV;
    }

    for (int hGnjjdJH = 458969678; hGnjjdJH > 0; hGnjjdJH--) {
        MsEKivcXV -= iwrjb;
    }

    if (sgObqfKcGAQ <= -308965759) {
        for (int QXiApcgtO = 1786808282; QXiApcgtO > 0; QXiApcgtO--) {
            FdzGsmlWlb -= FdzGsmlWlb;
            klHJlEfQIQTQfV = vkzMMMzfwgJkezXr;
            klHJlEfQIQTQfV *= iwrjb;
            mRzilvaJKd += REXubzFokJBZJfPT;
        }
    }

    for (int MyPpwuaX = 1241722265; MyPpwuaX > 0; MyPpwuaX--) {
        continue;
    }
}

string bgcghpwXOg::SNKqr(double IVBInCDxNOP, int DTAFV)
{
    string CnuBZR = string("EczdqElLstPfvvfOfMrzrBybfwJpoIzpoSaBnfADVFKQIXWnghTxAYLVaxs");
    int hbPsPMde = 1754375879;
    int VvDksWMRjChot = 1480681391;
    int rmRcZFEnuWJndsq = -144830645;
    bool aOahoLRXeaN = false;

    for (int wAZEqkDKAqrbtM = 1440850310; wAZEqkDKAqrbtM > 0; wAZEqkDKAqrbtM--) {
        continue;
    }

    if (IVBInCDxNOP == 473819.4811811101) {
        for (int rCOcFHDQ = 576502659; rCOcFHDQ > 0; rCOcFHDQ--) {
            hbPsPMde *= hbPsPMde;
            DTAFV *= hbPsPMde;
            rmRcZFEnuWJndsq -= hbPsPMde;
        }
    }

    for (int OtEcfbajliVmOcUI = 362197198; OtEcfbajliVmOcUI > 0; OtEcfbajliVmOcUI--) {
        rmRcZFEnuWJndsq = DTAFV;
    }

    if (hbPsPMde <= 1480681391) {
        for (int muxLzO = 1721650762; muxLzO > 0; muxLzO--) {
            rmRcZFEnuWJndsq *= VvDksWMRjChot;
            hbPsPMde /= DTAFV;
        }
    }

    for (int UqQGfygKBtcA = 1439230103; UqQGfygKBtcA > 0; UqQGfygKBtcA--) {
        rmRcZFEnuWJndsq *= VvDksWMRjChot;
        VvDksWMRjChot -= DTAFV;
    }

    return CnuBZR;
}

bool bgcghpwXOg::EKVNXZS(bool WGdgsBYkP, bool PDuGsGFJByWOfs, double sWPGvaWRv, int YkQuNyojm, bool wQIDGStCAD)
{
    string efrlzCFEWFNSz = string("RqmmRSBhKsVAaMzJnWADSryxknhYRkvaeFQlkxbRzOESKIHDnOWplioSUmJEjmptIIoNeHxKosqZHwDxFDlWBCpSAxMSIOQWPIqggktyUgIwRM");
    string CjXxbk = string("sIzUSbxiHjIryYCXFqANDjVtLEplPQRrJoHMirDQwnbHWkHBQiyReQfXzwoQKikPnpZeGGzVgjmsfodtDDUJHxNEgCneDVJlhrcvwqElNIggtyAAu");
    bool UfTGGKmjhpbcUmw = false;
    bool alCjgUSip = true;
    string nsWTzESjXNBm = string("OtVsBQzyGUwqCpRLsvAXHgrAksGyuvwosSaEStBNHXTZieARWiRtCBLowZSAXZjTJItqZFCkjEGzCeoQcMAALvdhhcMoGqxGNuFqWJIRKPSyDibZKFBrymNjfhPdVWpgfxCLQJKNmEwMIWplqolNdzWCaYXZyloAItPhuNkcGTUCkEMulgBMQUFiPblrvRvWoDpHgpa");
    int kEiYeOrmruBJL = -239816002;
    string IKbfxDEti = string("xPDLdRMHJfNYvTlmllUwTImPojzklBRJqmuEzUJMPGHQXNVYFrCgjJWXumEFrGJzPWmmhyLMewMDuGQVcUbkaAfdAqCWzptEWPEJxbjFLfmxwTVkFIEvJZCpKAgLhnODkhsNifIvfIbeQNTzikFrxIKKcUPJ");
    int ghFoucf = 1101907850;
    double wMnbhE = 242702.92314194157;

    if (ghFoucf > 1101907850) {
        for (int DXrNfHB = 183293332; DXrNfHB > 0; DXrNfHB--) {
            CjXxbk += efrlzCFEWFNSz;
        }
    }

    for (int lYKFviRYWxSiJk = 583590498; lYKFviRYWxSiJk > 0; lYKFviRYWxSiJk--) {
        PDuGsGFJByWOfs = wQIDGStCAD;
    }

    for (int jPXdCxSezpBHOe = 1986880428; jPXdCxSezpBHOe > 0; jPXdCxSezpBHOe--) {
        PDuGsGFJByWOfs = ! PDuGsGFJByWOfs;
        nsWTzESjXNBm += efrlzCFEWFNSz;
    }

    if (YkQuNyojm > 831836140) {
        for (int pWPtboGEBu = 1761982864; pWPtboGEBu > 0; pWPtboGEBu--) {
            continue;
        }
    }

    for (int vswPMML = 1550944039; vswPMML > 0; vswPMML--) {
        wQIDGStCAD = UfTGGKmjhpbcUmw;
    }

    return alCjgUSip;
}

bool bgcghpwXOg::ifSTZA(int ZTtmeLo, bool dowxDvZsBcTsoh, int XkhbcZHmqPmgIY, double uhhFbaRiH, bool PveEU)
{
    string tmvlhbQVOZliCp = string("XbDGueXMECdFCYmDPfykwyNexJJzwUrFlRoQYZDNdFunaXLlOFqjpdReAcCLAZEkIssfVpMTbnwvyzgsxGMMSyKMCDYTgbheYPoRrcNKTUnzIlMmIuNgzmhDb");
    double vnxYeiEVbhz = 652703.8758879578;
    string GibOHsspANzxTH = string("CJeiDfkyyfcCReRQePUyXtiuaBCNskoWncPhnEjNlFZNEwvXLjmPhTgFqUlzDXywDMBzMllpvAeuLFpmcYKLKaHdTIySMXIsoTKBiwQVgNVtkikYjdIJBnhOWJOWFMSOKSzNagHyeEkPtNYMRloOmCDJURTFtZFpHmKebdgnsMvQBgILmiguJTcgcCFJDfCjjzWwWMEQD");
    string zVdVWFqPo = string("bTNZpyX");
    double kdrpC = 687277.1227338902;
    string DIaKAOCeYXO = string("dcotpWrtKyFIdruQniaDPEPPPVdarhmSFLxoipmVRljIxkXFVmImqtUOAmgeacwicviFukbiWUxadcbHRATWgxscbsKxGfnHqJeiFlFRzkMiJHYfZBjarvRStUrqMtTdJOVpoKHSYDaLfxcahFWibopJvYQCofKHzkxaoYtOhBfklFCIvWcKoIEJdNlIYKltcxRdxtQgjxiTGzthnDJwexNHtWOJxTMXpKcWpKs");
    int VbqUZ = 1685352003;
    int cSBHZPbAbXmVzZM = 2014105953;

    for (int XLCixT = 1223912767; XLCixT > 0; XLCixT--) {
        continue;
    }

    for (int jNcjRjsARtfrLrbI = 1674571858; jNcjRjsARtfrLrbI > 0; jNcjRjsARtfrLrbI--) {
        zVdVWFqPo = zVdVWFqPo;
        uhhFbaRiH -= vnxYeiEVbhz;
        VbqUZ -= XkhbcZHmqPmgIY;
        PveEU = ! dowxDvZsBcTsoh;
    }

    for (int mIVznnXcioijhSh = 1427431639; mIVznnXcioijhSh > 0; mIVznnXcioijhSh--) {
        continue;
    }

    for (int bQQKP = 1910599681; bQQKP > 0; bQQKP--) {
        GibOHsspANzxTH += tmvlhbQVOZliCp;
        ZTtmeLo += VbqUZ;
        DIaKAOCeYXO = GibOHsspANzxTH;
    }

    return PveEU;
}

double bgcghpwXOg::ZcLZYJvMBlKVEZ(double TAjJFOLOhyvCUh, bool bhtkarwMsCiX, bool ZSmUB, double rYhWQcah, int iuIYYJBtRDPCJ)
{
    bool QyWABZvLGqqZkM = true;
    int DIyNUh = 79922910;
    int sCMDhGzfrjWgLvzK = -285565375;
    double TaYUoLTuKHgW = -397382.9011329451;
    bool cGNmkMGQeaPI = true;
    int zPhErDRWJbpNe = -1598275568;

    for (int fxsdVZ = 574362035; fxsdVZ > 0; fxsdVZ--) {
        QyWABZvLGqqZkM = ! QyWABZvLGqqZkM;
        iuIYYJBtRDPCJ *= sCMDhGzfrjWgLvzK;
        rYhWQcah = TAjJFOLOhyvCUh;
        QyWABZvLGqqZkM = bhtkarwMsCiX;
    }

    for (int LwMCp = 1508853277; LwMCp > 0; LwMCp--) {
        rYhWQcah += rYhWQcah;
    }

    if (DIyNUh != 79922910) {
        for (int fJbIDvMDWzlwWiJs = 687874111; fJbIDvMDWzlwWiJs > 0; fJbIDvMDWzlwWiJs--) {
            iuIYYJBtRDPCJ -= zPhErDRWJbpNe;
        }
    }

    for (int IZkVZpXthQcwb = 1447962362; IZkVZpXthQcwb > 0; IZkVZpXthQcwb--) {
        rYhWQcah -= rYhWQcah;
        ZSmUB = QyWABZvLGqqZkM;
    }

    return TaYUoLTuKHgW;
}

bgcghpwXOg::bgcghpwXOg()
{
    this->pPaelNsdcOSYfobM(true);
    this->prrxXjjQpTCjLLL(string("NjBEmMMnSWqHWxbFZnUSqejjXlhCutiBBNZwfPdkbUVBJdwUMrUmFjFXBvuOdZOrmqYBCkElwxtBBveOdqOGOxDqynwXzPaEaYjHbQjKWAqLYqhYgKDxWKMRzQIQxlWZNasXLhsJCWLAairHLEXLoEedKYgqiDyzvdnttEISdvGXElHrkwWCHvRNzrgzYlRRQgpJaiiVqCGAZMLfsKdvpcOIRLcnTfLCYSmzQNOux"));
    this->DhEhrvNxDQWr(true);
    this->rwcWhLK(760021277, false, -848721.3083392297);
    this->rjduqhsJhlxP(-2013548207, string("wvoyPCfwxwvnYFzoLLUCoyiabdTICkAhrUpnUHkiOMPePQjGVCFpELOGiIIQOcpcVCHBVSexHfoNbAsJJxfsbDMJMeqwnPqMoXZyQgSxDHzItAPyPQjXkOYvFQqrcYYmPvmJtKbPkoAOUzJVvJWZeIFBDANvg"), string("TaoxewYwFpdRfkkZayiflmtqzVMFIbGOgUfGLRjcvLngONEIEywKzYAQFjBagxrTTfjawmPwejRVMcNYZEXlscvsGakNVufKhNtVyEscFRNRJYLYKsMQoPQhYhwgaZJrNSEiUAIvVKTWRTUjdQvcUdEahtrfeYiuyOxDVPWohVrBnMOytgFzZqvliyjHXQuJd"), false, true);
    this->yUrUS();
    this->xndxQTuDdXaTQjOT(true, -1224845719, true, 799757.321035307, string("oIcQKcGKHSOjWkBqthWrwEfftVjdcAmdehVeIBKrxYyUnzUzmnSQNHqe"));
    this->aNadTYxkJd(-3681.0197800373007, string("UOUUFVclhAIjUBiiGxWyDHsByXCLkPwvVtFQvKFrKFXRRtWMVfsiDUlPXpGubayZbKrCfZnrLRPhHFNlOZOAhvJybyVWvqTnGGjZwKIIuVRLutGVBXUqngurrFVPBISDobBxjauK"));
    this->qZpIGfKwTRe(string("mQWlcBYgsrmaAlvTysuPQGBBvLfGPyUqswrYvXbuQkuecqBdLFzdzKHembZPQXIRhNwzWejHWLGJhoyyMnXMRXWJlpdzwLDVKAFSyaskrOiIkIPANUCuqcOuzeelKojekGCsCXjFtJVtqdxqKWcncPnQONfgoPTGdcPxgzzHQqsDSZWqnGfeUuThPReBGNdPsRtJAIKsA"), -1539214159, -1037912.7344927986, 73261894);
    this->qSneL();
    this->LKxfEUJASJyu(true);
    this->mGjokoy(1441427191, true);
    this->nnElheSAGbbiqjw(-1060294057);
    this->SNKqr(473819.4811811101, -1546198551);
    this->EKVNXZS(false, true, 230575.65171738816, 831836140, true);
    this->ifSTZA(-145662111, false, 137233847, 794241.192893823, false);
    this->ZcLZYJvMBlKVEZ(-316904.8713202836, false, false, -798359.8338354618, -478548404);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pjcqKusNVrQOoPEi
{
public:
    bool gaEIoND;
    string ayUylRKefNw;
    string iVSzXLHPa;
    bool rayPLwFxHrXvZPn;
    int lDBYGLKBcVLIt;
    bool BvFoIii;

    pjcqKusNVrQOoPEi();
    bool wOHenWL(int zXdqA, double PPjLlrsWV, double AEfemlfwkW);
protected:
    string dOvSll;
    string GJVDhUZDLWjZh;

    string rmakQzVNRJD(string RIgpTBTkPCWbjOwZ, double VTRqcq, string pDgbvOBqw);
private:
    string jnvhijIsAhaqhK;
    string qxyCFR;
    bool SgLuHa;
    bool dAoLydP;
    bool DxxCWDd;

    bool SSsAaRtDM(bool wlwEhJZcwouf, bool OdbMSgsjgaZL);
    double PhEVGkOtPdMkiM();
    string vQNbwlvcx();
    int MBEkmbUnELhFPrN(bool PTGpHtEaiCbW, bool zkoteaDmhpJp, bool VTRooLcN);
    string SuBBFXVCCYi(double SeqsRDkX);
};

bool pjcqKusNVrQOoPEi::wOHenWL(int zXdqA, double PPjLlrsWV, double AEfemlfwkW)
{
    bool OpwzyulAoJeEiY = true;
    string Tcqmbou = string("mZEWwuxZVIvwPwRYjnrUuSpqBSCkYVGYIFDUNOpgewJZdmsvPWbUmbtXgerqGDOWXtFwqmtwsYMAAdHELWbrELIreRnXvtACWmMiFiEubJPKuspJwGBnYGOJUsLqEFeevtFmztUNPEiMryvIpydurXWXGEVzyTnnHDTsXLIJWFBUzEAqtReACfUNdOekSSbMmslqmaBXObDrIpwKjpFZVbMUCwxaR");
    double BmTLUcK = 962872.0631717725;
    int QRFYeRVdiRGquod = 341455384;
    string lxZFhzUEiQGHRZHV = string("aSlPKmhnPuXiyROdliNNdZOZYhtBzLOxaerYMnDdbZbsUvhrQyccmFSIrdeoAZbdeK");
    double MjhFSMcY = 242155.01387564614;

    for (int UKurOIeD = 2068123288; UKurOIeD > 0; UKurOIeD--) {
        PPjLlrsWV -= PPjLlrsWV;
    }

    return OpwzyulAoJeEiY;
}

string pjcqKusNVrQOoPEi::rmakQzVNRJD(string RIgpTBTkPCWbjOwZ, double VTRqcq, string pDgbvOBqw)
{
    int xhpvvxVnCGqWqX = -1078848857;
    int xDmdTFaSI = 1579262434;
    bool LVVUY = true;
    bool HbgYUkLjVu = false;
    double OqNGaMcZCQV = 489939.46576381737;

    if (xhpvvxVnCGqWqX < -1078848857) {
        for (int AgJOdQnGZfRF = 1795609296; AgJOdQnGZfRF > 0; AgJOdQnGZfRF--) {
            continue;
        }
    }

    return pDgbvOBqw;
}

bool pjcqKusNVrQOoPEi::SSsAaRtDM(bool wlwEhJZcwouf, bool OdbMSgsjgaZL)
{
    double ihQpTwPZNhHqPlm = 503752.95916323166;
    double uzHkWGHGVtDQ = -834906.9917235589;
    string GXtrEIsiMGW = string("AUmJTSxxgMpfkAZpPRkhKvuElGyxbKchnhockAuhGGdtlJhFdgxWEPmdOYnAGnLMavCFJNdNVScYopaSFuDaOQJRoGaimFEtxpSTqgMRIosNdOfxuAwInpKTmBciclkeFhQAzrTHdaFqUvyRLnQtpsAQKmSLTHKHTvlnxYrLIzKRaKEuyzPfXemlykcvzPdNtNKeJAGVGbWyBmXZZbEUseVCTTp");
    string zcWicmsA = string("xsJpzxGEoLgEopOzzACQjOcdhQfIrAozmGXgMkNzoOVdDNosAkzeVqWNkCFIUBzkMgGivoRGUcQWCUEhChMqMSjiAFdvtszECWrAANqfeGYqRDVFRldhAgYRBQBcNLCqIkRLpvyCxlCCAZtPgrnwDkWpNlryctFbpAaChhCyVNpbjH");
    string MniWcGysERFKfbnR = string("HbJbbnkpYxSmOYWqrYviJmUrNguKejDhSSQeAHmoWgLFUWbxtjzTgfowMrMyfuXjQkLkxJWXrYUDZcxGGnHkNwtfSEUjYzOeIIScNefxvoVxLdLrsgJHGtpePcCWzdQWtrLDRWkUCflDBRmfGOyMGlQmMLrDWEHcdMEIxZVmhnrQylKILFnjIeOlkwodAxIBPgmmBsNpvGMgFsLNXzdpOkSeqjjvRHEQyIkAeZbjgYcfxFbHJiQAMuNnb");
    int GzkquIonDi = -1499122606;
    int tVezQhsaGpGg = -1169884680;
    int TapSVSkZYTWmm = 1712420114;
    int mDmNE = 861486895;
    double TCxwwtkqzXTSgTDE = 105595.2376445053;

    if (MniWcGysERFKfbnR > string("AUmJTSxxgMpfkAZpPRkhKvuElGyxbKchnhockAuhGGdtlJhFdgxWEPmdOYnAGnLMavCFJNdNVScYopaSFuDaOQJRoGaimFEtxpSTqgMRIosNdOfxuAwInpKTmBciclkeFhQAzrTHdaFqUvyRLnQtpsAQKmSLTHKHTvlnxYrLIzKRaKEuyzPfXemlykcvzPdNtNKeJAGVGbWyBmXZZbEUseVCTTp")) {
        for (int GfVfqeqHzVzM = 558839734; GfVfqeqHzVzM > 0; GfVfqeqHzVzM--) {
            zcWicmsA = MniWcGysERFKfbnR;
            OdbMSgsjgaZL = ! wlwEhJZcwouf;
        }
    }

    return OdbMSgsjgaZL;
}

double pjcqKusNVrQOoPEi::PhEVGkOtPdMkiM()
{
    double tOkxhw = 906458.4947400629;
    string GgnlOiMZ = string("fFhTsYfToYlriQoNBElGWRMGEXLbZmuLFhrWyzGaqZRiJHJeuoaFIHcxkRzbqApUiKdNWTUrBAMlQrVCewGbNIBJKNorzSCPtYyUGXPXWyCPXFYBZikAbsrXDprHwHJfzDgALloGeOVrWtZJ");
    bool atsPb = true;
    int jlFiRdwh = 2080458834;
    int GMIMR = 591302993;
    double KriNEzvmtJgOU = -946743.8318247003;
    string NiNYCGOl = string("qOQtnlANVbDZQlleCqeuGdkwkmvYMoj");
    bool PGbXZOBKJuUQ = false;
    int JyMdug = -850718960;
    string LbMXqpdAxFAweMCB = string("ibZhXSZaLjvkwLDGjvUVJoBvyGsSKepIXwDiEDYAMyTitvqNkWcrivqPCgzsEqtfNfyPRdhJgWbCtLGSuPKjGjzIlRezkwS");

    for (int lPawFXDzocTR = 28437898; lPawFXDzocTR > 0; lPawFXDzocTR--) {
        PGbXZOBKJuUQ = ! atsPb;
        jlFiRdwh *= jlFiRdwh;
        LbMXqpdAxFAweMCB += LbMXqpdAxFAweMCB;
    }

    return KriNEzvmtJgOU;
}

string pjcqKusNVrQOoPEi::vQNbwlvcx()
{
    double fcpkCqmPcAtrOp = -66391.65081449949;
    double lUDkJ = -118245.38977178127;
    double ZShHmakyPMVG = 738751.9422188413;
    int LiMyrsWIlGg = -1371454073;
    int LgOdOgNcd = -61326239;
    int FQnFXDcccdAIcxli = 754332982;
    bool DZhVLEJWctrtA = true;
    bool dFCYxqGHIaOQ = false;

    for (int XOLUGLzmc = 817072910; XOLUGLzmc > 0; XOLUGLzmc--) {
        FQnFXDcccdAIcxli -= LiMyrsWIlGg;
        lUDkJ *= lUDkJ;
        fcpkCqmPcAtrOp = fcpkCqmPcAtrOp;
        fcpkCqmPcAtrOp /= ZShHmakyPMVG;
    }

    if (lUDkJ > -118245.38977178127) {
        for (int tMhWXNrwfhnSdRr = 816882588; tMhWXNrwfhnSdRr > 0; tMhWXNrwfhnSdRr--) {
            DZhVLEJWctrtA = dFCYxqGHIaOQ;
        }
    }

    for (int VTUjZCYGwFkSria = 1358318663; VTUjZCYGwFkSria > 0; VTUjZCYGwFkSria--) {
        FQnFXDcccdAIcxli -= LgOdOgNcd;
        dFCYxqGHIaOQ = DZhVLEJWctrtA;
        LgOdOgNcd *= LgOdOgNcd;
    }

    if (dFCYxqGHIaOQ != true) {
        for (int rBxHswQW = 1298321974; rBxHswQW > 0; rBxHswQW--) {
            continue;
        }
    }

    return string("sNyAKjabkkoRudxVgZwndgXvbzOHuntsGVEzViVLxSspPzbjswabrNTjdwXgrhJxajntJZwjxoyDFIfyQWfvMGcobFqgUvvxMitnopIqGNZuSeyUPGAeDchsZhrberREQhWZRQ");
}

int pjcqKusNVrQOoPEi::MBEkmbUnELhFPrN(bool PTGpHtEaiCbW, bool zkoteaDmhpJp, bool VTRooLcN)
{
    string BreVNcio = string("xNTTVkEleJfXYHoMYdCVTFsEtjuaaBEYhUJquHjhdiyJhZDFYEFBEipfcEtEtUUUEeVPenYAutcCcDjRNKYHuTTAsOQCiMXGpiQQtqkbXYNQgoJthUvHXOYlIomiGBLwpYToPCfQdguhaIPnaTBfgNvYIXgKkPpsYZGwmkvputhxLZqZYarnWIiBOMXaxBAoVMlzNxhMmEzcV");
    int FbXwHUKMxV = 2039884781;
    bool SvQkEwF = true;
    double bWLsdfz = -726301.151654546;
    double FaVDSvMV = -100893.54434001925;
    double EZOXZFHDavq = -261866.09158457088;
    int NyXISwdpkRYIb = 1795571453;

    for (int gCHpkvAiS = 1293646661; gCHpkvAiS > 0; gCHpkvAiS--) {
        continue;
    }

    return NyXISwdpkRYIb;
}

string pjcqKusNVrQOoPEi::SuBBFXVCCYi(double SeqsRDkX)
{
    string UKYANlvNgkj = string("UMIffBVHsKLRrPSwYildktFtFHANXKtlCuDfAzRVSRA");
    string KkMppmSMkdUkw = string("wOZTDBkfCFMILUSYqHjHqOTINLcreoLUIBgOXMEghYNFJtZUZihdhKuzVZDLViuyANibKymfVlJdMcuGMlIXGIcQSSHTQCRiutSgaXceqBaXBcGmPbonkoYtrogCCRHolROqHrVzzKLjDuEdEVxsCH");
    int SMmhyfiNQLvCwGKv = -942960936;
    bool DfLCVvPAXsyihmww = true;
    int ZoBzqanZXjJEhm = 1241948043;
    int dOHNFraOPuZBB = -1168800480;
    bool xBcTnjCSSh = false;
    string uTKwpdQqBZndbe = string("OTUvbKkuwgygkGzQAJEsCfOSHUiEEkOeCNmlPFPTXBxhsjuwZpiNzHAylGxMYRdHLVKmrKXrzxayKhyaJtgYdWcMJGhAldvYhpAuPPMPZrLkRaTRaQZkyfiDlcXBVoWpzXfstqnhdfZxRQrDNekMuRxqDalmKKpbEKDhFsUYDYnMPlQzZmpRjEtjvUVdRByAozlcOGiSsuUxSvWmIftEParquoFjJvt");
    double PeJxKNjuNAgvo = 704859.4501506396;

    return uTKwpdQqBZndbe;
}

pjcqKusNVrQOoPEi::pjcqKusNVrQOoPEi()
{
    this->wOHenWL(-1484343556, 689137.3498394481, 438628.0866731756);
    this->rmakQzVNRJD(string("dutotULnBeXrjPACgbFTpThXTvUmSokZjxbvuWFgKRSSpzEwgAHwNZACRITUAZuSiJV"), 975992.1343250653, string("AyYJKMuX"));
    this->SSsAaRtDM(false, true);
    this->PhEVGkOtPdMkiM();
    this->vQNbwlvcx();
    this->MBEkmbUnELhFPrN(true, true, true);
    this->SuBBFXVCCYi(1036122.5182221596);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IDMXOBV
{
public:
    string hvWhIeneqRP;
    int CAatwtfSEChrWMzc;
    int KQWiPDL;

    IDMXOBV();
    int MLFrusRKd(string dkJKMypGLowoWVt, string BldFIS, double GaTKTxnanyvxmg, string rcmUBdUJqZTqcmM, int xMKKRHADxL);
protected:
    string msVrNihUrJDytuFG;

    void JTgKOqqPS(double tYRBNp);
    double mVtESGccHyT(string cTOaCbGbcrGrIDOF, string cpfrnFHvpJDDfzg);
private:
    bool gJdyirmbbhLC;
    double JcPIzbNMODfQxQ;
    string yAzdJfFoQVU;
    string wqzKBjtpYorKK;

    double yvDOtlooeR(double JXnAmaNewiYNTX, string KdfgpfuECaA, double UPDKsYxBC, double tCXSxbpFS, bool fouRZRTWMmV);
    bool OrpAqzFJphxSNuDp();
    void PusTfv(int SaGUxWWFdXtOanPA);
    bool kPyRSjP(double RleBai, string rjTRTysiljEv, string avifXdJCrzKbbxw, string BSIFd, int wiOiVEAZqNSnQuN);
};

int IDMXOBV::MLFrusRKd(string dkJKMypGLowoWVt, string BldFIS, double GaTKTxnanyvxmg, string rcmUBdUJqZTqcmM, int xMKKRHADxL)
{
    string oFdQKnlIMmK = string("JCNavZjRrmPOGwWrUMmKNQagsgqfjIcnmNSriYkgwWHPcEjnajYantGoAUeNZLFhxzoMwqiKQszkwzCIZSLsxnWCCTsYu");
    string HxzSVpISOxa = string("RDQXJIIbhMjjjsrtIXYZNKxYPbhVadKHcWpSaKjObwFwyYUGLTslKYrnfIfLSTYAYTmISTrwjJNoMTnktqHdtakIKHmCzSvPFHblJSEJzxHbNjxJqVZLdCenJAHNJPqvIiUyTTpltwhFdNKGKJxKxEiuMaDEycIgsukqAUwZEaTxPqtHHMzJVDLVYjhdNnvygbXSdACpQAQfEXaQllZLUCvjASknkcOicdmxNsjWxiAAixwXE");
    bool RiZdRiLzKFPhjISl = false;
    string npSZXxYLsyF = string("XNtUOguRzcyWFhtxnklgZgFlfQbGHPHGLKYBHQwevLXxOQAdVzslYEBrJdJLLmAeVUfabkcQsmEMiysnxTcRjMxxNVuhrvgBnwnJcwYXWBADjoaQrxQYBqLXrnORrGPvMKAPhmfHAjOKuieivBvSX");
    string itHQnQOywCxwgMv = string("VgOYNRuelOAtpEXvsdVzorjqncKwNcglBjjjDuiusNaDGBRHKrkFEeiJphUOFNDElfDcrCHgkcSYXaGkMnLOocqjVrOChyAdXrmMoczkTpeJKDWVwxLHLfHStPZWwfKBMAcOCPkqGEPTbtCwLCCqWkRxFzjpVzx");

    for (int cjLaqmMozgt = 561759847; cjLaqmMozgt > 0; cjLaqmMozgt--) {
        HxzSVpISOxa += rcmUBdUJqZTqcmM;
        dkJKMypGLowoWVt = BldFIS;
        HxzSVpISOxa += npSZXxYLsyF;
    }

    if (rcmUBdUJqZTqcmM <= string("iqKWBoBQAbvjqxFftwkVYbZbQuOwcSMqXQjcAjdbFVJLDPtQsogwttPtNzvBDZJudEBphUqYEIGVWStygEZEbsbTgVCSFBRTuPyxvisOYbdfjuKvUovZYpHYTUARlcpmxQIAUDtGHCXqZJTvdhaUHGTO")) {
        for (int RoHSdF = 1350444558; RoHSdF > 0; RoHSdF--) {
            BldFIS = rcmUBdUJqZTqcmM;
            rcmUBdUJqZTqcmM += BldFIS;
            HxzSVpISOxa = itHQnQOywCxwgMv;
            dkJKMypGLowoWVt += npSZXxYLsyF;
            itHQnQOywCxwgMv += dkJKMypGLowoWVt;
            itHQnQOywCxwgMv += dkJKMypGLowoWVt;
        }
    }

    if (dkJKMypGLowoWVt >= string("JCNavZjRrmPOGwWrUMmKNQagsgqfjIcnmNSriYkgwWHPcEjnajYantGoAUeNZLFhxzoMwqiKQszkwzCIZSLsxnWCCTsYu")) {
        for (int yVCGESPiK = 1465168280; yVCGESPiK > 0; yVCGESPiK--) {
            continue;
        }
    }

    return xMKKRHADxL;
}

void IDMXOBV::JTgKOqqPS(double tYRBNp)
{
    int QfuRq = -825721282;
    bool oaAoqeKXmAZha = false;
    int KbBIFOUTH = 2002931814;
    int CYXgfSv = -963665096;
    int MluLOQBJH = -196820226;

    if (KbBIFOUTH > -825721282) {
        for (int NhryAbpvi = 1895485322; NhryAbpvi > 0; NhryAbpvi--) {
            continue;
        }
    }

    for (int UeeGyDFTVbn = 1853735340; UeeGyDFTVbn > 0; UeeGyDFTVbn--) {
        CYXgfSv += CYXgfSv;
        MluLOQBJH += MluLOQBJH;
        QfuRq *= QfuRq;
    }
}

double IDMXOBV::mVtESGccHyT(string cTOaCbGbcrGrIDOF, string cpfrnFHvpJDDfzg)
{
    bool gwjnKVrmygVNn = true;

    if (cpfrnFHvpJDDfzg == string("FJHvnuDOuQzsMuEnnBISGbyujcLIlhnowVIrlidEHtuQdMkVjZgpaLaLpJtxpOaWvxQlUndfxIKxKGyVKWBGjVSStrdOwBFAZOBOTkIjlRNlyIQGuJqjqSXGpQNLjbspylRATeoBUxgRnGHOMAymovWWMVggbTEkRkTMOzUoTndjsvfDmCWVvXnHZGFJqCKyssogVwcXSUmutbcWkyqZckizAlAxklAoxeTPBbXsOZjDY")) {
        for (int OWgMyBSmwCi = 2019698586; OWgMyBSmwCi > 0; OWgMyBSmwCi--) {
            cTOaCbGbcrGrIDOF += cTOaCbGbcrGrIDOF;
            gwjnKVrmygVNn = ! gwjnKVrmygVNn;
            cTOaCbGbcrGrIDOF += cTOaCbGbcrGrIDOF;
        }
    }

    if (cpfrnFHvpJDDfzg <= string("FJHvnuDOuQzsMuEnnBISGbyujcLIlhnowVIrlidEHtuQdMkVjZgpaLaLpJtxpOaWvxQlUndfxIKxKGyVKWBGjVSStrdOwBFAZOBOTkIjlRNlyIQGuJqjqSXGpQNLjbspylRATeoBUxgRnGHOMAymovWWMVggbTEkRkTMOzUoTndjsvfDmCWVvXnHZGFJqCKyssogVwcXSUmutbcWkyqZckizAlAxklAoxeTPBbXsOZjDY")) {
        for (int CsxYE = 43275586; CsxYE > 0; CsxYE--) {
            cTOaCbGbcrGrIDOF += cpfrnFHvpJDDfzg;
            cpfrnFHvpJDDfzg += cTOaCbGbcrGrIDOF;
            cTOaCbGbcrGrIDOF += cTOaCbGbcrGrIDOF;
            cpfrnFHvpJDDfzg = cTOaCbGbcrGrIDOF;
            gwjnKVrmygVNn = gwjnKVrmygVNn;
        }
    }

    if (cTOaCbGbcrGrIDOF == string("FJHvnuDOuQzsMuEnnBISGbyujcLIlhnowVIrlidEHtuQdMkVjZgpaLaLpJtxpOaWvxQlUndfxIKxKGyVKWBGjVSStrdOwBFAZOBOTkIjlRNlyIQGuJqjqSXGpQNLjbspylRATeoBUxgRnGHOMAymovWWMVggbTEkRkTMOzUoTndjsvfDmCWVvXnHZGFJqCKyssogVwcXSUmutbcWkyqZckizAlAxklAoxeTPBbXsOZjDY")) {
        for (int hxAACBphtdKsc = 1357152493; hxAACBphtdKsc > 0; hxAACBphtdKsc--) {
            cTOaCbGbcrGrIDOF += cTOaCbGbcrGrIDOF;
            gwjnKVrmygVNn = gwjnKVrmygVNn;
            cTOaCbGbcrGrIDOF += cpfrnFHvpJDDfzg;
            cTOaCbGbcrGrIDOF += cpfrnFHvpJDDfzg;
        }
    }

    if (cpfrnFHvpJDDfzg > string("PCGvmpzFmjUMGmYlkHELOohEiSaKrjFsOgOrHadtNayvLKUhpNqXMLMtPZfAEbWJHwSKSaOCACDgsaYWSdlMpCdasmaCeXBYJbSzgJaxMIsINj")) {
        for (int XPmVYDt = 713137954; XPmVYDt > 0; XPmVYDt--) {
            gwjnKVrmygVNn = ! gwjnKVrmygVNn;
            gwjnKVrmygVNn = ! gwjnKVrmygVNn;
        }
    }

    return 908116.5537103129;
}

double IDMXOBV::yvDOtlooeR(double JXnAmaNewiYNTX, string KdfgpfuECaA, double UPDKsYxBC, double tCXSxbpFS, bool fouRZRTWMmV)
{
    double ijYxFG = -429678.95658050646;
    string fOFhIADkgfw = string("qWODBMVoPoxtnKoStMtchHNsFlkZQQSLGvOPDGVhyWcrnocwIidgYUFQyZaFIFesIMcuPJVsRcVTjPNpKFBtYQGPjrTXjtGFVEJkNqQBDYxRRpjYtUUZLctTdnVKHHDXwxXJYgElMhoglWcoJPWeISKZVIkMPuKvCUgRJNIrOylCQawgjkVCqRqXJPMROYc");
    bool paLeAHOJ = false;
    bool hAYwfft = true;
    int oFvAh = 1391922201;

    if (hAYwfft == false) {
        for (int weLihSiYuAZhK = 416305582; weLihSiYuAZhK > 0; weLihSiYuAZhK--) {
            fouRZRTWMmV = paLeAHOJ;
            hAYwfft = ! hAYwfft;
        }
    }

    for (int GTxNzq = 1456343418; GTxNzq > 0; GTxNzq--) {
        paLeAHOJ = hAYwfft;
        UPDKsYxBC -= JXnAmaNewiYNTX;
    }

    if (UPDKsYxBC < -63804.68812390387) {
        for (int LcGBfYqNhWLzZO = 278255259; LcGBfYqNhWLzZO > 0; LcGBfYqNhWLzZO--) {
            ijYxFG = UPDKsYxBC;
        }
    }

    for (int wOuxqGZpL = 1585873925; wOuxqGZpL > 0; wOuxqGZpL--) {
        ijYxFG += ijYxFG;
    }

    return ijYxFG;
}

bool IDMXOBV::OrpAqzFJphxSNuDp()
{
    string ZFzrboCfOYpnsn = string("kSNxwMJACXguVyZBxyLSszDTsWnTMaxVFQsGjsmAMlMbzTjkXTOoLEoWRHdZMJvbGqlCUivweoMWKpRhSbHYrNhXyPMdJfPgafrVRgaBptBnNejqayl");
    int XpbcT = -1312665927;
    int nmSSDuCoIASstX = 1990612506;
    bool HMCdKpy = true;
    double ahWcKV = 122373.81647652856;
    string VkoVRWtwgWOhWpRB = string("ioMYvuamXLGyreZWbpXFOMRRhzohZDkQEbNpFBOTYJukfYQNKpmjyRkbljWqCrnfcZFbEhZQwYMPxplJJLZqwuusQPFKZNeoJtWWnRMEmaajAPgHCWXeulfGUzXgmNQTD");
    string zLWoasQc = string("XGXLpuXYXjiIxJLxPTOecpbBafucbtrLtFKyHgmBtlpkQoLMisydLRRwQdTNGSiqpxsoUoajWjWUXffYzieGsyHwPMKTPCYiFyCwligvxqjpwRRUkTTlTAeNOOeZwYdBroGuPAXRHUtsMMBpbuweOdwQYObKLGjPVDfWfIzxQCdoXqSeFZlgajlbZZXCxshNtdtmzN");
    bool mflTRZxxs = false;
    int zzCUSDVfSZ = 420003505;
    int HNmbVX = -1350860022;

    if (HNmbVX >= 420003505) {
        for (int gyachssflfk = 1556611308; gyachssflfk > 0; gyachssflfk--) {
            HNmbVX -= nmSSDuCoIASstX;
            zLWoasQc += ZFzrboCfOYpnsn;
        }
    }

    return mflTRZxxs;
}

void IDMXOBV::PusTfv(int SaGUxWWFdXtOanPA)
{
    string QybFXp = string("pNBEbgdORIVOGOsKijuiXRsqSjFIzaNStzp");
    bool yIwNLOcgsSLqLD = false;
    bool wczufAWae = true;
    int uqvcQVDzrqlGQKl = 2012207881;
    double YPCcUH = -67586.53331148002;
    int fikqUzdX = -279682123;
    double WkMQdGND = 755947.6533289686;
    string XghHnyw = string("CoOAUWkWVEBckoaJNmyuxAceHkTgXCondSKhKGnCHegodRFWgVARLpPQsEszkfhMlnNRSLecKAdwfSOFuytodCEUoAbRlbDNbcQIeUjjDaZMoGCtWXzWnUBBiobceRoXAdBBFAfJImzotbx");

    for (int dXDHkGoJf = 1321387308; dXDHkGoJf > 0; dXDHkGoJf--) {
        wczufAWae = yIwNLOcgsSLqLD;
        yIwNLOcgsSLqLD = ! yIwNLOcgsSLqLD;
    }

    for (int VUHvHH = 836097139; VUHvHH > 0; VUHvHH--) {
        SaGUxWWFdXtOanPA += uqvcQVDzrqlGQKl;
        SaGUxWWFdXtOanPA = fikqUzdX;
    }
}

bool IDMXOBV::kPyRSjP(double RleBai, string rjTRTysiljEv, string avifXdJCrzKbbxw, string BSIFd, int wiOiVEAZqNSnQuN)
{
    bool eDUKzWxWgDsxmK = false;
    bool hwuVao = false;
    string MkEVJpzqq = string("FKUEDvErqMQCEUUOzfROKrsScbzDrSrZBgUKFTnCbYBbuIopWfNqmVagWbfRLiBSOhznwpAghmprHMGBgFLAGTjXTqWTULAQlOMXaYEsWFPKGGBZUEJjRFRjvIqUFtTRdcaOUSAmDftnFLpfZaMHaAYXsEndMrbcIVrmwvyhpSgpTgINMLYyEKYNqDFXJBWSbXBErzxlkzlUDrnBjBIuuvcvILoFXOOMzcQlGFn");
    bool mpJsXaBuFaDyhmtj = false;
    bool rhBNAHuoLgKHUB = true;
    string IQzsAzDC = string("kwDArnVDPKDgvLgChGMNdUJEAkoRdKXbCyWzrXdUuRjvRoGuyATNerZJLawNqDjPIFiKalFOyRdjlMAd");
    string rncNiHzvtzbzO = string("eMqgOViKcdOCsxWNnTKRoXeJSuxmVOxXZwUpAFyZupzHwEgfPTrPZLMEttYvaRJQwgESysnpZKWvXKTqtsnfWexRYoxQPltCfEwWaeTSybAZXDvKprBKXvDzyZhVAPkBOIWpbGNJyBOIvChkCLZeLirkuRNmiRcDcFAMmGOTBqpdnSpseCWrsHobsiihKSXghgepVF");

    if (rjTRTysiljEv <= string("eMqgOViKcdOCsxWNnTKRoXeJSuxmVOxXZwUpAFyZupzHwEgfPTrPZLMEttYvaRJQwgESysnpZKWvXKTqtsnfWexRYoxQPltCfEwWaeTSybAZXDvKprBKXvDzyZhVAPkBOIWpbGNJyBOIvChkCLZeLirkuRNmiRcDcFAMmGOTBqpdnSpseCWrsHobsiihKSXghgepVF")) {
        for (int mNrqJfLjPMmA = 1287088666; mNrqJfLjPMmA > 0; mNrqJfLjPMmA--) {
            BSIFd = rncNiHzvtzbzO;
            MkEVJpzqq += MkEVJpzqq;
            mpJsXaBuFaDyhmtj = ! mpJsXaBuFaDyhmtj;
        }
    }

    if (avifXdJCrzKbbxw < string("xDcsFeJAwobNETsnxRjfopzAFBCygFSchpooHhoCArdNaYwaeKLzONILUhuAOjuBxZoNNuuVZhMvJWJIbTMiiQGljyXBwinKdHcWPTfxsKRFhFousgoJTcXIcXcVlCzfqMjZYElzNDZIazyZjaqehTrHoJTqInnuLBJHKCvfsRVvtFIzRRZHTzldKqzbRYSSOJjPoWjzrDyoKjixyRZcPWGu")) {
        for (int OYTEUyyZvBYH = 846362562; OYTEUyyZvBYH > 0; OYTEUyyZvBYH--) {
            mpJsXaBuFaDyhmtj = ! eDUKzWxWgDsxmK;
            MkEVJpzqq = avifXdJCrzKbbxw;
            avifXdJCrzKbbxw = avifXdJCrzKbbxw;
        }
    }

    for (int YyzHXPf = 444520130; YyzHXPf > 0; YyzHXPf--) {
        rncNiHzvtzbzO += rncNiHzvtzbzO;
        rjTRTysiljEv += IQzsAzDC;
        rjTRTysiljEv += BSIFd;
    }

    for (int hZMWjaxywTzFALg = 710441604; hZMWjaxywTzFALg > 0; hZMWjaxywTzFALg--) {
        rncNiHzvtzbzO = IQzsAzDC;
        IQzsAzDC += BSIFd;
        BSIFd = IQzsAzDC;
    }

    for (int eTpxKsNoVmV = 1939307463; eTpxKsNoVmV > 0; eTpxKsNoVmV--) {
        rjTRTysiljEv += rncNiHzvtzbzO;
        BSIFd = BSIFd;
        eDUKzWxWgDsxmK = ! eDUKzWxWgDsxmK;
    }

    for (int NaUAlMvJiMLoSQ = 1398711301; NaUAlMvJiMLoSQ > 0; NaUAlMvJiMLoSQ--) {
        RleBai = RleBai;
        IQzsAzDC = IQzsAzDC;
        rhBNAHuoLgKHUB = rhBNAHuoLgKHUB;
        rhBNAHuoLgKHUB = ! mpJsXaBuFaDyhmtj;
    }

    for (int JMlRFIKdzdbPSdTw = 612606294; JMlRFIKdzdbPSdTw > 0; JMlRFIKdzdbPSdTw--) {
        mpJsXaBuFaDyhmtj = hwuVao;
        BSIFd = BSIFd;
        avifXdJCrzKbbxw += rjTRTysiljEv;
    }

    return rhBNAHuoLgKHUB;
}

IDMXOBV::IDMXOBV()
{
    this->MLFrusRKd(string("ZVBPyoHDdpdpeOPddEFQPwlsYQgfKWiGEplDUmEFhMGwVJpAGJVeWgUCqQKQfugTUiCSxEVDYSSJZAgkGjwkWygQYjdfdRCaqkaXQnBCNBIFDfStKhhXCnvqwMfgUGFCyYGeCNAUZrgvpOBxJPyqHpDPXDfRzFdGKXYtpCtZgHDKjEzKwxGCLaXziFME"), string("iqKWBoBQAbvjqxFftwkVYbZbQuOwcSMqXQjcAjdbFVJLDPtQsogwttPtNzvBDZJudEBphUqYEIGVWStygEZEbsbTgVCSFBRTuPyxvisOYbdfjuKvUovZYpHYTUARlcpmxQIAUDtGHCXqZJTvdhaUHGTO"), 150328.97798502995, string("YOTvfUtMsycqGssWf"), -2021247150);
    this->JTgKOqqPS(-947384.866656378);
    this->mVtESGccHyT(string("FJHvnuDOuQzsMuEnnBISGbyujcLIlhnowVIrlidEHtuQdMkVjZgpaLaLpJtxpOaWvxQlUndfxIKxKGyVKWBGjVSStrdOwBFAZOBOTkIjlRNlyIQGuJqjqSXGpQNLjbspylRATeoBUxgRnGHOMAymovWWMVggbTEkRkTMOzUoTndjsvfDmCWVvXnHZGFJqCKyssogVwcXSUmutbcWkyqZckizAlAxklAoxeTPBbXsOZjDY"), string("PCGvmpzFmjUMGmYlkHELOohEiSaKrjFsOgOrHadtNayvLKUhpNqXMLMtPZfAEbWJHwSKSaOCACDgsaYWSdlMpCdasmaCeXBYJbSzgJaxMIsINj"));
    this->yvDOtlooeR(-63804.68812390387, string("lcqoXTvyEapokEeRyJxuYgmjGuPVkmW"), -600694.1622038393, 607626.8055539869, true);
    this->OrpAqzFJphxSNuDp();
    this->PusTfv(1726964137);
    this->kPyRSjP(-518781.3339431681, string("xDcsFeJAwobNETsnxRjfopzAFBCygFSchpooHhoCArdNaYwaeKLzONILUhuAOjuBxZoNNuuVZhMvJWJIbTMiiQGljyXBwinKdHcWPTfxsKRFhFousgoJTcXIcXcVlCzfqMjZYElzNDZIazyZjaqehTrHoJTqInnuLBJHKCvfsRVvtFIzRRZHTzldKqzbRYSSOJjPoWjzrDyoKjixyRZcPWGu"), string("sSmdDRfySiEmzaRiIvUJDfiIEDKlnehCYoAMwPxiRWBvldqLUHKFTomROJSPUVnAIIuLHKvBddUaRhpFnvnzJrinNNjZeVeqnTuTBeWIQCvcmNYYbMVbRGCoIgsywFkkQNgtSiIFZbckNQqhTZKPcnKIcHIoTMLmlUvnDjvACMcntfhSFAHLmrdgECHebAZJNaswxOsNyJxEIRJfqcKSQecCXabmlTkbWv"), string("CWxETMZSGiueRtvBcsnxXWspriIhROTmrKiwKmOdWhayeWXsoxrNjqEFyERgOPvYqxVPpjRHpdRZtymfyfhYQGrXzvbpiHmtLLKEnOnBhfoHobjUBqUFQBSMfMGsHHHCbkqWZGmMFTVEInbyrflnlaRsCsdMoBmJgTugICJzsoJa"), -1088997613);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UtiIQkCxakBLm
{
public:
    bool eHtfdPpi;
    bool nusglbIPU;
    bool YzPtEtZrJbpaDM;
    bool NrzPbccuComkimwQ;
    string bUzVfZNgcyvq;
    bool llLukX;

    UtiIQkCxakBLm();
    double ScRFxBJYEXLbCP(bool nrvRRjjjEvurcVW, double nJiLleIqQd, double PrlvzQetypWD, bool UTWjVdsvoHJsl, int hnSxzMo);
    string aakDWyBqCVXLnZM(string zxwev, bool kZeNpv, string UAHXrBEbNucjdO, string LfezBZit, double IZCNj);
protected:
    string HLXJtxfyrRFxtt;

    string AJSheHAlGgh(string FYcHmC, string zqQtbwLi);
private:
    int MSQRDZgbOGM;
    string nconhNahJQOoIHR;
    string lNNcqht;
    int yacZezwTuyz;
    string fSglJdEzRBal;
    bool gTWlIgPSh;

    void WfGXHMFUaRVqkiS();
    int uUollNJ(bool XNEKunxYR);
    string FbSZEwB(int RHEQqKGjtUV, double vdObqA, string TIgSNCYyHoiAPS);
    bool SaTRjJ(double hRwDwhRJeV, double isrpYYE, string DCOzwGjXqsWd, int nxcANd);
    void mONzSYiUSuK();
    int CTRYKUEYy();
    double vJDKVNXlCBRvUFbC(bool lwZMKHKKqpzA, string ItGpKvfFbIFTST, double nexkKmjfFpREzNCe, double ipTgWgAK);
};

double UtiIQkCxakBLm::ScRFxBJYEXLbCP(bool nrvRRjjjEvurcVW, double nJiLleIqQd, double PrlvzQetypWD, bool UTWjVdsvoHJsl, int hnSxzMo)
{
    int GfaNjuoJHzLyJt = -1515603184;
    string pabBwgehoEAQqSba = string("xwRQVtHSeMruQnqCpZVXhkmTsepxLteDXbHBzKduLZUwyFRjsvuwkEyJyfUpAokGvKQKpmtvDVNXKlCYkAJFBgvfizMCoyXFDAAZctlnTMsGRgMaXhEtOpBkRnxulUXbkoBnHPiVDejSwOhSlSlErmpHtG");
    int xEIqkYDi = 653302669;
    int dxSLpvxjWgudrv = 1266729900;
    int PttyIaqZnBvSi = -617223292;
    string xbpdDeplC = string("v");
    bool KDmix = false;
    bool GGcoFvoKuFrQbf = false;
    string IsTTvzvjGgimg = string("pRkuCPLDAtHirQLBHJFGzuyLnfzXJZMbOwnhyVdATCdhPfEOhAwzRhNaQeeIvDBvkjFRfsmCrkPotbxGBjvTmyGQoJVITsQJxFWEiDmSbrCASHiPugWgothzsvmRuvcKTJQoaUTjYTdCHrNpaOKwbElnTqEaTDGAlpFRMHUoHcumEoeNnaP");
    double qCXxKUbNYcck = 803424.9063323388;

    for (int XvHyc = 1137428161; XvHyc > 0; XvHyc--) {
        nJiLleIqQd -= PrlvzQetypWD;
        xEIqkYDi -= xEIqkYDi;
    }

    for (int olVBo = 1768372666; olVBo > 0; olVBo--) {
        continue;
    }

    for (int QTtnMmWlhwUq = 174818688; QTtnMmWlhwUq > 0; QTtnMmWlhwUq--) {
        nrvRRjjjEvurcVW = KDmix;
        GfaNjuoJHzLyJt -= hnSxzMo;
    }

    for (int fdaJmYHJP = 1066500220; fdaJmYHJP > 0; fdaJmYHJP--) {
        PttyIaqZnBvSi += dxSLpvxjWgudrv;
    }

    for (int nKOjuJLJhpuEx = 1885149354; nKOjuJLJhpuEx > 0; nKOjuJLJhpuEx--) {
        xbpdDeplC = pabBwgehoEAQqSba;
    }

    return qCXxKUbNYcck;
}

string UtiIQkCxakBLm::aakDWyBqCVXLnZM(string zxwev, bool kZeNpv, string UAHXrBEbNucjdO, string LfezBZit, double IZCNj)
{
    int lTmVPgYbd = -895076018;
    bool rBEBHwCWMA = false;
    bool ZEnXRP = true;
    int FDxCbRiGlW = -1374166863;
    bool lkXFsU = true;
    string UjDGPOdeF = string("XISpAPqEfwrZpShYwcLgiYkamCmsnidRVsVNXVYerjvnFFlvFneaxSYrZzixIcKtrhxydXgLZTWeGfKznBtAkIpuEMLMtNqEOMmAEXjVuASMYgettYQRAOugA");
    bool eBWkbZeFIql = false;
    bool GavvRTnT = true;
    double PWdvTmiVJq = -864719.1593710363;

    if (ZEnXRP == false) {
        for (int vcLwXBdqjWBLkQnD = 817432839; vcLwXBdqjWBLkQnD > 0; vcLwXBdqjWBLkQnD--) {
            ZEnXRP = ! ZEnXRP;
        }
    }

    if (lTmVPgYbd != -895076018) {
        for (int VsChzqVfK = 1527243289; VsChzqVfK > 0; VsChzqVfK--) {
            continue;
        }
    }

    for (int TYEBCXyAAcJDvH = 1029271284; TYEBCXyAAcJDvH > 0; TYEBCXyAAcJDvH--) {
        UjDGPOdeF += zxwev;
    }

    for (int WWNwk = 1576390149; WWNwk > 0; WWNwk--) {
        UAHXrBEbNucjdO += UjDGPOdeF;
        ZEnXRP = lkXFsU;
    }

    return UjDGPOdeF;
}

string UtiIQkCxakBLm::AJSheHAlGgh(string FYcHmC, string zqQtbwLi)
{
    string elZUigG = string("IMqYYUhLXVbPgoXBRgWfWAtwFsupGyeHxBkkNXURHTOkvmTRLUQdisAAWAWcksADFYBSPePGCRbAnxYdYgXuxfPruTxFVKPNmJDaYcVUQZLDMmTFSarWeJZwfqlIrcMouqmgvJkodZddeuCcJTRBtEgmrOcAFKMJNYcfZiyEuKNPNTraNilrKEnkTZwAOzPVvhYocqiJmnauIBDZPfJqxRJbJiHbWEiCWAZXSvceXGiQbYCCCfqW");
    double NsJzqUcNkHRcQle = -891918.3737878765;
    double SlJtQiB = 252753.95435199168;
    bool CUsaltFiDDcwrlS = true;

    if (NsJzqUcNkHRcQle != -891918.3737878765) {
        for (int GAjQPSM = 534079602; GAjQPSM > 0; GAjQPSM--) {
            SlJtQiB -= NsJzqUcNkHRcQle;
        }
    }

    return elZUigG;
}

void UtiIQkCxakBLm::WfGXHMFUaRVqkiS()
{
    string IIfTbthwgJZd = string("giIdOLGyTlVGdsxsrnSjGsfswgRsGREIIAbaQxmjhhgHbAomNGUvqylpCCJrfsGPnlqdScLvcmOhOlODddhUbGIXnrOMLFHWkFBrzGWWbfCiAqKFqrNEzdDQkgXiGosLCmRPpMVAIEPqPUNcqqntKutfsBmgIriXhrLScrYxdpbWHXkJkbPZLUzGZCjBjJgHEwDjohbezJaRYCHPbsOIuZnjQYxTcdfqhFNAGSDmymsnBBnOYMd");
    int vPSQdYIvZX = 547541928;
    string bAUqbkFFi = string("nwjZEORmjMGRnUmsTAVbAGFdSoGwnMhaSeVrHOgVFUfaeoQvmsDQcnHDEFDnrKLSiJefFbASRQIdPaOPbtMyktFIPszqCpeoQAmknFGdUdaglkyNcrMvogAXkTPcPYjzlCRBLhPyEjLXFvUyqqoiKgWvxOpsCFNOXAFjDhAxTXTfGyPenpTjOrwgMEtyQERERZKEtkDoNZbVPGEVPJXjKFkGDAncfrRmpxqHECEWtOonPFUtjZYyo");
    int WeSidSkhc = 2019924818;
    string YOynqqviJRfhGvx = string("ssSOkmecRqesIOsxDcOpjhroLPBVTewjfJxVDvJypfWmftKhySeCdsFMdxOKmvGfj");
    int inqGrW = -1675220558;

    for (int pPGsMnReYJHuOkz = 656771385; pPGsMnReYJHuOkz > 0; pPGsMnReYJHuOkz--) {
        YOynqqviJRfhGvx += bAUqbkFFi;
        WeSidSkhc *= inqGrW;
        vPSQdYIvZX /= inqGrW;
    }

    if (vPSQdYIvZX < -1675220558) {
        for (int MdBmNLy = 1872104182; MdBmNLy > 0; MdBmNLy--) {
            YOynqqviJRfhGvx = IIfTbthwgJZd;
        }
    }

    for (int dCJrO = 174787167; dCJrO > 0; dCJrO--) {
        inqGrW = WeSidSkhc;
        WeSidSkhc -= vPSQdYIvZX;
        vPSQdYIvZX -= inqGrW;
        WeSidSkhc -= vPSQdYIvZX;
        vPSQdYIvZX /= WeSidSkhc;
        vPSQdYIvZX -= inqGrW;
    }

    if (WeSidSkhc >= -1675220558) {
        for (int SRVFjjj = 899807349; SRVFjjj > 0; SRVFjjj--) {
            YOynqqviJRfhGvx += bAUqbkFFi;
            inqGrW /= inqGrW;
            vPSQdYIvZX += inqGrW;
        }
    }
}

int UtiIQkCxakBLm::uUollNJ(bool XNEKunxYR)
{
    int McURoEeGNuURFe = 2007255293;
    string rGfCTETBmFEhpYjN = string("THpEQaujlAUVcntyKHvZFleALnhnNoiOWZwCJsFwhFspYkTxXZGRfRsPiiFlpTtlRvVIlKZlgaiQiQtxOHFCAZREqBGJyCFgcBvQKVONuHoLyFSuBSjAvjLsRbKLbImrIOztUNuakLOhDhFZVCJdiQnLTHghVCPNioxNkoXnyOTAukoQVlvGhqYuliRhMulAucTpurySyASXWWTkWYPfVqoMwoCEBqaLWUbkKrztbkdVNsHWjI");
    string mkzWZZvRkudlIp = string("VVYRiiLrXEiCtasnoIOSpFRDWAqpHuDeFAvNoWtLumqkVWWPsWYHlDYnjTVqHBooErPWiwbRscOYavIdjQrfGJKMPpdbBKkNkKpmEYAsPtuuyttIJsXIEmBgcyNOasHlzQgvjolgEhbdJIumtFiTEyNfVGYXaJGfDmennvcXjJuqdjlyXluUgqURsqJHzQneiWdeiXlzgvRTANIfgiJIMylbyIPdFxdBDoJSY");
    double zduKuREFsFNIq = 961548.0812611758;
    int tqLtIfjjEqHbI = -876249187;
    double ecKfzWDOyOsQsM = 526359.3838541382;
    string zirkAajV = string("fpjyYLpAKvdrMiKBgMEfUabeLLAEncHrKanDHHHMJoXRsnnuvBHKZNKKMgAbfsLfkaKYGhcDOpLxjAiQKKZfkROFcYtungpwePlGhNzWDrNBPYoKSjtZyqelhoHQtDbHslPnQYbzrJtCuFGAUDKlwPljACGvFRdWyQPTcyIJHSFGJRhRpN");

    return tqLtIfjjEqHbI;
}

string UtiIQkCxakBLm::FbSZEwB(int RHEQqKGjtUV, double vdObqA, string TIgSNCYyHoiAPS)
{
    double mSvricq = -354548.45597736357;
    int ShrnSmgMhxeSsVyG = 1049023306;
    string KLmZzyRZf = string("oOFDTTSQMKzURjDqXPeEoMsNRoznmXvAFweTEuIUsvtoUlpevuwCguPQvJyEXaxHGyqViilTisLJhNWaDamZwGIANKUFKhGRlmaRRTDyjMSDDqTKaxJInxdXzfaYrzUkVvJrdSQBPaqtfLZQAyfKWXhQlnJyDxrLrcgIxcUAgauvGeWGMzyOICnawfhfMtaWPjCBBQiwnisUMApUdNrcWU");

    for (int djdEcHecliCWkstH = 109249378; djdEcHecliCWkstH > 0; djdEcHecliCWkstH--) {
        KLmZzyRZf = KLmZzyRZf;
        mSvricq *= vdObqA;
    }

    if (KLmZzyRZf != string("oOFDTTSQMKzURjDqXPeEoMsNRoznmXvAFweTEuIUsvtoUlpevuwCguPQvJyEXaxHGyqViilTisLJhNWaDamZwGIANKUFKhGRlmaRRTDyjMSDDqTKaxJInxdXzfaYrzUkVvJrdSQBPaqtfLZQAyfKWXhQlnJyDxrLrcgIxcUAgauvGeWGMzyOICnawfhfMtaWPjCBBQiwnisUMApUdNrcWU")) {
        for (int VHqkCbMwlaKBM = 1903760443; VHqkCbMwlaKBM > 0; VHqkCbMwlaKBM--) {
            KLmZzyRZf += TIgSNCYyHoiAPS;
            ShrnSmgMhxeSsVyG += RHEQqKGjtUV;
            KLmZzyRZf = KLmZzyRZf;
            TIgSNCYyHoiAPS = TIgSNCYyHoiAPS;
            ShrnSmgMhxeSsVyG *= ShrnSmgMhxeSsVyG;
            KLmZzyRZf += KLmZzyRZf;
        }
    }

    for (int rWPVxdLOsoNlg = 1814502828; rWPVxdLOsoNlg > 0; rWPVxdLOsoNlg--) {
        continue;
    }

    for (int WkWdeVSV = 1873437743; WkWdeVSV > 0; WkWdeVSV--) {
        RHEQqKGjtUV *= ShrnSmgMhxeSsVyG;
        TIgSNCYyHoiAPS = TIgSNCYyHoiAPS;
    }

    return KLmZzyRZf;
}

bool UtiIQkCxakBLm::SaTRjJ(double hRwDwhRJeV, double isrpYYE, string DCOzwGjXqsWd, int nxcANd)
{
    double UhMUJ = 511508.39770830976;

    for (int ppmpRvzVuU = 831970468; ppmpRvzVuU > 0; ppmpRvzVuU--) {
        continue;
    }

    for (int XDmGsxMSR = 2059559874; XDmGsxMSR > 0; XDmGsxMSR--) {
        hRwDwhRJeV += hRwDwhRJeV;
        UhMUJ += UhMUJ;
        isrpYYE = hRwDwhRJeV;
    }

    for (int LBUXQtbjGvGUIY = 237029085; LBUXQtbjGvGUIY > 0; LBUXQtbjGvGUIY--) {
        hRwDwhRJeV -= UhMUJ;
    }

    for (int SimgRYnHeUOAlnp = 396627811; SimgRYnHeUOAlnp > 0; SimgRYnHeUOAlnp--) {
        isrpYYE = hRwDwhRJeV;
        hRwDwhRJeV *= hRwDwhRJeV;
        hRwDwhRJeV *= hRwDwhRJeV;
        hRwDwhRJeV += UhMUJ;
        nxcANd -= nxcANd;
        isrpYYE += isrpYYE;
        isrpYYE = hRwDwhRJeV;
    }

    return true;
}

void UtiIQkCxakBLm::mONzSYiUSuK()
{
    bool jwNTblZGn = true;
    bool YOQKgIcigg = true;
    string RNGfDTROXBug = string("KbyWmUpmLcAIneWkvAqgyyxaEqbqRqHsComCWeJwgjroWcOucSvMerJdRRoyCNArmnqltlBcntLLvukgsBDklvFJopOULsifjAvWhjCEaJAylDqcNhgnjgOplhjKQroSpDCTrlIEqpivQpqlvmxwfxWsvhmdcfEoiUWptsmhjWkeKp");
    int OxkREoEsv = -1889229663;
    bool mxuORWutMzYzsgsA = true;
    string ZOjCONUvYkcgrz = string("TQtfxaEsKPFBUSaaPZwCufULTBkdTAeXfkFGVkrMJBlrEATAXVpTxlAtbXXgBKsiwiMcPuGnbCxFdvkwGBlLBJyIzmAKcpWMjpDXwQYPdXeYjEYHKhrSkHvcborXLnXQPYfHuZByfQrcMCEHivWBmpSGSCKJspjPPxjyUiITYruujTFWLMklHVKwaQEAT");

    for (int KIagOnywJpXnpdll = 389342954; KIagOnywJpXnpdll > 0; KIagOnywJpXnpdll--) {
        continue;
    }

    if (jwNTblZGn != true) {
        for (int GkCHlS = 61386626; GkCHlS > 0; GkCHlS--) {
            ZOjCONUvYkcgrz += RNGfDTROXBug;
        }
    }

    for (int tcKnQzRqxKbGWitz = 256614621; tcKnQzRqxKbGWitz > 0; tcKnQzRqxKbGWitz--) {
        jwNTblZGn = ! YOQKgIcigg;
        mxuORWutMzYzsgsA = ! mxuORWutMzYzsgsA;
        YOQKgIcigg = YOQKgIcigg;
        YOQKgIcigg = ! mxuORWutMzYzsgsA;
        jwNTblZGn = YOQKgIcigg;
        ZOjCONUvYkcgrz += RNGfDTROXBug;
    }

    for (int amZCIQytnX = 396437678; amZCIQytnX > 0; amZCIQytnX--) {
        RNGfDTROXBug = ZOjCONUvYkcgrz;
        mxuORWutMzYzsgsA = ! mxuORWutMzYzsgsA;
    }

    if (jwNTblZGn != true) {
        for (int oDsUTfFdpeiUYFn = 643045507; oDsUTfFdpeiUYFn > 0; oDsUTfFdpeiUYFn--) {
            YOQKgIcigg = mxuORWutMzYzsgsA;
            YOQKgIcigg = jwNTblZGn;
        }
    }

    if (mxuORWutMzYzsgsA == true) {
        for (int GpVaFMd = 867176087; GpVaFMd > 0; GpVaFMd--) {
            continue;
        }
    }
}

int UtiIQkCxakBLm::CTRYKUEYy()
{
    double dBqGcZkRP = 796630.8632616625;
    int xYTqYKTxJF = 1814175977;
    int JybVUicPuI = 914811370;
    string saZSfGh = string("hQqmPoWJcCTlzyoNyvLmivWxwQKSGCJwHAaINrRKnTYgfosFyIcBhejDOjenZKaxQbhKrxGjvwFLQTuMzawFSMNJEfPGRBhqqXFLqatAOKvHwGjjCFdSPmEdYfsJLqZCzdnJhDWRTjSETyAjYHCtaIAyyVO");
    int ttXhVjI = 1702935350;
    int YrehEIs = 1668343448;
    double mzACEggsKTPAsIMI = 570033.2920969311;
    double OXAmCsQgBidm = -1026206.1566136039;
    double TNEMRDH = -947217.9101715111;
    string YpuuyHCfyedfMbB = string("xDVoDXRpNyvWUSeQMtSqWHADYTjXxzcafPxEyBAvvdFjndSvEIbcZWeCkhNYOXeRQEXnshPJwnTKQeBbVLQxIuPRkuXUkMjarinrxbdzuJMmvTqiouKlXQtjSmXADnfCUdzqxEvyLJRJViaOIeZlNmQKvNhNTNsixlEpZmeckMJHRjDdhMMPCRgPJEbUITKpopjLvyQNRxKpRQAIVWdkLCoxPpuBzeKCessyalnctLMkYZklpbaw");

    for (int VCzXPVoDo = 1218187662; VCzXPVoDo > 0; VCzXPVoDo--) {
        ttXhVjI = xYTqYKTxJF;
        dBqGcZkRP /= TNEMRDH;
    }

    if (YrehEIs < 914811370) {
        for (int aJoRxmYKxPAZcmuN = 942452381; aJoRxmYKxPAZcmuN > 0; aJoRxmYKxPAZcmuN--) {
            YpuuyHCfyedfMbB += YpuuyHCfyedfMbB;
            xYTqYKTxJF += xYTqYKTxJF;
            saZSfGh = saZSfGh;
        }
    }

    for (int Fbvbr = 331354732; Fbvbr > 0; Fbvbr--) {
        OXAmCsQgBidm -= TNEMRDH;
    }

    return YrehEIs;
}

double UtiIQkCxakBLm::vJDKVNXlCBRvUFbC(bool lwZMKHKKqpzA, string ItGpKvfFbIFTST, double nexkKmjfFpREzNCe, double ipTgWgAK)
{
    bool PAsOCbRDpeKMk = true;
    double IBZQT = 697415.1909992427;
    string huMSOhNDaYDp = string("ewwoJsEQprJwB");
    bool CbaBmpjXBPmeme = false;
    bool HgpeDVX = false;
    double XpiXiroDi = 441965.8602987208;

    for (int QatfGiw = 1493024754; QatfGiw > 0; QatfGiw--) {
        CbaBmpjXBPmeme = ! lwZMKHKKqpzA;
    }

    for (int FEquPBMdiIlS = 1426868510; FEquPBMdiIlS > 0; FEquPBMdiIlS--) {
        CbaBmpjXBPmeme = HgpeDVX;
    }

    return XpiXiroDi;
}

UtiIQkCxakBLm::UtiIQkCxakBLm()
{
    this->ScRFxBJYEXLbCP(true, -849440.6286672921, -168907.07096930896, false, -650536169);
    this->aakDWyBqCVXLnZM(string("lsAzCsPpCvWqmmvxHlkqurdieQuFlFJYahAhMGFtKPiLoEdmYGnKscoGuqoUASMebKxpKAOBidGcOlGqSkULqXWMFPAblqpnIQfSeEShswOzlsMplevjXttxfKwFfbfrxUsxiTptIIeeXEuLnUDHdixzfozEgmGvuiSxvocldEJrfYbFAhEdwN"), true, string("xmUkrdNzuxXZYrjOpWpJIIpMtmBDxWJdNiKgFEnIzTt"), string("BnOpUrawntxmiPsEMFTgsQXUMonMJwpakFEcnqLMduCfyGgxOKvGZagkqJrZMqbcCenPsPOeHyXMUJyMcLtDSlPYamPTNMUJMDIej"), 15645.545824507128);
    this->AJSheHAlGgh(string("gHFrygcReYundvOmmeODfqpefmTczkCqXcRMAhpJHWabnQfizEMFmgwmSUQsgMPHZlpnyQuOKeXthQkQvsyoDRWgwndUUymfnhAAFICjNbOykTwZScrMXUsObkIkkMqdvuYfjfxlPjhDfxojLiRAsFWgAVBwQVuVVQAsNtGCnlkaSgDpTgzjTYPuxBVkjvm"), string("aRQMTisMHCvIUmBVdSnioibEOTSPVLqHLcyerQvdQmrbAXtwfHsFgsUoEzeYguEmDjFCzQSDP"));
    this->WfGXHMFUaRVqkiS();
    this->uUollNJ(true);
    this->FbSZEwB(-2014993541, 152322.48959203626, string("XZEcTmQJQQogguAapNfYSFKNuRLccluQqnZzaRSkUPoEsGYflrjuHFluBrtxGYhnQOhRdFuRqyzRtaJxSLGeYsQzQkTsaysDiXoOBelyOiONKIYVIuAzpvpCUXhQitoyqofcNwCsNazAQwuwZUiamrtsMUUDsgiRaiKw"));
    this->SaTRjJ(1004085.3905135946, 691189.7004862101, string("jIOEEAgXZrNACnqDvqzTOnEaIFQoUOKWXvsRSYbxMEmVrsDtkxfa"), -1721518236);
    this->mONzSYiUSuK();
    this->CTRYKUEYy();
    this->vJDKVNXlCBRvUFbC(true, string("yXDRSMqTovJhTBYDnOgqgFBksEJlbyldVcztRJzhGUAYKuCikYLhENeXoGxwSadBxUPGyamEYtjfULZJzEyltJJxIArPMTMbkCeSlyGXMcttMhzUkNjNXSrqtKLaFGhQmUtvMuPBnAuELBJlcWGJGLRaPHapWATKaW"), -594720.1594651158, 988242.7389474194);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class phqceALnDPGtd
{
public:
    bool ojBQhKVgINFASmNh;
    string DNToLhbFklV;
    int jUYQSHUaFPK;
    bool nZutdes;
    int dIWJIJMuzwtUP;

    phqceALnDPGtd();
    double CfuIESb(int SiQsRHDZOqLGkIbb);
    void vhxTPQ(string RoHxgvg);
    double sCWmPEzFmpXU(double rQJYQfrh, string tPZUv);
    string UXptMoAyWHn(int zDlLBWJZvrmR, int GvXVMJ, int YpYqCorlFjk);
    double JSfFyFxgPCop(int IIIgSDOzkUgUiHKO, double TwvibaFUVxgY, bool WHSpJvVWA, bool vpTcmPvXUSm);
    bool htOeZg(double mpNQZBxKEae, bool zqGob, bool qQRvVL, string GbArt);
protected:
    int GHeZCIhSjXzBC;
    bool ZkdRjFnbeUPP;
    bool zLjIXrQHQnA;

    int OXyggTIJEvJeKd();
    string YxwzCkisUdKV(bool WJwxEbN, int zTLiVnPGwJZquC);
    string jKXoCy(string yXxzjqmJF, string KINFgvYSzZ);
    void rbtvl(double ntURwmfsViQTB, int ungrmg, bool PmhJNUpKcHzJv);
    double WAtBwxbjHvoaDA();
    int quTjM(double ITTWDJpANIACx, string ZjcfrxPIuz, bool dAHuywvAhjy);
    int FWBSMaEJtTPCS();
private:
    double jbnYC;
    double owZOeMQXU;
    int IwIUpcaVzTjeNVyI;

    int FkxjJEd(double vrfKB);
    int rSrkDFCQPWb();
    double hXimfeMKsMj(double AWeFGabfQrP, int eyXrRfveBlmSqUPL, string BpGXKH);
    bool cnCKGwMDHdUDQ(double CWmlE);
};

double phqceALnDPGtd::CfuIESb(int SiQsRHDZOqLGkIbb)
{
    bool ExYUzsTof = false;
    double udwDoydkmLwYs = 336246.3085762758;
    string tcufTGPeyckEfwDg = string("ijOUjhXKUPQYZfI");
    bool jBEHmSjU = true;
    bool DXXLpCyWtSG = false;
    int zTyqVst = -256563335;
    double xlsqY = 1047404.3407206977;

    for (int tFpZCZgXK = 855650894; tFpZCZgXK > 0; tFpZCZgXK--) {
        SiQsRHDZOqLGkIbb *= zTyqVst;
        ExYUzsTof = DXXLpCyWtSG;
        ExYUzsTof = ! ExYUzsTof;
    }

    if (udwDoydkmLwYs < 1047404.3407206977) {
        for (int sxdCMgZaFQnNUFbB = 647268909; sxdCMgZaFQnNUFbB > 0; sxdCMgZaFQnNUFbB--) {
            jBEHmSjU = ! jBEHmSjU;
            zTyqVst /= SiQsRHDZOqLGkIbb;
            DXXLpCyWtSG = DXXLpCyWtSG;
            xlsqY /= xlsqY;
        }
    }

    for (int CihPC = 1727993181; CihPC > 0; CihPC--) {
        xlsqY *= udwDoydkmLwYs;
    }

    for (int jtnQqhOWbOLNYDIo = 119775939; jtnQqhOWbOLNYDIo > 0; jtnQqhOWbOLNYDIo--) {
        udwDoydkmLwYs /= xlsqY;
        zTyqVst /= zTyqVst;
        ExYUzsTof = jBEHmSjU;
    }

    if (jBEHmSjU != false) {
        for (int RtJcbatKRfehgvYD = 1665639321; RtJcbatKRfehgvYD > 0; RtJcbatKRfehgvYD--) {
            jBEHmSjU = DXXLpCyWtSG;
            jBEHmSjU = ExYUzsTof;
            ExYUzsTof = ! ExYUzsTof;
        }
    }

    return xlsqY;
}

void phqceALnDPGtd::vhxTPQ(string RoHxgvg)
{
    bool HtvRBa = true;
    string QzNBcgcpoNmam = string("WzOMPFWjcbDFO");
    bool mCVlk = true;
    bool bMPoTf = false;
    double swosnlRLGZX = 1009886.5658305108;
    string UfaKBnyjRGNkq = string("rVcPzsHULwDuVovzgghUYykjPezlSyGnpoEEFzhPUAbIZyiZZOQrKuqLcDxpjRIvfHITIDyOePOiqQVjoizLeYgMGAualUlACZNghjEYZiVjNVFujkDLpZRywVrITFmtIbKQkWhnUN");
    double aXyuOzQnilAXj = 1035762.4003205325;
    double KpjUOWgTWAFMCW = 562699.6354316988;
    bool AkIwzwNtgKb = false;
    bool eLqMwIhZlnJWQyB = true;

    for (int zIIqJEPtFv = 642948475; zIIqJEPtFv > 0; zIIqJEPtFv--) {
        mCVlk = HtvRBa;
    }

    for (int QAmgc = 731011216; QAmgc > 0; QAmgc--) {
        mCVlk = ! HtvRBa;
    }

    for (int FpTIrzDPySdGyOwI = 411548765; FpTIrzDPySdGyOwI > 0; FpTIrzDPySdGyOwI--) {
        HtvRBa = ! AkIwzwNtgKb;
        KpjUOWgTWAFMCW -= aXyuOzQnilAXj;
        aXyuOzQnilAXj += swosnlRLGZX;
        mCVlk = ! eLqMwIhZlnJWQyB;
        AkIwzwNtgKb = ! HtvRBa;
        RoHxgvg = RoHxgvg;
        mCVlk = HtvRBa;
    }

    for (int iibqPCsUMUE = 1178384667; iibqPCsUMUE > 0; iibqPCsUMUE--) {
        eLqMwIhZlnJWQyB = bMPoTf;
        QzNBcgcpoNmam = UfaKBnyjRGNkq;
        UfaKBnyjRGNkq = QzNBcgcpoNmam;
    }
}

double phqceALnDPGtd::sCWmPEzFmpXU(double rQJYQfrh, string tPZUv)
{
    double jgisxQPpJLZxxRDS = 576466.7468859109;
    bool FJbDUx = false;
    int TiyrLhzRbhkaqMvQ = -113878753;
    double KqFPjbrP = -561583.1567933308;

    for (int OzMQYSyeIUcfmhw = 139903201; OzMQYSyeIUcfmhw > 0; OzMQYSyeIUcfmhw--) {
        continue;
    }

    return KqFPjbrP;
}

string phqceALnDPGtd::UXptMoAyWHn(int zDlLBWJZvrmR, int GvXVMJ, int YpYqCorlFjk)
{
    int xPItDfxj = -2116967222;

    return string("hKoIUPfudHgohHHbZDVisFuTTIhwrqZcdHVdUAnUaOdAxEgwxAYfFPxSzKlNskgMjibOgDzYvPqhLjtenJhKbjoIOHkAfOneSimeVWUYJqqdjrHuYMdiiKOXtLPytMPGDcZuEuXhQvXxtBDkBskoEpCVDCdeAjCPdWnxjKBjZyyTBznhNLiVRYOPPcBWOoCWVFGqZlatoNaNQRIwfqqEjXzgKob");
}

double phqceALnDPGtd::JSfFyFxgPCop(int IIIgSDOzkUgUiHKO, double TwvibaFUVxgY, bool WHSpJvVWA, bool vpTcmPvXUSm)
{
    int OoEayTePYyWKUnYb = -1956092202;
    double STUdCsFPhmfyc = -341465.57658770756;

    for (int hYQQScI = 1007216398; hYQQScI > 0; hYQQScI--) {
        OoEayTePYyWKUnYb *= IIIgSDOzkUgUiHKO;
    }

    for (int QwfNEHlBVMM = 1197290924; QwfNEHlBVMM > 0; QwfNEHlBVMM--) {
        vpTcmPvXUSm = ! vpTcmPvXUSm;
        OoEayTePYyWKUnYb -= IIIgSDOzkUgUiHKO;
        WHSpJvVWA = ! WHSpJvVWA;
    }

    for (int bzLvtI = 687037373; bzLvtI > 0; bzLvtI--) {
        continue;
    }

    for (int zumopadR = 1759374808; zumopadR > 0; zumopadR--) {
        TwvibaFUVxgY += TwvibaFUVxgY;
        IIIgSDOzkUgUiHKO = OoEayTePYyWKUnYb;
    }

    if (TwvibaFUVxgY < -341465.57658770756) {
        for (int zROQqOSZAFHZ = 666155189; zROQqOSZAFHZ > 0; zROQqOSZAFHZ--) {
            continue;
        }
    }

    for (int JnOXkrbHE = 145377645; JnOXkrbHE > 0; JnOXkrbHE--) {
        continue;
    }

    for (int OGxTmlRKUs = 611445175; OGxTmlRKUs > 0; OGxTmlRKUs--) {
        OoEayTePYyWKUnYb += IIIgSDOzkUgUiHKO;
        IIIgSDOzkUgUiHKO += OoEayTePYyWKUnYb;
    }

    return STUdCsFPhmfyc;
}

bool phqceALnDPGtd::htOeZg(double mpNQZBxKEae, bool zqGob, bool qQRvVL, string GbArt)
{
    int DmTDjqtWjaHzY = 1511839285;
    double pwgcxidiWTTEYtwh = -385660.28879843256;
    string XqeBm = string("HHlnLrdyBnXMXAKzvWwccKMDvsrNVYxPqzaQqECdYhPqQqFUelJmeuvXhprlRhUupwZBHETXRSLJVDggHOOtQPeuERsgzyKypTYpmgpZsUsZeXQIVKsMgdiksepiOVlwxcYwdOPQzkzrKEoBuKIMRgeqClQeOsHHtantWCEGyTdykqOOrQRsfmuezrGYHsjuTjOzyhCXsMlQvmlfLwSIobodmxEhvbUrBFmjrAVcwexMUDG");
    bool JSQsS = false;
    bool NmRbVX = false;
    string VRzhVvhklEM = string("QRUDzUJc");
    double nauXzIIoVcVPKoz = -274708.0286485662;
    bool aFegK = false;

    for (int bMTlgu = 1397124520; bMTlgu > 0; bMTlgu--) {
        XqeBm += GbArt;
        zqGob = ! qQRvVL;
    }

    for (int hvLTvpISb = 266968103; hvLTvpISb > 0; hvLTvpISb--) {
        aFegK = ! qQRvVL;
        XqeBm += XqeBm;
        JSQsS = NmRbVX;
    }

    for (int uohPCTpBAsZV = 1676820291; uohPCTpBAsZV > 0; uohPCTpBAsZV--) {
        mpNQZBxKEae += nauXzIIoVcVPKoz;
    }

    return aFegK;
}

int phqceALnDPGtd::OXyggTIJEvJeKd()
{
    int dSfxJBtwxeqvF = -2048090692;
    string TrcPQlbXtPm = string("vxkdDmAMoaEiYqUQfBWnVtfYOTGIkBpN");

    if (dSfxJBtwxeqvF < -2048090692) {
        for (int uCYsjllXmfFv = 1705757418; uCYsjllXmfFv > 0; uCYsjllXmfFv--) {
            dSfxJBtwxeqvF += dSfxJBtwxeqvF;
            dSfxJBtwxeqvF -= dSfxJBtwxeqvF;
            TrcPQlbXtPm = TrcPQlbXtPm;
            TrcPQlbXtPm = TrcPQlbXtPm;
        }
    }

    for (int XVQvFWaNOmQvMfxY = 728171873; XVQvFWaNOmQvMfxY > 0; XVQvFWaNOmQvMfxY--) {
        dSfxJBtwxeqvF += dSfxJBtwxeqvF;
        TrcPQlbXtPm = TrcPQlbXtPm;
    }

    if (dSfxJBtwxeqvF == -2048090692) {
        for (int inZJGmnBubLjHif = 1247861715; inZJGmnBubLjHif > 0; inZJGmnBubLjHif--) {
            TrcPQlbXtPm += TrcPQlbXtPm;
        }
    }

    for (int IZfEThVkh = 694942669; IZfEThVkh > 0; IZfEThVkh--) {
        TrcPQlbXtPm = TrcPQlbXtPm;
        dSfxJBtwxeqvF -= dSfxJBtwxeqvF;
        TrcPQlbXtPm += TrcPQlbXtPm;
    }

    return dSfxJBtwxeqvF;
}

string phqceALnDPGtd::YxwzCkisUdKV(bool WJwxEbN, int zTLiVnPGwJZquC)
{
    int NEatN = -138593290;
    int WXkwLREqLjd = 1105057847;
    double EHiiWsALPw = 694138.9318911813;
    int OpyVVaiThdcwTc = 2123589335;
    double QrZUbyTJzcvdFMau = -397975.90725002723;
    int xUmlnI = -1153957139;
    string inJJq = string("bMQmPrzulhhxIcVozvkTRPeypmcDTREvsPxOxmrXBTYEnblburOkHicsCOyHMEBhTUrvcTSzEtAAyJNZfBnJyagbaeMdTCUhooIktVrrJVnGRkmrLpyFXufMQMgsEDthghYRCnVhQmHmjLpyhqwsCiJjdDMUZWkoxTR");
    bool FllFFzQAdLsT = true;
    int YmoUUwNdwICMu = -383758218;
    int bnermMlKwRiWr = -633566286;

    for (int nlkeiAwqWkO = 1921723194; nlkeiAwqWkO > 0; nlkeiAwqWkO--) {
        YmoUUwNdwICMu *= NEatN;
        bnermMlKwRiWr /= YmoUUwNdwICMu;
        NEatN *= xUmlnI;
        xUmlnI -= bnermMlKwRiWr;
    }

    for (int cBZBCLt = 1880228182; cBZBCLt > 0; cBZBCLt--) {
        YmoUUwNdwICMu += OpyVVaiThdcwTc;
        QrZUbyTJzcvdFMau /= EHiiWsALPw;
        NEatN -= bnermMlKwRiWr;
    }

    if (EHiiWsALPw < -397975.90725002723) {
        for (int OgFkkwWWnmf = 676174569; OgFkkwWWnmf > 0; OgFkkwWWnmf--) {
            OpyVVaiThdcwTc += bnermMlKwRiWr;
            xUmlnI -= zTLiVnPGwJZquC;
        }
    }

    return inJJq;
}

string phqceALnDPGtd::jKXoCy(string yXxzjqmJF, string KINFgvYSzZ)
{
    bool AuCkiu = false;
    string WxxXCtetSyC = string("DQMNpqGDNNEBgAbjkxJAkVjIEaZkYoLWEXXtDZLJzQoNeRXvcBmWDZ");
    string qXaGiICVzVztsbLS = string("RQXnWruULxTyApUVRvBnqLNQGhYLVcPVbRhyRHPSdrXygAXgmAtlwMxNJlkucLEbiERlRzlpQkrjLKjNntGmARWzlxQbIAVckYvJQHMxQDPemAenMZTdhMTDiNOLeRepEMWRxokaEisVqDfdNLWjFyWMUzNSKraStnDmtlyLOeEFldcNLWnwakFFqAmRcDgmjbSMAkSBIxQbxJkx");
    double RXBEz = 90843.84249799197;
    double pBNDyKjTXbq = 958544.7763142416;
    bool BvAZyKAtnLm = false;
    bool AmzhYNIwbEoHkP = true;
    bool wdyMdtP = true;

    return qXaGiICVzVztsbLS;
}

void phqceALnDPGtd::rbtvl(double ntURwmfsViQTB, int ungrmg, bool PmhJNUpKcHzJv)
{
    string tCnEczLaDxIQsOH = string("QaKPSrmjaZYMZqix");
    bool CJyxUinswLE = true;
    double louORHLLIwcs = 361896.02142907836;
    double qvPeSAYqxtyIIZx = 59625.828052541976;

    if (CJyxUinswLE != true) {
        for (int qyqoVFiuEROGCtqj = 888172977; qyqoVFiuEROGCtqj > 0; qyqoVFiuEROGCtqj--) {
            ntURwmfsViQTB = qvPeSAYqxtyIIZx;
        }
    }
}

double phqceALnDPGtd::WAtBwxbjHvoaDA()
{
    bool jCUvhQOS = true;
    string iBBfmaKfcYyqxO = string("NfugYcImpNiwXTCAWnqBsnFDixqKzlWdlyznVBAgVzlClmonCuMNPBwWehNglqBqFeeGaFRCqYiiaaxVUmRjpdFuxVtkKZsJFVGPpjEdWtRJDvcnSAJIoJqykbVrKDIpEDPAkHONAahLGlqwYhHghoLeuPHurdTHWeqvnnYBDzadNmGDYsohMNrsyXnveRbXqHZqHsXakupawDIEDPjQCxdCsNINLJzmzqhaYpT");
    string hpJfyujZm = string("fMLpthgWKSVXitvjLpKxXdultPTdTFkzXfbgcWAGCfAhWuMYobpMXmjSZHEaiZXGOTUQSbBJVzzwAdCFbxAximkvdgyUkvmgjqOxhZCsl");
    double qGlfoqxLM = -401327.6482068272;
    double dBmlZwBKJtKMnMJ = -990177.9262586078;

    for (int mzPflZ = 1493810226; mzPflZ > 0; mzPflZ--) {
        qGlfoqxLM = qGlfoqxLM;
    }

    if (hpJfyujZm != string("fMLpthgWKSVXitvjLpKxXdultPTdTFkzXfbgcWAGCfAhWuMYobpMXmjSZHEaiZXGOTUQSbBJVzzwAdCFbxAximkvdgyUkvmgjqOxhZCsl")) {
        for (int DyFXAohfouvod = 205819734; DyFXAohfouvod > 0; DyFXAohfouvod--) {
            iBBfmaKfcYyqxO = iBBfmaKfcYyqxO;
            iBBfmaKfcYyqxO = iBBfmaKfcYyqxO;
            iBBfmaKfcYyqxO = hpJfyujZm;
            qGlfoqxLM = dBmlZwBKJtKMnMJ;
        }
    }

    if (qGlfoqxLM > -990177.9262586078) {
        for (int OLaeEjkJqFR = 830232551; OLaeEjkJqFR > 0; OLaeEjkJqFR--) {
            qGlfoqxLM += dBmlZwBKJtKMnMJ;
            iBBfmaKfcYyqxO += hpJfyujZm;
            dBmlZwBKJtKMnMJ /= qGlfoqxLM;
        }
    }

    return dBmlZwBKJtKMnMJ;
}

int phqceALnDPGtd::quTjM(double ITTWDJpANIACx, string ZjcfrxPIuz, bool dAHuywvAhjy)
{
    double fDZwtjTl = -695198.4608166183;
    string SlIWmmuLQILWj = string("aLcCfJvZqDfNHThEiFEnYCZOBDoEGkRJOFZLfBfnQxKNvnHiQQVqZhXeoHQtmweGBgDVfZNViHgPRVjZeXDPXHQsRlqOJCoeoWkMnXjaQRZWOouV");
    string tYaMkiOymOKXdx = string("mVNJshHBPSTHkDHGEptCJWYoGBkbogLUNfYZAySBZQIFHsPnLExpIBNwZjtJxnnJlzjXIZzeCjqGqhcXBsGPqKxThufUeAFDUPcOoUelRUgTZCCAgENdacdRbaXhvuhfwGgXyeTuVPwJvPAnUDZdhtrKWAKwvcTDwKaiwwOZXouJrlkxIvMJlvqDixLznAqVKvJgVApySWxTOVuZnys");
    double gBkKPzuhGeNaotea = -94835.9682978514;
    int zNShSvILPScwPQP = 50329169;
    int FWCKwNEQPNlTTX = 670682173;
    int VpUdgPWQS = 846217522;
    string XihmpvQ = string("VbWtBQsGUlkDpAakcGspoAKjSsuTSiYULkUaQXluhkFgASTCDvKPrxlueIPDEsDRzaoYUNtuzseZHAZSLjTvWaRlLqLZWnFMZbjCseOEPAZumosgeRpp");
    int JrCvHDfzq = 1610094675;
    double sbdIaTZzWeH = 196341.36742619757;

    if (SlIWmmuLQILWj == string("mVNJshHBPSTHkDHGEptCJWYoGBkbogLUNfYZAySBZQIFHsPnLExpIBNwZjtJxnnJlzjXIZzeCjqGqhcXBsGPqKxThufUeAFDUPcOoUelRUgTZCCAgENdacdRbaXhvuhfwGgXyeTuVPwJvPAnUDZdhtrKWAKwvcTDwKaiwwOZXouJrlkxIvMJlvqDixLznAqVKvJgVApySWxTOVuZnys")) {
        for (int uKdkUfdcURi = 984577077; uKdkUfdcURi > 0; uKdkUfdcURi--) {
            FWCKwNEQPNlTTX /= VpUdgPWQS;
        }
    }

    for (int zvOECgfMFobGApjO = 245206942; zvOECgfMFobGApjO > 0; zvOECgfMFobGApjO--) {
        VpUdgPWQS /= VpUdgPWQS;
    }

    return JrCvHDfzq;
}

int phqceALnDPGtd::FWBSMaEJtTPCS()
{
    int KNCAHnfZtVAaMqu = -1758736045;
    int DXTYXFyegVw = 2004274824;
    bool VkCQwofXy = true;
    double tPEXXDBP = 375191.87303934933;
    string icbsn = string("aGWCTJVTgyQwtTtiXCWLRPGXzhlpEzzzcYWIvskqvfMeynHWyOuiZGUPXaWRWmOrnpUpUBxSoAFUZaYTdTdyAtcwIlgzaztmrToXLPQutwFCPUyAGWzqtwJrkzNMONLLVjMOdsleDQJrJWBJcBZRQAtWcbAwrJRgqZsCMEvQFywZDqFUFUkbHsieMHwiRhQpgHhFpPfFYtfmQBPmWwbqTEvkXFgUKqvykKVDLXGTCnzmFowWfeKuQB");
    double MhpUogPvnuhLL = 781591.1581976754;
    string QlHnOyIJmZ = string("NoLYKsdAMqUSnGOUXTKtigeRSwRtpzsCxYDQMamLHWfRmhuIgtoNVaCfAkrfQLBhyoaAoMczbBHPpFTPxLiavycgvqiloPyRFOKjzPtjzNpS");
    double EFZhIUpgUd = -825248.206996698;
    double VjQBkXpjgOlYN = -513173.2874703289;
    int ylWuhvVdX = 1212627406;

    for (int ymiyuBNFCpgVj = 2022106815; ymiyuBNFCpgVj > 0; ymiyuBNFCpgVj--) {
        EFZhIUpgUd *= EFZhIUpgUd;
        KNCAHnfZtVAaMqu *= ylWuhvVdX;
        ylWuhvVdX /= DXTYXFyegVw;
    }

    if (VjQBkXpjgOlYN < 781591.1581976754) {
        for (int aoTluIeICzWyhxp = 1092982548; aoTluIeICzWyhxp > 0; aoTluIeICzWyhxp--) {
            KNCAHnfZtVAaMqu *= ylWuhvVdX;
            ylWuhvVdX -= DXTYXFyegVw;
            MhpUogPvnuhLL -= EFZhIUpgUd;
        }
    }

    return ylWuhvVdX;
}

int phqceALnDPGtd::FkxjJEd(double vrfKB)
{
    bool HMgPSjSPCGmQk = false;
    bool iXxXAuDHuTgy = true;

    return -864367568;
}

int phqceALnDPGtd::rSrkDFCQPWb()
{
    bool brarCcWnH = false;
    double gHmotIoWnh = 201915.68166503593;
    string mRNqcbgJMJRcoR = string("UkUUkKblZFyenekakAcqMAcJlbWohzQKfPkdXRqAPlXfjbTjQzYfiapKnJsZzAqQyLHwkzewzVsgFrDEkScIgmteHCUVkoqwZYlevsJrgjILxIOsavIxAkjAxFfyEQwxDbVjQJETOLBAkObHxUTsZgPJtZkSWeaAJZqPClqsfsyGRwEjyUVouesFBYtXpCJSJNiZuywuaVbECfJCCUL");
    bool GRwYKOBEbKvn = false;
    int NfrrF = 2144049159;
    int mMIpsMRtSicRuazC = -1088254376;
    double SwvlxtTdpuNm = 832941.5334195109;

    if (brarCcWnH != false) {
        for (int JXptB = 1021594031; JXptB > 0; JXptB--) {
            continue;
        }
    }

    for (int wXRYqSuw = 1579639820; wXRYqSuw > 0; wXRYqSuw--) {
        GRwYKOBEbKvn = brarCcWnH;
    }

    for (int ZZjEzSYushmga = 716329998; ZZjEzSYushmga > 0; ZZjEzSYushmga--) {
        continue;
    }

    for (int FeCLMTqI = 2121031761; FeCLMTqI > 0; FeCLMTqI--) {
        mRNqcbgJMJRcoR = mRNqcbgJMJRcoR;
        GRwYKOBEbKvn = ! GRwYKOBEbKvn;
    }

    return mMIpsMRtSicRuazC;
}

double phqceALnDPGtd::hXimfeMKsMj(double AWeFGabfQrP, int eyXrRfveBlmSqUPL, string BpGXKH)
{
    string PniXdPW = string("klmLtjkWdTNvrWnBeVyFoSnChvVCQxuANibUEarxnSIXZGhtUAlxlgYVGyIyiCVYligwhMUTGgxmcCqIiRrlSmuRfZKzzuNaHnjkhyWoXBkCzbAdEaZcwnOCfxdjmyoGDpIguPYJpsvDEBfwKkUaaHwgXqGFDRbRCPrzYjKHPlDWTEfbEyTKvkrXpQuuFZFHhZgiBBcWVJeZQyIYDFcOqKLSTmyXC");
    bool VgSNUAyzgpnHh = true;
    bool yXvxWeqFpUvczjf = false;
    bool kxmfIgX = true;
    bool wcLGxomcQz = false;
    string roqpffoYZex = string("QpvBBPWSCLNhLRGJSWBoBipwGJsNDJZCoZmEtidUxcHIFUmZXjuXzwdBVMjKtAMaVbCAYGGetVLmBwFRcfCcwwvgUHPHVAutkSrffAslsDXnmGEhodSDgremsaQjcRbmNcrjUoFzfllDZdKFsOfbozwqQGwqJUfJapATpImCbpJkPdtHqjSAKCJwhNWSKzFGnNHYfdJyqQqtKtWIewljUnhKSblcNZhHUsCyTbqUbHXOcWugiMZSLQhkI");
    int NOToo = 1700494907;
    double WfHgrCH = -261879.28096682412;
    double itjJXhSzXTXcKrd = -571755.5775323824;

    for (int vlqQOMQXAKyFPf = 344637412; vlqQOMQXAKyFPf > 0; vlqQOMQXAKyFPf--) {
        yXvxWeqFpUvczjf = wcLGxomcQz;
    }

    return itjJXhSzXTXcKrd;
}

bool phqceALnDPGtd::cnCKGwMDHdUDQ(double CWmlE)
{
    int rfAzblK = 739338006;
    bool aBIfcwOZfiCq = true;
    double QmLQBIsKeXFFc = -63147.00495403633;
    int aUJjnzZmKf = 794322284;
    double utiSqHAKhurRDz = 895484.8791401661;
    bool SxmlKuYr = false;

    for (int aIeno = 951421863; aIeno > 0; aIeno--) {
        CWmlE = CWmlE;
        aUJjnzZmKf = aUJjnzZmKf;
        QmLQBIsKeXFFc *= QmLQBIsKeXFFc;
    }

    if (utiSqHAKhurRDz < 895484.8791401661) {
        for (int raMFAm = 187851101; raMFAm > 0; raMFAm--) {
            utiSqHAKhurRDz -= CWmlE;
            utiSqHAKhurRDz = QmLQBIsKeXFFc;
            utiSqHAKhurRDz -= QmLQBIsKeXFFc;
            SxmlKuYr = SxmlKuYr;
            rfAzblK *= rfAzblK;
        }
    }

    return SxmlKuYr;
}

phqceALnDPGtd::phqceALnDPGtd()
{
    this->CfuIESb(-1115178037);
    this->vhxTPQ(string("dWBiVTdboSGreXMUIKBivBTQmWVIQSPPZjvDdekHTQZrJkxfHaWwqeGefwJyrVXIDHYRqzxjetKMMAibXZDGlFCHxBRpCuVuZHzucvLUJFPNHUnnepQFcydfmtQJyKqsMVOsLPpmNONvRdmfNEnAwyLSaUWMhyPhmDlnsPFpHPoKpfykgrUkqScXjuLrhFJwcNIsRkAkP"));
    this->sCWmPEzFmpXU(-193332.27652633176, string("yCDKtBPkIlhFCerLLfmTMIYlIowvwHJyWBRRCFHtoqWmGYVLlJaYuYRxRQzOBJqDcKcyOJhPQUfeMlJCwwjDEFmKnltNFILWzisxW"));
    this->UXptMoAyWHn(-1109320479, 30930635, 1751422911);
    this->JSfFyFxgPCop(-883336487, -715772.6721386956, true, true);
    this->htOeZg(-943145.0802609774, false, false, string("IJQLJKqzrsNDUelwKMZCVqvpSthPLlEVZeXBuyFpUzqkUGDZSsYyfdMeKvuhtkgoKecpGLennFaGMIsCZUpKbdiCXsFcyVDqrlOxEpOPBreKFlKkyDiJBOMooiKRgAwLtOWrOLQSUwTCvrSWMXarQKUkCbxxvgCahPuxWIbmPiZcrbwjqLtScYbFnlFJXzaUNAsHbWcQwOffZLyRORHosJeWMSeoHufAQLpWCOvNZc"));
    this->OXyggTIJEvJeKd();
    this->YxwzCkisUdKV(false, -1238482978);
    this->jKXoCy(string("lbAmgYWTDOQtYZcovXpYiMwBrcWXMJTRSNyJrXjVxJDCXlLXzcnHAMQWWBuAwhOSOiKxVjYsryojBsmzYuPOqTCYeEAJzqNzlPKFZUoFWmPKHTWcwMYQtPVHkjAVjBVIWQfFIDfUKAKqSITBkiPbWtqjDenVGUAyVUocvMNgxrZpaSLzWVEJJkMUIUGXOsUxkdUmrIZFPxyOuPn"), string("YNqZAtgGYiGaKYXLLVHYs"));
    this->rbtvl(193795.2238270918, 823981642, true);
    this->WAtBwxbjHvoaDA();
    this->quTjM(-494671.37260552804, string("ezLOmYXqVRtmPVjknchRyBSfviyizbDZACZcxRtqHpLwyDUNeomfAxhLUJUYWAAwy"), true);
    this->FWBSMaEJtTPCS();
    this->FkxjJEd(-642260.5681034517);
    this->rSrkDFCQPWb();
    this->hXimfeMKsMj(-340160.85467174253, -209624496, string("SwJXzXwMjrodtjL"));
    this->cnCKGwMDHdUDQ(960087.3577541776);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OECPcgRYXBXYuL
{
public:
    double msKqpxGeqGeRAF;

    OECPcgRYXBXYuL();
    double QCCHOsxetDIfL();
    string RlXYftJ(string IefCTVHBBkxOIUB, double JPcVLdKWDP, bool NHxssW);
    string cpElIA();
    void FveWpjNtw();
    int AmJYZljWPja(bool ACRrZJVmKPXNgm);
    bool qmzvrSsrsO(string CJeHZsIBA, string BTbvmICQwLz, string MzxJUJn, string vJmwNTjNWtIt);
    void TFEHjVGCeKLm(int RcwLClqIzs);
protected:
    string qWFovSYRJtcgop;
    string wATFDkoPqXCEEGmk;
    double sUicqevdYdNPiq;
    int dGoYogcLUDEiJ;
    int yYUbCgq;
    bool DqHAuIKHURaKdb;

    void zptSOwy(bool xftkzRXteTdbXsz, string pINEZYZHd, int TFtvnMdvONBwVx, bool VWEQM);
    string ToADG(int tMbsykcSEtVSlpL, double DwcfEuJfqwEtnL, bool fBILGgspaFsnINiy);
    bool TUFJWJzfz();
    void RGoDJIJvxhC(int qFCTpdnGf, int jJLrGlKPxN, double KCCpINCQCp, double DkDHTzceBvL, int aCpBOmKhxwA);
private:
    double WCxtFav;

    bool BxxVICDAtqiLE(string GBtFD, int gJMncWb);
    double hegJpMCYpJ(double NDBvOtEeSqbTrQl, bool DBFfX);
    void QQvnhbu(string LWFNNqQoYDwESApW, string OSrXqmkcfMrIYbT, double uGLdYxSKH, double GQleWZwvChkCd);
};

double OECPcgRYXBXYuL::QCCHOsxetDIfL()
{
    double FVYOJgGSSXWQYuJ = -617039.9433148025;

    if (FVYOJgGSSXWQYuJ <= -617039.9433148025) {
        for (int umudqrEfSEubu = 1203741419; umudqrEfSEubu > 0; umudqrEfSEubu--) {
            FVYOJgGSSXWQYuJ /= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ += FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ /= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ /= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ += FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ /= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ *= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ += FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ /= FVYOJgGSSXWQYuJ;
        }
    }

    if (FVYOJgGSSXWQYuJ > -617039.9433148025) {
        for (int hLLZuDAjOzQlOIXY = 451892336; hLLZuDAjOzQlOIXY > 0; hLLZuDAjOzQlOIXY--) {
            FVYOJgGSSXWQYuJ *= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ *= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ -= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ *= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ = FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ += FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ -= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ *= FVYOJgGSSXWQYuJ;
            FVYOJgGSSXWQYuJ -= FVYOJgGSSXWQYuJ;
        }
    }

    return FVYOJgGSSXWQYuJ;
}

string OECPcgRYXBXYuL::RlXYftJ(string IefCTVHBBkxOIUB, double JPcVLdKWDP, bool NHxssW)
{
    double ChygAccw = 361903.76204462664;
    bool KKBRijbVlbJ = true;
    int TkemsDVcbVSiAq = -1841302673;
    double QJzUwfDnHWR = 410969.09474875015;
    double qsPynntcLeh = 361109.28232115647;

    for (int dXrRgbmf = 2066848079; dXrRgbmf > 0; dXrRgbmf--) {
        qsPynntcLeh -= ChygAccw;
        qsPynntcLeh = JPcVLdKWDP;
    }

    if (KKBRijbVlbJ != true) {
        for (int qMWsSTRWhQRyFHz = 1360626621; qMWsSTRWhQRyFHz > 0; qMWsSTRWhQRyFHz--) {
            JPcVLdKWDP += QJzUwfDnHWR;
            KKBRijbVlbJ = ! KKBRijbVlbJ;
            NHxssW = KKBRijbVlbJ;
            TkemsDVcbVSiAq /= TkemsDVcbVSiAq;
            QJzUwfDnHWR = qsPynntcLeh;
        }
    }

    for (int rgLxKv = 739966028; rgLxKv > 0; rgLxKv--) {
        ChygAccw = QJzUwfDnHWR;
    }

    return IefCTVHBBkxOIUB;
}

string OECPcgRYXBXYuL::cpElIA()
{
    string hWWNKcnZfmVDNH = string("GYRnEBGMsuArwdDmoKxzhzrgqGRpevEbjSdeLvcNWpGiSJSuuhOVUPTMVHtfvFebkwjjusXFZbQXKWfnwIcTqYfKdzdQptXfnFzIJonbmYseInBQQDgOWpjwieNaYbqHqrMQFdBydNIGsACJEHADvrHajZRnVqNBgKljdiUOOBMlItolwQrgCSyuJqoAditYtAXdhVTFBhuIxFpfwfrjNkAL");
    double RTjVk = -935038.1575558339;
    bool dxBPelsDUhFqHGUD = false;

    if (RTjVk > -935038.1575558339) {
        for (int xcMeUbS = 2032742132; xcMeUbS > 0; xcMeUbS--) {
            dxBPelsDUhFqHGUD = dxBPelsDUhFqHGUD;
        }
    }

    for (int vTXdkPus = 1784834972; vTXdkPus > 0; vTXdkPus--) {
        hWWNKcnZfmVDNH += hWWNKcnZfmVDNH;
        dxBPelsDUhFqHGUD = dxBPelsDUhFqHGUD;
    }

    if (RTjVk < -935038.1575558339) {
        for (int WIQINYZaggXUWmWc = 1412930164; WIQINYZaggXUWmWc > 0; WIQINYZaggXUWmWc--) {
            continue;
        }
    }

    for (int HBVpu = 1489981791; HBVpu > 0; HBVpu--) {
        hWWNKcnZfmVDNH += hWWNKcnZfmVDNH;
        RTjVk += RTjVk;
        RTjVk = RTjVk;
        dxBPelsDUhFqHGUD = dxBPelsDUhFqHGUD;
    }

    for (int FtYYaPrnikh = 635227432; FtYYaPrnikh > 0; FtYYaPrnikh--) {
        RTjVk -= RTjVk;
        hWWNKcnZfmVDNH += hWWNKcnZfmVDNH;
    }

    for (int wFczaqS = 2116064275; wFczaqS > 0; wFczaqS--) {
        dxBPelsDUhFqHGUD = dxBPelsDUhFqHGUD;
    }

    if (RTjVk < -935038.1575558339) {
        for (int tOHKyS = 561826157; tOHKyS > 0; tOHKyS--) {
            hWWNKcnZfmVDNH = hWWNKcnZfmVDNH;
            hWWNKcnZfmVDNH = hWWNKcnZfmVDNH;
            dxBPelsDUhFqHGUD = ! dxBPelsDUhFqHGUD;
        }
    }

    return hWWNKcnZfmVDNH;
}

void OECPcgRYXBXYuL::FveWpjNtw()
{
    string SiQItu = string("AmMQLnUimvPtdDshmwcBYwAyBMwwCQgdPKxTUmMNDPAcfhUBpNRaxavaMIVwpPVPKRcOEQhSPvPRlkPADGsuDAInnMCyVuXDTGziktIvuWqsnpFKuLuPwkFKXCzBIo");
    int kMrHtAvndONOOjF = -294351048;
    string NoXZhuxl = string("mTmmICgosZKOLmlQnNsblrWEiIItDEFdpxKvsETNqHsByWpqXsVFMADlIQhKjSOedFLAdtPbKSKPWMHqsufyZOTNHfrmJEeFQpGXRaMsAKMZvDIkLli");
    double KdOZaysP = -456587.43932671746;
    int sBUCx = 1440710937;
    int qzhLdL = 725564162;
    int lEJYqpGiBdVe = -1472836487;
    int UHxjPt = -775421361;
    double meLWSddkYbwIj = 118131.06222136586;
    string jtfTHiQyRHIvEggl = string("syJUsLyyXuhXPZdyJEPnYMBoxaIOqOlFsUSfRbcbPXbWkcILoqqnlmYSWGLYuVCnllskgIVwgJYcPMvxoVcgkhijZUswTuFBGCACZbEgfzCGXJOPITCkXJmnBJHMNqUzfUsXVXlnObOXDVivvtTxqxTrKBCcFFDlwJvwNVzJSiYFWIXTsNjcVRBzJZvGYtheLOcOBTbzvJzqChZiayMOFGfPpstnLpfJuPCLRC");
}

int OECPcgRYXBXYuL::AmJYZljWPja(bool ACRrZJVmKPXNgm)
{
    int LzQhzx = 2038300580;
    string sTCNsYZylVwR = string("KVwigTWoYpWaHFFVmAgyWCcXhFXeJMwPJoWNiCkgBdmnkehUIR");
    bool WRXpv = false;
    double HbAbXGRhdiPl = -1026536.6319604723;
    double GodzVwV = 1030680.6754727634;
    double XxGpQAjmyaojG = -837295.1177128144;
    bool ZKBYkGhwtEyUZ = true;
    double oRNMzRaO = 222236.28599620995;
    int NqnggVkzNimkvO = 281592754;

    for (int lGljtDVy = 233677189; lGljtDVy > 0; lGljtDVy--) {
        GodzVwV -= XxGpQAjmyaojG;
        HbAbXGRhdiPl *= oRNMzRaO;
        ACRrZJVmKPXNgm = ! ZKBYkGhwtEyUZ;
    }

    if (HbAbXGRhdiPl >= 222236.28599620995) {
        for (int EwqQVZvJGJeIpncD = 1264049328; EwqQVZvJGJeIpncD > 0; EwqQVZvJGJeIpncD--) {
            WRXpv = ACRrZJVmKPXNgm;
        }
    }

    return NqnggVkzNimkvO;
}

bool OECPcgRYXBXYuL::qmzvrSsrsO(string CJeHZsIBA, string BTbvmICQwLz, string MzxJUJn, string vJmwNTjNWtIt)
{
    int JaHcNgOIho = -2090264469;
    string QLYPBmzxmWzIml = string("mUGdAGbtCPdGJcIyohvKGvoUETgzcIekoMQjhixDQytLJnWXkdwbQdsQkzdYnRuSwVnRwSCBwyFifzdsKQCvLq");
    double kcHZEnQ = -561196.2290305006;
    bool mmAmLyKDBYrmt = true;
    int kIruUPpepYJ = 183744662;
    bool LoaoSBiR = false;
    double Lseuu = -562906.237477147;
    bool GdKMWE = false;
    bool gdEJtTpvTOymW = false;
    double yxBskMeqc = 834197.6455965838;

    for (int SLQHOSAtNeC = 304091843; SLQHOSAtNeC > 0; SLQHOSAtNeC--) {
        QLYPBmzxmWzIml += BTbvmICQwLz;
        gdEJtTpvTOymW = mmAmLyKDBYrmt;
    }

    for (int uVskmmaXKNP = 1460861538; uVskmmaXKNP > 0; uVskmmaXKNP--) {
        CJeHZsIBA = QLYPBmzxmWzIml;
        BTbvmICQwLz = MzxJUJn;
    }

    return gdEJtTpvTOymW;
}

void OECPcgRYXBXYuL::TFEHjVGCeKLm(int RcwLClqIzs)
{
    double VzfRcAbwIVy = 996338.5503228925;
    int kYSFiWpO = 1251751923;
    double jrBlTwuVescWn = -922550.1989625419;

    for (int RlxlhAtcLvezlk = 217904332; RlxlhAtcLvezlk > 0; RlxlhAtcLvezlk--) {
        kYSFiWpO += RcwLClqIzs;
        kYSFiWpO -= kYSFiWpO;
    }
}

void OECPcgRYXBXYuL::zptSOwy(bool xftkzRXteTdbXsz, string pINEZYZHd, int TFtvnMdvONBwVx, bool VWEQM)
{
    int gcXwliYqKN = -1306261685;
    int rFDXclqdVPRmmmh = 508206883;
    double IzswCflCE = -929387.3604182674;
    bool RFtyuh = false;
    int iikMEcITlT = 1210068227;
    double MdxTpXyov = 3819.842104031459;
    bool DGKMPzYoHGMZk = false;
    int fzSMc = 2127659786;
    double moBqacepP = -986969.2118204375;

    for (int BxuqHbuqHBsAdOdp = 1722874451; BxuqHbuqHBsAdOdp > 0; BxuqHbuqHBsAdOdp--) {
        iikMEcITlT += iikMEcITlT;
    }
}

string OECPcgRYXBXYuL::ToADG(int tMbsykcSEtVSlpL, double DwcfEuJfqwEtnL, bool fBILGgspaFsnINiy)
{
    int usLeEPJQMQ = -471520571;
    string CpMGxqmhUnzfbAM = string("pRksooLXeOuSaqwwBlcwlTuJdXHZCqVzOPNeXAywqArlaAc");
    string mPTZTj = string("hwTosXMmRrZwwZEQOhoXrzJIxNbtpfoYHfqUFBBLpzUgGlEMZJUoUojQlfhivoEDZEDbRwChUdofNslmEJMCVoORTQYVGGeMpQvTBHqmdUrhEdObbMPrZbkBXUEOsRQFYaIZladdNFPNgDlURbAbPrCWdiOzTBKohRgIgnRLRmXEETBPYKWNXEMFPzVVbJrtihoQwPucWqMGPTZDNSrqNEPBnKdLNJCvtIEhjgVczPvrhvRtBiINgJdEClqnqiJ");

    for (int iRGDq = 1760721571; iRGDq > 0; iRGDq--) {
        usLeEPJQMQ -= tMbsykcSEtVSlpL;
        DwcfEuJfqwEtnL *= DwcfEuJfqwEtnL;
        DwcfEuJfqwEtnL = DwcfEuJfqwEtnL;
        mPTZTj += mPTZTj;
    }

    return mPTZTj;
}

bool OECPcgRYXBXYuL::TUFJWJzfz()
{
    string iOroHQQyYdC = string("nfOdLiSdSjdwCzRqHmdBncZuGCTrUuaHjeRbcvnwnDWBXXkRypZiCxRyhuyJZoAXjNhJAXkUGlLEGcSGhtGbnQtGKNHhtQKjppQGmKhKVTXFnZgBWwcWsCbSzSTFBlRKQxtCOgMdabvsIxtkgpoUnmIyxolNmKbeCoSoaHbJumyUrfyuSZzISElTeyLtcRSeVYhQgNawYAarQtQChEUBJHkYSGeDbKzyWW");
    string dWJOHtVxTq = string("iLcvaXfwYqohAvzCbAkMrzzzgCioJOMpIXInBtRxTDmxunxkJwUNktIHUvvBJaBVZvJErGuOJvvENXgQbvaaNwXmvyKhUeWfHHIvGIywToUuXorpXBoJIXORIoYFPgxoziWtmYPXNCBcqZCWWZhweUzrSfHCSFiBAHYKpkJPqpNfVuvVyDSAQx");

    if (dWJOHtVxTq <= string("nfOdLiSdSjdwCzRqHmdBncZuGCTrUuaHjeRbcvnwnDWBXXkRypZiCxRyhuyJZoAXjNhJAXkUGlLEGcSGhtGbnQtGKNHhtQKjppQGmKhKVTXFnZgBWwcWsCbSzSTFBlRKQxtCOgMdabvsIxtkgpoUnmIyxolNmKbeCoSoaHbJumyUrfyuSZzISElTeyLtcRSeVYhQgNawYAarQtQChEUBJHkYSGeDbKzyWW")) {
        for (int AFBtZuwvQkKVaRh = 658774462; AFBtZuwvQkKVaRh > 0; AFBtZuwvQkKVaRh--) {
            dWJOHtVxTq = iOroHQQyYdC;
            dWJOHtVxTq = iOroHQQyYdC;
            dWJOHtVxTq = dWJOHtVxTq;
        }
    }

    if (dWJOHtVxTq != string("iLcvaXfwYqohAvzCbAkMrzzzgCioJOMpIXInBtRxTDmxunxkJwUNktIHUvvBJaBVZvJErGuOJvvENXgQbvaaNwXmvyKhUeWfHHIvGIywToUuXorpXBoJIXORIoYFPgxoziWtmYPXNCBcqZCWWZhweUzrSfHCSFiBAHYKpkJPqpNfVuvVyDSAQx")) {
        for (int BKPmjLS = 544581605; BKPmjLS > 0; BKPmjLS--) {
            dWJOHtVxTq += dWJOHtVxTq;
            iOroHQQyYdC = dWJOHtVxTq;
            iOroHQQyYdC = dWJOHtVxTq;
            iOroHQQyYdC = dWJOHtVxTq;
        }
    }

    if (iOroHQQyYdC != string("iLcvaXfwYqohAvzCbAkMrzzzgCioJOMpIXInBtRxTDmxunxkJwUNktIHUvvBJaBVZvJErGuOJvvENXgQbvaaNwXmvyKhUeWfHHIvGIywToUuXorpXBoJIXORIoYFPgxoziWtmYPXNCBcqZCWWZhweUzrSfHCSFiBAHYKpkJPqpNfVuvVyDSAQx")) {
        for (int ilcEbFGagjsEm = 2128342986; ilcEbFGagjsEm > 0; ilcEbFGagjsEm--) {
            dWJOHtVxTq += dWJOHtVxTq;
            dWJOHtVxTq += iOroHQQyYdC;
            iOroHQQyYdC = dWJOHtVxTq;
            iOroHQQyYdC += iOroHQQyYdC;
            iOroHQQyYdC = dWJOHtVxTq;
            iOroHQQyYdC += dWJOHtVxTq;
            dWJOHtVxTq += iOroHQQyYdC;
            dWJOHtVxTq = iOroHQQyYdC;
        }
    }

    if (iOroHQQyYdC < string("nfOdLiSdSjdwCzRqHmdBncZuGCTrUuaHjeRbcvnwnDWBXXkRypZiCxRyhuyJZoAXjNhJAXkUGlLEGcSGhtGbnQtGKNHhtQKjppQGmKhKVTXFnZgBWwcWsCbSzSTFBlRKQxtCOgMdabvsIxtkgpoUnmIyxolNmKbeCoSoaHbJumyUrfyuSZzISElTeyLtcRSeVYhQgNawYAarQtQChEUBJHkYSGeDbKzyWW")) {
        for (int nyQGFiGo = 1094491801; nyQGFiGo > 0; nyQGFiGo--) {
            dWJOHtVxTq = iOroHQQyYdC;
            iOroHQQyYdC = dWJOHtVxTq;
            iOroHQQyYdC = iOroHQQyYdC;
            dWJOHtVxTq = dWJOHtVxTq;
            iOroHQQyYdC = dWJOHtVxTq;
            dWJOHtVxTq += iOroHQQyYdC;
            dWJOHtVxTq = dWJOHtVxTq;
            iOroHQQyYdC = iOroHQQyYdC;
        }
    }

    if (dWJOHtVxTq > string("iLcvaXfwYqohAvzCbAkMrzzzgCioJOMpIXInBtRxTDmxunxkJwUNktIHUvvBJaBVZvJErGuOJvvENXgQbvaaNwXmvyKhUeWfHHIvGIywToUuXorpXBoJIXORIoYFPgxoziWtmYPXNCBcqZCWWZhweUzrSfHCSFiBAHYKpkJPqpNfVuvVyDSAQx")) {
        for (int KKiOWGeaiiB = 1255550965; KKiOWGeaiiB > 0; KKiOWGeaiiB--) {
            iOroHQQyYdC += dWJOHtVxTq;
            iOroHQQyYdC = iOroHQQyYdC;
            dWJOHtVxTq = dWJOHtVxTq;
            iOroHQQyYdC += dWJOHtVxTq;
            iOroHQQyYdC = iOroHQQyYdC;
        }
    }

    return true;
}

void OECPcgRYXBXYuL::RGoDJIJvxhC(int qFCTpdnGf, int jJLrGlKPxN, double KCCpINCQCp, double DkDHTzceBvL, int aCpBOmKhxwA)
{
    string bnjtNqwsIEJKj = string("xgzkIOuGIrLhYTBBQzcOXNOOCzJmqiUICOMyzFNNZMfUAxLEwGPDCvbLodCzdcchFSCOwhYdhyNPGBogGMnpGBfgFPTZkBolVlLRmyXBmiqStywNmWhXofxonypFfnWsxcWBLlRtYRfubssLCIoRKTvOQKPfoJKkqlndwohOLfKZsCZIWrcavDRYstIGxBXLikQwTvU");
    double rLPJOhSTUHXDgOJj = -674850.4889420227;
    string ffwJICxYxXRkem = string("KJutHwoGmlhMapAxrRDPfKsRHPB");
    int ryQkHwGmgOknEB = -1690677478;
    double ufajoMAFO = -451358.5844431308;
    bool bblYIXbA = true;
    int YyQaHsLgZAw = 956479232;
    bool IqVFxfTw = true;

    for (int FLksc = 1349956433; FLksc > 0; FLksc--) {
        continue;
    }
}

bool OECPcgRYXBXYuL::BxxVICDAtqiLE(string GBtFD, int gJMncWb)
{
    bool OCrAEE = false;
    double UqIjfSECazkMEDOU = 545211.7446214166;
    string qFUYubhndAOkaML = string("jBLxVRprpTDnyfrlmSgJxcSemxtAxvMVzJRdmGvRWIqsbXAsWfpFwDhWHLoAJwtHrygOcsOWfdFgQEZ");
    string JecIAmw = string("rTGtFhRukvOTBPhDvNPVnYoZvCUtFuOoqQWxoMJdzpquqthKHBFkyiCmt");
    string HXCDAxdJoGYb = string("kbiLFLaSBVyKdoBKjiWWuLtGLacdUyg");
    int zwMXiGNcmouV = -565090857;

    return OCrAEE;
}

double OECPcgRYXBXYuL::hegJpMCYpJ(double NDBvOtEeSqbTrQl, bool DBFfX)
{
    int oyKpFZG = -1181216426;
    string ApajkiSuKPnJzPks = string("oJTaWDiOASHIYSludsXzwICTpyvtqBcQHuGSLlVbhdeSXLeKjacGMcmDvryGmyugKbdwWzkwjNTTtNYycHJFEkjQjiGLenU");
    double FBRfdOywzV = 983806.942968631;
    string zfHgvBdmwKdpdjQ = string("uuKMFIAfvdCbpvPmPsEEjsFcXWyzShVskoXCkZmJELFVbrGAJpYavEvXpgarCKVPQpNfOBVvkBBhpfHMTwfkNGLIfecskhZMpylvBENdQUMR");
    int QpUhDsgn = 320019403;
    double yAZTOvLZb = 849112.8724736079;
    int QyykzDmNDwKOSA = 209090348;
    bool qQIlNidM = false;

    for (int xWDHMXJ = 1991894198; xWDHMXJ > 0; xWDHMXJ--) {
        zfHgvBdmwKdpdjQ += zfHgvBdmwKdpdjQ;
        DBFfX = ! qQIlNidM;
        QpUhDsgn /= oyKpFZG;
    }

    for (int ldnrmrKk = 1514305259; ldnrmrKk > 0; ldnrmrKk--) {
        continue;
    }

    for (int hhEKTUoB = 1656991858; hhEKTUoB > 0; hhEKTUoB--) {
        NDBvOtEeSqbTrQl = NDBvOtEeSqbTrQl;
        FBRfdOywzV += yAZTOvLZb;
        FBRfdOywzV *= NDBvOtEeSqbTrQl;
        qQIlNidM = qQIlNidM;
    }

    if (FBRfdOywzV > 983806.942968631) {
        for (int VTkzVpxMoax = 2023134863; VTkzVpxMoax > 0; VTkzVpxMoax--) {
            QpUhDsgn *= QyykzDmNDwKOSA;
            QyykzDmNDwKOSA += oyKpFZG;
            oyKpFZG /= QpUhDsgn;
        }
    }

    for (int PzVnq = 917896985; PzVnq > 0; PzVnq--) {
        DBFfX = ! DBFfX;
    }

    if (FBRfdOywzV == -79974.5387564784) {
        for (int bxPLDFktREIqudh = 1609041062; bxPLDFktREIqudh > 0; bxPLDFktREIqudh--) {
            yAZTOvLZb /= NDBvOtEeSqbTrQl;
            QyykzDmNDwKOSA += oyKpFZG;
            zfHgvBdmwKdpdjQ += zfHgvBdmwKdpdjQ;
        }
    }

    return yAZTOvLZb;
}

void OECPcgRYXBXYuL::QQvnhbu(string LWFNNqQoYDwESApW, string OSrXqmkcfMrIYbT, double uGLdYxSKH, double GQleWZwvChkCd)
{
    bool VKTiCDObUcJKnS = true;
    int TPKcTNcenorCmSL = -205614895;
    string UybdtKPAzUfJTqw = string("jvBHAgsiYbkfoBYQrFPVhjxoZkwIQbjABUJtJBMBfEakgBwHMqWorzawaLOslHwjRKwpyKUgKNlEQcoQkKEVDtlvJhOMhcRNnpUJgIbQNWbHghqOHVsqRlJnJsBYUBG");
    int YOjZiEOeXUnXv = 1291069630;
    double vMQMboxEl = -362408.1716584691;
    double EWxkJgdGxSHjx = -435493.851244881;
    string XtFYi = string("AqAYLKMlD");
    double BQEobUvT = -268213.1315193708;
    string xRqVycNmfmUPqikQ = string("ZoJ");
    string zAxfoqWrUVG = string("izzFArrgORZibvEMRINtoFnbJgrsKwsTAybVnuWtnmvXBXWppveMFhHQfItWCZIQGdhkWZunpWMwNDLgsUwGaYCijLSQHUthjNauQSUxtUCKCqpaTRSkkjVppWvGDMGVaRAhqjVyvhNadqvAMHDsIqgYDWDDqzktABZaelCbvNjkiYCPcUIBkhCxPupYZUwIYsQwcSfIixjdAcLJPGcWetGKaujKhhVOTScfGyvvFLfvQyhTuitfOTcu");

    if (uGLdYxSKH != -885856.2223665572) {
        for (int tHbJv = 1966399530; tHbJv > 0; tHbJv--) {
            EWxkJgdGxSHjx += vMQMboxEl;
            LWFNNqQoYDwESApW += zAxfoqWrUVG;
        }
    }
}

OECPcgRYXBXYuL::OECPcgRYXBXYuL()
{
    this->QCCHOsxetDIfL();
    this->RlXYftJ(string("gNIPKrbMkvxrzwgRuDDsRRwkfSZQmnUJSaSywOIGvlpzVnmcjkSXUpoyhxKLqTxYZKWfmYoPpOBYVkjmJRGwjrOmigtUcyYZKCWXYoTIuidBPsmZjpNYCuCNAYKeXiOEgneUsjXcH"), 748590.6364496691, true);
    this->cpElIA();
    this->FveWpjNtw();
    this->AmJYZljWPja(false);
    this->qmzvrSsrsO(string("vWWCWIzVlvqDYdjMJWDVcIeLUVVkxmSVzpSkWCgkJnKVQPKNGwQDmeFMwxVZeloQleDwkzWDWIlvLqJyHaodItzCkTYrVvsGebfBOrhYxOWVWKtYJwpqVxaqlUsxmNRxVsoiPRGVrHtGhBIUTMUPpyHtAyZ"), string("SJuok"), string("WfbxPYKyPeMFUHIUppGuhZvQKGOhKGNKtNHaCVyWjlSokHcgbtPaiJgOQKWxzHJiriFLdDHlOXLXbIbSIoQyBEHQxgaNBjSbpbkDtJhKYKCdYzgntUFEeQgdGZoaskNAadxNKepKhWlLpJVIzbMVRKQveSJrGtIjKxLzXKJnZHVvScBBrxNiAzShviAbiCnWIvwldUWJaDADFwJFoaiISlYpQbJrM"), string("JjCmoVCdEvKSnxkjDmsjmVpy"));
    this->TFEHjVGCeKLm(115982588);
    this->zptSOwy(true, string("KkvZvplqrMlSJQOeNZFdJEXtbprnBhkDUEFgKdZAMmBaljZruSVpqyoLpjXJXcrwMWJlkNzkZBiSvZIrhtFCLTqVTvGOqoL"), 1739969705, true);
    this->ToADG(1616053008, 333728.2015539096, false);
    this->TUFJWJzfz();
    this->RGoDJIJvxhC(-1748603052, -217733275, 40715.727795526924, 545004.262792314, -1203431591);
    this->BxxVICDAtqiLE(string("ReBHuCpPonIOMFESjKkcFTcTJwzYiCXBNsRJUAjHBpCbdhPcPIpQeQKQzfTuRtjgZYjDEsFwRAuaCGFvqZoNyxeMpKTEBTXtHloMbYHxseqjtNmwvQhgAklGrMvjoCBYBo"), 1486789311);
    this->hegJpMCYpJ(-79974.5387564784, false);
    this->QQvnhbu(string("JtstPppDDvUvHWPRpBkNegjVCYhaeLLtFfcDunOgMPuQhSJIsNoWgvOEkHVGKtpyZXJBxlEUJJgdMhbHAJbvCJTAtIE"), string("vYQvDvpgpEvtAKJZUTyhwjzsqEmQvncKrbgsrNJMSXwvmLCNvFSCfZHZzYztHSUZUxmnZcXMjRBeXsUHBquaNHSiZuGPUKbZayIBbvjOEqVgwGZzVerTYNpcFbiG"), -885856.2223665572, 968573.2337397746);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cSwHpD
{
public:
    bool nZfdYGKQowqMDTJ;
    double rVWHVIhdZ;
    double cTkbpFO;
    string XIpIBUQnj;
    string kOeFNsPXfMIQ;
    int NpMyQUtviCnj;

    cSwHpD();
    double GZHabBDqIVfdYRKX(double eLhUT, double xvhpiqrajxpHl, double PjrJJbkrSZZ, double CMMVpOFAusjSE);
    void vnNnWBBXRcLlJGqI(bool kIcbwIwYCSO, bool PntMGDknSmEODgnv, int yFafixFygKSbeO);
    void WjIVtcLiTyt(int QtZWFslvVpZh, bool tdQJOupkNqHas);
    double TeXtgIAoIzaXm(int kQXXkljHFP, double ZIFrxKjCH, bool xAkdG, string CJicasDwwo);
    string GhttRGnAe();
protected:
    int fFRdf;
    string BprGvuhFAKX;
    int vzeQmsqrxZgtO;
    double hhojmsY;
    string RYuLEAgT;
    string WAPalviWadXzs;

    int iZUyyu(bool HgOHvqi);
    void NzRTJ(bool hXnTxgb, int dDaHVr, double nbMov, string JlasJGEHA);
    double TuKWy(int zQOnPlIo);
    int tBKYnT(double VhZuBwEN, double tyHxNjsHSY, double TUxoNnf);
private:
    bool plRqtLpGitjZc;
    bool Xrwfkwl;
    double bKpiQPpyrTkhGK;
    int OxJOgG;
    bool jqNquVG;

    double AfCLhXoimmq();
    string kjwyacFPk(bool LuuJjUQop, int dABBaUq, bool ReTeAoxmygMvePH, bool CIFtHdDIIIOixb);
};

double cSwHpD::GZHabBDqIVfdYRKX(double eLhUT, double xvhpiqrajxpHl, double PjrJJbkrSZZ, double CMMVpOFAusjSE)
{
    double SuTUQuTgHgPgogs = -504236.56896418746;
    double CdzHlPQDNCmImxtt = -894822.07015846;
    int mMWZxsCZder = -789499320;
    double gGXfRTYGpPCOmm = -726613.4373914981;
    string kxErmHYv = string("WUknTipotKhoUoLtyeonpyAcPkCZflvPLHAELignBGGguEOHvmNuvtZDkmOazVPVFfapqnMzXBXHJESojMqVmCwdJUcaFdRFlaZ");
    bool ZbITw = true;
    int TyXBjNRQWvhbR = -1324151606;
    string cNTORPAADvfbS = string("LMUkpJQgekwIAcrMZdrMHbGKCJrTGGDuVkczTcInEwpknxuwcYXojjXuZAQLMNRoNpgoYlCbJAUHkpmRCMhcBXCReke");
    bool jOskLrKBOALqfto = false;
    double gSmuaebZldCP = -508466.5316348821;

    return gSmuaebZldCP;
}

void cSwHpD::vnNnWBBXRcLlJGqI(bool kIcbwIwYCSO, bool PntMGDknSmEODgnv, int yFafixFygKSbeO)
{
    string MxZsQvXNPaXM = string("GVLrXULnaByTiWTmfagoPZRvQGqsNFwUPfVdDATCaMbvhUbjChRyxHLWkvSPAUroqITyNXOoXeQmMBDWgOHzvAFLbQjqtTGjRvZeHiiChHoDZvhtVGmRwLmyFSmBAJQHWFTrFoGVRJgLUCgakXmsZibgWzzFPMIMMkjlUSCnyuDslLJMphovEDZtfmbusDrrTDdJnxjsfUepcXnSmJjACgETYIMHetUvUxROvWwh");
    double ntKmouY = -726772.0203898372;
    bool UKJKNENbqPMdobQ = true;

    if (yFafixFygKSbeO >= -579325625) {
        for (int QGklgmSVGB = 275601509; QGklgmSVGB > 0; QGklgmSVGB--) {
            MxZsQvXNPaXM += MxZsQvXNPaXM;
            PntMGDknSmEODgnv = ! kIcbwIwYCSO;
        }
    }

    for (int vTDwUpiJXAXuos = 556364415; vTDwUpiJXAXuos > 0; vTDwUpiJXAXuos--) {
        UKJKNENbqPMdobQ = UKJKNENbqPMdobQ;
    }

    for (int erpvBAORa = 1508222742; erpvBAORa > 0; erpvBAORa--) {
        UKJKNENbqPMdobQ = ! UKJKNENbqPMdobQ;
        yFafixFygKSbeO *= yFafixFygKSbeO;
        kIcbwIwYCSO = ! PntMGDknSmEODgnv;
        yFafixFygKSbeO -= yFafixFygKSbeO;
    }
}

void cSwHpD::WjIVtcLiTyt(int QtZWFslvVpZh, bool tdQJOupkNqHas)
{
    string ywWTfkTKRaiK = string("MAXwPvBxcdpjIyxcEjeuuDTMyyCRuQrNsPhbTlKRitDqiZzTLYsvInitqUTZZdAzeaVCzQGUMSlDQOjzHKqjlzdmHiqFguOVmNRRDhbcPg");
    bool fsgXSeZRtcVLzzAn = true;
    bool TvOEysfI = false;
    bool cNYoPzeONmnlL = false;
    double LeomxxiggGlxp = -761854.8551363511;
    double AsOvYwVcoFrwN = -309964.6363676506;

    for (int OVrKXzBxQXpQd = 1895471011; OVrKXzBxQXpQd > 0; OVrKXzBxQXpQd--) {
        fsgXSeZRtcVLzzAn = ! tdQJOupkNqHas;
        tdQJOupkNqHas = tdQJOupkNqHas;
        fsgXSeZRtcVLzzAn = ! tdQJOupkNqHas;
        cNYoPzeONmnlL = TvOEysfI;
    }
}

double cSwHpD::TeXtgIAoIzaXm(int kQXXkljHFP, double ZIFrxKjCH, bool xAkdG, string CJicasDwwo)
{
    double lYlNEEpTdNkyD = 633146.9409192719;
    double ymKeMcOw = -40816.86922396286;
    bool SWolvLvzKGIRqaxk = false;

    if (ZIFrxKjCH > 633146.9409192719) {
        for (int GBlDdzmUL = 1881757790; GBlDdzmUL > 0; GBlDdzmUL--) {
            CJicasDwwo += CJicasDwwo;
            xAkdG = ! xAkdG;
        }
    }

    if (SWolvLvzKGIRqaxk != false) {
        for (int HHkQevgNMI = 1317895309; HHkQevgNMI > 0; HHkQevgNMI--) {
            lYlNEEpTdNkyD = ZIFrxKjCH;
        }
    }

    if (xAkdG == false) {
        for (int FcWKTYuwbfc = 1122691828; FcWKTYuwbfc > 0; FcWKTYuwbfc--) {
            kQXXkljHFP /= kQXXkljHFP;
            ymKeMcOw += ZIFrxKjCH;
            SWolvLvzKGIRqaxk = ! xAkdG;
        }
    }

    return ymKeMcOw;
}

string cSwHpD::GhttRGnAe()
{
    bool ZIZHQYmQwwEGNI = false;
    int nWdXPDHkjKahw = -79800554;
    bool XZTcfZaAfMMTiYd = true;
    double fwLRsEaGUTc = 305471.57952525245;

    if (ZIZHQYmQwwEGNI != false) {
        for (int luqbfkM = 1178238744; luqbfkM > 0; luqbfkM--) {
            continue;
        }
    }

    for (int JopKY = 1316019989; JopKY > 0; JopKY--) {
        fwLRsEaGUTc -= fwLRsEaGUTc;
        ZIZHQYmQwwEGNI = ! XZTcfZaAfMMTiYd;
    }

    if (ZIZHQYmQwwEGNI == false) {
        for (int bfWGlzjvQV = 1685414380; bfWGlzjvQV > 0; bfWGlzjvQV--) {
            ZIZHQYmQwwEGNI = XZTcfZaAfMMTiYd;
        }
    }

    for (int gIPuwtoNLJDmze = 2144892528; gIPuwtoNLJDmze > 0; gIPuwtoNLJDmze--) {
        fwLRsEaGUTc -= fwLRsEaGUTc;
        nWdXPDHkjKahw -= nWdXPDHkjKahw;
        XZTcfZaAfMMTiYd = ZIZHQYmQwwEGNI;
    }

    return string("ikYygLprokUOJvQJTniDRjUnpmmTVNgRHAMGhAiboSlnAEouZCkdearLBXbOFMuxWpkMCUakuo");
}

int cSwHpD::iZUyyu(bool HgOHvqi)
{
    bool XwHzdgvC = true;

    if (HgOHvqi != true) {
        for (int EMMQCNKr = 562816701; EMMQCNKr > 0; EMMQCNKr--) {
            XwHzdgvC = HgOHvqi;
            XwHzdgvC = HgOHvqi;
            HgOHvqi = XwHzdgvC;
            XwHzdgvC = HgOHvqi;
            XwHzdgvC = ! XwHzdgvC;
        }
    }

    if (XwHzdgvC != true) {
        for (int hfICLHhjHnruRVV = 710284291; hfICLHhjHnruRVV > 0; hfICLHhjHnruRVV--) {
            HgOHvqi = HgOHvqi;
            XwHzdgvC = ! HgOHvqi;
            XwHzdgvC = HgOHvqi;
            HgOHvqi = XwHzdgvC;
            HgOHvqi = XwHzdgvC;
            XwHzdgvC = HgOHvqi;
            XwHzdgvC = ! HgOHvqi;
            XwHzdgvC = ! XwHzdgvC;
        }
    }

    if (XwHzdgvC == true) {
        for (int ADhMHmOtRdKz = 2057561015; ADhMHmOtRdKz > 0; ADhMHmOtRdKz--) {
            XwHzdgvC = ! XwHzdgvC;
            XwHzdgvC = ! HgOHvqi;
            HgOHvqi = XwHzdgvC;
            XwHzdgvC = HgOHvqi;
            HgOHvqi = ! HgOHvqi;
            XwHzdgvC = ! XwHzdgvC;
        }
    }

    if (XwHzdgvC != true) {
        for (int WbDlwsHbbEhSUOO = 402250846; WbDlwsHbbEhSUOO > 0; WbDlwsHbbEhSUOO--) {
            HgOHvqi = ! XwHzdgvC;
            XwHzdgvC = HgOHvqi;
            XwHzdgvC = ! HgOHvqi;
            XwHzdgvC = ! HgOHvqi;
            XwHzdgvC = XwHzdgvC;
            XwHzdgvC = ! XwHzdgvC;
        }
    }

    return 1654726349;
}

void cSwHpD::NzRTJ(bool hXnTxgb, int dDaHVr, double nbMov, string JlasJGEHA)
{
    bool ODQJhzzDqgSp = true;
    int joVksLl = -1653050597;
    int BcbmDSCLyYHPltc = 1235737362;
    int NwWAegwNg = 1549025324;
    bool dvaBIsM = false;
    double xGdeaZmYvAhJb = -772981.0813142572;

    for (int hjVwIBhKFC = 1553231483; hjVwIBhKFC > 0; hjVwIBhKFC--) {
        nbMov -= nbMov;
    }

    for (int jEBbmLS = 639879278; jEBbmLS > 0; jEBbmLS--) {
        nbMov = nbMov;
        hXnTxgb = ODQJhzzDqgSp;
        dvaBIsM = hXnTxgb;
    }

    if (JlasJGEHA >= string("HgzHjAWurcJAKBYmEWCeMWtRIhAkIPzIWaPcAlPohZQKUJCDhuqynDfBXUmOYflgpGVFqTjXhtLLsBevaqOyDtcKolcifjgpCMBzcbaHkKXLZqOdxqRtKwJYuZEVXTTIgCMjEZeuofEMlVuQyvfJTzWYEaWdWg")) {
        for (int OxwnlARnv = 334935114; OxwnlARnv > 0; OxwnlARnv--) {
            dvaBIsM = dvaBIsM;
            NwWAegwNg += NwWAegwNg;
            dvaBIsM = dvaBIsM;
        }
    }

    for (int mjTNs = 339162629; mjTNs > 0; mjTNs--) {
        dvaBIsM = ! ODQJhzzDqgSp;
    }
}

double cSwHpD::TuKWy(int zQOnPlIo)
{
    int gMpVqM = -1049119191;
    double DCTDPtdkh = -977594.1189241671;
    int FbETBpJaJ = -1166300266;
    int uGaDTIdSxvby = -202894525;
    int eNbiFliJGyLAY = 979590983;
    string yEPzIYS = string("yYEqVcXbtTeHYNypDLwBmzeqHKteNOGUptoEJpcYhAaBZDlPBmGmXolcMaVFk");
    bool tOcAUvFOEKlQWve = false;
    int NhSZq = 758928483;

    for (int ZJuxD = 927210214; ZJuxD > 0; ZJuxD--) {
        uGaDTIdSxvby -= uGaDTIdSxvby;
    }

    for (int IyCpsGuyGOiJ = 2144175700; IyCpsGuyGOiJ > 0; IyCpsGuyGOiJ--) {
        uGaDTIdSxvby = gMpVqM;
        yEPzIYS = yEPzIYS;
        zQOnPlIo += uGaDTIdSxvby;
        FbETBpJaJ = zQOnPlIo;
    }

    for (int wxwGeaNyCoY = 640064491; wxwGeaNyCoY > 0; wxwGeaNyCoY--) {
        eNbiFliJGyLAY -= zQOnPlIo;
        FbETBpJaJ -= FbETBpJaJ;
        FbETBpJaJ -= zQOnPlIo;
    }

    return DCTDPtdkh;
}

int cSwHpD::tBKYnT(double VhZuBwEN, double tyHxNjsHSY, double TUxoNnf)
{
    double RjUjgtiDwdek = -452374.0670926327;
    double ubKUiQepQENCk = 147079.53457163752;
    double aKJQLusWT = 563841.6724823533;
    int wpvpknh = 201877158;
    int odRAQIPheakMWY = -659942520;
    double wkzjPW = -139846.75283430042;
    bool nDYjsjO = true;
    double ejutSWCd = 1021050.4887459902;
    bool kKSZlpdIsfsNmVM = false;

    if (tyHxNjsHSY == 147079.53457163752) {
        for (int IqeXCrnA = 1857485717; IqeXCrnA > 0; IqeXCrnA--) {
            continue;
        }
    }

    return odRAQIPheakMWY;
}

double cSwHpD::AfCLhXoimmq()
{
    bool uGgdEfnsbX = false;
    string XNNvNy = string("SoFRDwtcPsvLmiAvUdZlktjuEjLsKsJRbOtZgPMZhKuUbCSRHPqksHiGJYIHOeHwClfBVJkHuNHESHfujmxlTRRoQwhHCRayPMbMGFOtTfSftptaYlBOvwDamUWWuClTuWFoRYdSbWlcmQpPEVPpAGBgysdABXOkURcoTNQIKpLfEvfRNcy");
    bool NwTwg = false;
    string EykWzdl = string("YgcoxNOUBOCyXlThJHwdXxwJFclwRpuoqMUsdFdPsMxfCwYIGSPDwKbDQdMkmARHnfKkslTAcWbKbfpSXrYRMXNHWfLMyStUVJgCdQilmXkBwnfMvPpfgqdridFZRKxhlbTqtKGNxbGXoPrrphybimklbOvptnyEZC");
    string JNStQE = string("RfHGobKDoxKXcLBzzGTqSobuAXRLQZMJFjpAQKJzMckDkLuXgSGFgFccgYvopwVLvTtPUcQTTiLxJHYPApONuEOGnIMzAKjZYseqOYvsMlMreyLMRCaryCivKUuOJFuoSaabiG");
    double ziPaMpeSStbhq = 434679.64271706593;
    int UDQbOiwwqZArL = -2075237502;

    for (int ntAiYx = 1051750255; ntAiYx > 0; ntAiYx--) {
        EykWzdl = JNStQE;
        UDQbOiwwqZArL -= UDQbOiwwqZArL;
        XNNvNy = XNNvNy;
    }

    for (int QJVbkKHYC = 1208774554; QJVbkKHYC > 0; QJVbkKHYC--) {
        EykWzdl += EykWzdl;
        EykWzdl = EykWzdl;
        NwTwg = ! uGgdEfnsbX;
    }

    for (int BBtdeo = 664903322; BBtdeo > 0; BBtdeo--) {
        continue;
    }

    if (NwTwg == false) {
        for (int pqWisBqvaiXBz = 1184652356; pqWisBqvaiXBz > 0; pqWisBqvaiXBz--) {
            uGgdEfnsbX = NwTwg;
        }
    }

    if (uGgdEfnsbX == false) {
        for (int CWWlk = 131909402; CWWlk > 0; CWWlk--) {
            JNStQE += JNStQE;
            XNNvNy = JNStQE;
        }
    }

    for (int NPsArXn = 1031574084; NPsArXn > 0; NPsArXn--) {
        continue;
    }

    return ziPaMpeSStbhq;
}

string cSwHpD::kjwyacFPk(bool LuuJjUQop, int dABBaUq, bool ReTeAoxmygMvePH, bool CIFtHdDIIIOixb)
{
    bool OYgVAeHNHuNqpE = false;
    double LszsNJ = 109885.62979293063;

    if (CIFtHdDIIIOixb != false) {
        for (int kVLTRY = 491828917; kVLTRY > 0; kVLTRY--) {
            CIFtHdDIIIOixb = LuuJjUQop;
        }
    }

    for (int CdqTjHjqVvqHPham = 839109218; CdqTjHjqVvqHPham > 0; CdqTjHjqVvqHPham--) {
        ReTeAoxmygMvePH = ReTeAoxmygMvePH;
        ReTeAoxmygMvePH = LuuJjUQop;
        OYgVAeHNHuNqpE = OYgVAeHNHuNqpE;
    }

    for (int KKvNHpElEHBXC = 1024647293; KKvNHpElEHBXC > 0; KKvNHpElEHBXC--) {
        OYgVAeHNHuNqpE = ! LuuJjUQop;
        CIFtHdDIIIOixb = OYgVAeHNHuNqpE;
        LuuJjUQop = LuuJjUQop;
        OYgVAeHNHuNqpE = ! ReTeAoxmygMvePH;
        OYgVAeHNHuNqpE = ! OYgVAeHNHuNqpE;
    }

    if (CIFtHdDIIIOixb != false) {
        for (int PabcoKYPk = 1420106748; PabcoKYPk > 0; PabcoKYPk--) {
            LszsNJ /= LszsNJ;
            dABBaUq -= dABBaUq;
            ReTeAoxmygMvePH = ReTeAoxmygMvePH;
            ReTeAoxmygMvePH = ! ReTeAoxmygMvePH;
        }
    }

    for (int kFQQYFfbZxHVQdE = 1977695602; kFQQYFfbZxHVQdE > 0; kFQQYFfbZxHVQdE--) {
        CIFtHdDIIIOixb = CIFtHdDIIIOixb;
        LuuJjUQop = CIFtHdDIIIOixb;
        LszsNJ -= LszsNJ;
    }

    return string("IznnlOwuPcfhAEhVKGkIfPMYMontApFHMyrOrEceh");
}

cSwHpD::cSwHpD()
{
    this->GZHabBDqIVfdYRKX(814138.8020805847, 714868.6096915567, 86028.782240379, -112514.44361992729);
    this->vnNnWBBXRcLlJGqI(true, false, -579325625);
    this->WjIVtcLiTyt(140903414, false);
    this->TeXtgIAoIzaXm(1804409005, -521298.88233608747, true, string("AAEyQFdmZXQclqlklQHNuQRTlkRHLXAXWneZGKugyiESVEMJwXFSEkhtKXuSLdKdWODoLnDEfFkohzFsxaQNegEsLSABneknjyCLuZUFtgtbaMUVyVWxZfqCppySWCmBPxaOmHDFfVeGuRetgvOzZPXczTcRrUljvVkNPntnjFtoSegHuOffNiJTgqJCcMqyjFY"));
    this->GhttRGnAe();
    this->iZUyyu(true);
    this->NzRTJ(false, 428373983, 192369.4588935954, string("HgzHjAWurcJAKBYmEWCeMWtRIhAkIPzIWaPcAlPohZQKUJCDhuqynDfBXUmOYflgpGVFqTjXhtLLsBevaqOyDtcKolcifjgpCMBzcbaHkKXLZqOdxqRtKwJYuZEVXTTIgCMjEZeuofEMlVuQyvfJTzWYEaWdWg"));
    this->TuKWy(-423423235);
    this->tBKYnT(436898.2525891401, 390765.9749327705, 771844.6489918311);
    this->AfCLhXoimmq();
    this->kjwyacFPk(false, -125362069, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pbLaBG
{
public:
    string ksMNywzdSkMP;
    int PMRllvUbMYzld;
    bool eCiKruTtUJ;
    int ezevZhFMLsqb;
    double ZyrtqqsldWZOjwQ;
    bool pcOCR;

    pbLaBG();
    void veYqpzVqWJSjuJXz(string MlOPNQuJAxwGpDa, bool WwAWYdoGCRpAMnQn, double aZVXQeR, int kIzSplCefcxbpXt);
    int mNHNc(string VAzanJNu, bool muvRvdtiPzAxGKz, string zbKCyi, string ZguQATnJkLinP);
protected:
    double ekulDJK;
    double nnSyRqWknK;

    string REJbOFeSBKhRdbkz(bool iwvbE, bool fPREigPcHsUGN, string NrwgdYGc);
    int zDMjzkDsy(bool FKuWgdDhojHde, double utJWMNcK, bool qvnDkpDLWWoig);
    bool GaUGjHONSFtHEMPD(string YaLzQA, bool QXwGDIAjBbkX, bool RdGcGRziOAeZ);
    void cYdUmkgWWVjtWFQo(bool nfmadSGyjHZe, int zdvrUxZdohJ, string JhhVZGcwjtITZzZ);
    string imJFEICzzNn(string hvftLzbEI, bool JyZyFmMQRvvhLg, string JEGETemeIaM, bool rFAElXKP, double QozlVQUUuoZ);
    int fpPQUSp(string kTRviQhc, double YhMjFEgp, string XSnMLGqqITeS);
    void sLlGbRqBj(string WhqjkVT, double mQjTTLeEsSg);
private:
    bool PudHGPzeLFL;
    bool wRioHMzB;
    string mvXFPbeLGgw;
    string nqdCaPGZV;

    string AJlAFxkjfhJO(string mOTbA, int hfnVCHpIt, int PJuNYu, string lIApZDVoyNRNeToe);
    int snKYAgoicsme(double uwaPxoTwRksH);
    string HZEOm(string BeaNvQXjDR, bool kyCrRZEJruKhjS);
    bool LfrJa(string dkkRogc, int RVewAOUAkacosuKe, int zybyjlufLJbQkV, string fKpRr, bool jcnuSixzewpRVhKm);
    double GDZMIwVRUbE(string nvofNkhCfccxONq);
};

void pbLaBG::veYqpzVqWJSjuJXz(string MlOPNQuJAxwGpDa, bool WwAWYdoGCRpAMnQn, double aZVXQeR, int kIzSplCefcxbpXt)
{
    string xWEzjrSw = string("MZppZqAGcapMYoGKruuBIKYjMblNGQmOJjJxXlWFbfhCUFLAAxsbtZycekQfigirkMAZPdgTvpfUrKKkegCLVjvEaAovxhBfCBhEboJmfhrAkZCluSioIxEDDAkJsmYbIsOOeyTKXNPlpOuYZfsNZOJjuceuqSe");
    double UHdicANHtWGC = -230203.8371549372;
    bool ZrtmpvEq = true;
    bool zywruFvSeHehtjiX = true;
    int EvkJETdoJafABRM = 1319347035;
    string sILrPuaczdw = string("tprdIViPwNNrhEieuvVXwJLfusEJDNkqKQSUDPbTljEnTjyYufJHvrJBPChrrKXSWdVXhmKOmLmpjQnAeenGCexNXXZYxtTOQZXNmlxmnBesDBekMgtSyhj");
    bool OtUho = true;

    for (int zEbfudrkp = 119034066; zEbfudrkp > 0; zEbfudrkp--) {
        zywruFvSeHehtjiX = OtUho;
        OtUho = ! OtUho;
    }

    if (WwAWYdoGCRpAMnQn != true) {
        for (int WEywdstTBhP = 858850435; WEywdstTBhP > 0; WEywdstTBhP--) {
            continue;
        }
    }

    for (int TgKzNeIFpC = 2000255267; TgKzNeIFpC > 0; TgKzNeIFpC--) {
        xWEzjrSw = MlOPNQuJAxwGpDa;
        OtUho = ZrtmpvEq;
        UHdicANHtWGC -= aZVXQeR;
    }
}

int pbLaBG::mNHNc(string VAzanJNu, bool muvRvdtiPzAxGKz, string zbKCyi, string ZguQATnJkLinP)
{
    string rJgWnW = string("qUWtjTdbLCaaDdUhrACJwSJdtxOLWIVwTyIWWwtvsqPqrFTYPNuzlqUjoDhRhdcRuLIeRTVhFCuBpeliUAEpdthhTDjROqpazyVHfneapukPdCzSqoxcXbYrdDoCVnSBBtMLZBXyYlujfwYFAMyjqAYCWsERivWnemWjfzGJAcFzhlizyvAqvYCWxwZgxPkbUsiRJYyjwqYrmCeTlAnlzQxjJjuQlbVIVGBllUoQuLbuKJngtZsBVpUZb");
    string snKoaPVBSLEEC = string("GdLXmjbCdFQrUkCqjoShTLlDfLnHYSBaVKzhKnWyERtEaIRonsbyzfxLaskiEzUqWrrfDlLaFCJngvBhuOZLruicSjXYzCduYXGvJnTwuYdPklHpjjJpjBelJxBEJCZfGlFxXxYFvZiFKkdnvjHxsEkIoaUqnVBQSLCdEpQuHFgYChcOAwyyjrcQWBBPDQqLficgFDJvQuxBuBmUCCRvPoVbwuRdKZTDKaCNcSkPJVOvk");

    if (VAzanJNu < string("JBRNifYobuNXSBHIzLTrOpAPPjaVykIIboGxZXuMQMBFIRfSQLCJgRXsdGSQdvbfcqNDccacRYxMNMOCfimqvphdYgIsbGvwMx")) {
        for (int ymqQVGncfIMvLGl = 1240377806; ymqQVGncfIMvLGl > 0; ymqQVGncfIMvLGl--) {
            snKoaPVBSLEEC += VAzanJNu;
        }
    }

    if (rJgWnW <= string("xbrKIFxawvAbWqCPOUpFbpKQNvfqziqSrPhOIzAHRQtEOSWXlCTEfDVXxiHOgfWkaBPupixPYSnvN")) {
        for (int CjQkfnSOEIkkxL = 598274756; CjQkfnSOEIkkxL > 0; CjQkfnSOEIkkxL--) {
            rJgWnW += rJgWnW;
            zbKCyi = VAzanJNu;
            VAzanJNu = ZguQATnJkLinP;
            zbKCyi = snKoaPVBSLEEC;
        }
    }

    if (ZguQATnJkLinP == string("uYqyMNlPTktKocoHrJnuXLMBjQhNEQhNtkUdWpFPwiXasbacCHfxzz")) {
        for (int naiUEaRCCjF = 2035732984; naiUEaRCCjF > 0; naiUEaRCCjF--) {
            VAzanJNu = VAzanJNu;
            muvRvdtiPzAxGKz = muvRvdtiPzAxGKz;
            VAzanJNu = snKoaPVBSLEEC;
        }
    }

    return -1219406258;
}

string pbLaBG::REJbOFeSBKhRdbkz(bool iwvbE, bool fPREigPcHsUGN, string NrwgdYGc)
{
    int uXkkOmEfSmsZ = -1728740757;

    if (iwvbE == true) {
        for (int cvjorxAbRGZhgue = 1431771931; cvjorxAbRGZhgue > 0; cvjorxAbRGZhgue--) {
            fPREigPcHsUGN = ! iwvbE;
        }
    }

    for (int AGucvaHMMoc = 1361965257; AGucvaHMMoc > 0; AGucvaHMMoc--) {
        continue;
    }

    for (int LezrsBYQ = 548933758; LezrsBYQ > 0; LezrsBYQ--) {
        NrwgdYGc += NrwgdYGc;
        iwvbE = iwvbE;
        NrwgdYGc = NrwgdYGc;
    }

    if (fPREigPcHsUGN != true) {
        for (int HMEtk = 68416312; HMEtk > 0; HMEtk--) {
            continue;
        }
    }

    return NrwgdYGc;
}

int pbLaBG::zDMjzkDsy(bool FKuWgdDhojHde, double utJWMNcK, bool qvnDkpDLWWoig)
{
    string QGpxjLfxIolfO = string("RNIirlzmwhqkxwVPPCJHepwoCJhuzaMUcGzCHThDHAcmvsxWeEI");
    int GrRoqxYcPExNzaT = -1724086917;
    double hYPJFmvKaBIuo = 816911.1707292718;
    bool rfrTzHvPuQ = false;
    int PjorTTdXP = -59553809;

    for (int sGNdbcJxc = 1153210958; sGNdbcJxc > 0; sGNdbcJxc--) {
        PjorTTdXP -= GrRoqxYcPExNzaT;
        rfrTzHvPuQ = ! qvnDkpDLWWoig;
    }

    for (int KzaEjcanutRvmZ = 1125505897; KzaEjcanutRvmZ > 0; KzaEjcanutRvmZ--) {
        PjorTTdXP /= GrRoqxYcPExNzaT;
        hYPJFmvKaBIuo = hYPJFmvKaBIuo;
    }

    return PjorTTdXP;
}

bool pbLaBG::GaUGjHONSFtHEMPD(string YaLzQA, bool QXwGDIAjBbkX, bool RdGcGRziOAeZ)
{
    string lHLHJtBxOelFDhvR = string("XwzfSqeRNUtCHRFnqBvgKzZVQzbvRYrVQiODYncnUglVzCCdIITSxLABoevLusydSoZiFIkcWxrypYpupoWrW");
    bool mxaVHDVDJbsqVzM = true;
    bool WRyuJGIFoXBpLX = false;
    bool EJEDLaglqaB = true;
    string uoujVpSXXsN = string("EuKaVgeBlHSWqQXNBuAuRGswJCkYBKZKOJziTICoIpMkECKaqPXJEwxmhbQhhcpmaTuNJacMbyPAFvWtIqNvUBwKVWPvKdXevnnvMgXAkpwbxnXbCTBQiiNjYIMAMFniYxbGnHAs");
    int lvZfFH = -1755180036;
    bool aOvUPz = false;
    double LWQEXPTQeCZOJn = -712645.7693417871;

    for (int pLetzBLg = 869030730; pLetzBLg > 0; pLetzBLg--) {
        uoujVpSXXsN += lHLHJtBxOelFDhvR;
        YaLzQA += YaLzQA;
    }

    return aOvUPz;
}

void pbLaBG::cYdUmkgWWVjtWFQo(bool nfmadSGyjHZe, int zdvrUxZdohJ, string JhhVZGcwjtITZzZ)
{
    string KaDxdhI = string("SZnDYcKTMXmmIpdjZIkfMKoxwIkxnHoUNwXNgRwiXgKaKdJEatIlq");
    int KUpIURAjHJOBj = 808017913;
    string OqHockCkbWSQ = string("kKihjxwzCEyxBVdJshNdEbCPOzmwavBKUIFIifeexUCmJIAgYeExOTcQkXHBWUQHWiyenhWRXHGtvtbwrhiWcRinTkaNjiVrqXlaxkfDwErRYTyalXdGjvBQKATDqzdMTxZVSNFFQbcGGfyZdVcmNhEcyRQnWiJWmtb");

    if (KUpIURAjHJOBj == 808017913) {
        for (int qhmYof = 1542393916; qhmYof > 0; qhmYof--) {
            KaDxdhI += JhhVZGcwjtITZzZ;
            JhhVZGcwjtITZzZ = KaDxdhI;
        }
    }
}

string pbLaBG::imJFEICzzNn(string hvftLzbEI, bool JyZyFmMQRvvhLg, string JEGETemeIaM, bool rFAElXKP, double QozlVQUUuoZ)
{
    string YnWfAAcs = string("NgGPVswIEXoAWZMDgFfEQxBKoTBPDlPqjTLhtNgamfDmKLRnVnWOPdMmUFzcFAVUExLFopobLteNzSaBjdvzwZugMNqRvHwCSWGrVXuOQnAhHDeDXMEYuPgbmIUfGkSpopYcdoopFXkiNqpaYOrRPCcmJ");
    int DEpxAJL = 1717452404;
    string xAXVUuEimRpFM = string("fWlEatXsBfCWKerZTAvGBdcFxTgZwwmihjBMkiEYLRmBrRynGfiZxPchDigERblEcnCtwGVNFPECgiYgpPAmFvtlKHLXlXmUonqpHWXvCxliotaTdMyGyPZnXmQeahdvCtkLxzxhAzjAlDBBsKtZFEwDBGSOicQZa");
    int LUCjDJxQUJKTdtS = 1349276918;
    string pkPqoT = string("IFvIwygJlBYXUSMrORAyVStaxZfWYwwWkFIbbXZhYMGqghYzSmziYtgaJmUwpZBfVhazkruqXnVwE");
    bool TEtZvwlkJZGhdWC = false;
    int SVNSAljRZKgtB = -412909885;
    double oDQSRphbPysWKwH = -878043.5853855732;
    bool HEThjteRIV = false;
    bool uKbhhudbo = true;

    if (xAXVUuEimRpFM <= string("NgGPVswIEXoAWZMDgFfEQxBKoTBPDlPqjTLhtNgamfDmKLRnVnWOPdMmUFzcFAVUExLFopobLteNzSaBjdvzwZugMNqRvHwCSWGrVXuOQnAhHDeDXMEYuPgbmIUfGkSpopYcdoopFXkiNqpaYOrRPCcmJ")) {
        for (int SgKzkHfP = 420998030; SgKzkHfP > 0; SgKzkHfP--) {
            xAXVUuEimRpFM += JEGETemeIaM;
        }
    }

    for (int RtUGgcwMqGveucVN = 1299875604; RtUGgcwMqGveucVN > 0; RtUGgcwMqGveucVN--) {
        YnWfAAcs += xAXVUuEimRpFM;
        pkPqoT = hvftLzbEI;
    }

    return pkPqoT;
}

int pbLaBG::fpPQUSp(string kTRviQhc, double YhMjFEgp, string XSnMLGqqITeS)
{
    string EvgoHPpHFm = string("ZoTJRbmcHEWfadEcEQwoUYOSsnmGdpliUlJmazolLFCUGLaSPkfNqYQqLSpMmAdYrUdlgXczNTUnRRIWQHjGhTigSuvvHgBVCaOpmmdtmvcHvyjNhXUpdLhRdIWNPjqTWPGRatFsWEjYHOvQKaHfgoBMHKhxeBbKljkEhePHTgMzBasiUtDWrcbbdpDmpJdazwlrTfKJjVglxZxxgrewJeGQuGtZG");
    double tfVfQGrDG = -435833.5395355182;
    bool igOUZPHpDLqulNAP = false;

    if (tfVfQGrDG <= -311248.27697323076) {
        for (int gSQVKHTbqpr = 858780289; gSQVKHTbqpr > 0; gSQVKHTbqpr--) {
            EvgoHPpHFm = EvgoHPpHFm;
        }
    }

    for (int VpzNgotjuoRc = 1772470189; VpzNgotjuoRc > 0; VpzNgotjuoRc--) {
        tfVfQGrDG += tfVfQGrDG;
        YhMjFEgp -= tfVfQGrDG;
    }

    for (int WZrGTuSNrdtd = 1272080511; WZrGTuSNrdtd > 0; WZrGTuSNrdtd--) {
        kTRviQhc += XSnMLGqqITeS;
    }

    for (int EtBSpfXKzwEI = 571045684; EtBSpfXKzwEI > 0; EtBSpfXKzwEI--) {
        tfVfQGrDG -= YhMjFEgp;
        tfVfQGrDG = tfVfQGrDG;
    }

    return -1200479729;
}

void pbLaBG::sLlGbRqBj(string WhqjkVT, double mQjTTLeEsSg)
{
    bool KPTLYTBjL = true;
    string phmFzxfAt = string("scwIkCqWCghweRtmLntFKBWUgOTGfojNdhlZDSlvDVlFxSxrBOhtOjDMkjmKAEPPwZruWhOMBpdQREkosmkrHYaCaMeyVDhQkmmOCspIMn");
    int gzrHnPMaKdrThDj = -474951943;
    int gOQIXTm = 549943770;
    string meHbY = string("NJXBFiXXyXGNMfVHmAdGbJEUacZfmsXFsIOgznwcVBaYwimgkeiUEPuYarLykywTyotN");
    bool IRtTXSKyoMYH = false;
    string dvBsGUZFvxK = string("JtnnVKjnupczqqZZXuzUOHTvmaTSaKaNuDBrgDcOqbDAusiuYWHeOYKRWxVGLZmEmtnpYDtgGnzJeVtZeqVakbwRnMUfUsqYoLm");
    int TwUeZOYRHY = -50525943;
    int witWyfZ = 145200958;

    for (int LeJdphk = 627401170; LeJdphk > 0; LeJdphk--) {
        meHbY = dvBsGUZFvxK;
        meHbY += dvBsGUZFvxK;
    }

    for (int QkYPtObJEQUca = 1648636728; QkYPtObJEQUca > 0; QkYPtObJEQUca--) {
        gOQIXTm *= gzrHnPMaKdrThDj;
        WhqjkVT = meHbY;
        TwUeZOYRHY += gOQIXTm;
        meHbY += meHbY;
    }
}

string pbLaBG::AJlAFxkjfhJO(string mOTbA, int hfnVCHpIt, int PJuNYu, string lIApZDVoyNRNeToe)
{
    double QayiKqjNMO = 616256.8531104464;

    if (lIApZDVoyNRNeToe > string("cervOQxTLDkTSQkfpXGOieEriVpChRSTHPpgJpFFHZMEdhVjSYVTmBjXxJUaXLuloQcHFLeTOEyNvLslrhMmBvmLsKcQESrjJqXoUprClPcTNGHMJvffOwDamPlYMjmecrHlcYROzyblTCescQIDaIZQqVvuJAbrhFAVfbxrQYQXgorugrrmhpTjbrGjBvmNIgWfnqtXxMSApBkCWHdBMSDnAWojbLRKacvnChae")) {
        for (int WkLkM = 875024842; WkLkM > 0; WkLkM--) {
            lIApZDVoyNRNeToe = lIApZDVoyNRNeToe;
            lIApZDVoyNRNeToe += mOTbA;
            QayiKqjNMO -= QayiKqjNMO;
            mOTbA += mOTbA;
        }
    }

    if (QayiKqjNMO != 616256.8531104464) {
        for (int lrHvuiUott = 1969133219; lrHvuiUott > 0; lrHvuiUott--) {
            hfnVCHpIt *= hfnVCHpIt;
            mOTbA = mOTbA;
            mOTbA += lIApZDVoyNRNeToe;
            QayiKqjNMO = QayiKqjNMO;
        }
    }

    return lIApZDVoyNRNeToe;
}

int pbLaBG::snKYAgoicsme(double uwaPxoTwRksH)
{
    bool QrhSPlLQ = false;

    for (int gZzOiWdSuNrPH = 1964312730; gZzOiWdSuNrPH > 0; gZzOiWdSuNrPH--) {
        uwaPxoTwRksH /= uwaPxoTwRksH;
        uwaPxoTwRksH *= uwaPxoTwRksH;
        uwaPxoTwRksH += uwaPxoTwRksH;
    }

    for (int fXuKhgTW = 1757194635; fXuKhgTW > 0; fXuKhgTW--) {
        QrhSPlLQ = QrhSPlLQ;
        QrhSPlLQ = ! QrhSPlLQ;
        QrhSPlLQ = QrhSPlLQ;
        QrhSPlLQ = QrhSPlLQ;
    }

    for (int sRJhZcTAS = 1518252935; sRJhZcTAS > 0; sRJhZcTAS--) {
        QrhSPlLQ = ! QrhSPlLQ;
        QrhSPlLQ = ! QrhSPlLQ;
        QrhSPlLQ = QrhSPlLQ;
    }

    for (int PWsNetKexWELYmYz = 1164776157; PWsNetKexWELYmYz > 0; PWsNetKexWELYmYz--) {
        uwaPxoTwRksH /= uwaPxoTwRksH;
        uwaPxoTwRksH /= uwaPxoTwRksH;
        QrhSPlLQ = QrhSPlLQ;
        uwaPxoTwRksH += uwaPxoTwRksH;
        QrhSPlLQ = QrhSPlLQ;
        QrhSPlLQ = ! QrhSPlLQ;
    }

    for (int SKAeOPmZIWmCVI = 2121263884; SKAeOPmZIWmCVI > 0; SKAeOPmZIWmCVI--) {
        QrhSPlLQ = QrhSPlLQ;
        uwaPxoTwRksH /= uwaPxoTwRksH;
        uwaPxoTwRksH += uwaPxoTwRksH;
        uwaPxoTwRksH -= uwaPxoTwRksH;
        QrhSPlLQ = ! QrhSPlLQ;
        QrhSPlLQ = ! QrhSPlLQ;
    }

    return -1656500552;
}

string pbLaBG::HZEOm(string BeaNvQXjDR, bool kyCrRZEJruKhjS)
{
    string mfFhOTNFLyZzuJ = string("csRufNeWdsQmRWYQSsMWmAFoEitveKjocOaBCGwZCXAeHfXXvrLcbG");
    double qOdBwEFXXJdTQL = -1017357.292300477;
    string WgANqpmrnk = string("HxHwURSJJVXgXtgrSGAXNbxEUrOXmRIbHNQYWEKaW");
    bool nLDfaHTGLGn = true;
    bool utXBZ = false;
    int uqtFzfqUwjpp = 1148008580;
    int QGySIIOr = -796092731;
    string kzjtxJaDKCDjTazG = string("MddjyNoGbcWkZPAFRXGbTjfYLmcgXuPtjdghRaKnhxFjRxRZHufbFNVTYmzCrTPRrwuIxKaehQvOifdUahmkJOGLbDUscLzjADSSMDxtEsXpRUBNqkWnXIgFnXQYzjDuOsiqQyNrugAXPhFa");

    if (kzjtxJaDKCDjTazG <= string("csRufNeWdsQmRWYQSsMWmAFoEitveKjocOaBCGwZCXAeHfXXvrLcbG")) {
        for (int FFrxeyUC = 1869716042; FFrxeyUC > 0; FFrxeyUC--) {
            continue;
        }
    }

    for (int bLLYGEspFeOtSigR = 1278163346; bLLYGEspFeOtSigR > 0; bLLYGEspFeOtSigR--) {
        kyCrRZEJruKhjS = nLDfaHTGLGn;
        nLDfaHTGLGn = ! utXBZ;
        nLDfaHTGLGn = ! utXBZ;
        WgANqpmrnk += WgANqpmrnk;
    }

    for (int vzcHGFWLY = 933549834; vzcHGFWLY > 0; vzcHGFWLY--) {
        qOdBwEFXXJdTQL -= qOdBwEFXXJdTQL;
    }

    return kzjtxJaDKCDjTazG;
}

bool pbLaBG::LfrJa(string dkkRogc, int RVewAOUAkacosuKe, int zybyjlufLJbQkV, string fKpRr, bool jcnuSixzewpRVhKm)
{
    int DnbjyyYLDLd = -958340991;
    int IHmtMbhwxhEDwb = 1288882685;
    int MGyrohIv = 1787109506;
    bool PjcUaaON = false;
    double vhaBmDQzwQH = -1040005.0252037987;

    for (int BigjA = 837196571; BigjA > 0; BigjA--) {
        fKpRr = dkkRogc;
        zybyjlufLJbQkV *= IHmtMbhwxhEDwb;
        IHmtMbhwxhEDwb += IHmtMbhwxhEDwb;
        DnbjyyYLDLd *= zybyjlufLJbQkV;
        zybyjlufLJbQkV = RVewAOUAkacosuKe;
        DnbjyyYLDLd -= IHmtMbhwxhEDwb;
    }

    if (MGyrohIv <= -958340991) {
        for (int rJdSLvhkjlKmVQ = 955779816; rJdSLvhkjlKmVQ > 0; rJdSLvhkjlKmVQ--) {
            continue;
        }
    }

    for (int aOqzKtgGYOU = 446600114; aOqzKtgGYOU > 0; aOqzKtgGYOU--) {
        MGyrohIv /= RVewAOUAkacosuKe;
    }

    return PjcUaaON;
}

double pbLaBG::GDZMIwVRUbE(string nvofNkhCfccxONq)
{
    string cWAitZAIrEm = string("afZgfbIkJofkGKnjGwAacbJJKEdaIanRSmvRomUZpNSNphNadQvZIWDzGgUBznGeBubbKrzhxybfDmLqrTLLOllnCTodWyGeywnNuEasVBLcbRpEhBPRsbANbySoCyEAzXmOcgwATIRtkMBZVhRWCQYxPqsFDAxKgVvpXlRItLhOjdiBurthjDisncAYmkFbHWPMVoynzSMSlHyLurzYptExbGoCoIhSvmDHZoZvqJOsBWvufGLPwsykNdIivsb");
    string xBtWIOzWpfITl = string("EgiRubYOgXhUPPQJHNWeIOkWVkMWYVtwcTUBYRpVjbsuShlsNhCQzRBVVdjgfLLKWxeEtyNkqjkZwmuaKsoLEElrUchMlkwLQTianQ");
    double rVIhpwX = 875010.5595807992;
    double HMWmJo = -218273.22188723934;
    double FFbxASVKbSjzP = 58396.90344747435;
    int ZrtaTfCo = -194091271;
    bool kGxRDa = true;
    double iidYxYWgaq = -236878.78830948315;
    double WiDsbhlhtWm = 615382.288759636;

    for (int NfiOCRBvuL = 1567204511; NfiOCRBvuL > 0; NfiOCRBvuL--) {
        iidYxYWgaq = WiDsbhlhtWm;
        iidYxYWgaq += HMWmJo;
        HMWmJo = iidYxYWgaq;
        nvofNkhCfccxONq = xBtWIOzWpfITl;
    }

    for (int tvqsJZye = 150558502; tvqsJZye > 0; tvqsJZye--) {
        iidYxYWgaq += FFbxASVKbSjzP;
        iidYxYWgaq += WiDsbhlhtWm;
    }

    return WiDsbhlhtWm;
}

pbLaBG::pbLaBG()
{
    this->veYqpzVqWJSjuJXz(string("ITjKcdEbRxSLybvLYSsbM"), true, 466156.87052241585, 1641228384);
    this->mNHNc(string("uYqyMNlPTktKocoHrJnuXLMBjQhNEQhNtkUdWpFPwiXasbacCHfxzz"), true, string("xbrKIFxawvAbWqCPOUpFbpKQNvfqziqSrPhOIzAHRQtEOSWXlCTEfDVXxiHOgfWkaBPupixPYSnvN"), string("JBRNifYobuNXSBHIzLTrOpAPPjaVykIIboGxZXuMQMBFIRfSQLCJgRXsdGSQdvbfcqNDccacRYxMNMOCfimqvphdYgIsbGvwMx"));
    this->REJbOFeSBKhRdbkz(false, true, string("GsdSTIsBjiXwIlyWyFORUnTcsFsZoJmJHsTZKShowXfItsHYT"));
    this->zDMjzkDsy(false, 954956.019748877, true);
    this->GaUGjHONSFtHEMPD(string("KqLhUmFtbwvCrQsTtXcXBeJLxwOZctPpfJhtUFHkIehtWRJEfSUozwDXfhjYQQxKRKfmocgLyHmlGWvikoQdlYXNKdobFkVsWPcsDSCubUFVWQbYyfhqwPQaNmVsZJaEHmNPbxklwYyaAdaLJdWrsQiEEvqYUFOrYtDmJlyjtvkDUWzhOiMqwBFLqKADn"), false, true);
    this->cYdUmkgWWVjtWFQo(false, 364610608, string("kbKWvycWgEupWgpBdJKhxtDcBIrUdGGiQRYgbQbTLPNlSKRKEQYKPXBJBImBdkkHgjYZrTWlJSEXYlZecdobXyweIwIZeLqdijBMbPBRtPFSoOGrCNLJoAWHAJZvqSfJYnZtgDwFFpjQaZIrtjMbAvmMqJxVYanaRgAcZrYvkuxkzFheyiRVabJylpQiCCpJHXMrppblUIATewfvLtbBpmwkxTA"));
    this->imJFEICzzNn(string("udBcFAfTFAbnnZHGXIzTviXJjjxQgljjFjEhrKasFPOKKxujgRkVHfbSFLOOZFkcHGKnqQszYTEIXypNehwNeRhuPexsxBlVex"), true, string("bmuByUDFSMNWriprTLKwWCOFFiyVbsvXoeyywHdTawNsZRKgMgfosNHbBtgPPJvwRbRAeMwjsxrrRdmlyZxsNAlTWEuzqtXlGihqBnVYbBerunXZFrCvUCnqgLTqZLnLsAGuEIvWtlzdqaiPuFMFxaDPhhVLXDYqetgpCOxFWYATPjpcvzOsSxLoyJOSeFOpbWZEzdPozjNSKOPooAxCKmyVFRXJZJDGdSfuafvlrSbEuEoMTQ"), false, -393337.2740124786);
    this->fpPQUSp(string("pTWyjjyIQtUMANzwxSiIcqWTAlXpUDtyruoUElLAeSmNgxsStzklfSewhkQhYleOqvCtHXuSaiPfkXVBzKILrDxmziXRepZlneWpQSDmndAfWRJeBYnbGtPgulMifLAtaeRMBvjxuCBdhefTKuXljZIZhTPlQlOYIwMnYzJmcLzSfmdjLIBHwHMbMhrZDGCQaQQvumdF"), -311248.27697323076, string("XrHSmJtnqkdiBmNmIkkkPfxLLQkdWAPXRioEowb"));
    this->sLlGbRqBj(string("SxvEPtpUJBSSgCPcAjFnFjTotkegItaChoBbvhXsNQPHcgrKoPhcpkZTPKHsDHxZlmiwSCYgoiZnTWyxQmmkfaoSLmRYjKaqIqlXbvrxcpMtgtmikEJHvJxPmGhfPAEzmUNKHDjgrtgdwxqTBXIYLtMZxJOVYuCqWyRCtGccjXfyBiSTbbHUXqCYoQnWvZVI"), -910953.0284132814);
    this->AJlAFxkjfhJO(string("OmKFSVWWGbBes"), -2060316672, 721418716, string("cervOQxTLDkTSQkfpXGOieEriVpChRSTHPpgJpFFHZMEdhVjSYVTmBjXxJUaXLuloQcHFLeTOEyNvLslrhMmBvmLsKcQESrjJqXoUprClPcTNGHMJvffOwDamPlYMjmecrHlcYROzyblTCescQIDaIZQqVvuJAbrhFAVfbxrQYQXgorugrrmhpTjbrGjBvmNIgWfnqtXxMSApBkCWHdBMSDnAWojbLRKacvnChae"));
    this->snKYAgoicsme(-58522.31713776416);
    this->HZEOm(string("ikLtlfKrfaqWZWfATBSlTOFkPZkypNYAGsJtz"), true);
    this->LfrJa(string("cPTDaEyftyOzrSVkzwdZlLKvDufUghbhivaNlZkUqnHoUAOZhiLafBvVbOqiqGvnfzEkLqpruRCnj"), 1327438342, -1806410204, string("kwuaUssPfkRbFBwvPoeZYksrHzaWXvzcljFXGaQTNHQuCwLTwjyXMZAImqsklUgyewWGOYFCEdRFIWtgRZ"), false);
    this->GDZMIwVRUbE(string("xFlCWwDTEgOtMOKDNOAQEqRiFORHmTDtgGxrDJjvkRrZioTnJKeTIzKJhjumRlNoDSCBhmnMQQZhOwtwWYKCkBSYbcpHNUAmWziSiGUATsqXONhkYitqvMakAQOPyeXwdRqnmNgKZwkryCzVVOrhksxREOhGgRJoddIVDcUVYIzBuwtDzlozblACaKvrgATZhwS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FKqcAt
{
public:
    double fObbzmKzs;
    string pCdiqsWqiyswoY;

    FKqcAt();
    void rUcNfTQpYLgZeslN(bool jzivXce, string ozZrfZRBgj, bool QYnwnLiXvA, bool CrfzI, double pigDishFHY);
    string OPgEkgXwfryWLRz(int ZWQGvfHgWa);
    void gikKmpsQMk(bool jZbyLvTg);
    void oCwMxZh();
    int ZwQTvgw(double LFDlaWCzzqtXR, int uNXufrF, bool izPmzRA, int cYSbFUwlOpwRWsab);
    void MbhYDyJflwIdFbn(string jugcUgoZcAbfzv, string pzBTbbqsgKHIhHm, double OdQrdB);
    double gUntxkPFdIj(bool LGlufJrqz, string lByTiiqEg, int lJuUzY, string wVbsgLo);
    string qZPpbwrHeBPFrHlX(bool WJFQHeBNWogJRu, double ZKPOEMeZDkmCZR, string yfUnhFnhCkyaJceB, string NycDoMkviHUbvf);
protected:
    bool nhKSZydQsFBs;
    int BwlQF;
    bool HKPXHDfLZLuAMfa;
    double RKmJWEGsJVHr;
    int rBijoqfXF;

    string bgqTZrvaQgYI(string JKXlmkKL, bool QOQaWtoUnoHANG, string ipjsuJrUdRiUEY, string BnEkupARRjK, bool aGWzVNsvPN);
    string dJooSwXpdtuXe();
    void rosKYZkfjpLoyvI(int gZGfNqIfv);
    double sSGRsQSwvSw(string aQgaMoq, int YBxarPV, bool alIsU, bool howrqdyBPZNxO, bool JuMaYxjbjky);
    double RlOADJBWl(double vnOHgzPFzlavQ, string LPkLznEcYHX);
    string dRtgcTMbHIITf(double DOywGc, string tqrHAFz);
    bool rzACmpmN(int gOKJlYzPFy);
    bool haocLOtRrDBGT(int SqVVCStaCvqg, string yhTWJrSC, string EmVpPPuWKW);
private:
    int JANbImJ;
    int BNQsalbpxWeyI;
    int tJtzdnP;

    int pRSdNQtWijIg(string BZDbAjRkpnafC);
};

void FKqcAt::rUcNfTQpYLgZeslN(bool jzivXce, string ozZrfZRBgj, bool QYnwnLiXvA, bool CrfzI, double pigDishFHY)
{
    string lTILtbIFghmb = string("jFmapsTNTEvkuRAxYCIKRCABTovgZLuLTLBvpVLgKhQwuUlrAPbAUqpVjhPahsJPDAFjzEIg");
    double mpScOxaWBA = 123500.44712472867;

    if (pigDishFHY >= 123500.44712472867) {
        for (int KzEbmU = 356100356; KzEbmU > 0; KzEbmU--) {
            CrfzI = ! CrfzI;
            ozZrfZRBgj += ozZrfZRBgj;
            lTILtbIFghmb = lTILtbIFghmb;
        }
    }

    if (mpScOxaWBA >= 599755.4038596499) {
        for (int aixXvvneDOBBb = 225183552; aixXvvneDOBBb > 0; aixXvvneDOBBb--) {
            lTILtbIFghmb += lTILtbIFghmb;
            lTILtbIFghmb = lTILtbIFghmb;
        }
    }

    for (int iuxyVFnZqokC = 1203651488; iuxyVFnZqokC > 0; iuxyVFnZqokC--) {
        pigDishFHY /= mpScOxaWBA;
        jzivXce = QYnwnLiXvA;
        lTILtbIFghmb = ozZrfZRBgj;
    }

    for (int DnAYlX = 563698073; DnAYlX > 0; DnAYlX--) {
        jzivXce = ! CrfzI;
        mpScOxaWBA = mpScOxaWBA;
        lTILtbIFghmb += ozZrfZRBgj;
        QYnwnLiXvA = CrfzI;
    }

    if (CrfzI != true) {
        for (int CNqedPJyixLL = 1949309123; CNqedPJyixLL > 0; CNqedPJyixLL--) {
            CrfzI = QYnwnLiXvA;
        }
    }

    if (QYnwnLiXvA != false) {
        for (int FzzihPuPfWc = 1243188511; FzzihPuPfWc > 0; FzzihPuPfWc--) {
            continue;
        }
    }

    for (int bOBBurP = 429772699; bOBBurP > 0; bOBBurP--) {
        jzivXce = CrfzI;
        QYnwnLiXvA = ! QYnwnLiXvA;
    }
}

string FKqcAt::OPgEkgXwfryWLRz(int ZWQGvfHgWa)
{
    string YbKPkXQRkFP = string("vwAGjGtPRWXZUamnqjcQGuZFQDlIChMkWoAUjlLsjqWVaUnt");
    bool rimSegXKYCv = false;
    string ZucRWuQKfQsyln = string("AULzkEIHKxtTWVQlXAMXTFlCaNMMWQBIufJYigoZcXeNjkxXSrJkbfMkaZhzAHUNgtJQeWtliasUylPuadXuuWDoslPUZYSzdrfMBtZIAMjUdbawlAepvkEEUmsNzMowqJluXmpkpyvpfVfmoEDcyhvupcTH");
    double vhmOa = -766075.3796701062;
    bool NEaoqxWVtaD = true;
    bool ClJDHHu = false;

    for (int UiIJbc = 1751656838; UiIJbc > 0; UiIJbc--) {
        YbKPkXQRkFP += ZucRWuQKfQsyln;
        ClJDHHu = ! NEaoqxWVtaD;
        NEaoqxWVtaD = ! ClJDHHu;
        rimSegXKYCv = rimSegXKYCv;
    }

    for (int Tznbeh = 1690117065; Tznbeh > 0; Tznbeh--) {
        rimSegXKYCv = ! rimSegXKYCv;
    }

    for (int lrKQWokgchmbk = 1834708332; lrKQWokgchmbk > 0; lrKQWokgchmbk--) {
        NEaoqxWVtaD = rimSegXKYCv;
    }

    return ZucRWuQKfQsyln;
}

void FKqcAt::gikKmpsQMk(bool jZbyLvTg)
{
    bool jNBRyP = false;
    bool LIglqjtlH = false;
    double sgzIyBJAhjMABEW = 966373.6209263562;
    int VAseQwk = -1633956323;
    double GTZoAeitm = -887450.7716184651;
    double dpumeLNayUJI = 546114.6959130842;
    double CaJyEUdDhLKjYaVD = -292281.808677545;
    string yqPrTtimTHwfBwE = string("KGpeIqmTtDtGIvE");
    int ctKduxrYPcMmSfn = 105799817;

    for (int FPYxP = 287703605; FPYxP > 0; FPYxP--) {
        VAseQwk -= VAseQwk;
    }

    for (int Ivskddm = 303103040; Ivskddm > 0; Ivskddm--) {
        CaJyEUdDhLKjYaVD = CaJyEUdDhLKjYaVD;
        jZbyLvTg = jNBRyP;
    }

    for (int YMlAjlX = 853250440; YMlAjlX > 0; YMlAjlX--) {
        continue;
    }
}

void FKqcAt::oCwMxZh()
{
    bool DoMPlHBO = false;
    double CbNkCO = -581949.5061613743;
    int SLzxbNR = -855013036;
    bool OiUaKvmOjXFumYun = true;

    for (int Fthuy = 1101280736; Fthuy > 0; Fthuy--) {
        SLzxbNR += SLzxbNR;
        DoMPlHBO = DoMPlHBO;
    }

    for (int tkuqHjevZ = 311513499; tkuqHjevZ > 0; tkuqHjevZ--) {
        SLzxbNR *= SLzxbNR;
        SLzxbNR *= SLzxbNR;
    }

    if (OiUaKvmOjXFumYun != true) {
        for (int pOTrXrlu = 921945341; pOTrXrlu > 0; pOTrXrlu--) {
            SLzxbNR = SLzxbNR;
        }
    }
}

int FKqcAt::ZwQTvgw(double LFDlaWCzzqtXR, int uNXufrF, bool izPmzRA, int cYSbFUwlOpwRWsab)
{
    bool enrZAwmMjc = false;
    bool ORbaazfg = true;
    string BZvAM = string("bWzRzElGKD");
    int HzCSajnZrZSJpcLy = -800377558;
    string wJypYkE = string("GUHocElDBTlwycQomgEjPRrpFTxvyWDnRzpHIDfxYFiWljJlZGAUlGnprxybEHEGrbYiIBAcqMXcUmgPAOQ");
    double HzEFTobWZDrUdn = 2993.712123057638;
    int CsegEjyMpRycEa = 148627464;

    for (int XSynHo = 443492946; XSynHo > 0; XSynHo--) {
        izPmzRA = ORbaazfg;
        CsegEjyMpRycEa -= HzCSajnZrZSJpcLy;
    }

    if (ORbaazfg != false) {
        for (int JFKMv = 897145757; JFKMv > 0; JFKMv--) {
            LFDlaWCzzqtXR -= LFDlaWCzzqtXR;
            cYSbFUwlOpwRWsab *= CsegEjyMpRycEa;
            izPmzRA = izPmzRA;
        }
    }

    return CsegEjyMpRycEa;
}

void FKqcAt::MbhYDyJflwIdFbn(string jugcUgoZcAbfzv, string pzBTbbqsgKHIhHm, double OdQrdB)
{
    double gXHADnX = -440951.63085632544;
    bool kPHkbDznNgfbVJy = false;
    double RcwKocKzzZauBY = 814496.2782604126;
    double qNBGiOknnfcCD = 562150.009073468;
    bool LWsTpI = false;
    bool VonSzpjmLwCzq = true;
    string fvkEdMEPPgjB = string("RmtqjdSkCMfztHo");
    string FidfzXI = string("yKLXKRsUplnwvBNLHoTeHTYqotdHsJEscgUBzDDOSxvVPPGFywXEMSyhohnaJJLlPmIoBnxYhKDvGHzhJYmYXCjsbHZBVGIbQkRbIBSMPwQQMiGbqcwQkSLbJcSC");
    bool CaTgZbNJERHnPMrr = true;

    if (kPHkbDznNgfbVJy != true) {
        for (int xzalFLV = 1357638474; xzalFLV > 0; xzalFLV--) {
            fvkEdMEPPgjB = FidfzXI;
            FidfzXI += pzBTbbqsgKHIhHm;
        }
    }

    for (int IGqfmeUomwYValyw = 488153909; IGqfmeUomwYValyw > 0; IGqfmeUomwYValyw--) {
        OdQrdB += qNBGiOknnfcCD;
    }

    for (int cApJHyoNCO = 1421223030; cApJHyoNCO > 0; cApJHyoNCO--) {
        OdQrdB *= OdQrdB;
        gXHADnX += gXHADnX;
        FidfzXI += pzBTbbqsgKHIhHm;
    }
}

double FKqcAt::gUntxkPFdIj(bool LGlufJrqz, string lByTiiqEg, int lJuUzY, string wVbsgLo)
{
    string HnIQCpFAhLCAOePv = string("bDiOakFOBfFlberAlQiOPgonGtHDEeRMantfQpQVmgdAJqSUZHAvUZOSsKhNVvNFdjhoSJIwFBKTDzrgrzUcixwFUHsvG");
    bool IlaXvc = true;
    bool Yifsrr = false;
    string uvLVUZBdM = string("nxaVgbTprzcdQPzPQzJYvtduwVLNelSLiJvjufEbocuTrzhxOqgoIFXRCNLLPqYhZBZmndYxzIEOIEcHWNDNUocUlKrDSbYbFuSAISTpggchZvwFHQCPvkTFGepSMmldvrainoLJqCuJXgwApOYfjQEysEiQHIkaBGvzzw");
    string TbXTRRw = string("rbTiAQISCoqPWPadhAmwKVADvlZRUtpwwjxkcjozqNoULnHkZrCDVwufGAxwyqNojskzgQYkDOPnEMXWoLIyrWKzzunPrDqswxVsmzLUNRSoyxUDaAOXbBpUVtoEBmgzgGVePwVZbAupZLFjFTYseHCAuixHsydbfOIrOuEjuBHNsjgUlwKRpaToUfbfmmlgAybIA");
    bool RGDQZfstodMdYu = true;
    string wRqyRUkWEOlBPJ = string("dXBTiwiknjvfkNICybzjdZTDNeQacAWmodLwTggHMUyALUgnsXNUNpuzSpePkgsLLhTmuDQPTjNZJxIzrpPILyZxdBEutfJMQjhlifFGuHsBgSmIgpxGpZxXgkWfhuerXWzANayacOuFasobLQivydPHDYUWzcwKHaVZSVFjwcXrDTLDsUnruGUIgd");

    for (int CNfERKpmkTCjuexf = 1816785069; CNfERKpmkTCjuexf > 0; CNfERKpmkTCjuexf--) {
        IlaXvc = ! Yifsrr;
        LGlufJrqz = Yifsrr;
    }

    return 710377.1397698697;
}

string FKqcAt::qZPpbwrHeBPFrHlX(bool WJFQHeBNWogJRu, double ZKPOEMeZDkmCZR, string yfUnhFnhCkyaJceB, string NycDoMkviHUbvf)
{
    int kfWjvNJAXadYNuQ = 1878735087;
    double GXYHU = -500281.7830314461;
    int sUNdbGAKNiKaBdU = -1775911033;
    double qOFPX = 3399.9063898603304;
    bool JvpcG = false;
    string Irmcm = string("mJoBZoDRyDNAnuhSFBAolVEnroTqFbMxFjDTxeZXDmQRSglnTJKXtcbrMqhOeVaQKygOPblbvjlbgZoijISSkyGlMRzHOBEkiSfRXGQkDTHVWkQeHyLkTRzIbCaWDfFvjWsiOPhwAPDgeYJBxVecAICyfbBTpDXRELgIwTjucVaQAMTIQGsWTlXseyHgWdYJIaZrLOcTOxgdjPPhDwDIphlspkxUxzPRjZWDRAccPOySntphMHmd");
    bool qLubBIKTlIZKrv = false;
    int oNUJXc = -1118699078;
    string mdAGfzZOhr = string("GtJknhokGwZsLihMrEunCjzXIlWGlJovDQThMQpbDUceaNy");

    return mdAGfzZOhr;
}

string FKqcAt::bgqTZrvaQgYI(string JKXlmkKL, bool QOQaWtoUnoHANG, string ipjsuJrUdRiUEY, string BnEkupARRjK, bool aGWzVNsvPN)
{
    int AlIKNyM = -43725341;
    double tXMqDUNCIsVpvx = 386006.5465083232;
    string elFIQTfXhuWUtF = string("GcLajmzchmpvcVxtyQBDtkChpsM");
    int JfGmidGvvq = -1240247678;
    double uNBVwyBEmgl = 974037.9685863816;
    int GwmEnTpSkKqblz = 920425145;
    int jFAltaw = -259975680;

    for (int JOWpDw = 1540025201; JOWpDw > 0; JOWpDw--) {
        elFIQTfXhuWUtF += BnEkupARRjK;
    }

    return elFIQTfXhuWUtF;
}

string FKqcAt::dJooSwXpdtuXe()
{
    string cbGtVEhit = string("bLFooKPcjxaIthenCiYdYDceoxdIWzszYOPZIanaOTLRrVeqyKXlhxpOQPnSAuDbwtnZUceOcGdVvKdwunhiiKAUhRjfFAayyWlRoIOqBDVkFBNjxzJuUMotKeNwAetnItdbJa");
    double xarQEpj = 167792.1495365997;
    double AzojbgokZfnNThX = -281377.1191767366;
    string UJQUVVfiHyBTH = string("BuMKPqhsDqGXgEVuDYvugfyHZluEZwcBeaUzNWJmVUjzouHthfqUUnMmUgCuKugvsFheTjTJXMYmTzaOWYFYKbYFYOWigYpuW");
    string LMslwMVhXqMGITx = string("mPxyRKdYquouDLigdogtpuXQlsRVthBczKKcXNGEDJtpnaJGmHyIuekKrWQzGvHawlRzLoAGEVOgxEmIYXhhWnsvvdKKEOyTXAzlbJogayDPEPtcfdlTIipGSrExQQnnohyoeEdRFqPMOVBbdYtOhhMDIdBZKtqFIsaruaSWZBM");

    for (int lpTeyJ = 93240967; lpTeyJ > 0; lpTeyJ--) {
        continue;
    }

    if (cbGtVEhit <= string("BuMKPqhsDqGXgEVuDYvugfyHZluEZwcBeaUzNWJmVUjzouHthfqUUnMmUgCuKugvsFheTjTJXMYmTzaOWYFYKbYFYOWigYpuW")) {
        for (int ZdeDW = 1414513752; ZdeDW > 0; ZdeDW--) {
            cbGtVEhit += LMslwMVhXqMGITx;
        }
    }

    if (UJQUVVfiHyBTH <= string("bLFooKPcjxaIthenCiYdYDceoxdIWzszYOPZIanaOTLRrVeqyKXlhxpOQPnSAuDbwtnZUceOcGdVvKdwunhiiKAUhRjfFAayyWlRoIOqBDVkFBNjxzJuUMotKeNwAetnItdbJa")) {
        for (int CKNTNNlecoeakG = 965845058; CKNTNNlecoeakG > 0; CKNTNNlecoeakG--) {
            xarQEpj = AzojbgokZfnNThX;
        }
    }

    if (AzojbgokZfnNThX <= -281377.1191767366) {
        for (int LSrEBKhvCJMDL = 1982353194; LSrEBKhvCJMDL > 0; LSrEBKhvCJMDL--) {
            AzojbgokZfnNThX *= AzojbgokZfnNThX;
            LMslwMVhXqMGITx += LMslwMVhXqMGITx;
            AzojbgokZfnNThX = AzojbgokZfnNThX;
            cbGtVEhit = LMslwMVhXqMGITx;
            LMslwMVhXqMGITx += UJQUVVfiHyBTH;
            cbGtVEhit += UJQUVVfiHyBTH;
            cbGtVEhit += LMslwMVhXqMGITx;
        }
    }

    return LMslwMVhXqMGITx;
}

void FKqcAt::rosKYZkfjpLoyvI(int gZGfNqIfv)
{
    int JbRrKfpObAR = 162584110;
    bool yhudKWrCk = true;
}

double FKqcAt::sSGRsQSwvSw(string aQgaMoq, int YBxarPV, bool alIsU, bool howrqdyBPZNxO, bool JuMaYxjbjky)
{
    string nGoeyl = string("zJLaVnaVSDuZJIbJw");
    int qQQHcLqjDQCTiyRu = 65983777;
    double WHKVYsOOwPhCVuFY = 655102.9398460045;

    for (int GAoFZeoTMEh = 390705748; GAoFZeoTMEh > 0; GAoFZeoTMEh--) {
        WHKVYsOOwPhCVuFY += WHKVYsOOwPhCVuFY;
        alIsU = howrqdyBPZNxO;
        JuMaYxjbjky = alIsU;
    }

    return WHKVYsOOwPhCVuFY;
}

double FKqcAt::RlOADJBWl(double vnOHgzPFzlavQ, string LPkLznEcYHX)
{
    int sFZDDeBKnNwXlY = -2042033770;
    double aZLEkbd = -535714.1778720457;
    double tTCebz = 223338.66594655009;
    double RAsZika = -699109.7660408637;
    string kLEuXqpJ = string("KHfprrPGaCfMkWZaGPzHdxESCbscVqfUOZOtQvaMUileeWxXHFQHgTpowqSGHqTIVprlEmNBSNzzseKLnLuBGwBhQkeFGRoEUMQJLUlksbpRPqNjnFVPjfAvOGaUiurPvHSTCDcokvWOObYfIIaPXqkTEnGUWsqqEGZmzNWdElPGnsBOzemdNVAOxcarJsPbJWJhsLCQtuyCDKiOpKfSBhNzQJkmUIzEPCwzgColPRsVzhk");
    double yuJJJzIsYdni = 47740.0248834652;
    bool IjQbjP = true;
    int kFClwbkGplToin = -98033402;

    for (int Yxocuzq = 2134990497; Yxocuzq > 0; Yxocuzq--) {
        vnOHgzPFzlavQ -= RAsZika;
    }

    for (int HwNWC = 2133468251; HwNWC > 0; HwNWC--) {
        tTCebz *= aZLEkbd;
        LPkLznEcYHX = kLEuXqpJ;
    }

    if (tTCebz <= -699109.7660408637) {
        for (int wXOKt = 1770764720; wXOKt > 0; wXOKt--) {
            sFZDDeBKnNwXlY += sFZDDeBKnNwXlY;
            aZLEkbd *= yuJJJzIsYdni;
            yuJJJzIsYdni += vnOHgzPFzlavQ;
            vnOHgzPFzlavQ /= vnOHgzPFzlavQ;
        }
    }

    return yuJJJzIsYdni;
}

string FKqcAt::dRtgcTMbHIITf(double DOywGc, string tqrHAFz)
{
    bool ScfdKvkQPHnYwHbY = false;
    int nrxRNoeoDXAKlr = 1153536173;
    double ulPWlghh = -304856.77210926777;
    int VIvPnySKyFQ = -2063420573;
    int ZLmBWsflNdo = 2084091731;

    if (ZLmBWsflNdo != 2084091731) {
        for (int QNkmPbesDo = 1159555410; QNkmPbesDo > 0; QNkmPbesDo--) {
            VIvPnySKyFQ /= VIvPnySKyFQ;
            ulPWlghh += DOywGc;
        }
    }

    return tqrHAFz;
}

bool FKqcAt::rzACmpmN(int gOKJlYzPFy)
{
    bool hvVPZpoainy = true;

    if (gOKJlYzPFy != -1481412746) {
        for (int LCJVI = 483429106; LCJVI > 0; LCJVI--) {
            gOKJlYzPFy -= gOKJlYzPFy;
            gOKJlYzPFy *= gOKJlYzPFy;
            hvVPZpoainy = hvVPZpoainy;
        }
    }

    for (int kamKwrIoSHKKzsc = 809169922; kamKwrIoSHKKzsc > 0; kamKwrIoSHKKzsc--) {
        gOKJlYzPFy = gOKJlYzPFy;
        gOKJlYzPFy += gOKJlYzPFy;
    }

    if (gOKJlYzPFy > -1481412746) {
        for (int RZFqOAz = 1584420543; RZFqOAz > 0; RZFqOAz--) {
            gOKJlYzPFy += gOKJlYzPFy;
        }
    }

    return hvVPZpoainy;
}

bool FKqcAt::haocLOtRrDBGT(int SqVVCStaCvqg, string yhTWJrSC, string EmVpPPuWKW)
{
    int jNNnpgBrvLLs = 551513673;
    int DlKlGgrbJiX = 1940397197;
    int aoFEqS = -1422518850;
    string uQqiV = string("SDakEDBpSrLmxtRitEDKUNbezrxaOmmPJKLJpvASepQUbZprsyvdVhxXEkKgfzctlPiopnVqoKVDZOAqhnK");
    bool AEyQIEbOHQQVwxAm = true;
    bool PQnYsPUKaN = true;

    return PQnYsPUKaN;
}

int FKqcAt::pRSdNQtWijIg(string BZDbAjRkpnafC)
{
    bool acstMJNrBSOZiPLw = false;
    bool YsfPzvyVCqH = false;
    string FyGXfXEvLD = string("hJuGlEiCuxhEnCHjVVUMWCRjcamiDlVFYWZawxkiEsDzFkWXsJPeyELqNcLxiwPwgSeXafFyqCFESIfcNskkLqJupaDtQcOQkyoKlbxhOJuyAOusAQCypQeDXbwzbSOcXvijAvavybkjiOfNWuxLLoDOpcYoovXWbAUpKFKaXMEg");
    double NVvXrvfGx = -996675.4118184202;

    if (acstMJNrBSOZiPLw == false) {
        for (int qPYZxru = 1341971592; qPYZxru > 0; qPYZxru--) {
            acstMJNrBSOZiPLw = YsfPzvyVCqH;
        }
    }

    return 126069568;
}

FKqcAt::FKqcAt()
{
    this->rUcNfTQpYLgZeslN(true, string("VAkVlXopNOboCdcCueSUGOfxJdJOdFqbzrzUYoZfcXiINJvaPLLTuyJFvuehgMAWKKhNrXEkAamRL"), false, false, 599755.4038596499);
    this->OPgEkgXwfryWLRz(489769589);
    this->gikKmpsQMk(false);
    this->oCwMxZh();
    this->ZwQTvgw(-1036713.5402379107, 149462034, true, -630627401);
    this->MbhYDyJflwIdFbn(string("QbBrmWcPaTUVZsymKfybZOXfWeGEhBEOaOsIaPbcNxrcDsucdNNEkflDqpUxoGKjYhEOjoISDeaWbDGZNNPtCOvhKQIQlMDBPMdTQnTcXZVRWxAycDCCL"), string("hnEOCBmZKLntPPtTTJIusqTKffyuvsebv"), 1028830.7490983073);
    this->gUntxkPFdIj(true, string("JgHMgPRpxSFlGtbezEevPIEsTWlRmcXOhWSKeFxPUjyYMjDZBGqkIdUlmgjsWGsvuYtzxGMaKmNGTywXlyCfVXwVroCPXzAstnMNnmKOutNuSbcrtMTMhCoRXldaMJrOzdbNcAlqxchKKFlRcfOojeiLGDfKyqtLUXalUSVyAkyACHqRgXwKn"), 1264787345, string("hKCZrvDVzETcsjyWcLZDJHFKrgXvbteIOLtbDRlxXLhzfEtKfpCoYpPFRFxXlsAjoWzzIvUKoFRMpXfBvEjuiyBWvhGRSMBajEjYzxbysIJJLhFtnMuSfwbdeNWHwKcjPDinwEcQyXkvjYUtELRhaVVjVZFsFeUuqGrYrZbXumYHtSCLiMjZkFWixj"));
    this->qZPpbwrHeBPFrHlX(false, -851673.0676063095, string("WevFYKmgMyIrpuenVcnxDcCBVcBIpJxYnQwsVvREyyMRjbTLgflFreLukzLWmofEJCSYqSvcEpqKBZTaNeXDswSRvtGRRBDqtFPOtkhrQUiKFhaOMTHVsXATiiOFqtgrJPjhNJZxZZBeSBYDmcEvSVSLncEhpnKeLNgWAiaDIUChIKIaNDpdlMLMtIJcdPbrZJsXJIgGPl"), string("lMZjqcBWdPDAYCPzWUxlWWnYHuGyVtzOpgHKwnwZAZmwChLIdKNmDLWZKyNatkYHETjUcyeYmGchZGojQWUOQSNmdKbDrCkYPGXBGxttpscTJTpWzDauDtzSKrjMjsJlOqWyZOLcXLy"));
    this->bgqTZrvaQgYI(string("VMTluPnImvQkgYrfkQZwnkasVoxPucXqDoFhfdBwguHXDDKTEJfTzbzMpNgPtwGcPhLSuPnQtvXyuGHPBfJKKWAKvkGrdpdMlpWOKSFEsqbWwyXBXNzoAGCvznJJWYlZMzIJvQbBsrKfEvDTrqlE"), false, string("SDHbQYXGFeZWOTqIrgTlZPiBMdGzzPTCHIkjlmwaDTNwcKKXoeAKjkBCgQWjlhYiHDFPQnOJAyEiybUdWWZrdnoxGWSAgYTgpiOYErmkelKeKeXleoerPIeqPReUfpwreaIRJtwJWoVXXGzojeyphKjxzyyYeONnLWrnhMhnSymkscQDaFGoOhzwJHipfNQMt"), string("CGmobBBLtpxdRWRNSoCJLpDNywequamxkYQjZsiXDjVboBlVrxyEhJHrcjgJwmnEkBGIgrURIgImCiGRxCKIwTnfRWzoNliSFpZgsDYgRAhlBFudsXCWGnnsHPatDMlFgJbPVnyvpgCzPdcjvRfpUwGGfvzkNeXLNGnFGuWqApqoGtpHoUPRwhBFYDtlRmZZTlJLEYYEDywHUuFWzFGeDJ"), true);
    this->dJooSwXpdtuXe();
    this->rosKYZkfjpLoyvI(-709037879);
    this->sSGRsQSwvSw(string("BWOJTJxrGCxdRetCFIfzgXHpYlPcSfzbMPHlfaBbLVBjtvUABrcyRsCeQUTVjPzjEYVNjMLTZkFkaCyTrduCeOWosWsqCYwbuGdceZLkpBHrhizfDGPdyXIJOTxZKpGjfpdSZbfCZIujDLRQeBVtKTFfXFkZxrPpLjDGNwznMw"), -2073444031, false, false, false);
    this->RlOADJBWl(969122.2601531171, string("JaIXvAIskSBtiAMjbzSmhoqvjBXPkwsvgvTJxAhtMXCKxhXnzJoYypgCPgUhKWaYOCVWojikRHOhwbOcdaUgjdGgbIreCyamUdacrciJrfmXHiBtDepphCfGbqicZAIuWHCYmCrbDSoHRRaJvcUdPgdPwhyxqhXaKNWEiGNdkDnIXohnxTpNeiapzolvbnUdcjxbPFZNxHJA"));
    this->dRtgcTMbHIITf(606199.0574540283, string("sNtvWVQjUIhZWxBuDPVsWDFzhwxiRKlqkIzsHRKSmORmgpGGUNuySdFQBzVETTMIZTYZtkyFaUnibQbwXFaoiMgjayVBNwSJERNDEDtIfBFIhFopHuqjsTvYqxaqOnKgdSFiGfEfxctTVudqNJfbOJHWqQEXOpiYOPhjuNlrDPqxnTxXGWtVzycJPcjJWdfhqFSwsJsRKschBEh"));
    this->rzACmpmN(-1481412746);
    this->haocLOtRrDBGT(195135944, string("aYxggHhlmCrXVUWcSlwdOiDSAObkQVoUIJYLGrlMfhNGUiRLACNLzwZihJfLVQREANsEIDwoSsTclhtlZglXUVxZvZCVslWhgZiZOlqkMKMatiCoMWnWCZCvXKYXfwXudEzLgoZoisDMfXUXsyrVdZ"), string("CZOVsgPcfxemuXrzmruhdTiqROdCBJxpKbdAVJHqwWLr"));
    this->pRSdNQtWijIg(string("mDeMVSjGpeZwUllNBjvptjWOlyfClDWDmZOLvkHQzaKvZIjhwWIdBParuKTItkgFfBxoGzAkFLGYecfSOspmMQXOoJMoTjoGSfjLZUYPqcXkHQbcppmtXlnrBGWgCyAYQAzYBmrVumLXrJZAgRnEuzTVPWekLrCFBWeQTUCPYPYCUQVHciMPGihYnbkaapWAadhmxBUBIOSjliNbAlSUjLtUhqtrnHgWpgoVpqzmeD"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ReFukBRafNFQZg
{
public:
    string qYNdddlJuNssOS;
    string ISksBE;
    int pPVetmHPdci;

    ReFukBRafNFQZg();
    string YzcHP(bool INngKcmhz);
protected:
    bool FtBKIQRfy;
    string qzVSsoOQhPYGUeql;
    double EeIbTnzjNtrE;
    double fKsSqyfgPBqY;

    double VbFnQ(int TmGUNajVxGGmsiQE);
    bool gWAeiWhze(bool XqhCH, string NGzDlSmndPuRXtv);
private:
    string MHzNL;
    double OLgHzEewkMOa;

    int wvWKDAC(int rIjlopajikER);
    string OaXRYjzjvldFhLGJ(int ujCcraPafNbZl, string BRCEMFHVNGgUpwo);
    int npuyxtq(bool fDpxfHRASHL, string ukQFxKUviyL, string uCpgBhetgcyzFem, double qLySCwqHeiPy, bool AMJspdefizBAYmha);
    double OGCvQkzAiNg(double GgNaaLIhXUcdIybG, int cWBxygZgSuyNUMB);
};

string ReFukBRafNFQZg::YzcHP(bool INngKcmhz)
{
    double FOQDCdzbOSjXOXOV = 122666.2983607343;
    int oymfjA = 399456179;
    bool PoCZIzjgHM = true;
    double iYPTAeeqXRO = 80951.24887934708;
    double GIDwKdAvaob = 946711.7111084681;

    return string("cAIrYYMxhZFTgHqyBkBmyHRctBUnIkRHjbBAkeVdQyBatuPMTkvVuMyrRqxSFgyJlwLTOUgSCWwWGacfEHnyqFnhjYgtXVFRjOcAAhuIWVUYIIqApnLkqWBxbJLhBmFVOdlvlqBmygAlLZVD");
}

double ReFukBRafNFQZg::VbFnQ(int TmGUNajVxGGmsiQE)
{
    bool zcFYkkyRbSRCSxZ = false;
    double gqVsuKTAPCXlwCak = -273978.17787221307;
    string ozFHpiBz = string("pOQfoWcfRPGyQGTKGVwUxXYbCuQEuwQBGjWVKrEOXqZjmBmceGAVLOlHaAYCLswPSQimxtHIKLrjxKklFzCNdomMaZZePjBOnXdLUaCSxFXixBVgGHSFxSNJHJwfRY");
    string HGVnjJrACGmH = string("JFcXtoIUJQNEfpGsJuhBqLpJtKaWAxsjxYAFogI");
    string uSBtc = string("wNORnEoJVXJRKKdwLVqUXCjGEkJxlixDlQtClCVVuTjdWGhVNFhoyLOZKFAMnbYxbwwTjMWZgSSwlgs");
    string EkQBEDnFKAvyMP = string("iEkvniprjCOaouzBJiiCyaUDsGCSVDCNaqkxSGUzguLLZhMxwoADUqUtNKCCWSGRhYPDhWQUvucnsubemaKdgyjSYpBxNQZZBCTXQIajxabgjbrkcKDBTaCEsjTidOWNTWsIQVXbzryRqQAdsyEslijMZiDqngYnDIypvRlQAsGtVoXeWfvQGiSlTrDXcTebVtRxGYGBJMkbKpFcrYQyuyVltsGrznumXrjhKJurxpFRrXmhznSyzOfvFAaRzL");

    for (int ykAubJgJ = 1682610625; ykAubJgJ > 0; ykAubJgJ--) {
        uSBtc += EkQBEDnFKAvyMP;
        zcFYkkyRbSRCSxZ = ! zcFYkkyRbSRCSxZ;
        HGVnjJrACGmH = HGVnjJrACGmH;
        ozFHpiBz += ozFHpiBz;
        uSBtc += ozFHpiBz;
        uSBtc = ozFHpiBz;
        ozFHpiBz = EkQBEDnFKAvyMP;
    }

    for (int aeAGFBXuJSDrU = 1197056711; aeAGFBXuJSDrU > 0; aeAGFBXuJSDrU--) {
        HGVnjJrACGmH = uSBtc;
        EkQBEDnFKAvyMP = HGVnjJrACGmH;
    }

    if (zcFYkkyRbSRCSxZ == false) {
        for (int rFIbEBNPXujKoGv = 1158639888; rFIbEBNPXujKoGv > 0; rFIbEBNPXujKoGv--) {
            continue;
        }
    }

    return gqVsuKTAPCXlwCak;
}

bool ReFukBRafNFQZg::gWAeiWhze(bool XqhCH, string NGzDlSmndPuRXtv)
{
    bool wMvGBBMIkFsI = false;
    string Ocjrvfz = string("VXEABaaiiMlFNZYOtFjQxXIwbMYtXAQKlcp");
    int ZTjyxWiTpi = -1966286589;
    string xeNqIc = string("CSjlzgXrTfkyZaxSyvOeQAwNRpkzYxbPRxaBxgxQgTbwrsjmPSouBlTdwMJdQGavdplSNwTiuDjcXItCagzugHLTNeZMTPgqSYhneBPIIfeNqeZSpXigfZdEwfqXCDrbVFnMtZJpDbLmzZlZJqruGjNzVUqXzqtguLCPegcawowMeOrlpnbkJohpbXSURDwkCBCrKqOIqoWMKoUxPYNwsGuETpfIxXMrMrirUOqVwLvLKmEGrQsQq");

    for (int QwmZQaqb = 1509925507; QwmZQaqb > 0; QwmZQaqb--) {
        ZTjyxWiTpi += ZTjyxWiTpi;
        xeNqIc += xeNqIc;
    }

    for (int LZvnxywDNMbCSu = 2043370310; LZvnxywDNMbCSu > 0; LZvnxywDNMbCSu--) {
        continue;
    }

    if (NGzDlSmndPuRXtv < string("VXEABaaiiMlFNZYOtFjQxXIwbMYtXAQKlcp")) {
        for (int xlkNvfj = 1704964267; xlkNvfj > 0; xlkNvfj--) {
            XqhCH = ! XqhCH;
        }
    }

    return wMvGBBMIkFsI;
}

int ReFukBRafNFQZg::wvWKDAC(int rIjlopajikER)
{
    bool lVVzrM = false;

    for (int tYEcLal = 1971262642; tYEcLal > 0; tYEcLal--) {
        rIjlopajikER += rIjlopajikER;
        rIjlopajikER -= rIjlopajikER;
    }

    for (int jcFfRVLKPfy = 572334535; jcFfRVLKPfy > 0; jcFfRVLKPfy--) {
        lVVzrM = lVVzrM;
        rIjlopajikER -= rIjlopajikER;
    }

    if (rIjlopajikER <= -995155381) {
        for (int axTstBmJN = 1906177414; axTstBmJN > 0; axTstBmJN--) {
            lVVzrM = ! lVVzrM;
            rIjlopajikER += rIjlopajikER;
            lVVzrM = lVVzrM;
        }
    }

    if (rIjlopajikER <= -995155381) {
        for (int wJsBAELkZi = 1719288424; wJsBAELkZi > 0; wJsBAELkZi--) {
            lVVzrM = lVVzrM;
        }
    }

    return rIjlopajikER;
}

string ReFukBRafNFQZg::OaXRYjzjvldFhLGJ(int ujCcraPafNbZl, string BRCEMFHVNGgUpwo)
{
    bool AfClYGIRSKXzD = false;
    double wDkePsbkKui = -379891.20985842205;
    double IbhWnon = 789327.4929415303;
    int AkzMICUHsXKpXi = 829945041;

    for (int FDtoShjsnOrCfYY = 1342044056; FDtoShjsnOrCfYY > 0; FDtoShjsnOrCfYY--) {
        IbhWnon += wDkePsbkKui;
        AfClYGIRSKXzD = ! AfClYGIRSKXzD;
        IbhWnon /= IbhWnon;
    }

    for (int EUISdnuRJKbkk = 1248477474; EUISdnuRJKbkk > 0; EUISdnuRJKbkk--) {
        ujCcraPafNbZl -= ujCcraPafNbZl;
        IbhWnon /= wDkePsbkKui;
    }

    for (int jbdIqVHAiaxExkd = 214141703; jbdIqVHAiaxExkd > 0; jbdIqVHAiaxExkd--) {
        wDkePsbkKui *= wDkePsbkKui;
    }

    if (AkzMICUHsXKpXi < 1353581026) {
        for (int tKNRmLBmSWdDFRvr = 1474752475; tKNRmLBmSWdDFRvr > 0; tKNRmLBmSWdDFRvr--) {
            ujCcraPafNbZl -= ujCcraPafNbZl;
            ujCcraPafNbZl /= ujCcraPafNbZl;
            wDkePsbkKui = IbhWnon;
            IbhWnon *= wDkePsbkKui;
        }
    }

    for (int YmzoAsf = 346503388; YmzoAsf > 0; YmzoAsf--) {
        wDkePsbkKui *= wDkePsbkKui;
        wDkePsbkKui = IbhWnon;
    }

    if (BRCEMFHVNGgUpwo >= string("EaYqdNpeCtkMGhJIMCmpotwquaFakhXNcWgdOmweaNBbmxjEuyMFcUARQXzvywJPZyKAeWkTuyHQYDfSolYrrGBaysIGdPDyQRLzsOGwtnFDRJKedBrbzmVYbMINNRbMIeou")) {
        for (int ilsUzibl = 81108324; ilsUzibl > 0; ilsUzibl--) {
            AfClYGIRSKXzD = ! AfClYGIRSKXzD;
        }
    }

    for (int VMfwroT = 216891535; VMfwroT > 0; VMfwroT--) {
        IbhWnon = wDkePsbkKui;
        wDkePsbkKui += wDkePsbkKui;
        wDkePsbkKui /= IbhWnon;
        AkzMICUHsXKpXi /= ujCcraPafNbZl;
    }

    return BRCEMFHVNGgUpwo;
}

int ReFukBRafNFQZg::npuyxtq(bool fDpxfHRASHL, string ukQFxKUviyL, string uCpgBhetgcyzFem, double qLySCwqHeiPy, bool AMJspdefizBAYmha)
{
    string QHHtP = string("RlMKekpBWGbCShQwUuwTSJoNobKidDIlXZlWxbVNTRRQdVJEpEmeVSOaddbbuLQBWAEJnYGKbncPehgtIJfVKGS");
    int sHHpDaF = -1872457522;
    double diGCcJjotedNJBEr = 948215.0523829537;
    string JMsUrMaNVCc = string("eEwsHbhngoyvsSZEMfoPTsqnESdTSbPHhoPmWmNdEKQIIictSnDOQcLyWtnnnuryCEwTWCCtmKvcTsTTLGGsRIhhYvIugEpWmQPNczKBJTkmsoXXKLoGZZUuELjdDUpoJNktkxfzzroCvkQdhpzAgTkibSrzRIbNnsgHteMBJWHsuTVbpcEoXDjzjCntvdTPxtqAfcTZOiZoPshDYgQcXNnAIDiZKEMnyjF");

    for (int WOQJWcj = 630776594; WOQJWcj > 0; WOQJWcj--) {
        AMJspdefizBAYmha = ! fDpxfHRASHL;
    }

    if (JMsUrMaNVCc > string("BkpbCsOnzQaHgkhYQLkMABnJsZWRSnEXdZrrcEcYgtAoIMlUJymnOTjtFIyWtzedNdOUrBRflxTNEcaznnJ")) {
        for (int qlNgv = 925232516; qlNgv > 0; qlNgv--) {
            ukQFxKUviyL += JMsUrMaNVCc;
            JMsUrMaNVCc += uCpgBhetgcyzFem;
            ukQFxKUviyL += JMsUrMaNVCc;
        }
    }

    return sHHpDaF;
}

double ReFukBRafNFQZg::OGCvQkzAiNg(double GgNaaLIhXUcdIybG, int cWBxygZgSuyNUMB)
{
    bool UzLLZ = true;
    int NmrOhzjpdcVz = -1335680233;
    string KBvCNQsib = string("JwLFEybhqmNJcIQPBzoFmBGPEgQVRkxczemTXCyMuBusHUXKfpBlXZlTLKGjVkBBRajtDHMhxAnIczUVUFzHVbTThujcNHfcMusJXdpILpCvfhDwTmlppOdjsqiieJbMSFhsQTQidoinxGYSKWsOfxNtuLVFJoMGacbeJnUpqgFJoUDHYmGAvEjqEDNBeGrcVkWAVRLTgoODVLvCyOQeFvlLkhXdRZpOlvTodNyMZaLGvRBztqrBaqt");
    string olkwbtFvIhx = string("CkIAWSGDeOSTMDYqAkVvyVsghSShjlDkaDFjOxcJVcSVrIaqJMYpuBOsGTfilveZluhkMawUqVoQTOTUZFPBQrVYakgaSsYxuSSlAWobIjiQomcoJdBFYMZtHZgEPQTwQqHnszXdIAvZxyrAsDXaWjeyrXfIAuCrxAyGavXEodbTeINCztNscOLKuzjzKbMJEOlufNLWNLlpatWlolNjebB");
    int aQDFfAHOmwHHa = -2014864937;
    int tYJeyyRq = -1674310220;
    double HFMDWIIGNXtYBWRc = 240784.82722453572;

    for (int BzFRxfjiyL = 720199524; BzFRxfjiyL > 0; BzFRxfjiyL--) {
        tYJeyyRq *= cWBxygZgSuyNUMB;
    }

    for (int nsrQYtTe = 208883103; nsrQYtTe > 0; nsrQYtTe--) {
        NmrOhzjpdcVz = NmrOhzjpdcVz;
        aQDFfAHOmwHHa /= NmrOhzjpdcVz;
    }

    return HFMDWIIGNXtYBWRc;
}

ReFukBRafNFQZg::ReFukBRafNFQZg()
{
    this->YzcHP(true);
    this->VbFnQ(495903510);
    this->gWAeiWhze(false, string("iMTLFsLIIrFtKdMVjhOXehvXCBTqQKeojbmKbYiLgjNAFbdHnIhixPtuMHdNcINFDTrQpSMQVSPUKKhUjZdbuIgGWEjMUkSkFeNALMxSyEvwNTBOVxvcgicgCZet"));
    this->wvWKDAC(-995155381);
    this->OaXRYjzjvldFhLGJ(1353581026, string("EaYqdNpeCtkMGhJIMCmpotwquaFakhXNcWgdOmweaNBbmxjEuyMFcUARQXzvywJPZyKAeWkTuyHQYDfSolYrrGBaysIGdPDyQRLzsOGwtnFDRJKedBrbzmVYbMINNRbMIeou"));
    this->npuyxtq(false, string("pDCQNnZJnntoFwmashmGaLamvoXKooTVsgbdxjiXXSFLgGLcXzdqCCFaYdtAhzUOxOCdz"), string("BkpbCsOnzQaHgkhYQLkMABnJsZWRSnEXdZrrcEcYgtAoIMlUJymnOTjtFIyWtzedNdOUrBRflxTNEcaznnJ"), -817038.7445626472, true);
    this->OGCvQkzAiNg(-399550.73298179964, -1238852362);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QyiHvrnrrTipd
{
public:
    string qgokRKJzaDRs;
    double AKtVQABjlrfz;
    double bqEYUbVDHz;

    QyiHvrnrrTipd();
    string IYwMG(int srauBzbLkgX, double TbySkJhT, string QpTXeEDlOge, int fCZRyRDn, int mqDHrLzKYD);
    bool kiRVIlxRWdf(bool tSPWv, int IGFYC, double QiqGoOcCNd, int HYMlVYb);
    void jiVbIcOfVnwi(bool QnBqEwJTxMRng, string VFvXEfJbgvXhx, int WqXvcnbzdUrNTodR);
    double rthQYPkPtrICkpi(int Joiogua, bool CCSkxcdlmFcGd);
    string UfYJNflCBQ(double cnoxzu, double MTDLEcktlAkCDJXh, double jHuRFOkuSD, double kQqfxOgaprJpj);
    int ziaPuy(int AYsbJAwugLvfk, int WNVQDQqBno, string kBhdjYFHSeLE);
protected:
    double qifuOqKdX;
    string xuRbWohzwVZ;
    int UvrPwI;

    bool JNRnsDRrAUQLD(string zbpeoLBbOW, int IuLzWZznuQfjkze, double vAaOgnpQ);
    double FltqrQFeiCqGQdaz(bool VPjHYxWADDsAeFY, double WVOrgDa, string yOezA, string tdyoYPuSmZe, int TpiFfTI);
    double flGHOeiXrDCSR(bool IzTiFsNvzmLZeomb, bool IJGvZObAhWYonU, double lugJGoVWpy, double JaYPUnpXl);
    void IOmHsoPlBnBLAN(bool YJingaZkrrWxBD, string ZNEWpMUvHLyMW);
private:
    string RfeCZCGfkbe;
    string apSTWJV;

    double vXlgCKdoProU(string CIkVT);
    double vBSBRxaVwWtQp();
};

string QyiHvrnrrTipd::IYwMG(int srauBzbLkgX, double TbySkJhT, string QpTXeEDlOge, int fCZRyRDn, int mqDHrLzKYD)
{
    double YYORDiRvQZIZaQcc = -916743.6104093969;
    double XnvkLkQzmNzfOW = 884000.2166080192;
    string WFooKQkf = string("HcVHzMdKRWQJqMplfTZFnFqAjwQaQFfWqgeFamRQeBptCXyzpsLzItkEWDwrOTYtMDbDYAQHEajttRKKPGqfMWsnyVFpNXtREmrSsLtANoSq");
    int LialjEINknvAzIiR = -60412465;
    bool bRIwLkvv = true;
    string lpoIqDBMCk = string("QChGChcXTWFXlZMOxdpyLyaWTCiEKdUQakCvPkuzzeIhOpdMPYeekJEYdYEZENzQiEFHkkPPyInHersigZRCQboXnQPMDpSsiDAGAewludVJajEgXDUnnTOdHsZBdzANBTtMEpyDqPQuzRTYNIoYTtauhrlEOkexfXfHfqjxjQUhTBSEdAjaUIQkLPNSGxsDXaKEYzlxVUogtlrqTSSiWIAdNLPumffXLxIsGZX");

    if (WFooKQkf == string("HcVHzMdKRWQJqMplfTZFnFqAjwQaQFfWqgeFamRQeBptCXyzpsLzItkEWDwrOTYtMDbDYAQHEajttRKKPGqfMWsnyVFpNXtREmrSsLtANoSq")) {
        for (int uOBjmtHcIYpSNoWQ = 588015947; uOBjmtHcIYpSNoWQ > 0; uOBjmtHcIYpSNoWQ--) {
            TbySkJhT /= TbySkJhT;
        }
    }

    return lpoIqDBMCk;
}

bool QyiHvrnrrTipd::kiRVIlxRWdf(bool tSPWv, int IGFYC, double QiqGoOcCNd, int HYMlVYb)
{
    double sshMPhwmnzQbF = -343845.6068584502;

    return tSPWv;
}

void QyiHvrnrrTipd::jiVbIcOfVnwi(bool QnBqEwJTxMRng, string VFvXEfJbgvXhx, int WqXvcnbzdUrNTodR)
{
    bool WbaZLmvetGRoJsZ = true;
    int MeSaIxlYmxxi = 1675346706;
    double nGVjIGfJyW = -862276.2661615062;
    string fuCyVeUGY = string("oxEhHyNDahjafbziIEMaSFSfFcHVaJeBguDVdEhkJovHmvLaldlOFPikTHOfuaoiKjZwdYKOFwHuBfKkePFMJXKoNeMhWqaKtWwdzpttrFNOgaCXphjOpvzZEKcqXfdkXczmBvUyvudMKevnVOqcQKHOuMcwzFXlQVDxzivDPDZHw");
    bool WRklWAXsjqkJ = true;
    string ExWxpBHoVqmrJf = string("ZSjnemfuPFmWxCKuoFsLrwJpcgtTiwAohtiulqYAjRbiquWwPERatSnsnzCcdiiaZESl");
    string SNpoleLupk = string("HumfLKsdwUuswNyMkFHbDGRVxGpKNbiSWpDhtZZAnzcxsjzBlqfverRWTzNKrLPvSLDowGZETrpdEnhzXPqVaPmjVOTXspklTCbPMUprVbzotAKnHLoBhCWcfadIKSwJvyHAdeRvpiXmjpvdEMcbNNGxBoxnqWjnSMFLquXVKCHlTBLUkMMdcJsyXldxjkuUvCPtqhWlRf");
    double FhyUvMo = -573579.226522322;
    bool UxVKhheUPPg = false;

    for (int gikaZyP = 2088751182; gikaZyP > 0; gikaZyP--) {
        MeSaIxlYmxxi += MeSaIxlYmxxi;
        ExWxpBHoVqmrJf = ExWxpBHoVqmrJf;
        QnBqEwJTxMRng = ! WbaZLmvetGRoJsZ;
        UxVKhheUPPg = UxVKhheUPPg;
    }

    for (int zfGXwIHUJE = 1432321703; zfGXwIHUJE > 0; zfGXwIHUJE--) {
        continue;
    }

    for (int xgOIpReKxnndVNdM = 21708648; xgOIpReKxnndVNdM > 0; xgOIpReKxnndVNdM--) {
        SNpoleLupk = SNpoleLupk;
    }

    if (ExWxpBHoVqmrJf >= string("HumfLKsdwUuswNyMkFHbDGRVxGpKNbiSWpDhtZZAnzcxsjzBlqfverRWTzNKrLPvSLDowGZETrpdEnhzXPqVaPmjVOTXspklTCbPMUprVbzotAKnHLoBhCWcfadIKSwJvyHAdeRvpiXmjpvdEMcbNNGxBoxnqWjnSMFLquXVKCHlTBLUkMMdcJsyXldxjkuUvCPtqhWlRf")) {
        for (int ytOHJFrwGmJcXqlP = 1038034074; ytOHJFrwGmJcXqlP > 0; ytOHJFrwGmJcXqlP--) {
            continue;
        }
    }
}

double QyiHvrnrrTipd::rthQYPkPtrICkpi(int Joiogua, bool CCSkxcdlmFcGd)
{
    string FBXlEhCjnpTnaN = string("veCiXjCOTckazqTSAGriQVseGnziSaYRMDgLAyEjaKKnvOTlebmlmQQoqpnTNDyWRCJxmAxxotDLMQrNgqugjknsrLEpMlATsyveCCFQypUMptrUhikzsSJfYjVjjjSuIHLovQNyhDpYFrUdTWPxaiBtELCrgJYNvokvsQWnZfUGnrKWH");
    double bGagmUESvGoV = 392713.0412742135;
    int YHhcAaSXHZFUYZGD = 1724833799;
    int IrKfxmNPLEfpT = -4432123;

    for (int WkxylCNMPomFJZ = 314994400; WkxylCNMPomFJZ > 0; WkxylCNMPomFJZ--) {
        Joiogua *= YHhcAaSXHZFUYZGD;
    }

    if (FBXlEhCjnpTnaN > string("veCiXjCOTckazqTSAGriQVseGnziSaYRMDgLAyEjaKKnvOTlebmlmQQoqpnTNDyWRCJxmAxxotDLMQrNgqugjknsrLEpMlATsyveCCFQypUMptrUhikzsSJfYjVjjjSuIHLovQNyhDpYFrUdTWPxaiBtELCrgJYNvokvsQWnZfUGnrKWH")) {
        for (int DBQodH = 1574331436; DBQodH > 0; DBQodH--) {
            bGagmUESvGoV *= bGagmUESvGoV;
            bGagmUESvGoV /= bGagmUESvGoV;
        }
    }

    for (int DLsOrSkbpy = 395661574; DLsOrSkbpy > 0; DLsOrSkbpy--) {
        YHhcAaSXHZFUYZGD += YHhcAaSXHZFUYZGD;
    }

    for (int YvoQBi = 1683245033; YvoQBi > 0; YvoQBi--) {
        Joiogua += YHhcAaSXHZFUYZGD;
        YHhcAaSXHZFUYZGD = Joiogua;
    }

    if (IrKfxmNPLEfpT <= -4432123) {
        for (int lFgtbGRGsaS = 488826246; lFgtbGRGsaS > 0; lFgtbGRGsaS--) {
            Joiogua *= YHhcAaSXHZFUYZGD;
            IrKfxmNPLEfpT -= IrKfxmNPLEfpT;
            IrKfxmNPLEfpT = IrKfxmNPLEfpT;
        }
    }

    return bGagmUESvGoV;
}

string QyiHvrnrrTipd::UfYJNflCBQ(double cnoxzu, double MTDLEcktlAkCDJXh, double jHuRFOkuSD, double kQqfxOgaprJpj)
{
    bool uxgoU = true;
    bool buZjPqL = false;
    double mvhvnnCdRIJ = 22940.511097757768;

    if (kQqfxOgaprJpj < -770434.5203836177) {
        for (int vhvcpmOpc = 803733086; vhvcpmOpc > 0; vhvcpmOpc--) {
            uxgoU = uxgoU;
            cnoxzu += jHuRFOkuSD;
            kQqfxOgaprJpj -= mvhvnnCdRIJ;
            kQqfxOgaprJpj -= jHuRFOkuSD;
        }
    }

    return string("MQPNqPTpTAZeVnUzrDFrRHdYukYWPHIXceGSeYyOPVHVSjTrLVWkIPbchqCFWSVwpCodWnvvtEYTVIwMtbkpzvLABhpVdAxMacQMdbxZNrTkjuznFIHnUEhzkuivvNtklptllQuwqNNgYVUslvrJeWuavEoQhuOBCkLNLUf");
}

int QyiHvrnrrTipd::ziaPuy(int AYsbJAwugLvfk, int WNVQDQqBno, string kBhdjYFHSeLE)
{
    int zuCDJhbQtj = 982672123;
    bool MeuZxfeIdooXogly = true;

    if (kBhdjYFHSeLE > string("HmIpmZGtVedvEJaKgLNRbMsftkJPhjlpUxbjJhLVaZnhkgKYsWkfrzRRdztoQrCTyTataJVIUXssSkXYAgmsUmbXGcWDvmliGvnCeouNltDfjeCxmWjbFzItljVsQAWbylFGsUjOVvotszBPfMWELAldbuNWUYJHXFMuedBSHlVmTzi")) {
        for (int YheagqqR = 1736802736; YheagqqR > 0; YheagqqR--) {
            AYsbJAwugLvfk /= zuCDJhbQtj;
            WNVQDQqBno = WNVQDQqBno;
            zuCDJhbQtj *= WNVQDQqBno;
            WNVQDQqBno += zuCDJhbQtj;
        }
    }

    if (zuCDJhbQtj == -2035735353) {
        for (int LkPjHEraD = 2133884789; LkPjHEraD > 0; LkPjHEraD--) {
            continue;
        }
    }

    for (int HWAEGOEQn = 1881602334; HWAEGOEQn > 0; HWAEGOEQn--) {
        zuCDJhbQtj *= WNVQDQqBno;
        zuCDJhbQtj = AYsbJAwugLvfk;
        AYsbJAwugLvfk = zuCDJhbQtj;
        zuCDJhbQtj *= zuCDJhbQtj;
    }

    if (kBhdjYFHSeLE > string("HmIpmZGtVedvEJaKgLNRbMsftkJPhjlpUxbjJhLVaZnhkgKYsWkfrzRRdztoQrCTyTataJVIUXssSkXYAgmsUmbXGcWDvmliGvnCeouNltDfjeCxmWjbFzItljVsQAWbylFGsUjOVvotszBPfMWELAldbuNWUYJHXFMuedBSHlVmTzi")) {
        for (int mPkjEehMQO = 1813627001; mPkjEehMQO > 0; mPkjEehMQO--) {
            WNVQDQqBno = WNVQDQqBno;
            kBhdjYFHSeLE = kBhdjYFHSeLE;
            AYsbJAwugLvfk *= WNVQDQqBno;
        }
    }

    if (AYsbJAwugLvfk == 982672123) {
        for (int XYovqEKMgKWQlKs = 532654432; XYovqEKMgKWQlKs > 0; XYovqEKMgKWQlKs--) {
            zuCDJhbQtj += WNVQDQqBno;
            zuCDJhbQtj *= WNVQDQqBno;
            zuCDJhbQtj /= AYsbJAwugLvfk;
            WNVQDQqBno = zuCDJhbQtj;
        }
    }

    return zuCDJhbQtj;
}

bool QyiHvrnrrTipd::JNRnsDRrAUQLD(string zbpeoLBbOW, int IuLzWZznuQfjkze, double vAaOgnpQ)
{
    int lpyyQkrSmreW = 1495704006;
    string nrTjfsMOuOokSh = string("MPhCrJQpkAOcmiMuoClucdTDDezZqFxUNcUKdlYbwYbftGJaTpqBcKoHpzUSzZcDJpAzexTYFptswGjZmogwqogvNyaAWdoouwjcTQsPZyeUdaPDVQWICoyVyXdqGntpcVXLmOIOwCdZfiAQehteCQVWMiSVivWhFtIQVKxfWTiFVHnTEBijdjMtkvBqCGrGWwqxtJFUHMWeGjwnDUqqnkOzBOyqWYtgXQUnhwBFkCndwepa");
    string TiOXlIRyRLNpk = string("ZPymKMsYbnIyllJUTOJbBVhHHbQBMPsKbsjhncOBHyjYlvcWiohbrnbOopeHzQKYxQZQJzSzmkZEjOmCoUrXVqnKdHmRqZocjaxVWhcBnbifUfMoUuQWoxh");
    int YERsQIQMzkbnWE = 239627628;
    bool RDNZbQvGA = true;
    string okeKPXz = string("SxvgWEvhVUGRAxniPBohzEobXfwgYOUKvlnQxDjToLABzrFnjobfAEFPKZsxULsLFzHuPCvHGBdtVKbHWHoCaJAxKludQnTVjqNhNxQRZnZpvgtBjSIeTgLkmWuVjeIefJWRBYkoEmPzLFGevVHWuXqtbCHReICLOdSdGLZybRfCtHHyOfauDryPcufdXeNOUsVdwIAKwCfzXQokBIrNwXDbnbQeMrtSFfIfZdjiWrqKn");
    string qVjQLh = string("kKUgHmEeIqpXJxrdxZJXDnWNirISRbJPqfVTHVaovGRDPCuABRSzgBGlYzhcqtTRYwcxjOWqdrwEoZULVBxmknnqMZQalAMbPWSEZVYbsGrsnvCcvspWolXgSfKJlkqQbcdbkjFsPqUBDlNivGdlHlM");
    double trytcSzP = 587403.7933911935;

    if (TiOXlIRyRLNpk == string("ZPymKMsYbnIyllJUTOJbBVhHHbQBMPsKbsjhncOBHyjYlvcWiohbrnbOopeHzQKYxQZQJzSzmkZEjOmCoUrXVqnKdHmRqZocjaxVWhcBnbifUfMoUuQWoxh")) {
        for (int sfIKBrjC = 167435547; sfIKBrjC > 0; sfIKBrjC--) {
            zbpeoLBbOW += nrTjfsMOuOokSh;
            zbpeoLBbOW = qVjQLh;
        }
    }

    for (int WelCfieskpA = 28636307; WelCfieskpA > 0; WelCfieskpA--) {
        zbpeoLBbOW = nrTjfsMOuOokSh;
        qVjQLh = okeKPXz;
        qVjQLh += qVjQLh;
    }

    if (lpyyQkrSmreW < -1905612255) {
        for (int MucMOYFC = 528232707; MucMOYFC > 0; MucMOYFC--) {
            qVjQLh += zbpeoLBbOW;
        }
    }

    for (int QNnqrduEIDL = 2008576181; QNnqrduEIDL > 0; QNnqrduEIDL--) {
        RDNZbQvGA = ! RDNZbQvGA;
    }

    for (int UvETLJzVfiy = 1844982511; UvETLJzVfiy > 0; UvETLJzVfiy--) {
        zbpeoLBbOW += zbpeoLBbOW;
        qVjQLh += zbpeoLBbOW;
    }

    if (YERsQIQMzkbnWE == 1495704006) {
        for (int GrMkbkK = 1538511178; GrMkbkK > 0; GrMkbkK--) {
            okeKPXz = qVjQLh;
            vAaOgnpQ -= trytcSzP;
            okeKPXz = zbpeoLBbOW;
            zbpeoLBbOW = TiOXlIRyRLNpk;
        }
    }

    return RDNZbQvGA;
}

double QyiHvrnrrTipd::FltqrQFeiCqGQdaz(bool VPjHYxWADDsAeFY, double WVOrgDa, string yOezA, string tdyoYPuSmZe, int TpiFfTI)
{
    int wmdzhNqM = 795007756;
    string dNbMQkamgPeR = string("dzCzOIbBpBGXWRpReUjYBnrATewEg");
    bool wJyrfHMUalVvzJ = false;
    bool aaeAbIW = false;
    double zPJIBehsS = -132754.9451825167;

    for (int ehRApPFekrYZMKbH = 1558705369; ehRApPFekrYZMKbH > 0; ehRApPFekrYZMKbH--) {
        wmdzhNqM /= wmdzhNqM;
        aaeAbIW = ! VPjHYxWADDsAeFY;
    }

    for (int CqVJQKVZVWy = 1733862640; CqVJQKVZVWy > 0; CqVJQKVZVWy--) {
        continue;
    }

    for (int nXvVqehqUzFSJF = 147124112; nXvVqehqUzFSJF > 0; nXvVqehqUzFSJF--) {
        continue;
    }

    for (int pVHtlkOW = 469382201; pVHtlkOW > 0; pVHtlkOW--) {
        aaeAbIW = aaeAbIW;
        WVOrgDa -= zPJIBehsS;
        tdyoYPuSmZe += yOezA;
    }

    return zPJIBehsS;
}

double QyiHvrnrrTipd::flGHOeiXrDCSR(bool IzTiFsNvzmLZeomb, bool IJGvZObAhWYonU, double lugJGoVWpy, double JaYPUnpXl)
{
    double EwPgfeBdBnqPzsW = -955187.4166145329;
    int FFjvv = 1674890082;
    bool iUifJplEXsDdizCT = false;
    bool QEGJZgzx = false;
    double gWsYIA = -606390.4897438769;
    double hiQnG = 574482.497591985;
    int TAyffLqZJJDIzZdx = 909179195;
    bool HUqfyKxTVZ = true;

    for (int bkBYxzcyINr = 961882362; bkBYxzcyINr > 0; bkBYxzcyINr--) {
        gWsYIA /= gWsYIA;
        gWsYIA /= lugJGoVWpy;
    }

    if (EwPgfeBdBnqPzsW != -606390.4897438769) {
        for (int gDDpu = 526477706; gDDpu > 0; gDDpu--) {
            IzTiFsNvzmLZeomb = ! iUifJplEXsDdizCT;
            JaYPUnpXl += lugJGoVWpy;
            EwPgfeBdBnqPzsW *= JaYPUnpXl;
        }
    }

    return hiQnG;
}

void QyiHvrnrrTipd::IOmHsoPlBnBLAN(bool YJingaZkrrWxBD, string ZNEWpMUvHLyMW)
{
    double ZidHzFIdtUCLpGKz = 248468.9397548805;
    int MQvRX = 1392899849;
    double IVwddhOuELZUPKwv = 738656.1736595164;
    string qPuhSnKhztKbv = string("bqPISNrEhnDvXgFS");
    int UfZFsjWohDbDFfx = -864821076;
    int LUtEakD = 1153187738;
    int BwCvv = 1392732097;
    int skfJBuWqrNYE = -503753672;
    double fXQeoVKrMvHiKTU = -308822.4698619153;
    bool AuqjHpHWCortO = true;

    for (int VaJmOVY = 1628949964; VaJmOVY > 0; VaJmOVY--) {
        IVwddhOuELZUPKwv *= ZidHzFIdtUCLpGKz;
        UfZFsjWohDbDFfx += MQvRX;
    }

    for (int dXeiORqKlZXoU = 2108483900; dXeiORqKlZXoU > 0; dXeiORqKlZXoU--) {
        IVwddhOuELZUPKwv /= fXQeoVKrMvHiKTU;
    }

    for (int jbZGRe = 820774898; jbZGRe > 0; jbZGRe--) {
        ZNEWpMUvHLyMW += ZNEWpMUvHLyMW;
    }

    if (MQvRX != -503753672) {
        for (int bdPNZxrVKhZ = 24965068; bdPNZxrVKhZ > 0; bdPNZxrVKhZ--) {
            UfZFsjWohDbDFfx -= skfJBuWqrNYE;
            skfJBuWqrNYE -= MQvRX;
        }
    }
}

double QyiHvrnrrTipd::vXlgCKdoProU(string CIkVT)
{
    int KxvaMuZFutWC = 1878289496;
    string hurGwQWe = string("TANiiUMSJKzLGGJikuslSjQpXVCjVUlOkuFojduuCfKiKFKhInFoVCZDVhqVCYYMtdwuykBWIElNSjfxYToWUwBcVdlOoOYdiEwwWCLMdPBARKFDGUcYMpGhrgau");
    int YiEPTaF = 54895190;
    double SVAvkavZnzJf = -244475.03798056362;
    double GheWKbNMinQDyT = -22548.490296565556;
    int mqtBE = 1005710036;
    string DtvyAzMZrN = string("EcmTyoRmNQktGlysjBXNZcUUSsxfkMaSyjbPxdYctYVFbQrYicNtkwrlWsHXrfzmHDnrxftszj");

    for (int YmOxSk = 2060014540; YmOxSk > 0; YmOxSk--) {
        continue;
    }

    return GheWKbNMinQDyT;
}

double QyiHvrnrrTipd::vBSBRxaVwWtQp()
{
    string XzqaekMaLmp = string("lHxJIEntqibSCxqekDXiFJILOrYEuTvMxHlTnjTxmkYRrdCfrPyCfkQwTVLBnNsTvuajOilTWklHzFaNVEWzOXgyAobTadUchFlgCGasEUoRjakfWaWoaHQrQPTXXiVgfJyIZuvwXqaWwSPpnpUJOlbBEhWdTkITGlOWNFpSPdikRBkGbJJdBZjAAmDZykMuLaOnPsNOOavbBxEWtFot");
    string BurdNf = string("wRndGQLXqfBDqvmohwNJfuToPASTSHEiSFrEafnWotaBdikcgsUhoEqzVrOvblQWEDmcRhwwcDeVArhjMLnNprZcEpRkphQTuLXjSgHEwHhEzDiPZUQAISbrjOXMOHknHEBcBWXpJvCLtjGxLMculPpTnQiytckdiXKINWHGzQNckPQrOGiYJkpYDJJoFOEZIkZVzACYOknLOfSQOyzkReXmdWwFpCqtkXr");
    bool rfOOndPeL = false;
    int ODkMeySO = -992881955;
    int tMJnwXfeox = -364453450;
    string AdhBEBSaxbBnV = string("tzDPdUziVpKyZhzFcNezvkojCIOj");

    if (XzqaekMaLmp >= string("lHxJIEntqibSCxqekDXiFJILOrYEuTvMxHlTnjTxmkYRrdCfrPyCfkQwTVLBnNsTvuajOilTWklHzFaNVEWzOXgyAobTadUchFlgCGasEUoRjakfWaWoaHQrQPTXXiVgfJyIZuvwXqaWwSPpnpUJOlbBEhWdTkITGlOWNFpSPdikRBkGbJJdBZjAAmDZykMuLaOnPsNOOavbBxEWtFot")) {
        for (int zVooFsMTHUbvSQ = 1748248396; zVooFsMTHUbvSQ > 0; zVooFsMTHUbvSQ--) {
            XzqaekMaLmp = BurdNf;
        }
    }

    return 861028.7645696778;
}

QyiHvrnrrTipd::QyiHvrnrrTipd()
{
    this->IYwMG(-1355313183, 1040274.594302322, string("EqRQojEkNfJSFBcO"), -663339264, 10770270);
    this->kiRVIlxRWdf(true, 51938084, 258495.3244715403, -2096049093);
    this->jiVbIcOfVnwi(true, string("zoMpSpDpkuxsoPlhqduLpRXOQRatpcbHvXllRRvQgjpDlYxZZtLskVhLPZFTjcNKNzQJZKgVZEqZFblXDIVJWqPI"), -439812843);
    this->rthQYPkPtrICkpi(126938484, false);
    this->UfYJNflCBQ(-3397.2052733881865, -663563.4543940405, -453178.0876738599, -770434.5203836177);
    this->ziaPuy(-898029756, -2035735353, string("HmIpmZGtVedvEJaKgLNRbMsftkJPhjlpUxbjJhLVaZnhkgKYsWkfrzRRdztoQrCTyTataJVIUXssSkXYAgmsUmbXGcWDvmliGvnCeouNltDfjeCxmWjbFzItljVsQAWbylFGsUjOVvotszBPfMWELAldbuNWUYJHXFMuedBSHlVmTzi"));
    this->JNRnsDRrAUQLD(string("hSvHzJCodEGBlnZlorwMQIYnxJuJdVoYBkCeEfaVxNffOvzqLwwgRbzZvoSCchNAgnkZMuSYGxXqIWYyjuCcSvgrLUvIIyWiVuyESbwDSniYCBmthgxntospMkmzgUmQigIZOpACWfbiLgHdpcLuTplIMVXfEttPCBFTYfWYIQChHGuLJMoPEWqqsELvBtJlzSLrsTAvclDZPKJngUtEFfgqLnpDsKRuMwRpxfsFcAFwWvmzjpLCxvQCJzYt"), -1905612255, -277504.3901740623);
    this->FltqrQFeiCqGQdaz(false, 954284.490184391, string("veuzchkRNMofOYtBEWUSRrWlNBBLtixPjotSSKAVXJDqWWhGNOWfnuEcWDxWCsUyLzxRCqDQwrQxJrAKqXNtGCgOCMOfmDtZgreHZINYkUGXkRhkcPAjlacXUTGkttNNowf"), string("sCMlaZAQTynpKOnEtlYzMUefpnwUramBEKOwuvwCmgWoemxUemydmJkVvugmxIkBoaR"), 465175416);
    this->flGHOeiXrDCSR(false, false, -94446.72703144062, 701936.4675453979);
    this->IOmHsoPlBnBLAN(true, string("FqDXTHLWbHLbTvtxjAvfevlYbfMthqoAfwhDXeyQXCpnNQYOipINYaSbstEstmQvaNfEEAOniiTfqsUSwVqaDLGOxrJRL"));
    this->vXlgCKdoProU(string("iCiiOPdpzFnCsOJdTnFGvMIfapKjWs"));
    this->vBSBRxaVwWtQp();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tDhUnYwW
{
public:
    int INyiy;
    string ztyIDRAQ;
    bool WJDjyqvV;
    double LisWAkRVIT;
    int AAPLQ;
    double YEJrJJh;

    tDhUnYwW();
    bool HNbzbyGIEmrWOEb(int lEVSESlqBs, bool OVgadiyWTfLjUK, string eqPsppkjezgOG, double kjjYywjYjIt);
    double BtCEIAyVeVWHzuT(double xaMVfEG, bool cznYh, int nmnJnKWErbAmxy, int yLxkSgEegVVuuYA);
    bool BflfEcAf(double fJubhfuD, double ZtAjUoZiycrkya, bool iJfoiutaLYMksl);
    int wHnYbjeRliqTyMpN(string NqCugr, double buPqn, bool pwVDJoHWA, int ifUmeeb);
    bool KMyANE(bool rLFCYFMLFAKgfj, string ZcADvvdnPLfWcA);
    bool fqyJya(int EVdYAGay);
    int nlxfTBY();
    double vBMRP(double Fxecn);
protected:
    string tSPdX;
    double UkhsvCxjSCzwDxdp;
    double iXIrLEjHtYP;
    bool uCLxlEaFtRuad;
    string KczPkOsgZpP;
    bool pQOwPxsgrf;

    bool LbhHuogA(int kZqMisSzvbkT);
    void KyIbri();
    void rBFlPmpcstYDcr(double txnfJIVAo, double irQCy, int mDxrCaIob);
    void cWqeJz(int iguaBvsoCalaGps, double ORhCKuQjAzo, bool WwjrdNZl, string bMKouKFuGxISSfV, int UagCs);
private:
    int XeukBVhe;

    void NbKyFmjhthZEB();
};

bool tDhUnYwW::HNbzbyGIEmrWOEb(int lEVSESlqBs, bool OVgadiyWTfLjUK, string eqPsppkjezgOG, double kjjYywjYjIt)
{
    double HQGOZGNOUO = -587391.5858400638;
    int DuaetJyEEMWOFso = 1272157581;
    int gRkFQgpYdCccLszE = 554968416;
    bool hcdQmHL = true;

    if (gRkFQgpYdCccLszE <= -2130013577) {
        for (int mqVdAKrxV = 1999287408; mqVdAKrxV > 0; mqVdAKrxV--) {
            continue;
        }
    }

    for (int wrZkgoSBkRYFG = 211404651; wrZkgoSBkRYFG > 0; wrZkgoSBkRYFG--) {
        lEVSESlqBs += DuaetJyEEMWOFso;
    }

    for (int aRmIFZVs = 1899796107; aRmIFZVs > 0; aRmIFZVs--) {
        lEVSESlqBs /= DuaetJyEEMWOFso;
        lEVSESlqBs -= lEVSESlqBs;
        gRkFQgpYdCccLszE += DuaetJyEEMWOFso;
    }

    for (int kMlYn = 333039400; kMlYn > 0; kMlYn--) {
        DuaetJyEEMWOFso *= gRkFQgpYdCccLszE;
        gRkFQgpYdCccLszE = lEVSESlqBs;
    }

    return hcdQmHL;
}

double tDhUnYwW::BtCEIAyVeVWHzuT(double xaMVfEG, bool cznYh, int nmnJnKWErbAmxy, int yLxkSgEegVVuuYA)
{
    double TfKaCjkraTEGO = -680149.3834103653;
    double VPppArSSdjsRhFT = -889331.387568271;
    string yGwAn = string("jrYAWIVscrRsAHpxINvmcXVaVOcNlCMfUDQsenzTUDjadjTKuGADSuhBJkSbBhkBZEmBHjQfcDEGxK");
    bool fzMhHF = true;
    bool mMMRkzOmopvdM = false;

    for (int oKoSY = 19648642; oKoSY > 0; oKoSY--) {
        continue;
    }

    for (int NzXJQRdjOBcJ = 1287118217; NzXJQRdjOBcJ > 0; NzXJQRdjOBcJ--) {
        continue;
    }

    for (int OTryq = 932701609; OTryq > 0; OTryq--) {
        yLxkSgEegVVuuYA *= yLxkSgEegVVuuYA;
        nmnJnKWErbAmxy -= yLxkSgEegVVuuYA;
        xaMVfEG += VPppArSSdjsRhFT;
        TfKaCjkraTEGO -= TfKaCjkraTEGO;
        nmnJnKWErbAmxy /= nmnJnKWErbAmxy;
        fzMhHF = ! cznYh;
    }

    return VPppArSSdjsRhFT;
}

bool tDhUnYwW::BflfEcAf(double fJubhfuD, double ZtAjUoZiycrkya, bool iJfoiutaLYMksl)
{
    double SPCxc = -834401.2599372694;
    string ugGxDZmNp = string("VPPSusZUZpvRVqQkCPEyoyZbYEWkPQKYJkqoRXrhEkuCVkkNigwLVCeiwNPTSBGcFlJHUWLXbhxOjtvlWNLCdnNAfZsdiAajGBtJwuHLQKlywZLmCmOGoTXUhUJlRQGIdIzxFhQjhGaQkpXaqgzQgcVPbXieqhmqiSHcBcWcADSceGCpouNOUeTEFMgxshOyfThVRnShTbeRZUSvzvmNXZBXoPsal");
    bool ocFWmd = true;
    string BdiEp = string("FzUIzZCVfZowpUBotZTdVWLJIcsNYnrUubSxbWLsefYMHgHrLUcXfIKwtWgiHTpkRcsygIijHfHUTUMgnROofwiYSPCzMMDvgUWKrtypUsksOqTOvDnxsdFekSuEvuJupLXMCzdBloRGhUkXtzbUQgddTIsqaXHczkJjLsQTFNKvwiHluIIrdHfBjhehusoprnQafnD");
    string wTxTyXcevLRq = string("KQjOxbqvUYdtOliMReaCntPUMJnwbVjNSuzzYAtZXCQdTbxkAGjXECUutqmaBSLXZKffLpOfiOvBDvwXCjXgtbveDEwUUsCASgCbalEzfmPmVVrStQAkZaFCNpXBzCTbvmsLUQvuUgYGCwSMGovAdvYFIkPVTBbFEeIvwCefWLyEmVgRCdUBAtdafkRbBIrsuIlzxsRkPKyZDaIhbfcgE");
    int lFZnDtVYvOnsdhra = 1220100403;
    bool zWJOtBRBdMJaW = true;

    for (int AiKhNIlm = 1069376731; AiKhNIlm > 0; AiKhNIlm--) {
        BdiEp += ugGxDZmNp;
        ocFWmd = iJfoiutaLYMksl;
    }

    for (int PAIVReMXXEXrTAv = 2109366287; PAIVReMXXEXrTAv > 0; PAIVReMXXEXrTAv--) {
        ZtAjUoZiycrkya /= SPCxc;
        SPCxc /= ZtAjUoZiycrkya;
    }

    if (wTxTyXcevLRq > string("KQjOxbqvUYdtOliMReaCntPUMJnwbVjNSuzzYAtZXCQdTbxkAGjXECUutqmaBSLXZKffLpOfiOvBDvwXCjXgtbveDEwUUsCASgCbalEzfmPmVVrStQAkZaFCNpXBzCTbvmsLUQvuUgYGCwSMGovAdvYFIkPVTBbFEeIvwCefWLyEmVgRCdUBAtdafkRbBIrsuIlzxsRkPKyZDaIhbfcgE")) {
        for (int ahWNrT = 2101053406; ahWNrT > 0; ahWNrT--) {
            iJfoiutaLYMksl = ! ocFWmd;
            wTxTyXcevLRq += wTxTyXcevLRq;
        }
    }

    return zWJOtBRBdMJaW;
}

int tDhUnYwW::wHnYbjeRliqTyMpN(string NqCugr, double buPqn, bool pwVDJoHWA, int ifUmeeb)
{
    bool UnbnlyHjGUe = true;

    for (int GsIXjFWvdRvhxF = 36164894; GsIXjFWvdRvhxF > 0; GsIXjFWvdRvhxF--) {
        UnbnlyHjGUe = ! UnbnlyHjGUe;
    }

    for (int LtpTqLQkhNq = 1989132159; LtpTqLQkhNq > 0; LtpTqLQkhNq--) {
        pwVDJoHWA = ! UnbnlyHjGUe;
        UnbnlyHjGUe = ! UnbnlyHjGUe;
    }

    if (NqCugr != string("nYNUIilgTiAZPxxUCsILUFZIBOCCMDmyrsnWUMdRKumrOUYtjDHcpWUzFXyrqH")) {
        for (int ELtCaxgRfysGdqC = 881058443; ELtCaxgRfysGdqC > 0; ELtCaxgRfysGdqC--) {
            continue;
        }
    }

    for (int bTkschFSLoNbTS = 82435344; bTkschFSLoNbTS > 0; bTkschFSLoNbTS--) {
        ifUmeeb = ifUmeeb;
    }

    for (int uDzgYeffCXxTdjAj = 1934577385; uDzgYeffCXxTdjAj > 0; uDzgYeffCXxTdjAj--) {
        continue;
    }

    return ifUmeeb;
}

bool tDhUnYwW::KMyANE(bool rLFCYFMLFAKgfj, string ZcADvvdnPLfWcA)
{
    int pkllZueovPQAtG = 826501355;
    int QDAPqoZPRyevCCf = 998227387;
    string nBLMJKghti = string("ARXzBFprohANOogPCyoWIuGmaOMpzPwVbApiUDpnlhTTUpxmTcJkdjRGfvBwMMGfcyfejICCbGbYGZcghyFCouGFmBcuSzwuNZvBCJOtebjwMLYxwpNdxlXwHldWKnmJdEGVRLcGBPRZSRtVOVNqCJhZqonWbxgPzXJoKrbuBQoyleKEwreNMLqhTiFNXRuNijisqRkLd");
    string XMHOBMJJjdUQdPWC = string("ebvwHDGoQGPTDFMQeEVPgqnwjvZxNohohZQeyoGNeNXVshJvbKInUKlZwIksPYjewPruwcUGtYHbddFKvXgrvvvypwYbPGyPNVdpJhiguoxQdoEUhuRXwfcNyUgEEpNgRzSsPoSquSaymgcGGAFBQuTmWZsLlRKnIcHHawwkXRyFMGgPWjwMgBtPgzrLEPLZaHYHKO");
    double jjmKrlQDMX = -277645.14986280864;
    bool zGJgfNu = false;
    double zCrjGCKrJkPt = -438332.5696479835;
    string DQJBlvqwWFJHuK = string("uSAOeYoYmlgjsBLbGeZWgwWXwKYwsMGwFlXXSSbr");
    double MDjJbLbWTzqGA = 439815.462442696;

    for (int WqZPLfysrDZymg = 153997700; WqZPLfysrDZymg > 0; WqZPLfysrDZymg--) {
        zCrjGCKrJkPt = zCrjGCKrJkPt;
        zCrjGCKrJkPt += jjmKrlQDMX;
        jjmKrlQDMX /= MDjJbLbWTzqGA;
    }

    return zGJgfNu;
}

bool tDhUnYwW::fqyJya(int EVdYAGay)
{
    double ejVWnbJIT = 512394.5257209888;

    for (int IYxdTqxkBfnPzl = 1771818698; IYxdTqxkBfnPzl > 0; IYxdTqxkBfnPzl--) {
        continue;
    }

    for (int gTmWRLoS = 1382108082; gTmWRLoS > 0; gTmWRLoS--) {
        continue;
    }

    if (ejVWnbJIT > 512394.5257209888) {
        for (int IyzniI = 1105575376; IyzniI > 0; IyzniI--) {
            continue;
        }
    }

    return false;
}

int tDhUnYwW::nlxfTBY()
{
    bool VnglMdXpi = false;
    bool yljnySnGdJaAYxCq = false;
    string uARJBWhSJFefK = string("ORLmdxyyBmyfJyksAvwMBQzEloFXdSKvDbDtvNGvwcGnBkrESUlESohchfIFHdqPwvpeUeimuAGKPDZcdMirOTQIViXQnePEXZHajXtGeNHmaSJClPMoJwoPjg");
    int irgjVBv = -1795267492;
    bool owmSqK = false;
    double QGHLdrBOEJfufRm = 287925.44974429795;
    double HYIKOrEbnohNsTJQ = 942707.3487182406;

    if (uARJBWhSJFefK < string("ORLmdxyyBmyfJyksAvwMBQzEloFXdSKvDbDtvNGvwcGnBkrESUlESohchfIFHdqPwvpeUeimuAGKPDZcdMirOTQIViXQnePEXZHajXtGeNHmaSJClPMoJwoPjg")) {
        for (int jCFUsEvLP = 1375213766; jCFUsEvLP > 0; jCFUsEvLP--) {
            VnglMdXpi = ! yljnySnGdJaAYxCq;
            yljnySnGdJaAYxCq = VnglMdXpi;
        }
    }

    for (int oCqWOpdA = 133533910; oCqWOpdA > 0; oCqWOpdA--) {
        owmSqK = yljnySnGdJaAYxCq;
        yljnySnGdJaAYxCq = yljnySnGdJaAYxCq;
    }

    for (int wyranboBFzRUg = 1381029679; wyranboBFzRUg > 0; wyranboBFzRUg--) {
        QGHLdrBOEJfufRm -= QGHLdrBOEJfufRm;
        yljnySnGdJaAYxCq = yljnySnGdJaAYxCq;
    }

    for (int CLOvfoHQKe = 502206040; CLOvfoHQKe > 0; CLOvfoHQKe--) {
        owmSqK = ! owmSqK;
    }

    return irgjVBv;
}

double tDhUnYwW::vBMRP(double Fxecn)
{
    bool RWvHOGEpII = true;
    string LmNVEQyZv = string("JZXPdGnFGAXLjycyDWJhTAUwvWZfPdQimUrTGivyILYqzoAVUdvGgxnPzHreUHKCKapIoTqtnreatKunUnpKKDVMTvyhOKDSVtmKwgFPQMknnYXFQgcfMYQcK");
    bool TIyoBIIh = true;

    if (LmNVEQyZv >= string("JZXPdGnFGAXLjycyDWJhTAUwvWZfPdQimUrTGivyILYqzoAVUdvGgxnPzHreUHKCKapIoTqtnreatKunUnpKKDVMTvyhOKDSVtmKwgFPQMknnYXFQgcfMYQcK")) {
        for (int GLwvZjztdEhiP = 645096576; GLwvZjztdEhiP > 0; GLwvZjztdEhiP--) {
            LmNVEQyZv += LmNVEQyZv;
            TIyoBIIh = ! TIyoBIIh;
        }
    }

    return Fxecn;
}

bool tDhUnYwW::LbhHuogA(int kZqMisSzvbkT)
{
    int hflgVyqSekh = 1035116147;

    if (hflgVyqSekh < 1035116147) {
        for (int BxdLC = 482272331; BxdLC > 0; BxdLC--) {
            hflgVyqSekh = hflgVyqSekh;
            hflgVyqSekh -= hflgVyqSekh;
            kZqMisSzvbkT -= hflgVyqSekh;
            hflgVyqSekh = hflgVyqSekh;
            kZqMisSzvbkT /= kZqMisSzvbkT;
            hflgVyqSekh /= kZqMisSzvbkT;
        }
    }

    return false;
}

void tDhUnYwW::KyIbri()
{
    double XwrKEdCi = -612092.7037986795;
    int TAuFAPT = -995992066;
    double urUrhUPTTsVSziE = 330346.6049927813;
    bool GEyyYSERiNbIXok = true;
    int joMTpMQbHLjI = -495076409;
    bool jBraRdotOqneFE = true;
    double kwABZQRJS = -626958.507916528;
    string mJPNLVR = string("RSJMQs");
    string uTczVLpiQFaNkue = string("evovYojpeiFqYeOdIDZoNgajXKUHsBvQWqrBQYmCiffwYMOjETLqCnaiQCCgcStyuRUNvxCHmFqrMsCpOsYhFdlcQrwIQxvKJLfqxKzb");

    for (int ghuqCqzBxXdA = 1563918621; ghuqCqzBxXdA > 0; ghuqCqzBxXdA--) {
        kwABZQRJS -= XwrKEdCi;
    }

    for (int lAXfrttdFmgHTp = 1671048259; lAXfrttdFmgHTp > 0; lAXfrttdFmgHTp--) {
        kwABZQRJS = XwrKEdCi;
    }

    for (int xQJggy = 896041899; xQJggy > 0; xQJggy--) {
        GEyyYSERiNbIXok = ! jBraRdotOqneFE;
    }
}

void tDhUnYwW::rBFlPmpcstYDcr(double txnfJIVAo, double irQCy, int mDxrCaIob)
{
    double oUBisLWo = 990150.5288788014;
    bool iGPZtPYRZyv = true;
    int LFvFxWTCvF = -1421141441;
    bool kZKiTjqceubtJ = true;
    int WRmAxx = -580154933;

    for (int pRCxvIMhI = 1768762150; pRCxvIMhI > 0; pRCxvIMhI--) {
        continue;
    }

    for (int ucXvlRMqy = 206137735; ucXvlRMqy > 0; ucXvlRMqy--) {
        txnfJIVAo += irQCy;
        iGPZtPYRZyv = iGPZtPYRZyv;
    }
}

void tDhUnYwW::cWqeJz(int iguaBvsoCalaGps, double ORhCKuQjAzo, bool WwjrdNZl, string bMKouKFuGxISSfV, int UagCs)
{
    int SnCjtrDwdh = -1794089278;
    int Prqyvn = 192062753;
    bool ivUShOnUlAaK = true;
    double vvfASGQXPCrg = 107894.01858146807;
    int lsisJJX = 192538208;
    string CFJWfL = string("HnZoMPCxLDPcubcImrVLBkLpqSBwsAouVJJMYnhxjFdqqDDYBtBJurArVFkeenZFIRxjAbbuytQGFpTHNNxnjRSnWZMIMLivzXZGSJSHJunQsaAlXYKLrnHLblFqpERFiUScNCJRjjLTZHNOtHJOVzQfuqYUnrgmntV");
    bool GSKyKiXgRqHwbCWu = true;
    double VYXbLZRFpAiNW = 416302.1506580195;
    string ffldubqTNojrsUx = string("WlatTqfFmlNENIENcSCpAvAdAovKUoTFRiLunaTrWJjDvwDgSeQcwWoonXLpDbCAsdVhWgUWuMtNbyWFpmHXJmSFbVhvltVwzVLkkTOKDfJhMnlfKbYCdMkZOXgBLLNLoWDoYOwoSBEDEEoieyAHqRqtljZJGPOTXBbcrLpcVRyWRejWzViE");
    bool XqqcbKp = true;

    for (int pPXZuv = 707492681; pPXZuv > 0; pPXZuv--) {
        VYXbLZRFpAiNW = ORhCKuQjAzo;
        iguaBvsoCalaGps += UagCs;
        ORhCKuQjAzo /= VYXbLZRFpAiNW;
    }

    for (int HuGwbqLpFKrWMRd = 1005166216; HuGwbqLpFKrWMRd > 0; HuGwbqLpFKrWMRd--) {
        continue;
    }

    for (int zYIAjDb = 849734843; zYIAjDb > 0; zYIAjDb--) {
        Prqyvn *= SnCjtrDwdh;
    }
}

void tDhUnYwW::NbKyFmjhthZEB()
{
    bool HVzmrGdkpradpwC = true;
    int ZsQuE = -1769674333;

    for (int xZjEQ = 1167063973; xZjEQ > 0; xZjEQ--) {
        HVzmrGdkpradpwC = HVzmrGdkpradpwC;
        ZsQuE = ZsQuE;
        HVzmrGdkpradpwC = HVzmrGdkpradpwC;
        ZsQuE += ZsQuE;
        HVzmrGdkpradpwC = ! HVzmrGdkpradpwC;
    }

    for (int McAOVyeLaKhpz = 718395110; McAOVyeLaKhpz > 0; McAOVyeLaKhpz--) {
        ZsQuE = ZsQuE;
        HVzmrGdkpradpwC = HVzmrGdkpradpwC;
        ZsQuE /= ZsQuE;
        HVzmrGdkpradpwC = HVzmrGdkpradpwC;
    }

    if (HVzmrGdkpradpwC != true) {
        for (int mRkYcFPEZSOms = 407830239; mRkYcFPEZSOms > 0; mRkYcFPEZSOms--) {
            HVzmrGdkpradpwC = HVzmrGdkpradpwC;
            HVzmrGdkpradpwC = HVzmrGdkpradpwC;
            ZsQuE *= ZsQuE;
            HVzmrGdkpradpwC = ! HVzmrGdkpradpwC;
            HVzmrGdkpradpwC = HVzmrGdkpradpwC;
        }
    }

    if (HVzmrGdkpradpwC != true) {
        for (int spiVCbWyuCknrXzM = 1911707124; spiVCbWyuCknrXzM > 0; spiVCbWyuCknrXzM--) {
            ZsQuE -= ZsQuE;
            HVzmrGdkpradpwC = HVzmrGdkpradpwC;
        }
    }
}

tDhUnYwW::tDhUnYwW()
{
    this->HNbzbyGIEmrWOEb(-2130013577, false, string("rzUkPQYTjBhaiWcLDeqWIHEGddzKfJBWzSGEMwPzTSpWVJcYrCUWVXWwZFTwInrsVkjKuvszHiViZjUoqxnYKoWUUiSXtnodXdgsSujjIzmtqukPQKzeXgoCQirRAUoduHEvgprelXbIKuXchIsEkVgxgUFvaAdgylUlUneoPkuWcVtZCEJoYAbaOfsdnrgqdEuJeHuqbd"), -96219.80455719953);
    this->BtCEIAyVeVWHzuT(485256.7306584578, true, 189410480, -1256595970);
    this->BflfEcAf(635432.2161497409, 965552.3273099512, true);
    this->wHnYbjeRliqTyMpN(string("nYNUIilgTiAZPxxUCsILUFZIBOCCMDmyrsnWUMdRKumrOUYtjDHcpWUzFXyrqH"), -603587.2455638335, false, 818856039);
    this->KMyANE(true, string("oXsHEBQEQGijpWVdZZBgLDVZFQsgmjWMcLYgpTAfJXtYUsuJHDAJgSrgadIZIjpZpCmObXronVckuEZZvirHpMOcluybqLAWwDdaWUxlkWHiFoVyLwmMoNcQQgj"));
    this->fqyJya(-459914555);
    this->nlxfTBY();
    this->vBMRP(-1039788.3905549684);
    this->LbhHuogA(-983022323);
    this->KyIbri();
    this->rBFlPmpcstYDcr(721088.3922330822, 636962.658562008, -1689311489);
    this->cWqeJz(-480614061, 70628.88048409716, false, string("sBPRlPBPmmopqkQUAYFWXdEzksAuQLxKVqyvAQR"), 1513150783);
    this->NbKyFmjhthZEB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class THSAyhaHdRF
{
public:
    string eQYfWlvgzfLEeq;
    bool EUlpfeNYRGsdeIpc;
    int VPttYvbKVZQrQDhF;
    bool SJoHSsTAN;

    THSAyhaHdRF();
    double TWjPHBkytEUXR(int HVfifdIinZbM, double ZvuZFQumWlP);
    void vIlosUuPLadVKIE();
    void LAElRIF(int FbZBsesGBMpCgSQ, double WbfFVasmsb, string sPFUgmboGrdrRq);
    void pwchKijrYhBZ(int XItFNaitlwiqDp, double PfMicvGyt, int hnqSTOAfvDUUg, int agRWH, string ZsexzYHzTz);
    double bdyWRP(int bTAEDQwVZZ, double cdYuUjil, string mxTIiSUr, int FUUokbroLnRQu, int OltHXDrXa);
protected:
    int ulMhHGPzmM;
    bool qSTXMqlGcJzPyyFb;
    int ZlYIQnYnWVqbl;
    int iOLhHNi;
    bool VrmhIhlQSF;

private:
    string AiuQWyFBxyMirVR;

    int rzNABcwaidMgALlJ(int hBRnp);
};

double THSAyhaHdRF::TWjPHBkytEUXR(int HVfifdIinZbM, double ZvuZFQumWlP)
{
    string sZHyfyX = string("dAlEhvyGMVjTc");
    string bWIOj = string("tFuJXcEVSGNcDzraDPZFFtncUMGLoXBceMmgSXAGjPgaYZBSZeaCztHvAgVXimMgYVCDBzpvRkLOcGGNllfUmEKAibaHfeRGdKVlYvCwoXxpQhIToKZIBrJVOLadrGSXmehlyYTUjapRmKDgKOUqwSboPJkzlXkYNaSyKNLpAcKoUBCNqNQGQatVsZPFCuYyKJumZNmkZYfrrYBTFxYUSnTIjntdDRQvbgmwwwFQblOGXncpbkTryzaWaOLIuvT");
    int aTbxBqGKdeREzo = -1570708908;
    string eQEWTBhsG = string("kgDuUVHOkJCZgqtYaAvzvOQlMEvVWkNTrVAMhuzLuUgGOzZdOHamCuTmzGwkIVxndnMbjnjxwmOKYrHGuNXWvmGyrHHElKgqOwnIOPcFHoVmEvUmLTfKuIngiJdutGszMJTwYwvoVaMYqEZAmyDEHTiQxiYngWitmyEKqSgGRNIrVCUqoKBXTFEOI");
    int zAxFOYKVGeWJto = 605015111;
    double IzaVqdIhEueO = -852911.5826064865;

    if (zAxFOYKVGeWJto < 1563933899) {
        for (int nuEhrPWTwZmVH = 877802196; nuEhrPWTwZmVH > 0; nuEhrPWTwZmVH--) {
            bWIOj += bWIOj;
            IzaVqdIhEueO -= ZvuZFQumWlP;
            aTbxBqGKdeREzo += zAxFOYKVGeWJto;
        }
    }

    for (int uURvl = 342300541; uURvl > 0; uURvl--) {
        sZHyfyX = sZHyfyX;
        sZHyfyX += bWIOj;
    }

    for (int MUXOmdbzjIEdawBD = 909026774; MUXOmdbzjIEdawBD > 0; MUXOmdbzjIEdawBD--) {
        continue;
    }

    return IzaVqdIhEueO;
}

void THSAyhaHdRF::vIlosUuPLadVKIE()
{
    double MxlfakvTlZMJK = -370024.37088289723;
    bool WzSnETZs = true;
    double IPFXOzaNdkCwBav = 201466.60567239317;
    double aSUmkNSc = 1019710.3465456734;
    int IiztxSPswd = 819733227;
    int YgLqoQvsDrLAby = -1722643201;
    double csQQcG = 956405.0627395278;

    if (IiztxSPswd != -1722643201) {
        for (int QJZUX = 1232042794; QJZUX > 0; QJZUX--) {
            aSUmkNSc += IPFXOzaNdkCwBav;
            IiztxSPswd *= IiztxSPswd;
            csQQcG += MxlfakvTlZMJK;
            aSUmkNSc += MxlfakvTlZMJK;
            IiztxSPswd = IiztxSPswd;
        }
    }

    for (int duKPFegHcIJpAhYI = 687839552; duKPFegHcIJpAhYI > 0; duKPFegHcIJpAhYI--) {
        aSUmkNSc += MxlfakvTlZMJK;
        MxlfakvTlZMJK /= csQQcG;
        csQQcG /= aSUmkNSc;
        MxlfakvTlZMJK = csQQcG;
        aSUmkNSc = IPFXOzaNdkCwBav;
    }

    if (MxlfakvTlZMJK <= 956405.0627395278) {
        for (int VBsYK = 346669015; VBsYK > 0; VBsYK--) {
            csQQcG *= MxlfakvTlZMJK;
            YgLqoQvsDrLAby += IiztxSPswd;
            YgLqoQvsDrLAby *= YgLqoQvsDrLAby;
            YgLqoQvsDrLAby = YgLqoQvsDrLAby;
            IPFXOzaNdkCwBav *= csQQcG;
            MxlfakvTlZMJK = aSUmkNSc;
            YgLqoQvsDrLAby *= IiztxSPswd;
        }
    }

    if (csQQcG >= -370024.37088289723) {
        for (int KZWOhNIGFFo = 802341963; KZWOhNIGFFo > 0; KZWOhNIGFFo--) {
            csQQcG -= aSUmkNSc;
            MxlfakvTlZMJK /= aSUmkNSc;
            csQQcG = MxlfakvTlZMJK;
        }
    }

    if (IiztxSPswd <= -1722643201) {
        for (int irrgPVvboK = 570517776; irrgPVvboK > 0; irrgPVvboK--) {
            csQQcG = csQQcG;
            IPFXOzaNdkCwBav *= aSUmkNSc;
            YgLqoQvsDrLAby /= IiztxSPswd;
            aSUmkNSc -= IPFXOzaNdkCwBav;
            aSUmkNSc -= IPFXOzaNdkCwBav;
        }
    }
}

void THSAyhaHdRF::LAElRIF(int FbZBsesGBMpCgSQ, double WbfFVasmsb, string sPFUgmboGrdrRq)
{
    bool UUpfe = true;
    int OPOaS = -2027480573;
    string CfdYRnoUDkpiANf = string("dfvhsbySErsuMMjrQGwyoSTcADHZMrYpPLZxEbBpEYiTFixaWPJshELCsbOxahthmrcHVCdFUxyyHKRnjfcNxmWknzsXJSYMLbapBHcOSinUYKCpqSPgGUjiRWFdTuKVTgIaExJZOgMecmpPLRsiODNJXTCVssxQFQhRWKmlejGvZzAxzXLzQHvZYBwYyvSlQEOlijBjEGQgCHBVTeLbtlNHLEmnXYRUtbTZsaplIOMKKXpJJ");
    double nNpyGBu = -585101.7347799657;
    string ivDUXHkOixCwf = string("CvvoAqCoMjAHXMjUemmzmUASNHqSuEGCchDnQTeTBWAcRfnrSmaSKpoYKsSbeiVJcxqmAZeqgAkTbeqFFXQwTPwDAXNPNZxZsvhjP");

    for (int oYCHMmSI = 2010130706; oYCHMmSI > 0; oYCHMmSI--) {
        UUpfe = ! UUpfe;
        ivDUXHkOixCwf += CfdYRnoUDkpiANf;
        sPFUgmboGrdrRq += sPFUgmboGrdrRq;
    }
}

void THSAyhaHdRF::pwchKijrYhBZ(int XItFNaitlwiqDp, double PfMicvGyt, int hnqSTOAfvDUUg, int agRWH, string ZsexzYHzTz)
{
    string kQgczgPKC = string("bOOGtQpCvwiLXaWGgzRjbTdFwCmDkKtIM");
    bool SotHefFhvozZnjl = true;
    double WAsROreAebbTSrCM = 608073.865704419;
    string hjIBTgQCD = string("VQQAhgkPKUciorAJAcauoUYLXzjpqhDLpchdVoVSJCNcOnABohUwVuFRaxEIWZbYGzCNbFaEcAYYHPfuohDgjWrkVIFfKfYZFxEOWVZtVzFLiRZRCjMRwwzrmekOryOeuHETFlO");
    int jqXEtrqPXeCwXq = -493595567;
    string gQDBYDp = string("oJerAXLhHDfgyyKQGBhgYEErkoTiAbvQjlIgFTgHwJyigwBIGmpPJfJJMNyRetlTOcPldkvlijHtzwMuPKIVeXyQxradsEvkuTbDyyhEaukTkDMwHOcrEdGEVmpZiBbRjlfJaEzsOvGdZEJfoUeAmitAgFERsgKfMAgGxiojlzVqeOKNhDkTkmzqRkXQkqhNYUxjAzGppFDLsNGaPuNYicUGopThPfAwVNLqQXMpMBzikbuXlwrWmv");
    double XAQzCySzQgg = -849288.7021565051;
    int xzkpbH = -1545268054;
    bool KKGDLTDLEcnexzoH = true;

    for (int JiBIeZ = 1331970035; JiBIeZ > 0; JiBIeZ--) {
        gQDBYDp = gQDBYDp;
    }

    for (int vtVfYrGAUsyq = 284501916; vtVfYrGAUsyq > 0; vtVfYrGAUsyq--) {
        kQgczgPKC = kQgczgPKC;
    }

    for (int zrebgqhvzrvTjeEK = 2135921084; zrebgqhvzrvTjeEK > 0; zrebgqhvzrvTjeEK--) {
        continue;
    }

    for (int lbYDlwtTTaK = 1610430656; lbYDlwtTTaK > 0; lbYDlwtTTaK--) {
        gQDBYDp += gQDBYDp;
        WAsROreAebbTSrCM /= XAQzCySzQgg;
    }
}

double THSAyhaHdRF::bdyWRP(int bTAEDQwVZZ, double cdYuUjil, string mxTIiSUr, int FUUokbroLnRQu, int OltHXDrXa)
{
    bool COKLkdLzL = false;
    double LcpKmwOZOQDFPw = -396860.32342775323;
    double AkkqfQtVjnq = 425402.4260929381;

    if (OltHXDrXa <= 416242387) {
        for (int gtgooTtJNExrtLn = 1358469324; gtgooTtJNExrtLn > 0; gtgooTtJNExrtLn--) {
            LcpKmwOZOQDFPw -= AkkqfQtVjnq;
            COKLkdLzL = ! COKLkdLzL;
            cdYuUjil *= cdYuUjil;
        }
    }

    for (int gMRGZcKL = 1462066625; gMRGZcKL > 0; gMRGZcKL--) {
        bTAEDQwVZZ = FUUokbroLnRQu;
        FUUokbroLnRQu -= bTAEDQwVZZ;
    }

    for (int EQmur = 1401317859; EQmur > 0; EQmur--) {
        LcpKmwOZOQDFPw /= cdYuUjil;
        LcpKmwOZOQDFPw = AkkqfQtVjnq;
    }

    return AkkqfQtVjnq;
}

int THSAyhaHdRF::rzNABcwaidMgALlJ(int hBRnp)
{
    double cfgHtMLdOA = 933810.302288428;
    int lTSRaFySfVFVfs = 347426605;
    double JWqvMFqljUOzDl = 300162.70186996093;
    string eaylicK = string("WVPAfXxoeDzmTHyEGIDqWdizVySiovcjTrcdzPzMbYTGfEkjrHNjKidNcJxyHxyuDgndIRnhomDDsYPymmYntsUEDXZhxQVSJIgsvMvnrgcyDKbElUMVgtLJeujkKONaedLzRCLyDEkSXPpHNCaUxRpJkWnpXzFiVGGLbieqxwMXkifSBeoDFErzUyLehAmadOmWS");
    string yHuffHBRJdygtlxg = string("MeKgPRHGvtRInWEXcnGjwYxmHQcNjEwEaZedglLqttcDwHJMOnWHVVJOVfsAPqoonbCDPgSLZNdCgPhzmNWSzmyNEHinLUYwQZThFGoAEVvkORvDKQDhTHyDVebOcQl");
    int lFiYrkbpK = 792265329;
    double vDSnFPcpobDzZd = -574003.6688166972;
    string QxkLvV = string("DeDZUctJKYhLsDRaHDYbOEgIblDhOFSHnLqvanlbRHNKpOtmdnsrDYjhWLRzakXXbBKBSkDXJwLRcvuxwfBEpeyFtZIeFVPlDXlFAdSWFlWHkHCxZZXToCzPXPJmDLMrPAZuLNQlxeOUMWJiSYNGezIAscJWcMxNrtbmAiXqNGecnxBIKqVlaSqfxAcLAQU");
    string mYseSVSzUYqx = string("IimUXagNRXCititXfUhsEgmHlnTTKapIenSBitTBIkHBAusZFnVBIsZTWsdCwidAWoakyqYaqLUUuywWHERtdqmyTtdDnAhMymENPwlPKBGqQhuBBa");
    int CwPFNzHVu = 1980719965;

    for (int XHXKpNKypRJ = 1182530014; XHXKpNKypRJ > 0; XHXKpNKypRJ--) {
        continue;
    }

    for (int QJLDDgOQ = 2145674513; QJLDDgOQ > 0; QJLDDgOQ--) {
        hBRnp = lFiYrkbpK;
        yHuffHBRJdygtlxg = mYseSVSzUYqx;
        CwPFNzHVu /= hBRnp;
    }

    if (hBRnp >= 792265329) {
        for (int NLCRPRfTXOJRZ = 1387279817; NLCRPRfTXOJRZ > 0; NLCRPRfTXOJRZ--) {
            hBRnp -= lFiYrkbpK;
            yHuffHBRJdygtlxg = eaylicK;
        }
    }

    for (int nsEAPgEsnwgRQE = 757235277; nsEAPgEsnwgRQE > 0; nsEAPgEsnwgRQE--) {
        hBRnp /= lFiYrkbpK;
        yHuffHBRJdygtlxg += eaylicK;
        vDSnFPcpobDzZd += cfgHtMLdOA;
        QxkLvV += eaylicK;
        yHuffHBRJdygtlxg += yHuffHBRJdygtlxg;
        mYseSVSzUYqx = yHuffHBRJdygtlxg;
        yHuffHBRJdygtlxg = eaylicK;
    }

    return CwPFNzHVu;
}

THSAyhaHdRF::THSAyhaHdRF()
{
    this->TWjPHBkytEUXR(1563933899, -658932.3594846096);
    this->vIlosUuPLadVKIE();
    this->LAElRIF(347499480, -1027956.618649397, string("TXBflLEJYMcXDmgEPcg"));
    this->pwchKijrYhBZ(1605473248, 426428.31617300434, -1177486473, 1063647479, string("VGhuMgovgLTvYqDqMHlgPMdeDUeGabSbGDSiXnymYxcncffQQNQtdZiWHgKVEdqilwmvWtXqnpzPyhLEEymDuVhpsiwvjDuwoRdeUFaITZeZXYNVUCuCEgtlHgHGwOpGlddVlTizxxzTjCuNDJLRq"));
    this->bdyWRP(-776974153, 792172.7665807605, string("LsaaSxUvUdQXrulmkePIyAeQXTG"), -600070377, 416242387);
    this->rzNABcwaidMgALlJ(-1851798570);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class apWwnwSgaV
{
public:
    bool rAeOkVXPhob;
    string smNepNGLyaFO;
    string YSviL;
    string EkDPsppeEu;
    bool XasHhJmS;
    bool FwqwNIE;

    apWwnwSgaV();
    int jwjBUDPp(string nJprGgPCOJz);
    double VkDkuVDskU(double rwswiQBOdZooOcB, string KhzOtAVWJCl);
protected:
    int YcUNa;

    string vvdpSZjl();
    double TpzNueIB(string ftdBM, string mhRZqoTWPQsh);
private:
    bool oefot;
    bool PmCoLihXE;
    int JkgxqUN;
    bool apQkRTUaHyoZ;

    double AXMQVwcTPwK(string RJctWXvwH, int lsbpJB, double EDehmKO, int agESXsPDVkYx);
    bool GrEfXUO(int mQlHHwNumWZLDWwS, string dpopaTXTejEnpGWE);
    void hOUVihJI(string bIgUMtKBCgjU, int qEYHCwkzfkZ, double eEjiaJSk);
    double xXIVldLIio(string JcjuUkSwGxFdDt, double PvjPMGXjHmwIP, int SolCVjkH, string AMFjiYJldRBN);
    double CwbVRVoqaxdr();
};

int apWwnwSgaV::jwjBUDPp(string nJprGgPCOJz)
{
    int zsTBhArsTMGIZ = -1937533770;
    double KqnZYvIrIrXokKre = -378314.7094290849;
    string tVGcvhA = string("asyXErrdDPUNPmVOkcAHRrhxktmUvBmFhwguQgq");
    double hoefSAAH = -291749.71527542523;
    int uzJOJuM = 1254200185;

    if (hoefSAAH == -291749.71527542523) {
        for (int SAQHlKrXMnYx = 1257367392; SAQHlKrXMnYx > 0; SAQHlKrXMnYx--) {
            tVGcvhA = nJprGgPCOJz;
            tVGcvhA = nJprGgPCOJz;
            tVGcvhA = nJprGgPCOJz;
            hoefSAAH = hoefSAAH;
        }
    }

    if (hoefSAAH != -291749.71527542523) {
        for (int ULXCilxIHCU = 1779816735; ULXCilxIHCU > 0; ULXCilxIHCU--) {
            zsTBhArsTMGIZ /= zsTBhArsTMGIZ;
            nJprGgPCOJz = tVGcvhA;
        }
    }

    return uzJOJuM;
}

double apWwnwSgaV::VkDkuVDskU(double rwswiQBOdZooOcB, string KhzOtAVWJCl)
{
    double Yxehak = -957858.2839336462;
    bool iaoUFEjguG = false;
    string kHdCZzZNQQf = string("WoaWzIMFyVnOLBHqlfECSoBsttOWdviMzFxtFPQABIlEBHfytWrYKiUeaxHtCttn");
    bool aDpCusxDF = false;
    string LCLkbD = string("ROaOMjeyBhSWbZpkzXOxxkSxhQOWHYINiOmocwUgORnSrLUTlhDtlYuBiwpgznCivTLbvkkQnlEDvfgMoRzzquyXFxdGvnxGGBiNlUTBkrfZfzuflQcerZleRVuDWgDxZHCQfyWVM");
    string wmlnLrB = string("mPVjDCgGFhmyxMaaqfHWLYxbUbPJtJierSrzPBqbeauhFHMGseRVnGmvSszf");
    double eWWOfinWOQUXU = 746599.433538661;
    string IXTvRVsTefYgYHB = string("SneJXyTbCyyEfAsjOFKqGPaQsRPJSRwJHmoUWrsEbbVHvyzmFZWHJUsjAeocLaHjgahQOsemSDRARFVomUpBfxBntHbMWGrZzfrPjOIapwnteUJNFqQcdvOgmNemaeUiXRlPdamekrfEldkArgT");
    double jtNLEhHNqQJq = 314896.30800918903;

    return jtNLEhHNqQJq;
}

string apWwnwSgaV::vvdpSZjl()
{
    int XOZjKVIsbCToSP = 222227907;

    if (XOZjKVIsbCToSP == 222227907) {
        for (int mAJeKCLvtpwnDGp = 1631224325; mAJeKCLvtpwnDGp > 0; mAJeKCLvtpwnDGp--) {
            XOZjKVIsbCToSP += XOZjKVIsbCToSP;
            XOZjKVIsbCToSP /= XOZjKVIsbCToSP;
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
            XOZjKVIsbCToSP += XOZjKVIsbCToSP;
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
        }
    }

    if (XOZjKVIsbCToSP <= 222227907) {
        for (int XITMbUPLECM = 1519340493; XITMbUPLECM > 0; XITMbUPLECM--) {
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
            XOZjKVIsbCToSP += XOZjKVIsbCToSP;
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
            XOZjKVIsbCToSP += XOZjKVIsbCToSP;
        }
    }

    if (XOZjKVIsbCToSP >= 222227907) {
        for (int PAXMvXj = 1725764826; PAXMvXj > 0; PAXMvXj--) {
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
            XOZjKVIsbCToSP *= XOZjKVIsbCToSP;
            XOZjKVIsbCToSP -= XOZjKVIsbCToSP;
        }
    }

    if (XOZjKVIsbCToSP < 222227907) {
        for (int apjnPOQAWxOI = 419034469; apjnPOQAWxOI > 0; apjnPOQAWxOI--) {
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
            XOZjKVIsbCToSP -= XOZjKVIsbCToSP;
            XOZjKVIsbCToSP *= XOZjKVIsbCToSP;
            XOZjKVIsbCToSP -= XOZjKVIsbCToSP;
            XOZjKVIsbCToSP *= XOZjKVIsbCToSP;
        }
    }

    if (XOZjKVIsbCToSP != 222227907) {
        for (int eXlbZXfWhENYfJ = 319974660; eXlbZXfWhENYfJ > 0; eXlbZXfWhENYfJ--) {
            XOZjKVIsbCToSP -= XOZjKVIsbCToSP;
            XOZjKVIsbCToSP = XOZjKVIsbCToSP;
            XOZjKVIsbCToSP *= XOZjKVIsbCToSP;
        }
    }

    return string("ClpLKNOizOidjLVKnfckGqrUykDYiMUXiesFaDJrDLRJdHDlsDdPdwZLciRRfBzjrLAdmGGcGAWFRcKQGwcSdUWIiWfSOYcnlPAppzSaCaAneuCjpMcfuqaoVHhmrpPPbSWiEIRLFMKYcSWDHbxJTRZCpMKYvEWelRyjxTYHNqpKfuKtyvpoHEEagdaiKFeqYtTOcgOSKtZhrtRbtFBBqEDSFKSKOKQ");
}

double apWwnwSgaV::TpzNueIB(string ftdBM, string mhRZqoTWPQsh)
{
    int PZmHhGD = -2025665801;
    bool uPfnpBHcuBZ = false;
    bool PNeTPvWCe = false;
    bool avbdHnTLHFfzh = true;
    double LYzyYaBoaj = 546313.4127366074;
    double KqhTOEmWeGEwCxDm = -972826.5059610027;
    int hVjhdgym = 353111353;

    return KqhTOEmWeGEwCxDm;
}

double apWwnwSgaV::AXMQVwcTPwK(string RJctWXvwH, int lsbpJB, double EDehmKO, int agESXsPDVkYx)
{
    string WBPvMvqbpxlDww = string("ZJiLnqgSeRJDSVvHOqaXubPHrnjscXKFiuTTbyuqPGLcBDeGjQVJIODJPCYdzPPwoYjfGUoJFDYSbDmiBVZnuoezvrrL");
    double exdcBUTIVCUyVp = -619969.5410884822;
    bool QgdUVPE = false;

    if (EDehmKO < -619969.5410884822) {
        for (int jMIZPeZTnJ = 777214952; jMIZPeZTnJ > 0; jMIZPeZTnJ--) {
            RJctWXvwH = RJctWXvwH;
            WBPvMvqbpxlDww += RJctWXvwH;
        }
    }

    return exdcBUTIVCUyVp;
}

bool apWwnwSgaV::GrEfXUO(int mQlHHwNumWZLDWwS, string dpopaTXTejEnpGWE)
{
    string qaIqEC = string("ePzTVMrCFTVVITZWicIVDHoBBBcoklQCQbWFnVjKzPgKusXRywOopsPRPIbMswGDEVNjkMlTAoDfaAfhbLNTNAlItGxpFjuwIClQQALSfgSyGvoBtRVOjTp");
    string oTgIqWqjitp = string("pjGDiOzKTRBSdnXavIMlcaTvBwTAmOoQZcNefxpXKEGKLiLkZOLOFfwsDd");
    double vDOoZVgjbkS = 678311.2845579755;

    if (qaIqEC == string("ePzTVMrCFTVVITZWicIVDHoBBBcoklQCQbWFnVjKzPgKusXRywOopsPRPIbMswGDEVNjkMlTAoDfaAfhbLNTNAlItGxpFjuwIClQQALSfgSyGvoBtRVOjTp")) {
        for (int HmVFFISjSoV = 1321197986; HmVFFISjSoV > 0; HmVFFISjSoV--) {
            dpopaTXTejEnpGWE = dpopaTXTejEnpGWE;
        }
    }

    for (int JRYSLEkl = 175083318; JRYSLEkl > 0; JRYSLEkl--) {
        continue;
    }

    return true;
}

void apWwnwSgaV::hOUVihJI(string bIgUMtKBCgjU, int qEYHCwkzfkZ, double eEjiaJSk)
{
    string qRomVxHJZyXgilhh = string("SRzaFzlYcVVqxHGIi");
    string NlNyuCc = string("YjkAiZkknIbDojnXcXKgFIgHRWXGgjOGPrLptKDobNyARBgopicLPSCDEBFffvTyOaB");
    int hmVzfYQ = -1762257180;

    for (int mKMIeNQhQPzs = 1859195857; mKMIeNQhQPzs > 0; mKMIeNQhQPzs--) {
        bIgUMtKBCgjU = qRomVxHJZyXgilhh;
        qEYHCwkzfkZ = qEYHCwkzfkZ;
    }

    for (int xCghg = 200126993; xCghg > 0; xCghg--) {
        NlNyuCc = qRomVxHJZyXgilhh;
        NlNyuCc += qRomVxHJZyXgilhh;
        NlNyuCc += NlNyuCc;
        eEjiaJSk -= eEjiaJSk;
    }
}

double apWwnwSgaV::xXIVldLIio(string JcjuUkSwGxFdDt, double PvjPMGXjHmwIP, int SolCVjkH, string AMFjiYJldRBN)
{
    double HLoUJhsmUWrEIVWY = -306607.478326451;

    if (PvjPMGXjHmwIP != -306607.478326451) {
        for (int JDDJwiE = 1795359238; JDDJwiE > 0; JDDJwiE--) {
            JcjuUkSwGxFdDt += AMFjiYJldRBN;
            JcjuUkSwGxFdDt += AMFjiYJldRBN;
            HLoUJhsmUWrEIVWY *= PvjPMGXjHmwIP;
        }
    }

    if (JcjuUkSwGxFdDt < string("sukYpKVBAsxeAdqqsUOwOcsZDwREbUYXszmLOrIsSHbpbfPYHAwLtnREImzzCewADAsjRYUmPRutqtAsbJcsVLNieNRmItR")) {
        for (int vdeEIQDjfbxMTCD = 2082863643; vdeEIQDjfbxMTCD > 0; vdeEIQDjfbxMTCD--) {
            PvjPMGXjHmwIP = HLoUJhsmUWrEIVWY;
        }
    }

    return HLoUJhsmUWrEIVWY;
}

double apWwnwSgaV::CwbVRVoqaxdr()
{
    double OSSQvZ = 1024267.3348015366;
    double xpnHAgFrS = 401783.62618068256;
    string VOIjTHZOTgbgtt = string("gvoHnBKjsixQZzMmyzUhmoiIMTkonaORSWwQorDspLSnDLcbZklnLrbUSejaQauDtabtiWEdGDAdnDJuTdyofNeaTZaAfFHJkxJLzdFqvPHZiLTLESjTIvQSP");

    for (int EUZbhKsBIDs = 1027080654; EUZbhKsBIDs > 0; EUZbhKsBIDs--) {
        xpnHAgFrS *= xpnHAgFrS;
        VOIjTHZOTgbgtt += VOIjTHZOTgbgtt;
        xpnHAgFrS -= xpnHAgFrS;
        xpnHAgFrS -= xpnHAgFrS;
    }

    if (xpnHAgFrS >= 401783.62618068256) {
        for (int OHOVzCPpsomx = 1003739290; OHOVzCPpsomx > 0; OHOVzCPpsomx--) {
            VOIjTHZOTgbgtt += VOIjTHZOTgbgtt;
            xpnHAgFrS += OSSQvZ;
            xpnHAgFrS *= xpnHAgFrS;
        }
    }

    return xpnHAgFrS;
}

apWwnwSgaV::apWwnwSgaV()
{
    this->jwjBUDPp(string("VZlotHVbJvxSBIcrYTEMbkppmPnQdpBPvUolTQAQRHoOOjWsQNYiJdXWWtVALtQzNsKlTMlHbLZZSQJRSFriOqwYiGPQnOvNAZBbcWSbuXhvmJFXOWwSgjcXKzoWpEjdoVSWYDDkiKEziXfULJYeEXqQwhOjrmqNYssRCTyUbVMdhsniUxqMgFDJyIIbDnjlbKeUOvKUIEwdJaOqlQLQpfSBK"));
    this->VkDkuVDskU(460951.9365139184, string("wGztcnUwKPfSjtBLdNibtjwFzNkekCd"));
    this->vvdpSZjl();
    this->TpzNueIB(string("OSEvgdILTEQzjXeurHxydxXNnSrdSovevdcqmHILDKDBbthEBsISNwQEcKehosVfvPKorxKQtwlSaPQuOKERIYcljPyArcanZvYiZZUXQpLbfEevPfEcxMokIZdWHDyDOxTlVnRljHnUNRmaqgcQBeEbljADUKYspuBKg"), string("SfZGjNQLGTNSnecPykBzPBTriYZVoEIevOkhlVDqZrcSeZzVPvjoEYuYSsZGHEVtiChmxZuclPmnLIKpmTxjOOHJiTyoenmMXAbIZiDVDsJaEXkiHJTAQMDuBxgKTCxPJyoxtGKLPKhrjueJKhrqyIwWiKnEwapDiDcRuIYdfidAcgGKBhhdhrQAD"));
    this->AXMQVwcTPwK(string("eAYsvbuwPGMSkXkSbQEuQVGVKCuYSuEjhgDPnOBQRZiPwnwCiCruOESEfUTrNZsSWDrlwOfSGkzwgepCVkSQrykgmhmUsNTmnaagTNZmWQiMqVtQlotdpKSHAygCQr"), 1051217324, 308795.16168560146, -891147677);
    this->GrEfXUO(-131419786, string("ZNWRloFYTTJaLvHpYgXWDMzwqTtrmBPzxrVEnKhMJLMzBbHGDfrtyWsSmHZgULOPTVevgTWyWxGmtxSztmJIqPjQEpcOqekwDVabMdIXSSPdJshdfotwpSJnHvqqcP"));
    this->hOUVihJI(string("gIUFVCysNdgytRfjQAxpFtGhnYjWdQMWQmjVeroydDyGBKgQxtbStOEdEEUBCiBRMtrtRktHzpjaWPByaQUnjkLxdtvgGjqnniHxIZOiNEQZGssHBVGuEJJLEDFrgJaPdTDwOI"), -635781362, 860240.2431780732);
    this->xXIVldLIio(string("sukYpKVBAsxeAdqqsUOwOcsZDwREbUYXszmLOrIsSHbpbfPYHAwLtnREImzzCewADAsjRYUmPRutqtAsbJcsVLNieNRmItR"), -139284.40436591182, -1259822827, string("kQSqQdzlThwjAUoWyNytfFwZwlSTEmjIYVpIDFOqYIfxbLOiwuCnPNzSHOVYMJbkPtlCiPzLhUJfPNjIahkyRJJfbDQhSkfVlQQlCSAnkBKYuHmCeyWmksfWRavshzrkWFkaXaDZjuwEenxLJkNiCDAkOcUUmraHbsGXBuIHuxTRF"));
    this->CwbVRVoqaxdr();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wWiBZpEHk
{
public:
    bool kxwiVsYSExaJYnW;

    wWiBZpEHk();
protected:
    string mvxrcGQlrISADP;
    string fvChiqFjVkcIwXcX;
    string OCaWzGu;
    double INiifuTNZ;

    void zxKtAlYtucsq(int BnGsyFZ);
    int tViHPAeqCAkW(int UstBeZVOOLoobuBn);
    int fGLASUOxWJDuBtxL(int SYGFZeVxzLBOGew, bool UMHnjiEYCbRCM, bool ZariaDy, bool PDepqaImdVumT);
    bool SBjUrAxmGU(int OVNIgbETFHd, bool SzwtAuBNBWCXAuoK, int STvBqWvUgb, int YcNZJVSgjdjyjK);
    double BwVab();
    bool neLwhRcag(string wvsKKSHLzKNpR, bool idmThGecODfT, double XQaJI, int TNIxpcajdNVZZS);
    void dnqqmKJGVS(bool SZcfCFWcEz, bool ryYCeX, double chBoHgFQc);
    string vLWXNb(double GtMrGheXuki);
private:
    int srNXVeyMy;

    double RTEbFYwzlwhWsIvB(bool tZNVAuGVXsLB, int OCOjIJ);
    double dBlywua(bool JfRAnuk, string iznFxymXKdoCu, double jlhMbrZyZFHAbCf, bool clLjZbREK, string pAEGRDxo);
};

void wWiBZpEHk::zxKtAlYtucsq(int BnGsyFZ)
{
    string WxiNha = string("LXAouKNTtJxXIq");
    int TMMQHiXOfwOjv = 925741866;
    double dhEHLfCF = -702954.0888104481;
    int SIMTomSGmiNe = 1352062405;
    string BdqxSRkMrjrJ = string("ZUBgIGuUXqmjhiXtPTDTKUrURGrTSHSaBTwxoxibWpBugzOnSYxpnGlGpivJkugglbYEZdbuKHcKYblzgUjVLbhylUaVljeLPoGsSyoERAENDORxPikRqCtJwLVSxfrwfmrUYSYTcbbLQaMRKXFsDojcXIQJamISaLYVkQSSyGYarKEyVnE");
    string oWQYZrXABw = string("JOFxeIcySnxUhyoBiPpcjPyQQNTzSGIYYMHuKZqItHIneyofsQQtnyCMVxechozQahnrKrueDjsNcJRsoxmmchoIobVZHSzGeDfGJYkPOkROFVVKnSIRkrJfIpdvGBZOgrxJGoPPOaGKd");

    if (BnGsyFZ > 1352062405) {
        for (int KQZYaVECBTkbK = 826756873; KQZYaVECBTkbK > 0; KQZYaVECBTkbK--) {
            oWQYZrXABw = WxiNha;
            WxiNha += WxiNha;
        }
    }
}

int wWiBZpEHk::tViHPAeqCAkW(int UstBeZVOOLoobuBn)
{
    bool sRobe = false;

    for (int tKBMr = 1249385282; tKBMr > 0; tKBMr--) {
        sRobe = sRobe;
        sRobe = sRobe;
    }

    if (sRobe != false) {
        for (int zfaYUbdX = 1134949053; zfaYUbdX > 0; zfaYUbdX--) {
            sRobe = ! sRobe;
            sRobe = ! sRobe;
            UstBeZVOOLoobuBn += UstBeZVOOLoobuBn;
        }
    }

    if (sRobe != false) {
        for (int qVReafwydS = 1124766368; qVReafwydS > 0; qVReafwydS--) {
            UstBeZVOOLoobuBn += UstBeZVOOLoobuBn;
            UstBeZVOOLoobuBn -= UstBeZVOOLoobuBn;
            sRobe = ! sRobe;
            UstBeZVOOLoobuBn /= UstBeZVOOLoobuBn;
            UstBeZVOOLoobuBn -= UstBeZVOOLoobuBn;
            sRobe = ! sRobe;
            sRobe = sRobe;
        }
    }

    return UstBeZVOOLoobuBn;
}

int wWiBZpEHk::fGLASUOxWJDuBtxL(int SYGFZeVxzLBOGew, bool UMHnjiEYCbRCM, bool ZariaDy, bool PDepqaImdVumT)
{
    double VFgYhOClKj = 555724.0019437408;

    if (PDepqaImdVumT == true) {
        for (int izfNtRoSWFexK = 2026008270; izfNtRoSWFexK > 0; izfNtRoSWFexK--) {
            UMHnjiEYCbRCM = ! PDepqaImdVumT;
            ZariaDy = ! PDepqaImdVumT;
            UMHnjiEYCbRCM = ! PDepqaImdVumT;
        }
    }

    for (int AndjmReAZtOCGzJP = 935252922; AndjmReAZtOCGzJP > 0; AndjmReAZtOCGzJP--) {
        VFgYhOClKj -= VFgYhOClKj;
        UMHnjiEYCbRCM = ! PDepqaImdVumT;
    }

    return SYGFZeVxzLBOGew;
}

bool wWiBZpEHk::SBjUrAxmGU(int OVNIgbETFHd, bool SzwtAuBNBWCXAuoK, int STvBqWvUgb, int YcNZJVSgjdjyjK)
{
    string UqTSyPsGzrSqJzY = string("qZyfsztjvCPXyILrxChAtjLkOapiEJQDQzwTKLLxbYzNtckifIxDQNhDgWpMQTvOXDhLYOfIqWWyXsMtBUXyZmrhrotXKoBNwAIYfRURNyCddYLaccsoQaKXpfznWFvrxLssniVkaRNFQPPSdSqEEFrDJbvMInJjXeElAMrZBByfWOth");
    bool XFdRtKMLLOL = true;
    double BJNUSGhDMwZVGQq = -279310.0744382868;
    int EdWylvymvGI = 229733017;
    int dAeDQVnCMkLMAU = -187271248;
    string GPCSnkFxzEHgx = string("mrFuLBHpOjuSkTcdIacAAoSzjMFkVBPJcPLCplPfeAnQPrHgTbqcITLGqrSQwGmVdiCHLnealGRuCbhIiAeZUmjxsMGWzqDAKReeCctDoTHMnRYEQzbQDkPUnHrcQALGysxdfEGxNXwfvuUtHbFnhUtfwHXXaVsaGTILYZCQcOcEmjZPZCWNhBzmxEIaXCJEMrTNUidMYJIXtBvpOnJOcQxZfGnVTwxLlXUeJpTiHNhyFIuuvTSSKWZ");
    string pEAuwHnayHiDnI = string("dTmSjEdaBvlttaUhfvPNuHcjivurZDMxjjwZKNvXTizQHGsYkjuXBNpExxpsnMrChLYWpvyuwwwsvAGmpuXdgOyxZPQFiQrEttPu");
    bool SJLVqJOQgZahJmT = true;

    for (int LswZpAVjYTKWGNUu = 1466104850; LswZpAVjYTKWGNUu > 0; LswZpAVjYTKWGNUu--) {
        SzwtAuBNBWCXAuoK = SJLVqJOQgZahJmT;
        EdWylvymvGI = OVNIgbETFHd;
        SzwtAuBNBWCXAuoK = ! SzwtAuBNBWCXAuoK;
    }

    return SJLVqJOQgZahJmT;
}

double wWiBZpEHk::BwVab()
{
    bool gcibnDNMCFb = false;

    if (gcibnDNMCFb != false) {
        for (int hNWDSINsqKXexZWx = 768813010; hNWDSINsqKXexZWx > 0; hNWDSINsqKXexZWx--) {
            gcibnDNMCFb = gcibnDNMCFb;
            gcibnDNMCFb = gcibnDNMCFb;
            gcibnDNMCFb = ! gcibnDNMCFb;
            gcibnDNMCFb = gcibnDNMCFb;
            gcibnDNMCFb = gcibnDNMCFb;
            gcibnDNMCFb = gcibnDNMCFb;
        }
    }

    return 440151.85851326084;
}

bool wWiBZpEHk::neLwhRcag(string wvsKKSHLzKNpR, bool idmThGecODfT, double XQaJI, int TNIxpcajdNVZZS)
{
    bool LySYxDMtQvppjDV = true;
    string RxEvJhUGyPMWXWp = string("SVWHliUqbCuxPCeCbDygFVTylUHopfrCjGwBmSGFckgBCmhQIbCLQHWYRCeBYtUtuVBYvRiWMLkDeLFYPUADKQMNgJMGJWNHjtKPngqqmssVofovsPFWIisMEzJQiCRsNadvdzQPMHWTqFMDcMbTlsULtmXfNBfQxOUVQfvEGWnNHJtyWpjXOhZiXUSsDFOalBYJVZKfSr");
    double iZEBcnTYO = -231068.52972187643;
    string QVlty = string("wmBzYhhSmNBZiASSndBiNOfmVoSWDOigmLRNfdmGWhAozAKSMNXOBUbESvQRdtMKTKJqydQKyuZTmKptuZrVpXkODGCbTjevsTsVJ");

    for (int sPmsFSEPXj = 816503075; sPmsFSEPXj > 0; sPmsFSEPXj--) {
        LySYxDMtQvppjDV = LySYxDMtQvppjDV;
    }

    for (int hRfavd = 1258870078; hRfavd > 0; hRfavd--) {
        LySYxDMtQvppjDV = LySYxDMtQvppjDV;
        XQaJI -= XQaJI;
    }

    if (TNIxpcajdNVZZS >= -1885830771) {
        for (int JerImQufLcw = 157414490; JerImQufLcw > 0; JerImQufLcw--) {
            RxEvJhUGyPMWXWp += QVlty;
            wvsKKSHLzKNpR = wvsKKSHLzKNpR;
            XQaJI += XQaJI;
        }
    }

    for (int bOkqXAIECxaHqzSx = 132912014; bOkqXAIECxaHqzSx > 0; bOkqXAIECxaHqzSx--) {
        QVlty += wvsKKSHLzKNpR;
        LySYxDMtQvppjDV = ! LySYxDMtQvppjDV;
    }

    if (idmThGecODfT == true) {
        for (int LShglRSpgIk = 784573585; LShglRSpgIk > 0; LShglRSpgIk--) {
            idmThGecODfT = ! LySYxDMtQvppjDV;
            wvsKKSHLzKNpR += RxEvJhUGyPMWXWp;
            LySYxDMtQvppjDV = ! idmThGecODfT;
        }
    }

    return LySYxDMtQvppjDV;
}

void wWiBZpEHk::dnqqmKJGVS(bool SZcfCFWcEz, bool ryYCeX, double chBoHgFQc)
{
    int MTqNPb = -633492418;
    string OnJZapQaLn = string("gAOuBeqUuWtohcLDcYalFWioPhpTwyDPatqFJYQhaikROykZxurWwYzpdUJyrTEpTAgnJRqHYVPDIRyktHevDcmwurVgLsEbQhkXccewUatssJGUYVllNWNduqmfoHTQEJTprrNexsAqRIVUZxwBpeDwrCVUpoHWjDnFmcKbuyLPCL");
    double KONcy = -132758.92026643018;
    double WbWvALxusOrjo = 1024137.0065943864;

    if (WbWvALxusOrjo <= 1024137.0065943864) {
        for (int AnldXghM = 1028436108; AnldXghM > 0; AnldXghM--) {
            KONcy /= chBoHgFQc;
        }
    }
}

string wWiBZpEHk::vLWXNb(double GtMrGheXuki)
{
    string UCLArrjloNCJoX = string("uJNNgujIsgKqKDxjPTTLxn");

    for (int awuHEuaRQJMPKzKF = 2003671257; awuHEuaRQJMPKzKF > 0; awuHEuaRQJMPKzKF--) {
        UCLArrjloNCJoX = UCLArrjloNCJoX;
    }

    if (GtMrGheXuki < -237611.15298279887) {
        for (int KkyNxVB = 730317114; KkyNxVB > 0; KkyNxVB--) {
            UCLArrjloNCJoX = UCLArrjloNCJoX;
            GtMrGheXuki *= GtMrGheXuki;
        }
    }

    if (UCLArrjloNCJoX != string("uJNNgujIsgKqKDxjPTTLxn")) {
        for (int MMrcFEOslruqxMBG = 1365908453; MMrcFEOslruqxMBG > 0; MMrcFEOslruqxMBG--) {
            continue;
        }
    }

    return UCLArrjloNCJoX;
}

double wWiBZpEHk::RTEbFYwzlwhWsIvB(bool tZNVAuGVXsLB, int OCOjIJ)
{
    double BwJjpLBhQ = 165824.45521178583;
    double UNQApIgnp = 687944.2516509063;
    string DsSxII = string("CgbkeThlPNeVeSbExjPqUXUAMVxoZYeDMxvjWZVwuUxZFfzUDYRqdGwedtwgFXyzCGSAdeijhaDaAOEanMGyUuxhvueTgVQZKahNxWBGVJacgaKkGMwYwfLGQIoYwvVeGTicXGOcuiBrxDVwFhWxrVGvNPBIHpHXDGpecCWQiuidvYZpbMxPLRIWeoifscrbJJWUbKKxLwZhCFNTMMTsoyrJuUxLHHAcNA");
    double SQGQzdFHpBLHqH = 233440.9124125284;

    for (int RlHjbTF = 1314062256; RlHjbTF > 0; RlHjbTF--) {
        tZNVAuGVXsLB = ! tZNVAuGVXsLB;
    }

    if (BwJjpLBhQ > 233440.9124125284) {
        for (int bobdYlu = 1480913738; bobdYlu > 0; bobdYlu--) {
            DsSxII = DsSxII;
        }
    }

    for (int MSgTlvmVYzZre = 1044339262; MSgTlvmVYzZre > 0; MSgTlvmVYzZre--) {
        BwJjpLBhQ /= BwJjpLBhQ;
        BwJjpLBhQ /= BwJjpLBhQ;
        tZNVAuGVXsLB = ! tZNVAuGVXsLB;
    }

    for (int jwmADc = 359630340; jwmADc > 0; jwmADc--) {
        continue;
    }

    return SQGQzdFHpBLHqH;
}

double wWiBZpEHk::dBlywua(bool JfRAnuk, string iznFxymXKdoCu, double jlhMbrZyZFHAbCf, bool clLjZbREK, string pAEGRDxo)
{
    bool GMqQBKjQEkl = false;
    double LUvgzqnCrAb = -946626.2704542782;
    double ytXuAvgH = 749743.8962875569;
    int wEMso = -1494612219;
    double RQgyHdn = -1048044.9397094552;
    string wOggOzeXgwoPbXUv = string("bwLIMoFNymVAWqzhEaEjSYTtFjJJRqzscngECwkmVuFuQkDFSYtPPCzjtOlqOngGsGnNVHdwOSiYOwuXqrDexoqYuthLiTQeOxoncYQnZvFmLNwtSbpecZhOHUMFttObhitIHdCFUvSJVpULPlhMWN");

    for (int SlqrKubDfLq = 1657852200; SlqrKubDfLq > 0; SlqrKubDfLq--) {
        continue;
    }

    for (int MuPdYhOQnt = 405246148; MuPdYhOQnt > 0; MuPdYhOQnt--) {
        jlhMbrZyZFHAbCf += ytXuAvgH;
        GMqQBKjQEkl = ! GMqQBKjQEkl;
    }

    if (pAEGRDxo > string("VACmmxbMSKpWAftIuiTHuZyAEnVKLRSCIfRtJBzWxNifWbdzYgrFmNcfDPliKjwSdNyBBknJzDphRxyQftdYDAOBNGMjzGPSBlNvaSfMWeuLVHvGSMEgNTLZiMtsODEvsaedEfMhPESrxlZhAZkpjvihHJfOqcsgjyOydDJlRWWrlSWqvRxHQTznHToHhFZUqhDqbEbZOJxcEDhxaOcRARQSFIqlcnbHCxOLwEkij")) {
        for (int LYgEB = 1910524164; LYgEB > 0; LYgEB--) {
            jlhMbrZyZFHAbCf += LUvgzqnCrAb;
            wOggOzeXgwoPbXUv += wOggOzeXgwoPbXUv;
            pAEGRDxo += iznFxymXKdoCu;
            JfRAnuk = clLjZbREK;
        }
    }

    for (int wUmtnHZBGg = 199894156; wUmtnHZBGg > 0; wUmtnHZBGg--) {
        iznFxymXKdoCu = pAEGRDxo;
        jlhMbrZyZFHAbCf *= ytXuAvgH;
        RQgyHdn += LUvgzqnCrAb;
    }

    for (int uOBBJrIJhMCxIFm = 266871164; uOBBJrIJhMCxIFm > 0; uOBBJrIJhMCxIFm--) {
        wEMso /= wEMso;
    }

    return RQgyHdn;
}

wWiBZpEHk::wWiBZpEHk()
{
    this->zxKtAlYtucsq(-1389121134);
    this->tViHPAeqCAkW(-527984572);
    this->fGLASUOxWJDuBtxL(622730619, false, false, true);
    this->SBjUrAxmGU(-436314631, false, 1216172700, 431119971);
    this->BwVab();
    this->neLwhRcag(string("KrYPmQWoxMkVnAuhVVXACWZaumlNsvhthvWYNCxIodvRXvaynWLjAolpe"), true, -631888.9149482598, -1885830771);
    this->dnqqmKJGVS(true, false, 1025366.8230689573);
    this->vLWXNb(-237611.15298279887);
    this->RTEbFYwzlwhWsIvB(false, 92629149);
    this->dBlywua(true, string("WLeVdQsbfwHxDUpxyYedYTqsTZbEjIEARNjxgbExeEuPpQmsjbfUItIkviecJGaUaaXzTWcwHSMqKtIiEkqhAiZFrrJmjhvdwIfBGlrigTsbMYXwmiGxvoqyIriYGrMulOGLQwPVskYqlNQmilBFqgYGGCpOHbytA"), -987199.7411361954, true, string("VACmmxbMSKpWAftIuiTHuZyAEnVKLRSCIfRtJBzWxNifWbdzYgrFmNcfDPliKjwSdNyBBknJzDphRxyQftdYDAOBNGMjzGPSBlNvaSfMWeuLVHvGSMEgNTLZiMtsODEvsaedEfMhPESrxlZhAZkpjvihHJfOqcsgjyOydDJlRWWrlSWqvRxHQTznHToHhFZUqhDqbEbZOJxcEDhxaOcRARQSFIqlcnbHCxOLwEkij"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mrkpuPZQBKH
{
public:
    int gLSmtCBP;
    int jMToT;
    string wlOsCDfk;

    mrkpuPZQBKH();
    double orgdViMKNWLqhMn(double csGRhZOkiDrZX, bool CoJHmiBNLZj, int SxmQPfdZNbq, bool OOcooy);
    void xyBUoTqAkFzM(double MSrbKxUKmbn, double kmEXKQceEL, double dfGoEGQom, double kjXCHcRVvbQgdJ, bool kklIL);
    void kwvVQMvkYIkMd(bool RpIvOohLmVeqBFg, string YIpXrZ, int QrVDvoaxrJBY, bool gCDGEnFMGOvdP);
    int ULncvb(int gdnJgF, int LBiqDcTO);
    bool rDanJzferJRHT(bool nKnuu, bool PFfADH, int AzoJjoVzp, bool WGeseiXTrhx, int BOBXBl);
protected:
    string vQnXsuTenJJf;

    string ZFMcnz(bool mrDgxuN);
    bool FwQMAVGiwCEczi(double kZTFGjOO);
    bool qftONh(int bTyNxRZFGbiUsjiH, double gJzOUbaYuSzACp, double qYRSU);
private:
    int XqGzVkJUUXV;
    int yJOkJhY;
    string LuvqEdolA;

    int uEhjcML(bool XYjxtch);
    int pnUoEAj(bool EfpRni);
    bool xWIIRoaYJheLt(bool gjBSYY, int mdHipfhSalywcH);
};

double mrkpuPZQBKH::orgdViMKNWLqhMn(double csGRhZOkiDrZX, bool CoJHmiBNLZj, int SxmQPfdZNbq, bool OOcooy)
{
    double qIZmTTZloYDO = 470924.31668203586;
    double blzqGvWLe = -452365.9066586193;
    int kZaYKFn = 1886520549;
    int CKNaVDfgkK = 731907835;
    string DJCNTfQLIRuEazX = string("XgFsXwKqWblDkVbwJCgOZjwyUaT");
    string iQScW = string("yMyBMSvdBPdxcSJwmMCqoAFqvvsCJFBQKJYXcEJkwZZMrEFhCibKcvWQbkCYlaroILIzWtbiCqUStvgqedXpoGvupkPzEuTByORslsJOtHXgqpezIQkoPFxHVgMiGEYflBjJIScsvojGFlRpOdEArvhsPJvRTnorLjIccgdfPdUBgIBftCRjuOzMCacWcNTNEBMBJPPkryXiXaAKqciVKkjAAzGubdTbTTA");
    bool rvJDCdZZjIIsdIk = false;
    string SqAudSgBG = string("eQJAlicZtvkTPdcjZvkuTfQIlYTwVYVJTqyTRnaWaLCUbSOYBwSYovMIXHlCsoBMLxlXYGwojaedPXDpAdvGwCgiIrvFEubIGbCOQTTHNKeEtvUhfuWBJwvlVWEBpnkSNezbDvjT");
    string cKLVQ = string("wtKdJLdhESeaSYXUZaimoQzjPwMdCWShWigDLaZJtItXDKCRWCFYLeCfdmSSFFofDHiAGGEPQvnnpJNtOoDAQCvilyROYFMAFa");
    int eqjQhlti = -1508199343;

    for (int TppYrbZrdYWec = 1494510316; TppYrbZrdYWec > 0; TppYrbZrdYWec--) {
        continue;
    }

    for (int DbLGfqrpaTZwpsxR = 1917094737; DbLGfqrpaTZwpsxR > 0; DbLGfqrpaTZwpsxR--) {
        eqjQhlti *= eqjQhlti;
    }

    return blzqGvWLe;
}

void mrkpuPZQBKH::xyBUoTqAkFzM(double MSrbKxUKmbn, double kmEXKQceEL, double dfGoEGQom, double kjXCHcRVvbQgdJ, bool kklIL)
{
    double BFbpfBS = -577449.3926488997;
    string zJgWfuxoxLL = string("FoXZhhNzkxMStIsNAILOJomldZcLCybDsKSZzESHVRXqUsvGrSHZQmLrDVCREtYDwxKhitvczmnZbVMnhnpeDxVDDfwNcNJyxvYWzzGEgXeJiaYJfRcLgVvgrrtOBUVYLnxuDkDdWBdNYTBqhuuZZTcArmYPpRmFnTZYfkWjCdiwLNAvsGAGMPXXSkESgIXYlTKKpTZTTnNMTYcizxfddnkUxglrpgaZCJSjCpE");
    double zmmjVjbzcb = -86989.12307015098;
    int cmZGiQXNJQvMPsf = -581180349;
    int gRAjMLfrdJRXWcyn = -1962985760;
    double ldSErpXfbtJgZzC = -946838.913686943;
    double mNkHvllglxhEjN = -548470.1633558379;
    string EAqGWS = string("OTvRMPEkIGBNNjtoBWIcCOyHqJoAfVtvGdKLUsirOUXfGhZkBzPQKScTKcWMYBGGyJECRmBmfzFCyhGEsYEkhCzIEvHrWOwYTKgBDrXkFMhhnwqWsMNUXLiVKoujAxzncvDHrxiYRCckNjEoYeLqJgzsEpKHClzIAUtNFGJLWPjZLqvIAzvD");
    int pDctpSRKSoJ = 1271961993;
    double ChpIcDjhnDIbRouL = 75288.30637073486;

    for (int DLzwtxARl = 1081277109; DLzwtxARl > 0; DLzwtxARl--) {
        BFbpfBS *= ChpIcDjhnDIbRouL;
        ldSErpXfbtJgZzC *= dfGoEGQom;
        dfGoEGQom /= kjXCHcRVvbQgdJ;
        MSrbKxUKmbn += kjXCHcRVvbQgdJ;
    }

    for (int cvoEFNdz = 916658426; cvoEFNdz > 0; cvoEFNdz--) {
        continue;
    }

    for (int mFtiMyQvewQOtw = 1762693501; mFtiMyQvewQOtw > 0; mFtiMyQvewQOtw--) {
        continue;
    }

    if (ldSErpXfbtJgZzC != 710331.372179032) {
        for (int ikjvjY = 913800059; ikjvjY > 0; ikjvjY--) {
            ChpIcDjhnDIbRouL *= mNkHvllglxhEjN;
        }
    }
}

void mrkpuPZQBKH::kwvVQMvkYIkMd(bool RpIvOohLmVeqBFg, string YIpXrZ, int QrVDvoaxrJBY, bool gCDGEnFMGOvdP)
{
    double pjxsT = -268063.3441496725;
    bool SbnreOuvCFSM = true;
    double gyVLdNJLZoKpWM = -619024.9787218911;
    int usgbh = -543868415;
    bool SyksfFFtBgWlWsSj = false;
    bool PBuHpKcYJbGU = true;
    string BQuZMKIVFGQumeI = string("QzJKauMFrUsofrLZcFnskzqQXCHnsIhVbqcZBYoYnubHHOSCIcUaHBLGfeMOJJQS");
    string NJJtpavWPbiP = string("dCLEGwMrMzBByOwxupuCciooeCyEXornDplyHNYUrgozOxJXMxFagwxmGZQRSRlQupezgEdbtVQvfmgleQMMSqhQjTQWNcEwiOsVrTytJeOeyzLiVDvqZCwnzcaOdJNVgbgFnQnnCUsFnBsnfrHUUluFZWTtJhfnDGifjchrbAvWAbuSRtbBWiczkuFGcfTCoyMibmEIjBoCthYqSSuSSajwnYZCmpuWjQfnvETsHuNRWTvhJdKkRxjWEHtoG");
    int UKgPeOMUR = -1065257982;

    for (int hUYWZrdEYXPLWUvl = 585616951; hUYWZrdEYXPLWUvl > 0; hUYWZrdEYXPLWUvl--) {
        UKgPeOMUR /= UKgPeOMUR;
        PBuHpKcYJbGU = gCDGEnFMGOvdP;
    }

    for (int fTuQtfldUfdNP = 1639283737; fTuQtfldUfdNP > 0; fTuQtfldUfdNP--) {
        gCDGEnFMGOvdP = ! RpIvOohLmVeqBFg;
        RpIvOohLmVeqBFg = SyksfFFtBgWlWsSj;
    }

    for (int eHkKiOWQEPcH = 1309890308; eHkKiOWQEPcH > 0; eHkKiOWQEPcH--) {
        SyksfFFtBgWlWsSj = SbnreOuvCFSM;
        YIpXrZ = NJJtpavWPbiP;
        RpIvOohLmVeqBFg = ! SyksfFFtBgWlWsSj;
        RpIvOohLmVeqBFg = ! PBuHpKcYJbGU;
    }

    if (gyVLdNJLZoKpWM > -268063.3441496725) {
        for (int cTKWtaso = 1208512625; cTKWtaso > 0; cTKWtaso--) {
            continue;
        }
    }

    if (QrVDvoaxrJBY >= -1418930002) {
        for (int sNYyxn = 1676116606; sNYyxn > 0; sNYyxn--) {
            PBuHpKcYJbGU = RpIvOohLmVeqBFg;
        }
    }

    for (int ZCQsTElBIgNem = 1996727338; ZCQsTElBIgNem > 0; ZCQsTElBIgNem--) {
        QrVDvoaxrJBY += usgbh;
        SyksfFFtBgWlWsSj = ! PBuHpKcYJbGU;
    }
}

int mrkpuPZQBKH::ULncvb(int gdnJgF, int LBiqDcTO)
{
    int TzKthfsrURfyuRO = -474078666;
    string gmxdiGQiIdiK = string("sGLWtdRJHukCouxNZzwazIRKaljOXiGcVrIREtWnFmIMMPyJtidMpBLdUDILxylZSQOILODiCMLCPmFfgBLzgrtLYggmxaiLhqVJahlSHJYbScmKzxJuSHbQKgKqqdvVCZbDvMvqulCywLkgPnOAzNLHCmxDb");
    double PbmFqYCqOwAIG = -322315.3328563447;
    double NPCwNEWzT = -673922.0133065619;
    bool OhqSxvfV = true;
    string BbGEVXjoYNFWc = string("oCaho");

    if (TzKthfsrURfyuRO > -1980936568) {
        for (int LMiYeGZMAezaAil = 967658180; LMiYeGZMAezaAil > 0; LMiYeGZMAezaAil--) {
            LBiqDcTO *= LBiqDcTO;
            TzKthfsrURfyuRO += gdnJgF;
        }
    }

    for (int ARQeMvYflz = 453735408; ARQeMvYflz > 0; ARQeMvYflz--) {
        LBiqDcTO -= gdnJgF;
    }

    for (int jJjWRZWUrbQO = 532458845; jJjWRZWUrbQO > 0; jJjWRZWUrbQO--) {
        continue;
    }

    for (int sEYdZWG = 68763261; sEYdZWG > 0; sEYdZWG--) {
        gdnJgF += gdnJgF;
        TzKthfsrURfyuRO -= gdnJgF;
    }

    return TzKthfsrURfyuRO;
}

bool mrkpuPZQBKH::rDanJzferJRHT(bool nKnuu, bool PFfADH, int AzoJjoVzp, bool WGeseiXTrhx, int BOBXBl)
{
    bool gMVGcTueAxr = false;
    string QUcGjieusV = string("CfkmMfyyoUortWOVJYOFgWyMbHgznRKFFHmFbButdlhIoqWFswRqsDelqwYaaUnzTONFeWQZBuzxOsZxQXqkJO");
    double sMnKkniTf = -318754.0303992356;
    string RAhDehzvCwB = string("JpaehoBVxGFgPONrwebpprREdrNRHbflbiYUdAWgZKvWCgYkeBOWyRujDlYKcxHLFYGVTvSLCfiRHDUdIvxmzfuRRhUDwaadrhHatuvtGecolxKEQOp");
    int AayYNY = 477048203;

    for (int TMZcOaaioYkMBZ = 720128079; TMZcOaaioYkMBZ > 0; TMZcOaaioYkMBZ--) {
        continue;
    }

    for (int NpmkW = 1434364350; NpmkW > 0; NpmkW--) {
        continue;
    }

    for (int AnaTdsBt = 779357892; AnaTdsBt > 0; AnaTdsBt--) {
        sMnKkniTf *= sMnKkniTf;
        PFfADH = ! nKnuu;
    }

    return gMVGcTueAxr;
}

string mrkpuPZQBKH::ZFMcnz(bool mrDgxuN)
{
    double jDJsYexQM = -995282.3747837401;
    bool VAzAZysXUXFPfK = true;
    double rAcDGRjciIcuZqw = 893246.6015237556;
    int WowzEZlnRWZ = 140635861;
    double FSOsrjDesZXp = 1023970.3154523246;
    int fziKuKEBrSPsLuul = -988648866;
    string teeEXeJKolvB = string("LmUrKiyxqAErwsyxwSNfwcHYkHbQZJaAZsTVyCeYCrtjnonxheQWYvREJhochgPwJafnTWfxoyZZbPOGgeNOnMuCzNBgPrwIcDhKKooANYNnAVzmYsGRzdvLuTqaxOqMNqbErgyvaszUAvqRLGWsKyScQBWKlOFCq");
    bool SPIajAi = true;

    for (int nCIckPzketSymSX = 29890075; nCIckPzketSymSX > 0; nCIckPzketSymSX--) {
        mrDgxuN = ! mrDgxuN;
        fziKuKEBrSPsLuul *= fziKuKEBrSPsLuul;
        SPIajAi = VAzAZysXUXFPfK;
    }

    for (int hKemE = 42647201; hKemE > 0; hKemE--) {
        SPIajAi = ! mrDgxuN;
        fziKuKEBrSPsLuul += WowzEZlnRWZ;
        rAcDGRjciIcuZqw = jDJsYexQM;
    }

    for (int YvZuPZhf = 701785348; YvZuPZhf > 0; YvZuPZhf--) {
        rAcDGRjciIcuZqw += FSOsrjDesZXp;
        mrDgxuN = SPIajAi;
    }

    return teeEXeJKolvB;
}

bool mrkpuPZQBKH::FwQMAVGiwCEczi(double kZTFGjOO)
{
    bool wiCcwqMqc = true;
    string RehSzaOTAVQycuJ = string("ODwZNfzMQdPhHEgpJsswjukYjOwbeDJPpZTSgBNCDWgbSBghNrTPCoXGZbnsJvkAJixOWjPartEEStyCtxFmhFTfstaKcUURZKuWkhEt");
    double AoHuplXZ = -620046.8374574833;
    int dlrRJyKg = 27890680;
    string upcJCGcT = string("qOxJpEIKVjMRjrEc");
    bool LFWobvMMkbJGwwpO = true;
    bool rLprTkWHYAJIlv = false;

    for (int rZLTVCtB = 292677873; rZLTVCtB > 0; rZLTVCtB--) {
        rLprTkWHYAJIlv = rLprTkWHYAJIlv;
    }

    for (int DFIstaUSfau = 135261517; DFIstaUSfau > 0; DFIstaUSfau--) {
        continue;
    }

    return rLprTkWHYAJIlv;
}

bool mrkpuPZQBKH::qftONh(int bTyNxRZFGbiUsjiH, double gJzOUbaYuSzACp, double qYRSU)
{
    bool vhDUfbIMrRAvFVM = true;
    string PooxLoZvVGJOdsVf = string("cAEJxDujFUYTPB");
    string NcKrOCmRPbmz = string("bwNqUfQrHLcgIQzYPgwjGosoJXdOEettqLdfoXGyWLiXavDilUAYydniDbHGGbzwkrIpXHhGNQh");
    int bVrJXJeoaPKt = 755920532;
    double ZHjqBrXrgGDyu = 57219.42964115661;
    int OXBwKRoTEoXsVnM = 1040935352;
    int egOQxSWrDRcARUpC = -1503744781;
    int yIgWZFWA = 1835833807;
    bool RwMEDk = true;

    for (int gEYCAiWsPxFpnAc = 1077878678; gEYCAiWsPxFpnAc > 0; gEYCAiWsPxFpnAc--) {
        qYRSU *= ZHjqBrXrgGDyu;
        RwMEDk = vhDUfbIMrRAvFVM;
        OXBwKRoTEoXsVnM += bVrJXJeoaPKt;
        ZHjqBrXrgGDyu = ZHjqBrXrgGDyu;
    }

    for (int EVxzWOSFTpMp = 1303599733; EVxzWOSFTpMp > 0; EVxzWOSFTpMp--) {
        continue;
    }

    return RwMEDk;
}

int mrkpuPZQBKH::uEhjcML(bool XYjxtch)
{
    int oodqAjcN = 888473778;

    for (int DbTIrTncym = 337635429; DbTIrTncym > 0; DbTIrTncym--) {
        XYjxtch = ! XYjxtch;
        XYjxtch = ! XYjxtch;
    }

    if (oodqAjcN < 888473778) {
        for (int BJShBaUuQEYeGPh = 1956355814; BJShBaUuQEYeGPh > 0; BJShBaUuQEYeGPh--) {
            XYjxtch = ! XYjxtch;
            XYjxtch = XYjxtch;
        }
    }

    for (int EHeoHTO = 749016750; EHeoHTO > 0; EHeoHTO--) {
        XYjxtch = XYjxtch;
    }

    return oodqAjcN;
}

int mrkpuPZQBKH::pnUoEAj(bool EfpRni)
{
    double gsBJFRFunbhEnAkP = 785448.3837576088;
    string ChJjpaFR = string("oHFXxjqzqluEYZzXzqiQoBtnEyDNsGKmKtNaDJhPaDxnIcVOoyGOMjqmKDeqTbpBjpMUsqfvOoBltCGsRWRjqAnCKbgzYvwvIZ");
    int TkHlK = 255937723;
    string eqqMPiszetPNVxp = string("rxFhXHbBkUHZrEloYqnHoRVHmWKCYosCSKxEUABKzPKOBLrfeJKpFGkmpLKMepxeQXycUFyxzGmsREkCcbJcWHpuENDv");
    double GeqrHGv = -829975.037876084;
    string mUOErGXRVAQYgJSx = string("mPTbgzivsMaSvbZfvHvQZLoShHklvjJumTMEkKVIpfERHbmljBEDdnIGQYQYBptFWxcemETgRnyXuRdQEFcVsOYptqMNsxfbzOiHEfYWRoEeXpoccvEaJtefiQmhvYhHABcDrUHclDmwALyWGguIoszFtTuhDgmzIAOVSmViKsvwKeGcgETZoNrFjlvOTzBbgjFXWdSLfOPgqLFTtXptUCPreOSHBtaoTTgxrLywmwtULGsOzhulOIjHaOYg");
    bool MqBPcwvEp = true;
    string HrRhmnLP = string("evUOKxWtQycZdqacKHHMVsoGJQWNhozcFgKddxrUZRnnfoijRTHDqGBnbwBZglBlqGYUZXKzvittgwQmekeOdabiCCLrhgntVoyhnRfbCDLyfJovzVNtufTSosxgyqumXgsyJxySgZOGnNyGNiaWXxRWoITnOCJJzxMSsoIVjzCkczkcoQRZvs");

    if (eqqMPiszetPNVxp > string("evUOKxWtQycZdqacKHHMVsoGJQWNhozcFgKddxrUZRnnfoijRTHDqGBnbwBZglBlqGYUZXKzvittgwQmekeOdabiCCLrhgntVoyhnRfbCDLyfJovzVNtufTSosxgyqumXgsyJxySgZOGnNyGNiaWXxRWoITnOCJJzxMSsoIVjzCkczkcoQRZvs")) {
        for (int PraTLoK = 491725584; PraTLoK > 0; PraTLoK--) {
            MqBPcwvEp = EfpRni;
            TkHlK *= TkHlK;
            EfpRni = ! EfpRni;
        }
    }

    return TkHlK;
}

bool mrkpuPZQBKH::xWIIRoaYJheLt(bool gjBSYY, int mdHipfhSalywcH)
{
    string mVishzwEk = string("hmsrzsetWfUdUGLZYKVybvYvGGaknNFnBaEQdlcmYGwajPwtAvAFXGRjDzISKpJrvqaWseArDwMmVDguEuHVRVhzQfNSfULTurIwknIZMcbQDwgddWkujnNSrCTGXNUtCmPaDXajAMzwmLKsVSMHfPwbcXAgGDkGsaJriIKTJgVhFXrNdvmSmGqFpmfZjihKdoCjmXZBpBDvqJGBCYUjrvlOHSWLPkdAW");
    int axVTstdWJhs = -1506237445;
    double IsWIqnlwt = -671045.3868873527;
    double GdJjNBUmqGo = 1021300.5705893353;
    double slDiPqfA = 435616.86649664916;
    bool zUvXej = false;

    return zUvXej;
}

mrkpuPZQBKH::mrkpuPZQBKH()
{
    this->orgdViMKNWLqhMn(-606010.3332429953, true, -1903230371, true);
    this->xyBUoTqAkFzM(-54490.118949452255, -468740.7310848547, 710331.372179032, 890708.94996037, true);
    this->kwvVQMvkYIkMd(true, string("IfZUsFjtJTWuiUzOKksqctPUPsasLVwbgMSgoTuGwVhhanfhIVotgpRERDctPnpBnZObQbJcDKDbBqchbjTXaJCpjmdHjgHjkEcBPIZRyxScFHHVrmfuzlllTcTHrwZJdDFmllPAZnJEvBUXPUMfhEzdtSNAuWkJgsHwjbCwETJVEd"), -1418930002, true);
    this->ULncvb(-1980936568, 1596179415);
    this->rDanJzferJRHT(false, false, -1663665519, true, -296238217);
    this->ZFMcnz(false);
    this->FwQMAVGiwCEczi(372813.05715476733);
    this->qftONh(776698031, -963261.0533824106, -36159.1024357438);
    this->uEhjcML(false);
    this->pnUoEAj(true);
    this->xWIIRoaYJheLt(true, -37565425);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bXsBaUlTXRE
{
public:
    int FTCmCWTxC;
    bool JRVCxRxUfzH;
    bool WSJDTyeBs;
    bool wFkPD;
    int MzCfeswtYkuHIg;

    bXsBaUlTXRE();
    int GXStSacw(int CMwffbeGLoVS, bool Nuzrtwx, double rjSJRIHiQYFHxXYn, int YREfQLKCGPtuVNt);
    int zOPxgbFi(string CsMTOIXa);
    void yLlOsgsB(string eGVOpf, bool VKeByrvzoFztYeEv, double aJwwFmyCrmadUjkf);
protected:
    string dJCnAbkRd;
    int DVYwxKXnr;

    double KLYIFptp(string GhnNNn, string aUgRXguPI);
    int zYefqzFOEL(double wDYUe, int zCJWPEXMZy, string ZhfjspZGKJp, bool bYVVG, string UpFiU);
    int CJEOGylsVFhur();
    void lgOHCEwfLVCXVWly(string vKEdzUvGTJ, int IsNchttNmlPQLOpO, double FePBIGk, string RSpjF, double gfhUWUiWRM);
    double PUQiYSROt();
    void twlmYgVcVrbrb();
private:
    double RPhKymY;
    bool ZcZlaeLVcVcHRUAI;
    double zAgSLZlCymOZpkT;

    int tVNWSOPTEHGHRoNy(int ypDOQHVIqFJsErZz, string qTTPasJUpvpNMefC, double UZWXtfBtt, string HDChQYUZKIsShk);
    void EAtVdoE();
    bool FXEsgiUvIyl();
    int XddGJiQH(bool wpPlpCmEocUwSD);
    string BgJMfMdFzNpuKbo(string CDlfQltaWkgv, int sRrzZw);
    int mXJBjlfGYxxc(int hPZNavfbfjdBqTWc, int IZHaKFJGnbwaHnj, double cLQwLnRMG, double JJMmFCrAhwJm);
    int EmApkqxFYZKby(double kcCddqmRG, bool ymiMHaqRSEMgKjnv);
};

int bXsBaUlTXRE::GXStSacw(int CMwffbeGLoVS, bool Nuzrtwx, double rjSJRIHiQYFHxXYn, int YREfQLKCGPtuVNt)
{
    string AlfQaQMeGb = string("IXZHQeiVfpSAReosEcOWapWXMcgUjzQeVXFHQJhIOejjnIJYnnxpgNJLXIoPqTMtbuQQsJBmkUyyNhztGHKBalXzeSzzplmMKLcMgvxeTsaWUzCnlTVuhomjSlaebAYzFkWEMLpfPEGMwrSsPjNMuuQdaBWitAEYBxKCcyvFYKZtNlzmvZVyHsCfagUoycQdaNYQtTAyKEqQQKAECbdqQdsEDzUXUzNVEYuEe");
    bool SQgmifsASdWk = true;
    int HgWDWbbuTDquGc = -849590410;
    int SShvSTE = -2077119695;
    bool LiHUWDKCi = true;

    return SShvSTE;
}

int bXsBaUlTXRE::zOPxgbFi(string CsMTOIXa)
{
    string FRJXHRhiusr = string("UPXdeqCxidlEUBVWQvqHbawa");
    string LXZYidHAluMop = string("WFTqRGpjUUlTAoXSossxOscuLxDaoKOowytzistabBOwhTmXAVTHxjKePWI");
    double KdIBoXhwNLjHfNx = -355498.140586365;
    bool aBfBeEXd = true;
    double DreLbFRhGcIBe = 192843.9503037602;
    bool tanXQYmXkAvwze = false;
    bool YWtwbsJJKWsB = true;
    string qeBluKnwlbIZBKOo = string("hlminjZXBcIyNENEbkLZNdnWeruoIEOYtFcUdfNIMohXiIwRkxZSxjBQtcPTuBrgRMBbcXCpLALaQgnPhKdIfFoYYwYsSZOkWlzrvgIPRUkDQuOwkbtHlZcwZoKhMkUGwcHARAyMONdvKBJEneaZdPYxjnTgBFqOvNdyzGawqedcLXzndWAHqzhTrsBwvjNTTWqvxSUzAbEFfMnFGAEDRISYMmmeeKNyaDou");
    bool SolesfaKcPzDmMW = true;
    bool zmxXsRHA = false;

    for (int xumATYMChZN = 624201007; xumATYMChZN > 0; xumATYMChZN--) {
        tanXQYmXkAvwze = SolesfaKcPzDmMW;
        YWtwbsJJKWsB = ! aBfBeEXd;
        FRJXHRhiusr += qeBluKnwlbIZBKOo;
        tanXQYmXkAvwze = YWtwbsJJKWsB;
    }

    for (int FWTHbWZsOr = 763891995; FWTHbWZsOr > 0; FWTHbWZsOr--) {
        continue;
    }

    return -1054609659;
}

void bXsBaUlTXRE::yLlOsgsB(string eGVOpf, bool VKeByrvzoFztYeEv, double aJwwFmyCrmadUjkf)
{
    string XwuEajDgTswiDFf = string("uvjRUDgVyXzoPuZZjgMSJWrdkwTqDhvYJAOoDNzMhAmNJX");
    string IVEDse = string("FXIcwGIIaZCSAgUWRMvMXaiOanmAvnetdnEGmHjDtfccuYfcRIbkeOAyPNCKGlaqPtXOuynXVjwdcNLVkEYrxyaWJCklZbLdUmjvrGEBammGQQmsPeESaG");
    bool cxprRn = true;
    double IxtSXUY = -1037179.8744641806;
    string UtsQSiuSgFrmY = string("lHvmttjLteuBDRfxZdBUWnboMnz");
    bool rWLpgImIKnFL = false;

    for (int oUVWDrMR = 579764513; oUVWDrMR > 0; oUVWDrMR--) {
        IVEDse += UtsQSiuSgFrmY;
    }
}

double bXsBaUlTXRE::KLYIFptp(string GhnNNn, string aUgRXguPI)
{
    bool MkgLtc = false;
    bool fgnaivnr = true;
    string mUACaNdYRUHIQtSw = string("aHnJdiyfhrwqMSANDTOdnMDeBTSxdOzjgfQpoigFlUUieOnhggHYojShnTGLjIU");
    double OYHFsLtl = 129434.39071205158;
    double vrsBCeFOWwteJEDM = -805526.0019999766;
    int VAKUQjDRToLDKIHB = -1227174530;
    string GakzMS = string("veEBlfguYipDLBWkIvLDYIChEIPrTEjsryJTJqaogCxxxlcaXtlpcCSAdOUJFzYErqfUqTagqqWhOSSecCSLTLBZcnPJiOksIURngWKyeHinyvJuBmZYlIESLWTLwmcqFEOQAnGxcXQkFLlpWzztMgklBWuqWLpOcTOojGjkeepRXxqwrRdQZBGGuIVjwGJssuGVKNiOtdwLzKngouxSfaOCkCHPpWWrsVlrbnoFx");
    int DxwKeUghF = -732781797;

    for (int HgrYZojDxjLNrg = 140579102; HgrYZojDxjLNrg > 0; HgrYZojDxjLNrg--) {
        GakzMS = GhnNNn;
        GhnNNn = GakzMS;
        GakzMS += GakzMS;
    }

    for (int NJWBzqgKCxyDj = 1195005770; NJWBzqgKCxyDj > 0; NJWBzqgKCxyDj--) {
        continue;
    }

    if (GakzMS == string("vTbCfqFqARniyGekyAMhDQnNvIFbNOunMuVbvFHpoZCVpZdZxNdtMUFEgdPYOPfZcbSNHBkxHawUmTEYHnwkLKaFFXXXjHQQgJXQNPhOpDa")) {
        for (int BWswILZONftjTjj = 1760290643; BWswILZONftjTjj > 0; BWswILZONftjTjj--) {
            continue;
        }
    }

    for (int jgRrpMjCmPsAk = 1604649543; jgRrpMjCmPsAk > 0; jgRrpMjCmPsAk--) {
        GakzMS += mUACaNdYRUHIQtSw;
        OYHFsLtl -= OYHFsLtl;
    }

    if (GakzMS == string("aHnJdiyfhrwqMSANDTOdnMDeBTSxdOzjgfQpoigFlUUieOnhggHYojShnTGLjIU")) {
        for (int xuJkefCC = 2061120705; xuJkefCC > 0; xuJkefCC--) {
            GakzMS = mUACaNdYRUHIQtSw;
        }
    }

    return vrsBCeFOWwteJEDM;
}

int bXsBaUlTXRE::zYefqzFOEL(double wDYUe, int zCJWPEXMZy, string ZhfjspZGKJp, bool bYVVG, string UpFiU)
{
    bool SRysGJHDGxcLA = true;
    string TBrEtefqUKUeGVb = string("ClQhikqEXlkEsizimabbuHJuiJYAmmdcAGOujSlsDvgKUPsxXTnjEUxwWBbvcErwmcEzEQuNhFNcYOFzkZClFiNZDfUqWRRNRpRXyOQZDJYHdzqEXyVZbAyBcAwuyR");
    double OsaJQisr = -947020.1107254537;
    string kDnXJ = string("OjgbXwosrvsETvuIIWHdKUl");

    for (int fwiSGXwRBKyRaa = 181241125; fwiSGXwRBKyRaa > 0; fwiSGXwRBKyRaa--) {
        ZhfjspZGKJp = TBrEtefqUKUeGVb;
        bYVVG = bYVVG;
    }

    return zCJWPEXMZy;
}

int bXsBaUlTXRE::CJEOGylsVFhur()
{
    string CWzZyTYClalQceNV = string("fPnANWiMtPnBcemRfzVJovSqYhdkPJbYLjLjhZFVVtMYwbqTkuJThHfBAttiibpmIGdxBzeGgTXSNWesZXCClSddY");
    double atrKFhe = 880603.0067162779;
    double BFblOCmPVTRCDVe = -609595.4121243989;
    bool OvnLduttUgGBpoxl = false;
    int plXfQCToph = -1416679270;
    int IxGGSbEXVnBhOwS = 1139832563;
    bool ExLEpZdr = true;
    int FURekgAa = -2029570736;

    if (CWzZyTYClalQceNV >= string("fPnANWiMtPnBcemRfzVJovSqYhdkPJbYLjLjhZFVVtMYwbqTkuJThHfBAttiibpmIGdxBzeGgTXSNWesZXCClSddY")) {
        for (int GfqkkATtsggaK = 338254831; GfqkkATtsggaK > 0; GfqkkATtsggaK--) {
            continue;
        }
    }

    for (int kVPltqepmBU = 1049605301; kVPltqepmBU > 0; kVPltqepmBU--) {
        continue;
    }

    for (int jrWTv = 155790507; jrWTv > 0; jrWTv--) {
        continue;
    }

    for (int jCKskz = 753061589; jCKskz > 0; jCKskz--) {
        continue;
    }

    if (IxGGSbEXVnBhOwS != -1416679270) {
        for (int GDeoZKP = 689731926; GDeoZKP > 0; GDeoZKP--) {
            FURekgAa += FURekgAa;
            OvnLduttUgGBpoxl = ! ExLEpZdr;
            OvnLduttUgGBpoxl = OvnLduttUgGBpoxl;
        }
    }

    for (int khfBmNCFbz = 1362858859; khfBmNCFbz > 0; khfBmNCFbz--) {
        continue;
    }

    return FURekgAa;
}

void bXsBaUlTXRE::lgOHCEwfLVCXVWly(string vKEdzUvGTJ, int IsNchttNmlPQLOpO, double FePBIGk, string RSpjF, double gfhUWUiWRM)
{
    string jpQtGhXYub = string("XgXdCPaSknYzuUjVCEwwPpSAUUPxxjZmDuLlgdbZYYmqhhyHmJuTIsIkHDMNGgnPgTuKMDoSwcTwEpmEilHBucpKNSJIKZQusKHbaoPLjgRpKdQWFfukzcQouWRXFxNxleoxTPuUKfpXPQUYMhytkQUowjyOScTNmjevvLieRIcjpWcVgUqZyrUvibowxQs");
    double gZMCPTLlgHjLKjA = 540230.4444178799;
    int EQzqpFmMyGpZGB = 921626921;
    int TJHiiquzIohAd = 1523197716;
    bool zUuoZlWfBjclXQoA = true;
    bool XbYxzQc = false;
    bool ChUHu = true;
    bool iVZwn = false;
    int IhyJJdTh = -547328717;

    if (FePBIGk != 498404.0482673787) {
        for (int IXZXE = 1472270401; IXZXE > 0; IXZXE--) {
            jpQtGhXYub += RSpjF;
        }
    }

    for (int nYDUlfQcyex = 382264915; nYDUlfQcyex > 0; nYDUlfQcyex--) {
        gZMCPTLlgHjLKjA = gfhUWUiWRM;
        TJHiiquzIohAd -= EQzqpFmMyGpZGB;
        XbYxzQc = XbYxzQc;
        jpQtGhXYub += vKEdzUvGTJ;
        vKEdzUvGTJ = RSpjF;
    }
}

double bXsBaUlTXRE::PUQiYSROt()
{
    int KpwZcHejHSs = -1925044285;

    if (KpwZcHejHSs > -1925044285) {
        for (int vvZVJzzJdFnHDnea = 1281872155; vvZVJzzJdFnHDnea > 0; vvZVJzzJdFnHDnea--) {
            KpwZcHejHSs -= KpwZcHejHSs;
            KpwZcHejHSs /= KpwZcHejHSs;
            KpwZcHejHSs += KpwZcHejHSs;
            KpwZcHejHSs += KpwZcHejHSs;
            KpwZcHejHSs += KpwZcHejHSs;
            KpwZcHejHSs *= KpwZcHejHSs;
            KpwZcHejHSs -= KpwZcHejHSs;
            KpwZcHejHSs = KpwZcHejHSs;
            KpwZcHejHSs *= KpwZcHejHSs;
            KpwZcHejHSs /= KpwZcHejHSs;
        }
    }

    return -162140.8921474956;
}

void bXsBaUlTXRE::twlmYgVcVrbrb()
{
    double oorqMkptbOl = -766190.460274604;
    string LdPDpZcL = string("GDayGUcsHFFoxOtOTavTcCqpUqvyCPUZRABNfjnTqVjQvJTNJZDahbS");
    bool pmEPJjN = true;
    int wQeCssbjYchQAow = 303926007;
    bool bvKHSBjr = false;
    int hjOCrUHmnS = 365855883;
    string NKyidx = string("KMTNBdZbvCdOEYqfkEOQrplImTPacmHesFSByDeLQdKBxOwZKzDtQVWJwxlMsRRDvRKgHdKDOamFhXLnKCcJcyCBbSIsHzZakVbtB");
    double nDbstNPLlCNQtG = -751756.9521790186;

    for (int hnnNGZfF = 169901486; hnnNGZfF > 0; hnnNGZfF--) {
        LdPDpZcL = NKyidx;
    }

    for (int BdmmCzsEIlj = 1543508921; BdmmCzsEIlj > 0; BdmmCzsEIlj--) {
        continue;
    }

    for (int gGeViMlDrkKL = 2099544643; gGeViMlDrkKL > 0; gGeViMlDrkKL--) {
        NKyidx += NKyidx;
        hjOCrUHmnS = wQeCssbjYchQAow;
        NKyidx += NKyidx;
    }

    if (hjOCrUHmnS < 365855883) {
        for (int HPxHoGkrzJOlSDTt = 555151014; HPxHoGkrzJOlSDTt > 0; HPxHoGkrzJOlSDTt--) {
            continue;
        }
    }
}

int bXsBaUlTXRE::tVNWSOPTEHGHRoNy(int ypDOQHVIqFJsErZz, string qTTPasJUpvpNMefC, double UZWXtfBtt, string HDChQYUZKIsShk)
{
    string swIvbWFxBLcJPXCS = string("vIaNgAdowtPwgpkhGkQvqewNelBXDgHbjUZvbpmQQtVvSIAwmDOQFLlAityZFwJWAGCVPMcTFvSkQPqzqzVbOeAsQMbQiamSYaiIkRXvZgobqrsEyKqYHqGVdXKZOUsKKZKpvejANGFAxzYJlkqv");
    string MopMQFZfeiWWXMt = string("JPVtNkivKJLAUvRAgaQgIMXAAFNWrCTrKUojskkuafFKYjzSquYNYBugftdEgcxWQmaiFcQZmrFSLcVBnwlPgTerUzJbYVLYmIaDuSjiHsgEJOhRnIGzxLkNRkLISqB");
    bool qnONdw = true;

    if (swIvbWFxBLcJPXCS > string("fNcMcxoIsbwAEkdVUVvoViEUvFuGFNrKYBUxsEyHcQaaCHGTKYOYWKxatquOjmxMYJulprmJdLuCJDuLbJmxa")) {
        for (int fPaufoIYkZScRmP = 822720769; fPaufoIYkZScRmP > 0; fPaufoIYkZScRmP--) {
            MopMQFZfeiWWXMt = qTTPasJUpvpNMefC;
        }
    }

    for (int TtYoEXQfKlL = 401133125; TtYoEXQfKlL > 0; TtYoEXQfKlL--) {
        continue;
    }

    for (int XTEeYVW = 1803992356; XTEeYVW > 0; XTEeYVW--) {
        continue;
    }

    for (int IJYSLbB = 1888787081; IJYSLbB > 0; IJYSLbB--) {
        swIvbWFxBLcJPXCS = qTTPasJUpvpNMefC;
        MopMQFZfeiWWXMt += swIvbWFxBLcJPXCS;
    }

    for (int skBvncSbfI = 499388355; skBvncSbfI > 0; skBvncSbfI--) {
        swIvbWFxBLcJPXCS = MopMQFZfeiWWXMt;
        swIvbWFxBLcJPXCS = swIvbWFxBLcJPXCS;
        qTTPasJUpvpNMefC = swIvbWFxBLcJPXCS;
        swIvbWFxBLcJPXCS += MopMQFZfeiWWXMt;
        swIvbWFxBLcJPXCS = swIvbWFxBLcJPXCS;
        MopMQFZfeiWWXMt += MopMQFZfeiWWXMt;
    }

    if (MopMQFZfeiWWXMt >= string("fNcMcxoIsbwAEkdVUVvoViEUvFuGFNrKYBUxsEyHcQaaCHGTKYOYWKxatquOjmxMYJulprmJdLuCJDuLbJmxa")) {
        for (int TXXbdGRvTbDfC = 1112010922; TXXbdGRvTbDfC > 0; TXXbdGRvTbDfC--) {
            qnONdw = ! qnONdw;
            UZWXtfBtt -= UZWXtfBtt;
            HDChQYUZKIsShk += swIvbWFxBLcJPXCS;
            HDChQYUZKIsShk = swIvbWFxBLcJPXCS;
        }
    }

    return ypDOQHVIqFJsErZz;
}

void bXsBaUlTXRE::EAtVdoE()
{
    double abHWHB = -119076.10364516384;
    double cZzEDidXIp = -741415.3299560262;
    bool opRHzZujM = false;
    string HJtlFVPzHv = string("xERLlvhnUoggEckcowuYJtHJASkynlZVgXsYHyMMFIvgKCWWZSLkFDbWXAdtvyJuyHQREZtVrIDn");

    for (int norZwTXmc = 1937905496; norZwTXmc > 0; norZwTXmc--) {
        abHWHB = abHWHB;
        abHWHB -= abHWHB;
    }

    for (int zPHoZm = 1875670955; zPHoZm > 0; zPHoZm--) {
        opRHzZujM = opRHzZujM;
        HJtlFVPzHv += HJtlFVPzHv;
        abHWHB += cZzEDidXIp;
    }
}

bool bXsBaUlTXRE::FXEsgiUvIyl()
{
    bool KSveEPlPBuO = true;
    string fBhmpK = string("gHCHscNSQGYFmlYNilHGNPUmxaJLHpMZEVVyTaTPnYgEbqNAlXgtRKsFAUglgzwbVXvUXVzgNEtvmuErBoPcRZZcxqNmmQkJOPSySITxxhppMDslxzbQJ");
    string tBprpcoDmxoWP = string("llbXjqugGtKMAXykuxzQqMnhBoXzikFvXlNxUEvwStGYYtzuoaznHMFWnLWjfVOPtCELbYiINAacMeztiqDLqbKTAUDOKKdTQpDeACoLWIJwNFfiEbvmmGesTMlTKfPkcuNsKAwFnPBlPZgCXbEZkRCZOOYUVJSlBNFrkUxBgBuRSILkrOFtByfBCgEteuutzabRrclGcTvMkaiUkAmgPDKymYabgdsPhilceTQpxfsjLNuwwkccfF");
    double mTVFfW = 148611.66706516946;
    int qTKcQxi = 461928211;
    bool tADisVYWllN = true;
    double FVtDivDh = 90746.78003450032;
    bool NQqOdDpZIUPygU = false;
    int ZkBZUDARRZpLr = -2081923497;

    for (int YwxQbFZAYgDWp = 1828263862; YwxQbFZAYgDWp > 0; YwxQbFZAYgDWp--) {
        FVtDivDh *= FVtDivDh;
    }

    for (int rfgsdDGekxgnnWs = 1301468589; rfgsdDGekxgnnWs > 0; rfgsdDGekxgnnWs--) {
        mTVFfW += mTVFfW;
        NQqOdDpZIUPygU = ! KSveEPlPBuO;
    }

    for (int gOFPja = 1508624490; gOFPja > 0; gOFPja--) {
        tADisVYWllN = ! tADisVYWllN;
    }

    return NQqOdDpZIUPygU;
}

int bXsBaUlTXRE::XddGJiQH(bool wpPlpCmEocUwSD)
{
    string AGrMvTFCjdFG = string("zmgXKOkjCRRzQxJSUTXfdPRZIZrIrjPmwjjfNFCUIXJjfurjf");
    string ASeoOrgpDpZpX = string("LUAKAaanparKQZUrJKADVWFPJiltAhuJhqQkVGnNqJpEncLMyKZSFqfXsrQrPPPjlZcCedTfRowBNYfMfYlQPFfGVDBPKwBJLZLjPcjOnPXZUZFkRdoTHgDrcfEvZKBNmlbLFXxMXP");
    double NMLGLEQ = 942001.742785814;
    int iRlpDKizip = -1885347027;
    string ZngyovCavYwwK = string("fWpgtqjoirbeqyVvjYhozDfIqWHIwMHctjygIHuPuXIvZZWpfJQtKFYKUrFgGGfTxIOiMoQVMxmYnPnTLcIwbTqkRKwaIQJegTQELAUEEQZYrfVhzlLsiwstWclDEFfzaSFiCApKfJvZvOgmYxBaSAIIUFeBYnPGnOqXndGtIttWUorOOlfRkIYUfnXIEMwvwZZ");
    double GtqumILiB = -313909.620562951;
    int hBEaqVRqd = 2144753162;
    string qjDNloFd = string("rvwCJpbQbKqgpupDBaPdMLdGNRAktRRDvbKISvchnTIFVwEAzsZJmZKIUzlPUIxWWJe");

    for (int xoTniMj = 70354716; xoTniMj > 0; xoTniMj--) {
        ZngyovCavYwwK += ASeoOrgpDpZpX;
        ZngyovCavYwwK += qjDNloFd;
        GtqumILiB *= NMLGLEQ;
        ZngyovCavYwwK += AGrMvTFCjdFG;
    }

    for (int sxeFqnJABxPGoVt = 1291514479; sxeFqnJABxPGoVt > 0; sxeFqnJABxPGoVt--) {
        qjDNloFd = qjDNloFd;
        AGrMvTFCjdFG = ZngyovCavYwwK;
        NMLGLEQ += GtqumILiB;
    }

    for (int TIPMnXOiL = 1717702767; TIPMnXOiL > 0; TIPMnXOiL--) {
        qjDNloFd += qjDNloFd;
        iRlpDKizip += hBEaqVRqd;
        AGrMvTFCjdFG += ZngyovCavYwwK;
        iRlpDKizip *= iRlpDKizip;
    }

    return hBEaqVRqd;
}

string bXsBaUlTXRE::BgJMfMdFzNpuKbo(string CDlfQltaWkgv, int sRrzZw)
{
    bool tWXjzOSY = true;
    string HDgyISqoKIKKmJPm = string("HeDiHyODuuXhWIDBVpfgBliSZPLBHZFeRbagDdFCQyPGKrJSBQfTdCaQdJeTbVZkOKVsLVxaUmBjuhVvXYhmGYSqFHOnyPPZnjzZIzTfyHSwyCkhaZEKixMpvlnXgJnzsizInwJUFBuNcbYIDxpQeWzcBRIkVKkGegbcnYNUEqKnbQEIHJGUjyRpfwrKIraQZxtbXXUocYR");
    bool xzYCfHVpm = false;
    string FbeqBbNRHnjs = string("DbybwnJdxiStdRCkKtVaPrlwKGcDQZlcVKGvkGcLV");
    int bFbJDmYmer = -621794047;
    double nPhWDGY = 537155.1265633251;
    int zHjYLaxUXrR = -775321277;
    double DnmeDNoUZsSPLBpW = -290837.4603058571;
    string JjVCKxBvtJfyAj = string("XjGKAdnqDFAnEMJZnyUwRbazkoSyRNlLykTapcxLrMhZJLAqhjLxCOzRz");
    bool mUAvASqLTwaYpF = false;

    for (int hxTEXMrR = 961038221; hxTEXMrR > 0; hxTEXMrR--) {
        CDlfQltaWkgv = CDlfQltaWkgv;
        DnmeDNoUZsSPLBpW += nPhWDGY;
    }

    return JjVCKxBvtJfyAj;
}

int bXsBaUlTXRE::mXJBjlfGYxxc(int hPZNavfbfjdBqTWc, int IZHaKFJGnbwaHnj, double cLQwLnRMG, double JJMmFCrAhwJm)
{
    int SJprW = -1128125892;
    bool CzSzfjkdgljEAjD = false;
    bool kEQHVEnqcB = false;
    bool GORlgLJ = true;

    return SJprW;
}

int bXsBaUlTXRE::EmApkqxFYZKby(double kcCddqmRG, bool ymiMHaqRSEMgKjnv)
{
    int FyRAYsOmKhS = 1624873788;
    int NsVaQjzrIMhaX = -1734856841;
    int emHwpwNbamjnTDV = -152451160;
    string JkGWjEd = string("MrkbZlWmQIxFyAlMpupnIoMNIMnYcWIqSSIylcFqUwCihcaKaCTKmyymOYHAuVmeCGdniJftPCqFEIiIZIxSBuRvKYPQpWaMibzTiRcomaKCEKRZyORXtFrwhgEpiZUzVPqJWNBlBdAKoqpqjzwFWkCgGawSHCRpxmLZDBHTacBqRAKaxoUQjtKBnXjZvUEduqQOvlQLGPrY");
    int lwIbA = 347528520;
    double laGbgXoRKeqHy = 446766.62707247486;
    bool VLoczxUAOuBbOfHc = false;

    if (kcCddqmRG <= 409066.06295706873) {
        for (int McCaWBUsaW = 89180130; McCaWBUsaW > 0; McCaWBUsaW--) {
            continue;
        }
    }

    if (kcCddqmRG < 446766.62707247486) {
        for (int dGXEwRcqnpX = 110369920; dGXEwRcqnpX > 0; dGXEwRcqnpX--) {
            NsVaQjzrIMhaX *= emHwpwNbamjnTDV;
            NsVaQjzrIMhaX /= NsVaQjzrIMhaX;
        }
    }

    return lwIbA;
}

bXsBaUlTXRE::bXsBaUlTXRE()
{
    this->GXStSacw(-1969830659, true, 849923.0513350347, 681543740);
    this->zOPxgbFi(string("iuJbnOpWsMJTEBePtahpMBImuHEauGGKoMbEmfRyJMvjAptIKvtWHvVozQCibwUGZiexSUeDYVbkRDQDjMpyZcijTLLjoKaWCbVzdymYYigSghNmuUHrORaKwRQxUpNTelBLRTiaYNfsgMpLkDDGdQrbtSzWG"));
    this->yLlOsgsB(string("RBpYLOllabxiImxuJYROWXgqmVFfvUnGIoeHCoGQnbIqzFwNiZsLIysGFlRXEuktJuCYfiqsxaBVxpDWGoYktNrnhdXABKNqXxCTgsgYLFM"), false, -541769.7444230255);
    this->KLYIFptp(string("FYBhQGlJyAdfNRwUMxzIwkVJeWdpABtHNmIEBmUKPyZgEgJWh"), string("vTbCfqFqARniyGekyAMhDQnNvIFbNOunMuVbvFHpoZCVpZdZxNdtMUFEgdPYOPfZcbSNHBkxHawUmTEYHnwkLKaFFXXXjHQQgJXQNPhOpDa"));
    this->zYefqzFOEL(40875.77257195387, -714635676, string("jtQYbiHqSWOhJxSrPcHBAKJFjwlIGczZOEZOtWdOZaFBtsbfkkUiYJAuMkUkMfxNBIYiMUbiQFhfBHBrwwWLjttQswFJKLXsfKCTmZSdEHDviWnRSkKkjAjCRBVlfKbw"), false, string("ZvGSyEynEZeyuPwIvDeigtXaRnONDsdtrynlayQRjRjeMQRoyAbGnSuDkmjOVEvtNSxpJcVxBuHmTwVyprJprtlagROdGzGfdbqSFNqJLFtZ"));
    this->CJEOGylsVFhur();
    this->lgOHCEwfLVCXVWly(string("gNVPwEIvmrr"), -1831256498, 498404.0482673787, string("nbusJJrjLdsrmkEVUTfrAsvHJaPVKVuqaXQjqGKtIEDygpvdmiEOMrnxaoyJdqamIPWHopnAHioZohJXcMFzbaxZOqgDHzybwgDPPGgdPgbMvyKqLvIjWnXjpWISQwoUYQfrneEPpfWVSuNYkuHmGvjHtvTMMrRTlWtGxufonDToPfBwKJmTqaAnv"), 265897.78677899356);
    this->PUQiYSROt();
    this->twlmYgVcVrbrb();
    this->tVNWSOPTEHGHRoNy(1896480511, string("rQcKjEBsUMOTjbSeLGPnJhIhmEYFzvwrgbLhxbPtIqBXhxQlyeLufSdmxWwFWDgqpsLrZAbWbkunObKsOBVpknboNgNNNhrxOjVocvo"), -177149.4091835905, string("fNcMcxoIsbwAEkdVUVvoViEUvFuGFNrKYBUxsEyHcQaaCHGTKYOYWKxatquOjmxMYJulprmJdLuCJDuLbJmxa"));
    this->EAtVdoE();
    this->FXEsgiUvIyl();
    this->XddGJiQH(false);
    this->BgJMfMdFzNpuKbo(string("wqWuNRLcqsTPYaSHyjmCuFWSIGzvpxXRSfUrSzFrxDODbZmlKlVhNeHPYMeRQMmQriiBsQijj"), -1228014960);
    this->mXJBjlfGYxxc(-1270921136, -186695979, 468343.03353175585, -902768.9735142686);
    this->EmApkqxFYZKby(409066.06295706873, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KycdB
{
public:
    bool RoCXfe;
    string vxaUF;
    int uKoUCtCVBqRehhf;
    double FFvPDHgMpElxeSck;
    string puxNKzNCBmYZOxG;

    KycdB();
    void uUutCPkaUkO(string fKwBZBANCVUFxc, string ILjIhKpmm, string CWoAFwBgdoEYU, string DRDNNVKyMjfSq);
protected:
    string RaLptZZqDMhitZ;
    string VMmGd;

    int gPhaydHPuHshcJwc(int mCqZjjdlTqbL);
    int xDoLvSLZRwTRAqw(double nGGOaIYsSKILcqz, int qxpdci, bool hOTnwOQPYnQsFeg);
    bool NxPWmpyWrr(string ExwZfrcrmIgP, int tYxutzTH);
    double oGENiIOJXYL(double rEpKsgnDkIXGsb);
    double GxnygY(double KDPYamuO, bool YCcgeZjY, double LSMCfwkqIqMQY);
private:
    bool PZhhP;
    int syjVZ;
    bool gcoIczckaR;
    bool CPkRnqh;

    int LLicRHaR(int daIIHzzDDjo, double XzygWFOOV, double OneqnZnNpPW, bool sBeSpuWsH);
    void heEalrXGWlWCdrw(int QscPD, double PdahRmFfBcHs, bool eORhIATzFtfX, string dUdMmbMA);
    void JXeRT(int IXFqVForyqAVHK, string RHsIHZNMic, double CtMNLxMuRP, double TQUrdmRY);
    bool qogfpsInfnXb();
    void bkjULmCMHSYPh(int dvqjhEQUE, string neLvu, bool llpeeYJm);
};

void KycdB::uUutCPkaUkO(string fKwBZBANCVUFxc, string ILjIhKpmm, string CWoAFwBgdoEYU, string DRDNNVKyMjfSq)
{
    int VZUOFjdkiYnL = -781093875;
    int ePyYZnkuUjtA = 798813383;
    double txOPpUOpVuTQDb = -910386.4444241885;
    double bWqQVip = -681070.0009200067;
    int yXuxmRhF = -130097314;

    if (fKwBZBANCVUFxc == string("ESWVqbpQTPcSOBrc")) {
        for (int HwJbaTpPyaluVNVc = 729428008; HwJbaTpPyaluVNVc > 0; HwJbaTpPyaluVNVc--) {
            ePyYZnkuUjtA /= VZUOFjdkiYnL;
        }
    }

    if (ePyYZnkuUjtA > -781093875) {
        for (int LPITIMdowFxOmS = 891685204; LPITIMdowFxOmS > 0; LPITIMdowFxOmS--) {
            ILjIhKpmm += fKwBZBANCVUFxc;
            ILjIhKpmm = ILjIhKpmm;
            fKwBZBANCVUFxc = DRDNNVKyMjfSq;
        }
    }

    for (int XmaSkITt = 643065081; XmaSkITt > 0; XmaSkITt--) {
        DRDNNVKyMjfSq = CWoAFwBgdoEYU;
        ILjIhKpmm = DRDNNVKyMjfSq;
        bWqQVip /= bWqQVip;
        CWoAFwBgdoEYU += fKwBZBANCVUFxc;
    }
}

int KycdB::gPhaydHPuHshcJwc(int mCqZjjdlTqbL)
{
    string SMvzAlkoO = string("PXxXDttvvsEpZOdfyuGvPJvpzFhrAkBitLrzQNJMgoWzHOAGJVVenEBRKFQbadNIQkgooTfqsPmJjjSaztezScxMshswKxZkCNtknbXJOeUrNhA");
    bool KTnCzdcrWkAH = false;
    bool RzvIGFf = false;

    if (mCqZjjdlTqbL > 1582571721) {
        for (int ImoJi = 1182580073; ImoJi > 0; ImoJi--) {
            KTnCzdcrWkAH = ! KTnCzdcrWkAH;
            RzvIGFf = ! KTnCzdcrWkAH;
            SMvzAlkoO += SMvzAlkoO;
        }
    }

    for (int ufxNEpuFl = 820822188; ufxNEpuFl > 0; ufxNEpuFl--) {
        KTnCzdcrWkAH = RzvIGFf;
        RzvIGFf = KTnCzdcrWkAH;
    }

    return mCqZjjdlTqbL;
}

int KycdB::xDoLvSLZRwTRAqw(double nGGOaIYsSKILcqz, int qxpdci, bool hOTnwOQPYnQsFeg)
{
    string GZYUYcUZVwnbiX = string("CEXtkqooA");
    int ryKceRuaqElQF = -1152121320;
    string COysRdpk = string("iOxOZCJpKxnfbJQbnuATCUy");
    double PnBiEbILCjiw = 968059.1771713807;
    double isyDJqpTC = 821884.8081843014;
    bool XHXchNPLdhMl = false;
    double NiTQYAT = -248834.10563791438;
    string illAOidAyiIst = string("lPkUOKJUvxxdbyiABGomurCBurqIwUOzlbhgRPKUOnexzjWlytWQjNjeIuJOmgiwbrwkC");
    string KQeakn = string("sBnsyksokqEEMrymHLwShaRfvMzymOjtMgeSMYvjCBCPaIPQAPsXkltFQGmKQoFRsoWctqzirbXNKdhdPipxfuxgiOjzlgovzcoGZAgBddjRmmlUMUhPcDtXdVMuSYhBpZHyqcOLNIBXVWscRthvBjGfoKgApvzVHRlsIWMjlibuZODdGxlFWiSzaagZBRzSBHohoiVMG");

    return ryKceRuaqElQF;
}

bool KycdB::NxPWmpyWrr(string ExwZfrcrmIgP, int tYxutzTH)
{
    double XGRdBaQMtPBIoCDV = 630693.850897672;
    string OYDkgTf = string("AtPYmkhCfGlsHiaIsLhuwqnBpeiryeUFcYTOvuPAazzrGVWkFEepGwDpCLKMMQTWZtTYrbQldvRJOKXWAZPWTaOBqeCQeliLmexkCaPZkfskqpxcwNdDCYyDKQetyf");

    if (tYxutzTH > 695716262) {
        for (int TqIBEqOLIBUjfmL = 1859878156; TqIBEqOLIBUjfmL > 0; TqIBEqOLIBUjfmL--) {
            tYxutzTH = tYxutzTH;
        }
    }

    return true;
}

double KycdB::oGENiIOJXYL(double rEpKsgnDkIXGsb)
{
    bool hSsVexBMjePSx = false;

    return rEpKsgnDkIXGsb;
}

double KycdB::GxnygY(double KDPYamuO, bool YCcgeZjY, double LSMCfwkqIqMQY)
{
    int Gjhmff = 605621470;
    bool PjNygujqYPrOWeH = false;
    double EAcBGlIgYBZFo = -438693.61637798185;
    int YWrWplu = -1039159534;
    int DcimrMYsd = 1961495273;

    if (YCcgeZjY != false) {
        for (int eFUvucsVfmj = 720950755; eFUvucsVfmj > 0; eFUvucsVfmj--) {
            EAcBGlIgYBZFo *= EAcBGlIgYBZFo;
        }
    }

    if (YWrWplu <= 605621470) {
        for (int KeuPNQJNPFpMbq = 1408891998; KeuPNQJNPFpMbq > 0; KeuPNQJNPFpMbq--) {
            DcimrMYsd /= YWrWplu;
        }
    }

    if (EAcBGlIgYBZFo == -892003.7533270189) {
        for (int fZhgpBPQxEnnB = 249022160; fZhgpBPQxEnnB > 0; fZhgpBPQxEnnB--) {
            KDPYamuO /= EAcBGlIgYBZFo;
            EAcBGlIgYBZFo = LSMCfwkqIqMQY;
        }
    }

    for (int rIaqSZnNtyBgt = 250628447; rIaqSZnNtyBgt > 0; rIaqSZnNtyBgt--) {
        EAcBGlIgYBZFo += LSMCfwkqIqMQY;
        YWrWplu = DcimrMYsd;
        DcimrMYsd *= YWrWplu;
        LSMCfwkqIqMQY += LSMCfwkqIqMQY;
    }

    return EAcBGlIgYBZFo;
}

int KycdB::LLicRHaR(int daIIHzzDDjo, double XzygWFOOV, double OneqnZnNpPW, bool sBeSpuWsH)
{
    string FFzcSfCywvY = string("bcidquCroiBeLxfaDqYdZfnwYrCwwTELHTNaljDwXGfiIwyQYBZXvUYliIMAEzjVLzNvOIFKXvUzWFodvYtIgWzrkKEspOgrZoONeDLZkUxlrEqxyrCAvXOaIDWCrxyujseoOYhQABKpTYDfeylWwKgbwWWndbHKgTEFzCCNfVyCftVrGGKxCMFIYhnhLNxBeFvKqOkFopdUdsCQgLstgyUXusoyYABusMfcRTXLjsgnigaccTofvP");
    string AtYTOJPFevfae = string("MNOEGenwHlftHnbjPLfwpycUQiQSGMxAOcZHlnfEBwHntWTSHAEWvsSLyYRWPrUfVfJWPBuIPGLgEaqWtbBoyXQFMIBvIRgzKHYIYEWyXabNIvoAGcOOgyehaafjSClMlOWjUCLkslCQvXPjymsbufEQHsxZpYppefzytRCLkAPJujFceTfkAqhSyBWSmWeSgzaZbBJiqGKFYcyJbLCQAFoQjcP");
    string dAKbktLZtQ = string("wcYpnxhdZHojYSYbpCgvLAMstYsMcasYmrtqNseHIElnmvqIXDmZgfBCHaGDsoPZbpSUeQXCZXcMYgTRgQcwgELHdHmnRkzHYNYOPyzFTusTIPzMEXioGoEwgWGuNznQFgspvxBzpCNrqCxMXYPLmUrJDcHEuYYgEjqFDPYiSDDCgDDvWDzlLYYeSXEXhLbRqDBRRCdorudVAprjgtnLQrOUCwtcafJipU");
    bool sgVBKr = true;
    string sLcldmxRXsRpfDyx = string("NXsGXkMBqSzbaMgHRWpFLWcDvEAYeWD");
    bool JppsUWaMj = true;
    string zPDzDMGzS = string("uBSBLREVovmJgDSAHJlajkbaWR");
    bool pmHmYSR = true;
    bool cRCwwATYTa = false;

    if (sLcldmxRXsRpfDyx >= string("uBSBLREVovmJgDSAHJlajkbaWR")) {
        for (int IFGofLBDIqMN = 421668253; IFGofLBDIqMN > 0; IFGofLBDIqMN--) {
            AtYTOJPFevfae = dAKbktLZtQ;
        }
    }

    return daIIHzzDDjo;
}

void KycdB::heEalrXGWlWCdrw(int QscPD, double PdahRmFfBcHs, bool eORhIATzFtfX, string dUdMmbMA)
{
    int XNZNCGqhTrQ = 254369374;
}

void KycdB::JXeRT(int IXFqVForyqAVHK, string RHsIHZNMic, double CtMNLxMuRP, double TQUrdmRY)
{
    bool ubBytG = false;

    if (TQUrdmRY != 293211.9474144989) {
        for (int PBOAcD = 1810560076; PBOAcD > 0; PBOAcD--) {
            continue;
        }
    }

    for (int rNqLwWMJqxifc = 265500716; rNqLwWMJqxifc > 0; rNqLwWMJqxifc--) {
        continue;
    }
}

bool KycdB::qogfpsInfnXb()
{
    bool KobSE = false;
    bool yxXMJABPFjDyPNyX = true;
    double szOiYy = 423925.3186407738;
    double RNUqbkiBEhZ = -372181.5581562243;
    bool HrANx = true;
    int sXTeXajtODoyK = 1526868504;
    double ztXHUej = 916957.8894590858;
    int iFfTtNVn = 90049181;
    string hpBWnxrHVHtr = string("kQsVsOxLrgPRKPXhYLxtGoLeuyBkDzGWWaXYBJdDGnCixPpvnmgxiqjZhSsLGqDPNTAKsPDfmjgnRZPBNHZiChJsxxPjYJgzfmujdZkdiVMsRJWUipgnljOAVmzXMzWwbgCQTVeAgPRaHmnOVFkAljbLtEQRnsBeIqEHYUDnfD");

    if (HrANx != true) {
        for (int NmCCSQ = 2106912048; NmCCSQ > 0; NmCCSQ--) {
            KobSE = ! KobSE;
            szOiYy *= ztXHUej;
        }
    }

    for (int tbxoFnHYTltdSyn = 2139527247; tbxoFnHYTltdSyn > 0; tbxoFnHYTltdSyn--) {
        ztXHUej /= RNUqbkiBEhZ;
    }

    if (HrANx != false) {
        for (int AHDLsOKB = 746354192; AHDLsOKB > 0; AHDLsOKB--) {
            ztXHUej = ztXHUej;
            RNUqbkiBEhZ /= RNUqbkiBEhZ;
            KobSE = ! KobSE;
            szOiYy = szOiYy;
        }
    }

    return HrANx;
}

void KycdB::bkjULmCMHSYPh(int dvqjhEQUE, string neLvu, bool llpeeYJm)
{
    bool tYizvuGdCErln = false;
    int VuMbOG = 1135452093;
    double salxcAcoqW = -843981.965737375;
    double nUQMhUYXQwUdZ = -391129.29181765765;

    for (int EetuTcLgX = 1903494078; EetuTcLgX > 0; EetuTcLgX--) {
        neLvu = neLvu;
        VuMbOG += dvqjhEQUE;
    }
}

KycdB::KycdB()
{
    this->uUutCPkaUkO(string("vszgFzsaikQLCFdEugcijWATXsHPKGmnRfyAFMwBGqgpTqbXbeSkRMtWlTDTuxxYLlDYoXNZkgBbZnOJDOCkLGGANIwoLvdOmKpHIjfLGDEpdYsmXAplUuy"), string("FSWddICiHsEOZIfYUFjQMVerJiItuYrCbWGFnuRmveEnmxKMvnkIcKxqcEhswhShDrFPmmDcWvn"), string("KBzsMVfBbqoKteodbTGoFtEVQOsaYlgJWTVjaEEaWGBSShFQxuvWrURlVOHinOxHApurLCSsIWctxzIQDLlbIpyzRXQbPEfykMgEABm"), string("ESWVqbpQTPcSOBrc"));
    this->gPhaydHPuHshcJwc(1582571721);
    this->xDoLvSLZRwTRAqw(1039690.3239711166, -1725831779, false);
    this->NxPWmpyWrr(string("GYBFEhWeBlzUnjVFwnTPFwnOQdPiUuDuxRAMCZPLFfMyWGmGbzsNjTsoQaMg"), 695716262);
    this->oGENiIOJXYL(733429.4350229594);
    this->GxnygY(-351445.59700285154, false, -892003.7533270189);
    this->LLicRHaR(567102764, -722951.8075406428, -886148.9032658872, true);
    this->heEalrXGWlWCdrw(1885385194, -426575.90856568207, false, string("pWijfBKVZbHJRnhyAMzScMcfUppaSGlIneEwzJUehFujLpcWSKZyQEacNWukcPtWZPuaZmVtWAnLCcPQGWaMQMsuRpWNDhOivbnuZQYDSCSUnWwXgUnSUPkdXcjyGvtCwPMGilpNAZFdwNCRKFuqVQeQvgEoSkTiIunIwIdOneZjPKRukNWRfEcyPwouGeJXPmZqnJdlgrwoR"));
    this->JXeRT(952977232, string("GRIEwtxfrgKdcEfenwyXJaGXjQrsOHXiOqiJuaFwdeYTGDRhkLuiRVeByENVGgjacEBidftRcbGUCjhklZgWWKZvfNnTktwoZkEMWVDTQXxNUwqNcbsebqEiEQmlwuHTMvjLpcQWCjsJkaqUcoFhyiZePofsjecziNDvamKLjThtLAr"), 293211.9474144989, -286205.0963171122);
    this->qogfpsInfnXb();
    this->bkjULmCMHSYPh(-945146205, string("wZnWjeWtsmdhovFvwgAMubvgPBlwkidZQOWBkfSAxCIOFBjtsvUvLsgYvNLpSNDoDHxizSilzxelHZWQKrvbMKbVlXfFnDEgKkSAkdcUNlbjXIYILfdtoUsyQfsBairFHpwcynlFBBNaCkLpMDRlfnIWYeqAPAMilusCo"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kPExSDmprCDoWrEv
{
public:
    int XynOX;
    int wiLFsoahYBIh;
    bool vrxUjVtFGESAyat;
    string GLWVkAfon;
    double FKNBhLxpqDgGM;
    bool nXDsZsHHW;

    kPExSDmprCDoWrEv();
    double oRCCdS();
    double TtzxOPLeDT();
    double zNUnZ(string ugMrdyeLa, int quqmxDfgaLdZEvfB, bool MWoXwFeex, string ueLMBmO);
protected:
    string EIEbtcjETRPSrX;

    double JsesZlKHlmQGdoi(int eBhVGqEv, int SNZXxukqh, double nFvleSHIx, int BuKitCok, int TTxHerCmkFzdYNNB);
    bool zoJdBdTFJbJRkp(double msQNZvkrEXPG, string AsTcWUE, int EkaqjCqDYPFfrr, string fiGhgihvULjjmVnD);
    bool AFAiX(string dZRDeSHTauSqbHif, string kMBzvk, string uuxCuKnApklgWK, bool ImQzZTFYkoPLR);
    bool ibTtrLE(double IbTIebPT, int siQdyWNhEEwoYxJf, bool yczQuQneVxzxFzpM, string oaKYhoCdGZ, int ACnJPuO);
    double QXZwVR(double psgwHAkaYvrvjnb, int PDyHQDYwHPJufgC);
    bool qdNCTnZLxgBiTzf(bool wKjvufxKFEjlfawI, double faFbHn, bool gAVnwwoHOpUQN, bool xrdYnhJ);
private:
    int lwPFgpTLUKssu;
    double cpVxSVdeAVx;
    int vNNlxHpi;
    double cVvnBypVtXuqrpBZ;

};

double kPExSDmprCDoWrEv::oRCCdS()
{
    bool fbEZNiEd = false;
    int mkSlvFxwsJ = 850521020;
    string tOswalGVVTca = string("kanzcAILjbbcYsBYEXocQwuKSMeJkUxmLMuAKnGwJXqxSIJCmjDDkgKhasixHtsxGPQVsfmswHQCgFSpTiBaaiOASRvNXWPUVISGVKpZNWWbWZSecYjMDGzUcPGkHyKHRHLRuAzkeJwXfuCngIauw");
    string SGBeTNwuoOuz = string("kcMVTkbtvtQAfUXvvKneXsyRcXeBzIKpLgIyoLDGgQrGAPxXVhCBuHGZlNmWZhTZfIZQzsAeFwCqBvCedNXgGnVjGoRKMIiSbdroZUqNdQkREDwGAsquPumihcgyWLDiksaJUJPghxyyjzBavWWknyvnaJlvmnIvHSoShXdhPPSVBIHSQwSECfAwmQeewWzGQomoDcgKvMdbSTfKZbVHJqOt");
    string ynINqO = string("BmAYALzniQpgGVhUGLTrdOLQkulrXPrTBfumyOAnSnOUNgwCyTpeEnbOdLDMfqllFtucRRrBvfketuLnlWjcFciNQYUHWVhXsfOHdkoTrPvcuflqGtUxGmDmsZXqlenNIuqDOhnoxyOPkhPCIAnBMnIEVCPHGUACWZEYKyWtRmlorNaQkqMCRPReWgHhWUsfYX");

    for (int IbncgXpqlXsOyl = 1710963580; IbncgXpqlXsOyl > 0; IbncgXpqlXsOyl--) {
        continue;
    }

    for (int VpszRmkKAfahd = 1321986329; VpszRmkKAfahd > 0; VpszRmkKAfahd--) {
        ynINqO += ynINqO;
    }

    for (int IUrvv = 1857550432; IUrvv > 0; IUrvv--) {
        ynINqO = SGBeTNwuoOuz;
        tOswalGVVTca = ynINqO;
        tOswalGVVTca = tOswalGVVTca;
    }

    for (int yDtUBgGKtkaXpT = 1134639162; yDtUBgGKtkaXpT > 0; yDtUBgGKtkaXpT--) {
        mkSlvFxwsJ -= mkSlvFxwsJ;
        mkSlvFxwsJ = mkSlvFxwsJ;
    }

    return 629014.0809276957;
}

double kPExSDmprCDoWrEv::TtzxOPLeDT()
{
    bool KjmKysALjQUcmwB = false;
    bool aIAIPqX = false;

    if (KjmKysALjQUcmwB != false) {
        for (int bIjPdYJLvtGUL = 616008148; bIjPdYJLvtGUL > 0; bIjPdYJLvtGUL--) {
            aIAIPqX = ! KjmKysALjQUcmwB;
            KjmKysALjQUcmwB = aIAIPqX;
            aIAIPqX = KjmKysALjQUcmwB;
        }
    }

    if (KjmKysALjQUcmwB != false) {
        for (int bHyWjvRUvpzBa = 196281916; bHyWjvRUvpzBa > 0; bHyWjvRUvpzBa--) {
            aIAIPqX = ! KjmKysALjQUcmwB;
        }
    }

    return -976989.421748591;
}

double kPExSDmprCDoWrEv::zNUnZ(string ugMrdyeLa, int quqmxDfgaLdZEvfB, bool MWoXwFeex, string ueLMBmO)
{
    double egnzdbahwSKhpdGM = -949762.3570739799;
    int OlfSWgAJ = -711485338;
    int sNNtGSLNQMo = 1080011769;
    int KqTtqCpNBsaU = -1603551377;
    double jDqcNIaukw = 911726.4751337026;
    double WTrIQRm = 59206.284349799185;
    bool oNrykLToLaAnAV = true;

    for (int RUcTnvMUHZo = 390696585; RUcTnvMUHZo > 0; RUcTnvMUHZo--) {
        ugMrdyeLa += ueLMBmO;
    }

    for (int HsEWwRObiyZ = 842728312; HsEWwRObiyZ > 0; HsEWwRObiyZ--) {
        MWoXwFeex = MWoXwFeex;
    }

    if (ueLMBmO >= string("YUyjunmDjZNdmhlOdrAYCxphVFfQCUlzUqfzcwtXkKMYrGjCxWphBHaBUJjwTBlSqJDOhAciRgdcUWQYagvaarNNyrjsnemuvkebPQDKYeIHgGOoreMHgfYOYieJeFJTjxMctQTDTHZUVSIjyhyGMXjbXQZvqRFqfxPBps")) {
        for (int MzLLqApMzQsukKi = 1760953587; MzLLqApMzQsukKi > 0; MzLLqApMzQsukKi--) {
            ugMrdyeLa += ugMrdyeLa;
        }
    }

    return WTrIQRm;
}

double kPExSDmprCDoWrEv::JsesZlKHlmQGdoi(int eBhVGqEv, int SNZXxukqh, double nFvleSHIx, int BuKitCok, int TTxHerCmkFzdYNNB)
{
    int XdEUWXch = -979715126;
    double LTxbmF = -589752.0965150101;
    bool qFoRbEyxdmYOmVI = true;

    for (int RsCrtKaXqBp = 1859660403; RsCrtKaXqBp > 0; RsCrtKaXqBp--) {
        qFoRbEyxdmYOmVI = ! qFoRbEyxdmYOmVI;
        TTxHerCmkFzdYNNB /= eBhVGqEv;
        LTxbmF += nFvleSHIx;
    }

    if (XdEUWXch > 2133300461) {
        for (int KcxsB = 1175034586; KcxsB > 0; KcxsB--) {
            nFvleSHIx *= LTxbmF;
            eBhVGqEv = TTxHerCmkFzdYNNB;
            TTxHerCmkFzdYNNB /= XdEUWXch;
            XdEUWXch -= SNZXxukqh;
            qFoRbEyxdmYOmVI = ! qFoRbEyxdmYOmVI;
        }
    }

    for (int PmVpSoLwWw = 1681943540; PmVpSoLwWw > 0; PmVpSoLwWw--) {
        XdEUWXch *= BuKitCok;
        BuKitCok *= BuKitCok;
        LTxbmF /= LTxbmF;
        LTxbmF = nFvleSHIx;
    }

    return LTxbmF;
}

bool kPExSDmprCDoWrEv::zoJdBdTFJbJRkp(double msQNZvkrEXPG, string AsTcWUE, int EkaqjCqDYPFfrr, string fiGhgihvULjjmVnD)
{
    bool nnapaVaVndt = false;
    int KGVtdbnpSf = -1361641493;
    int PVVGMqZyTbXIZK = -95035331;

    for (int eYHITFECkGY = 1437503038; eYHITFECkGY > 0; eYHITFECkGY--) {
        fiGhgihvULjjmVnD += fiGhgihvULjjmVnD;
        KGVtdbnpSf -= EkaqjCqDYPFfrr;
        KGVtdbnpSf /= EkaqjCqDYPFfrr;
    }

    if (EkaqjCqDYPFfrr == -1448858516) {
        for (int KURlUhGURCy = 1957532038; KURlUhGURCy > 0; KURlUhGURCy--) {
            AsTcWUE += AsTcWUE;
            KGVtdbnpSf -= PVVGMqZyTbXIZK;
            PVVGMqZyTbXIZK -= KGVtdbnpSf;
        }
    }

    for (int peAFnSgcaZRidG = 122083126; peAFnSgcaZRidG > 0; peAFnSgcaZRidG--) {
        KGVtdbnpSf /= KGVtdbnpSf;
        AsTcWUE += fiGhgihvULjjmVnD;
    }

    return nnapaVaVndt;
}

bool kPExSDmprCDoWrEv::AFAiX(string dZRDeSHTauSqbHif, string kMBzvk, string uuxCuKnApklgWK, bool ImQzZTFYkoPLR)
{
    double LfbGniynQZivWJ = -253086.49295575154;
    string gJGKXaPxvcp = string("MSvxCgmNisNkoziRLzWBkBCcgQVEsrKoAnpyXCoFAOyfuxdVAJppISRRQPphgLriIZSFkrSWYlXtixhovIMiubRZxBiWyCDrvxcBmzeSukseENmBlerrvCePdORbML");
    double xRDCZ = -385931.1482410329;

    if (dZRDeSHTauSqbHif <= string("ZgjCLZEXyTvDuzQCcZIJgyUiigoQcvLcSsSVJVPzDzHToKlpVrTOIutLXmHXSnoOheClfSUfgORDBIuIZGGAjEACEnzBOKtgxCmPdomhqBhGTbZIcqtkKHRaefFHiLuaLaIStKibhpsREJaXcIvOOxJKxsjBelDTlqVOqLNyjvHvTrnzfpyaTURNEqtdZrIQlfhNZcYduRaEYXWGnuHnpVMtvRLIdUAEwrxSZSWLNqqptPlhNCZNzgEcAiT")) {
        for (int wQeQOmwSQRRU = 809936667; wQeQOmwSQRRU > 0; wQeQOmwSQRRU--) {
            uuxCuKnApklgWK += kMBzvk;
            kMBzvk = kMBzvk;
        }
    }

    for (int DiUtEnaPGF = 120782790; DiUtEnaPGF > 0; DiUtEnaPGF--) {
        kMBzvk += dZRDeSHTauSqbHif;
    }

    if (kMBzvk == string("jXhARSNphsHdvBmpkjBUZUzvSrqftalXvXcbbjmwSWKGlxPzcTRbJZfBegipnSAyNqBgVKxeJkWffKAPBZMApaLDCZCdedDaeKDiDaVaIfumYRQxVszxYKidXBotCfgjdzqyfcZClchXn")) {
        for (int nmZYjscpvyfwbwqO = 1431556237; nmZYjscpvyfwbwqO > 0; nmZYjscpvyfwbwqO--) {
            uuxCuKnApklgWK += kMBzvk;
            dZRDeSHTauSqbHif = dZRDeSHTauSqbHif;
            dZRDeSHTauSqbHif += uuxCuKnApklgWK;
            uuxCuKnApklgWK += gJGKXaPxvcp;
            uuxCuKnApklgWK += uuxCuKnApklgWK;
            gJGKXaPxvcp = kMBzvk;
            dZRDeSHTauSqbHif += kMBzvk;
        }
    }

    for (int emMEmKErvSxMA = 778018608; emMEmKErvSxMA > 0; emMEmKErvSxMA--) {
        continue;
    }

    for (int sbTAHEnl = 2118904339; sbTAHEnl > 0; sbTAHEnl--) {
        gJGKXaPxvcp += gJGKXaPxvcp;
        uuxCuKnApklgWK += dZRDeSHTauSqbHif;
    }

    return ImQzZTFYkoPLR;
}

bool kPExSDmprCDoWrEv::ibTtrLE(double IbTIebPT, int siQdyWNhEEwoYxJf, bool yczQuQneVxzxFzpM, string oaKYhoCdGZ, int ACnJPuO)
{
    int sEGXsUP = -1356252462;
    int kPbRSJKYCa = 216721587;
    int ZPqUQWxhuGPsAh = -932009668;
    bool BsIprlQCF = false;
    string VPjYrkky = string("NOcyhSixhpjedvsWrdNTBNMohhkVniqGqlblifzRijQygghkxBnAiNTFlDLuDVbWWEDmhDfSzrjHhjXlvljQbfNRsGMlDFIrnFtGvyvbkKJe");
    int JwtUDowGOfQxp = 1993569343;
    string nCLNamrgLJWJJR = string("KbrIHQNniIArbQKwghTAUCOVOoH");
    int cUohYNFtdui = -1463194147;
    int wBJrkNcUf = 1710213598;
    bool puFqWRTVmbSzFOQL = false;

    for (int tfxKPWfEApFtESg = 346104568; tfxKPWfEApFtESg > 0; tfxKPWfEApFtESg--) {
        ACnJPuO /= cUohYNFtdui;
    }

    for (int NQtLfYNYAb = 1580430949; NQtLfYNYAb > 0; NQtLfYNYAb--) {
        JwtUDowGOfQxp *= ZPqUQWxhuGPsAh;
    }

    for (int vqRhXUtnTUfg = 1582961412; vqRhXUtnTUfg > 0; vqRhXUtnTUfg--) {
        wBJrkNcUf -= kPbRSJKYCa;
    }

    if (nCLNamrgLJWJJR != string("KbrIHQNniIArbQKwghTAUCOVOoH")) {
        for (int gFJonlUZnStpvgWz = 1505138716; gFJonlUZnStpvgWz > 0; gFJonlUZnStpvgWz--) {
            JwtUDowGOfQxp -= sEGXsUP;
            ACnJPuO /= cUohYNFtdui;
        }
    }

    for (int PwwpcsAqSbauPxD = 902845360; PwwpcsAqSbauPxD > 0; PwwpcsAqSbauPxD--) {
        siQdyWNhEEwoYxJf += siQdyWNhEEwoYxJf;
        siQdyWNhEEwoYxJf /= cUohYNFtdui;
        nCLNamrgLJWJJR += oaKYhoCdGZ;
    }

    return puFqWRTVmbSzFOQL;
}

double kPExSDmprCDoWrEv::QXZwVR(double psgwHAkaYvrvjnb, int PDyHQDYwHPJufgC)
{
    string oCeaFviibFPBJ = string("oGXJRByaNRGsyHvwdchTOhBMJiVuYNQQvwlekcgiamMhjySLFGOOQpyqqIsOzLedkqlCasNeHEjyOvYFOWPgbsJzRqaZoTIbwBOfEqdzyvOfJ");
    int TZWryYNTWVvue = 1926000112;
    int bUWjrjICgCviq = -329617812;
    int hKEpnVe = 1230706117;
    string GTNzdkmPsQ = string("KGMyjVNLTBwzwZiBVigAbbElNeagLPCQKPaBIBKOvCOTxxoqSpFNdcPcNdxhVwTljvjKiLeAvGUYBdDQZgMFGpaWsVfXySOsJDAJVaowNlrVUUPvlKMihTjeceBwARfnxqyvqikCvJrvGJRwWaOEWLEyEibkNWTKMuKkeAVi");
    double tHWnkNL = 395519.56976826076;
    string RNGuZVZfya = string("lfWOjjpCVWxgILJGHiXKZJJWKPsmfbpQdz");

    if (PDyHQDYwHPJufgC < 1926000112) {
        for (int SUIiztUXFNqFv = 2130653252; SUIiztUXFNqFv > 0; SUIiztUXFNqFv--) {
            psgwHAkaYvrvjnb -= psgwHAkaYvrvjnb;
            GTNzdkmPsQ = RNGuZVZfya;
            hKEpnVe /= TZWryYNTWVvue;
            oCeaFviibFPBJ += GTNzdkmPsQ;
        }
    }

    for (int JgsxJVnEjCdc = 1932513968; JgsxJVnEjCdc > 0; JgsxJVnEjCdc--) {
        continue;
    }

    if (tHWnkNL >= 77128.95499137224) {
        for (int ksLheDTm = 372770161; ksLheDTm > 0; ksLheDTm--) {
            RNGuZVZfya += RNGuZVZfya;
            TZWryYNTWVvue *= PDyHQDYwHPJufgC;
            oCeaFviibFPBJ = oCeaFviibFPBJ;
        }
    }

    return tHWnkNL;
}

bool kPExSDmprCDoWrEv::qdNCTnZLxgBiTzf(bool wKjvufxKFEjlfawI, double faFbHn, bool gAVnwwoHOpUQN, bool xrdYnhJ)
{
    int OjRcjVmqvJhTkz = -303067173;
    int ozFuGLERvY = -2065034671;
    double yngkHkKyhocHmZg = 574620.1604530837;
    string NdnPEjuKbIW = string("mXlCwfJQRWHV");
    int HefZVmnxRx = -423520488;
    string NfPyc = string("gnInKjKnomNafneVPQevbSUOylvsNNginFxbmdNDKEbjNUCciOQxrBItBvoobCJcWtpBmXt");
    string XAvEMdAeZ = string("VEqpqodospGIUIozCUaEBtApFnnUmHGphhtltJNmMCjOWcDoLBHdMMKReLynxtoDRpitdMhTYOpIfGtrUhzRjEhRpeEPEDUEbsamEeJcfhyhXDRTvEVepRaKozuurAwYzsBzYSMtHrNyikcRUYjgiJuLlCPkAaxUbrXwfNHwLbZJeXifFJPwNlgYbedGYYGhJjsPeTslUxtbdFoJVWbTuicRCKiLLxAw");
    int dzCJOAfXlpxPSlh = -2097291812;
    bool vXYtxLzFUW = false;
    bool xNBIMVFWFeu = true;

    for (int RMXFrmVNuUmq = 540947145; RMXFrmVNuUmq > 0; RMXFrmVNuUmq--) {
        NfPyc += NdnPEjuKbIW;
    }

    for (int hTRyPYlyQjfeHvv = 1835117205; hTRyPYlyQjfeHvv > 0; hTRyPYlyQjfeHvv--) {
        wKjvufxKFEjlfawI = ! xNBIMVFWFeu;
    }

    for (int sYBMvau = 131920672; sYBMvau > 0; sYBMvau--) {
        continue;
    }

    for (int LSpFduv = 1967893436; LSpFduv > 0; LSpFduv--) {
        continue;
    }

    return xNBIMVFWFeu;
}

kPExSDmprCDoWrEv::kPExSDmprCDoWrEv()
{
    this->oRCCdS();
    this->TtzxOPLeDT();
    this->zNUnZ(string("uBHQlayiPyAIleyOlIaUemfIpWeUSaJfQIVOJCzloQIFHLPUpROZDtuudaTHipiSyZLkKbientftHkvzRZoSzSlfrjwReipBFhxeWMRFeBjWFBOPclSDJokkEthkmOtDPeWkgVZHQuEUaNEyvIpzDzeCtIna"), 68837223, false, string("YUyjunmDjZNdmhlOdrAYCxphVFfQCUlzUqfzcwtXkKMYrGjCxWphBHaBUJjwTBlSqJDOhAciRgdcUWQYagvaarNNyrjsnemuvkebPQDKYeIHgGOoreMHgfYOYieJeFJTjxMctQTDTHZUVSIjyhyGMXjbXQZvqRFqfxPBps"));
    this->JsesZlKHlmQGdoi(2133300461, -991407859, 1006574.0139534948, -249548380, 1052310057);
    this->zoJdBdTFJbJRkp(793270.6566769144, string("xupaiAJtJvYcMZpIvENCxBRFCcRIpkLfBoiouNTJqHQDnpqKhfewaOvrXst"), -1448858516, string("QdlcVwxijbpbyxfIMKOHasxgLJvkrUNVECVudMSryJPvrqIQdsWNSOdlwCzPYAAVFKsuvDdPBsFSwxffMaJeKATdlOIGuIKMTpOGxbUe"));
    this->AFAiX(string("jXhARSNphsHdvBmpkjBUZUzvSrqftalXvXcbbjmwSWKGlxPzcTRbJZfBegipnSAyNqBgVKxeJkWffKAPBZMApaLDCZCdedDaeKDiDaVaIfumYRQxVszxYKidXBotCfgjdzqyfcZClchXn"), string("XkQxqAjzlsHFFdDpSUlIFJAvduIUOkfjRycyJYesKQHsaeIgKvgzuRnDdBmtbUVzNbAsBXjbEInSxbViatTehFwMdstwKBxIlHDUvEgFwgZvIMNEOnJyarPGnKfAmFLYtOFjLtqLZxRjQbkCcpJSfIZBfgsbMyMbFNkAgCaFiSWLmWheGUJqWTynBYXzdmVsXjcHfJBLPwXeauPOFdxZLEjgmfWtjgyYjpjUO"), string("ZgjCLZEXyTvDuzQCcZIJgyUiigoQcvLcSsSVJVPzDzHToKlpVrTOIutLXmHXSnoOheClfSUfgORDBIuIZGGAjEACEnzBOKtgxCmPdomhqBhGTbZIcqtkKHRaefFHiLuaLaIStKibhpsREJaXcIvOOxJKxsjBelDTlqVOqLNyjvHvTrnzfpyaTURNEqtdZrIQlfhNZcYduRaEYXWGnuHnpVMtvRLIdUAEwrxSZSWLNqqptPlhNCZNzgEcAiT"), false);
    this->ibTtrLE(-800664.6946215042, -409894297, true, string("nraBwNCPiJgUiBxg"), -1359584532);
    this->QXZwVR(77128.95499137224, 415053850);
    this->qdNCTnZLxgBiTzf(true, -358848.3146915825, false, true);
}
