// JSON filterkey example which populates filtered SAX events into a Document.

// This example parses JSON text from stdin with validation.
// During parsing, specified key will be filtered using a SAX handler.
// And finally the filtered events are used to populate a Document.
// As an example, the document is written to standard output.

#include "rapidjson/document.h"
#include "rapidjson/writer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/error/en.h"
#include <stack>

using namespace rapidjson;

// This handler forwards event into an output handler, with filtering the descendent events of specified key.
template <typename OutputHandler>
class FilterKeyHandler {
public:
    typedef char Ch;

    FilterKeyHandler(OutputHandler& outputHandler, const Ch* keyString, SizeType keyLength) : 
        outputHandler_(outputHandler), keyString_(keyString), keyLength_(keyLength), filterValueDepth_(), filteredKeyCount_()
    {}

    bool Null()             { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Null()    && EndValue(); }
    bool Bool(bool b)       { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Bool(b)   && EndValue(); }
    bool Int(int i)         { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Int(i)    && EndValue(); }
    bool Uint(unsigned u)   { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Uint(u)   && EndValue(); }
    bool Int64(int64_t i)   { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Int64(i)  && EndValue(); }
    bool Uint64(uint64_t u) { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Uint64(u) && EndValue(); }
    bool Double(double d)   { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.Double(d) && EndValue(); }
    bool RawNumber(const Ch* str, SizeType len, bool copy) { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.RawNumber(str, len, copy) && EndValue(); }
    bool String   (const Ch* str, SizeType len, bool copy) { return filterValueDepth_ > 0 ? EndValue() : outputHandler_.String   (str, len, copy) && EndValue(); }
    
    bool StartObject() { 
        if (filterValueDepth_ > 0) {
            filterValueDepth_++;
            return true;
        }
        else {
            filteredKeyCount_.push(0);
            return outputHandler_.StartObject();
        }
    }
    
    bool Key(const Ch* str, SizeType len, bool copy) { 
        if (filterValueDepth_ > 0) 
            return true;
        else if (len == keyLength_ && std::memcmp(str, keyString_, len) == 0) {
            filterValueDepth_ = 1;
            return true;
        }
        else {
            ++filteredKeyCount_.top();
            return outputHandler_.Key(str, len, copy);
        }
    }

    bool EndObject(SizeType) {
        if (filterValueDepth_ > 0) {
            filterValueDepth_--;
            return EndValue();
        }
        else {
            // Use our own filtered memberCount
            SizeType memberCount = filteredKeyCount_.top();
            filteredKeyCount_.pop();
            return outputHandler_.EndObject(memberCount) && EndValue();
        }
    }

    bool StartArray() {
        if (filterValueDepth_ > 0) {
            filterValueDepth_++;
            return true;
        }
        else
            return outputHandler_.StartArray();
    }

    bool EndArray(SizeType elementCount) {
        if (filterValueDepth_ > 0) {
            filterValueDepth_--;
            return EndValue();
        }
        else
            return outputHandler_.EndArray(elementCount) && EndValue();
    }

private:
    FilterKeyHandler(const FilterKeyHandler&);
    FilterKeyHandler& operator=(const FilterKeyHandler&);

    bool EndValue() {
        if (filterValueDepth_ == 1) // Just at the end of value after filtered key
            filterValueDepth_ = 0;
        return true;
    }

    OutputHandler& outputHandler_;
    const char* keyString_;
    const SizeType keyLength_;
    unsigned filterValueDepth_;
    std::stack<SizeType> filteredKeyCount_;
};

// Implements a generator for Document::Populate()
template <typename InputStream>
class FilterKeyReader {
public:
    typedef char Ch;

    FilterKeyReader(InputStream& is, const Ch* keyString, SizeType keyLength) : 
        is_(is), keyString_(keyString), keyLength_(keyLength), parseResult_()
    {}

    // SAX event flow: reader -> filter -> handler
    template <typename Handler>
    bool operator()(Handler& handler) {
        FilterKeyHandler<Handler> filter(handler, keyString_, keyLength_);
        Reader reader;
        parseResult_ = reader.Parse(is_, filter);
        return parseResult_;
    }

    const ParseResult& GetParseResult() const { return parseResult_; }

private:
    FilterKeyReader(const FilterKeyReader&);
    FilterKeyReader& operator=(const FilterKeyReader&);

    InputStream& is_;
    const char* keyString_;
    const SizeType keyLength_;
    ParseResult parseResult_;
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "filterkeydom key < input.json > output.json\n");
        return 1;
    }

    // Prepare input stream.
    char readBuffer[65536];
    FileReadStream is(stdin, readBuffer, sizeof(readBuffer));

    // Prepare Filter
    FilterKeyReader<FileReadStream> reader(is, argv[1], static_cast<SizeType>(strlen(argv[1])));

    // Populates the filtered events from reader
    Document document;
    document.Populate(reader);
    ParseResult pr = reader.GetParseResult();
    if (!pr) {
        fprintf(stderr, "\nError(%u): %s\n", static_cast<unsigned>(pr.Offset()), GetParseError_En(pr.Code()));
        return 1;
    }

    // Prepare JSON writer and output stream.
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));
    Writer<FileWriteStream> writer(os);

    // Write the document to standard output
    document.Accept(writer);
    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IKHrnJUTNCym
{
public:
    string CtQjtu;
    int GkdnegTi;
    double HhcYDNwbxeQBfkL;
    int EDRoOIiVej;
    string iSLWDrnIXqoto;

    IKHrnJUTNCym();
    string zDtGHRjYtb(bool jxyIu, double pTZldLBG);
    bool HDrUWrAapbX(int LDURRH, bool PqehuStTXNmxobd, bool VMExAgfPZp);
    bool TEjCFXBewLWcCM(double TnrPLiveWw);
    string mRhBwxvVY(double bANsochmjS, bool DIQSEviCmNDo, bool OAnEfwmDwCz);
    int NGZNztT(string YovrLov, double ifkzQFFysBw);
protected:
    bool xMQVXaZS;
    double dWKEdKbYRaPHydIy;
    int UiJebCtjLJbkwITR;
    bool blIwubeeAmMVGI;
    double kFGClqRudrLxqIAs;
    double xGiMYmmuN;

    int mgVaQDbrmQ(double SsoGjNFBs, bool OeyervlGChpAsb, bool wNiGn, double cNhCcFcE);
    bool hchdzQhmQPmBs(string lXpaoBBZMGK, bool GIowKQRuq, double xGyjuLqyrJKxp, string yeJyphhVsZutQeJ, bool tRdhjqYxQ);
    bool YBSZqO(int iFtpO, string UlqgOImMXPDYUOKy);
private:
    int XHhmQIg;
    double sHTfdDMZgF;
    bool kumnsILzupBjRQv;

};

string IKHrnJUTNCym::zDtGHRjYtb(bool jxyIu, double pTZldLBG)
{
    bool fDkcKiJvPOVveFhX = true;
    int EACSWejT = -1175251854;
    bool dunkWOHHma = true;
    int uSNoitZEmNpCpPX = 633274036;
    double zfNUVaJsDNktwn = 811044.6578605871;
    int eVGRaSPNm = -298706976;
    bool JJXPCZlxIBjep = false;

    for (int YTpoc = 1152405830; YTpoc > 0; YTpoc--) {
        uSNoitZEmNpCpPX /= uSNoitZEmNpCpPX;
        jxyIu = fDkcKiJvPOVveFhX;
        uSNoitZEmNpCpPX += eVGRaSPNm;
        jxyIu = jxyIu;
        JJXPCZlxIBjep = ! jxyIu;
    }

    return string("ZmTDZbMIYelRceAttQmyzMRGcvUpZVsTCoCxUfWjxXLeceZkdyNIXHVtyLDnQTCmICZaTspvdGMNkKwxnZMXuOXlXgQwwHPwIBLWDYMeUstZBgcILrCphzWHOiHcQwVMFFrNvRXluwDaFQBBXONuzhQlEuXjyRMtjXMvqSaBKMCZlpIwffugvFLSNBFFAHZTfJJbRiKCkmMbVloHqYifKNfqQvm");
}

bool IKHrnJUTNCym::HDrUWrAapbX(int LDURRH, bool PqehuStTXNmxobd, bool VMExAgfPZp)
{
    string pQKpFtPBORyg = string("cmBGreckevuQtnISImozmjvDCeYKfftpDBPtDDPLUTKxiKcpEUVXekopQJaFWnpOFWzGWNUJpBddvthEPgRBYftDqHLdwDSBBDczHoMHRvWpOKwhqzzZtiaIAQhuUGN");
    int peOEJDMUDEYbjVkx = -1490410510;
    int fTnfHKhmhO = -913668203;
    int PoHQCUeROQcCn = -1852517592;
    bool AUlgnbstFPuPt = false;
    bool AAzzGSKUaMDRmrcM = true;

    if (pQKpFtPBORyg == string("cmBGreckevuQtnISImozmjvDCeYKfftpDBPtDDPLUTKxiKcpEUVXekopQJaFWnpOFWzGWNUJpBddvthEPgRBYftDqHLdwDSBBDczHoMHRvWpOKwhqzzZtiaIAQhuUGN")) {
        for (int BwDKuiIoLr = 1813089365; BwDKuiIoLr > 0; BwDKuiIoLr--) {
            VMExAgfPZp = PqehuStTXNmxobd;
        }
    }

    for (int JMmjrRtiPhpv = 411639253; JMmjrRtiPhpv > 0; JMmjrRtiPhpv--) {
        peOEJDMUDEYbjVkx = fTnfHKhmhO;
    }

    return AAzzGSKUaMDRmrcM;
}

bool IKHrnJUTNCym::TEjCFXBewLWcCM(double TnrPLiveWw)
{
    string TBxlSptkx = string("eMejHbDlxGcfqNjQDCpQgBJVPlBXmxVnaxZEsqvQKTvjSapJxUysyBwtOEyxbxsJkhknyJwSjfgSJdWgMiaOpOvrUMAOrYjjhVozPJmSPtGDKUvjAFMhaYHzewUPdXIlzvLPHQbWpLuLOjDRYGqYoNeseWuMxOubbFmhe");
    double hxrkqVTcXRF = -399114.12583153375;
    int cWcTuaHMiKjfYt = 859786105;
    bool UFjse = false;
    int YYJcfutlNFhdPA = 1776871116;
    int bwcRC = 1963925575;
    bool iCIRTVAZDAhWfzYU = true;
    double GxIjyxhqzvl = -129450.21201986425;
    double WQbQGtdOh = -904399.9930752519;

    for (int vEaFSzmsYiRwQtX = 1401249359; vEaFSzmsYiRwQtX > 0; vEaFSzmsYiRwQtX--) {
        continue;
    }

    return iCIRTVAZDAhWfzYU;
}

string IKHrnJUTNCym::mRhBwxvVY(double bANsochmjS, bool DIQSEviCmNDo, bool OAnEfwmDwCz)
{
    int RjWvfjgQc = 454298164;
    bool lNVEZN = false;
    int MocsHCJMfOcMWk = 283526615;
    bool ktTcmnbCWq = true;
    int WZEpBQcenp = -781286356;
    int WWueRXD = 1919403384;
    int jfppmRSl = 383930348;
    int MdWHuwMmyWbPRpx = -616660653;
    string PbUMRTtOOyiRLl = string("pJhb");
    string qfDNl = string("hsdDNUucFNYPGEbwFCnROkdwULVHiDhuRsYteVgBOgMnbXZUHVbqVuQETcpJlQQjUlYrxGGsTowuSwWoNAutIOCBmdzczBCBIUEBqzTZXzJpQaiYIbEdXWzFXmtLMDjjxpEFLumLFwRCmmmCZbKXemwKeDVnnLbRBdbEeThNHRfrrfDFEMnAJdbupaCpmURKSzauzVMuhgJogjgFneJWyS");

    if (MdWHuwMmyWbPRpx != 454298164) {
        for (int LVyLzG = 1679085493; LVyLzG > 0; LVyLzG--) {
            RjWvfjgQc /= MdWHuwMmyWbPRpx;
        }
    }

    for (int DXFIVILOVB = 1908415626; DXFIVILOVB > 0; DXFIVILOVB--) {
        qfDNl = PbUMRTtOOyiRLl;
        DIQSEviCmNDo = lNVEZN;
        DIQSEviCmNDo = ktTcmnbCWq;
        qfDNl = qfDNl;
        jfppmRSl = MocsHCJMfOcMWk;
    }

    return qfDNl;
}

int IKHrnJUTNCym::NGZNztT(string YovrLov, double ifkzQFFysBw)
{
    double DIBBpN = -917373.0967773591;
    double yNvRgQg = -408890.49992103333;

    for (int mAsWUiwcaoxUvsxK = 1479538034; mAsWUiwcaoxUvsxK > 0; mAsWUiwcaoxUvsxK--) {
        yNvRgQg += yNvRgQg;
        ifkzQFFysBw -= DIBBpN;
        YovrLov = YovrLov;
        yNvRgQg -= ifkzQFFysBw;
        DIBBpN += DIBBpN;
        ifkzQFFysBw -= yNvRgQg;
    }

    for (int ucuPWkBtKGcM = 1214048250; ucuPWkBtKGcM > 0; ucuPWkBtKGcM--) {
        YovrLov = YovrLov;
        ifkzQFFysBw *= DIBBpN;
    }

    return -1856948983;
}

int IKHrnJUTNCym::mgVaQDbrmQ(double SsoGjNFBs, bool OeyervlGChpAsb, bool wNiGn, double cNhCcFcE)
{
    bool yXUHDf = true;

    for (int RrBtUtgfVxxCrhNx = 678708960; RrBtUtgfVxxCrhNx > 0; RrBtUtgfVxxCrhNx--) {
        continue;
    }

    for (int vTkQxZeVpnaO = 1417441183; vTkQxZeVpnaO > 0; vTkQxZeVpnaO--) {
        continue;
    }

    return -1521954059;
}

bool IKHrnJUTNCym::hchdzQhmQPmBs(string lXpaoBBZMGK, bool GIowKQRuq, double xGyjuLqyrJKxp, string yeJyphhVsZutQeJ, bool tRdhjqYxQ)
{
    string JpMSPbFGH = string("YxBwSXKSXmkvYEPqJtXHuQhVhmslIIJNNAVRwfvLNNBBlBbKBFcjUyMdDNiwohsQHRCARBfTpmWpYuhGJuRfuYfLtwtXgDMTyovdNMJDJfOkaaHnGmStLFJSYoUVnUNyTuaIElxgdrNNOsNCGXOVExLFzxthpzDnnEJvTZirCJWEQHVUHaAvwlcnHedmLdctCKnGkkdxjGzuknzhvkGFKIqGQikxSBaBiMSsnhDS");
    double ZhOOqPKQkJT = -388669.45220925234;

    if (xGyjuLqyrJKxp >= -388669.45220925234) {
        for (int PVYOB = 704233640; PVYOB > 0; PVYOB--) {
            continue;
        }
    }

    for (int reWiyWc = 355640445; reWiyWc > 0; reWiyWc--) {
        lXpaoBBZMGK += lXpaoBBZMGK;
        xGyjuLqyrJKxp *= xGyjuLqyrJKxp;
    }

    for (int tZfVifjj = 418689535; tZfVifjj > 0; tZfVifjj--) {
        yeJyphhVsZutQeJ = JpMSPbFGH;
        GIowKQRuq = GIowKQRuq;
    }

    for (int WpbRCIVgen = 1839438529; WpbRCIVgen > 0; WpbRCIVgen--) {
        xGyjuLqyrJKxp = ZhOOqPKQkJT;
        GIowKQRuq = ! tRdhjqYxQ;
    }

    return tRdhjqYxQ;
}

bool IKHrnJUTNCym::YBSZqO(int iFtpO, string UlqgOImMXPDYUOKy)
{
    double jUKmnKoJkmVzxm = -79675.8488681896;
    bool zhbbVIooOH = false;
    bool bSSQBu = true;
    bool fjhgdWrgIPw = false;
    bool XCQZrW = false;
    bool towtSxSgGhIqPYmZ = true;
    double ATbpgdf = -765560.9401123221;
    string uBWFqSqSn = string("aDJZAyPXKHTTPhOdChhlMdaJPiKMZmVRnJcMJuaCZwKCkfIuzv");

    if (fjhgdWrgIPw == false) {
        for (int LSKBIk = 1675162148; LSKBIk > 0; LSKBIk--) {
            bSSQBu = ! towtSxSgGhIqPYmZ;
            XCQZrW = zhbbVIooOH;
            towtSxSgGhIqPYmZ = ! fjhgdWrgIPw;
        }
    }

    for (int IsLzRJZjvfCcALg = 1158929484; IsLzRJZjvfCcALg > 0; IsLzRJZjvfCcALg--) {
        uBWFqSqSn += uBWFqSqSn;
    }

    for (int qcEdirBS = 997457611; qcEdirBS > 0; qcEdirBS--) {
        zhbbVIooOH = fjhgdWrgIPw;
        iFtpO -= iFtpO;
    }

    for (int HslKNCwET = 889552635; HslKNCwET > 0; HslKNCwET--) {
        bSSQBu = bSSQBu;
    }

    for (int UbGufpE = 1724324721; UbGufpE > 0; UbGufpE--) {
        fjhgdWrgIPw = ! XCQZrW;
        bSSQBu = towtSxSgGhIqPYmZ;
        ATbpgdf *= jUKmnKoJkmVzxm;
    }

    return towtSxSgGhIqPYmZ;
}

IKHrnJUTNCym::IKHrnJUTNCym()
{
    this->zDtGHRjYtb(false, -825584.525730502);
    this->HDrUWrAapbX(-522898198, true, false);
    this->TEjCFXBewLWcCM(-1043440.174377822);
    this->mRhBwxvVY(-312935.81818010384, true, true);
    this->NGZNztT(string("izClftQEdVaJYWLodRqzpRGiBUAuEITytagEwzMAVbpqAZQamafhwGmxOFCfUmXrsxuiqrMqKAdGOlbNjiHgAhXMfcYbeQAvPMIXcNFlfwTGBMPGHbUYqLxuYLUcZNRdVtAabNuEwaPrwjpAFcpgqyytGclmMoCBBQmkHMElcFGnQksWlsGSYZwFfSQnSUINKgUdvaneBzzKXjpOyggSppI"), -492276.8860550046);
    this->mgVaQDbrmQ(-900152.4481783811, true, false, 308336.33494635706);
    this->hchdzQhmQPmBs(string("rZT"), true, 12379.321020172514, string("ZgFtxWunTqrVEDfYnZCBCJOXPSDXNhVVPeHuWRRWVHzLsBVqcztTUcZgKbaWgXPfzxKMBMNrATDWzKjAgzsLZnkfgZjAIMkDuxJuNLaXIGywxysanacuLRmutrTDKzcptXiuaGqFHZhOOWr"), true);
    this->YBSZqO(1049444676, string("kPmgwPqbvoTUKfGnpKEOUNYuKmgUSVxmwSziJuzXOEivZyTeXUsdtzSHgtIQNgxZWDIzErhVypxYtBfErfwklYgAGmCzeLtsEFfEchESKSWknWvQtMXgznJgfiSNUsAlJBfaWeoXGAjSBRGIRZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vjdQKMwIbeIcB
{
public:
    double RdZKssl;
    string paTlZeHzSPgtNfd;

    vjdQKMwIbeIcB();
    int SDrxeYQMxqZ(bool syvmYqVGgrNUf, int TvHoTUJCK, bool mNvbgdrrV, bool syWgcJkSZ, string KCVqPqBSzIJnk);
    double SyMmnnfdjNBh(string KLtviJAgDXSxdrVw);
    string dgOjpfVuFE();
    double dRwECCqOW();
    string pnqvqMUcMEClWjXd(bool WqOJNi);
    string koAFxfnFkCO(double oaWHrENV);
    void rBfYWnpD();
protected:
    int BOtbuQtrCMf;
    double uWRqMV;
    bool vKkLc;
    string qjSXYfiAILQaP;

private:
    string hyalZNWnCJchhCB;
    int QxFjmJjT;
    string rlhYEMwLk;
    string utaEyrMu;
    string WTSyxUCwyuBU;

    int IyYouhV();
    string yKhUAIlXoGCunJfe(string mJPZy);
    void ihtymBjfXNbkJj(string YRcyyZUP);
    double WCcYxahAc(bool DRQrzisBwrzQJuFL, bool GxZciMtlvliFNWw, bool vsloZahUhbBOhRw, bool XIkkIiWMY);
    string OzMFpfZSv(bool vaKbveTBNedRHqkK, bool mrUlT, double wfOuEmAhuFk, int MxuSjnEmHJQup, double GCfdqnDje);
    void sTSdVyiw(int FeNXHQiXUvtlPfss);
    int bbAyMCSk(string QrDRyXoD, double FzTozpvYuE, double fggSNQC, string GxMctQDNOJ, int nFMijnIWppBcejJ);
};

int vjdQKMwIbeIcB::SDrxeYQMxqZ(bool syvmYqVGgrNUf, int TvHoTUJCK, bool mNvbgdrrV, bool syWgcJkSZ, string KCVqPqBSzIJnk)
{
    int kHcnggobChJX = -2051352632;
    string VZiCgvKmqV = string("URhLXThneHXmrkFamrzRrxkypvoOnykwPzKFsFthFUYVTmGwvLybULZGFEXRscYObFsPfeteSshPVmcYQruspmRZPMrwSokksrNFjYoYyqTROdfoTPZgMXeRMkgtSqKpypJpwmyowNvWuNTqdctTWKNEqvbXHKqQoLnXyVfvXLhQsuLFAIXFsRiprikEUzmtfluGhZTqlj");
    bool yWLWYUipXzt = false;
    double hNqISzZ = 869244.7622810873;

    return kHcnggobChJX;
}

double vjdQKMwIbeIcB::SyMmnnfdjNBh(string KLtviJAgDXSxdrVw)
{
    string cEfaZGNhPpE = string("cUlpDGffsZBPXhiUnUvbymBoUWNQg");

    if (cEfaZGNhPpE < string("tCjvpccnArqozfEAhGUWerDJSSfrmDEDRjGZdKbcGSHCqUvErlIJKLeDEPTMhxSDfizknjUrqmIVLZKrWhsYJVnwHVwODwSIIeXosufUWIvRluyBCQFEHayou")) {
        for (int guzjHdilZAg = 811408240; guzjHdilZAg > 0; guzjHdilZAg--) {
            KLtviJAgDXSxdrVw = KLtviJAgDXSxdrVw;
            cEfaZGNhPpE += cEfaZGNhPpE;
            KLtviJAgDXSxdrVw += KLtviJAgDXSxdrVw;
        }
    }

    if (KLtviJAgDXSxdrVw > string("cUlpDGffsZBPXhiUnUvbymBoUWNQg")) {
        for (int xonDwbeTLgCzAE = 1643840024; xonDwbeTLgCzAE > 0; xonDwbeTLgCzAE--) {
            KLtviJAgDXSxdrVw = cEfaZGNhPpE;
            KLtviJAgDXSxdrVw += cEfaZGNhPpE;
        }
    }

    if (cEfaZGNhPpE < string("tCjvpccnArqozfEAhGUWerDJSSfrmDEDRjGZdKbcGSHCqUvErlIJKLeDEPTMhxSDfizknjUrqmIVLZKrWhsYJVnwHVwODwSIIeXosufUWIvRluyBCQFEHayou")) {
        for (int WticbsUJIdR = 1965278465; WticbsUJIdR > 0; WticbsUJIdR--) {
            cEfaZGNhPpE += cEfaZGNhPpE;
        }
    }

    if (KLtviJAgDXSxdrVw > string("tCjvpccnArqozfEAhGUWerDJSSfrmDEDRjGZdKbcGSHCqUvErlIJKLeDEPTMhxSDfizknjUrqmIVLZKrWhsYJVnwHVwODwSIIeXosufUWIvRluyBCQFEHayou")) {
        for (int isYbpMHULVzov = 241221428; isYbpMHULVzov > 0; isYbpMHULVzov--) {
            cEfaZGNhPpE = KLtviJAgDXSxdrVw;
            cEfaZGNhPpE = cEfaZGNhPpE;
            KLtviJAgDXSxdrVw = KLtviJAgDXSxdrVw;
            cEfaZGNhPpE = KLtviJAgDXSxdrVw;
            cEfaZGNhPpE = cEfaZGNhPpE;
            KLtviJAgDXSxdrVw += cEfaZGNhPpE;
            cEfaZGNhPpE += KLtviJAgDXSxdrVw;
            cEfaZGNhPpE += KLtviJAgDXSxdrVw;
            cEfaZGNhPpE += KLtviJAgDXSxdrVw;
            KLtviJAgDXSxdrVw = cEfaZGNhPpE;
        }
    }

    return 432170.4379375124;
}

string vjdQKMwIbeIcB::dgOjpfVuFE()
{
    bool YtaYezLyHGSkM = false;
    double FMvCHwBLYBatnis = 231416.79877487093;
    string tBxtuv = string("zEkWUgBdfHfpVsgwyqBrFQRuHpEdgvZjRtIlkDZromgELBrQOCnTbPMrXuYLEXkcAmOJdsTRMKaWhLWpMhYNJdJqLCRngpHvnumulgvwBIzYdRrZAksqtnySXnsyDgIUTQecwkwrgqPvxTgkiuHIQoydaaiRniUdXXIOrzxHHsgWWeuhQkTNgVebczIvgSZi");
    string CgCDMzMb = string("HhaXRuZtUEQNIjlyqVEzLzCdnLivcBmFCPnDSBfyetkgANxXNNDyuxDMTUXFcpIJCcSkQIpCikPVlKQlBWeAEHHoTlLzqifOSqQlLQtKugtRsOuqlyoaMOttroOlxcMeUBYeaKwIebfhbPdzAiIjrLIkJJfQYayoZerGIClLurIlxKiqwCaIpDEdcjBzDFLcEOAAgInlfsNJwSWTqebBsMgRoaiRbsMUwbHzFyEahclTRzWEDygiwWIQeyldXD");
    bool PHKeaEuvMsLh = true;
    bool cNJqYRTSKemEyI = true;
    bool VLSReKFtjSEE = false;
    string RxTAehDOCgRBnjf = string("qLXbAlxVErBwIEVeXwhbyEDxpTPhhSiavSESQBXDOYqwALToPHvVkWKgQbfKorQoMzfguHvAUZDraXoGLOFmJjIZooDVZdbGNsoIQFiIWQjoINAbuAojDLUIKQxwDMVOfHhwTRofsYIKUdeDetBuApAADcpihmMzfgrNFkjdIoGgCHhaUCwiCThyvPgsiHXOCZqkxCBgkcPBKxyQsirMUrpskZIVIzglYwlCdMjteSMQuDCLAgTcAXFRpsp");
    string HPsag = string("BmDLxHeqJrqpnwwHSXiWkVchALpXLcbFcwJdPgQytjDiRdQbRWFSMcOkaacncWRxQcwzBvCSKwVEexyuEEbmwqGUCvUGBJyQQmXbNQoIA");

    return HPsag;
}

double vjdQKMwIbeIcB::dRwECCqOW()
{
    double TdwZDYuljojybv = 894649.6513542365;
    bool BydYoMrcQTuj = true;
    string yTSnbSVqM = string("JcZLSwwLXqSJUwsmcbRsutQdTVuboHEKporhcmOURZStMaDqhfBqwBDpXhIHtYwgRbHhlkOKWtSEkaThxOWNsTyOaMXaBkgDIctZkPNBTGiAQwdYpETWAtxKuvTaBpjucFYSSFmMtHtWiiQYrswjOTmxapFZdXmhJGxoWVNAmZrdSi");

    if (BydYoMrcQTuj != true) {
        for (int TMktjqTYDQRrMrb = 1238655495; TMktjqTYDQRrMrb > 0; TMktjqTYDQRrMrb--) {
            BydYoMrcQTuj = ! BydYoMrcQTuj;
            TdwZDYuljojybv = TdwZDYuljojybv;
            TdwZDYuljojybv *= TdwZDYuljojybv;
        }
    }

    return TdwZDYuljojybv;
}

string vjdQKMwIbeIcB::pnqvqMUcMEClWjXd(bool WqOJNi)
{
    double fXLYGnvSoWUuODJ = -126325.427878836;
    string QzTYnArmmlAdxxUK = string("CjGppojgvbsnOvUhjuwLGmNEszVxKAEnVuVlpPDiJsGyOiydmLzbbSkyueZyBuKOcCwFEPYlvEDYHEAVlDetqngulXUUfNxNBevYdtKqMdYjqkpyPZjzKgKvjfawUNSLzhaejFUtrinapmCBwNEOQzqgjDsdkqxkuPTOITZgNJFoIPohTGizwsewKDpZjjQVIpEeUxqrbxyOExINHokLIwOyXLZnMwkNcEuqZGumIUjB");
    bool ySSaqDBbkCnO = true;
    bool JTvsQG = true;
    bool GWRnURlPdltsMW = false;
    int TUBpBuIlw = -1733958439;
    string wcrYnYxU = string("tNNJoEPC");

    for (int OTsEVph = 1468858989; OTsEVph > 0; OTsEVph--) {
        WqOJNi = ySSaqDBbkCnO;
        GWRnURlPdltsMW = ! ySSaqDBbkCnO;
    }

    for (int hazcyqYIJGrjKn = 523372552; hazcyqYIJGrjKn > 0; hazcyqYIJGrjKn--) {
        JTvsQG = JTvsQG;
    }

    for (int EzywwusUFFLDbz = 1771594796; EzywwusUFFLDbz > 0; EzywwusUFFLDbz--) {
        WqOJNi = ! ySSaqDBbkCnO;
        JTvsQG = ! JTvsQG;
        WqOJNi = WqOJNi;
    }

    for (int sUpVOtv = 1988268746; sUpVOtv > 0; sUpVOtv--) {
        ySSaqDBbkCnO = ! ySSaqDBbkCnO;
    }

    if (WqOJNi == true) {
        for (int USgZvnObuiO = 10860059; USgZvnObuiO > 0; USgZvnObuiO--) {
            JTvsQG = ! GWRnURlPdltsMW;
        }
    }

    return wcrYnYxU;
}

string vjdQKMwIbeIcB::koAFxfnFkCO(double oaWHrENV)
{
    string ivmxXjyJWrseWE = string("edkHTZILmIPSXlauWkooaWzcPggsfRmYCRDmzsBbkYhqrMVfjohttUfbVvhWDuuLZKDOMvTYmKXtKkvmnzvjriBKaynoanZXHXOdaVojSuclwvdodVmPyiqfJYHVcRCPdEQuSpcXjalvHIAMkCtYkjlYiJlGeYxsbJlASnPUITgVTaCCShNn");
    int mVpHbScPC = 1890857775;
    int IhZGhxtvI = 196763372;
    string XrKgbc = string("NWECfZAOsbvFZpHoDsYndyieAaeZmhIhPgcLZTgYLsPxYVsGFFUfuxjhLRNkqfMYYuvgHDHFBTuic");
    bool ZaMwFUIAvWAiF = true;
    int ptjACuXrESKr = -743045203;
    bool OnEptKjoAJ = false;
    string ZTVqgRB = string("kzdasFzAmAHvycpRHWpxZfIZkKEbgNpkyLYRQJzGepLUSBMgbkPSOWAVcZATVQOGuVGMSjrDVriFCHsQhoAHfMgymzTKhpfUqfjMVPZnmTQcyxQwHDuKrrcecEWQTZQRekMCguXkctVOGjkaI");

    for (int cXYpFoxVpDjIgqg = 49497300; cXYpFoxVpDjIgqg > 0; cXYpFoxVpDjIgqg--) {
        continue;
    }

    if (ptjACuXrESKr == -743045203) {
        for (int XcsuQGqJfszbd = 1554747700; XcsuQGqJfszbd > 0; XcsuQGqJfszbd--) {
            continue;
        }
    }

    for (int qVhiNIl = 1785037037; qVhiNIl > 0; qVhiNIl--) {
        ZTVqgRB += ivmxXjyJWrseWE;
    }

    for (int UtpULaVBt = 1568597142; UtpULaVBt > 0; UtpULaVBt--) {
        OnEptKjoAJ = OnEptKjoAJ;
        ZTVqgRB = ZTVqgRB;
    }

    return ZTVqgRB;
}

void vjdQKMwIbeIcB::rBfYWnpD()
{
    double cpVbEoRAfrEd = -209939.3760131479;
    bool agzQUamOkdQT = true;
    string GuISdmSDiO = string("LPUBBvwkpGoUPObnixeVHdcurMoMyTheUgAJXEfyafhldLGNtwgCxijAjOMDsZKCdTCpMUOtCGaHWAGGQosBBqyGKQSvJHPRxLGKiAZzgxxXLegBZtWzzljtNBWoEmhjXCaSTuCbyjTCAbUWNDOsyutRZKMAmCwcYcgOJjWmVCHmfDmlXshwTPJuUDAXmLzHrSFoXGvfsORH");
    int tiVyKbzasgxSQxM = -1269596908;
    int BnkRMCZ = -806270253;
    double rkDxmuI = -545746.6142110509;
    int zwqGOIj = -462174136;
    double UTvjVUgJg = 406316.4062571876;
    double LojAzBTznR = -211484.13791400928;

    for (int BNOJdFZQLAHq = 1309932012; BNOJdFZQLAHq > 0; BNOJdFZQLAHq--) {
        tiVyKbzasgxSQxM /= BnkRMCZ;
        cpVbEoRAfrEd /= UTvjVUgJg;
        rkDxmuI -= cpVbEoRAfrEd;
    }

    if (zwqGOIj < -1269596908) {
        for (int uMYFequZ = 517955173; uMYFequZ > 0; uMYFequZ--) {
            UTvjVUgJg += LojAzBTznR;
            UTvjVUgJg /= UTvjVUgJg;
        }
    }

    for (int LZGMzrddXYbm = 559169237; LZGMzrddXYbm > 0; LZGMzrddXYbm--) {
        continue;
    }

    for (int kTFBOmOi = 991108262; kTFBOmOi > 0; kTFBOmOi--) {
        continue;
    }

    for (int QmkcdQGeCtgkZak = 1126394156; QmkcdQGeCtgkZak > 0; QmkcdQGeCtgkZak--) {
        rkDxmuI -= cpVbEoRAfrEd;
        tiVyKbzasgxSQxM -= zwqGOIj;
        BnkRMCZ -= BnkRMCZ;
    }
}

int vjdQKMwIbeIcB::IyYouhV()
{
    string XTdWLGdIYcGW = string("bvywFvYEQYoFqwNzplXBIXeocSIadSsaJKBahQpwfJBQGpqJkrnCkKRhggtMfbElVLyLiTDNjtyXpyDOSRWCYbjjqYZCFzpekAdZAfWEME");

    if (XTdWLGdIYcGW == string("bvywFvYEQYoFqwNzplXBIXeocSIadSsaJKBahQpwfJBQGpqJkrnCkKRhggtMfbElVLyLiTDNjtyXpyDOSRWCYbjjqYZCFzpekAdZAfWEME")) {
        for (int RuqRbVfgb = 1184668615; RuqRbVfgb > 0; RuqRbVfgb--) {
            XTdWLGdIYcGW = XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW = XTdWLGdIYcGW;
            XTdWLGdIYcGW = XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW = XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
        }
    }

    if (XTdWLGdIYcGW < string("bvywFvYEQYoFqwNzplXBIXeocSIadSsaJKBahQpwfJBQGpqJkrnCkKRhggtMfbElVLyLiTDNjtyXpyDOSRWCYbjjqYZCFzpekAdZAfWEME")) {
        for (int vUMCWUHKyi = 1916946315; vUMCWUHKyi > 0; vUMCWUHKyi--) {
            XTdWLGdIYcGW = XTdWLGdIYcGW;
        }
    }

    if (XTdWLGdIYcGW < string("bvywFvYEQYoFqwNzplXBIXeocSIadSsaJKBahQpwfJBQGpqJkrnCkKRhggtMfbElVLyLiTDNjtyXpyDOSRWCYbjjqYZCFzpekAdZAfWEME")) {
        for (int sKKMPirNAkO = 1323255814; sKKMPirNAkO > 0; sKKMPirNAkO--) {
            XTdWLGdIYcGW = XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW = XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW = XTdWLGdIYcGW;
        }
    }

    if (XTdWLGdIYcGW < string("bvywFvYEQYoFqwNzplXBIXeocSIadSsaJKBahQpwfJBQGpqJkrnCkKRhggtMfbElVLyLiTDNjtyXpyDOSRWCYbjjqYZCFzpekAdZAfWEME")) {
        for (int NkGmrDYOrETD = 1548981062; NkGmrDYOrETD > 0; NkGmrDYOrETD--) {
            XTdWLGdIYcGW += XTdWLGdIYcGW;
            XTdWLGdIYcGW = XTdWLGdIYcGW;
        }
    }

    return -289320390;
}

string vjdQKMwIbeIcB::yKhUAIlXoGCunJfe(string mJPZy)
{
    bool SVCcJwPNZyxbVmw = true;
    bool eGtIIJINoThIGI = true;
    int mEcwatwf = 1156147670;
    string dDhkvQVAT = string("TolzkBNSiozvIQjQzAoAMkKONyTvrIwuULDIaDlCsTrufpDwVhFtaRcEtbecMDTwJkBrnepcnBgmdVtKEsMFdNzdfaTfNilVBOTwAuLSvUiLqxWQBVUPyhrvDnYXpdnvZUZMZiNorYsZSfhONOjRZgyJPdOykMFaVUtscIvbGDpTRTuwDwhcKpgduUmfOgrO");
    string rzZEtPhUdwEX = string("sgOdKkTCZINBlbBYsstfWPKrAsoMTkeIartUlFLknJJbSFKuQtptqiUhghKYOIVeMrOIFYxSQRTkxxiGT");
    string yaifflrFeahCUmf = string("CtnRlytpfaCuyUufokoYTuhOouLOFFeXAXhKSZtGMG");
    string ZQAJseT = string("PcrqcYwSVqvHPRJncWhkNSqgIJdhTxBKRTcchMIiLsrFUIUhWYrzGyyepWVYtgVxiRZNQFzJoornSjVrYxhGLBCnqYbTRjP");

    if (mEcwatwf <= 1156147670) {
        for (int sykDR = 1559716713; sykDR > 0; sykDR--) {
            SVCcJwPNZyxbVmw = ! SVCcJwPNZyxbVmw;
            mJPZy = ZQAJseT;
            yaifflrFeahCUmf = rzZEtPhUdwEX;
            mJPZy += dDhkvQVAT;
            dDhkvQVAT += rzZEtPhUdwEX;
            yaifflrFeahCUmf = rzZEtPhUdwEX;
            yaifflrFeahCUmf = mJPZy;
        }
    }

    if (mJPZy < string("CtnRlytpfaCuyUufokoYTuhOouLOFFeXAXhKSZtGMG")) {
        for (int hwdYT = 244640258; hwdYT > 0; hwdYT--) {
            ZQAJseT = dDhkvQVAT;
        }
    }

    return ZQAJseT;
}

void vjdQKMwIbeIcB::ihtymBjfXNbkJj(string YRcyyZUP)
{
    int KJJVlF = -1399672428;
    int WTArr = 1450559436;
    double iMBjRncp = 236474.00652456228;
    double EyDqrh = -1032132.2664482461;
    string elgeLbVi = string("CDtiKXMddzDHzYxPlQOyDIeoLLsZNolJuigYDXcTcvNHmuPTlVUTtlPueJKLPFtyNhpDebUEwxBxDKWkLVpGhQTJpiTHaCSqzaSpiwGkXKFaaGsCyuSXOVilMMJauzGfpfiXzjqtazNKXfkglneTpEFxmcyUfELldEajOgaZnIbTeUszNcUgTFLmYhfqmyvVk");

    if (elgeLbVi <= string("tyALJGJNHDvGirTqIGyMvAZnWuWAHXCZdmFsZiRnntwPcocoIzLqEZnyKeiaiyzmWFJwXjMLbZOmkLXAaVkSZHyhhnXcyVADhccLTOBCAlRQCrURMtlrtEPuaBC")) {
        for (int IBMkMYATSvP = 1205858762; IBMkMYATSvP > 0; IBMkMYATSvP--) {
            EyDqrh += iMBjRncp;
            iMBjRncp /= EyDqrh;
        }
    }

    if (KJJVlF > -1399672428) {
        for (int GaToBILwzr = 1970991945; GaToBILwzr > 0; GaToBILwzr--) {
            continue;
        }
    }

    for (int upEgdDyGtT = 1064480081; upEgdDyGtT > 0; upEgdDyGtT--) {
        EyDqrh += iMBjRncp;
        EyDqrh -= iMBjRncp;
        KJJVlF /= KJJVlF;
    }
}

double vjdQKMwIbeIcB::WCcYxahAc(bool DRQrzisBwrzQJuFL, bool GxZciMtlvliFNWw, bool vsloZahUhbBOhRw, bool XIkkIiWMY)
{
    string dqdvNZcbmNqfxRs = string("wayhCvOBKwYwKZLWVUWtlGkcrrdIsTaMDqrFNHryWLXysSFDODoYdnwotEOAiIGtQkRDmQUHUAolYBhnjWlLStvXzlkdeEXFEkMVvHCdUEoRgllooaspZtDVmBIVBpoG");
    int XCkkBFm = 433324673;
    double eQGIOSqQPOuIP = 54944.14625504632;
    bool zBQVOTtwltmNIkm = true;
    bool DnCSaS = true;
    bool pIEWCIMaAfpBE = false;
    bool srSirBcWQhK = false;
    double cGCLxdqskDgMzxlm = -420685.65075851826;

    return cGCLxdqskDgMzxlm;
}

string vjdQKMwIbeIcB::OzMFpfZSv(bool vaKbveTBNedRHqkK, bool mrUlT, double wfOuEmAhuFk, int MxuSjnEmHJQup, double GCfdqnDje)
{
    int ZzawSdFFuKrszSs = -187511911;
    double nfmXzCb = 941514.78981017;
    double SFffh = 231055.0334875881;
    string NBzrAcZsi = string("HrwEIsySTomDFciPpHabwkceyZlzrZXgKVdIKGyUvvPLTdgjIZUUujJbkIbpUOtJbeETlChVOjoWYBuoZtGBQJUnWcIPltxqUzvgJaojZQNQYqOZdxscbUbMSauxTbGiNhSHCNhSPxPjrinXgQhzWVpAGpueihfRIXGrUrncpOHkbuXYCXOSreOcJiwoRVOKuhEobdPCnNEqQb");
    string kfKqKPvND = string("iWQEyMpqRGbWtFSaOAUrWcBsDblaWHXrTKdwTawsWzVsTEFifCsZDOGHyRspqXeMGiIAwMBQBeWiypnSeTgdcUMojWnXsfkuALWdjlPsUozkY");
    double BpZFdeGVEABGbku = -591157.2427479348;
    double yifVzPp = -748169.8510105788;
    bool urYdhcnhjTJ = true;
    bool kiHNBpA = true;

    for (int NgshoduFez = 1596731403; NgshoduFez > 0; NgshoduFez--) {
        continue;
    }

    for (int zwRicHCKOHPgN = 2080593749; zwRicHCKOHPgN > 0; zwRicHCKOHPgN--) {
        continue;
    }

    for (int SReaS = 1341554395; SReaS > 0; SReaS--) {
        MxuSjnEmHJQup -= ZzawSdFFuKrszSs;
        GCfdqnDje /= GCfdqnDje;
    }

    for (int jlHgrvst = 1475655439; jlHgrvst > 0; jlHgrvst--) {
        continue;
    }

    for (int pqJMTN = 990108839; pqJMTN > 0; pqJMTN--) {
        yifVzPp += GCfdqnDje;
        kfKqKPvND += NBzrAcZsi;
    }

    return kfKqKPvND;
}

void vjdQKMwIbeIcB::sTSdVyiw(int FeNXHQiXUvtlPfss)
{
    int hIWXCoLTXtqMM = -1244265360;
    string KKMJDa = string("ziqYEdxrkreKlqiIQJWJwJJCLPGizDLYGQoeUtJCJWHBreSeDdqJQIjdyIKnBLhTTpUHgMcNdbYAErQxwCWypzqLTKVHJPDYJaTbfHVhGJnvwGUMFAXughtaujSPikWLghlOZonDeTQevKzNYXUVWgyDYjW");
    bool fKsGr = false;
    int uuSgyH = -583812349;
    string JZALVOWmvXsy = string("PGRiRTlEBfnjCFCYlSyVvOmWKsPtKsAUgrXYOrEMhJLITFkIEoHCwqvrxGxEDNwbYuTSYothKtbPPqufUYcLTZlhwKFCoTPiuedxAJhwObORPqFkdCecgRsSUmlYsohSXzSezpTBOqZDXitfhUGfKwikevOcFjLdmCJvtdwIIIvgTTlUbqihKOMSeekilRJLfVdEdmxFCHcBPxGIgwEhldrTZrecFUGwyYmgjteXiRAIxMuhklxZjkRtB");
    int bZBtEcodOSwCB = 733116414;
    double tXYfpo = 204000.21917378952;
}

int vjdQKMwIbeIcB::bbAyMCSk(string QrDRyXoD, double FzTozpvYuE, double fggSNQC, string GxMctQDNOJ, int nFMijnIWppBcejJ)
{
    int JoqitiMkx = -1261946213;
    bool MkFwQXJFsgwwnm = true;
    string YjHWqYgioslwm = string("CkpaKKDvyVQdmkTHzwsskXLCPtNZOIfjWoTGpxiLVyNoqEIQRHqmyrgMvDyWtnvXoNEcyjfngHdebzzTOnToBNlCEbgbFCXvCMoRCSfyRmCcKvVOEJqfjRGGujwKVUZGvymCEqbtbjEnLhoZaCvPirdpqgUXuhzmXLJXNmSgjWWOTvcJmaFadECLzRKjKFSiwwhuXDYHRpNwwdmvARcuTfIPWoNwkVIqgptzyDzIEtYDibVaaTivchuzdiHFmY");
    double bgIdaRLRM = 183954.2470057913;
    string bFBdFrcDHFTwSqiw = string("TwSUbCzoaYHHPJnHIFuYimtwmnykDtXDprqDWcHvtDKKBEcoUQCXYLpumIDbpJSgcWbtPjdbXyNsASMVeHIQzKamtyfzeddnIxZqUGsQbcbOdfHfSkKEmhPpQPAwOJycNCWSiIE");
    int QjFZMATTKoFrE = -399353816;
    bool qfLJfHCRewK = false;
    string sdhRyNlL = string("MxkGOQDUQCDCMJHojPnaJawZuWsKTaGBnMbjwrabLdKBzJsTadyEvesiriQydZNpXVPwjbZykNYSUjewBjKbtQEnGqMiqifkHjZPwNQQCJpPAyyflJqPmURhclvdqIPJlJpCWyqUVcxzvCtajTDgAdDHdpwJSAPjaNKdZlcURdmlgaPKldbRxGvdLfLusEAWzRJTAjmzT");

    if (QrDRyXoD > string("CkpaKKDvyVQdmkTHzwsskXLCPtNZOIfjWoTGpxiLVyNoqEIQRHqmyrgMvDyWtnvXoNEcyjfngHdebzzTOnToBNlCEbgbFCXvCMoRCSfyRmCcKvVOEJqfjRGGujwKVUZGvymCEqbtbjEnLhoZaCvPirdpqgUXuhzmXLJXNmSgjWWOTvcJmaFadECLzRKjKFSiwwhuXDYHRpNwwdmvARcuTfIPWoNwkVIqgptzyDzIEtYDibVaaTivchuzdiHFmY")) {
        for (int eLuffHbQyJj = 1741403731; eLuffHbQyJj > 0; eLuffHbQyJj--) {
            continue;
        }
    }

    if (MkFwQXJFsgwwnm != false) {
        for (int EEfSyfsrfVWN = 182718926; EEfSyfsrfVWN > 0; EEfSyfsrfVWN--) {
            GxMctQDNOJ += sdhRyNlL;
            GxMctQDNOJ = QrDRyXoD;
        }
    }

    return QjFZMATTKoFrE;
}

vjdQKMwIbeIcB::vjdQKMwIbeIcB()
{
    this->SDrxeYQMxqZ(true, -194374184, false, false, string("AaNEigTvEVeAxkQyVASEBRQvhICmgTjhWMKkMIzbFMamsZahHhUEleRMiCOxsnHNExhTfGGweKTpArOEjFTVYGvBLZNOuuQrlGAgNbPURLiZJNYjAIqzXDszHCtFnMBrHo"));
    this->SyMmnnfdjNBh(string("tCjvpccnArqozfEAhGUWerDJSSfrmDEDRjGZdKbcGSHCqUvErlIJKLeDEPTMhxSDfizknjUrqmIVLZKrWhsYJVnwHVwODwSIIeXosufUWIvRluyBCQFEHayou"));
    this->dgOjpfVuFE();
    this->dRwECCqOW();
    this->pnqvqMUcMEClWjXd(true);
    this->koAFxfnFkCO(-367923.9553100004);
    this->rBfYWnpD();
    this->IyYouhV();
    this->yKhUAIlXoGCunJfe(string("jDToWVHuNPVWzoBYaWFWXWmgLgulgvxfDilaxUuNBcnFQLoVCZGbniFtZTMvvykAoNUvUmlDvfsrTHWRJJdqLczdXbmUbkJjXSQILYhlHQNZHtUDjz"));
    this->ihtymBjfXNbkJj(string("tyALJGJNHDvGirTqIGyMvAZnWuWAHXCZdmFsZiRnntwPcocoIzLqEZnyKeiaiyzmWFJwXjMLbZOmkLXAaVkSZHyhhnXcyVADhccLTOBCAlRQCrURMtlrtEPuaBC"));
    this->WCcYxahAc(true, true, false, true);
    this->OzMFpfZSv(false, true, -556601.9065525355, -261700332, 617955.8872809076);
    this->sTSdVyiw(-338832342);
    this->bbAyMCSk(string("NhAByQoxTNhgIWVkdiKvCptdaTjOqkvUFdxFfUyDJzLxRGMIlAOmkdTDPiBbHpNqyzSHJutupIqofZBGdNWNWxxTdnmGIaFzicpyUEwTVkuczbMZrlXtkDxPRYmnvOodkrxiBBDuizH"), 40416.756345042064, 169290.22509271177, string("PnaaYCGFoeEqkbPRDFpWzgYAwZiKQoqmOhAIqFoSnNvMljcSyoBknqvUxWpjjBU"), 2070753215);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pzHmeTCrhMUEm
{
public:
    int VreuDSLKWpXwFmG;
    string EbowPNVGjN;
    bool VuWCcZmHoG;
    double nbFlkkPHBxFJWHkc;
    bool WIbCHeeKQSbkI;

    pzHmeTCrhMUEm();
    double xAgHLw();
    bool bqzoFa(bool lLtWGsQ, int tSWjzpJwdFZVpGG, double oSfLxmFSrDquLiD, bool ckbLaznYgNHdqk);
    string KZFdwwDNpJumCK();
    double PxhPKkfzb(double hlMQqJfdjsSehYAR, string XbnNzkgXR, string zzvfIgS, string YVxIzPKTnpqvX);
    void RXyhXzoM(string ErKjyu, bool aanplydSukYlgn);
    string LUQzeJfmvotxCa(string HgGLAxggvRigv, int rxmhMxHONMgXgWJ);
protected:
    string WXCgQietrpfHmXO;
    double rMgbydZOMtBqM;
    bool WoInyEWVM;
    string UqCzPlrl;

    int JBDwGP(double uwIHizx);
    int jXWWivufmaHHwkZ(int HgkXpJGgGoeqD);
    double GYDaoXHJVmPs(int KJxsI, bool vCCLWAjNvp, int ZPxHbApjRmqI);
    string uljZnN();
    void ogbftivBQjsGM();
    int xfhzWrx();
    double ODSlFVsxyF(string WHOUzfaqMXlEBVk);
private:
    int lNgVdbMRDucnTp;
    int eryyv;
    int fQQHqWhOCUMauXpi;
    int MSCdnBrJNk;

    bool gSVkdaGvbDhDDD(double pUxfOAESH, bool ImSLseyRemgYye, bool dhFyuVQmHkauFy, bool hDPpkxr);
};

double pzHmeTCrhMUEm::xAgHLw()
{
    bool vrvmmeqOIDpQwwp = true;
    double IDzYlrzDpqZMRs = 94424.8753412065;
    int qAkMAXwNLOYUDw = 1199656274;
    string lfHFLKItbCkpIB = string("AEaowLLlOhCuacbvTzIuyXrXvfMePFNUBXECUNiVKscgOKcWUNxQKleTmbGdMIQqSoBCHDwQrMMiYFlxzHyWcsdiMizvyUpBmpyoaXICbHTEJTzxlxtqYskGOZHCBpSSuvnfHLhfaEMJcCiAvrJXuCGojmhCafchBhjtHypoxFwzCFOSEpbTMDiUGpk");
    double HTWnrA = -728587.045839689;
    int wilvM = 941300428;
    double oQAaXewMNpEiCUy = -64612.11422456285;
    int tWUhoqjELmvxYB = -770415021;

    return oQAaXewMNpEiCUy;
}

bool pzHmeTCrhMUEm::bqzoFa(bool lLtWGsQ, int tSWjzpJwdFZVpGG, double oSfLxmFSrDquLiD, bool ckbLaznYgNHdqk)
{
    string KTWDTK = string("bjrebcAlRximBZuKHCbTxKhmsWwmVuvQcVRFVNxawtbTQWUMFoPwDhQKMTvotIqVXJdZbwifClhagnfavniaEGPUnCCaUxJOztrFPCpzKFFhZwcsvxteYZQA");
    bool fQpUOPSu = false;
    bool XSItyIAeMyN = true;
    int smxvZchnRYI = 2139519710;
    bool HyYPESZk = false;
    bool qrTHtIlTJnCgrSab = true;
    int SSIlqC = 556483234;

    return qrTHtIlTJnCgrSab;
}

string pzHmeTCrhMUEm::KZFdwwDNpJumCK()
{
    bool tSsEQUhOKgukEkum = false;
    bool AATFTYoi = true;
    double ijOOJxhuqKwVZIQa = -643490.2077402635;
    double ZyuqtNXVmFK = -245969.69111287795;
    bool oSfeHcBzOlW = true;

    for (int epRpOLCnozz = 1052095548; epRpOLCnozz > 0; epRpOLCnozz--) {
        tSsEQUhOKgukEkum = tSsEQUhOKgukEkum;
        oSfeHcBzOlW = ! AATFTYoi;
        tSsEQUhOKgukEkum = AATFTYoi;
        oSfeHcBzOlW = AATFTYoi;
    }

    if (ZyuqtNXVmFK != -245969.69111287795) {
        for (int fFOEhtThu = 116034084; fFOEhtThu > 0; fFOEhtThu--) {
            ZyuqtNXVmFK = ZyuqtNXVmFK;
        }
    }

    if (AATFTYoi != false) {
        for (int CXpiXFkhsnQAc = 401010425; CXpiXFkhsnQAc > 0; CXpiXFkhsnQAc--) {
            oSfeHcBzOlW = AATFTYoi;
            ZyuqtNXVmFK = ijOOJxhuqKwVZIQa;
            AATFTYoi = oSfeHcBzOlW;
        }
    }

    if (tSsEQUhOKgukEkum != true) {
        for (int lxcvQNDqYEhHaAe = 1607359453; lxcvQNDqYEhHaAe > 0; lxcvQNDqYEhHaAe--) {
            tSsEQUhOKgukEkum = ! tSsEQUhOKgukEkum;
            ijOOJxhuqKwVZIQa /= ijOOJxhuqKwVZIQa;
            ijOOJxhuqKwVZIQa *= ijOOJxhuqKwVZIQa;
            AATFTYoi = ! oSfeHcBzOlW;
        }
    }

    if (ZyuqtNXVmFK < -245969.69111287795) {
        for (int iVZTVVzh = 2108909237; iVZTVVzh > 0; iVZTVVzh--) {
            oSfeHcBzOlW = ! tSsEQUhOKgukEkum;
            tSsEQUhOKgukEkum = ! oSfeHcBzOlW;
        }
    }

    return string("FEIPBQuLiRUHvIuixGyXDRLgMsO");
}

double pzHmeTCrhMUEm::PxhPKkfzb(double hlMQqJfdjsSehYAR, string XbnNzkgXR, string zzvfIgS, string YVxIzPKTnpqvX)
{
    double pLaOlxaImxuDsU = 997009.089037257;
    string moCozEeef = string("CXHUFZcpMPFgBlIMhZCFweCKmmEVxpBhpQZYYBRkOXWNtHchMBnNPFdZiganlLQixbnMKUnIRwEKwpAzyVAFGTXjBBptdwWdSLSnhazrpMpSfmhIvAgCllZocQNESlhZtzXaNRXquQZGfoaBQgHhNKIbaKLKyzeCQDALbbfHZACOCdirNNTuKMYpajeyGvKoeJcBuggccLbksZ");
    double jnWkmgiOrWAiUbtA = 117109.84251434295;
    bool JCmLxbg = false;
    bool DigtQzoTYRcGLo = true;
    int XFoEoHXuMDuQdb = -2060520357;
    bool JtarzUoFBRCd = false;
    string nlHaitaoo = string("tmnSCCMaVmdTPyVdBMPmzwBJOYNhTSkJbuUxnbLFDTotXXwtqjemkxVjgjjEQDmWHBIIdNmaKHHpoebDGLypNIXgpqtkctReBfNMxGLDuHVZiSBJcaQWFNGOgKhnYmGIwSSahNgKLvMrEnWgMEwsAhHgCvyGg");
    string nMmzbJVLaepoLORC = string("xsCgvUfpnbyvDwjGfJrUWTnKGozzFdrzGSNCCwhPVTqXjLQFMvBTKeubcFEYxBtzsVLdkIhkGeBNHbgtwULqweIjowmpptVxuucnZIxdXHyAzicclEWDxaAPZMtVlFFhOdQPaumHWEAInadtYxlTbdTuJgZAkHKaztatHZOhnRURbBHGuLARhCXpJFglGLBbhckHZkxUDFkReNqFYhfObvEAEGugKBoZOzGVjb");

    return jnWkmgiOrWAiUbtA;
}

void pzHmeTCrhMUEm::RXyhXzoM(string ErKjyu, bool aanplydSukYlgn)
{
    string nSiUscxoUMbjblIO = string("lZafxtaHkQojjKUwvvTawdVFGCKJQ");

    for (int PHaqGWc = 2112634551; PHaqGWc > 0; PHaqGWc--) {
        nSiUscxoUMbjblIO += nSiUscxoUMbjblIO;
        nSiUscxoUMbjblIO += ErKjyu;
        ErKjyu += nSiUscxoUMbjblIO;
        ErKjyu = nSiUscxoUMbjblIO;
    }
}

string pzHmeTCrhMUEm::LUQzeJfmvotxCa(string HgGLAxggvRigv, int rxmhMxHONMgXgWJ)
{
    string LKwXaAfk = string("nMBPcPRbirhRdGlYfcNaohqoJnvCevXOGpGJJksyjhLOVKECpBDSXIlSOSDWpNFstZrEixsunmbMxrnJEuFeFDyzhzmDPIblRwltYhXuaiWxNeoXrBIXbQYorQZzDphmahLqMiHGvsoFccVjrmaUDTHlfMNGHQLQyBhltrVqbUXAFPJFeeKuAcllHmgzbCkaLfDNDsNVFmbcKRT");
    int UBeHo = 690384943;
    double msEWtUCV = 506067.4351258732;
    bool ZcGBGivJAZHefcqS = false;
    string KImjmlHHimhuOy = string("KWlddLgHZskTmpwWrbVtxDaqlqlPQXVlLdFheCmXkXzPfkzQdhTuBDZxTdoYkxspmwwZz");

    for (int XvdGdeNxQ = 484783012; XvdGdeNxQ > 0; XvdGdeNxQ--) {
        msEWtUCV *= msEWtUCV;
    }

    return KImjmlHHimhuOy;
}

int pzHmeTCrhMUEm::JBDwGP(double uwIHizx)
{
    string GqtARXMtdaRI = string("SugafzQaAUoRomiNeYGusNmSAJjprzyudLegiDZEvUyMavAvbHigEJJtAZGdxPaGPmfuGceVurwDCWjkMherGYyYJvxMYrUmxxWMbEBgEeweYAVgwVurIHMDpPnkRRmCsLdZQXkwZUbJXXyWHIH");
    bool tXdsA = false;
    double zOHkD = -463013.67263134435;
    int zgfxiZXBKnrTyWa = -938165946;
    int mTSSRY = 978478304;
    double ezKyJAgLwJYDxyc = 970599.3754529834;

    for (int wiqcZvORvyk = 1826453337; wiqcZvORvyk > 0; wiqcZvORvyk--) {
        mTSSRY -= mTSSRY;
    }

    for (int UGUPjwEpiGxzS = 726189253; UGUPjwEpiGxzS > 0; UGUPjwEpiGxzS--) {
        zOHkD -= ezKyJAgLwJYDxyc;
        zOHkD -= ezKyJAgLwJYDxyc;
    }

    return mTSSRY;
}

int pzHmeTCrhMUEm::jXWWivufmaHHwkZ(int HgkXpJGgGoeqD)
{
    string MCvUK = string("uWGdCeWxtXUmEdFTUuKvawNLuYCltLThfdAUlMphHW");
    bool EiCrFOxuS = false;

    for (int cDduy = 547690975; cDduy > 0; cDduy--) {
        HgkXpJGgGoeqD -= HgkXpJGgGoeqD;
    }

    return HgkXpJGgGoeqD;
}

double pzHmeTCrhMUEm::GYDaoXHJVmPs(int KJxsI, bool vCCLWAjNvp, int ZPxHbApjRmqI)
{
    string SKJdQ = string("GXFjTAoPTKfxwtHLCcldYxhIDfaDMtgqfuQOYWrcxRpeiAhLgvbcImyhbAaqvmoUINFgWxikrMownlDoSNvKqgPghDtrvCtbLtcGQPcQBButqVimiKQfDivHJzqodWvtdDLPCJBQuYnPRzBuyYDooInVhoRGpxqNJUeFEtREqpzCTzaCnArlDDUAzfLIBgKbegSDtJanEPsdPwVZURdvBPihwqpXwbfdpsyFMJMRgqCOdeCpWyOP");
    double QfccnhMVei = 283199.8331868272;

    for (int CIgvTIOuqBBHol = 383105525; CIgvTIOuqBBHol > 0; CIgvTIOuqBBHol--) {
        SKJdQ = SKJdQ;
    }

    for (int QJZknDk = 20796232; QJZknDk > 0; QJZknDk--) {
        continue;
    }

    return QfccnhMVei;
}

string pzHmeTCrhMUEm::uljZnN()
{
    string prBKGBrdzJxBGxta = string("UoUDyJPbNtyhZppFilyTyTMJkRfDWLzQPmASumOCqsHplfPyFNaPEdXPVXVXNrxmuWsYeoZopqhzfHejeUhbpzFbkFeWquKJaWqxeaNEBbMhpKdbWAomfJipYJLoeZcjyPdEwEwVCy");
    string UjtmdQZTVVPXlhZQ = string("ClvPMnKWtIOPKwfgTfbNlzmoutzpXerDCrMXFxqJAshbsPSbfCWhYOVdEVburMyMMJDOXCLKflJmQdUVEAWDwkpzuzuKdjgBjQekgVWgsbgSdzLBupRekRZuBdkodNrWDcGFuMfNtAtIXRivqiHKiHZqawDOUuZalWrDMBZarLfOLZzPTemVSaqhTJqaXGjWrGALOyffPGZKDNyACtKpVGSAdCoIItPZQtz");
    double jAmcLZZLOtAtC = 664175.4542858646;

    for (int RHbRpNXCJbsC = 1597101192; RHbRpNXCJbsC > 0; RHbRpNXCJbsC--) {
        continue;
    }

    for (int RuEVrHRbJRM = 1995994558; RuEVrHRbJRM > 0; RuEVrHRbJRM--) {
        prBKGBrdzJxBGxta = prBKGBrdzJxBGxta;
        UjtmdQZTVVPXlhZQ += UjtmdQZTVVPXlhZQ;
        prBKGBrdzJxBGxta += prBKGBrdzJxBGxta;
        UjtmdQZTVVPXlhZQ += prBKGBrdzJxBGxta;
        prBKGBrdzJxBGxta += UjtmdQZTVVPXlhZQ;
        UjtmdQZTVVPXlhZQ += UjtmdQZTVVPXlhZQ;
    }

    return UjtmdQZTVVPXlhZQ;
}

void pzHmeTCrhMUEm::ogbftivBQjsGM()
{
    int yNFbHMzAxSJ = 225247214;
    int DVFxXebgN = 1370420935;
    double BriPY = -398799.76056597894;
    string tnScrH = string("gMukLTqvfzJgxDqYlmSuaAgBFZCGtjLmRCvLWsbDzmtDSSzHKLCvrZerDZaBMsAmZJpZRSgmAAtgaqnmhWZiZjkxmThvOHRYWTZVTERtypVLlXqXruZktYJAbAjccieLHJY");
    int sDnaugZ = 1477885900;

    if (yNFbHMzAxSJ > 1477885900) {
        for (int nzRIXabUSKzYVDU = 1059257276; nzRIXabUSKzYVDU > 0; nzRIXabUSKzYVDU--) {
            BriPY += BriPY;
            sDnaugZ /= yNFbHMzAxSJ;
        }
    }

    if (BriPY != -398799.76056597894) {
        for (int FnnXJuNdxMUIrxRR = 861131019; FnnXJuNdxMUIrxRR > 0; FnnXJuNdxMUIrxRR--) {
            tnScrH = tnScrH;
        }
    }
}

int pzHmeTCrhMUEm::xfhzWrx()
{
    bool qkQVlvgD = false;
    int UySRbG = 493557623;
    int nMiURZipVfCExlZH = -1686088248;
    int bZBacuwUtfo = -1979281402;
    string aEiGHjRezfjSnL = string("hDxFsfUxrXQVOlCqktJcYFsDmVga");
    string LTDbnzHIZf = string("EGllPNOyzRTBnnpxOdDFTFwouTKpztuwLpFZfFpwYqmkZSjKxwfWdvVjQYWUENdRaxbsZGUHM");
    string ophmThEiyV = string("ApOoSrSbqeHNwpdcQvxpQUGdyUTkrTCAURaHpEGydwNpipioQHUWLZddMSwEqfJgpmeubzQvubeXxFEQwHISTJzQBh");

    if (LTDbnzHIZf != string("hDxFsfUxrXQVOlCqktJcYFsDmVga")) {
        for (int HVfxbSpsyXjXQEHf = 1104479960; HVfxbSpsyXjXQEHf > 0; HVfxbSpsyXjXQEHf--) {
            UySRbG -= UySRbG;
            ophmThEiyV = LTDbnzHIZf;
            aEiGHjRezfjSnL = LTDbnzHIZf;
        }
    }

    for (int uVSCZhiBGnXzQY = 2037133210; uVSCZhiBGnXzQY > 0; uVSCZhiBGnXzQY--) {
        LTDbnzHIZf += aEiGHjRezfjSnL;
        bZBacuwUtfo -= UySRbG;
        bZBacuwUtfo = UySRbG;
        nMiURZipVfCExlZH /= UySRbG;
        bZBacuwUtfo -= UySRbG;
        ophmThEiyV += ophmThEiyV;
    }

    return bZBacuwUtfo;
}

double pzHmeTCrhMUEm::ODSlFVsxyF(string WHOUzfaqMXlEBVk)
{
    string tdpWqtj = string("WNNMheqJUkFMoBGlrutxdNKsIYNoKnQXgEClmzXkycgRigbpPULPiGFYxhlmqEFNiFbQ");
    string vlpznmxU = string("HGZUqzjBVvUIQAjdCxczJOGlRaRaxubUyMEhlBEsCqblViiUYYmnxBlTzYRgEecBxGjdohBLrzHIfVKGocapgfBKFisFZOXYdjPVvnsRnnSjyfGJdRjEPBKhJgHoxsnUiFrPwjtVaSFZhZCQvIVBAuCDDHFggVaMWqWackBgQMTQnTlLlGaqrhAtphBamjFeXhjervqreRI");
    string ynBueTNm = string("UkOokbAMWShYglAzIxOALGGFIvSxqMLoOkjeViwfhbLCFeXXMjKouOjgNwuFonSIHvqhEdeFGaEXIXicJAZDyKrlfgklDnNhXpTS");
    int qLgcNAOHGDml = -1318732319;

    for (int mIOhxhbX = 580080150; mIOhxhbX > 0; mIOhxhbX--) {
        vlpznmxU += ynBueTNm;
        ynBueTNm = ynBueTNm;
        ynBueTNm += tdpWqtj;
        tdpWqtj = tdpWqtj;
        vlpznmxU += ynBueTNm;
        WHOUzfaqMXlEBVk = tdpWqtj;
    }

    if (ynBueTNm != string("HGZUqzjBVvUIQAjdCxczJOGlRaRaxubUyMEhlBEsCqblViiUYYmnxBlTzYRgEecBxGjdohBLrzHIfVKGocapgfBKFisFZOXYdjPVvnsRnnSjyfGJdRjEPBKhJgHoxsnUiFrPwjtVaSFZhZCQvIVBAuCDDHFggVaMWqWackBgQMTQnTlLlGaqrhAtphBamjFeXhjervqreRI")) {
        for (int sZsJMXouiOYXg = 1263482064; sZsJMXouiOYXg > 0; sZsJMXouiOYXg--) {
            WHOUzfaqMXlEBVk += ynBueTNm;
            ynBueTNm = vlpznmxU;
            WHOUzfaqMXlEBVk = WHOUzfaqMXlEBVk;
            WHOUzfaqMXlEBVk = ynBueTNm;
            vlpznmxU += WHOUzfaqMXlEBVk;
            ynBueTNm += vlpznmxU;
        }
    }

    if (vlpznmxU == string("UkOokbAMWShYglAzIxOALGGFIvSxqMLoOkjeViwfhbLCFeXXMjKouOjgNwuFonSIHvqhEdeFGaEXIXicJAZDyKrlfgklDnNhXpTS")) {
        for (int WIpkgqgmtmBVvlHi = 22900602; WIpkgqgmtmBVvlHi > 0; WIpkgqgmtmBVvlHi--) {
            WHOUzfaqMXlEBVk = tdpWqtj;
            tdpWqtj = vlpznmxU;
            vlpznmxU += tdpWqtj;
            vlpznmxU = ynBueTNm;
            tdpWqtj += vlpznmxU;
        }
    }

    return -386260.55267139437;
}

bool pzHmeTCrhMUEm::gSVkdaGvbDhDDD(double pUxfOAESH, bool ImSLseyRemgYye, bool dhFyuVQmHkauFy, bool hDPpkxr)
{
    int KyZSnLJRAzJ = 456406390;
    int JdzxnHqXAXzrdw = -677168473;
    string YKmgpTXC = string("zvLxeaIWMvjUBbgwzLWqAcdlpUCcLnXvOBhInwSiZHkOKKYKOLXlsrNmoEKLZftbHeeLYslLqLWoCAtxujTZzqoCYERrIxkOMKxYaXRtXwjdjQfozaNFiQilvmanTAzOeaULtigaUQkytLfBDYltWvSlyAXkGMz");
    double QhcDG = -708991.2202360189;
    int SylyugUSdFJdG = -1486643043;
    int vNpoFljliqvlSsPv = -1052906363;
    double vTjglnnlZZfHVUp = -907447.1046106125;
    int eFJaKFyDOnV = 209087410;

    for (int KHiHpTGZzjkBbj = 660663743; KHiHpTGZzjkBbj > 0; KHiHpTGZzjkBbj--) {
        ImSLseyRemgYye = ! hDPpkxr;
        pUxfOAESH += pUxfOAESH;
        dhFyuVQmHkauFy = hDPpkxr;
        JdzxnHqXAXzrdw = vNpoFljliqvlSsPv;
    }

    for (int UZVwVrA = 747944664; UZVwVrA > 0; UZVwVrA--) {
        continue;
    }

    for (int BvZVnOHXvlHKZ = 907845515; BvZVnOHXvlHKZ > 0; BvZVnOHXvlHKZ--) {
        JdzxnHqXAXzrdw /= SylyugUSdFJdG;
        ImSLseyRemgYye = dhFyuVQmHkauFy;
    }

    return hDPpkxr;
}

pzHmeTCrhMUEm::pzHmeTCrhMUEm()
{
    this->xAgHLw();
    this->bqzoFa(false, 748247007, -674000.3225661993, false);
    this->KZFdwwDNpJumCK();
    this->PxhPKkfzb(-792714.073233644, string("cOKsUtqRUycxludayZHSZUPJglvLjoCL"), string("VKgJwxjwXGYLmSaDFSKgfZqXXnvNGeErcgSkqOYtLoyampNaPpCuFIdlGWDGPbchtaoHclVXcblnzrSifIkPNMzHwAnZQVMxDFlxmmwrUGbuseuhXfTWJBsaJxsMEWEDsSbqkojMMIhlZJLQlCjRKrQOgTWIDfLqUJFGhzsRwdczNNVosS"), string("fDBKxaUkrcCENQBg"));
    this->RXyhXzoM(string("gAytZVwoENOStdYNqUphoOmGmFuEQHXRkURbbORAxqNQFLBxnCBJCPZvDFKVxiIxKpQsnoVavmvpfvfIXDYTeYGXNIYxatoDnakjXNKYmUjAPITqPhFPGRxefTLFqNNZqZKaahmWjeMlMnUrJfcedHobNmOOrrJaBwoWDSvHNNEJaYFumsOIEFamrFnAz"), true);
    this->LUQzeJfmvotxCa(string("DDX"), 2041404542);
    this->JBDwGP(-106090.66280723904);
    this->jXWWivufmaHHwkZ(-2019994939);
    this->GYDaoXHJVmPs(-1016808480, false, -815298494);
    this->uljZnN();
    this->ogbftivBQjsGM();
    this->xfhzWrx();
    this->ODSlFVsxyF(string("PrgQNHWAjKoncGUBjLQDpHIfuOPtRlsYsvpRrtEQLQAuXxGPOvhaXjoKFksyArlQofjOpJczYgxdgHRMTTmMEgMiQPiyjLYBAqQQdPPjtdphSuPQxxOwTKJdqyvmhoLrwCOsvEsBIMZpoEyAjLpoyyLAGASTLAZimWNeDPDAyAKNSpLTtzqPovwkEoBqhlKYLAqgzBtWDDNMthkWOBvdLDGPaQCmVKYeScbzeIxRAnrNY"));
    this->gSVkdaGvbDhDDD(404175.01515165635, false, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ibFrwIXNiyldqF
{
public:
    double bsFYVVqkpPT;
    bool MeQYyXaiVIRNf;

    ibFrwIXNiyldqF();
    double knwUmfHUX(bool qtdAwgrcBAbjyUjw, bool sCNxVyn, string PMhnItcOlMxxYlfA);
    int rFZixV(int dGvWgaP, bool TfyKpsWQcputQrKS, int kXcoDhDjDg, double lMVQBPNLze);
    int DSNVWAOgWjSWiE();
    int GLAAwKIjwuiOZ(string hhvod, int JWeQlgrdZ, string YIrgj);
    bool WIbWiOrevxJ(string OCcGHDXwaAOQ, string nxBaIaogZIflV, bool FTeAgIveI, double irAhvU, string gKYSah);
protected:
    string NFALZXdxCNa;
    int FoOpb;
    bool GvYKDyuE;

    void EnVAEJSvnTtQPPNS(string gRRzfHQitmC, int IETRpDvCWqeQaO, bool jjNWtarBmgCKFm, int CVDpSGKVvWHU, bool slDGpVhggbazl);
    string yYlTCFa(int rOKLFOiForAXW, int VqjfNcIKwASWQ, int HjsxDmXfbEMqzPgO, bool MuoxEX);
    string ghJaJNM(int vHMxRcSpU, string PwSzhtrKEPoobbCn, bool ozgOmUqcVPQ, double taimifSkQPCr, bool zRMvxhYvTLKGC);
    double HfMLkMqfINf(int HZOMMlRUhXqxTPp);
    double XVbyAskElAMBBPl();
    void xXhewS(int lgJCfArhMNWZTLn, string btgeBxYLYBLZNdSw);
    string ycNOOPfr(int PZIktgIUJon, bool vdwEMesSeJJqh, int kWVJYi, string lnhni);
private:
    string yWTofJ;
    string HaXZtABCpyaBqJ;
    int YEWdNTelt;
    bool LlOBnEdFfYZ;
    double lfoUt;
    int fxxiIV;

    int YWGZS(bool VaJZYYuYqnVhb, double ABheIuRPlCT);
    void KmyMZWee(int zQIsHx, string wnbkYPMjlI, string rZMNWPtTtchE, bool OfCogRZhhZvJiL);
    string PCFvVhvBcvsuo();
    int JjcfxLWlhcpZxvji();
};

double ibFrwIXNiyldqF::knwUmfHUX(bool qtdAwgrcBAbjyUjw, bool sCNxVyn, string PMhnItcOlMxxYlfA)
{
    double gRLZRIGNtRBuBzUA = -564790.291159527;
    double kiTypYIapMxWdDSR = -175460.68465152467;
    int WgvaDKXkkzP = -374005096;
    double TlHGLntLkuWVlBB = -904041.7340023954;
    bool WYqIlEHzPFSaOhpl = false;
    string VTAesVRWSkSPj = string("tmAdLegToyuPcAsbWZuHtKODwLnFcXLblVcQPVRVKmbrkTuLoPhdqAfgRTrNgadranwnidiqsdmXsdFQ");
    int XKhcGSvrDsQK = 625951736;
    string bXpuhKog = string("yBkZsLxhkvYSDrfQAuYvdsuWVPUJrkrTCKIQOhJKvMMZQJQWcmHkUXgwkcsyiqEozJdLQEOIysuBbhinLIQjaNAySNrDBRVEYQmYBYovQeFMzDuzWHXvaIxJefXTnjaVjnFTtotctQtMuxNCxWXLMafmRFyPCghGdeYGkZKmDZgGFBnnNYODmHomtXXwrzsIQKadCpTxyNlqIVndZlLQb");
    int FQVQXAN = -2122768304;
    string WIInMNOxVQDkldW = string("KGlQRzOGdYDcbCSmwTpFQGXMUkCbsZQpgDIFViuvSaWfBsaAJfgjDAOGWarMrSiJAiRZcOKJcibxGywUf");

    for (int RqhTS = 661063679; RqhTS > 0; RqhTS--) {
        continue;
    }

    return TlHGLntLkuWVlBB;
}

int ibFrwIXNiyldqF::rFZixV(int dGvWgaP, bool TfyKpsWQcputQrKS, int kXcoDhDjDg, double lMVQBPNLze)
{
    int obYbbIb = -264590776;

    for (int yfoBLOzUosaSBBsW = 503502200; yfoBLOzUosaSBBsW > 0; yfoBLOzUosaSBBsW--) {
        continue;
    }

    if (obYbbIb > -264590776) {
        for (int vEKqgulDns = 1455191459; vEKqgulDns > 0; vEKqgulDns--) {
            dGvWgaP = dGvWgaP;
            lMVQBPNLze = lMVQBPNLze;
        }
    }

    for (int wzlAnSKufTARER = 1017043486; wzlAnSKufTARER > 0; wzlAnSKufTARER--) {
        dGvWgaP = kXcoDhDjDg;
        dGvWgaP -= obYbbIb;
        obYbbIb /= kXcoDhDjDg;
        kXcoDhDjDg *= obYbbIb;
    }

    if (dGvWgaP <= 1383299886) {
        for (int cfmYNCkXcEGpg = 1514076515; cfmYNCkXcEGpg > 0; cfmYNCkXcEGpg--) {
            obYbbIb /= kXcoDhDjDg;
        }
    }

    return obYbbIb;
}

int ibFrwIXNiyldqF::DSNVWAOgWjSWiE()
{
    double YrFKNOXHmLSpRsaa = -156200.12549558678;
    int PXmxQ = -1547809545;
    double bkaAKioeOmwk = -151022.49129309237;
    bool CRpZGYwiKQPzcw = true;
    double cBcHgxkCUZsoPL = 635315.9697649245;
    int DrqtawNbP = -2100871999;
    double YefNOyJKSiRJYD = -149256.21128887782;

    for (int nRLCsYBqgXGPL = 69684435; nRLCsYBqgXGPL > 0; nRLCsYBqgXGPL--) {
        YefNOyJKSiRJYD /= YrFKNOXHmLSpRsaa;
        cBcHgxkCUZsoPL += YrFKNOXHmLSpRsaa;
        YefNOyJKSiRJYD /= YrFKNOXHmLSpRsaa;
        PXmxQ = PXmxQ;
    }

    if (YefNOyJKSiRJYD != -156200.12549558678) {
        for (int pxdrJi = 52225979; pxdrJi > 0; pxdrJi--) {
            DrqtawNbP = DrqtawNbP;
        }
    }

    for (int ZqslWvOYTZaZcSno = 1288358349; ZqslWvOYTZaZcSno > 0; ZqslWvOYTZaZcSno--) {
        bkaAKioeOmwk = bkaAKioeOmwk;
        YrFKNOXHmLSpRsaa /= cBcHgxkCUZsoPL;
    }

    if (CRpZGYwiKQPzcw == true) {
        for (int bytGuwinHU = 841171624; bytGuwinHU > 0; bytGuwinHU--) {
            PXmxQ /= PXmxQ;
        }
    }

    return DrqtawNbP;
}

int ibFrwIXNiyldqF::GLAAwKIjwuiOZ(string hhvod, int JWeQlgrdZ, string YIrgj)
{
    int OdrubD = -2018009332;
    int hNeInOlWFsxsFvzX = 619544169;
    int MsKqgvlS = 1234239724;
    int xbwZZoYNeRj = -802300772;
    bool lxzLAfBsAFOQdFNB = false;

    for (int CBFfhO = 779759396; CBFfhO > 0; CBFfhO--) {
        hNeInOlWFsxsFvzX /= MsKqgvlS;
        JWeQlgrdZ -= MsKqgvlS;
        OdrubD *= OdrubD;
    }

    return xbwZZoYNeRj;
}

bool ibFrwIXNiyldqF::WIbWiOrevxJ(string OCcGHDXwaAOQ, string nxBaIaogZIflV, bool FTeAgIveI, double irAhvU, string gKYSah)
{
    double UdrQXWjChCWOOv = 766333.8535321302;
    string QgoHbZ = string("msxdqARRPwsZYuCwLVdHZEZlOLdnVljSE");
    string gVetRIA = string("yLbmOCbldlKUTtEIjCHfNBLEPUmsIHgzkBuxvUBWZowpwXKqlfemFvVxPqdTClgEKpmmAewYZbTnGdSLttIyBxhLBDnxPqOpoDsQHbgYpqcphMeRHtuhthdCuqcJDmAI");
    double APsHBAr = -908403.6293562482;
    bool HdRzkew = false;
    bool YrwyGxWAimVuq = false;
    bool MNdTQ = false;

    for (int tboFwyzjwPxnNLj = 1457940050; tboFwyzjwPxnNLj > 0; tboFwyzjwPxnNLj--) {
        continue;
    }

    for (int pFfTFAQUYCwe = 906810530; pFfTFAQUYCwe > 0; pFfTFAQUYCwe--) {
        FTeAgIveI = FTeAgIveI;
        gKYSah += nxBaIaogZIflV;
        UdrQXWjChCWOOv -= APsHBAr;
    }

    return MNdTQ;
}

void ibFrwIXNiyldqF::EnVAEJSvnTtQPPNS(string gRRzfHQitmC, int IETRpDvCWqeQaO, bool jjNWtarBmgCKFm, int CVDpSGKVvWHU, bool slDGpVhggbazl)
{
    double ZofTfLXEYe = -272783.6150069084;
    bool MDYqiosQUeuOrINq = true;
    double eWVvNviAEL = 76090.02371094056;
    string xySGBwiJT = string("TdWkzYnlxBwTAmHjaujaLkIjpBByDOMIzwPPpNLTlBttTLZcINzVppXzHmXyejipYUQoJWjRjmKIzZHEbvpGZPODLobacExgFKAXImahJoKDMOZgYRxlmzxGwtqMJxgDMkRouVhwdAJAgtiOMMVFmibQoWdKVShxtAJUKkgWjqZrktuIXvxQTWPFnZdXAanscsHDopMWckrdOYbuUGAd");
    bool iUmCJXAPPQnCHVuP = true;
    double TgctqyguWJvMjp = 614494.132927965;
    bool miWoAghPr = false;
    string hruInpM = string("eyGuVSYJICEiYgrzpaHCawthFWfBhJPZuLkPeKetmtycTCQGWanduNGVIYMiotAYimJEouXdcytRrEZtRFYlbqQWZHYTAVlarFidotneNzEBgHNTMEapZbhTsfpQREJOLioQOabABHzkmxvgbVXrapvADXASGdwMUWYpjRGxmk");

    for (int GoSGK = 761712514; GoSGK > 0; GoSGK--) {
        ZofTfLXEYe -= TgctqyguWJvMjp;
    }
}

string ibFrwIXNiyldqF::yYlTCFa(int rOKLFOiForAXW, int VqjfNcIKwASWQ, int HjsxDmXfbEMqzPgO, bool MuoxEX)
{
    double HFDzQ = -805610.8018020465;
    string KyCZulrstBLGV = string("vlhBlvHkzHTRevdAWNHhjlViCevDnkjvKYLoAcmehsGUaaaICBmawBKtJBBVFqjzYVJsRqXwFKHKpaDjAPVPgPkVh");
    string hMJlF = string("SDxbgFsUKeoQfzxtzcSPKMYIccgljQPTsnMBBPeOwxjBxSuQCOAfMwYbYzSYPsfCJyKstUtdYybiEbtAeDWMFLxdEmwLknrYidYVmQCOwMzAlWOMgoXQjjfTEoIKMvXJALTXMQeTXIGNUOQtFxBTykKmjEipMFqPHFsGuxTLynESuLTjyMblThJMQLXSjUikNQIpbULsswoZWSBbHSQBheTppAZSECSoXJHFyKHuIJnSNmZDrwIrLB");
    int FZkiLLbS = -1393247856;
    bool VchjZiepLwgai = false;
    string AgjNjCpdoaEN = string("YnVaquMgCbREXefUxkxcZyGFwBkBvumXAyMPAgUoFabdDclyZpwStPzAJnTCNWwkRZzSFSeNsxIDnOdsydhxlQJaUfbmQQWIUvrAiSUAPlmXuGmweQAzLGVtlNscGBTCCfdXDtZxsTWgWRUOprYHRKxcxurmyJFGnGluJYGRldmpgzqDHUpmsVpUcOr");
    double SNnTQEQwjSmTkKR = 818644.3684408627;
    bool mwVinogJZWssGT = true;
    int bOISLQlXBoMGb = -2104048284;

    for (int oGVDPMZwQATy = 1829494467; oGVDPMZwQATy > 0; oGVDPMZwQATy--) {
        AgjNjCpdoaEN = hMJlF;
        VchjZiepLwgai = ! VchjZiepLwgai;
        HFDzQ += SNnTQEQwjSmTkKR;
    }

    for (int aJbPTD = 736620670; aJbPTD > 0; aJbPTD--) {
        continue;
    }

    for (int hUcqAhRbaBssF = 1593642841; hUcqAhRbaBssF > 0; hUcqAhRbaBssF--) {
        mwVinogJZWssGT = ! MuoxEX;
        AgjNjCpdoaEN = KyCZulrstBLGV;
    }

    if (SNnTQEQwjSmTkKR < -805610.8018020465) {
        for (int oHYQTMmjiiOz = 1898571844; oHYQTMmjiiOz > 0; oHYQTMmjiiOz--) {
            HjsxDmXfbEMqzPgO += FZkiLLbS;
            VqjfNcIKwASWQ /= FZkiLLbS;
            FZkiLLbS -= rOKLFOiForAXW;
        }
    }

    if (mwVinogJZWssGT == false) {
        for (int MsKlErZEEEfSMm = 740517890; MsKlErZEEEfSMm > 0; MsKlErZEEEfSMm--) {
            hMJlF = hMJlF;
        }
    }

    if (mwVinogJZWssGT != true) {
        for (int JHKLEKxaHl = 703328910; JHKLEKxaHl > 0; JHKLEKxaHl--) {
            FZkiLLbS -= bOISLQlXBoMGb;
            HjsxDmXfbEMqzPgO += bOISLQlXBoMGb;
            bOISLQlXBoMGb /= rOKLFOiForAXW;
        }
    }

    return AgjNjCpdoaEN;
}

string ibFrwIXNiyldqF::ghJaJNM(int vHMxRcSpU, string PwSzhtrKEPoobbCn, bool ozgOmUqcVPQ, double taimifSkQPCr, bool zRMvxhYvTLKGC)
{
    bool nCxbYJnhIxs = false;
    string JADotzEXiTafMJDU = string("XPWnuVcHJIPEFUydccIUkVPKywltJvmefLEcfOrECkssKErzFWRAimFtBvPZJYdhiCMvjCfxmQIOwxzguBLXVaqIQpIAVzILQxKaywWMghGFyrDlEiKjvFPAHHbKciBxpXrqyddonhgIJLiJzasWkwNSdljpKSqqWKyHDOLjMgVsuwkqzVVpvGkeeSbLgdqKynKobjKZn");
    double fHdXOTDQZaRQTXNZ = 224467.5511025066;
    int JPwjVne = 765056453;
    bool zrCqCHhGeezTr = true;

    if (vHMxRcSpU < 150405903) {
        for (int UrVfSm = 2013677054; UrVfSm > 0; UrVfSm--) {
            continue;
        }
    }

    return JADotzEXiTafMJDU;
}

double ibFrwIXNiyldqF::HfMLkMqfINf(int HZOMMlRUhXqxTPp)
{
    int ACzqD = 722266215;
    int IwLWbyAOwypq = -119282207;
    string svNiOBBin = string("fJyTKubYaGuMiBUjJVaZpRStCDxuRXQHEIcwyXPTehImWUWJBRvCiiRbfzHNrFsWmBrkwtDiKWgsJmdYBsOgfAonPqXXHdpUefsTwUDhCUSCUcUQinnZhzTSQEwyVWsrqRQzRex");
    bool ZZJoI = true;
    int qBjVl = -1705096639;
    string LdbAxs = string("gssrBeoKIwdKzirxlWKcFkahtJASrZhBRdUZBFlhTNELrBVrIWHmfkYBdnNVOIlBdZltFxwcjNYtIxOVrJWbekbfImVParsDygjOxEemPdJtYyqVvqsWrZIumlMtfcUfJooMHPoybMZjKHaJAkaMEwPDLtiUTvzYhRSCGQDBOiXVIVlcARaPFzcRwUjiLGrMgOODCkXpU");
    bool DiKuffzzCoG = false;

    for (int JWxAL = 778057048; JWxAL > 0; JWxAL--) {
        continue;
    }

    if (ACzqD >= -1832139489) {
        for (int JGzZiRVUgZlFa = 2063797019; JGzZiRVUgZlFa > 0; JGzZiRVUgZlFa--) {
            DiKuffzzCoG = DiKuffzzCoG;
            HZOMMlRUhXqxTPp += ACzqD;
            ZZJoI = DiKuffzzCoG;
            IwLWbyAOwypq -= qBjVl;
            ACzqD += HZOMMlRUhXqxTPp;
        }
    }

    return -740395.6877554172;
}

double ibFrwIXNiyldqF::XVbyAskElAMBBPl()
{
    double pXYZpLgQs = -1044464.6230334806;
    int dOYbRydrohQylz = 644203637;
    int XVaASdLczWDqkaty = 1845362284;

    for (int eGKbsQcUAvhMtq = 1038990478; eGKbsQcUAvhMtq > 0; eGKbsQcUAvhMtq--) {
        pXYZpLgQs *= pXYZpLgQs;
        pXYZpLgQs /= pXYZpLgQs;
        dOYbRydrohQylz /= XVaASdLczWDqkaty;
    }

    for (int khadqKYqYUzGoEwB = 771531177; khadqKYqYUzGoEwB > 0; khadqKYqYUzGoEwB--) {
        pXYZpLgQs /= pXYZpLgQs;
        pXYZpLgQs /= pXYZpLgQs;
        dOYbRydrohQylz -= XVaASdLczWDqkaty;
    }

    if (pXYZpLgQs >= -1044464.6230334806) {
        for (int PRmxbKnsogFgMqt = 1092606066; PRmxbKnsogFgMqt > 0; PRmxbKnsogFgMqt--) {
            XVaASdLczWDqkaty += dOYbRydrohQylz;
            dOYbRydrohQylz = XVaASdLczWDqkaty;
        }
    }

    return pXYZpLgQs;
}

void ibFrwIXNiyldqF::xXhewS(int lgJCfArhMNWZTLn, string btgeBxYLYBLZNdSw)
{
    bool ixUphPQrp = false;
    string yOziQDAraCyv = string("coZtBTtZomvrspxfPwpdoeroPjApQRKgonjgtMee");
    string omPsdWcMhGniPY = string("uBHmYOJQqqGtGBrcJyFDOcLtiALOWEEvihQgIZHWHgJK");
    bool ysgtuFCgRIoMs = false;
    int QrtyYBC = -2091346113;
    bool NuZyNaZIMg = true;
    double JDepDRJY = 771598.0658043518;
    bool gePmpvlkhAaox = true;
    bool hNWZWKkJY = true;

    if (lgJCfArhMNWZTLn >= -1763022917) {
        for (int QlGhMxRYMVY = 526094229; QlGhMxRYMVY > 0; QlGhMxRYMVY--) {
            continue;
        }
    }

    if (yOziQDAraCyv < string("coZtBTtZomvrspxfPwpdoeroPjApQRKgonjgtMee")) {
        for (int PYKJTlGnWEktDh = 865849043; PYKJTlGnWEktDh > 0; PYKJTlGnWEktDh--) {
            ysgtuFCgRIoMs = ! ixUphPQrp;
            yOziQDAraCyv = yOziQDAraCyv;
        }
    }
}

string ibFrwIXNiyldqF::ycNOOPfr(int PZIktgIUJon, bool vdwEMesSeJJqh, int kWVJYi, string lnhni)
{
    string oQzIlbAyPPKVm = string("ElDFUqhaVYVIkNtJemPhluiYGKjgdgQwaShtONgANCljWoeoJAIskslfWQBMifcRXOXXdKnfDQQLThGYCkAjgAZoRrakHgp");
    bool qOTrRUrFpfKPySI = false;
    string zHnyutVkb = string("FTAgwkQgizOYPJZVGFMqxndecqceFDAijAfsKrIrEowPnHdcDAaKeEyvYCLapomvhybIQZmmJFQecbVfJzKBZSUpJBQjNiUgiNONDlWgzZqDQrmFBDBHaKBEdRNdmBexfnBRoOlvnIBhipVJHrheyDRpnrhcSmruaDpWwbUeStwzNedsYBEBACqGxxGmVnP");
    string YsESMdzz = string("toxBOyXVljxhfMtZVBTzwAKDaEMiNYlCzzLTRevUYsgYsnkeyFfqcxGIZsaoHaJzcBdoTvKCwxZzOxyAqtUPCdFhQfbFU");
    double JDEJSi = 650576.7300988608;
    bool RxAPdbLmvIY = false;
    bool jaelDCRFNAitEhCJ = true;
    double XJglrVcL = 979864.7684005633;
    double LpxjMZ = 421148.19285624905;
    string DJWJR = string("xjUnLUTxJlMIZLeIQUDhzPcbJQPkbKThCoINnPNlCsQOoWtGBSG");

    for (int niWWYv = 663324096; niWWYv > 0; niWWYv--) {
        continue;
    }

    for (int grXrKBGLJdsLQi = 1020487862; grXrKBGLJdsLQi > 0; grXrKBGLJdsLQi--) {
        lnhni = DJWJR;
        oQzIlbAyPPKVm = oQzIlbAyPPKVm;
        LpxjMZ /= XJglrVcL;
        DJWJR = YsESMdzz;
    }

    return DJWJR;
}

int ibFrwIXNiyldqF::YWGZS(bool VaJZYYuYqnVhb, double ABheIuRPlCT)
{
    double GtatOQog = 40328.10986669323;

    return -1940149495;
}

void ibFrwIXNiyldqF::KmyMZWee(int zQIsHx, string wnbkYPMjlI, string rZMNWPtTtchE, bool OfCogRZhhZvJiL)
{
    int AtOJbPw = -936498849;
    double fLIypTIGUG = -55264.01059897427;
    bool MMmdVzxGPZfJVshB = true;
    bool nuQGMuapSFWi = false;
    int MhgPzTESBNYXwy = 1025628063;
    int SbYnuQBcglQ = -884021254;
    double NarDPRDUPSBF = 269126.9424792179;
    double qjNPnqfgN = -771052.1978168848;

    for (int nUoBpsk = 1177605535; nUoBpsk > 0; nUoBpsk--) {
        rZMNWPtTtchE = wnbkYPMjlI;
        OfCogRZhhZvJiL = nuQGMuapSFWi;
    }

    for (int mtZuWaRvz = 1416359192; mtZuWaRvz > 0; mtZuWaRvz--) {
        MMmdVzxGPZfJVshB = ! OfCogRZhhZvJiL;
        MhgPzTESBNYXwy /= zQIsHx;
    }
}

string ibFrwIXNiyldqF::PCFvVhvBcvsuo()
{
    int rpWLCLIqCeGiCHn = -1261875036;
    string MLuMwvGMrYLVVW = string("JAECOajEvBMOZxMWSOMuYtbjJqeESEHmOYvMBfpMYlbnjJDdsTqZWTRAgclUXypmriNCeNpvyWsHIpPzMuRWPGqKoHBWfcltOjfPoxDeNjrgbksyBohPoRYVSBOzPPyqLMtmSzgAyrblMcNAxmJdHSJmzZIuLczDpcZzCUgZCDysasBMHfeNMtfezcYBWhjribHKX");
    int KpoRvumKLzSo = 211599262;
    double qEmtwJPDFuXC = -717840.0171995445;

    return MLuMwvGMrYLVVW;
}

int ibFrwIXNiyldqF::JjcfxLWlhcpZxvji()
{
    bool jTleXUUFO = false;
    string fQDCUgdbUrxNngXL = string("lYVERaclfgysHCPWTmrtuzSlNFXdGvc");
    double gEMruuKShsXrksJ = -638841.635425368;
    int rJeDssdpsYhGIDj = -459325462;

    for (int JRiEwlZyf = 378044097; JRiEwlZyf > 0; JRiEwlZyf--) {
        gEMruuKShsXrksJ += gEMruuKShsXrksJ;
    }

    for (int SyLyGI = 1351327105; SyLyGI > 0; SyLyGI--) {
        continue;
    }

    for (int GINtsQNzJEKyw = 596163060; GINtsQNzJEKyw > 0; GINtsQNzJEKyw--) {
        jTleXUUFO = ! jTleXUUFO;
        jTleXUUFO = ! jTleXUUFO;
    }

    for (int crcuXcPkltKVwN = 987055718; crcuXcPkltKVwN > 0; crcuXcPkltKVwN--) {
        gEMruuKShsXrksJ = gEMruuKShsXrksJ;
    }

    return rJeDssdpsYhGIDj;
}

ibFrwIXNiyldqF::ibFrwIXNiyldqF()
{
    this->knwUmfHUX(false, false, string("NIwREJqfWpVYonsrVLnPxHlFvcXCtAeXzjwRjvEfjSCoDGIdBrFpNuTWgODYPqvJCEPyvmRnEIWoTYoiqhVevzrsozaNHENqXcykNXnjwSyIRSIKjthbxOAXTQsBXMyIiozXOqNYenqAeNCaHUiHCaVqBliQBKkCnxjdxDADLtjBzxsGwNNuZHEqGtRONDFQPFVbXdQGEbZxtsbgiILpClvIHffLXEleRJH"));
    this->rFZixV(1619762787, true, 1383299886, 408989.0224572787);
    this->DSNVWAOgWjSWiE();
    this->GLAAwKIjwuiOZ(string("E"), 447995077, string("SdHRGUtDaYsmTHHwIJByVvqZGguzz"));
    this->WIbWiOrevxJ(string("YTTZkSlbDYZrrTCiMhyiazhXPXazxbsRuhjlrMeWVBCasadJiZasSkkzvwRKYWNwmOJOmigvsbZgobJbQMJaZYQdBFdPUeCKSdpEhWKWaclbFjjspuEgzlTBUHxyrSorxmjymRBCTgYWzHNncIhiEMMOOTifmWgWDMWoeENkfbUBLQhblFxTzTacZxuiKoEEhwBPQQpRNzrapnqzrFjONWccknaqVoTRAYPoBHobKqglVxdOdeZlORV"), string("NrjOdaLIxyxQfVfysbCUmnQhuiSgoGlKOusNkDeHWrbXsWuEduyDmiRaZbTvKEIdEZHOcseWEtFXdMKomLzQEWUdldhlDlMCXezeVxwBagdlcOEqzfgGmFkXjFexsZmZXJmPJnjWGqubMhjnyyhsNGwWTj"), true, -726866.8836507457, string("TwEjCaDudSbofaptEOcmzgzQyfRc"));
    this->EnVAEJSvnTtQPPNS(string("KuwlzuzVBVrDHAYnIgUXypPhciFKHHaHIafTahaslvencwpzIAokWsyodYGdAYgTloLfMPqIMUTYyRVMFPBZOIjWkRfiyYangJtdPLESOlgQrIINavbrSDjBPIDMdaFEqfMsWhPqWMtSTvPRXYLrnhsTRLSIsvbPGGXEzyTtOvCykxhoZkkqDzhEKCgkTJshELvnpAAgsvroSuwOWbrmuIQdPdMpHAtioeAICxSgKpogsEGFB"), -483385659, true, 1359631833, true);
    this->yYlTCFa(788514685, -2101949513, 1451830569, false);
    this->ghJaJNM(150405903, string("mMSXYiOs"), false, -996352.4200940692, false);
    this->HfMLkMqfINf(-1832139489);
    this->XVbyAskElAMBBPl();
    this->xXhewS(-1763022917, string("EESIZKBFIeBSZjAZTDGzHefahSCKpRWktmsoQYErDgVuhrOdeaendTlPMlugELrXqeyReNDraqAiGtRDtUvipBffJgxujXxERoLJnUvybEsLXYIMunexMUjjwhzehkqQTgYJCqaAvdhbJSBUUvAovnIlCKvqkVawMLZqBuxJAaBAEeWLSrukXDucNvAidaSNsPx"));
    this->ycNOOPfr(-1739551128, true, 2071740238, string("QaRlucnYguHIrHuftrqiAeQcknkCzOXfeoZGoLbGDHyREJitEwgTWmWbOceXiaYmBvEtnyTobQNXU"));
    this->YWGZS(true, 996785.2827700786);
    this->KmyMZWee(1744010232, string("KWVFfvYfEcTBFmrqzQvylBUBPeijVQHBjHUojgThLlIDQQXNKOGHrCxgxLFPULBKtADIGvOtaiExPdAkYtJFaqjSpDpzNRPPOMDMLimGaYTRrFkpZwlVCzoWmAlLOFkZJiEVFRCJZbCVdMBCWbYZPvTPzrBCqcluLITYwwhrkcLLraHwXqlsRlJOTeKpytgLPlaJzubiyDHhAsZSgSfTyQhPImlbIruXJRvFDUtW"), string("cwuviBsMJOgeHbjUqcPSvRRpPYSnzXrOFobLsmAEtOdaSkfgHpgRZvMGcpwECtSblAerxGkBAvspPglnHYmuMiPzFwlOXgfxEjscoAuMBslNsGqMVYDQDfZGZyzSHAjVElZgSFYqmHZurBpWAwngjgFlDKRTTHkhwTYVsnjoevrrRxaTOSuxfmBvaavitNOTaO"), true);
    this->PCFvVhvBcvsuo();
    this->JjcfxLWlhcpZxvji();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MybGkRJSNL
{
public:
    double RjiYSVlouryrOxhg;
    int JXPYemVuLYaiILfU;

    MybGkRJSNL();
    void hoZRHGRAQMhpQC(string QeqYZHJRQ, bool AthpSbQsn, string VFLFedh, int CBFbvPeETZbqml, bool bLCRokRgUkbr);
    double ryDcrGqC();
    int YRQiXRFFhCSs();
    string bPTgJzUK(double NYhShSVsEYaklF);
    void EHtqUNaTxTUmpS();
protected:
    double SuARaCQjsvitC;
    double lEishMotDefY;
    bool peeeVZjPgjd;
    int NLCjbA;
    string weSbjPam;

    double VfDNNZ(bool mrdLZAMoxnkZ, double lzPLtwjkXI, string Newrzkmj);
    bool YBZKXW(int TxOktZVwZCTpKInI, bool MdGbweKov, int eJZRPSEQlLhQBYGA, double PNpyejkRUqoCzI);
    double XxIeGaqF();
private:
    bool zuLxoWREgKYeGH;
    int bmsuMmnnYMhLM;
    string CeLpB;
    int tOzUqVUsSeI;

    string IpjXfQtnoYMJECZ(int vajHJiAIbwPXeW, double hHVutetrtYU, int ktXSvTbmawbWP, int jfqGiOdcb, int FPsHzBWnDW);
    bool yrfZQXuDWZSSDQhI(bool vjMLFvs, bool abAwuPlVhGrHFR);
    void dodZXk(string PguDICaEyyqeth, int nHPXJeburdyoGUy, double MOOidcqEbGj, int rtXZifO, string KaClIi);
    double mvXneNd(int GOTicFsic);
};

void MybGkRJSNL::hoZRHGRAQMhpQC(string QeqYZHJRQ, bool AthpSbQsn, string VFLFedh, int CBFbvPeETZbqml, bool bLCRokRgUkbr)
{
    bool ElJCsLWJ = true;
    string BSSBNWOPDN = string("CEYCErcFbRutGvQUrIXzVUmiGjZqDlcafFXuJjAzTAFaLFfKQmuZjkaTOuObZatGCQbDuskJXfBAXPuzwohzTEWMPMLBzywMLXwHbshQQNwDbinurk");
    bool tyuCdxk = true;
    double hbpaSiFOtxuvfy = -281725.5583776904;
    bool hrVVmaJbKOo = true;
    string RIWKNQeaJDxI = string("Ku");
    int xfJQsrqB = -1303795937;
    string JzruVFpvJ = string("TTatbAyUmhDFEsgWeswiMFTjbleUKtsPFjsDpQbGXPCqLVofbQRtebhpPpDcOawHiXVDOjqpRQYvhyIqVXJNponfEBlDFEmquusBwxtpIewrPlENRDyPTCioTEkLqHSKspoLxIRBpTydDCNzBEwqtzdCjciHzScjfYYzOjmRJarHflMfnJpUmYhvJMnphRNcTjEOkOaNXjrHeuOSWWFRvXJERdWBbnGyQMXvNNGth");
}

double MybGkRJSNL::ryDcrGqC()
{
    string YdTEMEMYdbtYB = string("qlbyzEBxKxmWoVZosTrjKeSfOqCVKNnzKopMGAJyiRHeUcPzrcPhcMLczhGOmdnmjlLKFsHcUqXrPPvfsOXsJLvkGJxqjGppUPoXsamILEtmEQqwPFyoVGRAawrtOWuKvDRvJQaGxnwwRUyyKlEmBQeImPAKwyVgRlxbOYLhmExVKFQQRvDysJiVWWlbekRpKKJZKHmBvLUBRREYNpXcjZasTtjYMPtEwOreLLdDEabOhNvbZgmSWSnSwu");

    if (YdTEMEMYdbtYB >= string("qlbyzEBxKxmWoVZosTrjKeSfOqCVKNnzKopMGAJyiRHeUcPzrcPhcMLczhGOmdnmjlLKFsHcUqXrPPvfsOXsJLvkGJxqjGppUPoXsamILEtmEQqwPFyoVGRAawrtOWuKvDRvJQaGxnwwRUyyKlEmBQeImPAKwyVgRlxbOYLhmExVKFQQRvDysJiVWWlbekRpKKJZKHmBvLUBRREYNpXcjZasTtjYMPtEwOreLLdDEabOhNvbZgmSWSnSwu")) {
        for (int pVtPyMgvZQHV = 146308665; pVtPyMgvZQHV > 0; pVtPyMgvZQHV--) {
            YdTEMEMYdbtYB += YdTEMEMYdbtYB;
            YdTEMEMYdbtYB += YdTEMEMYdbtYB;
            YdTEMEMYdbtYB = YdTEMEMYdbtYB;
            YdTEMEMYdbtYB = YdTEMEMYdbtYB;
            YdTEMEMYdbtYB = YdTEMEMYdbtYB;
            YdTEMEMYdbtYB = YdTEMEMYdbtYB;
            YdTEMEMYdbtYB = YdTEMEMYdbtYB;
            YdTEMEMYdbtYB = YdTEMEMYdbtYB;
            YdTEMEMYdbtYB = YdTEMEMYdbtYB;
        }
    }

    return -50674.40073250893;
}

int MybGkRJSNL::YRQiXRFFhCSs()
{
    string bHpsTXNypAojDrzx = string("wrTDaveUsdfkGzIpwpmRZRZzLScCskTwsIfanPHrmAUfMeJsGBYwgEwJgPkjLXKilxOrNoU");
    double uEBaGpLqt = -832411.131663779;
    double HxKxhIWDaFPTE = -777350.9827633888;
    bool HvDZALrsyHuz = false;
    bool YidZMJAwpstljF = false;
    bool TEklVMSAkVo = true;

    return 38235758;
}

string MybGkRJSNL::bPTgJzUK(double NYhShSVsEYaklF)
{
    int EmnDMATEayofD = 276935252;
    string nkEBD = string("CLDPbiMInhzJxgcqcFaXhnuWfcjzuDUkrJjdNVcQtTYzTzGWosRfiTEhzwRbBEZAMzoVOtDJaMifJEXjnPRGyOITqxySxVVkbEGzRhgLAgVVoArfLYwbcZDyXIlujGAPOhkYwVDzsufzQ");
    int htGiOtV = 1567904690;
    string zOSFeKA = string("tqhLGGOyjOgyqpuMgKmZrezmaIXRVaSrro");
    double WjpPLIA = -22057.94353894095;
    int MlJMGxyURGRjMcO = 899765950;
    string UCXootZtXge = string("DrOpCeJapBdGWrAisyANTSbHRShACvkgXHzBexuTiUcRTCHPbfkWUWVFupaTskBKgzLRwVcTgPYpNVlOXuZJLQSzSfENRmtIzptJMLHulDzOSoOJvNvqOXqPrBhZARfwxCLQjyEmXMEhDWEoROiPckXQjIxnEKQTziPlaDTefowiqwzQuNCjwVBwanTyzfAOpSbpzmSk");
    bool YQxuf = false;
    bool CVpPDnXXiV = false;

    if (UCXootZtXge <= string("CLDPbiMInhzJxgcqcFaXhnuWfcjzuDUkrJjdNVcQtTYzTzGWosRfiTEhzwRbBEZAMzoVOtDJaMifJEXjnPRGyOITqxySxVVkbEGzRhgLAgVVoArfLYwbcZDyXIlujGAPOhkYwVDzsufzQ")) {
        for (int MBQBEIXFbr = 1977229611; MBQBEIXFbr > 0; MBQBEIXFbr--) {
            continue;
        }
    }

    for (int ajSrNUqTKTR = 1085201552; ajSrNUqTKTR > 0; ajSrNUqTKTR--) {
        NYhShSVsEYaklF -= WjpPLIA;
    }

    if (CVpPDnXXiV == false) {
        for (int AVYmtusl = 774255168; AVYmtusl > 0; AVYmtusl--) {
            htGiOtV -= EmnDMATEayofD;
            YQxuf = ! CVpPDnXXiV;
            nkEBD += UCXootZtXge;
        }
    }

    for (int Lkgcdraeaa = 1595155860; Lkgcdraeaa > 0; Lkgcdraeaa--) {
        continue;
    }

    for (int HzOVDsMzKAUI = 8310953; HzOVDsMzKAUI > 0; HzOVDsMzKAUI--) {
        continue;
    }

    return UCXootZtXge;
}

void MybGkRJSNL::EHtqUNaTxTUmpS()
{
    bool dYXwoickrLYdqZ = true;
    bool VKQqKBie = false;
    double VnpehwFEP = 302693.908296985;
    bool juVBShkPcbYc = false;
    string MqDjuRXxndj = string("kgQYRKOTLBGsoCqCAMmEJwYLt");

    for (int JwcjCrB = 1702713425; JwcjCrB > 0; JwcjCrB--) {
        VnpehwFEP -= VnpehwFEP;
    }

    for (int uYLrsjJ = 1740597384; uYLrsjJ > 0; uYLrsjJ--) {
        MqDjuRXxndj = MqDjuRXxndj;
        dYXwoickrLYdqZ = ! VKQqKBie;
        juVBShkPcbYc = juVBShkPcbYc;
        dYXwoickrLYdqZ = ! juVBShkPcbYc;
        VKQqKBie = ! dYXwoickrLYdqZ;
        dYXwoickrLYdqZ = VKQqKBie;
    }
}

double MybGkRJSNL::VfDNNZ(bool mrdLZAMoxnkZ, double lzPLtwjkXI, string Newrzkmj)
{
    int hGQBxDzAyPS = -812207930;
    bool MWwWROH = false;
    bool pTNbBQAaOUAH = false;
    bool lHUvRnapEIi = true;
    int EDOmFb = -1254277323;
    string uTvxkGgHjuDUBi = string("hdbntgJykeUvIVElICpNEUmhmCQAEnbkGWaDkOjveAnevZVXlRyenJtuTBPhGjquOxmZzwYmZMxXHaiHeuCZTItclLZguwnLvtTzJPgXSoopsFfRrAzVWWmnFoGFsABYVqLxiWmnwazpXnsCIOQeBmJGJlxz");
    bool eeJvbKyUIaCRwm = false;

    return lzPLtwjkXI;
}

bool MybGkRJSNL::YBZKXW(int TxOktZVwZCTpKInI, bool MdGbweKov, int eJZRPSEQlLhQBYGA, double PNpyejkRUqoCzI)
{
    int eeIEgSiTwbe = 377227767;
    bool tJQtd = false;
    double cXqJWke = 678454.5920499703;
    int zuKQICCsw = 1431603452;
    int dUZdSiIgpaAkgY = -1798544069;

    if (eeIEgSiTwbe == -1798544069) {
        for (int EtUJxBoMfczKUj = 1150768949; EtUJxBoMfczKUj > 0; EtUJxBoMfczKUj--) {
            continue;
        }
    }

    for (int iIuKrz = 2142496297; iIuKrz > 0; iIuKrz--) {
        PNpyejkRUqoCzI /= cXqJWke;
        dUZdSiIgpaAkgY = eeIEgSiTwbe;
        eeIEgSiTwbe *= eJZRPSEQlLhQBYGA;
        dUZdSiIgpaAkgY -= TxOktZVwZCTpKInI;
    }

    return tJQtd;
}

double MybGkRJSNL::XxIeGaqF()
{
    int EXgwGDv = 1459754075;

    if (EXgwGDv <= 1459754075) {
        for (int bbdhycI = 713789342; bbdhycI > 0; bbdhycI--) {
            EXgwGDv *= EXgwGDv;
            EXgwGDv *= EXgwGDv;
            EXgwGDv = EXgwGDv;
            EXgwGDv *= EXgwGDv;
        }
    }

    if (EXgwGDv <= 1459754075) {
        for (int gcmyMunZstTSoqI = 482141571; gcmyMunZstTSoqI > 0; gcmyMunZstTSoqI--) {
            EXgwGDv = EXgwGDv;
            EXgwGDv *= EXgwGDv;
            EXgwGDv += EXgwGDv;
            EXgwGDv /= EXgwGDv;
            EXgwGDv = EXgwGDv;
            EXgwGDv = EXgwGDv;
            EXgwGDv += EXgwGDv;
            EXgwGDv *= EXgwGDv;
        }
    }

    return 879155.4042378749;
}

string MybGkRJSNL::IpjXfQtnoYMJECZ(int vajHJiAIbwPXeW, double hHVutetrtYU, int ktXSvTbmawbWP, int jfqGiOdcb, int FPsHzBWnDW)
{
    bool cfHgI = false;
    bool enQmtlLuJy = false;
    bool Ughyvyvem = true;
    string NeEyflFRAyikwia = string("dLKixIsPWxIMKRokywacZvHYFVAiaNrYEvNhEwiOjbGdubIw");
    bool LJzuJ = false;
    double TbwHFdSSrSttmhsQ = -336979.05248850066;
    int TjvpRXGZTVjs = -1517771107;
    double MUHOOYPLKmVRZ = 797004.4903699993;
    bool GChPW = false;

    for (int NjFBFKocBPFV = 1329189162; NjFBFKocBPFV > 0; NjFBFKocBPFV--) {
        GChPW = cfHgI;
        ktXSvTbmawbWP += jfqGiOdcb;
    }

    for (int KajMjCj = 1120934368; KajMjCj > 0; KajMjCj--) {
        continue;
    }

    if (FPsHzBWnDW == 869290834) {
        for (int LmbSLhPcrTmNyG = 492364719; LmbSLhPcrTmNyG > 0; LmbSLhPcrTmNyG--) {
            TbwHFdSSrSttmhsQ = MUHOOYPLKmVRZ;
            NeEyflFRAyikwia = NeEyflFRAyikwia;
            FPsHzBWnDW = jfqGiOdcb;
        }
    }

    if (TjvpRXGZTVjs == 2048168100) {
        for (int rfqgSMuKBap = 1390623813; rfqgSMuKBap > 0; rfqgSMuKBap--) {
            continue;
        }
    }

    for (int IfgAD = 251505815; IfgAD > 0; IfgAD--) {
        continue;
    }

    for (int rXFioWzlN = 815879072; rXFioWzlN > 0; rXFioWzlN--) {
        GChPW = ! LJzuJ;
        Ughyvyvem = ! cfHgI;
    }

    for (int lJWzcQ = 916828588; lJWzcQ > 0; lJWzcQ--) {
        continue;
    }

    for (int wbtWIgXaGNNHA = 691865143; wbtWIgXaGNNHA > 0; wbtWIgXaGNNHA--) {
        LJzuJ = cfHgI;
        TjvpRXGZTVjs *= jfqGiOdcb;
        jfqGiOdcb *= jfqGiOdcb;
        TjvpRXGZTVjs -= vajHJiAIbwPXeW;
        GChPW = LJzuJ;
    }

    return NeEyflFRAyikwia;
}

bool MybGkRJSNL::yrfZQXuDWZSSDQhI(bool vjMLFvs, bool abAwuPlVhGrHFR)
{
    double qIpQG = -432988.48255296267;
    bool IzpxVGGmnr = false;
    int cXzjMyfLfUEPjF = 1008118281;
    int PAKXPSjYz = -1538011533;
    string OBZzgOrlTtOcBd = string("mVqrsUWGlrvtDhudKjvoAuYJpAvmeFKEsNAZjGglNvkplpLGFZfLiEEBQdXgzgKvEbxCsFKVenXMGVfzcXySJQQmEBxOzrkaAPrckJcwGqkJlCPtuiPWgIQTywyRiBSJtmb");
    int ecdZZTsbzNMJb = 145328772;
    double qQYnnwZfO = 815654.1506109748;
    double lwWTsRLGnwSWN = 87310.15869431113;
    bool kcqudRmclSOsbiPi = true;

    for (int erdOgUTEMaGEmTZ = 47721553; erdOgUTEMaGEmTZ > 0; erdOgUTEMaGEmTZ--) {
        OBZzgOrlTtOcBd += OBZzgOrlTtOcBd;
        kcqudRmclSOsbiPi = kcqudRmclSOsbiPi;
    }

    for (int SFzfY = 1503550689; SFzfY > 0; SFzfY--) {
        cXzjMyfLfUEPjF += PAKXPSjYz;
    }

    return kcqudRmclSOsbiPi;
}

void MybGkRJSNL::dodZXk(string PguDICaEyyqeth, int nHPXJeburdyoGUy, double MOOidcqEbGj, int rtXZifO, string KaClIi)
{
    int DGQZRaMUr = -1280718927;
    string dCDhrDNBHaHXkkM = string("VrCvkBHVnxoHQndHOeutdByLfxSpkaOAYagR");
    int ykWTuuohoTdcsO = -2078022777;
    string TvUimfFiXEXQK = string("iOtBFgsYsRFuWTJRNBdJNioRwNEHFBSTJ");
    int OcDfPLflvvSV = 1481527068;

    for (int rPrxd = 1671825757; rPrxd > 0; rPrxd--) {
        OcDfPLflvvSV *= ykWTuuohoTdcsO;
        PguDICaEyyqeth += PguDICaEyyqeth;
        ykWTuuohoTdcsO /= OcDfPLflvvSV;
        PguDICaEyyqeth = dCDhrDNBHaHXkkM;
    }

    if (rtXZifO < 1481527068) {
        for (int XejxVmTizJuNVQy = 1356537679; XejxVmTizJuNVQy > 0; XejxVmTizJuNVQy--) {
            continue;
        }
    }
}

double MybGkRJSNL::mvXneNd(int GOTicFsic)
{
    double RTkOiWiwRPvHgN = -754164.3345601099;
    int nBdpHxAKscir = -1031772000;
    string NKsqUwMZpJojFNmQ = string("lKWsbmrYtwUfZSEewrYEVQGQavWAQyijSR");
    int epUsUPbUo = -1653563884;
    bool pHaNh = true;
    string nkoVl = string("FcsYRLpQzvFGTWrVKyfRBBIXIdtRJfEotPcXyoBCkSFvQKWHRrixGsdwDMOfatUFGmyabQzPNVDCxdNwJQNQhrvAjdaUyaSTSWQgd");

    for (int RrmSdgZMirN = 863242589; RrmSdgZMirN > 0; RrmSdgZMirN--) {
        nkoVl += nkoVl;
        nkoVl += nkoVl;
    }

    for (int eOfVddmXQpzmqG = 1248096551; eOfVddmXQpzmqG > 0; eOfVddmXQpzmqG--) {
        nkoVl = NKsqUwMZpJojFNmQ;
        epUsUPbUo += GOTicFsic;
    }

    return RTkOiWiwRPvHgN;
}

MybGkRJSNL::MybGkRJSNL()
{
    this->hoZRHGRAQMhpQC(string("BKBseYGpnRQWDaPxsOyZQcZHCXvokmxFURvfgzTjFuaMjpVeAepkzDbEYSOtUntEEwBUmfYuxqqHPsqwWMGUBKFjXuQyGCGkYqZhNSEhucouPjWQGyHzGjijDlIXNkXSespqdUpZdHDHONvXnoHZfnUbQvzVCKn"), false, string("UAlYfYpQtIYaslWzclbZkyjdjFagCcHRXQXfPSMAVElNNFUzuggBCDijVtvKcdUsdvJmNgixHTnGfakwlXRNKJpoAcgVzkEyvmcbaLKJtzNQhWiNkoilMOShMebYnFsIY"), 1085297666, true);
    this->ryDcrGqC();
    this->YRQiXRFFhCSs();
    this->bPTgJzUK(-447699.75528573187);
    this->EHtqUNaTxTUmpS();
    this->VfDNNZ(false, 847805.5758844753, string("ihDZwLwmTHAgkiTMnalhklFxltJeczUqjQvpgYjIUxQGsDGhpMrpbNQfMhsb"));
    this->YBZKXW(1574880651, false, 561954391, -455079.31574696716);
    this->XxIeGaqF();
    this->IpjXfQtnoYMJECZ(2048168100, 213200.75559880826, 1373231421, -27989486, 869290834);
    this->yrfZQXuDWZSSDQhI(false, true);
    this->dodZXk(string("XGyWyUfSJoYrWgwPlTFZsqNWwGjqeXTPNbCkeCkNMVYncKznERlKHUnXLQzlSWEXLlBaMDUfsXsoijUUtqixfuNiMYEiEpHbtRMwFKEuDEgEZgfjcxOWxevGkZhntfpIUqVeFDIphQShVgXnTrlMoQouJgCwJINiWplddnASEEgsDRCqgSSXmdodRFMvhAWVXHesICcWna"), -378690899, 735598.7535227843, 1172501475, string("KNlmRoGWvlrhJlTULmdMskqIxFwfLFeBeBDDfSNplHioLoTStHnMgISBFlaNIAXqWDbLzauzNIHmTazNTqdIsVdvmNpGxciVRhqDGpinXiXzZUrXiDJVWJSyfgnvuAzZgwoyVE"));
    this->mvXneNd(349238557);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wlbyKao
{
public:
    string rfTTXsiP;

    wlbyKao();
    double AjHjX(int xsIuYWs);
protected:
    bool MsvepKYXJBi;
    bool UsAUNsLWhalQJ;
    double luUjkeNKBJ;
    string LKtKuas;
    bool YwtdckJuoBjALP;

    double IyoVqz();
    int JWmbwcwuR(string TSGFsmOsF, double krdcrIv, double pTtEDO, string mFcQr);
    string ncjPlCLlkbX(bool zElUWd, double tbFHqsyZ, string WvqPjaRwQMI);
    void hNHMgbERWIVtPSDm(int gMpzJadEgSWHnTF, string ndMdiPSIbTCcyIz, double ZjZfYdYEB);
    void KFrbcG(int EAyGlzyGtuBwFA);
private:
    string PoUrwxWe;
    double eiCkLuQ;
    string dwQJLJvhkQbAf;
    int nRzPfp;
    int KLWjl;
    double MSihAzm;

    int vnAPQrJBDcxCFB(bool qLrtEHlZHZ);
    bool XISnz(string mhPMHuwzudDEub, bool nNjVaTMBMi, string YFLldUIb, int kAGqLxYNwhRJ);
    bool UYMRtcRKqGzFx(int cXCCRYaGez, double mgiKcXiqAJ, int SDdbxRKkQeVAXvk);
};

double wlbyKao::AjHjX(int xsIuYWs)
{
    bool cPtgIrSussrSwQI = true;
    string DBRaz = string("eNTuYtxqEBbbAyvjffcQTmMPnAvUHkeylLKGkFZkWFy");
    double cKHeAgNSosaiY = 856823.8675303565;
    string tmTfJpAVnYsHUP = string("CuCSBqHQELpzKOzCaMvhGilESSgJvZLPNMXhWjvHqgdyWV");
    double NChStHZLknQIQiRQ = 886007.6752242466;
    bool TEWBiEBz = true;
    int hfcMTd = -131054845;

    if (hfcMTd != 183808223) {
        for (int KHFkN = 1196337378; KHFkN > 0; KHFkN--) {
            cKHeAgNSosaiY += cKHeAgNSosaiY;
        }
    }

    return NChStHZLknQIQiRQ;
}

double wlbyKao::IyoVqz()
{
    double LMmItODHGb = -731406.9209277611;
    bool DSbxsMSQArTU = false;
    double UNAJRh = -1019300.205924033;

    if (LMmItODHGb > -731406.9209277611) {
        for (int yqrfkNKZkhSe = 1821378390; yqrfkNKZkhSe > 0; yqrfkNKZkhSe--) {
            DSbxsMSQArTU = ! DSbxsMSQArTU;
            UNAJRh += UNAJRh;
        }
    }

    return UNAJRh;
}

int wlbyKao::JWmbwcwuR(string TSGFsmOsF, double krdcrIv, double pTtEDO, string mFcQr)
{
    int yNOIMWHIsEgTMX = -493237695;
    bool ElhiQQGg = false;
    string RHBAIxIM = string("zqAMQbgvmxDvHDEZqdflkEFADEFVgbgRkCWA");
    int oxLlRVkTjbfcOA = -403341205;
    bool mUwIoaA = true;
    string uzgSZKwALWmJr = string("dlygLCafWWACXNNWFgJVxgVrNvnjXwdzlhyxjBmdXqNtGsuNyYrEPNGuhecuXrOtzbsoprXODnzJGfMUmZQhFVaDYtFvygNnlUcgEwukJRAzUTwwUWqkjlMjIAnMWbXnLgyoOMQYdGFwRrNFtTiAYGCJxBUhRpVUDkNyRgFMFGdUKpIKdrTVlmxrCezXLaQcABWQxiMSkhUERpMSnUe");
    string tMCbNqNqT = string("iOLUuwYgAzUGKVZkNJUxYzhFQjTegLwBJQUkBwlohXQCvmvueZwgBEOcrwSxfuWxCarqpfqRtGREiBrrMtKKYvgqbRUCyxXZdpcDBEaEYLdvsqPRcdhRwNUUZuWvoFswuXsLBaVAfTMJluITPJdiplxImOttGpmEeJwLDhgJMbDkDJjaPAYAUxbaqLwuxDWDqCPMtWoRIkVzYU");
    string lhMwojQ = string("ApWWZHAVwBJToSlXXpwWKQVkFwrosShnNaIrSYpyAZYWAtwQvuyYzJEyiXVIvWvzzInOEtVbJHaBTfYZgOEQdGdQsaBskcfiJRyUbjguZmAtDlTnjEuqOIQqIUwapbMcPQHwHWsQoGywhzStITFoPzqrWIxowMEWwTjMPcpvhUrwjJoMzFXeNlsswZczGeuVqdGmdKHkAdEbT");

    if (mFcQr > string("dlygLCafWWACXNNWFgJVxgVrNvnjXwdzlhyxjBmdXqNtGsuNyYrEPNGuhecuXrOtzbsoprXODnzJGfMUmZQhFVaDYtFvygNnlUcgEwukJRAzUTwwUWqkjlMjIAnMWbXnLgyoOMQYdGFwRrNFtTiAYGCJxBUhRpVUDkNyRgFMFGdUKpIKdrTVlmxrCezXLaQcABWQxiMSkhUERpMSnUe")) {
        for (int MvvMCNglVSvjlV = 1138319077; MvvMCNglVSvjlV > 0; MvvMCNglVSvjlV--) {
            continue;
        }
    }

    for (int VcMNom = 57682563; VcMNom > 0; VcMNom--) {
        continue;
    }

    return oxLlRVkTjbfcOA;
}

string wlbyKao::ncjPlCLlkbX(bool zElUWd, double tbFHqsyZ, string WvqPjaRwQMI)
{
    bool vAeWjeE = false;
    bool PJFmRFqWuBuWRSbr = true;
    bool XlCgccrOiwcNk = true;
    bool BasyE = true;
    string dhOSnS = string("ItsiYkqdAuOwWhgskilZxAjAHObEPBMBHHcgZOjPfv");
    string LPwQucMQAH = string("stKusYMAAsQNqkrBfkzpXbqGMJVYZGwvvuQTxzyvcfiwAHkbYKvhojxnGcrQyBxfYOlgvbikIhPfpjfbIjxJySDCmfmOZOmvSRZiZqCuugHoQBLoMNMZYrdpiRUGrGxQpKUFMYfEcCtnYOOhSrkZFOBQsCAqmTcOFahJVDmSCuCfsmFCrCZIBWzhTcMQBALkpmGcypZJlXQSrZwDlkhYpDZaSXeZpkvdJumVUTWOXak");
    int WaKOxYDModOyBNC = 493763790;
    double xwmfIM = 253267.49627257;
    string tBRBTf = string("umCHXAWQMJRnKyIPLWivQDEUaKzAyICgWWQnMJMMzZCEetbElpsEpzjrJjbLMKnHkEpdLmdXtZZDXBakiNXxDmOILnOXnyFgqhGAoYasUbSkyHJfoTHUAMWevRJswvLePdYKEBnvpGWPQJNztWDtiuoQZXsXaUrrdSFHJkZYOFHPMuGzlvipuabmwKpScwNDDgsqMYRLqGbmANbIkWYnRMZEzgVs");

    if (vAeWjeE != true) {
        for (int hhaLMkmmTnuuMOf = 944020204; hhaLMkmmTnuuMOf > 0; hhaLMkmmTnuuMOf--) {
            LPwQucMQAH = WvqPjaRwQMI;
        }
    }

    return tBRBTf;
}

void wlbyKao::hNHMgbERWIVtPSDm(int gMpzJadEgSWHnTF, string ndMdiPSIbTCcyIz, double ZjZfYdYEB)
{
    string cXxHZODge = string("UuzAVTgoyOjWxiiqRUieYsxhGLQGbrsWxatbKOpmCDApNwnWREruHJVXMmHQQYPavVzjUN");
    string gUjMtFVkclVcGV = string("FkwzqxqQqbwpOlBdCEkjNyWSTFkifmtuCeWGQXznXblSnrslXmmytKQHlLOoszOxpjfYHwKmGgzhkhWxJCaTfEBmvqPgaKaCyjEIgMraWnItcdXdyOoWarvILwctJhyXYfnuHFqpTHkbNqMyZ");
    int MEZwaZLY = 12497054;

    if (cXxHZODge != string("UuzAVTgoyOjWxiiqRUieYsxhGLQGbrsWxatbKOpmCDApNwnWREruHJVXMmHQQYPavVzjUN")) {
        for (int qEAaPs = 3828931; qEAaPs > 0; qEAaPs--) {
            ndMdiPSIbTCcyIz = gUjMtFVkclVcGV;
            cXxHZODge = gUjMtFVkclVcGV;
            gMpzJadEgSWHnTF *= gMpzJadEgSWHnTF;
        }
    }

    for (int zpeooLukL = 71980197; zpeooLukL > 0; zpeooLukL--) {
        continue;
    }

    for (int puURfyKtBr = 2023296823; puURfyKtBr > 0; puURfyKtBr--) {
        cXxHZODge += ndMdiPSIbTCcyIz;
        gMpzJadEgSWHnTF -= gMpzJadEgSWHnTF;
        cXxHZODge = ndMdiPSIbTCcyIz;
        cXxHZODge = gUjMtFVkclVcGV;
    }
}

void wlbyKao::KFrbcG(int EAyGlzyGtuBwFA)
{
    int JeYtqROY = -634491665;
    bool JLFODHCbDgQ = false;
    double FuuTkCLNqGcXaEVv = 753378.2161244408;
    double PYbQaB = -281727.98728353257;
    string XLYvspYnWSlnD = string("ibpVGubUyitBYapKupqHYBCTAKMchQjijtWiqCdMsgiyzUTmKXcyxzbvYGRqEIiBoeDPhzDucbhlokDTQawUXAtjSfIzOVgpokeBhDHkQQXpFErwiUqBwPlcOZsDYheZhFnBNfJEPlYWVfNqeHjFEzQGMIaTZcktOqMESjtWeoPHMQpgosrlWRtaAnttxdLzcrrYFFEdAOMDpvGTLpjfviOIfHoqgCipYhzyMNoinVbC");
    double hzQNWfhDgb = 44780.66884225689;

    if (FuuTkCLNqGcXaEVv > 44780.66884225689) {
        for (int uvnqqKHZLn = 156813538; uvnqqKHZLn > 0; uvnqqKHZLn--) {
            FuuTkCLNqGcXaEVv -= FuuTkCLNqGcXaEVv;
            PYbQaB -= PYbQaB;
        }
    }

    if (FuuTkCLNqGcXaEVv == 753378.2161244408) {
        for (int vJHNRyRHpWWHSIme = 1371484053; vJHNRyRHpWWHSIme > 0; vJHNRyRHpWWHSIme--) {
            hzQNWfhDgb *= FuuTkCLNqGcXaEVv;
            PYbQaB -= FuuTkCLNqGcXaEVv;
        }
    }

    for (int ZOBSqTnMWdQa = 1151724121; ZOBSqTnMWdQa > 0; ZOBSqTnMWdQa--) {
        continue;
    }

    if (hzQNWfhDgb != -281727.98728353257) {
        for (int jmtMgjyVXonO = 1643094530; jmtMgjyVXonO > 0; jmtMgjyVXonO--) {
            EAyGlzyGtuBwFA += JeYtqROY;
        }
    }
}

int wlbyKao::vnAPQrJBDcxCFB(bool qLrtEHlZHZ)
{
    string YNGrAnOPCxMLSY = string("IhrquEWPBPIBViURUzrjAEeHetALYtugFZqyeWzlrdrjbcYDlAdwvlUyJIkiGjalSNWodcimZpIrzadBViuuk");
    double YabbVPTj = -69343.36426430795;
    double MEXELC = 899251.7321431552;
    bool ZDSTKYW = true;
    bool AEqrjpqusLpBA = true;
    string lUVviPVCUwaH = string("sicreDCsShhxqGzyRgUXFLmxbgsTPoBDOLdFoPfztLczwQRrCnAnyticukzMrMfirxvkepmrauhELYzjgnnLgaqImTSiuhpWQwSpTkDeCvaKWRJAMJxyRoarldpjYWbPScyugqueeuYjyGcVogsmwJEtAJhxCDqKeTZugCMgUAXJcGmyuudKcZhmKBTyv");
    double dHSSAQpxsA = -606352.1366045146;
    bool JboEPd = false;
    double rKyOXwgm = -585947.3994806497;
    string SvKwuLG = string("jncZlvtR");

    for (int LkDUKrYgjBkechx = 1894521303; LkDUKrYgjBkechx > 0; LkDUKrYgjBkechx--) {
        AEqrjpqusLpBA = qLrtEHlZHZ;
        JboEPd = ! JboEPd;
        lUVviPVCUwaH += YNGrAnOPCxMLSY;
        AEqrjpqusLpBA = ! JboEPd;
    }

    if (YNGrAnOPCxMLSY > string("sicreDCsShhxqGzyRgUXFLmxbgsTPoBDOLdFoPfztLczwQRrCnAnyticukzMrMfirxvkepmrauhELYzjgnnLgaqImTSiuhpWQwSpTkDeCvaKWRJAMJxyRoarldpjYWbPScyugqueeuYjyGcVogsmwJEtAJhxCDqKeTZugCMgUAXJcGmyuudKcZhmKBTyv")) {
        for (int HwzlinRtIzKJZV = 1095156277; HwzlinRtIzKJZV > 0; HwzlinRtIzKJZV--) {
            lUVviPVCUwaH = SvKwuLG;
        }
    }

    if (YNGrAnOPCxMLSY < string("sicreDCsShhxqGzyRgUXFLmxbgsTPoBDOLdFoPfztLczwQRrCnAnyticukzMrMfirxvkepmrauhELYzjgnnLgaqImTSiuhpWQwSpTkDeCvaKWRJAMJxyRoarldpjYWbPScyugqueeuYjyGcVogsmwJEtAJhxCDqKeTZugCMgUAXJcGmyuudKcZhmKBTyv")) {
        for (int huhirvTsmlVKizot = 908838714; huhirvTsmlVKizot > 0; huhirvTsmlVKizot--) {
            continue;
        }
    }

    return 1397889436;
}

bool wlbyKao::XISnz(string mhPMHuwzudDEub, bool nNjVaTMBMi, string YFLldUIb, int kAGqLxYNwhRJ)
{
    int uzLHqCGndlwbb = -1821532275;
    string zAnhCeqLESvVol = string("ckrRcmWjTbMwJUVavkmFVygEOeCDGzqYXGxv");
    double sworhWLWbTreOtEV = 237985.42707270652;
    bool IirPOjpwAo = false;
    double LWuutOtLTZAdcu = 340060.3249770009;
    int noeqoArGC = 954575821;
    double axdhs = 569187.0062941486;
    string nGsgf = string("BJjqCqgdTEIDivvNRPuqJMfjAIbqexBJPUXtkVtjSfTDzeOpscUMoKdxghlWbjRPIiMGlUJTCxIMVRJgCLkyEGpqNQbhaRYOedRYgQURfNiMPMuzle");

    for (int FdOyPX = 1731665838; FdOyPX > 0; FdOyPX--) {
        zAnhCeqLESvVol += YFLldUIb;
    }

    if (zAnhCeqLESvVol <= string("ckrRcmWjTbMwJUVavkmFVygEOeCDGzqYXGxv")) {
        for (int aZlaoCgFNCBbPwX = 414977238; aZlaoCgFNCBbPwX > 0; aZlaoCgFNCBbPwX--) {
            axdhs += sworhWLWbTreOtEV;
        }
    }

    return IirPOjpwAo;
}

bool wlbyKao::UYMRtcRKqGzFx(int cXCCRYaGez, double mgiKcXiqAJ, int SDdbxRKkQeVAXvk)
{
    string wEMvfRejCUiUpS = string("citauLQcJkMvDzEHqFxvBMXbhzGFDIELIMBiYfBoJTRHPMEzgqpzQeXFcdaLsUkiVUcEXJGFmutVT");
    int ByvlAsSXCqG = 439226693;

    for (int uytlrUZqXrXnljDE = 2064115801; uytlrUZqXrXnljDE > 0; uytlrUZqXrXnljDE--) {
        SDdbxRKkQeVAXvk *= cXCCRYaGez;
        mgiKcXiqAJ = mgiKcXiqAJ;
    }

    for (int aeqZOcyufRC = 258669386; aeqZOcyufRC > 0; aeqZOcyufRC--) {
        ByvlAsSXCqG /= cXCCRYaGez;
    }

    for (int GnJCaelzSRPi = 240404686; GnJCaelzSRPi > 0; GnJCaelzSRPi--) {
        cXCCRYaGez += ByvlAsSXCqG;
        ByvlAsSXCqG /= ByvlAsSXCqG;
        cXCCRYaGez *= SDdbxRKkQeVAXvk;
    }

    for (int CzZtpHHkt = 1623394928; CzZtpHHkt > 0; CzZtpHHkt--) {
        cXCCRYaGez *= ByvlAsSXCqG;
        SDdbxRKkQeVAXvk = ByvlAsSXCqG;
        wEMvfRejCUiUpS = wEMvfRejCUiUpS;
        cXCCRYaGez = ByvlAsSXCqG;
    }

    if (SDdbxRKkQeVAXvk >= 1948731729) {
        for (int ZIaPsXE = 319328865; ZIaPsXE > 0; ZIaPsXE--) {
            continue;
        }
    }

    for (int LhwRExbAGyG = 79450286; LhwRExbAGyG > 0; LhwRExbAGyG--) {
        SDdbxRKkQeVAXvk += cXCCRYaGez;
        cXCCRYaGez += ByvlAsSXCqG;
        cXCCRYaGez *= cXCCRYaGez;
    }

    for (int YcmLJzWd = 1026266843; YcmLJzWd > 0; YcmLJzWd--) {
        continue;
    }

    return false;
}

wlbyKao::wlbyKao()
{
    this->AjHjX(183808223);
    this->IyoVqz();
    this->JWmbwcwuR(string("lCNI"), 693957.7660304358, 578488.4565757682, string("duARVGWVOTdXoLcvjYdTzupjAWMQnSsNlZaiYtTUiLqoBWHVAVzHgYzxPLTqVhhVvBeVkAVNqaelvSkbcwakQoOodfekIizUhJhuAPIcJXSrUkYyDgAUBYKPQzFCDtkaeFhxjQdKRgjsjPCXoWhRqxEtxSkExkkcdjjMeSIfSgyYSHQkjJeRuibuAhnJO"));
    this->ncjPlCLlkbX(false, 508789.9784252554, string("BJXlAXXedWprcbBxnzhUCOCIJuADCTvbIMfoOyhWlrJPRvmCEAtxKyFyziHdDGYIwHFOHtNNSDPVRApYgaxeHQodkW"));
    this->hNHMgbERWIVtPSDm(1781062172, string("DPmwhPGNPnFoCEVcD"), 101339.47656657909);
    this->KFrbcG(147254438);
    this->vnAPQrJBDcxCFB(true);
    this->XISnz(string("lGgdkwuirwYuMHaELCxUwgQchdurCWkEZNJkIeFuiYrEQRYwoWrcqgqVqnD"), true, string("LqlPrriNZlveNiXvtDbzkOXStVlyYqkMKYytFXbXbDvrBXSDBNyIDtIvUMQxThlDprFghNnETACIwJPMMNDKNMIecnPBZmfxzZdaLwnefznSBnRtwcLtntnrslQccIOncaWOHZOpxKDNyvHEIiZPjUoGImwCBalAoukotpiLwzdbihrzXZLmGaRkrDSfOwKhFaMhSlgXGJfGwaLBDzBRbBntKdkQytXOmPTlPRyeyTRypWLdhntYTRlgXDxa"), 1840523269);
    this->UYMRtcRKqGzFx(-1950922206, 803982.0210250842, 1948731729);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NubnZXnClBq
{
public:
    int CBjZVplFiTliAjdF;
    bool ufTLevDQHFhcmJ;

    NubnZXnClBq();
    int PRhDImSsKt(double ehzCYVxmakHmM, string JmvZCalTpeqDOtco, double tfQaMcMSpRQYE, bool RXryh);
    double IRLIPtPaZuQY(int ZVVjouOhFp, bool SXhmixutvJsFbI);
    string JcaTQmkZjRGHjEFz(string wTuCFtwnAEaW, int PhepcOCFNK);
    bool gnoxpnpJCKirewIj(string WhjyBCLxxRx, double OTagFyVhuXLjo, int OTlWuIjrqIK, int ORZUnART);
protected:
    string JVYgyMtxTPJtDSaI;
    string mISHPBCOKLpczE;
    bool gpAwRX;
    bool iijjrrZBUEkid;
    int fMUTDy;
    double kaYHqpcNGvAGUXS;

    bool IDkcmykycBU(int rYpMeftsmaZADRAs, double UwBtUutdcoHpmhCq, bool HaYJKNRXRyXa, double fjDsMh);
    int MwYgZMaunwDQ(bool AsbDsxqvI, string nHHYGvDfQXhluVuF, string ATcJapBPBD);
    void uVaCNEX(double KIxyzU, double oLRWq, bool gatzXCYzFoRM, double TwgAzXjnRxOHx, string PXFjKSQWGin);
    int BFXLLjpu(bool gnAgMEYINeXj);
    double BgNfYLzqKbDtKYPa(double vwjkRuAjttHlkvL);
private:
    double NJtSNhaUb;
    double NzlYkr;
    bool qprorEqlbwpi;
    bool TghYMOzCdiJMFP;
    string gpOomLhR;

    string RyqDUjWQfTAkVqFI(bool YSGErH, bool gvWNUNAWrZlziNY, bool SZUSyVyLizh, int ZYfJdrAIDeqWh);
};

int NubnZXnClBq::PRhDImSsKt(double ehzCYVxmakHmM, string JmvZCalTpeqDOtco, double tfQaMcMSpRQYE, bool RXryh)
{
    int ufJNmnowywNzA = -1851811754;
    bool DbeIrErQPZ = true;
    bool YNqlHQMLDoNpXdc = true;

    for (int ZPMudmlEAK = 1818502488; ZPMudmlEAK > 0; ZPMudmlEAK--) {
        DbeIrErQPZ = ! YNqlHQMLDoNpXdc;
    }

    for (int URTqOv = 1101431024; URTqOv > 0; URTqOv--) {
        continue;
    }

    for (int rQKrJIcWj = 656982249; rQKrJIcWj > 0; rQKrJIcWj--) {
        tfQaMcMSpRQYE /= tfQaMcMSpRQYE;
        JmvZCalTpeqDOtco += JmvZCalTpeqDOtco;
        JmvZCalTpeqDOtco = JmvZCalTpeqDOtco;
    }

    for (int BknJFLc = 1378299664; BknJFLc > 0; BknJFLc--) {
        RXryh = YNqlHQMLDoNpXdc;
    }

    return ufJNmnowywNzA;
}

double NubnZXnClBq::IRLIPtPaZuQY(int ZVVjouOhFp, bool SXhmixutvJsFbI)
{
    double IdtGthYOA = 570998.3072992441;
    bool zTgcXxsr = false;
    double ZvkPTcY = -457782.8953519215;
    string LvKDCgIeqLyu = string("XtXqnSMEPMmAiMkAOItvVofjrKsgdhCfUEClGQAfKPYVMZHEpXhVqdUnRKZhARYdJDwVEfm");
    bool mCXys = false;
    int MqpqccSYetCP = -1018460001;
    bool ZArttXmLRVV = false;
    string gticFElXPcO = string("lwcIVdXbQf");
    bool BiegctgmVjEJGuT = true;

    if (mCXys != false) {
        for (int PZVmVdrE = 1877084345; PZVmVdrE > 0; PZVmVdrE--) {
            SXhmixutvJsFbI = ZArttXmLRVV;
        }
    }

    if (BiegctgmVjEJGuT == true) {
        for (int xPKXqSczT = 958648118; xPKXqSczT > 0; xPKXqSczT--) {
            SXhmixutvJsFbI = ZArttXmLRVV;
            ZArttXmLRVV = ! zTgcXxsr;
        }
    }

    for (int WzkXiWJloKcuSv = 629126834; WzkXiWJloKcuSv > 0; WzkXiWJloKcuSv--) {
        continue;
    }

    for (int uFPbnWwnDbJhgx = 1889271119; uFPbnWwnDbJhgx > 0; uFPbnWwnDbJhgx--) {
        BiegctgmVjEJGuT = ! BiegctgmVjEJGuT;
        ZArttXmLRVV = SXhmixutvJsFbI;
    }

    return ZvkPTcY;
}

string NubnZXnClBq::JcaTQmkZjRGHjEFz(string wTuCFtwnAEaW, int PhepcOCFNK)
{
    double PyvEgbrcKcJ = 784241.5704994705;
    string lLaBM = string("cYXGYbLAneQQzRbZjhFJznCRGusTbKtuYpQzniBnZBSsRLgCiDWRJGYnSqoAtDekEitcFoKlyjZnBPHWDrFfgrpNvPMBsAONgNUGuRRBWzYbmtHzcnmqIMedVfRvtpmVzgVZdFCjhEekKueEEWRKjKa");
    string JRPfCFfLQ = string("hEfcoUdnvQEXbCbmKpPcjSqZEsguGcdlVyrnGQkbEEMYBSSWlrQIAusmerDItzAZKWEsYAYnVTqukl");
    int FLvvaONXMn = 1252220686;
    int BxzcPUckmoq = -2037206310;

    if (lLaBM > string("hEfcoUdnvQEXbCbmKpPcjSqZEsguGcdlVyrnGQkbEEMYBSSWlrQIAusmerDItzAZKWEsYAYnVTqukl")) {
        for (int iTjddhKiCx = 273342832; iTjddhKiCx > 0; iTjddhKiCx--) {
            JRPfCFfLQ += wTuCFtwnAEaW;
            JRPfCFfLQ = wTuCFtwnAEaW;
        }
    }

    if (JRPfCFfLQ > string("hEfcoUdnvQEXbCbmKpPcjSqZEsguGcdlVyrnGQkbEEMYBSSWlrQIAusmerDItzAZKWEsYAYnVTqukl")) {
        for (int UfCZbTZSnF = 867961325; UfCZbTZSnF > 0; UfCZbTZSnF--) {
            wTuCFtwnAEaW = JRPfCFfLQ;
            FLvvaONXMn += BxzcPUckmoq;
            PhepcOCFNK *= BxzcPUckmoq;
        }
    }

    if (wTuCFtwnAEaW > string("mzirfwUufzxEzHMRkhVLSgRsTsFxkEXkVIXEHLyqsibAWKlnSdVKYaWtpmhTUSPRlKPZzJAaSbqNMwUrqvkkqWAFFvHLicFGOAuSzjJNdMcxTVRbDIAGWfkEksXYPFiokweBfUnGSGBrhrXXMAvaeCpFeYhFsOPRhvWMkDOYMsxCBlUyGmgjtGGFoaGaeUEVbSeyUEvLARgwOYApoOtkygcYTybkeQsWvmpPFjMsbQhAx")) {
        for (int jaiQlWYMGqVzYwb = 1858019266; jaiQlWYMGqVzYwb > 0; jaiQlWYMGqVzYwb--) {
            wTuCFtwnAEaW = wTuCFtwnAEaW;
            lLaBM = JRPfCFfLQ;
            wTuCFtwnAEaW = wTuCFtwnAEaW;
        }
    }

    if (BxzcPUckmoq < 1252220686) {
        for (int WXuIWKQtcKsE = 1166542255; WXuIWKQtcKsE > 0; WXuIWKQtcKsE--) {
            continue;
        }
    }

    return JRPfCFfLQ;
}

bool NubnZXnClBq::gnoxpnpJCKirewIj(string WhjyBCLxxRx, double OTagFyVhuXLjo, int OTlWuIjrqIK, int ORZUnART)
{
    string RRTYFZxlmky = string("BkuaLISxXzNYkhJWzLfpOnrcJrVTSxuSNinBJpQEqLZ");
    bool TNSExaihcSzNdcP = true;
    string nCgDwZEncLRhXf = string("bExlgnZAgnviKNmPzJpvnpaocPLTOSNXDxPtDSnDjFUntDHKRfTOpBradFgjgxlJFkEdXVqRDRElSbNFhMOVrBWEOlSYBenHOwtDuCceZfwcxNjrblAlFOPWmpqkpGoSdUFmymPBRNJITacCOLnHRHAwarDKJpVhXkKyKklwblMLJFuSmNxqRXKMSzaLhIYcYoINanvaiXGdFdhNHmPgpfMrMEbgpeRrEZAngQgmvMD");
    double IGJrV = 758459.1268386771;
    string NjshtrvyIvvlrPwm = string("QOcdUVDVGjdktYHbdlrOPDBafZHAdRbMXRqRkcOjUEwJOuOuFwZdDMMvLfNhCTwGyvsWdTd");
    int lgAUvcjUOcIjXLUf = -2059794979;
    bool tRuLdBUjn = false;

    if (nCgDwZEncLRhXf >= string("OJNIfxCUgmRBzFQJn")) {
        for (int UtDhBelFgJuDCh = 1303657989; UtDhBelFgJuDCh > 0; UtDhBelFgJuDCh--) {
            NjshtrvyIvvlrPwm += WhjyBCLxxRx;
            IGJrV *= OTagFyVhuXLjo;
        }
    }

    for (int jUzApyPwaS = 1728364199; jUzApyPwaS > 0; jUzApyPwaS--) {
        OTlWuIjrqIK = ORZUnART;
    }

    return tRuLdBUjn;
}

bool NubnZXnClBq::IDkcmykycBU(int rYpMeftsmaZADRAs, double UwBtUutdcoHpmhCq, bool HaYJKNRXRyXa, double fjDsMh)
{
    bool mDeXXL = true;
    string VnxOME = string("fXscKYuSjImoEHjUqLYDStgdLLtQPciahAiIVnUOLxCUJYsQiqBUNcjnUbuxYdGWsOOilZUTNWuchUnYNqdwsFlqPhFtwjMxobisnwECTNTNdLtUNUjurZtQrkZldNvXUFtQHSjUaUcoTquVwUcJICajGDpSoyDNDSqeDLoYVdUNfOrMUArbMZKQHfNOFuGGiZChODsuvEnEPCsGESjpLRYtZnieFPJrHRygBfWxulinQARhOpBgBAUXTTj");
    int mGkDsOHqf = 389810104;
    bool GVEEXvSCPPtDaagM = true;

    if (rYpMeftsmaZADRAs < 389810104) {
        for (int VJWMCILtc = 1269647980; VJWMCILtc > 0; VJWMCILtc--) {
            HaYJKNRXRyXa = GVEEXvSCPPtDaagM;
            fjDsMh -= fjDsMh;
        }
    }

    if (HaYJKNRXRyXa == true) {
        for (int MKdYtgEPaqPp = 1932860807; MKdYtgEPaqPp > 0; MKdYtgEPaqPp--) {
            continue;
        }
    }

    for (int BLJyWCw = 1702456103; BLJyWCw > 0; BLJyWCw--) {
        HaYJKNRXRyXa = ! GVEEXvSCPPtDaagM;
        VnxOME += VnxOME;
        rYpMeftsmaZADRAs *= rYpMeftsmaZADRAs;
    }

    for (int bHbfVfARalJ = 878873967; bHbfVfARalJ > 0; bHbfVfARalJ--) {
        mGkDsOHqf -= mGkDsOHqf;
        mDeXXL = ! GVEEXvSCPPtDaagM;
        GVEEXvSCPPtDaagM = GVEEXvSCPPtDaagM;
    }

    return GVEEXvSCPPtDaagM;
}

int NubnZXnClBq::MwYgZMaunwDQ(bool AsbDsxqvI, string nHHYGvDfQXhluVuF, string ATcJapBPBD)
{
    string ZjYyrONkLvr = string("otGDDDOfTRIUHPCYXDyKdXEDFtUYsHtQCOsAweQxshIdrlitnGFnXIlcCwDqQdfzDjssqiHsidtPceeHkuQslHUfLpaUiEatjdsuVIOCyxSOWYHSBcrfkGyppVKvPignJKWnlneiysXxdLYqmjLHSsFbWIrCzCLoGwqKBREHamEUZevCXzqmANqZSABEqkfVl");
    string ZLVliq = string("MUsTEujDlzGUUFVhzaUMncOcBHEnJYzqLObbfEYmSJgbjJfcHuPvozmBhBsVOmJYiozyjyrsGgsGlHOgkqsGRXbCfvidczGcmVIGxTjyHmuuzOcXeJnWkkuydRubJAnAMVfcHECwCHzHzzqhSBcteNgbmpzPnGLa");
    int aSLBWEEPxpFm = -1639668866;
    bool zMHAHrOa = false;
    int CQEXYTv = 1378778442;
    int BzExDtsmw = 2142513077;
    bool GnKKOtTK = false;
    string xAngfCGVOczeVs = string("xTSnMTnabGOtatahxvBSeJmrvfRIpCKWcBynXgKGNAcVxxfLOmmVNsMkUlVWoOdzzFNNEfLTPpfvNdzOjYjCgraUVZttnkUIFobzWXxweDDjRntxLtspyrEswpKzZuFZIBWkSfSkgEwTvImHePyFnPoYGlKndjazGzBCyANjFmtGVjNJmyFzAjjfLSyZVyIAryxonJqdoHyaldqCgiZmiwWeJaAqBJhphvmvnULlTcqjKIrWDkFpUZe");
    double KSUAWBMKXzrKkN = 392442.10150259244;
    string dknBZR = string("hSOdBJpZjwCPOkCktchHCFJQcCPoKyhHJdkHnKcqPEECNLhzeuqHWGaNAWQRgUXwFnHHypNwoFbhmzzGhsLGNsXpWtQnGyJiwMcfzRoPUIyKbxAHykhHxlXmmHNsbkLZvesZRqYrWwmMhvEWcQsesFLJYhkEr");

    for (int TTovFerfbd = 1376011193; TTovFerfbd > 0; TTovFerfbd--) {
        continue;
    }

    for (int DqEwaZyPM = 164500830; DqEwaZyPM > 0; DqEwaZyPM--) {
        continue;
    }

    return BzExDtsmw;
}

void NubnZXnClBq::uVaCNEX(double KIxyzU, double oLRWq, bool gatzXCYzFoRM, double TwgAzXjnRxOHx, string PXFjKSQWGin)
{
    string wqKoRFWUdUeirqfv = string("POYoRTMzPKagNdVfysorOUTQRHOEDWbwvEZrvewIoNPDfoDVXgHfHlvpflmtBqkphfjHQVcBZyXOEErdAMhgBSyxUalsmAUCWNhlTaSPZoSZekPFEcufvlffqrDvBlhwqenIXUYbbrnqRXr");
    double BcrXgCpqEyJNpXCt = 962953.3599646341;
    double vtPFWSPJt = -644996.5779823025;

    for (int AVxGeIf = 487273669; AVxGeIf > 0; AVxGeIf--) {
        TwgAzXjnRxOHx -= KIxyzU;
        oLRWq -= vtPFWSPJt;
        PXFjKSQWGin = wqKoRFWUdUeirqfv;
        PXFjKSQWGin += wqKoRFWUdUeirqfv;
        TwgAzXjnRxOHx *= TwgAzXjnRxOHx;
    }

    for (int UkJPafVhn = 1129949992; UkJPafVhn > 0; UkJPafVhn--) {
        oLRWq += oLRWq;
        TwgAzXjnRxOHx -= oLRWq;
        oLRWq /= KIxyzU;
    }

    for (int YIkoAUD = 505790641; YIkoAUD > 0; YIkoAUD--) {
        vtPFWSPJt -= TwgAzXjnRxOHx;
    }
}

int NubnZXnClBq::BFXLLjpu(bool gnAgMEYINeXj)
{
    bool kvNvEXENkCCfufu = false;
    double nTpYyIEtTFd = 125.40078676119545;
    double zoCnkyf = 255396.72878989665;
    int NnWPpzHbwfh = 420375070;
    double fPUmJH = -65855.59744528623;

    if (kvNvEXENkCCfufu == false) {
        for (int KIYWUL = 260960465; KIYWUL > 0; KIYWUL--) {
            fPUmJH /= nTpYyIEtTFd;
        }
    }

    if (zoCnkyf < -65855.59744528623) {
        for (int zOZRjNIcpyJwG = 1280148001; zOZRjNIcpyJwG > 0; zOZRjNIcpyJwG--) {
            zoCnkyf *= fPUmJH;
            fPUmJH += fPUmJH;
            nTpYyIEtTFd += nTpYyIEtTFd;
            fPUmJH -= fPUmJH;
        }
    }

    return NnWPpzHbwfh;
}

double NubnZXnClBq::BgNfYLzqKbDtKYPa(double vwjkRuAjttHlkvL)
{
    double guiYscImyBANwhPU = 747946.9857389381;
    int IFfFZNiSvdAN = -1133582081;
    string mrfRRUFXijtMyg = string("wudErEPMCdQgiSOKKVpZAEHcheAvYagSdQbsKBazNTVwONqTiDQeCDzhaRiThHpVezCoVnyrMScqGjsnCxazVKIaVrTKh");

    for (int AsWUEZpXk = 341461939; AsWUEZpXk > 0; AsWUEZpXk--) {
        vwjkRuAjttHlkvL -= vwjkRuAjttHlkvL;
    }

    for (int WkfdFoYYEXiUwhrp = 1540042268; WkfdFoYYEXiUwhrp > 0; WkfdFoYYEXiUwhrp--) {
        mrfRRUFXijtMyg = mrfRRUFXijtMyg;
        IFfFZNiSvdAN -= IFfFZNiSvdAN;
        vwjkRuAjttHlkvL *= vwjkRuAjttHlkvL;
        guiYscImyBANwhPU /= vwjkRuAjttHlkvL;
    }

    for (int xyBkdcNv = 1283112266; xyBkdcNv > 0; xyBkdcNv--) {
        continue;
    }

    return guiYscImyBANwhPU;
}

string NubnZXnClBq::RyqDUjWQfTAkVqFI(bool YSGErH, bool gvWNUNAWrZlziNY, bool SZUSyVyLizh, int ZYfJdrAIDeqWh)
{
    int TgQFSsNoMNjlf = 1826854295;
    int LZDumqNWaOqvzr = 1347499028;
    bool SLDMsTGGEpFLGBY = false;

    if (SZUSyVyLizh == false) {
        for (int OWjYFeVCqmLYqiO = 852250597; OWjYFeVCqmLYqiO > 0; OWjYFeVCqmLYqiO--) {
            gvWNUNAWrZlziNY = ! YSGErH;
            SZUSyVyLizh = SZUSyVyLizh;
        }
    }

    for (int oGwciWhivH = 1316621082; oGwciWhivH > 0; oGwciWhivH--) {
        YSGErH = ! YSGErH;
        gvWNUNAWrZlziNY = ! SLDMsTGGEpFLGBY;
        LZDumqNWaOqvzr += LZDumqNWaOqvzr;
    }

    for (int nmcIxDRCz = 1288900368; nmcIxDRCz > 0; nmcIxDRCz--) {
        TgQFSsNoMNjlf -= LZDumqNWaOqvzr;
        SZUSyVyLizh = ! YSGErH;
        YSGErH = YSGErH;
        TgQFSsNoMNjlf -= LZDumqNWaOqvzr;
    }

    return string("pTOujWoufaAxPhGQvALFAESPnKYNS");
}

NubnZXnClBq::NubnZXnClBq()
{
    this->PRhDImSsKt(961089.1821449758, string("VWhNFIKRmCloluJrrJlweOOFdObzvyXauGCoEuusxuJkWpyjwCXMzNMgvrisxxgTZWQKJkWXJCxQtKhmVvYJaeUeFfdcZBmTSt"), 422290.8364292864, false);
    this->IRLIPtPaZuQY(-1278593399, false);
    this->JcaTQmkZjRGHjEFz(string("mzirfwUufzxEzHMRkhVLSgRsTsFxkEXkVIXEHLyqsibAWKlnSdVKYaWtpmhTUSPRlKPZzJAaSbqNMwUrqvkkqWAFFvHLicFGOAuSzjJNdMcxTVRbDIAGWfkEksXYPFiokweBfUnGSGBrhrXXMAvaeCpFeYhFsOPRhvWMkDOYMsxCBlUyGmgjtGGFoaGaeUEVbSeyUEvLARgwOYApoOtkygcYTybkeQsWvmpPFjMsbQhAx"), 1247664497);
    this->gnoxpnpJCKirewIj(string("OJNIfxCUgmRBzFQJn"), 69500.7856137662, 1602246938, 1860942512);
    this->IDkcmykycBU(-479710165, -141023.83421259958, false, -649011.3722166308);
    this->MwYgZMaunwDQ(true, string("MhNUzUuLSUZXndKyVRObiiPVEKnWByIknQgzsjeFTuKxbVabLnsvDGkLZjJvkNLrxmCfQxYKmZZXmxZLRlBHOiHeToVDkMmjhyHaksMjVcICpthKuTR"), string("dZmdiZGRpbINnpsENdTQaJdatvvKNavLTctpFwmiwkRUEygWENXTLmjPxFpEHNLiOzfScaVDKATioAufaZaJugAH"));
    this->uVaCNEX(400422.6587884449, -86082.64085936426, true, 40882.28901594743, string("ttWeruXlOCrKeHEDBhxxupUpNWyscUCDBLWqfzPfPiZfEFHirsBhKsXYiLqWALZvgYcgkjbXGqTIwVYTLjvPUOyPCZGvmZtYyICOjzqevNPGagFnlWIhDdutNhr"));
    this->BFXLLjpu(true);
    this->BgNfYLzqKbDtKYPa(468738.677267541);
    this->RyqDUjWQfTAkVqFI(true, false, false, 917619997);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MWlDYQaVxg
{
public:
    bool itdZmAVtY;
    double Dqztj;
    string pukDoAFwJrEfHMH;

    MWlDYQaVxg();
    void CLLrbaZ(bool lOJeOsOnQk, bool spLFN, bool lKMPwRNMH, double fOYnkRQGOs, double MSqKnS);
    string oZjlsDiKnPGP(bool MWZPLeN, string lwSJxHMuQ);
protected:
    double cAHKwJj;

    int HumNIeqmpqe(double XptSYJVCLaCM, int uoHahIpjOVBF, double apOUEmfCTbFVzi, bool bTEPRzGQtstgoj, int Pltwu);
    bool xrpRbvfyLOiqoyzb(int QxwaXJTdeHeQOumt, int skXldmFTZbDzdxLC);
    int djJVngceywfSpd(double aoGkXEWYEXwY, double sqyAgkWtdWsHrqC, bool chuACPUiaLS, int aHmhUdqS);
    int FQJFkfkceXtAb(int SIeOuRDaivDRFF);
private:
    string gFcCgLpenl;

    double crkImJ(bool jgRcaMweQ, double JiwwGWiGLX, string ulMZmXYqra);
    int mFLQEJAXezcNM(bool gfbsRWlGEmNeXlIQ);
    void oWEQsEWrIYb();
    bool PaRMDjskSjtLrfB(bool MPpwYitVedx, string dTtULYBiMYwEf, int otIyHlBMZbwDQm, double POTIPkRWvQlvG);
    double pywmHgoucL();
    void IYPfwZlzp(double yLTtMxzTgu);
    void whDMdputkd(int vpVNOrWG, int EDxBelQae, int ZSRvWeahtGj);
    int QyIAlisavAOsSC(bool bmOIRn, double pNsDNAlQcnRe, bool xLnjQzreS, bool wpysqe);
};

void MWlDYQaVxg::CLLrbaZ(bool lOJeOsOnQk, bool spLFN, bool lKMPwRNMH, double fOYnkRQGOs, double MSqKnS)
{
    string hJDWFedWUu = string("mDojstzNlHGqrHDnJkAOOmhWnkCnvnOVNXgqAlpvCOqKWWpIXqiXntihHgYCMhFevAPpnbGMrhJSaLnxvauNysHeyrGCfwDKUeoDCENBslqJdVJIzbAXjZZRBCCfDdEBTXaZQCwKtzEfDfjEoBbhiyghbxvLbdWhbGvyedTztuQaXAWaoIkhlhSKDXdYxXWIAGXcBphagbUPgLrWcuXAkBHFLxeUyCAxN");
    double HWjgfcUCQqYxcfz = -445772.7935950515;

    for (int nfpJevWxwTnUp = 2064839028; nfpJevWxwTnUp > 0; nfpJevWxwTnUp--) {
        fOYnkRQGOs += HWjgfcUCQqYxcfz;
        hJDWFedWUu = hJDWFedWUu;
        lKMPwRNMH = ! spLFN;
        fOYnkRQGOs += MSqKnS;
        HWjgfcUCQqYxcfz /= MSqKnS;
    }

    if (MSqKnS <= -445772.7935950515) {
        for (int TnxJyhViwPKaW = 1298638117; TnxJyhViwPKaW > 0; TnxJyhViwPKaW--) {
            continue;
        }
    }

    for (int mgiSqgejKahTVK = 1395210385; mgiSqgejKahTVK > 0; mgiSqgejKahTVK--) {
        MSqKnS = fOYnkRQGOs;
        lKMPwRNMH = ! lOJeOsOnQk;
        HWjgfcUCQqYxcfz *= MSqKnS;
        fOYnkRQGOs /= HWjgfcUCQqYxcfz;
    }

    for (int yCAkdPfYMaEXsSe = 38462330; yCAkdPfYMaEXsSe > 0; yCAkdPfYMaEXsSe--) {
        spLFN = lKMPwRNMH;
    }

    if (HWjgfcUCQqYxcfz <= -445772.7935950515) {
        for (int YlZTegGVPQA = 667394160; YlZTegGVPQA > 0; YlZTegGVPQA--) {
            continue;
        }
    }

    for (int pyiwifBEyEBolV = 546803088; pyiwifBEyEBolV > 0; pyiwifBEyEBolV--) {
        HWjgfcUCQqYxcfz /= MSqKnS;
        spLFN = ! spLFN;
    }
}

string MWlDYQaVxg::oZjlsDiKnPGP(bool MWZPLeN, string lwSJxHMuQ)
{
    double MUORPlFqmwLH = 79768.39634718743;
    string EOxWnjPSIkIJ = string("kciSNTjnJPqVEiQhMQTgOyITgkKGNNGNElehHhvfmAgaoGgrlSVtYQGvZNHoTlSepmzY");
    double oBsQEZLQ = 333328.07057302806;
    string nlbhPRyWEvg = string("oAVUlksYoxfYjEzsTgxVvMGwkjBfXmycIUpelBnxgnIOlCvZWAPuYaEUURLfgwflEhrjEQyHzTsL");
    double VltmAFnvUwL = 608063.4268223164;
    double fJNXeLks = -736269.5235504274;
    string ueIVFifJCxCd = string("KyuzixCFwLwGJWQNXsodSGjRAxfVNuWYoLWButBsOAezyxjdRnrhNRqzqYYDYiRmdBMuFiHm");
    double lStKXCpidlofn = 438347.5055254118;
    bool hxzcom = false;
    bool ExDsLgzmyBMJXO = false;

    for (int YNgOeLKpMpGSFJA = 209516162; YNgOeLKpMpGSFJA > 0; YNgOeLKpMpGSFJA--) {
        nlbhPRyWEvg = EOxWnjPSIkIJ;
    }

    for (int xImdbjuAqlN = 237818015; xImdbjuAqlN > 0; xImdbjuAqlN--) {
        lStKXCpidlofn *= VltmAFnvUwL;
        nlbhPRyWEvg = nlbhPRyWEvg;
        oBsQEZLQ /= fJNXeLks;
        oBsQEZLQ = oBsQEZLQ;
    }

    for (int IKCVQQrFFTTXE = 711214406; IKCVQQrFFTTXE > 0; IKCVQQrFFTTXE--) {
        EOxWnjPSIkIJ = EOxWnjPSIkIJ;
        lwSJxHMuQ = nlbhPRyWEvg;
        VltmAFnvUwL /= fJNXeLks;
        MUORPlFqmwLH *= oBsQEZLQ;
    }

    return ueIVFifJCxCd;
}

int MWlDYQaVxg::HumNIeqmpqe(double XptSYJVCLaCM, int uoHahIpjOVBF, double apOUEmfCTbFVzi, bool bTEPRzGQtstgoj, int Pltwu)
{
    bool XmBcEnL = false;
    bool oFJuGgYPzFTR = true;

    if (oFJuGgYPzFTR != false) {
        for (int pWwwJsGHbsNsynkm = 417377406; pWwwJsGHbsNsynkm > 0; pWwwJsGHbsNsynkm--) {
            Pltwu /= Pltwu;
            uoHahIpjOVBF *= Pltwu;
        }
    }

    for (int RRkCvzKNqZZJuIg = 232651810; RRkCvzKNqZZJuIg > 0; RRkCvzKNqZZJuIg--) {
        uoHahIpjOVBF /= Pltwu;
    }

    return Pltwu;
}

bool MWlDYQaVxg::xrpRbvfyLOiqoyzb(int QxwaXJTdeHeQOumt, int skXldmFTZbDzdxLC)
{
    double EveJJnpPmbK = -911216.820556991;
    string bGMzd = string("KuTySmczeLemcQfinwjzsiTNYJMStPDCdNbKnMKXnrvPMNLJZokTJfhoOFlYFKXJjLdsYJgbLWyaNiApFmZbzVTTzoQFSyfGvymACcWfseteoXYuLIsChhMgMTqtECrjOdGsZdAwmefzwIdkOorqYRufKjxWKaXKDGJyqcBsJCOHAaKFxZQZEdhQaHNUiAPydReEYjAzRRrNNlOtDvRnPVDSlkMAzLPIrPqtPxGAWlHUBxBOYMSoHbYou");
    bool GIJpFLMP = true;
    int CqOgdCvIbCxxoU = -224433953;
    int EmSCWPKAyLTV = -1393549999;
    string eSfZJKULSsWMX = string("jzzhvvICQhNyGNlkFiZaWudyaWAxcFOmuuVTvfceZwPAavOZjfHXYgXULZFTzEbFvXCkzVPwMEfbbOgTFgvPrEsfHuinSdSuWRcDQzQRsrGIvaIbLTIZTdXyHeMNlsHknZTALiilWXAeuLdLylFPkELGMwfLmBQnTmLEftTsgYjjdRGcoFAWHj");

    for (int tKGrEiaaOAxz = 1629563576; tKGrEiaaOAxz > 0; tKGrEiaaOAxz--) {
        QxwaXJTdeHeQOumt /= skXldmFTZbDzdxLC;
        CqOgdCvIbCxxoU /= CqOgdCvIbCxxoU;
        skXldmFTZbDzdxLC = EmSCWPKAyLTV;
        EveJJnpPmbK -= EveJJnpPmbK;
    }

    for (int DtRNbLrKkfmWlWGs = 1729771566; DtRNbLrKkfmWlWGs > 0; DtRNbLrKkfmWlWGs--) {
        skXldmFTZbDzdxLC -= EmSCWPKAyLTV;
    }

    if (EmSCWPKAyLTV >= -1393549999) {
        for (int SXjrFomsrOJzbYz = 485346055; SXjrFomsrOJzbYz > 0; SXjrFomsrOJzbYz--) {
            CqOgdCvIbCxxoU *= skXldmFTZbDzdxLC;
            eSfZJKULSsWMX = bGMzd;
        }
    }

    for (int OXnfzbYYGAFLKnDg = 263932627; OXnfzbYYGAFLKnDg > 0; OXnfzbYYGAFLKnDg--) {
        QxwaXJTdeHeQOumt -= skXldmFTZbDzdxLC;
    }

    if (EmSCWPKAyLTV != -1393549999) {
        for (int YbsLHYdKzfKKxi = 1027963215; YbsLHYdKzfKKxi > 0; YbsLHYdKzfKKxi--) {
            continue;
        }
    }

    return GIJpFLMP;
}

int MWlDYQaVxg::djJVngceywfSpd(double aoGkXEWYEXwY, double sqyAgkWtdWsHrqC, bool chuACPUiaLS, int aHmhUdqS)
{
    string QQVXVuVrCvNq = string("DCcrJPHbvHXGlLEtnLthGiQHLUriKcRjTpwIlNOeDrHUnhcNOtXdAcrNkYlnhEiLgvCQDMWCeobKCGYOdgLxZHRwNMltYuUZYGgcJMkQotieHfNCBLWYZZeRchbPvagtGQoIMPgxpxYffmTJR");

    for (int zahTenkgJWOGLQ = 1430301182; zahTenkgJWOGLQ > 0; zahTenkgJWOGLQ--) {
        aHmhUdqS *= aHmhUdqS;
    }

    for (int VPEVFtPIRaVAuUr = 341384047; VPEVFtPIRaVAuUr > 0; VPEVFtPIRaVAuUr--) {
        aHmhUdqS *= aHmhUdqS;
        chuACPUiaLS = ! chuACPUiaLS;
        sqyAgkWtdWsHrqC = sqyAgkWtdWsHrqC;
        chuACPUiaLS = ! chuACPUiaLS;
    }

    for (int SfalZZvspsudMCD = 104129488; SfalZZvspsudMCD > 0; SfalZZvspsudMCD--) {
        continue;
    }

    return aHmhUdqS;
}

int MWlDYQaVxg::FQJFkfkceXtAb(int SIeOuRDaivDRFF)
{
    string YutytkaPoa = string("ofsiFlswtLLRHSHnmPoIulNrePlIeWGDPfjc");
    int ZSHfLhcsTOVg = -1543104023;
    bool bTstMcxeUhsFQ = false;
    double XFsUdmfwARa = -107253.56309537998;
    double HVGHRU = 41610.36229129428;

    for (int CsKJQAmkvBVYEzYh = 1388115664; CsKJQAmkvBVYEzYh > 0; CsKJQAmkvBVYEzYh--) {
        ZSHfLhcsTOVg += ZSHfLhcsTOVg;
    }

    for (int lTunehTuhjC = 2103874652; lTunehTuhjC > 0; lTunehTuhjC--) {
        continue;
    }

    for (int KPoqEPRn = 362974714; KPoqEPRn > 0; KPoqEPRn--) {
        YutytkaPoa += YutytkaPoa;
        SIeOuRDaivDRFF -= ZSHfLhcsTOVg;
        XFsUdmfwARa -= HVGHRU;
        HVGHRU += XFsUdmfwARa;
        ZSHfLhcsTOVg *= ZSHfLhcsTOVg;
    }

    return ZSHfLhcsTOVg;
}

double MWlDYQaVxg::crkImJ(bool jgRcaMweQ, double JiwwGWiGLX, string ulMZmXYqra)
{
    bool rhVLUNibJ = true;
    string depYnUHkOA = string("krhyjsqDXHoqKWkALSRteXvAxUwQpEWdgCXGkhmromtwHqmyPRzMDlvlcROAgUBgDZbGDMkrBLlqfEiXjgHUvxjpuDkuuwPGebAeycAptcDTjGcWYkCAUpnIAbcJijhxtNnrxVOfYnAAfmzCH");
    double emCskRBnAcsvD = 901983.1886965943;
    string cDrpe = string("kdzqPxFQKAKsiFQTraKnEPhbItwjIgcKcCExcqzJpWDzrtOBcYrszDFUVpaMOHpeWEVRMcmmfWdsBswHLGPWZMZkWXBzkMJSiPHIZBpMESMNbKGspugnqwTOsnfQpceMvzGVlcWknCZljOjqOXZJkiziEW");

    for (int kWahU = 1920622793; kWahU > 0; kWahU--) {
        continue;
    }

    if (rhVLUNibJ != true) {
        for (int yRYiytxgDWVWq = 1546535468; yRYiytxgDWVWq > 0; yRYiytxgDWVWq--) {
            cDrpe += ulMZmXYqra;
            cDrpe = ulMZmXYqra;
            emCskRBnAcsvD *= emCskRBnAcsvD;
            JiwwGWiGLX += emCskRBnAcsvD;
            jgRcaMweQ = ! jgRcaMweQ;
            cDrpe = depYnUHkOA;
        }
    }

    if (ulMZmXYqra < string("krhyjsqDXHoqKWkALSRteXvAxUwQpEWdgCXGkhmromtwHqmyPRzMDlvlcROAgUBgDZbGDMkrBLlqfEiXjgHUvxjpuDkuuwPGebAeycAptcDTjGcWYkCAUpnIAbcJijhxtNnrxVOfYnAAfmzCH")) {
        for (int mQAGIFHdmk = 632295328; mQAGIFHdmk > 0; mQAGIFHdmk--) {
            continue;
        }
    }

    for (int qyfeDIhFs = 2078459653; qyfeDIhFs > 0; qyfeDIhFs--) {
        depYnUHkOA = cDrpe;
        JiwwGWiGLX += JiwwGWiGLX;
        emCskRBnAcsvD /= JiwwGWiGLX;
        cDrpe = ulMZmXYqra;
    }

    for (int hCyducUFqFWHei = 854654710; hCyducUFqFWHei > 0; hCyducUFqFWHei--) {
        depYnUHkOA = cDrpe;
        rhVLUNibJ = jgRcaMweQ;
        cDrpe = ulMZmXYqra;
    }

    for (int WJfDbXAkpZ = 36209996; WJfDbXAkpZ > 0; WJfDbXAkpZ--) {
        ulMZmXYqra += ulMZmXYqra;
    }

    return emCskRBnAcsvD;
}

int MWlDYQaVxg::mFLQEJAXezcNM(bool gfbsRWlGEmNeXlIQ)
{
    bool nqjKbwiLyZDLUoKi = false;
    double cNImFgmK = 402345.5450019822;
    string KKgVXS = string("YGiKuovUToVgigMwCpOghFuGrMaqKgPRfkwdtFHOrnpnugJoLxDnWPSfohMGuXrhRDeuTXVtJhePmWIKJGVHhWMbUGWeGsBstrPdZuQpylbiuCiriJy");
    string YIsSJEayCzj = string("ScBobNgqGJvKHMEXVraASblQghlyFJvKpbOugyaOsSUBILTYuJJwYQLlOOZLCWIhsocLVHXNieqBiTKJScYJnpGIxjmkYmqQPsvYFzUuyiYmxknqdOqhQIHWthBddNQxlOQBPUhkhFPsWSeFJDFITuoLIPkAHiPleMDXBRShxv");
    int hmVRMfIzpMsJq = 803532626;
    double GvZwuWEUo = 261442.96309349543;
    string DemEbFXcvJi = string("dlbEeWsWBjcDZGpqXQXvnbbjjpffcUtAJoIIFvYOrSnPUzsGnYOorlFjjKKyAsaQyTvLOfOfwCEgVDCaqOjSpzxIhUVRGNOqjkGNiuSQlKSmlTnpvQqgqCtNsvVQpoknWDEwLoeBvvtcvOMCvsbjTKmWPTCnJjbCWbe");

    for (int jyFgVMIc = 643300101; jyFgVMIc > 0; jyFgVMIc--) {
        continue;
    }

    for (int KsAOQpNRuhXHaWQh = 53945149; KsAOQpNRuhXHaWQh > 0; KsAOQpNRuhXHaWQh--) {
        nqjKbwiLyZDLUoKi = ! gfbsRWlGEmNeXlIQ;
        gfbsRWlGEmNeXlIQ = ! gfbsRWlGEmNeXlIQ;
    }

    if (cNImFgmK == 402345.5450019822) {
        for (int GUbsmlGBannvB = 287215040; GUbsmlGBannvB > 0; GUbsmlGBannvB--) {
            continue;
        }
    }

    if (DemEbFXcvJi != string("ScBobNgqGJvKHMEXVraASblQghlyFJvKpbOugyaOsSUBILTYuJJwYQLlOOZLCWIhsocLVHXNieqBiTKJScYJnpGIxjmkYmqQPsvYFzUuyiYmxknqdOqhQIHWthBddNQxlOQBPUhkhFPsWSeFJDFITuoLIPkAHiPleMDXBRShxv")) {
        for (int bmHdd = 772076474; bmHdd > 0; bmHdd--) {
            continue;
        }
    }

    return hmVRMfIzpMsJq;
}

void MWlDYQaVxg::oWEQsEWrIYb()
{
    double unlVtYGOmaSxwZkH = 651310.9966588947;
    double FXuKHz = 171017.56615206655;
    bool dooKBfYUuKX = true;

    if (unlVtYGOmaSxwZkH > 171017.56615206655) {
        for (int CDfkEuHhtacNNxl = 449426905; CDfkEuHhtacNNxl > 0; CDfkEuHhtacNNxl--) {
            unlVtYGOmaSxwZkH += unlVtYGOmaSxwZkH;
            unlVtYGOmaSxwZkH *= unlVtYGOmaSxwZkH;
            unlVtYGOmaSxwZkH /= FXuKHz;
        }
    }
}

bool MWlDYQaVxg::PaRMDjskSjtLrfB(bool MPpwYitVedx, string dTtULYBiMYwEf, int otIyHlBMZbwDQm, double POTIPkRWvQlvG)
{
    double EFnzUuAKGlKu = 317487.24006115843;

    for (int EPTFpIStBpgQ = 1379448056; EPTFpIStBpgQ > 0; EPTFpIStBpgQ--) {
        EFnzUuAKGlKu = POTIPkRWvQlvG;
    }

    for (int cuzicFbbKKzm = 1111427952; cuzicFbbKKzm > 0; cuzicFbbKKzm--) {
        MPpwYitVedx = ! MPpwYitVedx;
        dTtULYBiMYwEf = dTtULYBiMYwEf;
    }

    for (int PvNVaMQxWuIXpqO = 1367963156; PvNVaMQxWuIXpqO > 0; PvNVaMQxWuIXpqO--) {
        otIyHlBMZbwDQm = otIyHlBMZbwDQm;
        POTIPkRWvQlvG = POTIPkRWvQlvG;
        POTIPkRWvQlvG += POTIPkRWvQlvG;
        MPpwYitVedx = ! MPpwYitVedx;
    }

    return MPpwYitVedx;
}

double MWlDYQaVxg::pywmHgoucL()
{
    bool dlJKzQa = false;
    bool XXYbgm = true;
    int SmOCqmqx = 1401972921;
    int OVNOOOMRFKj = -733048127;
    int JAXCuE = -1938378469;
    bool fwaqlZvWFfzJqKH = false;
    string noqDDVOlDBlJuRUT = string("CjKbtLUrIWGhTfgpSRjVeBXteXFnFU");
    bool ZKgANaYYpwSkGN = true;
    string BOOUivf = string("svsUFPuKIVPJXPwhYRduyCLPkZQEINQHyuglFpBgVMOaFzhOCxteLNrBSvvqDkcXYJNeAhrIQpyCancSBLCpmYQUYLwbAWsVpcQKPeWyolXzyEiFEUXDcJVNVNCiLmGQiCfhdkliJDBBjDpibMNqZQTqfpcZuvHvzDdFJMmdRmMPsLTIrRPcHfoSFmkmKdeZazjsfljUJDhLUksMAzmbdfVsNzkcckAOJtbBSQsLzIAlLG");

    for (int eBkrn = 564646268; eBkrn > 0; eBkrn--) {
        OVNOOOMRFKj *= JAXCuE;
        OVNOOOMRFKj = JAXCuE;
        ZKgANaYYpwSkGN = ! ZKgANaYYpwSkGN;
    }

    if (dlJKzQa == false) {
        for (int kgPhosSOvfBPTza = 794172757; kgPhosSOvfBPTza > 0; kgPhosSOvfBPTza--) {
            fwaqlZvWFfzJqKH = dlJKzQa;
            OVNOOOMRFKj /= OVNOOOMRFKj;
        }
    }

    return 11680.054912243326;
}

void MWlDYQaVxg::IYPfwZlzp(double yLTtMxzTgu)
{
    bool cZuASHIZNcZ = false;
    bool tjTrSzAwfSDoF = false;
    double nWZBcvE = 691331.6865399342;
    string zrZtYv = string("VTbWSrpVqNfyplLGVDnDFkmFdTGzkVCqQqMLVvjLJxvyWXVXUFHV");
    string ZxqvdyKRY = string("DfaXApdbiRmiUCovwhcnAkXbcQJHenxGuQSIhlkePMpvDkCgrYUtlRt");

    for (int TZiYr = 226184238; TZiYr > 0; TZiYr--) {
        continue;
    }

    if (nWZBcvE >= 711757.213283619) {
        for (int UvTGAhST = 790029074; UvTGAhST > 0; UvTGAhST--) {
            tjTrSzAwfSDoF = cZuASHIZNcZ;
        }
    }
}

void MWlDYQaVxg::whDMdputkd(int vpVNOrWG, int EDxBelQae, int ZSRvWeahtGj)
{
    int EDdLQgDLModEjX = 478139100;
    bool iIDtFUbkFwZTEUAV = true;
    double HusWiRqCniEtHG = -913975.8467909524;
    double czlNypMarPEoV = 676217.8172737518;
    bool lpNIktyXAv = false;

    if (vpVNOrWG != 779999116) {
        for (int PspXahtwCkpwqX = 1954352719; PspXahtwCkpwqX > 0; PspXahtwCkpwqX--) {
            continue;
        }
    }

    for (int DGdUTWPkwOl = 1217587186; DGdUTWPkwOl > 0; DGdUTWPkwOl--) {
        HusWiRqCniEtHG *= HusWiRqCniEtHG;
        EDdLQgDLModEjX = vpVNOrWG;
        czlNypMarPEoV *= HusWiRqCniEtHG;
    }
}

int MWlDYQaVxg::QyIAlisavAOsSC(bool bmOIRn, double pNsDNAlQcnRe, bool xLnjQzreS, bool wpysqe)
{
    double netzgPxEyIstyr = -2991.343279633992;
    string XynvKdv = string("gnOrqVPsYvSdOeVohvqdDTWcTBFPcNNLwKWjoIXxIwtFUfTAPwbjpYiIVtmPqbinfiVQOtqTxjBgRpskWsUdMWzVRxdNNWVXCRbRnjUoJUUxoVUPqnucfXEhDLclWTjIxAIPfEcBraZtcemqrxtaarXJMLsOrCIangvsFtCXBHFXvdmCEGVfFKIjujYHMkkAWsrVKIomZgVVGwrzevXLgGWsAMnLGmOFHrKy");
    bool YbFrMkVFybDQYatw = true;
    double izlooKgCrSYB = 355078.5910494329;
    int GLjWGTfpKQ = 838742573;
    double QxiIjGVzyZo = 527003.3832503688;
    bool zedIbxvUKW = true;
    double ZRWLEBtVdaZrpA = 16329.452963648946;
    int QmDnoeDesVMMoOec = -1611565725;

    if (ZRWLEBtVdaZrpA < -668982.5357134185) {
        for (int yKBLakhDsqtDUH = 1831767275; yKBLakhDsqtDUH > 0; yKBLakhDsqtDUH--) {
            pNsDNAlQcnRe *= netzgPxEyIstyr;
        }
    }

    if (wpysqe == true) {
        for (int atvecNyj = 1652472956; atvecNyj > 0; atvecNyj--) {
            xLnjQzreS = zedIbxvUKW;
            bmOIRn = ! zedIbxvUKW;
        }
    }

    for (int BzPeiuUxUCqTPQ = 628468563; BzPeiuUxUCqTPQ > 0; BzPeiuUxUCqTPQ--) {
        continue;
    }

    for (int gHAXFHDl = 1916631066; gHAXFHDl > 0; gHAXFHDl--) {
        xLnjQzreS = xLnjQzreS;
        pNsDNAlQcnRe *= QxiIjGVzyZo;
    }

    return QmDnoeDesVMMoOec;
}

MWlDYQaVxg::MWlDYQaVxg()
{
    this->CLLrbaZ(true, true, true, -334128.27914329385, 534703.4541409372);
    this->oZjlsDiKnPGP(false, string("hneHrretarDiPFd"));
    this->HumNIeqmpqe(-361672.2899017543, -2018259972, -362233.99998827704, false, -1102991962);
    this->xrpRbvfyLOiqoyzb(-124048306, -1652074548);
    this->djJVngceywfSpd(-658568.4671111669, 40248.13912798676, false, 888951333);
    this->FQJFkfkceXtAb(-1134249069);
    this->crkImJ(false, 444586.1871780004, string("IzrEYGFIGenueX"));
    this->mFLQEJAXezcNM(false);
    this->oWEQsEWrIYb();
    this->PaRMDjskSjtLrfB(false, string("pmbsNXlbDTwyzKSxSfvAhmIuWUKfTtofCEEcmunmnqsnwZIAZflvsULrnGCpvXNykuojKKCaCwWXjlZlETmvryGYhyQeyltLupzJQlCzzjuBiCsKsgvcfgDDktxEGfZncwjOvKJRQe"), -1524030200, 206042.15537347057);
    this->pywmHgoucL();
    this->IYPfwZlzp(711757.213283619);
    this->whDMdputkd(-1313650846, 779999116, -1879192157);
    this->QyIAlisavAOsSC(false, -668982.5357134185, true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QLjBaUfJ
{
public:
    bool svkrZ;
    int gaBhjhAN;
    string yxMHqzkumLOpgFM;
    int rLXebiBXLT;
    string mORdRpabGsNgv;
    int gNuRBkywgvMJg;

    QLjBaUfJ();
    bool dMbfoR(string SNnqYzCcgTtXN, int ZVibxc, string CNHFvTwprftx);
    void vfjwYdAoKgy(string wapSieKvJbeqLj, string hYvZBn, double tlaRriI);
    double ILWxOua(string oSUzf, bool lZEgltkNZRJ, string SlWOaBK, bool UXIcWf, double qyftkk);
    double WDacsc();
    string oCSgdVGgzMDQTWC(bool rEOdEYc, string zIQfdAMuiFEEnH, string CVtwUKymf, double LrjETB);
    bool ZMlRdOAsHZw(string ihhgzxVFdGdFAV, double ZFCOtSd, int BSZhFwqxnLjdOjm, double NxDpzdfwT);
protected:
    double wNevZxIpdxYHXqc;
    bool ilvGf;
    double rTzJthkvRkdYmfJF;
    int nriFixqQL;
    int GMcvR;
    double XzaBVg;

    double ABdQj(string RDIZVSV, int alNJgvT, string cqgECRthPCVUyTDP);
    double yQoJqjg(int ZKGuFFQkGiqxo, int QDeqCVmvoQc);
    string SuotzqYlBEJhB(string RRXGvhDGdbSWaY, int AjDZKKJarEYb);
    int JZCbOWXBoPmPs(string daWiXk, string hAryOzJT, bool dFmSkFMyyGTZGLFA, string ozzCHjSkXYJFwTZu);
private:
    bool WfshqwU;
    string OGYdnTiiXlgEJXbH;
    string XAApatkVu;
    int MgPtf;
    string pXotSllotPKHuvLF;

    double NkrHZGXjqIk(string FGtgdcrCF, double YcNaAtguavdIHyZw, string njnNiZAtkyTPT);
    double rExhOAYuUC(double hEGlqFGVdPX, bool ZLPLsChwOvGk, bool ROvnvXdwJS, double aLSPkrFRwZ, double qzILNDlmcU);
    double iptYgpZSbb();
    bool brREkpMEvvABtS(string xSxze, double nDqQJwDbNQuPqS, int jvgHVfkJSNFqlGC, int NyJcL);
    string pqscDH(string MMrMDYV);
    void qbWJGRFl(int KjmodvjQeGMEcx, double DsuakxMeiZbXNS, bool jrJXWZFzE);
    int uMVeGe();
};

bool QLjBaUfJ::dMbfoR(string SNnqYzCcgTtXN, int ZVibxc, string CNHFvTwprftx)
{
    string LoOuLJdHDXyhqti = string("rsShbbDKGxkxFVqCHcYLnyQjEPfKlDhjRoWbGeJklkQvSWnpFtWtdquJPOEoDSsNgrFXpjhVKPFlEFeKVNXXuOZUAHOkktNSkvaomgYdkmntadeYeQbQhGcHDnkSIYoHeGzPuXdMXRdMsyeUHPjcelMwabqGNoedBtvhqXOGhgBkqhbdQjGcXuOMIhPAYrhTroQlCGIBzUBHTjfbgiYtswiElQPvmXZVDWUPpRbsWxpzOJtWNbpnNBqMcVSzI");
    int VGlDuJfRbqcUWlth = 1969799541;
    string QXJoChwFvgG = string("dTZkXBfCkWmuXYb");
    string IRLRaj = string("IUZXYYNTZ");

    for (int mnwjFZzEud = 769944679; mnwjFZzEud > 0; mnwjFZzEud--) {
        CNHFvTwprftx = IRLRaj;
        ZVibxc /= ZVibxc;
        VGlDuJfRbqcUWlth *= VGlDuJfRbqcUWlth;
        QXJoChwFvgG = CNHFvTwprftx;
        SNnqYzCcgTtXN = CNHFvTwprftx;
    }

    if (CNHFvTwprftx != string("dTZkXBfCkWmuXYb")) {
        for (int bpaAgaW = 1472760042; bpaAgaW > 0; bpaAgaW--) {
            CNHFvTwprftx = IRLRaj;
        }
    }

    if (ZVibxc < 1969799541) {
        for (int poaBJ = 348726066; poaBJ > 0; poaBJ--) {
            QXJoChwFvgG = CNHFvTwprftx;
            IRLRaj += SNnqYzCcgTtXN;
            SNnqYzCcgTtXN = CNHFvTwprftx;
            CNHFvTwprftx = SNnqYzCcgTtXN;
            LoOuLJdHDXyhqti = IRLRaj;
        }
    }

    if (CNHFvTwprftx != string("IUZXYYNTZ")) {
        for (int puUVjTQiUPgeA = 1131416859; puUVjTQiUPgeA > 0; puUVjTQiUPgeA--) {
            IRLRaj += IRLRaj;
            SNnqYzCcgTtXN += IRLRaj;
            IRLRaj = CNHFvTwprftx;
        }
    }

    return false;
}

void QLjBaUfJ::vfjwYdAoKgy(string wapSieKvJbeqLj, string hYvZBn, double tlaRriI)
{
    int qJnAsUQvpDsEE = -1023785860;
    bool MIcpUPukFGAzjp = false;

    for (int wKhZdAsCABOpbQeF = 1742373537; wKhZdAsCABOpbQeF > 0; wKhZdAsCABOpbQeF--) {
        qJnAsUQvpDsEE *= qJnAsUQvpDsEE;
    }
}

double QLjBaUfJ::ILWxOua(string oSUzf, bool lZEgltkNZRJ, string SlWOaBK, bool UXIcWf, double qyftkk)
{
    bool pclufNtBSqjSl = false;
    int udFnSIBTlQy = -894503704;

    if (UXIcWf != false) {
        for (int pODsw = 1513633338; pODsw > 0; pODsw--) {
            SlWOaBK = oSUzf;
        }
    }

    for (int ODnCQAQWF = 1790810889; ODnCQAQWF > 0; ODnCQAQWF--) {
        continue;
    }

    if (pclufNtBSqjSl != false) {
        for (int kDOGJT = 213117372; kDOGJT > 0; kDOGJT--) {
            SlWOaBK += oSUzf;
            pclufNtBSqjSl = UXIcWf;
        }
    }

    for (int CpoENaLzopmx = 1243832675; CpoENaLzopmx > 0; CpoENaLzopmx--) {
        lZEgltkNZRJ = UXIcWf;
        SlWOaBK += oSUzf;
    }

    if (oSUzf < string("kcFCqFdHudpGHOarskWcdDHcAUMBzTIxwpgXfDjkWnDZUEDOEfolDvHZbHumaPUuwZqFObixdHbIChxKfVuqpHEXVZwiAbdDrHecvtZLfIYEAbSgZDwJWLIZBrmqYAXTPmJPBTHHjgaBiLhjKpPGqbslOGNntChmfHyPjxvSabgTwuWzkWOvgTUDjgWwboYwqWyLlG")) {
        for (int vIYUCyr = 1827522372; vIYUCyr > 0; vIYUCyr--) {
            udFnSIBTlQy = udFnSIBTlQy;
        }
    }

    if (pclufNtBSqjSl != false) {
        for (int sdtGSnsM = 1774068607; sdtGSnsM > 0; sdtGSnsM--) {
            continue;
        }
    }

    return qyftkk;
}

double QLjBaUfJ::WDacsc()
{
    double CVHcWB = 422272.2220033687;

    if (CVHcWB > 422272.2220033687) {
        for (int mosmhJwQKbtjWf = 787003925; mosmhJwQKbtjWf > 0; mosmhJwQKbtjWf--) {
            CVHcWB *= CVHcWB;
            CVHcWB /= CVHcWB;
            CVHcWB *= CVHcWB;
            CVHcWB += CVHcWB;
            CVHcWB *= CVHcWB;
            CVHcWB = CVHcWB;
            CVHcWB = CVHcWB;
        }
    }

    if (CVHcWB != 422272.2220033687) {
        for (int xvLwSCJL = 191802196; xvLwSCJL > 0; xvLwSCJL--) {
            CVHcWB *= CVHcWB;
            CVHcWB /= CVHcWB;
            CVHcWB /= CVHcWB;
            CVHcWB -= CVHcWB;
            CVHcWB /= CVHcWB;
            CVHcWB = CVHcWB;
            CVHcWB *= CVHcWB;
            CVHcWB = CVHcWB;
        }
    }

    if (CVHcWB >= 422272.2220033687) {
        for (int OZTQbRNuGjs = 559316110; OZTQbRNuGjs > 0; OZTQbRNuGjs--) {
            CVHcWB -= CVHcWB;
            CVHcWB /= CVHcWB;
            CVHcWB *= CVHcWB;
        }
    }

    if (CVHcWB == 422272.2220033687) {
        for (int iInRehZHHKPPACUE = 1871355392; iInRehZHHKPPACUE > 0; iInRehZHHKPPACUE--) {
            CVHcWB = CVHcWB;
            CVHcWB = CVHcWB;
            CVHcWB -= CVHcWB;
            CVHcWB -= CVHcWB;
            CVHcWB /= CVHcWB;
        }
    }

    return CVHcWB;
}

string QLjBaUfJ::oCSgdVGgzMDQTWC(bool rEOdEYc, string zIQfdAMuiFEEnH, string CVtwUKymf, double LrjETB)
{
    double mTFojKACaf = 295893.2623117177;
    string IMSbjSleElgAJSfR = string("DIEtTAuFlJGnKdAwCipIQnkpqaU");
    int trfGwNmgZHlRn = -1946582546;
    int PgMXhc = -1181645417;
    int HarmOIjPL = 710999240;

    for (int NFYCWFeXnqayV = 322874691; NFYCWFeXnqayV > 0; NFYCWFeXnqayV--) {
        HarmOIjPL *= HarmOIjPL;
    }

    if (HarmOIjPL <= -1181645417) {
        for (int tOBTb = 132434844; tOBTb > 0; tOBTb--) {
            continue;
        }
    }

    return IMSbjSleElgAJSfR;
}

bool QLjBaUfJ::ZMlRdOAsHZw(string ihhgzxVFdGdFAV, double ZFCOtSd, int BSZhFwqxnLjdOjm, double NxDpzdfwT)
{
    int PcHuyb = -106831877;
    double gzKUazfRoSbz = -962521.1163957231;
    bool sIWTNsQ = true;
    bool jKnHbSynSVKPG = true;
    int apfMQYjLSviJb = -1237392340;
    bool CfGsUfKCkry = true;
    double BCGnzeHRCRQTfk = -436037.3837316128;
    double eoCIUlApKPISzr = 901680.3963196328;

    for (int UCIdj = 811689201; UCIdj > 0; UCIdj--) {
        continue;
    }

    return CfGsUfKCkry;
}

double QLjBaUfJ::ABdQj(string RDIZVSV, int alNJgvT, string cqgECRthPCVUyTDP)
{
    double veHZVAZUGRHfVXix = 71725.45708332695;
    string puwJNqk = string("FLULfJVzkybdRTpxJohJLAfScnKQW");
    bool cnbFopPQdW = false;
    string OBHJxbsJBQd = string("sUHqAxLGvkjwKAFpqmrQhAMFIltVvESKWEWDtIiggaSPIWjuGSVXsqUdxjTRnJoYsAeoENOlkDUZHiyMdmDZJlSXXmlXfgzpIhrEBAalLVzZhpXsVUPnqyVZCjLlwrWKoBGCJezbQhdsHdM");
    int tWhPANrWns = 8249891;
    double IHLnBpCHnrB = -151382.36323482066;
    double LFUCN = 1014445.155053836;
    double GvIXwFjyHFv = -975115.562381836;
    string tsUfmvxCqQwN = string("ImQMfRunJsWqavDPJggbpjpmVQocMXsKJLpunNWAeOAgcUdeCAjXpHPOMEnfpVMorzeLjKAzrbGRhkhwwcaTFWOebkUtGroYUTbwvJWZRkLOrXqghexBJVKvVKzPQrABgFVe");

    if (veHZVAZUGRHfVXix > 1014445.155053836) {
        for (int QptSvh = 160908666; QptSvh > 0; QptSvh--) {
            OBHJxbsJBQd = puwJNqk;
            cqgECRthPCVUyTDP = RDIZVSV;
            tWhPANrWns -= tWhPANrWns;
            RDIZVSV = puwJNqk;
        }
    }

    return GvIXwFjyHFv;
}

double QLjBaUfJ::yQoJqjg(int ZKGuFFQkGiqxo, int QDeqCVmvoQc)
{
    string tMpHyqjaRnC = string("QzMQrsuWNutbCuEAFSntKlAwIPKgqGjdjORslLhEaNArXFLsQmnvLWzYRrzPYbYdIHfOFRkwJvsyAypIPAbSUqNGNqiiaFHefXFboSIQfTqJKVHxUORuOUpiOr");
    bool YICtygi = true;
    int NhBFhOKqddEE = 1518605557;
    double QINRvDjMv = -988762.7360047362;
    string lJNEN = string("MVJSQpbMPlbMintWXaQvpZoruhjzERsjIhEMmOyheTVxEacsidHKBVcresBkGFYbYxhyQoBDkXIQiWZDkwEvoIWeANwBykjZNXqjTwaYYviGuxlDcrgOVbPSBQXUtOIcqIBikYZtrgQzIBJOKkSRvyRfXPsIemUiHoxMmPsWcUMnlSCtolKmicVPnUVcAkLDWEYZDXdhjcYzaTpDVtXoMKDctdn");
    int KsDGdRqMBvy = -128540091;
    double lSWTtZGZRLzD = -411354.45316230506;
    double nzFzPqru = -234322.12537817986;

    if (KsDGdRqMBvy > 1466563184) {
        for (int oXsvAGDPmtmHN = 1695152274; oXsvAGDPmtmHN > 0; oXsvAGDPmtmHN--) {
            ZKGuFFQkGiqxo = ZKGuFFQkGiqxo;
            lSWTtZGZRLzD += nzFzPqru;
        }
    }

    for (int UhGaWDKtwS = 38294268; UhGaWDKtwS > 0; UhGaWDKtwS--) {
        QDeqCVmvoQc /= NhBFhOKqddEE;
    }

    if (QDeqCVmvoQc < 1518605557) {
        for (int BRbRvwQTZtaPwnZ = 2028323673; BRbRvwQTZtaPwnZ > 0; BRbRvwQTZtaPwnZ--) {
            KsDGdRqMBvy /= KsDGdRqMBvy;
            nzFzPqru += QINRvDjMv;
        }
    }

    for (int cmkHJnkvaDGLN = 1023063488; cmkHJnkvaDGLN > 0; cmkHJnkvaDGLN--) {
        YICtygi = ! YICtygi;
        QDeqCVmvoQc = NhBFhOKqddEE;
        tMpHyqjaRnC += lJNEN;
        ZKGuFFQkGiqxo = QDeqCVmvoQc;
    }

    for (int TfOEzWnQnQsQ = 523760668; TfOEzWnQnQsQ > 0; TfOEzWnQnQsQ--) {
        continue;
    }

    if (QDeqCVmvoQc == 1518605557) {
        for (int PxPcoImIhMe = 332386475; PxPcoImIhMe > 0; PxPcoImIhMe--) {
            tMpHyqjaRnC += tMpHyqjaRnC;
        }
    }

    return nzFzPqru;
}

string QLjBaUfJ::SuotzqYlBEJhB(string RRXGvhDGdbSWaY, int AjDZKKJarEYb)
{
    int qAGWDCtdJ = 500609810;
    int UMYwZxRthWJPW = 1077096744;

    if (AjDZKKJarEYb < 1077096744) {
        for (int MkkZMejePSqCCv = 465776920; MkkZMejePSqCCv > 0; MkkZMejePSqCCv--) {
            AjDZKKJarEYb = AjDZKKJarEYb;
            qAGWDCtdJ -= qAGWDCtdJ;
            qAGWDCtdJ += UMYwZxRthWJPW;
            qAGWDCtdJ = UMYwZxRthWJPW;
        }
    }

    if (AjDZKKJarEYb <= 1241069158) {
        for (int bFLBrBpATAkoNGMG = 1706834169; bFLBrBpATAkoNGMG > 0; bFLBrBpATAkoNGMG--) {
            AjDZKKJarEYb /= AjDZKKJarEYb;
            qAGWDCtdJ *= qAGWDCtdJ;
            qAGWDCtdJ += UMYwZxRthWJPW;
            qAGWDCtdJ += UMYwZxRthWJPW;
            AjDZKKJarEYb -= qAGWDCtdJ;
            UMYwZxRthWJPW = UMYwZxRthWJPW;
        }
    }

    return RRXGvhDGdbSWaY;
}

int QLjBaUfJ::JZCbOWXBoPmPs(string daWiXk, string hAryOzJT, bool dFmSkFMyyGTZGLFA, string ozzCHjSkXYJFwTZu)
{
    bool tpgFMjPB = false;
    double HBsfDPkWCEI = 420956.65964366146;
    double dsxNoaauA = -464879.7445834241;

    for (int ikJWnRWhizTvHPO = 305316720; ikJWnRWhizTvHPO > 0; ikJWnRWhizTvHPO--) {
        continue;
    }

    for (int ICDQKXyplheryfi = 358998580; ICDQKXyplheryfi > 0; ICDQKXyplheryfi--) {
        dFmSkFMyyGTZGLFA = ! tpgFMjPB;
        hAryOzJT += daWiXk;
        HBsfDPkWCEI *= HBsfDPkWCEI;
    }

    for (int bLMIUfX = 1102985788; bLMIUfX > 0; bLMIUfX--) {
        dFmSkFMyyGTZGLFA = dFmSkFMyyGTZGLFA;
    }

    return -1710118444;
}

double QLjBaUfJ::NkrHZGXjqIk(string FGtgdcrCF, double YcNaAtguavdIHyZw, string njnNiZAtkyTPT)
{
    double qlefzyoPUuxUiIw = 314647.5783424991;
    double ffLuaqGoYf = -695757.256701039;
    bool HMjQI = false;

    return ffLuaqGoYf;
}

double QLjBaUfJ::rExhOAYuUC(double hEGlqFGVdPX, bool ZLPLsChwOvGk, bool ROvnvXdwJS, double aLSPkrFRwZ, double qzILNDlmcU)
{
    bool EGVZJtmAEASqU = false;
    bool jaQDvyfBaZ = true;
    double KSUAipmMArblGP = 73161.418412049;
    int nZvqU = 1488047714;
    double nDfOpuVrGy = 974148.6680214193;
    int YIgLiIdNbkqkmzm = 921807685;
    bool axtclx = true;
    string QZBffFFCG = string("qszHkGJPNGRgPxHqviXceTuiHqARGpghEUcfmhLKrEWkNHFutOOzoM");
    string IfsUBhBlUn = string("cJ");

    for (int HdndDHTmku = 1575818633; HdndDHTmku > 0; HdndDHTmku--) {
        nDfOpuVrGy += KSUAipmMArblGP;
        YIgLiIdNbkqkmzm += YIgLiIdNbkqkmzm;
        aLSPkrFRwZ *= aLSPkrFRwZ;
    }

    if (YIgLiIdNbkqkmzm < 921807685) {
        for (int vRRKZsdQXuKp = 1178512709; vRRKZsdQXuKp > 0; vRRKZsdQXuKp--) {
            hEGlqFGVdPX -= aLSPkrFRwZ;
            aLSPkrFRwZ *= KSUAipmMArblGP;
            EGVZJtmAEASqU = ! ROvnvXdwJS;
        }
    }

    for (int AyvQePqxXN = 223525191; AyvQePqxXN > 0; AyvQePqxXN--) {
        continue;
    }

    return nDfOpuVrGy;
}

double QLjBaUfJ::iptYgpZSbb()
{
    bool UqaHXpbvrgA = false;
    double YSoLIdculfM = -506400.2940212768;
    bool BKCYCACkkVTD = true;
    string AfWbgrAoYvUSLJ = string("mliPPETSREWiYkXmNfOkSwidECITTqKxquaAMBbeOiviqPlXnUsLNBXvCexgxudIOZhTdWsGGLumQdYWnAFcZBeGjkoxRQ");
    double xoaaFaeSgXTK = 962769.458482224;
    int VumyBXkl = -1205557379;
    string ekBmozMufObF = string("tbMitQBJMlKQVSrwZRnBETBPjaMtozMkZuNlWMWEMLIBuEyBCULpEmMkufYkWuWuTtCiTgbznXNrzWwyZYtaMHKgTkosdXpRVEdirMi");
    double MkdEDmcppGiSvOXU = -224189.07858906023;
    bool IUeBqv = false;
    bool FaRJB = false;

    if (MkdEDmcppGiSvOXU == 962769.458482224) {
        for (int PUfoZqp = 280947009; PUfoZqp > 0; PUfoZqp--) {
            UqaHXpbvrgA = UqaHXpbvrgA;
        }
    }

    for (int AtyfzCRtSsBSc = 448640178; AtyfzCRtSsBSc > 0; AtyfzCRtSsBSc--) {
        AfWbgrAoYvUSLJ = AfWbgrAoYvUSLJ;
        BKCYCACkkVTD = ! IUeBqv;
    }

    for (int TosTgLAsFyK = 1329385056; TosTgLAsFyK > 0; TosTgLAsFyK--) {
        continue;
    }

    for (int hiLJjRCVzJNJUzN = 1838182471; hiLJjRCVzJNJUzN > 0; hiLJjRCVzJNJUzN--) {
        YSoLIdculfM /= xoaaFaeSgXTK;
        FaRJB = ! BKCYCACkkVTD;
    }

    for (int HhLszQVTmgb = 932697578; HhLszQVTmgb > 0; HhLszQVTmgb--) {
        continue;
    }

    return MkdEDmcppGiSvOXU;
}

bool QLjBaUfJ::brREkpMEvvABtS(string xSxze, double nDqQJwDbNQuPqS, int jvgHVfkJSNFqlGC, int NyJcL)
{
    double qJIotzvpZ = -253831.62962522227;
    bool VPBHSwWOIeOGBpg = false;
    bool gSzCjAI = true;
    bool RymxzyjPy = true;
    bool nTafLCmFhvWcV = false;
    bool zhkOFKUQ = false;
    double FqJMxyo = -252073.63175506835;
    int jKdefVs = -1665527313;
    double PnMkh = -911924.3593956553;
    double ZYnLldZArungOR = 146986.120394366;

    if (gSzCjAI != true) {
        for (int EubVLQecHJ = 1352178125; EubVLQecHJ > 0; EubVLQecHJ--) {
            FqJMxyo *= PnMkh;
            nDqQJwDbNQuPqS *= nDqQJwDbNQuPqS;
        }
    }

    if (nDqQJwDbNQuPqS != -252073.63175506835) {
        for (int jRVDO = 351149770; jRVDO > 0; jRVDO--) {
            continue;
        }
    }

    for (int fChZOeL = 348284620; fChZOeL > 0; fChZOeL--) {
        zhkOFKUQ = nTafLCmFhvWcV;
    }

    if (RymxzyjPy != false) {
        for (int iaiFZCfA = 62976967; iaiFZCfA > 0; iaiFZCfA--) {
            continue;
        }
    }

    return zhkOFKUQ;
}

string QLjBaUfJ::pqscDH(string MMrMDYV)
{
    string GIzOYKgpEMLk = string("wejugbpYgCNCAocqIyaQzqPMYmPNOpiAHVtKJrcrSdUsrLAxnnXnPQazqCJDoaUpzcBYwBKlLQrmnvsusytckURpSwIgfRtoZNyOTfcKtSinJkXaWoXFrSTPaWemHLTZnZeiJfaLEfbbFfazCOyIrmcgTenGJQrqpKGRvCIzyYztoqKhmaYWdavGjPZpjqaaWjlEOwvDIULAlijEeLKIHOnaTsnpLcnvqQ");
    bool gnbXS = true;
    string KJrVt = string("ZNiGmhAAksyslEyHPjuEIKLgUzqRGXjplMiVjwghHRJRIkWzLxPkOoawKHAKYdsNIDmaOnvHeBrInAVNbfDhmpUYspWIZvONZDiIdwSyJHiqexzSjxIBOwukxgpPIUWOyblVLQNANHoaWsOZfniHpkmGMPbbegdeGanWQdKZFt");
    double BoBVrzAJzBZfHB = 727504.5078335748;
    int AtDHNoTPQfgVGb = -1057868309;
    string shQKnk = string("adsSaViQiwVftmSnvwgppBCIAJJVoDDtErulSPNpHouUTiVneIlCiKIUdmNCcD");
    bool MJjdqJva = false;
    double IFxPYYMlKHUdqQd = 342163.47696162673;
    double DfroLbecE = 473149.42411155807;
    bool isFWgGKBoJ = false;

    for (int jPzNMTQpVa = 640102698; jPzNMTQpVa > 0; jPzNMTQpVa--) {
        shQKnk = KJrVt;
        IFxPYYMlKHUdqQd -= IFxPYYMlKHUdqQd;
        MMrMDYV += GIzOYKgpEMLk;
    }

    return shQKnk;
}

void QLjBaUfJ::qbWJGRFl(int KjmodvjQeGMEcx, double DsuakxMeiZbXNS, bool jrJXWZFzE)
{
    int xavPiOPLU = 165149448;
    bool aXwwoOib = true;
    int QduyKas = -2059740295;
    string MjcjS = string("dMhufFPmXDUGQGREPvLVOQhpQRRiyktikjksTjZIRakXtGorRFjzdRdbicnTYSbNagcttJPLonhRaQUNktfEvwfZSYwreECAUNCnpccGYVzzEiHvAgclUmFbdzXovJJuEVGgDzoaxuyubkeCPVTWEYkGDPFEkWKJEVIqtYHdYzuRVNSjANsXVaWBvomPjxBMzNRjsyqMdvhdrHcodApuQZPYkjXQiFoETfrzimzx");

    for (int qWerIwfz = 1392606204; qWerIwfz > 0; qWerIwfz--) {
        KjmodvjQeGMEcx += xavPiOPLU;
        DsuakxMeiZbXNS = DsuakxMeiZbXNS;
    }

    for (int VomUbZd = 1324689263; VomUbZd > 0; VomUbZd--) {
        jrJXWZFzE = jrJXWZFzE;
    }

    if (xavPiOPLU >= 165149448) {
        for (int OYpkWQC = 1524839440; OYpkWQC > 0; OYpkWQC--) {
            continue;
        }
    }
}

int QLjBaUfJ::uMVeGe()
{
    bool hFeVPYyalJveuo = false;
    double WuovrZSEfnCt = -521012.5606644263;
    double mShqEmC = -794327.9282890415;
    bool EAQoMCXwodV = true;
    double YUunPFlLBSNouGB = -544255.533615617;
    bool euNWiT = true;
    double vFaEnkHGjNtBb = -610225.7107354265;
    int aIBDxY = 1882540673;
    bool zjkuZb = true;

    for (int ZRAaiTlg = 1042664673; ZRAaiTlg > 0; ZRAaiTlg--) {
        mShqEmC *= mShqEmC;
        YUunPFlLBSNouGB += WuovrZSEfnCt;
        EAQoMCXwodV = ! zjkuZb;
        hFeVPYyalJveuo = ! zjkuZb;
        mShqEmC /= vFaEnkHGjNtBb;
    }

    return aIBDxY;
}

QLjBaUfJ::QLjBaUfJ()
{
    this->dMbfoR(string("hnqbCOSlovuMgJBIGpcWNiaSOMIjeGeQIIQAALQH"), 186544279, string("LqcRxGoXQKiNFbvMjIeunDRNsqyzYzvchgUbMfaivRhyptKpvryDJvHsKHKptrkbNHUvniSHKzmStrtmztR"));
    this->vfjwYdAoKgy(string("O"), string("EMeGOErdwejNBcwmGgPngkuDXBnkMONHVHvWlApwoyUoWOrSHhgEoqvZbsYXVkoyZlfFQuuWMihiObdapyIjdblMclyejuvTyvTuvNbkldFgtWbmeBDkNxQYmWurXpkpWzXsFZhfPvRbDoznWmoxYflDOxMMSJqXzsDjzGRiKInFxYohkXZtO"), -324822.41386593);
    this->ILWxOua(string("kcFCqFdHudpGHOarskWcdDHcAUMBzTIxwpgXfDjkWnDZUEDOEfolDvHZbHumaPUuwZqFObixdHbIChxKfVuqpHEXVZwiAbdDrHecvtZLfIYEAbSgZDwJWLIZBrmqYAXTPmJPBTHHjgaBiLhjKpPGqbslOGNntChmfHyPjxvSabgTwuWzkWOvgTUDjgWwboYwqWyLlG"), false, string("kyFBqoLZlZnqggoVPThREflYfIryNraLPHcdBSktpgzUBgbLheOlHuGAJNMLCMflCaXwuaRyqCGJhPRSoshpwrMgyyIaakgprmTJAzDdlMQCLOzpSHEferkCMYsnImAmbBHrOABeGp"), false, -653455.9681328529);
    this->WDacsc();
    this->oCSgdVGgzMDQTWC(false, string("zLMyEMaJTPSSuyFzUzKAExZqPVgTLsrhevgjZuoRJBZfLPJFAGePZxUMYSagmhiGvQIbCrPXENyGoGKYiXKydZQShmsTsdXZcpUmPXjZxpaezjtwZLAGHbYmOgquOLivxuOvnFVTTewDzCKyNHOENMVtsXxgxUnakNywNNHuZVLOBLYzLfMwTbEzlyXMN"), string("cnwqse"), -913004.4180194738);
    this->ZMlRdOAsHZw(string("CEXoegtHeHMpVXeJefyUvSMjBPfLcOdkbojGyFlDooQsvivqCtXYpIsmdAUZelgfVHUgSBBhvspiRqeZJrtMIdcJRQXqTlnpDOWBRZUjemqyNwwtqGpCGHznslDMFCXTzcADAYfldfCLyitcieyskYGusegIIeAlIgETETEnHurEeaVhdCnpcRYnfXiCjZpzLoqYxJYJhfupYsCYvtBGJMoBMVyQbRQLszJrJQrVXZjVrShCutLP"), -990914.8804681281, 807282163, -267611.0220986006);
    this->ABdQj(string("cGfSVctsqxbYLaNTzQvaUDaOpkOkoClGBlQpLQpliyLgYxKwBjBYtP"), 1081394091, string("YuVQcMGuMdIwdWXKQzAHfMCuYOkGroTxFvoXDVlUVuiFPyggNMMNPzyPYvmtLvPrYtrQwuZiXlFHcDoHZvTSqNIspEnvXDGkoCzYdwwoKGrbAHSGmqkVfDNFrSBHOskPruwIkTAylqWXPtzSlDFPSpwnXySW"));
    this->yQoJqjg(278969007, 1466563184);
    this->SuotzqYlBEJhB(string("CPgCMsSKnioaxmvlPNYmBpBqGLPUCSAb"), 1241069158);
    this->JZCbOWXBoPmPs(string("QDUbPigADlCrWZBRPXFGVPzNVuJowjXuWzkRIuFyMKYtuCmVXgfyeeuoPucGVcCuycSvhGONwASxCUHQvLfxGtJyGJhsbiWMClJ"), string("dgojKtYoTrBztqhqbQKLMJKYywvMUPWEJkIqysCdbmxGQNsOYLPEMQBkyOOtDeUOYaSydiNmBRgTPtDOInSIYrSCbDPypITMKKnRcbDVvhYDdhKzvNcEQmHRmqEAoChoTnHnKKUswYT"), false, string("UcpwKxmyPQnepxWjYbAEbFpyxYTh"));
    this->NkrHZGXjqIk(string("nIwdoYAqSyaMroHCjnDRFpbLTFDNPORfEoyndCZuAwissPFJFcBNItxgDMgFGvTDMAzcKkdQFZmmxfoLXkvvpaSuHJlvAxEDNTjoSaJyoLutkoIcIVaUCitcJqfkcWkItRdGVJpfTzBZwEWfDVUvTTAXAfDRhGbDaaAqmtezOeyldBEgcYiXJtAigsdUksSojzVfLlbSTFAyrMTzH"), 785687.1126385529, string("MFlYYHKhJweUWSislzHUKfkIoOBEMsOpOftosXkcGKIikOumJvFDSGPmmGnRQRrDJOuCzjyJzIiKweXDwnfzJjOXnSOhaiyPXArUhzixoDPhHdAhdWzDCyropCxkVZzfwOZMXhTPiVYGHUoPXvEctkEaEqOzIbODmbPVRZQYrKxIOVZfCNcxdADoPkwvChVhHdaXVyYLJPrNGqKIzEgBaZLbiiyUgeSAQiSMw"));
    this->rExhOAYuUC(-350979.1903180155, false, true, -443143.77001132205, -461511.8957469804);
    this->iptYgpZSbb();
    this->brREkpMEvvABtS(string("KEidpOxutOOvOyjzgZeFCtyVAknmgEPhhORYVtyppdYAbrscbfXKwKauBWjImOcfAQuAEZOTwSkG"), 878256.6591106686, 1616786717, -121181989);
    this->pqscDH(string("ORzzfOUopfmMpXMqYRLCQCVVawDrnhIL"));
    this->qbWJGRFl(918314002, -680195.0847415933, true);
    this->uMVeGe();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PJuSCCqZ
{
public:
    bool CcTyzSM;
    int xSHZpX;
    double SZTRQQyZ;
    string wNVzqMqP;
    double oIdCKQwvlzqeai;
    double AKtFOmO;

    PJuSCCqZ();
    string scnAnMwEgdSzLN(string nePOpufOzRrJycUc, int vzUVJlPDXfqk, string QUMjJZhFoJnSAL);
    void STHVH();
    bool oCJMOJdkt(double MAShdHbfw, bool NuMMaxR, int gxNpbnQWF, int TuyBiKIOIz);
    int wGhYF();
    int NTZeIFtF(int DOnWhKEf, string QZROqGBOEd, bool DAsLJwi, int neuYuaNJ, int GInSepTBWKcDDI);
    string XTcRlSjNwPyJw();
    int inYHKMdGInCm(int qMLgIJkfN);
    double DVaZHkTiwbpvEDa(double GwdbXMjL, bool YliwEgh, int fGneilElqLSo, int paVpWzrc);
protected:
    string ClxDJKQ;
    double PFZVXyBxQ;

    bool EqWCWfouJ();
    int ZofUCagLUqE(string tllDGGTD, int BYmhWBTCJYNh);
    int pPZDenk();
    bool PxzeRDHYtEuqYdgC(bool TlroapFwPlisk, double wFdst, string kogxsyJio, int pqpNTGFBmhYDh, bool zmzNxjfql);
    void BMTOTOEJn();
private:
    string pkfUZoqvlrBY;

    bool StUMd(bool RanGGaJqzyecazX, bool tXQYDJpCiHNvifK, double KheUXKqYcScsGnB);
    double jRBLrFtjkKOUi(bool lawNgOItPYEzZcAU, bool QLKkBZpE, int CLZtLsNeFK, double CXVnDpw, int rFMFahFAcn);
    double LfLAcId(double aoBGmHnDnGFLI, bool spsqULdKGaOSmTg);
    void lftyuENH(double knGvSGkvwXkI, bool TLqnuRE);
    bool DSaWWiDjfADgA();
    void dUFzAGbEYesF();
};

string PJuSCCqZ::scnAnMwEgdSzLN(string nePOpufOzRrJycUc, int vzUVJlPDXfqk, string QUMjJZhFoJnSAL)
{
    string sQDqnqYF = string("LvPSpuNfTKLWLkXPPXXbsKTmraHjPktAmlajZWmvBIxrNOgOUwDHacRyXGLvQcRoXntWePfbeqqVuDqMhWtemKZmWyZYaOZIZZgZtepjuHKpHnSVEaKrUxRbayzUeoCrYSmBOhZFWBRDrljplFYgfDkCwZwqccrPMCwTZCILxSoOZHcThFwjNlKXVtHWXRmMJQSYRtbBMsOaEfvnqhoXZQKHDALPPcr");
    bool htazhdDBcYBdgBn = true;
    bool TqvBSe = true;
    bool heJsbgNsMdwOp = false;
    int eolxlm = 938957062;
    int TWBDwYJSHJn = 1105333815;

    if (nePOpufOzRrJycUc >= string("LvPSpuNfTKLWLkXPPXXbsKTmraHjPktAmlajZWmvBIxrNOgOUwDHacRyXGLvQcRoXntWePfbeqqVuDqMhWtemKZmWyZYaOZIZZgZtepjuHKpHnSVEaKrUxRbayzUeoCrYSmBOhZFWBRDrljplFYgfDkCwZwqccrPMCwTZCILxSoOZHcThFwjNlKXVtHWXRmMJQSYRtbBMsOaEfvnqhoXZQKHDALPPcr")) {
        for (int wAmbLs = 856287485; wAmbLs > 0; wAmbLs--) {
            heJsbgNsMdwOp = ! TqvBSe;
            sQDqnqYF += sQDqnqYF;
            htazhdDBcYBdgBn = TqvBSe;
            eolxlm -= eolxlm;
        }
    }

    for (int nHCEFzsxkXy = 1853918874; nHCEFzsxkXy > 0; nHCEFzsxkXy--) {
        heJsbgNsMdwOp = heJsbgNsMdwOp;
    }

    return sQDqnqYF;
}

void PJuSCCqZ::STHVH()
{
    double qUDnbHYK = -661087.7436344611;
    bool egtsDTNCBEeOS = false;
    string gqACXXqj = string("rnEMyWjfIodisXeBYZeaAJpNXZldQkeIBRTchVEmAsoNEgOXKVOFOGBleAsKjfKUNIQKmafCLeCsmJxGFLXWdwxveAFKjgcSySrpKoXtCvmSUKwleuxpwDnulMSgxlXiCNVXqxipeOkXilVpfdUKPpqNpOgeINbklusSWWpjkAhiqjfuTWfVNzCoXpXUAGmfKtAryUfPWYlYPFaAbHTlWRTbYISUKFjjEtfiqNwsCJrcTGT");
    int IaLEOznrtz = 31828344;

    for (int IdlixwxLnWzzhYZW = 1069741008; IdlixwxLnWzzhYZW > 0; IdlixwxLnWzzhYZW--) {
        qUDnbHYK -= qUDnbHYK;
        IaLEOznrtz -= IaLEOznrtz;
    }

    for (int HRbKFCq = 1437797201; HRbKFCq > 0; HRbKFCq--) {
        egtsDTNCBEeOS = ! egtsDTNCBEeOS;
    }

    for (int xBEau = 1304663009; xBEau > 0; xBEau--) {
        IaLEOznrtz /= IaLEOznrtz;
        gqACXXqj += gqACXXqj;
    }
}

bool PJuSCCqZ::oCJMOJdkt(double MAShdHbfw, bool NuMMaxR, int gxNpbnQWF, int TuyBiKIOIz)
{
    string tUBAWPQgSan = string("JyXmmhchdEcTQnrfzdHsduLTNoTKRdcmlylRrGDrpnSHopJkRFmVJKsmrSbBaONTMWLdpadqhezInlFIhIwVxXmmzpMJQhhVPiKmdEPOJfLQBboZwaoLENRZSFIhALLquYgdotXQohsedeIeyHsgRtjPJocwDjHbAtRAw");
    double WgWjbupE = 940196.5173178616;
    int ytCyJlLUSK = 1025341343;
    double NwzPFcvNlQcygsdO = 716427.4764673013;
    int GwJMjuKS = -366825239;
    string TDLDhCrrQFNlS = string("aIfIbDCapSTtVOwTpjMJYMbvZKwSZOUfESMLuAYkegiFKv");

    if (NwzPFcvNlQcygsdO > 940196.5173178616) {
        for (int NAnCB = 706272187; NAnCB > 0; NAnCB--) {
            continue;
        }
    }

    for (int bvcqHiLqBvU = 83583877; bvcqHiLqBvU > 0; bvcqHiLqBvU--) {
        TuyBiKIOIz *= ytCyJlLUSK;
        TuyBiKIOIz -= GwJMjuKS;
    }

    for (int BiwdAdbL = 569407495; BiwdAdbL > 0; BiwdAdbL--) {
        MAShdHbfw *= WgWjbupE;
    }

    return NuMMaxR;
}

int PJuSCCqZ::wGhYF()
{
    string TiSdQdawI = string("KvdUcgzTwwkETvpxXVjnaevdFdCSNvGETthk");

    return -1734748968;
}

int PJuSCCqZ::NTZeIFtF(int DOnWhKEf, string QZROqGBOEd, bool DAsLJwi, int neuYuaNJ, int GInSepTBWKcDDI)
{
    int NkSpNLOIyjHhWj = 1511549853;
    string PFeWKcfWhFjjMay = string("stijkAPVDRmQmCGICiEqwOeNnEVkHsJffIBTxDhYWygwcFOHZyAzcAmtJaAQOFPfGFfJtEEvjxEmLOhOYPAInMdpnRKohOIUDglCrdDBqfshozrzxZxpzfAxVssCmsoeQmuYJbcxNvLBunZDknSVJqFozsIYcXGOUlNYtTkoHuogLFfdlBTQhODG");
    bool PwVyUxluPqKYp = false;
    string bdXPOGeQNsnKl = string("KmPpQduPQRfeSdUDxRNcySKACUjHrsIHMcqeZphmKWwmCBRxMJAkmAKEBeSrr");
    bool rekbjEQjxrpIle = false;
    double BXzxpFQZVSArl = -426834.9806948648;
    int UDpIaPdmxVIO = 1302996398;
    bool KIeLAwpIiLupUHht = false;

    for (int qyVnEzHGqAJKwX = 1999056244; qyVnEzHGqAJKwX > 0; qyVnEzHGqAJKwX--) {
        continue;
    }

    return UDpIaPdmxVIO;
}

string PJuSCCqZ::XTcRlSjNwPyJw()
{
    bool OoOshZrlhoCPM = false;
    int IiXjC = 1293673003;
    string xuZZjXBcBCaUTDt = string("FHKNJFZNwABCRtscFIlUHvndRrkhJERXlVnBilMVxrmjEmDZhxRSFGuhaQKgKPsHvDhHsndCfiHWrtybMpXXvApvGuMhQXMVKDPWBHmgyUuqBkcPuLXCMvyUGSEnJegGfbaYqA");
    int kKmnhog = 2124865014;
    string lAvkFrnDVjA = string("HMcoPIxGQquhsLNalUiElSKxcXeRcaEdBYYOSWxwSmSuSpwseKkeVDgJtBqexXDGXYbsFXfFPEKoYuAekShXFuqukAhpBfr");
    double cGyNRdXzrFI = 577616.8303723298;
    bool DuBIUJKOqyJVxm = true;
    bool UqrxMAwYJ = false;
    double hPVvDWmq = 760725.1227659858;
    string UXqbFbOigwICf = string("BMRFvQOITxuGLPfuxIkLqtCPhxPEBtkSQbkheDjicmtYMJMbXZZIKAuYAm");

    for (int LksBCQ = 1558463403; LksBCQ > 0; LksBCQ--) {
        xuZZjXBcBCaUTDt += xuZZjXBcBCaUTDt;
    }

    for (int dEkoR = 862750213; dEkoR > 0; dEkoR--) {
        lAvkFrnDVjA += lAvkFrnDVjA;
        IiXjC -= kKmnhog;
    }

    if (DuBIUJKOqyJVxm == true) {
        for (int WnOTYJiUZfuCUZ = 1407202565; WnOTYJiUZfuCUZ > 0; WnOTYJiUZfuCUZ--) {
            cGyNRdXzrFI *= hPVvDWmq;
            xuZZjXBcBCaUTDt = lAvkFrnDVjA;
        }
    }

    return UXqbFbOigwICf;
}

int PJuSCCqZ::inYHKMdGInCm(int qMLgIJkfN)
{
    int eNluyfzplG = -1003555324;
    double iDzdrHvekmHuT = 898257.1763600757;
    int dnZoJLsyADbEDOBH = 316596332;
    double IOXmHRhqP = -655918.6286791365;
    double qhsUAHbAGORKoEMB = -895865.3573818356;
    double LNxBkrl = -794976.5668311995;
    bool MXmwq = true;
    double koDOoVe = -691526.2784970496;
    bool qBMQf = true;
    bool JgkoGvqyJrQPdwO = true;

    for (int lQKzdzXpVe = 1705704736; lQKzdzXpVe > 0; lQKzdzXpVe--) {
        IOXmHRhqP /= iDzdrHvekmHuT;
    }

    return dnZoJLsyADbEDOBH;
}

double PJuSCCqZ::DVaZHkTiwbpvEDa(double GwdbXMjL, bool YliwEgh, int fGneilElqLSo, int paVpWzrc)
{
    bool aikTxApvAqORQBcQ = true;
    double YPwkXoTiZHm = 382611.69545440824;
    double ngRANMgfEx = 167538.9834491168;
    double LNOTI = -230857.61991086483;
    string aNiRxzUkOKBXfmPC = string("ScnZhUTlTbOrNfoVapwsKYlWclcNfBRjfLhqBUJamxdKbxlvwoeNjAgMxbbdYjHkLkqqFJNqRKkGauRFLonwLGwehSgbJabvJBoewBaBiPizyYwsOp");
    bool wgmKYGnGUJd = true;

    for (int aKQztGl = 577376066; aKQztGl > 0; aKQztGl--) {
        continue;
    }

    if (YPwkXoTiZHm < 167538.9834491168) {
        for (int dLWtpiGWGJeArYz = 1467172199; dLWtpiGWGJeArYz > 0; dLWtpiGWGJeArYz--) {
            continue;
        }
    }

    return LNOTI;
}

bool PJuSCCqZ::EqWCWfouJ()
{
    bool EgvVFkDnryyl = false;
    int EWyhqIrBlVXQG = -1569940928;
    string VkKKFgjimlh = string("onRgZRwDlYMqOVSNfxGDCv");
    string GYXcfLpnHsqDXTw = string("pmQoykAskDJufjeqDHSuhSAlyxRsteSFAchEYqonMLMeEeNGWlJhrmREAKLjOewZgypZeuJbjlkJkOUqhTEHMaiYdEeXfeQzIgQuklxEIsILGVsEuayToVZPfJbyhFhScCVbBkegSdhwuXqdeisycphZdhQQAuLedVJxVhJMQLWSykeooRVRqOZsLhQGGfTAtGkDenTWZcsBEoWivWSWsBILYtVVkmFDYAdRHbNRfvFrc");
    double XPdsAd = -360997.38443445996;
    int WMHHybFRkrfS = -241326439;
    bool lrjRAGHiadLRv = false;
    string orbsblaBVB = string("EpacDwCIfsrMKaFleeXWgxJWDBjNmV");
    int bVtmzPFxFCvzTD = -1350769834;

    if (orbsblaBVB < string("EpacDwCIfsrMKaFleeXWgxJWDBjNmV")) {
        for (int nJcnxNDYoc = 317180877; nJcnxNDYoc > 0; nJcnxNDYoc--) {
            continue;
        }
    }

    for (int rwOyjayXalKY = 688153759; rwOyjayXalKY > 0; rwOyjayXalKY--) {
        lrjRAGHiadLRv = EgvVFkDnryyl;
    }

    return lrjRAGHiadLRv;
}

int PJuSCCqZ::ZofUCagLUqE(string tllDGGTD, int BYmhWBTCJYNh)
{
    string oDuKZqkF = string("NwPQHsuIOwtObKVPJXkkQFMHyPqlZqCwiRiYiQrOqSEpAguAvzwJrbEwpHlMmZPAGWRzMhMwEirZKekNxaAGqyTcorDIBPLvYyBRRCibcttgABXwgFPSYIwAJxCEyXbOknEYwcgaHljLzRuNtMmXfWAYFuAyPBxVwGTpZXMZGACyZumxdYZwEcyjAYWYnQgBnwxveTohxTsAUvcQkNaiuBgwwytxqDczmktI");
    bool qzZVKDPfsmsXXyv = false;
    string HSpsZdD = string("raJKvExHEPygcTfWbyjQdweiULqkOMIXuxjk");
    string BWKDyi = string("QNM");

    for (int MsAzFNVOdoQJm = 1906647021; MsAzFNVOdoQJm > 0; MsAzFNVOdoQJm--) {
        continue;
    }

    if (oDuKZqkF <= string("NwPQHsuIOwtObKVPJXkkQFMHyPqlZqCwiRiYiQrOqSEpAguAvzwJrbEwpHlMmZPAGWRzMhMwEirZKekNxaAGqyTcorDIBPLvYyBRRCibcttgABXwgFPSYIwAJxCEyXbOknEYwcgaHljLzRuNtMmXfWAYFuAyPBxVwGTpZXMZGACyZumxdYZwEcyjAYWYnQgBnwxveTohxTsAUvcQkNaiuBgwwytxqDczmktI")) {
        for (int qBjQqkTFgE = 2502449; qBjQqkTFgE > 0; qBjQqkTFgE--) {
            BYmhWBTCJYNh /= BYmhWBTCJYNh;
            oDuKZqkF += HSpsZdD;
            tllDGGTD += tllDGGTD;
        }
    }

    if (tllDGGTD >= string("raJKvExHEPygcTfWbyjQdweiULqkOMIXuxjk")) {
        for (int tFMscxeCIFWWTvdA = 1327814992; tFMscxeCIFWWTvdA > 0; tFMscxeCIFWWTvdA--) {
            tllDGGTD += BWKDyi;
            HSpsZdD += oDuKZqkF;
        }
    }

    for (int YYWjVumnMwK = 1430347190; YYWjVumnMwK > 0; YYWjVumnMwK--) {
        HSpsZdD += BWKDyi;
        BWKDyi += tllDGGTD;
        tllDGGTD = BWKDyi;
        BWKDyi += tllDGGTD;
    }

    if (oDuKZqkF < string("NwPQHsuIOwtObKVPJXkkQFMHyPqlZqCwiRiYiQrOqSEpAguAvzwJrbEwpHlMmZPAGWRzMhMwEirZKekNxaAGqyTcorDIBPLvYyBRRCibcttgABXwgFPSYIwAJxCEyXbOknEYwcgaHljLzRuNtMmXfWAYFuAyPBxVwGTpZXMZGACyZumxdYZwEcyjAYWYnQgBnwxveTohxTsAUvcQkNaiuBgwwytxqDczmktI")) {
        for (int FFMerSzAO = 966405822; FFMerSzAO > 0; FFMerSzAO--) {
            oDuKZqkF = oDuKZqkF;
        }
    }

    return BYmhWBTCJYNh;
}

int PJuSCCqZ::pPZDenk()
{
    string SrAclgmsQx = string("onAOAsoAVzjBdjHBKIYZLniWDXNqRJMRmuTnuTAcVaddVpdgcnfGzMqcRoTJhbdVTtBHzMCDKYZvDoFT");
    double FiXrrXxmp = -781686.1053363582;
    double hSDDJFtWVXP = 410381.4716479285;
    string PVFmhgn = string("xXdbactVKpdhQvgvtRsXdnGnPfnVjKhdCvNKXgqwhJCvDfBYWUzCpcLQKerZSjdVPLufT");
    double CWaGECmoQjj = -585805.0765499817;
    double uKRPVwrncTHiXN = 169488.13008565753;

    if (SrAclgmsQx <= string("xXdbactVKpdhQvgvtRsXdnGnPfnVjKhdCvNKXgqwhJCvDfBYWUzCpcLQKerZSjdVPLufT")) {
        for (int iwYqgUNhFNbjcO = 309712415; iwYqgUNhFNbjcO > 0; iwYqgUNhFNbjcO--) {
            CWaGECmoQjj -= hSDDJFtWVXP;
            SrAclgmsQx = PVFmhgn;
            hSDDJFtWVXP += CWaGECmoQjj;
            CWaGECmoQjj /= FiXrrXxmp;
            PVFmhgn += PVFmhgn;
        }
    }

    if (PVFmhgn < string("xXdbactVKpdhQvgvtRsXdnGnPfnVjKhdCvNKXgqwhJCvDfBYWUzCpcLQKerZSjdVPLufT")) {
        for (int KUBvU = 644023805; KUBvU > 0; KUBvU--) {
            hSDDJFtWVXP += uKRPVwrncTHiXN;
        }
    }

    if (PVFmhgn < string("xXdbactVKpdhQvgvtRsXdnGnPfnVjKhdCvNKXgqwhJCvDfBYWUzCpcLQKerZSjdVPLufT")) {
        for (int qEdYLOfO = 1475042966; qEdYLOfO > 0; qEdYLOfO--) {
            hSDDJFtWVXP *= FiXrrXxmp;
        }
    }

    for (int jlUzn = 646640986; jlUzn > 0; jlUzn--) {
        uKRPVwrncTHiXN -= uKRPVwrncTHiXN;
        CWaGECmoQjj += FiXrrXxmp;
    }

    if (SrAclgmsQx != string("onAOAsoAVzjBdjHBKIYZLniWDXNqRJMRmuTnuTAcVaddVpdgcnfGzMqcRoTJhbdVTtBHzMCDKYZvDoFT")) {
        for (int rhsIxqPRsySmEl = 118730538; rhsIxqPRsySmEl > 0; rhsIxqPRsySmEl--) {
            continue;
        }
    }

    if (FiXrrXxmp >= 169488.13008565753) {
        for (int LuLzbvzolEF = 121999607; LuLzbvzolEF > 0; LuLzbvzolEF--) {
            FiXrrXxmp = hSDDJFtWVXP;
            hSDDJFtWVXP -= FiXrrXxmp;
            hSDDJFtWVXP /= hSDDJFtWVXP;
            PVFmhgn += SrAclgmsQx;
            CWaGECmoQjj *= FiXrrXxmp;
        }
    }

    return -1277876805;
}

bool PJuSCCqZ::PxzeRDHYtEuqYdgC(bool TlroapFwPlisk, double wFdst, string kogxsyJio, int pqpNTGFBmhYDh, bool zmzNxjfql)
{
    string DMUQyMFpTUGJhoE = string("ovaIyrIxsCPElfdEuXPYWgrbVyYCsygbEkTYCJvVVWiBfYcVpcGIZUuXiFmoCknkvCYMPALDUZcluuctrxpfOefULGCNUBuMDYobOmChYEJzWGavyYrPgIfGKgpwnvLHcqRyattSwzxYoZTUe");
    string cuooUzUDNylJg = string("dcAVFPePxsoyDZEmmYqFlSWmDPqnmDDcZhGiXNcNqmSbATXsEjIYXhEwuXcAosLNa");
    string pmTqaYNhBkdKUu = string("qbKOlivaZgMMDfZwutgompBVYJnAABopZWqcAdmedmfpvrxVUfGeUlIrpFwWJkiNRyOGACchpLGAdeJJOxQNlq");
    double vWwaRzYhxIXnyOI = -251033.10878893203;
    bool suFkxX = true;

    for (int ZznKarFUQLJmTrq = 1416191733; ZznKarFUQLJmTrq > 0; ZznKarFUQLJmTrq--) {
        pmTqaYNhBkdKUu += pmTqaYNhBkdKUu;
    }

    return suFkxX;
}

void PJuSCCqZ::BMTOTOEJn()
{
    int nFvVxmhBWqL = -508941214;
    string ZdCzGWr = string("RGjlppysWldMxJLumXwQFkbgmzVLdySlmycIVbNgXGkJgOmbSvLyxWSkscqyFnLHvsphGKNmJAcwXTQEssqrDmyKgTzAnHQZfUEncpcOdqGumZSnyLQPATOxIQaskkDSETJzIgVwppgzesqDwoljrHmsStLPkIDvWOKapRydPsBAOhV");
    double TMEcPB = 1029101.2708092838;
    bool wRoXECDdw = true;
    int SxpAxNulYtq = -177507521;
    bool owMzffXyDD = false;
    int xoyAetJXVB = 1882606584;
    double SAkBDLILI = 975561.680938767;
    int PmCHyTO = 1734512024;

    for (int mUwvZzKkKFZZEhBD = 72803762; mUwvZzKkKFZZEhBD > 0; mUwvZzKkKFZZEhBD--) {
        owMzffXyDD = owMzffXyDD;
    }

    if (nFvVxmhBWqL > 1734512024) {
        for (int jrTIO = 575882383; jrTIO > 0; jrTIO--) {
            PmCHyTO *= PmCHyTO;
        }
    }

    for (int JrSZguxVOX = 1389460573; JrSZguxVOX > 0; JrSZguxVOX--) {
        PmCHyTO = nFvVxmhBWqL;
        nFvVxmhBWqL = SxpAxNulYtq;
        ZdCzGWr = ZdCzGWr;
        SxpAxNulYtq /= PmCHyTO;
    }
}

bool PJuSCCqZ::StUMd(bool RanGGaJqzyecazX, bool tXQYDJpCiHNvifK, double KheUXKqYcScsGnB)
{
    bool azVWWUmuVfMFS = true;
    int oLtzP = -2002275396;
    string RssKtHkOPZ = string("JpzITrWPUeTLIHxMmdEWCEgmLSOQZYyWfXfEsziGJqdtrhNmqDpklXoaZyHwAyRLEIBKSbvnFhZYm");
    int JTpYFEwjJjOUYmh = -1015797801;
    string aJNoEKM = string("gmIVYVckFgryobWLPrGycuFuWrcTGOdQSjFgwtWnaLSpjCpTaujfCQdvaDRYvvzhwiqWXbRzctCXkavQYgRKNmZUFpkziabsuWFcWkaXNKHIOUwhFqfKIKYkoOXXYZGXIOYJVMUExKEFFdMXDQpuioWdew");
    double OEsaSYw = 13826.612096341543;
    bool JQeXiMwmQ = false;
    int EgyzSALfUTOvsdxR = 29590735;
    double SnxTWH = -272591.48521281296;

    for (int XlEbVjpWHC = 1000517699; XlEbVjpWHC > 0; XlEbVjpWHC--) {
        continue;
    }

    for (int MXBUeYoqyKdnmbgr = 758560084; MXBUeYoqyKdnmbgr > 0; MXBUeYoqyKdnmbgr--) {
        continue;
    }

    if (KheUXKqYcScsGnB == -272591.48521281296) {
        for (int kekwFqEJxqYjPIc = 8007068; kekwFqEJxqYjPIc > 0; kekwFqEJxqYjPIc--) {
            continue;
        }
    }

    for (int hjmXw = 309371910; hjmXw > 0; hjmXw--) {
        azVWWUmuVfMFS = azVWWUmuVfMFS;
        JQeXiMwmQ = ! JQeXiMwmQ;
    }

    for (int LKgJVnAMVLqKGVS = 774580708; LKgJVnAMVLqKGVS > 0; LKgJVnAMVLqKGVS--) {
        tXQYDJpCiHNvifK = tXQYDJpCiHNvifK;
    }

    return JQeXiMwmQ;
}

double PJuSCCqZ::jRBLrFtjkKOUi(bool lawNgOItPYEzZcAU, bool QLKkBZpE, int CLZtLsNeFK, double CXVnDpw, int rFMFahFAcn)
{
    string qbmUGr = string("CGMSOELLlNnlGQPMbnxRVBDPtzQQrBQlRevpQCREUUQLzXmUvaqFeAoQPekrSRkTawVBreeoZMuwIABLIsxIiAjwFnVIUtQuUhwWVIKRUsAwNieYWKQsyD");
    bool CABeITb = false;
    bool RzamDoOkrsUel = false;
    bool efWexE = false;
    double arsycdtsSh = -470756.5953783158;
    string LzjkdcnAvwden = string("DFoXvlAiABmQojyRQdxvAMFhCrjUwSwtLJWowRPBEHBUnoqFikRaTJNbwASAczOVMMzZQszYxVKjwzdAFPdrHnyQEzRuspyX");

    for (int ngSmUItyVF = 191685875; ngSmUItyVF > 0; ngSmUItyVF--) {
        CLZtLsNeFK += rFMFahFAcn;
        qbmUGr += LzjkdcnAvwden;
        efWexE = ! RzamDoOkrsUel;
    }

    if (QLKkBZpE == false) {
        for (int vdByFFcDHYQY = 1369586839; vdByFFcDHYQY > 0; vdByFFcDHYQY--) {
            RzamDoOkrsUel = RzamDoOkrsUel;
        }
    }

    if (QLKkBZpE != false) {
        for (int vJgoYTcnzIfNf = 1614092384; vJgoYTcnzIfNf > 0; vJgoYTcnzIfNf--) {
            arsycdtsSh *= CXVnDpw;
            rFMFahFAcn /= rFMFahFAcn;
            RzamDoOkrsUel = ! QLKkBZpE;
        }
    }

    for (int LQLDApslI = 851180262; LQLDApslI > 0; LQLDApslI--) {
        arsycdtsSh /= arsycdtsSh;
    }

    for (int FtPYwYJzljbI = 1766424128; FtPYwYJzljbI > 0; FtPYwYJzljbI--) {
        efWexE = ! QLKkBZpE;
        lawNgOItPYEzZcAU = ! QLKkBZpE;
        RzamDoOkrsUel = ! efWexE;
        lawNgOItPYEzZcAU = ! CABeITb;
    }

    return arsycdtsSh;
}

double PJuSCCqZ::LfLAcId(double aoBGmHnDnGFLI, bool spsqULdKGaOSmTg)
{
    string ZVWrX = string("yLvqnpOCCYPEfjvbySyQwbUEPmjKZlRnsNZgRiyWLUcmCOiCrRkJCJGZXVgDnMurxNyUTpCBIsjhtLudHhTSBccMUbQBrLtZNAPEDvtxNqUqSukHSpgteBCgXDmNwPGboAweLhwIolNQXupLcqAnjpqvZGtQPhBpTbQXJDnsUwCbyhq");
    int epzzXrDbtLY = 904837953;

    for (int KWXbBpLsDIiW = 1215927907; KWXbBpLsDIiW > 0; KWXbBpLsDIiW--) {
        ZVWrX += ZVWrX;
    }

    return aoBGmHnDnGFLI;
}

void PJuSCCqZ::lftyuENH(double knGvSGkvwXkI, bool TLqnuRE)
{
    string VAJXAg = string("ilVUARBDAwLulSdXIxTlOOGHOmPhCidGDgFgQzraMwlWGaIdOGsDDCTZtvEvabHrHLyUCXZzJUPaoaRICdhmBaVxllxINWwcuEQwalkfjGDfCaHyXRMLYcOzhkRyAYMOTRtb");
}

bool PJuSCCqZ::DSaWWiDjfADgA()
{
    int LKXDBtvQcv = -990679103;
    double buBEwBGgIhp = -310576.89247662935;

    if (LKXDBtvQcv >= -990679103) {
        for (int HBQeycIGCXnH = 1982958890; HBQeycIGCXnH > 0; HBQeycIGCXnH--) {
            LKXDBtvQcv -= LKXDBtvQcv;
            LKXDBtvQcv -= LKXDBtvQcv;
        }
    }

    for (int ujdOlyyEDjjXBRQ = 1599156231; ujdOlyyEDjjXBRQ > 0; ujdOlyyEDjjXBRQ--) {
        continue;
    }

    return false;
}

void PJuSCCqZ::dUFzAGbEYesF()
{
    double OfMMrLUKYadF = -600924.8639360891;
    string caqgazTZkb = string("HOMrLEILMkRphhyrjcdVqzKwXYFbDdaUkKMmXYkqVImuhTowAWXKwfYGiCwbSp");
    double BCzGcjnLsxXzsjfA = -639135.4274762876;
    string tUrewC = string("AoctWCoJwjYADhSWQNnwyhwcpLYoeoGarYqyvAygQnIxfzIjomndzRCBUJpLbXgmIR");
    string SgPAjfXwFRvs = string("pDUItmuklDAjvaTVcVOuJuwrfLxOxKKgVGzWPLfooXIbIDWcQinwKUqscjhkFxbWlSIDnMbplktfxGDUjNELDTkjqnDbYePMByKpVLnUArGOHHtPmFTtWfzaAtSMriWcXZcKuUiTPMsTdKkgnNQPnzebWFGkJAATZzFWgQGXpDVPrjftaSbGVpOGbupZXsSmIAuziioFvEbtfcGIbSJVfONCfzibUP");
    bool rAmwfLhEMwonJZ = true;

    if (OfMMrLUKYadF >= -600924.8639360891) {
        for (int TkCbmGaDRi = 806642873; TkCbmGaDRi > 0; TkCbmGaDRi--) {
            OfMMrLUKYadF = BCzGcjnLsxXzsjfA;
            SgPAjfXwFRvs += tUrewC;
            OfMMrLUKYadF = BCzGcjnLsxXzsjfA;
        }
    }

    if (SgPAjfXwFRvs != string("AoctWCoJwjYADhSWQNnwyhwcpLYoeoGarYqyvAygQnIxfzIjomndzRCBUJpLbXgmIR")) {
        for (int sJwmMWO = 40449237; sJwmMWO > 0; sJwmMWO--) {
            tUrewC = caqgazTZkb;
        }
    }

    if (caqgazTZkb != string("pDUItmuklDAjvaTVcVOuJuwrfLxOxKKgVGzWPLfooXIbIDWcQinwKUqscjhkFxbWlSIDnMbplktfxGDUjNELDTkjqnDbYePMByKpVLnUArGOHHtPmFTtWfzaAtSMriWcXZcKuUiTPMsTdKkgnNQPnzebWFGkJAATZzFWgQGXpDVPrjftaSbGVpOGbupZXsSmIAuziioFvEbtfcGIbSJVfONCfzibUP")) {
        for (int gDVohkfdj = 2020201079; gDVohkfdj > 0; gDVohkfdj--) {
            continue;
        }
    }

    for (int UuQtoJmkljnqk = 621459130; UuQtoJmkljnqk > 0; UuQtoJmkljnqk--) {
        BCzGcjnLsxXzsjfA /= OfMMrLUKYadF;
        BCzGcjnLsxXzsjfA *= BCzGcjnLsxXzsjfA;
    }

    for (int SNAuAKuEf = 1165025294; SNAuAKuEf > 0; SNAuAKuEf--) {
        SgPAjfXwFRvs = tUrewC;
        BCzGcjnLsxXzsjfA += OfMMrLUKYadF;
        tUrewC = tUrewC;
        caqgazTZkb += tUrewC;
        tUrewC += SgPAjfXwFRvs;
        caqgazTZkb += tUrewC;
        tUrewC = caqgazTZkb;
    }
}

PJuSCCqZ::PJuSCCqZ()
{
    this->scnAnMwEgdSzLN(string("CDxfKxnVZvOqRMsIPmflCGtsSnyBnVkZkjzvQmUlAHoLznRcPwKXtmHqqNFngmZhmuYMayzCdhZhpgxBfXfRzIImOlbOGylUhlB"), -456516685, string("JlPoUzLRJRuQDlnpusBMNQtmvWkeGJHexxYCaygNYhBnjrjkLWXgdOpKhkiatBZbXkHgdtyhEwxeXIgpMGUgZWZkUiBOqYtpNuyQjGizjlbDeIFnkUvHrGGiqWmYIVssmxUtNISZxsoLVeTgtqP"));
    this->STHVH();
    this->oCJMOJdkt(-652737.8783899278, false, -1640782362, -777313076);
    this->wGhYF();
    this->NTZeIFtF(1569266785, string("pMNMLdybaWORZqITMXZvuslxPSQDSwZ"), false, 872618608, 1154797870);
    this->XTcRlSjNwPyJw();
    this->inYHKMdGInCm(-1615094080);
    this->DVaZHkTiwbpvEDa(163572.47353486472, true, 1477903284, -464611143);
    this->EqWCWfouJ();
    this->ZofUCagLUqE(string("oAYimykBgOFMDCHGgRCJj"), 1237276664);
    this->pPZDenk();
    this->PxzeRDHYtEuqYdgC(false, 676442.7423273764, string("JnDwQTzYfEsQloCRvZNIaXBlfYiJWPlNdkrkzLxNcNUThcPoOkCfdaDpBoBwGKAPguBaRDfCWiuWFAyKhwoxSbkRylibJuATCErgJpospYtZhghAXwsPcSewzDUQNmUYnKNtvlVgFJNgPuDyUWvKLhpCkYWYAeMEWijXENFanLIkvxQEpMAICrWRalYOGEEKKYuarPzhwNoXiowuwKXYvxbFJiAFDJPMSL"), -1412703782, true);
    this->BMTOTOEJn();
    this->StUMd(false, false, 207478.64523314);
    this->jRBLrFtjkKOUi(true, false, -851992885, -865223.6318860791, 1798395988);
    this->LfLAcId(-594870.354015525, true);
    this->lftyuENH(754415.8201442006, false);
    this->DSaWWiDjfADgA();
    this->dUFzAGbEYesF();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qIKIKlJHsBWCbh
{
public:
    double QXycLcXWh;
    string hKmeUyf;
    double HDMoNtsDJoS;
    bool cFZWmQXeuq;
    int rqEeb;

    qIKIKlJHsBWCbh();
    bool RGCNXkPQHyrkHqQX();
    void CdhatHtnNrooT();
    double WJPYIuWhXCeslmf();
    double MNypSdZXuvdtYPG();
protected:
    bool bErifS;
    bool fsXoriUAA;

private:
    bool mUUeBkQQh;
    double BQmiCfvu;
    int hUTXu;
    string XpacajyNAqkOXq;
    int EQsKlsqEb;

};

bool qIKIKlJHsBWCbh::RGCNXkPQHyrkHqQX()
{
    int sSaGvZ = -1465126432;
    string joNcWIqHvlrlR = string("YtcNiWgBynblQLdXksaLBffylrbgArPcuhLFTBacLowIuxAuXFlVXllsnkepAlgDYLGWqrFJaaoxjpKxrhSSCpdGuGKpVpEMpGgTIOQDPGukLXHuiMdEiDapsjmOKMtgB");

    for (int WDFCAZqtXt = 1755708267; WDFCAZqtXt > 0; WDFCAZqtXt--) {
        sSaGvZ += sSaGvZ;
        joNcWIqHvlrlR = joNcWIqHvlrlR;
        joNcWIqHvlrlR += joNcWIqHvlrlR;
        joNcWIqHvlrlR += joNcWIqHvlrlR;
        joNcWIqHvlrlR = joNcWIqHvlrlR;
        joNcWIqHvlrlR = joNcWIqHvlrlR;
    }

    for (int oXfHptkZKnBRdgZq = 753444083; oXfHptkZKnBRdgZq > 0; oXfHptkZKnBRdgZq--) {
        continue;
    }

    for (int WMukRwauSCR = 138146188; WMukRwauSCR > 0; WMukRwauSCR--) {
        sSaGvZ = sSaGvZ;
    }

    return true;
}

void qIKIKlJHsBWCbh::CdhatHtnNrooT()
{
    double mbtbJKKAyYrN = -489850.3336792231;
    string xwalRDnciX = string("ociYzebHNRrkjIaKbpvRuiHuhqhJgfvsagBbaoRuDdwtXEwSGUrUusynqwmPwQljHxOByVddPkvSvCsEQgJEDFGzXJrOamTIFTMLVZQVanJgQuvkOyPmULfRGRaqjzyyIadAzSJZGXPpspodGzGYIhxtombXTUzFDgxkItgimiKDCOgsNpQWMmihwFqwhwUJxQRkevJg");
    string jmoXpzcErkt = string("UXrYMIiETskQdVYLndQXFiWZQPXwFZPKLyWEeLeYEGlVStEBZARWGLriIxqeQudjrzsqqzZghWDBSoncDAxOGZMPJeIWEIOWSxXpAreyDTFfkvzqAawnTtQBNPjirCSPjFCbLVTLmGNFwRrZgQWEMqKVfRvvakCmFtrAYxXzoZxbhgwsAvtEmnEtSYgFczPvciHAIfgSsJaQGbfvkLIwaGBqUzvjZOfhEHsARVSEsBLAKvx");
    int ctlxZ = -1031913183;
    bool wAgkcxegOQJTYu = true;
    bool InqqtXpsXWyRJcs = true;
    int OJwvhrdC = -1244409247;
    double ijmkLbeeJHPfBNI = 24697.669919382155;
    int rKagwyl = -466929466;
    int GcHsCNbKEALetb = 580041895;

    for (int lJFVQsxEkocDCs = 108996356; lJFVQsxEkocDCs > 0; lJFVQsxEkocDCs--) {
        continue;
    }

    for (int mnHCksQZrmfqDy = 2018820572; mnHCksQZrmfqDy > 0; mnHCksQZrmfqDy--) {
        continue;
    }

    if (GcHsCNbKEALetb >= 580041895) {
        for (int jPmUYxV = 301754942; jPmUYxV > 0; jPmUYxV--) {
            rKagwyl /= rKagwyl;
        }
    }

    for (int vFALgztF = 274629758; vFALgztF > 0; vFALgztF--) {
        ctlxZ += GcHsCNbKEALetb;
        rKagwyl -= ctlxZ;
    }
}

double qIKIKlJHsBWCbh::WJPYIuWhXCeslmf()
{
    string qrXxjMl = string("LnWEZBOpVyEimpjjBeToKHyJFvBJHhFfpGvOqDeEniuLHZCpnKPqLfenPJSGzphBLVfvLYtJpylZdtJnVtehYoiYyJqSVekzNkdgdAiPyViFcVyJtAKSZaCkRayQTMMspTGmPxGfpkHzrEMSAc");

    if (qrXxjMl != string("LnWEZBOpVyEimpjjBeToKHyJFvBJHhFfpGvOqDeEniuLHZCpnKPqLfenPJSGzphBLVfvLYtJpylZdtJnVtehYoiYyJqSVekzNkdgdAiPyViFcVyJtAKSZaCkRayQTMMspTGmPxGfpkHzrEMSAc")) {
        for (int PmQBgSevmsYTpGa = 1926586335; PmQBgSevmsYTpGa > 0; PmQBgSevmsYTpGa--) {
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
        }
    }

    if (qrXxjMl != string("LnWEZBOpVyEimpjjBeToKHyJFvBJHhFfpGvOqDeEniuLHZCpnKPqLfenPJSGzphBLVfvLYtJpylZdtJnVtehYoiYyJqSVekzNkdgdAiPyViFcVyJtAKSZaCkRayQTMMspTGmPxGfpkHzrEMSAc")) {
        for (int kUPVZbTihsgUlbm = 907111834; kUPVZbTihsgUlbm > 0; kUPVZbTihsgUlbm--) {
            qrXxjMl = qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl = qrXxjMl;
        }
    }

    if (qrXxjMl < string("LnWEZBOpVyEimpjjBeToKHyJFvBJHhFfpGvOqDeEniuLHZCpnKPqLfenPJSGzphBLVfvLYtJpylZdtJnVtehYoiYyJqSVekzNkdgdAiPyViFcVyJtAKSZaCkRayQTMMspTGmPxGfpkHzrEMSAc")) {
        for (int JTDlBNUobnjTn = 532781219; JTDlBNUobnjTn > 0; JTDlBNUobnjTn--) {
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl = qrXxjMl;
        }
    }

    if (qrXxjMl == string("LnWEZBOpVyEimpjjBeToKHyJFvBJHhFfpGvOqDeEniuLHZCpnKPqLfenPJSGzphBLVfvLYtJpylZdtJnVtehYoiYyJqSVekzNkdgdAiPyViFcVyJtAKSZaCkRayQTMMspTGmPxGfpkHzrEMSAc")) {
        for (int xnxdunAq = 460349888; xnxdunAq > 0; xnxdunAq--) {
            qrXxjMl += qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl = qrXxjMl;
            qrXxjMl += qrXxjMl;
            qrXxjMl += qrXxjMl;
        }
    }

    return 859231.0924751902;
}

double qIKIKlJHsBWCbh::MNypSdZXuvdtYPG()
{
    string CPHEBjVYuqwPv = string("TbxRTPxMtHyzjNcvEMrBiJMEXeHXmDhWPExZdZvxcjTVfiuoDWlXjyRQrQiybKwNEjuVPugPFJrMDqanHyyOKtntBKMNRjrqJLcrmGjIxGfIhUiffLQzneFcdVPsHQXCjhNPseilXoyGvXJNERDWJichqkh");
    double fYUJFYLAmAIkRH = 786139.0798756563;
    int mSqQVyUKDhluWsMm = -1270434629;
    bool PBCudg = false;
    int QXuPRiJFPBEbDHvO = -1808935994;
    double qyYxWgRin = 538999.6557105092;
    string LqzKAMHvNfaCvDA = string("ddAdRUzXMjMcXPLebuLJXKYPdQnJLbcMQONkbvLoDANbuztxZYlnhWCZjRhaiDbxxCffmaDPfQftuRxoRwmxepkoKAGvcOOvlNDKIvfGaqlZySSzCwyeoUXhwZNdHhWPREHMXOPXytNVPLAxSJzYujiIKfubsIzFtCYjNkcLBmvmtit");
    string jpLzeyxlXyJC = string("DMBlldiQjfjKFYcGrinGbftlWVeuTbWvYIlgHonhZURhYJMomVTmzBOAvUXrjuLkMFLVJEEUZxetQGJKBRyqJXaIyoIfXVVPoImPNijeEXGrxPRgpuYGqU");

    for (int lKBtIbGTEcw = 585901334; lKBtIbGTEcw > 0; lKBtIbGTEcw--) {
        continue;
    }

    for (int GMFkyIdHHhETD = 1646659445; GMFkyIdHHhETD > 0; GMFkyIdHHhETD--) {
        continue;
    }

    for (int ONAWqDxolJqrOtV = 952467324; ONAWqDxolJqrOtV > 0; ONAWqDxolJqrOtV--) {
        CPHEBjVYuqwPv = jpLzeyxlXyJC;
        jpLzeyxlXyJC = jpLzeyxlXyJC;
    }

    return qyYxWgRin;
}

qIKIKlJHsBWCbh::qIKIKlJHsBWCbh()
{
    this->RGCNXkPQHyrkHqQX();
    this->CdhatHtnNrooT();
    this->WJPYIuWhXCeslmf();
    this->MNypSdZXuvdtYPG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EINAKWsf
{
public:
    int RFQEyguJHQO;
    int ZUWrW;
    int INilNrjOWBxUnqn;
    double QUgGEOeuhZHGCB;

    EINAKWsf();
    void kvYjaEsp(int oYnzgxottTLE, bool CCWyNzI, string iKAyioOoLXTxUd, double kueHvSkTLVYoB, string EkLrhni);
    string MPCMPgZl(string QMfWKwPgpie, int DPBIKEEUfqJqjCEZ, int fMzQDrj, string HOZEvpUPsXpm);
    void wJrnfxBpFrTUld(string BAanZGKPflxu);
protected:
    string nDqEooxWSY;

    bool Ufeine(int TyFfrrcpH, double dTXlxxyHFHuyQxev, bool eTiwKit, double vloMABnaU, string mwKLfJQbJnzPv);
    bool AWuAijKPONQcYk(string QBbmqnOqVcMEA);
    double HxSolcuDHj(bool xCDesiPXO, bool CSsbvgussHcVYV);
    bool BbriVMYOxift(string ObBKUPEr, double NAxlcQoaXBqZlEV, bool NRlSfu);
    double JVhEzhHxR(string TJcdXbBYo, double cwqBwvNVdTRsx, string HxmYNqbmPcGn, double KpuKxaqmTFZOwP, string zdvUXUs);
private:
    string ArqUTVYjR;
    bool AkYeywomsnKiuYg;
    int WUtBeEfdGVwOgzzV;

    string VJmiWKOuRWzQyipG(string fQcSdEUKiG, int uLBQJUL, double bSXsCsR, double mhBDFtcvsSac);
    string sYmEoEW();
    bool rRypJlx(string GnKnBpq);
    double KNEOtVnMdTC(double BJzpfEVhUrSkJNNm, double wWtllZr, double QNjDPd);
    void XHxrboiib(double bbDtu, int BMvxfOZWUpYxRsfV);
    void CHnEDHWKGvqyo(int gDfZGgxghE, int dyXoDFvl, double xsAKEvGTgqs, double TjIOYIZkvViqH);
};

void EINAKWsf::kvYjaEsp(int oYnzgxottTLE, bool CCWyNzI, string iKAyioOoLXTxUd, double kueHvSkTLVYoB, string EkLrhni)
{
    bool znARoGCfCJsdDUp = true;
    string mRqGUonkugkAeS = string("oIiSsBjnIyXaKyLJsEDvKiDhynGQfPWlEPAZrYhiDoGrHcKzQGxyTZvdQIspQCEICWtAsqVXwvWRbjOiJFwoTOTNItVYVbIgNErLPmWrQhJEJoXJGEiYSASMcDfmxGQutMucVjNexlXgKTDpO");
    string MTAKxBS = string("xGzJZyhXAHAatUxwocRLQZuIhHQdkCyZJJXuUPKLaDfiUDoNDzIueOYLFlxKHzLTXswYoSXYMVsiAAMGRmmWOubyrQZEMeFMWITuHoWfbRplkduvnwkOwzRrzFgEFvcXXwepGNfkEuGQiPKgYAFxqWlZkdfMtPsBeeCWvQLWMpzchZeGggxNPAYouMCYDzzOsobcNnJlkDwUWAStIFdwmwzcxQZZOcuULvBuiECM");
    string cHBSrDBEqbsbN = string("MVwTjLUyNeucUSnYkZIBLIqSqPmUkbSVdaVHWNkZlaSDfryLLmncjuidOYrfECjOKmHiGBDtoVsrruflNmfznYDkbxMpzngqjQquyaVTExgWRJlUndBRwuJaUrUBVROdSpVnZKWNhCeQANKBhXqZOqGlfhKtXAsBpztbFufzKVqpStStweUZBZUtNqGEkUsGwXbkGJUXateoPGjYGtYOHupwdmsDRAJIwMgltdtgewbEiXFiwoSnRgpyYufcO");

    for (int FIfMwTzDEPJjNJf = 296558070; FIfMwTzDEPJjNJf > 0; FIfMwTzDEPJjNJf--) {
        iKAyioOoLXTxUd = EkLrhni;
        EkLrhni += cHBSrDBEqbsbN;
        znARoGCfCJsdDUp = CCWyNzI;
        mRqGUonkugkAeS = iKAyioOoLXTxUd;
        EkLrhni = EkLrhni;
    }

    if (EkLrhni == string("xGzJZyhXAHAatUxwocRLQZuIhHQdkCyZJJXuUPKLaDfiUDoNDzIueOYLFlxKHzLTXswYoSXYMVsiAAMGRmmWOubyrQZEMeFMWITuHoWfbRplkduvnwkOwzRrzFgEFvcXXwepGNfkEuGQiPKgYAFxqWlZkdfMtPsBeeCWvQLWMpzchZeGggxNPAYouMCYDzzOsobcNnJlkDwUWAStIFdwmwzcxQZZOcuULvBuiECM")) {
        for (int eejXOZ = 1973519915; eejXOZ > 0; eejXOZ--) {
            iKAyioOoLXTxUd = MTAKxBS;
            MTAKxBS = cHBSrDBEqbsbN;
            iKAyioOoLXTxUd = MTAKxBS;
            mRqGUonkugkAeS = cHBSrDBEqbsbN;
            cHBSrDBEqbsbN += cHBSrDBEqbsbN;
        }
    }
}

string EINAKWsf::MPCMPgZl(string QMfWKwPgpie, int DPBIKEEUfqJqjCEZ, int fMzQDrj, string HOZEvpUPsXpm)
{
    bool dgjqRPLnAp = false;
    string qYjfzERbxywLBUdO = string("mcdqiAtIGTxfEovUhBtfP");
    double MXeAJMJElEl = 101922.52139899612;
    string EwaDHJcjIoKnprSw = string("xuRQfzkOWTdmZeoGyTNUquBFdREVpznEhBgBbWAjgkwNxOyUtMpgekhPAoLxCXZWeBgtHYaqZOcMkAVtxwueWQNdMmQrIHRxwYIvHDUioedvkzVrtDuMPFGdyCFDyN");
    int IMaMRIHPFjQYtkFj = 531591750;
    bool OFZVqktdTZ = true;

    for (int ynssXWoG = 1992141469; ynssXWoG > 0; ynssXWoG--) {
        continue;
    }

    if (EwaDHJcjIoKnprSw == string("cMrVQGkLzzvTGhVndCSxGplpkCRiwyVhmHVIwchOJyeZRqGMHSBZFmLXaYFECUrUOVGGujbzLrucWFGJGRgFcsaxwNVgNufZlFSIBbGFGtcEKFATSupnCQCLXifVWUnmBfHCQFiVHIYCsNJPwtWQsTsZNmzGZrOJKXpTXPIGnXOICIMYTYqUDYWriPOVCTtwpKiPdXFLhiNXHXZmQrwkwZSFdo")) {
        for (int OLLjejPdiax = 411867941; OLLjejPdiax > 0; OLLjejPdiax--) {
            IMaMRIHPFjQYtkFj += IMaMRIHPFjQYtkFj;
        }
    }

    for (int FLepRAveYaeW = 742652699; FLepRAveYaeW > 0; FLepRAveYaeW--) {
        continue;
    }

    if (HOZEvpUPsXpm < string("cMrVQGkLzzvTGhVndCSxGplpkCRiwyVhmHVIwchOJyeZRqGMHSBZFmLXaYFECUrUOVGGujbzLrucWFGJGRgFcsaxwNVgNufZlFSIBbGFGtcEKFATSupnCQCLXifVWUnmBfHCQFiVHIYCsNJPwtWQsTsZNmzGZrOJKXpTXPIGnXOICIMYTYqUDYWriPOVCTtwpKiPdXFLhiNXHXZmQrwkwZSFdo")) {
        for (int KDAOAnssfBbzYaZ = 1197925350; KDAOAnssfBbzYaZ > 0; KDAOAnssfBbzYaZ--) {
            EwaDHJcjIoKnprSw += HOZEvpUPsXpm;
            DPBIKEEUfqJqjCEZ *= fMzQDrj;
            OFZVqktdTZ = OFZVqktdTZ;
        }
    }

    return EwaDHJcjIoKnprSw;
}

void EINAKWsf::wJrnfxBpFrTUld(string BAanZGKPflxu)
{
    int LAntjOyngHsRUkU = 151417584;
    double YvMHUMhw = -425413.7278958614;

    for (int HamsLunpbluXvU = 320141961; HamsLunpbluXvU > 0; HamsLunpbluXvU--) {
        continue;
    }

    for (int qMzxUnjUzwjm = 1264446108; qMzxUnjUzwjm > 0; qMzxUnjUzwjm--) {
        BAanZGKPflxu = BAanZGKPflxu;
        LAntjOyngHsRUkU /= LAntjOyngHsRUkU;
        BAanZGKPflxu += BAanZGKPflxu;
        YvMHUMhw /= YvMHUMhw;
    }

    if (YvMHUMhw < -425413.7278958614) {
        for (int VWbcaaolSMaNW = 1737395602; VWbcaaolSMaNW > 0; VWbcaaolSMaNW--) {
            BAanZGKPflxu += BAanZGKPflxu;
        }
    }

    if (BAanZGKPflxu <= string("SWLz")) {
        for (int QCrcEFZV = 577637329; QCrcEFZV > 0; QCrcEFZV--) {
            BAanZGKPflxu += BAanZGKPflxu;
            BAanZGKPflxu = BAanZGKPflxu;
        }
    }
}

bool EINAKWsf::Ufeine(int TyFfrrcpH, double dTXlxxyHFHuyQxev, bool eTiwKit, double vloMABnaU, string mwKLfJQbJnzPv)
{
    string VUFOanWYjn = string("kQbhcVZGDdkajKtCeiCzKyFonmaRzpDXuOYBTnAkvrztmZATaKKvINpImPULQZmHxHViZQAvHOtIOmYmZpzsXkAeLKVUJIlWXydvAYofsVyaPtHKhbNEmEpKAnqhxixYeOFclVnfunCPfPhKaZzfVyBnXswKVceuwJziNQdrdbPXZkUXqPJOtuELCYFGIYXLxgieqawRnTOvZlndHJdCiOlcYwtfXwzjZgKdlxRZgenhzmjsYHy");
    bool IDHwqmixzLFT = true;
    double xkHzpqZExMDbGDeU = 644572.1046855566;
    int kheGPcCYJ = -257372579;
    string jWiywdRMQIttUi = string("KUEoxMofMODhqRAMpqFWbMmlxfVeDPJvabxGvueXUqnkbYhrmDxmnFyMvAmtvhpYUOWaHboDGkzemNzEqfIkVtWiloLtorpIaZtrEeRu");

    if (VUFOanWYjn < string("kQbhcVZGDdkajKtCeiCzKyFonmaRzpDXuOYBTnAkvrztmZATaKKvINpImPULQZmHxHViZQAvHOtIOmYmZpzsXkAeLKVUJIlWXydvAYofsVyaPtHKhbNEmEpKAnqhxixYeOFclVnfunCPfPhKaZzfVyBnXswKVceuwJziNQdrdbPXZkUXqPJOtuELCYFGIYXLxgieqawRnTOvZlndHJdCiOlcYwtfXwzjZgKdlxRZgenhzmjsYHy")) {
        for (int LVZoga = 718581583; LVZoga > 0; LVZoga--) {
            IDHwqmixzLFT = ! IDHwqmixzLFT;
        }
    }

    if (mwKLfJQbJnzPv != string("kQbhcVZGDdkajKtCeiCzKyFonmaRzpDXuOYBTnAkvrztmZATaKKvINpImPULQZmHxHViZQAvHOtIOmYmZpzsXkAeLKVUJIlWXydvAYofsVyaPtHKhbNEmEpKAnqhxixYeOFclVnfunCPfPhKaZzfVyBnXswKVceuwJziNQdrdbPXZkUXqPJOtuELCYFGIYXLxgieqawRnTOvZlndHJdCiOlcYwtfXwzjZgKdlxRZgenhzmjsYHy")) {
        for (int iNEXzJRCWpKJc = 1815036799; iNEXzJRCWpKJc > 0; iNEXzJRCWpKJc--) {
            xkHzpqZExMDbGDeU *= dTXlxxyHFHuyQxev;
        }
    }

    return IDHwqmixzLFT;
}

bool EINAKWsf::AWuAijKPONQcYk(string QBbmqnOqVcMEA)
{
    string AkVLygqSIeAj = string("HhERsSwpNXFinedWubCsyFNEXGJOTIZAHUjYhfgxmivMkEhqUvSIsyjLoJppyfQM");
    bool kMBoMkr = false;

    if (AkVLygqSIeAj != string("MjBemgBpTJWoFBCXOEhPFoCiKQFwEemuLjOiNArTkjLVLKzIDHjJdJkuyMfPzZqfTrPrZJUsBwEGYARwvEqfTIyEkRwXWjqLZPqLuiGDubTmlSfrXQvBNUXwuZtFHsvaffvrbVMxSEQZhUJwTeRIoAKVTnYsEpuRMGXIapUgbxPesjrSiPDqQlnfDXfRcNatpdYAVFxKBABlDSLjadazFvjPjARYoQotNbRfURO")) {
        for (int vDQMdLJOfpj = 251905392; vDQMdLJOfpj > 0; vDQMdLJOfpj--) {
            AkVLygqSIeAj += QBbmqnOqVcMEA;
            AkVLygqSIeAj = AkVLygqSIeAj;
            QBbmqnOqVcMEA += AkVLygqSIeAj;
            QBbmqnOqVcMEA = QBbmqnOqVcMEA;
        }
    }

    for (int aVPsB = 1432173439; aVPsB > 0; aVPsB--) {
        kMBoMkr = kMBoMkr;
        QBbmqnOqVcMEA += QBbmqnOqVcMEA;
        kMBoMkr = kMBoMkr;
    }

    for (int KXoos = 1621445771; KXoos > 0; KXoos--) {
        QBbmqnOqVcMEA = QBbmqnOqVcMEA;
    }

    return kMBoMkr;
}

double EINAKWsf::HxSolcuDHj(bool xCDesiPXO, bool CSsbvgussHcVYV)
{
    int QLbIeVBWOBkLorTM = -1008310612;
    string MiZGsNdRZo = string("jIgfWhLHxXRINznzGEvBcwDZzPlatumjNCfVaDpcbjrRHzSmPrOAuNcuPzImbIedMAumpmaHJY");
    double ezDxs = -632469.7896685424;
    string FGDhaxLFuBbs = string("EaSwUweOawDKxDuGZvOLDrYuzCNsDkBTPCGhWQByGWzQnUbUPgWEzJlAbrHCtGTdOcBSEUNeWJgSAQdiJbvlAz");
    bool ldQsbqEBvVqli = true;
    string XsTGAOkYkRcgqEP = string("bzIRoWJIHrLMVadukYJxSNKSZAcICSTKFpDnSBbAUVfbBJOFauMtRoHB");
    int ApmYTIKFjpM = -7362470;
    bool vETFCj = true;
    double lYNwRtwa = -728965.5764873433;

    for (int NFXPWtrwKcDK = 37180255; NFXPWtrwKcDK > 0; NFXPWtrwKcDK--) {
        FGDhaxLFuBbs = FGDhaxLFuBbs;
    }

    for (int FbQDmrwMnJjQdtiN = 2027437091; FbQDmrwMnJjQdtiN > 0; FbQDmrwMnJjQdtiN--) {
        ezDxs += ezDxs;
    }

    return lYNwRtwa;
}

bool EINAKWsf::BbriVMYOxift(string ObBKUPEr, double NAxlcQoaXBqZlEV, bool NRlSfu)
{
    double xnoRDvBcl = -16157.078177795434;
    string rBLtMSJwEH = string("PJOsEBBknpRxlvTkTHznsRVMdMKqwILIObBREJHugQURFwMMNeYKwitUbLrTkROlJvxQAkWVTikYjymnWstwjPQvbbXUiKrDIMBbCKzhmGBAWSfnFuWmFByBOrlnKhbgMLbEeuSwklGDhkCNYAZlHYbrVDEaGsfEJyDoMwQPEVYDdxBYoWyEEQHWltSqUHOZopyyEjPjDxvzhYPGurPRGWXaLODfKSFHABnJYEGcpebnWPWQRisDAIQPymilC");
    bool LeAGIYrfIRMqoyus = true;
    string SzfBvY = string("pSnhHmLMBucabaPbdTKkegjFDBwdhhMKOtLcsjDoRJeFsvmzOQKMYlOqhHiqmNWojipjeyJBJCszbceYfrVMAcFQOeGELpRPXblfjOeKfHqZpsKyIlLLicyuehzSGGFkhitSLIFtvqUwlIu");

    if (rBLtMSJwEH != string("ZYkVjQxYEqLseWTBOcHCalgHWOGvkxMBZvtZTKMCzzLGfRMXCiVd")) {
        for (int ySRtXdkXgnB = 220269924; ySRtXdkXgnB > 0; ySRtXdkXgnB--) {
            rBLtMSJwEH = rBLtMSJwEH;
        }
    }

    for (int GsaDd = 1611187658; GsaDd > 0; GsaDd--) {
        ObBKUPEr = ObBKUPEr;
        SzfBvY = SzfBvY;
        SzfBvY += SzfBvY;
        SzfBvY += rBLtMSJwEH;
        SzfBvY = SzfBvY;
    }

    return LeAGIYrfIRMqoyus;
}

double EINAKWsf::JVhEzhHxR(string TJcdXbBYo, double cwqBwvNVdTRsx, string HxmYNqbmPcGn, double KpuKxaqmTFZOwP, string zdvUXUs)
{
    bool GCOpnluioA = false;
    bool joILBejaCFScBAo = false;
    bool ESyMhP = false;
    int wmCCJzjV = -1513331026;
    string PxmsipL = string("gxYSJjWjzIbeQAcbeMoCvgnJFNZNuuQFBIjtUwZGRYAmdcZxnrNQndZiNTxzzSiDDxBvFSEjzcSTdPcjMoUnmbOTZCVsQsjUIeacveGaBhcROVkUIFmYHLnQDQqGAxRDXtOFDfbhUYHYxalqMIQednmAhCRLxVQqfdHaZRmWXbnLwLqRnUuWlCcoDQZvVeHMfLlKTINHGIVvyAhqNQxnyQ");
    string UbPhke = string("yqzziWAIcNaIGMLaLVLthrMUurvYCOvwBVFfmgAZFGpwYUFyjsnLcJRAtwWXUYQFaTeaufrupQQmYBwaEiwjFxdXzsrSPLLiHBURoNEkTYoTACNCMFpkIWlpRbIDWioUlaMXlWrPwtkFxoWCBYZujRbILrFaglKLunVIODNjoFfHkmeKcBRFmUbTZqSQ");

    for (int rPRZucznRfh = 2102378612; rPRZucznRfh > 0; rPRZucznRfh--) {
        PxmsipL += HxmYNqbmPcGn;
        ESyMhP = ! ESyMhP;
    }

    if (PxmsipL >= string("gxYSJjWjzIbeQAcbeMoCvgnJFNZNuuQFBIjtUwZGRYAmdcZxnrNQndZiNTxzzSiDDxBvFSEjzcSTdPcjMoUnmbOTZCVsQsjUIeacveGaBhcROVkUIFmYHLnQDQqGAxRDXtOFDfbhUYHYxalqMIQednmAhCRLxVQqfdHaZRmWXbnLwLqRnUuWlCcoDQZvVeHMfLlKTINHGIVvyAhqNQxnyQ")) {
        for (int FQHkjsjmtRpVdw = 822003758; FQHkjsjmtRpVdw > 0; FQHkjsjmtRpVdw--) {
            zdvUXUs += PxmsipL;
            GCOpnluioA = joILBejaCFScBAo;
            TJcdXbBYo += zdvUXUs;
        }
    }

    return KpuKxaqmTFZOwP;
}

string EINAKWsf::VJmiWKOuRWzQyipG(string fQcSdEUKiG, int uLBQJUL, double bSXsCsR, double mhBDFtcvsSac)
{
    double iFkyt = -445242.60305621795;
    int FuDWluYIyxcyc = 1517149351;
    double llojSLAJF = 245532.6149535542;
    bool Iyluh = true;
    string uFbmpQMbS = string("XCSHKLUtgmBVXKfWsoSMbfNJEHGKlD");
    string jDBivxMzs = string("IcXIyJRGfkqesbzDaaWzSwtPpYJEtGguIGcUEXLyrauAbjUKBdUegcUobWxnfjsTzrCZRaYXJQRvhqDMaqEAaonImPjDpjUTZFGUutyNVpeoi");
    string gncedfeQXbempL = string("iJKbZfnmXSXeYmksOkewzIHAFsVoBGdvYoMyUffMATPTKVKcpASvRcauXYKrlpWEstofPUQrBjIhdzDDGnvpCujyzftMcHudEjwxRzEWPYUmhoCAICzZjJqNjgIHsbAksYSOV");
    bool JLpukvoP = false;
    string xZmemXNndJZWnPi = string("vRnYkRZMBIKbUXVsgvGstUVYpibDsIfmBoOLWvXMMRvvqDCtRNPUjHdeCgVPDqgIoUcyjgECQteJXXJCfcaGUacnLMCDTjDniVMOqQGNQxXOlTmGf");
    bool QTtUkVvRReOq = false;

    for (int tkfcbKuNzvnAAeCR = 1204840358; tkfcbKuNzvnAAeCR > 0; tkfcbKuNzvnAAeCR--) {
        fQcSdEUKiG = uFbmpQMbS;
        fQcSdEUKiG = jDBivxMzs;
    }

    for (int UfypFzkZK = 165646672; UfypFzkZK > 0; UfypFzkZK--) {
        gncedfeQXbempL += uFbmpQMbS;
        fQcSdEUKiG = uFbmpQMbS;
        iFkyt -= bSXsCsR;
        FuDWluYIyxcyc = uLBQJUL;
    }

    for (int baUAKgalqi = 1644100569; baUAKgalqi > 0; baUAKgalqi--) {
        gncedfeQXbempL += uFbmpQMbS;
        fQcSdEUKiG = gncedfeQXbempL;
    }

    if (mhBDFtcvsSac < -166326.96174343364) {
        for (int TbUDLqNYYFV = 722838611; TbUDLqNYYFV > 0; TbUDLqNYYFV--) {
            fQcSdEUKiG = uFbmpQMbS;
            fQcSdEUKiG += fQcSdEUKiG;
        }
    }

    for (int eyfXZUi = 2087125060; eyfXZUi > 0; eyfXZUi--) {
        continue;
    }

    for (int PnWgTf = 565480872; PnWgTf > 0; PnWgTf--) {
        continue;
    }

    for (int KdSTRYJRQnQWahE = 1383781363; KdSTRYJRQnQWahE > 0; KdSTRYJRQnQWahE--) {
        mhBDFtcvsSac -= llojSLAJF;
    }

    for (int GsgjRR = 520013998; GsgjRR > 0; GsgjRR--) {
        bSXsCsR = bSXsCsR;
        gncedfeQXbempL = xZmemXNndJZWnPi;
        uFbmpQMbS += jDBivxMzs;
    }

    return xZmemXNndJZWnPi;
}

string EINAKWsf::sYmEoEW()
{
    double fwdRUXDGraAizdkF = -562240.0566364679;
    bool zXseO = true;
    double CyQaBYeEfOuL = 244878.08319447655;

    for (int ePTGWSPNbWPT = 2114417251; ePTGWSPNbWPT > 0; ePTGWSPNbWPT--) {
        CyQaBYeEfOuL = fwdRUXDGraAizdkF;
        fwdRUXDGraAizdkF -= fwdRUXDGraAizdkF;
    }

    return string("cGsaBtQDMqQRIVYqdRbTjCdXYPVFjLJJl");
}

bool EINAKWsf::rRypJlx(string GnKnBpq)
{
    double KuYpWQDeySzrj = -98951.06306199609;
    string rhQHfOIbGSzFNZae = string("ajVqupPpNmGobsWhMOXLjUPHHYmIGEQFwretbWbmISkWQdzVRvWROzghaNhlGBaGiUnKyDOJbxIZwggIVeRRhEjdidhFpPLUbychOlJjeiwbjydYbXUCTcERZUFtvwIBFRPNxEzbPLunywzOgIplZMDoSxMBTAbQkbLjxZuEPjtySxHzwD");
    int etDtZAETdIk = 694847309;
    bool TxJichCxv = true;
    int rVOkqbZEZPiegnf = -260575289;
    double UhsBvcOfUk = -849935.8774129793;
    int MtdOFPcKjsPqUnKF = 1725906484;

    for (int xznRDhpuN = 503074064; xznRDhpuN > 0; xznRDhpuN--) {
        GnKnBpq += GnKnBpq;
    }

    for (int REzxBj = 2065410968; REzxBj > 0; REzxBj--) {
        rVOkqbZEZPiegnf *= etDtZAETdIk;
        etDtZAETdIk /= MtdOFPcKjsPqUnKF;
    }

    if (etDtZAETdIk <= 694847309) {
        for (int QbAUqP = 1549865046; QbAUqP > 0; QbAUqP--) {
            etDtZAETdIk *= rVOkqbZEZPiegnf;
            MtdOFPcKjsPqUnKF /= etDtZAETdIk;
        }
    }

    for (int rQUjPdRlva = 1182247314; rQUjPdRlva > 0; rQUjPdRlva--) {
        KuYpWQDeySzrj = KuYpWQDeySzrj;
    }

    return TxJichCxv;
}

double EINAKWsf::KNEOtVnMdTC(double BJzpfEVhUrSkJNNm, double wWtllZr, double QNjDPd)
{
    string wSfLPyS = string("fZUGFxYpITryKVKVZSSnbvNFMgfNVEfDjIsvnqjdiCkCNRSLDtxQdFtPKoGtCWYeogTZgQDXlgcEsWmRArNdHrkXxJbqeNebWGQvvCgzZUjeWIiZLHnDyNprlsPWkqxLwLlvNtbPlSpFtYpCLWUYxiuQxoGfgJWWLHrLsRYQbeJvsGdnUIsOSgMuvkhZvOVeiOkfG");
    string rPHgRP = string("AqoOmDxRZMxdDMcsqhfqnqJWcLuFLHCqfccJVAgbTYCMeBfwvuKguCrMwCAGwbGUzjEtElRWvjKZbtAPQCXqPmOXlHSkQeFTsrPNpNAuXDEjFJVDoLHeAFvNlJcOlKcDQNzCoIjWTm");
    string yOiOfspmM = string("SCtpPSHzSIKBBTJNldjrUFbTNFAKJOZGAmCfQLxyEHfLpMdBTQtQKgsMTEZyyFPqaF");
    string vUBQWXATsMoHQT = string("UsHuXdbcaNhTuoQNCsMFSxzgDadXxYYzvOgYdRYujaxVAjwNBAkEgxBLlHGWXCnKJQGHkQQNyJfCaqRaUJvbTDcOgxoOrEWYvrDxZEzSNimRwofEEitISIUKgjEDpCPuFZeZhtWNepbhsMRLItwgKAMSlraIROnFVLGHvdhbvUNCoiwMzZigEPigXuSapNpKoilKsOOMXeoyGNVCaxlSXvwxmNRnwdZEUPFXHuXzdyqelvbzlkphBJenP");
    bool HzgcNcYNWgnNLfA = true;
    string oxsLqejOiebWT = string("eRLUjXgVdXgswjiWLQRxCMkCsbNyMlObMsAkXradfCWDOYGdIcuYTqZErSzBKxOaqBVLHCAPcCziJwFPmbgErpFxbzCUYzwcfqysNxJGWgAcGZNfRekj");
    int xsbwJJ = -831632954;
    double ZyIyhFYBspYSsRHG = 716991.1313936819;

    for (int TDiNtYutmHjL = 39371541; TDiNtYutmHjL > 0; TDiNtYutmHjL--) {
        wSfLPyS += yOiOfspmM;
    }

    for (int IHeHvJoEqkqYw = 462674841; IHeHvJoEqkqYw > 0; IHeHvJoEqkqYw--) {
        continue;
    }

    for (int yAZbKfTAUubMk = 1943522930; yAZbKfTAUubMk > 0; yAZbKfTAUubMk--) {
        oxsLqejOiebWT += oxsLqejOiebWT;
        ZyIyhFYBspYSsRHG -= QNjDPd;
        wSfLPyS += vUBQWXATsMoHQT;
    }

    return ZyIyhFYBspYSsRHG;
}

void EINAKWsf::XHxrboiib(double bbDtu, int BMvxfOZWUpYxRsfV)
{
    string lcOlAsUVf = string("YibZzpJ");
    string gjMWXcMIYd = string("KwXaNUMZcbwWSlUFxUfKiIIwZoITatuYmeCPBOGWRNbLJjaFehLYkUmlESSednqqdPGHZHOCYRXefywcTzSudGqPMZzmZaGGUfpqBrqYVtHWaRNZrAOwXQgEeXSnDOHeKuotGhEskbyLvnTnqxUBHRKidrGDBPAoZqaVxlWbFMUfFHnRqdqoglXHzGODFyxzjyVRhEiVORxsHFjTImEXtiTGHlAYFkMKireqhp");
    bool VVtrrMlWEdVh = false;
    int HGwhemTfWzAhZvr = 731265922;
    double mlEaQP = 227085.4293505848;
    int MfRwlPqOa = -420000453;
    bool xgrmF = false;
    bool gqqgNQKQCm = true;
    double lPKhMZNkwtFv = -756253.1746797664;

    if (VVtrrMlWEdVh != false) {
        for (int RCOTeVc = 1025058419; RCOTeVc > 0; RCOTeVc--) {
            lcOlAsUVf = gjMWXcMIYd;
        }
    }

    for (int azrfYFhukKHjassC = 540908323; azrfYFhukKHjassC > 0; azrfYFhukKHjassC--) {
        BMvxfOZWUpYxRsfV = HGwhemTfWzAhZvr;
    }
}

void EINAKWsf::CHnEDHWKGvqyo(int gDfZGgxghE, int dyXoDFvl, double xsAKEvGTgqs, double TjIOYIZkvViqH)
{
    string YVeceeYHveYreufb = string("nzvYNHzRvkAaOmgQNLgyIlVOYVJcgJWQEXBGQttPIUNRXaJxLtMYDCXNHJlcOoVoFqfjgDvoDHMyCQPetJoEHYqYcLwMAdVgYmnWxIhqzajCRqgzmAnYMEz");
    string RLreset = string("xvhfhxqShWOYkiTbVHYjvsLwkIzIvAnXZixLIYCLFmftcSwFPtQmyJFTLFhfcpKcNBReTkGDmpjptaPzGTUCeszUIaQtIuNRiWEExZUKBwWykPlXpOaFihOcoNKydwxGeVRigMoidpGQyJCYuiGbESLgCrEBPRqgdCtaPdGFFgmEQPoOXmuCaXBJQKtbGu");
    string gBCwVGtCmeTHKuKB = string("nwYATSePYShnsWmCTMqJUfLfGkMBbeTElHtbVJeihaStOJSFRMdIUeKJNORLYfAgSxmBrcntWfoOTLf");
    bool yXOFsISounG = true;
    double YYewDQ = 434344.40205221495;

    for (int iOLrZG = 376962397; iOLrZG > 0; iOLrZG--) {
        YYewDQ = TjIOYIZkvViqH;
        dyXoDFvl -= dyXoDFvl;
    }
}

EINAKWsf::EINAKWsf()
{
    this->kvYjaEsp(-881217986, true, string("VwsDZTdrFcRebKHPiAlNuzSxoncbEY"), 527569.499620957, string("ZVChCzCsKxRhrvXAmUzdBVNzxTHfQAnMzQhAZCWbyHmvcxyjcQXqBKzjCZhQIbMunqsQEMoWJeIOWakmfjEUQcNSyKRLNTsWkPsFSAahtvDfrLihnDQjKapIqkcbNmwognzUesUzulZIHpTONmcggtHIVSZCKusQlcFCkWDgSsAJJlXDFaJBdSvRadegoSMlYUSpHtGitMYoTwReBnouCzIkxwajaPkUyROdXdYXNHgbgTDA"));
    this->MPCMPgZl(string("nGCtxLuEewZVnGIYbtVQZvJdiyJvjSNxdgutyeozbmNlEHGawfnfgTiHFQAGpEeUTnkUeVUPwGvgu"), -278210755, -1598602614, string("cMrVQGkLzzvTGhVndCSxGplpkCRiwyVhmHVIwchOJyeZRqGMHSBZFmLXaYFECUrUOVGGujbzLrucWFGJGRgFcsaxwNVgNufZlFSIBbGFGtcEKFATSupnCQCLXifVWUnmBfHCQFiVHIYCsNJPwtWQsTsZNmzGZrOJKXpTXPIGnXOICIMYTYqUDYWriPOVCTtwpKiPdXFLhiNXHXZmQrwkwZSFdo"));
    this->wJrnfxBpFrTUld(string("SWLz"));
    this->Ufeine(-1169971476, -609148.8805876609, true, 728029.0612710596, string("OWyKJlvpgrTlJGcsLybTrlIXQbAFygZtptCdBfY"));
    this->AWuAijKPONQcYk(string("MjBemgBpTJWoFBCXOEhPFoCiKQFwEemuLjOiNArTkjLVLKzIDHjJdJkuyMfPzZqfTrPrZJUsBwEGYARwvEqfTIyEkRwXWjqLZPqLuiGDubTmlSfrXQvBNUXwuZtFHsvaffvrbVMxSEQZhUJwTeRIoAKVTnYsEpuRMGXIapUgbxPesjrSiPDqQlnfDXfRcNatpdYAVFxKBABlDSLjadazFvjPjARYoQotNbRfURO"));
    this->HxSolcuDHj(false, false);
    this->BbriVMYOxift(string("ZYkVjQxYEqLseWTBOcHCalgHWOGvkxMBZvtZTKMCzzLGfRMXCiVd"), -716217.7840887384, true);
    this->JVhEzhHxR(string("dTnYNBFUqOryoIcaIBnvBEgzJcTIowQVfxAEDlPcSRdNWbwVBLoTyVebkksbsexawpsiVlVbxDvDETToEPFNVAcrkhDoypaAlxxfQAkwYaPRSLVHCQgynUjXenHXRBLnZYQqrZDxNNOCPxBJYxeHayXrHrpuOIAjNXDzKwhHLJ"), -400548.9347005501, string("NXLagDyXEudRkipUzJJLYcWLqtWthGFgnKjruVoHwAriSXoYLDpqZCfJSIbBVRQQhLhECuDaMxvfJQUISijwFMeHbOakppZVkjZLlmOBwpmsrYWcvhPmonJB"), -12693.186106291892, string("WirRWUEG"));
    this->VJmiWKOuRWzQyipG(string("wMmmyuzKOTYzVfpWqBzelmmshXgXPbCAiyCcQImAzYqIbRLVxlQAtiQqIAvSgNDrryQVESRLsCLPGwdPLjSffAKrezccMjOZFmxiUrFfsEPbnQAwGlCiWYtYSIWuIFqydmAWifhcnxPeMFiLlaQIbxPIMWpIckZWhtlSXBQjDkOjgikytZnbgosFUqIAOyyxdpFZyRZTvLLtLIKwjnAQXuPYuTtHHnGIzxvblRTFQSIV"), 529255798, -166326.96174343364, -302700.7664112135);
    this->sYmEoEW();
    this->rRypJlx(string("kKBInXKoVdToCHHDHjLwBDUXKgaztsfyoopXXnxEFOKpOhjCwfEAfoWDsIUAnFtNbbLKxjagNXPDMFhdARPYgMcYUKgnVxrzmLAhdcNHhYXiCOVSaEzEJQwhCoYzXscwpqJofaXyWphizkWMerCfUSFDrsHXbXTMnXkBmJbILCDMsOpHXQGOlZDLQbcumIcWrFaMsHhzTsgFrMAFwEThOaKLdHJKdlRawyLWsetgQOwamIAiAwRm"));
    this->KNEOtVnMdTC(-569973.8980225837, 680799.2587125296, 820678.2379939706);
    this->XHxrboiib(402718.5173187723, 441815824);
    this->CHnEDHWKGvqyo(-185547223, 1633679903, -41340.93997872493, -869518.6885638868);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CRsyLqyiZHRt
{
public:
    double QhwonFAkkGnqqh;

    CRsyLqyiZHRt();
    void TzJmxpzTzcodNN(string sezyUlgr, int mnzPmcpFl, double EzCElwU);
    void fokneJhPwZSFl(int eULEatFU, string jfsTVTjex, string hFpMDAxmmYPnJin, string vazywHursBtsER, double MbqOF);
    void jXXmuklOfO(bool gmTFmaVbpa, bool NfsyqY, bool EFHbjpwfeEZp, int gLtPnMjjEdpE);
    int zmYcwYmUzinZd(double dyWSYyXvO, int jeGqM, bool vwkwd);
protected:
    string QvgLCvTyIIBjMtU;
    bool xfobbYspFGtSQMkp;
    int RBZPjSbjOZRKol;
    int dEOTslTr;

    bool yjEBAbhdJ();
    string pOxmPnnZs(double CyBXQFtgnPmfVLcV, bool AcxXjECosdKvnx, bool TqLdUeTah);
    string KEyznWU(bool vZHAibUZ, string vkuREVTvnU, bool DGhpOhGzTHv);
    void ZsfPrZDOhICiSjuc();
    double JzWVOs(bool LydblOXE, bool lYteskeP, double KGJnkqOrvwMDG, string ReJfFhbYoAsoIw);
    bool YlKQZuIYtkwhLG(bool hHojEKF);
    int qWHwQPA(string tHNEGeGsl, int WCvdoTbS);
private:
    string UGRajY;
    int zifFkekVM;
    int FDllmeXYNsR;
    int mdrmJeUxu;
    string MHoqNQPTbRaJYj;
    string ZuHuhTLnyXPL;

};

void CRsyLqyiZHRt::TzJmxpzTzcodNN(string sezyUlgr, int mnzPmcpFl, double EzCElwU)
{
    string kwNJWxYZenSWsRx = string("mNXisyclRZkjWCoDMCpcyrqGGIMeFRTZGVsSWlKDNUTOlkMNEOXRCFKHCUKLOTmAMzoOnxfZMvEZtDAXAlyeaGibdCrUqIKmUImKaQTSPYcDCUjXvuwIJyvUdGVQeYdPQfeeTwUklstqRimUKaUVvDVCgUgKvTbJuYUBqxQCpMqbWOhjJyUQPAOaTDgGujnccPGryoIqzAmfc");
    double aHSJZ = -595258.5030530097;

    if (sezyUlgr < string("mNXisyclRZkjWCoDMCpcyrqGGIMeFRTZGVsSWlKDNUTOlkMNEOXRCFKHCUKLOTmAMzoOnxfZMvEZtDAXAlyeaGibdCrUqIKmUImKaQTSPYcDCUjXvuwIJyvUdGVQeYdPQfeeTwUklstqRimUKaUVvDVCgUgKvTbJuYUBqxQCpMqbWOhjJyUQPAOaTDgGujnccPGryoIqzAmfc")) {
        for (int qkBpCNIWKO = 994219071; qkBpCNIWKO > 0; qkBpCNIWKO--) {
            aHSJZ /= EzCElwU;
            kwNJWxYZenSWsRx += sezyUlgr;
        }
    }
}

void CRsyLqyiZHRt::fokneJhPwZSFl(int eULEatFU, string jfsTVTjex, string hFpMDAxmmYPnJin, string vazywHursBtsER, double MbqOF)
{
    int uCyXZLtIvK = 452108187;
    bool GAMXmtDPHAFHynM = true;
    int SzEJUUTuaF = 1566831092;

    for (int IpJjXgJYLnk = 1147995872; IpJjXgJYLnk > 0; IpJjXgJYLnk--) {
        hFpMDAxmmYPnJin = jfsTVTjex;
        jfsTVTjex += hFpMDAxmmYPnJin;
    }

    for (int AWoWFOOAjM = 200931472; AWoWFOOAjM > 0; AWoWFOOAjM--) {
        uCyXZLtIvK -= uCyXZLtIvK;
        vazywHursBtsER = vazywHursBtsER;
    }

    if (jfsTVTjex > string("xcULmFfejBnTHgXwfvebOMkVYOuxDFuNdOFeYHPIMOxdBcwjuajhinTDaaEpIIGnXJhbTwXBVjGcCjwlmUazRLtTRFsuTzcXGC")) {
        for (int uHKLpgDuxGAibdE = 1730642010; uHKLpgDuxGAibdE > 0; uHKLpgDuxGAibdE--) {
            uCyXZLtIvK /= eULEatFU;
            SzEJUUTuaF += SzEJUUTuaF;
        }
    }

    if (GAMXmtDPHAFHynM == true) {
        for (int AAwHTCAMnfvxq = 823925865; AAwHTCAMnfvxq > 0; AAwHTCAMnfvxq--) {
            hFpMDAxmmYPnJin = vazywHursBtsER;
        }
    }

    for (int snctldLNFDuPYFm = 1607936203; snctldLNFDuPYFm > 0; snctldLNFDuPYFm--) {
        vazywHursBtsER += hFpMDAxmmYPnJin;
    }

    if (jfsTVTjex > string("wduqPjBlOzwpbCcTZkOgNtzBDohxELladPaXBcirvtqzSHoJLXQaftWkJeNKCvSRUQvTbuiHSN")) {
        for (int fXULhwpzU = 1027817985; fXULhwpzU > 0; fXULhwpzU--) {
            continue;
        }
    }
}

void CRsyLqyiZHRt::jXXmuklOfO(bool gmTFmaVbpa, bool NfsyqY, bool EFHbjpwfeEZp, int gLtPnMjjEdpE)
{
    double eveHyQIT = -69571.63617001336;

    for (int GxibjIrbDZyII = 429056619; GxibjIrbDZyII > 0; GxibjIrbDZyII--) {
        NfsyqY = ! NfsyqY;
        gmTFmaVbpa = EFHbjpwfeEZp;
        eveHyQIT *= eveHyQIT;
        NfsyqY = ! gmTFmaVbpa;
    }

    for (int SfwWXrCrHEoWsr = 1828505731; SfwWXrCrHEoWsr > 0; SfwWXrCrHEoWsr--) {
        eveHyQIT += eveHyQIT;
        gmTFmaVbpa = NfsyqY;
        EFHbjpwfeEZp = gmTFmaVbpa;
        EFHbjpwfeEZp = NfsyqY;
        NfsyqY = ! NfsyqY;
        gmTFmaVbpa = NfsyqY;
    }

    for (int keZHDoqA = 1187085329; keZHDoqA > 0; keZHDoqA--) {
        NfsyqY = ! NfsyqY;
        gmTFmaVbpa = ! gmTFmaVbpa;
    }
}

int CRsyLqyiZHRt::zmYcwYmUzinZd(double dyWSYyXvO, int jeGqM, bool vwkwd)
{
    double MXJVe = -694662.0177212236;
    double dGZMGusIepG = 827042.8902846894;
    string gwyWskBhPcnGBh = string("NmMVxOFa");

    if (MXJVe == 306801.8553344315) {
        for (int SHzqdmhOx = 2130881857; SHzqdmhOx > 0; SHzqdmhOx--) {
            dyWSYyXvO /= dyWSYyXvO;
            vwkwd = vwkwd;
        }
    }

    for (int DNAqbsQohosg = 1410166401; DNAqbsQohosg > 0; DNAqbsQohosg--) {
        vwkwd = ! vwkwd;
        dyWSYyXvO *= dyWSYyXvO;
        dyWSYyXvO /= dGZMGusIepG;
    }

    for (int rPJLFunxvzpamvq = 1421626515; rPJLFunxvzpamvq > 0; rPJLFunxvzpamvq--) {
        gwyWskBhPcnGBh += gwyWskBhPcnGBh;
        jeGqM += jeGqM;
    }

    for (int jynQmyuFHBGx = 1430416064; jynQmyuFHBGx > 0; jynQmyuFHBGx--) {
        continue;
    }

    if (jeGqM == 1314912421) {
        for (int EmmvdQVfAlfkf = 1119179692; EmmvdQVfAlfkf > 0; EmmvdQVfAlfkf--) {
            MXJVe /= MXJVe;
            jeGqM *= jeGqM;
        }
    }

    for (int HkXIbueyYAE = 1689498941; HkXIbueyYAE > 0; HkXIbueyYAE--) {
        MXJVe *= MXJVe;
        MXJVe += dyWSYyXvO;
        dGZMGusIepG /= dyWSYyXvO;
        gwyWskBhPcnGBh = gwyWskBhPcnGBh;
        dGZMGusIepG -= MXJVe;
    }

    for (int OQLkGmVdPKr = 2053082198; OQLkGmVdPKr > 0; OQLkGmVdPKr--) {
        dyWSYyXvO /= dyWSYyXvO;
    }

    return jeGqM;
}

bool CRsyLqyiZHRt::yjEBAbhdJ()
{
    int XHMaScm = -1305894716;
    double rWUqP = 432838.17451610946;

    if (rWUqP < 432838.17451610946) {
        for (int ANYAYkP = 1289170975; ANYAYkP > 0; ANYAYkP--) {
            XHMaScm /= XHMaScm;
            XHMaScm = XHMaScm;
            XHMaScm *= XHMaScm;
            XHMaScm = XHMaScm;
        }
    }

    return false;
}

string CRsyLqyiZHRt::pOxmPnnZs(double CyBXQFtgnPmfVLcV, bool AcxXjECosdKvnx, bool TqLdUeTah)
{
    double CjcFz = -221820.9503972629;
    string QoMEgJTHHA = string("MoerSROpeLTTGCjagGMGoUMKbtznrCrBilGHeBSCjyckjzqJqIlPTEKRRLxuzaAyeIcTFahnQQdMUKfAQbboBnzqFkhMOcCldxNFWvlMisLMzAaAkIXLgnmtaEMUyJlqgYmKlAMxVWUGANtUekYurkZH");
    double PeVzZFZzwXin = -832293.3055863542;
    double xcmjf = -956218.6807039389;
    string gFhZgWfxRQXr = string("iMzrlkkvFmmEPsBJMkFvJqHkDrFBsIrboEVCWGTEOTkwtzcjKPuvjihGWFtOxFtpklWbqqsrjWAcJMrRcAAKzrDvpebOjCALkcILhodpdtEBHwinuENeEoCBuSKJOliWhHQlLFsTGsXqAhGSzCQbAPQSVUOmZKj");
    int AEVRMClsDbJe = 370261553;
    int yHFSbrVgeZhrlBNa = 10491971;
    string WGmJYXJo = string("FWyuLNhFRTAMLTaDWINSDpzULtWnGTAsImqxlLZsmpgXOUIKpfxzRnmYmvkFkbhrZMOIAZCVpgmuHlUaEGprlmjHcWtwnFDVjinYEjyPDBnMwanCXknDkBARzsnZUpXOcbLGBaPVxEXRKDQZNbgoozOoJvDmgGyzTtevOZuLXCXfvxGCzlwtQMlcjdzjGDsdMVK");

    for (int WfgQHNrOf = 1484023002; WfgQHNrOf > 0; WfgQHNrOf--) {
        gFhZgWfxRQXr = gFhZgWfxRQXr;
        AcxXjECosdKvnx = ! TqLdUeTah;
        PeVzZFZzwXin += xcmjf;
    }

    for (int CGdClxIKNTE = 1317984433; CGdClxIKNTE > 0; CGdClxIKNTE--) {
        AcxXjECosdKvnx = TqLdUeTah;
    }

    return WGmJYXJo;
}

string CRsyLqyiZHRt::KEyznWU(bool vZHAibUZ, string vkuREVTvnU, bool DGhpOhGzTHv)
{
    int PdfJodav = -617246095;
    double UKwIbORmSbhwtPu = -170052.4342366819;

    for (int ujAtkAKPaalclog = 788314491; ujAtkAKPaalclog > 0; ujAtkAKPaalclog--) {
        DGhpOhGzTHv = DGhpOhGzTHv;
    }

    for (int MEmXvpxSRu = 1952418356; MEmXvpxSRu > 0; MEmXvpxSRu--) {
        DGhpOhGzTHv = ! DGhpOhGzTHv;
        UKwIbORmSbhwtPu *= UKwIbORmSbhwtPu;
    }

    for (int ZFDiQqks = 267661197; ZFDiQqks > 0; ZFDiQqks--) {
        DGhpOhGzTHv = DGhpOhGzTHv;
        vZHAibUZ = ! DGhpOhGzTHv;
    }

    if (UKwIbORmSbhwtPu <= -170052.4342366819) {
        for (int sYvvSFjsCrTfQg = 926619305; sYvvSFjsCrTfQg > 0; sYvvSFjsCrTfQg--) {
            vkuREVTvnU += vkuREVTvnU;
            PdfJodav *= PdfJodav;
        }
    }

    for (int ycXelVdQOMIHx = 1868801648; ycXelVdQOMIHx > 0; ycXelVdQOMIHx--) {
        vZHAibUZ = ! vZHAibUZ;
    }

    for (int gDNbSKeYHJXa = 2122356334; gDNbSKeYHJXa > 0; gDNbSKeYHJXa--) {
        vkuREVTvnU += vkuREVTvnU;
    }

    return vkuREVTvnU;
}

void CRsyLqyiZHRt::ZsfPrZDOhICiSjuc()
{
    string LXvKBb = string("ziDzYEXDrKeBNHdjYyDjVOzpXUuVJrxypDKWAaynOPuonfCiRBVOpauxwKAUQxaOvIvADiXHewwIIsIiCrFdqnPbrVGtbiBlkyqYfAuUtMIaJUzKAkKnCqJCMPDWMdHzLqSSyaOUdMMqyPomjDvQwtQDfbmujMLFDvjppaqTphHvbWCErSXItSbujxJWfgxhqTSUWGMAbzVzGRmqUbhxgkxsGoIDvJgXVAUbdhOCWAcyYIHNLFhiEQiSybVAx");
    string XQTnzodhe = string("FLBOSFSJqDMKBVXrhfBKJmuJgr");
    string fqqYoU = string("SOTXlqOZuthMtTeSTPIIJIUGffxYcmkcQQBPscQUXmLRbKerXHwovfTkpjMjiUSIKMZiwIhrEWkFeInCJhmhMIMBfNJQpMnkYuHuAtovDLEjhpgWHxyszalGXJzwsLloPVBGSriDbNITvhoNxdqxliejfdMTZALyCZhwYgeOQe");
    string YgXBvbOJU = string("JaSOUdQyXqxyDpmdsPcomjGSjRXujRAGKQBrSmiMGFfcHLFZdjyuWslKvlhgsKqHYCRKLeslbEqsplLBhxypuXUTuiF");
    string FrmWyZBDzs = string("aFoocqYlEnKbIXdPBQvAczyIDstCUCUpSrQkRwLhPnxSALGCfeLqGIYBKKXUPYfSBglkONvOfbbfThmyQbPcHnEQonogDGLmHJJudEDbVmOSRImghzZovlxvNrGeuCGsviDoZIPmSIcVIqSnMRHKAdGINwQMFrriDSlIPOFboXyeZLqtuRLCiiPVjtCCGXLJszskgzNbRVcVHTyJJItDvZJ");

    if (YgXBvbOJU < string("SOTXlqOZuthMtTeSTPIIJIUGffxYcmkcQQBPscQUXmLRbKerXHwovfTkpjMjiUSIKMZiwIhrEWkFeInCJhmhMIMBfNJQpMnkYuHuAtovDLEjhpgWHxyszalGXJzwsLloPVBGSriDbNITvhoNxdqxliejfdMTZALyCZhwYgeOQe")) {
        for (int HusbnFeQyzD = 1180054466; HusbnFeQyzD > 0; HusbnFeQyzD--) {
            FrmWyZBDzs += FrmWyZBDzs;
            FrmWyZBDzs += LXvKBb;
        }
    }

    if (fqqYoU > string("SOTXlqOZuthMtTeSTPIIJIUGffxYcmkcQQBPscQUXmLRbKerXHwovfTkpjMjiUSIKMZiwIhrEWkFeInCJhmhMIMBfNJQpMnkYuHuAtovDLEjhpgWHxyszalGXJzwsLloPVBGSriDbNITvhoNxdqxliejfdMTZALyCZhwYgeOQe")) {
        for (int xqxEiqOZG = 235541621; xqxEiqOZG > 0; xqxEiqOZG--) {
            fqqYoU = fqqYoU;
        }
    }
}

double CRsyLqyiZHRt::JzWVOs(bool LydblOXE, bool lYteskeP, double KGJnkqOrvwMDG, string ReJfFhbYoAsoIw)
{
    double EUyyWhzsM = 349528.51167773583;
    int YLzbRwyr = -1975951901;

    for (int ptiWaernnCBihszI = 1775949443; ptiWaernnCBihszI > 0; ptiWaernnCBihszI--) {
        EUyyWhzsM -= EUyyWhzsM;
        LydblOXE = lYteskeP;
        LydblOXE = ! lYteskeP;
    }

    for (int yUnLNtaaJ = 2033877636; yUnLNtaaJ > 0; yUnLNtaaJ--) {
        EUyyWhzsM = KGJnkqOrvwMDG;
        lYteskeP = LydblOXE;
    }

    return EUyyWhzsM;
}

bool CRsyLqyiZHRt::YlKQZuIYtkwhLG(bool hHojEKF)
{
    double QTYIhQBnDBTE = 630595.3322552335;
    bool vXbJoCuY = true;
    bool lbfGO = false;
    bool tlHYuYBGNE = true;
    double aqXrkvFko = 232834.75176707542;
    double kGBAChhJd = -448810.37636844395;
    bool dytAPZMr = true;
    bool ggzzmoMBgaaRQG = true;
    string eLJOkgfJmfGwqUBn = string("xLxdJTgKCqiQLnUBIcuOrKufpeQiyEKedgEZdBvpjbGysvuksqQXJulwqQoEwSWFcPuoyXwtFhqReyuYPNFxksXufifTsTLpUPufBvdLqZUBqcDdyXDQocZNSZFxrfVWirrxXjvDDSLKeBLkooXuDShjkwzpJslYAueBybXFxwavuiwSugxYtPOaiTPNTZYlFHSOUiBBxbDLghLEmmNsHLdlCvuzAxxB");

    if (dytAPZMr == true) {
        for (int StGYQPTiszJndq = 628917640; StGYQPTiszJndq > 0; StGYQPTiszJndq--) {
            vXbJoCuY = hHojEKF;
        }
    }

    for (int cHyQggGpWqMwpRpO = 1145195819; cHyQggGpWqMwpRpO > 0; cHyQggGpWqMwpRpO--) {
        vXbJoCuY = lbfGO;
        tlHYuYBGNE = vXbJoCuY;
        aqXrkvFko -= aqXrkvFko;
        ggzzmoMBgaaRQG = ! dytAPZMr;
        kGBAChhJd /= aqXrkvFko;
    }

    if (dytAPZMr == false) {
        for (int WQzajQmzVthVZ = 1202749382; WQzajQmzVthVZ > 0; WQzajQmzVthVZ--) {
            vXbJoCuY = dytAPZMr;
            vXbJoCuY = lbfGO;
        }
    }

    return ggzzmoMBgaaRQG;
}

int CRsyLqyiZHRt::qWHwQPA(string tHNEGeGsl, int WCvdoTbS)
{
    string YKlYEBDNp = string("rJwmHgiUgTgsKUJaTMrUTjtiuBUPeJSXkjYBqnRaNCuuHMwsjCGvElhCmscakbBSIPnLkWWASYfrQIBkZMiUTPJRzghHpTDhnEPCEXqScfutfHYYiHWQmxSuHFrSlFSlOu");
    int sFPsXxKzEIqXmLJh = 213641829;
    bool aQYtj = false;

    if (tHNEGeGsl < string("VfiMszkFraZQWtXUCYLpIFYCmnIZyJAncGgGXFZAxooYnBbTqeVIAoqEPcDMbTqeJASjVwhMhIQyVEymRgayrEzTQXHnEsQLdxmYgYEtFrZpibfaQSVRQoJyHRDgit")) {
        for (int JKiwNtdAL = 1262193410; JKiwNtdAL > 0; JKiwNtdAL--) {
            tHNEGeGsl = YKlYEBDNp;
            sFPsXxKzEIqXmLJh = WCvdoTbS;
            tHNEGeGsl = YKlYEBDNp;
        }
    }

    for (int gRHoymOajkprEQM = 1387084682; gRHoymOajkprEQM > 0; gRHoymOajkprEQM--) {
        continue;
    }

    if (WCvdoTbS == 213641829) {
        for (int dTneBv = 922737871; dTneBv > 0; dTneBv--) {
            YKlYEBDNp += YKlYEBDNp;
            aQYtj = aQYtj;
            YKlYEBDNp += tHNEGeGsl;
            YKlYEBDNp = tHNEGeGsl;
        }
    }

    return sFPsXxKzEIqXmLJh;
}

CRsyLqyiZHRt::CRsyLqyiZHRt()
{
    this->TzJmxpzTzcodNN(string("BnjjridMXhiokYBCVRxpvpcgwoUHCgcYPvTddxLVCmIYjeaWdIEIPQtOPSEMOgVnisCaZtvDQgrCxURZQmIcxskbYHzCeeGMnEXatTwiSDUnZUFBbZlDsnYeyjbAHdFrroiMShsxkrjoGGsQJQJDSPfpewyBCiCoOLlCbVePSXrgcdeTRnmlBjdQuGvkkoEVmsboWxdlyJatMvihFsptAtGRQJmiRIQlcVHAnMqUaEBRwjFQe"), -1286404862, -87885.84166828098);
    this->fokneJhPwZSFl(1878156316, string("wduqPjBlOzwpbCcTZkOgNtzBDohxELladPaXBcirvtqzSHoJLXQaftWkJeNKCvSRUQvTbuiHSN"), string("xcULmFfejBnTHgXwfvebOMkVYOuxDFuNdOFeYHPIMOxdBcwjuajhinTDaaEpIIGnXJhbTwXBVjGcCjwlmUazRLtTRFsuTzcXGC"), string("AoDHBHLhrBgbcIhZHuRWqonoEjLXsANGQmPIlTcbSbQOewSIDVJsERujPnTPJvndTAfslJDygVSEAAjAeGnmNQTkdtoTHZwAmpdCxhacritalpRJYpEdyUi"), 506968.81787852425);
    this->jXXmuklOfO(true, true, false, 1630253315);
    this->zmYcwYmUzinZd(306801.8553344315, 1314912421, false);
    this->yjEBAbhdJ();
    this->pOxmPnnZs(-53654.94068805881, true, false);
    this->KEyznWU(false, string("BfnqicxQdfUCpaAvehZphhqSHhTtXbCCqFNtmnBRCLQORzxHpvTctocoZuSbpZetPVSRsBlXnKgpXeQOLuVFINdI"), false);
    this->ZsfPrZDOhICiSjuc();
    this->JzWVOs(false, true, 112927.3276546972, string("WoPGmfbxhsTqZutrZWggQvpGPLRBrPtbrJNpetVVQdDJqsGSlelwILgcmwvfJUtoTBSVvkolGBJMkhiuLfpDJnZkLdsRbYEZynJfNKsiLVNEhxrfQekMKYWABLdLBLxaMpQcmUIsJNrWYaFaSbgqPqEdovFPPBMAhGnxZuXhmgWcAlVUqmUDOjlrBfRdqYjZqdiGEuexwSiiHHTLZdLozwqDOvnyjVEbIgEaBOruATodIiLskmwzezGCrsR"));
    this->YlKQZuIYtkwhLG(true);
    this->qWHwQPA(string("VfiMszkFraZQWtXUCYLpIFYCmnIZyJAncGgGXFZAxooYnBbTqeVIAoqEPcDMbTqeJASjVwhMhIQyVEymRgayrEzTQXHnEsQLdxmYgYEtFrZpibfaQSVRQoJyHRDgit"), 1790840196);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OdcURehUdOzbCN
{
public:
    double bugQPh;
    string fmzyABKPTqenR;
    double VVEGqlXsimN;
    int YbLJCjYSDzMScr;
    double BpHTwYGRi;

    OdcURehUdOzbCN();
    string tmBQuQOakaFEV(string CCLyE, bool EroAhmjyrTCzmT, string wNEeVgdUu, double SlfbEA);
protected:
    int nWGuFPbkpNqciiBB;
    int DncYVpyRBq;
    int yIGPlXmSPCykdT;
    bool irkQmxAktdfXlT;
    double KXcnGuDB;
    bool mPbXxtdmTOZTDVvt;

    double FHLTypqUvKTKPx(double tzpWUx, int sxxysbE, string PUZJzevnchVFDMEV, double XnlQQkG);
    string pBgcLvhSUz(int RxcxO, int oOfgQRAxlCRKM);
    double jVJzGAwrNT(bool ObuxWdXspV, double pSHDmm, bool CvPQGUq, bool BvxTmVUmLCp, int LduIdvhHcJGClX);
    bool QAPYxPAs(int GRqPzasumBO, double UHgEkqQgdfnuViP, bool gZrpvaF, double AxKHmgpaTUeqAVZ, bool hGvwLpW);
    string idrqIYNz(string JeedfSbOefrG, double cPykhHupuDwEX);
private:
    int DTazwUHZaI;
    int jKnQhxKMhoAGe;
    int BPMykuNDOoKS;
    double tDWaPIyDQbTHXY;

};

string OdcURehUdOzbCN::tmBQuQOakaFEV(string CCLyE, bool EroAhmjyrTCzmT, string wNEeVgdUu, double SlfbEA)
{
    double uqbVSOag = 481784.31127196393;
    int VQcPkjfB = -351021454;

    if (wNEeVgdUu >= string("EACTvoeqvLIOdBZzcDUoDDdYCFsaOnWGzFTYlZhwGehzrAHwfLiTjiPAEHKvWRTebnMpewmfKwWPOxJEqEgDkFOKTYOQEcKGbiwBQgILyaXUpZobPXxyBZWqYoEPZwJfrEbUVRdYeeCivoDMdxDLfIZElCxBeOWAGwDBqKGnaVdxseeMbyDujVHzwhHhpXwIYpIbTTsyeAHRavmOeFJUNhpdDXOnekOTqbsdZZwTMrZzHXTooQXTTOmFR")) {
        for (int EkmTnCSlt = 1488066785; EkmTnCSlt > 0; EkmTnCSlt--) {
            wNEeVgdUu = wNEeVgdUu;
        }
    }

    for (int UaCfKFMgLhXykSY = 1836319666; UaCfKFMgLhXykSY > 0; UaCfKFMgLhXykSY--) {
        continue;
    }

    if (EroAhmjyrTCzmT != true) {
        for (int qvuEyLEExgldS = 866754152; qvuEyLEExgldS > 0; qvuEyLEExgldS--) {
            CCLyE = wNEeVgdUu;
        }
    }

    for (int zgJdPE = 341046217; zgJdPE > 0; zgJdPE--) {
        uqbVSOag += uqbVSOag;
        CCLyE += wNEeVgdUu;
        CCLyE = CCLyE;
    }

    for (int ohFOYd = 1493678206; ohFOYd > 0; ohFOYd--) {
        wNEeVgdUu += CCLyE;
    }

    for (int bCJeJbwDn = 56536682; bCJeJbwDn > 0; bCJeJbwDn--) {
        EroAhmjyrTCzmT = EroAhmjyrTCzmT;
        uqbVSOag = SlfbEA;
        EroAhmjyrTCzmT = EroAhmjyrTCzmT;
        EroAhmjyrTCzmT = ! EroAhmjyrTCzmT;
        uqbVSOag *= uqbVSOag;
    }

    return wNEeVgdUu;
}

double OdcURehUdOzbCN::FHLTypqUvKTKPx(double tzpWUx, int sxxysbE, string PUZJzevnchVFDMEV, double XnlQQkG)
{
    bool jeQaiIrDkoHOyvuS = false;
    string uTodXBhpCnQM = string("yfTsRfycSJBrnFDPxAyuagydGsohNrUoBnTgdsoQloQwknWAnlVoLaYpIExsaTxYAduLzPFctzECxtXtIQejtlXQHSkOFlNoFCtbwQBAMcJyjEZYbnVwDIQiIGrKrSxeCHKdtgdX");
    int ufuVhmjBYdUIC = 575571366;

    for (int pPXKJTU = 1850696578; pPXKJTU > 0; pPXKJTU--) {
        tzpWUx *= XnlQQkG;
    }

    if (jeQaiIrDkoHOyvuS == false) {
        for (int VRbQxliaoPKqTLR = 2096937217; VRbQxliaoPKqTLR > 0; VRbQxliaoPKqTLR--) {
            PUZJzevnchVFDMEV = PUZJzevnchVFDMEV;
            sxxysbE *= sxxysbE;
            tzpWUx *= tzpWUx;
        }
    }

    for (int eEYinoXR = 873057760; eEYinoXR > 0; eEYinoXR--) {
        continue;
    }

    if (XnlQQkG < 779623.342093986) {
        for (int lZBWAQ = 1744468469; lZBWAQ > 0; lZBWAQ--) {
            ufuVhmjBYdUIC += ufuVhmjBYdUIC;
        }
    }

    if (PUZJzevnchVFDMEV >= string("unaTShXFiioelsWJUCNASZxcRrwwFaSpknBXAdyldIwJZJmMltDaldcXcussqMvWDvVPmPZBFrUSRaNStUvYcTpQrHAOAiZNeEfzsXgsLkCycsxEbFhbwQiYnheshUhSgUeRshSZc")) {
        for (int zwxnSnQXVk = 1656738899; zwxnSnQXVk > 0; zwxnSnQXVk--) {
            jeQaiIrDkoHOyvuS = jeQaiIrDkoHOyvuS;
            ufuVhmjBYdUIC += sxxysbE;
        }
    }

    return XnlQQkG;
}

string OdcURehUdOzbCN::pBgcLvhSUz(int RxcxO, int oOfgQRAxlCRKM)
{
    string TTGcldfCzRnsDua = string("iOWsQEDCplvprAruKSmeffWiSFRiZDKNjFKwaiXgrhGtjHlUZIGCRKLJjudejEIlKxLbtWvPPqElHANwslXfXlApUyovwCtMsizEkZgslpvsUccVwrkAaAjLpNSLxSwdtYJIohlUWCepknmxPTGYEJRWaLforYtwXslytQqMYMggAFAlKyLHTXPasJTWgioTrWMAVrLugiwUfZiafKRNtvFgZQoccyvxNnvlNSSfUgKSatmcD");
    double JBvCKRoctlp = 622973.0487060883;
    bool QuDfSlyxdn = true;
    double UhKJdCAplp = 979210.7342045393;
    bool lPdyQIP = false;
    bool JyTxANnAWfX = false;
    string tQuSYqaasXMr = string("XtpiakrQnpFKuQKJIlpwYXqCAopPhdjRcFrnsBYWOZJrBmWhcpVFGJWHRntUolbXljfkKxpVTMzNBiscmsxtkrbGNToRLsmxGeXIdUmnFHHOjOljrBNRWukYTWKFmEOdhObdggjJGZIZfQIbCqaYIioNcyxPXzrhhXIdGQTwbBQimrxNUTrUYTCxlqHkUoCBzAjqBnbOugFWQScpsKKkdCgJJiZaTWQNkSFDmAQqlZvWwTqciEREdN");
    int TCnXfdCRMJC = -1477505930;
    double GrsnFSrkUe = 525511.4936201689;

    return tQuSYqaasXMr;
}

double OdcURehUdOzbCN::jVJzGAwrNT(bool ObuxWdXspV, double pSHDmm, bool CvPQGUq, bool BvxTmVUmLCp, int LduIdvhHcJGClX)
{
    double uKHHmO = 867218.0217747175;
    double KdFBBIeauIBqE = 971834.2230151215;
    int lKrvDXi = 1542024298;

    if (ObuxWdXspV != false) {
        for (int hsEoJZTPuT = 1813926402; hsEoJZTPuT > 0; hsEoJZTPuT--) {
            KdFBBIeauIBqE *= pSHDmm;
            uKHHmO += KdFBBIeauIBqE;
            pSHDmm += pSHDmm;
        }
    }

    return KdFBBIeauIBqE;
}

bool OdcURehUdOzbCN::QAPYxPAs(int GRqPzasumBO, double UHgEkqQgdfnuViP, bool gZrpvaF, double AxKHmgpaTUeqAVZ, bool hGvwLpW)
{
    double sWRrLyqyXDzexS = 395245.85404580104;

    for (int SknfEkVR = 1657418974; SknfEkVR > 0; SknfEkVR--) {
        continue;
    }

    for (int dYqQUtzXkPOhbrl = 701548482; dYqQUtzXkPOhbrl > 0; dYqQUtzXkPOhbrl--) {
        hGvwLpW = gZrpvaF;
    }

    return hGvwLpW;
}

string OdcURehUdOzbCN::idrqIYNz(string JeedfSbOefrG, double cPykhHupuDwEX)
{
    double abkMtayj = 584037.8286132622;
    string GdPPcODm = string("LnmkrkCTefxfOlmOBKcuewsBNebeOSvsKqrmmtFiHRRtWDwQehHLkgJHlnswAIQFZyxDyLkTWanzDCTuIRzPjeZQXVFPhypzlESXhJuLprbCEujnupJLkCzSVKMDDToVeBqaNLfijUxQrZaaTSQeZJdsjWtSkJDiqkWsEdPTAvUvRlhzWNTorfntLXHCFzkkUOvfEheeMFBUKhIlotFMWzxKgcuQkHXBQNlUIvNJXFDZdYdsxKFMxkvtP");
    double PtQoTalF = 214948.8305175539;
    int dgjZaTehjeaRSeDt = 121283767;

    for (int hRogMMyQtZi = 339482359; hRogMMyQtZi > 0; hRogMMyQtZi--) {
        PtQoTalF = PtQoTalF;
        PtQoTalF -= abkMtayj;
        PtQoTalF /= abkMtayj;
        dgjZaTehjeaRSeDt = dgjZaTehjeaRSeDt;
    }

    return GdPPcODm;
}

OdcURehUdOzbCN::OdcURehUdOzbCN()
{
    this->tmBQuQOakaFEV(string("EACTvoeqvLIOdBZzcDUoDDdYCFsaOnWGzFTYlZhwGehzrAHwfLiTjiPAEHKvWRTebnMpewmfKwWPOxJEqEgDkFOKTYOQEcKGbiwBQgILyaXUpZobPXxyBZWqYoEPZwJfrEbUVRdYeeCivoDMdxDLfIZElCxBeOWAGwDBqKGnaVdxseeMbyDujVHzwhHhpXwIYpIbTTsyeAHRavmOeFJUNhpdDXOnekOTqbsdZZwTMrZzHXTooQXTTOmFR"), true, string("uouekwdFposZClzePpFuvdBDnifEKkHiTxIaDLeuqwkbXUbRRnCjhgnfkmSjNdrYnAMMADzlJApvOEPQoBQXAosIBzYnWBTXOrflOAouIXuwtWkoUodUaDiqbDpqMUGaAZAanTHUKFyOqCbXfBXERIsGvqZBzTHXUMyceoYZQakWg"), -1027625.450835955);
    this->FHLTypqUvKTKPx(758121.4063253078, -1971421556, string("unaTShXFiioelsWJUCNASZxcRrwwFaSpknBXAdyldIwJZJmMltDaldcXcussqMvWDvVPmPZBFrUSRaNStUvYcTpQrHAOAiZNeEfzsXgsLkCycsxEbFhbwQiYnheshUhSgUeRshSZc"), 779623.342093986);
    this->pBgcLvhSUz(-463799055, -689354241);
    this->jVJzGAwrNT(false, -95313.04025745731, true, true, 1720904653);
    this->QAPYxPAs(-1683496634, 54647.48634336942, true, 131443.3305572454, true);
    this->idrqIYNz(string("UpkQHhWUrTpQRhSJfcIZDmZMUrripCIrHzkmYTfwVEdnRTacnNPzVoPhNsIWYxviAKyiXdvJeHVjCClZwsxBJOiGyNCgRpDxeWwOlQbufoPjPnplbeshYAakYvFsfaJEVMhTlfMqyHuDkTkyxILgnyQZzNScoLBBqCqisFOBJlJoADsncfcOYDWScBhhKkcxUQXoowK"), 262627.11635571625);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AHdMTiXmL
{
public:
    bool BdsWrRxTSR;
    int JqbtThX;
    string wrsndlaB;
    double uzbgMogWNF;
    string UGvswwY;
    bool clCUq;

    AHdMTiXmL();
    bool ppMjDyY(bool vemCfBYhEwHtU, double yEMAYpXDnxwBaam, double RhlznNU, int XbDrJNSvRLmFtCe, int rqVFigsi);
protected:
    int QYKPJ;
    string PMXmA;
    string aoKUydmzfaoC;
    int QhfJS;

    void pjJHh(string tpYCgODo, string gFwsT, bool iFpNUqayad, int IEFwUDFodxNDL);
    int xfADLMMWqM(bool KnXvWEnVrrGwJ, int YqRyOle, double tTzkUKXL);
    string ZQQneh(string VDxCUpKCI);
private:
    double FHAXjyzYqDkDv;

};

bool AHdMTiXmL::ppMjDyY(bool vemCfBYhEwHtU, double yEMAYpXDnxwBaam, double RhlznNU, int XbDrJNSvRLmFtCe, int rqVFigsi)
{
    double WtxfvGacFjHlV = 389441.8023949221;
    double MpnlJhEnQP = -382559.87530820887;
    double OWZhfcLAVCZosyC = 47148.55368157193;
    bool SOLlmTOPSpbdYir = false;

    for (int NhnGAGchaEq = 1978466703; NhnGAGchaEq > 0; NhnGAGchaEq--) {
        MpnlJhEnQP -= OWZhfcLAVCZosyC;
        rqVFigsi += rqVFigsi;
    }

    for (int AgiIvaCxEGqaMmb = 1663462918; AgiIvaCxEGqaMmb > 0; AgiIvaCxEGqaMmb--) {
        rqVFigsi /= rqVFigsi;
        WtxfvGacFjHlV /= yEMAYpXDnxwBaam;
    }

    if (WtxfvGacFjHlV != -382559.87530820887) {
        for (int MkWUdWg = 1037372449; MkWUdWg > 0; MkWUdWg--) {
            MpnlJhEnQP /= yEMAYpXDnxwBaam;
            MpnlJhEnQP -= RhlznNU;
            WtxfvGacFjHlV *= yEMAYpXDnxwBaam;
            WtxfvGacFjHlV /= WtxfvGacFjHlV;
            MpnlJhEnQP *= OWZhfcLAVCZosyC;
        }
    }

    for (int EOQhcEslVzwOu = 799897895; EOQhcEslVzwOu > 0; EOQhcEslVzwOu--) {
        MpnlJhEnQP *= WtxfvGacFjHlV;
        WtxfvGacFjHlV = WtxfvGacFjHlV;
        yEMAYpXDnxwBaam /= yEMAYpXDnxwBaam;
        MpnlJhEnQP -= MpnlJhEnQP;
        XbDrJNSvRLmFtCe = rqVFigsi;
        WtxfvGacFjHlV /= yEMAYpXDnxwBaam;
    }

    for (int uhGKxpAiWAV = 2095314639; uhGKxpAiWAV > 0; uhGKxpAiWAV--) {
        RhlznNU += yEMAYpXDnxwBaam;
        SOLlmTOPSpbdYir = vemCfBYhEwHtU;
        yEMAYpXDnxwBaam -= yEMAYpXDnxwBaam;
    }

    if (yEMAYpXDnxwBaam < -559336.8528923643) {
        for (int XMojqatssQ = 1173179418; XMojqatssQ > 0; XMojqatssQ--) {
            yEMAYpXDnxwBaam *= yEMAYpXDnxwBaam;
        }
    }

    return SOLlmTOPSpbdYir;
}

void AHdMTiXmL::pjJHh(string tpYCgODo, string gFwsT, bool iFpNUqayad, int IEFwUDFodxNDL)
{
    double TpRrWG = -42870.736915010195;
    string lSfVjFngyEGMvj = string("KUBFfZYtzOalxoiWAaPhkLugtuToDtFIGmYhsTInPoscQVOlXFgAPZuMLMjYLZOUFbotqDRpKNEcgvVBCxOJMvEvXUEoxiXMGZQLSsKPnbtlFXyQYaIlcpigLetheKGUMEVurLpQfWKgqjUGyAmRroDRwHBMlefrmUuJZusKMzYFKvHZpLSVkJMeudpsqKUTfUaYsPkzgsbTDJMqmXobEcRVHgZtOMZYpbMoRkWVvEHl");
    int PFmuOJF = -2059078974;
    int uTwLun = 1368506771;
    bool IhxnQRp = false;

    for (int rVaenkjTBExTg = 1672336459; rVaenkjTBExTg > 0; rVaenkjTBExTg--) {
        gFwsT = tpYCgODo;
    }

    for (int qmTlpSNOr = 149980985; qmTlpSNOr > 0; qmTlpSNOr--) {
        continue;
    }
}

int AHdMTiXmL::xfADLMMWqM(bool KnXvWEnVrrGwJ, int YqRyOle, double tTzkUKXL)
{
    bool wkkSZtUWRDncLlHw = true;
    int yzQEqXb = -1353711689;
    bool Sxajv = true;
    int aKXdYYGVNaaGdlV = -2089476321;
    bool gTSEqJ = true;
    double wUOKnPewtf = -85279.64454927466;
    int NDdWKdQr = 31397493;
    double HNGofjr = -439091.63660449575;
    int ThfMBzLTtf = 335616925;
    bool PxRGzTLd = false;

    for (int bgAeer = 1349908652; bgAeer > 0; bgAeer--) {
        aKXdYYGVNaaGdlV = aKXdYYGVNaaGdlV;
        Sxajv = ! KnXvWEnVrrGwJ;
        aKXdYYGVNaaGdlV /= aKXdYYGVNaaGdlV;
    }

    for (int YckMbgl = 1967165099; YckMbgl > 0; YckMbgl--) {
        KnXvWEnVrrGwJ = gTSEqJ;
    }

    if (YqRyOle == 335616925) {
        for (int vQuyTr = 1320204066; vQuyTr > 0; vQuyTr--) {
            gTSEqJ = gTSEqJ;
            PxRGzTLd = ! wkkSZtUWRDncLlHw;
        }
    }

    for (int inYXjyIqeopln = 104212964; inYXjyIqeopln > 0; inYXjyIqeopln--) {
        yzQEqXb = yzQEqXb;
        aKXdYYGVNaaGdlV /= YqRyOle;
        YqRyOle *= NDdWKdQr;
    }

    for (int eehdRsqt = 1832246795; eehdRsqt > 0; eehdRsqt--) {
        YqRyOle += aKXdYYGVNaaGdlV;
    }

    return ThfMBzLTtf;
}

string AHdMTiXmL::ZQQneh(string VDxCUpKCI)
{
    bool aypfxjKcvQH = false;
    double mQFSRcjsuAnji = -794229.417990165;
    int ssVXIVQBzdZ = -565049106;
    bool yZcyuyliDQpWnpme = false;
    int HyzlEwzfAyoiDyw = 9713190;
    bool nbyGzsladgEa = true;
    double greLOVujNQ = -567667.1052605624;
    string CydqiguxAaf = string("wfkwvqZejWUPEjGaYdKvqzGKnBPklgTqIxfZtYCFTBiXZNSWFcaDikvTHatEbeVFzWzIuXyxAmauZlBaEiwTVLZoEDPPCWjyzrkrNaIUvCePijqovTJQIsl");

    for (int xwbzzkPpWkAXfTMM = 616001510; xwbzzkPpWkAXfTMM > 0; xwbzzkPpWkAXfTMM--) {
        continue;
    }

    for (int BStwKNsdeAX = 1910372343; BStwKNsdeAX > 0; BStwKNsdeAX--) {
        aypfxjKcvQH = yZcyuyliDQpWnpme;
    }

    return CydqiguxAaf;
}

AHdMTiXmL::AHdMTiXmL()
{
    this->ppMjDyY(true, -559336.8528923643, 916544.9780544084, -44886966, -451118887);
    this->pjJHh(string("IsWnSbvnSRZSJxSNnMShCQNFntxZuhqCmGqDQsaYzzevDbpQHNJJdrEcuCnYAKkLnlpFNdZUoWlSFgEpOrdQPRsMBSYd"), string("zIuFlkhKkoYGTRXOLMQYjidwwnIsIqdMfVdlmnUuydaabYKHicDMLbFFvoGOAkKJGhkolzTENnMhuYreL"), true, -225968385);
    this->xfADLMMWqM(true, 1194862993, 991112.6042886992);
    this->ZQQneh(string("QipzqdwrFyWKSFuoqsKhycZrbOvESFQBWIXkLtZcSWSBnLFnuoQoqFfaUVFFRtJphBfYuQPPNjrsojxehMLMXpfHzSLEkENiAKcCvWpXtRfDAFhyitXsjzmJQhyrnqAWFKarmMOmPJrwjCIgsGgpNeWOIWQaKZIrMSfqQXwujOpACWvoEKLooWTRHLBdjrIGLTnpZuoAJzLkuXzACUVcOOvuzBtUFvYRThVURzzSgllsiMxTmUlKl"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RTlQuWcrNM
{
public:
    double pcPsReGKmJKQY;
    string AetnOGpGMHolj;

    RTlQuWcrNM();
    bool jfBrLvdzhMNm(int KyoIgOU, int uTVMdyjRZ);
    double bmYYNbxy(double DdaSCJwqXqyWDoMd, bool nHRAl, bool gTewPtdu);
    void jrZcwm(string nbemvPBXHMi, string AwNavXZtfWd, bool XgjgdkiVNcWdkJBM, bool HbNkIdPmSs);
    string ZpnOhPGTLMC(string kYGpSalIuKlHgM, double esWjEVdacBZAv, double NVNaDVxDtyAde);
    int RjOOBqiIZ();
    string iqicwZHXPDHyUp(int vhIPRiHkwEvwYrWX, bool UmDZAkCDyKZp, bool npoAvHZizMFCGRg);
    string sOtkZnOebVUAaUY(double twvUh);
protected:
    int YQIyg;
    string MexjrNzC;
    bool nmKeaZhSaVFi;
    int tprcvw;
    int abfYvTGYjZSoq;

    double JgDpYrzHC(string gCgiGFpcgiB, int XbOmeEKpv, double sJJjAingSxlawuT);
    bool tdCKbtExSWi(double nhvKXdZFQLEkmwGF, string etLcSfqZwFD, double CzBgzGOzJL, bool bQMim, double OpAZwHQdJNA);
    string GIOXgXMtOs(string cAVHveKfctdWi, bool GBOQeuvoxEWc, bool vIzrFkuqyNfuue, string SFzrYyLPiLrgop, string VIDIZacUnfIOHe);
    void fnreipkpCtC(double xpBathBufx);
    bool gKAzapI(int tVPUjAVBH);
private:
    int acAfbHsjjjHj;
    bool YvGaCFvkzX;
    int nnbUmcbztGV;
    bool yOIyKtvGqV;

    string inkghczqDwo(bool EocLzYSApwLdrMjS, double eJiwuI, string xRinEhw);
    string PkLqzgFbOCPDzO(double DKbAjZGghfjQJ, double WFYowEeXglaoN);
    string RfYyc();
};

bool RTlQuWcrNM::jfBrLvdzhMNm(int KyoIgOU, int uTVMdyjRZ)
{
    double iUgjCxbiup = -961548.9003758234;
    double tZhauuUrc = 914319.3307864881;
    double imhhjFMmlZaRoEf = 39178.19808051456;
    bool dbQzqmibsA = true;
    bool rLiaaxqQUsKJb = true;
    string rNTJZUaP = string("HkUjXxFAMvATleNzARuflYshKdWzHecOmJzlrApOjOXaLbZEkHcQICfkWcaLEFPhqBJzcBvTovVcUWKXAiGicnJt");
    bool cxZuQhm = true;
    string CsmkSnnTpFherBBi = string("GPKMKUIhkLQzBlXJvGRridKytyRyFGrtAhPfWHbskqFvCTGxUSsLWxNaPUtWsztvItnQdFfIjciFkcmkeUoBipmrLwDMtZCVmLNvKjWGPqpQjRnkwXLJPXPlkwunSlURFvFfUbncMnE");
    string VBdOmatVAXOxNjB = string("GXxwTgDZbcrPkifcJNQooDzRZKQHVhYWtoMTgCCiXOPkKnMbRlIXhGiDXCBhQNOSQfZwDoPjlSOQAFqGaCeWKCpLTYViRwnJdKoIyjjcpjUQketkvBttQYBGfiqTUHKgUAkoykagxEbGwwqvVNcPIqCXgFrgfKEEnxGtFvw");
    int uITkrSfVsEwbVj = -427832529;

    if (dbQzqmibsA == true) {
        for (int AHCVOF = 3033595; AHCVOF > 0; AHCVOF--) {
            CsmkSnnTpFherBBi += VBdOmatVAXOxNjB;
        }
    }

    for (int tNuqjRIrqU = 457100136; tNuqjRIrqU > 0; tNuqjRIrqU--) {
        continue;
    }

    for (int vEALjzNqf = 1905310833; vEALjzNqf > 0; vEALjzNqf--) {
        tZhauuUrc -= imhhjFMmlZaRoEf;
    }

    return cxZuQhm;
}

double RTlQuWcrNM::bmYYNbxy(double DdaSCJwqXqyWDoMd, bool nHRAl, bool gTewPtdu)
{
    double LwhNQpkD = -133765.9856756726;
    int pbMyEW = -350290808;
    string EdCHmSKFgVt = string("vLaCtUEvzmvePZHPJYuIyVwTFzDpIwmmjCrDFwPfvKSwmhtTVNpvipLrVohrqiikBFseUhltTbVEuSVSMSLqnVUsoIIxMPHSJEmulojiwldVkkcAwPafdKpTSfioYSePZQVhnlhbOIOfyGmvcHbtiiJtsnvZkSydcRjrmjsDYyqZtyWcPoSjylHqdFzbeGLOOBtBBOoSGDQpQVQOwGpbsd");

    for (int dQUEukjDQqOcyza = 213721866; dQUEukjDQqOcyza > 0; dQUEukjDQqOcyza--) {
        LwhNQpkD += LwhNQpkD;
    }

    for (int KxDkZzFRhjiyJd = 1930134849; KxDkZzFRhjiyJd > 0; KxDkZzFRhjiyJd--) {
        gTewPtdu = gTewPtdu;
        DdaSCJwqXqyWDoMd = DdaSCJwqXqyWDoMd;
        DdaSCJwqXqyWDoMd = LwhNQpkD;
    }

    for (int ypZlgtJLsnNk = 1028436813; ypZlgtJLsnNk > 0; ypZlgtJLsnNk--) {
        gTewPtdu = gTewPtdu;
    }

    for (int oDWiHIVUzYRleSh = 1500330889; oDWiHIVUzYRleSh > 0; oDWiHIVUzYRleSh--) {
        DdaSCJwqXqyWDoMd /= DdaSCJwqXqyWDoMd;
        pbMyEW += pbMyEW;
        LwhNQpkD += LwhNQpkD;
        EdCHmSKFgVt = EdCHmSKFgVt;
    }

    if (nHRAl != true) {
        for (int RnhPS = 698965849; RnhPS > 0; RnhPS--) {
            continue;
        }
    }

    for (int wFtncWuNxV = 1867827261; wFtncWuNxV > 0; wFtncWuNxV--) {
        nHRAl = nHRAl;
    }

    for (int rqCqAHNkPUhMDIu = 762827763; rqCqAHNkPUhMDIu > 0; rqCqAHNkPUhMDIu--) {
        gTewPtdu = ! gTewPtdu;
    }

    return LwhNQpkD;
}

void RTlQuWcrNM::jrZcwm(string nbemvPBXHMi, string AwNavXZtfWd, bool XgjgdkiVNcWdkJBM, bool HbNkIdPmSs)
{
    int hkqksodyIsKpXRI = -1484845193;
    string qazCJmuHHOuLp = string("ymHFDFAHIkhCUBxLTbijyVWqRMnzvjhVVgzJKjjnTottXtOqZrPuKiJcpetPgpcemDsuIcrcxgFhmySZyIkhFHBSzzAVDeRqiFZuyDe");
    string mXjUSDjqIs = string("UXpeIFYpVgZdCiQIxTbBLkkxgAMqHxoprCGSOgEoeMHkDEyAwVAflJxLYkruDzkhyZnCMJtjcdmYYlmzFxncwS");
    string ucwZIhieKA = string("IMKqBmgXpbwYHUZRBFKVmQeyAiLSaSptxGCgwaBpYAIcgv");

    for (int IWefpvgMrBnHWp = 860872152; IWefpvgMrBnHWp > 0; IWefpvgMrBnHWp--) {
        ucwZIhieKA += ucwZIhieKA;
        HbNkIdPmSs = ! XgjgdkiVNcWdkJBM;
    }

    if (qazCJmuHHOuLp > string("KzdxmiyCFwFeHTuUfHkjTMMoLcNDiqtHFoWVOdDTvhboADMFgQnCxPizaokvaqIFzhESRUTpNBogWTTUDQIptjAGtKKhjwcEjNAKXFSbsNussFKmbLgfDjiNWmGVnPvaxFPFwdOgbfAsqdvchJsXaBCcJHxwzcfImohkwuXuYyFRaInRE")) {
        for (int IALQawfhwtMNWR = 1811149388; IALQawfhwtMNWR > 0; IALQawfhwtMNWR--) {
            mXjUSDjqIs += mXjUSDjqIs;
            ucwZIhieKA = ucwZIhieKA;
            AwNavXZtfWd += AwNavXZtfWd;
            AwNavXZtfWd = qazCJmuHHOuLp;
            nbemvPBXHMi = nbemvPBXHMi;
            AwNavXZtfWd += AwNavXZtfWd;
        }
    }

    for (int DXupKdfUyP = 1530461962; DXupKdfUyP > 0; DXupKdfUyP--) {
        ucwZIhieKA += mXjUSDjqIs;
        nbemvPBXHMi = mXjUSDjqIs;
        XgjgdkiVNcWdkJBM = ! XgjgdkiVNcWdkJBM;
        AwNavXZtfWd = mXjUSDjqIs;
        qazCJmuHHOuLp += ucwZIhieKA;
    }

    for (int usYNvBUhCwvijJxG = 170188400; usYNvBUhCwvijJxG > 0; usYNvBUhCwvijJxG--) {
        mXjUSDjqIs = nbemvPBXHMi;
    }
}

string RTlQuWcrNM::ZpnOhPGTLMC(string kYGpSalIuKlHgM, double esWjEVdacBZAv, double NVNaDVxDtyAde)
{
    string NfvdTRW = string("ZuWBsfYwYobySeeiKtZwfOMyFdiGgLjolrqoHQHGVRrsCefzWiiNChflQjpxjGoriAvXZdbsCcYuRfmWchyNPqDqqsOtSamFAoGQupUlzKdFfexmqtsCgoSaQoXKlGwpmLOfHWSWGLbtTSvqfsHZlYPgHuvHXAhsGopXEMOpNtQpWokoK");
    int sTvIGodpCQFkn = 1945854058;
    string zgSkImjTy = string("OTcJERvvIGgAqCasvyIbqSMmeQZAMUEE");
    bool nqzCtUO = false;
    bool bkLLRYWh = true;
    string HlMGG = string("fHpjZlhQxebULVnxlexYgEUYCafapAZabDsDRhJDCwVhjHfnKuvZERksfDcVNPOOEnwlDmXWRgdPGOFDSeIWYDlOyVeeSvfRzXMSlNFrckvOfysGgHXaYhWXycNYjiEWIZQTagCePMyPYWDXGZVHaEhiUDoNXkFwzMJSsgpPxTyzYfkpbFgsTjBPgdQZuFWRERxiEpZYRBczE");

    for (int NlPsYluvAEGe = 684655236; NlPsYluvAEGe > 0; NlPsYluvAEGe--) {
        esWjEVdacBZAv -= NVNaDVxDtyAde;
    }

    return HlMGG;
}

int RTlQuWcrNM::RjOOBqiIZ()
{
    int ATiDMQ = 246514294;
    double dfmDhWsfAxdAUC = 618381.5948560019;
    bool hMyyjNB = true;
    string oFVAVugja = string("lrVxVpeMWFwfuueDPxINMIPFqXMqzyKBgQsUGcAcYjyytQJtYTuLUYsmptSgOxUHISLEYsPVIGHoQyMletmDYDyVTRLactQKxvhGApFUzdEUfHkwjOHMMkmkwWdGOVkdoeYrlGMzdxyRTFDSGOetGVCCPsPjDDRNViWWCxdxQIwIjnRvLRyzYTJKyBUInrzXQlfmNUAaPptuijgzvXjZZUCHCtIgIqRkCbrOXObSN");
    double EuNCpQopg = -869657.9236399046;
    int KsAOUfDNNQVWQLe = -1137479372;

    for (int hybecmUHsTSmG = 172020980; hybecmUHsTSmG > 0; hybecmUHsTSmG--) {
        KsAOUfDNNQVWQLe -= ATiDMQ;
        KsAOUfDNNQVWQLe /= KsAOUfDNNQVWQLe;
        EuNCpQopg /= dfmDhWsfAxdAUC;
    }

    if (EuNCpQopg > 618381.5948560019) {
        for (int vJMiJFehCZn = 1113756837; vJMiJFehCZn > 0; vJMiJFehCZn--) {
            ATiDMQ += KsAOUfDNNQVWQLe;
            dfmDhWsfAxdAUC += EuNCpQopg;
        }
    }

    return KsAOUfDNNQVWQLe;
}

string RTlQuWcrNM::iqicwZHXPDHyUp(int vhIPRiHkwEvwYrWX, bool UmDZAkCDyKZp, bool npoAvHZizMFCGRg)
{
    bool RlRytomFzqxvjNN = true;
    bool YDyumzd = true;
    bool dEKdEcKRPi = true;
    int xFvcisClLLTxsy = 1706660615;
    bool BbrblJkVKhmUcc = false;
    double OxcvfT = -367063.9076945208;

    for (int xSEKqfE = 1463512430; xSEKqfE > 0; xSEKqfE--) {
        npoAvHZizMFCGRg = npoAvHZizMFCGRg;
    }

    for (int gMFpJH = 1538402053; gMFpJH > 0; gMFpJH--) {
        BbrblJkVKhmUcc = ! YDyumzd;
        xFvcisClLLTxsy *= xFvcisClLLTxsy;
        YDyumzd = dEKdEcKRPi;
        YDyumzd = ! npoAvHZizMFCGRg;
        npoAvHZizMFCGRg = ! YDyumzd;
    }

    return string("yLbZnoXAnjIspOTMAetQBppUlnNvZOmqzABOoVDuywhMVDlTTwNuuWUmemiaNZnHLjYgHJaeAuQkQoYONfVKCuXGCPOMYBhZWDypJPPChOkrliqfCXZrVKIBjHXToHSaTWmhjYISLxIzziqbuocwbXnljyKtGamNrxwaacbvkIEgnqHXKOGjYWWvXrsWgcrmsuaWBElMfDXlN");
}

string RTlQuWcrNM::sOtkZnOebVUAaUY(double twvUh)
{
    bool Qawzq = false;
    double prxllLsxuuyi = -326369.05166542396;
    bool IkLHYZiIBIY = false;
    double DeaXLpgg = -720892.9681427078;
    bool pEOOfuNqZpvmn = true;
    double qzxBmzVpieu = -603822.5860900567;
    bool gLQzRf = false;
    bool TWhZgaY = false;
    string rkyHTUdhy = string("oSnVDBznHXGYmJzZnTivnyCRrZMptnIMGgCfiOlSSTOmeKQVuSFLCddoSgMYJVGWqFxtttRgRVZmUnDTADsShDLNcTeYOnSeIGoLaKXzjeSbnYssrOMAwJnTfUcVYfJWuuby");

    return rkyHTUdhy;
}

double RTlQuWcrNM::JgDpYrzHC(string gCgiGFpcgiB, int XbOmeEKpv, double sJJjAingSxlawuT)
{
    int vNjQgtQIrnZZNRHT = 641324174;
    string DNGcVVyCyu = string("ysvBbsXGHjfzvZvaOltCEOMCVBdZMLpftrfNfOjMbuXcycggboJzSyAPzyNAqQAIYkaKkmtvdUrgqWkwhKuPucMjTsZOykzEPhCeuYDQUeupfbMYOamiuzlRngvCixokaiHafEgipGWnSFoBSsjCUugbdHSozJbAZdrCorcHXncHFGFgzLIDVnRciVHsExxHmWmHarbXItMuHKiOgAgmwGcloEVCOMEtLd");
    bool wymMDVPLLtjNVN = false;
    int qWplJYADyAKUnlM = -1925244443;
    bool cDOdswzjtacc = false;
    bool JnmJFCsUFDDsn = false;
    bool WKDkUmZLroCXRxRz = false;

    return sJJjAingSxlawuT;
}

bool RTlQuWcrNM::tdCKbtExSWi(double nhvKXdZFQLEkmwGF, string etLcSfqZwFD, double CzBgzGOzJL, bool bQMim, double OpAZwHQdJNA)
{
    double TsItTw = -640248.5726615754;
    bool mMPGJUMwRyHXvH = false;
    double xevsPRLhmGsf = 460107.6277701608;
    double xjvWbX = 334544.16780157207;
    bool LXgVMQWMQyt = false;
    bool SdOYzWInglOwqCvL = false;
    double zLjmbcwFMsm = -175030.23990337813;

    if (CzBgzGOzJL == 403151.18113591097) {
        for (int RmVaJJNbKUAlyI = 1664961650; RmVaJJNbKUAlyI > 0; RmVaJJNbKUAlyI--) {
            xjvWbX += CzBgzGOzJL;
        }
    }

    return SdOYzWInglOwqCvL;
}

string RTlQuWcrNM::GIOXgXMtOs(string cAVHveKfctdWi, bool GBOQeuvoxEWc, bool vIzrFkuqyNfuue, string SFzrYyLPiLrgop, string VIDIZacUnfIOHe)
{
    double vHTyjpnH = 436538.04217838874;
    bool VkSvbfKWfUrYvDOD = false;

    for (int ZbZwGrDGw = 479587496; ZbZwGrDGw > 0; ZbZwGrDGw--) {
        SFzrYyLPiLrgop = SFzrYyLPiLrgop;
        vIzrFkuqyNfuue = VkSvbfKWfUrYvDOD;
        cAVHveKfctdWi = SFzrYyLPiLrgop;
    }

    if (cAVHveKfctdWi != string("GjmpAzGqNBvcZNHnaDhHJRwGOYKNgZDkFTsrEQXQVxPPpmLfjyImpErkAmyahmkfYGACyDd")) {
        for (int uoqyDqxX = 394483333; uoqyDqxX > 0; uoqyDqxX--) {
            VIDIZacUnfIOHe = SFzrYyLPiLrgop;
            SFzrYyLPiLrgop += SFzrYyLPiLrgop;
        }
    }

    for (int HJTOVuTqBgRPV = 141017432; HJTOVuTqBgRPV > 0; HJTOVuTqBgRPV--) {
        cAVHveKfctdWi = cAVHveKfctdWi;
    }

    if (SFzrYyLPiLrgop != string("MIKtqWAkCDYXtNfDFyAurJMxLgKRFqneVDmcUvJdacmNkOxSzcRPlWcyFmSpGiSGocBpPSoIHuNOnVPxWvJJwXpigRjxKpXVNaMNnjHRRWGKGJIYtYgQoCjiMjLHzhmNgaGraZNhzuXYCeDPfHdYgnWVswduwRrJKvHDgQgFIiqtcGPpzvCkZfRmwUcUsDjAzofNPnToKCxnkcJSpgOKLFYRqz")) {
        for (int NQLuUgugtQm = 1523324099; NQLuUgugtQm > 0; NQLuUgugtQm--) {
            cAVHveKfctdWi = VIDIZacUnfIOHe;
        }
    }

    for (int yKoTZvno = 1377532542; yKoTZvno > 0; yKoTZvno--) {
        VkSvbfKWfUrYvDOD = VkSvbfKWfUrYvDOD;
        SFzrYyLPiLrgop += VIDIZacUnfIOHe;
        VkSvbfKWfUrYvDOD = VkSvbfKWfUrYvDOD;
        cAVHveKfctdWi = SFzrYyLPiLrgop;
        VkSvbfKWfUrYvDOD = ! GBOQeuvoxEWc;
    }

    return VIDIZacUnfIOHe;
}

void RTlQuWcrNM::fnreipkpCtC(double xpBathBufx)
{
    string ouJIIGxdmANsbSEL = string("bFTweBhZYTAyhtRUmlWHesgWlhhKShgfZmLQBMviBPOQMiCgvLEcGrkRBKCtngMrlNAmYxzVA");
    double cGMayI = -802566.3899089663;
    double bhpfVlDtykwBXDIs = -563910.5891385095;
    double yGGnimxHeNLns = 554045.2649928196;
    string vyqWKPEKh = string("CEyCqqGQIAVoHVWPKAhAkhzSmYcinuVqVQPeMzUJBapIpGIakZQtyrWTAadmYKQNyFizJIUrebcyoxwCQKUpXcngYeQsnxlShpnLSPvAABvlKyqmTIHOPWLpoUEHKLFyrDjYlRBfjOArlFwwamnatRccsNAGZgqtodfwNuKUiIrSwSFosevLGrxUTeKUJrRoFaRHmuRAr");
    bool GhkzEAT = false;
    bool gLiaoAqlKO = false;
    string xXRjACbGAa = string("mDfTNIOeQMqFmfXUJCMrZHcKSUJRbEtcaHwdVhxqlxgKZQuNtiIwOyurZNiYUeTbOlUQEppxJYOAvJjFTGJphOVdzGZlEAPTbeYVyKCwEaAwcMgYHOYSxHIJSSdXWIoCKFlOTiKkpfLcaxlWsttszrwhuCeBFKACIsDwfiudUVGvabHOuPYbBvjYeqyUqvpaogEknwnfxTRz");
    string yLdXxscl = string("PSDnsmyBbioOJcOHbAiACTEUIPTtEjzbGSQYMsKPHvOhDBdvtzjROyHdsNPLFOzZVOufoxhpaPnnNUQVfGGKnRWYdzPputYIeNpULxhK");
    int BRruvI = 1140655477;

    for (int fHcLXeelIaL = 2052619687; fHcLXeelIaL > 0; fHcLXeelIaL--) {
        cGMayI *= xpBathBufx;
    }

    for (int xabcBsiHGLcASL = 628186627; xabcBsiHGLcASL > 0; xabcBsiHGLcASL--) {
        ouJIIGxdmANsbSEL = ouJIIGxdmANsbSEL;
        cGMayI *= bhpfVlDtykwBXDIs;
    }

    for (int CpqwvZjmbtWbw = 575829354; CpqwvZjmbtWbw > 0; CpqwvZjmbtWbw--) {
        GhkzEAT = GhkzEAT;
    }

    for (int aHTNBUhqZSsAbNx = 596288055; aHTNBUhqZSsAbNx > 0; aHTNBUhqZSsAbNx--) {
        yLdXxscl += vyqWKPEKh;
    }
}

bool RTlQuWcrNM::gKAzapI(int tVPUjAVBH)
{
    string HSfafSssSyiJRnsX = string("EoqHNUVWDNXolgdAhCyYdrCVSihESXOFieidHlHYwrALWevjnBRlsSIUXHoYCALieFJyfwVppnnyWksRfxcaTxrkVcGdOVKcvoXekAtXePgGXYtcewdrwjaVFAQJWcZFmYztOCOaneSkeocWptxdPMSnalMbwhQOOzsUtvmUBJGHnQhwzVLSSJmJCtXHVBUedCZiowTgNRNQMYsijbywnKNizJPktbO");
    bool FzwsPpbGR = false;
    bool nGTQUMtU = true;
    int UbpEVqTUuqjfkQ = -1077676594;
    double BYFGWS = 930896.3219810559;
    string gfgOzzhjN = string("RQTJoVZicKCojNDzVOElPHmJbvhbOjDqAjaqWCphBtyHKNkVeNtcpvgGukwfUhLYARiyqwEZEyxxwtdAGoPxqQrKTbvuCDNUrYhAaWskbzyVMrCStPnDMuRkLpJsshUAgRxZOqibTJd");
    int gVCdHTMFTquZMmOV = 708090205;
    int BpVBNmS = -269259398;
    string DJcuhuC = string("poolApirJwrxRFPPtHIhWL");

    for (int pPdoQknhvtEtTs = 21416008; pPdoQknhvtEtTs > 0; pPdoQknhvtEtTs--) {
        nGTQUMtU = nGTQUMtU;
        HSfafSssSyiJRnsX = HSfafSssSyiJRnsX;
        gVCdHTMFTquZMmOV *= BpVBNmS;
    }

    for (int ISzrhI = 1472465930; ISzrhI > 0; ISzrhI--) {
        nGTQUMtU = ! nGTQUMtU;
        nGTQUMtU = ! nGTQUMtU;
        tVPUjAVBH *= gVCdHTMFTquZMmOV;
        UbpEVqTUuqjfkQ -= tVPUjAVBH;
        gVCdHTMFTquZMmOV += gVCdHTMFTquZMmOV;
    }

    for (int rqLcVP = 2070438977; rqLcVP > 0; rqLcVP--) {
        BpVBNmS /= gVCdHTMFTquZMmOV;
        DJcuhuC = gfgOzzhjN;
    }

    if (UbpEVqTUuqjfkQ == 731011993) {
        for (int BMQsh = 210189803; BMQsh > 0; BMQsh--) {
            continue;
        }
    }

    for (int rJVZYtYzEhvwFT = 379381635; rJVZYtYzEhvwFT > 0; rJVZYtYzEhvwFT--) {
        gVCdHTMFTquZMmOV -= tVPUjAVBH;
        tVPUjAVBH += gVCdHTMFTquZMmOV;
        BpVBNmS += gVCdHTMFTquZMmOV;
    }

    for (int PWHtMGM = 1664986062; PWHtMGM > 0; PWHtMGM--) {
        nGTQUMtU = nGTQUMtU;
    }

    for (int ROSaV = 650348973; ROSaV > 0; ROSaV--) {
        gVCdHTMFTquZMmOV = UbpEVqTUuqjfkQ;
        UbpEVqTUuqjfkQ = BpVBNmS;
    }

    return nGTQUMtU;
}

string RTlQuWcrNM::inkghczqDwo(bool EocLzYSApwLdrMjS, double eJiwuI, string xRinEhw)
{
    bool jzAYGa = true;
    string WPbKcsViHcDiz = string("HABQAptnEjeBcNEebLCShlEpXxrqhPFNZOrkOKuGqfZPTWEBSaymCPpvVCoMmBAksaYMmBKHhyDvxjIewYLiRczAlDKh");
    int JsUnMGHolLmJ = 462144583;
    bool mClOjTs = false;
    string juSGvX = string("WMPSDrNKyTXyqTmQdoJoRAh");

    if (mClOjTs != true) {
        for (int iLmKtHKtQXv = 579404579; iLmKtHKtQXv > 0; iLmKtHKtQXv--) {
            jzAYGa = EocLzYSApwLdrMjS;
        }
    }

    if (WPbKcsViHcDiz >= string("WMPSDrNKyTXyqTmQdoJoRAh")) {
        for (int LlBmEClI = 2053350828; LlBmEClI > 0; LlBmEClI--) {
            continue;
        }
    }

    for (int RMcPhhWQqQCneC = 892294585; RMcPhhWQqQCneC > 0; RMcPhhWQqQCneC--) {
        continue;
    }

    return juSGvX;
}

string RTlQuWcrNM::PkLqzgFbOCPDzO(double DKbAjZGghfjQJ, double WFYowEeXglaoN)
{
    bool eQARHxL = true;
    bool xxSgdoiiw = true;
    bool uGpvWMzohTiT = true;
    string gRUaqUtNcC = string("FQXShnvpdKZNufCmdTimFWKnaPFeiQKfduRxJVdnrFRSMHTPgyYGHeqAcbTdGQKNIHcnsiAuiRGvVCRqPZvPeoceasnSyhLMAxRldoYsZaNWcnNeGFHTDVTNZAHuIEUSNggKAbJWkZwZitmUcgrPNEVoiup");

    for (int QaPNRuYwWZD = 308186952; QaPNRuYwWZD > 0; QaPNRuYwWZD--) {
        eQARHxL = ! eQARHxL;
    }

    for (int QxLnzqpeBlG = 511907984; QxLnzqpeBlG > 0; QxLnzqpeBlG--) {
        continue;
    }

    for (int pojgn = 1766756860; pojgn > 0; pojgn--) {
        WFYowEeXglaoN += WFYowEeXglaoN;
    }

    for (int sBPOg = 408377471; sBPOg > 0; sBPOg--) {
        uGpvWMzohTiT = ! xxSgdoiiw;
    }

    if (uGpvWMzohTiT != true) {
        for (int wSCTapHHm = 2070441859; wSCTapHHm > 0; wSCTapHHm--) {
            gRUaqUtNcC += gRUaqUtNcC;
            xxSgdoiiw = ! eQARHxL;
            xxSgdoiiw = xxSgdoiiw;
        }
    }

    for (int HJvlUhpvjkeYWg = 197182559; HJvlUhpvjkeYWg > 0; HJvlUhpvjkeYWg--) {
        xxSgdoiiw = ! uGpvWMzohTiT;
        DKbAjZGghfjQJ -= WFYowEeXglaoN;
        uGpvWMzohTiT = ! xxSgdoiiw;
    }

    if (eQARHxL != true) {
        for (int qUuwemIlnXpWh = 1570800170; qUuwemIlnXpWh > 0; qUuwemIlnXpWh--) {
            DKbAjZGghfjQJ += DKbAjZGghfjQJ;
            xxSgdoiiw = uGpvWMzohTiT;
            eQARHxL = uGpvWMzohTiT;
        }
    }

    return gRUaqUtNcC;
}

string RTlQuWcrNM::RfYyc()
{
    double qjXhtRwVrJkj = 606022.0479390826;
    int NcrUMeRev = -1689747287;

    if (NcrUMeRev >= -1689747287) {
        for (int sEmTEcqrRtWumoDI = 1454193219; sEmTEcqrRtWumoDI > 0; sEmTEcqrRtWumoDI--) {
            qjXhtRwVrJkj /= qjXhtRwVrJkj;
            qjXhtRwVrJkj = qjXhtRwVrJkj;
        }
    }

    for (int ebjNdez = 1794848131; ebjNdez > 0; ebjNdez--) {
        qjXhtRwVrJkj /= qjXhtRwVrJkj;
    }

    for (int SRJWND = 1491266646; SRJWND > 0; SRJWND--) {
        NcrUMeRev /= NcrUMeRev;
        NcrUMeRev = NcrUMeRev;
        qjXhtRwVrJkj *= qjXhtRwVrJkj;
        qjXhtRwVrJkj -= qjXhtRwVrJkj;
    }

    return string("EXysMXyBhEWQtdrYwPBQvgsgiusqMgQhTQelghEGYgOBtIGQrDXuXjclCEoUBJmcxjqaiuvaKlZSATaalQONQcMtqSrJkCXGAMSRgxgFcKenyYvygWkkhBlLSEQTSOInhRAOvHNiVNSeAWEHlZQYnGTONqQNeNKVoAbpATFbpnloIuizaNRwjIGbDozsgosjlnNRUJERFOEyTZlmehRAmibeqtQbJuTqigwfCfLx");
}

RTlQuWcrNM::RTlQuWcrNM()
{
    this->jfBrLvdzhMNm(-1778151726, -346434372);
    this->bmYYNbxy(934519.1005031758, true, false);
    this->jrZcwm(string("fSboGRdckIXOCSOIEMkmuyUhykjxKblCysvaZvSVCETNCsEROWrrxTsoDJDECaUBzXoQHhRhiiqCOHJAvbAXTvjwBvEUrPBDCsGSOjqJQjczfwMvoXpiFfPNdFFlankZOdKrpXAlXFJgikXuPNhNDGAJKEzdiJZiGsfAesaVIplPXCRgMRSUOAzBlUtkmMgbHcWKdPVgHIUOD"), string("KzdxmiyCFwFeHTuUfHkjTMMoLcNDiqtHFoWVOdDTvhboADMFgQnCxPizaokvaqIFzhESRUTpNBogWTTUDQIptjAGtKKhjwcEjNAKXFSbsNussFKmbLgfDjiNWmGVnPvaxFPFwdOgbfAsqdvchJsXaBCcJHxwzcfImohkwuXuYyFRaInRE"), true, false);
    this->ZpnOhPGTLMC(string("IGtvQekrZmtoQoIBIIfKeurneZouKRqWDSQzgtWIbLirPMpJpfpzCguZyGU"), -478610.4896422635, 614367.8716257421);
    this->RjOOBqiIZ();
    this->iqicwZHXPDHyUp(-541418851, false, false);
    this->sOtkZnOebVUAaUY(-1010420.1359477437);
    this->JgDpYrzHC(string("tzghLLXKpTiwzkOXqaQvJHjLEziPjkkJlbmfXwamhWhtgLgbKHOCMYQtuXjpIJLRPUBOCXLAyHslFcHSrHDibeMjHyYfbJUTewgbWxCpitUwGjnPPFyOiQUwGuTsqyuGzNHLwysGPPkdejAepbVWYHLwuGfRCWopxhlDwDDsqKlDsjEnlBOGaHxwkhBjwlZrITWKfyFjBuzzRucyoipXFGawbcqLjAplhugcbgCMwcAeGlYjkFaXvBpLnyIj"), 1992110689, 40224.73757545995);
    this->tdCKbtExSWi(448557.04489025805, string("UKATycnsGjuwNxRMdWgLaGeIlBWWAxYWcSZpZKOWGHlcRBHQoKmEnjOBoOOwIkwIAaQpPDsCiFkPyZZzHQRJXRKnHZysCerMZkRnkFHAwcGtwWlXuZSzklkSJSGawqRCTVU"), 403151.18113591097, false, 441806.92777235893);
    this->GIOXgXMtOs(string("MIKtqWAkCDYXtNfDFyAurJMxLgKRFqneVDmcUvJdacmNkOxSzcRPlWcyFmSpGiSGocBpPSoIHuNOnVPxWvJJwXpigRjxKpXVNaMNnjHRRWGKGJIYtYgQoCjiMjLHzhmNgaGraZNhzuXYCeDPfHdYgnWVswduwRrJKvHDgQgFIiqtcGPpzvCkZfRmwUcUsDjAzofNPnToKCxnkcJSpgOKLFYRqz"), false, false, string("GjmpAzGqNBvcZNHnaDhHJRwGOYKNgZDkFTsrEQXQVxPPpmLfjyImpErkAmyahmkfYGACyDd"), string("mDgCnXzLtRUULqlUZKdvWLzuiaddydaWkSDnEdQtoCnZZryQTVfKytmPqIcUjbxQziqBYqFFxnOYrWZPijbuOursuJCHsxJDjyrdmrYkJLuddyIHXcCcMqaYzwpndHzKnDkPzhqwfQPiImKIMKVOuQyVbxkisHrwEjkmMRjeOQq"));
    this->fnreipkpCtC(785373.4130593362);
    this->gKAzapI(731011993);
    this->inkghczqDwo(true, 275812.44886229926, string("YnnkyttGsuCyssYjCgSlcHHJXnVqeFMXEOBvaOLENntQSkeJcMMggMfSCe"));
    this->PkLqzgFbOCPDzO(283766.8383904939, 543873.3587456025);
    this->RfYyc();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lkdWet
{
public:
    int oAnOvQjfPMaiubYm;
    int wBjwGiWZyreWY;
    string GrjDAmiBxZzlHDFW;
    int heQASDoGRP;
    string RrUCTDNa;

    lkdWet();
    void IfwhAppCSrgeAyG(double mLzLWqCXozHhZB, bool KpyFaS);
    bool cFzggroZzjjR(string sWrHjZRjkgertS, double uceuNlgnQxwjT, string TsMzNI, double yvdxbujbJnnj, int qJmQCrHRUuDq);
    void kTAEDHdOCozFuYeI(string GmVdbBavhSpjxk, string LzIZNRrZaZnmZ, int kXSsonPivVUM, string gyrGSNkZRvXKkAA);
protected:
    int wIhjK;
    double GMOaVULQ;
    bool VaYXVAo;
    int RXVPFv;
    double zCfLdcRDeiKcKjfI;
    bool PHRAKnbz;

    int LSmwmKMRVCQCyJC();
private:
    int jraBRGaIAQ;
    string CKdkBAzT;
    double JLZKIeomrxyolsz;
    bool emcck;
    string EOGHbKo;
    int plGGTtFVKCYtz;

    string bMktalxBEsy(string xBJtMsqGEhWgO);
    string bLKYdabTdPI();
    string IsRAyNMAhSnPad(string YqnjVNrnDy, bool EPsBdlDaweGHp);
};

void lkdWet::IfwhAppCSrgeAyG(double mLzLWqCXozHhZB, bool KpyFaS)
{
    bool jiCiapcYHvhQkSj = true;
    double NfNXvYsCvskG = 323869.38619320694;
    string eYYCeZlzQyT = string("cawkFsTBqFHmsqueyqmyeUFwfRPJaVykgjiUbwLBCUHyXYYKYtqoPhuTxDZJErCLLAFchsDICVYkDXoYZQysmSjTOYiAspkIzxgxdLHBDIUvAKRXmwnHQBDyuBAZTkKolTFNVecpUTrPuuEEfQzpTibscvlqvBHHangSuJVygHwPGQxXINnpUDWNlMGiFAQIMEOTkIDxCbhDHJVaWRauXzLBcUHZcRWwsZiFILEhbgeBcdhuipUrfvBzDRkxnY");
    int relXRQjeesWIbDSR = 1862914050;

    for (int WqzDmtapQ = 1585056619; WqzDmtapQ > 0; WqzDmtapQ--) {
        mLzLWqCXozHhZB -= NfNXvYsCvskG;
        jiCiapcYHvhQkSj = jiCiapcYHvhQkSj;
        eYYCeZlzQyT = eYYCeZlzQyT;
    }

    for (int zMZkJ = 2003826969; zMZkJ > 0; zMZkJ--) {
        continue;
    }

    for (int djXOjiXscIbh = 1589465802; djXOjiXscIbh > 0; djXOjiXscIbh--) {
        KpyFaS = ! jiCiapcYHvhQkSj;
        NfNXvYsCvskG = NfNXvYsCvskG;
    }

    for (int VMSXTQes = 2043621285; VMSXTQes > 0; VMSXTQes--) {
        continue;
    }

    for (int dtcApNLMSvxfixFf = 1189757939; dtcApNLMSvxfixFf > 0; dtcApNLMSvxfixFf--) {
        mLzLWqCXozHhZB += mLzLWqCXozHhZB;
    }

    for (int sFHtQarZYeHPkwD = 2055365007; sFHtQarZYeHPkwD > 0; sFHtQarZYeHPkwD--) {
        jiCiapcYHvhQkSj = ! KpyFaS;
        NfNXvYsCvskG = NfNXvYsCvskG;
    }

    if (mLzLWqCXozHhZB <= 822622.6907998653) {
        for (int QdwwTyqkrFhO = 130622648; QdwwTyqkrFhO > 0; QdwwTyqkrFhO--) {
            NfNXvYsCvskG /= mLzLWqCXozHhZB;
            relXRQjeesWIbDSR -= relXRQjeesWIbDSR;
        }
    }

    if (jiCiapcYHvhQkSj == true) {
        for (int uKBtUEWAvuknjKL = 1015312730; uKBtUEWAvuknjKL > 0; uKBtUEWAvuknjKL--) {
            NfNXvYsCvskG /= mLzLWqCXozHhZB;
            jiCiapcYHvhQkSj = KpyFaS;
        }
    }
}

bool lkdWet::cFzggroZzjjR(string sWrHjZRjkgertS, double uceuNlgnQxwjT, string TsMzNI, double yvdxbujbJnnj, int qJmQCrHRUuDq)
{
    bool uSnVaYUBjbL = false;
    string iufsDqduyXv = string("cbmdGhpexHBgiZHJbEdUXj");
    double FBPMPcfmsJz = 622556.518875003;
    int Xwlgrgpf = 200135400;
    int kVcGIbGxsoCEMv = 1829310636;
    string CUPiksktY = string("RJAjsuSaxnFbSKVJTsPFtGMdQaBYJXvBhBHKXFguC");
    double hSYmKubXVTmOBZzu = -684307.6195664263;
    bool OnptHgucNAnZ = false;
    double tttNQ = -333261.87946183566;
    bool CswUzAehwCyJ = true;

    for (int hpTDTcNy = 191014318; hpTDTcNy > 0; hpTDTcNy--) {
        continue;
    }

    for (int dsQbMn = 2092145679; dsQbMn > 0; dsQbMn--) {
        kVcGIbGxsoCEMv += Xwlgrgpf;
        qJmQCrHRUuDq -= Xwlgrgpf;
        tttNQ /= hSYmKubXVTmOBZzu;
    }

    return CswUzAehwCyJ;
}

void lkdWet::kTAEDHdOCozFuYeI(string GmVdbBavhSpjxk, string LzIZNRrZaZnmZ, int kXSsonPivVUM, string gyrGSNkZRvXKkAA)
{
    int OfryauOPtPUoVoD = 716339392;
    int WSnBwsuZBnEMCRm = -1178786273;

    if (OfryauOPtPUoVoD >= -1178786273) {
        for (int oiWHFEoULfS = 1054727840; oiWHFEoULfS > 0; oiWHFEoULfS--) {
            kXSsonPivVUM += kXSsonPivVUM;
            LzIZNRrZaZnmZ = LzIZNRrZaZnmZ;
            OfryauOPtPUoVoD -= OfryauOPtPUoVoD;
            kXSsonPivVUM += OfryauOPtPUoVoD;
            gyrGSNkZRvXKkAA += GmVdbBavhSpjxk;
            GmVdbBavhSpjxk = GmVdbBavhSpjxk;
            LzIZNRrZaZnmZ = GmVdbBavhSpjxk;
        }
    }

    if (GmVdbBavhSpjxk >= string("lZwntKszvzAJyLOPugCGWsHklogiigf")) {
        for (int ALXYliYV = 934433386; ALXYliYV > 0; ALXYliYV--) {
            OfryauOPtPUoVoD -= kXSsonPivVUM;
            LzIZNRrZaZnmZ += GmVdbBavhSpjxk;
            kXSsonPivVUM -= WSnBwsuZBnEMCRm;
            OfryauOPtPUoVoD *= OfryauOPtPUoVoD;
        }
    }

    if (GmVdbBavhSpjxk == string("lZwntKszvzAJyLOPugCGWsHklogiigf")) {
        for (int EuAVIXLcft = 517402788; EuAVIXLcft > 0; EuAVIXLcft--) {
            kXSsonPivVUM -= WSnBwsuZBnEMCRm;
            OfryauOPtPUoVoD = WSnBwsuZBnEMCRm;
            WSnBwsuZBnEMCRm -= OfryauOPtPUoVoD;
            kXSsonPivVUM = OfryauOPtPUoVoD;
            gyrGSNkZRvXKkAA += gyrGSNkZRvXKkAA;
            OfryauOPtPUoVoD -= OfryauOPtPUoVoD;
            OfryauOPtPUoVoD -= kXSsonPivVUM;
            OfryauOPtPUoVoD /= OfryauOPtPUoVoD;
        }
    }

    for (int jHKcYzASzqgcgZ = 634533217; jHKcYzASzqgcgZ > 0; jHKcYzASzqgcgZ--) {
        gyrGSNkZRvXKkAA += gyrGSNkZRvXKkAA;
        gyrGSNkZRvXKkAA = LzIZNRrZaZnmZ;
        kXSsonPivVUM = WSnBwsuZBnEMCRm;
        kXSsonPivVUM /= WSnBwsuZBnEMCRm;
        kXSsonPivVUM += kXSsonPivVUM;
    }

    for (int BVwteHfCyLCgq = 1250725948; BVwteHfCyLCgq > 0; BVwteHfCyLCgq--) {
        LzIZNRrZaZnmZ = gyrGSNkZRvXKkAA;
        kXSsonPivVUM += OfryauOPtPUoVoD;
        WSnBwsuZBnEMCRm = WSnBwsuZBnEMCRm;
        GmVdbBavhSpjxk = LzIZNRrZaZnmZ;
        gyrGSNkZRvXKkAA += LzIZNRrZaZnmZ;
    }
}

int lkdWet::LSmwmKMRVCQCyJC()
{
    string jmGTJsMKbdeTYvo = string("LkZUPXfkKBJLnhkqEorWpfaMIKHRpkcnqdRZRcnXsXPlrPTvKlcGhzyhASubtooEfdIfZgmwMzEZseBpJzyoMtSwacJCqcrCdUPMFjUoVhnHjGuvdlIXPIvwoOZlVnzQYuSpVSPIghearUzvkZEriNxxknzGXWRLblNqZaHxOiIKRfoRTJAPqJdLrdoxDCghnknZzFeuoaSvjYEFjLJRpAvSFlNEUZiqfOSwJZxBAgLdwKKMiPYNVyngndIg");
    string AJgKouxGXUC = string("rEycbyFRHdosKUNOEObagGZPNRRRZKeMtWDiRVbYfJZpGTusdvXAP");

    if (AJgKouxGXUC != string("LkZUPXfkKBJLnhkqEorWpfaMIKHRpkcnqdRZRcnXsXPlrPTvKlcGhzyhASubtooEfdIfZgmwMzEZseBpJzyoMtSwacJCqcrCdUPMFjUoVhnHjGuvdlIXPIvwoOZlVnzQYuSpVSPIghearUzvkZEriNxxknzGXWRLblNqZaHxOiIKRfoRTJAPqJdLrdoxDCghnknZzFeuoaSvjYEFjLJRpAvSFlNEUZiqfOSwJZxBAgLdwKKMiPYNVyngndIg")) {
        for (int LgIRr = 1724528597; LgIRr > 0; LgIRr--) {
            AJgKouxGXUC = jmGTJsMKbdeTYvo;
        }
    }

    if (AJgKouxGXUC > string("rEycbyFRHdosKUNOEObagGZPNRRRZKeMtWDiRVbYfJZpGTusdvXAP")) {
        for (int catBtDXJLv = 25878979; catBtDXJLv > 0; catBtDXJLv--) {
            jmGTJsMKbdeTYvo = AJgKouxGXUC;
            jmGTJsMKbdeTYvo = AJgKouxGXUC;
            jmGTJsMKbdeTYvo += AJgKouxGXUC;
            jmGTJsMKbdeTYvo += jmGTJsMKbdeTYvo;
            AJgKouxGXUC = AJgKouxGXUC;
            AJgKouxGXUC += jmGTJsMKbdeTYvo;
            jmGTJsMKbdeTYvo += AJgKouxGXUC;
            jmGTJsMKbdeTYvo += AJgKouxGXUC;
        }
    }

    return -1634016249;
}

string lkdWet::bMktalxBEsy(string xBJtMsqGEhWgO)
{
    double zKEHYVZFgSgJMc = 691933.1763600304;
    bool xhKGG = true;

    for (int PNFwz = 797694198; PNFwz > 0; PNFwz--) {
        continue;
    }

    for (int XMaEUZCRcFvCkY = 487826754; XMaEUZCRcFvCkY > 0; XMaEUZCRcFvCkY--) {
        xhKGG = xhKGG;
        xBJtMsqGEhWgO += xBJtMsqGEhWgO;
        zKEHYVZFgSgJMc /= zKEHYVZFgSgJMc;
        xhKGG = ! xhKGG;
    }

    if (zKEHYVZFgSgJMc == 691933.1763600304) {
        for (int iTsTfedh = 1401343613; iTsTfedh > 0; iTsTfedh--) {
            xBJtMsqGEhWgO = xBJtMsqGEhWgO;
        }
    }

    if (xhKGG != true) {
        for (int leNPEG = 1220785011; leNPEG > 0; leNPEG--) {
            xhKGG = ! xhKGG;
            xhKGG = ! xhKGG;
        }
    }

    for (int cQDmxe = 840831293; cQDmxe > 0; cQDmxe--) {
        xBJtMsqGEhWgO += xBJtMsqGEhWgO;
        xBJtMsqGEhWgO = xBJtMsqGEhWgO;
    }

    return xBJtMsqGEhWgO;
}

string lkdWet::bLKYdabTdPI()
{
    int esAjGfyPoJuOoOI = 136573511;
    string mkNbWuA = string("KRgJOsWFkbxKgi");
    double DlZsHiUzAXC = 496911.0058345505;
    string yWWLzeCqRxGczw = string("NbnJKBGdFzEhTRZpoIPJeYFUUwqbvTvJSToLKwIBKLybDOGxTVkWAQSWqJVZVoUNbFUNKtYPaFKOhsQNrNjwwHcjzWfhFtRRPdxbzGBQaHIubekNZDGIfnwvsHogmtBKyEnvjQGjocBolRypGnFsEbMBFUnBMCOURBVuWKge");
    int fzNkrEQQtc = -1707539142;

    return yWWLzeCqRxGczw;
}

string lkdWet::IsRAyNMAhSnPad(string YqnjVNrnDy, bool EPsBdlDaweGHp)
{
    bool mFpgabGIyzDf = true;

    for (int xMLRThMnleoNA = 1094223305; xMLRThMnleoNA > 0; xMLRThMnleoNA--) {
        mFpgabGIyzDf = mFpgabGIyzDf;
    }

    for (int XQPRIW = 180727129; XQPRIW > 0; XQPRIW--) {
        mFpgabGIyzDf = ! EPsBdlDaweGHp;
        YqnjVNrnDy += YqnjVNrnDy;
    }

    for (int boyaGCBS = 285763387; boyaGCBS > 0; boyaGCBS--) {
        mFpgabGIyzDf = ! mFpgabGIyzDf;
    }

    return YqnjVNrnDy;
}

lkdWet::lkdWet()
{
    this->IfwhAppCSrgeAyG(822622.6907998653, true);
    this->cFzggroZzjjR(string("OMzjrhFDaixPWEYxkM"), -569908.2677399478, string("WCwqBFJGnEqTFrGqTjMspRafeuTtQZhmFofDvMEeaqsEztSSfKJBUbL"), -996634.573225648, 115408329);
    this->kTAEDHdOCozFuYeI(string("JvAwFiNwEsTdwioGDneaRqKXxjpYCphepQpXIlcfedXIBdrlfpxKt"), string("lZwntKszvzAJyLOPugCGWsHklogiigf"), 593020540, string("cUatofRIcUQRmXoILNCFunqKQlzrVPuu"));
    this->LSmwmKMRVCQCyJC();
    this->bMktalxBEsy(string("jpjuALnZGpbEQsFJOSnCSttahKhnflarjVRvsLoRlscLiTsgzUFggBwWXXIEUpqRMWpKxANVIfHetbojNokcEvSMOdLvMLmkBdTjzNrfpZchvJoxHWHdhFZiHwLYowRtzKJSWiiZuvCatxXIWpdnSMIMEMFCVPyJiVhJuaBoBPHIspaFSTVTQuDAbOllPWLoMOrGFlmGoIjrWuxExBrGowpHSQQzaUhOSmkSaDG"));
    this->bLKYdabTdPI();
    this->IsRAyNMAhSnPad(string("yzotBWUNxqKuvviFseXenzbikfskpivITzjYqqXbiPBcUoCFdWaheObriZTOpQUjTNbCCVpSzTFCtAxjHGBMGVXkX"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eJFZXuHNi
{
public:
    int pOeCZuBiNWRwkRPv;
    int xXvvxNsIJHMtD;
    int NXXcBca;
    bool KvrKfMsSP;
    double BBRERBxCQV;
    string rQrkNELCdqyHu;

    eJFZXuHNi();
protected:
    int hbYsdK;
    double satvyqsiqyHUnlZI;

    bool oNyIjyjjHdQIYcvj(string sASvBLDueyIE, string WgStxUqKcpbSrmPF);
    bool khZDNrBBkLw(int YWxKmVTajL, double jauoULQhZFXqzAPM, int NLkHGpxrKBqe, int easxSWhJqDVz, bool LFvTbs);
    bool qUpcdsjVvxZ(bool mfSUbz);
    string lYZNZYEZ(string ymqeLbPdKblhT, int KzWJbx, string EPuwwl);
    double WKsxenOfVrCjYqN(int UpbGjAONIbCDj);
private:
    bool BOSYB;
    bool HfJZpNiLMjZERez;
    string TNHrpoiVGCsnmKIw;
    int dbwVsDuibBz;

    string DAQbTPRyjNoqt(double jRoTM, int neDkRf);
    double NbvOdnwYKExVW(string gVvJM, bool oLNKNWOqzzI, string KsHOEAHCXQYdLv, int AZpwBhobXUtW);
    bool qyXkxx(double xpSriamfmRM);
};

bool eJFZXuHNi::oNyIjyjjHdQIYcvj(string sASvBLDueyIE, string WgStxUqKcpbSrmPF)
{
    double wYmsobFnuNsQIt = -785957.3055664538;
    string oqVOLcJt = string("GLwWxhfLgLssbIWoYnolfoPoTchPuUhmKUAwdwAdhFQQJEXs");
    double YltYAtbNfuiwv = 1037857.7310767317;
    double EYDZSmjQrPUYUEA = 118164.82379463017;
    bool vZchv = false;
    bool TIvgRLYYStPhXW = false;
    string bCBXdfzoRSu = string("xYdbfcuzASHbbaSVPGgklQQLVOOwDCwWHFDbqlXUaNNyKMmUSagtGnffuSKYDHBgmpfKImIOuXpnYBvoqhipJFqoEdlcsPvMZMESUwxiEQijdFjvQDGQUqWSQPBjRXMlvIQytBGBhGczAhISnOCGRbgOloWvaTDKFeoojwbFtYhVSVuJILFMlxZZRhvRLWRegVoHxDODPuipovvKjPjcGfiAGnIyINpWCxiHDyHonNSJKOeHdQUblKrgrNGYp");
    string ZmzpuzeQKpcspvdV = string("OJVtcciUNkGBtZi");
    string JaduzFCG = string("XAbLGzwGbYkypxpewRdxNDOOddbzgySVBbwTSudccuVtJapcjpTkJwASDgTfBVhbzpOGIYSWZGszazSxNQloghXWhXrIBdbQpzZyLlRQzGpryiXdpeItTRCcKreeODUmSdjjJhcNacjCaYGZUNObACUAtbaVdhQVbGfXqVtXBrghjdKhTQAQhXLtudRduOm");
    bool UPISlZYUGmIYmXZ = false;

    for (int yHujEUKu = 1257520171; yHujEUKu > 0; yHujEUKu--) {
        oqVOLcJt = JaduzFCG;
        JaduzFCG = bCBXdfzoRSu;
    }

    for (int TUOHFUhQkj = 1710573837; TUOHFUhQkj > 0; TUOHFUhQkj--) {
        oqVOLcJt = sASvBLDueyIE;
        TIvgRLYYStPhXW = vZchv;
        bCBXdfzoRSu += WgStxUqKcpbSrmPF;
        sASvBLDueyIE = oqVOLcJt;
        WgStxUqKcpbSrmPF = WgStxUqKcpbSrmPF;
    }

    return UPISlZYUGmIYmXZ;
}

bool eJFZXuHNi::khZDNrBBkLw(int YWxKmVTajL, double jauoULQhZFXqzAPM, int NLkHGpxrKBqe, int easxSWhJqDVz, bool LFvTbs)
{
    double LhBgBxawuFmCNDVW = 542874.4287184515;
    double FFFCnRjAI = -539551.4839262922;
    double DFCGHvGxqhRJOV = 630227.1654291579;
    int TveLcEmHeXKEw = 523732442;
    bool jZepNnnCeNB = false;
    bool XVRFhNAKSZbr = true;

    if (XVRFhNAKSZbr == true) {
        for (int uvUxXnvRqFLiA = 120128657; uvUxXnvRqFLiA > 0; uvUxXnvRqFLiA--) {
            easxSWhJqDVz *= YWxKmVTajL;
            easxSWhJqDVz += easxSWhJqDVz;
        }
    }

    for (int igBgDJTFsbIQUawM = 284428783; igBgDJTFsbIQUawM > 0; igBgDJTFsbIQUawM--) {
        NLkHGpxrKBqe += TveLcEmHeXKEw;
        DFCGHvGxqhRJOV *= FFFCnRjAI;
        jZepNnnCeNB = ! LFvTbs;
        LhBgBxawuFmCNDVW = LhBgBxawuFmCNDVW;
    }

    return XVRFhNAKSZbr;
}

bool eJFZXuHNi::qUpcdsjVvxZ(bool mfSUbz)
{
    int yYXKJyGhsyfx = 1537867450;
    double PaWiIcud = -564035.1247435322;
    bool vhdGfddvO = false;
    bool DDcWTNNIt = false;
    string fBVFtSCpFMAfTseV = string("LbnbXaIJShrwrwhadWWcudwcxzUIVQReslmQgG");
    string lFbwSL = string("IUDcgUkRzNWamiPEWdvtfgrYFkcmAYXiYNgyBZsCEggjvOSxrKzaQNJdGbu");
    int zKgMPLn = -1702970263;
    bool JeNXLA = false;

    for (int eSExTCqKulwEA = 1632039452; eSExTCqKulwEA > 0; eSExTCqKulwEA--) {
        continue;
    }

    if (JeNXLA == false) {
        for (int eBODOCCQagkONUP = 416534392; eBODOCCQagkONUP > 0; eBODOCCQagkONUP--) {
            yYXKJyGhsyfx -= zKgMPLn;
            zKgMPLn *= zKgMPLn;
        }
    }

    return JeNXLA;
}

string eJFZXuHNi::lYZNZYEZ(string ymqeLbPdKblhT, int KzWJbx, string EPuwwl)
{
    double rIJYbQreUWYUxwYo = -857242.7585544026;
    double btVEQRvbzkImE = -567033.1270462866;
    string XOdTksjumhtfeDa = string("uMghDDJFRroqjMzzhMkfxdvdeFRSCquFvLYRrOTAJmFPdBmydmtdWKhuuzHzwsHxBpbLUbVevOInmBbcDnAsnMjaiFAQMdDKVCzvJdUlcHIDkogLrKVJPIRADeYvqfADeJFfKegS");
    double CLLfnx = -473894.17493844935;
    bool rpqMOicAwuTOrV = false;
    string DhbJdUAGvtR = string("iDNLoWMrItHpgvoLUPtKOLKFEATWNkPvDnxzmeFgzXVzgVMNSpmMRAEhANtPawoJQocSjakNmnpYRimCKjUWsAtkOLRGJErhOGgOLUcFPMXqtSUtAxJgpDsEQMBKFEgdKdLFUXUwAFWnXbku");
    double KQrevNT = 777459.875333089;
    bool tjLya = false;
    string WMLvwvxDWdrihn = string("QpamMGRayhlcHLaWZpOFWgXMUlHJoakBWcUCJcgIYWcxjBfIQVMsunlzwTyIhJMZWbcoMzajPiOlBiihZuElQStWcmFrGiIJjIUeQIbQIvNLPahBCBfIjTdaEEOwbBQppSmWeUxERBQxiSQuzXCfwQyHnqKWFWQVZUZPQuzreKQmDgcVAsbTkxNrZWgXU");

    for (int POuItlPkOpTc = 993454343; POuItlPkOpTc > 0; POuItlPkOpTc--) {
        ymqeLbPdKblhT += EPuwwl;
    }

    return WMLvwvxDWdrihn;
}

double eJFZXuHNi::WKsxenOfVrCjYqN(int UpbGjAONIbCDj)
{
    double vPkkYgugr = -947641.238076184;
    bool aOJHBTlHwUpqAU = false;
    bool orhutSZgqjH = true;
    bool ZByGLSmOi = true;
    double ikKOufrfp = -661861.2038283048;
    string TIFPu = string("ThSjyNCRXemsCBbiCxXfENHTohFFCUsbSMUTKuRaupMByfKPQXQptSSnNaZMBQSWqzaDLFbweBkcFdOgXQahtwfMNhbSxtOIYYQGpNF");
    bool okOlCyxOw = false;

    for (int FyoCTFI = 1182445576; FyoCTFI > 0; FyoCTFI--) {
        okOlCyxOw = ! aOJHBTlHwUpqAU;
        aOJHBTlHwUpqAU = orhutSZgqjH;
        okOlCyxOw = ! okOlCyxOw;
        okOlCyxOw = ! okOlCyxOw;
    }

    for (int DPgxD = 1777280312; DPgxD > 0; DPgxD--) {
        ZByGLSmOi = okOlCyxOw;
        UpbGjAONIbCDj = UpbGjAONIbCDj;
    }

    for (int qlcvKkRLbD = 895660458; qlcvKkRLbD > 0; qlcvKkRLbD--) {
        ZByGLSmOi = ! orhutSZgqjH;
        orhutSZgqjH = orhutSZgqjH;
    }

    if (aOJHBTlHwUpqAU == true) {
        for (int fbjmvtcZIFXJVRYh = 315757885; fbjmvtcZIFXJVRYh > 0; fbjmvtcZIFXJVRYh--) {
            ikKOufrfp *= vPkkYgugr;
            TIFPu = TIFPu;
            vPkkYgugr = ikKOufrfp;
        }
    }

    for (int FjyKxHaw = 606632749; FjyKxHaw > 0; FjyKxHaw--) {
        aOJHBTlHwUpqAU = ZByGLSmOi;
        ikKOufrfp += ikKOufrfp;
    }

    for (int fINaIW = 1608062446; fINaIW > 0; fINaIW--) {
        UpbGjAONIbCDj = UpbGjAONIbCDj;
        ZByGLSmOi = ! aOJHBTlHwUpqAU;
        aOJHBTlHwUpqAU = aOJHBTlHwUpqAU;
    }

    for (int BfeHoHv = 1337117326; BfeHoHv > 0; BfeHoHv--) {
        ZByGLSmOi = ! orhutSZgqjH;
        ZByGLSmOi = ! aOJHBTlHwUpqAU;
        orhutSZgqjH = ! aOJHBTlHwUpqAU;
    }

    return ikKOufrfp;
}

string eJFZXuHNi::DAQbTPRyjNoqt(double jRoTM, int neDkRf)
{
    int ZSKKSCrKLt = 1274715380;
    string IPpqEMKVz = string("rrKRpUNFRYjkNHLyqqfJmVjXnFCkgWJUiAoJTZMRpjlcLJVsHSZUmDjwoJqFhxwpCVGdLhqo");
    int YNuSACXUfzURF = 1306797926;
    double jvbbqcfsEGYRM = -24035.06170253752;
    bool RzbaGdcUl = false;
    bool HzahmRmCKesPzP = false;
    string dzBhKZTvP = string("xVANGYQQfWwSKUkriRNVyHQKutCvcSIYOgZiqOcoCKyPEOtniRqmpopfODPqY");

    for (int KEIwmglMHgLVnZdP = 1213696869; KEIwmglMHgLVnZdP > 0; KEIwmglMHgLVnZdP--) {
        IPpqEMKVz += IPpqEMKVz;
        YNuSACXUfzURF -= ZSKKSCrKLt;
    }

    for (int ebJlUad = 1003576076; ebJlUad > 0; ebJlUad--) {
        neDkRf -= YNuSACXUfzURF;
    }

    for (int PjiUeBVQUOeKQMV = 1576213760; PjiUeBVQUOeKQMV > 0; PjiUeBVQUOeKQMV--) {
        IPpqEMKVz = dzBhKZTvP;
    }

    return dzBhKZTvP;
}

double eJFZXuHNi::NbvOdnwYKExVW(string gVvJM, bool oLNKNWOqzzI, string KsHOEAHCXQYdLv, int AZpwBhobXUtW)
{
    bool Cgpbj = true;
    int UYAFPbTUbUzgkuzh = 226379812;
    int DYizsyO = -1028289945;
    bool hJTumwjdTvLKv = false;
    double yAHfLLBWDWU = -230819.37026450425;

    for (int CfapA = 797532432; CfapA > 0; CfapA--) {
        hJTumwjdTvLKv = oLNKNWOqzzI;
        AZpwBhobXUtW += AZpwBhobXUtW;
        Cgpbj = ! hJTumwjdTvLKv;
    }

    if (Cgpbj == false) {
        for (int lweXHYodW = 1536202579; lweXHYodW > 0; lweXHYodW--) {
            AZpwBhobXUtW = AZpwBhobXUtW;
            UYAFPbTUbUzgkuzh = UYAFPbTUbUzgkuzh;
        }
    }

    for (int akirpIzm = 983975096; akirpIzm > 0; akirpIzm--) {
        AZpwBhobXUtW += UYAFPbTUbUzgkuzh;
        UYAFPbTUbUzgkuzh /= UYAFPbTUbUzgkuzh;
        oLNKNWOqzzI = Cgpbj;
    }

    return yAHfLLBWDWU;
}

bool eJFZXuHNi::qyXkxx(double xpSriamfmRM)
{
    bool cCnCNZbe = false;
    double NrztEYTj = 67600.30113689792;
    double CrBIkxdzEaYZw = -868777.9793754248;

    if (NrztEYTj <= 172577.5090896261) {
        for (int LNNBQOdtRMLaN = 292412392; LNNBQOdtRMLaN > 0; LNNBQOdtRMLaN--) {
            NrztEYTj -= xpSriamfmRM;
            NrztEYTj = xpSriamfmRM;
            NrztEYTj += xpSriamfmRM;
        }
    }

    if (xpSriamfmRM < 172577.5090896261) {
        for (int fSpfZaXudPeOqdJU = 854573075; fSpfZaXudPeOqdJU > 0; fSpfZaXudPeOqdJU--) {
            continue;
        }
    }

    return cCnCNZbe;
}

eJFZXuHNi::eJFZXuHNi()
{
    this->oNyIjyjjHdQIYcvj(string("TAeEVRWTtBZaOswgUJNjhGZfVwSkxCWaHlJfloTsfOjVzTFfEUFjewMsJQ"), string("UPxvChWUYTBRhQHdrIugYsfdDkzUyfsXymnXUkNjSTfEWUZPpTBTJZyhfKDQoNJvguUvtAWkYFOFGWBMurbVdLPTmDtpFKFKiWmaHTFsBP"));
    this->khZDNrBBkLw(462119230, -53611.39475039249, 1458186, 376489678, true);
    this->qUpcdsjVvxZ(false);
    this->lYZNZYEZ(string("rxLXqSdcjvhaNzBAIfuABOtdBATLkwSBGTCDhnUHCPBh"), -1815097775, string("pqKBLWaGIFHqvdslQTaiMWjzfdebfbNGxdIrQzFmiMCGKscYXmghSdCbIuBKErPVZqOtxpxoqg"));
    this->WKsxenOfVrCjYqN(-80820647);
    this->DAQbTPRyjNoqt(872407.2206749241, -1872075262);
    this->NbvOdnwYKExVW(string("GQkugnazSGWbTsZfitBzDnSBxiHTnNpURMjFGakapSAXVFgDRkQqvsZTcEtgPzexnOiJredpMgSyojromsQKLkZMGQHavSQXEqEddRxHUmBPLPmIUviUUFxxbOIfMUObLFhZjTYcXFbIpWEgrVZWskkDhaUOwbajocNEumEqzdHKCUiN"), true, string("oaEWqhkfdZtHdPCzUhfKYXjbJdwwcTxbHfTQCqZjTmpf"), 2138228429);
    this->qyXkxx(172577.5090896261);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class klgps
{
public:
    bool XmtJlyWurCTDfyg;
    bool cwerYp;
    bool QiKnhTA;

    klgps();
    bool rGCPsKWiHjs(string vpGiEjryZsyH, string RjAwRGFtiWjNW);
    int UKUKv(double dcNgwlENWf, double OByLmMHvZwqaKsf, double EbHrjKjridx, bool PdhqxPXvV, double kKGqVQgYF);
    int agzYuUHldVl(double RCgnKmlaOtt);
    bool VlsRffRMGQ(bool FAYwCTQSHd, int duaMZa);
    bool vjHjUdHlPRd(bool BzezZPL, string zHHBcluRBSIifz, double jXXdFjaCvnMfVXt);
    string HlSfECcnpPPmqNl(int bsZyOKRnB);
    void avJXTzwvmCJVJX();
    string Zzusmz();
protected:
    int VyYNhosGjliqbjoL;
    bool ugRuwnuJ;
    bool QDlpqEY;
    bool GDhahyFroaeJtzF;
    string vGvCYNrzK;

    void BvkLoKZst(double HodhbpI, int zLJJlwe, string zDddqEpV);
    void JCTsBTqeADscq();
    int ViwEHSHPrHd(string WuRerwRiVlaoT);
    string urrrrQGaaYxEr(double YPhEeSgtSt, int SEfqihKoLQq, int IDyPlzfjhDkWvIn, int cbvRlp);
    double EGDoUeQq();
    string qLCYZrcZrAyQz(int uiiEmtlhNRatKYYZ);
private:
    bool DWZsFOXuab;
    int GjMqibzewskTlMOk;

    int tuqdlGwaCsPLRZux();
    string zAzaRIbRDQlu(bool amAmVtZTdMHO);
    void KYqTbFu(string CjwEWilCD, double dRmYkCBjSVvlhu, bool ZFfXmVLcbtSeRjT, string FZQcaFyd, string vTGYA);
};

bool klgps::rGCPsKWiHjs(string vpGiEjryZsyH, string RjAwRGFtiWjNW)
{
    string bNXxKXsMXC = string("XboDgXiMSOMbAaQSPubYxsSAPJGsKvdJhUbOzqHeBmdLvKeB");
    int PCJjzyuackk = 578083206;
    double msDWlNTF = -659891.6468800984;
    string JPIevHLCJJE = string("TynejVEGBRocCyOmQPsAytATOtlyUhlgRWQFlBkQZJgjXaHpAPCDMfVK");
    int YmXwob = 2061251064;
    int VemoUouzNZ = 1319542203;
    string HfcxqtbYdBu = string("yTWbYfQafXZievWMnemkTmvFlgiAyRQhWpEKlNLEiWZERHBtCwQpQcBwvvQkjarHZszjTNjaUutVqszPxwAtdJIqGIAmjcPCtJYTOznPkpGyBIYynMfpiDkeoLzGsjdqkmQBQAqILMlyJdXgWmOnwXlzmmRyQXAiyJLpaldhZCONRHhvZMtQXfEXZoIShlckZYxWPFLRopycbswllKkHmoXjCYUXCYOFDQFxgYVSOBSkiNdBTdtRJfYhFAh");

    return false;
}

int klgps::UKUKv(double dcNgwlENWf, double OByLmMHvZwqaKsf, double EbHrjKjridx, bool PdhqxPXvV, double kKGqVQgYF)
{
    double hpHQrHV = -459148.5236795266;
    bool cWTNYsgja = false;
    bool bktbSw = true;
    int jdNeFLUclQsua = -546472871;
    bool CFAfwnuMCcFbulJ = true;

    for (int UnJYlbAY = 1504658311; UnJYlbAY > 0; UnJYlbAY--) {
        PdhqxPXvV = ! CFAfwnuMCcFbulJ;
        EbHrjKjridx *= dcNgwlENWf;
    }

    if (hpHQrHV < -716156.7284237911) {
        for (int KkmiV = 822853592; KkmiV > 0; KkmiV--) {
            continue;
        }
    }

    for (int DogcodFz = 1614228652; DogcodFz > 0; DogcodFz--) {
        OByLmMHvZwqaKsf *= kKGqVQgYF;
        CFAfwnuMCcFbulJ = ! bktbSw;
    }

    for (int oXenfsl = 1962545747; oXenfsl > 0; oXenfsl--) {
        bktbSw = PdhqxPXvV;
        OByLmMHvZwqaKsf *= OByLmMHvZwqaKsf;
    }

    return jdNeFLUclQsua;
}

int klgps::agzYuUHldVl(double RCgnKmlaOtt)
{
    int ueUlf = -467179786;
    int MZVSKnbxn = 1024136479;

    if (ueUlf <= -467179786) {
        for (int tnzCWjgtEI = 194649472; tnzCWjgtEI > 0; tnzCWjgtEI--) {
            RCgnKmlaOtt /= RCgnKmlaOtt;
        }
    }

    if (MZVSKnbxn > 1024136479) {
        for (int xrmWYck = 554118665; xrmWYck > 0; xrmWYck--) {
            MZVSKnbxn -= MZVSKnbxn;
            ueUlf += ueUlf;
            ueUlf -= ueUlf;
            MZVSKnbxn /= ueUlf;
        }
    }

    for (int fryprLnqfpAosg = 1363415014; fryprLnqfpAosg > 0; fryprLnqfpAosg--) {
        ueUlf /= MZVSKnbxn;
        ueUlf -= MZVSKnbxn;
        ueUlf += ueUlf;
        MZVSKnbxn = ueUlf;
        ueUlf /= ueUlf;
    }

    if (ueUlf >= 1024136479) {
        for (int cDHdLBGLRX = 990864529; cDHdLBGLRX > 0; cDHdLBGLRX--) {
            MZVSKnbxn /= MZVSKnbxn;
        }
    }

    if (ueUlf >= -467179786) {
        for (int nBRynplhVGTgwud = 1202188970; nBRynplhVGTgwud > 0; nBRynplhVGTgwud--) {
            RCgnKmlaOtt /= RCgnKmlaOtt;
        }
    }

    return MZVSKnbxn;
}

bool klgps::VlsRffRMGQ(bool FAYwCTQSHd, int duaMZa)
{
    bool NPFJwLgJSDut = true;
    string JYkOUKHPAzQq = string("yPlgGKSuBtQHZIGXJjWYWxxgxTuGKfuXItssgpzsKrWmxVlJkOUUwKQaMbJdUonYFwmGHlsgJsoUPPPmwNmPmFFpNfMVOOXjGvTcxUQgGQIXexrzDQKhyJKPZwfiMiYWWHVjFIcfscdmxKb");
    string NaFACYwfjE = string("RzQEzthigxLKlZclzktuJAKHvEQnGMXIptDouQBkbqFJaIqCoPejuqtjwprDBVntOeUmsbLybmLXvtasqmGINXXGcOsWtzMwNcyjkoxdOGGpyGXAmgCwhdDpKQWSfAEclHWuQMSECtIAImxcpFLBjSYpSPzWNKDCcinnCFuDOChitqLynAuHekhTfzAczWikV");
    bool yEqCYe = false;
    string TSuYBv = string("pABZfvEQegvxLLKldCHoPgatXdZksLSXILNIi");
    double fEOEJXsVzVVN = -987422.5475191635;
    double WDpahe = 37582.41348046058;
    double lXzxyer = 299951.79339878086;
    string ybtmALVmFUdOSgZ = string("CrRwqYoYRjTPyoFOIOwrVcPToGzdscJTbEPdAnXLvzAKQNoOOPbBZtpKdLbpXsgQW");

    if (TSuYBv < string("pABZfvEQegvxLLKldCHoPgatXdZksLSXILNIi")) {
        for (int hvEBJkbMwBFp = 849655980; hvEBJkbMwBFp > 0; hvEBJkbMwBFp--) {
            FAYwCTQSHd = ! yEqCYe;
            TSuYBv += ybtmALVmFUdOSgZ;
            NPFJwLgJSDut = ! FAYwCTQSHd;
            TSuYBv += JYkOUKHPAzQq;
        }
    }

    return yEqCYe;
}

bool klgps::vjHjUdHlPRd(bool BzezZPL, string zHHBcluRBSIifz, double jXXdFjaCvnMfVXt)
{
    bool wPUcuCdg = false;
    bool yGNbPwhaLBMRCf = true;
    double EFGRNEkZudBGT = -314157.57806653227;

    for (int UeEAKxS = 1747760759; UeEAKxS > 0; UeEAKxS--) {
        continue;
    }

    if (zHHBcluRBSIifz <= string("FBneMqgvsfRCxFgiiPABTwMdeTcCXGyiBeyiuoDYJZuXzgCwlGiKpxQVjbwcAYLWLShHGTGmWKkVZZFciMaRdnNiOUbLHxovUfJtskiJrWoLkBhOKKIIMGIKSHXTBnfiDRAvdqlMEboCxKsGCXuKruLmNyXPgTfoSFyGqIJkAclVSgQfoVFisOsCoJuJReyFDKBWZMvdtxYUHBcUMQtanfoMsanXfCmWnqDHASVoqxdIlVRcubrvX")) {
        for (int yUfnshDuOLwliApr = 224086571; yUfnshDuOLwliApr > 0; yUfnshDuOLwliApr--) {
            zHHBcluRBSIifz += zHHBcluRBSIifz;
        }
    }

    return yGNbPwhaLBMRCf;
}

string klgps::HlSfECcnpPPmqNl(int bsZyOKRnB)
{
    double xdIQbsYFtIRVs = -547512.760654953;
    bool rRAFlM = false;
    int HnOfVimEoe = 921334261;
    int EbBtQifxjIX = -573890220;

    if (bsZyOKRnB >= -573890220) {
        for (int ceHxl = 612458646; ceHxl > 0; ceHxl--) {
            bsZyOKRnB *= HnOfVimEoe;
            HnOfVimEoe -= bsZyOKRnB;
            HnOfVimEoe = bsZyOKRnB;
            HnOfVimEoe *= HnOfVimEoe;
        }
    }

    if (HnOfVimEoe >= -573890220) {
        for (int aJAUaFBatG = 963774268; aJAUaFBatG > 0; aJAUaFBatG--) {
            EbBtQifxjIX += HnOfVimEoe;
            EbBtQifxjIX *= HnOfVimEoe;
        }
    }

    for (int XoFyrgUbZNwgortr = 1449422102; XoFyrgUbZNwgortr > 0; XoFyrgUbZNwgortr--) {
        bsZyOKRnB = bsZyOKRnB;
        EbBtQifxjIX /= HnOfVimEoe;
        EbBtQifxjIX /= EbBtQifxjIX;
    }

    for (int VUTOYpFglBrfsU = 218757598; VUTOYpFglBrfsU > 0; VUTOYpFglBrfsU--) {
        EbBtQifxjIX *= HnOfVimEoe;
    }

    if (EbBtQifxjIX >= 921334261) {
        for (int KlAgqtzhVRIA = 1244722174; KlAgqtzhVRIA > 0; KlAgqtzhVRIA--) {
            continue;
        }
    }

    if (EbBtQifxjIX >= 921334261) {
        for (int BXGkoLeQbFO = 1862190552; BXGkoLeQbFO > 0; BXGkoLeQbFO--) {
            xdIQbsYFtIRVs -= xdIQbsYFtIRVs;
            HnOfVimEoe += EbBtQifxjIX;
        }
    }

    if (xdIQbsYFtIRVs >= -547512.760654953) {
        for (int GRyzKtprXrUMyc = 475496319; GRyzKtprXrUMyc > 0; GRyzKtprXrUMyc--) {
            HnOfVimEoe *= bsZyOKRnB;
            xdIQbsYFtIRVs *= xdIQbsYFtIRVs;
            bsZyOKRnB += HnOfVimEoe;
            EbBtQifxjIX += EbBtQifxjIX;
            HnOfVimEoe /= HnOfVimEoe;
        }
    }

    return string("ZpNkSPGjfwkhXenHayRPEgDNJNlAThVkLTzpQCZrIKtTYumGKtZfObQYqiMoHo");
}

void klgps::avJXTzwvmCJVJX()
{
    int xPIhkMnFA = -1510821576;
    int ziVfNAGm = 281333184;
    double QoFRdgtLXkZfmaR = -371548.87126351387;
    double haqwxywpTGjeRD = 964155.3209012427;
    int wHFFftvsGZeJPf = -331085868;
    double kwZLdTGRCOMpaC = 393121.3764741959;
    string hhDxiZAPobRcowne = string("hXZMDmvpUVUiVGEYbURnsTJxWSxsllybaqOmlIJSYCbfgiqSwSUPYHHKkEzmJWtFcAqwGJXiYGJyzwcNmKoscc");
    int CAWhhQboGmNGfM = -542930520;

    for (int QCwmyLtFmS = 906992112; QCwmyLtFmS > 0; QCwmyLtFmS--) {
        haqwxywpTGjeRD = QoFRdgtLXkZfmaR;
        CAWhhQboGmNGfM = xPIhkMnFA;
        QoFRdgtLXkZfmaR += QoFRdgtLXkZfmaR;
    }

    if (CAWhhQboGmNGfM < -1510821576) {
        for (int aFwMJIyGlqiFzK = 669728834; aFwMJIyGlqiFzK > 0; aFwMJIyGlqiFzK--) {
            CAWhhQboGmNGfM /= xPIhkMnFA;
            xPIhkMnFA *= xPIhkMnFA;
        }
    }
}

string klgps::Zzusmz()
{
    double aVyYIm = 41673.32475650631;
    bool VBrNEgwBdQLScF = true;
    int XtGvaN = -1112002097;
    bool gwMTqaG = false;
    int xKRCWUXJypsYnK = 2055110267;
    string xNilcwYfJx = string("LKkFnjMgiMRuonLoqgnngwfvFDvYTCaKWIUJsIjNtwKHuhZgOGFwdzpdYahAXHwAhwmSuuPaHCKtZVwSKVviAvXFVIzCADYsp");
    bool YuldD = false;
    bool rHxJaRQwZzq = true;
    string KDtiTxvfKRZjL = string("yeJBMRHxueyHOmYeYxYbTtkpSVKnRKmBXKkLOnAkERXvNonrxuuEwQPDEPbPCtaTlXPXlscCDbDTyjfKWYIZmFKPNCvwpPLQDeoDGtldgPHMGvWdrGLCZjVlvyDwVLDpsCpAqjsgePgBOkUwlMmPyOkXFNztlPfpyybaFFhzTaEVuKxOlPrfajHjwFePMlriVfKZBFiXkEmLoStbe");
    int DcPjUY = 33066207;

    for (int eWVJiYv = 1051223872; eWVJiYv > 0; eWVJiYv--) {
        rHxJaRQwZzq = ! gwMTqaG;
    }

    if (DcPjUY > -1112002097) {
        for (int euYBwGSlbJhXHpE = 1610544167; euYBwGSlbJhXHpE > 0; euYBwGSlbJhXHpE--) {
            continue;
        }
    }

    if (rHxJaRQwZzq != true) {
        for (int kIMSgSAhPwcELt = 64747500; kIMSgSAhPwcELt > 0; kIMSgSAhPwcELt--) {
            gwMTqaG = YuldD;
        }
    }

    for (int pzMiCPDFwZvfLfjf = 2063554465; pzMiCPDFwZvfLfjf > 0; pzMiCPDFwZvfLfjf--) {
        YuldD = VBrNEgwBdQLScF;
    }

    return KDtiTxvfKRZjL;
}

void klgps::BvkLoKZst(double HodhbpI, int zLJJlwe, string zDddqEpV)
{
    bool DhCOFLeyZabEZsjR = true;
    string HgXWG = string("vvGrFhRQCicuespWiqiYUnDsxPYeVQfuGIarJQpaIIUXvYILFpgYtSHUgQjexwAZAMnSvlHAKdJANDJkcHqUYBSowGzIqeojmhGrEBFnERHakTbOOFXCuZuWVfLCFLdQuoBpzawPZUbEdgVgFgRGlfIJEbMXCStMrLeLbrurckflvWmKZykewkPOpxpLWgEgFAMrQSlkdvRqZZHlDrZdFDgtEqOmSMNNgRRKNqsSDgxbYVZVsWavQXrv");
    bool InWnns = true;
    string iayEZPjaZbvp = string("RHzSFTboQTtlIOoXodvRHyPgrjlfHAvepyzjOwDpfiDILfcoJFKapeyBOVTdZlzxJatoRjoNvAbFcujEFguXhBPxMnnYZAlyhvrxHXOiEPbWozTLNjjKEihiDIuaknFbiOhnWVMswkOTlTezLRSzILyhJmpIMIMIAhcAwphaEhfEcQsYWfJTEMrrozxrCpXJUZEfGRkteOUcmjEVBTzqdWuEZxFGYPaYReOlhvhaHGUNAr");
    int SuTSJnjRqDDjv = -1049385010;
    int hVYOUsSRPudFEV = 1799087139;
    int owcblqUc = -150243766;
    string IMOprMPDHIeD = string("BRPZmqBhcTwkUbEjbKdbCmHYCLtaDiAnNutHqTCTHXilybdnJQPPHERFFtjDbhdiXFHQenyLezXJGTPyCrzcIuMuDHktieKakNHUAYtqHIYYKCrfu");
    bool PAYJd = true;

    for (int Csxrb = 674967624; Csxrb > 0; Csxrb--) {
        IMOprMPDHIeD = iayEZPjaZbvp;
    }

    if (SuTSJnjRqDDjv <= -926482549) {
        for (int rqqQIZ = 1882022305; rqqQIZ > 0; rqqQIZ--) {
            zDddqEpV = iayEZPjaZbvp;
            iayEZPjaZbvp += IMOprMPDHIeD;
        }
    }
}

void klgps::JCTsBTqeADscq()
{
    string OntSoJSNidQa = string("FJDYdbrFmlRxIPPGzMlHgPPHFJgrujHGwwVuLrGOaTlUDJndBXA");
    int fcwWyHNSTONfYLmC = 635834362;
    int MdYuSMEZ = -1834596202;

    for (int vOkTdFUgjwJX = 1372858552; vOkTdFUgjwJX > 0; vOkTdFUgjwJX--) {
        OntSoJSNidQa += OntSoJSNidQa;
        fcwWyHNSTONfYLmC -= fcwWyHNSTONfYLmC;
        OntSoJSNidQa += OntSoJSNidQa;
    }
}

int klgps::ViwEHSHPrHd(string WuRerwRiVlaoT)
{
    double DPTUquB = -562653.054541107;
    string pXolWBL = string("pYNRqgAPNzGYnKzzBOYsjiAscjFY");
    double huikbaLjFw = -183353.20400537897;
    double zXnbH = -935117.4070754914;
    double EaOtROTimj = 754615.9902029646;

    if (WuRerwRiVlaoT != string("HKyQIcOxKOkpOIEsbszZnDOLnYLVhuwvENiliMZspSBrsqUrKqqSawYBIXkOOchVpInIYmtboPCqOeLbQEVNsaQlnduXXZsWaEiVkhqJDyjQGYAnXOgWoZBXPOqpzkbWNWtDvfRWCJakrFZjISUoOtcAGEoHNlQGxGPsqQLtnuEYZnfkPRdzsZVWytljsFFUzqAiuEYoLjjZsfGySsmMyhukQVWMLhzaAmTYIBPpkHyDDYRgaRQCSblXPLPvQI")) {
        for (int IbyrCOTGu = 53609956; IbyrCOTGu > 0; IbyrCOTGu--) {
            continue;
        }
    }

    return -914008561;
}

string klgps::urrrrQGaaYxEr(double YPhEeSgtSt, int SEfqihKoLQq, int IDyPlzfjhDkWvIn, int cbvRlp)
{
    double FPHfrE = 741516.1940511025;
    string lgumlLcgMEoagz = string("hqUaOahGukKNENfIWYwOGZEcvcikWATSmQMiwBWJnnYWGReSumpGdnEGckRNtMCQIyZlrnECAoLvXOocMEeqIYWzEKMFhjFakhzXztPbjoiUkoFpaOhDNoTKeCrExwsPGGUPV");
    string NDuERu = string("IFHHHqJFjaqzvDbRyiAKIAuiGTYxDQnzzTePoeAkquhvKsMDyXlcOpATdmvzNDlSXPwCZzyrDidDitIEixylkRpJBPIUChuKRWoNlyLQ");
    bool Qzbsiwo = false;

    for (int pyops = 1533768880; pyops > 0; pyops--) {
        continue;
    }

    for (int EIVdeBtaYSAhTkJ = 1408330533; EIVdeBtaYSAhTkJ > 0; EIVdeBtaYSAhTkJ--) {
        continue;
    }

    return NDuERu;
}

double klgps::EGDoUeQq()
{
    double ewptWMzG = -143986.78585289128;
    double OSeAZnEkTShNzDI = -1017086.919767588;
    int pidFGkgFhWxTk = -257167457;
    string bAqOaiydwvzSV = string("BuubwoXNsAkTAGGEFuKlJmFggiDjpxLzHOVEuwqpxBsgYYWLucWwemscvLuh");
    string HYZQgJzxCzda = string("wfoaYZHZecPyyUcwmPWSaumAdDpvEWqRMVKgCDpthgwWzUZWIArqkxuQXeGLRGeXpnQSwASxPhRBSLAvMVdSWBIEUxiJiKUHxrzjD");
    int iuQmWBcrID = -801727372;

    if (iuQmWBcrID > -801727372) {
        for (int hTnFRdnPuYRqTvSJ = 265418896; hTnFRdnPuYRqTvSJ > 0; hTnFRdnPuYRqTvSJ--) {
            iuQmWBcrID = pidFGkgFhWxTk;
            bAqOaiydwvzSV = HYZQgJzxCzda;
        }
    }

    for (int aLezbhNAUO = 102099801; aLezbhNAUO > 0; aLezbhNAUO--) {
        bAqOaiydwvzSV += HYZQgJzxCzda;
        bAqOaiydwvzSV = HYZQgJzxCzda;
    }

    return OSeAZnEkTShNzDI;
}

string klgps::qLCYZrcZrAyQz(int uiiEmtlhNRatKYYZ)
{
    bool EesqXCQJDArY = true;
    double pGCrWbbEwy = 192141.4756770509;
    bool FSsMXqOVndiNsNxl = false;
    double FzlPSeQY = 729083.027566302;
    int gnIKIEjWo = 1808575485;
    string LLkkL = string("htfwbVFCREvSMtRFLlZGgHHVGCdcwiDrbhotUFGuJckrTkMiKqtEdmcGIItAKWzCYzEmTtQkbIMhv");
    string HDEfZ = string("sxwcoXDvrrMtNWNjxPZcapDVuxpVSShkSUIwMNmlsNULfoQThPvqejtsDSAnBwkR");
    int yLSoUCAfwB = 1184242651;

    if (EesqXCQJDArY == false) {
        for (int LuoDn = 642185947; LuoDn > 0; LuoDn--) {
            FzlPSeQY += FzlPSeQY;
            LLkkL = LLkkL;
            uiiEmtlhNRatKYYZ = yLSoUCAfwB;
        }
    }

    for (int UGeBWwxga = 110192289; UGeBWwxga > 0; UGeBWwxga--) {
        pGCrWbbEwy = pGCrWbbEwy;
    }

    for (int PZnLilDm = 207067645; PZnLilDm > 0; PZnLilDm--) {
        FzlPSeQY /= FzlPSeQY;
        uiiEmtlhNRatKYYZ -= yLSoUCAfwB;
    }

    return HDEfZ;
}

int klgps::tuqdlGwaCsPLRZux()
{
    string gfAFlK = string("YvLKguLXwEvdabNvqWLOvBxsaJdUkOvhvtnhZgFamjcyESuNfvDwUUogpvzHVwDYVpfSvKEKrgDQorLHWOgXhraoFLinCKFYRzGARvuRxbAyrnXMwIVNuNVlqCWZrwNLdVpkAkvsuZzDCRcTmtKSBffGOdcNyxwCcoCkiLkdWLfYpMwadeBmnOUQhQgjfuTFmQFiTrjH");
    int QJownOvZzx = -302897300;
    bool HzYvSQxgERT = true;
    string VvDTCzMET = string("uvUZqGuVZXtqFYlkXSCOunYQJWeQRwwjvZkbdzXVprWDxolHQ");
    double joiaVeaFBThhubi = -45422.85421451582;
    int SwpxNmuL = -1990225131;
    int xXhwLZjfeXXmWVx = 1945707408;
    bool cFhwew = true;

    for (int AsnKOhiEuWzZV = 172141271; AsnKOhiEuWzZV > 0; AsnKOhiEuWzZV--) {
        continue;
    }

    for (int tGSgT = 959110307; tGSgT > 0; tGSgT--) {
        continue;
    }

    for (int gBiEKnYTyKOXdPb = 1081641248; gBiEKnYTyKOXdPb > 0; gBiEKnYTyKOXdPb--) {
        gfAFlK = gfAFlK;
    }

    return xXhwLZjfeXXmWVx;
}

string klgps::zAzaRIbRDQlu(bool amAmVtZTdMHO)
{
    double cKLDEDePWTWTR = 850999.9431860503;
    double yxYJhAbtwlGIJ = -401246.25237974135;
    double IQVSdsYUZJOkDLBL = 103251.55219355795;
    double xgqNKoW = -836692.5411430199;
    bool wEDRSEXdha = true;
    string JKtAdxOYyagcmgP = string("PfJSknbASprHpHhWcJxStmpzvrMFHDATYFLJKheWzaObVztkLCrjmvMZoHlrlvNBFJqwNmZhMbixDvPkdilyLOwoiBFJGsIvArzvCEgzTetinvisYBMJdWdiBzODKjqBqVyfNXovchLqxCdklmtdRoMPVnIExVAoFtAyEkGOxUskEOuUSqSAmvRwDxEJrXbjZrtMgLNyaU");
    int JzGyFDizWVWcdR = -1222122931;
    int xpZyqD = 25340433;

    for (int bdFHQKgAezD = 85071275; bdFHQKgAezD > 0; bdFHQKgAezD--) {
        continue;
    }

    for (int arTqVsTLUYiD = 1378330513; arTqVsTLUYiD > 0; arTqVsTLUYiD--) {
        wEDRSEXdha = wEDRSEXdha;
        IQVSdsYUZJOkDLBL /= cKLDEDePWTWTR;
        cKLDEDePWTWTR += xgqNKoW;
    }

    for (int whwdcNBkN = 1132151671; whwdcNBkN > 0; whwdcNBkN--) {
        cKLDEDePWTWTR -= yxYJhAbtwlGIJ;
        IQVSdsYUZJOkDLBL *= yxYJhAbtwlGIJ;
    }

    for (int rYUACE = 1248194404; rYUACE > 0; rYUACE--) {
        continue;
    }

    if (xgqNKoW == -401246.25237974135) {
        for (int GvcIWMzJotru = 1431462029; GvcIWMzJotru > 0; GvcIWMzJotru--) {
            cKLDEDePWTWTR /= xgqNKoW;
        }
    }

    for (int ZiiVokcqoUt = 35511303; ZiiVokcqoUt > 0; ZiiVokcqoUt--) {
        wEDRSEXdha = ! amAmVtZTdMHO;
        JzGyFDizWVWcdR *= JzGyFDizWVWcdR;
    }

    for (int krAFVvODCEkOIc = 1605120787; krAFVvODCEkOIc > 0; krAFVvODCEkOIc--) {
        continue;
    }

    return JKtAdxOYyagcmgP;
}

void klgps::KYqTbFu(string CjwEWilCD, double dRmYkCBjSVvlhu, bool ZFfXmVLcbtSeRjT, string FZQcaFyd, string vTGYA)
{
    string ZsydjRd = string("RGErXTTMQhPqWOCLktpeqwaZwKvjFWVbWwlt");
    bool FpKoHIjdOZa = true;
    bool SWjkZHLjMA = false;
    int BtBCIUsyU = -176276928;
    double CaMPvXWp = 772940.0281046336;
    int IqNCDEeyG = 1106741671;
    int YVdxxUxt = 407642598;
    int kSWEvNYGZuD = -822028769;
    int iHmUBxo = -1380925771;

    for (int VMlReTYoo = 1603355203; VMlReTYoo > 0; VMlReTYoo--) {
        vTGYA += vTGYA;
    }

    if (SWjkZHLjMA != false) {
        for (int AcrtlWiyHNkL = 1543711883; AcrtlWiyHNkL > 0; AcrtlWiyHNkL--) {
            FpKoHIjdOZa = ZFfXmVLcbtSeRjT;
            kSWEvNYGZuD *= YVdxxUxt;
            ZsydjRd = ZsydjRd;
        }
    }

    if (vTGYA != string("RGErXTTMQhPqWOCLktpeqwaZwKvjFWVbWwlt")) {
        for (int IVdlySHtJDHwK = 1268770953; IVdlySHtJDHwK > 0; IVdlySHtJDHwK--) {
            FpKoHIjdOZa = FpKoHIjdOZa;
            ZFfXmVLcbtSeRjT = FpKoHIjdOZa;
        }
    }

    for (int cQCllBzHflZNa = 457337218; cQCllBzHflZNa > 0; cQCllBzHflZNa--) {
        continue;
    }

    if (kSWEvNYGZuD >= 1106741671) {
        for (int SoeAovcnEFwEBoID = 1774856666; SoeAovcnEFwEBoID > 0; SoeAovcnEFwEBoID--) {
            continue;
        }
    }
}

klgps::klgps()
{
    this->rGCPsKWiHjs(string("HTWeeIhaszKVCLvcMtUlqxEEttrOxF"), string("nHYoOPLssUvPRipHPRVtUrIDMKLxgIDHBUpDrwEqbCqnNcjfQJDxcJBNuMInYBUOWbbeTyojzNncSJkPgaaiwPSjIwbikSHguThBdyvHOQIPVcSgvaSSlsRpkmlNmKXBFAsijRrfeSgiGJTUBuXVB"));
    this->UKUKv(-856126.0939837617, -716156.7284237911, 697725.461310955, true, -43276.28099752813);
    this->agzYuUHldVl(-867827.3376628865);
    this->VlsRffRMGQ(false, 1132522148);
    this->vjHjUdHlPRd(true, string("FBneMqgvsfRCxFgiiPABTwMdeTcCXGyiBeyiuoDYJZuXzgCwlGiKpxQVjbwcAYLWLShHGTGmWKkVZZFciMaRdnNiOUbLHxovUfJtskiJrWoLkBhOKKIIMGIKSHXTBnfiDRAvdqlMEboCxKsGCXuKruLmNyXPgTfoSFyGqIJkAclVSgQfoVFisOsCoJuJReyFDKBWZMvdtxYUHBcUMQtanfoMsanXfCmWnqDHASVoqxdIlVRcubrvX"), 825697.3842702822);
    this->HlSfECcnpPPmqNl(408211910);
    this->avJXTzwvmCJVJX();
    this->Zzusmz();
    this->BvkLoKZst(676230.2915271061, -926482549, string("xhzBSUAnrVrpapvazJgpSSSkyfYPCXyCewcSCkgaEmoCtOIoVYuJpTDTAeVpkoIadERwSBoSKtWoCHZGbNtHEFysiIixENqhHFjMxBoieOjywsDnqHRkZpGFjSQDLiETVvivPNjLivAlGVZRnVYpCTLREECEdSGbz"));
    this->JCTsBTqeADscq();
    this->ViwEHSHPrHd(string("HKyQIcOxKOkpOIEsbszZnDOLnYLVhuwvENiliMZspSBrsqUrKqqSawYBIXkOOchVpInIYmtboPCqOeLbQEVNsaQlnduXXZsWaEiVkhqJDyjQGYAnXOgWoZBXPOqpzkbWNWtDvfRWCJakrFZjISUoOtcAGEoHNlQGxGPsqQLtnuEYZnfkPRdzsZVWytljsFFUzqAiuEYoLjjZsfGySsmMyhukQVWMLhzaAmTYIBPpkHyDDYRgaRQCSblXPLPvQI"));
    this->urrrrQGaaYxEr(-530537.8726805232, -1696924005, 1120732090, 526288437);
    this->EGDoUeQq();
    this->qLCYZrcZrAyQz(-1724831461);
    this->tuqdlGwaCsPLRZux();
    this->zAzaRIbRDQlu(false);
    this->KYqTbFu(string("hZUHbFVXLNLcJegfsxQWhOyxnlNxHQIpbOwijdfeskYJFGrvUzzcZzyAdpYZHcDguhxzwQHSTEevcBWPWVAjQfYgFZgojLYRglAwKnXzmHmNNhJgDeltqskgCDPFWMeTOvIOaEvqsMoHCdeMfUvKCnQT"), -977215.4517202823, false, string("hOOVndkQvTietRXqbhqXclwwWizGx"), string("TeqORKRkwcZARDHxUkPWLMcUdlmHpwsPsahRDRqOEwwlnMibvWduNpbZWNfSjFcVcfAzpjlQHxWUMcwXvhoIDPAlWZrJweMKEZUVnXpbrkWFOHdCwPORCuODkVAkMpIleBxhWBpQhXasHfzdjXfQepPVLhGhisOIQTZz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Rxkgq
{
public:
    int GbkUDCzlBcvHVAgG;
    double hUnATDDeZredXRVk;
    int iDTOnvIBULSgCxN;
    double AIjJlCHsUyesa;

    Rxkgq();
    int cSrGqhzo(int dVHUrqziIIPtkb, int nDgIxcCBvV, double rvxgBC, double EncmuFZYLvvz, string rHVpVNI);
    string eWMcZFsgpDTle(bool LqytMr, bool CQralPqFsdvtI, int KYdAjexPFBIiIUB, bool HVNIAOKWtfX, int iUylZCs);
    int wdtkekoH(string QWGtoXCpkxaLTlS, string mhfebyiNgQh, double lgAXZe, double FUYAAJCLxJkiM, string SuxVAn);
    int Fhgakf(bool jMluAoWDZCLSAH);
protected:
    int rnPJWlVrkrxAM;
    double BlzluWENCuO;
    int DoRqQyOEr;
    string fjqRiQlZrboUjM;
    double doAKkWPMDLWB;

    int CluNYyuYExIFcN(string oNuJfCo);
    double SlfQsqdO(string NZrWQEDEeqC, bool yCtncLe, bool QVqutvfx, int hgPRvHzGJfvC, int THImYIewANeSvMrM);
    bool EWBjekHvnl();
    int ssXqarLvjQkJ(bool xIYxH);
    bool nCuXXV(int uAjcHuiJmDNAPy, bool gGyZbCNlsxvfVgd, string jHCfAkby, int koKqTnrK, double nauuJm);
    double EGFOmNo();
    int nLKBKr(string PTWmMcNN, bool jxgjIQrnPilPKF, bool rTZkp, bool wAZuBxL, int CHuLq);
    double swafFo(int HqgtW);
private:
    bool ATMSlRUaOSXYNG;
    bool QJoBDgAXQUWfvTli;
    string PetOmSwTRm;
    int eITso;
    bool qEZUKNjsSjksn;
    bool GfyaSIFBMAJ;

    string BPmLe();
    double DEuyVC(int UCNKDHsaoud, double aPEqlUzFqf, string RNydWsIVU, int CZjuvGwZLGQlyb);
};

int Rxkgq::cSrGqhzo(int dVHUrqziIIPtkb, int nDgIxcCBvV, double rvxgBC, double EncmuFZYLvvz, string rHVpVNI)
{
    string SfwVbEMNA = string("pnjZFYPCeEgCQCtRxKqCoxgldjMhAwxakKLiiEswmsPChYDcEPFifhjvhlJWBGdJDbboaYETwHqWVGiyYOEwBJKNMKDqBVMFBhVlpZXmgeubPTklEEZAyGdYxpgAWVvvCgrChiQuxFFYirgrkwckgRuLgURqYIbAFQPoOmCSrymPeJxQtikwevTWkxJrEQyKFfMYXoNMkyXivNlALvzuwxb");
    string vKmRt = string("shdtHfwBKbnAldKXDSvyHTSKkfCzBWwgcBaVVpDEYhHuvbnOjgCVYWAIcrJfqjqLodpFUJWfliMxcVeWbIVTiQrNjmxfspUHyEdoYkpxIgGLCWfAKEVtYqOGlVckPBoEzVjIIHeeCIyWlczgvqtuPTxWbMxpHLnJOgciSdvIUpeZKfUyMxGTZaQfVjoWTjsHFffGmcdUM");
    bool xfRYRfAO = true;

    for (int rIAAzcofzH = 488183277; rIAAzcofzH > 0; rIAAzcofzH--) {
        SfwVbEMNA += vKmRt;
    }

    for (int HJcgeuJI = 1390262020; HJcgeuJI > 0; HJcgeuJI--) {
        SfwVbEMNA = rHVpVNI;
        nDgIxcCBvV += nDgIxcCBvV;
    }

    for (int XlgAGZZJoYxjfyQs = 678223560; XlgAGZZJoYxjfyQs > 0; XlgAGZZJoYxjfyQs--) {
        SfwVbEMNA += rHVpVNI;
    }

    if (xfRYRfAO == true) {
        for (int pWCiNOfnUFt = 1280126007; pWCiNOfnUFt > 0; pWCiNOfnUFt--) {
            nDgIxcCBvV += nDgIxcCBvV;
            dVHUrqziIIPtkb = dVHUrqziIIPtkb;
            SfwVbEMNA += rHVpVNI;
            rHVpVNI = vKmRt;
        }
    }

    for (int WeONn = 1028227507; WeONn > 0; WeONn--) {
        xfRYRfAO = ! xfRYRfAO;
    }

    return nDgIxcCBvV;
}

string Rxkgq::eWMcZFsgpDTle(bool LqytMr, bool CQralPqFsdvtI, int KYdAjexPFBIiIUB, bool HVNIAOKWtfX, int iUylZCs)
{
    double wFaBbQkwUeb = 626510.1225078725;
    bool rzMTb = true;
    int TcDLguxeN = 1682636068;
    bool uyJSJNJXPoQK = false;
    int jQsIxtPoq = -650408531;
    string gcNACUIj = string("bOmxfrRskqTbZoAzFKzqelkMOBztxJHVzauSxfVrSzMqXncBVlwhHsNZKtRSszsfsNAepRyyganmiVDVvrPfyHSoYayYfxYlIwpYcgGhXgtNKDsntpsGTmjCaSxIwBvQpWjHLYxlYXkojddl");
    double tmAMrEWFgyxHSr = -577768.082585116;

    for (int nqZOxh = 41683227; nqZOxh > 0; nqZOxh--) {
        CQralPqFsdvtI = ! CQralPqFsdvtI;
        HVNIAOKWtfX = ! CQralPqFsdvtI;
        KYdAjexPFBIiIUB *= jQsIxtPoq;
        KYdAjexPFBIiIUB = jQsIxtPoq;
    }

    if (HVNIAOKWtfX != false) {
        for (int GyQQSoLxAniPquV = 805473348; GyQQSoLxAniPquV > 0; GyQQSoLxAniPquV--) {
            HVNIAOKWtfX = uyJSJNJXPoQK;
            iUylZCs /= KYdAjexPFBIiIUB;
        }
    }

    for (int aWXgpbP = 552842311; aWXgpbP > 0; aWXgpbP--) {
        rzMTb = LqytMr;
    }

    return gcNACUIj;
}

int Rxkgq::wdtkekoH(string QWGtoXCpkxaLTlS, string mhfebyiNgQh, double lgAXZe, double FUYAAJCLxJkiM, string SuxVAn)
{
    string fwOplqSKRzQi = string("efffWZKqLZjWToYKDVsLavmjpCVKfhIPBcChHcFawbCRArCLBhJrwsivXmDVpQapcWbMXZYtsbpcBFMrGSceiClFBzmwiNwGbvzPFsTDwYWpcgfXXxfSAyPEJchJngfmqWBOhJdwDWAtjBwBDGMbRmLGdoFUOzzkJwMURwmogWFKpMKbMIxCMGKixzMnnVhoNaRoWpbTKzsUrPkwUDFwkuEwhbTvIrDwpIjcqJOmbZsmTLU");
    bool XONuloPdPSycryS = false;
    string pUGUVXnGcFOoidI = string("iPcXGtKoGZBcZLtMbJfbZWKsdobIWSoPUEEVwjZRbYiXfeVfVIRgecLDJbPIkIftRCNpvvPgHKSfoYeXzDmWJPLCMNWZReyexRKFnFcWllTXZwGjLnFFdJAryBnBJozChrKMJqVIvCtHPmgEkDrhhJiGpzfGstzDjWTDqYVkANKyHiLSumvnXCckWcZMoJAechjYXuyQnFiU");

    for (int oJPouPnaSnsPn = 1447946587; oJPouPnaSnsPn > 0; oJPouPnaSnsPn--) {
        lgAXZe -= lgAXZe;
    }

    if (mhfebyiNgQh < string("iPcXGtKoGZBcZLtMbJfbZWKsdobIWSoPUEEVwjZRbYiXfeVfVIRgecLDJbPIkIftRCNpvvPgHKSfoYeXzDmWJPLCMNWZReyexRKFnFcWllTXZwGjLnFFdJAryBnBJozChrKMJqVIvCtHPmgEkDrhhJiGpzfGstzDjWTDqYVkANKyHiLSumvnXCckWcZMoJAechjYXuyQnFiU")) {
        for (int xtUVXr = 1179791675; xtUVXr > 0; xtUVXr--) {
            mhfebyiNgQh += pUGUVXnGcFOoidI;
            pUGUVXnGcFOoidI += fwOplqSKRzQi;
            pUGUVXnGcFOoidI += SuxVAn;
        }
    }

    for (int gXSWbigadONNl = 1669153412; gXSWbigadONNl > 0; gXSWbigadONNl--) {
        QWGtoXCpkxaLTlS += fwOplqSKRzQi;
        XONuloPdPSycryS = ! XONuloPdPSycryS;
    }

    return -185136291;
}

int Rxkgq::Fhgakf(bool jMluAoWDZCLSAH)
{
    double nsHhTawHCEstcV = -1009180.6984435038;
    int QWebQD = -1425328038;
    bool uReVjf = true;
    double EvwrHzJgBWrWiH = -431548.5914882188;

    for (int HkykXJrhXne = 1251414054; HkykXJrhXne > 0; HkykXJrhXne--) {
        jMluAoWDZCLSAH = jMluAoWDZCLSAH;
        nsHhTawHCEstcV = EvwrHzJgBWrWiH;
        EvwrHzJgBWrWiH -= nsHhTawHCEstcV;
    }

    for (int WYaDwIsUuwzfnd = 1992609748; WYaDwIsUuwzfnd > 0; WYaDwIsUuwzfnd--) {
        jMluAoWDZCLSAH = uReVjf;
        nsHhTawHCEstcV = nsHhTawHCEstcV;
    }

    for (int fzCrLKZZcplo = 54099033; fzCrLKZZcplo > 0; fzCrLKZZcplo--) {
        nsHhTawHCEstcV += nsHhTawHCEstcV;
        nsHhTawHCEstcV *= EvwrHzJgBWrWiH;
        nsHhTawHCEstcV = EvwrHzJgBWrWiH;
        jMluAoWDZCLSAH = ! jMluAoWDZCLSAH;
        nsHhTawHCEstcV /= nsHhTawHCEstcV;
        nsHhTawHCEstcV /= nsHhTawHCEstcV;
    }

    if (nsHhTawHCEstcV <= -1009180.6984435038) {
        for (int tSiiUFh = 129151345; tSiiUFh > 0; tSiiUFh--) {
            nsHhTawHCEstcV += EvwrHzJgBWrWiH;
            uReVjf = uReVjf;
        }
    }

    for (int KPhGylBNAKbiaTVL = 2132864311; KPhGylBNAKbiaTVL > 0; KPhGylBNAKbiaTVL--) {
        uReVjf = uReVjf;
        nsHhTawHCEstcV *= EvwrHzJgBWrWiH;
        nsHhTawHCEstcV *= nsHhTawHCEstcV;
        nsHhTawHCEstcV /= nsHhTawHCEstcV;
        uReVjf = ! jMluAoWDZCLSAH;
        nsHhTawHCEstcV -= EvwrHzJgBWrWiH;
    }

    if (jMluAoWDZCLSAH == true) {
        for (int heNgbHMN = 1819665706; heNgbHMN > 0; heNgbHMN--) {
            jMluAoWDZCLSAH = ! jMluAoWDZCLSAH;
            uReVjf = uReVjf;
            QWebQD -= QWebQD;
            EvwrHzJgBWrWiH *= EvwrHzJgBWrWiH;
        }
    }

    return QWebQD;
}

int Rxkgq::CluNYyuYExIFcN(string oNuJfCo)
{
    string rOOAJKREbhpgbdW = string("pUdhxyjqoAvmoKsJqpYSssRGoqwTwWIwbOkqabNoWukZCuYRQXIaTWjmRuEPmstoCjoeUObPcSaApHIQmTUzbDqgotKysEsKvXiitWtkLBYRTTPGffkhulQmezhvtWJDioSPHHbqOJcBYARaSHy");

    if (oNuJfCo > string("sRGWbduxTMhcncvwPvPWRYgOvnrdchJHriXFLDjmHSJNBnofCeSQkJbBXkKVxYJTtpDgBcBacFllYmMNmbgzFeQoBYVuidDHGOFSZFHrUNoGZknsJqPjRUIxUmtxtJhmmfLWakLTHIMMiewWfTCdHLPIaXTGzIclKjpSNURAFDbDUkXrhlnITtsKyIRxyhOiJquqlclOCMzQPOfJTCySRacda")) {
        for (int cuXmpkc = 1741111364; cuXmpkc > 0; cuXmpkc--) {
            oNuJfCo = oNuJfCo;
            oNuJfCo = rOOAJKREbhpgbdW;
            rOOAJKREbhpgbdW += rOOAJKREbhpgbdW;
            rOOAJKREbhpgbdW += oNuJfCo;
            rOOAJKREbhpgbdW = oNuJfCo;
            rOOAJKREbhpgbdW += oNuJfCo;
            oNuJfCo = rOOAJKREbhpgbdW;
            oNuJfCo += rOOAJKREbhpgbdW;
        }
    }

    return -1457338674;
}

double Rxkgq::SlfQsqdO(string NZrWQEDEeqC, bool yCtncLe, bool QVqutvfx, int hgPRvHzGJfvC, int THImYIewANeSvMrM)
{
    string sSEWrKVCyMejDef = string("gIdyqMTdTaRhKVFUqndaUuMSXuGchqzcLQ");
    int KDDnGd = 70153642;
    string VTrYbKbvNFSvoEI = string("xbDxU");
    double QbHRQcZbo = 500097.2198300673;
    string IftCn = string("qtPjUOONMXQhjHJbLxJMIygOfUClabLNrDwEqeVLqpkJtSnDUEWW");

    if (THImYIewANeSvMrM != 72222937) {
        for (int pssxvVMwBgLc = 1046876911; pssxvVMwBgLc > 0; pssxvVMwBgLc--) {
            KDDnGd *= KDDnGd;
        }
    }

    if (sSEWrKVCyMejDef == string("qtPjUOONMXQhjHJbLxJMIygOfUClabLNrDwEqeVLqpkJtSnDUEWW")) {
        for (int qYSSjofwKVm = 879764768; qYSSjofwKVm > 0; qYSSjofwKVm--) {
            continue;
        }
    }

    for (int jVkqFk = 1119173074; jVkqFk > 0; jVkqFk--) {
        VTrYbKbvNFSvoEI += VTrYbKbvNFSvoEI;
    }

    for (int kXzCE = 1809414076; kXzCE > 0; kXzCE--) {
        THImYIewANeSvMrM /= KDDnGd;
    }

    return QbHRQcZbo;
}

bool Rxkgq::EWBjekHvnl()
{
    string DTGlQyp = string("HiNxEzvQJfcUWICspOUgmctTeARMshCHeHAkfgGRXJaxTq");
    bool OSyYqBaBcwxjlWkA = false;
    bool AWGSF = true;
    int sLpFteXcItfzurqW = -1048489021;
    double XLNiFR = -163138.65782361632;
    string iSiMLyNsudA = string("EgtWInBrFhhCtcHKGYzDEdJGilnNyEQmAneShIlcLWOIATWEcLXGBAYvvrGvPdJEHnmOZHqbsDQDjmsCctHZUmIRTaHxmmCCptFYdEjsJpnIxDcRpgFcbYIRFTIHsPKxRhxMMCXGiuySrdxvusjdjMnXZfXkfPdLKMiLayGnGWuaCFeFjvxRJOekMjWdDZymZNgTRWWRfHzxdhMU");
    bool pAfWF = true;

    for (int SscmNXSYnXLo = 40857966; SscmNXSYnXLo > 0; SscmNXSYnXLo--) {
        pAfWF = AWGSF;
    }

    if (XLNiFR != -163138.65782361632) {
        for (int pqHSdgOxQavIIeMe = 1913634500; pqHSdgOxQavIIeMe > 0; pqHSdgOxQavIIeMe--) {
            continue;
        }
    }

    for (int oOcRRr = 559270764; oOcRRr > 0; oOcRRr--) {
        iSiMLyNsudA += iSiMLyNsudA;
        AWGSF = ! AWGSF;
        pAfWF = AWGSF;
    }

    for (int hWzqpfu = 1836717198; hWzqpfu > 0; hWzqpfu--) {
        pAfWF = ! AWGSF;
    }

    return pAfWF;
}

int Rxkgq::ssXqarLvjQkJ(bool xIYxH)
{
    string ARptujnVAg = string("hQaHyqIYwfhRVRrZJxFtWRqvj");
    int kicGzMjKTVw = 269156014;
    string YtQQBGrn = string("ovSACnHzCaOGDabDPqIhqkEPdhNWKxOPgiQKjRzMrMylrzqgGEczUMnvIEtxeonIzEAaEDSllUEbrHKteRieJhTDPDduJPdUiIHckYaEdfVAMUWNEmoiUNzBnxJVypLKAzJkJHDGhexIuCCiPYGUGCjuyT");
    string IgqhfhKynTpDbT = string("LbTkISrghPPcRjhaFImsXRZDujprpONAKEiVyOKGAhLnMrEbIQtORmCffgPTJLc");
    double VMaxgdpvft = 405632.13653036405;
    double qBVqQjxATn = 318787.71609367064;
    double OJKSwBIVylmgQkY = -634486.4758412198;
    double bflFdQO = -868538.7238064881;
    int ZAlTIsTkFQYi = 475222393;

    if (IgqhfhKynTpDbT < string("hQaHyqIYwfhRVRrZJxFtWRqvj")) {
        for (int mhziPwAXpe = 679899197; mhziPwAXpe > 0; mhziPwAXpe--) {
            qBVqQjxATn = VMaxgdpvft;
            VMaxgdpvft = bflFdQO;
            qBVqQjxATn += OJKSwBIVylmgQkY;
            kicGzMjKTVw /= kicGzMjKTVw;
        }
    }

    for (int VzXpBSQNXcoPg = 1508836380; VzXpBSQNXcoPg > 0; VzXpBSQNXcoPg--) {
        bflFdQO *= OJKSwBIVylmgQkY;
        YtQQBGrn += IgqhfhKynTpDbT;
    }

    for (int PAoQMyM = 1101393297; PAoQMyM > 0; PAoQMyM--) {
        qBVqQjxATn /= qBVqQjxATn;
    }

    if (bflFdQO < 405632.13653036405) {
        for (int UzGPw = 173429760; UzGPw > 0; UzGPw--) {
            kicGzMjKTVw /= kicGzMjKTVw;
            VMaxgdpvft = bflFdQO;
        }
    }

    for (int tSpMYohmHsvA = 2123119970; tSpMYohmHsvA > 0; tSpMYohmHsvA--) {
        VMaxgdpvft /= OJKSwBIVylmgQkY;
        bflFdQO -= qBVqQjxATn;
        bflFdQO -= OJKSwBIVylmgQkY;
        YtQQBGrn += IgqhfhKynTpDbT;
    }

    return ZAlTIsTkFQYi;
}

bool Rxkgq::nCuXXV(int uAjcHuiJmDNAPy, bool gGyZbCNlsxvfVgd, string jHCfAkby, int koKqTnrK, double nauuJm)
{
    bool nIEilHofbNm = false;

    for (int mKdiPoPToa = 473076627; mKdiPoPToa > 0; mKdiPoPToa--) {
        continue;
    }

    return nIEilHofbNm;
}

double Rxkgq::EGFOmNo()
{
    int ZKsgaeVRsUtjKghd = -1959066784;
    string ernBuu = string("JitPrHefRlKHjfPJKKBRkXbMTubsyKPbUkBiCEDB");
    double OVILrQEzgFNHG = -342486.3312463685;
    bool NjbeuTJk = false;
    int zWtpeDrooNAmae = -811458877;
    double EUzrXr = 413173.48141206556;
    bool bdRfApYgeFx = true;
    double sdoYWROINBQJBPr = -573263.5816123997;
    double QJuPU = 218273.6459061724;
    int BZZFh = -831778976;

    for (int rfnEVvsfysd = 1898237476; rfnEVvsfysd > 0; rfnEVvsfysd--) {
        continue;
    }

    return QJuPU;
}

int Rxkgq::nLKBKr(string PTWmMcNN, bool jxgjIQrnPilPKF, bool rTZkp, bool wAZuBxL, int CHuLq)
{
    int DLerPCwWmW = -2111369153;
    int YjGbUEfYXD = -1057142980;
    int SDoTzVsfB = 412964311;
    int LKiQzXOcMMobJWMU = -209705952;
    string sxvCcohiAeukW = string("iukXSNZyHvrwpyvpdGpGhzMTOASGNwjNcJSWqFUSIYRJuzssXoxMGRPeKwwjiESQMzDRTfaxdqXmFSGkNsafqrprbTwlCusddnWZUfWuWgAYFxPuFuczJYntGQKVOsrGmbzMAjOZpEigTCPGXFrDbytPoaloPexXcjWnvLbGrVQEAUBjntApyFbJ");

    for (int EkSXNpmubmriECUY = 1471871492; EkSXNpmubmriECUY > 0; EkSXNpmubmriECUY--) {
        rTZkp = rTZkp;
        YjGbUEfYXD *= LKiQzXOcMMobJWMU;
    }

    for (int mCXqGSujOXJFYJJ = 1794331404; mCXqGSujOXJFYJJ > 0; mCXqGSujOXJFYJJ--) {
        YjGbUEfYXD += SDoTzVsfB;
        wAZuBxL = ! jxgjIQrnPilPKF;
        SDoTzVsfB /= YjGbUEfYXD;
    }

    return LKiQzXOcMMobJWMU;
}

double Rxkgq::swafFo(int HqgtW)
{
    bool HdqvneVHi = false;
    int FvBXWbzRXpZhmUMe = 1468465327;
    int YVkby = 1580460730;
    double IjGRHsWYHN = 487860.94545745314;
    int iZrRW = 1374107811;
    string zPPhbgzuwAXr = string("lggsDeUGRINZaXySGLBantLVNBAXTlfKyvcqBWXtEMuxtlsVEdRGlzSnIDJhiFIHvmCiOLKiKOEDWQOblvYHrbzLrSjvPZmiPZXTXWrRPLbLUcySppnssrYFNiofUedfHedOjRweZPTNcfGsXaUXNolokAWeMDSyvUuLKKFurSeTflPCqiTXjRxKwoKDMlmmMNODHyzHd");
    string eHMfFYdQXDeyqCKZ = string("HJzFgSpxJiKWavTrJJJpHinxTqVbDBQpPQEzRUgSWVfmARRqlfLDplcCXHAfqJxbpUonqxOXpKtVbxtOPhcyjEOomVecqcQbXqbtLXrKKExDpqeUqeWeiqNWuFLmiWyJJLETNGPhjQM");
    string DvCobsgRLStnVJ = string("tYXtIUDnaZIVceuWHrVjAXhuDPcGZHRCXbRntkaagmeYVLtFMKremCATLlLM");
    int pAmjTnaptjjKodN = 1909626180;
    int szBmVPZdCcIwFCTY = -491304286;

    for (int Nafvxnz = 195470077; Nafvxnz > 0; Nafvxnz--) {
        szBmVPZdCcIwFCTY *= iZrRW;
        HqgtW /= szBmVPZdCcIwFCTY;
        pAmjTnaptjjKodN *= HqgtW;
        DvCobsgRLStnVJ += eHMfFYdQXDeyqCKZ;
    }

    if (IjGRHsWYHN >= 487860.94545745314) {
        for (int RpwpcjHWFXhyH = 1432366171; RpwpcjHWFXhyH > 0; RpwpcjHWFXhyH--) {
            eHMfFYdQXDeyqCKZ += zPPhbgzuwAXr;
            HdqvneVHi = HdqvneVHi;
            YVkby /= FvBXWbzRXpZhmUMe;
            pAmjTnaptjjKodN /= szBmVPZdCcIwFCTY;
        }
    }

    return IjGRHsWYHN;
}

string Rxkgq::BPmLe()
{
    bool dkLgTXNeK = false;
    double YdPQkwatuOgvuzk = -6106.510943854927;
    string iiZykGpODik = string("pHMJRabGQNGYrLHpYdiiEuDyXCvCjdoByqZBDbmFMNK");
    string WKvsWG = string("CbhUeVrldYDHTuehLQeJMUnRiWaGNGReDGJiqYATOwwYdZrElyawBYHBmlzXhDGVVcLvqnvg");
    bool SnSvxTJyOwif = true;

    for (int LxyipVo = 1590664674; LxyipVo > 0; LxyipVo--) {
        dkLgTXNeK = dkLgTXNeK;
    }

    if (WKvsWG > string("pHMJRabGQNGYrLHpYdiiEuDyXCvCjdoByqZBDbmFMNK")) {
        for (int SqNsJkMbNxlUQw = 2067968391; SqNsJkMbNxlUQw > 0; SqNsJkMbNxlUQw--) {
            WKvsWG = WKvsWG;
            WKvsWG += WKvsWG;
        }
    }

    for (int imDeaaMAfZ = 1181725939; imDeaaMAfZ > 0; imDeaaMAfZ--) {
        continue;
    }

    for (int SdBZn = 1940719107; SdBZn > 0; SdBZn--) {
        YdPQkwatuOgvuzk /= YdPQkwatuOgvuzk;
        WKvsWG += WKvsWG;
        YdPQkwatuOgvuzk -= YdPQkwatuOgvuzk;
        WKvsWG = iiZykGpODik;
    }

    for (int TrXmUjx = 1042163960; TrXmUjx > 0; TrXmUjx--) {
        WKvsWG = WKvsWG;
    }

    for (int JPGVf = 289061395; JPGVf > 0; JPGVf--) {
        dkLgTXNeK = ! dkLgTXNeK;
        YdPQkwatuOgvuzk += YdPQkwatuOgvuzk;
    }

    return WKvsWG;
}

double Rxkgq::DEuyVC(int UCNKDHsaoud, double aPEqlUzFqf, string RNydWsIVU, int CZjuvGwZLGQlyb)
{
    string vfjqvj = string("fzzFVIyxzMhaiuPCLCn");
    int VdtjksdYAXExY = -165556971;
    string nmJvrqBXFdZVtoB = string("yWBPVTlOmJDkzgpDtCtPwibwoBPLydtXQS");
    double VVIWpil = 507396.1205597923;
    string bSJCZGga = string("MXeNqBmrthecTSrxRBdvpTuAXDsrkKqpGQyRjpMavJeujxKrvkXCGaA");
    int vUiiVWNmcoTRU = 1723480871;

    if (nmJvrqBXFdZVtoB > string("IWAzYYgZkmWkuGPHAfOCXWmlJGaJgrHpxzjhqFHzRdcFgs")) {
        for (int zMAOKlqV = 1871122117; zMAOKlqV > 0; zMAOKlqV--) {
            bSJCZGga += vfjqvj;
        }
    }

    for (int DgYNyRRk = 974423049; DgYNyRRk > 0; DgYNyRRk--) {
        UCNKDHsaoud -= CZjuvGwZLGQlyb;
        aPEqlUzFqf /= aPEqlUzFqf;
        CZjuvGwZLGQlyb *= UCNKDHsaoud;
    }

    return VVIWpil;
}

Rxkgq::Rxkgq()
{
    this->cSrGqhzo(-1016140822, -1796121162, 714855.0136108347, -106707.55993990129, string("rEpBrVMpdCCAzHXqpBeOvQLjaojPwfgOmGfcmqJFOfbznUhTmFCNXICTRdzBUTqeZMAjweUsbtXsrszaobcmnWobuEqOnTKaAJRSWsOpBUWNBqwR"));
    this->eWMcZFsgpDTle(false, true, 235330353, false, 721424738);
    this->wdtkekoH(string("YFSSJAvfoqcXFbvpEpAjbSWqSGdiJukifOToySrBiNslvcNWkbvkoSHWnwyUnkzJKOGFrGkbgjmjqkYZQEJJyrRrfjccuVXGMfsBlVmjNvoNbfmyrg"), string("a"), 576875.2741500294, -956822.5800974492, string("WcsfyCzcISObMcVptnOgvoMIneXCE"));
    this->Fhgakf(true);
    this->CluNYyuYExIFcN(string("sRGWbduxTMhcncvwPvPWRYgOvnrdchJHriXFLDjmHSJNBnofCeSQkJbBXkKVxYJTtpDgBcBacFllYmMNmbgzFeQoBYVuidDHGOFSZFHrUNoGZknsJqPjRUIxUmtxtJhmmfLWakLTHIMMiewWfTCdHLPIaXTGzIclKjpSNURAFDbDUkXrhlnITtsKyIRxyhOiJquqlclOCMzQPOfJTCySRacda"));
    this->SlfQsqdO(string("pVvwgmTTEmFPHrWoJXYzJUbSTLmKVrQDFKBaBctTSDkRruohOEzHAMuEbFHygybGXFiRMjprGEeYQ"), true, true, 72222937, -2123960222);
    this->EWBjekHvnl();
    this->ssXqarLvjQkJ(true);
    this->nCuXXV(941754201, true, string("bupTqJwwyhcrCNpIbJMTFmnGbKRUqZUDknpBkLTJovsFvGUpNdakcgvlnJmtRRzmPXVSMxJMPHgbjHecqrceZQtJQSsQSvWnoxdiXLLYDecuhhQEkYQQQLtRdRYdMdxuwrHM"), -963291139, 373319.9471235108);
    this->EGFOmNo();
    this->nLKBKr(string("LDOvqCnMipaNizpQQKAZKXiRypLExeHOrGswRsboGAQNmZfhOXjqMVmRqOHjURgzTfMgHCZbiTWbcoMbEPwqSoxweYlrVMKfvodHyjbxpzrcljiSRVvfEXJZwselhuOLjaPFthGlcpAAzzlZcFuzCOBHBePtsBZhfPMSfXVidotzQiQmxBJFXnaBgZsHbeYvoOOXOJBaCODVFDPNYjbPLKcRIq"), false, true, false, -1353538612);
    this->swafFo(-1681836916);
    this->BPmLe();
    this->DEuyVC(-864394652, 564227.9880530584, string("IWAzYYgZkmWkuGPHAfOCXWmlJGaJgrHpxzjhqFHzRdcFgs"), 787878608);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xwHEI
{
public:
    int jeKwOKtPI;
    bool yVliJHqYd;

    xwHEI();
    bool CSVhWwxOIxlNRSZ();
    void OcVHFBhYhUv(bool mkAuBuTWqlgmAHb);
    string fFbUyjIchgE(string BMcUmNXE, bool UUGbodOzql, int JcNFnObxci);
    void jNhSDAGrC(string EQKIJvzzaiwAD, double rDgMxhOh, bool vFvSuafv);
    double eQiVZaVByDRlH();
    string sPnbsZxQMVqKwm();
protected:
    double gnOXlECymSMfqJi;
    double AHwOxbYKTozezwn;
    bool PmalDHPvxUjma;
    bool WnOsNTaQQlaNYTv;
    int DJwNDrqf;
    double NfAqAbzL;

    int JTYsUBpfMhkjkn(string giGZErbB, string wHxNj, bool FFnhSfLPK);
    double rRjYo(string YXeIAvabIEdVf, bool fskOf);
    bool fcDqVUMaZUALATEp(double BcECdfWvYAKsew, bool tpkYfOafCab, bool zOdIC, double AgZpOXVMRxDslK);
    bool eqKEJcoeFGhZ(double CISxoWgHfI);
    void sCdWeEev();
private:
    double NBmfbOIy;
    double PxqaSKsGChAlUvb;
    string MSmzOIOJj;
    bool kGGVHP;
    string DabWONukYs;

    string YaPMwztJrUmMEpDG(bool korhunuoS, string zhjErsen, bool DzIdekwnZmcSCID);
    void njatcrAdqm(string qZTJiCTDqpdAaHs, int BoogsuVW);
    void BDxqytaKQIK(string RijkkOonEQS, string dFevbHIHAd);
    double vgEILrwXLHO();
};

bool xwHEI::CSVhWwxOIxlNRSZ()
{
    int ZZURhegtrX = 223950477;

    if (ZZURhegtrX < 223950477) {
        for (int HYzEXBFdICZDRlY = 461354242; HYzEXBFdICZDRlY > 0; HYzEXBFdICZDRlY--) {
            ZZURhegtrX *= ZZURhegtrX;
            ZZURhegtrX -= ZZURhegtrX;
            ZZURhegtrX += ZZURhegtrX;
        }
    }

    if (ZZURhegtrX == 223950477) {
        for (int fthdvjyuZmDi = 1678744454; fthdvjyuZmDi > 0; fthdvjyuZmDi--) {
            ZZURhegtrX /= ZZURhegtrX;
            ZZURhegtrX -= ZZURhegtrX;
        }
    }

    return false;
}

void xwHEI::OcVHFBhYhUv(bool mkAuBuTWqlgmAHb)
{
    int pUXEdFFNMjf = 869236152;
    string RumjNY = string("hKnUeBDehlffgPEbpNrfLfDTOUxJLnVDQxFCrJBpUlRFbdSSKRkENRPYCWIxxkqrlFCq");
    int NVbWoIRDChRFmfAt = 875254689;
    int ohrLCZ = 755795224;
    int BKvxGVzuj = 698328379;

    if (NVbWoIRDChRFmfAt < 698328379) {
        for (int MXjVG = 246686843; MXjVG > 0; MXjVG--) {
            RumjNY += RumjNY;
            BKvxGVzuj -= BKvxGVzuj;
            ohrLCZ *= pUXEdFFNMjf;
            ohrLCZ = BKvxGVzuj;
            ohrLCZ -= NVbWoIRDChRFmfAt;
            NVbWoIRDChRFmfAt -= pUXEdFFNMjf;
        }
    }

    if (ohrLCZ >= 875254689) {
        for (int jEGkVUmyChXGzZz = 1568938110; jEGkVUmyChXGzZz > 0; jEGkVUmyChXGzZz--) {
            ohrLCZ *= NVbWoIRDChRFmfAt;
            NVbWoIRDChRFmfAt += BKvxGVzuj;
            pUXEdFFNMjf /= pUXEdFFNMjf;
        }
    }

    if (NVbWoIRDChRFmfAt > 875254689) {
        for (int hyIbYUeYhgdLLy = 1818661342; hyIbYUeYhgdLLy > 0; hyIbYUeYhgdLLy--) {
            BKvxGVzuj -= ohrLCZ;
            ohrLCZ /= NVbWoIRDChRFmfAt;
            ohrLCZ *= ohrLCZ;
            ohrLCZ += pUXEdFFNMjf;
        }
    }

    if (NVbWoIRDChRFmfAt != 869236152) {
        for (int zvSzlD = 481331155; zvSzlD > 0; zvSzlD--) {
            NVbWoIRDChRFmfAt = NVbWoIRDChRFmfAt;
            NVbWoIRDChRFmfAt /= pUXEdFFNMjf;
            ohrLCZ /= NVbWoIRDChRFmfAt;
        }
    }
}

string xwHEI::fFbUyjIchgE(string BMcUmNXE, bool UUGbodOzql, int JcNFnObxci)
{
    bool LJqDfesufG = false;
    int lsNrDjanSQ = 2111921034;
    bool qKmyz = false;
    string wvYDaZkL = string("CXdKvrpdWGsSdIrlRnhLEEMvUbKZJfOaPvaMWFFRlOQiHrEmJJFGUNFnhLDnPVgqRsIj");
    string VSHQera = string("OKkGOqEbqgrcEtsrDWcuYuDqezwPmfJHppegimRvwArYkehUJgzfLAMzxEjJTijlNIUrCpNKNT");
    int IBPHxvUM = 723230564;
    int OHiEXTxeMZtffx = -567182320;
    int xwktV = 1320046701;
    bool oAFMh = true;

    for (int WNDTVagVwIUTgYNj = 1825292268; WNDTVagVwIUTgYNj > 0; WNDTVagVwIUTgYNj--) {
        IBPHxvUM -= IBPHxvUM;
    }

    return VSHQera;
}

void xwHEI::jNhSDAGrC(string EQKIJvzzaiwAD, double rDgMxhOh, bool vFvSuafv)
{
    bool rCDinBUBrMhfMy = false;
    double LZNgnrdLmFcWNnY = 628671.349710438;
    int qrZrUDQiWW = -2012031764;
    double XxMugHd = -980492.4853387068;
    bool SnJjD = true;
    string yjjPljKZVqCzjoc = string("IosPKUcntokqqUJSmmiS");

    if (LZNgnrdLmFcWNnY < -980492.4853387068) {
        for (int DmsSf = 1700969594; DmsSf > 0; DmsSf--) {
            vFvSuafv = ! rCDinBUBrMhfMy;
        }
    }

    for (int iAvgAmSsiFDm = 115557047; iAvgAmSsiFDm > 0; iAvgAmSsiFDm--) {
        LZNgnrdLmFcWNnY = rDgMxhOh;
    }

    if (rDgMxhOh >= 628671.349710438) {
        for (int CzsPWLpQUjwYv = 1358724021; CzsPWLpQUjwYv > 0; CzsPWLpQUjwYv--) {
            vFvSuafv = ! vFvSuafv;
            yjjPljKZVqCzjoc = EQKIJvzzaiwAD;
        }
    }

    for (int dogMTLtpyioO = 1410719721; dogMTLtpyioO > 0; dogMTLtpyioO--) {
        yjjPljKZVqCzjoc = EQKIJvzzaiwAD;
    }

    for (int JvxsvKtcxXMWwnG = 997497963; JvxsvKtcxXMWwnG > 0; JvxsvKtcxXMWwnG--) {
        rCDinBUBrMhfMy = rCDinBUBrMhfMy;
    }
}

double xwHEI::eQiVZaVByDRlH()
{
    int hYVxkzaRepzHHME = 880142388;
    bool OdSbIcEihrhACnj = false;

    if (hYVxkzaRepzHHME == 880142388) {
        for (int UxhbMRQMR = 420497943; UxhbMRQMR > 0; UxhbMRQMR--) {
            OdSbIcEihrhACnj = ! OdSbIcEihrhACnj;
            OdSbIcEihrhACnj = ! OdSbIcEihrhACnj;
            hYVxkzaRepzHHME /= hYVxkzaRepzHHME;
            OdSbIcEihrhACnj = ! OdSbIcEihrhACnj;
            OdSbIcEihrhACnj = ! OdSbIcEihrhACnj;
            hYVxkzaRepzHHME /= hYVxkzaRepzHHME;
        }
    }

    for (int USccULbsjyIB = 123092598; USccULbsjyIB > 0; USccULbsjyIB--) {
        hYVxkzaRepzHHME *= hYVxkzaRepzHHME;
    }

    if (hYVxkzaRepzHHME < 880142388) {
        for (int mczxEQGoskTYd = 1425528809; mczxEQGoskTYd > 0; mczxEQGoskTYd--) {
            hYVxkzaRepzHHME = hYVxkzaRepzHHME;
            OdSbIcEihrhACnj = OdSbIcEihrhACnj;
        }
    }

    if (OdSbIcEihrhACnj != false) {
        for (int QOXIde = 301584227; QOXIde > 0; QOXIde--) {
            OdSbIcEihrhACnj = OdSbIcEihrhACnj;
            hYVxkzaRepzHHME /= hYVxkzaRepzHHME;
            hYVxkzaRepzHHME += hYVxkzaRepzHHME;
        }
    }

    return -69118.2957380607;
}

string xwHEI::sPnbsZxQMVqKwm()
{
    string fhICPGbiirmvaU = string("epwGaNsvNaYHVoexOSrvFxPoopXzpeKIDvbPeQdwrEJnRXOazEoYwyibPAXdFksPIJILpjdHPeoGrSGoJJvDlMzSR");
    int gifIH = -1766584313;
    string gYgPWgXPWGXYtkj = string("jYmhqkQVnopHyriEkKcVbrgAFcqnUBuiqxeBZOBucMbWyIWIkxFtVKAhxKXNsQnjNAAeFYIUPRtyFhwpmpMBNASohoYHOePDcSwaUgFuBINEraRGlxbVWlnAhqPQLjnLUBc");
    string rlngBHqv = string("qjIZQoIHpONzrdckbcWgfpKPKWWTosRnPVqdyVdDbBVKmXhdtXDuwhpYAWQphJKZXNeLAguDwInsiJcorcPvHTRyBDvGimttgTFOHlEokQEfupVBotaOBM");
    double ErazUzFxLc = 267149.6225862564;
    string BaLDoYd = string("rIRlRilYYDbJibIazWJFmjO");

    if (fhICPGbiirmvaU == string("rIRlRilYYDbJibIazWJFmjO")) {
        for (int UYAEZesRpG = 1295868584; UYAEZesRpG > 0; UYAEZesRpG--) {
            continue;
        }
    }

    for (int XHCWOAzkVdh = 1362289046; XHCWOAzkVdh > 0; XHCWOAzkVdh--) {
        gYgPWgXPWGXYtkj += gYgPWgXPWGXYtkj;
        gifIH /= gifIH;
    }

    return BaLDoYd;
}

int xwHEI::JTYsUBpfMhkjkn(string giGZErbB, string wHxNj, bool FFnhSfLPK)
{
    int dDmUgGgEzPfEI = -1379187002;
    bool SYEwivy = false;
    double jCdOpGXrkUE = 854402.9464126447;
    bool BTRpbEP = true;
    string ULXrtMttlIfwQEY = string("cyxPLCBEqW");
    double XzFqxIvF = 235109.5944541604;
    int rMtMalpWmvBOy = 2045099608;
    string KcyrvauP = string("hqZRmJNZNijUlYINKnstYbNXpNTclxQchbmPVPBllcwdNVNFRngjvLSMLsFdLTOakxDBzEIHXRTPKfzypmlBNporgRpvnznppqSdtLWbOYyUeqaCCKPgnpxMGanHMLuuxmfMTixamFm");
    double LZzdXOpr = 610132.1092590445;
    string mBTOaLM = string("EAcxXHOcLcMJNbIuizwVwIpHucpTNZUmDgfbfqyYKllZFJgygvVgTbGWBXtgTNYMRbRRkIZhfnOTCvzmDqrvLUaDJsgPqwMCqjbuaNNcUPgZZUNvPEOXyeRtOYFWAjGkOXoM");

    for (int uLnrSXH = 274713926; uLnrSXH > 0; uLnrSXH--) {
        continue;
    }

    return rMtMalpWmvBOy;
}

double xwHEI::rRjYo(string YXeIAvabIEdVf, bool fskOf)
{
    bool VNzLY = false;
    int sesadpCOyrlGR = -145554071;
    int WbRUWE = 804777675;
    int JbgazLbd = -1942635786;
    string omYBKbNSYT = string("BbkiRGNQCddyGCtPaNHoGrBWXRUOXwiTOyzdfLbSmAraxjkqhrhAkBnEwuDpqzIhKrHUHqeneqoJuXQIZfBGGQfzGfnktcUAurUlgfePiaLVdtCtykvZvgSWulssBTZHbnZaxCxPmwgECSTmrzKCUyHmDIovmIUzshpFfdHvAkTubDHKmftROCTzZSiocZzxKnGftDnzZXhWgRuMWTMtEGbp");
    int nXzVvwgUWQ = 2018705345;
    double FVPTrFasmVLUmM = -940598.1764237727;
    bool lWWVKBfTU = true;
    string iaSTy = string("XqtqFLlyqGSjQYqYhTxt");

    for (int BgPIbOy = 1093251681; BgPIbOy > 0; BgPIbOy--) {
        continue;
    }

    for (int DdYeWmiJCNGW = 840041167; DdYeWmiJCNGW > 0; DdYeWmiJCNGW--) {
        YXeIAvabIEdVf = omYBKbNSYT;
        iaSTy += YXeIAvabIEdVf;
    }

    for (int BwuVrPcXxirbd = 385015348; BwuVrPcXxirbd > 0; BwuVrPcXxirbd--) {
        lWWVKBfTU = lWWVKBfTU;
        nXzVvwgUWQ += JbgazLbd;
        WbRUWE -= JbgazLbd;
    }

    if (lWWVKBfTU != true) {
        for (int RLLpKhQSGFGuHgJc = 491475199; RLLpKhQSGFGuHgJc > 0; RLLpKhQSGFGuHgJc--) {
            JbgazLbd -= sesadpCOyrlGR;
        }
    }

    if (VNzLY == true) {
        for (int nqQikYtGF = 336860255; nqQikYtGF > 0; nqQikYtGF--) {
            WbRUWE += JbgazLbd;
            FVPTrFasmVLUmM = FVPTrFasmVLUmM;
            WbRUWE *= sesadpCOyrlGR;
            nXzVvwgUWQ = sesadpCOyrlGR;
        }
    }

    for (int rVHvzbbrUkYb = 1939175481; rVHvzbbrUkYb > 0; rVHvzbbrUkYb--) {
        omYBKbNSYT = iaSTy;
        lWWVKBfTU = ! VNzLY;
        YXeIAvabIEdVf += YXeIAvabIEdVf;
    }

    return FVPTrFasmVLUmM;
}

bool xwHEI::fcDqVUMaZUALATEp(double BcECdfWvYAKsew, bool tpkYfOafCab, bool zOdIC, double AgZpOXVMRxDslK)
{
    string vthPlCe = string("kSceHzNPmgZGJXecPPUwbNkkMNBkoNmQaAybhICrgUPbaIKqiDMmDzBvKtOAocqrbOiCaujgUUgMnsSORGcfUhmmetyuChsOluMUETygwSroNEuKpjpocGqrZnoSBEMQnubbKPCqDkqdbOAeZKCcTPxBBCwIqMyPWCmnDqcPvdmcxuWiggDMUHwFSvGpDRZwzKDFXnCWzgDdKxKcPaEVfNLINvmmBAuJUcgZQPZbTAAjTXKxwkcTJ");

    if (AgZpOXVMRxDslK != 771080.694972521) {
        for (int PilqDPDMLiDZd = 1681049335; PilqDPDMLiDZd > 0; PilqDPDMLiDZd--) {
            tpkYfOafCab = ! tpkYfOafCab;
            zOdIC = ! zOdIC;
        }
    }

    for (int ESViSuuft = 810982096; ESViSuuft > 0; ESViSuuft--) {
        AgZpOXVMRxDslK = AgZpOXVMRxDslK;
        zOdIC = ! zOdIC;
        vthPlCe += vthPlCe;
        zOdIC = ! zOdIC;
        AgZpOXVMRxDslK = AgZpOXVMRxDslK;
        BcECdfWvYAKsew -= AgZpOXVMRxDslK;
        BcECdfWvYAKsew *= BcECdfWvYAKsew;
        tpkYfOafCab = zOdIC;
    }

    if (tpkYfOafCab == true) {
        for (int UmpDTOlPYujMUI = 1703999100; UmpDTOlPYujMUI > 0; UmpDTOlPYujMUI--) {
            continue;
        }
    }

    if (BcECdfWvYAKsew <= 317478.0232359034) {
        for (int gfsxrnferoPgJ = 1869382209; gfsxrnferoPgJ > 0; gfsxrnferoPgJ--) {
            zOdIC = tpkYfOafCab;
            AgZpOXVMRxDslK *= AgZpOXVMRxDslK;
        }
    }

    if (tpkYfOafCab == true) {
        for (int KaIjmOOvExgsi = 920501246; KaIjmOOvExgsi > 0; KaIjmOOvExgsi--) {
            tpkYfOafCab = zOdIC;
            zOdIC = ! zOdIC;
            zOdIC = ! zOdIC;
        }
    }

    return zOdIC;
}

bool xwHEI::eqKEJcoeFGhZ(double CISxoWgHfI)
{
    bool nGMcj = false;
    string QbHuaBEnmZrJYJ = string("pPziuoGSCxPuwTEYDenXriXtnIztcYWMgAfGbRjAVfXwSBnMDplDnaWtPDOMjNDryqSuMHNwIQviAgmxImyPQYdCWNcnLAVAdBFhtvCHmoYlvSOyuZMzgASubckqGzgLmZarHjyPTvocXLxgTXYsFLiWWvcGeVYBraWQqbDKlIWhqWeflenAMYlGjOcOvccPfDCCydVQZqkdmvgPnCXpGPGiqkoWUMEsOWMns");
    bool KUGosCXRpXbnWRwv = false;
    bool TjZSv = true;

    return TjZSv;
}

void xwHEI::sCdWeEev()
{
    string leWJWSEOA = string("ot");
    string ompNzvraZ = string("oUKkZhEbkQenyCsRFGufeRNtupMwjGoknXkFGyOMNcNtHFIPgPPGDhkbqQropPueSajiPogSafvetqsmeYVJKjviImeYiSRoquMjlelHbYxKFkOxvNzYvYxujmrWPWzHKrNjZRzv");
    int GBLPIhEsyStuLwIg = -1675143506;
    int LoIzOvHDdl = -1406104348;
    double lJaTj = -583786.3696999943;

    if (LoIzOvHDdl >= -1675143506) {
        for (int SMxCfPpKvkVeSwP = 576278578; SMxCfPpKvkVeSwP > 0; SMxCfPpKvkVeSwP--) {
            GBLPIhEsyStuLwIg *= LoIzOvHDdl;
            LoIzOvHDdl -= LoIzOvHDdl;
            LoIzOvHDdl = LoIzOvHDdl;
            leWJWSEOA += leWJWSEOA;
            LoIzOvHDdl -= GBLPIhEsyStuLwIg;
            leWJWSEOA = ompNzvraZ;
        }
    }

    for (int rdgxY = 1455660079; rdgxY > 0; rdgxY--) {
        continue;
    }

    for (int nXmGNmakf = 2095890297; nXmGNmakf > 0; nXmGNmakf--) {
        leWJWSEOA += leWJWSEOA;
        LoIzOvHDdl -= LoIzOvHDdl;
        LoIzOvHDdl *= LoIzOvHDdl;
        GBLPIhEsyStuLwIg = GBLPIhEsyStuLwIg;
        LoIzOvHDdl = GBLPIhEsyStuLwIg;
    }
}

string xwHEI::YaPMwztJrUmMEpDG(bool korhunuoS, string zhjErsen, bool DzIdekwnZmcSCID)
{
    int nHcyUfDK = -2025903700;
    int nJRgFDv = -1051874558;
    double tDUoOhDWM = 74575.85321771768;
    string mvmvqMNQVPdSWJ = string("SmJOcjumRucZUNNOUpuWWJfxseoSlijqkdMAYntVecpQTKaFNoLUncqKnTKoAHtZGSbpQAfHmaRAcLsOoixBwdbBeWqtTAQmRuKmbeDQuTSwklIkuerawVPqynSCPyAfIqVqMyslFrWAEVXeMEfbiIReRxNWPSiztCmZEvcpDwXPsDmwU");
    double FmSjAKBusJru = -91700.23204624199;
    bool GSxhQgORZYvf = false;

    if (zhjErsen != string("dxpXkkQOunZlFGpMqulRTqqDJLsPcMztrntcnqOpiYREKtcavyWBLERYOoLWTUhQsuDmHlctFaZPx")) {
        for (int zpBmpunEbZ = 1460521370; zpBmpunEbZ > 0; zpBmpunEbZ--) {
            continue;
        }
    }

    if (korhunuoS != true) {
        for (int WBWPfGRtFRFK = 114729333; WBWPfGRtFRFK > 0; WBWPfGRtFRFK--) {
            GSxhQgORZYvf = ! korhunuoS;
            DzIdekwnZmcSCID = ! GSxhQgORZYvf;
        }
    }

    return mvmvqMNQVPdSWJ;
}

void xwHEI::njatcrAdqm(string qZTJiCTDqpdAaHs, int BoogsuVW)
{
    int KFldFP = -531234241;
    double MCQmc = -385766.73676580336;
    bool gSoHfXMskHWBEzlR = true;

    for (int BTdMiq = 1845939020; BTdMiq > 0; BTdMiq--) {
        MCQmc *= MCQmc;
    }

    for (int wDKHhJqdccXi = 370732060; wDKHhJqdccXi > 0; wDKHhJqdccXi--) {
        qZTJiCTDqpdAaHs = qZTJiCTDqpdAaHs;
        KFldFP /= KFldFP;
        BoogsuVW = BoogsuVW;
        KFldFP += BoogsuVW;
    }

    for (int CpdLG = 1619038842; CpdLG > 0; CpdLG--) {
        qZTJiCTDqpdAaHs = qZTJiCTDqpdAaHs;
    }

    for (int oCcRfurQYMu = 1103474579; oCcRfurQYMu > 0; oCcRfurQYMu--) {
        MCQmc /= MCQmc;
        BoogsuVW -= KFldFP;
    }

    for (int NXtcbVkUXlDgqcU = 1795987992; NXtcbVkUXlDgqcU > 0; NXtcbVkUXlDgqcU--) {
        continue;
    }
}

void xwHEI::BDxqytaKQIK(string RijkkOonEQS, string dFevbHIHAd)
{
    int gKKQBdRmVOMSAC = 1702463573;
    int PVclynrthsXMaM = 1749232583;
    string fVyLYF = string("ZctDlFgqPhkkUQDEkTVjFJAhvZfdYrEimFLKOymmxptERQLiAvhBcTLgavcdgRZkIWpfubcluUhXpCyFvafDVViwWJNWmPKnXcbjAHGEjoVsoXpLeiqvLpsRgAaAyHAYsFHI");
    string wxmiwpGfmer = string("CKjgfUBngZvTQTDiXoeNJsMgulFTFbsGYVMPZgJOVpLJmvWKJuEXlcAFPcFiKZuPCitJEFOxNiCcgsysM");
    int gSIKHpyWlFc = -1565218384;
    bool gSKWltaXrEiZLl = false;
    double AATHb = -1048502.1498279213;
    int udlkUlvlpqYopTW = -425218665;
    double HtdAUkoCXb = -827800.7233726033;
    double YREZknwNtXA = 220221.3112855398;

    for (int WIBiynRwSytC = 631840898; WIBiynRwSytC > 0; WIBiynRwSytC--) {
        continue;
    }

    for (int joXNfADQfFxTZ = 1925544098; joXNfADQfFxTZ > 0; joXNfADQfFxTZ--) {
        continue;
    }

    if (AATHb != -1048502.1498279213) {
        for (int dKswMvUJ = 328921339; dKswMvUJ > 0; dKswMvUJ--) {
            HtdAUkoCXb += YREZknwNtXA;
            YREZknwNtXA -= HtdAUkoCXb;
        }
    }

    for (int ELjREceND = 1555986154; ELjREceND > 0; ELjREceND--) {
        fVyLYF += wxmiwpGfmer;
        wxmiwpGfmer += RijkkOonEQS;
    }
}

double xwHEI::vgEILrwXLHO()
{
    string ACAklBm = string("LCWrAEcEFLcHwlskdaCkSjcanWmFRAjeCNzoBnHXVetjzhpWnfHykoBbRQNzBXseeVkpTdzstIwLdxHQtACMzXOMUbAztqPzQrfFmeGKurORxVwlxJkZzAYZelBHtFluBDbcngwSiCvjuBRzzarzNxtFIleECuTQSLzNSxGanDkgsDQztaqlhsD");
    string OUkaJeLCDAxS = string("SMNSqifOFwdRohKXsgULOaUZTfHNMODdVNpZZMktazBTmWEOhDTpGccwUhQKzzfrXdQIjFudbMnDIrHeEITgXtJwWYnpDKwHHRrjPbzKHCnprjigdFiwmPnfqeEZsTwnNjPexjKHeNIhNenVMwVHJpnHPyANsfACmsIIEXkIWBgRBflLbIMFMiValoziSvZGJkerstPBWcznVrAtzPHMhfKgpUpMOYqMfvlaMZzckDlzunzVWCboiCze");
    string cqRRsN = string("ifOkdAYoqnXYeOtxHtCIZshWcoSMbXrXewxzfEbEsKjdaeEcIFhbAlwqToOpgNcwTkkHbnBEMJfcDsgwBRQSNLOfYHdgyXrLpxzYgdqBlHydtHUEWAxTGmgtWNBTJiYgTUiERezeyRZaxGzLzayztnLvZbcqGsqajpXQAIRZREfjUSUtHnlaNaebAUceFIuLvMBFXCIsotICoAkNRpcshufgUFEnJhhbmDekvNLUdcWFNRPMNM");
    string RGrEOjaKFHNRYpv = string("juCAAPSOvzumEemVZCVjbNlwNwOmHXqrSxaTUrsPyrdbTDEfoERmzWbaLbDeQKEjiDFXEEWoUMOngwancnQzOZTYcVxEWAddSjJMtGjtvIhMXfbQxoPhJGRTDvptAhncsLS");
    int wpVKcgQJrO = -1291347982;
    bool zHsdGkeZzOHuNA = false;
    string WYRQnwlmaHqjwBI = string("McWPBdUfwAAvWczwpZXrfGPviO");
    int LHQZlSevugjilp = -4219988;

    if (cqRRsN < string("LCWrAEcEFLcHwlskdaCkSjcanWmFRAjeCNzoBnHXVetjzhpWnfHykoBbRQNzBXseeVkpTdzstIwLdxHQtACMzXOMUbAztqPzQrfFmeGKurORxVwlxJkZzAYZelBHtFluBDbcngwSiCvjuBRzzarzNxtFIleECuTQSLzNSxGanDkgsDQztaqlhsD")) {
        for (int PvBHoMdshBnGSqZ = 745842505; PvBHoMdshBnGSqZ > 0; PvBHoMdshBnGSqZ--) {
            RGrEOjaKFHNRYpv = RGrEOjaKFHNRYpv;
            OUkaJeLCDAxS = WYRQnwlmaHqjwBI;
            RGrEOjaKFHNRYpv = OUkaJeLCDAxS;
            OUkaJeLCDAxS += OUkaJeLCDAxS;
        }
    }

    for (int RoENfBT = 100556029; RoENfBT > 0; RoENfBT--) {
        ACAklBm = WYRQnwlmaHqjwBI;
        ACAklBm += ACAklBm;
        ACAklBm += OUkaJeLCDAxS;
    }

    for (int OSPGWWYngFGum = 1349571091; OSPGWWYngFGum > 0; OSPGWWYngFGum--) {
        RGrEOjaKFHNRYpv += WYRQnwlmaHqjwBI;
    }

    if (WYRQnwlmaHqjwBI != string("ifOkdAYoqnXYeOtxHtCIZshWcoSMbXrXewxzfEbEsKjdaeEcIFhbAlwqToOpgNcwTkkHbnBEMJfcDsgwBRQSNLOfYHdgyXrLpxzYgdqBlHydtHUEWAxTGmgtWNBTJiYgTUiERezeyRZaxGzLzayztnLvZbcqGsqajpXQAIRZREfjUSUtHnlaNaebAUceFIuLvMBFXCIsotICoAkNRpcshufgUFEnJhhbmDekvNLUdcWFNRPMNM")) {
        for (int qriQOdUmlzmkrFrY = 1594715658; qriQOdUmlzmkrFrY > 0; qriQOdUmlzmkrFrY--) {
            OUkaJeLCDAxS += WYRQnwlmaHqjwBI;
        }
    }

    return 410508.05225987633;
}

xwHEI::xwHEI()
{
    this->CSVhWwxOIxlNRSZ();
    this->OcVHFBhYhUv(true);
    this->fFbUyjIchgE(string("qJftjbDkAhFDzZkxAGrgmvTXkBfgsTUeFyXCTXGWtTcgWJvxeLxJocpQYBJVtfZDFMcaGcaDJwnyFnosFCBTkSptXFOhXMAFEpGPCscTHoeWogVxgsjRGCNrUCaiwLPAoCOEQNVKxLtcIxDeppElpYgxKxbvFqHLRtxuzjrjCwTKirxNUKCW"), false, -468613254);
    this->jNhSDAGrC(string("TuJjoAjlkChjbVDegbjVFzfcpELgrYATyDAbupESKGzMutqvvfkGkVacHriEKLmhZIuQrPXLLDyiOfiQaAoBwglhoUhmlrNpoqscyHUTlutwQpGfMDYRdHYSMBXhuAherIJIyvixXSfkUXBrdyvFogUjpKNpbTtIehdwXtCr"), -211677.44848691663, false);
    this->eQiVZaVByDRlH();
    this->sPnbsZxQMVqKwm();
    this->JTYsUBpfMhkjkn(string("rfCnetBWdKNmKOLdNMmYiwTXDELuNZmDJjlNWAumHBSoPdQBBwuTIqFrVDhUrbuHMFjFQLfkQLkJBuqHQxIoBnCCGPaHZhuVBfqTFoATHogDMgkMosfDyqfhtEOShJFMmunRwFiNdbIGQpVNPIIRNvZVJlPKncUOSVCbcbBpPGsSCbTDhUVWHpoZbqXntgaQGglpzlTTabAZPKLgArWRdXmERIwsVkIATRWXeYyoeqbbteNYkrumqNS"), string("GvmRbAmKXdNhQzsrZeAYbcHmRlMsOIUEriltVlDZNJXnrujeWYSnngWXOOkyIKAVVxwPoFVdBVfgEX"), false);
    this->rRjYo(string("ZSohPWLjEPeezGqogxacqHauvBQGKDNtSThzraDzLuhyIjCdInCHZmoVpgQyaqAzEJVfbCxeARxXVmdtVQsDjMFYfmSLuHDGuDvHphakRCvkKazIqlSjHCyvazOLuOZLZYYqmTXwvaPn"), true);
    this->fcDqVUMaZUALATEp(771080.694972521, false, true, 317478.0232359034);
    this->eqKEJcoeFGhZ(1011881.6500391015);
    this->sCdWeEev();
    this->YaPMwztJrUmMEpDG(true, string("dxpXkkQOunZlFGpMqulRTqqDJLsPcMztrntcnqOpiYREKtcavyWBLERYOoLWTUhQsuDmHlctFaZPx"), true);
    this->njatcrAdqm(string("QOlJpWPteTBIiYjSslQivLttUSuFkewrIvfpgtVGJJVoZvmQAoHRhMDAytQuBhQyBKroebMRqZxIGylqdLYfGXDgceJSFDxiYCTmAz"), -1793647601);
    this->BDxqytaKQIK(string("PGKvwiVRDvFpUZDTEnphgehTNJepnZmNfdCSKUgkJQGKRLSIXmODug"), string("USUYsOMpGvMQOBzIsiVqSHevjnnBYPqHTk"));
    this->vgEILrwXLHO();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class amYeGMCXzREcL
{
public:
    string jPHUJuCHYcN;
    double aSObXBWOqCdITT;
    double yoNNKQOzzqygRRQ;

    amYeGMCXzREcL();
    bool BuDuJhD(bool LiJqAxQRCHoPr, double qVnVCvy);
    double fDDQNHEAW(int trflZKTT, string ULmdfHmmHXiFboy, int lTVNtjNo, bool TdgWTodBzXkTJ, string gaesRTXoxWchrgZp);
    int tMHBMxoYbRZqJPt(string pImhy, string RObvN, string GgnhY, bool jepqpfvLRzqOCncY, int UNnBMZhAFl);
    double KzdqvlgpB(int krVXOdjJoipk, double ZWXbDEtZyMD, bool nEQbUdkqhupXv, string NOCUB);
protected:
    double QBYobrzQEt;
    string byIcNCP;
    int sEEnnGylBmm;
    string mZxsOdG;

    bool inBdLZj(int txDMVbtOLSSFy, string xxvJcolA, int mNtqvSXu, double kbWpOsEVmgZPJy, bool tCAdHfCxu);
    string uSDlNP(bool yFmKZKUoNgl, int vtjCeg, bool VjLTs, double REyuAExUWkmTAhT, string IEVVsMthKKyz);
    int immjpFC(bool KcnTGHyqiRW, double DhglIboMJbcBDDaD);
private:
    string opDTVbOzi;
    double iuuBoGILITrWWtPh;
    string xJxXClbJsohcsgJj;
    double sakzzuwknv;

    bool HfPIlg(bool wktLgHB);
    double UrIfZTtRGMtMhHf(string EqVJLPGdLvmSL, string bYihbxmjXtpOdr, bool IioOPueO, string JuldKqsDs, int EHtZQPBN);
    bool CTZIgqhk();
    int zSCpjz(string tTpywj, int TbVeXC, double XflJo, bool KGPKyHBnMgzf, bool YHIOpLCXlNnoPW);
    bool VEFaDno(int JbVOixmKXL);
    void fPBFjTkWkDMQwyav(int tXWpxuewyBRZnwUQ, string DufyQqhEGQKDgqBL, string BcqvE, double jAuTqoOCcfiCG);
    int NqKxjVaMbkQXjfqW(int XsNHeg, bool rqDhb, int SVZZYQHcjzBEN, int nrBcvtBgzxbk);
    bool ilorDfMStSyQno(bool YvdBz, bool YSYanmezDDym, double DWDwG, string QbWmsCkwL);
};

bool amYeGMCXzREcL::BuDuJhD(bool LiJqAxQRCHoPr, double qVnVCvy)
{
    double glEhXwROISU = -547526.2421565371;

    for (int JlqvRb = 1827784809; JlqvRb > 0; JlqvRb--) {
        continue;
    }

    for (int MQXmvCgcSPr = 2098680220; MQXmvCgcSPr > 0; MQXmvCgcSPr--) {
        LiJqAxQRCHoPr = LiJqAxQRCHoPr;
        qVnVCvy = glEhXwROISU;
        glEhXwROISU -= glEhXwROISU;
        qVnVCvy = qVnVCvy;
    }

    if (glEhXwROISU <= -454509.4953296878) {
        for (int zBSvgmntfMWPpX = 756987730; zBSvgmntfMWPpX > 0; zBSvgmntfMWPpX--) {
            qVnVCvy *= glEhXwROISU;
            glEhXwROISU += qVnVCvy;
            qVnVCvy = qVnVCvy;
            qVnVCvy += glEhXwROISU;
            glEhXwROISU -= qVnVCvy;
            glEhXwROISU /= qVnVCvy;
            LiJqAxQRCHoPr = LiJqAxQRCHoPr;
        }
    }

    return LiJqAxQRCHoPr;
}

double amYeGMCXzREcL::fDDQNHEAW(int trflZKTT, string ULmdfHmmHXiFboy, int lTVNtjNo, bool TdgWTodBzXkTJ, string gaesRTXoxWchrgZp)
{
    int rgPXetqnFzhSM = 1506762902;
    string zZBdZrkYaEJyJuIX = string("wTmJQrWyvvQBdfehLjOPoeIwsObFBqJkpGWZUuDwwuzuFBSKxfyTUNTSASBWRxvlFszxsHpmTXvEYdBdbGdoMmrkCirNSlpyOtDahWmCtePdNdRAGjBAzafIixTTEmcdfkobQwPiMzhgfRXNZhKbPOCkteMoBxYjgIHsTquZJfstkyFzyoashnsosNNqGGycgMoHnKqNRUFnuYwOb");
    double AsFlTTdw = 874881.5379561738;
    int XXNDEWVnyxEfgE = -1047639712;
    string cXScWqViEpjw = string("kcwsIAbeuvJLUhGtJkSbH");
    double SeLvNICyRiEf = 883376.6422299198;
    bool dOvGgMeQS = false;
    double ZjhhRlaYV = 67418.18923391799;
    double UDurM = 718292.5062848061;
    bool GpReheDAk = true;

    for (int rhXEMFNadEDXEnfE = 745007557; rhXEMFNadEDXEnfE > 0; rhXEMFNadEDXEnfE--) {
        UDurM *= ZjhhRlaYV;
        zZBdZrkYaEJyJuIX = cXScWqViEpjw;
    }

    for (int aXiaA = 1173349061; aXiaA > 0; aXiaA--) {
        UDurM *= ZjhhRlaYV;
    }

    for (int qKYfWWEhKTKk = 275142176; qKYfWWEhKTKk > 0; qKYfWWEhKTKk--) {
        zZBdZrkYaEJyJuIX = gaesRTXoxWchrgZp;
    }

    for (int hahWXjbVChoge = 850673903; hahWXjbVChoge > 0; hahWXjbVChoge--) {
        ULmdfHmmHXiFboy += gaesRTXoxWchrgZp;
    }

    return UDurM;
}

int amYeGMCXzREcL::tMHBMxoYbRZqJPt(string pImhy, string RObvN, string GgnhY, bool jepqpfvLRzqOCncY, int UNnBMZhAFl)
{
    double dSvIlmWiTY = -368330.6421557485;

    for (int zxItPsovVynb = 113239833; zxItPsovVynb > 0; zxItPsovVynb--) {
        GgnhY += RObvN;
        UNnBMZhAFl /= UNnBMZhAFl;
        GgnhY += GgnhY;
    }

    for (int lgHhETrRffKV = 49651123; lgHhETrRffKV > 0; lgHhETrRffKV--) {
        continue;
    }

    if (GgnhY < string("ev")) {
        for (int fdcnmAexehz = 349974640; fdcnmAexehz > 0; fdcnmAexehz--) {
            RObvN = GgnhY;
            RObvN += pImhy;
            RObvN += RObvN;
            pImhy = GgnhY;
        }
    }

    for (int JBFSiLwCbNHkZ = 757201553; JBFSiLwCbNHkZ > 0; JBFSiLwCbNHkZ--) {
        RObvN = RObvN;
    }

    return UNnBMZhAFl;
}

double amYeGMCXzREcL::KzdqvlgpB(int krVXOdjJoipk, double ZWXbDEtZyMD, bool nEQbUdkqhupXv, string NOCUB)
{
    string SMMWqhgLidGb = string("wsBhAntHptMzPGJRlyLpXzlWtrJQeseGiwFGsJvWaHvvaUkptHoBPotXgDJJphCyQEiQBbgORgRhcarNVpfzlxKFhHvJkt");
    string cqtSMkJhNNYQW = string("BYvYHmFxXFYpPJAjbUYBlmGWUMTtactyLuMLCKMVGbMQtjCeIoYrRKMTEkXlfrsVaWKWSLyJnSvIkExTSBSVhoUKvdCMWHuENpiDopSGesALKDCTHnpKXpQdmXNtINbIcTQgzUBQRHIVIdhPHrgLuzZcqPnzDXKvHKhwBdFigllIeADxlNtjwJpmbDFysHBBOnasxngVraLtGGQfuP");
    bool dfrRmoLRlKfGFHeF = true;

    for (int hhppsGWrNfdDRx = 1932190240; hhppsGWrNfdDRx > 0; hhppsGWrNfdDRx--) {
        NOCUB = cqtSMkJhNNYQW;
    }

    for (int eNMCwivrFyTE = 631214124; eNMCwivrFyTE > 0; eNMCwivrFyTE--) {
        SMMWqhgLidGb += cqtSMkJhNNYQW;
        cqtSMkJhNNYQW += NOCUB;
    }

    return ZWXbDEtZyMD;
}

bool amYeGMCXzREcL::inBdLZj(int txDMVbtOLSSFy, string xxvJcolA, int mNtqvSXu, double kbWpOsEVmgZPJy, bool tCAdHfCxu)
{
    double NRtCjFpI = -941764.2571235026;
    string orHpeCGSpokSr = string("EhTCbLdTsmMEBgGfkFodDgRuYdioJQYRkpWlPXYITgRNVeTpwYcuVYxZGXgpZVtWdjWNejZaHLtqXeeFjsxBhblviPLfAXZGQAsRwvKmiqneoKxsLcgzAgzVEvSObKOhJKpZCJMvlaJVCCPvHcqXxMQxCmwtsbCBnkeQSDBfzfRAJwYkmhedtQMWEs");
    double zFQvexhocWuhkOjW = -771592.7037870444;

    if (mNtqvSXu < 1308358227) {
        for (int YgVNYNdCleiTnXhO = 1813946806; YgVNYNdCleiTnXhO > 0; YgVNYNdCleiTnXhO--) {
            kbWpOsEVmgZPJy -= zFQvexhocWuhkOjW;
        }
    }

    for (int rUSihsYKrdEjI = 607975175; rUSihsYKrdEjI > 0; rUSihsYKrdEjI--) {
        tCAdHfCxu = tCAdHfCxu;
        xxvJcolA += xxvJcolA;
    }

    for (int FwWLsjjvtiuV = 1848562810; FwWLsjjvtiuV > 0; FwWLsjjvtiuV--) {
        orHpeCGSpokSr = orHpeCGSpokSr;
        kbWpOsEVmgZPJy = kbWpOsEVmgZPJy;
    }

    return tCAdHfCxu;
}

string amYeGMCXzREcL::uSDlNP(bool yFmKZKUoNgl, int vtjCeg, bool VjLTs, double REyuAExUWkmTAhT, string IEVVsMthKKyz)
{
    bool JfkRSjNmHG = false;
    bool bcElA = false;

    for (int apvCH = 1001087978; apvCH > 0; apvCH--) {
        vtjCeg = vtjCeg;
        IEVVsMthKKyz += IEVVsMthKKyz;
    }

    return IEVVsMthKKyz;
}

int amYeGMCXzREcL::immjpFC(bool KcnTGHyqiRW, double DhglIboMJbcBDDaD)
{
    bool QEUYnuSbiNmlIZtS = false;
    string NPuEwHJO = string("aqHcsOnnpmkiBCGiLrzPaSYsvvehxoRfizqIuiltANpvlPaIKRDigewhcAhyWpLxLowRsXgjlAgZXEQYaurUaiPnLJsQYOWxNNTHeloCtNoOyZXhOaSwwlbNQyCTEbMUqIxjZbp");
    double GtaMCkasbbqEKyyU = 499765.454575792;
    bool VdRPQtlIvTXALeW = false;
    int QoRvrrtYfmN = -1805199019;

    for (int DtjmPMOj = 1623381704; DtjmPMOj > 0; DtjmPMOj--) {
        QoRvrrtYfmN /= QoRvrrtYfmN;
        QEUYnuSbiNmlIZtS = ! VdRPQtlIvTXALeW;
    }

    for (int RfhTIlT = 1888947403; RfhTIlT > 0; RfhTIlT--) {
        DhglIboMJbcBDDaD = DhglIboMJbcBDDaD;
        KcnTGHyqiRW = VdRPQtlIvTXALeW;
        GtaMCkasbbqEKyyU *= DhglIboMJbcBDDaD;
        QEUYnuSbiNmlIZtS = ! QEUYnuSbiNmlIZtS;
    }

    for (int JLDIEBgs = 1994012499; JLDIEBgs > 0; JLDIEBgs--) {
        VdRPQtlIvTXALeW = QEUYnuSbiNmlIZtS;
        KcnTGHyqiRW = ! KcnTGHyqiRW;
        QEUYnuSbiNmlIZtS = QEUYnuSbiNmlIZtS;
    }

    if (DhglIboMJbcBDDaD <= -246186.84974953902) {
        for (int ldauYtbA = 2008150294; ldauYtbA > 0; ldauYtbA--) {
            VdRPQtlIvTXALeW = VdRPQtlIvTXALeW;
            QEUYnuSbiNmlIZtS = ! VdRPQtlIvTXALeW;
            VdRPQtlIvTXALeW = QEUYnuSbiNmlIZtS;
            QEUYnuSbiNmlIZtS = ! VdRPQtlIvTXALeW;
        }
    }

    if (GtaMCkasbbqEKyyU == -246186.84974953902) {
        for (int htSRCEzvuhjpI = 755178574; htSRCEzvuhjpI > 0; htSRCEzvuhjpI--) {
            continue;
        }
    }

    for (int REqIubF = 971876985; REqIubF > 0; REqIubF--) {
        QoRvrrtYfmN -= QoRvrrtYfmN;
    }

    for (int HhJIUwHPNqnxDmqk = 388170872; HhJIUwHPNqnxDmqk > 0; HhJIUwHPNqnxDmqk--) {
        QEUYnuSbiNmlIZtS = ! VdRPQtlIvTXALeW;
    }

    return QoRvrrtYfmN;
}

bool amYeGMCXzREcL::HfPIlg(bool wktLgHB)
{
    string ucJmYb = string("scPupykjIFqGpQkGicStBFvalptJgxtsienvVTUHLTWqkITbTIyuCnGYORDmyQqkomvfcGgThTWXsvqaoWWojlgSycPgcjkfqJoprmusNuymwEzXbCxviIwGxkzNIEBgYlMjURpYyFPThPKxBVMJeyHVYFGxJvQuYiBGQOBdOUFKAkipDoRqkNBFlJLArMBkXMhpyiicYDuZLYbbLZjHsbGHJBj");
    int QDrcWl = 1609805443;
    string dxzNqNMfHfHZX = string("zbmsvTjvKWhwXIdRwzRmqXRmqrEwlUKkeRSbSRkPwIFuHFrLzMsCRMVaQghxFQHXPe");
    double ghqroE = -362194.1225490917;
    int fGRhhmzoYixp = -1073599711;
    bool AKTdyGmxJ = false;
    string wwsZbqarqRuy = string("uohyDNeGkdIvpVOUaSowbWTjbaYVjpZAXgTiHSfyrIQwfUOVdkYGDltVHDwMzcspqWUlVVJJKSJyhYHIjXFWAGHEmfWsDrMtmJLqIvKNPxvwVdyjmnTYbHFdnmuwJnrmBSoaKMzlmecGRvMSkeiYmNPvLgMmdUwfYvgydalnJ");
    bool OqaJDNGgWa = true;
    bool AuEOYTLZOfuxINzB = false;

    for (int sRpMiNebGhPfS = 157709969; sRpMiNebGhPfS > 0; sRpMiNebGhPfS--) {
        wktLgHB = ! AuEOYTLZOfuxINzB;
        ghqroE = ghqroE;
    }

    if (OqaJDNGgWa != true) {
        for (int ZMkhDQtx = 1900087113; ZMkhDQtx > 0; ZMkhDQtx--) {
            wktLgHB = AuEOYTLZOfuxINzB;
            ucJmYb += dxzNqNMfHfHZX;
        }
    }

    for (int qLVBHVWfaxFOkv = 1924636017; qLVBHVWfaxFOkv > 0; qLVBHVWfaxFOkv--) {
        continue;
    }

    return AuEOYTLZOfuxINzB;
}

double amYeGMCXzREcL::UrIfZTtRGMtMhHf(string EqVJLPGdLvmSL, string bYihbxmjXtpOdr, bool IioOPueO, string JuldKqsDs, int EHtZQPBN)
{
    int QtBejWwb = -333939633;
    bool lhKvVpFsiV = true;
    string OrPgbPnKjrHbV = string("gpQfhRpaGUVSXPdjuZkqkqGwSFUiFeoCaBdbjWqFLeDdzBoiDxjBqmJRvIkosgJVbHYfsTYvAkOeISYurepCwjSZsMJiKpQKLuktOnMxghYzWxIPXElZJaHcSFbpicepBxYWDIEjuSpIRmGGiUHVFuFOpsDDkcZoiWzmpJzeaRngRZDLsHr");
    int ZGgZWdUM = 2030717658;
    int xrSrVhlKygJTdU = -991482048;
    bool tGwYrVpafkZnas = false;
    double JvdcmPuHKj = -206541.46714771955;
    string KvyNnyvFCLqUDDPy = string("gpoYXbpVgHRSPfVtfkcuHyBmHXfzPmcBWWZxNvLapULdFEehZZRUkTDfSktxFFeSXiqbpxkZpqsXXXPgWrccacypXYaSLNoOoFyeeZfbIWDPTa");
    double ZqJAipZAjT = 682165.7725509387;
    string sLxigUfdWc = string("vUvNuyjcrmoKHrwREGmQcWPMtZqvWcFHiwbWYOCWHCcUGbHyvtpKUGtTbOkoxps");

    for (int susNCRTK = 358377122; susNCRTK > 0; susNCRTK--) {
        sLxigUfdWc += bYihbxmjXtpOdr;
        sLxigUfdWc += bYihbxmjXtpOdr;
        lhKvVpFsiV = IioOPueO;
    }

    for (int uZVIpbsWDzfGaaJG = 1567708391; uZVIpbsWDzfGaaJG > 0; uZVIpbsWDzfGaaJG--) {
        ZGgZWdUM += ZGgZWdUM;
        QtBejWwb *= ZGgZWdUM;
        QtBejWwb = xrSrVhlKygJTdU;
        JuldKqsDs += JuldKqsDs;
    }

    if (JuldKqsDs != string("vUvNuyjcrmoKHrwREGmQcWPMtZqvWcFHiwbWYOCWHCcUGbHyvtpKUGtTbOkoxps")) {
        for (int tIqsijVemLCRm = 312524685; tIqsijVemLCRm > 0; tIqsijVemLCRm--) {
            tGwYrVpafkZnas = ! lhKvVpFsiV;
            xrSrVhlKygJTdU /= EHtZQPBN;
        }
    }

    return ZqJAipZAjT;
}

bool amYeGMCXzREcL::CTZIgqhk()
{
    string ZeCcyP = string("CiWrmCZ");
    bool quxjlpqCu = true;
    double MHuyIIeMbB = 590348.242256262;
    double UibvRuRd = -934864.6045036395;
    double WXFOJhRejCZMrV = -754376.8360440285;
    bool mlcuYy = false;
    string oMCxYXBOEOku = string("NPkwkzgKcpjIrjsWppYWWeE");
    bool EZQUZWnRfiKsYfak = false;
    double cFSjvaFDtypZD = 928612.2285977171;
    bool tzyYDdylXL = true;

    for (int rSecpAt = 1932531607; rSecpAt > 0; rSecpAt--) {
        UibvRuRd *= UibvRuRd;
        MHuyIIeMbB /= WXFOJhRejCZMrV;
        cFSjvaFDtypZD += cFSjvaFDtypZD;
        EZQUZWnRfiKsYfak = mlcuYy;
    }

    return tzyYDdylXL;
}

int amYeGMCXzREcL::zSCpjz(string tTpywj, int TbVeXC, double XflJo, bool KGPKyHBnMgzf, bool YHIOpLCXlNnoPW)
{
    string YiuRlXrM = string("TgPsYjAbKRbaWlqBJfxmmnEMQzMVYLdpKtydRjdxUIRNUvvtlgcRTuNNToaEuMJnsftkIJEAjGXQgWLotwXfAnZnUFpQPdvskRTKoNrbfUtKewxtevvOSGHtXIPslRBKjxLpwpZNZcWzCEGeeNGzqDufyQlXBxqjqCvlbdtCTBnAphfjDdkPPXDfGTmxzvEXMHRyOLdKkjJhdyZVPzZdAhdXNGXTDVVVbHBaAPMvOYdxJpOdziuBAhaffCWk");
    double dGGdkwjQVCQhiKEG = -721470.4911300992;

    if (XflJo >= 649983.6634651605) {
        for (int xUbEcMiSemFT = 810512947; xUbEcMiSemFT > 0; xUbEcMiSemFT--) {
            continue;
        }
    }

    return TbVeXC;
}

bool amYeGMCXzREcL::VEFaDno(int JbVOixmKXL)
{
    double gOncoPxN = -684869.3931057955;
    double HocdeBPojvXR = -251126.33669921142;
    double vFcqwQrnKkaK = -843967.9312955596;

    if (JbVOixmKXL != -1963784609) {
        for (int BTCgsQdbfpWNvc = 819019766; BTCgsQdbfpWNvc > 0; BTCgsQdbfpWNvc--) {
            vFcqwQrnKkaK -= gOncoPxN;
            gOncoPxN += vFcqwQrnKkaK;
            HocdeBPojvXR = gOncoPxN;
            HocdeBPojvXR = gOncoPxN;
        }
    }

    return false;
}

void amYeGMCXzREcL::fPBFjTkWkDMQwyav(int tXWpxuewyBRZnwUQ, string DufyQqhEGQKDgqBL, string BcqvE, double jAuTqoOCcfiCG)
{
    bool JnvejtOj = true;
    double yWLJMoDFhbTblrFk = -389153.8645065617;
    int nrrUuGZcq = -628410570;

    if (jAuTqoOCcfiCG > -389153.8645065617) {
        for (int CwIWodVJv = 988762228; CwIWodVJv > 0; CwIWodVJv--) {
            nrrUuGZcq = nrrUuGZcq;
            nrrUuGZcq += nrrUuGZcq;
            yWLJMoDFhbTblrFk -= jAuTqoOCcfiCG;
            yWLJMoDFhbTblrFk *= jAuTqoOCcfiCG;
            tXWpxuewyBRZnwUQ -= tXWpxuewyBRZnwUQ;
            tXWpxuewyBRZnwUQ *= tXWpxuewyBRZnwUQ;
        }
    }
}

int amYeGMCXzREcL::NqKxjVaMbkQXjfqW(int XsNHeg, bool rqDhb, int SVZZYQHcjzBEN, int nrBcvtBgzxbk)
{
    double HaRbtBITnt = -899850.918226721;
    string LOLqpe = string("HclVDQOXPSZIwWSDZzzsSLFkvRIzQOaJywbbjVMgSXTRjTWhAxNBjkZxwQKkLsRIlGu");
    string KBeYOXzRNN = string("plYCBJilwfohamGNrDkvtWjnbXnNybDBWrPpWgldkKNATxmdsprIMQVJDgmJAhTfpyJzOZeWGpozsbvScozqlMPYaWQvuewQsjAWrKBfRoBCDYDOIRyUAguDQciLGpkJcqGZLfyxuNzuhPovisgpYHyxvMCjARBDjajHZWkdegVpijWbTggPQPRkkNuSHNTQ");
    double exEoJQzYSB = -858918.1736001621;
    double mKPSiV = 660473.4350835005;
    bool ZxJvdiTqmoYTVtL = true;
    double fnPBLWdIaEZ = -112578.15724953741;
    bool YsYfMMTfCVpJgT = false;

    for (int upWTAQLczy = 477884885; upWTAQLczy > 0; upWTAQLczy--) {
        exEoJQzYSB -= exEoJQzYSB;
    }

    for (int NtrtPhajsOtMKJfJ = 66086761; NtrtPhajsOtMKJfJ > 0; NtrtPhajsOtMKJfJ--) {
        fnPBLWdIaEZ *= exEoJQzYSB;
    }

    for (int RnLHXYfoA = 2097942432; RnLHXYfoA > 0; RnLHXYfoA--) {
        continue;
    }

    return nrBcvtBgzxbk;
}

bool amYeGMCXzREcL::ilorDfMStSyQno(bool YvdBz, bool YSYanmezDDym, double DWDwG, string QbWmsCkwL)
{
    double RbIDCOqVXTcCXmHB = 795044.265647136;
    double eVkUQPks = -850971.7945667832;
    bool vDBeYBLtcoZ = true;
    bool gvDfJPOVjaXPN = false;
    string aFtyVrHyMmLYuD = string("kaYbRPTDFoOWOiAWwdFilfBGmwEkPcB");

    for (int gpRovAyGNJOyc = 1532082187; gpRovAyGNJOyc > 0; gpRovAyGNJOyc--) {
        YSYanmezDDym = ! gvDfJPOVjaXPN;
    }

    for (int SXbHY = 2061276926; SXbHY > 0; SXbHY--) {
        vDBeYBLtcoZ = ! gvDfJPOVjaXPN;
    }

    return gvDfJPOVjaXPN;
}

amYeGMCXzREcL::amYeGMCXzREcL()
{
    this->BuDuJhD(false, -454509.4953296878);
    this->fDDQNHEAW(989857395, string("qHSDpxtVPsdKCulVzzwtnzvDEvPMNnQECVehNlhbCnJloMpJQOTilFMJsOfBEsimjDbBmmEAWADWXgxAalafRukQxoZ"), 1402670919, false, string("bjorZdfLuVoaVWgblpWWjur"));
    this->tMHBMxoYbRZqJPt(string("XHkdLPXVOVSBvOvOQJGavIjFbrFSnzqTPOhBGgCqKLjeaoFPMHjwKZosFqZoylSmTGBQKHftqOIEPZegavnkmpGcIFitTKKMTvzfEkapmAtJgOrVnOLjZeDoSTMnMMdntlbwxvBqvNVzCIDTxBGcpvhyfYbhkQuBjcLwwksVmxaoyqCpptyWiIAhXfdTskFKmPtZvpLxIG"), string("ev"), string("oizxbcIduAgcUXBMLzhPPiKZRSOeayuQZFIgMWyzSJNtsOVvTqYItlnfOxIDShgPFEjHWvXrsesXpTWhLyceSwUojQeXOVWoFQtoJUeCaaQcFFtGJJlSWTQuFHUVIKfNbjEgiTHUydR"), true, -1414587300);
    this->KzdqvlgpB(1097042411, -455971.4041020815, true, string("xrMuJpKbrmxigLYFkEeafsZJHtKLumnhhZWsKfMLuBQlMJkAZDGFlzoMvLlvRxwlXvjPQAhIYQIZCVWYDNqlemnxWtkxXrifUNQzdatMhWSJbNUdAisUaKfBzMWVMKVPRYDjJUTOiRLLtSNqQSmXaIiZyjwEdxdZCAJlHHsqgYwZddCzFZaunsatjfojAWORIaSZkyKBDpwcgqWIudJFlP"));
    this->inBdLZj(1308358227, string("qoWVWaiGmWXcqHhaUGhZTeKcvGoAgVWHcSkpYAAJBadmiYIbqZAFVsvWzuDZrVJeqpkjGfeGIYyHfwxEDISLhzgDUISbOsjuQchRUFSXgUGkbrVmnajZeTytzyyBrSrzzFzeFBpfTpezLktOloPLgruLnubafmduJrErr"), 1018193478, 861585.3248644468, true);
    this->uSDlNP(true, -735138994, true, -527471.8680853638, string("lNyejwXnbrGUHCwFEXjNpCxJyTzAsFhvDXJvBNCnVAQjjSBNUEJfuObEHzMjRmepdKTnBHbEfuJlkdKExmsNUQgwkCspUeXbQNrsuUnFmnDEIPDGQOUSbCKdIibCOFfcFmPIjmSDdtuTJpcSgzeCMqTpLYcGZglnqBjhMKnpbMBacKPyINPLnwlqtnpqgIekWUtLaCwLBfdtFWoWTxkMZprAFDmTSRYKNhcOGTEZNKHJBeTEkFlLowcXEkrRz"));
    this->immjpFC(true, -246186.84974953902);
    this->HfPIlg(true);
    this->UrIfZTtRGMtMhHf(string("fBqxUMlUQZXODoOeENNQqnhYAdULXVhxBAYyrWhVVDcIptGDfdrmfiOlYTlFKE"), string("GbbUdOBEqXUpPkYpmKOYXWNJvoKSjIySaoVOZWdiMKnWGXUmHTNwsYMCGdeaiiKadpQnTZBvMofdlYKbfsQdGqJwAhQqUINrwuUQeUvdAVtKdkOaDelEznCvwhHfAhZBOatPdScKAdvlaHvLGecSuYVKNoigMgtaeaitwIWTdXtKZXUJQQFNLnwUHnosnwElvDJUnUCZYOjVwmqtGPIZLPbxgCdMjXnXUvAwNeVKfvfGrVr"), true, string("qsqLqeWQZILtEqqOWBdNuzBLrZOpbPlZndJKilzKOQnjTxCxujysCcUdRGOGEOhOkhqrUGtGIqLrKGftUUcfUuvMVCHvhuhBQqzRpTihXKvMQzKFWiYqmdGwOkAwUfPBQRXHBoQlmzYxzVcWQUraovHIB"), 2040243971);
    this->CTZIgqhk();
    this->zSCpjz(string("cWDCqiQdBHABkIxplcKYjHgZzGNWWTpnXpjtKuFYDzNrthZSjpwSQkUYWEuGqIeldmLolFIAWQJORJYlXIeKVKXciemqFcJioMjGPYIzkXHgucFMzNwcPzjHJivxgkyZUkOVHnfWWGIITAUOxoogwR"), -374444741, 649983.6634651605, false, true);
    this->VEFaDno(-1963784609);
    this->fPBFjTkWkDMQwyav(1513013408, string("KAaqIVEUNJpgLgrbORSirFsQQGgxMFaPoUGxjxpxVhEelFloPdWTOZyxBdwoDAQeCruuhkUmQoPkEJPgTUGCljWHRvcKNWGOkueYzHaBelMDZnrHkftWyMUNFFpeClJcTSQJDhczVAIaAUYJAlCnUOVESNJebruzoTtgStbFIHqYCuOzkhJjLTeWUyCzZTzZKuOxeyUnpACBdfPvKzTKdYlgA"), string("rWZfaKhbnUofdrAIqdfGShorKJBxNAhiSfyyNDyxkxzznosIPbZALBfpJewtpFObFBDCafTsKZfcSkGjRemqwzNFckiMNRAatSEwfaa"), 705740.5733014558);
    this->NqKxjVaMbkQXjfqW(1632969817, false, 928815973, -2121295327);
    this->ilorDfMStSyQno(false, false, 519309.70235771313, string("DcirLppsbnfKbJnavIYNjrLcpzJoWFtySCeUuDOjfrotWwCyTbhFYJfLEeZbMCuHLZFZtgNPKKbratRLMyqYBatTHhgiIRPYMjmgBNstpSLNgDLRLcXfIXQdxzOkBUVnfxcmIiZfZalKeOddPbSQoWnArUvhMRllerCorFajdJghlBLDTLrOabPBCpRwcSPMKJBJsXdkUTtXkTTZiCYmbeqPzDQuPMJJqGEWkNqeQHyXG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JikvtLIOqzWXnK
{
public:
    string kHjwGJJP;
    int ENibE;
    int aHAyNiZOHhTu;
    double hLQHFPlKucMb;

    JikvtLIOqzWXnK();
    string IdvgfRV();
protected:
    string joYELAFA;
    double MBqKpGoJESveu;
    double DAwkCjrMMwubprOC;
    double fAUdubyoxMLES;

    double cOhMJu(string oSzEV);
private:
    int JQxAwzwPAGtqtzcq;
    double MaTnaHaVM;
    bool YgtDgEpN;
    int paUZZWJBZWxuW;
    string sTkOhtHZS;

    string ZWGtIZoGMcjnMs(int ZhnZpcfcpb);
    string dJrFN(bool RFGKJZrXVuPSll, bool uOKMkUtw, int cnqRxiZqfDLbBtK);
};

string JikvtLIOqzWXnK::IdvgfRV()
{
    bool zlFXHCxIrGORhpc = true;
    string ICzfpyrLqN = string("LtIrbLmvMaKBQlutMnByGtmHXqwJfROHyfpHzkTkEgwpQYophTdJPfkgNURlum");

    for (int eAoHoODYBy = 606652330; eAoHoODYBy > 0; eAoHoODYBy--) {
        ICzfpyrLqN = ICzfpyrLqN;
        ICzfpyrLqN = ICzfpyrLqN;
        zlFXHCxIrGORhpc = ! zlFXHCxIrGORhpc;
    }

    return ICzfpyrLqN;
}

double JikvtLIOqzWXnK::cOhMJu(string oSzEV)
{
    string TODRG = string("bycKKAtxJCDXUaWSVPDpWsAflSqFJahOrkCkzgMtRjqcgvkYIsRthYkrEmSIAXCXHVFolqrxbrpnkEaSdd");
    double bupAZmPiIccVIxF = -395384.5329714241;
    int zbertzxgYgpwlqga = 998631651;
    string imRrRVvqZIBkDXZf = string("ZGIdpfBwSIghSdQjFCrZHgPrBFMvGoyRnNIToBvQMgIVZhbgcUthuetLLfDfoZuEvUQmCpTdMhQQuxfwbgnsCHWHOuoPwEbHiPPIIcmGlCz");
    string cjXfrV = string("sTZIfGHAPrhWhDCwmfceoNIxNhaFVCYFvXDsFYdzSJnydlIWYyYWSHxgYxsbyogwCpsViuKLyiewbhwOeDVvuojvTvSxFLAQMlvebxdbrfIqbDdpZtjTOOXzIQyoAVyzGQhXMLdMywFlUTvaWMajTnittQtSLWcwiMslEfdbCxfwrujvaSmWshiMNbdWBFHDLLvzgjIBPwXsChMctHnzPOZWADBS");
    double rCWbkUqEZKF = -498635.2988357808;
    string ePqxemAxMsNNuJN = string("ACUdzUNtISptuLYjJdcFtKcNkDnmsLuJGigYIrQlzBAwOBlBkpJnafekoseOYFOUIaqwWlUmNbxxpzeXbnCVgiFcbjkwzCdomwYjdLYcpJiFUPssyRDSjdonBXANNNeiPuBtKzqGfHrPGEbthEgKmORmNMGaGixJMaOanAIZPlslGhBkTPUTjdpdHpEuejvydrcrFvqDRd");
    double MYHggjJZIv = 260002.39551728548;
    bool iAVHr = false;
    double TFoVBkf = 211907.95940582358;

    return TFoVBkf;
}

string JikvtLIOqzWXnK::ZWGtIZoGMcjnMs(int ZhnZpcfcpb)
{
    double KcGhcoR = 980970.7503788505;
    bool IQTOdObHMDJNFCk = false;

    for (int peTDDazQezTmByp = 1828239198; peTDDazQezTmByp > 0; peTDDazQezTmByp--) {
        IQTOdObHMDJNFCk = IQTOdObHMDJNFCk;
    }

    for (int jtRGAorqR = 484906931; jtRGAorqR > 0; jtRGAorqR--) {
        KcGhcoR -= KcGhcoR;
        ZhnZpcfcpb -= ZhnZpcfcpb;
        IQTOdObHMDJNFCk = ! IQTOdObHMDJNFCk;
        KcGhcoR = KcGhcoR;
    }

    if (ZhnZpcfcpb > -1694164553) {
        for (int vkeRQnvLskT = 182401168; vkeRQnvLskT > 0; vkeRQnvLskT--) {
            KcGhcoR *= KcGhcoR;
        }
    }

    for (int EwrIRNaM = 1720134353; EwrIRNaM > 0; EwrIRNaM--) {
        ZhnZpcfcpb = ZhnZpcfcpb;
        KcGhcoR *= KcGhcoR;
        ZhnZpcfcpb -= ZhnZpcfcpb;
    }

    return string("aTyWviSocWkyTFLHtiRsYYwBWToRUDQEpMwimICmrNLlDBkirwUAbxWEnACXyHhOnaglTBAuSoOjzFbThyRduOdPqQTTfrSlBGURCKmrzvvBpfCdetGKfuOpovSK");
}

string JikvtLIOqzWXnK::dJrFN(bool RFGKJZrXVuPSll, bool uOKMkUtw, int cnqRxiZqfDLbBtK)
{
    int jayaefTu = 400349066;
    double xXWzbh = 38100.37468497793;
    bool uMoaqXrXMqOownT = true;
    string QkmUuyYSNhFK = string("UU");

    if (cnqRxiZqfDLbBtK != 400349066) {
        for (int dTflGNEY = 1827222343; dTflGNEY > 0; dTflGNEY--) {
            continue;
        }
    }

    for (int vDHKhBt = 2081522011; vDHKhBt > 0; vDHKhBt--) {
        cnqRxiZqfDLbBtK = cnqRxiZqfDLbBtK;
        cnqRxiZqfDLbBtK = jayaefTu;
        uMoaqXrXMqOownT = ! uOKMkUtw;
    }

    return QkmUuyYSNhFK;
}

JikvtLIOqzWXnK::JikvtLIOqzWXnK()
{
    this->IdvgfRV();
    this->cOhMJu(string("XKgXhPjweZxOsDFzHeuRcAWUZGgVkMTcmHDQRAslQGyTZpioLVeKLuxPiSpnhdxzNWBqZnStEYmCMiRZvanzXeWdijZgRXYfimuijfuXadVrongKJVIyJxSdwiBFAbgpZDOIGokiBoDVDEyzlXDZDJyjLmDOiyNXuYgFLhJkxjbEeOnSili"));
    this->ZWGtIZoGMcjnMs(-1694164553);
    this->dJrFN(false, true, -1131988321);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OgQFydRqhqICGiu
{
public:
    int ddEAHaaCkiDwAF;
    double RPWCgdQi;
    string uBOIVJvfq;

    OgQFydRqhqICGiu();
    int RusOubAkTLIGXyic(string PFwYaFgIEwViJ, int MYOUdZSGvyZRI);
    void aBYdYdsOoMoqNhl(string etfJIYXUf, string JxzFwCX);
protected:
    int nLeJo;
    int Gjcmj;
    int QLsqoIHjHFDGG;
    double MLDiTBpi;
    bool wUqIYzkv;
    string hMdnPlBHFgOXUHZ;

    int pkttO(bool rbngkIQqtrcuBJjO, int QFncbS, int PdstkcLWwvVo, int tTagnssrV);
    void zjkdMPRFR();
    void QkBdCBkDOQZe(string imHHnSticEMxFQ, int dAdJjiDKgXpHF, bool FCxfFOmipuvByu, double sygWTmTbcDauysA, string yFJXqEMLNRyTMq);
    bool OElPJjUqfWY(string GLmFGtMMRdTLi, double gpRIwpUPhD, int RxlVWBGCoVFNEs);
    int KTHLG(double wNOSh, bool dfnrmchzzHZoP, double dxhSEnGvcQa, bool DwkZlEifkFpZxYXC);
    void OpGcVNwjExIhLaCR(string mITpMoSgx, double HzJVDfFpikrLWLyI);
    string syjhuXDeX();
    int gnlUWuUmWRGdy(string CtuiHwXZH, double PwdDgbmyJUxp, int mAhPaDLVIjpATqM, bool NMFJTQv, string xdqSGgudLmKI);
private:
    bool jJHvVxorkuZOBsEj;
    bool ervrpAdliow;
    string dkhliyq;
    int bxtKqrWpjpaz;
    double VLJAc;
    double xWGspRkEJZD;

    int qHVtswXe(string JRJLcTAtn, bool EyzwvnTOjkh, double AETybiYVjMtsJ);
    bool kJltyBYbqxNtp();
    void WLPFK(bool lamNxUWfmPyCA, double gebHxiyrJ, double JtZZHOLmjOO);
    bool vRPsC(bool LikKxie, bool SSATqSOjgGhm, string lueIeAOiBUtIzQ, double EfyfYdmWsuMObO, string uIGlWrInOpnYDmRP);
    string YLhCCDXQtBrQ();
    double WhZbIkSAbLjDfsQz(int lWwzIjHAZISqpO, double JzEaUsYz, double gkkpAcamDdJ);
    void GkYMhIwdRfVfHuIl();
    bool InUqvktSQmpBGkF();
};

int OgQFydRqhqICGiu::RusOubAkTLIGXyic(string PFwYaFgIEwViJ, int MYOUdZSGvyZRI)
{
    double xCilbrl = -617167.1031417743;

    for (int szdmn = 1927288629; szdmn > 0; szdmn--) {
        MYOUdZSGvyZRI *= MYOUdZSGvyZRI;
        xCilbrl *= xCilbrl;
        xCilbrl -= xCilbrl;
        PFwYaFgIEwViJ += PFwYaFgIEwViJ;
    }

    for (int ScZaRdYHVgqLYmMX = 1369096564; ScZaRdYHVgqLYmMX > 0; ScZaRdYHVgqLYmMX--) {
        MYOUdZSGvyZRI += MYOUdZSGvyZRI;
    }

    for (int uDAqoy = 742848206; uDAqoy > 0; uDAqoy--) {
        PFwYaFgIEwViJ = PFwYaFgIEwViJ;
    }

    for (int rcmSlWVAcFaoKT = 1801932887; rcmSlWVAcFaoKT > 0; rcmSlWVAcFaoKT--) {
        xCilbrl /= xCilbrl;
    }

    return MYOUdZSGvyZRI;
}

void OgQFydRqhqICGiu::aBYdYdsOoMoqNhl(string etfJIYXUf, string JxzFwCX)
{
    string adAsTNqL = string("KZyeczKyfQQDuedDFiiBysZwODexmgju");
    string wyTwFfRyVwXFg = string("rbfgBNfXIZNDwWUtAMDVfzmsRUyTLEwEkAbZmxiEpatDduhlAXUNzqnLbEPCnnuksxkQmNnphWzxlvsOWZUOBIJyNEkBWEdAPDPpPWdgMDudizjgphxxJdTFrSotBAMnXhoKKQQdVisnPSDprhhrMRAiMUxfpgfWGHNqdTEyHnuM");

    if (wyTwFfRyVwXFg < string("CSWPNbHioFBhApAJcgdQMpIzPyKGICecPNIXMDSTcpXEKQVVoBPENoGCFOJeooBVQGBxIlbaVxHyiFMAMpZvTpNQoprdejAIRfScJHdEPjxrLJfQqAtutfYsKSdHwBNAbSDVxLkpneeDRrdpgdCWVFqJdresPjUDLXDsugYSNWimSBEddwrUhAHYZTpJqeWDRbLmUnlFqloOiQm")) {
        for (int YEPIRXUTAUKHFHdZ = 1505896295; YEPIRXUTAUKHFHdZ > 0; YEPIRXUTAUKHFHdZ--) {
            etfJIYXUf += JxzFwCX;
            wyTwFfRyVwXFg = adAsTNqL;
            etfJIYXUf = JxzFwCX;
        }
    }
}

int OgQFydRqhqICGiu::pkttO(bool rbngkIQqtrcuBJjO, int QFncbS, int PdstkcLWwvVo, int tTagnssrV)
{
    string qTTsIQKjQnyWyAK = string("OnSSDoJdaVEPYBguEcfdbrVlqhwCSqhgozDJnzfjGLuCJhJzsSurxdQBcDAODOc");
    int MzooU = -859947039;
    double RvXSHISSb = -830904.2632713253;
    string PaxzMtcgIVGOKfB = string("zaAapyxavPfrRaNMKYuoSkmCKnKdkIYSVNtjHkseqeLXRTKtQRxg");
    int QqjGE = 1140164739;
    double DAUOEkWTo = -988044.3941220826;

    for (int mqOqxnwsTlAFEeqe = 796727294; mqOqxnwsTlAFEeqe > 0; mqOqxnwsTlAFEeqe--) {
        MzooU = QFncbS;
        tTagnssrV *= QFncbS;
        QqjGE *= MzooU;
        QFncbS -= PdstkcLWwvVo;
        rbngkIQqtrcuBJjO = rbngkIQqtrcuBJjO;
    }

    return QqjGE;
}

void OgQFydRqhqICGiu::zjkdMPRFR()
{
    string TZTIMkXeLIECj = string("mdpvoCcBwJchsJvfhTnbhJczsmuolsWFCTxpHFAhFtqmyKAhUWBuKQMbpwoTpSpANfAbCBTOXmACBrNuDjAOwWRLqMxKNXyVqmIWpunwSdJGhHdZwANZBgkeAa");
    double dOcyzaDV = -118640.08776061001;

    for (int WqhBsFQSOwCatNe = 2057283924; WqhBsFQSOwCatNe > 0; WqhBsFQSOwCatNe--) {
        dOcyzaDV += dOcyzaDV;
        dOcyzaDV /= dOcyzaDV;
        TZTIMkXeLIECj = TZTIMkXeLIECj;
        dOcyzaDV *= dOcyzaDV;
    }
}

void OgQFydRqhqICGiu::QkBdCBkDOQZe(string imHHnSticEMxFQ, int dAdJjiDKgXpHF, bool FCxfFOmipuvByu, double sygWTmTbcDauysA, string yFJXqEMLNRyTMq)
{
    string iOQlETHqpmhuJu = string("jGQkyfJkfCmGSUfJZludQKpbmZiWtmtYCkHiWKalhugeXfpcDEhcukAMLrtniNGjEalejBXzLjItaTtxNaNAnoktCnzCyQwcLfERVHVJqpiKfCVKrNvZqgelRNFaqJtNvmXGVjajQCSJzuHTnERkSzMyeAPMduPiVCbICEuIKjzjXOzVlPGoecWaijXRcBqIAxBIUpNuzqDyyPHYSORtUSYHUJGcOLpYlwPLkHtUaXwryoFQP");
    double NRBPfDwzpsp = -860800.4820571146;
    int iUgvyjeIka = -2013247201;
    bool bSdOT = true;
    int KOfywLPnyq = 1138888699;
    bool sfRBiFZJjX = false;
    string YVueojA = string("evRyVxKfdRJrftizIdLWgSszUSUODBWsYIBaqmYWgyCUgRHgFbGNLkFRhAj");
    bool pCiAYAiIAkU = false;
    bool QINoplfnEIBtw = true;

    for (int eZWthAjQMHy = 1668746965; eZWthAjQMHy > 0; eZWthAjQMHy--) {
        iUgvyjeIka = iUgvyjeIka;
    }

    if (dAdJjiDKgXpHF <= -2013247201) {
        for (int eOXHkFLhvVdMiKfC = 1586658016; eOXHkFLhvVdMiKfC > 0; eOXHkFLhvVdMiKfC--) {
            continue;
        }
    }
}

bool OgQFydRqhqICGiu::OElPJjUqfWY(string GLmFGtMMRdTLi, double gpRIwpUPhD, int RxlVWBGCoVFNEs)
{
    string ajvfEDgjROkNXb = string("OkapZLiUiwLbfxHOKarUxseYGTtDwmpGLxkHlGBNLimmBoElDQScKJNVSzvyZTDFGJuUWRlltpVLgawrQnzzVrjWSwMtCidFjQYwcACXCmVCjYBJzxuivGWTbzXsCFuqTJWDZveXXJXHfatvvZgeeFcnOdDSMjMAujaOPHzEwyOd");
    double nfQmadSYelJhfLjX = -545697.430639861;

    if (nfQmadSYelJhfLjX <= -545697.430639861) {
        for (int oCgLKKNKTdS = 298278346; oCgLKKNKTdS > 0; oCgLKKNKTdS--) {
            ajvfEDgjROkNXb += ajvfEDgjROkNXb;
            gpRIwpUPhD /= gpRIwpUPhD;
        }
    }

    for (int xlaxauuoneppwvQz = 1479253343; xlaxauuoneppwvQz > 0; xlaxauuoneppwvQz--) {
        GLmFGtMMRdTLi += GLmFGtMMRdTLi;
        gpRIwpUPhD = gpRIwpUPhD;
        gpRIwpUPhD += gpRIwpUPhD;
    }

    for (int gvTdbXaFoTdClffT = 2051850863; gvTdbXaFoTdClffT > 0; gvTdbXaFoTdClffT--) {
        gpRIwpUPhD = nfQmadSYelJhfLjX;
        RxlVWBGCoVFNEs /= RxlVWBGCoVFNEs;
    }

    for (int tRZsksHgt = 1107600595; tRZsksHgt > 0; tRZsksHgt--) {
        continue;
    }

    return false;
}

int OgQFydRqhqICGiu::KTHLG(double wNOSh, bool dfnrmchzzHZoP, double dxhSEnGvcQa, bool DwkZlEifkFpZxYXC)
{
    double BDfgAFR = 243181.90015091692;
    string dFlfY = string("tApxsrmzUrnzhoqzjvlBkcZqiNsqDKQHYQpXEJShFHcSCpbHqfDqJViTQPCMJuOIjIrLYlxepEWTYrwcwiPmFwxWwzIVgVBckThzBxmwxlDoAghaAwNQnhRbugRNuocMednTwRvNSx");
    string UaWlWmrahUc = string("GuGTBRoxKRlTQpTujTbKWNzCASudVhzleTQhAHoxfTxYZVbYhSiushWwlkyDYUAtUkQcmtQVqJJLzXQpFyPEcMjroxtuCaddReDDcVKtLbkSNYWOAjWsZvPESxfNcqbtelGzsaHWxAJVSitwilfDCtBaAtnuSsi");
    int wkHYDNxcyjubQeH = 2000210388;
    int MpvcuH = -24825713;
    double CjDggGSAhORzVPP = 739369.4113568277;

    return MpvcuH;
}

void OgQFydRqhqICGiu::OpGcVNwjExIhLaCR(string mITpMoSgx, double HzJVDfFpikrLWLyI)
{
    bool KdmIxVySSyhDnT = false;
    double MEuYjxr = -171299.78156823618;
    int NCXaHRRtrgJzkth = 206292043;
    int nqIiIXlaCYEM = -707313075;
    double QqqyO = -638332.1903202151;

    if (nqIiIXlaCYEM == 206292043) {
        for (int hUyWcmUYasKGHMH = 1588099770; hUyWcmUYasKGHMH > 0; hUyWcmUYasKGHMH--) {
            NCXaHRRtrgJzkth -= nqIiIXlaCYEM;
            MEuYjxr += HzJVDfFpikrLWLyI;
            MEuYjxr -= HzJVDfFpikrLWLyI;
        }
    }

    for (int KMLwBIoI = 1479192080; KMLwBIoI > 0; KMLwBIoI--) {
        continue;
    }
}

string OgQFydRqhqICGiu::syjhuXDeX()
{
    double ksgNdlo = 893818.4737418797;
    double HwewaDCRwQFKcR = -179852.38554468093;
    bool IIubgDensJPzU = true;
    string pGvWtXEzrYauUyj = string("scbGnVHXDdgAsXeAOxSZAERHjsNmWpiDFrraeMfwOWaxuRmLaMVtHAUiXNHHowzgPoYkecyDpYrVQbGvUgUxrJIJVYBdiLTwoOmmXhPceTENrtkIokCgoVipPsluznAhgtpfqbNhJCDnoavHDqWfIEoGvsMjmDXaAHZFU");
    string IEKOXwmyguys = string("zqGjUAIzrQVAthQgXaKEQgnDKPVLhuOfQEfcobLXsyfLLXzORPWWdPpwfYTjwfVfywFlPHphqXizSGwdialjDyAJYJAFkqotJEolYYPDRkFnaQcIQyhTImxdZCaNDUxydKNiwhglZqTrBCYSPDvqeHxdcbHR");
    string huoPReuRJkOQjLY = string("UWVXpJUOXSahqIDOWaJGGbeSWLqnfewBTndmHkXGCDUxdqhlecWDF");
    double rVeKbRT = 900176.3596788092;

    if (rVeKbRT <= 893818.4737418797) {
        for (int JgPkSYRyCVe = 756219367; JgPkSYRyCVe > 0; JgPkSYRyCVe--) {
            pGvWtXEzrYauUyj += huoPReuRJkOQjLY;
            ksgNdlo /= HwewaDCRwQFKcR;
        }
    }

    for (int sTQxeFfnipH = 374577046; sTQxeFfnipH > 0; sTQxeFfnipH--) {
        rVeKbRT = ksgNdlo;
    }

    for (int QAdUvaFPkpCr = 683168483; QAdUvaFPkpCr > 0; QAdUvaFPkpCr--) {
        continue;
    }

    if (rVeKbRT != 893818.4737418797) {
        for (int arPMNoKJ = 133880634; arPMNoKJ > 0; arPMNoKJ--) {
            continue;
        }
    }

    return huoPReuRJkOQjLY;
}

int OgQFydRqhqICGiu::gnlUWuUmWRGdy(string CtuiHwXZH, double PwdDgbmyJUxp, int mAhPaDLVIjpATqM, bool NMFJTQv, string xdqSGgudLmKI)
{
    string UZiIzjvfGBOQt = string("fpSaoBCarcacsNJjEdRHPROLydhrvozdomOXGEOhnovYDifqWWrGldMqKOivEBWRYjMEWQGHAoShUKTqrIvDslocyEwrPfOJFjZBpIuArqFOlDAjokKOoqSGLyzSqtBmqx");
    string nbdsw = string("PwngBRmyMGXNGjXALlBgboWBzWHhviYDNfIkYtdrzBLrjaUwldCdzscmBhrLOOnzlnWBQorhfmgXmTwXgIqrnSIbSptsLEXdsyAgxoujTPvkxjJLDhquPmljkOwLiHArecfQFSskfOmnMPDIOGqtMZJgwTyLRRTISUnYwSrGAUixnbDwqdVjzxIiJAsFGLJmlgSmPGEGcmXgvXDLAyWDzswQkIKnCiczIRFtsdrU");
    string Iupot = string("PRDmQRoquiLUtEGxdhcITGyovVkiYGVHCTdnoMiuwbPoIdJvWSbIzhBMsPVOIqVFzVZABAtaSSvwwPHwulRAyXUonOOOGuTyKpSnlbXysSqnMfTthApBnTiKPrdCyYPWfkSFZiyZcPqNBlcyKEHCOMcXNTCgcfGUuyhHvWSVOJnRAzIEtGJcODPvRVzRGDeqwfXCFZPNgLGqZqaUrFuTrGdZTtXAFbpEDCJsghuvZAYyQhdjSKvQVYOBXNqFPkF");
    int JjPpTNphOmH = -1120554932;

    for (int uDcjESAPvsECX = 431155584; uDcjESAPvsECX > 0; uDcjESAPvsECX--) {
        nbdsw = Iupot;
    }

    return JjPpTNphOmH;
}

int OgQFydRqhqICGiu::qHVtswXe(string JRJLcTAtn, bool EyzwvnTOjkh, double AETybiYVjMtsJ)
{
    int BmJYW = 2045150418;

    for (int OBcIud = 1712598573; OBcIud > 0; OBcIud--) {
        continue;
    }

    return BmJYW;
}

bool OgQFydRqhqICGiu::kJltyBYbqxNtp()
{
    int ExivvZMAbFYOWUyW = 204622347;
    int GXKjSTgp = 252402828;
    bool tBQYeaNusZrbsIP = false;
    bool pWcBMikzmHIDEwE = true;
    bool hdwXe = false;
    string jpMbEa = string("mWDmSAvtwTMHqcpvOpElROYASOmGaZNgjAkVTMYYfpgPnuiAvUCWiqyQOeNJKtrKhgSfkoQvdowaOKJXXjnzwydmKxTjpxihlbUJYlZtnyCGulTeXbnKIJqpQrsjsODGItmuYTFwTTWSRUDxuGFTypCiWwvAqevETzZnFJeCGFCLQZkuJQBBOfFBdVtayCbOQDQWVfwtuwBbkzjTfdUsoEiqDMuEFRRulBizSawcBWTxzWAmnwCoxwvipgR");

    for (int NAQvKQVWtDDj = 520688834; NAQvKQVWtDDj > 0; NAQvKQVWtDDj--) {
        hdwXe = hdwXe;
        pWcBMikzmHIDEwE = tBQYeaNusZrbsIP;
        tBQYeaNusZrbsIP = ! pWcBMikzmHIDEwE;
    }

    for (int kkrKuYkuoonVLy = 1167169344; kkrKuYkuoonVLy > 0; kkrKuYkuoonVLy--) {
        tBQYeaNusZrbsIP = tBQYeaNusZrbsIP;
        hdwXe = ! pWcBMikzmHIDEwE;
        hdwXe = pWcBMikzmHIDEwE;
        hdwXe = tBQYeaNusZrbsIP;
        ExivvZMAbFYOWUyW = GXKjSTgp;
    }

    return hdwXe;
}

void OgQFydRqhqICGiu::WLPFK(bool lamNxUWfmPyCA, double gebHxiyrJ, double JtZZHOLmjOO)
{
    double WEzBZhAPQvwryk = 1047023.1502488597;
    bool yQwJyrM = true;
    int lkHLmpyMFyXsqj = 1259048383;
    string nImIP = string("vtcGHAtiPrcOtiEUcCDhLSpBjHHNgZfIfoFvkdkBvyjUeKDlbcNmhXjXbhYpbpCBiLVlqgwbCQemBKHXgRArCytsYDhlBPliAbuAKbsHkKhkikISUxVelDOKLUctsKBjeLwzxQghnezGEDRrQkiEmXSSsQGuYRaDIaCnfAgYEYDMopFtLdhXcjWlVFnNMnNLQaHNdTmKkOT");

    for (int XluleSwFXFtoP = 1260956122; XluleSwFXFtoP > 0; XluleSwFXFtoP--) {
        WEzBZhAPQvwryk /= gebHxiyrJ;
    }

    for (int dARCIjoJZSPkgZW = 790621029; dARCIjoJZSPkgZW > 0; dARCIjoJZSPkgZW--) {
        gebHxiyrJ -= JtZZHOLmjOO;
        yQwJyrM = ! yQwJyrM;
        WEzBZhAPQvwryk = WEzBZhAPQvwryk;
        gebHxiyrJ = gebHxiyrJ;
    }

    for (int UWdNywCzJUXBtzD = 1903696804; UWdNywCzJUXBtzD > 0; UWdNywCzJUXBtzD--) {
        gebHxiyrJ -= WEzBZhAPQvwryk;
        WEzBZhAPQvwryk = gebHxiyrJ;
        gebHxiyrJ = WEzBZhAPQvwryk;
    }

    for (int slTdiiVjcplSoAG = 1237255827; slTdiiVjcplSoAG > 0; slTdiiVjcplSoAG--) {
        nImIP = nImIP;
    }
}

bool OgQFydRqhqICGiu::vRPsC(bool LikKxie, bool SSATqSOjgGhm, string lueIeAOiBUtIzQ, double EfyfYdmWsuMObO, string uIGlWrInOpnYDmRP)
{
    bool xlGzhwlGtZniTcDb = true;
    string thDpTlyGr = string("KufUQugUDwuRQsgAPYhMZRHouwiQpZoZATxqjRIugAyunsrmMzBXvoFJGEHSRTYZNbKkAbgrDMzkJJzDFYOLYLYamPlaznLnmJwZOFElAdfudUXtyzbqWzChymNFZrydPiFohRxHvKhchRVEOXVbifIXfbmIqSyZfJpcVkrQZEYXnVUiCgmLFteJEHzLwFQdapiBF");
    double PJIynr = -355108.39331272274;
    bool jEUWGlZhjWcGFRJd = true;
    bool LKRAsSDHfFFV = true;
    int GMVpSnJKz = -302808473;
    int FGFoUrrMypjkCNq = -344580455;
    bool fHBjaETnXC = false;

    if (fHBjaETnXC != true) {
        for (int oiJzPqsp = 1050243526; oiJzPqsp > 0; oiJzPqsp--) {
            xlGzhwlGtZniTcDb = jEUWGlZhjWcGFRJd;
        }
    }

    for (int KXWLudrft = 834702343; KXWLudrft > 0; KXWLudrft--) {
        continue;
    }

    if (jEUWGlZhjWcGFRJd == true) {
        for (int SRzrdmKV = 215371514; SRzrdmKV > 0; SRzrdmKV--) {
            lueIeAOiBUtIzQ = uIGlWrInOpnYDmRP;
        }
    }

    if (LKRAsSDHfFFV == false) {
        for (int ADXfTxLYUTCRl = 476607264; ADXfTxLYUTCRl > 0; ADXfTxLYUTCRl--) {
            continue;
        }
    }

    return fHBjaETnXC;
}

string OgQFydRqhqICGiu::YLhCCDXQtBrQ()
{
    double yefAGptWLUQwmytf = 114770.83925699712;
    string MnqmnXOkBGvJJPnF = string("BmMGtbtUqMuMoZYyGXPFYolnUJkyDYsAXVYQRiqXUCYPygQVwKbPljXgIzMcZNixoGXKiRLpfwSgMcycQualHzkzWZjSReQWmqQwBzdsuTZxYuSIfxOiGCjCBiPFkVZADAqRWqVeLWAAAZVpNUtqhHWrNHnxxUbCqTNCzvUhlsyfTlXptNaEMPJVqyTnzGOAJZnovCLvUWSYOxIUtXuXSNrBaTCDBTArjqhqDhVQjfLdRiFSpiczfjuHtGAe");
    bool bpVtdRzeoKgR = true;
    int wzkvMPYVayIzYRQj = 742395640;

    for (int LUcXxUs = 564158084; LUcXxUs > 0; LUcXxUs--) {
        wzkvMPYVayIzYRQj /= wzkvMPYVayIzYRQj;
        MnqmnXOkBGvJJPnF = MnqmnXOkBGvJJPnF;
    }

    for (int NNIYuHhCc = 450823530; NNIYuHhCc > 0; NNIYuHhCc--) {
        continue;
    }

    for (int RjJtjwMRSgaGSeUJ = 56105715; RjJtjwMRSgaGSeUJ > 0; RjJtjwMRSgaGSeUJ--) {
        continue;
    }

    return MnqmnXOkBGvJJPnF;
}

double OgQFydRqhqICGiu::WhZbIkSAbLjDfsQz(int lWwzIjHAZISqpO, double JzEaUsYz, double gkkpAcamDdJ)
{
    double SBnlpTPg = -442084.1351311141;

    if (SBnlpTPg <= -442084.1351311141) {
        for (int UPLGvJBKL = 604939478; UPLGvJBKL > 0; UPLGvJBKL--) {
            JzEaUsYz *= JzEaUsYz;
            SBnlpTPg = JzEaUsYz;
            gkkpAcamDdJ /= JzEaUsYz;
            JzEaUsYz = gkkpAcamDdJ;
            JzEaUsYz -= SBnlpTPg;
        }
    }

    for (int xFDMScGGZ = 200458336; xFDMScGGZ > 0; xFDMScGGZ--) {
        SBnlpTPg -= SBnlpTPg;
        JzEaUsYz /= JzEaUsYz;
    }

    for (int SHTJdjzksOghccQU = 385517190; SHTJdjzksOghccQU > 0; SHTJdjzksOghccQU--) {
        SBnlpTPg *= gkkpAcamDdJ;
    }

    return SBnlpTPg;
}

void OgQFydRqhqICGiu::GkYMhIwdRfVfHuIl()
{
    double LnyfadxuSU = -942334.2501354347;
    bool fRNZuuZ = true;
    int VIouRrIKXAihVk = 1319364061;
    double lHJSWlEDSGcd = -17179.047977855455;
    double rEmWKZiirC = -556467.2663016357;
    int imnPP = -1376436057;
    bool kgAVxTdH = false;
    double aXajI = 813484.2651861741;
    int XUXSBBMzKi = 180893073;
    string xQWxzyHIS = string("UFMarjtGNFElsQpEaZRDZnfCIuOMhbidnvfHpBOjlQafuATQmjAYTuGMoSUIbV");

    for (int ycUkPpB = 1308364159; ycUkPpB > 0; ycUkPpB--) {
        rEmWKZiirC /= rEmWKZiirC;
        XUXSBBMzKi -= VIouRrIKXAihVk;
        VIouRrIKXAihVk -= XUXSBBMzKi;
    }
}

bool OgQFydRqhqICGiu::InUqvktSQmpBGkF()
{
    double uXbvIhRkWUZ = -266608.3204584188;
    bool ZiKxwgHAXfq = true;
    int cWWhzCaUbPR = 249701603;

    for (int UbBkeqwM = 1940977697; UbBkeqwM > 0; UbBkeqwM--) {
        ZiKxwgHAXfq = ZiKxwgHAXfq;
        uXbvIhRkWUZ *= uXbvIhRkWUZ;
    }

    return ZiKxwgHAXfq;
}

OgQFydRqhqICGiu::OgQFydRqhqICGiu()
{
    this->RusOubAkTLIGXyic(string("dzLIq"), -1450006504);
    this->aBYdYdsOoMoqNhl(string("CSWPNbHioFBhApAJcgdQMpIzPyKGICecPNIXMDSTcpXEKQVVoBPENoGCFOJeooBVQGBxIlbaVxHyiFMAMpZvTpNQoprdejAIRfScJHdEPjxrLJfQqAtutfYsKSdHwBNAbSDVxLkpneeDRrdpgdCWVFqJdresPjUDLXDsugYSNWimSBEddwrUhAHYZTpJqeWDRbLmUnlFqloOiQm"), string("lLTbHWetpkpKcPwTETQUSqynrMIrqYjHDklQbpubAKgOueOHafoOSHGqjUUlqKkPQPREmDAMKHKeMMtYEPlepEKNHLzAMJUMEVGEucxCgyn"));
    this->pkttO(false, -951568142, -233952588, -1354796294);
    this->zjkdMPRFR();
    this->QkBdCBkDOQZe(string("gSgJUSZBhDmzvONkXCSYQegAJMfrUTfouievEvrrLRczmMNVnCzYVQMDkgTEUPtAoxqyHHLTnqOLhllaWyDMogpRVacUHutHgjKhJJOgbbspMChlXsMfzXLmmJBYkcviIDClfxufJHfgmhyyeUlnCbJHFJIBCUmNAkHogAwFNZFLpOCVGRZEqhkTfvNPfBZWPEdITIBfuNPKmUyDoPgjLITw"), -1073845535, true, 476116.0505685306, string("dmybvsJbwGfscbehzZaLUTwusvrLI"));
    this->OElPJjUqfWY(string("HClJRtMMSL"), -495941.1382622524, 925289134);
    this->KTHLG(-187930.82492273362, false, 1028798.7460841996, false);
    this->OpGcVNwjExIhLaCR(string("bwiJRXbXrXDmqCWBrcTVZTTxgxHwFHkHDWxvZIwApbenILIXmBKjQjHRkmryknGtLgCwYwrEHJYdNmUToiucnTlxoGZweifqwUMVJxKIgjDEUUDaeHxfVTlwtwCzVRhQtldOkBtcHLkmyVEEWsCddQRvlHCMqaCVmXkgVfWHgtIOcHgqlldcYAHllwWCahZVRKlni"), -598145.6257047573);
    this->syjhuXDeX();
    this->gnlUWuUmWRGdy(string("CLlVlfmVSErXpptfMINUFxboQeiMPgvECBZnOilQuhWVtNIJLxhKLnxExOeHvMSPRKhCgHwmLbbvYgTujazKhQnvhSMvvTmqzRdTmpNNYwrjGMsrWCBXRkHRuuxvyYvZAYLkbxbDhKdcczuOurIozrKesoAYYJNkowwSJXnhQjhNRK"), -363572.9483295425, 1284999510, false, string("eEyilmhYQAgUqAJvJGbYUxzpuWQNQVaZwsGKxiTuXyZMBEXjIgWKoSjVKBilwSahgMbJYuxLiEpBGJvoRbxQOFBlCOaJzNXqachBfJhdUrkSHkNRjkxBPUgCcysIrQXYniIDMmPtkkcLwbOJjSCRLEUTDAIZs"));
    this->qHVtswXe(string("BLtyiLfxjxwjTlXJgOedZrRDjeQfcVInbyKwPguxnHoWkzzvcDRMZsTLmsJIKLYlfUmfxGqeAmasvwJAeEilIsTHqeNRveYSblUT"), true, 625233.3100174046);
    this->kJltyBYbqxNtp();
    this->WLPFK(true, 193834.0780083154, -553409.6389734879);
    this->vRPsC(false, false, string("YZHWyaLMNCgBLoNQOmirnQlsxWcOAYdbwuYNysDFECywKppRsEHPIUbail"), 832733.7979147586, string("GcWJxnrcgrTZWhaCkKTTEscPhZaPvPXFXqYoZTlVTGPSDuJAfbRADzicDLaOzzQogAgHZqbFRSaaynAUEDjsmBMbmfGkUiFnpLnrKVddjvVq"));
    this->YLhCCDXQtBrQ();
    this->WhZbIkSAbLjDfsQz(1907392959, -458730.4129637643, 357233.5229105462);
    this->GkYMhIwdRfVfHuIl();
    this->InUqvktSQmpBGkF();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CJEHbOT
{
public:
    double sRuQatWlLJJEHBj;
    string xesSIye;
    string ADMPRvIPfyFEGUMP;
    int KAdXsCDVeuH;
    int bMyAE;

    CJEHbOT();
    void akbRvGxGVZdalUF(string DSSctv, bool BcpAEEjvwrMo, string FvrygydxNJM, bool OdQigaHciAsKPtlE, int tBzOma);
    void hZpKY(double yJBjAzhmVXid, string ovqytRHu);
    void tGOMIeQbV(int ioaXfrPbG, int pCuGoem, bool dWAdfDbBpy, int cLBaDdRbRQFMdy, int psTZYmPJGozv);
    string SuOwfkZrBO(string qjaag, string PXlBVDUJtsisMx, string rMbzQaCbNjvHOxgP, int brPWemymIFqUJxmm);
    double ykBfBUmNRzr();
    double RFNOM(string bPenNiMgWvT, int hvBjSFaNghyfuuN, string aAlLJpOJeyhAX, double kjmtnOVscthEns, double UYvCLNawFl);
protected:
    bool uYAXoUtsPxT;
    double rHIVUykFQqE;
    double kAZrWGg;
    int lWntOsh;
    bool GcuuJRiNP;

    string qUEkaOCCQ(string RDLAJOVRcOq, bool ZsWMmFCBoOGp, bool XKpKaQIlhyoF, int MdVexsu);
private:
    string VedMkCzmcfw;
    int gakdMbomOYZND;
    bool cHbljuhdjiCrx;
    bool iQojzcVSPwjp;
    bool DEYzPd;
    int LoQRMzwsWhViNp;

    double EHCtiEGkcsaQAKG(int SyKYGcfTXkdt, int VwNYIpiFbnzVI, bool HNnLAlHUbBcwUfmV, double dKNiHkhBQUz);
    bool itdhL();
    double JPBHtWulgLVpb(bool ebGRLqRGXOPoH, int jXjeWLKSVfkrGn, double brBeqxVzbvQn, int ICCDVQDbSDSLstSA, bool OQEDxQRVfRjeXUMt);
    double EsQiqAHSzR(double IvnVt, bool GbryNMvnpe);
};

void CJEHbOT::akbRvGxGVZdalUF(string DSSctv, bool BcpAEEjvwrMo, string FvrygydxNJM, bool OdQigaHciAsKPtlE, int tBzOma)
{
    string AOPusiwbcWWRhP = string("JPTKFtIafgjyWxQIZTDGCJUyOcGTRNHXegWTKmrYPcMtBpXBPXmTSVEXlKVqooWvjjZFNjDMXdNzSBgeupWwMcEefzMdBjezFEwEdduFUjSIgGaCZWBnTXEHBQemvgXpJiIeoHPDmbDaFqs");
    int kcMyJPlQd = -694198125;
    double ZNyywOLPmmx = 559934.9275668727;
    int EBVbWmgfJUBzekY = -1338096072;
    string ncqgJ = string("dnGxunSfWQZtSPXzWBjhcHonLUgfXzJawVtVRObahGzqGBcNLPvrcjzIiegfinFqhcWVlwOIATHfYrDaCGOkNjYoUJKdnQJcIETSLqeDjevQBwMZbqhMxuMSzuOdeMoxAKA");
    string FYKdfMxjU = string("JyGVeHvrGYJyoFiEfTwpeEObpUshpOUqVDUNhOpSivqslidEsQGfiXTNhyABtUxIZFPbqrXRaNqRgpjUEGKnztRkHeRtYaXXEeCdGBirdEWdhrsEwdZfCfuohcRoaJhYNDWfGiWWrtHdKEBwDORenHZzUPL");
    double lipfdY = -812948.8364508112;

    for (int dcWtnZVPQVxizO = 1555672793; dcWtnZVPQVxizO > 0; dcWtnZVPQVxizO--) {
        continue;
    }

    if (tBzOma < -278943090) {
        for (int rEqQvhGelgvIYZZ = 676547900; rEqQvhGelgvIYZZ > 0; rEqQvhGelgvIYZZ--) {
            EBVbWmgfJUBzekY *= tBzOma;
            kcMyJPlQd += EBVbWmgfJUBzekY;
        }
    }

    for (int zDkACbQxRiItGhOi = 463923712; zDkACbQxRiItGhOi > 0; zDkACbQxRiItGhOi--) {
        FYKdfMxjU += DSSctv;
    }
}

void CJEHbOT::hZpKY(double yJBjAzhmVXid, string ovqytRHu)
{
    int hoxfKCXXd = 102183089;
    int UmIcg = -85345808;
    bool jOvfgeN = true;
    int TMcyuWLsaw = -1110660463;
    string KkXoQVInGRyNeT = string("HawQolNaYjBYeizAgzGFNplgfJaCzmpcjhywwUpVTSThwLWRJwLMtsQPoGLoQdQMiMnDjVpdPAaXnRkLzLHKlnyJDavWMzZprAlZfDdMpPizRGCoeNjcGLteeKQgWNkrPnCzfqYuDNcBuvRyDeqlRtmZKDwgNyCnCLxtWyjczPJQDOZVEmCyCtZuoFLjmdQiEaqUpPBtBubOn");
    string dAzXLRMbIsuLiXv = string("nSUbQcCeCaXyDSWjqvVhemhUVnnwGLVRBZeeHxxgqQwPPAHliPIVVGZIkMUuuPGGBfSbWlyAeYbEYCwOLqVbnfwDFxdWjnqhHEYVFpALIVOV");
    double fDGZXYXjTZQogp = 558842.5784152797;
    bool SEoTjt = false;

    for (int OWbaOdtlSMoSEE = 993692051; OWbaOdtlSMoSEE > 0; OWbaOdtlSMoSEE--) {
        hoxfKCXXd /= UmIcg;
        dAzXLRMbIsuLiXv = ovqytRHu;
        SEoTjt = ! jOvfgeN;
    }
}

void CJEHbOT::tGOMIeQbV(int ioaXfrPbG, int pCuGoem, bool dWAdfDbBpy, int cLBaDdRbRQFMdy, int psTZYmPJGozv)
{
    int pDItEJBQtuKuOwe = -1809847394;
    string SVyDIoCoJsi = string("quiRQcHgScx");
    bool tvUwviTEnrQGjSHP = true;
    double FSCIPJy = -747870.6442607453;
    int WGorY = 1829455120;

    for (int kJYBA = 1984527936; kJYBA > 0; kJYBA--) {
        ioaXfrPbG /= pDItEJBQtuKuOwe;
    }

    for (int EJNgzh = 221187706; EJNgzh > 0; EJNgzh--) {
        pCuGoem = pDItEJBQtuKuOwe;
    }

    for (int QVVHURYbtDvQdUpe = 558034618; QVVHURYbtDvQdUpe > 0; QVVHURYbtDvQdUpe--) {
        pDItEJBQtuKuOwe /= ioaXfrPbG;
        cLBaDdRbRQFMdy /= WGorY;
    }

    for (int uPjFYPrPalu = 1731320898; uPjFYPrPalu > 0; uPjFYPrPalu--) {
        ioaXfrPbG /= cLBaDdRbRQFMdy;
    }

    if (psTZYmPJGozv <= 1829455120) {
        for (int nyQQIYiQv = 1316273497; nyQQIYiQv > 0; nyQQIYiQv--) {
            continue;
        }
    }
}

string CJEHbOT::SuOwfkZrBO(string qjaag, string PXlBVDUJtsisMx, string rMbzQaCbNjvHOxgP, int brPWemymIFqUJxmm)
{
    string FXvjNGSbrVLX = string("AhPNbuqHoICYOIaJYTMCorOpiFBRpzojmiwcommVVAmEXMaroJupKyDIfdXOsctjoQgQmGjefeqQeKFkprIYexHeMVmvBhziECReGzghokCqmIYHyenZmiZhRzEtQFUToiCYQkmSinxsszAYGahZyMJswqkKYfdIRFFOsRHWWhfunKOoqCUadKMPIKedDlMSNpTwmoMMohwrEKpoIzP");
    double dBhEpnv = 497744.0962372287;
    bool vReZkVAo = false;

    if (PXlBVDUJtsisMx < string("AhPNbuqHoICYOIaJYTMCorOpiFBRpzojmiwcommVVAmEXMaroJupKyDIfdXOsctjoQgQmGjefeqQeKFkprIYexHeMVmvBhziECReGzghokCqmIYHyenZmiZhRzEtQFUToiCYQkmSinxsszAYGahZyMJswqkKYfdIRFFOsRHWWhfunKOoqCUadKMPIKedDlMSNpTwmoMMohwrEKpoIzP")) {
        for (int PFkOzeXD = 1535358174; PFkOzeXD > 0; PFkOzeXD--) {
            FXvjNGSbrVLX += FXvjNGSbrVLX;
            FXvjNGSbrVLX = rMbzQaCbNjvHOxgP;
            rMbzQaCbNjvHOxgP = PXlBVDUJtsisMx;
            FXvjNGSbrVLX += PXlBVDUJtsisMx;
            rMbzQaCbNjvHOxgP = rMbzQaCbNjvHOxgP;
        }
    }

    return FXvjNGSbrVLX;
}

double CJEHbOT::ykBfBUmNRzr()
{
    double RFmvIcp = 460311.54644825024;
    double yBInRqLAsW = -502703.89404743904;
    int ajVjlfatHwwzZa = -784256425;
    string ZCwEYMlTUtmrk = string("XLANmRsbVsArakhhLlIGSPsJTALeOixuLDoXJVugDMKzHDVzyyXglhTvJpMYorlEZBhwwZEjhZWQZtDLmmlPulCdpusbbVHqlVJVWPVTaUjdJPseneszhCSqvHGvCWDeKVAVbMebCeysqgeNDeGuaKNsCUWsJBXBLtqCghJzyOIyLSVJCIAiOYqaaIouYHWlDyxTIamrycaZUZRRjzyxqthMxQBICs");

    if (ajVjlfatHwwzZa >= -784256425) {
        for (int rneSFIEkCTp = 1693648401; rneSFIEkCTp > 0; rneSFIEkCTp--) {
            yBInRqLAsW /= yBInRqLAsW;
            yBInRqLAsW = RFmvIcp;
            yBInRqLAsW = yBInRqLAsW;
        }
    }

    for (int RVJbYnEAX = 1361260629; RVJbYnEAX > 0; RVJbYnEAX--) {
        continue;
    }

    for (int DLUuld = 1754676153; DLUuld > 0; DLUuld--) {
        continue;
    }

    for (int YXoUVkwzRlnNOJAz = 782288844; YXoUVkwzRlnNOJAz > 0; YXoUVkwzRlnNOJAz--) {
        continue;
    }

    if (RFmvIcp >= 460311.54644825024) {
        for (int WOjZUzRayMYi = 2121688754; WOjZUzRayMYi > 0; WOjZUzRayMYi--) {
            yBInRqLAsW += yBInRqLAsW;
        }
    }

    if (yBInRqLAsW <= -502703.89404743904) {
        for (int MMqaPzLCBeyQoey = 1328502645; MMqaPzLCBeyQoey > 0; MMqaPzLCBeyQoey--) {
            yBInRqLAsW *= yBInRqLAsW;
            RFmvIcp /= yBInRqLAsW;
            yBInRqLAsW -= yBInRqLAsW;
            ZCwEYMlTUtmrk = ZCwEYMlTUtmrk;
            RFmvIcp -= RFmvIcp;
        }
    }

    return yBInRqLAsW;
}

double CJEHbOT::RFNOM(string bPenNiMgWvT, int hvBjSFaNghyfuuN, string aAlLJpOJeyhAX, double kjmtnOVscthEns, double UYvCLNawFl)
{
    int UZFekCfJXFajW = 1303847442;

    if (UYvCLNawFl > -120692.51216794025) {
        for (int GrLNUgocdcByFDR = 1164031439; GrLNUgocdcByFDR > 0; GrLNUgocdcByFDR--) {
            UYvCLNawFl -= kjmtnOVscthEns;
        }
    }

    for (int zERNR = 1817236894; zERNR > 0; zERNR--) {
        hvBjSFaNghyfuuN -= UZFekCfJXFajW;
    }

    return UYvCLNawFl;
}

string CJEHbOT::qUEkaOCCQ(string RDLAJOVRcOq, bool ZsWMmFCBoOGp, bool XKpKaQIlhyoF, int MdVexsu)
{
    int eOZwlhotdUxVoehV = 1518648108;
    double KoWJJNKXGRabD = -989417.166810407;
    bool FjnBxIqBcSbNsF = true;
    int wmomnHYQaUiWi = -349788953;
    bool wPmVLzDP = true;
    double wBmuk = -523043.55103623966;
    double dWddopPJMJvTDcfg = -478972.2810309394;
    bool xIoAuLowUafHqOC = false;
    int ZQIGafvUaDjuG = 1628769688;

    if (wBmuk == -478972.2810309394) {
        for (int dhIAjYF = 1561467922; dhIAjYF > 0; dhIAjYF--) {
            wmomnHYQaUiWi += MdVexsu;
            FjnBxIqBcSbNsF = FjnBxIqBcSbNsF;
            XKpKaQIlhyoF = ! XKpKaQIlhyoF;
        }
    }

    for (int KVSLUjkgkiimg = 471119554; KVSLUjkgkiimg > 0; KVSLUjkgkiimg--) {
        continue;
    }

    for (int VHHglsCiNQllR = 469352310; VHHglsCiNQllR > 0; VHHglsCiNQllR--) {
        wPmVLzDP = ! XKpKaQIlhyoF;
        ZsWMmFCBoOGp = ! xIoAuLowUafHqOC;
    }

    for (int jkNUEWupXyDBIx = 662424561; jkNUEWupXyDBIx > 0; jkNUEWupXyDBIx--) {
        continue;
    }

    return RDLAJOVRcOq;
}

double CJEHbOT::EHCtiEGkcsaQAKG(int SyKYGcfTXkdt, int VwNYIpiFbnzVI, bool HNnLAlHUbBcwUfmV, double dKNiHkhBQUz)
{
    int yLJeVDKBoJQRwy = -620015952;
    int QRGsxHLerisWTvz = 1379705000;
    bool uqUWP = true;
    bool rQpaleEcQh = true;
    int bShVlfSo = 817090748;
    bool wSiSPOVWbk = true;
    bool jeNaqNlLNwRzm = false;
    bool hQoLybj = false;

    if (QRGsxHLerisWTvz < 1379705000) {
        for (int Ldwynzgra = 1584334348; Ldwynzgra > 0; Ldwynzgra--) {
            rQpaleEcQh = uqUWP;
            QRGsxHLerisWTvz -= QRGsxHLerisWTvz;
            VwNYIpiFbnzVI += SyKYGcfTXkdt;
        }
    }

    if (QRGsxHLerisWTvz == 1523216266) {
        for (int FSNoUEJDK = 1889730219; FSNoUEJDK > 0; FSNoUEJDK--) {
            rQpaleEcQh = wSiSPOVWbk;
            SyKYGcfTXkdt = QRGsxHLerisWTvz;
        }
    }

    if (uqUWP != false) {
        for (int uCRyU = 2126111635; uCRyU > 0; uCRyU--) {
            VwNYIpiFbnzVI = VwNYIpiFbnzVI;
            HNnLAlHUbBcwUfmV = ! wSiSPOVWbk;
        }
    }

    if (VwNYIpiFbnzVI > 1523216266) {
        for (int DHyyNrIGICwNtk = 1849484523; DHyyNrIGICwNtk > 0; DHyyNrIGICwNtk--) {
            bShVlfSo = QRGsxHLerisWTvz;
            SyKYGcfTXkdt -= VwNYIpiFbnzVI;
        }
    }

    for (int bGiyPkR = 1279255994; bGiyPkR > 0; bGiyPkR--) {
        uqUWP = ! wSiSPOVWbk;
        uqUWP = rQpaleEcQh;
        bShVlfSo += VwNYIpiFbnzVI;
        uqUWP = hQoLybj;
    }

    if (yLJeVDKBoJQRwy > 817090748) {
        for (int XBycNAUpBWsb = 309042322; XBycNAUpBWsb > 0; XBycNAUpBWsb--) {
            HNnLAlHUbBcwUfmV = ! wSiSPOVWbk;
        }
    }

    return dKNiHkhBQUz;
}

bool CJEHbOT::itdhL()
{
    bool dyGfsgzEoKslJpsN = false;
    int byWklWDCqlUFLSo = -1987717580;
    int TNQpDUHJ = 427404251;

    if (TNQpDUHJ > 427404251) {
        for (int ORyKrewj = 434979278; ORyKrewj > 0; ORyKrewj--) {
            byWklWDCqlUFLSo = TNQpDUHJ;
            TNQpDUHJ *= TNQpDUHJ;
            byWklWDCqlUFLSo *= byWklWDCqlUFLSo;
            TNQpDUHJ += TNQpDUHJ;
        }
    }

    if (TNQpDUHJ < -1987717580) {
        for (int lQDtgTlKzQ = 348645644; lQDtgTlKzQ > 0; lQDtgTlKzQ--) {
            byWklWDCqlUFLSo -= byWklWDCqlUFLSo;
            TNQpDUHJ = TNQpDUHJ;
            byWklWDCqlUFLSo /= TNQpDUHJ;
        }
    }

    for (int IeynKRgF = 547159318; IeynKRgF > 0; IeynKRgF--) {
        TNQpDUHJ -= byWklWDCqlUFLSo;
        byWklWDCqlUFLSo = TNQpDUHJ;
        byWklWDCqlUFLSo *= TNQpDUHJ;
        byWklWDCqlUFLSo = byWklWDCqlUFLSo;
        byWklWDCqlUFLSo /= byWklWDCqlUFLSo;
    }

    if (dyGfsgzEoKslJpsN == false) {
        for (int SxrljoNFjrgeGo = 521075142; SxrljoNFjrgeGo > 0; SxrljoNFjrgeGo--) {
            TNQpDUHJ *= TNQpDUHJ;
            TNQpDUHJ /= TNQpDUHJ;
            dyGfsgzEoKslJpsN = ! dyGfsgzEoKslJpsN;
            dyGfsgzEoKslJpsN = dyGfsgzEoKslJpsN;
        }
    }

    return dyGfsgzEoKslJpsN;
}

double CJEHbOT::JPBHtWulgLVpb(bool ebGRLqRGXOPoH, int jXjeWLKSVfkrGn, double brBeqxVzbvQn, int ICCDVQDbSDSLstSA, bool OQEDxQRVfRjeXUMt)
{
    int aHGzPUlwBWPcmcVH = -1096439643;
    double cDjlQiQc = -854879.2166602127;
    double SWvxrmgcitfgjB = -175051.72157796705;

    if (ICCDVQDbSDSLstSA >= -1096439643) {
        for (int DsCBF = 1293153240; DsCBF > 0; DsCBF--) {
            continue;
        }
    }

    for (int CPIoK = 780929717; CPIoK > 0; CPIoK--) {
        aHGzPUlwBWPcmcVH += jXjeWLKSVfkrGn;
    }

    return SWvxrmgcitfgjB;
}

double CJEHbOT::EsQiqAHSzR(double IvnVt, bool GbryNMvnpe)
{
    double hzPgcdfPk = 745388.4776341468;
    int QCtOvURLLzu = 884289107;
    int YFHZpCpCi = -763825862;

    if (YFHZpCpCi > -763825862) {
        for (int YVZKrBPpVH = 1884935850; YVZKrBPpVH > 0; YVZKrBPpVH--) {
            continue;
        }
    }

    for (int GQgFNf = 1052309674; GQgFNf > 0; GQgFNf--) {
        IvnVt /= IvnVt;
        YFHZpCpCi = QCtOvURLLzu;
    }

    for (int ngtTUQXsoBfKE = 359468074; ngtTUQXsoBfKE > 0; ngtTUQXsoBfKE--) {
        IvnVt -= hzPgcdfPk;
    }

    for (int xGdBeMktHIM = 1317749269; xGdBeMktHIM > 0; xGdBeMktHIM--) {
        continue;
    }

    for (int YwzjfAynAgRAHI = 57045061; YwzjfAynAgRAHI > 0; YwzjfAynAgRAHI--) {
        IvnVt = hzPgcdfPk;
    }

    if (YFHZpCpCi >= -763825862) {
        for (int fQkgyj = 900669236; fQkgyj > 0; fQkgyj--) {
            hzPgcdfPk = IvnVt;
            GbryNMvnpe = GbryNMvnpe;
        }
    }

    for (int alcpjhEmjZ = 1722024814; alcpjhEmjZ > 0; alcpjhEmjZ--) {
        continue;
    }

    if (hzPgcdfPk <= -801321.19209796) {
        for (int YhgVrz = 1424145031; YhgVrz > 0; YhgVrz--) {
            GbryNMvnpe = GbryNMvnpe;
        }
    }

    return hzPgcdfPk;
}

CJEHbOT::CJEHbOT()
{
    this->akbRvGxGVZdalUF(string("XiAMkNYouUIyIImXQSkhxznUEzednMLK"), true, string("VoHTFdz"), true, -278943090);
    this->hZpKY(-66645.46924074565, string("xVmppUWtCYlDhXEbrAZvKscLfmfVfIPwlWdZMQaVKQLVQIdaEJwUEydCoxsaIuPUaTqGlzahgnUSxgWRVRqqEutfMZpodiNmZnmlXSgCwmBGHXTnipml"));
    this->tGOMIeQbV(-825459933, -1867222456, false, -1797242338, -608834933);
    this->SuOwfkZrBO(string("fjpIvekBpbhqJTjuMpkTQSwfOqkhfNZmHZGtUYxaWeWAzbCVFGPwvLtflNCRmOpFUVuCypHQFsKZCbEnZwepUmReCQkqjkZxiExezPapPYwsFRTzpSZtBSZShxDvmQMmqNydmxsvjEmiAMqfYKWFKTJYfRyqgZeqfuaKOFXwXQJsKsNmeXhTIdrmKHYsDATckxZSEwRvShwuzGfEFFNfHXwbBkrzrANwrikNRZSBdpoWxSCzxcpoLjOVdQyuA"), string("UWpXptNdzjNUQVSTFzAsTzTlmwsWbOudtosFTHoyslCEGzJAlzhSrqOqBHjJtEzrdLsbRCuuncVZZvQxsmltPCVWxvzdGqZkNjofvUhOMFXbRRM"), string("fFhyKAgGLqSuGCzOElytJTmRvIFnRAQFCzZSixMGoqAHUfuDAplStGnrXAMKfWvQTEHsqaeIbgveLcgfiMMZVcSnwkzfKUEtGk"), 1241436921);
    this->ykBfBUmNRzr();
    this->RFNOM(string("oTBLwgCczXpXCgpsZvmutCTKAsUIQvzYCcRCraTYoOKVlreadkfqOpoRjfEqHJPiikrGtmiuNJZYSQTaRvbgTZBfbBkpzjtRblMRBNlVHNzpTcOcvebbAbJjKOKVwuCcc"), 2045047843, string("rRIGeOmRskEnnxIYLnDVIvNxunAKmRiLwRnJSmYSqraaLRfvGKMbaCXYhrmWdORkoESJNPTHmCRSRIbXkOUpVzNofYUsjRZNwuoArWfVBZnSztgJZFrZltRNYMGogRIBBmTqpBaAKDzZwOgURNZatLxducbpvLGXzwjxSnECHYkbZuLSvDslDDVEQKsSiDBsUIuJKTgYzvfTwcwsNItNhqHXbkGWiehGBKpFM"), 610095.986767107, -120692.51216794025);
    this->qUEkaOCCQ(string("nnDNqirDjQFGAufSXoznHTfrNPemotULkHdhAauYpnApLqRDiteTvhUaVcGlGVZqeAemoptUhygmRMIDmBfVuaAeLRWaKWfGRnJPQxRIGinJJnEUJkrmmnBhyGanZLisYNblyirtmFif"), true, true, -915936171);
    this->EHCtiEGkcsaQAKG(1523216266, 1126588747, false, 987126.092726344);
    this->itdhL();
    this->JPBHtWulgLVpb(false, 2070533122, -358229.04595361766, -757767298, true);
    this->EsQiqAHSzR(-801321.19209796, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dpraSXUFZxLN
{
public:
    double rAAVfBGKhWsmszi;
    int bKPvpWDtLbkiGrl;
    int XIMcSugIjAWX;

    dpraSXUFZxLN();
    string pOHtvWw(bool wiLohGy, int ZgnBxBs, string OHCgGYzQ);
    int KHpuRdoUshIV(double asBlxFgYgrspRUH, string eRTTyBwvqlrPEaA, double drXjW);
    int KTfidPHVTjdFBth(int MpqAmBATVRMbIzlg, bool MvlHs, double byqIbXhOvuQyrC, double LSFceGgKjACoj, string cEYbLVXsnJRKJ);
    double AAeacdjZru(bool yaVfOS, double wIxVGAauwAUxl, bool SgzFYBNggEXbWlg);
    string eDsHnVCqmU(double GBffHBPeuwQYvomo, string NDxhzRK, double farKXAmNyGSR, string cMdcbSwRRf, int HsaYyxkNqCMkb);
    string dlFQaKPA(string Icsgu);
    int vylstJv(string WpHZOP, double dWAzVPze, string AjAXVdY);
protected:
    string nTFzgyl;
    int rDucAudmcRcnn;
    int JyfSZsxagXVvrO;
    int YFuhqTuoDvMygqY;
    double kScpmRcIKV;

    string vzpaElUCYlVRC();
    void oTvCU();
    int NRbfKi(bool XAYWMvxWWRQ, int GyVtkfPgMVlblNFL);
    double zuEMZwwIYq();
    void jgPiLx(bool oUIhb, int ciSDWbnSLpkvmLfJ);
private:
    bool pvDMwLtnOAAy;
    double grnjFKoZthBjm;
    string opzov;
    int hFjLlOsZLovI;
    string FyejrMKG;
    int OyNoglktYznKiXQt;

    int IzFbsGvaphdldwLv(bool iMCRsMp, string FZFvYD);
    double GHvBkKu(double XqBrxjgya, double UGugG, int sTlAhnmtTaS);
    bool OIdXf(double HXtnGX);
    void vQOHQOFBFPPCGlFs(bool ukpxOcMgJlSxxT, int gOHBFI);
};

string dpraSXUFZxLN::pOHtvWw(bool wiLohGy, int ZgnBxBs, string OHCgGYzQ)
{
    int ULYFjBwSBGhjqf = 119124748;
    bool hubQrbUpIrV = false;
    double GIpswLVJIN = -547057.2110756378;
    string JOkUsX = string("WDSradSlRCs");
    double qBYiYNwGhqcduAF = 449834.0396893113;
    bool PzjiJk = false;

    for (int TpWjSEUdn = 459329677; TpWjSEUdn > 0; TpWjSEUdn--) {
        wiLohGy = ! PzjiJk;
    }

    for (int wQLMJGhlFsAT = 1744231813; wQLMJGhlFsAT > 0; wQLMJGhlFsAT--) {
        JOkUsX = JOkUsX;
    }

    for (int XwOWlp = 930960951; XwOWlp > 0; XwOWlp--) {
        PzjiJk = hubQrbUpIrV;
        hubQrbUpIrV = ! hubQrbUpIrV;
        ZgnBxBs *= ZgnBxBs;
    }

    for (int ivVGRGRvaz = 560668976; ivVGRGRvaz > 0; ivVGRGRvaz--) {
        wiLohGy = PzjiJk;
        ZgnBxBs = ZgnBxBs;
        JOkUsX = OHCgGYzQ;
    }

    for (int YmzdmTdC = 934589711; YmzdmTdC > 0; YmzdmTdC--) {
        wiLohGy = wiLohGy;
        wiLohGy = ! PzjiJk;
    }

    return JOkUsX;
}

int dpraSXUFZxLN::KHpuRdoUshIV(double asBlxFgYgrspRUH, string eRTTyBwvqlrPEaA, double drXjW)
{
    int XbRkLiPLHGpTtufa = 1306678230;
    bool XZNzubhWAq = false;
    double AapUX = -155216.21208884649;
    bool jszCr = false;
    bool fZhSlXzi = true;
    string GLbIjTqCXDib = string("oMtnbCSxfmrmcXpOdrPGJUUDapCnGXOFJOiUCtUrWrmaoiGeJXoEhNeWDJjVftrlukKyyprRRUZihdVonrlbXQDNRbAbwZbvyvOpPQzPtZgJJYqHQxBqbfGRImWqhhmibpWgAPkuQevMNQqocmFDIonVgmkcZUzvMDygCdzBxCUniBmiumnVtBoaBgoBqVgtvQEQCBEVKvOdSjeiuIHtwrFDeEILLAzMbhOSOxLUTBkWJFuRTGWpiYsHgjlGdRe");
    bool ejMdWjfmYsWPdI = true;
    double TfdZeZ = 332321.8910722288;
    double SBbScZTwEj = -230279.00459354115;

    if (TfdZeZ != 332321.8910722288) {
        for (int OrAHlDgmcPM = 1240827057; OrAHlDgmcPM > 0; OrAHlDgmcPM--) {
            asBlxFgYgrspRUH *= drXjW;
        }
    }

    return XbRkLiPLHGpTtufa;
}

int dpraSXUFZxLN::KTfidPHVTjdFBth(int MpqAmBATVRMbIzlg, bool MvlHs, double byqIbXhOvuQyrC, double LSFceGgKjACoj, string cEYbLVXsnJRKJ)
{
    int uxBOFTNwwtnwH = 295034105;
    string frAyidBaIs = string("uQzoXBhpvJYIeCIUOKOeQtewNEdyrdoYlEmlUsIUjWfBuqlEGpzkuYceAJRqWOhXasCbChkGzXRHwHqMLHtex");
    double NjqNYynfl = 629113.5328431176;
    bool fadMFhDD = false;
    bool VFElMSEsYfzMpUW = true;
    double UPifggs = 231285.721426158;
    string ZNuHWADA = string("IXprcQlxvNcDgZHCyVUJGswOxDaoij");
    string FAoiHwdPvlIKUZm = string("vpUOPTSObpVDaiqZUYDiPngIACGYXEVGWYppklVWHVIunyvzyIntvboxPDkotDfDPxlZjVpCIFUiktozJeEEnUJuO");
    bool ruDXijTdrLFs = false;

    for (int qbsulCsihiRpoNN = 977419583; qbsulCsihiRpoNN > 0; qbsulCsihiRpoNN--) {
        continue;
    }

    for (int lnnRMM = 422661081; lnnRMM > 0; lnnRMM--) {
        ZNuHWADA += FAoiHwdPvlIKUZm;
        cEYbLVXsnJRKJ += cEYbLVXsnJRKJ;
    }

    if (uxBOFTNwwtnwH <= 1553637187) {
        for (int DGYiWqv = 949987208; DGYiWqv > 0; DGYiWqv--) {
            continue;
        }
    }

    return uxBOFTNwwtnwH;
}

double dpraSXUFZxLN::AAeacdjZru(bool yaVfOS, double wIxVGAauwAUxl, bool SgzFYBNggEXbWlg)
{
    double jRJWgsfHmNEPpx = 140547.32021140907;
    int lYlmWFbebIJQtOf = -2110033320;
    int NZZEyXyj = 1797197092;
    string XpPPN = string("IXIFTWPzebumcBodFyAEAsTkWaPAoiwxYluwZaSUiqFCKYcmujykfYbaMarBZdyNVNTwzGFKaSOJkNaVOVRhCiDyrzbrkDhDJfrEqHjGwqoH");

    for (int ApQpHeRaHtVG = 423775006; ApQpHeRaHtVG > 0; ApQpHeRaHtVG--) {
        continue;
    }

    for (int zKfAKe = 592676128; zKfAKe > 0; zKfAKe--) {
        SgzFYBNggEXbWlg = SgzFYBNggEXbWlg;
        NZZEyXyj += lYlmWFbebIJQtOf;
        XpPPN += XpPPN;
    }

    for (int kdasztu = 1640780394; kdasztu > 0; kdasztu--) {
        wIxVGAauwAUxl = wIxVGAauwAUxl;
    }

    return jRJWgsfHmNEPpx;
}

string dpraSXUFZxLN::eDsHnVCqmU(double GBffHBPeuwQYvomo, string NDxhzRK, double farKXAmNyGSR, string cMdcbSwRRf, int HsaYyxkNqCMkb)
{
    string EGiSV = string("vSntRnnQqdCBINiyTjcQjCGnQEeyFCwNtcnkEEuLWvrMeQiwoxBLTwqNJsFpIzbJiVIkOCoPeTNOPhpjmMCurlygGzmqudPeUTrxdrIsbODzzdlEMeeRTDFmLSjBgMCUmYcfFdEDiORazsCtZ");
    double enxHrf = -295323.8669391085;
    bool ZTJhbgCXLXv = false;
    bool PvhXZCSi = false;
    bool tDNZjlqbpVqt = true;
    int flGantSfCRbQ = -1500129065;
    int mFPzgcdpD = -1271777466;
    string FmecHQhlRiDkZ = string("VILdMcRkTzWXzEgXfIrNEaxNztigcpcyYSIkAwIRrFdOkEFWUjZCmEtgrbOwFEOoZJUOQicdDloBCbzoyrwfcuFLNSmlJHBfQJqtEewdrwcqyLdCtfLKafImnwOKVOPanUgunczwBaukNeqVArNfPhtDdprhjAnFWcnnemukhKbnvdRaqsdtiLYnpQrhmBZlEZKIUzRdBZtDThgDuChQtHWPXcLTmVVtclPAlWuLuwRAPa");
    string RHSOmG = string("bfqtxghcjPXwTPaXsDxoOyVQLSRjOcFIvPxufRJDSaZQvCymKZORpMpvIsoCRrmoDBhWrzLfjxBrGSPdHAkBIRLvLsiGyfKDxkqulSDPBvvVPBMXeSJSuHIPPtDMySdDAIxSlGClIxDUivFhhEammkauDDlclgNpcZyhrUbFgWqCXjmJRLvkCgYuZGtBnilVMBkFNIUMPWqgoEBzZhtjayxaNGzucGlAWFrqVbJrgzcmfMmVcsOHnRKN");

    for (int oNiusfWeoni = 1951809922; oNiusfWeoni > 0; oNiusfWeoni--) {
        continue;
    }

    for (int HgiIBDdpz = 1198641221; HgiIBDdpz > 0; HgiIBDdpz--) {
        cMdcbSwRRf = NDxhzRK;
    }

    return RHSOmG;
}

string dpraSXUFZxLN::dlFQaKPA(string Icsgu)
{
    string bmJCZOrcYT = string("sLzUjnNSBvNgbEoKxrYDGlrmeKtixAikTYVGQmIFdnXChNajGVCiSIRtIPSRtGpUTuMmoIEbgKsAnsQxLcJvbPtgJEtbHucOAQOfUW");
    int jbUCCqv = 319013095;
    int jRqCQzxFus = -1639516640;
    bool AwXhtShTtwFtaFly = true;
    bool ZyMmCxfpNJnvnBPc = true;
    int hqGMXwxPrTmO = 1892428607;
    double RnlHDBy = 394335.0563590333;
    bool VgkEqfRKDcTbY = true;
    bool mxUlVTbtUQdbEOt = false;

    for (int YqgYO = 176761761; YqgYO > 0; YqgYO--) {
        continue;
    }

    for (int KsSZCcWy = 3082771; KsSZCcWy > 0; KsSZCcWy--) {
        continue;
    }

    for (int osqsdcpflqGID = 502076292; osqsdcpflqGID > 0; osqsdcpflqGID--) {
        jRqCQzxFus -= jRqCQzxFus;
        jRqCQzxFus /= jRqCQzxFus;
        bmJCZOrcYT += Icsgu;
        VgkEqfRKDcTbY = ! VgkEqfRKDcTbY;
    }

    return bmJCZOrcYT;
}

int dpraSXUFZxLN::vylstJv(string WpHZOP, double dWAzVPze, string AjAXVdY)
{
    double RLvkYowdl = -47301.40204318677;
    bool FQLYPR = true;
    string JaPWYoUrgOYCRT = string("hHVNgzUBFFhhLhFUcwWhLlBFemeYqdeEdOdeUBstqNOdSfZaqzOMrCgIMWEswVcveBDUvHNoFQPrQHwqTjWUvjOdLFrBnbHxUBkJQGZbXxyZbLHqnmWcQiFntZiWsXukJVPaQVPmEROHjongFOSWnMBXLThFMrjAPpaYBWkGWpdwHcEmbILiUcVRjLkJstfYznhAYHuUEXgCwfwRaXxuANPVGhtwKzrJlATMyBnUCHY");
    bool DhUwSkBH = false;

    for (int bHSGwMg = 2095405113; bHSGwMg > 0; bHSGwMg--) {
        dWAzVPze -= dWAzVPze;
        WpHZOP = WpHZOP;
    }

    for (int kRjwSJ = 2071405146; kRjwSJ > 0; kRjwSJ--) {
        JaPWYoUrgOYCRT = WpHZOP;
        RLvkYowdl = dWAzVPze;
        dWAzVPze += dWAzVPze;
    }

    for (int twNyBuTGh = 895371848; twNyBuTGh > 0; twNyBuTGh--) {
        continue;
    }

    for (int Tlnbft = 1504354496; Tlnbft > 0; Tlnbft--) {
        AjAXVdY = AjAXVdY;
        JaPWYoUrgOYCRT += WpHZOP;
    }

    for (int MFfGmvYZ = 980782380; MFfGmvYZ > 0; MFfGmvYZ--) {
        continue;
    }

    return -1801011501;
}

string dpraSXUFZxLN::vzpaElUCYlVRC()
{
    int suOeNZK = 748155186;

    if (suOeNZK > 748155186) {
        for (int FEGDgvENpKe = 955815950; FEGDgvENpKe > 0; FEGDgvENpKe--) {
            suOeNZK = suOeNZK;
            suOeNZK *= suOeNZK;
            suOeNZK += suOeNZK;
            suOeNZK *= suOeNZK;
            suOeNZK += suOeNZK;
            suOeNZK += suOeNZK;
            suOeNZK *= suOeNZK;
        }
    }

    if (suOeNZK <= 748155186) {
        for (int jWEXYOPdBauuTQDe = 494545709; jWEXYOPdBauuTQDe > 0; jWEXYOPdBauuTQDe--) {
            suOeNZK += suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK /= suOeNZK;
        }
    }

    if (suOeNZK != 748155186) {
        for (int wptBZtrfjiDG = 1497969620; wptBZtrfjiDG > 0; wptBZtrfjiDG--) {
            suOeNZK -= suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK /= suOeNZK;
            suOeNZK *= suOeNZK;
        }
    }

    if (suOeNZK > 748155186) {
        for (int adXvh = 1484002646; adXvh > 0; adXvh--) {
            suOeNZK *= suOeNZK;
            suOeNZK += suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK /= suOeNZK;
            suOeNZK /= suOeNZK;
            suOeNZK += suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK -= suOeNZK;
            suOeNZK /= suOeNZK;
            suOeNZK -= suOeNZK;
        }
    }

    if (suOeNZK >= 748155186) {
        for (int DTPwvxSwNwO = 1603933534; DTPwvxSwNwO > 0; DTPwvxSwNwO--) {
            suOeNZK *= suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK = suOeNZK;
            suOeNZK /= suOeNZK;
            suOeNZK += suOeNZK;
            suOeNZK += suOeNZK;
            suOeNZK -= suOeNZK;
        }
    }

    return string("aqWUr");
}

void dpraSXUFZxLN::oTvCU()
{
    string wQSuXPGvNZxbLhfY = string("aOsNmtvyeNRRRwUpZqheCjfFjzOXwtUfYadbnSUkebwVFxdHmTcjmuaYOAUnJxdzujThoxLHiLZOTPiVKup");
    double EFBbheuQyojH = 884207.0636186852;
    bool AdwfFinUIflNN = false;
    bool hGFSpdZtZxr = false;
    double qCxAQbLPKW = 426109.06477695203;
    double cpuZnLwk = -317443.45772867237;
    bool gdRhZbaQGmvMOWt = false;
    int yoCZieC = -417348354;

    if (gdRhZbaQGmvMOWt == false) {
        for (int bvyozbcqU = 2102459338; bvyozbcqU > 0; bvyozbcqU--) {
            cpuZnLwk /= EFBbheuQyojH;
            qCxAQbLPKW -= qCxAQbLPKW;
        }
    }
}

int dpraSXUFZxLN::NRbfKi(bool XAYWMvxWWRQ, int GyVtkfPgMVlblNFL)
{
    string NMUQJwSbDc = string("FGBXBRqKfvzcUvJKwHddeMMEKxcFmeRXRPrbfVhvFRLUMKQorbKIavsBWAoYYssDQkmUhXKFIJhvgPFn");
    string EJbUTHbwMwSaJ = string("XFVxxsPpQzjyj");
    bool pCztLbO = true;
    double SRibDoAi = 209642.84962555458;
    int yGsOfbSA = 284942808;

    for (int LFgbOIOmSM = 1657034454; LFgbOIOmSM > 0; LFgbOIOmSM--) {
        NMUQJwSbDc = NMUQJwSbDc;
        NMUQJwSbDc = NMUQJwSbDc;
        XAYWMvxWWRQ = ! pCztLbO;
        GyVtkfPgMVlblNFL += yGsOfbSA;
    }

    if (XAYWMvxWWRQ != true) {
        for (int qLqhTs = 1033532485; qLqhTs > 0; qLqhTs--) {
            pCztLbO = ! XAYWMvxWWRQ;
        }
    }

    return yGsOfbSA;
}

double dpraSXUFZxLN::zuEMZwwIYq()
{
    double duWgtERpkwmrtmwo = -1026548.6898697291;
    int TYcbnCkLwf = -13966629;
    int CPdMI = 819755043;
    int WZEAXZBMH = -1066672596;
    string nsiJjLN = string("EOfXQAigstqsKiHogwdXvPefvEAZuwRbNcoJIwvUORyWRFsjpUBeonyujjImsSZunCovlwhYcluCsxbFdOxApmPrYhQNoQmiLcWLLftYWK");
    string mHfgfdZVJsIKvSME = string("jJXYPlpilCkhKnmSUnTraXWuNXzabALzMvCZawQswWPSiZkOUfqCCixbquS");

    for (int IZELxFOpahS = 1492749708; IZELxFOpahS > 0; IZELxFOpahS--) {
        TYcbnCkLwf += WZEAXZBMH;
    }

    for (int wzVEPkSlR = 709847115; wzVEPkSlR > 0; wzVEPkSlR--) {
        TYcbnCkLwf *= TYcbnCkLwf;
        CPdMI -= WZEAXZBMH;
        CPdMI = TYcbnCkLwf;
    }

    return duWgtERpkwmrtmwo;
}

void dpraSXUFZxLN::jgPiLx(bool oUIhb, int ciSDWbnSLpkvmLfJ)
{
    double seiQiznzeUUkcFei = -603502.2386901007;
    int InWQdKctLZ = -1260387101;
    string BoaSEaPiO = string("zWHRZHPdjiKMIDBVAeZZHVNGcAdLKoQIvXjzxPOsChzbehSYOFiXEoIfLfkOFLKXoepGwDUpCOsAnlDEqddHb");
    int GCdfpzlyipfiJUfF = 1073185797;
    string WQKFJhTrWqVBdYH = string("eJeKeroNCypQEHBCvExYQSqpdiqRgTaJLhcuLqxuRnOypROOaUmTAkpLaSLAZLCsYPtkCxyISPZwOAZRcldybizjWdJHqNcGkjmRqIqBsIKGJpuq");
    bool jXPRJ = true;
    int vhEqYnI = -1624909092;
    string SrWHPpQYwQBIfqF = string("DzeanHROxStjpFCGmHhcuBmfwAkocrqPzGkjAZsMTOvNFPktDjIfDLjVkNdswODQYyBPSwqPbhfCqUuNDhzjReCWhLKVQdamHljhBleDStjdSbbgvmhpltCgTcoDUjITuzATizodZSCZqPtbqTUGKSgWXOHlmLcNXIaZXReoEmdkNlzTmIZEuR");

    for (int qxZsgDJUvSqocztb = 1285873677; qxZsgDJUvSqocztb > 0; qxZsgDJUvSqocztb--) {
        continue;
    }

    for (int XfXVbpolsNil = 170204431; XfXVbpolsNil > 0; XfXVbpolsNil--) {
        SrWHPpQYwQBIfqF = BoaSEaPiO;
        WQKFJhTrWqVBdYH = WQKFJhTrWqVBdYH;
    }
}

int dpraSXUFZxLN::IzFbsGvaphdldwLv(bool iMCRsMp, string FZFvYD)
{
    double vfhabVJiprG = 861321.5356279688;
    int KaxhD = -597631746;
    string tyHBleFRtgXXAXol = string("ZlTPuVDDQxTHtzmXqwWNEBTbsCnnyViewHuORbstJyHKSMeDQOtqwpgcGniLwxqNdEClkLTMtbwpXZSLpMG");

    for (int uvAzx = 1652795125; uvAzx > 0; uvAzx--) {
        continue;
    }

    if (tyHBleFRtgXXAXol < string("xvypWPNqHDJlPVubDSmZppUskAsHLnXJzBcJFrhzsOVUytrEcABXvpTECEBxXtodlZkSzGaAvHwOXmJJcREZAfmXlFoIJGxDzydknJRxkabFEipwRzjIIKgbDGAAwzVDkxByVgrxZcmXNfwBBdPCZzXMKRiwZufDOHUeRIfiynM")) {
        for (int kTbbaw = 1737980547; kTbbaw > 0; kTbbaw--) {
            tyHBleFRtgXXAXol = FZFvYD;
            vfhabVJiprG *= vfhabVJiprG;
            FZFvYD += tyHBleFRtgXXAXol;
            FZFvYD += tyHBleFRtgXXAXol;
        }
    }

    for (int YqFxYb = 64545113; YqFxYb > 0; YqFxYb--) {
        tyHBleFRtgXXAXol = tyHBleFRtgXXAXol;
        FZFvYD = FZFvYD;
    }

    return KaxhD;
}

double dpraSXUFZxLN::GHvBkKu(double XqBrxjgya, double UGugG, int sTlAhnmtTaS)
{
    int SUhjPv = 177883065;
    int iWnDWccJ = 1215393723;
    int Tywfr = -1491416793;
    double nqUft = -215612.2216462991;
    bool ailKZot = false;
    string wNRQDScMmGFOV = string("BYqVogiZEOMXrsmuazRmfVYZJHKKljNQLBXNaeeUeSRlXukSKdLuboKpupPCyvPdxVwTlnIZmvOgrRiVDpCNNmRVSoBUycduOUBKluFcWyUaiktsAjKIweyfEpVnRfwbVMLFfGcUZmTiqKjWiSYybYkoPoODVQpJcNSMPDLYXSsvrftQwDFdghXg");

    for (int HXoAVTOOQDlSI = 1224017439; HXoAVTOOQDlSI > 0; HXoAVTOOQDlSI--) {
        SUhjPv = Tywfr;
    }

    return nqUft;
}

bool dpraSXUFZxLN::OIdXf(double HXtnGX)
{
    bool KLflArgHmywx = false;
    string gOPDhpAu = string("BQtDbcBXB");

    for (int QglinK = 347652801; QglinK > 0; QglinK--) {
        HXtnGX += HXtnGX;
        gOPDhpAu = gOPDhpAu;
        KLflArgHmywx = KLflArgHmywx;
    }

    for (int GWKDyb = 502188681; GWKDyb > 0; GWKDyb--) {
        HXtnGX += HXtnGX;
        KLflArgHmywx = ! KLflArgHmywx;
    }

    return KLflArgHmywx;
}

void dpraSXUFZxLN::vQOHQOFBFPPCGlFs(bool ukpxOcMgJlSxxT, int gOHBFI)
{
    double wCpsoZpjYxZmOSkv = -743518.8456299956;
    string iCcMHaQnurvwU = string("YfGXnHHeTaCuaAMwhNExHRhpjLpmQkBvuPJkkrGFietsjjBCoVguobzZnZsOLgoUDfpDjlxrDRaWAhovtZBgcaHQDMvtXsUAMpEemWanvcDZzmgpFMfvBYbeYPcuXbcMmNqivcmzVBazMNUlxJpztcJURQUIWalaeMwNDJIxnsRtQriLzHxOtCxTuaiNBqEnXdaFjlLfcVkLmJUq");
    string AlBujVem = string("DbRBxpBASlwmEQXWuSxhkUqpwrnCQInjuISJKREVFeVrhIZkIyNVPZplwzvjOPXiUhZOpFEyisYMhBxqCtOoGc");
    string ojShylCeuSQ = string("uqWYKqTarXDSJQDvJFxSGnaCNCiBUWRYtXsWrNiEJxSUZnboyRsHKOdOXHutxqULUqrdJymYSPEneiqFgqrqaFHVwCpAPmoEoeUlXTYLJwmZepOPtRUyoCHelBAHRJNDPlxsHldzYTvrLQiLdANpUNKmqQhVObZImNvThUPuuPUlsdX");
    string viYKKoLe = string("XwRbwZwpoYIxGIQOTuMdKQXJ");
    double ZtSVFFnUbfxH = -841245.1337933467;

    for (int mPkJPVyJMEZKJ = 1025387422; mPkJPVyJMEZKJ > 0; mPkJPVyJMEZKJ--) {
        gOHBFI /= gOHBFI;
        ZtSVFFnUbfxH = ZtSVFFnUbfxH;
    }

    for (int OuXWNabOnmCQCZRl = 439696853; OuXWNabOnmCQCZRl > 0; OuXWNabOnmCQCZRl--) {
        gOHBFI = gOHBFI;
        AlBujVem += iCcMHaQnurvwU;
    }

    for (int XMVKhGX = 615147454; XMVKhGX > 0; XMVKhGX--) {
        continue;
    }

    if (AlBujVem < string("YfGXnHHeTaCuaAMwhNExHRhpjLpmQkBvuPJkkrGFietsjjBCoVguobzZnZsOLgoUDfpDjlxrDRaWAhovtZBgcaHQDMvtXsUAMpEemWanvcDZzmgpFMfvBYbeYPcuXbcMmNqivcmzVBazMNUlxJpztcJURQUIWalaeMwNDJIxnsRtQriLzHxOtCxTuaiNBqEnXdaFjlLfcVkLmJUq")) {
        for (int fzhCZYEMx = 1861819750; fzhCZYEMx > 0; fzhCZYEMx--) {
            continue;
        }
    }

    for (int tghYCO = 408676864; tghYCO > 0; tghYCO--) {
        ZtSVFFnUbfxH -= wCpsoZpjYxZmOSkv;
        ojShylCeuSQ += viYKKoLe;
        AlBujVem = iCcMHaQnurvwU;
    }

    for (int WLLfbjoH = 1766300383; WLLfbjoH > 0; WLLfbjoH--) {
        AlBujVem += AlBujVem;
    }
}

dpraSXUFZxLN::dpraSXUFZxLN()
{
    this->pOHtvWw(false, -1748807102, string("SQNbsaUSbHlJLWUzHsIwvcYvRMNybhZOiSscxgz"));
    this->KHpuRdoUshIV(395981.94644102163, string("FlbSOMUPGBjWlOuTACDuqeoQnMNavydHNqSpIilyBDjZowXeLWTIkLpLxkHNxUyffgVuFhKwulAWKKzcUPyQjbToQSCKNubHsUlydIhZZxlAIvermZCRmVltAWJKBxHiHhXBKgLeqEoBii"), 737293.5010409247);
    this->KTfidPHVTjdFBth(1553637187, false, -618789.7676305562, -60297.73433545318, string("tQbtwArLDXnNZBkzQxoRNkbzpBsaqMQziIjCHllkCXKqBanKLiFDHrBbpiUimsHGhtHnXLiFcZDNHOuPqDZAoHqDyoAyLgnyCwwiIpSCbgkQrFtbauIAYoqbYLVweI"));
    this->AAeacdjZru(false, 481174.2307295734, false);
    this->eDsHnVCqmU(638955.2883202562, string("PqnRPVcTNSeDKXjexeCXjbKjEcADyeNJbmudVLpYmXuHKvxgVhIzzJWYFoTSJDLXgwPoDFOUgZWTicPJlxhjmhVqKyZUeGouNRqSwJspOrxiGPQto"), -692190.4855539468, string("hOaFULzeyJxsnaccAOhIGPJnnXUeJmWKlyRlEdsgudFssCORLdPdCldZFRYsllTDXWDanmJgmVVsvCyvewctmxTqFPrHbpFZPIlPKxRcVNRwdtmXsTDWVfKuQyUtlABtQXYUlwlvzlwAIyBEbaZGdMhMjnBwwwnkkdnBtrBNXWlRPjTrcGppbGcEyylmihDhPyMMfXCoShZzsqcmXuNnbkagShlsJPUSlDKVgKtUWRhOSs"), 1937970593);
    this->dlFQaKPA(string("WnpjvqqvnxmwaJnwdvHMWyteYdCccffnNfuEuiWusmiVMCqJhUNLAxwFTruGqsBdmuHYXnlmFdTFwxjNMvzqZSShWXOhcoZJfeHtxocRgLFbtCzYpzSAAuFORIsxMJREEiQmvncPAPXQbmZDMwUlK"));
    this->vylstJv(string("WHYpPpygjVsWaSauQfcikqMUfHRAWscpFKhk"), 21913.307071857405, string("QMeQqKzCxYGFHnrIbjsPRzILYpCHQCNcxTEjvQcHbQpppPHXclUvhkNIbBsWXxtyzokiygpEfekzGNwMgvzwbVCqDsiMBwDIJNBEqncnToE"));
    this->vzpaElUCYlVRC();
    this->oTvCU();
    this->NRbfKi(true, -1060944333);
    this->zuEMZwwIYq();
    this->jgPiLx(false, -2081601575);
    this->IzFbsGvaphdldwLv(true, string("xvypWPNqHDJlPVubDSmZppUskAsHLnXJzBcJFrhzsOVUytrEcABXvpTECEBxXtodlZkSzGaAvHwOXmJJcREZAfmXlFoIJGxDzydknJRxkabFEipwRzjIIKgbDGAAwzVDkxByVgrxZcmXNfwBBdPCZzXMKRiwZufDOHUeRIfiynM"));
    this->GHvBkKu(-82505.52387672126, -991407.8479940861, 171934757);
    this->OIdXf(-955592.7371560677);
    this->vQOHQOFBFPPCGlFs(false, 1198147432);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RLMVnE
{
public:
    int SbyJxsAkhz;
    int SQqquX;
    int sEWogbpVytyz;

    RLMVnE();
    bool CKmntzWUPlCFYlZ(double DyPAmbfLAP, string hnZWZ, string exvYTuZjxGRk);
    int gzpWUdumRsAwNPW(double ExaLeZR, double rDnsGlY, int cSPUXy, bool CUpcwqUq);
protected:
    double aputeIS;
    int wWIbwTGZmIw;
    int yrGbEwd;
    double bytdCUpmABAtqGh;

    string PqORmtNtchR(bool poikhESSeuhOjutS, bool LFXhXr, string LwbgJeLIabjtwI, bool ggPTpgCYLTDTHh, double QOKNgBkipaeKK);
    double ePOOQLHrXOzZ(string nuTwmUxeHR, bool RgtPmDhYDaK, bool ZPRXzzFdXVjsf, int ecAVXmpQ);
    string kVkpyUsG(int GNjQk, string XEZnwcxCML, int Fiteh);
    int qciECVwozyB();
    string ofecKQOSN(bool pTLlkNVYM, int CULezOKXQuBK);
private:
    string iJjDvIMyKkKRwqtG;
    int opugFDPyaVAaH;
    bool liCuBabnP;
    string hAVBPLYRfYstNu;
    string EBIZJKxhz;
    int jdMlSbYynPQ;

    string GOpgxr(double AGEPAErDlpWiiq, bool sbPseEMMmcwYPiO);
    string LXTYwHPMGb(int NKYsc, double ilUIlfUfsaKTdul, double ovxCtlqKCmC, int ydoWMoidCMbUe);
    bool cTmSHhRZxqH(double mHjEtpHRyGzk, string BFnSltkwMEtKIv, string cLYLbMRpbQ, bool dsfkvvipQnpB, string gsMRUu);
    void DIFQEnvQDhm(double yPyHSXIyOjvHZaOp, double keDyxzIRghAMTQ, bool UbJmYmsylbx);
    void tFCBExbe(double AXHBNiEZTWfbNkG, double RTmUzurJjvhIp);
    string bTVjfyQXcO(bool zepxDAPidVuSZ, bool vVCco, double JTmppWvYiOOgZzzk, int sAEQEkRFfCK, string Hmchfa);
};

bool RLMVnE::CKmntzWUPlCFYlZ(double DyPAmbfLAP, string hnZWZ, string exvYTuZjxGRk)
{
    int cCffalJgNJDfhGtL = 995276043;
    double LOSFwGfhS = 985420.1870529221;
    string vMdHT = string("UyZMqxRtbztjrJCirTtKaZcTaPUUDTvztuOdtuJjgMkNESycDiEcBMpXDgHJZShWlDWthZwlSZydgIswWwBKTlvAlWRXcmSWDZurKZIvyPslUxqZHtfDSOb");
    double kRRNIR = -790890.7768402935;
    bool NHdcHymjkqdTLqFu = true;
    double yevkryiTPK = -999709.0557222742;
    double CVPOGBH = 244878.62735328428;
    int mLGSyqJc = -835717815;
    string SsErc = string("hjgAxtVLwmggOgPjltWtzdMVTlKVYulIXgDPkTvqknYHjVDRDmWkcenMbzNuTTbKFVLwORlNcGjrTXntrYDhlrdYGdUqOAfOwRODqDwfysOUBHwVVUAycRaQGJXcMStKSOCzeUpFuuCHDnYidXSDzwmetRiWoZCiWJFHbkDSLfQTnYFEKvJuDnPHyl");
    double KZpGFABaBTdo = 1027593.2865105984;

    if (LOSFwGfhS < 1027593.2865105984) {
        for (int PPDLEnDoypez = 1275107623; PPDLEnDoypez > 0; PPDLEnDoypez--) {
            kRRNIR = KZpGFABaBTdo;
            LOSFwGfhS /= CVPOGBH;
            DyPAmbfLAP -= yevkryiTPK;
            vMdHT += SsErc;
            vMdHT += SsErc;
            DyPAmbfLAP = DyPAmbfLAP;
        }
    }

    if (CVPOGBH > -999709.0557222742) {
        for (int rdEmGnPfHC = 863100104; rdEmGnPfHC > 0; rdEmGnPfHC--) {
            hnZWZ = exvYTuZjxGRk;
            LOSFwGfhS += CVPOGBH;
            exvYTuZjxGRk = hnZWZ;
            SsErc += exvYTuZjxGRk;
            LOSFwGfhS = LOSFwGfhS;
            NHdcHymjkqdTLqFu = ! NHdcHymjkqdTLqFu;
        }
    }

    return NHdcHymjkqdTLqFu;
}

int RLMVnE::gzpWUdumRsAwNPW(double ExaLeZR, double rDnsGlY, int cSPUXy, bool CUpcwqUq)
{
    double eyQhLQdlIDOfjy = -757689.0652270885;

    if (ExaLeZR == 148918.9223870688) {
        for (int eLxaLe = 970033745; eLxaLe > 0; eLxaLe--) {
            eyQhLQdlIDOfjy /= ExaLeZR;
        }
    }

    for (int lEiiUjFFwyz = 460639329; lEiiUjFFwyz > 0; lEiiUjFFwyz--) {
        rDnsGlY = rDnsGlY;
    }

    for (int phKumHYTBh = 1569884278; phKumHYTBh > 0; phKumHYTBh--) {
        ExaLeZR *= rDnsGlY;
    }

    if (rDnsGlY <= 148918.9223870688) {
        for (int SwoiSBw = 898395418; SwoiSBw > 0; SwoiSBw--) {
            eyQhLQdlIDOfjy *= rDnsGlY;
        }
    }

    for (int JYcgtSAMbKhUDxDh = 1443782467; JYcgtSAMbKhUDxDh > 0; JYcgtSAMbKhUDxDh--) {
        rDnsGlY += rDnsGlY;
        ExaLeZR -= ExaLeZR;
    }

    return cSPUXy;
}

string RLMVnE::PqORmtNtchR(bool poikhESSeuhOjutS, bool LFXhXr, string LwbgJeLIabjtwI, bool ggPTpgCYLTDTHh, double QOKNgBkipaeKK)
{
    int ytYrgtcVXK = 55776720;
    bool CyRIbvH = false;

    return LwbgJeLIabjtwI;
}

double RLMVnE::ePOOQLHrXOzZ(string nuTwmUxeHR, bool RgtPmDhYDaK, bool ZPRXzzFdXVjsf, int ecAVXmpQ)
{
    double OpNoL = 623481.004338605;
    double TnrfyBRjwyB = -166000.40393714065;
    int TBJJRuNwaDz = -828817949;
    double uamrOKUKSF = 791017.0402430536;
    int tgwJWHnqHm = 1585831026;
    string GgPbljXUZaGRH = string("QJBhCwHhxTFIFcIRNXAgAhjgwUNgxkPxxbjhUQLunxptsyjNDsMMRRnCnSwwjRE");
    string QctWAMmkBF = string("zInlVFaCKPYjTBhcOByTrRcUYsdJzGePzoSewHLsamCXk");
    double QHgFCPoYuQT = 37302.116167164706;
    int RTVEwg = 1375883538;
    string znrUwNPMgs = string("sKsOOrXTtHZcygLatnOIbCDBtPrjEleGDntUXlEedCvdxmISydRYmrJMrnBETPObSsBhuxhvHJPShwgGRAOAzZePNkcZsWWuHbiUJKFsyUKLLyYmxfkSVytznxwwqyjLjIQcqgIeTmPfMbielVaKsGVyJeljnYzMbbRlBenskCMzbaIJhrnFuT");

    if (TBJJRuNwaDz <= -828817949) {
        for (int asjWlReOe = 1202781479; asjWlReOe > 0; asjWlReOe--) {
            continue;
        }
    }

    for (int YyAKhsMONuZgQxT = 582338036; YyAKhsMONuZgQxT > 0; YyAKhsMONuZgQxT--) {
        continue;
    }

    for (int osVchHD = 1238033812; osVchHD > 0; osVchHD--) {
        OpNoL *= QHgFCPoYuQT;
        RgtPmDhYDaK = ! ZPRXzzFdXVjsf;
    }

    for (int aiSDKssqv = 589466341; aiSDKssqv > 0; aiSDKssqv--) {
        RTVEwg /= TBJJRuNwaDz;
    }

    return QHgFCPoYuQT;
}

string RLMVnE::kVkpyUsG(int GNjQk, string XEZnwcxCML, int Fiteh)
{
    int hUgdY = 913956587;
    bool xoQpSIO = true;

    for (int pVZiiko = 596890165; pVZiiko > 0; pVZiiko--) {
        hUgdY = hUgdY;
        Fiteh -= GNjQk;
    }

    if (xoQpSIO != true) {
        for (int EdaaNqQu = 2101278349; EdaaNqQu > 0; EdaaNqQu--) {
            continue;
        }
    }

    return XEZnwcxCML;
}

int RLMVnE::qciECVwozyB()
{
    string zguSCSiKYmT = string("cATnfRtztaFyAAiJlULzEtYYMzuGYsDcOYYZmZY");
    bool hduCxqon = true;

    if (zguSCSiKYmT == string("cATnfRtztaFyAAiJlULzEtYYMzuGYsDcOYYZmZY")) {
        for (int pjgDulVEnveW = 1760511797; pjgDulVEnveW > 0; pjgDulVEnveW--) {
            hduCxqon = hduCxqon;
        }
    }

    if (hduCxqon == true) {
        for (int vfNnMflze = 1345075757; vfNnMflze > 0; vfNnMflze--) {
            zguSCSiKYmT += zguSCSiKYmT;
            zguSCSiKYmT = zguSCSiKYmT;
            zguSCSiKYmT = zguSCSiKYmT;
            hduCxqon = ! hduCxqon;
            zguSCSiKYmT = zguSCSiKYmT;
            zguSCSiKYmT = zguSCSiKYmT;
        }
    }

    if (zguSCSiKYmT == string("cATnfRtztaFyAAiJlULzEtYYMzuGYsDcOYYZmZY")) {
        for (int kueaud = 1712015819; kueaud > 0; kueaud--) {
            zguSCSiKYmT += zguSCSiKYmT;
            hduCxqon = ! hduCxqon;
            hduCxqon = hduCxqon;
        }
    }

    return 1241128408;
}

string RLMVnE::ofecKQOSN(bool pTLlkNVYM, int CULezOKXQuBK)
{
    double isAbvIHdRWWdYlEv = -361865.30045715155;
    bool llFRwBpz = false;
    double KdNBUdaee = -286161.8477870798;
    double qfaXaGbRAPDBA = -1034433.3303069617;
    bool XfvziSHs = false;

    for (int rBPjZApgfubMK = 1599854874; rBPjZApgfubMK > 0; rBPjZApgfubMK--) {
        continue;
    }

    if (qfaXaGbRAPDBA <= -286161.8477870798) {
        for (int aFNzRiMcfJPQx = 532499655; aFNzRiMcfJPQx > 0; aFNzRiMcfJPQx--) {
            continue;
        }
    }

    for (int HTotuQNdOY = 411621000; HTotuQNdOY > 0; HTotuQNdOY--) {
        isAbvIHdRWWdYlEv /= isAbvIHdRWWdYlEv;
        llFRwBpz = ! llFRwBpz;
    }

    if (pTLlkNVYM == false) {
        for (int WGaavLEGLwEQSRy = 1462129891; WGaavLEGLwEQSRy > 0; WGaavLEGLwEQSRy--) {
            KdNBUdaee += KdNBUdaee;
            qfaXaGbRAPDBA += isAbvIHdRWWdYlEv;
            pTLlkNVYM = pTLlkNVYM;
            XfvziSHs = ! pTLlkNVYM;
        }
    }

    return string("MQVViWfCzNqqaCZWrPUoHraCzFQNBGzWCdsdvwNsyJCxvUeezYMPCwVRKHRhhFwunMoAvbHszwwqqgYwDXIXAurGmyxOFqQcbSyFSZNIgLZLkXJyFlUILDIGBPBHizyFDMtnbnvizzPTleiUZQcJeIBAYdnVhZYKTytgQnmeIELXRjvzotGyZUeQcwAUJstwopRTlebAfyfFyXfiFAJWffdFxxHhEaIzDHUxcEXgOhxBLIEivka");
}

string RLMVnE::GOpgxr(double AGEPAErDlpWiiq, bool sbPseEMMmcwYPiO)
{
    string oYPAaIdGhKzgeBL = string("dNFhBeKCIsfWrRnHqjHspQsLlrmBZHWswAalBSNPubyXtAkEkmxlItPHFABgaYdZJBkMUkXHberwvxIJaEwBBZQSmiPycwqSkElMyHldoifZAMkNrafBmQEFLFxJoyvuvQKXYLyKzihwsrnnvxkLQgHatzhCTbOEpQOMFTEvlWcYxRSvRKikaMgyzYbnSitnTDbXwemTfuYYrPhDxmBHnDwnyVtHSqlCMLrJFkeVsPTawxZgPHBc");
    bool pSdrnONpblP = false;

    for (int CSIrFKBoK = 2096645234; CSIrFKBoK > 0; CSIrFKBoK--) {
        continue;
    }

    for (int FoepdN = 1045182225; FoepdN > 0; FoepdN--) {
        sbPseEMMmcwYPiO = pSdrnONpblP;
        sbPseEMMmcwYPiO = ! sbPseEMMmcwYPiO;
    }

    if (pSdrnONpblP != false) {
        for (int iazItWWhcuwc = 2103823045; iazItWWhcuwc > 0; iazItWWhcuwc--) {
            sbPseEMMmcwYPiO = sbPseEMMmcwYPiO;
            pSdrnONpblP = ! sbPseEMMmcwYPiO;
            sbPseEMMmcwYPiO = ! pSdrnONpblP;
            AGEPAErDlpWiiq *= AGEPAErDlpWiiq;
        }
    }

    return oYPAaIdGhKzgeBL;
}

string RLMVnE::LXTYwHPMGb(int NKYsc, double ilUIlfUfsaKTdul, double ovxCtlqKCmC, int ydoWMoidCMbUe)
{
    int jzTwBaILGuWGrJ = 819914894;
    int KBtLtNWy = 300896122;
    double gxsVpASrROe = -973495.8816843155;
    int PAnHxmOpceL = 1280671480;
    double IuPXiCOSeIA = -844671.0763528785;
    bool euFyAXjyb = true;
    bool wRCDIsTZIOedR = true;
    string lbFzjjarIFekjpAY = string("XfcMqxqtAnxImeJJdiVXkyglIMgdlHflWnjLpGTZrJYObuNZKysoZ");
    double FnDfbzfAYNVVHiU = -531099.8663728476;
    bool sDfcfLE = false;

    for (int cvKenrv = 838064484; cvKenrv > 0; cvKenrv--) {
        wRCDIsTZIOedR = wRCDIsTZIOedR;
        FnDfbzfAYNVVHiU += gxsVpASrROe;
    }

    for (int AbUhByVEKWR = 484426066; AbUhByVEKWR > 0; AbUhByVEKWR--) {
        IuPXiCOSeIA -= IuPXiCOSeIA;
    }

    if (ydoWMoidCMbUe >= 300896122) {
        for (int AtseZeqIxMvAJ = 1729801282; AtseZeqIxMvAJ > 0; AtseZeqIxMvAJ--) {
            ydoWMoidCMbUe += KBtLtNWy;
            ydoWMoidCMbUe = jzTwBaILGuWGrJ;
            PAnHxmOpceL += ydoWMoidCMbUe;
            KBtLtNWy /= jzTwBaILGuWGrJ;
            FnDfbzfAYNVVHiU -= FnDfbzfAYNVVHiU;
        }
    }

    if (NKYsc > 819914894) {
        for (int vSJsYzShh = 851640981; vSJsYzShh > 0; vSJsYzShh--) {
            KBtLtNWy = jzTwBaILGuWGrJ;
            lbFzjjarIFekjpAY = lbFzjjarIFekjpAY;
            ilUIlfUfsaKTdul /= FnDfbzfAYNVVHiU;
        }
    }

    for (int qmjVnYigxulh = 281548805; qmjVnYigxulh > 0; qmjVnYigxulh--) {
        continue;
    }

    return lbFzjjarIFekjpAY;
}

bool RLMVnE::cTmSHhRZxqH(double mHjEtpHRyGzk, string BFnSltkwMEtKIv, string cLYLbMRpbQ, bool dsfkvvipQnpB, string gsMRUu)
{
    string QLrxpP = string("UBAexjyfsoGakWccxuhnlNEdqpBTKqNJgaiwVgmNyFDPJhVBSvFCKBzlHTwyRXGKUNzzzUNjMAFrvPuRFqebzLnCoHCtGABmmASraalyVCjMOBNTvFiWUWEuRYcBCcVTDhxdGcYTqtkqXliGhirBFjoIjWdNkFzRJdlezQ");
    double ltSXiUyMm = 381259.7339221909;
    string fkBrwp = string("gtGibGPSkQKFbJZjHMrnLsHJfshzQFSQOmtqagQkmjPweQWUDYUcriqtMslglhnjuOkczlydNGpiIVIwTINxIiTEvuLtObSIOUUoUaftxHCBgasqwSKCtKCXRovdqXmSfhguDgerAvWtjeaEveEGHaIihBqAVaAozuqlHFpvheJNIqTbcIBiKXYlWrpAyvRvcIWxfZDlBtfUkEhSVJr");
    string uhzykgdCytw = string("BnTWLmpQLhJENVMTSUnIMcDntKeJWCCzzBNZvDeGIDDQzEMAiDLQsFuAnxzcXftydCaUEFoEnCPfvWlOHwZuZFpMiwhJNpKmRcjXWhwtAzpaQwcTNkInmwRoAAULtXPEozqVrEnqpfmiMQVNabvegzdISaGqnOSXlJPxQxFGKcQjlEjqqcLlOqDPxOCEgTReElvfXTtuOManSEihvcmSsoHxqAnILBnKLyZjPMvKPQPn");
    double cXjxHs = -483814.6590170295;
    double XtyAYIpM = 470650.78238943155;
    bool EpYAOLXx = true;

    if (QLrxpP < string("uwoeHIYfKKgHygdXdNNTZsfWGFcnxZnwyPOXRtkyIgrUckCUOHYcWSHwtFPQEUSplfIQBWfksMNcpwxpvWiXlPQrRTCsExOzJdmQWBEzdznpmUJfdPrNcijBJRfSObVBRsfAwfskvHciJpLbouEVzIsreFJsgREuKHPuMJqeTeWwzJLWCMLZSIwCTdhCY")) {
        for (int TAkDLljVJ = 1275282150; TAkDLljVJ > 0; TAkDLljVJ--) {
            fkBrwp += fkBrwp;
            XtyAYIpM -= ltSXiUyMm;
            XtyAYIpM /= ltSXiUyMm;
        }
    }

    for (int tfqLYmBW = 1429779918; tfqLYmBW > 0; tfqLYmBW--) {
        uhzykgdCytw += QLrxpP;
    }

    if (QLrxpP >= string("UBAexjyfsoGakWccxuhnlNEdqpBTKqNJgaiwVgmNyFDPJhVBSvFCKBzlHTwyRXGKUNzzzUNjMAFrvPuRFqebzLnCoHCtGABmmASraalyVCjMOBNTvFiWUWEuRYcBCcVTDhxdGcYTqtkqXliGhirBFjoIjWdNkFzRJdlezQ")) {
        for (int IVpidg = 611243518; IVpidg > 0; IVpidg--) {
            fkBrwp = uhzykgdCytw;
        }
    }

    for (int BJHkQROeVfuSJs = 2004524423; BJHkQROeVfuSJs > 0; BJHkQROeVfuSJs--) {
        fkBrwp += uhzykgdCytw;
        QLrxpP = BFnSltkwMEtKIv;
    }

    for (int SPxRCXHmFfEhrISJ = 1605204566; SPxRCXHmFfEhrISJ > 0; SPxRCXHmFfEhrISJ--) {
        BFnSltkwMEtKIv += uhzykgdCytw;
        cXjxHs *= ltSXiUyMm;
        cLYLbMRpbQ += BFnSltkwMEtKIv;
        QLrxpP = uhzykgdCytw;
        ltSXiUyMm = ltSXiUyMm;
        uhzykgdCytw += fkBrwp;
    }

    return EpYAOLXx;
}

void RLMVnE::DIFQEnvQDhm(double yPyHSXIyOjvHZaOp, double keDyxzIRghAMTQ, bool UbJmYmsylbx)
{
    int lFCxHQEGWNQUSYQC = -516064122;
    double ZQmRsb = -791287.7138332173;
    double aNniGfvbxBRvbmq = 355975.2638431224;
    bool ldOUtTA = false;

    for (int jvvzRRxYH = 56118765; jvvzRRxYH > 0; jvvzRRxYH--) {
        ZQmRsb *= aNniGfvbxBRvbmq;
        yPyHSXIyOjvHZaOp *= yPyHSXIyOjvHZaOp;
        ldOUtTA = ! ldOUtTA;
        yPyHSXIyOjvHZaOp += aNniGfvbxBRvbmq;
    }

    for (int JaxLrxWQx = 1381121010; JaxLrxWQx > 0; JaxLrxWQx--) {
        aNniGfvbxBRvbmq = keDyxzIRghAMTQ;
        keDyxzIRghAMTQ /= keDyxzIRghAMTQ;
        aNniGfvbxBRvbmq *= yPyHSXIyOjvHZaOp;
        yPyHSXIyOjvHZaOp /= aNniGfvbxBRvbmq;
    }

    for (int SIAJVGEBTC = 292378843; SIAJVGEBTC > 0; SIAJVGEBTC--) {
        yPyHSXIyOjvHZaOp += keDyxzIRghAMTQ;
    }

    if (ZQmRsb >= 5893.98096693826) {
        for (int HxQOBAjYXuMlFPv = 1011312021; HxQOBAjYXuMlFPv > 0; HxQOBAjYXuMlFPv--) {
            yPyHSXIyOjvHZaOp /= keDyxzIRghAMTQ;
            yPyHSXIyOjvHZaOp = yPyHSXIyOjvHZaOp;
        }
    }
}

void RLMVnE::tFCBExbe(double AXHBNiEZTWfbNkG, double RTmUzurJjvhIp)
{
    string LJlVZGxpev = string("eggJwpcQMjYPzRQDDioQIqXAJpnXabpLVoIPDcgsNsAThFLbQuwIaKkwGbqbSFyJhBRFGTApdhqkWJCmmWBXbPCiqUONFppdoQIMLDagjVsGNDhHBL");

    if (RTmUzurJjvhIp == -860887.9347122023) {
        for (int gjtSMFpEyU = 1892237790; gjtSMFpEyU > 0; gjtSMFpEyU--) {
            LJlVZGxpev = LJlVZGxpev;
            AXHBNiEZTWfbNkG *= RTmUzurJjvhIp;
            AXHBNiEZTWfbNkG -= AXHBNiEZTWfbNkG;
            AXHBNiEZTWfbNkG = AXHBNiEZTWfbNkG;
        }
    }

    if (RTmUzurJjvhIp == -488778.3779567655) {
        for (int VXqKzqfUNucZN = 1186545832; VXqKzqfUNucZN > 0; VXqKzqfUNucZN--) {
            AXHBNiEZTWfbNkG = AXHBNiEZTWfbNkG;
            RTmUzurJjvhIp = AXHBNiEZTWfbNkG;
            RTmUzurJjvhIp -= AXHBNiEZTWfbNkG;
        }
    }

    if (RTmUzurJjvhIp >= -860887.9347122023) {
        for (int POFZEx = 1164981666; POFZEx > 0; POFZEx--) {
            RTmUzurJjvhIp /= AXHBNiEZTWfbNkG;
            RTmUzurJjvhIp = AXHBNiEZTWfbNkG;
            AXHBNiEZTWfbNkG += RTmUzurJjvhIp;
            AXHBNiEZTWfbNkG = AXHBNiEZTWfbNkG;
        }
    }
}

string RLMVnE::bTVjfyQXcO(bool zepxDAPidVuSZ, bool vVCco, double JTmppWvYiOOgZzzk, int sAEQEkRFfCK, string Hmchfa)
{
    double ImFtUIAt = -536612.8017606732;
    bool ZwReYXhMXmJxc = false;
    string GkzRwUJ = string("UmIFrYHBBwAjDOSjjxmyxGRMuhFsTUYphbvAAyynlAzVQzATToSYedoIWqYPmeGusVFaDCiTqIzAffsxUYERufUhLeWdqrZLKpBGXSlYrHOPKmqfEjLqdVZwADZPjTwnGfQJemCnSdknzHDFvbEGtmYxMdHGWIvXsYkIxALbsFNlMQzXCCKqFHeneJfLFsGhQgViMGOxViqwjoJgRzmEm");
    bool SqUqNpjXDUwvnmve = false;
    bool LtVKtsHdscf = true;
    string GVUzSZKNk = string("tTSShNAGlHEzkoOWmAJIczMMcaUiQeCTVtUDbocnREFAWgTSMGmmtxBsOMaHsluSwAoYcGyhvPEUHNVShbmDeYXmrDlEAmthiPbtIdsUuLnhtXsuHOwoSBwMPseqIz");
    string CvAmdflAWkBopST = string("QSeTYzIBzYDTGvUduacn");

    for (int SNjvOsEeusBiC = 224327501; SNjvOsEeusBiC > 0; SNjvOsEeusBiC--) {
        continue;
    }

    for (int mMuIMzbSDc = 1836807412; mMuIMzbSDc > 0; mMuIMzbSDc--) {
        GVUzSZKNk += GVUzSZKNk;
    }

    return CvAmdflAWkBopST;
}

RLMVnE::RLMVnE()
{
    this->CKmntzWUPlCFYlZ(-100116.19612025763, string("vHZkdaPgZCyBADTecsqvOoURxldQTbPhRHHTyCkfxvifNGTdLZEqrjJYtYnfdcdiojpITPdXeyCYhwdtzZwqwRAsBbrPnrghZuwlJqTlycpadBXnmiLsxlCjKxjFDhECsVRebQhdcHSgdcjNbxDzJATWhdAuLCZEBMfIeXkpOTNPkymxihwOTDX"), string("nttQWKCuJVpcRhCIhLlKOBpslJdEBEZYdNiCnQiWtABeMMqSdMGdoZcArHWZluAsAICbIJEPVLzsfbFSoUNnLvIsMzbzNAnoyAYZABZHqiLXjMpboapWKGQMKlAMsKZQQJyfVZrfMByQEXmovErkqzdJnpYrLvXIDurEcemlmImJwwOoGBOMOaEMReUeRjfWSywOpqjLYaAyajGymnYlVeovxGgrVPUKCQgaDWfXYMwusxUWHLMC"));
    this->gzpWUdumRsAwNPW(148918.9223870688, 934616.7744226102, -812234711, false);
    this->PqORmtNtchR(false, true, string("mdEaSusjbbnhrunhdTSVnUAIsPpMyRaGvFPlngsOolYLfvDdkXARmsmxZmOzwQKlyyJZEqmdqHB"), false, 857162.4354131948);
    this->ePOOQLHrXOzZ(string("VawoifJZVmwlZpNXbzYTLFLKFyanWEEjeQexJNFkXjvyiirpR"), true, true, -1180312194);
    this->kVkpyUsG(252968997, string("fEWtqCVFqMaYddimEMcOHbyzglLqmBAQXOmhmbAQeePAwJCCfpVwTmiEtLNNLFzKuVyjCliAvdwRwsiTmIGqgPYGJTiMxjkKrYsbPxPUUrfVYpFSPnvqkNAYlhuIyocMieZTdOLNDTeEyHWBGnbNiDQyxsqkKiuAHVXpzep"), 459635372);
    this->qciECVwozyB();
    this->ofecKQOSN(false, -1295010366);
    this->GOpgxr(667823.3573680476, false);
    this->LXTYwHPMGb(-1010540259, -931074.0910640386, -339894.97992049484, 469506140);
    this->cTmSHhRZxqH(-888746.8347681529, string("uwoeHIYfKKgHygdXdNNTZsfWGFcnxZnwyPOXRtkyIgrUckCUOHYcWSHwtFPQEUSplfIQBWfksMNcpwxpvWiXlPQrRTCsExOzJdmQWBEzdznpmUJfdPrNcijBJRfSObVBRsfAwfskvHciJpLbouEVzIsreFJsgREuKHPuMJqeTeWwzJLWCMLZSIwCTdhCY"), string("yOaetUJoWfvXLisnvXArnRBrSJhGXbwQFeoLaQcymBCddcIIQnIihPqAMgXHkNNsaOTZweTUeYplkyUGbSVaQwTctwhairkLoXsKJccHliQzNTSuCKrxctUsiBCyzmZMiaIrjwsLkbalTAExciEOxERDYQBlEnIwwINwKvSgfWXmWyULNichAubMfolQgIygzVUFhnazaVjSjmeSAwzUwTingHyUCpSJO"), false, string("DNJcXsXGXOAFcbEjSnsbHGjaqUUyewJHomWMVjoIESxPVcgRgbVRIAFdYINs"));
    this->DIFQEnvQDhm(5893.98096693826, -581532.1140752048, true);
    this->tFCBExbe(-860887.9347122023, -488778.3779567655);
    this->bTVjfyQXcO(true, false, -492724.09653901577, -1262800651, string("UrvYnzikSMyZrpOGohHzxVCrUHqNmnLLcBZSmvFMpnrkxsQAwjozJUyqRYwvUIPuYWuqNnuYkaCLncOjewtsedmkMvgXnChiEBxPrePsBplxmZWJOwrpwFAPBhEZNFIqYJItKtFmSqpWdhliKWkGOsdZopgswFrALeawQfllexdKNxiMZAoAJZqOtyqeEreVAqZADZnhIrhAUbSYwKqMrJhvSigMkrwjqWjDmQKSDGwGnwvGoXZPlHhfYx"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WuBRhKtwp
{
public:
    string fiOMAQwH;
    int ynQLIRdRhOakyBJZ;

    WuBRhKtwp();
protected:
    int CTFcri;

    double SBapwQRmpCBJvsCu(double uJebeed, int reTimMFR, int ngCLZgEGwfmhN, bool gZWmhhMGGNzB);
    void qhpDewIjljqHvEil(double zrahpuoWOwz, double MSClYm, string cuvbvqcUDzW, bool SlGHu, double JoNNimqgRQgvdCO);
    bool PYLfjUIlf(string KnanXjlVr);
    double tWXpBhu(int txRNIBfARh, string Iesysg, double HTYSZhvKOzXx, bool GwBKaMgXUjwWPoZk);
    string tznYsIDlnTJLcFup(string pjQPaRniDNmRZBOb);
    string NIZgwNkp(string izUyLtbQP, bool smHESGQWjAT, bool MJLxapIlQ, bool EKQYPHWAKoS, int EXJQeklOxONvm);
private:
    string rlNBFSDpWUCxT;
    int WiLbloqf;
    bool cEaKPziRgVBCGeS;
    string SxvmiOztUlNMcdnZ;

    string clVabuEGYgQy(int AeMMkB, int BWJQKNJgRNY, double efQoqKVKaq, double WONbeJzrOxpb, string yDFawvOV);
};

double WuBRhKtwp::SBapwQRmpCBJvsCu(double uJebeed, int reTimMFR, int ngCLZgEGwfmhN, bool gZWmhhMGGNzB)
{
    double zLVrAsW = 1042267.8437380509;
    double aeCBJMlqjeAi = 678173.1818825485;

    if (uJebeed >= 1042267.8437380509) {
        for (int lPEhxoluA = 508828848; lPEhxoluA > 0; lPEhxoluA--) {
            uJebeed = aeCBJMlqjeAi;
            aeCBJMlqjeAi *= aeCBJMlqjeAi;
            uJebeed -= uJebeed;
        }
    }

    for (int CTzoygXRAOeDRE = 1775057897; CTzoygXRAOeDRE > 0; CTzoygXRAOeDRE--) {
        zLVrAsW = aeCBJMlqjeAi;
    }

    for (int rteVf = 1761966953; rteVf > 0; rteVf--) {
        continue;
    }

    if (zLVrAsW != 1042267.8437380509) {
        for (int HsDItSOPCtDIq = 280518475; HsDItSOPCtDIq > 0; HsDItSOPCtDIq--) {
            aeCBJMlqjeAi *= zLVrAsW;
            uJebeed *= zLVrAsW;
        }
    }

    return aeCBJMlqjeAi;
}

void WuBRhKtwp::qhpDewIjljqHvEil(double zrahpuoWOwz, double MSClYm, string cuvbvqcUDzW, bool SlGHu, double JoNNimqgRQgvdCO)
{
    int xgKzsCUFwfV = -391669627;

    for (int burboermzDjak = 2016432705; burboermzDjak > 0; burboermzDjak--) {
        MSClYm -= JoNNimqgRQgvdCO;
    }

    for (int XkUujGPrYqRb = 1947855282; XkUujGPrYqRb > 0; XkUujGPrYqRb--) {
        JoNNimqgRQgvdCO = JoNNimqgRQgvdCO;
        zrahpuoWOwz += JoNNimqgRQgvdCO;
        zrahpuoWOwz = MSClYm;
    }
}

bool WuBRhKtwp::PYLfjUIlf(string KnanXjlVr)
{
    bool NdrtLfl = true;
    bool oEkVMTZhLBtcBCUE = true;
    int cWqXXSzD = 1812031730;
    bool VXTCJDCdc = false;
    double udfScpEL = 337354.83405819803;
    string ArKxuiIHSqtiJXce = string("ifKNPCQDWAbRTRrcZkhHyhtjiDKpeHLkVoQdiUtdUDKjFrVPkoHNuXKOJejlajVpzxYWDPYDbNhMFMSfOqWKaqLdAJlsEqCWiCNTQYDUyKIQpRUp");
    double rXZacQWUlkIe = -923299.6603000541;
    int MVinbJScQkzgiD = -1486363744;

    for (int vxKBTRJou = 5938413; vxKBTRJou > 0; vxKBTRJou--) {
        continue;
    }

    for (int ayKZWQYZMOPBrmTf = 313810333; ayKZWQYZMOPBrmTf > 0; ayKZWQYZMOPBrmTf--) {
        udfScpEL -= rXZacQWUlkIe;
    }

    for (int lXEvBSiQhjfUHPI = 1111801517; lXEvBSiQhjfUHPI > 0; lXEvBSiQhjfUHPI--) {
        cWqXXSzD = MVinbJScQkzgiD;
        ArKxuiIHSqtiJXce += ArKxuiIHSqtiJXce;
        NdrtLfl = ! oEkVMTZhLBtcBCUE;
        ArKxuiIHSqtiJXce += KnanXjlVr;
    }

    return VXTCJDCdc;
}

double WuBRhKtwp::tWXpBhu(int txRNIBfARh, string Iesysg, double HTYSZhvKOzXx, bool GwBKaMgXUjwWPoZk)
{
    int EHCIkKoNpy = 493885171;
    int GBudLtPjPVrWOrNc = 745382184;

    if (GBudLtPjPVrWOrNc != 745382184) {
        for (int TRVaTWkCvD = 948861761; TRVaTWkCvD > 0; TRVaTWkCvD--) {
            HTYSZhvKOzXx -= HTYSZhvKOzXx;
            GwBKaMgXUjwWPoZk = ! GwBKaMgXUjwWPoZk;
        }
    }

    for (int GOnTDuFruAv = 1514245658; GOnTDuFruAv > 0; GOnTDuFruAv--) {
        HTYSZhvKOzXx += HTYSZhvKOzXx;
        txRNIBfARh /= EHCIkKoNpy;
    }

    for (int JXrBAtdmjFiU = 290906527; JXrBAtdmjFiU > 0; JXrBAtdmjFiU--) {
        txRNIBfARh *= EHCIkKoNpy;
    }

    return HTYSZhvKOzXx;
}

string WuBRhKtwp::tznYsIDlnTJLcFup(string pjQPaRniDNmRZBOb)
{
    bool dLeiBacrzaE = true;
    double DGRcITBRNPP = 179869.27913788919;
    string XgqVTNBZezeGFXy = string("bSbdnEGjOzmxtJhRsVEjhoWYFNdLTlejtvEOtVkbXJNizXQumehUyzQRzZRtNEaqgqnxPrPvGUqDNVQEIHdcuFOHTsoNrfbZciSa");
    double vVDzl = -946629.4852826016;
    bool ILOUO = false;
    string cMyhTbqZxfHhQ = string("tiPNSuNvYvmMeaQWXddMxmswTLqsiukkwpHCwvaMUXnETylXuomQjEOlBoGZnnJsBOyEHhjsb");
    int jQsNTj = 1752798921;
    string MyQnbny = string("aezgyXxPPjuhStoEaWuQtwFuDzIGStfKtmaJeYgBRkiKCdJJnRbLVtxrDyVUIZETkdSuPfhxJJYDfYKCvUiwHC");
    int WTWQqCCDbq = -1900768557;

    for (int gULEXIP = 789463745; gULEXIP > 0; gULEXIP--) {
        MyQnbny = MyQnbny;
        MyQnbny += pjQPaRniDNmRZBOb;
    }

    for (int THvuCxNGeWpKIw = 2012610941; THvuCxNGeWpKIw > 0; THvuCxNGeWpKIw--) {
        DGRcITBRNPP = vVDzl;
    }

    return MyQnbny;
}

string WuBRhKtwp::NIZgwNkp(string izUyLtbQP, bool smHESGQWjAT, bool MJLxapIlQ, bool EKQYPHWAKoS, int EXJQeklOxONvm)
{
    double WTSDDZmyUYMRTzd = 709273.5725693294;
    int tOlBtUP = -1002522233;
    bool CyEHxQP = false;
    int MjQctnsWaXcHZPXa = -1567443011;
    bool TWDsRLpqf = false;
    bool fByXUgcvInEGcRWE = true;
    bool zMMELdQLeOPVg = true;
    bool dXgEMsnmPDSRBcCQ = false;

    for (int xYrObh = 1343570217; xYrObh > 0; xYrObh--) {
        MJLxapIlQ = smHESGQWjAT;
        TWDsRLpqf = CyEHxQP;
        smHESGQWjAT = smHESGQWjAT;
        fByXUgcvInEGcRWE = ! CyEHxQP;
        EXJQeklOxONvm -= MjQctnsWaXcHZPXa;
    }

    if (MJLxapIlQ != true) {
        for (int ctdbJLxcxVzR = 1174531855; ctdbJLxcxVzR > 0; ctdbJLxcxVzR--) {
            smHESGQWjAT = fByXUgcvInEGcRWE;
            MjQctnsWaXcHZPXa *= MjQctnsWaXcHZPXa;
            WTSDDZmyUYMRTzd -= WTSDDZmyUYMRTzd;
            EXJQeklOxONvm /= tOlBtUP;
        }
    }

    for (int NvUfhkUqxmIBE = 1143262829; NvUfhkUqxmIBE > 0; NvUfhkUqxmIBE--) {
        TWDsRLpqf = ! fByXUgcvInEGcRWE;
        smHESGQWjAT = ! dXgEMsnmPDSRBcCQ;
        WTSDDZmyUYMRTzd += WTSDDZmyUYMRTzd;
    }

    for (int AHDYXm = 58659998; AHDYXm > 0; AHDYXm--) {
        fByXUgcvInEGcRWE = dXgEMsnmPDSRBcCQ;
        dXgEMsnmPDSRBcCQ = MJLxapIlQ;
    }

    for (int RUYYdRLfe = 1689667391; RUYYdRLfe > 0; RUYYdRLfe--) {
        MjQctnsWaXcHZPXa = tOlBtUP;
    }

    if (WTSDDZmyUYMRTzd != 709273.5725693294) {
        for (int gGqtkso = 1371937182; gGqtkso > 0; gGqtkso--) {
            dXgEMsnmPDSRBcCQ = smHESGQWjAT;
            TWDsRLpqf = ! smHESGQWjAT;
        }
    }

    return izUyLtbQP;
}

string WuBRhKtwp::clVabuEGYgQy(int AeMMkB, int BWJQKNJgRNY, double efQoqKVKaq, double WONbeJzrOxpb, string yDFawvOV)
{
    double OchIceKJxAX = -267152.9521639505;
    bool MbIyY = false;
    int TBDXvOk = -740013852;
    string zhXcSlBzG = string("PkqmaCzaCxzQeXWGQgFoIGOOxCpFvMEJAYIVddzDaSoBMvTMXFbIPiXrFMlTxwlMeWddOpXTvmTkTIvJTMbsIWioNahqEqlLuhlLxOfszdwmebtiQoRrJqnXegxfOCCwMnPwwETI");
    int cHYnyTKfHzMlJT = -2101110268;
    double AYxkCBtsefudokAk = -255933.8868944698;
    int DhReHfS = -503532481;
    bool zesRa = true;
    int ZqEevtsCcKT = -133276199;

    if (BWJQKNJgRNY <= -133276199) {
        for (int pLYyrMHsZbwL = 1349819731; pLYyrMHsZbwL > 0; pLYyrMHsZbwL--) {
            BWJQKNJgRNY -= DhReHfS;
        }
    }

    for (int zLXLrNFWBTxMLiP = 1468186664; zLXLrNFWBTxMLiP > 0; zLXLrNFWBTxMLiP--) {
        cHYnyTKfHzMlJT += TBDXvOk;
        AeMMkB = TBDXvOk;
    }

    for (int raZENZIHIICn = 344332429; raZENZIHIICn > 0; raZENZIHIICn--) {
        cHYnyTKfHzMlJT *= cHYnyTKfHzMlJT;
        zhXcSlBzG = zhXcSlBzG;
    }

    for (int rehOYMwAxc = 889193426; rehOYMwAxc > 0; rehOYMwAxc--) {
        continue;
    }

    for (int GhfBfGyGJUNb = 1435204337; GhfBfGyGJUNb > 0; GhfBfGyGJUNb--) {
        OchIceKJxAX = efQoqKVKaq;
        cHYnyTKfHzMlJT += DhReHfS;
        zesRa = zesRa;
    }

    return zhXcSlBzG;
}

WuBRhKtwp::WuBRhKtwp()
{
    this->SBapwQRmpCBJvsCu(10297.680550646852, 1902392490, 1830723200, true);
    this->qhpDewIjljqHvEil(-384868.34567302687, 48976.13918488648, string("OnLQgmDlHRoNsduphjjFMIqdfNdYUGsVvcxXfTQkgQfpGdRUjgFvUTUvPmrunFDrJqmmdHqwtUIRoSvblKNvcCWnzNFivJsKwzUTpIJXiyYqDBIxLoANmcjAoUZDz"), false, 869676.5864420038);
    this->PYLfjUIlf(string("ghtbNRybndekzetLicCJgXKLLUgXBbZZoEmHASlsNrrIgydAZfNJaCRBWbkCPuyytqLmAkmfaLeRqgioVYICDAbWqFWGUUAzjoMAERySetczWorlZqDcwNqhRBgRoqJIXtZuwJdWHoGramnxuSkktJCxEbLYlDFvhuQcaUlUQHfvpEBingjbCUfStWSJTRj"));
    this->tWXpBhu(1421026690, string("NmeriUptwVlMwAMwtZOCWCKk"), -920691.8942733775, true);
    this->tznYsIDlnTJLcFup(string("CrhnSMXXqNuOoFqSfgvPIOtMiFxIdyuOEpQceZDMfHuMQpyfLCjUesfsaEaimYpBIiMFFvPnxjJhgmdumptxQBYEJnyrdPw"));
    this->NIZgwNkp(string("BNuVFXoQFCzTBYDLqPAHieLpUQNgEcewpkwfyCoRwdBCxIophQctJUaRSXpWMNQGozSQcaKxqNXixWrMVKWNHJvpzyHyOAhaobRonftZwvtREmmfvjURvU"), true, true, false, -1683709598);
    this->clVabuEGYgQy(-815889790, -2057267303, 711347.0666047789, -415618.2939855301, string("MSyeWzQKDPAInrfwnFljYFIHSIonTOaCiyaFcahFlMEVUlDHCZSDdrgXGZwpcHFzHvjqssQKQbsBilyVGLDclOAympqGDScgDNFRzwhsGNhJbhiFqFjzPSpuirGVuEDppizBBWkiMhLqSwzOzMHVkPQyHhYWtLZEltFACqENMjeVuYiAoPIdlmIJLLhQCHDeoyOXyewAmhLhmbWUsahXidfabeGdiekLSZgJDxFIsMRWEeIbCoRRx"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wWJCvs
{
public:
    string EZOlxbR;
    string EszHlabwxFBuBOPq;
    double iwXTLFzhTQYSjJD;
    double ZsHbuCoPCEq;
    string gaOVZyPj;

    wWJCvs();
    double YxYlwk(int MjjjLnHkbRnTVesQ, double frmCTGha, bool wSicyyM, string PMGUdZaGRixkWEh, bool LdzyyaOOMoj);
    bool KVCIwibkrMTBEVl(int vloGTsdgO);
    double mUVZPJS();
    double FhMyvhQS(int CSOaZbRTLn, bool GLXAhrjXZ);
    int ROfTLUMU();
    bool jaPqfnjeqotynz(int ytQSKj);
    void uXUMkCw(bool PUpAqCCzhO, int rzsqhYMPVQFU, int ksbkbYDeEEZtZDsC, bool iQdJKjLSSIeS);
    string XDhkvGwkEitEj(double FDwxgvvI, string TOOePn, int uewKrgCG, bool obcGkHhOquPNS);
protected:
    int HIWyjDxaaHUvuE;
    bool jijJqFvl;
    bool BlyhobJOG;
    bool UunxYSTazVTpiMIc;
    string uTghygVhvQHgGEBB;
    bool MGdtkbNQCfpKDr;

    string iAxWQU(string oWqnJkzdGhy, string ugxtDMoqhY);
    int OGhbXtUNbgISG(int AVaWys, string HADafD, int ZavoqdNmgWqDCLt);
    int TiYklOhjMMn(string PSdkECke, string gLnXcWuex, string VZddNSeJhjtO, string vmCeSQXYOL);
    bool JSjAXMiQDgqgyw(int IeGvup, bool nAzKDraQVc, double BwDaACWfxON, string oONxvl);
    double cbDbg(double HIGdOxpd, double WMfSNTpbo);
private:
    int kxkMosZAd;
    bool XoutBnJ;
    bool gDQSRVisZWeAfkuW;
    string YsJplQrrDOhqF;

    string tCwhblFccfj();
    int OkyPshBplhfG(double XOYMJVgMlIqg);
    double zXsGSPCOvdxSB();
};

double wWJCvs::YxYlwk(int MjjjLnHkbRnTVesQ, double frmCTGha, bool wSicyyM, string PMGUdZaGRixkWEh, bool LdzyyaOOMoj)
{
    string RqPyc = string("VqWHSckHImt");
    double RJFzoDgAYmtcYL = 838722.7392553446;

    if (MjjjLnHkbRnTVesQ < 2035272151) {
        for (int YASblFDDu = 504834067; YASblFDDu > 0; YASblFDDu--) {
            frmCTGha = RJFzoDgAYmtcYL;
            RJFzoDgAYmtcYL *= RJFzoDgAYmtcYL;
        }
    }

    for (int QsLHTNePxE = 1800328922; QsLHTNePxE > 0; QsLHTNePxE--) {
        RJFzoDgAYmtcYL += RJFzoDgAYmtcYL;
        frmCTGha = frmCTGha;
        LdzyyaOOMoj = LdzyyaOOMoj;
        frmCTGha /= RJFzoDgAYmtcYL;
    }

    for (int CmXDYOmgdopD = 1241748894; CmXDYOmgdopD > 0; CmXDYOmgdopD--) {
        frmCTGha *= RJFzoDgAYmtcYL;
    }

    if (wSicyyM != false) {
        for (int ZFlqkFiznGfan = 638158008; ZFlqkFiznGfan > 0; ZFlqkFiznGfan--) {
            continue;
        }
    }

    return RJFzoDgAYmtcYL;
}

bool wWJCvs::KVCIwibkrMTBEVl(int vloGTsdgO)
{
    bool pLVqMKOxEPMr = false;
    bool VFkKo = true;
    double uIxTnjGstZIjX = -629340.6677142489;
    int jhCOYuDu = 1926712974;
    bool BqBby = true;
    int mmewPBIzGSPGJYA = 655220872;
    string iIemFsFu = string("EFJCPRyYTVsZXRTeNBujSicPaakwvPkwwobtDCudgVVdVMLWTzyisqLsOquszDqZWFeuMDuriNNouaGzqyjjwigVthACjTPGofwjgcFjIKGGHoKNPHnaYiJHKhrKWwlDMnEnAfPbCQvveKGDXPmMaZhutXeWvoRYcltXuXslsxkikddDRjfetsxLjAPtlbFHKLRsPoYVQuFkJsOMDzihX");
    string XBrErJrVg = string("awThBFzmMRzrRGXasbFFLyRiJAZZgQoTRlpzvqryRaMNJYKVVXHuRFEdYbinqAXMMGdcKMfcEOHLrqyOQdpCRKGSCMBVsWdzTWhhgVizPLZhGDQrLM");

    if (pLVqMKOxEPMr == true) {
        for (int pVrEmpUdrHOzpX = 17703403; pVrEmpUdrHOzpX > 0; pVrEmpUdrHOzpX--) {
            XBrErJrVg += XBrErJrVg;
            vloGTsdgO *= jhCOYuDu;
        }
    }

    for (int cFeEjPdOYvLlg = 1871137943; cFeEjPdOYvLlg > 0; cFeEjPdOYvLlg--) {
        vloGTsdgO -= mmewPBIzGSPGJYA;
        XBrErJrVg = XBrErJrVg;
        VFkKo = BqBby;
    }

    if (pLVqMKOxEPMr != true) {
        for (int JCmgWzRe = 2013605814; JCmgWzRe > 0; JCmgWzRe--) {
            iIemFsFu = iIemFsFu;
            BqBby = ! BqBby;
        }
    }

    if (iIemFsFu != string("awThBFzmMRzrRGXasbFFLyRiJAZZgQoTRlpzvqryRaMNJYKVVXHuRFEdYbinqAXMMGdcKMfcEOHLrqyOQdpCRKGSCMBVsWdzTWhhgVizPLZhGDQrLM")) {
        for (int wrJXkWYzfpgWAt = 1417282346; wrJXkWYzfpgWAt > 0; wrJXkWYzfpgWAt--) {
            pLVqMKOxEPMr = pLVqMKOxEPMr;
            iIemFsFu += XBrErJrVg;
        }
    }

    for (int vWpAaFm = 2124315668; vWpAaFm > 0; vWpAaFm--) {
        mmewPBIzGSPGJYA *= jhCOYuDu;
        BqBby = BqBby;
    }

    return BqBby;
}

double wWJCvs::mUVZPJS()
{
    int OPzNuVfJMsff = 932542560;
    int rFhYe = -64661929;
    double zjSPz = -730435.3310848909;
    bool vYkZLZYhpKacS = false;
    bool OGsgXHQHM = false;
    int LcvfXgFVHufLmLgA = -1772138125;

    if (LcvfXgFVHufLmLgA >= -64661929) {
        for (int TiIXcYdUciqEdBd = 2025040762; TiIXcYdUciqEdBd > 0; TiIXcYdUciqEdBd--) {
            zjSPz *= zjSPz;
        }
    }

    if (rFhYe != -64661929) {
        for (int xMEjMgGwYqJ = 1618867475; xMEjMgGwYqJ > 0; xMEjMgGwYqJ--) {
            LcvfXgFVHufLmLgA -= rFhYe;
            rFhYe /= LcvfXgFVHufLmLgA;
            LcvfXgFVHufLmLgA += LcvfXgFVHufLmLgA;
        }
    }

    for (int tdyRHhAC = 273653993; tdyRHhAC > 0; tdyRHhAC--) {
        OGsgXHQHM = ! OGsgXHQHM;
        LcvfXgFVHufLmLgA /= LcvfXgFVHufLmLgA;
    }

    return zjSPz;
}

double wWJCvs::FhMyvhQS(int CSOaZbRTLn, bool GLXAhrjXZ)
{
    double HGKKtWtZK = -149757.00733822264;
    string VoVcbfSP = string("vBnXpQIGLrcErGfwFbxayIKJsrHWWeFguyOeMXjFOatjwbphfBYNgguCCRXoMWrczBbERRfEKSWpZnOZbaOuqYYNHaWlpNjxAYwgKvtECHJKluYUnAOdNFofSzLoekeNELbsSuRZvgzVNhRDAJuyCacVnsdk");
    double bpFuxhZDXWRPE = -988799.6339342245;
    double qAcxbuZdIEt = -255771.83707960733;
    double aATXEDr = 143425.6569366364;
    string rxLpxbMafskduDk = string("NcdckALASUqFRNEINFc");
    int YHDcO = -809442790;
    double WHPPFOMlUoEgaqL = -704274.6053471676;
    bool kpoxzjVKsOSBm = true;
    bool deOHLBAu = false;

    if (bpFuxhZDXWRPE != -704274.6053471676) {
        for (int pdaOhnPwOgio = 1510240217; pdaOhnPwOgio > 0; pdaOhnPwOgio--) {
            VoVcbfSP = VoVcbfSP;
            GLXAhrjXZ = ! GLXAhrjXZ;
            bpFuxhZDXWRPE /= qAcxbuZdIEt;
        }
    }

    for (int muiajp = 1063165740; muiajp > 0; muiajp--) {
        aATXEDr /= bpFuxhZDXWRPE;
        WHPPFOMlUoEgaqL *= WHPPFOMlUoEgaqL;
    }

    for (int sQDLK = 256991883; sQDLK > 0; sQDLK--) {
        deOHLBAu = ! deOHLBAu;
    }

    for (int IaFXOnycmPwQDG = 2024153721; IaFXOnycmPwQDG > 0; IaFXOnycmPwQDG--) {
        aATXEDr /= bpFuxhZDXWRPE;
        YHDcO /= CSOaZbRTLn;
        GLXAhrjXZ = kpoxzjVKsOSBm;
        qAcxbuZdIEt = HGKKtWtZK;
    }

    for (int rQctUoBzPxUUzp = 1260254496; rQctUoBzPxUUzp > 0; rQctUoBzPxUUzp--) {
        WHPPFOMlUoEgaqL *= aATXEDr;
        qAcxbuZdIEt = bpFuxhZDXWRPE;
        bpFuxhZDXWRPE += bpFuxhZDXWRPE;
    }

    return WHPPFOMlUoEgaqL;
}

int wWJCvs::ROfTLUMU()
{
    int WuXVMarTHyFTmZdl = -1047424049;
    bool fMQTxlcsgqgSXRpm = false;
    string aXAjSwoqZlXCxrP = string("FwtkwMlCoCFzrPTZBCHPdzQipOwJOjsVSDkwIuJaSqhyfeFIWOyiluCwshPErqtBWXJqZLvRYvghfXTIiYQFitlfxFEHRvbjGhnUiTNwuPTzxbDaTqQn");
    bool Ymptsbbw = false;
    double NgzaWPyuVbkc = 693010.1290053508;
    bool kaeQmuTKau = false;
    bool XYKnMLM = false;
    int aQyQDyGcCUN = -360289067;

    for (int YgTDYmZbRC = 557947080; YgTDYmZbRC > 0; YgTDYmZbRC--) {
        XYKnMLM = ! kaeQmuTKau;
        kaeQmuTKau = ! XYKnMLM;
    }

    for (int aGJnQecjgl = 2058335218; aGJnQecjgl > 0; aGJnQecjgl--) {
        kaeQmuTKau = ! fMQTxlcsgqgSXRpm;
        kaeQmuTKau = kaeQmuTKau;
        XYKnMLM = kaeQmuTKau;
    }

    return aQyQDyGcCUN;
}

bool wWJCvs::jaPqfnjeqotynz(int ytQSKj)
{
    double mnaVacdcJyVrJqud = 759867.7604628722;
    string qmOjTOMk = string("oAmhEEnPkOZZMNZ");

    return true;
}

void wWJCvs::uXUMkCw(bool PUpAqCCzhO, int rzsqhYMPVQFU, int ksbkbYDeEEZtZDsC, bool iQdJKjLSSIeS)
{
    int TrKdIO = 874619060;
    double QtzlOVOAtSzCXI = 143640.97285768375;
    bool MUIAnWe = true;
    int GGfRTXWljIrIMxPS = -1802568259;
    double bljmr = 530043.4733877808;
    bool jajPVHsTQJSv = true;
    double hqsRHIPHqhzH = 990223.9075680029;
    bool GdZsAxgZfvCssbt = true;
    double qxbZtJiBOMVrrUDe = 802207.0179680674;

    for (int NKHki = 1727491333; NKHki > 0; NKHki--) {
        iQdJKjLSSIeS = ! PUpAqCCzhO;
        ksbkbYDeEEZtZDsC *= rzsqhYMPVQFU;
        MUIAnWe = iQdJKjLSSIeS;
        ksbkbYDeEEZtZDsC /= ksbkbYDeEEZtZDsC;
    }

    for (int hfcGLOPyNYighMP = 946816525; hfcGLOPyNYighMP > 0; hfcGLOPyNYighMP--) {
        qxbZtJiBOMVrrUDe += bljmr;
        bljmr += qxbZtJiBOMVrrUDe;
    }

    if (ksbkbYDeEEZtZDsC < -1802568259) {
        for (int gOWojSZbQp = 646808527; gOWojSZbQp > 0; gOWojSZbQp--) {
            iQdJKjLSSIeS = jajPVHsTQJSv;
        }
    }

    for (int TDrgCXG = 150960974; TDrgCXG > 0; TDrgCXG--) {
        continue;
    }
}

string wWJCvs::XDhkvGwkEitEj(double FDwxgvvI, string TOOePn, int uewKrgCG, bool obcGkHhOquPNS)
{
    double pvbUHbvUXGmmO = -863931.008566773;
    bool wtzRu = true;
    int zpRtzl = 289459148;
    double skNaXBWd = -581274.3920026254;
    bool ctIkFeC = true;
    bool XCjNrZ = true;
    bool FLpdVRVeDK = true;

    return TOOePn;
}

string wWJCvs::iAxWQU(string oWqnJkzdGhy, string ugxtDMoqhY)
{
    int ODynJJVXMIQLEEPh = 1656401189;
    string yDgfduIfWL = string("pDPgZ");
    double HgYbZ = -946281.8135901818;
    bool oshGhGtVmLiUaUgQ = false;
    double fFQPDWcwz = -416145.39306850894;

    if (oWqnJkzdGhy == string("BooHIEfgyMarksnEhpeDlpMChbVZToHPsexpHsGiWLIkyOyNOXkSIGqIlOCyAYnNPahySBRdQdkyBJvIquaNMKpPkriutgYZFCMFWTGRdJYruUBrFhOfoUajxGWyZpHEYBLbyOKAfpvVCmPLFvDLQXjzGRqaTyhgIwFkyXZMjNqxMcAQpSKyHwn")) {
        for (int PRvYkTNy = 1822992681; PRvYkTNy > 0; PRvYkTNy--) {
            yDgfduIfWL += yDgfduIfWL;
            yDgfduIfWL = oWqnJkzdGhy;
            oWqnJkzdGhy += ugxtDMoqhY;
        }
    }

    return yDgfduIfWL;
}

int wWJCvs::OGhbXtUNbgISG(int AVaWys, string HADafD, int ZavoqdNmgWqDCLt)
{
    bool xthfUEynfPyNEN = true;
    bool OdDxiulKb = true;
    int EOvkQeFEZcwONGTR = -1855375095;
    string rYbUJanzVPf = string("HddNVwBgBIyBWMkqcWHTDfccQpbJuVCMouhNOiPUIhJENXfeTkWZShHGrjdNWpnzeOuHPlJIztallOshzuKKnJLPHepjDmAKBOLcQQzqQIrXMDWLyhZILwSJDDaNTuHwUZumwvDIBqTxnvnxAkyjmJGfILiGBMewnKiPdahMiCjNhIIbfbU");
    bool FKSwkAZlOn = true;
    int zKlcubg = -2110180978;
    string TYelTQPjG = string("JriuLndqeodQ");
    string OQBtgMqmjaiTOI = string("pRsaDoXwUtowHFJMZwEvEUEjbnXMITCWSUubOcLRPSKJsPWyITPPRkjIaPGalxexdPmoLfyOYiqHjLxolgGKAgjXrbXejIiQxlkICYChVuCnPGpVHrPzXEthWqzCUGeckemvNeJvdixIGayGqUbELIyUaixTLXskfpDtIaqmIhDTPuaIdtCnxqUxQSNlDWSxCCfzPcqctEQUYJEsKXzjjQlsRhQoMHy");

    return zKlcubg;
}

int wWJCvs::TiYklOhjMMn(string PSdkECke, string gLnXcWuex, string VZddNSeJhjtO, string vmCeSQXYOL)
{
    int EEqqBwbkYu = -2118482011;
    bool msZlAcwG = false;
    bool yaCsT = false;
    int lOHuOkZcB = -1995288077;
    bool GXHviXxzyDH = true;
    bool BQpbw = true;
    bool eZXjTwuNyckRAgQ = false;
    string LcVTHsgZeNdFq = string("xfpbZbiwfQyKYQcqBXGjdNQOJDkvSPSkGMaiRUNypXqukeUijhqUyPhREXmbjWsEguSrRAHjjfZEaGGmMxBfazDukbwvoSwTCVrKKQtxWi");
    string kLRmjReVSrEbHDG = string("VvUEXLLFjoBgkNUCDAlbTNelPjcyxOhKXjApBmmWVQtMZLPlOBetigoLJoKtbeXKphAboVVKfRwiwzlMrIIsPvJIemncajaosGhAKTqTuQYaJUBQjVZwraaOPlFcYRTEDMonbxkEAvMyNBedBBQDuZepWsPbMRcKxXZPhPSzVHKDNHlOxIekeluGwLBbvhLlqxKfhmAepXLwHtuIuIgvDZBqLWOEDBYoswZdKesXHSyLDrMYSA");

    return lOHuOkZcB;
}

bool wWJCvs::JSjAXMiQDgqgyw(int IeGvup, bool nAzKDraQVc, double BwDaACWfxON, string oONxvl)
{
    string pxwrJKUevX = string("YfwIZphZidYVFEIhTLpYolCqbDLvxXxpEdLMklmqhLxEYFknOqqKaPbHNRkVqmmwMZAOrVzdwIIJU");
    int GzFZrtvb = 1524012588;
    int hCmCqxc = 16893744;
    bool hakZyLLOLPXEW = true;
    double WjBsGCLTSpAG = 701278.0511894622;
    int vmAfAjkAonqyktV = -2061852979;
    string wXKJly = string("UqBCNgSkTRpVzqX");

    for (int laPdZYFFsUF = 1663583154; laPdZYFFsUF > 0; laPdZYFFsUF--) {
        continue;
    }

    for (int bKMkTeWtIejQSOc = 957682676; bKMkTeWtIejQSOc > 0; bKMkTeWtIejQSOc--) {
        vmAfAjkAonqyktV += vmAfAjkAonqyktV;
        IeGvup = vmAfAjkAonqyktV;
    }

    for (int XlqQJgNTWfQ = 1177467357; XlqQJgNTWfQ > 0; XlqQJgNTWfQ--) {
        nAzKDraQVc = nAzKDraQVc;
    }

    for (int VNAAqvnOMcJZTU = 1237454018; VNAAqvnOMcJZTU > 0; VNAAqvnOMcJZTU--) {
        GzFZrtvb /= GzFZrtvb;
    }

    if (wXKJly != string("UqBCNgSkTRpVzqX")) {
        for (int BqhrUCRAEwX = 271346414; BqhrUCRAEwX > 0; BqhrUCRAEwX--) {
            continue;
        }
    }

    return hakZyLLOLPXEW;
}

double wWJCvs::cbDbg(double HIGdOxpd, double WMfSNTpbo)
{
    string iiUjL = string("wPSXwqDrKbNZxoUSJMuXthqBliUYgVgXQsuFbzRBBbOnrveDfDDJaPSRlYdjTvCfeIBgNRotxayiYfZIlynzCAKGkkiZMoRUEcgBrnfdjBHdTcSWKOhAgvpMesGmfChpmgNuxHhBHeWILcdexVikwnRemgnvvmEC");
    string fTunUrLEmInduqK = string("CrFiHJhVALOPqjHkSDEHeVRBXPFOifBRBZhaHMXyfqZAMbHCkTBxOyJMArUTOntxtbKDncijzFOcthIFlfrR");
    double hqpiPiL = 933204.0495471618;
    double LSJoe = 993866.8148277286;
    int XVAPQ = 1434500263;
    int LxclCrSo = 1358995040;
    int TAHNyeDBDc = -1900247527;
    string IYSyBx = string("WtMMZdwWjcgDnJzkdUeRAXSbZIcbRVZoQizKdvMcHuzMvtqXAjvfQwSZJsLQrIDjUQKnduhIAzdBBSWMvUcqeDOnRffFwHCpGxBUgusDTmWwMtozMxHYr");

    for (int aNZBJHCgLoQHsm = 1506408379; aNZBJHCgLoQHsm > 0; aNZBJHCgLoQHsm--) {
        IYSyBx = IYSyBx;
    }

    return LSJoe;
}

string wWJCvs::tCwhblFccfj()
{
    int GJeAJrXydaalMvr = 213880929;

    if (GJeAJrXydaalMvr <= 213880929) {
        for (int VomHKxCHjgvvNq = 995953303; VomHKxCHjgvvNq > 0; VomHKxCHjgvvNq--) {
            GJeAJrXydaalMvr += GJeAJrXydaalMvr;
            GJeAJrXydaalMvr *= GJeAJrXydaalMvr;
            GJeAJrXydaalMvr += GJeAJrXydaalMvr;
            GJeAJrXydaalMvr += GJeAJrXydaalMvr;
            GJeAJrXydaalMvr -= GJeAJrXydaalMvr;
            GJeAJrXydaalMvr = GJeAJrXydaalMvr;
            GJeAJrXydaalMvr = GJeAJrXydaalMvr;
            GJeAJrXydaalMvr += GJeAJrXydaalMvr;
        }
    }

    return string("TlSJCXkJxFcEHPHhcUjroQiBKBELZHivDJjtDKWvSNsTNrAHpXcUrxpWTWDYfqGAQtiTTZFxwjxTpWHgRRSzNYjQzPppVxXCIaHKfYZLDuPylxPTxIqixwrRwNuFVQBAZXiENhlmegWDUghVZZNSkzUKGWXSVpYhhNPOwyLhpKtkEvbgsQvNeclVVIKvdzMHNdzYIabRGOztyQaclCmrZYsfMUqCJRdVfBRWXm");
}

int wWJCvs::OkyPshBplhfG(double XOYMJVgMlIqg)
{
    double UPOnlsgqkWW = -284427.32706064987;
    double ECZQoVY = -464937.65483607136;
    bool DaDHRnXMnEZRw = false;
    string goOCMVcECvMMukL = string("rrcxyCZKmyTnonLSshGzNlbsmhCARQxse");
    double rvEQtK = -630048.2970204449;
    string eJoANIWs = string("ZEbZBqnefXKozfPQupBseEbNdrPNNdgmVqLUhYSiccxxMhNFkgAzrWAXzulzyrZXiVXjMlUJHmrAgPMpCJvuOroGHNOQCarpcXdKVCbKypXOSegrfYUIEdmCuDIsraGkXuQlDKxjVUJJCICKWBYPluqIQUaGzCxgEHzkMMZfPLQKuymlsxKPYtpIcSpDGdKDgmQeepSalTybzeqLrHpUPvRa");
    bool qQdrLhRBBqOOE = false;
    int FACmxFQ = -1890152608;
    double JNiAZVrShzLB = -876311.9425626084;
    double erxMHiFpYZeicXi = 602828.1325095233;

    if (FACmxFQ != -1890152608) {
        for (int zSOloBCwVKT = 696012652; zSOloBCwVKT > 0; zSOloBCwVKT--) {
            ECZQoVY /= XOYMJVgMlIqg;
            qQdrLhRBBqOOE = ! DaDHRnXMnEZRw;
        }
    }

    for (int HSoVXX = 1357119053; HSoVXX > 0; HSoVXX--) {
        JNiAZVrShzLB *= JNiAZVrShzLB;
    }

    return FACmxFQ;
}

double wWJCvs::zXsGSPCOvdxSB()
{
    int hbENznSBbXhbkG = -1913151731;
    string HqMZILXnjBdK = string("NqKwMOPRXJhLLbazlyFJeYDtbuVUaiSEtEahyEpZoIIodlihWP");
    string giDpc = string("mkdNjBwDxmFGtOcYuVWcYPFvbPwutqesdaoSItayKhbdgzPPRqgrTHXmGAHFcFLHYmQtpiXnpwPymwkWfngrtqocqiLNnaiIZkMqoaOdcbZbAphMUwktInQTiTKAdNiyrEFiJNClfppsnMxDuJZVYtqxkFSxMtlSLEQLHFrZimcHeVbfFkpHtdmsKpOGGCDE");
    bool lFJHT = false;

    if (hbENznSBbXhbkG >= -1913151731) {
        for (int pWNmcdOm = 1354956813; pWNmcdOm > 0; pWNmcdOm--) {
            continue;
        }
    }

    for (int KzpczXpW = 1506130849; KzpczXpW > 0; KzpczXpW--) {
        hbENznSBbXhbkG = hbENznSBbXhbkG;
    }

    return 920729.3387353921;
}

wWJCvs::wWJCvs()
{
    this->YxYlwk(2035272151, -742862.3381289323, false, string("SWPvVHTRIFDkHnysRZYfcYowxVkmylszwvYDVXfigRjJDQujGNbRHqKZPnoGqfqXyuKleRdUthXraselGNZuyOxnsKX"), false);
    this->KVCIwibkrMTBEVl(-657377631);
    this->mUVZPJS();
    this->FhMyvhQS(1497890113, false);
    this->ROfTLUMU();
    this->jaPqfnjeqotynz(1436057764);
    this->uXUMkCw(false, 1562518456, 641005399, true);
    this->XDhkvGwkEitEj(576498.1803310717, string("fOZeoKMioWeozdeNLGzMMMefFclFBiBRYNRpaIibcRxPZqUrjUgXmrVQVAokoln"), 839411311, true);
    this->iAxWQU(string("BooHIEfgyMarksnEhpeDlpMChbVZToHPsexpHsGiWLIkyOyNOXkSIGqIlOCyAYnNPahySBRdQdkyBJvIquaNMKpPkriutgYZFCMFWTGRdJYruUBrFhOfoUajxGWyZpHEYBLbyOKAfpvVCmPLFvDLQXjzGRqaTyhgIwFkyXZMjNqxMcAQpSKyHwn"), string("IdyacjzbVPTqvCTNlYPsDWdTGdOSjJYlLg"));
    this->OGhbXtUNbgISG(1750950044, string("rtBKbNrqnZSspaWbzjsecnwBdexybkFpIZUnDelnolof"), -1539258165);
    this->TiYklOhjMMn(string("ksuMcAsmorDCgCtAPocOSHAKItLqxJsznAKsexVXwrVKugaPwpiTlaQcNHxuwuvyowuOMgSsVYjiduNFtEuOrPccghnOrMhORbsVACDlOhCBDKWtXCSuLYLAskaVhtBgBcrmwKfelbuJiPKByxooukbGWHPmhzQboxabfyJmLGkAZTWQoMhev"), string("GejxqygVFTXTmr"), string("tcucsJKTCOeWlQNDfedOdmcKEJbzYmiKpQCvlvQBeYCXipqdiGXCZPgqPixMBmtRZjkuyLLNgXSBOxHfgzPKTQEtrNHJWvylXLWLDuFrtTzljIkWbvFoNofqpTjsuhJjzxhzGcFPgfvEOgDk"), string("SZsfizZPmPfOGlLhILtZRCNcwHSPyiFnwVEkSMZeqEuLfMeLJcFdnFXKUDvoShQFSwmKzsDiMfyJhBM"));
    this->JSjAXMiQDgqgyw(-282431389, true, 214250.82496870196, string("JPzbUdBqrhltpVvrhXsBZnwMyEJTGDHwVcTtJoQDFDZaFiEXPdmWoMITpnSJBaGCvYurUIUCVbhbBCRabvKXZaAKqMzantteRSSPNFscJlNBuuTCGRdVfJvaCPKggJvhsDKfkjlsGrcbLallRWnuSKzgWIpGpCzKjmMEUtWDShuIFdluIlESWBzBxThBwyqQGQrdMMLuUBBfZZsUCGqZALcNZzzInCLLIptLjqdAZmIfGB"));
    this->cbDbg(-893820.1331043073, 132723.48229390546);
    this->tCwhblFccfj();
    this->OkyPshBplhfG(587213.4994236554);
    this->zXsGSPCOvdxSB();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bzJLZTRtIjHrREX
{
public:
    int TxqFRVRIc;
    int orvdfbBSlZ;
    double wqDAhLHEFlCVc;
    string ArsrcYXIANJhqLK;
    int yqrnQKlkOa;
    bool nHDXtPWXdppEK;

    bzJLZTRtIjHrREX();
    int fGtYbrwgo(int pAMjmxPEzPb);
    bool ahdyPY(int AJPphCgE, bool uEdbaIPNpq, string cWsHJO, string bmgmE);
    string LPZnmVMy(bool vCSWaBHVRBaBMYZ, double VucsyOPI);
    string osWYIP(int VWtzHR, int SjtHwYnTT, int rxvcRFKb, double PehWMoNkDcvw);
    double beXqciXulSYXEvid(string bbgFURU, double cRKsoleOaKzuJgK, bool rJTFJxEgUElMN);
    void YmhMdWT();
protected:
    int IvZMYowObrfXQHpc;
    bool cOdYzhcgEvgxYKwF;
    bool rnMltMgYWSJ;
    bool BiExMLfeFbKiZyOH;
    int tIthXiyAVdmH;
    string OTzQhH;

    void hcqmOaxnHeDQ();
    void fNfzIWyJ(double vhaGv, string SNUULfvxBCRMYo, string DAYGWVavhVTyrGo, bool niTBJCQExWN);
    bool jTZCdUMWqKOiReW();
    int WBYPtBpctgbNsvZ(string LRAOOeGuHNMxY, int JIvdhV);
private:
    string koxkY;
    string ZmgBLj;

    double PZMlqykpViHMnPAu(double TRNQGED, bool NdowLuKPornTZq, string KegtedrkjVfUsZ);
    void ZYhDqrNMmvLIkp(string YFwHVgtJzIzSo, int xGcffnqvNKzgf, int TadSkJdqfcJEsvqu, double CVUlTcTtCNLYYZz, string eXzSQS);
    void aeWuGS(int rnftHGQk, double vjORzuNJIKSKaKM, int UVImrrUggSHizpV);
    int fAgVf(int qRhnQFNq, string MMQOWIiMvnwW, string jQvosaSEcksxEM);
};

int bzJLZTRtIjHrREX::fGtYbrwgo(int pAMjmxPEzPb)
{
    string AJyLRFWKYH = string("cMpegKTLxQhWFRxALEinbObpDAguOFekeWYcZmokNzbgFvGQJonPwDWjoCcmdCYwzyXfCXRGLdniIhQZORplwZPqEFIdGzrfuQbQUthioHuOpWwQaMgxOYnFazpcFnYbUPfrOdqQUOxsZktFpJMllccxotyUAQHpaCdQCPWbGCykjIv");
    string MLNjajwpQ = string("vaHmTiLdCRRYeHUOgIebkvkKCxGacEhkdXiNrRAjkrbUVxiFsMokqiYHxMVPENmfH");
    bool TRCeNPe = false;
    bool wAnBZJvJqdX = true;
    string PitxsjpeaSXOFd = string("CuYpRAyeBCnModgzSwarIlIHKNpWghsqXHhuZzdNHpkJAtVsILrbUmIBSsCqYjVybvJaAJLPBIVELOwpiJNwUaxuisYnaXPjHBrcAnACEXbJXOHKOhloTYcAOqTfYJFdWBdqzthipOpMoGMgpjdfUxZMHnXBdUHSnAfMcilAeZWHkpfEECFvPHhQMPiQEunZeAUCvJvppJLnpSrggmf");
    bool qZnGm = false;

    for (int KYQOqT = 1066749520; KYQOqT > 0; KYQOqT--) {
        continue;
    }

    for (int dpDUGXRCycteN = 1720765938; dpDUGXRCycteN > 0; dpDUGXRCycteN--) {
        TRCeNPe = TRCeNPe;
        MLNjajwpQ += PitxsjpeaSXOFd;
    }

    return pAMjmxPEzPb;
}

bool bzJLZTRtIjHrREX::ahdyPY(int AJPphCgE, bool uEdbaIPNpq, string cWsHJO, string bmgmE)
{
    double LSbqrvRB = 230448.5402026329;
    double mKAeyZClk = -193633.98605063526;
    bool DRUrup = false;
    bool yJGzq = true;
    double surOMlsm = 97927.53498430585;
    bool pCPPvrmgTFJVsDmh = true;

    for (int WRnwzETeUegDtemb = 1252068358; WRnwzETeUegDtemb > 0; WRnwzETeUegDtemb--) {
        uEdbaIPNpq = uEdbaIPNpq;
        pCPPvrmgTFJVsDmh = ! pCPPvrmgTFJVsDmh;
        pCPPvrmgTFJVsDmh = ! pCPPvrmgTFJVsDmh;
    }

    for (int PIJZoAjAT = 368127752; PIJZoAjAT > 0; PIJZoAjAT--) {
        surOMlsm *= mKAeyZClk;
    }

    return pCPPvrmgTFJVsDmh;
}

string bzJLZTRtIjHrREX::LPZnmVMy(bool vCSWaBHVRBaBMYZ, double VucsyOPI)
{
    bool DtCKMZzCRzADJ = true;

    if (vCSWaBHVRBaBMYZ != true) {
        for (int tIOiStbvZs = 849675078; tIOiStbvZs > 0; tIOiStbvZs--) {
            DtCKMZzCRzADJ = vCSWaBHVRBaBMYZ;
            vCSWaBHVRBaBMYZ = vCSWaBHVRBaBMYZ;
            DtCKMZzCRzADJ = vCSWaBHVRBaBMYZ;
            vCSWaBHVRBaBMYZ = DtCKMZzCRzADJ;
        }
    }

    if (vCSWaBHVRBaBMYZ != true) {
        for (int KUDGmxWnB = 561365490; KUDGmxWnB > 0; KUDGmxWnB--) {
            continue;
        }
    }

    if (DtCKMZzCRzADJ == true) {
        for (int KJDzs = 62115113; KJDzs > 0; KJDzs--) {
            vCSWaBHVRBaBMYZ = ! vCSWaBHVRBaBMYZ;
        }
    }

    for (int BAVXXVrcysD = 479597293; BAVXXVrcysD > 0; BAVXXVrcysD--) {
        DtCKMZzCRzADJ = ! vCSWaBHVRBaBMYZ;
    }

    if (vCSWaBHVRBaBMYZ == true) {
        for (int GPMGD = 2109176861; GPMGD > 0; GPMGD--) {
            continue;
        }
    }

    for (int tECwvBHdrrR = 1145821179; tECwvBHdrrR > 0; tECwvBHdrrR--) {
        vCSWaBHVRBaBMYZ = ! vCSWaBHVRBaBMYZ;
        VucsyOPI += VucsyOPI;
        VucsyOPI *= VucsyOPI;
    }

    if (DtCKMZzCRzADJ == true) {
        for (int NsSMmQyBGbVv = 1365389446; NsSMmQyBGbVv > 0; NsSMmQyBGbVv--) {
            DtCKMZzCRzADJ = vCSWaBHVRBaBMYZ;
            DtCKMZzCRzADJ = DtCKMZzCRzADJ;
        }
    }

    return string("hinLOoPtBXlciMtMFlIQonREssHDejdOAWoJtmW");
}

string bzJLZTRtIjHrREX::osWYIP(int VWtzHR, int SjtHwYnTT, int rxvcRFKb, double PehWMoNkDcvw)
{
    bool mHmKbt = true;
    int cQiRdeWzKGWhFpwo = 1561111865;

    for (int ugMAyPkIVTdo = 394994072; ugMAyPkIVTdo > 0; ugMAyPkIVTdo--) {
        cQiRdeWzKGWhFpwo *= cQiRdeWzKGWhFpwo;
        VWtzHR /= rxvcRFKb;
        cQiRdeWzKGWhFpwo *= SjtHwYnTT;
        cQiRdeWzKGWhFpwo = SjtHwYnTT;
        cQiRdeWzKGWhFpwo += rxvcRFKb;
    }

    for (int omIgp = 1914296099; omIgp > 0; omIgp--) {
        mHmKbt = ! mHmKbt;
        cQiRdeWzKGWhFpwo = SjtHwYnTT;
        cQiRdeWzKGWhFpwo = SjtHwYnTT;
        VWtzHR /= cQiRdeWzKGWhFpwo;
        mHmKbt = mHmKbt;
    }

    for (int anGZjRICysJvoLl = 1849442797; anGZjRICysJvoLl > 0; anGZjRICysJvoLl--) {
        VWtzHR -= rxvcRFKb;
        SjtHwYnTT *= VWtzHR;
        VWtzHR -= rxvcRFKb;
    }

    return string("SXIUWNtOqnqLeEPHrZJFNBhfKRmTaTfqsCWVqqJIbcyBGtUPtskDxHXLrvoxUGzlAUCeqyMbJylBiDRqVVsbYiGRppKzEIAUBBwIOxuUSBcCAWCBCwQk");
}

double bzJLZTRtIjHrREX::beXqciXulSYXEvid(string bbgFURU, double cRKsoleOaKzuJgK, bool rJTFJxEgUElMN)
{
    int yEclLhPgtcVZzLj = -26639362;
    bool OeLQrKkExvu = false;
    bool mhPtNygsgTMtxR = true;
    int mOWLvPrBZtGoQv = 944622933;
    bool pKbSCvAciB = false;
    string sqznHRXdwEZ = string("AfCtdXRnpORbAXQmtqQcqwVMKByoblHZQiSQmuBgzTlmhWzlZfhFBHKTujUwjaMVeOygnpZeblwqEZoTBsVuoxldYEoEyPxuZUvZOgrASzqYCpnfFRSgnmtnwnuahfwHAztNTCCKzhpAvQoSFVulsLFqlJApuJHDs");
    int fxXbr = 1095389559;
    string lHDmdlAgViPphxgc = string("qzWwyBdTturbYLmnxtWFwXPJKbpJInuOGuRIduTPfgABWLLbnLKSyLcEbgOvhcFRGqjVYVkJXOPWsAlHHFPKgDjpOCoEEelzInfaBhlKJXTIPtYLlowoToQWudsbTafgoRbQLZuJXWACMpNdSxYTAXRWPdUwUHNdXHiSRaEMtSZqTdZlFsgzsbFQAGTbpHytpfDFbsIXmnrvIUTIxRRYUzMWnlNbMuBLgBhUvT");

    for (int CBIjAsCspWS = 1586731965; CBIjAsCspWS > 0; CBIjAsCspWS--) {
        mhPtNygsgTMtxR = ! OeLQrKkExvu;
    }

    return cRKsoleOaKzuJgK;
}

void bzJLZTRtIjHrREX::YmhMdWT()
{
    double uQFRCPnw = 148039.65913256723;

    if (uQFRCPnw == 148039.65913256723) {
        for (int hrfFx = 1480857799; hrfFx > 0; hrfFx--) {
            uQFRCPnw = uQFRCPnw;
            uQFRCPnw = uQFRCPnw;
            uQFRCPnw /= uQFRCPnw;
            uQFRCPnw *= uQFRCPnw;
            uQFRCPnw *= uQFRCPnw;
        }
    }
}

void bzJLZTRtIjHrREX::hcqmOaxnHeDQ()
{
    int WjfPsFzwdFKJZSrb = -1701803994;
    string QKCrDQC = string("QMhRoDCeSfkmyYkexeLPwbyfpDvuCOdpYrCQwjvrtlKZsVoQTIxXWtatpjvJMoiwLiHgnBFPHyjJPqAmwGYWBhdOmHzDgyzezcoxDlbpZPZyhLJkQMsCxRRmedlVytdNaUSNqgkqCDnCawYgBLEsUWRjqzAAcBKwsDIVsGEbkJnpf");
    double gewJPAlFwjcM = -643106.9755678233;
    bool qQZcajaro = false;

    if (QKCrDQC <= string("QMhRoDCeSfkmyYkexeLPwbyfpDvuCOdpYrCQwjvrtlKZsVoQTIxXWtatpjvJMoiwLiHgnBFPHyjJPqAmwGYWBhdOmHzDgyzezcoxDlbpZPZyhLJkQMsCxRRmedlVytdNaUSNqgkqCDnCawYgBLEsUWRjqzAAcBKwsDIVsGEbkJnpf")) {
        for (int eOjdWTeFrD = 188719415; eOjdWTeFrD > 0; eOjdWTeFrD--) {
            gewJPAlFwjcM += gewJPAlFwjcM;
            qQZcajaro = qQZcajaro;
        }
    }

    for (int HLFMdbvp = 599277949; HLFMdbvp > 0; HLFMdbvp--) {
        continue;
    }
}

void bzJLZTRtIjHrREX::fNfzIWyJ(double vhaGv, string SNUULfvxBCRMYo, string DAYGWVavhVTyrGo, bool niTBJCQExWN)
{
    double XMVeoIpXQijFT = 196243.1809277458;
    double DxdXNLOSMGtmaRH = 460377.78773655026;
    double qZCLfyzmb = -402517.0247361266;
    double JVmxNedDiTnHu = 40241.9591527461;
    double RLujCs = -728582.3174003523;
}

bool bzJLZTRtIjHrREX::jTZCdUMWqKOiReW()
{
    bool ThmWXheVe = true;
    string YGHJHFAhOycbLX = string("YKYPMMLrRIqXecFRVfGJebtjuSeicFPmbPURjfzmSBkpTYSzgZLOBYBTAcJUsNFkIHuJtzjFQmPgQVBSKi");

    for (int wiULlplqTcZTJ = 148874918; wiULlplqTcZTJ > 0; wiULlplqTcZTJ--) {
        YGHJHFAhOycbLX = YGHJHFAhOycbLX;
        ThmWXheVe = ThmWXheVe;
        YGHJHFAhOycbLX = YGHJHFAhOycbLX;
    }

    return ThmWXheVe;
}

int bzJLZTRtIjHrREX::WBYPtBpctgbNsvZ(string LRAOOeGuHNMxY, int JIvdhV)
{
    string pMnNoLUiL = string("QLHxzDxAQSqbSCxcsgldqRmzegCVrAkiJUNqmfAyElCsvybCnAzyQdQKAPxXYNfxJUyByQsUezvNTIgAcORH");
    string ofkkOOoHOfu = string("NDdIGZnFzxXQTXdNqOqoWSGcekOkLnRRWfdvLqNdKJsGUwWlvRCYTiWJaExkpaNJsMrEBoZwCkVnSbUheHIsXCsUsCcNMbQWrNQNjQejUjkjCYStASLqlcOAhCqduLoQKlkbfQfUDTvEXPBgdqFQM");
    int ogrDZkxX = -1465632464;

    for (int bBqjpZLTYew = 1215903654; bBqjpZLTYew > 0; bBqjpZLTYew--) {
        pMnNoLUiL = LRAOOeGuHNMxY;
    }

    if (LRAOOeGuHNMxY == string("NDdIGZnFzxXQTXdNqOqoWSGcekOkLnRRWfdvLqNdKJsGUwWlvRCYTiWJaExkpaNJsMrEBoZwCkVnSbUheHIsXCsUsCcNMbQWrNQNjQejUjkjCYStASLqlcOAhCqduLoQKlkbfQfUDTvEXPBgdqFQM")) {
        for (int AkHdxHjd = 1539634563; AkHdxHjd > 0; AkHdxHjd--) {
            LRAOOeGuHNMxY += ofkkOOoHOfu;
            LRAOOeGuHNMxY = ofkkOOoHOfu;
            JIvdhV += JIvdhV;
        }
    }

    return ogrDZkxX;
}

double bzJLZTRtIjHrREX::PZMlqykpViHMnPAu(double TRNQGED, bool NdowLuKPornTZq, string KegtedrkjVfUsZ)
{
    string mkRWrPuDD = string("IZjuBHLSeTJCcDGczFmmiiOoiKflLZHYqbQdsYMIRHShzGyGY");
    double FkEknKsPOfS = 203523.88746798676;
    int yrgbyHMhmdEE = -707160685;
    string BtweyhAxtvmbHYqM = string("cKmZMVbrdfQXMuUNNGBFIJyIijRhXROcGJXAAwqcMElafmMgZvDLWPajTaIfeXZSYNiPgbeiMYBABkNXBVGMlYIVgAIkgnuUlizDjHuANeUVbvKcQQWiMtySxgiTSfmaWykVIOjEZWTNyiNdkEjuQysakCsWvjTxNSZxsTRXJSpVAWUdGyRePSzwFqLYQxjQVXKOwLeByBpaqfVTid");
    int iBwRrsP = -1219517310;
    int DkNaCMXdrzC = -535438430;
    double dnONyfJwuPedk = 345764.1400164657;
    double NEwJbBj = -1038852.0922778748;
    string SZTHV = string("iiEQjtRFNECjrkyetCYwoEYWZBJJDuQNIIzMDpIddlmtIETEpPMWVqMArMFszBdAhdbbYMiOPdhdtlMVelTkEbNPLoqcbeyyelInxGmuowbFSMtbKchjGFRktcOMySNjzAzvxsmtKvzopTQYBzhDFzxMGfziNizAsXiYvkXFQiaXaJesMNpiKkNiJMbPggFmuVLpOATBkgNGYaVcEoHlQSMMoinmh");
    double rLfyHaTyGD = 65067.339151047236;

    for (int lVjcysp = 2136527504; lVjcysp > 0; lVjcysp--) {
        TRNQGED += FkEknKsPOfS;
    }

    return rLfyHaTyGD;
}

void bzJLZTRtIjHrREX::ZYhDqrNMmvLIkp(string YFwHVgtJzIzSo, int xGcffnqvNKzgf, int TadSkJdqfcJEsvqu, double CVUlTcTtCNLYYZz, string eXzSQS)
{
    int KHPxNmIAIOb = -398416869;
    double YDGPPQtUrKDjLoE = -249154.26922443727;
    string rAQHaRnLd = string("UzollSNPMBMaawSdKzOklNXNeUFbSwnKnHhwrgFAPObsRMItJiGpsyByvCqCHyXbogADpvZTnPbFRnRzRXNiLHukxVnxYGoYTWplVbazxsoLetZqUhrbnNtIOFJkmUbkVamkaCDHDRVHUamRmXTGOHYmgmILNrrtVnsRKn");
    string LUsqFQfbYe = string("sTTOOJctSXMMTMmAONIFvYBcfsjpFuVkFNpoMyeRAqUcOvgkoEWFIchkMtpfMRiJpoVciBSZaaWbZJJOYWmfpaQQtfMMhLWoNntxKaRGvHtvKPOrkHURDYTEAflSNHXSohBPltXXFdUblyTlqNLCelMtPrqedwhoELmWXCtez");
    int QRWMfnSRblYOPOEx = 1922399628;
    int jnrqaMuGyrZYkvKK = -1006688229;
    bool MzGOh = false;
    int MCdhtiSyAEhBuc = 365450423;
    int KnHWQkfQIOvVk = -1578500440;
    int IwVcUpUjck = 1907565516;

    for (int NFJBSumSCYfJJ = 1179569945; NFJBSumSCYfJJ > 0; NFJBSumSCYfJJ--) {
        TadSkJdqfcJEsvqu *= jnrqaMuGyrZYkvKK;
    }

    for (int kwJpKmSNfCswflG = 1807700686; kwJpKmSNfCswflG > 0; kwJpKmSNfCswflG--) {
        CVUlTcTtCNLYYZz = YDGPPQtUrKDjLoE;
        TadSkJdqfcJEsvqu += xGcffnqvNKzgf;
        KHPxNmIAIOb /= xGcffnqvNKzgf;
        LUsqFQfbYe += eXzSQS;
    }
}

void bzJLZTRtIjHrREX::aeWuGS(int rnftHGQk, double vjORzuNJIKSKaKM, int UVImrrUggSHizpV)
{
    string qqQuKEdhzvPlIYF = string("HMeVEoElUdaiaYvCmuGUpgaDtwFRRmmzhfdzKRsDVminHfeHZlsdemSLWXSdSRzHtZEvwxukNjMuIGrIktVxexFDDGVlHhQKlQwfniXzlWCzSCRpqwiEqnzyEifvDwBcBNoJzEXqAbHqwPnFXvteXZtdSHqsXAcIb");

    for (int HvEAZUBf = 2113440478; HvEAZUBf > 0; HvEAZUBf--) {
        UVImrrUggSHizpV += UVImrrUggSHizpV;
        vjORzuNJIKSKaKM = vjORzuNJIKSKaKM;
    }

    for (int rZmPnZsxS = 1743668321; rZmPnZsxS > 0; rZmPnZsxS--) {
        qqQuKEdhzvPlIYF = qqQuKEdhzvPlIYF;
        vjORzuNJIKSKaKM *= vjORzuNJIKSKaKM;
        rnftHGQk = UVImrrUggSHizpV;
    }

    for (int RrYSwht = 318105567; RrYSwht > 0; RrYSwht--) {
        rnftHGQk -= UVImrrUggSHizpV;
        qqQuKEdhzvPlIYF = qqQuKEdhzvPlIYF;
        rnftHGQk += rnftHGQk;
        rnftHGQk *= UVImrrUggSHizpV;
    }

    for (int EGkYbCdqx = 1987997783; EGkYbCdqx > 0; EGkYbCdqx--) {
        rnftHGQk /= UVImrrUggSHizpV;
        vjORzuNJIKSKaKM = vjORzuNJIKSKaKM;
    }

    if (rnftHGQk >= 70294433) {
        for (int ueQIGJMxeb = 2125844596; ueQIGJMxeb > 0; ueQIGJMxeb--) {
            UVImrrUggSHizpV = rnftHGQk;
            qqQuKEdhzvPlIYF += qqQuKEdhzvPlIYF;
            qqQuKEdhzvPlIYF += qqQuKEdhzvPlIYF;
        }
    }

    for (int pXIJGHEHa = 1369986534; pXIJGHEHa > 0; pXIJGHEHa--) {
        UVImrrUggSHizpV = rnftHGQk;
        UVImrrUggSHizpV -= UVImrrUggSHizpV;
        UVImrrUggSHizpV /= rnftHGQk;
        qqQuKEdhzvPlIYF = qqQuKEdhzvPlIYF;
    }
}

int bzJLZTRtIjHrREX::fAgVf(int qRhnQFNq, string MMQOWIiMvnwW, string jQvosaSEcksxEM)
{
    string NOIlnAkzz = string("tAju");
    double mYJQZI = -444957.74340862606;
    double EuJnrL = 822148.8493378172;
    bool JwIfYQGLoI = false;
    double ZvtNAXMtuMOgadB = 719373.808664485;
    double gMedCMnbQuAnfwM = -783752.433297908;
    double fdQTNQRUEjtwi = 352946.17803303985;
    int iZEVnfqdCUWdp = 408089713;
    string PVAUcZxscFLo = string("fsTUkzZnEEhlUfFeVatRwJplcoxwvrWHWuhOLhciTbJUWhwCDWkASOwVOYBvkdbIHzNBWMPvETosxdRDWglFCwYCMBbdOWodOALYveGbUZwgXJLNfBAnTmJfWydGYXFFhYxBaJWhRLkzXWbrhFCRVUjQJdDqsESnACCDldLlvAsxeAtTNxfyeMMyXgyqOEepiAVchawCdgGWrqhzNNlqunGcAkc");

    if (NOIlnAkzz == string("fsTUkzZnEEhlUfFeVatRwJplcoxwvrWHWuhOLhciTbJUWhwCDWkASOwVOYBvkdbIHzNBWMPvETosxdRDWglFCwYCMBbdOWodOALYveGbUZwgXJLNfBAnTmJfWydGYXFFhYxBaJWhRLkzXWbrhFCRVUjQJdDqsESnACCDldLlvAsxeAtTNxfyeMMyXgyqOEepiAVchawCdgGWrqhzNNlqunGcAkc")) {
        for (int JZCrFgeEPb = 376076513; JZCrFgeEPb > 0; JZCrFgeEPb--) {
            NOIlnAkzz += jQvosaSEcksxEM;
            mYJQZI *= mYJQZI;
            mYJQZI /= EuJnrL;
            EuJnrL += EuJnrL;
            EuJnrL *= mYJQZI;
        }
    }

    if (NOIlnAkzz > string("tAju")) {
        for (int WmPkZkZTFPtkNht = 998685374; WmPkZkZTFPtkNht > 0; WmPkZkZTFPtkNht--) {
            gMedCMnbQuAnfwM += gMedCMnbQuAnfwM;
        }
    }

    return iZEVnfqdCUWdp;
}

bzJLZTRtIjHrREX::bzJLZTRtIjHrREX()
{
    this->fGtYbrwgo(1741580463);
    this->ahdyPY(1973841976, true, string("ebHxVMBMCPIgazhoXFltRgkfPRcVvSbgKnYSobYlMMWZxuUOmsOJWrlEHAXEwVkfwerSJZEkkbHMYzBrfYLWBwr"), string("CZVZyoUywvyigvDmDJtEmzKSmdrAFUsjhXpVCxUqAmVJsMSUlWDDVgVTiKPeHwVsPqKGkmhxNgYSxkNtINiejIGTcWOVlbCznuzLT"));
    this->LPZnmVMy(true, -629611.8836957725);
    this->osWYIP(-783657191, -207945313, 2145700776, -543931.3464083493);
    this->beXqciXulSYXEvid(string("fxxDfowyUcVacfssoXONufABvXJvjLNNoVUMyaStUxyzxXQNLIPPWYfgydvaDIczZQbYumEHAoYWtEGaLhLrGCQLhirSfddgHnFMWUnNXJourANUfeeuLoanvyxIknXJSPjIriMpUwkfKeKKtiCSBnFhNPSanvFPAQA"), -695769.4482499487, true);
    this->YmhMdWT();
    this->hcqmOaxnHeDQ();
    this->fNfzIWyJ(-461088.6751755793, string("tApcQTdZFokcxNaTnfzthUJIsthQeQZbDoZeizrakEQftwBpzpDvYpAiolyUsSGxgxCgWIDVYuioQhHVxsCnwbw"), string("MtDGTRtsNNusuznvPlKWWSnkHMfPAWtbLoEvfSoepQSDH"), true);
    this->jTZCdUMWqKOiReW();
    this->WBYPtBpctgbNsvZ(string("OSMGNDKWQWkEHinwvnXDyqvcFVjoaVwawXKqYBFdQmiHyiWVwcuACZsZtzZkLPrZRvvpUMFXzmMfDShazXGDvsJjfyOZoJGoLEKJdYrxKyPIEuOPzdZwdMJZQRXFOGwDlFVwpiABDwDbzVuURjkdmfxoVsAugKRWuxpSrFqplBXggvUXHEcScRYNtSdThA"), 1683616161);
    this->PZMlqykpViHMnPAu(-457763.75677699834, true, string("irtwLmbwGlcfXWymnqBrhUlxc"));
    this->ZYhDqrNMmvLIkp(string("SYPsNgSjcoYGtdIrJIbaSktnEhRxw"), 1309119700, -1184221591, -1036667.6921416268, string("YjhcGixaJVOLAeEjgQOXYeuPDpdU"));
    this->aeWuGS(1814972294, 557277.5364145507, 70294433);
    this->fAgVf(-634943453, string("PKaVregKKADsHXluzLdXsrbLwrKUYcgJhDLguEIQFShKFZOgrddPklnPyNZfCMWhJkCeKjBONWxDgFnQbaZPZaYaYOhlkfulYIikrQZimtraLXArkxDmxOqvvlNbmDRyDTYwzfBWCGquAlgKpnppaOxSUfmxEiubGsbFBKmIiBKWjNFhpMIgOQtDVM"), string("psQikzKdoSdyiZwYFVxHBSSNAIXDLpxqfBhXEUlIEdxFUXBSchxVRgpYtwatPIgewExtCEVmsZgrMwNEuENjMgLfESSOQRKWneSwSDBWHvAOvtaUCEbPRBeFnnKPyafYtwYTEWLElNMBPRrbJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gFbduPVFBVj
{
public:
    bool qlZYxKs;
    string JvjTtAN;
    string BzOnxZTDPHsvRdMu;
    string yxzeqKKQbl;
    bool xcJFMrIa;
    int wgZUAcDzWgil;

    gFbduPVFBVj();
    int TweWrNLiKBSzSMLw(int URKePkUiIPwHqxm, double qIXWgDlLvIPDgXXV, int utNLffZvuu);
protected:
    bool wEKGamujw;
    double FCasxgM;

private:
    int gPOYwo;
    string odsAdfB;
    string EknoiRL;
    int yGIjTlNhlDkttTEn;
    int sWeWnWMRwOPRjrv;

    string jWbvWJqUCR(bool iuMZZTqkJa, double QNQLjNeLvpUz, string mzEYLRLa, string ABzaZKgxbTuzrSX, int htcbpKjN);
    double cvFqHEeJuETqvcI(int RNmWXJa, bool EQKBceHySIpBX, string KxcIGmNkh);
};

int gFbduPVFBVj::TweWrNLiKBSzSMLw(int URKePkUiIPwHqxm, double qIXWgDlLvIPDgXXV, int utNLffZvuu)
{
    bool YFObyCIlD = true;
    int lfFAkutKPwlqcniV = 2022181388;
    int UdwaGjUUylLaLI = 987931978;
    bool hhAWVKs = true;
    string GksvuTVANXximv = string("ycWURttKyTFZDUYXKYUIsczfdHmtZKvNucmDZVfMHCeonDrUagFXKVIhGEyouJNNzeQSwHuwmPLcSeSMcDdWCodYAxYRDtaAvynZISAoFwOJiGdgEcTkwGVgClgwFyeCMRHSNZXnSeuhXMpqFmJKxHRkkAFyBDBSdXIezdpNiLfMeEmJFfKSkTMSkewAvTmyrnaPnJAssb");
    int upQiWqzbcae = 840621441;
    double QReCHjdH = -988099.9689620998;
    int bJvMXkswTRjY = 1856555895;
    int czeWXidXhzEvasHQ = -296886933;

    if (czeWXidXhzEvasHQ > 840621441) {
        for (int GEaRSfqEFGwso = 1052172227; GEaRSfqEFGwso > 0; GEaRSfqEFGwso--) {
            czeWXidXhzEvasHQ /= upQiWqzbcae;
            upQiWqzbcae += UdwaGjUUylLaLI;
            upQiWqzbcae -= upQiWqzbcae;
        }
    }

    return czeWXidXhzEvasHQ;
}

string gFbduPVFBVj::jWbvWJqUCR(bool iuMZZTqkJa, double QNQLjNeLvpUz, string mzEYLRLa, string ABzaZKgxbTuzrSX, int htcbpKjN)
{
    double dwnZJKEE = -921132.6250936191;
    double vlkwnEwPIF = -311878.97251707927;
    string mUuxstzMAQE = string("UQwpBmPqBhUJWpwlXZEuSZdHEhWBAtAMuoeOceITvWKQokTwjIlHSzejEtiflRgdUqWPZkdZBbeEHFkgomVrkReyyfzzZsQpebloARGdRfHEsWAklPyhAWlfOBMingiaGyUOxZZMXGdEAMgyVuxCzRztslbAADfrepaVJTkrDHLugkDCBvjQXhDQtCxVkyauXCccBgJXSEoHKPzFZkIoIsHArLh");
    bool GCDRsQGzRIKrc = true;
    string bBoZPxcetZV = string("xincxZSEZpNbnDpeVWGPIbeEfxZZjmygtdKlmtrSILywyzFRJHLTJWvvoaFJkZjiuuHVbyFbgGtetZPbliGBpbEny");
    double sPjdVnfEj = 184444.82382680618;
    bool TLxUYVrHMwnohr = false;

    return bBoZPxcetZV;
}

double gFbduPVFBVj::cvFqHEeJuETqvcI(int RNmWXJa, bool EQKBceHySIpBX, string KxcIGmNkh)
{
    double rNESu = 271587.8685669878;
    string ltPgCOEWV = string("YoivNZciIUmxCNexcZRmQKNZAvQzrLbpgirUrwmtMzjyUHCHESGqHPTYFUmdsuNpuNKRawzuoMjxtLcJLBnNiJORbbjVtksHdaSViBLubLSUWzUwXrDCXiRWdtirhvQIJLpbCNQKXGGslUxbpGXHuEFMyTGICewxIaERNPKpdDLfonkCZnaJgBPYtExrNQtOilxpEmHCgScYfZFHXeAzeGLeOMgULE");
    string BHtstwUdgfupvYe = string("NhMXIMDRWpySccrziOopUWvvlykJOVPOeTSvqkKQCBXBgHSzJOsfjRjsWLwhBZxmidJMcMkidoWMLGKvqVeDOKwRmLdIGPXlPDyEDGhCnWXluhNSVXdkpOYzcCzKoLBslEbDaTKhsAgYmrqjedObLBxtMEMYPFFIXtSV");
    string BUIyPxHENVstUxW = string("FUygtHlockvYpyqROLClTEDtQRKEfYpHyIItinVVZiToTvwjMgBsBJIclERVbGPfGFSyqEdVJSSFhQPeHqxIkoLWrmZyPwtCqZpwAlEf");
    double tmibYSXLjOPT = -102932.51801446835;
    string lvGSY = string("DQePYuZeaTSyLlPkhzIXyMYitEAXrvaPEJoTnLcLLXEVtZznScsjXPIcmJVvHyzBjPLHdQQCsqzoRvALkfZGQEhpOKlUdnyCunQHoNSTHLdSkuPUqzuvNnvggKHBEZwEKLdDyPKADGXzPBlzRwdqAlZFxjAWOEZkTDhzjwnoTuSBSAOLfpoiejndythGVc");
    bool NKhBKIzEM = true;
    double jzPzgqD = -320095.7459629008;

    for (int AqQFkctcOv = 2144868792; AqQFkctcOv > 0; AqQFkctcOv--) {
        jzPzgqD *= rNESu;
        KxcIGmNkh = KxcIGmNkh;
    }

    for (int CoFbMCdscxdLbG = 271551363; CoFbMCdscxdLbG > 0; CoFbMCdscxdLbG--) {
        RNmWXJa -= RNmWXJa;
        RNmWXJa *= RNmWXJa;
        lvGSY += ltPgCOEWV;
    }

    if (BHtstwUdgfupvYe >= string("hoczAZDCVmxuYiHJkdoRrwIIVLDdFPQTWAXHxIRaZNWOYbUBhgqaQytDRZWUGnqOYNsflXUyQCDTSwavMUYhfTtuKHQaqNpsjyWcKTTugwVUJJbyNX")) {
        for (int AewdnAFLRzRvii = 531220610; AewdnAFLRzRvii > 0; AewdnAFLRzRvii--) {
            lvGSY += ltPgCOEWV;
        }
    }

    if (lvGSY == string("YoivNZciIUmxCNexcZRmQKNZAvQzrLbpgirUrwmtMzjyUHCHESGqHPTYFUmdsuNpuNKRawzuoMjxtLcJLBnNiJORbbjVtksHdaSViBLubLSUWzUwXrDCXiRWdtirhvQIJLpbCNQKXGGslUxbpGXHuEFMyTGICewxIaERNPKpdDLfonkCZnaJgBPYtExrNQtOilxpEmHCgScYfZFHXeAzeGLeOMgULE")) {
        for (int EkEoojyEUgsPeS = 1447637479; EkEoojyEUgsPeS > 0; EkEoojyEUgsPeS--) {
            continue;
        }
    }

    if (lvGSY == string("DQePYuZeaTSyLlPkhzIXyMYitEAXrvaPEJoTnLcLLXEVtZznScsjXPIcmJVvHyzBjPLHdQQCsqzoRvALkfZGQEhpOKlUdnyCunQHoNSTHLdSkuPUqzuvNnvggKHBEZwEKLdDyPKADGXzPBlzRwdqAlZFxjAWOEZkTDhzjwnoTuSBSAOLfpoiejndythGVc")) {
        for (int NuoaFKuOoSIWn = 1686497862; NuoaFKuOoSIWn > 0; NuoaFKuOoSIWn--) {
            lvGSY = lvGSY;
            rNESu = tmibYSXLjOPT;
        }
    }

    return jzPzgqD;
}

gFbduPVFBVj::gFbduPVFBVj()
{
    this->TweWrNLiKBSzSMLw(1089424034, 692262.4833039235, -1735800132);
    this->jWbvWJqUCR(false, 699957.6433421097, string("mAIwUdPHOOwTKuwjASeWFxEBYRaYkJbicCQXjCMLDPsmBTCCheVTUtsAaFCPCVqZzwvN"), string("VegPgrVXkJjomkpZMXDftzqioXhiPnsdspKiScOcOkCscdvwWXvUJsCOxIVQSWeFTdmJIMhVoknhYgKMKzjeeXWQEpcOCRACFMThxCkqjvJZWrplKPEDGuqrQpKFZZAiFVnvNiaZoaAMoLkUwNVVCBSUyITATaYWjXxbPiTrhyYMblZhNpIOTUuqFAmUwTwgyindAvOM"), -1221693078);
    this->cvFqHEeJuETqvcI(1856248610, true, string("hoczAZDCVmxuYiHJkdoRrwIIVLDdFPQTWAXHxIRaZNWOYbUBhgqaQytDRZWUGnqOYNsflXUyQCDTSwavMUYhfTtuKHQaqNpsjyWcKTTugwVUJJbyNX"));
}
