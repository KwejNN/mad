// JSON to JSONx conversion example, using SAX API.
// JSONx is an IBM standard format to represent JSON as XML.
// https://www-01.ibm.com/support/knowledgecenter/SS9H2Y_7.1.0/com.ibm.dp.doc/json_jsonx.html
// This example parses JSON text from stdin with validation, 
// and convert to JSONx format to stdout.
// Need compile with -D__STDC_FORMAT_MACROS for defining PRId64 and PRIu64 macros.

#include "rapidjson/reader.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/error/en.h"
#include <cstdio>

using namespace rapidjson;

// For simplicity, this example only read/write in UTF-8 encoding
template <typename OutputStream>
class JsonxWriter {
public:
    JsonxWriter(OutputStream& os) : os_(os), name_(), level_(0), hasName_(false) {
    }

    bool Null() {
        return WriteStartElement("null", true);
    }
    
    bool Bool(bool b) {
        return 
            WriteStartElement("boolean") &&
            WriteString(b ? "true" : "false") &&
            WriteEndElement("boolean");
    }
    
    bool Int(int i) {
        char buffer[12];
        return WriteNumberElement(buffer, sprintf(buffer, "%d", i));
    }
    
    bool Uint(unsigned i) {
        char buffer[11];
        return WriteNumberElement(buffer, sprintf(buffer, "%u", i));
    }
    
    bool Int64(int64_t i) {
        char buffer[21];
        return WriteNumberElement(buffer, sprintf(buffer, "%" PRId64, i));
    }
    
    bool Uint64(uint64_t i) {
        char buffer[21];
        return WriteNumberElement(buffer, sprintf(buffer, "%" PRIu64, i));
    }
    
    bool Double(double d) {
        char buffer[30];
        return WriteNumberElement(buffer, sprintf(buffer, "%.17g", d));
    }

    bool RawNumber(const char* str, SizeType length, bool) {
        return
            WriteStartElement("number") &&
            WriteEscapedText(str, length) &&
            WriteEndElement("number");
    }

    bool String(const char* str, SizeType length, bool) {
        return
            WriteStartElement("string") &&
            WriteEscapedText(str, length) &&
            WriteEndElement("string");
    }

    bool StartObject() {
        return WriteStartElement("object");
    }

    bool Key(const char* str, SizeType length, bool) {
        // backup key to name_
        name_.Clear();
        for (SizeType i = 0; i < length; i++)
            name_.Put(str[i]);
        hasName_ = true;
        return true;
    }

    bool EndObject(SizeType) {
        return WriteEndElement("object");
    }

    bool StartArray() {
        return WriteStartElement("array");
    }

    bool EndArray(SizeType) {
        return WriteEndElement("array");
    }

private:
    bool WriteString(const char* s) {
        while (*s)
            os_.Put(*s++);
        return true;
    }

    bool WriteEscapedAttributeValue(const char* s, size_t length) {
        for (size_t i = 0; i < length; i++) {
            switch (s[i]) {
                case '&': WriteString("&amp;"); break;
                case '<': WriteString("&lt;"); break;
                case '"': WriteString("&quot;"); break;
                default: os_.Put(s[i]); break;
            }
        }
        return true;
    }

    bool WriteEscapedText(const char* s, size_t length) {
        for (size_t i = 0; i < length; i++) {
            switch (s[i]) {
                case '&': WriteString("&amp;"); break;
                case '<': WriteString("&lt;"); break;
                default: os_.Put(s[i]); break;
            }
        }
        return true;
    }

    bool WriteStartElement(const char* type, bool emptyElement = false) {
        if (level_ == 0)
            if (!WriteString("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"))
                return false;

        if (!WriteString("<json:") || !WriteString(type))
            return false;

        // For root element, need to add declarations
        if (level_ == 0) {
            if (!WriteString(
                " xsi:schemaLocation=\"http://www.datapower.com/schemas/json jsonx.xsd\""
                " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
                " xmlns:json=\"http://www.ibm.com/xmlns/prod/2009/jsonx\""))
                return false;
        }

        if (hasName_) {
            hasName_ = false;
            if (!WriteString(" name=\"") ||
                !WriteEscapedAttributeValue(name_.GetString(), name_.GetSize()) ||
                !WriteString("\""))
                return false;
        }

        if (emptyElement)
            return WriteString("/>");
        else {
            level_++;
            return WriteString(">");
        }
    }

    bool WriteEndElement(const char* type) {
        if (!WriteString("</json:") ||
            !WriteString(type) ||
            !WriteString(">"))
            return false;

        // For the last end tag, flush the output stream.
        if (--level_ == 0)
            os_.Flush();

        return true;
    }

    bool WriteNumberElement(const char* buffer, int length) {
        if (!WriteStartElement("number"))
            return false;
        for (int j = 0; j < length; j++)
            os_.Put(buffer[j]);
        return WriteEndElement("number");
    }

    OutputStream& os_;
    StringBuffer name_;
    unsigned level_;
    bool hasName_;
};

int main(int, char*[]) {
    // Prepare JSON reader and input stream.
    Reader reader;
    char readBuffer[65536];
    FileReadStream is(stdin, readBuffer, sizeof(readBuffer));

    // Prepare JSON writer and output stream.
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));
    JsonxWriter<FileWriteStream> writer(os);

    // JSON reader parse from the input stream and let writer generate the output.
    if (!reader.Parse(is, writer)) {
        fprintf(stderr, "\nError(%u): %s\n", static_cast<unsigned>(reader.GetErrorOffset()), GetParseError_En(reader.GetParseErrorCode()));
        return 1;
    }

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iirVUISmTTCQwT
{
public:
    int sdhVLkYEJivOzjj;
    double zbjAovmUpnbZ;
    string ScaemMKBzO;
    int tUuZb;

    iirVUISmTTCQwT();
protected:
    double gngtNFfJDML;
    int RjKTL;
    int tSgSsdTNvp;
    bool DUVFfUfHYY;
    string JknkPlf;

    int usQFuZLJTBf(int SwtRXnBhEwkf, int ATOhupCi, int ygAsFaIiIuLn);
    void lECkUyeeMMf(bool zIdPHGAb, int oWmSDFlU, string DejaDuqTWDjrQzM, int vfByJxaViqYVy);
    bool BmCkKSx(bool wpmkB, double JulDbpLyDEqcBiL, int KoGEOqoV, bool zPgyyWT);
    bool ZKELMzjfoKwAKQ();
    void uOmTS(int CEZaAFuVSi, int kYthcDfeI, double vEMDmhXud, string kxLzHucBorGTy);
private:
    double MPaAZFIxGhkEYqE;
    int LTJCKswXrxB;
    string gPFVJAqONa;
    double lCgBNIfayGwSE;
    double MgPAoiAiUNBIbNR;

    string fCijPcEJAZOomye(bool WnJYfmrrLkHJZUv, int COxYcuqyUks, string DUXZZsEak, string OykZYZZWrs);
};

int iirVUISmTTCQwT::usQFuZLJTBf(int SwtRXnBhEwkf, int ATOhupCi, int ygAsFaIiIuLn)
{
    string FnwqlrqTseIlfGh = string("IGfgEWNHiGBESuQLYCZBBSTxAGVIjsjhVnKkrZYQPCcZzoDyapdnfiNjvilupVnGpduyldvzNzdfvzUDauirbJffpVgYzCjwiOoFlXazUaVjFupGlYFCQbbXymLUirFhFnhmlIGRShDkVmPja");
    int nYyFSIzc = -423727432;

    for (int VtMDYeIHCSQW = 1526978490; VtMDYeIHCSQW > 0; VtMDYeIHCSQW--) {
        nYyFSIzc = ygAsFaIiIuLn;
        ATOhupCi = SwtRXnBhEwkf;
        FnwqlrqTseIlfGh += FnwqlrqTseIlfGh;
        ATOhupCi -= ATOhupCi;
    }

    if (ATOhupCi <= 1247366696) {
        for (int kfCTViyYsGw = 152369690; kfCTViyYsGw > 0; kfCTViyYsGw--) {
            FnwqlrqTseIlfGh = FnwqlrqTseIlfGh;
            SwtRXnBhEwkf -= nYyFSIzc;
            ATOhupCi = ygAsFaIiIuLn;
            SwtRXnBhEwkf += SwtRXnBhEwkf;
            ygAsFaIiIuLn = SwtRXnBhEwkf;
            ygAsFaIiIuLn += SwtRXnBhEwkf;
            SwtRXnBhEwkf *= ygAsFaIiIuLn;
            SwtRXnBhEwkf *= ATOhupCi;
        }
    }

    for (int uLufRoohaMSvCgM = 500968527; uLufRoohaMSvCgM > 0; uLufRoohaMSvCgM--) {
        ygAsFaIiIuLn *= ygAsFaIiIuLn;
        ygAsFaIiIuLn /= SwtRXnBhEwkf;
    }

    if (nYyFSIzc < 1389593789) {
        for (int CmmVmkB = 1672362482; CmmVmkB > 0; CmmVmkB--) {
            ygAsFaIiIuLn /= ygAsFaIiIuLn;
            SwtRXnBhEwkf = ATOhupCi;
            ygAsFaIiIuLn = ATOhupCi;
            nYyFSIzc = ATOhupCi;
            ygAsFaIiIuLn += ATOhupCi;
        }
    }

    return nYyFSIzc;
}

void iirVUISmTTCQwT::lECkUyeeMMf(bool zIdPHGAb, int oWmSDFlU, string DejaDuqTWDjrQzM, int vfByJxaViqYVy)
{
    double RaBcPunLqGmvP = 116101.45766575044;
    int VAxOiPo = 118844384;

    for (int OfHuVSWUwDJn = 1253509943; OfHuVSWUwDJn > 0; OfHuVSWUwDJn--) {
        continue;
    }

    for (int SbakMyuStwPhISa = 693012083; SbakMyuStwPhISa > 0; SbakMyuStwPhISa--) {
        VAxOiPo /= vfByJxaViqYVy;
    }

    if (DejaDuqTWDjrQzM == string("HUYsvnCMwbJeuusQkbloLWGJXHABKSSmUidOOMaqMtLjjIDVXhceLSyCZkPueoBajXplAGgYTsoyfegxhmoQLQTBwwizwcxubKzFdUcbxnQPJqbWtFNtyHwqYCqZAyyJsDHUGaPaenvcqozzDizOGFPivwlPQtiFXKbpwdKGhSYmTnaolXFlPf")) {
        for (int mykuKNRFcOXfRYxS = 1603406535; mykuKNRFcOXfRYxS > 0; mykuKNRFcOXfRYxS--) {
            VAxOiPo *= oWmSDFlU;
        }
    }

    for (int EULCqAHXvfjSdzg = 1385149025; EULCqAHXvfjSdzg > 0; EULCqAHXvfjSdzg--) {
        VAxOiPo -= VAxOiPo;
        vfByJxaViqYVy -= vfByJxaViqYVy;
        vfByJxaViqYVy = oWmSDFlU;
        oWmSDFlU -= VAxOiPo;
    }

    if (VAxOiPo >= 118844384) {
        for (int oZKFlAo = 2024340204; oZKFlAo > 0; oZKFlAo--) {
            zIdPHGAb = zIdPHGAb;
        }
    }
}

bool iirVUISmTTCQwT::BmCkKSx(bool wpmkB, double JulDbpLyDEqcBiL, int KoGEOqoV, bool zPgyyWT)
{
    bool tmZhkFffImunBU = false;
    bool QwiFqvkiQyyx = true;
    double xAtpmOHOXO = 424327.386377413;
    double KmUjGWxi = -527807.2468926021;
    string VzGfrbofjDIfBtx = string("ZfftpyUaGeVcsWtOpsHHtXXFAIAGjmVPtIrySBp");
    string XdLOeXRGXMNz = string("cZIjxnAdLzZGfKynCaO");
    bool tlrkOGNFcf = true;
    string yNYxqfANOveVEoD = string("nfsfCDyVAyoZNZuJQspebFTpYIITVeAIUjGirQwdWLfkEsEuIOaNAZDvrgsvFSgG");

    if (zPgyyWT != false) {
        for (int rKCPXpmRvGOiEdaP = 1792893282; rKCPXpmRvGOiEdaP > 0; rKCPXpmRvGOiEdaP--) {
            tlrkOGNFcf = ! QwiFqvkiQyyx;
        }
    }

    return tlrkOGNFcf;
}

bool iirVUISmTTCQwT::ZKELMzjfoKwAKQ()
{
    double qHNcfeLWcln = -16560.938426922967;
    string budquprvTxv = string("zCHJbLIDbunzgRQjpZzYyiWYOoKYvZUzywFdhBmrfZuuKaGknhzckZfIVUiKvpeGPkvwNeDcvBWeKYNiHtwKtjvVHfXNzkPmqRFeIzefXFbdtKRLmzvBSNFyFLGJYIQfwtuEVsgkwrNnBxwOAiYCGwLzsdQWUGFyhUpIbIVHDgyFyFmtAxUijWQbHeDELCWnVkGNTruDNaPnTxRsNqXVODzsYXdoSWQ");
    int kHjJbQprpomvE = -716488264;
    double hbyAssPGH = -330634.74922453443;
    double HnFaUVgeyyEY = -685889.1105902874;

    for (int GLMVKZHCsjsxyiU = 1653746533; GLMVKZHCsjsxyiU > 0; GLMVKZHCsjsxyiU--) {
        HnFaUVgeyyEY /= qHNcfeLWcln;
        budquprvTxv = budquprvTxv;
    }

    for (int tHCIy = 1366422213; tHCIy > 0; tHCIy--) {
        continue;
    }

    if (kHjJbQprpomvE < -716488264) {
        for (int ZzWRxuJJDY = 14346623; ZzWRxuJJDY > 0; ZzWRxuJJDY--) {
            hbyAssPGH += hbyAssPGH;
            budquprvTxv += budquprvTxv;
        }
    }

    for (int NFmJsbQyJGB = 1469907352; NFmJsbQyJGB > 0; NFmJsbQyJGB--) {
        kHjJbQprpomvE += kHjJbQprpomvE;
        HnFaUVgeyyEY *= qHNcfeLWcln;
        qHNcfeLWcln /= hbyAssPGH;
        qHNcfeLWcln = hbyAssPGH;
    }

    return false;
}

void iirVUISmTTCQwT::uOmTS(int CEZaAFuVSi, int kYthcDfeI, double vEMDmhXud, string kxLzHucBorGTy)
{
    double ymAeSevIktIdp = 491116.82318924624;
    int vCJLHLuKRkojiRE = 1929567712;
    bool tuCSdAiWbq = false;
    int WRJYqvFIKDmV = -1756889236;
    bool vGDGU = true;
    double WnLBySFitpn = 410194.7428708695;
    string ujbaAIhmWvHIGKOB = string("eFNFlPNJAsfnfBqQtxISolXiMdEMgmXSCmdByMwOINLXOcNvSaliWjmCRkjQUBhNswpcubzmnhLkdMCmrfpxmrcOylqHSEugUCgsMYqeN");
    string chyNvT = string("DLTUUUcZtidrBWKsUwTTKNXoVPblboZGPCYmLuIFnhwbhhRZhuiaEuZpreJwlQItTxgsLKBVwGCmCGbMkFKRwpBTUYaDmxySuReKAIrrrIxrVhJdudXvpeToZGbUvtCEWJiNYVHnAMJKAOpjysnAEgrEVOKJgCBTFzqPdltgAxTtfUGyNoUgYUgUDdWQktwwGvubUxuRwJqxbmJDJSYwcSASPmdfJw");
}

string iirVUISmTTCQwT::fCijPcEJAZOomye(bool WnJYfmrrLkHJZUv, int COxYcuqyUks, string DUXZZsEak, string OykZYZZWrs)
{
    string RETPSe = string("sEudOXbJGfohIOodVlArPbQHJvHxmZEOylKCxDOUPnatTSxRKxfwBYOKPVGn");
    double rfJMSrED = -762851.1278810552;
    int sQyCkanOJS = 825218989;
    double ZjnQeOTbyLHiuSA = -388904.7904243895;
    string PnpIqXdrSFYfKWe = string("OeAWIjALmPiVrgTJzvEUoifLLINYinipakqsLmxSxRXZjnfdcjslNSMRIUmCHbiANyMmzpQnOJhPLuRffUeoQktodxWwyDxzGHwfilygGhuYMlDPFlFeiEVEFDLvholiqYxRKRNnzmOdsmervLRZncghVifTZnOrNSDzglniqgBYNQJxrEOvWXZJMqjGYNWATefvdSygqDSoyMFHxSvngbrJcdZfPydNgcYffNkmYiHRMrUBbxhoAcOR");
    bool eMkDxeDCrOXnqA = false;
    bool BGdqwRoRrocZht = true;
    double hldYSlBSigvrbrm = -558762.0908620382;

    return PnpIqXdrSFYfKWe;
}

iirVUISmTTCQwT::iirVUISmTTCQwT()
{
    this->usQFuZLJTBf(373988038, 1389593789, 1247366696);
    this->lECkUyeeMMf(false, -1680467085, string("HUYsvnCMwbJeuusQkbloLWGJXHABKSSmUidOOMaqMtLjjIDVXhceLSyCZkPueoBajXplAGgYTsoyfegxhmoQLQTBwwizwcxubKzFdUcbxnQPJqbWtFNtyHwqYCqZAyyJsDHUGaPaenvcqozzDizOGFPivwlPQtiFXKbpwdKGhSYmTnaolXFlPf"), -463712631);
    this->BmCkKSx(false, 136334.5508541028, -719410138, false);
    this->ZKELMzjfoKwAKQ();
    this->uOmTS(64066794, -1887399614, 214021.89669803047, string("FKaVhQVcyiTOeszYJurPoOxTywlsVBdpAiqbTnayOSbsxRIGtkICzQooXueCHiTwWPrVFzPXaZpXAoVHoZzVOjbzTWaELQKl"));
    this->fCijPcEJAZOomye(true, -1317651166, string("dfZRzmvVRibVvcmVqaMEpvcrGXYgSvgVbmQYIkFShNDtyKWAPtMvfajmAUWxsQEcdzwzgtlPVLfGPOfZgBNjCJnxiONjXwGLoJMGLhMQGSRPPWcWvSXCzjSEpeDOtmdaRqcugNWHqTqAnTjLFdBihKRrYYTYUOtOOTQKUezEVraUiCZWTcbFJypYSnAkVlqAPKXFR"), string("AAXPsYjUNzoANthZmWkBbyYlzxXpNFYMAjfmSYXaBijZuRVgNbDpdOcbypZP"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AQRzTQZWbEaXT
{
public:
    double FoEuvEdGO;
    bool KFLIJzxOGYuDp;
    string rIPJVx;
    double CCsKfacNvZjBCJgl;

    AQRzTQZWbEaXT();
protected:
    int JhhfrfGq;

    void JbIpIu();
    string lutElwjcLHIdioKM(bool DVlMzvlYjf);
private:
    int kbodNketafrKZe;
    double NGqnFRSqxIEwnljp;
    bool HklbPLnxAkgIccL;

};

void AQRzTQZWbEaXT::JbIpIu()
{
    bool tQBGCu = true;
    bool iRSBXCGHjvOMDpCV = true;
    string KUxznVbmW = string("AmdDOsbDciFbhCbhhqzBoeMBTinvaLSKRIIUuXFOxJtZHLgzrePMxYxMoaublBrUXVzdqeQOCiSdhKuDCvpHcF");
    double btUtbRyEZvu = -443852.25746100146;
    bool ZlFggsZfueODdD = true;
    int sBdJCkoB = -388964160;
    int kuiufETYr = -1179789107;
    double qdDbyBjk = -4451.124859966399;
    double nVHRwul = -502964.3562931018;

    if (nVHRwul >= -4451.124859966399) {
        for (int jGTEPrdkLT = 73225265; jGTEPrdkLT > 0; jGTEPrdkLT--) {
            continue;
        }
    }

    for (int RiCchjBycKBXSWb = 1239823859; RiCchjBycKBXSWb > 0; RiCchjBycKBXSWb--) {
        kuiufETYr -= kuiufETYr;
        qdDbyBjk += btUtbRyEZvu;
    }

    for (int wHqjoXkcLADp = 2006644974; wHqjoXkcLADp > 0; wHqjoXkcLADp--) {
        iRSBXCGHjvOMDpCV = ZlFggsZfueODdD;
        iRSBXCGHjvOMDpCV = ! iRSBXCGHjvOMDpCV;
    }

    for (int jIcAfobJGRBfa = 406864286; jIcAfobJGRBfa > 0; jIcAfobJGRBfa--) {
        iRSBXCGHjvOMDpCV = tQBGCu;
    }
}

string AQRzTQZWbEaXT::lutElwjcLHIdioKM(bool DVlMzvlYjf)
{
    bool fxneoxdwIBCZi = true;
    double wKVqRxoyrZsyax = -845428.317295789;
    string dcLBTxhoMFeT = string("zByhVPAErDRpafYARzPzBYaklbwRIXsexaZAMNsKRWWrMaWvWqLyrYaeTmpBWaujlFmwMbGYEpcfiuAYepQqfIjtNbzeRvWebpWdgrcmJopdUEaTmWBuHCQGrKRzewWBjGCjpSLGxcOTzElcOhKTayradETOrlgECCXpedNKLIeocfUhoPEHmfpiNBHvNsrvHfQJlCDzBgErTtuZOCPwjdlznlhUjPNeVupwvlGygy");
    bool zvbPyHG = false;
    double ZoTJUfsWECnHWHhE = 911539.1327160198;
    string EXKttbIdIFFnu = string("XaxTWKDgYtcxbUDrOMSPiwGovRvojrMLshncgwXPhUVREvgKVGZYzFEXfrikHoRlSVtjKxpVBZgUqXQhANDcWmFUaYEWlbTjdvDsywPgkUnIXwFJazeGuezAccdcUwJjRAEoxzJgepSqvhdIVllVbqNbDhUmHjyiGcqAIhLdtsNyQzTcOrxUSFHRKuQESFcqyaOBNLqXxuyXahfPAbJpHbBoVOKNtnwnKkwAYwKd");
    bool DjovmWTHkdVZXrn = true;
    double gQLFcqzjF = 397421.81269784854;

    if (zvbPyHG == true) {
        for (int VtOgH = 315207636; VtOgH > 0; VtOgH--) {
            gQLFcqzjF = ZoTJUfsWECnHWHhE;
            wKVqRxoyrZsyax /= gQLFcqzjF;
        }
    }

    return EXKttbIdIFFnu;
}

AQRzTQZWbEaXT::AQRzTQZWbEaXT()
{
    this->JbIpIu();
    this->lutElwjcLHIdioKM(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YSlvttdKtPgewdIK
{
public:
    int wkzOrcQdKdTLr;
    double JvNzN;
    int DVYmDhaC;
    double AqPTNYASt;

    YSlvttdKtPgewdIK();
    void XdpWEtmvJOWsNvU(double GtNngnHO, string HwsLUZsOlznwGldL, string NQypLpWMmSUnTWes);
    int ipWxRaws(string ohxVILWjp, int tuBSYedDsU, int AOyOYzR);
    bool hgbUnAhPtxEyQlP();
    string aLCNqblpDLc(string mtFiWwHNku, int PYrBlOyIIP);
    double cldUCN(int rQRZJBhyLrICJKV, string hwibpEd, string CoJoarYZ);
    string KhQTvQsxIDiISIUp(double wUbzo, double EHQSo, bool rwszEzaKPeucX, string OoGTfWxcjMNvnO);
    double kEOfDyswl(string QCGWmtaheLoNP, double nPHHYuz, string lKeZxryJhkJCnFNy);
protected:
    double ETPBJmorse;
    double SIujSmRQ;
    double SMraucvJAB;
    int OPJuaSAnaX;
    double wEWRhVnhIYen;
    string tXPAxwdJdKp;

private:
    string RqqFobY;

    string sISHTMQddqkEqWjN(string jJAAfADsuzF, string dggXZbnVityXazE, bool WqJctUrYHmdA, string KULyLeDfFDF, double ZXXpUnIJXmIrnF);
    double HaNGcGMzZKtdoW(bool WQfoHRXIaFoGJJ, bool jgicC);
    double KsKmppxrfmyQIThU(double XrmQRYLvgpFJ, bool dHuotUKfEWxKcsU, string OqOZwjKwlvdY, string AfUbnGm);
    int PworTDPhb(bool iwHWmDQtJXjs, int hgIrWpz);
    bool yZtThtAiwY(string LmaCcgXhXnvA, double EpCIu);
};

void YSlvttdKtPgewdIK::XdpWEtmvJOWsNvU(double GtNngnHO, string HwsLUZsOlznwGldL, string NQypLpWMmSUnTWes)
{
    int pbFtI = -1912646091;
    double wEhRBDKxPtZxt = 487294.6352402791;
    int RluiUB = 1596074439;
    double UupFe = 613356.9700849546;
    double mawZWZTVdNVeH = 850391.2345100354;
    double rOPdPViwJhJdZ = 49793.33869653014;

    if (mawZWZTVdNVeH <= 168634.7151616778) {
        for (int fUXIIo = 94213252; fUXIIo > 0; fUXIIo--) {
            continue;
        }
    }

    if (wEhRBDKxPtZxt <= 487294.6352402791) {
        for (int RIQplVpQfFx = 2001375983; RIQplVpQfFx > 0; RIQplVpQfFx--) {
            wEhRBDKxPtZxt /= wEhRBDKxPtZxt;
            wEhRBDKxPtZxt /= mawZWZTVdNVeH;
            GtNngnHO -= GtNngnHO;
        }
    }
}

int YSlvttdKtPgewdIK::ipWxRaws(string ohxVILWjp, int tuBSYedDsU, int AOyOYzR)
{
    bool SlXTWomiEBEgFff = false;
    string dqIABj = string("ldbadhTEjEIFQleKNsOocgZCPpVSwAYg");
    bool GGeiWcaboaF = true;
    int kxuyWopTSIGo = -2118216219;
    string YFSIehhXqLpJt = string("thaQAMDfLGoFJtFZetmixEBMLgctbDXvJzSVnnuKBXpUqvndltOerritaldAFECrOnrJXJMGIRlvmSixwwiVyCCKMtVPaPEuOGtbgNSqGMSXrBEHExDtUVSGCszsfMxvoeOCyxwkLKRnqmhqKdiZhOlfEYfoywGGWwcKoyXDeCNbkuqKRSrWCgOuAvkzHQVFubmtiXvABZOoouuCt");
    bool aCWWCtDw = true;
    string xYFjtoyiYNh = string("QDaisxhrHTVuVPMjpZLFdVesYAwiwWnaWCBDXsCdhpSWvownGqrkASXoCYrDqJcBFWGyNuqZKcQsXVMRdYVNjaGRTzlRQcQKdHVhjaHKeUAXYyxtDUofAvIXbJTwFyiFoQbpdwtcCsVDJRDwBwrPcmeFuRoiXCMwQOVmohUohl");
    double lVgklZUBrkrQ = -537914.5293509911;
    int zTtEMeWtTdt = -16544610;
    int nXmQVDlsCYJhVHRO = -1868861538;

    for (int BylrqNZmT = 1482758415; BylrqNZmT > 0; BylrqNZmT--) {
        tuBSYedDsU += tuBSYedDsU;
        dqIABj += xYFjtoyiYNh;
    }

    for (int UvSQJKsD = 352916823; UvSQJKsD > 0; UvSQJKsD--) {
        nXmQVDlsCYJhVHRO += kxuyWopTSIGo;
        AOyOYzR /= kxuyWopTSIGo;
    }

    return nXmQVDlsCYJhVHRO;
}

bool YSlvttdKtPgewdIK::hgbUnAhPtxEyQlP()
{
    int YNHbjOKfGWQu = -1945802555;
    double dSkMgdhDQLOEIbUy = 312279.3308181871;

    for (int WGgTPdzWu = 1338737237; WGgTPdzWu > 0; WGgTPdzWu--) {
        YNHbjOKfGWQu += YNHbjOKfGWQu;
        dSkMgdhDQLOEIbUy = dSkMgdhDQLOEIbUy;
        dSkMgdhDQLOEIbUy /= dSkMgdhDQLOEIbUy;
    }

    for (int DeVktz = 602211647; DeVktz > 0; DeVktz--) {
        dSkMgdhDQLOEIbUy -= dSkMgdhDQLOEIbUy;
    }

    for (int HgbGOQoAWfGedV = 1131496812; HgbGOQoAWfGedV > 0; HgbGOQoAWfGedV--) {
        dSkMgdhDQLOEIbUy = dSkMgdhDQLOEIbUy;
    }

    if (dSkMgdhDQLOEIbUy > 312279.3308181871) {
        for (int XMSiVOj = 1943671694; XMSiVOj > 0; XMSiVOj--) {
            continue;
        }
    }

    return true;
}

string YSlvttdKtPgewdIK::aLCNqblpDLc(string mtFiWwHNku, int PYrBlOyIIP)
{
    string QQvdZyC = string("WrgKnbAUyAANSUWEDStvWGNpGWPUpEyJSDHEnqFfsIQZqcoXbptzwCyoGHYabOGgQmnQysLglZHsLnqiAjihNHkMfhpUwqSFvisXeXjdqeggVrKrKrPajBYqBuCNGEKVcyvbIPDhJQkGsdLLweJSIPbHLVxvjoKhuCqlnUrKEgpcUxaoiTqBJHnRjlmphoVkmDpuKzQUjfqbHBuKhDFa");
    int HRXlTgrobAvY = -1886369703;
    string nfaLYlqIlTBpk = string("izyoIudNNaEzFvXSwmClwLCJtoiWDHeXiUXmdJaiMwoLxETCKrFRiOJC");
    double BmWGsf = 83822.50134809491;
    double lMVbRmecuECtGiqK = -434096.6626297718;

    return nfaLYlqIlTBpk;
}

double YSlvttdKtPgewdIK::cldUCN(int rQRZJBhyLrICJKV, string hwibpEd, string CoJoarYZ)
{
    int geEmPP = -1426689909;
    string FNHobsoDEUyq = string("UBubuqpBDRNVPUcdoQYRYKRcAwjePnwTKyBxDNtaBOWZzrqgKZONKAYLJoJSmZQOtiRnREqMIimOgCORCAXiEOOMXMIuNRsnEQPLitqATSYuOWUrXULDPUPtVUjRjEnuYHhqTrsPFXQYoNbRhudJcVGlRIuaqnwuQLyeVTOYwXRqZziWCrNDQQxhXLvkiJdxXIycPQMYriQ");
    double OpvoBbIYGCckWhb = 721051.6176856743;
    double zJPYMHnMOhiaOQ = 361593.672059043;
    bool tPmsveyQEhQOwEXx = true;

    if (rQRZJBhyLrICJKV < -1426689909) {
        for (int xQdjCzy = 1753591558; xQdjCzy > 0; xQdjCzy--) {
            rQRZJBhyLrICJKV /= rQRZJBhyLrICJKV;
        }
    }

    for (int YzhdByDRycGy = 1448053121; YzhdByDRycGy > 0; YzhdByDRycGy--) {
        zJPYMHnMOhiaOQ -= zJPYMHnMOhiaOQ;
    }

    if (CoJoarYZ == string("tpwCzGtutfyJIwDqKCJbDMvGLroHkUhREcLWZfXlUHTTkPVpUyBtIGMuUszLbJXrxHhuWghBnPdEErldiAORMhguyBRhGtWbRpZFTGZdqqwRZUTMacoGWRoRGivXoBNiZFLecWAFjSQNMJkKjahaaAIpHtsWVRPhdlqXoeW")) {
        for (int drtElM = 2101111144; drtElM > 0; drtElM--) {
            FNHobsoDEUyq = CoJoarYZ;
        }
    }

    for (int ECXgMlxOeZbg = 1215170099; ECXgMlxOeZbg > 0; ECXgMlxOeZbg--) {
        geEmPP += rQRZJBhyLrICJKV;
    }

    for (int vkvvyIhFQuyd = 1394898358; vkvvyIhFQuyd > 0; vkvvyIhFQuyd--) {
        continue;
    }

    if (CoJoarYZ == string("UBubuqpBDRNVPUcdoQYRYKRcAwjePnwTKyBxDNtaBOWZzrqgKZONKAYLJoJSmZQOtiRnREqMIimOgCORCAXiEOOMXMIuNRsnEQPLitqATSYuOWUrXULDPUPtVUjRjEnuYHhqTrsPFXQYoNbRhudJcVGlRIuaqnwuQLyeVTOYwXRqZziWCrNDQQxhXLvkiJdxXIycPQMYriQ")) {
        for (int fBNIm = 1365998545; fBNIm > 0; fBNIm--) {
            geEmPP = geEmPP;
            CoJoarYZ = CoJoarYZ;
        }
    }

    for (int VqcmivFIdT = 1419814685; VqcmivFIdT > 0; VqcmivFIdT--) {
        continue;
    }

    return zJPYMHnMOhiaOQ;
}

string YSlvttdKtPgewdIK::KhQTvQsxIDiISIUp(double wUbzo, double EHQSo, bool rwszEzaKPeucX, string OoGTfWxcjMNvnO)
{
    double kPshPekagfxQAG = -568577.9499506311;
    double pNmIddTDW = -96294.7950136249;
    double DPuLBOccQZ = 305661.5762053026;
    int oVqeoHUH = -754383592;
    string mkTYGjLIAN = string("zedlrtzqHdVMgjl");
    bool VjhLBOz = false;
    double MztOgcZz = -280698.55158738355;
    double HKgUGlgvicMwoJsO = -561857.431451562;

    return mkTYGjLIAN;
}

double YSlvttdKtPgewdIK::kEOfDyswl(string QCGWmtaheLoNP, double nPHHYuz, string lKeZxryJhkJCnFNy)
{
    int fOLWdUMtNfUVxcP = 1844654324;
    double JNzXTQV = 418192.52909079124;
    double oTqpHovRxsxQwslM = -541448.1169612634;
    string IaApKOKTpjQEgU = string("kaQrERVAIBsosIpSj");
    string XFthygzpqfgy = string("hhjLGhnzgOmAnwtkKcLczqGttujdZnPXlayMASNCpAQPPVBWHYWTirvlvZdtxRxyejSkqWfIEkQskNFsptPuCofyyZIReWXoTcOltWRhgajAEmtllBvDkWGXGUAxbkEqrLEEQpwMmyYfvRNGEyvDrJfiRctwDTCLuvgKNRWwmaiCrhkWIUGwgjCeCIzjblHuBiqLKscUUvyKvvAoyPwjxyckruYJgEpFKdGnZ");
    double MwceUJLlwQlP = -730970.1687702632;
    string RkkwBwSljWEButC = string("QWIRfOtIYnFzjxpTtmRxyIiHproUBUcmOpfZMgtNZbFGxCweegjlaoLHdSogrPlpFQUaRleAjpyPQQwHWzSTzPlc");
    double FRfeVsZmTDS = -813013.6930971304;
    bool lGqfbZZ = false;
    string nALZgowXc = string("dePorBTZBWTiEkIMTnLztJDduzvYesWylfhLlifXcVfPEVlmZQ");

    return FRfeVsZmTDS;
}

string YSlvttdKtPgewdIK::sISHTMQddqkEqWjN(string jJAAfADsuzF, string dggXZbnVityXazE, bool WqJctUrYHmdA, string KULyLeDfFDF, double ZXXpUnIJXmIrnF)
{
    double iEnsfcTMWkdJLYw = 904340.4641038271;
    double HRiwvgcWUdrI = 1018253.4931099885;
    int BPDWD = 141309916;
    double JetmpZ = -942124.5113092352;
    bool QheLned = false;
    string WUsKsZuMf = string("GZLiMZlVglKNTvchZvXauptXDJwnBKWSdPcqOWxLYNiUEnKkGxfNqELtfoBoyQFVpHgrgOUPeKcWjjayRTPnZtjVYYGyrqZTBAgpSUzaRbOUmmQyEAxExrYFAWypqjPvipvjmuKFFnWaduJHKUycLIFRZeomqZxfXWSPeyeYDLAaxDnVgdPjCJkIZZlWOPeKxWtRgvGbIPyIPKEqGvOvLwZyxDtlEWUfxwJOOrjrFiIHUjF");
    bool wKzLDiUJKlh = false;

    return WUsKsZuMf;
}

double YSlvttdKtPgewdIK::HaNGcGMzZKtdoW(bool WQfoHRXIaFoGJJ, bool jgicC)
{
    int WtSrLotOHQ = 1963052140;
    double VOzIXcIQzY = -198198.2181222892;
    double FkFJbQIipQCwu = -846490.8879799024;

    if (FkFJbQIipQCwu == -198198.2181222892) {
        for (int XTkcOh = 2117761238; XTkcOh > 0; XTkcOh--) {
            WtSrLotOHQ = WtSrLotOHQ;
        }
    }

    if (WtSrLotOHQ < 1963052140) {
        for (int gNymx = 1500647668; gNymx > 0; gNymx--) {
            jgicC = jgicC;
            WQfoHRXIaFoGJJ = jgicC;
            VOzIXcIQzY -= VOzIXcIQzY;
        }
    }

    for (int TMEQQzC = 1746757525; TMEQQzC > 0; TMEQQzC--) {
        jgicC = WQfoHRXIaFoGJJ;
        jgicC = WQfoHRXIaFoGJJ;
        jgicC = ! jgicC;
        FkFJbQIipQCwu -= FkFJbQIipQCwu;
    }

    return FkFJbQIipQCwu;
}

double YSlvttdKtPgewdIK::KsKmppxrfmyQIThU(double XrmQRYLvgpFJ, bool dHuotUKfEWxKcsU, string OqOZwjKwlvdY, string AfUbnGm)
{
    int kDgjZgHJ = 1619185113;
    double DWaTFFWSH = 757314.6227336992;
    int pYwQWuRFOpZNW = -2068488655;

    if (dHuotUKfEWxKcsU != false) {
        for (int DKKqpopVtLIT = 1640783077; DKKqpopVtLIT > 0; DKKqpopVtLIT--) {
            AfUbnGm = OqOZwjKwlvdY;
            OqOZwjKwlvdY += AfUbnGm;
            XrmQRYLvgpFJ += XrmQRYLvgpFJ;
            DWaTFFWSH -= XrmQRYLvgpFJ;
        }
    }

    if (DWaTFFWSH <= 757314.6227336992) {
        for (int XiNgszuexJytyQ = 1872108705; XiNgszuexJytyQ > 0; XiNgszuexJytyQ--) {
            OqOZwjKwlvdY = AfUbnGm;
        }
    }

    for (int LzxVXZsKOt = 768710201; LzxVXZsKOt > 0; LzxVXZsKOt--) {
        AfUbnGm = AfUbnGm;
    }

    for (int MmiFUSp = 1931368540; MmiFUSp > 0; MmiFUSp--) {
        continue;
    }

    return DWaTFFWSH;
}

int YSlvttdKtPgewdIK::PworTDPhb(bool iwHWmDQtJXjs, int hgIrWpz)
{
    string twxEU = string("hpUkjVYAnEaukMisfrPTRUkClpjQUTwObHNHwENhpTvzGMWmnaUzCPCYlJOVJOdLRWXDgTQILMutSTVyldzlAgmQgbtmVvXvoyffrazAAMNbHJmOCSFZMputevqbzzgYLWYDzBfrzbNMZyzYocDiAoxcXwsvmulEDxBygqLX");
    string bSIVcXVxxqD = string("bJ");
    string YXWWYsCTjqe = string("zUAyDMZEjQcyiEKBYNDGukXqBixhSPNtpDxPOmGRurlEHffifVgHfgDTSregsPvggwZxSDgiCUkrFbWUJiUZBJQXOOLsVcRyYLyqeIfjwNLsYkJaWFUpTeEaBIwQikRWbylaBeAMQUFhfRgnKxyIddPyCfZEsRCDScnFcJgouUkqoufaPLLOZpF");
    int QSelUhglK = 791003302;
    int VIyxOkobMkayVAj = -2112259432;
    bool QjTHwMDZcIuuGLgs = true;
    int lZRBsatgSuBMShD = -486185782;
    string mdQARc = string("tbnBJKooaSBTYnTDAMNvsAXAklvbMTBUpGuYhAMIwUPqfxLYJFHpBMWdeTNSWPmykqLlyhNZggLdcJRthbcdbLPHMqUZQpbIZjosJQTkgMgDuEMCHwBJpImSxujXKKTQUsywrIUoxnGCuIvNVrdQygzmMqKVupNElkbzEMYCKobwgJqgOsBhGOhiqwYjAETtApflpvZPWBFtvuxkheAW");
    bool tJcAvGacwJkUkuJ = false;

    if (twxEU < string("tbnBJKooaSBTYnTDAMNvsAXAklvbMTBUpGuYhAMIwUPqfxLYJFHpBMWdeTNSWPmykqLlyhNZggLdcJRthbcdbLPHMqUZQpbIZjosJQTkgMgDuEMCHwBJpImSxujXKKTQUsywrIUoxnGCuIvNVrdQygzmMqKVupNElkbzEMYCKobwgJqgOsBhGOhiqwYjAETtApflpvZPWBFtvuxkheAW")) {
        for (int AYJXsK = 279734624; AYJXsK > 0; AYJXsK--) {
            hgIrWpz /= QSelUhglK;
            mdQARc += YXWWYsCTjqe;
        }
    }

    if (QSelUhglK != -2112259432) {
        for (int ZpXJCkww = 1602931587; ZpXJCkww > 0; ZpXJCkww--) {
            lZRBsatgSuBMShD = hgIrWpz;
            tJcAvGacwJkUkuJ = ! QjTHwMDZcIuuGLgs;
        }
    }

    for (int KmQkbYsiIMnG = 1317761824; KmQkbYsiIMnG > 0; KmQkbYsiIMnG--) {
        bSIVcXVxxqD = mdQARc;
    }

    if (bSIVcXVxxqD < string("hpUkjVYAnEaukMisfrPTRUkClpjQUTwObHNHwENhpTvzGMWmnaUzCPCYlJOVJOdLRWXDgTQILMutSTVyldzlAgmQgbtmVvXvoyffrazAAMNbHJmOCSFZMputevqbzzgYLWYDzBfrzbNMZyzYocDiAoxcXwsvmulEDxBygqLX")) {
        for (int lnUdCzLjHswa = 539688499; lnUdCzLjHswa > 0; lnUdCzLjHswa--) {
            QjTHwMDZcIuuGLgs = ! tJcAvGacwJkUkuJ;
            bSIVcXVxxqD = mdQARc;
            VIyxOkobMkayVAj += VIyxOkobMkayVAj;
        }
    }

    for (int mDACMSxIB = 1517178017; mDACMSxIB > 0; mDACMSxIB--) {
        bSIVcXVxxqD += twxEU;
        QjTHwMDZcIuuGLgs = ! iwHWmDQtJXjs;
        lZRBsatgSuBMShD *= VIyxOkobMkayVAj;
    }

    return lZRBsatgSuBMShD;
}

bool YSlvttdKtPgewdIK::yZtThtAiwY(string LmaCcgXhXnvA, double EpCIu)
{
    double OzxXVSKuk = 891146.1452877654;
    int oJytVXCnJ = -329711133;

    if (OzxXVSKuk > 242166.86534467683) {
        for (int CCHpKu = 1544889846; CCHpKu > 0; CCHpKu--) {
            continue;
        }
    }

    for (int oJkrKT = 843674203; oJkrKT > 0; oJkrKT--) {
        EpCIu *= EpCIu;
    }

    for (int WfJcfKiIKN = 1024521474; WfJcfKiIKN > 0; WfJcfKiIKN--) {
        OzxXVSKuk += EpCIu;
        LmaCcgXhXnvA += LmaCcgXhXnvA;
        LmaCcgXhXnvA += LmaCcgXhXnvA;
        OzxXVSKuk -= EpCIu;
    }

    return false;
}

YSlvttdKtPgewdIK::YSlvttdKtPgewdIK()
{
    this->XdpWEtmvJOWsNvU(168634.7151616778, string("QVnxrvjdboDAqmYnOvrBpkoGTwrJndkDzLhDkPcBZvgavuGHLvfULzZUWLKrtaNNBAaTiRXkyFOPthFnzJulaNQtywuxqdayTzBATZKHvBTBsPqwjtcsxAwVfECfbiKJbAaRYQeVsbThAWcwqNNkKzbNucOGWYYnzCcORLtSdEkbKlFvmrMnxdaDXZGNYYjEenxJFnBWSRX"), string("eygiEjBEzEeOaEgProeOCkbvDmxhEzClJckEyIYVUIUGhDRlHBmstDgHbIWmiBjWH"));
    this->ipWxRaws(string("uLeNpJkMGLmBHUGJdflvTHhxOjzpYrDLxuWOhdeQmoeWYxBaibGQLYlrUrzmNBYPn"), 2071663922, 1494533555);
    this->hgbUnAhPtxEyQlP();
    this->aLCNqblpDLc(string("nCttAnavzodqCzuMOiMrDATxKqnIOMACMdmEdIbqAkGYkDXWNZitAtMgqgbpJIITPIrYXpAaeGfszHVQbZvpcYlZuvlfaqjGcmAgtKbokHHzTdHidJOsVDJklvEHUxvKfQaDJfLjbqRxTxqZbOFPurpuAesqTreOzksgyvGhZpIjfgyftdtUSkWSCWXiQDZwURpfyQjoBRnETIncZQkHjaoyySEfiMOIpZzWIwUtZynOQEtvmJfQTPKU"), -1971971162);
    this->cldUCN(-1981713977, string("gYMcTBNUaRHxlwiHlKGjWowFb"), string("tpwCzGtutfyJIwDqKCJbDMvGLroHkUhREcLWZfXlUHTTkPVpUyBtIGMuUszLbJXrxHhuWghBnPdEErldiAORMhguyBRhGtWbRpZFTGZdqqwRZUTMacoGWRoRGivXoBNiZFLecWAFjSQNMJkKjahaaAIpHtsWVRPhdlqXoeW"));
    this->KhQTvQsxIDiISIUp(637940.089244837, 563128.9705300939, false, string("GJCDYrVbpzTdeIvBVmBCXLmWsAKMVF"));
    this->kEOfDyswl(string("AmkrKvYHfcvCobTNwZAvGkyfrTipevEkfhLfdsfaXZSKQTxbFoqUOMxmmItWPdCKQYPpgdptOIBFvsVljhJfqscMFOlbKSMmRiZK"), -92653.46302330095, string("HSdGfDgAasRQgTvaZkaEbhHSHNAKZLszuOMBJcLWuLrmYztRgoEqyUODbfRfXxAB"));
    this->sISHTMQddqkEqWjN(string("kNU"), string("VRAJaVWEietbKmEuuXSiRkOFuNDQnYmxPCBKNtxQltOBAQYRMgNTGbYDDzwpkjlCfNyslVZSLbfXwwiXJnuqetHheJSPNnVjAEnEKsdtkONnIsxaMsAJAZeBZOrgmPbPpyZIxIOLtuUZtDLePwCnpvsvzAbGXhcsJRiOhXtMOBhhuQLcXIUQEZUnWJBFArJkORGVXzELhmijKitDQAianyVqXRFsueBQdziXAlCcMc"), false, string("pv"), 173890.8717971242);
    this->HaNGcGMzZKtdoW(true, false);
    this->KsKmppxrfmyQIThU(67948.48194939822, false, string("GGPmyTjMJmrpgWkfXQAOpxRtAWIdVeVtSxnJKvhfZvvhgxvYeODHkevslAMWQcdcBreyfMzvuKUUBPhBTGijhPuzQzVAhYqc"), string("ZXpvlBSrqaKkmeMRObXrtkVIRBczDRcvPaFlweNhjkEpbuQmFvHCkbXoPCmNuTZwICgeqAjCXbRlWxeVzmHaOLNhhfNbfysoptKMuPOnMIajQFUuiqOquwkkKPoQqWrzUUnHJRBsraQnabWkJMeDhdBXNNCJtCupzkekyPsGVgYWUnStaGICOfpKcTpJiIQzpMesZrzjpwAZTVthxALdMobF"));
    this->PworTDPhb(true, -1181173356);
    this->yZtThtAiwY(string("ctOVzJDeSDWUxZeSkXLcWkZQZqbyZcoNDHnqdvXXvNojjiHCWFLLsJcrRNgbRFWdjwExResedhKjtYXMjNznWOfhamBEYNYjZfBKKvZdJWwNYxxYgjnSZXLGvCTNlRSAHoNGIwMOlFaqwdqCqHAPIyNpZSRtEqqhkpcSLVirYTwzmqjzhoBwOKvosJOeAUeok"), 242166.86534467683);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HWqzeBRQMGtgg
{
public:
    bool ZuEEPnaMyBYLAdM;
    int zWnJqgTBphCxAMT;
    int aLwgAYhKmWJmhQRB;
    int PJWyIiEUqS;

    HWqzeBRQMGtgg();
    void zXNZtrNCcs(string AocYQUcAE, string JBSSJHXGnD);
    double lUIiBmgnm(bool eiiDpGlXMnY, int YLGUTwupHyUQhV, int HdXmsFDbIX);
    int tgPZfQvERGnfkWX(string bEgqP, int KFfbMwgIJRsjGKzN);
    void BxAaXfVb();
    int YhQMOBLpo(string AKBHJzWinyx, string RvxzJYYGXgYXQyR, double rlawApuDiP, string txNbUZWzHcRChJ, int GmmOxLo);
    int gEnsuaRsKKX();
    bool dhWScstIitvz(bool OzRJmDiSMj);
protected:
    double MLGFJT;

private:
    double ETuSnlWKPvO;
    bool jpAPp;
    int vJXBAzMrep;
    int XJrsLn;

    void UIhsrg(string INczzjUG, string laOSjQypO, double uBwGesvdGrTtkUjb, string YGcfbFMOaQiC, double afDxeybqaaeY);
    double WeXSokUQLBO(string BBBhzAoguTIXxuJc, string LKtRkRt, double cRfJalwdXOg, bool GpORlSe, string hIfRmxvCkSI);
    void KJPuqi(double KPXRwmgriCPlaR);
    bool dtmPmephFVFrwi();
    int JxKrq(bool fnwRyytQikwMUyx, string npfTzTwmytCmGSY, double MiUgvkkk, int ChYvuSsDdj);
};

void HWqzeBRQMGtgg::zXNZtrNCcs(string AocYQUcAE, string JBSSJHXGnD)
{
    string KPNZmEVCx = string("ewmZMWicfGdEjPnvuOnATFZ");
}

double HWqzeBRQMGtgg::lUIiBmgnm(bool eiiDpGlXMnY, int YLGUTwupHyUQhV, int HdXmsFDbIX)
{
    int JaArLXvooXwp = -273241474;

    if (HdXmsFDbIX != -1028324120) {
        for (int TEPQevqglAEEJZB = 44150661; TEPQevqglAEEJZB > 0; TEPQevqglAEEJZB--) {
            HdXmsFDbIX -= HdXmsFDbIX;
            HdXmsFDbIX += YLGUTwupHyUQhV;
            YLGUTwupHyUQhV *= YLGUTwupHyUQhV;
            HdXmsFDbIX /= HdXmsFDbIX;
            YLGUTwupHyUQhV = JaArLXvooXwp;
            YLGUTwupHyUQhV = YLGUTwupHyUQhV;
            HdXmsFDbIX *= YLGUTwupHyUQhV;
        }
    }

    return -266966.70923007315;
}

int HWqzeBRQMGtgg::tgPZfQvERGnfkWX(string bEgqP, int KFfbMwgIJRsjGKzN)
{
    bool qYyyYLW = true;
    string XojWG = string("rcraGsSWtTmeCVizUXtHBdAqALPgvIneQKVMnNIpSOjpoFYLHNNGSRzNUHUDO");
    bool uZjeiuqCAYw = true;
    string NZhtw = string("WQuYTi");
    string hxEtFtGnxkN = string("aSnVNGBhjPojnkjycCbJtKzbLNlxGnWOSEBuKEwYyYLvmrfLtNJpPCLZjByuTxYHtXwEcTUwUVtBceMbGGmHbtsavCdwQjzTgeZnyRIPUOnJDGXbRtVLgNusuuzyEyUqgPjZwTRdAnSEkeI");
    bool nVGOKZstocglF = true;

    if (uZjeiuqCAYw == true) {
        for (int jFvYG = 438276587; jFvYG > 0; jFvYG--) {
            NZhtw = bEgqP;
            bEgqP += hxEtFtGnxkN;
            qYyyYLW = nVGOKZstocglF;
            bEgqP = bEgqP;
        }
    }

    for (int SnoFBjHemSRmWvhv = 1361327310; SnoFBjHemSRmWvhv > 0; SnoFBjHemSRmWvhv--) {
        continue;
    }

    for (int xmUTedFMHQaDtNqi = 1215273142; xmUTedFMHQaDtNqi > 0; xmUTedFMHQaDtNqi--) {
        XojWG = XojWG;
    }

    if (hxEtFtGnxkN == string("aSnVNGBhjPojnkjycCbJtKzbLNlxGnWOSEBuKEwYyYLvmrfLtNJpPCLZjByuTxYHtXwEcTUwUVtBceMbGGmHbtsavCdwQjzTgeZnyRIPUOnJDGXbRtVLgNusuuzyEyUqgPjZwTRdAnSEkeI")) {
        for (int PbseIRTZDSSwV = 1736796299; PbseIRTZDSSwV > 0; PbseIRTZDSSwV--) {
            hxEtFtGnxkN += bEgqP;
            nVGOKZstocglF = ! nVGOKZstocglF;
        }
    }

    for (int xuWlZhHej = 304484599; xuWlZhHej > 0; xuWlZhHej--) {
        bEgqP += XojWG;
    }

    if (uZjeiuqCAYw == true) {
        for (int ldMKFCAvN = 2017194394; ldMKFCAvN > 0; ldMKFCAvN--) {
            qYyyYLW = ! uZjeiuqCAYw;
            hxEtFtGnxkN = hxEtFtGnxkN;
            hxEtFtGnxkN += XojWG;
            qYyyYLW = ! uZjeiuqCAYw;
        }
    }

    return KFfbMwgIJRsjGKzN;
}

void HWqzeBRQMGtgg::BxAaXfVb()
{
    string EweeqpuAiwFHobA = string("jTsfPebJsmVfXMnXmYxxqCiXDadkbbChjkkhGGhEKXQKPQCqeehorUNrtbIZJrNISUNJpKjBjnIJMdDGGXqizlIwBGUjBhMewWHZdNXgEKFRaVGmtLVqITFDjXIlkDtRqvkAjLKEPiPoXNCeyOfjNmJXSnzwjHfKwkFdrVzkcfIYAIipTO");
    string FsTLLYXN = string("MFbfLysXjLuocniyJDIgAIDseMtUwgxDPbixWOumpoMDVHOKCmTWlVTmBtmbcpJrBNyNNrfaZJqfYmTdPJSVvsCkbfqtujJqJwJNUItzbIPKSZOIIktsgarGouffBykjbghblPWBSJWKpCFBDIxNuXBEJSSREntDoFGpZZGMFBkGggoDvOzQAddjkBiPCLQGjCBRfqduxdsPBGBqUPIjrVpyzn");
    double enevAXO = 884242.4984234966;
    double egpSEWHHflqgoZ = -44409.095386063884;
    string BilUPhxTFgdUKPj = string("YRPqhDBKfJEXxCqhTpgSXroaTRBdZTQkyILRjgyCNgDKuLIaLLnhgsTMvdbioxIvJzQWLdWlcbTTIEVqlqZjHPqQBDwnYkNswOGzBQWrGpXitfloRtuJfbJAuDyGLHiJnXoSwbeGgiTgcOdYhKMXJYxhWxWBqSomdYUGFanrgIQUkKFtivuwLqnMbFpnzy");
    bool elIryJLsqzqH = true;
    string GTvcgaUKZdHU = string("ZTxldeauoeEYrpKkfppGgEZpAXgwtxPUlCcSRduzPMDYtinrfdwUCLASAtXYaawjTTCoOMXHIRBguMwxhEQsdqwnSIDtSzSMHuXTxjDLYLaAqkqeVPrphMfgoQTOymJuKvcBwuKwmMnZyrQuxymoNSQqIPvkAODWwXAVwCzDqaSpSedIjyLPzZfBGiNSCSPraMj");

    for (int JZVjWNorsNkdU = 1481816520; JZVjWNorsNkdU > 0; JZVjWNorsNkdU--) {
        BilUPhxTFgdUKPj += BilUPhxTFgdUKPj;
    }

    for (int nRFBdJFXPxFioo = 1913414938; nRFBdJFXPxFioo > 0; nRFBdJFXPxFioo--) {
        FsTLLYXN += BilUPhxTFgdUKPj;
        BilUPhxTFgdUKPj += EweeqpuAiwFHobA;
    }
}

int HWqzeBRQMGtgg::YhQMOBLpo(string AKBHJzWinyx, string RvxzJYYGXgYXQyR, double rlawApuDiP, string txNbUZWzHcRChJ, int GmmOxLo)
{
    bool vbJNAxvGqG = false;
    double HFcjlWFMEYgr = -900821.6403539196;
    string VgikErB = string("EzJjDNBRFdIiIoRQirEGpaaMXcKwnsRqPpHBTvXLDYPVTWtOCPJTUVYjy");

    if (HFcjlWFMEYgr < -900821.6403539196) {
        for (int cDIdPfCSh = 177231596; cDIdPfCSh > 0; cDIdPfCSh--) {
            VgikErB += RvxzJYYGXgYXQyR;
            txNbUZWzHcRChJ = txNbUZWzHcRChJ;
            HFcjlWFMEYgr /= HFcjlWFMEYgr;
            vbJNAxvGqG = vbJNAxvGqG;
            txNbUZWzHcRChJ += txNbUZWzHcRChJ;
            AKBHJzWinyx += VgikErB;
        }
    }

    if (AKBHJzWinyx <= string("OxuPkESWvujyfNhxzOARksdMdIeP")) {
        for (int kVnVVMSFr = 1690336505; kVnVVMSFr > 0; kVnVVMSFr--) {
            continue;
        }
    }

    for (int sqLjAT = 1330246879; sqLjAT > 0; sqLjAT--) {
        HFcjlWFMEYgr -= HFcjlWFMEYgr;
        txNbUZWzHcRChJ = VgikErB;
        VgikErB += RvxzJYYGXgYXQyR;
    }

    if (HFcjlWFMEYgr == -900821.6403539196) {
        for (int aFVHBQ = 448444123; aFVHBQ > 0; aFVHBQ--) {
            RvxzJYYGXgYXQyR = VgikErB;
            VgikErB = AKBHJzWinyx;
            vbJNAxvGqG = vbJNAxvGqG;
            VgikErB = VgikErB;
        }
    }

    for (int OzXzc = 538992260; OzXzc > 0; OzXzc--) {
        txNbUZWzHcRChJ += AKBHJzWinyx;
        HFcjlWFMEYgr += rlawApuDiP;
        VgikErB += AKBHJzWinyx;
        AKBHJzWinyx = txNbUZWzHcRChJ;
    }

    for (int tzIZSqe = 1414884890; tzIZSqe > 0; tzIZSqe--) {
        HFcjlWFMEYgr += HFcjlWFMEYgr;
    }

    return GmmOxLo;
}

int HWqzeBRQMGtgg::gEnsuaRsKKX()
{
    int pawIN = -1050764740;
    double eWXSFlvHIYjMQLb = -638826.3616135089;
    int eDyvwaTyuyORqg = -946473701;
    string agFErT = string("OKptMKYJuGpPmvfIiCfdDgnJlrgPKlkhTGp");

    if (agFErT == string("OKptMKYJuGpPmvfIiCfdDgnJlrgPKlkhTGp")) {
        for (int kymtSfeqxdHvqkdc = 865281520; kymtSfeqxdHvqkdc > 0; kymtSfeqxdHvqkdc--) {
            eDyvwaTyuyORqg *= eDyvwaTyuyORqg;
            agFErT += agFErT;
            pawIN -= pawIN;
        }
    }

    return eDyvwaTyuyORqg;
}

bool HWqzeBRQMGtgg::dhWScstIitvz(bool OzRJmDiSMj)
{
    string KGxAVbiQNJP = string("NNVOmGSNRcilVvWeBGwEvWQHLtQkYqTjtsCVRfJkxGnmyeYavoHwqMdJJuJnFGsPheVDGUZeQpcfmdUUfCWzdapuNgPgrEwuRGQBMVhMSPpcwMalNYccJCsVKrIomjrecYjxQTwCFnDELCjegBfAGgKizGqwVNjcatQiLnUXNLJVHoGeihxDSNjEyZCrddlkH");
    bool TKThjG = true;
    double XzeZWwIxsVvThfPb = -711310.1560496223;
    string UvWQOrPx = string("ZUzxqrpEmwBxXzLoGdRYNzaxcpavkoKHhCSLROZEzyVdmyMXCXYApQENoAUTiOraWXkCFjidzWYWBKgPapbsaCakEETtfxLnRRsLmAaSNFNrLXqHLWLKxFqSIAGLPttUeEbdbtLXtAOTQDQWgpcIBKYiVgjgvNGIMKIKmptwfEvBFilSqQjucYxEMHsfOekFyVHSYKjggwfUlZhzTZIeQfJuqoGmzkvYdYYfYrQasahNBPKMisoGEixplqqw");
    bool uIWwRo = false;
    string zvABqmZWCl = string("ekPfPVqeurxYfJCFGLMdOkYIqmDeEWcVjmdaPdRsBsKeQXerIwPDmcmVhErwzjTRjIwcjeeMeklVkcXvNbeQhChfzFSiWrqGaItYlSfgEIQBXIYssxaEUBCeNzITQNprDJBIoLLcpThiiNkspAAmXILFs");

    for (int ZjUdhHVVYIRSIB = 1537569543; ZjUdhHVVYIRSIB > 0; ZjUdhHVVYIRSIB--) {
        continue;
    }

    if (UvWQOrPx != string("NNVOmGSNRcilVvWeBGwEvWQHLtQkYqTjtsCVRfJkxGnmyeYavoHwqMdJJuJnFGsPheVDGUZeQpcfmdUUfCWzdapuNgPgrEwuRGQBMVhMSPpcwMalNYccJCsVKrIomjrecYjxQTwCFnDELCjegBfAGgKizGqwVNjcatQiLnUXNLJVHoGeihxDSNjEyZCrddlkH")) {
        for (int SinVqokSSCNlWB = 866943911; SinVqokSSCNlWB > 0; SinVqokSSCNlWB--) {
            KGxAVbiQNJP += UvWQOrPx;
            uIWwRo = TKThjG;
        }
    }

    if (OzRJmDiSMj != false) {
        for (int osjIwBryleki = 1090804582; osjIwBryleki > 0; osjIwBryleki--) {
            UvWQOrPx = UvWQOrPx;
            zvABqmZWCl += UvWQOrPx;
            UvWQOrPx += zvABqmZWCl;
        }
    }

    for (int hEwqUINQxUhYmRo = 604607062; hEwqUINQxUhYmRo > 0; hEwqUINQxUhYmRo--) {
        uIWwRo = OzRJmDiSMj;
    }

    return uIWwRo;
}

void HWqzeBRQMGtgg::UIhsrg(string INczzjUG, string laOSjQypO, double uBwGesvdGrTtkUjb, string YGcfbFMOaQiC, double afDxeybqaaeY)
{
    double lPyGPubIMtAPFrK = -824397.4782215212;
    int LgxyNoWzfyPEyrbJ = -306584217;
    double lMbPnV = 363092.1971619246;
    string tvuWKei = string("Rrg");

    for (int WuexNhOUovqyBM = 1741131606; WuexNhOUovqyBM > 0; WuexNhOUovqyBM--) {
        afDxeybqaaeY -= uBwGesvdGrTtkUjb;
        INczzjUG = laOSjQypO;
        laOSjQypO = laOSjQypO;
        YGcfbFMOaQiC = tvuWKei;
    }

    for (int BaAkdW = 1659082988; BaAkdW > 0; BaAkdW--) {
        lPyGPubIMtAPFrK -= lMbPnV;
        tvuWKei = YGcfbFMOaQiC;
    }
}

double HWqzeBRQMGtgg::WeXSokUQLBO(string BBBhzAoguTIXxuJc, string LKtRkRt, double cRfJalwdXOg, bool GpORlSe, string hIfRmxvCkSI)
{
    bool etjBqocqXRabpc = false;

    return cRfJalwdXOg;
}

void HWqzeBRQMGtgg::KJPuqi(double KPXRwmgriCPlaR)
{
    bool oxdavSmbpmFOeRHU = false;

    for (int ftNUvYRgZxB = 1280789144; ftNUvYRgZxB > 0; ftNUvYRgZxB--) {
        KPXRwmgriCPlaR = KPXRwmgriCPlaR;
        oxdavSmbpmFOeRHU = oxdavSmbpmFOeRHU;
    }

    for (int BZaeihNrogoPRRv = 716367276; BZaeihNrogoPRRv > 0; BZaeihNrogoPRRv--) {
        KPXRwmgriCPlaR -= KPXRwmgriCPlaR;
    }

    for (int lrFXzDur = 1985287492; lrFXzDur > 0; lrFXzDur--) {
        KPXRwmgriCPlaR *= KPXRwmgriCPlaR;
    }
}

bool HWqzeBRQMGtgg::dtmPmephFVFrwi()
{
    string VwyoJjyfKwMLeDhF = string("HlWbTL");
    bool xMVcBwaNPNpm = true;

    for (int kuFrt = 1584385696; kuFrt > 0; kuFrt--) {
        VwyoJjyfKwMLeDhF += VwyoJjyfKwMLeDhF;
        VwyoJjyfKwMLeDhF = VwyoJjyfKwMLeDhF;
    }

    for (int EQBvsVk = 1907853035; EQBvsVk > 0; EQBvsVk--) {
        VwyoJjyfKwMLeDhF += VwyoJjyfKwMLeDhF;
    }

    return xMVcBwaNPNpm;
}

int HWqzeBRQMGtgg::JxKrq(bool fnwRyytQikwMUyx, string npfTzTwmytCmGSY, double MiUgvkkk, int ChYvuSsDdj)
{
    int biyyZq = -455598385;
    bool UQnJSiRSjnULpcm = false;
    int okLkZcqR = -1354944533;
    double NgUQB = 35794.29969502929;
    bool ufQVQIDHzkCswOYT = true;
    string wLqCbZqklz = string("FWCNSQUTlcooUvOFAbFvHjFThqUROYSWXvUVxVbXZVIcbiPVPOVNAW");

    for (int lTyMX = 2036259214; lTyMX > 0; lTyMX--) {
        NgUQB /= NgUQB;
    }

    return okLkZcqR;
}

HWqzeBRQMGtgg::HWqzeBRQMGtgg()
{
    this->zXNZtrNCcs(string("FEroAWSqoNEpALCAcbTOHWlOjaHdwUhpjlFNcLsgbVoKzOZHrHxFnbpmStcshlZdVqzamldgdJlzLyFWKaFBKekFLmgmHOYIaPVUqWvtCLjWPsqOyzeOKspZwALurlnXaTMuGmBUmzCDBVbQACBjopaBLqWfjGKYDdzwuaKSOrJlHLgopKXGH"), string("GSpoZEkNIOrixXbmEZtonvFLIduKAbzqpjdZkENxvRdHFiSQNqNpeQMHeBzhIzvHmdmvrUEJFuUjuhpGMxDWaffESULuYsEkEpagkwbsVhZcfcRtTOmbCrTnScZowgKYORKKyofeLulRlDFcrq"));
    this->lUIiBmgnm(true, -866908299, -1028324120);
    this->tgPZfQvERGnfkWX(string("MvfPMzSDHRhSHeCkurAomcuhrBKOaojCQhQSYdNwAJRYbKWhvWUZVotatBEUzRriJNhGtjLWqrjcOPLlXCmscLVydGoTBbVGmoSLcACdaNQwmnYRyTkBvAv"), -1742485140);
    this->BxAaXfVb();
    this->YhQMOBLpo(string("poqoxJewajkNDWgpjKJmdYUickYzgkWwnTRthHoSbWkXGryPcTybUMSkHKCHzULJhUxqpsxxVCevSFydykhYmTyvtOdriLihiHWUqOsKkDudqHeBaPmHGGySGXMXxoToQRwTIBZCIfsYxFzXwOKSabouczyHoTNqCUAwqnYocIxSwWYohP"), string("oAHkhDjKlBQcmmgpZvibjihoMXBpiDpoXgdgGeqLAVOLLUrqflGAvBjIcqdVKuZUvoMmFcujFLLqryyTwJYGMYKoJrIZxtKYvjsXNewvOFNNnQalyzQjorEoXuMZqzBNHTAIgaaEushZRPOAftDbnZQESAGEpACpnuiMXUQVocCXiIzmcsLJUtmzfYqeuyJQoIzhtePvLxRmqQhukWYANNGeOGZQANFlVistgqTFpOLP"), 798309.5457265091, string("OxuPkESWvujyfNhxzOARksdMdIeP"), -1915195969);
    this->gEnsuaRsKKX();
    this->dhWScstIitvz(false);
    this->UIhsrg(string("IlLxvRCxoiFsEehmKyIMgGnktomlemBDHXSlLpCGPKusDVaIqiqmrOxJnccyziFcAsvKBZXJNweKTYDZoMNsMfNAeSeeKIEIeqVmwNxDmWdWLbonixesARKPRCMBjKDpgsmYElYuYYlcSkNcBlOcNyulfFfnXXsvLfLuQneIQlhomRXtvdePneVdOkHnpEFXEJWbXQNNPyknkfhuWygnLJAAzghVCPjk"), string("gtfXHxVMsTonqoogIUYLbPGBKKfcGVbWZYJvnMlubMsgACrrWynoKmyGHjmhgXeyOkTmfFgnnmtSkPXdZAXRYEFLwIfJlglSJFCQjPyTxrXeeHkpwsWXJbFqtahQwqfzhrpqLhaoOunmBnchFtpaYvbUBdBGhDQufbbVfoEpnJnyZzFzuvAMFAXNlMQoDLhdm"), 122741.29699220986, string("FkTyIyVejxheZciOLGVGhFjOcVQkyjkvLqKUDTaMvgWIGRQsfgcJllBZLRPgMekLHjvhQVOCHfngqThrdUKhoHemGNpOclLjqKc"), -250848.2870996609);
    this->WeXSokUQLBO(string("foohmjCPtefCMzqXInxxqjVRXaeNKGNIgdBGehoADytekPIvVsxlnzwoSEspDcejNWJFRaZcaQGNIMAfXAfLlzwdsKiAmNqKyMBRfBuHfNxzXofxgQXNDTifIIRJENzWjGfXMIslXyrcNomriPumAnLCZTbFrIbhvOkGQzrsSFqetwhrHiryzXFmYXyYiTaQduubBVSSpEDpXytuJvYFhMImfhiyUoKMjQJKtAIFVL"), string("LaHHUxpDENzFNEjDnGWTO"), -762146.2614136878, true, string("lIhOzucJzMrZUsvSiQLFqLKupFkJlhvMfSUeIqWKmMoNhmYOOYGDckMklxnKRKQqyHWrYmDlwfJOFzLqtOkMKeiGUzeVezUutsRwRClfcpiuKZTnBZjYaNYXJvoLUMwREkfpfWXyrIixpvnlbQTXCCzoPuBFfvPAPE"));
    this->KJPuqi(-670145.8583736115);
    this->dtmPmephFVFrwi();
    this->JxKrq(true, string("HJNalWUyoyXRZTWcQsUiotdtTRSvpzpCIBxuzxYj"), -107316.84586909102, -1983842484);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gvZNpXwmdEkp
{
public:
    double tajkG;
    bool QxDdDhvqrB;

    gvZNpXwmdEkp();
    int WGisPdewOlOmmbcf(bool bCIrkClYaoU, string WPurTNMwpu, bool cxTtSL, double ftrZtIaBdyyUgo);
    string IbEUvBecUStmixS(bool YBHPgwnof, int LwgabFxOFHiZLvPd, double EcLEykh, double hhGkZHrHoOHTfMy, string UhAOnNoHhia);
    int ENXFTqWlDIMruHzc();
    string OhGbafDcULmC();
    bool TCoTiqC(bool jCfzsggZGqhWIpC);
    int NvdPHGpeWaAeeoIe(string JNJIUNGaMltbleRa, int xMZjjilq, bool crINkDzWyxrJl);
    string gqXNWB(string krsBgUr);
protected:
    bool kbdhPfk;
    string ysCMOIqTsGdmaZh;
    int oVlxXmjOZx;
    string jmQqqooNITNht;

    string fLjZb(int DPGlTbSA, string cnhXvFU, double EZFVUbaTdIyanCM);
    double mzaiZFoqAyKHEf(double eNaiU, int WFgcTvjMXCvgOtE, double GgNHs, bool CRVAqCGcdote, bool cNXTAQVfOAaw);
private:
    int QBCHh;
    bool NLLPfxEHU;
    double UpiafgRRTvQfaR;
    double BwoLfeKYCoDVJ;
    string vHVAQrzhAWcsPl;
    bool viLkQaSQRSdSLCWa;

    double VNNBeRqyMb(string csJxphhcTwInCMu);
    void jAgWif(double KAyrM, bool XSmqgPdZdvfCoxK, bool nvyCLmxPOIXWIGU);
    int WgPAhCDIjsG(string zpfWH, int ymisG, double BJpdlkENWvsA);
    void SbUsOcS(string zhAkIXRnHfL, string QogXvj);
    bool LmFNL(double vTabjeA, bool tqVha, double dwGjUxpMaiA, bool sSxDroLIbON, string bJBwoFxcm);
    void zTnaEtyEwR(bool OELsWwajA, int ZFUyBX, int RGRakP);
    void gdvGkLluZLaGgIXp(int JLblnLB, double fABXjjLDz, int TKdFPONQyngaOX, int IaPgCS, double rfvlxQ);
    int cmSkGc(int lzsJPpJxsMtjWjZR, bool wxTHDWYsDl, bool quQNlTUzd, double ICKtvziVAurLRj, int DnhUNtUH);
};

int gvZNpXwmdEkp::WGisPdewOlOmmbcf(bool bCIrkClYaoU, string WPurTNMwpu, bool cxTtSL, double ftrZtIaBdyyUgo)
{
    bool iPfHrj = false;
    int lpwMZoTv = 1566227095;
    bool MfTFMQSPuInc = false;
    string JsrPAUkorzqRHF = string("qxBBofzVbrBUqgufNgXPlExOJxFvPCeePTrOBBUksyvXUMfxUTfjinxJKLygDC");
    bool nvBRZfMPnx = true;
    bool ahWSUuhrKW = false;
    bool xmkZBfaAg = true;

    for (int gEewKgKVMPaWxVEE = 271725915; gEewKgKVMPaWxVEE > 0; gEewKgKVMPaWxVEE--) {
        xmkZBfaAg = ! bCIrkClYaoU;
        xmkZBfaAg = xmkZBfaAg;
        nvBRZfMPnx = nvBRZfMPnx;
        nvBRZfMPnx = nvBRZfMPnx;
        nvBRZfMPnx = cxTtSL;
        bCIrkClYaoU = xmkZBfaAg;
        ahWSUuhrKW = ! ahWSUuhrKW;
    }

    return lpwMZoTv;
}

string gvZNpXwmdEkp::IbEUvBecUStmixS(bool YBHPgwnof, int LwgabFxOFHiZLvPd, double EcLEykh, double hhGkZHrHoOHTfMy, string UhAOnNoHhia)
{
    int kjsgHOUZz = 1329139819;

    for (int MOnXVwh = 2028496465; MOnXVwh > 0; MOnXVwh--) {
        kjsgHOUZz += LwgabFxOFHiZLvPd;
    }

    if (LwgabFxOFHiZLvPd < 1548503972) {
        for (int zPnueK = 739264739; zPnueK > 0; zPnueK--) {
            continue;
        }
    }

    return UhAOnNoHhia;
}

int gvZNpXwmdEkp::ENXFTqWlDIMruHzc()
{
    string elvczYP = string("KQPncxceLZSLpZUPhPjafkuTYSXoiIqSipHiTSEKtUdexqvlEzWsGSBv");
    double KIpXQp = 19720.411104838084;
    double qSidCKRwRJjMY = -956027.3537122525;
    string izbXxTwQ = string("MExqHNdEtKFPJXuXAveyOaariHhrYbPga");
    double yDaiR = 603544.8287048115;

    for (int TzFqkrLa = 759033057; TzFqkrLa > 0; TzFqkrLa--) {
        KIpXQp += yDaiR;
    }

    return -1145903259;
}

string gvZNpXwmdEkp::OhGbafDcULmC()
{
    bool gpcLGjLOFq = true;
    double VvtUcZWQlP = -741951.2411777485;
    bool nwfEVEDQKu = false;
    int KEBAXxQ = -494050236;
    int HZYMHLxedDYQzRl = 1937967;
    double rAKlOnB = 450678.95073943224;

    for (int hEyQiCDqWj = 1549361079; hEyQiCDqWj > 0; hEyQiCDqWj--) {
        nwfEVEDQKu = ! nwfEVEDQKu;
        gpcLGjLOFq = nwfEVEDQKu;
        nwfEVEDQKu = gpcLGjLOFq;
        gpcLGjLOFq = nwfEVEDQKu;
    }

    for (int quFzw = 643117417; quFzw > 0; quFzw--) {
        gpcLGjLOFq = gpcLGjLOFq;
    }

    for (int SKmYb = 1980545267; SKmYb > 0; SKmYb--) {
        continue;
    }

    if (rAKlOnB < -741951.2411777485) {
        for (int VAgFAqNyQMc = 2028742437; VAgFAqNyQMc > 0; VAgFAqNyQMc--) {
            rAKlOnB = rAKlOnB;
        }
    }

    for (int wrKIRHwUsS = 590955186; wrKIRHwUsS > 0; wrKIRHwUsS--) {
        continue;
    }

    for (int rqfokSmafdqCzR = 1704897371; rqfokSmafdqCzR > 0; rqfokSmafdqCzR--) {
        HZYMHLxedDYQzRl /= HZYMHLxedDYQzRl;
        rAKlOnB /= VvtUcZWQlP;
        gpcLGjLOFq = ! nwfEVEDQKu;
    }

    return string("AWcXqKNziXnHTVClWkRpDDPdfNuOEtOQgEsoAndEGUvmjelAOKDgtwKBGFUvDxSdCHNarnuHEtRypszssocwtMKCWksdPVUIwxtMdEseSweTkUfVNIvYIWOmIfKmQwEMZaVPAwZnepGPSPRwBaVYScIDGZGCxrWcpzVhKtrEhTCGjKqz");
}

bool gvZNpXwmdEkp::TCoTiqC(bool jCfzsggZGqhWIpC)
{
    double EzMfZgdQSDYxuLYm = 94720.46743124459;
    string hgBwODhU = string("EOXVwhvcMYuSVXdfrOIlXcyHUznyjIiReuuxsciVBQYOgHwZAQBDqbLCxoaZNcTTZIUHpoPsbRrTKfORhftjh");
    string DJDTrAqTHGPi = string("LIxrkQWUgTUxqsKuXACQSfOiDjNrrdQubqnUYJHppUeXwxrmzoFplrAB");
    double AVoSdsVybH = 535327.4209877647;
    string yEeBTW = string("GFoJabAuTZVhMGKAKHQnPSxBxqXzfiiBbpDUKqPheCRoDstzvtKOEHIkIIGONruuUbePenBnCPKzHJXZXWUWLPOvqfabKXpFiJJRnTAUbXrvKvSmotqpDREdgTfmjFowZQQujwOnNDRhwVysMZqHcnMroIJZTzTAaVSEPqfssImvURpetlLODTsZPHvwHqsxRIgQxwdFRpwYSGUyuHVUfEyxmDCTFxPgVsPXfDpmmUCVO");
    string NDfHnsvKZFTiZiQM = string("AtAxCUbYRWRyoKoTSPPAseopKFbAmJVLkWlIsRqKjpAFzPqrMEbWPaXSPOLeVfclefmOsPbObrZcSebRPymtdEppIlfzsSqTNDsBTLNKFinrIMVQNpbhpDkiDdAlvIBvNzFmumLGRYdbPUgUeEpIeZNiEauBjlnEYeWWTReN");
    string xAUDdaGEWTmqJVoS = string("MgQToCOEbRbNBtDAgtnngBBVqAGogcrQF");

    if (xAUDdaGEWTmqJVoS != string("GFoJabAuTZVhMGKAKHQnPSxBxqXzfiiBbpDUKqPheCRoDstzvtKOEHIkIIGONruuUbePenBnCPKzHJXZXWUWLPOvqfabKXpFiJJRnTAUbXrvKvSmotqpDREdgTfmjFowZQQujwOnNDRhwVysMZqHcnMroIJZTzTAaVSEPqfssImvURpetlLODTsZPHvwHqsxRIgQxwdFRpwYSGUyuHVUfEyxmDCTFxPgVsPXfDpmmUCVO")) {
        for (int UPVfaYd = 964047079; UPVfaYd > 0; UPVfaYd--) {
            jCfzsggZGqhWIpC = ! jCfzsggZGqhWIpC;
            EzMfZgdQSDYxuLYm -= AVoSdsVybH;
            AVoSdsVybH -= EzMfZgdQSDYxuLYm;
            hgBwODhU += NDfHnsvKZFTiZiQM;
            xAUDdaGEWTmqJVoS = yEeBTW;
        }
    }

    for (int OYLjzA = 691600602; OYLjzA > 0; OYLjzA--) {
        NDfHnsvKZFTiZiQM += DJDTrAqTHGPi;
    }

    for (int kpDvRFskmvDREq = 130973564; kpDvRFskmvDREq > 0; kpDvRFskmvDREq--) {
        yEeBTW = DJDTrAqTHGPi;
        DJDTrAqTHGPi = yEeBTW;
        DJDTrAqTHGPi += xAUDdaGEWTmqJVoS;
        yEeBTW = hgBwODhU;
        hgBwODhU += xAUDdaGEWTmqJVoS;
    }

    if (yEeBTW >= string("MgQToCOEbRbNBtDAgtnngBBVqAGogcrQF")) {
        for (int epouopv = 443410796; epouopv > 0; epouopv--) {
            yEeBTW += xAUDdaGEWTmqJVoS;
            xAUDdaGEWTmqJVoS = hgBwODhU;
        }
    }

    return jCfzsggZGqhWIpC;
}

int gvZNpXwmdEkp::NvdPHGpeWaAeeoIe(string JNJIUNGaMltbleRa, int xMZjjilq, bool crINkDzWyxrJl)
{
    int zVoGHOlOtE = -1414476357;
    string tjsgmbAKoqdaijc = string("REOEXKnlEoKuYUXNNnuTHYlzWKsOplCIbwfgqHvsZtdyudYFzSbIyVHDcpFNQOjiwLOPtItbyWVyKLYUAYqzFrQNKLybbchEUUHkVUHy");
    string inCXKzKktMIs = string("ycSQpJwmIfLwdGhVDqskpsQwtsRpeKiEphqxJlPVETyx");

    for (int uxkziqWnGkCyr = 988309931; uxkziqWnGkCyr > 0; uxkziqWnGkCyr--) {
        tjsgmbAKoqdaijc += tjsgmbAKoqdaijc;
        crINkDzWyxrJl = crINkDzWyxrJl;
    }

    if (zVoGHOlOtE != 911113689) {
        for (int NeFjwq = 573593821; NeFjwq > 0; NeFjwq--) {
            crINkDzWyxrJl = ! crINkDzWyxrJl;
            zVoGHOlOtE /= zVoGHOlOtE;
            zVoGHOlOtE = xMZjjilq;
            crINkDzWyxrJl = crINkDzWyxrJl;
            tjsgmbAKoqdaijc = JNJIUNGaMltbleRa;
        }
    }

    for (int PfRuTMMX = 267076967; PfRuTMMX > 0; PfRuTMMX--) {
        tjsgmbAKoqdaijc += JNJIUNGaMltbleRa;
    }

    for (int ABufmqdKYDA = 1687542591; ABufmqdKYDA > 0; ABufmqdKYDA--) {
        inCXKzKktMIs = tjsgmbAKoqdaijc;
    }

    for (int XgPwNmGZW = 1464326365; XgPwNmGZW > 0; XgPwNmGZW--) {
        JNJIUNGaMltbleRa = JNJIUNGaMltbleRa;
        tjsgmbAKoqdaijc += inCXKzKktMIs;
        JNJIUNGaMltbleRa += tjsgmbAKoqdaijc;
    }

    for (int bskmTZlurmBveYA = 462700255; bskmTZlurmBveYA > 0; bskmTZlurmBveYA--) {
        tjsgmbAKoqdaijc = JNJIUNGaMltbleRa;
        tjsgmbAKoqdaijc = JNJIUNGaMltbleRa;
        tjsgmbAKoqdaijc += inCXKzKktMIs;
        tjsgmbAKoqdaijc = inCXKzKktMIs;
    }

    if (inCXKzKktMIs <= string("ycSQpJwmIfLwdGhVDqskpsQwtsRpeKiEphqxJlPVETyx")) {
        for (int uDfmKQUdykZxBjlr = 264431864; uDfmKQUdykZxBjlr > 0; uDfmKQUdykZxBjlr--) {
            JNJIUNGaMltbleRa += tjsgmbAKoqdaijc;
            crINkDzWyxrJl = crINkDzWyxrJl;
            zVoGHOlOtE /= zVoGHOlOtE;
        }
    }

    return zVoGHOlOtE;
}

string gvZNpXwmdEkp::gqXNWB(string krsBgUr)
{
    bool IpiJqxnblHNH = false;
    string HIqnxIkD = string("QpNRaHJquhdwTyhTdSXPpJriLlrfkqtxdKoSCcfwKLMHWJehrdQQbhIEpNRFdkmepRmmWPnnEiVkNJrGSJOnxSaQNGEzFDAqffdyjqFXBcYZwSeHSdVyOtAiaNnZIohNIwEPROFygRNsWvPhynEKRztsUteicNJqKemGqeOEXS");
    bool xxSgixyCJQuptjKO = true;
    double UdtGrGMF = 852612.984695971;
    bool wuXQBm = false;
    int rfouMCYCKuQWt = 1303274960;
    bool ydFtWcjtxflhbr = false;

    if (krsBgUr > string("QpNRaHJquhdwTyhTdSXPpJriLlrfkqtxdKoSCcfwKLMHWJehrdQQbhIEpNRFdkmepRmmWPnnEiVkNJrGSJOnxSaQNGEzFDAqffdyjqFXBcYZwSeHSdVyOtAiaNnZIohNIwEPROFygRNsWvPhynEKRztsUteicNJqKemGqeOEXS")) {
        for (int mBSnjXyYzwBi = 1433600670; mBSnjXyYzwBi > 0; mBSnjXyYzwBi--) {
            ydFtWcjtxflhbr = xxSgixyCJQuptjKO;
            ydFtWcjtxflhbr = ydFtWcjtxflhbr;
            ydFtWcjtxflhbr = IpiJqxnblHNH;
        }
    }

    for (int UpfgvNINPiUnp = 1331561999; UpfgvNINPiUnp > 0; UpfgvNINPiUnp--) {
        continue;
    }

    for (int bFKIxFrQBBsLMS = 483034659; bFKIxFrQBBsLMS > 0; bFKIxFrQBBsLMS--) {
        HIqnxIkD += krsBgUr;
        wuXQBm = ! wuXQBm;
    }

    return HIqnxIkD;
}

string gvZNpXwmdEkp::fLjZb(int DPGlTbSA, string cnhXvFU, double EZFVUbaTdIyanCM)
{
    int lbGfQlPNnyr = -317430027;
    double ODQUCKCI = -464889.6609266567;
    bool UrJVMnet = true;
    bool nkQYzk = false;
    bool DzYiBUmmK = true;
    string kaWfTSScpyIDVGm = string("KOjDkDbhdJNsnmdMbVAitHIaFWgieiDRNsaaWLvtAXGBQyQxCT");
    int xAkUqjPIyybmeC = -708093114;

    return kaWfTSScpyIDVGm;
}

double gvZNpXwmdEkp::mzaiZFoqAyKHEf(double eNaiU, int WFgcTvjMXCvgOtE, double GgNHs, bool CRVAqCGcdote, bool cNXTAQVfOAaw)
{
    int zeruMh = -1518779722;
    double KWSLBpAjz = -836695.0055294178;
    int AHLEINfRclzv = -1350756110;
    bool cEVCcTLvff = false;
    double bTWFY = 953200.7339121619;
    int UjzEECoalyaUPHFD = 134607265;

    if (AHLEINfRclzv != -1350756110) {
        for (int sjMXxOUO = 1288123726; sjMXxOUO > 0; sjMXxOUO--) {
            GgNHs -= KWSLBpAjz;
        }
    }

    for (int pglYAlacy = 223205684; pglYAlacy > 0; pglYAlacy--) {
        UjzEECoalyaUPHFD -= zeruMh;
    }

    for (int eUUKOgDKfBgdTR = 1249870547; eUUKOgDKfBgdTR > 0; eUUKOgDKfBgdTR--) {
        cNXTAQVfOAaw = CRVAqCGcdote;
        WFgcTvjMXCvgOtE += zeruMh;
        bTWFY += KWSLBpAjz;
    }

    for (int mQrFo = 1603105897; mQrFo > 0; mQrFo--) {
        continue;
    }

    for (int gxBLqDJHmryaMX = 2019549977; gxBLqDJHmryaMX > 0; gxBLqDJHmryaMX--) {
        zeruMh = AHLEINfRclzv;
    }

    return bTWFY;
}

double gvZNpXwmdEkp::VNNBeRqyMb(string csJxphhcTwInCMu)
{
    int uXPvyaRwqauASLk = 1425303037;
    string ytULhqsZywBJ = string("jQZCfjIhBCDdjdMfHMPAkuTAEIoMuCjzEyEackgCdMpXthucdlqxiIrDAjJLcKjnVZKWROhRpQWjBTnJQYoZrqmRoovWNxGIJFblAanArUcOaGtvJZSiwZEtTLhxQtQzNPFtCf");
    int dghXtGk = -1374088503;
    bool MTxBFhCmyoHD = false;

    return -322923.6087979987;
}

void gvZNpXwmdEkp::jAgWif(double KAyrM, bool XSmqgPdZdvfCoxK, bool nvyCLmxPOIXWIGU)
{
    string bvxXQSzYiTKaAAM = string("hFoadEuDAgwYQAulIaUhqssGREVGgqSwkwTmTqDCosAvsQSzugMslmOKNXCfBWZdDUjPlpXwAnlktdsbwmOXitUvNkxvtaSiBWsYYLQDvIxbXCWt");
    bool ErlxwsJ = false;
    bool NTdWjLyBsyWZJd = true;
    string pCaegiNvoQgd = string("RunZJeVCORWvVaUWjSRLCcEXdzcmNtEjOvUGkkgNrWMahpgXvivzQTsWvWcWeUWNUcspGanzDuSYDZrdXwDwSqLaKjBJazhSvbJtVbeEXElbhUzIdPouplgxJTqQGOtdRShyYjZdOsJwBFqyMLzIjxcFNINUyUvNkAnzJiQhEUubsmdMCMNyfyuJKGeKNKPlMBdXdpNGMrsYkxY");

    for (int sZXQYUSZEEnvsrS = 385814157; sZXQYUSZEEnvsrS > 0; sZXQYUSZEEnvsrS--) {
        XSmqgPdZdvfCoxK = ! ErlxwsJ;
        pCaegiNvoQgd += bvxXQSzYiTKaAAM;
        bvxXQSzYiTKaAAM += pCaegiNvoQgd;
        nvyCLmxPOIXWIGU = ErlxwsJ;
    }

    for (int VzfRQ = 670703435; VzfRQ > 0; VzfRQ--) {
        NTdWjLyBsyWZJd = ErlxwsJ;
        NTdWjLyBsyWZJd = ! nvyCLmxPOIXWIGU;
        NTdWjLyBsyWZJd = nvyCLmxPOIXWIGU;
        ErlxwsJ = ErlxwsJ;
    }

    for (int kzMyaDk = 1233476372; kzMyaDk > 0; kzMyaDk--) {
        XSmqgPdZdvfCoxK = ! ErlxwsJ;
        nvyCLmxPOIXWIGU = ! nvyCLmxPOIXWIGU;
        NTdWjLyBsyWZJd = ! nvyCLmxPOIXWIGU;
    }
}

int gvZNpXwmdEkp::WgPAhCDIjsG(string zpfWH, int ymisG, double BJpdlkENWvsA)
{
    int JRaty = 2115502714;
    bool dkFJkayYdSLtLtrL = true;
    int ZHzcmlJpRfjz = -1787595386;

    for (int DJhzTAobCUcnX = 1243933045; DJhzTAobCUcnX > 0; DJhzTAobCUcnX--) {
        ZHzcmlJpRfjz /= JRaty;
    }

    return ZHzcmlJpRfjz;
}

void gvZNpXwmdEkp::SbUsOcS(string zhAkIXRnHfL, string QogXvj)
{
    string Kemcssrs = string("YmfVOKjSMwAIQUPhrcJqpqJgLnbnUKLEWnbd");
    bool nZmKxNNAdyuR = true;
    int HNNhuignHbEL = -139008920;
    string oUZoXVGhhhmgUvj = string("YThykVzCLtNxnYReVnlsqNENUgAFvwEnrIaSxKQQzWmmGXKslkxdNRpwkpaTqCJYRbLHHaKmkvnyIOZjWkmUoSDxQtJQAYOjooVrENlaMuAVnbHZGIaJZKwhvSSXdnmxijxzusAjIJwcxAksFtTTJjErbYEPkXNImbKOyeqDuDOpdfKrQIgMJVTUmurNYdYlgEKhoBwYkBTqxumvgVgOfz");
    int zFkMFsAWJ = -1117960713;
    string vnGVqJatCISXKR = string("IaQvauLVqZErSSdjAiAZrtUiqPyhlJunuNbObNBPAzVSlOzpNDVBkORikoRpPyiYQZIvFSsadlOxZjhELMMUkmVfQiPguKLfFjtelwbUFxynAFSKJOTQKNEyCPylOiUyTuWvqKFuZZGeTlctxExpfLWVrhsZczvQuwYMYjeRiQMmYhxwkgavwWHPWyvOeGhqbjlAdnBBUfjADitcheiIzHjVkbdOMXJCjReTAwHTkmstYwHgbsdyOurSlKEm");
    bool RrGgdYXZfGFcWdm = true;

    for (int JAyvKwRwglO = 1350746498; JAyvKwRwglO > 0; JAyvKwRwglO--) {
        vnGVqJatCISXKR = oUZoXVGhhhmgUvj;
        Kemcssrs += QogXvj;
        zhAkIXRnHfL += Kemcssrs;
        vnGVqJatCISXKR += oUZoXVGhhhmgUvj;
    }

    for (int WEssbwosIadESgPJ = 2038803032; WEssbwosIadESgPJ > 0; WEssbwosIadESgPJ--) {
        nZmKxNNAdyuR = RrGgdYXZfGFcWdm;
        RrGgdYXZfGFcWdm = RrGgdYXZfGFcWdm;
        zhAkIXRnHfL = vnGVqJatCISXKR;
        zhAkIXRnHfL += zhAkIXRnHfL;
        vnGVqJatCISXKR += oUZoXVGhhhmgUvj;
    }

    for (int LNozLiwAQ = 547100163; LNozLiwAQ > 0; LNozLiwAQ--) {
        QogXvj = Kemcssrs;
        zhAkIXRnHfL += QogXvj;
    }
}

bool gvZNpXwmdEkp::LmFNL(double vTabjeA, bool tqVha, double dwGjUxpMaiA, bool sSxDroLIbON, string bJBwoFxcm)
{
    double HlNnLT = 175560.48891958853;
    string yJfuACQNXAnIlLU = string("IMxzAYlwCLwLxEZSutFhwTmzkeDJAZPXtymNxubnTGqFgAnTPefLgyOYJJPLSXOLBKYODqnqKQrWGjYyySuuVigcLQkCELHsOuRoTUFCojuKieqIdkUkQqjiubOJiEUDOwFzgcGfAHJdmBdOUcrpScGiUwcOclUvvFjQSGRnwHLgVteqSStNCGnWKDuZrUpKgAkdFnjUurwGsxnLmsgKxFkepcCOlAiwJkURvM");
    string rItUSaRNjh = string("WorCKNPPRSvkzxxCNFSKkibnhsuoRlzcxkVVwIhqOipUltCpJBtOfudJJjwmsYQTimIXRmX");

    for (int FPVHseuRTQ = 88236261; FPVHseuRTQ > 0; FPVHseuRTQ--) {
        HlNnLT = dwGjUxpMaiA;
        rItUSaRNjh = rItUSaRNjh;
        vTabjeA = vTabjeA;
    }

    for (int egNyHwfkKZYSXa = 55370923; egNyHwfkKZYSXa > 0; egNyHwfkKZYSXa--) {
        dwGjUxpMaiA += HlNnLT;
    }

    return sSxDroLIbON;
}

void gvZNpXwmdEkp::zTnaEtyEwR(bool OELsWwajA, int ZFUyBX, int RGRakP)
{
    int NHbZtE = -227879159;
    int ZXgtplL = -20362854;
    bool nmRCkzBjB = false;
    bool flqQohHvZME = true;

    if (RGRakP < -20362854) {
        for (int pAoPWh = 933353665; pAoPWh > 0; pAoPWh--) {
            flqQohHvZME = ! flqQohHvZME;
            OELsWwajA = flqQohHvZME;
            ZXgtplL += RGRakP;
        }
    }

    if (ZFUyBX > -1015001805) {
        for (int WXveBtTNnidgH = 36732642; WXveBtTNnidgH > 0; WXveBtTNnidgH--) {
            flqQohHvZME = flqQohHvZME;
            flqQohHvZME = ! flqQohHvZME;
            ZXgtplL = NHbZtE;
        }
    }

    for (int NPSksBtP = 706466766; NPSksBtP > 0; NPSksBtP--) {
        NHbZtE -= RGRakP;
    }

    for (int rNVLm = 639518763; rNVLm > 0; rNVLm--) {
        ZXgtplL /= NHbZtE;
        NHbZtE -= ZXgtplL;
        RGRakP = ZFUyBX;
        flqQohHvZME = nmRCkzBjB;
    }

    for (int yzlHNgWDJZE = 1468785625; yzlHNgWDJZE > 0; yzlHNgWDJZE--) {
        flqQohHvZME = ! OELsWwajA;
        ZFUyBX = ZXgtplL;
        ZXgtplL /= NHbZtE;
        NHbZtE *= ZXgtplL;
        flqQohHvZME = ! flqQohHvZME;
    }

    if (ZFUyBX >= -1015001805) {
        for (int quBDfLvGbGhYCp = 1083355192; quBDfLvGbGhYCp > 0; quBDfLvGbGhYCp--) {
            continue;
        }
    }
}

void gvZNpXwmdEkp::gdvGkLluZLaGgIXp(int JLblnLB, double fABXjjLDz, int TKdFPONQyngaOX, int IaPgCS, double rfvlxQ)
{
    double QyFxPjLY = -160664.41446716417;
    double KvfAqQqqkmhK = 235010.22672756162;
    int yEqtw = -1414000260;

    if (IaPgCS < 1894063309) {
        for (int gQEEC = 1508654593; gQEEC > 0; gQEEC--) {
            continue;
        }
    }

    if (KvfAqQqqkmhK < -160664.41446716417) {
        for (int yfoGixMGq = 1144543936; yfoGixMGq > 0; yfoGixMGq--) {
            QyFxPjLY = KvfAqQqqkmhK;
        }
    }
}

int gvZNpXwmdEkp::cmSkGc(int lzsJPpJxsMtjWjZR, bool wxTHDWYsDl, bool quQNlTUzd, double ICKtvziVAurLRj, int DnhUNtUH)
{
    bool bDbwKJwghlVqWuyM = false;
    bool MbxdA = false;
    double EfUIQ = 436630.4180698587;
    double GKANWGvv = 529516.5596271232;
    double QPHPcO = 433171.1967443324;
    bool ZdpOMUZ = false;

    for (int nEOyvSMvDtlBWW = 784518839; nEOyvSMvDtlBWW > 0; nEOyvSMvDtlBWW--) {
        ZdpOMUZ = ZdpOMUZ;
    }

    if (quQNlTUzd != false) {
        for (int xEFgxKsmOiRE = 200010640; xEFgxKsmOiRE > 0; xEFgxKsmOiRE--) {
            continue;
        }
    }

    for (int UeOgmbQkYUqnPdFq = 1000524464; UeOgmbQkYUqnPdFq > 0; UeOgmbQkYUqnPdFq--) {
        EfUIQ = GKANWGvv;
    }

    for (int qzxoaOsQ = 1467675871; qzxoaOsQ > 0; qzxoaOsQ--) {
        EfUIQ *= ICKtvziVAurLRj;
        MbxdA = ! MbxdA;
    }

    if (QPHPcO != 329909.0201302329) {
        for (int TSaTwbJbPSG = 38653992; TSaTwbJbPSG > 0; TSaTwbJbPSG--) {
            continue;
        }
    }

    return DnhUNtUH;
}

gvZNpXwmdEkp::gvZNpXwmdEkp()
{
    this->WGisPdewOlOmmbcf(false, string("wnuOYsBeZYhqhvqSsAQfYqtILVhyYG"), false, -420684.47962767014);
    this->IbEUvBecUStmixS(true, 1548503972, 327821.9957294217, 290184.8218671921, string("EIwkZCIdBAJPkzccJLYjwtcbKDjDtnQHiRzJQanGKkZjDnNMqbgTSpwxrjATeikBYJeNrUdzkRuqRKRRVIxoJJMHfNzpmNxoQlynQuJBonHwFRuqzfoyeUHgtoBaMMKRQTlzXpGeEXW"));
    this->ENXFTqWlDIMruHzc();
    this->OhGbafDcULmC();
    this->TCoTiqC(true);
    this->NvdPHGpeWaAeeoIe(string("btGEJgqQnpHzQTCnBTQqThBZeOJpQypOAbknXlpvAkpApsOdeoECQyNQYqmDCkBXfbqsfSYZCmkJUpBoyXIfSsnaGTVoRMjtewcdCPDSFcEOfkyeCUQRhkrmFTIYTsaOymuiEimDOjOUABfFVVpLdvPeDgMunXXsUPdoKcHaiCBDqVatXQ"), 911113689, false);
    this->gqXNWB(string("NeKXcfRpiAgcwCAaItxUXjQmxYPhlqndarDWwAoQXHgYtyMFAhwsXFroVVDrWxrdBzuJPpUBWxxRVYZBahqlhZWUbfByOKTZqSJiOYkeqobMYPgcRdwVlygmaymDJvXaustWOqDWgkGOPcvWQuvyYMrmNZoWDOSDoVKSnzYDEDfKtTIzffLVzvMMIyjibNuKHRkqxobagZZIFoGMBLD"));
    this->fLjZb(-1400121538, string("EaQtDqGtUZCmcezGoNfZUmMQSjDTLsiKKdqiqdDUKdYzCvFuAwidWDLLLQWYNnwHCrhjnpLTSNBEiKPmKeNBUyBDWVgyeLtKMDhOiyKbJ"), -1026968.9154984523);
    this->mzaiZFoqAyKHEf(-261518.63015271997, 664012823, -79642.95783551883, true, false);
    this->VNNBeRqyMb(string("XBRdtwdBPHenOnoyxaQw"));
    this->jAgWif(951158.5848655666, true, false);
    this->WgPAhCDIjsG(string("tIKLVOzcJSnJGUpmhCtSHEuKKaIC"), -530864333, 69448.08396589932);
    this->SbUsOcS(string("yVYFeSRvpRgbyhgDTcfAcDPBtxhAJbaqwhupEmHwEGzmfuffHLXzIcyhKkEaCsAFcgLJFqXcgAKDCIBNcMikdlvMONRqXTzdSkNILRMGqVuqXzTrJsBjMuWbqSxFFhIULtgfWqpaOtobtbxFMeRQnjNZskgWEcGXDQLZwyWhSksJkLnNCHxxloXReOkVJrbAGdeKnvzRxdgczLXvuJPqOf"), string("yHFsohPqVxaRrJCFevyaMGOzlTthsArSiaMtXtTWKGGnyrBPmtlZKVViwqpaGDmlmVaIaZFQdtjTEBkaWfPNopCXxXtNYRxEHvTxcoknDbZcPonYmHb"));
    this->LmFNL(-298325.61616283725, true, 429369.5294006023, false, string("SluaBrDPezMWQbCIYOgsRDQwlfTqBvzFfqDtxFxefdxsEOjuXabpvhfUYHAVsxjCoZzaACchAqotBUoZpmqGLkuCAFMdlNTWGNgxfcOKIXFqPnLjuwVMiNvCnZJgeEXLYEJCLZFfmfVONuCsWtzCQPPqhkjJIjdItOlQTNBfpUkaKHXxVsIRhbkbrTnvDcixcwYbUqWnvHppJsyNjIgMFwsuqtYuZSrhTWiPDpReCAUycEQgyP"));
    this->zTnaEtyEwR(true, -1865629368, -1015001805);
    this->gdvGkLluZLaGgIXp(1894063309, -944441.6775973055, -535167884, -2089988805, 185938.116419886);
    this->cmSkGc(-1119709227, false, true, 329909.0201302329, 776196922);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oORsgpGgqokrzEja
{
public:
    int veBbgKXMI;
    bool RQxQYvNstUcUQkLh;

    oORsgpGgqokrzEja();
    double YsWjjikmQb(int IOlXiVEETIiIhVn, double ZrjHxLUavQXIMZkl);
    void mzyDTgwpZyuKXMJ(int pkjjLUhB);
    double BaLBKyiLJT(double jzeNmEowC, double yzZTyKPFtGOR);
    void DRcDbzGfH(int BAKFcFRSGxJ, string FbUEzW, string tQseKxwHLtM, bool MDynP);
    bool uhwlunmDX(int JoCKHfkfWz, double pKHWBq, double IzeGgou);
    double XcNgukBJQsCQwVZ(double NvKZGigNttH);
    bool cHZJwCrr(int PsomQB);
protected:
    string hLrKlHQej;
    double KlzvX;
    bool lUflnqz;
    double zrJdU;
    string WJMdxiHZHwR;

private:
    string tQLLFncI;
    bool KqtwQq;
    double IVGwXJopJfsYpc;
    double jRNaHsHBlX;

    double lxDWTJgRUVCA(double OmKzWD, bool rbHGO, string JcBMtAnhuxbG);
    bool oVmYQhxEJU(double RkqFb, int EYmgjppJ, int OUgiPkZTZvYnzib, int vSkDoJCE, double VKskl);
};

double oORsgpGgqokrzEja::YsWjjikmQb(int IOlXiVEETIiIhVn, double ZrjHxLUavQXIMZkl)
{
    bool XQwblkSqDumLCLv = true;
    bool wKXLceQFCuKwUw = false;
    int sTDcxiOMjg = 5757579;
    double NgawgW = -622795.8366668904;
    string XLFyrHod = string("sVIDSIMKGCqiVtSPbNrWKJhzEuDeyLCOHJVdgYyTjVAxYRFWPXIGulHDDOSLQekmbUBzfLsFbQRHDpqssUXTYwNgMJWlXzGoBcVvuWMmNuHONfvJuvWSadlWrmLjtIQesAxTAURgDcadQjDIDRLsFgztALPMzEVLzoAkTEGbhOBqvWESuXblbYKASbdHOirBxXTynZztZkEHmdTRwIWJvRR");

    for (int kjzuNKTky = 905567445; kjzuNKTky > 0; kjzuNKTky--) {
        continue;
    }

    return NgawgW;
}

void oORsgpGgqokrzEja::mzyDTgwpZyuKXMJ(int pkjjLUhB)
{
    string szJFKaccIQzqXBco = string("rktZemHIqinRfPvGAVIxykHdepIuVdMWzlfOMMofSWbynJJSUUUpTuuALPQwwxplROzKYprJWpnemWTaoaYjGSrpFfjvNjWYClYTbEHbuFnIFot");
    bool VkczWEgDrlRsk = true;
    double fkiOt = 25883.819668905384;
    int sXHZz = -738073684;
    double RCHHaWUSqog = -396319.47619086574;
    double CjWJvfqzcMy = 87272.45581733919;

    if (szJFKaccIQzqXBco > string("rktZemHIqinRfPvGAVIxykHdepIuVdMWzlfOMMofSWbynJJSUUUpTuuALPQwwxplROzKYprJWpnemWTaoaYjGSrpFfjvNjWYClYTbEHbuFnIFot")) {
        for (int ecSvShpLLZ = 379991635; ecSvShpLLZ > 0; ecSvShpLLZ--) {
            sXHZz /= sXHZz;
        }
    }

    if (RCHHaWUSqog != 87272.45581733919) {
        for (int QUFhCPiAGxGb = 190930815; QUFhCPiAGxGb > 0; QUFhCPiAGxGb--) {
            VkczWEgDrlRsk = ! VkczWEgDrlRsk;
            CjWJvfqzcMy -= RCHHaWUSqog;
        }
    }

    for (int FydOCaLEd = 191820095; FydOCaLEd > 0; FydOCaLEd--) {
        continue;
    }

    if (pkjjLUhB == -738073684) {
        for (int SdAlAlVsRLp = 1278684026; SdAlAlVsRLp > 0; SdAlAlVsRLp--) {
            sXHZz *= pkjjLUhB;
        }
    }
}

double oORsgpGgqokrzEja::BaLBKyiLJT(double jzeNmEowC, double yzZTyKPFtGOR)
{
    int VqOZmKjZxPTdH = -1844658646;
    bool YDoAEx = true;
    bool DNDHNLsTMhSRh = false;
    double gtBcFwTnC = -673847.5548381208;
    string NgKrUv = string("nAVEwZtbVPFBLdbhNIBYQbsNjpjebXhXQhwlEpbCjMZeUOmMEHBVKJZuHYrrMdQUefqnZoYlQicAemTyIGnszMPPetKxQcoqrERLftAzgAEaMSZeWrUrCnQfdLqZIdcvDFKUtgLnWlLNxNNIyRgeRzITaePhzfjtIcfeRLnaYivxXCctBLVwKhWLRJriUYHqjYVMSf");

    for (int TdoHDhxRcTXatk = 1125609695; TdoHDhxRcTXatk > 0; TdoHDhxRcTXatk--) {
        YDoAEx = DNDHNLsTMhSRh;
    }

    if (NgKrUv <= string("nAVEwZtbVPFBLdbhNIBYQbsNjpjebXhXQhwlEpbCjMZeUOmMEHBVKJZuHYrrMdQUefqnZoYlQicAemTyIGnszMPPetKxQcoqrERLftAzgAEaMSZeWrUrCnQfdLqZIdcvDFKUtgLnWlLNxNNIyRgeRzITaePhzfjtIcfeRLnaYivxXCctBLVwKhWLRJriUYHqjYVMSf")) {
        for (int vALSy = 744383503; vALSy > 0; vALSy--) {
            YDoAEx = DNDHNLsTMhSRh;
        }
    }

    if (jzeNmEowC >= -673847.5548381208) {
        for (int laPQFhEXGO = 1612342747; laPQFhEXGO > 0; laPQFhEXGO--) {
            gtBcFwTnC *= gtBcFwTnC;
        }
    }

    return gtBcFwTnC;
}

void oORsgpGgqokrzEja::DRcDbzGfH(int BAKFcFRSGxJ, string FbUEzW, string tQseKxwHLtM, bool MDynP)
{
    int FRWARwkUNznBHBLo = 1246967196;
    bool PgcArmTDTxFKM = false;
    double gsEwubXTDD = 378475.40484071587;
    string nsXzOkaYwDfTt = string("ZpmBnPqrDbSVksAMXomUiUZhpYUygReVAVYcsmpVhNKIroaOOqTaQtraoKBvuUlWWupctpZYOiriIsaRMOvF");
    string IQUiZt = string("XXuTNlROnGzkmXLEEJiXAqFUhTUpNrbJeXlxyLwAvgwRNiHOuoeTRaaupnWdnnZVdWUxJMynrZBrtGuagFQyYbTWjppnEBeYtqlrPaXCYNSsBBUoEpZkTsFmfiBJkKI");
    double SzIMYaeMCXIrbAO = 968888.5318853927;
    bool DAJcr = true;
    int MwqIsG = 879182257;
    double AsdsadhpIvwR = 513903.6461312153;

    for (int KAYOiFwWzc = 1638334036; KAYOiFwWzc > 0; KAYOiFwWzc--) {
        FbUEzW += tQseKxwHLtM;
    }

    for (int smBputTCPfvZVTK = 48947716; smBputTCPfvZVTK > 0; smBputTCPfvZVTK--) {
        DAJcr = ! MDynP;
    }

    for (int tABbcqfev = 2030268099; tABbcqfev > 0; tABbcqfev--) {
        DAJcr = MDynP;
    }
}

bool oORsgpGgqokrzEja::uhwlunmDX(int JoCKHfkfWz, double pKHWBq, double IzeGgou)
{
    int gZEtAFbJaMN = 1638525245;
    double GGidDnydmFLVRYcG = -4123.644968212738;
    string lDkzFWJncYCTg = string("KBcQXRrplvEzjtonzNZJRAxdbipyZufqfiodxaBGQ");
    bool RJATxV = true;
    int iLCnViJoNyMWd = 748893670;

    for (int VGDhSEOh = 408099662; VGDhSEOh > 0; VGDhSEOh--) {
        JoCKHfkfWz += JoCKHfkfWz;
        IzeGgou /= GGidDnydmFLVRYcG;
    }

    for (int udUvsNllk = 336793337; udUvsNllk > 0; udUvsNllk--) {
        GGidDnydmFLVRYcG += GGidDnydmFLVRYcG;
    }

    for (int phypiitqWNyho = 964544320; phypiitqWNyho > 0; phypiitqWNyho--) {
        GGidDnydmFLVRYcG -= pKHWBq;
        gZEtAFbJaMN += JoCKHfkfWz;
        IzeGgou -= pKHWBq;
        pKHWBq = IzeGgou;
    }

    for (int bIQCp = 136626672; bIQCp > 0; bIQCp--) {
        pKHWBq += GGidDnydmFLVRYcG;
        iLCnViJoNyMWd = JoCKHfkfWz;
        IzeGgou /= GGidDnydmFLVRYcG;
        JoCKHfkfWz -= gZEtAFbJaMN;
    }

    for (int aPtIEgLr = 431309039; aPtIEgLr > 0; aPtIEgLr--) {
        IzeGgou = pKHWBq;
        IzeGgou += pKHWBq;
        lDkzFWJncYCTg += lDkzFWJncYCTg;
    }

    for (int JjinFKpZwPciL = 1558764102; JjinFKpZwPciL > 0; JjinFKpZwPciL--) {
        iLCnViJoNyMWd /= JoCKHfkfWz;
        IzeGgou -= IzeGgou;
    }

    return RJATxV;
}

double oORsgpGgqokrzEja::XcNgukBJQsCQwVZ(double NvKZGigNttH)
{
    int QpHBeOt = -78052989;
    string RtjNT = string("vECrfSwbcpJlYrfAkQvRdpFjQyUFvJuumWmHZUfHxnulDsqwUeQrWudisSsFJKgmZ");
    bool QZvvgWNv = true;
    double RxrjrPVwCYY = -568733.5801206214;

    if (RxrjrPVwCYY <= 9942.04883172207) {
        for (int lujtbp = 1827144993; lujtbp > 0; lujtbp--) {
            NvKZGigNttH *= NvKZGigNttH;
        }
    }

    for (int qfdDzV = 1059288511; qfdDzV > 0; qfdDzV--) {
        RxrjrPVwCYY = NvKZGigNttH;
    }

    return RxrjrPVwCYY;
}

bool oORsgpGgqokrzEja::cHZJwCrr(int PsomQB)
{
    double MRHckG = -247093.999543851;
    double GnOjCyX = 21991.50004456708;
    int soPnprEArt = -1029526411;
    string RlutvoTMJwb = string("KplmMyVCEdLvRYLqWMdRXZpvMeb");
    bool gqPEoExwnUjNq = true;

    if (PsomQB == -1029526411) {
        for (int QxqlGsLfjlAYBngw = 1737330425; QxqlGsLfjlAYBngw > 0; QxqlGsLfjlAYBngw--) {
            continue;
        }
    }

    return gqPEoExwnUjNq;
}

double oORsgpGgqokrzEja::lxDWTJgRUVCA(double OmKzWD, bool rbHGO, string JcBMtAnhuxbG)
{
    int jMLaWtrj = -1704702418;
    int IRYqR = 1595175003;
    int XvJbdugDwpcnzp = 318729260;
    int bzfPjNnztcJCid = 291371319;
    bool LegPxdoQWKv = false;
    double vmKdOlyRnPTv = 222748.8611265679;
    string NliPKEyvoGMBDZ = string("TxkMtlQVtpoPXzBUyrCWxNuTUVbeNAMnkyppcvlLbhPiaecJKbuhpDvKWwVQHBDshLRyQAqPWuwVacHQTUboxTRfspKbjnuTmCZBzkceBkBdZmulPbCMisHNjGovPlEDpqWZeVqtphKQDoV");
    bool bgqsvvmSkpPAPQI = false;

    if (IRYqR > 1595175003) {
        for (int loVRsycQHQZMUrW = 1277040147; loVRsycQHQZMUrW > 0; loVRsycQHQZMUrW--) {
            XvJbdugDwpcnzp += bzfPjNnztcJCid;
            vmKdOlyRnPTv += vmKdOlyRnPTv;
        }
    }

    for (int GhfUSzqUlMPT = 106375971; GhfUSzqUlMPT > 0; GhfUSzqUlMPT--) {
        IRYqR += bzfPjNnztcJCid;
    }

    if (vmKdOlyRnPTv < 222748.8611265679) {
        for (int EfNkBkJGoMGS = 1000669602; EfNkBkJGoMGS > 0; EfNkBkJGoMGS--) {
            continue;
        }
    }

    for (int xkeABbJRpBbDn = 1367437062; xkeABbJRpBbDn > 0; xkeABbJRpBbDn--) {
        XvJbdugDwpcnzp -= XvJbdugDwpcnzp;
    }

    for (int zBJNdqvfQ = 2035822126; zBJNdqvfQ > 0; zBJNdqvfQ--) {
        jMLaWtrj = IRYqR;
        bgqsvvmSkpPAPQI = ! LegPxdoQWKv;
    }

    return vmKdOlyRnPTv;
}

bool oORsgpGgqokrzEja::oVmYQhxEJU(double RkqFb, int EYmgjppJ, int OUgiPkZTZvYnzib, int vSkDoJCE, double VKskl)
{
    int ZTlwPRE = -343246446;
    bool yOvAEsE = true;
    bool NXAgFcUl = false;
    string SJVHxiqXE = string("sKHEjVMFgrgpiocsCfQsBkeQjbdtNBPxdpVPdrqUTnAvKoqoXgaWIkHiJXZyASXOEDwEAeVdVPsjvcRIessZPmTXIwgvKxXzOqeYBBBrApDbovEZaTfjbkqN");

    return NXAgFcUl;
}

oORsgpGgqokrzEja::oORsgpGgqokrzEja()
{
    this->YsWjjikmQb(-1641496753, 755395.4153058401);
    this->mzyDTgwpZyuKXMJ(1565964133);
    this->BaLBKyiLJT(-215487.77240314725, 863789.5850268459);
    this->DRcDbzGfH(-1860258748, string("nVSkBsMEflrsySIfquwuVvZGEptUyajXdsBoUPkGbTlwDGBoLzAiBKZuXebQVEmaCYXefOcjOxONiVkgUTEbPfgxUgdPjYylfEJQTGmQWWWAZ"), string("cGQuuaiywgHrmwWQJxCvvUEKoHQrRcLLdzKdmPSGZtaHtrozSFBkDaZWwLAwyjkJjjWHxrQORHhCUwjnTYGJYRVJlNZnBeqQwBLOKKcpiKdWFSJrKTqvisWTljRnncPZlvMvLByyPseqlAHPVXoGxqPmBKspNQCmNOLOzsVbTbXWrReacCtuKvgIgxLKCQcAyNzVSCuPKzkJBYIvkplTyMnvMzDjQzaGSfZHYpIXDZOIvAenoaKkTSUB"), true);
    this->uhwlunmDX(-2087216732, -113211.2206022832, 943447.4864984829);
    this->XcNgukBJQsCQwVZ(9942.04883172207);
    this->cHZJwCrr(-1852381350);
    this->lxDWTJgRUVCA(-605217.0845226871, false, string("jLFgvtrcdGr"));
    this->oVmYQhxEJU(-166597.3182393765, -95253991, -574812385, 1564939177, 551354.899686759);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ERqgDBvlLoZQe
{
public:
    double exPZHeJ;
    double MaXuUcElRSH;
    string WpeZxZUY;
    bool mOEnDEdXOLlzJCxF;
    double fZjdEfU;
    double ISiWyPoIxrahxEo;

    ERqgDBvlLoZQe();
    double PDyYMWOnKRtBDXFx(string pXuGqPemS, int ohvyWWMkihQlB, bool PhJXvNJsvru, int ZbzTmHZRsPpEDv, string ASgLpiaKjomoh);
    string TYitHHjNvswIEHxf(string VzxjqAq, int jNmoUezruWI);
    bool XqaajmnOAvOiJ(bool YQOPpgeyCnbszo);
    string dCcLoTAIs();
    string JNciM(string tPhzwRDWaFHF, double UEzAgdjsEc);
    void ZgDJDFdSzQI(bool Qxhhn, int YFIwbwFO, double pnbIuKMrCTFleQV);
protected:
    double YqGlTCI;
    int gSZxnJqPojkTWb;
    string bgLBmduL;
    double MYOnZbkhj;
    string ZlVtptlB;
    int hvSOq;

    double eSTZEOy(int NaewrVYc);
private:
    int QPVwSQOMYDrhMN;
    bool SkKMxG;
    string eHCEPMsqfSzSC;
    bool HtqDQi;
    bool YHqtGrFqbh;
    int HKJIeQAbNlcT;

    void aPxUkJFvhr(bool wGhxeeFP, int emhspZZ);
    double pnDGLqakvzPT(int kaSYLOOtYEeqFtwX);
    string YTXVhapJATlTJWmA(int KowEKSMAQliXq, string CKueBkbaVAV, int MLmSHywMOToGaKn);
    string gWkgtrcLrmlj(bool QrEPQMYE, int XAWUSGTGPQQcXa, double zSiGfDMgFH, bool ZGYmRkA);
    int xCjjEa(double ATvLRlbehq, double phqsCOfiKknYSwLb, double nTyUOSsDRJqaNoe, string nBNBakZkzjoMOlY);
    string szYCY(double mmwytCyfmR);
    double VqbnumlZJsDPJD(double jpYqe, double BmqNBvLUUUH, double qJCEKUEDtT);
};

double ERqgDBvlLoZQe::PDyYMWOnKRtBDXFx(string pXuGqPemS, int ohvyWWMkihQlB, bool PhJXvNJsvru, int ZbzTmHZRsPpEDv, string ASgLpiaKjomoh)
{
    int XMYMrz = 20258986;
    int TFLyJpdOq = -1887105900;
    double WWkemFyLPJaPI = -209986.41897534343;
    int CxEivpWgBVzH = 880637747;
    int iDtuUoEtF = 474631711;
    bool mTmjgWzVrhGXkc = false;

    for (int yxyMFXsCEipzPM = 2113143199; yxyMFXsCEipzPM > 0; yxyMFXsCEipzPM--) {
        continue;
    }

    for (int wBsMupsbJvu = 1267138588; wBsMupsbJvu > 0; wBsMupsbJvu--) {
        ZbzTmHZRsPpEDv = ZbzTmHZRsPpEDv;
        CxEivpWgBVzH += iDtuUoEtF;
    }

    if (CxEivpWgBVzH > 20258986) {
        for (int csxxvcgYvU = 481734665; csxxvcgYvU > 0; csxxvcgYvU--) {
            TFLyJpdOq *= ZbzTmHZRsPpEDv;
            TFLyJpdOq += CxEivpWgBVzH;
        }
    }

    return WWkemFyLPJaPI;
}

string ERqgDBvlLoZQe::TYitHHjNvswIEHxf(string VzxjqAq, int jNmoUezruWI)
{
    bool VNgcfTCf = false;
    bool OGFrRvxTfZGjjSuZ = true;
    bool TCAjMouEHLMk = false;
    double JZuNrPljm = 660955.6815797476;
    string xfQbfqqHBzADB = string("kIdyZnucOcTdcVAGHQMGOKhphfRnTOuQSbLhdwlemsniRaYUOaFAdAdOmYFgCILIkfGxMkjdYGmgHqPsFyjPPfrxuBugRkKZFSMnZsNaXrciOMmproXyCbcrNfYAitiywif");
    int stXgSBwZlzZ = 1388119957;
    double vVdutTMs = -10109.102631098383;
    double CVamiuqqjVVBtoJ = 103222.62072558443;
    int DzWfYjt = -1027000399;
    double VtbEBi = 295672.78705652937;

    if (stXgSBwZlzZ == -224441945) {
        for (int zVRHE = 1211644687; zVRHE > 0; zVRHE--) {
            DzWfYjt *= DzWfYjt;
            CVamiuqqjVVBtoJ += VtbEBi;
        }
    }

    return xfQbfqqHBzADB;
}

bool ERqgDBvlLoZQe::XqaajmnOAvOiJ(bool YQOPpgeyCnbszo)
{
    string yWoSPEsDez = string("ColfpLfvxOaHdxomDquaADdJS");
    bool IDZQjXqUlUOh = false;
    string ZnBHsgfReziBdWX = string("hmFkblEvIwIvVGgSQBEUaHROsvttrlksMpGAEgOQMfjcMElSvYHbOSpaQSdUPguQIDuwaqzRfLRBtYAeZTWQDhMOIAojSucFJFGOfnEKdGBipZMhSwixYdMVDSEcXONRCplYDwengjaZyNcJ");
    string CWZdutJDSdfqbQrV = string("tCuxkOdUQyADepfkSoVb");
    double IBuZin = 173991.55740523667;

    if (ZnBHsgfReziBdWX <= string("tCuxkOdUQyADepfkSoVb")) {
        for (int dAQEP = 539313421; dAQEP > 0; dAQEP--) {
            ZnBHsgfReziBdWX = yWoSPEsDez;
            YQOPpgeyCnbszo = YQOPpgeyCnbszo;
        }
    }

    for (int wkdArkXBpAa = 734398782; wkdArkXBpAa > 0; wkdArkXBpAa--) {
        ZnBHsgfReziBdWX = yWoSPEsDez;
    }

    if (ZnBHsgfReziBdWX != string("tCuxkOdUQyADepfkSoVb")) {
        for (int DdZWbeUkXAeVp = 1170848393; DdZWbeUkXAeVp > 0; DdZWbeUkXAeVp--) {
            continue;
        }
    }

    for (int coolmXVKVFDzkb = 21206350; coolmXVKVFDzkb > 0; coolmXVKVFDzkb--) {
        CWZdutJDSdfqbQrV += yWoSPEsDez;
        YQOPpgeyCnbszo = ! IDZQjXqUlUOh;
    }

    if (YQOPpgeyCnbszo == false) {
        for (int RJZmI = 1473477139; RJZmI > 0; RJZmI--) {
            yWoSPEsDez = ZnBHsgfReziBdWX;
        }
    }

    return IDZQjXqUlUOh;
}

string ERqgDBvlLoZQe::dCcLoTAIs()
{
    int ITpdrBzUG = -1839317895;
    bool BzpAJrpeDRhYD = false;
    double rLSWmorgxj = -1046897.4140010072;
    double uiiZrqXSVFyE = 576124.9185521663;
    string dIqHz = string("HwEdthhjHKtvXcdnRTCOisLZzsQllIvVlHTDpoZDJUjWburqiTFTwVFBtYqBjzTRJTKVIUDvKYQQdBvJIxclZTFEjYdWAhIdJ");
    int oUAKfkIWRg = 1381753447;
    int VFJLYNxnJw = 407096352;
    string bWNGGtvxMjvmmDzg = string("sCwaljjfgfeRmndgpVrueLuGtFHXpqVNuwDjeMoSWqqHJIyuQfoOJUaVkhswdDDeULyjpwUXNxByvilMdptuoEPQmbxtOwiYdttAbDhvUJfKaphEfxoOvTiAKthoKgOnsSzIHAQeJnXFaAatXklMmsLyMpYiviq");
    double tPOjRImEvWDuXtNG = -1002998.4705698855;
    int qqRVgsgnbgIgUevY = -1839935536;

    for (int eaMWDwUKhKrecX = 1288324826; eaMWDwUKhKrecX > 0; eaMWDwUKhKrecX--) {
        VFJLYNxnJw += oUAKfkIWRg;
        ITpdrBzUG += qqRVgsgnbgIgUevY;
    }

    for (int xEUuPMfrA = 685972298; xEUuPMfrA > 0; xEUuPMfrA--) {
        oUAKfkIWRg = ITpdrBzUG;
        bWNGGtvxMjvmmDzg += bWNGGtvxMjvmmDzg;
    }

    for (int IZFxTs = 2067941943; IZFxTs > 0; IZFxTs--) {
        bWNGGtvxMjvmmDzg += dIqHz;
    }

    for (int alxdzCIiyt = 1516866837; alxdzCIiyt > 0; alxdzCIiyt--) {
        qqRVgsgnbgIgUevY *= ITpdrBzUG;
        rLSWmorgxj = tPOjRImEvWDuXtNG;
        qqRVgsgnbgIgUevY = qqRVgsgnbgIgUevY;
    }

    if (ITpdrBzUG >= 407096352) {
        for (int PsuigbauZm = 113927017; PsuigbauZm > 0; PsuigbauZm--) {
            qqRVgsgnbgIgUevY /= VFJLYNxnJw;
            qqRVgsgnbgIgUevY *= VFJLYNxnJw;
        }
    }

    return bWNGGtvxMjvmmDzg;
}

string ERqgDBvlLoZQe::JNciM(string tPhzwRDWaFHF, double UEzAgdjsEc)
{
    string aZFAjqibNr = string("DUARQZXPHfVRRaFCphiiqhwSPlGSUPXAyjUEHmDTrFHfUllPTIvXJLZRjmzbUmmoDtwESXkWHoGMWkuAloCPyPsIiJZWUzKwtgfnCcdmbbEbivoBLwSKGGIzsmOEMzDJJyVtQAVubBcPjNWZvpLplUarMDAGuhyXSZPOggI");
    string ryiVCDHijPQx = string("qFkRQBHiFIFWhykfFSnJvdlNyDeRSfQWZUekWenBrBdJhdrCAovGRRcrSiJVOIyrppQurcbIyRypZJgIgaDfYQBfMYjNYmFSRRdGzEnzjJsobAmgOUFvOCIyKIexbuGeGFMKBneQrOyzPkvMngoXiermfTaIihUHQIxHjytrKlzozjptWxcwdsxpEhrcIkHmJEhHapgCOPUNRVztnWDaxRqXKnEuQQqBH");
    string uMZSQvFHX = string("mvHJydruEuGsMGKIwFQudMSYKoshBHvGWKuOwmHYcKCLPREyfkdmIqhekcKBOQpWFstIvclCACSXrBfnhGSuQftdPwoBRSMwcdCbNWyooCuniQhjVMjDbEVxS");

    if (tPhzwRDWaFHF < string("LwHZgriFXXAAkDpkJpHiPPoHYcUvqBnOpsZcDyiNLTwVNcldQDHgbHgxNWOpzOZVIsHgT")) {
        for (int xHeYr = 583633819; xHeYr > 0; xHeYr--) {
            ryiVCDHijPQx = tPhzwRDWaFHF;
        }
    }

    if (UEzAgdjsEc > -209133.5329023774) {
        for (int zMslsTSuRXYKwmh = 752895009; zMslsTSuRXYKwmh > 0; zMslsTSuRXYKwmh--) {
            tPhzwRDWaFHF = ryiVCDHijPQx;
            ryiVCDHijPQx += ryiVCDHijPQx;
        }
    }

    if (tPhzwRDWaFHF == string("DUARQZXPHfVRRaFCphiiqhwSPlGSUPXAyjUEHmDTrFHfUllPTIvXJLZRjmzbUmmoDtwESXkWHoGMWkuAloCPyPsIiJZWUzKwtgfnCcdmbbEbivoBLwSKGGIzsmOEMzDJJyVtQAVubBcPjNWZvpLplUarMDAGuhyXSZPOggI")) {
        for (int aewwj = 1193078230; aewwj > 0; aewwj--) {
            ryiVCDHijPQx = tPhzwRDWaFHF;
            tPhzwRDWaFHF += ryiVCDHijPQx;
            ryiVCDHijPQx = uMZSQvFHX;
        }
    }

    if (tPhzwRDWaFHF > string("mvHJydruEuGsMGKIwFQudMSYKoshBHvGWKuOwmHYcKCLPREyfkdmIqhekcKBOQpWFstIvclCACSXrBfnhGSuQftdPwoBRSMwcdCbNWyooCuniQhjVMjDbEVxS")) {
        for (int nBMrPOtyQVGO = 1598935229; nBMrPOtyQVGO > 0; nBMrPOtyQVGO--) {
            aZFAjqibNr = aZFAjqibNr;
            ryiVCDHijPQx += aZFAjqibNr;
            tPhzwRDWaFHF += aZFAjqibNr;
            aZFAjqibNr = tPhzwRDWaFHF;
            UEzAgdjsEc += UEzAgdjsEc;
            aZFAjqibNr = ryiVCDHijPQx;
        }
    }

    if (uMZSQvFHX > string("mvHJydruEuGsMGKIwFQudMSYKoshBHvGWKuOwmHYcKCLPREyfkdmIqhekcKBOQpWFstIvclCACSXrBfnhGSuQftdPwoBRSMwcdCbNWyooCuniQhjVMjDbEVxS")) {
        for (int ExhohQ = 1851267573; ExhohQ > 0; ExhohQ--) {
            ryiVCDHijPQx += aZFAjqibNr;
            UEzAgdjsEc /= UEzAgdjsEc;
            uMZSQvFHX = uMZSQvFHX;
            uMZSQvFHX += uMZSQvFHX;
            uMZSQvFHX += tPhzwRDWaFHF;
        }
    }

    return uMZSQvFHX;
}

void ERqgDBvlLoZQe::ZgDJDFdSzQI(bool Qxhhn, int YFIwbwFO, double pnbIuKMrCTFleQV)
{
    bool VVwGqk = true;
    double oBdwGL = -405112.2261365418;
    int nmRHoxqx = -1880374244;
    string mnqfCOr = string("saSTmdScFcWWHwAczapbTpSJjrqPORqSIdsoIVxNAFbzKxoKopqprRdRrOzbkeejEYoJuTxnQY");
    string enMchZsPtPn = string("GqCdNtdpeyzIzEHxDagtDTBHbZuSykCYWCDrMzCxXVZldYzZDJZdbGPEsfkUulLqXpfgIFZIAnGtLIXwUNgfgGmeLNNswEPCoJinmQOFmZboGtNomwjMBOfSpxRXbDFA");

    if (oBdwGL < 112871.42935502235) {
        for (int LYZZphp = 597772219; LYZZphp > 0; LYZZphp--) {
            oBdwGL -= oBdwGL;
        }
    }

    for (int zHtWoLUbwRobuM = 77055856; zHtWoLUbwRobuM > 0; zHtWoLUbwRobuM--) {
        YFIwbwFO *= nmRHoxqx;
    }

    for (int PepRgTkuqlrR = 192113362; PepRgTkuqlrR > 0; PepRgTkuqlrR--) {
        pnbIuKMrCTFleQV -= oBdwGL;
    }
}

double ERqgDBvlLoZQe::eSTZEOy(int NaewrVYc)
{
    bool RPtXDKVXXh = true;
    bool CQVbpJUP = false;
    string LMnQQYHDk = string("CVyTwKIdRzVhLAolmQiTcwsKZefKHiNxrfZnIstNcGgmPDpKoZzoEWihnWlzYHIgBPvrtuCtKvwPfgwgVcCZeAxtwehaktvflegnUsItcUEcbMjadJBGiOcBQADbILZHwavdhhgBmWmsIhBBbZHjQNOhcANcLXuTXPyQjCWYLdndYuyEaIbZOFk");
    double JvoOrNnl = 397178.64487083326;
    double MEKCwUOONuF = 920806.4562180227;
    int vERjRq = -22185764;

    for (int cnqlJDjCegRYs = 1554148673; cnqlJDjCegRYs > 0; cnqlJDjCegRYs--) {
        MEKCwUOONuF -= MEKCwUOONuF;
    }

    for (int UiHAGzvke = 1269951456; UiHAGzvke > 0; UiHAGzvke--) {
        vERjRq += NaewrVYc;
        RPtXDKVXXh = RPtXDKVXXh;
    }

    for (int mHDLCnLxcSNf = 1104532787; mHDLCnLxcSNf > 0; mHDLCnLxcSNf--) {
        CQVbpJUP = ! RPtXDKVXXh;
        MEKCwUOONuF *= MEKCwUOONuF;
    }

    return MEKCwUOONuF;
}

void ERqgDBvlLoZQe::aPxUkJFvhr(bool wGhxeeFP, int emhspZZ)
{
    string tHmIufaqqh = string("qDjmHNqCVkykIswOFtmCfeIigmcPfOQwKaWFiuiRneaijXtmjAELACAwqslXRfbuwJKOQzUhWVjKZFrSQkxFiLtetvLGbXLiSHRFivvbqtnxTliGJWiCfTUPHJSRziYmlprshKexLABDXguftAwlmULVJyVQjEthFCfLNHTmsvGyLNZBqjYPH");
    double wquAwlsUr = 416299.99249086616;
    double LjaaCbEWVWB = 205308.40100813273;
    bool HgiJSIXtePS = false;
    double zviYHjkdFrqZQ = 381963.5014999699;
    double HnBPEt = -259516.25826285352;
    string WYUXIcGtAdfs = string("MmfLiuNdMlKlkyAOBYWPcyvdimNueygulByHjznmToylWbqNMrUjyuKEvoqTyOfDCoKyfBXERXLTmZedoycM");
    bool AdOJtqXCIvLpEBw = false;

    for (int clXkjgnak = 99211824; clXkjgnak > 0; clXkjgnak--) {
        HgiJSIXtePS = ! HgiJSIXtePS;
    }

    for (int pTYYeO = 1109280371; pTYYeO > 0; pTYYeO--) {
        wquAwlsUr += zviYHjkdFrqZQ;
        wGhxeeFP = AdOJtqXCIvLpEBw;
        wquAwlsUr /= wquAwlsUr;
        emhspZZ -= emhspZZ;
        HgiJSIXtePS = ! HgiJSIXtePS;
    }

    if (zviYHjkdFrqZQ == 205308.40100813273) {
        for (int tgdFxGyD = 899020570; tgdFxGyD > 0; tgdFxGyD--) {
            wquAwlsUr = LjaaCbEWVWB;
            HnBPEt -= LjaaCbEWVWB;
        }
    }
}

double ERqgDBvlLoZQe::pnDGLqakvzPT(int kaSYLOOtYEeqFtwX)
{
    double UpWZLSGbXWYoCMmD = -21945.222987316552;
    double tSrOblyCjPKdDv = 44080.895168773524;
    string rIstBiekdM = string("cchrCaCKFNrMaaIvzxHEBgFtrKmEPFDwNHuPFAUwASMETVspGytLCeQdVWrOSriPMYOGzQEuUXJRUJTHbrHwSrurjKkKNajwOoiVHEjgifSRzGbDddYVpQqbQzRZgJGQcwbcxlbVCJPOYBfmeegHlafWMCsgHpiFFICAyugWWXNLziqfKOYwxpPOZmRrlrNMARyuPGtHncjJQMHXlIfcAFsYmBPYqtmVfmErgjMixkxfkWtfRk");
    double qwuIPptEHPxRzp = -82460.89307115588;
    double YZyMLrEw = 392583.9717655063;
    int XIMGUwul = -1912453257;
    int xIMnoGGo = -1123737575;
    bool aPcioVI = false;
    bool KtJqbgVZD = true;
    double XwvjWPW = -97465.37135711563;

    if (YZyMLrEw <= -21945.222987316552) {
        for (int LTKmHWb = 1057928477; LTKmHWb > 0; LTKmHWb--) {
            kaSYLOOtYEeqFtwX /= xIMnoGGo;
            YZyMLrEw *= XwvjWPW;
        }
    }

    for (int yoWlacjOe = 826681067; yoWlacjOe > 0; yoWlacjOe--) {
        XwvjWPW = UpWZLSGbXWYoCMmD;
        qwuIPptEHPxRzp = qwuIPptEHPxRzp;
    }

    for (int fSupfYy = 880757736; fSupfYy > 0; fSupfYy--) {
        UpWZLSGbXWYoCMmD = UpWZLSGbXWYoCMmD;
    }

    return XwvjWPW;
}

string ERqgDBvlLoZQe::YTXVhapJATlTJWmA(int KowEKSMAQliXq, string CKueBkbaVAV, int MLmSHywMOToGaKn)
{
    int yztquDZNrisS = 1301302845;

    for (int WFiZd = 597437298; WFiZd > 0; WFiZd--) {
        yztquDZNrisS += yztquDZNrisS;
        MLmSHywMOToGaKn *= yztquDZNrisS;
        KowEKSMAQliXq *= yztquDZNrisS;
    }

    for (int WvJIfvfsdwcb = 216816789; WvJIfvfsdwcb > 0; WvJIfvfsdwcb--) {
        MLmSHywMOToGaKn /= KowEKSMAQliXq;
        CKueBkbaVAV = CKueBkbaVAV;
        MLmSHywMOToGaKn *= MLmSHywMOToGaKn;
        yztquDZNrisS = KowEKSMAQliXq;
        yztquDZNrisS /= MLmSHywMOToGaKn;
        KowEKSMAQliXq /= yztquDZNrisS;
        KowEKSMAQliXq = KowEKSMAQliXq;
    }

    if (KowEKSMAQliXq > 1301302845) {
        for (int GGZFerASm = 719381550; GGZFerASm > 0; GGZFerASm--) {
            KowEKSMAQliXq *= yztquDZNrisS;
        }
    }

    if (yztquDZNrisS < 1301302845) {
        for (int jYetrUOe = 697168009; jYetrUOe > 0; jYetrUOe--) {
            KowEKSMAQliXq = KowEKSMAQliXq;
            yztquDZNrisS = MLmSHywMOToGaKn;
            yztquDZNrisS = MLmSHywMOToGaKn;
            MLmSHywMOToGaKn -= yztquDZNrisS;
        }
    }

    return CKueBkbaVAV;
}

string ERqgDBvlLoZQe::gWkgtrcLrmlj(bool QrEPQMYE, int XAWUSGTGPQQcXa, double zSiGfDMgFH, bool ZGYmRkA)
{
    double KPlSvWCyULmUCR = -940547.7755463781;
    string iruoqsiRKeAxiogP = string("caTCadrujaJxHHDKqnSFqAdmmiBrbcGlLvrQYutDqHfWkbwcTlrkzdTguuTqwSDKSAsLGMetrYtLDshLsaBNkemdCNYXNmsdqSBNnAcDQumNzyZcaIHCcmZmzWDInMloMdtrwccvuqHbVipETpwFpJqGXDrPateHEMqCL");

    for (int XyJzUjCeY = 167781169; XyJzUjCeY > 0; XyJzUjCeY--) {
        KPlSvWCyULmUCR -= zSiGfDMgFH;
        QrEPQMYE = ! QrEPQMYE;
    }

    for (int shNTMLeXKb = 2034799264; shNTMLeXKb > 0; shNTMLeXKb--) {
        XAWUSGTGPQQcXa += XAWUSGTGPQQcXa;
        QrEPQMYE = ! QrEPQMYE;
        iruoqsiRKeAxiogP += iruoqsiRKeAxiogP;
    }

    for (int dolRuAsaZJqU = 1150214415; dolRuAsaZJqU > 0; dolRuAsaZJqU--) {
        QrEPQMYE = ! ZGYmRkA;
    }

    if (zSiGfDMgFH != -940547.7755463781) {
        for (int yGagw = 547302139; yGagw > 0; yGagw--) {
            XAWUSGTGPQQcXa /= XAWUSGTGPQQcXa;
        }
    }

    return iruoqsiRKeAxiogP;
}

int ERqgDBvlLoZQe::xCjjEa(double ATvLRlbehq, double phqsCOfiKknYSwLb, double nTyUOSsDRJqaNoe, string nBNBakZkzjoMOlY)
{
    int nFKwJsjdtqfV = -1046684396;
    int qUQDgBQCgTRS = -735435508;
    int rpmetp = 622911200;

    for (int xgLFzunDGk = 777339658; xgLFzunDGk > 0; xgLFzunDGk--) {
        nFKwJsjdtqfV -= rpmetp;
        nFKwJsjdtqfV *= nFKwJsjdtqfV;
        nFKwJsjdtqfV += rpmetp;
    }

    for (int orxffRFPU = 341643530; orxffRFPU > 0; orxffRFPU--) {
        rpmetp += nFKwJsjdtqfV;
    }

    for (int uIqMlC = 1898729838; uIqMlC > 0; uIqMlC--) {
        rpmetp *= qUQDgBQCgTRS;
    }

    if (nTyUOSsDRJqaNoe <= 370163.66416723747) {
        for (int szXzGX = 1355408892; szXzGX > 0; szXzGX--) {
            nTyUOSsDRJqaNoe = ATvLRlbehq;
        }
    }

    for (int tmWMYlhCueeTwW = 119430261; tmWMYlhCueeTwW > 0; tmWMYlhCueeTwW--) {
        qUQDgBQCgTRS /= qUQDgBQCgTRS;
        nTyUOSsDRJqaNoe = ATvLRlbehq;
        qUQDgBQCgTRS *= qUQDgBQCgTRS;
        nTyUOSsDRJqaNoe = phqsCOfiKknYSwLb;
    }

    return rpmetp;
}

string ERqgDBvlLoZQe::szYCY(double mmwytCyfmR)
{
    bool mMOuSNxrnI = true;
    double drSHdSpREUHmEqMu = 676771.0992112992;

    return string("RYlpkNJewtFMyXhscqpJTYZAAaKTFQDHUbvoaJQMYlIqvQObBliShuoiNNkEVXdBRxuFijekqoHAqviXtxtJGMAKUKkJKxRFNBGEkaJgXMZoAMrllqUINDpwMhbTOtYmWscoNKqbDYfudoCoTTavQbsTizAfZospFccRBBpIIINVETOuvrPCvLdwtHdcLVYiJSufPonORXHuWUqyCDdspzWAtciXbNuhpPSuDxeJHNqynLZLEkLgcOZQa");
}

double ERqgDBvlLoZQe::VqbnumlZJsDPJD(double jpYqe, double BmqNBvLUUUH, double qJCEKUEDtT)
{
    string RcAkrZARwg = string("NkWKNlHzbtdZXUWPuTLNWTZQvRzWdtXrpAtuNVxKgBfKtaROjsjAOhVjgJHxBDGbTjuybHshrnCyWTWEAohkFZZUeioWyoXCFoByIpUUNTbwiEGHOKeVgDkcXiBDzozKVaQtRNaVJoxPEDIrsYYcXsyLlhFjjWnBpMuwBojTFMSrXAFyyvpjfgdciyIsxKzGVshnlgKgvOcflQeLwlNhtWUNnw");
    bool UxGzPbPzufK = false;
    string ZstoJdcKOGTithO = string("AFWnLBJsnwNXyPrngdmnlKywvijZmKvfedsqBlZiHqUDBjFZDeqqljlOUVjhczzTTKOqHVDKaauNDmKhoSZMrRadwiAWxCFgVPRfLHHfJjLYtyeqeUxvCzpGVeCvUfOQVFBEReBnxvJvNUkQhLRnLnmlsfYgvDzyVaIieAjCaktkwNxhlKJvfmhoeOUYGvDnMndXHXrNhWohMgVaIJFkMrovQFQHURRNOoNjDh");
    int eVwDX = 1058757736;
    double gSNJhtkvkpOMp = -596827.8535734157;
    string XNuue = string("qqJNmLYkNyugHjRKkxWpvxMHmOiaXZNCSdtHtHDXZpztBjZKmwkqYiAyRkMdyPAlEXJzUmOVddGkYRoXHlrfbRvgkPQsqRQOCzokejALEsPafAaNwYaTJaFBlXDQpvAKeWdapdWKkDHFzbFwKLNXECUgzYiUYGPCNajGFeRQWrAGMUZRtXFQGicjqOROqmznDNnBkJrKyjxaUyrINs");
    bool ppjmqtGhYFJYIuo = true;
    double ZCBLVPd = -677351.6528359294;

    for (int TSFqioW = 1753264586; TSFqioW > 0; TSFqioW--) {
        ZstoJdcKOGTithO = XNuue;
    }

    if (gSNJhtkvkpOMp <= -762791.5852338764) {
        for (int KWCUuBfeWT = 1365666577; KWCUuBfeWT > 0; KWCUuBfeWT--) {
            XNuue += XNuue;
        }
    }

    for (int LVtZeZCqQRPfBO = 838371385; LVtZeZCqQRPfBO > 0; LVtZeZCqQRPfBO--) {
        UxGzPbPzufK = UxGzPbPzufK;
        ppjmqtGhYFJYIuo = UxGzPbPzufK;
        jpYqe += jpYqe;
    }

    return ZCBLVPd;
}

ERqgDBvlLoZQe::ERqgDBvlLoZQe()
{
    this->PDyYMWOnKRtBDXFx(string("HueuTUohDlkGdAXPmiJWZLJZyhLjOJgHBorKsVmFbhZArmFJKctRYeglkCXSsSvETngOKGCOWVxyENlDeOAALCkGONxokBfxfNYTfAeojFxsScREAtpQnLBubmzoCWXJFkGKGPnraUDAAnwDiumevtyyRDCmkLSBxIXKZjuWPFnCZHrwJJojHEnNDMHGNBinKVNbbyybqKLGldMrsIscjHWKUCFlnZgZObt"), 1840522521, true, -850548011, string("zphrZFldmrhBeimDGHnN"));
    this->TYitHHjNvswIEHxf(string("YPwldySdyIqwOnjzvbLpcqQpJDAbKPpDJdmQGCT"), -224441945);
    this->XqaajmnOAvOiJ(false);
    this->dCcLoTAIs();
    this->JNciM(string("LwHZgriFXXAAkDpkJpHiPPoHYcUvqBnOpsZcDyiNLTwVNcldQDHgbHgxNWOpzOZVIsHgT"), -209133.5329023774);
    this->ZgDJDFdSzQI(true, -465752438, 112871.42935502235);
    this->eSTZEOy(2121480960);
    this->aPxUkJFvhr(false, 120137223);
    this->pnDGLqakvzPT(1213174668);
    this->YTXVhapJATlTJWmA(-376207201, string("sDuZqdsdAOQxGraKYvRYxPtmaDAOIwhasSBVbevBXSLNDZwQURpjHKJLXmZzNCLNWTQsSVDRAOFutCfDolGMOlhytSifRuFUkuEmoAWMlHcssSNWYoKtIpHIWtRakJjcpHVjXKKECLrNVobQmhlbxVNpSgYJxBqnqUvltutoCGWQOOnUKmmBvzgtfWvS"), 1376072945);
    this->gWkgtrcLrmlj(true, 1559302225, -742078.1799679685, true);
    this->xCjjEa(-271794.97186843335, 544171.0800830984, 370163.66416723747, string("twdijglSzLWRwHCdWwrMUXyanOVcGhIXFqQyJturQxaGjUVaIDzVzKgYfpwFuXYpOwfQBGwBcHgtEUZEvcQOzKnupqgdlYiSkHnDjLlDYxuiAsublRUoaCxOeHepBjyxNUvBdfQexZtXlxIyuGqRYggaGIHBJxZlpCvKdLfySBZsyfAQxjUawffb"));
    this->szYCY(216021.67587592572);
    this->VqbnumlZJsDPJD(-770933.4008739924, -762791.5852338764, 159177.7807940868);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xHsKNO
{
public:
    double dnMZUkxva;
    int nkaCyzRECYJzpGh;

    xHsKNO();
    bool XkHcoyW(int EYEBlZfNY, double tHAdtdC, string GaIyEhzdjXGLf, double LjBOBXmLVHK);
    bool gcmZbrCS();
    string AAZbtHpTWvbiyXEi(int BQEDQOKLbV, string YKPeqzZ, int vuRzBpTzlaYoj);
    double dVCEDRNGjV(string DhuQcdKyD, double CWqfT, int zvlcGNCT, int JVrKQs);
    void MGioGtcQ(string tbHVmqjIrCl, string QLyOWDBJObNy, double PJvDGvhzent, bool MONiusL);
    void AWnYkvvUOpLpNtBJ(bool lHYgUmRRpRzNP, bool pQGWF, bool xwvGMZrTsria, bool WdKzuCNtI, bool pWPTsbbkZSwmPJe);
    void pfQjTijfUC(bool gnZlvx, int HYIgtBdXeAIBzBEn);
    bool zDfIbRgxgJipUwv(int YjjIrlb, bool KHgRvIprkguZH, int USfTpYa, bool IaVrgYkYsJGWo, int oUZhd);
protected:
    int sbPJBfzxeQzTSvg;
    string eWtgIhgIxIw;
    double jWjLG;
    double oliYNAnrTkLaPRk;
    double xgVUauuqN;
    string hNbsIbwDkgWHlQ;

    int IkoMzulrAYqxbo(string MmPyrvivzelkYksM, double jkRUXJyRSJqFhM, bool JQommmvqZ, int wcgSKB);
private:
    bool stMWXquvLtJ;
    string uqpVbqBFURwZaI;
    string azqBjSmdg;
    bool mRiUYnPZMPy;
    string VxTBWY;
    bool sIeiXKvIIaXKJpjx;

    int enfeFlOunlKZ(double rkQKtRrNqX, string DbsNNNAKhnVv, string vdMSVWMCSbiRJ);
    double STHKCZhHN(int ssBMdLVHtFSrUKy, bool jqvwzpQOttKjGb, double ZrKBXMDBDCp, bool zCLgWgKsS);
    double IuTyzEGnv(string WnZhVOHE, double dKXmyGJPrSLsl, double eRJTdWHjhh);
    int piIJocSqCjy(int cuLbaxoZEtdQp);
    int qrGHXdpMjH(string DMBbO, string HtCLHi, double szUlsiinvsqbs, bool cGKnneBmhzkNyiyy, int eYKukuoQtnECgX);
    string klIcXbJZupx(int EOXJoVUbW, int iKbcEKuWstknFH);
};

bool xHsKNO::XkHcoyW(int EYEBlZfNY, double tHAdtdC, string GaIyEhzdjXGLf, double LjBOBXmLVHK)
{
    double pHkrDjYhQuDlAiD = -801149.6682641138;
    bool VfioNLBoC = true;
    int hPqceKgH = -1233474592;
    string FKqKfYJhBl = string("GxjlZFmnJAOZDUdYPxCqooqVRCrTqJMeQMtfMSPAeZMHMviCNzZoPGueoxKNJYtwwHWttsBJwOxOrBQDfqJiahwZoJnNkUYmMCQBIktQoYBdYgXAQuEOljICytcvXDWsFImlqGvGWzUhkjmjSkVAYIohvmutxDQSUFKZKJmeeQrGaXkTksqfgutUdVMiSlnoLhtMulbtklXkRxJcAFHJMcLIEE");
    int cSSbrkM = 1120622295;
    string aVqBkopBDyQK = string("nOoQhHVvEKgnrBYWmlubinSTIqhPyyVLhwAjpCvNNYRiNzvKHYhrSMYYFadpObrZqCjloLXLDhRbuCUomPPEcTpCRajAYULFoWfWXYUSftXMIaMMBQKKNhvRzHPLKkJXTDJKQlMTNJIrBqQMBbbXiMhmkQeGnuLLyybsNcAthholYHlIXrVWgpXRGyOVMVNeNqieDKOhprTDRiNsgFvWKd");

    for (int PQRTarHsWEKNc = 1002623163; PQRTarHsWEKNc > 0; PQRTarHsWEKNc--) {
        aVqBkopBDyQK = FKqKfYJhBl;
    }

    for (int lxtRzLfqsWk = 961386871; lxtRzLfqsWk > 0; lxtRzLfqsWk--) {
        GaIyEhzdjXGLf += aVqBkopBDyQK;
    }

    if (tHAdtdC >= 241407.84963798986) {
        for (int CqBYTStMYWnl = 1007819584; CqBYTStMYWnl > 0; CqBYTStMYWnl--) {
            tHAdtdC /= LjBOBXmLVHK;
        }
    }

    for (int BFZMaRaILMC = 659218666; BFZMaRaILMC > 0; BFZMaRaILMC--) {
        aVqBkopBDyQK += FKqKfYJhBl;
    }

    for (int FKBmJzvqwVbYhs = 1996897917; FKBmJzvqwVbYhs > 0; FKBmJzvqwVbYhs--) {
        pHkrDjYhQuDlAiD /= tHAdtdC;
        FKqKfYJhBl = GaIyEhzdjXGLf;
        EYEBlZfNY = EYEBlZfNY;
    }

    return VfioNLBoC;
}

bool xHsKNO::gcmZbrCS()
{
    bool saoVZheVQK = false;
    int TkjaoSbGyMSuzju = 132779346;
    string wldApRWCOa = string("hZYDJACPHDqQLIZevPPXZjsdImrzpiKIZZesXyZxatypLHeCBcdivWHVWiIfMvKrPZeuWEAHrbBVllGIPztKGtPDohvFdcFeXcdkLjCYuoOAloFbgdBCX");
    string XikchFWb = string("XpXRZLlzwLHlEDozYPjPRAteyhwKpsPetvslSTeIzVONDseIPLHDPOMbGHQfYGhcuKSYzIfitzYHaUjClXbPetxMhljFXUrCcxoosQMfaIZcDPHFKOTOkRklIAvEWsqmeWqvrZBqnNGwCVGBYaWSTUKwoBiUzzigXQChAiTjOscAk");
    int DzosNcdHNpfZFs = -752072942;
    bool WtOYWnprWdLWF = false;
    bool pGSycgR = false;
    string mpmTkTHvgEd = string("nMqXHNHHLYJNfdBWBQWdIpXWKlQhJUUsvkPyviNbRYByoQEHXMiyZeNlvZLELiSevtGYfATgwXaSiwdPGwSctQYVhXxCwKMVxKOeFkozJIDJYysTlIrYGWhJtDDxCbwGQdxgAvSPFhqaFmRwTzlXpFQOdOFJGkgUXjBYGmrOGwBRAfwQwxexAkuKJTlujECuaikbPDNe");
    double xQQJvezFGevYx = -363257.8112729403;

    for (int zQGEwIajJUTxnK = 1044525279; zQGEwIajJUTxnK > 0; zQGEwIajJUTxnK--) {
        continue;
    }

    for (int sLHLjxienCypEY = 1664694363; sLHLjxienCypEY > 0; sLHLjxienCypEY--) {
        continue;
    }

    for (int gdxfytv = 852475870; gdxfytv > 0; gdxfytv--) {
        continue;
    }

    for (int LgACMxzbYwcxsbL = 1566920800; LgACMxzbYwcxsbL > 0; LgACMxzbYwcxsbL--) {
        DzosNcdHNpfZFs /= DzosNcdHNpfZFs;
    }

    return pGSycgR;
}

string xHsKNO::AAZbtHpTWvbiyXEi(int BQEDQOKLbV, string YKPeqzZ, int vuRzBpTzlaYoj)
{
    int WXgFmjG = -581617288;
    int HiPTN = 661259902;
    double ufgLRJLjny = -952219.346560029;

    if (BQEDQOKLbV != 661259902) {
        for (int jLvOqWlUevLXs = 453337980; jLvOqWlUevLXs > 0; jLvOqWlUevLXs--) {
            continue;
        }
    }

    if (vuRzBpTzlaYoj >= -581617288) {
        for (int BeGtEhwhAWezwZm = 829873477; BeGtEhwhAWezwZm > 0; BeGtEhwhAWezwZm--) {
            vuRzBpTzlaYoj -= WXgFmjG;
            WXgFmjG /= vuRzBpTzlaYoj;
        }
    }

    for (int QLEBauEjNsKtMR = 1792319276; QLEBauEjNsKtMR > 0; QLEBauEjNsKtMR--) {
        HiPTN /= BQEDQOKLbV;
        HiPTN = WXgFmjG;
    }

    return YKPeqzZ;
}

double xHsKNO::dVCEDRNGjV(string DhuQcdKyD, double CWqfT, int zvlcGNCT, int JVrKQs)
{
    string yzPOl = string("SUaTBhIMnapbVnGSLAiH");

    for (int DlQXelfFifdTz = 595892398; DlQXelfFifdTz > 0; DlQXelfFifdTz--) {
        JVrKQs = JVrKQs;
        CWqfT *= CWqfT;
        yzPOl = yzPOl;
    }

    if (DhuQcdKyD == string("DsbiRWAgnOfXHnQKqmcetjzniYYPobLhIJQtZdkoMjNLocJegBwsrUuCxbaMfsEsBFsgdAYyXEDUBkToEXRXKrrWxtXgXWwlUHwQFyqmNJGfgFVqeILvHzUJuBadHsZjJLoscfVtPyLmQNPwvPVSrNTOmMKLnbgwBUmFggDcUNOsyIrDpACknlhMB")) {
        for (int ykENEIcWGzPwbRng = 897519746; ykENEIcWGzPwbRng > 0; ykENEIcWGzPwbRng--) {
            yzPOl = DhuQcdKyD;
            JVrKQs /= JVrKQs;
            JVrKQs *= JVrKQs;
        }
    }

    for (int ZtjltpmzzkIhH = 565657928; ZtjltpmzzkIhH > 0; ZtjltpmzzkIhH--) {
        CWqfT -= CWqfT;
    }

    for (int toGvod = 1767246670; toGvod > 0; toGvod--) {
        DhuQcdKyD = DhuQcdKyD;
        zvlcGNCT += JVrKQs;
        zvlcGNCT = JVrKQs;
        zvlcGNCT += JVrKQs;
    }

    for (int UidWrAul = 1654835441; UidWrAul > 0; UidWrAul--) {
        continue;
    }

    for (int noOpZDo = 1517568842; noOpZDo > 0; noOpZDo--) {
        yzPOl += yzPOl;
        zvlcGNCT += JVrKQs;
        JVrKQs *= zvlcGNCT;
    }

    for (int rZTOr = 104571456; rZTOr > 0; rZTOr--) {
        DhuQcdKyD += yzPOl;
        CWqfT /= CWqfT;
    }

    if (yzPOl <= string("SUaTBhIMnapbVnGSLAiH")) {
        for (int CzNsviJcUU = 1562918599; CzNsviJcUU > 0; CzNsviJcUU--) {
            continue;
        }
    }

    return CWqfT;
}

void xHsKNO::MGioGtcQ(string tbHVmqjIrCl, string QLyOWDBJObNy, double PJvDGvhzent, bool MONiusL)
{
    string mfXXkeZqzkwECBz = string("vbLAJyehETnKyNhKuGBmOaRRwBeMOTgnupkcDwkJxTUFDRqATEWmCmhVtNWatXMXOtDJHkRTgyayiKKkAcl");
    string uSLFGWCZNy = string("mFAJcrsiyAifhhZDcRZcVEKryQizennNIqgDylGaoFeRcLUUFDVQaGBTNOOJgdUpROQWBWeKYpZyGEVXldRAaEowWJEyyReOiRjXepDJglABBncFLMMCHTsDFtKhkvWIgfoKohRaNgdVlgkMenUtBdGMtsVBlyzgnixNLBEQLkHmkyRKsVfUNjthfh");
    int SPpWjIk = -126914995;
    double XXYOfVT = 733472.8567257213;
    int MqIsmN = -1398856614;
    string zUSAHCStTwbZ = string("pvemHQsujhGeWzXTaeFufTWkwjRRaTFiIDGuTCzyesMuDWhycigVrXbHfTDktuENpumZoJzGgwwJKDqrodrTNbCTqQCbtOccyVgHYOOpaQfanazeO");

    for (int NVetg = 85676076; NVetg > 0; NVetg--) {
        uSLFGWCZNy += zUSAHCStTwbZ;
    }

    for (int ZMUpWeHsDCQRGDz = 882074593; ZMUpWeHsDCQRGDz > 0; ZMUpWeHsDCQRGDz--) {
        uSLFGWCZNy += uSLFGWCZNy;
        mfXXkeZqzkwECBz = uSLFGWCZNy;
    }

    for (int nvuRlmupHmXKb = 1903638329; nvuRlmupHmXKb > 0; nvuRlmupHmXKb--) {
        zUSAHCStTwbZ += tbHVmqjIrCl;
        SPpWjIk *= MqIsmN;
        QLyOWDBJObNy = uSLFGWCZNy;
    }

    if (zUSAHCStTwbZ > string("QvRFfXYYdqLnLFqVqwzNxUauGfvbCZcbgUUqSihpabSmcUgHJSToBoI")) {
        for (int rlGGneHTsvFw = 1364923396; rlGGneHTsvFw > 0; rlGGneHTsvFw--) {
            MONiusL = MONiusL;
            mfXXkeZqzkwECBz += zUSAHCStTwbZ;
        }
    }

    for (int vZOpTKNIgnlJzq = 81801817; vZOpTKNIgnlJzq > 0; vZOpTKNIgnlJzq--) {
        mfXXkeZqzkwECBz += zUSAHCStTwbZ;
        uSLFGWCZNy = uSLFGWCZNy;
    }
}

void xHsKNO::AWnYkvvUOpLpNtBJ(bool lHYgUmRRpRzNP, bool pQGWF, bool xwvGMZrTsria, bool WdKzuCNtI, bool pWPTsbbkZSwmPJe)
{
    bool fHOlPuqiI = true;
}

void xHsKNO::pfQjTijfUC(bool gnZlvx, int HYIgtBdXeAIBzBEn)
{
    bool zzeehtmtzxhfMch = false;
    bool rqetA = false;
    string WdDTqZwEsyjUar = string("SrBGAhlwUwrSvkSpIPUApEbBzyMlDGCffQroQlwnFbEtpFnKDIVJppPokgydOYgmdZsDtrqMQIhEfjZXPhOdVSBnpDeehKGjaZbxQbYicoilBFVLLkUlJxvjDmFUELXsOlWgmhOioJvVTUUfALfZJSCShFBwDXtaIVUibtMXIiFZpPGPbXsPFQYVMCvZxcjbFhP");
    bool DoHnKMFTEFU = true;

    if (HYIgtBdXeAIBzBEn < -2133846761) {
        for (int LNdWQMCqdjhQT = 1086279227; LNdWQMCqdjhQT > 0; LNdWQMCqdjhQT--) {
            DoHnKMFTEFU = rqetA;
            rqetA = zzeehtmtzxhfMch;
        }
    }

    if (zzeehtmtzxhfMch == false) {
        for (int SxZoO = 525253986; SxZoO > 0; SxZoO--) {
            continue;
        }
    }
}

bool xHsKNO::zDfIbRgxgJipUwv(int YjjIrlb, bool KHgRvIprkguZH, int USfTpYa, bool IaVrgYkYsJGWo, int oUZhd)
{
    string NuttjGnKKbTK = string("nqcRkXFbBQQmjXFDJNMIzRUmvkzpFjOUWspZSsmtFBObzzgUiQqVJZWxGmpvJKRAwNtYTMOzRMQhKBPdtLaPpPdj");
    bool WvPlgYFFEUGBWhPJ = false;
    bool ylvsjYDvecTKmBI = true;
    int teBBmt = -862730703;

    for (int skLcFzTBllvwX = 1721761218; skLcFzTBllvwX > 0; skLcFzTBllvwX--) {
        ylvsjYDvecTKmBI = WvPlgYFFEUGBWhPJ;
        IaVrgYkYsJGWo = IaVrgYkYsJGWo;
        USfTpYa *= teBBmt;
        USfTpYa -= teBBmt;
    }

    for (int kSmkFlhJNqiYs = 263656503; kSmkFlhJNqiYs > 0; kSmkFlhJNqiYs--) {
        IaVrgYkYsJGWo = ! WvPlgYFFEUGBWhPJ;
        KHgRvIprkguZH = ! KHgRvIprkguZH;
        oUZhd = oUZhd;
        IaVrgYkYsJGWo = ! KHgRvIprkguZH;
    }

    for (int vDmcBE = 1054380037; vDmcBE > 0; vDmcBE--) {
        USfTpYa = oUZhd;
        ylvsjYDvecTKmBI = ylvsjYDvecTKmBI;
        YjjIrlb = YjjIrlb;
    }

    if (ylvsjYDvecTKmBI == false) {
        for (int egWaQymNAmCFsFQQ = 608267049; egWaQymNAmCFsFQQ > 0; egWaQymNAmCFsFQQ--) {
            YjjIrlb += teBBmt;
        }
    }

    for (int JOgnKlWiOZ = 1001978094; JOgnKlWiOZ > 0; JOgnKlWiOZ--) {
        KHgRvIprkguZH = ! WvPlgYFFEUGBWhPJ;
    }

    return ylvsjYDvecTKmBI;
}

int xHsKNO::IkoMzulrAYqxbo(string MmPyrvivzelkYksM, double jkRUXJyRSJqFhM, bool JQommmvqZ, int wcgSKB)
{
    string ymWoGxKku = string("wzUbdxKrTgmtSLMJAYKXRyrTytrEFXLmGkEgqKhihYiiFVkGeYnspxOIaGyXEJbxHIAYTZMDzoLZNDFMEoSbzkvySRbelSuJVCOWIwdjprtZSbEhJDSbsfFyRjMGjCRYfgXLfyLplAyVaqBNuaVWRBpmwLySdbPvMeHbuJBXEZHWEhGCzKaVDDDhsgOgeJbvgRcapEjhIlowrRvUMpNQyGbgLFpnyzOWbghZjToJmOHlrKRUnQInzqyjAc");
    bool WurlIhMoQBXS = true;
    int jBLWGINuolGhN = 623314816;
    int wUmBaEQulh = -771895092;
    string OgPWlJKEkGLtHvx = string("fVmlbAJgwyYZNDYKuoHxOQtTAwnFLwHsJMMTeiTDf");
    double VIJQLe = 293036.19749027974;

    for (int FLrEO = 305626780; FLrEO > 0; FLrEO--) {
        OgPWlJKEkGLtHvx = OgPWlJKEkGLtHvx;
        ymWoGxKku += OgPWlJKEkGLtHvx;
    }

    if (ymWoGxKku == string("zMqaUcYZNqyMWvdqaWnylEnYfffatRbEHTFZHTLQYvfqZkwKrJcEuqXEEdpUnwtwChEfFikhObOAmYuZZQhjwAKDHDPWelCFnVtAfQqfAoLDCSVNYFyuMtjYmQQPdlXjAdjqkcIVEyEsqiZBi")) {
        for (int JvYIEO = 900640727; JvYIEO > 0; JvYIEO--) {
            ymWoGxKku += OgPWlJKEkGLtHvx;
        }
    }

    if (jkRUXJyRSJqFhM > -867775.8340938537) {
        for (int EgXKfBE = 1254995516; EgXKfBE > 0; EgXKfBE--) {
            OgPWlJKEkGLtHvx += OgPWlJKEkGLtHvx;
            jkRUXJyRSJqFhM += jkRUXJyRSJqFhM;
        }
    }

    for (int VqozhDYlwV = 454770159; VqozhDYlwV > 0; VqozhDYlwV--) {
        OgPWlJKEkGLtHvx += ymWoGxKku;
        MmPyrvivzelkYksM += OgPWlJKEkGLtHvx;
        JQommmvqZ = ! JQommmvqZ;
    }

    if (wUmBaEQulh <= -771895092) {
        for (int GouPMQORuJDt = 1111614605; GouPMQORuJDt > 0; GouPMQORuJDt--) {
            JQommmvqZ = ! JQommmvqZ;
        }
    }

    for (int wbTNAzSnqajJxylJ = 1999818177; wbTNAzSnqajJxylJ > 0; wbTNAzSnqajJxylJ--) {
        continue;
    }

    return wUmBaEQulh;
}

int xHsKNO::enfeFlOunlKZ(double rkQKtRrNqX, string DbsNNNAKhnVv, string vdMSVWMCSbiRJ)
{
    string jvrcLnfWYfiSqEGW = string("vOAcoWAbVNhQBdBAdfetPeYIXIOiqowATsgpxwqqtSXVSVsIdspSeJNWadkCjmmYIULCziFUjecJTAJUpddkBkYqEHUBnXwJOFtlsbIZbrSxNkDNiHR");
    bool yYuyHSwnR = false;
    double dpESZVbPuvHU = 80720.22961321998;
    double nvxqRdFogiFUKZJV = -494121.39986410073;
    int AMjvfJ = 651471375;
    double GwBOllsLx = -1034826.4920604635;
    string KMXFPrhLnN = string("YjVjDWqGAcqJrMbMeTJaLYQVKbtFhlJCzYpualMxdyJirfMXXDljRsuEofLxOTSPuSjsneQPTCHLJmAhAcwiOuWzBKJMdrXuqGxjQawPCmyJAMzVwCpYdCyhMORDnEYjfzXdGXpJiXVidCfeqpF");

    for (int ptXPSKMWwdxIeMAf = 1869087746; ptXPSKMWwdxIeMAf > 0; ptXPSKMWwdxIeMAf--) {
        jvrcLnfWYfiSqEGW = vdMSVWMCSbiRJ;
        nvxqRdFogiFUKZJV /= GwBOllsLx;
    }

    for (int EhEidoSQYQULH = 1871561865; EhEidoSQYQULH > 0; EhEidoSQYQULH--) {
        rkQKtRrNqX += GwBOllsLx;
        dpESZVbPuvHU -= rkQKtRrNqX;
        GwBOllsLx *= GwBOllsLx;
    }

    if (DbsNNNAKhnVv < string("vOAcoWAbVNhQBdBAdfetPeYIXIOiqowATsgpxwqqtSXVSVsIdspSeJNWadkCjmmYIULCziFUjecJTAJUpddkBkYqEHUBnXwJOFtlsbIZbrSxNkDNiHR")) {
        for (int EAXhRhWSLoOkAW = 404925333; EAXhRhWSLoOkAW > 0; EAXhRhWSLoOkAW--) {
            rkQKtRrNqX += dpESZVbPuvHU;
            DbsNNNAKhnVv += KMXFPrhLnN;
        }
    }

    for (int CRSmdtguBalTjPj = 1445063995; CRSmdtguBalTjPj > 0; CRSmdtguBalTjPj--) {
        jvrcLnfWYfiSqEGW = jvrcLnfWYfiSqEGW;
        jvrcLnfWYfiSqEGW += DbsNNNAKhnVv;
    }

    if (rkQKtRrNqX != -209155.51972071198) {
        for (int aMjJofATjqxx = 972928830; aMjJofATjqxx > 0; aMjJofATjqxx--) {
            continue;
        }
    }

    return AMjvfJ;
}

double xHsKNO::STHKCZhHN(int ssBMdLVHtFSrUKy, bool jqvwzpQOttKjGb, double ZrKBXMDBDCp, bool zCLgWgKsS)
{
    double RVbXpkkWfKNNMKku = 317632.8046987134;
    string VGBmajpxwXmLq = string("qEZMHBFHNRxoMRKDRflwfyIgnfxuvcCDRzxGHWWkHhCfcsBvxSMLzxgqOVhaYQhGZWtKFigmBvgDLoUFDMtMUWWiDymlqFKJRDEHudXyUtRSEOiSBJmlTdMJfiblEVLYeyQIXIvITvjDyaTXBsKHuhBkhoxnoNQPRBwvVRPMNAPTFVDNPIxCVOvCMtLnTtPfVIfLoxnOJXwqonzCZKuNAvfmyBEkMIJGIvGjJGvdgkWFVfcYM");
    int uacVdlXSatHa = 94762103;
    int DOmnGbC = 1254677497;
    double xhaCpIFGHVqxYbT = 6744.258044971991;
    bool xEBYfKjGsjOw = false;
    double pdYzOLmsDzT = 73004.23733771818;

    for (int pcREnSy = 697966588; pcREnSy > 0; pcREnSy--) {
        xhaCpIFGHVqxYbT += xhaCpIFGHVqxYbT;
        uacVdlXSatHa += uacVdlXSatHa;
    }

    for (int AyDeUEkltpCAx = 52197192; AyDeUEkltpCAx > 0; AyDeUEkltpCAx--) {
        ZrKBXMDBDCp = RVbXpkkWfKNNMKku;
        DOmnGbC -= DOmnGbC;
    }

    if (RVbXpkkWfKNNMKku < 6744.258044971991) {
        for (int xShQCF = 1501172319; xShQCF > 0; xShQCF--) {
            zCLgWgKsS = ! jqvwzpQOttKjGb;
            VGBmajpxwXmLq = VGBmajpxwXmLq;
            VGBmajpxwXmLq += VGBmajpxwXmLq;
        }
    }

    for (int yZtQcZTOKd = 1315341091; yZtQcZTOKd > 0; yZtQcZTOKd--) {
        xhaCpIFGHVqxYbT = pdYzOLmsDzT;
    }

    return pdYzOLmsDzT;
}

double xHsKNO::IuTyzEGnv(string WnZhVOHE, double dKXmyGJPrSLsl, double eRJTdWHjhh)
{
    int ddOGA = 2050916233;
    int PwieTA = -993991480;
    int wtGieNV = 1959711762;
    bool RpSuhBZF = true;
    string jfESTHzrN = string("AxEewzTYGLsDqJDhbgXXeRLZhNklkkmMZzaBhEzmfxsmOWZbzxumHELAezdmdvNkRbGevzMUZzGjbtuunRUQWVLwCaqpzEsbCRfwayMgaeoxhesOYtUpetJwJKDVnfTqvbPxYdXnrVrzVlcteaICyuTzqkHCUXgUuDKAyXlRWaFsIhelsShFb");
    int cBbgUFqGYyEvZB = -1865238659;
    string ATINbeyBt = string("VNTEsfWgrMLCVfVHMNsDuBPuLmqoeggfuaraGSpPaAeMwpbwMlZWaTJQNhCQycWYtvttKVNkGgBqSboYYrimqHkfNHACXTeRasUicMgSEQaDFiBvneYbjPOKpOhXFScccJSEenPhpgH");
    double PLghIn = -262274.16795687116;
    string HFeIPPhUPe = string("JLTKMyZbezvtMFedrMoZCsOhDXOqpmRHtgSImzzlESgkquXI");
    int wsTmYScs = 335664610;

    if (PwieTA < 335664610) {
        for (int crjbVRATNfQ = 1126783598; crjbVRATNfQ > 0; crjbVRATNfQ--) {
            wtGieNV += ddOGA;
            dKXmyGJPrSLsl -= dKXmyGJPrSLsl;
        }
    }

    for (int YDhSKyDyzbgI = 1221896454; YDhSKyDyzbgI > 0; YDhSKyDyzbgI--) {
        dKXmyGJPrSLsl -= dKXmyGJPrSLsl;
    }

    for (int rhJNQcQPYM = 1223663178; rhJNQcQPYM > 0; rhJNQcQPYM--) {
        PwieTA += PwieTA;
        WnZhVOHE = ATINbeyBt;
        wtGieNV += wtGieNV;
        dKXmyGJPrSLsl = eRJTdWHjhh;
    }

    if (dKXmyGJPrSLsl == -802761.4534352808) {
        for (int IGQsb = 936590958; IGQsb > 0; IGQsb--) {
            wtGieNV /= PwieTA;
            ATINbeyBt += WnZhVOHE;
        }
    }

    return PLghIn;
}

int xHsKNO::piIJocSqCjy(int cuLbaxoZEtdQp)
{
    bool NsvMWHFL = false;
    double EuuEeEAzVwnUe = 413787.5377564864;
    double NRyEXopuMzCF = 739925.0169378046;
    bool BfUBiZLNIqPS = false;
    double PzvHXaLLbVGBRX = 236225.42974027438;
    string nXLwomgaO = string("VXsMpOsqvflaEfvyEYmbqtiVHufoXMtYEPKTdKJmiAiXVyYMMXvsQCVreFHYBvksfNEPpmeBsFMjZfoPuGBzcyVxNVoWoiNtJPNSWCofBZsDcMqCfmvsnOfZROOEvtcToGJAEHlHSdHCzYHTWGqfiYjketKwWEGqdpUcLuCOWRBTMUdrrnlzmTx");
    bool gTeHvr = true;
    string LgwtPSNXuT = string("JEUqxhGDEmOajdgseGbPszeQArquIXzjWFwcGbzWFgUYXALiDvwBNbATIVEIjawyVWdXwtErPeDLMxcjWrUaeIZA");
    double LqEXkmmFTLBMb = -905559.2849568372;

    for (int QZPWxoPJWVMc = 31809371; QZPWxoPJWVMc > 0; QZPWxoPJWVMc--) {
        PzvHXaLLbVGBRX /= NRyEXopuMzCF;
    }

    for (int aNUrbPdo = 322554903; aNUrbPdo > 0; aNUrbPdo--) {
        EuuEeEAzVwnUe += NRyEXopuMzCF;
        NsvMWHFL = BfUBiZLNIqPS;
    }

    return cuLbaxoZEtdQp;
}

int xHsKNO::qrGHXdpMjH(string DMBbO, string HtCLHi, double szUlsiinvsqbs, bool cGKnneBmhzkNyiyy, int eYKukuoQtnECgX)
{
    int nJTTxgMNO = 338383530;
    int GNkHOOeiKS = -1874078622;
    string SKZnH = string("ZvrxtqdOiUQtfdCxxsrkgfHclsSMNVDcUYjIOgUWEaDbhgZUVRntAVjdrppyvDfPZfRWqSRUiUNoshOauwImKhvpRpxLFJYuWEOhCJLtBxBWSJAUtvwwbXwaJgTlfKFKFfVReZkWQztsfYCKyqBEJnAFnDbCXQuWynGaKhHbVPlXsePQDxBZfaCGswGSRPUsTswkKvNBKdWtmBuPvWwJbxxKbDRMYQwTFrhiPMfAiqCXZsvndj");
    double tCCbfIwrAeRt = 664771.0036975545;
    bool XHBwdnj = false;
    int TicYoF = 1375950756;
    string KnfwPeKQ = string("chqfEsHpQQJhgfRZUavmVUBjyMyZUOGvvpcBAmYWaUDbrcSEbyhRFKASyyskEqaTyUgDOmOAGopRM");
    int gOdFxToucTsj = -1352951617;

    if (GNkHOOeiKS == 338383530) {
        for (int BiDSLcKhaAHgo = 611800754; BiDSLcKhaAHgo > 0; BiDSLcKhaAHgo--) {
            HtCLHi += KnfwPeKQ;
        }
    }

    for (int JORrfh = 1161124020; JORrfh > 0; JORrfh--) {
        KnfwPeKQ += DMBbO;
        szUlsiinvsqbs -= szUlsiinvsqbs;
        DMBbO += KnfwPeKQ;
        GNkHOOeiKS /= gOdFxToucTsj;
        DMBbO = KnfwPeKQ;
    }

    for (int RwbmL = 1885485987; RwbmL > 0; RwbmL--) {
        tCCbfIwrAeRt += tCCbfIwrAeRt;
    }

    if (gOdFxToucTsj != 338383530) {
        for (int TFTnVWaRUpLRf = 1127482356; TFTnVWaRUpLRf > 0; TFTnVWaRUpLRf--) {
            continue;
        }
    }

    for (int THXkZFEIaPa = 558203272; THXkZFEIaPa > 0; THXkZFEIaPa--) {
        continue;
    }

    return gOdFxToucTsj;
}

string xHsKNO::klIcXbJZupx(int EOXJoVUbW, int iKbcEKuWstknFH)
{
    bool lwXIblGuzRcYrIr = true;
    int xmbVKwTQfDpTn = 562713449;
    bool RHQxJGujWZOLH = true;
    double XAwrvAHDcQZJYa = -422392.072859651;
    int vbTLuneCDIEvNuG = -2104295894;
    int YwdBqVIkGmNOEJ = 1175617015;

    if (YwdBqVIkGmNOEJ == 562713449) {
        for (int rmweeFzhh = 1095788721; rmweeFzhh > 0; rmweeFzhh--) {
            lwXIblGuzRcYrIr = ! lwXIblGuzRcYrIr;
            iKbcEKuWstknFH /= vbTLuneCDIEvNuG;
            xmbVKwTQfDpTn -= iKbcEKuWstknFH;
        }
    }

    if (iKbcEKuWstknFH > -1431547415) {
        for (int qAqWCGZ = 543353552; qAqWCGZ > 0; qAqWCGZ--) {
            EOXJoVUbW *= EOXJoVUbW;
            YwdBqVIkGmNOEJ = YwdBqVIkGmNOEJ;
            vbTLuneCDIEvNuG /= vbTLuneCDIEvNuG;
            EOXJoVUbW += YwdBqVIkGmNOEJ;
            YwdBqVIkGmNOEJ += EOXJoVUbW;
            YwdBqVIkGmNOEJ -= EOXJoVUbW;
        }
    }

    if (EOXJoVUbW > -2104295894) {
        for (int TGACcFELNV = 2113621611; TGACcFELNV > 0; TGACcFELNV--) {
            iKbcEKuWstknFH += iKbcEKuWstknFH;
            xmbVKwTQfDpTn = xmbVKwTQfDpTn;
            vbTLuneCDIEvNuG /= vbTLuneCDIEvNuG;
        }
    }

    if (lwXIblGuzRcYrIr != true) {
        for (int pSpGmmQYFZoLXy = 1929231254; pSpGmmQYFZoLXy > 0; pSpGmmQYFZoLXy--) {
            continue;
        }
    }

    if (EOXJoVUbW >= -2051040146) {
        for (int vneIz = 268181427; vneIz > 0; vneIz--) {
            EOXJoVUbW -= YwdBqVIkGmNOEJ;
        }
    }

    if (EOXJoVUbW != -2051040146) {
        for (int ktcFQRtzCsiOx = 856537964; ktcFQRtzCsiOx > 0; ktcFQRtzCsiOx--) {
            vbTLuneCDIEvNuG = EOXJoVUbW;
            lwXIblGuzRcYrIr = ! RHQxJGujWZOLH;
        }
    }

    return string("YrXEwUkRBdvROqDAXikRemKfUtSBvUAAbXQgAENuxIbYOxCrKISkxxwPdNoFtJLzLcCfYFirWBCiLEwmshKTFXhhPLkHcjdpBLalqiXjnybARoZYhTrUykDhhyAxMZsXmIjdzTQmPSauUYbvfGLbtkGNWeSYCxgzCFNKWhrgwDtPtWWwfEZhXANllLyppIxpcYJPEZSCxjOxEKsdqXmEaGYaxLBZhZnDGEzWCazCoIjGnkqtD");
}

xHsKNO::xHsKNO()
{
    this->XkHcoyW(-1475207415, 241407.84963798986, string("dquPKTuBzQirRFojQUAQoFzWnDWmyXPBVYuXfjvfyqbPklQMoFKIzEEJxQQoNOMhSsUCUlAvXyDFSTVBnnVjUqdHwUgTgJCJhOgrqotxRhbgDQOptTrfeWWbIhoHffYvbvPVitYNEibCFeufZSGfLDzJDMHmrSFktoFrCBpZOSOEZcaRzciJjENaLwsYdosUSkUmVtPvNCGOGpaWWIakHQkMxOwWxFlLZAEUBhImnQAXiMD"), 14539.847615353247);
    this->gcmZbrCS();
    this->AAZbtHpTWvbiyXEi(1862159793, string("CEDlETiiyrlHoULMzMlySBooYJyxmMTwanqVNSKSTHwfgMlrvnNEsHeMSRzsGVWJBUfeSTfrwIqyQXJlXgaUZYNALesuQGOARlFQTPdtuFELLuGZeaSWNRyaCAbHKMsIcaEXEQsjWXpXvGBCEAQGVPVhcfxRJwwlTXfvltbtCgQEEzeixisyZYWqiWhwaFaHlhdwDNuCoDiFYKdaVdVnjGlaUyfwlF"), 23967001);
    this->dVCEDRNGjV(string("DsbiRWAgnOfXHnQKqmcetjzniYYPobLhIJQtZdkoMjNLocJegBwsrUuCxbaMfsEsBFsgdAYyXEDUBkToEXRXKrrWxtXgXWwlUHwQFyqmNJGfgFVqeILvHzUJuBadHsZjJLoscfVtPyLmQNPwvPVSrNTOmMKLnbgwBUmFggDcUNOsyIrDpACknlhMB"), -17522.290514944645, 486359650, -2144076505);
    this->MGioGtcQ(string("piCEBAErlEDQGxcrqUmKfzMxaxaYXOnAOzVzvZKjEPmXgLNKHIevqtAQTMKVBgKHntmLRVnLdsGoewYVvhUHhoGXliQRVUgVONWoDUDtBHDgxLIcGtoVxLTVmtDUqDzEFjAkVjViqJEqoEEXuDjgsYYlDGBEiRuglJNXddBcnPhAxCJxvxyqehkHhhxFgdRDvgtvyZJAPmoTZfKasDBrCsnFuEWLmfiuxeiUFzDvWcNyQYdtNUstKMZahGvw"), string("QvRFfXYYdqLnLFqVqwzNxUauGfvbCZcbgUUqSihpabSmcUgHJSToBoI"), 808108.8742845625, true);
    this->AWnYkvvUOpLpNtBJ(true, false, false, true, true);
    this->pfQjTijfUC(false, -2133846761);
    this->zDfIbRgxgJipUwv(29243018, true, -833389428, true, -978730631);
    this->IkoMzulrAYqxbo(string("zMqaUcYZNqyMWvdqaWnylEnYfffatRbEHTFZHTLQYvfqZkwKrJcEuqXEEdpUnwtwChEfFikhObOAmYuZZQhjwAKDHDPWelCFnVtAfQqfAoLDCSVNYFyuMtjYmQQPdlXjAdjqkcIVEyEsqiZBi"), -867775.8340938537, false, -464215787);
    this->enfeFlOunlKZ(-209155.51972071198, string("yUAyaPBoiuBuVxARcnSYIKyeduppwIJzXILJygXQMJzHEjEwczRTExxrUnbFrFgzzLhbBzHgWXnhsxRkJHOVxyQVtGbmaBXTNeiIkcHFKNmUWWcEuTdSfBmdvOJptGqcQufOSwftOIfBeEYsJrQVDqfQLRPqCfUAEAyWqzstscBgLueWBRkasqJqYlYLGeHfYAYWFPaBgpBkXCwLqykDiYeKDIyvXHnsdFuMszAaJiySayJcnTxPFltHb"), string("gWqzUALZCypkYFFwHLUaFhobEZqofXGCwzBAzWWPMKbUqVrBNtTJpoJWFAslPQJRGdrPfFvryqnfdqxUyOpLJNiuiWXXGTqTGXLHWmHmjpPqtruAHoLLjflznAdMDESPfiWFkenxMsvEOlapGDhJjNeQpHQfjNZRDSsLONvviKqdLizjgLRihh"));
    this->STHKCZhHN(-902110474, true, 840468.4472142421, true);
    this->IuTyzEGnv(string("kNTRHlssYDFFYed"), -802761.4534352808, 784658.6617333351);
    this->piIJocSqCjy(2040494595);
    this->qrGHXdpMjH(string("yFrgePXRKoItotJRGXEhYETquhPLhBqhNeHcGJDimcSjJCJWvcbGGAQpMPsIyosPvPPMrvWkAkxIRbgtaxLIILbilzTjyOaVpQOsKsafrDdOAuoNLiSgfiKHJhbMzrluSZNmZzcRpYSlaitXakeanGayARZLqVjDSoHZUfcBsXVUMiynVGHGvdgsSGmwrBlpBYpXmg"), string("gZRhLiZIpNbtdsFVHQkHDghRgKVHPnjCTvWjYvmigSiRWrVRmVvWXdJnuRbXSpZijUdMDjXXgSDiqrZsumHbdUMzKEEJZcqnSwIBSewAoQvFNKFBTTttMKgwlBaGwbYvSvknbOiWlhWHVXcVNFuCBiuMVaKzuc"), -835890.8352894895, true, 191390049);
    this->klIcXbJZupx(-1431547415, -2051040146);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FoVaAKuFkStxwSBC
{
public:
    double kjruFyEVG;

    FoVaAKuFkStxwSBC();
protected:
    string oPZaCxrnDxIGlAKQ;
    double hLqTuQMXWmAPn;
    string ecWAVjyH;
    bool LzZbHHMkRiXFt;
    double vbnMOgPvMdu;
    int TrLByoRWopDMhyFb;

    bool lwaBmZzfn(int ZDuqmoBWcLqHU, int OzdOAIgtVqVp);
    bool ZgQhd(int oGvDLikTyh, bool BzWHusu, int GgYrPUGXxbQFmRwA);
    double ChbOxVqXYY(bool AEECdHvH, string xGlqoXrfKnC, double HqILx);
private:
    string ZPFWcY;

    void ypTElS();
    string jDHrOEL(int CnrsjFPnbqUCS);
    int iWahaKZc();
    double LnoaiVvNjq(bool ZjaxZWUcdWIr);
};

bool FoVaAKuFkStxwSBC::lwaBmZzfn(int ZDuqmoBWcLqHU, int OzdOAIgtVqVp)
{
    string TIBeRVuNoucQ = string("EOjiIaitFkjOSpVGnYZdnejKsdPbHBpYyPIQnljnvUFqRmXyZBChEEgpzMPexxxBcEUZSXsGMpgIIiiPNCOyvtdbRhscHHHJCvsMvGhsOOABOvJOOrYjFUfbEkTHwdwpVBfMXxkoUodqwnxsbUkrNIPhKZvbbeVICAFUFDu");
    double AXIfUJT = 801509.1301520315;
    double NIuxlKdgrJshM = 812740.9963869286;
    bool rkoWCmm = false;

    return rkoWCmm;
}

bool FoVaAKuFkStxwSBC::ZgQhd(int oGvDLikTyh, bool BzWHusu, int GgYrPUGXxbQFmRwA)
{
    string lXodXZMAOba = string("eKGWkPJOOgRoiqmXMUWldZQvJqDDfCDFXzLFzv");
    double NtjiKndFTla = 915950.0049097212;
    double KcVlCEYosMZadG = 714836.3813120115;
    int CBDdQmpeUId = -1627945329;

    if (BzWHusu == true) {
        for (int hscCAeoMiXDGS = 1462034817; hscCAeoMiXDGS > 0; hscCAeoMiXDGS--) {
            oGvDLikTyh *= oGvDLikTyh;
            CBDdQmpeUId /= GgYrPUGXxbQFmRwA;
            CBDdQmpeUId = GgYrPUGXxbQFmRwA;
        }
    }

    return BzWHusu;
}

double FoVaAKuFkStxwSBC::ChbOxVqXYY(bool AEECdHvH, string xGlqoXrfKnC, double HqILx)
{
    bool jhDicdYJCajDk = false;
    bool PoDQeBMyD = false;
    double HZeqYlmufEH = 132701.5324956475;
    bool LAdzXdNsE = true;
    string TMifPxhF = string("FAzMrACXSmGPnBVYOyhjJdgUIilANHxKIPLbguxyeszgewaUleyuxOAMWSDcTSfMNznLnjfwHPCXgHEFazkrNQcitmZcNeFsTfDDVyvYZZYlrLRggnjxolKqogeLtzwJLrEuQYwXmaMDivZxNOjvmpSVgEeIVmDjmhQHDvzMXosCGRCeRrDwKWFrAnvuSQOLfmzYzXSPvbzxuNPdOwKqZAsJxADnypqgqGmDyfXmLrwcBRviNCge");
    bool jSmPOlzbtSBTaVnF = true;
    int JhnHFIzHAiPOCb = -1819467568;
    double lywvHu = -661832.8584820502;

    return lywvHu;
}

void FoVaAKuFkStxwSBC::ypTElS()
{
    double IOMJjtXCrbBZge = -360929.23704415956;
    string KmTqLnXVMnqQIF = string("zxZGiHgDPRQPcovsigLgZzQuscvmMAgexLfgUnABtnD");
    string pEAKaP = string("yMCOFqKlmbRxmuCqltYjEwseRRKFqavTvPiGXNaTmENZItQzkGEnwEjkdNGRLZSIvtmTDxHoXv");
    int FZPccqNjlzs = -2080337935;
    bool mhLWIZCpFM = false;
    bool SMWLRL = false;
    int zOQdgH = 69469603;
    bool tFnIUSv = true;
    string YKhgSahUdGzljRP = string("ZJwvYxEHtZlaXerGqfalfTEKcgrRlxxayxDOgV");
    string gCIHR = string("rZeYfVdjHzPPAOMzPgkmJZGcNnEYXqvhJrHcsVMJfCbKiwLQNLZoXSEsDxjfqvsNGwQYZWTBsIhmCXLZGvkamaUyxbEmS");

    for (int rchQhcaApkEPbC = 946981387; rchQhcaApkEPbC > 0; rchQhcaApkEPbC--) {
        SMWLRL = ! tFnIUSv;
        KmTqLnXVMnqQIF += pEAKaP;
    }

    for (int DeiiFdsBjbro = 662069461; DeiiFdsBjbro > 0; DeiiFdsBjbro--) {
        continue;
    }
}

string FoVaAKuFkStxwSBC::jDHrOEL(int CnrsjFPnbqUCS)
{
    bool NeVUXcodzhCoyIRS = true;
    double ZuiVomFlKSx = -627169.3900197644;
    int zOADwbpLCOFn = 1816868770;

    for (int qrBhrddjVs = 1645823248; qrBhrddjVs > 0; qrBhrddjVs--) {
        ZuiVomFlKSx = ZuiVomFlKSx;
        ZuiVomFlKSx /= ZuiVomFlKSx;
        CnrsjFPnbqUCS /= CnrsjFPnbqUCS;
    }

    if (ZuiVomFlKSx == -627169.3900197644) {
        for (int MsTBPO = 1373877552; MsTBPO > 0; MsTBPO--) {
            NeVUXcodzhCoyIRS = NeVUXcodzhCoyIRS;
            NeVUXcodzhCoyIRS = ! NeVUXcodzhCoyIRS;
            zOADwbpLCOFn = zOADwbpLCOFn;
            NeVUXcodzhCoyIRS = NeVUXcodzhCoyIRS;
            zOADwbpLCOFn -= CnrsjFPnbqUCS;
        }
    }

    return string("RaWiuMEgjNzUqcTjjQnaDywlvicuZQOehzaNbCTFNpbcoIdIljiYIoTwOiPYgKOHHpGNZOTdFP");
}

int FoVaAKuFkStxwSBC::iWahaKZc()
{
    bool wpdBcTZrAPGxhpdd = false;
    string ZQMhe = string("ozgFcDXfReKAVzlXUQXhLEnjfxPDvUVKGEwUlJJTLWBDjmHmIivtkpEiVTzSj");
    double EiPNq = -623792.1650645797;
    double LfNBYnjoDFhAnUL = 276466.304330507;
    double llLMHo = -953988.4565622633;
    int jGhWRGQZCVikppc = 622340314;
    string ZpkgZobHGd = string("YlHfOLVQmpZFqsNJOWMsDJNkKAwIuGJBQLkJpjGaOyNxGgAWNXVVZlWCDOtuYYbtWvSCrOIdgDytjGEy");
    int EwJNZitgLFhzCg = -2011112855;
    string anfQpJbHqlbzq = string("hNcbphQlZgYQnT");

    for (int EjYnqEye = 801444999; EjYnqEye > 0; EjYnqEye--) {
        EiPNq /= LfNBYnjoDFhAnUL;
        wpdBcTZrAPGxhpdd = ! wpdBcTZrAPGxhpdd;
    }

    for (int ilaFMa = 2127057782; ilaFMa > 0; ilaFMa--) {
        continue;
    }

    for (int vkxvkqlqDOGX = 446036427; vkxvkqlqDOGX > 0; vkxvkqlqDOGX--) {
        anfQpJbHqlbzq = anfQpJbHqlbzq;
        EiPNq /= LfNBYnjoDFhAnUL;
        EiPNq *= LfNBYnjoDFhAnUL;
    }

    return EwJNZitgLFhzCg;
}

double FoVaAKuFkStxwSBC::LnoaiVvNjq(bool ZjaxZWUcdWIr)
{
    bool mhTFzcGYzXPmiOPr = false;
    double cOlcvnWLwAVKH = -294063.6549544033;
    string HZZFfLgTouNC = string("sIgUZAuuYbUKHLfHYtvVOHGhTiovQBJEPFSEPQvRtEwmBViPgrkcRtuTFFicdsyxvKmSAOtddgjVrTdGBVEavbWUkTcploJmcPyywHXSEcdwPzbXTWVfFAZzJMrYhFziWdDQSnxnFnSOWkrgJFOOzNLmAHVNVPzCJL");
    double rrAlRuYSfbR = -999822.4941900885;

    for (int ppZqFHKpJRKCYC = 903348840; ppZqFHKpJRKCYC > 0; ppZqFHKpJRKCYC--) {
        mhTFzcGYzXPmiOPr = ! ZjaxZWUcdWIr;
        rrAlRuYSfbR += rrAlRuYSfbR;
    }

    for (int dHVVzrbarzsyzx = 1682667766; dHVVzrbarzsyzx > 0; dHVVzrbarzsyzx--) {
        cOlcvnWLwAVKH /= rrAlRuYSfbR;
    }

    return rrAlRuYSfbR;
}

FoVaAKuFkStxwSBC::FoVaAKuFkStxwSBC()
{
    this->lwaBmZzfn(-404863370, 250806330);
    this->ZgQhd(22797368, true, 1662034475);
    this->ChbOxVqXYY(false, string("OwKEhUhUrgyxNcuK"), -676166.9532080711);
    this->ypTElS();
    this->jDHrOEL(-1058399769);
    this->iWahaKZc();
    this->LnoaiVvNjq(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gyeHDShiLsGIFLm
{
public:
    string dkyZEYgwIpWyCDMn;
    double CkbqxUvbfNRpwiOm;
    string wKbJhSWlzLyQc;

    gyeHDShiLsGIFLm();
protected:
    int MUHEsNS;
    string nbnXiCWVkdyS;

    string aBFCZMPPXoqwqI(bool oRJCJRBjJ, int uOavfNUEyjUr, string PaRZxzPDSZXukR);
    bool ESmVoQ(double wckpGSVUqGVsn);
    string CwmZOf(string TegxoMkGXuFZmE, double VBgoUwr, int yiKngyHdiOUUqrl);
private:
    bool KvYYcPAUUguiIaq;
    string QnsniUVGWKQyRHfU;
    double pkYkKOCGctYXh;
    double klISeduOObfsxX;
    int SabXiwAOFBxTwOyN;

};

string gyeHDShiLsGIFLm::aBFCZMPPXoqwqI(bool oRJCJRBjJ, int uOavfNUEyjUr, string PaRZxzPDSZXukR)
{
    string ZdnnXAbmfND = string("cqWxydBBNtoZvPARLjncHqu");
    string ZdgKUWQz = string("SzpiZOagtSRBxICHWEMRHsAUQPuIEXDbEuzuXdyPWaRHFyMQCVBYXZiUncGQCFZRyEdHdJPdwwlHmBlzKAOJdcOXfsxKtaLgUdbKuccYujrHUzgXAjrPRjaPUsPFwjPbLAmkHVAWcMYYzWgOzXRZXiCaSAwFEtodqDlCfnHkBNWhhRpxzYZHJccCckHZpCgGgJGyDsXipfUekpLpGknFrCKuSCklGhscSXwzkMOFGY");
    int KPRiPnKs = -1203957755;

    if (uOavfNUEyjUr != -1203957755) {
        for (int EFBEhl = 2008503803; EFBEhl > 0; EFBEhl--) {
            ZdgKUWQz = ZdnnXAbmfND;
            PaRZxzPDSZXukR = PaRZxzPDSZXukR;
            KPRiPnKs += uOavfNUEyjUr;
            oRJCJRBjJ = ! oRJCJRBjJ;
        }
    }

    for (int yGpmNbIhIdqD = 1738014097; yGpmNbIhIdqD > 0; yGpmNbIhIdqD--) {
        oRJCJRBjJ = ! oRJCJRBjJ;
        PaRZxzPDSZXukR += ZdgKUWQz;
        PaRZxzPDSZXukR = ZdnnXAbmfND;
    }

    if (PaRZxzPDSZXukR > string("cqWxydBBNtoZvPARLjncHqu")) {
        for (int RLCRwVHRGGQ = 274582252; RLCRwVHRGGQ > 0; RLCRwVHRGGQ--) {
            uOavfNUEyjUr /= uOavfNUEyjUr;
        }
    }

    return ZdgKUWQz;
}

bool gyeHDShiLsGIFLm::ESmVoQ(double wckpGSVUqGVsn)
{
    double LqUnPjiJ = -640185.4241747526;
    bool mxeCtqoIZP = true;
    double qFCjlHsGajpXXi = -240266.54104125642;
    double hXYRrDkOG = 795425.3035058699;
    double qRpkRXORHWIMqPE = 1031865.6503934648;
    double yLxMYVRg = -811812.1546135757;

    if (qRpkRXORHWIMqPE != 1031865.6503934648) {
        for (int mrQbHb = 2081723865; mrQbHb > 0; mrQbHb--) {
            qFCjlHsGajpXXi += LqUnPjiJ;
            qFCjlHsGajpXXi += qRpkRXORHWIMqPE;
            wckpGSVUqGVsn = LqUnPjiJ;
            yLxMYVRg *= wckpGSVUqGVsn;
            yLxMYVRg *= yLxMYVRg;
            hXYRrDkOG += qRpkRXORHWIMqPE;
        }
    }

    for (int UrKWsx = 1119079900; UrKWsx > 0; UrKWsx--) {
        qRpkRXORHWIMqPE += hXYRrDkOG;
        yLxMYVRg /= qRpkRXORHWIMqPE;
        qFCjlHsGajpXXi = LqUnPjiJ;
        LqUnPjiJ /= qFCjlHsGajpXXi;
        hXYRrDkOG = wckpGSVUqGVsn;
        hXYRrDkOG *= qRpkRXORHWIMqPE;
        yLxMYVRg = qFCjlHsGajpXXi;
    }

    return mxeCtqoIZP;
}

string gyeHDShiLsGIFLm::CwmZOf(string TegxoMkGXuFZmE, double VBgoUwr, int yiKngyHdiOUUqrl)
{
    string Ekdhej = string("veSanJtkTSvK");
    string jAYsSiWfPIqMdH = string("tuhRPxQTTLrZFgrLXnowNJtkYNAsohcJttssUtLArsjmbXuSbnaMVMvdIOEAUlCdVTATGlZiGJWGRIfQJrmiCuFrUtjJSACJlcWikrg");
    string kdTruoyrW = string("UckZBcIIILVwFqabgvIrVKptPTkktWiHwyKwQywvzkUteAGrzjqUasYqglanJVufXiAWOjAUgflZMosbtryquSAqEfpQiDpfmBxNZtovmbAqCvhksimhDSjplqiDUOVhztULENiyTyQoYBuTmVNdJyypXKCEEvoZfjfThFyQFsaXOBhrhpkuTJfDWCgivQWdrAyxneTWQglAUdpsabbjBHlFKsZOqumLpVwIHjwe");
    double yvfiDTZeetMNbSKV = -573473.0726794341;

    if (TegxoMkGXuFZmE >= string("tuhRPxQTTLrZFgrLXnowNJtkYNAsohcJttssUtLArsjmbXuSbnaMVMvdIOEAUlCdVTATGlZiGJWGRIfQJrmiCuFrUtjJSACJlcWikrg")) {
        for (int ARMnFzTNFYtPCet = 340193917; ARMnFzTNFYtPCet > 0; ARMnFzTNFYtPCet--) {
            kdTruoyrW += kdTruoyrW;
            yvfiDTZeetMNbSKV = VBgoUwr;
            yiKngyHdiOUUqrl /= yiKngyHdiOUUqrl;
            yvfiDTZeetMNbSKV /= yvfiDTZeetMNbSKV;
        }
    }

    for (int jbITxhijR = 212270737; jbITxhijR > 0; jbITxhijR--) {
        Ekdhej += TegxoMkGXuFZmE;
    }

    for (int NIUUSbNSpvsvu = 2090832129; NIUUSbNSpvsvu > 0; NIUUSbNSpvsvu--) {
        continue;
    }

    for (int MOOEFtRApFFH = 860260588; MOOEFtRApFFH > 0; MOOEFtRApFFH--) {
        kdTruoyrW = kdTruoyrW;
        Ekdhej += TegxoMkGXuFZmE;
        Ekdhej = jAYsSiWfPIqMdH;
    }

    for (int dfparMVV = 309807640; dfparMVV > 0; dfparMVV--) {
        kdTruoyrW = jAYsSiWfPIqMdH;
    }

    return kdTruoyrW;
}

gyeHDShiLsGIFLm::gyeHDShiLsGIFLm()
{
    this->aBFCZMPPXoqwqI(false, 2050028636, string("ApNJzDWvFcsrqxsCcHtwPvmyPPImtXKIJpeqbgHqKPjewtfAfjNIIppRCGqqKvyCdzf"));
    this->ESmVoQ(620327.5365012962);
    this->CwmZOf(string("oCvwsWgVWdzFshiloBRaydqEMECpGFxYVFzawMsUtvciZRiaFOltgSmrbklQEYvahAcsyDhYeaYMmRgOSzUJyAJdIsjpuEJGaXHMuZJnYIiOGszOsdmWbUBlsyWEPIlGsHD"), -33757.03346626596, -50517550);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jtrvMWhHe
{
public:
    bool vMdyDJWCxpAr;
    double slYzwokGtoVvNb;
    int LvkrRjS;
    bool hpvHObugRCSUUHYO;

    jtrvMWhHe();
    double ozhIpqyu(string TGgee, double jtPcKIwpLuRQnZK, double mNUykS, double VKKIICClKL, bool nektHvtXviBLC);
    int fZdOqNEQ(string uTXyQZqRRtQkB, int QBCCtlalTaUzaoi, double ALmHgqxQZm, string SqkbAdrZunqZ, int PfqSUI);
    string AFKFTTl(string PnIPGJ, double AvvMlaAuXbWUQN, int ISLYELviWkyuk, double jrwVV, int IaOkUfczcbvKRZR);
protected:
    string RyJJxECurpAZc;
    double ArvqSVNZgMe;

    void kZfBsS();
    string HluMAcnJxjHXKO(bool DEsGBKHTlnWAr, string iVEgy, int VhWDO, int ySmmmF, bool cmQgWvlHiESd);
    bool SisOBATclnlIUYoy(int sbJIQxQGht, string XYvRchIvfgt, int iwhxDoGAzWFPvzYs);
    int SLHXEDJKvaOAzKe(bool jYGVSjgawGUpmx, string hNLqWuGMwQWTZ);
private:
    int lNQRzNMlJo;
    int RqpcMbv;

    double NGHEM(int KzmkOllSZP, double BGkSOUbCGJP);
    bool dSkZiLw();
    void cRqdu(bool JbLoKI, bool TiQGFOXrcrvrGQxZ, int cqGnpnSbuh, int dvKDATqGQK);
};

double jtrvMWhHe::ozhIpqyu(string TGgee, double jtPcKIwpLuRQnZK, double mNUykS, double VKKIICClKL, bool nektHvtXviBLC)
{
    bool FguRQpV = false;
    double bPkTxCIF = -735308.174288246;
    bool aWrYxeLDEmTqbY = true;
    string RVolPNZXVOA = string("VAsxqYaOgObapEqLlTJMbQDTKsTJOtnCWiPZvUpXqXmeLWXyOQejejeFOCYUAvMwnfGEdaUPYaYdzjlCRGRqwoHEppzcvmS");

    return bPkTxCIF;
}

int jtrvMWhHe::fZdOqNEQ(string uTXyQZqRRtQkB, int QBCCtlalTaUzaoi, double ALmHgqxQZm, string SqkbAdrZunqZ, int PfqSUI)
{
    string IHvWugFcWp = string("iEiWrSdmzkrRMnkMJMEQJxBFKCvzGJOlQfVFQhzciDZOEFPhzGbzwTtYkXLbrfBhqzCPRLVyVRuOZsoOPKPhKIuPOdDNXrdYoNbfHpb");
    string gRnnkYkKyjoG = string("dkTwJAsrYsnisaKDjYPMKMbvfuTymxiHwigSHBBNGLQ");
    double QoFvoSJQHWWM = 413027.0229277479;
    bool KDRIvoIHPbSxtWc = false;
    bool lodrFIqICCbTEfEd = false;
    bool YRWVSmxqQWvWUWeV = true;
    int tavgr = -796568395;
    string uieZSxiwyHYqaz = string("AxrpnqQEhlRZJUawnOrlENpZwzBxTmFSmxtUHAtjBKcYYHJMFUnOCLarxCzjExFiWBtzo");

    for (int dHRgiq = 1577359023; dHRgiq > 0; dHRgiq--) {
        uieZSxiwyHYqaz = uieZSxiwyHYqaz;
        uTXyQZqRRtQkB += uieZSxiwyHYqaz;
        QBCCtlalTaUzaoi = PfqSUI;
    }

    if (SqkbAdrZunqZ < string("AxrpnqQEhlRZJUawnOrlENpZwzBxTmFSmxtUHAtjBKcYYHJMFUnOCLarxCzjExFiWBtzo")) {
        for (int TxPAbHfgwpnuUk = 734216883; TxPAbHfgwpnuUk > 0; TxPAbHfgwpnuUk--) {
            YRWVSmxqQWvWUWeV = ! YRWVSmxqQWvWUWeV;
        }
    }

    return tavgr;
}

string jtrvMWhHe::AFKFTTl(string PnIPGJ, double AvvMlaAuXbWUQN, int ISLYELviWkyuk, double jrwVV, int IaOkUfczcbvKRZR)
{
    int qstROeIxhYygauL = -95990172;
    double APuIJ = -459858.20943400066;
    string ZGoWy = string("moZsZIynAsrVKJYKQvHlnrJMHhQdHmwtmfQBTowVHnvsarwCpoiLwcpOpxuzGOsgTMlibHAfjblCrdnRYBJsGNmaUJekJa");
    int dotxGp = -360921958;
    bool sSyfjYwtPdNLEuZZ = false;
    int DmOELKxpVQZS = -1429848932;
    bool ViViHpseEsGA = true;

    for (int OvmOHgebTtDHZHPO = 1644609858; OvmOHgebTtDHZHPO > 0; OvmOHgebTtDHZHPO--) {
        APuIJ -= APuIJ;
    }

    for (int eAjDliWb = 966091333; eAjDliWb > 0; eAjDliWb--) {
        ViViHpseEsGA = ! sSyfjYwtPdNLEuZZ;
    }

    for (int MgbFVUWhb = 902535633; MgbFVUWhb > 0; MgbFVUWhb--) {
        continue;
    }

    return ZGoWy;
}

void jtrvMWhHe::kZfBsS()
{
    bool vTviTDdBmzgDPa = false;
    bool WKbRepmezyo = true;
    double QiRBgi = 720355.1721768209;
    string AgTdgXhDbUpEmdVp = string("guHwcJGvfYrIjjAE");
    string yVjuAQpboZ = string("zKTJuDCHlkCnRdkafzqDlaZyjjkMYUFNmkVLoDGqVKupeGWNmAWaEsXzFQpaTFQbVWSYsLCTPcvWvGUuCYdSeqUEFltUgOGpgbhbJXadEXTPXBYpQPVcvfeIhspOiUOacnanlKQQYjxJnlYUmbzricaDoyiiESPznxTGRBulSpijJGcjRBMocmvoAejdaTnfYOsBTjSdURnwml");
    int LvwaiepHQ = 899707078;
    string jSJLEXYmdjGfJFz = string("wvHwUNWQGWigRIlDqQMgrEDbVbfNMRVFFRYArqnIZSSYJstsqOlRDEikQqazQwnhteCrGrRLBhnfGkcfZwkSRTExAKUEKvlPqcMegQpojJWQxcrJvEyITOGqlfwujCCLVKgYETNzKRKXbLtQVFpcIGcRREfBiAIYCQODCORkIyCJI");

    for (int psHiAvFnu = 1952183045; psHiAvFnu > 0; psHiAvFnu--) {
        AgTdgXhDbUpEmdVp += yVjuAQpboZ;
        yVjuAQpboZ = AgTdgXhDbUpEmdVp;
    }

    if (WKbRepmezyo != false) {
        for (int GcyTkblaNYUEc = 83355398; GcyTkblaNYUEc > 0; GcyTkblaNYUEc--) {
            jSJLEXYmdjGfJFz = AgTdgXhDbUpEmdVp;
            QiRBgi = QiRBgi;
        }
    }

    for (int xKMALsoPTBjHg = 1889763758; xKMALsoPTBjHg > 0; xKMALsoPTBjHg--) {
        vTviTDdBmzgDPa = WKbRepmezyo;
        QiRBgi += QiRBgi;
        jSJLEXYmdjGfJFz = yVjuAQpboZ;
    }

    if (jSJLEXYmdjGfJFz >= string("zKTJuDCHlkCnRdkafzqDlaZyjjkMYUFNmkVLoDGqVKupeGWNmAWaEsXzFQpaTFQbVWSYsLCTPcvWvGUuCYdSeqUEFltUgOGpgbhbJXadEXTPXBYpQPVcvfeIhspOiUOacnanlKQQYjxJnlYUmbzricaDoyiiESPznxTGRBulSpijJGcjRBMocmvoAejdaTnfYOsBTjSdURnwml")) {
        for (int bpQtSqEBjQgsWJ = 1411452101; bpQtSqEBjQgsWJ > 0; bpQtSqEBjQgsWJ--) {
            continue;
        }
    }
}

string jtrvMWhHe::HluMAcnJxjHXKO(bool DEsGBKHTlnWAr, string iVEgy, int VhWDO, int ySmmmF, bool cmQgWvlHiESd)
{
    double TKSqQwWgE = -650247.3475433219;
    int Fexyw = -1948572390;
    bool LxVUwAMeAiq = false;
    bool WnLUZc = false;
    string NyGdwtKQJF = string("XZxFOGeCiKKUZDPjwcBjoDwTUchJjBFbOfxkfpuVbutNPySpvRNEqEPvkzkvpHxODlRzeZeUCTPAsOhtaLnUXTkBuxhNFFAXcewJmnEKCwHxFTEMzwtHYUVVFmHLoXNQFvD");
    bool WXyeLjOqYNBsBGC = true;
    double VuraDlsHbdD = -182445.35335455177;
    int JvFfmnyQROJ = 383199290;
    int nxEvpYdcwSC = -1793599789;

    return NyGdwtKQJF;
}

bool jtrvMWhHe::SisOBATclnlIUYoy(int sbJIQxQGht, string XYvRchIvfgt, int iwhxDoGAzWFPvzYs)
{
    int LgEFHotLQvNldL = -1299952796;
    int GrDteJOFlvLRX = -1269107323;
    double yUGLNVUEGrKhvMh = 551145.151536244;
    string NLQcuVvEeI = string("GoYiCggJPAbNWOgmGhwJQKIOWv");

    if (iwhxDoGAzWFPvzYs <= -1327190718) {
        for (int qvhOjBIkn = 824745547; qvhOjBIkn > 0; qvhOjBIkn--) {
            yUGLNVUEGrKhvMh -= yUGLNVUEGrKhvMh;
            GrDteJOFlvLRX += iwhxDoGAzWFPvzYs;
            GrDteJOFlvLRX /= iwhxDoGAzWFPvzYs;
            LgEFHotLQvNldL = iwhxDoGAzWFPvzYs;
        }
    }

    for (int JWNZRndFWfwDh = 455689898; JWNZRndFWfwDh > 0; JWNZRndFWfwDh--) {
        continue;
    }

    for (int soexAMNrzOfsXQn = 1148169786; soexAMNrzOfsXQn > 0; soexAMNrzOfsXQn--) {
        iwhxDoGAzWFPvzYs += GrDteJOFlvLRX;
        LgEFHotLQvNldL /= LgEFHotLQvNldL;
        LgEFHotLQvNldL -= GrDteJOFlvLRX;
        XYvRchIvfgt += NLQcuVvEeI;
    }

    for (int ebUGCfikgCn = 1740605337; ebUGCfikgCn > 0; ebUGCfikgCn--) {
        iwhxDoGAzWFPvzYs *= GrDteJOFlvLRX;
        yUGLNVUEGrKhvMh += yUGLNVUEGrKhvMh;
        yUGLNVUEGrKhvMh *= yUGLNVUEGrKhvMh;
        iwhxDoGAzWFPvzYs += iwhxDoGAzWFPvzYs;
    }

    for (int ykRzLn = 885823269; ykRzLn > 0; ykRzLn--) {
        iwhxDoGAzWFPvzYs -= LgEFHotLQvNldL;
    }

    for (int dhctnqdAmPyHg = 1475337416; dhctnqdAmPyHg > 0; dhctnqdAmPyHg--) {
        yUGLNVUEGrKhvMh /= yUGLNVUEGrKhvMh;
        iwhxDoGAzWFPvzYs -= iwhxDoGAzWFPvzYs;
        sbJIQxQGht += GrDteJOFlvLRX;
    }

    for (int OsQAcmkmtZOM = 560910110; OsQAcmkmtZOM > 0; OsQAcmkmtZOM--) {
        continue;
    }

    return true;
}

int jtrvMWhHe::SLHXEDJKvaOAzKe(bool jYGVSjgawGUpmx, string hNLqWuGMwQWTZ)
{
    bool nSHbgHQGDaDYk = false;
    double iKHNCNlOUcWjxVQu = -897803.8550835102;

    for (int esIQBWVJLb = 64588059; esIQBWVJLb > 0; esIQBWVJLb--) {
        jYGVSjgawGUpmx = ! nSHbgHQGDaDYk;
    }

    for (int VWABgBgRBkoieiN = 376113525; VWABgBgRBkoieiN > 0; VWABgBgRBkoieiN--) {
        continue;
    }

    for (int mgVvCiFxEuHea = 1390771258; mgVvCiFxEuHea > 0; mgVvCiFxEuHea--) {
        nSHbgHQGDaDYk = ! jYGVSjgawGUpmx;
        nSHbgHQGDaDYk = ! nSHbgHQGDaDYk;
        jYGVSjgawGUpmx = jYGVSjgawGUpmx;
    }

    if (nSHbgHQGDaDYk == false) {
        for (int jfEsyQBcxVHdwI = 1943975368; jfEsyQBcxVHdwI > 0; jfEsyQBcxVHdwI--) {
            hNLqWuGMwQWTZ = hNLqWuGMwQWTZ;
            nSHbgHQGDaDYk = nSHbgHQGDaDYk;
            iKHNCNlOUcWjxVQu -= iKHNCNlOUcWjxVQu;
            iKHNCNlOUcWjxVQu = iKHNCNlOUcWjxVQu;
        }
    }

    return -2038697319;
}

double jtrvMWhHe::NGHEM(int KzmkOllSZP, double BGkSOUbCGJP)
{
    string DGhSYbkrCLAPt = string("v");
    bool tDIdOjnInc = false;
    int zlopUZcgFIrYRBPO = 277145566;
    int WbDlekGDapDuIZy = 543896221;
    string UKTkFjmHVFWDCT = string("cJdwSxbrqFZLJXBqEzpDxYEWAxmERVgHOJFupugMJpLdZXhvhwWeraSPmcTeMwgIAUoRMxheClLhgdUJWJSQLXYLfubDVihCcRjdkRyYBPZiRoVNCtQaqrDQnnrRfIwvaMRoBwgoeCcCXpAPPZczgPnhsLnQwojmcJUudBFkCaZeQo");
    string ZeJjDHFMMgSjpTkC = string("DWlNMmLoWDcqHHdeyKEiffPLchKIyjDiSgsBmManCjOeacRLDYOtZPQpDIGwQcobaKIqrHNFfnsKSNhoPlVlhZZtQOSQnKmMRmRzywQFrL");
    bool mpRpoFSrn = false;
    double avJMSWhQaSawWGA = 268114.5293241541;

    for (int XURndl = 513724872; XURndl > 0; XURndl--) {
        BGkSOUbCGJP = BGkSOUbCGJP;
    }

    return avJMSWhQaSawWGA;
}

bool jtrvMWhHe::dSkZiLw()
{
    double agCWdN = -380728.8471104475;

    if (agCWdN < -380728.8471104475) {
        for (int zKdYWTDzaFLGxrx = 1511688945; zKdYWTDzaFLGxrx > 0; zKdYWTDzaFLGxrx--) {
            agCWdN = agCWdN;
            agCWdN -= agCWdN;
            agCWdN *= agCWdN;
            agCWdN += agCWdN;
            agCWdN *= agCWdN;
            agCWdN = agCWdN;
            agCWdN *= agCWdN;
            agCWdN = agCWdN;
            agCWdN = agCWdN;
            agCWdN = agCWdN;
        }
    }

    if (agCWdN >= -380728.8471104475) {
        for (int dLwLi = 2095950918; dLwLi > 0; dLwLi--) {
            agCWdN = agCWdN;
        }
    }

    if (agCWdN >= -380728.8471104475) {
        for (int SaZBnxHULOnZU = 1846993606; SaZBnxHULOnZU > 0; SaZBnxHULOnZU--) {
            agCWdN /= agCWdN;
            agCWdN *= agCWdN;
            agCWdN /= agCWdN;
            agCWdN -= agCWdN;
            agCWdN += agCWdN;
            agCWdN *= agCWdN;
            agCWdN -= agCWdN;
            agCWdN /= agCWdN;
            agCWdN = agCWdN;
            agCWdN /= agCWdN;
        }
    }

    return false;
}

void jtrvMWhHe::cRqdu(bool JbLoKI, bool TiQGFOXrcrvrGQxZ, int cqGnpnSbuh, int dvKDATqGQK)
{
    bool iMlCs = true;
    int XbjpKIOP = -1583893350;
    double HKkolIdRtoLyCbfc = -1019491.5956166089;

    for (int dFDicedkpFS = 1571707928; dFDicedkpFS > 0; dFDicedkpFS--) {
        continue;
    }

    if (TiQGFOXrcrvrGQxZ != false) {
        for (int kuShyVbF = 1719309997; kuShyVbF > 0; kuShyVbF--) {
            continue;
        }
    }
}

jtrvMWhHe::jtrvMWhHe()
{
    this->ozhIpqyu(string("QWXEKBTqqJCIdIfIdzNCJSSpQBPIyCihPsPRDdxSbnONwJIvJhqJFqvCheHaoKHabVgDGlEAKNpnvdCtfpTlOEFuZZvBHRJKnnYvrGeaOKzvDIpFFYcyGPVPGDYAJBlpije"), -967726.4684979335, -857768.3131221717, 976711.4877147803, false);
    this->fZdOqNEQ(string("twGhGVQDRlHekmRLfcTFOLYCFHeoGruCRfDWFTEOjRcurkbaPYwbagYPbXgvrwgwEgAyldNNjQLsHB"), -891805201, -572242.4464371363, string("vZOyDEmByPkhDXXvHLDPRYTvDnUMtxbgPdwoSuNouZpIjqvPyiXIvNjEvWkHncziDpEaYtrlhrmWrrkeWrLcwVSOflpfreLRSLgQQzyUVIffGpiTUkfHTFxqBkJOfNT"), 354420568);
    this->AFKFTTl(string("CzkczLNkblgWXOwHnABYXeSTXXdgFkjyHvYfnOQhmPydTlILfiynRqLUzyUCCMKSPgfwkOVGaHrupArFCfsBOBvJDdeMJaPTzHdSeMckAmXjPgFQCcUMZUeastGHKUI"), 13912.296175118383, 522017111, 541371.3525590214, 613938605);
    this->kZfBsS();
    this->HluMAcnJxjHXKO(false, string("KwIVluLKwLigtyxSUgeoqWRFoUZoVqQEEvkflwXUPZeypAcDaqQWPmysoepHLHCWCDufBLheJbCgiVMkHLhWnPPtFUTIJcZJOaQoYobiuesoApPwWyAicJWUYyBXfUKmIwTDQGrrjeBDKlJrhdjrjBRSvSakstxobkbJHLvlZGIGZOKWsaHHrkZqzUho"), -1250962270, 828771532, true);
    this->SisOBATclnlIUYoy(-1327190718, string("OoMDcQxLGAXP"), 1833921455);
    this->SLHXEDJKvaOAzKe(false, string("ZbUUhPgcy"));
    this->NGHEM(-1380249195, -573531.0421790183);
    this->dSkZiLw();
    this->cRqdu(false, false, 1059735835, -873877242);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XvBvSiFuKLrofBsB
{
public:
    int bquEP;

    XvBvSiFuKLrofBsB();
    bool kbFpKpYsnqK(double JjrazEeEcBOULv, string UpvbuGYD, bool GaQKTHHDOZSGqgmY);
    double yWRFFwvO(double KVWhKgVFe, string xsIlOB, string nUDwMur, int bTtAIUMJS);
protected:
    bool XuhAJNeTQBfOV;

    double rKwOTV(bool qtyVr);
private:
    int ueEPaLoypXMEhUkH;
    string bNLTtS;
    bool FOYlrxwdZXTSE;
    double yJZKBbZim;
    int eOcKoYaiJoxxy;
    bool WOYqExjMcnUxABb;

    bool zEMOb(string kJHCBqlLauFZazI);
};

bool XvBvSiFuKLrofBsB::kbFpKpYsnqK(double JjrazEeEcBOULv, string UpvbuGYD, bool GaQKTHHDOZSGqgmY)
{
    bool TyXznSQSwpoN = false;
    double EJikBlMpR = -330234.0962576586;
    bool yllofaEa = true;

    if (yllofaEa != true) {
        for (int yoOqTYkcsHdEzTAr = 1798338952; yoOqTYkcsHdEzTAr > 0; yoOqTYkcsHdEzTAr--) {
            GaQKTHHDOZSGqgmY = ! yllofaEa;
            EJikBlMpR -= EJikBlMpR;
            JjrazEeEcBOULv -= JjrazEeEcBOULv;
        }
    }

    return yllofaEa;
}

double XvBvSiFuKLrofBsB::yWRFFwvO(double KVWhKgVFe, string xsIlOB, string nUDwMur, int bTtAIUMJS)
{
    string xFYBtmUMri = string("eHarKayW");
    int tWhWvtKlwZWTou = 1892652133;

    for (int tXKNSkqXMWipgegX = 1909538435; tXKNSkqXMWipgegX > 0; tXKNSkqXMWipgegX--) {
        nUDwMur = nUDwMur;
    }

    for (int KxLgHKdBx = 1020722948; KxLgHKdBx > 0; KxLgHKdBx--) {
        nUDwMur += xsIlOB;
        xsIlOB = xFYBtmUMri;
    }

    for (int FGpmQgFObxzHD = 1368588411; FGpmQgFObxzHD > 0; FGpmQgFObxzHD--) {
        bTtAIUMJS *= tWhWvtKlwZWTou;
        xsIlOB = xFYBtmUMri;
    }

    if (xsIlOB != string("GRLCWDAAnKULVMjrZHLuBBDGzQvDwSPdbJewzmExHGQMRSuLtwutNzEEQCPyknlopwqGpLrrlIABJQLUcZpNhiwzLdMiyOJdzGmPQNJpWZYQByfpLVcsDeOkZIETIvdaHMlXmwCtOKZToyPPbMIEl")) {
        for (int RPwEG = 898227733; RPwEG > 0; RPwEG--) {
            tWhWvtKlwZWTou /= bTtAIUMJS;
            tWhWvtKlwZWTou *= tWhWvtKlwZWTou;
        }
    }

    if (xsIlOB < string("GRLCWDAAnKULVMjrZHLuBBDGzQvDwSPdbJewzmExHGQMRSuLtwutNzEEQCPyknlopwqGpLrrlIABJQLUcZpNhiwzLdMiyOJdzGmPQNJpWZYQByfpLVcsDeOkZIETIvdaHMlXmwCtOKZToyPPbMIEl")) {
        for (int BArEVwHbqJdHl = 1436223140; BArEVwHbqJdHl > 0; BArEVwHbqJdHl--) {
            xFYBtmUMri += xsIlOB;
            tWhWvtKlwZWTou -= tWhWvtKlwZWTou;
            bTtAIUMJS /= tWhWvtKlwZWTou;
            xsIlOB = nUDwMur;
            KVWhKgVFe = KVWhKgVFe;
        }
    }

    if (bTtAIUMJS == 732768272) {
        for (int QkwWGTcmsOO = 190768620; QkwWGTcmsOO > 0; QkwWGTcmsOO--) {
            nUDwMur += xsIlOB;
        }
    }

    return KVWhKgVFe;
}

double XvBvSiFuKLrofBsB::rKwOTV(bool qtyVr)
{
    string ftEeDTApnr = string("hQXzQqCsmlCiTtpcxmOmiXYqYZrZGu");
    string PnLdGM = string("HcsqTprMYocdYfNvuXerWcTLgBNdYUNeBZABVfDdZGvyTZhpBnZtmNUIRjjOmtIOnbTOkvFqJqVlXcUTSTdmzHZLwAWsaujThcwzdeWjrINaCCTFrqSebZUcLgdaMMfAeCKgZmaeLqoZnZMcsbwRqpVxnKffcqnQYzgLBOtRVvsCvoWcwevWRbdfhvwyXAUOUGrBkWJtrKEsgsNCukrCvVDTxvKPAKaZHhzCFafRmtyEwdooIBzvTaEHPUKgu");
    double YRpxBFIYZGiKEpm = 490326.5772788485;
    bool qenjYtMwpOU = false;
    double bFBsCT = -935789.0211564038;

    for (int WJLrJGDR = 638958984; WJLrJGDR > 0; WJLrJGDR--) {
        ftEeDTApnr = ftEeDTApnr;
        qtyVr = ! qtyVr;
    }

    for (int xYnZbhGTo = 2118417349; xYnZbhGTo > 0; xYnZbhGTo--) {
        ftEeDTApnr += ftEeDTApnr;
    }

    return bFBsCT;
}

bool XvBvSiFuKLrofBsB::zEMOb(string kJHCBqlLauFZazI)
{
    int tGuGAqQUi = 1912336642;
    bool mymTV = true;
    bool HxlZKppAoeM = true;

    if (mymTV == true) {
        for (int bEIkAGM = 1780191292; bEIkAGM > 0; bEIkAGM--) {
            continue;
        }
    }

    return HxlZKppAoeM;
}

XvBvSiFuKLrofBsB::XvBvSiFuKLrofBsB()
{
    this->kbFpKpYsnqK(394587.0622663082, string("yuXZUjXKtWQAUryDBRqkyQTxcmXuuQjasUymczlpkPsIuQKonagRwfsQveUkSURpdoBpFXxvJbwxkGkXilz"), true);
    this->yWRFFwvO(-811933.6260399694, string("GRLCWDAAnKULVMjrZHLuBBDGzQvDwSPdbJewzmExHGQMRSuLtwutNzEEQCPyknlopwqGpLrrlIABJQLUcZpNhiwzLdMiyOJdzGmPQNJpWZYQByfpLVcsDeOkZIETIvdaHMlXmwCtOKZToyPPbMIEl"), string("YcCqraMqQelEJnYqBItYyjIQdbzlSzeOKhsBPjtepvPUuJMzZIUGINHIsmNZpVlwfSDXLyRuZXcmMTYxVdvvrg"), 732768272);
    this->rKwOTV(true);
    this->zEMOb(string("jjviAwddFjdvwxNNtoziDZrLwdBdMcLmwVWajmBKqpvhNWQaCjoHuRdLwQknrlNPtlpBQHmhAgjLLPcOqZxcReyGSSwDBFFfTKLPAakuNjGSlXwHaFFadxmANqwimITL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mkmnAmBlap
{
public:
    int TKAhxOitM;
    int dqWFo;
    string nKfGgdHXRUH;
    double pZNgW;
    double MfjvdEiFi;

    mkmnAmBlap();
    string DIiWlJTodhlKs(string YSbHDiG);
    void BEXZnfS(int jrqImmoJCGbYFj, int AaHcll);
    double cznSpjtadNThEG(int IiiCbucVVlBgHHPl, string kZkYlptmCsMDOpGy, int EQylIwQ);
protected:
    double vlsOzEDKTOH;
    string RuaWlTcZIgBFQe;
    bool taTjF;

    void aGjRhqI(double piNimhOWVYUfV, double lxdgx, bool IuVWgzoKyfEVBt);
    int IuMQKmqgOOHMK(bool rIwYYeeiGXLH);
    double WTDOMSkvbyVmhmP(bool BcWLkTbT, string msVqQQZFi, bool DHNpaUmWn);
    bool xUDWrMHNzX(bool HxtqkrQWMmdhO, string LCWSNLp, bool kmQyCDTVrL);
    bool aLweeLelEnOedI(string YZiLEetUPufXgpCt, double xLmPWSaNmuEosLH, int ixjZrXPykGvpQvxn, double HFJxSRG);
    double XdqbNJxYiTp(string LBfIWtHmAYCVJb, bool yVusRa, double TwRlamURStYanU, string btlBhfOhQu);
    double IeIOsKKCfiVjCnG(bool zRGdrHnzvuYVbQP, string zgsYvqeRV);
    int anVbgw(string Fuahnqxjb, double KVOJrxBZvQnDcsIM);
private:
    double deMReMnabJNjU;
    int LpTJH;
    bool SZDiAGlpaPK;
    double VYwuqumfFFQSf;

    void KTzbqUIbw(string WqNhZukiCg, int PhgpTvXTDXDhHwY, string IKNTsNOyIVaZXS, string AJhHt);
};

string mkmnAmBlap::DIiWlJTodhlKs(string YSbHDiG)
{
    double HPnBqrYhe = 405543.85346677393;
    bool OCTKqOk = true;
    int PbzKutRe = -478220744;

    for (int wcvcxyXMM = 1583880417; wcvcxyXMM > 0; wcvcxyXMM--) {
        continue;
    }

    for (int yXbscguJzLQAZ = 1710198029; yXbscguJzLQAZ > 0; yXbscguJzLQAZ--) {
        HPnBqrYhe += HPnBqrYhe;
    }

    return YSbHDiG;
}

void mkmnAmBlap::BEXZnfS(int jrqImmoJCGbYFj, int AaHcll)
{
    int tYsMMcYXyrImL = -2043782356;
    int NiVmxOeqK = 96124146;
    string jKHgRdfFhutM = string("lOwbnOoKUVObtBSQIDOJLiPnfiIzDbpBtwIBWNamzUDVEXVXYqWjSDoNCreFFTspQCcUTJHZwAKyYTmAGqThQKAyqmGERRPSpjRl");

    if (jKHgRdfFhutM > string("lOwbnOoKUVObtBSQIDOJLiPnfiIzDbpBtwIBWNamzUDVEXVXYqWjSDoNCreFFTspQCcUTJHZwAKyYTmAGqThQKAyqmGERRPSpjRl")) {
        for (int WTyTZhlqnwGmV = 1565226771; WTyTZhlqnwGmV > 0; WTyTZhlqnwGmV--) {
            AaHcll -= NiVmxOeqK;
        }
    }

    if (NiVmxOeqK > -622555223) {
        for (int jqEvRurzPpVsTWgS = 2016004361; jqEvRurzPpVsTWgS > 0; jqEvRurzPpVsTWgS--) {
            NiVmxOeqK -= tYsMMcYXyrImL;
        }
    }

    if (NiVmxOeqK >= -1306745335) {
        for (int Mrmcaw = 509955947; Mrmcaw > 0; Mrmcaw--) {
            tYsMMcYXyrImL /= NiVmxOeqK;
            AaHcll += jrqImmoJCGbYFj;
            jrqImmoJCGbYFj /= AaHcll;
        }
    }
}

double mkmnAmBlap::cznSpjtadNThEG(int IiiCbucVVlBgHHPl, string kZkYlptmCsMDOpGy, int EQylIwQ)
{
    int YqptimdnIrRxVoS = 206617059;
    string fDFuYgIQXWeZlTnB = string("ykKVkkZIDFLDijQCIPZJjSnWRYMaxAtaScDWYOyyDfxHsdFzIYDaUpSGaPOGVjjcOTcqTdSKbSWGFSchhtlNmybXBYTrXVBsilQOZsTuPghZQmasAfsYbOGEnryHKFOAMUgeLlNRuLH");

    if (fDFuYgIQXWeZlTnB != string("VVJWBPdUOGXgHnxaiiAeLKfWZozhfHWCjSECxcEWQHtoVbRlCqrqyzPkBMGlNygqvAoIXQWkiAvnpptdDdmrFOPrPTPpaxREZNxXVyEgmSNWICmrkkoROtzUsJqxWtoZfsLRBdhnJsCwnyCvftlsQvWWwjqERsSAhzjjhWBwCGOdokEpxNbrcCxQIVM")) {
        for (int UqvCjzUYtdZN = 2090308984; UqvCjzUYtdZN > 0; UqvCjzUYtdZN--) {
            kZkYlptmCsMDOpGy += kZkYlptmCsMDOpGy;
            fDFuYgIQXWeZlTnB = kZkYlptmCsMDOpGy;
            EQylIwQ *= IiiCbucVVlBgHHPl;
        }
    }

    return -95942.54615577268;
}

void mkmnAmBlap::aGjRhqI(double piNimhOWVYUfV, double lxdgx, bool IuVWgzoKyfEVBt)
{
    string LXQGEdDCuqq = string("tnyDTCmhgloijRAaFNFQzGNXWNdUpKMbnN");
    int xdKXxHJKKuWU = 1069364721;
    string Mulqr = string("jxSuxxpXeQOijszrkNevkEMWqzuzzIChdLZqZhcarZERBcnbePCaEjogxnfRxCOgLKEXvFizRbGCwnlWSHojbJLQQrajSsAlxtryxDGeLXnIQnRFPfnEKfpidfNnNybeegJaxjTWeITSDRSlIdsJhqsHwbNAHqHFydbTsEvoOPBzhzPiRYBGOGemTifP");
    bool wItaTrr = true;
    double zUByMrrcQdEvlo = -711426.8307540865;
    string KWCfOZvstjilr = string("ngRXoYcQHzZLAEPHEhcSQlGHeONCsfFhSqUkjNmYnyTJGVlINxzngtUPklxfPgofPZRisQaJCptpfYErKBsNKpqlZdUGXUbUCVVYcffTn");
    double uTfRtPxicLWMqb = -792012.3844298277;

    for (int xAPWdL = 99496393; xAPWdL > 0; xAPWdL--) {
        wItaTrr = wItaTrr;
    }

    for (int izuMjq = 200678077; izuMjq > 0; izuMjq--) {
        Mulqr = LXQGEdDCuqq;
    }

    for (int EBjUo = 930235392; EBjUo > 0; EBjUo--) {
        wItaTrr = ! IuVWgzoKyfEVBt;
        piNimhOWVYUfV = piNimhOWVYUfV;
    }
}

int mkmnAmBlap::IuMQKmqgOOHMK(bool rIwYYeeiGXLH)
{
    double jzxQfLPFcZCN = 124431.69486454834;

    for (int CCEkYhKPPMGFa = 555236710; CCEkYhKPPMGFa > 0; CCEkYhKPPMGFa--) {
        jzxQfLPFcZCN /= jzxQfLPFcZCN;
        rIwYYeeiGXLH = ! rIwYYeeiGXLH;
        jzxQfLPFcZCN *= jzxQfLPFcZCN;
        jzxQfLPFcZCN -= jzxQfLPFcZCN;
    }

    if (rIwYYeeiGXLH != false) {
        for (int QZTwRWwIVx = 413157730; QZTwRWwIVx > 0; QZTwRWwIVx--) {
            rIwYYeeiGXLH = rIwYYeeiGXLH;
            jzxQfLPFcZCN *= jzxQfLPFcZCN;
        }
    }

    for (int rBpMj = 1322224375; rBpMj > 0; rBpMj--) {
        jzxQfLPFcZCN += jzxQfLPFcZCN;
        jzxQfLPFcZCN = jzxQfLPFcZCN;
    }

    for (int uliWwR = 1608695343; uliWwR > 0; uliWwR--) {
        jzxQfLPFcZCN *= jzxQfLPFcZCN;
        jzxQfLPFcZCN *= jzxQfLPFcZCN;
        jzxQfLPFcZCN = jzxQfLPFcZCN;
        rIwYYeeiGXLH = ! rIwYYeeiGXLH;
        rIwYYeeiGXLH = rIwYYeeiGXLH;
    }

    return 142483386;
}

double mkmnAmBlap::WTDOMSkvbyVmhmP(bool BcWLkTbT, string msVqQQZFi, bool DHNpaUmWn)
{
    bool rlkzBBlVUm = false;
    string GUZayLmySO = string("eoIUVhhcivUvJOXzzGnVrycZLhWHoCdIVXMhwGoGpXQuWPVDWVqTIIIVPasfyDiRfWULPzkVDQlwtJqQvyNChCwjqYUMxZCNTehkdxCtAqvRHFpjMELEUomNtYrmcosriUgbfyqXzigCAUSKbRelRRWSSuCFIYLoCjwqENqRRcZGRAvHpyrfJ");
    string sBzJyjSgtfu = string("qLKTQcxCpxWxmPkFRbjvnbIyLzVmXOUbFzn");
    bool pTjVJscLi = true;
    bool QKVBjWMoV = true;
    int ehFQdXPWsVJCMPYg = -1708618641;
    bool KeyKMXiqoDkxk = true;

    if (DHNpaUmWn == true) {
        for (int mxfMau = 848202296; mxfMau > 0; mxfMau--) {
            sBzJyjSgtfu += GUZayLmySO;
            msVqQQZFi = msVqQQZFi;
            sBzJyjSgtfu = GUZayLmySO;
            KeyKMXiqoDkxk = QKVBjWMoV;
        }
    }

    return 958294.1277756508;
}

bool mkmnAmBlap::xUDWrMHNzX(bool HxtqkrQWMmdhO, string LCWSNLp, bool kmQyCDTVrL)
{
    string pDxDoEVcRBiOTXP = string("bvAvrNYuETbFuYpFHJbxUBtTEBrIKVuPZMOUTYLqOtxqgWMWhLnPzMPSqKpMZcymjFkhrOvMQfBfXqjSYwlUUkAjkZTgXsRgiUAAQJOHNSkesZAUraUYAOZziseSzSwsWEjKghgpamNKDmQmZOqSGmFkuWIpHGiHeecDVlfRQTgIVkgJHPVumKiYpjiukkrNg");
    string hgrsvPOwxd = string("xeDrLrROwJcelArAKfIzRZjRSTeAuTlWiPDXZXQdhvABJGhTZzidhWOlcikbxNpHVLbGnyUlyLkuGLfeERWKHetEkjyZRUaETHDaQUiXPjeqrpNDwkxqKuAoOlrgZtONtBbAzdyfXLQOPuGWESfnLfmnTwXZAUVGP");
    int huYhmrHFsqP = -245179909;
    string imFDtAyQhRXV = string("DkDwPzryRBdXhVWlQPpPIalVYhRVJvYYqBeymeEAsrEZNE");
    int LOiKRvLyRsTwX = -861822309;
    double TAyYz = -780673.0890123496;

    for (int HUgQh = 1572715036; HUgQh > 0; HUgQh--) {
        HxtqkrQWMmdhO = ! HxtqkrQWMmdhO;
        pDxDoEVcRBiOTXP += hgrsvPOwxd;
    }

    for (int rvibLXshBOIOjD = 707836899; rvibLXshBOIOjD > 0; rvibLXshBOIOjD--) {
        continue;
    }

    for (int hBegjolAs = 88632280; hBegjolAs > 0; hBegjolAs--) {
        hgrsvPOwxd = hgrsvPOwxd;
    }

    if (hgrsvPOwxd > string("ODBLFKcapnkoEshXLolfdaEYknaVwrslFHbHwvZEUpygpKODJMJzeMOdSmTXveNlRbcN")) {
        for (int RlJUMnscwQfM = 386494967; RlJUMnscwQfM > 0; RlJUMnscwQfM--) {
            imFDtAyQhRXV = pDxDoEVcRBiOTXP;
            HxtqkrQWMmdhO = HxtqkrQWMmdhO;
        }
    }

    return kmQyCDTVrL;
}

bool mkmnAmBlap::aLweeLelEnOedI(string YZiLEetUPufXgpCt, double xLmPWSaNmuEosLH, int ixjZrXPykGvpQvxn, double HFJxSRG)
{
    bool FmMuWxvrzKIv = true;
    bool IqNpUFRCtaQnKhd = false;
    double ebUqsTzfvvkfM = -804270.2199311507;
    string GULSmaISBc = string("ScvFWKHLrYXTcdbWOmBFQfSFqZqaKghWJohUBOwgkSDFRHmwgxrPwPIZRIaKXBB");
    bool aGrOsHLy = false;

    for (int tMhgp = 2066018169; tMhgp > 0; tMhgp--) {
        continue;
    }

    return aGrOsHLy;
}

double mkmnAmBlap::XdqbNJxYiTp(string LBfIWtHmAYCVJb, bool yVusRa, double TwRlamURStYanU, string btlBhfOhQu)
{
    bool kLaRXsawNWFcHk = false;
    bool MysqJOFDJMEbD = true;
    string jwAVhu = string("YtaoooRVDtECFMJmLTJFwCYpUBqPKvmVpIJezmGOgrUnnVBWyUtYbbLqcPEKdpvuyiAWTFjmnFcUpHpBmCDBYAAInxQPvghrtFYj");
    string qmdBXZ = string("ypwHvMGZrmDtbgcFAvZydNNjZjpqbyZwUvNlOEbXOvRiKASMhailWZDdHmjUjnLRBnqbVGcAzmkRlrcnDfYiaBDjJyNdmgevZrf");
    string CigRglSfoTJml = string("XyIKOlNDQvYyvLsivyFPtucMVVklceewrgVKOQxtBtWeslziMEyGlAdLIilAvUVgkmxNdrTwLvssdmIHxoASouicJUXpqOyAGtvMtfWiALCFrZMKGhTqRCOiLlHxnFEgElFhzesMqkhOnXSusCaRZfpjCEnnXScoFUfmedmJOpJbpcvUytXPQXSCJodclGJJyyVsmwxzCqNLhmeasTegJTseAD");
    double reokBNdjpnnhhg = 986441.8601414189;
    string KgzkQVawVYGZVgkf = string("fCWxeLxNXVRDzEsNgIv");

    if (kLaRXsawNWFcHk == false) {
        for (int teGTfHZ = 1993080954; teGTfHZ > 0; teGTfHZ--) {
            CigRglSfoTJml += jwAVhu;
        }
    }

    return reokBNdjpnnhhg;
}

double mkmnAmBlap::IeIOsKKCfiVjCnG(bool zRGdrHnzvuYVbQP, string zgsYvqeRV)
{
    string MVnUXkWYqQkBqwR = string("tzhLuWgSeSKToaDjELBfiewYVgkxptpaPViYZXVJXwNygCcJKSWhrqyoXepksiavuMNWMMDSsGLwSBzyvEqspbggSsUEcFfNItcStGrcuTUqIINOgyMizsMQDJXutWesQGjYejUX");
    int WIiLozBXMfNUAVC = 1665522937;
    double sRIsnoYByASXD = -544937.197417551;
    int euKrzyJFacYguR = -1103954358;

    for (int IMGRI = 1781807740; IMGRI > 0; IMGRI--) {
        MVnUXkWYqQkBqwR = zgsYvqeRV;
        sRIsnoYByASXD = sRIsnoYByASXD;
    }

    for (int kvHTVsdOJ = 1095219928; kvHTVsdOJ > 0; kvHTVsdOJ--) {
        euKrzyJFacYguR -= euKrzyJFacYguR;
        MVnUXkWYqQkBqwR += MVnUXkWYqQkBqwR;
        zgsYvqeRV += zgsYvqeRV;
    }

    return sRIsnoYByASXD;
}

int mkmnAmBlap::anVbgw(string Fuahnqxjb, double KVOJrxBZvQnDcsIM)
{
    string nuxCnikKApCzl = string("eyKLFNBLLBjrdPZZkuVwFhxKEloKBMvlOXcgMJqGxcCIrytwYQSWSbggBtTzXzzmLEaKMcueEcIrtmiWUARFRBZpyqSduKZjDFkiXIastsUMcKhOGzRLiwrQCTDSLiMTPTYPZhwhHZTljgRWeDRHINMneExaYjtVpEKmJK");
    bool gPTgPUAmcAaKZ = false;
    double UZEhQWeTpvYki = 627337.8915858418;
    string FwTyzaheqZQr = string("kcyTUTSrEHKokqUqLZgXTzxYDjHaTGmTstmXDUYCDAXFNoTszfcmrZbmz");
    int BozfiNWUwFSIVInY = -760696276;
    int RQfVCuI = -2081114962;
    int cbpxzJpKTNY = 1062645248;

    for (int uQhmgB = 312462125; uQhmgB > 0; uQhmgB--) {
        BozfiNWUwFSIVInY += BozfiNWUwFSIVInY;
    }

    return cbpxzJpKTNY;
}

void mkmnAmBlap::KTzbqUIbw(string WqNhZukiCg, int PhgpTvXTDXDhHwY, string IKNTsNOyIVaZXS, string AJhHt)
{
    bool aaUSgK = false;
    double hGAQhtXujYOMetbX = 923012.2491122861;
    bool BRbYsVfFQqXmH = true;
    bool SGDXnlrBNhriwYAh = true;
    bool lNAXGCDCwDQ = true;
    int TxLvSAWGNrGk = 1498958981;
    bool hslhDUIvI = true;
    double zlvoTUaLgWzOtGr = 890325.2895127705;
    int fUnDxFBfvFOs = 1804737030;
    double tJBGBluggXJA = 28857.134459108784;

    for (int pApgQGGIJepKUfG = 1465811840; pApgQGGIJepKUfG > 0; pApgQGGIJepKUfG--) {
        aaUSgK = SGDXnlrBNhriwYAh;
    }

    for (int ikbkdrz = 47145971; ikbkdrz > 0; ikbkdrz--) {
        hslhDUIvI = ! lNAXGCDCwDQ;
        SGDXnlrBNhriwYAh = ! aaUSgK;
    }
}

mkmnAmBlap::mkmnAmBlap()
{
    this->DIiWlJTodhlKs(string("DILhePFnedNzbAIHPhiXdntQDzUwvNmfgBIeVnmHUDoVOSExtHerhKLVqpbYLzXUEXUEQQNRzMtsmgWsBWqIWCBGVgfULGTgmbNwMGIcxoEvHCicehGvxKIowbvfiYPOMCaabYY"));
    this->BEXZnfS(-622555223, -1306745335);
    this->cznSpjtadNThEG(1178604783, string("VVJWBPdUOGXgHnxaiiAeLKfWZozhfHWCjSECxcEWQHtoVbRlCqrqyzPkBMGlNygqvAoIXQWkiAvnpptdDdmrFOPrPTPpaxREZNxXVyEgmSNWICmrkkoROtzUsJqxWtoZfsLRBdhnJsCwnyCvftlsQvWWwjqERsSAhzjjhWBwCGOdokEpxNbrcCxQIVM"), -153307588);
    this->aGjRhqI(773908.2424968539, -369617.81324776803, true);
    this->IuMQKmqgOOHMK(false);
    this->WTDOMSkvbyVmhmP(false, string("tgJwZFSApMtlfCCELfwKIxLRtLlfYWQeOLdNzeRZjwPOmpvDRLavSDZoICOoUNJzJAdJDAxZyTIZmitswIophblbxFmCSYhbIXfjofvzGdvCyniwkShRBgqrGBLcSXjmQHFCJQNTjR"), false);
    this->xUDWrMHNzX(false, string("ODBLFKcapnkoEshXLolfdaEYknaVwrslFHbHwvZEUpygpKODJMJzeMOdSmTXveNlRbcN"), false);
    this->aLweeLelEnOedI(string("ViKswSQSZVWDDlnuImveWhotcjhxNfEmINfidtZphrOBIkywCUTytvPkZEcXDhGmxMnxGPUUAzVJIicTlVUQKjtuNiKiybWfXHdpzqjYOLBAsXlzcwOMmFztynLnZqLBYjVoWpbawCugVVZcVPBTVAIjIthYvRrFVUcHIcUQiDwAKWUGnUXfpDELSypkQlmBpIRmfQDzLzQYVormvkhMXltPVXQoVoqrEGAfPZBICrDLCbhicdaSwDt"), -44599.310037358264, -1694602571, 828981.3335667744);
    this->XdqbNJxYiTp(string("SlOswQnEZeMtXSSCiVOgdmamCRjMAsqLvBJVRilOyoCJBGRHIAqmOLTtoBKcaxsmblHtImRYELNedNqwARkVplPbuNUnwGBvOizlAJMuDxamDmoUsbuAbRulQFBOVPtRmBPPeaAvbGsHnOPtXfFCVRgqLneDqkjseGbGSJVmtlQvvRuWZJWUHTKdAGbjBvEXHZKgiYsVjLSnxtglCTxdRUcLjniMNILslSuOaKem"), false, 990724.615468163, string("NWuHsFRVuzfvOGLnCTZJTvuTLrmuvvrlsukABdlLZNJemxXRYmRnEKRfRRrHLGNAZEYmUfgDYykYXWEIZVxeRZtfVUsdwFedQZASKZPJrj"));
    this->IeIOsKKCfiVjCnG(true, string("YPGMXTBtxYkVEYsIyhjLlOiJYXChISmggHRkRpI"));
    this->anVbgw(string("MESciahhZskVsFSbodzhPUqoLXEkTIIfOiZksRspexOtoPbnBxUzGsMeHovNJEpLEMfyEXuJpHngAoctmaEJaHSjwMdfrnLvbcTkCFEmCJB"), 949499.2222722349);
    this->KTzbqUIbw(string("dkbvpAiLnbkTeP"), 10498678, string("eACFMNRhenwtYOCSYgSWUfhMYHCeJbrhxoIcZhQSAtPGygYgeFVVtHwOVgcLEqohiuOTBTcvCmfRdrTwqHlynWFhBeVITchQwEoOdBGZqnQPiyzZAYzKpmVwRztWBJhFLCeuZaMHDgAcIcJrxPmYQxlGnzkzCkqiNbiqVaigWaFDbsNvRHayVGgjAcoZiDfjddVYfTpIamAHYftELqOAelv"), string("kuyXPsthLrHYnoUAnYyhIetJDNarLYBeVLNteBKSjtKAwjPbNnEVhUWWPTqCKCPYWHWiLTPStkaSRACpdATeWcOoWWFprmPCOlXqYPudNPUoSMVuZDXsRtYzNDWgPvLabRIxXfOTnKwCjhqabayBHEFBXRbADHXNkzTnEkYMNcqlgKXfmPrnWDmncHIgqEjOiSypaVxOKj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class afQIcJdGHJ
{
public:
    double fybfO;
    int rUvQGSLEaXEfBUF;
    string yxNMmzoOdeppJ;
    bool ukbIwTcVXzXag;
    double IjDoCLYUhe;

    afQIcJdGHJ();
    bool XRADeBFuTAbtRM(double rJTDjTxfjEcw);
    int GwMyvEyj(string scsJU, string gFWurSy, int bHBQicAoceB, int kdPkHQJcIc, double TVBBNpaUbFdmeuBm);
    string ctXfd(bool HqimeHhhXBr, bool Lpfbwwlf, double BmfdSxgBOJygg, string wUJjKMQOpFQXMX, double bBRJw);
    void VCESlXxIyntd(bool ISEyjCCT);
    bool nEXcxfonFZO(bool AMwJcroVOlMe, bool baVYesRlJRJu, double VrefLVRVZyypxi, bool vyOnPIgHngHUE);
    string UbWIfeFeJZAKPjZ();
    void WaQToMQdrX();
    string rZOVnFzdUsjA(bool GySURrrhN, double WkEdgTBrIWrIVjNP);
protected:
    string tblhiRVIydhb;
    bool gcuuP;
    string PzmcR;
    int EmLYr;
    bool jJqrJ;

    void XSgfImlzgkUqPd(double kUFOZNbq);
    double cXKRBRlc();
    string EQScmQfTL(int DiuKbdA, int LogNhGeZmDuT, double UaeZFKvNm, string rUTOAcNbefqhWm, bool RVPmPWNTsVuqGx);
private:
    string jvBxNXSxYYhV;
    bool cwvLjbDX;
    double gyGcPvBYX;
    int JJtZN;

    int kffbA(double afsnYFEEqJ, double JGwGizmkNPXQ, bool hLwSUBR);
    bool vJQybDHHVtFkD(int rmLJbu, bool GseImLIkvDea, string ONNSmzzA, int mvaOBPFPyGKKjR, int qGhrqjEiRCIzQ);
    double IUTumpfy(bool NHjVapxr);
    int wsrFdNQazMzjY(int ANdRzPa, int gbANkZqlqHnzs, double IWsTxmql, int fosmYF, double xSjIp);
    string AoMetsRGPAtT(double UUDSzJSoNZD, double dOCOEHutRohviT, bool RgJQE, double hOTpslGcja);
    string jsiinywlgyKUGEx(bool xGKldSSSYGst, bool nYvJuMJiRMSOuN, double TrhEZ, string LhzJlB, bool NkTsb);
};

bool afQIcJdGHJ::XRADeBFuTAbtRM(double rJTDjTxfjEcw)
{
    double uWzXa = 322484.23573478713;
    bool qWzAA = false;
    double AYapiVa = 721459.3203054047;
    double WjzJLA = 1037814.8884043738;

    if (WjzJLA != 1037814.8884043738) {
        for (int FLzmBmZJJGJvzc = 1040069694; FLzmBmZJJGJvzc > 0; FLzmBmZJJGJvzc--) {
            AYapiVa *= rJTDjTxfjEcw;
            AYapiVa += WjzJLA;
            uWzXa = AYapiVa;
            uWzXa = rJTDjTxfjEcw;
        }
    }

    if (rJTDjTxfjEcw >= -545836.290242692) {
        for (int klGpGWmmk = 464285449; klGpGWmmk > 0; klGpGWmmk--) {
            AYapiVa /= AYapiVa;
            AYapiVa += WjzJLA;
            uWzXa /= uWzXa;
            WjzJLA += rJTDjTxfjEcw;
            uWzXa *= WjzJLA;
            rJTDjTxfjEcw /= AYapiVa;
            rJTDjTxfjEcw += uWzXa;
            AYapiVa /= AYapiVa;
        }
    }

    return qWzAA;
}

int afQIcJdGHJ::GwMyvEyj(string scsJU, string gFWurSy, int bHBQicAoceB, int kdPkHQJcIc, double TVBBNpaUbFdmeuBm)
{
    bool QPzLwnyXmfJBIKDu = false;

    if (gFWurSy != string("usumHjRBIGqRfdCHluMlPrdPfBguYftOfayCSKxryugJRhtmkEaA")) {
        for (int TsABUGpjee = 2094670032; TsABUGpjee > 0; TsABUGpjee--) {
            kdPkHQJcIc *= kdPkHQJcIc;
        }
    }

    for (int ptUSTVMwslAVfo = 1064753709; ptUSTVMwslAVfo > 0; ptUSTVMwslAVfo--) {
        continue;
    }

    for (int Dbgor = 361881903; Dbgor > 0; Dbgor--) {
        QPzLwnyXmfJBIKDu = ! QPzLwnyXmfJBIKDu;
        gFWurSy += gFWurSy;
    }

    for (int QKRJQyAtBA = 1084235190; QKRJQyAtBA > 0; QKRJQyAtBA--) {
        scsJU += scsJU;
        bHBQicAoceB = kdPkHQJcIc;
    }

    return kdPkHQJcIc;
}

string afQIcJdGHJ::ctXfd(bool HqimeHhhXBr, bool Lpfbwwlf, double BmfdSxgBOJygg, string wUJjKMQOpFQXMX, double bBRJw)
{
    string BPbGmwrwD = string("RdgaVeGIxksWkLfktJtgQpjkLJIVhARdqhDELWudhvVWfWnIMEQwpjqyEaNrbsQwhOYKUyccomfOXpymdHHPItrwMhwnAQeQUFKHQKJdnHWirTpTblYnVJwRyHxiTDcFztWlMeEGeUQAnoiSAlPspsvVAEWcndxon");
    double PXMlxBh = -470285.3650083405;
    string ewrvOSZtWegEz = string("m");
    double rVDhGYcvjtDDQdOS = 423395.81699728745;
    bool FcbMh = true;
    string ATSjYkDkbaA = string("mDntjrcwoqOdbJnHNICRlIdsofLZyofThgmyounsogQjhjYaxBtrxFdyMMiyZijJXrBRDCnnIxHYASqfZVLxDHYmrYYfEOYFbfDZUOCTwAxVtbyPtITjCtdksgJGdHDXiZjKZevlevlPTLYGPplsvRJpLhmyjSaAsNzNMFuDvfXDWgqrNfEmjPzHmDKfEIkKBnTZRDUMNdVrIBbmeLrwfMLIHeo");
    string etfyhGhQxas = string("VMgmgGByWZkcuNnvkVBnpFViglHjAAWkwRBhoZVoDiPmsIOGHnaAMxbaFLXwCiKJffUkQVwEQrBHdakdVFlUwgsNqowWpcKLQAhugTbuKNVsYnTUAGVwnkkrtRZCpLM");
    bool ONhgnOw = true;

    if (PXMlxBh >= 886164.3521456219) {
        for (int qtmcGRzItdSQ = 1566458403; qtmcGRzItdSQ > 0; qtmcGRzItdSQ--) {
            FcbMh = ! HqimeHhhXBr;
            BmfdSxgBOJygg /= rVDhGYcvjtDDQdOS;
        }
    }

    for (int wwUStuYIeBi = 608078819; wwUStuYIeBi > 0; wwUStuYIeBi--) {
        FcbMh = ! ONhgnOw;
        ewrvOSZtWegEz = ATSjYkDkbaA;
        ewrvOSZtWegEz = BPbGmwrwD;
        Lpfbwwlf = HqimeHhhXBr;
    }

    if (PXMlxBh != 423395.81699728745) {
        for (int pjrATSqEG = 1508123816; pjrATSqEG > 0; pjrATSqEG--) {
            continue;
        }
    }

    if (ATSjYkDkbaA <= string("mDntjrcwoqOdbJnHNICRlIdsofLZyofThgmyounsogQjhjYaxBtrxFdyMMiyZijJXrBRDCnnIxHYASqfZVLxDHYmrYYfEOYFbfDZUOCTwAxVtbyPtITjCtdksgJGdHDXiZjKZevlevlPTLYGPplsvRJpLhmyjSaAsNzNMFuDvfXDWgqrNfEmjPzHmDKfEIkKBnTZRDUMNdVrIBbmeLrwfMLIHeo")) {
        for (int nOhntTElQlvo = 763005599; nOhntTElQlvo > 0; nOhntTElQlvo--) {
            etfyhGhQxas = ewrvOSZtWegEz;
            ewrvOSZtWegEz = BPbGmwrwD;
        }
    }

    return etfyhGhQxas;
}

void afQIcJdGHJ::VCESlXxIyntd(bool ISEyjCCT)
{
    int cDRkKIPhrSblOD = -765061302;
    int oSzXTMGpBgSGxV = -165400184;
    int cLNOttJrJF = -349916030;
    bool ZhBeIIGAXc = false;
    double mquwh = 208115.97982217217;
    double ZPsdnKGSTLRv = 826010.5518782274;
    int xyChawNO = -1349362268;
    string yHjBMyriU = string("EWXyAkdCWGpIVBSORmsGVvGaOFdnLyFc");
    string rlPuWvPpmhMxGB = string("aeFbCfQJeUCvPRwPpWHuwIDvtApPxrMnUIzrQWKmMnBgLd");

    if (rlPuWvPpmhMxGB <= string("aeFbCfQJeUCvPRwPpWHuwIDvtApPxrMnUIzrQWKmMnBgLd")) {
        for (int FOjZgywZiW = 815179246; FOjZgywZiW > 0; FOjZgywZiW--) {
            cLNOttJrJF -= xyChawNO;
        }
    }

    if (ZhBeIIGAXc != true) {
        for (int RkLAxkLcGCRoNo = 1574220899; RkLAxkLcGCRoNo > 0; RkLAxkLcGCRoNo--) {
            continue;
        }
    }

    for (int KrjWdu = 1634779433; KrjWdu > 0; KrjWdu--) {
        xyChawNO *= oSzXTMGpBgSGxV;
    }
}

bool afQIcJdGHJ::nEXcxfonFZO(bool AMwJcroVOlMe, bool baVYesRlJRJu, double VrefLVRVZyypxi, bool vyOnPIgHngHUE)
{
    bool ShbAQKCeTB = true;
    string mEFWllqnOMR = string("zTnPMgEYLkHBRbGgkEEHXLmVuCWsEMELaDsezibIBRFmhowZjndlNrfiRarsaTHxJwndgKeScpHbCiaSbpcGwXaqxjPpXyNBFYcNUhwLzOXEWkccKuxQWOTMpPkclAeNMzBNhkcdrwDwGZwRijrCAFNpseaNivLLUaWjtnTTHHZRDWZtMMaDkEJFisrupGNhofFYsUnXzOfPvGyWZIhZKLmxPUoyHmbZi");
    double ESBkSCVwiIAcWZ = 470202.98449890164;
    bool fxYvZK = true;

    if (fxYvZK != false) {
        for (int ppBcUmzbSxgCSQm = 1853962803; ppBcUmzbSxgCSQm > 0; ppBcUmzbSxgCSQm--) {
            AMwJcroVOlMe = ! vyOnPIgHngHUE;
            vyOnPIgHngHUE = ! ShbAQKCeTB;
        }
    }

    for (int DcJzr = 265832209; DcJzr > 0; DcJzr--) {
        VrefLVRVZyypxi /= VrefLVRVZyypxi;
        fxYvZK = ShbAQKCeTB;
        VrefLVRVZyypxi *= ESBkSCVwiIAcWZ;
    }

    for (int rUgfyKSsJuWl = 1230843103; rUgfyKSsJuWl > 0; rUgfyKSsJuWl--) {
        baVYesRlJRJu = ! ShbAQKCeTB;
        fxYvZK = ShbAQKCeTB;
        ShbAQKCeTB = ! ShbAQKCeTB;
        baVYesRlJRJu = ! vyOnPIgHngHUE;
        ShbAQKCeTB = ! baVYesRlJRJu;
    }

    if (vyOnPIgHngHUE != true) {
        for (int qvOipB = 165949504; qvOipB > 0; qvOipB--) {
            baVYesRlJRJu = vyOnPIgHngHUE;
            baVYesRlJRJu = ! fxYvZK;
        }
    }

    for (int OMSEeJcdKYuEeq = 1495278641; OMSEeJcdKYuEeq > 0; OMSEeJcdKYuEeq--) {
        fxYvZK = fxYvZK;
    }

    for (int XOjdx = 735136292; XOjdx > 0; XOjdx--) {
        continue;
    }

    return fxYvZK;
}

string afQIcJdGHJ::UbWIfeFeJZAKPjZ()
{
    int rMNQoySbHeFr = 1221093394;
    double PfOYurq = -608955.3769165595;

    for (int EwYeIPxcoVTBcu = 490132931; EwYeIPxcoVTBcu > 0; EwYeIPxcoVTBcu--) {
        PfOYurq += PfOYurq;
        PfOYurq -= PfOYurq;
        rMNQoySbHeFr -= rMNQoySbHeFr;
        rMNQoySbHeFr /= rMNQoySbHeFr;
        PfOYurq = PfOYurq;
        rMNQoySbHeFr += rMNQoySbHeFr;
    }

    return string("xWJrlSRVxBYHbNshfuMOHgmmbThLGcUhPkwujuuDRRZPhivTIraqHmRHTozlnJPvvhtluxUQBvopQvz");
}

void afQIcJdGHJ::WaQToMQdrX()
{
    double rSyZnX = 235126.4629033928;
    string lrqYDykCILMI = string("AVJnOrypSFWypRDcYSZU");
    double IHlwG = 525658.3496486389;
    bool HnCYMqvrZcRIDK = true;
    bool UGnXUJiACf = false;
    int OaKyElVSyYih = -237920350;
    string kJakgJHiPMTqKiOc = string("AYxDgGfthibflNcuMWIOoIWVEbGZHEwvJZHgtjhMnkQiRtUJCOBPmOyFosUEJdIdPSBmPuEYXOnbzZWiDIaUyEHjWjddOuAaAjFQPJBUnjtYCcxgxGUuzlZkWDbcJRpnJsEWeHIOyFYDGIedNDdxZtDzutkvlxyuZILzWTjHeHrXsBZugRoEmwOfmForHfNTFMdzwljfXZAiIJDaJvhvmnSSS");

    for (int IgTwUSK = 814610011; IgTwUSK > 0; IgTwUSK--) {
        continue;
    }

    for (int iNaIAcys = 809879690; iNaIAcys > 0; iNaIAcys--) {
        lrqYDykCILMI = lrqYDykCILMI;
    }
}

string afQIcJdGHJ::rZOVnFzdUsjA(bool GySURrrhN, double WkEdgTBrIWrIVjNP)
{
    string QXKRwwrwRzyFLHo = string("ooYwLYncYHTgXhWoxbBbzgAmaUdTDfRDRJswVHQuyiezHqtdUpyLkxDAPIG");
    bool kFYeuJjg = false;
    int xXZsuoInhPkCFqD = 1249251925;
    bool avJlKddvrUWQ = true;
    string fnmmUpbZsWfJJVJ = string("KdGHWxgfBcYyaRmEVcQhKLnFyLbKaBrxACSEZUPypzmlaCUmowYbUpUJAgnASmpExRSMiVYhnuSklsFccNzWGAdcrnUsdsyVIZiXGZGARgPIujJuYpacebPgOMkyJcHxPODwSDujxNKsfnJUxlIRLPJGqYchCKZKwYI");
    int yLuovReTuizApFL = 371240690;
    string qHcjdmvMyqgKq = string("ELxMsxrcKwGXzVZGbEwiSiynpgUOUixqhvIpbqafPvIzJCIlSDXOxVBjIbXhEWRMBwLmnvykiGNhghXVgburvZFPtkVtAleHCpKrqhubrmqUdFAUZiQATVJFfjgLTvvXOorzlYmuFxnUFNbOEkpdRRZQ");
    double TMEeUoUMCCvKueTZ = 923158.2871832725;
    int lDnEQuC = -809504844;
    string oFmiOKkO = string("EohtnWtrQAwCoFelPKLkEzHgSSsUKVoLurKESlkcNdPlaoblMhAQRORTAEsXZBVTtwbUdbcHwePboyw");

    for (int RgaDIax = 725768365; RgaDIax > 0; RgaDIax--) {
        continue;
    }

    for (int qrWfZHqpdmU = 1240780352; qrWfZHqpdmU > 0; qrWfZHqpdmU--) {
        fnmmUpbZsWfJJVJ += qHcjdmvMyqgKq;
        GySURrrhN = GySURrrhN;
        avJlKddvrUWQ = kFYeuJjg;
    }

    return oFmiOKkO;
}

void afQIcJdGHJ::XSgfImlzgkUqPd(double kUFOZNbq)
{
    double koubQexAkIEGzYuN = 256593.1710671379;
    string luXotlpvIpH = string("YcGDjHpCOrQfRwoEszjSRMaenXiKaEywAIwoPAUmHZDNgcPBXvRflqXA");
    double TElNyeoqmzSSu = -247097.285376262;
    bool USYpxaCUhJm = false;
    int YSEQSUAEIOPkyqj = 1735479934;
    int hcrkNRTjDRvLLcfm = 920979409;
    string UPULfnsBpUh = string("wzkWOfFXopKecPgHrJMfFVgdCPPnjaNUKRwbEOXztPJtHwNvNCHASXWPMNjFxmBWPEsIHcfVMLFlmfKayVAWhgFHZivKvlTGSCClRYjXwiwTphEPnOAeABSCeYAtgxOwPKYePluLIFvbnxsYHxwjQwGiSUgbLcaaHsYVvyEQyAtKqsUgymJgViIkBeAQIzPsleeBAmFHkUrekxzpseIFSOXyVJWjmgCLWWbGbZUWhWUYSNpVJYQkMrCJcqf");
    int dHJKWKUgFid = 918857226;

    for (int wxqCcFhCxzixMkP = 813454026; wxqCcFhCxzixMkP > 0; wxqCcFhCxzixMkP--) {
        continue;
    }

    if (YSEQSUAEIOPkyqj < 920979409) {
        for (int ocKUVA = 1086586784; ocKUVA > 0; ocKUVA--) {
            TElNyeoqmzSSu *= koubQexAkIEGzYuN;
        }
    }

    if (koubQexAkIEGzYuN > 256593.1710671379) {
        for (int BRzNH = 940767421; BRzNH > 0; BRzNH--) {
            TElNyeoqmzSSu *= koubQexAkIEGzYuN;
            YSEQSUAEIOPkyqj /= hcrkNRTjDRvLLcfm;
            TElNyeoqmzSSu -= TElNyeoqmzSSu;
        }
    }
}

double afQIcJdGHJ::cXKRBRlc()
{
    double BGOimVNC = 507724.4291812966;
    int scKqOXUlOeoGnuhv = 2017657833;
    double hEfQECbq = -171645.0006112721;
    int wKVMl = 1442712182;
    double boycacOtpaDJlY = 835887.9593469973;
    int FdeMz = 1174791490;
    double ylpOpxQc = 320045.5710676083;
    int uQoECzBxmsbxovH = -297872676;
    int pkkSwcWsUYWraJ = 33324410;

    if (wKVMl >= 33324410) {
        for (int bjZaErtnZSjk = 523548591; bjZaErtnZSjk > 0; bjZaErtnZSjk--) {
            BGOimVNC /= boycacOtpaDJlY;
            FdeMz *= pkkSwcWsUYWraJ;
        }
    }

    return ylpOpxQc;
}

string afQIcJdGHJ::EQScmQfTL(int DiuKbdA, int LogNhGeZmDuT, double UaeZFKvNm, string rUTOAcNbefqhWm, bool RVPmPWNTsVuqGx)
{
    double izNcNVaiompEHXB = 631939.9810495082;
    string jAqjIt = string("UhoJqUuovDyelmDEoltpcRcHBDigRmPvWi");
    bool JIUgaghvCdU = true;
    int KDTzQrP = -1969322360;
    string JNDLUohdjiRhF = string("kSywkpCJzlILKwdq");
    string tvLiJKzlknKKqv = string("ZALdRnTUyHjcHIBVzFqbIZXKzzRDWxVbJUeBqNSdiFjwmLbyPjZZoapYTBPrQphFkhAUMnqyEcnKQLMNgVZdnjHoFJqQWOguyknQSWSBrZeyfTonfnNLSlKNCFVFDKxTOOkgwJoGNEnEbaserdijZXuwFrHIt");
    int coSmAZJyQlxamxnL = -549218747;
    int mCsIJeyREXwjEus = 394855429;
    string LsRWAoMoeHdVipLJ = string("dhzYUCsBhOnFLOSMKIGqfJPdcozsefCXwdfTCEcWHfwEMRnmtSmhtJeaxnyFEMyeRPYxyZyKWoUkYbELaNusLbjKfdqvYHtBuEGMHVNijbwn");
    string aerexOQW = string("jzcMKpMzyqKNpCtTOScnoYwPCbaZUwnDXPaFjxJMrPmLhInklOhaiozdKpgVHiwNMPjbhNmyJpTuahlWxRVEqsRwlYXCaBagVmehyUIFlistbCagOynTUogrOvxNQTffUBLUYkdDzSHdQMFKNtXluTafsIHQbkCdHdeIZUnKgWldisXxzpJPmHLnlnSbcNaKfJmnRItRddijYpKLizoTvAIWnhbCtDZzRdxsDvnvDPclixcD");

    for (int krRncFtixNUZW = 598656097; krRncFtixNUZW > 0; krRncFtixNUZW--) {
        LogNhGeZmDuT -= LogNhGeZmDuT;
    }

    for (int VZoyTq = 780921199; VZoyTq > 0; VZoyTq--) {
        LogNhGeZmDuT *= coSmAZJyQlxamxnL;
        JNDLUohdjiRhF += LsRWAoMoeHdVipLJ;
        DiuKbdA *= coSmAZJyQlxamxnL;
        mCsIJeyREXwjEus -= coSmAZJyQlxamxnL;
    }

    for (int SyQjbeLBipbBduSH = 1980840422; SyQjbeLBipbBduSH > 0; SyQjbeLBipbBduSH--) {
        mCsIJeyREXwjEus -= KDTzQrP;
        LsRWAoMoeHdVipLJ += tvLiJKzlknKKqv;
        coSmAZJyQlxamxnL *= KDTzQrP;
        rUTOAcNbefqhWm += rUTOAcNbefqhWm;
        LsRWAoMoeHdVipLJ += rUTOAcNbefqhWm;
        KDTzQrP -= coSmAZJyQlxamxnL;
    }

    return aerexOQW;
}

int afQIcJdGHJ::kffbA(double afsnYFEEqJ, double JGwGizmkNPXQ, bool hLwSUBR)
{
    bool TBbFjIWGaHkTkyR = false;
    string shJMtmMjveaSuSpw = string("hkpQMEIMOYGjdoUGsyPjvzqoOZShsRtvCbmzonAxShncDeexHhxytgsGSVJNjfDXjIouEKfcGNkonVBrpXAIqDKKIUtfbnjDzceuwYDkuaOLTNVwxTqbLZmPHFudXQRTSYyEBFOqGbtwmeFZolhqIEoVzhuyYuxZbjklQewpHansElfuNuStSMfQOnPjRfQIjWi");
    double YjXJrQAKVpgTXD = -742060.1351112927;
    bool TMFQklGtO = false;
    int TEizeUb = -1932005883;
    bool eLAGXC = true;
    bool RIzXsnLECcVMs = true;
    string rDAYmIeG = string("CrvEiRHKuCPVzKsksIRqQzkayBrWCWugkjnYeCUQwIRJFIhywrjfGtNrJyebrAETrTiXEqsqyaaMOFQDmMidUzGaqkbJpNMNSnFExNWyIZNWLYAQCmLLOMOiBwhlxKhngxWEJTfhijDbdLXRVTtKVBefXUdcyYAyDsuGJgdwuJASbZhxLrbZzpUDCrWBJdRWjmzoPyBgZezyUsndYAAyYVTypcwqYdxcQOPtPDWUUiDi");
    double JbaAFXBTf = -1043860.4439392444;
    bool GkxmFKgdlszPC = false;

    for (int BxGaOpghifbNQeBS = 95494677; BxGaOpghifbNQeBS > 0; BxGaOpghifbNQeBS--) {
        TMFQklGtO = ! eLAGXC;
    }

    for (int BIBjAf = 945103428; BIBjAf > 0; BIBjAf--) {
        TBbFjIWGaHkTkyR = RIzXsnLECcVMs;
        hLwSUBR = hLwSUBR;
        TBbFjIWGaHkTkyR = ! GkxmFKgdlszPC;
        TMFQklGtO = TBbFjIWGaHkTkyR;
        GkxmFKgdlszPC = TMFQklGtO;
    }

    if (TMFQklGtO != false) {
        for (int uSXpb = 832229449; uSXpb > 0; uSXpb--) {
            eLAGXC = eLAGXC;
            TBbFjIWGaHkTkyR = ! GkxmFKgdlszPC;
            afsnYFEEqJ /= JGwGizmkNPXQ;
            hLwSUBR = TMFQklGtO;
            hLwSUBR = ! RIzXsnLECcVMs;
        }
    }

    for (int kUKNz = 1909969388; kUKNz > 0; kUKNz--) {
        eLAGXC = TBbFjIWGaHkTkyR;
    }

    for (int ymDYehEWDD = 285811732; ymDYehEWDD > 0; ymDYehEWDD--) {
        afsnYFEEqJ /= YjXJrQAKVpgTXD;
        TMFQklGtO = RIzXsnLECcVMs;
        TMFQklGtO = ! RIzXsnLECcVMs;
        YjXJrQAKVpgTXD += JbaAFXBTf;
        GkxmFKgdlszPC = ! hLwSUBR;
        rDAYmIeG = shJMtmMjveaSuSpw;
    }

    return TEizeUb;
}

bool afQIcJdGHJ::vJQybDHHVtFkD(int rmLJbu, bool GseImLIkvDea, string ONNSmzzA, int mvaOBPFPyGKKjR, int qGhrqjEiRCIzQ)
{
    double XIMpOeKPa = -624518.9942913117;
    string wVcYd = string("mFjhsSMtvSJlllxmSwKxKXPuLFjnpgmutQzHBkblZMZeBWpAfcJDejFfBlrbhPPCudzRFQajePzSxflKDMmuXGlSQTPgKYPWGeXSYtzbnTPjUnrabCUA");
    string FTuRhSDzdQl = string("QdqRGGOYsKmoySLdECwZvqcuTiEdmDGRGhXVlbGJmnZrqAPmBzlQmiZmkINcprsymfGOxhbsYCGnonVbXejcAvgCmxumqvKSPYSdCMRMzUoRoUpVsNUCGakafZBwLLeFfoGbLpMIPb");
    bool fMyfBo = true;
    string pqklI = string("ejcfnKZapGoapNFfWTudjteqMmDgeEYzkpKmUFApdrUZmzEnGcWERlgIUCrXanOUpMpTnOYmTcaDvJKZkcOLVmuWxhZVJqEUjWSmZIUkDbMUWNoWsXEegyOLdwtUsdKahWZJhYOcltwBqiSriSprhKvguDfGZeWbHDGUMRsKctkNhlQaRsibPFYzlmYrlzdGdeRXIFehkHlWzWzHAP");
    double CKRnXGrmfzPSWLQ = 275306.5635111949;
    string MZLNyyyWWuTXoU = string("bWHZKoqojJBMvStCAcOfZiETQvxCCDeSOokoICXEChOwnmWPpsQZZdISiVxVDxceoBHPsdVlfLUBJCRJJLiQOCqrEhjphCubSeniSarTzWqMIIztpQdnQyDKUvcbknXaqaoKFAHUmIgAyZbRRLwDpWvOyuCeKqNjkczINcAaSFkxlHkBHNYnVzdPoUKUXCcYbeDoZtYH");

    if (qGhrqjEiRCIzQ <= -227740030) {
        for (int fhgeSqdfHtN = 1860495239; fhgeSqdfHtN > 0; fhgeSqdfHtN--) {
            continue;
        }
    }

    return fMyfBo;
}

double afQIcJdGHJ::IUTumpfy(bool NHjVapxr)
{
    string AeWvUN = string("mDIJLNdgMWCcyKPNivfSPPTbXLkqUzxAyTXbBQIOtdYmtnPIKqEcMGKDtyPWEfefUaUTGjsjYanpwCTcZiGoVloFRxpfjorkrQXIDdtbbqewLWhGIIaPVgzfBPxLgpYCAvytLtUWuGbRYUytZajRcWJJZiqkUFUHfgDmITsayVdOKjApNCmYTwkBin");
    bool cyuJAnqNjY = false;

    if (cyuJAnqNjY != false) {
        for (int BnrSiad = 738975417; BnrSiad > 0; BnrSiad--) {
            cyuJAnqNjY = ! cyuJAnqNjY;
        }
    }

    return 98454.21691769794;
}

int afQIcJdGHJ::wsrFdNQazMzjY(int ANdRzPa, int gbANkZqlqHnzs, double IWsTxmql, int fosmYF, double xSjIp)
{
    string RAcWeecWtBcEa = string("dTdEFoItSnmlcrqeGaziLfukO");
    int mgrCoyGN = 972717129;
    string pbZRFmGQBnMSm = string("PDLDefFSlfADPJVYXfJVXKbKqgXuihFkrAuwpNBXKkrcnHqBYKAtsmBVvpotOUYdkfNTTknDqDbUabCnRNxudnuyMVhNlerkYmRwXKNxXCWyeGoLsPLBHlUfTNTlpweGBSlGBldaDVPSXqsBFFuogWQKHagaFMmNdPomCmYiyAYXgslNcPBihXQllGhlhIJrZGOcSURnkNGNZbXdmdqbzVpYaVvPCAUcVblFytm");
    bool KnpMcOoaTd = true;
    int eCrGs = -1361139763;
    bool ZqLejvBMn = true;
    string EEcZhBgLsO = string("OERXRgWlnoBrlsgoYHmkfvLhwcMAcnPYcVphHScKoiIGFEkgOoBVWpQVUBhBTDFvcUomTxbpAJHkOSvFCrVDXnhNmKuCNUbcVnddaDtIRVxcLCYjyPoDDsTlrYFczZtUICSpb");

    for (int bmgFnWdTSh = 1488761726; bmgFnWdTSh > 0; bmgFnWdTSh--) {
        mgrCoyGN *= fosmYF;
        IWsTxmql -= xSjIp;
        eCrGs = gbANkZqlqHnzs;
    }

    if (eCrGs == 972717129) {
        for (int jlNlqaMoEqFwxS = 1837044657; jlNlqaMoEqFwxS > 0; jlNlqaMoEqFwxS--) {
            ANdRzPa *= ANdRzPa;
        }
    }

    for (int lJtYoomthEX = 1810149337; lJtYoomthEX > 0; lJtYoomthEX--) {
        continue;
    }

    for (int rqohUwoUBopfU = 1557894843; rqohUwoUBopfU > 0; rqohUwoUBopfU--) {
        xSjIp -= IWsTxmql;
    }

    for (int YQcview = 1365532799; YQcview > 0; YQcview--) {
        KnpMcOoaTd = ZqLejvBMn;
        ANdRzPa += mgrCoyGN;
    }

    return eCrGs;
}

string afQIcJdGHJ::AoMetsRGPAtT(double UUDSzJSoNZD, double dOCOEHutRohviT, bool RgJQE, double hOTpslGcja)
{
    bool KeQQnMFIFqDQH = false;

    if (dOCOEHutRohviT > 749557.4439735875) {
        for (int yrqFUxZdJwSrJ = 1016964861; yrqFUxZdJwSrJ > 0; yrqFUxZdJwSrJ--) {
            hOTpslGcja -= dOCOEHutRohviT;
            RgJQE = ! KeQQnMFIFqDQH;
            dOCOEHutRohviT *= hOTpslGcja;
            UUDSzJSoNZD = UUDSzJSoNZD;
        }
    }

    for (int UDlvTaRwwBGQYP = 443570095; UDlvTaRwwBGQYP > 0; UDlvTaRwwBGQYP--) {
        hOTpslGcja += UUDSzJSoNZD;
    }

    if (hOTpslGcja < 749557.4439735875) {
        for (int jnZZFalcRNTaz = 974043256; jnZZFalcRNTaz > 0; jnZZFalcRNTaz--) {
            UUDSzJSoNZD *= hOTpslGcja;
            KeQQnMFIFqDQH = ! RgJQE;
        }
    }

    if (hOTpslGcja == 749557.4439735875) {
        for (int DNlRqWGC = 1079858339; DNlRqWGC > 0; DNlRqWGC--) {
            RgJQE = ! RgJQE;
            dOCOEHutRohviT /= hOTpslGcja;
            UUDSzJSoNZD -= UUDSzJSoNZD;
        }
    }

    if (KeQQnMFIFqDQH != true) {
        for (int hBvyvsmqiQy = 1545286609; hBvyvsmqiQy > 0; hBvyvsmqiQy--) {
            RgJQE = ! RgJQE;
            KeQQnMFIFqDQH = ! RgJQE;
        }
    }

    for (int eavXNJCaZOzCoD = 78303717; eavXNJCaZOzCoD > 0; eavXNJCaZOzCoD--) {
        hOTpslGcja -= dOCOEHutRohviT;
        UUDSzJSoNZD -= dOCOEHutRohviT;
        dOCOEHutRohviT += hOTpslGcja;
        hOTpslGcja = hOTpslGcja;
        hOTpslGcja /= dOCOEHutRohviT;
        UUDSzJSoNZD = UUDSzJSoNZD;
    }

    return string("IYiGyrIasLWgalSnaAptRmCbCKQmBGcqdnahJzAzRzRcUvwmUWsVlGZQaLGbqfwb");
}

string afQIcJdGHJ::jsiinywlgyKUGEx(bool xGKldSSSYGst, bool nYvJuMJiRMSOuN, double TrhEZ, string LhzJlB, bool NkTsb)
{
    int NIBCooXi = 1727571766;
    int gvWrsnkE = 1171244748;
    double dziJHypoE = 193651.09159332752;
    string kAJUDqtoPeWWY = string("DFVeLmBWRxxzYUkksAYyxgRMmdqtAKjYNQlWYuLpVYPgqdaflcVTDtpFdeEdgdnKXNpamUlzGAxXgskJYApGGdRjstUGGxLLsvuoaqgZuSXkkBhBjONYbuXgpFaqWDWmnxGZTlXjlpdwEKyejSgbjFKCYHYyJiJqsBuLqUbJHc");
    bool XCJwQb = false;
    double dQsoejpHKCaFX = -780159.9209457401;
    int LFyrvVmIK = -407163523;
    bool CPmuuGdTF = false;
    bool mwUuwZxNSeRkevm = false;

    for (int mVsLKVR = 1746842634; mVsLKVR > 0; mVsLKVR--) {
        nYvJuMJiRMSOuN = ! CPmuuGdTF;
        LhzJlB += kAJUDqtoPeWWY;
        nYvJuMJiRMSOuN = ! nYvJuMJiRMSOuN;
        xGKldSSSYGst = ! XCJwQb;
        CPmuuGdTF = ! XCJwQb;
    }

    for (int wcgEOajbRcDXVOh = 1072879066; wcgEOajbRcDXVOh > 0; wcgEOajbRcDXVOh--) {
        mwUuwZxNSeRkevm = xGKldSSSYGst;
    }

    return kAJUDqtoPeWWY;
}

afQIcJdGHJ::afQIcJdGHJ()
{
    this->XRADeBFuTAbtRM(-545836.290242692);
    this->GwMyvEyj(string("XXDznmuDomrtGALnbhdhlebOomADhWQYLMheYYgSxaUBSRpG"), string("usumHjRBIGqRfdCHluMlPrdPfBguYftOfayCSKxryugJRhtmkEaA"), -1587554008, -470506003, -443474.0522743325);
    this->ctXfd(true, false, -789399.5530461629, string("ZixgDoNfLYyxxxAYHfqnmFUZieOExXDmCmlpvkwVywoQyNTtxQpSvOLWQVQNeycEugoCzfqlsaawuLQWuAQqOeISMpVoEmJEEjyGnFeOMtoSrSZyLnHyuAhzzqXMPOwrlGBiypYrOeGnqeLbDfaMSAOFVUZJsewXhJGceULwWzqndfpSwfpyEaZRHlnsMpvTzvnFHQuxJBHSFLzqvaQTnzDPOkvOaQcjyxvqk"), 886164.3521456219);
    this->VCESlXxIyntd(true);
    this->nEXcxfonFZO(true, false, 23610.482763223546, false);
    this->UbWIfeFeJZAKPjZ();
    this->WaQToMQdrX();
    this->rZOVnFzdUsjA(true, -913525.087455215);
    this->XSgfImlzgkUqPd(155710.74177391687);
    this->cXKRBRlc();
    this->EQScmQfTL(985846375, -1838010463, 126053.62240734062, string("IGcSTnucQxVCoAqpdfGwmshliUUAaYkNBCoUEhZiSRJiNHdFGnKbSsIwSyVlomYVJkxalYbAfYmZijSwrIUGYzjyKuZmaTjAzkOhSTQdphZqFhZHltvIdVSTUVcnFMydutJgzYPInQfeqErwKlrxnNlvLlgTozQAIgduMVIOwLLVGklqmUKNZZWyThlmACtpbP"), true);
    this->kffbA(-90499.9281480816, -720188.3424143583, false);
    this->vJQybDHHVtFkD(-227740030, false, string("vCIUDwoWfzSUcYewOAlwTKxnUIaoxyduSPWXErIFGWeNsZMDgWXywp"), 1757969048, 1726480210);
    this->IUTumpfy(false);
    this->wsrFdNQazMzjY(1265993583, 484683841, 4600.3163075213615, 2070214900, -204147.8639269825);
    this->AoMetsRGPAtT(647778.675995317, 749557.4439735875, true, -947495.9423209188);
    this->jsiinywlgyKUGEx(true, false, 740484.2052632606, string("PMskRctwXMyNfXHxOdwgBZQOdyUUfabUwkYlUEhragAiMyWTlhmOnCbfLxaWBEUdTegRiaVeHtaiBkgIApeLFoJTwRzhnXNSHVaCLzanMwBRplmlxhRIodfSKkFQHTnAJmPWAgaSiNJLblsJZqhHHXjUgASEvJUpsboSWTDsTVyMjaEyhNWKNPMYHpPUPWIyPDLELsgGAaxdHXnZNTGtctjcZdbaBMz"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XkLcxSdEMWNCeUsx
{
public:
    string eCHlG;
    bool IaeDnIADrE;
    string tbFrdWlLoA;
    string oVfHcrWGgnffWrP;
    string ldAHizGBFHyOuLkp;

    XkLcxSdEMWNCeUsx();
    void uNVFbkxk(double QVaUGNneDwji);
    void jXTADgc(int TmFJZzqizGYur, bool YotDSrxgv, bool KJbeTGUGwWjzhoAm);
    int RwwZL();
    string XZrsRq(double MtBsLuIZxJo, bool BKrxXKHhn, string FbfrWh, bool kbaeKXjnulTSak, string SIfobeolAMNJAmg);
    void YELIqsZPfdcLg(bool BpIRp);
    void pgKKqV(bool lkkRbKtMgoo, bool EMmMeVTvlGAMCOA);
    bool sBOKgTXTA(double gCKtn, double QTzJRLBrAjpWzM, double MWbhvJlpsHjKn, double XSrfXU, string FajJxdvO);
    string bATvbDokhT(bool dkbYf);
protected:
    double OBllJr;
    string sHWYOCKifMabNn;
    string phyXuZ;
    bool qSaFdpzmZFwxSU;
    bool KaNeal;
    bool iefTQ;

    int keIRxYMbGYr(string kLtSQwbICUyWF, int ClGCEkD, bool cTSXKWCZ);
    int ERcpAAOLdy(bool KeurNYVyjdL, string eZKUgD, string kQJYYZLMNj);
private:
    double kDtEhcp;
    int WVNpriMxaFgq;
    bool HphXHX;
    double ZehnlcwWFsm;

    void iQrwPxkzgpJtR();
    void AUtXOgakpFJcoFw(bool NuoazmHT, bool pFnvVZtoXlX, bool cZzIjnDxhZkueM, double RTeXGQv, double KYcpdCGyNQdgCU);
};

void XkLcxSdEMWNCeUsx::uNVFbkxk(double QVaUGNneDwji)
{
    string mMhCfqfNK = string("ZtHsFfwyVGpFXAHPLLbPszSuFbXCotsRUwsfngHgfOCxJgGLKFVTVTwlMJmOKMnTjmOSpuqjJnViFkaWRFvawlafiLupiRBIPQzQxbXsRVAlGRmAHjiDtVuXDJluUaBfpCwaQi");
    bool uOTBkKFAqKRxAzwg = true;
    double MruOXLtmrqBzpnhu = -339285.7188293306;
    string boLXPM = string("ZbnKIwgiMRNUWkHWDFqXMaKkAUoyBsorjGonieVnCASaxUAhdCzXTJfhRUiKteLuQBADXsrolyPewQIvUnCRSKZmMDDqaQRuBTgEiAsFEitFPLQLpCDgOiYOMBkWNgwaSjilHQhNEQsmJZWcGOdyjSAqnLPLWgkWjyEqEBsmUfWpuakXyYgPpOmUWTzvPUPjKzKBXzr");
    string fLhbeOhL = string("TiXHRUGfcqlXcGqkqlQtDgaLKBWAlORgglIrmIUMpKQegHninjLYZVvuSjGTWyvybPEtaOCWpvvChOKCQGLnACgYzPxnJNsZAXyLpCeKYBEIAewXzgODNUMQsmvyiGSTHm");
    int DfrEImjUHD = -603531823;
    double hERvsJNTNh = 38309.58576960677;
    int CxfYjN = 1791505177;

    for (int QlWBYdHlvlvi = 132140810; QlWBYdHlvlvi > 0; QlWBYdHlvlvi--) {
        continue;
    }

    if (fLhbeOhL <= string("TiXHRUGfcqlXcGqkqlQtDgaLKBWAlORgglIrmIUMpKQegHninjLYZVvuSjGTWyvybPEtaOCWpvvChOKCQGLnACgYzPxnJNsZAXyLpCeKYBEIAewXzgODNUMQsmvyiGSTHm")) {
        for (int yCTvCRwdnIBqcKsD = 722838521; yCTvCRwdnIBqcKsD > 0; yCTvCRwdnIBqcKsD--) {
            continue;
        }
    }
}

void XkLcxSdEMWNCeUsx::jXTADgc(int TmFJZzqizGYur, bool YotDSrxgv, bool KJbeTGUGwWjzhoAm)
{
    int SQaNNGsaeCVsk = 82457053;
    string miZHcdHdlfuq = string("MHOQRPyCMVcdegXdGQkjFYgFiqUehNCBCyQhsviDXscndGVLCyAAMIEhIjUBbAFRyXDdkIcWKPvmuREYJgJJboinnMuBmYMrMjxvLVEyNvRrLxOzXPxRKcjyAPLwfyMuAnWzbtVXNufNIhWPUkoQbbjOK");
    bool KOjYjQwhzCtwIf = false;
    string TvQJfBSSYmBS = string("WBPMIskdyWzcFJVhYgYStLHdkvIGlwLOairdgqukLcmXluEhsNqcMPYBNnaolAMfhfInrYBlRIafjuzsFBRCdLzpfdLzDPBuhbnVYZkiikcTDSWHcaMtGdGSJWhUtWBdVBdWhkDmKMZxjwZHCLOgLlHYdOGXZOMTDvJUxfZJimskyqgGTXVB");
    int ffUrTwlgiYRVCCOF = 571034995;
    bool fZIOH = false;
    int OMizZWwXax = 787188791;
    string lMVdEwjH = string("WuPhKaJLPlEdfAyBLBZKpOmZMNkjCHfOvepOvYhopwzBNLHONTdCdsqpQBrZIVzLGmYmTnfgrPdcYxAeQMAxxhWwEDEZyGczttgEwDGGhWkRMtcqNXqIoCPZYxJTMLirnhRToPQKEkbsrqsqierVhDcnqbEaBQXHnNVXHkFLoxjyadsMPEujcgrUYcnaphmwYnUsXDsnFRNfTDaKFPjYEZmCydvDVGYDwXnIOTzUsatSPOqqP");
    bool GIDaXysVsHuVIVhO = true;

    if (KOjYjQwhzCtwIf != true) {
        for (int qTIrdkMden = 857311857; qTIrdkMden > 0; qTIrdkMden--) {
            TvQJfBSSYmBS = miZHcdHdlfuq;
        }
    }

    if (fZIOH == false) {
        for (int GIjAvJnyek = 1484681564; GIjAvJnyek > 0; GIjAvJnyek--) {
            fZIOH = KOjYjQwhzCtwIf;
            GIDaXysVsHuVIVhO = ! fZIOH;
        }
    }

    if (GIDaXysVsHuVIVhO == false) {
        for (int uQoeEXuSPOYJZ = 1137480144; uQoeEXuSPOYJZ > 0; uQoeEXuSPOYJZ--) {
            continue;
        }
    }

    for (int ueZKKIE = 458073485; ueZKKIE > 0; ueZKKIE--) {
        YotDSrxgv = ! YotDSrxgv;
        ffUrTwlgiYRVCCOF = SQaNNGsaeCVsk;
        KJbeTGUGwWjzhoAm = ! fZIOH;
        OMizZWwXax *= SQaNNGsaeCVsk;
        ffUrTwlgiYRVCCOF -= ffUrTwlgiYRVCCOF;
        miZHcdHdlfuq += lMVdEwjH;
    }

    for (int NMCUtZieqDD = 845354911; NMCUtZieqDD > 0; NMCUtZieqDD--) {
        continue;
    }

    for (int LBKJHeXUdRSdwFL = 672611939; LBKJHeXUdRSdwFL > 0; LBKJHeXUdRSdwFL--) {
        KOjYjQwhzCtwIf = ! fZIOH;
        GIDaXysVsHuVIVhO = ! GIDaXysVsHuVIVhO;
        ffUrTwlgiYRVCCOF -= ffUrTwlgiYRVCCOF;
    }
}

int XkLcxSdEMWNCeUsx::RwwZL()
{
    string MJjCAgLNuPbOTJT = string("aPpKNCEtYnUDzUAmsmjqzAHKAAlYBcqpjxIHyQoBWwTSjNSyhRgRRNQBKYeWOuWjqbLrDibacOZcEgmuTujSqIlBvLDJHSaioRXCMBKhbtkHbCGFiuZgcekexoXDXbuZQpmQBjZMYxNIzjpOxhJqPaewMAzpIyPDgDVXljYBAxLZgAPWtwJfwjWvFjtAReVoBzcXYDbPSEsWqset");
    int AIqjjiZCTKPdp = 2010776038;
    bool GHHBYweAobWMZlDh = false;
    int OXxvVKsUcPF = 1277057253;
    int jiVTQfnCnjCfi = -1114225913;

    if (MJjCAgLNuPbOTJT == string("aPpKNCEtYnUDzUAmsmjqzAHKAAlYBcqpjxIHyQoBWwTSjNSyhRgRRNQBKYeWOuWjqbLrDibacOZcEgmuTujSqIlBvLDJHSaioRXCMBKhbtkHbCGFiuZgcekexoXDXbuZQpmQBjZMYxNIzjpOxhJqPaewMAzpIyPDgDVXljYBAxLZgAPWtwJfwjWvFjtAReVoBzcXYDbPSEsWqset")) {
        for (int ydVVyEwNAsCDvrqz = 1371692819; ydVVyEwNAsCDvrqz > 0; ydVVyEwNAsCDvrqz--) {
            jiVTQfnCnjCfi += AIqjjiZCTKPdp;
        }
    }

    return jiVTQfnCnjCfi;
}

string XkLcxSdEMWNCeUsx::XZrsRq(double MtBsLuIZxJo, bool BKrxXKHhn, string FbfrWh, bool kbaeKXjnulTSak, string SIfobeolAMNJAmg)
{
    bool cixLixsfPMkNnHyl = false;
    double ssrIfqYiXNZDe = -429835.6835462086;
    double egLVHdUK = -514595.9444777086;
    string FyUitvbMo = string("nBsmBBtLXGYzNvVOroNIgRkaczmafPZHuoOnaKPOKvFFHjKuvYeyOjkOzRHVEOcAePfKTXwjaqzZtkkVdLEZEKiPSnOzbDwNviCRWLKohwWaEnDVlVDllaUynQJccCXbYQcrgbaXLKwxZ");
    int pOYKJfCrQejOd = 760031873;
    string NKUAnzyWwteNWIUx = string("nQIIhNZSvNwLEsTUgjxGmFkZTtsxoVbElwUUtq");

    if (kbaeKXjnulTSak != true) {
        for (int QPaLnTPnBNgNNyLy = 426741382; QPaLnTPnBNgNNyLy > 0; QPaLnTPnBNgNNyLy--) {
            egLVHdUK /= ssrIfqYiXNZDe;
            kbaeKXjnulTSak = ! cixLixsfPMkNnHyl;
        }
    }

    if (NKUAnzyWwteNWIUx >= string("KQMKINXNdxCOnifsIxbdNEIGHMHQvnRMrVvbAGhjsYJQGujodfYVMBVQBnxQfUBdauWHsiMlJxMCQuJNercJZzYvtDSVWjRdriLmxv")) {
        for (int PzEkENfBEkDSYjlZ = 383177282; PzEkENfBEkDSYjlZ > 0; PzEkENfBEkDSYjlZ--) {
            continue;
        }
    }

    for (int eiYOAzCdocrxBIq = 2043645516; eiYOAzCdocrxBIq > 0; eiYOAzCdocrxBIq--) {
        continue;
    }

    for (int swbOqTttvoHL = 908773168; swbOqTttvoHL > 0; swbOqTttvoHL--) {
        NKUAnzyWwteNWIUx += FbfrWh;
        FyUitvbMo = SIfobeolAMNJAmg;
    }

    return NKUAnzyWwteNWIUx;
}

void XkLcxSdEMWNCeUsx::YELIqsZPfdcLg(bool BpIRp)
{
    int XyOkQhG = 1320943446;
    string zzhgUbA = string("murQaucbDVzeBMpDtDQbIwTUHbrVjZwWPeXiMkeXDtrsaBnemOuIndgDqgspycRdAtuyegOBGsFWHbKsdEyCdwtOVGibrVcGWPSbuYRqYGzxXseRBabcJDohJEwmOjudHHXbqlecNtGCBUUSMiiocUbdzXkBZKrhQSZPKigingryhiRPazCyqhEFXf");
    bool HzDgvSeybHS = false;
    double HXqjzkhkevSXlV = 74957.35783661433;
    bool jbjzjvywtYRj = false;
    int xKjsCYHAQQYFo = 1362208331;
    string ASRrMjlWpxcvqhq = string("sydRvYGbyMDrNsnGsVgtHqmXLrBzkFQQqqoEFUrodkRFcSViHeMPnplPVCVyLPHNRDGCHbaNVNABDCvwMWVBaBjTZTVOC");
    bool xBVXF = false;

    for (int MVIkuLZ = 314167437; MVIkuLZ > 0; MVIkuLZ--) {
        HzDgvSeybHS = HzDgvSeybHS;
        xKjsCYHAQQYFo *= xKjsCYHAQQYFo;
        HXqjzkhkevSXlV = HXqjzkhkevSXlV;
    }

    if (HzDgvSeybHS != false) {
        for (int PzxVgrqCqsxwn = 1183597608; PzxVgrqCqsxwn > 0; PzxVgrqCqsxwn--) {
            zzhgUbA = ASRrMjlWpxcvqhq;
            ASRrMjlWpxcvqhq += zzhgUbA;
        }
    }

    if (HzDgvSeybHS != false) {
        for (int igxyupVsJFZZSEyM = 1721534045; igxyupVsJFZZSEyM > 0; igxyupVsJFZZSEyM--) {
            xBVXF = ! HzDgvSeybHS;
            ASRrMjlWpxcvqhq = zzhgUbA;
        }
    }

    for (int nXaeqJ = 507306038; nXaeqJ > 0; nXaeqJ--) {
        continue;
    }

    if (BpIRp != false) {
        for (int jgWNSYuUuBRsiN = 1468637839; jgWNSYuUuBRsiN > 0; jgWNSYuUuBRsiN--) {
            HzDgvSeybHS = ! xBVXF;
            zzhgUbA = zzhgUbA;
            HXqjzkhkevSXlV *= HXqjzkhkevSXlV;
            ASRrMjlWpxcvqhq += ASRrMjlWpxcvqhq;
            BpIRp = jbjzjvywtYRj;
        }
    }
}

void XkLcxSdEMWNCeUsx::pgKKqV(bool lkkRbKtMgoo, bool EMmMeVTvlGAMCOA)
{
    int dqJCcJrzAdbOonEa = 1704541473;
    string vtcxVdVHiJa = string("VMXuOcRJEbPKxVpedAsCPBKBvOAuxaHAeOlknRwheeOvFTwZXTXqzENtDZcMeVLDQaSKVXUmVgVVFuxQhNrDGFXDQjBdyEzJJtqWWgDgshOikmGeCZpyvt");

    for (int BXtscK = 813729426; BXtscK > 0; BXtscK--) {
        vtcxVdVHiJa += vtcxVdVHiJa;
        lkkRbKtMgoo = ! EMmMeVTvlGAMCOA;
        lkkRbKtMgoo = EMmMeVTvlGAMCOA;
    }

    for (int McWjkILSgl = 1789879737; McWjkILSgl > 0; McWjkILSgl--) {
        EMmMeVTvlGAMCOA = EMmMeVTvlGAMCOA;
        lkkRbKtMgoo = EMmMeVTvlGAMCOA;
        lkkRbKtMgoo = ! EMmMeVTvlGAMCOA;
        lkkRbKtMgoo = ! EMmMeVTvlGAMCOA;
    }

    if (lkkRbKtMgoo != true) {
        for (int MBzTmXZWahjRPp = 2141920751; MBzTmXZWahjRPp > 0; MBzTmXZWahjRPp--) {
            lkkRbKtMgoo = ! lkkRbKtMgoo;
            lkkRbKtMgoo = EMmMeVTvlGAMCOA;
        }
    }

    for (int QkwmglUvrflFEKQ = 259288142; QkwmglUvrflFEKQ > 0; QkwmglUvrflFEKQ--) {
        EMmMeVTvlGAMCOA = ! EMmMeVTvlGAMCOA;
        EMmMeVTvlGAMCOA = ! lkkRbKtMgoo;
        lkkRbKtMgoo = EMmMeVTvlGAMCOA;
        dqJCcJrzAdbOonEa -= dqJCcJrzAdbOonEa;
    }

    for (int CplWXYwLvcry = 1051405039; CplWXYwLvcry > 0; CplWXYwLvcry--) {
        EMmMeVTvlGAMCOA = ! lkkRbKtMgoo;
        dqJCcJrzAdbOonEa -= dqJCcJrzAdbOonEa;
    }

    if (vtcxVdVHiJa > string("VMXuOcRJEbPKxVpedAsCPBKBvOAuxaHAeOlknRwheeOvFTwZXTXqzENtDZcMeVLDQaSKVXUmVgVVFuxQhNrDGFXDQjBdyEzJJtqWWgDgshOikmGeCZpyvt")) {
        for (int azCPGiyvtHczWJo = 178294415; azCPGiyvtHczWJo > 0; azCPGiyvtHczWJo--) {
            dqJCcJrzAdbOonEa /= dqJCcJrzAdbOonEa;
            lkkRbKtMgoo = EMmMeVTvlGAMCOA;
            dqJCcJrzAdbOonEa += dqJCcJrzAdbOonEa;
            EMmMeVTvlGAMCOA = ! lkkRbKtMgoo;
            lkkRbKtMgoo = EMmMeVTvlGAMCOA;
        }
    }
}

bool XkLcxSdEMWNCeUsx::sBOKgTXTA(double gCKtn, double QTzJRLBrAjpWzM, double MWbhvJlpsHjKn, double XSrfXU, string FajJxdvO)
{
    double GMymdRjTBBO = 245124.81935508005;
    double NPYMKJVOJ = 422972.0809153238;
    double LQSFvkEtLIJrj = -839473.4417401915;
    double OLDfkemtNRg = 1031468.5258516787;
    string pQpjCVTzwYtCRh = string("imkWrtFsapfhdtHGKiUGRRHXoDZHZbdRghhzhhVCWkBxJVsJOSCipMTBpQYftzFKSUlECZKSvkcjtiKgMZjskgYgbsMrkPrkWGvkMaZYDBPvUSTlPIZfaDKjswoGjaH");
    double yOnmhwoQZvkIzjWs = 684694.870853586;
    string RpdzGbaqcTjJlXKT = string("PzAmAjOlsIORREPFTBcDIsfCnZKJ");

    if (QTzJRLBrAjpWzM >= 422972.0809153238) {
        for (int uVeFSiSYhwDvWO = 1173725112; uVeFSiSYhwDvWO > 0; uVeFSiSYhwDvWO--) {
            OLDfkemtNRg = MWbhvJlpsHjKn;
            OLDfkemtNRg -= NPYMKJVOJ;
            QTzJRLBrAjpWzM -= yOnmhwoQZvkIzjWs;
        }
    }

    if (MWbhvJlpsHjKn <= 245124.81935508005) {
        for (int MldBFZrNMY = 1722062964; MldBFZrNMY > 0; MldBFZrNMY--) {
            gCKtn /= gCKtn;
            LQSFvkEtLIJrj = OLDfkemtNRg;
        }
    }

    return false;
}

string XkLcxSdEMWNCeUsx::bATvbDokhT(bool dkbYf)
{
    bool NuxgRuZRRKdu = true;
    bool FrzbcKwQy = false;
    int eFLNoURlmxzKsc = 735207199;
    double dXVhoS = 35505.88942738026;

    for (int sZPCOkNwMxKaJq = 1219459390; sZPCOkNwMxKaJq > 0; sZPCOkNwMxKaJq--) {
        eFLNoURlmxzKsc /= eFLNoURlmxzKsc;
        FrzbcKwQy = ! dkbYf;
        dkbYf = ! FrzbcKwQy;
        eFLNoURlmxzKsc *= eFLNoURlmxzKsc;
    }

    for (int iwlCTCyKkdI = 1169305960; iwlCTCyKkdI > 0; iwlCTCyKkdI--) {
        FrzbcKwQy = NuxgRuZRRKdu;
        FrzbcKwQy = ! NuxgRuZRRKdu;
        dkbYf = ! dkbYf;
    }

    if (NuxgRuZRRKdu != true) {
        for (int xSjQJOyGs = 467252736; xSjQJOyGs > 0; xSjQJOyGs--) {
            FrzbcKwQy = NuxgRuZRRKdu;
            NuxgRuZRRKdu = NuxgRuZRRKdu;
            NuxgRuZRRKdu = ! dkbYf;
        }
    }

    if (dkbYf != true) {
        for (int FCsoNfN = 123523721; FCsoNfN > 0; FCsoNfN--) {
            NuxgRuZRRKdu = dkbYf;
            FrzbcKwQy = NuxgRuZRRKdu;
        }
    }

    for (int jTaOjVykImdhpp = 1479919976; jTaOjVykImdhpp > 0; jTaOjVykImdhpp--) {
        continue;
    }

    if (dkbYf == true) {
        for (int MvQMZy = 592604833; MvQMZy > 0; MvQMZy--) {
            eFLNoURlmxzKsc = eFLNoURlmxzKsc;
        }
    }

    return string("laSjPTjQDbruZYCPKlczLEADizcsZnXEveKKPkixzzjdRBXwltxUCgKjlneCDcfbdwMXqLkeUSLKAcCHLRRsDzpEYIRQPhdd");
}

int XkLcxSdEMWNCeUsx::keIRxYMbGYr(string kLtSQwbICUyWF, int ClGCEkD, bool cTSXKWCZ)
{
    int zIiZOJu = 1727744713;
    bool KqcNwivb = false;
    int YNNjPgVPfBqgl = 100212709;

    if (kLtSQwbICUyWF > string("CKxWjxzkVmNegbAVqxYFHmTLnMjSiQZmYQMlDHUldfWQEBIpzFRWtvdFPoiauePTMQGHkEfqanWCPydmAcIeTsZKJQvNRJLWUeNrBuBmrGweOQrjXJMwGEkpfsdpaphPQFZRlxlHtLoDZHwHlCWIJoJVaRNdWWHeSSBvVMsvQOtPvFKZwghhXnCvvOBxJWFCGTZtNszFavjXmhVnDseelbss")) {
        for (int KJkhZLsazhc = 366455473; KJkhZLsazhc > 0; KJkhZLsazhc--) {
            kLtSQwbICUyWF = kLtSQwbICUyWF;
            YNNjPgVPfBqgl = YNNjPgVPfBqgl;
            YNNjPgVPfBqgl += YNNjPgVPfBqgl;
            zIiZOJu += YNNjPgVPfBqgl;
        }
    }

    for (int DEvNZXBo = 117226013; DEvNZXBo > 0; DEvNZXBo--) {
        zIiZOJu /= ClGCEkD;
        zIiZOJu -= ClGCEkD;
        ClGCEkD *= zIiZOJu;
    }

    return YNNjPgVPfBqgl;
}

int XkLcxSdEMWNCeUsx::ERcpAAOLdy(bool KeurNYVyjdL, string eZKUgD, string kQJYYZLMNj)
{
    int VOONwQ = 1246895093;

    if (eZKUgD > string("gAVcFhuamsQToKmPWiFvNYETWvprMctPEQwsuYJIlvYwbEsWBkuRxdcosZLoCCXjVNFPFWJAXOSZAHZIQUwgkkraDusQCiMuVfJMBHnlfuxqnZTXpPBpNdikBCHqUJlGBPoWtyTAucBBHHHdzarvrhWeZXRGnlGanckEwrLZEHXVsayuxsISfldyCXDADnUfpVRwRHajvULcUrGaNdaNjWYhGCtCg")) {
        for (int BjAODRbk = 1726680332; BjAODRbk > 0; BjAODRbk--) {
            KeurNYVyjdL = ! KeurNYVyjdL;
            kQJYYZLMNj += eZKUgD;
        }
    }

    for (int WuqUTVoZO = 594045242; WuqUTVoZO > 0; WuqUTVoZO--) {
        eZKUgD = eZKUgD;
        KeurNYVyjdL = ! KeurNYVyjdL;
    }

    return VOONwQ;
}

void XkLcxSdEMWNCeUsx::iQrwPxkzgpJtR()
{
    bool pzWFP = true;
    string bQsXW = string("vxsuJpbRRESlZuRSmiFPbVuzSbDFlKMnkmzvbzKxQndeDHSFELvKwLAPRVpZzvRitMtTfeleNtWPqZzibYhgcCeRbVnloxQNVGeUi");

    if (pzWFP == true) {
        for (int orogo = 1604703880; orogo > 0; orogo--) {
            bQsXW = bQsXW;
            bQsXW = bQsXW;
            pzWFP = ! pzWFP;
            bQsXW = bQsXW;
            bQsXW += bQsXW;
            pzWFP = ! pzWFP;
        }
    }
}

void XkLcxSdEMWNCeUsx::AUtXOgakpFJcoFw(bool NuoazmHT, bool pFnvVZtoXlX, bool cZzIjnDxhZkueM, double RTeXGQv, double KYcpdCGyNQdgCU)
{
    double wyvaoq = -648070.1840542658;
    string evbaVK = string("VVcDcIOwDIkZEIsprdyoOVYElKUqXlchbQBWVvtIzzyoQyAWpuFddXdCfNAgswEldiMItJtzvlzNfvScneYvGOhyJnMhVlyKMXZRtfvSzXhbpVZmZahhXeSZkdZfATkxkHeIMZMvHirEWeIGhgxipBErsWHbfMSpfePhRFExvxIfGXGjLDlRKBgpgGxvOSqiPLlYBrInemgDvZOoNZcRhGIKPrNKfhFbugSoNSdGkHyRDCqjqKeEc");
    string QDEZqGFEdf = string("BwTaUxeZCszoEUnQVWLzTXIc");
    int GhxuZfneDCio = -1092462233;
    double PacEOBRSmZDx = -583841.2443778218;
    bool IAKGxdsqLaXwTL = false;
    int JCniddkBk = 829688334;

    for (int TeGooICUllezRhQ = 691102066; TeGooICUllezRhQ > 0; TeGooICUllezRhQ--) {
        JCniddkBk -= JCniddkBk;
    }

    for (int tvMBzDikFA = 1559493834; tvMBzDikFA > 0; tvMBzDikFA--) {
        continue;
    }

    if (JCniddkBk != -1092462233) {
        for (int iQOyxe = 211109217; iQOyxe > 0; iQOyxe--) {
            continue;
        }
    }

    if (evbaVK != string("VVcDcIOwDIkZEIsprdyoOVYElKUqXlchbQBWVvtIzzyoQyAWpuFddXdCfNAgswEldiMItJtzvlzNfvScneYvGOhyJnMhVlyKMXZRtfvSzXhbpVZmZahhXeSZkdZfATkxkHeIMZMvHirEWeIGhgxipBErsWHbfMSpfePhRFExvxIfGXGjLDlRKBgpgGxvOSqiPLlYBrInemgDvZOoNZcRhGIKPrNKfhFbugSoNSdGkHyRDCqjqKeEc")) {
        for (int QuMZpTlTzNVk = 509485277; QuMZpTlTzNVk > 0; QuMZpTlTzNVk--) {
            continue;
        }
    }
}

XkLcxSdEMWNCeUsx::XkLcxSdEMWNCeUsx()
{
    this->uNVFbkxk(-995056.5359406784);
    this->jXTADgc(2044126912, false, true);
    this->RwwZL();
    this->XZrsRq(278540.3887892791, true, string("KQMKINXNdxCOnifsIxbdNEIGHMHQvnRMrVvbAGhjsYJQGujodfYVMBVQBnxQfUBdauWHsiMlJxMCQuJNercJZzYvtDSVWjRdriLmxv"), true, string("QNDIpuvtRvaW"));
    this->YELIqsZPfdcLg(true);
    this->pgKKqV(false, true);
    this->sBOKgTXTA(-997177.0629668197, -73085.80443768301, 272694.179909321, -392799.00466824026, string("nGpVkDJVphFddnJMeTsNNwJmcYVoJKWEUBNlCgEPEqWyKKrllbIuILaWCtrxNmKbTpIufkYkVAIvlxXrFHtxCHSXjvoitqVwIrNOTAzhUQNWFYOLckwflyjoVMTWgAn"));
    this->bATvbDokhT(true);
    this->keIRxYMbGYr(string("CKxWjxzkVmNegbAVqxYFHmTLnMjSiQZmYQMlDHUldfWQEBIpzFRWtvdFPoiauePTMQGHkEfqanWCPydmAcIeTsZKJQvNRJLWUeNrBuBmrGweOQrjXJMwGEkpfsdpaphPQFZRlxlHtLoDZHwHlCWIJoJVaRNdWWHeSSBvVMsvQOtPvFKZwghhXnCvvOBxJWFCGTZtNszFavjXmhVnDseelbss"), -2067854703, true);
    this->ERcpAAOLdy(false, string("BbncEETafCstHwbmhVBKSvLryRqJWYmZYUGeDByEdfaJQwhPxeSmcfnVFmFNEQWrzmrzXhkKCkIXakhI"), string("gAVcFhuamsQToKmPWiFvNYETWvprMctPEQwsuYJIlvYwbEsWBkuRxdcosZLoCCXjVNFPFWJAXOSZAHZIQUwgkkraDusQCiMuVfJMBHnlfuxqnZTXpPBpNdikBCHqUJlGBPoWtyTAucBBHHHdzarvrhWeZXRGnlGanckEwrLZEHXVsayuxsISfldyCXDADnUfpVRwRHajvULcUrGaNdaNjWYhGCtCg"));
    this->iQrwPxkzgpJtR();
    this->AUtXOgakpFJcoFw(false, true, false, 471176.5972148148, -3948.1998479511662);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class efTkobDV
{
public:
    string wttlIuCYNe;
    string JHntWG;
    int bzMVVRvefEac;

    efTkobDV();
    double udVCvemeenZy(string NEnVb, int zssaZUynaiRt);
    string BtepLMWwvIuifq(int SXgMGLYImNUGvwTU, double mLuJP, double AIhaM);
    bool ebZhirAlMcxoybD(string ZuIqUHkY, double PwIzhDyxd, double XdiatEaql);
    bool LdwpM(string mbmLwRztv);
    double xIxtSVPkZG(double ZbcRSej, string TegFlKxvxnEnJ, int AOpAArGWYJ, string GRxcUbbRvEe, bool mcjqeyPlVUXZSQt);
    double qPlgYJnIRxhPfkGI(string hRyBZCKqr);
protected:
    string LYRzMo;
    bool xNopZVMhPQmgJTf;

    int oEUajPKNVGXojb(double kyAtGde, double oAbgLUyIDhNfB, string dPvSiEH, int ahNYVYQYIwzqiYNX);
    void wCCnl(int TEiIlFSgKtzCrR, int PLWVXnpbFBB, string gwcOMrcfu, bool YAtGJIvkuiWeGehp, string UcpzULJj);
private:
    double MOoLNB;
    int FkcOLeONqnnj;
    int KTAnIOMnBPxyJqEY;
    bool qeCcWIFBn;
    bool yIWzfFQNFcsSnpj;

    double AUWqo(int DFoPYC, string mfNyxxwigDKdBI, string PnmNisCy, string RwiojutVXB, bool UCYrD);
    int ZSNQCRPLOLhpZU(string BIhLvz, string oAsTlwc, bool iYxJNol);
};

double efTkobDV::udVCvemeenZy(string NEnVb, int zssaZUynaiRt)
{
    string YmlmLzmK = string("quXXofjFLxEEGYkYXmPTPzlvbZxluCSbOBGwYRbJHyYFHUJuMHwmHbtsEyHNICPBSyhTUXHkTFymkmuIQQAbKjUXxNytToIWPDgxHGNOasGjojjoXBNihwMjyOZRjmnxZCQqaggpOwnLNHucFAthklQFsnXVTtDLwDfyUnRZORhcoJULCqHFFwZIeuPzTSeBKmiBCmxzIMNGUnbvLbr");
    double ocKdBcSJhHR = -749392.4835493717;
    int lEdhUfNutAyOdQ = -2125059539;
    int pAYieHpoQW = -164038270;
    double KBpuCGsYpwlnNK = -64657.2093462128;
    string qvPec = string("LivEE");
    bool GNkGuy = true;
    double eKfliRZ = 447907.97974736843;

    for (int fPSakUijkwFuihv = 241801151; fPSakUijkwFuihv > 0; fPSakUijkwFuihv--) {
        GNkGuy = GNkGuy;
        qvPec = qvPec;
        KBpuCGsYpwlnNK = ocKdBcSJhHR;
    }

    for (int yDzRKpk = 889312678; yDzRKpk > 0; yDzRKpk--) {
        NEnVb = NEnVb;
        lEdhUfNutAyOdQ /= zssaZUynaiRt;
        lEdhUfNutAyOdQ -= lEdhUfNutAyOdQ;
    }

    return eKfliRZ;
}

string efTkobDV::BtepLMWwvIuifq(int SXgMGLYImNUGvwTU, double mLuJP, double AIhaM)
{
    bool ORVAHzj = true;
    int ePBIlzNqq = 1945967743;
    string NfAKmpug = string("fvRXFHCseWTNZznjdsVnFZGFyXkdfPHnhbApuTOW");
    bool ReosZOeGzU = false;
    string vyowZfkGKBqwKP = string("hfLYLLyAmFDDWYgUWdCZHCIbmxOLOBYSBJtXChoGoxOFAxsWvIIYaFVbfvGPhdkeuuoROBuhAtmpedFohGipAQIeihIMQbtcgEQTRkoGmKEmWxVrjkekWBUiTOJlAqHeBrVPtiGqAfHOucckFapDptqMCjIiEjirARXcjBBZRxFKdKyKEPFezb");

    for (int AtWgXWuYPBJqPpsT = 1223165368; AtWgXWuYPBJqPpsT > 0; AtWgXWuYPBJqPpsT--) {
        vyowZfkGKBqwKP = vyowZfkGKBqwKP;
        NfAKmpug += NfAKmpug;
    }

    for (int ejzct = 655815440; ejzct > 0; ejzct--) {
        ePBIlzNqq = SXgMGLYImNUGvwTU;
        ePBIlzNqq -= ePBIlzNqq;
        ePBIlzNqq += ePBIlzNqq;
    }

    for (int HISJfiAywMXI = 2003001367; HISJfiAywMXI > 0; HISJfiAywMXI--) {
        ePBIlzNqq /= ePBIlzNqq;
        SXgMGLYImNUGvwTU -= SXgMGLYImNUGvwTU;
        vyowZfkGKBqwKP = NfAKmpug;
    }

    for (int EwJoghhQZBWbrn = 876273080; EwJoghhQZBWbrn > 0; EwJoghhQZBWbrn--) {
        continue;
    }

    for (int seiqVBzGDveshy = 2081243025; seiqVBzGDveshy > 0; seiqVBzGDveshy--) {
        ReosZOeGzU = ! ReosZOeGzU;
        AIhaM = mLuJP;
    }

    for (int oynODvRhiXx = 1014486428; oynODvRhiXx > 0; oynODvRhiXx--) {
        mLuJP = mLuJP;
    }

    return vyowZfkGKBqwKP;
}

bool efTkobDV::ebZhirAlMcxoybD(string ZuIqUHkY, double PwIzhDyxd, double XdiatEaql)
{
    int NCfkDZIulRnx = 1860074544;

    if (PwIzhDyxd < -264732.65249735716) {
        for (int kmMuvXJkjPiG = 480929716; kmMuvXJkjPiG > 0; kmMuvXJkjPiG--) {
            XdiatEaql += XdiatEaql;
            PwIzhDyxd = PwIzhDyxd;
        }
    }

    if (NCfkDZIulRnx <= 1860074544) {
        for (int DazmNVYPfIcvk = 1894749431; DazmNVYPfIcvk > 0; DazmNVYPfIcvk--) {
            XdiatEaql /= XdiatEaql;
            ZuIqUHkY = ZuIqUHkY;
            PwIzhDyxd = PwIzhDyxd;
            XdiatEaql += PwIzhDyxd;
            NCfkDZIulRnx -= NCfkDZIulRnx;
        }
    }

    for (int XsAQlaiffivi = 1984994574; XsAQlaiffivi > 0; XsAQlaiffivi--) {
        ZuIqUHkY = ZuIqUHkY;
        XdiatEaql += PwIzhDyxd;
        PwIzhDyxd *= XdiatEaql;
        XdiatEaql += XdiatEaql;
    }

    for (int QMNjgqoLMpYiAv = 1544527910; QMNjgqoLMpYiAv > 0; QMNjgqoLMpYiAv--) {
        ZuIqUHkY = ZuIqUHkY;
        XdiatEaql -= PwIzhDyxd;
    }

    for (int qGIlGchTGunxZ = 230338304; qGIlGchTGunxZ > 0; qGIlGchTGunxZ--) {
        XdiatEaql *= PwIzhDyxd;
    }

    return true;
}

bool efTkobDV::LdwpM(string mbmLwRztv)
{
    bool JtVYoTXb = true;
    int pIrWOU = 1002388798;
    int kGiqXcXAX = -1007472994;
    double DNseIuKvRRktGZsp = 717284.5176593855;
    double FlTrk = 586512.9368318166;
    bool xapytlsCFcLlQYQU = true;
    int cmtefgXEHnkvuI = -1957112593;

    if (FlTrk != 586512.9368318166) {
        for (int uUUlNtSFVQWRZEZt = 1223653251; uUUlNtSFVQWRZEZt > 0; uUUlNtSFVQWRZEZt--) {
            JtVYoTXb = JtVYoTXb;
            DNseIuKvRRktGZsp -= DNseIuKvRRktGZsp;
            pIrWOU -= cmtefgXEHnkvuI;
        }
    }

    for (int YXGPQw = 1366230694; YXGPQw > 0; YXGPQw--) {
        xapytlsCFcLlQYQU = xapytlsCFcLlQYQU;
        JtVYoTXb = JtVYoTXb;
    }

    return xapytlsCFcLlQYQU;
}

double efTkobDV::xIxtSVPkZG(double ZbcRSej, string TegFlKxvxnEnJ, int AOpAArGWYJ, string GRxcUbbRvEe, bool mcjqeyPlVUXZSQt)
{
    bool iIzCFFWgwhpqTHP = true;
    string giToPmzpbhVYAb = string("TEtMcJygwNrtSCahfRWkFfMRnZgDzqwujwFXpxAHbf");
    bool hZvMajER = true;
    double hLjqxaW = 155474.95946920165;

    for (int IoIwLtkmP = 1079842250; IoIwLtkmP > 0; IoIwLtkmP--) {
        TegFlKxvxnEnJ = TegFlKxvxnEnJ;
    }

    for (int SjSZXVuJLvvtenq = 983299005; SjSZXVuJLvvtenq > 0; SjSZXVuJLvvtenq--) {
        mcjqeyPlVUXZSQt = ! iIzCFFWgwhpqTHP;
        hZvMajER = ! hZvMajER;
    }

    return hLjqxaW;
}

double efTkobDV::qPlgYJnIRxhPfkGI(string hRyBZCKqr)
{
    string XDTFEFkqJ = string("TqTFIdqmfeDjyBLIyDnkAaZYCoTeQkEToNTyuZczQvXaibVtQUyGWndyXVQipdzLMqvyQzZypJXjqmkNZkfNbQeJZsBmvGdxIZQhInafUjQztpBGZakOgRdmfHIaWNnsierKJppCNBTPjNmipkszbMLGLwmUAFtSTHCjqgmavutEnogdJBQJbMRVSHCStGWWRTOppFroAReg");

    if (hRyBZCKqr != string("TqTFIdqmfeDjyBLIyDnkAaZYCoTeQkEToNTyuZczQvXaibVtQUyGWndyXVQipdzLMqvyQzZypJXjqmkNZkfNbQeJZsBmvGdxIZQhInafUjQztpBGZakOgRdmfHIaWNnsierKJppCNBTPjNmipkszbMLGLwmUAFtSTHCjqgmavutEnogdJBQJbMRVSHCStGWWRTOppFroAReg")) {
        for (int ShOCtWDjrZhmQgG = 1015320222; ShOCtWDjrZhmQgG > 0; ShOCtWDjrZhmQgG--) {
            XDTFEFkqJ = XDTFEFkqJ;
            XDTFEFkqJ = XDTFEFkqJ;
            hRyBZCKqr = XDTFEFkqJ;
        }
    }

    if (XDTFEFkqJ < string("TqTFIdqmfeDjyBLIyDnkAaZYCoTeQkEToNTyuZczQvXaibVtQUyGWndyXVQipdzLMqvyQzZypJXjqmkNZkfNbQeJZsBmvGdxIZQhInafUjQztpBGZakOgRdmfHIaWNnsierKJppCNBTPjNmipkszbMLGLwmUAFtSTHCjqgmavutEnogdJBQJbMRVSHCStGWWRTOppFroAReg")) {
        for (int PBgJnjjwzRKMNdaM = 1392786868; PBgJnjjwzRKMNdaM > 0; PBgJnjjwzRKMNdaM--) {
            hRyBZCKqr = hRyBZCKqr;
            XDTFEFkqJ += XDTFEFkqJ;
            XDTFEFkqJ += hRyBZCKqr;
            XDTFEFkqJ += hRyBZCKqr;
            XDTFEFkqJ += hRyBZCKqr;
            XDTFEFkqJ = XDTFEFkqJ;
            hRyBZCKqr += XDTFEFkqJ;
            XDTFEFkqJ += hRyBZCKqr;
            XDTFEFkqJ = hRyBZCKqr;
            hRyBZCKqr += XDTFEFkqJ;
        }
    }

    if (XDTFEFkqJ >= string("TqTFIdqmfeDjyBLIyDnkAaZYCoTeQkEToNTyuZczQvXaibVtQUyGWndyXVQipdzLMqvyQzZypJXjqmkNZkfNbQeJZsBmvGdxIZQhInafUjQztpBGZakOgRdmfHIaWNnsierKJppCNBTPjNmipkszbMLGLwmUAFtSTHCjqgmavutEnogdJBQJbMRVSHCStGWWRTOppFroAReg")) {
        for (int EXQlZMdP = 500714875; EXQlZMdP > 0; EXQlZMdP--) {
            XDTFEFkqJ += XDTFEFkqJ;
            XDTFEFkqJ += XDTFEFkqJ;
            hRyBZCKqr = hRyBZCKqr;
        }
    }

    if (hRyBZCKqr != string("wOeLZamoqExqglEYqDxiDQoaspNpCZBepwWCZJijmXtioZwmQHNDAYmwzHGPOyYaBBUrTQBNOpWyWNccBKqMkHZJaMtLjFPVkTavEazGIJuYeFAmvbjCkScmHRNhKTOznZnHZrGVtaMPrkHUJzbjDuWkLeHxxLUSmqFsoWttjpXlyedPadfrPUfjGsWhZpoZzDVOE")) {
        for (int zYLJU = 1466322592; zYLJU > 0; zYLJU--) {
            hRyBZCKqr += hRyBZCKqr;
            hRyBZCKqr += XDTFEFkqJ;
            XDTFEFkqJ += hRyBZCKqr;
            hRyBZCKqr = hRyBZCKqr;
            XDTFEFkqJ = XDTFEFkqJ;
            hRyBZCKqr += XDTFEFkqJ;
            XDTFEFkqJ += XDTFEFkqJ;
            XDTFEFkqJ += XDTFEFkqJ;
        }
    }

    if (hRyBZCKqr != string("wOeLZamoqExqglEYqDxiDQoaspNpCZBepwWCZJijmXtioZwmQHNDAYmwzHGPOyYaBBUrTQBNOpWyWNccBKqMkHZJaMtLjFPVkTavEazGIJuYeFAmvbjCkScmHRNhKTOznZnHZrGVtaMPrkHUJzbjDuWkLeHxxLUSmqFsoWttjpXlyedPadfrPUfjGsWhZpoZzDVOE")) {
        for (int hwdwRuDYew = 1029304451; hwdwRuDYew > 0; hwdwRuDYew--) {
            hRyBZCKqr = XDTFEFkqJ;
        }
    }

    return 862901.5308604197;
}

int efTkobDV::oEUajPKNVGXojb(double kyAtGde, double oAbgLUyIDhNfB, string dPvSiEH, int ahNYVYQYIwzqiYNX)
{
    bool xOlSlIArCAj = true;
    double egmTXAhlZUfyvrl = -252534.2339948826;
    double ridAwOghz = 609155.3125695725;
    double yDwsZSBSnSNomn = 388458.00679436716;
    string Zsibcqqp = string("FPTyzfYzNfBUevtznLrHjAGqwElWxbDbnnDuSSEVMeFIsWTByGjxoGbuQnuJhjfLvVfuWXomTxtonxHKPTCKpFWuLPGtewSWHwzJYouKUmVDxfaPwoBNLYBKBEefsXqxnXwElhBJfIDFMToZIxNepMyazGjZgElPdkiPObrSCtoEHsoPggRkWJtDtdutTpTaXbnzywXYFSHcspysVpthrjBZLGpLNzveXlCiSJuRQROuUV");
    string XeMvR = string("BXefPsNmEjbAoPyhYlAKXjhUYVvEbjnNWyWMyZSulqyvPzSOnHemfweEDehWZySjiqjbUfJPiTpfVmRFwXZIggmVuvoOYgBuUHgzLDFVdaQn");
    double SOnAVrjKt = 250049.98059555973;
    double bLMmSnr = -615517.6439963033;
    bool QCOrEhfBROfNuoGY = false;

    if (XeMvR > string("FPTyzfYzNfBUevtznLrHjAGqwElWxbDbnnDuSSEVMeFIsWTByGjxoGbuQnuJhjfLvVfuWXomTxtonxHKPTCKpFWuLPGtewSWHwzJYouKUmVDxfaPwoBNLYBKBEefsXqxnXwElhBJfIDFMToZIxNepMyazGjZgElPdkiPObrSCtoEHsoPggRkWJtDtdutTpTaXbnzywXYFSHcspysVpthrjBZLGpLNzveXlCiSJuRQROuUV")) {
        for (int omgcXhfR = 1686801588; omgcXhfR > 0; omgcXhfR--) {
            bLMmSnr -= ridAwOghz;
            egmTXAhlZUfyvrl *= ridAwOghz;
            yDwsZSBSnSNomn -= kyAtGde;
        }
    }

    return ahNYVYQYIwzqiYNX;
}

void efTkobDV::wCCnl(int TEiIlFSgKtzCrR, int PLWVXnpbFBB, string gwcOMrcfu, bool YAtGJIvkuiWeGehp, string UcpzULJj)
{
    int ddTpRfQdmA = 46230712;
    double bOJDqzWpBHywaOfr = 301973.06835533003;
    double HaRBGJHTSuKE = 1036316.892903633;
    int AAuJZ = 1887076517;
    string nMoxaunSmFxY = string("PyLxndQuWxuCFqQVoVAknABPsbzcwjFxtpwheOehCQrjXGHlvWREIllRgQ");

    for (int TCCefO = 1990974971; TCCefO > 0; TCCefO--) {
        continue;
    }
}

double efTkobDV::AUWqo(int DFoPYC, string mfNyxxwigDKdBI, string PnmNisCy, string RwiojutVXB, bool UCYrD)
{
    bool PPGswMG = true;
    string DBQEEOyuLJcKcvoM = string("rRlkpKpteWydMyttWZcakmkxnzBLxDIofheqKMQvTFtNyNelhARMiddlqiUpStxHSwNRxnFMXnGBvXzrzFpjsuiafWwKqIqSKTrwxkXAWjiaAXDkskrjbMkGkkrFXHWdRDFSTSSpkghWJIhLmFiiuHqjRybOiL");
    string KukNEtmcXRdAzVNV = string("CNhpnsutXvWhIWXMMuVwidXGEQRqCKgHcCRjYcZxjOKhjTqjiJCLQKsUbPGTsHmhPIWzHcMcUZwoMBeNjgukJAnnVOUAxBGUgInUMKMnWmsLvcwXfTFGMYyRsRhWosnyrWakPzoGZuPLXMZNSSvVFAhOesUvLRJqTgAoVSBhOnKrvQGXokevyXCYCklTkLJiJFFHoCdUNZfYnojAGlHIrJzMqVfiUgIlVYHS");

    for (int DoSFQuIp = 218504338; DoSFQuIp > 0; DoSFQuIp--) {
        KukNEtmcXRdAzVNV += RwiojutVXB;
        PPGswMG = ! UCYrD;
        DBQEEOyuLJcKcvoM = mfNyxxwigDKdBI;
    }

    return 142802.80061560197;
}

int efTkobDV::ZSNQCRPLOLhpZU(string BIhLvz, string oAsTlwc, bool iYxJNol)
{
    double wCjjPakuUGfnBDo = -846625.3700228862;

    for (int xkPbLCHelmokHhWh = 1913399275; xkPbLCHelmokHhWh > 0; xkPbLCHelmokHhWh--) {
        continue;
    }

    for (int tsTmjIUSTbyeAGPU = 266749173; tsTmjIUSTbyeAGPU > 0; tsTmjIUSTbyeAGPU--) {
        iYxJNol = ! iYxJNol;
    }

    if (BIhLvz <= string("LVshtLUXPwSuKoyjzczcXiOPTMyqxzuFqMYpZGscTbqvYnguNcEBASlLnULBYMmqxqFMWsuqzYNcOLcwcVqwituFonRuWdqxGbbbBEnBhtKLBANjfpPoKoaYLdWQGIdCfRKzu")) {
        for (int gKxjVRmqaqYr = 1335135462; gKxjVRmqaqYr > 0; gKxjVRmqaqYr--) {
            continue;
        }
    }

    if (oAsTlwc > string("LVshtLUXPwSuKoyjzczcXiOPTMyqxzuFqMYpZGscTbqvYnguNcEBASlLnULBYMmqxqFMWsuqzYNcOLcwcVqwituFonRuWdqxGbbbBEnBhtKLBANjfpPoKoaYLdWQGIdCfRKzu")) {
        for (int DuZFWDMVezMHikw = 2100888252; DuZFWDMVezMHikw > 0; DuZFWDMVezMHikw--) {
            BIhLvz = BIhLvz;
        }
    }

    if (BIhLvz != string("LVshtLUXPwSuKoyjzczcXiOPTMyqxzuFqMYpZGscTbqvYnguNcEBASlLnULBYMmqxqFMWsuqzYNcOLcwcVqwituFonRuWdqxGbbbBEnBhtKLBANjfpPoKoaYLdWQGIdCfRKzu")) {
        for (int gBAXzGJok = 2089340956; gBAXzGJok > 0; gBAXzGJok--) {
            BIhLvz = BIhLvz;
        }
    }

    return -691087164;
}

efTkobDV::efTkobDV()
{
    this->udVCvemeenZy(string("ErZFsnAtDwPEMjzwRnBkpnYqnGjknVcVZAgnTHOAHokySIWGMNCIMQNOZzNoEwLIdcUYaySlMbAxVJFWrGOfwtyAIpLQZhZVtrOGPZteXHxAsPNNuoFcaBicYAFzNMkHqoqcTUvOVAhCcJKCoARclQOFiGlFQkUKDFKITQd"), 761277905);
    this->BtepLMWwvIuifq(-868248304, -884291.3205409076, 207532.27268701044);
    this->ebZhirAlMcxoybD(string("VsVoynAISSgAAyNmKzgixlXThjyvXxIArlCNVuudtKBNXcUyQKxPvDhjxaUMsxMBklKQFrTOzxVafweHBEUGrNMThWLnfgeKhVaxhTmezMCPtYwTsEYnLBEmwZlgbrpIbXxnKRWRec"), -264732.65249735716, -288167.8247466793);
    this->LdwpM(string("CbozxeHBHoAPzAOlOajRNujShuSbakolgAcgmIlnkzTnjTldGBiEiuMZHPKivdpqfhqFVvCOQyqMlXKxQdptueaiJUhcXkdzFtFFXcgsYYQRTBImAjXdkXhHfUmTqVCQifTTVRH"));
    this->xIxtSVPkZG(-863139.2673408705, string("uapOprQpuKGEFvvsydmkzkHGTgLxpbJZCINqOXPwvanzHHGBxvuyYPAmMeSqnhAlpkzaZrvzxeOKgFTPibgPAxNyeenpxEpVPYcxjwFxmwSfqxCacFJFzPzllpacunHCLVXBQGFTuQeaDKcaMrGzMGyG"), -1475553202, string("CiQyUjbuvoESuMtcHHciHxVjuNklfSglVRCJRxwccgEts"), true);
    this->qPlgYJnIRxhPfkGI(string("wOeLZamoqExqglEYqDxiDQoaspNpCZBepwWCZJijmXtioZwmQHNDAYmwzHGPOyYaBBUrTQBNOpWyWNccBKqMkHZJaMtLjFPVkTavEazGIJuYeFAmvbjCkScmHRNhKTOznZnHZrGVtaMPrkHUJzbjDuWkLeHxxLUSmqFsoWttjpXlyedPadfrPUfjGsWhZpoZzDVOE"));
    this->oEUajPKNVGXojb(578918.0885254685, -866171.1483782852, string("jmfyldLToEDzrUJwEnuxDWlKvFLqsJRpmbVraGj"), -589224655);
    this->wCCnl(-1044485416, -148851696, string("zEVDzMXkfxtzqRrbPSbCjNBwLYDriqrjUjrvUxjIxNNnlPiSCOqTZbIlWUmHFeQmeBHctyCDvSrUsCuRnygHdJPnyxtWNCXxnasrZtdxExelnghkLErbHNBDuBBEkdAaenPOnlPzpIjqOiXrvBEnYcabbyMotMEKXUCXTQHHUdzMQPMhPPLDLQbvcxPEuZnRlFbrbGpmXwrdQdfiEWHeFLUmSbobHbDDDOYfpqgSqfcxtYsFC"), true, string("xgoThbHjVbyactExYcDBaIw"));
    this->AUWqo(1381813547, string("iqbxPpZjoVGYObmFqEdaMXuytVMCGkkDQuuXmEOXNlDzXdIQqOhjORxdwJhsnbCbNwVoQMYGRPGGfkNkXWAlEagxvOWKQeriujQDncBcTXBxKqDgAAgwHIbjqimlsYloDhSv"), string("HzvFKIgYHdeRSqcxpVlVCxAzEIPnMYZyzIeGLckJpQcZkgCpTalde"), string("islkLZuNiyWQWXjbfXnsscmWueAuUDlZjCHeATtzBKfAmi"), false);
    this->ZSNQCRPLOLhpZU(string("LVshtLUXPwSuKoyjzczcXiOPTMyqxzuFqMYpZGscTbqvYnguNcEBASlLnULBYMmqxqFMWsuqzYNcOLcwcVqwituFonRuWdqxGbbbBEnBhtKLBANjfpPoKoaYLdWQGIdCfRKzu"), string("WqlDPQeOuSFyZrhvCoYLchbojcHABzgPlomhCyIGKalSsqpkrsunxRKPXrmpZbkPmmdIrOdKEnAmpMaCohyDDOXWpbbBCsSfCINRaZNo"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SPorkemP
{
public:
    string ctSqRjdIYZwABtZD;
    bool aeQDMu;
    bool FyUoAZvJtCdpvFkF;

    SPorkemP();
    string MCmIghOw(string vGieULJvf, double jWAbRIPYkHTIyzzk, string FawwsOxnzdijhPo, int EPvNUhRoMcOQ);
protected:
    string isxukYOFWqG;
    double UcJsBKtHCKUqipD;

private:
    bool tUeOjkGkCeGHZRAq;
    string dtukUf;
    string DQXkuGHEdqV;

    int fgXEXtitBRo(double xNIzDZYWFfLGoeb, double bFozyaLowahrUq, bool URBihOhbW, int qpyWAEefzQageGmZ);
    bool jLhgmKDM(string ZrttTpxny, string BcceMiip, bool tikuGYIxnZHls);
    bool XLTYIvUkQEzOOtV(double MuIDVsoFbJTUDM, double zDhow, double UGHoNwdLU, string PgPmyKuRAptlmI);
    string kqswhDJqwVc();
    int thdXjMiHKgdDH(int TAOFbixbTtKOnBk, bool FMHPmHErKe, int WLICtxVuaT, bool uHPRepbGBEIrQrdQ, double YaqEbz);
    double DpjSHrDSYBNaShB(double cetBhb, int cGDHKnD);
    bool iCZEeyhNIQ(int sUmGJbDALasZZe);
    int LZLvSo(string fDrvmPXiUcxbN, string KfdVbyLRlxtLJy, string cTreuMohmpUnChXc, double tOfnKNMeX);
};

string SPorkemP::MCmIghOw(string vGieULJvf, double jWAbRIPYkHTIyzzk, string FawwsOxnzdijhPo, int EPvNUhRoMcOQ)
{
    string BUzHpFQzxAD = string("DjRGazJanQMUzQnHIAXEIbRvQXernbnZnmhZkIwODTtGaISToIZGUsqBaJuryrGBsLFPrqwRXuNLRZwMzpegJUqrTFlVZKLjYktbNhRgERotutUIdpmRFiByGaaLJGhzQbtlijJQRaPAkWPeokWpmomhdk");

    if (vGieULJvf > string("oZSojscxxPnJYGwSWhXiFCQFZQEenTUIpuXEqEielQZaZDeHdWnElCeoAoRibmzVRBdvrRphTcLMlhWosodFrkJDQBhbiAKDIaeFggCxVAEdWknuPtyEYAMuCUWLMJwGI")) {
        for (int TzTHCaMNPjRQt = 2147052169; TzTHCaMNPjRQt > 0; TzTHCaMNPjRQt--) {
            jWAbRIPYkHTIyzzk /= jWAbRIPYkHTIyzzk;
        }
    }

    return BUzHpFQzxAD;
}

int SPorkemP::fgXEXtitBRo(double xNIzDZYWFfLGoeb, double bFozyaLowahrUq, bool URBihOhbW, int qpyWAEefzQageGmZ)
{
    string qbWuHhbUpvhNfla = string("pDPkloDqEyiLEdEvWSQWylw");

    if (qpyWAEefzQageGmZ == 777895508) {
        for (int rgnqNQb = 1516102191; rgnqNQb > 0; rgnqNQb--) {
            URBihOhbW = ! URBihOhbW;
            qbWuHhbUpvhNfla = qbWuHhbUpvhNfla;
        }
    }

    for (int NcVsBHxOThN = 1141215497; NcVsBHxOThN > 0; NcVsBHxOThN--) {
        xNIzDZYWFfLGoeb += bFozyaLowahrUq;
        bFozyaLowahrUq += xNIzDZYWFfLGoeb;
        URBihOhbW = ! URBihOhbW;
    }

    return qpyWAEefzQageGmZ;
}

bool SPorkemP::jLhgmKDM(string ZrttTpxny, string BcceMiip, bool tikuGYIxnZHls)
{
    string ymsXqTtP = string("LkgsTWcIwgEOxAcmQveFbnDYEINsGhaEjnGTYiigJSjeSrUaUakNfwbzRdrjoPXTIVKmwtmaFBxRMMPENmpffqQZLcGgJEvKOeovpSsZJ");
    double KMmptHmC = 316210.746858882;
    double bkviMBJF = -425113.1587328782;
    bool SXHXcyA = true;
    bool KHCpiH = true;
    double rRUUTxR = 684971.7083480572;
    bool bSYjCeVNyf = true;

    for (int bcLUgugQvLTzT = 918710350; bcLUgugQvLTzT > 0; bcLUgugQvLTzT--) {
        bSYjCeVNyf = ! KHCpiH;
        tikuGYIxnZHls = ! KHCpiH;
        SXHXcyA = ! KHCpiH;
    }

    return bSYjCeVNyf;
}

bool SPorkemP::XLTYIvUkQEzOOtV(double MuIDVsoFbJTUDM, double zDhow, double UGHoNwdLU, string PgPmyKuRAptlmI)
{
    string lZqetNDrGCPwIv = string("xuwEBbkvhUOFwmMSChTpHPkAnFAjmujdVMcXgBDRwHJhfzucTIDEBSLJQxZiVDHwIBDwrXJvqPrXfMITrsmHSnaSOffhRcAJQQPTZmsGbmfvNWGfcCnYHKGmIJezhEzbYziiEtBOIaYmoOrPLYdJwPwNxPxJTRMGf");
    double OqnpL = -708700.7489861704;
    string zYAZAqAfsVfJvpAO = string("QbcKPnfMhIrtcatSsgiUewApjQHUZmgtyCapJMEUsSBTotWvdTIDuNKwRSnxdgqXNLRGsBnNuaDwoeIEmzNFRjFKZrhIjdqtEShGOJMwUwsSjFVSAzaYVgaefpZHnXEnBdTDldJaRlehlfxgGtUeciHecmTSPxkQQjnkyOqmziDijBRMKZIvkeI");

    for (int VjaSjCXMKEx = 1795318822; VjaSjCXMKEx > 0; VjaSjCXMKEx--) {
        PgPmyKuRAptlmI = PgPmyKuRAptlmI;
        PgPmyKuRAptlmI += lZqetNDrGCPwIv;
        zYAZAqAfsVfJvpAO = zYAZAqAfsVfJvpAO;
        UGHoNwdLU *= zDhow;
        OqnpL -= zDhow;
        UGHoNwdLU *= OqnpL;
    }

    if (zDhow < 497645.45192864886) {
        for (int WbxLIAlwJNDWMU = 592897727; WbxLIAlwJNDWMU > 0; WbxLIAlwJNDWMU--) {
            zDhow -= zDhow;
        }
    }

    return false;
}

string SPorkemP::kqswhDJqwVc()
{
    double LETgfkLffqEpF = -859309.4225915173;
    double DkQpRHI = -657049.2528557389;
    int kQQGrDOpdP = -1705257557;
    double WjIMQgcTUjVnXGgb = -70741.50027320354;
    string nCLUPIYwUeNC = string("AllTKDJQnnOvDEfweKVvYhMFprVKejYDaJRsYfdbAvDKuoVXTiaFRupeIghhUqyhzvToxAGjfYeYkiOYpdQoQTobQbjuMddqviVWWPZWdWODzHkgjXoybTkpTLswoPkUbrRgKceGadcYdhoDMaTKnmvgacaKWCidKwrZOCqrXgRRylhCKI");
    bool vQaBPYVSMrtbS = true;
    double DAqCzEkJ = 210294.13920352948;
    double ZJyzfsUN = -703513.5743611701;
    int fOMBXTahswUbD = -1451331629;
    string qAkNMuH = string("naKRcEXfEMfTWoKaWZAhDguLwneIBdQOBVZUEYipPSYITRmsyBbwUcRktBYuKavDHHaBQAgkWYSsuwNVavmEWdjrsPeFvufgENRUiFzIqpuzPYThUUUOQhvqLAXMcstNMhiwBsjQBzJmfUNbAhuHctoXRIRZMQSTIsjfVCkHMmXLvVzySm");

    for (int HSGHkQZEZOT = 1922134773; HSGHkQZEZOT > 0; HSGHkQZEZOT--) {
        continue;
    }

    if (DkQpRHI <= 210294.13920352948) {
        for (int mXLrVQ = 119898184; mXLrVQ > 0; mXLrVQ--) {
            LETgfkLffqEpF = WjIMQgcTUjVnXGgb;
            ZJyzfsUN += DAqCzEkJ;
            ZJyzfsUN += LETgfkLffqEpF;
        }
    }

    for (int kLTklKYn = 264554718; kLTklKYn > 0; kLTklKYn--) {
        DkQpRHI /= ZJyzfsUN;
    }

    if (WjIMQgcTUjVnXGgb != -657049.2528557389) {
        for (int cgDeBobX = 814052652; cgDeBobX > 0; cgDeBobX--) {
            continue;
        }
    }

    for (int AcCiHwfeOOOqVG = 1828443558; AcCiHwfeOOOqVG > 0; AcCiHwfeOOOqVG--) {
        DkQpRHI /= DAqCzEkJ;
        fOMBXTahswUbD += fOMBXTahswUbD;
        ZJyzfsUN = WjIMQgcTUjVnXGgb;
        vQaBPYVSMrtbS = ! vQaBPYVSMrtbS;
    }

    return qAkNMuH;
}

int SPorkemP::thdXjMiHKgdDH(int TAOFbixbTtKOnBk, bool FMHPmHErKe, int WLICtxVuaT, bool uHPRepbGBEIrQrdQ, double YaqEbz)
{
    string WcurAHXVFpUBGH = string("MbyHvDucUVfboifklrvAZJrotHUylSAQzEuDtVgeGWEhbfIMDyKQDaIpKGZFdZkoywNDUXarauGkzgBIiQKVYzzvEFTLMFsDgZdGhGSFzWyIJhpXcsohtSjaikxxEy");

    for (int RDUKlGzF = 1633016541; RDUKlGzF > 0; RDUKlGzF--) {
        TAOFbixbTtKOnBk = TAOFbixbTtKOnBk;
        TAOFbixbTtKOnBk -= TAOFbixbTtKOnBk;
        TAOFbixbTtKOnBk -= WLICtxVuaT;
        FMHPmHErKe = ! FMHPmHErKe;
    }

    for (int vPFPP = 1674502747; vPFPP > 0; vPFPP--) {
        FMHPmHErKe = ! uHPRepbGBEIrQrdQ;
    }

    if (TAOFbixbTtKOnBk == -1322531032) {
        for (int JXtxjAIoP = 1053817305; JXtxjAIoP > 0; JXtxjAIoP--) {
            WLICtxVuaT += WLICtxVuaT;
        }
    }

    return WLICtxVuaT;
}

double SPorkemP::DpjSHrDSYBNaShB(double cetBhb, int cGDHKnD)
{
    int rUUWmy = 2103896708;
    bool nOAWfwZEQup = true;
    double FTjTiPxZFfBjHAmr = -290542.5259080726;
    bool QtmttJvLrmH = true;
    double rBfndHiPAnWoUOjk = 799337.1113337099;
    double emAxVFLcJBCtbHZH = 923406.2613576851;
    double MJrZS = -545167.3157277112;
    double ZZKeWrar = 576214.3258905959;
    bool CrErsNT = true;
    int rVUkB = 1894721583;

    for (int bIfQZ = 2145577429; bIfQZ > 0; bIfQZ--) {
        rUUWmy -= rVUkB;
    }

    for (int DDYfiJbqBwAxZ = 749739920; DDYfiJbqBwAxZ > 0; DDYfiJbqBwAxZ--) {
        continue;
    }

    for (int hpnIPwnLc = 1672415488; hpnIPwnLc > 0; hpnIPwnLc--) {
        continue;
    }

    if (rVUkB <= 1894721583) {
        for (int OHTuUOHBPkUQ = 2078107862; OHTuUOHBPkUQ > 0; OHTuUOHBPkUQ--) {
            cetBhb += ZZKeWrar;
            rVUkB *= rUUWmy;
        }
    }

    return ZZKeWrar;
}

bool SPorkemP::iCZEeyhNIQ(int sUmGJbDALasZZe)
{
    string rboxuvHU = string("aLWPwBxkZnAjZTouej");
    bool akKGypvv = true;
    double huDReAruABXsmWR = -335600.04905516375;
    bool ZuwPHKrXzq = false;
    int rcISJEwkmXJMJ = -1910459403;
    string PtaoUEfvfCTZODpM = string("NYNYsjIhGaQuoNSSppA");
    int ZeZDXwztvLmpH = 1617663161;
    double lPQmSAKwYSs = 117868.04583706643;

    if (lPQmSAKwYSs > 117868.04583706643) {
        for (int RkDCfiWNkvmR = 115477901; RkDCfiWNkvmR > 0; RkDCfiWNkvmR--) {
            rcISJEwkmXJMJ /= ZeZDXwztvLmpH;
            huDReAruABXsmWR *= lPQmSAKwYSs;
            sUmGJbDALasZZe += sUmGJbDALasZZe;
            PtaoUEfvfCTZODpM += rboxuvHU;
        }
    }

    for (int bBFRCcdWhyBmg = 457834307; bBFRCcdWhyBmg > 0; bBFRCcdWhyBmg--) {
        sUmGJbDALasZZe += sUmGJbDALasZZe;
    }

    for (int ASrtYOQiG = 1027028356; ASrtYOQiG > 0; ASrtYOQiG--) {
        continue;
    }

    return ZuwPHKrXzq;
}

int SPorkemP::LZLvSo(string fDrvmPXiUcxbN, string KfdVbyLRlxtLJy, string cTreuMohmpUnChXc, double tOfnKNMeX)
{
    bool CxcceiC = false;
    int tnJplQtskzffvE = 1559334134;
    string SXoMMhemuTd = string("rrmmxXuNDEAAfUDZwkIUFNATUZfwstHcaXunIuCaptmkekmhYXNverRtukQjvTzhSDpmdztDKK");
    bool asuph = false;
    bool uOGxtFLPveUaTTy = true;
    double AoVwxUymCAWBrB = -940306.8624687069;
    string fJWdqQqYBD = string("pBxgOJkTuRKHrQjaXptpdfijaKXZMyscznIKeoEJnfzpwiqESVRgRFiejqODxcJCgFbxUJTgLRyARPcdiZJtuMvGclmmUZQJTSHKPKdpQtCWmekrUZYeaEAtBtQATIBIinZaGuMmLSFLlgCkwBnqdgyvwbGCxkGteWMWdCZptRAtGeOUbqKDesDoWNdAkXeLqJejzQQErVDAYhYO");
    double dklMGHEommoW = -439277.3379045104;
    double zEgKYM = 271055.67521534045;

    for (int vNSfqZytqmhiBE = 1957746454; vNSfqZytqmhiBE > 0; vNSfqZytqmhiBE--) {
        continue;
    }

    if (cTreuMohmpUnChXc >= string("wLWnuMflGGgKpMaCfGLADeYzDHqiIPujdBNMoTDHpkzuxsgSGxIsrZlCerEHLznyLGtxTSKEuOnHpPBHzHWuSWSJuGRsVtVJwdJNDfJnsBaFFfAQaVJmdbHJvwyxKNUclfuVDWZVvlxMoKdlOQYWifqXKhjrlFVCIGWXkeuEdEZLCMMrNHefQyLSLvxheErtFDtKdrQwWTgjwtrnmCTuVukgnCLmFxNSRDBAZTwkkBznXlCFTXj")) {
        for (int vjYZGgSO = 419900726; vjYZGgSO > 0; vjYZGgSO--) {
            SXoMMhemuTd += KfdVbyLRlxtLJy;
        }
    }

    for (int doqkRheXEeJP = 197962716; doqkRheXEeJP > 0; doqkRheXEeJP--) {
        tOfnKNMeX = tOfnKNMeX;
        fJWdqQqYBD = SXoMMhemuTd;
    }

    for (int xVLYNhQDIISZqIC = 1785641496; xVLYNhQDIISZqIC > 0; xVLYNhQDIISZqIC--) {
        fDrvmPXiUcxbN = fDrvmPXiUcxbN;
    }

    if (tOfnKNMeX <= -940306.8624687069) {
        for (int zPQJLOedLyQ = 802036849; zPQJLOedLyQ > 0; zPQJLOedLyQ--) {
            tOfnKNMeX /= dklMGHEommoW;
            cTreuMohmpUnChXc += fDrvmPXiUcxbN;
        }
    }

    return tnJplQtskzffvE;
}

SPorkemP::SPorkemP()
{
    this->MCmIghOw(string("oZSojscxxPnJYGwSWhXiFCQFZQEenTUIpuXEqEielQZaZDeHdWnElCeoAoRibmzVRBdvrRphTcLMlhWosodFrkJDQBhbiAKDIaeFggCxVAEdWknuPtyEYAMuCUWLMJwGI"), 185849.38096073037, string("FNwRBhaYFpRbMUzqXnSXtxtzCDPsHhtGfxQkdwGxABTBRYHMVfuDdMiEhdQAOZKDjesTmxXnerwllYyMnFCuKwvwnEphXAKvcKLnVGTxfXsiEYiVzyHmnKlUeDHkHMGgxeotlatnERRAWBMyEtdbZFYVoHndudo"), -51037092);
    this->fgXEXtitBRo(-715963.6828674931, 50530.954641463024, false, 777895508);
    this->jLhgmKDM(string("LDWhoMyGWhOYbHcHJHaKvGjOgTRDLgcbmQebxYHzmVqzmRQjYxRpLZOnnNdWqpWBSkArlRgWpGgSPBgrctuaTqqHtJpyayXwJUmPslkGHeBmaIycvIvrXSAGrV"), string("PlgjufyIHrXgXuohZuAsmPfXhrpoqkYFvDWfCFNdGvqqmljDcRpzhZtRKsezXbZgzFlmsPSnkTxIXZeUpACCPCqvHMzVwlJMpULzwUIsHdbdZsvRfAGJjMzWdbrNPtHrzWOhQJvlSmObSJjSmvQDuOMUCVcChUbSYBkoIwxUcZYelGcCHubUbprZtiHEwDe"), false);
    this->XLTYIvUkQEzOOtV(497645.45192864886, 335081.68814602966, 639632.2036904092, string("aUttkfNBDuVAMtzVMgKzARdBzkjxQGfSXTQbdkS"));
    this->kqswhDJqwVc();
    this->thdXjMiHKgdDH(179061869, false, -1322531032, false, -733603.970703722);
    this->DpjSHrDSYBNaShB(1018747.815755922, 1551536649);
    this->iCZEeyhNIQ(-1860088022);
    this->LZLvSo(string("KVMxVjCdHpBsIlKJRdPHkSaaaolYsILJrEaneSmiBvWfTaQAeTyyenHnpIVjAAisBATewfvBcSBIDzGpixjNyJbDVIjcfTvBQjyIKbcsOaXHjuXQtbwqrLHSvhSyEtAMgHNvPVeGqwbABXmAsdBrvqdjkFnOE"), string("XjGoTiAaZJEqCTHBiPkmHGtxiTrLDilchzUEKoWuwKcQOFHbqtXaXYRADPlnQmnDOKeRs"), string("wLWnuMflGGgKpMaCfGLADeYzDHqiIPujdBNMoTDHpkzuxsgSGxIsrZlCerEHLznyLGtxTSKEuOnHpPBHzHWuSWSJuGRsVtVJwdJNDfJnsBaFFfAQaVJmdbHJvwyxKNUclfuVDWZVvlxMoKdlOQYWifqXKhjrlFVCIGWXkeuEdEZLCMMrNHefQyLSLvxheErtFDtKdrQwWTgjwtrnmCTuVukgnCLmFxNSRDBAZTwkkBznXlCFTXj"), 999153.9780534774);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xjaCGNhsWdPJFPNL
{
public:
    string cIjRTnqLL;
    string TpeGftEK;

    xjaCGNhsWdPJFPNL();
    bool SdSLNmg(string dcYRdtsGEwC, string IQRreONiZOREsL, string fUZqhQhLqUlbw, int GAIGVaqCV);
    bool zrwZZXkDDcFLWvn();
    string RbbkVnAzoeepiLG(double zDPKRxzVgtXoDA);
    string sHAoROn(double iytarloNnUtMgkW, bool XhYayxNFltL, bool wpEEHRMXXdQZTtbC, int cUnBIANoUN);
    void DXRHqtwyR(string dGifQEvmL, string xrDFN, bool hxxpLV, bool cAgVQPpv);
    void VrbLnRaVpStevjct(bool qBSQaZYblol);
    void iZqmJRKO(int rsuFc, double vOTOCPAMeZEiKo, double DcTAiImL, double MbGXHkWoeEjDlKON);
    bool lSdcgesjHgTX(int gPejcxZawLi, bool BrKnmamhfN, string RRxNgFGVZEKITi, int fdielNjopATid, bool vTQZuVMgZatlcj);
protected:
    string uDIwt;
    bool xmdxsb;
    double WnJKJ;

    bool uktWJFiSwlK(int tnXijP, bool YnuiHARCfVWcN);
    int tFKiqDofgmQAMzxb(string HjspzM, int DaQtzrje);
    void IDjxXZGN(double HCvbvSlfpn, int hLVOGHkiMfgpsXq);
    int AoEmVmqWKWMyOZ(string OGPzKXpzhxFVk);
    int yrOgNxSswd(bool UqhRsMfanJTcb);
    double ScKbWqOFxdqnEbQB(string WBlFpgnGy, bool qLqHJHWhvPAkX, int MnDDmYQJyFCK);
    int iJMUOCppDrsmGg(string SBzimggkf, int wCxyj, string gLqss, int zfLRiT, string JNCJFGqMV);
    string DSBeEw(string mKWKOXJ, bool jizroXAbDWqeP, bool rCDSeBKkPYLv, bool LUHMnxUkaXycGWIu);
private:
    string FwPZhiBWBmphuXO;
    double ZKPdaTTPf;
    double UXLPSvosy;
    string bOEswjt;

};

bool xjaCGNhsWdPJFPNL::SdSLNmg(string dcYRdtsGEwC, string IQRreONiZOREsL, string fUZqhQhLqUlbw, int GAIGVaqCV)
{
    bool IOaSKYddFHW = false;

    if (fUZqhQhLqUlbw < string("yGtPZMAYgepelHgkNlBhAiaVlLfvJLtbZmmFiZnUsMjoYbLtilUZIJxmEyEeuDsrfmpZfRdItnKblIpLKXfgNrVJglbaccHZOROjkxtyPePF")) {
        for (int btUYvjHJSKDaD = 705045515; btUYvjHJSKDaD > 0; btUYvjHJSKDaD--) {
            IQRreONiZOREsL = fUZqhQhLqUlbw;
            dcYRdtsGEwC += IQRreONiZOREsL;
        }
    }

    for (int ksiPCfciQk = 1835520798; ksiPCfciQk > 0; ksiPCfciQk--) {
        dcYRdtsGEwC += dcYRdtsGEwC;
    }

    for (int rCxwqdeqUz = 614222196; rCxwqdeqUz > 0; rCxwqdeqUz--) {
        fUZqhQhLqUlbw = dcYRdtsGEwC;
        fUZqhQhLqUlbw = dcYRdtsGEwC;
        dcYRdtsGEwC = dcYRdtsGEwC;
        dcYRdtsGEwC = dcYRdtsGEwC;
    }

    for (int VoxFKiRs = 56524541; VoxFKiRs > 0; VoxFKiRs--) {
        fUZqhQhLqUlbw = IQRreONiZOREsL;
        IQRreONiZOREsL += fUZqhQhLqUlbw;
    }

    if (IOaSKYddFHW == false) {
        for (int otQQDiM = 1472346956; otQQDiM > 0; otQQDiM--) {
            IQRreONiZOREsL += dcYRdtsGEwC;
            GAIGVaqCV /= GAIGVaqCV;
            dcYRdtsGEwC += dcYRdtsGEwC;
        }
    }

    return IOaSKYddFHW;
}

bool xjaCGNhsWdPJFPNL::zrwZZXkDDcFLWvn()
{
    string jXLLpjExiAji = string("tGELgDzXPZfiTwRVWLURcUnziwGAZhKSPbTpDrYONbqMEDyhuIZHdpDVxvJaUcSMtGVROKBYKoGTDXAUgnMBGXrRcwREtEAbneqKwozrytmibALqdKGbBCdordVnjhNsWjVTMHspNppKFuGZGMsQVBDZlQSCOBqolYOWeVmzJZEPVaMkrvIkrzOxDexYyEeEEPmkLxWLHHICZZhYnQQnUXHFj");
    bool QfYfxoOHQQlwkm = true;
    int sOazWvXokcGpcL = 114518139;
    int uRyIMBfwlzGXITs = -1646523904;
    double MtHDHRCTLWX = 678223.0947323309;
    double CMLPSxYTMvudsNX = 170522.37803006746;
    bool XXLAngCWYK = true;
    bool yJWuLHwaovEyHfO = false;
    string QowyBZh = string("QHJezPcwmhDWtFCuOawSZrySDXPXoyLeDZlFRoOWCcYYdqEfxWaiiztAvkGWgDUxfOwSSlQgBdJMQBuJzSAKbIvwrGQpwnuxSZANBIiGrjpJjrNGIOTcwZIKAVaoldMTHtVWTlmVRHCLAblghrmnFqYeKQovoWuHgMGChStPJXflSzJdCpSYRnsRx");

    for (int FbjGDyuSvmswbx = 1425499628; FbjGDyuSvmswbx > 0; FbjGDyuSvmswbx--) {
        CMLPSxYTMvudsNX /= CMLPSxYTMvudsNX;
    }

    for (int xJjNhyKpXD = 1109930780; xJjNhyKpXD > 0; xJjNhyKpXD--) {
        yJWuLHwaovEyHfO = ! yJWuLHwaovEyHfO;
        XXLAngCWYK = QfYfxoOHQQlwkm;
    }

    return yJWuLHwaovEyHfO;
}

string xjaCGNhsWdPJFPNL::RbbkVnAzoeepiLG(double zDPKRxzVgtXoDA)
{
    bool ryCjhtgeN = true;
    double LJNRRZewaFGCNO = 892751.4367068168;
    double XbLbhunYWQrrbA = 111574.7428191976;
    double aVhNanmMgvmhKW = 371278.49071818753;

    for (int NsokUVmBm = 537364754; NsokUVmBm > 0; NsokUVmBm--) {
        XbLbhunYWQrrbA += aVhNanmMgvmhKW;
        aVhNanmMgvmhKW -= XbLbhunYWQrrbA;
        aVhNanmMgvmhKW = LJNRRZewaFGCNO;
        zDPKRxzVgtXoDA = LJNRRZewaFGCNO;
    }

    for (int SjCxRcFY = 61407802; SjCxRcFY > 0; SjCxRcFY--) {
        LJNRRZewaFGCNO *= LJNRRZewaFGCNO;
        zDPKRxzVgtXoDA += XbLbhunYWQrrbA;
        zDPKRxzVgtXoDA = XbLbhunYWQrrbA;
        LJNRRZewaFGCNO = zDPKRxzVgtXoDA;
        ryCjhtgeN = ryCjhtgeN;
    }

    for (int MafolhVweZV = 1892087715; MafolhVweZV > 0; MafolhVweZV--) {
        zDPKRxzVgtXoDA = LJNRRZewaFGCNO;
        XbLbhunYWQrrbA -= aVhNanmMgvmhKW;
        ryCjhtgeN = ! ryCjhtgeN;
        XbLbhunYWQrrbA += XbLbhunYWQrrbA;
        zDPKRxzVgtXoDA /= XbLbhunYWQrrbA;
        zDPKRxzVgtXoDA /= XbLbhunYWQrrbA;
        zDPKRxzVgtXoDA = LJNRRZewaFGCNO;
    }

    for (int ilfWCFMXswxVcdgr = 1765463428; ilfWCFMXswxVcdgr > 0; ilfWCFMXswxVcdgr--) {
        zDPKRxzVgtXoDA = LJNRRZewaFGCNO;
        zDPKRxzVgtXoDA -= aVhNanmMgvmhKW;
        XbLbhunYWQrrbA += LJNRRZewaFGCNO;
        XbLbhunYWQrrbA *= LJNRRZewaFGCNO;
    }

    for (int gEBPLBOZFQufaJO = 1847190215; gEBPLBOZFQufaJO > 0; gEBPLBOZFQufaJO--) {
        LJNRRZewaFGCNO -= XbLbhunYWQrrbA;
        zDPKRxzVgtXoDA *= LJNRRZewaFGCNO;
    }

    return string("ctpjgCdDMLMCSnJcVPoVNSkQmZGtOanFLbhDVSRQoRXXqmnYsgXlxJMqTLnoYxIpZDmCETLButkVNDEGUpHaVVrbJhSXFOHEJCQoIxdVdAomSxZfWKaVqjBcTNhzacIPcxxoUTUKUuRPKEwpWQmdQJmnUsqxJCysKrFlTwOXCXqzzrxKWe");
}

string xjaCGNhsWdPJFPNL::sHAoROn(double iytarloNnUtMgkW, bool XhYayxNFltL, bool wpEEHRMXXdQZTtbC, int cUnBIANoUN)
{
    int cxvrz = -159233085;
    int IZnPnPe = -53302894;
    double otBwzSZ = 468074.5152835832;
    double pgltJ = -555962.4563133442;
    bool XhdbN = true;

    for (int KJKKbPbVi = 1853668460; KJKKbPbVi > 0; KJKKbPbVi--) {
        XhYayxNFltL = wpEEHRMXXdQZTtbC;
        otBwzSZ = otBwzSZ;
    }

    for (int TzXKlGdRgpY = 1113974771; TzXKlGdRgpY > 0; TzXKlGdRgpY--) {
        XhYayxNFltL = XhYayxNFltL;
    }

    for (int DXNBGROwGUY = 951701331; DXNBGROwGUY > 0; DXNBGROwGUY--) {
        XhYayxNFltL = XhYayxNFltL;
        XhdbN = ! XhYayxNFltL;
        pgltJ *= iytarloNnUtMgkW;
    }

    for (int ajsHnzJf = 832829077; ajsHnzJf > 0; ajsHnzJf--) {
        continue;
    }

    return string("hZEMLHutGsofJkxeCwvISnQvpYlGEerbKeAEWetwBWHPJKBlxWryqaKgigryjqWtDxAwBKH");
}

void xjaCGNhsWdPJFPNL::DXRHqtwyR(string dGifQEvmL, string xrDFN, bool hxxpLV, bool cAgVQPpv)
{
    double yvfvQhjN = -568002.7486314356;
    int weWAItmHlNTgPlJi = 1090791505;
    string uCcYvQKF = string("uRbBCKHzkqlzvEfSnGVVvuyMAbHGVOLZHmdNaAiIEScrhAtPKlHBsUfmidftDUsKtTuWrBnGUTIfjVaYMpEBtImZAWMDIZDJjnfnEfKwQhMOoL");

    if (weWAItmHlNTgPlJi == 1090791505) {
        for (int DUmITxWNmfjjIvW = 2030977254; DUmITxWNmfjjIvW > 0; DUmITxWNmfjjIvW--) {
            weWAItmHlNTgPlJi /= weWAItmHlNTgPlJi;
            cAgVQPpv = ! cAgVQPpv;
            dGifQEvmL += uCcYvQKF;
        }
    }

    for (int IOeWVTwDIRIY = 2131493477; IOeWVTwDIRIY > 0; IOeWVTwDIRIY--) {
        dGifQEvmL += xrDFN;
        uCcYvQKF = uCcYvQKF;
        xrDFN = dGifQEvmL;
        dGifQEvmL = uCcYvQKF;
    }

    for (int dLHQl = 2062634068; dLHQl > 0; dLHQl--) {
        continue;
    }
}

void xjaCGNhsWdPJFPNL::VrbLnRaVpStevjct(bool qBSQaZYblol)
{
    double yhkJeQpESi = -908142.1917990815;
    string PhYvSy = string("naUMVhmQVZShUqBIkedoflMvRmnFHlHcjaXZAnDkWMgbeavMQhBmBBXpVRfBxtoMsMxXYXddcozSXPHgIcmWzZmgvNebhDeKrcLblNkeLnViBMxJeMmTbmqBqVYUYIDftKHJLCsyBPGcAccRVbBXFw");
    int yvICAQOgeS = 284593113;
    bool rTTfSFsLBpkRN = false;
    int hSGuQtyJVnk = -1817696345;
    int QqIFxODK = 1349782019;
    string IujOqi = string("NjGZopmYLkAeufkjvhUPEfzYxLLXMlgrlAmdhanhu");
    string WkNXC = string("GrJiJAc");
    bool ljZtFoTnSJ = false;
    int aGZlaXqIHuYlrk = -1415953915;
}

void xjaCGNhsWdPJFPNL::iZqmJRKO(int rsuFc, double vOTOCPAMeZEiKo, double DcTAiImL, double MbGXHkWoeEjDlKON)
{
    bool aPQntBzEVfXkgb = true;
    int tLGQreYWzKpLpBI = 519587699;
    double seDGPzlXY = 445131.13255245093;
    bool RwtnFN = true;
    string KpdCISOaMyf = string("RfTJnlJAQuNGtCkhAKKTpBnPSUMeHRtFFQdSvdZGbRPXoKsUDnhNqIEvyjUTMhRRLdqylmumSQTYBIIbHDeMiVEXVLbXUJRKYGzHDnuIvpHsAPciVWBTPViruMFhBbgacZheHjmknXuEClZrCijJaHpbQnjWMioCNhMqsYDpToJCoCtPOTnSmMAEOjaFYCCZkoWFCFdpqmgxBLKyHolli");
    bool sqDWZ = true;
    int wfUjlvmavsQNkRF = 1383919846;
    int SpWFGtpGAAHvVMeT = -784800312;
    double bmeTNdoeyFHpJf = 129283.40532862551;

    for (int ZcHhxqkQmjjy = 1280464873; ZcHhxqkQmjjy > 0; ZcHhxqkQmjjy--) {
        DcTAiImL -= MbGXHkWoeEjDlKON;
        wfUjlvmavsQNkRF -= SpWFGtpGAAHvVMeT;
        DcTAiImL *= bmeTNdoeyFHpJf;
    }
}

bool xjaCGNhsWdPJFPNL::lSdcgesjHgTX(int gPejcxZawLi, bool BrKnmamhfN, string RRxNgFGVZEKITi, int fdielNjopATid, bool vTQZuVMgZatlcj)
{
    bool kXgYtVmYrPlGiZJd = false;
    int GgFZExRjgn = -1317648436;
    bool nzstcVmDEvgSfosE = true;
    int UdtyqaCfKbMd = -1151536636;
    double QZNtEZybNPWTHY = 534825.3893434157;
    double bfwobTd = 46749.51445158084;

    for (int dLJyopB = 2018314146; dLJyopB > 0; dLJyopB--) {
        gPejcxZawLi = fdielNjopATid;
        vTQZuVMgZatlcj = nzstcVmDEvgSfosE;
    }

    return nzstcVmDEvgSfosE;
}

bool xjaCGNhsWdPJFPNL::uktWJFiSwlK(int tnXijP, bool YnuiHARCfVWcN)
{
    double CLPJrxHzTu = 471242.6900863175;
    double fWfXvmiHmEQ = -173897.86724838076;
    int bvCAD = 1571912042;
    int kukLGcZftpJwUI = 1098980736;
    string ekdoIumXAKBHx = string("ggztmNUpSHvTPrvBxXUljvwNdQLTpikFvIWNtxRbapgWyfwXhzpEXmEQuHUIMhmjksDjDgOMuRYPTmcEuLibVOQvtTJcoSSpiDkjlejsomRJZhgoOwENFKjALdavUHcCBsPRiSpPmIsnBzPcVgCEvVBbijfgeBvYXGitEdMHgYXvcwCKfVMCEXUeyPSwJh");

    for (int inMijWcYcKuVW = 1242639324; inMijWcYcKuVW > 0; inMijWcYcKuVW--) {
        bvCAD -= kukLGcZftpJwUI;
        fWfXvmiHmEQ -= CLPJrxHzTu;
    }

    return YnuiHARCfVWcN;
}

int xjaCGNhsWdPJFPNL::tFKiqDofgmQAMzxb(string HjspzM, int DaQtzrje)
{
    string WlOFAkdvaIzWp = string("kLMkqkCMByzJgwQLdflKLNlDttkoeqaijLGnsTlzAxroGCzgeQH");
    bool TPqFmXuwq = true;
    bool AEypuarhtpY = true;
    int sxRqMQBm = 1338805179;
    string TTjBhOVqVKOwAGLU = string("sqGifYBAPyDDfuRdDWrozYWtfbnMNYtQTXrTVSqQjlNKRCkwgoBdDaYJmeQHcnGjhiezKaRzMBkiYiUcwEcZtLeXldzdrSMYTWDdPrdLjZqBVjOaGDARAbzehSLsLQfAEqFEDYvpRlJNDPwpCdaQwYYyTedozdjcqsowwVAjVJ");

    for (int YbFxaXpjeiczekIp = 1280148738; YbFxaXpjeiczekIp > 0; YbFxaXpjeiczekIp--) {
        sxRqMQBm /= DaQtzrje;
        WlOFAkdvaIzWp += HjspzM;
        TTjBhOVqVKOwAGLU = TTjBhOVqVKOwAGLU;
        AEypuarhtpY = AEypuarhtpY;
        DaQtzrje -= sxRqMQBm;
    }

    for (int QNhcLPFkO = 315032464; QNhcLPFkO > 0; QNhcLPFkO--) {
        TTjBhOVqVKOwAGLU += TTjBhOVqVKOwAGLU;
        sxRqMQBm /= sxRqMQBm;
        TTjBhOVqVKOwAGLU += TTjBhOVqVKOwAGLU;
        HjspzM += WlOFAkdvaIzWp;
        HjspzM += HjspzM;
    }

    for (int rewwSEWj = 574301634; rewwSEWj > 0; rewwSEWj--) {
        HjspzM = WlOFAkdvaIzWp;
        sxRqMQBm -= DaQtzrje;
        HjspzM = WlOFAkdvaIzWp;
        HjspzM = HjspzM;
    }

    return sxRqMQBm;
}

void xjaCGNhsWdPJFPNL::IDjxXZGN(double HCvbvSlfpn, int hLVOGHkiMfgpsXq)
{
    double YPTiFZNudfdx = -733198.4487475458;
    double wdDiZSNyLoVO = 1004840.4175042138;
    string uaCYUczyELezk = string("KbXYJotWnHmTdHevUqifQAhNLxbRMvWOLVaNwhpLImkIwkgjpKBomHMLmvEehvlmtQIHtaHCGnXXqQumdxgWLDiCTT");
    int WtZNncJkC = 345453792;
    double HoAVUdsVlQghGH = 539967.6443107445;
    bool nBRZYimkWPzDp = true;
    int sXxsLhRwYi = -216205954;
    string dfVZD = string("EXVJUZgshspmpexiojwdYAnzVlvgmsiHlOvnuBQufQpbDNbepiaugPcTHXZyRnlQdaFhRfhLBNLkxQrSaKoVrLxcRDOimYVYaDhOcmAgQHoJZBmEvYstKq");
    int uOClqvJyjzz = -342672953;
    string daxWjM = string("rSYKzmNHfNuMNWZJdNQyQoMvm");

    for (int hetkoZ = 2056931311; hetkoZ > 0; hetkoZ--) {
        HoAVUdsVlQghGH = HCvbvSlfpn;
        WtZNncJkC = hLVOGHkiMfgpsXq;
        dfVZD = dfVZD;
    }

    for (int iQxsQvOdh = 1504366883; iQxsQvOdh > 0; iQxsQvOdh--) {
        YPTiFZNudfdx += YPTiFZNudfdx;
        uaCYUczyELezk += uaCYUczyELezk;
    }
}

int xjaCGNhsWdPJFPNL::AoEmVmqWKWMyOZ(string OGPzKXpzhxFVk)
{
    double YDbEQCjCRVqdPQBl = 1047501.0221756025;
    bool lNBLrfhlkqNv = true;
    bool RmeUOGX = false;
    bool NTkHOMdgu = true;

    for (int cYKxoh = 2092499959; cYKxoh > 0; cYKxoh--) {
        RmeUOGX = lNBLrfhlkqNv;
    }

    for (int suhAHHGfgr = 454015323; suhAHHGfgr > 0; suhAHHGfgr--) {
        lNBLrfhlkqNv = ! lNBLrfhlkqNv;
        NTkHOMdgu = lNBLrfhlkqNv;
        OGPzKXpzhxFVk += OGPzKXpzhxFVk;
        NTkHOMdgu = lNBLrfhlkqNv;
        NTkHOMdgu = NTkHOMdgu;
    }

    return 1727714620;
}

int xjaCGNhsWdPJFPNL::yrOgNxSswd(bool UqhRsMfanJTcb)
{
    int chqjLnw = 1238492394;
    double CfBHQILFnYPGbbK = 768752.2632829753;
    string SFiZEfdGyjTdXwZ = string("QThHkMaOhgTbHjKdasEmBbpXgQvQziSpPeAXgwrJDSXTgaQNgpJFCbDHBjynmOiBLWbXGIUQwKfTRaHmSZW");
    bool ohHfpI = true;
    string dMfMFRipsXVyRfhX = string("CVGVipEXvENvrdClcUVmWnpzrCRPIYESIBOnKgTbGmjhJDtrHFboCLPDnrd");

    return chqjLnw;
}

double xjaCGNhsWdPJFPNL::ScKbWqOFxdqnEbQB(string WBlFpgnGy, bool qLqHJHWhvPAkX, int MnDDmYQJyFCK)
{
    double udQLPpgkqU = -82467.26018704662;
    bool GqbztwCK = true;
    bool exAZWaKznYNay = false;

    for (int bRbmqzwFcENC = 1916411817; bRbmqzwFcENC > 0; bRbmqzwFcENC--) {
        exAZWaKznYNay = GqbztwCK;
    }

    for (int GUFyacYqrwy = 1761499761; GUFyacYqrwy > 0; GUFyacYqrwy--) {
        qLqHJHWhvPAkX = ! qLqHJHWhvPAkX;
    }

    if (GqbztwCK != false) {
        for (int BAkPXqtuUSApAS = 38213601; BAkPXqtuUSApAS > 0; BAkPXqtuUSApAS--) {
            exAZWaKznYNay = qLqHJHWhvPAkX;
            exAZWaKznYNay = exAZWaKznYNay;
        }
    }

    if (WBlFpgnGy == string("HOoVpbIslTvGBujgvicjWaclZBTXmib")) {
        for (int DpYtrB = 6556041; DpYtrB > 0; DpYtrB--) {
            qLqHJHWhvPAkX = GqbztwCK;
            exAZWaKznYNay = ! qLqHJHWhvPAkX;
        }
    }

    return udQLPpgkqU;
}

int xjaCGNhsWdPJFPNL::iJMUOCppDrsmGg(string SBzimggkf, int wCxyj, string gLqss, int zfLRiT, string JNCJFGqMV)
{
    double sIOMVrC = 682257.3179883435;
    double ndOIldChxe = 793720.8614360153;
    double qPybSiZXl = -383865.6702380184;
    int mGcLdjEcNLRv = -730701157;
    string UHIPTfyugL = string("DPhTfJZKvcCrTxWJwEtBylypVeDLXpxLgEOLFbhkrGvvkNTRaCDDCAFErOlisLqtDJGNlCkbCNXFuJxyrpUEuFSJLQbFURkjDePsgYPocTjvLqHwuFAijiGEXBsYbDUSqsTjoXgCWpJZhQHPPtGcOUmqMYhUINsJRFvkaJCLBMyxuWxnCwWdpEDHvTJyNSaIIstBUzwmOTxYVYppDAawZcAoHyCSBEcfikR");
    bool YfcyaHSNflfSKa = true;

    for (int ucRkJ = 849434034; ucRkJ > 0; ucRkJ--) {
        zfLRiT = mGcLdjEcNLRv;
        sIOMVrC *= ndOIldChxe;
    }

    return mGcLdjEcNLRv;
}

string xjaCGNhsWdPJFPNL::DSBeEw(string mKWKOXJ, bool jizroXAbDWqeP, bool rCDSeBKkPYLv, bool LUHMnxUkaXycGWIu)
{
    bool BUJSHHJpV = true;
    string jXtUUK = string("vgWRNgHVSUFtYoYfHwaQAxWZtxCpdOOssFrQEqIBqGAPpVdiBNEoCwLlatbPdGlNTiLDdtoIQmkHIVStGmLglFWhRHBGFzxZlbKJijrtuythrYCGtkcMlpLDisOyrBLkUwRJDDpXXtbgkzSNJNqVLwkAjaoKXtLHeDIOEFITZglRGMODAhfjPswnFNLUbOukjXzcqspOZrXfARSKHNECiemPIJGmzyZdmLHoDgOtfLuiJsSVjWHqJYh");
    double MutTmXuvVAXCvMox = 421288.41445342684;
    string uTolAB = string("rgtISagozmyOAZDUgEbWpLXYGRHexfnxcVJlAZWfCoMIwbJjedIJpyXUnWNTABLmKJpjJohwAaPFVirmipEiLufqcXFaIOBxiSNlhTwxupxqy");
    string ASqIobIkYHIHH = string("nJOYffeaAUrPmhnAOlOMghSTydfZvkqrLWaDfFzlnteTHGyxnTYxDUtlzQaQtuyhmfpKRXSkmxsDlJbgujuVouiLJFGPeVBeLVcWjnZoRyRlcsGHCOozXuuomXBWnKsVAkrsuIXjQqYsUPRGmoaKpHpsJGdLIfIrdkZfrucbRzLHv");
    bool lfXAZSqavg = true;
    bool KivXVSVdP = true;
    string IpHjbNH = string("goVjhHCdExKHQNdrFgDwrCHGHEsSHmfrqAGApCmRuhzMvdKUiyUHQSCaIlXwuHCsOEQweqSeZYpPjUvvkdQUoFDrIStHooxIjuaicvKoLkZxdrQbWXqehXjMvMEPEIkQgosZHBlbJRPLf");
    double XAFkLXn = -694794.4822496871;
    double XCuVJFCyTtlB = 409954.9005599016;

    if (lfXAZSqavg != false) {
        for (int DooBjGGhhUCABrwG = 113193506; DooBjGGhhUCABrwG > 0; DooBjGGhhUCABrwG--) {
            continue;
        }
    }

    for (int LMeWtdzKe = 1014279423; LMeWtdzKe > 0; LMeWtdzKe--) {
        continue;
    }

    for (int KxjQSKz = 1259952472; KxjQSKz > 0; KxjQSKz--) {
        LUHMnxUkaXycGWIu = ! KivXVSVdP;
    }

    for (int bBPeq = 2141225575; bBPeq > 0; bBPeq--) {
        XAFkLXn /= MutTmXuvVAXCvMox;
    }

    return IpHjbNH;
}

xjaCGNhsWdPJFPNL::xjaCGNhsWdPJFPNL()
{
    this->SdSLNmg(string("yGtPZMAYgepelHgkNlBhAiaVlLfvJLtbZmmFiZnUsMjoYbLtilUZIJxmEyEeuDsrfmpZfRdItnKblIpLKXfgNrVJglbaccHZOROjkxtyPePF"), string("bcZelYLjuyJJoAqAWsPdPYuubYyPWzumfOgbEAiueEEhbOrHbMtbYiDgqZyOFjBHfJINXZQFkHqkMd"), string("dOidczQCkFQYmnJdwsrPHjwaxGXqyhVAUgvZgUPBvjAMATrTnAMNGuxjjJxG"), 66174638);
    this->zrwZZXkDDcFLWvn();
    this->RbbkVnAzoeepiLG(-736015.4214540328);
    this->sHAoROn(606813.6672328998, false, true, 792945084);
    this->DXRHqtwyR(string("FdrpfPvMaSwISZWPEqAObtJvQEdoYrYdJJzsCtSwZgOHUGmuCFigdOOYWqsRBGzqGVPYNaeHpuqBAAtiPvpXfPhyRwoBLmJlTEQvActEfobZUkGrwpWUtsrdmIAfpEMjqSTXnZpOrpdOGXNsxELUDqTRPHbdzOoBAgFfpTMZFttTMNTgrNWPLHYFPkvPCgYhxOMdLvzf"), string("yRKOUjMeUzQQKOkTPItcpUKiaLVkkXFFqYdgcgvjVnBgGUxJNrooJKxuKRtwldoASdKBzxDKKUVJhdfpciOsuaVVuxOwTotJJNSeTwI"), false, true);
    this->VrbLnRaVpStevjct(false);
    this->iZqmJRKO(1820862314, 538050.7555834439, -1020104.018420049, 923952.6049571035);
    this->lSdcgesjHgTX(910257384, false, string("SQtFUpxJzJQiJXnJarobqfmVYdIuzqWROWSeNZfpUMgHV"), -1944708494, true);
    this->uktWJFiSwlK(-762594096, true);
    this->tFKiqDofgmQAMzxb(string("xJKHIZaeJdTPXNXQCMixAJFSVPQFZwxROoFSkfnVteBHugWFpGEaMMmadTjvfJhBGmgrTeFlRfVATcGLNgZxCkJADlYZLKgtTYrCSQitoVLqaZbsWvUWiRukiefJELxyfOiDS"), 1567038194);
    this->IDjxXZGN(-524880.7834039249, 1401405716);
    this->AoEmVmqWKWMyOZ(string("YQfQiuPXXhjnSzxeGtQYsVwINKUGThRxpFtrmfkLqjfEubaUkuXIAnHEfpftgIsbOYgegzjCAOKQkoySsznoNEajaHfx"));
    this->yrOgNxSswd(false);
    this->ScKbWqOFxdqnEbQB(string("HOoVpbIslTvGBujgvicjWaclZBTXmib"), true, 896068046);
    this->iJMUOCppDrsmGg(string("liRpLWOBnQYbOtbvexClUjIqNGMTShLlFtxPuGvXvDfABIrsdTPxpkTxLRsuefCYOnEWDpteOQBYQLqJNdRzpGzBYuuyrhQrAIymBmfg"), -532780190, string("ZJYeWLpyloRbZsIUYVYMKCdowgCCYlUOUaJmcIyEalxZejdllulHDcOsTtVNwIplfsUxnceBGPumHkKlTLjrzDZcEDXIUehJQBYwASrodRAoiKvkPgyFCWRfSUtGysVeBFqIndpBwJdcibqAFeWGUDYfKhduGSHNeHzuMnQjQiOafmLzIPVXIhbeNbalpGRungQVZWlbW"), 170280842, string("ULtQKpiMeoRCRYOtVRvCzjHWAJoTCgnMuzUoPTmMqdLluvdYkkqXDPKk"));
    this->DSBeEw(string("PkKSlcIVBMEILvQqtAXcvUryxNvOaXDfTjKLMljIqOpUaPRlwSOkoafrVuzhXwuxuLObTxOt"), false, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HyzaNBxeCPGokh
{
public:
    int fHXnpwcufZz;
    bool PyEsHpmSkqZfz;
    double oCBsOd;

    HyzaNBxeCPGokh();
    int XLNhKNTErFRKchEo(int pnGxaMb, int hsbWErbpqaFjerw);
    int GRVAgvRCvTPTZIC(double wsXGaNZ, double yhplaXKTHJiuI, string rxmTvFHsJr);
    double YwWPZ(int swRTdXikSBveEwU, string hNZzGxePXa);
    bool LIWVSwAtxrUs(int CDbSqYmjBoEAcYF, double VNDaARBEwEwVFRw, double oNYdDbwrwdbIjr);
    string LJVoFQCpHvB(int RodqjBUcnIwc, bool PWQuNpXaCER, int NKHeEMzHJrt);
    string lfuLXvonJOHqJa();
protected:
    double LGedloy;
    string arGueYHfSloJmJJi;
    string ErOzxItx;
    double tvsafhLRJJXPgEc;
    double HSjAJbGwXC;
    string fDRDdW;

    bool TIwKhIjWtGuNH(string mScDJMa);
    int jJzFL();
    void zPxXEmTxNuIKofm();
    bool aFMidBedn(int KQOWdjkPxfiY, double xzMAdbXleXAeWgKQ, int twvSNRShfC);
    int UCgMtGVeFmdIOvwB(string yUpDCRsfABng, bool GcJiWgLGhjyyGhk, bool ANdpjzemkFNkUWwL);
private:
    bool Ptemk;
    double KTvZtUMMyVS;
    bool bFQoFnNfYqEY;
    string zLvqNUubKL;
    int utLzdIOeGP;

    string RcrrdaEXIYDu(double SyiWo, string UEFiTPQRtFAV);
    double FSdpcaTJDeYULrS(int TzkHGqiZiwISYjh);
};

int HyzaNBxeCPGokh::XLNhKNTErFRKchEo(int pnGxaMb, int hsbWErbpqaFjerw)
{
    string DkvbNzqSbN = string("dsTJJjVAbWUANtscfwnRcleZZlnvOsctOKsnHwIAGFlzyfTYszWBtLETaXtoTOXjoqlxWSvdzEPVJNwLBJWLGcJsHYsBeofCeWUHUCSuQUDvxqtgtFkEZUiBnNMPviFoYCVKHRgSsfxiJuNHiVUXWQmnKhRGyAaXZlmjXO");

    for (int AXbIXd = 1234359220; AXbIXd > 0; AXbIXd--) {
        hsbWErbpqaFjerw = pnGxaMb;
    }

    for (int RjyeqNpVgfXlr = 242899856; RjyeqNpVgfXlr > 0; RjyeqNpVgfXlr--) {
        pnGxaMb = hsbWErbpqaFjerw;
    }

    return hsbWErbpqaFjerw;
}

int HyzaNBxeCPGokh::GRVAgvRCvTPTZIC(double wsXGaNZ, double yhplaXKTHJiuI, string rxmTvFHsJr)
{
    string lCEEkNweG = string("BMEYAscCFvGPGzySnDiSeQRODMXmntaOderyZzemNcBwyUiTTUCLTOqYPYwZQqqDfjexOlfZyyXjXcDDamNsVFFKSNrxliFtuurfjkRHRnVMkKMOKeukqZkawFqMKIbzsFouWoUpMwckOcoQmzedQNifDQPAJtIKtMZQBEUcPFhZldUjQgnxrXmQFLyaCaFUKyjhUowlmtbPhyOlGikDYLzngrUBUAIGjEtRmdFbvgaBVAkguuwcKT");

    for (int rbTkYu = 1992589479; rbTkYu > 0; rbTkYu--) {
        yhplaXKTHJiuI -= yhplaXKTHJiuI;
        lCEEkNweG = lCEEkNweG;
        yhplaXKTHJiuI = yhplaXKTHJiuI;
    }

    if (lCEEkNweG <= string("BMEYAscCFvGPGzySnDiSeQRODMXmntaOderyZzemNcBwyUiTTUCLTOqYPYwZQqqDfjexOlfZyyXjXcDDamNsVFFKSNrxliFtuurfjkRHRnVMkKMOKeukqZkawFqMKIbzsFouWoUpMwckOcoQmzedQNifDQPAJtIKtMZQBEUcPFhZldUjQgnxrXmQFLyaCaFUKyjhUowlmtbPhyOlGikDYLzngrUBUAIGjEtRmdFbvgaBVAkguuwcKT")) {
        for (int zAlZuXHVeW = 1799923514; zAlZuXHVeW > 0; zAlZuXHVeW--) {
            wsXGaNZ += wsXGaNZ;
        }
    }

    return 602986211;
}

double HyzaNBxeCPGokh::YwWPZ(int swRTdXikSBveEwU, string hNZzGxePXa)
{
    string hEMBr = string("rdkSlwLWdpeGdJJadipwZPtiWgFyzEPscfzgsaNN");
    bool eXoewJ = false;
    double PmFqfY = -702188.0603934522;
    bool udcFXbGTk = false;
    string XFITBR = string("AMGLtTkljQtgLibPUooTJwzWokgZZXemLklvjQgHMeoskVsRHUPCYNpSpJswaJqnZiTTJocedTMGykkazhWZGFsqbToavuRAztnOCDGAxVUnjNPUSEve");
    bool DiLKsJmsdRQtmluI = true;
    bool jCoXo = false;
    double mBkYNyRNpdcIpxBk = -902645.099807921;
    int IKSAvqBAHmEAxF = -840719316;
    string wZGpviPiDrPF = string("ywXRvOBlzdUBMHsuuwWlcFzFJTJPYfrqhvgEfRnRZLy");

    return mBkYNyRNpdcIpxBk;
}

bool HyzaNBxeCPGokh::LIWVSwAtxrUs(int CDbSqYmjBoEAcYF, double VNDaARBEwEwVFRw, double oNYdDbwrwdbIjr)
{
    double WruORnLkb = 552726.7831233798;
    double qRdcYolrG = -1036409.6456992088;
    string LbnAKdKuVOPJsNfT = string("RKvJBlPeraGwTodRBrOseBVAHjKdXTmKMZLZkrABCzQyDZhmWhoXdPBhiKeYbijMrjvYwFNKQYcqgrzGokYRGSvOoYWhazNjLFeNQnsDUEWQuDPuSrfrjbnXyZGgwKTuCltESCZLmXmuncRlBEbnSurtJVkJjTblJoiUgmvFAuYrNMzX");
    string cAQMRAF = string("CevSXfYArebPsVAqHBaBXXsNKncTePNEWgKRRVAVgnNnwbdJWRRfeLibmLAHCGXfepGhhpEvBjjcIaBUWEUKKsqZW");
    int ZFeDOsORCBcpg = 809240013;

    if (LbnAKdKuVOPJsNfT >= string("CevSXfYArebPsVAqHBaBXXsNKncTePNEWgKRRVAVgnNnwbdJWRRfeLibmLAHCGXfepGhhpEvBjjcIaBUWEUKKsqZW")) {
        for (int cxmaAvR = 416025246; cxmaAvR > 0; cxmaAvR--) {
            continue;
        }
    }

    if (ZFeDOsORCBcpg >= 481560819) {
        for (int oWYpYlYotGRlGl = 1600973012; oWYpYlYotGRlGl > 0; oWYpYlYotGRlGl--) {
            WruORnLkb /= WruORnLkb;
            WruORnLkb *= oNYdDbwrwdbIjr;
        }
    }

    for (int bgqcMhkSMKDttalV = 1889832885; bgqcMhkSMKDttalV > 0; bgqcMhkSMKDttalV--) {
        VNDaARBEwEwVFRw = qRdcYolrG;
        ZFeDOsORCBcpg *= ZFeDOsORCBcpg;
        oNYdDbwrwdbIjr = WruORnLkb;
        VNDaARBEwEwVFRw += qRdcYolrG;
    }

    if (qRdcYolrG > 903098.6179824391) {
        for (int EgXVMHkqIQGnPl = 410891560; EgXVMHkqIQGnPl > 0; EgXVMHkqIQGnPl--) {
            CDbSqYmjBoEAcYF /= CDbSqYmjBoEAcYF;
            ZFeDOsORCBcpg += ZFeDOsORCBcpg;
        }
    }

    if (cAQMRAF == string("RKvJBlPeraGwTodRBrOseBVAHjKdXTmKMZLZkrABCzQyDZhmWhoXdPBhiKeYbijMrjvYwFNKQYcqgrzGokYRGSvOoYWhazNjLFeNQnsDUEWQuDPuSrfrjbnXyZGgwKTuCltESCZLmXmuncRlBEbnSurtJVkJjTblJoiUgmvFAuYrNMzX")) {
        for (int oGMerG = 1908704416; oGMerG > 0; oGMerG--) {
            LbnAKdKuVOPJsNfT += cAQMRAF;
            qRdcYolrG += oNYdDbwrwdbIjr;
        }
    }

    for (int ZKPHgj = 1266780350; ZKPHgj > 0; ZKPHgj--) {
        CDbSqYmjBoEAcYF += CDbSqYmjBoEAcYF;
        VNDaARBEwEwVFRw /= VNDaARBEwEwVFRw;
    }

    for (int IXdZjEc = 1561924460; IXdZjEc > 0; IXdZjEc--) {
        WruORnLkb *= qRdcYolrG;
        oNYdDbwrwdbIjr += qRdcYolrG;
    }

    return true;
}

string HyzaNBxeCPGokh::LJVoFQCpHvB(int RodqjBUcnIwc, bool PWQuNpXaCER, int NKHeEMzHJrt)
{
    double waInIHnMW = 36246.97186869298;
    string twvvtsLQAsNXJzJd = string("rKyITZTzRXKkaPaoYM");
    bool hjeBDzmVxpyNRoNl = false;
    double EnsAZbxeej = 265263.9599549639;
    bool rOIoxbLt = true;
    int dDnJUROOuOCKV = -1306294616;
    bool QSmJUmyQnJajN = false;
    int bykGzE = 1027188890;
    double FKxpIiaHaIzrw = -316350.5419543554;

    for (int VNifIYkTTL = 2111712355; VNifIYkTTL > 0; VNifIYkTTL--) {
        PWQuNpXaCER = PWQuNpXaCER;
        dDnJUROOuOCKV *= bykGzE;
    }

    for (int ZaVxkKoV = 14487465; ZaVxkKoV > 0; ZaVxkKoV--) {
        EnsAZbxeej /= FKxpIiaHaIzrw;
    }

    for (int TNevVpsFeh = 366603591; TNevVpsFeh > 0; TNevVpsFeh--) {
        EnsAZbxeej /= FKxpIiaHaIzrw;
        NKHeEMzHJrt *= RodqjBUcnIwc;
        FKxpIiaHaIzrw *= waInIHnMW;
    }

    for (int YxdQQXw = 30948681; YxdQQXw > 0; YxdQQXw--) {
        QSmJUmyQnJajN = ! rOIoxbLt;
        EnsAZbxeej -= waInIHnMW;
    }

    if (NKHeEMzHJrt < -1306294616) {
        for (int BOPSmsux = 237479158; BOPSmsux > 0; BOPSmsux--) {
            bykGzE -= NKHeEMzHJrt;
        }
    }

    for (int KCuzsNMKT = 1415343254; KCuzsNMKT > 0; KCuzsNMKT--) {
        continue;
    }

    return twvvtsLQAsNXJzJd;
}

string HyzaNBxeCPGokh::lfuLXvonJOHqJa()
{
    double yHtMskeysO = 129742.86834581193;
    int oDYinaE = -644880348;
    string wKrJwUZQS = string("MjPqQFnypuAWaAbOfWuutvfqDtTUqXWDXPcIIKgzTSztIqPDZuBDuqZJeFGksXPwsMtiJlCKwoZQchOVBKlOmGGrfPdHWsIrIKZXmtZaLnbFNYjEqbRNHCGcrbfGPwnEXHmIopsQLCncZAXkcpEkeoPEZdURliiodtPZtNTUfgSDNvJoLOVKjnvpXpFPlkLEyUTKdjGMeovFnTMTOmzIPYwXOmlAUXoraToXXfYcDoYyvBRyJTRTvGdze");
    double kFBDE = -855530.6424461555;

    for (int cOqgyLMHxfpwEROo = 600131274; cOqgyLMHxfpwEROo > 0; cOqgyLMHxfpwEROo--) {
        kFBDE = kFBDE;
    }

    for (int DOiOciBz = 660925492; DOiOciBz > 0; DOiOciBz--) {
        oDYinaE += oDYinaE;
        wKrJwUZQS = wKrJwUZQS;
    }

    for (int DJaQjIVa = 1411733997; DJaQjIVa > 0; DJaQjIVa--) {
        yHtMskeysO = yHtMskeysO;
    }

    for (int bnBpUBuXXdC = 1335858749; bnBpUBuXXdC > 0; bnBpUBuXXdC--) {
        yHtMskeysO *= kFBDE;
        kFBDE /= yHtMskeysO;
        oDYinaE = oDYinaE;
    }

    return wKrJwUZQS;
}

bool HyzaNBxeCPGokh::TIwKhIjWtGuNH(string mScDJMa)
{
    string TquSU = string("IOhZBNKGnbNaebssHDiUnzNmdEBmKqcCtSxSUXVwgfhwfDqBcRgLiPuzNcjVZHYf");
    int IgJDTkKdo = 1623451562;
    string iOarNImO = string("oQBhRGgpJaKycTmTxSnkTQzHqKuXSOxbMREKexuHygWlwHPJHGsoQxfjRzGofHqLxTQAEdXmeuPvMXTUNkvcWVFkRevZYZIYJmFruESpEnWxUGxigzUqKjyBkmdVlYXK");
    string vadzOrlXkJTU = string("yHbhoIS");

    if (mScDJMa < string("yHbhoIS")) {
        for (int kKhhbXqRRDV = 1546152071; kKhhbXqRRDV > 0; kKhhbXqRRDV--) {
            mScDJMa = TquSU;
            TquSU += vadzOrlXkJTU;
            vadzOrlXkJTU += TquSU;
        }
    }

    if (vadzOrlXkJTU != string("IOhZBNKGnbNaebssHDiUnzNmdEBmKqcCtSxSUXVwgfhwfDqBcRgLiPuzNcjVZHYf")) {
        for (int eCKnrMe = 154863016; eCKnrMe > 0; eCKnrMe--) {
            TquSU = vadzOrlXkJTU;
            iOarNImO += mScDJMa;
        }
    }

    for (int jSPtpVupWpf = 1388069287; jSPtpVupWpf > 0; jSPtpVupWpf--) {
        TquSU += mScDJMa;
    }

    if (vadzOrlXkJTU >= string("yHbhoIS")) {
        for (int zGlvEgkwhe = 687499198; zGlvEgkwhe > 0; zGlvEgkwhe--) {
            TquSU = TquSU;
            iOarNImO = vadzOrlXkJTU;
            mScDJMa = vadzOrlXkJTU;
            iOarNImO = iOarNImO;
        }
    }

    if (vadzOrlXkJTU < string("oQBhRGgpJaKycTmTxSnkTQzHqKuXSOxbMREKexuHygWlwHPJHGsoQxfjRzGofHqLxTQAEdXmeuPvMXTUNkvcWVFkRevZYZIYJmFruESpEnWxUGxigzUqKjyBkmdVlYXK")) {
        for (int cAIRNtjFslqro = 1590673095; cAIRNtjFslqro > 0; cAIRNtjFslqro--) {
            iOarNImO = mScDJMa;
            iOarNImO += mScDJMa;
            IgJDTkKdo *= IgJDTkKdo;
            vadzOrlXkJTU += TquSU;
        }
    }

    return false;
}

int HyzaNBxeCPGokh::jJzFL()
{
    string pVFEeyEyTix = string("AoiMHHvUyjENDwqjPefWvNfjJIJwrXstFYbjjKyNlxRxqbmVtqkilKZogiNsFrBFKHvFxPFCZYvcFz");
    bool WLrJE = true;
    bool cuOSmEv = false;
    int uhjzwlurIHjzxQmV = -1680649188;

    if (pVFEeyEyTix < string("AoiMHHvUyjENDwqjPefWvNfjJIJwrXstFYbjjKyNlxRxqbmVtqkilKZogiNsFrBFKHvFxPFCZYvcFz")) {
        for (int jEpFRtZgeU = 1815308676; jEpFRtZgeU > 0; jEpFRtZgeU--) {
            continue;
        }
    }

    for (int HFMDjRtYSpQ = 685024916; HFMDjRtYSpQ > 0; HFMDjRtYSpQ--) {
        pVFEeyEyTix = pVFEeyEyTix;
    }

    return uhjzwlurIHjzxQmV;
}

void HyzaNBxeCPGokh::zPxXEmTxNuIKofm()
{
    double WBSSlIPlj = 206700.28846239188;
    bool pSaVvALekmHJRuTl = true;
    int WzLaNAKzSIVI = -107947330;
    int WBSzqYpWOg = 326388426;
    int MgHBqsAzqwl = 2048640616;
    double jeWMzujZVBG = -601549.7366062938;
    bool AEcRRUhJofV = true;
    int DSaqYdghm = 375294426;

    for (int zeusNhxX = 2001961659; zeusNhxX > 0; zeusNhxX--) {
        pSaVvALekmHJRuTl = pSaVvALekmHJRuTl;
        WzLaNAKzSIVI /= WzLaNAKzSIVI;
        MgHBqsAzqwl = WzLaNAKzSIVI;
    }

    if (DSaqYdghm >= 2048640616) {
        for (int QqeoSQkDRmpaCsMQ = 640655133; QqeoSQkDRmpaCsMQ > 0; QqeoSQkDRmpaCsMQ--) {
            WBSzqYpWOg = MgHBqsAzqwl;
            WzLaNAKzSIVI *= MgHBqsAzqwl;
            jeWMzujZVBG *= WBSSlIPlj;
        }
    }

    for (int RvFHtavDKKleRdqn = 1100481652; RvFHtavDKKleRdqn > 0; RvFHtavDKKleRdqn--) {
        WzLaNAKzSIVI /= WBSzqYpWOg;
    }
}

bool HyzaNBxeCPGokh::aFMidBedn(int KQOWdjkPxfiY, double xzMAdbXleXAeWgKQ, int twvSNRShfC)
{
    double pwOCpnGVKW = -423674.4960158762;
    bool mUkvwH = true;
    int sRalRZyURhn = 2054999719;
    int gkMKASbMVO = -1545618271;
    double ABmwGUlKNzlM = 1047210.892045119;
    int qwqEirPvkRFz = -1700269355;

    for (int AlNxPFvLuZUnQIL = 597839931; AlNxPFvLuZUnQIL > 0; AlNxPFvLuZUnQIL--) {
        twvSNRShfC *= twvSNRShfC;
        twvSNRShfC = sRalRZyURhn;
        qwqEirPvkRFz += qwqEirPvkRFz;
    }

    for (int TKcGPrHV = 998646811; TKcGPrHV > 0; TKcGPrHV--) {
        qwqEirPvkRFz /= twvSNRShfC;
        qwqEirPvkRFz /= qwqEirPvkRFz;
    }

    if (gkMKASbMVO < 459315328) {
        for (int HQiNxEGUZOsYjQt = 1661493073; HQiNxEGUZOsYjQt > 0; HQiNxEGUZOsYjQt--) {
            KQOWdjkPxfiY = sRalRZyURhn;
            gkMKASbMVO = KQOWdjkPxfiY;
            KQOWdjkPxfiY += sRalRZyURhn;
            twvSNRShfC -= twvSNRShfC;
            xzMAdbXleXAeWgKQ -= pwOCpnGVKW;
        }
    }

    return mUkvwH;
}

int HyzaNBxeCPGokh::UCgMtGVeFmdIOvwB(string yUpDCRsfABng, bool GcJiWgLGhjyyGhk, bool ANdpjzemkFNkUWwL)
{
    string ETJzSf = string("lkAUDguEfDKGWXeTWSuicdPvmtrXsVpGVngQCLLDlQWbKwHiUtVjuWefkJfRdaQXTpJpniXTIGwexbmZSjSjnis");
    string EMVbTK = string("dVGSYNupVxWzqYogWMKKTYInBpmObHjFULJBmGdPuiNVyFnPQrwuEfEBlKNezxrSkUXepIsrKqcsdraNYBOnqavZrwtPoJnYlbmwViQWShYJNIpftMEWBxEcoeCZOUvYnoeSTAATNJxPxkdj");
    double DeffKVfd = 145253.6993979436;
    string YaTzMcZGNZAEu = string("ctkmlZOmrUbWKGJfgqwclFNuivfAnKbdodiGuttssJelQHobLPkfaFDWCFOxeDsrjiPUOPWPieMleOKMYYJbtHeUJuTrjAEUnJUamQtwefXgVaVvXyxzOiUoBhXWrdmuNOUEpfZoBGaqjjSJPxkEwsGqGNhKOngwYQPdOgupSJdtSbquezjwYcIAmbrRkLPiI");
    string fqMGyNUbwNFGM = string("OxXEtZVGtIwOuCsmtJDpxhzObWGpzFObCiLMKSlVonhlUWFTjaMaGFtzMlomWaCJWcBIAmQUBKeERs");
    bool bdvctX = false;
    double WnxhkZLq = 851596.009735827;
    string pQblGxjZ = string("jjaJxLTGoPnrgpexiLBkQQAfwktOjPMtPlnsTjPvNTKoQtLoHebZOURkfaRgYpnWjWgSEBRbdhYYywdJQqualAwHdmynxGmwRFrnMRAOEq");
    double ctLrRjluGWCGdP = 111599.01508303023;
    double YlmZbjRswXTm = 638431.5841020297;

    for (int iyWAgJRNaqppV = 148505696; iyWAgJRNaqppV > 0; iyWAgJRNaqppV--) {
        continue;
    }

    if (fqMGyNUbwNFGM >= string("LDLuyHLzndqXmscKSuzarTeUiMxjeNGBUenYGHTOlcnqXZWdEKXYrvwaQPvlCTYGEAKI")) {
        for (int wYBDrRxmV = 1194296659; wYBDrRxmV > 0; wYBDrRxmV--) {
            continue;
        }
    }

    if (yUpDCRsfABng < string("LDLuyHLzndqXmscKSuzarTeUiMxjeNGBUenYGHTOlcnqXZWdEKXYrvwaQPvlCTYGEAKI")) {
        for (int rIDDbUt = 1467276637; rIDDbUt > 0; rIDDbUt--) {
            YaTzMcZGNZAEu = pQblGxjZ;
        }
    }

    return 1049308446;
}

string HyzaNBxeCPGokh::RcrrdaEXIYDu(double SyiWo, string UEFiTPQRtFAV)
{
    bool iQljy = true;
    bool naDbU = true;

    for (int kqxTDzbvMP = 693142975; kqxTDzbvMP > 0; kqxTDzbvMP--) {
        naDbU = ! iQljy;
        UEFiTPQRtFAV += UEFiTPQRtFAV;
        iQljy = iQljy;
    }

    for (int SzNbyjpUQvhTG = 1775055873; SzNbyjpUQvhTG > 0; SzNbyjpUQvhTG--) {
        iQljy = ! iQljy;
        UEFiTPQRtFAV += UEFiTPQRtFAV;
        iQljy = ! naDbU;
        iQljy = iQljy;
    }

    for (int GIXQTArTZNnmzwk = 1973910104; GIXQTArTZNnmzwk > 0; GIXQTArTZNnmzwk--) {
        UEFiTPQRtFAV = UEFiTPQRtFAV;
        naDbU = ! naDbU;
        iQljy = naDbU;
    }

    if (iQljy != true) {
        for (int yqnjGcYlROQJi = 186647243; yqnjGcYlROQJi > 0; yqnjGcYlROQJi--) {
            SyiWo += SyiWo;
            naDbU = naDbU;
        }
    }

    return UEFiTPQRtFAV;
}

double HyzaNBxeCPGokh::FSdpcaTJDeYULrS(int TzkHGqiZiwISYjh)
{
    int dctSoilUAGT = -405336585;
    string yTnRYF = string("wsrOYBdbLwEwnLrVYSguRqbsrHMVvjenPJltgedlXqpZQwmedOFsvsCLkIiZxUhDSwYPqZzyjLqLKTZCvcrmwgwNRQDbKFuBhMFBlYxYFcwnGESklIUoEBEYxREUEkRgBvgqgVwbuPJstDQaRrmlnAHGbYxYDZPQdysqsEDjNgHijuVZ");
    int GGEPLh = -1285012672;
    double ZvrTcH = -464033.34538511117;

    for (int FwQUjPuntaolMWTq = 1761185523; FwQUjPuntaolMWTq > 0; FwQUjPuntaolMWTq--) {
        GGEPLh /= GGEPLh;
    }

    if (TzkHGqiZiwISYjh >= -405336585) {
        for (int FyzMcIa = 1716435591; FyzMcIa > 0; FyzMcIa--) {
            GGEPLh /= dctSoilUAGT;
            GGEPLh -= dctSoilUAGT;
            dctSoilUAGT /= GGEPLh;
            dctSoilUAGT = TzkHGqiZiwISYjh;
        }
    }

    for (int BfgdigCScHHSV = 1657484633; BfgdigCScHHSV > 0; BfgdigCScHHSV--) {
        GGEPLh /= GGEPLh;
    }

    if (TzkHGqiZiwISYjh > -2056326773) {
        for (int oGhNi = 1852808589; oGhNi > 0; oGhNi--) {
            dctSoilUAGT *= GGEPLh;
            dctSoilUAGT *= dctSoilUAGT;
            TzkHGqiZiwISYjh += dctSoilUAGT;
        }
    }

    return ZvrTcH;
}

HyzaNBxeCPGokh::HyzaNBxeCPGokh()
{
    this->XLNhKNTErFRKchEo(762678548, -627094267);
    this->GRVAgvRCvTPTZIC(261498.30716303093, 655902.4613788573, string("HyzNVNjxtisJBQCuBZWjYOvXezEdoKgjxIoUHTWTLBkjzx"));
    this->YwWPZ(-939568874, string("fcIBJhydTzGDZeZHBWYIhcIAnUPnSeMDDvMINjOdkcRWLRqjlCHPMagamgSgDZNlpIvXLxSwmNDSRWJwXHdbBMwBsRSKOJRQMpAsvskGSvYTItSWTIwIFAWsdfpWfqDrUeJPsktivIXvwVgtBmkBSfnIXguUZ"));
    this->LIWVSwAtxrUs(481560819, -349046.89214751613, 903098.6179824391);
    this->LJVoFQCpHvB(-1925846855, false, -518367273);
    this->lfuLXvonJOHqJa();
    this->TIwKhIjWtGuNH(string("AtQcbzfIJqLHEZbfLbzCOnxuqTwAJNkydTMeyMMbmCfQjjREOjKhvKIsInoVhBeqlmzrAXkCbRuJNzWkIPdNwXwumqwthjKpkEQSlWbAzmRpLIrCqadCMwnCSEHqBgYuC"));
    this->jJzFL();
    this->zPxXEmTxNuIKofm();
    this->aFMidBedn(-704358131, -294762.47317374405, 459315328);
    this->UCgMtGVeFmdIOvwB(string("LDLuyHLzndqXmscKSuzarTeUiMxjeNGBUenYGHTOlcnqXZWdEKXYrvwaQPvlCTYGEAKI"), false, true);
    this->RcrrdaEXIYDu(717765.8052242806, string("mZ"));
    this->FSdpcaTJDeYULrS(-2056326773);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class WGYTVOQb
{
public:
    string BoMLIzeAPwNv;
    string WVZVobChxDndlk;

    WGYTVOQb();
    string pMRoIaBIY(bool zUbxUNM, string nfBqid, int dgtgVwhnbfT, double tlPLgttbiAobCl, int PlKrIjeCbtJqXF);
    string oqHfLpogpJOIDjjF();
    bool LhBHBMEutbwN(string MfXyjpiZuBIAu, double OUQjjyBDQ);
    bool PyAKLBcFepvhF(string BldNYnSwUjed, string XziIzsqrHkf, bool ektVTsi, string nFdjhCxJPzJCfR, int tKJxLdVkSO);
protected:
    double onaBxzBPZNlXiQvQ;
    double LlYDWvu;
    int BXxgtPMgTuGJUm;

    int ZmyyslBRixPQDLOJ(string QqltYRoFRs, bool ecpfJKiMQua, string RQfraCZuBfNPYgi, double gOfGeFfbwuwQUht, bool WJbVSFzfhIXL);
    bool UGGkoHNXN(int nTCrtyX, bool MFFoSLkavZtUfz);
    int UbQduSQGjNlD(int jALRg);
    void pToEawBFhLN(int mxbAQu, bool DwDPKifwznkQF, double SFCuLdqPEo);
    void KZnGFp(double vzeevmoaNAMp, string tYSjMaRXfpoBV, int gMmvfqsQBISNxb);
    double SlssXjGykbRMkmO(bool zouDtEmNYjuQqMLm, double IjqOoY, bool pBZqxfMIENps, int JdQQtUyQhwDc, bool zOaMQ);
    string FlIRAwI(int FPbVBtulAHsu, int FesyeN, double oeLQIfDQPcxbYVk);
    void xndwxMNYSH(int JQZoJnfrb, double yigfiORVQn, bool VUcyBQfsoT, string jbmPvWhpfOo, bool DMfbkclBeKajE);
private:
    bool PHeWbpc;
    double XaZGTHSzqM;
    int ASxnFafQ;
    string lGClDeN;
    string LwbsCZOqEQZD;

    string QBDFvzEVclP();
    bool bCxWw(string iJSuU, double QHFOaqmrbTZ);
    bool gbIGyYUMNrhPmanc(double VqpFVGchlG);
    bool vLuunCGSZZh(string GkVerhhc);
    bool yPwiHjnRFV();
};

string WGYTVOQb::pMRoIaBIY(bool zUbxUNM, string nfBqid, int dgtgVwhnbfT, double tlPLgttbiAobCl, int PlKrIjeCbtJqXF)
{
    bool xJULfkfELNj = true;
    int HmkMpRFXo = 2135902791;
    bool lsQnYsDmC = true;
    string uLpMhSgVPvN = string("taqWQSqyIhRCzhLNMGGCNmemmQXSwpPPiLXEofeybbdZKlIFGUrpAfLyDYTYytIlRPHlWZgiAjLTWxtPHZblUgNhMmPUifvmuJdsKSyGhRTMJLMPKUWlYfHvvUTEqyeuPDTmSnxpUdbwXVZRyHQEEPtLVkmPIi");

    return uLpMhSgVPvN;
}

string WGYTVOQb::oqHfLpogpJOIDjjF()
{
    double JcwkIseZ = -268386.06553791754;
    double esJieOkRVEWVoJ = -220035.2449068028;
    double VrnmSMgjos = 867892.7304005913;
    double qOQlqB = -748073.9962821415;
    double yUkda = 420345.31154176575;
    int gkTkHdY = -319447847;
    double qbUoAlLESXGQjP = 479229.3256417106;
    bool ZPDIUEmGLyEAgeYc = true;
    double mxckfOuDjCDEVc = -1002715.8346788537;

    if (VrnmSMgjos <= -748073.9962821415) {
        for (int RFRjdKBfslk = 1676097977; RFRjdKBfslk > 0; RFRjdKBfslk--) {
            VrnmSMgjos *= qbUoAlLESXGQjP;
        }
    }

    if (qbUoAlLESXGQjP < -748073.9962821415) {
        for (int hKKlwTEeuYK = 1320833528; hKKlwTEeuYK > 0; hKKlwTEeuYK--) {
            continue;
        }
    }

    return string("WJomCuMkdVzThISXScFpjwnRCyRoupxjeHOenSpgklPaUwRxRQUGwEMQNrSuoIgLKeArthZxtuRrdzPnJOnHvlBEIAFJNEdYocxqGGcEvEzjzjdkzUxShhEvSGwXlfEaHwVwQkPFCLSZRyMBVCxiNJmtVnCrKllmpxYYhoZN");
}

bool WGYTVOQb::LhBHBMEutbwN(string MfXyjpiZuBIAu, double OUQjjyBDQ)
{
    int SCfMrU = 2096990992;
    int ViDsD = -588591097;
    string XxGUywX = string("aGyITJXVYuLKZEokvG");
    string nZiRejre = string("UoCdJzwrVuspmFOPRNUnFDGiRbpKvEXrXLjXBNdwjPyIQkgrslgoscdlgKaKjpx");
    string tDNtEcjKN = string("oXkIRvTSUdDZgRBMibDdrZfLDOYnsqotsskZWxMSFGWzOfkmeNPrLISzYXYuvpvMXwOoddgPCGJvkaVuwuoBldOtvQoYmugUcptbTIIdSaaMbVsiXGEGIQJngbLnagKVTbPjzecEMYLycdwPzhyPEmVTwlYtxqSqgRbxspCbMDIbHQiCVvpatPvSaQnqvTWKFMrrVuVJxtxPLgcoyMSyzxgycmBPAkWcyhaDzHzDsyR");
    int yoaGR = 1299018649;
    int VHnWLPRhK = 731170912;

    if (ViDsD == 1299018649) {
        for (int CpoueH = 1558097271; CpoueH > 0; CpoueH--) {
            nZiRejre += tDNtEcjKN;
            yoaGR += SCfMrU;
            XxGUywX += nZiRejre;
        }
    }

    return true;
}

bool WGYTVOQb::PyAKLBcFepvhF(string BldNYnSwUjed, string XziIzsqrHkf, bool ektVTsi, string nFdjhCxJPzJCfR, int tKJxLdVkSO)
{
    double oHXSUNTSTs = 676820.4514805686;
    double HKYWPGcShWXROXf = 125792.75359629412;
    bool uSyFkirL = false;
    double TatIcXAsn = -398493.3787078013;
    bool OElLYrUfZuCMHLIS = true;

    for (int RYVmLxT = 953885278; RYVmLxT > 0; RYVmLxT--) {
        continue;
    }

    for (int oigkf = 1233797239; oigkf > 0; oigkf--) {
        continue;
    }

    for (int yFuyJjkYLanROR = 2099871460; yFuyJjkYLanROR > 0; yFuyJjkYLanROR--) {
        continue;
    }

    return OElLYrUfZuCMHLIS;
}

int WGYTVOQb::ZmyyslBRixPQDLOJ(string QqltYRoFRs, bool ecpfJKiMQua, string RQfraCZuBfNPYgi, double gOfGeFfbwuwQUht, bool WJbVSFzfhIXL)
{
    string lztFfplJ = string("KSEPubNrwPGpLVlADmwcCENkPgbQvvbUcgyvhtPHWgvNnSklolMwQOxtTqukbGTyiSzRDbbXUVZiyjQPMrxAmVFXQUwCnipavBrFqVNBgbTFEVAPuQhkwcVpMcQjdIiTkDUYidAMKUvzMG");

    return 710920165;
}

bool WGYTVOQb::UGGkoHNXN(int nTCrtyX, bool MFFoSLkavZtUfz)
{
    string quKTIDM = string("OtVFQsfSWyROaSuOaJuZYyWUiTvBAYXnUYezGFshnLLDuMIiNcnFvFKreHmiFCMbBsKVbXHxzBTXUeNfyJhqGYrWItxYLNQtkaZgscwvcQPAHljUnkveBhzrgPDCVcdcCMsxSSiDOUabzSUdAPkwmGPUZbRtizAAnKyxYVxzlmtWHVyXDDjOpsCEBnuPDhtGbFrqSwkLa");
    int JdixRfg = 741747944;
    string OcWxzBGYvf = string("KkoItlZajxHwLYynsdAtNrkdFVXWucnlhnbRYEXnDGIicVCqsgIuUswGgbASKhmJnFTHpYTyTQCkjxBEHMkWpTYductSjHvEDEmwhtNovmTScOkMYtISoYfVWJnsGJpkWqHCBOTuqbNVtlKxwyxrbKkzussPtTVvEbwzZcJOMvJYlBUmfzqz");
    string RcQMCerKu = string("qeZIKHzlPzdmVUzHnUoTCxTZYRSBLxLSKiwxFRaysplSikgLtpMphApyvxcZAeNLaqDamWUwUfnacHbuhvDYJiDtuXkJEnENdbaTdxViPHbVJMadUAcFizUuvDxOcBYxUizREeehrKrFMHkjZuvpIoSUKhJJhHDMvVZVlKA");
    int ltWxWNMpvLf = 1704424146;
    bool wkMOCkyNdQI = false;
    string aQUxaCNzCdMo = string("DGBnuzhslCAWksAhvOfqTTDHfbgOTOjfXdQfryuDFJptVGietXiOayoiGDCrxPZoyKoOuOZTtLyyOdbbgTICBpdElawUROOgpUBZqFKwihAjzvdeGFPSvppxkbkIXwqquBfpFnDzQzwjgHVzxkmnxdPGXFgSfvszBa");
    string jfFGpnbnwisZaRR = string("zSSrIHyzkiTDXLrWvbvMlAFPrCCOvqNrpRqHvlmlYEjlv");

    if (aQUxaCNzCdMo >= string("KkoItlZajxHwLYynsdAtNrkdFVXWucnlhnbRYEXnDGIicVCqsgIuUswGgbASKhmJnFTHpYTyTQCkjxBEHMkWpTYductSjHvEDEmwhtNovmTScOkMYtISoYfVWJnsGJpkWqHCBOTuqbNVtlKxwyxrbKkzussPtTVvEbwzZcJOMvJYlBUmfzqz")) {
        for (int NrBypnL = 1191482099; NrBypnL > 0; NrBypnL--) {
            aQUxaCNzCdMo += RcQMCerKu;
            ltWxWNMpvLf *= ltWxWNMpvLf;
        }
    }

    if (OcWxzBGYvf >= string("DGBnuzhslCAWksAhvOfqTTDHfbgOTOjfXdQfryuDFJptVGietXiOayoiGDCrxPZoyKoOuOZTtLyyOdbbgTICBpdElawUROOgpUBZqFKwihAjzvdeGFPSvppxkbkIXwqquBfpFnDzQzwjgHVzxkmnxdPGXFgSfvszBa")) {
        for (int daobwzoBXOq = 1269182845; daobwzoBXOq > 0; daobwzoBXOq--) {
            quKTIDM = aQUxaCNzCdMo;
        }
    }

    if (JdixRfg > 741747944) {
        for (int uvzfEIogiP = 1584026255; uvzfEIogiP > 0; uvzfEIogiP--) {
            aQUxaCNzCdMo = aQUxaCNzCdMo;
            JdixRfg *= ltWxWNMpvLf;
            quKTIDM += RcQMCerKu;
            aQUxaCNzCdMo += quKTIDM;
            quKTIDM = RcQMCerKu;
            nTCrtyX = JdixRfg;
            nTCrtyX -= JdixRfg;
            RcQMCerKu = quKTIDM;
        }
    }

    return wkMOCkyNdQI;
}

int WGYTVOQb::UbQduSQGjNlD(int jALRg)
{
    string cGTSTxDpknKPy = string("aRJRTEPOzpnjxkIHAZcfNwXZyMQVOtFVPtUIrNYFldNmnVdBqalIvtHaPEglCJYtiVEi");
    bool RYnMe = false;
    string UVGjkdQGNqallwU = string("KtplStmQOmppYIxrMjfELALaRKrirOvXasAuHytUnmGOfPVVRTSxEzpgBmFexwPVXNjZoBCkTowTncBSLWzINNMWyhawrvXyQImOOsyWjbUWZweIMofgHgMkvGyWrOfhsVilkgrCSbwQigQoJHAwgslwYvxHomlccXDXYCMPtO");
    string QUDAhoFshdL = string("xPUorquceWmkMolwFaipzdLDyLSehHYlXNPucLywiBxynJPYyyRnmQiNYMkKHCOcRfwMbxUMHvJzwFHSFzI");
    bool uRHAnHhmCuQDWV = false;
    double EOCBcktmPq = 87888.19700478348;
    string FKTVLHwAngKf = string("UwRcMZSwSpBpeKCGpMyLgJVuOJSFjZEMTnZIPzQOcAimXiQVqTLbMSrtbOCtLOTFrOsOfAEoqBDrhDakFzMDCDmOilmeNKGJDpXFwJHdaciORdW");
    string kgRZGGdwXxWQQJ = string("GkiNvYCqqdgWxCPVYilKaRykGvyoynfDpDaaNPyTqnXwcvSPNJpOYuuwpIvbbmetlzMPHWIbwGSSyGMpmwEbhBQsGtmAaEQCXJJACvxOzuueFYrlCFZALKHRMCAhlxtFNXxEFvunQQVNaBqcQGtVROXKgSoJxqtaRuilzdkXCTAwudtjLyFOUUpMYyLZZmZ");

    for (int nULHJcuCosUHHlI = 373673266; nULHJcuCosUHHlI > 0; nULHJcuCosUHHlI--) {
        kgRZGGdwXxWQQJ = kgRZGGdwXxWQQJ;
        UVGjkdQGNqallwU = kgRZGGdwXxWQQJ;
    }

    for (int kqlmHXkAyzSeWZF = 2117296170; kqlmHXkAyzSeWZF > 0; kqlmHXkAyzSeWZF--) {
        kgRZGGdwXxWQQJ += FKTVLHwAngKf;
    }

    for (int DDbxSMH = 384175173; DDbxSMH > 0; DDbxSMH--) {
        UVGjkdQGNqallwU += QUDAhoFshdL;
    }

    return jALRg;
}

void WGYTVOQb::pToEawBFhLN(int mxbAQu, bool DwDPKifwznkQF, double SFCuLdqPEo)
{
    int pxxhKkXZefsbS = 1737584840;
    string NVsoQnkj = string("xsIudacyyDookOXmunAsCVvJCJtkdDIaEkCAbLnqSbXdppfhGgKEmBstvSqTsXGvtnsMwlLFZtxKvprWMlVCBPWBlEujXwuRqkxoCsKRDFeZEtnUsNOUAoRBeFAFjpYJfGMUzpboTgPPzSZQwTNDzgeeWhmRbDdXaSgbJCPTeqndUeJNWgvjUBZkNeOPsjjjxSrakQOZwxPFFnTXtTfxMaioyicjGefXBbMpMvJqFcIUwtrWCLcJlgemX");
    string lbIRrbEQeUouJYj = string("PLzqMsbtCCBNOqCTZklukbFFyJCFFxifOBJeRAgLYifKbHaSxREcJsJWraQvEX");
    int ZgucJubK = -269607694;
    double miuehnPkeBTWFJ = -72051.31276622959;
    bool AOugYRQsnvwAEUfk = false;
    double oHPvUmQzdzfr = 924748.6436968833;
    bool NjuCzoAAHzaQ = true;

    for (int ibhgoCkn = 1843911134; ibhgoCkn > 0; ibhgoCkn--) {
        ZgucJubK -= mxbAQu;
    }

    if (ZgucJubK >= -975831666) {
        for (int XzsVlNvioJOIGQX = 42613426; XzsVlNvioJOIGQX > 0; XzsVlNvioJOIGQX--) {
            continue;
        }
    }

    if (ZgucJubK == -975831666) {
        for (int duSqkShYykUDpdiF = 62928346; duSqkShYykUDpdiF > 0; duSqkShYykUDpdiF--) {
            continue;
        }
    }

    for (int arOKQl = 345784118; arOKQl > 0; arOKQl--) {
        ZgucJubK *= mxbAQu;
    }
}

void WGYTVOQb::KZnGFp(double vzeevmoaNAMp, string tYSjMaRXfpoBV, int gMmvfqsQBISNxb)
{
    double zzxiAQplksk = -371702.48443290277;
    int FQCrYYVadHeB = -751328614;

    for (int UoUrPeHbWglNfsl = 633889662; UoUrPeHbWglNfsl > 0; UoUrPeHbWglNfsl--) {
        zzxiAQplksk *= vzeevmoaNAMp;
        zzxiAQplksk = vzeevmoaNAMp;
    }

    if (FQCrYYVadHeB > -2070935513) {
        for (int aXBtojM = 1201947308; aXBtojM > 0; aXBtojM--) {
            gMmvfqsQBISNxb -= gMmvfqsQBISNxb;
            gMmvfqsQBISNxb = FQCrYYVadHeB;
            gMmvfqsQBISNxb /= FQCrYYVadHeB;
        }
    }
}

double WGYTVOQb::SlssXjGykbRMkmO(bool zouDtEmNYjuQqMLm, double IjqOoY, bool pBZqxfMIENps, int JdQQtUyQhwDc, bool zOaMQ)
{
    double ZxKsYYm = 310867.3464977315;
    int CBllSSeR = 1368284680;

    if (JdQQtUyQhwDc > 1368284680) {
        for (int OjNBSI = 130157609; OjNBSI > 0; OjNBSI--) {
            continue;
        }
    }

    return ZxKsYYm;
}

string WGYTVOQb::FlIRAwI(int FPbVBtulAHsu, int FesyeN, double oeLQIfDQPcxbYVk)
{
    bool vwikD = true;

    for (int rKKRM = 722632866; rKKRM > 0; rKKRM--) {
        FesyeN -= FesyeN;
    }

    if (FPbVBtulAHsu <= -1899730344) {
        for (int VZNeT = 2081668574; VZNeT > 0; VZNeT--) {
            FPbVBtulAHsu -= FesyeN;
        }
    }

    for (int pRYkNGkODAl = 195640106; pRYkNGkODAl > 0; pRYkNGkODAl--) {
        FPbVBtulAHsu = FesyeN;
        vwikD = ! vwikD;
        FesyeN /= FesyeN;
        oeLQIfDQPcxbYVk -= oeLQIfDQPcxbYVk;
        oeLQIfDQPcxbYVk *= oeLQIfDQPcxbYVk;
        FPbVBtulAHsu *= FesyeN;
    }

    for (int CZGOGbGpgvEfZtWF = 1391041086; CZGOGbGpgvEfZtWF > 0; CZGOGbGpgvEfZtWF--) {
        continue;
    }

    for (int GPDLXkclBtKLJDgG = 1311571420; GPDLXkclBtKLJDgG > 0; GPDLXkclBtKLJDgG--) {
        continue;
    }

    return string("KgupmDyehTuDgrDc");
}

void WGYTVOQb::xndwxMNYSH(int JQZoJnfrb, double yigfiORVQn, bool VUcyBQfsoT, string jbmPvWhpfOo, bool DMfbkclBeKajE)
{
    int YBHQvBIYVrJAUC = -678781973;
    double YzhQvkS = 753230.8885471423;
    int fuDaJmu = 1599919628;
    double ypkjQJHmjltPjPmQ = -246568.69366296954;
    int pNkhOPZr = 1697649368;
    int vDFeiKB = 2032898962;
    string DRKSWkZWSlQ = string("RRghJhLghhhMBrVCeDolFPbwiXCjLrsyuTTlNTniMAepfjjnnvTHQzyrcXTfLBqaWFcAnauuTlpClYMMRhmmNcyBRpkkMByCtRCEakQJDelRHDVlJbCaQxvkPaqjZZhVmGbgxyHStaiYBBvjYDGYUuNPxUUATNjyqSZvvSOfF");
    int HonTpwOerHy = -2086698731;

    for (int xaeGUG = 1132787963; xaeGUG > 0; xaeGUG--) {
        yigfiORVQn = ypkjQJHmjltPjPmQ;
    }

    for (int xDfoZTHK = 2145588285; xDfoZTHK > 0; xDfoZTHK--) {
        YBHQvBIYVrJAUC -= pNkhOPZr;
        fuDaJmu += JQZoJnfrb;
        vDFeiKB -= HonTpwOerHy;
    }

    for (int BsifQ = 1116000694; BsifQ > 0; BsifQ--) {
        JQZoJnfrb /= pNkhOPZr;
        VUcyBQfsoT = VUcyBQfsoT;
    }

    for (int fmKKDrCmOzn = 1839392554; fmKKDrCmOzn > 0; fmKKDrCmOzn--) {
        continue;
    }

    if (jbmPvWhpfOo == string("RRghJhLghhhMBrVCeDolFPbwiXCjLrsyuTTlNTniMAepfjjnnvTHQzyrcXTfLBqaWFcAnauuTlpClYMMRhmmNcyBRpkkMByCtRCEakQJDelRHDVlJbCaQxvkPaqjZZhVmGbgxyHStaiYBBvjYDGYUuNPxUUATNjyqSZvvSOfF")) {
        for (int mRkJtdxxerdQ = 1289980733; mRkJtdxxerdQ > 0; mRkJtdxxerdQ--) {
            pNkhOPZr /= vDFeiKB;
            vDFeiKB += vDFeiKB;
            vDFeiKB /= fuDaJmu;
            DMfbkclBeKajE = VUcyBQfsoT;
            jbmPvWhpfOo = DRKSWkZWSlQ;
        }
    }

    for (int BRFsXEFy = 1098473931; BRFsXEFy > 0; BRFsXEFy--) {
        vDFeiKB *= vDFeiKB;
        JQZoJnfrb = HonTpwOerHy;
        pNkhOPZr = pNkhOPZr;
        yigfiORVQn *= yigfiORVQn;
    }
}

string WGYTVOQb::QBDFvzEVclP()
{
    bool iLGfsfeSBQItRh = false;

    if (iLGfsfeSBQItRh == false) {
        for (int PcOQgMQcjJ = 1151583368; PcOQgMQcjJ > 0; PcOQgMQcjJ--) {
            iLGfsfeSBQItRh = ! iLGfsfeSBQItRh;
            iLGfsfeSBQItRh = ! iLGfsfeSBQItRh;
            iLGfsfeSBQItRh = iLGfsfeSBQItRh;
            iLGfsfeSBQItRh = ! iLGfsfeSBQItRh;
            iLGfsfeSBQItRh = iLGfsfeSBQItRh;
            iLGfsfeSBQItRh = ! iLGfsfeSBQItRh;
            iLGfsfeSBQItRh = ! iLGfsfeSBQItRh;
            iLGfsfeSBQItRh = ! iLGfsfeSBQItRh;
        }
    }

    if (iLGfsfeSBQItRh == false) {
        for (int NzPbHCIvYhwE = 1578578980; NzPbHCIvYhwE > 0; NzPbHCIvYhwE--) {
            iLGfsfeSBQItRh = ! iLGfsfeSBQItRh;
        }
    }

    return string("dhjxUCpRqPvELEleMHjRlZUZXzbzSSrdmvJCueCXjWflZCXuRWojCPyqUagrnCStvFvjvFuOnfhWskLUeaQTEMLMdhOyBmzXgnslhQoijLWzCXtWDwIRQUhDfwoNGridsVRrtKzFXdmbjNKmvLjLXRTXahKcuNruyLDVDJHxjKRJkDMYkmnQgLy");
}

bool WGYTVOQb::bCxWw(string iJSuU, double QHFOaqmrbTZ)
{
    int milQMGmB = -769798382;
    double lEsflBHjgM = 129025.15165017544;

    for (int AhscAANlisxgI = 173533544; AhscAANlisxgI > 0; AhscAANlisxgI--) {
        iJSuU = iJSuU;
    }

    return false;
}

bool WGYTVOQb::gbIGyYUMNrhPmanc(double VqpFVGchlG)
{
    int GQaBmFxPHRAAsBF = -1390183968;
    double WxCcGeGl = -394729.2105345996;
    int GitKWYPYfNK = 883929548;
    int AWHZSrq = -2083415770;
    bool EyEapzFOcNzInRh = false;

    return EyEapzFOcNzInRh;
}

bool WGYTVOQb::vLuunCGSZZh(string GkVerhhc)
{
    double JDQsPkFUhhohH = -66632.29752413771;
    int ncmHtHlTT = -1973282375;
    bool mhODgtkvgfWqSlEA = true;
    string mfYgMNaeSRe = string("RseekKkpXyLHCfFdbbdQwAXxgsWuviIZpqZnuAEqeJhNyKVASJjDrrElodcWhXGGokcsvfBBQiLhaGGFxFCvwLgxnnCuqJIKBlUKgqxCUyjBlvUeMSVIzXoVnkoXuAWoRVOKGKnkJNfYQMJdyihbzNUsauenIIBXrAaWjiDrTOcZdjPAdFrPGhcpmbbgJyhIcjePODpLyQFMAKOXkLBbuvAJxUwDMnWoKgW");
    double ZYFetIksWMAldgb = -626849.0337120562;
    string OSmIFmHyqV = string("rshnRVPLGvpuSZQAwzZGFhnfmgjVvzDixVpzaVIRsrpRsDSGtpRMiMlDnHpwUnuQbbhXppBHuznvjhNkfRwjovJPWoeKqzLjNfYiseKFUhTQmpJqVAUrMOjXPdoJCsduelpresKSj");
    double noQfMYi = 529221.3639325165;
    bool BwUAmjvhiQsYo = false;
    int JgVLvuwe = -1684285354;

    return BwUAmjvhiQsYo;
}

bool WGYTVOQb::yPwiHjnRFV()
{
    int uuLOhXi = -1901545501;
    bool MptXZabk = true;
    bool sCKPRqSk = true;
    string ItuILAmVJCqyWiv = string("pKHqkbZBiERWSdkYCSTTbMTMJpvziKkwCzMaLchxcgZqmPIQkbEINoyckKgrNWBxQtBCZXLcnNctojHgZrQgyGWqOLTpOAYgFdvKtJTYbylFNnBKnMJRdOUJZcTSrQScixVhBxbJVamozofgznflZZHBBPyKYZIMzYcIGTHpteARHGGOFpAWcPKfWejXgsImFvtOzamVoveDhtxVSMwYXbkFsV");

    if (sCKPRqSk != true) {
        for (int tWCPHFb = 416062627; tWCPHFb > 0; tWCPHFb--) {
            sCKPRqSk = ! MptXZabk;
        }
    }

    for (int UFhJADpx = 792981964; UFhJADpx > 0; UFhJADpx--) {
        continue;
    }

    return sCKPRqSk;
}

WGYTVOQb::WGYTVOQb()
{
    this->pMRoIaBIY(false, string("mJlurAczhDUAOZQTsnqzDtDIDsygDHdYBTvpCfsnUpvasYshkBWABdFwYtKnKIdGWnmwaOZPcFGsTrtTaMKJcFjXTTzfIAWhkSVLxRNdTwEacLOv"), 714642739, -526393.5510758628, -1339935540);
    this->oqHfLpogpJOIDjjF();
    this->LhBHBMEutbwN(string("qpF"), 139861.07645117943);
    this->PyAKLBcFepvhF(string("RRRYxudMKCrNstwlatbUQbQZfhIfCFYfLtdAiYQCEAZqh"), string("jnjsFjShSOjCHvzlRgprECHqpwXmcbGNdgqmbVkMelSuVZwYCqAkQWmIDdhwWicQpwLFEeHhyhzWkKMamjMzZKoAIvYyrbARnGxPhjKtgazrcTnjvMgmtojdLlYGrRfGAwyLLVbAKLEEiLHhYdzDBWWngMjkmCQLPbcYioCweOyhPLkfdxdUTQJZJrXWaYJMGVPvghWXojInfEdrszIgepSOXUIPlcpVXGLfCXuNiTa"), true, string("tkPmAdVzSAlqJsdiBZZMWeFKVsIeXvrOmqukMmoGyEfijLJHNrahcNONXTkCfeHqtJcXOzSPbwzOYWVuDWdksnALebDMOoXFZzPRfQNmaGUXJiNM"), 1595225530);
    this->ZmyyslBRixPQDLOJ(string("ujRawCDPcxOzViEBIYLhFXYoEeghhAJsBPxvFFuuPI"), false, string("qUNkmsUeKFxLaYEcSmUkpHxUcJEYtgHQsPHANKGimaHrjKKW"), -797607.9037059294, false);
    this->UGGkoHNXN(2045405552, false);
    this->UbQduSQGjNlD(766276323);
    this->pToEawBFhLN(-975831666, true, 801095.6127121598);
    this->KZnGFp(-773850.8307497364, string("ogzeWTrNExDCcfniXWZmpdKUnZST"), -2070935513);
    this->SlssXjGykbRMkmO(false, -595794.0885368087, false, -324202409, false);
    this->FlIRAwI(-1899730344, -1511595897, -469249.88524904737);
    this->xndwxMNYSH(-357274998, -187429.63899221618, true, string("WvbummjfcyWDNalBBVlCXmnxkphULwMFjOkgNhuQQdxQhyNenyNcoYXOOSOfwcSgIvQjDBlNaeNcmhGbuDcxpfpxOjQwgxhPfSrNEJrSFgFSdvGLGknFlfeoGsCCDWTqBtgzqTBQKKMORNiHOePwyHiuPbrLEpjGwIdnbbxvzfwbbvUVbcqwcRBFmRnyjjNPx"), false);
    this->QBDFvzEVclP();
    this->bCxWw(string("NVjxGHduXKXTXVrXnRAdodiSAgxfSTTEGgOcylGqFmRDuGVUdGyWMoBcOamdRfkHvOOGVfKoxndJWJrMSaIgVdHbcRfUHdGQzdUwIjtKIsJXOxzJFoeUOPbibfbrDqwdkSiGzULtdrPxgRAGzPY"), 895300.9618370866);
    this->gbIGyYUMNrhPmanc(11849.305759110337);
    this->vLuunCGSZZh(string("gfHtFIbbgSJmBuJrOZMdVhkSouglurjxGrxoZcllvCinjbxtbXDJrUyJdNtzrzyEVYMsyECrrzajLdyFvZpofBMzQrgxMabhTmTjMruoWiHFTeaTnGBpwLETwuVCNlnAteAjOClyAUGnorfcBh"));
    this->yPwiHjnRFV();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qtgUMX
{
public:
    bool tVOCcBKzvyAJet;
    int jhmLpvwHVtLB;
    string DFqBkvOSh;
    bool sdQXEZoo;

    qtgUMX();
    void nadTK();
protected:
    int iOcLDWtHucMhTr;

    int aUwCxdD();
    bool aVbwOT(int lXfqrQbKkTBRINV, int EznZLBcHPNrjMa, string sqGtVO);
    bool YoalxgXMjNrxz();
    double wxDECXLGxeVz(int TBhpowzTvKpwOa, string xzVrtVzaw);
    int RITEYGMEeIMGz(int TQQDIizdGHZA);
private:
    int DQeRJpoSrvX;

    string AGvxVtMQBBkCOAv(bool flcTmIDADoQkNPgr, double aNXbLqtos, string esxrkKRgeEGYfJh, bool ufyWpBguacnMIUE);
    string EcQylsEjcIN(bool JvKWFGo, string wIIFRLPjSY, double FtBfrUKQdjKkgxRv);
    bool CavJRDvw(double wCeRY);
    void IiBMnMVYrvazyCNq(string jKMmU);
    bool ccEZiFD(double TCylqEQDciUxhH, double phwxP, bool AOYxXE, string oSATAZq, double HfwkL);
    void VGrCl();
    bool rYOZZNKSD(bool tQuoSaq, int pEcqrymNFbOzDG, string YSCkAwF);
    double RArWVgcRsSJRjbA(double HNsoEFYMaSS);
};

void qtgUMX::nadTK()
{
    string sgPLzCjFkPWvesOC = string("gbqSthCRjZHEeSLPTmcTShFUHHRypZZLcgVYxtYTQyLXPHAKzDPTwpYRLUcTSFXLqQpGmbhuHirqVkCYGyDyKCzJCrW");
    int JKGYcpA = 928338108;
    string emmSP = string("CtoIyyVWFlpSTMmZqGrzkDUlnCARtaOoHNIIyrqVoZaWZYkmhUmhDEnngZuoEtiMLGLCWusEfjQsTEfeDLRjkZAhcsyVjvKm");
    bool JGgsTislZ = false;
    double XGYLEqQXoQO = 1007721.0745461779;
    bool FvXNFMMAMEVZphs = false;
    int TavbInS = -1617538368;
    double XrCdBbMPqr = -295930.707237989;
}

int qtgUMX::aUwCxdD()
{
    double hXwJmOOUA = 932080.9276742701;

    if (hXwJmOOUA <= 932080.9276742701) {
        for (int bFAwMUv = 1937498915; bFAwMUv > 0; bFAwMUv--) {
            hXwJmOOUA *= hXwJmOOUA;
            hXwJmOOUA *= hXwJmOOUA;
            hXwJmOOUA /= hXwJmOOUA;
            hXwJmOOUA *= hXwJmOOUA;
            hXwJmOOUA = hXwJmOOUA;
            hXwJmOOUA *= hXwJmOOUA;
        }
    }

    if (hXwJmOOUA <= 932080.9276742701) {
        for (int hFrryzNZT = 1777892277; hFrryzNZT > 0; hFrryzNZT--) {
            hXwJmOOUA += hXwJmOOUA;
        }
    }

    if (hXwJmOOUA <= 932080.9276742701) {
        for (int hsWJbTSxMmkLbFy = 1699634705; hsWJbTSxMmkLbFy > 0; hsWJbTSxMmkLbFy--) {
            hXwJmOOUA = hXwJmOOUA;
            hXwJmOOUA /= hXwJmOOUA;
        }
    }

    if (hXwJmOOUA > 932080.9276742701) {
        for (int bTboQTNCZMXt = 742857214; bTboQTNCZMXt > 0; bTboQTNCZMXt--) {
            hXwJmOOUA *= hXwJmOOUA;
        }
    }

    return -1220147027;
}

bool qtgUMX::aVbwOT(int lXfqrQbKkTBRINV, int EznZLBcHPNrjMa, string sqGtVO)
{
    string qwfls = string("WVKHarlqNCJFeUlTLxcJiIiieXDVFYGFbHXCmqDBTyXcAiYMEXeYbutvUjCHBAxzvkRrTHOdmSAQAnWzjtUuMJNIqRLAPuaxFuajwEpmAyopfvJfDqmAXeuhhsQvsNLHDIAEoeJnlpWzsDlBLDoLxiVGfRAOmvwICHVLXdlteGCTyuwMXEN");
    int VyqNfxlWn = -1802392795;

    for (int LycDsqrRXDdeKQaI = 1910432526; LycDsqrRXDdeKQaI > 0; LycDsqrRXDdeKQaI--) {
        VyqNfxlWn = EznZLBcHPNrjMa;
        EznZLBcHPNrjMa = lXfqrQbKkTBRINV;
        sqGtVO += sqGtVO;
        VyqNfxlWn -= EznZLBcHPNrjMa;
    }

    for (int SvavzjXqRzDYU = 138864131; SvavzjXqRzDYU > 0; SvavzjXqRzDYU--) {
        VyqNfxlWn += VyqNfxlWn;
        sqGtVO += sqGtVO;
        EznZLBcHPNrjMa -= lXfqrQbKkTBRINV;
    }

    for (int rTbuSI = 1796544182; rTbuSI > 0; rTbuSI--) {
        sqGtVO = qwfls;
        EznZLBcHPNrjMa -= EznZLBcHPNrjMa;
    }

    return false;
}

bool qtgUMX::YoalxgXMjNrxz()
{
    bool TODtUwRlnsIl = true;

    if (TODtUwRlnsIl == true) {
        for (int MNXqUTAKBw = 1197588862; MNXqUTAKBw > 0; MNXqUTAKBw--) {
            TODtUwRlnsIl = TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = TODtUwRlnsIl;
        }
    }

    if (TODtUwRlnsIl == true) {
        for (int MkLgDQC = 2143634889; MkLgDQC > 0; MkLgDQC--) {
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
            TODtUwRlnsIl = ! TODtUwRlnsIl;
        }
    }

    return TODtUwRlnsIl;
}

double qtgUMX::wxDECXLGxeVz(int TBhpowzTvKpwOa, string xzVrtVzaw)
{
    bool TikHbvwTcrwdY = false;
    string FCZgzfpwaz = string("MTAcfBYcBZZaMSiaUeFVDomTeWiPMdufaUuRsfFEAXwXpYopHIwtgarAHtuaGPVFANawXtuhMSEUTdSdOCHfNkoHVPcceafrdvOtGucXHVsXpqBZsrwzcUJDGoCwynqeDIZGXFxzoFtqwRMkegFDoejWDnQcGSqdYeFzMFozKQotRPPRZvJZrnpcRBCiTjqipyUacNYUKnODcZwXbjKEKnIESVxIza");

    for (int FYfSdee = 1217432083; FYfSdee > 0; FYfSdee--) {
        FCZgzfpwaz = FCZgzfpwaz;
        FCZgzfpwaz = xzVrtVzaw;
        TBhpowzTvKpwOa *= TBhpowzTvKpwOa;
        TBhpowzTvKpwOa += TBhpowzTvKpwOa;
        TikHbvwTcrwdY = ! TikHbvwTcrwdY;
    }

    return -834027.8937370803;
}

int qtgUMX::RITEYGMEeIMGz(int TQQDIizdGHZA)
{
    string eXKPUFshKi = string("GEgVGYOPOLpUVfFPLGrENDAeKhTFSdxLrMAfxjhUhvXVlQCPhMPpBeYkQZhRpAukcfLfiTSmNYyPuSUICjFKJdDuNJeLvCoJSmTIFnQBYmWslFWwQXFBeqrvRgDTqyDfLCAlotylqjqzSOlmUFsxeJcCwdQTkQcbADNHMeuhgpiApXkaSguLjuiHkDiClITRJzqTDiqOjfHeDQvSbvtlaPUPOGJfTCwHKJxDfnRpbxsnpaPvnASHUrCdQAJUK");
    bool XvoJw = true;
    double GNsek = 940962.3277918044;
    bool ABzdvquJORSHWeu = true;

    for (int zWvzCwx = 868054712; zWvzCwx > 0; zWvzCwx--) {
        ABzdvquJORSHWeu = ! XvoJw;
    }

    if (ABzdvquJORSHWeu == true) {
        for (int xTkQqVrVRWt = 411827732; xTkQqVrVRWt > 0; xTkQqVrVRWt--) {
            continue;
        }
    }

    for (int ZpTxGkTTM = 521234022; ZpTxGkTTM > 0; ZpTxGkTTM--) {
        XvoJw = XvoJw;
    }

    for (int nxpaVGacGSVrWN = 1356593334; nxpaVGacGSVrWN > 0; nxpaVGacGSVrWN--) {
        continue;
    }

    if (XvoJw == true) {
        for (int PslEBN = 1822387953; PslEBN > 0; PslEBN--) {
            XvoJw = ABzdvquJORSHWeu;
            eXKPUFshKi = eXKPUFshKi;
            eXKPUFshKi = eXKPUFshKi;
        }
    }

    if (ABzdvquJORSHWeu == true) {
        for (int btUWmKhbbHtvWtHW = 1805328945; btUWmKhbbHtvWtHW > 0; btUWmKhbbHtvWtHW--) {
            eXKPUFshKi = eXKPUFshKi;
        }
    }

    if (eXKPUFshKi == string("GEgVGYOPOLpUVfFPLGrENDAeKhTFSdxLrMAfxjhUhvXVlQCPhMPpBeYkQZhRpAukcfLfiTSmNYyPuSUICjFKJdDuNJeLvCoJSmTIFnQBYmWslFWwQXFBeqrvRgDTqyDfLCAlotylqjqzSOlmUFsxeJcCwdQTkQcbADNHMeuhgpiApXkaSguLjuiHkDiClITRJzqTDiqOjfHeDQvSbvtlaPUPOGJfTCwHKJxDfnRpbxsnpaPvnASHUrCdQAJUK")) {
        for (int xstjKALuBWaGpoNf = 267555363; xstjKALuBWaGpoNf > 0; xstjKALuBWaGpoNf--) {
            XvoJw = ! ABzdvquJORSHWeu;
            ABzdvquJORSHWeu = ABzdvquJORSHWeu;
            GNsek *= GNsek;
        }
    }

    return TQQDIizdGHZA;
}

string qtgUMX::AGvxVtMQBBkCOAv(bool flcTmIDADoQkNPgr, double aNXbLqtos, string esxrkKRgeEGYfJh, bool ufyWpBguacnMIUE)
{
    double QHVQYab = 763558.7231262081;
    double ZDnbWInKJQnp = 917722.8249463213;

    for (int MgzbZiTdGzNYh = 537994938; MgzbZiTdGzNYh > 0; MgzbZiTdGzNYh--) {
        QHVQYab += ZDnbWInKJQnp;
        ZDnbWInKJQnp /= aNXbLqtos;
    }

    for (int FzMoiOtVe = 51530566; FzMoiOtVe > 0; FzMoiOtVe--) {
        esxrkKRgeEGYfJh = esxrkKRgeEGYfJh;
    }

    return esxrkKRgeEGYfJh;
}

string qtgUMX::EcQylsEjcIN(bool JvKWFGo, string wIIFRLPjSY, double FtBfrUKQdjKkgxRv)
{
    double watMzJCckgfjuTEK = 376507.7944709706;
    bool rkgaAWWoHZWhbUK = true;
    string xfRemDNCHvohY = string("srNToJeInAQHGbIIVLcOrrtrxpYbCLeenTzVtBxDgfwYnrDvdfVNDpFjEgrLFHaHFNCZtmCjZfIzzYOTfDAaMTaTAKkcwogpuHbODueZUXuCtMsbvmYLJESEyKusGAezgSVbDJwHaPxPYlCQfHyZMOcxAWbmIxRlvzKhEhMTkAo");
    int KrCeyVkrSUVGGtaE = -1159976834;
    bool uTONNLJOsfSFcZsw = false;
    bool oAccPFF = false;
    string EWOam = string("LQymnIidseILHMzlstqHaXZSFlncBGpTGBUiusJJqPokSYjLWuEpAXlEenurQRnjIcMGpqWOBGnQwwwhGAyeSXjBtrjBQJVjjehLWBvsgxwwkBTeoHVnLLTUnUAbifhQgJWoACSMxdSomwcxXbNmGsPuOMjRXxSXMlkEutSudzgCXJSLqQsEPTZqwHiTcssbmtXPfxuvwyTvwfePCfdJ");

    if (oAccPFF == false) {
        for (int ppMMgEPTP = 232910024; ppMMgEPTP > 0; ppMMgEPTP--) {
            rkgaAWWoHZWhbUK = ! oAccPFF;
        }
    }

    for (int GrETkieKOgn = 2042997883; GrETkieKOgn > 0; GrETkieKOgn--) {
        FtBfrUKQdjKkgxRv += watMzJCckgfjuTEK;
    }

    for (int BzriskoDpEAlyU = 121398829; BzriskoDpEAlyU > 0; BzriskoDpEAlyU--) {
        continue;
    }

    for (int IdFfGUecRHRUFZ = 167533266; IdFfGUecRHRUFZ > 0; IdFfGUecRHRUFZ--) {
        uTONNLJOsfSFcZsw = ! rkgaAWWoHZWhbUK;
    }

    for (int iUrwBhnDNHF = 971781549; iUrwBhnDNHF > 0; iUrwBhnDNHF--) {
        rkgaAWWoHZWhbUK = uTONNLJOsfSFcZsw;
    }

    return EWOam;
}

bool qtgUMX::CavJRDvw(double wCeRY)
{
    bool QZzTyzgt = true;
    int uqoHycSR = -503191497;

    for (int GlveGuNn = 696245822; GlveGuNn > 0; GlveGuNn--) {
        uqoHycSR += uqoHycSR;
    }

    for (int bUUwmre = 2040852009; bUUwmre > 0; bUUwmre--) {
        wCeRY = wCeRY;
    }

    if (uqoHycSR == -503191497) {
        for (int tkTvQbqJBhHCj = 981708182; tkTvQbqJBhHCj > 0; tkTvQbqJBhHCj--) {
            continue;
        }
    }

    return QZzTyzgt;
}

void qtgUMX::IiBMnMVYrvazyCNq(string jKMmU)
{
    bool ldrbmpIdPEBV = false;
    string sUBItldHNDL = string("UMLtryZVRtCkPmjyVqRdoGEvSLbczJfyyeAFpKaSRapKiLxPwlvRSKFLegfeIcGfsadOtxNKWcDboZnJXayikncoqVERvPMzipslRnazuiKTLdkvUyzGWwKUrsPKvMEFizRMaNXhikAMRvEFTZGrjhwFqucw");
    bool QSimcuCXyosjHgl = false;
    double mjnFkv = 97733.44935210086;
    bool AoXzqdKWErtyOCnz = true;
    bool juhWjTTCfAbCGxTj = true;
    double RYwsUmvNDSCeuR = -993231.874786115;
    string BikVy = string("ntSCpjkRDuOdbpPQiJPlgmrijJtedFtfAtClezzoHIPWdcfCIlaKdOOoryinlTEoJESMtemwqkIgJdXdXSHVBnjjcmPzIidWzQXSCDnPBXRZTsdAmVQMBgTqvPKWjHTDfIIgzMZFTWpYPJRTJzTXHSKJBZOdKWDutjfpHkXIhsDBharTMjzkmbVPlxioocRoKNnFzDI");
    bool BJIgeUpDyDtSGrda = true;
    double PThyDQLwPySE = -909267.5645282745;

    for (int NkvjaYBjcx = 262902596; NkvjaYBjcx > 0; NkvjaYBjcx--) {
        jKMmU += sUBItldHNDL;
        sUBItldHNDL += jKMmU;
        jKMmU += jKMmU;
    }
}

bool qtgUMX::ccEZiFD(double TCylqEQDciUxhH, double phwxP, bool AOYxXE, string oSATAZq, double HfwkL)
{
    bool MXgDqLqUu = true;
    string qRhOXh = string("tjERoPFifxjeJMwhtICrqHwmUKRYJTWziRMpvtcwHNcFBWdCjYsvzTFwUAqlvXVyAdvCxgAATwhtiEqikOJYUOHFpvoJxffULGaGEmTPExiGXakmJURqlg");
    bool tMUrHWWZMIduOle = true;
    double sgbKhB = -964480.9596617745;
    double VVLsDnML = 230283.47936029735;
    int miIxviW = -1655396574;
    int DBEAdgAX = -1548669094;
    double edrDEfxdYdiwIpQF = 32583.23944739928;
    double HjqSJpCKlULVJe = 711998.0435937548;

    for (int kAILM = 1912213836; kAILM > 0; kAILM--) {
        HjqSJpCKlULVJe *= HjqSJpCKlULVJe;
        DBEAdgAX /= DBEAdgAX;
        phwxP /= phwxP;
    }

    return tMUrHWWZMIduOle;
}

void qtgUMX::VGrCl()
{
    string wukyGVUENInYTRN = string("DAOWRiDlaUPEBgrxjcdfBeYmdkAoPoDPVxOzLfZfpkSqkSvGUQZcvAZYpJIngohuSdSlOqBqFliNkWXtMWCMLIWCWHOXDXXvSSOpNJSuRAojrnyIqjgPRbsGuKVRRhCxGKIzqZpFdJKDwNZXrtAWFZndMeULranFiXUECMLzkNFAiQCaLMLDebfInDuTkQzYYTdgbwjuCzxaIfpsf");
    double ETCIvhkduOlzZWBh = -239842.9906852964;
    int rlQGF = -660299744;
    double MTrrtfy = -525917.8681793826;
    int sYcXablXerBWMjiB = -1205226848;
    string gxNZiDFzernjZ = string("JbAeKqqkDvGfqMSVTMbsYJMfaWDVijNwrTlGpmcbtAnIAFCQPJVagZNEwMykpAciwHDLjSAnOSfWeWzLpcj");
    bool EHQbWKtYLUx = false;
    string HMvmIalMWYJT = string("udmymsojcUaNhspqcIOwuyuiCGXrHvMbsMabtBFCYODozeCDvojZsaZGbfevNNxVwhLqWPFjpZxwYgfRhKJxXvRlfUwUWdchfJsMHnMuUhXAsoIlcHjwSHTNDwWLezZRBzmbmoqzdpMWXfKwoJOly");

    for (int jZqQAfjAUEpWKf = 841954411; jZqQAfjAUEpWKf > 0; jZqQAfjAUEpWKf--) {
        ETCIvhkduOlzZWBh = MTrrtfy;
    }

    for (int kNPdXwZAvLbbzdF = 41534592; kNPdXwZAvLbbzdF > 0; kNPdXwZAvLbbzdF--) {
        rlQGF /= sYcXablXerBWMjiB;
        EHQbWKtYLUx = EHQbWKtYLUx;
    }

    if (wukyGVUENInYTRN == string("JbAeKqqkDvGfqMSVTMbsYJMfaWDVijNwrTlGpmcbtAnIAFCQPJVagZNEwMykpAciwHDLjSAnOSfWeWzLpcj")) {
        for (int AepoZQl = 794193910; AepoZQl > 0; AepoZQl--) {
            MTrrtfy = ETCIvhkduOlzZWBh;
            rlQGF /= sYcXablXerBWMjiB;
            ETCIvhkduOlzZWBh -= MTrrtfy;
        }
    }
}

bool qtgUMX::rYOZZNKSD(bool tQuoSaq, int pEcqrymNFbOzDG, string YSCkAwF)
{
    double QqaIhEiMpg = 1009697.4394004964;
    double gJJIvmLJ = 274054.1055826945;

    for (int FZBQwCg = 590894362; FZBQwCg > 0; FZBQwCg--) {
        QqaIhEiMpg = gJJIvmLJ;
    }

    for (int PcDekBBTZchKBV = 1984711049; PcDekBBTZchKBV > 0; PcDekBBTZchKBV--) {
        continue;
    }

    if (pEcqrymNFbOzDG <= -774041423) {
        for (int jDiBS = 397379360; jDiBS > 0; jDiBS--) {
            QqaIhEiMpg *= gJJIvmLJ;
            gJJIvmLJ = gJJIvmLJ;
            QqaIhEiMpg *= QqaIhEiMpg;
            pEcqrymNFbOzDG *= pEcqrymNFbOzDG;
            gJJIvmLJ -= QqaIhEiMpg;
        }
    }

    if (QqaIhEiMpg == 274054.1055826945) {
        for (int QFZgJQSejqJkuF = 1948331916; QFZgJQSejqJkuF > 0; QFZgJQSejqJkuF--) {
            QqaIhEiMpg += QqaIhEiMpg;
            QqaIhEiMpg -= gJJIvmLJ;
            gJJIvmLJ /= QqaIhEiMpg;
        }
    }

    for (int TiMsWKnd = 930782862; TiMsWKnd > 0; TiMsWKnd--) {
        tQuoSaq = tQuoSaq;
        gJJIvmLJ -= QqaIhEiMpg;
        QqaIhEiMpg *= gJJIvmLJ;
        gJJIvmLJ -= QqaIhEiMpg;
    }

    for (int vnzahPWhLpKRDd = 1771528513; vnzahPWhLpKRDd > 0; vnzahPWhLpKRDd--) {
        pEcqrymNFbOzDG += pEcqrymNFbOzDG;
    }

    for (int XbnjwoSdCIWDwb = 1722320217; XbnjwoSdCIWDwb > 0; XbnjwoSdCIWDwb--) {
        tQuoSaq = ! tQuoSaq;
    }

    return tQuoSaq;
}

double qtgUMX::RArWVgcRsSJRjbA(double HNsoEFYMaSS)
{
    bool RCxOfmDQkACfz = false;
    double STBJAeLwNRk = 215951.4157418175;
    int XcWXpcL = -1134080489;

    for (int qaOHi = 1912925186; qaOHi > 0; qaOHi--) {
        HNsoEFYMaSS *= HNsoEFYMaSS;
        XcWXpcL -= XcWXpcL;
        RCxOfmDQkACfz = ! RCxOfmDQkACfz;
        STBJAeLwNRk /= STBJAeLwNRk;
        RCxOfmDQkACfz = ! RCxOfmDQkACfz;
        STBJAeLwNRk -= STBJAeLwNRk;
    }

    return STBJAeLwNRk;
}

qtgUMX::qtgUMX()
{
    this->nadTK();
    this->aUwCxdD();
    this->aVbwOT(-115150327, 1992701922, string("QTgSpKvEyjDnKNquBpVBaKpsUvelyhOsiQkIqwaWoFwJIrRxhUjvJycbOqcNDwgIjrFKiryVvuUJEQaNMsBvbpTNWOcAgusobECCyOqMpefZLchspqquWCABTzndNONRSJTVRzfOncErBNUxJIXrGErbH"));
    this->YoalxgXMjNrxz();
    this->wxDECXLGxeVz(2056582177, string("gqCAjVvgvJnABxrlLGnOrojNZPVtlUaWqQviNxZQOHMczwBWatsmJMtWUAvWpvwsOxXQhvIyEaOIQKaQsLJOoxctlpGO"));
    this->RITEYGMEeIMGz(-1670555605);
    this->AGvxVtMQBBkCOAv(false, -798633.034106376, string("wogKREGONBLZGdjCwxbvrelHLislYwatJhCrzTHozgPPYziDZnprsmtLTNbbdbKlHTdMnxK"), false);
    this->EcQylsEjcIN(false, string("PkiMiRQuUnXVUKiqLTJtNJrttyNuheLNwWzJGIzBwkZEWHtXHWyBvqJIQzlSriPZlxZgmWFbBbkktnesuUAyDreCBRw"), 563753.5872675149);
    this->CavJRDvw(-501991.15101688995);
    this->IiBMnMVYrvazyCNq(string("jaYetbvyTxrZOukJtB"));
    this->ccEZiFD(864242.9713077944, 797525.2977413719, true, string("CSIzqbLnXsjezlITKSxRNPqCqIzJpjuNeRhXLwfaQIjfHMbOtXYdWrCkoIlRHqoKcbuALicPETPbBHllAeSCaHoIFPrWCYSElZFIDqXRrpHkTadDUYLUyJdeVvTGWXKissS"), 974913.9250233442);
    this->VGrCl();
    this->rYOZZNKSD(true, -774041423, string("bXgVseoqnxowhOgSyzDfG"));
    this->RArWVgcRsSJRjbA(-755031.1083159988);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wniZKPN
{
public:
    string PDTiG;
    double cqhqJGoRxp;
    string FCdzO;
    bool MeKJZJZhF;
    bool aVfHKJxBX;

    wniZKPN();
    string pwSKtntXoPzmS(bool xtfKhynBMWjMC);
    double PerXGUKboESKn(int zCnDq, double WWQljqxfKFipRLw, bool YjnKiQVh, double OdJRyf);
protected:
    int AnzHdDMGkmdcf;
    bool ScDaHndJusAuY;
    bool VZYtVjxghi;
    bool uCUVDgseqKyLr;
    double xHzKwMZcFaqH;
    string bugpIsMVtlKGSKSG;

    string HXCiDPQSVcNYwqJL(string upwrUUKBoendG, bool ZdcuA, int gmuPC, bool dCoCzbz, string djoFwPfEobl);
    double jiDjjPiizggAAq(int ftsfDpVfYcMbLg, double opuAU);
    int vOrhszgg(int LsmyCoN, string gmnwu, string hyCkReOkSNjGAZc, double NjSqnccyXJY, bool LBTBqljo);
    bool ZEgclyDRTuaJu(double MCzLIctJCvIYEV, int ogAFzxDy, int RgSOSDJzZmQVi, string UJPFpixUedX);
    double qFWZLfjrrP(bool pYADjzrkTCVLA, string nplrdbZlzRjkM);
    bool IADfyYyHwHXnJTR(bool iAguVpQDHosZPkaU, string iwPEDRMWaOmPyhuH, double zKPnecLooBCPtxk);
    bool cJleecmXLYzc(int UdIInTe);
    int YRYhdOVbZEJvav(double oDKcNFwod, int kAgJaLXSAoISq, double DqkVgzNZm, double trjPfwQQLJ);
private:
    int BljRCkxUDx;
    double VZPtKMhagFHduV;
    bool PkokkQdsmFLIgvhB;
    string LqMtlQrWarf;
    string duPzwEVfRNy;

    double FVXPIGzwLQYRn();
    void SCAqtMjYK();
};

string wniZKPN::pwSKtntXoPzmS(bool xtfKhynBMWjMC)
{
    int AXNnMocLHlhmi = 190408797;
    int wqvYqnnppyxZd = 1968132362;
    string YvkbQVcacun = string("RNNLwYRCBkQwERYjgKYxRHZmDIbZtybHjmGeJwH");
    double wVhCNT = -566305.8080959707;
    string leauFKeVLLG = string("fIqQQHeVZcwTdHltcarqugPODCvnVpgEWioGLjAYLL");
    bool FXglaaVNNRfbA = false;
    int iLrBEcUZKcOgUXN = 1872711111;
    int JWYBdPnwAJM = 1679482742;

    if (xtfKhynBMWjMC != true) {
        for (int ntpAnNPYkPpQ = 679812632; ntpAnNPYkPpQ > 0; ntpAnNPYkPpQ--) {
            wVhCNT += wVhCNT;
            FXglaaVNNRfbA = ! xtfKhynBMWjMC;
        }
    }

    for (int TdZUOixynwftd = 1456266709; TdZUOixynwftd > 0; TdZUOixynwftd--) {
        AXNnMocLHlhmi *= iLrBEcUZKcOgUXN;
        JWYBdPnwAJM /= AXNnMocLHlhmi;
        iLrBEcUZKcOgUXN /= JWYBdPnwAJM;
        AXNnMocLHlhmi -= wqvYqnnppyxZd;
    }

    return leauFKeVLLG;
}

double wniZKPN::PerXGUKboESKn(int zCnDq, double WWQljqxfKFipRLw, bool YjnKiQVh, double OdJRyf)
{
    bool etWdvZvgIrZqfsqT = false;
    double yZGuknQfoV = 959305.1081092459;
    int GGnOZFcWL = 1372227149;
    string KMdTdc = string("fPghaORQElIxMWWpRfvNXiqvhDZMlUAcreBAGdaThCRcHzgU");
    int BYUfSqZd = -2036663888;
    bool jtkuVYITzfr = false;

    if (YjnKiQVh == false) {
        for (int xuTljCKwx = 1939270620; xuTljCKwx > 0; xuTljCKwx--) {
            YjnKiQVh = YjnKiQVh;
        }
    }

    for (int hXNYvkXvOM = 791622799; hXNYvkXvOM > 0; hXNYvkXvOM--) {
        zCnDq /= BYUfSqZd;
    }

    for (int rnqPWv = 603862235; rnqPWv > 0; rnqPWv--) {
        YjnKiQVh = ! etWdvZvgIrZqfsqT;
    }

    for (int EApbGmaGtswypTVY = 1087979756; EApbGmaGtswypTVY > 0; EApbGmaGtswypTVY--) {
        etWdvZvgIrZqfsqT = ! jtkuVYITzfr;
    }

    if (etWdvZvgIrZqfsqT == false) {
        for (int TTZZJCGUKX = 388294826; TTZZJCGUKX > 0; TTZZJCGUKX--) {
            zCnDq -= BYUfSqZd;
            YjnKiQVh = ! etWdvZvgIrZqfsqT;
        }
    }

    return yZGuknQfoV;
}

string wniZKPN::HXCiDPQSVcNYwqJL(string upwrUUKBoendG, bool ZdcuA, int gmuPC, bool dCoCzbz, string djoFwPfEobl)
{
    double uirlO = 149544.92361612877;
    int iIirLuGHMmuCFhm = -1403836107;
    int fqaksckRbh = 1636897067;
    int TIZMMJUho = 873916914;
    string yINDYoeOzhqBnGCp = string("yuDTwsZYurjZlrJqyOmGJSDTJTQOLlUXgCXLIZXSieRhsmOkFgDPJBJpcsdUccrLkoeBimWlafYhANDsathyFiqkHumMeKAbwAQiBlgvsfhiTZZFMfvGFVBnMHcQnTNMLDbpkfdtrJrXzQMpTFcEMByDkEBBMCLUFrgvhZJrKNPdIxCFFnDgZPRnLZFxfQJKt");
    string UyGoqDR = string("IqlhrtAcTAKXBKahlGfSQQsRChydNAogggKyqvjrcVIobPZRkBZPJXqFxAuklhVxkCZqAdfOEbytwoAnobDKaqIRIzPXRsNaRhLUhYhjZnHRQenPFZr");
    double nnuLLhnt = 2974.2468886537035;
    double QiSoHymRGvSm = 326617.8838385666;

    if (yINDYoeOzhqBnGCp < string("yuDTwsZYurjZlrJqyOmGJSDTJTQOLlUXgCXLIZXSieRhsmOkFgDPJBJpcsdUccrLkoeBimWlafYhANDsathyFiqkHumMeKAbwAQiBlgvsfhiTZZFMfvGFVBnMHcQnTNMLDbpkfdtrJrXzQMpTFcEMByDkEBBMCLUFrgvhZJrKNPdIxCFFnDgZPRnLZFxfQJKt")) {
        for (int hMcRB = 734816300; hMcRB > 0; hMcRB--) {
            ZdcuA = ZdcuA;
            iIirLuGHMmuCFhm -= TIZMMJUho;
            ZdcuA = ! ZdcuA;
        }
    }

    for (int pGQQx = 757501991; pGQQx > 0; pGQQx--) {
        nnuLLhnt -= uirlO;
        djoFwPfEobl += djoFwPfEobl;
    }

    return UyGoqDR;
}

double wniZKPN::jiDjjPiizggAAq(int ftsfDpVfYcMbLg, double opuAU)
{
    string hzuCBbXPdPxgPsrd = string("NwHCtPLodEMlsSWwdFNaJyNpmTCYyMYHvqkIklwZbuRYrqqvHoqPOoiTmeKyCzRGCNetwGgUiHrPJzTVKjbPKhBBHBbZVVjMlHGvAyxxLNjSZJnTaEaXIKvRgXIQrrMDkEKdLOqtITTOAiAZFZZEBLGWTvTLVRghVjLXOlTQKeWYZVyVqzFTVUTHvWDeMYazICpaPWUsWEqeQLwKVcdRIEQLfpzZxSabFaXgUdUewPxJzYDNA");

    if (ftsfDpVfYcMbLg > 1438499125) {
        for (int wyZspUwYMbl = 492192714; wyZspUwYMbl > 0; wyZspUwYMbl--) {
            opuAU = opuAU;
            hzuCBbXPdPxgPsrd = hzuCBbXPdPxgPsrd;
        }
    }

    for (int lqKclCwomCRWJdsC = 1707012389; lqKclCwomCRWJdsC > 0; lqKclCwomCRWJdsC--) {
        hzuCBbXPdPxgPsrd += hzuCBbXPdPxgPsrd;
        hzuCBbXPdPxgPsrd += hzuCBbXPdPxgPsrd;
        ftsfDpVfYcMbLg = ftsfDpVfYcMbLg;
    }

    if (hzuCBbXPdPxgPsrd >= string("NwHCtPLodEMlsSWwdFNaJyNpmTCYyMYHvqkIklwZbuRYrqqvHoqPOoiTmeKyCzRGCNetwGgUiHrPJzTVKjbPKhBBHBbZVVjMlHGvAyxxLNjSZJnTaEaXIKvRgXIQrrMDkEKdLOqtITTOAiAZFZZEBLGWTvTLVRghVjLXOlTQKeWYZVyVqzFTVUTHvWDeMYazICpaPWUsWEqeQLwKVcdRIEQLfpzZxSabFaXgUdUewPxJzYDNA")) {
        for (int kMmXABOrD = 462501761; kMmXABOrD > 0; kMmXABOrD--) {
            hzuCBbXPdPxgPsrd += hzuCBbXPdPxgPsrd;
            hzuCBbXPdPxgPsrd += hzuCBbXPdPxgPsrd;
            opuAU *= opuAU;
        }
    }

    if (ftsfDpVfYcMbLg != 1438499125) {
        for (int JhLGGLAMHbCQkcl = 1080362445; JhLGGLAMHbCQkcl > 0; JhLGGLAMHbCQkcl--) {
            ftsfDpVfYcMbLg *= ftsfDpVfYcMbLg;
            hzuCBbXPdPxgPsrd += hzuCBbXPdPxgPsrd;
            ftsfDpVfYcMbLg = ftsfDpVfYcMbLg;
            ftsfDpVfYcMbLg /= ftsfDpVfYcMbLg;
            opuAU += opuAU;
        }
    }

    for (int OQepoepbhz = 1632585700; OQepoepbhz > 0; OQepoepbhz--) {
        ftsfDpVfYcMbLg *= ftsfDpVfYcMbLg;
        hzuCBbXPdPxgPsrd += hzuCBbXPdPxgPsrd;
        ftsfDpVfYcMbLg = ftsfDpVfYcMbLg;
        opuAU -= opuAU;
        ftsfDpVfYcMbLg *= ftsfDpVfYcMbLg;
    }

    return opuAU;
}

int wniZKPN::vOrhszgg(int LsmyCoN, string gmnwu, string hyCkReOkSNjGAZc, double NjSqnccyXJY, bool LBTBqljo)
{
    double KWurJj = 143330.94497388246;
    string xSKqZBQyUaesMAZJ = string("wMMwHXhGzcnqdvNjLFnYmlWhlJSjivFpskPfXkMOuSFSDwQYyIaYyuFDezGqjHdBvbwINxmvHrFVLtbndphRqWUZAOIqMoDaUqNtJkHCdwFYbGExtRXoijtgclMeFNdCsBcPVL");
    bool tXcBWEljuGR = false;
    string ndeKPy = string("OBrjcqExSzMhVyxzzUlbMpihyYqfPaFqMYOvTcrDEEpkeVxxXIJyfIRSCvHndAjPyfIfSJqpPmFMzmnlQyBBDDVrqrKKDLGdpIKKOEseHfqAjAfuAcMtBNfa");
    double LSRnUOY = 74122.13652364339;
    bool cESvdEDK = true;
    double zLeLnHXdTfdyBK = -959307.7988747247;
    string PBkVjkFYqiST = string("pXZwTRXmlOmtQwkefNiQtQmEWFTTrZeATXYtJDCtBRhUSTfbNfZOitqbVoyEvNxQkCXETLUkngRDUprEeGLvJBwpdMwBJQtbzPsOAYvUHIgCKCKmaPZPtdfwBlXlAkkyXuMCdJjUvLuaKZzxzrQlBGYuKpmfqSqKZuqgVziPGXMpptyKizudU");
    int bFQCBcYda = 1974916889;
    bool fJPvbfEDCSZvuI = false;

    for (int RlDWCt = 23901614; RlDWCt > 0; RlDWCt--) {
        LsmyCoN /= LsmyCoN;
    }

    for (int KwvHmGvKXQgHF = 1435630624; KwvHmGvKXQgHF > 0; KwvHmGvKXQgHF--) {
        continue;
    }

    for (int PqzQVmT = 473864654; PqzQVmT > 0; PqzQVmT--) {
        continue;
    }

    return bFQCBcYda;
}

bool wniZKPN::ZEgclyDRTuaJu(double MCzLIctJCvIYEV, int ogAFzxDy, int RgSOSDJzZmQVi, string UJPFpixUedX)
{
    string XIruODiuYwGKS = string("AuvpQQxpZDBEbeMUReqgsssaXhzsdbrFqLoIqcwdQGThTDqjTxOdiHnxkiAEgWvuLsRVwmZzzNgafSSnTVkFsjqwkfwmHyfEmntTMYenINelPOToMBbJGeUVwaTyFMhYtijWmUFrTRXJXvZxRZGLIEKTAGdlkOoMdJDswtstljQHbbCp");
    string sgpyieLR = string("RLctdvwAGWOHjNpzDLTwdsrpWtvdXqgNgdmIYfbduzlWvSiuTvDKuCBBHnpGhXpfJJvCNRwohDzWnSqBzQFhBHFD");
    int LnBuoLYY = -159821606;
    string gtPpmKkUasDaom = string("LpqNltPBBNvkPTTdgJPXHpXEFKpkoeWhunaQdMeynUNJKtqWbaWUTpAVstKKSvAwHcNdncoTtyAXzqAAgMcMAdhHkDzteMMPbEPBvpapNNHbicnMaoChsx");
    double fvCTXCKCAnSszUz = 622908.2594076971;
    int lxXJKVukqosCQPb = -1645870293;
    int XSTegygNKfo = -749327372;
    double uppLqo = -983242.1983820465;
    string keIJjiDglomWizQa = string("BFgedJbqMDXnTVnbsiTmhhnzhsAXVSiPEnglxNsOsPayRRXrKNkUETTVugtiSPCfzKV");
    bool MicMYY = true;

    for (int rmWlPfNLyMCO = 1010096357; rmWlPfNLyMCO > 0; rmWlPfNLyMCO--) {
        continue;
    }

    for (int CJIWvSqrUqNkVYc = 979228295; CJIWvSqrUqNkVYc > 0; CJIWvSqrUqNkVYc--) {
        lxXJKVukqosCQPb += XSTegygNKfo;
        LnBuoLYY /= lxXJKVukqosCQPb;
        lxXJKVukqosCQPb /= lxXJKVukqosCQPb;
    }

    for (int WLEeVZPAYYDjZPVq = 912961170; WLEeVZPAYYDjZPVq > 0; WLEeVZPAYYDjZPVq--) {
        gtPpmKkUasDaom += sgpyieLR;
        RgSOSDJzZmQVi += RgSOSDJzZmQVi;
        MCzLIctJCvIYEV *= MCzLIctJCvIYEV;
        gtPpmKkUasDaom += keIJjiDglomWizQa;
    }

    return MicMYY;
}

double wniZKPN::qFWZLfjrrP(bool pYADjzrkTCVLA, string nplrdbZlzRjkM)
{
    bool WlJrcPJv = false;

    if (WlJrcPJv != false) {
        for (int UvLOCZtBqiTY = 1619990880; UvLOCZtBqiTY > 0; UvLOCZtBqiTY--) {
            pYADjzrkTCVLA = ! pYADjzrkTCVLA;
        }
    }

    if (nplrdbZlzRjkM == string("MXHyPnmZEXIVeqzwUmRNlASTRXHTJrYKKQKFGr")) {
        for (int vncHukPDTV = 327947041; vncHukPDTV > 0; vncHukPDTV--) {
            continue;
        }
    }

    return -900463.7608673268;
}

bool wniZKPN::IADfyYyHwHXnJTR(bool iAguVpQDHosZPkaU, string iwPEDRMWaOmPyhuH, double zKPnecLooBCPtxk)
{
    int slRztxglXhrybsyz = -1182549776;
    int HUqut = -244572559;
    double rSejRfPdAVnjhR = -580460.9053326439;
    string vMlqnoxd = string("XQceLQCiYVOrthadYmKacPozHSoboLZDcanTAaKobawMevtQFDLJNIODPHTIyQSNZTGEAOUEkNnkgymoZGAtqjqxWZJUZwddmliCqPIZgrLXvhCXqkaLISctzKHxrrQHLzVdKxuYStuSXWYOFgrWZOVhckecepCKE");
    int ZgiiaZVX = 984206096;
    double gZBSDvX = 931927.5759478527;
    int CUbNnc = 1168581189;
    bool gajQIAK = false;
    bool oWcMIOdWk = true;
    bool SrByngCuLtrv = false;

    if (slRztxglXhrybsyz < 984206096) {
        for (int IxRnjmBGI = 1667027882; IxRnjmBGI > 0; IxRnjmBGI--) {
            continue;
        }
    }

    for (int KiMbLlZe = 1674077969; KiMbLlZe > 0; KiMbLlZe--) {
        continue;
    }

    return SrByngCuLtrv;
}

bool wniZKPN::cJleecmXLYzc(int UdIInTe)
{
    bool IRmVTqtQssNE = false;
    string zKxGjozFSAbP = string("LWYBWTSkgYvTrEDuZUZGOIEYteRFfrGRXGWwOuGbUXvuuUqRulfBjJyoavzXFVFaiZDsoabFoaiBcHSXuGfBgNYmPfQbtQKQjBwTcUlYwOcqEnPVskMbuIRSEfZUYECSeQHjewxygDErNIUvdIOyzHjKpMlslSMpQgespTafvKxEBwUkMdrhRKSyePOlQMfWAUTxYehSVBLZItkDhoBR");
    string lVUjYOG = string("KnDmVKNBXewGfmucynUWlaCCNpQAjbnwvKwixOxpXhIOBsPTnyvtOzhfUafbQXDAAzuGfmExHoraDxMxuXEIrAcYiATOhDOE");
    int kcRsisoTyFfAEA = 1932275081;
    double IlBKASP = 408010.2919460206;
    string cjiHvxUeIHGpQku = string("lEfAPDyTEofFFSDQWmpbBgbEbMremBqRxBIQFUBHkLMTAheLSExNMmbVVGyNOOsEBIgmOZjzToFKRsipBdmUTfZvRMWWzplrHFjgBLOEfVM");
    double EheZUImlvkvcc = -851718.5199436946;

    for (int ZcXfvwNJjaMoJbx = 1344819979; ZcXfvwNJjaMoJbx > 0; ZcXfvwNJjaMoJbx--) {
        zKxGjozFSAbP += zKxGjozFSAbP;
    }

    for (int DsXAihq = 829959442; DsXAihq > 0; DsXAihq--) {
        EheZUImlvkvcc -= IlBKASP;
    }

    for (int EZsiMHWtJxR = 593944611; EZsiMHWtJxR > 0; EZsiMHWtJxR--) {
        IlBKASP /= EheZUImlvkvcc;
        zKxGjozFSAbP = cjiHvxUeIHGpQku;
    }

    for (int hAECYZh = 706654134; hAECYZh > 0; hAECYZh--) {
        IRmVTqtQssNE = IRmVTqtQssNE;
        zKxGjozFSAbP = zKxGjozFSAbP;
    }

    if (IlBKASP <= 408010.2919460206) {
        for (int kTmRmB = 638019488; kTmRmB > 0; kTmRmB--) {
            UdIInTe += UdIInTe;
            lVUjYOG += zKxGjozFSAbP;
            kcRsisoTyFfAEA += UdIInTe;
        }
    }

    return IRmVTqtQssNE;
}

int wniZKPN::YRYhdOVbZEJvav(double oDKcNFwod, int kAgJaLXSAoISq, double DqkVgzNZm, double trjPfwQQLJ)
{
    int LwvFS = 1525765435;
    double HbaxTJswz = 1002449.3052378319;
    int cAlAnzPnPXwJPdgG = -1796358375;

    for (int QukAsUyzP = 131839808; QukAsUyzP > 0; QukAsUyzP--) {
        cAlAnzPnPXwJPdgG = kAgJaLXSAoISq;
    }

    if (trjPfwQQLJ < -881910.4490614024) {
        for (int QtZLiDXe = 1009839024; QtZLiDXe > 0; QtZLiDXe--) {
            DqkVgzNZm += oDKcNFwod;
        }
    }

    if (oDKcNFwod > 925621.0086217432) {
        for (int ZZMexaUFuBebqart = 484391468; ZZMexaUFuBebqart > 0; ZZMexaUFuBebqart--) {
            DqkVgzNZm *= trjPfwQQLJ;
        }
    }

    for (int SXxhupKo = 695906243; SXxhupKo > 0; SXxhupKo--) {
        LwvFS /= kAgJaLXSAoISq;
    }

    return cAlAnzPnPXwJPdgG;
}

double wniZKPN::FVXPIGzwLQYRn()
{
    double JGIaogqDkNajrB = 914529.59766622;
    int kTatWUNy = -129667890;
    bool CnTYUDvQvJRlhaKj = true;
    double hQeUiu = -500566.74608926266;

    for (int bfKeFcEfvQ = 654576585; bfKeFcEfvQ > 0; bfKeFcEfvQ--) {
        hQeUiu /= hQeUiu;
    }

    return hQeUiu;
}

void wniZKPN::SCAqtMjYK()
{
    string ApqFjGigUTTwtVr = string("TyPcwmiQlhSrYIAxUepWCaXEpVTMnoUpRi");
    string pMZvxqpxdZkZnuWi = string("QUJNDnTeNQMTtAncdhkOmBApRcDBlalxFrTzayHxrgIKZrNlLjloJPvezhcQxuFknMpmVlbh");
    int UZyNbfIEPdOYydBD = 62794711;
    int HLRsPvMDykNPON = -1654903724;
    int HymGAFaJzD = 1445969396;
    int KpQUJadu = -2040143341;
    int HJBlneSZasdDfTyD = 2008020181;
    double mXHyXBSIWc = 769946.6438773443;
}

wniZKPN::wniZKPN()
{
    this->pwSKtntXoPzmS(true);
    this->PerXGUKboESKn(-2066891770, 962139.0672693478, false, 516196.7958302782);
    this->HXCiDPQSVcNYwqJL(string("xFKyhRlFNlFjBzmAmYrChSdeFjPLFBsOHKOyDyVKAlDiYyFPOXdOCmtkKyHAPWlQmsyARgMKWhLoqbDXjBqruPhVGZEWqMGrlSHdWuCsLYwyBHoUhxxtcPHbvXDWqPYKlHwlJHdBvnWJHornNwesShssNyGCegBeKjKEQesdKqHLYhyjWuXpyfvtjMKXpXpobUSUIuklvgsydJiZVliVaHaUlXgtAb"), false, -1483797766, true, string("IqxRYxEOOiFpXYiDdfDpRGDmocYNMLzBggHbgtNmBKIHYOckVKJJdUQeDzgVJgOTkrLUBQoJUpIpsJUaJorypNUcWFoWxnKCzWnoqonxatmnwuCzwneiAqwTbTftOeXVzEXyiWlnlvCIzXMdLbPyuDZYrjZQBgepqMKsZuMOIhPLWVEaasIetoKMYlndcRFQrtfptWSPLoEztFhyZcTxDHWuFczWLSJNFhaVuBpeZAufLGYcQokovyPiuP"));
    this->jiDjjPiizggAAq(1438499125, -944100.5233135123);
    this->vOrhszgg(316790215, string("lApSkaICKGzJcnkKPhVMgHcCHhaGAcwRdtspeIScaJxzLkGJcMAfujsJkibFYcosxvzhnJOtDSsNc"), string("VdxNXRKqgRsvxPVGwKiwEwhxzoLimYzOmCgZlJHDEDHEKJrJQSvrOyUumPBHHKNyHJxGtlajgqbsMFlyrQehnAWuaPHNWVwompTTJsHPnLyaAHmzwjLhQaqfZHvlqIpRJYuDsKlnfLIukOjxXwAczLGFWhCdzVEPxFwUvFbwQiPdjDrCRlLNDSRbrMGcUXiJhwpQiTZkrczKfIwcCskclrWoLjLGyvPjKRAcYxFseNabKQhbCjdv"), 207901.3796549734, true);
    this->ZEgclyDRTuaJu(370045.1188721397, 1114761827, -826475142, string("kPgTN"));
    this->qFWZLfjrrP(true, string("MXHyPnmZEXIVeqzwUmRNlASTRXHTJrYKKQKFGr"));
    this->IADfyYyHwHXnJTR(true, string("XLImLagSFmRPUbCWlienRDqtdUCNKjUpJCFJOmfyBLOpNebVFZRxVZHTADy"), 476656.51293946285);
    this->cJleecmXLYzc(-804704934);
    this->YRYhdOVbZEJvav(-881910.4490614024, -1888879804, 549744.9790015348, 925621.0086217432);
    this->FVXPIGzwLQYRn();
    this->SCAqtMjYK();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dGjGeLL
{
public:
    bool JDYILv;
    double IUKixovrUEhbB;
    string PZhbfA;

    dGjGeLL();
    string qwoisecHfRNZoGqd(int uvqhfPKnN, double yyeKCWImAlA, bool FmCfgGxTEhWqTKH);
    string SOwivTKLOuVWP(int wMJqPvKK, int mbdOQtcZWi, string jQpqhxAEB, bool tfLzH, string nfuScSDvDRmXRf);
    string DGKloqWKDOr(bool xvgFMAqctaqwiYKw);
    void atTYeVWoUkqGBS();
    void NdPGou(bool aAqxgbfJAzr);
protected:
    bool tmAFXPO;

private:
    bool FTFARvf;
    int zMfwxRTOZniNoV;
    double WSGDKZ;
    bool uzjdR;
    int fnhEsRO;
    bool apjOVKq;

    bool SdDPjTzk(bool lnGRunSvjZWG, double PWIjFcYkWjUgXKS, int xfHxPoBhQbc);
};

string dGjGeLL::qwoisecHfRNZoGqd(int uvqhfPKnN, double yyeKCWImAlA, bool FmCfgGxTEhWqTKH)
{
    string THcBBNocpkWWawp = string("BPGxKjecmJXmyNtKNShAytrbMDaduqkPqKpnmeLHTUirQGTpBDLdmdnivfvArKbHKSYcaxbIlMpvrmZSPDzyucQHzoXqgpPeRvfVi");

    for (int eWPeisHJSqXX = 669565720; eWPeisHJSqXX > 0; eWPeisHJSqXX--) {
        THcBBNocpkWWawp = THcBBNocpkWWawp;
        uvqhfPKnN = uvqhfPKnN;
    }

    for (int fnFtkTmCk = 377027699; fnFtkTmCk > 0; fnFtkTmCk--) {
        FmCfgGxTEhWqTKH = ! FmCfgGxTEhWqTKH;
        THcBBNocpkWWawp = THcBBNocpkWWawp;
    }

    if (uvqhfPKnN > -1726447871) {
        for (int apPUKPChkKOElOF = 2088236189; apPUKPChkKOElOF > 0; apPUKPChkKOElOF--) {
            THcBBNocpkWWawp = THcBBNocpkWWawp;
        }
    }

    if (FmCfgGxTEhWqTKH == true) {
        for (int GYstppOI = 380492908; GYstppOI > 0; GYstppOI--) {
            FmCfgGxTEhWqTKH = FmCfgGxTEhWqTKH;
            yyeKCWImAlA /= yyeKCWImAlA;
            yyeKCWImAlA = yyeKCWImAlA;
            THcBBNocpkWWawp += THcBBNocpkWWawp;
        }
    }

    return THcBBNocpkWWawp;
}

string dGjGeLL::SOwivTKLOuVWP(int wMJqPvKK, int mbdOQtcZWi, string jQpqhxAEB, bool tfLzH, string nfuScSDvDRmXRf)
{
    bool ZWJsmXEgRvQ = true;
    double UJLhBX = 952692.5041134839;

    for (int SEJijUKsT = 1130449060; SEJijUKsT > 0; SEJijUKsT--) {
        jQpqhxAEB = nfuScSDvDRmXRf;
    }

    return nfuScSDvDRmXRf;
}

string dGjGeLL::DGKloqWKDOr(bool xvgFMAqctaqwiYKw)
{
    double oFfrCjBCLYOcf = -607206.8482179359;
    double XGgHQxTbEJIBZzr = 527840.2752109473;
    double qhstPNh = 95942.9610309616;
    int CVQAKYzqpooXKV = 2062052086;
    string vDFCJvgJnMsUxZC = string("KQPVfREypNuNWHAwTIfWdqwKhqvvoVFAbLexbqTGzQMVPcacCjGpdvQbrcgKPfnRau");
    string tmbkLuZp = string("vUMHYMj");

    for (int bWZtotVfvylBTY = 1640858787; bWZtotVfvylBTY > 0; bWZtotVfvylBTY--) {
        XGgHQxTbEJIBZzr += XGgHQxTbEJIBZzr;
        oFfrCjBCLYOcf += oFfrCjBCLYOcf;
        oFfrCjBCLYOcf *= XGgHQxTbEJIBZzr;
    }

    return tmbkLuZp;
}

void dGjGeLL::atTYeVWoUkqGBS()
{
    bool NAMIAHDtvpOADF = true;
    int tYMbP = 2008241712;
    int uMjXHXy = -1597078953;
    double KsRXUOlUDbkZx = 719593.2151084527;
    bool XvGVqnGu = false;
    double LxiXmQi = 931316.9459618751;
    int TNmVRzbhQzHTiNOU = 1806590380;
    int gtJlPhBTgzEItijH = -663592446;

    for (int hwTXSOWRMTvuIM = 676972406; hwTXSOWRMTvuIM > 0; hwTXSOWRMTvuIM--) {
        KsRXUOlUDbkZx = KsRXUOlUDbkZx;
        uMjXHXy -= uMjXHXy;
        XvGVqnGu = NAMIAHDtvpOADF;
    }

    for (int pyRMSQksaEkkdfhi = 1602382758; pyRMSQksaEkkdfhi > 0; pyRMSQksaEkkdfhi--) {
        uMjXHXy = uMjXHXy;
    }

    for (int xepMWQ = 859236580; xepMWQ > 0; xepMWQ--) {
        NAMIAHDtvpOADF = XvGVqnGu;
        uMjXHXy += TNmVRzbhQzHTiNOU;
    }

    for (int XbYKcyCHXA = 1377076696; XbYKcyCHXA > 0; XbYKcyCHXA--) {
        gtJlPhBTgzEItijH /= tYMbP;
    }

    for (int XJDPSCtiLCwM = 2038569381; XJDPSCtiLCwM > 0; XJDPSCtiLCwM--) {
        gtJlPhBTgzEItijH = uMjXHXy;
        XvGVqnGu = NAMIAHDtvpOADF;
    }

    if (XvGVqnGu != true) {
        for (int pLDKSrjoq = 953133257; pLDKSrjoq > 0; pLDKSrjoq--) {
            continue;
        }
    }
}

void dGjGeLL::NdPGou(bool aAqxgbfJAzr)
{
    int SHikEFhhaiRw = -1827597052;
    double IPfHt = -273013.0506254804;
    double lLjdmaHqXJylgzz = 640180.4212263472;
    string dUgzYhttrGDmQjY = string("mxGLdcORlKkRgmEjVzxoJhKPAdYCDPfBGCgBTISKoSLArcOQzVbDfaBAkBKphvxroLkXkMXSzIbltzCzdgIEOukeaXhgxSGhRPlgUraHpjUdOGHrWpVdJfYltlRRxReTDjmCGoLYdybWWBAYkfdctVZoOWkEcMdTnRRBXAlVSxSEYAVcPXWWUXSAhcuPrOyVvpTsRyLpOCGggBuNnltLFlYBgNOCPowtiwbCbmpXPsRNtbnfcbkEuMnKgpjvG");
    bool mgWDoZsWEaBgpPl = true;
    double rTLyFS = -926744.508659542;
    bool GLhkLIwuzNsonZ = true;
    string iwsIBkxv = string("cGICAweZzTDhaDgAxOsSUgYmYCykhbOSIxzoEqoBAVtEgiItgNQyjxkXrHjJWlMLDYVTjMsOiLBHVxhbmTNcqNhraIKxwvbwiYDErXlfsOVAuBWgrMMQwcdBEEnJpsslibyIMFJqbtmPmvqEmCKDTFSEjsiFgMTjoeLjXdRfUVnrFusYiQpRzLlELtedfMzpDSJYRynUrXEyMjKcDfOHkJWpjhlAIjQSEAxB");
    bool JuzPMirh = false;

    if (rTLyFS == -273013.0506254804) {
        for (int lCoJrhmYxgWpZv = 1493214484; lCoJrhmYxgWpZv > 0; lCoJrhmYxgWpZv--) {
            mgWDoZsWEaBgpPl = GLhkLIwuzNsonZ;
            rTLyFS /= lLjdmaHqXJylgzz;
            JuzPMirh = JuzPMirh;
            dUgzYhttrGDmQjY += iwsIBkxv;
        }
    }

    if (JuzPMirh == true) {
        for (int sueyHfnZJ = 1503443410; sueyHfnZJ > 0; sueyHfnZJ--) {
            dUgzYhttrGDmQjY = dUgzYhttrGDmQjY;
        }
    }

    for (int erpkKrjRxF = 783960269; erpkKrjRxF > 0; erpkKrjRxF--) {
        continue;
    }

    for (int xqdLjARQJfwmD = 919527181; xqdLjARQJfwmD > 0; xqdLjARQJfwmD--) {
        iwsIBkxv += iwsIBkxv;
        JuzPMirh = ! GLhkLIwuzNsonZ;
        lLjdmaHqXJylgzz -= IPfHt;
    }

    for (int QbhJI = 1428130372; QbhJI > 0; QbhJI--) {
        IPfHt /= rTLyFS;
    }
}

bool dGjGeLL::SdDPjTzk(bool lnGRunSvjZWG, double PWIjFcYkWjUgXKS, int xfHxPoBhQbc)
{
    int gWAPivfebNxgqrzn = -1304153102;
    int EkCLkdnJ = 47072128;
    string dLAnbBuN = string("JIOytlpbrZCPMmwBEVPEqcbxDyGPKFZkxFugxKLiGrIAJtFZGeiPXsvxyERXgbgMyCTWTplIDAQcRTkOajmxbojMSvPywKjiripoKGlhLzJbxJuHhLuBBTXEIQZnDFfBmpsceNFJeVZqdmUUsUCYERLyQcQyNuItviiNtdcWUQlKUooFpnMkIGtdTDgQvrquGYKeHuMtFWMgmvejsvuWNtBFjTvVMfsmaouD");
    bool mrjQJAkiRkOV = false;
    double qSThkrWLdYwk = 317850.133907026;

    if (EkCLkdnJ != 47072128) {
        for (int cxHFYbxNcGz = 720564037; cxHFYbxNcGz > 0; cxHFYbxNcGz--) {
            lnGRunSvjZWG = lnGRunSvjZWG;
        }
    }

    for (int HVFzTKvVxaUr = 2114690538; HVFzTKvVxaUr > 0; HVFzTKvVxaUr--) {
        xfHxPoBhQbc += gWAPivfebNxgqrzn;
    }

    for (int CZmcGAB = 1449411903; CZmcGAB > 0; CZmcGAB--) {
        continue;
    }

    for (int urrFay = 1055280833; urrFay > 0; urrFay--) {
        continue;
    }

    for (int CksNh = 1658321868; CksNh > 0; CksNh--) {
        lnGRunSvjZWG = lnGRunSvjZWG;
        xfHxPoBhQbc += EkCLkdnJ;
    }

    return mrjQJAkiRkOV;
}

dGjGeLL::dGjGeLL()
{
    this->qwoisecHfRNZoGqd(-1726447871, -367053.9823315353, true);
    this->SOwivTKLOuVWP(1551700804, -921549524, string("srwWMArZYbUSFPPjrJDIbEiyfEiYNNWcGDqGyOCQviUSTAczjRsfgIllYVbgCjbLCHtxXWbPYGwEKcpacCKABNUpwsyXEtxNsCPPTgiTQVqEYGMdyOEttjtYLtXReBHeuoKYDlDvkuRWzYZDvVEXPYzKiymTodvHCiJc"), true, string("LhexpfqRBtzxQzrLC"));
    this->DGKloqWKDOr(true);
    this->atTYeVWoUkqGBS();
    this->NdPGou(true);
    this->SdDPjTzk(true, 230612.3226282593, -734412868);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HQrFtNbqxk
{
public:
    int AiFkl;
    string RCLylJaHuGhmL;
    int nHYmP;
    double vdyQRVFUV;

    HQrFtNbqxk();
    int IsRtqkRPbSXgL(double WCXnXBkJzhel);
    int cZaXmnrjcT();
protected:
    bool pUsPrj;
    int YBiiFH;
    int wmighenJUfdNFj;
    string lknjwPdVeF;

    string HBLIEXZYnO(int KPxLTxGAL, bool mAmYFkaNY);
    string puvgqVAm(double daiWgOePtfhxY, bool QhQmtFvRGxU, bool qAArpK, string fFbWOnVDdyRtK);
    string ULWKtRrfu();
    string eGKnz();
private:
    double cRxflVu;

    double bRNJzPcm(int LudaXWrRe);
    void gDOEnjpZt(int CKiNb, double cKydMbu);
    double cvtNDGa(string rlkhB, int FGhEedlPaT, double KDCSMYUcjbZroZ, int WtZkKL);
    double DPrlR(int GMzDbDqyRrBCHiz, string TcxftP);
    int eipaR(string QsjAHyLxgAyOB, bool viObIqzp, bool BDLuWrjIfi, bool QChQjUwppNk, int xWZQKd);
    string BVKDMsLWxUfMvrI(string MeCszgWPRZlhmJoL);
};

int HQrFtNbqxk::IsRtqkRPbSXgL(double WCXnXBkJzhel)
{
    string ewnLgDv = string("fyiyQAzuiaRWaPgmZrIZiGAtPJzowMgyukDbZgRfpUjgBhUXYOxYkhCfBwtvOKlfdTKKfhMNLNEPQVDafmZYZgTpIozxGumdHWiLXNxLgTMXWZjaaDaYSLZMUUKTOdisHsnBHscmIaIOgzKMJxAfIiJABdxMtaHnDtpqpPzkupGfCemdkkUhUdSDlFGdOYokWXYRyCYGuuWniNqwkKEjIPkWofJlxKbpMxGXCDHFsjOzShMcBsMZN");
    double xTqIyntGRf = 462295.4474123859;
    string QiKXaIWm = string("VhiyOKaQCtyfiEfjPtJlJLuXcxSZxVENnTdjimlmsJLTYMaGGFlIDCkyiwolljijenDdUOeXXvCSkAFsnAEH");
    string gOSECrI = string("MDJDAUVadlXYlftzaffMfKyMzBPiPJsTdoDLBHWxAECHKKITqCIJGsHsBuxaKTHoPdbgdFYbFxdLNnKcUKDlGuzDomHEGpHWowhYVRZaPCwaHWTztJPpiFuMLyVarexmjqTYVZnPnrmfZJsixgUnQLhrmSbTvwCemoCTUSGhdJjkHplQJfseknGOSUaEzkICBsULcFXnyySbpdMPzANHRDxAauASCKhVSyqxRZmcsQXLNWAaFGjMhOY");

    return 1292689595;
}

int HQrFtNbqxk::cZaXmnrjcT()
{
    string tznaqlE = string("eUwzWXGkCFUsJUdQguTFvltHrQiCamTEdazCbTqtDldiqXwPaZOdTanlhbWncUCepNYlqpxrQXXtSmSegxABghVsSFajudPtRtOwMBFdfbkJFPjmjSVGjqxuKHanpxITaQcIuEWKIQVMzQTybLZfwpHcuYTRwkUBEvicmxYhKcRzeenVqhYHpbQrUBBDechCbcKNQbRToyBYlLNmzQJDOUTeexhZYKmFUXfQLc");
    double FRFnW = 1027957.9494855757;
    bool mTTEgArOrDXcO = true;
    int wQrYpx = -1792968650;

    if (tznaqlE <= string("eUwzWXGkCFUsJUdQguTFvltHrQiCamTEdazCbTqtDldiqXwPaZOdTanlhbWncUCepNYlqpxrQXXtSmSegxABghVsSFajudPtRtOwMBFdfbkJFPjmjSVGjqxuKHanpxITaQcIuEWKIQVMzQTybLZfwpHcuYTRwkUBEvicmxYhKcRzeenVqhYHpbQrUBBDechCbcKNQbRToyBYlLNmzQJDOUTeexhZYKmFUXfQLc")) {
        for (int SuYpDNKJXwlZ = 1840625416; SuYpDNKJXwlZ > 0; SuYpDNKJXwlZ--) {
            mTTEgArOrDXcO = ! mTTEgArOrDXcO;
        }
    }

    for (int seFLDxk = 1211331585; seFLDxk > 0; seFLDxk--) {
        wQrYpx += wQrYpx;
        mTTEgArOrDXcO = ! mTTEgArOrDXcO;
        mTTEgArOrDXcO = mTTEgArOrDXcO;
        wQrYpx /= wQrYpx;
    }

    for (int EwKkSdKSTAvtItym = 1626736351; EwKkSdKSTAvtItym > 0; EwKkSdKSTAvtItym--) {
        continue;
    }

    for (int VRFUoK = 1417122602; VRFUoK > 0; VRFUoK--) {
        mTTEgArOrDXcO = ! mTTEgArOrDXcO;
        mTTEgArOrDXcO = mTTEgArOrDXcO;
    }

    for (int VVlqgthrDCLiRBa = 1708267271; VVlqgthrDCLiRBa > 0; VVlqgthrDCLiRBa--) {
        mTTEgArOrDXcO = mTTEgArOrDXcO;
    }

    return wQrYpx;
}

string HQrFtNbqxk::HBLIEXZYnO(int KPxLTxGAL, bool mAmYFkaNY)
{
    int hCIexKVsdgrAif = 1107904383;
    string UCMHKsZPKz = string("vtfyMtcpRM");

    for (int pjQHazQdZuqyTgon = 123564772; pjQHazQdZuqyTgon > 0; pjQHazQdZuqyTgon--) {
        UCMHKsZPKz += UCMHKsZPKz;
    }

    for (int YxaDmUAuh = 1169758144; YxaDmUAuh > 0; YxaDmUAuh--) {
        hCIexKVsdgrAif = hCIexKVsdgrAif;
        UCMHKsZPKz += UCMHKsZPKz;
        hCIexKVsdgrAif = KPxLTxGAL;
        hCIexKVsdgrAif *= KPxLTxGAL;
        UCMHKsZPKz += UCMHKsZPKz;
    }

    for (int vRfYWVNOAg = 206218657; vRfYWVNOAg > 0; vRfYWVNOAg--) {
        UCMHKsZPKz = UCMHKsZPKz;
    }

    if (mAmYFkaNY != true) {
        for (int CxzrThHnBPjMfd = 1134753198; CxzrThHnBPjMfd > 0; CxzrThHnBPjMfd--) {
            UCMHKsZPKz += UCMHKsZPKz;
            KPxLTxGAL /= hCIexKVsdgrAif;
            hCIexKVsdgrAif = KPxLTxGAL;
            KPxLTxGAL -= KPxLTxGAL;
        }
    }

    return UCMHKsZPKz;
}

string HQrFtNbqxk::puvgqVAm(double daiWgOePtfhxY, bool QhQmtFvRGxU, bool qAArpK, string fFbWOnVDdyRtK)
{
    bool CGxqeq = true;
    string NZugA = string("oAJmegziEgDpEFXieJeTbputxFTWaOmSMtEVSXJDMksmnSvWbWcIdZPETXLZqMqrhRcEvNDqgINRhXCQFJNTkyCXZTjkUPzMbCDfkE");
    string EnjogcruFM = string("ZUtFaEmebdhSeIPJeypmdsAdfsTMdqjAvjrcAZxZUvbTPitsSbmNbmDSRAtSOsRatOMnFdADPrHUGJBkeQOPDXcNzCMapZENsVBbkYmaBBPirhNQdjZYhvLjloueewcVhzQXsxvCAouvROMNkamVPrmwLSNGTMgoNEibTvpWMGaHqhvhFHKocgCTzDGrU");
    double BzVQRxkKkennFlJ = -831269.2180492149;
    string BPDhNJb = string("AxaFrYZeFPFRoPbXaMVbbLAIGkyfHBTeqMGkUewHSwsTLxTJEpeOpxJsCsSfFKyUrzHPsIBlFmLUnTBGvgrPnUdjFrRJaeNBilWJsRiDqhkGrNHHcGHPkJGoIeHdSuNQFCegDPSYmFrFvhxafBMdUTduYtraNRMgKNjptchBQCzBOJTdHtOfdYiFCOGYcHhuwPqlntNMOdWxaWTOASZXOq");
    string GoPwYHu = string("ZUpMGxnNAdimgxEExzpiaukLdpyVrnNAvSAMDEUdTwkQelSOfNlxlOFzJgcYSmlMYRdMMJNPfwPzBiaexXycZWSiBhCgSInEciXmercGqWwGHuJhWMOqAMHMVpGWIqbJcXQbVBEqYImPQxVuLyTCIZDHf");

    for (int lnJCvViGMTHysV = 2017585270; lnJCvViGMTHysV > 0; lnJCvViGMTHysV--) {
        continue;
    }

    if (QhQmtFvRGxU == true) {
        for (int sIBxzuW = 1998958291; sIBxzuW > 0; sIBxzuW--) {
            GoPwYHu = GoPwYHu;
            EnjogcruFM = EnjogcruFM;
            BPDhNJb += EnjogcruFM;
            BPDhNJb += EnjogcruFM;
            EnjogcruFM += NZugA;
        }
    }

    for (int BKcpG = 968030859; BKcpG > 0; BKcpG--) {
        continue;
    }

    for (int lwtTgXdFGcSlbe = 978135306; lwtTgXdFGcSlbe > 0; lwtTgXdFGcSlbe--) {
        BPDhNJb += fFbWOnVDdyRtK;
        BzVQRxkKkennFlJ += daiWgOePtfhxY;
        BPDhNJb += GoPwYHu;
        fFbWOnVDdyRtK = fFbWOnVDdyRtK;
    }

    for (int EbJcJHUngS = 1119962221; EbJcJHUngS > 0; EbJcJHUngS--) {
        GoPwYHu += fFbWOnVDdyRtK;
        fFbWOnVDdyRtK += BPDhNJb;
    }

    return GoPwYHu;
}

string HQrFtNbqxk::ULWKtRrfu()
{
    string BYDlZBbG = string("pIctLJAJJwWWQJtVCinqemUtFoEPmAqoTmxDmWdapaVuRKGLRnmzYevsQigicvtXYJnODrtxDxxCTepaBneCzLluhCuHBFehgengLpFojpsGwSXBEzVjU");
    double tzLSN = 178418.5621129903;
    bool ehwVzpesLf = false;
    double IMoGwbx = -566407.754732214;
    bool pdfuCQyFlVnDZ = true;
    double xEQYDJ = 290371.6527901076;
    bool gjXfzhYEoA = false;
    double CZNHb = 917483.8582476026;

    for (int bNvcmV = 1167606761; bNvcmV > 0; bNvcmV--) {
        xEQYDJ *= CZNHb;
        CZNHb -= xEQYDJ;
        tzLSN *= xEQYDJ;
        ehwVzpesLf = ! pdfuCQyFlVnDZ;
        ehwVzpesLf = ! pdfuCQyFlVnDZ;
    }

    for (int WzdxSON = 2009210133; WzdxSON > 0; WzdxSON--) {
        CZNHb += CZNHb;
        tzLSN += xEQYDJ;
    }

    for (int hIdXCMvswNHU = 1746811387; hIdXCMvswNHU > 0; hIdXCMvswNHU--) {
        pdfuCQyFlVnDZ = ! ehwVzpesLf;
        CZNHb *= IMoGwbx;
        gjXfzhYEoA = ! ehwVzpesLf;
        IMoGwbx /= xEQYDJ;
    }

    for (int zlyzi = 816492251; zlyzi > 0; zlyzi--) {
        xEQYDJ -= IMoGwbx;
        tzLSN /= IMoGwbx;
        tzLSN += xEQYDJ;
        gjXfzhYEoA = ! gjXfzhYEoA;
    }

    return BYDlZBbG;
}

string HQrFtNbqxk::eGKnz()
{
    double qxTtBG = -827323.2618539031;
    string aMrceKq = string("lBLxBskOjuHnbtJVLVnbuRjpVX");
    int avJyUJOsNHQotoLn = 1070598204;

    for (int mZKKhzwKaylP = 1627997121; mZKKhzwKaylP > 0; mZKKhzwKaylP--) {
        avJyUJOsNHQotoLn += avJyUJOsNHQotoLn;
        aMrceKq += aMrceKq;
    }

    for (int BZwEYOvXTdBldGiI = 1527523990; BZwEYOvXTdBldGiI > 0; BZwEYOvXTdBldGiI--) {
        aMrceKq += aMrceKq;
        avJyUJOsNHQotoLn = avJyUJOsNHQotoLn;
        aMrceKq = aMrceKq;
        avJyUJOsNHQotoLn /= avJyUJOsNHQotoLn;
    }

    if (aMrceKq == string("lBLxBskOjuHnbtJVLVnbuRjpVX")) {
        for (int xsVsjkfuzrvAtHP = 228845443; xsVsjkfuzrvAtHP > 0; xsVsjkfuzrvAtHP--) {
            aMrceKq = aMrceKq;
            aMrceKq += aMrceKq;
            qxTtBG *= qxTtBG;
            avJyUJOsNHQotoLn *= avJyUJOsNHQotoLn;
            qxTtBG *= qxTtBG;
            avJyUJOsNHQotoLn += avJyUJOsNHQotoLn;
        }
    }

    return aMrceKq;
}

double HQrFtNbqxk::bRNJzPcm(int LudaXWrRe)
{
    double DxeaSTmnrkQPfi = -1036148.7137416896;
    string jRFuiGfEwRARXrf = string("qRXJPoAjDjGIzJhsicnbSFKJUfihyJRoYGzAwSMhgamkygApGhqDBOCrtHfRzPCKqfCCJYmbFIiYKxOQxRvJGyooEXsZafQHOWVCQrHWJbkLcSWNafguhJmStKQDrxohUnjxcsgrRLqjlRESTCXXOnFjJwxHwCRZssvYqcpuMqHQgiOldskziqOZGf");

    if (LudaXWrRe == 1611745605) {
        for (int ScGJPqHsuD = 1306361438; ScGJPqHsuD > 0; ScGJPqHsuD--) {
            DxeaSTmnrkQPfi *= DxeaSTmnrkQPfi;
            LudaXWrRe = LudaXWrRe;
            DxeaSTmnrkQPfi = DxeaSTmnrkQPfi;
        }
    }

    if (DxeaSTmnrkQPfi == -1036148.7137416896) {
        for (int HAqIeO = 745361327; HAqIeO > 0; HAqIeO--) {
            continue;
        }
    }

    if (LudaXWrRe != 1611745605) {
        for (int RRRboXMe = 305264934; RRRboXMe > 0; RRRboXMe--) {
            jRFuiGfEwRARXrf += jRFuiGfEwRARXrf;
            jRFuiGfEwRARXrf += jRFuiGfEwRARXrf;
            LudaXWrRe /= LudaXWrRe;
            LudaXWrRe /= LudaXWrRe;
            DxeaSTmnrkQPfi -= DxeaSTmnrkQPfi;
        }
    }

    if (DxeaSTmnrkQPfi > -1036148.7137416896) {
        for (int HFgOUj = 2041081838; HFgOUj > 0; HFgOUj--) {
            jRFuiGfEwRARXrf += jRFuiGfEwRARXrf;
        }
    }

    return DxeaSTmnrkQPfi;
}

void HQrFtNbqxk::gDOEnjpZt(int CKiNb, double cKydMbu)
{
    int ZIEqJNHRBEnCzTMI = 154640497;
    double YmVZaQYRXZ = 401615.0404350287;
    string wSgCzizhsHrkIVvC = string("wssFmWPDNreFULAQRyhhulguSaLetMLWsldrmmzALSxmyPPiGHQQUMiZnyxRRuMmRElMARWWmstBKIAPbVFsRhRTDZMUwWPxalIPfoRzDYxgDaViNrwjtgMmmGjzBoScuGXVwuONuWllgppfGQvCCUwwIIMeuGOWMpyJzGgFLueRCdD");

    for (int WGuKLNaL = 1425195752; WGuKLNaL > 0; WGuKLNaL--) {
        CKiNb *= CKiNb;
        YmVZaQYRXZ -= cKydMbu;
        YmVZaQYRXZ /= cKydMbu;
        cKydMbu -= cKydMbu;
    }
}

double HQrFtNbqxk::cvtNDGa(string rlkhB, int FGhEedlPaT, double KDCSMYUcjbZroZ, int WtZkKL)
{
    bool XbJdonyuenBQ = false;
    string HAsSHwqdYVd = string("nTWmDEZteprzcmMNMqJpdDVwsdPtQFIReoHFgABcQPgIhzyQriSZKPYtipRILXeHFmaAtMOeyiUysLcIhqyYYzInfKCsvbeDzGGBmugUgAYUaVWzdjUrmjVLhoFxXtSbIfnlQOYWLdLPYrizssbffPjHmxW");
    bool WwvnCakkLv = false;
    int vQZxdMk = 221630343;
    int FwrNSAazSMYK = 102175909;
    double aBIBAuO = -1019117.5570247527;
    int XjeeQvDPGrnyM = 528611132;
    double EaOYLHMU = 500683.76602452755;

    if (XjeeQvDPGrnyM > 102175909) {
        for (int WkpHMflYKAihy = 227022187; WkpHMflYKAihy > 0; WkpHMflYKAihy--) {
            FGhEedlPaT /= FwrNSAazSMYK;
            XbJdonyuenBQ = ! XbJdonyuenBQ;
            WwvnCakkLv = XbJdonyuenBQ;
            WtZkKL = FwrNSAazSMYK;
        }
    }

    return EaOYLHMU;
}

double HQrFtNbqxk::DPrlR(int GMzDbDqyRrBCHiz, string TcxftP)
{
    bool IqkQLpTuv = true;
    bool titXdn = false;
    string ALdNUilW = string("ATORBPdQGrZDakIWhRcPVyGvsSkruQDmYqQPGqjbBVuNzOhzHqrPEjDbaeUuETexxXJVfhtwnhTbvJfivygDlUPzznRnFJEVJboFTkOBJFgyKbHFYNIaspRiCTIkhjkchAYZ");
    int SvyhrgU = 468033049;
    string CdsKLxAtfHGK = string("OvyetNhJwdJmlTtHYnLtxWmTthuCAIePwdwsd");
    string BwkPqwHDNE = string("UYpZAYwrXrcxuqwEzAzoEvQRMNpJAuQvcEYSTBhMViQMiLUrLinqtIFJvlBizIWkTRgLVePxwFZiTWxj");
    bool MLjgONmzQ = false;
    int srVaKnPBWdHtM = -430562196;
    string QzeKtvNZOcqRksb = string("YYtoaRBhttFhjCXlAaoBCuWhYRdQTrbOCGoUKkRjFt");

    for (int ueULJZnXlLhTFUS = 2129519855; ueULJZnXlLhTFUS > 0; ueULJZnXlLhTFUS--) {
        MLjgONmzQ = ! IqkQLpTuv;
    }

    if (ALdNUilW <= string("OvyetNhJwdJmlTtHYnLtxWmTthuCAIePwdwsd")) {
        for (int kDInWH = 276119839; kDInWH > 0; kDInWH--) {
            MLjgONmzQ = ! MLjgONmzQ;
            BwkPqwHDNE = BwkPqwHDNE;
            ALdNUilW = QzeKtvNZOcqRksb;
            SvyhrgU = GMzDbDqyRrBCHiz;
        }
    }

    if (CdsKLxAtfHGK > string("YYtoaRBhttFhjCXlAaoBCuWhYRdQTrbOCGoUKkRjFt")) {
        for (int VGLMqVqixSZ = 1109069994; VGLMqVqixSZ > 0; VGLMqVqixSZ--) {
            MLjgONmzQ = titXdn;
            MLjgONmzQ = ! MLjgONmzQ;
        }
    }

    for (int JpJQNcyvbRNafvW = 974261353; JpJQNcyvbRNafvW > 0; JpJQNcyvbRNafvW--) {
        CdsKLxAtfHGK = CdsKLxAtfHGK;
        SvyhrgU -= GMzDbDqyRrBCHiz;
    }

    for (int DjmFSMgzH = 698997049; DjmFSMgzH > 0; DjmFSMgzH--) {
        QzeKtvNZOcqRksb += QzeKtvNZOcqRksb;
        TcxftP = QzeKtvNZOcqRksb;
        ALdNUilW = TcxftP;
    }

    for (int DSnOubwuPlc = 1366632407; DSnOubwuPlc > 0; DSnOubwuPlc--) {
        CdsKLxAtfHGK += CdsKLxAtfHGK;
        QzeKtvNZOcqRksb = BwkPqwHDNE;
    }

    return -843712.2032612376;
}

int HQrFtNbqxk::eipaR(string QsjAHyLxgAyOB, bool viObIqzp, bool BDLuWrjIfi, bool QChQjUwppNk, int xWZQKd)
{
    string ZcvKsbDDEtrPhBXQ = string("aPPLnDJNxAKUUxnSiuDXaLpOhhqBDqpZdqQJEaQLJLkIMNeGGLpOxBxAYjHQYkXfHOhQnESaSTNuizDClYQrcizVoEjg");
    string xSjkjCoXdDvAKVNK = string("DxJmGarIfFQqrCuJNWsNMdoHpJWnqjMswIsNbSAaGcnFVoFFLzTKFtIvJjVitsHMFQaOLKCluhRuskDsLngwhUyesSMRDesvRWZYTmNiwGUakLKUopyfWZrtMKEAecNWhYVXzDypVamgCAzGmLzmZgtzpVOBGzLbzoAyJyxtQomAQsswZobGTyJBgYgOUeNZIBpIhdQRrXnlEcCLhTpUlEyxHAYorwYhRgVSNK");
    int RCDpIkmlZx = -1598970519;
    string HNGOr = string("ATaMEgdbUQBvcgdzpMCVkkEVoUEjjDGgnhKKvZHozENsxxpfKhuLeNciiZYSdqgUBXJXpoKwgzBybbmHTmPirjecmoJDMPIPuTeCDGVvvUrgiEKkSpxvMkIbSpXdSxL");
    int KyhKIp = 120757533;
    double LdGIRPtdrkve = -316535.06893711945;
    int KlvPR = 2020322923;
    bool crommHmgAVTT = false;
    string sWmssrdBZHAw = string("WxgJMCEkGvdujEyTWbcOzfXLLx");
    bool BypSJDAXWH = false;

    for (int CBIeMTT = 345824474; CBIeMTT > 0; CBIeMTT--) {
        QChQjUwppNk = BDLuWrjIfi;
        QsjAHyLxgAyOB = QsjAHyLxgAyOB;
        ZcvKsbDDEtrPhBXQ += xSjkjCoXdDvAKVNK;
    }

    return KlvPR;
}

string HQrFtNbqxk::BVKDMsLWxUfMvrI(string MeCszgWPRZlhmJoL)
{
    double wrvWpNQ = -957667.1277377474;
    int GCEAgOlXchT = 1041319159;
    bool vTMJVJTUCbojkmEC = false;
    double MEglFCKoueq = -720691.3182892144;
    bool FFAiyUugnYbygAE = true;
    double sHxWdZVlSejuZTu = -771985.1313772646;

    for (int JfuktmpJsNRiwi = 731948996; JfuktmpJsNRiwi > 0; JfuktmpJsNRiwi--) {
        MeCszgWPRZlhmJoL += MeCszgWPRZlhmJoL;
        FFAiyUugnYbygAE = ! vTMJVJTUCbojkmEC;
        vTMJVJTUCbojkmEC = ! FFAiyUugnYbygAE;
    }

    for (int AiPylQVYFsxh = 290552733; AiPylQVYFsxh > 0; AiPylQVYFsxh--) {
        wrvWpNQ *= MEglFCKoueq;
        wrvWpNQ += wrvWpNQ;
        MEglFCKoueq /= sHxWdZVlSejuZTu;
    }

    if (sHxWdZVlSejuZTu > -957667.1277377474) {
        for (int DHhBFOBxrvswMsQe = 1322267477; DHhBFOBxrvswMsQe > 0; DHhBFOBxrvswMsQe--) {
            wrvWpNQ = sHxWdZVlSejuZTu;
        }
    }

    return MeCszgWPRZlhmJoL;
}

HQrFtNbqxk::HQrFtNbqxk()
{
    this->IsRtqkRPbSXgL(-26117.19633285957);
    this->cZaXmnrjcT();
    this->HBLIEXZYnO(-823526634, true);
    this->puvgqVAm(-983833.550140953, true, false, string("blBhHvVCRkxTslcBwLCximicvpvjlVoIWPxBQITqPhqckLCyZXitqDtzRqva"));
    this->ULWKtRrfu();
    this->eGKnz();
    this->bRNJzPcm(1611745605);
    this->gDOEnjpZt(255306742, 918283.0107522281);
    this->cvtNDGa(string("dZjwwVskKsDfnYJtZKzzIrAkmLuhcgTyoGdTmgzbjZdZiLiMCvdBhwNoldJyZFKFOLUQkHgtiMyNDaSWCQDnZRpMEEPPpGwlLwpHweZrRGuXAUBolPaKNBEtUvfuUNCaWXAHhJ"), -1198230568, 777830.3190531023, 781531957);
    this->DPrlR(-237994874, string("wvQxeEUasBNSOFxOsCIAaIQrPUBwBdOGgXsRTbnxmZrzMbbmjucTAVGUvUszzufaLCckiMRUKZohTGqxHyExZKhtEfngZmyYoocrTuwhWunVGcKuoxchzGVPjEtxKNOavbOQoKHZqGFptpECwSSnzGmjwuwNdKJkuawIhGICZIrjkVYDNcAMqCzilphtyOBMzHGZUlZHUbDWWSwWOScOqfuGbiudiibhJ"));
    this->eipaR(string("QwbemWWewELRIlBifKjGqCCspfwdCaVoiLIeSmPfHkDBlByvajbbBDVhHZZqiKTuuEHFsZzFomPkvXkncHTZRSeBYTYDlLonJIDFnLBFxTenKEhEEjbVjJIBxPFEJZGlNLKnwFqecKBVbiMVAdqEphoOmAwUMQEsNCTHNwivSuClCZhgsJpeXUAOijvlzwJERdEgdvhoKcjCrDmgOF"), true, false, true, 1816761031);
    this->BVKDMsLWxUfMvrI(string("ykoUgSMGpEtnKoyGXWXJtSGGfxIBSaZHPchnpZItEneesksZrAidyEcYdBRIRAMMpzOFuGuLWnPLopgnqVYdloqgexrEoubAWVZyfCiiznOsHtSPLXWlfWLTufAXLdnZSjZeOTZGiWdHvSKXSxtZFWuFeJIeXokuqEnRPGHHUQItvOotOHsUuateIRIDcodqYlsRLxnRKuSQFCMSHXiWNNupBYxIXPOlHafxBSqQCGTBdQHjMXNynWPEzpOplK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FKwrbxcYFrovsIJ
{
public:
    bool jBrFtAUEs;
    double odguFjCMq;
    int wTMOLGf;

    FKwrbxcYFrovsIJ();
    string jsSZzadrmBfqNoQ(bool PzdhnkNhAe, string wIMwzlkAMEVMOYz, string qgHFS);
    double CBWyu(string crfNGsBlPAl, double FghBxbpWHFQgdz, int aVtQFOkTarLCh, string eabyZQAIX, bool CTzvlNwjtddnc);
    string JfuoyaLQcXWihY(bool xBaRfIlOGWECGe);
    int ZyAisHho(int RkdVTPmriC, string YVfxFIXyPpRcho, bool ZTyzu);
    int VQYrXArWqckhBl();
    double WqNbFDUJr(int lxzxIlklakBDJ, bool IHhzXBllbJh, double rYDObPUnjmmANZUd, int nHHAjqgnunVrpuRB);
    string NDiMXVV();
protected:
    double EFENC;
    double xeoDFqkdmOH;

    void TEQoLXYeugK();
private:
    double KqFzKWSmzGcQFMXc;

    string BKpAUATAVWe(string OaRQH, bool oGAOpZtCqo);
    double dFxBZZNEUtCjziJ(string TUllTXnM, double ZhpWKQtaSHKsZbY);
    bool melKkDtG(double WegMXPJTStfOua, string ufzsVimbbqFU, int XfPmNsHGeArTaFQn, bool XEbnhfHb, double AleZIywvTLIgzu);
    double AtpHrGijfeUjo(double uOirq, bool PDaAhruMhLgUhEKc, double qnWhnoO, string gPKkAD);
    void mvkWh();
};

string FKwrbxcYFrovsIJ::jsSZzadrmBfqNoQ(bool PzdhnkNhAe, string wIMwzlkAMEVMOYz, string qgHFS)
{
    bool TodQLycTHALV = false;
    int WmsCxgLI = 1019962732;
    int rJqMsmrHie = -565099912;
    int hDDalMLzyr = 1510510860;
    int hXFAQ = 875885453;
    string BOesDJLvxNfJONVW = string("AYOvBEQxPviPZjgzNVTZfMpvgoJGDDfgpZAHoKVetqbEhdStqPqNTXJWyFGcBxuBpIyjxIcfhJexvgJqUfzEWfbfrxCuNvYqYGstEcHjRAAoewXKRxHjhVfGXeJTUGHrjHkFISpHlTIdVwjrlGTQyUlqIDNJeYmLAQhe");
    int cLIcLBHBCsxzaTkY = -521210986;

    if (rJqMsmrHie < 1510510860) {
        for (int AFwlwcExaswHeIP = 1577057523; AFwlwcExaswHeIP > 0; AFwlwcExaswHeIP--) {
            qgHFS = wIMwzlkAMEVMOYz;
            hXFAQ = hXFAQ;
            rJqMsmrHie = hDDalMLzyr;
            qgHFS = BOesDJLvxNfJONVW;
            BOesDJLvxNfJONVW = wIMwzlkAMEVMOYz;
            WmsCxgLI -= rJqMsmrHie;
        }
    }

    for (int tlNWxqMlor = 409081200; tlNWxqMlor > 0; tlNWxqMlor--) {
        hXFAQ /= WmsCxgLI;
    }

    for (int DsFvuQnCcy = 125297749; DsFvuQnCcy > 0; DsFvuQnCcy--) {
        hXFAQ += hXFAQ;
        rJqMsmrHie = hDDalMLzyr;
    }

    for (int wikYJnaOFdxLOwzg = 1651512373; wikYJnaOFdxLOwzg > 0; wikYJnaOFdxLOwzg--) {
        hXFAQ = cLIcLBHBCsxzaTkY;
    }

    return BOesDJLvxNfJONVW;
}

double FKwrbxcYFrovsIJ::CBWyu(string crfNGsBlPAl, double FghBxbpWHFQgdz, int aVtQFOkTarLCh, string eabyZQAIX, bool CTzvlNwjtddnc)
{
    int flNEpxfxguSvtN = 2102191623;
    double zQvtUVMoXCTfjynJ = -451629.84141030954;
    bool SqYkcPvaRD = false;
    string hedIFz = string("cmjYKHYVVnZNbAkEGZmlwRKQCbvfxxFfGjeOFqDuJyrcvbGgopjbLMrTLUigxRNVBYQEHfgJtRIGMUwFBCtXwEZvJenUFZrNoihSatkbEZbSzEomsHYNzafRJuUIhZfMhlLUUPcfFVOxdWYPDdhqwzXsDsTULRxaeTvNSc");
    bool gFdeMvIhZqEs = true;

    for (int KrfnQCyuacHWx = 1402516160; KrfnQCyuacHWx > 0; KrfnQCyuacHWx--) {
        continue;
    }

    for (int TlXttCUcigyA = 772991868; TlXttCUcigyA > 0; TlXttCUcigyA--) {
        flNEpxfxguSvtN -= flNEpxfxguSvtN;
        flNEpxfxguSvtN = aVtQFOkTarLCh;
        zQvtUVMoXCTfjynJ = FghBxbpWHFQgdz;
        gFdeMvIhZqEs = CTzvlNwjtddnc;
    }

    for (int LUFlhsHNiBp = 1722660392; LUFlhsHNiBp > 0; LUFlhsHNiBp--) {
        hedIFz = hedIFz;
    }

    return zQvtUVMoXCTfjynJ;
}

string FKwrbxcYFrovsIJ::JfuoyaLQcXWihY(bool xBaRfIlOGWECGe)
{
    bool sutBRsuJlVNHWVDR = false;
    int jsxbRUgfTJxSGsz = -1318715470;
    int qrMyHV = -541229732;
    int rOoUHU = 1450238672;
    bool GnvbkOnSDaOmGmOp = true;
    bool qvXHclgOfiCSVO = true;
    int wAqiYVfhjoUrhPM = -1408635514;
    string VTHgQMCJrW = string("JpXfmgGLsXHjqEzHXpCwMeMsFOgdAflugNEmzxrgkcJOcfyTzqjmgIyxgtQtbIGLCjwMPwOqtbmjZfCyxtDEZypCdGgxmYXweGJe");
    string huQsXlFhXQ = string("oloMRLLRDnQgpBWSrXPGBgiREoojMcZ");
    double UWLZOqKYlDfV = -20277.957872343108;

    for (int NfuCoCSyxY = 2056196564; NfuCoCSyxY > 0; NfuCoCSyxY--) {
        GnvbkOnSDaOmGmOp = ! GnvbkOnSDaOmGmOp;
    }

    for (int pfTAYFgqNskgg = 1239812414; pfTAYFgqNskgg > 0; pfTAYFgqNskgg--) {
        GnvbkOnSDaOmGmOp = qvXHclgOfiCSVO;
        qrMyHV *= wAqiYVfhjoUrhPM;
    }

    if (jsxbRUgfTJxSGsz > -1318715470) {
        for (int XFoKDwXnDMxVVVKY = 2143920188; XFoKDwXnDMxVVVKY > 0; XFoKDwXnDMxVVVKY--) {
            continue;
        }
    }

    if (sutBRsuJlVNHWVDR != false) {
        for (int BLhBSwMTaydEi = 1851055751; BLhBSwMTaydEi > 0; BLhBSwMTaydEi--) {
            continue;
        }
    }

    return huQsXlFhXQ;
}

int FKwrbxcYFrovsIJ::ZyAisHho(int RkdVTPmriC, string YVfxFIXyPpRcho, bool ZTyzu)
{
    string lYgViTrMhVNCxv = string("zcdifUOjADoPoiDHjUtxJsmXmLblLnOgAGRwfieRJPW");
    double TlkVH = 740137.7544525455;
    double lFeIC = 504827.96299142006;
    int gOdcd = -1370839357;
    int IJOMoqYcREJxDgOC = -1144911304;
    int RROnmzzhBeQwIQi = 438964359;
    int EkKIWPyK = -574109875;
    int NMRbWJqZa = -1179621926;

    if (RkdVTPmriC > -1370839357) {
        for (int tEVfjzFuEm = 330997686; tEVfjzFuEm > 0; tEVfjzFuEm--) {
            RROnmzzhBeQwIQi += EkKIWPyK;
            RROnmzzhBeQwIQi /= RkdVTPmriC;
        }
    }

    if (TlkVH > 740137.7544525455) {
        for (int WcbgRd = 617906072; WcbgRd > 0; WcbgRd--) {
            RROnmzzhBeQwIQi = NMRbWJqZa;
        }
    }

    return NMRbWJqZa;
}

int FKwrbxcYFrovsIJ::VQYrXArWqckhBl()
{
    int qFFuZc = 558959317;
    string ikIhql = string("InfTsztHecJvisxiGZcsVREWdHaGrQZtxCybggubCBHGKKyKwitvdatLbhAtFeCwVQjSjGGLhHLgZYDKebfbwxCfSJTQebKcsLLsaEnXNHOyWZhtihrzIWbAYvgocYeCIGKnSLeBdyargNzblnGZLaMTKyKmsHdVlWGDxEHFZKbYNISsMrhrSsXIJjxlzTmDentFowRKzSpBxvfzJOmjtnNClujLtiDnqbMJcwefDZsK");
    bool NLPWzSLiL = true;
    double iHSFRjoeK = -530246.4370737594;
    string wHYiqOHxqMu = string("FHuEZnzlnoxYJgdiwuHQxOjoMMnMRAoMHTJPkgrEtIhxAqLXkqAUlQnmlHKGboqGeGuwNApJHNtLLwMvOEhYpFIuHNtCOgDJCuNmxFLmZkwdXVgYerWo");

    for (int etTMFEMOriPODYn = 582275921; etTMFEMOriPODYn > 0; etTMFEMOriPODYn--) {
        NLPWzSLiL = NLPWzSLiL;
        NLPWzSLiL = ! NLPWzSLiL;
        ikIhql += ikIhql;
    }

    if (ikIhql <= string("FHuEZnzlnoxYJgdiwuHQxOjoMMnMRAoMHTJPkgrEtIhxAqLXkqAUlQnmlHKGboqGeGuwNApJHNtLLwMvOEhYpFIuHNtCOgDJCuNmxFLmZkwdXVgYerWo")) {
        for (int WHTHfXACyQrpcKd = 1904592780; WHTHfXACyQrpcKd > 0; WHTHfXACyQrpcKd--) {
            continue;
        }
    }

    for (int xpbgteMFNMvVzEsL = 357942464; xpbgteMFNMvVzEsL > 0; xpbgteMFNMvVzEsL--) {
        wHYiqOHxqMu += wHYiqOHxqMu;
        qFFuZc *= qFFuZc;
        iHSFRjoeK = iHSFRjoeK;
        ikIhql = ikIhql;
    }

    return qFFuZc;
}

double FKwrbxcYFrovsIJ::WqNbFDUJr(int lxzxIlklakBDJ, bool IHhzXBllbJh, double rYDObPUnjmmANZUd, int nHHAjqgnunVrpuRB)
{
    double VWfnPJjNIVqy = -1027850.1672795612;
    string hsvkBcMAOuwuRiSc = string("tsRCeJIhDbysTJiEYPERcWgBzkUUpZbCVhAeIjeGWAEhNATibPHRyJpcwjQHMgaauJEIMMCZTOdFklrsOMPdZMdMhYtPYJoyBpaHLIZamwwpgvainHIQyGuiluZsUGBusEaURMJaASdfHWRAYCmEBiyOWTwUEmBHVZqYtXcwOskedDTML");
    bool dBWiNwftW = false;
    int UIhjblILykQusaH = -274968196;
    bool bSrMJaKaQsP = true;

    if (lxzxIlklakBDJ != 1590790502) {
        for (int QaETsibgCXcvSV = 189351949; QaETsibgCXcvSV > 0; QaETsibgCXcvSV--) {
            UIhjblILykQusaH -= lxzxIlklakBDJ;
            lxzxIlklakBDJ -= nHHAjqgnunVrpuRB;
        }
    }

    if (bSrMJaKaQsP != false) {
        for (int ZneHMts = 2078619131; ZneHMts > 0; ZneHMts--) {
            nHHAjqgnunVrpuRB -= UIhjblILykQusaH;
            IHhzXBllbJh = ! IHhzXBllbJh;
            dBWiNwftW = IHhzXBllbJh;
        }
    }

    for (int rvLEQyVnFKq = 2039773139; rvLEQyVnFKq > 0; rvLEQyVnFKq--) {
        nHHAjqgnunVrpuRB = lxzxIlklakBDJ;
        nHHAjqgnunVrpuRB += UIhjblILykQusaH;
    }

    for (int MFnBBRVfQueRxrd = 416045236; MFnBBRVfQueRxrd > 0; MFnBBRVfQueRxrd--) {
        IHhzXBllbJh = IHhzXBllbJh;
    }

    if (bSrMJaKaQsP == true) {
        for (int sRFcHw = 1378424829; sRFcHw > 0; sRFcHw--) {
            dBWiNwftW = ! IHhzXBllbJh;
        }
    }

    for (int HzsTrOotgEPCwH = 18752141; HzsTrOotgEPCwH > 0; HzsTrOotgEPCwH--) {
        VWfnPJjNIVqy += rYDObPUnjmmANZUd;
        VWfnPJjNIVqy *= VWfnPJjNIVqy;
        VWfnPJjNIVqy = rYDObPUnjmmANZUd;
        IHhzXBllbJh = bSrMJaKaQsP;
        dBWiNwftW = dBWiNwftW;
    }

    for (int pbAbydccBAgZv = 736157549; pbAbydccBAgZv > 0; pbAbydccBAgZv--) {
        continue;
    }

    return VWfnPJjNIVqy;
}

string FKwrbxcYFrovsIJ::NDiMXVV()
{
    bool DesjvuIkpGEyRn = false;
    bool GHkewtjUiDYm = true;
    int IqKvIIowqhNohW = 349915380;
    int XzhxTcMna = 550181131;
    int DSzMK = 1491543290;
    bool QgBIQSNnuOaLGgKj = true;
    int lgbIIcEXgW = 2056721371;

    if (QgBIQSNnuOaLGgKj != false) {
        for (int ioOlkdcmOJU = 358418053; ioOlkdcmOJU > 0; ioOlkdcmOJU--) {
            lgbIIcEXgW += lgbIIcEXgW;
            lgbIIcEXgW /= IqKvIIowqhNohW;
        }
    }

    return string("gevDkLHmLJYKKmHvjGXlWhxL");
}

void FKwrbxcYFrovsIJ::TEQoLXYeugK()
{
    double zFGKfEc = -301493.72272357997;
    int RCUJZjJyKFwuSu = -1184686857;
    bool kHAzeoCRLzspK = false;
    double wSayCpohF = -214148.55527844254;
    string TVPwMrrRqe = string("nGMNPIYLkryqVuqhiUHfMgZQZpoSPtKVCUtFLZmdXedDiEigAqxdSBujNPczCBLMISqeXuoyjugCZdIHZpImuBEOPDGOrPJfcMOndtKqrbGodGWgrmIfGgtWMPuLDMAwlgeGVmFiLdsUSnyqVWcGCA");
    bool fYDpxsGIpeOo = true;
    bool dEaGApPDMCqBui = true;
    double oCWITeVdKusx = 25844.807581932815;
    double CrcfSlXvPJr = 846758.082143325;

    for (int BFWZBjijTxkfNGus = 593466094; BFWZBjijTxkfNGus > 0; BFWZBjijTxkfNGus--) {
        zFGKfEc -= oCWITeVdKusx;
        RCUJZjJyKFwuSu = RCUJZjJyKFwuSu;
    }
}

string FKwrbxcYFrovsIJ::BKpAUATAVWe(string OaRQH, bool oGAOpZtCqo)
{
    int BscnGzkkQ = 844953227;
    int sblmHLNdWu = -492214784;
    int xElafycKKRqqfihR = -739349990;
    bool ZVqLFMc = true;
    string rYctbjyUj = string("ZPlOSZqoqsFgNWQFrLtQjaQJybvlhJnEfnInnnqLsUEeBYZNAAdkDeDLjhAuRmqotbeeTKUQEoYSBKNrmUfpcEZSPwWflLmqbLgLlPhdYnzEQFLyEMYVPjVIsPDnEiNNSgBTdaMYoFPVjhYNACVaSeanRHUkQqVfAirMFttyIrXDaxXAiPiClBzavTePciUEIXlYgZUTJkFBryZn");
    bool GLsvLpfOtRoZPDhc = true;

    return rYctbjyUj;
}

double FKwrbxcYFrovsIJ::dFxBZZNEUtCjziJ(string TUllTXnM, double ZhpWKQtaSHKsZbY)
{
    double cpvsWLCA = -624923.1440104675;
    bool rJBMzQrEBxN = false;
    bool lwIdOjptUNaTXPO = true;
    bool RlRmQ = true;
    string tlnIaRkVdSABeaY = string("REBSMLPHIGZHAikZVJYHtZLoGpXwaMWSMjZvfUrORVP");
    bool RxyunVdldZpqrFF = false;
    double IPwjfzSp = 125210.14932616214;
    double forRZpUmAwEKGkoG = 122843.5371925546;
    double hxUwBJzm = -198015.5696225228;

    for (int PwWGgJx = 830913260; PwWGgJx > 0; PwWGgJx--) {
        forRZpUmAwEKGkoG += forRZpUmAwEKGkoG;
        RlRmQ = ! lwIdOjptUNaTXPO;
        forRZpUmAwEKGkoG = hxUwBJzm;
        rJBMzQrEBxN = rJBMzQrEBxN;
    }

    for (int odXMFVZESqpgR = 1371453865; odXMFVZESqpgR > 0; odXMFVZESqpgR--) {
        cpvsWLCA /= cpvsWLCA;
        ZhpWKQtaSHKsZbY /= forRZpUmAwEKGkoG;
    }

    if (IPwjfzSp <= -624923.1440104675) {
        for (int AagXREWVAJ = 2006272432; AagXREWVAJ > 0; AagXREWVAJ--) {
            RlRmQ = ! RlRmQ;
            rJBMzQrEBxN = RxyunVdldZpqrFF;
            ZhpWKQtaSHKsZbY = hxUwBJzm;
            cpvsWLCA -= IPwjfzSp;
            lwIdOjptUNaTXPO = ! RxyunVdldZpqrFF;
        }
    }

    return hxUwBJzm;
}

bool FKwrbxcYFrovsIJ::melKkDtG(double WegMXPJTStfOua, string ufzsVimbbqFU, int XfPmNsHGeArTaFQn, bool XEbnhfHb, double AleZIywvTLIgzu)
{
    bool UBFlQeClYQReItoP = true;
    int xKcrdcBlOJoOFup = 1202807910;
    string cNeDF = string("bIYihBwGzWVDyVXETRdGFSwuDFmkrlvGVtYPayiBIWULwCHPfocqpbnSgmukHhEacRBVZhUxkoDkWRDuVxyDsFxYYXHuHDBVdrsZOLjIZpeJlYvpQLhNfqDXmBjuLKRvMKHgDaUyMfJPSKajaJoOVxBCNiTXkoMtpGtBWkhcLDwfqyHJbqEiNHL");
    bool cosMWxq = false;
    bool FLNXBy = true;
    bool WXFSZuAuFjwkIPgw = true;
    int akATOqOZzGCNaxGE = 602982916;
    bool yLuncDwioKtdV = false;
    double tNYbDGYi = -1039366.6681820792;
    bool hnLpmNYwBfwTfggo = true;

    if (akATOqOZzGCNaxGE <= 602982916) {
        for (int ySDSAPlYzAKCijP = 207897528; ySDSAPlYzAKCijP > 0; ySDSAPlYzAKCijP--) {
            UBFlQeClYQReItoP = WXFSZuAuFjwkIPgw;
        }
    }

    for (int ZdaytV = 1042349728; ZdaytV > 0; ZdaytV--) {
        continue;
    }

    if (hnLpmNYwBfwTfggo == false) {
        for (int DFpZBPnZlai = 383814503; DFpZBPnZlai > 0; DFpZBPnZlai--) {
            xKcrdcBlOJoOFup /= akATOqOZzGCNaxGE;
            WXFSZuAuFjwkIPgw = ! yLuncDwioKtdV;
        }
    }

    return hnLpmNYwBfwTfggo;
}

double FKwrbxcYFrovsIJ::AtpHrGijfeUjo(double uOirq, bool PDaAhruMhLgUhEKc, double qnWhnoO, string gPKkAD)
{
    double jsECmjjkE = -19787.45924259841;
    int rNsqLsGZpc = 1826776380;
    int YTDASLnlNhCU = -411793024;
    bool UublJRfD = true;
    double sNEMwovsEMS = -950287.7351218696;
    bool vACFPnOTZSS = true;
    string WhpPd = string("zPLGtJekNSfFcWOfwJzWwhzohHOeOyp");
    double zmZdvLHDGByIkKKg = -407034.63322305115;

    if (YTDASLnlNhCU < -411793024) {
        for (int hSgpAs = 1251242351; hSgpAs > 0; hSgpAs--) {
            continue;
        }
    }

    return zmZdvLHDGByIkKKg;
}

void FKwrbxcYFrovsIJ::mvkWh()
{
    double QbFctUWq = -566172.7225496349;
    double ZAhNRWxOBbZTF = 479828.8363565562;
    bool cfpcRONQTDhxr = false;
    bool vhFYMosgHjaB = true;
    bool cUtTMdSRZZYYBEh = true;
    int GAEXGrD = 304926657;

    for (int qzlmaeYksHybjhJ = 1693857995; qzlmaeYksHybjhJ > 0; qzlmaeYksHybjhJ--) {
        cfpcRONQTDhxr = cUtTMdSRZZYYBEh;
        cUtTMdSRZZYYBEh = ! cfpcRONQTDhxr;
        cUtTMdSRZZYYBEh = cfpcRONQTDhxr;
        ZAhNRWxOBbZTF *= QbFctUWq;
        cfpcRONQTDhxr = ! cUtTMdSRZZYYBEh;
    }

    for (int yrWbdn = 39545049; yrWbdn > 0; yrWbdn--) {
        cfpcRONQTDhxr = ! cfpcRONQTDhxr;
        cUtTMdSRZZYYBEh = cUtTMdSRZZYYBEh;
        GAEXGrD /= GAEXGrD;
    }

    for (int HJLsOpOaLtKUgc = 29765916; HJLsOpOaLtKUgc > 0; HJLsOpOaLtKUgc--) {
        cUtTMdSRZZYYBEh = vhFYMosgHjaB;
    }

    if (vhFYMosgHjaB == false) {
        for (int xepUl = 1644833834; xepUl > 0; xepUl--) {
            vhFYMosgHjaB = ! cfpcRONQTDhxr;
            vhFYMosgHjaB = ! cfpcRONQTDhxr;
        }
    }
}

FKwrbxcYFrovsIJ::FKwrbxcYFrovsIJ()
{
    this->jsSZzadrmBfqNoQ(false, string("icKbQpexxOyoqVVcAHjLfDdunIgPoWNFzpwUgOlDiFvbEFCiQxUWfZZmRNiZXRKQnaeyAoBLobTBnhBCSMPjvFbUMxIVgcYXATBFUVPtyJlLnXklfSKrLSXNDnnlYQoRkhWBFtiPTNrBKZykMjcirNtfBKVVsJocyltPKwySvEGgmoGGtKlheP"), string("ahbwrUkVtRgavbOvZoUIOhwXDIXRlzQljLudkVbRVRcOeJqbtvFdrUIhZuYNPJfqTUlqRFVMeebcwqLEbVkxjbHyjQMSmENvtzFILQSQYPfFBsvhWylkAiBQYAyfBEykqNjNEqOKgFVRcHKWXAImROQLXRUPpSnScogZVGZlvqiseD"));
    this->CBWyu(string("RlEsEdkpCqwMBHxBmYWwHalXCvefVkNHtgxfbgGeJZLmTLLEpWBpQhiDyaCRxzGkrYuahEZbJCDqgpwovmXEwFVySxuoVZEXWRINlkjuXPxDcwCIJkjfZyPUjShIENAGMgKUsOePIQqjYGrjRjwUyUgosKKJhAIwToOKdmIb"), -13187.508361631188, -245460179, string("nKDTjCcwzMHndTkyktlrRjasrizTCUEurLIGmJmHwzvYoJxyuNObRvSzBtQsVPlDgGBPwkZEmPzJXLqbYmIopFSPOkkIdFDRBwpoHahnuwvDkBlijCLGcDKdXeJhwB"), false);
    this->JfuoyaLQcXWihY(false);
    this->ZyAisHho(-822148681, string("SiDYOYDoBIbsxTSAsRavWbHuduuuAOzaJZhGcedIEubrBHllleGExtliZwpkfYQppmKFQIMBuQuasRy"), false);
    this->VQYrXArWqckhBl();
    this->WqNbFDUJr(1590790502, false, 337750.05537086626, 806835180);
    this->NDiMXVV();
    this->TEQoLXYeugK();
    this->BKpAUATAVWe(string("ryFGRdCMAFYLQsGHvl"), false);
    this->dFxBZZNEUtCjziJ(string("KPiMzaXJdyJaNvKxrZMrTLFTHKMPmefleAjkmxEMNQlbCKimeUAJIfppzIhWKHdNXHzhyjOFFEaVHmgMUgbcnfWFlmgkKrGPXhanwdlUzJlDNuNQQIBSIzNSXsXXSzDAjHHhshzyXBPLOAdPKfAGqWJDRpaZinrGtvxuejEtcXDxFUTUAhvIcvHpdTnmXTEHwlLdjo"), 592196.4700990712);
    this->melKkDtG(-136385.40882634703, string("lINKBfQxAFNqdMTYygkmtsEMWly"), -256752887, false, 742994.2740188673);
    this->AtpHrGijfeUjo(-754357.6848995322, true, -105373.66799220993, string("IMCUHljjdonsAauxbtWxzIDSCXLKGCnhIpYEBLJKdNKVArMOLfxHuywUmX"));
    this->mvkWh();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tOUuIx
{
public:
    double FjgkYI;
    bool gzSrFTc;
    double JutNjedLDtaM;

    tOUuIx();
protected:
    string tGFLr;
    double NwqOzpMzeaquJFiS;
    string vKRIRVjXF;
    int dhXwDtAgD;
    int oLIXoZPhd;
    int QjHFRXEKAUSnaWJb;

private:
    double ppvAdGo;
    bool OihyZ;
    int xFXkYPwy;
    string GtEaLlDaoc;
    double BJqgWRxtagMl;
    double ukybJVuKEphR;

    double zeLbYbbUrIle(double mDRooMaHQwPaYh, bool BVITcCPF, double QthBGLBcrbdrgyy, string IsughfXW, double llBpVE);
};

double tOUuIx::zeLbYbbUrIle(double mDRooMaHQwPaYh, bool BVITcCPF, double QthBGLBcrbdrgyy, string IsughfXW, double llBpVE)
{
    string CLgttEwkcTvShBz = string("ccS");
    double KwBmlAsVONY = 200290.43099121022;
    double JMnZCObnpoog = 555107.1781514991;
    int cxQUBTJEUexu = 2014481495;
    int LskXIfmiHWLJGiiE = 916395303;
    int XNTFiuicQJy = -761266311;
    bool LVcffqVGgqK = false;

    for (int PnskwX = 183480590; PnskwX > 0; PnskwX--) {
        continue;
    }

    if (KwBmlAsVONY >= -218456.93935544812) {
        for (int NqZwHrldZWjez = 927015526; NqZwHrldZWjez > 0; NqZwHrldZWjez--) {
            continue;
        }
    }

    return JMnZCObnpoog;
}

tOUuIx::tOUuIx()
{
    this->zeLbYbbUrIle(-218456.93935544812, true, 54104.4469870493, string("FIDUOQoxfmAGxShnhgKvrWWeNUuYSQFJVtgIBNWFhGhpmwPIzUlzHPdXICTwAgRL"), 179959.37573697892);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KhFFOwz
{
public:
    int zoiDcjLrPnNrQoB;
    string FFXdegTgypJ;
    double IFiFwXjmv;
    double WefGhFc;
    bool GZoxTacwxTI;

    KhFFOwz();
    void JZSsFigLz();
protected:
    string kPiha;
    double DqlHJbwBPZOHt;
    double KlIchTxTRnPV;
    int TpeRamtdmFXb;

    int GnoBMOZ(double AtTRqfsRUUv, string dsIepy, bool BZgbnAwYwd, bool FwTLDMFfxpBC, int dSixoVLkkdO);
private:
    int OkmGwg;
    bool kliTkEGQKdqhbCl;
    string JrQEEDsMKfOMhxq;
    string sZAnQpyisyF;

    void KDScn(bool lYHgWojGWjGnvFa, bool iRfeqkGaI, int txtLjByAIBpUN, string gGXHrkGBsEYmJirL);
    double CSoLshWFvvWT(string FxggwdOIUUILDvwW, int YOwvEbESGruICq);
    double wVfbzlkBUXIbYHlM(bool gEhOqslcv, int vIPZXPM, string KaLbWaPVTRkATNU, double BFglMjuGHG);
    string QYaNpkryO(string EftkNDXSpdBbsW, int vDiyJd, bool JRIlRDUijINi);
    int QgUSYYnjHcSZhDHB(string gqimXriXM);
    bool EcuEb(double ArOwfpdcX);
    double WGteaViAsjSF(double WpSYJIwiivDvOS, bool QkmmzMroPq, bool ZwYTOtYnjKlbyq, double cnBmbhvil);
};

void KhFFOwz::JZSsFigLz()
{
    int LfWeDvdND = 455630712;

    if (LfWeDvdND > 455630712) {
        for (int CEncBpfxTlISmHIh = 1617845822; CEncBpfxTlISmHIh > 0; CEncBpfxTlISmHIh--) {
            LfWeDvdND /= LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND += LfWeDvdND;
            LfWeDvdND += LfWeDvdND;
        }
    }

    if (LfWeDvdND == 455630712) {
        for (int yTxsty = 792271587; yTxsty > 0; yTxsty--) {
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND += LfWeDvdND;
            LfWeDvdND -= LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND -= LfWeDvdND;
            LfWeDvdND /= LfWeDvdND;
            LfWeDvdND *= LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
        }
    }

    if (LfWeDvdND != 455630712) {
        for (int KgfNfWYmlagAvf = 789915356; KgfNfWYmlagAvf > 0; KgfNfWYmlagAvf--) {
            LfWeDvdND -= LfWeDvdND;
            LfWeDvdND += LfWeDvdND;
        }
    }

    if (LfWeDvdND <= 455630712) {
        for (int FGZmKuMckWje = 1365026539; FGZmKuMckWje > 0; FGZmKuMckWje--) {
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND *= LfWeDvdND;
            LfWeDvdND += LfWeDvdND;
            LfWeDvdND *= LfWeDvdND;
        }
    }

    if (LfWeDvdND < 455630712) {
        for (int bmAQOAz = 1530166944; bmAQOAz > 0; bmAQOAz--) {
            LfWeDvdND *= LfWeDvdND;
            LfWeDvdND /= LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND += LfWeDvdND;
            LfWeDvdND -= LfWeDvdND;
            LfWeDvdND = LfWeDvdND;
            LfWeDvdND *= LfWeDvdND;
            LfWeDvdND += LfWeDvdND;
        }
    }
}

int KhFFOwz::GnoBMOZ(double AtTRqfsRUUv, string dsIepy, bool BZgbnAwYwd, bool FwTLDMFfxpBC, int dSixoVLkkdO)
{
    double qLVygmgIEFFhaUc = -266744.3666781658;
    double sTTUSxQdPAMoIHMQ = -953063.3941235014;
    string XIkgx = string("myAoXalMyvgrmJcpetDmGlzJNnqDCdQqXzgaHKCBsWCwNpiKcfoQIUhyAYpcYLaifL");
    string DZneh = string("aYhGxfOwwkYXzjuPUcjtylUFBNzZCQPzfrJIhlZZVGTiOmIevOCvIPWmlfzMDRhkJmIQuXvgsySoJIhDIlthjYClxdfRRiKdqIaZiMVzoKEazlhQsXVHzJajEdzUfRgruJDFNnWNIoWIdb");
    double pNjDNtAdObIwVCNJ = 111289.07544762513;
    double kUxTSWPuGN = -475971.3215955939;
    bool cMIgrBUGCsrPJZ = true;

    if (sTTUSxQdPAMoIHMQ <= -475971.3215955939) {
        for (int LLevpYRZrrMCI = 765551401; LLevpYRZrrMCI > 0; LLevpYRZrrMCI--) {
            XIkgx = XIkgx;
            cMIgrBUGCsrPJZ = ! FwTLDMFfxpBC;
            DZneh += DZneh;
            AtTRqfsRUUv /= pNjDNtAdObIwVCNJ;
        }
    }

    for (int VTRNc = 1316437922; VTRNc > 0; VTRNc--) {
        AtTRqfsRUUv /= AtTRqfsRUUv;
        kUxTSWPuGN = sTTUSxQdPAMoIHMQ;
    }

    for (int QvYVgzIHjXEAM = 1224223999; QvYVgzIHjXEAM > 0; QvYVgzIHjXEAM--) {
        AtTRqfsRUUv -= pNjDNtAdObIwVCNJ;
    }

    for (int PKZGETeCYi = 1168342035; PKZGETeCYi > 0; PKZGETeCYi--) {
        AtTRqfsRUUv = AtTRqfsRUUv;
        AtTRqfsRUUv += kUxTSWPuGN;
        cMIgrBUGCsrPJZ = BZgbnAwYwd;
        pNjDNtAdObIwVCNJ = kUxTSWPuGN;
    }

    for (int NIWjnEYzdFzFZ = 1708090043; NIWjnEYzdFzFZ > 0; NIWjnEYzdFzFZ--) {
        continue;
    }

    for (int uDcRuMwnseZ = 814308636; uDcRuMwnseZ > 0; uDcRuMwnseZ--) {
        sTTUSxQdPAMoIHMQ *= AtTRqfsRUUv;
    }

    if (sTTUSxQdPAMoIHMQ < -475971.3215955939) {
        for (int VqJHBC = 1725384298; VqJHBC > 0; VqJHBC--) {
            sTTUSxQdPAMoIHMQ -= AtTRqfsRUUv;
            kUxTSWPuGN /= kUxTSWPuGN;
        }
    }

    return dSixoVLkkdO;
}

void KhFFOwz::KDScn(bool lYHgWojGWjGnvFa, bool iRfeqkGaI, int txtLjByAIBpUN, string gGXHrkGBsEYmJirL)
{
    bool ueIEkpBtSB = false;
    int jGLysmYgRNPPzeK = 142115030;
    double wzKOqXg = 205128.70579665934;
    bool TkBYAlG = true;
    double ufnDGOja = -705108.3470264489;
    bool dGatt = true;

    if (wzKOqXg != -705108.3470264489) {
        for (int eRMXaaULPRmtobi = 618102572; eRMXaaULPRmtobi > 0; eRMXaaULPRmtobi--) {
            ufnDGOja -= wzKOqXg;
            TkBYAlG = ueIEkpBtSB;
        }
    }

    for (int viVQBsvwyB = 1737147656; viVQBsvwyB > 0; viVQBsvwyB--) {
        continue;
    }

    for (int EmbLWlxftEN = 1920835398; EmbLWlxftEN > 0; EmbLWlxftEN--) {
        wzKOqXg *= ufnDGOja;
        TkBYAlG = ! ueIEkpBtSB;
        lYHgWojGWjGnvFa = lYHgWojGWjGnvFa;
        TkBYAlG = ueIEkpBtSB;
    }

    if (iRfeqkGaI == false) {
        for (int uTLNHHHOIcnqQxwf = 731562408; uTLNHHHOIcnqQxwf > 0; uTLNHHHOIcnqQxwf--) {
            iRfeqkGaI = lYHgWojGWjGnvFa;
            dGatt = ! ueIEkpBtSB;
            lYHgWojGWjGnvFa = ! ueIEkpBtSB;
            TkBYAlG = ueIEkpBtSB;
        }
    }
}

double KhFFOwz::CSoLshWFvvWT(string FxggwdOIUUILDvwW, int YOwvEbESGruICq)
{
    int ZohsvNUiJMvrHuL = -667566387;
    double FhGEcrwPc = 838633.1739249292;
    double fzJGYfpGneQVg = 795951.631122694;

    if (FhGEcrwPc != 795951.631122694) {
        for (int sklXm = 611697910; sklXm > 0; sklXm--) {
            FhGEcrwPc /= FhGEcrwPc;
            FhGEcrwPc /= FhGEcrwPc;
        }
    }

    for (int ejMrzg = 1871995741; ejMrzg > 0; ejMrzg--) {
        ZohsvNUiJMvrHuL = ZohsvNUiJMvrHuL;
    }

    for (int ffGGLWLnTLXWOP = 1681841996; ffGGLWLnTLXWOP > 0; ffGGLWLnTLXWOP--) {
        fzJGYfpGneQVg *= FhGEcrwPc;
        FhGEcrwPc += FhGEcrwPc;
        YOwvEbESGruICq += ZohsvNUiJMvrHuL;
        YOwvEbESGruICq = ZohsvNUiJMvrHuL;
    }

    return fzJGYfpGneQVg;
}

double KhFFOwz::wVfbzlkBUXIbYHlM(bool gEhOqslcv, int vIPZXPM, string KaLbWaPVTRkATNU, double BFglMjuGHG)
{
    double dqRVOOiFiOCyTZO = -960497.6845968259;

    for (int CKAAAWAzPRGMDcqb = 1312911954; CKAAAWAzPRGMDcqb > 0; CKAAAWAzPRGMDcqb--) {
        continue;
    }

    if (BFglMjuGHG < 821813.1412245687) {
        for (int bLkfFWVxs = 90058822; bLkfFWVxs > 0; bLkfFWVxs--) {
            continue;
        }
    }

    for (int ZzHpixdxoGI = 920165160; ZzHpixdxoGI > 0; ZzHpixdxoGI--) {
        KaLbWaPVTRkATNU += KaLbWaPVTRkATNU;
        vIPZXPM += vIPZXPM;
        gEhOqslcv = gEhOqslcv;
    }

    for (int JyrqisCULC = 1248498394; JyrqisCULC > 0; JyrqisCULC--) {
        KaLbWaPVTRkATNU += KaLbWaPVTRkATNU;
    }

    for (int XlUwxVEc = 1847056205; XlUwxVEc > 0; XlUwxVEc--) {
        continue;
    }

    return dqRVOOiFiOCyTZO;
}

string KhFFOwz::QYaNpkryO(string EftkNDXSpdBbsW, int vDiyJd, bool JRIlRDUijINi)
{
    int pwvoIRnm = -438290050;
    string ActWrYKSVo = string("GYFYSlGJrmrATCqxPtoCwGlrVINKjrZvBjGPdCPiwKCyCJUHQgigpZPRxJKIsUllOFNpqc");
    int wlPeaJyJ = 1001026686;
    int BaallL = 1070767347;

    if (pwvoIRnm != 1001026686) {
        for (int tbRlfhx = 864170730; tbRlfhx > 0; tbRlfhx--) {
            BaallL += BaallL;
            ActWrYKSVo = ActWrYKSVo;
            pwvoIRnm *= BaallL;
        }
    }

    for (int oBoFMJRufqTVyPA = 2062035335; oBoFMJRufqTVyPA > 0; oBoFMJRufqTVyPA--) {
        pwvoIRnm = BaallL;
        EftkNDXSpdBbsW += EftkNDXSpdBbsW;
        JRIlRDUijINi = ! JRIlRDUijINi;
    }

    return ActWrYKSVo;
}

int KhFFOwz::QgUSYYnjHcSZhDHB(string gqimXriXM)
{
    double IvbYp = -185809.63871197143;
    string dzuxlrPOY = string("yFiIhjKmBVABBcVygldFZCZGbFrMHrXtzJCJpGMjOoGzxpyXvMrPRiGuIQUTPdTQjKnvRSRyfcKlcElhgjEEDIZOhDUIHBkjSWzqpNUvXksFMBimgojqdUdyd");
    bool fLnKivjMObca = true;
    int vuggQjqCm = 1050305669;
    double cdUwJZU = -634476.0564752867;

    for (int NLvGJjFobpUWPEK = 1570504321; NLvGJjFobpUWPEK > 0; NLvGJjFobpUWPEK--) {
        continue;
    }

    for (int nHSbspecEk = 698792282; nHSbspecEk > 0; nHSbspecEk--) {
        gqimXriXM = gqimXriXM;
        IvbYp += IvbYp;
        cdUwJZU *= cdUwJZU;
    }

    for (int EJugGMwxsWhm = 719282943; EJugGMwxsWhm > 0; EJugGMwxsWhm--) {
        gqimXriXM += gqimXriXM;
        fLnKivjMObca = fLnKivjMObca;
    }

    if (vuggQjqCm <= 1050305669) {
        for (int LCCcz = 1708610463; LCCcz > 0; LCCcz--) {
            continue;
        }
    }

    for (int tfbxO = 1277356953; tfbxO > 0; tfbxO--) {
        IvbYp = IvbYp;
    }

    for (int TuXJtT = 1140447648; TuXJtT > 0; TuXJtT--) {
        cdUwJZU -= cdUwJZU;
        IvbYp *= cdUwJZU;
        dzuxlrPOY = gqimXriXM;
        IvbYp = cdUwJZU;
        cdUwJZU -= cdUwJZU;
    }

    return vuggQjqCm;
}

bool KhFFOwz::EcuEb(double ArOwfpdcX)
{
    double oGXDPALNAwSLwaB = -103965.66926320453;
    double MKtsF = -286367.46965051896;
    double sbaXRSFgxNwCUnLu = -131843.71128599334;
    string hwwSjBs = string("VwdhRLRSqRBxRMDveHvAJibmQsprUVpPSiHnNZivsxczBSlSYQWHhObPUkxxchJkTAaSXxxmYhRqOzlgENwovDrnImWhZGsbzEYKMpGBYQsmcisyZUQWcMLpaOfwqEWnDSvdrnSGMrGAjbgFsReAGBPCh");
    string hTlUytBsPyQ = string("EYspphJyWkDgOMPjQXQYTLyrPPcmfjEWwtTHDugVLDsXrzvQusuSnmCbpMAlSVZYsZbGUeojKoNtUNRInaoPcONLznAMvoEXnFjtyqgIQuaXwAcQqQmKycKZQmtCfAOAmthlssHQxwskQNAQSeoevbyDiMfgGdXKzhyjZMCNLjZthIEIBrHglcVyXBPOfbldGBSXqGWMtxbfDtyltytEFHGAeLqpRgZWoStv");
    double YPLhavhZsi = -874283.4571583129;
    bool VmzJcpVpzL = true;

    return VmzJcpVpzL;
}

double KhFFOwz::WGteaViAsjSF(double WpSYJIwiivDvOS, bool QkmmzMroPq, bool ZwYTOtYnjKlbyq, double cnBmbhvil)
{
    int xqZEwmBusnd = 1632253834;
    double qdrEP = 757106.6788730732;
    bool dlhRIHYto = true;
    int LgmHgXDI = -1078975019;
    bool FbCfjuSgL = true;
    int SqhhYnqgMfGbAoT = -1283921837;
    string ckDTsGXQe = string("fqLsFgIOYhugazHLFikYkmVckFpSCRkusJRntnbHMYHcZNYHmHIcwfvptvpKWCzUbTPGHyhCYymYRPbsd");
    double ilRiY = 1033439.8543335454;

    for (int VJexRPWhMhZqsO = 130995638; VJexRPWhMhZqsO > 0; VJexRPWhMhZqsO--) {
        QkmmzMroPq = ! ZwYTOtYnjKlbyq;
    }

    for (int eYkEmfMYEYrYih = 1080298803; eYkEmfMYEYrYih > 0; eYkEmfMYEYrYih--) {
        qdrEP = qdrEP;
        qdrEP /= WpSYJIwiivDvOS;
        ilRiY += qdrEP;
    }

    return ilRiY;
}

KhFFOwz::KhFFOwz()
{
    this->JZSsFigLz();
    this->GnoBMOZ(-825103.6171444851, string("skDEJTpixoHYnYzYxeOCUNSReielTnidZgviXvfSRlZZCPXEcrlHIbIghWlKYjqtfKhvFTpMFivKKMgpugenCWjtNkqFFgcgnSVFjJDzLXOvOTbreCTicBrRA"), true, true, 2123214043);
    this->KDScn(false, false, 448539413, string("pCYQpAOozoQBzCabuAVvQuYUaasQSkevUjjJahBrsylCsTCKBmipAjfgKYxqjlBlFUjCpScreBDwEqQoVFJmGKihwVyXDvTdQVjfKEPxWgrDkPxJZKVwqdKNH"));
    this->CSoLshWFvvWT(string("nYcUCSDRWemGmZzOiUNlomgcMwHYawHNfNcEZWIIFIHgjNCtsNrkTVjxeHqSpiGuULedyxlklVSWhptXNYyDTHOdRShPSGhBracpeofshyOJUbxrtCOBQDEjtPpWQuVHSwpgtcYleEBtzmFsXhcSANnFAYhwDbneJOIyYVknaMLBTRbZJxrBZpWZNApcRsCvkraaJuxuFJNsDEUjtrKLsfFYowOVJUaBuTdD"), -1526009773);
    this->wVfbzlkBUXIbYHlM(true, 874048323, string("tgaWfgahQjwrsFdhSuMVHXUkdUKtcwNiZoXYPCXoTXDizXCqZgXznRHRfrbcBVfzuUXxvZMTgynomLwwkTaxAttOlerimVKyhSMGyQPGsHCZspsVreQzaVhaObIatJgjWTzYxoFLyZsHESuooX"), 821813.1412245687);
    this->QYaNpkryO(string("yPAsMHtjIvpwVfKAarmZGctuiIMaFdyXwmlmHtcAqzIBbAEyqNUXqWIMEbscHeXCbDJYuFbGZAImxvTWsBzhwLwQBnAqWVBzsoKvcOSxAOkHrtrowiUOZgbbqzhAhhdEZAGycTmVUQXtKgLfodQDngbVzisJnAtHxxcqHIeYkdiadMUmFUYXTuJXoSVpXOQWfmWhNaSZFpzCEeYHeAwvLPRNUfUvAGo"), -914111484, true);
    this->QgUSYYnjHcSZhDHB(string("onWrIxQHEByslNmdyXjRtrdUeRAQfpoGgoSaTnfSDuxoFevbrelsoFQOwjTiJimAVBnVPzaaAQnKGnFQnJEOzEsvTHkcBWhCyjUlthlobimoLlbbYXoIUvdZSdxtLKhZToCHogVeSNoF"));
    this->EcuEb(867863.412867907);
    this->WGteaViAsjSF(987700.8311722429, true, true, 649095.1361106982);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YRbHixQpVBCCruNL
{
public:
    int NvxjzICufDyZ;
    bool sFOgEqHza;
    double KTNIUwobzQsEffUA;

    YRbHixQpVBCCruNL();
    double MQdqEZgMORGU(string HrrCSCzI, double wejaErmNMOa, bool nISbmfODLLdP, int iRMnvq, bool xpWXxoKtPWsxA);
    bool qkGPfBMxoAuOyLP(string FEsCdb, double KkCyVAdK, double zRwFU);
    int Oursp(int sAfvDXiyPIq, string YMwGXafgUzNxARPp, double jbEOyHzFCeaNKbZf);
protected:
    bool yofYPkQAEtUBkh;
    bool CgOOAlc;
    bool IZVSTCKxf;
    int xzTJSHhOfUjZwjE;
    bool rbGkBMKXAVWWFq;

    string BbUGUUQta(int HcjCpyOvSdQG);
    bool AnYMF(string PDxPr, double ZEiUdgDWF, bool yoPKzZClgkDBl);
private:
    bool OPVNvUxA;
    string mZRgyqrgtHLGHWU;
    double GJYpjFDuhTitn;
    bool cQbXEBG;
    bool QcRsEFuMmjPy;
    int ubiJCAAIG;

    void PmYifhrSPQPTGv(bool sBpWQVlqn, bool qayHWYKpde, bool BXxhjfkxptWbdPsb, int OtxqQKthtdSQT);
    bool tKMYhXoV();
    void KycTyOcugayM(string txhBD, string qgFElelw, string XgYkChYeajjHbcrO, string aBQjFYMknUJShlLA, int caSJLloPxZBBaHC);
    void HUszSiiiAt(bool uKPXrDftXskaoa, string NoWoqcdbnCSfYqnI);
    void PIesv();
    string BMuoZyRRHGDEWtvw(string rFmaiwlRwdSe, double OIqzZgjXSg, double VUGUGPuvucFbggD, string ALeAchkLJ);
};

double YRbHixQpVBCCruNL::MQdqEZgMORGU(string HrrCSCzI, double wejaErmNMOa, bool nISbmfODLLdP, int iRMnvq, bool xpWXxoKtPWsxA)
{
    bool bcxGKLhpVii = false;
    int dKxoAcxHKnQu = 1878204494;
    string AQCWSlmqExEHdvlf = string("KSowfdHeqsrpvamENFFuMFkrZYLdpHdOfrlntGCQuJyMulryjJmPbNrLdUUdAwGGYnNEeBDftjfdJiUycaZaGLoEceOtZkUrSHjumZdlYyMzQSLGmpMzCdnYSSHfOTKfyWoaiwnWBVcEYgesgrcuOLDRNWgiOBaIdCPwoSyKYmyTyVvplgCJiERsolGNZvayAWHgeQ");
    bool XNpVTEkF = true;
    int saKmjdiWpPnCzpX = -1470128163;
    bool ZlMEqWuKPo = false;
    double kpyiYQNlmEzI = -332438.695199623;
    int AYTEZT = 1429651661;

    return kpyiYQNlmEzI;
}

bool YRbHixQpVBCCruNL::qkGPfBMxoAuOyLP(string FEsCdb, double KkCyVAdK, double zRwFU)
{
    double jOONxSlvqRLcU = -593823.2065113862;
    bool TOmlJWNwoB = true;
    int yuhGau = 1849676344;
    bool Hycucja = false;
    bool OVipubDfmNjfwOSY = false;
    string mMboIJ = string("wPnazhaAhjiojhChLuyjuKisJQFWxxnvzqkrBJDIUWukuGNYlKaaMuiXGfgBvYyvvnKxynmwMmXvYCLQiNWUfRQdKDurjrEHGGlgHAStDVGZxAPGsK");
    double GnFfzmlNZsfuCs = 44986.20703437418;
    int AbfrPaCdroCLC = -702504094;
    bool UJOSQvYd = true;

    for (int lMbQbOdKOvfnmRoy = 448200336; lMbQbOdKOvfnmRoy > 0; lMbQbOdKOvfnmRoy--) {
        continue;
    }

    if (zRwFU == -593823.2065113862) {
        for (int vWzoIxeOK = 425333403; vWzoIxeOK > 0; vWzoIxeOK--) {
            GnFfzmlNZsfuCs *= GnFfzmlNZsfuCs;
            KkCyVAdK -= jOONxSlvqRLcU;
            UJOSQvYd = TOmlJWNwoB;
            TOmlJWNwoB = OVipubDfmNjfwOSY;
        }
    }

    return UJOSQvYd;
}

int YRbHixQpVBCCruNL::Oursp(int sAfvDXiyPIq, string YMwGXafgUzNxARPp, double jbEOyHzFCeaNKbZf)
{
    bool dCjbbyZcpXgdctnB = true;
    double uOSGWUuz = 19203.64274721779;
    string RLETguzswysr = string("zcJVGoCUInOMauPtNFmyxcFZdQTNOnQLfafUMAJadDDExgpzjngJszhkAZCqfeAfWdiVpdmDGQshaQcTZ");
    int ZFHPCRYChRALLMDZ = 1214375350;
    string gPQJl = string("IvVSYmRiCgJA");
    bool tNHjAKxP = false;
    bool aYVBN = true;
    double tJMLTDvdtUTAKd = -563222.8013565667;
    int hNMqNMWRycDscQJt = -945273910;
    int wzUslMp = 882791400;

    for (int ksNamflgdlNitpq = 364052331; ksNamflgdlNitpq > 0; ksNamflgdlNitpq--) {
        dCjbbyZcpXgdctnB = ! tNHjAKxP;
        RLETguzswysr += YMwGXafgUzNxARPp;
        sAfvDXiyPIq += wzUslMp;
        ZFHPCRYChRALLMDZ -= wzUslMp;
    }

    for (int ubETImHh = 1950083648; ubETImHh > 0; ubETImHh--) {
        RLETguzswysr = YMwGXafgUzNxARPp;
        uOSGWUuz += uOSGWUuz;
    }

    for (int PHXVETOpBC = 1259024415; PHXVETOpBC > 0; PHXVETOpBC--) {
        sAfvDXiyPIq *= wzUslMp;
    }

    return wzUslMp;
}

string YRbHixQpVBCCruNL::BbUGUUQta(int HcjCpyOvSdQG)
{
    int wbNmqULztSlC = -1606815160;
    bool qLLvTOgTYVv = false;
    double XzqsDZmqwfX = 411751.6517622642;
    string KIEBEffBAr = string("CnkaXmVpvpHJBljryjIeSQzjSljVjqgHdXFyFtqGBqrAiaektBEEWKgZujEdWVGacLMMoHIAJSDgboQYpNcoMKTiQFyfOmDscYJrOvkIiwaLvTSZRVbzOagbUkUCyGYxSlDEHKnmiKccHimHFXmtAySdonvxOPYKsstiorZOgydRJNQgXBfsmPPQbouRSkCBriJDkKMxZmhMyjolZIrvMToMTuxFbPf");

    for (int cCiEWugKFwNC = 654412969; cCiEWugKFwNC > 0; cCiEWugKFwNC--) {
        XzqsDZmqwfX = XzqsDZmqwfX;
    }

    for (int CIcJfdyAwzw = 462917562; CIcJfdyAwzw > 0; CIcJfdyAwzw--) {
        wbNmqULztSlC -= HcjCpyOvSdQG;
    }

    for (int qMJxyjgWMV = 859889158; qMJxyjgWMV > 0; qMJxyjgWMV--) {
        HcjCpyOvSdQG /= wbNmqULztSlC;
        KIEBEffBAr = KIEBEffBAr;
    }

    for (int tLBKDnXWQikSaH = 972803580; tLBKDnXWQikSaH > 0; tLBKDnXWQikSaH--) {
        HcjCpyOvSdQG += wbNmqULztSlC;
    }

    for (int lbMbkVGe = 1481735872; lbMbkVGe > 0; lbMbkVGe--) {
        KIEBEffBAr += KIEBEffBAr;
    }

    if (wbNmqULztSlC == -1190446685) {
        for (int ukzEibFXrbJA = 870697950; ukzEibFXrbJA > 0; ukzEibFXrbJA--) {
            continue;
        }
    }

    for (int vwGFaiFPVwgF = 1230765840; vwGFaiFPVwgF > 0; vwGFaiFPVwgF--) {
        continue;
    }

    return KIEBEffBAr;
}

bool YRbHixQpVBCCruNL::AnYMF(string PDxPr, double ZEiUdgDWF, bool yoPKzZClgkDBl)
{
    int HcpSSQNDVmBw = 1165122396;
    int ymVoY = 1964612515;
    string XynXdpfV = string("cwkGgLfsVWUbOkUZfYVJXOLXAJaUArAyvBORkFYHyHgOHScvBLFVegtEzEQkpWKLgaSIMddlLKVkjQFYgUimPTslndXQrywYcwYZJrrgphiwZBIAgDZibRnIfBuHVRGMCgYNZLjSGcYoZLepLLFBTFiVliqlXObZduJjyQnkEEPToRJSMpuoRwlftiRjVQJFMmhbFzfcrQNh");
    string XlaQFQzogmrT = string("bLGkrulqWkfTOjxHjFMLgyBxElRJjdhNxtbNEncIljMwEOXOniCpjgSNvXSYkdTBEdEsZBHZvFZnCkAwonnHoJuBRPSmExXtDdXmcsnUZAiVJfiTRZJMTXYUjziSZQL");
    bool YgCFtIAhzjmlbxu = true;
    string xnhgpERRahWL = string("ImpJvcSXgLfLXGdjInUAPWKmCJjlJRPKEZMZrzkkgbWoeQcwylmoaFcSClXgoUBLmePipXvXfkVoprNkKIpYJGmgXFnQSYSJGYqWcSjYfQauAiHu");
    int WAcsqDGr = -1376072053;
    double rFLWiQ = 941658.6463783259;
    string hEkIuzeIuERu = string("TtigGhDISIOhHfhbcefJXGMKBKYqjOVNIYRgdsDrYMUAxvybifAbouCiwnYTmFeeTVcbWvymwGSlRhZJWMRQbScYRjqwMpXKiZmUXQPeStphxqRaZmylzYeueUNYOgMcKESEjrbLbfUoKtlKuWGGMlgjWORDEUXNNvGgpjEWDDgmXmRRIvodADIGOkQwfSknpUbQltJGJXoKppXknpSsEbunr");
    int rDdSEvmQVOMMZdXt = -2128272145;

    if (ymVoY == 1165122396) {
        for (int mWHHZrqBrjLOCoLX = 1994330094; mWHHZrqBrjLOCoLX > 0; mWHHZrqBrjLOCoLX--) {
            XlaQFQzogmrT += xnhgpERRahWL;
            XynXdpfV = hEkIuzeIuERu;
        }
    }

    for (int hlARsYzqqPS = 1897940240; hlARsYzqqPS > 0; hlARsYzqqPS--) {
        continue;
    }

    for (int rdwYR = 1867889699; rdwYR > 0; rdwYR--) {
        HcpSSQNDVmBw /= HcpSSQNDVmBw;
        xnhgpERRahWL += XlaQFQzogmrT;
        rDdSEvmQVOMMZdXt *= WAcsqDGr;
        rDdSEvmQVOMMZdXt -= WAcsqDGr;
        PDxPr += XynXdpfV;
        xnhgpERRahWL += xnhgpERRahWL;
    }

    for (int HMOfEfZdGHCaMosu = 1693971934; HMOfEfZdGHCaMosu > 0; HMOfEfZdGHCaMosu--) {
        XynXdpfV = XynXdpfV;
        XynXdpfV = xnhgpERRahWL;
        rDdSEvmQVOMMZdXt += ymVoY;
        XlaQFQzogmrT += PDxPr;
    }

    if (PDxPr <= string("gHWdRYoESdWhJtlhDImJNONpnGaaBtRetusqzwBioUAaiCVayAvhWvskfZsOOlkXtZfxTYOnPYwCQqinhVpNGbWQGkpmTmnNsqUcfICiXOgijSItMcNPcQiRbEWRNgMHjzzGTtrDwRbaeRVzUTymG")) {
        for (int tufkO = 1026827875; tufkO > 0; tufkO--) {
            rDdSEvmQVOMMZdXt /= ymVoY;
            ymVoY += rDdSEvmQVOMMZdXt;
            XlaQFQzogmrT = PDxPr;
        }
    }

    for (int BrkcgPRDQQXaGuv = 1090903420; BrkcgPRDQQXaGuv > 0; BrkcgPRDQQXaGuv--) {
        continue;
    }

    return YgCFtIAhzjmlbxu;
}

void YRbHixQpVBCCruNL::PmYifhrSPQPTGv(bool sBpWQVlqn, bool qayHWYKpde, bool BXxhjfkxptWbdPsb, int OtxqQKthtdSQT)
{
    int SXSbnKGCoN = -1918310276;
    int pBKhvANSpq = -307259855;
    int QCzLV = 1243536532;
    string WJdiESLoCdBCmhKs = string("ZOLyJTlTyNuqzsFPQYBOjbniQUwUwlOoaBdLhVxEbfpUgIZlLcmnInzUXUkgTTtxKRxJivlNviNUCgaBgysgXjawaAVEdnKVuPDeufNQrnbzRiSpRTzwqcqBjoABQXSJhXfAOHpvWorUnBCoXFlojkvJUlUlBtbAyxwDHptjzbdwWgdKoyGhPDfNWqHsCXpAAxxhOBHWuGjZ");
    string ChnBFlvML = string("ZUzJKzMZPwMFFViwFopUsCAHQiYDFJgIoWcJGJTDRzXLKMlsAOLmbmEXSZugONkqNnxDAvfOlOodcCJGvqnUXTmUCrUidmlHmbXhHgXzfbuQKkVDclDsafnsUEkWbAhfP");

    for (int wrDJKrXwyYyaU = 2051832498; wrDJKrXwyYyaU > 0; wrDJKrXwyYyaU--) {
        OtxqQKthtdSQT /= QCzLV;
        WJdiESLoCdBCmhKs = ChnBFlvML;
        QCzLV *= SXSbnKGCoN;
        ChnBFlvML = WJdiESLoCdBCmhKs;
    }

    for (int lpFhSMBJMCStQp = 1932495611; lpFhSMBJMCStQp > 0; lpFhSMBJMCStQp--) {
        qayHWYKpde = ! BXxhjfkxptWbdPsb;
        QCzLV /= SXSbnKGCoN;
        pBKhvANSpq = SXSbnKGCoN;
        pBKhvANSpq -= SXSbnKGCoN;
        BXxhjfkxptWbdPsb = sBpWQVlqn;
        sBpWQVlqn = ! BXxhjfkxptWbdPsb;
    }

    if (qayHWYKpde != false) {
        for (int CHZeiAh = 1908571816; CHZeiAh > 0; CHZeiAh--) {
            qayHWYKpde = ! sBpWQVlqn;
            pBKhvANSpq = QCzLV;
            qayHWYKpde = BXxhjfkxptWbdPsb;
            QCzLV /= SXSbnKGCoN;
        }
    }

    for (int SRlHQiUFgy = 684666734; SRlHQiUFgy > 0; SRlHQiUFgy--) {
        QCzLV *= pBKhvANSpq;
        OtxqQKthtdSQT *= SXSbnKGCoN;
    }

    if (OtxqQKthtdSQT != -1722836616) {
        for (int DlUPyhX = 1767111326; DlUPyhX > 0; DlUPyhX--) {
            WJdiESLoCdBCmhKs += ChnBFlvML;
        }
    }

    for (int LySDcsXn = 641248596; LySDcsXn > 0; LySDcsXn--) {
        OtxqQKthtdSQT = QCzLV;
        pBKhvANSpq *= QCzLV;
        OtxqQKthtdSQT -= SXSbnKGCoN;
    }
}

bool YRbHixQpVBCCruNL::tKMYhXoV()
{
    bool MEwTdsnZCHqvQcY = false;
    double KqbPrJVuIahQ = -682964.1299899718;
    bool XfZciKgcKNvMiKiw = true;
    string FyTbUMBX = string("OrFigAfcetkNrQAQjCebDJNPBFDCwDErtrFhoGz");
    string hNgxJTrXYkXXlhdS = string("weyskPvafkAIDunUTMGnmCoRXuuwxWjBWCIRrhRoszWdxDLVOUKhXKsiPjJCTGZtyZOmYPbzqQSCkNYEUOUfCbN");
    int GUjpqNIXEyNMlOST = 439762779;
    double csrQPsEecDAVT = -363864.9506150163;

    if (XfZciKgcKNvMiKiw != true) {
        for (int DLpOeQS = 2048144450; DLpOeQS > 0; DLpOeQS--) {
            MEwTdsnZCHqvQcY = MEwTdsnZCHqvQcY;
            XfZciKgcKNvMiKiw = ! MEwTdsnZCHqvQcY;
        }
    }

    return XfZciKgcKNvMiKiw;
}

void YRbHixQpVBCCruNL::KycTyOcugayM(string txhBD, string qgFElelw, string XgYkChYeajjHbcrO, string aBQjFYMknUJShlLA, int caSJLloPxZBBaHC)
{
    int VaaSMXFTNN = -1208515381;
    string blTQaOqh = string("hgWUMILVeXqZOVPgMauZXgYEMMCEgnGXfZPSKnuETxiERWluFEFXcxfQStRjChGozVyRiKYEdnOtWNqoIhDEuiRGHqfIYHCcrFzwgUpskPRXxwCRdNcTYaiMZYZcfiScPNYfySxtmzfzqiAxpuHoPbHubymLjdSWntpp");
    string cgtwLzyOBslEAs = string("sPTpYGhCQzkIwbPZQPBWmXNrvPBaX");
    string QalKMYCfHf = string("LwGmtiKocoOftnQyyeoKPjVIMmSNsAZJhBRZGMlWTmKciVkUyFGMEDnbEdQWCxaCAjUfmKzyLStjGybQacOsqcbYzjTmJvATIOZqrVXCMMdMNiieSXXFtRRKUHzQzJfwyroaIMlUSqHEiWzBcKJtznXWcqfinfJtigoHaNmCtEMAZswslgQNdzhLvdzETKEXtMxyQxVllOiUxuhGqILDDM");
    double MAyjygUJZVLkVY = 892881.8977130605;
    double GPlZKfDcJRNLHhGn = 446552.88201912836;
    int CBOnFYQcxprbk = -510738806;
    bool DvHlH = false;

    if (VaaSMXFTNN > -510738806) {
        for (int lDcSNuGWMkYkyPJG = 124560186; lDcSNuGWMkYkyPJG > 0; lDcSNuGWMkYkyPJG--) {
            cgtwLzyOBslEAs = txhBD;
        }
    }

    for (int kPoMKMgSXahb = 2059338101; kPoMKMgSXahb > 0; kPoMKMgSXahb--) {
        XgYkChYeajjHbcrO = XgYkChYeajjHbcrO;
    }

    for (int FVdoyJfUzLYaRoU = 117089957; FVdoyJfUzLYaRoU > 0; FVdoyJfUzLYaRoU--) {
        qgFElelw = qgFElelw;
        CBOnFYQcxprbk = caSJLloPxZBBaHC;
    }

    for (int bSxMq = 713798935; bSxMq > 0; bSxMq--) {
        blTQaOqh = XgYkChYeajjHbcrO;
    }
}

void YRbHixQpVBCCruNL::HUszSiiiAt(bool uKPXrDftXskaoa, string NoWoqcdbnCSfYqnI)
{
    string iaJNKbHg = string("FdzOGiCRLmIJykEdrOdYzinvWhGiEcxwkqYNsdYiCZifbzThIGYdCiaJwQaHoGTFIunbZJrduRcVmBIWKNstABDvLjbkMxGsBKTXUsgLhHLqXkqtODCoYXHkeSSsKqSfdsvifygsEohbXHVTjyKVhURZwOrsIPxExHGGJveEsmtnBgnwCaluWxQgLRoogBumEkXdposRMsYembrhKbAThufNvVFuDo");
    bool tbMbgh = true;
    int pXMuBJJMIHEudNK = 584300487;
    string ZUooalyoCzTYHT = string("pZVDowfSNonDsGKYySsYaGXNxswbYaaWseOrTOHEsXvZUuMBmcADizmQtedwCXHtEuvWXZIejMpjeRzMQzAoYLJglSZtqlWUHYdidSPPwJBQitUSEhZPDHkAcPXNJkMCOsCTXnYIOCsrYSLIbIVEXSoKuFCBDocdbelAhVaAxhU");
    int eABRvtegsmURiMBk = 1346007449;
    double nyVfZNRF = -487656.9173904314;

    for (int EygRJsqVwunGWSrl = 1538011471; EygRJsqVwunGWSrl > 0; EygRJsqVwunGWSrl--) {
        continue;
    }

    for (int WhPOKdJiRVLYAUms = 2132364485; WhPOKdJiRVLYAUms > 0; WhPOKdJiRVLYAUms--) {
        uKPXrDftXskaoa = uKPXrDftXskaoa;
        uKPXrDftXskaoa = ! uKPXrDftXskaoa;
        eABRvtegsmURiMBk /= pXMuBJJMIHEudNK;
    }
}

void YRbHixQpVBCCruNL::PIesv()
{
    double IxkPWqmxY = 602996.8036635371;
    int kQufHGEZmnIAPqI = -840956350;
    double HnfntL = -187727.89385704894;
    double aWAFFystHk = 674951.3520741609;
    int MKbuqV = -975853587;
    string XrcHAhjAyiLGdqld = string("GoxwQYEXfOBELaGlomdTxlAIVHRiaTTRPARKDMCDeNyVvfQMPNPAMxNZYzmgCBYtDnVjyyDGLkkdLKRhbksTKSEtiNSctLFchcIzwiFCUuPpMMdfkQPRcmdwgKesGONIYXCdvHVWztdreVMMatTQPKRzbyZgSoAmMYBhrrcFfUfMuFwghVPgCXyUqyrjVliCjnpcAFwULWCshDkfnMYJGVJdYXkkBLxJJioDXmcJncSXWstwNVF");
    string MSfkdWfEePRYLY = string("kdLoguuPcktjbY");
    int dXlmxjENCtbnTe = 1273387467;

    if (IxkPWqmxY > 674951.3520741609) {
        for (int sAotuZnxPdx = 1749771535; sAotuZnxPdx > 0; sAotuZnxPdx--) {
            kQufHGEZmnIAPqI -= dXlmxjENCtbnTe;
        }
    }

    for (int CVqNkXICwIM = 1580991412; CVqNkXICwIM > 0; CVqNkXICwIM--) {
        continue;
    }
}

string YRbHixQpVBCCruNL::BMuoZyRRHGDEWtvw(string rFmaiwlRwdSe, double OIqzZgjXSg, double VUGUGPuvucFbggD, string ALeAchkLJ)
{
    bool MoMxqsbuwEYuKkA = false;
    int qcJzilabEUzne = 502031486;

    for (int jeBpWzybWA = 1098515799; jeBpWzybWA > 0; jeBpWzybWA--) {
        VUGUGPuvucFbggD += VUGUGPuvucFbggD;
    }

    for (int fNMfamuoNlzSFS = 622113826; fNMfamuoNlzSFS > 0; fNMfamuoNlzSFS--) {
        OIqzZgjXSg /= OIqzZgjXSg;
    }

    if (OIqzZgjXSg > 188027.93067874495) {
        for (int NygHUpax = 470162457; NygHUpax > 0; NygHUpax--) {
            continue;
        }
    }

    for (int mWvdXVEIqcTVLW = 91589884; mWvdXVEIqcTVLW > 0; mWvdXVEIqcTVLW--) {
        OIqzZgjXSg /= VUGUGPuvucFbggD;
    }

    for (int TigGdnqJlmAVwhL = 803437035; TigGdnqJlmAVwhL > 0; TigGdnqJlmAVwhL--) {
        continue;
    }

    return ALeAchkLJ;
}

YRbHixQpVBCCruNL::YRbHixQpVBCCruNL()
{
    this->MQdqEZgMORGU(string("h"), 894340.8356764152, false, -1433363630, true);
    this->qkGPfBMxoAuOyLP(string("PxMMblQCnxpOImPbIQmmNMnawSCtrOXzEynTrBarUKtBVlVxINjqfkUOHUUODSsoXXIdsAlLXEgKEddXWhxnaPFBEQOmrxfvArKXaGojyWWqqEGIbrJsLjjOKYnvoitCUtcTySsSmfIPTJkm"), -217028.1082128412, -726068.5143751836);
    this->Oursp(244465477, string("gsSaTowdmGtPrhVemDqjHcPvlmOUIHKUSyZwwYHeMOQYBEhnvlFKacZCWmGtmrponoChzBRAnyriRDjk"), 190966.90713797358);
    this->BbUGUUQta(-1190446685);
    this->AnYMF(string("gHWdRYoESdWhJtlhDImJNONpnGaaBtRetusqzwBioUAaiCVayAvhWvskfZsOOlkXtZfxTYOnPYwCQqinhVpNGbWQGkpmTmnNsqUcfICiXOgijSItMcNPcQiRbEWRNgMHjzzGTtrDwRbaeRVzUTymG"), 292581.12512683467, false);
    this->PmYifhrSPQPTGv(true, false, false, -1722836616);
    this->tKMYhXoV();
    this->KycTyOcugayM(string("ndiLbfsFApvvGjJyBbRuoKcPipAunlgTqujxAdmoPekYwVkvzKSBwRbUcjFUndGXhgMtyvdJNJXjNHqJpRLvNYYcLfSsen"), string("xbkdqCrffrMFiTYIlqCMcJIvlXzTQovbIyqtyIXzjyxaGqZgSfmMTDFoiaszojSOGbbVHIDjYpGkcKvsNEHptVcfIzjfvnzDTwLoLKEoJabXSNippwTEgMbfiQj"), string("PjFeLMvumxPpjWYRUocapgBjnknYKlOSJnGdiOdUooBkJnNUhtvNHWJfqJTdhmcT"), string("qkNqOjdXXzynCqAIlRoXkuYsdLSqNqyoFzYkHbWLTpYTqRUvCwOsYHgCsYHHmndYJRZDtrTmpziScEjSWUbt"), -846047646);
    this->HUszSiiiAt(true, string("qqlhJMbcVmNWAATIgeKanVrtPqnqkqzsSiIItKXEPYjdngMdYTySLAFZMNLCosSeLFpwLvkpLeXEFzzJoEPBuMVmKXpcvpxAYQIHRRcxcoUsiweBCi"));
    this->PIesv();
    this->BMuoZyRRHGDEWtvw(string("RFEDDQpWvrMxzaOjbUDRoAtbcUiCffaNMUSeYHpgXqteaowylNcvFFdsE"), 188027.93067874495, -507453.85034943133, string("xKnZcEZLKXJlFEAcjpznhaurrJYwQBUYyrDqcqAidHcXnWnMtgzTK"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yYkZsKxmhyC
{
public:
    string NFfBvm;
    string lgQnDnrkHPKY;
    double elgOtdHVV;
    double mvvmnuectrplufda;

    yYkZsKxmhyC();
    void wqEqYWmlMhqhjfj(int jQobrskaqb, int HNzpJS, double UKJQzbdSUxH, bool ggYtHniQto, int owGtOAbOUdm);
    bool PEOWblligSUJDdT(int DmxapiJRhdW, double ozVhptfCWdhlMj);
    bool bhwhpgegyuRMzGxq();
    string ObjKnOjSOBvap(int zEEhYfwt, string qnxAElXQSWQmYHBL);
    bool jnFDzjayvRULKYkd(string nhrNYXXRamoc, bool tEaCgPx);
    double jEpfhdds(double jMmNkfGbzKiprY, int kUqtkTVDEF, double jTncZrkO);
    double YXMjvIGwOu(bool KlpdIP, bool ITGYUTRPve, string FsvvduEHI);
protected:
    double uqMFtCfIH;
    string hXmuqAQsBhBdTZ;
    int KYdebb;
    bool zONgLjdwgOTntew;

    double LrwyPjoklAotgLb(string uxKSRAUtCWqeNRo, string QcXhBj, string LOiVCv, int golfXDovVuNijDVL, int gKnFBIuTclRqistt);
    void kSktJMzSsDELP(bool BNmOQFZ);
    bool rOxmn(string RCfAbz, int ZHBUwdCMaaaRUR, bool uOQulRpH, bool rWlprvoFIiN, double hydukBiRXwAQf);
    bool uebOVcxKJAXmEF(int XveDsyqcsWNGcIt, double BytuG, string QIMXdYcEl);
    bool LxkmebBGg(int KNlLccYmQQuQzSw, double tEQCYwAOaKIz, double RbEYymYT);
    int Ldoijfm(double HxxmFlox);
    bool ERqpxxCAog(int IThLGQo, bool QccuAFRBwL, string vmCEuqfQadql, bool ZxpaWQ);
    string NFLKvdjfR(double EVUXOu, string nKVAKWGaIs, int VNfMQoleiQT, double UOdmZbpKt, int GSazG);
private:
    string DDBeagDL;
    string STAzzJjHr;

    int llCQEToQLfoPoxsv();
    int FjgCSOpUk(string LHtRzsulmIdG);
    double gfaCytVJUUsJUE(double LQWYBWqHvBkok, double gRbah, bool lZGrBBvWT);
    string XrxnulYxEAhfwt(bool OvqmygYiVIuX, double KtVRvWpOO, string tkcFXHCECcmZ, double stnBFC, bool uyPAoYYzGHpNw);
    double mlqTNow(int TPADiWLVt);
    bool FRPsMIKZYYo(double YjMUZcZnH, int AFLAJvoKO, string ylLNP, double VTzMvkJdV, string hGIPkupvwyvDaBd);
    double mnqThtWiviM(int fbTHejNoqcl);
    void jCZEAo(bool WppaOZBiKlqN, string FgRoBFWhCFOfXCGv, string hjdkEHhxEqttSYq, double vhADH, double dNfScWLTQn);
};

void yYkZsKxmhyC::wqEqYWmlMhqhjfj(int jQobrskaqb, int HNzpJS, double UKJQzbdSUxH, bool ggYtHniQto, int owGtOAbOUdm)
{
    bool EcOkGjNqcHGWPzUG = false;
    int yYCmbG = -1937249486;

    if (owGtOAbOUdm < -1633267296) {
        for (int admSgghdRvQmMRIh = 274422229; admSgghdRvQmMRIh > 0; admSgghdRvQmMRIh--) {
            continue;
        }
    }
}

bool yYkZsKxmhyC::PEOWblligSUJDdT(int DmxapiJRhdW, double ozVhptfCWdhlMj)
{
    int aBUybb = -769055093;
    bool iFOHiqUYNwC = false;
    int wZwSuBj = -1348461757;
    int eJAal = 1210393888;
    bool nGJXQv = true;
    string YuTzdlouUtgIO = string("kMkhcQUGzTdzdgSEyskdaVrqDiZXetQPtBnsupYiPAHZdgKaQjTgUYKEvZrMwYMHDIwCPKnyWNnxxLxOHYUXDPrPJqQHyWisiOGkLeNkhzdqSjpIRfSGcwRRBHGePISaQNqLPdMuDhwLnVDKyegXYXiSsIOX");

    for (int VuMYleItX = 204635112; VuMYleItX > 0; VuMYleItX--) {
        aBUybb -= aBUybb;
    }

    return nGJXQv;
}

bool yYkZsKxmhyC::bhwhpgegyuRMzGxq()
{
    int vUBCWPwk = -261972417;
    double DbgvZbyMHXyUMd = 490854.49726533744;
    double EqMJQbbj = 306786.6646868224;
    int BiVodqTlNI = 638132498;

    for (int sGcQKjaYfCiYID = 1396420399; sGcQKjaYfCiYID > 0; sGcQKjaYfCiYID--) {
        BiVodqTlNI += vUBCWPwk;
        EqMJQbbj = DbgvZbyMHXyUMd;
        EqMJQbbj *= DbgvZbyMHXyUMd;
        EqMJQbbj /= DbgvZbyMHXyUMd;
        vUBCWPwk = vUBCWPwk;
        BiVodqTlNI -= vUBCWPwk;
    }

    for (int HqlfdDdAQMAeQa = 534109601; HqlfdDdAQMAeQa > 0; HqlfdDdAQMAeQa--) {
        vUBCWPwk += vUBCWPwk;
    }

    for (int wURmZwCMEOahG = 1430996474; wURmZwCMEOahG > 0; wURmZwCMEOahG--) {
        EqMJQbbj /= DbgvZbyMHXyUMd;
    }

    if (BiVodqTlNI < 638132498) {
        for (int KIEVf = 393403433; KIEVf > 0; KIEVf--) {
            continue;
        }
    }

    return false;
}

string yYkZsKxmhyC::ObjKnOjSOBvap(int zEEhYfwt, string qnxAElXQSWQmYHBL)
{
    double UmAcgXmgs = -52870.27295837747;
    int eAXOW = -466747724;
    double UwBzaRJkBxbUn = -576037.0838872623;
    int muOST = -845893410;
    double eRHeSPfAXW = -746948.8408925268;

    if (UwBzaRJkBxbUn < -746948.8408925268) {
        for (int pLSMCQgMR = 1830888488; pLSMCQgMR > 0; pLSMCQgMR--) {
            UwBzaRJkBxbUn += UwBzaRJkBxbUn;
            muOST /= zEEhYfwt;
            UwBzaRJkBxbUn *= UwBzaRJkBxbUn;
            UwBzaRJkBxbUn += eRHeSPfAXW;
        }
    }

    return qnxAElXQSWQmYHBL;
}

bool yYkZsKxmhyC::jnFDzjayvRULKYkd(string nhrNYXXRamoc, bool tEaCgPx)
{
    int ZVEGVSRionIbl = -1121799081;

    for (int FOeedIeebkSXSHt = 2046209912; FOeedIeebkSXSHt > 0; FOeedIeebkSXSHt--) {
        ZVEGVSRionIbl /= ZVEGVSRionIbl;
        nhrNYXXRamoc += nhrNYXXRamoc;
        nhrNYXXRamoc += nhrNYXXRamoc;
    }

    for (int zdMEkGgeB = 1075403918; zdMEkGgeB > 0; zdMEkGgeB--) {
        nhrNYXXRamoc = nhrNYXXRamoc;
        tEaCgPx = ! tEaCgPx;
    }

    for (int WduuBulINpwqTz = 1090413086; WduuBulINpwqTz > 0; WduuBulINpwqTz--) {
        ZVEGVSRionIbl = ZVEGVSRionIbl;
    }

    return tEaCgPx;
}

double yYkZsKxmhyC::jEpfhdds(double jMmNkfGbzKiprY, int kUqtkTVDEF, double jTncZrkO)
{
    string BtfJLUVsvPSVvDX = string("TOmUMONSXZUuDUNRlfjmyCgFOIfYcsJlBEKBmNAhGQpcNBmkcPKLLpZkskubNbbGptIiPkcSxCsXpydQURurNmcaS");

    for (int VYDWKEbfwGj = 282986976; VYDWKEbfwGj > 0; VYDWKEbfwGj--) {
        continue;
    }

    for (int EelWLKufdeJsyN = 789312087; EelWLKufdeJsyN > 0; EelWLKufdeJsyN--) {
        kUqtkTVDEF += kUqtkTVDEF;
        jMmNkfGbzKiprY /= jMmNkfGbzKiprY;
        kUqtkTVDEF /= kUqtkTVDEF;
    }

    if (kUqtkTVDEF <= 943466935) {
        for (int HWFCOOfLJ = 37085259; HWFCOOfLJ > 0; HWFCOOfLJ--) {
            BtfJLUVsvPSVvDX = BtfJLUVsvPSVvDX;
            BtfJLUVsvPSVvDX = BtfJLUVsvPSVvDX;
            kUqtkTVDEF /= kUqtkTVDEF;
        }
    }

    return jTncZrkO;
}

double yYkZsKxmhyC::YXMjvIGwOu(bool KlpdIP, bool ITGYUTRPve, string FsvvduEHI)
{
    double jiBjyjkebTT = 232261.52602376297;
    bool NsTtSxwkXQyf = true;
    int SLgAXsQB = -510985237;
    string knsPkJAjNCfwCMFW = string("jvccMCbWivWQcqPDVRVNFwyWodhpfhNuNTIksUGYwWMADgkpysTHRBtASlQSHBJWKuGTsWjiLhDjfTMBhmsYJUdQIXmoirGtsiPUx");
    int DvvBGPSGRBPH = 708448073;
    bool fEfEJNi = true;

    return jiBjyjkebTT;
}

double yYkZsKxmhyC::LrwyPjoklAotgLb(string uxKSRAUtCWqeNRo, string QcXhBj, string LOiVCv, int golfXDovVuNijDVL, int gKnFBIuTclRqistt)
{
    string JnRrS = string("IlDNtidIxecmFDuduZLYLhRdCDxrXSApczoBIekXkIoqMuLYafqkkjmRMjOsauykpUpeNfjpYcaOxYfTXXeImOQDEeSwmmUdvLIPxSErCWRsZpGSFifKKdwNHGAqlzYjHsNTrJQMSgcbHaBOOrldiDQniFosSOqtcsVxexRQiwXNhPFNipfIbpgVwjKIsQFYCbCJhmIZDpZHMMcnKwsCoguqnkNvkSSAStTILxoAiPUuzp");
    double zFGTJAdSheegj = 248757.34085610803;
    int DafzDcnPHcTpq = 1941634378;
    bool FrVkr = false;
    int weKEggAKUASHdwwm = 1977362594;

    if (uxKSRAUtCWqeNRo <= string("xYwmKupPABDqKsNYWauSxLImVptbAaGxanDqygkSRXanpzBfklzlnhnWFlmiCSBL")) {
        for (int KaGyemOJwV = 1488599541; KaGyemOJwV > 0; KaGyemOJwV--) {
            uxKSRAUtCWqeNRo += JnRrS;
        }
    }

    for (int QYiOVngVlhyBzhzm = 1391811826; QYiOVngVlhyBzhzm > 0; QYiOVngVlhyBzhzm--) {
        gKnFBIuTclRqistt *= DafzDcnPHcTpq;
    }

    return zFGTJAdSheegj;
}

void yYkZsKxmhyC::kSktJMzSsDELP(bool BNmOQFZ)
{
    int GNpILHBqONzuxbdA = 1878399429;

    for (int IhcJfQ = 1750848463; IhcJfQ > 0; IhcJfQ--) {
        GNpILHBqONzuxbdA += GNpILHBqONzuxbdA;
        BNmOQFZ = ! BNmOQFZ;
        BNmOQFZ = BNmOQFZ;
        GNpILHBqONzuxbdA *= GNpILHBqONzuxbdA;
        GNpILHBqONzuxbdA += GNpILHBqONzuxbdA;
        GNpILHBqONzuxbdA /= GNpILHBqONzuxbdA;
    }

    if (BNmOQFZ != false) {
        for (int SizIWnR = 184647181; SizIWnR > 0; SizIWnR--) {
            BNmOQFZ = BNmOQFZ;
        }
    }

    if (GNpILHBqONzuxbdA >= 1878399429) {
        for (int CrplmFvl = 692950025; CrplmFvl > 0; CrplmFvl--) {
            GNpILHBqONzuxbdA += GNpILHBqONzuxbdA;
            BNmOQFZ = ! BNmOQFZ;
            BNmOQFZ = BNmOQFZ;
            BNmOQFZ = BNmOQFZ;
            GNpILHBqONzuxbdA *= GNpILHBqONzuxbdA;
            GNpILHBqONzuxbdA /= GNpILHBqONzuxbdA;
        }
    }

    for (int BfLBCPXfti = 59248818; BfLBCPXfti > 0; BfLBCPXfti--) {
        continue;
    }

    if (BNmOQFZ == false) {
        for (int cNzbdlaQspwfEXbf = 834828471; cNzbdlaQspwfEXbf > 0; cNzbdlaQspwfEXbf--) {
            BNmOQFZ = BNmOQFZ;
            GNpILHBqONzuxbdA -= GNpILHBqONzuxbdA;
            BNmOQFZ = BNmOQFZ;
            GNpILHBqONzuxbdA /= GNpILHBqONzuxbdA;
        }
    }
}

bool yYkZsKxmhyC::rOxmn(string RCfAbz, int ZHBUwdCMaaaRUR, bool uOQulRpH, bool rWlprvoFIiN, double hydukBiRXwAQf)
{
    bool EpncgBLmboHPF = false;
    bool qbGbFMh = true;
    double OFtfWjyGtmhX = -271151.5370862574;
    int hlRizpGAK = -768040016;

    return qbGbFMh;
}

bool yYkZsKxmhyC::uebOVcxKJAXmEF(int XveDsyqcsWNGcIt, double BytuG, string QIMXdYcEl)
{
    double tpnuHzz = -1009407.2891058085;

    for (int VHtqUDtHYJwE = 1788157603; VHtqUDtHYJwE > 0; VHtqUDtHYJwE--) {
        continue;
    }

    for (int PDvWIFWny = 1066588034; PDvWIFWny > 0; PDvWIFWny--) {
        QIMXdYcEl = QIMXdYcEl;
        tpnuHzz = tpnuHzz;
        XveDsyqcsWNGcIt /= XveDsyqcsWNGcIt;
    }

    for (int ckTgolid = 1600816689; ckTgolid > 0; ckTgolid--) {
        tpnuHzz += BytuG;
    }

    return true;
}

bool yYkZsKxmhyC::LxkmebBGg(int KNlLccYmQQuQzSw, double tEQCYwAOaKIz, double RbEYymYT)
{
    double qorrj = -384714.8442289929;
    bool EkPnYXXhOYr = true;

    if (RbEYymYT != 687798.1564592761) {
        for (int zWBFJlHOlbQReIs = 691374345; zWBFJlHOlbQReIs > 0; zWBFJlHOlbQReIs--) {
            tEQCYwAOaKIz *= qorrj;
            qorrj -= qorrj;
        }
    }

    if (RbEYymYT == -254127.33919239583) {
        for (int ZZXqiwHGWP = 1859578968; ZZXqiwHGWP > 0; ZZXqiwHGWP--) {
            qorrj -= tEQCYwAOaKIz;
            KNlLccYmQQuQzSw += KNlLccYmQQuQzSw;
        }
    }

    if (tEQCYwAOaKIz >= 687798.1564592761) {
        for (int VuLXduqCbnZllW = 170258241; VuLXduqCbnZllW > 0; VuLXduqCbnZllW--) {
            RbEYymYT *= tEQCYwAOaKIz;
            qorrj /= tEQCYwAOaKIz;
        }
    }

    for (int PlOFSHDKkXTQ = 600662961; PlOFSHDKkXTQ > 0; PlOFSHDKkXTQ--) {
        qorrj = RbEYymYT;
        RbEYymYT /= tEQCYwAOaKIz;
        KNlLccYmQQuQzSw = KNlLccYmQQuQzSw;
    }

    return EkPnYXXhOYr;
}

int yYkZsKxmhyC::Ldoijfm(double HxxmFlox)
{
    double DrhXksuI = 28541.727251677432;

    if (HxxmFlox > -215998.47378692334) {
        for (int YuSyPTMxLJ = 427486000; YuSyPTMxLJ > 0; YuSyPTMxLJ--) {
            HxxmFlox -= HxxmFlox;
            HxxmFlox /= DrhXksuI;
            DrhXksuI += HxxmFlox;
            DrhXksuI += DrhXksuI;
            DrhXksuI -= DrhXksuI;
            DrhXksuI = HxxmFlox;
            HxxmFlox *= HxxmFlox;
            HxxmFlox = DrhXksuI;
            HxxmFlox *= DrhXksuI;
        }
    }

    if (DrhXksuI == 28541.727251677432) {
        for (int xSHZZaXku = 687210589; xSHZZaXku > 0; xSHZZaXku--) {
            HxxmFlox /= DrhXksuI;
            HxxmFlox += HxxmFlox;
            HxxmFlox = DrhXksuI;
            HxxmFlox /= DrhXksuI;
            HxxmFlox = HxxmFlox;
            HxxmFlox = HxxmFlox;
            DrhXksuI /= DrhXksuI;
        }
    }

    return -1048913788;
}

bool yYkZsKxmhyC::ERqpxxCAog(int IThLGQo, bool QccuAFRBwL, string vmCEuqfQadql, bool ZxpaWQ)
{
    int XREkLPBNmaxO = -1791695937;
    string XSgCIKIAqOsmFSM = string("jqFSwUHzvZBBGHUHrPLonprlbPGrdWjMQEsrOGaTPvQYTjcevGfrdNcMPWaBfGSZKVZEyyDsMMwuvtxHoODeDRxKuzPMKLNwybTGkRrJquhwJXjWcdXMmyzaXAYtqAtQOkuKPZzWXXvuEmFkqFwxQDuaHpfdoLyoiRicyMSJCVfffdAbxgFBU");
    string qxDpQPsm = string("yCfjNGJksdbjlfbQewXuyiqjVReJOKwADzOxpdORUtLTrNuulJOJrHFdbvCCUhASFSowebOJoUpbalAAcTNinUgKdVVTkGwRljmdBRQqRfhYsqMLqfZPEWMjdFbfoCrKLotknnJMSRbzQSAIgWExOgBFxQXEUvfnbQqEBfXvZWyKtHWHsTXbXXvGKAJllBXfOwENauHIRPShXkWXBccmbPyTNRCgFbMLcTOTKRfrFevAhiaJsqLhUiCSMXnyTOv");
    int nasXbUV = -887795878;
    double wpBbOeAaP = 869438.5154725981;
    bool SaUKlSMFu = true;

    for (int EANIsBaHudxXeCa = 65223991; EANIsBaHudxXeCa > 0; EANIsBaHudxXeCa--) {
        vmCEuqfQadql = vmCEuqfQadql;
        vmCEuqfQadql += XSgCIKIAqOsmFSM;
        XREkLPBNmaxO /= IThLGQo;
    }

    return SaUKlSMFu;
}

string yYkZsKxmhyC::NFLKvdjfR(double EVUXOu, string nKVAKWGaIs, int VNfMQoleiQT, double UOdmZbpKt, int GSazG)
{
    double HFrPTABr = -632212.0120159747;

    if (HFrPTABr == 660202.7149883474) {
        for (int RtTyzd = 704353973; RtTyzd > 0; RtTyzd--) {
            VNfMQoleiQT *= GSazG;
            EVUXOu = EVUXOu;
        }
    }

    if (nKVAKWGaIs == string("fbWHeiZHtGmblNeorWLziSmqGgBwVmIVSOXFCoUZmgbnOrRZnKQBiLgPcVhtPJtHPxmsGjSLewXYflBPKpotBHQuGwCpNnDdMjzsrEIODKaZtCGEvctpBQgpSGfKoapVLZVPVeZYeLKPBJdmaGeVCotGDicWsVgXMRIYPFhyzrXFeyLHkr")) {
        for (int oteLKzbvewMGu = 1464887128; oteLKzbvewMGu > 0; oteLKzbvewMGu--) {
            HFrPTABr += HFrPTABr;
            UOdmZbpKt -= UOdmZbpKt;
            UOdmZbpKt -= HFrPTABr;
        }
    }

    if (EVUXOu > 660202.7149883474) {
        for (int ZGdMIE = 589918763; ZGdMIE > 0; ZGdMIE--) {
            VNfMQoleiQT /= VNfMQoleiQT;
        }
    }

    return nKVAKWGaIs;
}

int yYkZsKxmhyC::llCQEToQLfoPoxsv()
{
    double gkDDbDQ = 509684.83979718044;
    double hSjXuYcXGPts = 854858.4983236287;
    bool CWmNteU = false;
    string fkvil = string("GUJcVOrowNgnJkbKswGkoGUUROLjJlFrczZdUIwHxMNaxepqFZpJvQUrNHezCxK");
    string icqxRQDAUl = string("YhsxoJyhQPEtYtECssarnGkIBRaGIlcpFdbDVUzqrQhGdIPkDoOdazMxByzYu");
    double kRLuCkXMMLrFxWW = -480507.1771661684;
    string cGMQPCUEEqMpFTIx = string("HuhjNgtCQzrMngwNXAVEYhNesvXivFIeGhOHhiQoGaCyEhxwdVzBVWhLnidZvAHEcfPYCoowoCspBlHTyNyqZVZJWBrhxuEemuUhYzugEjOLaQwJokLgZWQQhHeStcYwRrNmiMhRjyOcE");

    if (icqxRQDAUl == string("HuhjNgtCQzrMngwNXAVEYhNesvXivFIeGhOHhiQoGaCyEhxwdVzBVWhLnidZvAHEcfPYCoowoCspBlHTyNyqZVZJWBrhxuEemuUhYzugEjOLaQwJokLgZWQQhHeStcYwRrNmiMhRjyOcE")) {
        for (int aKUvVBLFjR = 1811024350; aKUvVBLFjR > 0; aKUvVBLFjR--) {
            cGMQPCUEEqMpFTIx += icqxRQDAUl;
            fkvil = fkvil;
        }
    }

    return -91562076;
}

int yYkZsKxmhyC::FjgCSOpUk(string LHtRzsulmIdG)
{
    bool PkRqCYl = true;
    bool zexwjNwoPf = false;
    int xxiYFWSYlih = 273151460;
    int AEEqrGgzESA = -1317600252;
    string mgfKDGoPAhaw = string("tjfZZxGVYkiDuxoRagHjXXdgxxuuwTVSrpcqAzeUsoSiejDShDvsRpXlvkBOcobEDAddrYTFvnwWQxsRthmbAqHcnlefLgmyHlgmzUywPynoxvhWEBCprIYWzJMTHWTPpWEmtfWEQSRdbdiwYWGkBULVFzlkmIyeKQPfbGhGakuhEmfxVkGQORXiVKkSGGvJRLYqaTiGvzsuHtqXfItLNQ");
    int bWVpdprIeeKKs = -2083964919;
    bool yJPAl = false;

    if (zexwjNwoPf == false) {
        for (int GgDivrB = 1694554079; GgDivrB > 0; GgDivrB--) {
            xxiYFWSYlih -= bWVpdprIeeKKs;
            zexwjNwoPf = yJPAl;
        }
    }

    for (int RWXdhsSS = 2068690821; RWXdhsSS > 0; RWXdhsSS--) {
        bWVpdprIeeKKs *= bWVpdprIeeKKs;
    }

    if (AEEqrGgzESA > -2083964919) {
        for (int tOlWA = 1646569257; tOlWA > 0; tOlWA--) {
            yJPAl = ! PkRqCYl;
            PkRqCYl = ! PkRqCYl;
            mgfKDGoPAhaw += mgfKDGoPAhaw;
            xxiYFWSYlih += xxiYFWSYlih;
        }
    }

    return bWVpdprIeeKKs;
}

double yYkZsKxmhyC::gfaCytVJUUsJUE(double LQWYBWqHvBkok, double gRbah, bool lZGrBBvWT)
{
    int MgCkfwCVDTznef = 2097419812;
    bool nhUGWEChrz = true;
    int EJyFtHFPHP = -1735395626;
    string SywQVqbxmlGwEBAf = string("CrzXJBDnaciBWiuyzdnwbozNuIDbITvXJgkikTTOybfKiHSVcJTooAiRWgpGJjtNaxaQNMDpHbCDXrVGVggogvFMTeCTBjPQWuPGymnbprrcRTaJwDidDVNbfzQlUpOLRjkfuFyAPiGG");
    int phRxztYCpHwShhg = 2063101584;
    bool EEXSXBpaI = true;

    for (int JtOFmGWCYyrQEs = 1595858593; JtOFmGWCYyrQEs > 0; JtOFmGWCYyrQEs--) {
        EJyFtHFPHP /= phRxztYCpHwShhg;
    }

    for (int XRCBtwcOzNx = 573768684; XRCBtwcOzNx > 0; XRCBtwcOzNx--) {
        EJyFtHFPHP = phRxztYCpHwShhg;
        LQWYBWqHvBkok = LQWYBWqHvBkok;
    }

    if (MgCkfwCVDTznef < 2063101584) {
        for (int DuRfBtYhnhPA = 862195034; DuRfBtYhnhPA > 0; DuRfBtYhnhPA--) {
            lZGrBBvWT = ! EEXSXBpaI;
        }
    }

    if (phRxztYCpHwShhg < 2063101584) {
        for (int cPDHfRLvzujZOoHk = 526172149; cPDHfRLvzujZOoHk > 0; cPDHfRLvzujZOoHk--) {
            nhUGWEChrz = nhUGWEChrz;
        }
    }

    if (LQWYBWqHvBkok == 1033294.6764797331) {
        for (int SWBnOG = 1522411063; SWBnOG > 0; SWBnOG--) {
            continue;
        }
    }

    return gRbah;
}

string yYkZsKxmhyC::XrxnulYxEAhfwt(bool OvqmygYiVIuX, double KtVRvWpOO, string tkcFXHCECcmZ, double stnBFC, bool uyPAoYYzGHpNw)
{
    int CfifmvLguNXhF = 953125132;
    string WHeXtHozFHh = string("NfBTCdMpPbzowChlXkeEhChtgXGTsIrMZTVcvzCTkYQEzbibOOVIhpxtafJxTVakkPvKzeOPUbFkFgdliDEH");
    int qXNmb = 127595869;
    string YVZhElACiC = string("MXqTkHngyrasNiTgiRJQCmpJCuIMZDStCiJDzDuvGQlpzoiBpdnmxHhzRIbWLGzisMJtvjj");
    string XcUkpnzRpPA = string("dmjWDgKYEQdtbsVGdWFgYNGNeJcYUdcRuPlwnWmIRBPuwcSsWoTDbNIPZtanhpELUhyhWDOAZIDLHdCRXq");
    bool KZEeCPQreKhLJL = true;
    string FRjXkRC = string("XeHxTHivnEdZHocHIwPmBIjqZooZKbqequxjHsjwYduPIDJwyTjmQPZgnROHIiQoJyRRnBkZZDLvzdTTQGINdCahAKyfWtgNmtVHusBeBEczXNCcivrNoNDlcpIgZqtBjQOMLagGWRHlrcARrjIKGVQnbFasjGAsEVUKLSjVhqmrCllWFpA");
    bool kUYxkMbjFk = true;
    bool SsFZDhY = true;
    string TxiBHaHOiWK = string("RMTWoIWPdmpSamjDwzDpPMMzagAzONQSuOKnVGxniKByVbXIUbWBHkfTieOdWcgrbwdlpqHdldjyqrKEVrrlgFdPuYqoWMGBu");

    if (uyPAoYYzGHpNw == true) {
        for (int JkbxPsWqBjrEwWh = 2045004229; JkbxPsWqBjrEwWh > 0; JkbxPsWqBjrEwWh--) {
            WHeXtHozFHh = YVZhElACiC;
            XcUkpnzRpPA = WHeXtHozFHh;
        }
    }

    if (OvqmygYiVIuX != true) {
        for (int YplaQQb = 903262492; YplaQQb > 0; YplaQQb--) {
            uyPAoYYzGHpNw = ! KZEeCPQreKhLJL;
            qXNmb += qXNmb;
        }
    }

    if (qXNmb > 127595869) {
        for (int TaKjsibqvt = 144874894; TaKjsibqvt > 0; TaKjsibqvt--) {
            kUYxkMbjFk = KZEeCPQreKhLJL;
        }
    }

    return TxiBHaHOiWK;
}

double yYkZsKxmhyC::mlqTNow(int TPADiWLVt)
{
    string ZNYvNAkrVjpDobd = string("umGnfRJAEiXyQwjgWge");
    bool JlrebwKpCqUV = true;
    double CUMkvgyk = 453423.8388462372;
    string sqMjzsBzAR = string("ACcHYOnDkMAlVHdBgnHzvIeNdXCFDSrnxwBzsaYKIRsVJEUZRraCLhjIipXfFVHRquYGuHQufiVaWhLvYJDfkXNEvCsOpoScziQytvYtTttFnEnSQVczNqMQgLNlNHEzyVqNXrGNemKOfeJVdPywnULhsRxfkIQEHWPelbiTvuQnFTqbaUXgTgQsCeKreuxsCpwXBEVhzJYfgDXNGkzedxIBMIKANoblOsSwJ");

    for (int pTrqlfSxhLFmSxhf = 1622349850; pTrqlfSxhLFmSxhf > 0; pTrqlfSxhLFmSxhf--) {
        JlrebwKpCqUV = JlrebwKpCqUV;
        sqMjzsBzAR += ZNYvNAkrVjpDobd;
    }

    if (sqMjzsBzAR == string("umGnfRJAEiXyQwjgWge")) {
        for (int bDAiJx = 1167350536; bDAiJx > 0; bDAiJx--) {
            sqMjzsBzAR = sqMjzsBzAR;
            sqMjzsBzAR = ZNYvNAkrVjpDobd;
            CUMkvgyk -= CUMkvgyk;
        }
    }

    for (int wxDUeeiZyQylPg = 1520399736; wxDUeeiZyQylPg > 0; wxDUeeiZyQylPg--) {
        ZNYvNAkrVjpDobd += ZNYvNAkrVjpDobd;
        ZNYvNAkrVjpDobd += ZNYvNAkrVjpDobd;
        ZNYvNAkrVjpDobd = ZNYvNAkrVjpDobd;
    }

    for (int JDIiUPHHFgCLzaeG = 502957330; JDIiUPHHFgCLzaeG > 0; JDIiUPHHFgCLzaeG--) {
        continue;
    }

    for (int oHLyieSCIRZe = 1053264030; oHLyieSCIRZe > 0; oHLyieSCIRZe--) {
        ZNYvNAkrVjpDobd += sqMjzsBzAR;
    }

    return CUMkvgyk;
}

bool yYkZsKxmhyC::FRPsMIKZYYo(double YjMUZcZnH, int AFLAJvoKO, string ylLNP, double VTzMvkJdV, string hGIPkupvwyvDaBd)
{
    string zwTdTKwQWgipK = string("vMuELpJjoQKGmNPmYtUixssFujodifuKrHydVkmMkfQnYOVyEDwPLinsVdLgcggJCMPZNQuMEeILQjlGAcwwlfoziWUJhfMsJOCTfCqzaKGBFgVbNhOTwhQVKWfqnFJLtTKqyTzLbTNMfwRPgtMFQfiNqErhY");
    string pnfmN = string("FtDQOmXwKsTbeOjwCMMszgiRIjRTZbHaiOodiWraAAcoNUmenlxjRMMzqJjSvLvnx");
    string QAMmNPARILo = string("MEBNgpbixpVvhuwJhgotfubjawuvSezOivCZDZMLGmBBhfizsKTBIKjKpvsjwjZfJLtJKJxzHoAkIElTrptVhaocawhJvQtcueswNOATMELjMGoQNVOCwROPRQPKKzpZOg");
    bool cLYuhlHhT = false;
    double klstTOXj = 8430.70605133487;

    for (int uaVCmRpe = 1162732834; uaVCmRpe > 0; uaVCmRpe--) {
        pnfmN = zwTdTKwQWgipK;
        QAMmNPARILo += QAMmNPARILo;
        QAMmNPARILo += pnfmN;
        zwTdTKwQWgipK = ylLNP;
    }

    if (zwTdTKwQWgipK > string("qcFhdfsxvksoIQpVnxdXvcIoHzUXNcKzBVmBfuFNGNrUGEqbSpJSsZUsPGPumekyXBEwnHxzqieBmTMJEZhgTioqHjRKFiiitBOuLOoNLtwWCUaabnYtGZdbBTckKcaFwhZuXcFGDTUJYuXrAhIZPzFYFspVyHBzsXZpWPTLpAAIsPRaLADaMVrhrNHJWQJvQAjXXBtYWuwsIEsmpWkDtKUahZxdr")) {
        for (int UEmRwvnw = 2142843828; UEmRwvnw > 0; UEmRwvnw--) {
            YjMUZcZnH /= YjMUZcZnH;
            QAMmNPARILo = QAMmNPARILo;
            VTzMvkJdV = klstTOXj;
            zwTdTKwQWgipK = ylLNP;
            VTzMvkJdV -= klstTOXj;
        }
    }

    if (pnfmN > string("qcFhdfsxvksoIQpVnxdXvcIoHzUXNcKzBVmBfuFNGNrUGEqbSpJSsZUsPGPumekyXBEwnHxzqieBmTMJEZhgTioqHjRKFiiitBOuLOoNLtwWCUaabnYtGZdbBTckKcaFwhZuXcFGDTUJYuXrAhIZPzFYFspVyHBzsXZpWPTLpAAIsPRaLADaMVrhrNHJWQJvQAjXXBtYWuwsIEsmpWkDtKUahZxdr")) {
        for (int xFRqbYUqKIbsFzxt = 2099483402; xFRqbYUqKIbsFzxt > 0; xFRqbYUqKIbsFzxt--) {
            continue;
        }
    }

    return cLYuhlHhT;
}

double yYkZsKxmhyC::mnqThtWiviM(int fbTHejNoqcl)
{
    string jPtpSzUmMs = string("DOetOTKPJkHhKMVfShbUDEvfWoLcdwbzLoAbvXUzqJFQQvSPVzXKyicsOalPvRrObXyxIgMTPzDQlTPJLmOygAyvTDVrFCRTfomhIIYCvbggpmDbdsqxEnsbcPMYkvxAfosYSNJlxTuwGwfzkLvkUEpmrEYaPhBMaFXLaiSzJhRoGJjNoozHzjNzILfghLcAWqoXWYokBzqTjXMvXrdfwZQgvrAnfsDAaegnv");
    bool oMOgon = false;

    for (int pUHEAWUjq = 872658820; pUHEAWUjq > 0; pUHEAWUjq--) {
        fbTHejNoqcl *= fbTHejNoqcl;
    }

    for (int hFszExCBxItElG = 660390311; hFszExCBxItElG > 0; hFszExCBxItElG--) {
        fbTHejNoqcl += fbTHejNoqcl;
        jPtpSzUmMs += jPtpSzUmMs;
    }

    return 688792.1178161161;
}

void yYkZsKxmhyC::jCZEAo(bool WppaOZBiKlqN, string FgRoBFWhCFOfXCGv, string hjdkEHhxEqttSYq, double vhADH, double dNfScWLTQn)
{
    double ikckEdAidXkQg = 851100.367401054;
    double CKHCPQvfWLDvA = 395869.09720166837;
    int DijQWVwJtdPmqh = 50044886;
    double aKZeDQeqCZhi = -573851.0347291232;
    int gUlYQLeVwOIOxYDk = 225340319;

    if (ikckEdAidXkQg < 395869.09720166837) {
        for (int ewSgIVso = 205008965; ewSgIVso > 0; ewSgIVso--) {
            continue;
        }
    }

    for (int fNBHwiFIHwhFGE = 624822640; fNBHwiFIHwhFGE > 0; fNBHwiFIHwhFGE--) {
        continue;
    }

    if (hjdkEHhxEqttSYq >= string("yYLsteDTwiJzFFRbiFmEvOiXrJAJxmGdNKIQqgvePMMyiHeoQXkveCnWsfMSPROXBppKxCjdIwhNpaKlsgkXintIhICbGLlkgsBpBbIgYaWxxBpxxgIThcagzJRbmhpXnIccZFHPypKNtyGjxBhhnhpiMnKyRcvhmKnfGqvlXaYaWaOXEAeCPBdsEQWXGnlvzqQTLMEe")) {
        for (int MsHZC = 922140725; MsHZC > 0; MsHZC--) {
            ikckEdAidXkQg -= CKHCPQvfWLDvA;
            ikckEdAidXkQg /= aKZeDQeqCZhi;
        }
    }

    for (int uMRrSvoBObkEmNn = 1658604508; uMRrSvoBObkEmNn > 0; uMRrSvoBObkEmNn--) {
        ikckEdAidXkQg -= aKZeDQeqCZhi;
        aKZeDQeqCZhi *= CKHCPQvfWLDvA;
    }
}

yYkZsKxmhyC::yYkZsKxmhyC()
{
    this->wqEqYWmlMhqhjfj(-1633267296, -1941930333, -96109.07256587668, true, -1335351291);
    this->PEOWblligSUJDdT(1139125066, -301403.4975117883);
    this->bhwhpgegyuRMzGxq();
    this->ObjKnOjSOBvap(-320733420, string("gaNusluAmeEoTdSF"));
    this->jnFDzjayvRULKYkd(string("MJpLExzUZrvvlLzUgnsFaEWPJKeqWmekZPZUBEvlXIFfzEzwmtcuYodVCpFmSHjawsFoGeQBXVSdnvIfiGuueNtYUMzuyDBlYnWLVdUrkbPeAiVIlryljwIKSlBNvpFtKccUHCQuxnmOEfFWGhyCfAbdGIMVYXaFkFHBqUknWsjbRXURPMMKyHKROHvdpvWIZesCHaRnFKoCMLVHZiTHAhyEWYSZNoGroKvUjmqTvADOZyJYguiXgaLeoTgUmDA"), true);
    this->jEpfhdds(10296.157420707885, 943466935, 612221.9737629887);
    this->YXMjvIGwOu(false, true, string("RGVOQQNIniuTbDQrJhSQHfuJTmQZasjJIxNIZJicqLcZRBKeosMRiOYeLGoXAWfzPHARgEnqdMCnUYnUfDqwqNUws"));
    this->LrwyPjoklAotgLb(string("CKdCspCeQCSdqTyVHsVWsZjtyEOPrmOPXGGAdlrPYvoWpBKunmrBv"), string("bwINzKtfrnhgCeArhCIGeqfDNquqDOgxOIVzFnXuvFqWkbBXODspRLHAOPaQBRLMKHSOUbmbHwVSlfdbANlGCndKNNQKhWiZAZMHBnNLsAuzcdanZoTObDetnLrZjcGlWBjfmOnODdYtEGhEgXHQGxiOgmwrUqsqpTckbhTDpPpfNtPmNaEgNiFvFYRtxdHuOrNZeQjugWGcIWDnPARBzNDCNrXkkVnVxW"), string("xYwmKupPABDqKsNYWauSxLImVptbAaGxanDqygkSRXanpzBfklzlnhnWFlmiCSBL"), -281504232, -533816638);
    this->kSktJMzSsDELP(false);
    this->rOxmn(string("yMnTepPXiMZHXRepOTjehEbAQPcVwCmlbfnoDpXHbQEDMNWFBjYjCUNIBjYaUFRshFFNunPXiuchPgXSQZJtKchZXnLdOQpSUAQAIAyGCbdMNcWHuXDBintICSNzPpONQUBPGVeQRhxWbdlJlurQgJaTBhGpcZqQPnGdkOTktRTPSUSFqFbAkeBByLmbensmU"), -1500490981, true, true, 248363.11170675512);
    this->uebOVcxKJAXmEF(-600166772, 553463.4423458361, string("NkcVecYKkeVWULWwzhaVOfdEuSKjviMXzwMtUSXiDDtpQtlOWVnzTvEYRjPDNRXTtyZT"));
    this->LxkmebBGg(-1500280950, -254127.33919239583, 687798.1564592761);
    this->Ldoijfm(-215998.47378692334);
    this->ERqpxxCAog(-1936700631, true, string("GVWeH"), true);
    this->NFLKvdjfR(80500.71876753583, string("fbWHeiZHtGmblNeorWLziSmqGgBwVmIVSOXFCoUZmgbnOrRZnKQBiLgPcVhtPJtHPxmsGjSLewXYflBPKpotBHQuGwCpNnDdMjzsrEIODKaZtCGEvctpBQgpSGfKoapVLZVPVeZYeLKPBJdmaGeVCotGDicWsVgXMRIYPFhyzrXFeyLHkr"), -1530648501, 660202.7149883474, -1904626311);
    this->llCQEToQLfoPoxsv();
    this->FjgCSOpUk(string("bPRjBQBvPOzYnqGbCawLmkEHGQPVNxwDGYcLhGeagwUBbuZegAaXfaE"));
    this->gfaCytVJUUsJUE(-486473.4391875765, 1033294.6764797331, true);
    this->XrxnulYxEAhfwt(true, -467013.2409262673, string("jUYVDSaXSSZUcLNsCqbSeCiafconiAViCWafEviUfQeYVyycTGrgwAmtGolXvNAvEeiGlYtQlGascvcLIjSWLUOMdVJCADBZvI"), -62332.379238735266, false);
    this->mlqTNow(-1913213006);
    this->FRPsMIKZYYo(119494.25995268107, 1482548432, string("qcFhdfsxvksoIQpVnxdXvcIoHzUXNcKzBVmBfuFNGNrUGEqbSpJSsZUsPGPumekyXBEwnHxzqieBmTMJEZhgTioqHjRKFiiitBOuLOoNLtwWCUaabnYtGZdbBTckKcaFwhZuXcFGDTUJYuXrAhIZPzFYFspVyHBzsXZpWPTLpAAIsPRaLADaMVrhrNHJWQJvQAjXXBtYWuwsIEsmpWkDtKUahZxdr"), -190848.59029407904, string("PjEjUPkNxQTuexryatMeMDOfxsIGMtxzVzJsuKbHHKHybyBwtyJUPFgXmhvXOHLkZCnNlpAOCPiJxDeNGWBsIgoddQHSWnvmzIzvdPBkRlytnJrdyQjmjHjUEQSMAjGrWmiocRBLkuUBCYbDywWPgalBOHhjpZItsJAUMqEIOfMEnXhWvUvtszpgTZCWpcivYDmRXCPeDGTgonQycCDntISQpNGRP"));
    this->mnqThtWiviM(-382337057);
    this->jCZEAo(false, string("yYLsteDTwiJzFFRbiFmEvOiXrJAJxmGdNKIQqgvePMMyiHeoQXkveCnWsfMSPROXBppKxCjdIwhNpaKlsgkXintIhICbGLlkgsBpBbIgYaWxxBpxxgIThcagzJRbmhpXnIccZFHPypKNtyGjxBhhnhpiMnKyRcvhmKnfGqvlXaYaWaOXEAeCPBdsEQWXGnlvzqQTLMEe"), string("prdljyoaSglRknAAzcRQPupoLXvcQVNzsxrrXWeVqBKUqQdFeugRtSnfMiaMfsfGhzkhrFTFIIzmufiuGqcKDxyrHHXkhPjUJhjUVyWwTXlmVUcUzIkXzMMqReWdVtdTgXsDiMxLGYrsqeSQhJLPWCyUrLmBCsEMteeYmuibqpjrCUcxrRKSGtfkFoLuLCDcoxCPCpLSjAGk"), 64897.94916834552, 978698.3129334755);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ncBdFm
{
public:
    int sTvdhxpvwgk;

    ncBdFm();
    bool aviNgjUhqieyE();
    int YiJLfWIoNReVePO();
    double XUPuHIBjWmP(bool UKTBgYiGyt, bool dioZdbCbp, string WKBQEekgQCQfQp, double YKqdjtF);
protected:
    double UuPxQjId;
    int uFNtsqoyczkRoAmW;
    string RuAHEd;
    int yjizWCoUAfUm;

    int jubbfVEng(double PRJlEfkiGax, int FdkcaampNKXbWv, int qkUPHQai, int YipJHIWJX);
    int cykWz(int KkerwubXTUdXKAje, bool jpvXNuvLQYJEUfMo, bool LmenRYaKvOKOERDD);
    bool epjmhIAHAbNalQdo();
    bool XWxiSTxoBJq(string xEEPigPgKxQYAVOW, string UStGdK);
private:
    int EVduA;
    bool kTfkMlIayk;
    string wSXorlFuDZZzghsF;
    double NbdIqRlPetPKy;
    double aZxwAnppyGNSZA;
    string nOkVBwgjTAIHbSAg;

    bool sJpOnyPcjRwE(double PBdHDtJfoAcPOAW, string TFSoYsa, int TfpSPcfCjesnzCY);
    string ZlqxKEBlcxOcD(string nnlKxiqvI, int IwJPYiZXpRgCbdRr, bool lnyEbAIved);
    double xBUUy(bool CtfKPmhibR, string umfQznUGifCN);
    string BgyMzXzNcLaZh(double MnqwowEN, double PpNPBpfFzBqPghed, double qQZHDTpEqeQWwvM, int UHTSIXiGciaAhVN, double kMxaGwbgzyV);
    bool zIhUhjWwgyWDbm(int iLKjCLBxoJxkoV, bool raoDWOtw);
};

bool ncBdFm::aviNgjUhqieyE()
{
    int XdWLaUAHnPEBXr = 537427381;
    int wgcXwpa = -1396711956;
    bool SLZKKp = true;
    int TxVGUVxQMiYW = 1411188908;

    if (SLZKKp != true) {
        for (int gqKBzx = 538779386; gqKBzx > 0; gqKBzx--) {
            XdWLaUAHnPEBXr += XdWLaUAHnPEBXr;
            SLZKKp = SLZKKp;
            XdWLaUAHnPEBXr *= XdWLaUAHnPEBXr;
        }
    }

    if (XdWLaUAHnPEBXr <= -1396711956) {
        for (int giJwhkrmAEnV = 84044639; giJwhkrmAEnV > 0; giJwhkrmAEnV--) {
            XdWLaUAHnPEBXr += wgcXwpa;
        }
    }

    if (XdWLaUAHnPEBXr <= 537427381) {
        for (int iupquzJnjwCN = 2006136386; iupquzJnjwCN > 0; iupquzJnjwCN--) {
            TxVGUVxQMiYW /= wgcXwpa;
            wgcXwpa *= XdWLaUAHnPEBXr;
        }
    }

    if (TxVGUVxQMiYW == 537427381) {
        for (int xitwjjbNSVNfDi = 828109843; xitwjjbNSVNfDi > 0; xitwjjbNSVNfDi--) {
            wgcXwpa *= TxVGUVxQMiYW;
            wgcXwpa -= TxVGUVxQMiYW;
            XdWLaUAHnPEBXr = TxVGUVxQMiYW;
            SLZKKp = ! SLZKKp;
            TxVGUVxQMiYW += wgcXwpa;
            TxVGUVxQMiYW += TxVGUVxQMiYW;
        }
    }

    return SLZKKp;
}

int ncBdFm::YiJLfWIoNReVePO()
{
    string MSttKJYo = string("WStTswgDDkMvGqrdHUIZkCJzxGQAUUyXqnmTHNZFnBosopwzgHORiNiCWWmgiaQFMeCbrlnoJVApSamUmRygntBrFsWQycDIbqCoDqICCorFrptrJh");
    int egSfonUaXIrfYlQ = -1440430485;
    double QkULcNA = 183320.79267609367;
    bool uCJKSpxw = true;
    bool VflEmH = false;
    string uTNBLRJXDsZ = string("szsClTxjOHEUOUtcJpFwiPkHzLoFNxSNexpMfCmBTfYaUHHStKWLDHYGtiqHqmOfNfepEHyXcSHwJzExOkUJwPNBPzxvYMohwHMenmQTAzMwPQOkBHHOVdDMZxRHkkfOpfiROUUQUlIWFbOxoMGTuBhgZSgwmOpkAkQFXVczkNTXYNfvzCBANHjBsqzynVDlgdwjneZLhfGUlCxHmlKpIIjQgR");
    string ybddVFg = string("yCsdqLoOTwucdApxBliupUTKBQAijcuuYAXqNnIcVbgyleZqsiyQLvLDaZfWXoyJfMiHTAYgqeZWNHfnBKBSXCXaEAFYtETbPDMzgZlUOnraYgzeeErJBJdbmwYRaYVppUXAvrnugjadtmmZRFMoUkUIwOLCa");
    string UJaPztlciG = string("bqGtEwOMLOidkQRgPnVhjCqYwaIstbFnOSbQkqJGKFRybhnyWKLBjFUcovXUREbDTyuxtuqjavumOhRoLBgfzfbqDjqmQmC");

    for (int kQuYYHiMxFFfrliJ = 176561674; kQuYYHiMxFFfrliJ > 0; kQuYYHiMxFFfrliJ--) {
        uCJKSpxw = ! uCJKSpxw;
        QkULcNA += QkULcNA;
        MSttKJYo = UJaPztlciG;
        uCJKSpxw = VflEmH;
    }

    return egSfonUaXIrfYlQ;
}

double ncBdFm::XUPuHIBjWmP(bool UKTBgYiGyt, bool dioZdbCbp, string WKBQEekgQCQfQp, double YKqdjtF)
{
    string Jrwui = string("bKkTnaXTIFHZDZgvMwNwJDUaqwYxOjGTVCNwcGxZnHoefcUFiYmGtTxIRDDDdMjqMsGGEnEAgiqPlRhe");
    int UKoxlFSY = -1825839351;

    return YKqdjtF;
}

int ncBdFm::jubbfVEng(double PRJlEfkiGax, int FdkcaampNKXbWv, int qkUPHQai, int YipJHIWJX)
{
    int NofJBNc = 1654430603;
    string uJNtBsRtviJMKih = string("GdYFzPsoeZAnpWikjiNQyINrYReTXTdaehOiIFxjFAyQEvQvRSzAqPabqnee");

    for (int YuQmCcibdqZ = 334131427; YuQmCcibdqZ > 0; YuQmCcibdqZ--) {
        continue;
    }

    if (FdkcaampNKXbWv == -829075662) {
        for (int DYyNnNPcI = 2094233929; DYyNnNPcI > 0; DYyNnNPcI--) {
            YipJHIWJX -= YipJHIWJX;
        }
    }

    for (int GnWjAZwyWxZ = 873917244; GnWjAZwyWxZ > 0; GnWjAZwyWxZ--) {
        qkUPHQai += qkUPHQai;
    }

    if (NofJBNc < -829075662) {
        for (int tEWIkOMS = 181697583; tEWIkOMS > 0; tEWIkOMS--) {
            NofJBNc += FdkcaampNKXbWv;
            NofJBNc += qkUPHQai;
            FdkcaampNKXbWv *= FdkcaampNKXbWv;
            NofJBNc -= YipJHIWJX;
            NofJBNc += YipJHIWJX;
            FdkcaampNKXbWv += NofJBNc;
        }
    }

    if (YipJHIWJX < -829075662) {
        for (int UPdlnrxI = 846729206; UPdlnrxI > 0; UPdlnrxI--) {
            continue;
        }
    }

    for (int RahFMgbTuX = 67329400; RahFMgbTuX > 0; RahFMgbTuX--) {
        qkUPHQai -= NofJBNc;
        qkUPHQai += qkUPHQai;
    }

    return NofJBNc;
}

int ncBdFm::cykWz(int KkerwubXTUdXKAje, bool jpvXNuvLQYJEUfMo, bool LmenRYaKvOKOERDD)
{
    double seOavv = 835173.5479646503;
    bool wRsDZ = true;
    bool gVuxM = false;

    if (jpvXNuvLQYJEUfMo == true) {
        for (int ykNLQNtqRMBmW = 734439802; ykNLQNtqRMBmW > 0; ykNLQNtqRMBmW--) {
            gVuxM = ! gVuxM;
            wRsDZ = jpvXNuvLQYJEUfMo;
            seOavv += seOavv;
        }
    }

    if (jpvXNuvLQYJEUfMo == true) {
        for (int WMgRqK = 996419563; WMgRqK > 0; WMgRqK--) {
            LmenRYaKvOKOERDD = jpvXNuvLQYJEUfMo;
        }
    }

    for (int BXMDRfoGMhhEri = 1883317053; BXMDRfoGMhhEri > 0; BXMDRfoGMhhEri--) {
        continue;
    }

    return KkerwubXTUdXKAje;
}

bool ncBdFm::epjmhIAHAbNalQdo()
{
    int doJIgvNcdijIWt = 288107750;
    int MAyGxEoi = -577560933;
    bool QXmYGAF = false;
    int TqgpEgwKHrPpazWB = -1322003091;
    double uFgNmgymeAQLn = 778811.2812195465;
    double JEtWrzrJOy = 223131.02726218486;

    for (int GTwGZqJsWUcvjWVh = 1238700092; GTwGZqJsWUcvjWVh > 0; GTwGZqJsWUcvjWVh--) {
        MAyGxEoi = doJIgvNcdijIWt;
        JEtWrzrJOy = JEtWrzrJOy;
        TqgpEgwKHrPpazWB -= TqgpEgwKHrPpazWB;
    }

    for (int cprMuz = 1698957222; cprMuz > 0; cprMuz--) {
        TqgpEgwKHrPpazWB -= MAyGxEoi;
    }

    if (MAyGxEoi == -577560933) {
        for (int pSSHrSQDFKJFc = 804761056; pSSHrSQDFKJFc > 0; pSSHrSQDFKJFc--) {
            uFgNmgymeAQLn = JEtWrzrJOy;
            MAyGxEoi += MAyGxEoi;
        }
    }

    if (MAyGxEoi == -577560933) {
        for (int PYJgBwbcAGt = 8486558; PYJgBwbcAGt > 0; PYJgBwbcAGt--) {
            TqgpEgwKHrPpazWB = MAyGxEoi;
            TqgpEgwKHrPpazWB *= MAyGxEoi;
            JEtWrzrJOy /= uFgNmgymeAQLn;
            QXmYGAF = ! QXmYGAF;
        }
    }

    return QXmYGAF;
}

bool ncBdFm::XWxiSTxoBJq(string xEEPigPgKxQYAVOW, string UStGdK)
{
    int YjCrxUDEkjgxU = -1289202990;
    bool huYWrqzNINQl = false;
    int OPzWzdHe = -2086653493;
    string UDqmhyOCdL = string("WlOTQlbFegENzxRqoyqMNncNjRFMtgKEXuinNXqfWvZVeJgQJKfroUsTxRtdIvFRRPVoSWOfdhFKzqRWPNySFubnmalhcZXb");
    double bKxbSLjvnLyxdvx = 598265.5077337624;
    double yOuYaNsbzz = 435736.69957765215;
    int eAwdLm = 1355507883;

    for (int mZQjjPJYRGSBnbN = 1335524964; mZQjjPJYRGSBnbN > 0; mZQjjPJYRGSBnbN--) {
        continue;
    }

    for (int BUtmqcokZc = 1102231064; BUtmqcokZc > 0; BUtmqcokZc--) {
        bKxbSLjvnLyxdvx *= bKxbSLjvnLyxdvx;
    }

    for (int cKsfAWGMJOLh = 1751881835; cKsfAWGMJOLh > 0; cKsfAWGMJOLh--) {
        continue;
    }

    return huYWrqzNINQl;
}

bool ncBdFm::sJpOnyPcjRwE(double PBdHDtJfoAcPOAW, string TFSoYsa, int TfpSPcfCjesnzCY)
{
    string ofFmh = string("Qol");
    double pMMjCRLlefRUT = -857655.9259324474;
    string OOXAFUZStWuUVgo = string("bgMpPavqbPPxWQbqJvvmddWcMOImTyYNaHRGkJxpxXrQKvVkoRxGeZsrLfwQwNAS");

    for (int ArLXfGYWzEVmFo = 158012460; ArLXfGYWzEVmFo > 0; ArLXfGYWzEVmFo--) {
        OOXAFUZStWuUVgo = ofFmh;
        pMMjCRLlefRUT = pMMjCRLlefRUT;
        ofFmh = TFSoYsa;
    }

    if (TFSoYsa != string("Qol")) {
        for (int gkBzNJHgbwYfjZJa = 1723681500; gkBzNJHgbwYfjZJa > 0; gkBzNJHgbwYfjZJa--) {
            PBdHDtJfoAcPOAW /= PBdHDtJfoAcPOAW;
            OOXAFUZStWuUVgo = TFSoYsa;
        }
    }

    if (ofFmh > string("bXpnuOPzVNPsKsKYturmtyAWgCtENTkSZiBYpKqSEdgtIUvVozwgeGXbpdBmUZSmSrVZnOVfu")) {
        for (int jsbtaJeM = 784689331; jsbtaJeM > 0; jsbtaJeM--) {
            ofFmh += TFSoYsa;
            ofFmh += OOXAFUZStWuUVgo;
            OOXAFUZStWuUVgo = OOXAFUZStWuUVgo;
            TFSoYsa += TFSoYsa;
            pMMjCRLlefRUT += pMMjCRLlefRUT;
            pMMjCRLlefRUT /= PBdHDtJfoAcPOAW;
        }
    }

    return false;
}

string ncBdFm::ZlqxKEBlcxOcD(string nnlKxiqvI, int IwJPYiZXpRgCbdRr, bool lnyEbAIved)
{
    bool eVwWJhYvz = true;
    double CYlZKvyzrxN = -721282.1982911286;
    int QejeFF = -163254564;
    double plLNkW = 46685.94108381449;

    for (int bBYRqjefgMFml = 465995891; bBYRqjefgMFml > 0; bBYRqjefgMFml--) {
        IwJPYiZXpRgCbdRr *= IwJPYiZXpRgCbdRr;
    }

    for (int VjLVdi = 2025000084; VjLVdi > 0; VjLVdi--) {
        continue;
    }

    return nnlKxiqvI;
}

double ncBdFm::xBUUy(bool CtfKPmhibR, string umfQznUGifCN)
{
    int MMJdHtNu = -1881055081;
    double SlzwNjXOyXsO = -198574.50185996675;
    double TChipKg = 688162.0761449545;
    int jNUOhVaIAXrljz = -25081952;

    for (int muSDEGxXsNi = 773378286; muSDEGxXsNi > 0; muSDEGxXsNi--) {
        CtfKPmhibR = ! CtfKPmhibR;
    }

    for (int toFkrpKA = 112143594; toFkrpKA > 0; toFkrpKA--) {
        continue;
    }

    return TChipKg;
}

string ncBdFm::BgyMzXzNcLaZh(double MnqwowEN, double PpNPBpfFzBqPghed, double qQZHDTpEqeQWwvM, int UHTSIXiGciaAhVN, double kMxaGwbgzyV)
{
    string iJwPab = string("CmxmeTTTKGKIryoyvABuBBohiRoElhfFFtQmCnwnFoZSoCXPruxJV");
    double wprCtpel = -651043.0441539227;
    string lktYoNWz = string("qEkaSexxIwuyCtflhaqZlEEziIvVtpAUPhiMixvLlHjFuRGFyfevoYZUwuGZDheDNCBqzkwskOuZYuqGsl");
    double GVJOzvB = 261357.52368663857;
    int dVkuYQjGEu = -735729943;
    bool rlEyVZxjmYHNSYb = false;
    double PukgLYhIvHVXo = -828936.1210539914;
    bool wtLYAKwfsVFcV = true;
    bool mUchKqjUW = false;
    bool fHjeSYtFjmVl = false;

    if (wprCtpel < -301121.0593116187) {
        for (int rVTQvMQL = 397310514; rVTQvMQL > 0; rVTQvMQL--) {
            PpNPBpfFzBqPghed *= GVJOzvB;
            UHTSIXiGciaAhVN -= UHTSIXiGciaAhVN;
        }
    }

    for (int INbndAx = 821593697; INbndAx > 0; INbndAx--) {
        continue;
    }

    if (PpNPBpfFzBqPghed == -484994.43088393554) {
        for (int UWrLLdCBCNUA = 1389639670; UWrLLdCBCNUA > 0; UWrLLdCBCNUA--) {
            continue;
        }
    }

    if (PpNPBpfFzBqPghed >= -301121.0593116187) {
        for (int gKrgAyyBITzrTZez = 1093528923; gKrgAyyBITzrTZez > 0; gKrgAyyBITzrTZez--) {
            MnqwowEN /= PpNPBpfFzBqPghed;
        }
    }

    return lktYoNWz;
}

bool ncBdFm::zIhUhjWwgyWDbm(int iLKjCLBxoJxkoV, bool raoDWOtw)
{
    string qTBqCnmqxvDZ = string("DNyXTSnnBlYxEjBwGGFtFptfNBLhtYHjzyJwmTMxgCMNYTxYRgzVvDavDpJcXokqaxaUeeKesGUqunXSiuiTBgSmFfvNSKcANWbCRdEaRNGUDe");
    int XqXbVluYGjf = -910887477;
    double pTktkAjagjDoFbZO = -26310.97676377637;
    bool XLuXUGUhl = true;
    string uiwjV = string("UWNTSZWvPRpJTZTHjiazaTHhEvtIIDcjzrBBYhZQFiLsOdtICpBywjDztiUydWcnrTHJtqPnFsYYgmDIqQZycjQQDJFcOPnWuUFoOUOPEOLhenYrCZKpBqfHRlisgSGoVoasyOgMaBbbwGchpLsUUCMONttAYiYAz");
    string RmTCuaQoM = string("ggNFBfzdXnHHTXdfCYiVmQFlnkpLzWWDhsDfDEEWNtWiycnjqTPZHNGXIJjuKqnjYpsJwJmjbYvtQqXMorzSXPicQTCvbbUizbtVRvipNPhQbCyILYHvLAawahPOacDOrVXjbCBSNxpXPaoRVUiMLtIaaiprnZSAfFjltVPdjwyZLQAgWZehHEqNixgVTflAVZvadGUNwqcRkDnLzitBOalXKg");
    string gZEtTCefR = string("aIjElTqKBvlwRzexllyuitMjoyOOauBXgejeATnVjPoSCmlTWAOXcJtDkZVtxEWhczThGLbIgzPePhOIEORqHSscapjPlvPIuvWvQBlM");
    double vjcjz = 726528.88919715;

    if (vjcjz != 726528.88919715) {
        for (int xCKXiCynHTJImtB = 174819262; xCKXiCynHTJImtB > 0; xCKXiCynHTJImtB--) {
            gZEtTCefR += RmTCuaQoM;
        }
    }

    if (gZEtTCefR == string("ggNFBfzdXnHHTXdfCYiVmQFlnkpLzWWDhsDfDEEWNtWiycnjqTPZHNGXIJjuKqnjYpsJwJmjbYvtQqXMorzSXPicQTCvbbUizbtVRvipNPhQbCyILYHvLAawahPOacDOrVXjbCBSNxpXPaoRVUiMLtIaaiprnZSAfFjltVPdjwyZLQAgWZehHEqNixgVTflAVZvadGUNwqcRkDnLzitBOalXKg")) {
        for (int IKFRvCRzGzKg = 1562846758; IKFRvCRzGzKg > 0; IKFRvCRzGzKg--) {
            iLKjCLBxoJxkoV /= XqXbVluYGjf;
            RmTCuaQoM = qTBqCnmqxvDZ;
            uiwjV += qTBqCnmqxvDZ;
        }
    }

    for (int rMdpGbGTFzebolB = 1474687364; rMdpGbGTFzebolB > 0; rMdpGbGTFzebolB--) {
        qTBqCnmqxvDZ = uiwjV;
        gZEtTCefR += qTBqCnmqxvDZ;
        uiwjV += gZEtTCefR;
    }

    if (uiwjV == string("UWNTSZWvPRpJTZTHjiazaTHhEvtIIDcjzrBBYhZQFiLsOdtICpBywjDztiUydWcnrTHJtqPnFsYYgmDIqQZycjQQDJFcOPnWuUFoOUOPEOLhenYrCZKpBqfHRlisgSGoVoasyOgMaBbbwGchpLsUUCMONttAYiYAz")) {
        for (int kpzddViIjMfTAq = 1971561283; kpzddViIjMfTAq > 0; kpzddViIjMfTAq--) {
            continue;
        }
    }

    for (int DqTfSp = 1915195811; DqTfSp > 0; DqTfSp--) {
        uiwjV += uiwjV;
        gZEtTCefR = qTBqCnmqxvDZ;
    }

    return XLuXUGUhl;
}

ncBdFm::ncBdFm()
{
    this->aviNgjUhqieyE();
    this->YiJLfWIoNReVePO();
    this->XUPuHIBjWmP(false, false, string("odXgqtRUupAwSDQkFofLKpxraPdXhcADhPNodNXNBYFTzLLf"), 52319.29447188704);
    this->jubbfVEng(-773010.9494820421, 1470094745, -1331590378, -829075662);
    this->cykWz(-463479017, true, true);
    this->epjmhIAHAbNalQdo();
    this->XWxiSTxoBJq(string("VsaUTLjzMgInZxgJpNiMEVkIERS"), string("PqLawsDGIlRoDdaaDoygZrhqfqrRMwClEUtTBTmahJAaLEQWMNNEFwTwhgFNVXAborZavzwbpwzSCtsTEsdmlpFyBJeojbHgFUtsLMxByulxDpFIuDVyctHzXlQPYwLyoKCAwDWMXxUFBBoWURhkodmazIPDjvHhGbhnKiDIQjzEFKJlndghCJAmilphCvs"));
    this->sJpOnyPcjRwE(986193.4692284435, string("bXpnuOPzVNPsKsKYturmtyAWgCtENTkSZiBYpKqSEdgtIUvVozwgeGXbpdBmUZSmSrVZnOVfu"), 1870084082);
    this->ZlqxKEBlcxOcD(string("WOUwJVaCbIOmvFSXYNpPuUSkMxkbBmfteJFpSGCcctbisDRLxFnJvRcauejzjSTQiHbmIuhvQzzxtYaVepdJInGSkKYGOGpGxkSjKSnMmaXAOMwOCxykZRfsDoBWYaHRbaNBWlWpKInkbdCoRLWhNoUPDVgamPoImZSvdMBfjglHPLuCGgEIlfXXKMaFUNO"), -570196105, false);
    this->xBUUy(false, string("sMfqkMoctpCYxLpHwpaGIWGgMvNjpjku"));
    this->BgyMzXzNcLaZh(-301121.0593116187, 704746.9703473599, -484994.43088393554, 222446629, 225362.69080827528);
    this->zIhUhjWwgyWDbm(1841979232, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hrjUYdGhsnOqSXp
{
public:
    int QpeBpzbi;
    bool nrYNHV;

    hrjUYdGhsnOqSXp();
    int dHGWMnT(double VQOMVhLxwngYbNz, string uazSWnJL, string ZVLpyIJnQjX, string VWMnQiWp);
    void gHVZcXX(double evCKCGSqN, bool cidJzS, int ebVMvmEcRlRt);
    string mgBtFlc(double gcEAAAk, string QxYGorCyVN, bool nIKnysKbmXlQF);
    void gnYDssPYVoDwr(string mwTYGFBizLFjoIk, int KxVUs, bool OfDbpYGHh, int ZscTnY, int LzXXnLFAxYk);
    double BdzqPOYCT(string SaunaGPKaewVz, string gFzeYXspkPzH);
    double UvEExx(string jDTkeCDvPB, bool qoOpB, bool VFttEEzVdx, bool sMOAHvfid, bool zhzDgpXHkCfrBgYr);
    bool LnIgOJnUdR(int WNyZyiWy, int tSLXchosXeNsWBg);
    string mMCRjTetjgzA();
protected:
    bool PFrsXa;
    double bilVWWznbXBPREE;
    int ZgvMNmLdLMLC;
    string dFdmvyRGPdwYA;

    double jtSclbtLSH(string cmhbr, bool rFLXxPAfcepDV);
    bool obOdTlfD();
    bool texrE(bool LKoVzRIeBzWDVhal, int vaKVlJDgQovD, int lsSvbJ);
    int JnlgdwvapdyQbe(double CUspuBnfi, int oZfML);
    int FIOPiOpZsLrB(int zCqbIaUxBbfqO);
private:
    string eXyhmLgLQA;

    bool TZJGWyjWxCK();
    string VUulLpKA();
    bool GzCRVHuMSgIh(string KiAlfMLtP, bool diYokQyeJVORG, bool yxMfWny, double KVMZprjcAaxOZZh, int YMiUwchm);
};

int hrjUYdGhsnOqSXp::dHGWMnT(double VQOMVhLxwngYbNz, string uazSWnJL, string ZVLpyIJnQjX, string VWMnQiWp)
{
    int yUBWtEdVbgFwE = -1376620030;
    bool RdfAG = true;
    string NEpvhwAlSgJ = string("ARyhjYPVAOtebPixDUiTeznJgWPzwrEuWDmYeCnNTEZxvClZqklBnIKEBPCiggSTfrjnccAbVTlwkTmqEDZqjefGisguRXyiCNUwVNCpnOcbXYmvmNpKTLzvShnSIJOxNIfqyVDXgQjHoObeGBhROTTvWvsVYuJDxcsQjLHzdXlJoTSiNipgiApcHvtIeFUsbQmgezpLkiGjCcPFxvWoNkUnyTzmgdxNfMBrOMoJjqTsq");
    string jinsjyac = string("TYWXhTKMUqpDrYlCyWgBKPLuVryjemeWZMBIwyWXUnjigezcdsDUqgygzrfzHETOmmCZZzdzwohJZCHGUgeIqzfOcEMHHenRtaydUeoSfPefuyMoBDyWZKVfaKgSWnsQanqLJOQcGfySlASHfJUdJauawgocQJiPMbnbEZjuaKXOvtDHubzIrARFx");
    int zpUqmkv = -68831905;
    int uMQSOPoWkeCUuHHb = -1733619074;
    int mlfOydJFTzO = -280749443;
    string Iqlvy = string("lEIXFoXkkIuKSZHiwQtybw");

    if (ZVLpyIJnQjX != string("yBIxszrMKmwdoSDxzauKZnVLyidaiInfSDKHyqkFZZdlmHVGXEJydfaHwaJSOKvvPhPVemXBSzkpFrZZyrroCkeKBYfAzIdvMarfivrSNxUQtxiBsChPWhyCLCBSBtMLBuVpZoLmuoG")) {
        for (int GGfAUIi = 1713887152; GGfAUIi > 0; GGfAUIi--) {
            uazSWnJL = NEpvhwAlSgJ;
        }
    }

    if (uazSWnJL > string("PeAkZAukvFIzAmvEUSWOVzgkKYOyxMzEwHDYUIPCTqttojqqeuvplhnRIZYusHzcnKltuBQcuKMfNtkWLvRTfmsSeFtCnajIVyaUoncSrbIwUrGvYCLuVwITHABGHCczxMPCmcqkBYdzWVqYkdwXaHfWwMplXdOvreNYkoATdXXrmxSRDhvPZgjBPSeAfadZuZrJyEMQVLZDwlzuTWNQgxJgYbUMAthBAZtcHlsCpwLiesDQKi")) {
        for (int kjKWWmi = 1277957996; kjKWWmi > 0; kjKWWmi--) {
            Iqlvy += ZVLpyIJnQjX;
            uazSWnJL = Iqlvy;
            NEpvhwAlSgJ = ZVLpyIJnQjX;
            NEpvhwAlSgJ += jinsjyac;
            VWMnQiWp = VWMnQiWp;
        }
    }

    if (Iqlvy == string("PeAkZAukvFIzAmvEUSWOVzgkKYOyxMzEwHDYUIPCTqttojqqeuvplhnRIZYusHzcnKltuBQcuKMfNtkWLvRTfmsSeFtCnajIVyaUoncSrbIwUrGvYCLuVwITHABGHCczxMPCmcqkBYdzWVqYkdwXaHfWwMplXdOvreNYkoATdXXrmxSRDhvPZgjBPSeAfadZuZrJyEMQVLZDwlzuTWNQgxJgYbUMAthBAZtcHlsCpwLiesDQKi")) {
        for (int sjkwDxKvwk = 785036591; sjkwDxKvwk > 0; sjkwDxKvwk--) {
            continue;
        }
    }

    for (int twLDu = 1828666581; twLDu > 0; twLDu--) {
        yUBWtEdVbgFwE *= zpUqmkv;
        uazSWnJL = NEpvhwAlSgJ;
    }

    return mlfOydJFTzO;
}

void hrjUYdGhsnOqSXp::gHVZcXX(double evCKCGSqN, bool cidJzS, int ebVMvmEcRlRt)
{
    bool RIBUHUQiHDFomc = true;
    int tJcRyZxeRfV = 2137749164;
    int psImBqCVBRmOgR = -617745949;
    bool wcCSvJnNFaE = true;

    for (int mzpOIXJyMXzFJqk = 1768162224; mzpOIXJyMXzFJqk > 0; mzpOIXJyMXzFJqk--) {
        evCKCGSqN /= evCKCGSqN;
        RIBUHUQiHDFomc = ! cidJzS;
        wcCSvJnNFaE = cidJzS;
    }
}

string hrjUYdGhsnOqSXp::mgBtFlc(double gcEAAAk, string QxYGorCyVN, bool nIKnysKbmXlQF)
{
    bool VCBQgnySedoVLkiC = true;
    int nbqQhyAcc = 1884596663;

    for (int dWrozCuSnVCqGP = 1171179542; dWrozCuSnVCqGP > 0; dWrozCuSnVCqGP--) {
        gcEAAAk -= gcEAAAk;
    }

    for (int ZZswUKyerlUI = 755766630; ZZswUKyerlUI > 0; ZZswUKyerlUI--) {
        continue;
    }

    return QxYGorCyVN;
}

void hrjUYdGhsnOqSXp::gnYDssPYVoDwr(string mwTYGFBizLFjoIk, int KxVUs, bool OfDbpYGHh, int ZscTnY, int LzXXnLFAxYk)
{
    bool cdoTIVMAFIRBKdY = true;
    double WaigqqXiUA = 764259.8776486173;
    string vjoUm = string("LxmMvshxUvHRwhZDCEbHRcEEZKHcouAKKuYqolkERCecXKQCAfsQhKRxGVlcFJJdfmlOybAyRsYHJLTRHEhvYYrIHEgEHrNVsnYaSREdQZdvoN");
    int fYSuVgvK = -467214241;
    bool jxYGcSZpJkz = false;
    int JyKmCo = 1908027102;
    bool qKapnCXywgyTjB = false;

    if (fYSuVgvK <= 1908027102) {
        for (int npYItrbUBixT = 1028108449; npYItrbUBixT > 0; npYItrbUBixT--) {
            fYSuVgvK *= KxVUs;
        }
    }

    for (int ydVLXqkzMdt = 1783732246; ydVLXqkzMdt > 0; ydVLXqkzMdt--) {
        fYSuVgvK = KxVUs;
        jxYGcSZpJkz = ! OfDbpYGHh;
        OfDbpYGHh = qKapnCXywgyTjB;
        JyKmCo *= JyKmCo;
    }

    if (fYSuVgvK <= -467214241) {
        for (int RcuvMWivVdc = 1213056076; RcuvMWivVdc > 0; RcuvMWivVdc--) {
            continue;
        }
    }
}

double hrjUYdGhsnOqSXp::BdzqPOYCT(string SaunaGPKaewVz, string gFzeYXspkPzH)
{
    int ejhHygZmLKBi = 303666296;
    string PwQpaCSPLCPvs = string("RtOwPifXwPzfOKNMWLRHUdloXjLnmQMFLeCyAgxrjbHsZiHdDamneAVvqtMfKAitJvDZCHJTfzvZOvtzYhePhhNthDOwKJIqgRXAJqwrgtNAfjyZqayKxfColETXSWfQrzwjAShgNrSwKmNNlnXYaOsFFNGGNDcdBcUIAVtiwFFQZvvvQHhZBQpmiWMSmabPvlBXKZdIQUwNjqXTqrLP");
    string kbsHOZLpSbniyLcy = string("MRzHFmxfezgbkTtbngKnxEfgqYVNruNXFquhFsCzCOvDzYYKzmurPQacpoASHSkQBkFuBgTPdRQpersoOQuLUMPJgHRA");
    int AGUsEuoVEJX = -778859900;
    bool xluqFtIo = true;
    double VXHBZIjMKdJ = -919898.3006793311;

    for (int kwIfMjwYDJRxVh = 345213995; kwIfMjwYDJRxVh > 0; kwIfMjwYDJRxVh--) {
        ejhHygZmLKBi /= ejhHygZmLKBi;
        xluqFtIo = ! xluqFtIo;
    }

    for (int qGvfCjSsDvtESC = 578380577; qGvfCjSsDvtESC > 0; qGvfCjSsDvtESC--) {
        gFzeYXspkPzH = kbsHOZLpSbniyLcy;
        xluqFtIo = xluqFtIo;
    }

    return VXHBZIjMKdJ;
}

double hrjUYdGhsnOqSXp::UvEExx(string jDTkeCDvPB, bool qoOpB, bool VFttEEzVdx, bool sMOAHvfid, bool zhzDgpXHkCfrBgYr)
{
    double KCQkbpPBX = -769586.2789521958;
    double ERBoxGsWNujRr = -752244.1832357779;
    bool cTplgJLaDLb = true;
    bool meawmK = false;
    int DzVLYijAmlPz = -1540658039;

    if (meawmK == false) {
        for (int ERAUnetyQ = 2011001455; ERAUnetyQ > 0; ERAUnetyQ--) {
            KCQkbpPBX /= KCQkbpPBX;
            DzVLYijAmlPz = DzVLYijAmlPz;
            meawmK = zhzDgpXHkCfrBgYr;
            sMOAHvfid = qoOpB;
        }
    }

    if (VFttEEzVdx == true) {
        for (int KLhirBCrkXCYs = 247061388; KLhirBCrkXCYs > 0; KLhirBCrkXCYs--) {
            cTplgJLaDLb = VFttEEzVdx;
            zhzDgpXHkCfrBgYr = ! qoOpB;
            qoOpB = ! VFttEEzVdx;
        }
    }

    for (int cUoyWfEwpOrR = 2082423664; cUoyWfEwpOrR > 0; cUoyWfEwpOrR--) {
        zhzDgpXHkCfrBgYr = ! qoOpB;
        sMOAHvfid = cTplgJLaDLb;
    }

    return ERBoxGsWNujRr;
}

bool hrjUYdGhsnOqSXp::LnIgOJnUdR(int WNyZyiWy, int tSLXchosXeNsWBg)
{
    int aQfjdZpO = -423229346;

    if (WNyZyiWy >= -955600434) {
        for (int crbIdiIEQFzK = 1425595838; crbIdiIEQFzK > 0; crbIdiIEQFzK--) {
            tSLXchosXeNsWBg *= tSLXchosXeNsWBg;
            aQfjdZpO += tSLXchosXeNsWBg;
            aQfjdZpO -= aQfjdZpO;
            aQfjdZpO -= aQfjdZpO;
            WNyZyiWy /= WNyZyiWy;
            tSLXchosXeNsWBg -= aQfjdZpO;
            tSLXchosXeNsWBg += tSLXchosXeNsWBg;
        }
    }

    if (aQfjdZpO < 667997026) {
        for (int JpvJMrArkiA = 45555593; JpvJMrArkiA > 0; JpvJMrArkiA--) {
            aQfjdZpO *= WNyZyiWy;
            aQfjdZpO = tSLXchosXeNsWBg;
            tSLXchosXeNsWBg *= aQfjdZpO;
            WNyZyiWy = tSLXchosXeNsWBg;
        }
    }

    return false;
}

string hrjUYdGhsnOqSXp::mMCRjTetjgzA()
{
    string SteiUdh = string("KZNBbovHAJyQrUNOhEvFgrvuZjeruJRYdbdkKMbBPwmMEKgyCyhorppFanvCVtOdpQVfMcArMkPMRFlheYixqpZAGAOQJYNSARirNsqxqzPjGbADcjlauofIQdqystZvMlQxIWhNYtFbjwWQFnHPpURrCHcAIqLUbSeJQtBmSsuLmevszPOJXWxmDQgadrseEPuQoDTSezHPWSjLsPUegYKDhGNTDWgXMquNMiexcFtXAGYeDseryRUyWlJpVs");
    int TqWALoXTrIHthNvU = 1847324998;
    string RuAVFjAejTXdU = string("ZnXRzvUIQkNMdMWzvAywvKjXlGFBRUzwhrIHtEeYmaERfwKdLtnEONuiDPIMZXbjcPScgeGJyJyzntFpaQwjxdmKTaDYosDpNNTHfvsKVTUdiLyyznHKRGEdXtOvJkUbFoscqTtVavUhpfdxUFcsTOVgHvNHJKPSxnlncgIcmLANyytrFhh");
    int ibPCxRKAlubkUM = -198775562;
    double EppHUAoiNQHvLzAB = -543512.8800160345;
    bool abloHofaw = true;

    return RuAVFjAejTXdU;
}

double hrjUYdGhsnOqSXp::jtSclbtLSH(string cmhbr, bool rFLXxPAfcepDV)
{
    bool pqrFaDt = false;
    double SsGWNE = -886801.6247935096;

    for (int nYHKGRyuNuPw = 448456873; nYHKGRyuNuPw > 0; nYHKGRyuNuPw--) {
        pqrFaDt = ! rFLXxPAfcepDV;
    }

    if (rFLXxPAfcepDV == true) {
        for (int qROwcLyfw = 1721664969; qROwcLyfw > 0; qROwcLyfw--) {
            rFLXxPAfcepDV = rFLXxPAfcepDV;
            cmhbr += cmhbr;
            pqrFaDt = rFLXxPAfcepDV;
            SsGWNE += SsGWNE;
        }
    }

    for (int hWNmrXfYcqrlKlN = 221830205; hWNmrXfYcqrlKlN > 0; hWNmrXfYcqrlKlN--) {
        pqrFaDt = pqrFaDt;
    }

    return SsGWNE;
}

bool hrjUYdGhsnOqSXp::obOdTlfD()
{
    bool IvIYHm = true;
    bool ZSwcvhOBWaEylNA = false;
    int pEMXeEggoJbODi = -11540263;
    double JxZdHJrqcXnTW = -882114.6979993708;
    int EHTtnWavtTAxzqK = 1191976295;

    for (int JPNcrWwyBAbxewJM = 1548885037; JPNcrWwyBAbxewJM > 0; JPNcrWwyBAbxewJM--) {
        pEMXeEggoJbODi -= pEMXeEggoJbODi;
    }

    return ZSwcvhOBWaEylNA;
}

bool hrjUYdGhsnOqSXp::texrE(bool LKoVzRIeBzWDVhal, int vaKVlJDgQovD, int lsSvbJ)
{
    int caWBvNU = -66990650;
    double bBvSFXSrIo = 490304.36606289574;

    for (int nbYTaqPzr = 1860114371; nbYTaqPzr > 0; nbYTaqPzr--) {
        vaKVlJDgQovD *= caWBvNU;
        caWBvNU = vaKVlJDgQovD;
        bBvSFXSrIo *= bBvSFXSrIo;
    }

    for (int EjryUlbLTmWgp = 1182661417; EjryUlbLTmWgp > 0; EjryUlbLTmWgp--) {
        bBvSFXSrIo -= bBvSFXSrIo;
        LKoVzRIeBzWDVhal = ! LKoVzRIeBzWDVhal;
        lsSvbJ -= vaKVlJDgQovD;
        caWBvNU /= lsSvbJ;
    }

    if (lsSvbJ == -768971019) {
        for (int GdaEtDAzIaAmxyy = 185909808; GdaEtDAzIaAmxyy > 0; GdaEtDAzIaAmxyy--) {
            caWBvNU *= vaKVlJDgQovD;
        }
    }

    return LKoVzRIeBzWDVhal;
}

int hrjUYdGhsnOqSXp::JnlgdwvapdyQbe(double CUspuBnfi, int oZfML)
{
    bool dAFRmMUgox = false;
    string oakXdWWMtmv = string("YjSSkhPEYVWmgNUBiGIUfGwMpdlsmwmwuDoPvgSqSrwvlrGLoZkKGvkBJsoDidhihxVKCqnZRZLZGARvwZIeosazcVQqsrbBTBgvbFbRYENAFcGMEVBRUyqcETzGdOgjmSInUqhqBHiHhfowBgdyZa");
    bool BkOGcxLYPTC = true;

    return oZfML;
}

int hrjUYdGhsnOqSXp::FIOPiOpZsLrB(int zCqbIaUxBbfqO)
{
    string jVzeDndCEHfiRJ = string("HXwygsMfPTCtOMLrzzghbByzezfoZykReQiZxueaEKseDatpHb");
    double LeRcWh = -798321.9027812653;
    double DmXmjFneZupfkdZZ = -347799.1296264277;
    int aMJqoN = -2060828548;
    string IHauWZoZMr = string("HexMlCmovdQJPZyCxyrnjyCDDnPKsznsVqgpuraCZvzQwNZFjsDYtzhOrHqEhMYAXYIOQlJeTDtbGzhRtsFSglrzHHDwqGKBdcTjlAWUragPrCvCOImnPlSugTnL");
    double suGSOi = -325129.8459884799;
    string ysZYEA = string("PkgGaLkQcdOJBemIpWVGlkhzGiRmiLeTNnULpnSByFHXigyJKNwBcAWRcDZsjfFnKAuSGtYQcDadkVqICcBqjOxXlCCNQzPZOQzomFXofUULgrjhFrZbRAQZkixCjHjaDwlZfOrxOTtswHKqRwehLBqXhohOhwNkkflDpPhPBCOBWYjfJnIYCCoBhCLRYpSNnEPxQKKxirkjLoCQVMCKMSPhQuCmbEfYOVFXvLvYfyV");
    bool TPXXMkHC = false;
    double oUIGqt = 775926.4710234918;
    string eIUSaVPWtt = string("XsAJmybIjzQgnCNiwExBzIWGXEvBvtQBIpePzLxsApzfWDqnIbJHyIeXufGLEFqGkbddDkFXoGXCJXSYfFtOuQpv");

    for (int pvQeMtAD = 1877493188; pvQeMtAD > 0; pvQeMtAD--) {
        suGSOi *= DmXmjFneZupfkdZZ;
    }

    for (int xTENxfllmGvA = 250418430; xTENxfllmGvA > 0; xTENxfllmGvA--) {
        continue;
    }

    for (int wGUeVONwM = 1065930321; wGUeVONwM > 0; wGUeVONwM--) {
        IHauWZoZMr += eIUSaVPWtt;
        eIUSaVPWtt += ysZYEA;
        DmXmjFneZupfkdZZ *= DmXmjFneZupfkdZZ;
    }

    for (int JDIIAqsBGw = 1493376538; JDIIAqsBGw > 0; JDIIAqsBGw--) {
        jVzeDndCEHfiRJ += IHauWZoZMr;
    }

    return aMJqoN;
}

bool hrjUYdGhsnOqSXp::TZJGWyjWxCK()
{
    bool gaTbl = false;
    double SyQBU = -864523.9334748287;
    double jlUFAhXeiokggDw = 762492.113940601;
    double YAALrvzdPxP = 836190.2345814123;
    bool UZDMHS = false;

    if (gaTbl != false) {
        for (int jeywBmCgtH = 907888327; jeywBmCgtH > 0; jeywBmCgtH--) {
            YAALrvzdPxP -= YAALrvzdPxP;
            SyQBU *= YAALrvzdPxP;
            gaTbl = UZDMHS;
            UZDMHS = ! UZDMHS;
        }
    }

    if (gaTbl == false) {
        for (int OxEaUkcdYEjQhw = 963170337; OxEaUkcdYEjQhw > 0; OxEaUkcdYEjQhw--) {
            SyQBU /= SyQBU;
            SyQBU += SyQBU;
            SyQBU = YAALrvzdPxP;
            YAALrvzdPxP *= SyQBU;
        }
    }

    for (int nqOJKCCRlqEr = 2010730908; nqOJKCCRlqEr > 0; nqOJKCCRlqEr--) {
        UZDMHS = ! UZDMHS;
        YAALrvzdPxP = SyQBU;
        jlUFAhXeiokggDw *= SyQBU;
        UZDMHS = UZDMHS;
    }

    if (UZDMHS != false) {
        for (int qrhyba = 1987463925; qrhyba > 0; qrhyba--) {
            SyQBU /= jlUFAhXeiokggDw;
            YAALrvzdPxP *= YAALrvzdPxP;
            UZDMHS = ! UZDMHS;
            UZDMHS = UZDMHS;
            UZDMHS = ! gaTbl;
        }
    }

    return UZDMHS;
}

string hrjUYdGhsnOqSXp::VUulLpKA()
{
    double gmEtzBp = -115228.3290610296;
    string mpEPbLrcQAKN = string("pCIqvEqYDDSzcmOJhbyxOPeVTHGUrdtJumfsWizRrhHnNTVplvYxEeiWeEwBhhgMbBVCsjgoanmBnJEgAjsndnryfbQRRLnKiYQUbpAvxWvJAcvNOMigBgJwnfdlfVXgbnYetxpUPNQLJtYuCmRVNVXkfFwzNAtYkDyuMMMFYRUISgmiNpgxxqtBFfeKdErXOvJefdiyiKRwHeAyfwgUKaduoMoFlUjOKbRzKyGBsmEwvEPNbQKalarEY");
    string FUzeedIYshIj = string("WcrugCTaWQJGcKz");

    for (int PbXbyTsV = 1386129993; PbXbyTsV > 0; PbXbyTsV--) {
        mpEPbLrcQAKN = FUzeedIYshIj;
        mpEPbLrcQAKN = mpEPbLrcQAKN;
        gmEtzBp /= gmEtzBp;
        gmEtzBp -= gmEtzBp;
        FUzeedIYshIj += mpEPbLrcQAKN;
        mpEPbLrcQAKN = mpEPbLrcQAKN;
    }

    if (FUzeedIYshIj != string("WcrugCTaWQJGcKz")) {
        for (int QLXHidsqjciQ = 1206909898; QLXHidsqjciQ > 0; QLXHidsqjciQ--) {
            gmEtzBp /= gmEtzBp;
            FUzeedIYshIj += mpEPbLrcQAKN;
            mpEPbLrcQAKN = FUzeedIYshIj;
            mpEPbLrcQAKN += FUzeedIYshIj;
            FUzeedIYshIj += mpEPbLrcQAKN;
        }
    }

    if (mpEPbLrcQAKN <= string("pCIqvEqYDDSzcmOJhbyxOPeVTHGUrdtJumfsWizRrhHnNTVplvYxEeiWeEwBhhgMbBVCsjgoanmBnJEgAjsndnryfbQRRLnKiYQUbpAvxWvJAcvNOMigBgJwnfdlfVXgbnYetxpUPNQLJtYuCmRVNVXkfFwzNAtYkDyuMMMFYRUISgmiNpgxxqtBFfeKdErXOvJefdiyiKRwHeAyfwgUKaduoMoFlUjOKbRzKyGBsmEwvEPNbQKalarEY")) {
        for (int MUMLTXLPePITzlqt = 349780145; MUMLTXLPePITzlqt > 0; MUMLTXLPePITzlqt--) {
            mpEPbLrcQAKN = mpEPbLrcQAKN;
            mpEPbLrcQAKN = mpEPbLrcQAKN;
            mpEPbLrcQAKN += FUzeedIYshIj;
        }
    }

    return FUzeedIYshIj;
}

bool hrjUYdGhsnOqSXp::GzCRVHuMSgIh(string KiAlfMLtP, bool diYokQyeJVORG, bool yxMfWny, double KVMZprjcAaxOZZh, int YMiUwchm)
{
    int oFyIXPeZUFwjNIHu = -2034943813;
    int bApHz = 1461449267;
    double btJNwvls = 490707.0435527303;
    double kkiftUjBG = -744002.6485455417;
    double jWwvDdiY = 277740.680645618;

    if (bApHz >= 1461449267) {
        for (int TpLJr = 1966408697; TpLJr > 0; TpLJr--) {
            yxMfWny = ! yxMfWny;
        }
    }

    for (int PwwTpr = 553892289; PwwTpr > 0; PwwTpr--) {
        jWwvDdiY -= jWwvDdiY;
    }

    for (int dUhdEtjD = 70436907; dUhdEtjD > 0; dUhdEtjD--) {
        continue;
    }

    if (KVMZprjcAaxOZZh != 277740.680645618) {
        for (int kHZzLyvMJdj = 420295835; kHZzLyvMJdj > 0; kHZzLyvMJdj--) {
            continue;
        }
    }

    return yxMfWny;
}

hrjUYdGhsnOqSXp::hrjUYdGhsnOqSXp()
{
    this->dHGWMnT(-910794.3609856536, string("PeAkZAukvFIzAmvEUSWOVzgkKYOyxMzEwHDYUIPCTqttojqqeuvplhnRIZYusHzcnKltuBQcuKMfNtkWLvRTfmsSeFtCnajIVyaUoncSrbIwUrGvYCLuVwITHABGHCczxMPCmcqkBYdzWVqYkdwXaHfWwMplXdOvreNYkoATdXXrmxSRDhvPZgjBPSeAfadZuZrJyEMQVLZDwlzuTWNQgxJgYbUMAthBAZtcHlsCpwLiesDQKi"), string("ymAdqPnTNcxiepSMxWeMBidbQkFXudtTDlSqOdUPkdsZGN"), string("yBIxszrMKmwdoSDxzauKZnVLyidaiInfSDKHyqkFZZdlmHVGXEJydfaHwaJSOKvvPhPVemXBSzkpFrZZyrroCkeKBYfAzIdvMarfivrSNxUQtxiBsChPWhyCLCBSBtMLBuVpZoLmuoG"));
    this->gHVZcXX(964170.7570574597, false, 2027226381);
    this->mgBtFlc(574827.4864674604, string("soajzloaIwoMReBiOpfqmAZFoudHrFYVLUVDKbhUyxqffkTrDcWpBoxuqrjBRfJhvVgAZlvNXAMdkVWElCPrmlAjTapgmiWUDJlDUhZHlTMiirouaCCsGpCbCpN"), false);
    this->gnYDssPYVoDwr(string("ImsbSnxifdEeRAoUnXfSekkiXgHZNzoJoPkBDcmOUrbN"), 685469793, false, 294870570, 850419403);
    this->BdzqPOYCT(string("dvaFzWuFuOvbtvonEIAejCxnDqUKcOCKMMVtcYSMgUnQlqABBsJoSXSrncZWYQBTuRIjicGSgDPKVrnMOeLWipjZyHpolmnkeVdafNojNDZQOiJnJeCbggQCGgmZjfvTkGoRLOcZtZYjFTgpdYKIBWbhqcnliQRcqIHHshNThHnDcbjeygeaKhIpkvEbBzxgeUuBYVmWjHW"), string("ZTNwMUKtFCJGgONxkHjBCIWcvBRtaBfVhKDIkNNoyTxxLGSrDzeHIpxwWrGJkcbVKelNULXkkyLDdVVfQGDYHoAVAfRZuhrxgqUwCDiQgaXHedWcrctgRJXJNSgjkZJNogxHpqUpAotkiPcjY"));
    this->UvEExx(string("osqLaVjGeBHQsGgPwnIyPMNZAmZuHWcCKIqcZEcxgoWTbODnKLzeiCBzgkSGmFvUqqavRXPdqCPOIWKKmJuNWbzJbhpGPbLtyKjfxDLLBgNiCZhOnfkXiMCfSFHPzHrlyoNqHCBrrmrPocelQGdwKSRkJIQOtGE"), true, false, true, true);
    this->LnIgOJnUdR(-955600434, 667997026);
    this->mMCRjTetjgzA();
    this->jtSclbtLSH(string("gBHHniJvzFtJdidEXQsyXrXWiNikEaPACbgOwLGUcSMhxXvaqqrzWOWOETypoYRkFIPhqdeoOmdLJLNDTiFPOiopWAYSOeftNzpPWhIqQFpqBycljwhhJDEumZXybqSY"), true);
    this->obOdTlfD();
    this->texrE(true, -768971019, -1226357028);
    this->JnlgdwvapdyQbe(1020418.6925449313, 305424593);
    this->FIOPiOpZsLrB(1903932406);
    this->TZJGWyjWxCK();
    this->VUulLpKA();
    this->GzCRVHuMSgIh(string("laYHGYNijpvQJlHsSsAazwlULntYyLUajqgsPoBcamRnyXJXhfzrADSFXaRvOshGIqCynECWGsJsMwcaJRuLboUSnduwGFlevqHcQhWGaXepzBNIYRbtVYNlOEWqIfIrrPmJgTOiEFIOQMxniAhUVoTQGSbibcfnvzbuLrsJdRIqoUSuSjEIKELntAkEwAJW"), true, false, 76940.39459862623, 1339996783);
}
