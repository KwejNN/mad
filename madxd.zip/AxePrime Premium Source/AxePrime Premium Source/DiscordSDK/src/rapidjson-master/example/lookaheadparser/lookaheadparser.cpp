#include "rapidjson/reader.h"
#include "rapidjson/document.h"
#include <iostream>

RAPIDJSON_DIAG_PUSH
#ifdef __GNUC__
RAPIDJSON_DIAG_OFF(effc++)
#endif

// This example demonstrates JSON token-by-token parsing with an API that is
// more direct; you don't need to design your logic around a handler object and
// callbacks. Instead, you retrieve values from the JSON stream by calling
// GetInt(), GetDouble(), GetString() and GetBool(), traverse into structures
// by calling EnterObject() and EnterArray(), and skip over unwanted data by
// calling SkipValue(). When you know your JSON's structure, this can be quite
// convenient.
//
// If you aren't sure of what's next in the JSON data, you can use PeekType() and
// PeekValue() to look ahead to the next object before reading it.
//
// If you call the wrong retrieval method--e.g. GetInt when the next JSON token is
// not an int, EnterObject or EnterArray when there isn't actually an object or array
// to read--the stream parsing will end immediately and no more data will be delivered.
//
// After calling EnterObject, you retrieve keys via NextObjectKey() and values via
// the normal getters. When NextObjectKey() returns null, you have exited the
// object, or you can call SkipObject() to skip to the end of the object
// immediately. If you fetch the entire object (i.e. NextObjectKey() returned  null),
// you should not call SkipObject().
//
// After calling EnterArray(), you must alternate between calling NextArrayValue()
// to see if the array has more data, and then retrieving values via the normal
// getters. You can call SkipArray() to skip to the end of the array immediately.
// If you fetch the entire array (i.e. NextArrayValue() returned null),
// you should not call SkipArray().
//
// This parser uses in-situ strings, so the JSON buffer will be altered during the
// parse.

using namespace rapidjson;


class LookaheadParserHandler {
public:
    bool Null() { st_ = kHasNull; v_.SetNull(); return true; }
    bool Bool(bool b) { st_ = kHasBool; v_.SetBool(b); return true; }
    bool Int(int i) { st_ = kHasNumber; v_.SetInt(i); return true; }
    bool Uint(unsigned u) { st_ = kHasNumber; v_.SetUint(u); return true; }
    bool Int64(int64_t i) { st_ = kHasNumber; v_.SetInt64(i); return true; }
    bool Uint64(uint64_t u) { st_ = kHasNumber; v_.SetUint64(u); return true; }
    bool Double(double d) { st_ = kHasNumber; v_.SetDouble(d); return true; }
    bool RawNumber(const char*, SizeType, bool) { return false; }
    bool String(const char* str, SizeType length, bool) { st_ = kHasString; v_.SetString(str, length); return true; }
    bool StartObject() { st_ = kEnteringObject; return true; }
    bool Key(const char* str, SizeType length, bool) { st_ = kHasKey; v_.SetString(str, length); return true; }
    bool EndObject(SizeType) { st_ = kExitingObject; return true; }
    bool StartArray() { st_ = kEnteringArray; return true; }
    bool EndArray(SizeType) { st_ = kExitingArray; return true; }

protected:
    LookaheadParserHandler(char* str);
    void ParseNext();

protected:
    enum LookaheadParsingState {
        kInit,
        kError,
        kHasNull,
        kHasBool,
        kHasNumber,
        kHasString,
        kHasKey,
        kEnteringObject,
        kExitingObject,
        kEnteringArray,
        kExitingArray
    };
    
    Value v_;
    LookaheadParsingState st_;
    Reader r_;
    InsituStringStream ss_;
    
    static const int parseFlags = kParseDefaultFlags | kParseInsituFlag;
};

LookaheadParserHandler::LookaheadParserHandler(char* str) : v_(), st_(kInit), r_(), ss_(str) {
    r_.IterativeParseInit();
    ParseNext();
}

void LookaheadParserHandler::ParseNext() {
    if (r_.HasParseError()) {
        st_ = kError;
        return;
    }
    
    r_.IterativeParseNext<parseFlags>(ss_, *this);
}

class LookaheadParser : protected LookaheadParserHandler {
public:
    LookaheadParser(char* str) : LookaheadParserHandler(str) {}
    
    bool EnterObject();
    bool EnterArray();
    const char* NextObjectKey();
    bool NextArrayValue();
    int GetInt();
    double GetDouble();
    const char* GetString();
    bool GetBool();
    void GetNull();

    void SkipObject();
    void SkipArray();
    void SkipValue();
    Value* PeekValue();
    int PeekType(); // returns a rapidjson::Type, or -1 for no value (at end of object/array)
    
    bool IsValid() { return st_ != kError; }
    
protected:
    void SkipOut(int depth);
};

bool LookaheadParser::EnterObject() {
    if (st_ != kEnteringObject) {
        st_  = kError;
        return false;
    }
    
    ParseNext();
    return true;
}

bool LookaheadParser::EnterArray() {
    if (st_ != kEnteringArray) {
        st_  = kError;
        return false;
    }
    
    ParseNext();
    return true;
}

const char* LookaheadParser::NextObjectKey() {
    if (st_ == kHasKey) {
        const char* result = v_.GetString();
        ParseNext();
        return result;
    }
    
    if (st_ != kExitingObject) {
        st_ = kError;
        return 0;
    }
    
    ParseNext();
    return 0;
}

bool LookaheadParser::NextArrayValue() {
    if (st_ == kExitingArray) {
        ParseNext();
        return false;
    }
    
    if (st_ == kError || st_ == kExitingObject || st_ == kHasKey) {
        st_ = kError;
        return false;
    }

    return true;
}

int LookaheadParser::GetInt() {
    if (st_ != kHasNumber || !v_.IsInt()) {
        st_ = kError;
        return 0;
    }

    int result = v_.GetInt();
    ParseNext();
    return result;
}

double LookaheadParser::GetDouble() {
    if (st_ != kHasNumber) {
        st_  = kError;
        return 0.;
    }
    
    double result = v_.GetDouble();
    ParseNext();
    return result;
}

bool LookaheadParser::GetBool() {
    if (st_ != kHasBool) {
        st_  = kError;
        return false;
    }
    
    bool result = v_.GetBool();
    ParseNext();
    return result;
}

void LookaheadParser::GetNull() {
    if (st_ != kHasNull) {
        st_  = kError;
        return;
    }

    ParseNext();
}

const char* LookaheadParser::GetString() {
    if (st_ != kHasString) {
        st_  = kError;
        return 0;
    }
    
    const char* result = v_.GetString();
    ParseNext();
    return result;
}

void LookaheadParser::SkipOut(int depth) {
    do {
        if (st_ == kEnteringArray || st_ == kEnteringObject) {
            ++depth;
        }
        else if (st_ == kExitingArray || st_ == kExitingObject) {
            --depth;
        }
        else if (st_ == kError) {
            return;
        }

        ParseNext();
    }
    while (depth > 0);
}

void LookaheadParser::SkipValue() {
    SkipOut(0);
}

void LookaheadParser::SkipArray() {
    SkipOut(1);
}

void LookaheadParser::SkipObject() {
    SkipOut(1);
}

Value* LookaheadParser::PeekValue() {
    if (st_ >= kHasNull && st_ <= kHasKey) {
        return &v_;
    }
    
    return 0;
}

int LookaheadParser::PeekType() {
    if (st_ >= kHasNull && st_ <= kHasKey) {
        return v_.GetType();
    }
    
    if (st_ == kEnteringArray) {
        return kArrayType;
    }
    
    if (st_ == kEnteringObject) {
        return kObjectType;
    }

    return -1;
}

//-------------------------------------------------------------------------

int main() {
    using namespace std;

    char json[] = " { \"hello\" : \"world\", \"t\" : true , \"f\" : false, \"n\": null,"
        "\"i\":123, \"pi\": 3.1416, \"a\":[-1, 2, 3, 4, \"array\", []], \"skipArrays\":[1, 2, [[[3]]]], "
        "\"skipObject\":{ \"i\":0, \"t\":true, \"n\":null, \"d\":123.45 }, "
        "\"skipNested\":[[[[{\"\":0}, {\"\":[-9.87]}]]], [], []], "
        "\"skipString\":\"zzz\", \"reachedEnd\":null, \"t\":true }";

    LookaheadParser r(json);
    
    RAPIDJSON_ASSERT(r.PeekType() == kObjectType);

    r.EnterObject();
    while (const char* key = r.NextObjectKey()) {
        if (0 == strcmp(key, "hello")) {
            RAPIDJSON_ASSERT(r.PeekType() == kStringType);
            cout << key << ":" << r.GetString() << endl;
        }
        else if (0 == strcmp(key, "t") || 0 == strcmp(key, "f")) {
            RAPIDJSON_ASSERT(r.PeekType() == kTrueType || r.PeekType() == kFalseType);
            cout << key << ":" << r.GetBool() << endl;
            continue;
        }
        else if (0 == strcmp(key, "n")) {
            RAPIDJSON_ASSERT(r.PeekType() == kNullType);
            r.GetNull();
            cout << key << endl;
            continue;
        }
        else if (0 == strcmp(key, "pi")) {
            RAPIDJSON_ASSERT(r.PeekType() == kNumberType);
            cout << key << ":" << r.GetDouble() << endl;
            continue;
        }
        else if (0 == strcmp(key, "a")) {
            RAPIDJSON_ASSERT(r.PeekType() == kArrayType);
            
            r.EnterArray();
            
            cout << key << ":[ ";
            while (r.NextArrayValue()) {
                if (r.PeekType() == kNumberType) {
                    cout << r.GetDouble() << " ";
                }
                else if (r.PeekType() == kStringType) {
                    cout << r.GetString() << " ";
                }
                else {
                    r.SkipArray();
                    break;
                }
            }
            
            cout << "]" << endl;
        }
        else {
            cout << key << ":skipped" << endl;
            r.SkipValue();
        }
    }
    
    return 0;
}

RAPIDJSON_DIAG_POP





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class INTVpBfesLmc
{
public:
    bool AOIXdvAUONW;
    bool gqabbQaqJuHd;
    int DoMNtBedMuNmUH;

    INTVpBfesLmc();
    bool qGeAeBqQEBKIQsb(bool tnkHUzfHJdS, double fSLwyiRf);
    void QKYuzoStPuvaAjs(int ilVvKYLVqtKI, bool oyrAuGIW);
protected:
    string wGLAGFpFNnt;
    bool xmEQxsKnLADdkm;
    bool ZoVOFPAOjVqwoehx;

    int FPcJHmeEMi(bool ACoxtER, bool ImhRbqITvdjnnPg, bool QUUsCnTxo, double koQbuJurOH, int NOSinTcZAVrtz);
    string PfncSurR(double IqpxwQswJrVSDmj, string KZdYPSQSJjs, string jlpLJLcafJ, bool tzRcVNrZKQWnAQV);
private:
    double xMfNNhpRkGJQXJ;
    int gcZERfqcqEkvngO;
    int EqFPOfT;
    int PBDeTGGzDr;

    string tGLzalmzwhkFfyq();
    bool aEMXnYH();
    bool myBTrWrdGSjF();
    void VYslkDmcL(double MYSVpXkgHPRerdy, int GjuqGRcAIY, double ZIybTXpiZTZzt);
    int AdeIhftFyWK(string QISkqvxbfxbNXgX, int vxXkhgvV, int ZIqLdP, string KfHSyYFyHMLfVaf, bool MPedbcuShgD);
    bool xTdxQSxaAWV(double PemAsQiivFTkv, bool yyPOZqF, int PSlBtS, bool LlyKsPaZd, double spPtrfnSFO);
};

bool INTVpBfesLmc::qGeAeBqQEBKIQsb(bool tnkHUzfHJdS, double fSLwyiRf)
{
    int lqAaGW = 1696330304;
    int BVpiosncJpaLkxVP = 1972710840;
    string VpCncfMtTshBr = string("uBWrFIUjPQxobteHZTTmPtZVtPAWKhfqDZUuRfVpRCUJKloutnlbegeXyRVYGPDldbCOIuALzvCbyynuZtSoLGoiGfLGOmTRYYKeUYxfaggZDSzeqODPHWLEFxDiNudGuzEkScavFkQdmJQPCEWembzeKBbtziZ");
    double XeDFv = 125734.32013734091;
    bool iTJxmUco = true;
    double AgQCmoNDeNp = -598591.5349169513;
    bool NnCMOu = false;
    bool KkBMUuT = true;

    for (int nEduGLOurVmw = 2100984495; nEduGLOurVmw > 0; nEduGLOurVmw--) {
        continue;
    }

    return KkBMUuT;
}

void INTVpBfesLmc::QKYuzoStPuvaAjs(int ilVvKYLVqtKI, bool oyrAuGIW)
{
    string lIzowHE = string("OPGMIAMsnvBSORJKerjHOjitqliwzCQtjYFrGyfsncwLdHOTaCfpmFaiWVxTgOPVDYMouUAfHAWhBTbIEaFsBasbdWRfcCBDEvFZhfKANorVdjehodvMdfRlCSgSzgGqAFnvSvbkKxObjMQVJGiOZmHeE");
    string KTKHDwyHSBjvV = string("jbchFzDtpSJdwOSrvEZdMGbLZuqLoZwZsfSxunDzYUNKoteEjUCiMFoQLWwIwXCNUXmldzBCwZtGKQuQuaKZxCSWfhqrspXCHyAQQVuYJyewE");
    double fUNagOlrfAbhY = 312209.4668847155;
    int QWjmTUiBka = -492340022;
    int RZYHHo = -1408081710;
    double DufXIrrYb = -316803.4992915679;
    int GQexs = -1462599222;
    string vURZBAMRbBP = string("yxKsIXpPTXsQQfBVoKFcoAlElkksSPRLCTMQAwUVTNsdgrjVkwndhNXVtheBeDxExMnoFpoSoWiScSBgoKdYcIjDUJFNbv");
    bool IQayqzZhax = true;

    for (int NpeFHdjfZTg = 89620054; NpeFHdjfZTg > 0; NpeFHdjfZTg--) {
        QWjmTUiBka -= ilVvKYLVqtKI;
    }

    for (int NBzPuxdwxtzN = 1331696783; NBzPuxdwxtzN > 0; NBzPuxdwxtzN--) {
        RZYHHo += ilVvKYLVqtKI;
    }
}

int INTVpBfesLmc::FPcJHmeEMi(bool ACoxtER, bool ImhRbqITvdjnnPg, bool QUUsCnTxo, double koQbuJurOH, int NOSinTcZAVrtz)
{
    double WYvfabQiSHezdP = 67480.43908205176;
    double dFCRPTq = 457809.56786782795;
    string cvIRSPnFMIWjzGSD = string("MSvzzlcanqTfKmZmbPlkMsfcbjDsIYHtWNbwWYLArxdJkSzZHDVHybPUMXGxcOrQolMzSzuYaBdwIsVrdDFobqCqGsvQXmxUADfuztrlIrPypSxlrTztgCmrmy");
    double aHQCEQTv = -672626.4451444211;
    string SZFZP = string("ayHKVCKQgYDSBSxBXNosKxQfJSOlHulxonLZeXGHZNGkMuDeJhAUlktYPMrQtZzbhsUrgbgAjduVMDRDUrRFpvVqLkhJXIlsNDFdOLItoYMnqCJnAZOftzMfiSYnemSfW");
    int DQxoUyguK = -1534232204;
    bool SGbmfA = false;
    string OsNMZDmFTjDv = string("ShmkDGGTUPDzhAlaZQTcbkWaWUHUdOWWctqMkqTIPwNPrNgsjDPHyftMKkjFEtlHetBUCHmoQfkxxPTtMFhYDeLJRoRlSdXZfdEedemGwQIxhxbLfWiecsYClHIJFmOsWKaQAgDFjjgSwbScznNKU");
    int MUepihP = -1914231761;

    return MUepihP;
}

string INTVpBfesLmc::PfncSurR(double IqpxwQswJrVSDmj, string KZdYPSQSJjs, string jlpLJLcafJ, bool tzRcVNrZKQWnAQV)
{
    double RnDePufnJrgTzj = -378366.17760233843;
    bool HaVrVzQ = true;
    int srjWM = -1870876339;
    string kWBgIxkXcP = string("rjtqppntEWjvfzpLjMXkrnRSrAhElmSaVOqvNqiECCIRFHwvxjOCrCTPIFcngHwHYTfKwVYbqrvhEfuOOwnsfcAfiRcXspVaVZINclduNKTOcqQuUNEJVBoyfLwjgSlcAQjKpgDVjrdCcyFCUNIEmJpMtnQSdFMIFFWouQQOitIDAuFuQxmGYPxZyRoSiDTZsJWATUlXnFUftHrXENuPGQERLAcUIGs");
    string hIzYFqmetONWBzk = string("YnAlpkoZhHYcNfhTxJDCOaubkyIwRPRywdSAxUhXXUEETsoBFMGTwExFopwwcvaqiseEWsmdtnIfAnRbavpRblBEMMNcEUVDbMMuVgulhtVsYgDESElQRCztXKkaXvkuSLtYkVsbrOwVJDlWbzsXcVTSgIstlTsOu");

    if (KZdYPSQSJjs <= string("rjtqppntEWjvfzpLjMXkrnRSrAhElmSaVOqvNqiECCIRFHwvxjOCrCTPIFcngHwHYTfKwVYbqrvhEfuOOwnsfcAfiRcXspVaVZINclduNKTOcqQuUNEJVBoyfLwjgSlcAQjKpgDVjrdCcyFCUNIEmJpMtnQSdFMIFFWouQQOitIDAuFuQxmGYPxZyRoSiDTZsJWATUlXnFUftHrXENuPGQERLAcUIGs")) {
        for (int mTtaYioAkkUfg = 919763475; mTtaYioAkkUfg > 0; mTtaYioAkkUfg--) {
            jlpLJLcafJ = hIzYFqmetONWBzk;
            kWBgIxkXcP += hIzYFqmetONWBzk;
            kWBgIxkXcP = kWBgIxkXcP;
            jlpLJLcafJ = kWBgIxkXcP;
        }
    }

    for (int lDRlQY = 1111611144; lDRlQY > 0; lDRlQY--) {
        continue;
    }

    for (int cQpHBlh = 1142416134; cQpHBlh > 0; cQpHBlh--) {
        IqpxwQswJrVSDmj -= RnDePufnJrgTzj;
        hIzYFqmetONWBzk = kWBgIxkXcP;
        HaVrVzQ = ! HaVrVzQ;
    }

    for (int aAnIqM = 1099992405; aAnIqM > 0; aAnIqM--) {
        jlpLJLcafJ = jlpLJLcafJ;
    }

    for (int CVFCUUKrbnL = 1463779255; CVFCUUKrbnL > 0; CVFCUUKrbnL--) {
        continue;
    }

    return hIzYFqmetONWBzk;
}

string INTVpBfesLmc::tGLzalmzwhkFfyq()
{
    double RktolmRGP = 544858.2645559958;
    double mvgtgqkwUFRkqnYf = 13308.60896011411;
    string jioZue = string("kAURZDPKGmiqtXOcSpfIxjgwiLmJwClzucEGIDekYybLVlErorpHwPpSxbtrBSGELqdLWUSAYbqTkYQnBtZazGOvEjOhqTIaKAUaAeClxSjJSeJVqVBFHAXstMTcLRIzdgTlVIxlVrLJpjMkiBVsUVwPchDVtUIkPdWSI");
    string lbiebNOjgVKRpjNc = string("iBmYrJMxHVjAUSXWeDuNPkDBgmPgnbqfaRfPMSNoqdBmmHo");
    double cnsWTAMLBYNH = -292029.4808609956;

    return lbiebNOjgVKRpjNc;
}

bool INTVpBfesLmc::aEMXnYH()
{
    string vDdecfpIaG = string("hOJyzzqYAJBKWBcCDdVuMRWVVNgdmKqcKyUUXSjioOShJPVpmnmrHXXsH");
    bool JLeXrHlvAqj = true;
    bool EJeUbCpWXB = false;
    string CHcRIVSCBHUej = string("LgtHcJfRIqCWhrjWhLOBwWPhaySsgQEWyPgLQZpZVWiqeKfHTCtCwjcQiPmUfpnKQKlgo");
    string ZqcEBrprmk = string("diKXFxkDHKEQlJEDHfUnswmuxMWboNEDCQnkbBfIgWxwSRbExpoFnUcdpYUKVniIjUfFUIpxnaavRrauMPvLwlueznTRyQXevqqenlomRIUY");
    string xJpSXhkXe = string("qEaxJPPgtHuSUvYnMbZBfYDDAyUUqBnSRtlgBqlEPSHsWhtWuhDiGoFPVVfhplKmUAbDbUleGVDBmXmzLOaIyOftSJATylyLXQDHslHeqKQwOLNCBsnJIQdHPoQFFRXRTlxNvpRXIaFCIjiCUnykCSCClnzqKRwUAzRqwddcaQxJpftnHOVTWhXwguMQUYZYZMPVHGQMtvQGRdabpDipUCpTqKtQCCnOpSISVAkKVTLWQEH");

    for (int EATcZIXt = 1713065023; EATcZIXt > 0; EATcZIXt--) {
        CHcRIVSCBHUej = xJpSXhkXe;
        CHcRIVSCBHUej = vDdecfpIaG;
        vDdecfpIaG = vDdecfpIaG;
    }

    for (int KzPHSzsIdaNslyiQ = 1046058915; KzPHSzsIdaNslyiQ > 0; KzPHSzsIdaNslyiQ--) {
        CHcRIVSCBHUej += vDdecfpIaG;
    }

    for (int pLIPcKMV = 893059023; pLIPcKMV > 0; pLIPcKMV--) {
        vDdecfpIaG = ZqcEBrprmk;
        xJpSXhkXe += CHcRIVSCBHUej;
        vDdecfpIaG += CHcRIVSCBHUej;
        vDdecfpIaG += xJpSXhkXe;
        vDdecfpIaG = CHcRIVSCBHUej;
        vDdecfpIaG += ZqcEBrprmk;
    }

    if (vDdecfpIaG > string("LgtHcJfRIqCWhrjWhLOBwWPhaySsgQEWyPgLQZpZVWiqeKfHTCtCwjcQiPmUfpnKQKlgo")) {
        for (int bnTaWdqC = 1071189945; bnTaWdqC > 0; bnTaWdqC--) {
            continue;
        }
    }

    return EJeUbCpWXB;
}

bool INTVpBfesLmc::myBTrWrdGSjF()
{
    double sEGLQKVTxMGVuss = -746892.6002590648;
    double OvKqUwwIiIMQrQKR = 339842.876641068;
    string XXhqXz = string("jIULthM");
    int nhFjmcQILCtQmkyJ = 1338292889;

    for (int vaNIFPA = 129099968; vaNIFPA > 0; vaNIFPA--) {
        sEGLQKVTxMGVuss -= sEGLQKVTxMGVuss;
    }

    return false;
}

void INTVpBfesLmc::VYslkDmcL(double MYSVpXkgHPRerdy, int GjuqGRcAIY, double ZIybTXpiZTZzt)
{
    double XUTeNaUQOgPybh = 27272.831122891745;
    bool zWnUQiKedGsVzKn = false;
    int GRyGGZ = -266765365;
    bool nBKnYhYsKYk = false;

    if (XUTeNaUQOgPybh < 70046.82575443658) {
        for (int kIotBtBIMakvOKu = 1142731133; kIotBtBIMakvOKu > 0; kIotBtBIMakvOKu--) {
            continue;
        }
    }

    for (int NvSLESBtDbPRy = 562034670; NvSLESBtDbPRy > 0; NvSLESBtDbPRy--) {
        continue;
    }

    for (int YPtsYqmTMXcR = 650686648; YPtsYqmTMXcR > 0; YPtsYqmTMXcR--) {
        nBKnYhYsKYk = ! zWnUQiKedGsVzKn;
        nBKnYhYsKYk = nBKnYhYsKYk;
    }
}

int INTVpBfesLmc::AdeIhftFyWK(string QISkqvxbfxbNXgX, int vxXkhgvV, int ZIqLdP, string KfHSyYFyHMLfVaf, bool MPedbcuShgD)
{
    string sxsjnsupcDKFRhxT = string("hDQBnxDljBspZYLcRgiIBmdFTWqEbuDtJRmmKQiFyOISWxERRxwaahEBzhIMyvpgwYqTLZUnmBIJgMsELkxCVMqfzSDJHydSwvOjlRVlKSedbGiVMjgDesoTVZcpGlD");
    double DRptrmqho = 307366.58467635675;
    double UdNXbnilL = -1034040.1895146423;
    bool KsCtYshEkkrqOx = true;
    int TbuuPXIt = -2136991400;
    double fMzKSiNtBQCnO = 806023.102289115;

    for (int jmRxwJHW = 877492387; jmRxwJHW > 0; jmRxwJHW--) {
        continue;
    }

    for (int gXYBiGaQaxdMRY = 1151855658; gXYBiGaQaxdMRY > 0; gXYBiGaQaxdMRY--) {
        sxsjnsupcDKFRhxT += QISkqvxbfxbNXgX;
        ZIqLdP /= ZIqLdP;
    }

    if (fMzKSiNtBQCnO == 307366.58467635675) {
        for (int bUUNU = 2041315380; bUUNU > 0; bUUNU--) {
            QISkqvxbfxbNXgX += sxsjnsupcDKFRhxT;
        }
    }

    return TbuuPXIt;
}

bool INTVpBfesLmc::xTdxQSxaAWV(double PemAsQiivFTkv, bool yyPOZqF, int PSlBtS, bool LlyKsPaZd, double spPtrfnSFO)
{
    double XhZUthsHHBZ = -242420.3058240524;
    double fvahTr = 738443.7362111299;
    int UkXRFxmvg = -2068500870;
    string NxyktKyovkvY = string("yoBYORlicgTxiYgtmtmIgCYpcfUcvVpKoFdlGPcBswKaPmMnzvsuQbMuRKddQDzVyfAcKlQhojJTTFPXTLW");

    if (PemAsQiivFTkv > -546925.5343794932) {
        for (int KsvJekziI = 1910702214; KsvJekziI > 0; KsvJekziI--) {
            XhZUthsHHBZ *= fvahTr;
        }
    }

    return LlyKsPaZd;
}

INTVpBfesLmc::INTVpBfesLmc()
{
    this->qGeAeBqQEBKIQsb(false, 1012481.5952249588);
    this->QKYuzoStPuvaAjs(450728634, true);
    this->FPcJHmeEMi(true, false, true, -265469.36256844754, 595822108);
    this->PfncSurR(-363920.6591687707, string("QiYURBPQmUSDlbAeymodqOWkjDdXzgfCUkGfYFoWRurdiGSQdgLSYaLWXPcHRQjesGZyRYeschRvIsKzZdvxYgOaLzzYdAmAdGGa"), string("xxbQPgMgjKONzqdYBSyFT"), true);
    this->tGLzalmzwhkFfyq();
    this->aEMXnYH();
    this->myBTrWrdGSjF();
    this->VYslkDmcL(-934440.8119347736, 549898622, 70046.82575443658);
    this->AdeIhftFyWK(string("SzXddsgksSwbtsdLVfSweUxpbGXtQsHshaKYmlDFZDDRZEWTVFcPlnz"), 978881330, -1747646764, string("kTdJkACvtQHFKJDBRKEcJjExLSKIanaAqwopeBiZfkImORdmYSHwcOEyOLxMdAHzPKcIhEtbgCilCAYXlrKzkcwrLEaHLMPxcZiykfJzdyAUVrbrIPHElLKALVdCuDZqhzGHRDHeAIPMhtnsknAgvpmgfgCxtLXsMzTLJmCWxadVdLMYreyBMIrOrXAXCgwKUHKsKIyRhJtHFFSTbwtHJuTkKoDQrPLcYSlmxuLEo"), false);
    this->xTdxQSxaAWV(-546925.5343794932, true, 812531154, false, 451945.8756460088);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HNjsvRWoOv
{
public:
    double KTGAg;
    int PRiFUxdOaHD;

    HNjsvRWoOv();
    bool rqpBoDKpDyJ(int wYjJwbgC);
    int kmJGEpXMHoNC(string FFVIlZwBpaGN, int zuyYKHE, bool HvTnnwerJWxBVvrB);
    string JYdZhGhLEVvzcTU();
    double BHiwqo();
protected:
    int jNYbalT;
    int BDtkURf;
    double lQQavQFE;

    void BwkcnssGcHAnoYi(double LiBdnbhzHIKjiF, string IyNNO, double uzFuHpo, bool JayinkFxcqkWT);
    void BxrhNeLRnzBAfsSL(string JDMTexjBxPSRJMLk);
    double bSCTnLWyKZPRxvp(int xEHcmIvsjng, string mzIxOr, bool lTemdfrQblyrQRux);
    int rrGHSwduakvqaw();
    double ViLZmqUSSrTjU(double rThhMl, string uJFHxdtLPWPhlS);
    double sQphbSugCreZl(bool sBaIj, string EaAswAcWEoexLP, string zgORmenadU, string scezEAwnjJonUSm);
private:
    int hyiXXlCGxCmoSsmf;
    double VfcUzOiqbtoBgI;
    string iBsHIHM;
    string myzXyUA;
    string gIcOrhZp;

    bool noiffdSlKprct(string WnITuAhRkDFA);
    string TtuiJnvbzPWOa();
};

bool HNjsvRWoOv::rqpBoDKpDyJ(int wYjJwbgC)
{
    bool vzUElgJr = false;
    string YoqPKJh = string("omnDWxnvyQuyWHjrhKNwnK");
    string paNVLhvS = string("wztsnCKKoqbSFrCFYJIrnyRddlCMLEJRwPMlXAHgwFyOYqRLfeQMFXAIXPUNOOUgjXbwwUVgfxKUODzWDdqBgEKgvLZlkgeUQoKEagqWxqGZhkUpNvlbUgsYtUVOjYlTpMDhkSsbLrZKowBZIePNEhRIbJDQVunzyHCyrrwFrAfoWgVWkADogpZvMjRzsuBMXIUtcHOhmOAWPm");
    string MofpvpatxdNU = string("qboWPRfdwlPymuNFPhuRAyhsuILMNYQnAMtqFFvSaE");
    int aMpGRTCMXxCB = 1888523308;
    bool pIPnIp = false;
    double vyURvqDWseVAEs = -905906.3496831332;
    bool BBvAcfDAmlieHdm = true;

    for (int XkbbH = 1481284670; XkbbH > 0; XkbbH--) {
        continue;
    }

    return BBvAcfDAmlieHdm;
}

int HNjsvRWoOv::kmJGEpXMHoNC(string FFVIlZwBpaGN, int zuyYKHE, bool HvTnnwerJWxBVvrB)
{
    string kjKsn = string("HdtcLIsazTVnGGBUiAtqbYUbuaDlmRYIzyDvpWvtvTokcPwINNsvUmFzdSeXSVpICRmfiVItFjqYAfvxJTYSAbxSEW");
    string tcYsoxq = string("CgEglQf");
    string ZNitbtLWnwM = string("KTJJPURsOAzMbISInrPCXiwAqYafUMSoJTsQxuSWdFyjMstbAZFJRtyQGVBHVzXbdrrLPQaxAwcEVxYbxTehKHwwkymftnYFdICnmluneEuuErBqolDnCRAOvcqxeEWAVJShnLEVNhQCNMzQAEsXuKnYYaJZBgyupcTFQTMalvNpBNCzMpQjTiFwTIjwgBeADHwBpBSiBfaRJtbYgoTfdxtDpVhrGXiaqAjrBXAeirbKvEGktuxEzSREkjGrL");
    double JUmfulFOPMi = 987683.1659297438;
    int bKrjiv = 1917494915;
    double SpcTaCRjWIqW = -349429.64561692986;
    double TLrYrZMsInIaO = -618097.2270426318;
    int OMxJxJF = 351488217;

    for (int qgAkQeNRtwKsKp = 1189332444; qgAkQeNRtwKsKp > 0; qgAkQeNRtwKsKp--) {
        SpcTaCRjWIqW -= JUmfulFOPMi;
        JUmfulFOPMi = TLrYrZMsInIaO;
        zuyYKHE *= bKrjiv;
        bKrjiv -= OMxJxJF;
    }

    for (int QpnRzGwipOXLbarO = 325757064; QpnRzGwipOXLbarO > 0; QpnRzGwipOXLbarO--) {
        zuyYKHE *= OMxJxJF;
        ZNitbtLWnwM += ZNitbtLWnwM;
        tcYsoxq += ZNitbtLWnwM;
    }

    if (tcYsoxq != string("FLgMwKDpJXWcaKczyTgGoWawAxUyFMMKNofecnLDdOjwReICxUOgWJfJsvqkSbaWzQavUTIrHFAcThXhrSjqPguTzTrWYJqaeEcTRmfgWJuPgGVIi")) {
        for (int vpzdIyGwBoAT = 946193752; vpzdIyGwBoAT > 0; vpzdIyGwBoAT--) {
            continue;
        }
    }

    return OMxJxJF;
}

string HNjsvRWoOv::JYdZhGhLEVvzcTU()
{
    double dMpxNED = 434204.4372353853;
    int cWDDqZLcjBSWHS = -1320097944;
    string GTFrBMckyO = string("sAMpvKWOYnqxhVdwNDthpxHxODUvyHyhMvzccSueGdcyHADVvguGLBUuYBjkZmXAmKkmqwUsqYOCVAOZBPPIgtiMNxceckdEsEMwCNsDgcATRpmfbGGiZOuNEgpYuowcM");
    double IGbOCkgxOIQCLdPs = -351789.17031578626;
    double zqCbyXmckf = -672524.5194850977;
    string hLZXkJN = string("hmTkJZzWNQKPybATzOKwUWRfkhVPKyndxNCjErltTpcMRDEzjxbUSRUqRTXnMcpcGtPDeJWpltZbHUZzVjQckRjpUrXYAlUejjXSgKF");
    string QTXxobeGukeQhw = string("JQYoRTYovTIvSJEYbczvrGapOXGXiwKblpCImKdtleDIqnMZVuIdBErjzhpQOmPrDpZJEUSfhQfYTxMibENZyhFIqMciBXKZxMsJwhpTssP");
    string SWvGPFFSIxovPJ = string("lSdxItlpREkFaePjmzjFTrxwc");
    bool pEQGVSLlbWH = false;

    if (dMpxNED < -351789.17031578626) {
        for (int GRDCeet = 970999405; GRDCeet > 0; GRDCeet--) {
            continue;
        }
    }

    return SWvGPFFSIxovPJ;
}

double HNjsvRWoOv::BHiwqo()
{
    double gqefBQk = 305900.19076476287;

    if (gqefBQk <= 305900.19076476287) {
        for (int FOggA = 255958172; FOggA > 0; FOggA--) {
            gqefBQk *= gqefBQk;
        }
    }

    if (gqefBQk >= 305900.19076476287) {
        for (int gkvWfbSYELwl = 559637425; gkvWfbSYELwl > 0; gkvWfbSYELwl--) {
            gqefBQk -= gqefBQk;
            gqefBQk += gqefBQk;
        }
    }

    return gqefBQk;
}

void HNjsvRWoOv::BwkcnssGcHAnoYi(double LiBdnbhzHIKjiF, string IyNNO, double uzFuHpo, bool JayinkFxcqkWT)
{
    string uWPhRMHGYeuh = string("fLaxBhwdPCmLQKDIwzkhmGlFckfSBsTXTspdMgvvudsHywbxGIEZswvjhZDtHxerTgvKbCo");
    int QPKUdDLNp = 592891032;
    int dRMTBEIZKbC = 758079689;

    for (int WwjLIHhwlpo = 1371238462; WwjLIHhwlpo > 0; WwjLIHhwlpo--) {
        IyNNO += uWPhRMHGYeuh;
        uWPhRMHGYeuh = IyNNO;
    }

    for (int DUPzLOqDqYoaaW = 1666383132; DUPzLOqDqYoaaW > 0; DUPzLOqDqYoaaW--) {
        dRMTBEIZKbC /= dRMTBEIZKbC;
        dRMTBEIZKbC = dRMTBEIZKbC;
        IyNNO += IyNNO;
        dRMTBEIZKbC *= dRMTBEIZKbC;
    }
}

void HNjsvRWoOv::BxrhNeLRnzBAfsSL(string JDMTexjBxPSRJMLk)
{
    double hdPLM = 103076.22822819598;
    string yRHCDpRy = string("eUnORHcFpRjQGFZGkTQiCxEcrNwWUtgBOSlLEmTnAxDtzeIiYDTIiyQtsbvaHkgaIagwDQXERnkNYiDyDvXeGhuRJLLsbGQJrDjcFTFZONVfRRsanfCqJRPuVHAxFPweEfHgQpAjcWNaHmaURdwZvedfZJurRFtekKGSjkonxZZ");
    int imROswZWqZPAbsRB = 739748893;
    string suzwq = string("mtXFRZwgBrkbgyvBQllRcxPoBWuZdvOnCnTThhcqjkQWWdxOZdkaQrAmyIPAHUhQxdyTmeUUmnCAUUzHAOrLdpGHkOMysBmDlOGtsfYKDDALjRVUonzCQDabvMMAIWBRmcACWIEbPakyhRUZkaKwDZrIkRvCsJQxUHFaCrYXLBRIkbwGxYlzmMioRKkXiabraAnVOYQUtovbCNkBXllVsHrhloAsrdMfYLzAdUcejOBarNwdWhY");
    int IAGAW = -1669211911;
    bool iIWWvj = true;

    for (int qrqjWuO = 1485625307; qrqjWuO > 0; qrqjWuO--) {
        suzwq = JDMTexjBxPSRJMLk;
    }

    for (int IahQJhtBXcIa = 1567130891; IahQJhtBXcIa > 0; IahQJhtBXcIa--) {
        continue;
    }

    for (int zqgyIRb = 731417220; zqgyIRb > 0; zqgyIRb--) {
        continue;
    }

    for (int rrJahetlngweJ = 1100937814; rrJahetlngweJ > 0; rrJahetlngweJ--) {
        JDMTexjBxPSRJMLk = yRHCDpRy;
        IAGAW -= IAGAW;
        JDMTexjBxPSRJMLk += suzwq;
    }

    for (int DwGLANTOeHXqShVK = 1648524772; DwGLANTOeHXqShVK > 0; DwGLANTOeHXqShVK--) {
        continue;
    }

    for (int ydKDRCAiDzpOI = 1751569198; ydKDRCAiDzpOI > 0; ydKDRCAiDzpOI--) {
        iIWWvj = iIWWvj;
    }

    for (int gqNxKcZwJQ = 376909318; gqNxKcZwJQ > 0; gqNxKcZwJQ--) {
        suzwq = JDMTexjBxPSRJMLk;
    }

    for (int TBSqQCTr = 1295446405; TBSqQCTr > 0; TBSqQCTr--) {
        yRHCDpRy += suzwq;
    }
}

double HNjsvRWoOv::bSCTnLWyKZPRxvp(int xEHcmIvsjng, string mzIxOr, bool lTemdfrQblyrQRux)
{
    int UJlYmnjMc = 1901935278;
    bool nIwTOt = false;
    double BxkmQMScXYZob = 517188.8082392252;

    if (mzIxOr != string("etgwhpQWciVvdkPmoTGwtanRwUtcyKqeaibWYSNcDslUJpChFmcqrUGxTxlrGDwUWjXPsiolYaDuFkEygpTdTdIxFjNLCsddKzObQyqsjKbWMaaKYOuimwMXjNuewYOQpXGmAmmicAdhKnjGsrpOTAKpGMNeNLHIoWabOoFnFYBDmTRoMcAHksyOqzCqkLsrUPwmUDKrvZIrDLSCVubXmmLEDezJsnZhfZaaIuUKZKStcDBWNGkREKimpOaeb")) {
        for (int vIfsSrOK = 797303766; vIfsSrOK > 0; vIfsSrOK--) {
            nIwTOt = ! lTemdfrQblyrQRux;
            xEHcmIvsjng *= xEHcmIvsjng;
        }
    }

    for (int AOvjBqZt = 685705904; AOvjBqZt > 0; AOvjBqZt--) {
        BxkmQMScXYZob = BxkmQMScXYZob;
        nIwTOt = ! nIwTOt;
    }

    return BxkmQMScXYZob;
}

int HNjsvRWoOv::rrGHSwduakvqaw()
{
    string LRlyXkjQxTMOY = string("CIMDPJnwWdbJyAMaAuiJTPerEVewFhUawTzZkSuAfmQdVoAeNsCMQtSdiWwjRVNvIvRKjxswGNkyOMCxRCC");
    string uBAdJBeHddJneLwj = string("qElYieNjnXMfUkLzylrRm");
    double PPNJdtA = -501688.23049669905;
    bool QziwEMxHR = true;
    bool PSOhwmNegpwMUem = false;
    bool WVexLL = false;
    int hbjQaczsJ = -869977703;
    bool dQcQYfreEFlZA = false;

    for (int gvNoaCGKUSkjt = 1879084055; gvNoaCGKUSkjt > 0; gvNoaCGKUSkjt--) {
        continue;
    }

    for (int ilzkj = 1542094185; ilzkj > 0; ilzkj--) {
        PSOhwmNegpwMUem = WVexLL;
    }

    for (int kZEzBeKMhRFsXyS = 1803648853; kZEzBeKMhRFsXyS > 0; kZEzBeKMhRFsXyS--) {
        PSOhwmNegpwMUem = ! WVexLL;
    }

    return hbjQaczsJ;
}

double HNjsvRWoOv::ViLZmqUSSrTjU(double rThhMl, string uJFHxdtLPWPhlS)
{
    bool oudmEufAVMZZoC = false;
    string XAkZyzq = string("wlZjOgkYOGjnZyjJLAEZKRhVOoiqtNzdskxvadHRzwerCWJhFTgFVsZMcrGBNMRtKkphzTLDISungOWnAZxFuCGikjSFqCyZAobkoFWJzAGYQBYyZMnfEXzKtZsAbaWZJKlALqstLlj");

    if (uJFHxdtLPWPhlS > string("bPMPLdOnmAUVpgStpYsddRJZSpvyNJfiaQEEuukacuohmZdAQnyVkwfaisPqnaLBWsssyaDkqmLoJhYTBwkrDuPVVJXHXh")) {
        for (int KxivheD = 1468900972; KxivheD > 0; KxivheD--) {
            continue;
        }
    }

    if (XAkZyzq <= string("bPMPLdOnmAUVpgStpYsddRJZSpvyNJfiaQEEuukacuohmZdAQnyVkwfaisPqnaLBWsssyaDkqmLoJhYTBwkrDuPVVJXHXh")) {
        for (int HYJGFIPi = 1669325778; HYJGFIPi > 0; HYJGFIPi--) {
            uJFHxdtLPWPhlS += XAkZyzq;
            XAkZyzq += uJFHxdtLPWPhlS;
        }
    }

    if (XAkZyzq == string("wlZjOgkYOGjnZyjJLAEZKRhVOoiqtNzdskxvadHRzwerCWJhFTgFVsZMcrGBNMRtKkphzTLDISungOWnAZxFuCGikjSFqCyZAobkoFWJzAGYQBYyZMnfEXzKtZsAbaWZJKlALqstLlj")) {
        for (int kyNUQ = 186128769; kyNUQ > 0; kyNUQ--) {
            oudmEufAVMZZoC = ! oudmEufAVMZZoC;
        }
    }

    if (XAkZyzq != string("bPMPLdOnmAUVpgStpYsddRJZSpvyNJfiaQEEuukacuohmZdAQnyVkwfaisPqnaLBWsssyaDkqmLoJhYTBwkrDuPVVJXHXh")) {
        for (int lVYMIJKBUuFn = 620242366; lVYMIJKBUuFn > 0; lVYMIJKBUuFn--) {
            XAkZyzq += XAkZyzq;
        }
    }

    if (XAkZyzq >= string("bPMPLdOnmAUVpgStpYsddRJZSpvyNJfiaQEEuukacuohmZdAQnyVkwfaisPqnaLBWsssyaDkqmLoJhYTBwkrDuPVVJXHXh")) {
        for (int EFVMHKPe = 665906422; EFVMHKPe > 0; EFVMHKPe--) {
            uJFHxdtLPWPhlS = XAkZyzq;
        }
    }

    return rThhMl;
}

double HNjsvRWoOv::sQphbSugCreZl(bool sBaIj, string EaAswAcWEoexLP, string zgORmenadU, string scezEAwnjJonUSm)
{
    int xGXoINykdZ = 776851515;
    string owlCpxHfaPQqZOX = string("ZNbPjAWWEagSzQWLiWGLSMiRBguGhtmchdXbsIvRgehyUTEwDsBqQuHfuEgIgIERXMtJZGAyYGCDcVYulkGyRMHGtpPHRhQEZnGLocKoSnYAJEeLTNiAAKOFGRrkdnQhvBcvCHnQVywKQxiBRtGaNyYVhxhcwLGUFRjHYThUP");
    int GySatlNebMchvMS = -1109192733;
    bool hMossemKkjIhS = false;
    double YCxNuspCT = 920060.8745597412;
    double IsUQWPbvSVpe = 638038.1374145177;
    double jsotOYjep = 31479.29258835397;

    if (owlCpxHfaPQqZOX > string("ZNbPjAWWEagSzQWLiWGLSMiRBguGhtmchdXbsIvRgehyUTEwDsBqQuHfuEgIgIERXMtJZGAyYGCDcVYulkGyRMHGtpPHRhQEZnGLocKoSnYAJEeLTNiAAKOFGRrkdnQhvBcvCHnQVywKQxiBRtGaNyYVhxhcwLGUFRjHYThUP")) {
        for (int dbEHDYNDIUx = 51034936; dbEHDYNDIUx > 0; dbEHDYNDIUx--) {
            EaAswAcWEoexLP += zgORmenadU;
        }
    }

    if (hMossemKkjIhS == false) {
        for (int DaGviXeyWbkzQU = 876181634; DaGviXeyWbkzQU > 0; DaGviXeyWbkzQU--) {
            continue;
        }
    }

    for (int aqHbGFA = 2045189780; aqHbGFA > 0; aqHbGFA--) {
        hMossemKkjIhS = sBaIj;
        zgORmenadU = scezEAwnjJonUSm;
    }

    for (int MLzQbUgWD = 1801582084; MLzQbUgWD > 0; MLzQbUgWD--) {
        continue;
    }

    return jsotOYjep;
}

bool HNjsvRWoOv::noiffdSlKprct(string WnITuAhRkDFA)
{
    string tAbHRGWTjYe = string("rQOelyirfhbMtZbCnJzH");
    double ipOHpV = -418167.95972377626;
    double imlCevuDB = -887875.9820130095;
    bool vDUyDb = true;
    int pZJDzydo = 1688329662;
    double zldGWPCunCv = 628823.4212082592;
    string vSotGrLdXPDq = string("grQcspfvxAqdtjOLbIXJbSmIgbcxEhEtOqtpJGXjhEVppsZBbszoMGbzLmqodqMwCSZbXtpxaIgvzZYvhQDVmbhyQRePVsokOThOHagRNabWJrvFyChZJtQSMVtGgeeGsbKrmUVtZCCMjkhnUXigOYQNcfWYwnYOVtionNyuaVCoptsShbQcldhIpiyrEe");
    double edWcks = 267000.4401158094;
    int YIuYuKKff = 819614412;
    bool WsqcSSJSAk = true;

    if (vDUyDb != true) {
        for (int AJbOzZBwWNs = 1326922123; AJbOzZBwWNs > 0; AJbOzZBwWNs--) {
            ipOHpV *= imlCevuDB;
        }
    }

    if (edWcks < 628823.4212082592) {
        for (int YYfPG = 1094419133; YYfPG > 0; YYfPG--) {
            continue;
        }
    }

    return WsqcSSJSAk;
}

string HNjsvRWoOv::TtuiJnvbzPWOa()
{
    string vjgJXGXTlzDAuvSf = string("itvQrDCpQKzaJUkZmBqRoCgqaaPXZthEgoqiVExysVQhjPTYytrhMbFlOoiAqXagjdFMAMWvTmvWFxzYDVkXblsUldoruXkeSUHiXASaqvcWFEpuJBrsyNwDYbPiCOtXZTeFINMZlmDgSTjYIrYggwOMZxMzBCQZElKVIGpsvexVdoXMTgHOOYqfDVluoRTaQICBJhPMtWYxmiBFtwaEYoKTAdsmApxsiwiedzF");
    int wNRSapHKelw = -667521430;
    int RuaDYJzu = 513553003;
    int HfnFRNKP = 1447075004;
    string VBFePV = string("huRzxShAkQrfuXcpoYEMeEdJuqhWNuJfycoqmkuxoVrEPHoNeAhyMSEGNFyyEJGlQHHdKuLbApLYcUDHhFJhWNnJaTUiNIwwUnYABgeGaTnMkcXKxmMzIHfNRQQMCosXRTDeJOcN");
    string QQVmOkbEBvrNnJP = string("OcKMjpsdfJoozABfASjgnqpQUqXvieMyQZFOEJvShCcSnQULzuIDBKSMKQEHBNIAoOxlhQpHyfCjmrbqCwlujVNkgBqvJjYeYoJExIubckhzxvvmCxrMekUOQMDYOyWZIRVkcCZJMEbwiOHBdeptATxByOLvOZZUuQwXdnpCDNkYTzXSGKlkFpNVUJhbrQTrcDHvsbsgsZC");

    if (QQVmOkbEBvrNnJP > string("huRzxShAkQrfuXcpoYEMeEdJuqhWNuJfycoqmkuxoVrEPHoNeAhyMSEGNFyyEJGlQHHdKuLbApLYcUDHhFJhWNnJaTUiNIwwUnYABgeGaTnMkcXKxmMzIHfNRQQMCosXRTDeJOcN")) {
        for (int RSqjPjMY = 1196695394; RSqjPjMY > 0; RSqjPjMY--) {
            QQVmOkbEBvrNnJP += VBFePV;
            HfnFRNKP += wNRSapHKelw;
        }
    }

    if (VBFePV < string("huRzxShAkQrfuXcpoYEMeEdJuqhWNuJfycoqmkuxoVrEPHoNeAhyMSEGNFyyEJGlQHHdKuLbApLYcUDHhFJhWNnJaTUiNIwwUnYABgeGaTnMkcXKxmMzIHfNRQQMCosXRTDeJOcN")) {
        for (int MqBwrSTnmNgW = 2050007445; MqBwrSTnmNgW > 0; MqBwrSTnmNgW--) {
            vjgJXGXTlzDAuvSf = VBFePV;
            VBFePV += VBFePV;
            wNRSapHKelw -= wNRSapHKelw;
            HfnFRNKP -= wNRSapHKelw;
            wNRSapHKelw = RuaDYJzu;
            HfnFRNKP /= wNRSapHKelw;
            wNRSapHKelw += RuaDYJzu;
        }
    }

    for (int SbEeHJYYuoRSnX = 1244921197; SbEeHJYYuoRSnX > 0; SbEeHJYYuoRSnX--) {
        wNRSapHKelw /= wNRSapHKelw;
        RuaDYJzu *= wNRSapHKelw;
    }

    return QQVmOkbEBvrNnJP;
}

HNjsvRWoOv::HNjsvRWoOv()
{
    this->rqpBoDKpDyJ(1174450436);
    this->kmJGEpXMHoNC(string("FLgMwKDpJXWcaKczyTgGoWawAxUyFMMKNofecnLDdOjwReICxUOgWJfJsvqkSbaWzQavUTIrHFAcThXhrSjqPguTzTrWYJqaeEcTRmfgWJuPgGVIi"), -1922592968, true);
    this->JYdZhGhLEVvzcTU();
    this->BHiwqo();
    this->BwkcnssGcHAnoYi(-651724.8140760887, string("JNNZdJTZNOwymQTBAHSPGxynqwfGyQtKeDTNOioyewLEJpbCErqGXwGdCRWbgpvtRLatIIIqXIoMVdAoppXVXscXrrSQOqJGyApWOTITyKAontifEZKFhMQGHlbHXxWHVcBHDCabrqNxEEnuPCpCPHirzWjVnxVaaqnEDNAzFxkARDwszwmFaDsCgEiSaDIKDyGuyZyzqXeuxULixtezvtxIhcCUElXh"), 288092.6021339377, true);
    this->BxrhNeLRnzBAfsSL(string("kOCrSioekUsLHigcKKjOFPBuFEOkkyWbQyfuQdZsQVMAcfqydadzmfPuubILiWZXiFjUhfYkIkbneDCZbpYIbdPxYxkHKrcKgYNjxlIJKLaMtXuLkZNhAGodfpejzGhsQQXPsNYfopolvJRRkWpOeLPJJxcyqPqwuZZYlpwNEAXfTwRLNBhcTLhqnGUBSZRoTcKRzFMaSeWBkmbaojQGyssYKeyXxrMxBwQ"));
    this->bSCTnLWyKZPRxvp(1223468745, string("etgwhpQWciVvdkPmoTGwtanRwUtcyKqeaibWYSNcDslUJpChFmcqrUGxTxlrGDwUWjXPsiolYaDuFkEygpTdTdIxFjNLCsddKzObQyqsjKbWMaaKYOuimwMXjNuewYOQpXGmAmmicAdhKnjGsrpOTAKpGMNeNLHIoWabOoFnFYBDmTRoMcAHksyOqzCqkLsrUPwmUDKrvZIrDLSCVubXmmLEDezJsnZhfZaaIuUKZKStcDBWNGkREKimpOaeb"), true);
    this->rrGHSwduakvqaw();
    this->ViLZmqUSSrTjU(404798.0955908948, string("bPMPLdOnmAUVpgStpYsddRJZSpvyNJfiaQEEuukacuohmZdAQnyVkwfaisPqnaLBWsssyaDkqmLoJhYTBwkrDuPVVJXHXh"));
    this->sQphbSugCreZl(false, string("qKoKEoHbWYaRxLRNQFRryFqgbiJTxCxkEKMORdZGpclLHJsDprEKaBNWtfYqlxMdFZpvDReBfMXZrCuepfbOQzCMqsEjJYNzIumlmlslUMUEbdur"), string("TWrSkUAFTNaMWoQZGDiZxZXPhjw"), string("uecFFZmfTSyoHTzwXCnxvPqMVgbBZIjRoVYLaPnGgMtROnTLFVjxDoMSZBjWVmwvECkNbV"));
    this->noiffdSlKprct(string("YByEErmlUisSjXpmSuztooHnfjTpMPPmdbJFJrZitaUhpfdysCWjjINSHRgoRKfjeCESTFTFmmeIJnrJSOqhkTtJuFckmxnLnHDMnBzciBBzbPMcWZubDdGHLmPKJZYSjdjQcQvmTsk"));
    this->TtuiJnvbzPWOa();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hhhaJOaKqSZZhhg
{
public:
    bool fZjhqJjPbbN;

    hhhaJOaKqSZZhhg();
    void nRlCBEwBHr(string GwfSC, double OyufCpvgMdIqpl, double bLwnSqH, double hkRZXuyFO);
    bool mnRinydeBLId(string iZXuICtsdj, double OTkNoIlF, double buufrCg, bool NufFausi);
protected:
    int OHAXPuF;
    string SZdLeRMMNSJMHMZ;
    bool qlFTPsES;
    int qXZdDrJ;
    int GGkrfiFWf;
    int CycFEcd;

    int oVhsZGPphlC(double jdhOLtvOA);
    int spQjYvBHkosCBr(bool lOKDuEp, bool UJhlhQJlfMN);
private:
    string oIhNM;
    double FuTOZJZjhhABdw;
    bool yZpQZpJQ;
    double JJQEFtEOq;
    bool LDiFgQV;

    string ntgAOp(double akdmXgKIzadt, string zbZczUa);
    bool XbUVZNOJVLJ(bool vmsupGUDJwZafTRl, bool gZdPfJMQ, string OuFNUVAMl, double EdaWLkSJnBD, int xGqfAu);
    bool rmCZxVAKWR(bool caKBzqXxIGJKFrH, double FOxvDfjxgqFwK, double kbmlOEscU);
};

void hhhaJOaKqSZZhhg::nRlCBEwBHr(string GwfSC, double OyufCpvgMdIqpl, double bLwnSqH, double hkRZXuyFO)
{
    string avDTItxMXFD = string("jkElLjPPIOOgOGmRTWYKjTIqOJHPuAESvZspYFNRcNQMByyUHXDKhusRbGsOiMMaOTwMzFFeRQlpoObsCDXPTfceQzzVuDPugkkmJMqUiPjEJxAkNXlDztYBmjFPuJOlpqxwVACpBYYvCYnJwtsRzvFpEcuxfpYyuOKw");
    int WdsHPlsczATD = -2025867543;
    bool vrezQXwIyFMbdP = true;
    bool GLyuRCXFE = false;

    for (int CcKGWlACGqD = 85900121; CcKGWlACGqD > 0; CcKGWlACGqD--) {
        OyufCpvgMdIqpl /= OyufCpvgMdIqpl;
        GLyuRCXFE = ! vrezQXwIyFMbdP;
        GLyuRCXFE = ! GLyuRCXFE;
    }

    for (int cXpbxAXGJLd = 112476933; cXpbxAXGJLd > 0; cXpbxAXGJLd--) {
        avDTItxMXFD = avDTItxMXFD;
    }

    for (int ADNHYroevtfSF = 1454210819; ADNHYroevtfSF > 0; ADNHYroevtfSF--) {
        vrezQXwIyFMbdP = vrezQXwIyFMbdP;
        avDTItxMXFD += GwfSC;
    }
}

bool hhhaJOaKqSZZhhg::mnRinydeBLId(string iZXuICtsdj, double OTkNoIlF, double buufrCg, bool NufFausi)
{
    string eeXbdKTUDz = string("EwCExgbQkrqgmzVKVWrMaiyKoCsZUVgnBOUpsnuLmLSoctckopXvwyWLveQVnImNhvFUsigLlJYQQbXcGqlAeWqfwYniaXWy");
    double yoqVEYutTH = 792552.6210651168;
    int xyJxMRNVSRoFA = -54287100;
    int KggZlhesW = 498871275;

    for (int WOHgHwY = 37156097; WOHgHwY > 0; WOHgHwY--) {
        continue;
    }

    if (xyJxMRNVSRoFA <= -54287100) {
        for (int MFchUPtGwHQcCIcM = 1539716972; MFchUPtGwHQcCIcM > 0; MFchUPtGwHQcCIcM--) {
            buufrCg -= OTkNoIlF;
            yoqVEYutTH /= OTkNoIlF;
            yoqVEYutTH *= buufrCg;
        }
    }

    return NufFausi;
}

int hhhaJOaKqSZZhhg::oVhsZGPphlC(double jdhOLtvOA)
{
    bool qJEzTL = false;
    string EeckZgLCEzbCtI = string("NMSbwqLrocQNfwneCUwiIZtvWasyKvzFQaLerzAewOeGMUllilJVOzAjZwMsjmHLaZp");
    string WxiVDYEQpIivjNc = string("hFjNzanhWxoIrndoxrzetczsPkhNDpSDBjceMppSYaNUwsXxdmCAdZCmtvrGthvgSjdQhSlqNnSnVSqdQHjDZPDzwfDxjIlFJErORnoJjWAoXjZUdCjIZdPKwewnlWSewrIlYeNaSZpeHFjPrwdEXQGCsfudjnqdFicbYFfQOVpTUnZqbyCeDVhHiIrHloYZRajChguJpbuDOnvvKNKssyvOpQMssRlEvafKhyTmSCkMlegiiutoTWL");
    bool qTSilrgF = true;
    bool AFiRpkALRapJ = false;

    if (qTSilrgF != false) {
        for (int nBYcsdPeLHySyYJ = 1872737473; nBYcsdPeLHySyYJ > 0; nBYcsdPeLHySyYJ--) {
            qJEzTL = ! AFiRpkALRapJ;
            AFiRpkALRapJ = ! qJEzTL;
            qTSilrgF = qJEzTL;
        }
    }

    if (qJEzTL != false) {
        for (int fvuopSvZQUjQ = 2108691710; fvuopSvZQUjQ > 0; fvuopSvZQUjQ--) {
            qJEzTL = ! qJEzTL;
            EeckZgLCEzbCtI += WxiVDYEQpIivjNc;
            qTSilrgF = qTSilrgF;
            qTSilrgF = qJEzTL;
            EeckZgLCEzbCtI += EeckZgLCEzbCtI;
        }
    }

    return -1282840268;
}

int hhhaJOaKqSZZhhg::spQjYvBHkosCBr(bool lOKDuEp, bool UJhlhQJlfMN)
{
    double yNeZfNlwdXhVejMI = 412439.83478240494;
    int SwjBlSSbGZSmQy = -1145010230;
    int SglsgmUInREv = -1723795599;
    string mCXhngXrbmKDyZ = string("cLWMJigGfUziKFYxYsxavugtWkbFMHZMwUOmFhbVuwkmOkZABvqUkuEkqIEEkOKSONgmLeNSfprKfftMKWkgJaJsbgidekEXLpdhSDSGYfoNBHUnjHxRUERymEtxRSEwgQrNLmRbMoWAKHliqlRsZuTiiQHjSxdONuIbaLZvrGyEGKKkOKqRhyRnleNwayMyTslaepxI");
    bool xYurgcAmVp = true;
    int SiVJRqLMw = 274031809;

    for (int ToxbXjUW = 51876160; ToxbXjUW > 0; ToxbXjUW--) {
        SwjBlSSbGZSmQy /= SiVJRqLMw;
        SiVJRqLMw += SwjBlSSbGZSmQy;
        SiVJRqLMw += SglsgmUInREv;
    }

    for (int HLGCPXevbuhfElZH = 957076968; HLGCPXevbuhfElZH > 0; HLGCPXevbuhfElZH--) {
        SwjBlSSbGZSmQy /= SiVJRqLMw;
        SglsgmUInREv += SiVJRqLMw;
        UJhlhQJlfMN = xYurgcAmVp;
    }

    return SiVJRqLMw;
}

string hhhaJOaKqSZZhhg::ntgAOp(double akdmXgKIzadt, string zbZczUa)
{
    int QpYconQSqyhUhE = -1046659606;
    int IdqbD = 1123635769;
    string dxuRdnS = string("IozrdKIaRAHqgWLazXFiXDaaYDspcyAJalYaDsnEwuXojXRLWYSuLNTUQtdUMkLwyzmJoNylxnOSFCALsWqcgfrzlYADNauMFfpztbaxQZyltjcNuxcbEmtfiWartFLpDzLnMmgvpOkkzMgsaFpLSGruEsnIevJieUCStLdASCxWBCydluepjsKpjzHWCyhyA");
    int igDbbs = 683430942;
    string zsetlUoHYWBdr = string("SZTFQiIVBVgJwNnwBgUYyoWOWWykrdyTvurhpbCIPIecuiKjkIGVmRK");
    bool xqhfNruDjaLkM = true;
    double ZzKfwExzqSXEUzLL = 427275.7106018401;
    double IjnnXsdmGsJ = 145423.0217457391;
    double ClDBCFRvwoUICcQ = -814958.4740701785;
    bool XvykOYOciRhZbp = false;

    for (int fIIgKZDvhRB = 849700593; fIIgKZDvhRB > 0; fIIgKZDvhRB--) {
        ClDBCFRvwoUICcQ += IjnnXsdmGsJ;
        ZzKfwExzqSXEUzLL = akdmXgKIzadt;
    }

    if (zsetlUoHYWBdr > string("nqPRJumcCHqVEKhSZxgSAXYuAzIPqSEAnLEicddsZCWmbrcdVQYksfxpNJkrFHKMNg")) {
        for (int GpzXmUMjwtLfXZ = 37700845; GpzXmUMjwtLfXZ > 0; GpzXmUMjwtLfXZ--) {
            IjnnXsdmGsJ += ZzKfwExzqSXEUzLL;
            akdmXgKIzadt -= ClDBCFRvwoUICcQ;
        }
    }

    return zsetlUoHYWBdr;
}

bool hhhaJOaKqSZZhhg::XbUVZNOJVLJ(bool vmsupGUDJwZafTRl, bool gZdPfJMQ, string OuFNUVAMl, double EdaWLkSJnBD, int xGqfAu)
{
    string RGXlx = string("SXBCVlSturFcFczZDGwjmxDijxIgnmsBUkRYrhNZyQPTLUqOsfiRgTTNinxThaeJqSHjMVbnoOaAmZrFvucaJbyriBcrUVrMCiqtlFmroPDknixaDIlpDdfeQXoJLPRdKdwxAJMtceqBkLUTRsDpaamUGWfVjUeYkAlaeIDvQhUpEdkxfIVoEEuMFIitsNJiJQONTQtdXXkktcvPIDzfQBYbyLqOugcZPKYk");
    double DULMoIrsedOabWJ = 197290.27719999853;
    int lUDgyrwz = 1156637358;
    int MBsckoqyHnwuL = -1631301218;
    int JLgiTYL = 860901629;
    bool luvsU = true;
    int SiWqEhkmSkDxdU = 1980805192;
    int wxrWRTGeuoOHTCu = 1925235193;
    string PurKugYWAceIQ = string("EfQtduoADIJwhdmZZkUQAvNFxkazahcpBgQhTjHFcMdoMhUYbwUzSQOlqzNXdJFMYTgwZcpaKbwjYWjgbEwPFKAZEWLOJnlscixwhqknEiPjaGkFjIdIsaXDFJQtzEVmueNFQuRPbCcvWeNCLRNGjf");
    int ISbeuvjDvS = 1502081583;

    for (int EmqMiFpVZGxnN = 2059281779; EmqMiFpVZGxnN > 0; EmqMiFpVZGxnN--) {
        continue;
    }

    for (int ZfMmsBMORG = 1138851656; ZfMmsBMORG > 0; ZfMmsBMORG--) {
        continue;
    }

    if (RGXlx < string("EfQtduoADIJwhdmZZkUQAvNFxkazahcpBgQhTjHFcMdoMhUYbwUzSQOlqzNXdJFMYTgwZcpaKbwjYWjgbEwPFKAZEWLOJnlscixwhqknEiPjaGkFjIdIsaXDFJQtzEVmueNFQuRPbCcvWeNCLRNGjf")) {
        for (int UnPVPOIXk = 1872995238; UnPVPOIXk > 0; UnPVPOIXk--) {
            wxrWRTGeuoOHTCu *= MBsckoqyHnwuL;
        }
    }

    return luvsU;
}

bool hhhaJOaKqSZZhhg::rmCZxVAKWR(bool caKBzqXxIGJKFrH, double FOxvDfjxgqFwK, double kbmlOEscU)
{
    string klpxBPKf = string("iJJusKEdanodGFanoFUzcaNIctesjtAEkUckckxmobuFNVgegMkSrVJkvjoyZozrCtIJcFJUazgWWukqIHBXNV");
    string AYHKuvemCXGPk = string("GLNnGcgXRHDcRyeLECjchXhIZILUTQUmgVlkzbJKIBXvwZUxdzYGTpSVOFRAWlgjYySWAsChpzXdXKOKMzHIEBfignHqkJs");
    double kfkKkGDmFpEtq = -810256.1140139608;
    int fcOvGwfxxTHdu = -1948308232;
    string JcEQdh = string("oUpfOLnJiSeMBdJBsAjusnadnKJSvPqOEYwSoZboKEXbMxTjNJmZxRZQFbZRzwcweDuxxHDqlKpjafzogW");
    string aEFIUhrx = string("gwXNGPLGDgpMVlxSGrtTZLtGOvHgghvHxxLoqkKgoZuCAVvMLepcGmPrVoJbqrHzUfCkIvCbmhbnytCWnmAROivTypHLDfNoauUjtirmMfuvrppWgtufrbQLPruzoBdfhOwEhwyXEgWLvnWQdIykWmryNSSJCQQoCgBMkpQaJrkFucXFYfDziWIQrBxRWsWmkxkArG");

    if (AYHKuvemCXGPk > string("iJJusKEdanodGFanoFUzcaNIctesjtAEkUckckxmobuFNVgegMkSrVJkvjoyZozrCtIJcFJUazgWWukqIHBXNV")) {
        for (int jIYuR = 1130942858; jIYuR > 0; jIYuR--) {
            aEFIUhrx += klpxBPKf;
            AYHKuvemCXGPk = aEFIUhrx;
        }
    }

    if (FOxvDfjxgqFwK < 695502.7070136344) {
        for (int EZbQeeqJWmjzsO = 1944856330; EZbQeeqJWmjzsO > 0; EZbQeeqJWmjzsO--) {
            AYHKuvemCXGPk = JcEQdh;
            AYHKuvemCXGPk = klpxBPKf;
            kbmlOEscU *= kfkKkGDmFpEtq;
            kbmlOEscU += kfkKkGDmFpEtq;
        }
    }

    if (kfkKkGDmFpEtq >= 695502.7070136344) {
        for (int dKQEGaCgWbh = 1942988124; dKQEGaCgWbh > 0; dKQEGaCgWbh--) {
            aEFIUhrx = AYHKuvemCXGPk;
            AYHKuvemCXGPk += klpxBPKf;
            JcEQdh += AYHKuvemCXGPk;
            JcEQdh = JcEQdh;
            kfkKkGDmFpEtq = kbmlOEscU;
        }
    }

    for (int rHUXEZnFXRnMBp = 1895797539; rHUXEZnFXRnMBp > 0; rHUXEZnFXRnMBp--) {
        aEFIUhrx = JcEQdh;
        AYHKuvemCXGPk = AYHKuvemCXGPk;
        AYHKuvemCXGPk += aEFIUhrx;
    }

    return caKBzqXxIGJKFrH;
}

hhhaJOaKqSZZhhg::hhhaJOaKqSZZhhg()
{
    this->nRlCBEwBHr(string("XDPBulKhPykrgftpnqtafBEdNjgUATMjvmWMWcBMgZBkDFyVXDiUzRyghphlFNQvPKusLzXXbs"), 1032731.0920580771, 999715.7544218282, -238546.00560582793);
    this->mnRinydeBLId(string("IdusshERQIMWpIMgUwAZJbrSmEeZnDfcAGygjoHZGtLxbiZECHBLxzHyFzSkLysRbNkfZiNznkugQIzQBKYizgxQtCmlWbetFKSnYGXQCbIGQfTxWKKVDPFAwFRTQgTbpsaRIpfiCIiEqGOVtVLtRGtDzzBkadkCklrYvrTnZqaulaSmdZoi"), 363960.6306518865, 198606.77223713786, false);
    this->oVhsZGPphlC(-947858.0489000346);
    this->spQjYvBHkosCBr(false, true);
    this->ntgAOp(-929623.4094010481, string("nqPRJumcCHqVEKhSZxgSAXYuAzIPqSEAnLEicddsZCWmbrcdVQYksfxpNJkrFHKMNg"));
    this->XbUVZNOJVLJ(false, true, string("nXoWjNmqRlENMWVXgfnCmRsWKwbDXtscAnxPOPmqBCXkEDKnVhRGLTOZtCsrmMhInDUJENQVJACqBtaeirfBwcOdgKODLtJijHkAsufBTBAXRaEdWeCgwDZuINzaoKDFUOYbcCZKEfAYCBVpPLvWaENGXateVOSctlyZoLyjrzZcCPyktmXrqsqWhkxpmOFsQnnXTnswpvoBZfJgWAQPEjouurrhkNAbvstxqqzwrnhwnLHBPJTnAiMB"), -349335.8163095352, 1339968500);
    this->rmCZxVAKWR(true, -843790.4314133454, 695502.7070136344);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PcVbrKvDjuIoZg
{
public:
    int juahsQ;
    int aoaXEoecG;
    bool ygvvmnkLELJ;
    string HzKXQ;
    double NhkpSQdQEzAwBPo;
    string mMpgtyISZsKrCAFz;

    PcVbrKvDjuIoZg();
    double AxwrN(double yPNUU, double fpvpru, int PwRnTUaA);
    double WVhdE(bool NMvbobGAEBjcuYT, int SBEolZndzULonMP, string ZKWFwZMekARJEPc);
    string zeJpwkHzUGHWAK(bool NqhdwzOXnNzb);
    void ErdUieErqhwGmbRP(string fGJDzzhbnB, string hLaaWXqUTobR);
    string nrdLvoLnvQQPsPS(string nePxpabV, double fDFizYw, int BwrdjAThrjP, int bUSmIDgPYlrgqWNk, string QSMThtoVGhhrrC);
protected:
    string KzZzmfCPqrryR;
    bool zOHxEMPWXkIGLeZx;
    string lAjlzeeikoS;
    bool zpUlqamuYUjK;
    string ieScbnmfjMJpEUS;
    bool aknqUlKvOkfjvNeG;

    int eTPSOEUYGWx(int dMfHHhxwBAKQdSN);
    void AEMuFoJGWJAeH(int YcjKQ);
    void zqHoXcPIDuolxk();
    double YcxIXzoyDOLZqj(string PAFlWGynx, double ujJkjtJAZbZTX);
    double VBVPCnu();
    double OAROHgEBHtjIMAch(int CHMoqXPQoMtL);
    void TWbKqlk(string jmSJHMpvL, bool oBifJobnpcI, bool FZPhklKbnldU);
private:
    int fvgnLfD;
    double URPRQOecjVSdsK;
    int IGnBDdgGimnIJgB;
    bool qLTCG;
    double tOsuGoHqCQtP;

    void wBHfXIabLOaohF(string PjhfpICZBeFvdFd, int pfJGZGNH, bool QQNRoDQGTLPibHYx, bool omYrRfn);
    bool SZrGc(bool QQxgfFQfiAZJPjwq, string APJgDvC, string MjAEOkWitfZcjQD, double ITUGZWcfS);
    string wFKIrPbYtdv(bool ZsMIWBxuGKBAf, bool hYabJE, int vAynJ, bool OFhOKjbGgtFVqa, int zjvSoNfzFQZxBl);
};

double PcVbrKvDjuIoZg::AxwrN(double yPNUU, double fpvpru, int PwRnTUaA)
{
    string ecSFSo = string("RShOmqbCUzPczbAfvbxXQYbzaHcPDderEeRntDkSCG");
    double SJXGrvRhtYo = -918043.235974407;
    bool CVwId = false;
    bool lvDtePZTk = false;
    double AZIFZ = -11584.179315703523;
    string pBVuKAqvalyDUFrj = string("zxfhJTZoMGpAizsMHzaUYAsdlghvzhunxBzHBiSYXPJhtnMeMDORuqlGirFfYznRmYINjMzLsJRXOsjNvMluzhldxPcKxhHYMCkcrQjdJOqedDTEUrQqDRwHTaeoRBmVZzTuPCEIOoyVnroztWBPiJLUdqOGPeOETxkdQkZjZXORjpLhiqMeimeWYiJImYQBLENhGIuOHNTPmlI");
    string tQIgYJQqygFHe = string("bnYbCoNWSErJJGaFvuHzOFoFgktXmriqbUHRGbBaggKHsfHvisFCKekwNVidICAuaIfrShTeEylIohCTUvqbAohBgsZAkoahSvAtXgMnXXMuxQAXepsQyFHoq");
    string pVbdlfUiHLO = string("ZEuHilCUmzdZTIbtdqUPywZJfuZUfrBnfHRtwhbOUCZmavsAKLvmVSSTzKrcNedAEIAkCLCmXqMWiHiOgAmwZSXyjRFOlddMQBoSZtZanwVSGtZNRTxrOTEyVDvnDmqfzZTbOYfKvgRZTmJetbiBUDpzcOIQCFkBFYrRqGJuKkQzyRRCVlfAfEqgsSGlMHPCpjxWaXFbXnAcBSekDXB");
    string IJHpHRIMZ = string("aDKhoAIPYpFtyXMUYkLBOHMhAWcHDPwNuLRuMeuyeaSJCmDUBNwZiclnJMDeIAizjQekodAHiofivTSguJVvaItIyoscoKGzKlXstXixmBXPAJMVHYpttKLLMLnBZAobkXCcXzYWyPZAcjXnbsyYZTWYHrmvuwmJYIBYcxUlOnLHlwlPVsMzkQIMBctPxN");

    for (int WdHvrmQnIOX = 1937077560; WdHvrmQnIOX > 0; WdHvrmQnIOX--) {
        continue;
    }

    if (IJHpHRIMZ <= string("RShOmqbCUzPczbAfvbxXQYbzaHcPDderEeRntDkSCG")) {
        for (int vrZSI = 1979068902; vrZSI > 0; vrZSI--) {
            continue;
        }
    }

    return AZIFZ;
}

double PcVbrKvDjuIoZg::WVhdE(bool NMvbobGAEBjcuYT, int SBEolZndzULonMP, string ZKWFwZMekARJEPc)
{
    string zjvtcTDUxr = string("PiRQZMvzfHPTeNPJKVhHYovbGYPrYzDDaq");
    double gltmnLC = -549431.6004172708;
    double CbhrIF = -782731.2043456624;
    double RbxSGbTjkENlAu = -441235.6297259956;
    string UEwlgtwjOTKqK = string("UafDAyZkgEtcTPwadTbOhfXjObJwKhiHVcmXoDJqIQpQmesZwyVSODCfTNdpLWskmyNYLwnlnLdOHgQVAmgnFFrvSbAeVeVAhUtVLbfrzIBMkXqWIwbdCSsIIWlviiohHFeTDv");
    int PRkjxe = -1373182627;
    string TcwrCOJp = string("sfhvfzNLVRtOlVvUcZYqVxqdqCVVgtbtdMZuxopLSyFCayfUghYVjUyhYTZiUTVxQXrBNSIAWKWyFuwfCKAyWIFraQrPWxHEeOYvtoAudJPIWkhlEJxAntwPIRAKbNcexfAkMvmNyMBkFujVeQLCkPIFzFOMjjahSikwpDhYCZtvgWvSzQYnpswcadmAUTMpvilRLxR");
    bool usiRlmkyFhyIDO = true;
    double UUyiTNQsBtQBf = 452770.8816608283;

    for (int nlspJbXMOUlxtDbX = 684418639; nlspJbXMOUlxtDbX > 0; nlspJbXMOUlxtDbX--) {
        ZKWFwZMekARJEPc += UEwlgtwjOTKqK;
        TcwrCOJp += zjvtcTDUxr;
        UUyiTNQsBtQBf -= UUyiTNQsBtQBf;
        gltmnLC += gltmnLC;
    }

    return UUyiTNQsBtQBf;
}

string PcVbrKvDjuIoZg::zeJpwkHzUGHWAK(bool NqhdwzOXnNzb)
{
    int DcLDCuBoibY = 706904664;
    int yQBvowmebCrUtWeQ = 574392988;
    int LXEqoHnejV = 2092584969;
    bool KzXzcSRuWH = true;
    bool egqKK = false;
    int eUgrnxf = -1060096195;
    bool ZugSdpXKDRtrkYhp = true;
    bool AKPowMbgMpSeffVU = true;
    bool HOepqSpKbtvWj = false;
    int VBZIWwkPgLAhgvg = -321528854;

    for (int YoLdVbDJH = 1838401967; YoLdVbDJH > 0; YoLdVbDJH--) {
        ZugSdpXKDRtrkYhp = ZugSdpXKDRtrkYhp;
    }

    for (int EMXUabymebzOJn = 1184154634; EMXUabymebzOJn > 0; EMXUabymebzOJn--) {
        VBZIWwkPgLAhgvg += DcLDCuBoibY;
        KzXzcSRuWH = ! NqhdwzOXnNzb;
    }

    if (VBZIWwkPgLAhgvg >= 574392988) {
        for (int yDQYTKHA = 332315236; yDQYTKHA > 0; yDQYTKHA--) {
            NqhdwzOXnNzb = ZugSdpXKDRtrkYhp;
            KzXzcSRuWH = ! KzXzcSRuWH;
            AKPowMbgMpSeffVU = ! KzXzcSRuWH;
            ZugSdpXKDRtrkYhp = ! HOepqSpKbtvWj;
        }
    }

    if (LXEqoHnejV >= -321528854) {
        for (int POjVTQdZ = 2083987924; POjVTQdZ > 0; POjVTQdZ--) {
            ZugSdpXKDRtrkYhp = ! NqhdwzOXnNzb;
            eUgrnxf /= eUgrnxf;
            egqKK = ! KzXzcSRuWH;
            ZugSdpXKDRtrkYhp = NqhdwzOXnNzb;
            ZugSdpXKDRtrkYhp = ! KzXzcSRuWH;
        }
    }

    return string("NaA");
}

void PcVbrKvDjuIoZg::ErdUieErqhwGmbRP(string fGJDzzhbnB, string hLaaWXqUTobR)
{
    string qzkfOoN = string("VESzVYVRrUfQSVJsPiunkmiGcyZrjQHRlzcpFheGAPHzTOawLxEDQHaVmvwlbLIifCiwkotiLRJdOAhgxsydYlvmgADvrAaIsYYjBFLbcciSyzTWUcnWe");
    double OxjzrVfhqSPTiNvq = -729012.2981655209;
    int XAzOWgCRaQRBwXi = -1546517368;
    bool XaTUPMmz = false;
    double bRsaUNvZxKocX = 487619.9725243829;
    double lBuOJXiZkPclApM = -253590.15817671007;
    bool IbJLEARKSrJr = true;
    double YoMOrDFQHTI = 148689.0936943602;

    for (int oEikZJPgjMn = 1953437708; oEikZJPgjMn > 0; oEikZJPgjMn--) {
        YoMOrDFQHTI -= OxjzrVfhqSPTiNvq;
        bRsaUNvZxKocX += OxjzrVfhqSPTiNvq;
        lBuOJXiZkPclApM /= YoMOrDFQHTI;
    }

    for (int HqvCydaEL = 2107574447; HqvCydaEL > 0; HqvCydaEL--) {
        YoMOrDFQHTI -= bRsaUNvZxKocX;
    }

    if (YoMOrDFQHTI < 148689.0936943602) {
        for (int ShAWZQ = 704924735; ShAWZQ > 0; ShAWZQ--) {
            OxjzrVfhqSPTiNvq += OxjzrVfhqSPTiNvq;
            lBuOJXiZkPclApM *= OxjzrVfhqSPTiNvq;
        }
    }

    for (int wlxPHrqXdgu = 545402272; wlxPHrqXdgu > 0; wlxPHrqXdgu--) {
        XAzOWgCRaQRBwXi += XAzOWgCRaQRBwXi;
        qzkfOoN = fGJDzzhbnB;
    }

    if (hLaaWXqUTobR >= string("UsjpHqoilhiNPvBnNippiuewngglsHzXbsuxYhYLeFXjWwHOTXEKkxGwIYBZUSuaKhYfadHZYrxkRdNzvzCCCPtoGOugAXMQuafEmbWftPPnbKfbPnoHkQxIZOrhbqjJQvQhWkbiGCLlcsaQcLITXzuyBxdHzcbfRweyOvR")) {
        for (int ACRKvikfYGYjC = 1245138960; ACRKvikfYGYjC > 0; ACRKvikfYGYjC--) {
            YoMOrDFQHTI -= bRsaUNvZxKocX;
        }
    }
}

string PcVbrKvDjuIoZg::nrdLvoLnvQQPsPS(string nePxpabV, double fDFizYw, int BwrdjAThrjP, int bUSmIDgPYlrgqWNk, string QSMThtoVGhhrrC)
{
    bool OEfKf = false;
    bool FwgLFTSjZILXTS = true;
    double LLEbvkeAxInqH = 912405.8625853341;
    double MqCCRsqowvIF = -421192.4505414602;
    int saiSlSxXT = -1947841746;
    double TumTjKfqdy = 5407.627873643044;
    string RTWnGahkypPmsQC = string("ZGtvqcEIKDXzeVlnoooYtIxFMOoGYIkfaErSHZgBdrQasHlSIqKrKGcVnunMJPq");
    int zxipTmDnRueRs = 1412277229;
    bool kohybcZVZfNww = false;

    for (int vBPMlwN = 130635507; vBPMlwN > 0; vBPMlwN--) {
        MqCCRsqowvIF /= LLEbvkeAxInqH;
        kohybcZVZfNww = FwgLFTSjZILXTS;
    }

    for (int MjEsOLczoQmR = 848959451; MjEsOLczoQmR > 0; MjEsOLczoQmR--) {
        BwrdjAThrjP = zxipTmDnRueRs;
    }

    for (int UFrpXukB = 1614519387; UFrpXukB > 0; UFrpXukB--) {
        continue;
    }

    for (int SFMunrzQQumJLEwS = 1810652808; SFMunrzQQumJLEwS > 0; SFMunrzQQumJLEwS--) {
        continue;
    }

    return RTWnGahkypPmsQC;
}

int PcVbrKvDjuIoZg::eTPSOEUYGWx(int dMfHHhxwBAKQdSN)
{
    bool ZqlQLx = true;
    int ZdEpyGlLpqFQ = -706789187;
    bool SeIRVHj = true;

    if (SeIRVHj != true) {
        for (int nHNDCejz = 1100539751; nHNDCejz > 0; nHNDCejz--) {
            SeIRVHj = ! SeIRVHj;
            dMfHHhxwBAKQdSN += ZdEpyGlLpqFQ;
            ZqlQLx = ! ZqlQLx;
            dMfHHhxwBAKQdSN /= ZdEpyGlLpqFQ;
            dMfHHhxwBAKQdSN /= ZdEpyGlLpqFQ;
        }
    }

    if (ZdEpyGlLpqFQ >= -706789187) {
        for (int QYLFwjrt = 1906387193; QYLFwjrt > 0; QYLFwjrt--) {
            SeIRVHj = ! SeIRVHj;
            ZqlQLx = ! ZqlQLx;
        }
    }

    for (int LAPlzIYlOkBpIe = 248903720; LAPlzIYlOkBpIe > 0; LAPlzIYlOkBpIe--) {
        SeIRVHj = ZqlQLx;
        ZqlQLx = SeIRVHj;
        SeIRVHj = ! SeIRVHj;
    }

    return ZdEpyGlLpqFQ;
}

void PcVbrKvDjuIoZg::AEMuFoJGWJAeH(int YcjKQ)
{
    bool YktDgA = true;
    bool ROcLyI = false;
    bool VLEBhkgUJmCU = true;
    string MGTzOY = string("Br");

    for (int cOiyyxNWk = 1720494614; cOiyyxNWk > 0; cOiyyxNWk--) {
        MGTzOY = MGTzOY;
        ROcLyI = VLEBhkgUJmCU;
        YktDgA = ROcLyI;
        VLEBhkgUJmCU = ! ROcLyI;
    }
}

void PcVbrKvDjuIoZg::zqHoXcPIDuolxk()
{
    string qzCDw = string("PHbpaWISUHyBsevXnhPDtAjgQlHMsRiPEqMFAKDHxQvFsMeGWhnuwvnZGY");
    double SpSSXMNsJmPCM = -288645.83789692196;
    int HVwbipkHSG = -594502209;
    double CyEgNCWZQIoQGe = 756395.8333990745;
    double IobwyGxM = -309125.06930443365;
    double kUPJtptK = 368224.39485466713;
    double MVjcJXuaQsCitt = 643479.3156306234;

    for (int zvpXkee = 1518712410; zvpXkee > 0; zvpXkee--) {
        qzCDw += qzCDw;
        MVjcJXuaQsCitt = CyEgNCWZQIoQGe;
        MVjcJXuaQsCitt /= IobwyGxM;
    }

    if (kUPJtptK != -309125.06930443365) {
        for (int DYGwebkDjNnXzzJ = 1785996792; DYGwebkDjNnXzzJ > 0; DYGwebkDjNnXzzJ--) {
            MVjcJXuaQsCitt += MVjcJXuaQsCitt;
            kUPJtptK += IobwyGxM;
            SpSSXMNsJmPCM *= CyEgNCWZQIoQGe;
            HVwbipkHSG = HVwbipkHSG;
            IobwyGxM = IobwyGxM;
        }
    }

    if (kUPJtptK <= 368224.39485466713) {
        for (int mKjuCxrTXjHr = 1686083966; mKjuCxrTXjHr > 0; mKjuCxrTXjHr--) {
            CyEgNCWZQIoQGe /= CyEgNCWZQIoQGe;
            kUPJtptK += IobwyGxM;
            IobwyGxM -= CyEgNCWZQIoQGe;
            kUPJtptK += MVjcJXuaQsCitt;
        }
    }

    for (int vZnyw = 1083149108; vZnyw > 0; vZnyw--) {
        SpSSXMNsJmPCM *= MVjcJXuaQsCitt;
        SpSSXMNsJmPCM /= kUPJtptK;
    }
}

double PcVbrKvDjuIoZg::YcxIXzoyDOLZqj(string PAFlWGynx, double ujJkjtJAZbZTX)
{
    bool KjNYbrCFe = false;
    string xXSzDjp = string("bDTtHsVBFoFJtgoGquqZNtdxuHFnlBIYiuBhynXlmXUcdftPTURCXRSLwoxDOlXfLdxgtpofxaprdtGHPokJvPElrapjuiStRNdKMIazJRUFPQINHPLNDPpVECLbbPVM");
    double gRWFKl = 806317.4693431203;
    bool pZQPFnfoJCwwWP = true;
    int siTPmNShrbUbtMR = -1416300815;
    string pnhdqAxCfuwkX = string("ZmsIpeRKSxoMBKFiMzCWBmnecxLdGcFlEmVMDyliyiIitvEkeFQdNITmTskfDIPluCN");
    string QfSMt = string("PHERnKSBbUBdBkCNnbzuwWUvqjUJydUrRqnuEZddSWoNvnEYGXTBexbMQFzAQovqxjRmtWPjckbYIhTufcfwclZzEyKfTZGHTXdpUJxuNtpjtMviarTXQUULluEhIvlxMRbClMuKkuGhZWlkNkvPGtoVcqcyXNPoIaOnQLqSjpsARsEroGNVJZ");
    bool OjMdemYmiDZWTKWF = false;
    string KMxrtJCYr = string("tfybRwFeODfaZgpgrNjTzccnOkAhsrpQNyZXdGZkTrCwAvwjTAZuRVjSaeCLSxtCoVaBF");

    return gRWFKl;
}

double PcVbrKvDjuIoZg::VBVPCnu()
{
    double JqjwzYeXFRJESYxd = 88198.13921645079;
    int YFBbDusrqXgXRtw = -487241064;
    double tSwpRqHgdZIjM = 147937.70296907474;
    string cNDZybJbwqjOW = string("RuyDAIJVgPAPNERaJDRsBzbZKDgUrVDSVQurbGTxeZcbMPrmLoyWIOsNehtduzcgyxowaMFkEFMJYogAqijXgFOopucXDAvjksFxPkWmSHuWzAGAoMqzqttEKShHjOanWGAvNHMxboyCTERPcTJguICfYuHVtCuffqazDKtumZSenuyHxCdAlrlgmYr");
    int XSahFzGXZPbevRnb = 1136944819;
    double DXJCFkqfXeN = 805352.2301494771;
    int vOXDxI = 984456621;
    double ACVJWFQCBHXxPhoX = -504361.2451992601;

    if (XSahFzGXZPbevRnb > 984456621) {
        for (int OUSyMaFhJL = 479723070; OUSyMaFhJL > 0; OUSyMaFhJL--) {
            XSahFzGXZPbevRnb += vOXDxI;
        }
    }

    if (tSwpRqHgdZIjM >= 147937.70296907474) {
        for (int uOJSonu = 559563430; uOJSonu > 0; uOJSonu--) {
            YFBbDusrqXgXRtw += YFBbDusrqXgXRtw;
            vOXDxI += XSahFzGXZPbevRnb;
        }
    }

    return ACVJWFQCBHXxPhoX;
}

double PcVbrKvDjuIoZg::OAROHgEBHtjIMAch(int CHMoqXPQoMtL)
{
    bool mSSGJJGKbJlCuxT = false;
    double tJwaYpWosUsFBjY = 804987.5873212584;
    bool gvIDRwT = true;
    int xFZPkYbXQTjjUHmL = 1438507849;
    int yoQfjulPjQzG = -752722897;
    int CukWTQTCBuUlqTCW = -297958516;
    string ziCyJoIP = string("WXboyFhAQVlNjeitMrdzWoOrwHGbCbHbdMftUegDRiuBBzThqKVruowkWiXHbmsqjtpbCzsSP");
    double DatEzAWFXVbMKMZw = -859957.7204799699;
    bool wWfTMQWgCc = false;

    return DatEzAWFXVbMKMZw;
}

void PcVbrKvDjuIoZg::TWbKqlk(string jmSJHMpvL, bool oBifJobnpcI, bool FZPhklKbnldU)
{
    bool kdIquY = true;
    double xMjdARcNcA = 740856.0728611748;
    int ZOzhLBPCySTjQ = -1888615718;
    bool AvOFd = false;
    double KCWhkSvCJP = 873466.6425796102;
    int BdeUNQksKAmAzE = 1237835451;

    for (int SdQiO = 1894991961; SdQiO > 0; SdQiO--) {
        ZOzhLBPCySTjQ -= BdeUNQksKAmAzE;
    }

    for (int JsGWMQnTvD = 739518176; JsGWMQnTvD > 0; JsGWMQnTvD--) {
        kdIquY = ! FZPhklKbnldU;
        BdeUNQksKAmAzE = ZOzhLBPCySTjQ;
        kdIquY = FZPhklKbnldU;
        oBifJobnpcI = ! FZPhklKbnldU;
        FZPhklKbnldU = FZPhklKbnldU;
    }
}

void PcVbrKvDjuIoZg::wBHfXIabLOaohF(string PjhfpICZBeFvdFd, int pfJGZGNH, bool QQNRoDQGTLPibHYx, bool omYrRfn)
{
    bool qIjzbWIWASXeNO = false;

    for (int KlBZSAiRKtyxq = 1898667766; KlBZSAiRKtyxq > 0; KlBZSAiRKtyxq--) {
        qIjzbWIWASXeNO = ! QQNRoDQGTLPibHYx;
        omYrRfn = qIjzbWIWASXeNO;
        omYrRfn = omYrRfn;
    }

    for (int gyzFUGATwNovdtX = 2119996788; gyzFUGATwNovdtX > 0; gyzFUGATwNovdtX--) {
        continue;
    }
}

bool PcVbrKvDjuIoZg::SZrGc(bool QQxgfFQfiAZJPjwq, string APJgDvC, string MjAEOkWitfZcjQD, double ITUGZWcfS)
{
    bool LvKkHFTTYTapLqNV = true;
    int ttuIRrlgJteAG = 1430426395;
    string NnKlIrLcccrUJRM = string("bgQjgqTLPcRmpZvh");
    bool XgHOmVRxBbKKX = true;
    int OXbWYbVySSEe = -25935702;
    int ZLGMA = 745910768;

    if (ZLGMA < -25935702) {
        for (int cqXmnmqOU = 59791605; cqXmnmqOU > 0; cqXmnmqOU--) {
            MjAEOkWitfZcjQD = MjAEOkWitfZcjQD;
        }
    }

    return XgHOmVRxBbKKX;
}

string PcVbrKvDjuIoZg::wFKIrPbYtdv(bool ZsMIWBxuGKBAf, bool hYabJE, int vAynJ, bool OFhOKjbGgtFVqa, int zjvSoNfzFQZxBl)
{
    string djZGgNzDaHLfzSl = string("gFyjdMaDBQwoibieIEBLVDpKGixCYpyfXskLBMPKFrUWUhMhJwXEgphVxsjTMJgEeVKXjDeUugLZcrynZlbkiYLaiikUiwKZgJkzqbiMcgqMHIjTfcTvIXYXDoQcQUBadFGtLEBKbcrNBzybUHqfQCBPeawKkcmjzvRhkREUVoySXejsRMlBnNvlYTfbtHJlxHuVmZtItLMhFfetOchlzImaDCRF");
    double ecPurtBITTX = 662217.0713216816;
    bool WoOMdsrQrBEmfc = true;
    bool ZJkcLeKaAAh = false;
    double ceVfIJpspAw = 219731.89720428395;
    string edCIjjaa = string("kuDNjHTYGuChTIBJyxovgdNNSTgvIMQNcytokmTAIfCKUHmrjIewDNauaYuDWcmFe");
    bool zZusJLps = false;
    bool Tqsnrpls = true;
    bool kRHREskZD = false;

    if (hYabJE != false) {
        for (int ztSbiJOAlU = 2100612030; ztSbiJOAlU > 0; ztSbiJOAlU--) {
            ZJkcLeKaAAh = hYabJE;
            kRHREskZD = Tqsnrpls;
        }
    }

    if (ZJkcLeKaAAh != false) {
        for (int yxUAOFGgPI = 999187392; yxUAOFGgPI > 0; yxUAOFGgPI--) {
            ZJkcLeKaAAh = ! ZJkcLeKaAAh;
            ZsMIWBxuGKBAf = ! Tqsnrpls;
            ZJkcLeKaAAh = ! kRHREskZD;
            Tqsnrpls = ZJkcLeKaAAh;
        }
    }

    for (int wzuaZxq = 1111808770; wzuaZxq > 0; wzuaZxq--) {
        hYabJE = ! zZusJLps;
        hYabJE = zZusJLps;
        kRHREskZD = ! kRHREskZD;
    }

    return edCIjjaa;
}

PcVbrKvDjuIoZg::PcVbrKvDjuIoZg()
{
    this->AxwrN(225496.91050791397, 728384.9016835637, -1964360706);
    this->WVhdE(true, 2022394181, string("HUGCSUrmMMbFJgATNCFkbIvtUCtBCrYncdpYmKvSRQcAQeMSbRxgWKyFXuv"));
    this->zeJpwkHzUGHWAK(false);
    this->ErdUieErqhwGmbRP(string("rXCgFnuupCvaPFkjZcYayxmcwZEWJNg"), string("UsjpHqoilhiNPvBnNippiuewngglsHzXbsuxYhYLeFXjWwHOTXEKkxGwIYBZUSuaKhYfadHZYrxkRdNzvzCCCPtoGOugAXMQuafEmbWftPPnbKfbPnoHkQxIZOrhbqjJQvQhWkbiGCLlcsaQcLITXzuyBxdHzcbfRweyOvR"));
    this->nrdLvoLnvQQPsPS(string("GkEJVWvtzIebquMYSrShtUFzCTrNJyFKsctDDQhVpKzyopUiMJroMQqXsrUIiFkwJZlCebdsKGfIFaSVosCHrFJHRgdGUFguQTANMGAKHPDDTKTdrUJuWZgVgbfSbnXkvQwsNdHIkqgpcGWxDELhHomGtqQpGAKztsikIDCzwpxUDCWzFvEsCykOlXKTUVW"), 354821.88900665776, 936434777, -955076788, string("vDUJiFmnjSmCaBshmWjciafuWClCdRtdJVbnrowvoOmqGWixpVOjMUgWSgOTnSzRHJbmdNAOdzrwGRhRHdqoyRCkVpyvPdPSnkWklRPLRlbqjFoVcWXZyhqLCZWefaRBRWNeEmjbVsGNPdKZaWRULvdBTYAbQlAaxndZByZxMDrMfaGHSOhmpcOxuTugBIAgxdNRPMgRqueVMXXTQisHOCr"));
    this->eTPSOEUYGWx(-1339498456);
    this->AEMuFoJGWJAeH(-1106510615);
    this->zqHoXcPIDuolxk();
    this->YcxIXzoyDOLZqj(string("FaHjYZmKSkAQIyfiaTkqYXNpBqnqpveSFHFLrkoTiUUWmIcAGTUgDNHbJxqJupOowZypAVvihZKgjfqiAgYUGbIdWAjyeqpiZrjYAcYOgsTVwkzwaXBDHnOXBufMYaKVlXXyeIJHCfdJxkifpvxHphmgsNDttSuVXdxH"), 298635.8357882639);
    this->VBVPCnu();
    this->OAROHgEBHtjIMAch(950097782);
    this->TWbKqlk(string("dUpMrtMzqdUeMlBfwXeouxOUyhPcHwjoNXXBGrVFaErtgVBcknQIoxrTvQaDRtnoDwxzMMmIfvHjwbXdAVBsLcpsifonQilwUhEYTMwpDiArKegzrrvPiJllZBwWkeDVJupTVYPFoXGadYqjkEOvxHdqZpgwEhGOlfOiaqWvudRGCbOKhTlTQrbMCLfyOQuzNEQMuKTsFQIlSYyhYPdrdwsyxlOMJeevJREGSMpJl"), false, true);
    this->wBHfXIabLOaohF(string("YVyHW"), -1681781543, true, false);
    this->SZrGc(true, string("HLvSbKbUKDuwUlZyVnUvKfNUlKNdfsEXZzLELdrKwpCTLjucTZthiEfQAaMqbhHJNAMdsTuMOMFOlWYycXPwmIudepOWfhuXfzNeoSOdXOqRanFQOadbEGOw"), string("PnWGWXbLbmBYdUrXyjNwLqiAuuRYyCvOgICzRrlVLFiFeClvytvIvoDvzzfo"), 944900.512505485);
    this->wFKIrPbYtdv(true, false, -8504696, false, -1829910268);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NNcxmuILyqIH
{
public:
    int HAWhPytQWXLFayfJ;
    double VCjPyuOy;

    NNcxmuILyqIH();
    int YAjQoo(int xgrwqXJogldmrhg, string xAJRTstra, string naYXUMkhMkTtuY, int QaUpFzsVPK, bool nqtSm);
    string SfmbtMya(string uGcxnliDRFDXhBZt, bool nHMxeXNo);
    string bturCzS(bool EinxbUn, bool CGwGqVDwNMvuiW, string RmPVXhgwCRKE, double tCBgRtM);
    void yRSRdbUKgXwcZZ(double GnxGtVbURVptAd, int RyBeAtUvdys, string WidlRMZWUrqd, double phatqGXIJpok, double eCTXzLvwYqTJmtXy);
    bool CJTCVpCbm(bool OBhNeyjAS, string dgfoJAUUKvqw);
protected:
    int meWFizvQGQz;

    double BuCAYHQXx(string YGeEDFDSaWRVpBrW, double KXsBTcjnJePdoOj, string RqqZcMNPqxQwz);
    bool XtKpvOEyzm();
    string DlZrSmN();
    int bzKpLSFne(string YDJNmvaGpKvPNUm, string APApSvWnPSIPko, bool mDlbnsVavPF, int cnUNhWZsxCaEqod, bool MwtydsAuqCvk);
    void vioFzIYvjITMWuo();
    double iOlsPvw();
    void uSnqjJSbt(double qIDnJQXQ, double wYyCf);
private:
    string AECrLHjx;
    int POVIgpnIeE;

    double XPcjxPupMydat();
    bool UlogZsyFHj(double AZwEvcjraTNb);
    double DRGiYLutLnljrmC(double UlSiJEJHaZFXWm, bool HGpmFtBFLJUWvU, string dsRJSwsa, bool iggyMsEUWyZtC, bool KSUiHmgPsQvldP);
    string qFmCFdVBO(double MGfLgZIbpQWEf);
    int HANGSIUxjXFljyhH(double rSoNobyT, bool wDAxqcim, int SConmGdyqX);
    string wFqzxpeFfSvCLsD(int hbilV, int cpslNuUILN, string WgbGBwP);
    void GbjKoldmFBZdS(bool fkCYTb);
};

int NNcxmuILyqIH::YAjQoo(int xgrwqXJogldmrhg, string xAJRTstra, string naYXUMkhMkTtuY, int QaUpFzsVPK, bool nqtSm)
{
    int sEYTTw = 1765909707;
    double DXAbNs = -1046671.1649582811;
    int BXpVeJAraFLJRgg = -688455837;
    string ALIMkNFrDxFA = string("sVmqUaNWDdaLItfchrUDsZFDPURltDRgoDoedLjYmoLOtYYSDGftgMTSwbOwFFDoAqFplpMJePqeurOOFrIbutLKkbKdEBwIAUhqHmYdIonYJ");
    string GKlGVUt = string("aksyEZZdufvlHhhtlsqBpxqSGatGwmgXnJUlKGqHKBzAaEdpfiBhnCNhmoYxJMWZGlDHOhRcMmykLayUiBxAZBQSNtvjm");
    double faKdBOkW = -221513.87681963513;
    bool SxqAIODqIBG = true;
    int cwBYj = 1837670472;
    double MpwKB = -84007.11054121195;
    double uIYXrXZKTgtn = 993269.1100459257;

    for (int qkmEKXqetnHkOqND = 323045009; qkmEKXqetnHkOqND > 0; qkmEKXqetnHkOqND--) {
        continue;
    }

    for (int CmrGPAVQpHDRusXH = 81423921; CmrGPAVQpHDRusXH > 0; CmrGPAVQpHDRusXH--) {
        naYXUMkhMkTtuY += GKlGVUt;
    }

    return cwBYj;
}

string NNcxmuILyqIH::SfmbtMya(string uGcxnliDRFDXhBZt, bool nHMxeXNo)
{
    bool edeIz = true;
    double VYrxIuxqc = 169696.95304280255;
    bool fZkaEnljpGxhN = true;
    double NTZyF = -173466.94797300338;
    int FcWqkQ = -1469150612;
    string kBawnnawDxMoBl = string("eBSnucJxRqiuuFtbTeahPkMJrDLFxWAwHSfxXKNGZourpOuWGsgmDgglSmoRfywJoVbLzrKBZFNJxNZGGaPlrsXkEnjepGkf");

    for (int KxtLscg = 710951731; KxtLscg > 0; KxtLscg--) {
        continue;
    }

    if (kBawnnawDxMoBl != string("eBSnucJxRqiuuFtbTeahPkMJrDLFxWAwHSfxXKNGZourpOuWGsgmDgglSmoRfywJoVbLzrKBZFNJxNZGGaPlrsXkEnjepGkf")) {
        for (int ETPibA = 1237033668; ETPibA > 0; ETPibA--) {
            fZkaEnljpGxhN = fZkaEnljpGxhN;
        }
    }

    if (uGcxnliDRFDXhBZt < string("eBSnucJxRqiuuFtbTeahPkMJrDLFxWAwHSfxXKNGZourpOuWGsgmDgglSmoRfywJoVbLzrKBZFNJxNZGGaPlrsXkEnjepGkf")) {
        for (int aKuQNbeHmsiAm = 916497049; aKuQNbeHmsiAm > 0; aKuQNbeHmsiAm--) {
            continue;
        }
    }

    return kBawnnawDxMoBl;
}

string NNcxmuILyqIH::bturCzS(bool EinxbUn, bool CGwGqVDwNMvuiW, string RmPVXhgwCRKE, double tCBgRtM)
{
    string lFHEQVGilKFVDhG = string("fYIvnjARUdNnfULFnBhYDftiLSdNeocrWFUaZpOFADMBmUfEHoIlUkdBSTIoXCZuFPEVbSgMJCPQoELTMFPzRABWjNPMboUORuMTFBVdbHcgmgBvpTUzNCKzQjMJzmTxtHHufwqdfBxgYwINFUNobZBKuvuLXmSqDPCRoxghMWEVEBeOqwJmLJkepWyqmJQERhnCQAQepNkh");
    double MgoPVAgfaP = 642459.1669851174;
    bool LxFCbUdKFygG = false;
    string JehEGM = string("BdRtWRGZIRDhjbbZlUFEkzzhxTqNhiwFFLhronbJrCANAjHGkGLZAmwVnJSVTvLcpWXFrDLAsjhaXXFiLkHKIszpBTuYYCgvAWgkMqOcAnsEtbHKPNEhcXgJlBOyKbgIG");
    bool eMxApGP = true;
    bool jMOjJIgeqintLTPw = true;
    double qFgspdk = -111152.42874334144;

    for (int lCMAUCKqTItE = 1055066547; lCMAUCKqTItE > 0; lCMAUCKqTItE--) {
        CGwGqVDwNMvuiW = ! jMOjJIgeqintLTPw;
        MgoPVAgfaP = MgoPVAgfaP;
    }

    for (int OkSZtwxmmrIQTn = 1977310313; OkSZtwxmmrIQTn > 0; OkSZtwxmmrIQTn--) {
        qFgspdk = MgoPVAgfaP;
        RmPVXhgwCRKE = lFHEQVGilKFVDhG;
        CGwGqVDwNMvuiW = ! CGwGqVDwNMvuiW;
    }

    for (int GisLzAxeVCVEivr = 1076148670; GisLzAxeVCVEivr > 0; GisLzAxeVCVEivr--) {
        LxFCbUdKFygG = ! CGwGqVDwNMvuiW;
        lFHEQVGilKFVDhG = JehEGM;
        EinxbUn = eMxApGP;
    }

    for (int lLOKUCbZVu = 816386725; lLOKUCbZVu > 0; lLOKUCbZVu--) {
        eMxApGP = ! jMOjJIgeqintLTPw;
        jMOjJIgeqintLTPw = EinxbUn;
    }

    return JehEGM;
}

void NNcxmuILyqIH::yRSRdbUKgXwcZZ(double GnxGtVbURVptAd, int RyBeAtUvdys, string WidlRMZWUrqd, double phatqGXIJpok, double eCTXzLvwYqTJmtXy)
{
    string MFRQHqsfVq = string("iQyennwYNUxgZjIfpmmWDFCpwWJOxOZvIRwNHoqfXgBWpkmQtYTAfsHrPGMOALzYrJrEQVKWgmAhWREaTdxcCXbihLhQxXpmOgLyhcKqwlYEWJJZfuvePWmPauQcezlBpGfUxoAXEIsfkxcDsmsJadPTqCsUsxVco");
    string xevmzv = string("OeRZxKxPOeNpZuNIBhfrljjZJzZFvfBftTJdxtRMFcVZTVNamwYoiBUeCSseZQJPbgPtmPDiqIsoLmGghCZXzbAOMtwTsBOqWHvmYcuSJYrjDzqREgYRsXIpvvAEPlYZgcEMZAbSFNVxbxjzNicrnTvsOeHANBeTLSQqetBpfWOSvPduwhzevKjCsIZNKeSctMEBjXHZBFzAyIcgxHuszNMojrfErXCTysZIayhgSjOyBreBKk");
    bool ODluL = false;
    double sfqkProTcwL = 278112.48808465095;

    for (int PgfqnXNQEbAjhIMo = 988673626; PgfqnXNQEbAjhIMo > 0; PgfqnXNQEbAjhIMo--) {
        sfqkProTcwL *= GnxGtVbURVptAd;
        phatqGXIJpok += phatqGXIJpok;
        GnxGtVbURVptAd = GnxGtVbURVptAd;
    }
}

bool NNcxmuILyqIH::CJTCVpCbm(bool OBhNeyjAS, string dgfoJAUUKvqw)
{
    bool uzNjDzxGANxzY = false;
    double zIbfygibroNwobuc = -9720.307738249778;
    bool zmrOyKyLML = true;
    int IxMVC = -243932522;
    bool EVTJCoALdWlVC = true;
    string ldOYvBpmdR = string("ANjVYruhiBGBZmFCnEjNibJjdJFVGIyoStuZrUWjOZPLjrRFnXNzrqnEKyPdRREojwmuVbuXQtSTOvdjaHrDFKQMDiZlOqzTHYbOWHFYKEImsLMKtJBEFtendqKamCRvfjmcKYlXaYbswhrCSQPvAXnucprUXCIHdgsDitrQZjLbaDkVzdBRINYvNJg");
    int QrEAyCXRnMv = 1788901673;
    string nmJmKmFumVgMj = string("qpkozKffkymLeJIefvkxEGEOwyQInQtllmrdcqaNOEsAsPAIUyWkNtWRpwqTBhDDexjeOytoqBKAaxBisKrAvzCVWEbVzDzurQnoetgopcJjMnWQDQRuleiwuBLUoxcYKRujLPqdLHHFxESXrNcibxykNIafeEDnLgOjQoXmvEKrPFNBgCxAzuSTLPwZGjCMFyOugg");
    bool GmmgvdF = true;
    string QBtFU = string("wYhOvcZUhbxjGhOMXWmnZecTAqkcfQjCQGojHvloQyJsPgEaAwFLXFbOvvALZNaQHDuNUSQgqjUXmROdxRzGZInyclLkkGkCm");

    if (GmmgvdF != true) {
        for (int JjuPIPMmOXTcxZCn = 1416423121; JjuPIPMmOXTcxZCn > 0; JjuPIPMmOXTcxZCn--) {
            uzNjDzxGANxzY = zmrOyKyLML;
            ldOYvBpmdR = nmJmKmFumVgMj;
        }
    }

    if (zmrOyKyLML == true) {
        for (int CsLvZ = 1364120733; CsLvZ > 0; CsLvZ--) {
            OBhNeyjAS = OBhNeyjAS;
            dgfoJAUUKvqw += dgfoJAUUKvqw;
        }
    }

    if (uzNjDzxGANxzY == true) {
        for (int MypHRbI = 1919720902; MypHRbI > 0; MypHRbI--) {
            continue;
        }
    }

    return GmmgvdF;
}

double NNcxmuILyqIH::BuCAYHQXx(string YGeEDFDSaWRVpBrW, double KXsBTcjnJePdoOj, string RqqZcMNPqxQwz)
{
    bool wKKvfwtyvwmLHvx = true;
    double QyVpc = -709482.9912748481;
    bool NosXENAyFFC = false;
    int CxIZKQIYotomEU = -1801976423;
    double SLGVTykZBwHs = 712243.9844452005;
    int EXkWRWqJPR = -303231699;

    if (EXkWRWqJPR == -1801976423) {
        for (int DrajaS = 1713948854; DrajaS > 0; DrajaS--) {
            continue;
        }
    }

    for (int VTziqxoTYW = 1468724054; VTziqxoTYW > 0; VTziqxoTYW--) {
        YGeEDFDSaWRVpBrW = RqqZcMNPqxQwz;
    }

    if (wKKvfwtyvwmLHvx == false) {
        for (int eBYUHrsjkdKlp = 1040387950; eBYUHrsjkdKlp > 0; eBYUHrsjkdKlp--) {
            EXkWRWqJPR = EXkWRWqJPR;
            KXsBTcjnJePdoOj *= KXsBTcjnJePdoOj;
            QyVpc *= KXsBTcjnJePdoOj;
            EXkWRWqJPR = CxIZKQIYotomEU;
        }
    }

    if (QyVpc == 503149.68510245293) {
        for (int GBcnsEvVtty = 2034113508; GBcnsEvVtty > 0; GBcnsEvVtty--) {
            SLGVTykZBwHs /= QyVpc;
            NosXENAyFFC = NosXENAyFFC;
        }
    }

    for (int DwPswkvYkVUXb = 19274499; DwPswkvYkVUXb > 0; DwPswkvYkVUXb--) {
        QyVpc += KXsBTcjnJePdoOj;
    }

    return SLGVTykZBwHs;
}

bool NNcxmuILyqIH::XtKpvOEyzm()
{
    string JPeHPkMIZaysXvA = string("ydLLyMCfJGJNLOcNcaKfRPEhGqFvhaRabYXUBflAxWVaGUlAsRBKZqGGKbWhdagGnXxTqrlnegRYCrIIRMmeKCqCacJalbDVCKAwqMXfSmPAuhtGPHRXDjpImxxyHBSyXgKuMNAKUudVmjDG");
    int CCjpZvkhbeCZPtaw = 1677813984;

    if (CCjpZvkhbeCZPtaw == 1677813984) {
        for (int QzDvFLRCCfFQgH = 1550677417; QzDvFLRCCfFQgH > 0; QzDvFLRCCfFQgH--) {
            CCjpZvkhbeCZPtaw -= CCjpZvkhbeCZPtaw;
            JPeHPkMIZaysXvA += JPeHPkMIZaysXvA;
            JPeHPkMIZaysXvA = JPeHPkMIZaysXvA;
            CCjpZvkhbeCZPtaw /= CCjpZvkhbeCZPtaw;
            JPeHPkMIZaysXvA = JPeHPkMIZaysXvA;
        }
    }

    for (int dxaXJvlIwrOGONj = 222975093; dxaXJvlIwrOGONj > 0; dxaXJvlIwrOGONj--) {
        CCjpZvkhbeCZPtaw -= CCjpZvkhbeCZPtaw;
    }

    return false;
}

string NNcxmuILyqIH::DlZrSmN()
{
    double woxzlN = -806264.539334481;
    int WDfqh = 1283962565;
    bool UvIwYAiuiknL = true;
    bool uuImXALPbpKOoMZp = false;
    string gdJZiITJksNBG = string("gRbnwvDJYZTsnSFWabHSrJAZfMNYmJnOfbLSyAiFstRNVNgmzgKsQjmH");
    string DyyRyWr = string("ccWOhRMqdaVtpPtDsauIgAKaNYjpLznUhllowtctlHCcaRYwidHCLBlsAzqWtGLVOtrvPhDPrTFkMrQKJwBmQjgbzevNqpNGtBaShmFJmSpGfEGXnubmOXQSyjLbKESZDqoYomqDSkHLtBFenDpLJQOdGuxFlumabpaJcJLfrpMsrYIlgrGQnFCnNTgg");
    string hBVLFAPdlhvsu = string("YwLkFELvSwOOPSuUMZxwqrHTvxjWaHjnYYEOElZJBEkvtFgRsinLZNGvtkbgEBMAuEhzEnuzmYnUPniJFIQGkKamqbGGNVwnrwsoYeEdgyeDNnegjormNBCbnlpkTgbcQlQWCPNdEXxhuueGfBvFDmdHhMcGyQTXklEThK");
    int uTHLeWLebNdDj = 1579052949;

    for (int qWLoBouA = 271260203; qWLoBouA > 0; qWLoBouA--) {
        uTHLeWLebNdDj = WDfqh;
        gdJZiITJksNBG = gdJZiITJksNBG;
        DyyRyWr = hBVLFAPdlhvsu;
    }

    if (hBVLFAPdlhvsu == string("gRbnwvDJYZTsnSFWabHSrJAZfMNYmJnOfbLSyAiFstRNVNgmzgKsQjmH")) {
        for (int HeFTWFSRdTfTm = 1271177395; HeFTWFSRdTfTm > 0; HeFTWFSRdTfTm--) {
            WDfqh *= uTHLeWLebNdDj;
            hBVLFAPdlhvsu += DyyRyWr;
            woxzlN += woxzlN;
        }
    }

    for (int vlLTTGHQxScWJNeZ = 1971450377; vlLTTGHQxScWJNeZ > 0; vlLTTGHQxScWJNeZ--) {
        DyyRyWr = gdJZiITJksNBG;
        DyyRyWr += hBVLFAPdlhvsu;
        gdJZiITJksNBG = DyyRyWr;
    }

    for (int FXKbdvZCbxsfY = 2100599845; FXKbdvZCbxsfY > 0; FXKbdvZCbxsfY--) {
        continue;
    }

    if (WDfqh >= 1283962565) {
        for (int CptbFGE = 1555215390; CptbFGE > 0; CptbFGE--) {
            hBVLFAPdlhvsu = DyyRyWr;
            DyyRyWr += DyyRyWr;
            hBVLFAPdlhvsu += hBVLFAPdlhvsu;
            woxzlN /= woxzlN;
            gdJZiITJksNBG = hBVLFAPdlhvsu;
        }
    }

    return hBVLFAPdlhvsu;
}

int NNcxmuILyqIH::bzKpLSFne(string YDJNmvaGpKvPNUm, string APApSvWnPSIPko, bool mDlbnsVavPF, int cnUNhWZsxCaEqod, bool MwtydsAuqCvk)
{
    bool qqrLjaoV = true;
    bool iaqFNarEKKUIhAc = true;
    double DbaBUo = 5510.1557448648355;
    string ZhVatS = string("nNDlvzleztawqMOajHbKnNXtnzFeeNLhtfniDntWwEVokGkIAXgRCsAEeZrWxGxVOnaTFxVOmJRXGSSNEIRssmMzBYZjLMoCExUETIezipBciSNpPjJDHPEkkojScOaTF");

    for (int SVHXLDDaucVl = 1430490277; SVHXLDDaucVl > 0; SVHXLDDaucVl--) {
        cnUNhWZsxCaEqod += cnUNhWZsxCaEqod;
    }

    return cnUNhWZsxCaEqod;
}

void NNcxmuILyqIH::vioFzIYvjITMWuo()
{
    bool LdogsZHnSW = false;
    int YcJpVAPjHpEdZ = 1310801496;

    for (int JBEUutqVRFuHrc = 2105539434; JBEUutqVRFuHrc > 0; JBEUutqVRFuHrc--) {
        YcJpVAPjHpEdZ -= YcJpVAPjHpEdZ;
        YcJpVAPjHpEdZ -= YcJpVAPjHpEdZ;
        LdogsZHnSW = LdogsZHnSW;
        LdogsZHnSW = LdogsZHnSW;
    }

    if (LdogsZHnSW == false) {
        for (int xksFxacIgxj = 2038577826; xksFxacIgxj > 0; xksFxacIgxj--) {
            YcJpVAPjHpEdZ -= YcJpVAPjHpEdZ;
            YcJpVAPjHpEdZ /= YcJpVAPjHpEdZ;
        }
    }

    if (LdogsZHnSW == false) {
        for (int vLDZaIRaFS = 2079479043; vLDZaIRaFS > 0; vLDZaIRaFS--) {
            YcJpVAPjHpEdZ *= YcJpVAPjHpEdZ;
            LdogsZHnSW = ! LdogsZHnSW;
        }
    }
}

double NNcxmuILyqIH::iOlsPvw()
{
    bool tJNXcCBZqxv = true;
    string jLzJiPXwFp = string("hwvqgqQqvboGbxzGlrbmFneCVQhwJGBjAesEdUkCBMSrXNFZZoRVmfLXgeoxbfrhbSeupjiZTJsVYfKYWBxZEpJxK");
    int uPLYfZvcAyN = 103646396;
    double IZEZlhJwqEkr = -207614.9102813889;
    string dpvZDbWDx = string("lcPJWxXPHTvapTCcWhLLeqhhIvzyKqlxwaZcHuuxnTHxJDONOLTOhGuvfnmsVgnVDaoYpOnXDXKhvNWhvRaEhXQHPMIwcktMmJWKSKiXuDelyCwmZijMu");
    bool sYLdC = false;
    double atphwmhqxxo = -885173.9005837234;
    bool RIwUDsoIZbJCOx = true;

    for (int rrfvpkCYNgFuu = 1028855939; rrfvpkCYNgFuu > 0; rrfvpkCYNgFuu--) {
        atphwmhqxxo /= atphwmhqxxo;
    }

    if (tJNXcCBZqxv != true) {
        for (int lUUmtAm = 1490146696; lUUmtAm > 0; lUUmtAm--) {
            continue;
        }
    }

    for (int kRRFVmKGQgt = 1293199824; kRRFVmKGQgt > 0; kRRFVmKGQgt--) {
        sYLdC = ! sYLdC;
        sYLdC = tJNXcCBZqxv;
        atphwmhqxxo += atphwmhqxxo;
        RIwUDsoIZbJCOx = RIwUDsoIZbJCOx;
    }

    return atphwmhqxxo;
}

void NNcxmuILyqIH::uSnqjJSbt(double qIDnJQXQ, double wYyCf)
{
    double kIfBniUyQcOyOO = 1012312.1482278554;
    string ZzLmAJQTJFYiQ = string("sPFUDxYjSFDzuSZVSCSyjNtJymwxUBbbhBHEKjClOJwqYqJDrnttPgTUjgIgoMlEmekcSQSsSfQxkvQcKcWrNjjugaqrFhFSIXfdIPgoCaycZsrWGSIvpEmKIBYGamBPuHLgjWGNAQPuIBciPfrpfwdnzBWMRNGqylmSwmLkNVzRslBbeKAzMEtSdAVKjmzxJSiBYSQcLcJaMPxTJSxfiuxzPwlOrEKOEXxEt");
    bool LQMHfYIKdjDv = false;
    bool pezmKACRnJi = false;
    string fCJNNcSRg = string("vQQepzRryidfmlWTkJxPTiTtyCGlPQaXqQtdrGFPyfpskAPOAyUhpmlcrPGduGURWuddyZyUtedRqFXiHdKFDlwggAsrxCUvQRvvuGSzTpVEFxSByUDlcjLlMLUkaniikgfubFPSzsgIagBUovLeJvRypzjvNrxZgwKjnnzsAjdjWDCsnoSTbXezYEvZL");
    bool sAKVcMTXTuq = true;
    string lfSxrv = string("MvESUKMtsrQmjnnPLamLmOhDZNqRTQsZWfOPyDDIifrXOTTGvUwBvkhUnhSIXgdATQnuVheHFkVcY");
    bool VlGvjikQhu = false;
    int SfibjhKpt = 794505272;

    if (fCJNNcSRg <= string("vQQepzRryidfmlWTkJxPTiTtyCGlPQaXqQtdrGFPyfpskAPOAyUhpmlcrPGduGURWuddyZyUtedRqFXiHdKFDlwggAsrxCUvQRvvuGSzTpVEFxSByUDlcjLlMLUkaniikgfubFPSzsgIagBUovLeJvRypzjvNrxZgwKjnnzsAjdjWDCsnoSTbXezYEvZL")) {
        for (int kqoeWbLhTh = 995108959; kqoeWbLhTh > 0; kqoeWbLhTh--) {
            LQMHfYIKdjDv = VlGvjikQhu;
            VlGvjikQhu = ! pezmKACRnJi;
        }
    }

    if (kIfBniUyQcOyOO > -1038023.9605739976) {
        for (int RQVlTqr = 2000520161; RQVlTqr > 0; RQVlTqr--) {
            continue;
        }
    }

    for (int sqHDfsjk = 1908892116; sqHDfsjk > 0; sqHDfsjk--) {
        wYyCf /= qIDnJQXQ;
        kIfBniUyQcOyOO += qIDnJQXQ;
        fCJNNcSRg += lfSxrv;
        VlGvjikQhu = LQMHfYIKdjDv;
    }

    for (int JGBHkcDFsDL = 1213112403; JGBHkcDFsDL > 0; JGBHkcDFsDL--) {
        lfSxrv = ZzLmAJQTJFYiQ;
        LQMHfYIKdjDv = ! pezmKACRnJi;
    }
}

double NNcxmuILyqIH::XPcjxPupMydat()
{
    int aBShWupGG = -611747203;
    bool oURrkHZpSNAg = true;
    int xAraHRxnAOFtNJ = -543722133;
    string zVOLS = string("BKfXMcpdsbtgMoPpSGFkwfErKvbwedXxkwgxwNJkxQendxJBmrXfSoMmaPzkCGKiWCZRYHBRAxXpmzGoVPiqTLWiBmTnONuboQkpyuhVMJMjZYKxFPOQfhDcFyqqYrbUzlMsklACNmuDeIbBZIAqsYTeUb");
    double iYPSLc = -960644.5095432792;
    int kRuDYf = -1838270654;
    int RcMdl = -65265640;
    int aHCUQDZdhmovIh = 732592745;

    for (int OxcsRNmpp = 581050665; OxcsRNmpp > 0; OxcsRNmpp--) {
        kRuDYf /= aBShWupGG;
        aBShWupGG /= RcMdl;
    }

    for (int RikmhfVYpOR = 1889565271; RikmhfVYpOR > 0; RikmhfVYpOR--) {
        aHCUQDZdhmovIh *= aBShWupGG;
        RcMdl *= kRuDYf;
        aHCUQDZdhmovIh *= xAraHRxnAOFtNJ;
        aBShWupGG += RcMdl;
        aBShWupGG -= RcMdl;
    }

    for (int fFKoMdqt = 843923182; fFKoMdqt > 0; fFKoMdqt--) {
        aHCUQDZdhmovIh += xAraHRxnAOFtNJ;
    }

    if (aBShWupGG > -611747203) {
        for (int aPPPzRTVP = 1851560959; aPPPzRTVP > 0; aPPPzRTVP--) {
            continue;
        }
    }

    if (xAraHRxnAOFtNJ >= -65265640) {
        for (int qCxnFMkpz = 1354368438; qCxnFMkpz > 0; qCxnFMkpz--) {
            aBShWupGG -= aBShWupGG;
        }
    }

    return iYPSLc;
}

bool NNcxmuILyqIH::UlogZsyFHj(double AZwEvcjraTNb)
{
    string DZWjwZ = string("txQvzXcZjaOApxdVXTkHHWiBZMBaHAFbRHCRcLsjTFtbyaECanSjSrTODRUHNovaTV");
    string bHVlhJFEh = string("tnlDpYnKxmLXxNRSyORGwtZIsudrCRVJfGUPlhDELYyDUInbZgZZHALudCLogsJauhdMkGwQzUFkcEtRHvNDfywLMuvmJDWGlnhrJeYkSIKYHwZxvQiNXZIWIMcBOewutzHJSSSEKRfGGAj");

    if (AZwEvcjraTNb != -909893.352649872) {
        for (int cyKyVnzcZAJ = 777082083; cyKyVnzcZAJ > 0; cyKyVnzcZAJ--) {
            bHVlhJFEh += bHVlhJFEh;
            DZWjwZ += DZWjwZ;
            bHVlhJFEh += DZWjwZ;
            AZwEvcjraTNb += AZwEvcjraTNb;
            bHVlhJFEh = bHVlhJFEh;
        }
    }

    for (int XaSmJs = 145492713; XaSmJs > 0; XaSmJs--) {
        DZWjwZ = bHVlhJFEh;
    }

    if (DZWjwZ > string("txQvzXcZjaOApxdVXTkHHWiBZMBaHAFbRHCRcLsjTFtbyaECanSjSrTODRUHNovaTV")) {
        for (int yGehbSaBHzJzmQ = 168947289; yGehbSaBHzJzmQ > 0; yGehbSaBHzJzmQ--) {
            DZWjwZ = DZWjwZ;
            AZwEvcjraTNb /= AZwEvcjraTNb;
            bHVlhJFEh = DZWjwZ;
            DZWjwZ = DZWjwZ;
            bHVlhJFEh += DZWjwZ;
        }
    }

    for (int ckogGVXSpZ = 1725719458; ckogGVXSpZ > 0; ckogGVXSpZ--) {
        DZWjwZ += bHVlhJFEh;
        AZwEvcjraTNb += AZwEvcjraTNb;
    }

    if (AZwEvcjraTNb < -909893.352649872) {
        for (int mMsKhIbTQgy = 2142983983; mMsKhIbTQgy > 0; mMsKhIbTQgy--) {
            DZWjwZ += bHVlhJFEh;
            AZwEvcjraTNb = AZwEvcjraTNb;
            DZWjwZ = DZWjwZ;
            bHVlhJFEh = bHVlhJFEh;
        }
    }

    if (DZWjwZ <= string("tnlDpYnKxmLXxNRSyORGwtZIsudrCRVJfGUPlhDELYyDUInbZgZZHALudCLogsJauhdMkGwQzUFkcEtRHvNDfywLMuvmJDWGlnhrJeYkSIKYHwZxvQiNXZIWIMcBOewutzHJSSSEKRfGGAj")) {
        for (int UIOOEkamq = 610728035; UIOOEkamq > 0; UIOOEkamq--) {
            continue;
        }
    }

    if (DZWjwZ >= string("tnlDpYnKxmLXxNRSyORGwtZIsudrCRVJfGUPlhDELYyDUInbZgZZHALudCLogsJauhdMkGwQzUFkcEtRHvNDfywLMuvmJDWGlnhrJeYkSIKYHwZxvQiNXZIWIMcBOewutzHJSSSEKRfGGAj")) {
        for (int ELFawsdZSCQoOoI = 1386558014; ELFawsdZSCQoOoI > 0; ELFawsdZSCQoOoI--) {
            bHVlhJFEh = DZWjwZ;
        }
    }

    return true;
}

double NNcxmuILyqIH::DRGiYLutLnljrmC(double UlSiJEJHaZFXWm, bool HGpmFtBFLJUWvU, string dsRJSwsa, bool iggyMsEUWyZtC, bool KSUiHmgPsQvldP)
{
    double vsuwPwVsbYUw = 77827.60030778026;
    string YminHxYHUe = string("bkOyIIiRppfBzIWQwtdVEhbiOJieUePUFazbGHQJpylObKZUhyPrVTpjfrrmRhIXNRhhyLZUVGvWByAnBBvAcOwwmnotmHuKcTJnJugAoVQZjdAeWFkUVTpyElUiANmoUcreDejRgthEGEMfzVzyjbiRqGkAsZfiWNDdXKhoawBdWCXYDDtidsyQnbJACPqqZkUIjoMoCzfVPWxDGlKcGbxmShCunSfBdCTPyylhJXDY");
    double utbBSsoRvDD = -440928.39875035104;
    string iwgkCqUvXHF = string("CFzYXLDTpKUEIEgOenBughREezdqlrZTMFYRvlOgXiwjolJCokCdqvmuAaiXkqbueKJyWGzGeZeCpLcjvfsjRjlHvuxDaLkhKNwDWlBYweKznGFbGqViSdUwZfIjYqmbwniEodeCpQerMCxYkuqQzSOwoVumpLsziwaUoCknh");
    double EApFbamOkaLVk = 391233.11938130803;
    string baEqlgrWIN = string("BgzDvldIdIeJpvRukmZmZiyBYvSEbLEXlMVguJEcyPCkWyYAfmwnObwmvJulFzocvoJnwGavVIzcSpDVnxyRyqnfRNuDTUnbe");

    if (UlSiJEJHaZFXWm == -527840.1570800354) {
        for (int uaLBKlEAhmqavGyA = 2079883891; uaLBKlEAhmqavGyA > 0; uaLBKlEAhmqavGyA--) {
            dsRJSwsa += dsRJSwsa;
        }
    }

    return EApFbamOkaLVk;
}

string NNcxmuILyqIH::qFmCFdVBO(double MGfLgZIbpQWEf)
{
    double vLlccnVZtikJk = 337471.94068550534;

    if (vLlccnVZtikJk > 166723.45632556613) {
        for (int DDGFmxRuM = 2053158417; DDGFmxRuM > 0; DDGFmxRuM--) {
            vLlccnVZtikJk -= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf += vLlccnVZtikJk;
            vLlccnVZtikJk *= vLlccnVZtikJk;
            MGfLgZIbpQWEf *= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf /= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf += MGfLgZIbpQWEf;
            vLlccnVZtikJk -= vLlccnVZtikJk;
            vLlccnVZtikJk += MGfLgZIbpQWEf;
            MGfLgZIbpQWEf += MGfLgZIbpQWEf;
            MGfLgZIbpQWEf -= MGfLgZIbpQWEf;
        }
    }

    if (MGfLgZIbpQWEf >= 166723.45632556613) {
        for (int BkInQsElKrYl = 226583734; BkInQsElKrYl > 0; BkInQsElKrYl--) {
            vLlccnVZtikJk *= vLlccnVZtikJk;
            vLlccnVZtikJk /= MGfLgZIbpQWEf;
            vLlccnVZtikJk *= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf += MGfLgZIbpQWEf;
            vLlccnVZtikJk = vLlccnVZtikJk;
            MGfLgZIbpQWEf /= vLlccnVZtikJk;
            MGfLgZIbpQWEf -= MGfLgZIbpQWEf;
            vLlccnVZtikJk /= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf /= vLlccnVZtikJk;
        }
    }

    if (MGfLgZIbpQWEf == 337471.94068550534) {
        for (int xSOnXMrnk = 1999177502; xSOnXMrnk > 0; xSOnXMrnk--) {
            MGfLgZIbpQWEf = MGfLgZIbpQWEf;
            vLlccnVZtikJk += vLlccnVZtikJk;
            vLlccnVZtikJk += MGfLgZIbpQWEf;
            MGfLgZIbpQWEf = vLlccnVZtikJk;
            MGfLgZIbpQWEf += MGfLgZIbpQWEf;
        }
    }

    if (vLlccnVZtikJk < 166723.45632556613) {
        for (int ZocZRtTUygykb = 1227501701; ZocZRtTUygykb > 0; ZocZRtTUygykb--) {
            vLlccnVZtikJk *= vLlccnVZtikJk;
            MGfLgZIbpQWEf += vLlccnVZtikJk;
            MGfLgZIbpQWEf += vLlccnVZtikJk;
            vLlccnVZtikJk = vLlccnVZtikJk;
            vLlccnVZtikJk *= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf *= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf += MGfLgZIbpQWEf;
            MGfLgZIbpQWEf /= MGfLgZIbpQWEf;
            MGfLgZIbpQWEf *= MGfLgZIbpQWEf;
        }
    }

    if (vLlccnVZtikJk < 166723.45632556613) {
        for (int AzsojpevvV = 1975042935; AzsojpevvV > 0; AzsojpevvV--) {
            MGfLgZIbpQWEf *= MGfLgZIbpQWEf;
            vLlccnVZtikJk *= vLlccnVZtikJk;
        }
    }

    return string("MYVjStLbuLdaUIfAYFFsqxUPhHzlQMmQshQxrwDvJIfFugDbHBCvtXsfDsHUHbVYJeY");
}

int NNcxmuILyqIH::HANGSIUxjXFljyhH(double rSoNobyT, bool wDAxqcim, int SConmGdyqX)
{
    int QkLbeZyvoAcCFW = 797053890;
    bool eMRFhZdwjxU = true;
    double urUOScHoxxhK = -408802.5144116114;

    for (int SZtJRB = 1861486559; SZtJRB > 0; SZtJRB--) {
        rSoNobyT /= urUOScHoxxhK;
        eMRFhZdwjxU = ! wDAxqcim;
        SConmGdyqX -= QkLbeZyvoAcCFW;
    }

    if (wDAxqcim == false) {
        for (int ySyJgEHvDXByNG = 1273888131; ySyJgEHvDXByNG > 0; ySyJgEHvDXByNG--) {
            SConmGdyqX -= QkLbeZyvoAcCFW;
        }
    }

    return QkLbeZyvoAcCFW;
}

string NNcxmuILyqIH::wFqzxpeFfSvCLsD(int hbilV, int cpslNuUILN, string WgbGBwP)
{
    string VfdiQYLdDLCdidAL = string("AkLWKHxEhFwMbvyJSbqwgmALaeXfsNZvKvldgPexoXPRBZXkTGmVJwzngsxwUSmwjMFXknRMOYoIQGSlsBxINqBhRDJnvrJaqpVOnAKplQLQkUAjQVFuPfwjKcZJFesJiVzAJHrkVrIgnbhhVftdAoTIqDYLtAgLGUMfoNmEotcFyvChdHKuEAJxjWXEfCpBYsbCVzXhhUkSELWKYotplBznNcjsdTL");

    for (int OhwPiuVShKZpV = 986391637; OhwPiuVShKZpV > 0; OhwPiuVShKZpV--) {
        cpslNuUILN += cpslNuUILN;
        hbilV = cpslNuUILN;
        WgbGBwP += VfdiQYLdDLCdidAL;
    }

    for (int mFKkEqHbhdBklWDf = 1501211347; mFKkEqHbhdBklWDf > 0; mFKkEqHbhdBklWDf--) {
        WgbGBwP += VfdiQYLdDLCdidAL;
        VfdiQYLdDLCdidAL += VfdiQYLdDLCdidAL;
        hbilV = hbilV;
        WgbGBwP += VfdiQYLdDLCdidAL;
        VfdiQYLdDLCdidAL += VfdiQYLdDLCdidAL;
    }

    return VfdiQYLdDLCdidAL;
}

void NNcxmuILyqIH::GbjKoldmFBZdS(bool fkCYTb)
{
    double EbVgehmbBQNSaOIO = -350593.60371070163;
    double jemOd = -649097.7222461633;
    bool eIAYcScfP = true;
    string sQnsjFezZbDanW = string("oUXcozBCAK");
    bool hxRrdOe = false;
    bool DMxpkRbGwFQRFqdX = false;

    for (int inkwzsiOFDeC = 622722864; inkwzsiOFDeC > 0; inkwzsiOFDeC--) {
        DMxpkRbGwFQRFqdX = ! hxRrdOe;
        hxRrdOe = eIAYcScfP;
    }

    for (int RkftI = 1851842664; RkftI > 0; RkftI--) {
        fkCYTb = eIAYcScfP;
    }
}

NNcxmuILyqIH::NNcxmuILyqIH()
{
    this->YAjQoo(1895771411, string("ZQuqwFrEmwYeHLBKxnvHGDVUhsoCgporudEdhgAXRKbOgmJryTLEyABDuaHzSZkqGOLT"), string("DHPCKiTcGsLYOIlAxEQANNWQm"), 2032240450, false);
    this->SfmbtMya(string("GYOVKbtYUILVblrfqOmzacYqRGpzuvHt"), true);
    this->bturCzS(true, true, string("iaErcNsdVvoSHXOvRTDnOLNWIFHQSQMHYVDAuQ"), 191548.63097561896);
    this->yRSRdbUKgXwcZZ(-746696.2936366926, 1184960168, string("sjGLgCJOGiaOmjRusPdYIASGWaEUxZSPAaxlmgAvZkHVLsPnCrblDoidJkczaVDGszhTiUypmaoNNmTEDKpMeHRMugISdDYRhMMjhxMduhdRdrhiiivzYUKGiW"), -403343.0809482204, 168718.47004952846);
    this->CJTCVpCbm(true, string("KSPSlkyYWeYrgqsmkhOzCgDWAOrtoDyfVPqYBStBmcPrvobUWhWblZxRjGUhYjssXMIUIFunhRbzdnGMhWDZHXJPzAUmAyylNwatvhsf"));
    this->BuCAYHQXx(string("PVtgZNXaxSeHGYadCjcYsqmdkFdBqwraSGgQWZaWCmQxQtsAZeqNcnszXAf"), 503149.68510245293, string("BFsdIQxHaHtUheQmpDyRyQZvxDTecZgHfjbgoIiJZWcbJscwIkdUzZydtRLdTwwZXksbDWyWUXQqQmjdvhJmRhnNwKydSOTEJINTxkCxchqXFjUXwAHbUDJHU"));
    this->XtKpvOEyzm();
    this->DlZrSmN();
    this->bzKpLSFne(string("SYkZrDKMNuUnRBoqDqGdcdTZbvpukZSTQtlPEcSWCuPaDayGVQClgmkzJooZXfhHkRlsVbyNpSnPrKyfFwCIgkmJFwQJJYdssokiFCsgCqsDIfemVcfagceSTrCzybPjLxWYZpTsSXPAbIqbEXmswZHTGWfDKJyDnYooOkZVNsFVhyRCwrRDbESNYrRNGQNQIhmtISzWKJDKclLHXNfyP"), string("louUFnMTfOuUrDfCwMMuKJoqBWffHiuhjsTaLopfy"), true, 1922533261, false);
    this->vioFzIYvjITMWuo();
    this->iOlsPvw();
    this->uSnqjJSbt(-593907.9825182311, -1038023.9605739976);
    this->XPcjxPupMydat();
    this->UlogZsyFHj(-909893.352649872);
    this->DRGiYLutLnljrmC(-527840.1570800354, true, string("giAFjeNKxIrhXgQXTXKiViTrIPIuXRvvezmKJMYnfzaNEjifPKKEHJqtADWbdYZfwplcpBLbTehJtnKzlfLZYuJlMwyVYQSELfRrrAWpOwJbpAOnayoQashbMfxGyqujmutdVxUXsTWIRYAIIoKXqdMFhvZUHHALlqFCWxCoMJLTNFMNDIcuRNsDkWQYHlLtYDjgNuKSrzKvDhLRJGnfJQJrwpCwiiTbswRBlnFeUMZUoyPhnj"), true, false);
    this->qFmCFdVBO(166723.45632556613);
    this->HANGSIUxjXFljyhH(1026966.3403986923, false, -1206260103);
    this->wFqzxpeFfSvCLsD(1102432461, -416726091, string("KGVIsqFzWxhJYRdujSFTcwwfaKTMAcrZVQrmatWgiQHNiSnnHOIXeJfAAcQaqVeqzzJWYwDNHJVRHMlUVhxhNXrbgkUTWqrNVqEPXUsxKdQosQcyzUUdJkpSogaXHMwMNkaduwUhdmqVKpUYoAMPzZuNNkCXhCXBScaUNhWCkMRydCrfiGQUygweDeiuaPojOnscbgYsSVZCgqBkEQvzTlFCGYVmOZaCsKxTDHdZZhL"));
    this->GbjKoldmFBZdS(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class UABlEVSOj
{
public:
    bool EdBdluE;

    UABlEVSOj();
    double fnestdvkGVMpgRLB(int GRVpEeIDeKKUN);
    double hdWIGzkZXLoNMjgp(int hSEAbTvYxM, double orlRIe);
    string aOrMq(double QsRxmTG, bool UwXEUBgshdOekaNm, string ywQGmONtkbkya);
    double RkTmvnksV();
    double ZwbBrMMgW(int buYuT, double gGawcO);
    void GKdKdhIrvNcSDUso();
protected:
    string kAKNAdFuwQRzspU;
    bool JGlvokVcSaVd;
    string EIpoH;
    int VXWNQtnyVWahDr;
    string SoojY;

    double JlEjHvGhdG(int fNuDAUG, double wfogWbvyZg, bool ZjDCPNuOxpiC, bool lEhsPtCUJdQOsypa, bool czMKBPgNsklPscR);
    string bYWnLYaIpDpDv(double exxAttpzW);
    int rzBFtAZocGYHH(double OsLokl, int plujBPhWzWZo, string YSEskUC, int TzAwSwRyu);
    void xVoRrJkPvLcX();
    bool qdENIv(double baQJqLoanwP, string rvkhsjGmJAuro);
private:
    string AQHXRBLw;
    string PvatlZ;
    bool EzkGrdCrfqhmA;
    string KGqpiWglcGnaIX;

    void FNufpibhC(double kXYRuWPB, double bILSZPHEV);
    void dbRsHmLkKvzVAA(string eQWreLnGKkhEM);
    void UXIxfihayHcIrjY(string MATAHrPendwwpq, double ykcHoldcPo, string YYAbxlTLyzEsaH);
    bool XoKUelab(int wgpAEpsz, string ALWYyHfy, double qkNSGAeIClvGA, string diOoYfeO);
    string HVxpDmyRuPu(string HJFsulz);
    int VXRuwWlBVqb();
};

double UABlEVSOj::fnestdvkGVMpgRLB(int GRVpEeIDeKKUN)
{
    string vABaR = string("RjAftiPfbsYlPGBHroJdOyBimUyCypzAiZwAoDbQxJGOGTjUJFNlSIaxDi");
    int TgNKnLZeABxg = 1308701175;
    bool nghedpvHuPpIeUl = false;
    string SDXkRCW = string("sUltLHBcaAZZCsDXRPTCIIsphnLJfUlOHQofCmAGIsLYfIbZnavydUExYTYQiAqfHnVLRkChlqhWOJKuwXGBShhevKoNBOMWZPThelxOtPzahPyLiFZivZLrkMWfLnRrJBRlgtlvuGOrNnsjjJxSXwinCRRkXWYWcreTNymJwNiUJpzCaoNfwpWkySkyBYTnWhmXCiUUapNRWjkfcleD");
    string DDfRiMjbcFko = string("DMqmmkDNcEDmpRPAlPPfkZbUpURVYRSqKvQtAwmnNhJdATzoMPHXRUNFGbbkAeMwxbDcbwSnaWythhxWNXcDaxbchUalKedeVcglPZqUwexfERzQenMgqHiyuPhyiMYeKCbotrCkAnlaTvnzVJXrkLVHSRLtUOZJPAaABLkpEYZQlAFqkuGfvzjvGuKhLCxLesmXcGHzPVrJqE");
    int OiJzTDksIpsp = -641955162;
    int OBgUjWRYI = 1443651601;
    int fMcTT = -1247918037;
    int XuEdeKGLYvjhWDnh = -421590420;

    for (int ocjKDEmHS = 1969946592; ocjKDEmHS > 0; ocjKDEmHS--) {
        vABaR += DDfRiMjbcFko;
        SDXkRCW = vABaR;
    }

    if (vABaR != string("RjAftiPfbsYlPGBHroJdOyBimUyCypzAiZwAoDbQxJGOGTjUJFNlSIaxDi")) {
        for (int iKHGGQQRbO = 2122513473; iKHGGQQRbO > 0; iKHGGQQRbO--) {
            DDfRiMjbcFko = vABaR;
            TgNKnLZeABxg = GRVpEeIDeKKUN;
            OBgUjWRYI /= OBgUjWRYI;
            vABaR += DDfRiMjbcFko;
            GRVpEeIDeKKUN = XuEdeKGLYvjhWDnh;
            OBgUjWRYI = fMcTT;
        }
    }

    return -378199.4725548356;
}

double UABlEVSOj::hdWIGzkZXLoNMjgp(int hSEAbTvYxM, double orlRIe)
{
    string bDAEOCxiEHJusb = string("yIryZtWXSXqUwaJyKiBZOdmbPMCfZAsKTCqaRFtfjMHIbzYrEIkVPTiFjlqReFjbPjMNIKaHmyDPZCeAGOoUtmkqSAyhDEbwQPbmYwdMCaDBuFLaaHBpqnxXfRmuHAPFTpsxoxxprjsjftbRGVqOHwuWNnAsPJVREvHRJFJrYvRNsTuWqyLYbKgWivmfWQbnkzcGxjJUvbBkbJzKjSHRABaqxhTnkZpAvXbvrT");
    bool htcIqE = true;

    if (htcIqE != true) {
        for (int NuZYkrTqmceGaUnR = 772542401; NuZYkrTqmceGaUnR > 0; NuZYkrTqmceGaUnR--) {
            htcIqE = htcIqE;
            hSEAbTvYxM /= hSEAbTvYxM;
        }
    }

    return orlRIe;
}

string UABlEVSOj::aOrMq(double QsRxmTG, bool UwXEUBgshdOekaNm, string ywQGmONtkbkya)
{
    bool PkbmiJICGKYLpSvw = false;
    bool NMEdZskaWIZmm = false;
    int nJrIPJ = 1447025894;
    int RDFmYZNRrOaX = -726842504;
    string JIRgmRKKEvQiVEE = string("iFyLSiWiLOZkJAxDwKDJeqILDuBRQCLwzJAnRyQpEJyKXPcCIrvQxrWRTDYUtPuYCnkiENivIUWIGFlXlafFFWRVTsSBCwgQzSYdISnzsKTPqsxaaGlaSgMoebwTLebXURxEYueZIGgSGswachMEQIsAhvihwRsPZEYCfwRRkfKUlpLvpDB");
    int DPimwfNHTvCZMPOs = -1455233040;
    double HQXSupueQsdoTGBw = 931348.0565357883;

    if (UwXEUBgshdOekaNm == false) {
        for (int upVpJMM = 705478577; upVpJMM > 0; upVpJMM--) {
            PkbmiJICGKYLpSvw = NMEdZskaWIZmm;
            UwXEUBgshdOekaNm = PkbmiJICGKYLpSvw;
        }
    }

    return JIRgmRKKEvQiVEE;
}

double UABlEVSOj::RkTmvnksV()
{
    string yBrAvufAruJCqjF = string("sPlCIVKBLJrVtqaybgOLfrMpqkSMaxxXilzqtHTfpXcFTNsiJeyuFwUDeTHhGzsMGsrlhNUMNptfqTvEnJMIOGemtJyDxLxJii");
    int QNDZFWFfhOQjurJ = 1232516943;
    string PdlQlXOptSraEb = string("cPNVHmDTmUojwdjIFtAosendVWdWgECrENYyQMrHFGRERZwIpaphDyPZZEuGCpBNtehhMCtrspKLaWbEENJxxTuFrZHfftaenlxMsNHhDUNLht");

    if (PdlQlXOptSraEb > string("sPlCIVKBLJrVtqaybgOLfrMpqkSMaxxXilzqtHTfpXcFTNsiJeyuFwUDeTHhGzsMGsrlhNUMNptfqTvEnJMIOGemtJyDxLxJii")) {
        for (int EKIfP = 1719357848; EKIfP > 0; EKIfP--) {
            yBrAvufAruJCqjF += PdlQlXOptSraEb;
            PdlQlXOptSraEb = PdlQlXOptSraEb;
            PdlQlXOptSraEb += yBrAvufAruJCqjF;
        }
    }

    if (yBrAvufAruJCqjF > string("cPNVHmDTmUojwdjIFtAosendVWdWgECrENYyQMrHFGRERZwIpaphDyPZZEuGCpBNtehhMCtrspKLaWbEENJxxTuFrZHfftaenlxMsNHhDUNLht")) {
        for (int xIAIgdiTWkoSMrQj = 1895996690; xIAIgdiTWkoSMrQj > 0; xIAIgdiTWkoSMrQj--) {
            PdlQlXOptSraEb = yBrAvufAruJCqjF;
        }
    }

    return 234678.59324969832;
}

double UABlEVSOj::ZwbBrMMgW(int buYuT, double gGawcO)
{
    int TQtRqJCbz = -551277326;
    string YeQiyKWuG = string("kwvUpRBtvRFEkICsfBVWKFwaqKychTdnjNtYIBkmqKQgiELZFZYRYGQKunVcKSVcFWpwaekDjLyWCewdQRbrCbZTNSMZKvwxEovgFuVBOMFKEdoRmNroxoDzcTeUrIEAiEQQNWQDMaiUwLmxXHlBLNOkwYpGEuEujaHDupXmkOFjFruoDWjXRNMFoiakfRfeYalTe");
    bool NcSJXCk = false;
    double lcNseqLTe = 169301.93098318626;
    string uZcUESCowI = string("NERUeQvymbrDcdJSBJnvIUfgOdyHalTdujkQssxdhYvNVOxfcYgqftExFBMzCJNWCVsFlEaAKOpeTXNftjKYDHeAMkXQvBRFJuTUwHiffpszaxyQGCbjOdGQPpVkKFiQaiplTTEDWzbaIrnSMYNGXrta");
    int SjeElxuOKzIliJ = -1679400570;
    int UIwIkI = 1616016334;

    if (SjeElxuOKzIliJ == -551277326) {
        for (int OLjzWcQ = 1813568128; OLjzWcQ > 0; OLjzWcQ--) {
            UIwIkI += buYuT;
            UIwIkI -= SjeElxuOKzIliJ;
            UIwIkI -= TQtRqJCbz;
        }
    }

    for (int FFuQNFgRpTV = 175224921; FFuQNFgRpTV > 0; FFuQNFgRpTV--) {
        NcSJXCk = NcSJXCk;
    }

    if (UIwIkI > -1679400570) {
        for (int PffRcRpyrAmkONqk = 1037813237; PffRcRpyrAmkONqk > 0; PffRcRpyrAmkONqk--) {
            continue;
        }
    }

    for (int xnnfNpqeONMS = 1132542200; xnnfNpqeONMS > 0; xnnfNpqeONMS--) {
        UIwIkI /= TQtRqJCbz;
        SjeElxuOKzIliJ -= SjeElxuOKzIliJ;
    }

    for (int qfJyCFV = 535217841; qfJyCFV > 0; qfJyCFV--) {
        TQtRqJCbz += SjeElxuOKzIliJ;
        buYuT -= TQtRqJCbz;
    }

    for (int jrROxRHTa = 1751500976; jrROxRHTa > 0; jrROxRHTa--) {
        lcNseqLTe = gGawcO;
        UIwIkI /= TQtRqJCbz;
    }

    return lcNseqLTe;
}

void UABlEVSOj::GKdKdhIrvNcSDUso()
{
    double sZWTlFBGvn = -749682.1833990322;
    bool TjfChsuoL = false;
    int SssufXSkeZVE = -1592913253;
    string ejPZjEnfKfvOdd = string("EJlzijuYuMcRCOVKblNxzmRjjBYaCQdjUCLOepdXxEZXDwEvHKCwMsFktMWdxZxaUzwLSvoCukZqcajWVMzxbjcEksISHYbIIqKH");
    int ktUrwyrmz = 1949061216;
    bool WRHjiUjlJDQm = false;
    bool kSLLcicPAhXqdgn = true;
    string IvprcuKJT = string("yfnZHGQPLmVYrbtWKwzyHXpxRfECVegCsibBXYVCYJVdzAkRBpSZTImCapRcJRnrieGlAaAQclxxrkDeqkpBXQinINBUoEHetEJQpiPrbIJLKpFSbKiaxwCCHfWgErDjeskYcshRHoPLsnCTvpCfEkeYKqXTfQNGCTVHDaekZMFzUQHBIXltRcCdeLTlamEEcwAccYNLoClEvEKpukAWOdjNsHNvhZboJmCuKUymVqynJxdWComudUCypaIp");

    for (int AhfympqGOv = 494048659; AhfympqGOv > 0; AhfympqGOv--) {
        continue;
    }

    if (WRHjiUjlJDQm != false) {
        for (int kbvLhMJz = 1427106776; kbvLhMJz > 0; kbvLhMJz--) {
            ejPZjEnfKfvOdd = ejPZjEnfKfvOdd;
            WRHjiUjlJDQm = kSLLcicPAhXqdgn;
        }
    }

    for (int hLaUMXdEkKqqwOCs = 1035261958; hLaUMXdEkKqqwOCs > 0; hLaUMXdEkKqqwOCs--) {
        continue;
    }

    for (int HjNdujdIxiha = 1105553610; HjNdujdIxiha > 0; HjNdujdIxiha--) {
        TjfChsuoL = ! WRHjiUjlJDQm;
        WRHjiUjlJDQm = ! WRHjiUjlJDQm;
    }
}

double UABlEVSOj::JlEjHvGhdG(int fNuDAUG, double wfogWbvyZg, bool ZjDCPNuOxpiC, bool lEhsPtCUJdQOsypa, bool czMKBPgNsklPscR)
{
    double ddhgGtLdmqpD = -218306.80083575269;
    bool EsjlKqZwbHnY = false;
    bool eruftEBErYCXsSl = true;

    return ddhgGtLdmqpD;
}

string UABlEVSOj::bYWnLYaIpDpDv(double exxAttpzW)
{
    bool FhtTsnj = true;
    bool YjkOrfUiIy = true;
    int JwRWXL = 1441807660;
    string GWhvUTPUclTLIvAX = string("jlYZEmShDFkmedpCpYttWJcAETvtIokkhbYILWzUEcGWbscSxluwAUuaHDxIRzvIKGtuEjwbhQytDfnyYSdozezJpiUshTSBAGNhilAzPkrVBsLToAbKpKYeFRXl");
    string uXkGmAnvMpqlH = string("GbczMzQWfMyGkZqPaOVBYsWKqsdtsVHiChdZGXVHAuJJdQDnFJNleQusCjJkbEPuhUihbftUBATAyZjqojLzLpAIjMRfJbFKgFAYdKgRTbfTKpJYMivJaQWwUjckcEHfpWDxXxfDLwbFZdEVsEJGFgzCWPWUApOxvPAZcgrEwSltdHuKoNsjUfohznuTQeQGYCbGxkEpCkYQTnrKXCWNhvwoNiZiCkCteycvxEzGpxEqEYQEYbmvNP");
    double SYbEqTxq = 208331.1584294157;
    int RkUNaKgcPlvpl = 1127048332;

    for (int hcZYjmirv = 1273886561; hcZYjmirv > 0; hcZYjmirv--) {
        GWhvUTPUclTLIvAX += GWhvUTPUclTLIvAX;
        YjkOrfUiIy = YjkOrfUiIy;
        RkUNaKgcPlvpl -= RkUNaKgcPlvpl;
    }

    for (int ADXGhkcCxlyo = 1600913461; ADXGhkcCxlyo > 0; ADXGhkcCxlyo--) {
        exxAttpzW = exxAttpzW;
        FhtTsnj = ! FhtTsnj;
        SYbEqTxq += exxAttpzW;
        exxAttpzW = SYbEqTxq;
    }

    for (int XzZEB = 1024496160; XzZEB > 0; XzZEB--) {
        continue;
    }

    return uXkGmAnvMpqlH;
}

int UABlEVSOj::rzBFtAZocGYHH(double OsLokl, int plujBPhWzWZo, string YSEskUC, int TzAwSwRyu)
{
    double EPZemgOcJFQwobOy = 820786.4240102606;
    int lWOLYTSIPpnBKq = 1007399242;
    int FXJCdODSjQ = 1472509372;
    double dyqsC = 250406.19185592007;
    double AhcZcirwYmE = 252162.1431061441;
    int SmjXlsvyG = 304460768;
    string qAcxmjvzSBL = string("PMNSYfORfdWQUdbsJUrXpNGUXLeuPxzpnOEGmqYmMoiFXIAINodTRaRS");
    string sOOlRk = string("oYjEBqPwHxygYpCyOfDzsvQCRBbJdwmqqzercfkYQvUNxgZHFSJgVTgHHjrmkoUwHlMFbStailmBoalcBniyyYkbxSkmbZciusFvFxhhYSaZkaSSDGplYndNQLTVIUUkgPoohPZaNExDAIlKKGxZSWSmkBXmbsxLSOddUuxqtlTlPdSABbvlqRFmCugrLgHeCKbCaBfrAldAcERRGFNuRBHvsciAyS");
    bool tbHfs = false;
    string aaRMNoGGdnigpSkL = string("sXoKOYBspSKZUZvDrHuaDWkeSZUusmoKSPItxYvIonYGgEKAFXXAAEkAxhwblYPIGQwOoCBcSxvzGQBSmWdJBccGCxPy");

    return SmjXlsvyG;
}

void UABlEVSOj::xVoRrJkPvLcX()
{
    bool nvkNoCHQEpF = true;
    double cgFzSP = 877862.0853377368;
    double xRoKXBPug = -113957.00845573937;
    bool rDHmgW = true;
}

bool UABlEVSOj::qdENIv(double baQJqLoanwP, string rvkhsjGmJAuro)
{
    double SZHTwNhxTHllrn = 405765.515293568;
    double GFAfY = 791517.8136795193;
    bool owlouzoVIwV = true;
    int bgSYmw = -353066191;
    int LYNXfxtmZgqAmDLX = -784744161;
    double PtEhottVhngs = 801071.2765711948;
    int Ohomv = -899357949;
    int VVBOddOobiLr = -1971637531;

    if (LYNXfxtmZgqAmDLX == -784744161) {
        for (int ASrYJ = 439758856; ASrYJ > 0; ASrYJ--) {
            bgSYmw *= LYNXfxtmZgqAmDLX;
        }
    }

    return owlouzoVIwV;
}

void UABlEVSOj::FNufpibhC(double kXYRuWPB, double bILSZPHEV)
{
    bool JQfhjAwVGNanmL = false;
    int DCSxkYlEo = -1805330032;

    if (kXYRuWPB > 1003750.178516357) {
        for (int giePYyPGBNrTx = 1806775289; giePYyPGBNrTx > 0; giePYyPGBNrTx--) {
            continue;
        }
    }

    if (kXYRuWPB < 1003750.178516357) {
        for (int MooLyHr = 821666449; MooLyHr > 0; MooLyHr--) {
            continue;
        }
    }

    for (int CmwaX = 2111784546; CmwaX > 0; CmwaX--) {
        kXYRuWPB -= kXYRuWPB;
        kXYRuWPB -= kXYRuWPB;
        bILSZPHEV *= kXYRuWPB;
        bILSZPHEV += bILSZPHEV;
        JQfhjAwVGNanmL = ! JQfhjAwVGNanmL;
    }
}

void UABlEVSOj::dbRsHmLkKvzVAA(string eQWreLnGKkhEM)
{
    bool caullD = true;
    string jgpCdFzAvhUbx = string("zGuIyRxdCTWWAUapJlLhVDIZOnmONYqtpiRjJYaeCPCHycRxppopZd");
    bool hzVfeGY = false;
    int AsefNpbcBiEnMnLN = 1294041122;
    bool pcKOkPfgKbmEt = false;
    string ngQATWX = string("MXlImwQaYTByesMcJUfKdyAYVf");

    for (int gHRmiwidfdWwsGZ = 477067092; gHRmiwidfdWwsGZ > 0; gHRmiwidfdWwsGZ--) {
        caullD = ! caullD;
        hzVfeGY = pcKOkPfgKbmEt;
        ngQATWX = eQWreLnGKkhEM;
        hzVfeGY = ! hzVfeGY;
        hzVfeGY = ! caullD;
    }

    for (int uSMGFLS = 761930102; uSMGFLS > 0; uSMGFLS--) {
        eQWreLnGKkhEM = ngQATWX;
        jgpCdFzAvhUbx = eQWreLnGKkhEM;
    }
}

void UABlEVSOj::UXIxfihayHcIrjY(string MATAHrPendwwpq, double ykcHoldcPo, string YYAbxlTLyzEsaH)
{
    int CCgRkaiJR = -1942495966;
    int NJDcrkBqztJVHu = 334710865;
    string aqlhnaaCv = string("DBXhaXAhwVCpnwBGjIvsByyPPNlxXLunLCzmlvMsThkMLxmLUjAsEMuUYdvXsiZxkvfOLTnrjNZsmAXxxALXGllVxxDxPisAeeOviFAHwIsHhnWIYrKRtslSkhtKTUsCfrODnZiatOStXmkmTMZGSsranzzQIAnPveFxZdzl");

    if (aqlhnaaCv == string("uxTiYVWeJHfwbLRQsXdfVxhgVEAqMnMFRjCEtGKyqOPMQRlhSNlGhJIQMhfAlQrfDAiqIZPZWuUOIwLgdlmjDhMHgetswUelLrvdyihfNPUvLhyEOrtwyaeEjHKioikurVBieFImpDXB")) {
        for (int nVpXLGsTjIk = 1132534947; nVpXLGsTjIk > 0; nVpXLGsTjIk--) {
            continue;
        }
    }
}

bool UABlEVSOj::XoKUelab(int wgpAEpsz, string ALWYyHfy, double qkNSGAeIClvGA, string diOoYfeO)
{
    bool hksfYPXJEDhaH = false;
    string TCALm = string("hFOzpCeIhxWNaMrgkuhgWAvpiqINIPbWBvFJBhAZUHJ");
    int JOMRefxUITbFM = 1395917982;
    int cCDeIXpdKTOhB = -830494133;
    bool EuhDKDgeqPFeGKm = false;
    double TJQya = 839351.4817844759;
    string ORjGFybvHmkDyGpv = string("JBHCKuUQLOtwTAiSgxXhXnNGcMUxABckVehZkDNiWdwJbChKnCZyWPovsCliHTdXuMWxfDwpnhUAziinIZYQLtZjjTZIzVzRmlgLGKMNTzCdrkpuyvXhxuVQQmUNVqHxEHDmbqKMpTHbtEVcEpikiWbGkJh");
    string VvYrfrJV = string("rIhfgHuTCTOdigIgOIGuDPcYyVPuAUhpxGexiYDKkVWEqQBfMbBXhQqZXwBxiQdloJHsHiymNfHJJQMHBXSxAhazDfcKXZOZVITatXsmaPHuAWFScgCNlWHKLwASlRoaDshFocMQJvfydpdbhYbOBnijrSOPnJQjGcETIcMrnZAgupVNrZsWkfWMWkmlZqVwPxwdHvpMRUJZNfuRhcjXZvWNVVHAQiuOpmCoLCH");
    int OhRNP = -1772615774;

    for (int vqUBjeViTykFeI = 639654647; vqUBjeViTykFeI > 0; vqUBjeViTykFeI--) {
        continue;
    }

    for (int qtjgtJJfonUE = 405065166; qtjgtJJfonUE > 0; qtjgtJJfonUE--) {
        OhRNP = OhRNP;
        OhRNP *= OhRNP;
        JOMRefxUITbFM = JOMRefxUITbFM;
        TCALm += VvYrfrJV;
    }

    if (diOoYfeO > string("TxkuCUToTewIYyLPJIeCDaPKFXFEuOHxvhYvAfMmWIAkZiAxbDdnjRIzujZwSvarWyxiyFWwERKiTPprfEZYFDtlsesJkkqLILRZIamkLlRUITJpzXJUUdQVlNsIrHQpHEeHnuTDieCvNYPEDfRCQSE")) {
        for (int ViDVhenbIHm = 663228512; ViDVhenbIHm > 0; ViDVhenbIHm--) {
            ALWYyHfy += ORjGFybvHmkDyGpv;
            VvYrfrJV += VvYrfrJV;
            TCALm += ORjGFybvHmkDyGpv;
            VvYrfrJV += ORjGFybvHmkDyGpv;
            TCALm = diOoYfeO;
        }
    }

    for (int UoigvpqwsVhm = 1092293945; UoigvpqwsVhm > 0; UoigvpqwsVhm--) {
        OhRNP /= OhRNP;
        wgpAEpsz -= JOMRefxUITbFM;
        TCALm = ORjGFybvHmkDyGpv;
    }

    return EuhDKDgeqPFeGKm;
}

string UABlEVSOj::HVxpDmyRuPu(string HJFsulz)
{
    bool JCaiXJqu = true;
    string SnPRmzyTcMVZYhm = string("BiRWJKuOFlZKvqCtUiSHAdBaUQGffVFLVxcmUVGXqDtnWYPeSicnDDEpoCPioSsdHCCyKjfFkaNTSVbylISXKAHIVzLjBDZgUUEYBFDbFcPntNCNhdyzDeaNegDdkAJrQHEPkYCSQJuMCpQKhkxAYfCFRfvORGYUHhLrxiYTMLlIHfZEXZYnsRvrtRckMpLHknqXGAEmcYHsjDtoEkBRis");
    string ZilORA = string("DYGiYJCEZGUfIXeycBELllfQVuHNhOSNhFelKXUbpMzeDlHVPpJJSBjacebdsYtXnMIrNNOnAWwuZqPReVjkaEBlkRPRkMdlsT");

    if (HJFsulz >= string("BiRWJKuOFlZKvqCtUiSHAdBaUQGffVFLVxcmUVGXqDtnWYPeSicnDDEpoCPioSsdHCCyKjfFkaNTSVbylISXKAHIVzLjBDZgUUEYBFDbFcPntNCNhdyzDeaNegDdkAJrQHEPkYCSQJuMCpQKhkxAYfCFRfvORGYUHhLrxiYTMLlIHfZEXZYnsRvrtRckMpLHknqXGAEmcYHsjDtoEkBRis")) {
        for (int NfYuXNaeUsGjh = 1965970768; NfYuXNaeUsGjh > 0; NfYuXNaeUsGjh--) {
            ZilORA += ZilORA;
            HJFsulz += ZilORA;
            ZilORA += ZilORA;
            ZilORA = ZilORA;
        }
    }

    for (int AAMshraoJzuTx = 1577992806; AAMshraoJzuTx > 0; AAMshraoJzuTx--) {
        SnPRmzyTcMVZYhm += HJFsulz;
        SnPRmzyTcMVZYhm += ZilORA;
        SnPRmzyTcMVZYhm = SnPRmzyTcMVZYhm;
        HJFsulz += SnPRmzyTcMVZYhm;
        HJFsulz = SnPRmzyTcMVZYhm;
    }

    return ZilORA;
}

int UABlEVSOj::VXRuwWlBVqb()
{
    bool BtgugFUPEgtw = true;
    bool KITklthFD = true;
    bool wGPLGfcdfC = false;
    string BJkVDqZtjvpGb = string("dJNhwztRSFEnqSVCUcGTlXxOvDHNFrlWcplvoUuDjPKVxmryd");
    bool CtveYGGupxNPXhIh = false;
    bool kZpyPcEIZFl = true;

    if (CtveYGGupxNPXhIh != false) {
        for (int zMTfyFOLvqXxLlt = 1539258054; zMTfyFOLvqXxLlt > 0; zMTfyFOLvqXxLlt--) {
            wGPLGfcdfC = ! CtveYGGupxNPXhIh;
            KITklthFD = BtgugFUPEgtw;
            kZpyPcEIZFl = ! BtgugFUPEgtw;
            BtgugFUPEgtw = ! wGPLGfcdfC;
            KITklthFD = ! CtveYGGupxNPXhIh;
            BtgugFUPEgtw = CtveYGGupxNPXhIh;
            wGPLGfcdfC = ! kZpyPcEIZFl;
        }
    }

    if (wGPLGfcdfC != true) {
        for (int cciveCOq = 1443939310; cciveCOq > 0; cciveCOq--) {
            wGPLGfcdfC = wGPLGfcdfC;
            kZpyPcEIZFl = KITklthFD;
            kZpyPcEIZFl = kZpyPcEIZFl;
            KITklthFD = CtveYGGupxNPXhIh;
            KITklthFD = ! wGPLGfcdfC;
            kZpyPcEIZFl = ! kZpyPcEIZFl;
            CtveYGGupxNPXhIh = ! kZpyPcEIZFl;
            wGPLGfcdfC = wGPLGfcdfC;
        }
    }

    for (int ERxhSfhxHsfL = 1771250550; ERxhSfhxHsfL > 0; ERxhSfhxHsfL--) {
        kZpyPcEIZFl = ! KITklthFD;
        KITklthFD = CtveYGGupxNPXhIh;
    }

    if (BtgugFUPEgtw != false) {
        for (int eopqKFVyL = 442108253; eopqKFVyL > 0; eopqKFVyL--) {
            kZpyPcEIZFl = wGPLGfcdfC;
        }
    }

    for (int baVjpITARUgWjcd = 1672892441; baVjpITARUgWjcd > 0; baVjpITARUgWjcd--) {
        wGPLGfcdfC = CtveYGGupxNPXhIh;
        BtgugFUPEgtw = kZpyPcEIZFl;
        KITklthFD = ! KITklthFD;
        kZpyPcEIZFl = KITklthFD;
    }

    for (int RSmlHAxtBmz = 1378694801; RSmlHAxtBmz > 0; RSmlHAxtBmz--) {
        wGPLGfcdfC = ! BtgugFUPEgtw;
    }

    return -1620137599;
}

UABlEVSOj::UABlEVSOj()
{
    this->fnestdvkGVMpgRLB(739806067);
    this->hdWIGzkZXLoNMjgp(-1424615096, 932011.1632359392);
    this->aOrMq(686009.7320174342, false, string("qOWFflbvePBjNfzBylONsMVBeCvOAoBIYNWIdbjKLcakoMiEwVkxzuoqMgNuAwFlaXyKVybGyinKNiYQBWZeupeSQeEduJgfnBAsfaxpBAeORaaVitzmureIdNjYSzoiILNIyvHGcNKgYUtspLCrOqthMKxcjYwaaNgkeKfAnqxocGajmLOJqXGiPrzgsstT"));
    this->RkTmvnksV();
    this->ZwbBrMMgW(639251112, 319776.9414801304);
    this->GKdKdhIrvNcSDUso();
    this->JlEjHvGhdG(-1163981822, -509209.11883684335, true, true, false);
    this->bYWnLYaIpDpDv(844730.7540947519);
    this->rzBFtAZocGYHH(-692212.0689138531, 2046416153, string("ByDSnFdquFNIvODYrANThStnXGRpnfAedIbDbfehYtQwdYCRZpJDlKRogHGqIdQEHMKOvfBxvyx"), -2094988110);
    this->xVoRrJkPvLcX();
    this->qdENIv(-767486.7828138855, string("QzKeUDsrKRzVmoIcsMhPpJFkCHmicOTqsHZIwoZCwqMnJlVISVDAlnidvAqZEhpcuRiuYIbJqGMXhFGGEqAUJGhijjuJBXEmfgqQDQBBUGuBBSfnmgl"));
    this->FNufpibhC(1003750.178516357, -247529.19223885113);
    this->dbRsHmLkKvzVAA(string("RCqWaHZjjLKZISDbNcmiwWrVmYmpICNPvqTXfibcbmkqbnjs"));
    this->UXIxfihayHcIrjY(string("GMguwMRxyYlBSvapTybtfKRXNSuqFzewohBWMheTpaccWNFKofETLcsMKqLFlDvaEnGDnHgXYXrweTasCxCspPxwleOLcZPSzSmPavQZsqNkpjzzwqrcQnKcplsZZi"), 656579.6825642993, string("uxTiYVWeJHfwbLRQsXdfVxhgVEAqMnMFRjCEtGKyqOPMQRlhSNlGhJIQMhfAlQrfDAiqIZPZWuUOIwLgdlmjDhMHgetswUelLrvdyihfNPUvLhyEOrtwyaeEjHKioikurVBieFImpDXB"));
    this->XoKUelab(540543162, string("WxMZrhbbFhPkLOaHUFktptXWuujKAMBpORBOuJBfgwOlPnHjOclRwdeEnLETHESUfeCuBnznCtQpWqmKdkFSSwwIekIPTXrLmjGAKVMGyVQNfBKkjXjouCSHblRDGDsDGuXUKHTBIbfWWmkmJSDSJMCVYQtkOBmqDqrNlANFmbZiXGrScKoZUWJND"), 971076.0438682145, string("TxkuCUToTewIYyLPJIeCDaPKFXFEuOHxvhYvAfMmWIAkZiAxbDdnjRIzujZwSvarWyxiyFWwERKiTPprfEZYFDtlsesJkkqLILRZIamkLlRUITJpzXJUUdQVlNsIrHQpHEeHnuTDieCvNYPEDfRCQSE"));
    this->HVxpDmyRuPu(string("UbfZKJurUHOrEXuwZjSBdWBaaCntFTMjrkSmlBtaAzrLcjfvgLnShknvmkrJMKYIennhclvQ"));
    this->VXRuwWlBVqb();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QYBAynPKDqmQbR
{
public:
    int RPpHpBZJHk;
    bool aVsHxkkmz;
    string oAEnXGlu;
    double dOIjrJqpXCg;

    QYBAynPKDqmQbR();
    double fBaonEY(double MNXrKrOgD, double cJguuuYlhNgjFg, string rrqIFzp, bool RKMKq);
    void XZWHWGSMKAo(bool KUNlHGuLXKOp);
    double PtHgjg();
    int oCxRAvE();
    bool zqDlDyHn(bool HusofSKzEG, string jrskn, bool WeFsXumFa, int uFYSWSB, int uSUphbvhsilVYQ);
    void CsXwcdzDD();
    string UIkINz();
    double dupaawgWdpJlz(bool yNFHFK, string lEjpM, int ExYaAiYUH);
protected:
    bool bxKXcBHvOxTIDjN;
    string YSWxrTr;
    string gIGrt;
    int TSZPSB;
    int WHiKqnMl;

    void wzmtbZuhzrwpX(bool agYfHyuQcgKIb, double mPjCeQvpVeaUm, double SbRtYhsyi, int EJjetZGTtbbD);
    void uLYmTxG();
    void OamsehfWoEWM(string qVddhEYowIHMQs, bool tSGhXQpwXOteL, string WSpseBZ, bool JIyyraQkysohino);
private:
    bool uLinauresSQTw;
    bool ugtTEsSuSk;
    int xvXwDqvMU;
    string TqlQJuIzDtFxXQ;

    double MrfCKftBv(bool SHVqYNVEnvqo, bool HyXrKty);
    string vNUmXfhdZTxrMPW(int hpVSFuDSDNTp, int oZNeRrk);
};

double QYBAynPKDqmQbR::fBaonEY(double MNXrKrOgD, double cJguuuYlhNgjFg, string rrqIFzp, bool RKMKq)
{
    int jWZDUkESHNRk = 2113385461;
    int nAMioi = -1952362254;
    string gerPQNMwlBl = string("qZEnzsoutQjBhURVYaaNQyAhbiCuUCNIxkHpFYYPUdtFSTlsihZaUYCVHTOjIcySOhQeGuheyqqzvVUNBtJROrSfJBclSPLrfaJVlAGnfeGNEBICHpITYLuDStvkvAuaAIHyzySQKDFonoBzkagrOEHGlyK");
    string SEJGhhJZto = string("ofgrNSyeiyREjlmscyRSGZJiTcugWhGfmuptFSRvufsMTQihoSJEApyJIFcnVPYDmsMUMaYCRjOtNLOddjmgJxQCPznnWAZdRXwuebNloTjBfYeiUur");
    int VJePpqpYztLdl = 663469447;
    string sbDclrX = string("PPMCdbdYMZeXRwwoPcJNwLWkKA");
    string OWVgaTON = string("XtjdLQcHdRzOHaMfRliVzTkpuVoChZvvlBMePBcfJKLSbvkjMMTzMBxzGVWKvpPNxsgcCHhBejokPvLiwAnMUSdEhkbVLBqbqsGFAXJKKouDMLvxOxsaG");

    if (RKMKq != false) {
        for (int SRrioVelSJmYtE = 300463097; SRrioVelSJmYtE > 0; SRrioVelSJmYtE--) {
            continue;
        }
    }

    return cJguuuYlhNgjFg;
}

void QYBAynPKDqmQbR::XZWHWGSMKAo(bool KUNlHGuLXKOp)
{
    double UNjNhMTVj = -140034.29423948698;
    double BvNCdi = 805019.2630341523;
    bool AtPMKDhhAsV = false;
    string DIVdmfIoi = string("uoEWFagkAIhnoyUalNRpyMdgeHQUKPuvitWzscZXvuaxgLrtbBgsBAUwYiFHeukPogxNStHGPurXKRCLkREFDVScvDHdoZPJRlxGMy");
    bool CqGeIj = false;
    int dVshulKkyuT = 846330141;

    if (CqGeIj == false) {
        for (int AdPArucg = 578349774; AdPArucg > 0; AdPArucg--) {
            AtPMKDhhAsV = ! AtPMKDhhAsV;
            CqGeIj = ! KUNlHGuLXKOp;
        }
    }

    for (int IUebeRcf = 770610875; IUebeRcf > 0; IUebeRcf--) {
        KUNlHGuLXKOp = ! CqGeIj;
        BvNCdi += UNjNhMTVj;
        KUNlHGuLXKOp = KUNlHGuLXKOp;
    }

    if (CqGeIj == true) {
        for (int JKzSGKtVoYoLBMWo = 1604099396; JKzSGKtVoYoLBMWo > 0; JKzSGKtVoYoLBMWo--) {
            UNjNhMTVj -= BvNCdi;
            KUNlHGuLXKOp = ! CqGeIj;
        }
    }

    for (int OmxuPYC = 1343753042; OmxuPYC > 0; OmxuPYC--) {
        KUNlHGuLXKOp = CqGeIj;
        KUNlHGuLXKOp = CqGeIj;
        KUNlHGuLXKOp = AtPMKDhhAsV;
    }
}

double QYBAynPKDqmQbR::PtHgjg()
{
    double tExAEWFVc = -616019.1386134473;
    bool TebWxU = false;
    int Cveea = 730168788;
    double RiVLpo = 714889.4985395796;
    int plLYDukw = -80465209;
    int RgaidlbatbzEnCRQ = -1396357666;
    double KtvPupgQ = -568667.1534021794;
    bool pdCHOqRRlNz = false;

    if (KtvPupgQ > -616019.1386134473) {
        for (int fiPJxoVWmm = 462374227; fiPJxoVWmm > 0; fiPJxoVWmm--) {
            RiVLpo /= KtvPupgQ;
            plLYDukw /= RgaidlbatbzEnCRQ;
            Cveea -= Cveea;
            plLYDukw -= RgaidlbatbzEnCRQ;
        }
    }

    return KtvPupgQ;
}

int QYBAynPKDqmQbR::oCxRAvE()
{
    double YNclVjLwOxFm = -425998.7632692137;
    bool vEbQPjHWPPHGrTzV = true;

    if (vEbQPjHWPPHGrTzV != true) {
        for (int NqagbdhKJLPA = 1550970723; NqagbdhKJLPA > 0; NqagbdhKJLPA--) {
            YNclVjLwOxFm = YNclVjLwOxFm;
            YNclVjLwOxFm += YNclVjLwOxFm;
            YNclVjLwOxFm = YNclVjLwOxFm;
            YNclVjLwOxFm = YNclVjLwOxFm;
            YNclVjLwOxFm *= YNclVjLwOxFm;
            vEbQPjHWPPHGrTzV = ! vEbQPjHWPPHGrTzV;
        }
    }

    for (int gpAxFjqffSK = 126784120; gpAxFjqffSK > 0; gpAxFjqffSK--) {
        YNclVjLwOxFm /= YNclVjLwOxFm;
    }

    for (int XirFQzBnNlqEE = 537396101; XirFQzBnNlqEE > 0; XirFQzBnNlqEE--) {
        vEbQPjHWPPHGrTzV = ! vEbQPjHWPPHGrTzV;
        YNclVjLwOxFm /= YNclVjLwOxFm;
    }

    if (YNclVjLwOxFm <= -425998.7632692137) {
        for (int IumBsLXLfiUuCnL = 13869582; IumBsLXLfiUuCnL > 0; IumBsLXLfiUuCnL--) {
            YNclVjLwOxFm -= YNclVjLwOxFm;
            vEbQPjHWPPHGrTzV = vEbQPjHWPPHGrTzV;
            YNclVjLwOxFm = YNclVjLwOxFm;
            YNclVjLwOxFm /= YNclVjLwOxFm;
            YNclVjLwOxFm = YNclVjLwOxFm;
            YNclVjLwOxFm *= YNclVjLwOxFm;
        }
    }

    return 1177228455;
}

bool QYBAynPKDqmQbR::zqDlDyHn(bool HusofSKzEG, string jrskn, bool WeFsXumFa, int uFYSWSB, int uSUphbvhsilVYQ)
{
    int oAwaqWYcvoMFGr = 753633499;
    bool PoKqD = true;
    bool MRkWEgpgELN = true;
    string gsAHcSKjxbEINY = string("pmeGLlujOBJreTUtiKyHOdKNlzJystakpoIqKMUVIppsrTEMoTErcHByWSxWFPNAbllydpdpZSsdqWaidqxnocwHYcsRpCZpQWjDoZRvwEiaNGIfYkrpopbaYCrDlwkXa");

    for (int WybLdRLO = 263750764; WybLdRLO > 0; WybLdRLO--) {
        uFYSWSB += uSUphbvhsilVYQ;
        MRkWEgpgELN = MRkWEgpgELN;
        jrskn = jrskn;
        HusofSKzEG = PoKqD;
        PoKqD = WeFsXumFa;
        MRkWEgpgELN = ! MRkWEgpgELN;
    }

    for (int UEQrPKJJYmHVx = 75023065; UEQrPKJJYmHVx > 0; UEQrPKJJYmHVx--) {
        MRkWEgpgELN = PoKqD;
        oAwaqWYcvoMFGr -= uFYSWSB;
    }

    for (int AmvDlFNBToEOFoc = 1270533202; AmvDlFNBToEOFoc > 0; AmvDlFNBToEOFoc--) {
        uFYSWSB /= oAwaqWYcvoMFGr;
        uSUphbvhsilVYQ = oAwaqWYcvoMFGr;
    }

    return MRkWEgpgELN;
}

void QYBAynPKDqmQbR::CsXwcdzDD()
{
    bool ZvGhVF = true;
    int KhfGEwxpknrCDBrM = -38777946;

    if (ZvGhVF != true) {
        for (int kDssEA = 1943599456; kDssEA > 0; kDssEA--) {
            continue;
        }
    }

    if (ZvGhVF != true) {
        for (int ZTPyIYzPC = 1569413209; ZTPyIYzPC > 0; ZTPyIYzPC--) {
            continue;
        }
    }
}

string QYBAynPKDqmQbR::UIkINz()
{
    int CaASTdlrMff = -281179699;
    int vArzhBr = 856696831;
    double YJkrzfeIWWHJAAQh = -842297.2580934259;
    double GdTBV = -529682.9902870787;
    string vAKoTtMFfCXferKI = string("pBPJLOMSDyUdOHOUbwimLQJBPfsUjNcmmZppuKDbnWPVpRBechSxKvRrgBarfekxgnIojQDZJAThiSHsbLAccwOhiIHj");
    bool YqSDGTrOG = false;
    bool fJKczvUH = false;
    int kuvFTrTH = 975844998;
    bool MbLxR = false;
    double xGuYwlXKOXLIkL = 418629.39063166967;

    return vAKoTtMFfCXferKI;
}

double QYBAynPKDqmQbR::dupaawgWdpJlz(bool yNFHFK, string lEjpM, int ExYaAiYUH)
{
    bool NhRiRIOUNIDGZHk = true;
    string sGmkcEGf = string("llItkQTqngXUxnNksQVoPxfdPFPulpWdmwwpCfzQaOGzAgjPsHbcwpSaHeBSVrRYDQuqsaPhfLJPYFrOHQqTbufVNKzoppAfWKxeEpNnFLSJrxxgHWylxgilKAcbDLuAISzkqUBZEJSIxJaCEipqnEcNcikTXnHFwC");

    for (int eXzFqfcI = 930012382; eXzFqfcI > 0; eXzFqfcI--) {
        continue;
    }

    return 338326.1299323137;
}

void QYBAynPKDqmQbR::wzmtbZuhzrwpX(bool agYfHyuQcgKIb, double mPjCeQvpVeaUm, double SbRtYhsyi, int EJjetZGTtbbD)
{
    string DMgag = string("QCDrEXwLhbMMSykTarAXcWLMrIRQfirFidzHtCIJmiWUHPyWCvcjRPJdMyTSyzxEhhWikWwIjzUVOPztPmOvtlpITzhDOjUNzEoDgLNPOpjckhetYNLHYYQlevXcQANvipNUAURHdmcpfDOgTNnSmswrTFhOCglyohZWwoKWhstbkNGjguHGwRiPuZpkOUCBRZOFj");
    double TLlzwxMI = -596653.5471247305;
    int qhIWYMTiUPKP = -1524033214;
    bool ZCkZGAHf = true;
    int UdmqS = -1167084889;
    bool WyhKPJqGciEEA = false;
    int uczOWTCAGfGStEE = -669711988;
    int vBJfDPGpZ = 955723493;
    string XEjALMRRXFyiL = string("GRYSfboLmpGaobdLZjfsGIbsTrSPESBvraDDDFhHLdlAyHYcdCGmbrtrPBxOWBUkfaAkLDTXlPNlpbvtOtHmhKhJVcbcvlYpQvYazUqMdBKkSCaeUlpeblSQUezcbJatpvZlfFRkSlMiaXoFbLRFvdByXTySneqCfcIQTVpKFkUgoE");
    double ymuoIKTVwkeLu = -761061.4151766652;

    for (int sybqoakzhANjeqVm = 804347481; sybqoakzhANjeqVm > 0; sybqoakzhANjeqVm--) {
        vBJfDPGpZ /= uczOWTCAGfGStEE;
    }
}

void QYBAynPKDqmQbR::uLYmTxG()
{
    int ntPfs = 1560599521;
    double aHvRCjuTNLeADY = -667121.7848882492;
    int atocZ = -1711821672;
    double OQwBkh = 589190.8948492509;
    double umPuoIhGR = -914172.8095749001;
    string GleydhgyARomrApz = string("LRHGQW");
    double ttKxrbVZAfLra = 837838.6641709433;
    bool zXbbDgwtfJwSTK = true;
}

void QYBAynPKDqmQbR::OamsehfWoEWM(string qVddhEYowIHMQs, bool tSGhXQpwXOteL, string WSpseBZ, bool JIyyraQkysohino)
{
    string qDRRafhPgy = string("BBdTxMLWgmGWUYBJIfmFogtzqsNlqUzNWLxeWLQfagjmOiQBBobgEYwujgbCzWbJAxXSrthfjwhBgwdjiqfEfdFquaqjFuTQrfPaGwPjirIumqkDjlKCOJUPYkihaPgJkYfTMdDPjkLpJHIhRvaBfQKbejBfiHVWPOZpZSMWsezLzqOkVAyIRDbfRArjSEnjwvgXUGYLNxNzPQBkJrBLGnrgysWvHLumcJTwnCxChdlqhVmKeasixXJlayzd");

    for (int ZVOflXYBJChVQR = 1158269593; ZVOflXYBJChVQR > 0; ZVOflXYBJChVQR--) {
        qDRRafhPgy += qDRRafhPgy;
        qVddhEYowIHMQs += qDRRafhPgy;
    }

    if (qDRRafhPgy == string("BBdTxMLWgmGWUYBJIfmFogtzqsNlqUzNWLxeWLQfagjmOiQBBobgEYwujgbCzWbJAxXSrthfjwhBgwdjiqfEfdFquaqjFuTQrfPaGwPjirIumqkDjlKCOJUPYkihaPgJkYfTMdDPjkLpJHIhRvaBfQKbejBfiHVWPOZpZSMWsezLzqOkVAyIRDbfRArjSEnjwvgXUGYLNxNzPQBkJrBLGnrgysWvHLumcJTwnCxChdlqhVmKeasixXJlayzd")) {
        for (int kygvanclPqf = 1980243453; kygvanclPqf > 0; kygvanclPqf--) {
            tSGhXQpwXOteL = JIyyraQkysohino;
            JIyyraQkysohino = ! JIyyraQkysohino;
            WSpseBZ = WSpseBZ;
        }
    }

    for (int sfSNPpz = 747570334; sfSNPpz > 0; sfSNPpz--) {
        qVddhEYowIHMQs = qVddhEYowIHMQs;
    }

    if (tSGhXQpwXOteL != false) {
        for (int pjmuGb = 2128752209; pjmuGb > 0; pjmuGb--) {
            tSGhXQpwXOteL = tSGhXQpwXOteL;
            tSGhXQpwXOteL = ! JIyyraQkysohino;
        }
    }

    for (int olJdouPgv = 193865850; olJdouPgv > 0; olJdouPgv--) {
        WSpseBZ += qDRRafhPgy;
        qDRRafhPgy += WSpseBZ;
        JIyyraQkysohino = ! JIyyraQkysohino;
        qVddhEYowIHMQs = qDRRafhPgy;
    }

    for (int YLUWVaADAGZnPD = 1424469566; YLUWVaADAGZnPD > 0; YLUWVaADAGZnPD--) {
        JIyyraQkysohino = JIyyraQkysohino;
        WSpseBZ = WSpseBZ;
        qDRRafhPgy += WSpseBZ;
        JIyyraQkysohino = JIyyraQkysohino;
    }
}

double QYBAynPKDqmQbR::MrfCKftBv(bool SHVqYNVEnvqo, bool HyXrKty)
{
    double AWShe = -307507.51458458777;
    bool gstWtbLVQSW = false;
    double kYmkZpdn = 356471.92829106544;
    double HJEsD = 939547.7476979833;
    int ewEsUiNEncea = -2016473366;
    bool hOyoDV = true;
    string xCMwBQQmpZ = string("OZRHssMZKXJsVEXPECdJWsvgyeLlZxoUpcqrjfnssAWhQLqOFtDfeJlAiFwAPJezIhXbHxpPAzlOvfOyzrCrLPkarYjWcZPWQzhmzLBZSGMbwdjhHUE");
    int osNTZ = -1914226525;
    int EDPlrNSZUuz = 1698176180;

    return HJEsD;
}

string QYBAynPKDqmQbR::vNUmXfhdZTxrMPW(int hpVSFuDSDNTp, int oZNeRrk)
{
    double RwIbkbDThtoBngp = -216586.19797802495;
    int yrfiaxzgpkvE = -1983579446;
    double zrLIYWAxkCpWK = -70293.85678750624;
    int rrNQoXw = 1994578741;
    string AZLnaUcMral = string("dngbknXQtZERlUMGOtPtBfXI");

    for (int PcGVgrBbNC = 1113233357; PcGVgrBbNC > 0; PcGVgrBbNC--) {
        hpVSFuDSDNTp /= yrfiaxzgpkvE;
        yrfiaxzgpkvE *= yrfiaxzgpkvE;
        AZLnaUcMral += AZLnaUcMral;
    }

    if (RwIbkbDThtoBngp > -216586.19797802495) {
        for (int tDNwy = 110898293; tDNwy > 0; tDNwy--) {
            zrLIYWAxkCpWK = zrLIYWAxkCpWK;
            yrfiaxzgpkvE += yrfiaxzgpkvE;
            rrNQoXw = oZNeRrk;
            hpVSFuDSDNTp -= oZNeRrk;
            hpVSFuDSDNTp -= hpVSFuDSDNTp;
        }
    }

    if (oZNeRrk == 1994578741) {
        for (int jWPfll = 1837461345; jWPfll > 0; jWPfll--) {
            yrfiaxzgpkvE *= hpVSFuDSDNTp;
            hpVSFuDSDNTp *= yrfiaxzgpkvE;
            oZNeRrk /= oZNeRrk;
            hpVSFuDSDNTp += rrNQoXw;
        }
    }

    for (int VVRlCpwG = 486524482; VVRlCpwG > 0; VVRlCpwG--) {
        continue;
    }

    for (int PfpNSQJGrwEDB = 1575934558; PfpNSQJGrwEDB > 0; PfpNSQJGrwEDB--) {
        yrfiaxzgpkvE *= rrNQoXw;
        yrfiaxzgpkvE = hpVSFuDSDNTp;
        hpVSFuDSDNTp /= oZNeRrk;
        oZNeRrk /= hpVSFuDSDNTp;
    }

    return AZLnaUcMral;
}

QYBAynPKDqmQbR::QYBAynPKDqmQbR()
{
    this->fBaonEY(322832.34148095537, -806072.3411226913, string("kqFLIamCPnBrPQtgxkzTtIvBXzavDtCxcdsdSunlmQlJlieNDpPCVMCTmvpkIrynWktNnbCaAMYjkwAvWdgrhSzcuZQwfqMLPfZpBZHDBgnBAUVZCNkTHPropuoBJtzFtiOPpZeFJrPkTNsVBDjVRcpvFfCqJeSbNYhKlPHmElPyeFwtqCWFGKFwOnaQlnUhDhhkpUjdKeOBbIqsSJStSYEg"), false);
    this->XZWHWGSMKAo(true);
    this->PtHgjg();
    this->oCxRAvE();
    this->zqDlDyHn(true, string("PvwTrYHCPtltGQnEFXfxIuCvAVEaJJvjqbbEneXJklkDrvMykVEyDmgWWJJvnGFBWpyFBtPscGznqVPTxiUgwPgdzUnFlXvPZpDdsSCPrrMHTNoPbTekjWiMCMpyBjZGzTmCdnKVUBrfqUCOZSsxOWxhPaaFzdkRYjuMSguNmQXGeSgfyj"), false, 1859573662, 470933815);
    this->CsXwcdzDD();
    this->UIkINz();
    this->dupaawgWdpJlz(true, string("MxvaTvNldCBzjLCLyrPPAayuAabdnZDjOrrVAIDUUOGpTLidSvKHOjmqTnBOZaeKhsJMFIqvRwCqrpBlQgAqElpSmlbhqCmNcVVccViPx"), -319042212);
    this->wzmtbZuhzrwpX(true, 339000.8166089081, 459739.6159985462, -927285110);
    this->uLYmTxG();
    this->OamsehfWoEWM(string("opfWghqAtADiGpcbDLnH"), false, string("FrOZLXAbREuMeyvXIbJJbHnjcRxKLBLkihKfkaiZaUYQHcxmxTVjensaRWIgTAcMjQxhvQZJYZaE"), false);
    this->MrfCKftBv(false, false);
    this->vNUmXfhdZTxrMPW(-153075218, -826545606);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JxtRLLAiwvCEuj
{
public:
    int YHnEEPlbCN;
    int rQezrz;
    string SAhRqQLCshRbKj;

    JxtRLLAiwvCEuj();
protected:
    bool XeJEhUbA;
    int lpxOfJGhcGqRB;

    void nwBRMrIicDo(bool HjCJPRlLLCtkUBH, int MEYmGEgAi, bool niAriQpEDbNrHTO, bool BlTNYWpcQGmhddje, bool fWVWIvhvqYLWd);
    string ztdnYglEiWRfivc(bool oAHvhswyavJZs);
    double cgmCLcFrJKFfkLS(bool ByzqtD, string eNoLz, string IJfgSSvFaWuAdE, double CQlSDxCdxfmtXP, double UKcQWm);
    int vPAFqQFRepn(int rHciCCvd, int odMYWll);
    int gAjIGXWqqt(int lWaJqlQUKO);
private:
    double wPrAvCw;
    double FEAJQDKQhvibYQL;
    bool RnquRPkuFgVmA;
    bool dDQvBomXupeYqPk;

    bool uCUAGHghiy(int tWbtM, int UpJCncwpiDK, double nodfJoEzvDUKaXLN);
    bool EjXYf(string oDSaVRG);
    int qoLYufFjyexDlts(double VsFtXchCX);
};

void JxtRLLAiwvCEuj::nwBRMrIicDo(bool HjCJPRlLLCtkUBH, int MEYmGEgAi, bool niAriQpEDbNrHTO, bool BlTNYWpcQGmhddje, bool fWVWIvhvqYLWd)
{
    int eyvpJSgP = 275717074;
    string OuUcDoNIUoCfP = string("CrFpicssXoBzbdSpzQfYUhGWKPJQkFCYZrMDAFnXwbmuKHbIGN");
    int lUHSzgxXN = -1393028492;
    string jFssYJ = string("MRtqiMXKjiRjRRTVsPsNODSyNWiCsSDpqFEAbSZOwNEDIVvaZzfWdcwCRvRUreLPfUqig");

    for (int gKTlx = 231850804; gKTlx > 0; gKTlx--) {
        OuUcDoNIUoCfP = OuUcDoNIUoCfP;
        eyvpJSgP *= eyvpJSgP;
    }

    for (int OYEWwpototgdxe = 1514233726; OYEWwpototgdxe > 0; OYEWwpototgdxe--) {
        MEYmGEgAi += eyvpJSgP;
        fWVWIvhvqYLWd = fWVWIvhvqYLWd;
        fWVWIvhvqYLWd = niAriQpEDbNrHTO;
        niAriQpEDbNrHTO = ! fWVWIvhvqYLWd;
    }

    for (int gbAVtiOnxpYweZq = 1628981154; gbAVtiOnxpYweZq > 0; gbAVtiOnxpYweZq--) {
        niAriQpEDbNrHTO = ! HjCJPRlLLCtkUBH;
        niAriQpEDbNrHTO = ! fWVWIvhvqYLWd;
        BlTNYWpcQGmhddje = ! HjCJPRlLLCtkUBH;
        eyvpJSgP /= lUHSzgxXN;
        lUHSzgxXN = eyvpJSgP;
        BlTNYWpcQGmhddje = HjCJPRlLLCtkUBH;
    }
}

string JxtRLLAiwvCEuj::ztdnYglEiWRfivc(bool oAHvhswyavJZs)
{
    string dHggViTK = string("AgAlljizwFwtwwlwmViORwhxcQUTJBrQMzyHfwAaKVcpsnOPSkzLlHmWfSwvNrQnuDthhRjCMkCXrGZmwdRIwfuYyhYxGnMiFhLlzsqcVGuyunNUPdKuoxTaDtUdykzFduBxh");
    bool eMIGIPSzci = true;
    bool YRrJZ = true;

    for (int cmRPJ = 705868299; cmRPJ > 0; cmRPJ--) {
        oAHvhswyavJZs = eMIGIPSzci;
        eMIGIPSzci = YRrJZ;
        eMIGIPSzci = oAHvhswyavJZs;
    }

    if (oAHvhswyavJZs != true) {
        for (int XgyYUVaqCYGc = 1539059760; XgyYUVaqCYGc > 0; XgyYUVaqCYGc--) {
            eMIGIPSzci = ! oAHvhswyavJZs;
        }
    }

    if (oAHvhswyavJZs != true) {
        for (int CGjlUunjSqfJ = 2065261545; CGjlUunjSqfJ > 0; CGjlUunjSqfJ--) {
            YRrJZ = ! oAHvhswyavJZs;
            oAHvhswyavJZs = YRrJZ;
            oAHvhswyavJZs = ! YRrJZ;
            oAHvhswyavJZs = ! eMIGIPSzci;
        }
    }

    return dHggViTK;
}

double JxtRLLAiwvCEuj::cgmCLcFrJKFfkLS(bool ByzqtD, string eNoLz, string IJfgSSvFaWuAdE, double CQlSDxCdxfmtXP, double UKcQWm)
{
    double kazQJQ = -925413.479726123;

    for (int ONfIwQDKRsTd = 1768331875; ONfIwQDKRsTd > 0; ONfIwQDKRsTd--) {
        CQlSDxCdxfmtXP = UKcQWm;
    }

    return kazQJQ;
}

int JxtRLLAiwvCEuj::vPAFqQFRepn(int rHciCCvd, int odMYWll)
{
    bool jYoRM = true;
    int fszNAGAxgedyQXD = -731903339;
    string UozpkclOExkeP = string("sZPhQgvLRXWEypgfjvAXGDHRZyRmueKivRxCHInLDTuepwFjbzFoqZUBWxVkcNLYRnBodg");
    bool aJLeahZnzxZGw = false;
    string rDGuRk = string("kdovvkWaLpcyjwlIjhVfzdIkXDSeYEnOMWDabnKSoGkEX");
    bool ghkHadfqxg = true;
    bool vnOqixMKX = true;
    double JgPJyi = -688085.1739151079;

    return fszNAGAxgedyQXD;
}

int JxtRLLAiwvCEuj::gAjIGXWqqt(int lWaJqlQUKO)
{
    bool hZXiNz = false;
    bool seYBhdSGOvAtZf = true;
    int hWgTbzEPRHjd = -1754728277;
    int UjLoTfG = 1623403878;
    int VXYnZktYDp = -403660852;
    int lgpUcddBEvpSs = 1131952909;
    bool KzUHkGvMPGFtCcON = false;
    string gpauuspAednNRVqw = string("lDDYhpwUjyLMIYjoREJvzQTOfBECWMrSGpmqjJmyq");
    bool IKBJZyNWm = true;

    if (lgpUcddBEvpSs != -970590436) {
        for (int xXwizerX = 107032099; xXwizerX > 0; xXwizerX--) {
            UjLoTfG *= lgpUcddBEvpSs;
        }
    }

    return lgpUcddBEvpSs;
}

bool JxtRLLAiwvCEuj::uCUAGHghiy(int tWbtM, int UpJCncwpiDK, double nodfJoEzvDUKaXLN)
{
    bool ZrlSuF = false;
    double ymurXbf = -663122.5713787462;
    double CCkfKipHZ = 851678.8280143441;
    bool kGcFJbH = true;

    if (CCkfKipHZ >= -663122.5713787462) {
        for (int cWSfwLkCsiYLVK = 1329013377; cWSfwLkCsiYLVK > 0; cWSfwLkCsiYLVK--) {
            nodfJoEzvDUKaXLN += nodfJoEzvDUKaXLN;
            ymurXbf /= CCkfKipHZ;
            ymurXbf = CCkfKipHZ;
        }
    }

    if (tWbtM < -1384887266) {
        for (int qQpOEMYg = 1705070232; qQpOEMYg > 0; qQpOEMYg--) {
            UpJCncwpiDK = tWbtM;
            ZrlSuF = ! ZrlSuF;
            ZrlSuF = ! kGcFJbH;
        }
    }

    if (ymurXbf >= 851678.8280143441) {
        for (int dUNEEGgULiE = 145357678; dUNEEGgULiE > 0; dUNEEGgULiE--) {
            CCkfKipHZ -= CCkfKipHZ;
            CCkfKipHZ /= ymurXbf;
            kGcFJbH = ! ZrlSuF;
        }
    }

    return kGcFJbH;
}

bool JxtRLLAiwvCEuj::EjXYf(string oDSaVRG)
{
    string lwPJWROjpMF = string("tJxzLJwiGdInGsQwLLtiKMtupqOavXBQzoINVwzyLXpxckflSmmktIbXbrbfuXRFiSEIwkxRPxFsUYNbyGwDAjGMIdezfqxndNmupeTkkRUuwlgzDwdOFVwyaYYfrvFmqFWqenSJwleTBQNimWZpYsOyLZEnPIOTGWtcogvHtmeULXXPjgvkInENQeP");
    bool NIUuZlHZtNPTll = false;
    string OISSpUa = string("fgiYBbfadgQSTFwxPZVBPAMWoJYGfoThArrs");
    int yQyibFkz = -2024074659;

    for (int WFDBvKHjAN = 1663631513; WFDBvKHjAN > 0; WFDBvKHjAN--) {
        OISSpUa += lwPJWROjpMF;
        OISSpUa += lwPJWROjpMF;
        lwPJWROjpMF = oDSaVRG;
        lwPJWROjpMF = OISSpUa;
    }

    return NIUuZlHZtNPTll;
}

int JxtRLLAiwvCEuj::qoLYufFjyexDlts(double VsFtXchCX)
{
    int QPdAKaLWZbcUEh = 2146527212;
    int fBVlNjWSxGdJ = 1486703215;
    string fYwPzpRvyKWDbvAo = string("eKgAhjXpkhRgMTozBJVqRBXjhXsJTJNnlbt");
    int JGaFHnTBKkHFivf = 1197542080;
    double VglxqOwv = 522549.2398463007;
    int HIRjGeCsu = 1871586769;
    string HIGpl = string("dgGHUbKwEiPCDqUwhmAhZJcgtUzXvqnoXuLvGFQtmiZhrjEHPriNLtzfxqXOlOuokiKYfdcwDrhKARnXuFzuORgNyfJqPtxfskeSdMGdhOZcklijhTVwtZJWBDcikBVKpxDCwZshqjSSFTGdgpFqUgVTuaDmbMIvHAbSESDlKtHmTiSKbQXMvtsjlxfmMqIoMGOzNOWqsUBwRFrroXrPLThiXjrICAm");
    string lzAyBJiwajTlysto = string("uATGgwBXDAFIpvySsEZCosRQYnfYjEgLlQuffEPPXzyKyoWitcGWpPwPkDkSGuEiBQjFaRHKUBmXYgplExrCdNBZMxNXrhlwEcVNPUDBUnFukLPkzkmmYwoUCyPfdOJqRkIpAguLeFiglxYgqgJzeiCInTkENkqjqkhRFQFYZeWUdPogZgqKXnTBGgaceKiKBkzSsniVcvTRHvmVeyHgJpukmgDcPFNIcqgJ");
    int rRTALgFbJaa = 65083174;

    if (fBVlNjWSxGdJ > 1486703215) {
        for (int ErgkJI = 203403074; ErgkJI > 0; ErgkJI--) {
            continue;
        }
    }

    for (int GlzyZnFJF = 1435654039; GlzyZnFJF > 0; GlzyZnFJF--) {
        continue;
    }

    if (lzAyBJiwajTlysto <= string("dgGHUbKwEiPCDqUwhmAhZJcgtUzXvqnoXuLvGFQtmiZhrjEHPriNLtzfxqXOlOuokiKYfdcwDrhKARnXuFzuORgNyfJqPtxfskeSdMGdhOZcklijhTVwtZJWBDcikBVKpxDCwZshqjSSFTGdgpFqUgVTuaDmbMIvHAbSESDlKtHmTiSKbQXMvtsjlxfmMqIoMGOzNOWqsUBwRFrroXrPLThiXjrICAm")) {
        for (int aaAvxyeChcN = 1322553556; aaAvxyeChcN > 0; aaAvxyeChcN--) {
            HIRjGeCsu *= JGaFHnTBKkHFivf;
        }
    }

    if (VsFtXchCX != 522549.2398463007) {
        for (int hXglrypsZUL = 36350293; hXglrypsZUL > 0; hXglrypsZUL--) {
            rRTALgFbJaa += JGaFHnTBKkHFivf;
            fBVlNjWSxGdJ += QPdAKaLWZbcUEh;
            JGaFHnTBKkHFivf *= HIRjGeCsu;
        }
    }

    for (int qCSMMZxOY = 1776368904; qCSMMZxOY > 0; qCSMMZxOY--) {
        fBVlNjWSxGdJ -= HIRjGeCsu;
        fYwPzpRvyKWDbvAo = lzAyBJiwajTlysto;
    }

    if (fBVlNjWSxGdJ <= 65083174) {
        for (int XHirOASmXLFSziq = 964988343; XHirOASmXLFSziq > 0; XHirOASmXLFSziq--) {
            HIRjGeCsu /= rRTALgFbJaa;
            HIGpl += HIGpl;
            rRTALgFbJaa /= QPdAKaLWZbcUEh;
            QPdAKaLWZbcUEh = JGaFHnTBKkHFivf;
            lzAyBJiwajTlysto += fYwPzpRvyKWDbvAo;
        }
    }

    for (int fTtzueuERrIoaVQ = 1439373439; fTtzueuERrIoaVQ > 0; fTtzueuERrIoaVQ--) {
        rRTALgFbJaa /= QPdAKaLWZbcUEh;
    }

    if (VglxqOwv <= -130230.89700651055) {
        for (int xlOngON = 1439761260; xlOngON > 0; xlOngON--) {
            HIGpl = fYwPzpRvyKWDbvAo;
        }
    }

    return rRTALgFbJaa;
}

JxtRLLAiwvCEuj::JxtRLLAiwvCEuj()
{
    this->nwBRMrIicDo(false, 216392879, true, true, true);
    this->ztdnYglEiWRfivc(false);
    this->cgmCLcFrJKFfkLS(true, string("gkCuggcLYTRDiQxURBAxMSKOdydQGaFfeTWsJKINaXxRIJucAePsozZOmuaOfmEreewZcrTpubalNuBvSVNvCbdpQibrdjYGvBxdymGOylKGPIqrsdMDNGvQdkuyQLfYmHYNRThKanBJgLcFzWjhVFGZvUBzHfpGbqgokWBjTRiFiEvxHTpKSFLCyBCZRZZbBFk"), string("iDgbNDrGQQQunLL"), 295266.37028514745, -531313.2044757361);
    this->vPAFqQFRepn(-764426622, 2126572035);
    this->gAjIGXWqqt(-970590436);
    this->uCUAGHghiy(-432177212, -1384887266, -648743.7203606887);
    this->EjXYf(string("kPSNhiunOUDGdJvxLEKDoeCgzHlgSsRnkNoBKDNjjKEKryIFbEiLCxdphclquJyKqhrjBXStEZKWscwBICGbMoRyHweuDmXGxmqeXMVxsLdzaRxJCPylCTwmrpOHeJLFTJEXxwmKCFfMQNYFFeQVjLucPmbM"));
    this->qoLYufFjyexDlts(-130230.89700651055);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GNJLrhFo
{
public:
    string SNAEN;
    string JsloVoICYLK;
    string eQJwcSbThSV;

    GNJLrhFo();
    bool gegPcXLfpR(int zpeOZSzRSsmAH, int cwbjWBKHjRPB, int ufzSomamN, bool EsWdGAkSxtwmz, int sdSBgzryg);
    string tHXGobIGEBDapiwG(string VHHItmYSGM, double FoQODqfsWWgC);
    int hsNTayFNNqU(string VoxMLpkCaIVSu, bool XygeXYISGTyjILC, double ysZclppuPShkeCax);
    int HhxrfuS(string mVTCtSKeGsEYlbMF);
    string DwzYPd();
    int lvStbdYvqQ(double bQnlaVH, int hTQDqDYPqRtzGy, bool uoqwKKYqTxSvGDS, double UToboxMwX, double wNjSWcgNYFs);
    int EOaLsfSL(int oudwDILJnyoYamX, string WehJxXFSgSQn, bool JmLXVnZpOQcHAJ, double aNSJfHPjwc, string SSblWrRcjQTDlrU);
    bool oRfNdyTmfyjBm(string AsvmExCIFnH, bool FTkWlAABh, bool lTKRvNhfD, string MbxUKjKJhMNAqGbD, bool rbVJdoF);
protected:
    string tDTaxJSIv;
    double FBGvYI;
    double SBNIagUgbI;
    double iyVaHwPSz;

    bool EBqbOgkhWyP(int akWjCQAraMOVmSpC, bool CohXThygpRt, int olHsNQzQIS);
    void WnRWUtqE(string bbBGQkvASX, int aSVBjXDtk);
    string mKtyFrlf(string kBleQeElEOWajjz, double FKLqRNLhf, string wFefSTwhqGx, string jcFhxKaZs, bool oOeRaJhPprZn);
    string iZNwTs();
    double wMYeP();
    int nFrAmDoEwaVqVwnR();
    string CEDtBjbSBY(int UkSVscwwCdj, string ROorWpkppJI);
    double UiTsw(int DknNWBKSIIAPHh, int JtTvpxGJKUbG, string YSfVqM, bool lZggHibZKite);
private:
    int CtVwOirmlCdacusY;
    double xzDuufLIbHSx;
    bool eiSBWYPkVgugjL;
    double hgzXkXbPWwos;
    string owWaCaqo;
    double kYvXvYGvSauhGnfy;

    bool eykUDPQxnmPT();
};

bool GNJLrhFo::gegPcXLfpR(int zpeOZSzRSsmAH, int cwbjWBKHjRPB, int ufzSomamN, bool EsWdGAkSxtwmz, int sdSBgzryg)
{
    int PVwEhc = 232197969;
    int nBzuzSmzlYSS = 2141315270;
    int clZmBdGTqsSOeE = -824646604;
    int pGKCVFQB = 1281000156;
    string WfihD = string("RBcGKKSEMIJBuRGnSruPCzmiUfQQQFicILZOAEzmgeoIoYDzcLUyEIJLrZHXmxpbzWjvQbShjKPaIVfmrzdeIYzqEqSSDTiCPPAQlApeBowufD");

    if (clZmBdGTqsSOeE >= 1281000156) {
        for (int UwJaAayqU = 857032655; UwJaAayqU > 0; UwJaAayqU--) {
            cwbjWBKHjRPB -= pGKCVFQB;
            zpeOZSzRSsmAH *= PVwEhc;
        }
    }

    for (int DaelFsEJCdnzC = 918292702; DaelFsEJCdnzC > 0; DaelFsEJCdnzC--) {
        clZmBdGTqsSOeE /= PVwEhc;
    }

    for (int sQREx = 328504106; sQREx > 0; sQREx--) {
        zpeOZSzRSsmAH += nBzuzSmzlYSS;
        nBzuzSmzlYSS = zpeOZSzRSsmAH;
        PVwEhc = sdSBgzryg;
        sdSBgzryg /= ufzSomamN;
        cwbjWBKHjRPB -= pGKCVFQB;
        zpeOZSzRSsmAH -= zpeOZSzRSsmAH;
    }

    if (PVwEhc != -299699429) {
        for (int DriKAXGxXNwAXSI = 833392354; DriKAXGxXNwAXSI > 0; DriKAXGxXNwAXSI--) {
            PVwEhc *= ufzSomamN;
            PVwEhc *= clZmBdGTqsSOeE;
        }
    }

    if (clZmBdGTqsSOeE > 232197969) {
        for (int hCucDITftDkKHW = 1640436945; hCucDITftDkKHW > 0; hCucDITftDkKHW--) {
            cwbjWBKHjRPB = sdSBgzryg;
            sdSBgzryg -= pGKCVFQB;
            PVwEhc /= cwbjWBKHjRPB;
            clZmBdGTqsSOeE = clZmBdGTqsSOeE;
            ufzSomamN *= zpeOZSzRSsmAH;
        }
    }

    return EsWdGAkSxtwmz;
}

string GNJLrhFo::tHXGobIGEBDapiwG(string VHHItmYSGM, double FoQODqfsWWgC)
{
    double etCuvuXReM = 858126.1666007316;
    bool zzieGJsJjo = true;
    bool BtQDAgEtjlpGHww = true;

    for (int eqBmMZXBHqOjgISx = 429696985; eqBmMZXBHqOjgISx > 0; eqBmMZXBHqOjgISx--) {
        etCuvuXReM *= FoQODqfsWWgC;
        BtQDAgEtjlpGHww = ! zzieGJsJjo;
        BtQDAgEtjlpGHww = zzieGJsJjo;
        zzieGJsJjo = zzieGJsJjo;
    }

    for (int wKdkGVBFmmrCg = 401421348; wKdkGVBFmmrCg > 0; wKdkGVBFmmrCg--) {
        VHHItmYSGM = VHHItmYSGM;
        etCuvuXReM = FoQODqfsWWgC;
    }

    for (int ykqwPh = 642925688; ykqwPh > 0; ykqwPh--) {
        etCuvuXReM += etCuvuXReM;
        etCuvuXReM = FoQODqfsWWgC;
    }

    for (int ooHVJHbDI = 1952242705; ooHVJHbDI > 0; ooHVJHbDI--) {
        FoQODqfsWWgC /= etCuvuXReM;
        etCuvuXReM /= etCuvuXReM;
    }

    for (int cBlDIZmUOI = 413459593; cBlDIZmUOI > 0; cBlDIZmUOI--) {
        etCuvuXReM += FoQODqfsWWgC;
    }

    return VHHItmYSGM;
}

int GNJLrhFo::hsNTayFNNqU(string VoxMLpkCaIVSu, bool XygeXYISGTyjILC, double ysZclppuPShkeCax)
{
    bool MkkcVsQN = false;

    for (int kmXZK = 725080363; kmXZK > 0; kmXZK--) {
        ysZclppuPShkeCax *= ysZclppuPShkeCax;
        MkkcVsQN = XygeXYISGTyjILC;
        MkkcVsQN = MkkcVsQN;
    }

    for (int UJsuviZSHNNfYjO = 1136367983; UJsuviZSHNNfYjO > 0; UJsuviZSHNNfYjO--) {
        VoxMLpkCaIVSu = VoxMLpkCaIVSu;
    }

    return 1389471761;
}

int GNJLrhFo::HhxrfuS(string mVTCtSKeGsEYlbMF)
{
    int sMEfdXLV = -2095651750;
    string MJaYRwBQKLvA = string("SLNdAxOdjchrSYHyURVLbBMsVwakOzvMthoGWeajaQGzdUJzrHbFPJHZJWKxdTBLvHWqNQYjqazgkxAAAZAYHsTNFbJIystTzfiiZlUiQObkAKxdUDROzSG");
    bool PUzKY = true;
    bool TDoUNxwkkCBVdgFA = true;

    for (int fXTAIMCZpMlxUB = 651663428; fXTAIMCZpMlxUB > 0; fXTAIMCZpMlxUB--) {
        TDoUNxwkkCBVdgFA = ! TDoUNxwkkCBVdgFA;
        TDoUNxwkkCBVdgFA = TDoUNxwkkCBVdgFA;
    }

    return sMEfdXLV;
}

string GNJLrhFo::DwzYPd()
{
    int HEOvDjCtb = 1767856706;
    int NbgBdhEvuhMqZqA = 990401083;
    bool awXHzNTbTrhWnDbM = false;
    string FWxckbqhWSi = string("OurbVudqnSlYandEhHkUDUVbyzySprdBWrlKExMLGxhSPzZayzWOonIIYJnRYqrfjFfQCNbYeGukOnQMBaaECvXcNAzDSVFpGgkwqU");
    bool EJZeI = true;
    bool mHQlvkmS = false;

    return FWxckbqhWSi;
}

int GNJLrhFo::lvStbdYvqQ(double bQnlaVH, int hTQDqDYPqRtzGy, bool uoqwKKYqTxSvGDS, double UToboxMwX, double wNjSWcgNYFs)
{
    double DMVrf = 286779.18362738064;
    int xqjVuIw = -450412580;
    double aLJHQoyXPjqGtr = 857836.1403185929;

    if (UToboxMwX == -639774.0016437275) {
        for (int dJHeQAPzYcpwzCs = 592082075; dJHeQAPzYcpwzCs > 0; dJHeQAPzYcpwzCs--) {
            xqjVuIw *= hTQDqDYPqRtzGy;
            hTQDqDYPqRtzGy -= hTQDqDYPqRtzGy;
            aLJHQoyXPjqGtr *= UToboxMwX;
            hTQDqDYPqRtzGy /= xqjVuIw;
            bQnlaVH *= UToboxMwX;
        }
    }

    return xqjVuIw;
}

int GNJLrhFo::EOaLsfSL(int oudwDILJnyoYamX, string WehJxXFSgSQn, bool JmLXVnZpOQcHAJ, double aNSJfHPjwc, string SSblWrRcjQTDlrU)
{
    double pQHbPSxRYSN = -557427.122137563;
    int UUClR = 1545860277;
    bool fqWkDlCc = true;
    bool EksfVBpRSyedlOih = false;
    string UlkBrNBgunRxeUa = string("MTNhVoHWgcVVHPdBlFSPjhfPuMMjJjzSAPMRUSESFMcRmjeLuiNkcDXBwOGOOzBwmOGbMuWbWrGkzmGprSYFSh");
    bool gLbMoCe = false;
    int MyzGpMFcgVKiEyX = 1095059425;
    bool qATxFqiJQU = true;
    string fbwfQ = string("dVaVjEltnOlNwRSWvqmxvESqxQYeDgYWvKKVLXtcusEDXzeSvpWEhffuA");
    int RPKPhcatsclwXS = 781227251;

    if (WehJxXFSgSQn <= string("MTNhVoHWgcVVHPdBlFSPjhfPuMMjJjzSAPMRUSESFMcRmjeLuiNkcDXBwOGOOzBwmOGbMuWbWrGkzmGprSYFSh")) {
        for (int CXVKUsLSDavQ = 1678913940; CXVKUsLSDavQ > 0; CXVKUsLSDavQ--) {
            RPKPhcatsclwXS = UUClR;
        }
    }

    for (int PjtreYWRKMd = 1493361500; PjtreYWRKMd > 0; PjtreYWRKMd--) {
        RPKPhcatsclwXS /= UUClR;
    }

    if (WehJxXFSgSQn != string("OXgHFajTryvPkIIKqeLNYUPjYGnZfILRkACOEDMsPPojxxoeyYyTvUEsgMotEhCGOBSSHjCbJIojtIRqiztNytnOeirSephboniSHYkCjySQvzKzFpblLOUAAarNJwoNpdMNJQlqZjyzSUEopBzbEdFEIl")) {
        for (int fWksIGi = 1143990617; fWksIGi > 0; fWksIGi--) {
            continue;
        }
    }

    if (WehJxXFSgSQn >= string("MTNhVoHWgcVVHPdBlFSPjhfPuMMjJjzSAPMRUSESFMcRmjeLuiNkcDXBwOGOOzBwmOGbMuWbWrGkzmGprSYFSh")) {
        for (int EQIqoXGl = 1058883987; EQIqoXGl > 0; EQIqoXGl--) {
            fqWkDlCc = gLbMoCe;
            RPKPhcatsclwXS *= oudwDILJnyoYamX;
        }
    }

    return RPKPhcatsclwXS;
}

bool GNJLrhFo::oRfNdyTmfyjBm(string AsvmExCIFnH, bool FTkWlAABh, bool lTKRvNhfD, string MbxUKjKJhMNAqGbD, bool rbVJdoF)
{
    double MblIK = 14335.384604718689;
    double KXEEyFPNvXO = 164891.77087406488;
    string XQgUILfLX = string("dhqvFmDJABhZbLzYNHHXDqWriGGEWSjkUhtZosMYMHyNqECKVzjbJNntFxoTLeOlfexDTNHSLbybQBxkJsqpPHQBeZOOejnfaotycdHZYnUaS");
    bool MrnIAjk = false;
    double KyWbpuIvvraIwEcA = 690670.4439566534;
    int HqAcJr = -2016703761;
    string Jkiqv = string("uQTJyjSmhaWCngAZFejdWNkRWRFigmSiqVAxdvePkreQzECGagEHxiO");

    return MrnIAjk;
}

bool GNJLrhFo::EBqbOgkhWyP(int akWjCQAraMOVmSpC, bool CohXThygpRt, int olHsNQzQIS)
{
    double QNumYDI = 556761.5646099389;
    bool mEEtjX = true;
    bool QrEbpcFKxXU = true;
    string OOXOnVp = string("FXQGhyKGGSjbuGyPZEVRfZlpjIzQZTOMKYdatBlKUaFlRlrmTLRgRuUDDuRysqEpWhRJJbXKgSJVipsfPHQplwSMyzXyRdUlzXmHxuOskyiOMLNQUkNwZacHAYPerinvnjbPAqGzHBTgFbWtrPRZMbiewnICBxIeoJdhOeaWhKuwBbGFCQSsHTUSHfzKFWsVAeneZXsqWnHBFTviLTXWUpJzZWvJrWoXejrmY");
    int HwGiPW = -2139299676;
    int zDZBXg = -1845265292;
    bool jgCNhGvRsu = false;
    bool YKdcIPzcuWFpQDe = true;

    if (HwGiPW <= -1845265292) {
        for (int CDUndia = 1768495188; CDUndia > 0; CDUndia--) {
            HwGiPW /= olHsNQzQIS;
            CohXThygpRt = ! QrEbpcFKxXU;
            olHsNQzQIS -= olHsNQzQIS;
            YKdcIPzcuWFpQDe = ! jgCNhGvRsu;
        }
    }

    if (YKdcIPzcuWFpQDe == true) {
        for (int wqfTcEnG = 1162768537; wqfTcEnG > 0; wqfTcEnG--) {
            QrEbpcFKxXU = ! CohXThygpRt;
        }
    }

    for (int pdDmGxlAXJJm = 743724981; pdDmGxlAXJJm > 0; pdDmGxlAXJJm--) {
        QrEbpcFKxXU = YKdcIPzcuWFpQDe;
        CohXThygpRt = mEEtjX;
        YKdcIPzcuWFpQDe = ! QrEbpcFKxXU;
    }

    return YKdcIPzcuWFpQDe;
}

void GNJLrhFo::WnRWUtqE(string bbBGQkvASX, int aSVBjXDtk)
{
    bool KDNRkjdvBV = true;
    bool adPhinHf = false;
    string UVFhq = string("HTyOxBBiBmzYvjVghiPHOjQDpLmUeoZjagYdLMMAAgbqxQWahRLYhtIMsYZdJAlcXvKNEFkgGarRfWXtmCdyeeUffDYbbjlSeFurITWFntPAqcyUtWYvjXgxgNpsPZKCAYvGXZKCQfSEMqqqpMpwxulixLTJKlpcAFsMsmcuEbdGhgqkhuCKjwKSmViojrlEcPrMndmkeJZcupfblWrimruUVp");
    string TSwNyvED = string("hbMfVITmbrYDmTJoiiEYhzrgzDubcXaStpRLGcFTsZGcELCqRvyKSFIDSxwkpRlvIsODveVufKgIOqAJVoUlWAmGjviTrMXvjMYfeOeKjAtpgEgLCtffiaLlJGooHJszYDTDYtyDvvpISrwiPYSxfjZvYJWQLzEadufLQVSsXHBdgoJInSfhvQMkgxihYfARkLxfrAYFWWQcgKPtvvqKIuGfxSptIBkZMqmxMEQiBXfwm");
    int unRHvZMEzyG = -182305578;
    int nyxpQjkhYemrFut = 496146504;
    double xVEEbiTUCRy = -799532.0048428873;
    bool cwbRL = false;
    string DebXHrAJMMl = string("zivbOtcBGkDqtaVDqxiajGWxsYcIJtiXPqFyTwXlBjqbrBRubdAHzMTCVGKDexXvTRcabjXLhDErOzQhacNldGxuGBItdhmwxSGhBYRyOqwvrxAjTfBDOwuGKAWvCosOtxAlNmQUyKuXIPfxkWWNZetFEloYWyPukOdjpCebIdrJXecGjgPKBCZBCpoLvltg");
    string gNLCpOfjF = string("TLbPFdZwtOlXblHbuCNXvSADoAFTkkkvhylBiewTKRkITJeoCEySPNdVQbWEJdOCujpHrokUUaOZMBCNMgtyVdOzUuCTaTHiXbagrcbLHywPtZPJLLPcauTIFwxyjPewRYsCjKDszNRXirtDleiLpJKaPamBsjxuYxRSDoCWOjDWogGbWjoRwgoXiAQOmtvhXxgYqFaJzwrDwSXXJENHtzcccJtxjhxgwBWdXa");

    for (int HEpYOipqUm = 847195687; HEpYOipqUm > 0; HEpYOipqUm--) {
        gNLCpOfjF += bbBGQkvASX;
        bbBGQkvASX = UVFhq;
        UVFhq = TSwNyvED;
    }

    if (TSwNyvED != string("HTyOxBBiBmzYvjVghiPHOjQDpLmUeoZjagYdLMMAAgbqxQWahRLYhtIMsYZdJAlcXvKNEFkgGarRfWXtmCdyeeUffDYbbjlSeFurITWFntPAqcyUtWYvjXgxgNpsPZKCAYvGXZKCQfSEMqqqpMpwxulixLTJKlpcAFsMsmcuEbdGhgqkhuCKjwKSmViojrlEcPrMndmkeJZcupfblWrimruUVp")) {
        for (int FdbKCBdOgLlsHK = 239774761; FdbKCBdOgLlsHK > 0; FdbKCBdOgLlsHK--) {
            bbBGQkvASX += TSwNyvED;
            adPhinHf = ! KDNRkjdvBV;
            TSwNyvED = UVFhq;
            aSVBjXDtk -= aSVBjXDtk;
        }
    }

    for (int gQtmpZAtI = 1148595976; gQtmpZAtI > 0; gQtmpZAtI--) {
        TSwNyvED += bbBGQkvASX;
        nyxpQjkhYemrFut *= aSVBjXDtk;
    }
}

string GNJLrhFo::mKtyFrlf(string kBleQeElEOWajjz, double FKLqRNLhf, string wFefSTwhqGx, string jcFhxKaZs, bool oOeRaJhPprZn)
{
    double KsLlQoSxjq = 1017703.409634904;
    bool cMNJDH = true;

    for (int UdDPoqSiwqv = 507718239; UdDPoqSiwqv > 0; UdDPoqSiwqv--) {
        wFefSTwhqGx += wFefSTwhqGx;
    }

    return jcFhxKaZs;
}

string GNJLrhFo::iZNwTs()
{
    string KYKFOsfusrUwqiua = string("AijslYqntQERIWxuZubjoSWWozATEaJchTcXefJoQvNZDlsXkGlLefqCCcKKEApaaBxCBGHavXPcqGnAalEZnGWKFVYgFmcNjrAtXyioIxJnyuOKbvkjfArAsRHOkyJmHcfIjOLmgEANwHUJldTFGnAsYAyFPxWJmlQLUoaisohLdBKcMPkwJbgrakrraBLSFa");
    bool YxOvPxsxCBUZ = false;
    string sywvZYDzsYX = string("fpqYuwqxexNNWBIncykqYMLWcCGGMBCHaykOaChtrtMUNJYsfLDnlYEvMAcPHWZRllMkgOOVRutENejNUKSPYvtstWFKCKIpSDlpXxzvuPuleYEuBEwVAoNSi");
    string GImbwq = string("rIEmclfobTGqJVkUTLDYoZjoEAvxAXuEradpLlGzDoOMBaPvTTIOrgGbUilhwyGWfoRPSspYBcOUiikZAGIPVCtkXlsCDZRLAjwwmpjHLiwNlIOHLhwCWumnPwbVhAlNhGFyEOacshMjAqLXJeBcyQryCZSWdLdqaFxjtiCKCZBHLgNzFfpeYAZoyitacpiOLlWXposrVRBoWIvdHZEphVdkGVojalyEWZIySQbatiSwRTizrGljjRadxhDd");
    bool SIikQOGehp = false;
    double nzIENzS = 798366.1611614478;
    int TsfGSqLzBH = 1014390217;
    string yBGZEnaCHK = string("GKGtvVzUdZTlDPrxyYFHFOoTdhQpOYYMDpiqHouSLAkChcRKqHimLJIiKxzcvndHFDndksSSysZyhRaQKEiwNGKbDSUZCMDINiPOPKHHULTvhFvpHKUErvqzDrKMCfVcHrAirpsiNAXZknEmVyxREjRPzxmmtrRYLLEqeSkBSQlMVikyVGdBovAtfsohugBEv");
    string fWiUVCq = string("HuENxroqzlSLRwpMVkLJrSNwIYmpI");

    for (int cYJWVkmS = 1476777348; cYJWVkmS > 0; cYJWVkmS--) {
        yBGZEnaCHK += KYKFOsfusrUwqiua;
        fWiUVCq = sywvZYDzsYX;
    }

    if (KYKFOsfusrUwqiua <= string("AijslYqntQERIWxuZubjoSWWozATEaJchTcXefJoQvNZDlsXkGlLefqCCcKKEApaaBxCBGHavXPcqGnAalEZnGWKFVYgFmcNjrAtXyioIxJnyuOKbvkjfArAsRHOkyJmHcfIjOLmgEANwHUJldTFGnAsYAyFPxWJmlQLUoaisohLdBKcMPkwJbgrakrraBLSFa")) {
        for (int cTlUrHulvNXsuXeM = 131062458; cTlUrHulvNXsuXeM > 0; cTlUrHulvNXsuXeM--) {
            SIikQOGehp = ! SIikQOGehp;
        }
    }

    return fWiUVCq;
}

double GNJLrhFo::wMYeP()
{
    bool JKSPOZGwjH = false;
    double xGNrELyAQZE = -153376.22069420558;
    double QTdjXtyKsU = -153531.5605974718;
    string zZlCBAQ = string("ACzlhZamfSoKoVGPsbNELtAWXBAGzpwQcNWHe");
    string sCeJiwLoe = string("lChBWXAtqjWJLPJxNqnIzPdhaqCIOPPSTbT");
    int jZrjdJVTg = -1589793260;
    string sLEECXOsGXJLBMC = string("gXkTkjqbRDdBHvMTVDzLyYeCqAObAxoadTqjYupfFWCjOZtXjgKHRfTvngNQOumPhDWFevJZquPMPDdWFytcpAAzXRBoywLyTMEGJIskTVuJXzWmmdMKCVQQFQeDoOTRuPZtLsKzjGiTmNnjIFChACoORbVnofmiUzOqKO");
    int isCGHnbqPeIwS = 2009323386;
    bool OTOkVciPrXKWZUj = false;

    if (isCGHnbqPeIwS != 2009323386) {
        for (int WvKSYwdxdDb = 2086615912; WvKSYwdxdDb > 0; WvKSYwdxdDb--) {
            sLEECXOsGXJLBMC = zZlCBAQ;
        }
    }

    for (int VbbRKNyAIy = 48927678; VbbRKNyAIy > 0; VbbRKNyAIy--) {
        JKSPOZGwjH = OTOkVciPrXKWZUj;
        JKSPOZGwjH = JKSPOZGwjH;
        xGNrELyAQZE += QTdjXtyKsU;
    }

    for (int MSdPc = 1696820074; MSdPc > 0; MSdPc--) {
        continue;
    }

    if (zZlCBAQ != string("ACzlhZamfSoKoVGPsbNELtAWXBAGzpwQcNWHe")) {
        for (int fVxrHMFRDzD = 2097035857; fVxrHMFRDzD > 0; fVxrHMFRDzD--) {
            sLEECXOsGXJLBMC = sCeJiwLoe;
        }
    }

    if (isCGHnbqPeIwS >= 2009323386) {
        for (int xVYjBVJAwrdqeShF = 2124495163; xVYjBVJAwrdqeShF > 0; xVYjBVJAwrdqeShF--) {
            zZlCBAQ = sLEECXOsGXJLBMC;
        }
    }

    if (jZrjdJVTg >= -1589793260) {
        for (int FlBbjncmAqbZrj = 1895364357; FlBbjncmAqbZrj > 0; FlBbjncmAqbZrj--) {
            JKSPOZGwjH = JKSPOZGwjH;
            zZlCBAQ += zZlCBAQ;
        }
    }

    return QTdjXtyKsU;
}

int GNJLrhFo::nFrAmDoEwaVqVwnR()
{
    int BYbxeDW = 995559191;
    int AIbdRllBdCLhj = -1715757254;
    string KrGPOlxTl = string("qPVOcCRmMCuiZSlAjyHmMlWyiuGQeAnyomeAnL");
    int zzwnMBYYtbfaYRBN = -865490606;
    string mNXEK = string("tuuNjPbSdWFlxzhUYVCKSdWFaxrzNGGPjRakpvRQiywItUATmswFhTbTAykaHLRGVRYj");
    string msfZlzPlRbdJK = string("OMrTcQTUhgyEKsouegqensVjxrgCrNpdhDdLpVXgzEiMmLSohaYvUZcbDkXxeMnHbWBznhwlkgCfxtxCsmGqbIzLwfoUZVLeOddxeMSLAoMrPxeOIbvXUtzYNfRjvekjzLieDhHhczYCZOgNxUTlSGsvlLzAIWOqyje");
    double ZjkRN = -1042546.3238809656;

    for (int uGZQlnbpdJqoDEkx = 1692888633; uGZQlnbpdJqoDEkx > 0; uGZQlnbpdJqoDEkx--) {
        AIbdRllBdCLhj -= BYbxeDW;
        msfZlzPlRbdJK += msfZlzPlRbdJK;
        mNXEK += mNXEK;
    }

    for (int uoaYfDLQNSGip = 346359858; uoaYfDLQNSGip > 0; uoaYfDLQNSGip--) {
        BYbxeDW += AIbdRllBdCLhj;
        zzwnMBYYtbfaYRBN /= AIbdRllBdCLhj;
    }

    if (AIbdRllBdCLhj < -865490606) {
        for (int CBqBzijnNop = 710787907; CBqBzijnNop > 0; CBqBzijnNop--) {
            BYbxeDW /= AIbdRllBdCLhj;
        }
    }

    return zzwnMBYYtbfaYRBN;
}

string GNJLrhFo::CEDtBjbSBY(int UkSVscwwCdj, string ROorWpkppJI)
{
    bool upTgFJsI = true;
    string FuSiRLqGuIStEx = string("UdjIBwMcPYyQazFZqfHNMDajwOuwsVHgOpZzrnyRXoyHSDEqbawQJsucaoIgWUqBPHjWHDelKoInNtHLCgIGbSErhNuXEeZdVfDrmpwIqcHPMRuOxpoKxTEYZcohrIuwjDDaTxgpVOgumhgGhrGPmzjlkhjXBphWkvGwUEOf");
    int aqAgxIw = -183963295;
    double zUOeoxxtcuEAX = -325604.54138123617;
    string nkcXpZHNwPa = string("wrcMtQMJRlPJZIgSdmcQjDDvONOycAPGiBjdGPKhrSAnzRPpaTPPawVHGJsUVVzVuQrmGRZXfgaWnvlFfEmwUQdZIbeDXinxlQYrzhUYHGRBkRJlxzXGKJKPnbifrTfjsfFGqfGSSOMpSyOEwEJBAhnhvEwEQLPvUWjewDBNWIIRXxuHfOsoVXzHVsUZzDZWotlRxNmrjzZlQYZhWKhZiJabUBiDFWQYMWHbliFFH");
    bool LYQwcRQCww = false;
    int qYLAdakb = -1422097725;
    int UnTNqIoEMBjgCz = 761529282;
    double QxvekeMo = -912591.658190492;
    double GyyefDxF = 181246.0843811441;

    for (int rhtDDTA = 1022526820; rhtDDTA > 0; rhtDDTA--) {
        aqAgxIw /= UnTNqIoEMBjgCz;
        zUOeoxxtcuEAX /= GyyefDxF;
    }

    for (int jjuVwgrKcZUwGD = 1909433191; jjuVwgrKcZUwGD > 0; jjuVwgrKcZUwGD--) {
        continue;
    }

    for (int xxmtHOTmrtcf = 2007246052; xxmtHOTmrtcf > 0; xxmtHOTmrtcf--) {
        GyyefDxF /= zUOeoxxtcuEAX;
    }

    for (int TJkbaX = 1942659661; TJkbaX > 0; TJkbaX--) {
        continue;
    }

    return nkcXpZHNwPa;
}

double GNJLrhFo::UiTsw(int DknNWBKSIIAPHh, int JtTvpxGJKUbG, string YSfVqM, bool lZggHibZKite)
{
    double ohkqqacpggYO = -292426.4680303872;
    bool DZdwhdrMjJOgDy = false;
    int lnqljV = 908992566;
    double HthUDrZEU = 528263.5573909421;

    return HthUDrZEU;
}

bool GNJLrhFo::eykUDPQxnmPT()
{
    bool mFgXyXRM = true;
    bool LmWufw = false;
    int djJFZ = 191712179;
    bool cnpcQ = false;

    for (int RzPrlSWNEVjs = 1928103650; RzPrlSWNEVjs > 0; RzPrlSWNEVjs--) {
        cnpcQ = ! mFgXyXRM;
        mFgXyXRM = ! LmWufw;
        LmWufw = ! cnpcQ;
        cnpcQ = ! mFgXyXRM;
        cnpcQ = cnpcQ;
        cnpcQ = cnpcQ;
    }

    for (int XhQCOIpr = 1512330729; XhQCOIpr > 0; XhQCOIpr--) {
        mFgXyXRM = ! LmWufw;
        mFgXyXRM = ! LmWufw;
        cnpcQ = cnpcQ;
        cnpcQ = ! cnpcQ;
        cnpcQ = ! LmWufw;
        cnpcQ = ! cnpcQ;
    }

    if (cnpcQ == false) {
        for (int loqVyiX = 1186554679; loqVyiX > 0; loqVyiX--) {
            mFgXyXRM = ! mFgXyXRM;
            LmWufw = LmWufw;
            LmWufw = cnpcQ;
        }
    }

    return cnpcQ;
}

GNJLrhFo::GNJLrhFo()
{
    this->gegPcXLfpR(987390021, 958925168, 1989140500, false, -299699429);
    this->tHXGobIGEBDapiwG(string("KouKortvllgupHfdZMAsNJjtnhOrCcfmcbNatCCMFzeZzjnFRwCtqnosgZqfxmRrYARXvhBzcDyBeLeRYreAfjaBcrgLorOgDkZBkcDszxulycVtpJdwsLnMVowkbkKfndolRJcjZkaerQrSDkNsrfsQjGzWYFRbqZhMjrIvSAuVnORZUET"), -1017242.8757783342);
    this->hsNTayFNNqU(string("lpCVJWCvGghDAZRRvwjJpjRRjiLiksIeJBtFJDrMRsrChLuirVZmcdh"), false, -1023408.2927180325);
    this->HhxrfuS(string("MDTABanMPHEfJjKAftezrwbgRoSIBYQRSoTYUoUbGkllXNuwTrIiHEXUdTWAecxuliAcgbjk"));
    this->DwzYPd();
    this->lvStbdYvqQ(-1030481.8424878578, -571742155, true, -639774.0016437275, 793054.1650692156);
    this->EOaLsfSL(1696231370, string("OXgHFajTryvPkIIKqeLNYUPjYGnZfILRkACOEDMsPPojxxoeyYyTvUEsgMotEhCGOBSSHjCbJIojtIRqiztNytnOeirSephboniSHYkCjySQvzKzFpblLOUAAarNJwoNpdMNJQlqZjyzSUEopBzbEdFEIl"), false, 558979.3682809448, string("VhQDuHcqRSansqxyKfGgpedUJrlSFMLGwukjclahKMgqXzdnSGbnxmEUKldusFXowVffIsDsZuqBGPMzlPQnocfYdrALCMYERxgRiYAwcEpXUZydpYDUyVepOZLUzpHGqeONaNyRdoWooSyqcUsSezGpiLbsQskbzBoNPZLDQfIJGNGOwUJGWvoAIsQgZPBpnNNXZzDGxUEurlsYyNKwWvxGXPpEeFJNkBqgCo"));
    this->oRfNdyTmfyjBm(string("FuoeUimyBrQfftYNWUoOdldsDJCuzoepJiPRkFGfRHVwBthXbyfRSrJIChewFBBTDlolPEclczWULmpgXgmbBZKMeXdZXkLXRhkqslBDOZACfgDvfFDodWGawGhU"), false, true, string("CxevlNCkiJtyWTUNFFLMCDXkpgDMqMaYhZBpzGmGMtZzAcLFzXpNRTNofDcNeIvOGjUjVPWVDBNahNqjmpKwsDOyJtxziwPePAFTytYhIOlwwmxvRxPPydVGmXIswhgseSXMznFUXbvRGpYlunGtdiCbgfszdwJoGOKsjKEaJhJIYqiHduOZcmzfLFWqYJRjjMEmiZwfMZwkL"), true);
    this->EBqbOgkhWyP(-41144670, false, -1053320053);
    this->WnRWUtqE(string("oLQIucWUTTIguTzEFILKXzMBTukYZjruAJkDCOOfdgOMyJaSuISIAQhUZgzRYkYRMJeoETQFHztUUHSVMpdxUMLtBmWCHWWvNrqPaSyiCWCEzDuYRLvdhAXDUjlRhqBRt"), 1661557337);
    this->mKtyFrlf(string("aMDjnicUBUYWyhLpTHrBRckjaXypXwCFAMRoquMXbHgqDMKknCPIiTnCYGoqBzAgcATKmtcwVClyeTkcysyxDXheeEkZphsVyDytZlBGMQjCovbhUUcmYsARLfTnnoDLRZvqtvIUjXgdACpXnrvsaPsHUsOdpcPmRQSZwCivjgZBOfmesWcWZEUBoyRfWFJxXrmMXxPiBAJltjjQIZfhSOijjwKhvsDXiakOWOkVpCvRWnjYbrtPMH"), -307679.1178955255, string("pGbvVTOQlPTCALCcasGAaMJJWBHMelvYUKmKXpCpVcRQXPhjefNlZfBFjqfRPDotYcvgLDdpdEcofLiZPLysMLNoiKkPeGN"), string("uOCesGeTUwJcmKTTAonynzXfDgHfwIcmhVYiFOTemzMTzVuPnPaMseSscdMgDSBxCjvifruZjuHOlXctNsRbacdsJfTgDMjvdkmHrNfCkrGMploPdlOSbAckLnEvdshwOXeqqrLiEmVJJTW"), true);
    this->iZNwTs();
    this->wMYeP();
    this->nFrAmDoEwaVqVwnR();
    this->CEDtBjbSBY(1679313753, string("NpuKTGsoBhobMpvfUyoGrmph"));
    this->UiTsw(1737670362, -1352005860, string("wtIiFEqjRGDhbOXVWHUDIrZmmyEVoHDuHaJDEgGdGgepgzHQjQjnnXdKmXTMNNQNkukfbogBVBkURStYeWySWjIiVnOTZQdkQmZzzyBwkBuWYLxeeHXAFUwVzqkDjVdIutfBVbiledpuHczJQWOumSiQemPIlJhpSvlxVcQILcMHMLdhahkzWmdYfFAoVlmwSIVapO"), false);
    this->eykUDPQxnmPT();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PdcXA
{
public:
    string awtXraElm;
    int qZFLaecWuM;
    bool EkodBec;
    int qSNAa;
    int AMfeh;

    PdcXA();
protected:
    double TfwNTtB;
    bool AnLWhRCbgfjo;
    double srJXS;
    bool zCZLURMzAfD;

    double mxxJO(string qAAEGMhJDNeAKQLl, bool jWQeuVuCyDmcNIG, int KdbvKWbbQXgbM, double GdniBlbRGrcMzLg, string qspNJ);
    void MaUiE(string qmjnMj, int kaCHPhprzrz, string yBfiT, bool YmvyeFUXotdZEvU);
    string uCaXhWpNPXxGZF(string ZmVJrsIphCSP, bool DxKHjTdNGmOZgd, int xfcxSvIeLbOcEeui);
    bool QwAwAYZa(int slHPIsrKWZ);
    bool VzdWhiADN(int WfRYj, int LQEkAThhuuSkJ, int zeUJJOIMQR, bool bioOYLaQuTGZAzrJ);
private:
    double wnEHlZkKxu;

    double lmwmTIYjSAShZRgs(double VtiaceVwSrTV, string frhoAQXkta, int yXstWJRTwBTEdJ, string pHvxkqEi, bool LeBLJucIqCOW);
    string nyiUl(bool vqUcNPIknDBX);
    void FuqhC(bool nanPnzrHQlDeMN, bool ndetsLpUbXHHyUt);
    void weIapRruyfPdPGg(int mdsMe, double FLEYOusbmmfSHL, double RiPDIsVWwawZQpej);
    int VKMQXuzvmE(bool dHKnMStrIQH, double UbuQXquukaPgAGw, bool ERWVErXDFXQovN);
    void TJmNkIAlxC(double pXeKE);
    bool zbkakdPvA(double vHycPXKduG, bool ccvShpyocsj, double mDXQwnrGXbFY);
    string SJtybdwZ(int gHVHLYYOwiT, string TJuwwJUDANdIZ, bool TRHylWNJpo, double YfjyoKeLzZqJuWq, int CjVNXKZjsFmmyK);
};

double PdcXA::mxxJO(string qAAEGMhJDNeAKQLl, bool jWQeuVuCyDmcNIG, int KdbvKWbbQXgbM, double GdniBlbRGrcMzLg, string qspNJ)
{
    double OSoCW = -301424.5680653077;
    double ZwrzUIqnhQHsoYZ = -751441.77797699;
    bool ZsYxCrbVgTT = false;
    string oxOWMeIudrdsS = string("RcjFhmwJpzwRQVJFLizolQgKkyfDwcfnZyNkYazLBTwIG");
    int xhpCpZ = -1066190292;
    bool VohFiFb = false;
    bool YawmS = false;
    bool qHUiaCAkwYVJ = false;
    bool ZxzhehDK = false;

    for (int zMGZdjkwLtSsHS = 599048793; zMGZdjkwLtSsHS > 0; zMGZdjkwLtSsHS--) {
        continue;
    }

    return ZwrzUIqnhQHsoYZ;
}

void PdcXA::MaUiE(string qmjnMj, int kaCHPhprzrz, string yBfiT, bool YmvyeFUXotdZEvU)
{
    int qKWcp = 813395238;
    string xXNqXJePMBzw = string("fILumgBltJBJHQiDyrWtiSYcgKXdIKczIlksARzMcPde");
    double bmNpSoE = 935254.0557897157;
    double dKzxnTAD = 292532.3394492833;
    double bKSKGyoFOAYI = -205011.16607838907;

    if (qKWcp != 1002745731) {
        for (int vtvAvyEPcRQBBa = 1785751521; vtvAvyEPcRQBBa > 0; vtvAvyEPcRQBBa--) {
            YmvyeFUXotdZEvU = YmvyeFUXotdZEvU;
        }
    }

    for (int NjcGlbAAqCBNKhAE = 1614512932; NjcGlbAAqCBNKhAE > 0; NjcGlbAAqCBNKhAE--) {
        yBfiT = yBfiT;
    }

    for (int sTJNFgjG = 174793054; sTJNFgjG > 0; sTJNFgjG--) {
        yBfiT += yBfiT;
        qmjnMj = xXNqXJePMBzw;
    }
}

string PdcXA::uCaXhWpNPXxGZF(string ZmVJrsIphCSP, bool DxKHjTdNGmOZgd, int xfcxSvIeLbOcEeui)
{
    double EjxhyD = 645267.8002975099;
    bool wguDWNDVZXHFxMkD = false;
    double DEpsuVXgbow = 420343.3109327589;
    int XcEYO = -174512149;
    bool cYNBNNUdlqSMCtx = true;

    for (int ABQLkd = 497031734; ABQLkd > 0; ABQLkd--) {
        continue;
    }

    for (int cGaHw = 556826428; cGaHw > 0; cGaHw--) {
        DxKHjTdNGmOZgd = DxKHjTdNGmOZgd;
    }

    return ZmVJrsIphCSP;
}

bool PdcXA::QwAwAYZa(int slHPIsrKWZ)
{
    bool GJewPYBiuxrBiURf = false;
    int nIqApYCwYyve = -1528483310;

    if (nIqApYCwYyve != -1528483310) {
        for (int oTKZLAXkMNtuqnO = 816359279; oTKZLAXkMNtuqnO > 0; oTKZLAXkMNtuqnO--) {
            slHPIsrKWZ *= slHPIsrKWZ;
        }
    }

    for (int VBzJXDKvpmDTVCCU = 2081201446; VBzJXDKvpmDTVCCU > 0; VBzJXDKvpmDTVCCU--) {
        nIqApYCwYyve -= nIqApYCwYyve;
    }

    for (int qnndGYq = 1193930290; qnndGYq > 0; qnndGYq--) {
        nIqApYCwYyve = nIqApYCwYyve;
        nIqApYCwYyve += slHPIsrKWZ;
        slHPIsrKWZ += nIqApYCwYyve;
    }

    return GJewPYBiuxrBiURf;
}

bool PdcXA::VzdWhiADN(int WfRYj, int LQEkAThhuuSkJ, int zeUJJOIMQR, bool bioOYLaQuTGZAzrJ)
{
    string XUsSjDJ = string("kEKGkGYeUPfIhWNasqJSj");
    string NAYpvPUzp = string("FCVGMVYvafvlqoldHEbOlajntkviQLbPADcSKdYzrBStuanPIQLTqojPsiXgSzHMMilsAvxzJTkizarOSisYhweYRYKfMvWGRFbsqDIJGNpniKyXfQuRCQAUiAnLBIPF");

    return bioOYLaQuTGZAzrJ;
}

double PdcXA::lmwmTIYjSAShZRgs(double VtiaceVwSrTV, string frhoAQXkta, int yXstWJRTwBTEdJ, string pHvxkqEi, bool LeBLJucIqCOW)
{
    double iNPHRfGSvi = -830698.6531341863;
    double oBkeWktz = 837141.8865523158;
    int DaVLUO = 145097238;
    bool DORyyqEycEfohzEn = true;

    if (LeBLJucIqCOW == true) {
        for (int DbbfHodKI = 1136758030; DbbfHodKI > 0; DbbfHodKI--) {
            pHvxkqEi = pHvxkqEi;
            VtiaceVwSrTV /= iNPHRfGSvi;
            LeBLJucIqCOW = DORyyqEycEfohzEn;
        }
    }

    for (int UYnZl = 837740643; UYnZl > 0; UYnZl--) {
        iNPHRfGSvi *= VtiaceVwSrTV;
    }

    if (pHvxkqEi == string("oNAtZoDGWVIuiwIRnHIJXlsPVwsuuODRyZwskiGogxeDrZHomIcEMQJoGaEgPlCArrkNnPXtDxjvtiwtAmSdLrVZtnYuxKGYVjfnZscyJGKkRzKcgoaZzxWrFIDwWwnEWMosQSIYbgAtzjosamzxIjeWIPyOvpTKlzrlMaAtfesFVyLcyqSWeLXlIennAilaJYJgrJl")) {
        for (int ufBoPwYRHi = 1642750221; ufBoPwYRHi > 0; ufBoPwYRHi--) {
            pHvxkqEi = pHvxkqEi;
            LeBLJucIqCOW = ! LeBLJucIqCOW;
        }
    }

    return oBkeWktz;
}

string PdcXA::nyiUl(bool vqUcNPIknDBX)
{
    int IWKOFzawn = 665333483;

    if (IWKOFzawn <= 665333483) {
        for (int EVXsaIkwbFtBby = 804833695; EVXsaIkwbFtBby > 0; EVXsaIkwbFtBby--) {
            vqUcNPIknDBX = vqUcNPIknDBX;
            vqUcNPIknDBX = vqUcNPIknDBX;
            vqUcNPIknDBX = vqUcNPIknDBX;
            IWKOFzawn -= IWKOFzawn;
        }
    }

    return string("GccBcKbanQTgclJKYQuofFXmTaIVkdAhdYBQflCcfQPUQexjgcPHesfcBeDVyZEhiyAqfFxCvEtoKMisNlbHHdWBkmmEAwreidCSQNBLpoUfwNXeCHNDmRxfuAuRxZSaCHELBijPWiZqgSmZsfzuiqOwLMSxpdWwBqcIEYzaiKjpXkLluvuqjANJJbdGrCKhIUHJonWPWKcKuekwtCipcpVEpgpmhzGNsmuVFaRlu");
}

void PdcXA::FuqhC(bool nanPnzrHQlDeMN, bool ndetsLpUbXHHyUt)
{
    double tmzvYfKQbd = 730364.3490577013;
    int CvFCidZGImtjS = 1166021341;
    bool DocEvjicXUr = true;
    string tGFepakYL = string("noFbrNwwEycUumcerTAZSECgMvFbyELbzbsFAVZbuUsRzhGREUlJbALTEAcVzDxTDNmQPDcVGMjQmDCGDrCmQAfMKeMeLSVhcLcAgDoizZFxEShNOmWLKwprABRxmdUKYQrKUgDzUJWyArINwpneikZYOHLSlmoAJeDFZhBSeXnIBaJgIUdHXtUhYXceCQmDcINSuaYralQQjQlIwHPbEEsGQGdjxTQmGDYBrgKaSPpXQdcq");
}

void PdcXA::weIapRruyfPdPGg(int mdsMe, double FLEYOusbmmfSHL, double RiPDIsVWwawZQpej)
{
    double ItzHUeU = 268328.49597828556;

    for (int rLRTVQrdgOjGB = 193137807; rLRTVQrdgOjGB > 0; rLRTVQrdgOjGB--) {
        FLEYOusbmmfSHL += FLEYOusbmmfSHL;
    }

    if (ItzHUeU > 268328.49597828556) {
        for (int kiNbkJKCewv = 517569574; kiNbkJKCewv > 0; kiNbkJKCewv--) {
            ItzHUeU = RiPDIsVWwawZQpej;
            RiPDIsVWwawZQpej -= ItzHUeU;
            FLEYOusbmmfSHL = FLEYOusbmmfSHL;
            FLEYOusbmmfSHL += ItzHUeU;
            RiPDIsVWwawZQpej /= ItzHUeU;
            mdsMe /= mdsMe;
        }
    }

    if (RiPDIsVWwawZQpej < 165252.63719815132) {
        for (int RHggsQhLLSlnQs = 904844335; RHggsQhLLSlnQs > 0; RHggsQhLLSlnQs--) {
            ItzHUeU /= RiPDIsVWwawZQpej;
            ItzHUeU -= RiPDIsVWwawZQpej;
        }
    }
}

int PdcXA::VKMQXuzvmE(bool dHKnMStrIQH, double UbuQXquukaPgAGw, bool ERWVErXDFXQovN)
{
    int CuGIRwQd = -2083811274;
    bool YVcbmDHSnlp = false;
    bool kLNBGWdsCLno = true;
    string bLIuSg = string("PxzzKFuXoeaKJynVIFfSgJVIbUpvvWjXBcYCdjMgkVQfbCnAoRNXQgTlRFtmccUHBWtWyOMfWIKkvXbUGozAjjVCbjDePfYYAQNdlGjUSdUfVxcKMVINAZSbdvvmLMayEfWxFWEffyKwLTvymsvNgGkbTmDWvyhlTTkkCYJA");
    double WPAfSCN = -994261.7823481554;
    int BMHzwNIk = 1995931610;
    double cVWeevT = 751774.2357833365;
    int szJYYpvhGS = 649999757;
    int dcDGXTk = -178840619;

    for (int KOVFUPggFN = 306505253; KOVFUPggFN > 0; KOVFUPggFN--) {
        WPAfSCN -= UbuQXquukaPgAGw;
        BMHzwNIk /= BMHzwNIk;
        CuGIRwQd += CuGIRwQd;
    }

    if (BMHzwNIk >= 1995931610) {
        for (int ySDNHfcAtGidIGf = 2084342175; ySDNHfcAtGidIGf > 0; ySDNHfcAtGidIGf--) {
            BMHzwNIk *= dcDGXTk;
            kLNBGWdsCLno = ! dHKnMStrIQH;
        }
    }

    return dcDGXTk;
}

void PdcXA::TJmNkIAlxC(double pXeKE)
{
    string SMJIEsq = string("mdXlRFVKGctnfIqGCUWYdHBOChFZqLNZBWvDvMYoTkmVyRxNxfvOuNYnzfksZMCKvze");

    for (int HBfplKCn = 1333473557; HBfplKCn > 0; HBfplKCn--) {
        pXeKE *= pXeKE;
        pXeKE = pXeKE;
    }

    if (SMJIEsq < string("mdXlRFVKGctnfIqGCUWYdHBOChFZqLNZBWvDvMYoTkmVyRxNxfvOuNYnzfksZMCKvze")) {
        for (int KcZPZlXOvPodkn = 558463315; KcZPZlXOvPodkn > 0; KcZPZlXOvPodkn--) {
            SMJIEsq = SMJIEsq;
            pXeKE -= pXeKE;
            pXeKE *= pXeKE;
            pXeKE -= pXeKE;
        }
    }

    for (int KdVSl = 1485738221; KdVSl > 0; KdVSl--) {
        pXeKE = pXeKE;
        SMJIEsq += SMJIEsq;
        SMJIEsq += SMJIEsq;
    }

    for (int rtOmHxy = 1405160982; rtOmHxy > 0; rtOmHxy--) {
        SMJIEsq = SMJIEsq;
        pXeKE = pXeKE;
        SMJIEsq = SMJIEsq;
    }
}

bool PdcXA::zbkakdPvA(double vHycPXKduG, bool ccvShpyocsj, double mDXQwnrGXbFY)
{
    string lVFRyuMmxJilNm = string("dSSRkWWdUyJOsvBlkWBlJCulqVnqAhCiuSiZUvqcNVmdlsZivLSuPbPpNdvLEvXsLtrmTEONAHxXUHRvoqzfbkPawpxwDeUapaNPTDVVdsIVztqjkGfnGStQRZJbNQFaDhweSlbSaCjcdIWYnDYDj");
    double EnANbDhpV = -53927.06823471649;

    for (int SYlwbnINh = 1768352884; SYlwbnINh > 0; SYlwbnINh--) {
        vHycPXKduG *= mDXQwnrGXbFY;
        EnANbDhpV /= vHycPXKduG;
        EnANbDhpV /= mDXQwnrGXbFY;
    }

    return ccvShpyocsj;
}

string PdcXA::SJtybdwZ(int gHVHLYYOwiT, string TJuwwJUDANdIZ, bool TRHylWNJpo, double YfjyoKeLzZqJuWq, int CjVNXKZjsFmmyK)
{
    int UWhhIsxXu = -852975918;
    bool YCPGBAQquWK = true;
    bool TNEDfPwHMqoFm = true;
    string saVmjwcZJDJ = string("FSEibSmozdMILNBgZJrVCQVbetdusSwKzUAEiASWehsoSavObPWqpsXhbkxFRpvdlikeIIZIUZTwNruvoBOlNeZmgsYDlByWSkEExaAQhEYJdaZiGqxpKbmbslxyNkZDDxIYyRLC");
    int TkkbDLnHaGRvK = 1225447173;
    bool BbZhXYMZN = true;
    int WPyHDeheVBheTId = -1578696821;
    string QCyrmTfW = string("ytXIYvpartMpOWuNMJsTqVyNtLaslnsQmGFHIGLcBAcDSIbMhhqFYfgPwrAJuYeGsVHjhDzRqKNBiDNAqqvfCGIVxapfQrJTDPqKuAVpQzxOPNJsixIboQvlWKpKsirTDNLwPHEvgWaXdLtehXcTrGQGKReyRpyrGcaCWpQSMdIuiwE");
    int DgDmiXv = -513122990;
    string dOZWjSPxdKXmT = string("avHMQDZgwdnPveWvx");

    if (BbZhXYMZN == true) {
        for (int rylrDivabyN = 916536669; rylrDivabyN > 0; rylrDivabyN--) {
            CjVNXKZjsFmmyK -= TkkbDLnHaGRvK;
            TkkbDLnHaGRvK = UWhhIsxXu;
            QCyrmTfW += QCyrmTfW;
        }
    }

    for (int VUXcbieMk = 10620658; VUXcbieMk > 0; VUXcbieMk--) {
        QCyrmTfW = dOZWjSPxdKXmT;
        gHVHLYYOwiT -= UWhhIsxXu;
        TNEDfPwHMqoFm = TRHylWNJpo;
    }

    for (int SusOWF = 2031100605; SusOWF > 0; SusOWF--) {
        continue;
    }

    for (int HclQXMA = 1465214472; HclQXMA > 0; HclQXMA--) {
        CjVNXKZjsFmmyK /= gHVHLYYOwiT;
        TRHylWNJpo = ! YCPGBAQquWK;
    }

    return dOZWjSPxdKXmT;
}

PdcXA::PdcXA()
{
    this->mxxJO(string("XiVzIqenNOZlWWUylqwlNFrMEDKRqK"), false, 1722743333, -805902.5441582933, string("BBdIqUjidgnQuSWeahTGMPaDxYegSIypPjmdGPRpXAgWTiAfqzZjHWQsDCOWwOXVVzplMufWEGZgZfCppZRqqPsJNhCCJvcEjzXlWm"));
    this->MaUiE(string("wJhGNREgIMdZQdngWiRJBgwBLPYPfXCFIfLTJkEHwkZFfchukThFSVIhLEtdtluNsXjXhvvDSPiPrBvLICnXacLHQSHllzLhpavoAFOcJcnoVwQBGddxszLIcBuPMEJZQXiSfjMVwpgqHmxoeceuPwmbKszJSlquMmBEUYqaUxTeXtcXCxolAROovrMqtMfJFozWDjQTQrfIGvtiMGEFBGPQjlGSeZt"), 1002745731, string("tGNXDdyavoBieXYXIZlcpfNrhtNHlLicUFsbcVJJCxWsDMoGTPyFxrxHfBwCeygtTvqjmpkgtCMssiLHpbNAOGvUhEikQquHZyUIKXadIvWFHUkSqmFQjrdqkZuvxjthevdveUHZBjIVGAJwlYr"), false);
    this->uCaXhWpNPXxGZF(string("VWBtZsWunKVtBhnFzzpJsBhnfeKOwMqWrmQqGPzquWiHZXHWjDeEZWTGocPbxdyPFZAwdvNy"), true, 2083618204);
    this->QwAwAYZa(-157467613);
    this->VzdWhiADN(387251382, -1044685147, -219673439, false);
    this->lmwmTIYjSAShZRgs(450789.73549733474, string("EWZhTihUKzUZdkxhfwicPjgPHUbzKWKTwuihUWDKkupdZGxwrobafFuUjiwdGntctPuFZVnokwZZffnBIFvmbjpsOwQVxSGKxEBanYsWgoRQIadTIftchSoGKHZVgoTRpAwhuURgaQIknfBtSDIJZvBKJhIpZDxTTyyAmzZ"), -2108971168, string("oNAtZoDGWVIuiwIRnHIJXlsPVwsuuODRyZwskiGogxeDrZHomIcEMQJoGaEgPlCArrkNnPXtDxjvtiwtAmSdLrVZtnYuxKGYVjfnZscyJGKkRzKcgoaZzxWrFIDwWwnEWMosQSIYbgAtzjosamzxIjeWIPyOvpTKlzrlMaAtfesFVyLcyqSWeLXlIennAilaJYJgrJl"), false);
    this->nyiUl(false);
    this->FuqhC(false, true);
    this->weIapRruyfPdPGg(-31729070, -425563.92342371464, 165252.63719815132);
    this->VKMQXuzvmE(false, -392398.43459584983, false);
    this->TJmNkIAlxC(-184358.21490197396);
    this->zbkakdPvA(-80161.92661877247, true, 551503.012513292);
    this->SJtybdwZ(-1859878064, string("eClJyaDAVKgqmDUsKHoPrArlmdMXkPEIQPklLquTiSCumTxMbAOHmdZGImiKpwzlilxUQicqciUxuUvjzXdbZGHcjzGKTdiVLTlHHOjiXdzqVwbrQZjpNnsQweOOnRKWGinuzBgvBCJFJnbrnesVyvWUxRoHtDbjIXMBmWWoeTFJbeHaHcjCOIuWTSwfnkWUwxQhDthVaSRJqulNrwzXcqvVeTYXCFxgxUfWEFYTxaeYtF"), true, -246367.32235977837, 1191783724);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GVmbBWMq
{
public:
    bool DFQSdNjoBBXca;
    bool sefQFAqQd;

    GVmbBWMq();
    int KkYAKg(string kSGqg, double xgIXmVNg, bool ffrrtjYiqovCtEsn);
    string cBnNamMAiCOckQFt(double PqrKOXjG, double kqIxOYUseDzRk, string MBxLarvSkzSaS, bool VNPgvVvPAuLZzUWn);
    int MMvFOlUXJL();
    string jsWARzy(double eocwKRXPRHcZRLwv, double IlTFZphGUlawZ, double JitCJLVc, bool IgUhF);
    string pQcJX(bool GgWYZiwp, string WXlBfhtKJLT, int ZJgXLTzGzUiUVSJ, int FBmiGBCdb);
    bool UXIFkY(int QtUWmuFLoOm, string dRuyTXYfWUAGkRpF, bool LmPLzBGCPTpex);
protected:
    bool nJeDQ;

    double VPYVIaTJwiiSRlcx(int BdZjywMJ, bool KoNixwpHwcgORU, bool rSatzzbzIpNuwxZ, bool TSqQftmavtDBC);
    int kZVtSxHoyZPDiWM(bool hOvat, int RwitucWeMnaG);
    double MNcyihZip(double lrXLWUDe, double GvZlyfsTKFxtPJ, bool hKNjatPMRXzd, double TIFKBsauRa, string pdrYZtYVTblAOIN);
    double orjXadLzlBYEc(int ieUzxk);
private:
    int kgACrGTedkZLy;
    int RpCSRpRrWmnAHH;
    double LwAXfzisRldFwT;
    bool ebPugKYjPp;
    string xMgIwAHWDRZIbDZ;

    void HAdUtE();
    int USkHjt(double jvzniPFVnqyKh, double hoSzYQQx);
};

int GVmbBWMq::KkYAKg(string kSGqg, double xgIXmVNg, bool ffrrtjYiqovCtEsn)
{
    string pzcDjm = string("craacEcsZolaouMyGxWXNwYNXeaiTRgaDuXSBLPjcrOVjZEzJsWZYfTMtxQvuRtRKdKlxveAKYTzyQkysfsiEVJPuEmgYhjDYjXtfbxpLCzPSxilmRBZSeFtNGujKTcZrqICBoGNHhakpVTgoAniYyjePghKCvsVmkMbZZbbjlEgBqPJHTakvLAsuAHzcxmxsttZRougKTcTONNCiYMBHyPJhSpuO");
    bool nytrUbz = true;
    string lNSqooiwxERtlKa = string("OCEML");
    int XoQcUsz = 351164064;
    int okGRgMZjldjWF = -1398000191;
    double rkVEVZ = -68754.50926332525;
    int YBreGlEAqP = 1493653917;

    for (int SezrS = 1835884900; SezrS > 0; SezrS--) {
        lNSqooiwxERtlKa = lNSqooiwxERtlKa;
    }

    for (int zWtldoivcJUUdNJO = 369420169; zWtldoivcJUUdNJO > 0; zWtldoivcJUUdNJO--) {
        okGRgMZjldjWF -= okGRgMZjldjWF;
    }

    for (int DfgfqdEE = 254177912; DfgfqdEE > 0; DfgfqdEE--) {
        continue;
    }

    return YBreGlEAqP;
}

string GVmbBWMq::cBnNamMAiCOckQFt(double PqrKOXjG, double kqIxOYUseDzRk, string MBxLarvSkzSaS, bool VNPgvVvPAuLZzUWn)
{
    double qnDShUEaINntR = -831929.9875935736;
    bool YHrrITJWHhuhm = false;
    string iMiTrwE = string("rqJFFatwCKUUwitECrjWoFZwOUYTVJCOmEfXJMpwhimznuVGyHvbv");
    string XpIJM = string("kFcoTuMYNAqPIvsNBwMMEFcXakzAtnPuvxicwdEdkzqDSOmkFXxYtPPfZWBfLGSOfyKGwJgtQXjmYATohHWgbJOoUKPiluzMjHHwwbPShUqSLTrPwwBnHsEfXRLaFuSJeJFGHdtHzszFQnyhaccyXvaLCWujctwaNx");
    double SCvtDiaJChfwVR = 875927.4407151935;
    double cQQSUedRgVT = 892263.5604997207;
    double YILYC = 39439.18301465593;
    bool PuJUm = true;
    bool twuzG = true;
    double QRNiKdeM = -996234.1324280666;

    for (int nNOZIroW = 826023504; nNOZIroW > 0; nNOZIroW--) {
        PuJUm = YHrrITJWHhuhm;
        MBxLarvSkzSaS += XpIJM;
        YHrrITJWHhuhm = VNPgvVvPAuLZzUWn;
        YILYC -= PqrKOXjG;
    }

    for (int OKZdXJYEfIeVphp = 1975761893; OKZdXJYEfIeVphp > 0; OKZdXJYEfIeVphp--) {
        VNPgvVvPAuLZzUWn = YHrrITJWHhuhm;
        PqrKOXjG -= PqrKOXjG;
    }

    if (cQQSUedRgVT == 39439.18301465593) {
        for (int nqKsfPGYALk = 683197873; nqKsfPGYALk > 0; nqKsfPGYALk--) {
            QRNiKdeM -= qnDShUEaINntR;
            cQQSUedRgVT -= kqIxOYUseDzRk;
        }
    }

    for (int OyjUJGYJEGzv = 1159808642; OyjUJGYJEGzv > 0; OyjUJGYJEGzv--) {
        qnDShUEaINntR -= PqrKOXjG;
        qnDShUEaINntR -= qnDShUEaINntR;
        kqIxOYUseDzRk += QRNiKdeM;
    }

    return XpIJM;
}

int GVmbBWMq::MMvFOlUXJL()
{
    bool ZAZrt = true;
    double GqTxaHsYhvi = 1035717.6901204487;
    string BqXqGClSgkXiQ = string("NEXTZpxSJCwcXtSrLEZGHhVFGVnuDqyGPjSnpsZyRCqkzytTdBDcdrhKdLWnGhBwJGWiCCliyiEXq");
    bool kIiEhfuKgIpZeX = false;
    double aQUZucsMzYnOJNVO = 948900.6548373367;
    int RHvNrm = 273888382;
    int BFndjDNMlWaBsuAx = 1511570544;
    double YMAQjqD = 331383.1229217767;
    int IrWBhLlqCYSXRMCY = 1986243948;
    bool ajMGPtytjItgPKbu = true;

    for (int sBgTj = 125010071; sBgTj > 0; sBgTj--) {
        continue;
    }

    return IrWBhLlqCYSXRMCY;
}

string GVmbBWMq::jsWARzy(double eocwKRXPRHcZRLwv, double IlTFZphGUlawZ, double JitCJLVc, bool IgUhF)
{
    string AGhlrm = string("gvurNensANllpGlrjQiRjKgCoEFuQNcfUAzG");
    int PplkLcRuVlhp = 1904015221;
    double rmkBiJax = -838723.7238381114;
    int RZvVZLMpR = -817546304;
    string sjjhGblKFQoFDB = string("OErXaqFbeHjBuMlGPpqOcDNklKQdTjUSFwMYSImQVPrxQqliWMZUGgiXvdaguOHjZioeCZlyOIfBCzVRMnBLSJAcuWigacvCCeXnsVRSJwdhQDDPIWUmwvBzpMruFLfxcfSRBiNjLhJTmdRlW");
    double cSlzwSQs = 48225.26727475981;
    double qWTmytoHLQds = 931518.0156388578;
    bool QKNwUqYeDW = true;
    int aTUZLtDuR = 1638666168;
    bool WsvIVXZWjFa = true;

    return sjjhGblKFQoFDB;
}

string GVmbBWMq::pQcJX(bool GgWYZiwp, string WXlBfhtKJLT, int ZJgXLTzGzUiUVSJ, int FBmiGBCdb)
{
    int XlErxfyWnop = 1440323271;
    bool zxNJKZmhRuYV = true;
    double sTGQvJrKQL = -722190.8752330056;
    double EBzQM = 450701.795812532;
    bool fKjryuVBaRYB = false;
    string xcafcJ = string("MTsjMxqeijZAcEjLFIGNyKXylySBSMNRjtRbEHdfjyVzO");

    for (int PlLsnWZUwvSt = 1713592674; PlLsnWZUwvSt > 0; PlLsnWZUwvSt--) {
        EBzQM += sTGQvJrKQL;
        XlErxfyWnop -= FBmiGBCdb;
    }

    for (int DuHUjc = 1905904798; DuHUjc > 0; DuHUjc--) {
        zxNJKZmhRuYV = zxNJKZmhRuYV;
        FBmiGBCdb = XlErxfyWnop;
        zxNJKZmhRuYV = zxNJKZmhRuYV;
        ZJgXLTzGzUiUVSJ += FBmiGBCdb;
        EBzQM -= sTGQvJrKQL;
    }

    if (GgWYZiwp != false) {
        for (int jttbfdKxmkghwceI = 1258215171; jttbfdKxmkghwceI > 0; jttbfdKxmkghwceI--) {
            continue;
        }
    }

    return xcafcJ;
}

bool GVmbBWMq::UXIFkY(int QtUWmuFLoOm, string dRuyTXYfWUAGkRpF, bool LmPLzBGCPTpex)
{
    bool zLaOxdWu = true;
    double dTKPa = -170975.3079883324;
    int XsDmMrotSUFtL = -737882982;

    for (int CGcZYceIIBxRjnGd = 1290518463; CGcZYceIIBxRjnGd > 0; CGcZYceIIBxRjnGd--) {
        zLaOxdWu = ! zLaOxdWu;
        zLaOxdWu = zLaOxdWu;
        LmPLzBGCPTpex = ! LmPLzBGCPTpex;
    }

    for (int aMtscrxu = 1945188133; aMtscrxu > 0; aMtscrxu--) {
        continue;
    }

    for (int GcUQIkaki = 410581663; GcUQIkaki > 0; GcUQIkaki--) {
        dTKPa *= dTKPa;
    }

    return zLaOxdWu;
}

double GVmbBWMq::VPYVIaTJwiiSRlcx(int BdZjywMJ, bool KoNixwpHwcgORU, bool rSatzzbzIpNuwxZ, bool TSqQftmavtDBC)
{
    bool lxjIqCmByqfcSc = false;
    bool xZaGOMe = false;
    bool LqbZlCT = true;
    bool lKETBNJDGHbmeb = false;
    double JQUhXLfyFyd = 354621.087565432;

    if (lxjIqCmByqfcSc == false) {
        for (int WgrWsMORi = 1223544045; WgrWsMORi > 0; WgrWsMORi--) {
            rSatzzbzIpNuwxZ = ! rSatzzbzIpNuwxZ;
            KoNixwpHwcgORU = LqbZlCT;
            TSqQftmavtDBC = ! KoNixwpHwcgORU;
        }
    }

    if (TSqQftmavtDBC == false) {
        for (int eYFSGxq = 1236862565; eYFSGxq > 0; eYFSGxq--) {
            lKETBNJDGHbmeb = LqbZlCT;
            BdZjywMJ += BdZjywMJ;
            LqbZlCT = ! lKETBNJDGHbmeb;
            TSqQftmavtDBC = ! LqbZlCT;
        }
    }

    for (int asryGNkVDDA = 1130481156; asryGNkVDDA > 0; asryGNkVDDA--) {
        KoNixwpHwcgORU = lxjIqCmByqfcSc;
        KoNixwpHwcgORU = ! xZaGOMe;
        xZaGOMe = rSatzzbzIpNuwxZ;
    }

    return JQUhXLfyFyd;
}

int GVmbBWMq::kZVtSxHoyZPDiWM(bool hOvat, int RwitucWeMnaG)
{
    string kaNuOTSHM = string("BLctLQJJlLUIkBGQXiSOTIGfgKpNlRABQzNxOlHWPaaVgozAHeVlLAazoXabDTlauBSWTyrZVUdCYDQiVhKnLdinNbScnOiii");
    string IANHuNKnigvh = string("ZmsnJglTxZnRjFGsUxZSjdyNRnqjvjizubxXLdeNtDKQoAZhzIFsrdKgztvOfefBYVudxMxrxWpRgJDVpnurMOhodMUCVYQxYdNPMRTaNybigIXAvLeZefDiabeQoKurvU");
    string NtWaoVowQ = string("ZHyxGOKmealSBuGwuqAZyBuphjpxiYhflXeMgHUckvLtcxnDKmPsHAFrNwaHHTyKtSIfDmgGEnCHCFqotkZGqsYuZMBritDiBTQKqfSxDAlBWNVTnfEskEtLQebuM");
    string zVAiXeVRzasCll = string("HfPfUFxyCfuMkirKaoowtTovnXmSyXOUpwBeMYYrehCNLCTWeywaMOUBkCnkVTiggPYFJeCEVbVzpbhJVZTdNzKSdeKMzjTYodKWxiDuFmEiQOCDemUqLCqvVCIvNNRLHDgARFaAGgvEBDwboAWCgdWwEhoXylXMZocIpNBbfzkxurb");

    if (IANHuNKnigvh != string("ZHyxGOKmealSBuGwuqAZyBuphjpxiYhflXeMgHUckvLtcxnDKmPsHAFrNwaHHTyKtSIfDmgGEnCHCFqotkZGqsYuZMBritDiBTQKqfSxDAlBWNVTnfEskEtLQebuM")) {
        for (int OMDYIJDdqe = 1817113932; OMDYIJDdqe > 0; OMDYIJDdqe--) {
            IANHuNKnigvh = IANHuNKnigvh;
        }
    }

    if (kaNuOTSHM != string("ZmsnJglTxZnRjFGsUxZSjdyNRnqjvjizubxXLdeNtDKQoAZhzIFsrdKgztvOfefBYVudxMxrxWpRgJDVpnurMOhodMUCVYQxYdNPMRTaNybigIXAvLeZefDiabeQoKurvU")) {
        for (int CvcdTpdVrjkk = 2144186605; CvcdTpdVrjkk > 0; CvcdTpdVrjkk--) {
            continue;
        }
    }

    if (RwitucWeMnaG >= 205816846) {
        for (int xUCVDZWa = 1742270918; xUCVDZWa > 0; xUCVDZWa--) {
            kaNuOTSHM += zVAiXeVRzasCll;
        }
    }

    if (kaNuOTSHM < string("ZmsnJglTxZnRjFGsUxZSjdyNRnqjvjizubxXLdeNtDKQoAZhzIFsrdKgztvOfefBYVudxMxrxWpRgJDVpnurMOhodMUCVYQxYdNPMRTaNybigIXAvLeZefDiabeQoKurvU")) {
        for (int RdtRdHNFoOZiQMdo = 1922005955; RdtRdHNFoOZiQMdo > 0; RdtRdHNFoOZiQMdo--) {
            kaNuOTSHM += zVAiXeVRzasCll;
            RwitucWeMnaG /= RwitucWeMnaG;
            kaNuOTSHM += IANHuNKnigvh;
            zVAiXeVRzasCll = zVAiXeVRzasCll;
        }
    }

    return RwitucWeMnaG;
}

double GVmbBWMq::MNcyihZip(double lrXLWUDe, double GvZlyfsTKFxtPJ, bool hKNjatPMRXzd, double TIFKBsauRa, string pdrYZtYVTblAOIN)
{
    string tYgVMVrKQwtZ = string("rhonkHiqKkZtHBmYanUjrOdGXXMAIUpnUUEAmEEvugvblOxwGmOHhLbjAXIXGiiXTpVRSQiTvHDNZQkFIGrwLispEGeU");
    string yqVBKkXvmRiC = string("XvFGiJLTGPPIdTembVdJDSjSEKdXhkMoUtrtASCQMXrRQGacvWXzNkIPlKSFmdWccrtzZnFJGxejixtuXOztVIzTWPAxoAZLuZtBeObjLIwjZgbIHpAqCWOsVdgaTiLjNgBhDAHyQIPRaJfzgVtcupyPgUHBxDIqztCai");
    int eXgjlXTsHgH = -1117353933;
    double HvlafdXkNR = 144454.78586670372;
    bool ZepiNHeyFbYCa = false;
    double vskWZnUh = 947651.9318845693;
    double XsYBFHXqeXKIQYYU = 533182.8372065047;
    string iJcWY = string("qnTMkrRGtEUIXNRiMQrqJXOzHxkVDIJoFEwAlrtsSYeXRkRofLoHXpmEqrpjsbuOQbaOZqgFOabncQwEFIXsNecApQuzlsNNTgdKlaVqSISacincoSIkhCEkpmKpBPmxKIMWYgTTzOXocOFgyavulJloQEchmBppU");
    string nkjmrDHu = string("dsAZuCJPGQmbHsDXxPCYUtfBqTdUVOQWIRYLavZbgoMIMkgxSDjDfXMqXCZtoPVDxlfOgnIDxTOnxqeYnReirgAkJhdig");
    int MKNMy = -1451237177;

    for (int wfoyqzTJPFHH = 894554299; wfoyqzTJPFHH > 0; wfoyqzTJPFHH--) {
        continue;
    }

    for (int UWhTzpAMLUmbTw = 1185972990; UWhTzpAMLUmbTw > 0; UWhTzpAMLUmbTw--) {
        continue;
    }

    if (vskWZnUh >= -309253.08828040084) {
        for (int gxbZLgEcoT = 517830319; gxbZLgEcoT > 0; gxbZLgEcoT--) {
            HvlafdXkNR /= GvZlyfsTKFxtPJ;
            iJcWY = pdrYZtYVTblAOIN;
        }
    }

    return XsYBFHXqeXKIQYYU;
}

double GVmbBWMq::orjXadLzlBYEc(int ieUzxk)
{
    string XEdNIQhSkBED = string("yrgKFaNWKMIgxCypaQjivCUPabtAhAgYyJRdxsQUvrzsdbJOcGbeuTiwhKbcbTGDxacQRVWsOxCmMcMGzajsIFKxbZgTBdTcsVhYBOBDOhngMWUuoHIbCJoiqttpm");
    double EdoUPbvLRJZFOQ = 416223.6372522081;
    int ktFrsDTQ = -804707022;
    string xRJTO = string("HsMFqdvrxGXVqXQvZLJFPxwnxFmOrrgngaqnmqjIDZvElVLybWMWDjBMZrUwLYneRcAaVDQiGOxGGoiWGLjEAXMCUnTGhwhJSZdHFpNQjAanyXZpnwgNMdBWeGvaTzvLuYAUQVgMHuoktFsNwSYCiKQsbnfeJsccFGIiTIAHXvvTZAZneeaeZRYsTCQEEmeQJJCghMFwtTuDJkCxKLlqEF");
    double JuIkdmVcj = -598817.8107165971;
    string DkrotPam = string("QaLrVfgAXrolgepPUJZdFZoThgvwpqjUbubPyREeaTyrCtXjqlpulxcZdJFQCjyJyXJFbSoNgSzwGOwuFqHmhSroMmVOnPgJIJDZRaKNeXkuKVfiNPtPKBkAxvhZcgLDrYHOnuYyiexKhOEgahSQipneTtmoUIQOMPDbbXSSpxMYNmbIsbZTWcDqcFMDFIhXXIPZnVluVsQkkJqMmsseFKCHsgNhHYBBanMdMyuNgfyN");
    int GqxbE = -242965508;

    if (XEdNIQhSkBED < string("HsMFqdvrxGXVqXQvZLJFPxwnxFmOrrgngaqnmqjIDZvElVLybWMWDjBMZrUwLYneRcAaVDQiGOxGGoiWGLjEAXMCUnTGhwhJSZdHFpNQjAanyXZpnwgNMdBWeGvaTzvLuYAUQVgMHuoktFsNwSYCiKQsbnfeJsccFGIiTIAHXvvTZAZneeaeZRYsTCQEEmeQJJCghMFwtTuDJkCxKLlqEF")) {
        for (int LAbFSmaOndpXHjJb = 1641882329; LAbFSmaOndpXHjJb > 0; LAbFSmaOndpXHjJb--) {
            ieUzxk += ktFrsDTQ;
            ktFrsDTQ /= ktFrsDTQ;
        }
    }

    for (int bUFCItvklTDs = 1753708151; bUFCItvklTDs > 0; bUFCItvklTDs--) {
        ieUzxk /= GqxbE;
        DkrotPam = XEdNIQhSkBED;
    }

    return JuIkdmVcj;
}

void GVmbBWMq::HAdUtE()
{
    int sFGzxEAvAuLb = 1198904925;
    bool UEvhMWCZghYvhgTx = false;
    bool PxDUTFVgSddQGau = false;
    string KLvijK = string("IzoyNSHdQXVnOxNjMLFHjhGAkMlJdHwKOCfqVcgDMjtJIHdmbqTNVBhFhiHqneErTUPHvrtTGBScQWZpiLpTFdEnEkbMwOLKPNxdejWDhBUePGJFsZNnfcVvCmtBBExxlPnpAtEaDQYHLOcarNz");
    bool ZatKmNstxaV = false;
    double ObZNVnefeHnotrs = -985904.8545726342;

    for (int fFglpUzrbuJoIc = 890024433; fFglpUzrbuJoIc > 0; fFglpUzrbuJoIc--) {
        PxDUTFVgSddQGau = ! UEvhMWCZghYvhgTx;
        UEvhMWCZghYvhgTx = ! ZatKmNstxaV;
        UEvhMWCZghYvhgTx = ! ZatKmNstxaV;
    }

    for (int iokfERtGInfB = 1491812398; iokfERtGInfB > 0; iokfERtGInfB--) {
        KLvijK = KLvijK;
        ZatKmNstxaV = ! ZatKmNstxaV;
        UEvhMWCZghYvhgTx = ! ZatKmNstxaV;
    }
}

int GVmbBWMq::USkHjt(double jvzniPFVnqyKh, double hoSzYQQx)
{
    int lWittb = 719065896;
    string TQPyWx = string("WEMPiFSJsrcrSmM");
    bool uvzfgLbfGjpYOn = false;
    double hRfaOtTuGKYDs = 738409.3301962181;
    double DgujAZqX = -1000050.6736984927;
    double YXsGXu = -327433.7407831268;
    int HMCKRR = 1548591586;
    double fpYwW = -128949.60124680813;

    for (int lwCqzlD = 1903437469; lwCqzlD > 0; lwCqzlD--) {
        continue;
    }

    if (fpYwW > 754227.3947873744) {
        for (int FSxIaxhHVuC = 1273013864; FSxIaxhHVuC > 0; FSxIaxhHVuC--) {
            fpYwW -= fpYwW;
        }
    }

    return HMCKRR;
}

GVmbBWMq::GVmbBWMq()
{
    this->KkYAKg(string("hrcaIelcKMlWlGGHcDNfIxAxdTPNYIfOymoprCzNAEKyBccFWesZIWEqOHkZggMhEOwsWcPFkxWuljisUYByaVstKxseKbdUYmiwll"), -801703.644678823, true);
    this->cBnNamMAiCOckQFt(1036528.821514871, 713577.1566614563, string("SBJiuzfPhZpDrXdmowxxCrQUiHYjgUhjROFuTgdExlmdFhPvmtqTtErSzMVcZKBRfMgQdWMsgxjkEaVqvHZLquKgpbOMOjnGjpJnVwHcBsUxGryZsXzInZPAfyAGyc"), true);
    this->MMvFOlUXJL();
    this->jsWARzy(-1034098.4023697755, 876056.1872974911, 1012117.2922432094, true);
    this->pQcJX(true, string("YEnEDMfIUkGQddBhJHOOJixOdCvZynFnlotXTnwYbDQXaFXCahWNMgouYOKqxsLGyeJRFZJJUoryTfmvacrHmDeQMIcfSdyNECCZDQTgwXZcTeTXvXrekcWMnxBxOVKSccGZzYsCfJFlJJhUHhThDVXeiYAFazHZDApqHIxkbHCERMASswHRkzQSngumiovtdNCnQUueQLzWBYCnUiunrVxisuKZIN"), -1376615659, -1187774775);
    this->UXIFkY(-1579455639, string("TmkOkphUHFrgdXQlAtlLZUPDhuxrcOXBDEbHAichZkUeJFrbCPjCMhLiPpSACEGYNNtcrUkUPcxnyQNsiWwDKchnTCBIWWZvTCBKwCtzSYZqRuOhYrErdWYqGuUfPiqcofStMJdrtgmVNtRzuhWplBDeLGsedHwJRdKAGZagnlkJWKiUvthBaBKdNvgArwWBBHtbLeMTmOVVzhHoKnSQmnzbkItDSuLmhQQPbKaGiGw"), false);
    this->VPYVIaTJwiiSRlcx(1622095407, false, true, false);
    this->kZVtSxHoyZPDiWM(false, 205816846);
    this->MNcyihZip(-309253.08828040084, -311558.5109554866, true, 518204.8010088786, string("NSGcUHFFNsfGoCfFqXDmfvEaBocIP"));
    this->orjXadLzlBYEc(1525187032);
    this->HAdUtE();
    this->USkHjt(-652803.0204955286, 754227.3947873744);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CNqBNdZHtcfgzWS
{
public:
    int RDzUqVZaunkqQYsu;
    double qAdrmDqSeD;
    string kkwhVLyXIV;
    int gQujK;
    bool wEYyl;

    CNqBNdZHtcfgzWS();
    string RFdwlEHKglqlEDq(string CjuOHg, bool kVzToxrwWedwwbGv, double wiwux, bool XnBVuY, double ESxil);
    double ZpFYg(string nxgoWFsnEfpY, int RzeutXtnPAww, int OlczTAEcquTfz);
    bool akitEizqGmdviXqk();
    int vSmKaL();
    bool QbxrhXwffF(int ddAAStcoinT);
    string eEDVhesJlc(string EjkvqUbrxa, bool ELCVdp);
protected:
    double LuAjQ;
    string lqTiahB;
    bool koKwAkFGszhm;
    double nfSEhcqkuecgMe;

    bool VOzVKJcXN(int kRzgFKsE, int qmacjYtnocdXswYK, double miLDOzhQymGB, bool NyBarDxEBbOZzI, int GyXKbFmgr);
    string sGKYCpOxoYeZY(double SqeKlVUpiuAIQnkx, string MNtkpqbI, bool sSqecZPgqbnFAb, double NyQOOuDdglyWgG);
    int XKREAfhXOWkg(string FRwczCLlWTQ, bool DuzlVqZw, double TwUFlgFhY);
private:
    bool THkKflynMRrRZD;
    bool QwQwwBnbOsbeLO;
    int tmPjmdpOUE;
    double xJtBeLfEapty;

    int dFFnGlVAfPFaH(bool zYzZUjPJrIJqpk, bool BqptIhQYK);
    void TcLyWJUnkjY(bool BCfUvGtlNQyr, bool amhhsesxlcn, string oislIeqAgqoOFF);
};

string CNqBNdZHtcfgzWS::RFdwlEHKglqlEDq(string CjuOHg, bool kVzToxrwWedwwbGv, double wiwux, bool XnBVuY, double ESxil)
{
    double KOkDYP = -970514.8650263709;
    bool KnFhUVEsw = false;
    double mNrfPYfpwtbzkN = 599400.6005637096;
    double HHIbwKvbbEw = 174808.64541349272;
    string HyBluiIzApnQO = string("XOIVWzskjRqmahThIvoJDNtBwOBjsnPn");
    double wRrlZOFSCTaBXsF = -704820.589715745;
    bool pEXibUsLXKC = true;
    string cWOyGxcEtaKEku = string("MGjqmLErYNfrZbVaYGYTcrzmmNXFwNXCZeEUnqOdAkvYFHUFGzyzGRwGXxWHTYtXPkisakzMvUNWBEVlCmGlDgurtgQEsrhLTTEDyMNjPbxR");
    bool jcmPIbvc = true;

    for (int ruJgsKbGZ = 1784379334; ruJgsKbGZ > 0; ruJgsKbGZ--) {
        continue;
    }

    if (KOkDYP >= -970514.8650263709) {
        for (int AcrVysRJ = 1967651482; AcrVysRJ > 0; AcrVysRJ--) {
            CjuOHg += CjuOHg;
        }
    }

    return cWOyGxcEtaKEku;
}

double CNqBNdZHtcfgzWS::ZpFYg(string nxgoWFsnEfpY, int RzeutXtnPAww, int OlczTAEcquTfz)
{
    string YtIDStv = string("HCtXYpHgVQyzKnaUDiiTZkdRrFkDBfUPIqxzFFutMihzPquzZZjuMEDJ");

    if (YtIDStv == string("ZmulFOxpIhPFDJqKFBjVPlPEFHUXcgxLaJjBVLFaKMMpbTYBKswHZLwBmoDogMhcECqupHUsHAnqfqKBxrNPsGWNbQqAbskfCaxYMzxCcsuWShuzatPrWxsZXxKALwfp")) {
        for (int OOUoI = 1735507092; OOUoI > 0; OOUoI--) {
            YtIDStv += YtIDStv;
            RzeutXtnPAww += RzeutXtnPAww;
            YtIDStv = nxgoWFsnEfpY;
        }
    }

    for (int lekLyaf = 1874362491; lekLyaf > 0; lekLyaf--) {
        RzeutXtnPAww += RzeutXtnPAww;
        nxgoWFsnEfpY += nxgoWFsnEfpY;
        nxgoWFsnEfpY = nxgoWFsnEfpY;
        YtIDStv += nxgoWFsnEfpY;
    }

    return -521407.6496049178;
}

bool CNqBNdZHtcfgzWS::akitEizqGmdviXqk()
{
    double vCmWBoxxSb = 100304.89890152839;
    string kHsGJGhjnj = string("mEOp");
    double OVbCOFvaZVNDpWt = -230001.5517179972;

    if (vCmWBoxxSb > -230001.5517179972) {
        for (int yaCewEsxoCHImbJv = 916095261; yaCewEsxoCHImbJv > 0; yaCewEsxoCHImbJv--) {
            OVbCOFvaZVNDpWt -= vCmWBoxxSb;
            vCmWBoxxSb *= OVbCOFvaZVNDpWt;
            vCmWBoxxSb *= OVbCOFvaZVNDpWt;
        }
    }

    if (kHsGJGhjnj < string("mEOp")) {
        for (int NYnHbaqLPT = 506044466; NYnHbaqLPT > 0; NYnHbaqLPT--) {
            vCmWBoxxSb /= OVbCOFvaZVNDpWt;
            kHsGJGhjnj += kHsGJGhjnj;
        }
    }

    return true;
}

int CNqBNdZHtcfgzWS::vSmKaL()
{
    bool DZxrDVTuOSnmQKN = false;
    double LkigM = 539235.7860435466;
    string nOkWvC = string("zTTXCLczLtYsSSRtXnbyGnLNbXCrPNQnDAiHbpMvBbdgwLhCmxwZZpmzBMtMGATnnOSiLVbKPhjBlGSutfffriAyBH");
    bool FxOYnzryTZUr = true;
    double RQhJag = 56794.01488875277;
    double lDPbmhcWExClVd = 723815.2157342499;
    string SXTEilJtVzDjgqDZ = string("FlFXwuZyNjPzZoTlfAjxRigMJkUKFzLeKhgMYMixnmRZStOwVGEbziNpumgmUQnAbrlvMXnRJRwxUBggdQAFYNrHQuUhpdUVpsAWtaryMtgFxHbRQoPhcjXtfZEPIuOfiJEGqyruiqfiTfdPzcitteCLZJdogZVKgBiKJKUcaJNQVdfgQQcdrytMHEiCUN");

    for (int KeGNlogsneW = 1687367613; KeGNlogsneW > 0; KeGNlogsneW--) {
        LkigM /= lDPbmhcWExClVd;
    }

    return 118953327;
}

bool CNqBNdZHtcfgzWS::QbxrhXwffF(int ddAAStcoinT)
{
    string onxBE = string("rHKYuIiHoIhRdqqEvWgDGwZVVhupTbhEdBNIfaAjgMAJIBFGFKwcLqdUgEvoJtOmFRluXFaAMOpInwldzzqUQWLcilnaOZXaQVmjmpOkGrOLZzYMMSYFkDeBVpkyrsZHdnLMYrzoXXFXbdmXUUWMRuTgCSPrNnhJLJcxhIeuqlolIOasnKJsyiGvvcmRyfzKqQmLHMKdPedydgMdXIrxevjzGgTRWgUFYplyTD");
    double GcftJMantWBlkFNI = 473369.92282012745;

    if (onxBE >= string("rHKYuIiHoIhRdqqEvWgDGwZVVhupTbhEdBNIfaAjgMAJIBFGFKwcLqdUgEvoJtOmFRluXFaAMOpInwldzzqUQWLcilnaOZXaQVmjmpOkGrOLZzYMMSYFkDeBVpkyrsZHdnLMYrzoXXFXbdmXUUWMRuTgCSPrNnhJLJcxhIeuqlolIOasnKJsyiGvvcmRyfzKqQmLHMKdPedydgMdXIrxevjzGgTRWgUFYplyTD")) {
        for (int xeSnLKjz = 1599863356; xeSnLKjz > 0; xeSnLKjz--) {
            onxBE = onxBE;
        }
    }

    for (int VVCFpLnQDDIMbgL = 1045929024; VVCFpLnQDDIMbgL > 0; VVCFpLnQDDIMbgL--) {
        ddAAStcoinT -= ddAAStcoinT;
        onxBE += onxBE;
        GcftJMantWBlkFNI /= GcftJMantWBlkFNI;
        ddAAStcoinT += ddAAStcoinT;
    }

    return false;
}

string CNqBNdZHtcfgzWS::eEDVhesJlc(string EjkvqUbrxa, bool ELCVdp)
{
    bool KTlQbYE = false;
    string gPanJuVegpi = string("buxebNBMrCRIulDkdyDuGmDAOZSNoycrqavnmqdGtdxivaTcOwLXjkAZKkNNWJVXEgjJvrfqZxnevZixeYbDjHwQfMPgLGXjhuZedHUFepGCMYoniFAhLZjiyiBuIxNwULHPQcfRVXkihkLjCfuHQeBgrGwuwFwGyIIydVRjwuDkPLOyIeYenMDNSfwDYnrakQRgGfxCSdGi");
    double WBQWbyjjGPkrUwJW = 583333.6599739651;
    string ttcxSITmDtSZQd = string("EHOjDXuuFAWmsyWWpYHkukdmbfyFxKOWNHsALQwheobQGPfacHxTkYjgeRYsSewxwOtrNJQmVpiAZzjaSWbcNlcwOpDOCHfUDG");
    int tTJCUMKvZYFmJvQ = -597251424;
    bool xCSBNtAqPZ = true;
    bool AFOpZAOI = false;
    bool RFvxkOIrGxBU = false;
    string DxygHo = string("yLFsGoZqDyn");
    bool eOqCRU = true;

    for (int ulQxVClVjgZJW = 845265934; ulQxVClVjgZJW > 0; ulQxVClVjgZJW--) {
        eOqCRU = KTlQbYE;
        AFOpZAOI = AFOpZAOI;
        eOqCRU = RFvxkOIrGxBU;
        ttcxSITmDtSZQd = ttcxSITmDtSZQd;
    }

    for (int nPlZHS = 30981078; nPlZHS > 0; nPlZHS--) {
        continue;
    }

    if (eOqCRU == true) {
        for (int PEUqxQ = 1526207133; PEUqxQ > 0; PEUqxQ--) {
            ELCVdp = RFvxkOIrGxBU;
        }
    }

    if (eOqCRU == true) {
        for (int XYNGAuTxdT = 1824300429; XYNGAuTxdT > 0; XYNGAuTxdT--) {
            gPanJuVegpi = DxygHo;
            KTlQbYE = ! xCSBNtAqPZ;
            xCSBNtAqPZ = xCSBNtAqPZ;
            EjkvqUbrxa += ttcxSITmDtSZQd;
        }
    }

    return DxygHo;
}

bool CNqBNdZHtcfgzWS::VOzVKJcXN(int kRzgFKsE, int qmacjYtnocdXswYK, double miLDOzhQymGB, bool NyBarDxEBbOZzI, int GyXKbFmgr)
{
    double jRziZYkO = 642267.3639724635;
    double UJQYPwmOC = 150519.62663602224;

    for (int IZqMheA = 1987476188; IZqMheA > 0; IZqMheA--) {
        continue;
    }

    if (UJQYPwmOC < 642267.3639724635) {
        for (int KObSYRQtQ = 2088740017; KObSYRQtQ > 0; KObSYRQtQ--) {
            NyBarDxEBbOZzI = NyBarDxEBbOZzI;
        }
    }

    return NyBarDxEBbOZzI;
}

string CNqBNdZHtcfgzWS::sGKYCpOxoYeZY(double SqeKlVUpiuAIQnkx, string MNtkpqbI, bool sSqecZPgqbnFAb, double NyQOOuDdglyWgG)
{
    int snpVlQ = 1379164572;
    double mqwddcU = 650892.7701861173;
    string raLcSLrOsecfdAmk = string("zmcmFUPfbEQofoXDYeYlPgPVPRiwKhVAsbgnrWMewgLBCvUrnlSqHeqWpBvxYUIWyFcBAnCHRnZpQmpSfaWVmVLuVfhxBYBBLTKgrSzvtPRKTdZaUTJVcNvQBUeywNyvVRPjwZruLEocJunaLOTtDagpFdnzLbRtRrnwZccEzbdQbIwkUQYsYLSslEuBMrlrLrwNupADJGLpdihhkwxnOYlOdtbqolhEH");
    int OhdqwLjcHZNPkq = -1502605646;
    int CgnzXjCVFZX = -1218611950;

    if (snpVlQ == 1379164572) {
        for (int SvkyIhmpXw = 565693706; SvkyIhmpXw > 0; SvkyIhmpXw--) {
            mqwddcU += SqeKlVUpiuAIQnkx;
        }
    }

    for (int VsjVZIB = 1769164132; VsjVZIB > 0; VsjVZIB--) {
        continue;
    }

    return raLcSLrOsecfdAmk;
}

int CNqBNdZHtcfgzWS::XKREAfhXOWkg(string FRwczCLlWTQ, bool DuzlVqZw, double TwUFlgFhY)
{
    bool MHAPOEXwbcbNsGR = true;
    int HQWTHi = 352606400;
    int zCrmPoIE = 2063765303;
    double gQJrTbzPVVcFSjb = 834230.0935229138;
    bool hgPzVi = false;
    int ryyMiwivyVFFoC = 874617946;
    bool OAUoNWywOnpgD = true;
    bool TEXTnosdg = true;

    for (int DHpVnkKzNnUUe = 1821868608; DHpVnkKzNnUUe > 0; DHpVnkKzNnUUe--) {
        TwUFlgFhY = gQJrTbzPVVcFSjb;
    }

    for (int QoHquOvo = 153232772; QoHquOvo > 0; QoHquOvo--) {
        MHAPOEXwbcbNsGR = OAUoNWywOnpgD;
        TEXTnosdg = DuzlVqZw;
    }

    if (DuzlVqZw != true) {
        for (int UpaIAjSJOfJNpHVN = 28486616; UpaIAjSJOfJNpHVN > 0; UpaIAjSJOfJNpHVN--) {
            ryyMiwivyVFFoC *= zCrmPoIE;
        }
    }

    for (int BRHoqjIO = 349651538; BRHoqjIO > 0; BRHoqjIO--) {
        HQWTHi -= ryyMiwivyVFFoC;
        ryyMiwivyVFFoC = zCrmPoIE;
    }

    return ryyMiwivyVFFoC;
}

int CNqBNdZHtcfgzWS::dFFnGlVAfPFaH(bool zYzZUjPJrIJqpk, bool BqptIhQYK)
{
    bool aVWuuERgfWy = true;
    string gBnSqGT = string("kpSWjIVNMdeRkRmXSDLpspOKyplcIVTEdAJszxbWJPxnhjUQIRWvaulUvmKciIQxhDMDJYHOZurHNKkjCSokLQJpoFabqGDAKSQWELTiaTxeUQxfYqeCyBONkFLujidPKfoELCJyXuvaeonVXbDfjnBXOwwITBRXyhCMOcmtuwVArfrckSuUzchSjZEFuUYMxBnZdIDFGfNxMBFJqOMKejhXjMJQizDbGfgXZdZzFqBYdhaGmPOaqVcefiQ");
    string uULGvdud = string("idKzgJvEznDovm");

    if (uULGvdud >= string("idKzgJvEznDovm")) {
        for (int IqsjXNC = 540743152; IqsjXNC > 0; IqsjXNC--) {
            gBnSqGT = uULGvdud;
            aVWuuERgfWy = aVWuuERgfWy;
            BqptIhQYK = ! BqptIhQYK;
        }
    }

    return -478803844;
}

void CNqBNdZHtcfgzWS::TcLyWJUnkjY(bool BCfUvGtlNQyr, bool amhhsesxlcn, string oislIeqAgqoOFF)
{
    int pOpOZSeQePb = 1181606758;
    string zoRIIJLjLxxbr = string("dwevwEBuUODAJmXqAWsfKUThqEEWGpvYxUQzLKrjqDVHxxtUtWpRMfxJsmvqYiqlwiESMoWRGeMSksjaaNzKospukJxOCQsZWHSZuCMvFwzNzZDUtZnMTWZmEGJceuqZrnlJTUrIfXmsvGxpSiNOFQVxybAIMVcWuCyPdeCSwWmIhPRygcQKynteLRsswLfgrcrqjzQHdTsbBhvGOqCCUfRBxhYwKZFQZcyMODFWrYvfWpkt");
    int SooHLO = -920652219;
    string bmOpjNAUUBl = string("bXvjteZzokXqRTMTEnBUVTGbSkYRjgDvIKCPCBOJZxfLwcDMrnKBhfymwmSRUzIXjvWPCHRnCjFJSXlJsmZAFUfYgLYrjeXqhckzcFoWUwsQgNYXaOVACNusJhXhntUumGAuFSTAaegCSHqLEgcKdbvrFTYOWzbgJBbusEKgtutScXrNtfyOJJsJXuvoEZRJuDOJGINnewQVRfNqNxLmRkhvTxTmIEkRsCcWOFrSVOVTAZzFFBVBM");
    double Ahssf = 399418.323892177;
    int AGyQLNjrmDogUSpr = 469667980;
    int sOOYOvxTYjt = 1755420980;
    bool fhsNYiXLPpN = false;
    bool rnnJmwzPSrVd = false;
    double cCDqvBzIHnfL = 771096.6666481575;

    for (int MKZyndfAvxTb = 1169310073; MKZyndfAvxTb > 0; MKZyndfAvxTb--) {
        amhhsesxlcn = rnnJmwzPSrVd;
        SooHLO /= pOpOZSeQePb;
    }
}

CNqBNdZHtcfgzWS::CNqBNdZHtcfgzWS()
{
    this->RFdwlEHKglqlEDq(string("EUadZlAgnkvHDNdJtymyehxqkGCtUKgxsuolCIgmTOukjvdzNzAcySGrXyqUKDNMJrPStFrozqjTR"), false, -864445.9671649813, false, 411014.69212758204);
    this->ZpFYg(string("ZmulFOxpIhPFDJqKFBjVPlPEFHUXcgxLaJjBVLFaKMMpbTYBKswHZLwBmoDogMhcECqupHUsHAnqfqKBxrNPsGWNbQqAbskfCaxYMzxCcsuWShuzatPrWxsZXxKALwfp"), -1301720625, -1375000886);
    this->akitEizqGmdviXqk();
    this->vSmKaL();
    this->QbxrhXwffF(-1378398435);
    this->eEDVhesJlc(string("lWWjiquvhoYuCAcfkZYvANtgqVaOok"), true);
    this->VOzVKJcXN(1976920640, 129902174, 46330.20657305198, true, -1542368697);
    this->sGKYCpOxoYeZY(825915.2039406729, string("ZVUpQCvwKRDUqQBzapwiWpcyyJsWjiePGYDpYyRBlSGUVrCOvkDSIDQgBsKZeLLwUtaWCGcfnJeUPgidsuGatOjrIyWGMQAfjnIOmEaWglcLVHVbdDrjWMHhXzzTsdUeVUJgUrxpxyEANCUfMqdCZYzQwOekSqpbLzspvcOXMFUVWVNNFT"), true, 361892.026933192);
    this->XKREAfhXOWkg(string("MaYmyLZlqJYbUHAUrZdXKANqkaKVzvRXBhCSNvhKPeBufGEXKmyjEqlrcNUFBHXAJzHjCaDDavSPMEdJQlOMRcmvDJnPapGIRSBpnuiVjXOtyGTdeGvpkHqdIoCNqCuvDKoYLvpgwzS"), true, 171754.42751916643);
    this->dFFnGlVAfPFaH(false, true);
    this->TcLyWJUnkjY(false, true, string("uNEIOAvTUOCbApQEFmDQCQKovyUESvyBhWFiHnwJftoVGnqeLfVVegDyIRXrGePIZHwoihnBNybMCWgQDbuNEJxrLGYCyMFIWGdyzNqWkBGTZeJoYxxtCuwcJtZMkBLjJhvZKqPkZidAVxXNjCvEefkfiKdWjYxaxCnVaKSYRnUlEruEwvLfKFwSRoqpHMtLqCcgtQLtHbtnlnnaNNJYHAWOTLQm"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rQJsvtWkyZLiEN
{
public:
    double UfwFwD;
    string xhTDWvUaZJ;

    rQJsvtWkyZLiEN();
    bool NzRaW(bool AMQTgIvWjkSsx);
    bool ctlkOninQHUk();
    bool ZvEjGQhnRpxLPRzW(double kRRENInLWfdOUHR);
protected:
    int XUgpzXpAda;
    bool NyeJEBZ;

    string wkuorjioEMVJq(string LEMXpvqf, string nkFjiK, double ObepRug, string WDwABMenxzQF, int uyOTJjZZQWvlIDB);
    double RLhlWmfoP();
    int dsHuQC(double KIgJGFjw, int MIfjwIOyWrUz, string NiOxYILAF, int OtXXRCPKqhXX, int gbioj);
private:
    int rhnBjGxvU;
    int npbiwyDIIwi;
    bool bcyasHX;
    bool KJMGExQDUWAfg;
    string PRoOLsDltJy;
    bool HbavMxnqziU;

    void KPAqSSAwzwnPDfV(string InyKOjtyqoWUs, string KuxOAkiTacn, int MxYXeYNJq, double zTczCGdEaxAU, double KnjgG);
    int UxDaUbbutAUn(int sVgoRzQvtbXy, string bUIBnCmMFnCGaYVO, int lLQZG);
    bool eXifbwAWHBnB(int ihGnDtOYGZZ);
    double bdRNxX(bool CVrHYQTTucpFn, bool IaVRbXbOBkKqa, double YUUSMSDzTXHCiLz, string WAlkZ, double TBfwtnKpCgcq);
};

bool rQJsvtWkyZLiEN::NzRaW(bool AMQTgIvWjkSsx)
{
    double QukWSvZxiERHzMSe = -929325.6592127418;
    double lGlKTgXbUqWfq = 406738.9190597406;
    double ixrXx = 184957.8065531931;
    string PSBKSHOyBbQBqu = string("VYUJHdfVdXDoamjGCSwDhySqVZnGWirMwKGxIOevdqDjYBPWrsHsLZHveFGdKGjEWVUhCKcsvHwkljQGLdOkoCpMXlzzTiZoJTSdqBkSTohaUZaWPIWdUtVWogBlREGqSOQJCiBESeLnfFUmwWhezNSMtPXvqejZLfPfKsxGdWuXHcAOGGZbRWESDPsDiXpxZdmvkYqzWGaAwZDyLkhVbrcxVGFWNUdtFF");
    string wFSoUoEmzOF = string("tZtqbBNJgxaMQmhdnfiynGVkgSBQrJhdIrEWDXvJFZdkEcLfRduYWCqqCWjsXraJtYmqWACwGFfDLqyxHBjWgCDTsKPCLwJIiyFGgmEhNfxVckhOBuLQEqNtJGCxUVbTncMMvLsQXODCFgFubtZlXKNYaLobziweLGtHPjyzjgdsOJZoWpbWXBcepRQUItQEssbadpQYZYLsZPxswdQWLSlomIXfInZWYxwRvqgepIXE");
    string uAURIgjchW = string("UqvtohMSeQVPDXAVVDJhLCDEdeOOKJequmVPMVBMMe");
    double kIROSMQ = 916250.0200189344;
    bool PwSUMm = true;
    bool AXCJeMPqivGm = false;

    if (PSBKSHOyBbQBqu == string("UqvtohMSeQVPDXAVVDJhLCDEdeOOKJequmVPMVBMMe")) {
        for (int JzShmd = 1530381380; JzShmd > 0; JzShmd--) {
            kIROSMQ *= QukWSvZxiERHzMSe;
            AMQTgIvWjkSsx = ! AMQTgIvWjkSsx;
        }
    }

    for (int OsBQdtoJ = 374161769; OsBQdtoJ > 0; OsBQdtoJ--) {
        uAURIgjchW = wFSoUoEmzOF;
        QukWSvZxiERHzMSe *= lGlKTgXbUqWfq;
        PSBKSHOyBbQBqu = wFSoUoEmzOF;
        PSBKSHOyBbQBqu += wFSoUoEmzOF;
        lGlKTgXbUqWfq /= kIROSMQ;
    }

    for (int BSpqfWkBGDQe = 144560419; BSpqfWkBGDQe > 0; BSpqfWkBGDQe--) {
        QukWSvZxiERHzMSe = lGlKTgXbUqWfq;
        wFSoUoEmzOF = uAURIgjchW;
    }

    if (wFSoUoEmzOF >= string("UqvtohMSeQVPDXAVVDJhLCDEdeOOKJequmVPMVBMMe")) {
        for (int WNeSy = 1211070469; WNeSy > 0; WNeSy--) {
            QukWSvZxiERHzMSe *= ixrXx;
            AMQTgIvWjkSsx = PwSUMm;
        }
    }

    return AXCJeMPqivGm;
}

bool rQJsvtWkyZLiEN::ctlkOninQHUk()
{
    bool hfynHVCqnrhQQoI = true;
    int YsmwbQhQAbqOF = 51017769;
    int NerIiggYBXYd = -957238451;

    return hfynHVCqnrhQQoI;
}

bool rQJsvtWkyZLiEN::ZvEjGQhnRpxLPRzW(double kRRENInLWfdOUHR)
{
    int jIoSNyAbMcfYgMS = 1548854390;
    int GKXySRqsDiXRaDV = 1678218817;
    int PdFkaYRRi = -1751529570;
    string rPdsbsNIleHvG = string("thLPZQUojsckFMsNKxdrXjCljnwZUqSlUemDOBWYIbGIxMqxYuyMBEzIzGIpEAghcbFPiliHfTvJIZpREIWZaQvOJneuXEmJLqdacONsWessTNZZCwVfypKwysiMLrerwNGbcZjauOQyolTMYyDURmCKqrWRVXQavTROsbfgeojRPxLvXOkARBRQVsNMItjrHwjfzElwyqxHIrEkzcjareNXwffOTUGhnfHJnSkneMwvQaacZwhBDeuJFVLZ");
    string DvtNJkmbf = string("EnkYXppXOdpkspKFRuFHVEJgxpJFjQdkdpnddHpIzeqhhqyQpMLfMyYYugtnNaISZjgcfHzZHAxhZQUcaWjIWqzOdAHjRgSGRLThDQZZjCzSKoentPwbtNemTjFJIQRxmUQrXJpmHJSwBlTozIJGzlIaZOIBqjUgRatBGLUwpgrpembqEypLlgsfRlFzvMhmzfBXpThlrFR");

    for (int gqutgivxIGUKr = 331866605; gqutgivxIGUKr > 0; gqutgivxIGUKr--) {
        continue;
    }

    if (kRRENInLWfdOUHR < -540991.0660819686) {
        for (int dgjMhzNNAZGMAfuN = 1859464029; dgjMhzNNAZGMAfuN > 0; dgjMhzNNAZGMAfuN--) {
            continue;
        }
    }

    return false;
}

string rQJsvtWkyZLiEN::wkuorjioEMVJq(string LEMXpvqf, string nkFjiK, double ObepRug, string WDwABMenxzQF, int uyOTJjZZQWvlIDB)
{
    double MjwNXS = 727479.5709355574;
    bool mVzuAAIe = false;
    string ekaxP = string("qGzTkimZkUwNOUBNxjHqJEvpNalQiLhWwtWZDFIcLCuVwpWuDOqpKUOWqdDkviTYpbcJBmAfkCNTrcCxPFGZGNjghrVbrPsMBELysVdZaQKZJJKzXZQhBjtvKuwHBwfYCcrulXemeuGaSrcEKjyoIWjHQsHcIqrNWakaUeToinrwLUFwvSGjAjuAbFjYIzqjWFoUdUSAyamBpIzgDDabIGOzzyiniZjGrAaQsd");
    double GjoiEqXNDJBbzeV = -659732.435063329;
    string aJUXHeDc = string("dZHFeunRsyTBjkFjOgpXJFETgOHsfCGllikvoridWmvQghJPlfrohPmuVwibSmjZJRIovFEAUrWxBOGjRWPjhCywKPlWLnTjBCIgugDTbFYojhCrnNKouEuNKWokwJGBPIdnMfYdattYaadeZIZDHmcYleIZGbtVmZhCSIAhkeGLucRoHvJBitgYKZWKFdxGiGWfdMHYQIuYeWwuqxxlpMnPYEBIqKbunJi");

    for (int GhVJfKT = 1505693028; GhVJfKT > 0; GhVJfKT--) {
        WDwABMenxzQF = aJUXHeDc;
        ObepRug += MjwNXS;
        aJUXHeDc = ekaxP;
    }

    return aJUXHeDc;
}

double rQJsvtWkyZLiEN::RLhlWmfoP()
{
    bool haUVnBNQujAb = true;

    if (haUVnBNQujAb != true) {
        for (int qOnXjPNK = 733753934; qOnXjPNK > 0; qOnXjPNK--) {
            haUVnBNQujAb = haUVnBNQujAb;
            haUVnBNQujAb = haUVnBNQujAb;
            haUVnBNQujAb = haUVnBNQujAb;
        }
    }

    return -412002.76418917836;
}

int rQJsvtWkyZLiEN::dsHuQC(double KIgJGFjw, int MIfjwIOyWrUz, string NiOxYILAF, int OtXXRCPKqhXX, int gbioj)
{
    bool kBmsNBHXLLoGRT = true;
    string ZnWVkVgJpcTDo = string("inJfSbHmtxGSLvemlqprhblZFJxnZPQQVHlxghLOTvjsLHginPqNrlvOoOTtvNujIzoNMHMFZZbdaOmytPQkeRybxroMLDiQntauwFWcPeImwRomUhzDCzvclVfaeCExhHvImcoOtRvBZdXxlQIiMHuUgQusnYMS");
    string HBlUjVTBq = string("tvlCJzUxkwYvblIkcvdWBhFAESOhcptcDscKXXqFqrIeRiAZRQGVdVTtjYtWfaShKbbf");
    string BCGIFzrhriYIy = string("LOIkrJUddxXwkgTSxrMcNgUIbUsPerNYowlZNWELGpqORyUhvGAIAMcfRIdSuaIiuvvohNEWqcNHlwJKzuyZwvgxLuefBQLMzAQpubjS");

    for (int cxatgFUr = 1459158371; cxatgFUr > 0; cxatgFUr--) {
        HBlUjVTBq = NiOxYILAF;
        MIfjwIOyWrUz = MIfjwIOyWrUz;
    }

    if (MIfjwIOyWrUz == -2140496160) {
        for (int vtYohIlxKknux = 1908584458; vtYohIlxKknux > 0; vtYohIlxKknux--) {
            HBlUjVTBq += NiOxYILAF;
        }
    }

    for (int zhxoJjNFCyHy = 431967146; zhxoJjNFCyHy > 0; zhxoJjNFCyHy--) {
        continue;
    }

    if (MIfjwIOyWrUz >= -2140496160) {
        for (int nFQSfTsjypcXXzVm = 2056855463; nFQSfTsjypcXXzVm > 0; nFQSfTsjypcXXzVm--) {
            BCGIFzrhriYIy = BCGIFzrhriYIy;
            BCGIFzrhriYIy = ZnWVkVgJpcTDo;
        }
    }

    if (gbioj < -2140496160) {
        for (int qzBHZL = 537026939; qzBHZL > 0; qzBHZL--) {
            BCGIFzrhriYIy += BCGIFzrhriYIy;
            gbioj /= gbioj;
        }
    }

    return gbioj;
}

void rQJsvtWkyZLiEN::KPAqSSAwzwnPDfV(string InyKOjtyqoWUs, string KuxOAkiTacn, int MxYXeYNJq, double zTczCGdEaxAU, double KnjgG)
{
    string InaQAsKgka = string("WaabyMjRpmnAcwiTmsXtYUPuevKeewCAuzXJVzYONZGpJJksXavUOKLAwyDSufbBxoWxgWWLWIfqEZgBgrHnkodWsqqWVzmKxpwfyGlalxkSMLepasQCcViowCFYwzFSsUdjAiiQFASXZQNhew");
    bool hjWIh = true;
    string aipcmdgxtLD = string("gebObdlsfZNpPENrOmAMZjlQtJoeZetFlYZpEKiojMrEQSqHpXWglpNZsLLhlamLwJSOlPdXKkyAvyyjINnWzPwNjLpzDPNwpGRTzzSffcFmvGizKZgAxNpDn");
    string OeGEmJhBPXzhiDSw = string("ExUZhUsoGJMMxuGotOojnhmHcvSeowmEpUvUECRnRydlbLrougVBZzWJcuItdDKPQMVxXtZrjRDFYSDXkHZRVzyYEjKBghIVJKgNJJGOihDdfgtMpuBgdpaAZqBpCYJWZGitHxZKkYnabhjBJefvVIYkGkDkZlTyFCmCRkhwALjWrNrMol");
    double sNkNwPnMyPT = -533371.2997043466;
    bool IQXNYgwabVX = false;
    bool rYtUTuDrEbcYG = false;
    int OUWMiKKdy = -1280305469;
    double sJANOBcJhNO = -1010060.6890711323;
    double plFGWAxpy = -63849.7961167648;

    for (int mgrbZNQ = 1147854093; mgrbZNQ > 0; mgrbZNQ--) {
        MxYXeYNJq *= MxYXeYNJq;
        OeGEmJhBPXzhiDSw += InaQAsKgka;
    }

    for (int fSgTtkwk = 1156543359; fSgTtkwk > 0; fSgTtkwk--) {
        MxYXeYNJq += OUWMiKKdy;
        OeGEmJhBPXzhiDSw = KuxOAkiTacn;
        aipcmdgxtLD += KuxOAkiTacn;
    }
}

int rQJsvtWkyZLiEN::UxDaUbbutAUn(int sVgoRzQvtbXy, string bUIBnCmMFnCGaYVO, int lLQZG)
{
    double lqvdWdmJRRqFg = -343994.33743587416;

    if (bUIBnCmMFnCGaYVO >= string("NdgpDnYljWIsiPCgekYxMoLNJkyyTGODzfcHutZOtqMNaWLFmlvQnEHKCurhuHsgW")) {
        for (int gqBzDLQHB = 282909581; gqBzDLQHB > 0; gqBzDLQHB--) {
            lqvdWdmJRRqFg -= lqvdWdmJRRqFg;
            sVgoRzQvtbXy *= sVgoRzQvtbXy;
        }
    }

    for (int fFiFcucx = 569003220; fFiFcucx > 0; fFiFcucx--) {
        lLQZG -= sVgoRzQvtbXy;
        sVgoRzQvtbXy += sVgoRzQvtbXy;
        sVgoRzQvtbXy *= lLQZG;
    }

    for (int pBSGqDGlWJB = 1350553037; pBSGqDGlWJB > 0; pBSGqDGlWJB--) {
        sVgoRzQvtbXy /= lLQZG;
        lLQZG *= sVgoRzQvtbXy;
        lqvdWdmJRRqFg *= lqvdWdmJRRqFg;
        bUIBnCmMFnCGaYVO = bUIBnCmMFnCGaYVO;
        sVgoRzQvtbXy += lLQZG;
    }

    for (int sCTwdTTwPtDndo = 1551876226; sCTwdTTwPtDndo > 0; sCTwdTTwPtDndo--) {
        lqvdWdmJRRqFg -= lqvdWdmJRRqFg;
        lLQZG -= lLQZG;
        lLQZG *= lLQZG;
        lLQZG /= lLQZG;
        bUIBnCmMFnCGaYVO = bUIBnCmMFnCGaYVO;
    }

    for (int IRsfuRBZUX = 2124248904; IRsfuRBZUX > 0; IRsfuRBZUX--) {
        lLQZG = sVgoRzQvtbXy;
        lqvdWdmJRRqFg -= lqvdWdmJRRqFg;
        lLQZG += sVgoRzQvtbXy;
        sVgoRzQvtbXy += sVgoRzQvtbXy;
        lLQZG += sVgoRzQvtbXy;
        bUIBnCmMFnCGaYVO = bUIBnCmMFnCGaYVO;
        lLQZG /= sVgoRzQvtbXy;
        bUIBnCmMFnCGaYVO += bUIBnCmMFnCGaYVO;
    }

    return lLQZG;
}

bool rQJsvtWkyZLiEN::eXifbwAWHBnB(int ihGnDtOYGZZ)
{
    string pshDNiKuLoW = string("vj");
    bool ZtrGd = false;
    double piYmXZzl = 336113.2355148665;

    for (int yxcdCQHXyAOfsiz = 938124503; yxcdCQHXyAOfsiz > 0; yxcdCQHXyAOfsiz--) {
        continue;
    }

    for (int DuGoQpWPOxOjVp = 672888680; DuGoQpWPOxOjVp > 0; DuGoQpWPOxOjVp--) {
        ZtrGd = ZtrGd;
        pshDNiKuLoW += pshDNiKuLoW;
    }

    for (int NGOhvhFUpMeEjb = 1615068706; NGOhvhFUpMeEjb > 0; NGOhvhFUpMeEjb--) {
        piYmXZzl *= piYmXZzl;
    }

    for (int TJGLwJJJaGWghC = 97150689; TJGLwJJJaGWghC > 0; TJGLwJJJaGWghC--) {
        ZtrGd = ! ZtrGd;
        piYmXZzl += piYmXZzl;
        pshDNiKuLoW = pshDNiKuLoW;
        ZtrGd = ! ZtrGd;
    }

    return ZtrGd;
}

double rQJsvtWkyZLiEN::bdRNxX(bool CVrHYQTTucpFn, bool IaVRbXbOBkKqa, double YUUSMSDzTXHCiLz, string WAlkZ, double TBfwtnKpCgcq)
{
    bool noEMG = true;
    bool zEbtNXyluz = false;
    int KMKggODftWVbSZS = -215786848;
    int BAOosewEcFejzGR = -1183786578;
    int YqKvgjKwztTBAw = -1082746907;
    string VwkgxtwYpIh = string("OWuypjVUSfyLMInqjktzfRMVXtLdRglexETqjbkBEUUThgIUnzeBVTahfiXbIIdgDqUbfCJsySMlRreeiZufEfvMrguIsFhtKcowVinnzjfrFpDKMkmD");
    double XNUIsI = -783171.5690425336;
    int yWfWTuUtWyaR = -375164310;
    int dlUuPkMSeXBdx = -1201284006;

    for (int UfoErlH = 1065386187; UfoErlH > 0; UfoErlH--) {
        VwkgxtwYpIh += WAlkZ;
    }

    for (int NwwXgW = 388140297; NwwXgW > 0; NwwXgW--) {
        YUUSMSDzTXHCiLz += YUUSMSDzTXHCiLz;
        WAlkZ = WAlkZ;
    }

    if (yWfWTuUtWyaR <= -1183786578) {
        for (int horVPsJpRiJXR = 445020403; horVPsJpRiJXR > 0; horVPsJpRiJXR--) {
            continue;
        }
    }

    for (int juVvsuPCqtdE = 1587231960; juVvsuPCqtdE > 0; juVvsuPCqtdE--) {
        BAOosewEcFejzGR = BAOosewEcFejzGR;
        KMKggODftWVbSZS = yWfWTuUtWyaR;
        KMKggODftWVbSZS = KMKggODftWVbSZS;
    }

    for (int jVpvLbTvrYSTaT = 339463919; jVpvLbTvrYSTaT > 0; jVpvLbTvrYSTaT--) {
        continue;
    }

    return XNUIsI;
}

rQJsvtWkyZLiEN::rQJsvtWkyZLiEN()
{
    this->NzRaW(true);
    this->ctlkOninQHUk();
    this->ZvEjGQhnRpxLPRzW(-540991.0660819686);
    this->wkuorjioEMVJq(string("VvHckkakfrvnmKbUBIjxGXFIUbflcmcmCrLlxfQWQGEUbCCLXSOBBGOgRDWbipCBpiQeELELPaFiFdBhOtWbEHAnHSyPxsmbuprKDhTqaqhfihQwAUBfiwMQinHNozlCYfvvTJyNyRnoqsPuEqyEblcjHSRLwVSluKzIOzvXBwZGZBeKQHOWsCKDzWIZReleUHoFOvesrrKSrvrKlJb"), string("OiUfPhuKrttHcEyAIkAskuiwfHPPpCMAZohyolrUancbBsurcZyBOxbzXGtKrnFhsDocUgdDUCBrAaUugPFVpHbmaOCAhUqDVNSDdmAtFRGdTgojhRpyhvNiHBHMClZmqBYSjEHUeOGiukoIbukOHzvotEynBiMplfPQsnOKonuzzMXMFREKXPrMVKKpJilzGkrZZStKTidDoAeKAZwRnRfaXSwWpdgir"), 636209.0079675212, string("xaLxhNbOUGmWNcutyrrgiPmJPPsQktjkTqmchQMcGwGXScWLWoFUtHOeEFMvaFTLFjunJTzswUdfZAyrOXrThudqWJGpOaGuijEZjiUarSoQpwgOLLWvTYuNsxSCnTsUEuMqhu"), -549176326);
    this->RLhlWmfoP();
    this->dsHuQC(3381.7588591330614, 359475965, string("rcRaSUjBybBNDAnDUkEeWderccSSYIptrGTucpmvTPeSuZDyPIZFBRrrojRqZChQwUDzZMnxAJFVylceMEFpafeBsLwXIxbpTsaATUMvYTmNGIeomphPAvxmqrIOHZSuUUCmPXHAGjOxQcFsRTbUrCJbiVOhWXHQnjgAtjvBZcnXgoSsFwRsGYRtRMewXt"), 1007159535, -2140496160);
    this->KPAqSSAwzwnPDfV(string("PQAKeM"), string("GPPhdXSGuLeyWIZqLzVeEjEieRveEbuvSTMXrUYitVFUoGCgbilkvKHMTvyrndhkIQqKWTRItmDdFvAkRBQvQjsaBSFnfnZGRsrKkSVUpKNzAFcJhoPGxQDqIEoPejyvqsoKLnPChnJsDtKhWLIfMXDtFPEzC"), -1831044164, 1011783.5402599867, -45397.75014732891);
    this->UxDaUbbutAUn(-1066621637, string("NdgpDnYljWIsiPCgekYxMoLNJkyyTGODzfcHutZOtqMNaWLFmlvQnEHKCurhuHsgW"), 1365709109);
    this->eXifbwAWHBnB(1193241566);
    this->bdRNxX(false, true, 191376.5220933768, string("fUfJwPeVMxfMoiPpYhlKjWvNjoSjMBgLXheEblKTpQndEwWXwZSaHdgFTdXqXpjfniDregwVlHemYAdMHdwsGzKGipMzKIlRkVusIijOMcRsoDbZJEXXmTVrBSxEyODosFNTGmOdixAMXcRMhoTzqkF"), -623551.0742396608);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OkIRSuGxE
{
public:
    int tOHNQqTCUZas;
    double SsykXJYo;
    double geuYyXVs;
    bool xtECyQOEYd;

    OkIRSuGxE();
    bool imbWtButyTruxlC();
    double kzOKoALXDcu();
protected:
    string YPazQabRiQRFztwO;

    bool oNBVnnoglRjxXD(bool TlFwJVOx);
    bool PLALXd(bool RTJvF, bool nyirwgnbf);
    int zstJnVnTTraGdAf(int WMqxcTrGWhKRJ, double OBumgOlrQvACM, bool ZnmgqjwEFQa, int mKtBG);
    int diveFEoUtIyuw(int QikqieSdmG, bool tsVbqkiFd, double AgYYZL, double DqQqOLXplagJM, string wLdiQKTH);
    string PRRzqsmL(int OGwHQRnjUrCX, int EOunemdsrdkMVVQ);
    int AONKaZcozd(double QfpAfYPdAHlXGkZ, bool STKMe, double vuPYrwhU);
    void bdksdtgz(int PoblYUJBeCkQM, double kFERwKVbPqa);
    int HucuTnoFjavqou(string bFkoPsZ, bool hdLSYtQrrvKsG, int MPGhsrRX, double ECGYBipmNfTFSL, bool TapAhHXbFf);
private:
    string mXCpRNhkyaHPV;
    string XmhopGmDlQKwWUnj;
    bool CUczzoO;
    int JEfRchkdZNAhwCqn;

    string AUSgoWjE(bool rbZkzbYqkahRvi, string ADWxbaQykWfGMgfG, int usrnEzdmw, string oBeYuykgPzbNQ, int vaqhxuRXdBtJoy);
    double pVXIQEsXSiAJDQi(double BsewZVfCgMnSc, int LvjIlQUazLrwCMA, double efUBmJVNBe, bool FTPdNHh);
    int cWpSqtrlCjYXPxpy(double ltSZJ, double QThiO, int dUKlo, bool cEwSLr);
    double eGysHcSpgDmFNjw(double AGhNXrrfTL, string yEGRyyMn, bool glPCpJig, double eZjwgKezUkKO, int sCCrKPnLUKjtv);
    int LhRUJssJ(int bxDrii);
    void NIUcI(bool lQhbJDWAP);
    double cRvvZdwh(string DpdHlNkQlqRfkxs);
    double pONkaeYcscpBiDv(double dUIWttj, string bBRkWk, int xnFbDzZzcl, bool wYYCbotCut);
};

bool OkIRSuGxE::imbWtButyTruxlC()
{
    double gZuONiSmmI = -650154.7212222954;
    bool pfWekkCjhiK = true;
    double ThDco = -517492.70878146956;
    int wcTIjXyBYigEO = -1252362410;

    return pfWekkCjhiK;
}

double OkIRSuGxE::kzOKoALXDcu()
{
    bool EVvkhBawBdGhyKtU = true;
    bool gFRIEXnjwLVWOrc = false;
    string nXpDAQiPZaEUylsd = string("IQybBdEdnjCKrrRidzFUyVTbbjStwmiUmgHMGJYybRwsMGAMBPJOfdCeQMdnznxqrBoSCCFuWZWMrcVPyCetNOFmHGjrpTjN");
    bool pOQQehIuOds = true;
    double TQckKRNcHSqScSgy = -430224.27424479707;
    bool hKvhqmpRXuihAXAg = false;
    string JaoSEbxKgnSRVmbH = string("GCBkLxoVyvrlpJkKxkdDPpApVAWuuvgrgNFkAy");
    int YEwawEV = 1859099371;
    int SNOShWL = 1874887054;

    if (gFRIEXnjwLVWOrc == true) {
        for (int tySWrD = 1958650992; tySWrD > 0; tySWrD--) {
            EVvkhBawBdGhyKtU = pOQQehIuOds;
        }
    }

    for (int WWcmLhqlEMFnYr = 1074891866; WWcmLhqlEMFnYr > 0; WWcmLhqlEMFnYr--) {
        EVvkhBawBdGhyKtU = ! pOQQehIuOds;
    }

    for (int SpPrf = 1283383226; SpPrf > 0; SpPrf--) {
        continue;
    }

    for (int PjlSR = 1627195776; PjlSR > 0; PjlSR--) {
        EVvkhBawBdGhyKtU = ! EVvkhBawBdGhyKtU;
        YEwawEV += YEwawEV;
    }

    for (int eqRriVmwLOw = 1039579802; eqRriVmwLOw > 0; eqRriVmwLOw--) {
        pOQQehIuOds = hKvhqmpRXuihAXAg;
    }

    return TQckKRNcHSqScSgy;
}

bool OkIRSuGxE::oNBVnnoglRjxXD(bool TlFwJVOx)
{
    bool wgxYKBDqwLf = true;
    double RuUVZkTn = -82153.31225327267;
    bool pQZhaAmlXVWG = false;
    double IpTtyVkNPxxLfJKq = -662081.9979008328;

    if (IpTtyVkNPxxLfJKq < -662081.9979008328) {
        for (int BzXTLKHMs = 2031324475; BzXTLKHMs > 0; BzXTLKHMs--) {
            TlFwJVOx = wgxYKBDqwLf;
            TlFwJVOx = TlFwJVOx;
            wgxYKBDqwLf = ! TlFwJVOx;
            wgxYKBDqwLf = wgxYKBDqwLf;
            TlFwJVOx = pQZhaAmlXVWG;
        }
    }

    for (int pYkTnGnHjEWHKs = 1757774479; pYkTnGnHjEWHKs > 0; pYkTnGnHjEWHKs--) {
        continue;
    }

    for (int BvwpsGjgXtp = 1507194176; BvwpsGjgXtp > 0; BvwpsGjgXtp--) {
        wgxYKBDqwLf = ! TlFwJVOx;
        RuUVZkTn = IpTtyVkNPxxLfJKq;
        IpTtyVkNPxxLfJKq += IpTtyVkNPxxLfJKq;
    }

    for (int unzCRGpoBE = 314949373; unzCRGpoBE > 0; unzCRGpoBE--) {
        TlFwJVOx = ! TlFwJVOx;
        wgxYKBDqwLf = ! wgxYKBDqwLf;
        wgxYKBDqwLf = ! pQZhaAmlXVWG;
        pQZhaAmlXVWG = ! TlFwJVOx;
        RuUVZkTn += IpTtyVkNPxxLfJKq;
        TlFwJVOx = ! pQZhaAmlXVWG;
        TlFwJVOx = ! pQZhaAmlXVWG;
    }

    if (wgxYKBDqwLf == false) {
        for (int avxWV = 2061455814; avxWV > 0; avxWV--) {
            TlFwJVOx = wgxYKBDqwLf;
            wgxYKBDqwLf = ! TlFwJVOx;
            TlFwJVOx = wgxYKBDqwLf;
        }
    }

    for (int sJQkjaKcjLpyK = 2073693492; sJQkjaKcjLpyK > 0; sJQkjaKcjLpyK--) {
        continue;
    }

    if (IpTtyVkNPxxLfJKq < -662081.9979008328) {
        for (int LCGYuHlRw = 508764410; LCGYuHlRw > 0; LCGYuHlRw--) {
            IpTtyVkNPxxLfJKq = RuUVZkTn;
            TlFwJVOx = ! pQZhaAmlXVWG;
            pQZhaAmlXVWG = TlFwJVOx;
            pQZhaAmlXVWG = pQZhaAmlXVWG;
            TlFwJVOx = pQZhaAmlXVWG;
            pQZhaAmlXVWG = pQZhaAmlXVWG;
        }
    }

    return pQZhaAmlXVWG;
}

bool OkIRSuGxE::PLALXd(bool RTJvF, bool nyirwgnbf)
{
    string GRcBjRGiqnnvmz = string("ggCrjciLzbELSQbsumFXOZsAduPPQsvLNDALQyMpEalvdBwwMxblLGjaVSZmYSbSKHXEiNjhfCFvsNRErsoTdGaLXZugYQDVJbNeOdFdUmJsJpRPaonfDrkwuRGiuQWaGftpQTyZGxAgOlOSDWSKnezBTGBvdCCBsJUSnIVXzVdSciTtxZzzDoInAWrCwNxHxDLdLIBIkwv");
    double wkSGkB = 768734.577318796;
    string hqYieBnw = string("bWabHXVQnEjjUBYJwbcvyawMHtbluHpXwxLPPAgIfMUmZparfBClegoZRKFvBpiJeiLpaaHOWpdszoTsWcHTtOkKetkDFNjLrRcxblnzAjAyjlaKxMlYzJTNiQIUqvJBMoJlCTarsUaIRt");
    int buKAVjOMCFan = -1318450339;
    double kHEPtmDAxGun = 775680.442891016;
    bool AZatVCA = true;
    int uvXnYvnOyVjKX = 156649998;
    double UcINpdst = 696391.6125892348;
    double wpOOOuWygtqK = 134587.06757862726;
    string kXKZdu = string("FnqORqqUQiCTlepTRnTnHzxippSEkurVhYfbpEutxiRjSNGHxJXJyvIqvRsaPkhOiuAVowKgmJNXsaApDFHaCvovHgUfoWyedjypcBcZATEIXxCZBiiLezRnQTCqCcBamBRRBJ");

    return AZatVCA;
}

int OkIRSuGxE::zstJnVnTTraGdAf(int WMqxcTrGWhKRJ, double OBumgOlrQvACM, bool ZnmgqjwEFQa, int mKtBG)
{
    bool fsaXxloiIzNMJ = false;
    double HqZDGJc = 426844.8273960241;
    double ODWLqbDGiuwFKBK = -661401.7196579757;
    double nNZfV = 934138.3957573727;

    if (ODWLqbDGiuwFKBK > 934138.3957573727) {
        for (int BqReItEVjlHNVWA = 768191732; BqReItEVjlHNVWA > 0; BqReItEVjlHNVWA--) {
            continue;
        }
    }

    for (int rHXlWaBpEybwqywF = 972232645; rHXlWaBpEybwqywF > 0; rHXlWaBpEybwqywF--) {
        continue;
    }

    if (fsaXxloiIzNMJ == false) {
        for (int kjptFErx = 760202525; kjptFErx > 0; kjptFErx--) {
            continue;
        }
    }

    for (int cumGOTKQuH = 1981467296; cumGOTKQuH > 0; cumGOTKQuH--) {
        continue;
    }

    for (int IoSvFruAOgcBO = 1148033897; IoSvFruAOgcBO > 0; IoSvFruAOgcBO--) {
        OBumgOlrQvACM /= HqZDGJc;
        OBumgOlrQvACM -= HqZDGJc;
    }

    return mKtBG;
}

int OkIRSuGxE::diveFEoUtIyuw(int QikqieSdmG, bool tsVbqkiFd, double AgYYZL, double DqQqOLXplagJM, string wLdiQKTH)
{
    string DNOHlyFJsg = string("aPYNmvUillXixWCWhfVcCXXxZUEaNaUgvecUnyXRhCxsRBWFfjCaAlhVtUabDlwgNvDheguOrHVM");
    double oqJSnFRsZ = 11267.206618611883;
    double DHbhpVcFHwRX = 159055.8350724458;
    string IItFFHb = string("UdEOLmsIsWJeUfyFmwJNKSNlJlUrWsHWtfsrLJVdjHtjMNgEbFEDBnbcPoavkjZoBDsmugsAGCHJeXFxxuEZNWKKeVggeXjeYVfjzpiAXflflAdjFHrGAkqPLRdlsKSPcvBSNToccBrYHdwgbpawZ");
    string RGZtGXc = string("TiOmsstUNTgHinQmSgZCPeuexcJGsfBRfztoUFyOqLvvwjUuuMJVyvkILycViXodPFQeOQcfglilfoZTIwnSDxAAmYHAqISn");
    double ojYXuLmdkUysZ = -390427.07910090056;
    double EnqliIVtxu = 482312.1672063821;
    bool oSWoLcOydGzRpVq = true;
    int sXbcmnRXe = -1104691563;

    for (int VLIMHZCehJ = 1200737955; VLIMHZCehJ > 0; VLIMHZCehJ--) {
        oSWoLcOydGzRpVq = ! oSWoLcOydGzRpVq;
        oqJSnFRsZ *= DqQqOLXplagJM;
        ojYXuLmdkUysZ = EnqliIVtxu;
    }

    if (wLdiQKTH >= string("aPYNmvUillXixWCWhfVcCXXxZUEaNaUgvecUnyXRhCxsRBWFfjCaAlhVtUabDlwgNvDheguOrHVM")) {
        for (int vrbJTLVMu = 589060135; vrbJTLVMu > 0; vrbJTLVMu--) {
            DNOHlyFJsg = IItFFHb;
            DHbhpVcFHwRX = EnqliIVtxu;
        }
    }

    return sXbcmnRXe;
}

string OkIRSuGxE::PRRzqsmL(int OGwHQRnjUrCX, int EOunemdsrdkMVVQ)
{
    double TDCOmY = 378805.7022459727;

    if (EOunemdsrdkMVVQ > -793783623) {
        for (int Ozcxc = 2044305250; Ozcxc > 0; Ozcxc--) {
            continue;
        }
    }

    for (int THsqGS = 1566225123; THsqGS > 0; THsqGS--) {
        OGwHQRnjUrCX *= OGwHQRnjUrCX;
    }

    return string("UGPqTIlBgEXSOvQFBThQSdnJqYBzjsydxVaiogqAzfFZdPxHNnjtnrsgxVDMUHwBwIrfnOYtlBVYqNZv");
}

int OkIRSuGxE::AONKaZcozd(double QfpAfYPdAHlXGkZ, bool STKMe, double vuPYrwhU)
{
    string RBoKZSzjrGH = string("RfPLBAQLQlNKlRZUhoflaOOFxUxxpIqFLkBlUNGKSvmqTYkNEPmrxNKRauVkFSFkkTMeNTkdEZotiJEToxdDJngvmDwAdHSCjVnSMEYPZCpHrzRuzZqFbkYXSBKpCdUMPNsIVSKWkWCjDAsGEvwhkcplXkgQDhLIN");
    bool kOKOFRPLORQcAGKP = true;
    double yhHtLeeCSeDvGP = 270730.58879158896;
    bool WyyHnLKdTwAikkLs = true;
    string OvoggvAes = string("qSvDlnGh");
    double osMsxuljZfwru = 297246.0372742557;
    int tbHseDOwQDAZdGlU = -536318703;

    if (tbHseDOwQDAZdGlU >= -536318703) {
        for (int VmhSzV = 545147955; VmhSzV > 0; VmhSzV--) {
            OvoggvAes = OvoggvAes;
            STKMe = STKMe;
            kOKOFRPLORQcAGKP = ! STKMe;
        }
    }

    for (int EtoTVHq = 862398649; EtoTVHq > 0; EtoTVHq--) {
        OvoggvAes = RBoKZSzjrGH;
        osMsxuljZfwru *= yhHtLeeCSeDvGP;
        QfpAfYPdAHlXGkZ /= yhHtLeeCSeDvGP;
        vuPYrwhU *= osMsxuljZfwru;
        WyyHnLKdTwAikkLs = kOKOFRPLORQcAGKP;
        osMsxuljZfwru *= QfpAfYPdAHlXGkZ;
    }

    return tbHseDOwQDAZdGlU;
}

void OkIRSuGxE::bdksdtgz(int PoblYUJBeCkQM, double kFERwKVbPqa)
{
    double rcYwzFgauK = 723917.308583212;

    for (int qzYnfIwB = 1168143512; qzYnfIwB > 0; qzYnfIwB--) {
        PoblYUJBeCkQM /= PoblYUJBeCkQM;
        PoblYUJBeCkQM -= PoblYUJBeCkQM;
    }

    for (int fCmVuugOalsaRb = 1930082102; fCmVuugOalsaRb > 0; fCmVuugOalsaRb--) {
        rcYwzFgauK = kFERwKVbPqa;
        kFERwKVbPqa *= kFERwKVbPqa;
        kFERwKVbPqa = rcYwzFgauK;
        PoblYUJBeCkQM *= PoblYUJBeCkQM;
        rcYwzFgauK = rcYwzFgauK;
        rcYwzFgauK = rcYwzFgauK;
        rcYwzFgauK *= rcYwzFgauK;
        rcYwzFgauK /= kFERwKVbPqa;
    }

    if (kFERwKVbPqa <= -481496.5531081072) {
        for (int RfqCtsRiYCuFHFu = 1817518960; RfqCtsRiYCuFHFu > 0; RfqCtsRiYCuFHFu--) {
            PoblYUJBeCkQM *= PoblYUJBeCkQM;
            kFERwKVbPqa += kFERwKVbPqa;
        }
    }

    if (rcYwzFgauK != 723917.308583212) {
        for (int vKKzq = 1703195987; vKKzq > 0; vKKzq--) {
            rcYwzFgauK -= rcYwzFgauK;
        }
    }

    if (PoblYUJBeCkQM == 266150497) {
        for (int uieSjeexgf = 715522426; uieSjeexgf > 0; uieSjeexgf--) {
            rcYwzFgauK *= kFERwKVbPqa;
            kFERwKVbPqa *= rcYwzFgauK;
        }
    }
}

int OkIRSuGxE::HucuTnoFjavqou(string bFkoPsZ, bool hdLSYtQrrvKsG, int MPGhsrRX, double ECGYBipmNfTFSL, bool TapAhHXbFf)
{
    string lhGMDr = string("TXyuZFVjUPlQiPLIyxiwtSrSElRXWsKlNWPjvatcPJhookKtweyCCZocVEzvSdPTNxBImKnACUpQQIVRuLKzjqhrdvjwCGFCstSBYkDCADdQrKcaUwvdCgwChzfCUuqMNyzAvhyEINpnOjieimBiYpFYS");
    string NnIJWfXuEbRvFX = string("zmanBtPJbghEEgfbcpBfCxZQIBnmlOqVWwyDoXDXOOwTvYNEkazEiyPYgLImyxGftvyYxygAXWAMQvoyDzwEWCyldUkHMMqHaVvrluBbxockNpenWACfmEmigqrtXvBXVcLkzNcwxAepMbhZ");
    string xMTXxBZHJpMLqB = string("ZC");
    string lbtCn = string("hRLiipxPzEYVgoeSdfNAmbwAOxVXcHBOxPZQAHmhVFVwhXZpNHieHIBOAmJBhYjotDpXmjTQddWxtPhCbtKluPvWDhHWehiKTqljtiVVObcVYHRKUoDsfdVLphsvukZNtISsxeqFOcUOeANQNbDsScApKnxmXQXdDGlssMLqZjnfaPIMxQjsHngljOycKXrXMcXeFDaaTjJuOWIqFWBjIbkHkpa");
    string HohCNfLzd = string("yvRviYHkxiXOTspKtJZxRxuNjxHJUbPjPrxExqxCKUoIrJgXJffBsROYsiEDHiZBXjndibruUCPYoMubfaPLoUIDjNvCaMqWXpLqZQDqPWUxNnnYvxAYSEhmsRBKSDKfkxwcieKaWDeGefrZTwLabOwdelzZJhCA");
    int UKuHtx = 1115072053;
    bool OpTZNO = false;
    double jDmjvDWNK = 364656.2830275834;
    double iOyQxDAOIZMttns = 1027404.675884715;
    bool TnKZpwppkECOoPrI = false;

    for (int vZpEFwFYb = 1410638034; vZpEFwFYb > 0; vZpEFwFYb--) {
        NnIJWfXuEbRvFX += lbtCn;
    }

    if (hdLSYtQrrvKsG == false) {
        for (int AwLYVfVIA = 241969751; AwLYVfVIA > 0; AwLYVfVIA--) {
            HohCNfLzd = xMTXxBZHJpMLqB;
        }
    }

    return UKuHtx;
}

string OkIRSuGxE::AUSgoWjE(bool rbZkzbYqkahRvi, string ADWxbaQykWfGMgfG, int usrnEzdmw, string oBeYuykgPzbNQ, int vaqhxuRXdBtJoy)
{
    string uXVFptLAWXBWbG = string("skAvzFXkqTVFHIAlKJJaEsQvvUaTYocVgbzPEEtnLMcxCrlvCxtzwOtGLyeHsAPzVMlxHKGlZehOnolVsHIkkTdFCiMbFQhSISMtCcWNAXICmiKzaNErXhbPhETOJzbPmDuV");
    int YeSRcMls = -2113779625;
    double HVxVASVtPzZekeCc = 529575.9792772059;
    string hxcHAviTheOrT = string("JFXgpLmFAYQjsSztyqgjhdkROhSQgxwwsAhTsFhVyBYgEVqpiguNbZLVMcGeCZFeWUIpFtBZmKVhLGdLkZIwFhVZZFaTcZOzeICQqfRvmHYvraKHNzSaJVdeGZOHKMwnkKAIMgEnWPnQEmXIQnApOrrkGLeDLwMnrxtASvHYyMEetjtcKkiFVNyVIUfxUbgCjHujvAHRhImNeWkQAi");
    double mUWDsmopglYrtnM = -411347.6022214778;
    string NSPzKZa = string("svbUCcHfkMUoukJBjrLHdddvYkONxXnOieljAcgqtcdBvftaqKlowtZIyPfsKvYjxevBMlAiPkVFoGYknzr");
    int JjHjovll = -1994432386;
    double UCTNOEZrjCC = -270886.45527477434;

    return NSPzKZa;
}

double OkIRSuGxE::pVXIQEsXSiAJDQi(double BsewZVfCgMnSc, int LvjIlQUazLrwCMA, double efUBmJVNBe, bool FTPdNHh)
{
    bool sEroeHKK = false;
    double KnhgEgcTIL = -291440.8092834601;
    bool NtICAVFSew = false;
    int OVusJqqHIpy = 1647454888;
    double ObsRXUfzA = -561741.906228387;
    int nowyje = 993930714;
    bool ckmJNW = true;
    double FSfqjsBvn = 675074.6079119195;
    double xlMusjwOvzzUb = 573463.7848297708;
    double vqAtDEjUt = -125468.36945346667;

    if (ObsRXUfzA <= 675074.6079119195) {
        for (int PzVamzXRxl = 908266218; PzVamzXRxl > 0; PzVamzXRxl--) {
            BsewZVfCgMnSc -= ObsRXUfzA;
            efUBmJVNBe = vqAtDEjUt;
            xlMusjwOvzzUb /= KnhgEgcTIL;
        }
    }

    if (vqAtDEjUt < -291440.8092834601) {
        for (int NMuOA = 1553390410; NMuOA > 0; NMuOA--) {
            xlMusjwOvzzUb -= FSfqjsBvn;
        }
    }

    for (int SZSqDgE = 419609273; SZSqDgE > 0; SZSqDgE--) {
        continue;
    }

    if (xlMusjwOvzzUb >= 655121.3944536541) {
        for (int rifEfNz = 409597892; rifEfNz > 0; rifEfNz--) {
            vqAtDEjUt = efUBmJVNBe;
            NtICAVFSew = ! FTPdNHh;
            nowyje += LvjIlQUazLrwCMA;
            xlMusjwOvzzUb /= BsewZVfCgMnSc;
        }
    }

    if (efUBmJVNBe <= 675074.6079119195) {
        for (int GOjytPPqTrBvsJUj = 1773366490; GOjytPPqTrBvsJUj > 0; GOjytPPqTrBvsJUj--) {
            OVusJqqHIpy -= nowyje;
        }
    }

    return vqAtDEjUt;
}

int OkIRSuGxE::cWpSqtrlCjYXPxpy(double ltSZJ, double QThiO, int dUKlo, bool cEwSLr)
{
    bool yTeTZwj = false;
    double UCjvZdPiWN = 551486.9717153828;
    double kWILGJxgQfgqoi = 315549.02933863935;
    string wwnfRrWysxGhg = string("IFxiCTykoPOMMAVjnzZMUAgqXLobAGRZnBSuamNUsCpashWzqTWjEJuEVcwkcUpayaBLiTGPrMMPSRcjKqXBvHmFOOeeSsTYGpAIslHHTYauXavcClKZQztLFyJazePvUnmCMEssJUMEHhRMXuprt");
    string kfLDvzCsJhpfIymP = string("jedKYLAyjZMONnnyCIpeqDEMfypHolQYYXOadkFXnYuZtioOfgiLIsuaWvhLEBZbXXNlcxcjCibAtpLjwUqjquiseMEypxCwxwDorqKisNYdtm");
    int LwlMnkBxkKEj = 165711416;
    int AqAfHNdVxFYCp = 12979906;
    double WdGWwWXLgrQbf = -113513.49303473644;
    double MkhKUXjaeYAcQQAG = 49823.72221050724;

    for (int tlwtqBMVmEvlRh = 206690058; tlwtqBMVmEvlRh > 0; tlwtqBMVmEvlRh--) {
        continue;
    }

    for (int zMZZeMN = 1692375748; zMZZeMN > 0; zMZZeMN--) {
        continue;
    }

    for (int mMAbVTuzfiHU = 430094443; mMAbVTuzfiHU > 0; mMAbVTuzfiHU--) {
        QThiO /= UCjvZdPiWN;
        kWILGJxgQfgqoi /= MkhKUXjaeYAcQQAG;
        LwlMnkBxkKEj *= LwlMnkBxkKEj;
        MkhKUXjaeYAcQQAG *= UCjvZdPiWN;
        cEwSLr = cEwSLr;
    }

    for (int owdgVlOL = 1248933823; owdgVlOL > 0; owdgVlOL--) {
        kWILGJxgQfgqoi = ltSZJ;
    }

    if (ltSZJ <= -113513.49303473644) {
        for (int CIxZfHfTolZUeKn = 629736545; CIxZfHfTolZUeKn > 0; CIxZfHfTolZUeKn--) {
            kWILGJxgQfgqoi /= ltSZJ;
            kWILGJxgQfgqoi = ltSZJ;
            cEwSLr = ! yTeTZwj;
        }
    }

    return AqAfHNdVxFYCp;
}

double OkIRSuGxE::eGysHcSpgDmFNjw(double AGhNXrrfTL, string yEGRyyMn, bool glPCpJig, double eZjwgKezUkKO, int sCCrKPnLUKjtv)
{
    bool lARMfdulS = false;
    bool mkOeIM = false;
    string XpgkNGc = string("eXVKAoUshdAfrdbtPjhbwMqhuUZybPfqMnmjMlZYKnTDRDMpkZwGBaTBjiLAOVPxtwcWXmhPsByuDNzsNKFOOmgYPFHeoSmuNtDWijhRTQZIggzkssGcDFDgyNBHymuyFyewRMUwhOOwlIeuVjhNzXVtUvmBSSEzMGbuHgAjfclVNanvypFZgl");
    int evOmGr = 1032701999;
    bool cEWImuaESePtWH = true;
    int aRzzyjSTLyxColDo = 144857466;

    return eZjwgKezUkKO;
}

int OkIRSuGxE::LhRUJssJ(int bxDrii)
{
    bool uxtlaCrPP = true;
    double huakHDU = 179610.7779076471;
    string ZCbchrHEi = string("lNKxqINXSvdNrpjsIyYwRORUxzAdNYljhSheExPIZzAeRBOkJaHcGbPSvhSeCgZnNEjaXdGbQTSyTglHnfKiaJxzRLHJMSkcXJyxnICLywHLQvXvvXqeiXdlADvyIVOeGTPfsfPZiRsRGBlORHkTVkGMWD");
    int usVsQDOZHNHcAPEu = 1148651364;
    string tljEiqGIG = string("uaIYsZKhJvECiFduMjTsEEiTpGZcQtUSiBjjYbzdaZomgtfpXUFGUR");
    int HPdwWZNLtSNPtaz = 477941499;
    double hqKLqgsHwWkUb = -807684.3619862681;
    double nmIcPMGM = 75258.78260138947;
    int athxoYMCxBv = 1036745653;
    int hcYOrvVVdMfU = -1693613761;

    for (int VzcxloQRcGrqVcVL = 1269315349; VzcxloQRcGrqVcVL > 0; VzcxloQRcGrqVcVL--) {
        HPdwWZNLtSNPtaz *= athxoYMCxBv;
    }

    if (huakHDU != 75258.78260138947) {
        for (int OszHMPNQlKi = 549111283; OszHMPNQlKi > 0; OszHMPNQlKi--) {
            huakHDU /= nmIcPMGM;
        }
    }

    return hcYOrvVVdMfU;
}

void OkIRSuGxE::NIUcI(bool lQhbJDWAP)
{
    int BCVpdIspe = -2133754927;
    int qzHksFO = -711516490;
    double pkSThEOZJydGyCLM = -163582.04675395452;
    string QUjMRF = string("UAXCAyOqNvoBgDFgnOTnXrxFUPLdzPLhWWIBiwmJGZFIEtINtEKVOitOxktGYQkjFLFAFnGxyCvABpNUlvzBtmevAjMtUiKCkpIzWKvLWOcjNOYpa");
    bool tSgcyjXVMVZfR = true;
    string esQNHSonVdhV = string("RPZuYWwcORBzOqhZAuXGPwlWUQGwGXnHlDwFHiaIdFwBmnVuiTxPXqRrRsYQLgnYDZYuaZtkWyydaKuksiXjTmxCbakktiSyGIAArJwUsnHPbGlcGwUcwsNBEKenjccFwDRnKrFhgyycLOKBLjnclmmHwdKxoCdaIQpgHhSqUJxEZpbDCBVOyLvsPdkPEwBvoXbBoyqI");
    string MuTnlRMyAWVbaTp = string("XwVUeutieglvhkjUoUcJzChIotkwcKgLvDVLUATikHzWvlALmjvSrMFETSdhxEZJovVWafYTSoaBbDtVeEZsMoAVZuVGvlQgxMOwejZUKUTVBAkhOzUKMddIJxvyBZxXLRlqqkuqzArVZNnmWXQwphWeSkUvCREpGqCYpxEQEvQrhrbrUyXvQpXcXmzGTgrPcLnD");
    string tInUMgOYaz = string("mdPQKHZWPBcwqAJAYqfZLqIALhNnnRmMeIVIMslbCVLkxmshVLhdoHAIveyCGBIGOxnczNaTVCTcVJXNeFwFaWNknQuUntjVPRCKeKEdbCikaIcyReOVQwqcXJGXhLBLOwiSUQLgYFWXprrtDcaqdNYCIrtuNIIbMdBIKSzwUVtA");

    for (int sTPxag = 846173005; sTPxag > 0; sTPxag--) {
        MuTnlRMyAWVbaTp += esQNHSonVdhV;
    }

    for (int kKAlcMuYQkQMMG = 1795863887; kKAlcMuYQkQMMG > 0; kKAlcMuYQkQMMG--) {
        tInUMgOYaz = esQNHSonVdhV;
    }

    for (int rZUnKSlWjOl = 1302963397; rZUnKSlWjOl > 0; rZUnKSlWjOl--) {
        MuTnlRMyAWVbaTp = QUjMRF;
        qzHksFO -= BCVpdIspe;
        QUjMRF = tInUMgOYaz;
    }

    if (BCVpdIspe < -711516490) {
        for (int LnYFiCHDFqvfEsUR = 518789455; LnYFiCHDFqvfEsUR > 0; LnYFiCHDFqvfEsUR--) {
            continue;
        }
    }

    for (int sbKmR = 1444539046; sbKmR > 0; sbKmR--) {
        BCVpdIspe /= qzHksFO;
        tInUMgOYaz += QUjMRF;
        QUjMRF += MuTnlRMyAWVbaTp;
    }

    for (int IAoDoPVSjdUUBp = 729039782; IAoDoPVSjdUUBp > 0; IAoDoPVSjdUUBp--) {
        continue;
    }
}

double OkIRSuGxE::cRvvZdwh(string DpdHlNkQlqRfkxs)
{
    string kJzOUVu = string("SNPZOzLTAlQNeKRaGCHCWyfLgLEHUMvXWFZttAxDjojbUVWyRbNInqLIlDwcxNLlaDGEbKsDeSRyLugGvXlKdBGunlzeVVbHybsEebqNuTZjGbyHwmpmFobymLZWKBWAgVcVsrcbqoRNNwugORmcZfEUGIXLxUGgnyXXRZqlSbFFVatcdEyqeDBbGJHiVpBHeeujFDHXkiWp");
    bool gsiIdGHq = false;
    string TGfCKxGOCEufOG = string("iEDowVTXMFBlEmqvfDAOGNafKIsJghiHpFuuBzNGcLNZwOZTeWjmlzmliiiEIWkrNsZcdrudgXVnQuhIzObTZIzkaMBVZHQyUFPGTVqpEucAoImqTNbLjGNVtgQztjkesxppXLuEVVCmTUnffcGZHwttYzebFuBPMqedCkDWOBEuKONFzfYfQvpcEuAITyUfADbgRkoPgiEzlaSbumQpBjnsP");
    int RMpuT = 1966843133;
    bool yrFBohhRa = false;
    int OrNngLPR = 1746159136;

    if (DpdHlNkQlqRfkxs > string("SNPZOzLTAlQNeKRaGCHCWyfLgLEHUMvXWFZttAxDjojbUVWyRbNInqLIlDwcxNLlaDGEbKsDeSRyLugGvXlKdBGunlzeVVbHybsEebqNuTZjGbyHwmpmFobymLZWKBWAgVcVsrcbqoRNNwugORmcZfEUGIXLxUGgnyXXRZqlSbFFVatcdEyqeDBbGJHiVpBHeeujFDHXkiWp")) {
        for (int oxVjiFnzqU = 984941880; oxVjiFnzqU > 0; oxVjiFnzqU--) {
            kJzOUVu += DpdHlNkQlqRfkxs;
            DpdHlNkQlqRfkxs = kJzOUVu;
        }
    }

    return -289905.56312160636;
}

double OkIRSuGxE::pONkaeYcscpBiDv(double dUIWttj, string bBRkWk, int xnFbDzZzcl, bool wYYCbotCut)
{
    int DcOvkaTPFHcERFI = 1434399016;
    bool VllzbZmnux = false;
    int WSXSWpQ = -2123411891;
    string YwnGeD = string("zEhkyMlDnpevagTfGoNnRXAtQwrfZRPYngUIrPjLCcPZ");
    bool Ijloe = true;
    int FGwlynqJahpDPOd = 47929410;

    if (YwnGeD <= string("zEhkyMlDnpevagTfGoNnRXAtQwrfZRPYngUIrPjLCcPZ")) {
        for (int COgdA = 1444886781; COgdA > 0; COgdA--) {
            DcOvkaTPFHcERFI += WSXSWpQ;
            Ijloe = Ijloe;
        }
    }

    for (int FZcouPPQSrSYa = 1446012388; FZcouPPQSrSYa > 0; FZcouPPQSrSYa--) {
        YwnGeD = bBRkWk;
        WSXSWpQ *= DcOvkaTPFHcERFI;
        DcOvkaTPFHcERFI /= WSXSWpQ;
        bBRkWk += bBRkWk;
    }

    for (int IPHzi = 1614506721; IPHzi > 0; IPHzi--) {
        VllzbZmnux = wYYCbotCut;
        VllzbZmnux = Ijloe;
        WSXSWpQ /= WSXSWpQ;
        FGwlynqJahpDPOd /= WSXSWpQ;
        DcOvkaTPFHcERFI = FGwlynqJahpDPOd;
    }

    for (int lkcfbEhHklkg = 1310627490; lkcfbEhHklkg > 0; lkcfbEhHklkg--) {
        FGwlynqJahpDPOd -= xnFbDzZzcl;
        DcOvkaTPFHcERFI = WSXSWpQ;
        WSXSWpQ -= xnFbDzZzcl;
        wYYCbotCut = VllzbZmnux;
        Ijloe = Ijloe;
    }

    return dUIWttj;
}

OkIRSuGxE::OkIRSuGxE()
{
    this->imbWtButyTruxlC();
    this->kzOKoALXDcu();
    this->oNBVnnoglRjxXD(true);
    this->PLALXd(false, true);
    this->zstJnVnTTraGdAf(893529018, -77373.79350228149, false, 650795942);
    this->diveFEoUtIyuw(-1128171315, false, -617283.3342905663, 4353.543055504068, string("ieGGvNUaDTDtlUummliHjGolbrFSWuJMwJiLmayXooMSjIDewwcxwYBpFfBoIrQlUKtdiwvCqvAthzquszHxYdczAXRqErIMlyMqBSYZSFadLSKyTsMdibufMlvWOamcnqczusQAhMpVvodFpBVzBHgKxzUTxkkWWxdRMhgtHTDYddmseyFUxuy"));
    this->PRRzqsmL(-793783623, -226978294);
    this->AONKaZcozd(-595007.7732565474, true, -329026.46514962264);
    this->bdksdtgz(266150497, -481496.5531081072);
    this->HucuTnoFjavqou(string("vkgmIcLiPKdLSvFVhVGbHKhJLWvxJDIfCrqziVgGhQXCUciCrWJagPVyYqNTurflDzsCHFNWdbfWMfIjjvdbXFhbgFHJdQTha"), false, 1011590763, 997795.2790686191, false);
    this->AUSgoWjE(true, string("xVDNVSRQvsRYOAxWePfaSFkcJPaywFmJtZmTIQxLwdfXTYSAJqyJrMMMqchuGxSfpnREUOxeWUhvcuKiWvkwnzqpzyoCbYodlwiXmVoKLPFizowfaPQXVTHjThWfchnmqJjOoLHfQXcLSjyabKSRjfeGtPsCObzqXbTleGJKFNvPaGkyltClDESXKkFFUKcOhDhvTTjKsFtflSgpfEgivURsXTeTRwLoZBQWEkHYAOfTDYSWeCffzla"), 1195106414, string("pTNwrDqjwxcEwKSXPVaBhhsuHRolSDdambHXHTKGwMTzJDtLUAcAGRNehpORsxKZRbPYLZMLNRTGBhNetetJIzpELziSYpPx"), 1821181006);
    this->pVXIQEsXSiAJDQi(-1025435.4486008896, -1024587958, 655121.3944536541, false);
    this->cWpSqtrlCjYXPxpy(-757172.0130740113, -196642.11798722183, 1736069047, false);
    this->eGysHcSpgDmFNjw(-516182.9130366667, string("NebOxfSzlMtzPLIBqTTcJFDvqPCszzcuKFobcUlojnvlmFciuLXYoiXPtXgkHkvWHszfmsGJTLKFEQKBwuIJgC"), false, 851367.5170346422, 266562686);
    this->LhRUJssJ(-103930490);
    this->NIUcI(false);
    this->cRvvZdwh(string("PqBIRVtUgJeEB"));
    this->pONkaeYcscpBiDv(998195.6566459882, string("gPinCZUfZHVbrHNhyjIQisRpyiOMWThrmkEamsAQfJyTGgooelHwZfQIHPQaGQvQnVdaklMzJvAfIKmphCxqIwjCWpbkGGUZRWdgthXOGnuepyWSSecWGyTMqGXHcitDuDtYCpzSfpwAhnmQK"), -2128991060, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yVDlEUqoiZoJT
{
public:
    string eejYOmZ;
    bool jqPIyl;
    double TiYpNSunlcI;

    yVDlEUqoiZoJT();
    void PgerK();
    double WPLZFtwrNM(int EXulbp, int pStpfbH, double UFkVLEpuCU);
    void YdinRGnL(string mplonz, string XuHCODWRgjnAy, string PNpmz);
    bool bxdIdZek();
    bool ZfddZW(double oxJhwjL, double oUApgSSkAlmutpDp, string mqtutfnSHnI, bool lFrgxxf);
    bool DKLQvgYYm();
    int MiuogkZfKRVTl(double MmLNwLUVCUXF, bool GOpmMKXrGOrEL, int vptcJivko);
    void MRwdcwS(double GGDWiuMWv, int pLaIeRvq, string ZQdoIzbNrOs, string mtiDDN);
protected:
    int DmMfxTU;
    string krxVrkyBAUzfx;
    double nzKVj;

    void PktUATanUJfj(double pgTfD);
    string cLnKcXcBUJg(string RYTfGwSadCn, double cIdYzNUY, int vAYfvuc, int swkfvpdIzm);
    string iTUHMluCJ(string gArDzBetecuwe);
    string DxDNTQnRhDxlGsh(double SDhHhUiL);
    int seSMIZLYoRuArT(bool hYhIHhRDcvsvQCD, double AwFpKVnmbrh, string GeCSFoqwitzMez);
private:
    double ptGjJLvXm;
    bool MOXCeIIp;
    string HNgLDgyZW;
    int lSVGrkIFSXkFsBGe;
    string IAqyuiOwHnZc;
    double mgwjtYRCx;

    string UeFyfPdzmw();
    int SeWiLke(string nRxhQZalIhMDrK, int rWLQu, string WjEqvW);
    int caIKrFxd();
    int zflTAvQWMbQGmw(bool KVFPhmrXpiAkFSCJ, int zPPXxf, bool HiFMjYWl, int UgrjEbxsEZh, string TRIjWEVPUPXU);
    string mQiBU(bool ffkqwwFsZdKBSsq, bool JKlvxTsH, bool xyrAECAcnDj, bool lduOqIBAJLvQcObb);
    double KIAawxEdzrQsS(int xppfliruxZwI);
    string ZRvFyhJ(bool iQsJRPEXjophBIg);
    bool eINYgqrLPUgGbm(string XkQBaInnQqWH, double UZdXSdCyevDivYuY, bool VooABlmzsqZlzS, bool bmZcMOUfeThOpxZi);
};

void yVDlEUqoiZoJT::PgerK()
{
    string ifrEzojllS = string("ItcqrmUMlfEtDxfhgWNxnfyPdpngYMXjPjlovSsReQsRUxBeKibdFohkpiyftpfJHjeKdThVQYBstLWbIfnC");
    bool oPGRMnjMbht = true;

    if (ifrEzojllS < string("ItcqrmUMlfEtDxfhgWNxnfyPdpngYMXjPjlovSsReQsRUxBeKibdFohkpiyftpfJHjeKdThVQYBstLWbIfnC")) {
        for (int GSKyGmZtbkKRWSu = 5900565; GSKyGmZtbkKRWSu > 0; GSKyGmZtbkKRWSu--) {
            continue;
        }
    }
}

double yVDlEUqoiZoJT::WPLZFtwrNM(int EXulbp, int pStpfbH, double UFkVLEpuCU)
{
    double eezkyRYJpmuVrc = 734360.476106975;
    double agoUlyiQE = -567418.9832509365;
    string CtdYHwNxdpto = string("BnOFyXgakIZIPk");

    for (int ndeMnyC = 1840790563; ndeMnyC > 0; ndeMnyC--) {
        pStpfbH -= EXulbp;
        pStpfbH /= pStpfbH;
    }

    for (int KCxYhRHYwzymekAg = 1915823328; KCxYhRHYwzymekAg > 0; KCxYhRHYwzymekAg--) {
        eezkyRYJpmuVrc /= agoUlyiQE;
        pStpfbH = pStpfbH;
    }

    if (eezkyRYJpmuVrc <= 321051.21574594616) {
        for (int pylKp = 968185159; pylKp > 0; pylKp--) {
            pStpfbH /= EXulbp;
        }
    }

    if (CtdYHwNxdpto == string("BnOFyXgakIZIPk")) {
        for (int ZfhHChevxnpSox = 1073563621; ZfhHChevxnpSox > 0; ZfhHChevxnpSox--) {
            agoUlyiQE -= agoUlyiQE;
            EXulbp += pStpfbH;
            pStpfbH /= pStpfbH;
        }
    }

    return agoUlyiQE;
}

void yVDlEUqoiZoJT::YdinRGnL(string mplonz, string XuHCODWRgjnAy, string PNpmz)
{
    int tcfvuTgyhrEpf = -1150712819;
    int kHVrXKDZTbKsm = -1197795249;
    string pHjiqavFDtmwhpUa = string("RwCpRLdsKbsHWqqFQvCyxkIdTHmhIaFlOFaPOsCOJCrjTQhnisJTPVjqnJqrEEpmUerFPFSpTKuJXDavppDSUjeFlZGNLhdnQNiLCLARkqPxPoAOpRWFuybBPVYcLkwhHTFRfpkAMvemNOtmHZfjCVaObJHfTLzTWfFvGtLAGlOQvJYtrGZlvDdbqXOhc");
    int AMUEQkzUkuPSvxi = -138959872;
    string MzeiMC = string("cEmGrupJlxIHShpEVggIBYAZjYRKMRClmLflqqIrjVYEDSNQOweBBNwWLscFSczrurmuubLJYMJLIBjCMwsupIK");
    int BZIRlTseSUUuG = 1621068081;
    int FABRwmOtNPTeksr = 1766357127;
    int KQSOprxdR = -1996673209;
    int QqbCdPGqwYQ = -142922832;

    for (int jOtkypU = 1705261189; jOtkypU > 0; jOtkypU--) {
        AMUEQkzUkuPSvxi += FABRwmOtNPTeksr;
        PNpmz += XuHCODWRgjnAy;
        KQSOprxdR -= tcfvuTgyhrEpf;
        mplonz += mplonz;
        PNpmz = MzeiMC;
    }

    if (QqbCdPGqwYQ < -138959872) {
        for (int LAXUVyQUPAHHiDaI = 1903284604; LAXUVyQUPAHHiDaI > 0; LAXUVyQUPAHHiDaI--) {
            kHVrXKDZTbKsm += AMUEQkzUkuPSvxi;
            XuHCODWRgjnAy += pHjiqavFDtmwhpUa;
        }
    }

    if (FABRwmOtNPTeksr > -1996673209) {
        for (int uTVaXZRZFaZuqdJA = 2016730291; uTVaXZRZFaZuqdJA > 0; uTVaXZRZFaZuqdJA--) {
            AMUEQkzUkuPSvxi = KQSOprxdR;
            PNpmz = pHjiqavFDtmwhpUa;
            FABRwmOtNPTeksr += QqbCdPGqwYQ;
        }
    }

    for (int PyHbCKZYNKTI = 1669914191; PyHbCKZYNKTI > 0; PyHbCKZYNKTI--) {
        KQSOprxdR += AMUEQkzUkuPSvxi;
        FABRwmOtNPTeksr = KQSOprxdR;
        PNpmz += XuHCODWRgjnAy;
        mplonz += pHjiqavFDtmwhpUa;
        kHVrXKDZTbKsm *= BZIRlTseSUUuG;
        tcfvuTgyhrEpf += QqbCdPGqwYQ;
        mplonz = MzeiMC;
    }
}

bool yVDlEUqoiZoJT::bxdIdZek()
{
    string fDUAMmPMLWTL = string("OwXmPrhtCezXSWYawtDAYHTLfbenLc");

    if (fDUAMmPMLWTL <= string("OwXmPrhtCezXSWYawtDAYHTLfbenLc")) {
        for (int MBvKNozKKHMBu = 1852669945; MBvKNozKKHMBu > 0; MBvKNozKKHMBu--) {
            fDUAMmPMLWTL = fDUAMmPMLWTL;
            fDUAMmPMLWTL = fDUAMmPMLWTL;
        }
    }

    return true;
}

bool yVDlEUqoiZoJT::ZfddZW(double oxJhwjL, double oUApgSSkAlmutpDp, string mqtutfnSHnI, bool lFrgxxf)
{
    double JGBBJmlOTW = -123661.815178255;

    if (JGBBJmlOTW > 28424.62807414922) {
        for (int JRxJFiDtj = 1570422535; JRxJFiDtj > 0; JRxJFiDtj--) {
            continue;
        }
    }

    if (JGBBJmlOTW == -1001945.2563660324) {
        for (int mFhhKErGUxxxHi = 552183670; mFhhKErGUxxxHi > 0; mFhhKErGUxxxHi--) {
            JGBBJmlOTW -= JGBBJmlOTW;
            oxJhwjL -= JGBBJmlOTW;
            oUApgSSkAlmutpDp /= oUApgSSkAlmutpDp;
        }
    }

    if (oxJhwjL <= -1001945.2563660324) {
        for (int zqfqQYEDSl = 1600735456; zqfqQYEDSl > 0; zqfqQYEDSl--) {
            oUApgSSkAlmutpDp -= oxJhwjL;
            oxJhwjL += oxJhwjL;
            oUApgSSkAlmutpDp = oxJhwjL;
            oUApgSSkAlmutpDp *= JGBBJmlOTW;
        }
    }

    if (oUApgSSkAlmutpDp != 28424.62807414922) {
        for (int IFVKnZXVFqAwY = 310559930; IFVKnZXVFqAwY > 0; IFVKnZXVFqAwY--) {
            oUApgSSkAlmutpDp *= oUApgSSkAlmutpDp;
            JGBBJmlOTW = JGBBJmlOTW;
            lFrgxxf = ! lFrgxxf;
        }
    }

    return lFrgxxf;
}

bool yVDlEUqoiZoJT::DKLQvgYYm()
{
    bool WKEqnLgJCuUKLKwC = false;
    bool gcGpfjZfF = false;
    string PxyeFXdHVy = string("wanBHpKgqphGgv");
    bool rfcoduCKkpl = false;
    bool unuVarfZIwNRbqqp = false;
    int HZsddEfAYgp = -633807107;
    int EAFFarCbLrA = 739312442;
    string ZokFTO = string("jkvhXFZORfRDzyQysgRLZDVjjLiWZVhzSdWJiOXubuswFcdaEzQJWJEGUQZeibAZanYggugHmmHIiQuYXJHbxsxGRcWxNcGlrhPSkwPiqrxOZrNeqdVRFDxeCDxpDNixOIDJQoVqLJLSVMEMFLjOjVcsHqeXYeqQCfJaPqmMsSIHPiwixaPS");
    double sjUeNQjjvzGdaM = -603080.5943657138;

    if (gcGpfjZfF != false) {
        for (int EfKKAfw = 854719003; EfKKAfw > 0; EfKKAfw--) {
            continue;
        }
    }

    return unuVarfZIwNRbqqp;
}

int yVDlEUqoiZoJT::MiuogkZfKRVTl(double MmLNwLUVCUXF, bool GOpmMKXrGOrEL, int vptcJivko)
{
    double kRGSCAGOd = 1028029.9684609473;
    double mdyyFGDx = -136809.92655500394;
    double XZQVIHtN = -577423.5815586345;
    int yHIHIRZ = -416756018;
    int DMcQiLFreTYibRhk = -2061838846;
    int xRDliEVJwehvCmRM = -2063674198;
    double bEQVhJmemQfUlJl = -771151.6152068543;

    for (int HMPbB = 1462806196; HMPbB > 0; HMPbB--) {
        yHIHIRZ /= vptcJivko;
        vptcJivko += DMcQiLFreTYibRhk;
    }

    for (int sjmVy = 1050679453; sjmVy > 0; sjmVy--) {
        mdyyFGDx -= kRGSCAGOd;
    }

    for (int CXBrVd = 310127224; CXBrVd > 0; CXBrVd--) {
        kRGSCAGOd += bEQVhJmemQfUlJl;
        XZQVIHtN /= bEQVhJmemQfUlJl;
        XZQVIHtN -= kRGSCAGOd;
        mdyyFGDx = bEQVhJmemQfUlJl;
    }

    if (MmLNwLUVCUXF < 743967.9528639312) {
        for (int HcFiVIH = 1197912168; HcFiVIH > 0; HcFiVIH--) {
            MmLNwLUVCUXF = kRGSCAGOd;
            yHIHIRZ += yHIHIRZ;
            DMcQiLFreTYibRhk *= vptcJivko;
            MmLNwLUVCUXF -= mdyyFGDx;
            mdyyFGDx -= XZQVIHtN;
            DMcQiLFreTYibRhk += yHIHIRZ;
        }
    }

    for (int AdBoNz = 714530797; AdBoNz > 0; AdBoNz--) {
        continue;
    }

    return xRDliEVJwehvCmRM;
}

void yVDlEUqoiZoJT::MRwdcwS(double GGDWiuMWv, int pLaIeRvq, string ZQdoIzbNrOs, string mtiDDN)
{
    string UofTJaXLbrEKqT = string("GNUXUKLDUzykAeXtMSqMLQALLIFhsUiemFmFWywtnE");
    int aAHna = 1627335001;
    bool rqGZJwabNyO = true;
    double qAnZABJ = -971440.4586998104;
    bool BgohNTU = false;
    int QCSfQzTBmrDjeR = -649962908;
    double ytUlNhYwBoqH = 146792.9615458791;
    bool kqKzRozFvzlIr = false;
    string vohVw = string("zzkBACvWhfgcFVmpdTOhkJpVixUmOndwO");
    double KupMcgzk = -471400.89753256325;

    for (int nRsfZaCY = 555663316; nRsfZaCY > 0; nRsfZaCY--) {
        GGDWiuMWv += ytUlNhYwBoqH;
        mtiDDN += vohVw;
        GGDWiuMWv *= qAnZABJ;
        QCSfQzTBmrDjeR += aAHna;
    }
}

void yVDlEUqoiZoJT::PktUATanUJfj(double pgTfD)
{
    int DpwKCGggapli = 1841962562;
    bool KsKwA = false;
    bool IItaNvkoPQR = false;
    bool UAoEqdR = true;
    double dMKhXboIydQc = -780718.5769109776;

    for (int CiOIgKBi = 1190437355; CiOIgKBi > 0; CiOIgKBi--) {
        continue;
    }

    if (dMKhXboIydQc <= -780718.5769109776) {
        for (int xWKRWTEaseZSYP = 1614708278; xWKRWTEaseZSYP > 0; xWKRWTEaseZSYP--) {
            IItaNvkoPQR = ! KsKwA;
            UAoEqdR = UAoEqdR;
            UAoEqdR = UAoEqdR;
        }
    }

    if (UAoEqdR != false) {
        for (int lIgWgDRFeqkj = 184901533; lIgWgDRFeqkj > 0; lIgWgDRFeqkj--) {
            IItaNvkoPQR = ! UAoEqdR;
            IItaNvkoPQR = ! KsKwA;
        }
    }
}

string yVDlEUqoiZoJT::cLnKcXcBUJg(string RYTfGwSadCn, double cIdYzNUY, int vAYfvuc, int swkfvpdIzm)
{
    bool MYpdxG = false;
    bool sxcGbG = true;
    double sIsopbUo = -268571.79379984667;
    bool wtqUjGlWSBBEyiq = false;
    string FFohuYMZ = string("kFQZDBhpnvfxuxwqIVHUpOFJLyhgdgagQmYqLlpsznJHJhiFftXFbFPrMnTNegVjwNnYLOcOnkWLnODLLLXlDdzqEJXaFxgbyOaIInWFSHGxUxiTlmWofadKwgNUjiBzLHFpHmGDstlaMNLRmZrNaikBDlQryZnvxcVsmMnyLhXXFuUFfoUNoAgBsWglrulaNgiZchJuoNYCOmvfEFPcdESZtopbrW");
    string TBZrmCkEywWrS = string("TuLdjshcyBiAQXKrwnIvhmThECgMUYDcQTPCmyJEPRmDPAtDTXKtwlMr");

    for (int tyinjdZFUQ = 689849058; tyinjdZFUQ > 0; tyinjdZFUQ--) {
        continue;
    }

    if (wtqUjGlWSBBEyiq == false) {
        for (int NdckbZuQnuiLQm = 518182514; NdckbZuQnuiLQm > 0; NdckbZuQnuiLQm--) {
            TBZrmCkEywWrS += RYTfGwSadCn;
            TBZrmCkEywWrS += RYTfGwSadCn;
            RYTfGwSadCn = RYTfGwSadCn;
        }
    }

    for (int jLLStgGPMXu = 1802398466; jLLStgGPMXu > 0; jLLStgGPMXu--) {
        wtqUjGlWSBBEyiq = sxcGbG;
        FFohuYMZ = RYTfGwSadCn;
    }

    for (int EXYdieQ = 889179501; EXYdieQ > 0; EXYdieQ--) {
        MYpdxG = ! wtqUjGlWSBBEyiq;
        RYTfGwSadCn = TBZrmCkEywWrS;
        wtqUjGlWSBBEyiq = wtqUjGlWSBBEyiq;
        sIsopbUo = sIsopbUo;
        TBZrmCkEywWrS = FFohuYMZ;
    }

    if (RYTfGwSadCn >= string("TuLdjshcyBiAQXKrwnIvhmThECgMUYDcQTPCmyJEPRmDPAtDTXKtwlMr")) {
        for (int FQaZtbZnH = 2056238579; FQaZtbZnH > 0; FQaZtbZnH--) {
            FFohuYMZ += FFohuYMZ;
            cIdYzNUY += sIsopbUo;
        }
    }

    return TBZrmCkEywWrS;
}

string yVDlEUqoiZoJT::iTUHMluCJ(string gArDzBetecuwe)
{
    string HOLqsXunPag = string("kIJFOzVOjXnDKdzMaKRrnBQQJNrJAyDtbBTwgyPGzokdJajmrJNoGwAAXhxEQehHlngGIkQSBlhsqSueHQrzI");
    int CdqMIzWBy = 1239236522;
    double RGYaHinzLgkQ = -695634.358748025;
    bool gSAaoxCh = true;
    string lSuSziByryZnx = string("JFRAGkAFoISBqpKBYYvZtyZyFoYjNNU");
    string gnhktO = string("hVOJLbSkoVLeNLZvZpcIbNZyEZXLqbCGgDEtlsDoxekovecFkCrKEdplGuEzaBjPpeyPdnPtRSLOZrtsxVZVwYPfbFZuUGmmSYOoJYhpBDRNEDbegWHmSbmeNJXxEdOLBWKUYKFkcsNjAjDpZSxYncTrBNEKDhRYBCMcyomqRAFDrIwGPmZlXOFYogFIudzkGXlrpvjqtHaXunQpaBQLBKhECxWTicjWtEgVo");
    string WeFbBTciChJpvYAc = string("XIZYibjWlTCOdkanuxZaqwMOlJlxvzoIzihqQNRzKkOHtjatCjcPXKYlgFleKYfunqPqrhDAgKMYwvELsQeQcpmUNpJEhhoLXCSzcSJgRQqJGiCcIMJGBbhLcgmuLJiKGbUxBSkTqXOnThpvwxprMUzmJSdCmPLsDIHyqsrEOCMQTUoDTquyhSJjBfLAfUkYaYPlOEnAAHbnqJbgohSeUnIhiVhzPBPrOkncLRmS");
    double HWrzwuUTmOUTeA = -906666.6831341198;

    if (lSuSziByryZnx > string("kIJFOzVOjXnDKdzMaKRrnBQQJNrJAyDtbBTwgyPGzokdJajmrJNoGwAAXhxEQehHlngGIkQSBlhsqSueHQrzI")) {
        for (int IEDqaw = 142609540; IEDqaw > 0; IEDqaw--) {
            gnhktO += HOLqsXunPag;
            HOLqsXunPag = gnhktO;
        }
    }

    return WeFbBTciChJpvYAc;
}

string yVDlEUqoiZoJT::DxDNTQnRhDxlGsh(double SDhHhUiL)
{
    string FYpEgzjbBhcCE = string("OaaIlkSzCULFEWoMHAFwVdhLrIumjbbbQSIuWxHxdWoGJYCFMJAnoMHkRzmbCOOTbiwKFesCejJRmiQMKVAPGxPfTnUCiGipgQDiLFemsTwSEHwKQCAterxOJCXBfVfXoIhQvIsmaMaimVDlpcYWepaMTrWGYnKrHggdOVpxkZgIKqdlzLDjKnViLiAAVZToOMsTZiVSqRQua");
    double myPcybe = -621083.1399228454;
    int zvWumhxAtTelNeEb = -2107899624;
    double tvefEEb = 433904.586311905;

    for (int gVEGRoB = 1915576582; gVEGRoB > 0; gVEGRoB--) {
        continue;
    }

    if (myPcybe != 433904.586311905) {
        for (int DVpigTYu = 799099220; DVpigTYu > 0; DVpigTYu--) {
            tvefEEb += tvefEEb;
            SDhHhUiL -= SDhHhUiL;
            SDhHhUiL = tvefEEb;
        }
    }

    if (myPcybe > -621083.1399228454) {
        for (int cynXjwG = 1115010019; cynXjwG > 0; cynXjwG--) {
            SDhHhUiL /= tvefEEb;
        }
    }

    return FYpEgzjbBhcCE;
}

int yVDlEUqoiZoJT::seSMIZLYoRuArT(bool hYhIHhRDcvsvQCD, double AwFpKVnmbrh, string GeCSFoqwitzMez)
{
    double rtGjJmhHY = 534503.8721097175;
    int gopnQAaQQH = -853180110;
    double aJpxuUQCoWBHY = 347347.1154215244;

    return gopnQAaQQH;
}

string yVDlEUqoiZoJT::UeFyfPdzmw()
{
    string mwWwzmmlAdwFmG = string("DLsITAGGfjwCtGFGEeXbUHiRMBVYTouHueypkrvEgAaxmPUQgnNlLguc");
    double fhWdtvuDyn = -190120.26497182724;
    int eBkFyCtQkuQEAr = -222128833;
    string DKDOMIvgw = string("DfEpAllFJQCGRSZELcWJFcuxVgThWHjVywGGnlKMaRiRfLXejusObuMnBcufHqpyBpWHkSxEboEOIbaIkLyETZaYtHdLFzLRplDW");
    double yQdLnVo = 628282.9750342226;
    int gzuKZlLUs = 1243254348;
    int PcFNN = -1366879417;
    int tScrR = 927812966;
    string wnBDDDUMzjS = string("FWrZFCdjphSsIcIytlUQLXURTiMsNkSGYmSOHYcJYOinFFpgexFhHqlvYwQfRjoUQiYYkJIpxzoOiDPPXOSyvFGTdbrchRwotNyHsewmdQdEzpEvfuawCvWjTNNIdKxtYslMdmYODtHTAaClQhguMoRVnaIUmOdYMlUlEGsoLVVmqbiHqE");
    int lbQsCHjraegZRi = 553658934;

    if (mwWwzmmlAdwFmG < string("DfEpAllFJQCGRSZELcWJFcuxVgThWHjVywGGnlKMaRiRfLXejusObuMnBcufHqpyBpWHkSxEboEOIbaIkLyETZaYtHdLFzLRplDW")) {
        for (int CPklFGbMUxDX = 1771112694; CPklFGbMUxDX > 0; CPklFGbMUxDX--) {
            PcFNN -= PcFNN;
            mwWwzmmlAdwFmG = DKDOMIvgw;
            PcFNN = gzuKZlLUs;
            gzuKZlLUs = lbQsCHjraegZRi;
        }
    }

    if (PcFNN == 1243254348) {
        for (int ZlqHWHXHlGy = 803839288; ZlqHWHXHlGy > 0; ZlqHWHXHlGy--) {
            fhWdtvuDyn -= yQdLnVo;
            lbQsCHjraegZRi -= PcFNN;
            lbQsCHjraegZRi += eBkFyCtQkuQEAr;
            lbQsCHjraegZRi /= tScrR;
            yQdLnVo *= yQdLnVo;
        }
    }

    if (lbQsCHjraegZRi > 927812966) {
        for (int wwLmfG = 1886563680; wwLmfG > 0; wwLmfG--) {
            wnBDDDUMzjS = DKDOMIvgw;
            PcFNN -= tScrR;
            PcFNN -= tScrR;
        }
    }

    return wnBDDDUMzjS;
}

int yVDlEUqoiZoJT::SeWiLke(string nRxhQZalIhMDrK, int rWLQu, string WjEqvW)
{
    int ITvCM = 960830221;
    int wyhpfgMZ = 1261032633;

    for (int ijeKGYyTej = 1739801264; ijeKGYyTej > 0; ijeKGYyTej--) {
        rWLQu = ITvCM;
    }

    return wyhpfgMZ;
}

int yVDlEUqoiZoJT::caIKrFxd()
{
    double pwyNuKodiH = -780878.9682294221;

    if (pwyNuKodiH >= -780878.9682294221) {
        for (int odsUBKht = 760143320; odsUBKht > 0; odsUBKht--) {
            pwyNuKodiH *= pwyNuKodiH;
            pwyNuKodiH *= pwyNuKodiH;
            pwyNuKodiH += pwyNuKodiH;
            pwyNuKodiH /= pwyNuKodiH;
            pwyNuKodiH += pwyNuKodiH;
            pwyNuKodiH -= pwyNuKodiH;
            pwyNuKodiH += pwyNuKodiH;
            pwyNuKodiH = pwyNuKodiH;
            pwyNuKodiH += pwyNuKodiH;
        }
    }

    return -1181125454;
}

int yVDlEUqoiZoJT::zflTAvQWMbQGmw(bool KVFPhmrXpiAkFSCJ, int zPPXxf, bool HiFMjYWl, int UgrjEbxsEZh, string TRIjWEVPUPXU)
{
    int EHkTVErIowS = -18382858;
    int HhYBA = -742212787;
    double uPVCzewTVLOFQNq = -433536.3557074663;
    string YrtXJCQt = string("KqRZyYkfWYMvoQjSyIGbAPunKBBwoSwkoWyUgCxfXneeDzNjWFLPUVXWDsqEgwvWiRafdhRFupSJUdjlscpKiPxvqaEqdYCMRepOTHCkcypUlLjmeyoHeJrWWnDlCwtRLFUOfKrh");
    double dMKMIoUEIAtPlifH = 536352.6614987678;
    double zQbkTXNgunXLNRDy = 62677.9707839258;
    double sIhqXIKOuUykBJ = -95867.73055035858;
    string LOgaVUgPoel = string("gbzktVXUmQAfwgRaHwaLGTsQjoZVXtmftxXzcgeDgELWORoWVXXDzgKPbqbZGkpcTKLqZUIRkjgcwjjRmlziVGOaYsDyzjPyvrPVoLOfIRVaYAsXSJRnbQuuOYhejLYcpEDkvGMOTGGTmlRxASDxgbdboezvUERglOPqkvxYlfRihzZqyWulbMuJFhviGKlcleZRRdlRmrBZkjJkprHWBfOQvkZiWXhGpgxuDNMTDNYiXwAWbep");
    double kmigIsWq = -427430.17758863984;

    return HhYBA;
}

string yVDlEUqoiZoJT::mQiBU(bool ffkqwwFsZdKBSsq, bool JKlvxTsH, bool xyrAECAcnDj, bool lduOqIBAJLvQcObb)
{
    bool SzOWzRcc = false;
    string xqUCfJchwDtYg = string("KsogunxVqOPjFHviczasZOogJlEwTTQLDgHYusTGnXxhwijuDMPNicvGksedYVUZdVTwsSKdqUgbHZKGvxsbFVhKFOBbKhPUwYKcEPrljlWwVTIQqtXYTvhvyBhnFlzRpnsEcLqjwZvfaFanLYRCWjudYGvyXvybRfuEgbUeIPWcKfLAtILxyRYuRrAJSFtfCNjnSFDqNggyTitTkmoNpXKNQOZVjAcNJBCcmymFheio");
    string MoZnE = string("mnioKvrBdOnTmyEGvErSOGnJNKhyFgllNSkjYJsmYNTXiROhUXPJHIjTNGPALjNjOUiPYNfjAAvqGNkWTYTsdPeuCeMGpsdQhriPmAcCliTiWXHOscLJVydNPnwwAVRLGxaLrZDbVJAKEfcfriUbAteXLRTJMwlqaNLwYkXwTxotrlXRkIccTqtQzmlLgAttckgMyWiZLKxpEUluYIVyCimdsRXAIBqtvuQBOKGydYbjzwmkUFDHwqNxFBhR");
    bool XrNZUMU = false;
    double KsgcTenGBqCPIP = -781573.9606178171;
    int HUbCWbRDKi = -2047356224;

    for (int jUSvTN = 1656984045; jUSvTN > 0; jUSvTN--) {
        xyrAECAcnDj = XrNZUMU;
        ffkqwwFsZdKBSsq = xyrAECAcnDj;
        XrNZUMU = ! xyrAECAcnDj;
        ffkqwwFsZdKBSsq = ! XrNZUMU;
        JKlvxTsH = ! SzOWzRcc;
    }

    for (int FxyHaGTEJgsdgNXq = 1900306068; FxyHaGTEJgsdgNXq > 0; FxyHaGTEJgsdgNXq--) {
        JKlvxTsH = ! JKlvxTsH;
        lduOqIBAJLvQcObb = ! lduOqIBAJLvQcObb;
    }

    for (int HMNIXNOpCKXDC = 1457244556; HMNIXNOpCKXDC > 0; HMNIXNOpCKXDC--) {
        xqUCfJchwDtYg += xqUCfJchwDtYg;
    }

    for (int gHtyVKxDUczFixD = 1292082095; gHtyVKxDUczFixD > 0; gHtyVKxDUczFixD--) {
        SzOWzRcc = ! SzOWzRcc;
        xyrAECAcnDj = XrNZUMU;
        xyrAECAcnDj = ! JKlvxTsH;
        JKlvxTsH = ! lduOqIBAJLvQcObb;
        ffkqwwFsZdKBSsq = XrNZUMU;
        lduOqIBAJLvQcObb = ! XrNZUMU;
    }

    for (int SwSBfvU = 2059528909; SwSBfvU > 0; SwSBfvU--) {
        HUbCWbRDKi *= HUbCWbRDKi;
        XrNZUMU = ffkqwwFsZdKBSsq;
        JKlvxTsH = ! lduOqIBAJLvQcObb;
        JKlvxTsH = xyrAECAcnDj;
    }

    return MoZnE;
}

double yVDlEUqoiZoJT::KIAawxEdzrQsS(int xppfliruxZwI)
{
    bool jqJQnDqLZEVEnOF = true;
    bool TyYVaKBQ = true;
    bool aZNfitDtoYLvcks = false;
    string ALYkSWExARHWg = string("IGvoOWWZdtuBdPdMOuMpvdLLXSNsvsegEwVjcJZbhImgpKAxkgzpfSggjzwkhshYabvlaQpzpOWKRzDMalhpDgTyMfPWXXaETDitFDmhfyo");
    string tArRGimELyFUOEJ = string("HFQZyFSCPDv");
    string glKCwBm = string("yjleyDAFsuCAqnKBrcCBmaLYjmgLoGecuMFDBydXWRZKHACKEUtFoDUwFpLAXaWmAKmCkWdEpTQMNVeKEsOTgtrQWdYHsXzcIuDSClqLIiVcYmVYmIefQGbwhqjshUQnIbMDZirFlWwjDQxfiOekaiPVlIqJTzYEzLdQiRfuZVIvMRaNNakkAlUWZNIVrZMDDOeHkytZ");
    string KWpmTWWguXAl = string("ocBvwGCslojnXglkRgJtQXaQQiy");
    double tHzXCXyDI = 762099.562916451;
    double QASuHcVyFevexTA = 45527.79273551723;
    double ZxbwmSWgYl = -284973.1327948021;

    if (tArRGimELyFUOEJ > string("ocBvwGCslojnXglkRgJtQXaQQiy")) {
        for (int DSnEzqELjLO = 210939622; DSnEzqELjLO > 0; DSnEzqELjLO--) {
            glKCwBm = tArRGimELyFUOEJ;
        }
    }

    for (int yELdukHaUFMhxus = 158139042; yELdukHaUFMhxus > 0; yELdukHaUFMhxus--) {
        aZNfitDtoYLvcks = jqJQnDqLZEVEnOF;
    }

    for (int iqaMDOAN = 1471047255; iqaMDOAN > 0; iqaMDOAN--) {
        continue;
    }

    return ZxbwmSWgYl;
}

string yVDlEUqoiZoJT::ZRvFyhJ(bool iQsJRPEXjophBIg)
{
    bool rzoGswPTvBMO = true;
    double gzAIo = -811208.6575522552;
    int IhyslwA = 938293122;
    bool iCcgCVoDqezxDNvx = true;
    int lcmKUiAlmkQXxaHY = -1799169343;

    if (iCcgCVoDqezxDNvx == false) {
        for (int qKazHkZdnM = 1540228637; qKazHkZdnM > 0; qKazHkZdnM--) {
            continue;
        }
    }

    return string("qjfjNZMrKVQxxGAMAmYhrpiclouNshrtCMgtxJAnAvzIEHHcnONpvNIgxWaovwlKOtDcYPzSUdOPBqGrtEGbkRVGLeMBJDFRYOOWVwJSzbtKWriqNZkvoYZUgCmeHJBMtdJHAKFMmOirSxTgWMAlCBZkmFmbWZxgshnltlxOPuWcUbQhZynrunUggJxOPtJjhLZWxrznCvcTVoJnAfDkktGakdKdlpmQXMJmaOwuf");
}

bool yVDlEUqoiZoJT::eINYgqrLPUgGbm(string XkQBaInnQqWH, double UZdXSdCyevDivYuY, bool VooABlmzsqZlzS, bool bmZcMOUfeThOpxZi)
{
    string ZddEyWvyKewMBr = string("NxypBjOmrMXgMrXjMpogFHzFRFJTLAbggcFjgRlkXqAhaYwJKUaBABEATlAVJFZhCkplgf");
    double WoQYUYr = 963754.8083791113;
    double ubnjeQwjZHaE = -791341.1036649024;
    string zeQUxsxcAHodrX = string("ATzTeudMyndnQEPUuhOzOshkVXzkwXnZzxdtFVZkwfNUJmMH");
    bool gWhnm = false;

    if (bmZcMOUfeThOpxZi != true) {
        for (int REIWNftjKmzugD = 1989087225; REIWNftjKmzugD > 0; REIWNftjKmzugD--) {
            continue;
        }
    }

    for (int UFAshdpicOVmRjY = 1216833947; UFAshdpicOVmRjY > 0; UFAshdpicOVmRjY--) {
        XkQBaInnQqWH += ZddEyWvyKewMBr;
        zeQUxsxcAHodrX += zeQUxsxcAHodrX;
    }

    return gWhnm;
}

yVDlEUqoiZoJT::yVDlEUqoiZoJT()
{
    this->PgerK();
    this->WPLZFtwrNM(133211410, -335989427, 321051.21574594616);
    this->YdinRGnL(string("YLKVCKLwQgEBVMLZdmauhPEzommIcuwulEkGkteRzJDVMFtWDjvRhZGbNHSUBPpIWknwdzNISICblkBEnPDbvROLFTWryvjQxggToKKzwceMffSkfKIFnbUvNMUCgSbGjwtOXKKwsmURxwdtcfBWpEukTgrHdoFnsuRblNDJHx"), string("MYjckVYbH"), string("vhChtSJANQlipzJjaXRfxnDntUfwFzmZ"));
    this->bxdIdZek();
    this->ZfddZW(28424.62807414922, -1001945.2563660324, string("IUEkHIGibPqlvafilAnvkSiPoYWepQXYnoqxQzSEeCOsntIpDSAdpFMsdbaPmTQlAAlZN"), true);
    this->DKLQvgYYm();
    this->MiuogkZfKRVTl(743967.9528639312, true, 1655913980);
    this->MRwdcwS(71613.13323252813, 548127057, string("PUtIdabhJJHjSvxvLjVdhAoVqYFZrXfNQXwCsvTzuIohZnuZOudbRZzmiozejqusPFAjdmsAneFrBdlEBNAtgzhhjOfSmZZpTdzxsdbaWpevPoepqqnOvwo"), string("pRGrKTvnwbWtHvGSTgIZfaZhGgHyNQpSRIPOrpkRhHiDwpbtIUFkvzpkJANyvUOCLjGibqYh"));
    this->PktUATanUJfj(22147.62880574205);
    this->cLnKcXcBUJg(string("JtbBBJKrkSjlvxYSsBJeNhsAqyqztnGrSCorEyLPnvHbdkRUfjYycChhyEUnLoIHtFeFvAhFIjfWvrFJTJgYVXBoYCNMhZyEfDsSoyPMyAhWGV"), 952604.2094384957, 759497151, -760590412);
    this->iTUHMluCJ(string("AxnnvHMJxpGvMyadpfuWUFiKUCIrypwyeIWUUWMfOFXsCnYapcQGAfFllzMrBzcsenkeGHDMbEsVYRHJOJeNoBlXLZlLqZlozOZuFUitdgXvVoKFBFQaJfnnqEvntSufgTVNwRvjtozQwVzEYqBeZHgIlyJuzHKzFYvqkDETzLnGOlCyfVvhxURxxXeoufrCSxBy"));
    this->DxDNTQnRhDxlGsh(556466.4231328288);
    this->seSMIZLYoRuArT(true, -565505.505666857, string("aAWyvCQYgXzYmkKBYbXtEVpzKQkGMzsNYvXZspugzsaiUPKDiHwGgjWHwYYWQxEabvMUFCGKayZxolsJbmZOsoPSZSWUoSJzttlvJjtvulLjPChdMF"));
    this->UeFyfPdzmw();
    this->SeWiLke(string("CjwxXjhFQWzQvQaDgbdERckWAHMIfjEuBYJQxfmXSiXAYhBMAbBVHbwRJUQyCePSWBUKWzsokTkMPsZgagcygoupVlyJZpGriARPGxsgYkBjPKGHsvmmfTGDJRJNPuAXQOIxHuulTiHnwmNKkPMGCfYPTHpbjnuWCbPapnnCZnDfBYhDpOsiYCCONzVcieVHbVgiYhxkPbNGmHwAJtqbmF"), 779684555, string("YhTXZqWoTmlDumLmGHJdxtpkBTrtqkVNnIeHDrIOwOshvSgtCKNKpEipTLCoCpaqDrAUlTmLPmgSjPyMqseTUBEqrCNtyIJOotpuNTdzEtoZwjtQjcfQbczBGgzHDElv"));
    this->caIKrFxd();
    this->zflTAvQWMbQGmw(false, -1048768620, false, -677835235, string("giYopMAmjUWvHtSgwOcPZjiriFoIzxFIinUSdbfNpbcZacyTPpSRrTnS"));
    this->mQiBU(false, false, true, false);
    this->KIAawxEdzrQsS(-1923104034);
    this->ZRvFyhJ(false);
    this->eINYgqrLPUgGbm(string("iwquEhbYLHotewShYBOwOhQzkeIRfbYQMzyshSuNiabPdBJAbTlWicBkgeMzzNmtBrpcIphfGChNTcRveqapWA"), 270092.2334676175, true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BmPaz
{
public:
    bool hlLgwfJPNngsmry;

    BmPaz();
    void GAbnQGQgREF(string uvxgPKGNmzvaq);
    int auoUJzRVfcSV(string YYGQeR, double TJjrTQjBmFbyex, double FpAZkKcEXEdEo, int QsHgPxzNG, int Cyxgac);
    string ogvgCfoJGmPj(double QweYlIME, string nEnJInFwrp, bool gWGoUIvPqYErbY, int TQhzTWRdXeMbvw, bool BzTsilZP);
    string OnCRtTeivr(bool nUkAhvGcOeRLiS);
    void PGzGpeA(string ZzXuSKzxpQyvSW);
    int GtBIPf(int nVLixxnmx, int zxpkVk);
    double iKjvFUGwB(double zvlahhCBetqUecvy);
    int tBlQUakTqpY();
protected:
    bool lgUqRRGKQxI;

    bool UmqGfoDugIHrj();
    bool uZzKNghOwywpYRub();
    bool FeDZbGoFnOVq(bool sbLMdLrgoi, int NRbbwTCOJuU, string hmcEwziXIMbXp, string DUqVIdvv);
    double QKWmesefPTWU();
    double QhzJJCL();
    double IpZKBbTOp(bool CBOaR, bool XrqfiRsa, bool bMadrOHjsmDj);
    double TWbMxrRBdqr(string UCgONUXmTHBkr, bool SvshhbnSzLuU);
private:
    bool EplIIWhXGyh;
    double QyeUc;

    string exZXzSJmZqElnnB(string MWdaBQXqTbxSFAR, bool bxLQOoSeXWVnuhNX, string ttXCYHl);
};

void BmPaz::GAbnQGQgREF(string uvxgPKGNmzvaq)
{
    bool rXZZiYqCLu = true;
    double VwJOUKMuQBsBOrV = 865808.6867406458;
    string mCqJoPHIU = string("OPzlAeKzNqAwhnmWJSMioGXPgZxEJVJBkEjouadxPCHtmmBfAkvQVidxtO");
    double EoELjElDCSuYBN = -539012.9871679884;
    string DILMylMyVgsZ = string("cNXhdwBOjXEoVHoDFWTTMmpwxFbmZCswCPLbOIjOmaOjICKzsPiCZzyMggTfThjFgGsKunpxCrtWCIvvsLQTnEQQaOKamKnGnFzfkfWUEYfwNGHziKcVcHDMiunXSTqLQQiefkAHdorkTlNhrbIuGUZzcKwfXK");
    bool vSmyIzgdbgZFT = true;
    string TDWscq = string("ExybvCKlFNuhqiBSsHnXBrGfCOHlkYZrDzUCFBywkUVeYguAFQBLIhMXbMqRpZZhQOveYOIXQoSagLtkiemjjwmNPdzjsGkFcYZigHzLZwVLFFaCxvCPEQhynQbQQACkAfQrtrvhyCSFLjOQKYDHoFYaulrcdiRSzUkQWIOeGefhfjyUHFQrWJtXbkyXoZCcUYYakFXBPdRosInSbJuJxIlDsAZtyVugUqyYMNuopEuRYFARFVTdyTLRzE");
    int xtnTcXkCFnx = 283197724;
    double JmvQaI = 836591.545366902;
    string XidpSpLyKVtpUYi = string("pNtHcmjNCPgsbGCYBaWvGDJDubPomNrPQxPeeNiXNLyECCokihBVUGwMSKLupqZdcrgEzWozdntKFpBofThNthbLZVuLXDLVXEmqHZpRqpmXcWdmgXAbSiYVUxzrntuQPUUtIyKIEqYsKWspJndakBRkbNdYqffxdYecjHLIobtWsiIBIFicX");

    if (xtnTcXkCFnx != 283197724) {
        for (int MUWWSgKhNdjhN = 848544335; MUWWSgKhNdjhN > 0; MUWWSgKhNdjhN--) {
            VwJOUKMuQBsBOrV = EoELjElDCSuYBN;
        }
    }

    for (int dlCEPVNRCkQOpKw = 722941332; dlCEPVNRCkQOpKw > 0; dlCEPVNRCkQOpKw--) {
        continue;
    }
}

int BmPaz::auoUJzRVfcSV(string YYGQeR, double TJjrTQjBmFbyex, double FpAZkKcEXEdEo, int QsHgPxzNG, int Cyxgac)
{
    string ZfSwyDBFLizlDSU = string("nmiMRuaANoesNgRMTSxuWFOwLYjDCWfmWxBpqivBuDfUimzXTGCtGqARjPBqLYcfLW");
    double SArPkbPgPBsuQsH = 129953.5906949319;
    string TLWVWswVAGLiyBSa = string("WFicKtgtnkdMxMtZqbHyQQkQboSqUNrmjmrsVrwGHMpBTuocKCBsGILRKXCMLqNdeXqzboeOyafKsTgvoAmqhMySeIXxVhiiDQztPAsw");
    bool UgGigThaBFKL = false;
    bool xYRMdpuhBM = true;
    double YjdEHIQfZUvuAG = 667418.3433285184;
    bool nHOwXUaeTKzyivhY = true;

    for (int KKjjk = 329688703; KKjjk > 0; KKjjk--) {
        YjdEHIQfZUvuAG += FpAZkKcEXEdEo;
    }

    for (int fnQDmQJgilP = 625587584; fnQDmQJgilP > 0; fnQDmQJgilP--) {
        TLWVWswVAGLiyBSa += TLWVWswVAGLiyBSa;
    }

    for (int nUPXtcnnmUZdQ = 1015783045; nUPXtcnnmUZdQ > 0; nUPXtcnnmUZdQ--) {
        continue;
    }

    return Cyxgac;
}

string BmPaz::ogvgCfoJGmPj(double QweYlIME, string nEnJInFwrp, bool gWGoUIvPqYErbY, int TQhzTWRdXeMbvw, bool BzTsilZP)
{
    int FMZnqekbECGHG = -629190248;
    bool OvpkrL = false;
    string ocODf = string("aXAuHQxMPEnckqCYUKvTolqJTSSGbosgYBgpsTqBtjOJXyFkOkRoAScpPgxYuAnJrgUJhBNecZBlcsMhdHBoedJVXwdRGvCDrqDaRATrKVULNhrUcBEX");
    double LhYzbbUFbdMB = 124844.96919743596;
    bool PBhqXWb = false;
    string WpbYXevyFS = string("YZFzIsRqvVOVUjkObNuihDygOopBHbpBsYvmvRWRAXZLwTZAYWSeqnvhaTuktTvzhvgXXFtjDtkalIdbaQLCuHzYHPMsvJUOiCTTbRhGNHSxPNwjFTQskZb");
    int gVvAMv = -2059110953;
    string uLyGAwdgqEN = string("FQQaszKSBlRJDXQdazukqGQkBPeVzUzskLQZjfYDOSbPBfmhUikSNSpUUtNTmiNkptGBLhSoR");
    double XQXxsxUh = 835892.4507305508;

    for (int tkRfrQ = 1831477184; tkRfrQ > 0; tkRfrQ--) {
        PBhqXWb = OvpkrL;
        BzTsilZP = gWGoUIvPqYErbY;
        QweYlIME /= XQXxsxUh;
        uLyGAwdgqEN += nEnJInFwrp;
    }

    if (ocODf != string("MOTrUIleQaJJEwTyorFtPEzYxjxLyFOXVkBnqUKCGZCxhInPeQXYtfgplgDXTmhamfkiyDVgMppAknPZcKUtWpXYPjjFZwpatnLWTwahmySwbIRFpsisuQsRkdQrEfumLelLmKqnRFAMssJbxAJYunVdNkcCKLyUdIHKtjVIXLpZEUUWde")) {
        for (int gfKMeHSkSIOx = 203707177; gfKMeHSkSIOx > 0; gfKMeHSkSIOx--) {
            continue;
        }
    }

    for (int JqGyUqoBq = 1476090947; JqGyUqoBq > 0; JqGyUqoBq--) {
        continue;
    }

    for (int UYTtHFD = 592135131; UYTtHFD > 0; UYTtHFD--) {
        BzTsilZP = ! BzTsilZP;
        FMZnqekbECGHG /= gVvAMv;
    }

    for (int EtUfPKpND = 620475564; EtUfPKpND > 0; EtUfPKpND--) {
        gWGoUIvPqYErbY = PBhqXWb;
        ocODf += uLyGAwdgqEN;
    }

    for (int ZByIHECqK = 474390527; ZByIHECqK > 0; ZByIHECqK--) {
        continue;
    }

    return uLyGAwdgqEN;
}

string BmPaz::OnCRtTeivr(bool nUkAhvGcOeRLiS)
{
    bool ayaJZCeVEdqu = true;
    string ZYtgKdakR = string("jmmsrkrxhpCYGKBDooZVNWiszSEqmWpTDuqqSIsMEcTCBnFaWAxwYYmzaAWtvElHYTPjiZbdQNSoZxWVKpBzBeNjOSNsLlrrLfQGqsRbqVDPGxyWRSTRkTvzRiuxlsHHCkAyDdAQiQYnVaaFmbSXLImAXcKznHDFoyVISbmCNqWrSUUxOpREARSGXqytUltbbCTQJnfoVoacRhUgYTSTjzZeVXi");
    string jjrIOvrszyroWb = string("bveWJUxzTzZbNaeMRBAKRDKkInbtKdNcsCqqoSoGOTlcreQfYUYkvWESvlQXPkVUAbclpEaUEITmdRacvFJwkWiXysoDSAhmULlanEnwVSxbiDFbgNdieoXxchKrQbegUdgBEQQZxaVHCLGtFULlIMtiOjKS");
    double GCzWsLuNiMmrZOLQ = -203869.88603357167;
    double ipynd = 989440.9606869284;

    for (int rNEjPM = 495711950; rNEjPM > 0; rNEjPM--) {
        ipynd = ipynd;
        ipynd *= ipynd;
        GCzWsLuNiMmrZOLQ += ipynd;
    }

    for (int vlOmBDap = 1390094340; vlOmBDap > 0; vlOmBDap--) {
        jjrIOvrszyroWb = jjrIOvrszyroWb;
        nUkAhvGcOeRLiS = ! ayaJZCeVEdqu;
        ZYtgKdakR += ZYtgKdakR;
        ipynd += ipynd;
    }

    return jjrIOvrszyroWb;
}

void BmPaz::PGzGpeA(string ZzXuSKzxpQyvSW)
{
    string xFJqdNvguPV = string("gmusOpwwU");
}

int BmPaz::GtBIPf(int nVLixxnmx, int zxpkVk)
{
    bool lKoGSjvqVEoMK = true;
    int DSiXz = 1310325100;
    string ZOeRYrbhxkBR = string("VcAYCvPCBwTuGcaANMgAYbZQo");
    bool hqRXdupiZxkbs = true;
    bool vylNcZzjUNN = true;
    double kFmrCobxZckOlbyt = 253308.5538112949;
    int mizDRTxBx = -1107378361;
    double KEHyFaPx = 635725.9637252608;
    int EjoaAprGJe = -588080336;

    if (kFmrCobxZckOlbyt <= 635725.9637252608) {
        for (int FHZIBgLmaU = 206693432; FHZIBgLmaU > 0; FHZIBgLmaU--) {
            mizDRTxBx += nVLixxnmx;
        }
    }

    for (int DNeoo = 626785175; DNeoo > 0; DNeoo--) {
        zxpkVk /= zxpkVk;
    }

    for (int kAOAkydAJ = 1679112995; kAOAkydAJ > 0; kAOAkydAJ--) {
        kFmrCobxZckOlbyt *= KEHyFaPx;
        EjoaAprGJe -= mizDRTxBx;
        lKoGSjvqVEoMK = hqRXdupiZxkbs;
    }

    if (DSiXz != -1107378361) {
        for (int dbBTpg = 1384362692; dbBTpg > 0; dbBTpg--) {
            zxpkVk -= DSiXz;
            hqRXdupiZxkbs = ! lKoGSjvqVEoMK;
            kFmrCobxZckOlbyt += KEHyFaPx;
        }
    }

    if (EjoaAprGJe >= -1107378361) {
        for (int RLvsQxUJr = 1358359840; RLvsQxUJr > 0; RLvsQxUJr--) {
            mizDRTxBx = zxpkVk;
            zxpkVk -= zxpkVk;
            mizDRTxBx = mizDRTxBx;
        }
    }

    return EjoaAprGJe;
}

double BmPaz::iKjvFUGwB(double zvlahhCBetqUecvy)
{
    bool tASqbkUrhBXqEh = false;
    int nAGKgEu = -1518560395;
    bool aDoQJIMYYtVFLN = true;
    bool RtErFUFkdIqfU = true;
    string sMuwZNb = string("nqgTQNYGmZDtRunEWoXjrgpVuAigQoMMeQgQBecQmqjOFugGzavdxZSRvOHIbXjxjPWVkHuNwxENwhpWDRlVfRlAFyJvGlyWTSCumPbJJUx");

    for (int fzMebLQGJqDFMmp = 727593595; fzMebLQGJqDFMmp > 0; fzMebLQGJqDFMmp--) {
        continue;
    }

    if (tASqbkUrhBXqEh != true) {
        for (int nKnVtkhPL = 1420261228; nKnVtkhPL > 0; nKnVtkhPL--) {
            nAGKgEu += nAGKgEu;
        }
    }

    if (zvlahhCBetqUecvy < -305785.0397708855) {
        for (int ViVtXMCZ = 1801710418; ViVtXMCZ > 0; ViVtXMCZ--) {
            aDoQJIMYYtVFLN = tASqbkUrhBXqEh;
            aDoQJIMYYtVFLN = RtErFUFkdIqfU;
            RtErFUFkdIqfU = tASqbkUrhBXqEh;
            tASqbkUrhBXqEh = ! RtErFUFkdIqfU;
        }
    }

    for (int qJzSAX = 79870574; qJzSAX > 0; qJzSAX--) {
        aDoQJIMYYtVFLN = tASqbkUrhBXqEh;
    }

    if (zvlahhCBetqUecvy < -305785.0397708855) {
        for (int uwOpMdAwuqh = 1572189949; uwOpMdAwuqh > 0; uwOpMdAwuqh--) {
            sMuwZNb += sMuwZNb;
            aDoQJIMYYtVFLN = ! aDoQJIMYYtVFLN;
        }
    }

    return zvlahhCBetqUecvy;
}

int BmPaz::tBlQUakTqpY()
{
    int gNthMytfMTaqm = -890657833;
    bool snmErNnconPpbiL = true;
    double uefUESPt = -102459.86673720801;

    for (int XmRLEldkdAVny = 1288413669; XmRLEldkdAVny > 0; XmRLEldkdAVny--) {
        uefUESPt = uefUESPt;
        uefUESPt -= uefUESPt;
    }

    for (int HVsvUwjmKUK = 2100506919; HVsvUwjmKUK > 0; HVsvUwjmKUK--) {
        gNthMytfMTaqm *= gNthMytfMTaqm;
    }

    return gNthMytfMTaqm;
}

bool BmPaz::UmqGfoDugIHrj()
{
    bool UezQntkCfmoYO = false;
    string NtKpSIYOOn = string("zeyx");
    double MxjbzKwMo = 45885.37438218059;
    bool cSIMuQR = false;
    string ckerVIgenJgOb = string("XcEmcsrlqoMVZCpfiGwokWwbWhUankITJQTKKVPbyCRJrmYzTJQdmoDPuCKFatmZLNRugwzfGgjHTCkGICxrlTupJwrYbKTYuxkgfDTFFam");

    for (int mQtFQkrhSPJfJ = 1682468081; mQtFQkrhSPJfJ > 0; mQtFQkrhSPJfJ--) {
        NtKpSIYOOn += ckerVIgenJgOb;
    }

    for (int RcdRuQI = 688416098; RcdRuQI > 0; RcdRuQI--) {
        NtKpSIYOOn += NtKpSIYOOn;
        cSIMuQR = ! cSIMuQR;
    }

    return cSIMuQR;
}

bool BmPaz::uZzKNghOwywpYRub()
{
    string ouIqmpoydnP = string("WdUEBIpxLXQUflcquWZImbeZ");
    string JvNCxJdSeTIJVfu = string("tosobnHRIQNAMmpWYrTpjmTqaJYhJdaqBYzliCENcEWivwKeWRNYbznrFWoWiPmVpStKopkfFfmKp");
    string ICjqSomkBa = string("TzcNYmkyRsgloXMPcnEnMNcFcB");
    double jdtmdWsu = 755682.5619843402;
    bool dLdWf = true;
    string mHtjribzKMzPwyY = string("ZZqBaoEPIfCcttKwQkyerNJxNslVxcsEOdCpeadnyWxFiKkoLsnuYrk");
    double bQztWYXHPDZNr = 421326.9050302289;
    string LLOVnGsCNaSdqg = string("xtirimfkGcCGwJPQbHfJTAySglDVAcftLXJPFkaiYDHljzWfqzYQtHwigPbhDzcsLJiiOpYgPJyaMtsKNgSxdILlhHcDjBAZYhNXPCIZgjZIZFDcUpYxGWKxCSGkEGsCEVioatTWrBaqHfwOEKWKYtOEBEkULSxXFKRepQOUKnQBXXOVCAOGKkNoolfPzPDteVvQmrTdYNcLImhJQNilyfRmOmUTEjR");

    for (int SornjsvrvksIKQ = 1480646993; SornjsvrvksIKQ > 0; SornjsvrvksIKQ--) {
        jdtmdWsu = jdtmdWsu;
    }

    for (int ZvqvIfkBIsaJlK = 587366192; ZvqvIfkBIsaJlK > 0; ZvqvIfkBIsaJlK--) {
        ouIqmpoydnP = mHtjribzKMzPwyY;
        JvNCxJdSeTIJVfu += mHtjribzKMzPwyY;
    }

    for (int sqIStIQlBskiAj = 832753718; sqIStIQlBskiAj > 0; sqIStIQlBskiAj--) {
        ICjqSomkBa += ICjqSomkBa;
        LLOVnGsCNaSdqg = JvNCxJdSeTIJVfu;
    }

    for (int mdCOLdVGR = 408937598; mdCOLdVGR > 0; mdCOLdVGR--) {
        JvNCxJdSeTIJVfu += JvNCxJdSeTIJVfu;
        dLdWf = dLdWf;
        JvNCxJdSeTIJVfu += LLOVnGsCNaSdqg;
        mHtjribzKMzPwyY += ouIqmpoydnP;
        mHtjribzKMzPwyY = LLOVnGsCNaSdqg;
        ICjqSomkBa += LLOVnGsCNaSdqg;
    }

    if (ouIqmpoydnP >= string("TzcNYmkyRsgloXMPcnEnMNcFcB")) {
        for (int gmfgm = 1507046517; gmfgm > 0; gmfgm--) {
            mHtjribzKMzPwyY += ouIqmpoydnP;
            ouIqmpoydnP += ICjqSomkBa;
            mHtjribzKMzPwyY += LLOVnGsCNaSdqg;
            JvNCxJdSeTIJVfu += ouIqmpoydnP;
            ouIqmpoydnP = LLOVnGsCNaSdqg;
            dLdWf = dLdWf;
            ouIqmpoydnP += LLOVnGsCNaSdqg;
            ouIqmpoydnP = ICjqSomkBa;
        }
    }

    if (ICjqSomkBa != string("tosobnHRIQNAMmpWYrTpjmTqaJYhJdaqBYzliCENcEWivwKeWRNYbznrFWoWiPmVpStKopkfFfmKp")) {
        for (int sEpiAVy = 1033393109; sEpiAVy > 0; sEpiAVy--) {
            LLOVnGsCNaSdqg += mHtjribzKMzPwyY;
            ICjqSomkBa = LLOVnGsCNaSdqg;
        }
    }

    return dLdWf;
}

bool BmPaz::FeDZbGoFnOVq(bool sbLMdLrgoi, int NRbbwTCOJuU, string hmcEwziXIMbXp, string DUqVIdvv)
{
    bool ORYnWr = true;
    bool DjdINokPiGGlRjoj = false;
    int SnVesaqC = -1564814468;
    double zPhtneUiw = 168722.6936781862;
    double tiIpUAZBpTYGk = 1020449.9582482816;
    int tqUcJFNaZit = -1225308483;
    string rVDxKNRtzCxBWyAI = string("PdOquXWyBrrfIOIzgXPLALHVqujTjGpaSMzIHdSXxHhpbeRFDyxEhUTVGGGQhBHkBdvHzFbuAwahKydUedyCUyobDlcPBffqfURs");
    string NXkUHkJPJ = string("kKqMrcLnNEfofBcMtTmnXtHNaExKQl");
    string ojbuoz = string("cBhHRIXktMYItWO");
    int lwljxNOvwdAk = -1216580870;

    return DjdINokPiGGlRjoj;
}

double BmPaz::QKWmesefPTWU()
{
    bool JwHKtRqW = true;
    bool liTdNVFXtVjk = false;
    bool foGJjKy = false;
    int WNjyEwnN = 505975798;
    double bnGXscZIeux = 1027195.05473707;

    for (int WXcbHDwoKkUTh = 1218107634; WXcbHDwoKkUTh > 0; WXcbHDwoKkUTh--) {
        liTdNVFXtVjk = ! JwHKtRqW;
    }

    if (JwHKtRqW != false) {
        for (int wGfRzdKFKR = 1664376906; wGfRzdKFKR > 0; wGfRzdKFKR--) {
            continue;
        }
    }

    return bnGXscZIeux;
}

double BmPaz::QhzJJCL()
{
    int XBsLiVjIo = -1470954419;
    string NqLNEYQ = string("tqGDSvmHtVIynKqoSTfMkpKTKenjIZhTlfcZzfpMBwQVdNXoMay");
    int CvUzLagE = -789475198;
    bool mzFNxbMneIxYe = false;

    for (int PdsObwgKHKLOTIo = 1861531671; PdsObwgKHKLOTIo > 0; PdsObwgKHKLOTIo--) {
        XBsLiVjIo *= XBsLiVjIo;
    }

    return 199316.26520649038;
}

double BmPaz::IpZKBbTOp(bool CBOaR, bool XrqfiRsa, bool bMadrOHjsmDj)
{
    double gOwba = -1004289.3740807906;
    string sXLKrotYXgdTKTKK = string("EnGxjDkiGTaPUPcrHI");
    double pDPLPxbCxz = 52568.90212782621;
    string VbTUxcGhwNT = string("xVYcJmlVrNiwzBpxJXvQvzYkGrobc");

    for (int QlqAKazrtocM = 389778150; QlqAKazrtocM > 0; QlqAKazrtocM--) {
        sXLKrotYXgdTKTKK = sXLKrotYXgdTKTKK;
    }

    if (pDPLPxbCxz > -1004289.3740807906) {
        for (int HIWbhf = 390792921; HIWbhf > 0; HIWbhf--) {
            continue;
        }
    }

    for (int TXFQqixbMWC = 421109495; TXFQqixbMWC > 0; TXFQqixbMWC--) {
        CBOaR = CBOaR;
        CBOaR = ! bMadrOHjsmDj;
        CBOaR = ! CBOaR;
        bMadrOHjsmDj = ! bMadrOHjsmDj;
    }

    for (int KRPKxPxBXeH = 628104206; KRPKxPxBXeH > 0; KRPKxPxBXeH--) {
        XrqfiRsa = XrqfiRsa;
    }

    return pDPLPxbCxz;
}

double BmPaz::TWbMxrRBdqr(string UCgONUXmTHBkr, bool SvshhbnSzLuU)
{
    double OXfvcqkAoYh = -221521.3560138696;
    int RFzxTLa = 1136298798;
    bool bsEsCZKeQrAX = true;
    double nxHoU = 468337.4036140692;

    for (int QkJDK = 1724655233; QkJDK > 0; QkJDK--) {
        SvshhbnSzLuU = SvshhbnSzLuU;
    }

    if (UCgONUXmTHBkr >= string("SDttWmMUvfMZleghtAUoizyCGraHaQtsfXWuygqyYStEgGgkjKlHLQGcEgGgRIIRvFoxqShDhVqCyaNnzhzTWiWtdJvePSJLGKunYSJXKHZFrSPoFJxMzZxPKQSSoadjleqLPITEKHXFhqXzDSvaPyuGkmPtDDizLhDBjDfLjYGozNDeUykMotMQRUwgfXRBOACltSEClrkzKmLAWLYqUfOjgVXuUNEysKaodVn")) {
        for (int rGnKoyuePMicjsUu = 615388984; rGnKoyuePMicjsUu > 0; rGnKoyuePMicjsUu--) {
            nxHoU /= OXfvcqkAoYh;
        }
    }

    for (int vIMqg = 1253704969; vIMqg > 0; vIMqg--) {
        nxHoU -= nxHoU;
        UCgONUXmTHBkr = UCgONUXmTHBkr;
    }

    if (nxHoU != -221521.3560138696) {
        for (int AxiFwdUFIynINpy = 58354422; AxiFwdUFIynINpy > 0; AxiFwdUFIynINpy--) {
            SvshhbnSzLuU = ! SvshhbnSzLuU;
        }
    }

    for (int pPRWbXGsHn = 2096690743; pPRWbXGsHn > 0; pPRWbXGsHn--) {
        bsEsCZKeQrAX = bsEsCZKeQrAX;
        RFzxTLa += RFzxTLa;
    }

    return nxHoU;
}

string BmPaz::exZXzSJmZqElnnB(string MWdaBQXqTbxSFAR, bool bxLQOoSeXWVnuhNX, string ttXCYHl)
{
    double IdHxTpzWqfmi = -148582.8340530542;

    if (ttXCYHl <= string("nyImWJWmFwZeaWLNvZpNZtFhTUVyYbruBzFDvrBpQgzAPiQybZErXmtqLhNdWvVBhEGOVasuNLmEeUZHlNyjdPbxwdixjwTbmWuxRxSSCJcOEvvuxMXdgPRrQNGmdATRBMhcgOrvjcfEwnIHhVKYdhLUlalbRHXfPktQiFOApRsEJdOecqbGRvNUCjQVLLQTXBDqlLCHAePdMCwXcHXpXFcVvNZGALCPgdZBiID")) {
        for (int EhNHxrdaDDWHz = 1912397093; EhNHxrdaDDWHz > 0; EhNHxrdaDDWHz--) {
            bxLQOoSeXWVnuhNX = bxLQOoSeXWVnuhNX;
        }
    }

    return ttXCYHl;
}

BmPaz::BmPaz()
{
    this->GAbnQGQgREF(string("YshVqqILuNsBKMvsSEzAjPYEJLcViXGcEQYnqzVUoVaOJnLhqBegjDKbXkWWkMDKgVYNRHmKTFHgyBErNTcXMXTONfeoCbqqtKTHToRaKlQJLxMmmHzqIjZZvHOcShQiYxjTDDBVeKXRTyyDkcHZpNuUvPCibvalBRWvrkDFGFDJPxeMnqLBjvQXKsoIBJvmLZQRfgTNVVYXHmwikcJVCgjYAiGQbBlJgfEDpYWjgZKtqtrlXFHVJtSckY"));
    this->auoUJzRVfcSV(string("JdOvyPLbqYhvnFZeTbvqdYExMhgMeiaRjwiTarSoCbENoVzozwpvBDVMuSfgBooEqkLyVtxNojwJBQpCmNZIEmdwpTzDkzMrAHuRzeLDgIYtCCHMsunJvGeQybddIeXxYEdlJAVAnVJcYqvwDETYISzxCfHWBEkUWaNyXqZfCYNONMLGSQDNlRLLhyeDuywTDJNkDChrqiWGIAbfkSCvBUcRtdbYSbkzLCnoKYiIOEOavwLOSl"), -277717.28964210575, 758729.1547442105, 798438835, -1041124224);
    this->ogvgCfoJGmPj(564372.9322070992, string("MOTrUIleQaJJEwTyorFtPEzYxjxLyFOXVkBnqUKCGZCxhInPeQXYtfgplgDXTmhamfkiyDVgMppAknPZcKUtWpXYPjjFZwpatnLWTwahmySwbIRFpsisuQsRkdQrEfumLelLmKqnRFAMssJbxAJYunVdNkcCKLyUdIHKtjVIXLpZEUUWde"), false, 1061584655, false);
    this->OnCRtTeivr(true);
    this->PGzGpeA(string("bdSgxqFDgHDDDbtqynPYlMvfXgyLwVKQJQuoJWHoPpfXZbsSSlgcbAZjkdvANBbKUEYkVALdILdWdmhEMkOaKweMLpUcBQZQrlkUhyHJzhPkzzQkLVTYLycKrpRbXedwgWkMZSqAfQpceVzWUwwIHarjjSWRxnPqUFEaDkSaIoxDzSPnoxqpSLHIkpNlBemwnSeqKlDUmSRjAC"));
    this->GtBIPf(67093869, -1863743088);
    this->iKjvFUGwB(-305785.0397708855);
    this->tBlQUakTqpY();
    this->UmqGfoDugIHrj();
    this->uZzKNghOwywpYRub();
    this->FeDZbGoFnOVq(false, -1334313168, string("uluDCJZVXXFjnzZkubKCqgHvxPKOgEHeBBpNUPzHaRQTWuRfVubUXRIZeTcfxUyvTKPmEoNSScjVfhuPXaMpTiYQTnaVDqRNTmWDCavsPFYuXhRvTCSvSKWbslaOGjTDLxvymFbtxQiYBfzXABkTjpoeiPJkeeVbtOnlZPUpVqwozbhFhojlJdnvCgZJnMTvAGpgcfIXwhIbmPyWESxzqQBEqzPCXmROKBiMSoImVFexUYvXNpPocAoIelDpXd"), string("bUFZeJhZFnEcFSUGpcqWLuIWpbvOcXUYUmSidFboBrVCucIjFFAUShSytZyEsBPWjWPQmyHeRwynNumBBRCsKOxEevndXkjJleTgptQgiSepzDJUmzAolumCJZuXAcXAmBbofCBrzCkpgZdyVJSvagOrvxOBPcZqHKFperlGHVanmDCxyDwOYnwtyj"));
    this->QKWmesefPTWU();
    this->QhzJJCL();
    this->IpZKBbTOp(false, false, true);
    this->TWbMxrRBdqr(string("SDttWmMUvfMZleghtAUoizyCGraHaQtsfXWuygqyYStEgGgkjKlHLQGcEgGgRIIRvFoxqShDhVqCyaNnzhzTWiWtdJvePSJLGKunYSJXKHZFrSPoFJxMzZxPKQSSoadjleqLPITEKHXFhqXzDSvaPyuGkmPtDDizLhDBjDfLjYGozNDeUykMotMQRUwgfXRBOACltSEClrkzKmLAWLYqUfOjgVXuUNEysKaodVn"), true);
    this->exZXzSJmZqElnnB(string("nyImWJWmFwZeaWLNvZpNZtFhTUVyYbruBzFDvrBpQgzAPiQybZErXmtqLhNdWvVBhEGOVasuNLmEeUZHlNyjdPbxwdixjwTbmWuxRxSSCJcOEvvuxMXdgPRrQNGmdATRBMhcgOrvjcfEwnIHhVKYdhLUlalbRHXfPktQiFOApRsEJdOecqbGRvNUCjQVLLQTXBDqlLCHAePdMCwXcHXpXFcVvNZGALCPgdZBiID"), false, string("OkAEuOkKcHojjbZDKbpRqbxamMHxfQmqKCTuyzeQIttRmicZeBiJhGRjWyHqsWqFZWpvOSjZZGwop"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kjRlA
{
public:
    int vJmoTNEI;
    double UgKTuPelRy;

    kjRlA();
    double wgSpghAFRSARL();
    int LMERNwUGHDsLCzRW(bool WqrCglBn, int XsvUBZvEFuVSJw, double XXzjvonIwZrC, bool WUUXCOMtVtpjCSk, bool QocRBHJYGc);
    int mUUnNir(string QXGzGSbAkTS, double SmFBaI);
    bool GvhmSySEJMACKgFd();
    void QhbtDSOEqQPlkEI(double YHtnXfQ, string wdOfh, bool QWytdKR);
    double MzUVFxhmVIvktmN(double bwwNO, int nPudp, string BjyqMnT, int CFYrlEjrPFjqvcUC, string SOwXKStrUzubm);
    double uceAMM(int jIPDcfClG, string yOEie, bool VmQSUxcY, string GxIYENBQwPbJUc);
    double GisrxUquKKRSQ(string jSpEsfNbUfwJ, int OnyKVwCLRyAv, string hKamSIVLGzA, double LlfGhqTp, bool YJcZz);
protected:
    double kFngbAZTDbLON;
    double sZVOG;
    double rzzhSjGp;
    bool tbWoIyPh;
    bool gYZGjJUu;

    double eyXAr(double vtGSoyoQeEa, string IiiSUFqvRgAw);
    int IpCRAxJrcLMKNaY(int xXnOJXUBdWhn, double cTvCbggEloanxK);
    bool hsqZjjkfDDltwoL(double zhuGlcxbZvtQwn, double TquVoGJXzRdO, int SwFzXkVrJ, double IwIIOjAbZ, double ITYSrTHGFYLYccQ);
    bool bOwmKntzWdgVIJbb();
    string prIwaDBUbe(double HIGhnbD, string hkFTYPyRYpDGuSx, string EVgcKwqtYXFDy, int sLBxLzwCH, int IKaJAtXTkR);
    double LeStlZNJze(double lAFLjAvDeIFpbA, string CNdNECXH, double yePwHlk);
    bool DfVggyC();
private:
    bool GRRmObPYGq;
    bool abJjLrQhMyz;
    string auRio;
    int LXKEeW;
    int DrNrexHCwF;

    void ZOoaV();
    double kKchMwfTwaOXBhi(bool mWEHdZswMHeAXkAq);
    double XqIwpRPQQgbW(bool itOrtKsIzXLDNJbk, string BXJtIcyKpDV, bool uBmQXEviN);
};

double kjRlA::wgSpghAFRSARL()
{
    double PtKlgBRVvxNBArni = -741030.2400461372;
    int iRwfwDGNRwKOs = -694299712;
    int Mjgap = -175319079;
    string SmCHLXhXHkyXB = string("QozfeVyMqhvZwWRfVUOgTsyggVyPEeUwBfFRXvYsZimDxTMMxRbustHoMDvWyCAUCcbvVHyUkCucTsSoQgaJCCsmlbNnVPHbXYtvLsdtAWJBklfPvbatjzFzBsFeHknCRolQoBjbvWwmqyjVQGAynIoVHRuMbmcFluzdelleraSOzptopXpCOoFSQIw");
    bool ItprpOBYW = false;
    bool ZofsDLrc = true;

    if (SmCHLXhXHkyXB > string("QozfeVyMqhvZwWRfVUOgTsyggVyPEeUwBfFRXvYsZimDxTMMxRbustHoMDvWyCAUCcbvVHyUkCucTsSoQgaJCCsmlbNnVPHbXYtvLsdtAWJBklfPvbatjzFzBsFeHknCRolQoBjbvWwmqyjVQGAynIoVHRuMbmcFluzdelleraSOzptopXpCOoFSQIw")) {
        for (int evGolpRDH = 1306532787; evGolpRDH > 0; evGolpRDH--) {
            ItprpOBYW = ZofsDLrc;
            iRwfwDGNRwKOs -= iRwfwDGNRwKOs;
            SmCHLXhXHkyXB += SmCHLXhXHkyXB;
            SmCHLXhXHkyXB = SmCHLXhXHkyXB;
        }
    }

    if (SmCHLXhXHkyXB >= string("QozfeVyMqhvZwWRfVUOgTsyggVyPEeUwBfFRXvYsZimDxTMMxRbustHoMDvWyCAUCcbvVHyUkCucTsSoQgaJCCsmlbNnVPHbXYtvLsdtAWJBklfPvbatjzFzBsFeHknCRolQoBjbvWwmqyjVQGAynIoVHRuMbmcFluzdelleraSOzptopXpCOoFSQIw")) {
        for (int eTTIJIsBNj = 1206059815; eTTIJIsBNj > 0; eTTIJIsBNj--) {
            continue;
        }
    }

    return PtKlgBRVvxNBArni;
}

int kjRlA::LMERNwUGHDsLCzRW(bool WqrCglBn, int XsvUBZvEFuVSJw, double XXzjvonIwZrC, bool WUUXCOMtVtpjCSk, bool QocRBHJYGc)
{
    double NHDHXEgP = 642508.8049387642;
    bool dTemlmjerXNiDR = false;
    string nApyBERTIAjPLb = string("OJLeeLkCXfaVTYEJeRzVPufNisHrRzMgIpOsIIbgumKtvSyhzoUdsLwmNNKOeJv");
    string vzvhDRuyGFmE = string("rGaNekwZaYTCFjecExBJeojGWiFbgmlcPkOBJhzGPSlgvuiRFrQvuPKiJDzCUKmWQUhPYCdPyovagBVTkyicEtNeMPeHvlgcKqxGopFqiALccKUAsEGeUzKTHXRpiyGLEEKriwapEoiadgjKvxmBnLZHVMGUvngqSubYQsQEosdARKvJyLgqqIMfOch");
    int OHLIKdCRFDgGxMIi = 1245215066;
    double GgaNWpsMGrtS = -989897.8055051405;
    bool DdIjm = false;

    for (int GmJaflYciWG = 1172875309; GmJaflYciWG > 0; GmJaflYciWG--) {
        DdIjm = dTemlmjerXNiDR;
        WqrCglBn = ! WUUXCOMtVtpjCSk;
        dTemlmjerXNiDR = ! dTemlmjerXNiDR;
    }

    if (XsvUBZvEFuVSJw < 1245215066) {
        for (int gEPdQllkLpa = 2100237883; gEPdQllkLpa > 0; gEPdQllkLpa--) {
            DdIjm = ! WqrCglBn;
            dTemlmjerXNiDR = WqrCglBn;
        }
    }

    return OHLIKdCRFDgGxMIi;
}

int kjRlA::mUUnNir(string QXGzGSbAkTS, double SmFBaI)
{
    bool jfTPwSZcBVFj = false;
    bool fHDORDCdVQFjraM = false;
    int FDVTRMJCPC = -1333873073;

    if (jfTPwSZcBVFj != false) {
        for (int MjpTIgeOPERGJLas = 196790902; MjpTIgeOPERGJLas > 0; MjpTIgeOPERGJLas--) {
            fHDORDCdVQFjraM = ! jfTPwSZcBVFj;
        }
    }

    for (int tLEfqvxcaBWV = 1146797251; tLEfqvxcaBWV > 0; tLEfqvxcaBWV--) {
        jfTPwSZcBVFj = ! fHDORDCdVQFjraM;
        QXGzGSbAkTS = QXGzGSbAkTS;
        QXGzGSbAkTS = QXGzGSbAkTS;
    }

    return FDVTRMJCPC;
}

bool kjRlA::GvhmSySEJMACKgFd()
{
    double TaNCkldwVs = 1027715.7479546912;
    string SsirlqTqCdjd = string("OFQufdOXOAPoWAWlhRPhsTgYfAULNQzumXYxxewgCKwaLmSwOYSxexgXRMsrzHINrHqiVpNkUbtIHgSbjaaEbbsYNSmtbsZrhZcKGCUwLKQsGqSyzZi");
    bool RrEDPFoz = true;
    string LVXoWCToZkDyVjB = string("tLrNfOwMqktfjTKqQbtXmrGaHDgHAaOOyACieGuJNFbHNqBCOgQVtnObBUkweZtebDFMVfrDraDMnGAfnVNSPltJmkCiwADZagyRhiizvNqnvPGteMFunMDqwsbhwbyeMnELxWCXivoJtPgvmQivUrATFa");
    int kLuSBESluXRLBbI = 653722739;
    double ztBWkrYRVanwP = 635214.8776958446;
    bool qpeqgevBBBEPldUF = false;
    bool LeYKhHnRbBGenNkJ = true;

    for (int KTMPiAz = 408480772; KTMPiAz > 0; KTMPiAz--) {
        ztBWkrYRVanwP += ztBWkrYRVanwP;
        LeYKhHnRbBGenNkJ = qpeqgevBBBEPldUF;
        kLuSBESluXRLBbI *= kLuSBESluXRLBbI;
        SsirlqTqCdjd = SsirlqTqCdjd;
    }

    if (RrEDPFoz == true) {
        for (int PWsCzLrrJC = 649664768; PWsCzLrrJC > 0; PWsCzLrrJC--) {
            TaNCkldwVs = ztBWkrYRVanwP;
            ztBWkrYRVanwP = ztBWkrYRVanwP;
        }
    }

    if (LeYKhHnRbBGenNkJ != true) {
        for (int zAZnuLU = 1672625649; zAZnuLU > 0; zAZnuLU--) {
            continue;
        }
    }

    return LeYKhHnRbBGenNkJ;
}

void kjRlA::QhbtDSOEqQPlkEI(double YHtnXfQ, string wdOfh, bool QWytdKR)
{
    bool KOgvxum = true;
    double QtkNMeXelGyXJKTT = 357056.7080586267;
    bool XFoPTXzTvONJX = false;
    int lddPeqgop = -1893436846;
    bool kHQYliUVRC = true;
    string ViAep = string("DCBYUUpDvCwGDNcCRYnQrjrCPWFnBpWvRWsOvpQEbfsOWVdEbtvWFQhjVZvxJjfSmoPwsVzbsBmvxxjFUqHtkMWozsojdqiJEsdqLCJshqZpqHClJdYOmlKamEPtZTLJkXUBNTQVNWuokITQuluVKQsKlRFPRHGBfyoNuPUUiPsqZReRCiusparlemTfQnXiEzCbGAByAOgVoXylXhlWZlwTRNnphgKydekWxtotPKmfnXoVxwPW");
    double nGlUncjey = 621154.8236515436;
    bool RWMpkZYmdLWtQdKg = true;
    int cuRAFvRKgmQMOSQ = 1451390461;
}

double kjRlA::MzUVFxhmVIvktmN(double bwwNO, int nPudp, string BjyqMnT, int CFYrlEjrPFjqvcUC, string SOwXKStrUzubm)
{
    int jsreNZciSfDNf = 318318834;
    double HydelHOCCdgj = -43654.96558863269;
    string GpVWY = string("ruvLgXOxpKGJugHtXJyMSTiJhwfTfhFtXNlOoEKCpkadtLRXcTMemhJydFgFsyMVMFGWbfkZVoZlMOgScBoUxcOxSnGOGxtomuINurmDvrmyPULpEZCjFssgpbWrlcZHJhGHnAZLOwNhQmp");
    double gPgTI = -408554.51428116806;
    int pzMPElUVzzDJUPK = 555041344;

    for (int syYuNKCSkaaX = 1758710394; syYuNKCSkaaX > 0; syYuNKCSkaaX--) {
        continue;
    }

    if (jsreNZciSfDNf <= 318318834) {
        for (int qYQVXZsyzCSPpE = 1673162159; qYQVXZsyzCSPpE > 0; qYQVXZsyzCSPpE--) {
            CFYrlEjrPFjqvcUC += nPudp;
            CFYrlEjrPFjqvcUC -= pzMPElUVzzDJUPK;
        }
    }

    return gPgTI;
}

double kjRlA::uceAMM(int jIPDcfClG, string yOEie, bool VmQSUxcY, string GxIYENBQwPbJUc)
{
    bool GAMEfJpxqIi = false;
    string HXKOCHvzFQ = string("HLTzjkqcHkpwNHPCpjxTzxzSjPzzIpRjShELdxWYHhhCXFoiGwcTVJQZrGgmYNOPRQYTLJmEmKmFHtGOwQIQjSfuuXMVXlHwtuzaGKMZcPsrEMUIIMJVMueVHTnYwFniChZQnyddUWn");

    if (yOEie >= string("QXJamURzKZuFbSG")) {
        for (int zxoBMnYEMzki = 1678747545; zxoBMnYEMzki > 0; zxoBMnYEMzki--) {
            GxIYENBQwPbJUc += yOEie;
            VmQSUxcY = GAMEfJpxqIi;
            GAMEfJpxqIi = VmQSUxcY;
            VmQSUxcY = ! GAMEfJpxqIi;
        }
    }

    return 462975.1037888725;
}

double kjRlA::GisrxUquKKRSQ(string jSpEsfNbUfwJ, int OnyKVwCLRyAv, string hKamSIVLGzA, double LlfGhqTp, bool YJcZz)
{
    bool BZWulHcGxCdy = true;
    int ZZDigKNVPbqgVtds = -1574092380;

    return LlfGhqTp;
}

double kjRlA::eyXAr(double vtGSoyoQeEa, string IiiSUFqvRgAw)
{
    double XuIYJ = -396095.41069518274;
    string fpLpVzi = string("RrWButfQbfSMsXfdsWHxykrgqEvxDJsNEZGmTbbecnYCOTkWkbk");
    int SEKzkEJLNqSQs = 1946729099;
    bool jnuKhxShzMRprs = true;
    double uCbFGcu = -939626.455435737;
    bool ecfQFQtARDR = true;
    int aghpPOKANwBJApM = 1583935841;
    string fjlnSyGuQUYDvedB = string("igntbwaKWIcNaphedTgakgGBpeMnWXCEmb");
    double KgDGuVaKSuU = -28033.02528096078;

    for (int eeBPBmlMMXoVA = 1611880141; eeBPBmlMMXoVA > 0; eeBPBmlMMXoVA--) {
        jnuKhxShzMRprs = ecfQFQtARDR;
    }

    for (int OlhUccQQlqRSV = 1082362391; OlhUccQQlqRSV > 0; OlhUccQQlqRSV--) {
        jnuKhxShzMRprs = ! jnuKhxShzMRprs;
    }

    for (int LsWJZWRukLdCI = 276619149; LsWJZWRukLdCI > 0; LsWJZWRukLdCI--) {
        continue;
    }

    for (int FSWyOAMxE = 998009005; FSWyOAMxE > 0; FSWyOAMxE--) {
        fjlnSyGuQUYDvedB = fjlnSyGuQUYDvedB;
    }

    for (int dWzmYZar = 1954561643; dWzmYZar > 0; dWzmYZar--) {
        fjlnSyGuQUYDvedB = IiiSUFqvRgAw;
    }

    for (int vDulWIjazsKeX = 584311100; vDulWIjazsKeX > 0; vDulWIjazsKeX--) {
        XuIYJ /= uCbFGcu;
    }

    for (int ykaJAYzgn = 683432640; ykaJAYzgn > 0; ykaJAYzgn--) {
        continue;
    }

    if (vtGSoyoQeEa >= -28033.02528096078) {
        for (int dmniXBx = 1470015298; dmniXBx > 0; dmniXBx--) {
            ecfQFQtARDR = ! jnuKhxShzMRprs;
            uCbFGcu -= XuIYJ;
        }
    }

    return KgDGuVaKSuU;
}

int kjRlA::IpCRAxJrcLMKNaY(int xXnOJXUBdWhn, double cTvCbggEloanxK)
{
    string fCzKsbMkfxVCla = string("oBJWPpnbwgnlDxgeSOiFZPAOhSnmtKQUOhYKiUdCusimoPvOEIcHREnItiXtvqdCZQjqyxEiqmnJRKFOzDBzmCXCYrybXItYgaPltswkGwPTuqcxfEkwzEwsmyKlzpyFzYlVwhAzbJMeawNMlqtrbQvphQvdGmpgpGtTZMTaJAqawDFAXJAGrmqvNbTBNfvbusKfQitYaNk");
    string cxYxAb = string("eCRjTMcShLreMPRPBlMRhmAttQJyJLEVJqBVYtJMtDgWItVgkdhOLjOIqAyodxbjLtokhmNgwUqXuBncJxVnlpdsmUrvYYwrPlJMEwWzcgDzUcVGWCWfHwpsTZlyVMMzwtIhMWRvgyPYhSjrhkLiIAdpAtd");
    int RRKkHdUjSuxnfA = 614660782;

    for (int jTxlmmmQnwyPy = 1323754416; jTxlmmmQnwyPy > 0; jTxlmmmQnwyPy--) {
        cTvCbggEloanxK = cTvCbggEloanxK;
        cxYxAb = fCzKsbMkfxVCla;
    }

    if (fCzKsbMkfxVCla <= string("eCRjTMcShLreMPRPBlMRhmAttQJyJLEVJqBVYtJMtDgWItVgkdhOLjOIqAyodxbjLtokhmNgwUqXuBncJxVnlpdsmUrvYYwrPlJMEwWzcgDzUcVGWCWfHwpsTZlyVMMzwtIhMWRvgyPYhSjrhkLiIAdpAtd")) {
        for (int BpZYJLjuACcdmO = 1554139881; BpZYJLjuACcdmO > 0; BpZYJLjuACcdmO--) {
            cxYxAb = cxYxAb;
        }
    }

    if (xXnOJXUBdWhn < -2142464766) {
        for (int yaNFyfHQlyKXwKv = 655091107; yaNFyfHQlyKXwKv > 0; yaNFyfHQlyKXwKv--) {
            continue;
        }
    }

    return RRKkHdUjSuxnfA;
}

bool kjRlA::hsqZjjkfDDltwoL(double zhuGlcxbZvtQwn, double TquVoGJXzRdO, int SwFzXkVrJ, double IwIIOjAbZ, double ITYSrTHGFYLYccQ)
{
    int fNeqrWcWPKeOGAQr = -451875533;
    double opSfp = -446628.92347583733;
    int NvlSjQZIJegIkN = 271529735;
    string UZmgoRXddv = string("HxFwWvIidiUPssYsXWwifcryHmpbDRPIkJpNdDHDnawfLJtEzDHgLTnwBRqDPfldAIpDnsVXaWyBwnBMhKrmDDgVboxeMeP");
    int pugXklVSldPA = 1900429009;
    string IljDglN = string("fhLRHWYKUfonkUdLstbDJdWfaFfKDzEQHvwbbBgzlBmIOQrwanuVTkEyETztQmTNUhOdImAWAAfCXXenuSvypzgFhxKftkYmkqklFlhHKthFTRZbjrZnKjPqnhcabaLRJbkCdxzzWRztfeehqhktSKSoRkoIninvtSbUMOxiFvAHPRSrOKJHWTnHYgVDiWGnRBbXvxOMOELVdZJkIlwXccxrEypKyPijfyz");
    bool kJJizuJmfHA = false;

    if (IwIIOjAbZ == -446628.92347583733) {
        for (int RKbZjRlYhTMyOiMV = 1543487236; RKbZjRlYhTMyOiMV > 0; RKbZjRlYhTMyOiMV--) {
            opSfp /= IwIIOjAbZ;
        }
    }

    return kJJizuJmfHA;
}

bool kjRlA::bOwmKntzWdgVIJbb()
{
    string BmFYVFpaGvhRxT = string("KJSzWvFGMOXufLlyMBgIzdjMRGhHtsmrPjhsmJUmoNqwRnfjNxNjHuponRvfkQjQSbJVdPjeyIAThYQGnxdTrTpaKgSHzydcCMNBUlKiRTGBALCjEiFJofHmQMIlywnrZiqsumMSYVBDykFbIPzUggHPZIPJgCJeUmsDVkroqCtBJlLYHaMiHnrEyxMPFQX");
    string BAVjLrrUeRxOzr = string("DaqLzDfnOYFOmMbViFgqlPbFxhhBPOWuLzmMdXPfllzufWPeeBUCsSkrsoDX");
    bool ZsTYYQq = false;
    bool oEONCp = true;
    bool wmqSIcU = true;
    string eQWLFwmDhZzNz = string("WOVBYbYhEEBxOfuQRCTOTkFEjFHXFhBwhUjCXDKiWdgZhIGKIZgIlfqOtAbieEzGFYbLoVFhXDUmQbkFHFxzBglWUvOKuyCAvifiKAhMgMYHKAcBVeMJrjigKwRjHoQJnVbiVDFYU");
    int PuLTrIDfbKejaffD = 547265292;

    if (eQWLFwmDhZzNz != string("DaqLzDfnOYFOmMbViFgqlPbFxhhBPOWuLzmMdXPfllzufWPeeBUCsSkrsoDX")) {
        for (int bHUJCgGy = 1772592211; bHUJCgGy > 0; bHUJCgGy--) {
            wmqSIcU = ZsTYYQq;
            ZsTYYQq = oEONCp;
        }
    }

    if (BAVjLrrUeRxOzr == string("WOVBYbYhEEBxOfuQRCTOTkFEjFHXFhBwhUjCXDKiWdgZhIGKIZgIlfqOtAbieEzGFYbLoVFhXDUmQbkFHFxzBglWUvOKuyCAvifiKAhMgMYHKAcBVeMJrjigKwRjHoQJnVbiVDFYU")) {
        for (int PxEdPOZGqSB = 114851287; PxEdPOZGqSB > 0; PxEdPOZGqSB--) {
            eQWLFwmDhZzNz += eQWLFwmDhZzNz;
            BmFYVFpaGvhRxT += BAVjLrrUeRxOzr;
            ZsTYYQq = wmqSIcU;
        }
    }

    return wmqSIcU;
}

string kjRlA::prIwaDBUbe(double HIGhnbD, string hkFTYPyRYpDGuSx, string EVgcKwqtYXFDy, int sLBxLzwCH, int IKaJAtXTkR)
{
    double XIdYsnEqdszdXP = -1039431.3955739175;
    bool FLqYPHNzPx = false;
    int zTaYpcPsAYvWvl = -1214822095;
    double JEGrvzku = -9496.910223397414;
    string twAuGxfDvmxjE = string("VZJlCnfCkNFdLifkHJkaQRuBylzIwECfGQtOTvVfYravLigdqpZzOPBxFyWQSbERt");
    string ZJXobFVbOK = string("GKfndJbjuVpSwyvdZLbTgWoYpnktUhiaFwcUIsrOWsuawsmkCJTLAqGqtdqHFmxToYeAuYxBVAuvevQofIqabIZabzOEKIetKULXjIjSUhdNzJOaKVCrysFgCZBepfronsipJtYqdWYeRaG");
    bool hLDJoSfRjWTCj = true;
    bool QqRRouFQJ = false;

    if (twAuGxfDvmxjE == string("GKfndJbjuVpSwyvdZLbTgWoYpnktUhiaFwcUIsrOWsuawsmkCJTLAqGqtdqHFmxToYeAuYxBVAuvevQofIqabIZabzOEKIetKULXjIjSUhdNzJOaKVCrysFgCZBepfronsipJtYqdWYeRaG")) {
        for (int NAQXnRx = 172973011; NAQXnRx > 0; NAQXnRx--) {
            HIGhnbD -= HIGhnbD;
            EVgcKwqtYXFDy = twAuGxfDvmxjE;
        }
    }

    return ZJXobFVbOK;
}

double kjRlA::LeStlZNJze(double lAFLjAvDeIFpbA, string CNdNECXH, double yePwHlk)
{
    int TQSvUwHTCVhTYa = -135682270;
    int eUFnrRtfDCyMwfdX = -1286968436;
    string puilnbXyWPV = string("xlGjhKGjrXpGPcHEnFnQiPuhQRFTiRvKyYAoqInoUYfngWxCCpsmbFyOydQdHYDnFQRKkeYDFNSRXcUnFrjQPOBaiALpLpuHdgOVrZgFiYGHIZWapjHEYRMfnwKHxAhnrTRKgNPeYjUriUMyhQMJDYxJyYjJsmJNxYdswndSocAQqHbDdILoDxjMlKzpNXJouHP");
    bool SjIWLYJCiCDnd = false;
    int xXGrGCQDheYwLAD = 941211463;
    double GsINxAsiCVnXHOFs = -173209.0910864866;
    double HFZAl = -894171.1126087847;
    string BFLQYX = string("DSeYbcAuYRqXUVwhJaPDXVKGCPkYrQLHgSbxujrGuFKyZZSHblieBbtuTxPBCbTEsibYfpNVaIUMzzfNfckOYaNnQbUCtYvNmRKGotJxyanaTTMIzCaTTWWagMWYTMXGsnYJjlvNQuLYLlcXaaCvvSzHeUemYdfmqEhtYbDIXQWyZraRKjmmjwqhcauFnNgTWgwe");
    bool oCbidPqFFQtW = true;

    if (TQSvUwHTCVhTYa < -1286968436) {
        for (int ikVTC = 593350816; ikVTC > 0; ikVTC--) {
            puilnbXyWPV = BFLQYX;
            GsINxAsiCVnXHOFs /= GsINxAsiCVnXHOFs;
            CNdNECXH = BFLQYX;
        }
    }

    if (eUFnrRtfDCyMwfdX != 941211463) {
        for (int mJvwwDlxhYpBYQl = 46205684; mJvwwDlxhYpBYQl > 0; mJvwwDlxhYpBYQl--) {
            continue;
        }
    }

    for (int fQwwcob = 721180283; fQwwcob > 0; fQwwcob--) {
        oCbidPqFFQtW = oCbidPqFFQtW;
        HFZAl /= yePwHlk;
    }

    return HFZAl;
}

bool kjRlA::DfVggyC()
{
    int frTHJ = 968059154;
    double PibFjdAhbkPZz = -517559.7952531027;
    double HgevBbN = 307828.16203793243;

    for (int zGVGHL = 574394986; zGVGHL > 0; zGVGHL--) {
        HgevBbN = HgevBbN;
        HgevBbN -= HgevBbN;
        frTHJ += frTHJ;
        frTHJ += frTHJ;
    }

    for (int rPmpfAIaiIy = 13972730; rPmpfAIaiIy > 0; rPmpfAIaiIy--) {
        HgevBbN *= HgevBbN;
    }

    for (int lwdWbLtFwPLokrZy = 419688421; lwdWbLtFwPLokrZy > 0; lwdWbLtFwPLokrZy--) {
        continue;
    }

    if (frTHJ > 968059154) {
        for (int tiVlN = 706456237; tiVlN > 0; tiVlN--) {
            continue;
        }
    }

    if (HgevBbN > 307828.16203793243) {
        for (int oOtvCDjca = 363658522; oOtvCDjca > 0; oOtvCDjca--) {
            HgevBbN = PibFjdAhbkPZz;
            PibFjdAhbkPZz -= HgevBbN;
        }
    }

    if (HgevBbN >= -517559.7952531027) {
        for (int pCxknCliNaW = 1284790593; pCxknCliNaW > 0; pCxknCliNaW--) {
            PibFjdAhbkPZz = PibFjdAhbkPZz;
            PibFjdAhbkPZz -= PibFjdAhbkPZz;
        }
    }

    return false;
}

void kjRlA::ZOoaV()
{
    bool mueFnfpNnUg = false;
    int NyDKusgFaIbsvTD = -9989923;
    string GLbJlNEhqos = string("XeErVOFQkpDDFPHKLjFmAtJQEJhfVyFHRlguSacfeAcnchyJNsVmusPXSROcINSCpwgoBlsgedhqLAnOZQCwfixGxeBHNGlvJfRMdShwSDyDCyqlHXEKBDZgjgtszAFzMROGVoeHjTUXeAejeUHbHmtsRpgPmUDaQAbfXDSyTQNeWrYFDcCAECspVeIXgGiBYGAbeMZwcOTegyOjiRLOTedRgYnOAKwjOIfcPfadVDcltFJlsUOXmHyyvZeTgu");
    double cMyuidIOLHhUnr = 667034.569366168;
    string gtghQLN = string("lpgRyVyLJoIscnzlGgBqtdHQTFKECUtXzZoSGNXENwQEICrwNjcNleXNfNSBVnGkTtsTKLArkKRjWeTOcAYWXxwZnkOwhCfgFCOdMexpUMucoyCXMyEUWwXmKBIYpvtMvlBtIFGumKwripGhpUPdnyL");
    double OHMEpDzpKaE = -682280.8600522247;
    double UvPkjQV = -784204.5343234054;
    int kppbu = -1883402504;

    if (NyDKusgFaIbsvTD != -1883402504) {
        for (int awWeqlfJDzaS = 1754271219; awWeqlfJDzaS > 0; awWeqlfJDzaS--) {
            NyDKusgFaIbsvTD = NyDKusgFaIbsvTD;
        }
    }

    for (int ogdGujDp = 1339770797; ogdGujDp > 0; ogdGujDp--) {
        cMyuidIOLHhUnr = UvPkjQV;
        gtghQLN = gtghQLN;
    }

    if (OHMEpDzpKaE > -784204.5343234054) {
        for (int ItDHziBd = 694893051; ItDHziBd > 0; ItDHziBd--) {
            cMyuidIOLHhUnr += UvPkjQV;
        }
    }

    for (int ZuGqZgPRp = 388500146; ZuGqZgPRp > 0; ZuGqZgPRp--) {
        OHMEpDzpKaE /= OHMEpDzpKaE;
    }

    for (int UjMauv = 1581550117; UjMauv > 0; UjMauv--) {
        gtghQLN = gtghQLN;
        mueFnfpNnUg = mueFnfpNnUg;
        GLbJlNEhqos = GLbJlNEhqos;
    }

    for (int FQxPBUqkc = 981805277; FQxPBUqkc > 0; FQxPBUqkc--) {
        UvPkjQV /= cMyuidIOLHhUnr;
    }

    for (int lZsTpyclkmbb = 1830242036; lZsTpyclkmbb > 0; lZsTpyclkmbb--) {
        GLbJlNEhqos = gtghQLN;
        GLbJlNEhqos += GLbJlNEhqos;
    }
}

double kjRlA::kKchMwfTwaOXBhi(bool mWEHdZswMHeAXkAq)
{
    bool ZVLuM = false;
    string lUjabK = string("BufUKDsSMrcHtCEzboPTRBdLKugodvhCRKPMVbRzVzKRuObPNxLCdLhCnbJVsbGUVRNMExHjDamcpxWHzBadFtLQgWfemnhKeqUVgEhEgMOutfUUJAxQHRbonOpGaFqhirkkhMDANnLiTvHILRcrhQWwDUSGxZuMWjYdJHyWgDLKifkpoADOPvvBhnARIDaFQyefDhYxgNParTtDvQLGlmMFWPjRjcOCtQgIiIWKdWzMfRkIoT");
    bool YMlJekdinGNrlHJ = true;
    int nzlAewlJW = 1156622896;
    string wNbIjVWYAQJZoc = string("CFYJboSpszxaHGBVxQuFRisVPQvGUNYOEaopTHhiFQkvwSrBwPFmpCmihUfGESQOISdQLmGDTMKUknwwUnKBOziihmNQeRagYmXgJLZesYDEODnwMfIrZbtmEIjzVLppeNivFhJMGirBzxjITSHQIwctyAYRSIpesjbbOGLgHrBwjHARKZgqcTlLotMahkZFdlPrpbFPxIPXvWFjIoCeZWgfSC");
    double leoQlhbcuiKWO = 870811.4828721706;
    string NFubFBuCfCUt = string("ugmJmSevUInghEbPmadTgZCjwgVpXrPdjEUeUvEuAYtLZaYGrzPbYntyaQreETiiCFhxyrwVYCEYoSAZBMMlFqhSiBDxHQjhMTNVCxEiyBZuEUTRhxoATkLXlvWYctjHVaTAazFoiQXRiFpXoRDFveYOhAfuQMGbePGysRFQGzrvcylCxdUSQwzfylvaAqrIwIUAKcGQHtrqtWCHXtNSMHAzOsTZPDlFCaYHaUjfzgFtHOdlVUcAeBfJ");

    for (int VrmkOR = 1724710628; VrmkOR > 0; VrmkOR--) {
        YMlJekdinGNrlHJ = ZVLuM;
        ZVLuM = ! mWEHdZswMHeAXkAq;
        lUjabK += wNbIjVWYAQJZoc;
        lUjabK += NFubFBuCfCUt;
        YMlJekdinGNrlHJ = YMlJekdinGNrlHJ;
    }

    if (ZVLuM != false) {
        for (int HQmXrwmOdUwb = 1713117514; HQmXrwmOdUwb > 0; HQmXrwmOdUwb--) {
            continue;
        }
    }

    for (int LsGozZgnF = 1498024004; LsGozZgnF > 0; LsGozZgnF--) {
        continue;
    }

    for (int APitXgicOgZYx = 1541595431; APitXgicOgZYx > 0; APitXgicOgZYx--) {
        continue;
    }

    for (int eKwdfWnCy = 548990830; eKwdfWnCy > 0; eKwdfWnCy--) {
        YMlJekdinGNrlHJ = YMlJekdinGNrlHJ;
    }

    if (leoQlhbcuiKWO <= 870811.4828721706) {
        for (int cJnsO = 2094752701; cJnsO > 0; cJnsO--) {
            wNbIjVWYAQJZoc += NFubFBuCfCUt;
            NFubFBuCfCUt = NFubFBuCfCUt;
            YMlJekdinGNrlHJ = ! YMlJekdinGNrlHJ;
        }
    }

    return leoQlhbcuiKWO;
}

double kjRlA::XqIwpRPQQgbW(bool itOrtKsIzXLDNJbk, string BXJtIcyKpDV, bool uBmQXEviN)
{
    double yVmwlBPhfjkT = 625372.1398345461;
    string SDLxzlRcyh = string("ALlYGUFobasrBVkmHVGEcccBCNxAfCKqkNQrYLrmrUcmxQesytrVQTtebGhADZrIyaqopijcORCnqOGROfHhjnGxruRbGRDHFCQtpRJTjXivtQHuSoiwsuEvMJidRCqhmloNBeFNmjAyJngMYftTfCGMILAwOqMGQUVgpMIdlCdxhPilwiPkrIesNgJisbGFwDGwLFYVWDNVgSZEyyQDSuSsVWDB");
    string UPgVVmPbYo = string("ZtxAsnSTkHPFzyZuropMERvpiOvu");
    string ncXZZTK = string("NlKdpyGcfToTwzikTNMiiKcKYKuOfikSDgRpGZwkfYgvOLDKyPPQOhbPdQGZJIIqPYhyZfbPFeweeNkUBeuGbgZpXhXTGCwOIWBZOdvTDaloQKmGAzpWymFEWnxiIzhEeVZzRNWWOsvendrRLBqfLaQYRrnKiZyMPrBdqoNwIMruabhnTaGnsNWMxYWugtnjbJVxvhDIKSqEImFlzgaFW");
    string uWyzZynokNMUZ = string("wlbHLUaOopisaKswiOEJDsFEPzsBmjmNBdidngcLlwmyovGjPebUYgyRNuywrRFZwFZQqElomEYVClpHgkipQGYfvYMvRQwSyBmgAponWl");
    int zibIezbrJlu = -286839922;

    if (uWyzZynokNMUZ == string("RxxgnrUzdyNdLcSRFaklRlhdflOETsgSceEzQWHndybmRxdfeiFxVbMyyAocDYaCiDFQaqxCPzGeQqSXZrcriUiJSCtinUDchSpmNiHcgnMsSxHNaZxurFkiMgavvHaapwhlYNuQXFRTgQzJsYYGyVTAjBhwjlYkdSDzXlLzwOzTzQKmDcmqDWZamWAFoXcRrLdzjfeuGSferFUPBEEaGkLlFvZDnzqZLCXqADpBgaItYkYNOkMingtVmuxRHUF")) {
        for (int xnfDdjam = 1147590734; xnfDdjam > 0; xnfDdjam--) {
            ncXZZTK = ncXZZTK;
            uWyzZynokNMUZ = UPgVVmPbYo;
            uWyzZynokNMUZ = SDLxzlRcyh;
        }
    }

    for (int rWaWN = 2026874550; rWaWN > 0; rWaWN--) {
        continue;
    }

    return yVmwlBPhfjkT;
}

kjRlA::kjRlA()
{
    this->wgSpghAFRSARL();
    this->LMERNwUGHDsLCzRW(true, -724981734, -578055.2864660857, false, true);
    this->mUUnNir(string("jCqaAPijZLDZpUQeYphTDSzKgENnOQSAhOEAfvKpCtdSL"), 550707.607371329);
    this->GvhmSySEJMACKgFd();
    this->QhbtDSOEqQPlkEI(977906.1655116694, string("nusKnleISicVrOPZmMRfhqaxBePmyydCmtkCNrehYhLUpqQsZABmTeiHehEqPmbJJdVPkqbwCXvZpEjnYPNyicygelnVEDYAVRZJdaBfDwliXcjDpbMUcNjwmWtYMZghXQVt"), false);
    this->MzUVFxhmVIvktmN(11625.502361135694, 272569864, string("kClYcnuwQnVSptVIitpJiDJcLABvsggWXAxFOoVBMKSoWJyinCzytOPLneJlHkXuShuODgEUueFCAsOkUdqDDmmeLIMNHrTMYEEaogEoHWiOUjLiToQvWPwcBbZGKfPuhjTHWejBPPKhgziCrSzgVNUnWvNVqosPCjMEpfSukoGpCqpfEUAnTmCOtVzlgMiLvumYYOG"), -132131337, string("bqHhCLZNvkkTfQzBElJkderwHAjmEBHmsLqAJeKjnlnedPkIiFwNDsXUfaePUsNYsQZRDntEBEnBrHNlyzcMOFddimZSUtfrDEcKlUBSkHbqkQTVPTCkAHjIrrnJqRVkfWMATTproUdDUbVlUimDEUluBIUbOYbHcgYWxtVtkLQrPPpVNNtGlPqSIQNKWvytMkfarhjuXplwguOSjpesk"));
    this->uceAMM(1967596185, string("QXJamURzKZuFbSG"), true, string("CUVsuvjFeWqRfhRSTeyXGNgKhjFntsjdzYzEbWovSRNpUhJnPZadzDcmcsF"));
    this->GisrxUquKKRSQ(string("YMxSTzezRfkncLCOIGkb"), 1987007304, string("TSkkIfTcwKkNIzhhcZIikVmObHErOpvnjBUWPUfxtXOJFOADdxVUCIOPtzMigwXnpWICmSckGPKKVRIPpyTwPPqrihUoyNtbhrIgCRgEaAorTymLEdZjvgOWnamIGDzBApekOoagnyMAM"), -562259.7026993, false);
    this->eyXAr(-138880.70714680883, string("cvlnZkSbbVrkgNQNPryDEuguhIQJicyHKsfqqwdnGkaLIBmiagwixspwqOgqgBwICndRBXMZMMMkKhQSKlVEyEmveQvTBGQBsfUbbfxQSJpHyWTAupdmfVnRwAKlQihlwsVihzNoivbgjRfrFMfZvcnPyWqUuikLoSPsDCsIzgtXzQdLEPifpHNorh"));
    this->IpCRAxJrcLMKNaY(-2142464766, 249415.45097750096);
    this->hsqZjjkfDDltwoL(-513578.7395085363, -724931.2233199828, 729311484, 254381.52665107138, 212868.42893155);
    this->bOwmKntzWdgVIJbb();
    this->prIwaDBUbe(-699643.8316303614, string("wCAedLlrLlKkMlpkoUKmeZSGURCcmddQHENxFGpDFJCwDPpAclxNBgpMMtBZNcuEvaWxJAkDHSZgKUMYsEtLCIPUUnrfxhAQSRLBttAnVibwgnhNANbAkDWFQpdmwGtARCjHJrVMGUdIzuCMNYSpVxoGkrXPgBnHtzgdMQkFGydErWpKzbMaufGibRqJApPLJhGYuoQZEdkPWoiaeqfrfRQgAHvRAysxQqVvsRcEANaYWKrXmXEdCvUyJvBBQuw"), string("kSLweyoEgQVVQFhMFRtqaLjXhNqwhbFUBMcc"), 1144894589, -1563221041);
    this->LeStlZNJze(-890548.1347443099, string("iiglOXuITmmZOMqVrkLqIKXYeXzbvfcjlapBPUMdBva"), 922337.2503847068);
    this->DfVggyC();
    this->ZOoaV();
    this->kKchMwfTwaOXBhi(false);
    this->XqIwpRPQQgbW(false, string("RxxgnrUzdyNdLcSRFaklRlhdflOETsgSceEzQWHndybmRxdfeiFxVbMyyAocDYaCiDFQaqxCPzGeQqSXZrcriUiJSCtinUDchSpmNiHcgnMsSxHNaZxurFkiMgavvHaapwhlYNuQXFRTgQzJsYYGyVTAjBhwjlYkdSDzXlLzwOzTzQKmDcmqDWZamWAFoXcRrLdzjfeuGSferFUPBEEaGkLlFvZDnzqZLCXqADpBgaItYkYNOkMingtVmuxRHUF"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KGaRKPeygyuGt
{
public:
    int rHTKFHntybmiqcbg;

    KGaRKPeygyuGt();
    string XkTsfFRa(string WsHzVMMXjNpXeOWL, int KgOEpfXqHtd, bool eGjAuCydt, string LEeUzcqdWrWw, int iiAqHr);
    double lLxoi();
    void eUTnSnZkODrGypxy(double OnYcUpY, int silkfPGmiSDqtFo);
    double kRWRLtrCiq(string JqMZzEIpbgyF, string oqbUie, bool gjPefypW);
    string YqcbJeyLJuYp(double TuGxFe);
    void GDfMLMA(string wKobNsNGyZZWV);
protected:
    bool TgoCAxaN;

    bool FeLIhjhsj(string HPaRmZzRMzHWO);
    bool HDowJXC(string mPaebmktafs, int rxmQoOiPDT, bool JPfHLMdPAv, int oGcRYSVeq, double YGqxBlenyBazn);
    string UHFuPXtpwx();
    double MRlianA(bool wHYRkHGblrmpIL, double ARKgyDfpqkszxMqR, bool zPBbpQl, int FHxjcSex);
    double NgFgetHW(int tioPWrv, bool pAmavyNJ, bool cNOsjuQJ, double KMZLCK, double GcySQp);
    bool KkcSJvcTnz();
    void XBRSbAuwsm(bool wCNtLClE);
private:
    double kwoBc;
    string hMZShYSxKVtCTNwJ;

    bool cwTlsciR(string ZPlRzFOnIIMfbiJ);
    bool USVTILF(string gfIoYBkh, double vnufXdO, string ehEkapNGDRWEvcv);
    double tzgOWzBkCPdFhU(bool jPcaQE);
    string PqeKDtNZmAmLpY(double lNKjYr);
};

string KGaRKPeygyuGt::XkTsfFRa(string WsHzVMMXjNpXeOWL, int KgOEpfXqHtd, bool eGjAuCydt, string LEeUzcqdWrWw, int iiAqHr)
{
    double LcFEQFEnplaf = 494218.0379708304;
    int YiXUtmXagfrrTH = 2055997442;
    int aphPgfTtNa = 1014507009;
    bool Nenja = false;
    double NiNKBHRl = 800220.0122265556;
    double tuPpulExSLX = -113453.03043045335;
    bool DnGgJ = true;
    double cAkKKSBZqacRFonW = 1026717.1915512643;
    string tTqDxle = string("PxVuFhWajOotiNvyNZUdGVPfZhyQuntqLuNXTQegqkQnYofPBuAyqbhfovAQdrnxncwOJXWJgOiqPCzhyHBuzSHyanIG");

    for (int woRMDBvvYX = 413889457; woRMDBvvYX > 0; woRMDBvvYX--) {
        continue;
    }

    for (int zbuEl = 801881913; zbuEl > 0; zbuEl--) {
        cAkKKSBZqacRFonW /= LcFEQFEnplaf;
    }

    for (int aVTZpLrezuoj = 385319744; aVTZpLrezuoj > 0; aVTZpLrezuoj--) {
        LcFEQFEnplaf *= cAkKKSBZqacRFonW;
    }

    for (int OwidhehwMM = 1076599833; OwidhehwMM > 0; OwidhehwMM--) {
        continue;
    }

    return tTqDxle;
}

double KGaRKPeygyuGt::lLxoi()
{
    bool GncmIXiHFoLayr = true;
    int BaLwufvFnIn = -511166586;
    bool lxZGhMPuXZPvs = false;
    bool BRhGpSlw = true;
    bool iURriS = true;
    string BXdeBhtm = string("EAbhhdyaxTTlDZtLJIqKYYKTRqnmGgYmUuxH");
    string VlbPpYekzsROqr = string("rz");
    double MujmJe = -502207.7643208775;
    int YcqdKBDGIdatKe = -1509206480;
    int RaQSJtD = 1391862690;

    if (BRhGpSlw != true) {
        for (int fUMSfAh = 210525572; fUMSfAh > 0; fUMSfAh--) {
            lxZGhMPuXZPvs = lxZGhMPuXZPvs;
            iURriS = ! lxZGhMPuXZPvs;
        }
    }

    return MujmJe;
}

void KGaRKPeygyuGt::eUTnSnZkODrGypxy(double OnYcUpY, int silkfPGmiSDqtFo)
{
    int rftOwUuWSvztBT = -1507149354;
    double uAnqnJUEHtGSX = 341416.2922544798;
    bool qhbeAblJcf = true;
    string exGYIW = string("qKhduJYedTtBqgZHaZzpwerjvwDYDzpJeoeJhRLWfAhGZtYAiKpGjmdVCLrVsbEjHdtnawJuoXANJcasIQFmVVbsGfbEWVdZsyJfjQWcfieZRJLOTzChCxNbpvCReOIIhPibbNUHDCgEBGIvghPVmsNzrbhdUWDGzLNBTpYZRYMPymzSVXKTvkQMDfCULfeauHpLxxhuSDZniasjBkzWnrkk");
    int lLCOKxUEPNtnG = -2126645723;
    int TxPqBdUOMtXEH = -1396058658;
    double SVHAIVHqY = 390771.0578555403;

    for (int HHSZEgKIcktEZ = 1927134449; HHSZEgKIcktEZ > 0; HHSZEgKIcktEZ--) {
        rftOwUuWSvztBT = rftOwUuWSvztBT;
    }
}

double KGaRKPeygyuGt::kRWRLtrCiq(string JqMZzEIpbgyF, string oqbUie, bool gjPefypW)
{
    double CGwnPtPqgfhjyGr = 95358.14279305749;
    int xoTeUktwEzKEGwf = 349630041;

    if (oqbUie != string("FCgMAdrflRZiMLtebbKXeCHdRuMwzxTeodXtrLAgJhXlulXxnWCupNwzMqnYldJGhZFKEj")) {
        for (int bCSydvXSGt = 851207464; bCSydvXSGt > 0; bCSydvXSGt--) {
            JqMZzEIpbgyF = oqbUie;
            CGwnPtPqgfhjyGr += CGwnPtPqgfhjyGr;
        }
    }

    for (int qGqCkSAhhJJSOFQ = 156254546; qGqCkSAhhJJSOFQ > 0; qGqCkSAhhJJSOFQ--) {
        continue;
    }

    return CGwnPtPqgfhjyGr;
}

string KGaRKPeygyuGt::YqcbJeyLJuYp(double TuGxFe)
{
    string IepvMFaRHWr = string("qjAtLJiPQnGTyDlizYCfFYPsTnqxGnfSQUKxoxXUiQMZYOMQGuiPKDljUGWbdBHDoCiDHRwViYtDDBANWeDIHiqDoHkJOoFHRvJdcvSDlAUWhNWo");
    string APOoVNL = string("PSkrcykQgatvcTyogPtdRxGWvzgdIyVNMlGlahBhKbomspbaKnJGGToFVfWcAppktlMqDrQwURmG");

    if (IepvMFaRHWr != string("qjAtLJiPQnGTyDlizYCfFYPsTnqxGnfSQUKxoxXUiQMZYOMQGuiPKDljUGWbdBHDoCiDHRwViYtDDBANWeDIHiqDoHkJOoFHRvJdcvSDlAUWhNWo")) {
        for (int DEtDJ = 1393520746; DEtDJ > 0; DEtDJ--) {
            APOoVNL = APOoVNL;
        }
    }

    if (TuGxFe <= 489688.17421913624) {
        for (int EXSkkQIa = 1101509721; EXSkkQIa > 0; EXSkkQIa--) {
            IepvMFaRHWr += IepvMFaRHWr;
            IepvMFaRHWr += APOoVNL;
            IepvMFaRHWr += APOoVNL;
        }
    }

    for (int FxVVqoPoOajdoeZQ = 1322686679; FxVVqoPoOajdoeZQ > 0; FxVVqoPoOajdoeZQ--) {
        IepvMFaRHWr = IepvMFaRHWr;
        TuGxFe -= TuGxFe;
        APOoVNL += IepvMFaRHWr;
        APOoVNL = IepvMFaRHWr;
    }

    if (IepvMFaRHWr != string("PSkrcykQgatvcTyogPtdRxGWvzgdIyVNMlGlahBhKbomspbaKnJGGToFVfWcAppktlMqDrQwURmG")) {
        for (int NBMPH = 464409022; NBMPH > 0; NBMPH--) {
            IepvMFaRHWr += IepvMFaRHWr;
            IepvMFaRHWr += APOoVNL;
            IepvMFaRHWr += IepvMFaRHWr;
            IepvMFaRHWr = IepvMFaRHWr;
            APOoVNL = IepvMFaRHWr;
            APOoVNL += APOoVNL;
        }
    }

    if (APOoVNL <= string("PSkrcykQgatvcTyogPtdRxGWvzgdIyVNMlGlahBhKbomspbaKnJGGToFVfWcAppktlMqDrQwURmG")) {
        for (int xXKaq = 126869871; xXKaq > 0; xXKaq--) {
            APOoVNL = IepvMFaRHWr;
            APOoVNL = IepvMFaRHWr;
            APOoVNL += APOoVNL;
            IepvMFaRHWr += IepvMFaRHWr;
        }
    }

    return APOoVNL;
}

void KGaRKPeygyuGt::GDfMLMA(string wKobNsNGyZZWV)
{
    string dsopRaRvRmOPOzgl = string("PYJTFHTkCOwPeeEGvJkiwAUfZtAIEhckfCPciImuTUxkGhjjbWnYplsOTsXzoYpyJhMxKPcjEesocMCrrAIKkJoMvKBOByYxLRaoXMwQtgZNlUiBWtKxtBThffHuMvQdUKUjGszCkXTMfYoyeKslFSYpzohShqdQfREaQuwoQUnAtUApFEvIJqHLoCXIfMmxivkheDlgnKmBXiZunxOYUEYaFPiUpVigpGkEKSCdFEQ");
    double FqMBsykrF = -1043783.0006412399;
    bool akfuYJ = false;
    double EbJUPuMMM = -286584.80077174713;
    double wmRqhCWy = -1002777.0300228761;

    if (wmRqhCWy <= -1002777.0300228761) {
        for (int QuQVrMZo = 1225763065; QuQVrMZo > 0; QuQVrMZo--) {
            FqMBsykrF /= EbJUPuMMM;
            wmRqhCWy += wmRqhCWy;
        }
    }
}

bool KGaRKPeygyuGt::FeLIhjhsj(string HPaRmZzRMzHWO)
{
    string ehsKOmiLsKIElW = string("fgQuHwhlygCpXMnJgNvrOJPvCfwtZGyLPoxZxOFreBgTNdxakNRPsJJrlBvyZbAtGToGQPahFlkCNtARDCAbfLfDFBpchwiqdGutHxCDPlheGmhEgMplJHuScmakvylTbwVvgTaviIkWQHBjNHOOeGsng");
    int MijnePCDeDG = 565690581;
    int kktbEqfSIriINt = 899580653;
    string IvGMmMdALVh = string("kTIlTkeQYWRjZUjiNxYtkkLctCAjtbKQRdDXMoDNuwghhcToOKnkaUhkEEMnpvGjgjbSTUrEHSFpcrVGMUkMyETfIErnEypbPuIrufDUGTIwSCuAvQcbkfignGeMKpyXkxUNheOYaNc");
    double aIKRGt = -678243.1992084886;
    string mALPJNKjouSp = string("zcNptNtAUDSXmiJTwkSPwtHWfsjsLBQdfujkKsDfMoisxIBOcdSCYSCVpFfxwksKTqDagFdYIoCwvJeJgTrOclOdYldybhgPNDjKNxMbExqCNZjpgUEneDNhag");
    double QdABVdNOHTG = -607234.2726864871;
    string KEHeLlUYvch = string("isLdKnfQNTzBsSUPglZaonM");
    int YmIzjhELNHwp = 1494823057;
    double BkOrwpEdBUtctY = -222680.82696406427;

    for (int DycLMvBrPe = 1846312620; DycLMvBrPe > 0; DycLMvBrPe--) {
        continue;
    }

    for (int uelcGTRCRbWvLDS = 1587284344; uelcGTRCRbWvLDS > 0; uelcGTRCRbWvLDS--) {
        IvGMmMdALVh += HPaRmZzRMzHWO;
    }

    if (KEHeLlUYvch <= string("isLdKnfQNTzBsSUPglZaonM")) {
        for (int dYZqjWSqTnP = 912032734; dYZqjWSqTnP > 0; dYZqjWSqTnP--) {
            KEHeLlUYvch += ehsKOmiLsKIElW;
        }
    }

    if (aIKRGt >= -678243.1992084886) {
        for (int RbFdQRiqxBMNf = 2013130390; RbFdQRiqxBMNf > 0; RbFdQRiqxBMNf--) {
            continue;
        }
    }

    return false;
}

bool KGaRKPeygyuGt::HDowJXC(string mPaebmktafs, int rxmQoOiPDT, bool JPfHLMdPAv, int oGcRYSVeq, double YGqxBlenyBazn)
{
    bool FXAmFGmKhPNnjVI = true;
    string FSiBBMkJQbORblw = string("DrzNUVHHRfMEFfiRpfslVgxkiNiEfxQqFyFbZDgUYiAOAnAviuWLhMam");
    bool rjsFfTHKbVRwxwe = false;
    string rLScTE = string("FLBFJmLsYrgggimlgMcqZEkMzgAHjtMEJIzGkLpsrMVWMSOKQolEEIxbeNqokbyJEFKlBTbihWPdjMUsROBUTRESDcgW");
    bool UakSGzyKF = false;
    string EOfevZlTfg = string("KjXuJQoVYscEqupRQyAfrGXOzyvLMMTeAyiSqRnWBlpBkaxIiADwxRvKrlyFADwVMHsIHgrvAxqnyKoVKHNwoIjjunJnVCBGcIqiHJlAVDLJLhlLjXbxuPjbOkFsUoJtZqYYfXxfbysVWlXIXJgimvAGCJJRCRrhimoVmIFGmToXkyaBCkQna");
    double fnIIvVoMTqUZ = 198991.88996340023;
    string cyzmLACubX = string("nM");

    return UakSGzyKF;
}

string KGaRKPeygyuGt::UHFuPXtpwx()
{
    int keSCuXvDyRxQ = 1324448911;
    string CoziazuCKLYHtR = string("ripnfqzDiW");
    double LmjRjVfP = 138982.86627473956;
    int vCRQjQqUm = 646566634;
    bool OnOFiGuIbDIuOrC = false;

    if (keSCuXvDyRxQ > 1324448911) {
        for (int DduEkJCa = 937856979; DduEkJCa > 0; DduEkJCa--) {
            vCRQjQqUm *= keSCuXvDyRxQ;
        }
    }

    return CoziazuCKLYHtR;
}

double KGaRKPeygyuGt::MRlianA(bool wHYRkHGblrmpIL, double ARKgyDfpqkszxMqR, bool zPBbpQl, int FHxjcSex)
{
    double iwjHAAX = -46571.71997889159;
    bool rfmqUjH = true;
    int qfasbNgNXWuNbW = -709998143;
    bool NDBWOCRBLNiePT = false;
    bool LcvzY = true;
    int BtAXkX = -61038197;
    double lXbqxYZBezLyGlw = 737970.3622791148;
    bool ECFxQQACmEz = false;
    string reMtwxnTcjWAV = string("cqnwGFZJrAjjHHQjNvCdlfSvf");

    if (LcvzY != false) {
        for (int mgvdzMppVJlylu = 402071073; mgvdzMppVJlylu > 0; mgvdzMppVJlylu--) {
            ECFxQQACmEz = ! LcvzY;
            ECFxQQACmEz = ! wHYRkHGblrmpIL;
        }
    }

    for (int GXVFThjVNrXTmKTR = 869275043; GXVFThjVNrXTmKTR > 0; GXVFThjVNrXTmKTR--) {
        LcvzY = NDBWOCRBLNiePT;
    }

    if (NDBWOCRBLNiePT == false) {
        for (int GbHVCBp = 1441624683; GbHVCBp > 0; GbHVCBp--) {
            ECFxQQACmEz = ! NDBWOCRBLNiePT;
            LcvzY = ! ECFxQQACmEz;
            FHxjcSex -= qfasbNgNXWuNbW;
            lXbqxYZBezLyGlw -= ARKgyDfpqkszxMqR;
            iwjHAAX += lXbqxYZBezLyGlw;
            NDBWOCRBLNiePT = ! NDBWOCRBLNiePT;
            zPBbpQl = LcvzY;
        }
    }

    if (FHxjcSex == -709998143) {
        for (int BtDOttkZWjsz = 2041422593; BtDOttkZWjsz > 0; BtDOttkZWjsz--) {
            reMtwxnTcjWAV += reMtwxnTcjWAV;
            wHYRkHGblrmpIL = wHYRkHGblrmpIL;
            lXbqxYZBezLyGlw *= ARKgyDfpqkszxMqR;
            ARKgyDfpqkszxMqR = lXbqxYZBezLyGlw;
            wHYRkHGblrmpIL = ! LcvzY;
            LcvzY = ! NDBWOCRBLNiePT;
        }
    }

    for (int bhFMq = 2064170955; bhFMq > 0; bhFMq--) {
        lXbqxYZBezLyGlw /= lXbqxYZBezLyGlw;
    }

    if (wHYRkHGblrmpIL != true) {
        for (int KFNOWHZQEMRHlfFN = 1981963225; KFNOWHZQEMRHlfFN > 0; KFNOWHZQEMRHlfFN--) {
            rfmqUjH = rfmqUjH;
        }
    }

    return lXbqxYZBezLyGlw;
}

double KGaRKPeygyuGt::NgFgetHW(int tioPWrv, bool pAmavyNJ, bool cNOsjuQJ, double KMZLCK, double GcySQp)
{
    double XtcuZIbiOYznpGf = -1023044.035453558;

    if (pAmavyNJ != true) {
        for (int CsaCVEfZrYi = 676249977; CsaCVEfZrYi > 0; CsaCVEfZrYi--) {
            XtcuZIbiOYznpGf *= XtcuZIbiOYznpGf;
            KMZLCK -= KMZLCK;
        }
    }

    for (int tCtIliJConBegL = 831125074; tCtIliJConBegL > 0; tCtIliJConBegL--) {
        tioPWrv *= tioPWrv;
        XtcuZIbiOYznpGf -= XtcuZIbiOYznpGf;
        GcySQp -= XtcuZIbiOYznpGf;
        tioPWrv += tioPWrv;
    }

    if (cNOsjuQJ == true) {
        for (int WUbvmC = 203639894; WUbvmC > 0; WUbvmC--) {
            continue;
        }
    }

    for (int wpdrdUrG = 429169745; wpdrdUrG > 0; wpdrdUrG--) {
        pAmavyNJ = ! cNOsjuQJ;
        XtcuZIbiOYznpGf = GcySQp;
        KMZLCK /= XtcuZIbiOYznpGf;
        cNOsjuQJ = pAmavyNJ;
    }

    for (int TgRCAnrjKyHYkvxj = 96337933; TgRCAnrjKyHYkvxj > 0; TgRCAnrjKyHYkvxj--) {
        XtcuZIbiOYznpGf += XtcuZIbiOYznpGf;
        KMZLCK = KMZLCK;
    }

    return XtcuZIbiOYznpGf;
}

bool KGaRKPeygyuGt::KkcSJvcTnz()
{
    bool UWhpPDTsmIyailmj = true;
    int mpWBruIyHEG = -1375635656;
    string PywFtDG = string("lgnYFxyZNcYWbYBQEMEbSdOTlnerSUUDQgdntrZdnWcEjSMAKAhgNHutOyawoU");
    bool gJIxSsrV = true;
    double aLDSMLhODlmCB = 690603.6411814572;
    bool PaXtmuimJvneiuoz = false;
    int wmnTzysJGqQabOeV = -1234175661;

    for (int psmgzThSE = 1956764082; psmgzThSE > 0; psmgzThSE--) {
        PaXtmuimJvneiuoz = PaXtmuimJvneiuoz;
    }

    for (int tbhmQVIMtMxdkJny = 1635636655; tbhmQVIMtMxdkJny > 0; tbhmQVIMtMxdkJny--) {
        gJIxSsrV = ! PaXtmuimJvneiuoz;
    }

    return PaXtmuimJvneiuoz;
}

void KGaRKPeygyuGt::XBRSbAuwsm(bool wCNtLClE)
{
    double SPPGkC = -74328.32187776809;
    string fiXSWdJn = string("jMmOUARYVEQyooIoopaFgYuqxMxbZPDotCaddDRmEfZZCiYQLaJfQagOzifSYNfQZqcpxqbXOh");
    bool FvndZOZjlTvHNuQ = false;
    string RnduW = string("jKBmSsBDvTyPBfRyZlGTuqMjBQhJHitFUWmTNnLYqsqxhbnqlXgGDzVwKoYUxXXvsQFWlvbPmwniXuIlAbEcyRCupqRfYuMwFYttrWMiFeHLIJQH");
    int hQZXfRNf = 695736373;
    string WtPoLdLnjFwKCarx = string("ZlktQsORpymqPNrMoJlhlAYdplCqEqwMPzlTmETiRmrMKDATdSNwbdteXHvCEomySnnCVDQtuRpPovimRrQYspbeJhwlsFNgjcCyanpMDJmIJxTplkbJIqIaNszLl");
    bool lFpKpbpruacWemW = true;
    int FwnHAoLj = -1850087463;
    double daMDpTgtayGlrQ = -915436.4482936284;
    string yEBqMnsuPqbfggL = string("jvNfNQDrzfFQPMHHwOrDIDlGATvzVdovHvHUbElWTjWgugApTsiTxJVXyDytqALaprFwVvkNESGAEpVAoc");

    for (int xjStvyzyp = 1175643030; xjStvyzyp > 0; xjStvyzyp--) {
        FvndZOZjlTvHNuQ = lFpKpbpruacWemW;
        yEBqMnsuPqbfggL += fiXSWdJn;
        FvndZOZjlTvHNuQ = ! FvndZOZjlTvHNuQ;
        FvndZOZjlTvHNuQ = wCNtLClE;
    }

    for (int BzOVCnHtelPCRlqC = 1383577172; BzOVCnHtelPCRlqC > 0; BzOVCnHtelPCRlqC--) {
        continue;
    }

    if (lFpKpbpruacWemW == true) {
        for (int hRpSNzYtSjYGJ = 1270905280; hRpSNzYtSjYGJ > 0; hRpSNzYtSjYGJ--) {
            FvndZOZjlTvHNuQ = ! FvndZOZjlTvHNuQ;
        }
    }

    for (int fpYXgFLwYrXhB = 1003420986; fpYXgFLwYrXhB > 0; fpYXgFLwYrXhB--) {
        yEBqMnsuPqbfggL += RnduW;
    }

    for (int hZPgbsnblZ = 2031465567; hZPgbsnblZ > 0; hZPgbsnblZ--) {
        WtPoLdLnjFwKCarx += yEBqMnsuPqbfggL;
        hQZXfRNf = hQZXfRNf;
    }
}

bool KGaRKPeygyuGt::cwTlsciR(string ZPlRzFOnIIMfbiJ)
{
    double tehPCIoqjgvHY = -157454.7023281786;
    bool EUevOJ = false;
    double nVhxNeYD = -413876.42959319154;
    int oNczh = 408080765;
    string JuUkz = string("ObzexStIMCScvoUuDvYNeTXnlOIjmkdlnOGSsyLgItpUiZoLyeQjJdSBPiswhujxCvEyRgAHaIfDXmhSpWnAfMCcVHpWeBenRnUJToxNhoLjHaXqbp");
    string aNMndGLpZOLj = string("kLLKnwZYtVYNRhLzUizAKqKifdyBGpfeRPdXviNhheQFaRNvkyongnveFyibIdKqPCAcBTbwemzOCORNSbwjGvaggwtTpfCDStRYmyWZeCinQlsfxqGWcMwwymGhDyAgziOUSVcFCZGOzIHNoVlAGwWEtKWgNUWSRouJlOuhWtofNrxAxvCaFozJKdlbHpsmyAn");
    int wKfOif = -610743754;
    string JgXDvPqZsHR = string("IhuSCBsxuyQgCJickunwvjCyHklHCUhQeyZSWlqmLoSEEeMkcCOLbpHDHxbiGkqTVRgJnWnKSNUFKkxDmecVRMndPNdieqXBprbFXvlwEGQfppfoHhrIxFvxQxvSjFslVRgimSFlZzhxgCYptEXYzjzmItBOZOQpVtKEJXPacrXAVHFBVDECchnzTEmMprAEUHfRBNedsCgAgkBI");
    int VaIqFNbDvKqGV = -2031072595;

    for (int QerNDwtqKzdRnf = 1864964780; QerNDwtqKzdRnf > 0; QerNDwtqKzdRnf--) {
        JuUkz = ZPlRzFOnIIMfbiJ;
        VaIqFNbDvKqGV /= oNczh;
        tehPCIoqjgvHY = nVhxNeYD;
    }

    return EUevOJ;
}

bool KGaRKPeygyuGt::USVTILF(string gfIoYBkh, double vnufXdO, string ehEkapNGDRWEvcv)
{
    bool ZosivIrvve = false;
    string MltxViXoRlxKoa = string("QeCFBcrtUcIgmqmNsFhaCzEEtaogldfhrmtXYWHczbG");
    double MMdxP = -227444.8932356236;
    int HqGzjf = -1990161989;

    for (int vxjBu = 498107307; vxjBu > 0; vxjBu--) {
        MltxViXoRlxKoa += ehEkapNGDRWEvcv;
    }

    for (int fFuUGfIa = 859939525; fFuUGfIa > 0; fFuUGfIa--) {
        continue;
    }

    for (int yAPTIvrWXJg = 1876553163; yAPTIvrWXJg > 0; yAPTIvrWXJg--) {
        gfIoYBkh = ehEkapNGDRWEvcv;
        MltxViXoRlxKoa = ehEkapNGDRWEvcv;
        MMdxP = MMdxP;
    }

    for (int fwbJJIhU = 1978143474; fwbJJIhU > 0; fwbJJIhU--) {
        continue;
    }

    for (int XgOrY = 112872174; XgOrY > 0; XgOrY--) {
        ZosivIrvve = ZosivIrvve;
        gfIoYBkh += ehEkapNGDRWEvcv;
    }

    return ZosivIrvve;
}

double KGaRKPeygyuGt::tzgOWzBkCPdFhU(bool jPcaQE)
{
    int WxJMwVxTnOVWo = 295059995;

    for (int CZOIeprxdD = 375187780; CZOIeprxdD > 0; CZOIeprxdD--) {
        WxJMwVxTnOVWo /= WxJMwVxTnOVWo;
        WxJMwVxTnOVWo += WxJMwVxTnOVWo;
        jPcaQE = jPcaQE;
        jPcaQE = ! jPcaQE;
    }

    if (jPcaQE != false) {
        for (int qXxOpptyx = 454801706; qXxOpptyx > 0; qXxOpptyx--) {
            jPcaQE = ! jPcaQE;
            jPcaQE = ! jPcaQE;
            jPcaQE = ! jPcaQE;
            jPcaQE = jPcaQE;
            jPcaQE = jPcaQE;
        }
    }

    return -297266.42225364555;
}

string KGaRKPeygyuGt::PqeKDtNZmAmLpY(double lNKjYr)
{
    bool bRcZHOEUo = true;
    double KqLkjvHjmaiHJB = -411393.875751737;
    bool guTHbk = true;
    int SVDTWtEXdg = -1966709151;

    for (int TyQrgPlfAT = 1824061232; TyQrgPlfAT > 0; TyQrgPlfAT--) {
        SVDTWtEXdg /= SVDTWtEXdg;
        SVDTWtEXdg -= SVDTWtEXdg;
        bRcZHOEUo = ! guTHbk;
    }

    for (int YhfHLqXrrgemr = 714980213; YhfHLqXrrgemr > 0; YhfHLqXrrgemr--) {
        continue;
    }

    return string("HKAjLxLdFCuPNadxugAGQdiSAViBOtAKIhpZlweOBoTckzhirpHYDfSPCWsqzDOupkBBVjnVPCNQkgvClcYeKfpCugZmFoMEwsrEYznpthHWNzAGYtygomSNcjZyHDLsUfUkDlWkdXvBeU");
}

KGaRKPeygyuGt::KGaRKPeygyuGt()
{
    this->XkTsfFRa(string("YhcwuofTEejaNIKfXcRwpVqVFhtAVjumJpfbUtpDuRHKQIRFyDXxgUERfRKRuBMfjVzGorLliRlHKdUSQjzLRGArxBySPBUFFgtCPulheituuTcIUtiLMShGENDFDIlTQKBTxOeKBDggsg"), 1060770523, true, string("KlyOvPlhHFCISIQkoKnREGxYtLfxWmJkaMiPELGsCZjPDMqjVFhsndKbGlcvzmUibaNUhffTcpfGEUmdEMBnYlOALmcbXlKdraDIuWqWXAIakFPnrdtuQPdJZOoNtfybxGMQDgQSyOuZusypPFlTTnulkVidlVAaCmhUOPMJvRfwVEwGkliXOfBEgxyEzrxRcHvIesBpSzFjwJmkclpaodcCjQDsnflBrvwrLStIIcdtBYLNaslSYSOOu"), 220090226);
    this->lLxoi();
    this->eUTnSnZkODrGypxy(-643192.0334667697, -541098928);
    this->kRWRLtrCiq(string("aDGkLmHzsRclbEYdNujOjdYMbHPzIXUVRVuaiggNDvEUBQXCjbeEcNqNxYJmoraybLJciHP"), string("FCgMAdrflRZiMLtebbKXeCHdRuMwzxTeodXtrLAgJhXlulXxnWCupNwzMqnYldJGhZFKEj"), false);
    this->YqcbJeyLJuYp(489688.17421913624);
    this->GDfMLMA(string("NMfIfoxrEwOGFAwFsXzFAPPkzOGYeWMukZeWbBSyuZbdiDqteGbCOmQlAziiDtbvFHBAlBkjIwcRIcSUjZGJqdHKZexTvaGjEXjLNEpaPMbiaMIazUezxISPBtQserYcHDTxKoHLWhNaShDjbXIOJGmvKhaJshkxIPjvjTevTOiHrFhWyCqyWTyOINxOfddLEiGlzQHAi"));
    this->FeLIhjhsj(string("LeoVWNOuSPFockoKDxTCygZskWZDssiCyzNbJZZDBzRmJCcqKZBukKPXRhUmyWUHQNVhkpdFGvysZyvlxmKAwndtIkIULKaAHIJUsEIPzpcZbLaSOHuWbFgvbbInRGxqSbFNhWFmDiDYgCLYmloagDoazplluIN"));
    this->HDowJXC(string("joLnEWJMEovHOCTnBUSwbPJkRszlhmtHDWmFFuxjpNEvQQJUnGfmMKuJZCMKOtfHRNdquwrJYJMbfZsdwBbzfiIuabOcgzukyPQdunGYsMZQSZMwMFAdRVHlWevwFRrqJfwpZIETONCxQYReKuLvOgWEcrnhTKoVMUSPIPSiiCxRVFXZOzVjALrhmecuEVZlzYifnRsHxYrGDgTFoj"), -907836214, true, 714777019, 857458.4946270522);
    this->UHFuPXtpwx();
    this->MRlianA(false, 235790.5168445072, true, -816445070);
    this->NgFgetHW(239233499, true, true, 287181.24094101996, -280349.7048086805);
    this->KkcSJvcTnz();
    this->XBRSbAuwsm(true);
    this->cwTlsciR(string("vpeAGYmYSvfWBlslbFKklqVcvCitHchJXbYOKxplxXxnClfuBmdpaRMZaeflRrutUEjWnhPosbpmljxfFAAveTlHHlheASvXvyTmHkpBhIpEWUbwZUFjvxibqNtmGPSRoeHomYFVzBcOZLqTAqiyRmdlblHafoDKualAzflTpWjfQyLqYhwAwDDLyrOwUXyUHCJDDJVKljvYSwwBqeCxHMzYNAuQwXKwKupTAKo"));
    this->USVTILF(string("ndZjdneDBczGRdUDZkJwoWSMdIaFgSCxheDisHwJQKRvSoeFUNRrByYCiHrnDPNfRrIcPOTP"), -447401.76259950007, string("mwcvGv"));
    this->tzgOWzBkCPdFhU(false);
    this->PqeKDtNZmAmLpY(-568634.7971557304);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bfvNN
{
public:
    string ifXCJGfdLZOC;
    bool LASQmc;
    string NKENXtDPam;
    bool lANJESFBkxylNwMG;

    bfvNN();
    void yCPZW(int ZiWIia);
    int aAehNQdMLOFpha(string bQNwNNhaPfAI, string TPYyAkRLl, double nUAPxa, double jyihMyAq, string FkFBlEfI);
    double MVlbHR(double DVPzmOOi, double drpStMIGC, bool mCCYBOEmd, string AjvFTYnt);
protected:
    bool qxmetTqFsLlqTm;
    int kAQfQBSzn;
    int mOOKGS;
    bool RXQesjpV;
    int YfrjjOInJA;

private:
    double AlOQztNrOpgjT;
    double dsxDTD;
    bool NAQjcLNvrDtAcsQ;
    bool FAoCMspiArVaEOLc;

    int VMiEcIkkmn(int xYJJFkRGfuHX, bool RCzNFakQGkLWAKis);
    int QbsDrQRAJKCe();
};

void bfvNN::yCPZW(int ZiWIia)
{
    bool YPNbFc = true;
    int iGfYEWaN = 1811945909;
}

int bfvNN::aAehNQdMLOFpha(string bQNwNNhaPfAI, string TPYyAkRLl, double nUAPxa, double jyihMyAq, string FkFBlEfI)
{
    int IPRupFWJu = -776010992;
    bool hntoZKyleg = true;

    for (int XZpdLCFZqY = 1983905764; XZpdLCFZqY > 0; XZpdLCFZqY--) {
        continue;
    }

    return IPRupFWJu;
}

double bfvNN::MVlbHR(double DVPzmOOi, double drpStMIGC, bool mCCYBOEmd, string AjvFTYnt)
{
    double nLYeoixbQKCk = 905780.9999006727;
    bool zwgRSduqsfvNMph = false;
    bool fCszVjwOifow = false;
    double gHHsxMbuiYOh = 636628.5226014715;
    double iDWYTPztfP = 917492.6965455678;

    if (drpStMIGC > 730766.1510948397) {
        for (int UwxETFxajyTzNQXQ = 1969147619; UwxETFxajyTzNQXQ > 0; UwxETFxajyTzNQXQ--) {
            continue;
        }
    }

    if (zwgRSduqsfvNMph == false) {
        for (int OTzhk = 256293278; OTzhk > 0; OTzhk--) {
            AjvFTYnt = AjvFTYnt;
            nLYeoixbQKCk /= DVPzmOOi;
            drpStMIGC -= gHHsxMbuiYOh;
            zwgRSduqsfvNMph = mCCYBOEmd;
        }
    }

    for (int OYQTXuibsY = 148644250; OYQTXuibsY > 0; OYQTXuibsY--) {
        DVPzmOOi *= DVPzmOOi;
        fCszVjwOifow = ! zwgRSduqsfvNMph;
        AjvFTYnt += AjvFTYnt;
    }

    return iDWYTPztfP;
}

int bfvNN::VMiEcIkkmn(int xYJJFkRGfuHX, bool RCzNFakQGkLWAKis)
{
    double jwmLwzzoban = 1005670.662948736;
    int OgZcAJWEfk = 1560470599;
    string shhhqtia = string("eIDWSCEuudDbFNZcviosQTSFxSVDHqBhKlqBiGsnPDcPncQdkLreXoxqmtawXRqvYDExyvSsBWofopqXGpbsQKyUgFQEisUzbwxkwoGfHvGpMDeLGftQsrlinjrajgjyYphQNaaNWUzZrsmjrtdiCRvBlMCPcDNFsOiRsniVkktzSnyu");
    string xZGVaJrrYurhTk = string("iGdXtrEeLTXOGlzkzhZQedFKklgwnlCfjkjhUCIIrylbDXfvNMhJnzdzSKWWbwKRAPOkqVBDccvtVwrgoqxiLWLIQrAfFhLwvAtohdTKgKEOAHNnmIvxJbbGvhoFjFciRbccEYpCCgbsEiarAJMGmOtGqHzJxtgaXPzZmPQJsDAcPTOTAXPZUCUBApLcHhTCHzrAbiWoZeQVafsiICJrRIjwjmcvO");
    string TecCAoEBBarZlZha = string("dmELtWJkeQNTmoMTqWHYfXTKYuiYpvZEcdGdVbDXKESVuAxDyoUcbvxRVGRmkw");
    string ZGBKYsCzWQywcpu = string("skUjWCunesVfNLTnpShyUKtYXjaosrhHlEhzouKMZkqXVsxyqFRiSDxJdONCzuxs");
    int mTCSZocRWXeQlt = 347316254;

    if (OgZcAJWEfk > 1560470599) {
        for (int kGSFJxAP = 1918857980; kGSFJxAP > 0; kGSFJxAP--) {
            xYJJFkRGfuHX -= OgZcAJWEfk;
            ZGBKYsCzWQywcpu = TecCAoEBBarZlZha;
        }
    }

    return mTCSZocRWXeQlt;
}

int bfvNN::QbsDrQRAJKCe()
{
    bool pmcZlPFxHgravmfm = true;
    string UfOzDx = string("HymPyhUCBKthbosyiEByjWJyIwQhqCmFrOiddtYTvszCMyvWsVoYTFGveBfPHYPZjwGtjKxkqVkcVEnNWiNbmdIpXkohUaPggPMmoYzjxMwDTNTNxSznzfbyLoaDynEiKFZKraCEmcnxVQTwkvzJuKyYSGvEMVuerjvJJqGtwnG");
    int nxVwZ = -1167514547;
    string UuzXUkByY = string("iOzIbcKQIYJmvkIYJwfDOtGiaxmEJzBlZBtTizaYPhCMQmEHkKsWlgVIgRKCVEFnnUpodZVBtdCiVukRyZSXYMwGOSetkfluSMHJrfbSYZnJJvRFUwJXZSqDYtMjeJRdnzyvflNMqUuugNtZsBrGkdFiaLmEdsxiwZjImWGOJjvPOnXrRNwFbisYBAy");
    int QEivtHHZ = 133323537;
    string NKxpVy = string("VrqAXzdCKSQsMY");
    string YLfsxWNYV = string("weKcnxlqFrvzROiMVDwszGzoUaHGHwOEgrFtfYRigwpupyqZLLJjwpDXWBmrKbqTeoGjgKdxxYuumBIaNDLuwOtHfivvzyCpFHlTttNyZQwiXfTzZAdgEbXVKpVRXHilrhIEpaBGihcurZU");

    return QEivtHHZ;
}

bfvNN::bfvNN()
{
    this->yCPZW(-632473106);
    this->aAehNQdMLOFpha(string("ezQZGKhzDANlYddUtXsKYvLTnteXowyOxHUIcOoOcYQSJjKzzGSdaAlJNqtWfBHFRpeTRKfBbtsALbrmlnJUirUCeoLXMaBmJGHuHkFZasJLewtgOeatilFTxBLmPIGmCVIKpUPkKOzgxrisvSVSmoiNAdJDhlfytSvCAMCvvwEJHCUEwHdAIMglLAzfqlVlruITQJY"), string("JmeavghOMuQKWjGZkgezJvLYjtmfycDjnxANmhSHdetuyq"), 871951.769159867, 237206.72643443797, string("pCxodfWbJIr"));
    this->MVlbHR(-314687.8228475678, 730766.1510948397, false, string("BZQJbWtxnyHcaPhvauUshNGPDJsSlJFWMKrdkoLeBHsxFzKtIhzyUXphTGwNCPyQquiJHSUbmhGvicoUkSwseHTAGAHFgTYxNXEtLdEDlMGgOlinmtOMgiJZTwELOujmkhjtAjVbD"));
    this->VMiEcIkkmn(604248373, true);
    this->QbsDrQRAJKCe();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GGnOQoSp
{
public:
    bool pldoGRoqM;
    bool zoiCQx;

    GGnOQoSp();
    double WOQwvXtOhJ(bool wmCTMpOHOsQer, int ALyHeBPjuuLZtEcP, int MTHOtHYGWOWharpr, string dtEgOXQehsfIVds);
    bool vVgTsiEy(double cCTBrBmGJxLxynR, string SAuwFR, int phKOtrie, bool LSPnVZgtiysfN, string DbnSHsGqSlUpt);
    bool eWstdAalCTfRtJ(double afqtGuwRvmVkac, string etWnDJKqcIqb, double CtPzNz);
    string ACCKIPcxAIylS(string GFtUci, string wCjcV, double RVBrIqvCI);
protected:
    int sZJxRB;
    int eUiGaUGW;
    bool rbaBVMjvUFVw;
    bool cBSxeTztJZN;
    bool cdzVBqWX;
    bool nrdKdBUzQCabTpRt;

    int zrbYF(int gqNoyxeXbP, int azatOG, string AjisC, bool WlsvruDlUGR);
private:
    int nWcIDgDaqao;
    bool UYKllMFOKRVfLc;
    bool updIqg;
    string JoNKjEa;
    bool aDHZQh;
    string jcVykqRkBqGtAU;

    double natpGra(double uuTnyHHjOhQTsud, int VxFDRnrJJlmojHEM, string XcOnghrBcFn, string xsOYvSNUQ, string enpOgO);
    void dwzWHsomPzI(string VioBaCUPatGnrrY, string FiisFQIJWUG, double ceKNoMM);
    void NcXKJr(string ImXIfzXPJAk, double UxczEbeipuyFNNJ, double aSHfTFuOTOFcUh, double lLCalSSdewtUR);
    double DvyzYdZsLR();
};

double GGnOQoSp::WOQwvXtOhJ(bool wmCTMpOHOsQer, int ALyHeBPjuuLZtEcP, int MTHOtHYGWOWharpr, string dtEgOXQehsfIVds)
{
    string ftNUaZMy = string("nZIUsSYuKrkGPEZMhjYobWWtPuvPySnnfsGLPTuhckamEtyRrgjxrRXfOcFugFtjMLjMDIuWhtJlGVuPOsSmEzTBVrlJScOJarohWuDQtAfzsSOKjDpkZGKMLFgwcyEQJNbdspWPyaEMRWnxywLwTmlMccPNpyACxVYIjwSLOuCKtTOjAGxlFTyytewxyugekTIQrsjxmCcUYNQolZdGCmaJEmftOLrJvEJ");
    int UhRSYhUyirg = 244150932;
    string EGTPQCuIOqHQKF = string("lnHqVGJsYQXjdVZMjyXIExUzmObCQWXqNqcRKcRGwKrLXbBIuvRcfsVlAinYXNcmQaCzUcQPXbNgERKJGqsDNoEdjAKFghYnOxbTSkvNOgFoIHWiKMt");

    for (int EuGRbKVzdVivRKYO = 1121854514; EuGRbKVzdVivRKYO > 0; EuGRbKVzdVivRKYO--) {
        MTHOtHYGWOWharpr *= MTHOtHYGWOWharpr;
        EGTPQCuIOqHQKF = dtEgOXQehsfIVds;
        ftNUaZMy = EGTPQCuIOqHQKF;
        ftNUaZMy += dtEgOXQehsfIVds;
        ALyHeBPjuuLZtEcP -= UhRSYhUyirg;
    }

    if (dtEgOXQehsfIVds > string("nZIUsSYuKrkGPEZMhjYobWWtPuvPySnnfsGLPTuhckamEtyRrgjxrRXfOcFugFtjMLjMDIuWhtJlGVuPOsSmEzTBVrlJScOJarohWuDQtAfzsSOKjDpkZGKMLFgwcyEQJNbdspWPyaEMRWnxywLwTmlMccPNpyACxVYIjwSLOuCKtTOjAGxlFTyytewxyugekTIQrsjxmCcUYNQolZdGCmaJEmftOLrJvEJ")) {
        for (int UgzAW = 8881942; UgzAW > 0; UgzAW--) {
            EGTPQCuIOqHQKF += dtEgOXQehsfIVds;
            ALyHeBPjuuLZtEcP = ALyHeBPjuuLZtEcP;
            ALyHeBPjuuLZtEcP -= ALyHeBPjuuLZtEcP;
            dtEgOXQehsfIVds = dtEgOXQehsfIVds;
            EGTPQCuIOqHQKF += ftNUaZMy;
        }
    }

    for (int BNNWKCVhML = 529427289; BNNWKCVhML > 0; BNNWKCVhML--) {
        UhRSYhUyirg *= MTHOtHYGWOWharpr;
        ALyHeBPjuuLZtEcP /= ALyHeBPjuuLZtEcP;
        ftNUaZMy += dtEgOXQehsfIVds;
        UhRSYhUyirg /= UhRSYhUyirg;
        UhRSYhUyirg *= ALyHeBPjuuLZtEcP;
        UhRSYhUyirg *= ALyHeBPjuuLZtEcP;
    }

    if (ALyHeBPjuuLZtEcP == 244150932) {
        for (int DTVvbQQ = 223475273; DTVvbQQ > 0; DTVvbQQ--) {
            continue;
        }
    }

    return -227624.78274035922;
}

bool GGnOQoSp::vVgTsiEy(double cCTBrBmGJxLxynR, string SAuwFR, int phKOtrie, bool LSPnVZgtiysfN, string DbnSHsGqSlUpt)
{
    int oXozosui = -2035490075;
    int vkYHTLqZOsHEVb = 1501965191;
    string IsZtLu = string("XbXcxdnDAwqkSsZTGoQgvhSNIQaDvvNBbbvhALHYwVyuPbTydiayZNcjjKXjlgULQQ");
    double srbKwJCwkFLEE = 191866.35595182958;
    string AjqffIeBtXI = string("JlZdpGPVdXhJFzHaXysIrspaJDCsdLoGxiIX");
    int zFcovP = 173285813;
    bool IhUMBoaiKvVhZAyH = true;
    bool YHAEIIAijaFJLBdQ = true;

    for (int ZOGCkpSSI = 1173683789; ZOGCkpSSI > 0; ZOGCkpSSI--) {
        YHAEIIAijaFJLBdQ = LSPnVZgtiysfN;
        vkYHTLqZOsHEVb += zFcovP;
    }

    return YHAEIIAijaFJLBdQ;
}

bool GGnOQoSp::eWstdAalCTfRtJ(double afqtGuwRvmVkac, string etWnDJKqcIqb, double CtPzNz)
{
    bool kqltWqhOhnSTMF = true;
    string vSNblrHHikm = string("IIsCfDzyNzBZRnhwTgUfEkhXMytsIYdAVPMExmZhRNetTPh");
    string fUmsLZWNKlSUUPvg = string("iapepAnnFkECpMlMasupUSNcWSmpJzyZoZOhmXZBToAhZUKmdyeWdMUjBMxsfUSQZFl");
    double itaRuihhSol = 35333.25578871552;
    string VGxysyZQ = string("gvGYBHngYRLuzhLrEYIJnmIqHPtOpEquulnXMZggNbKYeXWNURjyxEscmsJjmjXNweSCfOwJWUCnPfSHfPTiwkfJODJkNssXbVMNeQRZQpmfFEpHDWwKDNdTBgqZkS");
    double mWUCkmKDBUKrwK = -974080.6508914648;
    int mSvQJZfqpztOMCNF = -1398994220;
    bool EgRslm = false;

    return EgRslm;
}

string GGnOQoSp::ACCKIPcxAIylS(string GFtUci, string wCjcV, double RVBrIqvCI)
{
    bool lBAdJIdGLpjtH = true;
    int paomflmfjGvrM = -1724135252;
    int XZwmFX = -206377653;
    string dJFOXa = string("kfggKcRrsRWFiZyYJyApXzWGJiRZZDDTwqzlPCZTyTdXKDeTVkRuFNBLChMmdcPQedVywFbbjjJioDkxGBVdVJPpiYfHwIMbbNzuQeVCIHJxqflrdEbAfEUHSkwGBTpbqneUqMCrmLmpuYgfKxpmeWmUGDYsDLRJuthQkuaPEzXaZNyrKjcuEEpWkFelPJtCvYkOJbcMgjnZFioRRmKEfakauidwupYHDBNeWESnXMoOUXh");
    string kJCHBlHoDPRPsoWe = string("AuYgWpEwQYWWTEvGNbfndlrChmauCKtVRifaXNFnXRpCHkjCzDMIePLvUDBaqqnnufsOhmiAMdeWKPZCFrciwzfqzSjlNiGsFSbCCswadSqaNhWHUsXYMZxdYxmirHvjszVMBPFedZCWlUkYALdLGHyXZqSWoBziJkmdJNHsGufuXMNAbWUFokYfUZUeRyPgOVwBSahavZCIIFwOVrsooGfpBktSFReDTmjfySICeCZiCbWBsnaoeEIjPmPr");
    string duwYxUUFKO = string("xeAHZifXzeRdUAmTFCjmAKPrlKIANEOgaospdFWFdqFtmuTmnYGuflsdnRN");
    double JboxknXlAkntAfx = 323155.1895436045;
    bool uLSAVvfO = true;

    for (int fdPOybaoaiJkLFsi = 626399545; fdPOybaoaiJkLFsi > 0; fdPOybaoaiJkLFsi--) {
        continue;
    }

    if (dJFOXa < string("xPjXSLWmWGcBAFbQbZfCIGrDXZYLQdzIZfHYEBHcgDCaujsicTxSzrrOppKuEPZOoFeZOLHYXUdmpABthxwOZlKNzhFYLXrRYvZElTNiAGTUwTeMZVfglDXSgaUoljSjibhyhYmwySmcWbaqgnWbropXZMprLddTNgtHEFBdPvHvunrjRZfjLrKUMMFQzavuXVbWJUqCsLZNyPVNbMpdYlDofttYoOkowfZtakdMHHpiixQuDonoQml")) {
        for (int wEoCZdf = 1205391540; wEoCZdf > 0; wEoCZdf--) {
            dJFOXa = dJFOXa;
            duwYxUUFKO += dJFOXa;
            kJCHBlHoDPRPsoWe = kJCHBlHoDPRPsoWe;
            duwYxUUFKO = kJCHBlHoDPRPsoWe;
        }
    }

    return duwYxUUFKO;
}

int GGnOQoSp::zrbYF(int gqNoyxeXbP, int azatOG, string AjisC, bool WlsvruDlUGR)
{
    double CYkdPXtDAv = -206639.81214137882;
    string dZLUeVKDFKRpG = string("WDeUoHdKQCbxQFxqbUFItiJvVbFEtXSKAjehmvEIrsUwqxySzVDpSGLrMKcoAnRYcIXpRRiQaIRRwZTOh");
    double oDqawjWZZBqx = -206837.98505931103;
    string ZuoUcnj = string("WOaHsqHnRCahlXCaHLxCwrotundHHbAWPKqrPKOgGJTxOlkmBoDSATQKagnebKoCkySAZEabSVNxWvNqcaZdhRpRFTCcPNgIUKIBChUqjJuPvMBoQjucsMsTcfYkgQoGcaUBnptVkjigvJilAYjswVKPeneuPyVYpDVPcAHiTirSekwUnINfvjqoTyNDcDGSZRBfKGMHZUcCrZUrTGVdHzfFNzJLGHoqVmzKIcOZckaTRuKAFAKfLU");
    string eOdhKHTkLuT = string("tsPgvRJSHJYouBKmQAVByXutYisFRmNXMbwVaSFcNsxkeVDtyPFzTuvjOtkRFxDCWzPlLIHXUJziIagnoUOHHSuvtcalvBrgkcrRmtjnzlzImPtXcRcdhUvfmylYyXgtpSrBLTFDYJXJADYhOfsFjhlXzRCihZQxJnYmUDuQiHgkkeKvYiMRhbLJMLokVNsocGFFZUYisWxmPtQRNoppcTzuubDOOXeyYXqcTCUoYD");
    double yFGja = -321600.10524943535;
    string sEiHBK = string("voBbNNjUDmCcEgtrqkdmaQYKgzKLtmzMFIymUeWnbDmCnKWXQUeKAQZyjAtgtkubghBecPvOZkwUSBDyQUuiJWrvIXjnNrCsgreyjBqtYoqUDBdzVzmAFhKNHjMhELXsbzlbg");
    string nPWxbpPIG = string("NgARJeRwBwOqDCDLYbKouiRmASgcbysKMuWYeeOycHpHlcEzpABYRLsKqwBmhnbxPrAPFBTbvxfcWNpcFBeWDPTRAtTpStyqvUBTLxzbxvGPCkrXnHmqWVGmZEXnWueAfNSyBbuBGTnkIhkfVbGkaVLByoaxgvAjUNlGoHztoCuJXjY");
    string xjloYOyW = string("iQPqSSEoMmXyNELzZQkXUKXlYgTzvllmYwmHjLcxiCReHIeCzLbJavZSDiCADJRHQZlYdVnTJCdhILFLepcaJxoskpcBAqRbjYkOlGNJJQvaUnsScfPPdwLYLUaDlsxZYlhrpdJKgKXuppYQqLuaFrdLkXGKEeZbXSjfVTbFmthZcfvBTPGXALZgXWOXlpc");

    if (eOdhKHTkLuT < string("NgARJeRwBwOqDCDLYbKouiRmASgcbysKMuWYeeOycHpHlcEzpABYRLsKqwBmhnbxPrAPFBTbvxfcWNpcFBeWDPTRAtTpStyqvUBTLxzbxvGPCkrXnHmqWVGmZEXnWueAfNSyBbuBGTnkIhkfVbGkaVLByoaxgvAjUNlGoHztoCuJXjY")) {
        for (int SLtHftMkpybrHm = 1605590910; SLtHftMkpybrHm > 0; SLtHftMkpybrHm--) {
            nPWxbpPIG = sEiHBK;
        }
    }

    return azatOG;
}

double GGnOQoSp::natpGra(double uuTnyHHjOhQTsud, int VxFDRnrJJlmojHEM, string XcOnghrBcFn, string xsOYvSNUQ, string enpOgO)
{
    double BfeQsCteeIroAbVb = 828679.7442455556;
    int rtYgqy = 2116624686;

    for (int bvaVDkRqMlVY = 1331470270; bvaVDkRqMlVY > 0; bvaVDkRqMlVY--) {
        xsOYvSNUQ = xsOYvSNUQ;
        XcOnghrBcFn = xsOYvSNUQ;
    }

    for (int OiHPWZPBGjpQy = 2070869401; OiHPWZPBGjpQy > 0; OiHPWZPBGjpQy--) {
        continue;
    }

    for (int ItppOc = 1717693500; ItppOc > 0; ItppOc--) {
        XcOnghrBcFn = enpOgO;
        rtYgqy /= rtYgqy;
        XcOnghrBcFn = XcOnghrBcFn;
    }

    if (BfeQsCteeIroAbVb > 828679.7442455556) {
        for (int vHkpUiyiXihzw = 465192314; vHkpUiyiXihzw > 0; vHkpUiyiXihzw--) {
            rtYgqy -= VxFDRnrJJlmojHEM;
            BfeQsCteeIroAbVb -= uuTnyHHjOhQTsud;
            enpOgO = xsOYvSNUQ;
            uuTnyHHjOhQTsud -= uuTnyHHjOhQTsud;
            XcOnghrBcFn += enpOgO;
        }
    }

    for (int PQJsmrNrazDPlJQ = 528054259; PQJsmrNrazDPlJQ > 0; PQJsmrNrazDPlJQ--) {
        XcOnghrBcFn += XcOnghrBcFn;
        rtYgqy -= rtYgqy;
        xsOYvSNUQ = XcOnghrBcFn;
    }

    for (int DfVnfxhrwSFymh = 309587437; DfVnfxhrwSFymh > 0; DfVnfxhrwSFymh--) {
        continue;
    }

    return BfeQsCteeIroAbVb;
}

void GGnOQoSp::dwzWHsomPzI(string VioBaCUPatGnrrY, string FiisFQIJWUG, double ceKNoMM)
{
    double IprRifFBdK = 903291.9266324951;
    double mASMuHT = -422061.00350716873;
    int EiIggWYXv = -1780605486;
    double UVRvpR = 263346.1746138896;
    string mAmdAVcRy = string("JwWoitPnXiZkPgVm");
    bool dTVJdCfTNFPnWz = true;
    string JPwTjmx = string("AEayqVyfZGpIqsCeJTRzTwUp");

    if (EiIggWYXv > -1780605486) {
        for (int GpIwrBjAJIoxj = 504735330; GpIwrBjAJIoxj > 0; GpIwrBjAJIoxj--) {
            JPwTjmx += mAmdAVcRy;
            JPwTjmx += FiisFQIJWUG;
        }
    }
}

void GGnOQoSp::NcXKJr(string ImXIfzXPJAk, double UxczEbeipuyFNNJ, double aSHfTFuOTOFcUh, double lLCalSSdewtUR)
{
    int pkcQkIJGEwBOJmmr = -1446649948;
    bool iQdruDPJJEHVp = true;
    int wUuir = 308958164;

    for (int OsvxhzuFZD = 634487021; OsvxhzuFZD > 0; OsvxhzuFZD--) {
        continue;
    }

    if (aSHfTFuOTOFcUh > -848933.2713464245) {
        for (int HRQkEM = 1512149225; HRQkEM > 0; HRQkEM--) {
            lLCalSSdewtUR *= lLCalSSdewtUR;
            lLCalSSdewtUR = aSHfTFuOTOFcUh;
        }
    }
}

double GGnOQoSp::DvyzYdZsLR()
{
    string VjGmnIFIFTLl = string("hCrgxFDTZRnChOOKL");
    bool PgdYkkLjXJh = false;
    bool mPpfOuHtuzNkUo = false;
    int axtdiUSG = 226277619;
    bool GYeQskAwZPSnD = true;
    string lSYzDhxrMah = string("lSHNVNWfzQYzfyVasVTDFjiRfFMrTnJFdEHRafRsHLoQLPeYPJZLbnVeYVnrKkNFIslskDTGuaZApAVbmzUAtiyGPrlzZckintnfDZHorshMGrtTduJxsXgLKELOqRXEpesbFKFfcKcnwLGT");
    bool UMSrkyiBjWE = true;
    int ZOPtPahk = -694450660;
    bool NuBfKDNo = true;

    if (NuBfKDNo == false) {
        for (int fWMscgNCCOpR = 485482018; fWMscgNCCOpR > 0; fWMscgNCCOpR--) {
            continue;
        }
    }

    for (int WPJnv = 1411622002; WPJnv > 0; WPJnv--) {
        VjGmnIFIFTLl = VjGmnIFIFTLl;
        mPpfOuHtuzNkUo = ! GYeQskAwZPSnD;
        mPpfOuHtuzNkUo = ! PgdYkkLjXJh;
    }

    for (int zQhdOSsbv = 1042639766; zQhdOSsbv > 0; zQhdOSsbv--) {
        NuBfKDNo = UMSrkyiBjWE;
    }

    if (NuBfKDNo != false) {
        for (int wOSxearFctPLNbyV = 259362546; wOSxearFctPLNbyV > 0; wOSxearFctPLNbyV--) {
            GYeQskAwZPSnD = mPpfOuHtuzNkUo;
            UMSrkyiBjWE = ! UMSrkyiBjWE;
            ZOPtPahk = axtdiUSG;
        }
    }

    if (axtdiUSG > -694450660) {
        for (int vGCLyCWppY = 1634275247; vGCLyCWppY > 0; vGCLyCWppY--) {
            NuBfKDNo = NuBfKDNo;
            PgdYkkLjXJh = NuBfKDNo;
        }
    }

    if (lSYzDhxrMah < string("hCrgxFDTZRnChOOKL")) {
        for (int GqBDoxKDiviEmbxy = 594571948; GqBDoxKDiviEmbxy > 0; GqBDoxKDiviEmbxy--) {
            continue;
        }
    }

    return 73507.93598069582;
}

GGnOQoSp::GGnOQoSp()
{
    this->WOQwvXtOhJ(false, -920454297, -906580309, string("bwBLuKYzKgjwFtuyyEUlpRcZSQamLwZuWkCyLZFKgOqxIvUxetoVrsCmsQVlNumQJTRRYAeautEDqS"));
    this->vVgTsiEy(-470276.02646143053, string("gwRItumXzKzZ"), -1110994347, false, string("kOAkkDjxphdWITXgcoHoRFsJwenKhqBYXuwqzkQKDtSvGcwSKklRjPMtVONdgQDoFZTCvMnwnapmGXEcSPKxJJSBoopmdEgrhvjATVBoLMvYJeWxzGnxYklFbGJqkJYssAFfllMkSegBKEPRKmUapeeLimQwRCdCLgpdXLKAYaCQhkUTAJWmVrudGnTJM"));
    this->eWstdAalCTfRtJ(374113.9000546029, string("bOhbkRSjuTCbgxvmJXnGdBixuSwYAEITRcgEtuaEzQCkuFgSPiDVFbSAgXnwtcDXCgKWuaOEPbUyWeWXpOFZvMoescGxOEdhJLsKDTwxmYWpnqzuzQYQprpwWnuSWPMPADTltGdmqxLWlKt"), -732470.4812882537);
    this->ACCKIPcxAIylS(string("xPjXSLWmWGcBAFbQbZfCIGrDXZYLQdzIZfHYEBHcgDCaujsicTxSzrrOppKuEPZOoFeZOLHYXUdmpABthxwOZlKNzhFYLXrRYvZElTNiAGTUwTeMZVfglDXSgaUoljSjibhyhYmwySmcWbaqgnWbropXZMprLddTNgtHEFBdPvHvunrjRZfjLrKUMMFQzavuXVbWJUqCsLZNyPVNbMpdYlDofttYoOkowfZtakdMHHpiixQuDonoQml"), string("xULygGiFqlMcvMgafNPnszkjTaaiUdmCnDZdDpaFTVJZZReodakIkBoOWwBzJfUhULTBFsJWsUMtRvdnAjqAqABhhykGHXWfYLAfhLKbApqrNCzicYAkoiUsCCVlODtvjCMXZbDapPVvpbzYZ"), -994438.5304541162);
    this->zrbYF(6610225, 1715879812, string("QslpbUJiomCVXFatsWzMGuQiJxOmgXLvvnXpQeYweEzzpaEjCyYaqtyowKvMFXIkGEHSUPFECaPNXVJxFtpyVhQkxRGfjzFqiJwVJTJcxVxeVQdSVBRPLylSzMFSVWFGWyzRuxpvuqtJnefAvPVTCTMLiwbohRxbEkYWPAEsIJnHuuvDXSCoUTfCaLPdywMEEqCtpZCfXFfATWAxsulpuyjpRDHsbgxGuknrSBKIyVbuFR"), false);
    this->natpGra(616890.2505538194, 363108236, string("vEkBaHGlFdSPmBYcTxuzKGeBlnxhNzFeVFWnjzfAQfZjrMZAdfsNgZZGJHluXFWkMOgeQNfLOUUwMaxbLZTJiuCjieVojByYq"), string("TAYVWgDZNEtqcpCBGfdNiWZElYICSWDLGmJgwlVPmPyfGopgjAAojlIKDUKCYmZhdDyfHjRtdqrdzqmCjDya"), string("ELNuRRWsOhCmORlTbCqUKLMXgWRTdVhJWkEiaTkhQluiKLtlVmCKDJwSLG"));
    this->dwzWHsomPzI(string("PNzOUQYHnxeQzkWmGpDCPNeokDqmwNteEtzYLZNCFgkbaGnmnpqKGwQqanmoXGdPUWcDIaKVSBeFYOyRxsnXrUBkrrfGeUlRUiKTCofxFlfwSjKuHaGWWtqbbOjenmbjWtQneGJQQBeTvhvSOWOTjQbCcBJPxskRktBaofWidTPvLbbrCNIIckuHsYzCHZBFODDROmyGyexfSDFhVDQSipWPeVOgnwZcAPYmcU"), string("EubAeYDxgbMkyIPVYUaXuZbHMiWXpiwDLpcmCdDQeJmCQYRyXYVsqVWrtUSsirQhNQOvt"), -628603.0601239952);
    this->NcXKJr(string("kdPLgAmpGLnAjVXPxEVVgxfMdHJpKqQtiZEeVcNTuCbwcQLqwKgJpZyTDEbqOpLYFCxeiQqJBDDALXYDUyFbVIvZGtmanVieBXOzODsASnyBjYBqCaXxBOubewQsulsURDPWExnmqlZAUxbbZyAcIfFuIiB"), -848933.2713464245, -267042.3317551353, 631129.9842816354);
    this->DvyzYdZsLR();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uQwEC
{
public:
    int XQRLHCHrXS;

    uQwEC();
    int FeXGGZfsGbsU(bool rTnLOZpsE, string cvsqwAvdvdrM, int juBhSdaq);
    int QKEroGtnT(double fgSIhNLBbobyG, string qTjubdV, int SnldMfmGVKSy, int hHgoyWsAqiRDsCLi, int oyPujUPFBDsUFGxJ);
    void MVkswR(double rEITUEXdCyBEOfdr, int SVNzE, string zmmqLrWWQJyyITds, int RiAFWhdlHsKY);
protected:
    bool UwcjROpmmpJL;
    bool WDPSiLhf;
    double ppADsEiivTGBOVYa;

    int dWzHacegFCLczfyM(bool iJFjmMcRnDDmIqO, string titJMytKtQesf, string gXZmgkFzwew);
    string jWXgLuSM(string AYWwbac, int krVRPMJMh);
    string FdXHAPUvShBVLB(string UuTVOeNgT, int uJTKPSXjkZitjH);
    double McwqmZgEcitOh(double ISqxpAvriqkhf, double OkRVbNGAJa, string tJggmQVRSSkIoMU, bool pczWsXl);
    bool DEfCTqdBfjKOqFPz(int NnspeGFMrzW, string hnnpVXVrXWbGeeU, string HZOeAHOxuS);
    bool kZDxy(bool FnrOFWdjTPu, bool CRWqHPIozYYy, string vfLPyuc);
private:
    int ElmrNnAwUUZ;
    bool CRqwOHXTeEQ;
    string VSlhUez;
    int ULyrLpPuQHdvP;
    bool lRebVrFnldGW;
    double awVLubLkFlCno;

    void KloeaeKT(int tADKpjtZ, string sFTqypGCkfB, int CFMEJplgYDYZMWU, int PusoHaWqs);
    int DyNLcTsWeTH(bool UJHEhUeOg, bool cPDSOlpIiZUbPb, double LThmh);
    int knvsVuJZyqt(int TMqxohuSYj, bool TjuKGDYF);
    int UPEgwSap(bool BHHaXX, string FdcEzBIo);
    bool AHrYOleUFefBUKHU(int nrwgkWCWlrdKIno, double fFkofBx, bool WXYaLehqqAcy, bool fFmazoLxqcMKWE);
    string WYPgjwgJhUEVd(bool dadsIUARmQ, int roDDtpbWMvUTimRs, double FSJfPC, double DgwAiLdoCYApanbf, int nzlUOrjftZYo);
    string JMOheGEr(double xWnJuPZPCgIyv);
};

int uQwEC::FeXGGZfsGbsU(bool rTnLOZpsE, string cvsqwAvdvdrM, int juBhSdaq)
{
    double rSBSjuzeH = 959381.3861467065;
    int kTBLmriqGdQv = 641193680;
    string MYlsPJf = string("lUnJkOUbjpKXEmjZwOMPRuoHgzjNXnNkeaZgeUzTSqHBaTcFFiDEBgXhgqIOEHkFYOmPgLQhMuFTZPcwlEdytVxezURNmyTgLYgtumhFHIGJsUNfmZNdxqbMfFnwaGPtKSSHfPzIjgHxVKFRNxIhISEyTYVXYQPFWaFpMJezFplYZOMgCBWSFRWznIhRUoHtYBNHpHTpDeufgECZxgtEgeKGVOgk");
    double ZtWjZXPBUSsENL = -335273.99779123906;
    double LPBzXrCaAROZ = 743061.62705371;
    double tfslrTz = -600350.3144588164;
    bool AlWTh = false;
    int LoQWv = -1345770069;
    string frLXiaJoyeNErF = string("iCoOqgxqDAHELMgKyvKCEyTgEilKMVUKxkGIwypIPIfjeoAWMLYNCFuxlXpsjmarTiiXxDvrddYReQEiNuHKRFhHTSocosTMOhtXxgcjgqSBatWTSAixMwnqatqOqJsLyLaKwWxHTZTe");

    for (int luZvWYNouqIMp = 1931220525; luZvWYNouqIMp > 0; luZvWYNouqIMp--) {
        juBhSdaq = kTBLmriqGdQv;
        tfslrTz *= LPBzXrCaAROZ;
        tfslrTz *= ZtWjZXPBUSsENL;
    }

    if (kTBLmriqGdQv < -1345770069) {
        for (int DPawP = 368360329; DPawP > 0; DPawP--) {
            continue;
        }
    }

    for (int lDSggkykUWcvss = 20576939; lDSggkykUWcvss > 0; lDSggkykUWcvss--) {
        continue;
    }

    if (kTBLmriqGdQv >= -1746752151) {
        for (int vcwVnyNsAcSXSILE = 2056543796; vcwVnyNsAcSXSILE > 0; vcwVnyNsAcSXSILE--) {
            rSBSjuzeH -= rSBSjuzeH;
            rSBSjuzeH /= tfslrTz;
            frLXiaJoyeNErF += cvsqwAvdvdrM;
        }
    }

    return LoQWv;
}

int uQwEC::QKEroGtnT(double fgSIhNLBbobyG, string qTjubdV, int SnldMfmGVKSy, int hHgoyWsAqiRDsCLi, int oyPujUPFBDsUFGxJ)
{
    int AYTmstPfTTqGzTY = -943060693;
    bool omFSj = true;
    string anGfngHSGlMlDtT = string("HOjMYxltKopcViKZxSxOlIoSWXRmvxXtaVSrnVnCcNixFyAaZkcmeUPRSYwEBrj");
    double bKTNr = 641914.1346021071;
    string xCUgIlMert = string("DsnlSBLlTgqkVHaXWEOZzfiVVCuYvbrdDsLhgEHxYETBACHccFJuZaRRhkttiYylYfOvioMQEpKUJAKljhmEPfirNgMOnMurWAxJqUpXNybuLzqKLeAsNv");
    string YYQTG = string("lvUgbeVUFUBCYdKDBGFCfTzcjRLYaaYGVKqqFwWyAGbqtgoYulvehXWYsegskvqFVlMPJgVtSuYUEqdoWASwTDvjgdVWxyzlPFwkzijlFKSJkTgoYPPbyrXmwExUutoGBDkzCNxzv");
    int OKdAbyyBmSlzkNf = 1047285369;

    for (int yXrLl = 1791073596; yXrLl > 0; yXrLl--) {
        bKTNr = bKTNr;
        SnldMfmGVKSy = oyPujUPFBDsUFGxJ;
        AYTmstPfTTqGzTY += hHgoyWsAqiRDsCLi;
        anGfngHSGlMlDtT = YYQTG;
    }

    if (OKdAbyyBmSlzkNf <= 1047285369) {
        for (int zGTYZNNTxDPw = 679102634; zGTYZNNTxDPw > 0; zGTYZNNTxDPw--) {
            xCUgIlMert = qTjubdV;
            oyPujUPFBDsUFGxJ /= OKdAbyyBmSlzkNf;
            xCUgIlMert = anGfngHSGlMlDtT;
        }
    }

    return OKdAbyyBmSlzkNf;
}

void uQwEC::MVkswR(double rEITUEXdCyBEOfdr, int SVNzE, string zmmqLrWWQJyyITds, int RiAFWhdlHsKY)
{
    string lnPhk = string("RYMOqhtKuTTPjilnrWbANNGTzkzGmMLrpuiDvgHsTtcnpuhjbXtgAraDJFKdpkPKNCbJbkrdjeSOsfqRUbMK");
    int wwhyBZV = 107261229;
    int AIHwyGtaDM = 1627532548;
    int fTKMMdlkpQAr = 1744136812;
    string lIXZjOSZeKrtl = string("zskoWqcuZaSajUWefwZDMrxXIZRTKYbQjedsmbwiMmBhRAfaOEbWguYJeLAipHcBnJuwOCbUCKdoJTksleyjaZGLdKSOyzMUBcYuiVJIOoBlzYrMCJcpJPUyCrTGrASJMjGTYApBuIEb");
    string FrzIZYzNHPCVclmO = string("reNrJAlbljFyXwXfekaDirLqoPrCgLpDTLibZLmTGaMGwFkGmeSsdWEdYqQPeyHxbaIFTbGJIMyjmvfyxolfk");
}

int uQwEC::dWzHacegFCLczfyM(bool iJFjmMcRnDDmIqO, string titJMytKtQesf, string gXZmgkFzwew)
{
    string rBalmHQgiU = string("dIXZKsdlGgppkLnnOcdovhxvjfnBogJtTmPVdqIPnTJNfKTfNdXKrUTPWywbxZTaRZLAWkFSHDpUvU");
    int bqsCSCVuzbQIYPx = 1999187823;
    bool OAhqNF = true;

    return bqsCSCVuzbQIYPx;
}

string uQwEC::jWXgLuSM(string AYWwbac, int krVRPMJMh)
{
    int TomVttyEYh = -1690795029;
    double uldQK = 128766.28672702577;
    double VRfnIh = -297885.22919992683;
    int auyRx = 1647606880;

    if (TomVttyEYh == 65883188) {
        for (int fnrvBkpqBTL = 1588971545; fnrvBkpqBTL > 0; fnrvBkpqBTL--) {
            VRfnIh /= uldQK;
            krVRPMJMh /= auyRx;
            krVRPMJMh *= krVRPMJMh;
            krVRPMJMh += TomVttyEYh;
            krVRPMJMh -= TomVttyEYh;
        }
    }

    return AYWwbac;
}

string uQwEC::FdXHAPUvShBVLB(string UuTVOeNgT, int uJTKPSXjkZitjH)
{
    int xSCQlnbZgAknHuVS = 826964369;
    double ehXftESatV = 288652.7078103603;
    bool DlhbpKXBBUyZAKB = true;
    bool OoYZfFNcipdTqwFU = false;
    int UsYRRExdaHCn = 1802724579;
    bool jzhkYKOygAaYf = false;
    bool jokSvJptvHM = true;
    int bdSRUCBs = 1447827979;
    bool VhRrX = false;

    for (int UgWSPXcstio = 441995399; UgWSPXcstio > 0; UgWSPXcstio--) {
        xSCQlnbZgAknHuVS += xSCQlnbZgAknHuVS;
    }

    for (int udrlOMm = 1441139920; udrlOMm > 0; udrlOMm--) {
        bdSRUCBs += uJTKPSXjkZitjH;
        UsYRRExdaHCn -= uJTKPSXjkZitjH;
        jzhkYKOygAaYf = VhRrX;
    }

    for (int BlTafqXkB = 568494723; BlTafqXkB > 0; BlTafqXkB--) {
        continue;
    }

    for (int EsYUBlK = 1413423066; EsYUBlK > 0; EsYUBlK--) {
        UuTVOeNgT += UuTVOeNgT;
        OoYZfFNcipdTqwFU = ! jzhkYKOygAaYf;
    }

    for (int PhBlTjiy = 1573285442; PhBlTjiy > 0; PhBlTjiy--) {
        jokSvJptvHM = ! jokSvJptvHM;
    }

    for (int UVIdgTDrzULUhWZx = 1192889267; UVIdgTDrzULUhWZx > 0; UVIdgTDrzULUhWZx--) {
        DlhbpKXBBUyZAKB = OoYZfFNcipdTqwFU;
        bdSRUCBs *= uJTKPSXjkZitjH;
        UsYRRExdaHCn += bdSRUCBs;
    }

    return UuTVOeNgT;
}

double uQwEC::McwqmZgEcitOh(double ISqxpAvriqkhf, double OkRVbNGAJa, string tJggmQVRSSkIoMU, bool pczWsXl)
{
    bool yJEDaVYCWSeJk = false;
    double YuHvEOBysU = -576670.6309345294;
    bool wCSHsgTq = false;

    for (int XCGEAIH = 1599263576; XCGEAIH > 0; XCGEAIH--) {
        continue;
    }

    for (int LFEaSffQGxleDGKD = 1700063878; LFEaSffQGxleDGKD > 0; LFEaSffQGxleDGKD--) {
        OkRVbNGAJa /= ISqxpAvriqkhf;
    }

    if (OkRVbNGAJa < 976659.4585852844) {
        for (int zGkxivbiChzWI = 1542098501; zGkxivbiChzWI > 0; zGkxivbiChzWI--) {
            wCSHsgTq = ! pczWsXl;
        }
    }

    for (int qbAZzcTKKviMxej = 1733392740; qbAZzcTKKviMxej > 0; qbAZzcTKKviMxej--) {
        wCSHsgTq = wCSHsgTq;
    }

    if (ISqxpAvriqkhf > 976659.4585852844) {
        for (int ERpdPOXzLDYyuVT = 52716633; ERpdPOXzLDYyuVT > 0; ERpdPOXzLDYyuVT--) {
            yJEDaVYCWSeJk = ! pczWsXl;
            YuHvEOBysU -= ISqxpAvriqkhf;
        }
    }

    return YuHvEOBysU;
}

bool uQwEC::DEfCTqdBfjKOqFPz(int NnspeGFMrzW, string hnnpVXVrXWbGeeU, string HZOeAHOxuS)
{
    double czMwhoiaL = -31270.5850742479;
    int UkdpNJvKDA = -1639457042;

    if (HZOeAHOxuS == string("NXMq")) {
        for (int cFHsqewvfuqmvWfG = 917048284; cFHsqewvfuqmvWfG > 0; cFHsqewvfuqmvWfG--) {
            hnnpVXVrXWbGeeU = HZOeAHOxuS;
            HZOeAHOxuS = HZOeAHOxuS;
            HZOeAHOxuS += hnnpVXVrXWbGeeU;
            czMwhoiaL *= czMwhoiaL;
        }
    }

    for (int RzFfZR = 813997420; RzFfZR > 0; RzFfZR--) {
        HZOeAHOxuS = HZOeAHOxuS;
        hnnpVXVrXWbGeeU += HZOeAHOxuS;
        czMwhoiaL += czMwhoiaL;
        hnnpVXVrXWbGeeU = hnnpVXVrXWbGeeU;
    }

    for (int CkECeJGxcHhjLw = 1068147935; CkECeJGxcHhjLw > 0; CkECeJGxcHhjLw--) {
        NnspeGFMrzW = UkdpNJvKDA;
        hnnpVXVrXWbGeeU = hnnpVXVrXWbGeeU;
    }

    return false;
}

bool uQwEC::kZDxy(bool FnrOFWdjTPu, bool CRWqHPIozYYy, string vfLPyuc)
{
    bool eylScfcm = true;
    int GuCWtcAkpCGBHZ = -654958447;
    string crJxHnq = string("MgEvQqthdPJCCZpgFAnpWJzGAMfJLdYcXMIlxBxRAhNrapftUpZlrLWweUHNvkIqgqkIASJEMJgWPRFTAXchaawUYKBUPhjGVINsHmRYSvzMjZjJUyeBZyMPMSgADHDcBpFrMbUcMXCGkLIIWgMqzbTQCduwjCelatFJDDzUcNKISYKxMKXnLGkPTeLLKxXPQ");
    string xNKOMreqw = string("DopDmqYXxeKHsRKYzWUpuMXLjmXIFbByxlKyIDnVGvQAYstiguyaaEdhjCUmIKAvbGEELDqBkPqgJlbvJIrnmGwfHHsCFCFdhyjzNBjJQaJkrlRpWGnshNwNkMDuzeHihIIopopIHLvTRBgofiDpZRVRhfeDVEEeEIFUKhCtXpSgqhGORAQQqRrrBgoGxhBUJqfXvjMuUwChiGpMivemxPBRaOpiGYAJXffbHdeLVTIRW");
    int lJVuLHGrkySsixmA = 1664776626;
    int xllqASbnqxRP = -2111192592;
    double eYfSzfdSdCPoSFA = -399108.2275659227;
    double VMCEnPTomaFC = 731056.332867009;
    bool ASHHtzc = false;

    for (int xnZizEUiQgUKZUFX = 616756719; xnZizEUiQgUKZUFX > 0; xnZizEUiQgUKZUFX--) {
        FnrOFWdjTPu = ! ASHHtzc;
        lJVuLHGrkySsixmA *= lJVuLHGrkySsixmA;
    }

    for (int dqWTejQ = 1062647057; dqWTejQ > 0; dqWTejQ--) {
        continue;
    }

    return ASHHtzc;
}

void uQwEC::KloeaeKT(int tADKpjtZ, string sFTqypGCkfB, int CFMEJplgYDYZMWU, int PusoHaWqs)
{
    string qJciDLDIYLfQB = string("FfHRORJRogfNFYJflpHqzorUxsvsutmgbhKiUngWEsRIskYQRwkOKacFlSUnOcxgtrYtuBHivJKJwCTGbXUwlfpvbJlUMwMALkPFZOCeicboVtThAGPeTdDMxpxHOUrJJzyYjDWaiXHGqQdMVRhMAggFwjmnYGAiQaxjbWYxgTllgsZzmHFwJZdZlmNPgqaqDPjFDwCztKqKlegERPZzwlsZPUEOIBwyCxbGFwkbnLxyWvkLOkwQoJlcobvOvP");

    if (qJciDLDIYLfQB != string("FfHRORJRogfNFYJflpHqzorUxsvsutmgbhKiUngWEsRIskYQRwkOKacFlSUnOcxgtrYtuBHivJKJwCTGbXUwlfpvbJlUMwMALkPFZOCeicboVtThAGPeTdDMxpxHOUrJJzyYjDWaiXHGqQdMVRhMAggFwjmnYGAiQaxjbWYxgTllgsZzmHFwJZdZlmNPgqaqDPjFDwCztKqKlegERPZzwlsZPUEOIBwyCxbGFwkbnLxyWvkLOkwQoJlcobvOvP")) {
        for (int rCklgz = 941875389; rCklgz > 0; rCklgz--) {
            sFTqypGCkfB += qJciDLDIYLfQB;
            PusoHaWqs /= PusoHaWqs;
            CFMEJplgYDYZMWU += tADKpjtZ;
            PusoHaWqs /= CFMEJplgYDYZMWU;
            sFTqypGCkfB = qJciDLDIYLfQB;
            CFMEJplgYDYZMWU /= PusoHaWqs;
        }
    }

    if (sFTqypGCkfB <= string("FfHRORJRogfNFYJflpHqzorUxsvsutmgbhKiUngWEsRIskYQRwkOKacFlSUnOcxgtrYtuBHivJKJwCTGbXUwlfpvbJlUMwMALkPFZOCeicboVtThAGPeTdDMxpxHOUrJJzyYjDWaiXHGqQdMVRhMAggFwjmnYGAiQaxjbWYxgTllgsZzmHFwJZdZlmNPgqaqDPjFDwCztKqKlegERPZzwlsZPUEOIBwyCxbGFwkbnLxyWvkLOkwQoJlcobvOvP")) {
        for (int pfkzCEam = 1130066541; pfkzCEam > 0; pfkzCEam--) {
            qJciDLDIYLfQB += sFTqypGCkfB;
            sFTqypGCkfB += qJciDLDIYLfQB;
        }
    }
}

int uQwEC::DyNLcTsWeTH(bool UJHEhUeOg, bool cPDSOlpIiZUbPb, double LThmh)
{
    bool aFRjXbYf = false;
    bool XjjwrCvv = false;
    int ANDHLpYcsGE = -830525240;
    double OivTMxBugvnHmu = -271453.13505226444;
    int afZguxaDFRITdJ = -1351103237;
    int tEzsWgUbo = 1996408549;
    double kLEabJVSZUR = 320551.98084081005;
    string izGWWjuSH = string("WyNhNmygiZsXbURJXbkEZeKxtIGdCfoucPlAgPRKbKmGLdiXvgLKhhIBlElNATLLVTwXawYcfOtsRSFFYvMBMPzMHF");
    int aidutBWM = 711399278;

    for (int AlDzupau = 1302903273; AlDzupau > 0; AlDzupau--) {
        afZguxaDFRITdJ *= afZguxaDFRITdJ;
    }

    for (int MlQClWpzDvCd = 986088121; MlQClWpzDvCd > 0; MlQClWpzDvCd--) {
        aidutBWM *= tEzsWgUbo;
        XjjwrCvv = XjjwrCvv;
        aidutBWM -= aidutBWM;
        aidutBWM *= afZguxaDFRITdJ;
    }

    for (int nQKkqPGyLJPTc = 1572803471; nQKkqPGyLJPTc > 0; nQKkqPGyLJPTc--) {
        tEzsWgUbo -= tEzsWgUbo;
    }

    return aidutBWM;
}

int uQwEC::knvsVuJZyqt(int TMqxohuSYj, bool TjuKGDYF)
{
    bool nDdSZqNwMarbe = false;

    return TMqxohuSYj;
}

int uQwEC::UPEgwSap(bool BHHaXX, string FdcEzBIo)
{
    string kqBHMTkx = string("deuaqROGPCVyMwpdJJyMKlfFrIjVndsXUtpEQBQXloHJliIevpVaTvIOWDHpHunsKipnwCWISgHEMNpsXQhqKkWcEQkUKSCMUbIeSTNMWmdJCtijKIiEaSWMhTjhHURXSqqJlzIghWxUhBkNYuzLvrsTsJpbqCYgOjRdshSCtszkBhdabqTuGnhSfLpkJVVGIdALrBYCgMpqCRlTJypVFldNOIzuQIdyyBLPzrHPmDQ");
    int CWhBhpv = 870839724;

    for (int tLbWkuXfHzKcK = 1728265903; tLbWkuXfHzKcK > 0; tLbWkuXfHzKcK--) {
        FdcEzBIo = kqBHMTkx;
        kqBHMTkx = kqBHMTkx;
    }

    for (int VqpyFRYMyt = 472797455; VqpyFRYMyt > 0; VqpyFRYMyt--) {
        FdcEzBIo = FdcEzBIo;
    }

    if (kqBHMTkx <= string("deuaqROGPCVyMwpdJJyMKlfFrIjVndsXUtpEQBQXloHJliIevpVaTvIOWDHpHunsKipnwCWISgHEMNpsXQhqKkWcEQkUKSCMUbIeSTNMWmdJCtijKIiEaSWMhTjhHURXSqqJlzIghWxUhBkNYuzLvrsTsJpbqCYgOjRdshSCtszkBhdabqTuGnhSfLpkJVVGIdALrBYCgMpqCRlTJypVFldNOIzuQIdyyBLPzrHPmDQ")) {
        for (int MrgfIuKlFTVoXWb = 473015907; MrgfIuKlFTVoXWb > 0; MrgfIuKlFTVoXWb--) {
            kqBHMTkx = kqBHMTkx;
            kqBHMTkx = kqBHMTkx;
        }
    }

    for (int MFIukML = 751677281; MFIukML > 0; MFIukML--) {
        continue;
    }

    if (kqBHMTkx > string("deuaqROGPCVyMwpdJJyMKlfFrIjVndsXUtpEQBQXloHJliIevpVaTvIOWDHpHunsKipnwCWISgHEMNpsXQhqKkWcEQkUKSCMUbIeSTNMWmdJCtijKIiEaSWMhTjhHURXSqqJlzIghWxUhBkNYuzLvrsTsJpbqCYgOjRdshSCtszkBhdabqTuGnhSfLpkJVVGIdALrBYCgMpqCRlTJypVFldNOIzuQIdyyBLPzrHPmDQ")) {
        for (int khdplTeSMICqIXe = 636847645; khdplTeSMICqIXe > 0; khdplTeSMICqIXe--) {
            FdcEzBIo += FdcEzBIo;
            BHHaXX = BHHaXX;
            FdcEzBIo += FdcEzBIo;
            kqBHMTkx = FdcEzBIo;
        }
    }

    if (CWhBhpv < 870839724) {
        for (int dXoJgEx = 965750967; dXoJgEx > 0; dXoJgEx--) {
            FdcEzBIo = FdcEzBIo;
            CWhBhpv *= CWhBhpv;
            kqBHMTkx += FdcEzBIo;
        }
    }

    for (int bqVfhfeWil = 294198450; bqVfhfeWil > 0; bqVfhfeWil--) {
        CWhBhpv += CWhBhpv;
    }

    return CWhBhpv;
}

bool uQwEC::AHrYOleUFefBUKHU(int nrwgkWCWlrdKIno, double fFkofBx, bool WXYaLehqqAcy, bool fFmazoLxqcMKWE)
{
    int QJrMEZHTIHLkHB = 1052140337;
    string nuYTyVUTbriMF = string("bUFUzFRlVQTMCZKBxNowJcLmMHdIMYYcNwNOvozxEcaUszUZPPqyWauhRMswsyPAcuvHJZZlrwdJAxkpWcsRiKcJuAdMXNNIBovfYzqlDWTverRUhufsfDOCeBkKbskcOUXtmWbAEqqIYikBeBYIEaBLyVMIKrvZYvwJHVkVvtQwDGlccmyGkEMnxmmnLIRcmNUxonfKFKbStoCFanvBXzV");
    double QFDxrSIEe = -745082.0867583564;
    string AqbmoLW = string("MsEItGQhqgwuqcHwxqOkLoonLAUDUl");
    int rdKMFRT = 501736310;
    int YGXOgPClOKeGYBhS = 377816876;
    bool teZZbLlnIXoZWsnY = true;
    double ARuelOMq = -1014758.0062375483;

    for (int yULvPnJDr = 2078499823; yULvPnJDr > 0; yULvPnJDr--) {
        continue;
    }

    return teZZbLlnIXoZWsnY;
}

string uQwEC::WYPgjwgJhUEVd(bool dadsIUARmQ, int roDDtpbWMvUTimRs, double FSJfPC, double DgwAiLdoCYApanbf, int nzlUOrjftZYo)
{
    int DVUkcVm = -575545909;
    string JQilxzbkUik = string("etjwUrAHkyFBwAtIaNNZgyXDpvHOGqlRXqhNlvhanj");
    bool CoFkrEHemhcNEoL = true;

    for (int WdctI = 1675459560; WdctI > 0; WdctI--) {
        FSJfPC /= FSJfPC;
        FSJfPC /= FSJfPC;
        roDDtpbWMvUTimRs += DVUkcVm;
    }

    for (int stQYdUa = 1501849623; stQYdUa > 0; stQYdUa--) {
        continue;
    }

    for (int oZFcYvVfc = 344558815; oZFcYvVfc > 0; oZFcYvVfc--) {
        dadsIUARmQ = ! CoFkrEHemhcNEoL;
        JQilxzbkUik += JQilxzbkUik;
    }

    for (int MafhvWj = 1414071886; MafhvWj > 0; MafhvWj--) {
        continue;
    }

    return JQilxzbkUik;
}

string uQwEC::JMOheGEr(double xWnJuPZPCgIyv)
{
    bool mnIqD = true;

    if (mnIqD != true) {
        for (int nHakVM = 1155067573; nHakVM > 0; nHakVM--) {
            continue;
        }
    }

    for (int gnZkHuInhXMvyO = 906389936; gnZkHuInhXMvyO > 0; gnZkHuInhXMvyO--) {
        mnIqD = mnIqD;
    }

    for (int vIgRWmVJzsd = 218689739; vIgRWmVJzsd > 0; vIgRWmVJzsd--) {
        mnIqD = mnIqD;
        xWnJuPZPCgIyv *= xWnJuPZPCgIyv;
        mnIqD = ! mnIqD;
    }

    for (int zphPi = 715670060; zphPi > 0; zphPi--) {
        mnIqD = ! mnIqD;
        mnIqD = mnIqD;
        xWnJuPZPCgIyv += xWnJuPZPCgIyv;
        xWnJuPZPCgIyv -= xWnJuPZPCgIyv;
    }

    for (int pOUrBlLQGDzNSBi = 296483330; pOUrBlLQGDzNSBi > 0; pOUrBlLQGDzNSBi--) {
        continue;
    }

    for (int WuCDBRSyrp = 1699047400; WuCDBRSyrp > 0; WuCDBRSyrp--) {
        mnIqD = ! mnIqD;
    }

    return string("SJWkGVmmnhBVxKmmkgqWbUkpESdRsQqEZjidruQsmbusqPeBFkzeVQkTxxkBoFomccaWsOKfmaSIwYDkpAtNpKARsZsiRZeudWOmpYQOxYXcZzzTnQngUfqgTJIOkDbiKngewoNpCaUXgpusPhmbLuobodHRHpqQ");
}

uQwEC::uQwEC()
{
    this->FeXGGZfsGbsU(true, string("dQROPBWaVAQCzGsj"), -1746752151);
    this->QKEroGtnT(-938382.3710216921, string("JVFoSRhKJmfaMhrGZkvMJAxMnVVyMmNUlz"), 1994506147, 766212387, 232594094);
    this->MVkswR(-796152.7912443368, 653850101, string("GPInCuXebAxGgYuHdkyjfkvTKiBIyZWTenTPctFfDzUfSRVNusZKHEMteAsYauzOhUcrGDeSPzmDeRdvBkdnqLgkYBqfFNuHfHsMUjTErUSBcxUjVDYKygapOMjBKJH"), 1901087991);
    this->dWzHacegFCLczfyM(true, string("mAGupNrKRvMQpGhrQEJzcUVuMYeGEXvqlQXRlmMfzKqTwkrbJDDdnfEjfBRolKyWpgCrejSnaXIcmAMuXyPXOJKUdHHTeXCdSPYGXWdMTXsKRWdlVIgRNDuGbjqpsrEUiYnOngklQmTnMdfIFrWmmIluiUUHIIULwnUXkDJpdeHbKeZIqzayCFPdziblZGOwcAOeWBGhn"), string("KcXlZnoOQtYelAolFsZPmJUWCoouZlcvsEEAsmteCYVBfpklYGHvjzcIxnWYjRgpGdULLGQYQLYlOpt"));
    this->jWXgLuSM(string("pHIAjnVDaGKuo"), 65883188);
    this->FdXHAPUvShBVLB(string("VciPPVBhJZKRQqkmoBFZlRSmBicLvBiASkg"), -918554117);
    this->McwqmZgEcitOh(154066.25486062872, 976659.4585852844, string("AzfxXsNvqcVmmFrNOItFudIktVeHZoFQUEpACevMoxxHmYLbyhZgOhZKfGDgiWcAxjBDaDMM"), false);
    this->DEfCTqdBfjKOqFPz(1874119892, string("LJKqGIbZaFCnoPeNnvnXRYSKytvpKgiRSHxTS"), string("NXMq"));
    this->kZDxy(false, true, string("IVJKEojgsnuGCDbMutdFtXctJZDgGpfYfivHaJsUcroYxhoLsqQLhWDxEXWYbIOdGuXxPeISyliUUzvUxmnsUbhHBCpapqpMrrMlbZcyAEvZQpNDKJiFTJePDVdJgIEJDFrAAlQGrlKCUdKKyjzafdcBTLcIRuJnbugHgtypmDkUpQODMqYZByoiBhWIRMQvaiLChHtwxVZopApGTQDPkQieVAaNrwhoNzUuoQEQDeplcjMMXt"));
    this->KloeaeKT(-1424067071, string("kHturOosaYgEIaQQrafpYUVdgCrSHGtkifinBVqwUodlSRpPTRVoRVMAhVpHsInhtmtZAnlijfVWqaLjutRBIWDvkbaXVYAkocTTeBxqZoKimLMxDGAOkER"), 183857259, 120490942);
    this->DyNLcTsWeTH(true, false, -92879.16610932187);
    this->knvsVuJZyqt(-1168223347, true);
    this->UPEgwSap(true, string("afJpXALxPTjqltZuJbaxvCkQFdnmUvauejrKBzEQEbYlJpVzyYmliOQHMhEuWUFZvfmHFNsCtCamSNydebZJKtinMWMHEfOwVrekOYbgVietVcWfvjMcJooVOYMRunuhCHnGNBYmEMzSOZpEdQWVZhLoxRAndOSrCCVkzVDBbtSqpmgoPOOpnNnwFoIdQSumCHbcGyRIbtBgOCFrBbVuovbAsacnxftkDRHHnpgJGfkGBpNSVWlTWaedV"));
    this->AHrYOleUFefBUKHU(-2055446962, 107203.10486471998, false, false);
    this->WYPgjwgJhUEVd(true, -493267090, -657965.9127611625, -496112.50597411836, 1665759590);
    this->JMOheGEr(-566832.3731718896);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QJxQw
{
public:
    bool NqwLkQPgflnnUlQ;
    int QqzJObyIatFMW;
    int LUWucJK;

    QJxQw();
    bool dqByMgIFI(double UquHUvBFk, string DuVeKIkxUUtpL);
    string QAPsmWYQ(double UcGyJsf);
    int pAjtbVunCwDV();
    bool gybDdph(int CspchAmKj);
    void tcFemabyAGxMwC(bool KNiICmPSTi, string DkOSJwNyJET, double JSFIgWYUyZzUmF, bool kdzupTqAbwFbcxvJ);
    double qXtFFKJWuQeJRA(double CKopyecjZEWUMvI, int uTqndQCntfWGLXXr);
    int EDMdfAadVRGEghMT(double MGcdBZGlKPnX);
    void gxzAZhzhdcwZK();
protected:
    bool nbzxovMbV;
    double cRKZiW;
    string pMlctAKMyWmLsjp;
    double gUvrv;
    int JivBHmDKl;
    bool QmoGthsXI;

private:
    string aWjsr;
    bool zEVrwPoE;
    bool KuZpDLKpTUStADP;
    int bRkGAwwpwWlB;
    bool WToSPwGWdzcL;

    double SSPdztPdzugrw(bool XSomdVhJW);
    string wxFFitxHEYAEgCH(int EDoVJBDgRvQCloG, string KqpBdhrKuqA, double fQIpMvyZEwX, double TqNjny);
    double YKBdEpYcwwHZUuY();
    int jmvvkkalyZPHAyVw(double UhDdIydTSYguVIE);
    bool ijVjuml(string QKEauHQmHdUQgeJq, double TwEIghsmonCKVa, bool acCukBHbgCBOh, bool kSeTUSVApgqzz);
    int dVKagIWg(double zMuxoxn, bool hvCfk, string bjDvagvCDViByeE);
    bool AtffQbwVe(int pZNALzXnEbtx, double AIHdGWZc, bool PArTTTYRwfqT, double iIKoHoYkoWRKp);
};

bool QJxQw::dqByMgIFI(double UquHUvBFk, string DuVeKIkxUUtpL)
{
    double GVADGTFDq = -529461.537139537;
    bool UpQXjOcWLesKf = false;
    string EhFkEczA = string("UlxbvEUQKsTYkRZhrtXnXZtHjNBApiGqYtfrioeyhugChGEQFWJFGhNmihaEVPEXBbvssdPKBkpRigYfOKFLJCCxdiaBoscbmvFdNaxcFsXhxzZYyaErBSPSSHamgxGSTqDWAHOCyeVcCLAfMhHMFpJrZOfrMicjzToZCwHrHCJftyewTFdWnqDPwEREqbriTOQvmgjKPezPZsZoAULPoXT");
    bool CvcGFjVX = true;
    string inYClBCsumORJ = string("rZxYBJOTSKKzmRWbCulUzOYKAreijGFlYTbRAdwnqvhWNFXChXELAPKyiwXmDFuheKPVttnzQLhmuOpkKAloDXvNBSbygGVkhXcpuHkLiTEachluFnHcKVQrllgZRa");
    bool fXvado = true;
    int YUcvzbnO = 1351602860;
    double YMuErzgJlgaO = -433482.21702370193;

    if (UpQXjOcWLesKf != false) {
        for (int FOyhNF = 1162516181; FOyhNF > 0; FOyhNF--) {
            DuVeKIkxUUtpL = DuVeKIkxUUtpL;
            YMuErzgJlgaO /= YMuErzgJlgaO;
        }
    }

    for (int KLjjLgJqNxiXWFW = 1095979564; KLjjLgJqNxiXWFW > 0; KLjjLgJqNxiXWFW--) {
        inYClBCsumORJ += EhFkEczA;
        UpQXjOcWLesKf = ! CvcGFjVX;
    }

    return fXvado;
}

string QJxQw::QAPsmWYQ(double UcGyJsf)
{
    bool WxiGyd = true;
    int FeFQxk = -316885561;
    int RUsPNZnK = 49872712;
    double nSBawGPnVvDVILr = 938265.8187387477;
    double kdkQu = -833840.6918098667;
    double EeWoyABHMTGSpsXf = 143805.12055130952;

    for (int zvlcYJUiTNwH = 710689200; zvlcYJUiTNwH > 0; zvlcYJUiTNwH--) {
        nSBawGPnVvDVILr -= kdkQu;
        UcGyJsf = nSBawGPnVvDVILr;
        kdkQu /= EeWoyABHMTGSpsXf;
        EeWoyABHMTGSpsXf -= nSBawGPnVvDVILr;
    }

    if (UcGyJsf == -833840.6918098667) {
        for (int FJmQubKfvfug = 231825064; FJmQubKfvfug > 0; FJmQubKfvfug--) {
            kdkQu -= nSBawGPnVvDVILr;
            nSBawGPnVvDVILr = kdkQu;
            EeWoyABHMTGSpsXf -= kdkQu;
            nSBawGPnVvDVILr -= kdkQu;
        }
    }

    if (UcGyJsf >= -833840.6918098667) {
        for (int EwmzZl = 92824533; EwmzZl > 0; EwmzZl--) {
            EeWoyABHMTGSpsXf *= UcGyJsf;
            UcGyJsf /= nSBawGPnVvDVILr;
        }
    }

    return string("CnoGfFEejBHroexbLYmQTnVRikblicKaZTfTnvxPxYuYgTesarEIXYoXgnqbywrogkLPWJpdoZRonC");
}

int QJxQw::pAjtbVunCwDV()
{
    double iPaHrzjSPoiE = -454067.67233550054;
    bool aWSRunV = true;
    string HBxDcvJ = string("pxamwzdwOUeSmdkYiKrWjMJrMNkvPJArVZpTJLBHsLGuwGiCdqSRChSidguNdAqPQmMnjENkFcRRKwwNoBlFqFRRhZlhgqghJEIMXbKiOkzgZTExCcUEaFECFPvPZUgAKSj");
    double NZkayjiUkgMGAlO = -585556.3275105427;
    bool SUryl = false;
    int SqfHtEYeCMTYI = 351750771;
    int zfSEXnAx = -1256531467;
    string otgSpstWhw = string("OvBVWZcv");
    string AbqoqIgc = string("zuKeitUuXJaLrlSXLOUZLeCBEwiLRBMvEmqZERUeXPLsObJZgdxtziVysVxHxGkPayswiLYSRbmMBUJdhFQwZhGxwOaMsKFRAAkzEZeSsZiEWMccluPyupigunHGqtQEsUedZeYjqrugJjrJxzvRAspZNzHYIVqZBuCKobtnowgdOJEorNxXCidnrOBdFLacQOjPsIfMbhKKoMIqncj");

    if (SqfHtEYeCMTYI < -1256531467) {
        for (int nIogiSrgiZF = 677268769; nIogiSrgiZF > 0; nIogiSrgiZF--) {
            NZkayjiUkgMGAlO += NZkayjiUkgMGAlO;
            otgSpstWhw = AbqoqIgc;
        }
    }

    if (NZkayjiUkgMGAlO != -454067.67233550054) {
        for (int ilWOuMpoRcRevmbe = 895109780; ilWOuMpoRcRevmbe > 0; ilWOuMpoRcRevmbe--) {
            NZkayjiUkgMGAlO = NZkayjiUkgMGAlO;
            aWSRunV = ! aWSRunV;
            aWSRunV = aWSRunV;
        }
    }

    for (int yZUQnUzOsskE = 2092616562; yZUQnUzOsskE > 0; yZUQnUzOsskE--) {
        continue;
    }

    return zfSEXnAx;
}

bool QJxQw::gybDdph(int CspchAmKj)
{
    bool eaODWUcIXWonn = true;
    int yFiJblywM = 1200678498;

    if (yFiJblywM == -1731638329) {
        for (int dyZKXtxengrcSL = 2018007344; dyZKXtxengrcSL > 0; dyZKXtxengrcSL--) {
            CspchAmKj /= yFiJblywM;
        }
    }

    if (eaODWUcIXWonn != true) {
        for (int AioTwIRBy = 1798324770; AioTwIRBy > 0; AioTwIRBy--) {
            eaODWUcIXWonn = eaODWUcIXWonn;
            CspchAmKj = yFiJblywM;
            CspchAmKj = CspchAmKj;
            CspchAmKj *= yFiJblywM;
        }
    }

    if (CspchAmKj >= 1200678498) {
        for (int bimapQyT = 1583539701; bimapQyT > 0; bimapQyT--) {
            CspchAmKj = CspchAmKj;
        }
    }

    if (yFiJblywM <= 1200678498) {
        for (int vlmdsWwaQH = 991392706; vlmdsWwaQH > 0; vlmdsWwaQH--) {
            continue;
        }
    }

    for (int UzdyHhz = 1017438892; UzdyHhz > 0; UzdyHhz--) {
        CspchAmKj /= yFiJblywM;
    }

    if (yFiJblywM > -1731638329) {
        for (int KaCjkCiHFtt = 1369880787; KaCjkCiHFtt > 0; KaCjkCiHFtt--) {
            continue;
        }
    }

    return eaODWUcIXWonn;
}

void QJxQw::tcFemabyAGxMwC(bool KNiICmPSTi, string DkOSJwNyJET, double JSFIgWYUyZzUmF, bool kdzupTqAbwFbcxvJ)
{
    string rFGWRWBotX = string("dGeNzeEPLOJmuTBIkDgxAHffGgCgtdVrmTwakpCkceNhQwxZJKGKREgDSZFvkwXEOTdRNCnXszwRAMfGSNzErEWAtThpQTzpabbQdjdfUSOCEpJbDGlCPWrodniSexFYVLdXayTuBxh");
    int zyplwNcb = -353431683;
    int iDwITEF = -675226486;
    double dcXplqpXVECT = -274372.79093340633;
    string ERCEWkMmVPN = string("nUhNiiylLxUfUCzqCuwgXsrsxFSxsNfnUqKmdJbwznAxgismjbQEpMZgUkRtuM");
    string VCSbjoNHGYNP = string("nzSNhvYhSxjWdkOIFAXWkZAmBoHnrZlmQAwuzAIEHBVEBTEQbeWWnGgxIYUGkejTTWHigvjIZrmyhstHoOrSfASsOEhNdxmuRqfgtmMHPcBvbOgJuPcsNakzqMITtFeyPAviSXdKjHjSGPFMktuOsxgSyyllfdyQtHBcWqTkeCDDHtmLETSjpTFUVVlPmEJnijJMxjoriKfqFuRcGiM");

    for (int NzFxnnTDDpkDtBbg = 964642720; NzFxnnTDDpkDtBbg > 0; NzFxnnTDDpkDtBbg--) {
        dcXplqpXVECT += dcXplqpXVECT;
        VCSbjoNHGYNP = ERCEWkMmVPN;
        ERCEWkMmVPN += VCSbjoNHGYNP;
        ERCEWkMmVPN += rFGWRWBotX;
    }
}

double QJxQw::qXtFFKJWuQeJRA(double CKopyecjZEWUMvI, int uTqndQCntfWGLXXr)
{
    bool zgRowfblZrIKtP = false;
    bool GjvhNFAU = true;
    int IEPpAcGfdmLZr = -531165094;
    double qrtdWwIbRLwoPHR = -454573.8196258472;
    double gmeqrRdexhiNB = 935156.9588586802;
    string wFbHgt = string("NjgeEZIyGZAxnWKySElhqAbMkuxfgCnulpUSykpsBoaLuEIQWEsLunQgSUYaRmcEoWsKhfUtXOMIMtCIuqyiiHJkvBnuJxlRDjKCTfIzbSEOcyBGoF");
    int CEFmMmBegL = -1619896107;
    bool lyDjGDicMiM = true;
    int bmfGg = 180193221;

    if (lyDjGDicMiM == false) {
        for (int cWuUsFlUnHjweq = 626927863; cWuUsFlUnHjweq > 0; cWuUsFlUnHjweq--) {
            IEPpAcGfdmLZr /= IEPpAcGfdmLZr;
        }
    }

    for (int svlzKM = 105065023; svlzKM > 0; svlzKM--) {
        zgRowfblZrIKtP = ! GjvhNFAU;
    }

    if (IEPpAcGfdmLZr == -1619896107) {
        for (int UQdkJBkw = 1740828933; UQdkJBkw > 0; UQdkJBkw--) {
            CKopyecjZEWUMvI = gmeqrRdexhiNB;
        }
    }

    for (int WifnynBJ = 368350623; WifnynBJ > 0; WifnynBJ--) {
        zgRowfblZrIKtP = lyDjGDicMiM;
        wFbHgt = wFbHgt;
    }

    for (int ySMcdMS = 2088922301; ySMcdMS > 0; ySMcdMS--) {
        continue;
    }

    for (int rcjcDfrS = 1289510789; rcjcDfrS > 0; rcjcDfrS--) {
        IEPpAcGfdmLZr -= IEPpAcGfdmLZr;
        gmeqrRdexhiNB /= CKopyecjZEWUMvI;
    }

    return gmeqrRdexhiNB;
}

int QJxQw::EDMdfAadVRGEghMT(double MGcdBZGlKPnX)
{
    bool PVOOucvKTjMt = false;
    string bXarXXq = string("QZiRNWCEzHoCNvIHGtRVYTyLIOjNKHVToyuoTRXpSTkvVUpEIzRHOdLAxqEUaX");
    double vmcjPGorG = -726862.6178279986;
    double sFFYgjmFE = 537597.7290490313;
    double rUOGjA = 73758.4587618933;
    bool PcLrmAHiXSyPwGNe = true;

    if (vmcjPGorG != 537597.7290490313) {
        for (int ITCoKlNVLPwzK = 1380498760; ITCoKlNVLPwzK > 0; ITCoKlNVLPwzK--) {
            sFFYgjmFE *= vmcjPGorG;
            PcLrmAHiXSyPwGNe = ! PcLrmAHiXSyPwGNe;
            vmcjPGorG -= vmcjPGorG;
            vmcjPGorG /= sFFYgjmFE;
            sFFYgjmFE *= MGcdBZGlKPnX;
            sFFYgjmFE *= MGcdBZGlKPnX;
        }
    }

    if (sFFYgjmFE < -726862.6178279986) {
        for (int HiKTHmMmZAc = 1636897158; HiKTHmMmZAc > 0; HiKTHmMmZAc--) {
            sFFYgjmFE = MGcdBZGlKPnX;
        }
    }

    if (sFFYgjmFE > 537597.7290490313) {
        for (int nKStrwdWBhCCL = 516940200; nKStrwdWBhCCL > 0; nKStrwdWBhCCL--) {
            sFFYgjmFE = rUOGjA;
        }
    }

    for (int LbxmC = 229851049; LbxmC > 0; LbxmC--) {
        MGcdBZGlKPnX -= rUOGjA;
        MGcdBZGlKPnX *= MGcdBZGlKPnX;
        sFFYgjmFE -= rUOGjA;
        MGcdBZGlKPnX = vmcjPGorG;
        MGcdBZGlKPnX = MGcdBZGlKPnX;
    }

    return -1985656826;
}

void QJxQw::gxzAZhzhdcwZK()
{
    string CxTpxRTaitB = string("DhfSbjxbCChxRWWFqEcHZAJMKwpEOMwqfiZvLdqgGPyUFmwEZbpvTTvzvVFbgWBlNofrufSJcwyfhMwAZwZffyXqorPoCKrREThNyZcKznPd");
    double LEleh = 516384.450429293;
    int LwCdwXLWFNtevjZ = 746748209;
    int VAxFc = -710463778;
    int aWjBQePwLN = 815990543;
    double sbLID = -960451.876579174;
}

double QJxQw::SSPdztPdzugrw(bool XSomdVhJW)
{
    string xrZqynBMML = string("HmPCkPyYmZdHqyDHKdtWydAtgTBmgOjSTmucWpMuXAkkwOUvSYoVJlXbVOpNMLEtDATVCLJrcUqOskUwGLdJVgjrYcNnFUPvYWSInJZjUKKEuSFJYXblasfHkZvGhFFobofwwiCSjysTgYbupivQFOyWmZxJHManANUfwNQBLDIOHjRuAvZxTKKeoDMfGhlNGQCJTWzBwPJn");
    bool kohvp = false;
    string EwIxPQHNwThoAdK = string("XsfqyHSigKlbdivOZScdogOQTnNMrTjJBHMMqifJLRhrlKIfKaFnlxISNKvHtzFuppSFugasIREoHFBinGUEPbtWVNXKOiBXUjqXgxmPRrqjAWABQEVwLjEpNVJUiFnIqKEDz");
    bool ElaUH = true;
    double pXMOZAtm = 798165.0755250296;
    double dDGrXITdm = 725225.9639078814;
    int yaLcGkyGqmE = 476197568;

    if (dDGrXITdm == 798165.0755250296) {
        for (int PRwyXkQY = 7724187; PRwyXkQY > 0; PRwyXkQY--) {
            ElaUH = ! XSomdVhJW;
            kohvp = ! ElaUH;
            pXMOZAtm -= pXMOZAtm;
            dDGrXITdm /= pXMOZAtm;
        }
    }

    return dDGrXITdm;
}

string QJxQw::wxFFitxHEYAEgCH(int EDoVJBDgRvQCloG, string KqpBdhrKuqA, double fQIpMvyZEwX, double TqNjny)
{
    int vQnXqCXZXAHs = -1126471599;
    int Ncafj = 229884826;
    int GgJFMhtGoD = 291332747;
    bool uAPhkouJETLtDm = true;
    bool JaLxxKnTQJX = true;
    string CYpPN = string("WppBhnllPngdchVvSQJdsxoummLNiJuWAzrAevBIGEOCVPhqUagiiNMaLkMvRdHNDTkZLGCJUjuMTPXFSNM");
    string RzOIWXaAoiXTa = string("gSskmSUhgsECqNxlaUsJijCXpWaGpiJgKbHaCOZuJnPGAzndswrpnZBIsoRXSqaOQDtQQaFoFiUTQfHzupremIBJNXdpdPNgbanSCBCvgSttNLL");
    string llzWCrqmOuTMuYAd = string("VwygDPaCtMTAfJrrX");
    bool LATaSX = true;

    for (int CjBRmNceW = 1777863544; CjBRmNceW > 0; CjBRmNceW--) {
        CYpPN = llzWCrqmOuTMuYAd;
        uAPhkouJETLtDm = JaLxxKnTQJX;
    }

    for (int netCCejfCyZuY = 2082144278; netCCejfCyZuY > 0; netCCejfCyZuY--) {
        GgJFMhtGoD += Ncafj;
        GgJFMhtGoD += EDoVJBDgRvQCloG;
        llzWCrqmOuTMuYAd += CYpPN;
    }

    for (int TeEBiFusQxUHKqlb = 1033779006; TeEBiFusQxUHKqlb > 0; TeEBiFusQxUHKqlb--) {
        EDoVJBDgRvQCloG -= EDoVJBDgRvQCloG;
    }

    return llzWCrqmOuTMuYAd;
}

double QJxQw::YKBdEpYcwwHZUuY()
{
    int SIHWuRweqRQVa = 307123357;
    string yBVaqrgii = string("wKPrbRsNnXRoHSTnhxIET");
    int zaeLhSGuDnK = -876312254;

    if (zaeLhSGuDnK >= 307123357) {
        for (int qjsBPkkNb = 1804583172; qjsBPkkNb > 0; qjsBPkkNb--) {
            SIHWuRweqRQVa /= SIHWuRweqRQVa;
            SIHWuRweqRQVa = SIHWuRweqRQVa;
            yBVaqrgii = yBVaqrgii;
        }
    }

    if (SIHWuRweqRQVa == 307123357) {
        for (int asTeQx = 234446285; asTeQx > 0; asTeQx--) {
            continue;
        }
    }

    if (zaeLhSGuDnK != 307123357) {
        for (int laOEGdoHWOnCtGt = 2082721420; laOEGdoHWOnCtGt > 0; laOEGdoHWOnCtGt--) {
            continue;
        }
    }

    for (int FieUIEsS = 1812918191; FieUIEsS > 0; FieUIEsS--) {
        SIHWuRweqRQVa = zaeLhSGuDnK;
        yBVaqrgii += yBVaqrgii;
        zaeLhSGuDnK += SIHWuRweqRQVa;
    }

    return 226136.62657431426;
}

int QJxQw::jmvvkkalyZPHAyVw(double UhDdIydTSYguVIE)
{
    bool Ugilbp = true;
    double CweSiEHsBPFMNU = 463117.542541735;
    string aTFxV = string("tgqUUKZCOztyelPaPDqmDMqNdkBnimFziDiMBRHiKPoPEHWSKVEfvcZvBvwaCwABsxdwpDKcxHvlhDHTZLvGDqRoJPqovkJOuFZLbqLsWBLCLbehKsrSBoahMhaNLCImkeDOStfggvAAPYDUxNuQZJktjVHTvJiKbTAqTsIhgQQKucCcsrAsFLNIYvYHgiGZEAXPejthMyhJrNCFqngDNZjxvES");
    int VnsJIMOnCSMiiza = -1760030472;
    bool kSwITcjZokoFq = true;
    string fcEiX = string("gzridaGqkiTteSvBypuUHyXYlJWsyUzNWnPBoQYGRnXnuFyHqCUwfsrFuAsmWNJtdIpkLMhFLyaPxVYedkgYZlGCdr");
    int GabhBkzMFjQ = 179470596;

    if (GabhBkzMFjQ <= 179470596) {
        for (int ecDfBof = 1622384346; ecDfBof > 0; ecDfBof--) {
            aTFxV = fcEiX;
            GabhBkzMFjQ = GabhBkzMFjQ;
        }
    }

    if (UhDdIydTSYguVIE <= -268965.7257236007) {
        for (int mZXWgf = 218945375; mZXWgf > 0; mZXWgf--) {
            continue;
        }
    }

    for (int unEuaeWNKkYbvD = 464749700; unEuaeWNKkYbvD > 0; unEuaeWNKkYbvD--) {
        CweSiEHsBPFMNU -= CweSiEHsBPFMNU;
        VnsJIMOnCSMiiza *= GabhBkzMFjQ;
    }

    for (int sdavADJpTthfj = 716179699; sdavADJpTthfj > 0; sdavADJpTthfj--) {
        CweSiEHsBPFMNU = UhDdIydTSYguVIE;
    }

    return GabhBkzMFjQ;
}

bool QJxQw::ijVjuml(string QKEauHQmHdUQgeJq, double TwEIghsmonCKVa, bool acCukBHbgCBOh, bool kSeTUSVApgqzz)
{
    bool eGLkYnekDvlXv = false;
    double vYqBcMhWvh = -919332.2822778389;
    double CgxWIaQWUGKVxeW = 29702.885438913385;
    double NnJCQyivO = -1030430.3906491988;
    bool hWecehwkf = false;
    int iNeMEJBVDVxlxS = 1443248801;
    int AKtgyBst = -2094593642;

    if (eGLkYnekDvlXv != false) {
        for (int pfMQt = 1455748468; pfMQt > 0; pfMQt--) {
            CgxWIaQWUGKVxeW -= vYqBcMhWvh;
            NnJCQyivO = NnJCQyivO;
            AKtgyBst = AKtgyBst;
        }
    }

    for (int mdXxhmkQyagLJvB = 840900559; mdXxhmkQyagLJvB > 0; mdXxhmkQyagLJvB--) {
        continue;
    }

    for (int jKanUnZJv = 91426549; jKanUnZJv > 0; jKanUnZJv--) {
        CgxWIaQWUGKVxeW *= TwEIghsmonCKVa;
    }

    for (int zKhVCLGZfTHVcuY = 2120348734; zKhVCLGZfTHVcuY > 0; zKhVCLGZfTHVcuY--) {
        TwEIghsmonCKVa *= TwEIghsmonCKVa;
        NnJCQyivO = TwEIghsmonCKVa;
        CgxWIaQWUGKVxeW /= CgxWIaQWUGKVxeW;
        QKEauHQmHdUQgeJq += QKEauHQmHdUQgeJq;
        acCukBHbgCBOh = ! kSeTUSVApgqzz;
    }

    for (int ZQsnCmypIax = 2039107124; ZQsnCmypIax > 0; ZQsnCmypIax--) {
        CgxWIaQWUGKVxeW *= vYqBcMhWvh;
    }

    return hWecehwkf;
}

int QJxQw::dVKagIWg(double zMuxoxn, bool hvCfk, string bjDvagvCDViByeE)
{
    int EAglt = -1275339156;
    double hBugjCObSLBeBTzV = 944594.8863303933;
    string txmqVWdi = string("MPlXBGmqhhMIZANINinXaQlcePtsHwmjcWXHLQnibATsTVOfLDRWmbesoadAumxvkBTKRjxYYAKxyTkuTVtQigVNXojmfYBuXYoGAQVocshuXsqdpDKbuKNeUeCxSmtbPKTcBsyChLdpTaAlgJLSJjNTKD");
    double GYQXABCxCdO = -1003820.1052714854;
    bool EmlOPFf = true;
    string qdnxFVIxYviYmE = string("hViRQUykGNqnDjpgIoafeQKjMfskSEJgsdeyJEGCsMibusezRqFsnBiQiChPDKBkNFwTCKeHKCyJrvmJR");

    for (int GoScSvHX = 163943840; GoScSvHX > 0; GoScSvHX--) {
        txmqVWdi += qdnxFVIxYviYmE;
        qdnxFVIxYviYmE += txmqVWdi;
    }

    return EAglt;
}

bool QJxQw::AtffQbwVe(int pZNALzXnEbtx, double AIHdGWZc, bool PArTTTYRwfqT, double iIKoHoYkoWRKp)
{
    string kpDHvC = string("K");
    string lkPNQy = string("YMFKFkPGMLvSwNLlOswdUKsIOIRLbpNDFJbslHOTNemOAbTtQxKejYRAWvEZanOffRyYkhRATzxmvyWLnaPTVpRpbxugbTdIGFBvtsdPhgmGJuIGrBEKUkTcSeB");
    string VUsbcKKdqKzStE = string("TAqmJjUYHrtwqMkrlVNDovTcMUvkJfbDcltgPHHeKNViYJkVBAORRWKinWSdztRqOEOpGZFRkctvNfOsvXwBvUEMGWtTfRGgnULnCHLTTuXkfFNgQCChmUHEFViNwaZwhtwGLAJLFGlL");
    bool QUsSTZqqm = true;
    string xxCzDaPMEq = string("nokiCvQbEQhBHtekYcNYKqlRbNQvrgNecHnvAEzMLmMSARBMLpgFQRNAdNqfpjSkKKJCvMOJXPopOSUBekPtqffJqgxRrlEGrRWPAaKsrnfQqdyeQHnKTCyPowTJfnVHjMyjqrAcWStRejFfGdKvaSEvftOLIKmatXvAOFxGEHQLVEbgxEA");
    string IFDGWidRR = string("VSkjVTFenizJkikWqlfcVyPYTUDxAGYMhGCxbkUJPwKZwUdmjcGIkYIJWGGNGzerFNMpUeBcozZZuOO");

    if (xxCzDaPMEq <= string("nokiCvQbEQhBHtekYcNYKqlRbNQvrgNecHnvAEzMLmMSARBMLpgFQRNAdNqfpjSkKKJCvMOJXPopOSUBekPtqffJqgxRrlEGrRWPAaKsrnfQqdyeQHnKTCyPowTJfnVHjMyjqrAcWStRejFfGdKvaSEvftOLIKmatXvAOFxGEHQLVEbgxEA")) {
        for (int iwqGtZ = 673821179; iwqGtZ > 0; iwqGtZ--) {
            iIKoHoYkoWRKp /= iIKoHoYkoWRKp;
            lkPNQy += IFDGWidRR;
        }
    }

    if (iIKoHoYkoWRKp <= -205147.37148846049) {
        for (int bKWXo = 1079365745; bKWXo > 0; bKWXo--) {
            xxCzDaPMEq = VUsbcKKdqKzStE;
        }
    }

    for (int NKBnDjgirUPMvDV = 1762871840; NKBnDjgirUPMvDV > 0; NKBnDjgirUPMvDV--) {
        VUsbcKKdqKzStE += kpDHvC;
    }

    return QUsSTZqqm;
}

QJxQw::QJxQw()
{
    this->dqByMgIFI(-117701.91055094464, string("QqgqRdFEBSIGxradyDSYAVECfARPyZTwVUCrGUFWYmeGPEecIIxYwXYyNANuuvEhvwNUqOMeENgfhCOimKAeOUjxZTUzWJLjaYVVOVMAWfHiXdbExsDyjPXaCBl"));
    this->QAPsmWYQ(-663726.686278336);
    this->pAjtbVunCwDV();
    this->gybDdph(-1731638329);
    this->tcFemabyAGxMwC(false, string("acNefgYKqpAgBZBWvftKEsGXDYQVxiOaAFVljwfNKomySdslpZmBOkNqhhicqFHxPiEpecuhzdMTFQeKHCVAxKXbscVyKyXzKaVcYzgayznlfANaklaZDtxBboqOHyedfDUYsYlKQZlTePPuUUlCgtBCGFloooDlPXSAIDMWLSNOBQvK"), 793326.18102782, false);
    this->qXtFFKJWuQeJRA(-108445.48842313563, 1571082123);
    this->EDMdfAadVRGEghMT(-368459.23212488653);
    this->gxzAZhzhdcwZK();
    this->SSPdztPdzugrw(true);
    this->wxFFitxHEYAEgCH(100177281, string("ekPCRuBR"), 142318.7304811741, -270751.2956986963);
    this->YKBdEpYcwwHZUuY();
    this->jmvvkkalyZPHAyVw(-268965.7257236007);
    this->ijVjuml(string("gGUWDWSkDzrNyxhSASanFBmiFsOcwUAiAaoPgymrBYHAuZeCfcuITSpBiTMdXltcsaaKwGjGEVJDnAgjqiySTVYoYGPxcCryrqiCxQMioNJRzJwOKKjxxGcBIQxwyocLeKXurFLpbiOZsZvEINWNZAZxhMQgHNBYgCxlhpBXAJ"), 829213.6312698883, false, false);
    this->dVKagIWg(-294113.8999377283, true, string("iUILNJCnjkkHZEMhxrFurwhgGinjDRvsfIowiLoslleHZbhPwfEeypZcFEtcMPueNjcrfGMKdZcapGbCwlJnmpyAofplZdtuvTQvKGdOLFOfqYTbvPuYoEEflxMFxBZHcSLEBzFsTbVBXjUulTmVdYsfTcXJFvRiPVmJZjTQpTUCtmeflDFiifjmpiLTIijzAogODkjWbhiBeTyhpDmxouFnuETnqP"));
    this->AtffQbwVe(-312494547, 957478.56068803, false, -205147.37148846049);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BcKtcxplpQsSi
{
public:
    int HpZAbl;
    bool TSapRtCYUM;
    string svqPIuLtFxzeqP;
    double JUzGH;
    double QppEtrRgdvZ;

    BcKtcxplpQsSi();
    void UIcaEUfCQ(string DoNaj, double ousjgHbNy, int WvnZjwsbbZwbVcIn, int oDqVa);
    void iXymaHaVOjcI(double wqIEQpp);
    double BJJxpvVbpvyGXtZ(double QddwNzIeQk, double ioHpvmrs, string OfjzcoHJJHXs, string WzFBAwnq);
    void tvCssYopcNKCWl(double GMWEy, double cRwRDOKuLe, double aDPRaTfj, bool YMtOVAtaSgkY);
protected:
    double aGIGfbNwOt;

private:
    bool QHxzEmrMyMD;
    bool YskfRhhnqbOQ;
    bool VuBcjmKStmuUc;
    double jzCSoC;

    string omSXy();
    bool YQJGyhOQCqWyl(string ZNQqsdw);
    int JyxBoyUjiCFrJjs(double gPrScJddJpoYwELp);
    void DEBKvmPY(string RMEutFeHefzkorcT);
    void kzDztEOJP(string nFOsPRjXsGP, string AmqJp, double egZQyJK, int frVTWj);
    string vTiCHIcOCvNYdrpd(bool WqaIFLXqUZhdsgxv);
};

void BcKtcxplpQsSi::UIcaEUfCQ(string DoNaj, double ousjgHbNy, int WvnZjwsbbZwbVcIn, int oDqVa)
{
    double emmdQXYXDT = -324295.58972155175;
    double ISrWW = 898455.5165038664;
    bool dccKV = false;
    string wzPXIRNnCkiZ = string("fZAlcLPIHiZuCAXJboBfEewHucJmuqzpvQkTmJVhqdbisebjHQIoIxMKfzYIIthfYgQZhOnfPhsEXMkEYsKGuGpGTqGzzVgBMxQYTrPHOCaFYZHRiFkIVbttlHynjDhauwDOrZWfSkOkyCcXRoTrmHxxumxHKUeICHMsGfIYoIyoXqtGZBRCkjLQmrOBjcvoRLqQdOMMddGKdjSOEsRJnvmfqHsDMhdPLJkETCTXtIJMywcVAFwDwMSRulzht");
    string DlGpBFykn = string("NCmyrabieIEskzqNIFhQiksPiOVmGbiwSAUGBxjzDCaNNdODQzTupndSyqgUfMNcyQZZOxbYmDiYJmEAFEOIrTUjZViZNgtfhPCuNRrtYUlhiHkaPZgzeNsFjpbpHcJIojsxsjFkdhNhKEfkuUWTnZgNrmxwkZVVjqYnZjvBsdtqRNJVGXpUKXjtbLflVJSspVGHVUwvkFHGLgSNPziHVXbGEPMHyjvlgBFQzdwInGJyrAJcFfYAJRyUBxDWP");
    double bkjdBGwxRywaU = 384790.62963125034;
    int ZrXcvzMdIZbT = -649941492;
    double fleFfpVv = -1015083.9812140109;
    double yGBxrsKDs = -127354.02745490815;
    double BUvnCTrFEll = 858151.0871124539;

    for (int bdpNvibxhWWMUl = 1081836391; bdpNvibxhWWMUl > 0; bdpNvibxhWWMUl--) {
        continue;
    }

    if (BUvnCTrFEll > 898455.5165038664) {
        for (int pXvTDhsioW = 1527031118; pXvTDhsioW > 0; pXvTDhsioW--) {
            fleFfpVv *= yGBxrsKDs;
            fleFfpVv += yGBxrsKDs;
            ousjgHbNy -= bkjdBGwxRywaU;
        }
    }

    if (DlGpBFykn <= string("NCmyrabieIEskzqNIFhQiksPiOVmGbiwSAUGBxjzDCaNNdODQzTupndSyqgUfMNcyQZZOxbYmDiYJmEAFEOIrTUjZViZNgtfhPCuNRrtYUlhiHkaPZgzeNsFjpbpHcJIojsxsjFkdhNhKEfkuUWTnZgNrmxwkZVVjqYnZjvBsdtqRNJVGXpUKXjtbLflVJSspVGHVUwvkFHGLgSNPziHVXbGEPMHyjvlgBFQzdwInGJyrAJcFfYAJRyUBxDWP")) {
        for (int sbrBOvvMXulA = 1587194574; sbrBOvvMXulA > 0; sbrBOvvMXulA--) {
            ousjgHbNy += ousjgHbNy;
            ousjgHbNy = emmdQXYXDT;
            ISrWW -= emmdQXYXDT;
            fleFfpVv *= ISrWW;
        }
    }

    if (BUvnCTrFEll >= 898455.5165038664) {
        for (int DwFcicJZFNrb = 1326192707; DwFcicJZFNrb > 0; DwFcicJZFNrb--) {
            bkjdBGwxRywaU -= bkjdBGwxRywaU;
            bkjdBGwxRywaU -= ISrWW;
        }
    }
}

void BcKtcxplpQsSi::iXymaHaVOjcI(double wqIEQpp)
{
    int OUBQKm = -1190555960;
    string CSHznzBc = string("xbTYqzgzkxAzetIibFYfWrgLUeHaNolIPFunPvjOPckmaUI");
    bool xptEsivCH = true;
    string gLnbutgbDAWCP = string("PXsSTjMEhBn");
    bool gQEIminMu = true;
    double UQMIcgqzYcqJg = -672650.0809559972;
}

double BcKtcxplpQsSi::BJJxpvVbpvyGXtZ(double QddwNzIeQk, double ioHpvmrs, string OfjzcoHJJHXs, string WzFBAwnq)
{
    bool uAEALcbhQyiTPl = true;
    double ZsSUrrMMdbFsIj = 755194.2969776539;
    bool cFLSAXOXf = true;
    double XofQvE = 975744.5057202306;
    int oYetUubtcYOHP = -774030874;
    string bwvRjKeGoNSE = string("GxvzJMEYrpMHQGAhPHABRXMAiXBYYDgLwRVieFxCzFMdq");
    int YGjbEFlOnky = -2143736271;
    double xJjGCd = -299891.06180895685;
    string JlekfCrwOmyOK = string("eMnNkFACImXYASAfNNexwzczohLiZXyTaxkEnjFbsEjupwispmSeQvrktvzvvtBEqVtwBiWYuQeXYODSpJBfelLlivexwInlPIaIHRa");
    double fLthAjiYffHnCa = 875100.6012490434;

    if (xJjGCd == -1002289.9489746835) {
        for (int BWwfChSXpwyPUMj = 375502527; BWwfChSXpwyPUMj > 0; BWwfChSXpwyPUMj--) {
            QddwNzIeQk *= xJjGCd;
            WzFBAwnq = OfjzcoHJJHXs;
        }
    }

    for (int qgGynzqRGIF = 360490937; qgGynzqRGIF > 0; qgGynzqRGIF--) {
        XofQvE /= ioHpvmrs;
        oYetUubtcYOHP *= oYetUubtcYOHP;
    }

    if (oYetUubtcYOHP > -774030874) {
        for (int FuQCzuSONtpAHGYB = 1417994212; FuQCzuSONtpAHGYB > 0; FuQCzuSONtpAHGYB--) {
            XofQvE -= ZsSUrrMMdbFsIj;
        }
    }

    return fLthAjiYffHnCa;
}

void BcKtcxplpQsSi::tvCssYopcNKCWl(double GMWEy, double cRwRDOKuLe, double aDPRaTfj, bool YMtOVAtaSgkY)
{
    double bHQxfXG = -240689.68952812586;
    double uAtPKDFRs = 765270.6211893803;
    int UQftG = -155645459;
    bool tmVXOI = true;
    double sDpodVwqaABin = 65972.39625897403;
    double jcEQG = 155291.94249543635;
    string hMWyrKZwVB = string("gYOJfYGqFmKyYAtznMcguPCrGGdEhHWHgrOsuSSTTyOEJARRZApdCXAFVgkHhLXsRxEKtjNzXnscHejwmRwENUqKrrQhrytJYvGpysbyWFVXuHlaOQpSLQGUDxaGhCrAMFsBjquOpQWJYCiZlKhvhMxgeIKALZrLlQyPRlgtChdHEVqxciEhv");
    string bcHfVbDowtS = string("JXbsTrpiEdNguVLcWoeTHJrSfvebjygIdduCJmxgaCbrnkiqMmRKzxTcdoehPHhWsJUlSmwqxagmInuXHBycaSYRcNNuJgyNPqDJotOdRJBSHnWPCCCbAGPUyRhFSIbHUdutQXbIscnHQwvoGRsBGedfYJVbODalSFJIskZtOaLaHSveHXNWShlPxisIuSsuXMO");
    string mNwYTd = string("FVaKIjkbGxMtLYNTUpHoCZbZqhPJNkeMxHvlgSEKxcZnFpaxoYTTfTGFCMsmNRhBGXzRUZ");

    if (sDpodVwqaABin > 505166.4650385593) {
        for (int KahBnfCDMPitHS = 1547888828; KahBnfCDMPitHS > 0; KahBnfCDMPitHS--) {
            tmVXOI = ! YMtOVAtaSgkY;
            GMWEy = bHQxfXG;
            cRwRDOKuLe *= GMWEy;
        }
    }

    for (int YdfRefwqY = 176306908; YdfRefwqY > 0; YdfRefwqY--) {
        continue;
    }
}

string BcKtcxplpQsSi::omSXy()
{
    int ztAvISiFNXVAPw = 1147106918;
    double SihRHAY = -83514.86745266314;

    if (ztAvISiFNXVAPw >= 1147106918) {
        for (int LFvasd = 1957119698; LFvasd > 0; LFvasd--) {
            continue;
        }
    }

    for (int kjhKHUHMF = 1176858469; kjhKHUHMF > 0; kjhKHUHMF--) {
        ztAvISiFNXVAPw += ztAvISiFNXVAPw;
        ztAvISiFNXVAPw /= ztAvISiFNXVAPw;
    }

    if (ztAvISiFNXVAPw == 1147106918) {
        for (int ypoGEIPovUMHkYl = 737818620; ypoGEIPovUMHkYl > 0; ypoGEIPovUMHkYl--) {
            ztAvISiFNXVAPw /= ztAvISiFNXVAPw;
            ztAvISiFNXVAPw -= ztAvISiFNXVAPw;
            SihRHAY /= SihRHAY;
            ztAvISiFNXVAPw /= ztAvISiFNXVAPw;
            ztAvISiFNXVAPw += ztAvISiFNXVAPw;
            SihRHAY += SihRHAY;
            ztAvISiFNXVAPw += ztAvISiFNXVAPw;
        }
    }

    if (ztAvISiFNXVAPw >= 1147106918) {
        for (int NjxyNRSH = 854428833; NjxyNRSH > 0; NjxyNRSH--) {
            continue;
        }
    }

    for (int wELuSnbiotN = 202460281; wELuSnbiotN > 0; wELuSnbiotN--) {
        ztAvISiFNXVAPw -= ztAvISiFNXVAPw;
        SihRHAY += SihRHAY;
    }

    for (int DixIMM = 595512160; DixIMM > 0; DixIMM--) {
        SihRHAY -= SihRHAY;
        SihRHAY *= SihRHAY;
        SihRHAY /= SihRHAY;
        ztAvISiFNXVAPw = ztAvISiFNXVAPw;
    }

    return string("XBBWDpbaYVUpqRpNinmXeixyMPMIetoPoCuMEvGkKIkvbkmGrqGYtjFehNHeLgQ");
}

bool BcKtcxplpQsSi::YQJGyhOQCqWyl(string ZNQqsdw)
{
    bool sVdynT = true;
    int LyqOpJqozTKzwYH = -1190428963;
    bool RjoMkrrFNKuzsCA = false;
    bool RHbuSITvo = true;
    string BRAZuvUB = string("wRygjhaNRDnAKcNByrNVKWXIlLRNAddIPrMnCBylDRVocNXwogFqnSWuIXaBXDkeCdxiBXmsGPUrUrJfkZvtiiZS");
    bool omEBkhkrq = true;
    double EFuFNIU = 423382.11219077656;
    double zmZNuVqJEwJQgsr = 791012.8090549374;
    bool PfDoqmRQtK = false;
    double DuiqaGNkesrT = 364614.54939711804;

    if (RjoMkrrFNKuzsCA != false) {
        for (int MsKqZfyMcEd = 1222711853; MsKqZfyMcEd > 0; MsKqZfyMcEd--) {
            sVdynT = ! omEBkhkrq;
        }
    }

    if (RjoMkrrFNKuzsCA == false) {
        for (int GqcLwLh = 495039361; GqcLwLh > 0; GqcLwLh--) {
            omEBkhkrq = ! omEBkhkrq;
        }
    }

    return PfDoqmRQtK;
}

int BcKtcxplpQsSi::JyxBoyUjiCFrJjs(double gPrScJddJpoYwELp)
{
    double AEyAPzieh = -513365.3997353028;
    bool dGffGtrdl = true;
    double OGhtxVKgfHrDv = 586168.6258048258;
    int ajpEWlD = 1641349132;
    bool CrPqknLTuCOAABY = true;
    int gyBYjl = -1185998015;
    double sjGUCkb = -395676.60415908817;
    string FiTEOoUClJJbZrb = string("RhWjCpKczHxxnHssHviKLGsWMLeCMwvRdgvIvkuhsvzmkdeGvPdxCXxDoeLkGWuxBYyYdgWukQeIpqovtkdVYOfZV");
    int yQuFXcXqdgDKjOw = -774809321;
    string EUWPwWrWtICdqdr = string("RwndHLJKbcPSPdAmddlDxfCgksTaacBkPYbKOZSEAIdPaPzWWKtfjlTBUyANIEgohQIqKVDFZHedzavDwRHVvJHSMuFCHoahgXEYjYFnykXKuvHyXPLOLwohJzaHkcyeBkMSLEyarSLuFIORfXIFvwagagsGwuAPmYNWHKWPgDNSAbQHGtwnmxFUszdERlaJqdOZbYKqrTUKBTzjZtfggrPLWssVMhczfvvvtobDCUqoeKERmvjaoDl");

    for (int jxjeIGWe = 397194754; jxjeIGWe > 0; jxjeIGWe--) {
        continue;
    }

    return yQuFXcXqdgDKjOw;
}

void BcKtcxplpQsSi::DEBKvmPY(string RMEutFeHefzkorcT)
{
    bool cCCHURQD = false;
    bool aWHIEJnoFVMKptP = true;
    int JvNAV = 1054803594;
    bool UnLbOzkNufAdCDY = true;

    for (int iOxmthGXQcHsg = 2002057974; iOxmthGXQcHsg > 0; iOxmthGXQcHsg--) {
        continue;
    }

    if (aWHIEJnoFVMKptP != true) {
        for (int lJYCRYOWU = 1124244280; lJYCRYOWU > 0; lJYCRYOWU--) {
            cCCHURQD = ! aWHIEJnoFVMKptP;
            aWHIEJnoFVMKptP = cCCHURQD;
            cCCHURQD = UnLbOzkNufAdCDY;
        }
    }

    if (UnLbOzkNufAdCDY != true) {
        for (int aNPnYrFeCxLC = 40324917; aNPnYrFeCxLC > 0; aNPnYrFeCxLC--) {
            UnLbOzkNufAdCDY = ! UnLbOzkNufAdCDY;
        }
    }

    for (int WlWKh = 1769761895; WlWKh > 0; WlWKh--) {
        cCCHURQD = aWHIEJnoFVMKptP;
        JvNAV -= JvNAV;
        UnLbOzkNufAdCDY = aWHIEJnoFVMKptP;
        cCCHURQD = UnLbOzkNufAdCDY;
    }

    for (int jFnUF = 36380467; jFnUF > 0; jFnUF--) {
        aWHIEJnoFVMKptP = cCCHURQD;
        UnLbOzkNufAdCDY = ! aWHIEJnoFVMKptP;
    }

    if (aWHIEJnoFVMKptP != true) {
        for (int jLbPcqeShPhKrfL = 1510581079; jLbPcqeShPhKrfL > 0; jLbPcqeShPhKrfL--) {
            UnLbOzkNufAdCDY = ! UnLbOzkNufAdCDY;
            UnLbOzkNufAdCDY = ! aWHIEJnoFVMKptP;
        }
    }

    if (cCCHURQD != true) {
        for (int wGVtreTsCLtYYK = 358319622; wGVtreTsCLtYYK > 0; wGVtreTsCLtYYK--) {
            continue;
        }
    }
}

void BcKtcxplpQsSi::kzDztEOJP(string nFOsPRjXsGP, string AmqJp, double egZQyJK, int frVTWj)
{
    double eyxNLaBgCAGpN = 885781.2303619662;
    double WEIWXkxtBQFPap = -522060.0878408824;
    string uTEGLHHiYSmsebD = string("txtoqpvGSsDDjqPKqPeChGUoOkqMxgkUIbRVvXtCer");

    for (int PeLYKzhPVyviy = 1426090536; PeLYKzhPVyviy > 0; PeLYKzhPVyviy--) {
        continue;
    }

    if (eyxNLaBgCAGpN < -522060.0878408824) {
        for (int qYpwPHbrAhTowZQa = 1507306247; qYpwPHbrAhTowZQa > 0; qYpwPHbrAhTowZQa--) {
            continue;
        }
    }

    if (eyxNLaBgCAGpN <= -522060.0878408824) {
        for (int hgdVAD = 584998052; hgdVAD > 0; hgdVAD--) {
            AmqJp += AmqJp;
            AmqJp += AmqJp;
            nFOsPRjXsGP = uTEGLHHiYSmsebD;
            egZQyJK /= eyxNLaBgCAGpN;
            frVTWj += frVTWj;
        }
    }
}

string BcKtcxplpQsSi::vTiCHIcOCvNYdrpd(bool WqaIFLXqUZhdsgxv)
{
    double gxZJDdzKpDt = -897910.529541504;
    double pzljWEwEPS = 70793.92708469773;
    double kJBMhKAQr = 550306.1878397443;
    double myHzBXq = 362940.79515551345;
    double hTEOHUhMSl = -435940.0911186391;
    double HEOSQZxXpGF = 299773.90549036575;
    int AcJLUyGimbbmewf = 541757544;
    string cJcZlYyFZ = string("vLQhqmjFUWDedpgoCnDsdzfPMFQCtgcxGTZOkhBqhkSyowSraYeVgpnuOqnkIVqupfLgGlCJwhcMdhGDFZsvdtvsdJTeKxezZqWXcXAMVCIWGPuSjlDECbDGQwIZrykyevyZfjDltnALtVwJDiFEQxwwwnciDDaMWUfHRitTWOlHadVNfqtBATgHiBhAnuYUtZQNCaYc");
    double eRkIlmCHFnEifu = 717980.7967192847;
    double qbGcJJgSZR = -280742.1653641074;

    if (hTEOHUhMSl >= 70793.92708469773) {
        for (int PfRMgKwwsaNjdOR = 1838913205; PfRMgKwwsaNjdOR > 0; PfRMgKwwsaNjdOR--) {
            gxZJDdzKpDt -= hTEOHUhMSl;
        }
    }

    for (int OwkpxtBgg = 291404600; OwkpxtBgg > 0; OwkpxtBgg--) {
        gxZJDdzKpDt *= qbGcJJgSZR;
    }

    for (int VygTFAbrwHCrepsZ = 390896346; VygTFAbrwHCrepsZ > 0; VygTFAbrwHCrepsZ--) {
        continue;
    }

    return cJcZlYyFZ;
}

BcKtcxplpQsSi::BcKtcxplpQsSi()
{
    this->UIcaEUfCQ(string("kPjWuLhBrwpZhbezyupiJHbOCCbOkjSwHgGCTXrlILQuXgtGDMWsZJhPyTAHMQiborCtOlGlYTbuIEPDgoQeHyysrhPfwUPuclarLDdSsIpCfgtZdrypCOWExxYpVVBDCVTEdXYNKpejwIxlbumttZoY"), 493857.23423229833, 657347467, -573644641);
    this->iXymaHaVOjcI(214087.78341442507);
    this->BJJxpvVbpvyGXtZ(-1002289.9489746835, 468413.34633092827, string("rwGnunoiLPHCVaQJgnftOYApGmyFbkcALluMVwHZXHbLdVxwlrPvOIEpOsOSlNSObdTfVWWrymNzQhcKqodJyKYBEUNMipyVntaYytnxzAxWXXQpRuIJPfPRCADZIOdVEvqhXRpwBBAvmAkBSjbBWazvAqwhweoDeXqQloMOWTfwkTiRuoVSthLbLZRqkIWXSGJhcbqhHHaxvqqFtycEsdoXwzHveJwECfs"), string("FwkytkZRgqZEKWftTruWLPqWbQAzjzVIJTTbrVvPxLDFETNYbVcJcziwYwbNVadVmPzHwEAxPzLlWDjCpqBSkShqPaBCTLmBCRjxhRFutswfgUwivhBSpvAJSZqQNCNJvtIqbLBfUayLmXXllzOzTUoRynWRAHfZYWzsIKiYlqCOxcruhCblVE"));
    this->tvCssYopcNKCWl(505166.4650385593, 696521.5199399521, -1015207.7567037323, true);
    this->omSXy();
    this->YQJGyhOQCqWyl(string("VYTFiFdnLtDfwHOqMDdIcYYuAZeUMZdzhaNYcqLUZWqCIyGrPEoWbocbvheJIXcGwdJDgWlfujzRuRAqObpilIctuweTfPgJyhTFgDQXKykcCTaUeEZBeFpkyjUKAFMrYVqeUEciiYZaVWboMOfjsImaLPNYHmWdSFtIiPxOfBqeoZLZICQmYPVxysJLVlkgeegOOnlxZFdm"));
    this->JyxBoyUjiCFrJjs(617832.0553842775);
    this->DEBKvmPY(string("fIOIYIHHdtAgidxRhvbZbCIYKCUCWhnLObHNPotHosNRCyfZQdzkFKZceKPCosOXkpXVfUBSwVLKCDNnMziNdpeTSPnlmDhyosUFvtKvDVwgQwBVjDgOmojOJhdJsUUWJvNmTWduJCsMnCXZCrfjxoQGcaWNvNZhmCCwifsWHrsjslKKQdNsL"));
    this->kzDztEOJP(string("bncHaUIxZsdavWfmBbdKQDdfsilbdnPwuWu"), string("uELILkFObTROAaKNJgCpLYOVxCVjMGfxuxPslXgKgGQSFqrCXHsqiJTmITAffPJKRYLTlXwFrGbDPcnOSxwNpLjKKCYhACJSdKeYCXqmWQgbQkMoPsoSDmOWfXYWtaJzMPtAJwNjatiwYTaUhhIIuCkumgRvMSsfDbgbhIjriumUazAYqNgoZBzxzOSZpyYAeaeEYfgQbMlTzCVXPioEmAlotlVSrDZbFwFUCcnsqMNtVqzeXroRnLapyNSj"), 290728.83941964136, -1905321793);
    this->vTiCHIcOCvNYdrpd(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aDnOljpQLrmOO
{
public:
    int QaNEORQQoZQ;
    bool kJlduDItPaj;

    aDnOljpQLrmOO();
    double nNoXimrWsUyxXl(int nMBGyr, bool WNnzVPvgylwJcevC, string psdUeLkxqahxq);
    bool hdutLYryqU(double qanqYiFoaNWZvic, string KpXBOnMeJPT, string briJrjb);
    bool usQLLTAPIJN(bool HKYdFgMxpniKkoh);
    int GITrGBB(double ZTHHcpUuBqlhnK, double lmCyLwfGUMlmj);
    bool zZLfIdRQyS(double NjsbgdHl, bool fXiHwHJOGKHMOvf, int mYpSjOK, string AoKUiihYYT);
    void SAKpRnYog();
    bool zsCKWyZEm(string WDZxmSSEI, bool guDbATz);
    string YcwBlcHoAD(string rJYUgfaencL, double wbxAMNGSv, bool TSXYJkNBGqvSl);
protected:
    int WYPVazU;
    int McbBrribD;
    string UJFVsfjrn;
    string zgsGEnwMUEG;
    bool HJoslEbz;

    bool qkEXfMsZxCAapLU(int OlPDbiijsfmynQIw, bool fXyVsDpAJyyaApp, int ZhwjhdqhJgAOxOS, double JAFLi, int MirCBKVdetzIjJap);
    int KFKiEHEbCXpcbRaY(string HNsTE, int eLGVopgkS);
    double jEquaVZLDNvFisha(int WTDKAmesxa);
    void esyxQZjHsYeWtlK(string aFcldDkYpFRu, double myWdNlDeDe, double QOKZfPkZA, string mOUahEMrxRbnh);
    bool akebfPWpZPd(double goiPVQMClJ, double yWFdEbtqHdOUohDw);
    string BPxaO(int MdgyvxcQEthIwtec, string jbaWfOMvmjBpEIlw);
    bool oynLhVyyifKzaDV(bool OBMcuQqgNRVxTp, string YWINmzfHZmEAq);
    void MFGDFFMJHuO(bool yCooeXkWqHzaxs, double KCXHZmlnEC);
private:
    string rxcMUvgfuExGy;
    int aYxUpwbi;
    int KEFmMjYi;
    bool XrFAhvdbB;
    bool lXOxKnYOrVQdWtC;

    double guqDMxgrIPKvYAdy(double RCERPyVNrefYubi, string XubTDTieNYPWStC, double xnbAPcTwfbDw);
    int xuaebxOmFebwgOi(string MMFOWZNmjAgzfiv);
    bool vzJZfTA(string upzYvJYMInCXGbA, double HBEiWpcrksFbjqKC);
    double sOvmpmRHQLBtkvHy(string WruZpYCSjRtsCS, bool VBqpSdYjaCaO, string bDjGu, string rpNZePIZ);
    int olQTOVEL(string EEBLZOZbsILbAU, double OeGRWzAxFYlEtMS, double ITPrYFlmhuOGiem, double tmnWoyb);
    int CIKSYopFrosISm(bool gKqqwOujQpqoeq, bool nprPrPKKxxbFHNSe, double oCEmZuxJuub, int DoZeeSuTMqXlcL, bool kDydaquCv);
    string mfmUYG(string hKsMrTvARcNLWBi, bool ieqZbpqIxkeQnnWa, string HSUhN);
    void qEQCiSFYzti();
};

double aDnOljpQLrmOO::nNoXimrWsUyxXl(int nMBGyr, bool WNnzVPvgylwJcevC, string psdUeLkxqahxq)
{
    double pfKxddAjJY = 458916.96967996407;
    int HaZWpiVEWKJnlr = 690431199;
    int bbRTkFXTna = 4457265;
    double rrvHIlrgLSquJBb = -567246.8285850807;
    int hLcNq = 309792192;
    double DuFJYutr = -861844.8735501848;
    string BcoJwXJKRZ = string("EkVhYdQLGQmpMWUbWBZjRmPBRPKXlEZAXeRtSkjDtnTetcrKYuflzsbKIrRthONGtPkEQYyGpYdcyeJTrGbyBhdrPHWcnTLTmGEYfKivbfRkIIwCibkGMmoKSYawvFPukmCGvurMZWERjsRSEOyDW");

    for (int UqvHVIcZ = 1934002408; UqvHVIcZ > 0; UqvHVIcZ--) {
        HaZWpiVEWKJnlr /= HaZWpiVEWKJnlr;
    }

    if (bbRTkFXTna == 750603739) {
        for (int orBRVuWSETQc = 2134382183; orBRVuWSETQc > 0; orBRVuWSETQc--) {
            DuFJYutr -= DuFJYutr;
            psdUeLkxqahxq = BcoJwXJKRZ;
        }
    }

    return DuFJYutr;
}

bool aDnOljpQLrmOO::hdutLYryqU(double qanqYiFoaNWZvic, string KpXBOnMeJPT, string briJrjb)
{
    bool ozGBsACHkftY = true;
    int FTpLbCDBINZbgjS = 397087684;

    for (int HWhfvcbbqLMockUU = 575599045; HWhfvcbbqLMockUU > 0; HWhfvcbbqLMockUU--) {
        briJrjb += briJrjb;
        FTpLbCDBINZbgjS -= FTpLbCDBINZbgjS;
    }

    for (int RdLQKONEqDHBM = 697172118; RdLQKONEqDHBM > 0; RdLQKONEqDHBM--) {
        briJrjb += briJrjb;
        briJrjb += KpXBOnMeJPT;
    }

    return ozGBsACHkftY;
}

bool aDnOljpQLrmOO::usQLLTAPIJN(bool HKYdFgMxpniKkoh)
{
    bool YDHVvUnzPonUXoH = true;
    int aSqeQ = 1946074750;
    int KWxGvPOpbscIhCq = 1262076527;
    bool kyOTaSOMN = true;
    double pybtsexG = 698133.6079325363;
    double jfLoCFbBIVInVXp = 656083.6192806183;
    double GJLoqDqRpDkaWsB = -575419.9358026325;
    int AJJYkb = -8806721;
    bool atzSzHuvN = false;

    for (int RNAdyqoscsZWjV = 1934891291; RNAdyqoscsZWjV > 0; RNAdyqoscsZWjV--) {
        AJJYkb = aSqeQ;
    }

    for (int eVFiYmAoyKKxT = 1555995375; eVFiYmAoyKKxT > 0; eVFiYmAoyKKxT--) {
        aSqeQ += AJJYkb;
    }

    return atzSzHuvN;
}

int aDnOljpQLrmOO::GITrGBB(double ZTHHcpUuBqlhnK, double lmCyLwfGUMlmj)
{
    double pnuEsPb = -1042573.4353386536;
    string polvRzFSyUJ = string("POnvhPEFClMlEHebfdvspCDenjuZVDXgzcnrzGzheyryceQtqAZvrZmbAfSRTWRLNTfYJnZINlvEsjfxivvGviBEjVZOPozHbJKAefNWRyoutWTiJwqjjES");
    string SUUyHpAqNN = string("mFeVfJgXsejYqKVz");
    string gfDoQUCuPFCpMJ = string("irIYwetZElwfTveHkqyzjKkuoQjXNHpUkQOmxioDIsHEFPZkflcUbZdppGPSssuenSgwBLLRBDNKLoreIvqPiwWMYlPcLrWGxUwWfOUlQEDoasCFrlZBiuhSyoFMFpgfjTuLIDeTiswLFuOnVlfhEQXwneCJosRarOrwjeluqWaXpglCzsu");
    bool tFVrWEQMbEMsrIW = false;
    int xaMJTLyjI = 923632216;
    string uzBhJbnadZC = string("LNveiTFvBOABMzfVyIICaKoTJbFksdbVLvwysXgQLhQXVFnsxTykBnnvTLnruVnOBUZlcAkAicLgXYknrCesTuSwJcukOmtzExQidEoYSqEauArUDbOSdFUZSNbPHSrwQoRZgBoVnMepXwWRdUWVjLuReOFZCbBNuujqVIcBzKbujaumpvr");
    string nbYse = string("vhyqIRQpToZkcTRvvKMrnoEXFwIvmKtFxZLUDlEFLaqRVsnZPUeIgfvXHTikTXmZdLZJNRebxYptHjgJDdtdUZWnrackeUXGUOBfmxAAEJnSAiZVYMkgGRINravLgGiRXfNauPQWMyNayKUNIAOfebyeMvqXYNltbnPLmiGMrDOwZJdpaXsPCjOdrF");
    double lGBkEtLbqiX = 1010739.7728801639;
    int spskXWrTm = 887549211;

    if (polvRzFSyUJ == string("LNveiTFvBOABMzfVyIICaKoTJbFksdbVLvwysXgQLhQXVFnsxTykBnnvTLnruVnOBUZlcAkAicLgXYknrCesTuSwJcukOmtzExQidEoYSqEauArUDbOSdFUZSNbPHSrwQoRZgBoVnMepXwWRdUWVjLuReOFZCbBNuujqVIcBzKbujaumpvr")) {
        for (int pETAYYYqpHe = 1985997269; pETAYYYqpHe > 0; pETAYYYqpHe--) {
            pnuEsPb *= pnuEsPb;
        }
    }

    for (int QjeugWBUOAsEIe = 1788029337; QjeugWBUOAsEIe > 0; QjeugWBUOAsEIe--) {
        polvRzFSyUJ = gfDoQUCuPFCpMJ;
        pnuEsPb /= ZTHHcpUuBqlhnK;
    }

    for (int BDEnnTTDypgC = 714315913; BDEnnTTDypgC > 0; BDEnnTTDypgC--) {
        nbYse += uzBhJbnadZC;
        lGBkEtLbqiX -= lmCyLwfGUMlmj;
    }

    return spskXWrTm;
}

bool aDnOljpQLrmOO::zZLfIdRQyS(double NjsbgdHl, bool fXiHwHJOGKHMOvf, int mYpSjOK, string AoKUiihYYT)
{
    double yDHVQoV = -581677.6591019119;
    string zsGLfCZpIznnOp = string("PYSMdPrnMdxDuJzzhoBIJmGjwEKtlRtGektsJoaYkLaoHkusYkATShyvoFKVEVcBTyMjToCbKlVYRHwLcoKEMJAJgzrGOMbdyazJIMShBCiXKNcRLcJhOMQKQ");
    bool TjAHKvQCQ = false;
    string Hnihda = string("LDeeWFUGOmwsVeakGoURJdFFmYSwMJzXdCasczpGwfiIBgoiBZsaDRrfmmlOKoRwYnVibBbqtMZtiuziHHevlrWaRuYygEzHCNNwzLPepsAoCecYpqYJbavIQoErKjPKPRFyrytiLfEYJIvbKuZuAkzYVbHbBbEDvrXPTYZkjSoBLwTLrJjogIDBqflKgtiwOIh");
    int AEZjZfleCN = -529057962;
    int jFCCeXfkLwqn = 1752841476;
    int wGSRPH = 432174336;
    int WpkwwtLWu = -2035564552;

    for (int swfeDWqRkoXRq = 2011804384; swfeDWqRkoXRq > 0; swfeDWqRkoXRq--) {
        continue;
    }

    return TjAHKvQCQ;
}

void aDnOljpQLrmOO::SAKpRnYog()
{
    bool MEKfbU = true;
    int zRnXAAiTFHL = 761243781;
    double dKxoBR = 615438.7818740052;
    bool UVavKpaMT = false;
    bool nnqGSvFChU = false;

    if (UVavKpaMT == false) {
        for (int SpFCDEGwuLXs = 2057708390; SpFCDEGwuLXs > 0; SpFCDEGwuLXs--) {
            MEKfbU = ! MEKfbU;
            MEKfbU = ! nnqGSvFChU;
            zRnXAAiTFHL += zRnXAAiTFHL;
            dKxoBR = dKxoBR;
        }
    }

    for (int nymzey = 1002095264; nymzey > 0; nymzey--) {
        zRnXAAiTFHL -= zRnXAAiTFHL;
    }
}

bool aDnOljpQLrmOO::zsCKWyZEm(string WDZxmSSEI, bool guDbATz)
{
    double omCqyhGS = 829957.0961217654;
    string HhsyRt = string("ThAgxZJvkIROXmUAewAzNgwoFATBfRrGqnGASzmKBwQIzXInWlnGhbjqRRUOQwQjRPPBykDYXRGGFEnkQcUCRwJtUnwOyWxxZiGmmUmIDArezPmDqPvwwyhWEHrmwKzAUjvAcUgcX");
    string HTTPCaZiJUWfwc = string("EIMjMoqaxuOvzjoODTjMstVuCkoCDTxTBleThFfODTZPLGhlxpbalPNlFlrKPiTwBBAfwVUdHBmnZApioWPLeDjilmwxgQDGhHPgishELDBXwagCSZSxbnNYzjgqGWBzKQUmHNMMXQvtwFhMLhCHPfK");
    double JggEjWFCE = -14884.858394737126;
    bool BGuYqUASuzvuWYhj = true;

    if (WDZxmSSEI != string("iICeweAWdWkoXCoDfLmkuaSDVIhSlsMgMcaulRJxXWFFjZImSvddXnZpHsQuvOcvvsyctGYQquatpxEOYMgsFDRLAmumqgCLRlfn")) {
        for (int zUxYEIkZxu = 1653706394; zUxYEIkZxu > 0; zUxYEIkZxu--) {
            omCqyhGS += omCqyhGS;
            HhsyRt = HTTPCaZiJUWfwc;
            WDZxmSSEI += HTTPCaZiJUWfwc;
        }
    }

    return BGuYqUASuzvuWYhj;
}

string aDnOljpQLrmOO::YcwBlcHoAD(string rJYUgfaencL, double wbxAMNGSv, bool TSXYJkNBGqvSl)
{
    bool NKtrGH = true;
    double HmKNztRd = 815322.9310595257;
    string qeBTKFhECleimhNl = string("KvrrcjxcmmdpcYRgnfmnWZBGlBnBBfdbAITJPvADaokAOrzTfamWQtEDWGiEsKwclWQJuEPxzkgItksnwTrbp");
    string zBzzIsss = string("PmtyGzPUhQPLuzemnoVmMIibOBBRhFdsyXOMcsvdLfmGfiERIGRWqELZFzTBOiFuVtcHimDPeBhrZttqCbylVDqXGvAXqqtUYEleHMTAXiAeCEdUdTupVCsiIBIarUFNuFYPeGoujuyFviEnwuMdxtLTfZmDRDcoFhLMpVNhGUlIojSpSStFnwqujltuYfqDMhuUKSyKboZg");
    string EAdLCKejbJQcs = string("RujXjWRXKHATxyddduWXBWfRRQMOKOJODPjrtzzqcaixjxBmaJkiLiPevWvKAoFStRCjQahDysPPWizFtCBwYRwYckcKeKYgcixbfOHTBOpskyVUmSrMncERbLMYqpXjGKZRkEsbggGgFLLxqnfmmAhDiNnTIKPbDOhLQeKxRMXxGhINqqvSnjUAHLwlHgEhGQunk");

    for (int muZVKX = 898376343; muZVKX > 0; muZVKX--) {
        continue;
    }

    for (int pubqvYqX = 2057282717; pubqvYqX > 0; pubqvYqX--) {
        continue;
    }

    if (NKtrGH != false) {
        for (int AKlbCBnYsO = 1636613628; AKlbCBnYsO > 0; AKlbCBnYsO--) {
            TSXYJkNBGqvSl = TSXYJkNBGqvSl;
            rJYUgfaencL = zBzzIsss;
            HmKNztRd /= wbxAMNGSv;
            zBzzIsss = qeBTKFhECleimhNl;
            zBzzIsss = qeBTKFhECleimhNl;
        }
    }

    if (zBzzIsss >= string("dLVHPYNkPNpPaYmgGZcFQhtZYsUkywxDScbzbFAcIuqyTZanXbWxPOqeTHGLhVSacdsuGABVirmkdhfTjdWatVxDVKSERMPbBdnzlvJSsyBcMZqbWsonawUhxnuzSBdUvQofJddTyqrzvlxdFAEcTXbinAGCzElS")) {
        for (int iTatOjv = 202624394; iTatOjv > 0; iTatOjv--) {
            wbxAMNGSv /= wbxAMNGSv;
            HmKNztRd += wbxAMNGSv;
            EAdLCKejbJQcs += qeBTKFhECleimhNl;
            zBzzIsss += EAdLCKejbJQcs;
            qeBTKFhECleimhNl = rJYUgfaencL;
        }
    }

    return EAdLCKejbJQcs;
}

bool aDnOljpQLrmOO::qkEXfMsZxCAapLU(int OlPDbiijsfmynQIw, bool fXyVsDpAJyyaApp, int ZhwjhdqhJgAOxOS, double JAFLi, int MirCBKVdetzIjJap)
{
    bool OcQFfhCTXgXCsaxp = true;
    string GoDibrLSBGJNX = string("VSpvdRgmkiaFifhicmAvbABZYzZCvfCCccTgYjPSYtqmpAosAiSadfjuZVInMTwZmgeQsngQxvuFpqxdgEArTVVNNdhRBWmNceieYsYYFfINwqsClOLcbgTYEMuQoAUySJpdDxCMppYrSYtOEKdydyQzYeVVkdKxCQgUlqnhRcpYsv");
    bool hdXWmUUdgNjTt = false;
    bool bjRgkXUSVlIp = false;
    double OCvPedOdPJS = -148078.02088838437;

    for (int fKGZNEExjZYVDN = 1186762794; fKGZNEExjZYVDN > 0; fKGZNEExjZYVDN--) {
        OlPDbiijsfmynQIw /= OlPDbiijsfmynQIw;
        MirCBKVdetzIjJap /= OlPDbiijsfmynQIw;
    }

    for (int PjsfGUNG = 1667543788; PjsfGUNG > 0; PjsfGUNG--) {
        GoDibrLSBGJNX += GoDibrLSBGJNX;
    }

    if (OcQFfhCTXgXCsaxp == true) {
        for (int EOfupUVgDiEYSWtU = 1794803143; EOfupUVgDiEYSWtU > 0; EOfupUVgDiEYSWtU--) {
            OlPDbiijsfmynQIw /= ZhwjhdqhJgAOxOS;
        }
    }

    for (int kWpRuhKO = 1310782936; kWpRuhKO > 0; kWpRuhKO--) {
        OcQFfhCTXgXCsaxp = ! OcQFfhCTXgXCsaxp;
        MirCBKVdetzIjJap += ZhwjhdqhJgAOxOS;
        JAFLi -= JAFLi;
        OlPDbiijsfmynQIw = MirCBKVdetzIjJap;
    }

    return bjRgkXUSVlIp;
}

int aDnOljpQLrmOO::KFKiEHEbCXpcbRaY(string HNsTE, int eLGVopgkS)
{
    bool sJedr = true;
    double ZnZpOAFSvRURfA = 75193.15143134612;
    double SdpPlLliNupGyMJ = 221156.21101486948;
    string SPwsMiIdgR = string("nbLitjVAlkvbstZbrGkhHyTVIfwOMvwnUUAKAxODKbrHXINefryHhjMwdVQxsYEpsEYjhsHqwrCRFYZwEbJHXKMTTRzutCMhCmbmKQBUSWziVLexmqgWSQJqZVSveyaqWyadiqtiOFDViBaonBmgEJbnFqIvqHOeKUBnMPT");
    double kJOnwBPAgVmhNDTi = 473466.3159456369;
    int BVyLwTrtEEB = -1128926472;

    for (int gBcoxehPbDNe = 703164620; gBcoxehPbDNe > 0; gBcoxehPbDNe--) {
        ZnZpOAFSvRURfA = kJOnwBPAgVmhNDTi;
        SPwsMiIdgR += SPwsMiIdgR;
    }

    for (int OsrnCOpc = 375140810; OsrnCOpc > 0; OsrnCOpc--) {
        BVyLwTrtEEB -= eLGVopgkS;
        sJedr = sJedr;
    }

    for (int LIQFibxZ = 1837107880; LIQFibxZ > 0; LIQFibxZ--) {
        SdpPlLliNupGyMJ += SdpPlLliNupGyMJ;
        ZnZpOAFSvRURfA -= ZnZpOAFSvRURfA;
    }

    return BVyLwTrtEEB;
}

double aDnOljpQLrmOO::jEquaVZLDNvFisha(int WTDKAmesxa)
{
    string IvcEMEugPpwRJO = string("cVnwrVdzPpZmNIayZFyKSounoLNippZfQSXatWbjocqwPyVzqUtzTLAshalxkiviRwJymtaLdemJNpgYMGabeFiUAtNUTwkFgsAFjqiiwsMyUhBYptUfHaKJbfXJWCWfuMfmHmhaOwOZbZdMbgBUvscBbKeRRJbgtWJTpgfXEnkNnCCOoAMojUrSZlUvmLu");

    if (IvcEMEugPpwRJO <= string("cVnwrVdzPpZmNIayZFyKSounoLNippZfQSXatWbjocqwPyVzqUtzTLAshalxkiviRwJymtaLdemJNpgYMGabeFiUAtNUTwkFgsAFjqiiwsMyUhBYptUfHaKJbfXJWCWfuMfmHmhaOwOZbZdMbgBUvscBbKeRRJbgtWJTpgfXEnkNnCCOoAMojUrSZlUvmLu")) {
        for (int PnnNGs = 1464972518; PnnNGs > 0; PnnNGs--) {
            IvcEMEugPpwRJO = IvcEMEugPpwRJO;
            IvcEMEugPpwRJO += IvcEMEugPpwRJO;
            WTDKAmesxa += WTDKAmesxa;
            IvcEMEugPpwRJO = IvcEMEugPpwRJO;
            IvcEMEugPpwRJO += IvcEMEugPpwRJO;
            IvcEMEugPpwRJO = IvcEMEugPpwRJO;
            IvcEMEugPpwRJO = IvcEMEugPpwRJO;
            IvcEMEugPpwRJO = IvcEMEugPpwRJO;
        }
    }

    for (int CyetEKegtYEVR = 1342687171; CyetEKegtYEVR > 0; CyetEKegtYEVR--) {
        WTDKAmesxa = WTDKAmesxa;
    }

    return -131285.68089542183;
}

void aDnOljpQLrmOO::esyxQZjHsYeWtlK(string aFcldDkYpFRu, double myWdNlDeDe, double QOKZfPkZA, string mOUahEMrxRbnh)
{
    double vGrtSykcFAkV = 461533.8107364133;
    bool SCXwQvoJZ = false;
    bool ZadxuJSdsn = false;
}

bool aDnOljpQLrmOO::akebfPWpZPd(double goiPVQMClJ, double yWFdEbtqHdOUohDw)
{
    string eRGIN = string("lCgzVANCIpRfvcIsjyFQikxRKtZbaWIGACCSRYMWnkYyaBvpvzCdOqJZEEabrrUNHUuFoPnZBVfTodkVeXJamYlphQYKIlEWGPPOgYpXcvApxfxUkVZxwggnUkdrQWOmdbclIShJUJHwQXdjdKlBIkJufdhdOzDwnplLIjYwgfxHzOVszDlctAvVwJQpEdBVebjoCSdPMDOK");
    bool jIPqSOSxDUOaOkf = false;
    string GfIxCX = string("UmrOeWbIcfyeoKwtEZofNAlsyfkyAmSCJiiQWYEEGFeEbvlbYnJkeNeIvzwqnFUqYGYQFdCQrFcypktHdHJuZuICqYHxhDluDLUkupPWbBfkfJDDbFYPURBdGZGPlazTNeLZHErEIxDvCATWJqwChxixXboIgyIFvcRmNGaxvhRIeGyBLXwnVMZUWZhwLwbjHvjosmiYvQcJUrxHAjmTeadpezvlUYdNVAGzx");
    bool joWECWolrc = false;
    double lxviTpNd = -226719.8190112051;
    int OvhVug = 1295423004;

    if (jIPqSOSxDUOaOkf == false) {
        for (int FqWAMQQVR = 616416171; FqWAMQQVR > 0; FqWAMQQVR--) {
            joWECWolrc = ! jIPqSOSxDUOaOkf;
            lxviTpNd = lxviTpNd;
        }
    }

    if (jIPqSOSxDUOaOkf == false) {
        for (int plKRmbY = 563389811; plKRmbY > 0; plKRmbY--) {
            lxviTpNd -= yWFdEbtqHdOUohDw;
            goiPVQMClJ *= goiPVQMClJ;
            jIPqSOSxDUOaOkf = joWECWolrc;
        }
    }

    for (int zEtmStxIlf = 242440754; zEtmStxIlf > 0; zEtmStxIlf--) {
        jIPqSOSxDUOaOkf = ! joWECWolrc;
        lxviTpNd -= lxviTpNd;
    }

    if (yWFdEbtqHdOUohDw <= 22403.015875861805) {
        for (int KViqMjQmKs = 2061377657; KViqMjQmKs > 0; KViqMjQmKs--) {
            goiPVQMClJ = yWFdEbtqHdOUohDw;
            joWECWolrc = ! jIPqSOSxDUOaOkf;
            goiPVQMClJ *= goiPVQMClJ;
            goiPVQMClJ += yWFdEbtqHdOUohDw;
            joWECWolrc = ! joWECWolrc;
        }
    }

    for (int vFDeFrmQ = 1374904335; vFDeFrmQ > 0; vFDeFrmQ--) {
        joWECWolrc = jIPqSOSxDUOaOkf;
    }

    return joWECWolrc;
}

string aDnOljpQLrmOO::BPxaO(int MdgyvxcQEthIwtec, string jbaWfOMvmjBpEIlw)
{
    int ykGdCncDo = -1178104551;
    int HFsYAhcmsi = 1719212268;
    bool iumfbXh = true;
    string kUOPwmFFSZvRguW = string("dWvQxeRfNJPLtjHnnrZQmCLUxYGeVWReYpfceUbqBsvYdgluqtCSUqknlanDHrjbAmVMGKNWvuDdtJcNKsGOTGhYEPauCKMhHpPJbWwRqSDhRioXiTKqlcRefslgIZXbsxuTrISgsCLQTFFdYzYwfzwAArRSkQctymjXtNeQSDnDsRcTXbOPPVMmehYlSICbOTumQhGAIwVrSWkngrQGWPjumWVjubZweGQKy");
    int rdvrHPeCog = -2058658864;
    double dMrhZnoZgPaFudLK = -230243.79867486676;
    double uhPDeYfCuxMAKN = -30763.836716858987;
    string TNYrma = string("sfjMXfSkTiYhBWknAoZAcDFixQsSHXfiqZgyEQvSBIaRDgrHHoSidaTvSKFPPyJAbxJcoUCjOKXSSpkBrTSqjSkTtmCNsqnjlXGezoYtKdvbkkeS");
    double hvndesldwQi = -746191.7668087382;
    double LEKiXsDmWiGZ = 937558.5961781895;

    for (int nHhZuMedovjocXeY = 1904779582; nHhZuMedovjocXeY > 0; nHhZuMedovjocXeY--) {
        rdvrHPeCog *= ykGdCncDo;
        rdvrHPeCog += HFsYAhcmsi;
        LEKiXsDmWiGZ *= uhPDeYfCuxMAKN;
        MdgyvxcQEthIwtec = ykGdCncDo;
    }

    if (jbaWfOMvmjBpEIlw <= string("nIjzjHRMJGaUdVtAMUFbsMxmUANJkyRHpWJsRURBGlXYYLyCMGJcoqyCLeaqgUDDgkoLbziGfCOe")) {
        for (int LhFnlo = 1942489413; LhFnlo > 0; LhFnlo--) {
            LEKiXsDmWiGZ += LEKiXsDmWiGZ;
        }
    }

    return TNYrma;
}

bool aDnOljpQLrmOO::oynLhVyyifKzaDV(bool OBMcuQqgNRVxTp, string YWINmzfHZmEAq)
{
    double idEgjfVbqJqas = -691985.7512179672;
    double wkhtPRzIJaDuWE = 1022356.2410947368;

    for (int pQAqeuyteK = 2098941452; pQAqeuyteK > 0; pQAqeuyteK--) {
        idEgjfVbqJqas -= idEgjfVbqJqas;
        YWINmzfHZmEAq = YWINmzfHZmEAq;
        idEgjfVbqJqas /= idEgjfVbqJqas;
        YWINmzfHZmEAq = YWINmzfHZmEAq;
    }

    if (wkhtPRzIJaDuWE > -691985.7512179672) {
        for (int ujQIp = 1976605028; ujQIp > 0; ujQIp--) {
            continue;
        }
    }

    for (int NSNvZuUM = 455234016; NSNvZuUM > 0; NSNvZuUM--) {
        continue;
    }

    if (OBMcuQqgNRVxTp != true) {
        for (int UKCBNInaEusJs = 1250627726; UKCBNInaEusJs > 0; UKCBNInaEusJs--) {
            idEgjfVbqJqas = wkhtPRzIJaDuWE;
        }
    }

    return OBMcuQqgNRVxTp;
}

void aDnOljpQLrmOO::MFGDFFMJHuO(bool yCooeXkWqHzaxs, double KCXHZmlnEC)
{
    int PSalCEHN = 1373104061;
    int MeoHEef = 243814158;
    string OZSQpBWPr = string("oKeJnGtBbLTfZoOMUWbAKNogOAVcVkOyzxXFuRUMDqBGWwSJHZnTHNmlHcYSuRLtIyHlIjT");
    int RGdILXJI = -1126854329;
    string FiLZoAqUimPng = string("hXDepFcpgqNVERWlmPzKJGfNWRyYhHaHEoGpbeYLLTaozSRAimjAnuaNSplhbBotxPGPYeglujCrqmBVSiXWGPAMQDxTAPjcCpkgWJzjDRZehgjYnqhLRcbYzdFVdmLxQkXaghBGPNHSeexipFhMTBkfpgm");
    double KxHBtmuoXlS = 121605.19311902356;
    bool TKpEFEimonFSiop = false;
    string rchxV = string("vZTPRTEOFEbpbsirXBWOdmqIZUdDXlzewiBJigyDcHHZqaJCLSGLxTravAZakNBgnhYjJCDmwhhT");
    string wvjquemZayzJJPV = string("YunlJDINsSCGfFBRLMidUyVIEEOhxXneykzflIUNjCmZAwjfXzcDLpcKdFzKGyXYJLYfWLMBEXopBmpRdFxMtPVEGYgLdPwUEhnyOdryEQVzQRBvYSKOYXZfasdoHxgXnSlWKjalGbZrBHAoMVpxwwSpnmHHkUKeROOkushKaADJvwFFXdFLmsroDcpoRCyVVufPkhJgpNYfdYvncxBJCWfAMAXHsVtGfHjdKiKF");
    string RVHMpYO = string("NRxyBHBPnLdgPkwusaGJchZRDusskGAptmJLgJBEimiFHvpBARqmeJAhzgMEIwQzqQMkZPlzouyFKIFCfwT");

    if (OZSQpBWPr < string("hXDepFcpgqNVERWlmPzKJGfNWRyYhHaHEoGpbeYLLTaozSRAimjAnuaNSplhbBotxPGPYeglujCrqmBVSiXWGPAMQDxTAPjcCpkgWJzjDRZehgjYnqhLRcbYzdFVdmLxQkXaghBGPNHSeexipFhMTBkfpgm")) {
        for (int WdjHuQFWX = 649790354; WdjHuQFWX > 0; WdjHuQFWX--) {
            MeoHEef /= MeoHEef;
            PSalCEHN += RGdILXJI;
            rchxV = rchxV;
            FiLZoAqUimPng = OZSQpBWPr;
        }
    }
}

double aDnOljpQLrmOO::guqDMxgrIPKvYAdy(double RCERPyVNrefYubi, string XubTDTieNYPWStC, double xnbAPcTwfbDw)
{
    string tVWhSxytnqmoQSgB = string("uGQpoQYvEVVqgIYayX");
    double tboHmL = 167167.88219553418;
    bool GmbWhdngHIDt = false;
    double dXbrtUMDHcgmHy = -473511.1138509204;
    double NFwpjI = -559630.9272866198;
    int RLQAPvmOqrSSYzH = -124788537;
    string FWHdoaGgwCQGiA = string("GnHpojbZezhlUIeFTMmYSMjmnvuKItVJYHsFqXpbQphDUYWFfKGvdEypogtWFK");
    string gqlKETLl = string("XQmZTehRlsCHGwCrEaTXOorhOaxHpwbmPJobHVBKlAQYSEDhhVQcuyeBcGLutfUGnprHrVwvlyBORTBcxnvIYZbAFFsQLPpVUANGsPBSqVfMrYGDrzfTNLsZsCsxiWSCIAbPdCutkEzGPBtcbsBWMOmCtPlFHSTsPeIeemCwIrFWuOQTuKSZvTkMmFmyrJMyotIvgiMjjlcWkaAKiCvqxJYDYVqsPrFYtCbAeFHEXhYVSv");
    bool DsqsTcHiuKqNNM = false;

    for (int PLtIuyao = 1608471729; PLtIuyao > 0; PLtIuyao--) {
        tboHmL = xnbAPcTwfbDw;
    }

    for (int zNSNnoCCClD = 1821257695; zNSNnoCCClD > 0; zNSNnoCCClD--) {
        dXbrtUMDHcgmHy /= xnbAPcTwfbDw;
        RCERPyVNrefYubi += NFwpjI;
    }

    for (int spRaqh = 1122585503; spRaqh > 0; spRaqh--) {
        RCERPyVNrefYubi *= dXbrtUMDHcgmHy;
    }

    if (gqlKETLl != string("loTuqfK")) {
        for (int UBYQDwJvhm = 1084011840; UBYQDwJvhm > 0; UBYQDwJvhm--) {
            tVWhSxytnqmoQSgB = XubTDTieNYPWStC;
            gqlKETLl += XubTDTieNYPWStC;
            RLQAPvmOqrSSYzH *= RLQAPvmOqrSSYzH;
            tVWhSxytnqmoQSgB += tVWhSxytnqmoQSgB;
        }
    }

    if (XubTDTieNYPWStC > string("XQmZTehRlsCHGwCrEaTXOorhOaxHpwbmPJobHVBKlAQYSEDhhVQcuyeBcGLutfUGnprHrVwvlyBORTBcxnvIYZbAFFsQLPpVUANGsPBSqVfMrYGDrzfTNLsZsCsxiWSCIAbPdCutkEzGPBtcbsBWMOmCtPlFHSTsPeIeemCwIrFWuOQTuKSZvTkMmFmyrJMyotIvgiMjjlcWkaAKiCvqxJYDYVqsPrFYtCbAeFHEXhYVSv")) {
        for (int CBJdSqrnXK = 122005056; CBJdSqrnXK > 0; CBJdSqrnXK--) {
            RLQAPvmOqrSSYzH *= RLQAPvmOqrSSYzH;
        }
    }

    return NFwpjI;
}

int aDnOljpQLrmOO::xuaebxOmFebwgOi(string MMFOWZNmjAgzfiv)
{
    int tstAhcih = 579763399;
    bool TENcksJtQ = true;
    string ObPsbqzayXKiiTj = string("enAzDjDutmgtJfXpdZwJRCOZirvzpkLKwewlHlhzsCSmYMNTqMMjlWqVGSmcqmRvtVgYpQnqOAcDtxFFMSssEfjzSuglyRmHyANekFYGEewLthGpvPMocXa");
    int cqcjTyPwFkR = -1484778850;
    int xbcFMWThFGD = 1853262513;
    bool pGMjuyXUzNifEu = false;
    string HvKyEKTTYD = string("kQcmWJxEiVLvawSeCsQoAgEdzuGdLbeKJaFFbGOmujEYvNAHkDpXZINeuPMZarFIGRieeWMauDXNmrRXcAKKckVXITkLlFuaDyhXADFINkBdagvkFbsbQAeXgpvqhHQAam");
    int FYvazlciLJSNkn = -1504834062;

    if (cqcjTyPwFkR == -1484778850) {
        for (int ykIxpYdZqQjfEh = 1438576466; ykIxpYdZqQjfEh > 0; ykIxpYdZqQjfEh--) {
            tstAhcih -= tstAhcih;
            ObPsbqzayXKiiTj += ObPsbqzayXKiiTj;
            MMFOWZNmjAgzfiv += MMFOWZNmjAgzfiv;
            xbcFMWThFGD += FYvazlciLJSNkn;
        }
    }

    if (HvKyEKTTYD >= string("TSwDNXYOUIIQKCAHW")) {
        for (int ZFuQk = 679724185; ZFuQk > 0; ZFuQk--) {
            xbcFMWThFGD /= tstAhcih;
            MMFOWZNmjAgzfiv = HvKyEKTTYD;
            MMFOWZNmjAgzfiv += ObPsbqzayXKiiTj;
            tstAhcih = xbcFMWThFGD;
        }
    }

    for (int cquTZz = 831668012; cquTZz > 0; cquTZz--) {
        continue;
    }

    for (int FHjNEoDUk = 1180853319; FHjNEoDUk > 0; FHjNEoDUk--) {
        pGMjuyXUzNifEu = ! pGMjuyXUzNifEu;
    }

    if (HvKyEKTTYD < string("kQcmWJxEiVLvawSeCsQoAgEdzuGdLbeKJaFFbGOmujEYvNAHkDpXZINeuPMZarFIGRieeWMauDXNmrRXcAKKckVXITkLlFuaDyhXADFINkBdagvkFbsbQAeXgpvqhHQAam")) {
        for (int UoybFMRj = 839085520; UoybFMRj > 0; UoybFMRj--) {
            tstAhcih += xbcFMWThFGD;
        }
    }

    for (int bXuuMP = 1508678842; bXuuMP > 0; bXuuMP--) {
        FYvazlciLJSNkn -= cqcjTyPwFkR;
    }

    return FYvazlciLJSNkn;
}

bool aDnOljpQLrmOO::vzJZfTA(string upzYvJYMInCXGbA, double HBEiWpcrksFbjqKC)
{
    string ksMdCyRS = string("USxwOyHSroRibBbjInLtorXIagTYrgDYeHUZoUtGg");
    int jjpYebgSES = 540800518;
    string SiPTWZhbtELG = string("MVNXkYxYXkzuEnPuFQruNungvOTtaxRnRFFGzijXavEJqblbqZMsDajvHiAyfgYhEdCPQZSPSqiLDQNEjTxJRPuaXPWlhSexDNoRZkyGPRAgoawaCMFaYeAJSkcxOweXPoQAOKEeqZFfhmrIxdojrVukTTkxgkZSEhuEPAkDluhLOXSrEXXdBJxsaXDBKPtMmAEDCXvbuTvdOImXrB");
    bool LuHrIFkgNaSqmhF = false;
    double NLGFfpJqeE = 295048.167586416;
    int phytChDwrgI = -869809227;
    double XJInbVNnP = -775841.4994987886;

    if (ksMdCyRS != string("UlhZAgdqjcoyDacFiHtBcbBWsLVcElonTArZzRAwnhUNQGAkgOlJFhhbZsqbCVNiMtHuTVnMykWEEYyUixvmDngFzAZIxFmBTFkiViiykhDQApzhadNOTZMoHxxsQWeg")) {
        for (int XYTITpMUA = 746001981; XYTITpMUA > 0; XYTITpMUA--) {
            continue;
        }
    }

    for (int jCvNRnDPTFnmXDVj = 1894643349; jCvNRnDPTFnmXDVj > 0; jCvNRnDPTFnmXDVj--) {
        SiPTWZhbtELG += ksMdCyRS;
        ksMdCyRS += SiPTWZhbtELG;
        SiPTWZhbtELG += upzYvJYMInCXGbA;
        XJInbVNnP -= NLGFfpJqeE;
    }

    for (int waYdlWP = 514855041; waYdlWP > 0; waYdlWP--) {
        continue;
    }

    for (int eFgVdMB = 696870149; eFgVdMB > 0; eFgVdMB--) {
        jjpYebgSES *= jjpYebgSES;
        upzYvJYMInCXGbA = SiPTWZhbtELG;
    }

    for (int CurmrYiwVU = 150350094; CurmrYiwVU > 0; CurmrYiwVU--) {
        continue;
    }

    return LuHrIFkgNaSqmhF;
}

double aDnOljpQLrmOO::sOvmpmRHQLBtkvHy(string WruZpYCSjRtsCS, bool VBqpSdYjaCaO, string bDjGu, string rpNZePIZ)
{
    string auLsf = string("THFNfaTFtkoQvKPKygGBSQDjvbPWslneTFrtAMLeHNGlCBOovApOvgrZJPlDAhGIClddRsEeMlxRaEDlVyjgQsPuqAfocNcpNaATeAuBNpmYzlxfl");
    double SyxgMJAvjDpo = 668986.2571155827;
    string vweUBVfOzUeLcZZO = string("RVmOIdkeHZjQCLkfwxfTiAFQHeqeknUWIHLNJDZiHesYvYTBRjwIPDzfQCnfIFmxzunvNPLVxaeZEXzNEpJjFfthzHDguEgIiAyJuWyvozFlvYijipNNdbqXPOMROLcbtHnQKgOsbJlDzqJuTDKJSBWUcdyCEgfSpluLQfVYteQdPjHoENMXgHCWjkFpqyFvJGkXHtEfOs");

    for (int ZTzwvCDoFtAFOa = 1657080415; ZTzwvCDoFtAFOa > 0; ZTzwvCDoFtAFOa--) {
        WruZpYCSjRtsCS = vweUBVfOzUeLcZZO;
        auLsf = rpNZePIZ;
    }

    for (int hTdbxSZDCPqmy = 1130357589; hTdbxSZDCPqmy > 0; hTdbxSZDCPqmy--) {
        auLsf = auLsf;
        rpNZePIZ += WruZpYCSjRtsCS;
        WruZpYCSjRtsCS += bDjGu;
    }

    if (bDjGu <= string("UIBLqwuZUgPaQopHeVVupVjeImbeOcCDYTdTVgHfrAUHDJSYQTAAfklOINHKWFMmNuUbTKemvCseBeSvevofpowvrVjDpUFhzSUjIyObTgaYRZjsCRYJXnuGhPuQncTUZIRjCZdiiRPUpAfJeKrNvgReNcBylNlmGZNCbucjSqxmyESQhFZretAjdhDdEmVaPBBsnofXaKj")) {
        for (int hKAIEsuGsGVqD = 283069200; hKAIEsuGsGVqD > 0; hKAIEsuGsGVqD--) {
            continue;
        }
    }

    if (WruZpYCSjRtsCS != string("RVmOIdkeHZjQCLkfwxfTiAFQHeqeknUWIHLNJDZiHesYvYTBRjwIPDzfQCnfIFmxzunvNPLVxaeZEXzNEpJjFfthzHDguEgIiAyJuWyvozFlvYijipNNdbqXPOMROLcbtHnQKgOsbJlDzqJuTDKJSBWUcdyCEgfSpluLQfVYteQdPjHoENMXgHCWjkFpqyFvJGkXHtEfOs")) {
        for (int HpYRDsXiOUz = 1130165567; HpYRDsXiOUz > 0; HpYRDsXiOUz--) {
            VBqpSdYjaCaO = VBqpSdYjaCaO;
            auLsf += bDjGu;
        }
    }

    if (rpNZePIZ > string("UIBLqwuZUgPaQopHeVVupVjeImbeOcCDYTdTVgHfrAUHDJSYQTAAfklOINHKWFMmNuUbTKemvCseBeSvevofpowvrVjDpUFhzSUjIyObTgaYRZjsCRYJXnuGhPuQncTUZIRjCZdiiRPUpAfJeKrNvgReNcBylNlmGZNCbucjSqxmyESQhFZretAjdhDdEmVaPBBsnofXaKj")) {
        for (int RocyXFJYwiOao = 1576314704; RocyXFJYwiOao > 0; RocyXFJYwiOao--) {
            WruZpYCSjRtsCS = WruZpYCSjRtsCS;
            vweUBVfOzUeLcZZO += bDjGu;
            SyxgMJAvjDpo /= SyxgMJAvjDpo;
        }
    }

    for (int aWWYefWSedxamEy = 23746412; aWWYefWSedxamEy > 0; aWWYefWSedxamEy--) {
        rpNZePIZ += bDjGu;
        rpNZePIZ += WruZpYCSjRtsCS;
        vweUBVfOzUeLcZZO += vweUBVfOzUeLcZZO;
        VBqpSdYjaCaO = VBqpSdYjaCaO;
        bDjGu = rpNZePIZ;
    }

    if (rpNZePIZ > string("UIBLqwuZUgPaQopHeVVupVjeImbeOcCDYTdTVgHfrAUHDJSYQTAAfklOINHKWFMmNuUbTKemvCseBeSvevofpowvrVjDpUFhzSUjIyObTgaYRZjsCRYJXnuGhPuQncTUZIRjCZdiiRPUpAfJeKrNvgReNcBylNlmGZNCbucjSqxmyESQhFZretAjdhDdEmVaPBBsnofXaKj")) {
        for (int iESVvuVFmrqfui = 578488817; iESVvuVFmrqfui > 0; iESVvuVFmrqfui--) {
            bDjGu += bDjGu;
            WruZpYCSjRtsCS += rpNZePIZ;
            rpNZePIZ = WruZpYCSjRtsCS;
            rpNZePIZ += WruZpYCSjRtsCS;
            vweUBVfOzUeLcZZO += rpNZePIZ;
        }
    }

    return SyxgMJAvjDpo;
}

int aDnOljpQLrmOO::olQTOVEL(string EEBLZOZbsILbAU, double OeGRWzAxFYlEtMS, double ITPrYFlmhuOGiem, double tmnWoyb)
{
    int yAfyEiLIcUbqIcsK = 1188339892;
    int DRwWqs = -2046642006;
    double rvyRxl = -160678.82182936493;
    string pywmsHQeS = string("hkplbgMpCpAqdOXIptkfdhvWkcmzRgSmlkfxvkuEiHuWhvtlqiWJWZAHzPrKZvTKbeWOmPjCGssmmRpQSfIkBGdwraXzYZLlHUZQKpeLMU");
    int rSEWgUrbZP = 206025382;
    string DMLqPYUJh = string("tlZfQsxaOMWRZnQCwLCSLRjlxVorXGRdAcCUKzWNpWoICqmLOoYybBjZXEKODSizuSjTIpTRNyajuvZOFYldBAmjeVfkUhHvNdPEukVRECLYDphsIFLGlNAcHrlabfafOdHwwYyEZHyErKgfZapBoQrUnJVwMKgDWVVIZBQuuNCBXqHJZOxqKMVIFWJJapzTAsuobFJopBtQXPOGxWTOebxedMgn");

    for (int nGeNkleDLNvm = 542255456; nGeNkleDLNvm > 0; nGeNkleDLNvm--) {
        DMLqPYUJh += DMLqPYUJh;
        EEBLZOZbsILbAU += DMLqPYUJh;
        ITPrYFlmhuOGiem = tmnWoyb;
    }

    if (rvyRxl > 207966.37706190246) {
        for (int QCpZM = 325842300; QCpZM > 0; QCpZM--) {
            DMLqPYUJh = pywmsHQeS;
        }
    }

    for (int VcqDXrm = 756001567; VcqDXrm > 0; VcqDXrm--) {
        pywmsHQeS = pywmsHQeS;
        rvyRxl /= ITPrYFlmhuOGiem;
        rSEWgUrbZP -= rSEWgUrbZP;
        EEBLZOZbsILbAU += pywmsHQeS;
    }

    for (int WXwtmMO = 1821671716; WXwtmMO > 0; WXwtmMO--) {
        tmnWoyb -= ITPrYFlmhuOGiem;
        tmnWoyb = ITPrYFlmhuOGiem;
        rSEWgUrbZP -= rSEWgUrbZP;
    }

    for (int ggqyvaBioOyLYl = 1303840585; ggqyvaBioOyLYl > 0; ggqyvaBioOyLYl--) {
        continue;
    }

    if (rvyRxl >= 207966.37706190246) {
        for (int GUGqYb = 1953090927; GUGqYb > 0; GUGqYb--) {
            continue;
        }
    }

    if (DMLqPYUJh != string("tlZfQsxaOMWRZnQCwLCSLRjlxVorXGRdAcCUKzWNpWoICqmLOoYybBjZXEKODSizuSjTIpTRNyajuvZOFYldBAmjeVfkUhHvNdPEukVRECLYDphsIFLGlNAcHrlabfafOdHwwYyEZHyErKgfZapBoQrUnJVwMKgDWVVIZBQuuNCBXqHJZOxqKMVIFWJJapzTAsuobFJopBtQXPOGxWTOebxedMgn")) {
        for (int QIuMADoXD = 51298525; QIuMADoXD > 0; QIuMADoXD--) {
            ITPrYFlmhuOGiem += OeGRWzAxFYlEtMS;
            rvyRxl -= OeGRWzAxFYlEtMS;
        }
    }

    return rSEWgUrbZP;
}

int aDnOljpQLrmOO::CIKSYopFrosISm(bool gKqqwOujQpqoeq, bool nprPrPKKxxbFHNSe, double oCEmZuxJuub, int DoZeeSuTMqXlcL, bool kDydaquCv)
{
    int Sipty = 1925447989;

    for (int SNmDzSgQWwSUh = 1168638122; SNmDzSgQWwSUh > 0; SNmDzSgQWwSUh--) {
        kDydaquCv = ! nprPrPKKxxbFHNSe;
    }

    for (int LsvpmH = 2022444293; LsvpmH > 0; LsvpmH--) {
        Sipty -= DoZeeSuTMqXlcL;
        gKqqwOujQpqoeq = ! kDydaquCv;
    }

    if (oCEmZuxJuub == -118822.72022539783) {
        for (int UFLvYLQywqdvBHt = 869540372; UFLvYLQywqdvBHt > 0; UFLvYLQywqdvBHt--) {
            gKqqwOujQpqoeq = gKqqwOujQpqoeq;
        }
    }

    for (int WbEBTvookssGDZuC = 1392734704; WbEBTvookssGDZuC > 0; WbEBTvookssGDZuC--) {
        continue;
    }

    for (int ZkimPgheayNVsOr = 93811580; ZkimPgheayNVsOr > 0; ZkimPgheayNVsOr--) {
        gKqqwOujQpqoeq = gKqqwOujQpqoeq;
    }

    if (DoZeeSuTMqXlcL <= 681097600) {
        for (int YxbKLM = 369526196; YxbKLM > 0; YxbKLM--) {
            nprPrPKKxxbFHNSe = nprPrPKKxxbFHNSe;
            DoZeeSuTMqXlcL = DoZeeSuTMqXlcL;
            Sipty += DoZeeSuTMqXlcL;
            kDydaquCv = nprPrPKKxxbFHNSe;
        }
    }

    if (kDydaquCv == false) {
        for (int pKjPBw = 386702220; pKjPBw > 0; pKjPBw--) {
            continue;
        }
    }

    return Sipty;
}

string aDnOljpQLrmOO::mfmUYG(string hKsMrTvARcNLWBi, bool ieqZbpqIxkeQnnWa, string HSUhN)
{
    bool QPCkOSNszOyKiRV = false;
    string fBrBsKhOfNFds = string("ASDVKmmTjyNkvgbQJnVzgWrDoBVAMHKkKOhfKFLMrPEzWsrNKQfixJeKbmhfBNPFMwbNvbJRfslHvsFwWRajSodLFymPugipViciJsFfwXmtdxnFfRUPeRbNUBOiTHZbrQRfskgWXSDavRwlGeEWtYPFngKxxlVYNmrlcxRZlkwVrgaGyGDQxnNjgpYLtEMQNHhreTJNZxRuDELmPmmgnlQRxdqshyNnslPORkKCqYUdRkAZzLGLuL");
    int gVzNvRSyLCheP = -1406607976;
    int tfvLRSHwACF = -1703553563;
    bool BdYTDdQj = true;

    if (fBrBsKhOfNFds < string("jJLmpmZqgqZnHgeiXfyGwMHnsaRNEAMlbfgUofYwZJvBDvYbCBudMlOuVuMNkBFSAIoFDEqJxIHZpiQXIwCXlUwRaquPMZmCmFRNorlHXlsuxRorcrFppnybNMdRlIuZrFJLxEvqsKeyJrgixFZZh")) {
        for (int FQyUWDq = 1513184205; FQyUWDq > 0; FQyUWDq--) {
            QPCkOSNszOyKiRV = ieqZbpqIxkeQnnWa;
            tfvLRSHwACF *= gVzNvRSyLCheP;
            QPCkOSNszOyKiRV = ! QPCkOSNszOyKiRV;
        }
    }

    for (int mBYKRuqc = 291819966; mBYKRuqc > 0; mBYKRuqc--) {
        QPCkOSNszOyKiRV = BdYTDdQj;
        tfvLRSHwACF /= tfvLRSHwACF;
    }

    for (int qhsPaiZdY = 1555908109; qhsPaiZdY > 0; qhsPaiZdY--) {
        hKsMrTvARcNLWBi = HSUhN;
        fBrBsKhOfNFds += fBrBsKhOfNFds;
        ieqZbpqIxkeQnnWa = ! ieqZbpqIxkeQnnWa;
        fBrBsKhOfNFds += HSUhN;
    }

    if (hKsMrTvARcNLWBi >= string("aHnhamrTSHAtxwxYQfsLZUoRMSCHBviuGoPmPuoRxzrhJKnUWfMrBglMCXKgFonKDoVzGvCouiVvbCBKrLWcvUKSftEzmxeAreTdQXFfrNhICGAtwcmBGeprd")) {
        for (int QcrjxrHCDZSjjnE = 286634239; QcrjxrHCDZSjjnE > 0; QcrjxrHCDZSjjnE--) {
            QPCkOSNszOyKiRV = ieqZbpqIxkeQnnWa;
        }
    }

    return fBrBsKhOfNFds;
}

void aDnOljpQLrmOO::qEQCiSFYzti()
{
    string bkDxGD = string("sJspfyFbtjuUjgZBqYrBTVNLjrRbieuUwTQOnmsCCgXShdOeJnvYHQyvfrnoivwTdTBrqJhumXaFMvSswiSrTttsbrnOHZvjqyRRqRjOgiQBXSFDZdYQFovkMDqDQbCzmjuxflBlwhyiTqvzSBCbSYbvxrGPctfOYKjMkpATJRqdMjhEfQrRxatDzZMMpToTpPNArkmqdCCqjIkZKBXxPlbLWuYBvmgZOHDbpPjulldyfSOhM");
    string OPcvbEgarfCWYm = string("cXRAcuuXlYthbeIMjMHbQCadkiGuLljhSAlfEeRtBYFFysywAAHBKBVHiV");
    int wgQBdNTIxCOyxff = -1700988873;
    double eGXonDVmHhC = -595843.6810802065;
    bool PpsosLIAMtahNvJ = true;
    double MZUHbXm = 695807.4149362727;

    for (int IjvfInihBKFSbt = 1700909488; IjvfInihBKFSbt > 0; IjvfInihBKFSbt--) {
        continue;
    }
}

aDnOljpQLrmOO::aDnOljpQLrmOO()
{
    this->nNoXimrWsUyxXl(750603739, false, string("jaKmgADgGYkhggDhKEKsAGXZFyDlgMngxsgLFzJnfyUOSGzPcIifciOlYacdJfCxAFtZYMGTsHEBVIqKlsSSDiYUoxNenzBgatUJcQtFeHYUaJVFpiNDclpMiWWquYKKHASACziVGPIIRxNaAMIIUMhSXwjxicHeYYIYkKxLecYgvWzzGGRSlYlyfPGDqfybqDjikhjXDHiXQcnMlHskHHCks"));
    this->hdutLYryqU(-704160.0924123137, string("ubdBynTXUibvzfBKDxadVkRPMDVIfyjgmboTolQAJnOcwZHCjsBekmCjHMcDqhTYJfZlcROBypMtPYgFJQkrCPAIggJcRHgJuduycJGyYmshKkHObKgHAShSlkdjyKGmIRUzQZsXDLoCXRAtQUTMOrWbYjayQzFAtCCbPUdOzoAHAkzgvvmWRnkhAj"), string("nWBFRCayaSFVYkOhipQmyEopmXhRaxjvPjhlJYonMAvVqLNwAnxpACxlGVmtdJpwQRaexhAAKgpwbmQQOjZWXSixnRvAuocimMzUsYPTxCbbaeToydqIlRqXfYOGNzMkejfqxNNPVVwtzJUupHEXqEccctFbttKewGMo"));
    this->usQLLTAPIJN(true);
    this->GITrGBB(-806499.84137185, -561785.6990434092);
    this->zZLfIdRQyS(126585.73896881046, false, -461898781, string("tERvQDixWtkdbglvNNuhbGqCtHuBKnSntMzZKhSSFevNvDHtqPtWxxNxTWqeSjQJpkqqIVYfvFKdXSopIJOnUFGAqonEFmWVPVHBgDncjoRwjLCmFPUSOVbOncRLgCjmSDmBByXViqOudNQblQhWHrPbgeIEZZmaEKhIZBMrDCFKmkvRAmxwdaJCfIANvAvHincjRKJmETLhzopEMdCcCvrUAykwrSrrePaVqfbjGIN"));
    this->SAKpRnYog();
    this->zsCKWyZEm(string("iICeweAWdWkoXCoDfLmkuaSDVIhSlsMgMcaulRJxXWFFjZImSvddXnZpHsQuvOcvvsyctGYQquatpxEOYMgsFDRLAmumqgCLRlfn"), false);
    this->YcwBlcHoAD(string("dLVHPYNkPNpPaYmgGZcFQhtZYsUkywxDScbzbFAcIuqyTZanXbWxPOqeTHGLhVSacdsuGABVirmkdhfTjdWatVxDVKSERMPbBdnzlvJSsyBcMZqbWsonawUhxnuzSBdUvQofJddTyqrzvlxdFAEcTXbinAGCzElS"), 6225.500633099208, false);
    this->qkEXfMsZxCAapLU(1040077836, true, -2015603817, -251788.78211612243, 887292273);
    this->KFKiEHEbCXpcbRaY(string("WXoddGsDOElDOoOMOyivNdnTiMFIKzyyPSWVMwiyOFmJwHtyoIuMjXtdMCXBBbVADtwQTkeUwRBaZoHPffkHFOTtBzDOljiYjlTzkBAkvXOIgcvMMWfoRzvbaCLqiIXzUAyiZmEIXNWedbJzFVnUiTXJMEgtopBCsHLjctunrCZgdjvrTd"), 66038066);
    this->jEquaVZLDNvFisha(-1003228567);
    this->esyxQZjHsYeWtlK(string("wTJtmhqzhhpmuryCHvOsAlbKUHjxEQbYAsRPUYAydHhIUwidBXlEeHHGMKMRIvtTPCwIqOKTTeRViJ"), -728221.0308224373, -941586.5648166521, string("brTdrdolniJEEyDgQPexEnfVRatQDZqqitjZnjUDLoKjMMfgjRfVkQmlfewDUWowBxCibCFXftaNsvht"));
    this->akebfPWpZPd(406829.1137040354, 22403.015875861805);
    this->BPxaO(-303135694, string("nIjzjHRMJGaUdVtAMUFbsMxmUANJkyRHpWJsRURBGlXYYLyCMGJcoqyCLeaqgUDDgkoLbziGfCOe"));
    this->oynLhVyyifKzaDV(true, string("RVggyVqzyVtAPLtTEutcbiDflAjpMFLAVbbdMAIueHakYphlyAjkHrmVyYawPedOrwfwRRsvleXepSauRPasDxyMmhuZUMaTOfUCNkPtkpXFJshOcyyPoxfPlpSehmBEWwsgSzMUSRVPUyMFutOrTKTWqPEHkbUYijFePnYtRKaquUrlxOxAziLAgJzRXRUFKXfiUBGnaw"));
    this->MFGDFFMJHuO(true, -299807.05861896236);
    this->guqDMxgrIPKvYAdy(-405088.0188786171, string("loTuqfK"), 782627.0703795116);
    this->xuaebxOmFebwgOi(string("TSwDNXYOUIIQKCAHW"));
    this->vzJZfTA(string("UlhZAgdqjcoyDacFiHtBcbBWsLVcElonTArZzRAwnhUNQGAkgOlJFhhbZsqbCVNiMtHuTVnMykWEEYyUixvmDngFzAZIxFmBTFkiViiykhDQApzhadNOTZMoHxxsQWeg"), 838053.2266980209);
    this->sOvmpmRHQLBtkvHy(string("UIBLqwuZUgPaQopHeVVupVjeImbeOcCDYTdTVgHfrAUHDJSYQTAAfklOINHKWFMmNuUbTKemvCseBeSvevofpowvrVjDpUFhzSUjIyObTgaYRZjsCRYJXnuGhPuQncTUZIRjCZdiiRPUpAfJeKrNvgReNcBylNlmGZNCbucjSqxmyESQhFZretAjdhDdEmVaPBBsnofXaKj"), false, string("rFVqNjMzodACznwuyoSVaeoZrLlATXSjrJjBRgTkdUswMnOrkqLPSQqlSgEtGJWQhLWbLhyTctPfVftNKvvwZEvqdVkumbVUuSUMExVqwNabMrHSLYrAKrFVGutaYcqJuYJDELMunVPbSuoAKoCiiKORGXWLQmNYsEYVJyDEnekjmvqQlxDHmgdiOWmjGiptgVJRVYljBdUaEyqYvmrgLzCbzOVYwCsGaycJPJ"), string("BTmAVArSNjxdJOsQuIUTKHMFXvPnoCuDoJBPCjjOfPKGfpJxktKPYVzvaQFHychcapiXIDZobKzYKRxIPXIDrANOXKflGFliSarROGmbhzVyXInpnLQXbZNHpeVAKFNmeEtRmZZEHRVoyIsCYRisMFrpqJjpSfZwrDKuoMYMjQNPNNIFEBCkSiXiPPNTjOdVKAKcWRGgmrtQnLmDhaYIfxxSSnWbmWe"));
    this->olQTOVEL(string("sXSiSBMYVeEocBsiNOCSSComzwYjSAqbTkDEEPSIqRHlOjfQkQRrdDznsApIQmplIdTAzwUbikCQBuoyhxGCjfikJvBMwJWszVjtGpMLhZwpKdWcivXusBcAyWUAYdDnUoxgYzfNpVvtfOiJLLIUYZahFDzrIqkxvtKCpdGmuhjN"), 207966.37706190246, 443015.03023287887, -382170.53389605327);
    this->CIKSYopFrosISm(false, false, -118822.72022539783, 681097600, false);
    this->mfmUYG(string("jJLmpmZqgqZnHgeiXfyGwMHnsaRNEAMlbfgUofYwZJvBDvYbCBudMlOuVuMNkBFSAIoFDEqJxIHZpiQXIwCXlUwRaquPMZmCmFRNorlHXlsuxRorcrFppnybNMdRlIuZrFJLxEvqsKeyJrgixFZZh"), false, string("aHnhamrTSHAtxwxYQfsLZUoRMSCHBviuGoPmPuoRxzrhJKnUWfMrBglMCXKgFonKDoVzGvCouiVvbCBKrLWcvUKSftEzmxeAreTdQXFfrNhICGAtwcmBGeprd"));
    this->qEQCiSFYzti();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JjGofmTyHhIwNk
{
public:
    string cEwJxttaJPVRW;
    double wrInlkphxAxDY;

    JjGofmTyHhIwNk();
    bool yxGEgiRfajvgcQSO(string smcObXPqcZLr, string CMPDfvAitTm, int eerhyQcju, int XzljtTp);
    bool YMfphmUQ(bool jTckHZBFEa);
    int DkVMfbKh(string wyjmNqaNynBGmS);
    double CHpqX(int vLpZJgacyBO, double jGqILPFNpIs, string uDdMHGoXyKmgCBin);
    double dSfSHiTy(int CgZrYmytqWtbd, double IHsExoWgbir, string eBvsLDkcIcdiMnxx, bool zOTCzs);
    string hYKyuFAfxJbPIjcT(bool uPSMTscFcIcx, double RSZHGHUBaUjcO, bool CLNBK, int KkTwaF, int nPyNk);
    bool liVdnlJpZPBmbL(int cXxxRLcV, bool ryAVewRed);
    int oNMnXEnryKXOEctC(int rDaLeZuefLKP);
protected:
    double jLkQTiKGw;

    string BTJiTwrkdvWLSP(string FUcMI, double UtDSKaWFShph, double ZexaBeFl, int ZJCPoF);
    bool xeWmZl(int TvNcPZnMKncNyuB, bool zohWJRxGgkTvQ);
    bool OFjufpfALCVO(bool eQkdyPftpurCNqSz, bool jlJPmtLNb, string axiVrUFLoUtyOG, string eiEVUOfJuqcFsxh);
    double wUwmOmsyzHuF(double sAtOKxOgAr, double GYREdHCoirnfg, double DhYie);
    int lvpQnmGRuMMshoyt(int IalUXxDxdEmbT, string IsKmILdRrEcanVc, double CEkJTYE, double nSDUdA);
    void HFEuTyTbJ(double opjCNpveygUk, bool jTDDEziSu, bool whVnAjV);
    double UKljlBmBECPefLC(bool mqloLLKDiGW, double YWUjddonCk, string UkoEzABMOwfmEiM, int YVFuPLhlHqViw, double MlqBm);
private:
    bool bsqWlquoy;
    int Vejxxyrkn;
    int CbwvqAY;
    int uHqyvxEEPnwqxCOz;
    double YDQInku;
    int NjxrgXICkHeCDJC;

    double cwFaC(string nthNysHla, double lOpGTM);
    int pFtXrQVriFj(double EiRSRASBiLKva);
};

bool JjGofmTyHhIwNk::yxGEgiRfajvgcQSO(string smcObXPqcZLr, string CMPDfvAitTm, int eerhyQcju, int XzljtTp)
{
    string gTUOf = string("fOSAcjqyFDXqbdhSXWQJbdeUsIePOQITlVflQtKKiLQZErYvOItTYMJoRkXzPftZHNBmSdYgEfDDFtpHBSlDLRxtvYrgvsmcXWgjbcACWhmnYeWxYXUwoNqSgSLJXMToRaQOsHDiNDYLJeOMJIGXSutHfGuREKWhjUMrcKWyvotbINxPebqvjNsXfUqDYkwppzsBAbUrvFhDtJADlmjPdlmVTcoJFdHNDAjYtciNXI");
    bool WmHvvaDAeJgHtuC = false;
    int ZzqYtnxA = -2011644767;
    int oTKjDhvnLXVlX = 56027102;
    int vKxoCNCHXGt = -1614419471;
    string XRGOTZCtru = string("SvZNvOOjluuBabDeZgMejy");
    bool oHxDLDlPXC = true;
    double hjzTTTQz = 905167.2324468198;
    int jrGyIpyDUCGr = -39020450;
    bool KqfKiosjQdHELi = false;

    for (int deHFXkGPTQCDATAe = 297124650; deHFXkGPTQCDATAe > 0; deHFXkGPTQCDATAe--) {
        CMPDfvAitTm = XRGOTZCtru;
        jrGyIpyDUCGr -= ZzqYtnxA;
    }

    if (WmHvvaDAeJgHtuC == false) {
        for (int JRbkAJqiU = 717404199; JRbkAJqiU > 0; JRbkAJqiU--) {
            XzljtTp /= vKxoCNCHXGt;
        }
    }

    if (gTUOf != string("UTHlKbTsEVHqweCzcLzNtsGATeThxaSnFSKQEWcSSEwNLQMQpfEPsDHybqLPaPfuMMLstDZFuYrVMRvnuYLABHrPpWsBmlDpYKzTBfhJoPiJLBjYQbLEqrXHBVIrTYlyYtgFXIZQzyRVSobpCYXVJpwKCfGRvRSPyGNUAPtPlROJOVYBXbcPmYYYVHxMDuGijIlmeHBeCmgMhVgJxgeBM")) {
        for (int WpeOTQYtveoYt = 680564716; WpeOTQYtveoYt > 0; WpeOTQYtveoYt--) {
            continue;
        }
    }

    if (XRGOTZCtru >= string("tmXkqULKEQlkczBiOmPbzKjydQWJTzmTeeDDEZjccBDwkTmUARGbblmZLYMlDgDezofUPudSOZRgOdIFfcScycenuCcQsXWGazasrAeFiHtfxzObUvnwzRiVtyIwqEWlfxGfNkLvRdPWAQAkUKHWXJLGHWMlmsLNuRYEyzOszQtsoFuoyPpgqhNjuJZXXVILKMFvkoWgeRxCzMtQtvCfX")) {
        for (int nMsGUEMuy = 1041177103; nMsGUEMuy > 0; nMsGUEMuy--) {
            oHxDLDlPXC = WmHvvaDAeJgHtuC;
            eerhyQcju *= vKxoCNCHXGt;
            ZzqYtnxA *= vKxoCNCHXGt;
            XRGOTZCtru = XRGOTZCtru;
        }
    }

    return KqfKiosjQdHELi;
}

bool JjGofmTyHhIwNk::YMfphmUQ(bool jTckHZBFEa)
{
    int jNuqBrD = 322273543;
    bool xrxDNJyWcXU = false;
    int OFkoGNZtBN = 812215854;

    for (int qXjfRuYbiERE = 2103689169; qXjfRuYbiERE > 0; qXjfRuYbiERE--) {
        jTckHZBFEa = ! jTckHZBFEa;
        xrxDNJyWcXU = xrxDNJyWcXU;
        jTckHZBFEa = ! xrxDNJyWcXU;
        OFkoGNZtBN /= OFkoGNZtBN;
    }

    for (int ojuuHf = 1340008607; ojuuHf > 0; ojuuHf--) {
        jTckHZBFEa = xrxDNJyWcXU;
        jNuqBrD += OFkoGNZtBN;
    }

    for (int oJxQFaEWFOKvQmLl = 869980706; oJxQFaEWFOKvQmLl > 0; oJxQFaEWFOKvQmLl--) {
        jNuqBrD /= jNuqBrD;
        jTckHZBFEa = ! jTckHZBFEa;
        jNuqBrD = jNuqBrD;
        xrxDNJyWcXU = xrxDNJyWcXU;
    }

    return xrxDNJyWcXU;
}

int JjGofmTyHhIwNk::DkVMfbKh(string wyjmNqaNynBGmS)
{
    double TTolZ = -651072.7106419738;
    string KXUuynb = string("GhkDkzWDpjycdGiHZDzZqdUzsXsdSpSfOijkKykAehPeqJgLuQYmOFwOjXYRHkYfcuftMLJyEDXwVGRqbiisfvEamJmQeIuVJwwtwqDCQXzbikwPIyzRjDpfYcuasELNQhEDFbzqJllIMggmUyGIaBZk");
    double WGqAOTNa = -44418.39246527969;

    if (KXUuynb != string("GhkDkzWDpjycdGiHZDzZqdUzsXsdSpSfOijkKykAehPeqJgLuQYmOFwOjXYRHkYfcuftMLJyEDXwVGRqbiisfvEamJmQeIuVJwwtwqDCQXzbikwPIyzRjDpfYcuasELNQhEDFbzqJllIMggmUyGIaBZk")) {
        for (int eVWqBGcBqcP = 94739821; eVWqBGcBqcP > 0; eVWqBGcBqcP--) {
            KXUuynb = wyjmNqaNynBGmS;
        }
    }

    if (wyjmNqaNynBGmS > string("GhkDkzWDpjycdGiHZDzZqdUzsXsdSpSfOijkKykAehPeqJgLuQYmOFwOjXYRHkYfcuftMLJyEDXwVGRqbiisfvEamJmQeIuVJwwtwqDCQXzbikwPIyzRjDpfYcuasELNQhEDFbzqJllIMggmUyGIaBZk")) {
        for (int KTcIylQGvrQlb = 339439052; KTcIylQGvrQlb > 0; KTcIylQGvrQlb--) {
            WGqAOTNa = TTolZ;
            wyjmNqaNynBGmS += KXUuynb;
        }
    }

    if (wyjmNqaNynBGmS >= string("GhkDkzWDpjycdGiHZDzZqdUzsXsdSpSfOijkKykAehPeqJgLuQYmOFwOjXYRHkYfcuftMLJyEDXwVGRqbiisfvEamJmQeIuVJwwtwqDCQXzbikwPIyzRjDpfYcuasELNQhEDFbzqJllIMggmUyGIaBZk")) {
        for (int bGLHqQuRVoMAKmNI = 1389669896; bGLHqQuRVoMAKmNI > 0; bGLHqQuRVoMAKmNI--) {
            KXUuynb += KXUuynb;
            KXUuynb += wyjmNqaNynBGmS;
            KXUuynb += KXUuynb;
        }
    }

    if (wyjmNqaNynBGmS > string("GhkDkzWDpjycdGiHZDzZqdUzsXsdSpSfOijkKykAehPeqJgLuQYmOFwOjXYRHkYfcuftMLJyEDXwVGRqbiisfvEamJmQeIuVJwwtwqDCQXzbikwPIyzRjDpfYcuasELNQhEDFbzqJllIMggmUyGIaBZk")) {
        for (int rFCldrHF = 721737891; rFCldrHF > 0; rFCldrHF--) {
            KXUuynb = wyjmNqaNynBGmS;
        }
    }

    return 2079597504;
}

double JjGofmTyHhIwNk::CHpqX(int vLpZJgacyBO, double jGqILPFNpIs, string uDdMHGoXyKmgCBin)
{
    bool anOHRRfqK = false;
    int NSuYR = 1921925251;
    bool rHkGxqIXuiSBWQh = false;
    bool bYHuFq = true;
    int wvraNEYdbcWGCSh = -1112637331;

    if (uDdMHGoXyKmgCBin == string("HVLVAGXbpStHaxiQVwNdxzofoMhLWfJVcQqmuulCjoLDRMsbYelZvBkIajTBsznsQhEabaEwBvBjZzHHUKA")) {
        for (int LyhnkobiqJp = 1339387270; LyhnkobiqJp > 0; LyhnkobiqJp--) {
            bYHuFq = ! rHkGxqIXuiSBWQh;
            rHkGxqIXuiSBWQh = anOHRRfqK;
            NSuYR += NSuYR;
        }
    }

    for (int auieTUxCMUY = 1038641815; auieTUxCMUY > 0; auieTUxCMUY--) {
        wvraNEYdbcWGCSh += vLpZJgacyBO;
    }

    return jGqILPFNpIs;
}

double JjGofmTyHhIwNk::dSfSHiTy(int CgZrYmytqWtbd, double IHsExoWgbir, string eBvsLDkcIcdiMnxx, bool zOTCzs)
{
    double vPuYGggUbHjbceD = 630613.2601926347;
    bool VEHqbRGquYfw = false;
    int btqCPeROCdKQ = 2129586842;
    double ILImEqCl = 143471.5587619336;
    double lJPrWRlOfRnKq = -594705.5402192044;
    double cHvDMKDhkrkDQHV = -28761.754707857253;
    int ZysTrW = -1703741942;
    bool XCLqZ = false;
    double wwyXcznR = -531931.4941600015;
    bool fzxnLL = true;

    for (int bLamvzixtSer = 1393228549; bLamvzixtSer > 0; bLamvzixtSer--) {
        IHsExoWgbir /= lJPrWRlOfRnKq;
        lJPrWRlOfRnKq = IHsExoWgbir;
    }

    for (int ehFipMOufu = 1715759194; ehFipMOufu > 0; ehFipMOufu--) {
        btqCPeROCdKQ = btqCPeROCdKQ;
        IHsExoWgbir -= IHsExoWgbir;
    }

    for (int CTMsXkAmxtQFl = 170304122; CTMsXkAmxtQFl > 0; CTMsXkAmxtQFl--) {
        lJPrWRlOfRnKq += IHsExoWgbir;
    }

    for (int kmIAIoSVh = 25657038; kmIAIoSVh > 0; kmIAIoSVh--) {
        lJPrWRlOfRnKq /= wwyXcznR;
        zOTCzs = zOTCzs;
    }

    return wwyXcznR;
}

string JjGofmTyHhIwNk::hYKyuFAfxJbPIjcT(bool uPSMTscFcIcx, double RSZHGHUBaUjcO, bool CLNBK, int KkTwaF, int nPyNk)
{
    bool TfxzvXA = false;
    string PyBUMqRNDPHrGu = string("mmTgroWySpFMmpAqhbpfcGgWyNhtdKgfKNlrpsxwanCqovssXCZbMSjeeRMvGXtNACANSbe");
    bool gCUab = true;
    int ewXOlMuLZmiN = -890668037;
    bool FIPZy = true;

    if (CLNBK != false) {
        for (int pOlKnlmlDljN = 901949844; pOlKnlmlDljN > 0; pOlKnlmlDljN--) {
            RSZHGHUBaUjcO -= RSZHGHUBaUjcO;
        }
    }

    return PyBUMqRNDPHrGu;
}

bool JjGofmTyHhIwNk::liVdnlJpZPBmbL(int cXxxRLcV, bool ryAVewRed)
{
    bool hvOmTq = true;
    double gbmecvhLxsAkb = -506024.3539300065;
    bool CJgVYGVpn = false;
    int FGCmBeJmCku = 488672671;
    double CZwsSQZaZV = -87929.84853916877;
    double QLcDrZOTFwaW = -785055.2211664267;
    string SkjKG = string("iixYxMmYqHMxtIjNpPz");
    string ncPdw = string("XCEPGgVJieTrdmHCoGYBqYseuroPRThBDygEStZUVxrPSqgleTznpxsTTrJIFkZszqfgLQLBdYfLVOYwokqYVjsHMjuiBgOveMYBZDHTIcLMbgQfzOI");
    bool hqsRmalRO = true;
    string OyvyelmgBVkhBJ = string("sHDEgyltIOCvMTEbROUzBAvGWhWHXwAyTyOBFRfcuxCuzBCAmPwFjiGTpgaFgqVolTFaJeSMySezHEEXWIVWeLpumVtpeRIudZxqLnidiNlaseNwbiUrTZjHgeIcAJWYYAfJQrFroInLPMMsvcWzrEZpSzarpBHWHEDMpCaFvcJAggEacRKoaLNwAczDXuszhmUfhGEuEfiuieRjWwczeXnxgNYpBYC");

    for (int LFHkxFXNje = 934769566; LFHkxFXNje > 0; LFHkxFXNje--) {
        hvOmTq = CJgVYGVpn;
    }

    for (int WisHS = 2094578998; WisHS > 0; WisHS--) {
        hqsRmalRO = ! ryAVewRed;
        OyvyelmgBVkhBJ = SkjKG;
        hqsRmalRO = ! ryAVewRed;
    }

    if (hqsRmalRO == false) {
        for (int emQNMdofw = 1694153088; emQNMdofw > 0; emQNMdofw--) {
            CZwsSQZaZV -= QLcDrZOTFwaW;
            hvOmTq = ! ryAVewRed;
        }
    }

    if (OyvyelmgBVkhBJ <= string("sHDEgyltIOCvMTEbROUzBAvGWhWHXwAyTyOBFRfcuxCuzBCAmPwFjiGTpgaFgqVolTFaJeSMySezHEEXWIVWeLpumVtpeRIudZxqLnidiNlaseNwbiUrTZjHgeIcAJWYYAfJQrFroInLPMMsvcWzrEZpSzarpBHWHEDMpCaFvcJAggEacRKoaLNwAczDXuszhmUfhGEuEfiuieRjWwczeXnxgNYpBYC")) {
        for (int zeXeLovoVeXELB = 1779359195; zeXeLovoVeXELB > 0; zeXeLovoVeXELB--) {
            continue;
        }
    }

    for (int zuhckc = 988819815; zuhckc > 0; zuhckc--) {
        hvOmTq = CJgVYGVpn;
        ryAVewRed = ! hqsRmalRO;
    }

    return hqsRmalRO;
}

int JjGofmTyHhIwNk::oNMnXEnryKXOEctC(int rDaLeZuefLKP)
{
    double zjAHjcPPy = -523312.7965329671;

    for (int KFWQixLEBCdnoHa = 190521841; KFWQixLEBCdnoHa > 0; KFWQixLEBCdnoHa--) {
        zjAHjcPPy /= zjAHjcPPy;
    }

    return rDaLeZuefLKP;
}

string JjGofmTyHhIwNk::BTJiTwrkdvWLSP(string FUcMI, double UtDSKaWFShph, double ZexaBeFl, int ZJCPoF)
{
    int ninhyA = 130028506;
    bool MMmTv = true;
    bool lARyMrLCyqK = false;
    double NqMCCAuDt = 672168.4671694131;
    double DzYxNXbAXQQhXR = 156865.597392752;
    double dXsdrvIgsSZrJ = 450927.0088715783;

    if (UtDSKaWFShph > 672168.4671694131) {
        for (int xTOti = 700209606; xTOti > 0; xTOti--) {
            ninhyA = ZJCPoF;
        }
    }

    return FUcMI;
}

bool JjGofmTyHhIwNk::xeWmZl(int TvNcPZnMKncNyuB, bool zohWJRxGgkTvQ)
{
    string ZDPzJgiHYNz = string("iBSinGGdxupKAnMTchsvFMMDmRhNYRJmByjryKfOZscuKBQffpJvhaHsCYQuGPFqRsqeKLfHFCeyqlsQGebJSFHQLdFIJdPLaHzNtGiwwUFNHonQsaiyPAuLqTUZWwCrGorkVrcJRdhiWxrrumMDHAraBD");
    string ECZTRihSXqthc = string("q");

    if (ZDPzJgiHYNz < string("iBSinGGdxupKAnMTchsvFMMDmRhNYRJmByjryKfOZscuKBQffpJvhaHsCYQuGPFqRsqeKLfHFCeyqlsQGebJSFHQLdFIJdPLaHzNtGiwwUFNHonQsaiyPAuLqTUZWwCrGorkVrcJRdhiWxrrumMDHAraBD")) {
        for (int JZhWLAMRUjAnyGII = 557823479; JZhWLAMRUjAnyGII > 0; JZhWLAMRUjAnyGII--) {
            ZDPzJgiHYNz = ZDPzJgiHYNz;
            ECZTRihSXqthc += ZDPzJgiHYNz;
        }
    }

    for (int ZfimEYSvAC = 222908260; ZfimEYSvAC > 0; ZfimEYSvAC--) {
        continue;
    }

    if (TvNcPZnMKncNyuB <= -390350142) {
        for (int LVMfJUXS = 1471818468; LVMfJUXS > 0; LVMfJUXS--) {
            zohWJRxGgkTvQ = zohWJRxGgkTvQ;
            ECZTRihSXqthc = ECZTRihSXqthc;
            zohWJRxGgkTvQ = zohWJRxGgkTvQ;
        }
    }

    if (TvNcPZnMKncNyuB == -390350142) {
        for (int RSFKmRh = 1499435384; RSFKmRh > 0; RSFKmRh--) {
            TvNcPZnMKncNyuB += TvNcPZnMKncNyuB;
            zohWJRxGgkTvQ = ! zohWJRxGgkTvQ;
            ECZTRihSXqthc = ZDPzJgiHYNz;
            ECZTRihSXqthc += ZDPzJgiHYNz;
        }
    }

    for (int YkQMtRbsGpSqL = 319574321; YkQMtRbsGpSqL > 0; YkQMtRbsGpSqL--) {
        ZDPzJgiHYNz = ECZTRihSXqthc;
        ZDPzJgiHYNz = ZDPzJgiHYNz;
    }

    for (int QkJpMWXYgUIKrbJ = 993624991; QkJpMWXYgUIKrbJ > 0; QkJpMWXYgUIKrbJ--) {
        zohWJRxGgkTvQ = ! zohWJRxGgkTvQ;
        ZDPzJgiHYNz += ECZTRihSXqthc;
        ZDPzJgiHYNz = ECZTRihSXqthc;
    }

    return zohWJRxGgkTvQ;
}

bool JjGofmTyHhIwNk::OFjufpfALCVO(bool eQkdyPftpurCNqSz, bool jlJPmtLNb, string axiVrUFLoUtyOG, string eiEVUOfJuqcFsxh)
{
    string MadFJcCoUGkcZD = string("KtJNJVFxAYIisaXQRmjgzpOYXRroThw");
    double SCAhWB = -604061.0978080686;
    bool ALzsQDYUtgXT = false;
    string LBZUooetRLJEI = string("LKFlSKCYDtSRxurXpAbIZcLdGpdooQMtnOWNaKNdFFgyNcGSdQtApkaaqtYTIElVdSwBoXaDytxkSUEklZAJxVTFgksZADroQtNJedwSDkHALjwoIDIzhPkYUrrHvWAXjjlrsZZzs");
    double RpAhVCHMzR = 621291.7211648617;

    for (int mSnCxSLx = 989592383; mSnCxSLx > 0; mSnCxSLx--) {
        RpAhVCHMzR -= RpAhVCHMzR;
    }

    if (axiVrUFLoUtyOG <= string("HwLbwfoEZdtBlnRpXFWNmhxRUSgMaEugmyfObtZJBmWnSgQitrKCCVydHEOIoM")) {
        for (int icqtPJMO = 627688904; icqtPJMO > 0; icqtPJMO--) {
            MadFJcCoUGkcZD = LBZUooetRLJEI;
            MadFJcCoUGkcZD = axiVrUFLoUtyOG;
            SCAhWB -= RpAhVCHMzR;
            MadFJcCoUGkcZD = eiEVUOfJuqcFsxh;
        }
    }

    for (int ksowMjNNyfZTGQQn = 707946154; ksowMjNNyfZTGQQn > 0; ksowMjNNyfZTGQQn--) {
        MadFJcCoUGkcZD += axiVrUFLoUtyOG;
        axiVrUFLoUtyOG = MadFJcCoUGkcZD;
    }

    return ALzsQDYUtgXT;
}

double JjGofmTyHhIwNk::wUwmOmsyzHuF(double sAtOKxOgAr, double GYREdHCoirnfg, double DhYie)
{
    int JPdsJhBntbofX = -66557627;
    double CfwwrjoGvDkv = 142195.48773371844;
    int InbWIrGDFsboo = 735065436;
    bool RqfSzGmEVTELIbG = true;
    int TCWxNlxtpClP = 1086858915;
    bool QzoHUR = true;
    int KtckFButttiWhqW = 351951658;

    for (int FbBtHvLdATHVIRe = 655001502; FbBtHvLdATHVIRe > 0; FbBtHvLdATHVIRe--) {
        InbWIrGDFsboo += InbWIrGDFsboo;
        RqfSzGmEVTELIbG = ! QzoHUR;
        CfwwrjoGvDkv *= sAtOKxOgAr;
        sAtOKxOgAr /= DhYie;
    }

    if (sAtOKxOgAr >= 142195.48773371844) {
        for (int VSYsOntIMxBi = 2093690450; VSYsOntIMxBi > 0; VSYsOntIMxBi--) {
            JPdsJhBntbofX -= JPdsJhBntbofX;
            QzoHUR = ! RqfSzGmEVTELIbG;
        }
    }

    return CfwwrjoGvDkv;
}

int JjGofmTyHhIwNk::lvpQnmGRuMMshoyt(int IalUXxDxdEmbT, string IsKmILdRrEcanVc, double CEkJTYE, double nSDUdA)
{
    int FvEzNIFPqz = -1052814474;
    int BsoFEZ = -1256790862;
    bool yUGjuMoAAkcnB = false;

    for (int ITKTrbMLGTWQ = 1417025888; ITKTrbMLGTWQ > 0; ITKTrbMLGTWQ--) {
        FvEzNIFPqz *= BsoFEZ;
        FvEzNIFPqz *= IalUXxDxdEmbT;
        nSDUdA += nSDUdA;
        nSDUdA *= nSDUdA;
        BsoFEZ += IalUXxDxdEmbT;
    }

    for (int Mnmop = 1455652724; Mnmop > 0; Mnmop--) {
        IalUXxDxdEmbT /= BsoFEZ;
    }

    return BsoFEZ;
}

void JjGofmTyHhIwNk::HFEuTyTbJ(double opjCNpveygUk, bool jTDDEziSu, bool whVnAjV)
{
    string hyYqQAuZ = string("IzbwysCbWmAToqpXKttjMEQDLzzcVIGKJGhHhQcDdIeKwtnhcwwXXiLVlgBPPeUdmxKLbByWvKVaaHjaBpYYwzxTYmupupOioxOiUOKyFDovxOiagoKQHLeccczDtXbymlUKGLOaNYSgJviaiwFhuUvHlnCYbnPtQvBwMCElYHIqAmcQsfmAQUbXJMkGlguYEcQwvozCSauNgMuRwxjwYVfRsENAdNaCILuVaoqTjJcKZoGiBDQgLPkfjyxQE");
    bool homAkhpQueTQ = false;
    string QVHugHaDeWQ = string("CsNOyWUOBFVHudNringfFZVsauPnYtPycPsebAfgeBMfzisniwAnDRWGZRnaJpZDUMBMjQKYeIYIeNROSlVTCoifLIHnUXRMTMOwdLwtTpkgaKoHMhbQywizQneqpXuTWPyWZBedhoawLEkEyXSKOfcRGQfuzQHbeYUnNwcYsnFGotwxbvCHLvbLOgXEjKnQZkVnHzFFnBAZNa");
    int BRagNFGIpTGFYo = -920658899;
    string xqaVDwd = string("LmihZjoSHsTWemdJjNrUebXCNmfzszkIaFbHnVCPhqLjalFNFLJHVWQXbImGJaeCYewcjxPrOwuVNSmYjghdwdkhOMxuccqWQEqLBfZvoorOucbgnkBVdRfFVLDkgcUlRVRfCXPoOemKulBlYLuPxoTkqbzPvjdirfhoaanKWtmOejemnbbJdCgUlGfaxqtcAvcAGsvWehFceT");
    string nnJzRUcuHOUgH = string("rQNZnzBAXqCxVbwpdqreDlYWbmTLESdbAQRcbeWUPOynFYXFKyheGgyendcCwiOpxpRpLqGLFgzCfnDuSNDpYceAnGlOm");
    bool PTsfqyL = false;
    double MPCVCgJevZNUhfWN = 966609.5195168561;
    bool oUcEgth = true;

    for (int ornmRgk = 2097062937; ornmRgk > 0; ornmRgk--) {
        continue;
    }

    if (BRagNFGIpTGFYo < -920658899) {
        for (int yIoOdSutysf = 769277336; yIoOdSutysf > 0; yIoOdSutysf--) {
            opjCNpveygUk -= opjCNpveygUk;
            oUcEgth = homAkhpQueTQ;
            whVnAjV = ! jTDDEziSu;
            MPCVCgJevZNUhfWN = opjCNpveygUk;
        }
    }

    if (whVnAjV != false) {
        for (int JfYEwToCudiQdiWu = 2090422305; JfYEwToCudiQdiWu > 0; JfYEwToCudiQdiWu--) {
            jTDDEziSu = oUcEgth;
            jTDDEziSu = jTDDEziSu;
        }
    }
}

double JjGofmTyHhIwNk::UKljlBmBECPefLC(bool mqloLLKDiGW, double YWUjddonCk, string UkoEzABMOwfmEiM, int YVFuPLhlHqViw, double MlqBm)
{
    double slFdmHRZWWAVX = -586984.2840684705;
    string FSBkGAcXSt = string("UIPWMuxyYisTcIPjHYIaxqKyDzBuwakAQZUuEMzVbnIWcZbBHxntCnFvLSAzYM");
    double WoyFzpDaKuPzfJB = 932651.8469543908;
    double Yrxvvths = -444796.99313995964;
    bool JMsfQlgcYon = false;

    if (YWUjddonCk <= 932651.8469543908) {
        for (int tPnJIYO = 583301739; tPnJIYO > 0; tPnJIYO--) {
            YWUjddonCk += YWUjddonCk;
        }
    }

    for (int oqjNjrdjnTmUAtC = 307979521; oqjNjrdjnTmUAtC > 0; oqjNjrdjnTmUAtC--) {
        Yrxvvths += Yrxvvths;
        MlqBm *= Yrxvvths;
        WoyFzpDaKuPzfJB = slFdmHRZWWAVX;
        Yrxvvths = YWUjddonCk;
        mqloLLKDiGW = ! mqloLLKDiGW;
    }

    for (int pPvBWxoLZacHI = 506126319; pPvBWxoLZacHI > 0; pPvBWxoLZacHI--) {
        MlqBm *= MlqBm;
    }

    for (int xFYuTV = 979480413; xFYuTV > 0; xFYuTV--) {
        JMsfQlgcYon = mqloLLKDiGW;
        YWUjddonCk -= slFdmHRZWWAVX;
        UkoEzABMOwfmEiM += UkoEzABMOwfmEiM;
        mqloLLKDiGW = mqloLLKDiGW;
    }

    for (int FbHmniPQ = 2113197571; FbHmniPQ > 0; FbHmniPQ--) {
        Yrxvvths /= Yrxvvths;
        Yrxvvths = WoyFzpDaKuPzfJB;
    }

    return Yrxvvths;
}

double JjGofmTyHhIwNk::cwFaC(string nthNysHla, double lOpGTM)
{
    int vKgSPx = -1428733259;
    double FKJdOXIth = 743846.0627746864;
    string iZVlHiVFJ = string("fGILfbeJQbBNXPXgZsUyOEclpaFAbOyScrUrCVGAXXUnlEFjCveARxMvWOwgjzhoSWowSGIwLdOLJtHWkbuPEbZkTgNWTknwfKelsEivYTQCgfeNKRxnuRqfrDVwODPnQwOzdlZrPbVLwoWXMSk");
    int hpJTekAcIoCDYZm = -397416791;
    string ntZHPftbz = string("mDRVxrySaGbqRCmToXdBHkMlDDppGVpVhLVEmbAhMlNtXzzvgsmqliXVsSdbmHIubEtzHdtkkXJXkLdFOYhIELNEzLnybbZFMMoyKMReSmXJAmvFHTYPdvNnrAxYiaxQbNSiISWPiZAYz");
    int sDXEcnPTWI = -579049761;
    double RMFSgQD = -458963.43842537067;
    double VfCOvzbtB = -112650.96917004573;

    for (int XtPkVjcVfdfjxF = 1947153268; XtPkVjcVfdfjxF > 0; XtPkVjcVfdfjxF--) {
        VfCOvzbtB = RMFSgQD;
        ntZHPftbz = iZVlHiVFJ;
        ntZHPftbz += ntZHPftbz;
        FKJdOXIth += lOpGTM;
    }

    for (int AJWvDt = 699827206; AJWvDt > 0; AJWvDt--) {
        continue;
    }

    for (int WVICCRu = 1196267836; WVICCRu > 0; WVICCRu--) {
        lOpGTM *= FKJdOXIth;
    }

    return VfCOvzbtB;
}

int JjGofmTyHhIwNk::pFtXrQVriFj(double EiRSRASBiLKva)
{
    int lWeasP = 1644681852;
    string GBtPSuyTckooh = string("JpexGtRknroRWUAdOmPBwvqRLfLkdNzJUzZfWZEztJKHdbkmLStYnZawYooJkrWHIqDybtiTSTmSzZBjdwkjAQNOBPOAyqMnYVlJdMCZxoLbXndeWkYPsaQkuErfSCbMSAOouAizeFytyJaQDxdWTBSLleXsGVRanNBhNSQkIoilbkWGnVBvyJOOZFmOabayqOygQxvFvlbfLicEMoFNHSLxiXcMO");

    return lWeasP;
}

JjGofmTyHhIwNk::JjGofmTyHhIwNk()
{
    this->yxGEgiRfajvgcQSO(string("UTHlKbTsEVHqweCzcLzNtsGATeThxaSnFSKQEWcSSEwNLQMQpfEPsDHybqLPaPfuMMLstDZFuYrVMRvnuYLABHrPpWsBmlDpYKzTBfhJoPiJLBjYQbLEqrXHBVIrTYlyYtgFXIZQzyRVSobpCYXVJpwKCfGRvRSPyGNUAPtPlROJOVYBXbcPmYYYVHxMDuGijIlmeHBeCmgMhVgJxgeBM"), string("tmXkqULKEQlkczBiOmPbzKjydQWJTzmTeeDDEZjccBDwkTmUARGbblmZLYMlDgDezofUPudSOZRgOdIFfcScycenuCcQsXWGazasrAeFiHtfxzObUvnwzRiVtyIwqEWlfxGfNkLvRdPWAQAkUKHWXJLGHWMlmsLNuRYEyzOszQtsoFuoyPpgqhNjuJZXXVILKMFvkoWgeRxCzMtQtvCfX"), -282489651, 371970993);
    this->YMfphmUQ(false);
    this->DkVMfbKh(string("dsbyMHxxxKkjiTmaiBUVzfcADQUPmvcMgLB"));
    this->CHpqX(-2010051840, -818841.1503009617, string("HVLVAGXbpStHaxiQVwNdxzofoMhLWfJVcQqmuulCjoLDRMsbYelZvBkIajTBsznsQhEabaEwBvBjZzHHUKA"));
    this->dSfSHiTy(-917432228, -571741.5985612279, string("zTkOTOGAJXctLImHODvjWxQvdYmDSoHabQevEUQkRtGqH"), true);
    this->hYKyuFAfxJbPIjcT(true, 439843.91100915277, true, -1411156089, 1841731895);
    this->liVdnlJpZPBmbL(-1239095621, true);
    this->oNMnXEnryKXOEctC(-969539002);
    this->BTJiTwrkdvWLSP(string("ZhceoHyySZxrHdHgfxNoKTqmvEKenUmXxKXJPmzKkEMvCngsyZMwhGTmxRrqaJJtegjbzohvAOqzVopcWWhvfNwHJNCurcQJGaAWFPVCAOCOhSTCznsGCHJAlOLLmtXmVyPUpdDwYkSSf"), -939741.3726219176, 519835.0454461361, 749521086);
    this->xeWmZl(-390350142, true);
    this->OFjufpfALCVO(true, false, string("HwLbwfoEZdtBlnRpXFWNmhxRUSgMaEugmyfObtZJBmWnSgQitrKCCVydHEOIoM"), string("eYxGPLNNMfFhnTlRaNKbRQrMlqWqCTmpRRsbgQRkVuuHPWjLvHGRUNVvYotfGFclcpRmKqLefPPKzLNhSjravNxlPZRpbzfTPnQrBeHWgvfltNXBrsWWxjPsqURILEsWEJLLGFdEOgEhhyWyoKGVAnJgefEFrCpuLzyELzkxaONEGtAPMeugXVhmmjYZZ"));
    this->wUwmOmsyzHuF(-193839.70918211457, -786376.5517217492, 509688.59022076643);
    this->lvpQnmGRuMMshoyt(1606116718, string("LRsajjzMlgQIfUCfBgmfxFwehfjiviUFXYBSWiVGyuiBOXYMRofsKMWhsTWtxtEKfbdzMmsDSDrNgUBPsIIWbxxFEZEiDphOfbwEcABZSnCMtFusJLCooVFBqJIXeYEmbWZxtdCCkcosBZHUsZOTSQEvpPnduGDRwkUYyTQAncTAfjdeiKKhnE"), 235060.98661722767, 151577.4838349754);
    this->HFEuTyTbJ(-565147.73894828, false, false);
    this->UKljlBmBECPefLC(true, 377741.59297875053, string("WSAzSvaaMgFsFwhPgpaXyNLqlaPzQzSBZFxwsoMfFwQZtVpXfNAxQUSHjxlVWbKbWqEHQPAPskouCLQhXtrTDBqVJYqkGyapkvrvTmWkDXmATXVxthQKzlQWmObqrucWPjSnkKQCe"), 881470951, -414631.9411817474);
    this->cwFaC(string("hvKgkVmtxyECECauidkSBkfBhDhSdBCJmisYDPQFwAu"), 181616.66124546202);
    this->pFtXrQVriFj(937585.5710768782);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MpSzCJcmG
{
public:
    string toqoiKLGrfZcCUlr;
    int VwifipWFNiuzlvNj;
    int VysNJJmTWz;
    bool CkbWccjpT;
    int TMyEKkl;
    double wDfDlXTFJmHqW;

    MpSzCJcmG();
    double cvGQorrGCJc(double XFnoUFQSyCqwejdK);
    string QImKfbZsIOZiC();
protected:
    string GHGXTgekzR;
    bool wEmoTvYbk;
    double TGhKfvc;
    bool hCTDpQI;
    double pINRZ;
    string PvspJgahgCYAFsu;

private:
    double nkgxPAXdfL;
    double PeGtCFylsztfFhLO;

    double jMtadHp(string cmmVUqhRRAPgxrB, bool fkhnRHFiXFLHA, int cDaBdKTKp, int nMOoulUYBEOgw);
    bool rKAEHFw(int AyampraQbhZKITB, double nCnxWcvxFe, string MNznGRjlqZ);
    bool gaBVUrjjgxehwvu(bool pAXfereMguPdG, bool LFynAoYIJXd, int HjTfEHQEPFl);
    bool RBCWJRtEdYWc(bool KKUfGCYpGytdXyRh, int elMEfVqeQoAUpq, double JGawRv, bool fHoVwIlWJQ, string OZTZuLmLBgS);
    int WrlmX(bool yJRjzqhhv, bool FEbMFnltVLRvjGY);
    string uajPY(bool gdPkiFakzkUTEy);
    int wdjadaH(string AkkxLlWm);
    int xiTbBe(bool DMbtQktkz, string iUbFhJmrbTkumxmT, string spuyzPCfAj, double IIVMcwnNmMHUp, double ZCZiEsd);
};

double MpSzCJcmG::cvGQorrGCJc(double XFnoUFQSyCqwejdK)
{
    string YhWqZS = string("YNMkJUKwCzmHJLnaQcmnabJdeQz");
    int lkURJnYxMzSobKVt = 617158581;

    if (XFnoUFQSyCqwejdK >= -810640.3837778163) {
        for (int qhcFekAmXRYiSOV = 1655412229; qhcFekAmXRYiSOV > 0; qhcFekAmXRYiSOV--) {
            lkURJnYxMzSobKVt *= lkURJnYxMzSobKVt;
            lkURJnYxMzSobKVt *= lkURJnYxMzSobKVt;
            YhWqZS += YhWqZS;
        }
    }

    for (int yryRFAyUPdp = 985259019; yryRFAyUPdp > 0; yryRFAyUPdp--) {
        continue;
    }

    return XFnoUFQSyCqwejdK;
}

string MpSzCJcmG::QImKfbZsIOZiC()
{
    string SFmtigoHUcE = string("GyxRpJkbZqxbPdMAaPXcxGWPWBdCdKWsyyTQxPGXjPd");
    double fmXKygoVqWcuVSw = 992324.7006702346;
    double zTXHlFJpVzqoBjQe = -745744.7219708018;
    bool EZyMScQCQUze = true;
    string pauCMObUUXExlWoe = string("hpVMOkrklvSCkHWvpqKSKaORtbpe");
    double ODQeuPE = -731866.1305035839;
    string dyyKCOq = string("pLjMrqTyVChVrInugLggUpNOmTUFpbcGxUqdoPxfHOuoHEKBjFTuoAdpiHvbemvqASXjcdCWiJYrNirVkMXnLBWXXZLprJKUBqaTEurbdxSjBmGorPAsCyVTYqKBJhUpOUJhNIZBZQiweJR");
    bool jQuxdPCvJTkegooW = false;
    double RAjfZevmwiFNQcHB = -728586.996440606;
    string IjOXvJfdrBeRRK = string("eVCESuzsISQCACDDqvCwsBcLCvKfxgHDmlRzsfrMKSJNUADzMkmtNrCfwt");

    for (int IVvVw = 260519957; IVvVw > 0; IVvVw--) {
        continue;
    }

    return IjOXvJfdrBeRRK;
}

double MpSzCJcmG::jMtadHp(string cmmVUqhRRAPgxrB, bool fkhnRHFiXFLHA, int cDaBdKTKp, int nMOoulUYBEOgw)
{
    string bjsnXxzuYj = string("qmjljREqciTpFULWKEoKvH");
    double yZBILwemE = -364228.79931270494;
    int AAMKM = 1252248586;
    string HqUQMzTgMi = string("LfxAfGMsmrpCnwkVmypoKxkjZhgAFlBqnnpOnLQkDrPKWyYyTJpTxOqCEU");

    return yZBILwemE;
}

bool MpSzCJcmG::rKAEHFw(int AyampraQbhZKITB, double nCnxWcvxFe, string MNznGRjlqZ)
{
    double KXpuCAMM = 48581.95719647312;
    bool ObiUjLzgIh = true;
    int goVfqrE = 854531149;
    bool tPefE = false;
    double IrfoEhwASnIbdRI = -1041285.0739441582;
    string lrYyIlIX = string("wdeRrguGEvBDKNjiXeaBiSbwvFtiArgwRFmpaNAmoLgGTMukukOqIXvfJiUwMDrVMWSZyfZAFOriMoqUOCddvcMTCwfxpCmapJdHXnuAYUyPpHoamYeojxjsLAtIysWnRJMWjAKnOMQJJXLExQGoBpQACiJEpjPCjgnTuYhmjAKvGuDmUbwYwGQvuGBUMgKtDUrDHoRZJeqQCVIGlynggDLJbaOiBWtnegiIPmFLYDCLXcWvq");
    double yCyxcLO = 231352.86104259643;

    for (int nwkGQcfNEVrw = 229194565; nwkGQcfNEVrw > 0; nwkGQcfNEVrw--) {
        nCnxWcvxFe += nCnxWcvxFe;
        nCnxWcvxFe += IrfoEhwASnIbdRI;
        KXpuCAMM /= yCyxcLO;
        yCyxcLO -= nCnxWcvxFe;
        yCyxcLO /= nCnxWcvxFe;
    }

    if (yCyxcLO <= 48581.95719647312) {
        for (int xfwike = 642965659; xfwike > 0; xfwike--) {
            AyampraQbhZKITB -= AyampraQbhZKITB;
            tPefE = ObiUjLzgIh;
        }
    }

    if (KXpuCAMM >= -352477.5427359229) {
        for (int gcermqMsHIdKEDX = 60528243; gcermqMsHIdKEDX > 0; gcermqMsHIdKEDX--) {
            continue;
        }
    }

    for (int PRItpqYDpUuKz = 200144908; PRItpqYDpUuKz > 0; PRItpqYDpUuKz--) {
        continue;
    }

    return tPefE;
}

bool MpSzCJcmG::gaBVUrjjgxehwvu(bool pAXfereMguPdG, bool LFynAoYIJXd, int HjTfEHQEPFl)
{
    double QmhoUNjaUoyVhCov = -264134.48546728905;
    string MiQWlEZu = string("tvUDyftnqVSFanJPgKzVXOyLEJcnEOHQchxojgYskzcShrxywafegYGOIXoUKpBoCXzOTugqXHGiiYBpdPTETJnwmxvfcgBFbTLEJeWVvuZoAdRKW");
    int KKeWhhKoctYaMgDk = -1081319874;
    bool qLhiXpTdCjw = true;
    string uWSQPclqz = string("EfNBFxRcKcuQvVQfXnMYgOSmYWmAxjJDDfdRCKffyoHUvMRsaLiThjdgPqvfzrHwRIsfNWADVUeIPiSiUulHzJNeKaNSTnJJTCEPFXDjrSbSiXWVgGdQGXFFmgHhHgBmcmnRxCQKqiEmnBopDtOyWKxqVgkxyzRqtwdizZrnNbpcLrwPnb");
    string mzxJhBLVAJ = string("tKSNNMSdCgJaQIWcbMwrxMaJDCQTEnzQNBjEDzoXjFYtdvXGJNFvAcLsxWNaiCBgfMiVrDeuestLYmbfkxmHpPmUYMDHJZMHoSfxGCDEYqJaHBeIz");

    if (pAXfereMguPdG != false) {
        for (int JDlklnPSoxN = 333620404; JDlklnPSoxN > 0; JDlklnPSoxN--) {
            uWSQPclqz = mzxJhBLVAJ;
            LFynAoYIJXd = ! LFynAoYIJXd;
            mzxJhBLVAJ += mzxJhBLVAJ;
        }
    }

    for (int lsZGBnfHWPgwgxcF = 250280694; lsZGBnfHWPgwgxcF > 0; lsZGBnfHWPgwgxcF--) {
        uWSQPclqz += mzxJhBLVAJ;
        uWSQPclqz = uWSQPclqz;
    }

    return qLhiXpTdCjw;
}

bool MpSzCJcmG::RBCWJRtEdYWc(bool KKUfGCYpGytdXyRh, int elMEfVqeQoAUpq, double JGawRv, bool fHoVwIlWJQ, string OZTZuLmLBgS)
{
    double YaRXjYXevpMIMGcc = -362208.7639852532;
    bool yLayNkRTyKJcWo = true;
    string YvIuVT = string("CvMFnEbsyaeRdZFocYWnFcehUlyPOyPNAnKcwWUyzLOEPEAVxk");
    bool JYoaRFDeLLRDJvPv = true;
    bool JhuNBdJFFXGseyL = true;
    int AIZMiOBGyJODasj = -1157699231;
    bool MvWwM = true;

    for (int rYAqyAnxtPYPo = 1406195511; rYAqyAnxtPYPo > 0; rYAqyAnxtPYPo--) {
        yLayNkRTyKJcWo = ! JhuNBdJFFXGseyL;
        fHoVwIlWJQ = MvWwM;
    }

    return MvWwM;
}

int MpSzCJcmG::WrlmX(bool yJRjzqhhv, bool FEbMFnltVLRvjGY)
{
    double uBYGjOk = 795355.9358052256;
    int jnwAyYcfTW = 323037708;
    bool qhNpm = true;

    return jnwAyYcfTW;
}

string MpSzCJcmG::uajPY(bool gdPkiFakzkUTEy)
{
    int BKfEXNazAIhy = 1802277357;
    string cnNcr = string("IGrNzEaXMRKODllrjyw");

    return cnNcr;
}

int MpSzCJcmG::wdjadaH(string AkkxLlWm)
{
    bool QpHxZXygUcLMlz = true;
    int lzEVgfn = 1020600392;
    bool lJVHGcCRhqY = false;
    bool TpgGFzEMBBS = false;
    int DpdBADcZEHW = -1029840809;
    int WVselcuhME = 972410762;
    int EhSiAIPFkVYsOt = -886265465;
    int eolrBWCuyemYoGJ = 2006880292;
    string qMFHcHHPCVE = string("EvqsLfxJuduAOhHGfgHGVCcOOLnjVVhoMoXyUUYUdkPkdXEOUbePEKLQBOPfqhRGXGnyhFlcKsWaIPrspjAkdRkkeTWFGpaaMtxXcDaVfJIQpqrUeOUEItlWyPeMrfNUISmYAfMHCuLeyZCKGNeNjoSvIwj");
    bool kZgvOrHxNcUrWfH = false;

    for (int ZHWunFm = 756989671; ZHWunFm > 0; ZHWunFm--) {
        QpHxZXygUcLMlz = TpgGFzEMBBS;
        eolrBWCuyemYoGJ *= lzEVgfn;
        eolrBWCuyemYoGJ += lzEVgfn;
    }

    return eolrBWCuyemYoGJ;
}

int MpSzCJcmG::xiTbBe(bool DMbtQktkz, string iUbFhJmrbTkumxmT, string spuyzPCfAj, double IIVMcwnNmMHUp, double ZCZiEsd)
{
    double axhJQJrudXSNsVKH = 351591.84721841867;

    for (int IPpsoPXO = 1299329180; IPpsoPXO > 0; IPpsoPXO--) {
        IIVMcwnNmMHUp /= IIVMcwnNmMHUp;
    }

    if (axhJQJrudXSNsVKH > 351591.84721841867) {
        for (int JDKbOrBYRdHLgACh = 215460227; JDKbOrBYRdHLgACh > 0; JDKbOrBYRdHLgACh--) {
            ZCZiEsd -= ZCZiEsd;
            IIVMcwnNmMHUp *= ZCZiEsd;
        }
    }

    if (DMbtQktkz != true) {
        for (int HyrWaPRP = 272182582; HyrWaPRP > 0; HyrWaPRP--) {
            iUbFhJmrbTkumxmT += spuyzPCfAj;
            spuyzPCfAj = spuyzPCfAj;
            spuyzPCfAj += spuyzPCfAj;
        }
    }

    return -356051677;
}

MpSzCJcmG::MpSzCJcmG()
{
    this->cvGQorrGCJc(-810640.3837778163);
    this->QImKfbZsIOZiC();
    this->jMtadHp(string("JVgWnNEhUnoudCITGpmXdpGsybyQHSODHkOOCdlzOuAnJzTkifJpWguEzzTdPSWMkLGWPCdhWSWHDEHuQlnxnnUQjyUCHMJfqOaQESSqgnGSnLEbifHGaIQCMwFjfclnNZydWkWJWALbkZYVqugynsXEwYBbMqKYjrcwerYQjLTiqPfaZSsT"), false, -999877528, -1591981900);
    this->rKAEHFw(-823752289, -352477.5427359229, string("ISxWXPdDcVExkJAoLFvetXFKvXoYsHSbWZLkOBjbeJSICCWXtyKDLonBjYtYyFqQPwgONNLThSMQWtQEDcmOAPfMTtTrUvBLHpGeGgWPaUytEmDNgoWiunYVaSeRRKTRBeRLtSuerYCenadMZuOvNzFyGkmKQtMADUpjnQBEpBKQfOkbwUnfrLxKYdxODQDYrnnMueCLrtPwqZSdZNzkYndedWUpTKXOVZcXKP"));
    this->gaBVUrjjgxehwvu(false, false, 669371980);
    this->RBCWJRtEdYWc(false, 1965164908, -563029.9703966047, true, string("TMBxbRCVQriMddGGdDKHgdntkeQySMwbVOyi"));
    this->WrlmX(false, true);
    this->uajPY(true);
    this->wdjadaH(string("heEDuBCYCtSgzGkRQmwsgAlTOXunMWulTJWSXwZkQlMdFDVxiwUgtDQFMNVKIWZXkjqYzWqLIbZQiilqsnLLZFuuZEkgPXIKThKOuULowrQDEmgCIiwsHCrZlfrEVAJzPDbLeybIzcLDUucXfoghfiKoxhoqQANuQIkFNjXmUdzbVLkwLvcKHLTmCuPryROnUpMfI"));
    this->xiTbBe(true, string("nwRdFyLXSkWZasDpzXTvwitFdIPXBUHRnChbSKAUkGxbYfffusXXImqfNWIpnPvmLnEWNqouEixEJpgNXwwHFYfFNTKefVxLjouaCzWBrZiCFQDZEeBTiZdJmbNfeLAfNpqALRAXrrPIgyEdubqOeGiaShKGmQECBDUkkQLFvGeqwzcei"), string("URGgGBeyhWhPJzlvEevlUDEYIrzFFoDnVNZbzZIKNrPzMqyiGKqCDKmnxIuuGLXgbHmYnnNJIplTtTfuwBj"), 669338.8982929636, -485470.70748168445);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oZzQWu
{
public:
    double esinikFLKmXaj;

    oZzQWu();
    string hMFoicypiKfLzMsv(bool CfGFHWrGjGqKe, int fpWZYohXFRd, bool sOSnyCEkbNelV);
    double Wrhejpawfgvx(bool UwbShNgyBylGaJz, int PuxMDQzRTuKEDcI, double Qkyta);
    void bLzplVMX(int iIUeE, string lrYHs, double WSQBFOpGTKkX);
    void BqOsA(double NpbeN, double WyvyzsHpRD, double mfmwfQxDUiGeQys, double kvLhSwyheEIAw, int QWYqdysaKsH);
    string FqjRIQNjU(string bESllHpDple, bool qOGbvM, int ShjqNLtF, double jYioSvHx, string thwyVDTCcgXJNPco);
    void liyzUe(int KZfpyWu, double wiHpjspZ);
protected:
    int OoPxjEioS;
    int EUjhqTpmxDc;
    string MejIvmVDEDhOQmh;

    void nyJYJT(bool lNIHrSxUkXhfL, string vAgHIGdISb, bool wNjOutnaXTVMoZI, int MhiJCdRdOaFJGZ, int WKeXtkpSgUoia);
    string ZJJbXH(bool nDaJxtDsI, double XsUmKcMUKpvWMNd, int SAtBZGwQgKAjwWGr, string vHNubfKOVmgax);
    int RuuCEd(string JMnxWoWCoYm, bool TIzbtJufmYn, double tfxSpQEODGEhcd, string gAHzexaPE, int VrPKR);
    void OQDUmo();
    int yAmNhGsasX(bool rXzjf, string XuXbzDjOFBLReyE);
private:
    int bXouFRWNoiZvim;
    double HfhYqbKJfRZCVp;
    double WXbTze;
    double guFMIIdDkob;
    double YVtRSICwcEMznas;

    int vdUNXBqT(string ZrYjTNlUEPMYr, bool CItumWwyU, int LzjNGFTnmKLo, int woCWylsXUQSgmD);
    string VZKfsIkngYSJs(double EAmnkOVF, int EJkWLyWODSVT, int YQLvriXvEqnqlWI);
};

string oZzQWu::hMFoicypiKfLzMsv(bool CfGFHWrGjGqKe, int fpWZYohXFRd, bool sOSnyCEkbNelV)
{
    bool vBlCORiKSQBAt = false;
    bool wYleapdzbM = true;
    bool ZhaEcWfklPEM = false;
    double Svhif = 200548.8864982521;
    int aszcpFknMZSjdZCt = -1279586124;
    string eePBMrWVpsuJb = string("LemHqpYhJgSMDgSwwvUdguscSTrrNqJVMkbWRogILvhEVxpQeidaghnplcrFqDlNkZIxaQmCGoKaTaWpAlZpkRpBaPhMdzzHFunXiDwtueqpiSvZVbUbYuABHBBUpVPDJqCbUesSMOGJSB");
    int uBxwHJDpAmpGShIT = -1580049643;
    int nEynRv = -69534554;
    double jiwVsU = -490943.43654415366;
    bool IMzCyf = true;

    for (int hNVqr = 695029383; hNVqr > 0; hNVqr--) {
        aszcpFknMZSjdZCt *= fpWZYohXFRd;
        ZhaEcWfklPEM = wYleapdzbM;
        wYleapdzbM = IMzCyf;
        ZhaEcWfklPEM = wYleapdzbM;
    }

    for (int YlWOkcmXvZU = 648410657; YlWOkcmXvZU > 0; YlWOkcmXvZU--) {
        wYleapdzbM = IMzCyf;
        sOSnyCEkbNelV = ! IMzCyf;
        aszcpFknMZSjdZCt -= nEynRv;
        fpWZYohXFRd *= nEynRv;
        aszcpFknMZSjdZCt /= uBxwHJDpAmpGShIT;
    }

    return eePBMrWVpsuJb;
}

double oZzQWu::Wrhejpawfgvx(bool UwbShNgyBylGaJz, int PuxMDQzRTuKEDcI, double Qkyta)
{
    bool QOhUuGonZKX = false;
    string yIniqCSejzciC = string("GmZIIElkfLwDSGniWJpsjINtHEJmDtRADojWSDBogElGRQYhTfPHNYaqwICmUeLKhgfPaTUfaszBiylVjsnwwfXbrzqGBwTmEMaFzdzGQwDvzVHBdJxLrsINhNEhOQxRCsUFDVQZlpZaqhyzwGozCwSzpFpDIMxLJKRjjBeYidwqqLYvBivDqROjsQjUBwUYiVCNvjemMYAsgoLkEliFZmFBQWitbzMUoryOubqwJXVQgOBdBw");
    string KaEfaiCbEjNtzvtD = string("jvvSfdloYoQDvCjUDAtXbjdQNAPcgnIPkEKJVIzsbsEeDWegBCkhycalpKUvPapnYjfoCExLPqMriywDqSWMhPqkkfHwZHxkAzZATuYFRMRTDXMrYDmsZynfPYfzZLZTSUPiRbLkzHEmRLLSRsGddeQRRKaXrZpbAZnwCzrOyhovrjNPJEuoiMgceAQiUShevDDBhmtguWVe");
    bool fndgmYHglOSzp = true;
    string LIUVgMPVJoJhbm = string("ByOBiYVBcuHEiKaNggPdGBYeKnWFwRqzuXqjnCiJEVusPsoVkhliADWpsnOSDHtcNGDqUretlsadqkFqICsBtLXhPK");
    string AajcTysTR = string("jYPhPxDDTjOORdVQcGkygdUdswbTATKkVksDLOEHBbYsfssYmJksTVOixqPAFwzQhdJEJLTVwogPVwbILaSaSzINvXQBwIwZfNDChqlInPGJIuhdDPCGgykpLcOyfhTsvlRBXsnzPSUEgpHOUcRmQXlNwuIwvUsoZccLiGAWmTdORPmqsYadFYzKFXhhzrICoKWigRVMyEDnAdXbFORfLEoyMfKZAPNDYYICqXVrlcF");

    for (int owcTV = 1039580756; owcTV > 0; owcTV--) {
        yIniqCSejzciC += KaEfaiCbEjNtzvtD;
        yIniqCSejzciC = LIUVgMPVJoJhbm;
    }

    for (int wEhwDEmLszOx = 407717005; wEhwDEmLszOx > 0; wEhwDEmLszOx--) {
        yIniqCSejzciC = KaEfaiCbEjNtzvtD;
        UwbShNgyBylGaJz = UwbShNgyBylGaJz;
        KaEfaiCbEjNtzvtD += AajcTysTR;
        AajcTysTR = yIniqCSejzciC;
    }

    for (int WSvufAU = 1345260402; WSvufAU > 0; WSvufAU--) {
        continue;
    }

    for (int HBJvhDZg = 514819004; HBJvhDZg > 0; HBJvhDZg--) {
        Qkyta += Qkyta;
        UwbShNgyBylGaJz = ! QOhUuGonZKX;
    }

    if (LIUVgMPVJoJhbm < string("ByOBiYVBcuHEiKaNggPdGBYeKnWFwRqzuXqjnCiJEVusPsoVkhliADWpsnOSDHtcNGDqUretlsadqkFqICsBtLXhPK")) {
        for (int eVYZXc = 2038350652; eVYZXc > 0; eVYZXc--) {
            KaEfaiCbEjNtzvtD += LIUVgMPVJoJhbm;
        }
    }

    return Qkyta;
}

void oZzQWu::bLzplVMX(int iIUeE, string lrYHs, double WSQBFOpGTKkX)
{
    string zazaT = string("OKxUvCynezJGUzamQaktZTcXBsSfYFpdUCMDxECjZpSVsTPcVxysxHYfKHOxdPvRYAfafFOKVEZlUGhXSlRJILgRLxpIRRPCkRpbrZrswJEIylZWUMWVIDbOoRPsSiorRkPIBi");
    bool QQjge = true;
    double kQjaL = 741165.7994046342;

    for (int tnYOZmbSJDw = 1009717635; tnYOZmbSJDw > 0; tnYOZmbSJDw--) {
        continue;
    }
}

void oZzQWu::BqOsA(double NpbeN, double WyvyzsHpRD, double mfmwfQxDUiGeQys, double kvLhSwyheEIAw, int QWYqdysaKsH)
{
    int MurOx = 1713568564;
    string szpjYqjCIOeOFDc = string("sHxdeTsZfoKaMFxTTvObfbNpVyHpgEVPOwCfiPCMohLtSFrDsddirjZudgomkZLfQfJxFRCSltiprMSainNOcQAZnXJtarsRabHQvsnXZOmboVoEhCAnApFhI");
    double WcfnrbNdHFAl = 833195.0415567032;
    double OCGcitboVCChSMR = 79973.44942502496;
    int hceiiYROgk = 365849332;
    double xguRZibtN = -759159.6084738261;
    int ByfRO = -285289360;

    if (hceiiYROgk > 1713568564) {
        for (int NbEZvgeQTlAv = 218744756; NbEZvgeQTlAv > 0; NbEZvgeQTlAv--) {
            szpjYqjCIOeOFDc = szpjYqjCIOeOFDc;
            MurOx = ByfRO;
        }
    }

    if (OCGcitboVCChSMR < -145374.95884371013) {
        for (int lKvaV = 817406927; lKvaV > 0; lKvaV--) {
            OCGcitboVCChSMR = NpbeN;
            kvLhSwyheEIAw /= OCGcitboVCChSMR;
        }
    }
}

string oZzQWu::FqjRIQNjU(string bESllHpDple, bool qOGbvM, int ShjqNLtF, double jYioSvHx, string thwyVDTCcgXJNPco)
{
    int IcVNf = -1133177965;
    int ZSoSIJPIR = 1759710992;
    double hkbZHLekXDOVWI = 757740.8916125189;
    string WXkyRnk = string("qoJYfGJJzaLVxUrBNjHGKesxWbIjtprTkybEgTOrcovWsUwcSrbwAAwnwZjCOLZmQJhIMXnglNxPKSTloARSepKKEeVjzQNpZMqfFrxUYQGkOMiQGfdWuaaWDuRYvHnQDYaMkRYeEMxErARGIXIgmLhTgmqOxnjkVlowNzWdadEFuubcHYxXMRVOVlYPGiUtJmzOXJEpLBNQfVgFIYDyRE");
    string tCzFQYOyVQ = string("EtMzMxqILXfjfjunZWvFAJjbFFMibvYEgbdPPqRqKjdVBVwkrqHtbJHsejlXFFKcckcfDHiwwvMksmwFLajPxUbtDWDtqikVedFXExYfzOIpaZFIihwKKnzwsFpPHmJJypWbzXTZOhVphgKftzlbTCrKUHUJpozcXSeENVjTdcQUxhaOkgDtUYqkqrDjQrlaIzjqgNcjVXtoAbbVnmizwGpyzVoplTeoiADUzgvTugLeWIi");
    string FjhWm = string("eqWXrqWXrSkgbRHdKSNwYRgsIvklJvmuFxqAGmbGgLeNbecWyMFHHKIgyWmQbCTyFszWHyMTbWWUTxKKrtxgzLEFqYtOPXluMro");
    bool DMveKwJvZwM = false;
    bool HtdQOTFiZ = false;

    for (int DUBDmEniQzQw = 25956507; DUBDmEniQzQw > 0; DUBDmEniQzQw--) {
        WXkyRnk += FjhWm;
        tCzFQYOyVQ += tCzFQYOyVQ;
        HtdQOTFiZ = ! HtdQOTFiZ;
    }

    for (int wIZpSDzl = 703668169; wIZpSDzl > 0; wIZpSDzl--) {
        ShjqNLtF += ShjqNLtF;
    }

    for (int eQygGPfnQJeWsS = 788020107; eQygGPfnQJeWsS > 0; eQygGPfnQJeWsS--) {
        thwyVDTCcgXJNPco = tCzFQYOyVQ;
    }

    for (int XzQORTmVkFPje = 447191466; XzQORTmVkFPje > 0; XzQORTmVkFPje--) {
        continue;
    }

    return FjhWm;
}

void oZzQWu::liyzUe(int KZfpyWu, double wiHpjspZ)
{
    string VwTzEPK = string("sbHmpvdbYMcOPwGgnIFWHTYPbywYEtodekeNfycBKItlPXoJwQLBjIPLMlbySAfIFEtMqXCathrkHtfkkYWOOFqeYtyAgLRNueuIlyLINAxLaMOSEsJbDKRZeKaVyTqVnEXjrWZRgKkfTi");
    int EFGWqgJFs = -979089695;
    int WxlrCdzcFq = -813270915;
    int SemJbPPFAzB = -1487157559;

    for (int hpGmsSG = 408992083; hpGmsSG > 0; hpGmsSG--) {
        WxlrCdzcFq -= WxlrCdzcFq;
        EFGWqgJFs += WxlrCdzcFq;
    }
}

void oZzQWu::nyJYJT(bool lNIHrSxUkXhfL, string vAgHIGdISb, bool wNjOutnaXTVMoZI, int MhiJCdRdOaFJGZ, int WKeXtkpSgUoia)
{
    string NddajX = string("oxbxwYFVAldUvWWDkqnZrLveamnKPdzmkkMAySMfjQIbktasAGhccOyBpQyRTVvaiDoswkLvrttCPpZZpbTLzFUH");
    int FAizEDEXkDn = -1217330357;
    bool TnCYOHfJjeByfGw = true;
    double cDDmLWI = -835516.5343207173;
    string HpVcFWkBrTtTXGNV = string("skugcEcCTDuguWIvIpDqKQWIpWYZEgpgTuoOTOpOmeYcjNmEQXhKCbrkGqaDHrMctAgMMMkfMajouulZsElimzyHHhXWwzlEtzcAbyNIJAbNcueOEdZYLlGRCbAswDUOVeSvBNOeUWAvPeehaRkYNiDNnYtVLpyYMbLevWLMkuRyxlkFVeWuUCjTfWddYMCRrMvmgnNJWPwobbAQ");
    string ROMYEyA = string("kbqOgYzenzQKqrGMXXcGhDMSljUPfyRRdPmTOY");
    bool iQNqhNxK = true;

    for (int TZmAOXGuzjnSw = 429319146; TZmAOXGuzjnSw > 0; TZmAOXGuzjnSw--) {
        continue;
    }

    for (int nOhmH = 1229793280; nOhmH > 0; nOhmH--) {
        TnCYOHfJjeByfGw = iQNqhNxK;
        MhiJCdRdOaFJGZ -= MhiJCdRdOaFJGZ;
    }
}

string oZzQWu::ZJJbXH(bool nDaJxtDsI, double XsUmKcMUKpvWMNd, int SAtBZGwQgKAjwWGr, string vHNubfKOVmgax)
{
    bool GErZzjWtrSexeCS = true;
    bool EfjmX = false;

    if (vHNubfKOVmgax <= string("GCDDlNdusQuJMzUGSgLUbZvZGnBnpinycoGVorDLVgTGSNDtGhWxbBCFiUgGaKNHBNrFuXDXdPlUxVjpVmpEhOeAQmfXgZTxwNyUebTFSsjht")) {
        for (int HPfOkhsyFRkt = 350250190; HPfOkhsyFRkt > 0; HPfOkhsyFRkt--) {
            EfjmX = ! GErZzjWtrSexeCS;
            GErZzjWtrSexeCS = ! EfjmX;
            SAtBZGwQgKAjwWGr += SAtBZGwQgKAjwWGr;
            nDaJxtDsI = nDaJxtDsI;
        }
    }

    if (EfjmX != false) {
        for (int nOgHtIBAT = 2002992979; nOgHtIBAT > 0; nOgHtIBAT--) {
            continue;
        }
    }

    for (int VTXYQu = 1080892741; VTXYQu > 0; VTXYQu--) {
        EfjmX = EfjmX;
    }

    return vHNubfKOVmgax;
}

int oZzQWu::RuuCEd(string JMnxWoWCoYm, bool TIzbtJufmYn, double tfxSpQEODGEhcd, string gAHzexaPE, int VrPKR)
{
    int jhDspxa = 859469886;
    int trmECp = -1294145106;
    double noEkNt = -127453.56985696995;
    int XHeIffG = 1264481800;
    int qAiUo = 8785940;
    double EhvDBcRDnKZT = -639788.2070537938;
    string TrOxzTaEef = string("xdKQazMVKTzJDwLJthXfGApDlEJoCENQponOGjjcDXolJwmakHNCUkRHphrIxZhJuMZXjBJbhWHiumAPxJFCayzubSnrjkuzpuQkVITlxFZqGPiKgVjDfgbqhxldPwMvdZSqTfpHSlUGfdEJeufmXmyhSwepMKOzhgEOsfkDadXTPuVToyEiLpNdFqOMbGATeQSXCHOPsuXduts");

    if (VrPKR != 656565498) {
        for (int jAjsMfJrHFlcT = 1837925553; jAjsMfJrHFlcT > 0; jAjsMfJrHFlcT--) {
            trmECp -= XHeIffG;
        }
    }

    for (int XmixdVGPdDiWCifg = 1706259590; XmixdVGPdDiWCifg > 0; XmixdVGPdDiWCifg--) {
        gAHzexaPE = TrOxzTaEef;
    }

    for (int ILEpZiTabqJUbzg = 1466656518; ILEpZiTabqJUbzg > 0; ILEpZiTabqJUbzg--) {
        jhDspxa += trmECp;
        JMnxWoWCoYm += gAHzexaPE;
    }

    if (JMnxWoWCoYm <= string("kshIgWvEKeoivtmDbouOxTSaiAKAeNGfYgvrkWBedneUDqDHsgHeFaaQPEUPmYsTNvaIMeVOzLoQAtpSxmmYesHVTqyGBZmiNCTfbemgLpRRIrMwPCAGkPyvgPXUoCKzxJYblZGpARjCfDOaeZyWdtplOxCJXvYvxjdBzMNDiPfLybfWbBjReqlkf")) {
        for (int zBtJNxaZc = 786745848; zBtJNxaZc > 0; zBtJNxaZc--) {
            XHeIffG /= trmECp;
        }
    }

    if (XHeIffG < 859469886) {
        for (int lFbskmTLI = 1664456501; lFbskmTLI > 0; lFbskmTLI--) {
            jhDspxa /= jhDspxa;
        }
    }

    return qAiUo;
}

void oZzQWu::OQDUmo()
{
    double UqPgRyB = 552161.8574069183;
    double MRHqAsTRvYv = -342646.8132066692;
    double SvYMeYmlafqze = 585188.9819496775;
}

int oZzQWu::yAmNhGsasX(bool rXzjf, string XuXbzDjOFBLReyE)
{
    bool jRpmrfkD = false;
    string xjNayrdLhSdDOM = string("OMjfgMIikHeJmKVODTltyHxnYuftcHsRhMgDeIrBBKtIRKCaJLgIXvPaIgBGZsVSVQPbjdyZTeENgORgnGHsCWNJEdicVfmItcdDsksjNMwjXNOvwWapIHJACKJAinvpqsKkOxHyRzYoxepZIyZTrM");
    bool BBqlv = false;
    double AyACEzHGvxdLwQ = -771126.6811751162;

    for (int KnsuL = 1423226412; KnsuL > 0; KnsuL--) {
        xjNayrdLhSdDOM = xjNayrdLhSdDOM;
    }

    for (int WSsvN = 1155822814; WSsvN > 0; WSsvN--) {
        xjNayrdLhSdDOM += XuXbzDjOFBLReyE;
        rXzjf = ! rXzjf;
        AyACEzHGvxdLwQ = AyACEzHGvxdLwQ;
    }

    for (int YKanEyHHVmjnh = 839787203; YKanEyHHVmjnh > 0; YKanEyHHVmjnh--) {
        XuXbzDjOFBLReyE = XuXbzDjOFBLReyE;
        xjNayrdLhSdDOM = xjNayrdLhSdDOM;
    }

    if (jRpmrfkD != false) {
        for (int rFaViX = 167819571; rFaViX > 0; rFaViX--) {
            BBqlv = rXzjf;
            rXzjf = ! BBqlv;
        }
    }

    return 667338555;
}

int oZzQWu::vdUNXBqT(string ZrYjTNlUEPMYr, bool CItumWwyU, int LzjNGFTnmKLo, int woCWylsXUQSgmD)
{
    int fMXXHVWYXZKoBAi = -708055858;
    string JKISdW = string("zIDhIHJKpNdQvrsvEcfOjqBdOYLWBDuCgOsnXlCcjXemzqAXMztFGPVuRw");
    string dCNqza = string("BlakuluMlUwGlpskIiTAvsNKYXBBoMkedahsruNZEIEeaGjIHAcazRHRWaYVFXXjwdezDzygQmWHJNFWpWgoHFVCjUfDPKdERPYqFTytBaJvdvGvMdihlolqQKsRMtmnaMyGWUOdoKPJrQiyKCXUSsQRyZEkjzMYXRfoZAuEnQOcNyXDBX");
    double vALLysOshMAos = 130392.26753346222;
    int hKVotuiYxGiEQeS = 1837309144;
    int OCcrPPhDSXruhKC = 403389840;
    int dUTSUn = 579624919;

    for (int PWeSEcuxuwz = 1007355474; PWeSEcuxuwz > 0; PWeSEcuxuwz--) {
        OCcrPPhDSXruhKC *= dUTSUn;
        woCWylsXUQSgmD *= LzjNGFTnmKLo;
        LzjNGFTnmKLo *= OCcrPPhDSXruhKC;
        OCcrPPhDSXruhKC -= LzjNGFTnmKLo;
        ZrYjTNlUEPMYr += ZrYjTNlUEPMYr;
    }

    for (int zQBdBKqojFNcP = 180050704; zQBdBKqojFNcP > 0; zQBdBKqojFNcP--) {
        dUTSUn = dUTSUn;
        fMXXHVWYXZKoBAi -= OCcrPPhDSXruhKC;
    }

    if (dUTSUn >= 579624919) {
        for (int eAluYBRw = 2110031834; eAluYBRw > 0; eAluYBRw--) {
            fMXXHVWYXZKoBAi = woCWylsXUQSgmD;
            fMXXHVWYXZKoBAi = dUTSUn;
            hKVotuiYxGiEQeS = hKVotuiYxGiEQeS;
            hKVotuiYxGiEQeS *= fMXXHVWYXZKoBAi;
        }
    }

    if (ZrYjTNlUEPMYr >= string("BlakuluMlUwGlpskIiTAvsNKYXBBoMkedahsruNZEIEeaGjIHAcazRHRWaYVFXXjwdezDzygQmWHJNFWpWgoHFVCjUfDPKdERPYqFTytBaJvdvGvMdihlolqQKsRMtmnaMyGWUOdoKPJrQiyKCXUSsQRyZEkjzMYXRfoZAuEnQOcNyXDBX")) {
        for (int xKmZrWKCXIjItfDZ = 897662538; xKmZrWKCXIjItfDZ > 0; xKmZrWKCXIjItfDZ--) {
            CItumWwyU = ! CItumWwyU;
            fMXXHVWYXZKoBAi *= dUTSUn;
            dUTSUn += woCWylsXUQSgmD;
        }
    }

    return dUTSUn;
}

string oZzQWu::VZKfsIkngYSJs(double EAmnkOVF, int EJkWLyWODSVT, int YQLvriXvEqnqlWI)
{
    bool uxPgfpj = true;
    bool JctzHYb = false;
    double XwjCr = 274231.3402262405;
    bool sVHwZO = false;
    bool KdosDpaFjFxhz = true;
    double BmJVvgYZerEPc = -343653.58711251494;

    for (int JYveMSHjxlwb = 1290207371; JYveMSHjxlwb > 0; JYveMSHjxlwb--) {
        KdosDpaFjFxhz = uxPgfpj;
    }

    return string("WYCpgaVaXvKGXiCKroB");
}

oZzQWu::oZzQWu()
{
    this->hMFoicypiKfLzMsv(true, 1649090156, false);
    this->Wrhejpawfgvx(false, -125300728, -110047.52268860607);
    this->bLzplVMX(23508457, string("PYuFrKtTovfMaJYvICbaUYIpjURUUmRvDSNvAaaxYKBiXREMPxsQDeBGTInkHJqhYzsMxrVImryAhirWpxhEbGarVuPBItxhcotbHSFPS"), -222646.47916266802);
    this->BqOsA(-19722.79174325251, -145374.95884371013, 221250.06759383428, -377562.4142158203, -1188898631);
    this->FqjRIQNjU(string("VwlDGrldmgxwQJpUgQvfEKuqbwLFxLDSGDQaommnVcLCuZeWUrbzhGujgUrTzByZcOLdQPijNTCccSrrXcrDfnfLCMhAQNKIOKheuZJbfxxubMkBswVMfutaXAuLgDmEhuSUdHYfggtZwcPgEyIQEAGjkHQyntQqlBmydyzCuzpbjSLZTLuEXHSYEqxUfRihkmxyvPwrjNXfqjuzyWRYYmmCEVAkHPebBnidrLZFzsGRgGQGwtDg"), false, -39384109, -615963.8068130517, string("EWFWuBMQhiIIsOdHYzCXmYeomHdVOOdjiWIsyqdgXeptmKoMyxxXjofIjiaJPEatLdhapSCKGhCysnoBfoXqpnwTpAcdxfBrnAzSunflXYCsAoJbznNMTNFNKLYcXOnp"));
    this->liyzUe(-1905570579, -22240.37961364551);
    this->nyJYJT(false, string("QLdWmWJSTdHnVdytJZWKftAxszaWvCsbhUXNlRcoZQTvCJCvwkBXengBYkRIduQWrMzXcsRhwhgaLoYxDWqMpVwNaxPXhNSvoGrbDldFhiaciVeiTWdnDeiCbqxqbptqHkDGThJPGvjrPJUvFUGRAjiMgOXzSiSpKOMrTVYewZTRfWvixIpJkplPVcsWyNDTbqOvKuyRTkgIBBAjeIdPLmpdYJCAHqWJapumCKhQAvublptCCeAddzDYRXl"), false, 1305436434, 121262862);
    this->ZJJbXH(false, -461084.63360498525, 1642592769, string("GCDDlNdusQuJMzUGSgLUbZvZGnBnpinycoGVorDLVgTGSNDtGhWxbBCFiUgGaKNHBNrFuXDXdPlUxVjpVmpEhOeAQmfXgZTxwNyUebTFSsjht"));
    this->RuuCEd(string("kshIgWvEKeoivtmDbouOxTSaiAKAeNGfYgvrkWBedneUDqDHsgHeFaaQPEUPmYsTNvaIMeVOzLoQAtpSxmmYesHVTqyGBZmiNCTfbemgLpRRIrMwPCAGkPyvgPXUoCKzxJYblZGpARjCfDOaeZyWdtplOxCJXvYvxjdBzMNDiPfLybfWbBjReqlkf"), false, 89623.19920708296, string("droEYOVYRYFzvKAlrYxHWlEMofcrLEqNhRagixiWBYjmJwxzzUCEfiQFmxLYDyoewQJhrHTcNkKhMfxvKzdNSESfegTGgTScOfpajmrLdCbglZjpslDcndLuMZWSOLpFaCXwOLEythRGvlvPZhwgJHWczAztaEXPYcKNYUvJpYJbJNajBnJRBdnbTwddjOsbnLqoqmBXdeyIjrhjepBASAlUhNbhDqtvcMLCyRYUAEvfflNPPBmIt"), 656565498);
    this->OQDUmo();
    this->yAmNhGsasX(false, string("BRynQknwGJwGLnAAVFTLwrsxIzyyXsZYFiSjhoghLhzlyBKFLsXZZYCphCtilOSrreysZstnOqvmnXsYkWWJenWgpCOnuMYdXBMlBeSWCTe"));
    this->vdUNXBqT(string("hHVctOKLaOGJnTrvAmUttMfYfMDekBAWrqZHSxncSGKVSoJiRuDCpypTiGirniHGPWSZxKPiIvekHuaFqvpbQxGhdqIQSetxtCTdgnVWpaYkTQCQwbUCBFZhNMxAXqoojTMXJtzbNhYdqHPPvOGKBWrZZahbOFhRdIafGfvtQwrbgbCfOPcFaNktKNXVfzWGwCYRjrSFwoOHxWDMBjdPYfYTPeroXwWXTISzMOKsUfRZTcUo"), false, -1528117826, -1394427826);
    this->VZKfsIkngYSJs(195980.86574421584, -86389996, 1090619803);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qtObz
{
public:
    int RhCuseC;
    string GuWpuxzMbmsm;
    int FXllwLAoz;
    bool voJLbVPiGfL;
    bool FbdXsMXOeLOkxOVK;

    qtObz();
    string DMhue(string VEqrazgkLVJ, double lqJDepNTeN, string eDhXcz, double rkMzjY);
    int xzPLTyWYY(int ECBNZqm, double lmkgqGqyg);
    void zCIZzdAZlmgCjP(bool lcBIfFWiJoEWqT);
    void ImBMI(bool nJDaOKaIYe, bool SAQaUlarMNAXN);
protected:
    bool eaajjxNFiP;
    string LjRrg;
    string NntFVxtFPMsB;
    bool oBVTaoqmNlb;
    double vlDlYVwfSysj;

private:
    string hWfluZbKOEQWYOEe;
    string DDrODja;
    bool qfHEg;
    int rtOWCsfPapgwbjio;

    bool FXDPXLVjTCEL(bool YuIAsRJBWhK, string CSWSj, string viXaovhpveVltQK, double CHcpqFZ, int pNakEyP);
};

string qtObz::DMhue(string VEqrazgkLVJ, double lqJDepNTeN, string eDhXcz, double rkMzjY)
{
    int DJnYSwuRVgqwq = 540974063;
    int BBrHjVTsEGzPm = -22702051;
    string bJvMmNcJCDUwo = string("YsZoDnGmuhXOjdhfmbGTiDiwaoQGZpEfXoQYCIkvRcehDTwtzwftSONBrapgjfAwvWnIbCJLSBgcGXkxdhXyCowJCgoKbOAzQNfkYEqNjunsxRkQComipBruIqVpUcJgdovTwtlikBLXtonSzGvvZjpMRNggTiqcUcyhYSKQIDOgrRjyuTeqllNbEMV");
    bool MtqHAQGkqzbis = true;
    bool ZJHSKacihYIgoqcU = true;
    bool DiJSUtYhTbqcS = true;
    bool XvRts = false;
    double xWZkUW = 218486.9520900047;
    int sPSBD = 1680879339;

    if (MtqHAQGkqzbis != true) {
        for (int xCFWJWNEqLB = 1814194625; xCFWJWNEqLB > 0; xCFWJWNEqLB--) {
            rkMzjY = xWZkUW;
        }
    }

    if (MtqHAQGkqzbis == true) {
        for (int UmwWvJeVYlexKVIF = 524635380; UmwWvJeVYlexKVIF > 0; UmwWvJeVYlexKVIF--) {
            ZJHSKacihYIgoqcU = DiJSUtYhTbqcS;
        }
    }

    if (ZJHSKacihYIgoqcU == true) {
        for (int YoQlewpZnb = 1050593086; YoQlewpZnb > 0; YoQlewpZnb--) {
            eDhXcz = bJvMmNcJCDUwo;
            eDhXcz += eDhXcz;
        }
    }

    return bJvMmNcJCDUwo;
}

int qtObz::xzPLTyWYY(int ECBNZqm, double lmkgqGqyg)
{
    int Gnmljg = 953331530;
    bool LgzAEWaOYnMzI = false;
    int KjSwGUHeKlIhINm = 2122571492;

    if (LgzAEWaOYnMzI != false) {
        for (int WlqNhZCdNL = 262018924; WlqNhZCdNL > 0; WlqNhZCdNL--) {
            continue;
        }
    }

    if (ECBNZqm <= 953331530) {
        for (int hoVSRRHcMcKxP = 261323366; hoVSRRHcMcKxP > 0; hoVSRRHcMcKxP--) {
            LgzAEWaOYnMzI = LgzAEWaOYnMzI;
            KjSwGUHeKlIhINm += KjSwGUHeKlIhINm;
            KjSwGUHeKlIhINm += KjSwGUHeKlIhINm;
        }
    }

    for (int NDYaU = 492231294; NDYaU > 0; NDYaU--) {
        LgzAEWaOYnMzI = ! LgzAEWaOYnMzI;
        LgzAEWaOYnMzI = LgzAEWaOYnMzI;
    }

    for (int BTJirQjRg = 1946366945; BTJirQjRg > 0; BTJirQjRg--) {
        continue;
    }

    return KjSwGUHeKlIhINm;
}

void qtObz::zCIZzdAZlmgCjP(bool lcBIfFWiJoEWqT)
{
    bool WyhcUtaiXQcbGogs = false;
    int BMqWB = -1909848913;
    int iEYSeGSlThIp = 285044171;
    double jUbpyzuygwcTQXCu = -314217.905331559;
    int VeuvCyToPypc = -117217220;
    string OKBGDCfq = string("SOWlaRwwxqFKoekKEcYqVFcEJfByzSUMYtByVxJelBhihiwdnMFttAkPfIQJCptmrudwfCOLZXFlYfvBWSFdcHdcRIFHIoqLDIScLqrVQRfuguqORObYeeNBSErKyvJ");
    int noBJH = 902067466;
    double zuCvYwhTgAcVXvNK = -635640.5551213127;
    int yUVEPzlTCVmRuzc = -792947703;

    for (int ymEGgttOebU = 992290027; ymEGgttOebU > 0; ymEGgttOebU--) {
        iEYSeGSlThIp = yUVEPzlTCVmRuzc;
        VeuvCyToPypc = noBJH;
        noBJH *= iEYSeGSlThIp;
    }
}

void qtObz::ImBMI(bool nJDaOKaIYe, bool SAQaUlarMNAXN)
{
    int QBjJDMeBLdD = 796052089;
    bool NweVtqCH = true;
    bool aSFZIkCQRSSQWlxF = false;

    if (aSFZIkCQRSSQWlxF != true) {
        for (int rXVgZ = 174914555; rXVgZ > 0; rXVgZ--) {
            NweVtqCH = ! SAQaUlarMNAXN;
            SAQaUlarMNAXN = SAQaUlarMNAXN;
        }
    }
}

bool qtObz::FXDPXLVjTCEL(bool YuIAsRJBWhK, string CSWSj, string viXaovhpveVltQK, double CHcpqFZ, int pNakEyP)
{
    string jFipdeDfr = string("sFKpHUsgZrIJlcBmFSOJKwBaZgReGejfYnamsnNzygIsYIjqNikVZQNsnxZDhzZyQDmMceHsGaMdczLZqIcRFEWouNazTcykgMHifYJcyhRFnJRIyqZNcwPnCafSHAwIMDdGgKIOerRfHZEwKGfBvfGjcQP");
    string kwqLkgNRdXv = string("IyHpVEZYDaCteZiPGLLYPwMgrWMiWHPgEZIjJuSOD");
    double jYoxLtvbXvH = 743757.975469069;
    int GQyrl = -957055599;
    string QMcwmpfPENfvQ = string("cIbBoAPQeHRsOvSLMxLuLsMnjDDLvSiecsGBvSHBFDoVZNGxNvoQpMrSzisxUARhdcpsnnCLHacHoGDCoPEzqwjSOvPnZQbKbfZgoXglDrMvpRpzJcKgIwKUohuxGkKAHQSWVZgyqsdKOsmujsHtcyJPFLQHdAFlQieqpxVRQnfErTPWx");
    double UljZXsnNz = -906500.1100920717;

    for (int XOWZgnHa = 690930414; XOWZgnHa > 0; XOWZgnHa--) {
        continue;
    }

    return YuIAsRJBWhK;
}

qtObz::qtObz()
{
    this->DMhue(string("ZgVEtnnNcqQyHoJonulvGJaXUduImWJbUVEvROcYWJYxmlHicPGViOAPjWzghPbQJODsoOOSoQFTqsHbqHqAqYDrVemYJYQGGaOOThmIxcynpexrFHqeSHiEGLclS"), -870899.6961591333, string("dSHljfxtsIbCVaOrXklDzxIBeVMGJAFPLZREFaGViPUGDpnnCGXGyrXdpZixdeRlYlrKXUtQeAiQXpJszRNGjeIdNqAAqlcHLSeGiLDpgucCemNkAgAWnMuuAwmysKlfteGjnrxSWrOqcfQYuuBLPEXjzpEPUxSCXUyxtGEnbmVIdcEPDDLdrmoBdVlenQkjTjdFDJjxtFMwEqFTJfvbzCoKdjzbiZLoj"), -543107.5359260229);
    this->xzPLTyWYY(-486505527, -336962.9727340663);
    this->zCIZzdAZlmgCjP(false);
    this->ImBMI(true, true);
    this->FXDPXLVjTCEL(false, string("vSePJVJLrRXSvhmyxNWxrVuzcVuzcQXnBfkxXvaUlYLjteMrzcxmhooWmotLibIsixWEUzaCySjHpjXhmgeqFAFjWRApTlbnQBSsWDAUUhOAftMvdtxdPqWkenRWzBqzfGkgeNoZYKbhWbOxQIlxkTDyRfSRdFiEnUuvNCDKaeSzGBZcdXgvCfWmmwwqvMpfZvPVxwOqYtzdnrfDXSfRG"), string("xzaJxNkqwzxODQnsIQYGOCroyzRqCKWYZBeIyCXHZHbHPqKaJVtFxYMsWJTESOrskZIKGjqJFZzXJbdCUDeBAVRicHXUjmwytNhppQfnSTlrpfaiXspEtAUNdfooUNwpEuGBgHcrMUxaIKAaqFXAPyi"), 1036272.6121744161, 1810766093);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hEmSUlHL
{
public:
    int gmydHD;
    bool SfTjDdBYtnyOx;
    bool ZfElKyKEir;

    hEmSUlHL();
    int ROjCYCma(int foyXsfWWVJHkISf, double zbNmxiRs, int llFHdDaZrLNVZf, double MpQfmTTlyZEe, bool HsyAAHwVWf);
    int yjWqbke(bool KYXNiouDDsgX, bool wSRxKtkMbygPX, int nYoQnirOxH, int VdLtCjlK, double JLOzLbKbrXfi);
    bool pnAIfTsUErDMIa(bool DVHumKXles, int YJqqAxhHOGh);
    double yNwuzjVRsWCvfI(int fVzvQTFOGDmGFqPE, string QlKPZisRBX, string fcmvaIdTneR, double blZDG);
    bool WuYNqtCmtDQT();
    void xQtPCdHqTCs(double mhHOFfpIzQ);
protected:
    string ucwhXLjfcJvVOKyT;
    string FRNKG;
    double vECoBF;
    string aiiVjQF;

    bool JnDwKYws(bool NFDYDfi, bool iQFbDLmvFUFlHlF, double vjehHg, double jCxEoDKN, string jsZhlHmY);
    bool ZpuwcCuiPIWa(int EaJTwbeOvogYM, double RLcrOfybSI);
    double NZWeC(int SaBKU, int wxsVvXWsnBZ, string ycTznxRG, int EeUjkgLi, double ArEEvdNNZXRWpCwq);
    int yXiEgIbGHasM(string lwDJHDOCbBpDgL, bool YtBSz, double exWpMaABtxGK, double gUJsdOTcs, bool YEodpUoXUvGy);
    bool nwwRNlsv(string jptIbOfFx);
private:
    bool VIDSFkMWXzPi;
    string qJyKSqQiJbpaI;
    double LuHKepvX;
    double rkVPCFadsXlU;
    double IMuCfApKPMhSNQ;

    string eYdIjONCB(bool beVSeGFDqKNsAHHo, string iMfbSu);
    int AUNIOrLWjeo(string QUsTy, int bDiHvPjHRDii);
    bool qgMSFi(double MJzUp, double uzVxy, double hgTuqx, int UDSChZE);
    string kTDjUegQfki(bool iVPJM, string AqMBYNCtTS, int GxOHeKQK, string gQCBfiKBTHUowCc);
    bool JwaRCQYTPMwQ(string qairiiOjeTulP, bool FBajByFesCrG, int niaCFEqftqgz, double btwoNZJcJMqncnMH, string wuLbIpZIdW);
};

int hEmSUlHL::ROjCYCma(int foyXsfWWVJHkISf, double zbNmxiRs, int llFHdDaZrLNVZf, double MpQfmTTlyZEe, bool HsyAAHwVWf)
{
    int pNgXjHpQILDDPUYF = 78203301;
    int narbHigTIcPl = -73268048;
    double KXtQgK = 912422.1493094199;
    string GIThMnnAIlR = string("WCpzEUufRPpCQCXiLeDpWdcxRHyUNBbjGzJpokXLEwfHcbFEJrlEBtOZOlDdQRaVdMebepHKPvyIGbQkaMbZKQGQeHWpmHNoeSEceKxGKhpgWjTrAONN");
    int lpXRfuQ = 64279303;
    int cdeahWZZFKkUbKw = 2139443274;
    bool xhAgiVObszIlDZ = true;

    for (int DnTGWd = 1489340497; DnTGWd > 0; DnTGWd--) {
        KXtQgK -= zbNmxiRs;
        foyXsfWWVJHkISf = foyXsfWWVJHkISf;
        lpXRfuQ /= pNgXjHpQILDDPUYF;
        foyXsfWWVJHkISf /= llFHdDaZrLNVZf;
    }

    return cdeahWZZFKkUbKw;
}

int hEmSUlHL::yjWqbke(bool KYXNiouDDsgX, bool wSRxKtkMbygPX, int nYoQnirOxH, int VdLtCjlK, double JLOzLbKbrXfi)
{
    int mmsvE = 1648771504;
    double EFZoSufIGsZ = -1040584.5915705656;
    string vqztLarCdCIflliG = string("RmFBYpETaxEmfaRWENfNkdkAdrZaENmqnaIiqMOoCsSYOiPeN");
    int kIqtIRTfWH = -968477370;
    double QDJpMnTPXsatH = 771637.8313477224;
    string cnlvgksp = string("abOkUQgSbUeRCjmWIpnZRCSXlYIzcAtDqxIxRfBrgdXKRCXQSdnvYExIXwHRKA");
    string vSsmWFof = string("dZYuGvZdkQYopyJBytuOsMvQvKAhuGuTVtCqnFpOHyMOnzzcoTpTHBOOmFxdlFByFWTMXuXduwCNJpxYvFiTvNHsbsoEYUuPwYKmYTepWCPMYvGYalsSPWLghlnbMDjEsYyyyQwaVglQlYQGTGZikdTIw");
    string jgHam = string("ShfbCOxCwEyDIEIKsiLfHqgOEQypSChDtwYAlczCSJNAVoWaRRICYVmvSkkUkklYWhObomBvodyJYlfFJYanwrttPoGGAzxGIZkNqlVCDONrJwKquhmgKDYYJLmgmvxWyXbOyGoQAmnsjyplSofacPGpjHdOghxLNTdYaGYaZFW");

    for (int iIvMGPhuKuIXHjj = 908587464; iIvMGPhuKuIXHjj > 0; iIvMGPhuKuIXHjj--) {
        continue;
    }

    for (int tAVHlNSh = 1184051736; tAVHlNSh > 0; tAVHlNSh--) {
        continue;
    }

    return kIqtIRTfWH;
}

bool hEmSUlHL::pnAIfTsUErDMIa(bool DVHumKXles, int YJqqAxhHOGh)
{
    string iBQyrifquhob = string("lBUtWEibCFLAFkWdfnywmZcWVjKtyukqhUzqkasetlcOGuJYelVSSFqNBAzBvjiGhf");
    double PDkjaw = 908986.5611032194;
    string DqDuaM = string("ZwzbFkFqzTUmBoiUZllLtVUsVauspizihjPaajiRjShlzSixaxeLjBRxdVcQUBtwdmWtybbepmNCvmbqfIc");
    bool XmrQsWIPX = true;
    bool mmsQPPTzhmdnL = true;
    int PNKbTQV = 1670370669;
    bool IJOmdDsttNLBP = false;
    bool ubQXHhEqP = true;
    double cBtzAgBpRVrQki = -538407.2835344838;

    for (int GWdVyuY = 1518981626; GWdVyuY > 0; GWdVyuY--) {
        XmrQsWIPX = IJOmdDsttNLBP;
        PNKbTQV = YJqqAxhHOGh;
        DVHumKXles = IJOmdDsttNLBP;
    }

    return ubQXHhEqP;
}

double hEmSUlHL::yNwuzjVRsWCvfI(int fVzvQTFOGDmGFqPE, string QlKPZisRBX, string fcmvaIdTneR, double blZDG)
{
    int zwoTwqQTONZx = -1309780584;
    double IChnVDmfwdarNtsA = -532479.0965767509;
    int BzUBUFwDZcCP = 787895100;
    bool BDeVnQt = true;
    double QyEQfNWNqj = -556097.7427180178;
    string PZdPaHYdgz = string("dWvKboSNjjOWyssdwHuJebKBxgfyGhDrPDorwejBdZBAPDwXYuWnQVHaLUmJ");
    bool UNOmKcDlBLhsYc = true;
    string QexGPHb = string("tXFRHeEGz");
    double HhpGwOlIBgEDD = -247665.07727383508;
    double GMRNJNxhcOKmaK = 378923.1669092652;

    for (int mYbCRh = 179166842; mYbCRh > 0; mYbCRh--) {
        HhpGwOlIBgEDD -= IChnVDmfwdarNtsA;
        PZdPaHYdgz += PZdPaHYdgz;
    }

    for (int EKKZVhHOcdMc = 217153482; EKKZVhHOcdMc > 0; EKKZVhHOcdMc--) {
        continue;
    }

    for (int MwlzfFbIGsBOw = 169311528; MwlzfFbIGsBOw > 0; MwlzfFbIGsBOw--) {
        QyEQfNWNqj -= IChnVDmfwdarNtsA;
        zwoTwqQTONZx *= zwoTwqQTONZx;
    }

    for (int kEzZyqeV = 1645600833; kEzZyqeV > 0; kEzZyqeV--) {
        PZdPaHYdgz += QlKPZisRBX;
    }

    return GMRNJNxhcOKmaK;
}

bool hEmSUlHL::WuYNqtCmtDQT()
{
    string BpNexgUAgKFo = string("oFlutpTVnRMrStUuESWlhgkiJMJKOotKwNuStUZZjqDBvMvnQDEjSUekwhLNqiyhZZRYbIyp");
    int JuoDn = -1784652551;
    string xdWKKHeMs = string("rxNxOrGVwmRjXaQSHVwzxNzAPpIUjdroaFTdVTjLOelXUDYtcUfZrqLNmvuZTAWgDgvNvIbwAVjUyXiWelusbMkokTRvuuKMMGXHpijmIJofnUNZSfNritOxOTvbJuh");
    double oWAVkucL = -85280.7459519041;
    double tNueVQRlNiDzWzx = -632588.6039127616;
    string MqsMQUWuqaUVoNv = string("bnBiKNqPJkckaYoGgFVGUOTqQpWyjRNVXFmNRLYiZVPHawvvkiAukNbPzcheJLsyayjZldGhkHARlIwPTorTGhilpEciiQnxfXJHAdrIKpATXXAnevfnqKUodZyPAeQOvtUqGDm");

    for (int KvfiX = 595933590; KvfiX > 0; KvfiX--) {
        BpNexgUAgKFo += xdWKKHeMs;
        BpNexgUAgKFo += MqsMQUWuqaUVoNv;
    }

    for (int LseuSUfFEYZ = 281400115; LseuSUfFEYZ > 0; LseuSUfFEYZ--) {
        MqsMQUWuqaUVoNv = MqsMQUWuqaUVoNv;
        tNueVQRlNiDzWzx /= oWAVkucL;
    }

    for (int iUYsi = 1747940739; iUYsi > 0; iUYsi--) {
        BpNexgUAgKFo = BpNexgUAgKFo;
        JuoDn /= JuoDn;
        BpNexgUAgKFo += BpNexgUAgKFo;
    }

    for (int DatJBfgyFMxZB = 1501756507; DatJBfgyFMxZB > 0; DatJBfgyFMxZB--) {
        tNueVQRlNiDzWzx -= tNueVQRlNiDzWzx;
        MqsMQUWuqaUVoNv += MqsMQUWuqaUVoNv;
    }

    return true;
}

void hEmSUlHL::xQtPCdHqTCs(double mhHOFfpIzQ)
{
    string CQPtGFwCwfRw = string("xfjGwtnqMmAELcegvmYmQvKGxNzxSArKhhnGKHxOgOwhtdyNqhNQrtcJGfIEkxaDRfGCbUmMXWvXraMOfEecyWmqACUnujbVKymDNyQsguEdZuAfLoieezbaYkMcRvofNGGfpbUpwnkkgqYoLRjztrTGWKlvNxBGoRMNVtLNQuRdirIZhCtMmIkaLKYkHCjDPZvfmR");

    for (int FuAMkRVmUzzx = 1083087762; FuAMkRVmUzzx > 0; FuAMkRVmUzzx--) {
        mhHOFfpIzQ *= mhHOFfpIzQ;
        mhHOFfpIzQ = mhHOFfpIzQ;
        CQPtGFwCwfRw += CQPtGFwCwfRw;
        CQPtGFwCwfRw += CQPtGFwCwfRw;
        mhHOFfpIzQ *= mhHOFfpIzQ;
        mhHOFfpIzQ = mhHOFfpIzQ;
    }
}

bool hEmSUlHL::JnDwKYws(bool NFDYDfi, bool iQFbDLmvFUFlHlF, double vjehHg, double jCxEoDKN, string jsZhlHmY)
{
    int wXxQlMc = 1215202737;
    string IrAZObiVDOsILXDE = string("CyBSYxcmmNKZApJRwmoksuUoEWpPEOYKwBwFqpDFWyDovQbwSMuDHdipXuzVAtHxzhXUsyBJFAekoWtOLJCtcZqvFwxmwCYJ");
    int FRvmKouOVHXc = -148255633;
    double JniwfM = 412218.76134792424;
    string sZBdKA = string("brErgcgqSSjNkovDKEIlDLbiSUYstVOENjNZmXsfTcpWnZcvXmcmQPmykcfZPJxrTmyvwpzFlLxlBdYzYbWRAfMBnuOEaFaVnlsSgcJFhwSsZQDzVhPphyHHGMwSrxyzLiafNIOdnbCaHoBmtloDZaiHAGbKKOY");
    int SfuNnkth = -168048838;
    int ZqjZmwIGimLqCgyL = 928013635;

    for (int DmsWMzEaBFeDjYaz = 1661948858; DmsWMzEaBFeDjYaz > 0; DmsWMzEaBFeDjYaz--) {
        iQFbDLmvFUFlHlF = NFDYDfi;
        IrAZObiVDOsILXDE = jsZhlHmY;
        ZqjZmwIGimLqCgyL -= ZqjZmwIGimLqCgyL;
        ZqjZmwIGimLqCgyL += SfuNnkth;
        SfuNnkth /= wXxQlMc;
    }

    return iQFbDLmvFUFlHlF;
}

bool hEmSUlHL::ZpuwcCuiPIWa(int EaJTwbeOvogYM, double RLcrOfybSI)
{
    int rzjrQMyDBhQauLNP = -1434128382;
    double pgRwskBglxUNLnN = 876170.8550806218;
    bool JdfGUWdENuGT = true;
    bool EcSkIlAJMX = false;
    bool YmJFVaXFYZdtwP = false;
    string BwFCvg = string("oaXYUhlmpcSbVcOfgBikeqSyRiHfjKYUdhkYNSvDaQDpCGjgGxMETNjiYSEkkMjTNacFotKxWGCqhaxKUronMeWyJFAAUxFlkoRUbkBXcVXoyYkYXLMAdtpTOZtBupDzgPsQDbPGbDTCmcxuAEiFDOvoVLapKLpSNYePklCRzUM");
    int GEzJOSjGX = 1376967808;
    int VAxLMANTmVy = -1225117707;
    bool gYILDpGQgLMI = false;

    for (int KWwXYVz = 946694481; KWwXYVz > 0; KWwXYVz--) {
        EcSkIlAJMX = JdfGUWdENuGT;
    }

    return gYILDpGQgLMI;
}

double hEmSUlHL::NZWeC(int SaBKU, int wxsVvXWsnBZ, string ycTznxRG, int EeUjkgLi, double ArEEvdNNZXRWpCwq)
{
    int MIuTkTSzzLSvzS = 280123066;
    double desdAnLnRkgPTK = 461213.3096372047;

    for (int cAlABXZdVpOog = 1396669652; cAlABXZdVpOog > 0; cAlABXZdVpOog--) {
        continue;
    }

    for (int vHKBzJ = 1833976485; vHKBzJ > 0; vHKBzJ--) {
        ycTznxRG += ycTznxRG;
        desdAnLnRkgPTK += desdAnLnRkgPTK;
        wxsVvXWsnBZ *= wxsVvXWsnBZ;
        ArEEvdNNZXRWpCwq -= desdAnLnRkgPTK;
    }

    for (int JZwYFaG = 748731854; JZwYFaG > 0; JZwYFaG--) {
        desdAnLnRkgPTK += desdAnLnRkgPTK;
        wxsVvXWsnBZ = SaBKU;
    }

    for (int FxAkqzHK = 2087039821; FxAkqzHK > 0; FxAkqzHK--) {
        desdAnLnRkgPTK /= ArEEvdNNZXRWpCwq;
        EeUjkgLi += wxsVvXWsnBZ;
        wxsVvXWsnBZ = EeUjkgLi;
        MIuTkTSzzLSvzS /= MIuTkTSzzLSvzS;
    }

    for (int rMKkhcLSYYttbO = 1081724940; rMKkhcLSYYttbO > 0; rMKkhcLSYYttbO--) {
        ArEEvdNNZXRWpCwq = desdAnLnRkgPTK;
        EeUjkgLi = SaBKU;
        desdAnLnRkgPTK += ArEEvdNNZXRWpCwq;
        EeUjkgLi *= EeUjkgLi;
    }

    if (EeUjkgLi < -467278445) {
        for (int kOyPxJghPKK = 1488752721; kOyPxJghPKK > 0; kOyPxJghPKK--) {
            wxsVvXWsnBZ *= wxsVvXWsnBZ;
        }
    }

    return desdAnLnRkgPTK;
}

int hEmSUlHL::yXiEgIbGHasM(string lwDJHDOCbBpDgL, bool YtBSz, double exWpMaABtxGK, double gUJsdOTcs, bool YEodpUoXUvGy)
{
    bool TCfpIX = true;
    bool DLpVDLPZd = true;
    int mouKtkKAFgADyS = 870399559;
    bool XstiYqwoH = false;

    for (int BrxZOKFvE = 1485444942; BrxZOKFvE > 0; BrxZOKFvE--) {
        YtBSz = ! TCfpIX;
        XstiYqwoH = DLpVDLPZd;
        TCfpIX = ! DLpVDLPZd;
        TCfpIX = ! TCfpIX;
        gUJsdOTcs *= exWpMaABtxGK;
    }

    if (exWpMaABtxGK > 539983.4578195051) {
        for (int OVnEqWBpBHkGP = 1007145408; OVnEqWBpBHkGP > 0; OVnEqWBpBHkGP--) {
            DLpVDLPZd = ! DLpVDLPZd;
            YtBSz = ! YEodpUoXUvGy;
        }
    }

    for (int alIgJUhKB = 680918961; alIgJUhKB > 0; alIgJUhKB--) {
        continue;
    }

    return mouKtkKAFgADyS;
}

bool hEmSUlHL::nwwRNlsv(string jptIbOfFx)
{
    int mfulqqSKG = -781847817;
    string IgDQcieysse = string("UGlEolKjkMYBnQuhPZxJKnAtTzoNnI");
    double pSGgSbCH = -386870.518989669;

    for (int MyGrOjTPliRSVR = 258092003; MyGrOjTPliRSVR > 0; MyGrOjTPliRSVR--) {
        mfulqqSKG = mfulqqSKG;
    }

    return true;
}

string hEmSUlHL::eYdIjONCB(bool beVSeGFDqKNsAHHo, string iMfbSu)
{
    bool DveucLOaDkY = true;
    double cQFCqcJFtebyoJB = -967616.6312192463;
    int CJGEYBVBfQcLZfxv = -1399236132;
    int kdqtPf = -831457567;
    string wPcWdZlNVztc = string("mzRJfCILRNLiBKilLPwGLNxlCtLdeZRzPuHcpMEsGOcfZTQfgDbMNwqMDeSEDlYYsQrpfFfibvvqsXwJPJbcgCThRkxqfuCqaBwxKvpApDVtYByvINoMFzQLy");
    bool nsTrS = true;
    string IpfHaWJrHUni = string("PGCDrUPCWnxUPdfKFWuAzumnmPgwiskokjEtTvBCMSRxWRgvyILadTnXveIdlwAtSjZKXXtyiCgbwSwANabfdUZnoniAKTJzXDhtdBIvmOIWDENrhuDPugEWuLOfUXWcJAGBnlRQAXKBvHBcHEv");
    int VGlQVGkvBDCb = 829717837;

    for (int lVeFJB = 1138327269; lVeFJB > 0; lVeFJB--) {
        VGlQVGkvBDCb += CJGEYBVBfQcLZfxv;
        cQFCqcJFtebyoJB /= cQFCqcJFtebyoJB;
    }

    for (int igLkCGMX = 1582386152; igLkCGMX > 0; igLkCGMX--) {
        wPcWdZlNVztc = IpfHaWJrHUni;
        beVSeGFDqKNsAHHo = DveucLOaDkY;
    }

    if (iMfbSu < string("QOZpMmSlAnQdMcXySPodGcqFdXQikhyitPWkwGKQUPAypTgwPtljdNxkoxMbucwsbEPfiQZxquFEPWKsOZFulCjnxlQVFJNSLBEVSRCcqFMuKvJiQmnNLOXAExQTookNGitBBNXHdOtpeiTXTTqfOiLsZbauGDLdCvFYkBaFOLHZILKLMTqZKTzgpkVyfZT")) {
        for (int GFoMC = 1208771214; GFoMC > 0; GFoMC--) {
            continue;
        }
    }

    if (IpfHaWJrHUni >= string("mzRJfCILRNLiBKilLPwGLNxlCtLdeZRzPuHcpMEsGOcfZTQfgDbMNwqMDeSEDlYYsQrpfFfibvvqsXwJPJbcgCThRkxqfuCqaBwxKvpApDVtYByvINoMFzQLy")) {
        for (int wuEgbbSiSZ = 25765830; wuEgbbSiSZ > 0; wuEgbbSiSZ--) {
            CJGEYBVBfQcLZfxv -= VGlQVGkvBDCb;
        }
    }

    for (int tivJnXeVGlN = 743005330; tivJnXeVGlN > 0; tivJnXeVGlN--) {
        DveucLOaDkY = ! beVSeGFDqKNsAHHo;
        wPcWdZlNVztc = wPcWdZlNVztc;
    }

    return IpfHaWJrHUni;
}

int hEmSUlHL::AUNIOrLWjeo(string QUsTy, int bDiHvPjHRDii)
{
    bool bPFObAlYrr = true;
    string FhZdWbN = string("ajXCyWURJulXrsKqyiUiZRdlOtLdQPfsYoMYuIqfKOkFPVoapnGsETSJmUKPxTjFSNJXDuPXVPZxWeDfnXTzeFOUTKrVkeCBdEwlROYTgQfePIckHEHodGVmAtAvugqCUnohrUiYJbMUOCFiCIKTzIyVxTDZIKeAisNUGCWAgPlY");
    string uIjglO = string("yqcYoaYzvcgdhBDtODYjTyPLHjiZRYsgmdnazmaOexTMwMeGwhpnCIPqAfokWEfJSxISCppGJAESihBPjSilUHmzoeCBdMgP");
    string AizEjUP = string("cCffSKEgOvdATpLwbEQVADrMpHkjvuecNOodTBDbCQUKvBxLHtcNXIDqbevdROMdwzAhlIntFfhvFiauuCvwcqdcObjBeBTtFhIClZAuyWFhhXYzMGjaiswdemvdnaGweqExElFZoiCWDecSrkPL");

    for (int GcAXjzddlgL = 86987583; GcAXjzddlgL > 0; GcAXjzddlgL--) {
        bDiHvPjHRDii += bDiHvPjHRDii;
        bDiHvPjHRDii += bDiHvPjHRDii;
    }

    if (uIjglO >= string("ajXCyWURJulXrsKqyiUiZRdlOtLdQPfsYoMYuIqfKOkFPVoapnGsETSJmUKPxTjFSNJXDuPXVPZxWeDfnXTzeFOUTKrVkeCBdEwlROYTgQfePIckHEHodGVmAtAvugqCUnohrUiYJbMUOCFiCIKTzIyVxTDZIKeAisNUGCWAgPlY")) {
        for (int BooPXkSaCmRFUox = 1955097202; BooPXkSaCmRFUox > 0; BooPXkSaCmRFUox--) {
            bDiHvPjHRDii -= bDiHvPjHRDii;
            AizEjUP += uIjglO;
        }
    }

    return bDiHvPjHRDii;
}

bool hEmSUlHL::qgMSFi(double MJzUp, double uzVxy, double hgTuqx, int UDSChZE)
{
    string IdzggYmkRs = string("lRmxRXGCYwYAZHOosAXTntQqGTEhNsGKjvVNIoPBtxSHYKEdalCxMKTmv");
    double vVzAanmmOrh = 869091.7039767258;
    string qLgKXvldk = string("TkHsbRQUqwMGNPHwYUaAgiuAiyhzjDxKomGQQSsMvydN");
    bool nJQRBL = true;
    double nNyUm = -982758.7946130154;

    for (int RAguUlU = 407568661; RAguUlU > 0; RAguUlU--) {
        continue;
    }

    for (int uTFulh = 1755307666; uTFulh > 0; uTFulh--) {
        hgTuqx = nNyUm;
        vVzAanmmOrh *= nNyUm;
        nNyUm -= uzVxy;
        vVzAanmmOrh /= nNyUm;
        qLgKXvldk += qLgKXvldk;
        uzVxy /= MJzUp;
    }

    for (int ePXANlfjszeh = 268342894; ePXANlfjszeh > 0; ePXANlfjszeh--) {
        hgTuqx += MJzUp;
        qLgKXvldk = qLgKXvldk;
    }

    return nJQRBL;
}

string hEmSUlHL::kTDjUegQfki(bool iVPJM, string AqMBYNCtTS, int GxOHeKQK, string gQCBfiKBTHUowCc)
{
    string btjKkNQDnOq = string("DkEaWicbGtoYaalaecnGPvBBbckXaKJOtLSfhzwmPOMPBCtQhxsheNbPFwYEtFWxlZBMXeiEiQlsqpwNURmLRImurYKFeCtFbxLpwGxNKrFgAUlxRPAcYRQjdfNiIFZnpjqmGUFDmylNUtchmyqQmIFGMLfJlqlBKcJfkcekLLLAVEyYdtnmFdITeXKEFYHIctFy");
    int zGrMvOLWA = -388892394;
    int CWPuu = -1333372103;
    double kFazrVfvM = 380142.09152155335;
    int JvRgwmQ = 147787635;
    int lANPMTQdN = 800749025;
    string pJTCJJTA = string("WSFNgwDCpKaUINQdmgVuYtPnxbUxmiNCsLWVrJujNYsVEqvpLVbYLxthwlxMFKvcWNVhlllFDKTovZTEcdQQlUliTLvARmOekus");
    string FyGoDQdIHklzgo = string("QeeIJJIMCNNSmgIQcWxmAHVUDjYbejhWazUGaLXQleBZjalybbZWcTPBlaKlpXpQNlsDlPWLnhuWuMZqAZWGZQFPuffbsNAhPXMPuGhoXcJhZq");
    int JLaXuWrxUNuuVIP = -115773357;
    int WUbDeXbjAilMmuG = 1936574167;

    if (FyGoDQdIHklzgo == string("lZGZfJvBo")) {
        for (int OQxyRx = 311259738; OQxyRx > 0; OQxyRx--) {
            continue;
        }
    }

    for (int BORfGmdp = 1927253436; BORfGmdp > 0; BORfGmdp--) {
        CWPuu += GxOHeKQK;
        GxOHeKQK += GxOHeKQK;
    }

    if (AqMBYNCtTS == string("DkEaWicbGtoYaalaecnGPvBBbckXaKJOtLSfhzwmPOMPBCtQhxsheNbPFwYEtFWxlZBMXeiEiQlsqpwNURmLRImurYKFeCtFbxLpwGxNKrFgAUlxRPAcYRQjdfNiIFZnpjqmGUFDmylNUtchmyqQmIFGMLfJlqlBKcJfkcekLLLAVEyYdtnmFdITeXKEFYHIctFy")) {
        for (int xuDFKrBRQmFopru = 1680562843; xuDFKrBRQmFopru > 0; xuDFKrBRQmFopru--) {
            continue;
        }
    }

    if (GxOHeKQK <= 321716488) {
        for (int eShlzbmTDVBxmu = 1108503075; eShlzbmTDVBxmu > 0; eShlzbmTDVBxmu--) {
            JLaXuWrxUNuuVIP /= WUbDeXbjAilMmuG;
            JLaXuWrxUNuuVIP /= JvRgwmQ;
            GxOHeKQK = GxOHeKQK;
        }
    }

    return FyGoDQdIHklzgo;
}

bool hEmSUlHL::JwaRCQYTPMwQ(string qairiiOjeTulP, bool FBajByFesCrG, int niaCFEqftqgz, double btwoNZJcJMqncnMH, string wuLbIpZIdW)
{
    int NpBJK = 1395952156;
    double LvFSlw = 699444.1831815285;
    string SYoYMdVDT = string("qBPsjkpskZJclhfoJrzbrVZxEtmJKEZxejTBkAUnGuYwxDnKBVqZeZywzRkcbRYGaxrWQbRZJEDTawmlgrmPjYDWcXrpwyGjIKylMogGUejPJHeEjSFhgHepjboefmSyvQgPohGBNSxOoQIVmTNLhwOfslYhJTHtStcQvFGaxitqePRXZlYgBPjXa");
    int VKqRBwCunV = 229458294;
    string sNkNa = string("JbnNSlpnaUbhqeXCEfXdYPtklVoPONubPSwdlITPDYKvwrzjbMNIBzRmnkPudtgbTKSSYzlLRsIxdH");
    double kJLIIOZhdKmRMj = 733800.3200653472;
    int jgfLYj = -1974672371;
    double udNAHYgzdJftGq = 377595.92459435354;
    int CRVaWkWTqCbiLrVi = -733912499;
    int xPwpSPVlHOi = 1615375294;

    for (int szCbTMzMR = 688940834; szCbTMzMR > 0; szCbTMzMR--) {
        VKqRBwCunV *= jgfLYj;
        kJLIIOZhdKmRMj /= btwoNZJcJMqncnMH;
    }

    for (int XLALKxXZk = 1151687490; XLALKxXZk > 0; XLALKxXZk--) {
        LvFSlw += LvFSlw;
    }

    for (int qiDhxeGyAbgGfMSC = 1278505329; qiDhxeGyAbgGfMSC > 0; qiDhxeGyAbgGfMSC--) {
        continue;
    }

    for (int QRACsJAoIsCn = 1438277308; QRACsJAoIsCn > 0; QRACsJAoIsCn--) {
        niaCFEqftqgz -= NpBJK;
        jgfLYj *= xPwpSPVlHOi;
    }

    for (int NNsoQHJtQFzMQp = 689832222; NNsoQHJtQFzMQp > 0; NNsoQHJtQFzMQp--) {
        continue;
    }

    return FBajByFesCrG;
}

hEmSUlHL::hEmSUlHL()
{
    this->ROjCYCma(-145682108, -687036.2367777369, -1867036265, 398599.4334064688, false);
    this->yjWqbke(false, true, 1948667200, 263992293, 530377.7602728201);
    this->pnAIfTsUErDMIa(false, -499397399);
    this->yNwuzjVRsWCvfI(557895463, string("PUfYlHwSfzPoMtmIeviWAaRmpPaipZEElaHQVYFavTIbVpszqfjqlusibDmZwbZNTtSAjbeCHBSBeJPBkmOZiPryzjhpxeLqtJzYBVVOBycDbBBsNGZtyNvMMxwEiMsvbHKmchUYiWjOULbczQe"), string("fWdBOfZOHAvKZqQxtJgicgosuxfFhhfjOOKjUgLYnnpzmaBsvCezzyeFZTMCQncpP"), -541034.3234318292);
    this->WuYNqtCmtDQT();
    this->xQtPCdHqTCs(146175.70479604352);
    this->JnDwKYws(false, false, 233282.75312303426, -543166.6756054201, string("UYzveDOSwokWRIiyNgibYiAfFmEvbEgGUaQPhIWOwLapimMslTRqRuxKKwZpvgPXYUefmfffzVllVlphMmwGlkzSvvqxigWhIBPiZXFCoMJnufDpXkGYbCoNFfmscHKTyqjRACrDwjFJINJwpUqONwhthRKcSaqqeahjWjBDqay"));
    this->ZpuwcCuiPIWa(-811525725, -322402.2668129009);
    this->NZWeC(599859361, -467278445, string("EtrYuTbfmGDFkEWbvNOiNvHiiszarvsmywAhzsiINgIYpWZZQMFwvXaQYMANogRhbYMBJ"), 2004064255, -921447.3181679881);
    this->yXiEgIbGHasM(string("ZYclqOngvjBkmLybyeGjYtblhkIWuWkrAgFdXBgCxpLiMlsHFMBFGbsifPCyTVGfchXGYPJBvtFxnubIglPAlzwiefHkdXKSqvNDUnAoyqUDoIwPIKZOAmmQaLeXvARLPMYZBrTLuxhWRXAJnnrZzMBxuBtDKNzbwklIIVlmswGBmBtCjTNZIvVaudjnIhGNuGRSGZL"), false, 539983.4578195051, -989900.6670086657, true);
    this->nwwRNlsv(string("eRQWEqkcRlWhEkmanRFscAQMlmoSXHDktnMfyTqFyasJpDRXLpehllCnahvjlNwcKlRoyRiScPkjQUGNdeLTDyLXDrJuvAQyFVUvMlUfWlSGh"));
    this->eYdIjONCB(false, string("QOZpMmSlAnQdMcXySPodGcqFdXQikhyitPWkwGKQUPAypTgwPtljdNxkoxMbucwsbEPfiQZxquFEPWKsOZFulCjnxlQVFJNSLBEVSRCcqFMuKvJiQmnNLOXAExQTookNGitBBNXHdOtpeiTXTTqfOiLsZbauGDLdCvFYkBaFOLHZILKLMTqZKTzgpkVyfZT"));
    this->AUNIOrLWjeo(string("eyexRYSYQwWyMrAauOkSpMszVYJvFeiVhoSwfvXKjOBUtqIdzNAZeCMbwUSyPwcpumnnJsFKEhuNkpRIbDYsYqYvgUbQRpXkrViLbrpxesKjEwODEgnOCGQHJYnYVHjMBYEVudVPocUhUMtjfGuyWxaOvLSoHGiDNESBzryyhEEGtABiCaUlCquMMFlOupZqGqSWeaAQjfMAJ"), 1103691179);
    this->qgMSFi(-350830.8102747469, 81319.8164987238, -689704.4368970394, 997288561);
    this->kTDjUegQfki(true, string("lZGZfJvBo"), 321716488, string("iLoUwOmbTAHatLRuKzdmcqfZ"));
    this->JwaRCQYTPMwQ(string("rsXYNScQ"), false, -1800841750, 531253.5529607746, string("orqVsyrDUmbtsgTcPWShebWxyuAlwWwveGEaIezGDPYzXsanJLcrihvXMwlEstrEcGqpaaw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MHQZiyLLaLOXv
{
public:
    int BEMHfS;
    int bLVelVvzGIb;
    string UNfOXnNxiennDqo;

    MHQZiyLLaLOXv();
    bool fyopkYCUS(double MJVGqK);
protected:
    string hOrOsZQPILCk;
    double MIdKhoJLipTIqK;
    bool LjBgR;
    string qKXzPOPWmDB;
    double dFoEaS;
    string TGULsHCE;

    string UzmczCebmIhF(bool DFYXtsWxIi, double xOxhlBx, bool aoDkPyadl, bool eSzSc, bool eyKFkKAdnATOVSML);
    int cvmtPyMnobAFEcU(bool XVooglgDqZKSKT);
    bool hAvaRmKWKetDvphZ(double yqnAcJbvlWmuRXL);
    void PAEAybQbIBJkhwHE(string ocMzNuOCBe);
    void jkemIYbF(double tQFWeDWLYa);
    void TMVCYLYXZvNuT();
    int avnIThycyg(string CAKWoZ, string xEgURW, double aLXmU, int mIGIdzXrEqfKR, string gmKBHABTKIOXfWZz);
    string yLRJAkqmcxCJR();
private:
    int jZoOr;
    double XhIsgY;
    double GrpZui;
    int HpvFMwcnKOHCCZ;
    bool iIbrNTviGHoWye;

    string TzRZqmMUMsjA(int HKXbJBaC, int ppAousazJljk, bool IYZyjDTzfJ, int DMVTg, bool MIikLnjMmiTN);
    bool SEhmwHnokVnDkP(string rGYipaLg, int waGVxXZpknvDt, bool sSbTIGVsmU, double sTySerbZgQXbjx, double ezCJVqxLDp);
    string lmJzRU(double SBcRUJTvQhQXC);
    void rYDMnlyoJGqzRWi(bool cBTIHsRPqZTGoLmJ, double xiQuE, bool eCAZWNsju, int NsNECrLyOGL);
    bool BgRUqdgQHm();
    double VEMAK(bool EbRmTbeMgnYiTps, double IAcbilZmfuCoxHRT, int aPfWattcydrnwH, bool JTcjVmhCmRn, double sCYFNDHiAF);
    bool xQWhZxRa(bool xDuZLGJVX, bool DaUVYMMHk);
    void QBrBwETEgaX();
};

bool MHQZiyLLaLOXv::fyopkYCUS(double MJVGqK)
{
    string BPkfYEQssnNMW = string("BqROhKDCSapZasNsUiqoWpCxZezzytReUcjOxwuYCgLdOJzdRIhgWItjrXphwagvmtndFMsJimrThddHlMsCpfligfaQkWVShveUlJzrXgAhMuegYgzirsBSUYzehCRqHIyAalrrWDDsgvYzVbtjXcoEEBcQopumtePbPfpGIujTFBrMKdRpSvrEXkDicxJEopdBYxrwYWOKBZEPoMl");
    double JxOqGSg = -762896.1656746626;
    bool HFSSArOjoYlA = false;
    bool LXynBqEGsC = true;
    int bLpOQtbHg = 1267515871;
    double FKdWNhvg = -541101.3909303526;
    int GbDwPSgtEuwxWOQ = 1507681576;
    bool mQVHSzFX = true;
    bool exsfyRE = true;
    int qaZLxMAXUGaIsh = -46801022;

    if (mQVHSzFX != true) {
        for (int fyMRiw = 291761458; fyMRiw > 0; fyMRiw--) {
            mQVHSzFX = ! LXynBqEGsC;
        }
    }

    for (int gCeUwPqxyNeYTLv = 103799083; gCeUwPqxyNeYTLv > 0; gCeUwPqxyNeYTLv--) {
        LXynBqEGsC = exsfyRE;
    }

    return exsfyRE;
}

string MHQZiyLLaLOXv::UzmczCebmIhF(bool DFYXtsWxIi, double xOxhlBx, bool aoDkPyadl, bool eSzSc, bool eyKFkKAdnATOVSML)
{
    string aqNuHEVrK = string("ryxKlhADmnxhCDbYRAQjiCnpRUFMNqRheWqgatPiaswaVzcknxxmxuosfdWwRHkBeoufqcGwbRBIobjegRCUrrvUuqMPUtxAmyfBpvQ");
    double dmihPoeGpH = 301854.48196172254;
    int hKOhIzwijR = 228747911;
    bool tqjnkTQYKSwBCm = false;
    bool UnFfmmJkUzZPmNV = true;
    bool QibpxinQZOj = true;
    string ZgcPshtp = string("DgyIHFfkjrOAtkCzsJDUxcf");
    string OXiwsYLNN = string("uafRZtBPfHeBWgxbtpyhFHpZHlqQxBQVQxUfBpvRKwgTpfZKlocBxUqkVwbji");

    for (int TfPpx = 848176651; TfPpx > 0; TfPpx--) {
        tqjnkTQYKSwBCm = DFYXtsWxIi;
    }

    return OXiwsYLNN;
}

int MHQZiyLLaLOXv::cvmtPyMnobAFEcU(bool XVooglgDqZKSKT)
{
    string YIjOYyrXuPNrQ = string("bfVjpgvoHaUkuwkTuXJIKgfXXwesHtrCPBMgFJqpLqmBnwHqfRQnLygQjMYSVhDLCYCxKZBZtgrkIMfdtqlSJuSidBkwBiWEfNVRtUeTYfNARRkvmDHssnZZcNFTwdNdMfQorYbMDvoaRqDFCEgyIBfkCVglwv");
    string HaDnutMdxgChPj = string("wgCQIJERyTYxdZTHXyPbLNUqWsiCsCHnFVGajOrMfEANuSNySirkjLSbVaynHrxwLmqdsRFPHMyVgFPMXabZtlbIHlOXXFZQXMvLKyFXXGxAsVkxKIVHImFOCcrNaqdJKWKuCAQRNvoYLBtmlisxiOAjTYPvXLMogiXMVgYcdVql");
    double afRjopitPsfqPk = -429303.8100473297;
    int kfmeB = -1325531843;

    if (HaDnutMdxgChPj < string("bfVjpgvoHaUkuwkTuXJIKgfXXwesHtrCPBMgFJqpLqmBnwHqfRQnLygQjMYSVhDLCYCxKZBZtgrkIMfdtqlSJuSidBkwBiWEfNVRtUeTYfNARRkvmDHssnZZcNFTwdNdMfQorYbMDvoaRqDFCEgyIBfkCVglwv")) {
        for (int yBPrxDnARXpHBurp = 1450506855; yBPrxDnARXpHBurp > 0; yBPrxDnARXpHBurp--) {
            YIjOYyrXuPNrQ += HaDnutMdxgChPj;
            HaDnutMdxgChPj += HaDnutMdxgChPj;
            YIjOYyrXuPNrQ = HaDnutMdxgChPj;
            afRjopitPsfqPk /= afRjopitPsfqPk;
        }
    }

    for (int sAjVL = 1592680822; sAjVL > 0; sAjVL--) {
        HaDnutMdxgChPj = HaDnutMdxgChPj;
        YIjOYyrXuPNrQ += YIjOYyrXuPNrQ;
    }

    for (int WiVwSN = 421675274; WiVwSN > 0; WiVwSN--) {
        YIjOYyrXuPNrQ = YIjOYyrXuPNrQ;
        HaDnutMdxgChPj = YIjOYyrXuPNrQ;
        HaDnutMdxgChPj += HaDnutMdxgChPj;
        HaDnutMdxgChPj += HaDnutMdxgChPj;
    }

    return kfmeB;
}

bool MHQZiyLLaLOXv::hAvaRmKWKetDvphZ(double yqnAcJbvlWmuRXL)
{
    bool TEPZFD = true;
    int puccfwVo = 398532770;
    int pXXuvy = 1257981593;
    string khnOAgiki = string("tCDjvEYPmNUeGhYkynKSFpTzvwkIBWUuKeEaElBHyBzEgeKjgZzcBQpvAUGSTIKIcbfjVywZshJxkfUIhycxGwrsMFCTmmFPyCDvIcOcxlWZEBAZKGqbsSfvNYfFQAPlSJcoftvRvCpJzcXRzghbUOGfsTfVRZBCGSNTYdhOxoRCfbXqhYIaIYsSehWDkhcWFYMuzppQQTXyJXeBoDvXK");
    bool VxnenfKOS = false;
    bool TqPfUqZDs = false;
    int xBmlhQZAO = -1404416510;
    int MyBsQRjOY = 2142406248;
    string IQlDuHCKylGXN = string("KoQmTlvZGMntzNPUshkGPvsiVkedlMNFkyFmYewmbkoAPPZCtGdXTJUugUHGnFfYJrVGuQFFyscJwEXinrBqqZZsnTZHvIXUIOrGtqXuhAfoNfDDnRJAiNGMxsNltVTWJJyDoWEnetjoQyVDNKOxGpxCiTZJLgVKuLuRacLSnKqUmhSOtJPqpxsMKA");

    for (int VUoMS = 638446677; VUoMS > 0; VUoMS--) {
        MyBsQRjOY /= pXXuvy;
        xBmlhQZAO = MyBsQRjOY;
        xBmlhQZAO /= puccfwVo;
        MyBsQRjOY += xBmlhQZAO;
        IQlDuHCKylGXN = IQlDuHCKylGXN;
        puccfwVo /= xBmlhQZAO;
        pXXuvy = pXXuvy;
    }

    for (int thbwOWlGibASgfx = 789292820; thbwOWlGibASgfx > 0; thbwOWlGibASgfx--) {
        TEPZFD = ! VxnenfKOS;
        puccfwVo += pXXuvy;
        VxnenfKOS = ! TqPfUqZDs;
    }

    for (int JYgVKsQEQwpNjTq = 2063627458; JYgVKsQEQwpNjTq > 0; JYgVKsQEQwpNjTq--) {
        IQlDuHCKylGXN = khnOAgiki;
        puccfwVo /= puccfwVo;
        TEPZFD = ! TqPfUqZDs;
    }

    return TqPfUqZDs;
}

void MHQZiyLLaLOXv::PAEAybQbIBJkhwHE(string ocMzNuOCBe)
{
    string sHTrsCC = string("ZcsuyKOfChMCLOWKgZdZOSeJ");
    bool RPyzpvjxysbsA = false;

    for (int skfooV = 832514032; skfooV > 0; skfooV--) {
        ocMzNuOCBe += sHTrsCC;
        sHTrsCC += sHTrsCC;
    }

    for (int tObFJ = 326861200; tObFJ > 0; tObFJ--) {
        RPyzpvjxysbsA = ! RPyzpvjxysbsA;
        ocMzNuOCBe = ocMzNuOCBe;
    }

    for (int dPayswVDZLCnGO = 174626860; dPayswVDZLCnGO > 0; dPayswVDZLCnGO--) {
        ocMzNuOCBe = ocMzNuOCBe;
        ocMzNuOCBe = sHTrsCC;
        RPyzpvjxysbsA = ! RPyzpvjxysbsA;
        ocMzNuOCBe = sHTrsCC;
        RPyzpvjxysbsA = ! RPyzpvjxysbsA;
    }

    for (int ftrluMWtnMtNMTmB = 1519545045; ftrluMWtnMtNMTmB > 0; ftrluMWtnMtNMTmB--) {
        RPyzpvjxysbsA = RPyzpvjxysbsA;
        ocMzNuOCBe += sHTrsCC;
        ocMzNuOCBe += ocMzNuOCBe;
        RPyzpvjxysbsA = RPyzpvjxysbsA;
        RPyzpvjxysbsA = RPyzpvjxysbsA;
        ocMzNuOCBe = ocMzNuOCBe;
    }
}

void MHQZiyLLaLOXv::jkemIYbF(double tQFWeDWLYa)
{
    bool HMVvyPw = false;
    string OIbUzdZ = string("KDVevvUGKsqhpbBVpXhUWYJLhKTvVvCYqRfcLUBBBJTBuyRoBaaChjqydUTyYWQhtdBjRYZInHIUeXXgOUhwazCfRBKYBEBR");
    bool fPvwSUCTJmJ = false;
    string yYlnnhBux = string("UrxxmyATgwlVsTUDiUuivCnWEfxsARseulgmpIQdSxnab");
    string SgjdxTHpGydiieZ = string("sxgsewwCueGQouIzpUXvmHeFamqAJHAqvVyKgUjrbJFDePvhMuXYrzBCIKLWkzRBhxJUcsktKtiwRwNhwtaCEMLiLOzQcdGyEfkcTKuDKjioaQktnyQhxvUqEbqtTFFpwoyylBaIjTVUCJqaVWzQdrshYY");
    double gbnAAbR = -1004964.2448578953;

    for (int gfGqTXniLZcgdr = 1639322199; gfGqTXniLZcgdr > 0; gfGqTXniLZcgdr--) {
        gbnAAbR *= gbnAAbR;
        tQFWeDWLYa /= tQFWeDWLYa;
    }

    for (int PeXouvLMCW = 651210303; PeXouvLMCW > 0; PeXouvLMCW--) {
        continue;
    }

    for (int cYwcRpbBIYsnJDxo = 2025986175; cYwcRpbBIYsnJDxo > 0; cYwcRpbBIYsnJDxo--) {
        OIbUzdZ = yYlnnhBux;
        yYlnnhBux = SgjdxTHpGydiieZ;
        gbnAAbR += tQFWeDWLYa;
        fPvwSUCTJmJ = HMVvyPw;
    }
}

void MHQZiyLLaLOXv::TMVCYLYXZvNuT()
{
    string jGLFnmPOGqd = string("WEYABBbQUIiQcLbQbpeHqxyNJUvnXStEEYEftmaaECqLnACwOnLodVApn");
    int iiruFUHNiP = -1101860280;

    for (int LpgAJBXyLYEjYjQh = 819775544; LpgAJBXyLYEjYjQh > 0; LpgAJBXyLYEjYjQh--) {
        iiruFUHNiP -= iiruFUHNiP;
        jGLFnmPOGqd = jGLFnmPOGqd;
        iiruFUHNiP *= iiruFUHNiP;
    }
}

int MHQZiyLLaLOXv::avnIThycyg(string CAKWoZ, string xEgURW, double aLXmU, int mIGIdzXrEqfKR, string gmKBHABTKIOXfWZz)
{
    string ttFljnFzscFFCh = string("xhiIeImmwvRTdVtniYZdqQhBXptjXCwZXOGfCxSYStAIwkDVqtBajZ");
    bool kQHIOKTnTs = false;
    double VYxHwLuaHdW = -667052.8836713616;
    bool YvdoAWnxUGos = false;
    double gNnRu = -472509.07188252814;

    for (int QFweFxBRPIvTEXy = 485189276; QFweFxBRPIvTEXy > 0; QFweFxBRPIvTEXy--) {
        aLXmU += VYxHwLuaHdW;
    }

    for (int OxwcZLkuZ = 1240471720; OxwcZLkuZ > 0; OxwcZLkuZ--) {
        CAKWoZ += gmKBHABTKIOXfWZz;
        CAKWoZ += ttFljnFzscFFCh;
    }

    return mIGIdzXrEqfKR;
}

string MHQZiyLLaLOXv::yLRJAkqmcxCJR()
{
    string bSkEyuo = string("BJxEleOjvyvSvgnyIcyPhvwepmlcEqGtpfxmzYyoKuWNUFHyfCcqrserhnDSgLBUOiQToFQWOChUdZAHWBHJMidDheThFscVrlIqznzCCQDfOukSDWUjncmcbybnI");
    double ArZskXnaVjjTR = 977377.018036245;
    bool OvqUCNzUnwT = false;
    int brAtQ = 1655008748;

    for (int ADLwBWaR = 559547421; ADLwBWaR > 0; ADLwBWaR--) {
        ArZskXnaVjjTR += ArZskXnaVjjTR;
        brAtQ /= brAtQ;
        ArZskXnaVjjTR /= ArZskXnaVjjTR;
        ArZskXnaVjjTR /= ArZskXnaVjjTR;
        brAtQ /= brAtQ;
    }

    for (int SvfVCqtrbBBV = 2056217256; SvfVCqtrbBBV > 0; SvfVCqtrbBBV--) {
        brAtQ = brAtQ;
    }

    if (ArZskXnaVjjTR <= 977377.018036245) {
        for (int YOyShc = 386849672; YOyShc > 0; YOyShc--) {
            OvqUCNzUnwT = OvqUCNzUnwT;
        }
    }

    return bSkEyuo;
}

string MHQZiyLLaLOXv::TzRZqmMUMsjA(int HKXbJBaC, int ppAousazJljk, bool IYZyjDTzfJ, int DMVTg, bool MIikLnjMmiTN)
{
    bool jdLTtxzoqiAMs = true;
    string GeFlKpkMatkgej = string("DpJOBKH");
    string bPyCJd = string("VtDRvLpHOvCqvwNEJQIWvbTiYnDlzYCGFLBkaKg");
    int tFuGeTC = 1815327328;
    double JNdonZlfmwOV = -285545.1941935569;
    int xoeNaWCEOAA = 139131556;
    bool hesopBBjtEcI = true;
    string ARklqYpvKO = string("jSjxWPbPdJxIiRKtzjphCLYCWWXSXIofWTbMgySSoDPFuuelKjwPnRAwlyFvvNtpaNaVSNuqjvXxryqFslnUQeQCGSrLykfCAxZvtTUTqnKqaaqPLXjKnEWeIXSTULCgPwbNKBJjUjZrsuxsfBJWXqfPkqdsO");
    bool hFkDFzwquypgZarr = false;

    if (IYZyjDTzfJ != false) {
        for (int BcdVpbk = 389177813; BcdVpbk > 0; BcdVpbk--) {
            hFkDFzwquypgZarr = jdLTtxzoqiAMs;
            HKXbJBaC -= tFuGeTC;
            tFuGeTC -= xoeNaWCEOAA;
            bPyCJd += GeFlKpkMatkgej;
            ARklqYpvKO += bPyCJd;
            xoeNaWCEOAA *= DMVTg;
        }
    }

    for (int plqzCdFjrtmArht = 224263756; plqzCdFjrtmArht > 0; plqzCdFjrtmArht--) {
        xoeNaWCEOAA -= DMVTg;
        hesopBBjtEcI = ! hFkDFzwquypgZarr;
        tFuGeTC *= ppAousazJljk;
    }

    for (int epmaveDmvfwWUhD = 39717101; epmaveDmvfwWUhD > 0; epmaveDmvfwWUhD--) {
        ppAousazJljk += ppAousazJljk;
        MIikLnjMmiTN = ! hesopBBjtEcI;
        hFkDFzwquypgZarr = ! IYZyjDTzfJ;
        ppAousazJljk *= HKXbJBaC;
    }

    return ARklqYpvKO;
}

bool MHQZiyLLaLOXv::SEhmwHnokVnDkP(string rGYipaLg, int waGVxXZpknvDt, bool sSbTIGVsmU, double sTySerbZgQXbjx, double ezCJVqxLDp)
{
    int lveSvpE = 1973709168;
    string ysOrhiSeCPazwyQV = string("XBlgBaaEKbCcPsGVsxpwlfQTxXXYYejqoaMSoYxiQqoeSdSIMFRbwHHEpVMfPLCCYRgqRdnlBZFhJbHaWThNzihXWgIqgTLENWaRnwZJFbVRpNqSopaIkEUugaBvOohMbYXrAVRKKOb");
    bool fDPeugqipiZ = true;
    bool BZDxUXfjPGsvSTa = false;
    int tRVdkvDEFvv = -1057921013;
    int KNBHtrdrJp = 668534311;

    for (int cvzjccMeWsXK = 1594825328; cvzjccMeWsXK > 0; cvzjccMeWsXK--) {
        BZDxUXfjPGsvSTa = BZDxUXfjPGsvSTa;
    }

    for (int zRacoEdKE = 436931387; zRacoEdKE > 0; zRacoEdKE--) {
        tRVdkvDEFvv /= waGVxXZpknvDt;
    }

    return BZDxUXfjPGsvSTa;
}

string MHQZiyLLaLOXv::lmJzRU(double SBcRUJTvQhQXC)
{
    bool cahOV = true;
    int oKLwKKMVQb = -1864592171;
    bool vpzeiwneYY = false;
    int xwxaErJLQdfB = 1244534309;
    string DjGxRtoU = string("VQGAOJlrjlPMLLKeBekwxikUZbtnZMeiYRjOFTPoYHTKHJVufjNfhjMotSrhbMgdksP");

    for (int gCtpnz = 1232714216; gCtpnz > 0; gCtpnz--) {
        continue;
    }

    for (int xilFAhRep = 445842403; xilFAhRep > 0; xilFAhRep--) {
        DjGxRtoU += DjGxRtoU;
    }

    if (SBcRUJTvQhQXC != 974096.3028023749) {
        for (int esZIgO = 753592566; esZIgO > 0; esZIgO--) {
            continue;
        }
    }

    return DjGxRtoU;
}

void MHQZiyLLaLOXv::rYDMnlyoJGqzRWi(bool cBTIHsRPqZTGoLmJ, double xiQuE, bool eCAZWNsju, int NsNECrLyOGL)
{
    double dHSrc = -841771.7596940275;
    bool YfnMrUkVZFRrrh = true;
    bool EtWdw = false;
    string hwUQZJJtuOl = string("nxnXicJwemRvQaKWNehwtTnmHdgSALurIpFbaOUDdlIbycnwgGOoOMiUNufZVyyoCNhsELDINOlDbcwDmnyHatRcSdCKZwrHclruYWOPxU");
    double bINHvJpXJY = -543894.1373143203;
    bool JFZHd = true;
    double uFHJeIzbyC = -987240.016788401;

    for (int kTFXZVNhiHDSaylT = 983813678; kTFXZVNhiHDSaylT > 0; kTFXZVNhiHDSaylT--) {
        JFZHd = eCAZWNsju;
    }

    for (int qjlTCG = 493836969; qjlTCG > 0; qjlTCG--) {
        uFHJeIzbyC -= bINHvJpXJY;
    }

    for (int bbgrbemsIqFAeiy = 265326796; bbgrbemsIqFAeiy > 0; bbgrbemsIqFAeiy--) {
        eCAZWNsju = ! eCAZWNsju;
        bINHvJpXJY += uFHJeIzbyC;
        xiQuE = xiQuE;
        dHSrc /= bINHvJpXJY;
        JFZHd = ! JFZHd;
    }

    for (int kdltqoPw = 1130056553; kdltqoPw > 0; kdltqoPw--) {
        eCAZWNsju = ! YfnMrUkVZFRrrh;
        eCAZWNsju = ! YfnMrUkVZFRrrh;
    }

    for (int UbwBcv = 1547675866; UbwBcv > 0; UbwBcv--) {
        YfnMrUkVZFRrrh = cBTIHsRPqZTGoLmJ;
        uFHJeIzbyC /= uFHJeIzbyC;
    }
}

bool MHQZiyLLaLOXv::BgRUqdgQHm()
{
    bool STQbXZw = true;
    string wcRDIADBePXoKl = string("gLHtlIYnqHmHgbGwDUzmUOYWwpFdpncPKAATyJqMJTIIWtYyGAEibmnWaBlOuEYJPCiyLHprofAyzTAdANHCedrOyYhvoAWJmgWNBJzILmpXGbWQbULMsJTuZDKUiPDnMbIkSbEFoKsNPXfZLqMhNvcLxgTplvosohZTuaIJuzbexWmjnFEFCaxGxbpLqcdhpAWChUoVyuBvdsErMLEVrCpFEmHWYNzbdcXVxBmbz");
    string bgbVuIVNkmHz = string("yokYQkAcYEWtcfizhcSIIkeObLj");
    bool JYxSaCALnunbLPCq = true;
    double ikhDsKOGwtylxbA = -762325.5811737378;
    int OtdrIQMNLcOOnqpc = 431988913;
    string SbiSBSRD = string("cikdafmqePAjtujskosSokErhtODOhUlPgwHpjFxDNaJBdvGYRJjkUixWxSpSGYfEmRasIpnPwGjdZRbdyQroHDvWxWYhYNCDbFaWVeeBlCKVfoglmLXaKqHRJCAaVSakFTmEbsruXnrEzlAEtjrsyeOwWmgwKFftKnJJdcNUjOTePssdedJSVXgDFYesZzgLGOnoaqOxmEaPzJGClNiGdFddUzcczFmiKirEBUXlQfaKksT");

    for (int QNGjoOfrRpcA = 999515994; QNGjoOfrRpcA > 0; QNGjoOfrRpcA--) {
        SbiSBSRD = wcRDIADBePXoKl;
    }

    if (bgbVuIVNkmHz < string("yokYQkAcYEWtcfizhcSIIkeObLj")) {
        for (int QBIAsPeMR = 1646763475; QBIAsPeMR > 0; QBIAsPeMR--) {
            OtdrIQMNLcOOnqpc /= OtdrIQMNLcOOnqpc;
            bgbVuIVNkmHz += SbiSBSRD;
        }
    }

    for (int qsNrsfic = 244791216; qsNrsfic > 0; qsNrsfic--) {
        continue;
    }

    for (int oVYnDxqkjsgoIvTe = 1732836158; oVYnDxqkjsgoIvTe > 0; oVYnDxqkjsgoIvTe--) {
        wcRDIADBePXoKl += bgbVuIVNkmHz;
        OtdrIQMNLcOOnqpc -= OtdrIQMNLcOOnqpc;
        JYxSaCALnunbLPCq = JYxSaCALnunbLPCq;
    }

    for (int zojRu = 424979444; zojRu > 0; zojRu--) {
        bgbVuIVNkmHz = wcRDIADBePXoKl;
    }

    return JYxSaCALnunbLPCq;
}

double MHQZiyLLaLOXv::VEMAK(bool EbRmTbeMgnYiTps, double IAcbilZmfuCoxHRT, int aPfWattcydrnwH, bool JTcjVmhCmRn, double sCYFNDHiAF)
{
    double ZmmuTkWjNDP = 637873.37233886;
    int hhGkmfY = 724704;
    string CpBkDGqTzBc = string("nllhDe");
    string aCAYJlmHCRRd = string("elYeKdXIAKnytZWLdCGeTwMMnbbRRMUysLnzwiDyirOdSqtpeReZsfYJVvJVxVRwdRgsNrZOeTUwYttRhLmKlIetDLlEEeahofPVRTnSvDdvOcnkTOzvUgtZiejfSwCWrksjwULTaWKJbjmEcEdK");
    bool MujSw = false;
    bool kdOwpEAq = true;
    double bpBVlvWJXNGKt = -581859.3145252512;
    bool vvnnMM = false;
    int zHEdzqEWwu = -1111199432;
    string peRRLulXhmycrO = string("YbvaxpTfDogrNEfBolrehQKfmEZSVvhPkLWrALbLFTSyqBA");

    for (int eSjsiDKeLqA = 434335584; eSjsiDKeLqA > 0; eSjsiDKeLqA--) {
        JTcjVmhCmRn = ! EbRmTbeMgnYiTps;
        bpBVlvWJXNGKt -= sCYFNDHiAF;
    }

    if (ZmmuTkWjNDP > 637873.37233886) {
        for (int sMFTgsD = 709668138; sMFTgsD > 0; sMFTgsD--) {
            MujSw = vvnnMM;
            JTcjVmhCmRn = MujSw;
        }
    }

    if (CpBkDGqTzBc > string("nllhDe")) {
        for (int GzGrVQzdR = 773383363; GzGrVQzdR > 0; GzGrVQzdR--) {
            continue;
        }
    }

    return bpBVlvWJXNGKt;
}

bool MHQZiyLLaLOXv::xQWhZxRa(bool xDuZLGJVX, bool DaUVYMMHk)
{
    bool qaPoiB = true;
    bool LwZaDYykL = true;
    int Mdmbg = 448700395;
    int GTavht = 1698954713;
    double vAEvuoGcClf = -490044.0699295292;
    bool AXIIedUBclmlyU = false;
    int ESfxQqa = -1902250710;
    string wewpUYkLGxgg = string("ZWEVNzDfXxHPEMoaZciBqNUpevWwpzxxfskfDjBknsbCBpVzLKSpMEHRWNICXDecZeMLTAjKPcQJTeZqPRhpQlpibqKAYoPTnafYqwEWWihveAIbibIZiLwuRYVKtXdIsaCcqTaloPBUWNXVfgFwgoaPSyijKwurzbBltzbQrbkpUJjXhJWeFtzXpkmkatQlWTPbQUOGAUpILWXmogigBjypKnVRsYSApzxLzNajBsQuyiFFKQJYSgNwsaR");
    string msicUFE = string("lulCGCvbXgjWcWLnWEKehGUMFVyfOmOUlhOWJyAQ");
    double AVhNhCvMT = 421269.0294182602;

    for (int MZAbKUwkeyugyPl = 1138517182; MZAbKUwkeyugyPl > 0; MZAbKUwkeyugyPl--) {
        continue;
    }

    for (int xJPUjUqJEICJWjh = 2007721757; xJPUjUqJEICJWjh > 0; xJPUjUqJEICJWjh--) {
        DaUVYMMHk = LwZaDYykL;
        xDuZLGJVX = ! DaUVYMMHk;
    }

    if (LwZaDYykL == true) {
        for (int XUEHbPewOYhjn = 1028337664; XUEHbPewOYhjn > 0; XUEHbPewOYhjn--) {
            AVhNhCvMT = AVhNhCvMT;
            xDuZLGJVX = LwZaDYykL;
        }
    }

    return AXIIedUBclmlyU;
}

void MHQZiyLLaLOXv::QBrBwETEgaX()
{
    string OkDyTUhBEZMyo = string("qvsjnWEfQyEzmkJuYxLcKyeOxrRqZIHiKgJSiEnnufOWtITYZRxNjmcLNcklBWqKFErUuhInVAanWqhgd");
}

MHQZiyLLaLOXv::MHQZiyLLaLOXv()
{
    this->fyopkYCUS(-476211.64845592016);
    this->UzmczCebmIhF(true, 998723.6215215715, true, true, true);
    this->cvmtPyMnobAFEcU(true);
    this->hAvaRmKWKetDvphZ(415182.338668888);
    this->PAEAybQbIBJkhwHE(string("FmSCLwLoSFHatfTrqyccvjGwEijiDpndhYnBhPDweSLbHnuMuLPdfbbpkSlLAdNDFAwhXfuDpUPHEAsczALjinvOPsatbYoUESwQkQgjwMiNpNIeoCsWaVRSAyvpyIQMABjWWxNBbvdEmyfWjttFXaPwkChUkyfRRNAfChwlslm"));
    this->jkemIYbF(-1020816.3201825606);
    this->TMVCYLYXZvNuT();
    this->avnIThycyg(string("xDUChDJLZvkCJGiPMRlSSefzmibAOGjotDooVACIKMpdCCMSKDdqYeLZNgPhLMPDycbCPyCWRxtqRJIoChWsZyieRUBnySKxJaqZvtyynf"), string("eTXDHIkjTNAzAlJvUhMnzAvxQFpSPpbciWkAOrPvGPft"), -718698.189325781, -1268755456, string("jaFIzIxUzbMxfQvwmrSNpPUaKKyHmfAeFwGnoznaqhAowCiIugkWbqGhlWLdZlJowvheZnYzjMgylDMkfSCpLbGRrKnrQAAbiyxZlutoYJsNyLKdNjHIFGJyNsxsIYaGSYrjFdtqsmhWlINt"));
    this->yLRJAkqmcxCJR();
    this->TzRZqmMUMsjA(-1065464584, -716067631, true, 1471002600, true);
    this->SEhmwHnokVnDkP(string("DVbGOCAGcOJcOYspCayNrVLBoaYtVjgKCxYHbqAnpYoEOtfXXYIbaZjyFAfZAAaJQQvaKpKGgqhkXzPMlGYphyqHYlwahKBteyUCMGfbbTpVEJOtPqjooOOhiWHCVIhZPQfzYZLpKtGjWqyFZyTtRccnsOjXSKGCjEuwGliExAwdVRdEIUyGMggJJwbhEbUeZrvtERoDKqCc"), -601259617, true, 779744.1180130976, 992240.1185541027);
    this->lmJzRU(974096.3028023749);
    this->rYDMnlyoJGqzRWi(true, 110005.05536964932, true, -888311668);
    this->BgRUqdgQHm();
    this->VEMAK(true, -144413.95003680862, 747049063, false, -468877.2276678682);
    this->xQWhZxRa(true, true);
    this->QBrBwETEgaX();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ibecbKVanMw
{
public:
    int HZkauQrBPGVvgLlW;
    double iodblbonSBT;
    bool bVrKYjUeCvd;

    ibecbKVanMw();
    bool tgAkQKhfYiN();
    string btRRSJKKS(int eVAAkMoZOkUQ);
    string YEsfJqtbdLhiSCyU(double nEdjroSsQqdopN, double OpEYwLcfkJg, bool LEaSzUWeQav);
    double eycfz(int wRtpVK, string TaYrNGpfdqyTYdGR, string UskZy);
    string FnOtJPzl(bool CqvjAiLymNkqTBVi, bool VGPobvWgcBUPpHM, string IpqViUTziSVQh);
    int ZNZnOS(double fRlFENtXsywJmI, int vGIvuGSvtqDkrpFz, int TjWXyPqtYTm);
    double LVPXahbgIoO();
    void uTEOFsD(bool uhEvhsLOhjLW, double HhPNXaCgfxjmfMEE);
protected:
    int VkPRFpcjCBXCiO;
    string iQYTRwbNVr;
    bool xynxDyP;

    void KYjnDdMlmq(int pmhZReG, string Qxcwx, bool zHWBVUSb);
    void dUrrIsBsv(int wbkixSPsKyTM, string OrseHwWL, double yAbfqponNXqpFE);
private:
    double NXQCCliqJEdlmMTk;
    double AfZQYrCNZ;

    bool jdzPosTBFFOIUgKC();
    int YVjLDJsGJ(bool IhhpWAKe);
};

bool ibecbKVanMw::tgAkQKhfYiN()
{
    double kKMQO = -892770.916521592;
    string qGWHZbQGK = string("KCoyUEGycBhzqaMGzCdNamcGhSGZSUDYZNQqBoUAIcYVnlELKLkDCuaaPnihXdxJCxKpzUdqqOAtztsCBxeoHtHeaoueGGGpUbkDlwLJlkKtFTA");
    double xvihcSDOcZdS = 406826.4974259336;
    int GxUdpYfWTofFQwk = 1642987993;
    int pSDTVJpWiotJ = 1044124164;
    string NzaNcXMRWZdyq = string("YsmeAPdPqoaQoynBAizbVTkWojmfeNLqtxyeQJIXJFvycETlLJriMFvPVsImbqqcPgyMIjrsZJHonBWOsqXnBeTlaYIlPEAEQiKhCqAEmQDJCYsVXhUXUJtkOezswnvLwdaWbpUdlyaobcMVALuopyEXMAIZJF");
    int VIIfKm = -514428471;
    int xtWrMkibXVrdY = 499583694;

    return false;
}

string ibecbKVanMw::btRRSJKKS(int eVAAkMoZOkUQ)
{
    bool TRHVZVYmdHKeXzM = true;
    string oTPUgJK = string("jgyWRygGucDTsvNakozMtHAKmAHmLLczJfzvUtQkOOgRSNbXnyMhbjdaeGaiLztTtTtXCoCzNKltKHfmAyfiLLalQcObMFsrYHiOszKrZeltmrFiSYJWuwEzzAEYUEaPwIClMSUpGDdBOlMjTBcgHdXNdlkQrzcaGjMdbhzMlmWVn");
    bool JaKYXRMeVVH = false;
    bool ZyZUynQ = true;
    string edcpgOuiKHWC = string("qowbQSkquzMqHkyLLPzDJNXpzCViYznzGnuTYfJvLeNXBVqEXkYvzPlVBrGJZRASFwNoZrCdAbVefwSMQJQIpFjzVucCTFVSawSvHecImVvxUyrTsh");
    double FBZEDrgSSBOyqv = 993488.2292564814;

    for (int joYdFhHi = 1205815259; joYdFhHi > 0; joYdFhHi--) {
        FBZEDrgSSBOyqv /= FBZEDrgSSBOyqv;
    }

    for (int cJxJTPDRuuYHd = 1233967402; cJxJTPDRuuYHd > 0; cJxJTPDRuuYHd--) {
        edcpgOuiKHWC += edcpgOuiKHWC;
    }

    return edcpgOuiKHWC;
}

string ibecbKVanMw::YEsfJqtbdLhiSCyU(double nEdjroSsQqdopN, double OpEYwLcfkJg, bool LEaSzUWeQav)
{
    string AHRwpHLiAWGxLQ = string("oaKywgHWFhuuSMzwxbUHyyFmlZganjXXyzjczSxOTQZLmfqWPhmg");
    bool IBakyCZNlVmB = false;
    string WrDyHcuP = string("cjuMxCByjVGdcqFNyAURT");
    bool kpRWDJoRRBApwDp = true;
    string NUwKcferMD = string("rhEeNPNymAbrsJgllbtmMoaeWZQpEInsqpuLjXkAVeagEZJMdqZeiILGdFhIFOnqyqPwHpJpkfHKbjPnKBE");
    double qwSdne = -680605.7842605877;
    bool KQEzSA = true;
    double IudrXsvzTBQmK = -950554.7783992293;
    string gnBGwOTz = string("hFhttDKBzcqTJPHTHDKqFwMCIpLubTNjSiVMafPmOkpwOLAqDQbExbAKrqvaxj");
    double vlhIGfhf = -296283.36883549084;

    for (int qCJhoxbHiMEBgMTG = 837485639; qCJhoxbHiMEBgMTG > 0; qCJhoxbHiMEBgMTG--) {
        WrDyHcuP = gnBGwOTz;
        AHRwpHLiAWGxLQ = AHRwpHLiAWGxLQ;
    }

    if (AHRwpHLiAWGxLQ < string("oaKywgHWFhuuSMzwxbUHyyFmlZganjXXyzjczSxOTQZLmfqWPhmg")) {
        for (int eFBgbh = 122700413; eFBgbh > 0; eFBgbh--) {
            IBakyCZNlVmB = ! KQEzSA;
            LEaSzUWeQav = kpRWDJoRRBApwDp;
            vlhIGfhf = nEdjroSsQqdopN;
        }
    }

    for (int tBPjX = 1030228871; tBPjX > 0; tBPjX--) {
        IBakyCZNlVmB = KQEzSA;
        IudrXsvzTBQmK /= nEdjroSsQqdopN;
        IudrXsvzTBQmK *= vlhIGfhf;
        NUwKcferMD += AHRwpHLiAWGxLQ;
        WrDyHcuP += WrDyHcuP;
        gnBGwOTz = WrDyHcuP;
    }

    for (int iVqEELVtZ = 639032744; iVqEELVtZ > 0; iVqEELVtZ--) {
        continue;
    }

    return gnBGwOTz;
}

double ibecbKVanMw::eycfz(int wRtpVK, string TaYrNGpfdqyTYdGR, string UskZy)
{
    bool pyvJUqgZUfhqVf = false;
    double ngrYTHKcDlfNYKp = 796697.0378997915;
    double WHjjBjflfmqjFOc = 236981.89171752648;
    bool HLthnDwnrC = true;
    bool wHIQXTeHQZcT = true;
    string HTdzbunwPasxSYdP = string("hyDPJTHhYOQShlMOjsbQdlVJeshVtbLkecNxXvQPljxWcCtfMXBYVWtPaxImynralVktLPvyKTCfbxcdjxxvqDvjcNHLezDBDXoNBtwPVNFVUzYjwkJPoEGkpFwiePXIJXObyFrq");
    int vvubuuROGxmcZTs = 599958458;
    double scsqwWhadVASRIu = 922878.2909160512;
    string jVPCejSQcQHQ = string("jIheMUskTtxZUuG");

    return scsqwWhadVASRIu;
}

string ibecbKVanMw::FnOtJPzl(bool CqvjAiLymNkqTBVi, bool VGPobvWgcBUPpHM, string IpqViUTziSVQh)
{
    string TOMvB = string("aNLzLpovPTWnOqLGmwHCvMXXhMTPlRlqXsBrXsHVwQEmlvLVpXWnkQNMhoZowmdoCpwNhhEiawRorcEfnTWGHOvVVCfiXCRgvpZXNNwhQaXkWtEsXPkzdUAvRzMNIyHdJNTRSdSmRcdgjUyqTMTKqJBgXbRkEzhQRGLfpdxmIFOpWiiMkAxzrLYGlwIsCTwMbTUdeZyAumEZrON");
    bool sNIkBOimHA = true;
    int IKAFhpwTdk = 252875188;
    bool GHKHd = false;
    double YOKxpj = 534300.2265749654;
    string okUABGzVQwP = string("qsBdFhWaageboqYKcJHyaYIyzmZapannDkfBAqmlyRZDsQpAkOJvfWJNPoJphnPTkLaASdynOUEypxzCMlXud");
    bool PYyoDIvpEzYjDQWf = true;
    string hXwkPHG = string("PvZFtqGWdDRYPQYzxhbbjVuJZOsNZJzkhSskfuvwYilocCZnbGEQPzVkzCZtgJCBGUbAZEoTIBByHwBtKvLxqjcwPNUbeScgpOwOjgBLiCWHCmxKxWYJmyyRCRCy");
    string FZXinZDjgX = string("plfVlWMkTEKTcTSjrsvhPpQSySefROPhdbfyLtnIxvcZIEHDRZmREuyXnLMJtYjqyLidQIbyfUjCKyIiVuywHaTFExItH");
    string ghvkRbrryQC = string("wfeFjZeqzhznoHGJEXHlnjTPcDlkuOHpRCOKRxTHiYbsGHSgaLBgKPMbSlbizvfeCYsoakBDTUdFwlPZwqnwtmTtsPaPXtFYQPuuGgBSQCfyvmstOQzpOHENzsykdyQciabxGlzDIItfpcSeUyemRwxykAmoPBWYOwAjXQQWdwsuQpIEDVhpBApodfpHuSTfWewBEIhaMZjETzXeTYm");

    for (int kwXzYTiuqqvodsu = 1137934081; kwXzYTiuqqvodsu > 0; kwXzYTiuqqvodsu--) {
        IpqViUTziSVQh += TOMvB;
        okUABGzVQwP += hXwkPHG;
    }

    for (int tTczoC = 2044446614; tTczoC > 0; tTczoC--) {
        FZXinZDjgX = hXwkPHG;
        okUABGzVQwP += okUABGzVQwP;
        IpqViUTziSVQh = okUABGzVQwP;
        VGPobvWgcBUPpHM = ! sNIkBOimHA;
    }

    return ghvkRbrryQC;
}

int ibecbKVanMw::ZNZnOS(double fRlFENtXsywJmI, int vGIvuGSvtqDkrpFz, int TjWXyPqtYTm)
{
    double GIYdExXCyXgSBH = -535721.5664044125;
    bool ByDvhSWFNUYKyV = true;
    bool NreQwcIRkHGTGX = false;
    bool DvpdFBrrWJx = true;
    double CaBTODYPGNOyJ = -760120.3156351893;
    int kCcWkYKiBiZh = -1750367116;

    for (int FfgWwJJ = 602273619; FfgWwJJ > 0; FfgWwJJ--) {
        TjWXyPqtYTm = vGIvuGSvtqDkrpFz;
        CaBTODYPGNOyJ += fRlFENtXsywJmI;
        vGIvuGSvtqDkrpFz = vGIvuGSvtqDkrpFz;
        kCcWkYKiBiZh -= TjWXyPqtYTm;
        kCcWkYKiBiZh = TjWXyPqtYTm;
    }

    for (int xBIIhMQxQWCjSYR = 993880834; xBIIhMQxQWCjSYR > 0; xBIIhMQxQWCjSYR--) {
        kCcWkYKiBiZh /= vGIvuGSvtqDkrpFz;
    }

    if (GIYdExXCyXgSBH == -760120.3156351893) {
        for (int nGUfRf = 532787791; nGUfRf > 0; nGUfRf--) {
            NreQwcIRkHGTGX = ! NreQwcIRkHGTGX;
            NreQwcIRkHGTGX = ! NreQwcIRkHGTGX;
            ByDvhSWFNUYKyV = DvpdFBrrWJx;
        }
    }

    for (int PutLiQMVKMOHIS = 654665893; PutLiQMVKMOHIS > 0; PutLiQMVKMOHIS--) {
        continue;
    }

    for (int SfeGc = 1540168598; SfeGc > 0; SfeGc--) {
        continue;
    }

    for (int UEVlP = 187447588; UEVlP > 0; UEVlP--) {
        GIYdExXCyXgSBH = GIYdExXCyXgSBH;
        GIYdExXCyXgSBH *= CaBTODYPGNOyJ;
    }

    return kCcWkYKiBiZh;
}

double ibecbKVanMw::LVPXahbgIoO()
{
    double UTEFUwLgSYtozDJ = 448635.80880361126;
    bool hACpwwIczSu = true;
    bool SwoMhOUJPGaGlb = true;
    bool QBQAsPic = true;
    int ebtoByvhjRtmXoE = -460176627;

    if (UTEFUwLgSYtozDJ > 448635.80880361126) {
        for (int XHfXge = 974914959; XHfXge > 0; XHfXge--) {
            QBQAsPic = ! hACpwwIczSu;
            SwoMhOUJPGaGlb = ! SwoMhOUJPGaGlb;
        }
    }

    if (SwoMhOUJPGaGlb == true) {
        for (int JwZaLrJYU = 1680938228; JwZaLrJYU > 0; JwZaLrJYU--) {
            UTEFUwLgSYtozDJ += UTEFUwLgSYtozDJ;
            QBQAsPic = QBQAsPic;
        }
    }

    for (int wEjtPmxdKGASDgWE = 708848860; wEjtPmxdKGASDgWE > 0; wEjtPmxdKGASDgWE--) {
        hACpwwIczSu = ! hACpwwIczSu;
    }

    if (hACpwwIczSu != true) {
        for (int Avmfqr = 104336927; Avmfqr > 0; Avmfqr--) {
            QBQAsPic = hACpwwIczSu;
            ebtoByvhjRtmXoE /= ebtoByvhjRtmXoE;
        }
    }

    for (int JhjSxlLpS = 83551504; JhjSxlLpS > 0; JhjSxlLpS--) {
        SwoMhOUJPGaGlb = QBQAsPic;
        SwoMhOUJPGaGlb = ! SwoMhOUJPGaGlb;
        hACpwwIczSu = SwoMhOUJPGaGlb;
        QBQAsPic = QBQAsPic;
        SwoMhOUJPGaGlb = QBQAsPic;
    }

    return UTEFUwLgSYtozDJ;
}

void ibecbKVanMw::uTEOFsD(bool uhEvhsLOhjLW, double HhPNXaCgfxjmfMEE)
{
    int xjevMAhvv = -1102776903;
    bool sdNoDiNGCMnUWbk = false;
    string BzRGRS = string("fwabQUsCuNomHqxCchliOokFIteZPifYiScJViRExVNSJdLvzSYLDxsXnZEjHZyQmNbSuFQMNazXmVFsbebMgrHDoauhhprmGadMTauwmkxrvjIxAOngXzbYLtmJtKqGxixSMe");
    double SxERb = -666882.4737539581;
    double pPQJcrGP = 554837.7953192156;
    string ZOGRyJVk = string("BibmkWcYdgyDQIZAgvQGZSYJmFzTtcsRwqEhSssh");

    for (int dwgQbnteCGbPlp = 1478654587; dwgQbnteCGbPlp > 0; dwgQbnteCGbPlp--) {
        continue;
    }

    for (int cykXCilMQ = 2084596096; cykXCilMQ > 0; cykXCilMQ--) {
        continue;
    }
}

void ibecbKVanMw::KYjnDdMlmq(int pmhZReG, string Qxcwx, bool zHWBVUSb)
{
    double xggPrW = 23868.71802342419;
    double pjJkMDuUOuN = -962757.769301271;
    int iTprpzWYtyYoucx = 1268357645;

    if (pjJkMDuUOuN >= -962757.769301271) {
        for (int pAQiqPqAcEWmz = 194030746; pAQiqPqAcEWmz > 0; pAQiqPqAcEWmz--) {
            zHWBVUSb = ! zHWBVUSb;
        }
    }

    if (pjJkMDuUOuN >= 23868.71802342419) {
        for (int lZieNtQdrJbTWdF = 639947437; lZieNtQdrJbTWdF > 0; lZieNtQdrJbTWdF--) {
            continue;
        }
    }
}

void ibecbKVanMw::dUrrIsBsv(int wbkixSPsKyTM, string OrseHwWL, double yAbfqponNXqpFE)
{
    double LySyoh = -764209.5749055631;
    double JkSzh = 26100.62182452775;
    bool DLgKYYk = false;
    string chnKPrPmBrO = string("AUHXZSocdqCIbBweCOANwyTSwHfDlpRlbSChNUoLfNLXprITQlCQZmJmAGexWsvfxJCtVrlfLOjpYCQYqERdhqJXTOZpSrgcbzsBjEdMHhgjDFOojmZjACDhoc");
    bool yqTJK = false;
    int UoTBjHO = -902884067;
    string WQXyerKVzHrS = string("JmDutwoyxYlQNyjhSpyaOAvBPTfLNzvGzCtNQPwRfmqMZVZMHuQggumINWrnNZDHkqVJbxrMQTSVHUBfCMzDTODwlutDAsPFziOJUMtzSxOXYEJfRjTjcLxkhbNeilWjnTDWtgphKVeTEUpCKFNXiFETCfStWNXjULZxFndTbNVNzPJIhypTmKIFURCWRRtOTyqozLRWAuwTOuxBoPqaTjKXdIktidSHPMBXrLCFvgOEu");
    string SGzXursuvFUP = string("axUUAeuSScUApPKOVbWYksPvTPvnnIQfcStwlytJvPQiuyIbLVRMchFyLixfcgpmkqTUXxhKDFwVvJEXXTbeaRtE");

    for (int igBmKIklBaFaCtR = 253413069; igBmKIklBaFaCtR > 0; igBmKIklBaFaCtR--) {
        yqTJK = ! yqTJK;
    }

    for (int rLQYM = 1898894229; rLQYM > 0; rLQYM--) {
        continue;
    }

    if (OrseHwWL != string("JmDutwoyxYlQNyjhSpyaOAvBPTfLNzvGzCtNQPwRfmqMZVZMHuQggumINWrnNZDHkqVJbxrMQTSVHUBfCMzDTODwlutDAsPFziOJUMtzSxOXYEJfRjTjcLxkhbNeilWjnTDWtgphKVeTEUpCKFNXiFETCfStWNXjULZxFndTbNVNzPJIhypTmKIFURCWRRtOTyqozLRWAuwTOuxBoPqaTjKXdIktidSHPMBXrLCFvgOEu")) {
        for (int YBTOghQqtAJM = 787141031; YBTOghQqtAJM > 0; YBTOghQqtAJM--) {
            UoTBjHO = UoTBjHO;
            yqTJK = ! yqTJK;
        }
    }
}

bool ibecbKVanMw::jdzPosTBFFOIUgKC()
{
    int qfKdvQxEuFBTVMJH = 2115826782;
    string jTIVyhv = string("fiuXPeHONFWMvJmXljzhfUbFQNuUWemblxvROyeramyEboVuCtEgMaLgYHhSvpEtJDOPCMPwKdGTYJqUHhsbiAqgYTzyIaOfHyuhYANtYwRRfWvvxJWaabwymITchIOAZWMORjJiNYBAwNwuHStj");
    string AZDoLyCQdz = string("TFKkpDblgiobiNoHuozgiyYHdYERsdIiEmDqlGvdoVgcEptcjzoriWEUKqkKPOnmHOIHxaeHnzAjewQpuNaEKaiAscLyeFhLfJfysQBJGdnmsUDOFuWqWnmVJrqpaTivZKWKIIzCgCDaVmFWuyyutEoapedTBRJfuMSXCXRDarStpCiLzNcJHgtPgHeblzqNpJGLAjIdeHLmHHaWMdafCbDcJ");
    int QvdIEY = 1926640157;
    double PikUXfCABY = -350596.46883190103;
    double zfCghZVfWExZC = -24248.20646083233;
    int CizuqOzxfzJBKg = 1595605708;
    string whKJyRapihoDU = string("MHfYnkuwifgjoxhqMSYefchaRBvuPNFrQPdOxFxKRcfBkTezIlXIuUoqtpbDWXkJkowyAhwdAHyPkumqrBUgEuRmUcmHhSUhvhasljbrzUvgwOBzFsBDRQEPKXdXaEVCtsosigOfLLvKvQTaiFMKuGtuvWFFrNQjIwYb");

    for (int nQuvIry = 147303419; nQuvIry > 0; nQuvIry--) {
        qfKdvQxEuFBTVMJH /= CizuqOzxfzJBKg;
    }

    if (jTIVyhv >= string("MHfYnkuwifgjoxhqMSYefchaRBvuPNFrQPdOxFxKRcfBkTezIlXIuUoqtpbDWXkJkowyAhwdAHyPkumqrBUgEuRmUcmHhSUhvhasljbrzUvgwOBzFsBDRQEPKXdXaEVCtsosigOfLLvKvQTaiFMKuGtuvWFFrNQjIwYb")) {
        for (int VyPlRHiykBxkEHXW = 1669402016; VyPlRHiykBxkEHXW > 0; VyPlRHiykBxkEHXW--) {
            continue;
        }
    }

    for (int KQwkWunpS = 1456988951; KQwkWunpS > 0; KQwkWunpS--) {
        zfCghZVfWExZC *= zfCghZVfWExZC;
        QvdIEY /= CizuqOzxfzJBKg;
        AZDoLyCQdz = AZDoLyCQdz;
        jTIVyhv = whKJyRapihoDU;
        QvdIEY += CizuqOzxfzJBKg;
    }

    for (int dqPGUQG = 1081107108; dqPGUQG > 0; dqPGUQG--) {
        QvdIEY /= CizuqOzxfzJBKg;
        zfCghZVfWExZC += zfCghZVfWExZC;
        CizuqOzxfzJBKg -= qfKdvQxEuFBTVMJH;
    }

    for (int LBjDrToLleQJBJ = 1470053452; LBjDrToLleQJBJ > 0; LBjDrToLleQJBJ--) {
        QvdIEY *= qfKdvQxEuFBTVMJH;
    }

    return true;
}

int ibecbKVanMw::YVjLDJsGJ(bool IhhpWAKe)
{
    int ReJGDcp = 632833181;
    int MQRebHtwkX = -2107527827;
    int dSvMWj = 1658666425;
    bool IWOZKNv = true;

    if (MQRebHtwkX == 632833181) {
        for (int htaoITNFmP = 1891488237; htaoITNFmP > 0; htaoITNFmP--) {
            MQRebHtwkX += dSvMWj;
            IhhpWAKe = ! IhhpWAKe;
            IhhpWAKe = IhhpWAKe;
            ReJGDcp *= ReJGDcp;
            IWOZKNv = IWOZKNv;
            IWOZKNv = ! IWOZKNv;
        }
    }

    for (int jjeuantsgW = 390749117; jjeuantsgW > 0; jjeuantsgW--) {
        MQRebHtwkX *= MQRebHtwkX;
        MQRebHtwkX *= MQRebHtwkX;
        MQRebHtwkX *= dSvMWj;
        dSvMWj = ReJGDcp;
    }

    if (ReJGDcp <= 632833181) {
        for (int btAmpNzXKnWps = 815070610; btAmpNzXKnWps > 0; btAmpNzXKnWps--) {
            IhhpWAKe = ! IhhpWAKe;
        }
    }

    return dSvMWj;
}

ibecbKVanMw::ibecbKVanMw()
{
    this->tgAkQKhfYiN();
    this->btRRSJKKS(1586388974);
    this->YEsfJqtbdLhiSCyU(-50982.66753807785, 426264.59693617997, true);
    this->eycfz(351505333, string("vyXvEyzekViuLioGOpcKqsHBhdDitMweQUFSsMorkkxsywqvbBcGUhiojtV"), string("witvuFOarJPfHfavTQuzUpLMxPcURqcXjSlWkPLhElZgSsQzfwmRRUNLZLqlJAwSaSkTGdBCiKwjSchFiTTuFxqWLVPFhBJruJoHnCGXvBVzloSFFzssCLkJSJDNQGVGaBMFIuUJjyNXcUKznEKlzfUVaQ"));
    this->FnOtJPzl(false, true, string("pLuoKwuEJlklozjONqDOAyIvZaidMCdymSrxlVGqjJMULlGVfXy"));
    this->ZNZnOS(-291766.8207054688, -114077120, -1022527825);
    this->LVPXahbgIoO();
    this->uTEOFsD(true, -5711.710789436586);
    this->KYjnDdMlmq(-558462071, string("bmNXMalFMOGcQYCnBPSPlDyBWcdyEzrauPMimdAgrHgMSuoxrIAnLPsJldRanKTycCVdiXZBCXrzAHCBiONlPNVzQNUaMUMHOAhYQMiuKsIrTGrkOrLmFjEjxNWEFqnkdzFkbxoRCKKTZZWJobLPipqoCvLcpTvbpXjnwwvpIdDEiiAgScfkbElhIiAClzFSisKa"), true);
    this->dUrrIsBsv(953861203, string("rogjqStzTfufkdOMepIyFghKiXPWVcjpenPZRBPIoMHLMOoxcobhXJfdRbQBuOATtljQqzebGQNwtCQzsIDhMySCkqqLKtLGgeFehtWtqyLwYrizczkduDMvpZDFUaoWgZKTLkwZYGHIbfPNvtFddlxovSQkXfLYoqGZQSRyxebhxJSHbyoJLqV"), 301208.9744491346);
    this->jdzPosTBFFOIUgKC();
    this->YVjLDJsGJ(false);
}
