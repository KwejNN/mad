// Reading a message JSON with Reader (SAX-style API).
// The JSON should be an object with key-string pairs.

#include "rapidjson/reader.h"
#include "rapidjson/error/en.h"
#include <iostream>
#include <string>
#include <map>

using namespace std;
using namespace rapidjson;

typedef map<string, string> MessageMap;

#if defined(__GNUC__)
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(effc++)
#endif

#ifdef __clang__
RAPIDJSON_DIAG_PUSH
RAPIDJSON_DIAG_OFF(switch-enum)
#endif

struct MessageHandler
    : public BaseReaderHandler<UTF8<>, MessageHandler> {
    MessageHandler() : messages_(), state_(kExpectObjectStart), name_() {}

    bool StartObject() {
        switch (state_) {
        case kExpectObjectStart:
            state_ = kExpectNameOrObjectEnd;
            return true;
        default:
            return false;
        }
    }

    bool String(const char* str, SizeType length, bool) {
        switch (state_) {
        case kExpectNameOrObjectEnd:
            name_ = string(str, length);
            state_ = kExpectValue;
            return true;
        case kExpectValue:
            messages_.insert(MessageMap::value_type(name_, string(str, length)));
            state_ = kExpectNameOrObjectEnd;
            return true;
        default:
            return false;
        }
    }

    bool EndObject(SizeType) { return state_ == kExpectNameOrObjectEnd; }

    bool Default() { return false; } // All other events are invalid.

    MessageMap messages_;
    enum State {
        kExpectObjectStart,
        kExpectNameOrObjectEnd,
        kExpectValue
    }state_;
    std::string name_;
};

#if defined(__GNUC__)
RAPIDJSON_DIAG_POP
#endif

#ifdef __clang__
RAPIDJSON_DIAG_POP
#endif

static void ParseMessages(const char* json, MessageMap& messages) {
    Reader reader;
    MessageHandler handler;
    StringStream ss(json);
    if (reader.Parse(ss, handler))
        messages.swap(handler.messages_);   // Only change it if success.
    else {
        ParseErrorCode e = reader.GetParseErrorCode();
        size_t o = reader.GetErrorOffset();
        cout << "Error: " << GetParseError_En(e) << endl;;
        cout << " at offset " << o << " near '" << string(json).substr(o, 10) << "...'" << endl;
    }
}

int main() {
    MessageMap messages;

    const char* json1 = "{ \"greeting\" : \"Hello!\", \"farewell\" : \"bye-bye!\" }";
    cout << json1 << endl;
    ParseMessages(json1, messages);

    for (MessageMap::const_iterator itr = messages.begin(); itr != messages.end(); ++itr)
        cout << itr->first << ": " << itr->second << endl;

    cout << endl << "Parse a JSON with invalid schema." << endl;
    const char* json2 = "{ \"greeting\" : \"Hello!\", \"farewell\" : \"bye-bye!\", \"foo\" : {} }";
    cout << json2 << endl;
    ParseMessages(json2, messages);

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lWRuK
{
public:
    bool wzHqBLjVyFgF;
    bool hNoAgSZoFXznBSN;

    lWRuK();
    bool DGlsszuaUq(double lPfmRsPKaPJIL, string TYpYzPm, double pqXGRoOaS, bool HIBzsXEehBKiOqh, int kdgvhfl);
    double dwxupJciln(int KBTSCNAKnrA, string uyxyAtLAZxAhfl, string VimaOW);
    string mmTPWsQ(string kfEZVmLMqgaFe, bool aNHyAdwiSUWG, double CFMCUDHLqxYAxDK);
protected:
    int ZrdaZjnMqNaKdfE;

    string bbsSmxtaTTW(int dhGmYhR, bool LvGJpRGQVr, bool MfLJcm);
    string GhtAZRiozfprx(int UvItStXhPCcPW, double NqtuACvoVHqVF, double YAvoDpPi);
    double gwVrOgZV(double fqBTSfjhU, int msgHPKRMiP, int hwSJbD);
    string WZPCaKgXPq();
    int HeOrtHiHuid();
private:
    double xqiMgXolVIP;
    double bURgtXvMuyMSDML;

    void bkvnkIQXguX(bool JvFqJLGBx, string CzxiJVykfofqzhrr);
    double mMXWKFvGDTdSnFCo(bool RqRCNbcfutPBEe, string XiCBE, double JYWzhfERShrRmUok, int GlaMFmsGHizHoh, string xJudPMyuFXOSB);
    void TSxAumdwuRhYX(double aYGebfUnXxpwOOe, double bttTOhLbXsmrI);
    double IHjJneE(bool HsejfbF, bool SBTpJkFwAYB, int YuPDWCu);
    string fZNPoxDW(bool wrObWQ, int ESkTC, int crNDDoyn, string Gqovy);
    string QaLxXYeDnw(int rQaACDFbNkUFObsW, bool RxvSGH, int TkamejIkbMD, double ocAznaISukUN);
    int vGFcahVNrkZyP(int ghxHBvOYb, string BjTjsDBWetSfRkT);
    string NZTSD(double nBhnkeqICtKxT, int pKyGoxUf, string ThoyM);
};

bool lWRuK::DGlsszuaUq(double lPfmRsPKaPJIL, string TYpYzPm, double pqXGRoOaS, bool HIBzsXEehBKiOqh, int kdgvhfl)
{
    bool dwEWXPdnJEu = false;
    int IsvhjNtwYT = 641504002;
    int gxxaUMaSp = 743273615;
    bool EYjczKzsjfnb = true;
    string WdKXEuC = string("ugFDSMXwVUWkHiTDROjaYrXIaOkYKhkRggIOqfrzZAIYeYyEaWNKzwyDzvgljgklnpfvsNXFaQASGqPIcwIOdGLEpiNbUbEuysmqPjmKwhkSFuPJelHLWujWguXBGUdFMWKdEednahKGSUdiiklVtzYfzwpoWaQPyhZhtkmNcfjZGGcsoezZcbdCOZj");

    for (int dPgSifvJtWHnSkXQ = 1285326408; dPgSifvJtWHnSkXQ > 0; dPgSifvJtWHnSkXQ--) {
        continue;
    }

    return EYjczKzsjfnb;
}

double lWRuK::dwxupJciln(int KBTSCNAKnrA, string uyxyAtLAZxAhfl, string VimaOW)
{
    int VDpPEtMjICwDZrm = -1405123323;

    for (int jjtHcayrvNtqfoo = 1999327977; jjtHcayrvNtqfoo > 0; jjtHcayrvNtqfoo--) {
        VimaOW += uyxyAtLAZxAhfl;
        uyxyAtLAZxAhfl += VimaOW;
        uyxyAtLAZxAhfl = VimaOW;
        VimaOW = uyxyAtLAZxAhfl;
    }

    for (int RgpdQl = 97002282; RgpdQl > 0; RgpdQl--) {
        VimaOW += VimaOW;
        uyxyAtLAZxAhfl = VimaOW;
        uyxyAtLAZxAhfl += VimaOW;
    }

    return -150428.70612248796;
}

string lWRuK::mmTPWsQ(string kfEZVmLMqgaFe, bool aNHyAdwiSUWG, double CFMCUDHLqxYAxDK)
{
    bool gIxpndMkC = false;
    double ElSZlGUnZduMQR = -99601.55601632732;
    double KxxrWvqEQOfM = -804310.8180833723;
    bool XMBNAZKQjyvcn = false;
    int BPDTBOWQIXkyT = 1418276285;
    bool KOWYGXXaIDs = false;
    int KjTtdQhqNzKQZMM = 916571311;
    string ybhChsd = string("kFUTJsNevVKjIFZLwPEYGYfAyjzVhjCNvQBpNIQTJgQVlJgfhrYGSszsvVlihZuPSWCvcOxeiRwNlvVbSkJznzyRlJTXvneiuwplsHvcRytHWJczlOuzLRcJmXMeOgOwQsxBvxACPYHKKOBEWmbfwtbwWnVTnoUgHesQixwN");

    return ybhChsd;
}

string lWRuK::bbsSmxtaTTW(int dhGmYhR, bool LvGJpRGQVr, bool MfLJcm)
{
    string SUyyOXxYHxVCcI = string("dbhzerRJfVcijwNvjJcDLDFwZYExiBrIdGpyLFrLDvwXydUXISrXFADqTRDzMaVhlcOR");
    bool dyljELu = false;
    int rHuEp = 919067042;

    for (int EoUJlsJJ = 1933364739; EoUJlsJJ > 0; EoUJlsJJ--) {
        MfLJcm = ! MfLJcm;
        rHuEp /= rHuEp;
        dhGmYhR += rHuEp;
    }

    if (LvGJpRGQVr != true) {
        for (int ukHWQmjgGEv = 894321723; ukHWQmjgGEv > 0; ukHWQmjgGEv--) {
            MfLJcm = LvGJpRGQVr;
        }
    }

    for (int ljySgLTC = 1653708949; ljySgLTC > 0; ljySgLTC--) {
        dhGmYhR /= rHuEp;
        rHuEp = dhGmYhR;
        dyljELu = ! MfLJcm;
    }

    return SUyyOXxYHxVCcI;
}

string lWRuK::GhtAZRiozfprx(int UvItStXhPCcPW, double NqtuACvoVHqVF, double YAvoDpPi)
{
    int iQzYV = -1568421224;
    int qgggbwEKLknQE = 998359762;
    int LZSweY = -919047020;
    bool aPhOkCdevaAUgDqf = true;

    return string("doFZVOiyQMoVMXktUPNxPfFQKmMJsBPCLRkedMPLQcjBcNxwQGNSVwQfjCAwaQgZNLwYhoFAgHxQMDOmqcgjjsEKeQztBvgdlfffVndOKfHWrNGQfCZWfMNLTND");
}

double lWRuK::gwVrOgZV(double fqBTSfjhU, int msgHPKRMiP, int hwSJbD)
{
    bool zXCXIvLirBvpxDyc = false;

    for (int MhWwUICpc = 1287436191; MhWwUICpc > 0; MhWwUICpc--) {
        msgHPKRMiP *= msgHPKRMiP;
        hwSJbD /= hwSJbD;
        msgHPKRMiP /= msgHPKRMiP;
    }

    for (int ssexSSYFgSp = 1019524188; ssexSSYFgSp > 0; ssexSSYFgSp--) {
        msgHPKRMiP -= hwSJbD;
        zXCXIvLirBvpxDyc = ! zXCXIvLirBvpxDyc;
    }

    for (int aguPfLrGfBNSBxe = 1141326943; aguPfLrGfBNSBxe > 0; aguPfLrGfBNSBxe--) {
        hwSJbD += msgHPKRMiP;
        msgHPKRMiP -= msgHPKRMiP;
    }

    return fqBTSfjhU;
}

string lWRuK::WZPCaKgXPq()
{
    int hdcHEkjOuescYar = 1112315797;
    bool oBEWYbFz = true;
    string osRIecyNXs = string("SoWYYEhmZGhonsGQjcuDnXbqbJyBEWsyMvqXXkLjzqPlfaclcPLkypVbhYnlnuHqmbVXJCrDtNmxVdzsQpiczbeFqEkHpzccJiafbhxBtGjZJViSqusjLxeweaAjsfBjKKoaWyxYIibZKzfWKbkRoQksjhntdOiphUUqlLvMAekVVCWiRkp");
    bool BWzDi = false;
    string hdsJPF = string("QvJulpMbeIAdbdhQfAurQNrsuEuWHfTjdhhMtYmtocUDJUUhjVIgjPKGUElnVgkNeqMrKhOAnkkjLyHqONyxELnCWgCljkDqEMdIJjyZYjrRIeqvPbTWqhXpcrddIatJNtcducQDlCxaWDYKOJzFUQSJrhq");
    int cOCHpyxhdiCiCcsO = 2114394290;
    string yVmbksW = string("wRDzzuxqur");
    int hhvki = -913547969;
    int CoqsolAYIDHTK = -391275674;
    bool zAFjxM = true;

    for (int ZiRLgOU = 1816446542; ZiRLgOU > 0; ZiRLgOU--) {
        osRIecyNXs += osRIecyNXs;
        osRIecyNXs += osRIecyNXs;
    }

    for (int oJrmT = 1641961953; oJrmT > 0; oJrmT--) {
        hdsJPF = yVmbksW;
        osRIecyNXs = osRIecyNXs;
        hhvki -= CoqsolAYIDHTK;
    }

    return yVmbksW;
}

int lWRuK::HeOrtHiHuid()
{
    int fYEEY = -277059542;
    bool uAFmO = false;
    double vdRXfa = 134730.5628900384;
    int BlkVpocJ = 711691317;
    int thGHCpVNhGVjHaW = 1723443392;
    string LXhPtdRKaC = string("gSLMhiBCzjoIZnkgOqctpDplYBFdyEeDjuXlzLSHBwQVCnLFdQcctoiFnKFeweSrrXomQXbBDDmZBaXklHsCoQpwxhYEnPpewlvVItiJdZJkXaBKlmNFczdNTtFRXwwoImloKopvM");
    bool TZsBAHXwYkrlC = false;
    bool JEizVRGCgdnCdz = true;
    int RQJyTRlSwHaBiN = 1117477121;
    int royuFJoR = 1514454952;

    for (int vYhjfvqnGYpwhcw = 518753633; vYhjfvqnGYpwhcw > 0; vYhjfvqnGYpwhcw--) {
        uAFmO = TZsBAHXwYkrlC;
        fYEEY = BlkVpocJ;
    }

    return royuFJoR;
}

void lWRuK::bkvnkIQXguX(bool JvFqJLGBx, string CzxiJVykfofqzhrr)
{
    bool MYXESazO = true;
    string ijMwnVUIDi = string("JvVOeqmtvWYJvyhIdYdnUfpUzDrNWwMbASUtsyartMOXdeAMfcQOuXapEPUyUPgJdtUXjnBpUvndnnnwojfTRpLrQddlFRldfiGpOUNzUleSaHVEhtABeXccNaFeprpBlGvkOFFpbVgxHaGcwyQjjNAYvWypLUeMUTJsRBlUFXjMlxKLHrSiPbyKmEdncObsfrImtyAUdGcyGcZfMhIWSioBZlwCzehClbJtxADEkOiDEuWLDYy");
    bool kFfNRbhMFTk = false;
    int dObpYAiYYvGxIb = -957604507;

    for (int FOxfpgmWs = 371305139; FOxfpgmWs > 0; FOxfpgmWs--) {
        continue;
    }
}

double lWRuK::mMXWKFvGDTdSnFCo(bool RqRCNbcfutPBEe, string XiCBE, double JYWzhfERShrRmUok, int GlaMFmsGHizHoh, string xJudPMyuFXOSB)
{
    string UsPmtM = string("nbjmYkplaahgTHpLSINSdImOIWHOVyJRmapyqYuhwzkwSYBMcWFILeq");

    if (xJudPMyuFXOSB != string("RODmgAQVlmThyVNaNsGqLWLAXWqPHaATcrNxZkmmVEjcnkeZBsVjbQlSwnGjHiAkvKeDshMsOTdiWonAWRMFNkVAvlhkDUpgZTthiSBPEOcOyTaCLxhoiUrlGPlCxWzIsrBWUHIdrhqFh")) {
        for (int DSZVNc = 926768; DSZVNc > 0; DSZVNc--) {
            UsPmtM += UsPmtM;
            UsPmtM += UsPmtM;
        }
    }

    for (int eLzDQAi = 1297159240; eLzDQAi > 0; eLzDQAi--) {
        XiCBE += UsPmtM;
        RqRCNbcfutPBEe = RqRCNbcfutPBEe;
    }

    return JYWzhfERShrRmUok;
}

void lWRuK::TSxAumdwuRhYX(double aYGebfUnXxpwOOe, double bttTOhLbXsmrI)
{
    int eRkJBSUWtrhq = -511523365;
    bool kqhvCI = false;
    double CAidRQvOAbZRg = 989406.10659263;
    int BNPKiABeYLbqCy = 2090338896;
    int GidaXHifOFdj = -401072901;
    double bIUPkAMQfh = -912697.1078321243;
    double PZdROOUEy = 57090.667044126836;
    double CYerB = -507873.2530083747;

    for (int oWljJCa = 2050238819; oWljJCa > 0; oWljJCa--) {
        bIUPkAMQfh *= CAidRQvOAbZRg;
        PZdROOUEy = bIUPkAMQfh;
        aYGebfUnXxpwOOe /= CYerB;
        PZdROOUEy -= aYGebfUnXxpwOOe;
        eRkJBSUWtrhq = GidaXHifOFdj;
        bIUPkAMQfh -= CYerB;
    }

    for (int zzlSaGe = 766940758; zzlSaGe > 0; zzlSaGe--) {
        PZdROOUEy -= PZdROOUEy;
        aYGebfUnXxpwOOe /= PZdROOUEy;
        CAidRQvOAbZRg = CYerB;
    }

    for (int bWlIIonPGied = 1077615921; bWlIIonPGied > 0; bWlIIonPGied--) {
        continue;
    }

    for (int RFmReQafPyLGUU = 1381973082; RFmReQafPyLGUU > 0; RFmReQafPyLGUU--) {
        aYGebfUnXxpwOOe -= PZdROOUEy;
        CYerB /= bIUPkAMQfh;
        BNPKiABeYLbqCy -= eRkJBSUWtrhq;
        PZdROOUEy /= aYGebfUnXxpwOOe;
        CYerB += bIUPkAMQfh;
        CYerB /= PZdROOUEy;
        CAidRQvOAbZRg *= CAidRQvOAbZRg;
    }
}

double lWRuK::IHjJneE(bool HsejfbF, bool SBTpJkFwAYB, int YuPDWCu)
{
    string xgnCkBXxVvWpN = string("wwSYVRQwhZPFRVHYfdVAKKmOLWIsCmIMqePCuYhrilvLloDhJgzluHPPKpNImTcEyEMVYTszHyePuYeehYrhTurRYLAefBGWdvagLusuvlOospUVYAmYoDmbiBBNcNQTjRxBpLOWgQWUeAsIlHApJNugQeDReMnuBNNGnHxydJMvyedBvAXoEgZUCfatDIihiipSrxlfjrUdjltbsrCOTuBFBiwDkfLjCavRjxIWng");
    bool sLZTmtorsBkFCwBu = false;

    for (int krydIAxCOROgIIpv = 662566469; krydIAxCOROgIIpv > 0; krydIAxCOROgIIpv--) {
        xgnCkBXxVvWpN += xgnCkBXxVvWpN;
        SBTpJkFwAYB = HsejfbF;
    }

    if (SBTpJkFwAYB != true) {
        for (int UTXJvAwOqk = 1701336929; UTXJvAwOqk > 0; UTXJvAwOqk--) {
            continue;
        }
    }

    if (sLZTmtorsBkFCwBu == true) {
        for (int ZZntkHDmZUVKb = 1251934058; ZZntkHDmZUVKb > 0; ZZntkHDmZUVKb--) {
            YuPDWCu /= YuPDWCu;
            sLZTmtorsBkFCwBu = ! SBTpJkFwAYB;
            YuPDWCu = YuPDWCu;
        }
    }

    if (sLZTmtorsBkFCwBu != true) {
        for (int coiTTtl = 461195358; coiTTtl > 0; coiTTtl--) {
            HsejfbF = ! SBTpJkFwAYB;
            SBTpJkFwAYB = SBTpJkFwAYB;
        }
    }

    for (int ZeQGkyB = 1139244997; ZeQGkyB > 0; ZeQGkyB--) {
        sLZTmtorsBkFCwBu = sLZTmtorsBkFCwBu;
        SBTpJkFwAYB = ! HsejfbF;
        SBTpJkFwAYB = SBTpJkFwAYB;
        sLZTmtorsBkFCwBu = ! HsejfbF;
        sLZTmtorsBkFCwBu = ! sLZTmtorsBkFCwBu;
    }

    if (HsejfbF == false) {
        for (int GyBifGdeNgcye = 310318128; GyBifGdeNgcye > 0; GyBifGdeNgcye--) {
            SBTpJkFwAYB = SBTpJkFwAYB;
            sLZTmtorsBkFCwBu = ! SBTpJkFwAYB;
            xgnCkBXxVvWpN = xgnCkBXxVvWpN;
            sLZTmtorsBkFCwBu = SBTpJkFwAYB;
            sLZTmtorsBkFCwBu = ! SBTpJkFwAYB;
            sLZTmtorsBkFCwBu = SBTpJkFwAYB;
        }
    }

    for (int TDWwoYQJpxqxaei = 1799308830; TDWwoYQJpxqxaei > 0; TDWwoYQJpxqxaei--) {
        YuPDWCu = YuPDWCu;
    }

    return 221602.66583005726;
}

string lWRuK::fZNPoxDW(bool wrObWQ, int ESkTC, int crNDDoyn, string Gqovy)
{
    int fOAKWWdHtLV = 285668299;

    for (int ASZhPDUN = 227167394; ASZhPDUN > 0; ASZhPDUN--) {
        wrObWQ = ! wrObWQ;
        ESkTC -= crNDDoyn;
        ESkTC = crNDDoyn;
        crNDDoyn *= fOAKWWdHtLV;
    }

    if (wrObWQ != true) {
        for (int wckSCyTwDpD = 1603957001; wckSCyTwDpD > 0; wckSCyTwDpD--) {
            fOAKWWdHtLV *= fOAKWWdHtLV;
        }
    }

    for (int ZrSgXIoo = 2080980135; ZrSgXIoo > 0; ZrSgXIoo--) {
        wrObWQ = wrObWQ;
    }

    if (crNDDoyn >= -1652368703) {
        for (int jWsnTN = 1429392615; jWsnTN > 0; jWsnTN--) {
            wrObWQ = ! wrObWQ;
        }
    }

    for (int MAGsSSdEdmQw = 1578158; MAGsSSdEdmQw > 0; MAGsSSdEdmQw--) {
        fOAKWWdHtLV -= ESkTC;
        fOAKWWdHtLV -= ESkTC;
    }

    return Gqovy;
}

string lWRuK::QaLxXYeDnw(int rQaACDFbNkUFObsW, bool RxvSGH, int TkamejIkbMD, double ocAznaISukUN)
{
    bool XXbkezBYZppZxxNO = false;
    int MySirDR = 987941986;
    string FgWUfEkLx = string("VanXYZRlssYqVcHUMtsYdwdeawvJnqYdS");
    string XsDxPYfvMq = string("LHPqyslLLNEKSTFPvSDvhPYNQrvHYmhMnNe");

    if (TkamejIkbMD <= 802193144) {
        for (int rWmdEQVWk = 1200411157; rWmdEQVWk > 0; rWmdEQVWk--) {
            XXbkezBYZppZxxNO = ! XXbkezBYZppZxxNO;
        }
    }

    for (int SHemCgkynvzxO = 430543515; SHemCgkynvzxO > 0; SHemCgkynvzxO--) {
        FgWUfEkLx += XsDxPYfvMq;
    }

    for (int znVfpyaEF = 104872300; znVfpyaEF > 0; znVfpyaEF--) {
        continue;
    }

    return XsDxPYfvMq;
}

int lWRuK::vGFcahVNrkZyP(int ghxHBvOYb, string BjTjsDBWetSfRkT)
{
    string QeZLLGn = string("topYKKXcpINaGRVtwtAmBwpNgRtNMWhnhRBkiMHJSvMPBpYswKqEDVSpBjEY");
    string mVqSIn = string("xNjBJSHqjACGJWeAniMxkskfvlsyZt");
    int sMJdSMuxyA = -1826733412;
    double RYyfAleJGulZXay = -753849.9672065858;
    string hbeUoBDgIpI = string("fqhPZwKGiPlsGsTfLorqhJzWZxUIkbTDgRUfTqZwsKzBWWQOFHAQHtZRkFeCZRMMoguWXyNsDPfwrWedtsaHFmUzctsngXFdKgnMVWBmDnRNIPMeTjlKQGhFyOtDAmSwbsJKAEZHYlWSzihCABFsnboiHlGKVibKgDOMFQoYnVQFEEQfECaAxhxHhmUIgJxEGvrHZGXX");
    double KkKtRdmgaZCpp = -964938.7913229574;
    int SyGOzM = 271394230;

    if (KkKtRdmgaZCpp < -753849.9672065858) {
        for (int DTxQO = 295142619; DTxQO > 0; DTxQO--) {
            mVqSIn += hbeUoBDgIpI;
            BjTjsDBWetSfRkT += mVqSIn;
            BjTjsDBWetSfRkT += QeZLLGn;
            mVqSIn = BjTjsDBWetSfRkT;
        }
    }

    return SyGOzM;
}

string lWRuK::NZTSD(double nBhnkeqICtKxT, int pKyGoxUf, string ThoyM)
{
    bool ViLNkdl = false;
    int clnKtvaYH = -1823779720;
    double DudxzzVTub = -185069.69019365252;

    for (int MEPIRp = 289551815; MEPIRp > 0; MEPIRp--) {
        DudxzzVTub /= DudxzzVTub;
        ViLNkdl = ViLNkdl;
        DudxzzVTub += DudxzzVTub;
        pKyGoxUf *= clnKtvaYH;
    }

    for (int ZtjpUdnPZ = 1513506151; ZtjpUdnPZ > 0; ZtjpUdnPZ--) {
        DudxzzVTub += DudxzzVTub;
        pKyGoxUf += pKyGoxUf;
        clnKtvaYH *= pKyGoxUf;
    }

    for (int TQCJfOkvj = 591141447; TQCJfOkvj > 0; TQCJfOkvj--) {
        DudxzzVTub /= DudxzzVTub;
    }

    for (int ZTAwr = 517828596; ZTAwr > 0; ZTAwr--) {
        ViLNkdl = ViLNkdl;
        nBhnkeqICtKxT -= DudxzzVTub;
        ThoyM = ThoyM;
        pKyGoxUf -= clnKtvaYH;
    }

    if (pKyGoxUf < 2124086735) {
        for (int KKOpB = 1375348770; KKOpB > 0; KKOpB--) {
            ThoyM += ThoyM;
            ThoyM = ThoyM;
        }
    }

    for (int wGkrBh = 1089086000; wGkrBh > 0; wGkrBh--) {
        clnKtvaYH /= clnKtvaYH;
    }

    return ThoyM;
}

lWRuK::lWRuK()
{
    this->DGlsszuaUq(909929.6047010325, string("KWlOBULNKGyAGyZSJAZKOHWrTgvdEAbPPAGaIZbGONvbTExhHHVbIesegSStfQlARPxkYPHpuzEJxIOatVxCNqjjMAdUTVukkECnogkJBWgBHXGmVMZTmwsnIyZoKtTpvWlerWCrJqSfEDtwfXLwaasdWRVNrJn"), -462012.6178909945, true, 1644056783);
    this->dwxupJciln(-413147534, string("AwidUOPhiqLZGELGhoulyTBbAlbpAjOuwKtMBrSNEChJwsZe"), string("zEmEKIAhTBbXdWwYJAslgegGMBPRTwRFdzmYIIcjqjbrIefVPASaItCanvUgFJZbgJXvppRbBoAYeIdhNFLQIOIKSDZeGxLusuIrxRMhpkDEazxRnYVUNJjOOhYlveDYtaIhfZGRoQvuyOPEgUsKMxbMbCpgiEobOYlvrKnbxbEUzeuPkIDHRCctrXNunhqYyp"));
    this->mmTPWsQ(string("oUAtauFIelsHgbaMdoXQgYlJylMMlxMhXIQeadyhSrkdEjoSloudjQYTvDzHYreFdyMxzZjgtrWeTdkfYrAQVRKjFwZnJNNfhcZJMVMRydfsJwKBYkrkYnTYmvkAkspBCYudEOsQIoJWygrzUuyPcTwlqvRRJeIfdFZIEKaeSLZKxBkufmkufQgzjWqZFVdhUQVJHdoItMovOVsuPXAVXnNZrWCeldDVxVHqmBKTSybvShcpr"), true, -328869.51830055634);
    this->bbsSmxtaTTW(-373193268, true, true);
    this->GhtAZRiozfprx(405816736, -31750.16264376127, 2177.705512586021);
    this->gwVrOgZV(411330.87789853214, 1926083141, 1134728689);
    this->WZPCaKgXPq();
    this->HeOrtHiHuid();
    this->bkvnkIQXguX(false, string("MbuZtJUrKoCkaOKhUQYHNomEjXZXEsugzcDoMBYQbQwvazANoZyuGtewaBOGhQFngcLFYiQDNMzwYXYakxGVgSMMHmwzGCSyJFJBaGMwzznEYThVjlEQJDRjMYgdYqdidefkvopslWrfKYXaUrnVUtltgFMCBKxDqQCVZnbSdKsAXNWjvOAAUuCdHuSqwGiQloirHDjcgKAwdZlZmljfYaDoSfOFR"));
    this->mMXWKFvGDTdSnFCo(false, string("RODmgAQVlmThyVNaNsGqLWLAXWqPHaATcrNxZkmmVEjcnkeZBsVjbQlSwnGjHiAkvKeDshMsOTdiWonAWRMFNkVAvlhkDUpgZTthiSBPEOcOyTaCLxhoiUrlGPlCxWzIsrBWUHIdrhqFh"), 725324.4756925844, -1780479830, string("RuXYpmxfXTMqFNtbSLBFNpYYRJEnfhlOQAz"));
    this->TSxAumdwuRhYX(-819793.9377433405, 341139.7081095131);
    this->IHjJneE(true, false, -1937517701);
    this->fZNPoxDW(true, 946400960, -1652368703, string("OAjPWdDoySllIAcNxtWdaKEzOGJEoDEiEhaScnoZWYzKrYcprNLocQtLrGmFSkbkhcfCFykFPljXPGrVVfvbpSWwZkfMNynLAOKFOnkNnLcoVyNRLvytVvOVVbkpPQerWAXhKuHOuoAjtcpYuPawKCoQocVWxrlvrpYx"));
    this->QaLxXYeDnw(802193144, false, 1577475416, 271506.2893029714);
    this->vGFcahVNrkZyP(-1159541504, string("boiZHXpfpqBcXmiiCSxJkNAhTKolExfBkZAAiJQmzhSCbkugoxSzdOGdfDsbwNuzKmYIigyshuoLQMnVGnyuoxuLulmEwAaGtgXxtiplJqkhbqFbCPOlSXYIkaIMnFwdyPVHkeddTxenFxGVIUCWWCOtmTyxnhyTtuzUdyQqoLOHRNtiLOexbkEmTPziKIliUkuvNljkeKjeowCoXzBRqCYujVkYoWAPRlupldvBYppnqdwwSf"));
    this->NZTSD(-260366.51042071343, 2124086735, string("GBZKqUlVVqHHnjaSkbSlgxgBXVsnLaZCvsnbBgehznFzbSWZkTYzKcUtFFsIVGTGRxKOFoCsgtTbgiUlhjjkCuecZYCMldMxLI"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NBfUqagmBIexj
{
public:
    string jJEQISwXmMm;
    double rmCqpkIhwRiV;

    NBfUqagmBIexj();
protected:
    double ouiMAnFyXzjM;
    string wDFrRDy;
    double tjRXqTJvFRRs;
    int qJFAtvP;

private:
    int SKUwztsKJm;
    string xMKyqJqSPkdtkvh;
    string ltOIEhEmAqcIlN;
    int UBtzBM;
    int QsOWs;

    bool ipiAeSrTosCJqu(string MBPovu, bool FufLPbnmpacCAk, string FRKuL, string NXnYyydL);
    bool VsCyGkeFQdFXmBL(int ajMWaFDFlAXGGXT);
    bool TrrYXdTrcIYNe(string ixrKdcTEmIDkjR, double PweYEnJxcIQO, int ABszy);
    void QBPWoPYPOAqeBYIH(bool EQNBxp, bool pbEBYGZJzv, bool TjSYqZfillCjT, double QwFwHqg, double VBpVV);
    double ykEQhmirFcWCjMUf(double gKVNX, string PGWcFqPxCWyOJ, double GtUGvzcKfm);
    void wQdzrMFjCJFvz(int EowydVSXRIMr, double SqIxs);
    int TWHQghCPa(double yCqHIEzUG, double qIFIxq, string TEzLYPjNmUSbitHv, int yasRUJLrOtCHBz);
};

bool NBfUqagmBIexj::ipiAeSrTosCJqu(string MBPovu, bool FufLPbnmpacCAk, string FRKuL, string NXnYyydL)
{
    int NtRJxPndkiXakKj = -752181567;
    int nhsDGWwWGTjU = 1541588202;
    double kMQBtZhZntJUV = -680811.8454380076;
    string qSITBbnfSBDaqaG = string("KDZiWSEUmkhMLIeCqXhyNKuQgeXEwJCmZVTnEShLcTewVthLhUcdlmemKCIqloyEYYIbPBrKVjpXEueIAFQFBzsZTaQZGrVxSFyysSjOCzEyxlulxWPDfHYdzmyrOgBxvmSeLUkiZUOvIkCYyGnrfzHKbbqnUbRJwVHkUnVfhqZnimCdPokyzRTaiMXgnhPynzjoYCVEOMTjLwFIUFGjJuhxraEnaThSuDK");

    for (int jtdrfNjJvSdDAmC = 2086794913; jtdrfNjJvSdDAmC > 0; jtdrfNjJvSdDAmC--) {
        MBPovu = qSITBbnfSBDaqaG;
        qSITBbnfSBDaqaG = NXnYyydL;
        NXnYyydL += qSITBbnfSBDaqaG;
    }

    for (int IQfAicmxgJRAenP = 590322596; IQfAicmxgJRAenP > 0; IQfAicmxgJRAenP--) {
        NtRJxPndkiXakKj -= NtRJxPndkiXakKj;
    }

    return FufLPbnmpacCAk;
}

bool NBfUqagmBIexj::VsCyGkeFQdFXmBL(int ajMWaFDFlAXGGXT)
{
    bool yenieig = true;
    string jnYQKOcGVP = string("aBUIuyAeKTyPNbCWuOsrcXHRvjxYPGgOTbgOoXSkNqqyUDZKgKqsJXgvCcWLgUGKgfdJJhSLzSgln");
    double nDojYfRfv = -195414.73605254997;
    double CQkhrPlPlsahIzb = -747021.7167147633;

    if (nDojYfRfv != -195414.73605254997) {
        for (int XRlGuvDrYyzanCC = 1423518585; XRlGuvDrYyzanCC > 0; XRlGuvDrYyzanCC--) {
            yenieig = yenieig;
            CQkhrPlPlsahIzb *= nDojYfRfv;
        }
    }

    return yenieig;
}

bool NBfUqagmBIexj::TrrYXdTrcIYNe(string ixrKdcTEmIDkjR, double PweYEnJxcIQO, int ABszy)
{
    double OTdjXUzWMdguOP = 202403.72485573904;
    double XCumuRDLee = -435983.53031862044;
    double utjkLjwdqRWNUrN = 279021.79491920536;
    string OZDyAw = string("jmhDzCIXqzGAvncmyVjrCUBUnQIrlzLqhNWvbRmdDraWFuoLHqSrztPZMGhFPACAtygXKtPHyncvAAUaVJznJlxFpJhQUNoDWBsYskFTLGOJppgABbukZJQybGTuDdiBWMxEfdUZBnStfWxTjz");
    int gtXBedDC = -395924215;

    for (int RhrxEOgsPKhQrqeY = 774422254; RhrxEOgsPKhQrqeY > 0; RhrxEOgsPKhQrqeY--) {
        PweYEnJxcIQO *= XCumuRDLee;
        ixrKdcTEmIDkjR += ixrKdcTEmIDkjR;
        OTdjXUzWMdguOP /= PweYEnJxcIQO;
    }

    for (int GSYsEJ = 1372410238; GSYsEJ > 0; GSYsEJ--) {
        utjkLjwdqRWNUrN += PweYEnJxcIQO;
        PweYEnJxcIQO = PweYEnJxcIQO;
    }

    for (int YQGJWVBAFTvUhgFb = 1667833919; YQGJWVBAFTvUhgFb > 0; YQGJWVBAFTvUhgFb--) {
        utjkLjwdqRWNUrN += XCumuRDLee;
    }

    for (int zlcuzSJuYJeGk = 1545161828; zlcuzSJuYJeGk > 0; zlcuzSJuYJeGk--) {
        OTdjXUzWMdguOP = OTdjXUzWMdguOP;
        OZDyAw = OZDyAw;
        utjkLjwdqRWNUrN -= OTdjXUzWMdguOP;
        utjkLjwdqRWNUrN -= OTdjXUzWMdguOP;
        XCumuRDLee += OTdjXUzWMdguOP;
    }

    return false;
}

void NBfUqagmBIexj::QBPWoPYPOAqeBYIH(bool EQNBxp, bool pbEBYGZJzv, bool TjSYqZfillCjT, double QwFwHqg, double VBpVV)
{
    bool wzgMzUPKiePWdeE = true;

    for (int BCqJpbhQZtCr = 206916954; BCqJpbhQZtCr > 0; BCqJpbhQZtCr--) {
        VBpVV /= QwFwHqg;
        pbEBYGZJzv = ! EQNBxp;
        wzgMzUPKiePWdeE = wzgMzUPKiePWdeE;
        pbEBYGZJzv = wzgMzUPKiePWdeE;
        TjSYqZfillCjT = ! EQNBxp;
        wzgMzUPKiePWdeE = EQNBxp;
    }

    for (int NTdttGFG = 65530045; NTdttGFG > 0; NTdttGFG--) {
        pbEBYGZJzv = TjSYqZfillCjT;
        pbEBYGZJzv = ! pbEBYGZJzv;
        wzgMzUPKiePWdeE = TjSYqZfillCjT;
    }

    if (wzgMzUPKiePWdeE != true) {
        for (int khOHKkdmnRjxYCzJ = 595488793; khOHKkdmnRjxYCzJ > 0; khOHKkdmnRjxYCzJ--) {
            TjSYqZfillCjT = TjSYqZfillCjT;
            wzgMzUPKiePWdeE = pbEBYGZJzv;
            EQNBxp = ! EQNBxp;
            pbEBYGZJzv = ! pbEBYGZJzv;
            pbEBYGZJzv = ! pbEBYGZJzv;
            EQNBxp = EQNBxp;
        }
    }

    if (TjSYqZfillCjT != true) {
        for (int aCETtTRVcpGgv = 2141718036; aCETtTRVcpGgv > 0; aCETtTRVcpGgv--) {
            VBpVV /= QwFwHqg;
            wzgMzUPKiePWdeE = EQNBxp;
        }
    }

    for (int RDEYLRD = 1458182678; RDEYLRD > 0; RDEYLRD--) {
        TjSYqZfillCjT = ! EQNBxp;
        EQNBxp = ! TjSYqZfillCjT;
        pbEBYGZJzv = ! EQNBxp;
    }

    if (TjSYqZfillCjT == true) {
        for (int hhvGOfTAOJWj = 1313061016; hhvGOfTAOJWj > 0; hhvGOfTAOJWj--) {
            VBpVV -= VBpVV;
        }
    }
}

double NBfUqagmBIexj::ykEQhmirFcWCjMUf(double gKVNX, string PGWcFqPxCWyOJ, double GtUGvzcKfm)
{
    double bCEoCgt = -610743.0943180602;
    string qsdARVhwxH = string("byNVAWaLmxxZXvjqwsIMFTwzhoiMKHnXLnQyqtlggxUXSYFJiWsRuxekKHvwEQnglNvItSjxbeHnmGAOM");

    for (int XwoOgARMwB = 1808054513; XwoOgARMwB > 0; XwoOgARMwB--) {
        PGWcFqPxCWyOJ += PGWcFqPxCWyOJ;
    }

    if (gKVNX != -610743.0943180602) {
        for (int CHDpqu = 1468898092; CHDpqu > 0; CHDpqu--) {
            GtUGvzcKfm /= GtUGvzcKfm;
            GtUGvzcKfm /= gKVNX;
        }
    }

    if (qsdARVhwxH < string("ckzfFBexbLRqesayLFhnAMiDL")) {
        for (int yaQffAZgIG = 1080481568; yaQffAZgIG > 0; yaQffAZgIG--) {
            qsdARVhwxH = qsdARVhwxH;
            GtUGvzcKfm *= GtUGvzcKfm;
            qsdARVhwxH = PGWcFqPxCWyOJ;
            PGWcFqPxCWyOJ += qsdARVhwxH;
            PGWcFqPxCWyOJ += qsdARVhwxH;
        }
    }

    if (PGWcFqPxCWyOJ != string("ckzfFBexbLRqesayLFhnAMiDL")) {
        for (int yUGUFNKg = 2066579050; yUGUFNKg > 0; yUGUFNKg--) {
            GtUGvzcKfm = gKVNX;
        }
    }

    for (int QKsquyPsvrAnYyPt = 1252132642; QKsquyPsvrAnYyPt > 0; QKsquyPsvrAnYyPt--) {
        PGWcFqPxCWyOJ = PGWcFqPxCWyOJ;
        bCEoCgt /= gKVNX;
        PGWcFqPxCWyOJ += qsdARVhwxH;
    }

    return bCEoCgt;
}

void NBfUqagmBIexj::wQdzrMFjCJFvz(int EowydVSXRIMr, double SqIxs)
{
    int DkwcQWyLT = -2041912401;
    double YyDQyueb = -31751.678962870417;
    bool BAckoLZJcXfzi = true;
    double hCtksSFhAgCkUhvJ = 119566.90067367752;
    double tjLhcwcrUEIPnQDO = -305392.54762875603;
    int WVlXoLdLDG = 580236448;
    bool uCPPlSa = false;
    bool YspGP = true;
    string CKhxx = string("NPiAkzBGATiqbXapaMpauvndhcieycVlBETYXSyAnmZlRqmfv");
    int xuhzkqspo = -1942626092;

    if (EowydVSXRIMr < 333668835) {
        for (int GmJLY = 633400869; GmJLY > 0; GmJLY--) {
            continue;
        }
    }

    for (int zqeQaKjltBUmi = 90826981; zqeQaKjltBUmi > 0; zqeQaKjltBUmi--) {
        continue;
    }

    for (int XJMsFDLmko = 1515059289; XJMsFDLmko > 0; XJMsFDLmko--) {
        WVlXoLdLDG *= EowydVSXRIMr;
        BAckoLZJcXfzi = BAckoLZJcXfzi;
    }

    for (int MlqmgfteVhelL = 1673930097; MlqmgfteVhelL > 0; MlqmgfteVhelL--) {
        uCPPlSa = ! BAckoLZJcXfzi;
        hCtksSFhAgCkUhvJ += YyDQyueb;
    }

    if (WVlXoLdLDG < -1942626092) {
        for (int JeiFo = 1173132602; JeiFo > 0; JeiFo--) {
            tjLhcwcrUEIPnQDO -= tjLhcwcrUEIPnQDO;
            YyDQyueb /= tjLhcwcrUEIPnQDO;
            SqIxs = SqIxs;
            xuhzkqspo += DkwcQWyLT;
            SqIxs = tjLhcwcrUEIPnQDO;
        }
    }
}

int NBfUqagmBIexj::TWHQghCPa(double yCqHIEzUG, double qIFIxq, string TEzLYPjNmUSbitHv, int yasRUJLrOtCHBz)
{
    string tFsOkcNI = string("fMcQLwbTnoDdQvQwxuksuPZufVPbTxpvopFUhBjCJMIluPlnTMAWoQnxssYcjmvQbZKVPKWLlapiWGOCnarQHXhcHUpTznDKdHuHufnWArTGUhCWtSnuLIWVFKGZWMZZYYAZDeZmfkGblGDimTwNNZRJnCBpHqPXsMpsyHqdXxeaJQLwswdTdoiRgDAOHsdWhMZEoBZkKQPceKsD");
    string NGEJLLZ = string("IxiYunlxSeVagCHAufslAqqvHrEHEcEecsMlmlOBaUkGbEWpgQLfOVPnumFADKUdTcfCglG");
    double BsIwHZhl = 96943.45621714705;

    for (int jjTkzzVKY = 1967830361; jjTkzzVKY > 0; jjTkzzVKY--) {
        tFsOkcNI += NGEJLLZ;
        tFsOkcNI = NGEJLLZ;
        yasRUJLrOtCHBz /= yasRUJLrOtCHBz;
        qIFIxq /= qIFIxq;
    }

    for (int FpTHGIZjgnV = 1904655824; FpTHGIZjgnV > 0; FpTHGIZjgnV--) {
        qIFIxq /= qIFIxq;
    }

    if (yasRUJLrOtCHBz < 1803407955) {
        for (int LOWHvLRqobgIngu = 1380151072; LOWHvLRqobgIngu > 0; LOWHvLRqobgIngu--) {
            continue;
        }
    }

    return yasRUJLrOtCHBz;
}

NBfUqagmBIexj::NBfUqagmBIexj()
{
    this->ipiAeSrTosCJqu(string("gSKJrakunDnLKG"), false, string("TQSTqHywZofRacsjQwzmxqdsznYTzuHvPsRwLqGnqtSNKuYgUpHZFgnFDLUNjQTfSiOnqWUZTRbcE"), string("chlOOidqmWvSKWMuuOrUMFRntolCTmZitANPqvhuVXoAKLiJyJlNLxvaxswpvhmZYrWsGghOlrLhCeCvkGKcWJSqkiZbxvjIPhzbblLGZLKfvRhAZEAIgaLjparPWvEBGvxbYAmlCswmbPnRYNIxcEgsbWWzAWmIULvVJYfYxNYCzNFSIXVvbIsYbXSpBOdnYuqnwVSEDgWotM"));
    this->VsCyGkeFQdFXmBL(2087278822);
    this->TrrYXdTrcIYNe(string("tWFkmlOiJfjNEROAyDXKTEuTsnacyXshsUPSqAnwjmDKMEciDFGMjEFzlDKeeMdFHYYCFpgOHCPDeMgcQRfPzgjqEMyxENzUneFTSXAKtLVpzouqmgRsUgoCbzyoIIZDAugikotjTZMgKDumfHMbyjFBZJYPkuNVeDRQdKsDoLf"), 520886.59118723485, -1485965953);
    this->QBPWoPYPOAqeBYIH(true, true, false, -642381.5499832219, 959274.5893912315);
    this->ykEQhmirFcWCjMUf(11791.456544774057, string("ckzfFBexbLRqesayLFhnAMiDL"), -82306.55770220305);
    this->wQdzrMFjCJFvz(333668835, -12500.034444045672);
    this->TWHQghCPa(132076.79714640687, 618088.0662791412, string("iAdRlDcawEYvzjExawmGfiItqpXGdbudxAASjeKYXKvjDzKUJSEYmkRhAWhAuiiWYfuKcCHIRMofjKwyFnSsDlvzaPCcCjnSpLCjdZUcHBoMgfsRAflyJAfTxGKnmEuGEwUVqTMFYYCARdjyxwTtQCLVCyIIYzFsJnAIovVVTdz"), 1803407955);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gKJLWsATdHR
{
public:
    bool HGhFNGpuDrWoGZIl;
    string dGjAzXDApTA;

    gKJLWsATdHR();
    int iCFUSjWGRzycyBLu(int zZfOUuB);
    int pBPtNuscwCR(double fwgyWoKxnTq, int MFRbAXE, int AWkVOCSjVU, bool VpqUHbIZpYtuqPyg);
    int MNXnobFlgaPKSE();
    int ChqCYruWloHllo(bool bFwxbZ, double LeXnPRxtjZ, int UfFyJ);
    double dfkvLOhq(double eDVJkCpDZFUuF, double JdZahoOWaEGhu, bool nnYjo, string qhLFIkjvNe);
    int SLBEPaKQBKabCbQ(bool uOthIcbHMmCXYpBL, double dzestCwrR, bool RgAqimvAS);
    string cjqYNVFGQobMMIy(bool TdJtCM, string sTbPhOz, int wElofzBATAJ);
protected:
    int IVdVQqTEzhldOa;
    bool tatNwQBbFT;
    bool NMmsTrzwizuBlq;
    bool SWgdroH;
    string bLEeSzjtiDqRPLI;

    bool GkoFyVXQGNPED();
    void VcBFTjkUV(string vPMtFyrgcayMjP, string IUSOIqpC, int bDsaLdhkg, bool xCsDCEyzcirsYoU);
    bool svzJJp();
    double eqQaaHoxTkJBfzxx(string NITyaGaMqVMCOfI, bool YAkIZDpWqDwOD, string beOSaGDTjsFd, bool vNXDRPuSGiQaWBOg);
    int lCkxNhjBVYu(string dArEfMoh);
private:
    string YNoLNXrfbI;

    double eJywgxbZBWtFZQN(double ZhVzWVKb, bool RSZECDLQWhwgvpXp);
};

int gKJLWsATdHR::iCFUSjWGRzycyBLu(int zZfOUuB)
{
    bool ADVWUhjVsn = false;
    string rMwqjgKsOz = string("DIIfMeQWXLNaiUfaQqKPxqHriXGRIktGsNqgZHGdjhNnYqfInBepRVifBDJCiGobMxSihxarUaHVhIJnHNEHoJSUIXEwjlnthzTIsjjIAITdWSXQoFzSruIFHPBrozxqMRDlOPEsxcMoiGhHKKIqzKPCjBncryWSfpJUzklYlxiXVhNlnqhDXtFLWbfSXMahsSklWLPomi");

    if (rMwqjgKsOz >= string("DIIfMeQWXLNaiUfaQqKPxqHriXGRIktGsNqgZHGdjhNnYqfInBepRVifBDJCiGobMxSihxarUaHVhIJnHNEHoJSUIXEwjlnthzTIsjjIAITdWSXQoFzSruIFHPBrozxqMRDlOPEsxcMoiGhHKKIqzKPCjBncryWSfpJUzklYlxiXVhNlnqhDXtFLWbfSXMahsSklWLPomi")) {
        for (int ZSeDA = 1221860539; ZSeDA > 0; ZSeDA--) {
            continue;
        }
    }

    for (int YARrZUhAuliedds = 1602512284; YARrZUhAuliedds > 0; YARrZUhAuliedds--) {
        continue;
    }

    if (ADVWUhjVsn == false) {
        for (int mYChryNFyufs = 869187627; mYChryNFyufs > 0; mYChryNFyufs--) {
            ADVWUhjVsn = ! ADVWUhjVsn;
            ADVWUhjVsn = ADVWUhjVsn;
            rMwqjgKsOz = rMwqjgKsOz;
        }
    }

    for (int SffarHhBjkJMUi = 1014808394; SffarHhBjkJMUi > 0; SffarHhBjkJMUi--) {
        zZfOUuB -= zZfOUuB;
    }

    return zZfOUuB;
}

int gKJLWsATdHR::pBPtNuscwCR(double fwgyWoKxnTq, int MFRbAXE, int AWkVOCSjVU, bool VpqUHbIZpYtuqPyg)
{
    int bolYOWxTqvpx = 1732736326;
    int kTjaSaSy = -1006794559;
    string mduPciTGI = string("pNsdGPQXNovHSydlgaUiVMsCjmdlSdihMZQUMHnoTUshpVqieaOjQhGroMgbWAHGZWJDfjOeytQNIrwXuRqiLfdXbjlbUdZSPVahxgHHRbYuzdu");
    bool mXIkWI = true;
    double oUVRWIEh = -315486.9955077385;
    bool EzWGWiiVQIuUVay = true;
    int LdWXBvk = 1546217749;

    if (kTjaSaSy <= 1732736326) {
        for (int TqESSfEHYo = 990735154; TqESSfEHYo > 0; TqESSfEHYo--) {
            AWkVOCSjVU -= AWkVOCSjVU;
            fwgyWoKxnTq -= oUVRWIEh;
            kTjaSaSy /= bolYOWxTqvpx;
            AWkVOCSjVU *= LdWXBvk;
        }
    }

    for (int KnDENsRnXN = 5966199; KnDENsRnXN > 0; KnDENsRnXN--) {
        bolYOWxTqvpx *= kTjaSaSy;
        EzWGWiiVQIuUVay = mXIkWI;
        LdWXBvk += LdWXBvk;
        bolYOWxTqvpx -= bolYOWxTqvpx;
    }

    if (fwgyWoKxnTq >= 917390.4201578435) {
        for (int CLlDUpwbaMzfw = 1977353275; CLlDUpwbaMzfw > 0; CLlDUpwbaMzfw--) {
            EzWGWiiVQIuUVay = ! EzWGWiiVQIuUVay;
            LdWXBvk *= MFRbAXE;
        }
    }

    return LdWXBvk;
}

int gKJLWsATdHR::MNXnobFlgaPKSE()
{
    int XEDXKlsaWNLHB = 1738194188;
    int zqwxdETWVdjhyR = -767489991;
    string afCdmqMH = string("mbQixQnznXsFJsAGrDSWucGAiseyDvkIfAJlDkVxkzbtYAxIhaCijzTjJyBAippLQtSBjAuLXbehSiAABQnqtPQLazoeMtCRdarsRnTMVImXehyqHzuUKjrwilolWWewXqDGmpGkUIYnhcpuqdUbBxYpjDVtnwABAiPHyoarnbJIvSLWlKVKCxpYQEcsDdZoshENmiMJSpwCyNnSjTiQSqhhEqcmLu");
    bool lKuODXnTCn = false;
    double wiLnuRAHWbAvNAuM = 914017.9040857875;
    string QzezUQUFtqOev = string("EjYjcrJinAMBewqVUNvHkLYbtocsxfCnUYJKHvshWQyltpSekoxxRbqkbGSvMvkmUnSzkjnOBvFVimsRDmCYrLkVVRywajBXXIrZfJAkysESMzvqBhEYzXPGMvkVzTwMXOskapBvUuoAxNxnMsiDAlxPutlPsYdpwWbZyWvMXgZzgJOoZGQdYOzBXgCtfWYSsKzDcIzCzMGbYwgbAsIB");
    bool WlPHMULcI = true;
    string orfpBfasmRDh = string("lfWqgDFcCVQDSGshaHfUOsCTbJooJpsfUtEAsUBPZKjNGckfZHjVbbHEpKiZqAuqAfZnZnYpkeCkClJzyAHiiIXXjFIiqyuhVypMjNVrjYpUZONCflfBQxJdyagjRqWXswWNVljQGUItQBpZieWDEsiFPUmcRKLomrJDMQBscAXlZhuGgbuPTmtUuIfMTZNCv");
    bool UnYYXDyT = true;

    if (QzezUQUFtqOev != string("mbQixQnznXsFJsAGrDSWucGAiseyDvkIfAJlDkVxkzbtYAxIhaCijzTjJyBAippLQtSBjAuLXbehSiAABQnqtPQLazoeMtCRdarsRnTMVImXehyqHzuUKjrwilolWWewXqDGmpGkUIYnhcpuqdUbBxYpjDVtnwABAiPHyoarnbJIvSLWlKVKCxpYQEcsDdZoshENmiMJSpwCyNnSjTiQSqhhEqcmLu")) {
        for (int tFtYk = 850529872; tFtYk > 0; tFtYk--) {
            afCdmqMH = afCdmqMH;
        }
    }

    for (int akewUKsnslNRk = 1883609059; akewUKsnslNRk > 0; akewUKsnslNRk--) {
        UnYYXDyT = UnYYXDyT;
        orfpBfasmRDh += afCdmqMH;
    }

    for (int VgQmWyZEVeWTUUbj = 939137853; VgQmWyZEVeWTUUbj > 0; VgQmWyZEVeWTUUbj--) {
        afCdmqMH = afCdmqMH;
        QzezUQUFtqOev += QzezUQUFtqOev;
    }

    for (int lsnIr = 298227910; lsnIr > 0; lsnIr--) {
        afCdmqMH = afCdmqMH;
    }

    return zqwxdETWVdjhyR;
}

int gKJLWsATdHR::ChqCYruWloHllo(bool bFwxbZ, double LeXnPRxtjZ, int UfFyJ)
{
    double mUnVhkSn = 360080.393867495;
    bool AuKTDtU = true;
    bool IIjuxXRbS = false;
    double XpovlFiUwU = 79819.19303220956;

    for (int GzAGvbKSe = 1734700207; GzAGvbKSe > 0; GzAGvbKSe--) {
        LeXnPRxtjZ /= XpovlFiUwU;
        bFwxbZ = ! bFwxbZ;
        UfFyJ = UfFyJ;
        bFwxbZ = bFwxbZ;
    }

    for (int OKIIJblkIBXR = 1962543735; OKIIJblkIBXR > 0; OKIIJblkIBXR--) {
        continue;
    }

    return UfFyJ;
}

double gKJLWsATdHR::dfkvLOhq(double eDVJkCpDZFUuF, double JdZahoOWaEGhu, bool nnYjo, string qhLFIkjvNe)
{
    double mqQFAzML = 341265.05814322305;
    bool rfdpIZrlk = true;
    int EYASuQM = 262179201;
    int KgQBwPsNVOJ = -1258943094;
    int VIBMHBcVLDUUAW = -1671373900;
    bool TrDmfmqMMD = false;
    double PLBOrTqijVv = -27665.176903479976;
    bool TAcSeOAfzFvJ = false;
    double XOdbAb = -72546.80750399464;
    string KqMhAVtITDqBKa = string("SjmcSyszylwKGIslgMnFIOiQkSDFMqSSRYPeGZNAyuNBAREXiUIHrYrEaBmkkbtVJSXIYaoemYTsnYJUyiwnqeFLSbdNzSCJszgNvFXGZXrjpubON");

    for (int uNfrVJV = 1248914555; uNfrVJV > 0; uNfrVJV--) {
        JdZahoOWaEGhu += PLBOrTqijVv;
        mqQFAzML -= XOdbAb;
    }

    if (XOdbAb == -72546.80750399464) {
        for (int rvjmrVuTFG = 915625697; rvjmrVuTFG > 0; rvjmrVuTFG--) {
            PLBOrTqijVv = XOdbAb;
            VIBMHBcVLDUUAW = EYASuQM;
        }
    }

    if (PLBOrTqijVv == -27665.176903479976) {
        for (int kWNwoLDqOlRNsO = 742326504; kWNwoLDqOlRNsO > 0; kWNwoLDqOlRNsO--) {
            continue;
        }
    }

    for (int bHteBXYxTI = 1787001595; bHteBXYxTI > 0; bHteBXYxTI--) {
        continue;
    }

    for (int qnIdwKZv = 1821487127; qnIdwKZv > 0; qnIdwKZv--) {
        continue;
    }

    if (PLBOrTqijVv != -72546.80750399464) {
        for (int cfoToiisyTEC = 1530257151; cfoToiisyTEC > 0; cfoToiisyTEC--) {
            continue;
        }
    }

    return XOdbAb;
}

int gKJLWsATdHR::SLBEPaKQBKabCbQ(bool uOthIcbHMmCXYpBL, double dzestCwrR, bool RgAqimvAS)
{
    string DHQogKLQiVbRLvJr = string("iZoZmnMBopozEbaUSMZxjWvwidjOfywRvCUAGfVPHkCBaegnOONWyvMEvLxdqpfYEMhdgrZivnGgNuosRGFiwlTdXNrmhUyHubPJPNcCbBVcBbDwOxaixPgBDUxiEOpYxlvtlGCYpRcJmbPOWPGcDqGDIpSahTCBTAWPFckHkaAVSDrXPZFVcuJKPPmcpeGKoyQZzRMkO");
    string lCWTETnqkX = string("eXEuYVVaLllgVevTcStMREVDMTkpIqDmkx");

    if (uOthIcbHMmCXYpBL == false) {
        for (int lqvaypWBVORg = 139149347; lqvaypWBVORg > 0; lqvaypWBVORg--) {
            RgAqimvAS = ! RgAqimvAS;
            DHQogKLQiVbRLvJr = lCWTETnqkX;
        }
    }

    return 1488504417;
}

string gKJLWsATdHR::cjqYNVFGQobMMIy(bool TdJtCM, string sTbPhOz, int wElofzBATAJ)
{
    int yGvTxHKHPKOPM = 373946808;
    bool YrbiiDsBq = false;
    double MsPKnOx = -568965.1352633833;
    string vLHgQENSNlwgveM = string("nBQFLprxfxbJfPoFeWDEJMEwjPSIKLqImgDuwGNlHoWjrJzbbEsWLaJknMJOVnoUeAYedvAazlPDxKdwaunLOEsqlIxKSWLhyfAeeoWiZcLWQeGxcNNlqxqAYyxfgBrGprqPQuWVPtFMVspBZfJsZDONrCFzgF");
    bool XGZzEEFRIQt = false;
    string gjcBwSeIFQsGS = string("gywTyznerxTcIpVBqcRiOGOjhRUOjEEiHmvppKNSMFxEjKRXNeihXgaupQHVkQGZVbUgmCNvFQNwukDsfAcjWWMtIOmJhNdoOOpOMPckGAujYoMDzleVZJm");
    string vvqmBTzBCMBRecvD = string("PnSIIpURZvRmUhOwairtCmOYtCRbZi");
    int NQRbij = -1919784297;

    return vvqmBTzBCMBRecvD;
}

bool gKJLWsATdHR::GkoFyVXQGNPED()
{
    string GbCWKBTtRJMpoK = string("kNuELLANyyx");
    string jOCHPziWgnrDko = string("qjMRnxYSeyOgsjHZDvxgnCWbmhyMaaTwiIituwLXTaJyEnAYeKLCTiifDHNTCWkkVunnZUNjLeElxLUchHfkJqaSnUBlLGxRWRrqNDTFuRAqdrtZvyNqbaAMOGqnuzosxcdqNaAcVgLCFvhrftnedkQZcNCwLgArOzLRlZfXNYbidFAxvrHs");
    bool vxNEAkddEUkkM = true;
    int fBdeTpvcAXdTQ = 1360553295;
    string MuNGVn = string("WEHErIRsLNVonQEzKYNRjiNDhRZznvOvdPtGrJFcDOuJYxMnFaqHZaFLANSDEZTUpJwqFPsaNeIxnoTeYXupgmhHQUuRFrKggckotTyBtOyzkaNnvchlRcqWyvYBXBJUFONKKNPSOfVRyIRnnlmhWVEunZIQiQlbcIGldemABQSMjQdtXMWLIuGNBXoCaUndi");
    int nVJTaokgQOVGLAqg = -1320504757;
    string eAnYVn = string("N");

    for (int GCTdeGUg = 1870459911; GCTdeGUg > 0; GCTdeGUg--) {
        fBdeTpvcAXdTQ -= fBdeTpvcAXdTQ;
        MuNGVn = MuNGVn;
        jOCHPziWgnrDko += jOCHPziWgnrDko;
    }

    return vxNEAkddEUkkM;
}

void gKJLWsATdHR::VcBFTjkUV(string vPMtFyrgcayMjP, string IUSOIqpC, int bDsaLdhkg, bool xCsDCEyzcirsYoU)
{
    double aVfGKbzk = -23011.880096011715;
    double JaMkLTtsj = -799364.5981659996;
    string RcjrIeTyYs = string("rVtAQCQQnbFUBjJVSqrfVDmcOTSyhPYoIRJZQBrUqYIneCxQcStzwctnnOjMgjeZmjsbgifVFFfFdrGLfxEVQqXSJFLvPsTmIlHgDPDYVIKKOqzIrdwgttlAtEDsznMUnPpAvOMlXRNojprJVRnHNriEDFyLir");
    string XeCLJC = string("ChmhObsSHOMCilOJYdNnTZuvhwscvoMsvqAOmIjevxLPjPEZVMPyDMuLcvglkvkXqUwKPAXOjjDgFJaZDRenf");
    bool YKkZZjF = false;
    int RQzTgMvaSiKY = 99835443;
    int OmzTlKu = -450594838;
    string gYhQjDgxFFXA = string("cudJkPaMybLjQXypYgIrKXcEAArJLFcAOelDzzDXcFXUOYIlKuntftyOFJSbpUKhnMihlXFZILqvpjBfywKlyIEATXZjYchIjFFWRrVpzmBJlKfUVVlIsViYxXoLPBO");

    for (int PJrARQpAAa = 2031809876; PJrARQpAAa > 0; PJrARQpAAa--) {
        JaMkLTtsj += JaMkLTtsj;
        vPMtFyrgcayMjP = IUSOIqpC;
    }

    for (int rJPWpuosG = 1615090212; rJPWpuosG > 0; rJPWpuosG--) {
        continue;
    }

    if (XeCLJC < string("hcYV")) {
        for (int cUBrGqDDTU = 1258034693; cUBrGqDDTU > 0; cUBrGqDDTU--) {
            RcjrIeTyYs += vPMtFyrgcayMjP;
            XeCLJC += vPMtFyrgcayMjP;
            IUSOIqpC = RcjrIeTyYs;
            gYhQjDgxFFXA = vPMtFyrgcayMjP;
            IUSOIqpC = IUSOIqpC;
        }
    }

    for (int boWoWHtFxYYw = 626539420; boWoWHtFxYYw > 0; boWoWHtFxYYw--) {
        aVfGKbzk *= JaMkLTtsj;
        IUSOIqpC += gYhQjDgxFFXA;
        IUSOIqpC = RcjrIeTyYs;
        RcjrIeTyYs = IUSOIqpC;
    }
}

bool gKJLWsATdHR::svzJJp()
{
    double XRjfNgyyIlc = -580310.3842444173;

    if (XRjfNgyyIlc <= -580310.3842444173) {
        for (int OuiPAxsIbMO = 1473028356; OuiPAxsIbMO > 0; OuiPAxsIbMO--) {
            XRjfNgyyIlc /= XRjfNgyyIlc;
            XRjfNgyyIlc = XRjfNgyyIlc;
            XRjfNgyyIlc -= XRjfNgyyIlc;
            XRjfNgyyIlc += XRjfNgyyIlc;
        }
    }

    if (XRjfNgyyIlc >= -580310.3842444173) {
        for (int pzcYvOJzdcUZUYaz = 1714760867; pzcYvOJzdcUZUYaz > 0; pzcYvOJzdcUZUYaz--) {
            XRjfNgyyIlc -= XRjfNgyyIlc;
            XRjfNgyyIlc *= XRjfNgyyIlc;
            XRjfNgyyIlc /= XRjfNgyyIlc;
            XRjfNgyyIlc += XRjfNgyyIlc;
            XRjfNgyyIlc += XRjfNgyyIlc;
            XRjfNgyyIlc /= XRjfNgyyIlc;
        }
    }

    return true;
}

double gKJLWsATdHR::eqQaaHoxTkJBfzxx(string NITyaGaMqVMCOfI, bool YAkIZDpWqDwOD, string beOSaGDTjsFd, bool vNXDRPuSGiQaWBOg)
{
    bool jKyjcMLtZeO = false;

    for (int IuKPIRYuTnvFCxc = 1215624897; IuKPIRYuTnvFCxc > 0; IuKPIRYuTnvFCxc--) {
        NITyaGaMqVMCOfI += beOSaGDTjsFd;
        vNXDRPuSGiQaWBOg = ! jKyjcMLtZeO;
    }

    if (jKyjcMLtZeO == false) {
        for (int LLoUM = 459756370; LLoUM > 0; LLoUM--) {
            YAkIZDpWqDwOD = jKyjcMLtZeO;
        }
    }

    if (vNXDRPuSGiQaWBOg != false) {
        for (int MYwCR = 590985097; MYwCR > 0; MYwCR--) {
            jKyjcMLtZeO = ! jKyjcMLtZeO;
            vNXDRPuSGiQaWBOg = ! vNXDRPuSGiQaWBOg;
            YAkIZDpWqDwOD = vNXDRPuSGiQaWBOg;
            beOSaGDTjsFd += NITyaGaMqVMCOfI;
            jKyjcMLtZeO = ! YAkIZDpWqDwOD;
        }
    }

    for (int pbqwceaHuuvF = 1620315994; pbqwceaHuuvF > 0; pbqwceaHuuvF--) {
        continue;
    }

    for (int nUfvEjaIVpLs = 1703474742; nUfvEjaIVpLs > 0; nUfvEjaIVpLs--) {
        jKyjcMLtZeO = jKyjcMLtZeO;
        jKyjcMLtZeO = ! YAkIZDpWqDwOD;
        jKyjcMLtZeO = ! jKyjcMLtZeO;
        vNXDRPuSGiQaWBOg = jKyjcMLtZeO;
    }

    if (YAkIZDpWqDwOD == false) {
        for (int KQAByttNaWn = 399778455; KQAByttNaWn > 0; KQAByttNaWn--) {
            YAkIZDpWqDwOD = vNXDRPuSGiQaWBOg;
            NITyaGaMqVMCOfI += beOSaGDTjsFd;
            YAkIZDpWqDwOD = ! jKyjcMLtZeO;
        }
    }

    return 286476.34577708744;
}

int gKJLWsATdHR::lCkxNhjBVYu(string dArEfMoh)
{
    string QQHdZUIPdUJAKcg = string("NREtXhpXPmBpLvDnpqXTXNbdVKyfP");
    double JFDcHaXQeii = -557341.2218080035;
    double VYeXopSCuNEbXXQB = 891272.3045284072;

    if (JFDcHaXQeii <= 891272.3045284072) {
        for (int GbGXAVMA = 783375708; GbGXAVMA > 0; GbGXAVMA--) {
            VYeXopSCuNEbXXQB += VYeXopSCuNEbXXQB;
        }
    }

    if (JFDcHaXQeii > -557341.2218080035) {
        for (int Vfmmk = 1929443284; Vfmmk > 0; Vfmmk--) {
            QQHdZUIPdUJAKcg = QQHdZUIPdUJAKcg;
            JFDcHaXQeii *= VYeXopSCuNEbXXQB;
            VYeXopSCuNEbXXQB = VYeXopSCuNEbXXQB;
        }
    }

    if (dArEfMoh != string("kvqBwBCnnUTQxBEVvEmcfdWMvLCjimzVhqhMZfCkyuZWKVZlhxLQFGAmKPmRr")) {
        for (int tPVOKcpFxvJWghPz = 1124122508; tPVOKcpFxvJWghPz > 0; tPVOKcpFxvJWghPz--) {
            QQHdZUIPdUJAKcg += QQHdZUIPdUJAKcg;
            QQHdZUIPdUJAKcg = QQHdZUIPdUJAKcg;
            QQHdZUIPdUJAKcg = QQHdZUIPdUJAKcg;
        }
    }

    if (JFDcHaXQeii == 891272.3045284072) {
        for (int rHIWfqzuESELTL = 1136090640; rHIWfqzuESELTL > 0; rHIWfqzuESELTL--) {
            VYeXopSCuNEbXXQB *= VYeXopSCuNEbXXQB;
            VYeXopSCuNEbXXQB *= JFDcHaXQeii;
        }
    }

    for (int hBrQyBxdfNO = 377293560; hBrQyBxdfNO > 0; hBrQyBxdfNO--) {
        VYeXopSCuNEbXXQB -= VYeXopSCuNEbXXQB;
        dArEfMoh += QQHdZUIPdUJAKcg;
    }

    if (JFDcHaXQeii < 891272.3045284072) {
        for (int ScpfylMUAaP = 51050023; ScpfylMUAaP > 0; ScpfylMUAaP--) {
            QQHdZUIPdUJAKcg += QQHdZUIPdUJAKcg;
            dArEfMoh = QQHdZUIPdUJAKcg;
            dArEfMoh += QQHdZUIPdUJAKcg;
            JFDcHaXQeii += VYeXopSCuNEbXXQB;
        }
    }

    for (int CghBBpe = 1671200222; CghBBpe > 0; CghBBpe--) {
        JFDcHaXQeii += VYeXopSCuNEbXXQB;
    }

    for (int cUkCvYYTw = 690335106; cUkCvYYTw > 0; cUkCvYYTw--) {
        JFDcHaXQeii *= VYeXopSCuNEbXXQB;
        VYeXopSCuNEbXXQB = JFDcHaXQeii;
        JFDcHaXQeii /= JFDcHaXQeii;
        dArEfMoh = dArEfMoh;
        dArEfMoh = QQHdZUIPdUJAKcg;
    }

    return -1754342227;
}

double gKJLWsATdHR::eJywgxbZBWtFZQN(double ZhVzWVKb, bool RSZECDLQWhwgvpXp)
{
    bool SpwdmODBeE = false;
    double hKmPznOGXzkgqMxR = -693911.4157082165;
    double FWKRihsD = 1028316.1229226945;
    bool LjofReKmvq = false;
    string EUZSYrPIRlvvmCD = string("BiwyFPgXeFptbisMHiszaohRkRwjalxjYWjhkpbGaMTuyA");

    if (ZhVzWVKb == 1028316.1229226945) {
        for (int CfMOdTbUAFSlkcb = 1481614827; CfMOdTbUAFSlkcb > 0; CfMOdTbUAFSlkcb--) {
            hKmPznOGXzkgqMxR *= ZhVzWVKb;
            RSZECDLQWhwgvpXp = RSZECDLQWhwgvpXp;
        }
    }

    for (int ttLKBjKF = 154287901; ttLKBjKF > 0; ttLKBjKF--) {
        LjofReKmvq = ! RSZECDLQWhwgvpXp;
    }

    for (int ihsGByjg = 899071047; ihsGByjg > 0; ihsGByjg--) {
        hKmPznOGXzkgqMxR -= FWKRihsD;
        ZhVzWVKb = ZhVzWVKb;
    }

    if (RSZECDLQWhwgvpXp == true) {
        for (int kLJQhQnlzGbVAPIg = 987236571; kLJQhQnlzGbVAPIg > 0; kLJQhQnlzGbVAPIg--) {
            FWKRihsD = hKmPznOGXzkgqMxR;
            RSZECDLQWhwgvpXp = ! RSZECDLQWhwgvpXp;
        }
    }

    for (int mLNKCTtbGwl = 253312747; mLNKCTtbGwl > 0; mLNKCTtbGwl--) {
        continue;
    }

    for (int hWOESKdT = 666428853; hWOESKdT > 0; hWOESKdT--) {
        hKmPznOGXzkgqMxR -= FWKRihsD;
        hKmPznOGXzkgqMxR += hKmPznOGXzkgqMxR;
    }

    return FWKRihsD;
}

gKJLWsATdHR::gKJLWsATdHR()
{
    this->iCFUSjWGRzycyBLu(1728171929);
    this->pBPtNuscwCR(917390.4201578435, -1352924742, 56468496, true);
    this->MNXnobFlgaPKSE();
    this->ChqCYruWloHllo(true, 254014.66082869974, -1730536633);
    this->dfkvLOhq(439010.0977571564, 752569.7918684739, false, string("kdbzzwAaRqsmWwGBKGOvBbLQsxqQrxGydWyQTgrYZPnIZpsBqGEiabAwslcSsHMfPByQejpyJKdZYLMeUPmxt"));
    this->SLBEPaKQBKabCbQ(true, -57980.110653105934, false);
    this->cjqYNVFGQobMMIy(true, string("DzicIGzxVWtVSPchqJEtQCybsJHaYVPqoUHzDZoVqFEtQnZLgGQAEdnFLkfgQqNFausqXNbdyBdXJIIpJUHvoWVwGpcVgKKenJGrjvmealPQndYMgJCDzxroTlZJUkALMmjbtrV"), 1965042012);
    this->GkoFyVXQGNPED();
    this->VcBFTjkUV(string("FWypnqzThipqNmuXNXXQunigWbTkRNMdQQKBoZBMSnBYFGELpXuVigHNQCFLEDDiejLBoJrqGnHyxSoCJYTQjXBnBsuvzUfiZRIPkyDiPMrWUQJSlsKnXTB"), string("hcYV"), 709868554, false);
    this->svzJJp();
    this->eqQaaHoxTkJBfzxx(string("vTOogPwJCzOwDOjHISuWiroOvPUNkvMREoXmnOVRlIbaPMieuwCwqqpqETZghSNIioJACFHkpAvDVRzzZORbXWLyPJOsUwktFEIMDHTmvZTMbwOzMIaaIqz"), true, string("xjHGOCxoodtjYVolfsSQvJaaZVnjORopUvmiNIjYzfoaipVOwHCzwHqnlKYqkcyNuZDtDkuXCYVobyHnsJxnOHKQbuWVRxbQLbBHXotGseOiUWZPfllEptcqLofLTLTZOWzgMljnmugzw"), false);
    this->lCkxNhjBVYu(string("kvqBwBCnnUTQxBEVvEmcfdWMvLCjimzVhqhMZfCkyuZWKVZlhxLQFGAmKPmRr"));
    this->eJywgxbZBWtFZQN(-312041.635046081, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tRMHJHwh
{
public:
    double xNdaSVuk;
    string CQqFCeeinCv;

    tRMHJHwh();
    string BUgnXW();
    bool SZljAHTZEUpJm(double qdxXEWPmV, bool pYJTIQuWgxSdWy);
    double UKKsfucvMNciYMm(int FNICNgwCoMH, string bLajMzzL, int XoMQxz);
    string TroItHMksd(double ZBxuEXkSSlNejnVd);
    double JXfnLqTN(int BxcMbmeeyCra, string rQqiBsHzhskRvX, double yyNbdPOMETNAS);
    void bxfWcOvJzvLzqGP();
    string OhuTkuteaaGCQt();
protected:
    int amzyKUsyHsiRqXqW;

private:
    int VeHZdijyqHDjl;
    bool VawnhX;
    double JrBCVywlxrxix;

    bool EJUiVUzxP(string eCgDyBEW, string iLrHubYYstlUbf);
    double HSggkCY();
    double TJjIrvrkdVM(bool EmtwKNNLuGotq, int cVqHop);
    int TjdHgt(bool xezcOb, string jqlJt, int XrGDjBQNxcYNPn, string xCDPVDRvOnE);
    bool PzLfLWOhMYR(string pQAmnTeMBbrni);
    string BnwfrahMjG(double KAHPAsHzBkmUDSUZ);
    int MDGBOeCT();
    void izYcjXS(string ceslFHmM, double sJxZUbuqNrg);
};

string tRMHJHwh::BUgnXW()
{
    string hWitY = string("vumCsR");
    int GTyKhSgPtMSzqJ = -2022724496;
    string UwpXawbM = string("fJMdMjvwVdNvFwRPRVatjfqrsqBGAUXnDSQkfrnsoMDzE");
    int BfWGyAutK = -1869426746;
    string cOcYfpjlOfipqW = string("ykeyyOqUyWXFSHzzRutoZMibCbVrJiBxFMhXLaVtFDBGVvEGnIfwwBsYWfmhazuzN");

    if (cOcYfpjlOfipqW == string("ykeyyOqUyWXFSHzzRutoZMibCbVrJiBxFMhXLaVtFDBGVvEGnIfwwBsYWfmhazuzN")) {
        for (int DiaSVV = 1330828193; DiaSVV > 0; DiaSVV--) {
            cOcYfpjlOfipqW = hWitY;
            UwpXawbM += hWitY;
            cOcYfpjlOfipqW += hWitY;
            hWitY = hWitY;
        }
    }

    return cOcYfpjlOfipqW;
}

bool tRMHJHwh::SZljAHTZEUpJm(double qdxXEWPmV, bool pYJTIQuWgxSdWy)
{
    int xuzbH = -24710851;
    string EDlVNgBLvktHIrzo = string("pGOZTcSNXFQIHgUlSpSGvFgCUtbzNDTOSrjPhcZCLPSLOlbtoCVNKHseKTLDVQyWzXLydJiyfmzRLtDAcqTtsxPIxhBBLVabHgmgejueTUhDmsCBhdMhUarowlWLR");
    string iIrYln = string("bXLZsidEaftWRtTangDGnhEFvD");
    int PWxTpNisxwo = 1099818869;
    double NawZey = 840128.3338105363;
    double JKZbiLYKIj = -929973.8210929808;
    int qAkmwJkiGXCmtJw = 1941355236;
    bool sHoZYHSYUJdL = true;
    string xJRGCV = string("dQCkxjlDgKUeYcVebJDuWBVMrcpofsPGLrdYWCfYGTthDSeTlEQzFZuPRvKAMWtQYBaYEgxBMhfdkXAlwoQlOPIOvQhgbCtLUBLaszmKJGKhHqyWmoUWXfFqHzfQNJypNjvuqYmaWbQmVsVDsgbaoYaHBiyIZBWNtoWKFxlWXsAkJBCzxWTTRyeXvXZlLwqNuykSgQVezAIPJUSoZ");

    if (iIrYln <= string("bXLZsidEaftWRtTangDGnhEFvD")) {
        for (int QQkyO = 1875823112; QQkyO > 0; QQkyO--) {
            JKZbiLYKIj += qdxXEWPmV;
            PWxTpNisxwo /= PWxTpNisxwo;
        }
    }

    for (int BwEocaQGTA = 1138945533; BwEocaQGTA > 0; BwEocaQGTA--) {
        continue;
    }

    for (int BJsvt = 1520345870; BJsvt > 0; BJsvt--) {
        PWxTpNisxwo = qAkmwJkiGXCmtJw;
    }

    return sHoZYHSYUJdL;
}

double tRMHJHwh::UKKsfucvMNciYMm(int FNICNgwCoMH, string bLajMzzL, int XoMQxz)
{
    string vfNAwuHnblSatPyZ = string("twXSAbYOJVRfXfqvzkxAfPbiKGFCZtpbmqCQwEPuNBluELYrjTFixIHFncXkROCEFxNFySyGkdoWPwSFbeSxaQIrbdzxRTXbYOhsqfvthbeSIsnkjSqRUDGBbzopKkkBOZtYIJCvQQplcirHInfVApRnlwhHlIBgW");
    int fTPUDUXbKcDlY = 2033850410;
    double uceHYqGHECzrTUe = -971664.0764855912;
    string bCsTFbQARa = string("ketARRuYGgsQPYzLzarQmGXrmvSkRIWNXdxjiJsTBOEwOpAuzXVqaUJSdlFPdsFpRMDYnRSUAgCdsFLHAtxoITyOGLoVdwtOhOCJLvPAWxcGTfAS");
    double uSIVAmSUYPssd = -304094.91032634553;
    double KmXvnOxYg = 328737.31600915187;
    bool qWHEjGViIX = true;
    double ZVblZIoh = -356404.62514853576;

    if (KmXvnOxYg >= -304094.91032634553) {
        for (int sYmPEqKAckTWnvL = 1228593796; sYmPEqKAckTWnvL > 0; sYmPEqKAckTWnvL--) {
            bCsTFbQARa += bCsTFbQARa;
        }
    }

    for (int ELzPHSMK = 1139417347; ELzPHSMK > 0; ELzPHSMK--) {
        bLajMzzL = bLajMzzL;
        ZVblZIoh = KmXvnOxYg;
    }

    for (int FLxLirfZSHkWRu = 1023765472; FLxLirfZSHkWRu > 0; FLxLirfZSHkWRu--) {
        KmXvnOxYg = KmXvnOxYg;
        uceHYqGHECzrTUe -= uSIVAmSUYPssd;
    }

    return ZVblZIoh;
}

string tRMHJHwh::TroItHMksd(double ZBxuEXkSSlNejnVd)
{
    double BbOydJpejVFIy = -1041441.5988235826;
    string EIKpuUdjPgotN = string("DcrFOcdZuiFcvswhpiiKnPsROkyPBkJhWTzggeKdFhxzPBfnPOPYfxtEMGBTCunMUegQQRzeiVEwAKyAwGbXEpXtZWcFaglSlCHdzizblnFYDRLerozdohquSjiNHJCV");
    int ZuzFuT = -1623274405;
    string NEAIxiQJJWQGzxeH = string("BuQmZlFhYNyAnkvvENqNDvjlGyDzEXXUFEMSKm");
    double JSuxW = 232469.8275073853;
    int qwALKUnTjGe = -457566281;
    int pIXXPVeMiE = -833703797;
    bool MDpQloRwUyWooSe = true;

    for (int eqTeDJijdKzRWnNj = 1454734589; eqTeDJijdKzRWnNj > 0; eqTeDJijdKzRWnNj--) {
        continue;
    }

    for (int yIunFkKnlVHZIwAO = 1734823654; yIunFkKnlVHZIwAO > 0; yIunFkKnlVHZIwAO--) {
        pIXXPVeMiE /= ZuzFuT;
        MDpQloRwUyWooSe = ! MDpQloRwUyWooSe;
        JSuxW *= JSuxW;
        ZBxuEXkSSlNejnVd *= ZBxuEXkSSlNejnVd;
    }

    return NEAIxiQJJWQGzxeH;
}

double tRMHJHwh::JXfnLqTN(int BxcMbmeeyCra, string rQqiBsHzhskRvX, double yyNbdPOMETNAS)
{
    string RSWbEMeICwYKhAhY = string("QFBHWvhjBKpOOufCcEgNBINmKxIFDSsSOgISaKfGrrDqXUcZqAMnruHrMZhVokNxCMqbLWPtwxiRkGyFQDlUpowGldAagKcrMleztZYHsXHFBjeoAavRlRDBowHU");
    double qADyxHSKbYVTxlsX = 818316.7862995852;
    string PsqZMrHfhDHt = string("nWXcPVRxsuZqYevqlTmPqzIyxBJBktRjLNAxZhzqaGlMfjseqrcdCHaamyPXFFYKRmEXBCtMwGBQggbaBMukwmzXkHcxdTpzEETkJQqstCQirhgcSvHYyGaPOVhfRbdKUCcgMplzxXcmwQkBbBSVEVxMUIKlTZAnfWLBwkjazFlZzdUzsZMExMHDQcYoWySEeMCgdAwICVFbfqZZCSqCVsaVHPRBWPxomNtdMnLlvroPSZhtbIWUwTM");
    string oAgDNLDg = string("jNVyCXSJUqmXdhCnpgTzjEetneyScLCdbhoidjxRPOZAsTiNaWqCSdLaKMcjkJjYVaKiGplGKrUffcydEJZJOudeOuCUzoyorFmniivzHvUvVZrFMqIoOZMAGbkhHjGkhKBoScQcpLHoNZiHrzvVdnHyfFvxXBbDIzHnianDQfqtoffYVgsunROObgsCUGuqzyUPx");
    double WxZwLVIKu = 993571.4795783984;
    double GxTcVYSkobg = 378093.68722621934;

    return GxTcVYSkobg;
}

void tRMHJHwh::bxfWcOvJzvLzqGP()
{
    string idhnEsnlKn = string("JtMibWdEIstGHMkgDiwWcSMpqpqLtlx");
    int rrlBdysXhBGO = -71677769;
    double zvkPcUCTwzaQp = -716633.863251917;
    int VTJGRsKLSPVBZYjJ = -1664601155;
    int CxBFroLfbS = 1999103121;
    string gBGkcTq = string("hFjfTyrnGzeDwZFCrjzcRFVNCmQWdPfKSYmYiakucEmOPuefhyzNRhkWTexCAUuzoSgjeFwdpKJlSrhYIfVFgXNfTvZTTsWWqkYadbOCeXLzSSSmjxyYEPDDfOmKNvUEeVAmnmMQjITGZPibjaAGWsTYSfIKeptqCxfGFLVaii");
    double hQSQEPY = 66575.11896941192;
    int ILFNqgYk = 1634181859;
    string NsAvvdL = string("eDCaakjhBxsAQqzPFDuGvSPafCcpmTiZecvzavlXdpRMCUJiRIYSVoKPplQJqzuafZeCCHBZqoNXlWvVqrEAgqQt");
    int PddmPlozXDv = -1071570268;

    for (int hbiPSIWTVIYNRNN = 111065707; hbiPSIWTVIYNRNN > 0; hbiPSIWTVIYNRNN--) {
        VTJGRsKLSPVBZYjJ /= PddmPlozXDv;
        PddmPlozXDv = ILFNqgYk;
    }

    if (PddmPlozXDv == -1071570268) {
        for (int mhmkXjdJ = 1622487568; mhmkXjdJ > 0; mhmkXjdJ--) {
            rrlBdysXhBGO /= PddmPlozXDv;
            ILFNqgYk = PddmPlozXDv;
            idhnEsnlKn = idhnEsnlKn;
        }
    }

    for (int JCqzUHJJVPZCtRGe = 515715624; JCqzUHJJVPZCtRGe > 0; JCqzUHJJVPZCtRGe--) {
        rrlBdysXhBGO -= VTJGRsKLSPVBZYjJ;
        PddmPlozXDv *= CxBFroLfbS;
    }
}

string tRMHJHwh::OhuTkuteaaGCQt()
{
    bool RdDJAzColQXNdsr = false;
    bool wWAqJioSk = false;

    if (RdDJAzColQXNdsr != false) {
        for (int hvsBLKkxNjpspwLx = 73146009; hvsBLKkxNjpspwLx > 0; hvsBLKkxNjpspwLx--) {
            wWAqJioSk = ! wWAqJioSk;
            wWAqJioSk = wWAqJioSk;
            RdDJAzColQXNdsr = ! RdDJAzColQXNdsr;
            RdDJAzColQXNdsr = ! RdDJAzColQXNdsr;
            wWAqJioSk = ! wWAqJioSk;
            wWAqJioSk = ! RdDJAzColQXNdsr;
            wWAqJioSk = ! RdDJAzColQXNdsr;
            wWAqJioSk = wWAqJioSk;
            wWAqJioSk = ! RdDJAzColQXNdsr;
            wWAqJioSk = wWAqJioSk;
        }
    }

    if (RdDJAzColQXNdsr != false) {
        for (int jWEByMXAr = 475217955; jWEByMXAr > 0; jWEByMXAr--) {
            RdDJAzColQXNdsr = wWAqJioSk;
            wWAqJioSk = wWAqJioSk;
        }
    }

    return string("cTCOUoFSUxXGpEtChTyFFCtyApuUpkozRSHofzPKJptsVxbpDrSENOqRMwFqcwYtcsTARWiExeSNcOQlUyv");
}

bool tRMHJHwh::EJUiVUzxP(string eCgDyBEW, string iLrHubYYstlUbf)
{
    bool esdCq = false;
    bool CYJwoAPRvhBcNPg = false;
    double tHsukuzrAvQnXwL = -936686.8509230786;
    string infjLiQxdB = string("KxQDjSXoLEhpjzZtbFgMxpVjYeURuEQiIzskFTiBVxFYrNELOQZRPTaSwHcMjhiYCFrubyppdOrgwooxWqVFLbkHOMmTztvWlPczfqjqOkfWhcqtwtINWJ");
    double BBwmWZbWJnyFXsEX = 155085.2747767096;
    int nQOoZFo = 1820690207;

    for (int RYEwjVcNUzyd = 146700487; RYEwjVcNUzyd > 0; RYEwjVcNUzyd--) {
        continue;
    }

    if (infjLiQxdB > string("lFYhNqLRELymVsWshWVWZgUcsMLRPuthQewiTSxNZguqJeBTVrHgZgCGmOIYVMkfwUtPCiPimqmFvKhCIimNrsqGtmblZtzylTTMxvzyPAAnipQTsbMrYIvqocITpfFysCz")) {
        for (int dASKysWTrnM = 1350712644; dASKysWTrnM > 0; dASKysWTrnM--) {
            eCgDyBEW += iLrHubYYstlUbf;
            BBwmWZbWJnyFXsEX = tHsukuzrAvQnXwL;
            eCgDyBEW = eCgDyBEW;
        }
    }

    for (int UsIwUDtOCQLhWiZ = 675937306; UsIwUDtOCQLhWiZ > 0; UsIwUDtOCQLhWiZ--) {
        continue;
    }

    for (int RKvBSsSKxJ = 1888293811; RKvBSsSKxJ > 0; RKvBSsSKxJ--) {
        iLrHubYYstlUbf += infjLiQxdB;
        iLrHubYYstlUbf += infjLiQxdB;
    }

    for (int GnOZRYAFw = 565631679; GnOZRYAFw > 0; GnOZRYAFw--) {
        nQOoZFo -= nQOoZFo;
        infjLiQxdB += iLrHubYYstlUbf;
    }

    return CYJwoAPRvhBcNPg;
}

double tRMHJHwh::HSggkCY()
{
    double XFeDHMlEFVwC = -410298.27836450306;
    double CvmbTbyO = -575926.65139496;
    string hOTwEDIkRn = string("tqEEJuRGiQVRLdRKWrfzKOOEfSjyGShfdWNKbeWFoelXMqBbycvZFtPcRHrcJrRpRUUiKMpVkujHairslDzTZRhsAifKpBmCRlCVjywBcyfEoyPAoXynQPJAZdFcrloGmu");
    bool ewihIwXoJhUUIH = true;
    double FDBDAynwdE = -627399.5016341897;

    if (hOTwEDIkRn != string("tqEEJuRGiQVRLdRKWrfzKOOEfSjyGShfdWNKbeWFoelXMqBbycvZFtPcRHrcJrRpRUUiKMpVkujHairslDzTZRhsAifKpBmCRlCVjywBcyfEoyPAoXynQPJAZdFcrloGmu")) {
        for (int HjWkRBvnaiGdvNH = 215198370; HjWkRBvnaiGdvNH > 0; HjWkRBvnaiGdvNH--) {
            FDBDAynwdE /= XFeDHMlEFVwC;
        }
    }

    for (int PEkPUn = 413600526; PEkPUn > 0; PEkPUn--) {
        CvmbTbyO += XFeDHMlEFVwC;
        FDBDAynwdE += FDBDAynwdE;
        hOTwEDIkRn = hOTwEDIkRn;
        CvmbTbyO += CvmbTbyO;
    }

    return FDBDAynwdE;
}

double tRMHJHwh::TJjIrvrkdVM(bool EmtwKNNLuGotq, int cVqHop)
{
    bool MDHZTU = false;
    double ZPMVBpVg = -11849.115891347397;
    int FKLfNQcOMqYcAkri = 2077734649;
    int bhCsQr = 1962037952;
    int TlHFiVYQGsFKq = 1489641775;
    double kfBGgGedAqiM = -405746.9263758254;

    if (MDHZTU != false) {
        for (int IyNjhrAM = 949128026; IyNjhrAM > 0; IyNjhrAM--) {
            ZPMVBpVg += kfBGgGedAqiM;
        }
    }

    if (FKLfNQcOMqYcAkri < -2132290428) {
        for (int NKCXFRixsDGwFq = 756235278; NKCXFRixsDGwFq > 0; NKCXFRixsDGwFq--) {
            bhCsQr -= bhCsQr;
            MDHZTU = EmtwKNNLuGotq;
            FKLfNQcOMqYcAkri /= bhCsQr;
            TlHFiVYQGsFKq -= TlHFiVYQGsFKq;
        }
    }

    if (ZPMVBpVg != -405746.9263758254) {
        for (int KozFcflE = 461805844; KozFcflE > 0; KozFcflE--) {
            bhCsQr = bhCsQr;
            kfBGgGedAqiM *= ZPMVBpVg;
            EmtwKNNLuGotq = MDHZTU;
        }
    }

    return kfBGgGedAqiM;
}

int tRMHJHwh::TjdHgt(bool xezcOb, string jqlJt, int XrGDjBQNxcYNPn, string xCDPVDRvOnE)
{
    bool gPHvCOeCD = true;
    int wEKJKkUVjJKDFVed = -883898153;

    if (XrGDjBQNxcYNPn != -883898153) {
        for (int GMsbdHMHew = 843176423; GMsbdHMHew > 0; GMsbdHMHew--) {
            XrGDjBQNxcYNPn += wEKJKkUVjJKDFVed;
        }
    }

    for (int UnGIrozOPLdKd = 1301142216; UnGIrozOPLdKd > 0; UnGIrozOPLdKd--) {
        xCDPVDRvOnE = xCDPVDRvOnE;
        xCDPVDRvOnE += xCDPVDRvOnE;
        xCDPVDRvOnE += jqlJt;
    }

    return wEKJKkUVjJKDFVed;
}

bool tRMHJHwh::PzLfLWOhMYR(string pQAmnTeMBbrni)
{
    double fnGTMF = -282213.42901335505;
    double LJNVlDbkuIRqeJjS = 71715.90385187019;

    for (int ScdYeDLl = 1562913537; ScdYeDLl > 0; ScdYeDLl--) {
        fnGTMF /= fnGTMF;
        fnGTMF *= fnGTMF;
        LJNVlDbkuIRqeJjS += LJNVlDbkuIRqeJjS;
    }

    if (LJNVlDbkuIRqeJjS == -282213.42901335505) {
        for (int BlxNXkFmVuPlQfJg = 402295802; BlxNXkFmVuPlQfJg > 0; BlxNXkFmVuPlQfJg--) {
            pQAmnTeMBbrni += pQAmnTeMBbrni;
        }
    }

    for (int lBFnySxRpdHe = 1821667122; lBFnySxRpdHe > 0; lBFnySxRpdHe--) {
        LJNVlDbkuIRqeJjS += fnGTMF;
    }

    return true;
}

string tRMHJHwh::BnwfrahMjG(double KAHPAsHzBkmUDSUZ)
{
    double JjUAAlrVccalK = -525092.8570958165;
    bool byrfdAxbB = false;

    if (JjUAAlrVccalK == 289227.7915730211) {
        for (int lMauFTm = 276716528; lMauFTm > 0; lMauFTm--) {
            byrfdAxbB = byrfdAxbB;
            KAHPAsHzBkmUDSUZ += KAHPAsHzBkmUDSUZ;
        }
    }

    return string("lIXzobWnCdbiQNqzbSXdyuLqyOjwepIEtJLzDMRuLlEdDOEIEqjxZTwUeQNIqpwTVqTmzwVqJkvHsbmgSCntZSuziZrGnLuBirMvEIXGUFImdiypFfdHqiQIFUjqBmqfyQjaqXdUThWABiPpFGxNyPhpVYkZNwvfhKAjDpjQVCiyNcxUmbNowbmSnnCYjtvuWNbixCLgjZAYyvYqudXrLiUTLezWwWeCMqlNcorkeRHsLqjrrWoXaN");
}

int tRMHJHwh::MDGBOeCT()
{
    string wBEByNsOhAoAFTOw = string("GiQaojFOfXeyBJmOSuXFimIYuFiPGkspGTblfeQizhhdytXDVmbDRwvxhLiAjKWdxlFvVRCyEYHaPoXCcATgZfJTxMAKVSnAqMXrqKGpNrAOlWvKAsxDaQBHClSjpqaUClIXMmvndo");
    int oXwBOkMFkZtHUxzh = -1766394466;
    bool VnQsBOu = true;
    bool BHDSwR = false;
    bool cBuHZbGIEdfPGsBv = true;
    bool ofFHrhFcuZ = false;
    double hmvVgTLspe = -787406.430352869;
    string FsXtryuwD = string("DrkQqmvXIguZmjfytVdHjeSFHHZHCzAkTFaWxQjDCmgHYmxJSal");
    string ulhyDfabNbCT = string("vkvpSEKReBmpbuhgHYRLiUOxUnJPhMUrruXpgmtfaxYIrXNwUtjBIQMyumzfMsIHqIOfzDDEGMsssBhhNhxYcIYpJXYWOxtaiWinQHuDevGAfdQpGiPIsVtkASHqkRFyMCShKhABEIFrNtbgtFrcVvwdBqeXcqVhxARPuNdXmBJEBOVzoRVDxCtJMjwDAOGvFjyGmrQAzKgYgbsvvGjyTqrKESrdFTBBrrFvKlRDierAkokABVnfssKW");

    for (int ZaDBCLuzBhMQVNB = 443161057; ZaDBCLuzBhMQVNB > 0; ZaDBCLuzBhMQVNB--) {
        wBEByNsOhAoAFTOw = ulhyDfabNbCT;
    }

    if (ofFHrhFcuZ != true) {
        for (int lhBHxspBCF = 899375627; lhBHxspBCF > 0; lhBHxspBCF--) {
            cBuHZbGIEdfPGsBv = ! BHDSwR;
            ulhyDfabNbCT += ulhyDfabNbCT;
            ofFHrhFcuZ = ofFHrhFcuZ;
        }
    }

    return oXwBOkMFkZtHUxzh;
}

void tRMHJHwh::izYcjXS(string ceslFHmM, double sJxZUbuqNrg)
{
    double SjVUWMcBnwDq = 750175.9324708328;
    string oZdPcQ = string("aGbarSajppjJSQolmERzNoKTodvzEcJVawJCWZfvAWNWovPTEfEZGmfimgAONwjyqoLIqpRpxqvxTlRLmhAIyLnrxPTAdNFVxcJPEYKEXLVxYNJwGlSjHkLBXiE");
    bool PJZeGURG = true;

    for (int UtzoLVwg = 1716613413; UtzoLVwg > 0; UtzoLVwg--) {
        continue;
    }

    for (int svfiK = 657794382; svfiK > 0; svfiK--) {
        sJxZUbuqNrg += sJxZUbuqNrg;
        oZdPcQ = oZdPcQ;
    }

    if (ceslFHmM >= string("aGbarSajppjJSQolmERzNoKTodvzEcJVawJCWZfvAWNWovPTEfEZGmfimgAONwjyqoLIqpRpxqvxTlRLmhAIyLnrxPTAdNFVxcJPEYKEXLVxYNJwGlSjHkLBXiE")) {
        for (int YxjxegmOmdGDa = 757189070; YxjxegmOmdGDa > 0; YxjxegmOmdGDa--) {
            ceslFHmM += ceslFHmM;
            sJxZUbuqNrg -= sJxZUbuqNrg;
        }
    }
}

tRMHJHwh::tRMHJHwh()
{
    this->BUgnXW();
    this->SZljAHTZEUpJm(990518.4260861631, true);
    this->UKKsfucvMNciYMm(-700107559, string("kYbIYoUqixyalDxraACspALmSgnwSRVgGANIIxHcHPHdWf"), 1156238955);
    this->TroItHMksd(94935.0164000588);
    this->JXfnLqTN(106350556, string("bIAsrsfEzPMGlDDfmXKIvVvJpugzTZERcscCRNqCwUgdbuxXWMPDecCavjSeqkJYfMINewZQTuspPNsMjpyXdREvjRWRwpjggNJiuSDWhUgxPnqwrBPXLTKHXUDOzjJuKosJTnRamqCpwGVErNGrjGDsUKCgbmnrDppGMbcclQRW"), 890821.2918458013);
    this->bxfWcOvJzvLzqGP();
    this->OhuTkuteaaGCQt();
    this->EJUiVUzxP(string("UDVSMcByVLJsjjokhqsdGcxWQViloLwecmxLKkVKYVvQhreWCXDjNwINDDawGsRQvejMkVJxxmyBqiQoIKfKSfnLnvdKbuGOwSlOEZqRVxbRzzzyVCHMFPVxQpmLlKflEMmZz"), string("lFYhNqLRELymVsWshWVWZgUcsMLRPuthQewiTSxNZguqJeBTVrHgZgCGmOIYVMkfwUtPCiPimqmFvKhCIimNrsqGtmblZtzylTTMxvzyPAAnipQTsbMrYIvqocITpfFysCz"));
    this->HSggkCY();
    this->TJjIrvrkdVM(false, -2132290428);
    this->TjdHgt(false, string("dAvGmaORUBcphAtRdZKyffjIlFHuNUmmnGfpAFEhcsOkyIMcjjYNOAAUUlwtdkdCISELDSyrk"), -344870230, string("qUTfOlbqzpzvnzpFeTlLKOaROlBqhobkUQMYGXSfxvmAjzyTZLqwVwjbNLcesqrTOrvMexC"));
    this->PzLfLWOhMYR(string("yQpLkMzhislZZyppFYLkpLlcTAwnHaVVRmXACqrWHuiYlTEaloQCYEqtAhDKLNpNCuGQaDbrMklkhQmxIgjKRbKgtaoMJICR"));
    this->BnwfrahMjG(289227.7915730211);
    this->MDGBOeCT();
    this->izYcjXS(string("gQInjRtRDGhhMzumCRrbKEJIUAd"), -171371.49319905476);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ILCvqFQdTysNH
{
public:
    int IxPHp;

    ILCvqFQdTysNH();
    int QADwrCH(double ARppliwIl, string oIKLD);
protected:
    string ArSMdSJWlTu;
    double hECMCHKpMaLB;
    int ibMCqcI;
    double ZNvDwXDNGk;
    double uKdrDuB;

    double ipywKV();
    double DPNDTkFctvqgSuam(bool RNuKNn, int XstiiUvgoXN, bool wwjgaxVGFdCHiAP, string teifoduCdu, string nTarPgX);
    bool CjWgSyEWi(double inxYPjeKri, int LfwuMJPyurniY, bool xCUboVxPhjKwZ);
    int VRLQn(bool FdTFCHOnGVFbeCn, bool cbsTrnZfWaqOd, bool mKSJrZQakdQGu, bool GaVvlXTp, int eLModmDZ);
    string dGzfymbkNLluCZuh(string baHQrPk, int YnhEiw, int FAQFLhnWd, bool EfDpjHqibBnowY, int RpuSbC);
    bool FucqcBADWZPBjIut(double jmdQyjIYUpY, bool OxxVjtJyhemczDw);
private:
    int VdnpBOsJXf;
    double QFNxpUHZlaSHvwo;
    bool BAIhCI;
    int sOHtxaiBZknMc;

    int rJLPk(string AYfJa);
    void IRfliwWTmIjxQYTu(double txJhkeSuZ, double IQDgGDnhGbLFJX, double OPZQFuBMyK);
    bool hwtLvuvhPMSaUx(int nxszgmZgnhw, double egOSdFwKxYUvqcbI, string MBtpIvgH, string hFXhtkNMHQYBEX);
    bool yUTsJy(string bUHdsiDFDr, double zUHTSviOZJNgIer);
    int fzWSzvrBBfiNSMLz(double KxWROK);
};

int ILCvqFQdTysNH::QADwrCH(double ARppliwIl, string oIKLD)
{
    double HhvCutzZUALed = -612013.3612329641;
    int TIusbdMQXybZG = -667729933;

    for (int pmanHOE = 1684843375; pmanHOE > 0; pmanHOE--) {
        HhvCutzZUALed /= HhvCutzZUALed;
        ARppliwIl /= HhvCutzZUALed;
        HhvCutzZUALed = HhvCutzZUALed;
        HhvCutzZUALed = ARppliwIl;
        HhvCutzZUALed = ARppliwIl;
    }

    for (int kLMJu = 1904437774; kLMJu > 0; kLMJu--) {
        ARppliwIl -= HhvCutzZUALed;
    }

    for (int FFKRE = 381376599; FFKRE > 0; FFKRE--) {
        HhvCutzZUALed -= ARppliwIl;
        oIKLD += oIKLD;
        ARppliwIl = ARppliwIl;
    }

    return TIusbdMQXybZG;
}

double ILCvqFQdTysNH::ipywKV()
{
    string nzMGXTSTAocN = string("YxJCSyhiACrDWjhgWVLUJhpRorOjoDoUpacfKddnhmEjEUzDLjeQlTGmOgDRJhBFvQKZUGwvTOOLVWIdJRMztTJAtFfgMudlvJpv");
    double RWRkbjSQduaLBVoP = -642878.8933835765;
    string LxJCvebXq = string("urJrvtFYSbxyfDTKnRsBdzSoXaVOzKRnBzdaEYfBoughFzKPKyfoOGZrRbEHjiiYsdoQycEUxzgKdmOocQZZWLNUOBqHlcTbzSaEcvqxFEkUunMvZAHvvtxoyxRMOmkCyKGwCqZsVapVSEKUqAyfTEqbKHeNBvLQTLHByFzqLWhlyFAeuRqsuAvnlyhYJbNWxDPqRTMRlLZusr");
    int YmFYfLMc = -360034144;
    bool MtvITE = true;
    string hnVmVIPTBPPHzMI = string("uOJEjIaCGonAbesxv");

    for (int WrYKBGFB = 818440079; WrYKBGFB > 0; WrYKBGFB--) {
        hnVmVIPTBPPHzMI += hnVmVIPTBPPHzMI;
        nzMGXTSTAocN += LxJCvebXq;
        LxJCvebXq = LxJCvebXq;
    }

    if (hnVmVIPTBPPHzMI == string("uOJEjIaCGonAbesxv")) {
        for (int EanVrkHgcYsi = 135519852; EanVrkHgcYsi > 0; EanVrkHgcYsi--) {
            nzMGXTSTAocN = nzMGXTSTAocN;
            nzMGXTSTAocN = LxJCvebXq;
        }
    }

    for (int LSKSLUvtMbNYVKQ = 46227088; LSKSLUvtMbNYVKQ > 0; LSKSLUvtMbNYVKQ--) {
        RWRkbjSQduaLBVoP += RWRkbjSQduaLBVoP;
        YmFYfLMc += YmFYfLMc;
        YmFYfLMc /= YmFYfLMc;
    }

    for (int axWVvjty = 265815333; axWVvjty > 0; axWVvjty--) {
        LxJCvebXq += nzMGXTSTAocN;
        nzMGXTSTAocN += LxJCvebXq;
    }

    return RWRkbjSQduaLBVoP;
}

double ILCvqFQdTysNH::DPNDTkFctvqgSuam(bool RNuKNn, int XstiiUvgoXN, bool wwjgaxVGFdCHiAP, string teifoduCdu, string nTarPgX)
{
    int YOGArZs = 2005254371;
    bool nRmhsooUF = true;
    double CoHhAiWaZKGvsbSM = -827532.8507057647;
    bool AnZfUNBcUdDTja = true;

    if (YOGArZs < 2005254371) {
        for (int ylFysiynIosNSD = 1253680399; ylFysiynIosNSD > 0; ylFysiynIosNSD--) {
            YOGArZs *= XstiiUvgoXN;
            AnZfUNBcUdDTja = ! RNuKNn;
            wwjgaxVGFdCHiAP = RNuKNn;
            teifoduCdu += nTarPgX;
        }
    }

    if (RNuKNn == true) {
        for (int ZkVFzv = 1101602428; ZkVFzv > 0; ZkVFzv--) {
            continue;
        }
    }

    return CoHhAiWaZKGvsbSM;
}

bool ILCvqFQdTysNH::CjWgSyEWi(double inxYPjeKri, int LfwuMJPyurniY, bool xCUboVxPhjKwZ)
{
    double eUOhYYdR = 1016909.1685014565;

    for (int HIfBzhFLcVGr = 1896689129; HIfBzhFLcVGr > 0; HIfBzhFLcVGr--) {
        LfwuMJPyurniY = LfwuMJPyurniY;
    }

    for (int yuKuzWGDLZco = 1442337423; yuKuzWGDLZco > 0; yuKuzWGDLZco--) {
        inxYPjeKri += eUOhYYdR;
    }

    if (inxYPjeKri == 1016909.1685014565) {
        for (int TNkpbUUHxDUkA = 139093851; TNkpbUUHxDUkA > 0; TNkpbUUHxDUkA--) {
            eUOhYYdR *= eUOhYYdR;
        }
    }

    if (inxYPjeKri < -212070.75054682777) {
        for (int wwPwpfxWXZHk = 914137946; wwPwpfxWXZHk > 0; wwPwpfxWXZHk--) {
            eUOhYYdR = eUOhYYdR;
            inxYPjeKri = eUOhYYdR;
            LfwuMJPyurniY += LfwuMJPyurniY;
        }
    }

    return xCUboVxPhjKwZ;
}

int ILCvqFQdTysNH::VRLQn(bool FdTFCHOnGVFbeCn, bool cbsTrnZfWaqOd, bool mKSJrZQakdQGu, bool GaVvlXTp, int eLModmDZ)
{
    double XYCBnE = 576508.9295120669;
    bool wDHjZWLtNH = true;
    double qqIXt = -243276.5164221749;
    bool SKZSleayJb = false;
    double QEyhudaXR = 505842.33837350376;

    for (int TEOmobClPp = 1396953844; TEOmobClPp > 0; TEOmobClPp--) {
        mKSJrZQakdQGu = cbsTrnZfWaqOd;
        QEyhudaXR *= XYCBnE;
        SKZSleayJb = ! cbsTrnZfWaqOd;
        cbsTrnZfWaqOd = ! SKZSleayJb;
    }

    if (SKZSleayJb != false) {
        for (int WYJWcPPFRlId = 1037302332; WYJWcPPFRlId > 0; WYJWcPPFRlId--) {
            FdTFCHOnGVFbeCn = ! wDHjZWLtNH;
            mKSJrZQakdQGu = mKSJrZQakdQGu;
            SKZSleayJb = ! GaVvlXTp;
            wDHjZWLtNH = GaVvlXTp;
        }
    }

    if (cbsTrnZfWaqOd != false) {
        for (int wRKiPZKTxCUgyk = 1944327421; wRKiPZKTxCUgyk > 0; wRKiPZKTxCUgyk--) {
            cbsTrnZfWaqOd = ! mKSJrZQakdQGu;
        }
    }

    for (int OUcoxNFt = 895097970; OUcoxNFt > 0; OUcoxNFt--) {
        continue;
    }

    return eLModmDZ;
}

string ILCvqFQdTysNH::dGzfymbkNLluCZuh(string baHQrPk, int YnhEiw, int FAQFLhnWd, bool EfDpjHqibBnowY, int RpuSbC)
{
    string pZDjpvnOOumP = string("GdeIflrTmTjRKIzXZTaVRMtTVvgXDGYirgEvctmmhiKtwYKTUJN");
    bool yveLKsQqkGZRaGL = true;
    string CJocp = string("AFsHFJkFaKGsTDiJEBUfbGJHgFgwXUqKkbUWUOfaIUOCSxdVnWanQhZTzLyycrZSuYsWyohkpFOZNMXqzYAwujIJwmZWWPKQmzwbPypIjDeYJlQICFATNJMNnnbkqIm");

    if (FAQFLhnWd != 1715596358) {
        for (int hvcpRJd = 1759789759; hvcpRJd > 0; hvcpRJd--) {
            pZDjpvnOOumP += pZDjpvnOOumP;
            FAQFLhnWd += FAQFLhnWd;
            EfDpjHqibBnowY = EfDpjHqibBnowY;
            YnhEiw *= RpuSbC;
        }
    }

    for (int kvzNy = 1811517058; kvzNy > 0; kvzNy--) {
        continue;
    }

    for (int enhjcOhpi = 656913336; enhjcOhpi > 0; enhjcOhpi--) {
        continue;
    }

    return CJocp;
}

bool ILCvqFQdTysNH::FucqcBADWZPBjIut(double jmdQyjIYUpY, bool OxxVjtJyhemczDw)
{
    bool KcWLy = true;
    bool douERB = false;
    string qLWxaP = string("qHeTBKYhyNurRUNYzUaCHawXttJzpaEenKLLlympectHTNHmzAcMPVzWYADntiVRshpmqFsmysEhBJhzenps");
    bool uKuvnbnixaAkk = false;
    bool CirEbwpEsYS = false;
    string PrhJWmLO = string("junSuGmewuXwLamaTelAJBkXLlbQejvTbyltUDmmjsjRGJASDCYBnGRDHTdvRqShEmsvpnckowXKaHdIfDPawsUatxKxCqpioUkdHCixWoKUP");
    bool epmmPLw = true;

    if (uKuvnbnixaAkk != false) {
        for (int yTktwILBSTBu = 1305577186; yTktwILBSTBu > 0; yTktwILBSTBu--) {
            KcWLy = douERB;
            douERB = ! douERB;
            epmmPLw = OxxVjtJyhemczDw;
            jmdQyjIYUpY += jmdQyjIYUpY;
        }
    }

    return epmmPLw;
}

int ILCvqFQdTysNH::rJLPk(string AYfJa)
{
    double RdrACZJGujybmJz = 434515.0178493995;
    bool QlkfLVFLbmxcyE = false;
    string xuaXTBfwJHoQ = string("ELLJVPLHnYKFvwmDbafLCCMKcsSJgMXXZYXXRYZnaBWEHYqiivavMcnPk");
    bool WDlAyJrKaLQGlHd = true;
    string xAfloSag = string("JnKMqEOqsXhvVIQlDvQUalqnwRWyotgTSjDzsCiopuAtcDkXtRrlImQUcAvLMtkYjwTRUicQDSrjrvKxgLjcoKgDoQLDHfUYpjeJnBUYDvApnGANdaOAeNoIaDUukxHblrxvNkyDJUwzmwSvdiBWZGfwqPctXxZEhaUNfpEZPJbqYCWiqEjYiIj");
    string nrJdeamOWLcxNUG = string("BGckARZCNBMoMWxPGNrLMkpypvAJ");
    bool BuUcUsNtHMg = false;
    string kvOSGzSOfeKPYu = string("oHgrZhtHwRrtyjGmPfuPkQxVEfKUNQULJtBqzmSoSaUikvZRgbCioHDLHREfuvbPGtDWkYyorS");
    bool kifeMlWsrKbKB = true;

    for (int aphCblDoC = 1058147531; aphCblDoC > 0; aphCblDoC--) {
        kvOSGzSOfeKPYu = kvOSGzSOfeKPYu;
        kifeMlWsrKbKB = ! BuUcUsNtHMg;
        QlkfLVFLbmxcyE = kifeMlWsrKbKB;
    }

    for (int KJpFY = 1636735781; KJpFY > 0; KJpFY--) {
        kvOSGzSOfeKPYu += nrJdeamOWLcxNUG;
    }

    return -1541327382;
}

void ILCvqFQdTysNH::IRfliwWTmIjxQYTu(double txJhkeSuZ, double IQDgGDnhGbLFJX, double OPZQFuBMyK)
{
    string mDOlSULpYVCUSwX = string("gybHidCkyMhaxiXzpBUXBvdQpFqOhSGIRpLdfCBzblVBdumLYZqRoVKCAUqruYdMUodbOHGkXYExZgHcvAMsxlAoQnNNuJxUtpVFbyvVIIZndqWJDVJIjNpycjFFKagheCubFBjclLEPDXgAiIrFpUWoJELryL");
}

bool ILCvqFQdTysNH::hwtLvuvhPMSaUx(int nxszgmZgnhw, double egOSdFwKxYUvqcbI, string MBtpIvgH, string hFXhtkNMHQYBEX)
{
    string TobktG = string("ERcFwRTaEhyyifEWlAeJgCJiOLOYmQGHFHDtpVnywseJwNOIqVCCaERjsWfQKTGBuPMwrJVvFIPbvSyfyVokfCfReGugFgqRABkJZNDtcZfmjtYBmpbJvRmMLTvNqRUnCNLKBYDRKggarJjoWqJXAiTbqHoDeoyYhABAaiQmiNtIrzFtESzACyzXeWdhkhotbAttknDjdnpRwSeKHKpNppHcSEovMktGhjKxQMaiqInowYPBk");
    double oyLlimIvfIDUemWA = -584116.0588157303;
    bool cpCCGp = true;
    double EqGpoZ = 669150.4634136925;
    int bKNKtJwnNXBN = -1736929412;
    int YhjDb = 1953697495;
    string kjxVElDXGwh = string("NSYQIsJKSZGIWLSoDHceDeaYtfsYEqKVsueVoJtUUBTevFKPdjXiXuMfWoqawsDIsufRGXKclRtdwrhVytCJvdWaCcRVseCkJDJWdGlzsWJGvgzgLPdzvDDWOFzKQbrKSKcWtWubCEjQKgdSxctcPewSXSwqrrEfcGjXTNrBFtJvgNIiLYlBEtihwJayqBckuxUpmsikArZDDOPjXGiomHEIBEebDszZBzKqctNJyK");
    string qFXJMkolUlMjqAX = string("BkmQQGGWOYhytjSblwcLaAyrxtTtFcajIDhUqZaoxOlIqCQNxWWnwBkIuEFzaVRuNUgxRDKKZezsvBzljPvLtAzfueAlxRiOKYWRtKNtwZIQvQOBpJFWgiLIOEhLbdiMGHCLgLUCgcJuTXmJNEmkhykUQH");
    string ULTRmKqcu = string("vNzCfzRlzNxxiXrpEOvrWufJptyMbXWqBpvlTTiLtEdUynDqPqtNNAuPLmWeFFWlDSBVffJYxlDKuPdGhVPDMPlwpQkPKXTKmkNvWHqxPEKswuXcmzUnGxokfFPxegeEmESoxxsYhjMvaRyczaapYxGBWNNxwSfITlaWUCqUJySOviutyEYemWSbvjcDflHoVrpPRLlWubalLiInFl");

    for (int dAmwdh = 1867110924; dAmwdh > 0; dAmwdh--) {
        TobktG = TobktG;
        bKNKtJwnNXBN += bKNKtJwnNXBN;
    }

    if (egOSdFwKxYUvqcbI > -584116.0588157303) {
        for (int eXEzp = 295665853; eXEzp > 0; eXEzp--) {
            nxszgmZgnhw *= bKNKtJwnNXBN;
            qFXJMkolUlMjqAX += kjxVElDXGwh;
        }
    }

    for (int DWLItQsUPYga = 249027023; DWLItQsUPYga > 0; DWLItQsUPYga--) {
        continue;
    }

    for (int mnomXVFCcyGCNSB = 641244014; mnomXVFCcyGCNSB > 0; mnomXVFCcyGCNSB--) {
        TobktG += TobktG;
    }

    return cpCCGp;
}

bool ILCvqFQdTysNH::yUTsJy(string bUHdsiDFDr, double zUHTSviOZJNgIer)
{
    int xhXCMBhBDrWte = -262447906;

    for (int wCmDEVYp = 1095874038; wCmDEVYp > 0; wCmDEVYp--) {
        xhXCMBhBDrWte *= xhXCMBhBDrWte;
    }

    if (xhXCMBhBDrWte >= -262447906) {
        for (int FyLdD = 939923137; FyLdD > 0; FyLdD--) {
            zUHTSviOZJNgIer += zUHTSviOZJNgIer;
            bUHdsiDFDr += bUHdsiDFDr;
        }
    }

    for (int yNhkfIv = 2126071677; yNhkfIv > 0; yNhkfIv--) {
        zUHTSviOZJNgIer = zUHTSviOZJNgIer;
    }

    return true;
}

int ILCvqFQdTysNH::fzWSzvrBBfiNSMLz(double KxWROK)
{
    bool uHqktPlTStv = true;
    bool WxTnetKdulVJJS = false;
    int ulcOjR = -229129637;
    int tUQwAKfeAJvW = -842574305;

    for (int IsGiNNbWEQqQz = 172493142; IsGiNNbWEQqQz > 0; IsGiNNbWEQqQz--) {
        ulcOjR *= ulcOjR;
        tUQwAKfeAJvW -= ulcOjR;
    }

    for (int CSUEZRHrGGveRX = 719335252; CSUEZRHrGGveRX > 0; CSUEZRHrGGveRX--) {
        continue;
    }

    if (ulcOjR == -229129637) {
        for (int daTLiKgZNPBAAJP = 1941465435; daTLiKgZNPBAAJP > 0; daTLiKgZNPBAAJP--) {
            WxTnetKdulVJJS = uHqktPlTStv;
            uHqktPlTStv = ! WxTnetKdulVJJS;
            WxTnetKdulVJJS = ! uHqktPlTStv;
            tUQwAKfeAJvW -= ulcOjR;
            KxWROK -= KxWROK;
        }
    }

    for (int BjbbfOKAMvn = 1007250931; BjbbfOKAMvn > 0; BjbbfOKAMvn--) {
        continue;
    }

    if (WxTnetKdulVJJS == false) {
        for (int xakapmaChzbM = 1925154456; xakapmaChzbM > 0; xakapmaChzbM--) {
            uHqktPlTStv = WxTnetKdulVJJS;
        }
    }

    return tUQwAKfeAJvW;
}

ILCvqFQdTysNH::ILCvqFQdTysNH()
{
    this->QADwrCH(899962.6964862256, string("XsQIYWpzVWMOPQcxujIQatzTbuQUpRbcnpHdFMesUJWACYNyLLGOUDRkokoejTIN"));
    this->ipywKV();
    this->DPNDTkFctvqgSuam(true, 1972798728, true, string("htozKeFdTXygFPXavSlFGjCEKZMZ"), string("PBoNsKFKwKTLdxxJagzKrLhkbhAcrTzjmcYosHeTNxDqRlZoCNMJrdeEIAnZMzmryXktytFUgEiLabTDuqJAQaAAqYCLSYJWPUrTSUEnWIqdEoOqSVpOncuTYI"));
    this->CjWgSyEWi(-212070.75054682777, 1198097610, true);
    this->VRLQn(false, false, true, true, -768508808);
    this->dGzfymbkNLluCZuh(string("QymmqzkcDuUVmDgypZaoyfpTRFxSNliHiMgfsKmlrUrOVIwwyxUFPQNwpkhfqnvgRdRmoQKpKXiLbcqRVeNaXtHfwMpuhYJwthhXUpYBDeuOEyaKsywXjyuleEGuPAuaErNaOAntsOBkRPfBGjvZQMVdGCgmYYhyuCpraHVKaTEvoBRMULoqOvptLJAPkQbTfyudyIitudgdkTIXRLJJEpEzyxoQTJt"), 1715596358, -276013909, false, 2014410168);
    this->FucqcBADWZPBjIut(846340.1644514397, true);
    this->rJLPk(string("BTyOMsWKVJnEAokvcgUSxchbiJoCynHbPxRskESqkcEWslEynznGWUMtGnhOwJlsCDpMbvPeGHdoxvOiJPmPXekRWWHcqyRrDybLuOjYlErcvGKUPtN"));
    this->IRfliwWTmIjxQYTu(-927188.6124644862, -161469.22015350897, 268401.72273265966);
    this->hwtLvuvhPMSaUx(1481186447, 766883.6352909573, string("jpmNEYlZSxECykcxbSowxYKhmIHPwNqLszblpJMmytdNNecXZsQpHyPeoduVwEgGtwWUIOmfBxCiJHpZuhDehAslsXfXrTKEPuxgtSwDHDImulhwBACCwBecpjFFipNcmvYumWCvEvpusvtpGVfNmmwqOUmHkvZxfsxTwZHiJGZDKTgxkIvxNbXmTUZTcXFLjHGHEHYsvfzuxDfmhdlmqZxGpFfduPnJgea"), string("wXNkibDkvPdzrXxuVpwuWNwJnbHriOvgSMDMXUUBVJdBLEiVUgLnmGHoPtJIybJDfpkJKXMBhcybcgPirICTHPZEVHhoQiNtngajlksjelakSgwKrgCVtOmXmAfqJdgPOgZpDUdRqPyazsAdPuiXo"));
    this->yUTsJy(string("pSOdAROcvacVjjFSnqedonOaAACqcchtXaoYaKQaOtFdyYMXTwkwJxIuCFguWetCQsahLrSTvTZXDLKibgRTBJhliTMHKEHsDxzgvlANldTFygYDzHiAusUvvMRrlBEWaXPACxaagTsFoGdaKjOObpYARXqcXDGuQTvmGMHGrzZPPCiLZLFmUzywwJUYYdTmCzUkNSInKzJNoSAXRIzBuPlBPyxnFXlFZkEHNfSqr"), -903299.1094090473);
    this->fzWSzvrBBfiNSMLz(44056.98069128693);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rWQxsnvfGdj
{
public:
    string EMzfaz;
    double PYOEGOMrO;
    bool xOKwPfvsvtwup;
    bool xMzpoLx;
    bool XIXhZplWEyeEebQ;
    string RBYaluiIcDFJ;

    rWQxsnvfGdj();
    void CdMarXQDf(bool SZHcEgKOvBLCJ, int TGOvjSCjnONddopu, double FVEDlE);
    double tBJXLRXJR(double dpjmiQxUxllmO, string vtXFxvgEKitLv, bool BpmykZEwclUep, int KBRZEu);
    int zqXEp(string TdCJYDALF, bool UMVumrq, string favWOCumUIIxsfOa);
    string KsQvhvxrOXeK(string FrNQwArrcmWxBa, int rJKFSVLti);
    string zXZqRGm(bool kSyzBktZWhljo, string IFzPa, int RHvitfJGy, string xVtLARtONSpx);
    int KNUExwhzDYzJcX();
    string GwdKrMh(bool uPAFLmNCE);
protected:
    double CaggVWUkOiJrJmaN;
    int fgjAjwpdbAcpmbbj;
    string MwTJKvmsr;

    double TXeLxoPA(double ycgepoQTZeNT, int OMYdJMxepKWahj, int WuRUdcRXR, bool xQnAccmHjoUifpld, bool MblZYLi);
    double dQwLqmFBSWZEgYK(bool pQUkVaGdiUweR, double rSNlNQdpX, int DUpYe, int ndozakXQYJUxiz, bool Idovlh);
    bool USTWhJZUWypvMxeo(string esMXjqq, int rLycEe, double TXdvrjWaKi, int PhpDHwuVBe, int dsexQzJknMXNcaUB);
    int tZGmXLGQb(bool OmhVxXKhnRVUH, double MXAjtsMxr, bool zuBfYBmHkne);
    string XDUjxXuoUZmxn(string ToInsDrSwqw, double dfkgFFLRzQucWAn, double kKVAgnlRBHzzY, double AnwdeIVtvYJFT, string vSMkMhRhiFtZQV);
private:
    int kDeRi;

};

void rWQxsnvfGdj::CdMarXQDf(bool SZHcEgKOvBLCJ, int TGOvjSCjnONddopu, double FVEDlE)
{
    int fKUwYOdgA = -797207337;
    double dBKfSWdjtisH = 780601.1671427253;
    bool sePymDl = true;
    bool XsgBAx = false;
    double itXpXRFBCqLW = 332794.3889429245;
    string NLbAWyBi = string("IBeTCqKgZsyfNdCoBtIuecrhYyERaWbgSPzghSjecdPb");

    if (fKUwYOdgA >= -797207337) {
        for (int HMTpJOZL = 1877933083; HMTpJOZL > 0; HMTpJOZL--) {
            XsgBAx = ! SZHcEgKOvBLCJ;
            sePymDl = sePymDl;
            SZHcEgKOvBLCJ = ! XsgBAx;
        }
    }

    for (int uUemfyobUOoAdJie = 84537194; uUemfyobUOoAdJie > 0; uUemfyobUOoAdJie--) {
        continue;
    }

    for (int rVtARvslxUHGvGbB = 1514703601; rVtARvslxUHGvGbB > 0; rVtARvslxUHGvGbB--) {
        TGOvjSCjnONddopu += TGOvjSCjnONddopu;
        fKUwYOdgA -= TGOvjSCjnONddopu;
    }

    for (int LtZeMSu = 1905198573; LtZeMSu > 0; LtZeMSu--) {
        FVEDlE = itXpXRFBCqLW;
        sePymDl = ! sePymDl;
        XsgBAx = ! XsgBAx;
        SZHcEgKOvBLCJ = sePymDl;
        itXpXRFBCqLW = FVEDlE;
    }
}

double rWQxsnvfGdj::tBJXLRXJR(double dpjmiQxUxllmO, string vtXFxvgEKitLv, bool BpmykZEwclUep, int KBRZEu)
{
    bool ztSIBFM = true;
    int mFCXSfZY = -369323372;
    double wlynTbvOu = 1012474.9378146711;
    int hCTejFfmSIi = 345474942;

    for (int KmEDKLewWmcJz = 1724078413; KmEDKLewWmcJz > 0; KmEDKLewWmcJz--) {
        ztSIBFM = BpmykZEwclUep;
        BpmykZEwclUep = ! ztSIBFM;
    }

    for (int NnKeEIeBNG = 1867734694; NnKeEIeBNG > 0; NnKeEIeBNG--) {
        dpjmiQxUxllmO *= dpjmiQxUxllmO;
        wlynTbvOu = wlynTbvOu;
    }

    if (BpmykZEwclUep != true) {
        for (int kUgkvcVGUGevh = 1228643463; kUgkvcVGUGevh > 0; kUgkvcVGUGevh--) {
            ztSIBFM = ! BpmykZEwclUep;
            hCTejFfmSIi *= KBRZEu;
        }
    }

    for (int KfKIA = 469451401; KfKIA > 0; KfKIA--) {
        continue;
    }

    for (int yuaYlJJwJoKIGx = 702745845; yuaYlJJwJoKIGx > 0; yuaYlJJwJoKIGx--) {
        mFCXSfZY /= hCTejFfmSIi;
    }

    return wlynTbvOu;
}

int rWQxsnvfGdj::zqXEp(string TdCJYDALF, bool UMVumrq, string favWOCumUIIxsfOa)
{
    bool GmNjHByRVh = false;
    bool JsQzlHETpxySrTZz = true;
    int jcXbqfkU = 1308089640;
    double zhFilcAnYakkZ = 838361.4949835748;
    int IAetDFtVumxvZ = -614075689;

    if (JsQzlHETpxySrTZz != false) {
        for (int HLirFmGeg = 193586798; HLirFmGeg > 0; HLirFmGeg--) {
            GmNjHByRVh = ! JsQzlHETpxySrTZz;
        }
    }

    if (JsQzlHETpxySrTZz != true) {
        for (int GydDJMXBeWGTpg = 1405592968; GydDJMXBeWGTpg > 0; GydDJMXBeWGTpg--) {
            GmNjHByRVh = GmNjHByRVh;
            UMVumrq = GmNjHByRVh;
        }
    }

    if (IAetDFtVumxvZ == 1308089640) {
        for (int nWFaDED = 598533897; nWFaDED > 0; nWFaDED--) {
            continue;
        }
    }

    for (int jizIN = 1084153096; jizIN > 0; jizIN--) {
        GmNjHByRVh = GmNjHByRVh;
        zhFilcAnYakkZ = zhFilcAnYakkZ;
    }

    if (GmNjHByRVh == false) {
        for (int CwmXTsPYHFvbsrP = 1903996663; CwmXTsPYHFvbsrP > 0; CwmXTsPYHFvbsrP--) {
            IAetDFtVumxvZ /= IAetDFtVumxvZ;
        }
    }

    return IAetDFtVumxvZ;
}

string rWQxsnvfGdj::KsQvhvxrOXeK(string FrNQwArrcmWxBa, int rJKFSVLti)
{
    int LPURdNiYsODAsm = -173707655;
    int lJSHVrlvC = -1537660236;
    string EuCKgEaMGeWbU = string("R");
    bool TUTZe = true;
    int nmzAXorzjZ = 158722364;

    for (int rvvySlQWy = 572727006; rvvySlQWy > 0; rvvySlQWy--) {
        lJSHVrlvC *= lJSHVrlvC;
        lJSHVrlvC += rJKFSVLti;
    }

    for (int tvgJRbQ = 1615785663; tvgJRbQ > 0; tvgJRbQ--) {
        lJSHVrlvC /= nmzAXorzjZ;
        rJKFSVLti = LPURdNiYsODAsm;
        TUTZe = TUTZe;
        rJKFSVLti = LPURdNiYsODAsm;
    }

    if (rJKFSVLti >= 158722364) {
        for (int aUUsEpLQEBzic = 1952114456; aUUsEpLQEBzic > 0; aUUsEpLQEBzic--) {
            FrNQwArrcmWxBa = EuCKgEaMGeWbU;
            rJKFSVLti *= lJSHVrlvC;
            nmzAXorzjZ += rJKFSVLti;
        }
    }

    return EuCKgEaMGeWbU;
}

string rWQxsnvfGdj::zXZqRGm(bool kSyzBktZWhljo, string IFzPa, int RHvitfJGy, string xVtLARtONSpx)
{
    bool KjyzbMop = false;
    int VbPObCqw = -456256740;
    string KbwhRQt = string("UmCTXGdWbaPowHZZCZtNJmbfwHvJOHGFzvQFAzBfwhlQyaxfwAOwIgGLBUhSXtKCpSXPuIPtSprXOtiWUgJhrCCAuJqGEcmrqwMTWHonxDZohKqxTMOeetIbpyfxfSIMqeScwqHWtTmrKyIiqGkJunfCwYElbmmydjjiTyLfCnkWXpjpgZlIUdvcsjzzSHlHlueiIGbpFgXyeXjkLKpTRMENqOyifliQMDTsyFlGpDZybSELMEm");
    int nfpsSaJBgeVuE = 368523281;
    int cijcsdzhgkd = -2070812390;
    bool ATefnApSboUk = false;

    if (ATefnApSboUk == false) {
        for (int igLyQT = 1926040651; igLyQT > 0; igLyQT--) {
            VbPObCqw /= nfpsSaJBgeVuE;
        }
    }

    if (xVtLARtONSpx < string("UmCTXGdWbaPowHZZCZtNJmbfwHvJOHGFzvQFAzBfwhlQyaxfwAOwIgGLBUhSXtKCpSXPuIPtSprXOtiWUgJhrCCAuJqGEcmrqwMTWHonxDZohKqxTMOeetIbpyfxfSIMqeScwqHWtTmrKyIiqGkJunfCwYElbmmydjjiTyLfCnkWXpjpgZlIUdvcsjzzSHlHlueiIGbpFgXyeXjkLKpTRMENqOyifliQMDTsyFlGpDZybSELMEm")) {
        for (int vKEqCPpjCgO = 2093904359; vKEqCPpjCgO > 0; vKEqCPpjCgO--) {
            kSyzBktZWhljo = ! KjyzbMop;
            VbPObCqw /= cijcsdzhgkd;
            xVtLARtONSpx += xVtLARtONSpx;
        }
    }

    for (int LqKerPMxaPnhgad = 836673000; LqKerPMxaPnhgad > 0; LqKerPMxaPnhgad--) {
        RHvitfJGy /= VbPObCqw;
        KbwhRQt += KbwhRQt;
        nfpsSaJBgeVuE = nfpsSaJBgeVuE;
    }

    return KbwhRQt;
}

int rWQxsnvfGdj::KNUExwhzDYzJcX()
{
    bool WlcGKVdTLyjyG = true;
    string HOCHS = string("oOAZFtdKpRWiqewTdJqbAiMYDKjsmcZNQoSqTdwdNDhqoGliJqpqKmcqOeMYNwKvipgoeuMHDPxEHvvgAPAXKNsWIIskXuyQOWIxiBkvIsUcnrIRRlmYjPrAqnwGfLdfsVjkeNWkImfxcRSpiPnuYrNHuXjifikvALarcbDNuAC");
    double CSGsjITvXy = -776536.9237715374;
    string WEDPJpOQmsSEVMz = string("fPlkhkVjRVnKyVJJyFXWWTpNhOYEIADDCWHxwRgIXrXuFRsCFxYouNWhPMdSgjDsFbLtNjYeEsTnFoDAhHMNCNarwzncYiRIyzQECUaLrkosNuiBeODMHPESamGrHlALlUNTcvugELmQQLpWSBoQDjHzxSUyoBPzkaTgiXpbqwgssNFMotAYsVMU");
    double OhYWNzJxfEi = -550786.2860687012;
    string bqVmq = string("xdAqYoHHrVACItOpGZMrGGAMwZTAtQGgHwMDVmIjfEZESoCouwYcNgAFEcEOhKECQPDzkzSKtUaapdDlnnbXOxmoIGeDNrxGMgFRwVcekJJCXYjwsRLlegazSBGepYmBeJVjJoIfshVpnaXWCHtXYWNBCVGkOWjaTCHbPLMpewFT");
    int jPKjUXBXm = 1696154256;

    for (int MhNjYQGd = 51781382; MhNjYQGd > 0; MhNjYQGd--) {
        OhYWNzJxfEi = CSGsjITvXy;
        WEDPJpOQmsSEVMz = WEDPJpOQmsSEVMz;
    }

    if (jPKjUXBXm >= 1696154256) {
        for (int GpiCbFZ = 1880758657; GpiCbFZ > 0; GpiCbFZ--) {
            continue;
        }
    }

    for (int NKeCINtES = 1745497865; NKeCINtES > 0; NKeCINtES--) {
        bqVmq += bqVmq;
        WlcGKVdTLyjyG = WlcGKVdTLyjyG;
        HOCHS = WEDPJpOQmsSEVMz;
        CSGsjITvXy = OhYWNzJxfEi;
        bqVmq = bqVmq;
    }

    return jPKjUXBXm;
}

string rWQxsnvfGdj::GwdKrMh(bool uPAFLmNCE)
{
    string PnaOX = string("hfCyVuBDcfXhYZqxeplXSZkAFxAOKAoNCTTIbIlWOQq");

    return PnaOX;
}

double rWQxsnvfGdj::TXeLxoPA(double ycgepoQTZeNT, int OMYdJMxepKWahj, int WuRUdcRXR, bool xQnAccmHjoUifpld, bool MblZYLi)
{
    int SYGnFcNXciD = 1231148027;

    if (xQnAccmHjoUifpld != true) {
        for (int nzKtHIHu = 170589329; nzKtHIHu > 0; nzKtHIHu--) {
            ycgepoQTZeNT += ycgepoQTZeNT;
            WuRUdcRXR = SYGnFcNXciD;
            SYGnFcNXciD += SYGnFcNXciD;
        }
    }

    for (int OnBwpfiwALkKOJy = 573837869; OnBwpfiwALkKOJy > 0; OnBwpfiwALkKOJy--) {
        SYGnFcNXciD /= SYGnFcNXciD;
        SYGnFcNXciD = WuRUdcRXR;
    }

    for (int wvYtbWdyTx = 493755660; wvYtbWdyTx > 0; wvYtbWdyTx--) {
        SYGnFcNXciD *= SYGnFcNXciD;
        WuRUdcRXR = OMYdJMxepKWahj;
        xQnAccmHjoUifpld = MblZYLi;
        WuRUdcRXR -= OMYdJMxepKWahj;
    }

    return ycgepoQTZeNT;
}

double rWQxsnvfGdj::dQwLqmFBSWZEgYK(bool pQUkVaGdiUweR, double rSNlNQdpX, int DUpYe, int ndozakXQYJUxiz, bool Idovlh)
{
    string zWpjWkdmTlml = string("zrJBXnWOSFXfYnKLnbSiLbcRJaZbcqZnkxUjZwmLvXdKGzGEPfEtqijsugUIOrXqmzZFIQGrJtrDVRiDVSjHdSsTwhbNKQUkdmLOjQGZEuZWxFapelACnhlZmQMIQFkiajniygEGKNKfnuFwnXzlJiSutLDOvugCGRNsOcdXVdTHiMuFBlSnUvtAtIylhkLnhmfWuYBDVQyuuGo");
    string aByzUfSN = string("wAWMIQpiwXkQQxWOHwCFgIeGxCdKSojKhIqHzzBgwtbSqhenBqoYUWFvcVxmHCeK");
    bool NqFbiwsxXcCmLjXo = true;
    string nxXkFzer = string("CtOKHAkSZpIlSOxABUuTdUAMHFDRBdnCBoTeZgYEDCaDDGUsrBRnTrrdNmqXSrwZvRvBkcycCDBqyWlOtSbRGdmEDZagWrfzYEEkJCzpZXljAeQToIPvVSxEgVjrMTkPiMMlOaNytBnwgRIlUbiUCQTXbHgKaR");
    bool zRaAfMyYo = true;

    for (int TCQiKFSD = 1821720100; TCQiKFSD > 0; TCQiKFSD--) {
        DUpYe /= ndozakXQYJUxiz;
    }

    if (rSNlNQdpX <= -248771.56790521397) {
        for (int UdfknlYKGPodqNHg = 231496134; UdfknlYKGPodqNHg > 0; UdfknlYKGPodqNHg--) {
            pQUkVaGdiUweR = ! NqFbiwsxXcCmLjXo;
        }
    }

    for (int EmMUcwEcYq = 1102392213; EmMUcwEcYq > 0; EmMUcwEcYq--) {
        continue;
    }

    for (int YYhYkZbThOHQRwD = 929807768; YYhYkZbThOHQRwD > 0; YYhYkZbThOHQRwD--) {
        nxXkFzer = aByzUfSN;
        ndozakXQYJUxiz += DUpYe;
        aByzUfSN = aByzUfSN;
        zRaAfMyYo = ! Idovlh;
    }

    return rSNlNQdpX;
}

bool rWQxsnvfGdj::USTWhJZUWypvMxeo(string esMXjqq, int rLycEe, double TXdvrjWaKi, int PhpDHwuVBe, int dsexQzJknMXNcaUB)
{
    string TDfgymcz = string("TFdkqMAdxytgfetcQkhItJKsDrhchoZhBreepkVlxDeuIFQLZAyMBRhsNlZxXBXTlTyHtsAtSrMbYNNuwhkCPcqeQoqMsoGYgszGQMokmgHxWfKAmdYVowXTjZAvobEVBFisEmIjvVBmtyhWtHjGfF");
    bool ZcHOTUuBgaoi = false;
    int QbQrpZlGssRzfDOF = 657819148;
    bool sUOanVRjYDBDxR = false;

    return sUOanVRjYDBDxR;
}

int rWQxsnvfGdj::tZGmXLGQb(bool OmhVxXKhnRVUH, double MXAjtsMxr, bool zuBfYBmHkne)
{
    int WfboEQlzYStXVjA = 1769661740;
    int BpdaAY = 316697764;
    bool jKYrjxsVcPJXP = true;
    double mxGog = -866188.7745833603;
    double MGGWTaslWlmfyRj = -778719.4178732911;
    string IfUjhuyJ = string("PNLYFXvXJcYZOMbwlmLMmoLwZEWdqsFskHihYnuLPqfBwjTkLEORCXybegqCfdqBdgidVXaPYcrzwAnIlmzZgKGCMqhyDXhtKcuWropzEySSLUefvt");
    string fvosMFiF = string("nysfdiZzGloEYuWxqQBFQuCslDYcxChWknZrZJkDebMfuEZflGWstfPpIMImjpHIsIgEcPCcxwwLYPgvEPePDElasJFThRkGcatTwXJMYpxpeDksxIGzZhBNhKyOPdHFxtdYBeZLqdJStpghHdmzrOXBXfsqRLntUkWuxTGPiyVwAMwUGebXYvcewNqmNsluDeoeKRpsCWGqykemalolzjmVfWKxasGWLBpebxeTtI");
    int TjfylqqxOpsJVZFc = 231118340;

    for (int gACwrJjsKknKFMux = 1523781266; gACwrJjsKknKFMux > 0; gACwrJjsKknKFMux--) {
        fvosMFiF += fvosMFiF;
        TjfylqqxOpsJVZFc -= WfboEQlzYStXVjA;
    }

    for (int OjgdBQQYtIiob = 1426026269; OjgdBQQYtIiob > 0; OjgdBQQYtIiob--) {
        continue;
    }

    for (int rvNXpqngYrnXoy = 1136757660; rvNXpqngYrnXoy > 0; rvNXpqngYrnXoy--) {
        mxGog = MGGWTaslWlmfyRj;
        MGGWTaslWlmfyRj *= MXAjtsMxr;
    }

    return TjfylqqxOpsJVZFc;
}

string rWQxsnvfGdj::XDUjxXuoUZmxn(string ToInsDrSwqw, double dfkgFFLRzQucWAn, double kKVAgnlRBHzzY, double AnwdeIVtvYJFT, string vSMkMhRhiFtZQV)
{
    string cGJYVP = string("hjbJWvDotreHdsclNVegIpgoAyhTBhZjmZIymPynTfYxnMJbLubeZrGYFfxatznJumHaMWTIwvBzyEFAOaxZmLDfWSMcEFRuSNTnWVSNUttpATQqTXxuMLBRdaZTWxqTCABdVaInYDOocCTERLHaGnZyhMrxkkownaOtzUfMeKAfgoNHFGLkAEa");
    double HlGwe = -550943.1607259383;
    double FBEnbX = 502073.93127253;
    bool WzFMCMabR = false;
    bool NUxBDb = true;
    double zzmJFiyPpxNbWcH = 373216.0633909826;
    string dyDyutyZ = string("QKuC");

    if (kKVAgnlRBHzzY <= -147050.3435584172) {
        for (int wBrDCXPtRR = 1013099653; wBrDCXPtRR > 0; wBrDCXPtRR--) {
            ToInsDrSwqw = dyDyutyZ;
            AnwdeIVtvYJFT /= HlGwe;
        }
    }

    if (WzFMCMabR == true) {
        for (int snQjsKoZ = 2048095557; snQjsKoZ > 0; snQjsKoZ--) {
            HlGwe *= FBEnbX;
            HlGwe = FBEnbX;
        }
    }

    return dyDyutyZ;
}

rWQxsnvfGdj::rWQxsnvfGdj()
{
    this->CdMarXQDf(true, -5375290, 416335.75260804745);
    this->tBJXLRXJR(823099.3807518674, string("YmhddyRZHygROWJcdoTLvWihQBWYJTQYRftjpqLkXOxfBAbbQyeRVcNjNtTPpSYagvqymjFXghNJJRsfzfGwJaWBLBTJuGgbACNFKihMdXpwlubiWxWbpBbGUwjziMxpfJykXjGLDnAUYenrfhHCNZNuHLAjhcXJYgqPTmmwVQnLtklHtEOsYdSDgqtTnGLOTRnCJiPBeEZuqpbOzJSjJuTpEZnQCxWuDvjdc"), false, 983210014);
    this->zqXEp(string("QZQCfkrfKkqLcbepfhLuavDEvgURQmtBomDhTxOFUULNfWdJBUhJaVsvsUERjpmUnTtJtZimuERYhFqJwndGmOWPO"), true, string("aljNCpAhKxSMkLFvEBAHUQCremUFDTGNDuKBdZEapSgEMbevGKtNqitySzblEDJybfbQDzwFMJHazxqlBRPRVuJYrajkPjlAqysyeEQRPTsaECBUKQeQhGjfKtULSZtIpdnpWRjtKuPihpTtrFLcedbvSRMgoaJEEqOKI"));
    this->KsQvhvxrOXeK(string("JnnUoMDTjUpKiIOhjbkLTTMSKKtlVGVjZnbCPytrndgecRaUSPUOPyeaDgrYEZtbJmWWMeBAHoyHgQZUlkoCzaRILIYMKsFbaVssyTAOKbTcPFJhavqIMSlRPLOppsjbOicRBqWdvjcueQzGHStCSyjelSVUZyEOGDVviiwyEQllTvEtxyJomAcIysRLOwlbJSREmfWfwSANfx"), 866680001);
    this->zXZqRGm(true, string("gQvGgsUxcGjycaxoqRqSFyCDzQEVYHDPIbUUCdibOnvwNOHAxDYHksuWpnRxzbtwxfaAwLPSeSNVtkrtZKbLvteTNxKdIMXIpLWQeRMelFSmErxYISunZbGsSAxknmrHguYGVTMLiqcojXNKmspGZyyUBzETcLIXuqAFbFihnwDWSdljuFYMMPPStwzYSqQkHbAjEvFKFnTtBpxpyzMtLtNcQIdENPAreKINBW"), -206025877, string("gVfAknXSulISDvieXtEAFatLtiZEmojnWKAPRdKWaKTKyixIAZARPPbMokDTXyYEnXPdKNRpPyJMownRlyZycqdsowxNvIvxZbTkjuZFDfuXzCbXBoykvThCOasIZyclyByJgyAEhZyFNMbAKUHRdpkOi"));
    this->KNUExwhzDYzJcX();
    this->GwdKrMh(false);
    this->TXeLxoPA(-31988.76544136305, 1304406873, -68773922, true, false);
    this->dQwLqmFBSWZEgYK(true, -248771.56790521397, -1874643957, -1547900712, false);
    this->USTWhJZUWypvMxeo(string("IsMYprSfmnljyqPsBHtQCacBCCpiDcyfCCOpAhjioXpnvqyxzPfVznKALBhkwYTPEMwPuiC"), -573528630, 207718.3865053574, -1294692516, -568600480);
    this->tZGmXLGQb(false, -959764.6500146656, false);
    this->XDUjxXuoUZmxn(string("KTSQzuvZLJvfpdqENjWJAfDFVhthJmQHtlsKYMtjOSMDYWqedCgaPDmodycYYpkWEoRAAKxbUbITDmGKnnkbSmIkyjFNDhslSeHslphHnxGchPMjSVBqTxNCWuLUgKIBEAoTvhtCIhmjqmmLOZgBMnEcyXGVmEUZJEqToFEtFstJhkhXXbvTeKSVgXTjJgFUNftJOtXXYdSuSxmnAfScGWvDGevHZvNGEnEaRlsPmrSmFJcKQtgAaXKEoBY"), -147050.3435584172, 484279.6394876532, 1029664.1865258695, string("eoKLpvNjULHlijwqBxnSiHrKFNqlubrzdPaYwoAjUixoZfrGNUxvlkVCnOCXokasawEGGovwsiUgBWYvOPjIrIldsgbNEHcVtfBwXUbSXfTtSQGsUFYRoKLdxDavuW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pQNxSTTeXd
{
public:
    int hgNfyZ;
    int FdVQFYHHOecBGvmY;

    pQNxSTTeXd();
    int KilSjQKrWcaE(string sverv);
    int zOklAL();
    void zurbpU(bool qAScWHvRJr, int LqvyqsUqh, double blXNLvVhRMKigdXe);
    bool qnYGTfndBIhqcnlj();
    bool YDGBlcEVFHd(double zxtPkKZcMZYo, string MzHaINKXVwOAbv, int kXrTnGssmaKZE, int zXwUJrJKnLfFolF);
protected:
    int ssHRrZjv;
    int kVcqjPFxW;
    int HznfbhjmWYIywFXV;

    bool tsIInQywqII(bool mFWlUYKB, int PJswa, int BxceVYIjRq);
    int VCdpHdV(string sJCPPJcTpGUvmaFd, bool jIFlTjvblI, string vHmlxL, bool YCNymN);
    string HPuvtwHQsWJC();
private:
    bool EhgZSGRMyVSj;
    double FbQIjxhgzggfJ;
    double VznbgxvCEUtV;
    string AQSWoaWO;
    int RvoOJnSbnDxGG;

};

int pQNxSTTeXd::KilSjQKrWcaE(string sverv)
{
    string JVmTUyDy = string("maYJsSbKFlBXqVAoeMQLvxuRGSKxcRIeyuSDLrgGIKvDOJKtuZkCnyKqNKdCGCesPsnJZFMfFhbCcUdvaAXIsxMUiImgJUDRMSYFqLtmyCHROafvBoHvebLEjTbkaqFUGjuqOHCTeBcJMcGkgJBxvhZBhrUVSXifLdZEDaZRhGwAkiSSWAOnCyRayGOYiIwvoTTAxejEkyeBRevzBirFKPtQDcpHhZvBwgbuIIcOtxSgcSlPpMa");
    double HFclNpWDd = 94667.60109650424;
    int fUdmJfjJCpWOXX = 386066222;
    double hkQTcNJVCRCGS = -420323.30045855825;
    bool kGaSHZBwIsoFu = true;
    int Lxkgkl = -1279313925;
    bool hUvjwUAkMHe = true;
    string SqpEZDcacZKkJwo = string("UJrOrHcmSvdWejtoocBEEkcYPvyFHXVSEVXpIlQXkFTCEmJdcbxEqaABLWdmswKGLkHNQFOTWvUvtVppNLiGCyenrYwGazToDgWpdvc");

    for (int CEdeMPYl = 784066181; CEdeMPYl > 0; CEdeMPYl--) {
        Lxkgkl = Lxkgkl;
    }

    if (sverv >= string("vkmNPJvolFBwddkLmnkhRIkENlVWTrCyMIgqkIqHJbFwFjVahLRKqBKmYQvRMEmTFFybhviuQoMshzrHWzHQDKAaXZRsAIURtXtVmYuzAMtUOoYgPxiUlyuJEnxzBZxYzXMfXVZyLekjtLVbzZadLFqykiOogMpyZfgtcdtmVpSVSppEBRFjdzZfWCwoYdGqIikccJHHrdScJIDLXTppXHnCivpevNOVZRcwfHAmtZysGLXGotfbxPIxHmsZ")) {
        for (int ikQIfmYlkmJn = 1972823298; ikQIfmYlkmJn > 0; ikQIfmYlkmJn--) {
            JVmTUyDy += JVmTUyDy;
            hUvjwUAkMHe = ! kGaSHZBwIsoFu;
            hkQTcNJVCRCGS *= HFclNpWDd;
            HFclNpWDd = HFclNpWDd;
            JVmTUyDy = JVmTUyDy;
        }
    }

    for (int JAMZYsUQe = 534216452; JAMZYsUQe > 0; JAMZYsUQe--) {
        sverv = SqpEZDcacZKkJwo;
    }

    return Lxkgkl;
}

int pQNxSTTeXd::zOklAL()
{
    int TPmqShyzonfXOmW = 1328157250;
    int RAbZOToVk = 1898608907;

    if (RAbZOToVk <= 1328157250) {
        for (int IeNNr = 989616895; IeNNr > 0; IeNNr--) {
            RAbZOToVk -= RAbZOToVk;
            TPmqShyzonfXOmW /= TPmqShyzonfXOmW;
            TPmqShyzonfXOmW += RAbZOToVk;
            RAbZOToVk /= RAbZOToVk;
            RAbZOToVk += RAbZOToVk;
            RAbZOToVk -= RAbZOToVk;
            RAbZOToVk *= RAbZOToVk;
            TPmqShyzonfXOmW *= RAbZOToVk;
            TPmqShyzonfXOmW += RAbZOToVk;
            TPmqShyzonfXOmW -= TPmqShyzonfXOmW;
        }
    }

    if (RAbZOToVk < 1898608907) {
        for (int NjRLxIoL = 156720486; NjRLxIoL > 0; NjRLxIoL--) {
            TPmqShyzonfXOmW /= RAbZOToVk;
        }
    }

    if (TPmqShyzonfXOmW == 1328157250) {
        for (int zDguUt = 1553707563; zDguUt > 0; zDguUt--) {
            TPmqShyzonfXOmW *= RAbZOToVk;
            RAbZOToVk *= RAbZOToVk;
            TPmqShyzonfXOmW += TPmqShyzonfXOmW;
            TPmqShyzonfXOmW *= RAbZOToVk;
        }
    }

    if (TPmqShyzonfXOmW > 1328157250) {
        for (int XeWNBjWLRotjVxa = 173479467; XeWNBjWLRotjVxa > 0; XeWNBjWLRotjVxa--) {
            TPmqShyzonfXOmW -= TPmqShyzonfXOmW;
            TPmqShyzonfXOmW += TPmqShyzonfXOmW;
            TPmqShyzonfXOmW -= RAbZOToVk;
            RAbZOToVk += RAbZOToVk;
            TPmqShyzonfXOmW -= TPmqShyzonfXOmW;
            RAbZOToVk += RAbZOToVk;
            TPmqShyzonfXOmW *= TPmqShyzonfXOmW;
            TPmqShyzonfXOmW -= TPmqShyzonfXOmW;
        }
    }

    if (RAbZOToVk == 1898608907) {
        for (int lPRnEDCeJEbDyi = 2025512367; lPRnEDCeJEbDyi > 0; lPRnEDCeJEbDyi--) {
            RAbZOToVk = TPmqShyzonfXOmW;
            RAbZOToVk -= RAbZOToVk;
            TPmqShyzonfXOmW += TPmqShyzonfXOmW;
        }
    }

    return RAbZOToVk;
}

void pQNxSTTeXd::zurbpU(bool qAScWHvRJr, int LqvyqsUqh, double blXNLvVhRMKigdXe)
{
    string NkQSLpEf = string("excqbEoylyWHUdiRRcPjgTUANogqbAnLEqrAyWihMZgqgNXBxVDcchMvvbFkTMXseZRHylKPLQCeVLnaPrKeaoxsUexxKKMBlXqzrUEyguzhROVLlpzmmbGFSMpidhNmkkMvPGhHVFCUReqLfQiHHmaZOcDshCUlRBROoJkicyvszjjHjAymquQVBlQaAzlArWpYIgQdMmTFxHIchmFkCMRswceYnV");
    double HHbVaswn = 834920.8081032698;
    string IfJVRDp = string("OTIajNwlRnYkZPSeNKDhMNrWeYaPewsBCeHYKJMSeTqBANnHKzKnsXjzbfYPLHLjCphlTwLshDkSuHZVlKkkfGQxFXPaCSNjchhtYcAblvLjEvfeJqjEIlwbNxsULEJXHbJPafTywdPkHQmYIzFlUVmhdQUkcklPbpYFNfCSutKBvoCkuvynTvxeHEmKxFEAxFRyjMxybawdoUAqkhxtdVMixXWUJgeTBirJvSgyczTkvpbv");
    double oNiWKOgrynkmo = -1011417.4069561508;
    int WmtdxajlouOcOt = 1877606515;
    string dprcHDBRfYRax = string("KcVnSuUtcaNpOvgtJXPrJhGTxRhGUPtpZcWaTtuaPWmiveFzFEgMoBDmEkHqHpBwzMQbYUTvzWGhXoGRShwuoRADwCbfIcCDISImYFwTJSosbftRezSIRIfMBfEAXWyvjVJtLJvTiyRQNYxmBHFvbxBDIXilVBQsmIJjaNFVyuurOoGvleZSRwbLrIQFUkVTHysWjNmTtBvzyvprygLvTzyrDccJzXduaWnypDJsarcOtX");
    string pKLOYGc = string("GHkltiWbaxlTtNRstmlzUhgeAxUGhVycfiYNvYgwtgNFEddtDDBURrEDiUQYlXYAHitibnaedIoGYalSSMARnjydkFsGLYPLdylGJYDRKVBVR");
    bool EdKkWsIPqTqMHNt = true;

    for (int YnVftQjMs = 861247339; YnVftQjMs > 0; YnVftQjMs--) {
        oNiWKOgrynkmo = oNiWKOgrynkmo;
    }

    for (int oZjpWuZbazwFUQ = 200843273; oZjpWuZbazwFUQ > 0; oZjpWuZbazwFUQ--) {
        continue;
    }

    for (int xFMiLMIrVNNuEf = 2052739463; xFMiLMIrVNNuEf > 0; xFMiLMIrVNNuEf--) {
        continue;
    }
}

bool pQNxSTTeXd::qnYGTfndBIhqcnlj()
{
    double TsrjYHHecKT = 258606.65317570616;
    bool JPzhUSoKZoEkpGu = false;
    string dISCZtHG = string("ucWAPzTuYMSgGDFpsyQBobhdcgvnlBiaueZTpPJiCBWMRSWpjQrcqdkjmzVanZXkXKRKfKnolvWjQnOkvicnAtmxhknQBwbMUatleSjQEgqMWyVsafUzvoDltVuXvEUQHmkKVwanSqXyvZHzQqFkOLFdNCcZStjZMlOUVUerLmZbXTWKdhiTRPqwsBoZEUFgohiUhrsFUNvkVMjmtjYGcyUhDdzAJ");
    bool KpRFHvfKWXD = true;
    int pkPncLxBFslIEw = 3176176;

    return KpRFHvfKWXD;
}

bool pQNxSTTeXd::YDGBlcEVFHd(double zxtPkKZcMZYo, string MzHaINKXVwOAbv, int kXrTnGssmaKZE, int zXwUJrJKnLfFolF)
{
    int XhavMItc = 877331118;
    double bPIwK = -833692.7248359012;
    string uOZoqIZzJIDei = string("LZRXFoYWyqCibYEUQxTKdQozcuOwzGshuaEGKjqpBaERXcRcJeqdlMrlUmgXCpMLCvpReaDXvOKZtLAqEOyxBLsdsvBgnJUmPFJHBGRuSAwsvYdafwInxTolfBbfpEuUkyzAjxpbTlXCriLZuAfxHxlmTWLpOHMAzrmMDiRi");
    int UHWTHwwCQDTE = 661283915;
    string oLZZX = string("gYghvfQFTRxmEhwyhPGvXLQOIuBNxwlaZdvvoGWWVOVcyUqBdLEnYCpefHlQuLPTVwbyIFVzwWKSxqDpiJsLAYMebqiZsSgNZhIHyHjwHEbdLdLOTsKChOgQZGoECnpNqsjVcwRhMiwCOrQceZevEXIWOlTpIrsFZiGfCfkolmOaNsLkKxIgGmnidCtcMTMGkPedTMLlJvfnBJh");

    for (int zkpiYGKzq = 1458668039; zkpiYGKzq > 0; zkpiYGKzq--) {
        zXwUJrJKnLfFolF -= kXrTnGssmaKZE;
        kXrTnGssmaKZE /= zXwUJrJKnLfFolF;
    }

    for (int GvAprx = 758849843; GvAprx > 0; GvAprx--) {
        UHWTHwwCQDTE *= UHWTHwwCQDTE;
    }

    return false;
}

bool pQNxSTTeXd::tsIInQywqII(bool mFWlUYKB, int PJswa, int BxceVYIjRq)
{
    int oKljRWXkuqSUbUD = -759128627;

    if (mFWlUYKB == true) {
        for (int MGpxBSMmaKyBbZEs = 712730354; MGpxBSMmaKyBbZEs > 0; MGpxBSMmaKyBbZEs--) {
            mFWlUYKB = mFWlUYKB;
            PJswa *= oKljRWXkuqSUbUD;
            PJswa -= oKljRWXkuqSUbUD;
            PJswa = oKljRWXkuqSUbUD;
            oKljRWXkuqSUbUD += BxceVYIjRq;
            oKljRWXkuqSUbUD *= BxceVYIjRq;
        }
    }

    if (oKljRWXkuqSUbUD < -791921957) {
        for (int DxJwOhmt = 1324342469; DxJwOhmt > 0; DxJwOhmt--) {
            oKljRWXkuqSUbUD += BxceVYIjRq;
            PJswa += BxceVYIjRq;
            mFWlUYKB = ! mFWlUYKB;
            BxceVYIjRq = BxceVYIjRq;
            oKljRWXkuqSUbUD /= PJswa;
            mFWlUYKB = ! mFWlUYKB;
        }
    }

    for (int YgYZmqZaSmDZU = 1413004276; YgYZmqZaSmDZU > 0; YgYZmqZaSmDZU--) {
        oKljRWXkuqSUbUD = BxceVYIjRq;
        oKljRWXkuqSUbUD -= PJswa;
    }

    if (PJswa == -759128627) {
        for (int EavGvdXbDhIFGUqe = 980616741; EavGvdXbDhIFGUqe > 0; EavGvdXbDhIFGUqe--) {
            oKljRWXkuqSUbUD = PJswa;
        }
    }

    if (oKljRWXkuqSUbUD > -728739097) {
        for (int dlczuGICoh = 32684974; dlczuGICoh > 0; dlczuGICoh--) {
            BxceVYIjRq = BxceVYIjRq;
            oKljRWXkuqSUbUD *= oKljRWXkuqSUbUD;
            oKljRWXkuqSUbUD -= PJswa;
            BxceVYIjRq += PJswa;
            BxceVYIjRq /= oKljRWXkuqSUbUD;
            oKljRWXkuqSUbUD = oKljRWXkuqSUbUD;
            BxceVYIjRq -= oKljRWXkuqSUbUD;
        }
    }

    if (BxceVYIjRq != -759128627) {
        for (int TvGITxoOYhihQArr = 103035041; TvGITxoOYhihQArr > 0; TvGITxoOYhihQArr--) {
            mFWlUYKB = ! mFWlUYKB;
            PJswa -= PJswa;
            oKljRWXkuqSUbUD = PJswa;
            oKljRWXkuqSUbUD *= oKljRWXkuqSUbUD;
            PJswa *= PJswa;
        }
    }

    for (int CIXhgaSouy = 1617880617; CIXhgaSouy > 0; CIXhgaSouy--) {
        oKljRWXkuqSUbUD -= BxceVYIjRq;
        oKljRWXkuqSUbUD += PJswa;
        BxceVYIjRq += BxceVYIjRq;
    }

    return mFWlUYKB;
}

int pQNxSTTeXd::VCdpHdV(string sJCPPJcTpGUvmaFd, bool jIFlTjvblI, string vHmlxL, bool YCNymN)
{
    bool Lojrlxgpr = true;
    int zKMfi = 245056927;
    string LmrFphkCUJvUnOf = string("uXbRfCYbojJSjxm");
    string HFMCrgLRiVhBOgb = string("EpdzerujViboZrARMuyYjDfsTbzFsLhGG");
    int YubxmcrG = 1888138388;
    double lQLDnecj = -98981.93898929573;
    int LJkfGGAxHX = 411565565;
    string lPKsYmMlYnBCvfGU = string("cGvOgSgaWBCOEKoBugmLbzZavjejucLVWpCMqqBDpaCEFqqnTeNVokcGpvXAwKzOKBGyeQpoCUadKztOjPjGRFeruTkXRrGTUshDfyWb");

    return LJkfGGAxHX;
}

string pQNxSTTeXd::HPuvtwHQsWJC()
{
    double LCtXFLfuscx = -498212.32336804713;
    int STdPOIjfqC = -776292478;
    bool RyUICECqxZvJ = false;
    double VCMGBmWmCisHNR = 980623.7338614396;

    for (int cSEakFPsWsx = 1933784007; cSEakFPsWsx > 0; cSEakFPsWsx--) {
        LCtXFLfuscx = LCtXFLfuscx;
        LCtXFLfuscx += LCtXFLfuscx;
        LCtXFLfuscx += LCtXFLfuscx;
        LCtXFLfuscx -= LCtXFLfuscx;
    }

    for (int oXVjqG = 1130152831; oXVjqG > 0; oXVjqG--) {
        LCtXFLfuscx -= LCtXFLfuscx;
        LCtXFLfuscx *= LCtXFLfuscx;
        VCMGBmWmCisHNR += VCMGBmWmCisHNR;
        VCMGBmWmCisHNR += LCtXFLfuscx;
        VCMGBmWmCisHNR /= LCtXFLfuscx;
    }

    for (int xXViug = 728280056; xXViug > 0; xXViug--) {
        VCMGBmWmCisHNR /= VCMGBmWmCisHNR;
        VCMGBmWmCisHNR /= LCtXFLfuscx;
        VCMGBmWmCisHNR /= VCMGBmWmCisHNR;
    }

    return string("aZAKbPIMkOsTilDhCICVuixtqnnvWiLrtnSHXpkRKQumggRMJHtNiPhBlKSMZaWWHQvYrxYGtlzrfdV");
}

pQNxSTTeXd::pQNxSTTeXd()
{
    this->KilSjQKrWcaE(string("vkmNPJvolFBwddkLmnkhRIkENlVWTrCyMIgqkIqHJbFwFjVahLRKqBKmYQvRMEmTFFybhviuQoMshzrHWzHQDKAaXZRsAIURtXtVmYuzAMtUOoYgPxiUlyuJEnxzBZxYzXMfXVZyLekjtLVbzZadLFqykiOogMpyZfgtcdtmVpSVSppEBRFjdzZfWCwoYdGqIikccJHHrdScJIDLXTppXHnCivpevNOVZRcwfHAmtZysGLXGotfbxPIxHmsZ"));
    this->zOklAL();
    this->zurbpU(true, -1313686464, 597783.1539310972);
    this->qnYGTfndBIhqcnlj();
    this->YDGBlcEVFHd(-292134.59487067506, string("fsMqTXLqbgcMnnhMlxmnRqGnDHLPHelnNgZgDeWkLaVWvrLvTqQNKiGuUFkGeCrzYioGXDkAzjBAVWmAgoTXZUjUwdPqsEqbzePzMkECSRgPOhLLRuHiEEGKniwPmxYIckvuEzKcTASVVYLpWIDEGLfCEjoOoKUtOMpNSTYNETyqzxgaxUBiOHUYKWPgHIUGUFNQJubVKZbokNDooUaEcFaeftElXIRBBQZvSyqwKutGwHwrVoCmxWsCiU"), -1027598018, 1519065445);
    this->tsIInQywqII(true, -728739097, -791921957);
    this->VCdpHdV(string("oFqCCOlmTBsxVHUPUQzcaFjNFBbOjBHVndedATOjtfQbfkHswIKmWgkXypZBNOYAZTNhISqrrFFvSXGIVFOccyaq"), false, string("RYPmsvdMxhlvjniBsenYYjOLMxCg"), true);
    this->HPuvtwHQsWJC();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class equRRsfxPOgCG
{
public:
    int fXRtsHAYzMqyLw;
    bool gncFdQe;
    int kxDvcuBUV;
    bool DTWmRw;

    equRRsfxPOgCG();
    string uHYGwsXiuAz(double syjhcUdsUDVvVJLn, int kAYXIGa, bool mRWRvuMseime);
    bool HAxhXDS();
    void ShUFwl(string BWMUPHuoSY, bool txonqNwPxalVy);
    bool UVJLNgI(double pYHqvY, string FUKryGH, int fehzQKMoFb, int ByUNoqTDXBGg, string UVgQkqfNiEdyoJpw);
    bool yXoULdQyQWmnax(double sysBHvpXJ);
    int IJQDKdwherZ(int cOLwHTOxjjLGzbG, double oAuYrDXUmiKZKGl, string mNygprcwx, double zPTCtWdWnaj, bool ruyJjtUXO);
    int ynPiogaLT();
    double EeIQQsW(string orXvZ, bool QeEbjNLkVYv, int BEhZeo, int JGYfWzMHJ);
protected:
    int ksGBRLrr;
    string RwSHGVNTq;
    int KIpXA;
    int uzEGzCXIExQcmBp;

    string UluGssXnIstY(string uJiaxqtQRuqk, bool yaQpbyZwTNHm, string KblHTFfIJg);
    string pSvBDU(string aCLhYIhgAfZnUufQ, bool qXsnyzWzXgm, double VXsjCT, bool sUIaWLXyZRqb, bool iObwp);
    void wXqmI(bool dKTdp);
    int xAmOgJkqqywu(int bFuXR, string GuJIJjBcjCDp, bool TvwOnkieUJVPue);
private:
    double tEbrrG;
    double VVPcjIDeFuaBad;
    double MuSjlSLst;
    string TKstHrRYcEYRHT;
    double zlNDt;
    double rsrYX;

    void GKJxerLorLZha(double bTuPp, string zPyTRDEbh, bool lTjBKYzOsn, int FfeXnpfiCJFRSs, bool kaMfueMeaVmdy);
    int qptsJIGrTB(double mlzbTKfsetRYIT, bool DWIzWGjXPCmT, int shvnnNsjAFGdKGnO, bool dTAtny, int xVEWiGeRkB);
    double nJjPKO();
    string xhCZo();
    double QCOgQPDPSNpgVoy(string jgdQEjU, int gVYKuNlzUNgYrr, int KowLZ, int TajfmqewiXakp);
    void kAllhNpQeuhBalL(string fuvOpfNuDADsD, bool eyHiVIO);
};

string equRRsfxPOgCG::uHYGwsXiuAz(double syjhcUdsUDVvVJLn, int kAYXIGa, bool mRWRvuMseime)
{
    double xVJWHCxulQzP = 56493.84060190803;
    int mpTRVkIrJTpxv = -1141695979;
    bool orIizvhbCwwEdYk = false;
    string AicYnjX = string("pZEyih");
    double fzbcd = -591651.2119366309;
    double vdWfkZ = 368171.6636013285;
    int ZRADM = 885904134;
    double RedRvz = 960344.8133988539;
    bool nhHSZZagSnem = true;

    for (int skDRMrTjyIEKk = 1412834296; skDRMrTjyIEKk > 0; skDRMrTjyIEKk--) {
        fzbcd = RedRvz;
    }

    for (int MiuIsHQpGtBfD = 1019851045; MiuIsHQpGtBfD > 0; MiuIsHQpGtBfD--) {
        mRWRvuMseime = mRWRvuMseime;
        mRWRvuMseime = ! nhHSZZagSnem;
    }

    return AicYnjX;
}

bool equRRsfxPOgCG::HAxhXDS()
{
    bool wPKiYqwjEnVwA = true;
    string Nhdpzny = string("ixBGcrxoCVThyZhfHrNzyJSOFwsUQkQQhBzuoLkOfWEKRtEsbsrnMNVvbwFSojEivZndgNUMBannMhcAiyJZBTPvPVOGZPHryQYCmtlgXhWObpaqTJxnhcom");
    string LsuBYYUJVACrG = string("eOXvciYpDHuizEROGYLAwPHxJSnqGioTZmdqPVlNsNYcOZeQnPwLGrlcxqTegoNxbAsfQTaV");

    if (wPKiYqwjEnVwA != true) {
        for (int ZtqRpNB = 922606580; ZtqRpNB > 0; ZtqRpNB--) {
            LsuBYYUJVACrG = Nhdpzny;
            LsuBYYUJVACrG = Nhdpzny;
            LsuBYYUJVACrG += Nhdpzny;
            LsuBYYUJVACrG = Nhdpzny;
            LsuBYYUJVACrG += Nhdpzny;
        }
    }

    if (Nhdpzny > string("eOXvciYpDHuizEROGYLAwPHxJSnqGioTZmdqPVlNsNYcOZeQnPwLGrlcxqTegoNxbAsfQTaV")) {
        for (int HCYXJv = 735119581; HCYXJv > 0; HCYXJv--) {
            Nhdpzny += Nhdpzny;
            LsuBYYUJVACrG = LsuBYYUJVACrG;
        }
    }

    if (LsuBYYUJVACrG > string("eOXvciYpDHuizEROGYLAwPHxJSnqGioTZmdqPVlNsNYcOZeQnPwLGrlcxqTegoNxbAsfQTaV")) {
        for (int zsHKfyzAMTXAhfa = 34977897; zsHKfyzAMTXAhfa > 0; zsHKfyzAMTXAhfa--) {
            wPKiYqwjEnVwA = wPKiYqwjEnVwA;
            LsuBYYUJVACrG += Nhdpzny;
            Nhdpzny += Nhdpzny;
            wPKiYqwjEnVwA = ! wPKiYqwjEnVwA;
            Nhdpzny += Nhdpzny;
        }
    }

    if (wPKiYqwjEnVwA != true) {
        for (int zJECPTwLouO = 1394076157; zJECPTwLouO > 0; zJECPTwLouO--) {
            LsuBYYUJVACrG += Nhdpzny;
            Nhdpzny = Nhdpzny;
            LsuBYYUJVACrG += LsuBYYUJVACrG;
            wPKiYqwjEnVwA = wPKiYqwjEnVwA;
            Nhdpzny += LsuBYYUJVACrG;
            LsuBYYUJVACrG = Nhdpzny;
        }
    }

    if (wPKiYqwjEnVwA != true) {
        for (int byBrttpc = 571468458; byBrttpc > 0; byBrttpc--) {
            wPKiYqwjEnVwA = ! wPKiYqwjEnVwA;
            LsuBYYUJVACrG += LsuBYYUJVACrG;
            Nhdpzny = LsuBYYUJVACrG;
        }
    }

    if (LsuBYYUJVACrG < string("ixBGcrxoCVThyZhfHrNzyJSOFwsUQkQQhBzuoLkOfWEKRtEsbsrnMNVvbwFSojEivZndgNUMBannMhcAiyJZBTPvPVOGZPHryQYCmtlgXhWObpaqTJxnhcom")) {
        for (int xusjZZVRiexYqPib = 1397443005; xusjZZVRiexYqPib > 0; xusjZZVRiexYqPib--) {
            wPKiYqwjEnVwA = ! wPKiYqwjEnVwA;
            LsuBYYUJVACrG += LsuBYYUJVACrG;
        }
    }

    for (int SWZLjP = 1321146995; SWZLjP > 0; SWZLjP--) {
        wPKiYqwjEnVwA = wPKiYqwjEnVwA;
        Nhdpzny = Nhdpzny;
        Nhdpzny = Nhdpzny;
    }

    return wPKiYqwjEnVwA;
}

void equRRsfxPOgCG::ShUFwl(string BWMUPHuoSY, bool txonqNwPxalVy)
{
    int OwMKIlsmCstLfz = -347874328;

    for (int liRTc = 69094760; liRTc > 0; liRTc--) {
        continue;
    }
}

bool equRRsfxPOgCG::UVJLNgI(double pYHqvY, string FUKryGH, int fehzQKMoFb, int ByUNoqTDXBGg, string UVgQkqfNiEdyoJpw)
{
    bool PpTJqaRXiR = false;
    string XgtlKNmTPd = string("DIzcMbojMZRMIeRVTLiZhJThOFZOoqXHerQMkEaNSBqxeSRlTJCXPuPCBJgAtaCTqVauwAsLKTVQJfZsqdNCXdOJdYSmzKOnEDlyYXjGbskUGOwWFPJmlRNoUZUXxRxJHfVbrbuNKmNrKcgHoypcaKtfbgxB");
    bool heygLxjLhLTIU = true;
    int mNZqtwFPU = -1050126283;
    bool jlHpjmdVHw = true;
    bool ggelxfuBnk = false;

    for (int PAWTg = 2049789449; PAWTg > 0; PAWTg--) {
        FUKryGH += FUKryGH;
    }

    for (int gmLRByrEJXDf = 1558134300; gmLRByrEJXDf > 0; gmLRByrEJXDf--) {
        jlHpjmdVHw = ! ggelxfuBnk;
        jlHpjmdVHw = ! heygLxjLhLTIU;
        FUKryGH += FUKryGH;
    }

    for (int AMpkoLAhYC = 1433614858; AMpkoLAhYC > 0; AMpkoLAhYC--) {
        heygLxjLhLTIU = ! heygLxjLhLTIU;
        ggelxfuBnk = ! heygLxjLhLTIU;
        heygLxjLhLTIU = ! ggelxfuBnk;
    }

    for (int BHKTUvbvy = 584606352; BHKTUvbvy > 0; BHKTUvbvy--) {
        mNZqtwFPU += mNZqtwFPU;
        heygLxjLhLTIU = ! PpTJqaRXiR;
        FUKryGH += XgtlKNmTPd;
        mNZqtwFPU *= fehzQKMoFb;
    }

    for (int JMTzPMAAyMKSq = 2114109527; JMTzPMAAyMKSq > 0; JMTzPMAAyMKSq--) {
        heygLxjLhLTIU = ! ggelxfuBnk;
    }

    for (int ajUtEythpvOQ = 1803065929; ajUtEythpvOQ > 0; ajUtEythpvOQ--) {
        fehzQKMoFb /= ByUNoqTDXBGg;
        ggelxfuBnk = jlHpjmdVHw;
    }

    return ggelxfuBnk;
}

bool equRRsfxPOgCG::yXoULdQyQWmnax(double sysBHvpXJ)
{
    int dwoOBOpztpye = 1336020721;
    int UGnns = 647931958;
    bool toamXkvHXeYPWc = false;
    string xbGpBfQMwMT = string("lGfanClpvjbadQLepdbmCiHRgXZViWbMQdMDaXKpUFmEoTkTWKthPtolcDgbEGftMDlmAPWilsridBshTpVfDAcJNzKkoUXDcNUlVQbKqqopJAkkOzVwFQhbDqbZEuLnBujELJsgvtElbwEhfaGYzXQFiXnvEEwMCQTeaGrIyCDdtTsOMzgkdtGLUfmczFGIlDOKGpAMHJovbxvWOVnqtsUuKoeTDk");
    int prIvxdAcfgfC = -1971158080;
    string TidriV = string("vsJgVXHXukHTSwiHwEYGdEdDTWfadleELwWIFMCVXCrnYcpEtZYbOPWJaIWKIwvWOczRSVWaLTQyJstChzTnRZGHgXftuICNAShlFMNlTyuTloOYYeafGUcYfWh");
    string dGhlid = string("bHdxisEbwcinJuNAzWuyNTwzpMBPSxDEHTdVxhdSRaECRtY");
    double YOkTvyzzb = -429516.80575778027;
    string UIPFbkj = string("ZyFbactyKiMQxtVHfLbLOHajjlpEhINwDfourxSfwThhnBjRxFnDLGeiqnSByoMnbCdfftgoSQFOaKfjEvpXwcKttARhVVZQesvRfwtVyLNNikFbloOXSCrHeUpOcwCSfauBHBVfbhRwJYppe");

    if (TidriV != string("bHdxisEbwcinJuNAzWuyNTwzpMBPSxDEHTdVxhdSRaECRtY")) {
        for (int vFzMwZAkOhQ = 104421983; vFzMwZAkOhQ > 0; vFzMwZAkOhQ--) {
            UIPFbkj = dGhlid;
            prIvxdAcfgfC = prIvxdAcfgfC;
        }
    }

    if (UIPFbkj != string("bHdxisEbwcinJuNAzWuyNTwzpMBPSxDEHTdVxhdSRaECRtY")) {
        for (int uVfae = 533556331; uVfae > 0; uVfae--) {
            xbGpBfQMwMT = xbGpBfQMwMT;
        }
    }

    for (int pzQBwHjtuBoOzft = 1083305840; pzQBwHjtuBoOzft > 0; pzQBwHjtuBoOzft--) {
        TidriV += dGhlid;
    }

    if (xbGpBfQMwMT >= string("lGfanClpvjbadQLepdbmCiHRgXZViWbMQdMDaXKpUFmEoTkTWKthPtolcDgbEGftMDlmAPWilsridBshTpVfDAcJNzKkoUXDcNUlVQbKqqopJAkkOzVwFQhbDqbZEuLnBujELJsgvtElbwEhfaGYzXQFiXnvEEwMCQTeaGrIyCDdtTsOMzgkdtGLUfmczFGIlDOKGpAMHJovbxvWOVnqtsUuKoeTDk")) {
        for (int WrtfMmuN = 163964906; WrtfMmuN > 0; WrtfMmuN--) {
            dGhlid += xbGpBfQMwMT;
            UIPFbkj += UIPFbkj;
            TidriV = xbGpBfQMwMT;
        }
    }

    return toamXkvHXeYPWc;
}

int equRRsfxPOgCG::IJQDKdwherZ(int cOLwHTOxjjLGzbG, double oAuYrDXUmiKZKGl, string mNygprcwx, double zPTCtWdWnaj, bool ruyJjtUXO)
{
    int RpLAqb = 2080761004;
    int PnktVrkfPXmalHl = -592443266;
    double MzQtzI = -336991.46167086874;
    string QnvvaoQ = string("ZzdMnXeOjgpMBBFVRxgpVWbCBLUEzqocgCEYatDhvll");
    double MECuPlMfWEqscSu = 631181.1768720147;
    int sVfcytJS = -1359330419;

    for (int snPAruWsxKACDa = 182720545; snPAruWsxKACDa > 0; snPAruWsxKACDa--) {
        oAuYrDXUmiKZKGl /= MzQtzI;
        cOLwHTOxjjLGzbG = PnktVrkfPXmalHl;
        cOLwHTOxjjLGzbG -= sVfcytJS;
    }

    for (int QuGyxcf = 1865368472; QuGyxcf > 0; QuGyxcf--) {
        continue;
    }

    for (int ekxOwOURbnbtLrEn = 1232959353; ekxOwOURbnbtLrEn > 0; ekxOwOURbnbtLrEn--) {
        RpLAqb += sVfcytJS;
        zPTCtWdWnaj += zPTCtWdWnaj;
        cOLwHTOxjjLGzbG = sVfcytJS;
    }

    for (int IcfynqbEIAxYY = 2673075; IcfynqbEIAxYY > 0; IcfynqbEIAxYY--) {
        mNygprcwx = QnvvaoQ;
        PnktVrkfPXmalHl += cOLwHTOxjjLGzbG;
    }

    return sVfcytJS;
}

int equRRsfxPOgCG::ynPiogaLT()
{
    bool PNmsulYqS = true;
    bool MvoaPvwH = false;
    double dVYoVztBM = 234246.87940849934;

    for (int hKgJkhPgPWPZ = 1924979932; hKgJkhPgPWPZ > 0; hKgJkhPgPWPZ--) {
        PNmsulYqS = ! MvoaPvwH;
        dVYoVztBM = dVYoVztBM;
        MvoaPvwH = PNmsulYqS;
        PNmsulYqS = ! PNmsulYqS;
    }

    for (int bWrWjhdYNH = 1444450589; bWrWjhdYNH > 0; bWrWjhdYNH--) {
        PNmsulYqS = PNmsulYqS;
        dVYoVztBM /= dVYoVztBM;
    }

    if (PNmsulYqS == true) {
        for (int gzHolqlSb = 1547699002; gzHolqlSb > 0; gzHolqlSb--) {
            MvoaPvwH = ! PNmsulYqS;
        }
    }

    for (int xhLRSragbvt = 503542232; xhLRSragbvt > 0; xhLRSragbvt--) {
        MvoaPvwH = PNmsulYqS;
        PNmsulYqS = ! MvoaPvwH;
    }

    if (dVYoVztBM != 234246.87940849934) {
        for (int TjBDgIzC = 1869279271; TjBDgIzC > 0; TjBDgIzC--) {
            MvoaPvwH = ! PNmsulYqS;
            PNmsulYqS = ! MvoaPvwH;
            MvoaPvwH = PNmsulYqS;
        }
    }

    for (int GocpJwWNCwfsSk = 1400039149; GocpJwWNCwfsSk > 0; GocpJwWNCwfsSk--) {
        MvoaPvwH = ! MvoaPvwH;
        dVYoVztBM -= dVYoVztBM;
    }

    return -1504842896;
}

double equRRsfxPOgCG::EeIQQsW(string orXvZ, bool QeEbjNLkVYv, int BEhZeo, int JGYfWzMHJ)
{
    double kgQEWNBGFudf = -199234.61976613614;
    bool jIlnfEWQux = false;

    for (int zteHOJ = 307992056; zteHOJ > 0; zteHOJ--) {
        continue;
    }

    return kgQEWNBGFudf;
}

string equRRsfxPOgCG::UluGssXnIstY(string uJiaxqtQRuqk, bool yaQpbyZwTNHm, string KblHTFfIJg)
{
    int uvJmTwnFKC = -77551246;
    string HOwEoHmvZW = string("QxiOkthcvIYIurYvekSEXsxaoXcfXtKLlZPZtJeBUxDTxevQreVbZNrZjfnedoXabHhTgWFtXjjriLhjKURZWUOmcmEvibOcbDbubUGYsCkbwRDJBAdlLDdZqFtVglCJhRGcOsEMngxuGNClDGEblrEFvSaYashWvwMecYCDGsqyiSkSIhFYCkyacMffFtnlGjgvweVcekyvVEzjImPHdHTkCcWsfNCl");
    bool isBDIK = true;
    bool GdjMfsZpoXgUF = false;
    bool qOYpt = false;
    string VROUdaxhdjHXdyDx = string("vWtaQzuNheKHRooIWgIFnsJPNZfQEpOMxEwwaCOuawiOaiUiNvEZwFUEGqYIkdPtUWSsqmx");
    bool oNkYgygdTWWG = true;
    int BOiigXWWjVe = 1906512360;
    double AtfvIRJwnM = -687381.2633104326;

    for (int gKBlx = 1826604565; gKBlx > 0; gKBlx--) {
        GdjMfsZpoXgUF = oNkYgygdTWWG;
        uJiaxqtQRuqk += KblHTFfIJg;
        HOwEoHmvZW += KblHTFfIJg;
    }

    for (int ZUBlXWQyp = 776471150; ZUBlXWQyp > 0; ZUBlXWQyp--) {
        uvJmTwnFKC += BOiigXWWjVe;
        yaQpbyZwTNHm = oNkYgygdTWWG;
    }

    for (int fSAPKNEwxlI = 1331719266; fSAPKNEwxlI > 0; fSAPKNEwxlI--) {
        isBDIK = GdjMfsZpoXgUF;
        yaQpbyZwTNHm = ! yaQpbyZwTNHm;
        VROUdaxhdjHXdyDx += HOwEoHmvZW;
        VROUdaxhdjHXdyDx = VROUdaxhdjHXdyDx;
        yaQpbyZwTNHm = yaQpbyZwTNHm;
    }

    for (int shcPkB = 2086135869; shcPkB > 0; shcPkB--) {
        HOwEoHmvZW += VROUdaxhdjHXdyDx;
    }

    return VROUdaxhdjHXdyDx;
}

string equRRsfxPOgCG::pSvBDU(string aCLhYIhgAfZnUufQ, bool qXsnyzWzXgm, double VXsjCT, bool sUIaWLXyZRqb, bool iObwp)
{
    string LFjJwFS = string("DZBfBjCblUyBLwTHGtcFonPbPDfxmXZHJuRrfEytFmMPBZMcjxuSmcoNQsFTbdkNZIldDhHLLRLAjHGolOSNmoEUyXll");
    double kNzBkMt = -988473.693454279;
    double YnENynFMVzHtjjZJ = -1046898.9922065691;
    bool ypCnoALAIMu = true;
    double gfqcZUGrNfPC = -820523.6036351643;
    string CHjvuyIFn = string("yxqeKluMLnpoXYUWnh");
    string GPRSRWnsQVR = string("dFbuyqLqXzinzCpNOausCkcQPqBHtFUQYAcBINawIbMfvsajTMnzhnZNIWoZEVVIzTrhRDCVtGJYQikHuupubEdlNKZyGjHXS");
    int MAQYCvA = 1204709182;
    string wwOfnrPSuSt = string("oYttURlPbaEAbFArnAxIXGLxPJVfLHTfghwCaxRSjbnFNpsPQJznQYPKHcwwIvKqpLtegJMIUDuBuwYjgLECUWDXsCmIfMsaDztZUAWwovmHuXqFEGwoHKIzEetwqGIPKDafeqDEGCBPQHzCtMaImNZPuhvFQdTxCkjSCD");
    bool sZTRvr = false;

    if (GPRSRWnsQVR >= string("dFbuyqLqXzinzCpNOausCkcQPqBHtFUQYAcBINawIbMfvsajTMnzhnZNIWoZEVVIzTrhRDCVtGJYQikHuupubEdlNKZyGjHXS")) {
        for (int ijqATMio = 257050068; ijqATMio > 0; ijqATMio--) {
            continue;
        }
    }

    for (int WBUTqyfkWkgGy = 1757253512; WBUTqyfkWkgGy > 0; WBUTqyfkWkgGy--) {
        GPRSRWnsQVR += LFjJwFS;
        CHjvuyIFn = LFjJwFS;
        gfqcZUGrNfPC -= VXsjCT;
    }

    for (int LDxve = 474089030; LDxve > 0; LDxve--) {
        GPRSRWnsQVR = LFjJwFS;
    }

    for (int bjByuN = 2133622731; bjByuN > 0; bjByuN--) {
        ypCnoALAIMu = iObwp;
    }

    return wwOfnrPSuSt;
}

void equRRsfxPOgCG::wXqmI(bool dKTdp)
{
    int MSkzBtJYPvAyBi = -1937354425;
    double vjJzX = -743916.5223482301;

    for (int IuCEVxsJTiyGk = 1748331688; IuCEVxsJTiyGk > 0; IuCEVxsJTiyGk--) {
        continue;
    }

    for (int ERAZldLXMCuraS = 1337719061; ERAZldLXMCuraS > 0; ERAZldLXMCuraS--) {
        MSkzBtJYPvAyBi *= MSkzBtJYPvAyBi;
    }

    for (int ZDNvKhyPPsrB = 381912227; ZDNvKhyPPsrB > 0; ZDNvKhyPPsrB--) {
        vjJzX /= vjJzX;
    }

    for (int eLFscxKLkqhHxZa = 102101981; eLFscxKLkqhHxZa > 0; eLFscxKLkqhHxZa--) {
        vjJzX *= vjJzX;
        dKTdp = ! dKTdp;
    }
}

int equRRsfxPOgCG::xAmOgJkqqywu(int bFuXR, string GuJIJjBcjCDp, bool TvwOnkieUJVPue)
{
    int ULEpkdOpaMmHFnR = -1869671197;
    double oZLsYCwa = 345137.6588200668;
    int XhwoSbbENLcLn = -977471051;

    return XhwoSbbENLcLn;
}

void equRRsfxPOgCG::GKJxerLorLZha(double bTuPp, string zPyTRDEbh, bool lTjBKYzOsn, int FfeXnpfiCJFRSs, bool kaMfueMeaVmdy)
{
    int uWLxQVcdoGwPv = -1207944437;
    bool aveWJ = false;
    double bxjLGcYXqSSYTnv = -243322.4058672268;
    string QCbiEKcN = string("vujlZIRRecZtEJqQbBdrqVLWNoUeACJAYnGqKuZanBEcuMfPva");
    string UMVLHM = string("jQCjcBEogaDFTRxEJDrUkTxTtCsysEYHvTRhEjWjJpbhRPSulzExWhAeeXurIEFMerQUMdpfyzDmHXRtMIdNakEcneMapmGOrlZgauSxlsTaQSraSTDhcAaEvbkFmsYSauRkPNXuFQBemasyEGpIKRsXFVPBazIWZDxAXhzUxcZsVGFECFTbfCOrEHPYtbxEdMUwBAIIdjfUgpiLYGvPZZvQFhNzuNZiekBaqRSEGyncZTj");

    for (int vpStEoDgqFZbkZ = 279180857; vpStEoDgqFZbkZ > 0; vpStEoDgqFZbkZ--) {
        bxjLGcYXqSSYTnv = bxjLGcYXqSSYTnv;
    }
}

int equRRsfxPOgCG::qptsJIGrTB(double mlzbTKfsetRYIT, bool DWIzWGjXPCmT, int shvnnNsjAFGdKGnO, bool dTAtny, int xVEWiGeRkB)
{
    int qDGhLEdoMtVUnMYX = 1270385639;
    bool GEnvwe = false;

    if (shvnnNsjAFGdKGnO != -162397936) {
        for (int UVADwgCNipf = 1160366200; UVADwgCNipf > 0; UVADwgCNipf--) {
            dTAtny = ! DWIzWGjXPCmT;
            GEnvwe = DWIzWGjXPCmT;
        }
    }

    for (int VgPiq = 1511098620; VgPiq > 0; VgPiq--) {
        qDGhLEdoMtVUnMYX -= shvnnNsjAFGdKGnO;
        xVEWiGeRkB = shvnnNsjAFGdKGnO;
        dTAtny = GEnvwe;
        dTAtny = ! GEnvwe;
    }

    for (int KzVRFfDoXhEQfiYb = 1807765431; KzVRFfDoXhEQfiYb > 0; KzVRFfDoXhEQfiYb--) {
        dTAtny = ! GEnvwe;
    }

    return qDGhLEdoMtVUnMYX;
}

double equRRsfxPOgCG::nJjPKO()
{
    double QHUbvoXZ = 738460.7742519059;
    bool ngOJZrHEadFDfmC = true;
    int ywrhRx = 516704111;
    bool QiVwFL = true;
    bool yIphefidtk = true;
    string gEzJa = string("HfuqLmXXxJFMZZNwxrQzMLJRenTTzjNLGcwJQXLRvqiIEUBhOfguEkgzanIKtwPFCSxYOcbMrbpHeqeOQMQTapcyooliYvFQWGsDNleuTRMFaWvcPAsOpmjOZQFQywbfkJmTVUKrhReaqpF");
    int DNtKKmfNqy = -768031601;
    int aonAU = -1681066981;
    double VCQSnBDPGzCWJ = 821824.4355853079;

    if (DNtKKmfNqy < -1681066981) {
        for (int ikbTxMXtkMxnfUHX = 1363425968; ikbTxMXtkMxnfUHX > 0; ikbTxMXtkMxnfUHX--) {
            VCQSnBDPGzCWJ -= VCQSnBDPGzCWJ;
        }
    }

    for (int yMhpjHFIFOMOslA = 461411981; yMhpjHFIFOMOslA > 0; yMhpjHFIFOMOslA--) {
        ywrhRx = DNtKKmfNqy;
    }

    if (DNtKKmfNqy >= 516704111) {
        for (int sskduSXEq = 1137722304; sskduSXEq > 0; sskduSXEq--) {
            continue;
        }
    }

    for (int yBYqeKLcotNwRZ = 2056511840; yBYqeKLcotNwRZ > 0; yBYqeKLcotNwRZ--) {
        continue;
    }

    for (int qUgRPYavR = 2003101961; qUgRPYavR > 0; qUgRPYavR--) {
        VCQSnBDPGzCWJ *= QHUbvoXZ;
    }

    for (int NSnDv = 1688874534; NSnDv > 0; NSnDv--) {
        QiVwFL = ! yIphefidtk;
        ngOJZrHEadFDfmC = yIphefidtk;
        yIphefidtk = yIphefidtk;
        QiVwFL = QiVwFL;
    }

    for (int KofFj = 937573932; KofFj > 0; KofFj--) {
        aonAU -= ywrhRx;
        yIphefidtk = ! QiVwFL;
    }

    return VCQSnBDPGzCWJ;
}

string equRRsfxPOgCG::xhCZo()
{
    string GwAkpfCFZ = string("lzcKHtmVPBnMiAQWPpururRQGpxJoKEWhLUlXvnalGUlzaoMjhlXPZrMsdyALkOPRWlkqHmdPAINvvROp");

    if (GwAkpfCFZ >= string("lzcKHtmVPBnMiAQWPpururRQGpxJoKEWhLUlXvnalGUlzaoMjhlXPZrMsdyALkOPRWlkqHmdPAINvvROp")) {
        for (int WwZJQrBntcau = 865596577; WwZJQrBntcau > 0; WwZJQrBntcau--) {
            GwAkpfCFZ = GwAkpfCFZ;
            GwAkpfCFZ = GwAkpfCFZ;
            GwAkpfCFZ += GwAkpfCFZ;
            GwAkpfCFZ = GwAkpfCFZ;
            GwAkpfCFZ += GwAkpfCFZ;
        }
    }

    if (GwAkpfCFZ >= string("lzcKHtmVPBnMiAQWPpururRQGpxJoKEWhLUlXvnalGUlzaoMjhlXPZrMsdyALkOPRWlkqHmdPAINvvROp")) {
        for (int AjyZDWIUvQYZUZ = 831603922; AjyZDWIUvQYZUZ > 0; AjyZDWIUvQYZUZ--) {
            GwAkpfCFZ += GwAkpfCFZ;
            GwAkpfCFZ += GwAkpfCFZ;
            GwAkpfCFZ += GwAkpfCFZ;
            GwAkpfCFZ += GwAkpfCFZ;
            GwAkpfCFZ = GwAkpfCFZ;
            GwAkpfCFZ += GwAkpfCFZ;
            GwAkpfCFZ = GwAkpfCFZ;
            GwAkpfCFZ += GwAkpfCFZ;
        }
    }

    return GwAkpfCFZ;
}

double equRRsfxPOgCG::QCOgQPDPSNpgVoy(string jgdQEjU, int gVYKuNlzUNgYrr, int KowLZ, int TajfmqewiXakp)
{
    string VnCewW = string("gVwONGXLbETUKSXsCVoVyRVxdjqMRclNLTtHeMVCxfLPgxpmoEMBlztRIDetUmUcyuMEyynjUJnJzJLLnDJUqtQjwAUOeInwdgFaSCxkHLhLLRcBqYoMNGsTOlNeHYZpTPqGGwBOkMCxvcWwbbXRXVGYhPapuqKRpmNspOUnCRkGEzuvwVrwTvDglCJjvoeykewNQtugoYfxDYutstkXkZGCYXAzyU");
    int YjjwvyoWkPlSMir = 694150379;
    int vpxqcCjHRYLVD = 753810471;
    bool EhcQH = false;

    return 436315.002433673;
}

void equRRsfxPOgCG::kAllhNpQeuhBalL(string fuvOpfNuDADsD, bool eyHiVIO)
{
    double TAlUrkh = -302158.0969780375;
    double OEylICWNvWxJWz = 726569.7719608594;
    bool zpuYYbGsg = true;
    double FqyBFwHEKd = -22506.684237804395;
    bool uGbPxbrwyUQWkwe = true;
    string npmcsSmzrkCFqm = string("FAsaAfdKXlkZHnQHRcbeicIefhRupvFQRsDfFfSzqaLPDgWdARPQeoggkiWKrrZWLxRXgEeTBSGcrZOZSCKGAHNdPeRtrHynvjruahuANKgyGrEgAmVowWqPefJEKOozWNTyADzDayGJyzMCvCTXywlbDArjyBSGayztLCPoHckpBBrbxfUttxYnEooQskuywfAOcFoFDjAeUuusqYoQcDMcmRdOepApUygFfyZvyhvgYgukRZjLlu");
    double vAzSL = 284575.3041402979;
    double zIGOFroreiDjhn = 479026.0697137781;
    bool ztBpLZyguzk = false;
    double XqpjMlYtSpXyEVn = -148481.8540959598;

    if (vAzSL >= 284575.3041402979) {
        for (int HolscmJ = 414908895; HolscmJ > 0; HolscmJ--) {
            XqpjMlYtSpXyEVn *= OEylICWNvWxJWz;
        }
    }

    for (int BYMvGcgoj = 1752702379; BYMvGcgoj > 0; BYMvGcgoj--) {
        continue;
    }

    for (int iSkiOPqv = 1382121590; iSkiOPqv > 0; iSkiOPqv--) {
        zIGOFroreiDjhn += OEylICWNvWxJWz;
        fuvOpfNuDADsD += fuvOpfNuDADsD;
    }

    if (eyHiVIO != false) {
        for (int pDbyPeRUxmC = 400804707; pDbyPeRUxmC > 0; pDbyPeRUxmC--) {
            OEylICWNvWxJWz = OEylICWNvWxJWz;
            zpuYYbGsg = ! zpuYYbGsg;
            vAzSL /= TAlUrkh;
            zpuYYbGsg = ! zpuYYbGsg;
        }
    }
}

equRRsfxPOgCG::equRRsfxPOgCG()
{
    this->uHYGwsXiuAz(893170.5042065113, 1231457107, true);
    this->HAxhXDS();
    this->ShUFwl(string("vaApgFgRQLlP"), false);
    this->UVJLNgI(100757.32849907641, string("bIdObbkeVNsleiabEcnJnpKPndXx"), -1291334983, 1838425687, string("gqVpueiXuxHliWOHftfZIpgifaRhDnSIIAlMlmKlNpNEmwHtcijuULDJHErseVGmAGzGQukMBeaGXdSLOsYauGKkJPuXYkIjVATPZbXbnkqrJMjlrUhyOoBWmtKSjNtojZvczwuBvgXGDIUqyryEqVcXxCQzfQASdOtpKnVOMvfPKsTKHrDtInGLYMjBtrxXdZKg"));
    this->yXoULdQyQWmnax(519096.49722791294);
    this->IJQDKdwherZ(-659913239, -513299.95303357294, string("vxLZtvAmrCnnyLu"), 560444.3604600125, true);
    this->ynPiogaLT();
    this->EeIQQsW(string("bUWNCguIATArpjICuovlIVdPyTbfolnwCebzwkSUiPwdLwwHzV"), false, 563986755, 338428795);
    this->UluGssXnIstY(string("OyxwFYqjBwGKGQnsNotuhdQPrCesmuAEOTnJFOkoGCvbXNYDAznppgsCOvadNiDeoriszjIYQVijNwwpHoNXdhdzHrvoNhAh"), true, string("GIFrbValfRzNSZWMaJoSfijPBraCklbrBoY"));
    this->pSvBDU(string("PMAnUuAjdhQbeAXQjOkIZOkdFLsywtXDEuXiDbYhlPDf"), false, -916901.2424403654, true, true);
    this->wXqmI(true);
    this->xAmOgJkqqywu(1468587845, string("xuEtXnjzXsPOdFBhpaRWTyVbrujycMoPHvZFXtNhKtVmMlaVqzhjUDKnOYCAVSXALXTTWedfGBbkinOYcrrVrzthnYiunSGjpVaQoSkcVFlXmd"), false);
    this->GKJxerLorLZha(811981.9947831072, string("VurkaVMgWcOvoSdhiezuChaunScJFNxYFoQZQEBqoRhKcFjdeDujaHQwJeSCVRbeiDCXHAIkJJuHCSFJaWdjcGvjXq"), true, 2008619363, false);
    this->qptsJIGrTB(16207.493048580765, true, -518139592, false, -162397936);
    this->nJjPKO();
    this->xhCZo();
    this->QCOgQPDPSNpgVoy(string("PssJQwJQCVCexmKPVpmsyIbeTffoqbhktbIOSwGsijDNWvnqjtWkprZwyzECNANfnkZTjofZdIPDzUCAKDcXdtLoRJAiNCPVYsr"), -606107498, -1762755563, -1257919715);
    this->kAllhNpQeuhBalL(string("pskiyerMLdckPAyAtEmhsCleQMBOxbnJnSWgkZtqlOjelNrEbjTVnCevzpPsqufyofUQOStQYFMNUVobmwpptTDAgMDiNhZDVQsJJGYtBwJKqWgotBjEefcoGRyfomkqModPNcyiEQUgLTbNmPXX"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nNorbYn
{
public:
    double xKIyZEDqIGOnwz;
    int JnOrSSUwri;
    bool BuFnebCUV;
    string AxAzaNldkV;
    bool TmVyZCMRvNsXGH;
    double dsZDe;

    nNorbYn();
    int FzTXnTZFslI(double FzgzohttE, bool ayHFCywjNrQICjC, string kljbYYAvxqnNBlkD);
    double GpQPCXukkrmPWb();
    bool PqiqUsgShDisGdiI();
    void VIeWruPN(string tfETbXhV, int PDGWqB);
    void pMsjFG(int qqsUUus, int MKvIcmbEOnPuL, double TFRkfT);
protected:
    bool wPIrjvXiXDuynVy;
    int CFFTck;
    int CPMlVoyAZfn;
    string PsnqXdyYGqwo;

    bool mhGzzFuncYiV(string HKVYBOlzglNG, string CakggALl);
    int svieGqkMVQc(double qBsluBdgMetbgF);
    void hdNvMkOwkXcqp(string nPftZGlm, int NPCzCBK, int wxDWvQ, double gWAOfuhvAtGHR);
    string qeVUBiMUy();
    bool MRCjAadywj(string sMUIpLbJtFPBIxZ);
    bool nRcNIiJ(int AsQeKv, bool bkaOxOZN, int kGetF, string gDjXDtytSkCPF, string nyLyFrBbGebYGC);
    string kDqDQxswANqSVK(double aBZzTjlk, int owPRtqvVoargBYFV, bool BnuouNmHNjyL);
    void OXykZTHiyE(string ZwwJGTiGPsqejre);
private:
    int qjgTJdrRyuvOww;
    bool Krunlp;

    void LZlkmpLzZuBgM(string mtZRYZazx, string xxihINOxBHlnx, int XcyiqIWvemFLpiIY);
    double wqQhpbAOVKkKJi(double SNBLTT, double vndDMgsDUNKO, double vGcwdYlBJo, double BPDBSQ, string JOaqsCakfdrjVwuS);
    void iAyImANfcoWBQ(double NDoMse);
    void YHJcKNDx();
    double YPqujMj(bool qYIJzfsXpCvyPHi, string CJzZksiNGYsVBkno);
    bool jaqaOL(double CNNFUqWk);
    void sIBzbi(int spbsIEMVUbmAxY, double EqAvznCZtHHbo, string wWbBXY, bool nEvLqrvOZG);
    string hBjTti();
};

int nNorbYn::FzTXnTZFslI(double FzgzohttE, bool ayHFCywjNrQICjC, string kljbYYAvxqnNBlkD)
{
    string xYrxUGBwH = string("nhnnuYDJLzmUdHmoCKDHQrZFagkQe");
    bool qFiddWPPQrgAuA = true;
    double wnUNGeCyDXSxjuc = -432187.71360973344;
    string GVqkQKwvXO = string("QkeNoLMDeQkrbWAsKHlDXYdAScJNuelkRbWYcTSlneVBiHyWmlAhYcFvqoXsXLmtqOalSVnSEokJiRHZBHsPyanfefaLXJoMkZsSogQMsIuzGmjUKaprIJBhUFrFvhbFCiSAgxwnusBKtssdCOHCJjFvGCatqybWADDqPlwfJuiFoSNCpEJ");
    bool qcgPuzc = true;

    for (int bVFxMlkZCF = 1888951938; bVFxMlkZCF > 0; bVFxMlkZCF--) {
        qFiddWPPQrgAuA = ! ayHFCywjNrQICjC;
        GVqkQKwvXO += xYrxUGBwH;
    }

    for (int GDdkaCGyUwTdRToq = 1917531831; GDdkaCGyUwTdRToq > 0; GDdkaCGyUwTdRToq--) {
        FzgzohttE *= wnUNGeCyDXSxjuc;
        FzgzohttE -= wnUNGeCyDXSxjuc;
        GVqkQKwvXO += xYrxUGBwH;
    }

    return -1602628374;
}

double nNorbYn::GpQPCXukkrmPWb()
{
    int jtTKoWcwROlBMqt = -1587372407;
    int ePDkrDZiTL = 1220254652;
    int bfcNdfPuETZqkR = -378034217;
    string iwkKlWRJAnHqp = string("pzSQwBVxwZDYjQSZpUmjYRIlhQaeUxsrVaAWHhzdmUEkWwrKkRoIYGYWBvTGRDwivwKyVqmqecpywbIquzzqeFvqJWhRclSoTJQDQzbPoZyKCcNlJkGutqReuhDRJdlLgMAsAHiKFaYgNIkejVTrnrJJxovgsgA");
    double asWqyH = -1017830.1654517358;

    if (ePDkrDZiTL <= -378034217) {
        for (int bKWcsukr = 147853922; bKWcsukr > 0; bKWcsukr--) {
            jtTKoWcwROlBMqt += ePDkrDZiTL;
            ePDkrDZiTL *= jtTKoWcwROlBMqt;
        }
    }

    if (ePDkrDZiTL <= -1587372407) {
        for (int lCCSIVqhnChJSRao = 1518215737; lCCSIVqhnChJSRao > 0; lCCSIVqhnChJSRao--) {
            bfcNdfPuETZqkR *= bfcNdfPuETZqkR;
        }
    }

    if (ePDkrDZiTL < -1587372407) {
        for (int qGUFFRjmKJqK = 1019993384; qGUFFRjmKJqK > 0; qGUFFRjmKJqK--) {
            continue;
        }
    }

    return asWqyH;
}

bool nNorbYn::PqiqUsgShDisGdiI()
{
    string zpUIpecTiyOBDrQK = string("LHVftDhFvWUdofAWYSbLMRcaTdlzwrzDeuIvfymUcGlqfrYQsfDHTgzHrnlaGAqlnGhnYuaxcZrXmvPSUWbZghWawNCpvwUgLcDDPEPmtPoELrlWNnFjakVuWFyyoWLHJDeTVTlZemlsQETAfYIUVedunYpibU");
    bool YPwpUG = false;
    bool xdAeLza = false;
    int suJrMxYtZxOSFN = 469914355;
    bool vVNNfrzpKT = false;
    string wLhVPdeHyZ = string("YtODMNghJCteiAphjyokEAqCBkTuMtchxwEFGLscLiCLksATXqjUxvqCxFuUJntvcKCevDBxtWwoYzXorreSqnmExhhAdkAAujoMEwthZWcUEcmrgVOzHRuGyOqBQGwCKIeQGJkSsXuJTpfOuLXBDSAkKFSFqMKSRGGSdxOqMbXdJdedFNcwYPjXKKhGtJNaIuFBpWynGLQorUvHXURIFJlSzVloSbSOnVsFgcOtORvTnYPkUrvtyncibkCf");
    double JBAHo = 42060.847293355175;

    for (int vkmfc = 534380282; vkmfc > 0; vkmfc--) {
        xdAeLza = ! YPwpUG;
        zpUIpecTiyOBDrQK += wLhVPdeHyZ;
        YPwpUG = YPwpUG;
    }

    for (int iLPvKNlRsBnmlrSV = 54514351; iLPvKNlRsBnmlrSV > 0; iLPvKNlRsBnmlrSV--) {
        xdAeLza = ! YPwpUG;
        wLhVPdeHyZ = zpUIpecTiyOBDrQK;
        xdAeLza = vVNNfrzpKT;
        xdAeLza = ! YPwpUG;
    }

    if (vVNNfrzpKT == false) {
        for (int POBDw = 1740138808; POBDw > 0; POBDw--) {
            continue;
        }
    }

    for (int oItuCPUcbnhKiRT = 300503193; oItuCPUcbnhKiRT > 0; oItuCPUcbnhKiRT--) {
        continue;
    }

    return vVNNfrzpKT;
}

void nNorbYn::VIeWruPN(string tfETbXhV, int PDGWqB)
{
    double pFPscBIRZAEKQv = -1032235.4832669961;
}

void nNorbYn::pMsjFG(int qqsUUus, int MKvIcmbEOnPuL, double TFRkfT)
{
    double yPMDqkyJS = 435366.84550381533;
    string poUqmmxvME = string("CBCHNLvMNNsxtpxgDvpmhaAqMyPIpAUOmtOdfjhH");
    int qyuyOhcxbVxzrc = 446000016;
    double PjgQCe = -36899.399104384276;
    int XTyyDCDGNCysYb = -1719055166;
    bool jaQJmRE = false;
    int hsbAvS = -1744001712;
    int QNrnskVYYYsuwHA = 418737951;
    string ZBOEq = string("OCmPrzByqcvAyxmKcQCYAVVhCsElXgBiAAhpkbDdNXEgjBMwUykQeydmMCzNIUwTvUgIzzjzquYjfUbfsuuYmbwivNKPtinHIRxPYqCanSEvkZKNdtCDRImvFVPJZwFKURYYbRZlwsneJsfRDcPfSRbTCNjBuNXQFHiIwbDlkOOCtRnyRDNu");
    int hIZvfdtQv = -1053787574;

    if (poUqmmxvME != string("OCmPrzByqcvAyxmKcQCYAVVhCsElXgBiAAhpkbDdNXEgjBMwUykQeydmMCzNIUwTvUgIzzjzquYjfUbfsuuYmbwivNKPtinHIRxPYqCanSEvkZKNdtCDRImvFVPJZwFKURYYbRZlwsneJsfRDcPfSRbTCNjBuNXQFHiIwbDlkOOCtRnyRDNu")) {
        for (int AsuxYKO = 824295511; AsuxYKO > 0; AsuxYKO--) {
            continue;
        }
    }

    for (int BJPvnIAmCPAul = 502618830; BJPvnIAmCPAul > 0; BJPvnIAmCPAul--) {
        continue;
    }
}

bool nNorbYn::mhGzzFuncYiV(string HKVYBOlzglNG, string CakggALl)
{
    double PQNpyfZkLoMGzPT = -726735.6554952624;
    double TxWDOvddzcjw = -455978.4715061609;
    bool BEeRHZYxpK = false;
    string CtdADBZszLpcukzI = string("uKmqNPmjIDSZIPwFEYGkoORPQnNBzFPQfOSDkhQTNxOWOPROEMBdPaOjGPlAonONLRxzUHZcJywouMBNNTocbpoZzCWgZpxYVCqFifNDUlmHQGuKyITJLyFSPuKEZpqIoDROOlI");
    int hDldRLtVXu = -1315066408;
    int CfForBhYphEYn = 1402821078;
    int DXIeXTilWbn = -422897459;

    for (int viRLyqvPHZ = 2007967720; viRLyqvPHZ > 0; viRLyqvPHZ--) {
        BEeRHZYxpK = BEeRHZYxpK;
    }

    if (CakggALl >= string("HOWNfyvHiYACIRbeFwFxXVVPkYEenzRjVLtJiESFqmCJtGNLklsAqGmhTfdQZJvMqGqprTZGUlQNspcRwUGoVnpPntpqPFnUiGdMTUnNbIACEDseqKioDqKbzSxAtXjcPMdDnkJqQJaAKGJBkKTxlUQGFyIWckLsGJFzvuSSyjBEOOsJlnkKIgQNPNoABPSxlxQOkQHYhxZmOLxuSSXHmHLJIAoLOyebrtxBvRqtAupZd")) {
        for (int vacNxG = 1900437591; vacNxG > 0; vacNxG--) {
            hDldRLtVXu -= hDldRLtVXu;
        }
    }

    if (HKVYBOlzglNG >= string("uKmqNPmjIDSZIPwFEYGkoORPQnNBzFPQfOSDkhQTNxOWOPROEMBdPaOjGPlAonONLRxzUHZcJywouMBNNTocbpoZzCWgZpxYVCqFifNDUlmHQGuKyITJLyFSPuKEZpqIoDROOlI")) {
        for (int uGLzaJuumis = 17797959; uGLzaJuumis > 0; uGLzaJuumis--) {
            hDldRLtVXu += CfForBhYphEYn;
        }
    }

    for (int ObZiWXjJ = 1418113246; ObZiWXjJ > 0; ObZiWXjJ--) {
        HKVYBOlzglNG = HKVYBOlzglNG;
        BEeRHZYxpK = ! BEeRHZYxpK;
        CakggALl += CtdADBZszLpcukzI;
    }

    if (DXIeXTilWbn > -1315066408) {
        for (int KBcwSfx = 1521858890; KBcwSfx > 0; KBcwSfx--) {
            PQNpyfZkLoMGzPT /= TxWDOvddzcjw;
        }
    }

    for (int rDrfz = 40845345; rDrfz > 0; rDrfz--) {
        hDldRLtVXu /= DXIeXTilWbn;
        CfForBhYphEYn += CfForBhYphEYn;
    }

    for (int EImNIrsNUWKQLEI = 2136295498; EImNIrsNUWKQLEI > 0; EImNIrsNUWKQLEI--) {
        hDldRLtVXu -= DXIeXTilWbn;
        PQNpyfZkLoMGzPT /= PQNpyfZkLoMGzPT;
        HKVYBOlzglNG += CakggALl;
    }

    return BEeRHZYxpK;
}

int nNorbYn::svieGqkMVQc(double qBsluBdgMetbgF)
{
    string mxPvxfE = string("ljloKDtaxGhkvUjEGQnMsPhWZYEhwOHWrpqIVaVXPgjXZdT");
    bool KNzTZaXo = true;
    int VuVszdkBA = 420518207;
    bool pemOJ = true;

    for (int bPUFrmdVXB = 1932852879; bPUFrmdVXB > 0; bPUFrmdVXB--) {
        mxPvxfE += mxPvxfE;
    }

    if (mxPvxfE >= string("ljloKDtaxGhkvUjEGQnMsPhWZYEhwOHWrpqIVaVXPgjXZdT")) {
        for (int izyem = 764700510; izyem > 0; izyem--) {
            KNzTZaXo = ! pemOJ;
        }
    }

    for (int TtohgegV = 523539681; TtohgegV > 0; TtohgegV--) {
        pemOJ = ! pemOJ;
    }

    return VuVszdkBA;
}

void nNorbYn::hdNvMkOwkXcqp(string nPftZGlm, int NPCzCBK, int wxDWvQ, double gWAOfuhvAtGHR)
{
    string iShKoBlmuGbhMA = string("jruGgDgFoGwoHvGlPCLEpOnaRLzeCniaLynNgBPDxxBSwBsmbQVbTeDpSLMmPCJhyFFzZRqHGcisT");
    bool hEzbHwBRugSKgQ = true;
    bool RJgsMMuRctQ = true;
    int NeAVuHyaXXoMInVl = 1207139329;
    bool NiIhmx = false;
    string flNccRSz = string("zRuVizuqFlAypVcriKaKehQGhjQjakXPnMgMC");
    double ZPgBq = -56559.8871923821;
    int zjCoUQjFyBoj = -1560401620;

    for (int pZkeiVCCupB = 809737178; pZkeiVCCupB > 0; pZkeiVCCupB--) {
        wxDWvQ *= zjCoUQjFyBoj;
    }
}

string nNorbYn::qeVUBiMUy()
{
    string mczGFQZkLr = string("bYlDwnlwAtUHeRnQJozQdcmpBusnHWwzhtrOziYrRtrPrbxpICVBvMLmrVvHvrWoDLIFbWiehaNgGZxlaYmtloTWtOooxaItYkUSczRJItIePVkLLZdsCLlzIFnPAGwXPIW");
    int nGybo = 674512854;
    bool fvCDqRiSeK = true;
    string BnocdsZCeZHn = string("LMXFjYtsAuHBSUaQiFPlroZppjJRzQvZSLGlNJvRQIpmgwJJIkSBqwUBpuhqVjnISvJabKXIccowvDUNZYUktCrwDuHsyHswEwAwShVDALHpcltfNKcffQxFEmwaIyfwPff");
    double urPDiviL = -511647.8481976969;

    for (int iHbErWpOPojhdUUx = 1603646928; iHbErWpOPojhdUUx > 0; iHbErWpOPojhdUUx--) {
        continue;
    }

    return BnocdsZCeZHn;
}

bool nNorbYn::MRCjAadywj(string sMUIpLbJtFPBIxZ)
{
    bool FGbSVdXGM = false;
    double zWvDFZsWoRqJdr = -786279.4323573179;
    bool IhUzAhMDGfVr = true;
    int jXCpeZHuMYFcAtvI = -46471695;
    bool wGOus = true;

    if (sMUIpLbJtFPBIxZ <= string("zBlwUYFnpomWRivSZUXWwABHExEzUSmjcFzetFLtZZbHydHYYdMBEXJlQXTXsAMpkxKyYLgsFOEYQLZiFIDplzIZDIDwPoBoxPKkAzerpGPiVhxlRmRiKmEvUjFlHopyyIioTxmyXzlGbvVKkaJaRVpsJStzRNbwJwjoTvvlYGNKSHgugg")) {
        for (int zSbgqfs = 2080231368; zSbgqfs > 0; zSbgqfs--) {
            FGbSVdXGM = ! IhUzAhMDGfVr;
            wGOus = ! FGbSVdXGM;
            jXCpeZHuMYFcAtvI /= jXCpeZHuMYFcAtvI;
        }
    }

    for (int FsSLcMJdRZehkTtd = 790581052; FsSLcMJdRZehkTtd > 0; FsSLcMJdRZehkTtd--) {
        wGOus = IhUzAhMDGfVr;
        FGbSVdXGM = IhUzAhMDGfVr;
    }

    for (int oztJnVHJo = 921945412; oztJnVHJo > 0; oztJnVHJo--) {
        sMUIpLbJtFPBIxZ = sMUIpLbJtFPBIxZ;
        IhUzAhMDGfVr = wGOus;
        zWvDFZsWoRqJdr = zWvDFZsWoRqJdr;
    }

    return wGOus;
}

bool nNorbYn::nRcNIiJ(int AsQeKv, bool bkaOxOZN, int kGetF, string gDjXDtytSkCPF, string nyLyFrBbGebYGC)
{
    double NJbAwo = 119130.21963948171;
    string gpdAtJKX = string("GgRBFiPNIFbHJyibJZEvblDxRJSuAQYtXFWGDCCVmMuxThmfWhbWBiPkwzaGKcJPSfJUkIfVxBaxCbCOiFnXgimVNHUlELUmVCayAiZSJEDcEizDGprkjLeWdOxzeqpupPyQlBybGeSLi");
    string YmaZBgjIhY = string("tipUFrvZVxUaZvhRLTupjAyiPyV");
    bool HkSHZUeZqty = true;
    int KNRTvtUpJv = -2146238570;
    string pukIrRKNVe = string("NgaNIAYHzCNWqBohxNLNpWFeZCkQiwGzTgVTvDhTcyLyDhlFSVbYSBSIuYlnXToeiYkMsHlifpnYaUvXEDiw");
    double JhKuzdpADjh = 945976.5171118699;
    string cGQvvZqV = string("beEgqDQgoakSkGedfrGHEiOxzIsSotaIIegSMtVCUkCynNzdkVUelgNHWpEVrpDRJDSsQDxGoKbEpCgPHkOZdeTxzGJBQjlmSJBDZGqfYPHkxvsHBGeStkooFfpKiGoQBTWsqekTscINuwNoCiomnPByCvkCTvWuosBLODCGNeKdETtQfOJVz");
    double WKYkZyX = -366088.0652203214;
    string Esvdj = string("XaNBiVBZdiMRkMCOFMRJWBvoyQjhSQDevbkRsGwutsrHzzpaJjNvAPrhRIMGsrJAyerGXZXbjWGgpSwLMmCMgEvaJLtUCRdKnLYdhewsXoQpqldzSIGHGFOKyfykJcjegvmUNUcomFDwMmhMcspcEfhvbwBiCsQ");

    for (int cAUiVtWxnSgjLsf = 696259449; cAUiVtWxnSgjLsf > 0; cAUiVtWxnSgjLsf--) {
        continue;
    }

    for (int ktAuBPqmQhElg = 1767934614; ktAuBPqmQhElg > 0; ktAuBPqmQhElg--) {
        pukIrRKNVe += nyLyFrBbGebYGC;
        WKYkZyX /= JhKuzdpADjh;
    }

    if (NJbAwo >= -366088.0652203214) {
        for (int PvFhlYynIrhGeeY = 390146798; PvFhlYynIrhGeeY > 0; PvFhlYynIrhGeeY--) {
            continue;
        }
    }

    return HkSHZUeZqty;
}

string nNorbYn::kDqDQxswANqSVK(double aBZzTjlk, int owPRtqvVoargBYFV, bool BnuouNmHNjyL)
{
    bool UKykpT = false;

    if (BnuouNmHNjyL == false) {
        for (int psTzyfcArUQ = 175651065; psTzyfcArUQ > 0; psTzyfcArUQ--) {
            BnuouNmHNjyL = ! UKykpT;
        }
    }

    if (UKykpT == false) {
        for (int XNngnXfVCdX = 108082385; XNngnXfVCdX > 0; XNngnXfVCdX--) {
            UKykpT = ! UKykpT;
            BnuouNmHNjyL = ! UKykpT;
            aBZzTjlk /= aBZzTjlk;
            BnuouNmHNjyL = UKykpT;
            aBZzTjlk = aBZzTjlk;
        }
    }

    return string("DYWAYLqXmYBqxlidfRsjWkjOfFGZYEcUzIQPACmxtLMBvbGHsQodGiQdUkWvnckpckvpUtQiLWzHpNdtkcGITwqeBeleBVhKfMAlAlyYsIAJUwMBndERapNHjdTYDxEYABCqEBpzOjeVFrqyOMZWXZndDtsLLxUt");
}

void nNorbYn::OXykZTHiyE(string ZwwJGTiGPsqejre)
{
    bool LyRxnTZt = false;
    bool hzMAZlqmEA = true;
    double ppaQYsBYbjzD = 860470.6035881904;
    int JhjKahlj = 1302201657;
    double metPmZSAleTv = 96053.50299919068;
    bool JDnJBeagG = true;
    string gpOdxalodwqFi = string("hZkkDLnYeLdglzUfixMEcLzHvHNoCmVPEXCYOGnkZsQUVNxtfYoRxOmVSGyCzJponRz");
    string RSyJVCxdMhpaUl = string("tGBnAsimLUvccNwKwTSPOoYoBsnvTIjrNMSEyNojrxtWuTjQINhmzbUBvwqbombnFWkURNEsCMXAnmNKlYJOetgHUneGdumWsiLRZMbLLCcIApRyTtBJzOiCmnrSvUCgrtQXGHVMUrgFKVEzAdgwDjknOFIRdWBEZzxiHmXDQRnNZFuMQZSkHgPbXJuaxMGppBzstZSTvpsLMThHmUskLtXmSwoohhA");
    double MwjshAcxPReuQDU = -57084.205262800824;
    string QJHAfTuPyHDhTG = string("vPOASNcJFOZHmlHJVuErUGHzrwvCNQWxsptDnNchaeGKaotgrArqsIoMfrIGqvEgnhaVfEDPifeAuyNiKtifeHecBKSlOzKoRitfAzftVEzyhXGoUIWTwdjpLGQfVKwmA");

    if (ZwwJGTiGPsqejre != string("tGBnAsimLUvccNwKwTSPOoYoBsnvTIjrNMSEyNojrxtWuTjQINhmzbUBvwqbombnFWkURNEsCMXAnmNKlYJOetgHUneGdumWsiLRZMbLLCcIApRyTtBJzOiCmnrSvUCgrtQXGHVMUrgFKVEzAdgwDjknOFIRdWBEZzxiHmXDQRnNZFuMQZSkHgPbXJuaxMGppBzstZSTvpsLMThHmUskLtXmSwoohhA")) {
        for (int IUrmu = 996280366; IUrmu > 0; IUrmu--) {
            MwjshAcxPReuQDU /= metPmZSAleTv;
            JDnJBeagG = LyRxnTZt;
        }
    }

    for (int bwkWDXdBEtH = 1291619996; bwkWDXdBEtH > 0; bwkWDXdBEtH--) {
        QJHAfTuPyHDhTG += QJHAfTuPyHDhTG;
        JDnJBeagG = ! LyRxnTZt;
    }

    for (int icIrOCLxRZHGwWi = 1433604283; icIrOCLxRZHGwWi > 0; icIrOCLxRZHGwWi--) {
        JhjKahlj = JhjKahlj;
        QJHAfTuPyHDhTG += ZwwJGTiGPsqejre;
    }

    for (int zzAsrPDlACKjIKfW = 100699437; zzAsrPDlACKjIKfW > 0; zzAsrPDlACKjIKfW--) {
        RSyJVCxdMhpaUl += QJHAfTuPyHDhTG;
    }
}

void nNorbYn::LZlkmpLzZuBgM(string mtZRYZazx, string xxihINOxBHlnx, int XcyiqIWvemFLpiIY)
{
    bool XHyVl = false;
    bool lxtgXzJpk = false;
    int zMRjokHmbyqegHh = -364811692;
    bool bZbHURDb = true;
    string QRzYUHChWFgQINvY = string("sCJhCRQWWABFLDhxwkLaMDTvCxmULEssxzCVfQEmbfDTuIdzePZpAaxqxqhMwseqewThQEOcBSUfrIIXwxrpWXIoStfyAcvyfmXaGEuuXnPeDbLfdKdHYTMNRyPNeJvzCTpClyTvNBhfeAgHfAOkWVosOkdgUpqJyknzBJgQHJexXfSiUexxLUXpvtnMblcESLkXpkrxmZQPtvPZfdJJkNmPhbNpzUHKKme");
    bool yxsDUXTEyTK = true;
    int KEBzlSSE = -400446632;
    int IBepzAhIxkKJQ = -1053706250;
    bool aZImXxt = true;
}

double nNorbYn::wqQhpbAOVKkKJi(double SNBLTT, double vndDMgsDUNKO, double vGcwdYlBJo, double BPDBSQ, string JOaqsCakfdrjVwuS)
{
    string cfqozashcbP = string("VBTObUZUwTPuKnEIRrvztLvvxxpZszXAUCPHPCwPCyMaNGbxCNeUvQzpyhzFAonOOCGGfAJiGMdfIlYZEnrjFBLxokQJUZQuuVGcFTbPLPxRNGHjHXhLYPMqUgxMpdQHHAyypzFSCMdbPxFJXQUNlKVhHWlRUAnVhyXWwCLTNWZtYtTgZijaJYNfBlGNlNwzByVLLEDgfjjsOVgjjysdianQtjupXu");
    string kAPZzTmq = string("uZOVxhetJriAgMZqQjFOtmNodlDGOWeXNJGbInClfmAHlXPMLarlpCPKEmgzRnHBUFTFAbpxoRehSRtQuRGBFHoIlntZMrvVrypuRyGzirMsmVsCWGdXsaYguqLHmFTHFDDvQapDirimuGAmxtyhJVtzQMFujPMPrRzGbbCZCvosHHVLhTYRDZAccdvMqvjnpnIwq");
    double IsjHIcHWdT = 908506.9645604711;
    double wcEnLTZndOPuH = 795710.8196052962;

    if (IsjHIcHWdT <= 795710.8196052962) {
        for (int LvDubRgwnvChIKa = 393667373; LvDubRgwnvChIKa > 0; LvDubRgwnvChIKa--) {
            continue;
        }
    }

    if (BPDBSQ >= -217713.32626764287) {
        for (int rQAnTlQuKxyuSIF = 115606294; rQAnTlQuKxyuSIF > 0; rQAnTlQuKxyuSIF--) {
            wcEnLTZndOPuH *= SNBLTT;
            BPDBSQ = BPDBSQ;
            vGcwdYlBJo = vGcwdYlBJo;
            IsjHIcHWdT += wcEnLTZndOPuH;
        }
    }

    if (vGcwdYlBJo > 795710.8196052962) {
        for (int hilppIwlOdq = 483667772; hilppIwlOdq > 0; hilppIwlOdq--) {
            cfqozashcbP = JOaqsCakfdrjVwuS;
            vndDMgsDUNKO -= SNBLTT;
            wcEnLTZndOPuH *= SNBLTT;
            vndDMgsDUNKO *= BPDBSQ;
            IsjHIcHWdT -= IsjHIcHWdT;
        }
    }

    if (vGcwdYlBJo > 1029016.4271081757) {
        for (int PMjucXa = 913613323; PMjucXa > 0; PMjucXa--) {
            vGcwdYlBJo *= wcEnLTZndOPuH;
            SNBLTT += wcEnLTZndOPuH;
            vndDMgsDUNKO *= SNBLTT;
        }
    }

    for (int bvuYpUlyDTPXGz = 1797369573; bvuYpUlyDTPXGz > 0; bvuYpUlyDTPXGz--) {
        BPDBSQ *= vndDMgsDUNKO;
        BPDBSQ *= vndDMgsDUNKO;
    }

    return wcEnLTZndOPuH;
}

void nNorbYn::iAyImANfcoWBQ(double NDoMse)
{
    bool tYMriIq = true;
    string GZmwMwHdjHS = string("haeScJWNOblylOlqMFsnvMHDberLZPzHJwVxyztQjXMwolvZkWdcrkSlyxGyneqKOUybzewtlOAjxZtMNGnTvgUnIePPnSFepZjFalywcmyAeuzPzOumGkkwNejg");
    int GLhzNbsx = -772604380;
    string fOjtpEmngDsu = string("MuJHxFuXPsmuFphQXXaSpZMKuaGuKIykuiTlbSzRPCeVCkoUGtJEjUUSDiOuxKcsvawVupjYVfVnxUHAQlnMHTtPsMcOWSEdlIzDjCKZnCdtIGSXxSRDFMujzsrirMdFZraaqOFKFpYeBHXogSCstRzXuHJQAJCErsG");

    if (GZmwMwHdjHS != string("MuJHxFuXPsmuFphQXXaSpZMKuaGuKIykuiTlbSzRPCeVCkoUGtJEjUUSDiOuxKcsvawVupjYVfVnxUHAQlnMHTtPsMcOWSEdlIzDjCKZnCdtIGSXxSRDFMujzsrirMdFZraaqOFKFpYeBHXogSCstRzXuHJQAJCErsG")) {
        for (int mWFgiiAwBU = 1673082714; mWFgiiAwBU > 0; mWFgiiAwBU--) {
            tYMriIq = ! tYMriIq;
        }
    }

    for (int cLFUFiJDN = 1423415624; cLFUFiJDN > 0; cLFUFiJDN--) {
        GZmwMwHdjHS = GZmwMwHdjHS;
    }

    if (GZmwMwHdjHS >= string("haeScJWNOblylOlqMFsnvMHDberLZPzHJwVxyztQjXMwolvZkWdcrkSlyxGyneqKOUybzewtlOAjxZtMNGnTvgUnIePPnSFepZjFalywcmyAeuzPzOumGkkwNejg")) {
        for (int IlRMsKLoNhczK = 1895841221; IlRMsKLoNhczK > 0; IlRMsKLoNhczK--) {
            GZmwMwHdjHS += GZmwMwHdjHS;
        }
    }

    for (int bjsKhDM = 832566599; bjsKhDM > 0; bjsKhDM--) {
        fOjtpEmngDsu = fOjtpEmngDsu;
    }
}

void nNorbYn::YHJcKNDx()
{
    int rxYgphlcsXpqOL = 1878079190;
    double hoeGxZL = 633864.0459214416;
    int mIDJlkeJkWWRB = -1307510600;
    int cvrZlAJx = -1145034729;
    int IyfCAzqtphHXfQZi = -1084247805;
    bool KNrsqKqfXJ = true;
    bool YlNZFESvuG = true;

    for (int HNCSGHiJJ = 638656120; HNCSGHiJJ > 0; HNCSGHiJJ--) {
        YlNZFESvuG = YlNZFESvuG;
        IyfCAzqtphHXfQZi -= cvrZlAJx;
    }

    for (int ubeGtIvPw = 223532775; ubeGtIvPw > 0; ubeGtIvPw--) {
        IyfCAzqtphHXfQZi *= rxYgphlcsXpqOL;
        IyfCAzqtphHXfQZi += rxYgphlcsXpqOL;
        rxYgphlcsXpqOL += mIDJlkeJkWWRB;
    }

    for (int aSSthDfGOdejSiy = 1061866321; aSSthDfGOdejSiy > 0; aSSthDfGOdejSiy--) {
        IyfCAzqtphHXfQZi *= cvrZlAJx;
        cvrZlAJx += mIDJlkeJkWWRB;
        YlNZFESvuG = KNrsqKqfXJ;
        mIDJlkeJkWWRB /= cvrZlAJx;
    }
}

double nNorbYn::YPqujMj(bool qYIJzfsXpCvyPHi, string CJzZksiNGYsVBkno)
{
    int ZssjOfLGkrkqs = -1267814128;
    string SJoJrliGx = string("GSeSDxBcYJlIDiaaUbwacjQNYRbncHWyZmOYFwKmRhrisFvGZyTCMccgLRNkUrwersukpoBgRbNfxkzvXHqmfFpJxRgUNUvODkFgssIVHnEVKoADWUpSZSbJSFnNqciJnDuItFEpjBKtExwagnShSqxSUxGGbWhJimkuZHucmAiuncmMZlTbPbEXEtyMLnZIRZsDuZtACGzxnLocHsuuFbTzUbXbmVRHOWgfeLOfqS");
    bool cFlyCHOZEWW = true;
    double FguFeb = -1011875.2890881934;
    string TCQJvkLhfuzbDcy = string("WYhKQYevnsamFxnubXuUxZMvfKondAbvEyCipqhEbAauTofVxsscatoHfjAahQImWzWzWeWhDwHvWtrvqKVTmjkYAznMSbJxprMbpSjFYVySNLyKkTPvJqYQCbprLRfGGYAMeIkflzEcJFygrSfMBcSpfhyxtGnVuebAeMeAnatRzPjkiWfAUgaacCEaGsdVLZrtxPlqobFjJeGTJyuwHEJL");

    if (ZssjOfLGkrkqs < -1267814128) {
        for (int MoEzfM = 1163976341; MoEzfM > 0; MoEzfM--) {
            ZssjOfLGkrkqs -= ZssjOfLGkrkqs;
            ZssjOfLGkrkqs = ZssjOfLGkrkqs;
            TCQJvkLhfuzbDcy = CJzZksiNGYsVBkno;
            qYIJzfsXpCvyPHi = qYIJzfsXpCvyPHi;
            cFlyCHOZEWW = ! qYIJzfsXpCvyPHi;
        }
    }

    if (CJzZksiNGYsVBkno != string("LvQLHuBNWPzUhphpeozoeQrdEBhMiwYJVtPZWcwYf")) {
        for (int bXTFNcKUlhTH = 1831711083; bXTFNcKUlhTH > 0; bXTFNcKUlhTH--) {
            continue;
        }
    }

    for (int NuplUCJmCQLR = 442416644; NuplUCJmCQLR > 0; NuplUCJmCQLR--) {
        ZssjOfLGkrkqs -= ZssjOfLGkrkqs;
        qYIJzfsXpCvyPHi = cFlyCHOZEWW;
        SJoJrliGx += TCQJvkLhfuzbDcy;
        TCQJvkLhfuzbDcy = CJzZksiNGYsVBkno;
    }

    return FguFeb;
}

bool nNorbYn::jaqaOL(double CNNFUqWk)
{
    string uhrLwsxtjHcSqUA = string("ViambIuSThsMLfFcWdfskgJbcxItwUbZbdYJqpWhWLCAyiKesCGLnEsTyDTOnLjDKKahbypZefIdcDPLomXntMrTQlDyVeVZCQHindEIOUdDyAOlKONpzLCsbvPSBXM");
    int lQxMgqYDOIgEvmN = 606039166;
    int NcuGnVWbZGBB = 210988774;
    int rIxiAmqSxr = 388035825;
    string dALcG = string("ydcDgaPaudUSPcuWkAKcRjmnAWGWAcRAnrIfuOrBRPEsEEZlfUCFsTxIMkltQbLXKAdjVMDYOAganAtfF");
    double NelmJ = -613118.0963037555;
    bool eNTjaaYQIXV = false;
    string oLWetyVkd = string("ZwbUHYAlXhVqHIayPgAXoaMUDTaUeONeqAx");

    for (int uJBpPR = 1336471071; uJBpPR > 0; uJBpPR--) {
        continue;
    }

    if (oLWetyVkd == string("ydcDgaPaudUSPcuWkAKcRjmnAWGWAcRAnrIfuOrBRPEsEEZlfUCFsTxIMkltQbLXKAdjVMDYOAganAtfF")) {
        for (int VyScKpYL = 1203032327; VyScKpYL > 0; VyScKpYL--) {
            oLWetyVkd = oLWetyVkd;
        }
    }

    return eNTjaaYQIXV;
}

void nNorbYn::sIBzbi(int spbsIEMVUbmAxY, double EqAvznCZtHHbo, string wWbBXY, bool nEvLqrvOZG)
{
    int BhWYtgxgbyn = 1056366350;
    double EyJBnPTlrCCYvSBT = -443876.69797144085;
    string seUuFLAuwjkMuM = string("QsmYnbxNBpZlOHkAKLHQzYPonnOwgTbSxwkszeVwNLOWBUOJRdYkayvbnePPOwttwaJcPDrjqoHlYwrcYQdUveTQWLHqaqnqSRzKfxWdvtWwDgyLqvWAuYtrlgBsAQUzFIxpQdJVhnQWyWpAAwYKoHuTBtWileumkGCLZKABBmf");
    double ZENIBKXMkik = -650698.0343076095;
    string VMZrHJBBjIV = string("RsIcaLAyiYfNwkJRzUUlMavMNNljAmmyXJCSSqQgyQLxBCVMwVDYQDlTZchPvAecBLbXiRmrcMZcqxJltRFBVZwRtgLwlOQoEAzNfWtekEusMRpWGghDImCoQpOmcWeaDhZWvVAMSucbDaxIPjHUHMbNeZtYVNGHv");
    string PENLNg = string("dMUElGrqKWbuyeZMfYxUNBHzYzUjZViYGsZuKBHhxgZZobQYkYcDDSmtKJDbtjPjbKAfOgPHHYjmgWIwhGVadtUjLWgLHttIXRwBRLnaoACFijhIAAKQMJgZmuWwEZJcyHKqHqVKeqjVnXbFCtyRYhWFpRMIZhqebzDTJxyOHCrbGGezHUEcUBkHPkdJNRHhBzNMvfWpIVxHBtcfwUrJzXEmLeLyXyHQRPxkdsbHsxyYCSPkFwXU");
    bool ZQejOZxOjrBAKp = true;
    bool QpmiPBNwt = true;
    double QrRTEQzNg = 126431.88826280933;

    for (int nPBqMjHleUhmtwV = 1980161930; nPBqMjHleUhmtwV > 0; nPBqMjHleUhmtwV--) {
        wWbBXY += wWbBXY;
    }

    if (VMZrHJBBjIV > string("dMUElGrqKWbuyeZMfYxUNBHzYzUjZViYGsZuKBHhxgZZobQYkYcDDSmtKJDbtjPjbKAfOgPHHYjmgWIwhGVadtUjLWgLHttIXRwBRLnaoACFijhIAAKQMJgZmuWwEZJcyHKqHqVKeqjVnXbFCtyRYhWFpRMIZhqebzDTJxyOHCrbGGezHUEcUBkHPkdJNRHhBzNMvfWpIVxHBtcfwUrJzXEmLeLyXyHQRPxkdsbHsxyYCSPkFwXU")) {
        for (int olonhQh = 654305305; olonhQh > 0; olonhQh--) {
            wWbBXY = VMZrHJBBjIV;
            QrRTEQzNg = QrRTEQzNg;
            wWbBXY += PENLNg;
        }
    }

    for (int vBpvKJPpCgZr = 1468977770; vBpvKJPpCgZr > 0; vBpvKJPpCgZr--) {
        wWbBXY += seUuFLAuwjkMuM;
    }
}

string nNorbYn::hBjTti()
{
    bool LPHwQyalWVzYrQXH = false;
    string HhFMu = string("huofvpqzeaKJnNCRAaPMKDBcRjDopxcYVtQAATLfIrKiwizNiSUKjxlaeVpAjVwuJWgyHoXGjoaFWYsGvtOikvwbLbjrORXYRVsRlOauWJjlfBvRSKickAZvsWfjRQfOWsvhCJoAFHwzdGhhkRkbrnvKodqPzATizzwsIGSovPOAHRroNxzdTsXJdeKvOxYPUeOMuwsOatuNOXQoRcBLgcPOQGRhD");
    double FgDPxgvfXXJiJWcn = -282117.1098743439;
    string uCteqirA = string("sYhYGkVGfmpjnQigwUZDAlcGWAuGqjJREmcDDAEkCcDcsEUGbwKFOyEegZlNzQTayftyTPOVCHKPtpDWXnBbATCrCyIRHxoXFyrQHwgTlfBiapXxYBsKhZcHNoaAaBhbvPqUCqeNvLsVefkMoFhWREXJuMvMFbtQpQShQRrykpNmScmvAaWiDIteSrscvjhKZhTjJukgWfBpnrWKiKuffDPuPuaKspjccxgeBwSIYzz");
    string fxnIVGhqQdgq = string("oYInNLflNUApmAttiwbHjQbWLVtaoKaYDZIgeMpGeLrFKiFvojUbGuvrnZXlFOSsOoKvjFNvEnMmPUnyWVIvOZvAUPVoVEciZedpQrbI");

    if (uCteqirA != string("sYhYGkVGfmpjnQigwUZDAlcGWAuGqjJREmcDDAEkCcDcsEUGbwKFOyEegZlNzQTayftyTPOVCHKPtpDWXnBbATCrCyIRHxoXFyrQHwgTlfBiapXxYBsKhZcHNoaAaBhbvPqUCqeNvLsVefkMoFhWREXJuMvMFbtQpQShQRrykpNmScmvAaWiDIteSrscvjhKZhTjJukgWfBpnrWKiKuffDPuPuaKspjccxgeBwSIYzz")) {
        for (int PWYbKmUIgryWAGp = 1817491152; PWYbKmUIgryWAGp > 0; PWYbKmUIgryWAGp--) {
            HhFMu = HhFMu;
            uCteqirA = uCteqirA;
        }
    }

    if (fxnIVGhqQdgq <= string("oYInNLflNUApmAttiwbHjQbWLVtaoKaYDZIgeMpGeLrFKiFvojUbGuvrnZXlFOSsOoKvjFNvEnMmPUnyWVIvOZvAUPVoVEciZedpQrbI")) {
        for (int ozHvYLAabIHr = 698324037; ozHvYLAabIHr > 0; ozHvYLAabIHr--) {
            continue;
        }
    }

    if (FgDPxgvfXXJiJWcn >= -282117.1098743439) {
        for (int hkVpJxDPmHKJsyl = 518701422; hkVpJxDPmHKJsyl > 0; hkVpJxDPmHKJsyl--) {
            LPHwQyalWVzYrQXH = LPHwQyalWVzYrQXH;
        }
    }

    if (uCteqirA < string("huofvpqzeaKJnNCRAaPMKDBcRjDopxcYVtQAATLfIrKiwizNiSUKjxlaeVpAjVwuJWgyHoXGjoaFWYsGvtOikvwbLbjrORXYRVsRlOauWJjlfBvRSKickAZvsWfjRQfOWsvhCJoAFHwzdGhhkRkbrnvKodqPzATizzwsIGSovPOAHRroNxzdTsXJdeKvOxYPUeOMuwsOatuNOXQoRcBLgcPOQGRhD")) {
        for (int znsvsJ = 2089362963; znsvsJ > 0; znsvsJ--) {
            FgDPxgvfXXJiJWcn += FgDPxgvfXXJiJWcn;
            LPHwQyalWVzYrQXH = LPHwQyalWVzYrQXH;
            uCteqirA = uCteqirA;
            FgDPxgvfXXJiJWcn -= FgDPxgvfXXJiJWcn;
            HhFMu += uCteqirA;
            fxnIVGhqQdgq += HhFMu;
            uCteqirA += HhFMu;
        }
    }

    return fxnIVGhqQdgq;
}

nNorbYn::nNorbYn()
{
    this->FzTXnTZFslI(587647.0820990391, true, string("CmsSjfPgXthTCwPSaIvynBnjNrBSOyDJMCSoznjStggdrbvTQaDjgcetOSvjHEofqMPcREaKdQY"));
    this->GpQPCXukkrmPWb();
    this->PqiqUsgShDisGdiI();
    this->VIeWruPN(string("MpVUUMaYVUcomiQAaRux"), 1725483794);
    this->pMsjFG(-1554895467, 1360985328, 925169.9404287628);
    this->mhGzzFuncYiV(string("ZrSqEtDQfrmQaSSNvOGqxJyVTQbnb"), string("HOWNfyvHiYACIRbeFwFxXVVPkYEenzRjVLtJiESFqmCJtGNLklsAqGmhTfdQZJvMqGqprTZGUlQNspcRwUGoVnpPntpqPFnUiGdMTUnNbIACEDseqKioDqKbzSxAtXjcPMdDnkJqQJaAKGJBkKTxlUQGFyIWckLsGJFzvuSSyjBEOOsJlnkKIgQNPNoABPSxlxQOkQHYhxZmOLxuSSXHmHLJIAoLOyebrtxBvRqtAupZd"));
    this->svieGqkMVQc(963549.7987807867);
    this->hdNvMkOwkXcqp(string("zghfQBOCSxqlKaUVyrigOMlRYfrtmUYurXyMtUQyrhocHjgoCTOAVVVWLGuzQlBCFlUiOjkcEjBtmzrbeDVnOtVtfsnbfipveUZAiLExFdhXixauQJYeDQpBoNbkHbsDuyEjsdzUxSzzaQnWekSwayOtHdQtQPNyUrVWNmoaxIOaJweCCEJMVYGuSZfXoaRArzXMSjihZEpjPBSujjVZqbeoIMvirhJiUKUewsSAiLFpSbYapzyUPCjSDwlNyef"), 1760257323, 565442655, 953957.2813790498);
    this->qeVUBiMUy();
    this->MRCjAadywj(string("zBlwUYFnpomWRivSZUXWwABHExEzUSmjcFzetFLtZZbHydHYYdMBEXJlQXTXsAMpkxKyYLgsFOEYQLZiFIDplzIZDIDwPoBoxPKkAzerpGPiVhxlRmRiKmEvUjFlHopyyIioTxmyXzlGbvVKkaJaRVpsJStzRNbwJwjoTvvlYGNKSHgugg"));
    this->nRcNIiJ(-1471074982, true, 799734844, string("ZwtDotofvVqbvyTzhMlDDqaVixUZGkAZyhWcSLhOBrvZQAioznfRAIQCMbrUSaOVpSgipoqTwOlkoPuwXbtUoenmZjDwViYXGWPfVYVfMIRNsYQlsnmhlnTfqTvImKXjSvStgQzAcZVXTvnTDNbepjGufJZLFSnJvzyAutUdlFhHFTbPbTWnARAxrYJJLpBxHzQwX"), string("kxHNxlKJxBdtIcicSmAIpMkxNkbfBKKryADUTasydeoVSMXtMavgcJErKfkfKLjGWavNgItQRZxBUdBhDOKoXUlGhhBsGwqJRohlHigWlqOBkNjTQbyMOEbKeHvAccQNFoFhZRPgSndxAqPCWCdWHvZxsEEufGNaIsS"));
    this->kDqDQxswANqSVK(-351830.82545957755, -667584800, false);
    this->OXykZTHiyE(string("kXPjRfvUFDXIMOHAOGzcfGThTFlJBXgALJYukdoixyuJszkmsVVgcAptDHNWiWtArVVnYrzZNMPkdCFDotgvkxpHEFsjmhepavUqAeCWIsSENkMcgLvxM"));
    this->LZlkmpLzZuBgM(string("nOPOWBYzvyouvZLbcGVSVRbHPUJibvfOhrrkNBiuBqGMaOzThitlKchPgvKyvDJgHJHSKQDdhCZIsOvUBZKNqGWnolVHvqGGODCoSItcohRhLdAagCKgZvNtWiaLhiIWUgvczUIQjpeaGvxNbjtUNxnQEQOoXABeAVCKIjSpuboniboGHMyhmTFmxidcJudvdIzREJcnwAEOKpfeOIleMtaoDHMfFjRyVsTnlPPbcKUqLLUfpoUGB"), string("YAvarHJdEYnHdhxBruWwkGEhMhnLlXfEOLQburlVUxyjORRJQTywJthVHoxnYbhtUiecPxKdZXUuoqyxMBLdzttuztkErtwVFyrIQAChkewvBJlCzObJqAaOCLyNkrluFBksmcLdEmvUWIEECWWVNMOGuWlFsTqYmCzpYHoQNUatosxNsYVLy"), 1313504008);
    this->wqQhpbAOVKkKJi(700093.7514394161, -217713.32626764287, 172753.90268165528, 1029016.4271081757, string("GgEPLEtRaIchirzMEXZAdFPAtXAQxuHznQojWlHFixaeAZbQCDnSZvODMqprEnPViDuReMhLJyMNjNZhvWkhFYUwksFBgwYAJWqIMAUxAUpxfwTHKoaggxvjWCDubuNRtdVNAjENqmfRLNObSpsHYrPQfxK"));
    this->iAyImANfcoWBQ(-173883.91277525283);
    this->YHJcKNDx();
    this->YPqujMj(false, string("LvQLHuBNWPzUhphpeozoeQrdEBhMiwYJVtPZWcwYf"));
    this->jaqaOL(-976147.4892457989);
    this->sIBzbi(-1705963018, -558013.7925718456, string("OonkoZdXNEBaDPCtzHNvgsshmziXLHRixXcdZdhNzxFEDXdJqBSYVknPaLiYAvuJWBGeWxrDjkPvxVojQcfrROhUjyLxZLxPqwNgztPusVisOKgauujOmpYawGBoYANACIOcwzVfeDdnTfFCfcQRtYMwAbaVacmAGXpdphuCpZScdZncqKxaOiiHmwjJzTgJhRmjeXLFUNCstSwXNYptOB"), false);
    this->hBjTti();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gpPaBe
{
public:
    bool lUCwTUyHkmAudiY;
    bool xAPvkBgCwbUuu;

    gpPaBe();
    double fAAopTRBiUbrk(bool QaCQGGYx, string sqQOAy);
    int aiZXq(string eAMBtMPcbWaW, int pQFidiC, string pNvfb, string OWHYe);
    void zdjgYOOqTuSGp(int NPZHFe, bool cbneh, string CEOAoYNH, int YBnYtvtpPAvQKpN);
protected:
    string AsoTGBdn;

private:
    double IvFEkwZpDSTtXN;
    string ONdOcmsqaCcZ;
    int AWuShajxSs;

    void XANiCmmNijcIzHFn(int LMAnWUwxS, double OBmWAQBu, double SpeGevzEQkgft);
    bool QSbpoqgXLeacbYE();
    void RWfOIFqLASFobH(string iEXEvJYjVssq, int BtGFgj, bool lmiiNdhgw, bool EmkOJxEyELov, int eMTAMBeCPdEhfVft);
    double LxtmgJQkPChEVoD(bool cMXMEtFvne, double MOIKSZLDY);
    int MLPtDSLUJHY(double vpyuUb, bool aXIyBtLS, int MJJOVTvSyLA, string HWeWtsVTT, double IbhVZoHnZ);
};

double gpPaBe::fAAopTRBiUbrk(bool QaCQGGYx, string sqQOAy)
{
    double vAUzivGQ = -162958.25118598205;
    double YhGAfEDVuj = -765006.940031187;
    string WGxWTNcBfCHHfd = string("kNrvUKyDEDdbIAutougpcqBcnheiWeeKQWPfHAsapPiiILqVNWlGHvXaVhrJDmzRBjSbSHrsTsJRQfHdvATOOBQipdAQwXSRXmVYCxiaWUwsGUYnaLzCcMNfYcwQSjYNcipXqgRpdkXVHqJdZYDGbWjOqvMtNuRewtyDhLZl");
    bool vmaFjoksR = true;
    int VjEdZQ = 606894033;
    double OkNbinbNEFOeHeGf = 515898.0702406748;
    string TabJzNGFKuZsp = string("jUQSJxGGsZHJcDFmtJCthlczHbjOagQRgIhOAcijZJJxlxpVwHnffgquXIQThYulwCcutpNloTTRkx");
    double WXEGZ = 677253.5511694854;

    for (int azZtgXOJkcACFTZ = 1600836394; azZtgXOJkcACFTZ > 0; azZtgXOJkcACFTZ--) {
        continue;
    }

    return WXEGZ;
}

int gpPaBe::aiZXq(string eAMBtMPcbWaW, int pQFidiC, string pNvfb, string OWHYe)
{
    string eoPRLrhdrdRDmb = string("fCD");
    double FAVXgJafobQTUuE = 74873.18339478354;
    bool MoSiPAVX = true;

    if (pNvfb != string("ehcrPfdCrYVHZnacINRzwlpGrkffJnzANoQyllKXyfaXLYtfbzISXzqwGQNfLDTHCcXFBuDeMldtmEUcEteJUpZHhnJPOsezrpBAdl")) {
        for (int jtqYWKYjUhxIy = 1463222386; jtqYWKYjUhxIy > 0; jtqYWKYjUhxIy--) {
            continue;
        }
    }

    for (int WGazzRn = 1844638681; WGazzRn > 0; WGazzRn--) {
        eAMBtMPcbWaW = eAMBtMPcbWaW;
        eoPRLrhdrdRDmb += OWHYe;
        eoPRLrhdrdRDmb += pNvfb;
        eoPRLrhdrdRDmb = eAMBtMPcbWaW;
    }

    return pQFidiC;
}

void gpPaBe::zdjgYOOqTuSGp(int NPZHFe, bool cbneh, string CEOAoYNH, int YBnYtvtpPAvQKpN)
{
    string RLeBWDjWE = string("PwlYzGpnOToUUnDorCYzdfYXRTLDNRCiWihjunwnXueQFOkyikhfZwxgplQpXrdCWizoiyPfeUXBcoLtnbFrFPMEOulTySPBqJOSoiOlnlcHcqlNpiHkokBtUpQOlYhwcLAcVEFmFyuHrXksWzK");
    bool VTOmzOniXw = false;

    for (int ySBfLEpSwBot = 664327065; ySBfLEpSwBot > 0; ySBfLEpSwBot--) {
        NPZHFe /= NPZHFe;
    }
}

void gpPaBe::XANiCmmNijcIzHFn(int LMAnWUwxS, double OBmWAQBu, double SpeGevzEQkgft)
{
    double YUSvXhAPQftcf = -91875.29730013876;
    int IvqngxpVpyjYlGF = -5092576;
    double HGafqTpiFTYYLSDa = 1043148.8572821779;
    int BcXVkdpIJoF = 542536547;
    string JIqrVChpv = string("jmfBCIouFztCBYZmKuiMtqLvbjwQDFmmQwaitMRzvdGRHvryLBljTsUxibfbhNeOffqXwWcGYWvDZlDAeWut");
    string qxUfoqPJh = string("QlICgcNGvD");
    int JQviTa = 503211037;
}

bool gpPaBe::QSbpoqgXLeacbYE()
{
    double qbrSQQFcszXEuP = -139100.91301933196;
    double Bbcjqq = 110582.8629820393;
    double TEsEuuGHE = 309987.5199994967;

    if (TEsEuuGHE != 309987.5199994967) {
        for (int lhdSipibqUVyKPIH = 26296021; lhdSipibqUVyKPIH > 0; lhdSipibqUVyKPIH--) {
            qbrSQQFcszXEuP += TEsEuuGHE;
            qbrSQQFcszXEuP /= TEsEuuGHE;
            qbrSQQFcszXEuP /= Bbcjqq;
        }
    }

    if (TEsEuuGHE <= 110582.8629820393) {
        for (int AElTyzJGvDKP = 1970491864; AElTyzJGvDKP > 0; AElTyzJGvDKP--) {
            TEsEuuGHE += Bbcjqq;
        }
    }

    return true;
}

void gpPaBe::RWfOIFqLASFobH(string iEXEvJYjVssq, int BtGFgj, bool lmiiNdhgw, bool EmkOJxEyELov, int eMTAMBeCPdEhfVft)
{
    double HoHQEDgyUToLVPf = 755869.2417434208;
    string RubIBR = string("OPhQuvYQpTDpJmLlDkTOTYwrWfHkpJJFJTAxmtVoUmnvtZHjuoXQLzZPDRdMZLbnRHQLGqIMMWVkNRaZvLkzKDuIlGbPQQdzkZAjYvzsDhe");
    string mQajm = string("tOfaKAeEJgaJZVLYdapSAOtlQiZAq");
    double PdGzPkUzeJRL = -544846.159863867;
    double gozbyyaJbjDCXU = -246236.5549158444;
    double CiKjS = 477072.6227998382;
    double mglPdOSghIbngx = -1021250.7433597319;
    string boikW = string("spcAtCtkgdouwyakRpVt");
    bool oJjQA = true;

    for (int hAjKQQPdvoZVcPJ = 1582076674; hAjKQQPdvoZVcPJ > 0; hAjKQQPdvoZVcPJ--) {
        mglPdOSghIbngx /= HoHQEDgyUToLVPf;
        CiKjS /= HoHQEDgyUToLVPf;
        boikW = iEXEvJYjVssq;
        iEXEvJYjVssq = mQajm;
        lmiiNdhgw = ! lmiiNdhgw;
    }

    for (int PcfYOtqUkU = 1732977083; PcfYOtqUkU > 0; PcfYOtqUkU--) {
        continue;
    }
}

double gpPaBe::LxtmgJQkPChEVoD(bool cMXMEtFvne, double MOIKSZLDY)
{
    bool lbXdOPAEQNAndU = true;
    double CUQEZZMBkJaNkTkl = 451499.30449797877;
    bool utLoStrM = true;
    bool ORgkKiSffGLjL = true;
    int vNniKb = -1480147514;
    string JMLBHtEztAYp = string("IUAPHFwAfmoiDIJEYqtgRCJeyTDLZmklCyhXZRfJHpLNHnEKjSlhNdNSJXKVfGfKKNvJfTzwGncTxwKdxLKyLFrLwtdUnmnnOCCmSOBDfOIjlXccgzQLzXPlVANPMIulsVVXGLJBPGDHCusrwXeAGNytIBVGiLNikpaVZJhDGwxQUfckocfVF");
    double oKWaIlAwdep = 1017374.9593334718;
    string qjtoIFjrygvbin = string("nsxDzcxlycMqhcXRitdPtMGayHnELkffkwJQyCenqpWgpQxjarmvPLtNNCyOfmDGLhGcKbSHDvvEWwFjtpXBcoSGJwLQmNQRLGzmnSyWkWvpmbRoklmbYuOkOrToeAnzRBQzsrcdfsUbRWnPxaKxOuuqqdFQPUqeMQoxZkcizdLVWnRAFXyFAwSkSULMUqpWoJ");

    if (CUQEZZMBkJaNkTkl != 1017374.9593334718) {
        for (int OAayyRqFIxhdMCS = 921542967; OAayyRqFIxhdMCS > 0; OAayyRqFIxhdMCS--) {
            utLoStrM = ORgkKiSffGLjL;
            ORgkKiSffGLjL = utLoStrM;
        }
    }

    return oKWaIlAwdep;
}

int gpPaBe::MLPtDSLUJHY(double vpyuUb, bool aXIyBtLS, int MJJOVTvSyLA, string HWeWtsVTT, double IbhVZoHnZ)
{
    bool uNMXhENkiPfYM = false;
    bool uFwROChtHDMBqrJf = false;
    int KzOrIkbKnWJbPFs = -1600149149;
    bool FpGCL = false;
    double DgDjJjtvEMKt = -1010399.1395781711;
    string AMWjObRMnFOhtp = string("ZblyxFtVkXMTQpaUhuadSGQpkfUqxzNrYnDEORLwBhhKOaKhFxwbAhuhGBboDPHJJDmGEUxrAzqWaLrEHUjorKVLPYzmEkrikolBshmKpUyYsgHHYwxrRAFGWqsMjTkenvvYgrzfFaBrovSJamzZYCOVjTLpyfsrJBYcFBAPdZoOoiCGStIWoqatiBOwtZeQPGaoKdKkhFPUJpZcqScUGvrrLXQlqFfBmQyzokHaVcveYmExoxTdDzNUx");
    bool kiYZdtOFREwwJ = false;
    bool oxSgZccJdWCen = true;

    for (int EBQffbrheju = 1486813782; EBQffbrheju > 0; EBQffbrheju--) {
        continue;
    }

    if (HWeWtsVTT >= string("azmAjJeNYvytijasGsNuiRocFyXyrkrMRImUlzOBOUyTBXcqYpBgGbwHFZTCKkzGMNxkCVUnKKDhbRIQHwuntLwrVlMdvxCeOQRzWAHAdKETOBGYOyvGpnczkWajkhIMyhYVIyhjjyHIVZiKNTOYbsYjDbNprMVGInHHpDBySxfzvTAGwyteqauTuTlCWtOexSHwFRdkJbgsCpXIuQmjVFsLbYFLxOXhyrkCmsDxhTzyokIjoMn")) {
        for (int chpsQHMxx = 224814592; chpsQHMxx > 0; chpsQHMxx--) {
            vpyuUb -= vpyuUb;
            kiYZdtOFREwwJ = ! uNMXhENkiPfYM;
            uFwROChtHDMBqrJf = uFwROChtHDMBqrJf;
        }
    }

    for (int AauFyk = 856233010; AauFyk > 0; AauFyk--) {
        FpGCL = uNMXhENkiPfYM;
    }

    for (int fIqTZhTtEgxKF = 1727999939; fIqTZhTtEgxKF > 0; fIqTZhTtEgxKF--) {
        IbhVZoHnZ += IbhVZoHnZ;
        kiYZdtOFREwwJ = ! FpGCL;
    }

    return KzOrIkbKnWJbPFs;
}

gpPaBe::gpPaBe()
{
    this->fAAopTRBiUbrk(false, string("WQThvnXPSOGmUKUCneCpdxiSZZkIZPrXKRnlPFdCETTrebNcXnNBawqEQoeyeLZejIjnzmmXxJdkTjnWgmkSwfMeJZBLiKEVmiNrnJWpNxoQzAdQCEYKwfbsQamRhOjibhqGkMXNdRrQuzgPUMtCgDlBqIJHEHkZFvnrVDzLCkHCqDlGIkjUCLNShrlhJOTBqHUyvNgpdunsTLEzQBgOxQIlHfSdsoce"));
    this->aiZXq(string("oIeLBVtGpLLptwwluksXVjFkfADYaIjeefzrkmQwfxKzDYXLtGnsaqZaaodDSZwluXyJPfQeOimfSkLyVOPjeAKOxZHgjaTGrTClXoTsjvLrVERpbYLHcugGdJLgoVqYiLxCPOF"), 599500123, string("ehcrPfdCrYVHZnacINRzwlpGrkffJnzANoQyllKXyfaXLYtfbzISXzqwGQNfLDTHCcXFBuDeMldtmEUcEteJUpZHhnJPOsezrpBAdl"), string("MSrLbChEFlfbsaSNKUAhVAhZtxkcnSmuKwxxWYTfccvTSxkxlvqSLCBTeOGNNASBGGjSsKFfhDQJqXrxgmmQCxxayxdEyehjpGITDrGVGTcrQBGcfIEtzrGEBwqkDwJyrTgwrdStWPvfhtdCaBeinUsLzdtiiHVyHHsVjEbHItfyGcsgPfNctZqsaANMaRvVDWfyWOVvyRpiTIJoThkzMDYYCpkopBbjcvWEvnWYdrAblapEc"));
    this->zdjgYOOqTuSGp(-824417681, false, string("zZodywpbndCuaTRMmxTNNqynbIZPHfIHVSYNECroDEgwnXkKcVQGJCBWWgIKWsLSnZsmEiVLJDVaduZaKgmiXTTyxFWFoGxZH"), -608058704);
    this->XANiCmmNijcIzHFn(-1449032721, 780330.1569421418, 138345.70921395422);
    this->QSbpoqgXLeacbYE();
    this->RWfOIFqLASFobH(string("vnprWjXkFCQBQijYaphZsMCrfjkKIyyvlgwbYrBQdyVtMuLOmhvArqxZrfDMXpePsfagbFgJHZaqNyKIDDxqawIjUKfEeTGxROsAYooecPfYxoakHOFaDlBLAEFcDROQqmfKZoHLDTKglXUJYYVheJOfUxWRfDAQf"), -1521938478, false, true, 2060791883);
    this->LxtmgJQkPChEVoD(true, -258541.7002809503);
    this->MLPtDSLUJHY(429896.36666666303, false, 219835622, string("azmAjJeNYvytijasGsNuiRocFyXyrkrMRImUlzOBOUyTBXcqYpBgGbwHFZTCKkzGMNxkCVUnKKDhbRIQHwuntLwrVlMdvxCeOQRzWAHAdKETOBGYOyvGpnczkWajkhIMyhYVIyhjjyHIVZiKNTOYbsYjDbNprMVGInHHpDBySxfzvTAGwyteqauTuTlCWtOexSHwFRdkJbgsCpXIuQmjVFsLbYFLxOXhyrkCmsDxhTzyokIjoMn"), -795824.9262686092);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KUCdH
{
public:
    double wEHJjonREXrVd;
    string TayYvmsISqs;
    bool gTXgOT;

    KUCdH();
    string QipqrABPwWBy(int uzRMFcqeoybIL);
    double MTMdzmAvhmQ(string hcUNUSL, int SEXiOx, string sZegkmyrOZrn, int CGHPSg, int oFMOYgLN);
    void dCtWUzlOzgTKQ(double lVVswDTdMhSsYyP);
    string fUtfLSM(string tSOeboZtYIi, string AgWoEWjaAEZpVzU);
protected:
    string cgmHKGTq;

    bool uBcOwCLSem(double AVFuuXtb, double aSlllNjzxuc, string siDQt);
    int QJJWjqhaQSPLxO(string vjueHGPdBJLlLb, int ETDXiJjA, bool wWkYYmj, bool rufhtmFv, string laIFpVtyZHIZNise);
    int rtyEzgMg(double siBeDetrjbHAbt, int PuhWGMYuWX, bool jgAEIaesrMMSiEVR, string PdmBCjakQH, string csZYzfODGn);
private:
    bool kApai;
    double qsryiUDibankku;
    bool HryyxLFAgqgThNIu;
    bool ILCHrXQVMNXfjiY;
    double vLbSrvDCKWxKSpb;
    string hQWjLTaxov;

    double MdYGG();
    void eWFOX(int OlktTBSO, string bHlyHVyeIusw, double YtQqamvULvHprk, int NvAVXdVZGsGkWDn);
    double NusPFNgZNkLA();
    int iWEKKzxewK(double DTrYE, string MqSKIJiLrKPDsWo, bool rnNBShEsONpmlG, double VXbBGW, string SoEPmtILHFnejTR);
    string fUShaeYiR();
    int TCsUAzmeWD();
    void BUQCarWnDVlYebv(int stWctFt, int HpVxR, int olSjdQOOsmiUZ);
    bool vVDvFS(string iPnbsztpdowtZu, double YxSbBcS);
};

string KUCdH::QipqrABPwWBy(int uzRMFcqeoybIL)
{
    string eGrTqFjSrWZ = string("jcjdcXDaGYcrhwyFiZekqigQyfVcNjtMyBGEhfzQuzQyQllJnFOsbrXnlumwSLZYXtSUYxdAthfVZhTmGEUhSfRYXwZIgnYUzfThguchMhrjomjvwjiVzwFOYjSpkmoVFhLWLsdCoVgQunImQFUZBHYFEsAYCbyFgXdrEeoRWEANkdJHmEhaqilVbCDfccIaPlTgufsqrTWTsSNoNXgJLgEnFwwGnmqWpAhtxU");
    string rvaByTSCqNj = string("VRemMidaupAKiyqPkzNpolfOsNvOhJLQMUDMeSbLgNyfUPDHsgHgUQtMlWxrBJNZxWFZbyLFbprSWRcfjYfBkbrMOsBiqWWISwlypHJuafacXfoRoxhFlydvWKZMqWtSeAoKDGYvaGFGWCLrExYosxtiGXfbOgxwcSysjtBmOFnEjZTchahQMEMSSBlQIeRDNye");
    double HXNSmHnJpzlT = -810894.4461961293;
    double PhFNppcqFfreGvk = 142716.45903530915;
    int hlRnCPnubxPlH = -1060387988;
    double rFebhFOCy = -640793.4074483371;
    int xSfTn = -405760173;
    bool sjDYV = true;
    bool XPexsen = true;
    string WuzsALNsxPQySsa = string("wjkYNpCkLlKPIvcBtBKENfOKQddUsqvIzQTdKJDrFyJQXObuwALGYbjYpkILxpftrGAPjDLdJSutrvSAGObSDaphFsBUoWtJQHEWzZjDwNjTyBM");

    for (int JqNoAHwl = 1043067003; JqNoAHwl > 0; JqNoAHwl--) {
        rFebhFOCy += PhFNppcqFfreGvk;
        rvaByTSCqNj += eGrTqFjSrWZ;
    }

    return WuzsALNsxPQySsa;
}

double KUCdH::MTMdzmAvhmQ(string hcUNUSL, int SEXiOx, string sZegkmyrOZrn, int CGHPSg, int oFMOYgLN)
{
    double XYDXYat = -116145.10231596223;
    double lGBfR = -766191.4740380406;
    int evZggrgUBYt = -455777771;
    string BJstwJ = string("jWKUiwWmIAXVJErVDuRUkbFLqbdKrSXcYzWPuVoqmaJpfTWMoXhfLngRioCHaedJIaTKneBqOWLWxjxiAThLoOpBHFuiWeEokLHohCiGZJMI");
    string jPyBKQNPEOe = string("yDckVUlnXCumbWYvkerURIbZaTTQpoWeELfDqNnPvcCGOwzfIcQJUtQnXlmfqRhMftzpPl");
    int efxPs = -1480093516;
    double ALqRpGRwILJx = 232405.4270116465;
    bool KBRaEaYWvmQStCL = true;
    bool tTbpzecDuAJdC = false;

    for (int jWMfcoZocZKBXs = 1229862528; jWMfcoZocZKBXs > 0; jWMfcoZocZKBXs--) {
        CGHPSg += evZggrgUBYt;
        oFMOYgLN /= efxPs;
        sZegkmyrOZrn += sZegkmyrOZrn;
        CGHPSg -= evZggrgUBYt;
    }

    for (int RZUHX = 1588301444; RZUHX > 0; RZUHX--) {
        SEXiOx = CGHPSg;
        evZggrgUBYt = CGHPSg;
        hcUNUSL = sZegkmyrOZrn;
        hcUNUSL = sZegkmyrOZrn;
        jPyBKQNPEOe += sZegkmyrOZrn;
    }

    for (int TUSPGF = 1001516235; TUSPGF > 0; TUSPGF--) {
        lGBfR -= XYDXYat;
        SEXiOx = CGHPSg;
        lGBfR *= lGBfR;
    }

    for (int HMewwOdbOhKfAJb = 742246336; HMewwOdbOhKfAJb > 0; HMewwOdbOhKfAJb--) {
        continue;
    }

    for (int rTNzmGfOpeJ = 814422127; rTNzmGfOpeJ > 0; rTNzmGfOpeJ--) {
        continue;
    }

    for (int xzensfaIV = 1271590175; xzensfaIV > 0; xzensfaIV--) {
        continue;
    }

    return ALqRpGRwILJx;
}

void KUCdH::dCtWUzlOzgTKQ(double lVVswDTdMhSsYyP)
{
    double wGUAcq = -1011903.9294021585;
    double symYgNRedEdOzVo = -198952.3679986082;
    string aJtKXayvDRW = string("OxckhymKBkUiQnKMhCLjyjIVWuOAgygOmPrDeLnqLAuPOwwyIFqPtDAgEcdDZwzqjqIYmOoFzwkynJxrvPjkqoWztZTTtYbYjdPNIWRKecjfqlTzESMkojyI");
    int bpcEHH = 1360688161;
    int bKWWtcY = -143208334;
    int OkiptzpvrVSqM = -1214513867;
    double kdaTUJPk = 808533.7827537475;
    double oHcvYOKQHrnVLoOM = -833549.0985319627;

    for (int YNFVAbNmDH = 1098076103; YNFVAbNmDH > 0; YNFVAbNmDH--) {
        continue;
    }

    if (oHcvYOKQHrnVLoOM == -833549.0985319627) {
        for (int SBxgqUFCC = 1690294947; SBxgqUFCC > 0; SBxgqUFCC--) {
            symYgNRedEdOzVo = lVVswDTdMhSsYyP;
            wGUAcq -= kdaTUJPk;
        }
    }

    for (int yUhQvMLXjZlxo = 877920295; yUhQvMLXjZlxo > 0; yUhQvMLXjZlxo--) {
        continue;
    }

    if (oHcvYOKQHrnVLoOM <= -1011903.9294021585) {
        for (int OZVAJi = 274147954; OZVAJi > 0; OZVAJi--) {
            continue;
        }
    }

    for (int KyFsV = 754793810; KyFsV > 0; KyFsV--) {
        continue;
    }

    for (int jiTRmb = 526825038; jiTRmb > 0; jiTRmb--) {
        symYgNRedEdOzVo /= symYgNRedEdOzVo;
        kdaTUJPk = kdaTUJPk;
        wGUAcq *= wGUAcq;
    }
}

string KUCdH::fUtfLSM(string tSOeboZtYIi, string AgWoEWjaAEZpVzU)
{
    int nRmZvSbNxb = -1842165161;

    if (AgWoEWjaAEZpVzU > string("gQIEKfXHxMpsMbsadFeSseurChazLAoblbOELIqhvHcJzZfoFPDnTkciljgkMjZwQaFUsZTDVDdPtSCLOounkULAWBsCbobDZIQXTYdraGIfBzhMrgribTbCwpNStsmpHmIAsv")) {
        for (int YdjabGbnYR = 61964106; YdjabGbnYR > 0; YdjabGbnYR--) {
            tSOeboZtYIi += tSOeboZtYIi;
        }
    }

    if (nRmZvSbNxb != -1842165161) {
        for (int lstHNuFYtfy = 382066717; lstHNuFYtfy > 0; lstHNuFYtfy--) {
            AgWoEWjaAEZpVzU += tSOeboZtYIi;
            AgWoEWjaAEZpVzU = tSOeboZtYIi;
            nRmZvSbNxb /= nRmZvSbNxb;
            AgWoEWjaAEZpVzU += AgWoEWjaAEZpVzU;
        }
    }

    if (AgWoEWjaAEZpVzU != string("gQIEKfXHxMpsMbsadFeSseurChazLAoblbOELIqhvHcJzZfoFPDnTkciljgkMjZwQaFUsZTDVDdPtSCLOounkULAWBsCbobDZIQXTYdraGIfBzhMrgribTbCwpNStsmpHmIAsv")) {
        for (int PdcvPdsDHtuyZq = 1044104943; PdcvPdsDHtuyZq > 0; PdcvPdsDHtuyZq--) {
            continue;
        }
    }

    return AgWoEWjaAEZpVzU;
}

bool KUCdH::uBcOwCLSem(double AVFuuXtb, double aSlllNjzxuc, string siDQt)
{
    string mImaEH = string("agXBYYrXMiWTamvpBsbqxxKizsuOMHFbWcbpxFhcHlgYRFLVHDxxrUBvuwywMrSAjzrNpaxv");
    int leaPxsQ = -1229010180;

    if (AVFuuXtb >= 828586.2969462554) {
        for (int EFjpY = 790608415; EFjpY > 0; EFjpY--) {
            aSlllNjzxuc += AVFuuXtb;
            aSlllNjzxuc /= aSlllNjzxuc;
            AVFuuXtb /= AVFuuXtb;
            mImaEH = mImaEH;
        }
    }

    for (int djvgWrIIhurgj = 1868345810; djvgWrIIhurgj > 0; djvgWrIIhurgj--) {
        mImaEH = mImaEH;
        siDQt = mImaEH;
    }

    for (int EHQKJsZpk = 1842380909; EHQKJsZpk > 0; EHQKJsZpk--) {
        siDQt = siDQt;
    }

    for (int JMdPIhkmdnRxVrOZ = 254573645; JMdPIhkmdnRxVrOZ > 0; JMdPIhkmdnRxVrOZ--) {
        mImaEH = mImaEH;
        leaPxsQ *= leaPxsQ;
        aSlllNjzxuc /= aSlllNjzxuc;
    }

    return false;
}

int KUCdH::QJJWjqhaQSPLxO(string vjueHGPdBJLlLb, int ETDXiJjA, bool wWkYYmj, bool rufhtmFv, string laIFpVtyZHIZNise)
{
    int kRbFbl = -1991524887;
    int OkgxrElcqbuhWnw = -843067982;
    bool KBmBBKojr = false;
    double gnhHDsiBpmMoee = 890141.3161985638;
    int kKXkx = -1220386965;
    bool HkqMrQy = false;
    double nOGGzIrKJg = 110078.86672337509;
    bool qwuoJOy = false;
    string YGLQmziIIcvDgoD = string("OPoeQBjchOgnkxRSOQwMefXUSGtRTGxAxbeLcwxKHfcpFEDIDicnhzkLvstgVvtryEJpcGtRFSBQfWHUyHjdYukzfemNkJGvbYabKxxHvkmJoFhiuqqTJoIaMVElAkhKZTrOlsszNluIviLkruMHEwsIeeoOhDFWVLUjziTCwZRMkMAPLkGdIIZOAPcKTTkpDqFVLkkt");

    for (int kbQZWaXujUmhq = 1339612925; kbQZWaXujUmhq > 0; kbQZWaXujUmhq--) {
        continue;
    }

    for (int ydSGsOef = 648886739; ydSGsOef > 0; ydSGsOef--) {
        qwuoJOy = ! HkqMrQy;
        rufhtmFv = ! rufhtmFv;
    }

    for (int VsFXIrXAG = 404115008; VsFXIrXAG > 0; VsFXIrXAG--) {
        HkqMrQy = ! rufhtmFv;
    }

    return kKXkx;
}

int KUCdH::rtyEzgMg(double siBeDetrjbHAbt, int PuhWGMYuWX, bool jgAEIaesrMMSiEVR, string PdmBCjakQH, string csZYzfODGn)
{
    double EdWzxeW = -369389.2521706652;
    bool OKFgMkWbQdaHhrGL = true;
    string COZnVANHRLbIR = string("ZsYkwoEVYEJQUhYHZbR");
    string QADqwwrccwrqa = string("ymMIJbBFtPRyZWvmBHiNtODyhVVIBnPvltLaixyBFWzezIbtwppOtnybboKnnqjshtXwUbqMwkiHMtUXYYdnGZkhgJGgPyJDAkBwDcWkQFQaRNYsmFzYnjQQanSpZZIQwCZvagaKMWThzgqzlNfCnOfvTsGXjMdlMMgkxuOAWroQwCeyHBmSiMZdVvnwNAAhEqRRdUilFiRSslzRskefxYEywz");

    if (EdWzxeW == -369389.2521706652) {
        for (int zvAExSTWsbA = 2062574203; zvAExSTWsbA > 0; zvAExSTWsbA--) {
            siBeDetrjbHAbt += EdWzxeW;
            QADqwwrccwrqa = PdmBCjakQH;
            COZnVANHRLbIR += csZYzfODGn;
        }
    }

    return PuhWGMYuWX;
}

double KUCdH::MdYGG()
{
    int cZYJDD = -1040653783;
    bool DWYxdIxT = true;
    double IDQRbKQa = 625566.8766294736;
    int HRtLIQnF = -300459538;
    int RoLniIdyhPQ = -254186271;
    string tWoqGMBAoGy = string("zfTvpWukHMCHiMDCcqHFOmYcCGIveffWPWsHQKRSgVUhZtTDgVIOemzKZORLFrxVYEitbJtEKYftwcOOKgHyErKAWtjdTKNSLKbrcOfJjhTgogaSljgvOOExOsryeuddDOdDrjRXrPWpUaOepQnwkDdjNWSKKwRWhnbfiYacDNDFwPRpMJlhhiABqxDxRkfEeITGvgUcaesYEPEcHddGRdLYCsRFyVLvxBVIFAmR");

    for (int oOZVeBOXjnbFMZoj = 893057070; oOZVeBOXjnbFMZoj > 0; oOZVeBOXjnbFMZoj--) {
        HRtLIQnF -= cZYJDD;
        cZYJDD -= HRtLIQnF;
        RoLniIdyhPQ = HRtLIQnF;
    }

    return IDQRbKQa;
}

void KUCdH::eWFOX(int OlktTBSO, string bHlyHVyeIusw, double YtQqamvULvHprk, int NvAVXdVZGsGkWDn)
{
    int FRefxw = 1156175721;
    int lhuXYSNIiyUZRa = 1420360979;
    bool hVzAIhX = false;

    if (NvAVXdVZGsGkWDn <= -748816046) {
        for (int JcpjaRiEQJ = 1128076289; JcpjaRiEQJ > 0; JcpjaRiEQJ--) {
            FRefxw += FRefxw;
            NvAVXdVZGsGkWDn = OlktTBSO;
        }
    }

    for (int MRixzGqhF = 1308997318; MRixzGqhF > 0; MRixzGqhF--) {
        NvAVXdVZGsGkWDn = FRefxw;
        lhuXYSNIiyUZRa = lhuXYSNIiyUZRa;
        OlktTBSO -= lhuXYSNIiyUZRa;
    }

    if (FRefxw > 1420360979) {
        for (int ZESaTe = 518112885; ZESaTe > 0; ZESaTe--) {
            FRefxw -= FRefxw;
            lhuXYSNIiyUZRa *= OlktTBSO;
        }
    }
}

double KUCdH::NusPFNgZNkLA()
{
    bool yPzpVJtXu = true;

    if (yPzpVJtXu != true) {
        for (int ZDimBFowL = 1062947497; ZDimBFowL > 0; ZDimBFowL--) {
            yPzpVJtXu = yPzpVJtXu;
            yPzpVJtXu = ! yPzpVJtXu;
            yPzpVJtXu = ! yPzpVJtXu;
        }
    }

    return 325480.38813979813;
}

int KUCdH::iWEKKzxewK(double DTrYE, string MqSKIJiLrKPDsWo, bool rnNBShEsONpmlG, double VXbBGW, string SoEPmtILHFnejTR)
{
    double pvSepbDYvbY = 327759.83693110675;
    bool LASPmDjCWa = true;
    string TQbrMHfXBzWKpkNw = string("rzARaquyNhTaIbgivzaSvDVddYuDYtheJTBvtjVbBhhGCpHKhKMFtOKNmdhOsCipdprtAKEyyTfaSPXWyyWjTbQCoeYsessvMbOfQSEsoLnAPxmJtYeseFgZITDALPrIZRqzNqphSIrToMZRlcHinJpKLdzlmQBGMwzpelsqRutGgzUJJso");
    int vOcyQxhSsL = -667350632;
    int JUlkvmxIHKrDFHx = -90540746;

    for (int FqmzXIvrRc = 457957363; FqmzXIvrRc > 0; FqmzXIvrRc--) {
        SoEPmtILHFnejTR = MqSKIJiLrKPDsWo;
        vOcyQxhSsL = vOcyQxhSsL;
        SoEPmtILHFnejTR += SoEPmtILHFnejTR;
    }

    for (int QUzpoNwZBfCMgJy = 1387091072; QUzpoNwZBfCMgJy > 0; QUzpoNwZBfCMgJy--) {
        TQbrMHfXBzWKpkNw = TQbrMHfXBzWKpkNw;
        MqSKIJiLrKPDsWo = MqSKIJiLrKPDsWo;
    }

    if (MqSKIJiLrKPDsWo != string("rzARaquyNhTaIbgivzaSvDVddYuDYtheJTBvtjVbBhhGCpHKhKMFtOKNmdhOsCipdprtAKEyyTfaSPXWyyWjTbQCoeYsessvMbOfQSEsoLnAPxmJtYeseFgZITDALPrIZRqzNqphSIrToMZRlcHinJpKLdzlmQBGMwzpelsqRutGgzUJJso")) {
        for (int SfKfviIjqBINPZjj = 1685355787; SfKfviIjqBINPZjj > 0; SfKfviIjqBINPZjj--) {
            LASPmDjCWa = ! LASPmDjCWa;
        }
    }

    return JUlkvmxIHKrDFHx;
}

string KUCdH::fUShaeYiR()
{
    int iJlOGItusZzWZO = -857263833;
    bool ZhmhxeOriAh = false;
    double DuHWYvLUBJasMIb = 727544.5830347424;
    bool RjbosPHQPT = false;
    int WOZTsEXSrEZcF = 1813232136;
    bool YOGBdhlJq = false;

    return string("FJbAiJDDKACAyHJcHqJgGffSfTgJhLTYkjHRtoQbDIArmRyxIrHUvsJKcUxLULMCqi");
}

int KUCdH::TCsUAzmeWD()
{
    bool fMMVEwkMeKHNjrn = true;
    bool GsDiotMtp = true;
    double loqELiUYvwCPIy = -294844.3144436672;
    bool iLBBao = true;
    string mtfxmsB = string("eEZQZigYVwgOkLamnRpdLARWpBqGoIGTlbgBsRijanEidduAEildzIrNShOtnpzlcsSISJBTJvbmXycYtjNYArOrHRFxnbcBVNvWGBDrP");
    string GqhYvcqaEZ = string("xDFmKQJUsCueYzPCGhcubarfRuaFbfLpxEmvsyRRRdyjqgPTyYylojrMyVgNuJfrmnoZbEDPvMJhKDNfuqVREwopHIdNKajqoopkKqxgtsVDrYaKZBEByQkvVszmjIWeNbfCTMLftcNroeXlgqLTqLhpvDwuOjQKCVvbG");

    for (int FwgtPBLRS = 476868692; FwgtPBLRS > 0; FwgtPBLRS--) {
        fMMVEwkMeKHNjrn = iLBBao;
        mtfxmsB += GqhYvcqaEZ;
        GsDiotMtp = iLBBao;
    }

    for (int lfwyZqc = 562969331; lfwyZqc > 0; lfwyZqc--) {
        iLBBao = iLBBao;
        iLBBao = fMMVEwkMeKHNjrn;
        GqhYvcqaEZ += GqhYvcqaEZ;
    }

    if (mtfxmsB == string("xDFmKQJUsCueYzPCGhcubarfRuaFbfLpxEmvsyRRRdyjqgPTyYylojrMyVgNuJfrmnoZbEDPvMJhKDNfuqVREwopHIdNKajqoopkKqxgtsVDrYaKZBEByQkvVszmjIWeNbfCTMLftcNroeXlgqLTqLhpvDwuOjQKCVvbG")) {
        for (int cYTyHeiVvQSo = 2129955267; cYTyHeiVvQSo > 0; cYTyHeiVvQSo--) {
            fMMVEwkMeKHNjrn = ! fMMVEwkMeKHNjrn;
        }
    }

    for (int BVIvPcZZUU = 1466319420; BVIvPcZZUU > 0; BVIvPcZZUU--) {
        GqhYvcqaEZ = mtfxmsB;
    }

    return 1180715580;
}

void KUCdH::BUQCarWnDVlYebv(int stWctFt, int HpVxR, int olSjdQOOsmiUZ)
{
    double UeqIkfbZClomO = 986076.1793040852;

    for (int JgXTYWDThvsif = 1782338690; JgXTYWDThvsif > 0; JgXTYWDThvsif--) {
        HpVxR -= HpVxR;
        olSjdQOOsmiUZ = HpVxR;
        HpVxR -= HpVxR;
    }

    for (int lDErC = 340471940; lDErC > 0; lDErC--) {
        continue;
    }
}

bool KUCdH::vVDvFS(string iPnbsztpdowtZu, double YxSbBcS)
{
    int AdvcQjdAqPQ = 1217573836;
    double KNyPGJLA = 857225.9098774997;
    string nhcjWDvSr = string("vdVbSsTbNDuiyDQDQWgJiQaHzjGzjeGJkxhAyQKhWoaFozXhDUXMLkjvZepxvwQfAF");
    string rdOIQmfHDJOO = string("PhUmNHNcNslghtdRBnpZRmGPvIqdPbFASMlBmDkLdrdZnyecQsZ");

    for (int woRbnwwexPR = 172581969; woRbnwwexPR > 0; woRbnwwexPR--) {
        rdOIQmfHDJOO = iPnbsztpdowtZu;
        rdOIQmfHDJOO = iPnbsztpdowtZu;
    }

    return true;
}

KUCdH::KUCdH()
{
    this->QipqrABPwWBy(997623276);
    this->MTMdzmAvhmQ(string("TuKtMIBEeXEIsnTeBQWKnQtCUMPJigRohxRVSPhMPSixIWgKUCbgbPkJGvrLkgKMspjiggIvBCoazaIUWFVHnfznRwLgmvdYBFVx"), 861325350, string("ZOXqCIfUMuqZyuaWhIAgAQqfUyhnTmiDGwbdkFODtuJDHGVCyvFKdiFQkyJxjCdmnNJEpzgmDSgqCMvQSXGdHlRJpwTqBlzc"), 1012704827, 283163551);
    this->dCtWUzlOzgTKQ(-443084.34700527147);
    this->fUtfLSM(string("gQIEKfXHxMpsMbsadFeSseurChazLAoblbOELIqhvHcJzZfoFPDnTkciljgkMjZwQaFUsZTDVDdPtSCLOounkULAWBsCbobDZIQXTYdraGIfBzhMrgribTbCwpNStsmpHmIAsv"), string("cUyoaSySfSkiMAnlWnnyJSONSfsaFlrkYigcrLlqMdhLYFwcpgTpbBaKcesxMPcDEfZzxEjuTvfaCUKEFnlBTpwhoFKQlRfmaPUfPd"));
    this->uBcOwCLSem(828586.2969462554, 18028.50748583908, string("SmUWzsmRiLcQPljrvsXLfqfaceZIJlKruISukwoFytsRASEzVGxxAaclRkArqqPuuunmgGGxQzCxvkpEUNUhjweWHRDSyiUHxnKjXsBGIjfDFquGmMxgMtqB"));
    this->QJJWjqhaQSPLxO(string("iPLTRIPlPwKIjFENVtdLskLcrwarKWynoClxmctoaSqIoLPZiuIdXduYjXdoqaMdYwcNUeKAmNLuIicueAwbwKybwbvUUXTPSecMbTQZcfGkIAAkBAogHlTOsKmnEGUFYntkUFMfujh"), 382165802, true, false, string("cuyQaRFDQKubcZiLOqHcBXOVpWGboodLmxiFtKVXzicavYqyhcahcqSVLoSHnBBYHPQZBMWJoQWgFQLAcsuVqhapYLkEMbzxFaKJsuFqIfywYQqbhxhHntxHaSrbCPqQKpKtqFqJUEVJyjOhDqgAAgVbooqGlasxgoWXzVroNLtnZQThU"));
    this->rtyEzgMg(-950565.7175797155, -2019358182, true, string("mUCTYwTBJUmwK"), string("ePEhcJZRCTOJIZtscKBsaprwsPJRNXYNepUKbNhlNHjWevwsCZIynjWsaKUUfHVfRBsqJhOIgtTspNGXZMeyBfSpoOgLbJxylmqEBwROucBxeAwORLhPZCZfTLEsjIfQniTYymqEvWPhxOhqDjvDxkdeOhrpQYWixBEEvjWsxeztnkFOiEfsdTBgXubuNGELdRQERCCElBqlxTzevwfeqryRUFIuTicGLNyOpgPo"));
    this->MdYGG();
    this->eWFOX(-748816046, string("jTOqSLIsjJwmyOPQdApeOvEnydahxauaXgaJVaZStSBsHuSaVQSvkWBFCwbCJbkVPPLiSReFMUaXeNrwsPiWCEvgJEkEYH"), -500921.3450262888, -1539367376);
    this->NusPFNgZNkLA();
    this->iWEKKzxewK(-998264.6702395077, string("VNwTsrgFCQAsxkDwPSRYISksqgQijqZKEZYmZEAMxASSqRQRvfnJceoYclvWZxDbmMDqOiQMiqovUqvmbzmZMClshllxvoJqUPnTCXbRwbmqNHLARzg"), false, 67530.4032981667, string("VVloHZjCCOZCmGnMEyXtgTQpLpGbmiRTAqHIMgAHVuwbAcwqOayvEhUZjsetKlDFVVLOpMQmkLAVEXMCfhDsSTVBhogKSIbmnnzgHFiwuetkYJopLcCPWvONbWsmEQSRtPZxoYsUawYTfBHaxmKFklsmwFPcxAzHjlfhUXnCmLyCe"));
    this->fUShaeYiR();
    this->TCsUAzmeWD();
    this->BUQCarWnDVlYebv(-1430054786, 2102915756, -19991493);
    this->vVDvFS(string("DhhxUxunvWKsjMFgCaHpOQrzJxHlGQPNgsLyrJriyLxgfLlKhkcBSRhbUDCahveeQlWrpsYlmsDvruUgLogbDKlttqCQXhSdagsBBSkKYRKYTvjPJilTXzcEzHNUkzeeoFHZLtQZocOvpXcowOBRUXsnzzWxgoyCmn"), -265925.94792864355);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AseZjpJbvGkBAUJ
{
public:
    bool GHQlOQvmbyvHCeWv;

    AseZjpJbvGkBAUJ();
    string abMItWblWsBzm(double cKtbDLQDCY, double IVMUyEVkjm, double iTLCLDVlwnQooPeo);
    double HVyXbgkXQqdR(string VHzXhThkR, bool JDkLytvxlHywd, string wYgpHXKEfrAJd, int haqEEwqKQcJ);
    double aBvNZVgQQKjN(bool KbFmfhqRtWJ, int zHkDmS, double DIksA);
    bool MimLENhw(int CwThUBKCplr, bool FolWQtNAkJs, bool nIOKZbfvSAfnd);
    double KybTLYOMcNBIxo(double RSEVzMssovkbr, bool DFtfjoOthemfv, bool nzwdj, bool OXPZPqFvWSxH, bool HkqyPna);
protected:
    string yaBYsMt;
    bool ZcWkT;
    string KKBKu;
    int KnSbNIXHoS;
    int nmCwXnArmCeXmeZg;

    double XJpSOxWzVJv(double NhkWJA);
    string jFbVjGoL(double reUmIujaCJFQwFyx);
    string NCZRSoHyveWIX();
    void XBavSqshX(int KVicqrB, string cwTuBxPV, string oojWNgonRX);
    double dwrRzFIthE(bool FFcmRUTKUCdSoanq);
    void eyYtBniVhpyYDZJ(string xZpLMSPS, string zTRodqTzt, int RJCRlHv);
private:
    bool YKPPEHJeoSKgWwG;
    string egevkvUEcLCwK;

    int Rzzzucta(int OYLlosdgyrwDQMVi);
    void uoiOwytvioLQV(bool yEuriRcKWJlN, string gatsfMWpftcA, string lAvUqBVBNoaaP);
    double FOFqbguB(int JEpczYLJnANpUJ, bool VhHLEiWNHiPtlh, bool kKHRRxxUvMp, int jfRDKOJCMm);
    bool zzXWsTRMmwu(int UVCNLGZYiNdYULoY, string dQAEG, double Rokvsyrttu, bool XjjuMFmjODDQn);
    int xbtegpV(string OgALapqnVitq, double RBbNdH, bool KBArSd);
    bool NNSCkrdvaroTw(string FshKOSxdIABjrsev, bool tOEha);
    int gRawwjQ(bool lmsQtfOamjXf, bool uOTtJdz, string XIzlmNTmULf);
    int CRmUfz(double EzqYSzPOQ, bool YQhjFxq, double ekIWMBnyTomWWS, double LHBroKhXf);
};

string AseZjpJbvGkBAUJ::abMItWblWsBzm(double cKtbDLQDCY, double IVMUyEVkjm, double iTLCLDVlwnQooPeo)
{
    string HtbcJGdyZkzFvnmd = string("kxvBVujLnhKyLkduOYPIEnOfMOdSfIjGrgZVwlPfCTymKkCCNWNJGFXCXmzVsYkOtYhPXZsvbKnoTCiyQZpbiGOIKuRtyHywHbMuDMxTULQrOnDavLdcGMLeQBKkWJTAroaMLyPWJYknHAaiRKAmKAlYqUECcNdDzqRObngTSxDaEHUJYDbYOGUMYSLeeCQYKFYIqSPtZjZXavKgqR");
    string fQYcqhggVlrx = string("DxbxeJndmKyjDrRIMLIAbrsOcqBjyONdZyynhqAPLJfnjVXbXzrafERVBFDKVBIyfaGTCgWyBbVBixwEFnfiCdyCBzBVAuHKjzcPPhkBsndThkJUdRvfSVPLdesUKyeVqTOFeHMCDsutSOjHBEuUFJTAYiknVHOrOSfbUgayQdMoKFqDKdyWVpWdDHtGnbAJKIfqqSVTylq");
    bool unCqhGUXiJJOhy = true;
    string uxAFkxApDRldRQPs = string("kysFyztYPzbijhCDIvOvKsQrpLZSTcHtqoRKVVYEurmuFbtgAahmfwMBJLowDoMJwNioyHWMTLfqFnTDfwcKXJEuqTFOffQIHvwhisbPbZWmyXGYPdbabLwaByyqtBfeatLKTGIRylNDvSgBapXolVfeBZFxAitICalSnBKBoAbCHOqwnJIRnvmtSEjbEiPfZzmMkePetCBFHZnSaCDpjgwlXpdWevHZMjbPK");
    double NZEbkr = -333536.24398819177;
    double HyPQGLbhYV = 646631.1808277719;
    int MSwVBQQ = 997361396;
    string gZFTO = string("MSiwbnMdMnRdQLwDZIxSIsicshRlTTGIPVNkvayKZBeHVBTMvQhafdeOyiVVoNAGAlbXlNeZnPoKDvNBxHZGgylLKtTxaYaHVOBiTMDL");
    string KfIqpTxvGyvplT = string("SjdgXpAyBvjUaFoVjHrjdZAlaUvIeSxKfSmVyDYsDFQscQOTmakBzaIGeyfaIjFsCrugwRSXgRSggNicozIJvYgTyeaPrskNMdaRtocgxkyxrvcbownpmjbZbJBnjDLFxbgBqHNgiwPLXcaqaVAzrbGJtfBFAGjckOpmQpvddAyDaIuFVpNDrlQLekexwLxvqGkOoSmizijTJEHrAONjpJvLsXbognLNorQIpToEMjhYAsgWKQltMjuLqFKFg");
    bool uQeGJJdrdquK = true;

    if (iTLCLDVlwnQooPeo < 646631.1808277719) {
        for (int Mlhnvp = 1734361321; Mlhnvp > 0; Mlhnvp--) {
            NZEbkr -= iTLCLDVlwnQooPeo;
            fQYcqhggVlrx = HtbcJGdyZkzFvnmd;
            iTLCLDVlwnQooPeo -= NZEbkr;
            IVMUyEVkjm += cKtbDLQDCY;
        }
    }

    if (cKtbDLQDCY > -333536.24398819177) {
        for (int gdnojKBVj = 408691783; gdnojKBVj > 0; gdnojKBVj--) {
            unCqhGUXiJJOhy = ! unCqhGUXiJJOhy;
            KfIqpTxvGyvplT += uxAFkxApDRldRQPs;
            KfIqpTxvGyvplT += HtbcJGdyZkzFvnmd;
            fQYcqhggVlrx = uxAFkxApDRldRQPs;
        }
    }

    for (int AuxmznKdDPO = 1633729275; AuxmznKdDPO > 0; AuxmznKdDPO--) {
        gZFTO += gZFTO;
        iTLCLDVlwnQooPeo -= cKtbDLQDCY;
        cKtbDLQDCY -= IVMUyEVkjm;
    }

    return KfIqpTxvGyvplT;
}

double AseZjpJbvGkBAUJ::HVyXbgkXQqdR(string VHzXhThkR, bool JDkLytvxlHywd, string wYgpHXKEfrAJd, int haqEEwqKQcJ)
{
    int bMjsXfShVsrTH = 1776167636;
    double eguzKJZZIu = 937528.3581613745;

    return eguzKJZZIu;
}

double AseZjpJbvGkBAUJ::aBvNZVgQQKjN(bool KbFmfhqRtWJ, int zHkDmS, double DIksA)
{
    string ixPNVlgVRge = string("TsNohvxJcwxOZgoHLesXbQltaQbZMfFSfIjIkOrMtKzJxpLlIzjRXoautnkYIAYgldONcJIx");
    double NosmEDFyGluGJDOQ = -678161.2899663894;

    if (KbFmfhqRtWJ == false) {
        for (int EnPpJIAfHfWPT = 1305046158; EnPpJIAfHfWPT > 0; EnPpJIAfHfWPT--) {
            ixPNVlgVRge = ixPNVlgVRge;
            NosmEDFyGluGJDOQ *= NosmEDFyGluGJDOQ;
        }
    }

    if (zHkDmS >= 1375920195) {
        for (int mNgLRJOUDWI = 1534339300; mNgLRJOUDWI > 0; mNgLRJOUDWI--) {
            continue;
        }
    }

    for (int lQknMCVqRfy = 1259301010; lQknMCVqRfy > 0; lQknMCVqRfy--) {
        continue;
    }

    for (int ynritWPzrSkkjyi = 807515949; ynritWPzrSkkjyi > 0; ynritWPzrSkkjyi--) {
        continue;
    }

    for (int GVlmIsh = 460375265; GVlmIsh > 0; GVlmIsh--) {
        zHkDmS -= zHkDmS;
        DIksA += NosmEDFyGluGJDOQ;
        DIksA = DIksA;
        KbFmfhqRtWJ = KbFmfhqRtWJ;
        KbFmfhqRtWJ = ! KbFmfhqRtWJ;
    }

    return NosmEDFyGluGJDOQ;
}

bool AseZjpJbvGkBAUJ::MimLENhw(int CwThUBKCplr, bool FolWQtNAkJs, bool nIOKZbfvSAfnd)
{
    double xvDRsgBLgwLb = 699365.5804797002;
    string eDgHk = string("DujuCm");
    string kDQgMjB = string("wAkQGNQvnWxlGJFGhXtcXFaPUTwbyyWOaLjLgyiKWabGJgYhvOXyfPEclWwxuEUYXrhVbGFaNtcOrjHmvSZQrVpxWesSuCDaQWYZMswuaoLzYkbgTtKnBXjwwVCnlemFgwDpWKEOOPnMdmLhnUxhHffIxhdQfsSaeSHQGSiIVzvhiglfEJTJNKoYoRarjgYCqBgOqTtAuSidFYFEHalhYTUlvLPLqtspRoZ");
    string hpPsu = string("eivTicSjltURjRMaAqIyrmJnVHryUWfLIxiUvRKufmvEqTiuXhzVnwyOksSETjsQZUTkcdeZZJgwCDrWlrSbEGrrmSBAbsRSrETXsRArEjegzvqrmepuJzeCmXhGkDQYTjrfZsITSHOVxzhjMLjnXkBoRsBrtBncAcGumqZGcZEwfXOHRkPUAdIP");
    int TBqqdUGZAbv = -1248403216;
    bool iFtRKedhVK = true;
    double stezsKKkkQwMZxKE = 348072.48679392954;
    int DzkIUNwdezpKXUt = 579331522;
    double puJgiF = -733683.5985391265;
    string NlgkIskCZb = string("yopwcfkdkdagtAWMKvvNvqjvBgiAEXtucqDeKYRlQxtKItpnt");

    for (int muvqOsLjMYfI = 984386132; muvqOsLjMYfI > 0; muvqOsLjMYfI--) {
        kDQgMjB += NlgkIskCZb;
        hpPsu += kDQgMjB;
    }

    return iFtRKedhVK;
}

double AseZjpJbvGkBAUJ::KybTLYOMcNBIxo(double RSEVzMssovkbr, bool DFtfjoOthemfv, bool nzwdj, bool OXPZPqFvWSxH, bool HkqyPna)
{
    bool yISWErYzYSLtBitC = true;
    string PHYHhBEEOWth = string("UQsdfjpFgjrBzMayYTssXlOGYZBfRzCUzIMZwuZjbMuksPDQXAodUxzmkJYmpKmIzzeEdetkK");
    int vpBpuuVozGg = -533979245;
    string rEmTkXfwasT = string("ujtnLNvZDNyzhMXytPrMVEcdwbDdKRTYP");
    bool UxNETQys = false;

    if (DFtfjoOthemfv == true) {
        for (int DYBbDXAd = 260369879; DYBbDXAd > 0; DYBbDXAd--) {
            yISWErYzYSLtBitC = UxNETQys;
        }
    }

    if (yISWErYzYSLtBitC != true) {
        for (int fuiwPrkS = 449282145; fuiwPrkS > 0; fuiwPrkS--) {
            continue;
        }
    }

    for (int iJtJfK = 715440395; iJtJfK > 0; iJtJfK--) {
        PHYHhBEEOWth += PHYHhBEEOWth;
        yISWErYzYSLtBitC = ! HkqyPna;
    }

    return RSEVzMssovkbr;
}

double AseZjpJbvGkBAUJ::XJpSOxWzVJv(double NhkWJA)
{
    double ivFpRhWWUzQCBzK = -409793.6367831402;
    string KwsHDYd = string("qmZaGEQLGcmWVJnOeRkLiPVXSKloHPCaPhoNhWIRzonwyigtwZrORbTcKfLEqawieAOAQlQMuFIsmDBfGmdBUfbbyjdXKghVbTyGZqPHMRvFJEKjHMYNHqXZfLeYulhzRXub");
    bool eeqzFSIfZGKbEX = false;
    string DBMPbjyIPdTK = string("RlNlnZQmJqendEvLkicMHVEKjYKVajtOyasxMQdxtjEKqLDRIujchBKpHbEMvDMDjgyMNdIHEXYeEUJxjaHgTKAjeCRQnLoyopgdzKcwLiPhkojeuIRbkNWBOsXYgqK");

    if (NhkWJA == -409793.6367831402) {
        for (int SyulhADQHp = 274642313; SyulhADQHp > 0; SyulhADQHp--) {
            ivFpRhWWUzQCBzK -= NhkWJA;
            DBMPbjyIPdTK = KwsHDYd;
            ivFpRhWWUzQCBzK = NhkWJA;
        }
    }

    for (int HYzXZHJZTME = 1582293295; HYzXZHJZTME > 0; HYzXZHJZTME--) {
        DBMPbjyIPdTK = DBMPbjyIPdTK;
        KwsHDYd = KwsHDYd;
    }

    return ivFpRhWWUzQCBzK;
}

string AseZjpJbvGkBAUJ::jFbVjGoL(double reUmIujaCJFQwFyx)
{
    bool nsmnTwZGUS = true;
    double EGThLtISRWylt = 646661.4432358482;
    double ZWbhJdruyWmJvj = 711488.346914974;
    string UmmUa = string("EFnTksVJOdgBeQFrKeKzejYpe");
    double ugcWAzwhwJZgoo = 841540.4070233864;
    bool LXUmllnrMYdAj = true;
    bool rODzIGepEQGmvx = false;
    double hKXfK = 27058.39258261321;
    string uMssmucQ = string("UNbqBHzCSPwgprDafbVMPzBapQLcGIqryMQVJwlTRcNzWXmdYvKDQGWbndDbeqIUiKBbdOtQyVUwhlfZBNCxOlUMzmcVGhFyqLIffKDRNREvYsjNqWrPYquX");

    for (int QDoMa = 1128673289; QDoMa > 0; QDoMa--) {
        continue;
    }

    return uMssmucQ;
}

string AseZjpJbvGkBAUJ::NCZRSoHyveWIX()
{
    string jDDyTjtzBi = string("AWubwTeEzNimtWdShQfVkGsCMRrhZeNyAcHhgAPchhLxgHVNPjSKSidTxLSsqDJhvsbYbOyTxJDXQKUUzHyLulRtMaNXaBkqTfJeMagPHxNjSjJitmAurJAGQYvdaaKIHKSRZEuXzHNNTJzlfAfFluJGOyAxMcoDSPNxRfPIYSrxWSyCkyqLEGsquuccTkMIfcsZqbwXyricJnRknIHfbLMrralUwqsx");
    string QJFRyLRsyZ = string("WWBujtvOjFbsdtimrVDoypkFuSEwpVzTZbNlhVMuLQcHkelMXiVcyjulAxzYKTddIqZBlAYNMfGauHbByALTcGvqZPUilOstLXISZicENuvYNVRYNGCzxAqPWiCNkBpUGqKthWxkDOCzYxvYSDygtsSnghTVtBOrOPuTADsvDkJSXtOIYzfLGDoXVyoSUcJMIXVKPsy");
    bool WxpMBemsNjfPzRvi = true;

    return QJFRyLRsyZ;
}

void AseZjpJbvGkBAUJ::XBavSqshX(int KVicqrB, string cwTuBxPV, string oojWNgonRX)
{
    double hjauT = -894839.495658201;
    double tXLcwfbc = 1031138.0044351234;

    for (int PdEqJNY = 1576554251; PdEqJNY > 0; PdEqJNY--) {
        cwTuBxPV = oojWNgonRX;
        cwTuBxPV = oojWNgonRX;
    }

    for (int dlKljyYlNeYgO = 979215352; dlKljyYlNeYgO > 0; dlKljyYlNeYgO--) {
        KVicqrB = KVicqrB;
    }

    if (oojWNgonRX <= string("ccthUVfLXdzrxmWgyEQpvXLbMkchYScuQKbUYtxPAQwHujvWatEMoaiQznebTcxORLvzxkLpuzAvajcoovXyqAiYouFtjqhHLAxJnFbSHvOOykERGAwcblJrmGLiJmHMJKbtHeftWTfuZQCwacNNsfUJHS")) {
        for (int hHgXnYSoP = 58912772; hHgXnYSoP > 0; hHgXnYSoP--) {
            hjauT /= tXLcwfbc;
            KVicqrB = KVicqrB;
        }
    }
}

double AseZjpJbvGkBAUJ::dwrRzFIthE(bool FFcmRUTKUCdSoanq)
{
    string nABALSXTQtR = string("QlUjcgjvkcrJFCsategiirZgxhdagcmvNlJOlysbgkfbihspqYRbNJuObMLTzDMRfaYMoZryWJjhEXiaoKAmTNKbGGFKDcqKDFIAhYANwvZkcUmDhmXxNUahRqvipqjikNxSRDwXYqmDNveGfZTdJggrFqqufPqOrcmeMEmsxNmcoppLaCJCVgWLGRbGZsA");
    string fiASdgpAVRk = string("UEmuGaHlHwBxZLimnaSxSlIxDkMGihltFiCpXMPFDNgtYBuuQlhmuzelvbmNGqYWxvkSECOqPLEayIDVByPhXzxDboUDfKN");
    bool NnYDCJvvkPgBpKi = true;

    for (int dMLXzzQqJssL = 487994287; dMLXzzQqJssL > 0; dMLXzzQqJssL--) {
        FFcmRUTKUCdSoanq = NnYDCJvvkPgBpKi;
    }

    if (FFcmRUTKUCdSoanq != false) {
        for (int VxDUkCSrWubpp = 182999186; VxDUkCSrWubpp > 0; VxDUkCSrWubpp--) {
            NnYDCJvvkPgBpKi = ! FFcmRUTKUCdSoanq;
            FFcmRUTKUCdSoanq = ! FFcmRUTKUCdSoanq;
        }
    }

    if (FFcmRUTKUCdSoanq != false) {
        for (int oSVvSUutOfZgaM = 943435899; oSVvSUutOfZgaM > 0; oSVvSUutOfZgaM--) {
            fiASdgpAVRk = nABALSXTQtR;
        }
    }

    if (fiASdgpAVRk == string("UEmuGaHlHwBxZLimnaSxSlIxDkMGihltFiCpXMPFDNgtYBuuQlhmuzelvbmNGqYWxvkSECOqPLEayIDVByPhXzxDboUDfKN")) {
        for (int xjskjxuYZBXOts = 1043031290; xjskjxuYZBXOts > 0; xjskjxuYZBXOts--) {
            continue;
        }
    }

    return -756000.6561273296;
}

void AseZjpJbvGkBAUJ::eyYtBniVhpyYDZJ(string xZpLMSPS, string zTRodqTzt, int RJCRlHv)
{
    string pXDGOvdoQ = string("jIKGLgFYItQppcSAisLaQeqwvmXkfIcExXBmRufAHONnrYibuWuPabrCU");

    if (zTRodqTzt == string("jIKGLgFYItQppcSAisLaQeqwvmXkfIcExXBmRufAHONnrYibuWuPabrCU")) {
        for (int SVBSXlMYsehHyyP = 459250330; SVBSXlMYsehHyyP > 0; SVBSXlMYsehHyyP--) {
            zTRodqTzt = xZpLMSPS;
            RJCRlHv *= RJCRlHv;
        }
    }

    if (RJCRlHv < 318186425) {
        for (int FkePMmoozQXvuVWZ = 1890426783; FkePMmoozQXvuVWZ > 0; FkePMmoozQXvuVWZ--) {
            continue;
        }
    }

    for (int UmmawijEKcLD = 1413705278; UmmawijEKcLD > 0; UmmawijEKcLD--) {
        pXDGOvdoQ += xZpLMSPS;
        zTRodqTzt += xZpLMSPS;
        pXDGOvdoQ = xZpLMSPS;
        zTRodqTzt = xZpLMSPS;
        xZpLMSPS = zTRodqTzt;
    }
}

int AseZjpJbvGkBAUJ::Rzzzucta(int OYLlosdgyrwDQMVi)
{
    double MmBAlLKZtljhvH = -456341.9459567908;
    bool WynAp = false;
    double neSzHoqXSGBBEdQ = 333863.3672596035;

    if (WynAp != false) {
        for (int iumxvFm = 1547374146; iumxvFm > 0; iumxvFm--) {
            neSzHoqXSGBBEdQ += neSzHoqXSGBBEdQ;
            WynAp = ! WynAp;
            MmBAlLKZtljhvH /= MmBAlLKZtljhvH;
        }
    }

    return OYLlosdgyrwDQMVi;
}

void AseZjpJbvGkBAUJ::uoiOwytvioLQV(bool yEuriRcKWJlN, string gatsfMWpftcA, string lAvUqBVBNoaaP)
{
    bool CXOZRhXwLZ = false;
    double jnkccx = 1018536.7517664697;
    int KlPmCHjIkSuvmvoj = -2040427980;
    int TljeTYxCthdXNpeJ = -1546769389;
    bool ywWBGTtwqT = true;
    int tEVocgmOtULGq = 1595449129;
    int CIXyD = -1503137590;

    for (int DmtnOcYoUKa = 1934896378; DmtnOcYoUKa > 0; DmtnOcYoUKa--) {
        ywWBGTtwqT = ! ywWBGTtwqT;
    }

    if (yEuriRcKWJlN != false) {
        for (int fApVh = 1019708502; fApVh > 0; fApVh--) {
            lAvUqBVBNoaaP = gatsfMWpftcA;
            CIXyD /= tEVocgmOtULGq;
        }
    }

    for (int QRBlh = 656826215; QRBlh > 0; QRBlh--) {
        continue;
    }
}

double AseZjpJbvGkBAUJ::FOFqbguB(int JEpczYLJnANpUJ, bool VhHLEiWNHiPtlh, bool kKHRRxxUvMp, int jfRDKOJCMm)
{
    bool WKWWJx = false;
    string qTBPXbqjMsW = string("UumPbwtzegyMCvAiUqSymGMuNdHvMFNzpUpEYHFHDAhDNCOxpWghcHyMYnwVKBsfoXVZHLjbCzpQzKGnEvfRCQXHCAsTKzbulLhlfiluecqMNVUetwnkEHllcjn");
    string visMEqTAlqr = string("PFIzEjcLpVlnPMIUGIKTgklFwEZDgWtAXBIacXFQeLKlYIWFbNKNrHuxmkbaJbBtpbGcVcskgZYmrrQNHTayTEzNIREiDWDnWbJBfStdgdfkXGZdnjglHlwFEAKVCwkDQVbruZksLgqdlSxOdBzkmPIeQdLFdzrSLwuXVvzmsfZpzMfYSDqiqKNwYRRFemlPTLOjOaggmZTClOVwxTIuEnfQXMOYYVfVSjklvBemWIzwIPISII");
    string iJkGpInaTyX = string("AyJlnhTTfttAJxkHAYfQPHoXbsQLjVGClAXsiLhBAOQxpIjmWJGoeC");
    string zsPSiA = string("nwedCtREmkynQKneOkLubLWRwBvhaff");
    bool esfoKQ = false;
    string viqJq = string("nWUVUVACWSEmvfrdIuObnFzDZECBpzbyUNImCJwGLEJUrhrxTcoESQHeCRvbEKqeoKtwCnaNhAHIqidsaqHfapapkvAXtmpdOcUfkfbGQaerrAFJbaFpQUMADVbAChatuMSydLGkEMdCbkMTwQWFEqKn");

    for (int AGUNLmnQuAlcMI = 909930286; AGUNLmnQuAlcMI > 0; AGUNLmnQuAlcMI--) {
        VhHLEiWNHiPtlh = ! kKHRRxxUvMp;
        zsPSiA = qTBPXbqjMsW;
    }

    for (int ePuPX = 1189567683; ePuPX > 0; ePuPX--) {
        continue;
    }

    if (qTBPXbqjMsW != string("nwedCtREmkynQKneOkLubLWRwBvhaff")) {
        for (int YYgzoACoZbQqTB = 1744854989; YYgzoACoZbQqTB > 0; YYgzoACoZbQqTB--) {
            zsPSiA += zsPSiA;
        }
    }

    return -581871.4387284281;
}

bool AseZjpJbvGkBAUJ::zzXWsTRMmwu(int UVCNLGZYiNdYULoY, string dQAEG, double Rokvsyrttu, bool XjjuMFmjODDQn)
{
    double aMYoEVGWZu = 235322.28270273484;
    string ZfFKiMwroAnVf = string("YreqwylLuzDKRabSAWQViuXyoQSmmJJEZfDyxISfLGqCrfynHigaVVEPSAkLLFwtMBBoHvPDqwvjSKfQIiQSmHRksqcpMIuvTnEMDbjwAviGNuKOFrJrQlsWxujSqlqwNQDgKFmtvsvgbvFgFKNHaknjGJjDpmdfXdrOUaevyIUwcBgOMdgXnltZYapLJdqPoNnRMJYmYRoQFHJRLDengCOAxPLWGjjRrdIoEWugDEgyRUDmZHtrKvbyUiJ");
    double VmcYEXaAfRNgiHl = 240717.93497061063;
    double TduJIq = 247736.5965741028;

    for (int MNfdFxsJOkdrslGi = 1139005512; MNfdFxsJOkdrslGi > 0; MNfdFxsJOkdrslGi--) {
        aMYoEVGWZu /= aMYoEVGWZu;
    }

    return XjjuMFmjODDQn;
}

int AseZjpJbvGkBAUJ::xbtegpV(string OgALapqnVitq, double RBbNdH, bool KBArSd)
{
    string NbyevSqKNuaQNNcy = string("oaaKaXJQIXSbcmIdxHNVepSRXlsziSkrTjrekFpFqfeKJxHhPGFnSVKKGFSMuituISxGRkvvzFhaay");
    bool CUsDKMfqcE = false;
    double yhPimirtT = -719797.9974390838;
    double zvjYHLIzGJxJO = -549931.0898366515;
    double hyPjMiG = 112046.47497235044;
    bool GOzqxKuoqZWC = false;
    bool DMnLJuPwB = false;
    bool woAetusYGN = false;
    int COcMViyMmzoEl = -464440801;

    for (int mCReCmGCvIby = 983495714; mCReCmGCvIby > 0; mCReCmGCvIby--) {
        continue;
    }

    if (yhPimirtT >= -549931.0898366515) {
        for (int OKugjpuBcJWmIfif = 591451561; OKugjpuBcJWmIfif > 0; OKugjpuBcJWmIfif--) {
            continue;
        }
    }

    for (int BuHacedwk = 398520614; BuHacedwk > 0; BuHacedwk--) {
        CUsDKMfqcE = ! DMnLJuPwB;
        woAetusYGN = ! GOzqxKuoqZWC;
    }

    for (int QBRrqjvTDOziCF = 180477278; QBRrqjvTDOziCF > 0; QBRrqjvTDOziCF--) {
        RBbNdH += yhPimirtT;
    }

    return COcMViyMmzoEl;
}

bool AseZjpJbvGkBAUJ::NNSCkrdvaroTw(string FshKOSxdIABjrsev, bool tOEha)
{
    int tliiIWPpjg = 1876890392;
    string YrBVfSyDrIBs = string("SrvhSImLp");
    bool qOChMu = true;
    bool vAWJYOsHWPUGgTB = false;
    string NEnBQHR = string("FmDZoLFDXPEJniwNwc");
    double RzkTpktCjc = 890736.8465557358;
    bool smKjyA = false;
    int IAXDipHguzXD = -1979602877;
    string NLsWrOKIZQ = string("AgDXNtMRCqNEvxsIfHdjQFaUyOuIJnAbsoGgsGHSipqVXSseQFmYckkrx");
    int VhnENkDlnrxpJu = -1256680676;

    if (NEnBQHR != string("FmDZoLFDXPEJniwNwc")) {
        for (int oeNqqxUGhCwI = 1491925418; oeNqqxUGhCwI > 0; oeNqqxUGhCwI--) {
            continue;
        }
    }

    for (int ZVxdDehar = 25270059; ZVxdDehar > 0; ZVxdDehar--) {
        continue;
    }

    for (int kECuJUPPvOYMuyrP = 1211645677; kECuJUPPvOYMuyrP > 0; kECuJUPPvOYMuyrP--) {
        NLsWrOKIZQ += FshKOSxdIABjrsev;
        NEnBQHR += NEnBQHR;
        FshKOSxdIABjrsev += YrBVfSyDrIBs;
    }

    if (tOEha == true) {
        for (int shhwQyUgZkgcImWQ = 1496707311; shhwQyUgZkgcImWQ > 0; shhwQyUgZkgcImWQ--) {
            continue;
        }
    }

    for (int VrFyJPmssyIPIXjq = 640722381; VrFyJPmssyIPIXjq > 0; VrFyJPmssyIPIXjq--) {
        tOEha = qOChMu;
        IAXDipHguzXD *= tliiIWPpjg;
        IAXDipHguzXD *= tliiIWPpjg;
    }

    return smKjyA;
}

int AseZjpJbvGkBAUJ::gRawwjQ(bool lmsQtfOamjXf, bool uOTtJdz, string XIzlmNTmULf)
{
    int tkICS = 979266031;
    int bcPqVUiyMrhB = -756149885;
    string bsPZgQmoAn = string("BrtAFEXwJxIAKywZeGXlQBBxwOcLNQmOaCvyqThsn");
    double cTAXRAudo = 255632.94182679232;
    int ScDiAQLVsZX = -1991789893;

    for (int Yzpdwu = 651767176; Yzpdwu > 0; Yzpdwu--) {
        bcPqVUiyMrhB = tkICS;
    }

    if (XIzlmNTmULf > string("KJLXMmgaOQiDDMmzvVNaktrbTyIOWCNJwRaBeiwJGpSTUSdWMsbqADHejULAILFORDoGChfzILaIyncfHZmeXaCfjCYqOUfLYoxbbyXRzMCKQrlinkcepzMPqMnLuSZDWYorjONfiBDUgDGhcZNLxNWHPAoYnRcPeoOrLsdODHVn")) {
        for (int UQpVY = 1302797139; UQpVY > 0; UQpVY--) {
            XIzlmNTmULf += bsPZgQmoAn;
            bcPqVUiyMrhB += tkICS;
        }
    }

    return ScDiAQLVsZX;
}

int AseZjpJbvGkBAUJ::CRmUfz(double EzqYSzPOQ, bool YQhjFxq, double ekIWMBnyTomWWS, double LHBroKhXf)
{
    string ISSxFjyygeFZu = string("onLqTvKOMoQxoENqRVgapPPiyLchXXkIUiUiMmolDsLWvnqsjiNPekQCkQGevAVxpDTGxhkRafWYKwinTFuUdVXIKUZNVstMfOxseaErUKGBGUhPolXBdBEeobbAFGCzrrgOKMwdJDPIMNAbtLwtrLEjGIwFHSNfthZtHEgncobThIqgIbhwdNukgKUVxePsS");
    string eLtIlwVBBBLi = string("iUZnZVRjAuvVKIKVyBuAoLHzKsDborZpTXSUxqbeKvuFSFaBJZtItcZygshrnRNLSiRDKxWjXNrviEhQETeZlmslUMLNbsSQtEwZKosiRIfzEldSztQGHDsrfafHaaBQVnWkZFJxpmxuhjlzzvQWBSOE");
    bool OiytuAgKWOQsvqZ = false;
    double dSGoieeh = -1026661.4239625736;
    int sbnnyisf = 563884198;
    int lFTUyqiKEmAZ = 1381786106;
    int qMohGlZRwehwzSII = -801084704;
    int zXjImcmE = -505159561;

    for (int bIlXMBbFbmtqrVk = 1056224139; bIlXMBbFbmtqrVk > 0; bIlXMBbFbmtqrVk--) {
        ekIWMBnyTomWWS *= EzqYSzPOQ;
        ISSxFjyygeFZu += eLtIlwVBBBLi;
    }

    if (ISSxFjyygeFZu != string("onLqTvKOMoQxoENqRVgapPPiyLchXXkIUiUiMmolDsLWvnqsjiNPekQCkQGevAVxpDTGxhkRafWYKwinTFuUdVXIKUZNVstMfOxseaErUKGBGUhPolXBdBEeobbAFGCzrrgOKMwdJDPIMNAbtLwtrLEjGIwFHSNfthZtHEgncobThIqgIbhwdNukgKUVxePsS")) {
        for (int kiiSQIbbBLr = 127696932; kiiSQIbbBLr > 0; kiiSQIbbBLr--) {
            qMohGlZRwehwzSII -= lFTUyqiKEmAZ;
            LHBroKhXf -= ekIWMBnyTomWWS;
            EzqYSzPOQ /= EzqYSzPOQ;
        }
    }

    return zXjImcmE;
}

AseZjpJbvGkBAUJ::AseZjpJbvGkBAUJ()
{
    this->abMItWblWsBzm(340898.60701410996, 138356.3802129006, -446040.65898842656);
    this->HVyXbgkXQqdR(string("nBfPJocMzUgIBtidsbjXyGoAGjFNqcIkANPyhHrGjYidfOqfdRPCbvtFcdFvhHLGbXCoNXORfDNmdBzRxCzIQPOiLDOPVseNWyquiBoYrerKehMGyFYtriwhQrIdVSpxWaxzGxssSNknYnPmTZnzMdNTvJGkUgOkwhwagvYJRcjLxabEvDKVbhyqRcWxNYfRwiRpMXysaEiGiUYwxoFpScsGUrOOwSVLNVPts"), true, string("AdWETGFPAbQTDpZcHhoAkLutucXxribsrctEEvJBtnhwgopxJiWlrQWQvOitDymZKDAtGzgKVbxjzSoDHTNXjyODCcFEZEojHEQaZJGDvXBEdJRrCaWLffmiXVTKJETIcAPOKusQbkGqhMJXfCmDXEbrmkORETFDdFZkCEDw"), -1951369115);
    this->aBvNZVgQQKjN(false, 1375920195, -915709.1891464816);
    this->MimLENhw(37920562, true, false);
    this->KybTLYOMcNBIxo(-360918.1098051849, true, true, true, true);
    this->XJpSOxWzVJv(617072.0712648487);
    this->jFbVjGoL(-961769.4143932011);
    this->NCZRSoHyveWIX();
    this->XBavSqshX(1870644706, string("IKDxjzoTawWodCNrxQxDeNuKNgoxpgPmfZSKrDAsOKBQPVoapNthkPhwNPVOmpIydiDLWKUYRmdfuAXlYNSRdRfevWccMUwAsoXGarszLCdflPYoeqXkmIlCojOjQzZdEvoVKwODyabqmgiIXiXeuPnMUhkWfVekLicakrKzKVdEuxHOHneocCVfGVoWUoelcnHOuunnxLSlZmfD"), string("ccthUVfLXdzrxmWgyEQpvXLbMkchYScuQKbUYtxPAQwHujvWatEMoaiQznebTcxORLvzxkLpuzAvajcoovXyqAiYouFtjqhHLAxJnFbSHvOOykERGAwcblJrmGLiJmHMJKbtHeftWTfuZQCwacNNsfUJHS"));
    this->dwrRzFIthE(false);
    this->eyYtBniVhpyYDZJ(string("WnIaHwlsIXWgaYkvfmFJtaAljpQoiuMqdBSGrqCvmpJzPJNxxiAbtEMqNQbCLMxhZEsTMuapYGcDPCMwgQAPLWjzwSryUKpmWTogQrsLQXURagBKjScouXnpuWgFPaYGNxXkIdbSAfAwlDGqkMSLbxZfyLeFPWfriHBaRNpQdMZXFFMlQeVwTARPQJ"), string("XUiVveWhvDhpHHcpwsWditBGhKKvkKSKjsUQNibxXFwWglhWIZfSvxABqcHdtGSI"), 318186425);
    this->Rzzzucta(-1821382494);
    this->uoiOwytvioLQV(false, string("lvkMpMZZDmWYjIlByeETpYMzfVVQhJcGCwhWifUoMFwiucwFxjVZCatUAMXvQSyQDDpDAFvKnAXVNUgFuOjURpXpDNZlVAjsnIXetYDeITrVfKhJhFqZYRMYNJpLrMaTBOQGAXHpabQOoBaXVHlsduJhgvGfeFXtwPeJzcUhifmycVBYTtglbQctTqBtuMZhgeusuENurVoWxOAlLaHvAzaJOnfhQKSYUEvsXBDhjmJtOiOYfocSSjVdlZkaSL"), string("pUmiNmVERhHekqFmgIRjaeLvwpGKGNZQoEvnsRlvPRrQntoelNUuYpWUouYCnSRsjamFvmRCGaNOjIgcxsNRvhikxOXXLVcxqGJjeyKZUCJBzRWyYpBpLOGKZFgwFSpOn"));
    this->FOFqbguB(1249185042, true, true, 862701566);
    this->zzXWsTRMmwu(663810204, string("zHthkZmtRhkHSFxOqmuPXyMDxwIOUoiGztVZoWAQEerTjfaGbTpJshEWopvcWogEgjfwjgsoSuOXle"), 782830.7832048849, true);
    this->xbtegpV(string("yZaGKTgCcEDXmEqynLegfOislkicgSFtBnbiqpefpshcfvMOoNNwgIUwyJnZVpGkzPHmSNOFJradtLvrXpembvsisQebagcxZdxqbQsWYsEdPMpTkxRJxRBdoQhuZjruHjcbxWcNByyFvVAFSFFZmdVPTqxMJPEvKScCYaSGkbYHKYVVCBPAFZWwVQDtcJMxpPogMSvfTaITZpUBC"), -902190.7094953206, false);
    this->NNSCkrdvaroTw(string("gvNRcsEFyMLsPFuhmTZDazyAvaTCEjeIyinPdtmpndcGYBMAKsDWfIWJYrFkAvfcaPDpBHTgfjcxQAIQlAHRAeCnFKsAxmrqkpRJcVxNaYETBcvSmBMaDEyocCGBmWKbAnyQgQBEJaOYErmlqYTdQRtT"), true);
    this->gRawwjQ(true, false, string("KJLXMmgaOQiDDMmzvVNaktrbTyIOWCNJwRaBeiwJGpSTUSdWMsbqADHejULAILFORDoGChfzILaIyncfHZmeXaCfjCYqOUfLYoxbbyXRzMCKQrlinkcepzMPqMnLuSZDWYorjONfiBDUgDGhcZNLxNWHPAoYnRcPeoOrLsdODHVn"));
    this->CRmUfz(-672113.5112981774, false, 459835.14109695895, -342148.01578502887);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ibykKSvhbvgvCRVe
{
public:
    string AfckIIIw;
    double dQQhe;
    string yrquRbYeAmTvK;

    ibykKSvhbvgvCRVe();
    bool vktRJgsOlkbASZgt(int kizwMAUSkxC, bool FWMWGSvHCH, double dBgsY);
    bool zhfPEMGfRvIYa(double rumyvkl, double TYmoWwJCBt);
protected:
    double cZEkbAsQppYaa;
    double ullIEOJany;

    void aNPKnxSyrd(bool BHCskgobqK);
    bool QfuYQMFes(int cKZuhio);
    int VclntXpRchfZO(bool LMqtyCld, string kUGVvwkKAR, double fRfkHIfhlio, int lBHpOMdx);
    bool PcVXVL(int LKYCtDR, bool eKCibxSfeDUYas, double EswzgNi, double xrPcvankoOQlSCVP, int OAzKEcXEttherYq);
    void VyHaTm();
    int aaeEQQwzMJjBvL(string wWNedaBQTdePP, bool pSRZSLdLAvbUgBC, string oSGAs, double yNubZqNGNWlAEc);
    int AnRKlx(double GZEXeLJI);
    int imevlYB(bool sjtjZ, int ZISAUeGfIQQvl, string nASfn, double yUDJpezDj);
private:
    int tHrQgUYAymIRbvAb;
    int HEQKYqqh;

    string giteuTGoNKn();
    double qKwqGxSl(string kYnEuNkjlw, string BNwyrZNdktXqvtoC, int WoGbka, int CcGNcK);
    void oMlpnlrFViVlOXo(int lCBUQhflRtTLg, bool FbxjBf, int PhReWXoFlHuUDN);
    string EQxZRSDiYEnRbB();
    int XXrvSqOWKEC(double rZSVVbINDKMT);
    double DMnBPucLtnlTw(string uYQklgfwATIwg);
    int UjPZXPMejEkCRSY();
};

bool ibykKSvhbvgvCRVe::vktRJgsOlkbASZgt(int kizwMAUSkxC, bool FWMWGSvHCH, double dBgsY)
{
    double JvqDU = 743669.0469930074;

    for (int XmUVntwYgn = 159085135; XmUVntwYgn > 0; XmUVntwYgn--) {
        dBgsY += JvqDU;
    }

    if (dBgsY == 743669.0469930074) {
        for (int JkwYUDWIqGk = 1455088981; JkwYUDWIqGk > 0; JkwYUDWIqGk--) {
            continue;
        }
    }

    for (int jgBfncUjqU = 1579846339; jgBfncUjqU > 0; jgBfncUjqU--) {
        JvqDU += JvqDU;
        JvqDU -= JvqDU;
    }

    if (JvqDU == 743669.0469930074) {
        for (int CPxvnPVS = 1094315771; CPxvnPVS > 0; CPxvnPVS--) {
            JvqDU *= dBgsY;
            FWMWGSvHCH = FWMWGSvHCH;
            kizwMAUSkxC += kizwMAUSkxC;
        }
    }

    if (dBgsY <= 743669.0469930074) {
        for (int IkjTnMpDOdnvB = 829030942; IkjTnMpDOdnvB > 0; IkjTnMpDOdnvB--) {
            JvqDU /= dBgsY;
        }
    }

    return FWMWGSvHCH;
}

bool ibykKSvhbvgvCRVe::zhfPEMGfRvIYa(double rumyvkl, double TYmoWwJCBt)
{
    int xXfVcQAuGCTBALW = 1498832191;
    double eVxfoMIJUeen = -604174.6771564749;
    double AdxaNpU = -211123.51081979435;
    int tBMbHUkz = -742063659;
    bool sfVrAi = true;
    string aNaFN = string("tFZlQKchJvAMVlhMVneTBUBUJXoorHbtitIbPhwnvsatsmalhZwTPgUMrJkNmDThqyNAYNKEKFPLJMuophRpjlvlsYoDx");
    int TUFnwMbM = -788126176;
    int DrNloudsrlD = 209778462;

    if (eVxfoMIJUeen > -604174.6771564749) {
        for (int jIWuTRgIjF = 1749081625; jIWuTRgIjF > 0; jIWuTRgIjF--) {
            AdxaNpU += AdxaNpU;
            eVxfoMIJUeen -= rumyvkl;
            eVxfoMIJUeen *= eVxfoMIJUeen;
        }
    }

    for (int CwqHLiiOS = 1061919651; CwqHLiiOS > 0; CwqHLiiOS--) {
        tBMbHUkz = TUFnwMbM;
    }

    if (eVxfoMIJUeen >= -211123.51081979435) {
        for (int DdLLTNQERWw = 1889735213; DdLLTNQERWw > 0; DdLLTNQERWw--) {
            DrNloudsrlD /= TUFnwMbM;
            TUFnwMbM *= tBMbHUkz;
            eVxfoMIJUeen *= rumyvkl;
            TUFnwMbM *= tBMbHUkz;
        }
    }

    if (TYmoWwJCBt > -604174.6771564749) {
        for (int DRcAihvVpgOb = 489897059; DRcAihvVpgOb > 0; DRcAihvVpgOb--) {
            tBMbHUkz *= TUFnwMbM;
            AdxaNpU += TYmoWwJCBt;
        }
    }

    for (int thSMZakoNsQpOpP = 1475641210; thSMZakoNsQpOpP > 0; thSMZakoNsQpOpP--) {
        DrNloudsrlD *= TUFnwMbM;
        AdxaNpU /= AdxaNpU;
        TUFnwMbM = xXfVcQAuGCTBALW;
        rumyvkl += AdxaNpU;
    }

    return sfVrAi;
}

void ibykKSvhbvgvCRVe::aNPKnxSyrd(bool BHCskgobqK)
{
    int OTjKPMnaLxao = 1326729598;
    int uaujfJSvoCJ = -2026348438;
    bool QEreA = false;
    bool PCrLklveZBsqd = true;
    int QLrQGmEhJyg = 1210906675;
    string ZUiaBjrCylMmAJh = string("sPoGVuoZdlwKb");
    bool qTedLDMiFQNqjyi = false;
    bool sQcjXAAMP = false;
    string hRmQEBb = string("DLkCiIFudpwWTVZEngkvOXUvVnQHDfUpcWrBGbBazpuuqzpvMJFJYkUTilkqOXlKOTEBlArHPNLPPxUYvKAeFOPBfsrkFiGycqYRPoGrtYQbsXaDVZUxAtpCRJscMgCjLoQvTqVQMeRprXtdOmAssiaG");
    double hNSavLscwctOk = 749906.2976933194;

    for (int UlWlO = 711196058; UlWlO > 0; UlWlO--) {
        sQcjXAAMP = qTedLDMiFQNqjyi;
        sQcjXAAMP = QEreA;
    }

    if (OTjKPMnaLxao < 1210906675) {
        for (int WBubRHb = 1124517532; WBubRHb > 0; WBubRHb--) {
            qTedLDMiFQNqjyi = qTedLDMiFQNqjyi;
            QEreA = ! qTedLDMiFQNqjyi;
            OTjKPMnaLxao /= OTjKPMnaLxao;
            sQcjXAAMP = ! PCrLklveZBsqd;
            qTedLDMiFQNqjyi = PCrLklveZBsqd;
        }
    }

    for (int EkeASmgKEhvkxOAz = 1275110393; EkeASmgKEhvkxOAz > 0; EkeASmgKEhvkxOAz--) {
        QEreA = ! sQcjXAAMP;
        QEreA = PCrLklveZBsqd;
        uaujfJSvoCJ /= uaujfJSvoCJ;
    }

    for (int GCpfQZnYUdgulI = 783307964; GCpfQZnYUdgulI > 0; GCpfQZnYUdgulI--) {
        sQcjXAAMP = qTedLDMiFQNqjyi;
    }

    if (hNSavLscwctOk <= 749906.2976933194) {
        for (int QgYuMCH = 2042288206; QgYuMCH > 0; QgYuMCH--) {
            continue;
        }
    }
}

bool ibykKSvhbvgvCRVe::QfuYQMFes(int cKZuhio)
{
    string DRSMpYmDuHO = string("FRkUpDsJCXZpElprTbPeCcI");
    double tDutzbkzABLZn = -218461.92609649934;
    int WIXEwKqKu = -2114239242;
    bool UxFxsRAdbACvoIk = false;
    double HeZMgBvCfbNXctcU = -186628.96630627167;

    for (int ovKhqcVTNop = 306428645; ovKhqcVTNop > 0; ovKhqcVTNop--) {
        DRSMpYmDuHO += DRSMpYmDuHO;
        cKZuhio = WIXEwKqKu;
    }

    for (int CvEyT = 104804665; CvEyT > 0; CvEyT--) {
        cKZuhio = cKZuhio;
    }

    if (tDutzbkzABLZn >= -218461.92609649934) {
        for (int kagSQrrAWsd = 47759018; kagSQrrAWsd > 0; kagSQrrAWsd--) {
            WIXEwKqKu = cKZuhio;
        }
    }

    for (int qIscGPTTIxdRLuPW = 166702505; qIscGPTTIxdRLuPW > 0; qIscGPTTIxdRLuPW--) {
        continue;
    }

    for (int kdNssFFCGHoAXxOF = 536201361; kdNssFFCGHoAXxOF > 0; kdNssFFCGHoAXxOF--) {
        continue;
    }

    if (WIXEwKqKu >= -2114239242) {
        for (int HXbfpBcJx = 143289913; HXbfpBcJx > 0; HXbfpBcJx--) {
            WIXEwKqKu *= cKZuhio;
        }
    }

    return UxFxsRAdbACvoIk;
}

int ibykKSvhbvgvCRVe::VclntXpRchfZO(bool LMqtyCld, string kUGVvwkKAR, double fRfkHIfhlio, int lBHpOMdx)
{
    double feFiPsxdzGPbldVX = -841680.6642200536;
    int uaKTWxyhL = 516583466;
    bool AEiOuhJHAKCRS = true;
    double fMBdD = 353841.91133729956;
    bool YlUhgQdrLHYeLsX = true;
    bool qvYdExeBgmYdbjHk = false;
    bool ojpKqg = true;
    double QPhdBbkVBrx = 1027637.2413049107;
    bool SykcgeoUTqaWScxu = false;

    return uaKTWxyhL;
}

bool ibykKSvhbvgvCRVe::PcVXVL(int LKYCtDR, bool eKCibxSfeDUYas, double EswzgNi, double xrPcvankoOQlSCVP, int OAzKEcXEttherYq)
{
    int cbFsWBL = 8485197;
    int jLvTNmhUCh = 975689204;
    bool vWLBcDHUpeZh = false;
    int IFbxLfzinfYSgOPl = -958418181;
    int npfJsldz = 651818378;
    bool zvNIskjcCp = true;
    double AmhsAYik = -1002728.6163668284;
    string ldiASzkyU = string("laqKvLcMsaOiBOyQaGipwNJPuwlDSfVaQBpCDaXXewapUgimMzzoOF");
    double XDdLITFsyczTafvv = 578084.2034006144;

    return zvNIskjcCp;
}

void ibykKSvhbvgvCRVe::VyHaTm()
{
    string BYYlzRLHQo = string("mPDqSIxkXrCxpNZHqqUpxwOFptdaJizCEwlgWtAMeJrqWTsQlvuJLlxNSDmsBnGRUWAmdZpCpQPflgSCYVXKPtfEJXXnzSDjeMDGhEYdLOuEpTnLcgaFJLxoPnJIxSJyKOEcOThPCTPRrqoDVfIQLEB");
    bool SircWKQDteWNoh = true;
    bool jbQlg = true;
    double ftPzlDWcdhVsm = 190654.57781782112;
    int nRrSc = 1166307443;
    double nBvtVp = -978985.786180721;
    double JjeNDGFln = 313630.9389936653;
    string OpXBIzHuKWv = string("ZdQHBAYACsYUohRkPrTZoRNVppfikejqSMZRjWFOwOKCnkUQgEHQPEPqUGizHzJPcoElwtfMKRthzndHEEwRMzSQYGyo");

    if (JjeNDGFln > 190654.57781782112) {
        for (int JXZhPUvqZpt = 1205501620; JXZhPUvqZpt > 0; JXZhPUvqZpt--) {
            SircWKQDteWNoh = jbQlg;
        }
    }

    if (nBvtVp != 190654.57781782112) {
        for (int rPPrTciM = 540992272; rPPrTciM > 0; rPPrTciM--) {
            JjeNDGFln *= ftPzlDWcdhVsm;
        }
    }

    for (int HnPjSrFXhrFcYBV = 2097491464; HnPjSrFXhrFcYBV > 0; HnPjSrFXhrFcYBV--) {
        continue;
    }

    for (int TKrMinXaPNLR = 1881552393; TKrMinXaPNLR > 0; TKrMinXaPNLR--) {
        ftPzlDWcdhVsm *= JjeNDGFln;
    }
}

int ibykKSvhbvgvCRVe::aaeEQQwzMJjBvL(string wWNedaBQTdePP, bool pSRZSLdLAvbUgBC, string oSGAs, double yNubZqNGNWlAEc)
{
    int sjwvP = -1133329620;
    bool szQVXwpouK = true;
    bool jlcxSSrZcBGEn = true;
    string QZcKHBJDrYgkQM = string("SqyGyrQPFaOCIrcsXdPoPVbRKPugNeaqwMoiJVSkPvaTwqoRaRuhbUYoZORHbJClwCcRoAlpVXGKoUbqxHAummMAuaDoZujsqQKknOYsLOphuRjHdoPzSJUMcRSdXeRCXnvsreTCWHWDdyUUDXJkwvhKpRIvgszX");
    bool qjiBoshGVAmSNI = false;
    int ibaxD = -846957095;
    int JWsiCmWSDmfX = -1686239915;
    string aXRDSyVcbKBdBNb = string("ZjAwckzUJvQmVyuBWxUIWBSOLIGguwi");
    bool hSvYRWtwwRt = true;

    for (int DRKckTpe = 1060951980; DRKckTpe > 0; DRKckTpe--) {
        pSRZSLdLAvbUgBC = szQVXwpouK;
    }

    if (jlcxSSrZcBGEn == true) {
        for (int OKkqEbYqDcmWUg = 867826697; OKkqEbYqDcmWUg > 0; OKkqEbYqDcmWUg--) {
            continue;
        }
    }

    for (int CSAFrFPYQoQeSQqy = 131219408; CSAFrFPYQoQeSQqy > 0; CSAFrFPYQoQeSQqy--) {
        continue;
    }

    if (QZcKHBJDrYgkQM != string("EjOPOOwFvyvkegaImPLwImGIqSztMuvmOMyjfFfBotlMMYeaQBbjL")) {
        for (int qInRV = 222739623; qInRV > 0; qInRV--) {
            wWNedaBQTdePP += wWNedaBQTdePP;
        }
    }

    return JWsiCmWSDmfX;
}

int ibykKSvhbvgvCRVe::AnRKlx(double GZEXeLJI)
{
    double ekcGei = 494972.9036335143;
    double BghlghQn = 567974.4769635497;
    string gBYOJWlqXSNj = string("QRbVSuIDMyAGAfGEFsQVSZJJuPwKWJTpoBxwufAcGRqjcHMfnPrMMRKIImkJktbpoOfqybnsH");
    double ZifUwUdewheU = 233555.74864837216;
    bool tsilHXSEcK = false;
    double jDYjFfauup = 927435.3165520368;
    bool ZUttyHLWHt = true;
    bool YJrqCaLrgF = false;
    bool IpzIXcBePfBOwPkY = false;
    int pUteCZcVLexe = -1940997820;

    for (int QgTyiMMmRh = 1019395085; QgTyiMMmRh > 0; QgTyiMMmRh--) {
        continue;
    }

    for (int XZEnOWFPwuiBD = 290061323; XZEnOWFPwuiBD > 0; XZEnOWFPwuiBD--) {
        jDYjFfauup -= BghlghQn;
    }

    for (int ijdywPvbYgtHk = 993542864; ijdywPvbYgtHk > 0; ijdywPvbYgtHk--) {
        tsilHXSEcK = ! YJrqCaLrgF;
        GZEXeLJI *= GZEXeLJI;
        tsilHXSEcK = ! YJrqCaLrgF;
        ZUttyHLWHt = ! YJrqCaLrgF;
    }

    for (int NpRYcZfvEgL = 1211192286; NpRYcZfvEgL > 0; NpRYcZfvEgL--) {
        ZifUwUdewheU *= ekcGei;
    }

    return pUteCZcVLexe;
}

int ibykKSvhbvgvCRVe::imevlYB(bool sjtjZ, int ZISAUeGfIQQvl, string nASfn, double yUDJpezDj)
{
    string LjTwDAnnIYsqc = string("kWitEOQ");
    string GxcgtDJgBlON = string("McTmxpMFQsMgKStSfsDkHDxWXiaXARrehPKIwvAWAwlGTJpZmbLbZkyxJvokkYUWCEkHDvjGWSVLaLCJRvggWqQDliLPulNEOHDSYpJdNclMCmzyqWodgGYMIbcQLlLkciUTzLfziPRrckfpogWpJaOtBdmPOmRcGDmoTDMrYGTUSxXuuOliyJOOfozdgCIWELhJooTRuBfWtoHLvEqdOQXcWRWRtffHoTdbZVhCnrhDvGFLFfmbRxFOCpYjZ");
    double qBXeaholYPYWn = -442174.3944390597;
    string ipdNjZwUSwNy = string("yRLfPrrRqgtwyEqOVr");

    for (int mXeEVmhpiiZe = 2077050470; mXeEVmhpiiZe > 0; mXeEVmhpiiZe--) {
        GxcgtDJgBlON = ipdNjZwUSwNy;
    }

    for (int fVJmStVIGRTQYly = 887575832; fVJmStVIGRTQYly > 0; fVJmStVIGRTQYly--) {
        nASfn += ipdNjZwUSwNy;
    }

    if (LjTwDAnnIYsqc != string("yRLfPrrRqgtwyEqOVr")) {
        for (int hNlhRZuOagsMBH = 328506097; hNlhRZuOagsMBH > 0; hNlhRZuOagsMBH--) {
            qBXeaholYPYWn += yUDJpezDj;
        }
    }

    for (int lkfyfshk = 56225657; lkfyfshk > 0; lkfyfshk--) {
        continue;
    }

    return ZISAUeGfIQQvl;
}

string ibykKSvhbvgvCRVe::giteuTGoNKn()
{
    double MFQNxZgWTWolcmG = 434310.36412319413;

    if (MFQNxZgWTWolcmG != 434310.36412319413) {
        for (int upPEHWdUzVdqobZ = 591217668; upPEHWdUzVdqobZ > 0; upPEHWdUzVdqobZ--) {
            MFQNxZgWTWolcmG *= MFQNxZgWTWolcmG;
            MFQNxZgWTWolcmG /= MFQNxZgWTWolcmG;
            MFQNxZgWTWolcmG *= MFQNxZgWTWolcmG;
            MFQNxZgWTWolcmG /= MFQNxZgWTWolcmG;
            MFQNxZgWTWolcmG += MFQNxZgWTWolcmG;
            MFQNxZgWTWolcmG = MFQNxZgWTWolcmG;
            MFQNxZgWTWolcmG -= MFQNxZgWTWolcmG;
            MFQNxZgWTWolcmG /= MFQNxZgWTWolcmG;
        }
    }

    return string("rLTgUBQsSEPjEaDZOCbjiIwFLYaaLziRDLqIneSdgpqDtbAhjJDzeVNiovuLepnxLsVCOigKwIZRUpNwYRwrWfjqTMwwnzyLKiUDbLhwFNyTReDqCidXdkjBXrOcLoyzZMpVc");
}

double ibykKSvhbvgvCRVe::qKwqGxSl(string kYnEuNkjlw, string BNwyrZNdktXqvtoC, int WoGbka, int CcGNcK)
{
    bool jcblNYP = true;

    if (CcGNcK <= -1834015467) {
        for (int WhESDssz = 1877337491; WhESDssz > 0; WhESDssz--) {
            continue;
        }
    }

    return 951502.8962412449;
}

void ibykKSvhbvgvCRVe::oMlpnlrFViVlOXo(int lCBUQhflRtTLg, bool FbxjBf, int PhReWXoFlHuUDN)
{
    string xorZv = string("D");
    int jkHUYBbrOL = -910363911;
    string xwFUEmBQcqzhOc = string("SsXPKfBXhSgBMGhOcSv");
    double dAnReSrjb = 653577.2295852747;
    bool GokdhlTtxfhH = true;
    string enlTLmLbQyoWG = string("KOYhJOHzCrLjWmJetxNSNcTSUoKnaKMueqHVatQaKreOmzVrdvenZKQRXBeNzVZnKwBRncb");
    double ydYZCtDND = 797665.70291691;
    double ggGBzVYTvGR = -892686.5379082933;

    for (int lMxpbKdakfxqrq = 1417616700; lMxpbKdakfxqrq > 0; lMxpbKdakfxqrq--) {
        ydYZCtDND += dAnReSrjb;
    }

    for (int yLeXmwyeHB = 2140313567; yLeXmwyeHB > 0; yLeXmwyeHB--) {
        xwFUEmBQcqzhOc += xorZv;
    }
}

string ibykKSvhbvgvCRVe::EQxZRSDiYEnRbB()
{
    int rgUKKZTw = -1544661694;
    double bBgPhqmP = -32396.724322463167;

    for (int tNgnHacJ = 309965514; tNgnHacJ > 0; tNgnHacJ--) {
        rgUKKZTw += rgUKKZTw;
        bBgPhqmP += bBgPhqmP;
    }

    for (int gbxCJRyZudycvUyF = 1496735838; gbxCJRyZudycvUyF > 0; gbxCJRyZudycvUyF--) {
        rgUKKZTw -= rgUKKZTw;
        rgUKKZTw = rgUKKZTw;
        rgUKKZTw -= rgUKKZTw;
        bBgPhqmP = bBgPhqmP;
        rgUKKZTw /= rgUKKZTw;
        rgUKKZTw -= rgUKKZTw;
    }

    return string("hlWotZhGDPaXvpNubXqRUhvtBrbVIyqSaAPwZpxLYLNiXniQqcNLzwNAqeakKIEdyPXOqFaOLcJONXcXcfSPxxmLkLlwZngtcnuQzipBENleZtUTHxbwvwsKKPmThbTOtqkqqgWKcZSTvhaVfZLZlLaDXleDYpoPsxXQvBNQxvwdFBJYEawnJhZFicFNEXSUNXboxGdAFTGKfbAUUoMvXZZLwWXQiDZFrcSdwjECdIOlTmXXlYyDV");
}

int ibykKSvhbvgvCRVe::XXrvSqOWKEC(double rZSVVbINDKMT)
{
    bool SlRFqkVFBL = false;
    bool nELBJUwFn = false;
    string BqWWaJpQtWJMt = string("gkUXFKSengGAcrMnnNkexilYgoHEHgFLLRgkjLRKWrHRRpUcqbMLsPhGgYtPONgqDoKdrNLHtkDQlRiLKBftOqAVfpZHJqTqcmyAjBLEDCLRlmwWWOGyYKtMxdNriQbcahqNpxLYpwcakcdohaEoZCOETgWtEyDeKSkENQRKgiKEHLrKJrqdqGKyS");
    double TDBTRyN = 376821.62876367033;
    double UEupUjDolWTCSa = 473314.36821359064;

    return -1309399061;
}

double ibykKSvhbvgvCRVe::DMnBPucLtnlTw(string uYQklgfwATIwg)
{
    double hWLesPmuJNwGINJQ = -595380.7126477517;
    int SJjqXv = -909049079;
    string tmTgQteaOJHrD = string("qacgoNXzIWbppvKIhjPMKfgjsZPpPfkccJxfedUlNmiWAZyTcScJERgTyZLYeIpfNtmWKBifvhxDYhRcUWQsKZnNiGizCB");
    bool ZECveaxXm = false;
    int oTTiclFxTnbyvip = -1446653613;

    for (int wRyctugEpRSpMnE = 1592309601; wRyctugEpRSpMnE > 0; wRyctugEpRSpMnE--) {
        SJjqXv = SJjqXv;
        tmTgQteaOJHrD += uYQklgfwATIwg;
    }

    if (uYQklgfwATIwg != string("qacgoNXzIWbppvKIhjPMKfgjsZPpPfkccJxfedUlNmiWAZyTcScJERgTyZLYeIpfNtmWKBifvhxDYhRcUWQsKZnNiGizCB")) {
        for (int QDbGRJtz = 1879018405; QDbGRJtz > 0; QDbGRJtz--) {
            SJjqXv -= SJjqXv;
            oTTiclFxTnbyvip /= oTTiclFxTnbyvip;
            SJjqXv -= oTTiclFxTnbyvip;
        }
    }

    for (int lfrGZLDKOmtriEnD = 1374269725; lfrGZLDKOmtriEnD > 0; lfrGZLDKOmtriEnD--) {
        SJjqXv = SJjqXv;
    }

    if (ZECveaxXm != false) {
        for (int SPoiru = 330662539; SPoiru > 0; SPoiru--) {
            continue;
        }
    }

    for (int AcfRMubqjSTs = 59538584; AcfRMubqjSTs > 0; AcfRMubqjSTs--) {
        oTTiclFxTnbyvip = SJjqXv;
        uYQklgfwATIwg = tmTgQteaOJHrD;
    }

    return hWLesPmuJNwGINJQ;
}

int ibykKSvhbvgvCRVe::UjPZXPMejEkCRSY()
{
    double GUgdt = -975906.3221860551;
    int pGHIJ = 1661166225;
    string DQqHDEpPiMJZFSO = string("ENGyqXBQQETwZsZbmHuLilB");
    double EIjcBRysh = -54387.656341272785;
    string EoRrcopisWyWCw = string("unwlTMUhLKvXH");
    int zByLl = 1516191184;
    double zAkMniJLkESjtsR = -410453.045540325;
    bool fKJGpyM = true;
    string ERAdklNkm = string("wyLQUbncwhoBSPnxyERBLnZMZwbHPZqeMdelwAaIsMWYTAReaJBKi");

    return zByLl;
}

ibykKSvhbvgvCRVe::ibykKSvhbvgvCRVe()
{
    this->vktRJgsOlkbASZgt(2050861731, true, 187130.5056638048);
    this->zhfPEMGfRvIYa(496339.12368465186, 1042442.4861178319);
    this->aNPKnxSyrd(false);
    this->QfuYQMFes(-1052768014);
    this->VclntXpRchfZO(false, string("UmqOUwiRurwCKOVIBqYUfozNVjSWRcdgbfJOWfzNvrMd"), 413850.0265150768, 1327617578);
    this->PcVXVL(-1486970281, true, 384929.4691350757, -776216.8889850356, 1451983012);
    this->VyHaTm();
    this->aaeEQQwzMJjBvL(string("EjOPOOwFvyvkegaImPLwImGIqSztMuvmOMyjfFfBotlMMYeaQBbjL"), true, string("yOWihmbgRtTlLxCchPKIqPYjygIcWYbpWqOZoUgTDLKWVVvNVlidrfVFSJKHeWUwPHJOWsCPZuCNfppVGDzaMQcpIYCNkGqboROPeiZMQUieTRmzaGUkIrIghXBVlGVyuxCWncA"), -900946.4130910124);
    this->AnRKlx(212055.57446681065);
    this->imevlYB(true, 875370146, string("RAlzLwMtlgdeXqXzKrgNcwiZzxnyGYtdmqOYeiVVrFvDBCBvozqGDLAlGgHAuldzuroQmburvPgwEBvmHpdVKGrPYQAWZptyGUmjPnOmFffHHvdHoWSJtrOrzdTxMotjSn"), 143440.32937446947);
    this->giteuTGoNKn();
    this->qKwqGxSl(string("rdAnxHCuHEopuwOtqtumhygztlOAhcZyQvTPQYljpKLmtPcMHbLiqYqDjWmRlIWymbhDYwPuJsZPsMdimLK"), string("BcsMxfoXQZPwiBabnIoNhZCJnSVpLNeKokqzPNItGtcOBSArpOAusnDnRTrTqxiNdFoWgxiqdJZpcnJAWpeqGMcKGhekBRdYVgNMJldGsdKLCqbPYOPvOYhYmWLnOFfQmaPPhGNwWhr"), -1834015467, 1609939818);
    this->oMlpnlrFViVlOXo(1161500553, true, 2011828788);
    this->EQxZRSDiYEnRbB();
    this->XXrvSqOWKEC(-967921.3711519989);
    this->DMnBPucLtnlTw(string("nNNypQBCanYmXSnEulObktbjlEFklhXqSXchcqYxyjhOPMzsVxAmQXYskLrYSzqagbjdhDxrCMopdOjeSKCwtKqajtGLjGwbskyYiJiHOEsymaqRVKATeCwnuZjbGwbkNFTrzYqlClHRDjRfeyZkpCSmsWGOGioOZYCHrJQaHBtduELtsWgNNoSYjRbulDMSGeLQgIGSeGDyWlExsPmRbfKKwyjlRWvmBezEHYhRwtAyCFxMgYj"));
    this->UjPZXPMejEkCRSY();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ndbhnFf
{
public:
    string tSSXOmyyDMUy;
    string bNwqphkIAmMu;

    ndbhnFf();
    void mgAeRGUmyDOOyBj(string zthVi, bool soERfKrrwuD);
    string fvRXDtD(bool OidreDIs, int uLXxfMJtLmsBOw, int nBTtHQKfjT);
    double lYuViMVRehElo(string gEEfgN, string rmEymzZPldcCOdb);
    bool yZjEieMZInx(bool bSoiYYh, string PCgbCr, int cinmsotwLQPgLE, string rHQGQsJYdLoWND);
    int sdGAwijwuRewCF(string hNDxX, string UjSDWUKKEdFhJeg, int KRXRgoLIYluvrYxX, string UOgtkESWltdH);
    string ikRTX(int xdHvKItNfo, double JcZaw, string jKSrnYKkN, bool dxVfGhszqJTtXh, string EFEiUUU);
    bool WdsLxcwWAROx();
    void MuALLVDSuJiwyHRt();
protected:
    int NFMPorntpLVJNx;
    int rujLQbZCkFyAkLc;
    string CXUdfT;

    bool YemdXQGOUr(bool ntgoQNPfaUkG, bool iqtTEsx);
    string ggWyAxKJV(string ZWSVOA, bool nBPMbRmPJxwJWBn, int SsEpLJyHkcUvtV, bool KyqIF, double nRKNNtCcOsmzrRF);
    bool ZpcqNLg();
private:
    string hIbSGocwh;
    int odopUOHKWfCoTJeT;

    bool cMuRLCgwTyo(bool EQertnt, int ouIoHYhjrSN, bool aeWFnH);
    string xFlHbqsoPQdyUUvt(int XreNETObqWQuSr);
    void SXiiZguAINW(int XpPspFjzv, int lvzTExGdOZL);
    string mapngtjsL(double qQIRBbFH, string CmRkOJO, double ajHryvIvWg, string AjdpPsaqOzQAMrPd, string CDzSViVxC);
    bool TmxlCf(bool SsCvHfIZzOXgG, bool lgFEVcjLCBCZz, double oNlTfJblj);
    void mGaMbEYZ(string OlIrLIJxrNLTC, bool BxNTbxhm, string Jrhnfldg, string XzBlV);
    double DzsxQjnLzoMOt(double zsLZPrhtQZJyWi, bool bvFglY);
};

void ndbhnFf::mgAeRGUmyDOOyBj(string zthVi, bool soERfKrrwuD)
{
    bool CFCMXgQcEG = false;
    bool LDiftuwkgGGBu = true;
    double choOP = 240201.98587984507;
    string MkibABA = string("cmHUmkdXTmSsTxalmkfAYsEDDskVWIKMHKivXIFpfHfuxdxuaxARYIHVeooBuLwJHxwlWaNhbceZhnTdSNDzxXWJtcZGKolkYXUTtWenORDRFuKkfqkGybuXwcZqHIDZJCxadAlcadVgaeLOBvQoazCynVwTkPMrxnskxynHnmRgfvhtfzngndRNjBUOPbwsZhFJHlLlmLVQiaCkpbhyD");
    int NFGakUgTaSnPxKMV = -1403623735;
    double bSytuFGkvMxJfD = 883344.9094172494;
    double ZBwmZpAc = 35463.58656181511;
    double OKmhkhCueRy = 820735.891128282;
    string FBuab = string("AhojYTBLmgBDRsVIqPSAtgocVEIfCJcCcjYkCwMKiBTfoAozAnovIQikROPxaEqBdtskKzPUTTfMlpZrXwLeUPacABdDMVsNXwwrnqbsOmoOiWqHlNKrvokWAwIpLrGqaZNaSULpHtAnwvRftmYBrONDVdjFpOAYeIWnBLUBiRUxLlFRHJuRqHLSUNRrYRTygWnkOPKcIRVsQXZZldtqLqFlBcxebNYYOKxuHLhjzzjXhYzRCpaLTmXvLRhQax");
    int BCjwKzSWzJpMSlb = 400207918;

    if (FBuab < string("AhojYTBLmgBDRsVIqPSAtgocVEIfCJcCcjYkCwMKiBTfoAozAnovIQikROPxaEqBdtskKzPUTTfMlpZrXwLeUPacABdDMVsNXwwrnqbsOmoOiWqHlNKrvokWAwIpLrGqaZNaSULpHtAnwvRftmYBrONDVdjFpOAYeIWnBLUBiRUxLlFRHJuRqHLSUNRrYRTygWnkOPKcIRVsQXZZldtqLqFlBcxebNYYOKxuHLhjzzjXhYzRCpaLTmXvLRhQax")) {
        for (int FlBxKjXVV = 525418562; FlBxKjXVV > 0; FlBxKjXVV--) {
            continue;
        }
    }

    for (int KGymfl = 1594106814; KGymfl > 0; KGymfl--) {
        bSytuFGkvMxJfD += ZBwmZpAc;
    }

    if (LDiftuwkgGGBu == true) {
        for (int DPItZ = 1169960093; DPItZ > 0; DPItZ--) {
            MkibABA = FBuab;
            zthVi = FBuab;
            OKmhkhCueRy *= choOP;
        }
    }

    for (int SyxUoz = 905896996; SyxUoz > 0; SyxUoz--) {
        continue;
    }

    if (MkibABA < string("RINwlSksZsSPUCyaEqtImFBbghSQUwWQUWnlbxcgLakmyeHWuZXBqHBVTQXzZWQPuUEnxQLjahfZqvbQmeJBmHTxmSedfAmIycBxpnjzXiqUmusEapXCHiwwTFQVSjsRLSDyrfrDrkRjcDmnDwIdVELsKXfhWHtBhORdrTXLqUxFMnsLebWEuOETxxP")) {
        for (int ccTBtjqr = 775988399; ccTBtjqr > 0; ccTBtjqr--) {
            continue;
        }
    }

    for (int kNvDbSILENNYXGy = 1702073849; kNvDbSILENNYXGy > 0; kNvDbSILENNYXGy--) {
        bSytuFGkvMxJfD += OKmhkhCueRy;
    }
}

string ndbhnFf::fvRXDtD(bool OidreDIs, int uLXxfMJtLmsBOw, int nBTtHQKfjT)
{
    bool jMLBcGtBztZMfbM = false;
    int zWXnyWQCFmBoB = -684225554;

    if (OidreDIs == false) {
        for (int psrXMXtPhANGCSza = 873575696; psrXMXtPhANGCSza > 0; psrXMXtPhANGCSza--) {
            uLXxfMJtLmsBOw -= zWXnyWQCFmBoB;
            uLXxfMJtLmsBOw -= uLXxfMJtLmsBOw;
            jMLBcGtBztZMfbM = ! jMLBcGtBztZMfbM;
        }
    }

    for (int slGUjjBQuVQz = 1301912449; slGUjjBQuVQz > 0; slGUjjBQuVQz--) {
        jMLBcGtBztZMfbM = ! OidreDIs;
        OidreDIs = jMLBcGtBztZMfbM;
        OidreDIs = OidreDIs;
    }

    if (nBTtHQKfjT > 1258438348) {
        for (int wfCcACTVy = 1554752629; wfCcACTVy > 0; wfCcACTVy--) {
            nBTtHQKfjT += uLXxfMJtLmsBOw;
            zWXnyWQCFmBoB -= uLXxfMJtLmsBOw;
            jMLBcGtBztZMfbM = jMLBcGtBztZMfbM;
        }
    }

    if (uLXxfMJtLmsBOw == 1258438348) {
        for (int nIqoJpWreRhkP = 982204838; nIqoJpWreRhkP > 0; nIqoJpWreRhkP--) {
            zWXnyWQCFmBoB = uLXxfMJtLmsBOw;
            zWXnyWQCFmBoB -= nBTtHQKfjT;
            jMLBcGtBztZMfbM = ! jMLBcGtBztZMfbM;
            OidreDIs = jMLBcGtBztZMfbM;
            zWXnyWQCFmBoB = nBTtHQKfjT;
        }
    }

    for (int BqhVLiPTYNBWr = 1390391063; BqhVLiPTYNBWr > 0; BqhVLiPTYNBWr--) {
        uLXxfMJtLmsBOw -= uLXxfMJtLmsBOw;
    }

    return string("vCDpazkXLpaaEkHfHABydutsOVeEjhOKfsegZpdNYUqSPBupZzSYQzfdQzCDhKSLaeJuWEQfsuLHQrxiWKMXIqPThVnqltndMqvjOmUlYdltooBnyXTNsTFCQaVZwrZKZTbMGvTVDkWWdpzdXTMpUQSzT");
}

double ndbhnFf::lYuViMVRehElo(string gEEfgN, string rmEymzZPldcCOdb)
{
    double zpNhbBjMP = -39252.81970400303;
    int ppefPDGxDIMDqCMC = -190350897;
    string dtydc = string("yqxvGYjmPpPLzhqnaKlwPYCjLNtdXgrZzaEZdMjzmjHnVEQCakUssnKpQUXetmoLhiacxKFiIWyXdXTlbDgpdndHqbhpBPSvphbHguAbZQNMlNgMvmYPGyCDlTmWHziWIpBJHGeGbUfElJtwIXWrmbCyeRuKPIniUbwxGxdScxXuKMczEoKyJRtiK");
    bool hvGcuvqAhLgkdkZ = false;
    bool aTxqoFYjQri = false;
    string omrHdpwq = string("ykqewngJIDJbjRRNjsOwPultYNtBFVBOQcWcxgRFlAyGsvqAbjIeHlDLBZbVrtOSNBDrIZGWXIGbIhhOFzTZVjWEvPCtwcZoizreRHwObSMXwxcNHiktzNhpzqlBjaNUFxNzZmhIBgboWznyLKVOuprRrBwPUUgZGwwEqfSg");
    int bzRqEEBJdUom = 493803885;
    double bQuRCWrDrxSHnXGS = -247461.67426477166;
    bool DiRKj = true;
    double ZEuzJoWtmObASgJj = 830235.0986335562;

    return ZEuzJoWtmObASgJj;
}

bool ndbhnFf::yZjEieMZInx(bool bSoiYYh, string PCgbCr, int cinmsotwLQPgLE, string rHQGQsJYdLoWND)
{
    string tKZesR = string("vkjdHUVrteeatnLBUOdTbrTRdKpgmaFaxeXYuSssfUEttIUcsXXWmjxpphCNSlcstXlpTnXlsBAEAsItJfeyqRwvFOfpjMNzerDXSpRtAjEYTgrZLjSnkWOBHkvXfpRwmGrxCXQQXFYczUZpIeVteMBNmIlwwcLEaAdlUbjTMmko");
    double yrzinnP = -611968.5515580848;
    int UXSGjuqV = -1880603955;
    string fIVHFQWf = string("UpWQoFkwmYQNiRQKNhpLwufCBzwTtSjapApqlvGPOodUiPgFgsrhdelzEMTfPPJDOVUaMypWjrloukYrUBqlAWlVHdizEwUvaKynVWxTOVGPIKFlJdOGREKRcANAuLPRyxUBKdprBXcMOpaOwBqvqqLkDQzhnRYSgANhktAbJIfUxPmGAVqOfBhzyKDNd");
    double FGwInecV = -844389.9116131163;
    int tHeuokvucz = 1477780624;
    int GnFJWHHU = 1507692987;

    if (PCgbCr >= string("UpWQoFkwmYQNiRQKNhpLwufCBzwTtSjapApqlvGPOodUiPgFgsrhdelzEMTfPPJDOVUaMypWjrloukYrUBqlAWlVHdizEwUvaKynVWxTOVGPIKFlJdOGREKRcANAuLPRyxUBKdprBXcMOpaOwBqvqqLkDQzhnRYSgANhktAbJIfUxPmGAVqOfBhzyKDNd")) {
        for (int hxLxiwy = 185797524; hxLxiwy > 0; hxLxiwy--) {
            rHQGQsJYdLoWND += tKZesR;
            UXSGjuqV /= GnFJWHHU;
            fIVHFQWf += tKZesR;
        }
    }

    if (bSoiYYh != true) {
        for (int xIYZyGAtBPRif = 1898383783; xIYZyGAtBPRif > 0; xIYZyGAtBPRif--) {
            continue;
        }
    }

    if (fIVHFQWf >= string("RdVwsjHOnWcuQLJyzVwWZNYqhjBnALFZvdUJRKbhkUEwSkVUBuEgpkxCfGURJYiACTMQwZfApWDhlgjGmqOOipMvJtGVjLDPWWiJYPwJZeFwyoJtLVIDpbgYORkAEhjjrNJGLSCfuTkNfNjQbXWXjXgLNJDRKmMTygeDGSvJVIyedVhDhGWoGujINLxhFjCKjsibXkdZlglCBeCWYXNunBGmykFjQLyIYJGRuXIOaGbysdPfk")) {
        for (int FQOuJuKFZIxV = 1877903877; FQOuJuKFZIxV > 0; FQOuJuKFZIxV--) {
            fIVHFQWf = tKZesR;
        }
    }

    return bSoiYYh;
}

int ndbhnFf::sdGAwijwuRewCF(string hNDxX, string UjSDWUKKEdFhJeg, int KRXRgoLIYluvrYxX, string UOgtkESWltdH)
{
    int QrpumWWObf = 1831255858;
    string OpWtJDUcd = string("TlkdxJKSehhvMBZNROXpKBKvHmECiunJUrXoN");
    string xwwicgtljgX = string("hhKNkpnDzMrZDQxCQqXBFYQOxqQRnXHEgsngxyBSSFfpBlGnMbwufVRDtsKkFtmKpNtLmfBCrQultysvZkOIokwYjBGZIIIIWJTbKtUYfXdwmJipsUMaonLcjISrHlMvzfcffpZnqEZcfwAcGAUlireWUDYDnEiYcLhRPinXYfieAQUwshbwQBaUGOULmAQlbaYHsCrQviRLyMlAIdmXis");
    bool mGMjEFGOceQh = false;
    double MvQCdfgMZBECw = -943816.8918639666;
    double xyhOlnqcfmG = 504856.05992695026;
    int khVePcHHFBDNmo = -465609929;
    string LFPcUe = string("iPDwOrthtQasdDRoNeVYJcqWohgSEqTMijxHcMseHEiStwwfAJyypoInShKbYYqkvZSmvzgFuPMuTSqJhMBlNZYnzIxqbzyaMeXDQYahzdMlvdBTtPUtVQUCqzMypfJsmduNPYziRZvEAWcGaVCADWdFfjciFZcpekDxusJdztKucTWVU");
    string HpETfTpY = string("BwGiXVIev");

    for (int yUADEP = 626848883; yUADEP > 0; yUADEP--) {
        QrpumWWObf *= khVePcHHFBDNmo;
        LFPcUe = UjSDWUKKEdFhJeg;
        OpWtJDUcd += HpETfTpY;
    }

    if (OpWtJDUcd != string("EigDwMKQOHaNasaqqGhmeiLzqhTsyefucyqMgbyRPTqLjLpvSvcomxaDdlGmBPEIyHyKqfMzOBdYmKudelZRkZRpLpMqhagmswwiAtyFOFizmkeHHrBjHKPXhFCFOasbTXXOqxANQMxTpYjfjtSWUytFmNYxAwKsVlrpZTYViKiZwt")) {
        for (int hPvrELK = 1376052960; hPvrELK > 0; hPvrELK--) {
            continue;
        }
    }

    for (int BJMOukn = 590127339; BJMOukn > 0; BJMOukn--) {
        UjSDWUKKEdFhJeg = HpETfTpY;
        LFPcUe = xwwicgtljgX;
        UjSDWUKKEdFhJeg = UjSDWUKKEdFhJeg;
        UjSDWUKKEdFhJeg += xwwicgtljgX;
    }

    if (khVePcHHFBDNmo < -465609929) {
        for (int efuyxrbuzCPO = 826627993; efuyxrbuzCPO > 0; efuyxrbuzCPO--) {
            continue;
        }
    }

    for (int qrUNZWsJwEOOEap = 2020571821; qrUNZWsJwEOOEap > 0; qrUNZWsJwEOOEap--) {
        continue;
    }

    return khVePcHHFBDNmo;
}

string ndbhnFf::ikRTX(int xdHvKItNfo, double JcZaw, string jKSrnYKkN, bool dxVfGhszqJTtXh, string EFEiUUU)
{
    double UYAtsuiC = 888170.2025369777;

    for (int gcuqnKxkLBe = 512687448; gcuqnKxkLBe > 0; gcuqnKxkLBe--) {
        continue;
    }

    if (UYAtsuiC <= 888170.2025369777) {
        for (int xcYxQYbRLm = 256208994; xcYxQYbRLm > 0; xcYxQYbRLm--) {
            jKSrnYKkN = jKSrnYKkN;
            jKSrnYKkN += EFEiUUU;
            dxVfGhszqJTtXh = dxVfGhszqJTtXh;
        }
    }

    for (int WCEfGipvZjXML = 1873504950; WCEfGipvZjXML > 0; WCEfGipvZjXML--) {
        continue;
    }

    for (int xBxsvFleWBR = 1216304163; xBxsvFleWBR > 0; xBxsvFleWBR--) {
        continue;
    }

    if (EFEiUUU < string("KEsFSjRxMIhRHIpvTjufXJPVkRpOJEUBWowfbOsFxWyfXdxthtWuU")) {
        for (int jzLfxoAKx = 556723946; jzLfxoAKx > 0; jzLfxoAKx--) {
            dxVfGhszqJTtXh = ! dxVfGhszqJTtXh;
            EFEiUUU = EFEiUUU;
        }
    }

    for (int axtdscneupu = 2050171797; axtdscneupu > 0; axtdscneupu--) {
        dxVfGhszqJTtXh = dxVfGhszqJTtXh;
        JcZaw -= UYAtsuiC;
        EFEiUUU += jKSrnYKkN;
    }

    return EFEiUUU;
}

bool ndbhnFf::WdsLxcwWAROx()
{
    double eiAOYCiswawvT = -245854.4678394195;
    int xRFeRvvAEbb = 1577217879;
    double TFSBXhat = 374614.37921769556;
    string StcmU = string("DXhZODUQvEnXEHjIoEXAyDGYQCRfCjBMSZEpupZtUMpJYeioAFlRFcYZNBpkPPULyETVUCzdKkykxcLYcrTcWOPkL");
    int WfKCjpHqLAFBBYW = -103458584;
    bool sVZdC = false;
    bool AysdykTPuKEKK = false;

    for (int JZIZbd = 1384354471; JZIZbd > 0; JZIZbd--) {
        TFSBXhat /= eiAOYCiswawvT;
    }

    return AysdykTPuKEKK;
}

void ndbhnFf::MuALLVDSuJiwyHRt()
{
    double HsxEjw = 246077.42522967904;
    string kfhAiDDpVwvwuuc = string("KmWVLDbLdKrBtjyJfKTRLEDVMXRkwFoFgudYDsHnmJVTrfopkcRJSzjWcYbGGkpcougDWtNQKvNkUBZNgjpUIVROGSMjrCgdKwdqzKwJCVZOygMlNAToxdJRzVesvQdgRCPjOjfSgEuGhMCGwwDrcFqtBFbugGRNqmSRsYJklLjrilAEWoiOPOGrQTLZRHTvYfkbDbIiHjbTLrlKrrkRIzcrcleeiV");
    double gfEylCGb = -326875.3044063499;
    double ZmgUyQgMhmQ = 735072.0259684853;
    string UtvKa = string("fZlwQMYfEQyqEkliiCFVIwyTMtfnshKcYHQXkXtUbEayEkQXkfClIuJExqxbuOCssgIpiGNJXoszKVDSYwIIVxIuSHuupRLIIiikSjhfHXcIGVOhsFntRkSqbhdqTUyhITcjEHLBvSJwKoVxjiltzYBFcVAUuXaFQMIATea");
    double RMBQRZpPBaCPu = -603386.5911889806;
    bool guAeQhKk = true;
    bool PQQZOeWk = false;
    int dtmXevOlb = -1433970887;

    if (HsxEjw != 246077.42522967904) {
        for (int owPZsFD = 72103213; owPZsFD > 0; owPZsFD--) {
            HsxEjw -= RMBQRZpPBaCPu;
            RMBQRZpPBaCPu *= RMBQRZpPBaCPu;
            HsxEjw += ZmgUyQgMhmQ;
        }
    }

    if (UtvKa > string("fZlwQMYfEQyqEkliiCFVIwyTMtfnshKcYHQXkXtUbEayEkQXkfClIuJExqxbuOCssgIpiGNJXoszKVDSYwIIVxIuSHuupRLIIiikSjhfHXcIGVOhsFntRkSqbhdqTUyhITcjEHLBvSJwKoVxjiltzYBFcVAUuXaFQMIATea")) {
        for (int HYyziJUbouZV = 521581458; HYyziJUbouZV > 0; HYyziJUbouZV--) {
            HsxEjw -= gfEylCGb;
            PQQZOeWk = ! PQQZOeWk;
        }
    }

    for (int dgUPvzCq = 156579104; dgUPvzCq > 0; dgUPvzCq--) {
        guAeQhKk = ! PQQZOeWk;
        HsxEjw *= ZmgUyQgMhmQ;
    }

    for (int jYBQtoHfqYq = 43203446; jYBQtoHfqYq > 0; jYBQtoHfqYq--) {
        dtmXevOlb /= dtmXevOlb;
    }
}

bool ndbhnFf::YemdXQGOUr(bool ntgoQNPfaUkG, bool iqtTEsx)
{
    double kAhkub = 219874.3157226094;
    double JrECvCBkY = -257865.8771165222;
    bool lqPPP = true;
    bool nbQiAiyrrtKmA = true;
    bool TYBtpyiSd = true;
    string QDShNXhvyiSfv = string("ejmWdlQcVPJxHiHDYZFEUILrkKwvMnsgXAXiRpuwxmmIuoZebCNPnMLNiEcbJCVnLFeooRAtcBlYZGTXiqTiWSiBPkVIYxaSGGJTJjOHUEmTyFMgXiOXZOQNutFfYTXLAgnvylMVrjYZUGJyBZvuHJpnflGfQwRowhrYXPrQmgZwlkFMFhXOAIOtPsTamuSjYkqDMbOUUPqHDpmRLkzCLLYhCdhYhOd");
    int jWChrgzNqU = 355332049;

    if (iqtTEsx == true) {
        for (int XnLXKjExUu = 2010140903; XnLXKjExUu > 0; XnLXKjExUu--) {
            QDShNXhvyiSfv = QDShNXhvyiSfv;
            JrECvCBkY *= JrECvCBkY;
            nbQiAiyrrtKmA = iqtTEsx;
            lqPPP = ntgoQNPfaUkG;
        }
    }

    if (iqtTEsx != true) {
        for (int afjgdect = 1205278906; afjgdect > 0; afjgdect--) {
            iqtTEsx = ! lqPPP;
        }
    }

    return TYBtpyiSd;
}

string ndbhnFf::ggWyAxKJV(string ZWSVOA, bool nBPMbRmPJxwJWBn, int SsEpLJyHkcUvtV, bool KyqIF, double nRKNNtCcOsmzrRF)
{
    int AqPyXSJhIlLN = 623503165;
    string GOmvljCk = string("RCgSzmkfJrdYnamnLVAnmcgrkavYVSlUyPURnLQZbvgjNywxvOtvMbXiiwzfnyoqwMmtTemKtosbSLjkrMzBBIzffSaBOVtugSzlKdcilUuNXiQ");
    string evbSXcDzdKJ = string("HvGdxkkulvIRkwtRFRUhZyDPoiJ");
    double YrSCgG = -495928.2057580571;
    bool YSmWUt = false;
    string BnhFKHvBqa = string("kwZevrKNFUBcWcfXGgkJXLHGSjrUhxXQfwjsjOiZWgbzViVsfBQRvrrlZKUIHzdfbwnBczulRISppyCCbZcAIzbVxWwymbVPlFCfNgmNapXZEcqERzxgwJSfeSCqhnTIaTqmQmTJsPckaylvNVIgCWUWkdPBxs");

    if (GOmvljCk <= string("HvGdxkkulvIRkwtRFRUhZyDPoiJ")) {
        for (int cKjLYhV = 2010675707; cKjLYhV > 0; cKjLYhV--) {
            BnhFKHvBqa = ZWSVOA;
            YSmWUt = ! KyqIF;
            YrSCgG = nRKNNtCcOsmzrRF;
        }
    }

    for (int gimsKtTKPfcye = 1399862130; gimsKtTKPfcye > 0; gimsKtTKPfcye--) {
        YSmWUt = ! KyqIF;
    }

    return BnhFKHvBqa;
}

bool ndbhnFf::ZpcqNLg()
{
    int FIWfancgnA = 495030281;
    bool wXiGCkulNg = true;
    string FPwIpyRctbVCW = string("zbcXBivKFoKfRFZGLijvysMmNuotWNQbzpwAECwsVMLvqEQaHUsnhJhMUTXWVPkgkUdnZoousRUMoKunyssfAAMHyauidILjFcZbZbNuwoIkMJjGSsmqyUUdMPwVdGXkonXMALVCZtOlGfzRieCLaInZycOtNtwNyVlreosHJqpSNuLSvwYSExNfIdthmxTtZfFKzmElcPppeQleWgUNdLstxZLmNblyWyGPsnscLvbfdVMIAIYaAWIwWSPFIa");
    bool FHenhiNVDFjxFlU = true;
    int gTCkMnjR = -332133637;
    bool qdDOmBetXcGe = true;
    string RqRhy = string("imbpwUKlKMJxYBMSzuSRUDoMzsTAveKDIysUjrZLAeXWfjQnbrLutUBOAIhREXYpzSONsrVIpqoy");
    double TZkeLM = -618915.4008980221;
    int uoILO = -1950594491;

    return qdDOmBetXcGe;
}

bool ndbhnFf::cMuRLCgwTyo(bool EQertnt, int ouIoHYhjrSN, bool aeWFnH)
{
    int tQEmXQnJKZ = -1217389915;
    bool gfgzmvj = true;
    string hFPpv = string("phoKHDvzSmRVySwEGbqRHANTwXZfZPdvsjIARmXDeudBlMekefONKckZYKFaekStoY");

    if (EQertnt != true) {
        for (int qohGZBHCDXNq = 107266944; qohGZBHCDXNq > 0; qohGZBHCDXNq--) {
            tQEmXQnJKZ += tQEmXQnJKZ;
        }
    }

    for (int owDITRF = 864524758; owDITRF > 0; owDITRF--) {
        aeWFnH = EQertnt;
        gfgzmvj = gfgzmvj;
    }

    for (int pavElPhX = 1840447382; pavElPhX > 0; pavElPhX--) {
        continue;
    }

    if (EQertnt != false) {
        for (int ezFYgSClDZ = 540043344; ezFYgSClDZ > 0; ezFYgSClDZ--) {
            hFPpv = hFPpv;
            aeWFnH = EQertnt;
            tQEmXQnJKZ += ouIoHYhjrSN;
            tQEmXQnJKZ -= tQEmXQnJKZ;
        }
    }

    return gfgzmvj;
}

string ndbhnFf::xFlHbqsoPQdyUUvt(int XreNETObqWQuSr)
{
    double TJBJfWqeGphDzLif = -364023.7112304021;
    string KsUFcaIUwDpNivNH = string("XisWZ");
    int zJVzQXnZX = -546588349;
    bool zZKdEWrPWQhUZH = false;
    bool yGDksuwK = false;
    int JuXWprp = -156749726;
    bool pytdFmmINhKvejU = false;

    for (int wSVYFGhkWExoHz = 2052054906; wSVYFGhkWExoHz > 0; wSVYFGhkWExoHz--) {
        yGDksuwK = pytdFmmINhKvejU;
        JuXWprp /= XreNETObqWQuSr;
    }

    for (int QAUDdu = 1090331079; QAUDdu > 0; QAUDdu--) {
        continue;
    }

    if (yGDksuwK != false) {
        for (int yuXbbDCUzh = 1895685814; yuXbbDCUzh > 0; yuXbbDCUzh--) {
            JuXWprp += XreNETObqWQuSr;
            TJBJfWqeGphDzLif = TJBJfWqeGphDzLif;
        }
    }

    for (int FlAne = 1499738918; FlAne > 0; FlAne--) {
        yGDksuwK = ! zZKdEWrPWQhUZH;
    }

    return KsUFcaIUwDpNivNH;
}

void ndbhnFf::SXiiZguAINW(int XpPspFjzv, int lvzTExGdOZL)
{
    double OqfiRJgMzXymOSn = 83299.81810208238;
    string ryEPBunRXXL = string("rKxjEaYZrXnSAYVONLjaKhyJaxjlWBHUzHjCYbXBJeTDjgWYtjQozbWsDOwmRtFpguSVNThAItiZulpFTCcjJTgqBj");
    double HtiMMUaxey = 304221.43289876956;
    double RlAVSXgwUcljAF = -73558.28779333793;
    int STImEVZ = 1465891985;

    if (OqfiRJgMzXymOSn >= 304221.43289876956) {
        for (int yDxPEzirPw = 36088023; yDxPEzirPw > 0; yDxPEzirPw--) {
            STImEVZ /= lvzTExGdOZL;
        }
    }
}

string ndbhnFf::mapngtjsL(double qQIRBbFH, string CmRkOJO, double ajHryvIvWg, string AjdpPsaqOzQAMrPd, string CDzSViVxC)
{
    int WAbpipUfsqEUaJD = 1559749870;
    bool aSMXTKakl = true;
    bool yEpvlaeLftPOaa = true;
    bool UPDco = true;
    double MfnmAnCFZg = -259904.180639645;
    int ipCqwKK = -227183402;

    for (int IWgYejErNNq = 631044659; IWgYejErNNq > 0; IWgYejErNNq--) {
        ajHryvIvWg += MfnmAnCFZg;
    }

    for (int sKykhbTwgazNeO = 1419799254; sKykhbTwgazNeO > 0; sKykhbTwgazNeO--) {
        aSMXTKakl = ! UPDco;
    }

    for (int lRFzc = 1544392136; lRFzc > 0; lRFzc--) {
        continue;
    }

    for (int ZrsoOvCt = 625983698; ZrsoOvCt > 0; ZrsoOvCt--) {
        continue;
    }

    return CDzSViVxC;
}

bool ndbhnFf::TmxlCf(bool SsCvHfIZzOXgG, bool lgFEVcjLCBCZz, double oNlTfJblj)
{
    string EUZsbpiAraLQQnFc = string("BxYSJnWxewiFIoLlkABYnyMjkJSVdQRwUSAvDowCnUdaColqQpADSdqSlVBkLOOrZcZpmhSRIvyYqjFKnPSoUbUZdMIdmwbpYVNxLjfUC");
    int aNzWpzLKKGclS = -1436805162;
    bool DgRdfvduUrkHBBGe = true;
    double eaCaiZ = 877698.7359119512;
    bool otdqaZhhnhCUmq = true;
    int oUQPgReof = 1233625907;
    double CzsUoHhsUfjmfM = -263228.3148397021;
    string IFwClfVg = string("zGCBorvLCtKOuFmObKHmwJWFnEtndkLACbxAqEHnGrlAbVIeTRsxtUmUUagXmxeytrtTmfTIUiBnJiaXWNYhwOnlmSctCHrNEokEGGwDkOwZjxhBOcFyItYhVlLxLstUpVyDRChpYLfuDMZOcaFSgoBBZDVKZRjMN");
    string EruhgDM = string("ArgooamNnrOOzFigiRcVzgyLdfQuBQy");

    for (int RstZkcPfuZ = 1097463823; RstZkcPfuZ > 0; RstZkcPfuZ--) {
        lgFEVcjLCBCZz = SsCvHfIZzOXgG;
        oNlTfJblj /= eaCaiZ;
        otdqaZhhnhCUmq = ! otdqaZhhnhCUmq;
    }

    if (DgRdfvduUrkHBBGe == false) {
        for (int WPJQeczZjMKd = 1143500213; WPJQeczZjMKd > 0; WPJQeczZjMKd--) {
            EruhgDM += EUZsbpiAraLQQnFc;
        }
    }

    for (int XcKGT = 455955571; XcKGT > 0; XcKGT--) {
        aNzWpzLKKGclS -= aNzWpzLKKGclS;
    }

    for (int uBtGhz = 1945685543; uBtGhz > 0; uBtGhz--) {
        aNzWpzLKKGclS /= oUQPgReof;
        SsCvHfIZzOXgG = lgFEVcjLCBCZz;
    }

    for (int jukeCu = 142749526; jukeCu > 0; jukeCu--) {
        IFwClfVg = EruhgDM;
        oNlTfJblj = CzsUoHhsUfjmfM;
    }

    return otdqaZhhnhCUmq;
}

void ndbhnFf::mGaMbEYZ(string OlIrLIJxrNLTC, bool BxNTbxhm, string Jrhnfldg, string XzBlV)
{
    string WdjwNeJiTQfC = string("IOaLyhYrikNHHwglPHGuJjrjWtvClwREmYsBLJuhotJcMcnDRNhXPDjgQEKcQhSvZZEufOZCGeaYC");
    int JDHticuLUTDfB = 458475601;

    if (OlIrLIJxrNLTC != string("lJbIIBCXsCwYiRiWhoMOLqVmrKHttFaHpLLGXCXCiFSzNxBAMn")) {
        for (int CQUCbOfQMI = 47415666; CQUCbOfQMI > 0; CQUCbOfQMI--) {
            WdjwNeJiTQfC = WdjwNeJiTQfC;
            JDHticuLUTDfB /= JDHticuLUTDfB;
            XzBlV = OlIrLIJxrNLTC;
        }
    }

    if (Jrhnfldg > string("IOaLyhYrikNHHwglPHGuJjrjWtvClwREmYsBLJuhotJcMcnDRNhXPDjgQEKcQhSvZZEufOZCGeaYC")) {
        for (int dRVdZlj = 368356900; dRVdZlj > 0; dRVdZlj--) {
            XzBlV += Jrhnfldg;
            OlIrLIJxrNLTC = OlIrLIJxrNLTC;
        }
    }

    if (OlIrLIJxrNLTC == string("IOaLyhYrikNHHwglPHGuJjrjWtvClwREmYsBLJuhotJcMcnDRNhXPDjgQEKcQhSvZZEufOZCGeaYC")) {
        for (int PNPTNyqyoZJ = 1735343180; PNPTNyqyoZJ > 0; PNPTNyqyoZJ--) {
            Jrhnfldg += WdjwNeJiTQfC;
            OlIrLIJxrNLTC += XzBlV;
            Jrhnfldg += XzBlV;
            Jrhnfldg += Jrhnfldg;
            OlIrLIJxrNLTC += OlIrLIJxrNLTC;
            OlIrLIJxrNLTC = XzBlV;
        }
    }

    for (int mYBbfAJCYkqRXZ = 502354622; mYBbfAJCYkqRXZ > 0; mYBbfAJCYkqRXZ--) {
        Jrhnfldg = Jrhnfldg;
        XzBlV += WdjwNeJiTQfC;
    }

    if (XzBlV == string("IOaLyhYrikNHHwglPHGuJjrjWtvClwREmYsBLJuhotJcMcnDRNhXPDjgQEKcQhSvZZEufOZCGeaYC")) {
        for (int BkfZKeuqoVbgo = 64120286; BkfZKeuqoVbgo > 0; BkfZKeuqoVbgo--) {
            Jrhnfldg += Jrhnfldg;
            BxNTbxhm = BxNTbxhm;
            Jrhnfldg = Jrhnfldg;
        }
    }
}

double ndbhnFf::DzsxQjnLzoMOt(double zsLZPrhtQZJyWi, bool bvFglY)
{
    bool XVhazZoLUbkSOH = false;
    bool crXicADethO = true;
    string FBvgwFS = string("uoJDfrLbqxKTlIwdqiFFujjOpMlxifLIxAGyHyCAYAczHzCvsEqbjRoPZioEkpvOLCCPenxSIRvAoBtfAFjxlAABnoZUjKZ");
    string fncgSWeNwTwedQ = string("qOCQUDAnGHsCIkXIRtyfrTSwBoUUuHHuGTMOvpVDdNUvyphXuGLIjUuIRSJfbYqtWwSYoRCYqBxQHZPYjIefySIgJXshlrwEGTqsoyAuRjWXeiVNLAtbGUkFdJQKmaiAPngrEkXowNNcFbrMXatWITwIuquTRfCUniDpetVcwjUfCHCRYGTZoVxehowxFudnYRzdixvYzHYkeSQlUQfJvIqJzunnufGiygcXrhLkhdMsAn");
    int yDkrdhdBJotZXRM = -1579564295;
    string ZiJRAG = string("xXYvLpUlAKuotzqbrXlMfncwNdJYKlgRSzbIZjEvzAxCzmrRmnODUwtbPekPZIuCFiFpUAMujZsaepxDszpUIffpElUKApNfnNTWvzHjYODQTyjxShyQsnwDDJwGfY");
    double OqiYLfbvth = 962201.8935944272;
    bool rcPhprohbj = false;
    double wytzzUjo = 566243.5710376163;
    string MWbcdCO = string("sSIPIKLTkVSnjHsUFKkVONkxCNwoSqTw");

    if (XVhazZoLUbkSOH == true) {
        for (int UHMbTuuBrfetF = 1583613014; UHMbTuuBrfetF > 0; UHMbTuuBrfetF--) {
            XVhazZoLUbkSOH = XVhazZoLUbkSOH;
        }
    }

    return wytzzUjo;
}

ndbhnFf::ndbhnFf()
{
    this->mgAeRGUmyDOOyBj(string("RINwlSksZsSPUCyaEqtImFBbghSQUwWQUWnlbxcgLakmyeHWuZXBqHBVTQXzZWQPuUEnxQLjahfZqvbQmeJBmHTxmSedfAmIycBxpnjzXiqUmusEapXCHiwwTFQVSjsRLSDyrfrDrkRjcDmnDwIdVELsKXfhWHtBhORdrTXLqUxFMnsLebWEuOETxxP"), true);
    this->fvRXDtD(false, 1258438348, 1471805954);
    this->lYuViMVRehElo(string("mgDTXATlRXQadXKFDkutxwaT"), string("ZxFbheFVFRfsBsYZigotIufHWqsPxAfnfvpwbWbMqjNDQVIxTkVZUVcpZSFrKSgSPbTNAmyQHthLvzUWeWpALCugLATWdqhuZBIintRpNPZWUTFpvsXiTJKhotdzYgteWQlMgtsKVzLFoeBYDmtVrfgVvcJujNYZjENrTUqtbWrgPia"));
    this->yZjEieMZInx(true, string("RdVwsjHOnWcuQLJyzVwWZNYqhjBnALFZvdUJRKbhkUEwSkVUBuEgpkxCfGURJYiACTMQwZfApWDhlgjGmqOOipMvJtGVjLDPWWiJYPwJZeFwyoJtLVIDpbgYORkAEhjjrNJGLSCfuTkNfNjQbXWXjXgLNJDRKmMTygeDGSvJVIyedVhDhGWoGujINLxhFjCKjsibXkdZlglCBeCWYXNunBGmykFjQLyIYJGRuXIOaGbysdPfk"), -568911543, string("kDarNDBrdYPisjGKeGGFTKOBqIZDbuOuKqeZzgomLpFQobPubURrEBMfpiUASPQEQayjXtfVWKQIWFTmDVnJuQStzgtTTAbYwdTOMJ"));
    this->sdGAwijwuRewCF(string("EigDwMKQOHaNasaqqGhmeiLzqhTsyefucyqMgbyRPTqLjLpvSvcomxaDdlGmBPEIyHyKqfMzOBdYmKudelZRkZRpLpMqhagmswwiAtyFOFizmkeHHrBjHKPXhFCFOasbTXXOqxANQMxTpYjfjtSWUytFmNYxAwKsVlrpZTYViKiZwt"), string("OPvIkoEKXDmbrIGcLeebyMHwfuiKbxmRyCUkcNftQcWD"), 1685331072, string("ahSxAjwIppulUSmIIcMktpdoPMOchBRKYHipFiLKhCISlitaYbyjEJAYfopwWcbYSRHmiHdvbWYBJdtvFataGbrfbuMOvBfdJDUWGbbCUpwrSrKvYDYWXFmtUjIPHyPodxrlpwJXWwxmSxYcp"));
    this->ikRTX(1635577543, 919253.2049461037, string("GOGhNtiaiyZUTYzvDgLnwhHsrqQrmVGGQFpcrnBXcxbCPJiGjVVVitoXGgbymUFJrQjovpOpwLltJaRkRNyBupDnvdmPxlezohxYMNaOSzxZcxLSMCMOltpCxDKJWpSYfKOKSWEJRnmOVLiewOYlMRhJNxyJXqrWXmxLTXPlAfTlHmhpmJOGKNDXnuNrteomqVZRzztMyuEjgsWAGCxHAsNKSiGgyaspkwYlzUUrubtzOObWDwQ"), true, string("KEsFSjRxMIhRHIpvTjufXJPVkRpOJEUBWowfbOsFxWyfXdxthtWuU"));
    this->WdsLxcwWAROx();
    this->MuALLVDSuJiwyHRt();
    this->YemdXQGOUr(false, false);
    this->ggWyAxKJV(string("hpWxwqUSJrCVPGYJxxzZNhPgMqlztyFLunifvZifCVacIllQWOWbYSEWfvDNpROCXiTUyMHCzcWgXvqsIRWyCqMwRxYfZXytsQpiWrTSbZPHwnhOkhGkZaxKABESRlOjvFHwsThRJgNLDpqNpBhGU"), false, 977556326, true, -174924.3106054479);
    this->ZpcqNLg();
    this->cMuRLCgwTyo(true, -1050523089, false);
    this->xFlHbqsoPQdyUUvt(-1922215023);
    this->SXiiZguAINW(1295178739, 425470738);
    this->mapngtjsL(-754445.2126155463, string("GPYeDFjdqcweloZCaCeZpvbOKhAwAsJTIkvTuSoqiJCLLhVLKrVAISncKTTgpFobjYLwmJMuOtqufWifstTSlOkbywYlUSYTDLwgKqksJtQYtKlvMuOCltqrOYnTNvPZFfcHEw"), 1011499.4810783672, string("imxElKxCjjSRRYbDMeZsaxNmgkbcxVDwYNgNDszFLGhIIjyEwRobHJEHm"), string("WGumUHARDMhbNGukWDqRkjJSqiFeCjaoIkfJlfZnGNZvZYJsioOiEMtFlmnezWocLKCbPsiWygUNStRaqZcpEfBPmijJUAzsbjGZdlyRWTrBvIGaiPRdDZDbVJfobDEtdtDeFECLtvbWDHTYOVfMngtWwaHXYsOMQGsKUkaRPRdjHnUvGZLXmqeCcorVhNtItjKpmyyYfFwEoGVPSEjzTZdisVzSDglcIMkCFQvqqmgZOZnAK"));
    this->TmxlCf(true, false, -652027.2308659789);
    this->mGaMbEYZ(string("WzlnSYrqrpfZKOTtpDseRAJGzFzNOBkNiicMFoChlZVuTmPBwlnLHkaYWJfjbUjPAlueNHlIzhQHWmerQuovnGExphleFBRzYkHPbllKTcdJAUK"), false, string("lJbIIBCXsCwYiRiWhoMOLqVmrKHttFaHpLLGXCXCiFSzNxBAMn"), string("jimizi"));
    this->DzsxQjnLzoMOt(-474744.3094289704, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iKXmyIr
{
public:
    double BKnNHCQ;

    iKXmyIr();
protected:
    bool mQVFrDGRUcWowd;

    string CoWxSzYztBooBt(string oNEAx, bool qPHXNCQJwPsFFljL);
    int GcGoHrZwn(double ueOJuar, bool mqovYPcJ);
    bool FWrZPuAt(string fTBEJ);
    bool sGMVRV(bool gffDiwoTZu);
    string PuBdhEIjnuoYyYQ(string OzpcGcoEOYcMWCcE, bool fBLCDAKysBZA, string DwzUWBjnmkih, string ZZVEW, bool GBgxRrnix);
    string mearEwUnlvh(bool VSAfiX, int rQehJFrWJQTwv, string oJzTvwyj, double NHQWMFyv, double iULgYlbuA);
private:
    bool ADVivLqTFVdfW;
    bool WezWhxKHwhkIyvh;

    void xZbNTgG(double fDxBCyxYlAUaS, double huyoIu);
    int zsLoAgJkjs(int KwCnJpWzm, double NGTRqZKXZt, bool hozQEmjJgvNM, double tvGAmew);
    void LWbogdWnIKAHK(int qKtMifnqICzRanO, bool CErZUMztcUSYj, string XAKyWVLxcVNzFnkM, bool oAQBrDZGirSH);
    double SDFqsJOKNPG();
    string BUACGDH(double RVHLBOFGaejAUSa, double MXmqNYNW, bool gfnIdNRemWik);
    double EhSom(int xqpFSRDlhSJnys, double uXcWPnuXqis, double BjgwIXOoc, string kwLXSMXer);
    int PtEYInUonMjG();
};

string iKXmyIr::CoWxSzYztBooBt(string oNEAx, bool qPHXNCQJwPsFFljL)
{
    double ckwcuEGGDhJXQbx = 344554.2308706832;
    double QmicPLbB = 658238.3718466893;
    int OgIGqgNwuSIACs = 98748862;

    for (int KXXefvKYlP = 546573225; KXXefvKYlP > 0; KXXefvKYlP--) {
        ckwcuEGGDhJXQbx /= QmicPLbB;
        QmicPLbB /= ckwcuEGGDhJXQbx;
    }

    return oNEAx;
}

int iKXmyIr::GcGoHrZwn(double ueOJuar, bool mqovYPcJ)
{
    int AUjee = 2078326383;
    string fDUmGBa = string("qFCJyMjJMGSYVYwFPeSSGbGPajTAahHJdWqdIRWWXDutaRxWmLrUqTwjzGCjPyPmlnKfuwJNwyvfPcBNQByXqSeaWneJdbaDCpzQjMhNPkBNJAjtlRrRjLWBlgnQqdqlgJQRQJtlQ");
    bool gtpdnpCofUZO = false;

    for (int ZYMHVhVNh = 2099276550; ZYMHVhVNh > 0; ZYMHVhVNh--) {
        continue;
    }

    if (AUjee >= 2078326383) {
        for (int TUcstWcRbOU = 526268140; TUcstWcRbOU > 0; TUcstWcRbOU--) {
            gtpdnpCofUZO = ! gtpdnpCofUZO;
        }
    }

    for (int kfFisRkjoWs = 993460102; kfFisRkjoWs > 0; kfFisRkjoWs--) {
        gtpdnpCofUZO = ! gtpdnpCofUZO;
        fDUmGBa += fDUmGBa;
        gtpdnpCofUZO = ! gtpdnpCofUZO;
    }

    return AUjee;
}

bool iKXmyIr::FWrZPuAt(string fTBEJ)
{
    bool oIelIKDzOcvaaqH = false;

    for (int BRWis = 1281935138; BRWis > 0; BRWis--) {
        oIelIKDzOcvaaqH = oIelIKDzOcvaaqH;
        fTBEJ += fTBEJ;
        fTBEJ = fTBEJ;
    }

    for (int VyiJMDZlNQU = 1969744846; VyiJMDZlNQU > 0; VyiJMDZlNQU--) {
        fTBEJ += fTBEJ;
    }

    if (fTBEJ < string("DeCKRtHgffTKjWAjlEuhZOSMvwoSneyeCkTnXgYcBkeNqgMtVzqpmtYdSvGeEkiZtMDBbjYJufixCKSxXPVxTCFuVvIeyMvcvMimYxbmuoXQKOVDsZoXcXxFrmCwCFlbsJnelYuQWIXGFSSrWBpFicHXWJCtTLrGLNdBJcgDjYVgRwEfHc")) {
        for (int qvbiwEsUBkFt = 573979183; qvbiwEsUBkFt > 0; qvbiwEsUBkFt--) {
            oIelIKDzOcvaaqH = ! oIelIKDzOcvaaqH;
            fTBEJ = fTBEJ;
            oIelIKDzOcvaaqH = oIelIKDzOcvaaqH;
            fTBEJ += fTBEJ;
        }
    }

    if (fTBEJ != string("DeCKRtHgffTKjWAjlEuhZOSMvwoSneyeCkTnXgYcBkeNqgMtVzqpmtYdSvGeEkiZtMDBbjYJufixCKSxXPVxTCFuVvIeyMvcvMimYxbmuoXQKOVDsZoXcXxFrmCwCFlbsJnelYuQWIXGFSSrWBpFicHXWJCtTLrGLNdBJcgDjYVgRwEfHc")) {
        for (int sChlmqRlmmd = 501902593; sChlmqRlmmd > 0; sChlmqRlmmd--) {
            continue;
        }
    }

    for (int zSlVrngjGLrlVERb = 836622795; zSlVrngjGLrlVERb > 0; zSlVrngjGLrlVERb--) {
        oIelIKDzOcvaaqH = ! oIelIKDzOcvaaqH;
        fTBEJ += fTBEJ;
    }

    for (int gajYtzcfwprnB = 2093842937; gajYtzcfwprnB > 0; gajYtzcfwprnB--) {
        oIelIKDzOcvaaqH = ! oIelIKDzOcvaaqH;
    }

    return oIelIKDzOcvaaqH;
}

bool iKXmyIr::sGMVRV(bool gffDiwoTZu)
{
    string UXFLoq = string("XtQKUNuwZcarwuTDoNxLlqhOBAsCvTnIRADAKyIHxcXcGXwkWBPzBRhPApVLzYoznMMKRuQAgxtSBDcrqAFCqETqSQVKKylGIpVStctKLgLOPERdwTHsfOeSolBruDAhNXyRITTMGQqZDIbtdGFECNXRdnMMSitKCauLDUDvFRXnPWlOBVwmGDdliRtrtVOThvHKdCDxYGaZGhEgNrdNiONZnwBiaEwwzSWTKOKbmdkRozaHAMGsfleCAy");
    string RnqczvAULK = string("MQQNRHgybZqVVTDzjLAUQebLhSqxCMAGalkLglTZLSbiLDZyVmyoWYdmyRrRPMTfUSnuBpgOOvqEoVGymCKKsNmnwJHEjzshCxkdlnVSQYWdfFmGAkncYtMMydgNcnZrTFVpvvCtKLthIXQQWVgMMpUfulwCJMSxfcmRlAvZuICzcNQtYSLqvgUETaZXVWfgNFylcWLhAObVZUiaJNcbJWOvweQTxwxDowuYFGEMj");
    bool NUoZd = false;
    bool aPzNHD = true;
    string skAZqYp = string("wPSGeTGMEpmCQJNgSvguNzucjEuJONXflLCYYSbIgYBoKEFIEaRD");
    bool NyMVUMQPLQd = false;
    bool YdtVGrgqi = false;
    bool eAuorjRX = true;
    bool hTBxuteAlCHpxDn = false;

    for (int xFLPhTR = 758171001; xFLPhTR > 0; xFLPhTR--) {
        continue;
    }

    for (int CEjtTwhdExW = 1533030296; CEjtTwhdExW > 0; CEjtTwhdExW--) {
        eAuorjRX = eAuorjRX;
        hTBxuteAlCHpxDn = ! gffDiwoTZu;
        NyMVUMQPLQd = ! NyMVUMQPLQd;
        YdtVGrgqi = ! NyMVUMQPLQd;
        hTBxuteAlCHpxDn = gffDiwoTZu;
    }

    if (skAZqYp < string("XtQKUNuwZcarwuTDoNxLlqhOBAsCvTnIRADAKyIHxcXcGXwkWBPzBRhPApVLzYoznMMKRuQAgxtSBDcrqAFCqETqSQVKKylGIpVStctKLgLOPERdwTHsfOeSolBruDAhNXyRITTMGQqZDIbtdGFECNXRdnMMSitKCauLDUDvFRXnPWlOBVwmGDdliRtrtVOThvHKdCDxYGaZGhEgNrdNiONZnwBiaEwwzSWTKOKbmdkRozaHAMGsfleCAy")) {
        for (int yZYdfIqqzqUmjcTh = 735295167; yZYdfIqqzqUmjcTh > 0; yZYdfIqqzqUmjcTh--) {
            NyMVUMQPLQd = ! gffDiwoTZu;
            gffDiwoTZu = ! NUoZd;
        }
    }

    return hTBxuteAlCHpxDn;
}

string iKXmyIr::PuBdhEIjnuoYyYQ(string OzpcGcoEOYcMWCcE, bool fBLCDAKysBZA, string DwzUWBjnmkih, string ZZVEW, bool GBgxRrnix)
{
    int ZocawbPTcAQee = -780632952;
    double osmqZhXyiqh = -585386.4627469563;
    double HXGsBTgUyqJB = 504498.0562441674;
    int bDLVwRQvNS = -1999192625;
    int YWEbPtkBpS = 1861027958;
    bool xrFEffSvDIskNAF = true;
    int uaaNGHFWZGRvAl = -289535957;
    int rnFcMzSVvmcJA = 1826107252;

    if (OzpcGcoEOYcMWCcE < string("cBYHpRnqZxLGjGKfhUzTOTOgIYMAszy")) {
        for (int pgBpzZCFP = 162002406; pgBpzZCFP > 0; pgBpzZCFP--) {
            continue;
        }
    }

    for (int NhyUJfPqSaKBT = 497447455; NhyUJfPqSaKBT > 0; NhyUJfPqSaKBT--) {
        ZocawbPTcAQee /= ZocawbPTcAQee;
        bDLVwRQvNS += rnFcMzSVvmcJA;
        uaaNGHFWZGRvAl /= bDLVwRQvNS;
    }

    for (int gExAL = 1835892144; gExAL > 0; gExAL--) {
        osmqZhXyiqh += HXGsBTgUyqJB;
        DwzUWBjnmkih += OzpcGcoEOYcMWCcE;
        xrFEffSvDIskNAF = GBgxRrnix;
        bDLVwRQvNS = ZocawbPTcAQee;
    }

    for (int UhzFEWDtUAzoR = 624893048; UhzFEWDtUAzoR > 0; UhzFEWDtUAzoR--) {
        bDLVwRQvNS /= ZocawbPTcAQee;
        bDLVwRQvNS += uaaNGHFWZGRvAl;
    }

    return ZZVEW;
}

string iKXmyIr::mearEwUnlvh(bool VSAfiX, int rQehJFrWJQTwv, string oJzTvwyj, double NHQWMFyv, double iULgYlbuA)
{
    double VGEvIUszFWTxCA = -982518.7715148336;
    int GVjgLajJAzutlnot = 1428982377;
    double vaxhbrFd = 821775.0523071345;
    int LtmGDvZVjbysv = -1254877838;
    int gvOvs = -833742346;

    for (int ExYFjGnaTpzy = 827257029; ExYFjGnaTpzy > 0; ExYFjGnaTpzy--) {
        VGEvIUszFWTxCA += vaxhbrFd;
    }

    return oJzTvwyj;
}

void iKXmyIr::xZbNTgG(double fDxBCyxYlAUaS, double huyoIu)
{
    string TuyRg = string("RivuNKVToQpsvFqsTCtFbSJiQgnAQNhDBCuxIbRwTWPuNmaaUDOLQqCIRbCxzvXoHtckfLZTKPIROaDJehJbGyHNBlysAZJJmZuXCaMHDpibWjaaQfZJACkAWrhjxjxAgnfkvaGvgawKGqnFrtzHpADGVFwnwFMCHZkcZFVtGxcBIAxuKWZiUozybPcjdyQdTiGhLOiUqxQRcObcbEClPJobS");
    bool RAjCCIK = false;
    double vrNBReRExaAS = 699027.2720084422;
    int tWkSGBQALVg = -1555245501;
    int fkYLm = -461575293;
    bool NnKsOeJpiWohKfW = false;
    int hUZyFWrsbdXJDY = -155769282;
    bool NzaGKpvt = true;
    int pZKqRflf = -1830046981;

    if (pZKqRflf <= -155769282) {
        for (int VCTRgus = 141047990; VCTRgus > 0; VCTRgus--) {
            continue;
        }
    }

    for (int gRjTmzS = 566266892; gRjTmzS > 0; gRjTmzS--) {
        continue;
    }

    for (int YtUxtoiMD = 457239547; YtUxtoiMD > 0; YtUxtoiMD--) {
        continue;
    }

    for (int dbqSTwLG = 46697644; dbqSTwLG > 0; dbqSTwLG--) {
        vrNBReRExaAS -= fDxBCyxYlAUaS;
        vrNBReRExaAS -= fDxBCyxYlAUaS;
    }
}

int iKXmyIr::zsLoAgJkjs(int KwCnJpWzm, double NGTRqZKXZt, bool hozQEmjJgvNM, double tvGAmew)
{
    double iRmiGN = -646350.5316010591;
    int XHdQbAOS = 8333470;
    double SwzEfkf = 409867.8256869639;
    double UBHsoIDPCuoK = -106762.07310824566;

    return XHdQbAOS;
}

void iKXmyIr::LWbogdWnIKAHK(int qKtMifnqICzRanO, bool CErZUMztcUSYj, string XAKyWVLxcVNzFnkM, bool oAQBrDZGirSH)
{
    int xxLhE = -1067770040;

    for (int moEkPbPs = 705761887; moEkPbPs > 0; moEkPbPs--) {
        CErZUMztcUSYj = CErZUMztcUSYj;
        xxLhE -= qKtMifnqICzRanO;
    }
}

double iKXmyIr::SDFqsJOKNPG()
{
    bool wOEvFjcoBqCz = false;
    double ETlPik = 648069.3913441203;
    double ioEbkJv = 379999.69847924035;
    int AHUVF = 1845071889;
    bool LLgFTe = true;
    bool nrZNVSgEEse = false;
    double izYgp = -678185.4488029944;
    bool ktoGhPoAOUVE = true;

    for (int RKnVl = 671464091; RKnVl > 0; RKnVl--) {
        LLgFTe = nrZNVSgEEse;
        izYgp -= ETlPik;
        nrZNVSgEEse = wOEvFjcoBqCz;
        ktoGhPoAOUVE = ktoGhPoAOUVE;
        ETlPik += ETlPik;
    }

    for (int ZSrceXUJAbTM = 418263959; ZSrceXUJAbTM > 0; ZSrceXUJAbTM--) {
        ETlPik += izYgp;
        ETlPik *= izYgp;
        wOEvFjcoBqCz = wOEvFjcoBqCz;
        ioEbkJv = ioEbkJv;
    }

    if (izYgp != 648069.3913441203) {
        for (int InoOYkUTQYl = 1150294482; InoOYkUTQYl > 0; InoOYkUTQYl--) {
            ktoGhPoAOUVE = ! nrZNVSgEEse;
            ETlPik /= ioEbkJv;
            ktoGhPoAOUVE = ! LLgFTe;
        }
    }

    for (int vCUOOcSzjtMLjMn = 402866425; vCUOOcSzjtMLjMn > 0; vCUOOcSzjtMLjMn--) {
        izYgp *= izYgp;
        izYgp -= ioEbkJv;
    }

    for (int aNNnpX = 2100989582; aNNnpX > 0; aNNnpX--) {
        ETlPik = izYgp;
        ioEbkJv *= ioEbkJv;
        LLgFTe = ! nrZNVSgEEse;
    }

    return izYgp;
}

string iKXmyIr::BUACGDH(double RVHLBOFGaejAUSa, double MXmqNYNW, bool gfnIdNRemWik)
{
    int cGuEBVlQgA = -1600134362;
    double tggwMPJs = -170730.95992899008;
    int cZUvp = 397783109;
    int ecofXLSMRFKXIn = -1413143840;

    for (int AUAAoNowD = 447308123; AUAAoNowD > 0; AUAAoNowD--) {
        MXmqNYNW -= MXmqNYNW;
        MXmqNYNW -= MXmqNYNW;
        RVHLBOFGaejAUSa -= RVHLBOFGaejAUSa;
    }

    for (int AVHSX = 1640975377; AVHSX > 0; AVHSX--) {
        RVHLBOFGaejAUSa /= tggwMPJs;
        gfnIdNRemWik = gfnIdNRemWik;
        RVHLBOFGaejAUSa -= MXmqNYNW;
        ecofXLSMRFKXIn += ecofXLSMRFKXIn;
    }

    if (cGuEBVlQgA > -1413143840) {
        for (int WfGENjSPxLAKRhn = 1546591168; WfGENjSPxLAKRhn > 0; WfGENjSPxLAKRhn--) {
            RVHLBOFGaejAUSa /= MXmqNYNW;
            tggwMPJs -= tggwMPJs;
        }
    }

    for (int MPisToaBA = 1580894132; MPisToaBA > 0; MPisToaBA--) {
        ecofXLSMRFKXIn *= cGuEBVlQgA;
        tggwMPJs *= tggwMPJs;
        MXmqNYNW += RVHLBOFGaejAUSa;
        gfnIdNRemWik = gfnIdNRemWik;
    }

    for (int JpEfc = 1527295456; JpEfc > 0; JpEfc--) {
        ecofXLSMRFKXIn = cZUvp;
    }

    return string("RVjWhtUTPOBwJfylKBRIhkTFToXGeacTYbEMrTwrwXbJOfrrrdhVGmiMurZQeBeqiCktvTfvzOVSkdATnGmGEjUcWcfRDayeazRqTzPkzpCQprQXgtmJQKLkzzWcGNnwZdTJOqrBgvf");
}

double iKXmyIr::EhSom(int xqpFSRDlhSJnys, double uXcWPnuXqis, double BjgwIXOoc, string kwLXSMXer)
{
    string XnzytgTVmnlnA = string("EIEENMeDPWcPGIdAPhalGbMbyNypoBkSXOQCmuKDxHwuAjSSmqMmvVKegDKJMvQQSeHZQcNsnhjVcdwzPgBSQhjogKdgBqTNSXJJ");
    int rdPLEoMEOV = -1902275488;
    string VoYkMk = string("aUkGAWJYCOBLDMeFduyibYwnPXHLZSZUYJCYOMEuMzHLxXppmQzFFdMRGvgKVFcHdUPXIBbaLuXJwoWgFWoRASXMAfxNWLXByNgUHXNliFHDUXgLbBhJdKeLetmIZpTyRYNrCJkFDNutxnyBdwsCEuvLYRuOWaqqEPoMZLvXVnMSelctxCONgloFYlRVXBtLfxqBmVGYxCmYgngRHdCPotLxxPxzoZhiVBnvEkpQpRJKkftTtOjorAeUNWQEPmy");
    bool OUtLHROTN = true;
    int KztNrCjJepnmMJS = -799565266;
    string XcFGxYfeOeBDyMq = string("LKRlVsTEcGKLoqYocxAHbNuNCaQNOMGnMgLQamfxuveOsaBPhhOhhOleXidUjsBOwwDaTIDyOMRXTpDpHVBuXXDjSxLMiCxVzpdePLTCLwltTQHqcuzQCIDipmbxTwStlWDfRzsKBkIwnVYbiHbNmiNjeobNfJJnJSJEvLDomaBmQcdoypRphKBLRcHAiIoOSHPgiPopZCENBvhrpvjGaQYBFAkFVWEhlUiqfsDqv");

    for (int qPlDRuunZr = 2131925757; qPlDRuunZr > 0; qPlDRuunZr--) {
        XcFGxYfeOeBDyMq = XnzytgTVmnlnA;
        XcFGxYfeOeBDyMq = XnzytgTVmnlnA;
    }

    for (int ybEpCSV = 292190406; ybEpCSV > 0; ybEpCSV--) {
        xqpFSRDlhSJnys /= rdPLEoMEOV;
        rdPLEoMEOV *= rdPLEoMEOV;
    }

    for (int tepovnCiIiNQko = 1638444550; tepovnCiIiNQko > 0; tepovnCiIiNQko--) {
        XnzytgTVmnlnA += XnzytgTVmnlnA;
    }

    for (int hRZnKF = 1600913864; hRZnKF > 0; hRZnKF--) {
        continue;
    }

    for (int waCWlMPE = 619687412; waCWlMPE > 0; waCWlMPE--) {
        XnzytgTVmnlnA += XnzytgTVmnlnA;
        kwLXSMXer += XnzytgTVmnlnA;
        rdPLEoMEOV += rdPLEoMEOV;
    }

    return BjgwIXOoc;
}

int iKXmyIr::PtEYInUonMjG()
{
    int TpxXsNFxKwyX = 1289676252;
    string guKCnKzubzxBpzO = string("LezCEvkEEUGvNyldHJEBjixWbjRgeQHfklRGLEvHpMasTGNpuXlHgcbQnChvTV");
    string wYNIlSMmTbzB = string("GjTuEnbxCrLSODUSjTORO");
    string gUegRVtZf = string("MMhiVKpGGeOLyPrWWmekellDiLUFCqEEsdAIYIqVYgxKQSViUjWAOEGcEXWqqQoboLAJlxCTuJRtEEKnznvSYbJTwtlEKJZBChFtYOmWCAmVavHfhxSpIQfILRPUMEokKBtaPbyyfwIIkWFGFrNvWPeDMMCKgRPyPbBgGuqeZGjmzevJWXmNlpvFCrWrrEWonMqAJByICOnhOaLaqbTFe");
    double HqJSbAoAMR = -993305.6079255241;
    int srocXTq = 969708453;
    double RgkWMWGywMgQ = 893130.7146879409;
    int awlholIuM = 1624963226;
    bool IqXjyvJkQ = true;
    string qEWyC = string("xUirXRrdLPdvkFZGnDLbxjxqeCZIaTihAVQpuzXwTqrWdOkLwjTjgZWRNCFrasWEZAMdlYodxvOydHLppUKnzHRmSxGdyqFjvyYSAWRGdpcRFOvZFVYshlSYLOTmtnBeWkIYTgAHLDnDMULwguLRLWjsfPGOgqOrIXfzcMc");

    return awlholIuM;
}

iKXmyIr::iKXmyIr()
{
    this->CoWxSzYztBooBt(string("RrOrJKHhIINHdmbxSLisdpCQiyiAaYrGMrBtPKgFOcBhhonbiDFTfLcmKwMBUmPLPloRYvgwOjLrfracRapMVvRCEuKSCoxOcCkHOlJYhPvySkHPTbfIazlPsMEJihQifbELlITytzonQXfd"), true);
    this->GcGoHrZwn(182542.54022494363, true);
    this->FWrZPuAt(string("DeCKRtHgffTKjWAjlEuhZOSMvwoSneyeCkTnXgYcBkeNqgMtVzqpmtYdSvGeEkiZtMDBbjYJufixCKSxXPVxTCFuVvIeyMvcvMimYxbmuoXQKOVDsZoXcXxFrmCwCFlbsJnelYuQWIXGFSSrWBpFicHXWJCtTLrGLNdBJcgDjYVgRwEfHc"));
    this->sGMVRV(true);
    this->PuBdhEIjnuoYyYQ(string("cBYHpRnqZxLGjGKfhUzTOTOgIYMAszy"), false, string("ajlLmjRZiunFfXgWbRpdGTUFkEuYdGMlEUbyGUolmMohViwrijcpcDPzsuliexcQijQzQjLXwuaVDEBVHeWraYpWgpfApjSkmuPkIRLbRvtuRBSjRmFBrBVHuDYANCnFPjRePiBuiCqNNExXRYLjlxjAKuyubIADIyXCDVFAKFTQJVtiedQzoRumCXAnXGbpMfHtIPdykCLUogFfiOqPlqTyhdACxMpbkvFgeerk"), string("eoAqdmpKVMbcpAvCROemHaiybrvknSWQkkQOZHdgySTDOCELKUXTWzAcMblqWzhAfdkbEFCewnEuHKRCSgJOiZwxZAMmdxjPBUcVhBBXfquXckPRaiYtXnciLnSGqnJGCqIT"), false);
    this->mearEwUnlvh(false, 1858310108, string("crqSWnMLWmFTnEUAnRQySDzaSHDCVIiZanIIxhnEUrDFguBPwYLxPvDLcQkkJYzFixVGstrUyIEotgGzNQoXSYnLONOxiLbnMVpmSXTlURE"), -165290.95708910056, -12188.209228571344);
    this->xZbNTgG(11446.594975031257, -380566.7428937412);
    this->zsLoAgJkjs(-1484958746, 130049.10613088329, true, 491476.23234284366);
    this->LWbogdWnIKAHK(355542785, true, string("SGZbVhUyTJVOfdoAkDgYAbiOGSyVVsRYGWPdMHJEThSnDnFgSSiCazCcvHjwIAleiSBibweGhTsdAjboXGqaQZaICJSngBLMdSPuRQYCNhpJlInqckRuLhWSjqcESKwLOcJjNNuhrFcAkdYgSJJvVilqEcRcNAKEQsbdqGwMFpvQaKjKjABJyFcZTqMWesuAIgAcqGGfXpaStzUrQUJvmQHUrmvCDrJcMBe"), false);
    this->SDFqsJOKNPG();
    this->BUACGDH(605951.5139092095, -1041593.1788171735, false);
    this->EhSom(1477589639, 567903.2403803333, 468858.67537291645, string("MuytoqmWzvOrEYuRHeZSxuFmMFXBynPbQelptQkAluWMDAJmVZGdcdPsnKVzaHLrWlSbOxsaDkHDYnOkgBwdlGkGZDPJmjaVMuwwkdtBtFcDWIOldnWUZeYMABOLnjCndqNnCKXeGDvnFFrBGtZOFUKnsJjJPuuIWTafvwCvPMZkeGSphgadPAkvXzpLXRNxzcGqgVUYNwJwSjYNtbk"));
    this->PtEYInUonMjG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lOqTg
{
public:
    double qcPgcnjB;
    double UnmxbAHv;
    double gULAomNXvccK;

    lOqTg();
    string xINrynMfkwwQB(int IyHblhXXFkmYZgDk, string TDEru);
    void rwmgaLGZbWawjGg(double kpejV);
    bool kklTpoaL(string LwXysOMG, string GDFiQOU, int akPODxUIWRrDurX);
    bool dtBGNQleIPrC();
protected:
    string CxjeIai;
    double PkARrh;

    bool xDUjZsK(string QkmhZmzlEjM);
    int YGVXcnXfvKsG(string SXNtkTl, bool JtBGCBUPgzf, double qYvpcqWBeau, double YsTIbRhLCirgyewk, bool fIuDrQTvhcyyHHvs);
    bool iPMMlGWEU(double taUbtqPxAirfn, bool xITihjRd, int BNNPMqaGSXuDyxUg);
    void vIdpXTtErK(double USgqlXnNpItWW, double SdpjZiz, bool DqcnFFJW, double OlPauIjwL, string uWVOAuBmFXzKC);
    bool FlNPo(bool zNamNTDJSqJjmya, bool ebtQnnV, bool VJzGogfYlZApN);
    void vfJQZ(string TJVPznM);
private:
    double AjOolLGQ;

};

string lOqTg::xINrynMfkwwQB(int IyHblhXXFkmYZgDk, string TDEru)
{
    string KETvLNVek = string("XfEVjiAdBJhwBxbuQfKKhvzEaGYonoQmkWXlI");
    int STBlHBsvIRIl = 2074935767;
    double qUhMWfDcw = 899451.7338477734;
    double LqANTRERh = -45720.07902778462;
    double CdGpKcSBq = 701050.3370975596;
    double OKpsjt = -538798.4092409593;
    double jLdLbKxPsH = 678907.5183801872;
    bool lSrWPZEIt = false;
    int MNhni = 1770456069;
    int wrFbktRmJOsuCJA = -1770152886;

    for (int tBWzj = 1221993569; tBWzj > 0; tBWzj--) {
        CdGpKcSBq /= qUhMWfDcw;
        IyHblhXXFkmYZgDk = MNhni;
        qUhMWfDcw -= qUhMWfDcw;
    }

    return KETvLNVek;
}

void lOqTg::rwmgaLGZbWawjGg(double kpejV)
{
    string yZYEGTMSltTmzmir = string("QFTjVTnvzFNeeKWfIEexwqshgWgmKJQOLUZlJkigERxfEOPUOkUdDMDMRvjGZMkiJFESRDVbZehVyrTgRwPvdsvbBeaogZYNbaaBxCAzAGNGRnFMvtAwCeVzKIppilubWcOPMVXQhOxWRoRRvoYtUQEmzxUjpMYGoxOFAbFRjnyPubp");
    double NTUzLurqJqgJFc = 103343.3159861184;
    double tOxZtasHuDkxlQj = -273451.7222763182;
    double eaEATUKzL = 194529.21453244786;
    string irXgqRezA = string("qTvPpmETGOMSQBuefZcHhkYLNhTcwFMfnvUYKfopoWMZuXbXIDeqtgTQyZiwDVCmMaPEfmPSKSOvaUlzCZkbsjvrGAnHNekQHWUjkWwWlHQhubfeNRKpWCESoyVCObaaaFpzSFtpsLVnniCJFtWNNJxoXTqcOJPbYoTukaJTlZnKruWgyziolbMfXCIRBbbPUabEYTmGZU");
    int iohzdVo = 1682102670;
    int VykpKfJeNGf = 1943887072;
    int mRjAyQlezypQBu = -1086196622;
    double looyPYB = -833578.8999216547;
    bool CGITgkzMyH = false;

    for (int YhwzDxDHzhFm = 1700017583; YhwzDxDHzhFm > 0; YhwzDxDHzhFm--) {
        iohzdVo += VykpKfJeNGf;
        kpejV += eaEATUKzL;
        VykpKfJeNGf *= mRjAyQlezypQBu;
        irXgqRezA += yZYEGTMSltTmzmir;
    }

    for (int SBpyBBzyy = 1863517938; SBpyBBzyy > 0; SBpyBBzyy--) {
        NTUzLurqJqgJFc -= NTUzLurqJqgJFc;
    }
}

bool lOqTg::kklTpoaL(string LwXysOMG, string GDFiQOU, int akPODxUIWRrDurX)
{
    bool JDXciEShrrmt = false;
    int zSzisC = 1469882346;
    bool sSfPC = false;
    string guINREnBctf = string("OqSsNFbOYUDGxdEeRkBPCtRDZpAEQuWFVrjYINmuhsPHLNuvkDLAKRitxxXnlSVdHnaRaxBRBJzPgsMBcwFUPdRwsOrmTbvbSdlBCmbWXMIezXirkltsssGpiMSBpBjmdIyq");
    bool IJsJvBCdCfU = false;
    double pasbDoyuwTZR = 443743.1272597789;
    string RbTSJ = string("XZRQVlYQpNISPbADpzpXuwoqfHEfkgszIxlGYknyFvbZtjzqJlaWwLUXXMXvCbWPVDvGIjRdsnTkqVrYmtRPfjxFjbXUZTHtMbxHHrFZTWhgMPRsDZWMhriFpp");
    int YnfFqUN = 121760878;
    string qcHRbKpOYinfWkA = string("DTqHVbSfSxkImJFAlYDsFTdWXDwqqefWckZjWpwYqegmxITXCBoirOHcUaAnSbubKqxKimLdZoinbKPxngecJJhURBcLBGgRctpUeaIBIsYMTbrWHecadzqmtwfhAMuixCNOtJiJoylCVtFhLhsfZjrLaIFRCmbASCsxUFNUpetRkPDBYEUwUKEpQmQTdeljdePmL");
    bool ABRplQLXgmTE = true;

    for (int rJbqRpSxY = 664190601; rJbqRpSxY > 0; rJbqRpSxY--) {
        ABRplQLXgmTE = JDXciEShrrmt;
        RbTSJ = RbTSJ;
    }

    for (int PRToAanZlyNvHpq = 477119352; PRToAanZlyNvHpq > 0; PRToAanZlyNvHpq--) {
        akPODxUIWRrDurX *= zSzisC;
        YnfFqUN *= akPODxUIWRrDurX;
        LwXysOMG += qcHRbKpOYinfWkA;
        sSfPC = JDXciEShrrmt;
    }

    return ABRplQLXgmTE;
}

bool lOqTg::dtBGNQleIPrC()
{
    bool wfENgBBX = true;
    bool OZLbTgHcO = false;
    bool txHutItvVWqtx = false;

    if (OZLbTgHcO == false) {
        for (int QnFDMJWjTkkIkIJ = 1214219577; QnFDMJWjTkkIkIJ > 0; QnFDMJWjTkkIkIJ--) {
            OZLbTgHcO = ! OZLbTgHcO;
        }
    }

    if (wfENgBBX != true) {
        for (int qhpQrrZ = 1558819796; qhpQrrZ > 0; qhpQrrZ--) {
            OZLbTgHcO = txHutItvVWqtx;
            OZLbTgHcO = wfENgBBX;
            wfENgBBX = OZLbTgHcO;
            wfENgBBX = ! OZLbTgHcO;
        }
    }

    if (wfENgBBX != false) {
        for (int iSppwlBiooiZ = 810302105; iSppwlBiooiZ > 0; iSppwlBiooiZ--) {
            txHutItvVWqtx = OZLbTgHcO;
            OZLbTgHcO = txHutItvVWqtx;
            wfENgBBX = ! txHutItvVWqtx;
            OZLbTgHcO = ! txHutItvVWqtx;
            txHutItvVWqtx = ! txHutItvVWqtx;
        }
    }

    return txHutItvVWqtx;
}

bool lOqTg::xDUjZsK(string QkmhZmzlEjM)
{
    bool xbEIZMYlBJWLPQf = true;
    int IlJsQ = 1452191042;
    string OKQslhMBplJq = string("mkXdHwpGiolKwLnmlBJmPitVaLGuyuiVRtAdjiZjXmukaCCMeXnkwmTRCGyhePygdSUioiyQLtCseqZQfTnoqjUKSdlWQXBrUEjtqBhZurzqJxpYWtkXfYGOYuvMwKiIAYjOhXjqiRCnnQUnZyhJxOjghOVsOxOhY");
    int LtkmzfGtbWwuJ = 1924788163;
    int XfTKujzsOoMbdSMJ = 522609249;
    double xHlCXednmyHULr = -724245.0990143903;
    int razaGhTCivXx = 897175305;

    for (int oIwIJEwbBDuKSz = 1641795128; oIwIJEwbBDuKSz > 0; oIwIJEwbBDuKSz--) {
        OKQslhMBplJq = QkmhZmzlEjM;
        razaGhTCivXx *= razaGhTCivXx;
        QkmhZmzlEjM += OKQslhMBplJq;
    }

    return xbEIZMYlBJWLPQf;
}

int lOqTg::YGVXcnXfvKsG(string SXNtkTl, bool JtBGCBUPgzf, double qYvpcqWBeau, double YsTIbRhLCirgyewk, bool fIuDrQTvhcyyHHvs)
{
    int LCjHdWtUaxEymTCd = -2146869662;
    string ocYWIaJAFbYf = string("mYLEiXvNxnMSdqdZDjGuITuRubSkzZqPplNnpnVmCeDpRHCgxQgzRbVRlJEiSfpDhqGPITAvCFnjpupFMqhRtiEUiTItDjTqyMJTCSDkDbEIksKeuNtRxuBbCixVFZxJYonZPxgDtEeCQCStyDqXClUJjvoiburaRNGtdVbelFizPGBilZemeLhuQBvzrNACxrXiHZdXPgZdeKPEMgvZIrsOqbAfrpxbVZvTZQpPfKbdeKzGZsENsKeLLHn");
    bool gohpvbiNVUAmZkej = true;
    double TjOjfmeKBL = -911421.4882253011;
    double gezGqDQEOMOQCv = 404103.56543845;
    bool EWcWqpMssEsnPZN = true;
    bool EIPvpEOvVA = false;
    bool fyxCm = true;

    for (int BVqMUSWE = 1553270232; BVqMUSWE > 0; BVqMUSWE--) {
        gohpvbiNVUAmZkej = fIuDrQTvhcyyHHvs;
        EWcWqpMssEsnPZN = EWcWqpMssEsnPZN;
        SXNtkTl += SXNtkTl;
        gohpvbiNVUAmZkej = ! fIuDrQTvhcyyHHvs;
    }

    if (fyxCm == true) {
        for (int gkSPpparJATHeFtP = 312963371; gkSPpparJATHeFtP > 0; gkSPpparJATHeFtP--) {
            fyxCm = JtBGCBUPgzf;
            EWcWqpMssEsnPZN = fyxCm;
            EWcWqpMssEsnPZN = ! fyxCm;
            YsTIbRhLCirgyewk *= TjOjfmeKBL;
        }
    }

    for (int XyhgUb = 1757171974; XyhgUb > 0; XyhgUb--) {
        TjOjfmeKBL /= TjOjfmeKBL;
        EIPvpEOvVA = ! fIuDrQTvhcyyHHvs;
        gezGqDQEOMOQCv = qYvpcqWBeau;
    }

    return LCjHdWtUaxEymTCd;
}

bool lOqTg::iPMMlGWEU(double taUbtqPxAirfn, bool xITihjRd, int BNNPMqaGSXuDyxUg)
{
    double BBYYEXzITpj = 728854.9626315224;
    double GLrqfXtaIQBKfY = 853342.2221888452;
    double rLAvxi = -32708.911942104212;
    double OrnKIRIJ = 1036702.5762015677;
    int gAVGMLTiUSfnX = 1879174439;
    string wzKVkRwQHLelO = string("DKDcNYlmGJkMWunFaposVVVbpHKJrRqhIymsWekOfmJjYMDVAGiNlUPhrJVnQATGDkNvMrZqASxLFrKrIlNfUJdzqAHiTZbOrqZjwgUzTDXkSNMVnVyPMwZCdPBFrBwMPviBlANtiNPsOTyJnXdEHyETABNTcVYOHXgauzRsvaeszQnWaEsHPRBnQbhGRGYhNokWaPtNIuwzDytmuqocLYPVMofQIvOQKGGRvswhBHaiLvTTzNkpUpmbsSZ");
    bool oqPxv = true;
    string wdBLGXErkXarO = string("hTeoCnrjzhlHmqKXltBYAbOyurlxtQAKEditpsnMNoCAdxXHVqVgKltibPklAnjralUmTFMtbYHLxrqdTVEyHnAJTjTtutnmus");
    bool bdFTqyJ = true;
    string hDsrGRWD = string("zZuNrmwpbYxPlGRVcsab");

    for (int FEQNvjWPSEANxh = 1373409774; FEQNvjWPSEANxh > 0; FEQNvjWPSEANxh--) {
        GLrqfXtaIQBKfY /= OrnKIRIJ;
        wzKVkRwQHLelO = wdBLGXErkXarO;
    }

    for (int PgjTyHxTTRz = 1566077024; PgjTyHxTTRz > 0; PgjTyHxTTRz--) {
        OrnKIRIJ *= taUbtqPxAirfn;
        OrnKIRIJ -= OrnKIRIJ;
    }

    if (wdBLGXErkXarO != string("DKDcNYlmGJkMWunFaposVVVbpHKJrRqhIymsWekOfmJjYMDVAGiNlUPhrJVnQATGDkNvMrZqASxLFrKrIlNfUJdzqAHiTZbOrqZjwgUzTDXkSNMVnVyPMwZCdPBFrBwMPviBlANtiNPsOTyJnXdEHyETABNTcVYOHXgauzRsvaeszQnWaEsHPRBnQbhGRGYhNokWaPtNIuwzDytmuqocLYPVMofQIvOQKGGRvswhBHaiLvTTzNkpUpmbsSZ")) {
        for (int GYfOPIWHao = 227867508; GYfOPIWHao > 0; GYfOPIWHao--) {
            gAVGMLTiUSfnX = gAVGMLTiUSfnX;
            hDsrGRWD = wzKVkRwQHLelO;
            rLAvxi /= BBYYEXzITpj;
        }
    }

    if (OrnKIRIJ > 728854.9626315224) {
        for (int irMtAERSZqmqWre = 1243100928; irMtAERSZqmqWre > 0; irMtAERSZqmqWre--) {
            continue;
        }
    }

    for (int IMwqgYJeYfCOHRcX = 178418566; IMwqgYJeYfCOHRcX > 0; IMwqgYJeYfCOHRcX--) {
        continue;
    }

    return bdFTqyJ;
}

void lOqTg::vIdpXTtErK(double USgqlXnNpItWW, double SdpjZiz, bool DqcnFFJW, double OlPauIjwL, string uWVOAuBmFXzKC)
{
    bool HReLTcwyXiZqd = false;
    double yjgKmglVfzaRI = 32520.376035593887;
    string ibYNLeMfVFy = string("thoGmRCJIReTfzlSmgfmqtofZdffXfLcVlBKjQbTEFGULifwUdIamHhJcRYFRZdmtTELXfDOVMNLHqE");
    int NBoAlHIxt = -571752784;
    int mjgTkSiV = 439259776;
    double KMjjrKab = -503390.40502366377;
    bool kqqXnmW = false;
    int YvfxNhsy = 1112174356;
    int wCtyET = -754708813;
    bool UnKJKREvCK = true;

    for (int BlGOvOToOZGcHln = 705547220; BlGOvOToOZGcHln > 0; BlGOvOToOZGcHln--) {
        USgqlXnNpItWW = USgqlXnNpItWW;
        OlPauIjwL -= SdpjZiz;
    }

    for (int RFXKWTu = 1253583776; RFXKWTu > 0; RFXKWTu--) {
        uWVOAuBmFXzKC += uWVOAuBmFXzKC;
    }
}

bool lOqTg::FlNPo(bool zNamNTDJSqJjmya, bool ebtQnnV, bool VJzGogfYlZApN)
{
    double iUlIDk = 775403.5922577404;
    int vEVRCQlRMicfDi = -347260383;
    int HfkkAcWzvqqBiLl = -1032735663;
    bool vxeRjVFnbGWIka = false;
    string JFILJuDFzs = string("BOYAIfGAgEvgBzkXVvBsPcmFkZrcjtVKMkvHyxPwIfJGVESVOlUfFqDTcplKxujf");
    double BeIBpw = -84917.24859164374;
    string hIzHPLfJVCZ = string("kYuuBagpcWWYbkQqxHitPKgHYRTLHACeZnwpOEaJeXRHtayCPRuhqzBfmXWNFVakuhBpOfhEgwDdzXDaBrCaPQgbTGuIuvYiahHWuefACoVpWDgAUYYtmTrKfQVROoBmEnBQuurIRxbUMjxiGPvbrTLWpPQzVexEzKKJOeDVIKzfimFt");

    for (int JAIKdSSUHWoSTvAp = 1551635870; JAIKdSSUHWoSTvAp > 0; JAIKdSSUHWoSTvAp--) {
        continue;
    }

    return vxeRjVFnbGWIka;
}

void lOqTg::vfJQZ(string TJVPznM)
{
    int fPXFmaFdp = 1360378616;
    int mpikysCLxfnhsY = 1587920228;
    double BSZQlmZsiTTwxKCd = -287558.0987614363;
    int qyAXcoiR = 1679361577;
    double aKODmvxkH = 723078.1848957392;
    int azjReXb = -1447160898;
    double NoaUd = -532992.5328182132;
    double kWrOWUValmRjBf = -60838.78221671756;
    int rwxINTvqAOJNHJo = 120730409;
    double RevSvHFSp = -835123.0490116152;

    for (int yGizCOpUisTPhhJa = 1102082414; yGizCOpUisTPhhJa > 0; yGizCOpUisTPhhJa--) {
        rwxINTvqAOJNHJo -= fPXFmaFdp;
        RevSvHFSp /= aKODmvxkH;
    }

    for (int XoubffzDMJedN = 2066876723; XoubffzDMJedN > 0; XoubffzDMJedN--) {
        rwxINTvqAOJNHJo = mpikysCLxfnhsY;
        mpikysCLxfnhsY *= qyAXcoiR;
        NoaUd /= kWrOWUValmRjBf;
        kWrOWUValmRjBf = RevSvHFSp;
    }

    for (int wUzXCkSDYoP = 1980459438; wUzXCkSDYoP > 0; wUzXCkSDYoP--) {
        NoaUd -= aKODmvxkH;
    }

    for (int dQPNZFlxmLwXJ = 2142221718; dQPNZFlxmLwXJ > 0; dQPNZFlxmLwXJ--) {
        aKODmvxkH -= kWrOWUValmRjBf;
        qyAXcoiR *= mpikysCLxfnhsY;
        mpikysCLxfnhsY /= qyAXcoiR;
        kWrOWUValmRjBf *= aKODmvxkH;
        mpikysCLxfnhsY *= qyAXcoiR;
    }

    for (int VhDkZtuoTUwqbPp = 1068313985; VhDkZtuoTUwqbPp > 0; VhDkZtuoTUwqbPp--) {
        azjReXb /= qyAXcoiR;
        NoaUd *= kWrOWUValmRjBf;
        fPXFmaFdp *= rwxINTvqAOJNHJo;
        NoaUd += kWrOWUValmRjBf;
        NoaUd *= RevSvHFSp;
    }

    if (rwxINTvqAOJNHJo == -1447160898) {
        for (int EdzftNkGzSKvD = 2133627478; EdzftNkGzSKvD > 0; EdzftNkGzSKvD--) {
            azjReXb *= rwxINTvqAOJNHJo;
            qyAXcoiR += qyAXcoiR;
            aKODmvxkH = aKODmvxkH;
        }
    }
}

lOqTg::lOqTg()
{
    this->xINrynMfkwwQB(1940977270, string("TYJGbfKuuHofNLeZvzwsTvcbDCINTNJXXutGTFNkrdOXdgGAdIhfuvmgZQdrZNRC"));
    this->rwmgaLGZbWawjGg(-263560.7273090722);
    this->kklTpoaL(string("vUbbZfkcorZhmRYKxtOSXTplnhEqkEMzEOwPlsbQinCnsnnTgwaSlrLreDcvEQMOTpgBIGiyPEWnwQjBGUGtNSLaohwwdsgrQxyToGWDNOMeqlupqYKxkgFSyYOktqjHvHyEdKrzXkXkfzNPazJqToFYwlkERAYclpB"), string("YWCyEBdpvQliImRzzAoEmHsfjenWhbMPolwNvCKlXZdwuFtIoMKDkpkuXBYHoCSJHLzsSUQqNblRmAajwCkoQrStfnIvbsgWUJFJWcxERwQAiKXUwsYHevuCgXztEinDYCneuoTPCBIutZYNmgCUxjITDakYjGPZdRlJsRvsjgvWEUKTvfJbtVtAWcGFFkzzoTfDDu"), 523727713);
    this->dtBGNQleIPrC();
    this->xDUjZsK(string("QZUZERsCpkwOLMbLSpsdaSFLrQmEnPbcZefsXnTUtTHsGjOTKHxXbpYDofvmdmhfIcqBVKRDDhyhDGrdivcudVHsgTpgunekekRnnEZNfRahwTQpxZfktdrDzLivrojUygUERdaFodMhsnDMGuVXbcwpJLnMFBtutzxhkgFfarREZoZWfUainGnzPkfxQTyBMpuIiCvGYFPUbDDXMqaJEF"));
    this->YGVXcnXfvKsG(string("KOYWElDSfIDtuFSadRizbbEFzeFOVDBpjIvXPiRETojpGorxbEArrmPmzTFRREuNRMQkpiexvevxJHYOuNGiEJsiIaHvtFhwEfQWUAaMuitKtvhlSZCZTxetxZPSxscsFNmcKEPggHmwRzNFEJdWHoquSjkQFEXqRHmmymTZDxxIyTJkmYHfODlTnHD"), true, -463451.1348905819, 374221.74295186147, true);
    this->iPMMlGWEU(205405.94510514685, true, -1698414923);
    this->vIdpXTtErK(-328311.0108399439, -676758.0585448496, true, -572372.0410967986, string("kCDfsKaIdYjfOSlzimivGZltZxQGwlOUXBsMRWsVIUttrdrvIDoXDROgvpJzazuhlibgCTovniLvPPGSKsLKeblGZPcSTMnSpXqOzgZBmRPSzxYZUTUdpyGZPnsTX"));
    this->FlNPo(true, true, true);
    this->vfJQZ(string("WnbheHOzoftPqEXpZtiznAfnSeifQUjCYboNBwFcJKPOZFbAsWnNunHGwpdfTnNwEsFbcOONFFXodIMBsGFlPKhdeDZtgaMuPzDZYcoCmMdYVOoKqcwGjetTjwJJMBGlzUMDGYQOktICDNLJBVbmVOraNfkojDsjewelbQaqEsiENkKyzmVPBYYxcgpuZKnopbawMSWtIJQBlTEnbXDvAPzBvJEgui"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZyhhNStrdJfkvnj
{
public:
    string IrSjwCUN;
    bool YbxgihYOWjT;
    bool kjVaVplOm;
    double vDdzTzkGADcDXb;
    string Rdros;
    double ZKPqLF;

    ZyhhNStrdJfkvnj();
protected:
    double jTMUgdfXrcPvQ;
    string cESzugxvZlm;
    string aKNUqGVzLTUb;
    bool zcvuV;

    string ZOnHwLQydR(int FTdivt, double Ibfwuh, double KqMhmoF);
    double dSUstBCQl(int himrMycqFvBxWpi, int xKwLFFxCNudqYE, string wcRfQYahXztjbV, bool nWXHXVsUyoTyf);
    int xLqRwMdtZmHJzh();
    string cmyuitglJOQqM(double FQNkpMcsBQdFq, bool rpwZvPFLvFcIvg, int audNlPhtPagz, string xOSqqEzNIt);
    bool ahwgJWm();
    double IbjEsXWz(int petmlOfkbqnx);
private:
    int iRdBupukNGpSX;
    int XtAitaaONqlOrzi;
    int LeLFZRJX;

    void ggsheotyIvwWMf(bool OeQKIUpXU);
    bool UeXfWnRhURmbth(bool tBMrsUVKvss, bool VWCjSmcZUHhi, double rCico, string latltkqv, int cMIYwWJAwaXv);
    int CAkmPLzieGKZyU(bool NWUrLTPUEXT, int uMsgiIFYVwuAK, double iZiqrkmLVhnppT, int lzfHwuA);
    string afHyfuaL(bool dvWaUd, string JcQkNSPUOMg, string KfEleY, string ZRfEjIVhRzwLwsS, int vGBJr);
};

string ZyhhNStrdJfkvnj::ZOnHwLQydR(int FTdivt, double Ibfwuh, double KqMhmoF)
{
    bool zepDKhkynkZpq = false;
    bool bTNitdJNXnkLX = false;
    bool xZBfmZtXXBurTES = true;
    bool TIMixMTme = true;
    string bitEnIyYPGR = string("iHIGPLOInowgTfGMejgPxfOuFYwYsXbwKUiXmVjapMKpJbwIMzGOlqYhvoBYglXlvUMZCuSygsSyUqzlrrsvpGMTchKBgOFTTfaoIUkLRWmXOYAGbYKFlywruM");
    bool GxIEBWzNTATDXVhu = false;
    string ryIKxicuUkvD = string("BlfranaBjfJmqzwixScrYOrtSeEmMoBUcAqEcPZQDTAdnwABCztSiXpUPlVxPWxNKiBJQpmxmEPvsJwMdawMYfsdWoBweUAmloszoCJHPCgPQPwpvnPuXMNYiauYhXiDKJULKoBQyKCMcXDlAaTIrapqGLuJOZwbnlmHDisGXaMAyYhOvTaeoQomBeXeDBkDatmdHAviokqgonqGm");
    string PFrEhDsxkD = string("kgzSbejZjISjbKQDtJJYJ");
    int dTtVGOFkoKSVgo = 1004470294;
    string oLfdOeqPO = string("CschuwvWgtJzEdaTSXDnKKBXjEMDDaKFTDBzkAjGusmFCXvPJlQDbkHOuQTMtcbYzRQrQFenWCVfIhrhJEYkpdZstnKXlnryyISPvsrmcLLONuAopdTPjxrGKeCWTRaNKoy");

    for (int XnNxPmmeoBJsOnO = 1344438189; XnNxPmmeoBJsOnO > 0; XnNxPmmeoBJsOnO--) {
        continue;
    }

    for (int LRUsTuTAv = 657623004; LRUsTuTAv > 0; LRUsTuTAv--) {
        TIMixMTme = GxIEBWzNTATDXVhu;
        PFrEhDsxkD = bitEnIyYPGR;
    }

    for (int MWuWhHxBWsALjyv = 2018506139; MWuWhHxBWsALjyv > 0; MWuWhHxBWsALjyv--) {
        xZBfmZtXXBurTES = zepDKhkynkZpq;
        zepDKhkynkZpq = ! xZBfmZtXXBurTES;
        PFrEhDsxkD = ryIKxicuUkvD;
        TIMixMTme = xZBfmZtXXBurTES;
        PFrEhDsxkD = ryIKxicuUkvD;
        FTdivt /= FTdivt;
        xZBfmZtXXBurTES = TIMixMTme;
    }

    return oLfdOeqPO;
}

double ZyhhNStrdJfkvnj::dSUstBCQl(int himrMycqFvBxWpi, int xKwLFFxCNudqYE, string wcRfQYahXztjbV, bool nWXHXVsUyoTyf)
{
    bool ilQBTp = true;

    if (nWXHXVsUyoTyf != true) {
        for (int avYuRRmxsnRZ = 661703072; avYuRRmxsnRZ > 0; avYuRRmxsnRZ--) {
            ilQBTp = nWXHXVsUyoTyf;
            nWXHXVsUyoTyf = ! nWXHXVsUyoTyf;
        }
    }

    for (int ogGEHeW = 512062932; ogGEHeW > 0; ogGEHeW--) {
        nWXHXVsUyoTyf = ! ilQBTp;
        himrMycqFvBxWpi += himrMycqFvBxWpi;
        nWXHXVsUyoTyf = ! ilQBTp;
        xKwLFFxCNudqYE = himrMycqFvBxWpi;
    }

    for (int yDmTKoKoi = 1023664695; yDmTKoKoi > 0; yDmTKoKoi--) {
        wcRfQYahXztjbV = wcRfQYahXztjbV;
        nWXHXVsUyoTyf = ilQBTp;
        xKwLFFxCNudqYE = xKwLFFxCNudqYE;
        nWXHXVsUyoTyf = ilQBTp;
        wcRfQYahXztjbV += wcRfQYahXztjbV;
    }

    if (xKwLFFxCNudqYE <= 1003932934) {
        for (int GWLuTv = 2145699916; GWLuTv > 0; GWLuTv--) {
            ilQBTp = ! ilQBTp;
            himrMycqFvBxWpi = himrMycqFvBxWpi;
            wcRfQYahXztjbV = wcRfQYahXztjbV;
            himrMycqFvBxWpi = himrMycqFvBxWpi;
        }
    }

    return 970474.0136281135;
}

int ZyhhNStrdJfkvnj::xLqRwMdtZmHJzh()
{
    double yMrPCZY = -384716.43885352195;
    string LiWiTcroCqNIkrs = string("CQpFapeSJIcdhQsGDGiWfHXitbGtadbDAreeHIYzUIZQlqVLjYYZaJDhDcIqjJkDvWorSUMsZLIWifCBcgtxPKSFjyoCkheJndVbfhwwqYchrmZuyJuAKCYdydjimzApxogkanQnIEwjnLPLBdwPQUmRXqaDqFhSSvbtyDZhryszUuLpkKfUyVsmnRteKUbZhlMFBwFPaJFemY");
    double dezxAoLzpMeGfV = 476598.98527833226;
    bool gTbvwlqivJHt = false;
    double TkqWx = 91989.95449360176;
    int ngluYOECFuWe = 985974275;

    for (int BQqpLdJRbCg = 2089789086; BQqpLdJRbCg > 0; BQqpLdJRbCg--) {
        ngluYOECFuWe *= ngluYOECFuWe;
    }

    return ngluYOECFuWe;
}

string ZyhhNStrdJfkvnj::cmyuitglJOQqM(double FQNkpMcsBQdFq, bool rpwZvPFLvFcIvg, int audNlPhtPagz, string xOSqqEzNIt)
{
    double yEScJk = -97905.16554830766;
    double CykPAyLjKKn = 361423.64265324274;
    int jwCQXSqX = -589497484;
    double cmbffgNhz = -166760.17850300565;
    int VwoGGkJtR = -633624850;
    string lmrNBPOtsZ = string("eyTpJetRkOoJEXWzseyEzXAwMlIRvivHyfKgrwPERWSlxEfKUsGVrChLFGvrLDbGAjVsTWHhYHANJhtVldIzKaXEfkMeJFOaTsUeuzyyqaBXPjkXxEoREucNNQtJWikbCzeplTMFWJpxbAmxGNzs");
    string UHiKXgQ = string("HcOMOlqfqmGDFgLRMobBwUlBYgDqfGXygvRBXqDUWjQkTylwgwrWgKNMTNCxCbBXYSzbsxgFzRYcbBbWDwUwIwjJXHQcBuHjCqbECyodfzaRdZceyFwDdUqNPQEG");
    bool iYeewF = true;
    bool YtGtNnezOZOfvT = true;
    int ZMYUVC = -2017225122;

    if (CykPAyLjKKn != 361423.64265324274) {
        for (int nLjzejZPuJrBTK = 900213055; nLjzejZPuJrBTK > 0; nLjzejZPuJrBTK--) {
            UHiKXgQ += xOSqqEzNIt;
        }
    }

    for (int oiPxetOvSOikbA = 186996153; oiPxetOvSOikbA > 0; oiPxetOvSOikbA--) {
        audNlPhtPagz /= jwCQXSqX;
    }

    if (FQNkpMcsBQdFq != 883927.1029179116) {
        for (int IwoTCqVLpuNW = 777889481; IwoTCqVLpuNW > 0; IwoTCqVLpuNW--) {
            YtGtNnezOZOfvT = ! YtGtNnezOZOfvT;
        }
    }

    if (rpwZvPFLvFcIvg == true) {
        for (int kkGEi = 1780751270; kkGEi > 0; kkGEi--) {
            continue;
        }
    }

    return UHiKXgQ;
}

bool ZyhhNStrdJfkvnj::ahwgJWm()
{
    double JMJnnimZto = -769168.9579233833;
    int xSFpaWI = 1173309946;
    string msBfAnhIX = string("rSrQOCfoyWVwIIASJnYvxicxjsJJbeyEdtJCCbWaPRgmPRIKFMYFESOFjvbItggPgzaKUyitAwFDkWVNuzvAFqrVWTasgtBHqrDmWVuDRcoKSGOmtygRfaYzjAFKylmFBsg");
    bool dYswsOIeX = false;

    if (xSFpaWI < 1173309946) {
        for (int bcpjzfxD = 1120283431; bcpjzfxD > 0; bcpjzfxD--) {
            xSFpaWI *= xSFpaWI;
            xSFpaWI = xSFpaWI;
        }
    }

    for (int XVpRNaqVqvTx = 1475459232; XVpRNaqVqvTx > 0; XVpRNaqVqvTx--) {
        msBfAnhIX += msBfAnhIX;
        dYswsOIeX = dYswsOIeX;
    }

    return dYswsOIeX;
}

double ZyhhNStrdJfkvnj::IbjEsXWz(int petmlOfkbqnx)
{
    double gLfaP = -510071.9915970749;
    bool OmGfaZzm = false;
    double zGKGmUDyC = 624025.17546766;
    bool CFdPnCMkvA = true;
    string SRgippYXzJHlYuv = string("TTPqYYEhIkxcsUdPcKUuFdNZEztNphBSHUJwYrzaMGsYVTszTrlxcRfAjQOROpOsKHRHbtceJBX");

    for (int KZsYTuNZ = 570029303; KZsYTuNZ > 0; KZsYTuNZ--) {
        CFdPnCMkvA = OmGfaZzm;
        zGKGmUDyC /= gLfaP;
        OmGfaZzm = ! OmGfaZzm;
    }

    for (int UBIuqmyPPkFxHz = 357348523; UBIuqmyPPkFxHz > 0; UBIuqmyPPkFxHz--) {
        continue;
    }

    for (int FKRvaAUdbwOswyKl = 1136776734; FKRvaAUdbwOswyKl > 0; FKRvaAUdbwOswyKl--) {
        CFdPnCMkvA = CFdPnCMkvA;
    }

    return zGKGmUDyC;
}

void ZyhhNStrdJfkvnj::ggsheotyIvwWMf(bool OeQKIUpXU)
{
    double ykOoY = -435589.10547132423;
    int dzWsT = 248738338;
    bool gMUufTgCQQ = true;
    string GbGwPTbZvqIG = string("OVVYMYSTCMWGioiakIxLWuSxyGAhMnqMUaZwKCuYCXNutdvchJdxppXBqpwSSnnqXIunlhCxJqlfyPOqdMkpbBRkWleQXpEHucdCWEwCCOzQDiXpidTZzuLyAtfEmoWjtGdmQIOThYoYytAjygVNuLAQlJpvFQkQulzXDHCLZoTygxpdUimETpbiYPHGqqePiBunOlhCaFAPiNcGskIIVWcdBCsOqJguSsyzyffmBQmeNQsVgZrnW");
    bool dBrZrcAVLQaf = false;
    bool ghGWgfmpPsAtAx = true;
    string CDnnwJClXDssDlH = string("bysfAqDJadMkWspSIniFfsQtoftgMaSaCFjvZqRJqjnFvjQxbzlfssvuwcPMdodudtLqBfYTfwDDKaSNnjQyjlBedNyP");
    double QqPmpgyy = 643454.8135948693;
    int fbRqJSMLHOtZmJH = -1222144573;
    double BTBxoP = -593324.4281592855;

    for (int kXAVOx = 1931739085; kXAVOx > 0; kXAVOx--) {
        CDnnwJClXDssDlH = CDnnwJClXDssDlH;
    }

    for (int IQdWAkBJXlFxSvLJ = 539012885; IQdWAkBJXlFxSvLJ > 0; IQdWAkBJXlFxSvLJ--) {
        gMUufTgCQQ = ! OeQKIUpXU;
        OeQKIUpXU = gMUufTgCQQ;
        gMUufTgCQQ = ghGWgfmpPsAtAx;
    }
}

bool ZyhhNStrdJfkvnj::UeXfWnRhURmbth(bool tBMrsUVKvss, bool VWCjSmcZUHhi, double rCico, string latltkqv, int cMIYwWJAwaXv)
{
    string UjOHKTpgQy = string("orHxTeKYEhNsrMjSzJBibghtXJIIIrvpqtOcSRpsPIUDnjXIFYyChliPehBNjnaoscTnqlbLipLgeOgIxkWcmlbwBNiBDRwKhFYgVwoySfAuPYqShfPgQLPXUm");
    double UoaYvqgfSrFrH = -114521.77022640775;
    string peIZDq = string("NKuXDMUmQcgcfcTxAyUmHEKswbYsbwdepstxgiwKbggjqhjbcTaUKmYqbaLMxRIiEkQUKGknqFpOAQzEMtCMWqjYLvyBVZeHClaJfiqYBMYVmmOjUxHbTK");
    double QQaRzSjQtr = -314741.3249237247;
    string CqGFeljEdpLcUMN = string("gzItZukcKyiUGKRRPlamtJRTjjgbOMUClaFDNNTNOtFTpOuDrkSLHgsqzHeLRhrovwvuPVRqLceFZWRRNSrckiUzQwZpWaCLhONpfhfmVMnzgSkboVsyzhzMyhOWpsQWYgBUutRshLOdeSjDKslRsjCLPIZJkbmqWIxnSksCYjHnZyIVhhohKBkDpxtKHLWxMeyrBFVBIJQxsxoLlzobdiLltNdwZtZDO");
    int EkmZdVLPzL = -1919407107;
    string BIzlK = string("zXcnLSkFWKMUGgjsTbUFMadTPeITgLQxEnBQgeSBfMuHGGXUErAHqMLByOrQwXieKipWVIowAzAZTZjPcdzrVB");
    int zlSHtxQMPWJZETSa = -131400795;
    string bGnBTHMhr = string("IyzTCjxDsJJinsgCcDSAdaDkykOEbPvVnNnuJtKqYHKTSlqAVWmbvsARwHTJkUmJFslSMdxPgQgilnGjQzngxScRfORIkvgmjlaQNAyEeenVGPKJGVmUhQZpATqhrKeDyibvDQIEEPOeobdsJiNgWCHwyQJivEeBBAquUICHURtjVeUnoxaakEIsNIUjzKVYSQRsGICnprYiehvDvmijtwuQucmt");

    if (QQaRzSjQtr == -314741.3249237247) {
        for (int LsDGxviJDwvuUfRz = 1649240846; LsDGxviJDwvuUfRz > 0; LsDGxviJDwvuUfRz--) {
            continue;
        }
    }

    for (int cAKSDqGJfwEGazjb = 1854040387; cAKSDqGJfwEGazjb > 0; cAKSDqGJfwEGazjb--) {
        latltkqv += BIzlK;
        tBMrsUVKvss = ! VWCjSmcZUHhi;
    }

    for (int BlHSXEJfqZ = 1856957002; BlHSXEJfqZ > 0; BlHSXEJfqZ--) {
        continue;
    }

    for (int MmMpYEmuxdS = 64856131; MmMpYEmuxdS > 0; MmMpYEmuxdS--) {
        zlSHtxQMPWJZETSa -= cMIYwWJAwaXv;
        tBMrsUVKvss = ! VWCjSmcZUHhi;
        peIZDq = peIZDq;
    }

    if (cMIYwWJAwaXv >= -2107799689) {
        for (int eslTgZsnxrtnzpvB = 195250640; eslTgZsnxrtnzpvB > 0; eslTgZsnxrtnzpvB--) {
            BIzlK += CqGFeljEdpLcUMN;
        }
    }

    return VWCjSmcZUHhi;
}

int ZyhhNStrdJfkvnj::CAkmPLzieGKZyU(bool NWUrLTPUEXT, int uMsgiIFYVwuAK, double iZiqrkmLVhnppT, int lzfHwuA)
{
    bool gUIsPNbqFgaQHdRE = false;

    for (int BhMbX = 1239629554; BhMbX > 0; BhMbX--) {
        continue;
    }

    if (iZiqrkmLVhnppT == 176473.6675735651) {
        for (int EqRDaeYJtfjH = 1349294210; EqRDaeYJtfjH > 0; EqRDaeYJtfjH--) {
            gUIsPNbqFgaQHdRE = gUIsPNbqFgaQHdRE;
            iZiqrkmLVhnppT *= iZiqrkmLVhnppT;
            uMsgiIFYVwuAK += lzfHwuA;
        }
    }

    return lzfHwuA;
}

string ZyhhNStrdJfkvnj::afHyfuaL(bool dvWaUd, string JcQkNSPUOMg, string KfEleY, string ZRfEjIVhRzwLwsS, int vGBJr)
{
    string NahSvmBorJDEkMpJ = string("BnSZCQMnHbANWuCGAkaioIfxTvOJzcPCYuQkenGGxfcumyoHyMLxeRScgfqdDwvMbPngHbNMhnjMyCbUSMduyyRCERFAxqNBhsnddBCmhQLbDgGOSAikRsHIreqhCikEQYRJLmVMMKmKkMRcSwGUCIpGIUmcCITqofncwdBDDwsvikYLgyFMTKyIMdGCPIXWtRCNDQZtqnySslhrkimZykxjvom");
    double ShFFfAFV = 1016953.7287152929;
    string DqfscKQxPBIyhuXE = string("pgAXQpStruQHIjXfFJhYZnVJTETgQHOyKjZXWTkZQfGefcvIlmSozuoudyEmTtkBLvheUWSBDAiGrHUBxWKUvVKqkRxASsvfnXbKarSVxlJCMrfrBPcEqiuEJyvfqlhPVrUQEKHZNaFJAJKAeUKmxSLGNnONbxZGajwoHynWaKgXhJQtYBNLwPSXZIGEiDuUAgBaaIVLK");
    double IGpgacmCHhvJTG = -842608.4198978379;
    string JSrvQMuZx = string("GpFKljUbzVekYvLQFxeLnDqiEoRxePICXydlDRxqYXPKlPopgBvckbMBLxEvFNPgXXeYYNEKMADIVvWOdxVghmOsiaBVYlTAZfcNFuFXOnGcjVaChFTsrxUgQVrESpzeboBqArsJIzKiBTJ");
    double rnrgJJ = 965636.6691139325;
    string oPxgTwyiodAGkXZ = string("XHbrPRtDjnpTvwmuglbKxmwxBeHrflMpZkkAMlvvBWgLiivCOmiBHgwYIvNmeEGIYWWEFwAIvOKfITGLKuIVYJVPVCDemSXFcDADQBZqXLGtyaDkTvhYABy");

    if (DqfscKQxPBIyhuXE != string("dHEfqocbTXLHSPlhXwZcxFhBDBdiHWjymqGlCPWxwFJfVVXlbTvnIskgsbshazHZxvmLCucAtamsAobOtIjaNpVQeQdwhLPTVZYPamZtMLRJvvDNbqkpsvyhuATOUBrWbGXMsatFWuoxNduHEgocXbHMPgDDpPytKZiPM")) {
        for (int hdUtJEdABIW = 1379351465; hdUtJEdABIW > 0; hdUtJEdABIW--) {
            ZRfEjIVhRzwLwsS += oPxgTwyiodAGkXZ;
            rnrgJJ /= ShFFfAFV;
            rnrgJJ /= rnrgJJ;
            KfEleY = ZRfEjIVhRzwLwsS;
            vGBJr += vGBJr;
        }
    }

    return oPxgTwyiodAGkXZ;
}

ZyhhNStrdJfkvnj::ZyhhNStrdJfkvnj()
{
    this->ZOnHwLQydR(-1141581858, -624276.286847172, -210286.9105669788);
    this->dSUstBCQl(1003932934, 1719020268, string("SkvyjFtUbLVCAzwpMqulwjLwEceuqHANiSjFIcBWcKxlmftOyocshbMzAvVGvxCtkJVgiKKjDX"), false);
    this->xLqRwMdtZmHJzh();
    this->cmyuitglJOQqM(883927.1029179116, true, -334707694, string("dhnJKPmUtBPOXLzxfIgvNifNvveqzSARtzGbdhCBWIeVyglqHXpcorbwLUEjfTJmjtqfjxGMYZoSbbgqFMQXpsifvjyHTAbagvJzUAKVzCzPKhxLJqKjsLVXMcYURcvGhyhGabXbNlJxFElroscBZSoezPUTiTgMShsiOpbjAdwngVdKdoMBpSaVwIOcprhdNSSAaJULQBetvvBFjslmmUWDjprTvbtRLksEZwsJQlkbJlHKdztk"));
    this->ahwgJWm();
    this->IbjEsXWz(1968133119);
    this->ggsheotyIvwWMf(true);
    this->UeXfWnRhURmbth(true, true, 326400.78215722303, string("EGpXtVfxthGQxLWmaeEfjnlCXlSndRSdOWYLSipjWceDKCVvlaFOtOsACOKTOjLINCFgFKxFdSSpQPpWmYDuhemmnAFmgWSJFOILWKUWWjykaWozSKRvGmJXQIyPNiBumJJzLufcULByktyuNtMZpmcmMcimGDCGTcGreipKmyJWIAnFcStiIuJUFeRmQljZIUZCHAGAQYDdpWVGhVFsPfuSKOCLFXVgQoEhijJZviOnsCNFu"), -2107799689);
    this->CAkmPLzieGKZyU(false, 765648072, 176473.6675735651, 790401482);
    this->afHyfuaL(false, string("IQMEKamZEvcKVaMqoMZFiYiGiEaFTsMedmERAgsbUhKOcgsLvnVtJynvrXxzQOchIBQDxAaSEqNRDWnytJCqPeCtmcwxKANeHsHBkwYtdMiNBuNxetEKkGGTPvkiqldxorOlCNoiDPrSoIOuTCOPoiSmLzbQTbgavyKNuIFHEZtWGeoUTglpdFEWFtHRUTfwverhfXO"), string("usnmQhKuGxnPcukxpUFdOCgDeelhNpBsJOmFcTCwSgTyKsPjETUYJROGpuCMlMdQwPbrxMruiPkmEOgzhopyYRyPBzhkYaJHvtKxXqgJiZtxwpkTKZvzfu"), string("dHEfqocbTXLHSPlhXwZcxFhBDBdiHWjymqGlCPWxwFJfVVXlbTvnIskgsbshazHZxvmLCucAtamsAobOtIjaNpVQeQdwhLPTVZYPamZtMLRJvvDNbqkpsvyhuATOUBrWbGXMsatFWuoxNduHEgocXbHMPgDDpPytKZiPM"), -1940776107);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YUKGpWrEltJHDMYh
{
public:
    double xLbYnUsqEGF;
    double qGtQAGfLzg;

    YUKGpWrEltJHDMYh();
    bool IQivaLa(int DWrfPJczMDQIdaeo, string jgdDFyKBBWREyzy, double sQXxbPCaps, double ObJnmyeB);
    void ebVsFoNH(int FHMAafnGZffK, bool yPRcn, bool RNDVkUZMH, bool tFrtidzALxC, double gWMGK);
    void wKAFa(double kQPEOxLI, double SZEhpr);
    int nUsBW();
    double CQnuppLbcASzGie();
    void KhredvajgEhQS(bool IFGINzQ);
    bool ZfNEwYXGJyIdKMTf(string laBsIxsmulJscbF, int iBDDjLEpgsLjL, bool DSDuS, bool AzqVEYjxUPqg, bool bWNYnGQQaaVI);
protected:
    int fquDhJUojqlK;
    double dsxUKmQhAGu;
    int ABFnhfy;
    int tILTaD;
    double FklXFtTNwqadGfLs;

    bool oDutjrKabmJTL(bool ahqzgBEo, double uKBicmdNhJCbU);
    double oEecUhppOqiUy(string zaBdWhdIqs, bool ttXAgnRyBGhJjOi, int jCOuHddEItMkrrM, string ObQLP, bool yclsYkxuuYYsI);
    void uDeMWQ(string mCXBfrVCoiajwe, double tqiWXinuCtFnkNEI, bool FdUYYYdqESU, int itUUAoZLDgdO, double FFraVzsR);
    double ORxYGpBBaTKaDKDb(int DEgAbbJcCsJ, double oWuTHG);
    int lSGwGfxdcmOhRn();
    bool xpMvJYoFZaE(double BdmwXjnBVgyqsA, bool XCjSIxTCeVtUqkRS);
private:
    int ReyLxBRrWZ;
    bool nfKTosGhISsdrw;
    double BCxZLfNMAYhDhVgA;
    bool wYKoRvHcTvEG;
    int IJGHLQHS;
    string qDFeEpsAQVMF;

    int NQOSNyCsJFBXu(bool KfVIxkAxcBYU, int lrSovOCkj, string TQbcsMDJxTqI, double FnumWQ);
    bool qOhCUnhYUqrOb(double xnopD, bool PQlAdchGtD);
    void pcKCiwYHn(string cmuBx, int tgNhXyVug, bool fEVaTPUCB, bool kOyFNEUOrX);
    void RGlQrgpyurCKJ(int BVtEf, double gmIjsqUIQQxgiOZO, double thfjeEDbRh, string iIxeQUVsP);
    bool QCSCXLSxwP(string eVGWUhKz, double bLwBRTnklmPnvo, bool GpusSofhefHy, int VSCxGkfn);
    void EJRga(string ghzCLr, string TMqIWNyqBwybzQMP, double mWmcykpS);
};

bool YUKGpWrEltJHDMYh::IQivaLa(int DWrfPJczMDQIdaeo, string jgdDFyKBBWREyzy, double sQXxbPCaps, double ObJnmyeB)
{
    bool lfpLsZdR = true;
    string OFtkSaXhe = string("QOvLDyMDIeREkKRNbjWwSqqaCMYyTmqWGYdmDGHIXxzGGbfjXAteFZBXcEdsPrkGZusTyOyxUqBwRXOxvitrqmAXRKUwOoUGRIMbpKoDBKYxKHnfQASvBeIVGhjeyNrrDwzgujGYAmMhXycTuoghvqdfAWDDCbRKOcyoOfrDbdMMSqcuMXBDxlSsdZcnFuaO");

    if (ObJnmyeB != 161675.22023542333) {
        for (int aLNkrXHCZYi = 501942413; aLNkrXHCZYi > 0; aLNkrXHCZYi--) {
            OFtkSaXhe = OFtkSaXhe;
            DWrfPJczMDQIdaeo -= DWrfPJczMDQIdaeo;
        }
    }

    return lfpLsZdR;
}

void YUKGpWrEltJHDMYh::ebVsFoNH(int FHMAafnGZffK, bool yPRcn, bool RNDVkUZMH, bool tFrtidzALxC, double gWMGK)
{
    string QfzqmuyjPS = string("zTSedDjuQblYvumLugtXCxIWfzFGVgdCsfwLUCEtjTrThlOWBJFEUBBHxCjysAxOpkuXxBAWNObQKOZqRvAVbiSNhatDNnKiDHoCqUegFvVvQuSQTWoXelbpRyUCNuqknQxMStfcdQORfGopAyUpKRAMnulflFSLTLuOFqtkfZMdVvzURvARJkEGRrdAncPCZERMAYVfmwHvRgsVapGcXSrzVwwfITiiPmcEnKsfWzuNTwL");
    double jneDbOqBVmuYRbGh = 1035619.2679743698;
    double qUfaO = -292779.5915311419;
    string wjYHjQqbYurCr = string("ylPanjuvSgHfeuqjwWbsKkkBtdazclIlzIZQTEXQTTmSUftISCLDdGLzkHNoBPGJMdRqWHfqUqlKXWkAfoQgWiRFhQMRWhbchRhLNySgilpdfdGKUkSNefzrlsEEChFjMCoCtisycAmsjBcnewPTCJlOEzYWxZMYUCWHlzCgh");
}

void YUKGpWrEltJHDMYh::wKAFa(double kQPEOxLI, double SZEhpr)
{
    string QgDWjyAReg = string("rvCygUbztFLzmPNoYHgiNxYjPpcrWGvJzitXuhipdsWUhlaVPcJMTKJrsKhZvQsbDbKSUZwKEdfLyjHVUhtLKNpmciwoqvvYtOmHBjutTgBGRvfvdoSCecRSNmhJJpauFaFTqgpXpphpaFXbRImKGjPEQVHxblgZFPQGoNIhEVAjbvRhQKuMGLWoejrQzRTihPsXziFrTF");
    bool euaLPtwQuQhvxb = true;
    double iFXKsEzxqUpjE = 646905.1235284518;
    double BazAaEJXu = 652901.3658003157;
    string hLZsKpvGWdW = string("GqYQPBaCtBfOnPowDaaBlucCmDKJcwYBOqpruXzLBerFMlhysOlBcakvJJOcPPyIXeJrJhItqVNucxAhhmNwDVGGpZnFJQeWdDaULXQXtwRjojJxqKEHlOiUctORGNiAvzOAHMKdkrwZfxPFzSHWHWNiilduxypAASOEcqZhYp");
    bool MiVMu = false;
    bool ZnCNGmXJs = true;
    int EbZthxtrWQALpxj = 1893204817;
    double HAQOkdWxsPqg = 322675.29302897234;

    for (int tDvanuQU = 1566942869; tDvanuQU > 0; tDvanuQU--) {
        euaLPtwQuQhvxb = ! ZnCNGmXJs;
    }

    if (ZnCNGmXJs != true) {
        for (int mbAHhwriWoHVyq = 742293376; mbAHhwriWoHVyq > 0; mbAHhwriWoHVyq--) {
            continue;
        }
    }

    if (HAQOkdWxsPqg > 461973.72728195036) {
        for (int qPVpa = 1820619361; qPVpa > 0; qPVpa--) {
            SZEhpr += iFXKsEzxqUpjE;
        }
    }

    for (int wVAwPiStkWbrtBl = 284911152; wVAwPiStkWbrtBl > 0; wVAwPiStkWbrtBl--) {
        continue;
    }

    for (int mOmcPUTozSVr = 1557980793; mOmcPUTozSVr > 0; mOmcPUTozSVr--) {
        kQPEOxLI = HAQOkdWxsPqg;
    }
}

int YUKGpWrEltJHDMYh::nUsBW()
{
    int XxEYvvbUVH = 1535690646;
    bool JeaAeZRpvsYMH = false;
    double OOWcSvHB = 729761.0646714824;
    int mbnABoRIwEdC = -915411909;
    int kqWpAJO = 1271602269;
    bool xQyuuvRoHzV = true;
    bool cLWKBEYeh = false;

    for (int uPAzdgyvm = 1076567931; uPAzdgyvm > 0; uPAzdgyvm--) {
        cLWKBEYeh = JeaAeZRpvsYMH;
        kqWpAJO += XxEYvvbUVH;
    }

    for (int lmwkMCJTripvNNX = 1636237054; lmwkMCJTripvNNX > 0; lmwkMCJTripvNNX--) {
        xQyuuvRoHzV = cLWKBEYeh;
    }

    if (cLWKBEYeh == false) {
        for (int QNyzdiwCpJ = 1922411873; QNyzdiwCpJ > 0; QNyzdiwCpJ--) {
            mbnABoRIwEdC /= XxEYvvbUVH;
            XxEYvvbUVH *= mbnABoRIwEdC;
            xQyuuvRoHzV = ! cLWKBEYeh;
        }
    }

    if (xQyuuvRoHzV == false) {
        for (int IrPTpPYsrFux = 699847912; IrPTpPYsrFux > 0; IrPTpPYsrFux--) {
            continue;
        }
    }

    for (int rUcVuZlSQjxjCT = 197671998; rUcVuZlSQjxjCT > 0; rUcVuZlSQjxjCT--) {
        mbnABoRIwEdC += mbnABoRIwEdC;
        XxEYvvbUVH *= mbnABoRIwEdC;
    }

    return kqWpAJO;
}

double YUKGpWrEltJHDMYh::CQnuppLbcASzGie()
{
    double PHCqEoXaxdVazcys = 1036249.6227092906;
    bool NlBGCzBriQUK = false;
    bool UQmuVDilEHYrJKWR = true;
    bool JkyCCsquITkWB = true;
    bool EvORdOroJwX = true;
    string ESpokXPfpl = string("IbyHZraslaAOZZtrMCnOPZKKWKZtckmcZCEYReJvirgTrMxJAxTUuTgLQTpbEFOuAMWUuHQGFVQLAhamObOuGWfcKKakjmlUYmphgEsMsnPppIXYBUuAtWVCacwyjgOyrTqNjamvHoaTyDszKlSyqKIBlIzaiYmthDybvKNeSLrUQHzOAVVaOTyGOVrBoqSdFmsUVAglWMtTJCFyfCOnZHUtrIhKJivMtOO");
    double QvjyRpfwidQ = 540053.9170559939;
    bool ByfPQm = true;
    int RMxRLFNNj = -1279383943;
    bool xHUXBprSErtn = true;

    return QvjyRpfwidQ;
}

void YUKGpWrEltJHDMYh::KhredvajgEhQS(bool IFGINzQ)
{
    string hTewqjU = string("FcqUUafcvWBPNDaKlKkYvpvpzrSsGDnpCghCjNtJjo");

    if (IFGINzQ == true) {
        for (int xTtclHGdcITJWpW = 444585771; xTtclHGdcITJWpW > 0; xTtclHGdcITJWpW--) {
            IFGINzQ = IFGINzQ;
        }
    }

    for (int wNeslqzARwFBKWh = 105748817; wNeslqzARwFBKWh > 0; wNeslqzARwFBKWh--) {
        IFGINzQ = ! IFGINzQ;
        IFGINzQ = ! IFGINzQ;
    }

    if (IFGINzQ != true) {
        for (int OxIbvGCDasWO = 1488662051; OxIbvGCDasWO > 0; OxIbvGCDasWO--) {
            IFGINzQ = ! IFGINzQ;
            IFGINzQ = ! IFGINzQ;
            hTewqjU = hTewqjU;
        }
    }
}

bool YUKGpWrEltJHDMYh::ZfNEwYXGJyIdKMTf(string laBsIxsmulJscbF, int iBDDjLEpgsLjL, bool DSDuS, bool AzqVEYjxUPqg, bool bWNYnGQQaaVI)
{
    string FGpmxtvGQQneoJk = string("KSIoBM");
    double HXcTk = -124520.61865511177;
    bool payOsDZnJZT = false;
    int LRtWIlThCrnC = -758689548;
    string ACwDBqPYYePRxTe = string("CoMInEGIBTfCBmAUfhVAqzX");

    if (payOsDZnJZT == true) {
        for (int FQZKpZKqiOFMFPF = 372675215; FQZKpZKqiOFMFPF > 0; FQZKpZKqiOFMFPF--) {
            continue;
        }
    }

    for (int ytTcACqad = 97312607; ytTcACqad > 0; ytTcACqad--) {
        continue;
    }

    for (int LYBPdhsMvGnTqKMp = 2011015291; LYBPdhsMvGnTqKMp > 0; LYBPdhsMvGnTqKMp--) {
        payOsDZnJZT = AzqVEYjxUPqg;
    }

    if (DSDuS == false) {
        for (int EtLmyugBUz = 427068561; EtLmyugBUz > 0; EtLmyugBUz--) {
            LRtWIlThCrnC -= LRtWIlThCrnC;
            iBDDjLEpgsLjL = LRtWIlThCrnC;
            AzqVEYjxUPqg = AzqVEYjxUPqg;
        }
    }

    return payOsDZnJZT;
}

bool YUKGpWrEltJHDMYh::oDutjrKabmJTL(bool ahqzgBEo, double uKBicmdNhJCbU)
{
    int lOlGmVqM = -412864075;
    string MoiGjOU = string("DctJIvDydidULcRZxbMSLyFsCOhnKEYzWSQxtqpJsEInVkDjnzQNcuJWgjPKbBgRqKuiHYcxIIyUyZsCeaLqPaKzLlZXFojMuFolMjwtVWRwEPybELmLrBoYBZarefkdVsYtZJDWywBXoKJVKuikjsodBIWfEAGYex");
    double ERhfahIcAGbdZB = 129890.19085351752;
    string WJvsDNjK = string("JGbKhWncxhBswcTtENzQDPmWCTUlbbClLDGMLlTrgdVmAMZgjAOGsvuhnpnfrMPWqqHgLyLQjgIqDfKiassgSGNTcZBTaawlCGFZkCAbjMESEneraqCUPIgATmSFDHtkwJwuCXHVaaFjXYqjfSaRHLhFjRjPblCummGAzkEpzZPDkKCmkxMIhxeyEfPEYopeuyAqrZpywlaxKqhfufvRKljvCwycU");
    int PRDfYHjZhOKbQUYz = -248075054;
    double CPuZC = 263686.7394655224;
    int LgwlWuev = -564630719;
    bool BbNFLvtoOnmgAsE = false;
    bool DgNpHpd = true;
    string erlZP = string("DnGhcVsHnZehEnGzjeOTjqvMaYlOucTtxbwJliyuERomKlleLsULDqMRZdslHlswldtVZEdNYJRtTbrfoHdmEMsdmuxsZvKbukUOKycEgqnpxdLEWEzXnReYMIijzdUCEVIhUMEOZqFZODmGgPAgKdDyG");

    if (PRDfYHjZhOKbQUYz > -248075054) {
        for (int wlFCiUvuRRtVETG = 149015328; wlFCiUvuRRtVETG > 0; wlFCiUvuRRtVETG--) {
            DgNpHpd = ahqzgBEo;
        }
    }

    return DgNpHpd;
}

double YUKGpWrEltJHDMYh::oEecUhppOqiUy(string zaBdWhdIqs, bool ttXAgnRyBGhJjOi, int jCOuHddEItMkrrM, string ObQLP, bool yclsYkxuuYYsI)
{
    double gHtWHaJfolpRqK = 707067.3699423576;
    bool RizYHMqhUKYtRmxP = true;
    double tPhEnkagJprVwQ = -597811.6910026795;
    bool ykMykARcFAAyFV = true;
    bool DebbNlPEAuiG = true;
    bool ICvYFcqFXQZFzUR = true;
    int MvrgyyiQ = 1334197993;
    int LgIYOf = -1866907712;

    for (int sXrfIDYnWSrROI = 1130001647; sXrfIDYnWSrROI > 0; sXrfIDYnWSrROI--) {
        continue;
    }

    if (zaBdWhdIqs == string("jIPYDGVgyMVMipBoOgQEpoTunHASnJDTXnUMjAsdvEdnKgPyUybqOkvZlzqXdcwcxXHKLl")) {
        for (int XQLHnoOYYpENN = 1299900086; XQLHnoOYYpENN > 0; XQLHnoOYYpENN--) {
            tPhEnkagJprVwQ = gHtWHaJfolpRqK;
            DebbNlPEAuiG = ! ttXAgnRyBGhJjOi;
        }
    }

    for (int dNHHkV = 2097456394; dNHHkV > 0; dNHHkV--) {
        jCOuHddEItMkrrM *= jCOuHddEItMkrrM;
    }

    if (ttXAgnRyBGhJjOi != false) {
        for (int nZhnviuVtAk = 587864110; nZhnviuVtAk > 0; nZhnviuVtAk--) {
            DebbNlPEAuiG = ! ICvYFcqFXQZFzUR;
            LgIYOf = LgIYOf;
        }
    }

    return tPhEnkagJprVwQ;
}

void YUKGpWrEltJHDMYh::uDeMWQ(string mCXBfrVCoiajwe, double tqiWXinuCtFnkNEI, bool FdUYYYdqESU, int itUUAoZLDgdO, double FFraVzsR)
{
    double MYxoM = -370546.3292395941;
    double vzuwYcCNIiW = -332675.24230732414;
    string DGcfJVZqqGQqiD = string("AMDYSsFehzjgbZSpBKUWIymxxsQYYqfjMevJyUKBrdtzzJVEQWJonCBOFmlrvGPcWhPVxkUOhpaXdtsssHYIXFWWKMJwOrRTsvsWrlhREgJRVcPpXXdZVvuuIaRHaaLvPMOcsahySMcqJpUQpSqQiCTHCOQocWfbdfybBtwPIHjFGtqBjpTnWYySoIiuMWuMUzkSCkzqJocp");
    string HiEgdi = string("eTwXbdDPfHeJUUYazGAbtzcDqFYxgyyUYMlwZQqnrVFmgDRNoZQoPYkaRUWTktSSvFHmOwTUDOQdXYhsLeRDRwtwMLMdPuSNlPpPfMGvFMiwjHsPpqJkUaUUoxeEOpQqDmiHWPGvRonjadgnSUNejdeKAp");
    int bXkgT = 1472888063;
    bool NXOFGObFSDHKvhB = true;

    for (int NgDbjdNWOeVESjzA = 1891658756; NgDbjdNWOeVESjzA > 0; NgDbjdNWOeVESjzA--) {
        vzuwYcCNIiW = MYxoM;
    }

    for (int NxvqvrtHbNXeDAF = 529054890; NxvqvrtHbNXeDAF > 0; NxvqvrtHbNXeDAF--) {
        itUUAoZLDgdO /= bXkgT;
        vzuwYcCNIiW -= MYxoM;
        MYxoM -= tqiWXinuCtFnkNEI;
    }
}

double YUKGpWrEltJHDMYh::ORxYGpBBaTKaDKDb(int DEgAbbJcCsJ, double oWuTHG)
{
    bool GQGYOJeaekiUMde = false;
    int TJOCfnyWRckJF = -1976637912;
    int uBFZemWghOqZDFj = 363628332;
    string rwIfadd = string("ZwxGQgpgtwUAzeMlCOSUxrImFUiVFseHdXTeqvtgRfpQESwgeDnZAbKnVqqVhBqcKlHOAXqXSplafrbVUCqeRyuRgwRZZdoqMUUZWNMaShucoOmohhPAUoEuEXZgitXGOZSJZv");
    int zPcThUJGndRN = 1325139068;
    double ohVNSRJqxsHPt = 399681.6508530103;
    int OrFMzIqIZ = -695554464;
    string hZRpBJceHK = string("MnqEIrMpHiIsztaYEHuQTXTzWpkEBaztiCixMjegyWVggJoCQZNSoFgUTJTueeHBvCKaxkTUcXTniSojIIlLnUBIsIRDtxCuVFfNKqhiXqBddoxzdYhDQTibXZBMABmOBZBCLAoMH");

    for (int UZOGtSHNjcqVvEJ = 721574695; UZOGtSHNjcqVvEJ > 0; UZOGtSHNjcqVvEJ--) {
        continue;
    }

    if (OrFMzIqIZ != 363628332) {
        for (int TnwqbaEJdba = 1904872853; TnwqbaEJdba > 0; TnwqbaEJdba--) {
            DEgAbbJcCsJ /= OrFMzIqIZ;
            DEgAbbJcCsJ -= OrFMzIqIZ;
        }
    }

    return ohVNSRJqxsHPt;
}

int YUKGpWrEltJHDMYh::lSGwGfxdcmOhRn()
{
    double hLtgTOAqTsY = -222184.1283488759;

    if (hLtgTOAqTsY != -222184.1283488759) {
        for (int qqPOtYkvLQcPu = 2028489474; qqPOtYkvLQcPu > 0; qqPOtYkvLQcPu--) {
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY /= hLtgTOAqTsY;
        }
    }

    if (hLtgTOAqTsY >= -222184.1283488759) {
        for (int SowGRxoCocTdPaa = 1752270213; SowGRxoCocTdPaa > 0; SowGRxoCocTdPaa--) {
            hLtgTOAqTsY = hLtgTOAqTsY;
            hLtgTOAqTsY = hLtgTOAqTsY;
            hLtgTOAqTsY -= hLtgTOAqTsY;
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY = hLtgTOAqTsY;
            hLtgTOAqTsY /= hLtgTOAqTsY;
            hLtgTOAqTsY *= hLtgTOAqTsY;
        }
    }

    if (hLtgTOAqTsY == -222184.1283488759) {
        for (int uehxk = 1453758734; uehxk > 0; uehxk--) {
            hLtgTOAqTsY /= hLtgTOAqTsY;
            hLtgTOAqTsY -= hLtgTOAqTsY;
            hLtgTOAqTsY += hLtgTOAqTsY;
        }
    }

    if (hLtgTOAqTsY == -222184.1283488759) {
        for (int AGiQuPUWAFFPp = 1642604944; AGiQuPUWAFFPp > 0; AGiQuPUWAFFPp--) {
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY /= hLtgTOAqTsY;
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY -= hLtgTOAqTsY;
            hLtgTOAqTsY = hLtgTOAqTsY;
            hLtgTOAqTsY /= hLtgTOAqTsY;
            hLtgTOAqTsY /= hLtgTOAqTsY;
        }
    }

    if (hLtgTOAqTsY > -222184.1283488759) {
        for (int rcakekyAm = 1855598212; rcakekyAm > 0; rcakekyAm--) {
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY = hLtgTOAqTsY;
            hLtgTOAqTsY -= hLtgTOAqTsY;
            hLtgTOAqTsY *= hLtgTOAqTsY;
            hLtgTOAqTsY -= hLtgTOAqTsY;
            hLtgTOAqTsY = hLtgTOAqTsY;
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY /= hLtgTOAqTsY;
        }
    }

    if (hLtgTOAqTsY != -222184.1283488759) {
        for (int OmzPHsAVrmP = 926686179; OmzPHsAVrmP > 0; OmzPHsAVrmP--) {
            hLtgTOAqTsY += hLtgTOAqTsY;
            hLtgTOAqTsY *= hLtgTOAqTsY;
            hLtgTOAqTsY /= hLtgTOAqTsY;
            hLtgTOAqTsY = hLtgTOAqTsY;
        }
    }

    return -775077327;
}

bool YUKGpWrEltJHDMYh::xpMvJYoFZaE(double BdmwXjnBVgyqsA, bool XCjSIxTCeVtUqkRS)
{
    int HRdEfUGPBLCC = -736298374;
    int DrwvblDsjyQrmy = -214584873;
    int hbUlKyP = 1037341825;
    string CDYmzKZgBlF = string("NpBiBnWaEKFhorDQTHFomwEHOaKLmHZghCzGyzvZZVvGjWCtohiusfql");
    string pVHnJIYLOXRLDwk = string("AuETfDMPsBvKkTcBmnkNOocptUDsnlIlCneGMIRUzUlNAmiEHYpjFACYUFwjYCXslfZuBmBnnELROEUUoDZhFfxkurMjfjKtRusXJtnZPZjYgBVQFqRp");
    double gbESJrBcfUkKYHt = -361115.1321434254;

    for (int YrlHQmBiiiP = 798889413; YrlHQmBiiiP > 0; YrlHQmBiiiP--) {
        DrwvblDsjyQrmy += DrwvblDsjyQrmy;
        HRdEfUGPBLCC /= hbUlKyP;
    }

    return XCjSIxTCeVtUqkRS;
}

int YUKGpWrEltJHDMYh::NQOSNyCsJFBXu(bool KfVIxkAxcBYU, int lrSovOCkj, string TQbcsMDJxTqI, double FnumWQ)
{
    double OgGCdZcANlgJw = -937794.4275464733;
    int hDasOmlNS = -1555489337;
    bool rNgqQePNYxyIagY = true;
    bool qTxdgo = false;
    bool qFlKmkcaGtdMlPt = true;

    for (int zBQGJlaGNdJNMkb = 2119142135; zBQGJlaGNdJNMkb > 0; zBQGJlaGNdJNMkb--) {
        hDasOmlNS -= lrSovOCkj;
        qFlKmkcaGtdMlPt = ! qFlKmkcaGtdMlPt;
        OgGCdZcANlgJw /= FnumWQ;
        KfVIxkAxcBYU = qTxdgo;
    }

    for (int dixUJ = 858317903; dixUJ > 0; dixUJ--) {
        qFlKmkcaGtdMlPt = qTxdgo;
        FnumWQ -= OgGCdZcANlgJw;
        hDasOmlNS -= lrSovOCkj;
        qFlKmkcaGtdMlPt = ! rNgqQePNYxyIagY;
    }

    for (int kwANTJOETnKxPMhZ = 2044004626; kwANTJOETnKxPMhZ > 0; kwANTJOETnKxPMhZ--) {
        continue;
    }

    return hDasOmlNS;
}

bool YUKGpWrEltJHDMYh::qOhCUnhYUqrOb(double xnopD, bool PQlAdchGtD)
{
    string fwssjIbVDfvYo = string("sXhZqiKhRijKvRHDoFGhIOGIuBqCLCKIOKffFMkxJHonzOsRirkzrWEVYHnhryexMAyVzmYmVvcoxbPgRdMRRztYrBndfBYQWDAmhOMpsmOGJbBNQqFDyhtDjfzvegZjidePGYFlRnZAnktmIrAGUPrVUrvNtPhInGglSWbAqLFtcDtFmMgmvcVGxB");
    string JuORJqBqGD = string("NcNiNvACwdkpMCDCzwvuOOfrbJmAMgKSzVYxRlBEwzniMngiuiTuoQAvylLjiGvXLUKRcxXLTqwlrwJweehqzzVtElCxOysigFAOElLvUrXwnuuolZfqWuuwmgPhYFKwCuJRbeIESKidlYdWqmCiHvWNVCNtGdTDskRk");
    bool bJNUyLbMkE = true;
    int LEOtT = -2090333603;

    for (int YeyxYhPs = 1604033369; YeyxYhPs > 0; YeyxYhPs--) {
        bJNUyLbMkE = PQlAdchGtD;
        JuORJqBqGD = fwssjIbVDfvYo;
        fwssjIbVDfvYo += fwssjIbVDfvYo;
    }

    for (int ESFFDn = 229257661; ESFFDn > 0; ESFFDn--) {
        PQlAdchGtD = ! PQlAdchGtD;
    }

    return bJNUyLbMkE;
}

void YUKGpWrEltJHDMYh::pcKCiwYHn(string cmuBx, int tgNhXyVug, bool fEVaTPUCB, bool kOyFNEUOrX)
{
    int oXZnQUN = 358262002;
    bool sdUhZcdkStqWd = true;
    bool vqiKqcsK = true;
    string qrukaobhLcw = string("PBuWaqHmQoJPiKLyHXXoVuILfaacUv");
    string yhqmVAUtkcwSO = string("pMTSGJkmMfUdNxDpoAhVMoovqlPnQLUFJKhJkeWaQLdftbLplrBLLUIgGIYmMECQBvpiUSNoyVDsKDjTbwIQAwAagGeVLQUVRmilpDNOHLskOkNtKLMJLvQhBtRLalVrIJIIugzkFMExRNQCczkioxFsqIynEcXUeKnfpbsXjxRQEyuFfEBgOXYcNHqwdeIDAzqXQpBX");

    if (vqiKqcsK != false) {
        for (int GsHLtbOGDfNMP = 864977370; GsHLtbOGDfNMP > 0; GsHLtbOGDfNMP--) {
            continue;
        }
    }
}

void YUKGpWrEltJHDMYh::RGlQrgpyurCKJ(int BVtEf, double gmIjsqUIQQxgiOZO, double thfjeEDbRh, string iIxeQUVsP)
{
    string ILfFikyMlGGJUBvg = string("pIBxcVXDYseyuxALpIzTPPAPEseRWlYTmWFKcykOLsVNghfIACAerweOxqJQYsKyMmOwlZKClQNvuvPgpgfHtDsStykQDbHjzocDzpNJgEioiazHHVvbIbFfxnfoaicaiLqRpuYkTzfqsMAIznpkvhTSPsSSowvcZKljXCYFYOEMiKbEcqXwjOERPhvPKNFozzAYReqzlYflxkCKIyiptH");
    bool BSnPjqP = true;
    double RtNpyVzm = 791595.9460506511;
    int UrSyYQyDWFY = 529748232;
}

bool YUKGpWrEltJHDMYh::QCSCXLSxwP(string eVGWUhKz, double bLwBRTnklmPnvo, bool GpusSofhefHy, int VSCxGkfn)
{
    string LSJhXHccYSn = string("dbFwXuyyJctrThfMMkXFNLQegnHhrPoBXqNnqtESgWekXfqZvUkSYxqgsVAzKLlVhCYWvUfVozdvlGxyPVQWLQFuOqmQeohecsFjZueCEgLIomtebSOwvPaPsiMDqxwbrpJwzmeXbNcuDkJPhFOayckwaYsyzBwxtzaUcT");
    string IBYPQSwBppAv = string("ZfGekBygXjbCcWmGeLXlzxiwVwWgnYpBqPqCZltQlqTPUjPauEEOxpinWmfPyfkgwAbuegnhmgPtTycKvaGICRWqNMcivoEGjlSTlaSLdHxwHzIDDZevornSGkKxidmpQVYlnNCUZiWxBoRHWkLhpBzxhdtLJYEMVacpfVrNMrJqeocUadpC");
    double DeUfjo = -471462.0012262974;

    for (int SLOIZX = 823767717; SLOIZX > 0; SLOIZX--) {
        eVGWUhKz = IBYPQSwBppAv;
        eVGWUhKz += LSJhXHccYSn;
    }

    for (int PlsXqwnoTpHgA = 1098197714; PlsXqwnoTpHgA > 0; PlsXqwnoTpHgA--) {
        LSJhXHccYSn = LSJhXHccYSn;
    }

    for (int mGapkxeUzqOVuWL = 1854653812; mGapkxeUzqOVuWL > 0; mGapkxeUzqOVuWL--) {
        LSJhXHccYSn += LSJhXHccYSn;
        GpusSofhefHy = ! GpusSofhefHy;
        LSJhXHccYSn = eVGWUhKz;
        eVGWUhKz = IBYPQSwBppAv;
    }

    for (int LSLESAivVFHGt = 1237341245; LSLESAivVFHGt > 0; LSLESAivVFHGt--) {
        eVGWUhKz += IBYPQSwBppAv;
    }

    return GpusSofhefHy;
}

void YUKGpWrEltJHDMYh::EJRga(string ghzCLr, string TMqIWNyqBwybzQMP, double mWmcykpS)
{
    string YUMmo = string("WLqLqwbxYnxIdEkGJSxFVTkKRDSOiMfUuohomPWMJaOPIcRvmpsFsqHPyfiiMVnOigwflhOXaCaPjrwtMUEvYvcpBnCHWPPqGAQYKvNryMswoqBmYErBLCXcliJsBfXreZwObINEuqpgAyLjeYdknotSGGnlXVIJddusTaEEMAjFGLxDLVejrnvnlybDzvYmLHjwPqEUNiePaQcFOWPskFUfsJdrlZrA");
    double hYxBfRRGCPEZXNw = 106057.4669733724;
    int hZCuAEl = 1600573774;
    string vRdVHZZFt = string("WXxEexMvAalmyegShFlYobbySyuYCHYPdGgSXwdJTiZCpbulhYnGZEiuoxxUlcpLSBabQDSLLqFmdn");
    string IlDnURPDatqMBsD = string("RnfwCPesmghCYbfattOeWXNuVNERQRGMluoZEVCZoCzJeRMdGoaDiuMEakJIyZyyVfcQLxofVsiuEkSuBfdutmljICEDlEqSGevhYxmCSbbCDSQhaWYalhmlPlOBjkYPzUZgdkAGjqHYPlrUqhrkTiFLGpazLJfyMaQNUlHCYhbQUkTZQABRPFFIjAdhUAJMRiUxbNtXWOYOsKCSieszDONvzvGVWpMxWaCBdWNLOtgEVnRyorrZn");
    string boobONhDqlpqASg = string("qlRawHfVtdoeRSdcpRPXqooBfiCAwrcuJuBHMTvZnmrEdgASMBfswMBNMfNICzPAjYCGgFRwTVgHFnYogHM");
}

YUKGpWrEltJHDMYh::YUKGpWrEltJHDMYh()
{
    this->IQivaLa(885366400, string("xpzOePgtpWshAVvFYKNilAsdLFmgKBOnmTRQyXPSsyprItkcWJEfxAqzrhZkzZcySBQTrGAKARlNrHufRVGyCMxRxXHhTvXHZXvQnKqkgKqgADXJlOahPYiVWkcucubqtsaOkmH"), 300844.2587264678, 161675.22023542333);
    this->ebVsFoNH(949279428, false, false, true, -277247.7343716182);
    this->wKAFa(493154.0715820591, 461973.72728195036);
    this->nUsBW();
    this->CQnuppLbcASzGie();
    this->KhredvajgEhQS(true);
    this->ZfNEwYXGJyIdKMTf(string("gUQqiJDqSwbGeTmBWyfpgZUbkAsstkNrXXjLAWasdOUkRArzolgUwqiIEqtyQVhZzEMKDHthUGIHfbLdYXXRZqD"), 2045683739, true, false, false);
    this->oDutjrKabmJTL(true, 317312.5095060774);
    this->oEecUhppOqiUy(string("jIPYDGVgyMVMipBoOgQEpoTunHASnJDTXnUMjAsdvEdnKgPyUybqOkvZlzqXdcwcxXHKLl"), false, -1183014235, string("heEKuSsNxTWLHdSoRYuwwfGynUZzzeVERFYDNanuauWHzCzQjZtPIXkKhlgEYsdRRgDOSFvOqQxYLPbdfSIiXpVkaJFkkKxYKlRYeCQkLZGcBfjQOQULyVxEoUsENJqphipuPRTcuwnrVcfJPfXJMHFZTYKMs"), false);
    this->uDeMWQ(string("wwECOXIWEegHTiBbKiKKndxZFcOFZwGvKlpFYaxvyoRdMSKraseztWiQST"), 713192.7657209125, false, -1429312244, -77814.12739889178);
    this->ORxYGpBBaTKaDKDb(235564655, -194706.4013096033);
    this->lSGwGfxdcmOhRn();
    this->xpMvJYoFZaE(-85036.05013766668, true);
    this->NQOSNyCsJFBXu(true, 1143917820, string("oBXNxbwdHzrIinELwcuobogRcFCcWdPWdPXUGtEY"), -330280.11326970457);
    this->qOhCUnhYUqrOb(918721.7439742206, true);
    this->pcKCiwYHn(string("lOgTMPYJtEQZMRfmDPDpbCvBenyjbCoYCjUkAbxKcdlAIVjyztGkBlpUljzuiDRqDaPoQqkrAUDWuXIutHXOzq"), 1328036146, false, false);
    this->RGlQrgpyurCKJ(2067165512, -679765.532199783, -811472.0800315893, string("BrINPNeikxUheGSquJzWLKryOaowRTmdwqVkTfPbRvOKQdsutlBLNnuWGBMGnAGhWKXHqqpCUOczhXfCEvbVrHCJBlrzQcVgkipBodGTVZfXeEAfVkUVxSdqDvFEMWCESteDnSbaRrZCnVDZAxxTJQvisXrgiGVTR"));
    this->QCSCXLSxwP(string("JjdOSWsdmPcJVRBzDWXjAjWsmRjgkjxLULEPPTdgxfDUESGSPfmhnOlUidnNgDgLWADVVhKAeLUCsGNMkOcFGOSEFFbDsKuaiSVElNTkkDqTGEQqewJQnDEjUDrObNMbhwLTnoZNzCgGsFAatZbjzfarNPYNFr"), 468708.1943219962, true, 179194961);
    this->EJRga(string("fKZybCqlMdadtgKtCCfNcMqLblUkhyqFLlWbxJbbgnEkWDXdefFPttGvEfssDbmDLHwsKqGPRRwuWVtzdujsvBnmUrjIlejsHmBhaQhcAmYaPJEWtHgGgTvODSIinzqXohFhSjPgNnlCaxeUFXVdpAyNcBrMTxJRjLdgMBKzyCVIZqlotDafKuSD"), string("SuvUTirpVsrThTywRKLeLGItwDAjDDRXTjyiEmbtNbtKSyAwQWLVuC"), -518142.76225514227);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GsYrgXvAQK
{
public:
    bool YPwmrmtpOu;
    string FHCAJUtPbxsF;
    int WzNIBj;

    GsYrgXvAQK();
    void FmHKRkpth(int CdcQOzRYdhGS, double jkHavv);
    double XTjJsLLjhR(int fKItaTtvdlNAt, int UcWOzwRhABucX);
    int cwtqU(int IbgSKAuftqy, int okHnZClwCzGwwUE, double mboAY, int kZhyns);
    void LARauzZixXtuVtv(string AKeJE, string wOTGCCI);
protected:
    int mlMltsKCT;
    double eNTlaglwPRQB;
    string XATMoFakHcmmMUo;

private:
    string fPLwwM;
    bool svchHujgjOE;

    string pXfLw(int DAVeBrzk, double KtLtawQPtQg, string XekkJNM);
};

void GsYrgXvAQK::FmHKRkpth(int CdcQOzRYdhGS, double jkHavv)
{
    double kGGDdAJFbuDi = 985854.514524871;
    string TkKaEIGeNKWMyNe = string("yVtWiRNjUTyAVTxZTHPEZvONpLQWhuTkBGtFwXGdGfLlQEsuQivffDFKMtrAEDGFpjYyRCfwWpLukctKOxbIuOeVFagTWokkCIakgXJIDfvBaluPhZlYJvxmrEqtjFaOxJkdOFmnVcXqPPlMuYMeNYswEzwqanHbvwFBOZbafvHVEXSceQNDqQmptlspOoLfxpnUUEeabaJPMHlFqTfZIBJNMtzv");
    string UjyFDlGDNJPEiLz = string("bUGmZzEvvzjtUOMgxMZPKYQXYgsrQigPlwMNYvPgoxvISDWeIaTVAtUzFAJAqMRFYniNktfWasXwVmiRxPJvTiuGLUKEeHKYVMPoQLGHosWJpsjTSfjUxPgIZjWLxxlyQqCMllwROIHpdnAtmDuUOQnaLryWrweZnfOWbCcexBnsqNZwZxgDISrTSsCiQmUdMnpkRSVtWIERhdjpOQeZmuQDXXqwRwPosZhik");
    double XvMhebjdEAAVGnq = 468373.69558477047;
    int BPGXYLNYuryuPZyD = -57696739;
    double SyAozdadJkdQbmF = 753664.5636697845;
    int MBhgMvS = -1127148529;
    bool gKTYzkhZALo = false;
    int rpHntsaWZFQhMNal = 1697229558;

    for (int OvJJxjCOHJwUwJd = 1454884656; OvJJxjCOHJwUwJd > 0; OvJJxjCOHJwUwJd--) {
        jkHavv = XvMhebjdEAAVGnq;
        TkKaEIGeNKWMyNe = UjyFDlGDNJPEiLz;
        rpHntsaWZFQhMNal = BPGXYLNYuryuPZyD;
    }

    for (int buwOpEkbSiAczwJ = 889230439; buwOpEkbSiAczwJ > 0; buwOpEkbSiAczwJ--) {
        SyAozdadJkdQbmF -= jkHavv;
    }
}

double GsYrgXvAQK::XTjJsLLjhR(int fKItaTtvdlNAt, int UcWOzwRhABucX)
{
    string wasbsmGcTYRC = string("JvGPYtpEHmKtChsPZzwgdIWrlhlqFdaGehkJZcygGjwqKsqlobISlcKPFRJCdyxkKwWatBLFGjiXnJCGJfXzcvGBsijHedIAggssAIQGZQMHFCIgzizYPCTsAgJfvDLBhCmpfjFjxmJgRXKagWbhWMvqaXxLbLgmPXVmfvzuMVtuPWLvBeHhGfpN");
    string LOzzTXJutK = string("IDLRtPOkNZCxyPXWcYWDMfNLjITNCfMFJiCYVeLypuVVic");
    string ZMPbpTExXg = string("fSJCPufzXdYTWAQDiIptswbqNQTfEyWoiphfqOUoLnJXiUKlkIBxsMGIWJjTHteDfuBzWtOkporYfFebcUXocAVEfacuxzHHfoA");
    bool OdyvgYRTXiCK = true;
    int ZKqFhwepr = -1894382268;

    if (ZKqFhwepr == -2088313846) {
        for (int PPeXsMYnujQa = 604885773; PPeXsMYnujQa > 0; PPeXsMYnujQa--) {
            ZMPbpTExXg += ZMPbpTExXg;
            UcWOzwRhABucX /= fKItaTtvdlNAt;
            ZKqFhwepr *= UcWOzwRhABucX;
        }
    }

    for (int tKsnlJFo = 1528543890; tKsnlJFo > 0; tKsnlJFo--) {
        ZKqFhwepr -= ZKqFhwepr;
        UcWOzwRhABucX -= fKItaTtvdlNAt;
        ZMPbpTExXg = ZMPbpTExXg;
    }

    return 7424.828306037045;
}

int GsYrgXvAQK::cwtqU(int IbgSKAuftqy, int okHnZClwCzGwwUE, double mboAY, int kZhyns)
{
    double scdEUYzPPbIyqwtm = 353173.0706099066;
    double BpdidAm = -623297.5038843869;
    double kxAAHaKXQCJMp = -115763.99806441834;
    string JBdNjK = string("hjgruulscIyqFahcXkAyksGiItlGWwdCivHhxiNueCHGcSRvcDKQfuzzKmXLjmAlGNXBbXeXTSWIqcYtCBzvhTkAXQYaHeOQmJgjKpNrsmRUTYqVReYypfnDzoifGdgaEbCMakJgDBIgcIDYONbPMOdWkcaJuIgciIKtCVCduLoCVRnSksoTbIEFXKnCbejJPFsAfPYTQjtEJGwjjZGTjDOkyhVwwhhyEtrPWzoNZjMaYpjLFAVbQpxezOnhvNC");
    double LeRNRNatcZPPPUY = -416670.2097353859;
    double SkYab = 633907.762369277;
    double tOHpzkVG = 96326.27125341757;
    double bqFtLYxB = -945041.5892160739;
    int HlHui = 992389210;

    if (mboAY < -623297.5038843869) {
        for (int fqtYSCWQeF = 494373766; fqtYSCWQeF > 0; fqtYSCWQeF--) {
            LeRNRNatcZPPPUY /= bqFtLYxB;
            LeRNRNatcZPPPUY = bqFtLYxB;
            bqFtLYxB /= kxAAHaKXQCJMp;
            SkYab /= kxAAHaKXQCJMp;
            bqFtLYxB *= scdEUYzPPbIyqwtm;
            LeRNRNatcZPPPUY = kxAAHaKXQCJMp;
        }
    }

    return HlHui;
}

void GsYrgXvAQK::LARauzZixXtuVtv(string AKeJE, string wOTGCCI)
{
    bool HMYDyyZvXgMEK = true;
    string HKYaKgY = string("uMMYkUlLzhuR");
    double pZlmTylgQIG = -972721.4401936014;
    double htDXGvukcuH = -993789.7639011096;
    double rFSPstIZGuC = 829748.6959019233;
    int uwObUHHOn = -1764839510;
    int rqunKaMqiOmkIrMs = -1333936454;
    bool qOPElTvDa = false;
    double pImqj = -205693.11331723788;

    for (int MRhzXjAa = 1575513601; MRhzXjAa > 0; MRhzXjAa--) {
        HMYDyyZvXgMEK = qOPElTvDa;
    }

    if (htDXGvukcuH >= 829748.6959019233) {
        for (int EArcoqqzDXlFo = 1474740710; EArcoqqzDXlFo > 0; EArcoqqzDXlFo--) {
            htDXGvukcuH += htDXGvukcuH;
        }
    }

    for (int IgvwAtfV = 787439342; IgvwAtfV > 0; IgvwAtfV--) {
        uwObUHHOn = uwObUHHOn;
        HKYaKgY = wOTGCCI;
        qOPElTvDa = ! HMYDyyZvXgMEK;
        wOTGCCI += AKeJE;
        wOTGCCI += HKYaKgY;
    }

    for (int gHhlWs = 1589137935; gHhlWs > 0; gHhlWs--) {
        htDXGvukcuH -= pZlmTylgQIG;
        rFSPstIZGuC -= pZlmTylgQIG;
    }
}

string GsYrgXvAQK::pXfLw(int DAVeBrzk, double KtLtawQPtQg, string XekkJNM)
{
    int BwEwmCiHxROSynA = -2010417197;
    string PJLrVdTJnj = string("iDMhpppGMWcIppUFveXbasyMsBLpopdqXHGLouGHLPcKdjpzfoOsdQQqFUloGJjpHJboOpDfkVXMYGyHarEVkilYOGZLfWopvrRqZyKXUBsdeFeBBcknkvEYNhRKQWkzeLVcbsnMiglvoFJFCDevuqgSoPMauavYdNGeAYUEqgOOkMwUZeqqSEVUgpKrDwOdlFzEeIAwzjvPjQYzgDw");
    string LYyFBjruMSX = string("hKyzpEDsXmJkzcBgSexDBRplhgSGUYggNYchUwxGXu");
    int LUgJtnawKiM = 108439639;
    string PnusX = string("zZABkYRktxqekYxBbMualpoDSVrfYBXZNjbBIxPqnTQTcnNwFHdgkxuPHRrsunBYuYjCsToXWPnekeJQbjSUyzCCtSvXuUjBqwhtwUoFKSANFQTQzQoERKauboUQDCkJBAOwzAiKJWGojITerjFOmchDBKBiNYRMgULM");
    string VuHNTCwEBqd = string("gBsPwLeoaMvmdOXNayWgbrpRXHKbykanltKLaZVDQjRjgmhITYymEUMtiztYOFns");
    bool uQwlle = true;
    double CAUTcKCHfNH = 262167.7618110111;
    string ILaVyA = string("RhZGZgefXAvifYPdAgRINaNQnMFYlaCqsmYuRhDOLszBRSZhDKPpHKmFgSKaOKXeFOdNXCUcwUnkdXTFUp");

    if (BwEwmCiHxROSynA <= -2010417197) {
        for (int KRSQLSHRrGeF = 390453449; KRSQLSHRrGeF > 0; KRSQLSHRrGeF--) {
            ILaVyA += PnusX;
            PJLrVdTJnj = PnusX;
            PJLrVdTJnj = VuHNTCwEBqd;
        }
    }

    for (int AMCNrZYldta = 1500682775; AMCNrZYldta > 0; AMCNrZYldta--) {
        LUgJtnawKiM /= DAVeBrzk;
    }

    for (int wvTyXjdsfgbe = 866060413; wvTyXjdsfgbe > 0; wvTyXjdsfgbe--) {
        DAVeBrzk -= LUgJtnawKiM;
        VuHNTCwEBqd += PJLrVdTJnj;
    }

    for (int obuymuQlbFt = 116136832; obuymuQlbFt > 0; obuymuQlbFt--) {
        CAUTcKCHfNH += CAUTcKCHfNH;
        uQwlle = uQwlle;
    }

    if (PJLrVdTJnj >= string("ZcjIrckYsiEvWnZPgXtGVqCjiaHatjxqTycBSzlqOAilisxOtgzrraJAkOUSCwAStgQStPGpnUUStSzppgbPpPkqOcUtAXqJFIZNanYAenrJyzSwDTOnLEmhEhhwGllRzXxBmrFMSJqXGuqoMdhGpLBysJEiSnYSqCxgsvQVFLJnSjhgUS")) {
        for (int GfJzMq = 205095517; GfJzMq > 0; GfJzMq--) {
            CAUTcKCHfNH += KtLtawQPtQg;
            VuHNTCwEBqd += PJLrVdTJnj;
            ILaVyA = VuHNTCwEBqd;
        }
    }

    return ILaVyA;
}

GsYrgXvAQK::GsYrgXvAQK()
{
    this->FmHKRkpth(-1327376297, -91187.88202835384);
    this->XTjJsLLjhR(2001254705, -2088313846);
    this->cwtqU(-884831121, -1557756919, -114760.2547287367, -1445689205);
    this->LARauzZixXtuVtv(string("PJNcjIDJJEEvKUwTThzmMfIMdfhWoccSMMNULLOyWhXwmVPNOjn"), string("BoTpiygzVVTVmRhvrucewuNIVOdyKakNcpWYNpAykZSpoHXPsIUDURAgUCBhUFmArVSaqkyGSOkkzVHnJqjrQbnbUesKdNEJSOYCSopgEbbQcyGwBLgzUBWVbeOCAoxFYjGiVHWwlJtjGCTZLAqP"));
    this->pXfLw(1067016408, 262437.2778319782, string("ZcjIrckYsiEvWnZPgXtGVqCjiaHatjxqTycBSzlqOAilisxOtgzrraJAkOUSCwAStgQStPGpnUUStSzppgbPpPkqOcUtAXqJFIZNanYAenrJyzSwDTOnLEmhEhhwGllRzXxBmrFMSJqXGuqoMdhGpLBysJEiSnYSqCxgsvQVFLJnSjhgUS"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wgyildWybzLZOa
{
public:
    bool cHelEva;
    string JqYNmxEbgUwuOGpM;
    bool bgswZVUtTZbNOfOc;

    wgyildWybzLZOa();
    void DhSwwfQUcthHg(double TbXWwRrwcxCr, string OfRqTxtqlZyLNdX, bool ylVTNR, string lqPKtEkQGWrjmZ);
    double Whbqht(bool SAIgY);
    double NXKEmerRRDwkXu();
    bool LHbszuwiWbgnD(double RcIYFJwnJsCXfVr);
    void BjNhnRpgnslawk(string ThWZKLHToVGzOKZ);
    double Psjjk();
protected:
    double ZVKnvfOzFSDTj;
    double VGiSGIybakEk;
    string pYCklqDcAXKU;
    int RgzqTXvqQ;

    double ZGwdoIAdOdzBVOG(string QbzFwrFotwRHGnpp, double ppLxrujUx);
    double PzUJGs(bool IFJWwRTuIUFTh, string hSHMpRqMCpF, int VlxaDZvs, bool vmvgjtWVSSP);
    int IPSRKgZuXn(bool RwMbVC, double GCTpO);
    bool gqhnuiXH();
    string NlXTzheWha(string kJUNxeCAvqj, string qEYQvGR, int sulbuRxqwYVrtaUK, bool RLzcwHmZCLz, int ODpgmoVU);
private:
    string hvrbCgEOLUQF;

    int QGpVhQPJ(double MhJBucAHFcrNzpzp, string jFLoVmnxbLnG);
};

void wgyildWybzLZOa::DhSwwfQUcthHg(double TbXWwRrwcxCr, string OfRqTxtqlZyLNdX, bool ylVTNR, string lqPKtEkQGWrjmZ)
{
    int pjTYEAjgVmdQGhoS = -1371686002;
    int mIElXUiisCR = -1879128575;
    bool YJGEeP = false;
    int IfbppAnyjkO = -2004533489;
    double zuzrARjwpFpMtSZe = -316783.1072763655;
    double ZLoITycOvm = -97201.97217484526;
    double VdTkzvUFWi = -343721.26429455465;
    double RbumLII = -470147.5826061584;
    double CduZWryEmLsDCU = -615926.821602989;

    if (CduZWryEmLsDCU < -470147.5826061584) {
        for (int JdibXifQVCkXIUHf = 982393354; JdibXifQVCkXIUHf > 0; JdibXifQVCkXIUHf--) {
            TbXWwRrwcxCr *= zuzrARjwpFpMtSZe;
            CduZWryEmLsDCU -= VdTkzvUFWi;
        }
    }

    for (int wLpvGVfjobLi = 1372461266; wLpvGVfjobLi > 0; wLpvGVfjobLi--) {
        zuzrARjwpFpMtSZe = RbumLII;
    }

    for (int SfCDSzz = 76507012; SfCDSzz > 0; SfCDSzz--) {
        zuzrARjwpFpMtSZe = CduZWryEmLsDCU;
        mIElXUiisCR += mIElXUiisCR;
        ZLoITycOvm -= TbXWwRrwcxCr;
    }

    if (mIElXUiisCR != -2004533489) {
        for (int JfhwZt = 2137265239; JfhwZt > 0; JfhwZt--) {
            TbXWwRrwcxCr = VdTkzvUFWi;
            OfRqTxtqlZyLNdX += lqPKtEkQGWrjmZ;
        }
    }
}

double wgyildWybzLZOa::Whbqht(bool SAIgY)
{
    bool znJEAOHqSUk = false;

    if (znJEAOHqSUk != false) {
        for (int tKFtNDDRTTzX = 160182604; tKFtNDDRTTzX > 0; tKFtNDDRTTzX--) {
            SAIgY = SAIgY;
            SAIgY = ! znJEAOHqSUk;
            znJEAOHqSUk = SAIgY;
        }
    }

    if (SAIgY != false) {
        for (int WHNSBdvHSmSefa = 825671523; WHNSBdvHSmSefa > 0; WHNSBdvHSmSefa--) {
            SAIgY = ! znJEAOHqSUk;
            znJEAOHqSUk = ! znJEAOHqSUk;
            SAIgY = znJEAOHqSUk;
            znJEAOHqSUk = ! SAIgY;
            SAIgY = ! SAIgY;
            znJEAOHqSUk = SAIgY;
            SAIgY = SAIgY;
            znJEAOHqSUk = ! znJEAOHqSUk;
            SAIgY = ! SAIgY;
        }
    }

    return 469788.04220227257;
}

double wgyildWybzLZOa::NXKEmerRRDwkXu()
{
    double jHpnfVNEPCWDy = -1019545.3218006563;
    double ehVfHXmqZcVlizy = -373029.46031065384;
    double hJoPLOuPVyXHqvEw = -399318.78848690004;

    if (ehVfHXmqZcVlizy == -373029.46031065384) {
        for (int RrLcxgMvTLPFZN = 883997607; RrLcxgMvTLPFZN > 0; RrLcxgMvTLPFZN--) {
            hJoPLOuPVyXHqvEw *= ehVfHXmqZcVlizy;
            hJoPLOuPVyXHqvEw /= ehVfHXmqZcVlizy;
            jHpnfVNEPCWDy += ehVfHXmqZcVlizy;
            ehVfHXmqZcVlizy = hJoPLOuPVyXHqvEw;
            ehVfHXmqZcVlizy *= ehVfHXmqZcVlizy;
            hJoPLOuPVyXHqvEw /= jHpnfVNEPCWDy;
            jHpnfVNEPCWDy = ehVfHXmqZcVlizy;
            jHpnfVNEPCWDy += jHpnfVNEPCWDy;
            jHpnfVNEPCWDy += ehVfHXmqZcVlizy;
            jHpnfVNEPCWDy *= jHpnfVNEPCWDy;
        }
    }

    if (jHpnfVNEPCWDy > -373029.46031065384) {
        for (int OscDrVrmNcZ = 1483177214; OscDrVrmNcZ > 0; OscDrVrmNcZ--) {
            ehVfHXmqZcVlizy /= ehVfHXmqZcVlizy;
        }
    }

    if (hJoPLOuPVyXHqvEw > -399318.78848690004) {
        for (int JGrQLUIGkquniJ = 494616806; JGrQLUIGkquniJ > 0; JGrQLUIGkquniJ--) {
            hJoPLOuPVyXHqvEw /= jHpnfVNEPCWDy;
        }
    }

    return hJoPLOuPVyXHqvEw;
}

bool wgyildWybzLZOa::LHbszuwiWbgnD(double RcIYFJwnJsCXfVr)
{
    int uJwBAfGFm = 697022833;
    string vNvtqQduMffHHje = string("sTFcCqahIrwZwpr");
    bool PNvtW = false;
    int oJrczjzyOY = 475823726;
    string VbiYwIlag = string("EcSTfjztcYnCGdkWxwTZjTRPVEigNubWULvgWelEhDJJbGvbWeeQMjqlhRgDVHsWaroSBQaSUXAKeXebvokKrOKGHYBCYgoQUNdfsaltQaKWdBXNjlHesSXuogHGUyIpzxrMyMrIXeaLAzvkrVWdiiaWPeFJLtjAWfLjkPugacCNpXazTFkhbyAYtbtZJ");

    for (int kOPavoThv = 800718465; kOPavoThv > 0; kOPavoThv--) {
        uJwBAfGFm = oJrczjzyOY;
    }

    if (oJrczjzyOY != 697022833) {
        for (int WLTEOqgjGZQnOoR = 1443132219; WLTEOqgjGZQnOoR > 0; WLTEOqgjGZQnOoR--) {
            uJwBAfGFm *= uJwBAfGFm;
        }
    }

    for (int jKjVMqTSxD = 1647097661; jKjVMqTSxD > 0; jKjVMqTSxD--) {
        continue;
    }

    for (int JYXIAKzvLUUFQJMP = 290211853; JYXIAKzvLUUFQJMP > 0; JYXIAKzvLUUFQJMP--) {
        oJrczjzyOY = oJrczjzyOY;
    }

    if (uJwBAfGFm == 697022833) {
        for (int DeKcMN = 1235054059; DeKcMN > 0; DeKcMN--) {
            vNvtqQduMffHHje += vNvtqQduMffHHje;
            uJwBAfGFm += uJwBAfGFm;
        }
    }

    if (oJrczjzyOY == 475823726) {
        for (int wyPwqdiR = 2023802968; wyPwqdiR > 0; wyPwqdiR--) {
            PNvtW = PNvtW;
        }
    }

    return PNvtW;
}

void wgyildWybzLZOa::BjNhnRpgnslawk(string ThWZKLHToVGzOKZ)
{
    double CgOYFwTMvBkRn = -788025.8789770558;
    int icoYfcYstX = 836608514;
    string EvMpPGrJbxf = string("bDWawAukZUeNhAsfDBQrpzRydWnaxLokQdYtzQHJPrWrkANvAcVDCZBdLhqnqrVzXhyZeGFARFzGJqzUeAqruSWpBzrmMbilbFjRapfOwICiKeBexBjWcBPdvKXGGpsZxKeWpZSquVSeVwGSMucIuR");

    for (int LyFeGov = 911006865; LyFeGov > 0; LyFeGov--) {
        ThWZKLHToVGzOKZ += EvMpPGrJbxf;
        CgOYFwTMvBkRn = CgOYFwTMvBkRn;
    }

    for (int qmBJmlTieiDOnA = 2057155782; qmBJmlTieiDOnA > 0; qmBJmlTieiDOnA--) {
        CgOYFwTMvBkRn -= CgOYFwTMvBkRn;
        icoYfcYstX -= icoYfcYstX;
    }

    for (int nuvVPzEbaVK = 1511552232; nuvVPzEbaVK > 0; nuvVPzEbaVK--) {
        EvMpPGrJbxf += ThWZKLHToVGzOKZ;
        ThWZKLHToVGzOKZ += EvMpPGrJbxf;
    }

    if (icoYfcYstX == 836608514) {
        for (int bxodmQtW = 534522960; bxodmQtW > 0; bxodmQtW--) {
            EvMpPGrJbxf += ThWZKLHToVGzOKZ;
            CgOYFwTMvBkRn += CgOYFwTMvBkRn;
        }
    }

    if (CgOYFwTMvBkRn != -788025.8789770558) {
        for (int MXsgGzBWbRdMPmy = 1617498377; MXsgGzBWbRdMPmy > 0; MXsgGzBWbRdMPmy--) {
            ThWZKLHToVGzOKZ += ThWZKLHToVGzOKZ;
        }
    }

    if (icoYfcYstX < 836608514) {
        for (int wcloMjh = 316391467; wcloMjh > 0; wcloMjh--) {
            EvMpPGrJbxf += EvMpPGrJbxf;
            EvMpPGrJbxf = EvMpPGrJbxf;
            CgOYFwTMvBkRn += CgOYFwTMvBkRn;
        }
    }
}

double wgyildWybzLZOa::Psjjk()
{
    bool qDNdSnnOXpljc = false;
    bool agloSJ = false;
    bool lmQOoTNNv = true;
    string ijLsknluYsgcFe = string("VNzFdaqrDSqiRmHPIQRfRVbJGitGDSXcsaVHgYwrnaC");

    if (agloSJ == false) {
        for (int QhYWrSFfdVKism = 39571857; QhYWrSFfdVKism > 0; QhYWrSFfdVKism--) {
            qDNdSnnOXpljc = agloSJ;
            agloSJ = ! agloSJ;
        }
    }

    if (qDNdSnnOXpljc != false) {
        for (int mHnSEK = 1496095606; mHnSEK > 0; mHnSEK--) {
            ijLsknluYsgcFe = ijLsknluYsgcFe;
            lmQOoTNNv = agloSJ;
            lmQOoTNNv = ! lmQOoTNNv;
            qDNdSnnOXpljc = lmQOoTNNv;
        }
    }

    if (qDNdSnnOXpljc != true) {
        for (int iIFhrMaRTe = 804714790; iIFhrMaRTe > 0; iIFhrMaRTe--) {
            continue;
        }
    }

    if (agloSJ != false) {
        for (int JdVTSRHoi = 2084194842; JdVTSRHoi > 0; JdVTSRHoi--) {
            ijLsknluYsgcFe += ijLsknluYsgcFe;
            agloSJ = agloSJ;
            qDNdSnnOXpljc = ! agloSJ;
        }
    }

    return -879703.6703469789;
}

double wgyildWybzLZOa::ZGwdoIAdOdzBVOG(string QbzFwrFotwRHGnpp, double ppLxrujUx)
{
    int uxhvwjgnDJco = -726182644;

    if (ppLxrujUx > -227696.35090815052) {
        for (int WxEyIY = 678956940; WxEyIY > 0; WxEyIY--) {
            continue;
        }
    }

    return ppLxrujUx;
}

double wgyildWybzLZOa::PzUJGs(bool IFJWwRTuIUFTh, string hSHMpRqMCpF, int VlxaDZvs, bool vmvgjtWVSSP)
{
    string kvvwEuUHaqMLK = string("ZdxEFknJswQajAmYcvcZQrTibtxhMVrNJsIYLEYZnwGwjZAChwNViQBAXggaHvqsmINnqrgANCAXsZjYCnvsTjRBoDbTHzDcKnNOcTnZODdfMaawqGglUrdrRuGLnuLDRwmYPrpaflmOHHRpekRVAwvIRvKldrlDtADvkKyFrXQSRRtSsxFJJUNnRwqgQJozXKUwgxtHCXtqZCkwjbYbCCbVvAjMPCktmIE");
    string TtrFVBJ = string("NoMAMNLlciiEBVwIWEaPepRZl");
    bool BlBSjVpFEyTXRzW = false;
    double JTOkiSFVYKTFpevY = -958478.5371496434;
    bool uslKPldB = false;
    int XvujoxzJT = 133979062;
    double dQegiRYuJGkh = -877240.1169174077;
    int onYVTxTqNwxJ = -466873430;

    for (int MFHWJuwiXJLF = 1545588027; MFHWJuwiXJLF > 0; MFHWJuwiXJLF--) {
        TtrFVBJ = TtrFVBJ;
        XvujoxzJT -= XvujoxzJT;
        VlxaDZvs *= VlxaDZvs;
    }

    return dQegiRYuJGkh;
}

int wgyildWybzLZOa::IPSRKgZuXn(bool RwMbVC, double GCTpO)
{
    double cjJoKnmAuNXm = 91974.36725355336;
    bool amzTjrvplaforn = false;
    int OQIKz = -1040396851;
    double RmULPkAYlMu = 564372.5099745976;
    double XZmhuzMlJ = 650962.4010345112;
    string akFlVZETCvHc = string("VCsAEmihEuVhqQePFlDeaFkHCxFlSJaTEmnVWrKiKeqLJDDNhIPoQeIAmfRLTHmrBaKnKQBmkhxACzzqFpSkxkzFrSGDmRRjQvhKmLSvPCFNbUUmiCkGWmHqxutOhMFWmUCJDuSHvvHrypWUoDaZrctYFfGKEcNnCwivqJPPqBXrJHiErHdTVuyrHavOPwPMBmXqEnLGRWLVssvmPQ");
    double AOXYTxP = -622126.1493955666;
    string WnbLqREtilyAX = string("HiMTKmGEqvLUMjdhDITIiyVhrVRoexsBnNSJBLZmxLJbVSvigZYkLNALnDfZouJRuTdQEDKDOXmZPWUwNrKHcSPcfBhLJZVKopunloRQHOKrWGggLLFNGLVGLZWCKeChNQXNxskxmcgFQJhjwVAiaGZvRLjekCKXzbFnYezCGSDRjnJpuDlprJHVxkindamTVDbEujUCnOCIJbVifaTgizxniLQKOiMgfgIYMhoGtAhKcNNboIAffQUeZI");

    for (int AVszuOyDHB = 1629943209; AVszuOyDHB > 0; AVszuOyDHB--) {
        RmULPkAYlMu += cjJoKnmAuNXm;
        AOXYTxP /= AOXYTxP;
    }

    if (XZmhuzMlJ <= 650962.4010345112) {
        for (int zrlZnzT = 1644147578; zrlZnzT > 0; zrlZnzT--) {
            RmULPkAYlMu /= RmULPkAYlMu;
            akFlVZETCvHc += WnbLqREtilyAX;
            cjJoKnmAuNXm -= XZmhuzMlJ;
        }
    }

    if (cjJoKnmAuNXm == 650962.4010345112) {
        for (int nOMopZLHzIbE = 1479175019; nOMopZLHzIbE > 0; nOMopZLHzIbE--) {
            continue;
        }
    }

    if (GCTpO != 91974.36725355336) {
        for (int JCmDN = 1517781296; JCmDN > 0; JCmDN--) {
            continue;
        }
    }

    return OQIKz;
}

bool wgyildWybzLZOa::gqhnuiXH()
{
    string VIGGckCOv = string("yvnVmprGjPmWTJZRmQIWRXVtMyTZhhfKcfpSUiNtlwsArbsRgSCAhnZWRtwhIkjIOiQCTgVFJHuwyCHQCWgZPlZCQsvudGHoKZFVNPMpERKZXWCoeyigLZZbwhIhnKptULqIhJCDhhfPSosPauswJAgnQxyqudnEWHnuZGqMgVJzZQEkSdnQKFguSDbrnjdMRsYaAH");
    bool pEYavzL = false;

    for (int BUwshLZrdnBgS = 1734560368; BUwshLZrdnBgS > 0; BUwshLZrdnBgS--) {
        pEYavzL = pEYavzL;
        VIGGckCOv = VIGGckCOv;
    }

    for (int NmdoSnqacD = 1090200755; NmdoSnqacD > 0; NmdoSnqacD--) {
        pEYavzL = ! pEYavzL;
        VIGGckCOv += VIGGckCOv;
    }

    for (int FlJdQNxn = 211049247; FlJdQNxn > 0; FlJdQNxn--) {
        continue;
    }

    return pEYavzL;
}

string wgyildWybzLZOa::NlXTzheWha(string kJUNxeCAvqj, string qEYQvGR, int sulbuRxqwYVrtaUK, bool RLzcwHmZCLz, int ODpgmoVU)
{
    string XJlwFCdffZwrm = string("sMWueglAQJZOVtfeEKu");
    bool gfaqOlOACsZZjHV = false;
    bool sAUTcggV = false;
    double YJVGdtnJdt = 424942.2359480193;
    double kklamoC = -339348.3055672935;
    double xQgYfjfXIybvvtS = -991083.3213851299;

    for (int qJDjRxzeszqpXw = 1407318362; qJDjRxzeszqpXw > 0; qJDjRxzeszqpXw--) {
        qEYQvGR += qEYQvGR;
    }

    for (int EvtEo = 238406290; EvtEo > 0; EvtEo--) {
        kklamoC += YJVGdtnJdt;
        qEYQvGR += kJUNxeCAvqj;
    }

    return XJlwFCdffZwrm;
}

int wgyildWybzLZOa::QGpVhQPJ(double MhJBucAHFcrNzpzp, string jFLoVmnxbLnG)
{
    double KozmBeaVQrW = -522824.70645346685;
    double lbZMjXOkkQthU = 107967.31836722238;
    double yjqfAFvmLk = 952916.2567191323;
    double bqMMoJuU = 944355.3969206163;
    int EzXJzYqHHR = 1759132542;
    int EuDScK = -589443507;
    string hFJiJNOcj = string("dwwKMOnqjpYnlBVfNtHTHPdeQoQOKBkMkamqDcgAQmVKBegpqCdnXBqSWgOhATcwjacKYpZbUuRhHtufGrDjDTSYilzIeUtQbdbQHHTtLjzMOQNoqSklqzGfQFTECwEDwjQhwkGUMyxhwHRpYcQIGYzPWpFClqKPYOnXBfjbDEuynNgxNzhNa");
    string TgcVKxtEeISuufA = string("ZcmgPSAHKSYORuyODjPKttBkYybvAVhvSGesYBjAZzWAZgvRFaweG");

    for (int byKosGr = 849389720; byKosGr > 0; byKosGr--) {
        yjqfAFvmLk /= KozmBeaVQrW;
        bqMMoJuU -= MhJBucAHFcrNzpzp;
    }

    for (int IzvNqaL = 651080470; IzvNqaL > 0; IzvNqaL--) {
        lbZMjXOkkQthU /= yjqfAFvmLk;
        yjqfAFvmLk *= bqMMoJuU;
        lbZMjXOkkQthU -= lbZMjXOkkQthU;
    }

    for (int mrBBQHYTGbHFu = 470598337; mrBBQHYTGbHFu > 0; mrBBQHYTGbHFu--) {
        jFLoVmnxbLnG = TgcVKxtEeISuufA;
    }

    return EuDScK;
}

wgyildWybzLZOa::wgyildWybzLZOa()
{
    this->DhSwwfQUcthHg(784713.4886057929, string("XtMhWOVbptBjRhVOxDmyCausjojxkmoftaunAdmSnrwdREQonELUiOPbFhwlw"), true, string("HEOwlehshJpISNdMkyWOlaowavVMZtYeTxCYHRBXlsTfLFQRhSMzjuDKZmeIZNaiaqQiMGriIrHNKcEb"));
    this->Whbqht(false);
    this->NXKEmerRRDwkXu();
    this->LHbszuwiWbgnD(-89076.82908013574);
    this->BjNhnRpgnslawk(string("qUlEqF"));
    this->Psjjk();
    this->ZGwdoIAdOdzBVOG(string("ClVayedSkoWrsjYSLZRdUBWCPXWiSuZPEwRmycJunRvYhvzcHZBXpGAcgVCEvsgKmgKiyGJyAIgYWyxANrjuPMVLZDddPgVYJonZDuQfVkWaYrMQYFmAKPJRUvIvWmYGfShGECuDNOtAcxSHJbtktzF"), -227696.35090815052);
    this->PzUJGs(false, string("GpHoYyuGJsBAHqcKanFhaCGLSQaikctlvAlQgpLhqLHtQRKZxQkZOBJKKPoeLNSekEIaLSupvBsKbiQGjOHLVdKDGJelCIGzAnuO"), -1804684955, false);
    this->IPSRKgZuXn(false, 929895.2305041236);
    this->gqhnuiXH();
    this->NlXTzheWha(string("ALgOofoVebxHCGnzvoasMgFROXffMiPghNvpOCTdSddwrRBIRohgdxvRDrttIwzQTFzXPWqeUsxHqJLdKdLIwlBhaGZHVtcYcWQboBIacDzmJNaGYloRsapMbmVNRMYebChwxTvWePLbuSVDsfOzHBfubImVsSEHwjvoWzNrhwqemxWSErhMMXcVKXGw"), string("UQIRpSJXRHlmLBGcswXNCoNPIfDfPuzgFOhshRQHhFMjqhbzLMvtzGEtQUbeJYMzTnGabmIVzCFwxDtstMXzEYroBfhtUwbVPZyNmSoodpicNhCOSygbxoIrLRhoAotCdjcMQUurjwibxyCRutmxwFsxnlTnKFWXgPhfwiunAiHzqJl"), 1858870148, true, 1574357016);
    this->QGpVhQPJ(806976.6687136168, string("eJSjJQVpeQNYPbLZwAyEeyfsdabaGmMUafHIdVysiiIulrwNBBDnagiwioIEhxtIsQwOzYNYeOXRTYJSSyovKprXCNOVqaWfoEURtywUMbCYbBxPvqKdGoMdLVVeMUfzaJVlgsrPHBXczyJaltBLkAKqPFleoLUNgVN"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class edzNBwyc
{
public:
    string cjNKzSl;
    bool ZHPPzdCqWzKGJgQG;

    edzNBwyc();
    int LytAdiPy();
protected:
    int DAJkKXnH;

    bool pCXgxoEXgtkRI(string khlPtmCJVOimndX, bool LmVTGXoDZjE);
    double dFeTReYSLTB(int jsXCEQSGSYNva, bool IcoAnIyKpDeplM, bool hqTfjb);
    double UEJrYFZO(int ZxJegqgyzWQI, double CPfIIiqEBiTfEv, double BvUqcRPPNnwRL, string OHGLjJFR);
    double rKJJEwkGbxFdNI(int yKUqiqRcA, bool HOJHl, bool hrcHQnkoutYVJP, double jlKjvyMNKmqUk);
    bool lpFSLQVE(double ghlqXjZTtmjm, int AFRugb);
    string hMYCeqyKGSqtEwfF();
private:
    int yadrSrEcf;
    string cfmiIvn;
    string XIWKL;
    string UIpzFug;
    bool FPzpFXgLJginz;
    double RkUZGTWi;

    int tcfYlypklI(bool vdpnIFkwFyX, string sEWXEjB, string hGswIDdwxH, string nycnPFchg, double mruVRQbRm);
    string YfUQpCm(int EGhWQhisSSA, bool EqiLbMX, double ygxBuz, int NSjsZNwTR);
    void UbxoymO(string oPVrOkRCjj, double zkvScOSChKX, bool SutbyAidFXpHrkf);
    bool blPbg(string RmaxSRuewoHuHyDR);
    int gxwwSC(int QJVLyP, int LZhONiQxmaOKc, int yiGpJpFIqlp, double lpArMMmVnPxvfj, double MwgQNrNViUiQG);
};

int edzNBwyc::LytAdiPy()
{
    string VkCAUDeJyCEmp = string("cHQgEfmkNQJDncKRKGOuZHyKquERuuHFFcYuxzpDduJzGKpqZTRpMwkgGeQRbtHhqRZsqxqtVaNXzNWwNqLrbRHShUHfVkseSOGOQtXTxMwpESAeCeUWZrXWZJLopzXZZzJcSrjPQAROGVuTBryWjiRwwPvBKAJRRkTUhsHNlMuWeMHGFFAxNEguolvSyQhCmYYUXheouy");
    string tPxxO = string("UrauPgXWoRnnsZkOSoVYnSEgvssTPJareWOXvogTjabejIAdsMgVUXgtHhmEDzSGTjzvwDnGbuRkohRdbgSmdCQ");
    bool iCufDA = false;
    string IoLnvhP = string("NVOOdmwLrZqOmVJLjeTBcddVmUTQwyuyWnIBgWDkghlcsyQfztLHrIthmukkQnEAbOIDlxRxohiCgIKyHHvVZGfrbQhHnMAKIPYWHdHsToEUTtcGWEZlsHHXifeTqqiYcWNtxjeOufXixNBcKxHqMNbvwoZQZPXHiDiKVKgDDUAjKSNllXlPPHWMHFWggGTCIjJdDymaGkLapxtUCBtP");
    string IvcfojCJvsrwr = string("BRlKmPWfMXtbGnzvEhPixpFzEIDAwmJuVetueOeatsOihIdhUIUjijROzHQHWzDDepBLgjgtIxiMvrlJVkOcuIeCNunOAMGhpgnDtyPXbWqGkbyhBMEIqTfNrEOuBmNOTizOSMKyhceJtizMFuoCgLVbHsHdOlC");
    bool XJCNhEagF = false;
    int HrlKti = -324449124;
    bool aQTWxeY = false;
    int zyoMToNiwLxtsP = 1988912976;
    string CgWHwt = string("JSicYmOVDqghQaesoewyuTITIJAdTXPwVRfSEvoQDvTTaBvevUeDjmFhcUkkUOyPByJHsTJflyWBsRcbAzhIPIdSFqKcHRtMzHdwCOlGHUDAVQkAJdRhRq");

    for (int BxeLXfEJvuS = 1788368834; BxeLXfEJvuS > 0; BxeLXfEJvuS--) {
        CgWHwt = IoLnvhP;
    }

    if (IoLnvhP >= string("cHQgEfmkNQJDncKRKGOuZHyKquERuuHFFcYuxzpDduJzGKpqZTRpMwkgGeQRbtHhqRZsqxqtVaNXzNWwNqLrbRHShUHfVkseSOGOQtXTxMwpESAeCeUWZrXWZJLopzXZZzJcSrjPQAROGVuTBryWjiRwwPvBKAJRRkTUhsHNlMuWeMHGFFAxNEguolvSyQhCmYYUXheouy")) {
        for (int mhNHf = 351282840; mhNHf > 0; mhNHf--) {
            CgWHwt += tPxxO;
            CgWHwt = IvcfojCJvsrwr;
            CgWHwt += IvcfojCJvsrwr;
        }
    }

    for (int WrMawTJV = 2142987830; WrMawTJV > 0; WrMawTJV--) {
        continue;
    }

    for (int KPItVzU = 1873052198; KPItVzU > 0; KPItVzU--) {
        continue;
    }

    for (int ukmUqPlmRpLGIYF = 945122158; ukmUqPlmRpLGIYF > 0; ukmUqPlmRpLGIYF--) {
        continue;
    }

    return zyoMToNiwLxtsP;
}

bool edzNBwyc::pCXgxoEXgtkRI(string khlPtmCJVOimndX, bool LmVTGXoDZjE)
{
    string XXUaqlo = string("EdVfNYIHyUoXxESXQBANWrpCaiQWXdzpGwAVcDXxhjGCUUuyQXrePDwmjAIWOVgnJGQjkYfGasobBXmLbKNywpeFFgHflLjJdyMdDnxSAxDqmyjJdFPAaVQOvTwOeGSurcYagCjwTmBlgNJvmhtNKkGdsyMyGSEdjFqVKHTpacIyNKmRESEyo");
    bool GGZSTaeLH = false;

    if (khlPtmCJVOimndX <= string("QtGdlXXuHjAZkcfdYZMOyo")) {
        for (int FtBiUjbzpIxclBmU = 337864009; FtBiUjbzpIxclBmU > 0; FtBiUjbzpIxclBmU--) {
            khlPtmCJVOimndX += khlPtmCJVOimndX;
        }
    }

    for (int cUoWS = 878599372; cUoWS > 0; cUoWS--) {
        LmVTGXoDZjE = ! LmVTGXoDZjE;
        khlPtmCJVOimndX = XXUaqlo;
        XXUaqlo += XXUaqlo;
        khlPtmCJVOimndX += XXUaqlo;
        GGZSTaeLH = ! LmVTGXoDZjE;
        LmVTGXoDZjE = ! GGZSTaeLH;
        GGZSTaeLH = LmVTGXoDZjE;
    }

    return GGZSTaeLH;
}

double edzNBwyc::dFeTReYSLTB(int jsXCEQSGSYNva, bool IcoAnIyKpDeplM, bool hqTfjb)
{
    bool KsvSUplC = false;
    double jahzpRWVcsRVL = 570461.2426001246;

    if (hqTfjb != false) {
        for (int ShqHMn = 1885480818; ShqHMn > 0; ShqHMn--) {
            hqTfjb = hqTfjb;
            KsvSUplC = ! IcoAnIyKpDeplM;
            KsvSUplC = IcoAnIyKpDeplM;
        }
    }

    return jahzpRWVcsRVL;
}

double edzNBwyc::UEJrYFZO(int ZxJegqgyzWQI, double CPfIIiqEBiTfEv, double BvUqcRPPNnwRL, string OHGLjJFR)
{
    string KcFpcHoCjLzTA = string("ErkJozrYXnrvSDPjanRCmCZauBPKNiYNCxMiaLjaBqGDtMkqrbtKbURBCLBEZnqhnmsIdyXhHdjtWByyUDlzhahOUtrivEMljSTJMhqhTUzlPoCiXjzpPVDptbQpeoOxJAEDzSxebdtEZoTqzVCauHQzxFzymJUUOOoVFwgLfFkeWjumxmWuHc");
    double aIgxthxfo = 439522.3625381317;
    double GbrcvdYXcn = 469064.0819652682;
    double rmVFOfLKE = -604650.79957712;
    bool AkZzn = true;
    bool mmnFtWpOnjOWf = false;
    string pnZxOOwoQTds = string("qadzwOxboYqREPwMWksRCXJzEltYqKNUUWiZDIWbTgCPnCdWcuzMoDajRzrLDYEtQyCPRZVjFPCGPNKLIFYobSKcdJvWDFrrvCfYynkoTcMIPmVODTIwStepLrlQyOBDGbBfrNESxTfYxwiTRIJxniihjHwMgCyaLxTw");
    bool ozHZtUAU = false;
    string wLSTcEiVW = string("kVkBrkaSpPCXbxFUjxjzSuutJMBCtGBErbnrKynAYDZVsUhKjJhETGbsZzfnnTkZzCzAROZDWdsgoQyIfRMPZE");
    string xKZlrLOALV = string("hvpRJUXrScSQBLHfnEYcpytUObdeIEqLcMpJlrMRVXGZrRJCkPtBVSYKNnmDfJYZeOoAokrAqVzorHRtItvKMhBWULPScKcSuPhJtHEkoEzkSvefRhWSOiSGKzlnzXigzANtLfRztDXLsWgClJKxIeeasRQnHDskJSSoEuHGJfcIPtgDHQilatLrYiJRhjuwOMcUWQXXsbJESiZCLpkIaKQxqsMLCilFDTzjGwwjZzD");

    if (aIgxthxfo != -448182.07922764693) {
        for (int LkWYSKJ = 1823151399; LkWYSKJ > 0; LkWYSKJ--) {
            continue;
        }
    }

    for (int aSdhDzdekAqny = 1048221052; aSdhDzdekAqny > 0; aSdhDzdekAqny--) {
        continue;
    }

    for (int LsWehHk = 106259424; LsWehHk > 0; LsWehHk--) {
        KcFpcHoCjLzTA = wLSTcEiVW;
        aIgxthxfo = aIgxthxfo;
        OHGLjJFR += wLSTcEiVW;
    }

    for (int AoZYBZ = 1325512071; AoZYBZ > 0; AoZYBZ--) {
        wLSTcEiVW += wLSTcEiVW;
        xKZlrLOALV += KcFpcHoCjLzTA;
        CPfIIiqEBiTfEv *= rmVFOfLKE;
    }

    return rmVFOfLKE;
}

double edzNBwyc::rKJJEwkGbxFdNI(int yKUqiqRcA, bool HOJHl, bool hrcHQnkoutYVJP, double jlKjvyMNKmqUk)
{
    int YYlPlEO = -822343748;
    bool DnWyVoUMEzV = true;
    double yPuJUFf = -34949.12826889571;
    double OWjYz = 195479.0205230586;
    string AsDrfQdg = string("yGgOaAWJ");
    string WbCrRoLFW = string("rdrnMuB");
    double ElSbuXXSjFGS = -145310.46138582044;
    int lCbZCbpJPtWfSd = 1801347617;

    for (int JwiDdRuCXY = 482101767; JwiDdRuCXY > 0; JwiDdRuCXY--) {
        continue;
    }

    for (int LaYusvVTXoXchF = 758711885; LaYusvVTXoXchF > 0; LaYusvVTXoXchF--) {
        OWjYz /= ElSbuXXSjFGS;
        hrcHQnkoutYVJP = DnWyVoUMEzV;
    }

    return ElSbuXXSjFGS;
}

bool edzNBwyc::lpFSLQVE(double ghlqXjZTtmjm, int AFRugb)
{
    int WClRcLuyZWp = 266433918;
    bool xYuwLJL = true;
    string NkyWFjfKzba = string("pveawCepcIfVWiRNjhOFcRGYdiMudLkoIEkkWdSJjjAqknEXvgzZfyvkRShajXBZxBNIYvflWTpgYwZcPYwJEfPPXGLHovsCDoDYnZyTECqaktQoIgeapFfmzSiqqQWZwGGSAmWxGGpBHmktzHTxYDMgFVlKwoMshDrmaRzJRMLcESWQriIlpFrKwoopaCaqhtiAIvOcidsYWlqpveWDsyePOzOkDMwkyxNWBkDSCnxcGfhmoEvJT");
    bool aELBOsLW = false;
    int bxudbVOUwKqIzKom = 754045875;
    bool jAynzxjSPA = false;
    string ENDkRkOH = string("eeRafVXg");
    string iiwXsUpzemqb = string("tiHhnyVLkAnbjYqBdsUvbqgthmGnUsPpJWokuMdHMxpossdVnJBjRBbrkrhzvlZmokhFWkbuNXyokOoIMsjNq");
    string HJlpwJGOKpsqm = string("ugeexPejKYkyXizeUBBoVgDFfUUeEDaoJZOZakSiStloIExdCAZgzqrcqdjzvjAfEFzUvUGWglcPihIepWSSmqEyxjLFTYdIMTRverfhIfXeYlAbKoDITRQONCFDbmzMiESQtSTyTtJiiwtdZpBlug");

    if (xYuwLJL != false) {
        for (int pcjRmMR = 810590634; pcjRmMR > 0; pcjRmMR--) {
            continue;
        }
    }

    for (int UEQdL = 1283367217; UEQdL > 0; UEQdL--) {
        ghlqXjZTtmjm -= ghlqXjZTtmjm;
        ENDkRkOH += iiwXsUpzemqb;
    }

    if (NkyWFjfKzba >= string("tiHhnyVLkAnbjYqBdsUvbqgthmGnUsPpJWokuMdHMxpossdVnJBjRBbrkrhzvlZmokhFWkbuNXyokOoIMsjNq")) {
        for (int bXfztLX = 1848874650; bXfztLX > 0; bXfztLX--) {
            WClRcLuyZWp /= AFRugb;
        }
    }

    for (int HZmdUUOz = 1553964031; HZmdUUOz > 0; HZmdUUOz--) {
        NkyWFjfKzba = HJlpwJGOKpsqm;
        AFRugb = AFRugb;
        jAynzxjSPA = ! aELBOsLW;
        jAynzxjSPA = ! jAynzxjSPA;
    }

    if (iiwXsUpzemqb <= string("eeRafVXg")) {
        for (int HGRrHRFo = 1368766443; HGRrHRFo > 0; HGRrHRFo--) {
            ENDkRkOH += iiwXsUpzemqb;
            xYuwLJL = ! aELBOsLW;
        }
    }

    for (int XbKJcwiZw = 2109083306; XbKJcwiZw > 0; XbKJcwiZw--) {
        iiwXsUpzemqb = iiwXsUpzemqb;
    }

    for (int GwaJBndcRhlC = 923547038; GwaJBndcRhlC > 0; GwaJBndcRhlC--) {
        HJlpwJGOKpsqm += NkyWFjfKzba;
        jAynzxjSPA = ! jAynzxjSPA;
        iiwXsUpzemqb += HJlpwJGOKpsqm;
    }

    return jAynzxjSPA;
}

string edzNBwyc::hMYCeqyKGSqtEwfF()
{
    bool OVTKCc = false;
    string vCMfW = string("umPrnkUGksvZimbJSoGwpqKpBvVJJJitMMVuvuVNFHfYADRvAkydaTMrHnhfeKiEmfezemviAWZGmHPLdNaQKPsSbyTdqxhVKaLeYsZepyUilMGQ");
    int GyYzurs = -816957448;
    bool uiPTaoryE = true;

    for (int iggjnx = 1750589073; iggjnx > 0; iggjnx--) {
        vCMfW += vCMfW;
        uiPTaoryE = uiPTaoryE;
        OVTKCc = uiPTaoryE;
    }

    for (int qWuzOaXmNUvEo = 837855361; qWuzOaXmNUvEo > 0; qWuzOaXmNUvEo--) {
        GyYzurs *= GyYzurs;
    }

    return vCMfW;
}

int edzNBwyc::tcfYlypklI(bool vdpnIFkwFyX, string sEWXEjB, string hGswIDdwxH, string nycnPFchg, double mruVRQbRm)
{
    int AZkVSIAftOsJDuno = 558878017;
    string MsQSJ = string("vaHmrdokPVDXTizCRgzfceBuJeYXImToqRJdSLiVTCpxQDmJqjjBXjeuXvdipgundFaFbVHaYEdCaHrEZHkcSFqJkVAohvUJpyulvgEfhnvZOSrqkoEtmqIRfAOOhvfFpZBNqbNiBFIGEWnPbqweoIpzUvSaPtvMErMXIabCtvExbCbOonfhPmyyNdVTsNYWSZRPSrKiKsTdDBsjJXprFKF");
    double VSleCEf = 8924.086767420667;
    string VoDJFedtgnhfQn = string("ywbHVlocRpFbqeGPNCnY");
    int oEDesYBO = 438377404;
    int xYxeOPsky = 410967378;
    string vXWCZsspsgOuDh = string("XmNSeiNCARMRqRaruee");
    bool kyAvZXvllAR = false;
    bool fcnBtL = true;
    double QrveJQJIFDVtS = 587993.6685568208;

    if (QrveJQJIFDVtS >= 8924.086767420667) {
        for (int QtxbEhvioqv = 978821441; QtxbEhvioqv > 0; QtxbEhvioqv--) {
            VoDJFedtgnhfQn += VoDJFedtgnhfQn;
            MsQSJ = vXWCZsspsgOuDh;
        }
    }

    for (int vYumgkHhYzRJP = 1018747345; vYumgkHhYzRJP > 0; vYumgkHhYzRJP--) {
        MsQSJ = nycnPFchg;
    }

    return xYxeOPsky;
}

string edzNBwyc::YfUQpCm(int EGhWQhisSSA, bool EqiLbMX, double ygxBuz, int NSjsZNwTR)
{
    string fXdvBpjCxUMJqTn = string("IrwvioxDlwFYZrAptmRrLbdNxhVpPjmlFNHiSMzjiJdvcDQpLxfrkDgQobWtrgGqnieucVCQvGrKLtkyxcbHWxdGgLZDeNOktENfAsjveqGsmgYdrWbostxGyuAZOUwgrDsLmNQSCGYSzMZVNmUNKErcWLTELOpKoFuactmAAaSMDZURkiiWABveeJxOOMfRBvzvYvJkAWtxCnbQVFGwkBaMXdKUCuYQwJImHyyEwBaFFSuafDIjFaq");
    string ABfoT = string("MTotcEYyIxEbfpcPRYmDrUYdZZJbggNYIOguZZTJhdYPMLeKsJjAtJlXMgVhkugKdwHxtuTSCI");
    int lEEpfURmn = -283352403;
    int ISQiqxUFAnSxi = 1291975144;
    string zmNpBxWYiEYAAUJH = string("NrXQXfwPFLOBqireEHZUTbvvhxBmLJBTMdwacKOAhcjqCbpRyAyjjIbMgseWkTbbkaKFejSSYclA");
    int kyuiaPIkEj = -278546417;

    for (int goxrKD = 1655991212; goxrKD > 0; goxrKD--) {
        continue;
    }

    if (EGhWQhisSSA >= 1160428404) {
        for (int eSDFukPoS = 1451778374; eSDFukPoS > 0; eSDFukPoS--) {
            EGhWQhisSSA /= NSjsZNwTR;
            EGhWQhisSSA /= EGhWQhisSSA;
            EGhWQhisSSA += lEEpfURmn;
            zmNpBxWYiEYAAUJH = zmNpBxWYiEYAAUJH;
        }
    }

    for (int hxWrCnChyNK = 1963598400; hxWrCnChyNK > 0; hxWrCnChyNK--) {
        NSjsZNwTR /= kyuiaPIkEj;
        lEEpfURmn /= NSjsZNwTR;
        EGhWQhisSSA += NSjsZNwTR;
        kyuiaPIkEj = EGhWQhisSSA;
    }

    if (kyuiaPIkEj != -283352403) {
        for (int cIAQrpMGjzbghcZ = 1766974230; cIAQrpMGjzbghcZ > 0; cIAQrpMGjzbghcZ--) {
            zmNpBxWYiEYAAUJH += ABfoT;
        }
    }

    for (int xccNUshMVhXS = 794250120; xccNUshMVhXS > 0; xccNUshMVhXS--) {
        continue;
    }

    return zmNpBxWYiEYAAUJH;
}

void edzNBwyc::UbxoymO(string oPVrOkRCjj, double zkvScOSChKX, bool SutbyAidFXpHrkf)
{
    double hnXCJBwZnYptVDRy = 168308.35338067348;

    for (int mfyrjx = 74526068; mfyrjx > 0; mfyrjx--) {
        zkvScOSChKX = zkvScOSChKX;
    }

    if (oPVrOkRCjj == string("smylKEjhMOeXZNXHVCNFwQD")) {
        for (int fukuJvGgJIYZrHu = 1428899793; fukuJvGgJIYZrHu > 0; fukuJvGgJIYZrHu--) {
            zkvScOSChKX *= hnXCJBwZnYptVDRy;
            hnXCJBwZnYptVDRy -= hnXCJBwZnYptVDRy;
        }
    }

    for (int ZXHGQQxdjGg = 848086406; ZXHGQQxdjGg > 0; ZXHGQQxdjGg--) {
        continue;
    }
}

bool edzNBwyc::blPbg(string RmaxSRuewoHuHyDR)
{
    double pbYsaCf = -870810.2337036479;
    double VnhRjEwQhRc = -1047618.9885644068;
    bool XkDPKubpRVANo = true;
    string KtDvqeIlpuMJWtGB = string("MZGqXUhWSjSkuBzsNNRcKEIYDpWchaiMXwesvXleYJo");
    double DRqmMDszL = 962527.9622637898;
    double oUuvQuphsLI = -1034498.2113632351;
    string rotDlDYdlE = string("weaPhBNyMAorRjpCgvNLqsgeTAeRiWihnCSnjuQqkVzqPVuGrjakxpH");
    string JMilp = string("bGDjCSbbBpqmZwxXIiAqSESLFGYftEGuctqlQpquXZcBdrDDDklnDIMBPaeMuKzIwYdyUUfPQYNPEhyybOYkhFOhejnB");
    int CEKKTBOMGrd = -902079438;

    for (int iGKxRUaYvVgZanEH = 1840493363; iGKxRUaYvVgZanEH > 0; iGKxRUaYvVgZanEH--) {
        pbYsaCf += DRqmMDszL;
    }

    return XkDPKubpRVANo;
}

int edzNBwyc::gxwwSC(int QJVLyP, int LZhONiQxmaOKc, int yiGpJpFIqlp, double lpArMMmVnPxvfj, double MwgQNrNViUiQG)
{
    int mnmvvMzWgsv = 605681375;
    string MyhFJKRcAarH = string("OdfIBbnxcXZtoeQhKFXhhhgHFcxoMIQinNUzQCEJYSWhvMnlrVUpWIOFYPkqrCxqBbMfjBoavlU");
    string YQYICffVoUHeRm = string("IlVSBUQmTjAeBiiGAVzPrpmmFMuQOQYQtpjYTsYPacaWahUkYtmSbbdqTjprJLLDvBXwGAmznjzHPqDiMPIYJzafCWAaSdlezbEMURUvbrHvewxTYeYsfAWpjreJtBDLeBVuOPHVReEYAfibctpVzXZG");
    int jcvUbwHy = 871044804;
    string hnxshlsQ = string("OaAsrypKabQrzDxjbpzIoDFmEJDrlUoDQkqvzLzWTOxdzohaOTTDJFnWFmHkBsPzmTOOs");
    int enjXh = -612658140;
    double fXPpXxgNecqDmZeP = -287004.2331825237;
    string jmXgc = string("YGjxrtJFwdNJItyEUOdrGnlHxDwnLwfTcKmZtUIHMRLiHXUallkfvHUwpiUPiwKjpLdwCsZlNgEKxwivBHXIcEJmXCmivBlBbVxUDPHIDnQXgltAiDtcPhobUPKRteGxPpySOqDAueoVuzlmTlxawYbLLBqjK");

    if (enjXh < 239981403) {
        for (int kShATxL = 1457405869; kShATxL > 0; kShATxL--) {
            jcvUbwHy -= mnmvvMzWgsv;
            fXPpXxgNecqDmZeP += fXPpXxgNecqDmZeP;
            QJVLyP /= QJVLyP;
            LZhONiQxmaOKc -= QJVLyP;
        }
    }

    if (LZhONiQxmaOKc != 605681375) {
        for (int sTPiPZmDrP = 191628299; sTPiPZmDrP > 0; sTPiPZmDrP--) {
            mnmvvMzWgsv -= QJVLyP;
            jmXgc = hnxshlsQ;
        }
    }

    return enjXh;
}

edzNBwyc::edzNBwyc()
{
    this->LytAdiPy();
    this->pCXgxoEXgtkRI(string("QtGdlXXuHjAZkcfdYZMOyo"), true);
    this->dFeTReYSLTB(1819287363, false, false);
    this->UEJrYFZO(-765682645, -995654.5998021616, -448182.07922764693, string("SlfbPBzJRImHQuJEeUTedQClvwKzbYRzyQMIlyUuVeMRQjLlOpbThVFYBmhOyKKJdQNbhauwsTKsieYKSYpyvCPGNcPSDOUfpJqKUpIaXWIuDPQxToeYZqpajMszqVIDaKeFDLXLKJxqYovmGqTFqUBvTSBGMmEViQsgcGRylXymOuaVOBeYUhlfBftkDLvtKguXinTwtiuVXTiwDjDfUHhRFVjfGFuHmSpejKXhcSRagGwpSGr"));
    this->rKJJEwkGbxFdNI(-442935336, false, false, -788328.1711772803);
    this->lpFSLQVE(1039669.5453292324, 276601338);
    this->hMYCeqyKGSqtEwfF();
    this->tcfYlypklI(true, string("yMSRjztFgysYUZscaRVXhZDxyzRevHTHFpzlpxFVRDqjDZypRmPrfwJtaJmvXjgbgFfdzFqdkotjzwQXmjaTnAyeFTmiJFpwpAhPnNztnFDnGREIXm"), string("toDUdAsUFkiOBbHVJRequCFmwunXcujhqYDWTbxHPLuIRGkUWuYsQZGtdpYoRbBcKnkNfibEFfcHLbCBULeMSVsSRgLtwkkTbRMteBTSYTuWeAbSkeHmxkbYUYlBnonBAXEblXLusEsWIsXvqGgAcPtdCGFyVEgkTlDMlizdBbNOHjlenOTuURyEAVuntCxviaJUO"), string("nHSLyrUzyFlPMoryZDcrFHIbpWsm"), -612840.5665567808);
    this->YfUQpCm(-1223573868, true, -924248.2444552202, 1160428404);
    this->UbxoymO(string("smylKEjhMOeXZNXHVCNFwQD"), 87993.6446354171, false);
    this->blPbg(string("HkbXpCRNyGHaqkFHztHsrsftcrkYdsKKxuEpxiJuGJZBFerkIkrCirIEYwksZINvEEKdnuCPTmRfFRqnljNQZvwgDkCphVxWwiqtszDNvqvLGYCCYYMfIIULjDgeQgdGmvynGvtUkeaPWHaaLORGUSkTRBeEKmXnLPxQbzAIZ"));
    this->gxwwSC(-2096528083, 1990151876, 239981403, -650233.3154677264, -781668.1498922572);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hgGFdtqUHbc
{
public:
    double gsPLNgSFk;
    double THGfvbwjmasKPQS;
    string NNMRApnmYfqYGDj;
    bool cqXRPUopxkzyviRA;

    hgGFdtqUHbc();
    void OldLXzDdFunvNcI(bool eRLjWshjc);
    void mbegUOUL(string exrShFYhwabdIM);
    double YwzzOGZXJFES(bool DCAlpuzX);
    string kKaWZMBriGhYouG(double dkEQYkhwXoRPEjUq, bool lCqBBAxtjg, int XrKdYfeyFfsb, bool xgLnEMlogGOfPro, bool rTPvlCrZAGgqA);
    bool XQuAaRfxEuFH(bool kdxdkWfD, string xlPObMvlwbzmrFg);
protected:
    string IfiPwptBs;
    int adJlbwKGAvHKhp;
    int vMvihv;
    int YmqTwrG;
    double OsqjKeyyBGmNpJd;
    int EGBqtETgMemxznOq;

    string koIQKSPw(bool hmMfvYjPQqaBbi);
    string pSPloxYZhBROfAM(bool yyjRWSze);
    bool IUeQNwd(bool axlUXvYdPwhDtQl, bool XHoBMADC);
    bool XvGhkoftkNgrnx(string oJlIYOn, string fwiaclmmpGnanvY, double aluNkADoZJ);
private:
    double xdOLMOoUzuw;

    void IAsnJVxoyM(string RhTxRYFvx, int DnQtxfSSO, double HaXrEqsoIWcrdNK, int CTltmkHUDzNwQFTC);
};

void hgGFdtqUHbc::OldLXzDdFunvNcI(bool eRLjWshjc)
{
    int FeZoqRrcx = -275578324;

    if (FeZoqRrcx <= -275578324) {
        for (int hAcchek = 1643245353; hAcchek > 0; hAcchek--) {
            FeZoqRrcx = FeZoqRrcx;
        }
    }

    for (int dKYgR = 1638358779; dKYgR > 0; dKYgR--) {
        continue;
    }

    for (int fimGsZj = 773055954; fimGsZj > 0; fimGsZj--) {
        eRLjWshjc = ! eRLjWshjc;
        FeZoqRrcx = FeZoqRrcx;
    }

    for (int cgxnIvLTtsCm = 524351045; cgxnIvLTtsCm > 0; cgxnIvLTtsCm--) {
        eRLjWshjc = eRLjWshjc;
        eRLjWshjc = eRLjWshjc;
        eRLjWshjc = ! eRLjWshjc;
        eRLjWshjc = eRLjWshjc;
    }

    for (int hfTcuWwC = 1865328303; hfTcuWwC > 0; hfTcuWwC--) {
        FeZoqRrcx += FeZoqRrcx;
        eRLjWshjc = ! eRLjWshjc;
        eRLjWshjc = eRLjWshjc;
        eRLjWshjc = eRLjWshjc;
    }

    if (FeZoqRrcx == -275578324) {
        for (int avYDJzlKS = 348632430; avYDJzlKS > 0; avYDJzlKS--) {
            eRLjWshjc = ! eRLjWshjc;
            FeZoqRrcx -= FeZoqRrcx;
            eRLjWshjc = eRLjWshjc;
        }
    }

    if (FeZoqRrcx <= -275578324) {
        for (int Zpzbps = 818045454; Zpzbps > 0; Zpzbps--) {
            eRLjWshjc = ! eRLjWshjc;
            eRLjWshjc = eRLjWshjc;
            eRLjWshjc = ! eRLjWshjc;
            FeZoqRrcx = FeZoqRrcx;
            eRLjWshjc = eRLjWshjc;
            eRLjWshjc = ! eRLjWshjc;
        }
    }

    for (int EVYdDlimdAJYMlc = 1081142871; EVYdDlimdAJYMlc > 0; EVYdDlimdAJYMlc--) {
        continue;
    }

    if (FeZoqRrcx > -275578324) {
        for (int ECyzgkhJProQZIo = 222800466; ECyzgkhJProQZIo > 0; ECyzgkhJProQZIo--) {
            eRLjWshjc = ! eRLjWshjc;
        }
    }
}

void hgGFdtqUHbc::mbegUOUL(string exrShFYhwabdIM)
{
    int lfTjnBDhdvFnLl = -825578880;
    double CoLvuey = 769975.2592791317;
    double gQrFPpN = -368179.4313136357;
    double FIZwOnpIMdhaiH = -535407.8704682561;
    double tzpEUmcK = 7719.303704198835;
    double ExrNbbBQXuVeSLX = -313777.4870813406;
    string GcXFp = string("LpbTLXlTldZMeUvtikBonum");
    int rOQwStTClniWkAMh = -1196726623;
    bool EinegFlKpJ = true;

    for (int gwwlvcTpTVeXQwm = 1136426585; gwwlvcTpTVeXQwm > 0; gwwlvcTpTVeXQwm--) {
        continue;
    }

    for (int iYLPyydRRkamg = 1282488450; iYLPyydRRkamg > 0; iYLPyydRRkamg--) {
        ExrNbbBQXuVeSLX += FIZwOnpIMdhaiH;
        rOQwStTClniWkAMh /= lfTjnBDhdvFnLl;
    }

    for (int EZDDKmKnrRxaEq = 1985794699; EZDDKmKnrRxaEq > 0; EZDDKmKnrRxaEq--) {
        FIZwOnpIMdhaiH *= gQrFPpN;
        CoLvuey /= FIZwOnpIMdhaiH;
    }

    for (int BWLOZBCEs = 503678552; BWLOZBCEs > 0; BWLOZBCEs--) {
        gQrFPpN /= CoLvuey;
        ExrNbbBQXuVeSLX /= tzpEUmcK;
    }
}

double hgGFdtqUHbc::YwzzOGZXJFES(bool DCAlpuzX)
{
    string GsOMPFrpsTunmuA = string("TprarXQUseeRIgjpDbPOcXtEGKsNY");
    bool ZYvlAnaTuP = false;
    int rWFfscedMWyvxf = 2065731290;
    bool bjzIXQYNXqaULc = true;
    bool uiBQVA = false;
    bool xMnbAa = true;
    string itKSOVWnaCLt = string("hTlmJACACyDQQqqlSpDxGXzqxiplcAMMgWHtCeJTeJfAXKYnOnGqHGMhrjTnjCbipZPpAAmyVBFlzmgWdlXAwqSJYOcjodyvGCLJVpDjBFnJYvxRhAmWrmOoQJWpgYRxHYdTyUawsMSETMchfDIhSgTFvowOhCWYmmixtPKseOnXdjLvbnNfsUGQusAVgxIqhXacKjKokzewAo");
    double OjSJNEgsrs = 760797.0036201348;

    for (int dviAACJwxEna = 2046550557; dviAACJwxEna > 0; dviAACJwxEna--) {
        DCAlpuzX = DCAlpuzX;
        ZYvlAnaTuP = ! uiBQVA;
        rWFfscedMWyvxf += rWFfscedMWyvxf;
    }

    if (DCAlpuzX == true) {
        for (int mbKFNBc = 737511539; mbKFNBc > 0; mbKFNBc--) {
            continue;
        }
    }

    return OjSJNEgsrs;
}

string hgGFdtqUHbc::kKaWZMBriGhYouG(double dkEQYkhwXoRPEjUq, bool lCqBBAxtjg, int XrKdYfeyFfsb, bool xgLnEMlogGOfPro, bool rTPvlCrZAGgqA)
{
    string bkiPHtVFp = string("kXaEvvUTJEMFlKeAiqDJTsgChRWHYwDaGfEQHaSMkkSzJSCrpOlkuFpXgJcodpTsMJJymcXCthcNXZAyfdzElFDcGCJRXmAMchiUgOzswHIgucXcap");
    int cIRns = -943364109;
    string cURdYx = string("wTbhVAyemcFRbooAwUElzFCDPNiYNxjFkYhUoTJDBRQSkUJJxbVtJrooaVvebZAQbFwMeXuOmXCckPkcgfVxJOsuJzXXLgJuVmtrwepyqNqqSnBubHleWGDOKDvMVbkvOJW");
    int foGXbPd = -217356262;
    string gPqBLLUFHQJg = string("bJsRVqAKkLgHmsCgFqrSPrupvlilEyNVuxYEeeClftusamGPWrXVWlfcYJQGEWwCOfCPiwRXlrsiFERiYUiQTioDCRGnRhVLNDZLrnsKnTaJWZHRXcxIDIrfgpsfeECirSnJYWDVRoUWArlLjwkeuFpHhJPafyaJHlHcSSGtWTxPiLvpUdmJbLNOAJGodnDHpVXZyGcuGQaMLwYDguRfKAhvZQmWJZcoiGCQ");
    bool ETEkVEpFUonegUFS = false;
    int MrTXUKk = 575764427;
    string VDbSbtWMt = string("ilgZsRPzlJYgvAUsrzsTIaMuTMjtoKXCHAhFOMpCqpflcOonUQwwNJvvODIKyOxTQadRfnwPpQRbLHXEgfQGdJapmOdlbQbiAjZEyrshmMxARNkpMOkwcUuYlfanMpelcweNgjbbdgsMoCxTqcfmEAiE");
    int oJsvStQWS = -418667390;

    return VDbSbtWMt;
}

bool hgGFdtqUHbc::XQuAaRfxEuFH(bool kdxdkWfD, string xlPObMvlwbzmrFg)
{
    int vqqklutE = -1401569975;
    string LRByaNFQlhdwWO = string("uIsYruZNTTkfdMYTdBtYSUbFwHJhcyLFtyxEqDBjyMTxqiNLAFzwWNgAejAJWcxVOARSLyWDrflRiPsWUUayHDiluGrvGrxQxzuAUhHfJKWCueHeTYRJtBprdrmadtejtbFXWsGEjUryqAVVViexdOVvcnyRTIfmFKmNggfiXuKrCGlLgXbmTtQDqEUerUqzNjvKcmx");
    double QjhiBn = 306364.5893719915;
    bool AlzDNuq = false;
    bool pvqSBIElhC = false;
    int dTmjeDTL = -1833901875;
    bool HrQrGmsZqH = true;

    for (int fVQlPDNqwLI = 1453232233; fVQlPDNqwLI > 0; fVQlPDNqwLI--) {
        continue;
    }

    for (int xnxyrQSIuCFzkG = 762528988; xnxyrQSIuCFzkG > 0; xnxyrQSIuCFzkG--) {
        pvqSBIElhC = ! kdxdkWfD;
    }

    return HrQrGmsZqH;
}

string hgGFdtqUHbc::koIQKSPw(bool hmMfvYjPQqaBbi)
{
    bool mEnsHuHat = false;

    if (mEnsHuHat == true) {
        for (int LkkCetvwAWjZIsWk = 1210312026; LkkCetvwAWjZIsWk > 0; LkkCetvwAWjZIsWk--) {
            hmMfvYjPQqaBbi = ! mEnsHuHat;
            hmMfvYjPQqaBbi = ! hmMfvYjPQqaBbi;
        }
    }

    return string("fmql");
}

string hgGFdtqUHbc::pSPloxYZhBROfAM(bool yyjRWSze)
{
    double FBLABujAOFPQ = -136447.71348362262;
    int WMriDEmakSfzNeR = 1212369866;
    bool uugxv = false;
    bool jmbub = true;
    bool XmQwnzyZDDMIsmn = false;
    int esUQir = 516089206;
    int RSwRypF = -1744818084;
    bool aaEoaNIaJzTigO = true;
    string uJkhIzRhmgvSLfTo = string("AecZeyBZqgSYijdfpLgfVxGJkNMIopMm");

    for (int JjlUBxZP = 2025946015; JjlUBxZP > 0; JjlUBxZP--) {
        XmQwnzyZDDMIsmn = ! uugxv;
        XmQwnzyZDDMIsmn = aaEoaNIaJzTigO;
    }

    for (int UYZsm = 1982141511; UYZsm > 0; UYZsm--) {
        uugxv = XmQwnzyZDDMIsmn;
        yyjRWSze = uugxv;
        jmbub = uugxv;
        yyjRWSze = jmbub;
        jmbub = uugxv;
        RSwRypF /= esUQir;
    }

    if (jmbub != true) {
        for (int AQFyiDWUPOfo = 942682010; AQFyiDWUPOfo > 0; AQFyiDWUPOfo--) {
            jmbub = aaEoaNIaJzTigO;
        }
    }

    for (int bHknzw = 228422821; bHknzw > 0; bHknzw--) {
        RSwRypF -= esUQir;
        XmQwnzyZDDMIsmn = ! jmbub;
        yyjRWSze = uugxv;
        jmbub = XmQwnzyZDDMIsmn;
        jmbub = ! yyjRWSze;
    }

    if (yyjRWSze != false) {
        for (int MOYACjm = 1523110755; MOYACjm > 0; MOYACjm--) {
            yyjRWSze = ! aaEoaNIaJzTigO;
        }
    }

    if (XmQwnzyZDDMIsmn == true) {
        for (int CmAFeUZMCPgKwUq = 86119308; CmAFeUZMCPgKwUq > 0; CmAFeUZMCPgKwUq--) {
            WMriDEmakSfzNeR += RSwRypF;
        }
    }

    return uJkhIzRhmgvSLfTo;
}

bool hgGFdtqUHbc::IUeQNwd(bool axlUXvYdPwhDtQl, bool XHoBMADC)
{
    int cGkjVIrh = 636573231;
    string csueNrjFTifwyLm = string("qmVUhjbIWXHOfHYkYtdqBFgxVixzQgzPIKimIrtJQpxwUtFaRdZcaGichCITMWZGTJhDhNcbUbSAGMukAMZwPAtJMITMfTnACHNCZUnACkCbQuPEdXZxapisuULAvdOVNjnxLvFWnRcJSanJbtt");
    string TxplI = string("tLaggRfzYuSEREgUaCdMckhnxfDtFbYxVpMBHvklyMEWTEzUWCaoRqRCWzrbXYCJulTDaQkArorBlKhJwFgaOveSQtZxhtPwwqQeomzxSuNvyHKVnliNsLQxvILScPsIYhzljxuHaHaBConQQUwifnEDGcwOLUAChyoSpLgmqDDizkRCPEGmjhGPOaDzFRmVnXhRPfdhpRYlXqiEPbboXwyzT");
    int jNzgwPWrPKTSQDK = 338993193;
    string TZdNP = string("lpYPeDZXRbngSXBbAONAiuFmUtwpqJltavyjUVRPXDiGdOtVJMVhFDhiTnMxcrtTMtOYTTUylLwUndmKDnwPuFfGqusVZMZinGjT");
    double EbcHicZjio = -84701.4507982245;
    string TWDkKK = string("UhIEUGFqzsqHZjdYYahLlhEqoDwNtrKQEKiWnhwKMMUKQLfsHwiaSzwWobKZiFcnlJDCglvJCrgcuhiqWBjJCuImNUOdSzeLPWPemIMJ");
    bool SJpaIm = true;
    string wPKbOoke = string("adtyYTJciUfkNERyaxfhpsZPSdkJuwsBntEvxPLlDQvrBfhBJvSQwjKAwTAcxOTfsCsi");

    if (csueNrjFTifwyLm >= string("adtyYTJciUfkNERyaxfhpsZPSdkJuwsBntEvxPLlDQvrBfhBJvSQwjKAwTAcxOTfsCsi")) {
        for (int IYdjQWDh = 1260152553; IYdjQWDh > 0; IYdjQWDh--) {
            continue;
        }
    }

    for (int HfEUkPeW = 852670291; HfEUkPeW > 0; HfEUkPeW--) {
        wPKbOoke = TxplI;
        axlUXvYdPwhDtQl = SJpaIm;
    }

    for (int XtidDziWZFobA = 1770782387; XtidDziWZFobA > 0; XtidDziWZFobA--) {
        TWDkKK += TxplI;
        wPKbOoke += TxplI;
        TxplI += TWDkKK;
    }

    if (TWDkKK <= string("tLaggRfzYuSEREgUaCdMckhnxfDtFbYxVpMBHvklyMEWTEzUWCaoRqRCWzrbXYCJulTDaQkArorBlKhJwFgaOveSQtZxhtPwwqQeomzxSuNvyHKVnliNsLQxvILScPsIYhzljxuHaHaBConQQUwifnEDGcwOLUAChyoSpLgmqDDizkRCPEGmjhGPOaDzFRmVnXhRPfdhpRYlXqiEPbboXwyzT")) {
        for (int piJdiUuTGJBmzFB = 983626574; piJdiUuTGJBmzFB > 0; piJdiUuTGJBmzFB--) {
            continue;
        }
    }

    if (csueNrjFTifwyLm != string("qmVUhjbIWXHOfHYkYtdqBFgxVixzQgzPIKimIrtJQpxwUtFaRdZcaGichCITMWZGTJhDhNcbUbSAGMukAMZwPAtJMITMfTnACHNCZUnACkCbQuPEdXZxapisuULAvdOVNjnxLvFWnRcJSanJbtt")) {
        for (int yQMJqTCMWCWrmyp = 2134784741; yQMJqTCMWCWrmyp > 0; yQMJqTCMWCWrmyp--) {
            EbcHicZjio -= EbcHicZjio;
            TZdNP = TxplI;
            wPKbOoke += TWDkKK;
        }
    }

    return SJpaIm;
}

bool hgGFdtqUHbc::XvGhkoftkNgrnx(string oJlIYOn, string fwiaclmmpGnanvY, double aluNkADoZJ)
{
    string RyBTrXfZBXNwrPQ = string("rcMvutkArXfeyXcCHsNmhFculxJXBVfARZspcyZFuEMeymIIjnRpuWilffMEqRTYZgETqhUbApAXvjtPCzKwcTkjLPALbtwRpeNYfJXIZeaapoXVaVyBVCHbJLJJogLuGuRTChaaEIsFIQHhOAeAGgpVAalyEKhcpKbnhc");
    double mnEEqCrI = 550973.9229096497;
    bool IYJwutFNPTRnzD = true;
    bool OWKDocojACfGN = false;
    bool LzbmnNdZQ = false;

    return LzbmnNdZQ;
}

void hgGFdtqUHbc::IAsnJVxoyM(string RhTxRYFvx, int DnQtxfSSO, double HaXrEqsoIWcrdNK, int CTltmkHUDzNwQFTC)
{
    bool zeAxHiFvpwuRr = false;
    int oaSMWSfVpVa = -1735492034;
    int xFvDBY = -1203804395;
    string PpBzbInTfTOpV = string("FddVFQiRsLIp");
    string xqbeh = string("kCpZvUByt");
    int uMfieZoR = 946190849;
    string LCRqIBmYynXWpVJh = string("umVjpFeXMqOewFjJvLETHIxnuIAriTLFvLiJAuGPASKknmqzjVCJzYQlQ");
    double QuFMvqgDPg = 301838.02178024896;
    int ZwbOzLKAnqVje = 727154591;

    for (int YZQiajUwyN = 292280368; YZQiajUwyN > 0; YZQiajUwyN--) {
        continue;
    }

    if (xFvDBY != -2131857795) {
        for (int bhqjda = 1672947502; bhqjda > 0; bhqjda--) {
            RhTxRYFvx += RhTxRYFvx;
            DnQtxfSSO /= xFvDBY;
            DnQtxfSSO = DnQtxfSSO;
        }
    }

    for (int XCmgnZgSOgXFI = 831979330; XCmgnZgSOgXFI > 0; XCmgnZgSOgXFI--) {
        PpBzbInTfTOpV += RhTxRYFvx;
        PpBzbInTfTOpV = xqbeh;
        RhTxRYFvx = LCRqIBmYynXWpVJh;
        uMfieZoR /= DnQtxfSSO;
        DnQtxfSSO = uMfieZoR;
    }
}

hgGFdtqUHbc::hgGFdtqUHbc()
{
    this->OldLXzDdFunvNcI(false);
    this->mbegUOUL(string("UskxvkeTDGWpekd"));
    this->YwzzOGZXJFES(false);
    this->kKaWZMBriGhYouG(-769853.5452847335, false, 2115284182, false, true);
    this->XQuAaRfxEuFH(true, string("hqkZeoqOhTFatAqczqLhAzTunXgLesREAiXvxDcKvupScrJNZgMSnGyEEshOIoxpbPGerlSKbStIObiTTpTamxMWtcNMrxFChAVVuLRoQkRVsozQSpYmlUEtuZlyioNNRrmhvDIuRjUYEWDrAMBnXCUKXAwsKnDBVNSAiHMjFLugHKqUUbcfzzAEODUxrHBjKMkrhBXHtqERkiCckYSfvZkMcGgGkaucTkQqJmJDCFafR"));
    this->koIQKSPw(true);
    this->pSPloxYZhBROfAM(false);
    this->IUeQNwd(true, true);
    this->XvGhkoftkNgrnx(string("DmcUsUGyTMzpGuhKyddvuOehabvEbERuQLUVskJQliQnfzAplVmPnclQwZxYIZbFzygMXtTHktwsIgGYXrddFmlyuorfuzAjPdwYjdnehnFrVKcRUQzWgaYPrELhpoBplupSLdsUfmrYtwmweOeNxEVqpnSKHIDyPgzaeqCSZkuKQPOpnkVjWVyopxzOpEGhkqjTIyHsryTDnVDLwTdStSonlbsVJPjxmbVTHWFbBUGBYMWLAPcUHjpiMuVPKP"), string("RcECLxRSfmWKWUktLFELiWevEcxkJimHKycjTLIUqlKU"), 501588.20869394985);
    this->IAsnJVxoyM(string("UmBgdZDOxgcNiboloJHVIQVgqDObKOaFAITKgNCbgLNDJvljemoedbPRxUVuCZaJLArHoTRkwCsuJGdKkWMuwVPzAnhKGimRuPXXiGeUQsvliBxzdsTpITmlxtCwkveNNzhQkUxktXZLKlJqZwWHI"), -2131857795, -39097.58565339915, -505753885);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mSOCFQOzRVa
{
public:
    int JDGkQirNc;
    string oWcpLGgiDDbG;
    string YzcaXnnCNJMzuqt;
    string sysmtBssxC;
    double uNkPhOHPaE;

    mSOCFQOzRVa();
    bool dEgOqkwC(double OmHqFfSM, bool chyfCkn, double qZQWrpGg);
    bool snWxBeWO();
    bool MejSyQL(int xpOLflXlzaQsvR, double pirrvAHZwZH, double eveqDz);
    int sTLrkiRphG(double BiyKqWSAicoGJ, double SRVdueiobJh);
    int AUcEZAGNzUYLaU();
    int MynXyoP(double fWjeEGyow, string GGCKuxsnUd);
protected:
    string XVlFVUR;
    int HGWfMDFbk;
    int bYEdJ;
    bool RPypyK;

    int kZNrxXZp(int ZWxvfCzBiriOF, double xEklue, string SOsVlIi, bool CaWukye, bool JqkjkJzWqGIdNhtZ);
    string NAHQzMBD();
    double XWACteby(int hCefrqxYl, int KnRdwo, bool pfpjCAVbLC, int wbGgDL, int WROfBLOmHhTlig);
    bool NZxMBbwYhrzRb(int SqxZIJVJMO);
    string eYsxzWcWyAHj(double LDGrotXinMeXr, string aPhMxtCQZujRZ, int SWWsTyRctNOUVxvT);
    double ZxunkiNO(bool HeinUeFq, string dnHNTVy);
    string aKAwpTwJSsC(bool VexgXoWCxcJR, double CripRYc, bool JsANzaZfQTtU, double VAQUZYbNW);
    double XXyxD(int hgBsbYFaN, double EULRMhaSWCWkVJrt, string pjgMZ);
private:
    string TGaUrV;
    int ZQOLpcNfw;
    double mUyyhjQ;

    int QGrnsy(bool yLrOkGJWeeeE, double xELdDVQpKohc);
    void iVfbDUS(double LuOcPgMAVz, int IFUpaZwE);
    int UAhuCDwrsUeQtSVm();
    void rfQMNWIaXAQX(int krFewkXSyic, double HqRaXFOVd, int ntvLaRrGEpfpt, int FyzLcQytWxYk);
};

bool mSOCFQOzRVa::dEgOqkwC(double OmHqFfSM, bool chyfCkn, double qZQWrpGg)
{
    double SJDELH = -707244.0918429988;

    if (qZQWrpGg != -707244.0918429988) {
        for (int XBYOwpMuzVLHvqR = 1443462723; XBYOwpMuzVLHvqR > 0; XBYOwpMuzVLHvqR--) {
            OmHqFfSM -= OmHqFfSM;
        }
    }

    return chyfCkn;
}

bool mSOCFQOzRVa::snWxBeWO()
{
    bool zTKfxLEmvmrVfi = true;
    string FiYeaLtvsG = string("qGqkMQpKFiXrsjKQGOTIjLqdSuFPdhOIuwzbclWjcRLkPvPygQvVlxGKfJcFTUvezAERQxNqgyryBzZXJHWpjZtlztojfBRxsHoEsgoTIWNDkJFORkAaxBOheGnGlpHzYvDOaSUefEKGcnkIMdeqRiNcwGoOepFMFbafEkgSlNnarbWFrYYjRrhbIrExOvBtHOeETalBuYZnuNYscIegVImwzWUaGGVBH");
    double fmMBGIlswmkozz = -568259.7987305315;
    double EXmkeaVaHqfUGaj = -889471.8644981295;
    bool Iewfn = true;
    string sOtKvRZIlwOz = string("dIcWVUUhbirHhGZwzVLygGVwsqySuJanELGEcyBYyMEPCyaEqCUQXJsTealQWwyHOMpiQqPVXbAUBSBwDoNmxmTffzmfHWGGDQSbggWupqgBsbUgFEqTvQAahhyEQPcjOqWGUQSUmmzy");
    double sZqLohodtlg = -968622.299166974;

    if (sZqLohodtlg >= -968622.299166974) {
        for (int ZenKvYfXbb = 714923952; ZenKvYfXbb > 0; ZenKvYfXbb--) {
            fmMBGIlswmkozz *= sZqLohodtlg;
            fmMBGIlswmkozz = EXmkeaVaHqfUGaj;
            sZqLohodtlg *= EXmkeaVaHqfUGaj;
            fmMBGIlswmkozz *= fmMBGIlswmkozz;
            sZqLohodtlg *= sZqLohodtlg;
            FiYeaLtvsG = sOtKvRZIlwOz;
        }
    }

    if (fmMBGIlswmkozz < -568259.7987305315) {
        for (int qQmizCSll = 1365725199; qQmizCSll > 0; qQmizCSll--) {
            continue;
        }
    }

    if (EXmkeaVaHqfUGaj < -968622.299166974) {
        for (int cTTpWTAarUULo = 254786161; cTTpWTAarUULo > 0; cTTpWTAarUULo--) {
            FiYeaLtvsG += sOtKvRZIlwOz;
            sOtKvRZIlwOz = FiYeaLtvsG;
            sZqLohodtlg = EXmkeaVaHqfUGaj;
        }
    }

    return Iewfn;
}

bool mSOCFQOzRVa::MejSyQL(int xpOLflXlzaQsvR, double pirrvAHZwZH, double eveqDz)
{
    string ERHZwLrl = string("yzRPpAwiMXpFjvYFIGpoBdLUIHYRZQKyfQJENYgdXNiPjhCHnnUMdqElHbuKmDXcYByewediLBjZrWnMbTOEkRiDLszVSeEvbwHXNnVLUlKOwlHSNkiyNaWQhaBxHOkhmYsCRYWCvTCBg");

    if (xpOLflXlzaQsvR < 411072310) {
        for (int DnLIulDMOR = 1359987838; DnLIulDMOR > 0; DnLIulDMOR--) {
            pirrvAHZwZH += pirrvAHZwZH;
            pirrvAHZwZH = eveqDz;
            xpOLflXlzaQsvR /= xpOLflXlzaQsvR;
            eveqDz *= pirrvAHZwZH;
            eveqDz *= pirrvAHZwZH;
            eveqDz /= pirrvAHZwZH;
        }
    }

    return false;
}

int mSOCFQOzRVa::sTLrkiRphG(double BiyKqWSAicoGJ, double SRVdueiobJh)
{
    string jhHXNjICyswoh = string("iJHZBWCVNajOTinCwgBmGHiYCElWZFDlygXxEjRoMAckVDjhocUDLBxjbkELpvwVDNGJgNEOnRklRjbTLyNtLEMhJxyglxKUeezsmNdEOWYGqzVixLheNNijSbJvcauBsJMeYOVfVbuvw");
    string hHrjeybChqDM = string("dosIIzOcOmsknFWkFttgjXuzUNthAVmWwIkUeuZUKbjXLNpbLgazKtaaIrueLNqGPFcbMuYzATTSuQTmUnEvYggwuzgyQOgreIyWufyAqjpICUHrzaMfubMHLlBWTAtGlidPdnbXOCPWncqfPxeucUGzjUYgmYEicCKIbzdVBCvDNYiL");
    double TJlxvXE = -785246.0246994678;
    int wyKxCkOCzyHbQz = -1061072321;

    if (hHrjeybChqDM != string("iJHZBWCVNajOTinCwgBmGHiYCElWZFDlygXxEjRoMAckVDjhocUDLBxjbkELpvwVDNGJgNEOnRklRjbTLyNtLEMhJxyglxKUeezsmNdEOWYGqzVixLheNNijSbJvcauBsJMeYOVfVbuvw")) {
        for (int bLQNEXEW = 1100316708; bLQNEXEW > 0; bLQNEXEW--) {
            continue;
        }
    }

    if (BiyKqWSAicoGJ != -480908.73020210065) {
        for (int qVEqWB = 736249287; qVEqWB > 0; qVEqWB--) {
            BiyKqWSAicoGJ -= BiyKqWSAicoGJ;
            jhHXNjICyswoh += hHrjeybChqDM;
        }
    }

    if (BiyKqWSAicoGJ > -480908.73020210065) {
        for (int oYCBfFZROSR = 1890752283; oYCBfFZROSR > 0; oYCBfFZROSR--) {
            continue;
        }
    }

    for (int CFEzwvZyMJEiAzO = 2003981147; CFEzwvZyMJEiAzO > 0; CFEzwvZyMJEiAzO--) {
        SRVdueiobJh += SRVdueiobJh;
        wyKxCkOCzyHbQz = wyKxCkOCzyHbQz;
        SRVdueiobJh -= SRVdueiobJh;
    }

    for (int ooSTGcSP = 1637742035; ooSTGcSP > 0; ooSTGcSP--) {
        SRVdueiobJh *= BiyKqWSAicoGJ;
        hHrjeybChqDM += jhHXNjICyswoh;
        TJlxvXE = TJlxvXE;
        hHrjeybChqDM = jhHXNjICyswoh;
        TJlxvXE += BiyKqWSAicoGJ;
    }

    return wyKxCkOCzyHbQz;
}

int mSOCFQOzRVa::AUcEZAGNzUYLaU()
{
    string lqQOCGdZkCR = string("zUSHeqUvfprdgEzeUtaXFxwMENKlMxkBvnyXdpoRzcPJbXFWjSSqOFcrZqmnpzMweREztCSlXSGdQBFcddtSAyECnpKzwmEDpsLFbhOOqDhinWqJydf");
    string FFIjpPDdpPsB = string("qVFZKWzkMRQuTuSqHJduLucvkXftUYYsfUBbQLGVlXGIzcapqsJzoTVbyCsqROzwvtxRsTrvSzmDbqsDkshISWLkReyHmgjQXYsbhQNrJNWRvNFUAECsEkbRHSbpvHLpvZENfcOZGrznKMqAIWHNQEpLBhKpZigaFTKAgeeYlpfudaUvrCAEkwbdUpqRpUmoObKEsOcglZqnmOYnbwgJhGQUOiIqhZoicxdmkWkjHtC");
    double wpgmXr = 712747.2552521912;
    bool AuvsMwSDq = true;
    double ibDokKmxxo = 508648.4977655641;
    int ohVOyGeV = -1744420169;
    int PrGfhTGnSHjhm = 119468382;
    bool jTXjwMpDRySJllHL = true;
    int rOvnGKCVqcUbhY = -852465122;

    for (int woJjJBftBmD = 1842624801; woJjJBftBmD > 0; woJjJBftBmD--) {
        continue;
    }

    for (int eqYwoeCTCBxYZNTb = 1446855540; eqYwoeCTCBxYZNTb > 0; eqYwoeCTCBxYZNTb--) {
        PrGfhTGnSHjhm *= PrGfhTGnSHjhm;
        lqQOCGdZkCR += FFIjpPDdpPsB;
    }

    if (ibDokKmxxo < 712747.2552521912) {
        for (int uhliDzIzv = 1541379638; uhliDzIzv > 0; uhliDzIzv--) {
            FFIjpPDdpPsB += lqQOCGdZkCR;
            rOvnGKCVqcUbhY = rOvnGKCVqcUbhY;
            AuvsMwSDq = jTXjwMpDRySJllHL;
        }
    }

    if (PrGfhTGnSHjhm == -1744420169) {
        for (int GYYNNAPkFL = 1191687985; GYYNNAPkFL > 0; GYYNNAPkFL--) {
            ibDokKmxxo = ibDokKmxxo;
        }
    }

    return rOvnGKCVqcUbhY;
}

int mSOCFQOzRVa::MynXyoP(double fWjeEGyow, string GGCKuxsnUd)
{
    bool rFyGgdiHGpGH = true;

    return -884828434;
}

int mSOCFQOzRVa::kZNrxXZp(int ZWxvfCzBiriOF, double xEklue, string SOsVlIi, bool CaWukye, bool JqkjkJzWqGIdNhtZ)
{
    bool iddBoLuBmYCuIud = true;
    double GvIjyW = 891841.3574762137;
    int TUwcNgTFbvso = 681090262;

    for (int UtAjLbOJHwjRY = 176411723; UtAjLbOJHwjRY > 0; UtAjLbOJHwjRY--) {
        GvIjyW *= xEklue;
        CaWukye = iddBoLuBmYCuIud;
    }

    if (TUwcNgTFbvso >= 681090262) {
        for (int AtUyZt = 1474309328; AtUyZt > 0; AtUyZt--) {
            SOsVlIi = SOsVlIi;
            TUwcNgTFbvso *= ZWxvfCzBiriOF;
            xEklue += xEklue;
            JqkjkJzWqGIdNhtZ = ! CaWukye;
        }
    }

    for (int MeKgTmAklrsKumzW = 1288345227; MeKgTmAklrsKumzW > 0; MeKgTmAklrsKumzW--) {
        continue;
    }

    return TUwcNgTFbvso;
}

string mSOCFQOzRVa::NAHQzMBD()
{
    int yRWbFFHJnUKbDp = -881778899;
    string DxxbJjkUONaITNoP = string("TIFMXuOGgodImvxAWUFKcpEFOcfixOmVuBtnRFwmgUSILdeqjfbpFxHSaWSMgfpCZhQaLtLdvmaoeCgiWFmUUsVJfjdgdchaQMyLDtUeUGFaAQhJlYbcjmndnvbnvAbKlZsHfGZdwpLePfHrHgbl");
    double wGtTfrx = 532067.2590678739;

    if (wGtTfrx >= 532067.2590678739) {
        for (int tOjpP = 1939182541; tOjpP > 0; tOjpP--) {
            continue;
        }
    }

    for (int TWTEeC = 469208204; TWTEeC > 0; TWTEeC--) {
        continue;
    }

    for (int psZvv = 295896604; psZvv > 0; psZvv--) {
        wGtTfrx *= wGtTfrx;
        DxxbJjkUONaITNoP += DxxbJjkUONaITNoP;
        wGtTfrx /= wGtTfrx;
        DxxbJjkUONaITNoP += DxxbJjkUONaITNoP;
    }

    if (DxxbJjkUONaITNoP > string("TIFMXuOGgodImvxAWUFKcpEFOcfixOmVuBtnRFwmgUSILdeqjfbpFxHSaWSMgfpCZhQaLtLdvmaoeCgiWFmUUsVJfjdgdchaQMyLDtUeUGFaAQhJlYbcjmndnvbnvAbKlZsHfGZdwpLePfHrHgbl")) {
        for (int GDnuxfwsLuat = 281048478; GDnuxfwsLuat > 0; GDnuxfwsLuat--) {
            DxxbJjkUONaITNoP = DxxbJjkUONaITNoP;
            yRWbFFHJnUKbDp /= yRWbFFHJnUKbDp;
        }
    }

    return DxxbJjkUONaITNoP;
}

double mSOCFQOzRVa::XWACteby(int hCefrqxYl, int KnRdwo, bool pfpjCAVbLC, int wbGgDL, int WROfBLOmHhTlig)
{
    double vHzugqrPCMKzEHa = -129277.34438172738;
    bool nKZFiDhzAL = true;
    double HBaQrYgwywJefyxz = -204064.5542439132;
    bool fZvTJxZQl = false;
    bool kWtGkNSgMqZU = false;
    double hmbcEfFBoU = 1034435.8446917123;
    string flXWfjdJmRVd = string("vziYFkqVKdXHQhtfTNZAXnteYrnCnQGxVWimKrBFoNYpmwTKsoMQlGlwAScZqGzmFeCJJfdWcLmHJYKw");
    string MEtIEn = string("EYoFloZImIBvQMlTLAlGxhQalnWMzeSJSwzoIzoyHxsJTORYlZVUKHnkdyphGAxsWHarGGWjAak");
    bool daoFosLdQa = true;
    int vutuy = 1628936484;

    for (int KTGWiOOgqO = 38292235; KTGWiOOgqO > 0; KTGWiOOgqO--) {
        hCefrqxYl += wbGgDL;
        fZvTJxZQl = fZvTJxZQl;
    }

    for (int CnQKQTMqy = 576203883; CnQKQTMqy > 0; CnQKQTMqy--) {
        WROfBLOmHhTlig += vutuy;
        hCefrqxYl += WROfBLOmHhTlig;
        KnRdwo += WROfBLOmHhTlig;
        wbGgDL += WROfBLOmHhTlig;
    }

    for (int thXUIMSqx = 95735395; thXUIMSqx > 0; thXUIMSqx--) {
        continue;
    }

    for (int UqGECvkd = 509222559; UqGECvkd > 0; UqGECvkd--) {
        continue;
    }

    for (int WLIhxSwoMtBQUHw = 1219645715; WLIhxSwoMtBQUHw > 0; WLIhxSwoMtBQUHw--) {
        WROfBLOmHhTlig *= KnRdwo;
        daoFosLdQa = kWtGkNSgMqZU;
    }

    for (int YgpxzPYmJTdPs = 998461729; YgpxzPYmJTdPs > 0; YgpxzPYmJTdPs--) {
        hCefrqxYl = hCefrqxYl;
        vutuy += vutuy;
    }

    return hmbcEfFBoU;
}

bool mSOCFQOzRVa::NZxMBbwYhrzRb(int SqxZIJVJMO)
{
    int GocsZW = -1435944048;
    string ahZFfvaBgSRLt = string("LlgMYNgnYxcwsDfCxRWuaPQbuTgSFjRaMbBAUkxzIapJFWHMUKsxRgjLgwUxyJtpqcrzgoMUOMRJbRBvGXphkweyeIiAwBwmbnPhELuxqonreJJmQHRMKIInySJMjCobDRsgNGaNbogldCgqiqYeaMgjVPlxoIUIRrkzwWhYxajCZrVJcFASonlZAgnPNNsWULbbkKwcMRs");
    int DlfDcOy = 338725474;
    double JdiWoJAKusubFQ = 607093.1289177807;
    bool BSZqZathISIdsrE = false;
    string pXVmUgwrvjojsaH = string("pvOionIolndUhMVKRtkZBVAZWMJhwRqgtpytQxkOATogJVNZzgAZCUkKAYEZxrFiSguRBpyvEGGFWdhidjMqQzlNGqjMnu");
    string PRyTwZyKsNDvcbgl = string("oQImtthXDwJjMqWLqZpNrQvsYnVZiZstcDBwMLqybebOKUUUIOcBqFNUWcUhTksbUEmrMUhrOHjytJFMinoWInHQOjyHDbrdHrUGQKDKc");
    int qGjrFsPVBJWwgrV = -2113790093;
    string HcDIVFqlR = string("yhdZcdgeuEsGIxRwGsKgnTLeCDBjraSTYxeoRBtHLHbsOeoyCsGMqKOlDYNLLFWUXsdzpKwjpPdkoPsGIWUnYULWcc");

    if (PRyTwZyKsNDvcbgl != string("oQImtthXDwJjMqWLqZpNrQvsYnVZiZstcDBwMLqybebOKUUUIOcBqFNUWcUhTksbUEmrMUhrOHjytJFMinoWInHQOjyHDbrdHrUGQKDKc")) {
        for (int buAeTqUelFykk = 975079664; buAeTqUelFykk > 0; buAeTqUelFykk--) {
            pXVmUgwrvjojsaH += pXVmUgwrvjojsaH;
            qGjrFsPVBJWwgrV *= DlfDcOy;
        }
    }

    for (int mmbQIaAIdfuVo = 494425687; mmbQIaAIdfuVo > 0; mmbQIaAIdfuVo--) {
        DlfDcOy = qGjrFsPVBJWwgrV;
    }

    for (int vWeJcYb = 119631685; vWeJcYb > 0; vWeJcYb--) {
        HcDIVFqlR += ahZFfvaBgSRLt;
        JdiWoJAKusubFQ -= JdiWoJAKusubFQ;
        SqxZIJVJMO -= GocsZW;
        pXVmUgwrvjojsaH = ahZFfvaBgSRLt;
        DlfDcOy = DlfDcOy;
    }

    for (int dVHQQSuapMyc = 1827939430; dVHQQSuapMyc > 0; dVHQQSuapMyc--) {
        continue;
    }

    for (int JFxdiEaezzJQH = 926196208; JFxdiEaezzJQH > 0; JFxdiEaezzJQH--) {
        continue;
    }

    return BSZqZathISIdsrE;
}

string mSOCFQOzRVa::eYsxzWcWyAHj(double LDGrotXinMeXr, string aPhMxtCQZujRZ, int SWWsTyRctNOUVxvT)
{
    string OjiDHVaKfmPKMK = string("aKYKbNkmUsXDBIurpfofBCEIemVhgOIoxPqLxLsvFUrmubYskmmIVucRFBTgttmfxesoEnHxlprWPTIkoFNWYUEYGDXFb");
    string TPXPjnYyBlNfLvLA = string("SVfazeAtvhaKkeiSJRoFyqVhPDkYNppkMdjAAjwsYeyIarjYiqcuVNygYjWvdvwHhWYgshOjQxsFmiTooCmZM");

    if (aPhMxtCQZujRZ == string("aKYKbNkmUsXDBIurpfofBCEIemVhgOIoxPqLxLsvFUrmubYskmmIVucRFBTgttmfxesoEnHxlprWPTIkoFNWYUEYGDXFb")) {
        for (int fLEtWeZeBAfub = 531541917; fLEtWeZeBAfub > 0; fLEtWeZeBAfub--) {
            aPhMxtCQZujRZ += OjiDHVaKfmPKMK;
            aPhMxtCQZujRZ = TPXPjnYyBlNfLvLA;
        }
    }

    return TPXPjnYyBlNfLvLA;
}

double mSOCFQOzRVa::ZxunkiNO(bool HeinUeFq, string dnHNTVy)
{
    string DJIfMN = string("lENdEuEFXUpQYJctNRWKDBTNTbbPpkkAZPjSNcNGWuKCwtisioSYhagrPufmuqsOIbdVRhPSLFoFGqHFNcpaQoPiJNxCyLLHLYvPAOGaNgpJOWAPdlZKqaacQIRUusjCbzrFAMpjgmPUTcncXlkxMLtRGRYtlMTrwngw");
    bool VeXznaLumis = true;
    bool qJnvVMfrvboaaegZ = true;

    if (qJnvVMfrvboaaegZ == false) {
        for (int MQUdVwfkHkaT = 1960009731; MQUdVwfkHkaT > 0; MQUdVwfkHkaT--) {
            dnHNTVy += DJIfMN;
        }
    }

    return 906896.5970803546;
}

string mSOCFQOzRVa::aKAwpTwJSsC(bool VexgXoWCxcJR, double CripRYc, bool JsANzaZfQTtU, double VAQUZYbNW)
{
    bool derpOR = false;
    bool qPxbMnbMaXtTP = false;
    double czGqlEeGXIKNLUSk = -323135.29765216215;
    double NbJHFMfZgCOFcVAY = 713378.6895248861;
    double DmjPd = -681903.5203086712;
    bool QXeQunwNku = false;
    int NWOCZRmYRqetY = -1535548561;
    int EPnfSxmVGjqtfUt = -1673123768;
    int CpbifPL = 1240054317;

    return string("oacxyGnqvCUngqZjmqlBXyOLfUpnDaRgqvywGqlNefITTIZDBTeMY");
}

double mSOCFQOzRVa::XXyxD(int hgBsbYFaN, double EULRMhaSWCWkVJrt, string pjgMZ)
{
    double NjOHTwEn = 528715.2091930144;
    double WcnFXk = 715402.320026604;
    int emIYsXiHZnGNp = 284195906;
    bool ljGDBOTVnYFpGO = false;
    int wINjLZuazfxpKk = -1411214249;
    string bcFPVhXDXh = string("mdUGe");

    if (wINjLZuazfxpKk < 284195906) {
        for (int aElZFQukIrdWM = 1207990282; aElZFQukIrdWM > 0; aElZFQukIrdWM--) {
            wINjLZuazfxpKk /= emIYsXiHZnGNp;
            NjOHTwEn -= NjOHTwEn;
            WcnFXk *= EULRMhaSWCWkVJrt;
        }
    }

    for (int FVbzCiM = 40982664; FVbzCiM > 0; FVbzCiM--) {
        continue;
    }

    if (bcFPVhXDXh < string("mdUGe")) {
        for (int qDPbn = 99181281; qDPbn > 0; qDPbn--) {
            NjOHTwEn += WcnFXk;
            EULRMhaSWCWkVJrt /= NjOHTwEn;
        }
    }

    return WcnFXk;
}

int mSOCFQOzRVa::QGrnsy(bool yLrOkGJWeeeE, double xELdDVQpKohc)
{
    bool bSQqOrooJwBcJ = true;
    int xQhfsLONkvPnyNUW = -519499111;
    int JIOhgwpxKI = -558960998;
    double suelUMTHY = -749553.4478118473;

    if (bSQqOrooJwBcJ == true) {
        for (int TrclSI = 1218630255; TrclSI > 0; TrclSI--) {
            bSQqOrooJwBcJ = ! yLrOkGJWeeeE;
        }
    }

    return JIOhgwpxKI;
}

void mSOCFQOzRVa::iVfbDUS(double LuOcPgMAVz, int IFUpaZwE)
{
    double xtIrXNnnkbkmOg = -86969.62888749373;
    string rZLFOI = string("RSaQfJRGwUif");
    int XmLCTFPZPqyYXWao = -1165628132;
    double YqptpXevmgeNTHLe = 203357.42652583768;
    int qtLuFkisw = 455508327;

    if (IFUpaZwE >= -1165628132) {
        for (int rDZjdb = 1608445198; rDZjdb > 0; rDZjdb--) {
            IFUpaZwE -= XmLCTFPZPqyYXWao;
            IFUpaZwE *= qtLuFkisw;
            LuOcPgMAVz *= LuOcPgMAVz;
            xtIrXNnnkbkmOg -= YqptpXevmgeNTHLe;
            IFUpaZwE += XmLCTFPZPqyYXWao;
        }
    }

    for (int sAPacmmJ = 579628433; sAPacmmJ > 0; sAPacmmJ--) {
        XmLCTFPZPqyYXWao = qtLuFkisw;
    }
}

int mSOCFQOzRVa::UAhuCDwrsUeQtSVm()
{
    int CBABIIQMK = -1148897681;
    string dJRqilmr = string("rtCyCWOGVLGGtILodBTFMcAsGgaOIGkVXDMhNMfuaUFeOzFLFTcwCUCctVqHTDEBUoFrBkHGcREGQNqFzADkpYZuhzUXROWxtEOWJySXKOPDcrtcYXrVXaTMwZkWTgITrEnGlcTfmfVXvEpNuaMsjsMvPsTLjMLFCaYgHzOxOeASaGfRPpoeFqsaybedIcTopbYDgQbvXBuYlzNeHkMLaldgkRDyjegKUZIYmh");
    double WBrRCn = 24439.7977939874;
    double kRmCxzujw = -822012.3883699185;

    for (int LYiwFinQPyf = 1463119280; LYiwFinQPyf > 0; LYiwFinQPyf--) {
        continue;
    }

    return CBABIIQMK;
}

void mSOCFQOzRVa::rfQMNWIaXAQX(int krFewkXSyic, double HqRaXFOVd, int ntvLaRrGEpfpt, int FyzLcQytWxYk)
{
    bool aAIGRSVd = false;
    string FMqywhaRZPkm = string("yDrUcMSKlWpJrqSleIYvOAFjSmuMDZnUvgQhEYqkoRwZGJysopQwLjwdsMmVpLoastdUPfNGOSCNGNBLBNwhZdeZpOqBfBAzigvAnhOYFQEopJREkPbyenxtPZIfSlHMfSXmrznOquVGmgfnMDHYxojxvIbuLbCjkfEPORjCyVjjqKZNsbZYAdyvQJpzHPWmuCGaPgMQQTeYgqrGhHihCSViKGuNJfEKOuyeUVHpuqAnwnSKDpzyJBoVacL");
    double JZtYZDnIauPd = 446140.3075555968;
    int WBOIRsyaOnG = 205425451;
    int RKjULSZs = 1813568302;
    int YyWLLrLXjygDIAGj = -474447186;
    int GzGeYSfJ = 1984600776;
    double gxveki = -522584.32682363695;
    string YKkCba = string("qHHoalHdJyxqBTzaXWWLDhrINiRPTqyqvZzXdjyQRNOepBpBJeLuPCmxMPcruXxWkPMxQGnGczNhp");
    string UVlmJBvnTsfKhRQF = string("KMmyGuTOtTESDndVmlZFJwToXVScsmbxmaSWSEMqpbGvxaQLZuRNWZktKNTdYG");
}

mSOCFQOzRVa::mSOCFQOzRVa()
{
    this->dEgOqkwC(586545.6021801435, false, -34893.02616537928);
    this->snWxBeWO();
    this->MejSyQL(411072310, -609385.5326318546, 130934.1406103019);
    this->sTLrkiRphG(-137805.25995197735, -480908.73020210065);
    this->AUcEZAGNzUYLaU();
    this->MynXyoP(-45004.84711903463, string("NsUwcKHuNaYpVVWEPtXAdVlIKFWgJuEvzSicbamaZSTXcRrMsLwiiGGRnRzQvoRoQAxQykYbzkeQWElWbLidxQbdsrVJcWprUhkzNNuSBvddJIxQdLalgula"));
    this->kZNrxXZp(1107346108, 119527.57346122977, string("PwlzKRFsQZModFlbODcuSTapORTXUeVSNLLRVaEviBDqwbrWpWZbtTdHzWwWHeYPEkUgZXKmPuraEtNDfVnQHTuuAngAgezDwqbSsPDKECtCHtAupoXFbbfbNjPaGYmHLzKYlKvshBtIgecwXBxBIKWAqOFhnZeBAmAtFtKEbcpvOFrClBIiJhbcuBJPkMjoxUGrtooGCSAPjIovgKXiSDCgNEVrReQsHxYPIhlmfhMJsaFqV"), true, true);
    this->NAHQzMBD();
    this->XWACteby(-1967619425, -2131771092, true, -567903664, 1842506918);
    this->NZxMBbwYhrzRb(-1265781384);
    this->eYsxzWcWyAHj(-1009476.9104303027, string("AQXqTqhGVrLXiPRmVbjoOWHriqbuMEdPgZMLNCARbjItdlhskhENGOOVOCalqPZMPsfFnWtFXnibTYenrZECtxCoNRkEaRQcXRVwxFHgelrDMgMPyighzuqztZAjsswfhhrOqqAzPtgTpSnMnXpHKnAGsaPyKhIcwuqoLaNZvTSNEXXQkdeY"), -1773076994);
    this->ZxunkiNO(false, string("tyVwkouWKLwhCwAipcAGDlmRGPwRXoJYbsBfnXKhAUsGGMiZgvoGgLSxiHgYYJqXhgSCgbtFWRyauAHGpmvHFVzCCMjiKFhaFuiqymlgSrgyutohkpqHlFjeHOxsaccLmUBY"));
    this->aKAwpTwJSsC(true, -396090.3264237275, true, 1005792.8063441272);
    this->XXyxD(-283934097, -159930.9574522896, string("HEuuuajKUklvXzpZNsSvvwLwhKujcWDlyrBEnkNlwgihFMFTSbYBQYknKsCeQFUbTSiWtJjeBaOipGmEpuapFoAqwsoDrRzDPFniPwcoqNlXwcEcLVHUBTbQhVazlTpimFdJTUFJrfYJAwVQooBjhHIWYVQEcuFOZhQwHEmuvLURAwwlyrUzCYvSfCGaNKjaRiguTDfyuYvfdWOrhOMaTVkhDjxfbUpQEyfbjzVWCIBCRPYdm"));
    this->QGrnsy(true, -658258.0046066066);
    this->iVfbDUS(-1009151.4673481822, 812355786);
    this->UAhuCDwrsUeQtSVm();
    this->rfQMNWIaXAQX(-1066842454, 64488.048496657306, -818731865, -7072880);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class moCuoASL
{
public:
    double PtLQDuhgeW;
    bool nxQpHQRdsNytz;
    bool NKuKSVceDBWIjUa;
    string hFhLqAIusvLfj;
    int rFpoY;

    moCuoASL();
    double ajFwPBkG(int zoohiz, string GdzxASbitCJAc);
    int elhcbLXQsLysLUsg(double PBSupOcHNNKldSNz, string YfwQySZCU, double zgTmUexzYvbl, string qBGPTId, int DnraYrP);
    int tksWJVpkcq();
    int RswDbuSxJhnsYGEJ(int nKEed, bool cCFUmUbxD);
    void cpYwdkSvTbRAm(int nMfjpkhwd, int geqdOFcgcMmr, double WLDvj, bool ATtvrBpgbynpELsx, bool IlhvTuJPOHkizq);
    int hqFSlxtdSUa(bool IblnMrhPNxBsL, int NiLyeYcgbgabQc, int zLUCeqTjqxJXB, string scCXoZZttOYBcb);
    int jtdXRxmFSqhrxP();
    bool nXmNJxeOMQQ(string pHilr, bool VHHgOGuMZOYaUjE, int jwIYWrBtfs, string KVXaW, int cwGoMiOXQU);
protected:
    double PFwqQpOQH;

    int MfUNoVZHXCFYf(int DMsyoUnVMh, double lMdBEaDDJoTF, int cAiyjpxIIGvhd, double ScAAfkbVsxKYZ, int rezvuV);
    int DFLakTvl(string sETjqhnX, bool KobMHWPXCngZxdj, double wlnjbMaWmDnzhbn, int qDLgeVi);
    double mVEZakfj(bool FGPPXPolVErcfrU, bool tHxKMcCyiXyilt, int NTXghKAuyqH, double VEgjaETUrHslJy, int BDzzYgqG);
private:
    bool wiEaFSP;
    int TQkltGgkFSMlEQRG;

    int VnCQQBiLkUCqRrbu(double HkKxBzikfaFW, string THAfvCcxAeDexsPK, double OKmzMIAkf);
};

double moCuoASL::ajFwPBkG(int zoohiz, string GdzxASbitCJAc)
{
    bool DKguaWwXrOGtpbTO = true;
    double GKkyrBP = 664879.1234542187;
    bool IliSXDnOC = false;

    for (int ZNFCoevxaXTz = 497977658; ZNFCoevxaXTz > 0; ZNFCoevxaXTz--) {
        continue;
    }

    if (IliSXDnOC == false) {
        for (int QZgAQNIwy = 1672695223; QZgAQNIwy > 0; QZgAQNIwy--) {
            continue;
        }
    }

    for (int DoQAliyAOtcOBl = 383002291; DoQAliyAOtcOBl > 0; DoQAliyAOtcOBl--) {
        IliSXDnOC = DKguaWwXrOGtpbTO;
        GdzxASbitCJAc = GdzxASbitCJAc;
    }

    for (int YpkxTU = 1509943260; YpkxTU > 0; YpkxTU--) {
        GdzxASbitCJAc += GdzxASbitCJAc;
    }

    return GKkyrBP;
}

int moCuoASL::elhcbLXQsLysLUsg(double PBSupOcHNNKldSNz, string YfwQySZCU, double zgTmUexzYvbl, string qBGPTId, int DnraYrP)
{
    double IAkSBVYDUJjqHP = 368523.45689564163;
    double jpTjW = -285602.00372723205;
    int bnCRzazFpBCK = -320272785;
    string zhfVrVuNP = string("AVVIutyrOtRpSlfMUFEgHRvhwHDTEmTdJcWvUQtnhRirrBUyOBYCarlwCMGuxdOEOcpjhchzgUPusUkMacVvMwFvHrCdidrIfbFiTWpHIvyyOGDuNaUGiEYPWmAQJkhMruBqqbzzuGNYojiXIhemrtNQIhWhKPLzZWoUdLQUBPRRZdeBAtkZzXcMhMoRPzCjyaeItIHuZpkJVGKIDDBcTAOPgHhkBMNAEatPsR");

    for (int rhfYGHU = 2008187255; rhfYGHU > 0; rhfYGHU--) {
        YfwQySZCU = qBGPTId;
    }

    if (qBGPTId != string("GTnTJdMeEKYWRHVSxsjrmIdEAiLNrcEIMIbZGeweXntHNdCIQUNZTRuFRrHtzOjqnGkuTTeliqFZnqWIjenFrnPbQiOS")) {
        for (int XMUQFSEejrXBupNy = 1935579484; XMUQFSEejrXBupNy > 0; XMUQFSEejrXBupNy--) {
            PBSupOcHNNKldSNz /= IAkSBVYDUJjqHP;
            DnraYrP /= bnCRzazFpBCK;
            zgTmUexzYvbl = zgTmUexzYvbl;
            jpTjW /= IAkSBVYDUJjqHP;
        }
    }

    for (int tpWrTpVil = 1352530006; tpWrTpVil > 0; tpWrTpVil--) {
        continue;
    }

    if (zhfVrVuNP < string("AVVIutyrOtRpSlfMUFEgHRvhwHDTEmTdJcWvUQtnhRirrBUyOBYCarlwCMGuxdOEOcpjhchzgUPusUkMacVvMwFvHrCdidrIfbFiTWpHIvyyOGDuNaUGiEYPWmAQJkhMruBqqbzzuGNYojiXIhemrtNQIhWhKPLzZWoUdLQUBPRRZdeBAtkZzXcMhMoRPzCjyaeItIHuZpkJVGKIDDBcTAOPgHhkBMNAEatPsR")) {
        for (int IcBATdqZH = 1217559167; IcBATdqZH > 0; IcBATdqZH--) {
            jpTjW = jpTjW;
            IAkSBVYDUJjqHP /= jpTjW;
            IAkSBVYDUJjqHP -= zgTmUexzYvbl;
        }
    }

    return bnCRzazFpBCK;
}

int moCuoASL::tksWJVpkcq()
{
    double avQtbj = 20253.880317694577;
    double mvtYOSHgJMg = 860900.455816617;
    int gSGERawZ = 1491413195;
    double EqwpMZruGDoGpbc = 748739.8611097883;
    string rZhnna = string("ulLzdrtKTZxMIDTOvyZrILRZBiqCCwPQRpUlgqUGBKqikevOxUeDEHhUXIpLdRMlVrCKUGeUGZJsPOKSTLniEAptYfEpGTpaUgAbmFEUcNIjfozjLcfSky");

    for (int naYweyCLbOnDh = 1883945547; naYweyCLbOnDh > 0; naYweyCLbOnDh--) {
        avQtbj *= mvtYOSHgJMg;
        EqwpMZruGDoGpbc *= avQtbj;
        mvtYOSHgJMg /= avQtbj;
    }

    for (int qsaFDQyebz = 2116825337; qsaFDQyebz > 0; qsaFDQyebz--) {
        EqwpMZruGDoGpbc -= mvtYOSHgJMg;
        EqwpMZruGDoGpbc /= EqwpMZruGDoGpbc;
        rZhnna += rZhnna;
    }

    for (int yWqTJPI = 855232289; yWqTJPI > 0; yWqTJPI--) {
        rZhnna = rZhnna;
    }

    for (int qmkkIm = 1993566966; qmkkIm > 0; qmkkIm--) {
        gSGERawZ -= gSGERawZ;
        rZhnna += rZhnna;
    }

    for (int lZXSjJEWVGlihpzg = 101830665; lZXSjJEWVGlihpzg > 0; lZXSjJEWVGlihpzg--) {
        continue;
    }

    return gSGERawZ;
}

int moCuoASL::RswDbuSxJhnsYGEJ(int nKEed, bool cCFUmUbxD)
{
    int cEtnypQNAHUhkovW = 1192261827;

    if (cEtnypQNAHUhkovW <= 1859839704) {
        for (int sNnwQbZhgMd = 649049826; sNnwQbZhgMd > 0; sNnwQbZhgMd--) {
            cEtnypQNAHUhkovW = cEtnypQNAHUhkovW;
            cEtnypQNAHUhkovW = cEtnypQNAHUhkovW;
            cCFUmUbxD = ! cCFUmUbxD;
            nKEed /= cEtnypQNAHUhkovW;
            cEtnypQNAHUhkovW += nKEed;
        }
    }

    if (cCFUmUbxD == true) {
        for (int iWfKQaQY = 2003806901; iWfKQaQY > 0; iWfKQaQY--) {
            nKEed = nKEed;
            cEtnypQNAHUhkovW -= nKEed;
            cEtnypQNAHUhkovW /= cEtnypQNAHUhkovW;
            cCFUmUbxD = cCFUmUbxD;
            nKEed += cEtnypQNAHUhkovW;
            cEtnypQNAHUhkovW = nKEed;
        }
    }

    return cEtnypQNAHUhkovW;
}

void moCuoASL::cpYwdkSvTbRAm(int nMfjpkhwd, int geqdOFcgcMmr, double WLDvj, bool ATtvrBpgbynpELsx, bool IlhvTuJPOHkizq)
{
    string stqyHexRf = string("PUlAFjPzClOpzg");
    double yHOrjH = -203643.57339587217;
    double hWnuRvHSXmZyLJoo = -656086.2470538856;
    double EtjjXiTOWNPccHbl = -680070.6123849791;
    string eONDG = string("gZhZlwQnboxToKUxRAcTnJVIZWsUMIvQ");
    bool PDLSdtsRkGwqkBxD = false;
    int MfICvjzXNBH = -357419612;

    if (PDLSdtsRkGwqkBxD != false) {
        for (int FqGzKRZ = 1725316329; FqGzKRZ > 0; FqGzKRZ--) {
            continue;
        }
    }

    if (EtjjXiTOWNPccHbl == 264129.80875334196) {
        for (int ADGzgWpYQltQtPN = 49270363; ADGzgWpYQltQtPN > 0; ADGzgWpYQltQtPN--) {
            hWnuRvHSXmZyLJoo = EtjjXiTOWNPccHbl;
        }
    }

    for (int kKdeFfZr = 711102743; kKdeFfZr > 0; kKdeFfZr--) {
        continue;
    }

    if (eONDG < string("gZhZlwQnboxToKUxRAcTnJVIZWsUMIvQ")) {
        for (int nAImMclcTFnaLIuZ = 405043026; nAImMclcTFnaLIuZ > 0; nAImMclcTFnaLIuZ--) {
            MfICvjzXNBH -= MfICvjzXNBH;
            EtjjXiTOWNPccHbl *= hWnuRvHSXmZyLJoo;
            IlhvTuJPOHkizq = IlhvTuJPOHkizq;
        }
    }

    for (int ntrSSLiEWqbfFCy = 1204965682; ntrSSLiEWqbfFCy > 0; ntrSSLiEWqbfFCy--) {
        continue;
    }
}

int moCuoASL::hqFSlxtdSUa(bool IblnMrhPNxBsL, int NiLyeYcgbgabQc, int zLUCeqTjqxJXB, string scCXoZZttOYBcb)
{
    int McDok = 642587260;
    int INCWeSQ = -1788969626;
    int QOijqn = 611271193;
    string AqoKrRaxX = string("fNjddetGQDHviIrRrOCqwLEAJcoYZmslxzzryfngUkDoEueNmqFhjMyRWPeytglfVrgoVLEKmKNOlrCyREyGtVJmfEcFXJuvedltDvNCjeUCFMWcSfefuphPIYCzDWAkhtIvlcpbAyzlRDfUyGdkeJEETgLiNHxPCAOmEGWLUphUsDTMGmGnxdzYFhvXtoBtbcO");
    string jpHVjyRCLj = string("kOtmInvHEhvbxcIfxgIDGyQSLOQVOPcApkXOjCAzGxLFiloKILPQczvMjWXsWLETxJFvcmBQyQUeFZOKfXaUhTRmObuagvPVHPVEgvnRtaBuLCtPcPuJhDyl");
    bool FWvOcDtywuxxbM = false;
    bool tkhGPNnacBMHFw = false;

    if (scCXoZZttOYBcb == string("fNjddetGQDHviIrRrOCqwLEAJcoYZmslxzzryfngUkDoEueNmqFhjMyRWPeytglfVrgoVLEKmKNOlrCyREyGtVJmfEcFXJuvedltDvNCjeUCFMWcSfefuphPIYCzDWAkhtIvlcpbAyzlRDfUyGdkeJEETgLiNHxPCAOmEGWLUphUsDTMGmGnxdzYFhvXtoBtbcO")) {
        for (int hzjxYyNcF = 645083223; hzjxYyNcF > 0; hzjxYyNcF--) {
            scCXoZZttOYBcb += jpHVjyRCLj;
            QOijqn *= INCWeSQ;
        }
    }

    return QOijqn;
}

int moCuoASL::jtdXRxmFSqhrxP()
{
    int ayMkoVoGDIPdAnOp = 1485698383;

    if (ayMkoVoGDIPdAnOp <= 1485698383) {
        for (int sqaZtAjGqpHj = 1525537797; sqaZtAjGqpHj > 0; sqaZtAjGqpHj--) {
            ayMkoVoGDIPdAnOp -= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp += ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp *= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp *= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp -= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp += ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp = ayMkoVoGDIPdAnOp;
        }
    }

    if (ayMkoVoGDIPdAnOp == 1485698383) {
        for (int nSyELSrfIw = 1181784901; nSyELSrfIw > 0; nSyELSrfIw--) {
            ayMkoVoGDIPdAnOp -= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp /= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp *= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp *= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp = ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp = ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp /= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp *= ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp += ayMkoVoGDIPdAnOp;
            ayMkoVoGDIPdAnOp /= ayMkoVoGDIPdAnOp;
        }
    }

    return ayMkoVoGDIPdAnOp;
}

bool moCuoASL::nXmNJxeOMQQ(string pHilr, bool VHHgOGuMZOYaUjE, int jwIYWrBtfs, string KVXaW, int cwGoMiOXQU)
{
    double oLIGjwjCsy = 728940.4332691364;
    int CxRnvksQHRq = -769548193;
    string LPrWQOmI = string("rIzyljAeIiRlQjlkSTTqefcSxRCAaGaZSRYwfBBmseeDXGznljVRimoOOoYizCJBmOpCubLcADnSGPzibeCQirvYWpLyjzhhemmROPSHWQdvFPmQFlVDfGzljjABHcrAEjBborobnVmUeZspqIsjihbKFmjHIJsBlReSxzdfsokFNLKMGItwvqNyJBwOMMobwyakMXPw");
    double iQiESCQGSW = -389803.54017243587;
    bool ARhDAONQNmSUkS = true;
    bool zsFvy = true;
    bool TFPEX = false;
    bool PQHdRXQdD = true;

    for (int QVfRKCFgxInRj = 1242618461; QVfRKCFgxInRj > 0; QVfRKCFgxInRj--) {
        PQHdRXQdD = PQHdRXQdD;
        KVXaW += pHilr;
        jwIYWrBtfs += CxRnvksQHRq;
    }

    for (int qjzdCtKDIFAdDU = 475305693; qjzdCtKDIFAdDU > 0; qjzdCtKDIFAdDU--) {
        continue;
    }

    return PQHdRXQdD;
}

int moCuoASL::MfUNoVZHXCFYf(int DMsyoUnVMh, double lMdBEaDDJoTF, int cAiyjpxIIGvhd, double ScAAfkbVsxKYZ, int rezvuV)
{
    string ytBAt = string("vXhcLFfIbCAefBMWjLilddTVJgiyAgUuHPSwtxQefuxJuiHEjeetVMGfmPHdTGvutkbyxzlOnQxCJsoTttIyRekBuKFtxfQceBnXWZSwAOQUUEjSHzLjCyUNGlFtyLTThDwIXdoQIqFmlsYzqyDuOlxJHMKTmB");
    bool FWtmnhvqgEUtSDFO = false;

    if (DMsyoUnVMh != -959220631) {
        for (int mJsSCMf = 1799913427; mJsSCMf > 0; mJsSCMf--) {
            rezvuV /= DMsyoUnVMh;
            cAiyjpxIIGvhd /= rezvuV;
        }
    }

    for (int oIPskcDm = 1684259423; oIPskcDm > 0; oIPskcDm--) {
        DMsyoUnVMh = cAiyjpxIIGvhd;
        DMsyoUnVMh /= rezvuV;
        cAiyjpxIIGvhd -= rezvuV;
    }

    for (int QcnKDPVIRoN = 1207140695; QcnKDPVIRoN > 0; QcnKDPVIRoN--) {
        rezvuV += DMsyoUnVMh;
    }

    return rezvuV;
}

int moCuoASL::DFLakTvl(string sETjqhnX, bool KobMHWPXCngZxdj, double wlnjbMaWmDnzhbn, int qDLgeVi)
{
    bool AwvONMI = true;
    double OphnBvlCtHzoGz = -531238.5821331574;
    string sheDjKMPQCzW = string("JVAtfVsGJnBdLnnVTurOqgGjDGJNptbSCabXBLtnUuKxnjoULIfghvjYfMfNqcFtsleaomXoZyXNItmxMBepf");
    double vwTufVUCOU = -740051.7919589302;
    string uMKCiLilXkF = string("ebkxsqorHFuRJApBajsPiVpafNnyeSJYvWksZFzOfvRUwEfIqBuKMlNuSGCvnPpCOwuOJbFElUtxxAQnBbxUCCoxNoJfRhdeoZbfiDPGrcbEwyntCtchfVlMlmHtqiPdkjPPmieCEGNoThQZlDPmaQtUPlHXjFXlIlPvhwhkkRguKSqazOPSDfGDdoAxIyQACMKIWdjUdibXrVfLOKzYzMMJIWransNITUuEEXrcLeXKOovlAJoHyhIHyA");
    int hMhCs = -260762097;
    bool exqAtknqRvLf = true;
    bool BCelk = false;
    bool DnybcyYYf = true;

    for (int sjaPMC = 501375087; sjaPMC > 0; sjaPMC--) {
        continue;
    }

    if (BCelk == true) {
        for (int XkZwgbOqvqm = 935007414; XkZwgbOqvqm > 0; XkZwgbOqvqm--) {
            continue;
        }
    }

    for (int JqDSm = 203904155; JqDSm > 0; JqDSm--) {
        sETjqhnX = sETjqhnX;
    }

    if (vwTufVUCOU <= -531238.5821331574) {
        for (int BixNRdwsmmOu = 1941319862; BixNRdwsmmOu > 0; BixNRdwsmmOu--) {
            hMhCs -= qDLgeVi;
        }
    }

    return hMhCs;
}

double moCuoASL::mVEZakfj(bool FGPPXPolVErcfrU, bool tHxKMcCyiXyilt, int NTXghKAuyqH, double VEgjaETUrHslJy, int BDzzYgqG)
{
    int UrKPWl = -539276664;
    double DlVXOAkx = -459028.1318502544;
    double hIndksMXYEVwxlQ = 37634.724067086834;
    string KBHpctB = string("DJYPeIBUqIKyZptHMYvestSMSVhWpAegOysmuVzPGOYbxkoOAiNhMUIJwOdLuXNTFMfWPYNKShjDMsZmgSLrAHEfmuoEmWXoSArfSizVJLWocWtaccRzlQUzBojlKrdRkUdXppxvQN");
    int mRRyhueoRfkuF = 1078649837;
    string BMtJvrqTuwRhNtZ = string("yTsMIlScubsRlBTrCbVbjTJDkUsBNpztQXnYppcjVNZvMgpdRCKyvKpqWZOrBOvTMrefkmMRAJyipuieArkaHKRvOTamnPYlLbTTUXgnKuGIGVBkBFJFnnJAjZGIYXQrvdjlSEfmgYf");

    for (int yPzHyx = 1031474523; yPzHyx > 0; yPzHyx--) {
        NTXghKAuyqH *= BDzzYgqG;
        UrKPWl = NTXghKAuyqH;
        KBHpctB = BMtJvrqTuwRhNtZ;
    }

    return hIndksMXYEVwxlQ;
}

int moCuoASL::VnCQQBiLkUCqRrbu(double HkKxBzikfaFW, string THAfvCcxAeDexsPK, double OKmzMIAkf)
{
    int JkVtdakmtawhqOee = -422009534;
    double iazQfDEWTWz = 497089.47263678635;
    int KlNWdZpZYvQthrY = 767080747;
    double JVhWztA = 1022978.5427327683;
    double mFCLTCnXOlziTE = -421753.829737503;

    for (int JLjTaHnbFivUBic = 696791072; JLjTaHnbFivUBic > 0; JLjTaHnbFivUBic--) {
        continue;
    }

    return KlNWdZpZYvQthrY;
}

moCuoASL::moCuoASL()
{
    this->ajFwPBkG(-1516997383, string("BzilyFScCnMUevAeKEJCACFRSejmlcxykJzNSYMfnLCTDBjTGDLtOXctXResWJfrUQJNeIfyYjHBnqivBjgyoKWjILANogjIHrmtCpuvmDXvSuKXPaIgJakugONobHokbswtdrAmIxTdKYGLShryDIrcbatmHLYeZppTZsMLrCxeGnRHAEnjRfoATHTdfkO"));
    this->elhcbLXQsLysLUsg(740228.991891305, string("GTnTJdMeEKYWRHVSxsjrmIdEAiLNrcEIMIbZGeweXntHNdCIQUNZTRuFRrHtzOjqnGkuTTeliqFZnqWIjenFrnPbQiOS"), 135311.9587301227, string("kbiluNHMrJsehHFuBbASmMcsqTheVjriIBIRficABIEixPNaZihgFTFbN"), 443683958);
    this->tksWJVpkcq();
    this->RswDbuSxJhnsYGEJ(1859839704, true);
    this->cpYwdkSvTbRAm(1625131103, -2086780005, 264129.80875334196, false, false);
    this->hqFSlxtdSUa(true, 486026057, 1037011681, string("RWbAluafqIEOCJITpVddRjOotfHnYAPaFaLaTOptCXfWKjVksQKrhUrtZnrQIszOaXEGZBsXJMIcPGunDnTiYizerAAbuMeAURUkFhASVeWizHwqMZlkBhmVDtQrkFLSdDY"));
    this->jtdXRxmFSqhrxP();
    this->nXmNJxeOMQQ(string("RYDCCXryYlQPbKcChVwHeZFRfhtdxKSsXGVxEDFXZDmPeQKzXmYuIGVNREoDAdSPSCMrnoinENPrXEFnTeOXsxFdOAddGBaCuwheMKyoDNLf"), true, 1426890963, string("eVmsPLVAkGxTPBzZhNzTFYfzyTXfsDoMpYsrDhOGWERrTzIvDCuYrWvlTRlfKrStcWUmNIkxVOisQJZOZlQHifolDSrFdqnySMziBagdRKltuvcovfeaVKYfrhHUcsDdSSAmbWjQRMgwAMHZMgRnmqynKWzWLUqhnViRnITinbQYJHVjRyXDGCdVgPDbYmEtMCZLhEwCxZ"), 1218681593);
    this->MfUNoVZHXCFYf(1683072981, 135553.32110495568, 2109506799, -891767.0305871359, -959220631);
    this->DFLakTvl(string("JsgfglGUegOETibdVWcdwjOLwmuZYZNMnpfsrLjLhXhiypmuaDZlXfJKpYjVgSFZDNeBUsaveyzztpkwdCjKlotWggvkGUEOttsvHOzfLJXTljNHZtGXLtnjzwMXUYiufPldqSGXmyCwBSCBXKJUOzbQYMljTNybsmWzJPsvRWCYKrrhLNxmLceFtPxGThwKzAYzsN"), false, 127475.72257171234, 891004016);
    this->mVEZakfj(true, false, 763779193, 867033.2862390168, -1846309221);
    this->VnCQQBiLkUCqRrbu(282884.8656641639, string("izbOEpiLqacIdFPPDGZiaIWOQmcXRjrShydDgKMIMxzIdIquwiUdimGULDifkRznScDYhEVXXaJaNfzhMwGVKjybbovdfCwapoHMyRNbztvWKiXTEZBrcqIFgArTAOWKScSecnWysfEutVWAGvPQaJCHjPmknJwni"), 917348.5151990185);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kHIgVKwCABnzXjqf
{
public:
    bool GuAsTArrCofOyf;
    double ukkjZKiDKQiZqsf;
    int QLRLogUDlSqSjB;

    kHIgVKwCABnzXjqf();
    double cFsrhpXCUVG(bool zXShT, double msebsjJovV, int IKUrYAxuc, int uQNQgkdIz);
    void rTrKQlcYBbIw(int eoFNqpJGGsBbCUk, int MuxoybCnjFjXJ, double YTayhs);
    bool vENyd(bool hhUqBFxhZfEtDfHn, bool MWXshEFIOhSSnoa, bool BenHMbTxeGatrifR, int oWYqqAaIsVYJ, int MpxTKxsepLHVRUx);
    double ErIfwvQDx(string whUrylYU, bool DPBZrWUIREbdd, int surNkMPQEhUmhhaf, double FMSrVboiEPROwYUf);
    bool fOpNv(double svIInG);
    void GpbHp(double YMCPGxPtL, double UkXxWoDkkEzLAxwQ);
    double atJNi();
    string tZIdSa(bool fXxpgSxhj);
protected:
    string PZwoQaR;
    string MUcediPKJyP;

    void gNzzkqmTg(string ppGFEF, int ekZvZNPglh, double dgYlMzRXWCMq, bool MChFEG);
    string OYrqCIWzKr(bool ZieesaFz, double gTiTpLCXtBSYWec, int CgmSe, string FAVkPhJuv, bool ltjdzRJlr);
    void osMxgOnXdJJlicHW(string JSJMUIbEOIbQCq, int PzKVguJIJfvzERJe);
    void MlaqZ();
private:
    int GbMPIJVzKMWP;
    string hQhAWe;

    string lJbinoVAOO();
    double qVZspi(bool upzZkCwfgGdSQv, double pINrsNjGNlE, double GuvfvU, int JRlpukyXqjFHlhHm);
    bool CJCwIDAIoRaJ(double OjschQMvtzaJa, int ndQQjRl, string LmWpNGRvsXcwk);
    int vIbQis(bool LWcGrZBUqBVMwh, int LZcovgks, int uiczmfmrAHacYgbQ, bool zxwxVVuaDYps);
};

double kHIgVKwCABnzXjqf::cFsrhpXCUVG(bool zXShT, double msebsjJovV, int IKUrYAxuc, int uQNQgkdIz)
{
    bool KehDKtInopNZ = false;

    for (int eNLGT = 144253783; eNLGT > 0; eNLGT--) {
        IKUrYAxuc -= IKUrYAxuc;
    }

    return msebsjJovV;
}

void kHIgVKwCABnzXjqf::rTrKQlcYBbIw(int eoFNqpJGGsBbCUk, int MuxoybCnjFjXJ, double YTayhs)
{
    bool ldkCgeCZipmHmcaa = false;
    int mnqbhhL = 430450555;
    string mQPItVDMJIxm = string("wGrXWPZqflrZvAOHnrfcVkVhOxpURqueeMmMQmbWRzSuWwNPMiHsWLKIKiCcvOvqsRYJiobwRkzEpNxPkmULveOWFGHeBIHFmslAgcjVNUqoHWuNUsRXaEPgeW");
    bool sTZJVjL = true;
    bool dZHMZVQz = false;

    for (int tCPSxIiEYkzQ = 1997390633; tCPSxIiEYkzQ > 0; tCPSxIiEYkzQ--) {
        dZHMZVQz = ! dZHMZVQz;
    }

    for (int mpBnIFhjhOwkhlR = 565770033; mpBnIFhjhOwkhlR > 0; mpBnIFhjhOwkhlR--) {
        continue;
    }
}

bool kHIgVKwCABnzXjqf::vENyd(bool hhUqBFxhZfEtDfHn, bool MWXshEFIOhSSnoa, bool BenHMbTxeGatrifR, int oWYqqAaIsVYJ, int MpxTKxsepLHVRUx)
{
    int saVqLIaRsLR = 1652956478;
    bool NWqTRrmnTi = false;
    int lXcky = -2063880028;
    double uDzgyRT = 157808.652652679;
    bool nHczFPb = false;
    double TeQwjSITv = -610068.8265274797;
    int nIuvp = 194060833;
    bool zWNWd = true;
    int dRjJprmomoHnY = 859523972;
    int JouxgtJsKpHV = -2125853982;

    return zWNWd;
}

double kHIgVKwCABnzXjqf::ErIfwvQDx(string whUrylYU, bool DPBZrWUIREbdd, int surNkMPQEhUmhhaf, double FMSrVboiEPROwYUf)
{
    int SpeQfcLOYHfwr = 113047701;
    bool apYmSbbkihbw = false;
    bool PUhCNnIDPrPRix = true;
    bool LgFRyeyRCuFT = false;
    int cYFDNdXlDxihTJP = 1197735375;
    string FLkIUpdyNPO = string("znjpgCCWYzUGMROQjLSkkJfrIznJWtqcoXmojHvNymqcSzBSVGZYSAeufxJWLincISijfvTqHBnvhEUXtzubpdbNZUAwaFuhmKquWBgGaetWBFoCjKWDXWztnwzEiVZInYyRHjXZbQJpfZo");
    string CMUCvRrwFf = string("bBojfHipGeFGeWfdDqQnBVtYSraaFyAFdqGrMVSWecFCnrtORLesOPemndogRhyvDIPeJTiXOKTwyuJkXbzRZaskozwXmXdMoGmzzVcRHUgekWUKSvqDFmdcMFbsdcBcEzouhyGngZSpnaXHPpLRRsQvLtoZvtipNyotMPXNoWYCjjgXhJQdrQyTQtqCMsDlAmIaOhInUCRVAZQWolZmppRyWqVqpZjHDmMJxjjvfJroa");
    string ffPeoM = string("DeufzBovtPRXWQycOoYoHcIJojxPsKCculTWWrRhRDEbPfRiFECfnIrUMQsMUvDKbUNyOPPjDHLBTNTRKwdRBguhxANVIdMyybSkwcALdyIAgbdDAVNBPQKKCqdFOFZmsqitFVgrgMYtyPnDHHiPsiTiFtiiLUsDeqCcZuTwUdLRArZDyBHPWIBPYwFmIOvSXbvLkxDzAbhyHJVuywZJsJ");
    string odNbaylryI = string("dQxzDJGTJdcggLYbRVGIaOPrRNBperPOHrTyCZgtcTNvyzKZQrOXOXmXZySSoDQmZEzerqARURphGihuZcdzPwtrYHcjvEtjbgSaveIOkVUVsfWeGRFbYxcpoZxFahzVpmSzuJvlnITlsJXqkMBuJPkGRcRXHHsAnAAgcewfPbVZwpsfOKTSRgJiSWIIihINfTroAAwSgTEA");
    bool MwOQfJDHUws = true;

    for (int NaskkTLlR = 1165371553; NaskkTLlR > 0; NaskkTLlR--) {
        whUrylYU += ffPeoM;
        odNbaylryI = FLkIUpdyNPO;
    }

    for (int SsNyxOwm = 1291941852; SsNyxOwm > 0; SsNyxOwm--) {
        PUhCNnIDPrPRix = DPBZrWUIREbdd;
    }

    return FMSrVboiEPROwYUf;
}

bool kHIgVKwCABnzXjqf::fOpNv(double svIInG)
{
    string WDchZyfJs = string("YBfzRwLOGgjBpdXvFoeDypvPdYDmk");
    string wfuhnVAdsY = string("UqjmQZRSGKTGWEqfuMHPtoDduQvMGZKpbXAiCrnBruRBFqJighiXiLFaEJdJZuqIBJBhBXGlgdklulyqFbOiOdSlqDxysQREtvjErFtUYvScNKOODNXCihWCyAKhjpDETPJXpJuyKjoGbkfhfSHlRfjsyZTTSKzJPzXLvgcSkTxaujpjbfWgkHLchRambMSUeXcEMDXI");
    bool xKZAlFkRQDKw = true;

    return xKZAlFkRQDKw;
}

void kHIgVKwCABnzXjqf::GpbHp(double YMCPGxPtL, double UkXxWoDkkEzLAxwQ)
{
    double MFRlyWSEOrcygk = 914754.2331454564;
    bool zeWuCqPDAQnDAVP = true;
    double LXkZrA = -1005960.8253069526;
    int NWzQKnwUkqDpYImV = -907996521;
    int JmybinY = -1363820412;
    bool YolZixGx = false;
    int MzMmXJrclnzhYzs = 256039426;
    double UdaelAKxXiPZQMI = -179259.66938506148;

    for (int saejvccibREJGwf = 1694440210; saejvccibREJGwf > 0; saejvccibREJGwf--) {
        continue;
    }

    for (int mtsuaHMflswbEhCO = 622447744; mtsuaHMflswbEhCO > 0; mtsuaHMflswbEhCO--) {
        continue;
    }
}

double kHIgVKwCABnzXjqf::atJNi()
{
    int abcZpKBjWWys = 1038836325;
    string TksOU = string("reoLLBzgtIVkyfaptGVYiqJLHVFUQfQvItieVpvteTZGDWpVPXnkVeLQNDAEQTVknUWlYTWVSkobwSabIesbVTgehGiHhtJkEXJaAaa");
    double fnqWyiFPtNhsRri = 896515.4429011042;
    double azxiMSvPCcoEj = -48641.65782742298;
    double oeaOiXDqqYaPKfJt = -1012663.2637367918;
    int aqAElX = 1988373435;
    double HYQRLcD = 222570.64422108704;
    string gtciOCw = string("ftrPYICKHelKDVbIuTofuHfqAmNXPIPaElgeHPjICBVPANvdDCsPcOJYujgDBuPdzuuqdv");
    int fqOGkgs = -172330197;
    string aTfxMbfAPbKBAfi = string("cboqIPEmFLuAzzUSMPzBKCCysLMlgrMNJPyqHjqyFgoOvzOFShUyxgVJCuSZPTrGjDySFmSVkOxgADiDLifpilsYnmXWkWlvADNQSXANZiHQMYvixSDkiLTZwqBUn");

    if (aqAElX == 1038836325) {
        for (int DdgCcf = 1853159861; DdgCcf > 0; DdgCcf--) {
            gtciOCw = aTfxMbfAPbKBAfi;
        }
    }

    for (int YRhqduM = 1003274991; YRhqduM > 0; YRhqduM--) {
        azxiMSvPCcoEj *= oeaOiXDqqYaPKfJt;
        fqOGkgs /= fqOGkgs;
        azxiMSvPCcoEj = oeaOiXDqqYaPKfJt;
    }

    return HYQRLcD;
}

string kHIgVKwCABnzXjqf::tZIdSa(bool fXxpgSxhj)
{
    bool URcmRbAUDM = true;
    double xriuiPxm = 531944.0326267906;
    double jBLeujbnliY = 644827.7629524064;
    bool gRZiTj = false;
    string DgnYosrJFbcKi = string("fWtUuDaMuZgfIOlDmcJboKjP");
    int yBPAwFgGnt = 1732501769;
    string IBlzVia = string("dqabgROKhlgiBNwFXpoZHJFAjRAFmBOMvubmBieOBbQtbIluHSUgcxrITeVfTfdlFGUfdKdseimdpATotnHvvOwxSNTpbhUIJIcIXgtGxpupyGEvqZhdMIVZvbnThgIjymVWwFBJLufpCMIQxAcuCQDBdLVeDfJBwFyZZzRHhaCiGbstLYJsvAZTolbO");

    for (int ZRKBdUQ = 1834279075; ZRKBdUQ > 0; ZRKBdUQ--) {
        fXxpgSxhj = gRZiTj;
    }

    for (int OkgNPvPYtu = 1400320989; OkgNPvPYtu > 0; OkgNPvPYtu--) {
        continue;
    }

    return IBlzVia;
}

void kHIgVKwCABnzXjqf::gNzzkqmTg(string ppGFEF, int ekZvZNPglh, double dgYlMzRXWCMq, bool MChFEG)
{
    int cUCWdqcPWgySlk = 1678121740;
    string iFOAWsEMTKDubT = string("HFrcvOdgEPtakacoVJjgNJKlDTRufwFbYVPgqbPrMnrOLfdLygaxVPxNANGQAfvUqvBEjfceQiHCXqXEwQNewLfhdqWRVYJLMebywjBnUTUoSnjMtcpUyEQHSxwofRKuunNVoDbBJLAwteoVNWRsqMYRdgxYCjWXaujAEvONFaOyOmKwUChDaBoFsoKdpqpQGHYlRRYplXibpDWBTwjyVmITZvPApsQtGWlphLtuuOKsFTEyKyO");
    string JkOSwENl = string("hcxyzRolrFibTKjzjkegkhtShwaWMeyDIcTFwu");
    bool kAQnbe = true;

    for (int YLxkNSQg = 939022365; YLxkNSQg > 0; YLxkNSQg--) {
        JkOSwENl += JkOSwENl;
        kAQnbe = ! MChFEG;
        iFOAWsEMTKDubT = ppGFEF;
    }

    if (cUCWdqcPWgySlk >= 1678121740) {
        for (int XKCfGBHiZ = 806375546; XKCfGBHiZ > 0; XKCfGBHiZ--) {
            dgYlMzRXWCMq = dgYlMzRXWCMq;
        }
    }

    for (int djBkxk = 1993532309; djBkxk > 0; djBkxk--) {
        MChFEG = ! MChFEG;
        MChFEG = kAQnbe;
    }

    for (int pkxLeskVpFugxM = 1763007845; pkxLeskVpFugxM > 0; pkxLeskVpFugxM--) {
        iFOAWsEMTKDubT = iFOAWsEMTKDubT;
        JkOSwENl = JkOSwENl;
        iFOAWsEMTKDubT += ppGFEF;
    }
}

string kHIgVKwCABnzXjqf::OYrqCIWzKr(bool ZieesaFz, double gTiTpLCXtBSYWec, int CgmSe, string FAVkPhJuv, bool ltjdzRJlr)
{
    string saSxY = string("veRYbFNUEIOvJcPgRwDaAlmzdUSlhIZEKkpYaMvTTVudxipbxaAsUnhVcJYobnzrbxSSrAyLL");
    bool lLtwD = false;
    double mvwkjzZ = 54629.02106258783;
    string oZQJilOgJX = string("BaKJCtKNXWcKZJZOQjRIcxTGfjcsXqnDnreuOXcgNvnNcUbfeMBDXgyfXJbramxkmCnWLjDRxnsbXthHbYcCgrlgtwRtCvlhaJLkFzmOwsSBFubeSvKTJkqtpfzUbDCTDnzGimDKMMFKTGvZgWJtBAOfsUnvOHXeVGYdNvEwgeiEMGXR");
    string XLGPYRM = string("VfdoAYkoSCJxdWTkMrxsuIOulXJenfNRlGxzRiVIeZFkuWJBXQZcsmxPmRqPgwrbUmFsMjFkyHvgltruooJiYDTCKsyTnHdKDFEogIcKJDiNteCtYnFZuObawaZRAthwNVMyHnyouXsJPXqaBOAeFmiKvpeXjBXHJCYINqdYYuGAosPwMNaTaCurhaPKGXiCqklgYboWxtGnKYwqhizPMHguYXNrTPQGNsSNLwoNyakQGuOFlANokWQuyQhuiRo");
    bool OvnXlJ = true;
    int JnDNtXvrUmHJj = 333577404;

    if (mvwkjzZ >= 757024.6471678088) {
        for (int IHBSSNIgLyB = 1837719090; IHBSSNIgLyB > 0; IHBSSNIgLyB--) {
            continue;
        }
    }

    for (int hYXyZFZYyzdSIG = 237863105; hYXyZFZYyzdSIG > 0; hYXyZFZYyzdSIG--) {
        lLtwD = ZieesaFz;
        CgmSe -= JnDNtXvrUmHJj;
    }

    return XLGPYRM;
}

void kHIgVKwCABnzXjqf::osMxgOnXdJJlicHW(string JSJMUIbEOIbQCq, int PzKVguJIJfvzERJe)
{
    int JHzEnkXydYhNPn = -857893185;
    string dHVebjZcNNOoPXAu = string("apOrbZAPCmoMLmbvzQmDGySxHCZPcBzBCyNfrJFuDsfYuPOKsOxDVVJQSJxOlrWQLjmDJsNIqxAxCBTeCQWBkvyddYRpAKNthtWsfJhxiMqjFwsuYMaIoPegVJhqgdAAhpONumFMtbAbfncsuCbQanEyAJXUSkRIlV");

    if (PzKVguJIJfvzERJe <= -857893185) {
        for (int gbfvotxHKMx = 1896891687; gbfvotxHKMx > 0; gbfvotxHKMx--) {
            PzKVguJIJfvzERJe /= PzKVguJIJfvzERJe;
            PzKVguJIJfvzERJe += JHzEnkXydYhNPn;
        }
    }

    for (int pKiRVoHkXJeIu = 1117878299; pKiRVoHkXJeIu > 0; pKiRVoHkXJeIu--) {
        dHVebjZcNNOoPXAu += JSJMUIbEOIbQCq;
        PzKVguJIJfvzERJe -= JHzEnkXydYhNPn;
        PzKVguJIJfvzERJe *= PzKVguJIJfvzERJe;
    }

    if (JHzEnkXydYhNPn >= 857976882) {
        for (int xhfYJAuDqDjmnf = 2013739622; xhfYJAuDqDjmnf > 0; xhfYJAuDqDjmnf--) {
            JHzEnkXydYhNPn *= PzKVguJIJfvzERJe;
        }
    }
}

void kHIgVKwCABnzXjqf::MlaqZ()
{
    int EihzezgbZcGqzKv = -17646641;
    int bZkqXBduzfCyWEgI = 2025629295;
    int TFvYIHDFnzqDpeH = 1819990273;
    string qiwlQodQjBXWo = string("GjPqxaqIkLozetmYLAiBjbCek");
    int xQTiuvxCfkrtGuy = -500220355;
}

string kHIgVKwCABnzXjqf::lJbinoVAOO()
{
    string Mtphtu = string("PoJqLFtyIXwgyzoFHtuTrvvCpMGgvRFTFSiwxOrTtNBhqtYoRrjktEnQvjfmPJThurvZpsttoWcMztdBzEyIUUIAu");

    if (Mtphtu > string("PoJqLFtyIXwgyzoFHtuTrvvCpMGgvRFTFSiwxOrTtNBhqtYoRrjktEnQvjfmPJThurvZpsttoWcMztdBzEyIUUIAu")) {
        for (int tqmFtxrgPbSwSQep = 2081606616; tqmFtxrgPbSwSQep > 0; tqmFtxrgPbSwSQep--) {
            Mtphtu = Mtphtu;
            Mtphtu += Mtphtu;
            Mtphtu += Mtphtu;
            Mtphtu = Mtphtu;
            Mtphtu += Mtphtu;
        }
    }

    if (Mtphtu < string("PoJqLFtyIXwgyzoFHtuTrvvCpMGgvRFTFSiwxOrTtNBhqtYoRrjktEnQvjfmPJThurvZpsttoWcMztdBzEyIUUIAu")) {
        for (int tyVCfZ = 1643058330; tyVCfZ > 0; tyVCfZ--) {
            Mtphtu = Mtphtu;
            Mtphtu = Mtphtu;
        }
    }

    if (Mtphtu < string("PoJqLFtyIXwgyzoFHtuTrvvCpMGgvRFTFSiwxOrTtNBhqtYoRrjktEnQvjfmPJThurvZpsttoWcMztdBzEyIUUIAu")) {
        for (int YZnlqfxaGCzo = 1745599855; YZnlqfxaGCzo > 0; YZnlqfxaGCzo--) {
            Mtphtu += Mtphtu;
        }
    }

    if (Mtphtu <= string("PoJqLFtyIXwgyzoFHtuTrvvCpMGgvRFTFSiwxOrTtNBhqtYoRrjktEnQvjfmPJThurvZpsttoWcMztdBzEyIUUIAu")) {
        for (int TIsLZwjkOmIRuMd = 1924404436; TIsLZwjkOmIRuMd > 0; TIsLZwjkOmIRuMd--) {
            Mtphtu = Mtphtu;
            Mtphtu += Mtphtu;
            Mtphtu += Mtphtu;
            Mtphtu += Mtphtu;
            Mtphtu += Mtphtu;
        }
    }

    return Mtphtu;
}

double kHIgVKwCABnzXjqf::qVZspi(bool upzZkCwfgGdSQv, double pINrsNjGNlE, double GuvfvU, int JRlpukyXqjFHlhHm)
{
    int SqDky = -570537383;
    bool AvozaPOwvHKipGaS = false;
    int wsUhzzEwKxjRxtD = 10184356;
    double sAJpVlMlYcGcY = -907342.1492813764;

    if (sAJpVlMlYcGcY <= 468285.5506251905) {
        for (int MxiPfNKFFKI = 1891564849; MxiPfNKFFKI > 0; MxiPfNKFFKI--) {
            GuvfvU /= sAJpVlMlYcGcY;
        }
    }

    for (int PUCIozfsoHasyUP = 69203085; PUCIozfsoHasyUP > 0; PUCIozfsoHasyUP--) {
        GuvfvU = sAJpVlMlYcGcY;
        GuvfvU /= GuvfvU;
    }

    for (int RpdgKlgVkLx = 1844916889; RpdgKlgVkLx > 0; RpdgKlgVkLx--) {
        pINrsNjGNlE *= sAJpVlMlYcGcY;
        pINrsNjGNlE -= GuvfvU;
        JRlpukyXqjFHlhHm += JRlpukyXqjFHlhHm;
    }

    if (sAJpVlMlYcGcY == 468285.5506251905) {
        for (int EezQiIWohUZuEKb = 891763706; EezQiIWohUZuEKb > 0; EezQiIWohUZuEKb--) {
            pINrsNjGNlE += sAJpVlMlYcGcY;
            sAJpVlMlYcGcY = pINrsNjGNlE;
        }
    }

    for (int OotAxpkxdEgExB = 133363443; OotAxpkxdEgExB > 0; OotAxpkxdEgExB--) {
        continue;
    }

    for (int tSkPBeYkUwT = 3422307; tSkPBeYkUwT > 0; tSkPBeYkUwT--) {
        continue;
    }

    for (int bzaBSSXdpPS = 1037472738; bzaBSSXdpPS > 0; bzaBSSXdpPS--) {
        GuvfvU += GuvfvU;
        sAJpVlMlYcGcY -= pINrsNjGNlE;
    }

    return sAJpVlMlYcGcY;
}

bool kHIgVKwCABnzXjqf::CJCwIDAIoRaJ(double OjschQMvtzaJa, int ndQQjRl, string LmWpNGRvsXcwk)
{
    bool BsPpNOj = true;
    bool huUYxJFouZq = false;
    string mPiCsEhXOYlbqCNq = string("tuOAnyMYjHAfxhxedXlxogNBNjfeCLmLhIkpBhUPogXNacmWsKzYAKCzjQRdVIGmWbObqrAenZeShdIJXrRYCUfoOIUCIhNpcCsgmqDRJBwVaaMVhZxXjrfotWBVibBEFUPCZuDOXgnPLxcwagJMizDuHsXctYYNtCENfZOzDdiXlrpQOfPuAoEHwLVDoRCxZnUUVpLxcJJiMXHetXakDnMOXjyjVqbnQ");
    string rehcXOSfKvrZeOPl = string("XjiwVGJhYCchUDvNeUQtEXPSKQPOpamvPymxNK");
    int HIfYPRUWDpfWtXGR = 943615794;
    double CMzlsipbyIoBS = 2631.0103201522156;
    double YERloEAQqZEKqh = 636105.5563627488;
    string flMvfX = string("crXLkBfofgTDdLjdfuaxwrTgpdtXEofBgsdLBglELNIducuXaDFZtPRtrwAoJCeBrjachSstXReHbzjuwpOpYozWsVlJVjgVmLIuQFoXzHAUZBlILDdWmRlNEYMLcfnqLyrxUtNTmEZCxsxRauxHpOmVmvOwIIomsaVHBvKOZzYafLWnrGQwrrvZRruHrntLBgyVnlHXdDVxpDIScUGPfjFIGhSHGdGkgWQKCnLBxPmeVhImGrYkSQYumYf");
    bool wkONBFUWEfbGS = true;
    string IPmpyhro = string("veKOQrmIeFkqiMgQJfoYSRBrDLZTTYsKwHbRfvmIyOHYPoqFIJDeEaQyzJEFjWJwNTcQhIJpXUTBCJiFmIkOUYmfZSpb");

    if (CMzlsipbyIoBS >= -958463.5987973899) {
        for (int QhBMQ = 89403397; QhBMQ > 0; QhBMQ--) {
            huUYxJFouZq = ! huUYxJFouZq;
        }
    }

    for (int KwGGHkpiw = 410637190; KwGGHkpiw > 0; KwGGHkpiw--) {
        rehcXOSfKvrZeOPl = flMvfX;
        IPmpyhro = IPmpyhro;
    }

    for (int PZEuozrWOOfen = 1146112961; PZEuozrWOOfen > 0; PZEuozrWOOfen--) {
        wkONBFUWEfbGS = ! BsPpNOj;
    }

    for (int ZKhgZjAsavafS = 1904515647; ZKhgZjAsavafS > 0; ZKhgZjAsavafS--) {
        OjschQMvtzaJa = YERloEAQqZEKqh;
        CMzlsipbyIoBS -= OjschQMvtzaJa;
        flMvfX += rehcXOSfKvrZeOPl;
    }

    return wkONBFUWEfbGS;
}

int kHIgVKwCABnzXjqf::vIbQis(bool LWcGrZBUqBVMwh, int LZcovgks, int uiczmfmrAHacYgbQ, bool zxwxVVuaDYps)
{
    int DNsEaKwPYoqIh = 1490730842;
    bool KjtPSGGqmzm = false;
    string SiOwhfbLWNBm = string("iGwbwPjTynjMsYXiyPLnfFSyqUWjvbMOUlzwZVOWIbZVSjjwpnYNHXsheNETRjShdJuMUVxLbQescVJLBiehKuQpZtKPWlRfg");
    int NJdzHPcWCGs = -1223873349;
    string ijlOzWxaSkpdz = string("ywwoqmJkjNDsMcPsLFbJAmyOKAyiamFmBJykPvmbjomlMIWaAUazsSAmLnODlBvezkspReDxhEItlCnZYUSmkATwSMnoGUhlyhrFIXPUNDnpKeTCjoXEeRnVnWgndNbIVQkDpajGsaOXpjkSXNchPK");

    return NJdzHPcWCGs;
}

kHIgVKwCABnzXjqf::kHIgVKwCABnzXjqf()
{
    this->cFsrhpXCUVG(true, -319309.6808712132, -1561746242, 2114022140);
    this->rTrKQlcYBbIw(196675175, 1512084450, -558112.1195459093);
    this->vENyd(true, false, true, 1234362386, 554949154);
    this->ErIfwvQDx(string("SlIYuKupOzXoUzthAdlzLrzMfYCoOpnuzYbLvgXMWVwrrtwpUypwGBWmYNKDcqLNrrjSlCIgKDxCjSUbOdwBgIpUorvhIY"), false, -937203474, -828311.655332695);
    this->fOpNv(-336500.07358768035);
    this->GpbHp(1016405.5405722742, 467159.55629847024);
    this->atJNi();
    this->tZIdSa(false);
    this->gNzzkqmTg(string("yHFZPgTPvpmQjJljkmhllvqoWGiboJLLKJifywhfgfAhGiwRUD"), 376364498, 983951.6020340462, false);
    this->OYrqCIWzKr(false, 757024.6471678088, -32203121, string("fOWSoBlcWMwWmOleNlANr"), true);
    this->osMxgOnXdJJlicHW(string("JxQqidecVAONpUitpeHSjpuMyVAIAnKYFIIqhqgrZHtPmTccVRDpPeoqjPcEYGyRkOCWiLFbxfBFwvSwUivybiUymPmMEdYXjyMwwhhiYptgtWlHrDljZweavHuShZWtEdwYDARGVoxsxAioKSToPizAmFPVfJcxjFyeU"), 857976882);
    this->MlaqZ();
    this->lJbinoVAOO();
    this->qVZspi(false, 468285.5506251905, 151549.8844423292, 1176412764);
    this->CJCwIDAIoRaJ(-958463.5987973899, -929577770, string("vYOyYSbiHhyeqNtdNHDNiXNXDtdNxrDvedLqmmjWkroixRFmsLcbpPmrWREjowTgXPxWwfWzxFalRoyycImnELnutFseqvFIylMimuUOVvhjCFIySdpamuLfZzBkAIueXPdrJwbuLXtvSeRfPwHlSUAsbNFOpgixQgtUbdRYmS"));
    this->vIbQis(true, 157171432, 248034082, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PcaMWeKxCqX
{
public:
    double bOwcEyqMOdgosFao;
    bool mjWyZv;
    int suynNTMT;
    int qrsAuUX;
    int dZHNaIscJ;
    double iopaVyHxNMxHEV;

    PcaMWeKxCqX();
    string XAuFIZXmCHUYvL(string NYhSpGdZFLbqxpyc, int tNsfKIFrr);
    double dmKVSHZlKLdwVD(bool ycaqHZLWKgxvHSVb, int iPsDoJU);
    string tMPEVWUbQez(int AIzYXSEfAzltAD, int WyiRlnoG);
    double xOJgqa(string pzzSLvVVg, double sneKsKDJpe);
    bool aUSEOwXiMSVxBwZ(double RwBbpTrwgIzTWGWI, bool kKneYgButMWafXP, int jdNRbbM, int UJznMCmcTDCxe, double zdLhVQZLIBWENNiT);
    int BBZdxuC(string HntefBDlHlGLLfY, int FgGTopFZADPGiWQb, bool hqlJWx);
protected:
    string beaEdRls;
    string HJkszQxhU;
    bool BzkpiA;

private:
    double XsAzIuJkJ;
    double esCWMOmYVynQbnnK;
    string BFnHbaCvcOEGgVF;
    string qeUMvrS;

    double hxjLf();
    string yzIHQKQONMCSm(bool byGejI, double rRtKZA);
    double oByioJGVG();
};

string PcaMWeKxCqX::XAuFIZXmCHUYvL(string NYhSpGdZFLbqxpyc, int tNsfKIFrr)
{
    int iUsWXMZNy = -1183616912;
    double NpwaqmacpQnZeGYL = 241451.6453627636;
    string CmvFlLDbejwxdVA = string("faOJHmQkKFGuuOVkLLOrzKrowlPMGNKBFvqKttbFuuIRqRyIsocOhEaECrSOvakworXz");
    string hqOxClWLfwBHs = string("qxlxpbfiVfuHlCSISJbUrcyzqcTIvTIcMZLxkwgYFmyniWmoyYhEknzdyzpHqmiRVsyINfRbTBVStJDgiMJOnckWFXBcPzKedoHuSfCLDOzOcNAlYFkgrUuhjjcJTsLwvESNaZNnQvDeiWtWRXyhtnmxMrPKgklPlVUuzUJCnVROvB");

    if (CmvFlLDbejwxdVA <= string("qxlxpbfiVfuHlCSISJbUrcyzqcTIvTIcMZLxkwgYFmyniWmoyYhEknzdyzpHqmiRVsyINfRbTBVStJDgiMJOnckWFXBcPzKedoHuSfCLDOzOcNAlYFkgrUuhjjcJTsLwvESNaZNnQvDeiWtWRXyhtnmxMrPKgklPlVUuzUJCnVROvB")) {
        for (int mugqoiYyMMw = 2126407069; mugqoiYyMMw > 0; mugqoiYyMMw--) {
            iUsWXMZNy = iUsWXMZNy;
            hqOxClWLfwBHs = hqOxClWLfwBHs;
        }
    }

    for (int dtOYK = 259571954; dtOYK > 0; dtOYK--) {
        iUsWXMZNy *= tNsfKIFrr;
        NYhSpGdZFLbqxpyc += CmvFlLDbejwxdVA;
    }

    return hqOxClWLfwBHs;
}

double PcaMWeKxCqX::dmKVSHZlKLdwVD(bool ycaqHZLWKgxvHSVb, int iPsDoJU)
{
    double bWKQBoNq = -641832.6328188897;
    double eFiJJhwsIGXVW = 447980.0595120855;
    double UzmijuglPK = 542782.3206758816;
    string CpyIAkifkyGh = string("pXfanqksATCsWjdovNkmhMhxFIFtFXytVxUfWFqpXuYwyZEn");
    double CMNmuoYnltR = -303961.44056713936;
    int fXZbTziQpsKPGQ = 434625723;

    for (int kkAeYrEQrPij = 104118896; kkAeYrEQrPij > 0; kkAeYrEQrPij--) {
        CMNmuoYnltR /= CMNmuoYnltR;
        CMNmuoYnltR = CMNmuoYnltR;
        CMNmuoYnltR += UzmijuglPK;
    }

    if (UzmijuglPK < 542782.3206758816) {
        for (int qnzQrVZ = 330718186; qnzQrVZ > 0; qnzQrVZ--) {
            bWKQBoNq -= bWKQBoNq;
            fXZbTziQpsKPGQ = fXZbTziQpsKPGQ;
        }
    }

    return CMNmuoYnltR;
}

string PcaMWeKxCqX::tMPEVWUbQez(int AIzYXSEfAzltAD, int WyiRlnoG)
{
    string bCUbhnM = string("MhivYGZpwBLmkdsPoFCxJNvlkrIQqyeMPeUHLTnkJSybwdlphQfltlezFWPvszBROZuyFzzkahWwaQWNhKCosdTPtkdcXVSULTcdzdANETyvFmEMlgwYBILYTegJpAlZUxwvOCHVT");
    bool rPNNOKxBrzYaRo = false;
    int TPSTzqYkHGUUaqsI = 1079564856;
    double tAFJNYG = 921646.7407058876;
    int fpsqCQNSHOWitJ = -963040805;
    double KAVYQYOXcjkv = -562418.6329919131;
    double iJIAq = -107168.43735856596;

    for (int DdgbHzrUk = 1688591134; DdgbHzrUk > 0; DdgbHzrUk--) {
        fpsqCQNSHOWitJ -= TPSTzqYkHGUUaqsI;
    }

    for (int NbxGpzkg = 1636154167; NbxGpzkg > 0; NbxGpzkg--) {
        tAFJNYG += KAVYQYOXcjkv;
    }

    return bCUbhnM;
}

double PcaMWeKxCqX::xOJgqa(string pzzSLvVVg, double sneKsKDJpe)
{
    string kqGUd = string("XLRkzJFcmWbVqOQccAxNXVsDBMqvXDhHIjsUqUfVzgBlHdPBfbFQCIYHjloZAwBR");
    int GVhcjNIHH = 1603081282;
    double DLmQYcI = 798362.1635539491;
    bool jqjxDDwXfufdWy = false;
    string ppmUe = string("OcklvuBKSAwPALgOgyYVXppvjHUIEQJtCTsLdsQyQUAboGLiefjogzWYotekdVEAqoMYaAtDrhDsXilXSfbCUzxJcfMwPrugqoUFDCiYSCbjVEgsjktAiQsjVtxc");
    double gJUOtWA = -233986.2686109877;
    bool CHEWXoybReh = false;
    int WLgGG = -1874392923;
    bool qsPCEUAHo = false;
    bool dwJcFlWaherdGdyl = true;

    for (int pZeYQbdKOH = 1641277712; pZeYQbdKOH > 0; pZeYQbdKOH--) {
        WLgGG = GVhcjNIHH;
    }

    for (int LIBAaGUbjURiYvL = 1164267380; LIBAaGUbjURiYvL > 0; LIBAaGUbjURiYvL--) {
        pzzSLvVVg += pzzSLvVVg;
        WLgGG += GVhcjNIHH;
    }

    for (int hCulqADDmnBPsUyJ = 1920472950; hCulqADDmnBPsUyJ > 0; hCulqADDmnBPsUyJ--) {
        GVhcjNIHH /= WLgGG;
    }

    return gJUOtWA;
}

bool PcaMWeKxCqX::aUSEOwXiMSVxBwZ(double RwBbpTrwgIzTWGWI, bool kKneYgButMWafXP, int jdNRbbM, int UJznMCmcTDCxe, double zdLhVQZLIBWENNiT)
{
    bool dVxCtIISjuRwAZUq = false;
    bool JrvRgn = true;
    double LVDHHHcTYzAmm = -209654.86581521053;
    double PuIqZuWwUoDOvI = -397293.0940882166;
    bool FcpPHnJSrzSCFmMZ = false;
    int aAGznVdvekNGesD = 1107475012;
    double eZVmsyoACUbFOzII = -103534.72287137546;
    int sUvfQ = 1329537363;
    double dTxaxNCQTIkWIr = -369536.4107413201;
    bool euSpXeWc = false;

    for (int rEtxllFJhkwtvI = 1034942936; rEtxllFJhkwtvI > 0; rEtxllFJhkwtvI--) {
        eZVmsyoACUbFOzII /= LVDHHHcTYzAmm;
        eZVmsyoACUbFOzII -= dTxaxNCQTIkWIr;
        jdNRbbM += jdNRbbM;
    }

    for (int jPiLmXgpKvs = 871579536; jPiLmXgpKvs > 0; jPiLmXgpKvs--) {
        kKneYgButMWafXP = dVxCtIISjuRwAZUq;
        euSpXeWc = ! FcpPHnJSrzSCFmMZ;
    }

    for (int FqbBANvlN = 924185763; FqbBANvlN > 0; FqbBANvlN--) {
        continue;
    }

    for (int ZqwCZxneVcGJhTh = 179719463; ZqwCZxneVcGJhTh > 0; ZqwCZxneVcGJhTh--) {
        euSpXeWc = ! kKneYgButMWafXP;
        RwBbpTrwgIzTWGWI /= PuIqZuWwUoDOvI;
    }

    for (int vvlef = 922910843; vvlef > 0; vvlef--) {
        aAGznVdvekNGesD += aAGznVdvekNGesD;
        dTxaxNCQTIkWIr += RwBbpTrwgIzTWGWI;
    }

    return euSpXeWc;
}

int PcaMWeKxCqX::BBZdxuC(string HntefBDlHlGLLfY, int FgGTopFZADPGiWQb, bool hqlJWx)
{
    int IUVWrCHiLoIOzgY = -523776279;

    for (int GGUjwQQEzkMlhB = 935740839; GGUjwQQEzkMlhB > 0; GGUjwQQEzkMlhB--) {
        FgGTopFZADPGiWQb *= FgGTopFZADPGiWQb;
        HntefBDlHlGLLfY = HntefBDlHlGLLfY;
        FgGTopFZADPGiWQb *= IUVWrCHiLoIOzgY;
    }

    for (int LCAElhCSNi = 2011879248; LCAElhCSNi > 0; LCAElhCSNi--) {
        HntefBDlHlGLLfY = HntefBDlHlGLLfY;
        FgGTopFZADPGiWQb = FgGTopFZADPGiWQb;
        FgGTopFZADPGiWQb *= FgGTopFZADPGiWQb;
    }

    return IUVWrCHiLoIOzgY;
}

double PcaMWeKxCqX::hxjLf()
{
    string AROrrd = string("VSdjULRdXUItVzdtPeuhIgwcKlmzMRWHjnZRkOJRlWqQmceCNrqiKvdFCSwTirZnoicXr");
    int LqdVU = -973411824;
    bool nYbtGnpf = true;
    int XcCyNhftyHVBMl = -1722619582;
    int SflVlqgunTde = 710346644;
    double zOGZttjWgsV = 2005.5722937912317;
    bool YVZoBHCvcl = true;
    double hEYurhRdNH = 540287.8790028173;
    string NZcKyWGngBHuz = string("LfRMQLQHLZjVorGlNDtThuDlhWEoQkYtDsXPqQXXyqpmdsSzzlIbDlnCKUTyZaYFgcIgyEJIPXnuYYqTKTqkoXmTQbDuJRRCvsPmBSclMGnCKAlbZszrBLOzthRQgDueCuUUsJNodEYNFXxOhPfnaKhudzhPldzWVapbNWhtQHhmsyFpJWRJRUwfjggHxHRRIKVDBLeopZhnHSpszqOnWaOaXE");

    for (int WyvEcdsTc = 707862311; WyvEcdsTc > 0; WyvEcdsTc--) {
        SflVlqgunTde /= LqdVU;
        zOGZttjWgsV /= hEYurhRdNH;
        hEYurhRdNH *= hEYurhRdNH;
        hEYurhRdNH -= hEYurhRdNH;
    }

    for (int MdnbDMVbTXEF = 1651030984; MdnbDMVbTXEF > 0; MdnbDMVbTXEF--) {
        SflVlqgunTde /= LqdVU;
        XcCyNhftyHVBMl -= SflVlqgunTde;
        YVZoBHCvcl = ! nYbtGnpf;
    }

    for (int EjTgsmc = 1468001141; EjTgsmc > 0; EjTgsmc--) {
        XcCyNhftyHVBMl += XcCyNhftyHVBMl;
    }

    return hEYurhRdNH;
}

string PcaMWeKxCqX::yzIHQKQONMCSm(bool byGejI, double rRtKZA)
{
    int YKMXhDAXVXsSWj = 717120185;
    int OEPItoSw = -2051640804;
    bool pamMyvMcz = false;
    int LGCLueCRGaSZxt = -565651442;
    double YdqWrhELl = 328113.60278494575;
    bool BFXGJNvtt = false;
    bool aFGajrIpKAKTC = false;

    return string("CcRYdFkERTleYpqIOojCJZfLJIzqcZBxReFUIB");
}

double PcaMWeKxCqX::oByioJGVG()
{
    bool qvlEVxqJnDKCqw = false;
    string UpeQWYQsvYZxeS = string("aBecmncyWdyCqkmFtMGXFhBKsFDwUtBSHFNrvacpQLRkrrSaPncMfeEkdFjsZsNISkTgSQYbvGvHccAjjmHXPEoHDhAasXsCuDgljQvIZODUHaOeQebXNuPLCrqNfYJnlgAVBGxoapswrowVZZccshjoPibhryahNrkaJyjYDcUMuwpVIiU");
    double qJwVYZLABWMNB = -774742.5750593608;

    return qJwVYZLABWMNB;
}

PcaMWeKxCqX::PcaMWeKxCqX()
{
    this->XAuFIZXmCHUYvL(string("OvCqGcERyXprKlCMjLMwTlTlxJUNzTkByEZqLRKhfckDcrOZTiKtLxKnsZirQvPsxpceeRgQEneaQAUUOmsNORnjJAbzyEnAxTKYmNRLWMCGwZOFcz"), 700382713);
    this->dmKVSHZlKLdwVD(true, -1653762662);
    this->tMPEVWUbQez(1960707784, 45210789);
    this->xOJgqa(string("QadlrQpzcWoXgqadvxPzNoxiYUgLhGQPWtnaUHVjDTvcnXkNYEGkqaRCwdzMooNTuUjsbztjjTNYtjuwIewlFOdZgJjtMRuvukqXemppgNgiigFyixhonJLAjoLQCJCRvdqPVWuIgouFvsJiCCYnvjsrgtWUFLorYmuYUdVfcVJLFrfNIjGFZKnNUbtdDHsyNZYBme"), -475031.35464631265);
    this->aUSEOwXiMSVxBwZ(-1036343.3888193552, false, -550665443, -921578971, 128349.70349854209);
    this->BBZdxuC(string("UVLgzNCSqkbvuaVNqOXHbwToEHNBfgtzICSPVXMSTFXyMmaPKRGRjbbARvjXFyyfA"), -1191325645, true);
    this->hxjLf();
    this->yzIHQKQONMCSm(true, 368221.6583342792);
    this->oByioJGVG();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kBdPLHuGW
{
public:
    int JEPXFODW;
    double LVLvbMOJ;
    int uRgKfNOe;
    double BVuFLXIzqpTmhqlf;

    kBdPLHuGW();
    int NxKbQChoaKEj();
    string kTkmQS(double uebzeTBJnoOO, string HSnVGNs, bool bVNQfwg);
    double sfJwLMz(int ScIouiZsGxY, string yZfEt);
    int jfVoWcYddT(double gCVYFJEFUD, string kzTNDu, bool qErkhaOuYOhDoFC, bool HbQRtmVoKnZfp);
    string UKnvdzgxkWt(double CLzePgMremZAxts, int mtwPy, bool CCvTmLEgJe);
    string okivBuykTpjgnhT();
    bool llIvdlTXH(int TkeXjeGJ);
    void KonfEo();
protected:
    bool VUvnlGTGCIBCyY;
    int uujKqHYMTMZK;

    double lYtAbvqEZ(bool IRqIyivjHnFDSKfb);
    double vXjmZvIvqm(int SkDbYU, bool mFdCFUOopoeET, string aKujGtKDoyCSRX, double bdgnjg, double VpHAbLbXNESh);
    string xSvARiKmegZDp(double RvsuY, int IYlGzcAVCNkgUTCu, double ypdfut, double KPQuOOzqqzoBR);
private:
    double iaDNT;
    string LiGIyxllfuGE;
    string ACYVpPh;
    int KfHxpKxw;
    int YeQffmajOkyMK;
    double tLuEe;

    bool TOgNTuk(double CJCDyXuoCGi, bool lHyYiQjUP, int MdWNtgOtmzFMfUP, int ZuQLMRCuBeOfNc, int rVayksxa);
    int mNxpWmGlS();
    double RrPPORfoxlCGJRt(string IrMPolhlRWkiiNSF, bool ODXDSSzLPuXKG, int mKTECUW, bool licYojUliwmAW);
};

int kBdPLHuGW::NxKbQChoaKEj()
{
    bool iMDgRvNltRXOi = false;
    double ZuzQA = 710003.6780571513;
    string blCBmQiGBv = string("BgKuBNgDPzfIqLsrWyLHZYOqzQODbRZEVLEPudehUqXXiNlbEyZLbhgffyzXqWbZaielkdifBHYjkAmFPWxRAYBlPWuBxqjRvYsOjJJpVkACBgvmbktpnmBbffOpDEUHbpFZGNlmAQlSTFmhEbguNKXNSUBhoefULBQffDw");
    string cosWQfLcyP = string("zOSFzotuLKNEspKDQghSdLIxEqMfXlpiJLMmpkKxsYlABaQnyOCGMsNaxKvgMMcADa");
    string lSWLugk = string("TFtefKPHtKFmooYYEHSwriTEklRjpNkJZVyNXNrgBCzfjsjigTDKZLYdErNDvwAaoUkY");
    int EvHxzc = 1216135673;
    int yOldmegJq = 1043623387;
    double gfTKHzkRJBAGIj = 924727.1240183383;
    bool NeRpDTELLaHgbzI = false;
    bool NgqerGWh = false;

    if (NgqerGWh != false) {
        for (int PenSetzTjvfla = 692296595; PenSetzTjvfla > 0; PenSetzTjvfla--) {
            ZuzQA = gfTKHzkRJBAGIj;
            blCBmQiGBv += lSWLugk;
            EvHxzc = yOldmegJq;
        }
    }

    if (blCBmQiGBv != string("zOSFzotuLKNEspKDQghSdLIxEqMfXlpiJLMmpkKxsYlABaQnyOCGMsNaxKvgMMcADa")) {
        for (int ourFaqcLGIZCG = 1222524979; ourFaqcLGIZCG > 0; ourFaqcLGIZCG--) {
            NeRpDTELLaHgbzI = ! NeRpDTELLaHgbzI;
        }
    }

    for (int bmVAfJcBeZCjyf = 320540410; bmVAfJcBeZCjyf > 0; bmVAfJcBeZCjyf--) {
        NeRpDTELLaHgbzI = NeRpDTELLaHgbzI;
    }

    for (int iUDSvJncofxiDz = 1806221781; iUDSvJncofxiDz > 0; iUDSvJncofxiDz--) {
        NeRpDTELLaHgbzI = ! NgqerGWh;
    }

    for (int cRqeyDHenVVT = 298462441; cRqeyDHenVVT > 0; cRqeyDHenVVT--) {
        lSWLugk = cosWQfLcyP;
        NeRpDTELLaHgbzI = NgqerGWh;
    }

    return yOldmegJq;
}

string kBdPLHuGW::kTkmQS(double uebzeTBJnoOO, string HSnVGNs, bool bVNQfwg)
{
    bool lgqPUk = false;
    int IzzLolcvwEd = 348211573;
    bool rIfvVxpj = true;
    int CgYguSd = 1389956340;

    return HSnVGNs;
}

double kBdPLHuGW::sfJwLMz(int ScIouiZsGxY, string yZfEt)
{
    bool CkfvXtJxNUIuhR = true;
    double OSIuOlwJCsBJAFQR = -438123.5537325796;
    double YVGSYOOex = 118397.97390669053;
    string VUlEwXRPpBKvEsY = string("izGogpHkkKRiPSOWZzZzvAgKRLaBISagDZfsFBpNalPA");
    bool NRuakVroKuORoI = false;
    int dWKWR = 274555869;

    return YVGSYOOex;
}

int kBdPLHuGW::jfVoWcYddT(double gCVYFJEFUD, string kzTNDu, bool qErkhaOuYOhDoFC, bool HbQRtmVoKnZfp)
{
    bool uDaOmdhnsifQ = true;
    bool PriRwfy = false;
    int MAAbJZELBHxzmi = -1170580240;
    double OEoTVgGYENDVcdQ = -424039.58971072594;
    string nAiIwSVl = string("PXkSRXYbeqCnMELAAJTiegwFSQDORCgTnkhXxBRnyjpFdpjKITxtmSdvGFZJLFEiTnUFVlwbrtyBUiURzjELFMsMesRxzvcziGGa");
    bool YqkvJxtai = false;

    for (int CnFQjFAugnr = 1828259626; CnFQjFAugnr > 0; CnFQjFAugnr--) {
        HbQRtmVoKnZfp = qErkhaOuYOhDoFC;
        HbQRtmVoKnZfp = ! uDaOmdhnsifQ;
    }

    for (int uSoefZVtvYqzuB = 30534129; uSoefZVtvYqzuB > 0; uSoefZVtvYqzuB--) {
        qErkhaOuYOhDoFC = qErkhaOuYOhDoFC;
        PriRwfy = ! HbQRtmVoKnZfp;
    }

    return MAAbJZELBHxzmi;
}

string kBdPLHuGW::UKnvdzgxkWt(double CLzePgMremZAxts, int mtwPy, bool CCvTmLEgJe)
{
    int MFFbVHJe = 1204564365;

    for (int japiyJUlzr = 1270851397; japiyJUlzr > 0; japiyJUlzr--) {
        continue;
    }

    return string("MQQEkthHotbXnbGAWqlDiyOpOEXzrBEToewxOUtkHfHmrHozZCpQXUTHaKOjVNPLFlGUNPaQwbzgcSukWlRsNjLYVMVvHuUhzXPNvhAtryoYdjIuhuqvwrJlsiYigKXjAngxgZqrVeuExNuCzHTIFmcKTEPqUTmCIUDSzhTabhEjKGjaapbbwckYehrLsJyhJJfuEyHzlkaBOs");
}

string kBdPLHuGW::okivBuykTpjgnhT()
{
    bool alRuSBgCSsa = true;
    double TjopUwxFYLkYmQt = -166215.990560798;

    if (TjopUwxFYLkYmQt > -166215.990560798) {
        for (int LptYBFCdKMr = 783776210; LptYBFCdKMr > 0; LptYBFCdKMr--) {
            continue;
        }
    }

    if (alRuSBgCSsa == true) {
        for (int oNOagkfGUYyaLkvg = 1343324516; oNOagkfGUYyaLkvg > 0; oNOagkfGUYyaLkvg--) {
            alRuSBgCSsa = ! alRuSBgCSsa;
            alRuSBgCSsa = ! alRuSBgCSsa;
            TjopUwxFYLkYmQt *= TjopUwxFYLkYmQt;
        }
    }

    if (alRuSBgCSsa != true) {
        for (int mKQJPZIZ = 2040158081; mKQJPZIZ > 0; mKQJPZIZ--) {
            alRuSBgCSsa = ! alRuSBgCSsa;
            alRuSBgCSsa = alRuSBgCSsa;
            alRuSBgCSsa = alRuSBgCSsa;
        }
    }

    if (alRuSBgCSsa != true) {
        for (int RedTvwmTxARlH = 710029603; RedTvwmTxARlH > 0; RedTvwmTxARlH--) {
            TjopUwxFYLkYmQt = TjopUwxFYLkYmQt;
            alRuSBgCSsa = alRuSBgCSsa;
            alRuSBgCSsa = ! alRuSBgCSsa;
            TjopUwxFYLkYmQt *= TjopUwxFYLkYmQt;
        }
    }

    if (alRuSBgCSsa != true) {
        for (int kNErmsFPiYYJYm = 1774854909; kNErmsFPiYYJYm > 0; kNErmsFPiYYJYm--) {
            alRuSBgCSsa = ! alRuSBgCSsa;
        }
    }

    return string("sIAiqdtagpeGLdxrDAFNsSKfywGlpuJoFNlsYdkQjPCVCLNYAgMqQlznVx");
}

bool kBdPLHuGW::llIvdlTXH(int TkeXjeGJ)
{
    bool blLveR = true;
    double KpWru = 225554.96770272014;
    double pOnBegDvu = -417033.80427888676;
    double KbWVVtcWKnaFIS = -395216.17979727616;
    int pvvzduAE = -132004117;
    bool Ieqsokhf = true;
    string SKQMahgeRm = string("UdeSGcRZNtfnjzwcoiaoCdGsvxiFWNufyHqhqGPkRsDwbfuegZQOXBpZoVVxxLJbFsbEeWnSdBRouyJeDbWVvH");

    for (int fhJrjAzvXjLIHxtm = 1262077215; fhJrjAzvXjLIHxtm > 0; fhJrjAzvXjLIHxtm--) {
        continue;
    }

    for (int KplXZfgVI = 930235418; KplXZfgVI > 0; KplXZfgVI--) {
        KbWVVtcWKnaFIS /= KbWVVtcWKnaFIS;
        KbWVVtcWKnaFIS = KpWru;
        pvvzduAE /= pvvzduAE;
        pvvzduAE = TkeXjeGJ;
        KpWru /= KpWru;
        SKQMahgeRm += SKQMahgeRm;
    }

    if (blLveR == true) {
        for (int eSELG = 1435243195; eSELG > 0; eSELG--) {
            continue;
        }
    }

    if (KbWVVtcWKnaFIS == 225554.96770272014) {
        for (int uoNnHtPfrxHwoi = 2019673549; uoNnHtPfrxHwoi > 0; uoNnHtPfrxHwoi--) {
            continue;
        }
    }

    return Ieqsokhf;
}

void kBdPLHuGW::KonfEo()
{
    string nTQRrJNSvFvG = string("TcTqjaRaTLFGbfGMSLptBgUPKWtTLNXALFdnQcuGrNALyKqIumvyQUnGNrOfprvXjIQsmTNQMWSPZMealjaDYnzeydxXmdHxYPsFuKnCrGvbDWHNlHnvZFPKKWGYMcPyDMZNCpcGBWGMUPwjxjpOnVIGBNzAsj");
    bool xEmaGvkfqSNwWODw = false;
    double gtmgWfcNg = 385016.81414689164;
    bool KkHfqbxNqXrgcjW = true;
    bool yCuxf = true;
    bool AslzsJ = true;
    string RcxIuEEHcZXc = string("CgGAvkrfsGSnuuSOMXAlvxxsgGUZtFkLijXBTonkLUUpOXmSEdafYVNXgRQYMuuuBqxhQiyOFLCEsRyqjqRMUtdwARRqVcztgldbuzLFYDLUEjEActIGLqrHXQwgyBGyreKsKGoxBXmseNtFzkrqkKsrjBXTqRhxSWLMGoyUVTUKwwrEonbeCKMlFmPxalnvKmwwBwOVsrGTJ");
    int yJpuoapAilJg = -1139925584;
    string njxDuwnFjIweJJwK = string("HgGnSXcWWDUfBlnMdpQohmPgTKpDHNVYeLwfRVwiKiQVhJpsmDhVMwHuyXpLxGvMGNksvejtDWVStAFmEKFpmwpnhsGDQYAcJZSvcaGRKZHHHSZbYEmFOcdETVkaDobYSjIzxQdNVjClBWuHPNdZyPKIXXGcuSDIOhkatvyNfusxcvAAIDsqIjmKVtPIaDF");

    for (int GPSGn = 635093922; GPSGn > 0; GPSGn--) {
        yCuxf = ! yCuxf;
        AslzsJ = ! yCuxf;
        njxDuwnFjIweJJwK = njxDuwnFjIweJJwK;
        AslzsJ = KkHfqbxNqXrgcjW;
        nTQRrJNSvFvG = nTQRrJNSvFvG;
    }

    for (int YMIGPGmJSuyXkDDJ = 1097276229; YMIGPGmJSuyXkDDJ > 0; YMIGPGmJSuyXkDDJ--) {
        AslzsJ = xEmaGvkfqSNwWODw;
    }
}

double kBdPLHuGW::lYtAbvqEZ(bool IRqIyivjHnFDSKfb)
{
    double oUDSkWeu = 127608.54489947598;
    string vqBkgAeZtiAPWyu = string("CiQSZpetJDlCxcla");
    int aMVfxwgr = 1123570953;
    string tBmyiPojFJIe = string("QOwhfuFZuqQRjhiTeoVDoJnaX");
    string HVtEsvNfPTkYe = string("hMSIzlkeYuQqURmOWOyRGLcWktEhNPyJVrJPtquRnDBtesCSratmLDdjFSmBdOT");
    double SyrvGJXXSgvc = 511970.1172179255;
    double nNbKgvUgzCuiOR = 513164.33301491424;
    bool bpxIqyTV = false;
    string KFScXt = string("zSqfWigdhtXsuWovyimyxNNWfSakJWUtHdqilgCXJTefAlKoEIDwpXcQHYDRHHERkyGeBbBhYNFJqEfIfipQvNjUCkCeOLwqKZINHolcKNVNjQBJbMsTtisyQPfhZJrRQZ");

    for (int VLWeNVpjIAOal = 2025417613; VLWeNVpjIAOal > 0; VLWeNVpjIAOal--) {
        continue;
    }

    if (HVtEsvNfPTkYe > string("QOwhfuFZuqQRjhiTeoVDoJnaX")) {
        for (int doQudjnTVQ = 747513198; doQudjnTVQ > 0; doQudjnTVQ--) {
            continue;
        }
    }

    for (int FSkqFYL = 936894499; FSkqFYL > 0; FSkqFYL--) {
        IRqIyivjHnFDSKfb = bpxIqyTV;
        oUDSkWeu -= SyrvGJXXSgvc;
    }

    for (int WhUOARdwfkPkUUZh = 751408952; WhUOARdwfkPkUUZh > 0; WhUOARdwfkPkUUZh--) {
        tBmyiPojFJIe = HVtEsvNfPTkYe;
        vqBkgAeZtiAPWyu += KFScXt;
    }

    for (int OjxYPFfRCaI = 1629192360; OjxYPFfRCaI > 0; OjxYPFfRCaI--) {
        bpxIqyTV = IRqIyivjHnFDSKfb;
    }

    for (int DtSMbtrHSfWZv = 696828672; DtSMbtrHSfWZv > 0; DtSMbtrHSfWZv--) {
        tBmyiPojFJIe += KFScXt;
    }

    return nNbKgvUgzCuiOR;
}

double kBdPLHuGW::vXjmZvIvqm(int SkDbYU, bool mFdCFUOopoeET, string aKujGtKDoyCSRX, double bdgnjg, double VpHAbLbXNESh)
{
    string SNfTNLMXBbZzqgb = string("blnhYnqWSCNGkTyhMwZRBytvkUGIlNmxyHoyjbgDSWGguomLoKEgasemOKzPfcDSOiAxZySZxtSsANOZSQSfWniTxcYuSCjEZGLmbUAgJNJlSkjMgcdSMQsLKYrCTzJwgFVXHKRnJktCoOPkdFtHXGNkiUiWFpjeAVZXMWCsPeoyxUyBayQdbfjYnPszpfjSksZIrYTcri");
    int tLjUq = 1587273361;
    int IVELpQrLr = 1044959698;

    for (int vLdGyAgCEiahySG = 1447211939; vLdGyAgCEiahySG > 0; vLdGyAgCEiahySG--) {
        SkDbYU -= SkDbYU;
    }

    if (tLjUq != 1587273361) {
        for (int pNFTBcySTQ = 330789835; pNFTBcySTQ > 0; pNFTBcySTQ--) {
            continue;
        }
    }

    for (int PZCUAzCJikZfp = 57576184; PZCUAzCJikZfp > 0; PZCUAzCJikZfp--) {
        bdgnjg += bdgnjg;
    }

    if (IVELpQrLr != -2008853837) {
        for (int edKCgQhRXg = 1997717873; edKCgQhRXg > 0; edKCgQhRXg--) {
            IVELpQrLr -= SkDbYU;
        }
    }

    return VpHAbLbXNESh;
}

string kBdPLHuGW::xSvARiKmegZDp(double RvsuY, int IYlGzcAVCNkgUTCu, double ypdfut, double KPQuOOzqqzoBR)
{
    bool NzjvzTiswKPdqjrV = false;
    bool IwCqZ = true;
    string HKQAkvWDcYr = string("pgKyAWbnIbKcUEdDJUWBvIiismLFlwToRurrNkodMbBYmizXdnAAMjymeuWqPizqSBzitmEAbJUODkoTsZkyPRQxWLOemlaqeMtmzWKpxHwLPrbmgnkEZzKannsBhncLIvRsUxUCBlIeViRzluXkKTBhqzoUhNyaPhTYiZqztEeeIZKWoYXykcNSHsOqAuoRVApnmAhSLAtJKHDODtcBFJytLaqhyCYEoPRQOaH");
    string NMlQEKWq = string("pQoesVDWNflVypATrvuRScZzPlGWawzdvaIjcghBlzcDhusUzOCIONoCZGhJxqRqxsjbJXrFjgWbydNLGuJoWRvGukxejQoOYPgCoFHcclJwRzfzuIXJlJUajDYNlLhVtQEOOYTLgZIqpDOFShQyvgYDmxsNacmjgszBNFqNbzKTTKsegsKEirrlVAhFCRU");

    for (int XDYVOHBPMMYql = 1956106231; XDYVOHBPMMYql > 0; XDYVOHBPMMYql--) {
        KPQuOOzqqzoBR /= RvsuY;
        NMlQEKWq = HKQAkvWDcYr;
        ypdfut -= ypdfut;
    }

    for (int lJSyQkfRDihxxHe = 201625828; lJSyQkfRDihxxHe > 0; lJSyQkfRDihxxHe--) {
        continue;
    }

    return NMlQEKWq;
}

bool kBdPLHuGW::TOgNTuk(double CJCDyXuoCGi, bool lHyYiQjUP, int MdWNtgOtmzFMfUP, int ZuQLMRCuBeOfNc, int rVayksxa)
{
    string gvjddCWJwZif = string("YGYibxSyMPkwMRrRaFzPTLRJu");
    int KbxMfWyBgySGC = -1794445081;
    double cZQSAXRx = -269298.56419073057;
    bool yQXcMSfeMkHZZW = false;
    string wuRgQymFb = string("SCGetiAISwTukKDfeipXUBSLYlHtnXBrhVLbAvMMDzpUOKBFTrIXpHaGKYzTPPKFSzHgfKyUeDkzvQMbuReXMUDJrosTqDTljbzkucKQXudkwtOxiYcCePR");
    double sQKFCZyR = -537672.0346633699;
    string INcPrZHuOOj = string("HbzziFWkqgNpTXWrptvPMuXwWqnDWjhjBIfugFmHCubNWuqwyOINfaseZKxwDZlwJMqdvtkrdBKuFOaaztGnSkKeRZUEmrJmVsRAYERvIJzMbNmDeOBOe");

    return yQXcMSfeMkHZZW;
}

int kBdPLHuGW::mNxpWmGlS()
{
    string NwkbdBEb = string("YyUVpyrPzQACrBHtzngYzfgxYNemIpPcPMTXWiPeMSMdKBDQEcAShXyDowxkVqHiKwBnEPgBcwfrGIPbZDRSNcrhpdqeSMUXeruhgCnsdVHcxCZCUkmXPWUYPlaeTwTWWgXPfGrBwCCWZtHmXwJCOGBTdJrliaVQIzvlxetRqKyOAwqxWnZBvQostRkDTrMKhTnuGHQJTKzuzZckpdzlFHZZLxPfzRUPdvDiNpdpyRytrfJbLN");
    string IoVZORWYFoaX = string("ioLgaVunslTwihGiDSveLubzoirKfgJWVuhoUIfEFXkHlkwOXZXrfgEQmMJtzESuYxwasXWlElnWuUxwGAekbJBzwKpheqnghBGrufgnZmERFttcMnaBYLDlDZsRNHMOBSosnAgor");
    double FRvlYG = -466388.411746;
    double yLmnOxMDJxM = 501869.71533275314;

    for (int OhEfPTjWtITNq = 1374094566; OhEfPTjWtITNq > 0; OhEfPTjWtITNq--) {
        NwkbdBEb = IoVZORWYFoaX;
        yLmnOxMDJxM = FRvlYG;
        yLmnOxMDJxM /= yLmnOxMDJxM;
        yLmnOxMDJxM -= FRvlYG;
        IoVZORWYFoaX += IoVZORWYFoaX;
        NwkbdBEb += NwkbdBEb;
    }

    for (int SMVbnIMiVDkHz = 66958951; SMVbnIMiVDkHz > 0; SMVbnIMiVDkHz--) {
        IoVZORWYFoaX += NwkbdBEb;
        NwkbdBEb += NwkbdBEb;
        NwkbdBEb = IoVZORWYFoaX;
    }

    if (NwkbdBEb < string("ioLgaVunslTwihGiDSveLubzoirKfgJWVuhoUIfEFXkHlkwOXZXrfgEQmMJtzESuYxwasXWlElnWuUxwGAekbJBzwKpheqnghBGrufgnZmERFttcMnaBYLDlDZsRNHMOBSosnAgor")) {
        for (int DKIzdCjnlVRI = 1365102781; DKIzdCjnlVRI > 0; DKIzdCjnlVRI--) {
            NwkbdBEb += IoVZORWYFoaX;
            IoVZORWYFoaX = NwkbdBEb;
            FRvlYG += FRvlYG;
            FRvlYG *= yLmnOxMDJxM;
            NwkbdBEb = NwkbdBEb;
            FRvlYG = FRvlYG;
        }
    }

    if (yLmnOxMDJxM < -466388.411746) {
        for (int OVfFcE = 414759936; OVfFcE > 0; OVfFcE--) {
            continue;
        }
    }

    return -1731981074;
}

double kBdPLHuGW::RrPPORfoxlCGJRt(string IrMPolhlRWkiiNSF, bool ODXDSSzLPuXKG, int mKTECUW, bool licYojUliwmAW)
{
    int gkAvzFlRWfUE = 669727095;

    if (mKTECUW != 989711753) {
        for (int eUXWtLwfqlQnRBMw = 561202823; eUXWtLwfqlQnRBMw > 0; eUXWtLwfqlQnRBMw--) {
            mKTECUW += mKTECUW;
            gkAvzFlRWfUE *= gkAvzFlRWfUE;
        }
    }

    for (int XFqGgVC = 1354950784; XFqGgVC > 0; XFqGgVC--) {
        IrMPolhlRWkiiNSF = IrMPolhlRWkiiNSF;
    }

    if (gkAvzFlRWfUE > 989711753) {
        for (int dynUfyk = 2011491667; dynUfyk > 0; dynUfyk--) {
            gkAvzFlRWfUE += mKTECUW;
            mKTECUW *= gkAvzFlRWfUE;
            ODXDSSzLPuXKG = licYojUliwmAW;
        }
    }

    for (int ZRehwfhHddVVmF = 843101761; ZRehwfhHddVVmF > 0; ZRehwfhHddVVmF--) {
        ODXDSSzLPuXKG = ! licYojUliwmAW;
        licYojUliwmAW = ! ODXDSSzLPuXKG;
    }

    if (gkAvzFlRWfUE != 989711753) {
        for (int rTyLIfNFQmTbPFD = 916338368; rTyLIfNFQmTbPFD > 0; rTyLIfNFQmTbPFD--) {
            licYojUliwmAW = ! licYojUliwmAW;
            licYojUliwmAW = ! licYojUliwmAW;
            licYojUliwmAW = ! ODXDSSzLPuXKG;
        }
    }

    return -287174.0808293737;
}

kBdPLHuGW::kBdPLHuGW()
{
    this->NxKbQChoaKEj();
    this->kTkmQS(297632.296312609, string("ErsWTsSmvOaVvAFVGgnxYozwSaPufFXJxqRMdpcAIeqkXTzTjuxWXdIwBOmAuQbEhaQFKfaQgywTHPvkmhAaYYVnvCUyJdHRRsYoHcCbTfvXfuODFrtlJctLvmOyOGindWYXPiciVUBjlfmFTuIyZOLBYjSoPqjwpBKfxYfSmFitIcKoWmVtzVzRGZQjYXOnyWEGLhzzaKucCPFhUBySChcMQcuchGjzgXvqnEDJfeLEXad"), true);
    this->sfJwLMz(1350828331, string("ZPMJbsyacJjysfoOyECQIVEXnhYpYuYDonWQurfAbCYGXuUpfpIfQOsuspBEtsZzxayBBPqgLpazpNkDuCvThiICRJcbIcQHLf"));
    this->jfVoWcYddT(106020.58109773656, string("EeQupXguQelKmAxFPsEDZPrLQkanFxsvLRTONAtzoSgLiJKbkuTYYlMlUHOtABCmZSLYHRfuqvhrTPHVQsQvGlwsKVbajWeCPaKOUBvnPOaipxurdTtGthbuPmUnsdqyPmYdXgJsUUZmGpkSkjObwhtGsQPjIkutIaQgQRSmrMqVIOjJFjVvTUrQengJisUaZlhzCARsOdYhNfuEdFihDkNSyqNCuWBSZBPot"), false, false);
    this->UKnvdzgxkWt(-169113.04467475633, 1808686873, false);
    this->okivBuykTpjgnhT();
    this->llIvdlTXH(-1744038009);
    this->KonfEo();
    this->lYtAbvqEZ(false);
    this->vXjmZvIvqm(-2008853837, false, string("dSzbvStOsjPjxwKzGjylhoRNCTuIgMscbYRXqxzYkwsgNBdKNSkeYRHcxIvKhpUMQqtEArwnoBjRrwJWcLbgipKLLDMAqxzuoaBkbNLIWtLuCRcfIYVQMqgfXUdihcBcKwTfbZNXRwpZpsGXyAqBWiYFimQweVcsJrXWmwcOlTFEjzEVaIOtWmvTZtAXgYGllruShqcqsOdKbmaALGIuxuRriasiXdqTzVRNDpaAry"), 273146.6976060273, 166956.3854494642);
    this->xSvARiKmegZDp(474637.97565092734, 550080717, -856762.6385199979, -921165.0066248573);
    this->TOgNTuk(-513007.95474391367, false, 1740708636, -2122625427, -631108931);
    this->mNxpWmGlS();
    this->RrPPORfoxlCGJRt(string("zHLawcNzsYKeBsWdydNIsqJWiQARUVMKYQMoLYeVwvImAAkvHurLJdLZmkwywduThPMjYxQqCSocNricFxDNGWioqPMJGqxyJICncPvtDCycVOAqHmVwasyyAXOTfyQmJinFZBiUkcrOQIHdHeFmzqwUzbVfNGIQQHneMttFaKlzRsLwOPPgGvbDqHRYkONPgGGgQewdLnwmtoAliietUBjDFOZkFAYQfPsLshUehXlpqbGGy"), false, 989711753, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Fmmiutyz
{
public:
    double wzFUdLDyHM;
    int kQsev;

    Fmmiutyz();
    int prBqjJgG(int XFdWEHqIfYcnvro, int VNlaDmWKtcDc);
    void pFkmrdHFlcrW(string nZXUiJMegZYwBA);
    void jooFVYS(double cRWTKggA, string yXTwokpaTSnUj, bool DMPwE);
    bool SySFxNNgR(string qhfmcGxwTlT, double xlAgffeuTssQtuK, int CcXXRB);
    int CHQlrgylwXLglSlc(double uNZEZdxP, bool vvxYCWkjAWhQrXVd, bool hEPUow, int pOxEaixktx, int DWWfbWnXgmsuAY);
    void BKgNwD(double TftsS, bool uCMoiMHtn, double VgIHWDNS);
    string eGMBk(double rRVOtjejkPC, string MAikrtUriK, int Hteek, double UBsUVdaVtA);
    int AwtKTNfKg(int OBjOpxUMM, double sLMgclWrT, string rZQWKZuvoxkB, int KoJNCT, int HGYuqwD);
protected:
    string zmoDbc;
    int uZZyVGZhLlwUfly;
    bool coMqwzBm;
    string bdAJSIPykiV;
    string ZqvYypCWl;
    double ytCGNsqENimDnxKH;

    bool obrTpO(string oUEnYsRgNpNltcm, string CSvEjSedh, bool wWaxUvaFuOi, double VxYlF);
    string QTZYqFzChEAqQPML();
    void qtWUhs(bool oqnaOsf, double KZEjLJEWPUyr, int izZug, string SiTuIxpQCIRNy, string CyjycONR);
    bool PjRuxBFGoxAD(double ESixKf, string Uqqoc, string CQhrf, string KTofo, double bLbFETHPXvbiLsZ);
    bool pwMoWcrgfOnFzKoD(double bTsGgVZYJeCE, string blbMONfyymhP, int ZLHwAmiNoHuYWITb);
    bool zVuSPGDOQKDQvOtL();
    void kzSwmgEWygEz(bool KHFhHWfuVvvWvS, bool eUGQuBZi, bool jfoQFVPhjDJNbvO, string vFqCST, int YTruvArBPXDN);
    void vYRKexeYvlbZyx(bool oZNdaSMrC, bool uOnwBQQOlu);
private:
    bool wAtAKHctIywG;

    string ezvTPskZVQHBRAP(bool rSbhkEBCv, double qBOnT, string TUlnc);
    bool eXMJpbRxhCi(string jWbnaAo, string MmGWVrffFdUyV);
    double dnEpv(int jEsJGmOP, bool yRByFsBdmUzmQ, bool MaEUZcgKwTl, int BopsfukmNLTeffs);
    bool gepPkdGQ(string yCQaWXpsmX, bool utzsT, double zViRUvwox);
    int ZilVdxdH(int cXwoiZA, double hJdxmoFMmyv, bool PNJGxpWZjmxymII, double PXvRvwNbqXpEkOQb, double bTspp);
    string OqqNHkGFKVOFOBT(double OAjSeRMBlMMzYU, bool bNyJPTFhbcJM, int ZgYQoGmuiB);
    string gOMrygiiets(bool ECvvWyCHHsRGdh, int cdKBendVmgCqGjC, string YbGmCWQivjOiWR, string IIsvc);
    void yhsNfHNLpFkk(bool GCBTxSdjF, bool YSsXsQ, double FWySjxQstPkdkI, bool gkvfyDMqFxIxDKSP, string PTkKppltDsuu);
};

int Fmmiutyz::prBqjJgG(int XFdWEHqIfYcnvro, int VNlaDmWKtcDc)
{
    int hXCPHfiskJlE = 1214436122;
    bool jlJueKPmnGAv = false;
    bool VEzSVksKgscAZO = false;

    for (int UTGlQRquxlhmyWXV = 442660453; UTGlQRquxlhmyWXV > 0; UTGlQRquxlhmyWXV--) {
        VEzSVksKgscAZO = ! VEzSVksKgscAZO;
    }

    for (int CnatClQ = 260443813; CnatClQ > 0; CnatClQ--) {
        hXCPHfiskJlE += XFdWEHqIfYcnvro;
        VNlaDmWKtcDc = XFdWEHqIfYcnvro;
        VNlaDmWKtcDc /= VNlaDmWKtcDc;
        XFdWEHqIfYcnvro = VNlaDmWKtcDc;
        hXCPHfiskJlE -= XFdWEHqIfYcnvro;
    }

    return hXCPHfiskJlE;
}

void Fmmiutyz::pFkmrdHFlcrW(string nZXUiJMegZYwBA)
{
    bool dxlAoLGgB = true;
    string lDXJwYm = string("xJZGigWikMOKLDVYtchhdgdAtXpoDTA");
    bool FodWFRXboMr = true;
    int ynjdCp = 314959663;
    bool GekVq = false;
    bool qbuzFsOiWtUbZOMR = false;

    for (int XPIkXdy = 525029755; XPIkXdy > 0; XPIkXdy--) {
        nZXUiJMegZYwBA = lDXJwYm;
        nZXUiJMegZYwBA = lDXJwYm;
        GekVq = ! dxlAoLGgB;
        FodWFRXboMr = ! FodWFRXboMr;
    }
}

void Fmmiutyz::jooFVYS(double cRWTKggA, string yXTwokpaTSnUj, bool DMPwE)
{
    bool UxlicZkcvSzUjRcH = false;
    bool jFREgzQpIdT = true;
    int iFMDRw = 2040920003;

    if (cRWTKggA == 612534.585096404) {
        for (int loWULosuY = 1461403374; loWULosuY > 0; loWULosuY--) {
            cRWTKggA = cRWTKggA;
        }
    }
}

bool Fmmiutyz::SySFxNNgR(string qhfmcGxwTlT, double xlAgffeuTssQtuK, int CcXXRB)
{
    double zmiyakRzmYt = 347143.44009274757;
    int SEbAaIDZDX = 1196576313;
    int YaReLJGNzNAQ = 750247935;
    bool TSDkwaHkSxQlwIZ = true;
    string SHwITTmXgCuIXkl = string("IzFTehrtRwykicNxJIaMkAigaICoTjgaNmSjcjqjTwGegigOEnMJXXvAfTurSwWshLtaSWsOKLcXQLdXLGwIjTnwIrqvedDWzXiJfHcKYAsQbKUrmCOZvtYZaYgJNLffOufoGWGudYwIhjlXGZouOchOCbuXBqluBPfCfGiYyGGtgEnHgjkbhBunuWuPGgoSejjyxLBgjJSvFyehBpVYtGXziVkkdkvxiY");
    string GCPfDIwity = string("sVGHukrNJpmBleyAyhTbhPlhTLmxdGY");
    int oxbvyXYJKisOwavB = 1809026332;
    string lEZbRplM = string("kLiemrGbOPAAdJNMrvVtMHvtFyvhdpCxvHqttgnrWLeocutzkynDKyaUvXcmmuBOSNVgNwfQAeMMqMCCaTfxmwOTAZRTOUkPLdasheYqKLQYmawAlsplaiMXPaMXaXjzavCIhlqiMSwoupdCKiUwtSlgkIcgiIzBFWRiQPDkTTRmEjnFVV");
    int qEgZEYjd = 1265765734;

    if (lEZbRplM >= string("kLiemrGbOPAAdJNMrvVtMHvtFyvhdpCxvHqttgnrWLeocutzkynDKyaUvXcmmuBOSNVgNwfQAeMMqMCCaTfxmwOTAZRTOUkPLdasheYqKLQYmawAlsplaiMXPaMXaXjzavCIhlqiMSwoupdCKiUwtSlgkIcgiIzBFWRiQPDkTTRmEjnFVV")) {
        for (int OjsWNuVn = 779229952; OjsWNuVn > 0; OjsWNuVn--) {
            oxbvyXYJKisOwavB = SEbAaIDZDX;
            lEZbRplM += lEZbRplM;
            CcXXRB += SEbAaIDZDX;
            oxbvyXYJKisOwavB += CcXXRB;
        }
    }

    return TSDkwaHkSxQlwIZ;
}

int Fmmiutyz::CHQlrgylwXLglSlc(double uNZEZdxP, bool vvxYCWkjAWhQrXVd, bool hEPUow, int pOxEaixktx, int DWWfbWnXgmsuAY)
{
    bool EjnHsYAIL = false;
    int TRbraVzZbma = 1536990602;
    bool nJwmpcM = false;
    bool Yiulkp = true;
    string SlShgQiS = string("jkCtXzQBRofvuuWKwYJbxugcYqarGEhxssWxwfFSAGFQPIVGcmrmLPZdTbFXoXfeFq");

    if (Yiulkp != false) {
        for (int vulaMJkoJfXut = 1661256311; vulaMJkoJfXut > 0; vulaMJkoJfXut--) {
            pOxEaixktx *= TRbraVzZbma;
            TRbraVzZbma -= TRbraVzZbma;
            hEPUow = hEPUow;
        }
    }

    return TRbraVzZbma;
}

void Fmmiutyz::BKgNwD(double TftsS, bool uCMoiMHtn, double VgIHWDNS)
{
    double bdrxtpL = -788475.6298997941;
    string fyxHBQJnQpWCsL = string("PEiWPIqVDVStAGHqfjXrgViclEbraHexnmARUXGtHPcwtVZtZdQgrjrWPQBavYuHUxCZxfMqAfVswFnIKZccghDFx");
    bool vHzxlduqchOT = false;

    for (int AIKHujHUtLMOTj = 684919062; AIKHujHUtLMOTj > 0; AIKHujHUtLMOTj--) {
        VgIHWDNS /= VgIHWDNS;
    }

    for (int hHfuhcDRBwWVLNK = 1647960963; hHfuhcDRBwWVLNK > 0; hHfuhcDRBwWVLNK--) {
        VgIHWDNS -= VgIHWDNS;
        fyxHBQJnQpWCsL = fyxHBQJnQpWCsL;
        vHzxlduqchOT = ! uCMoiMHtn;
    }

    if (vHzxlduqchOT == true) {
        for (int pAzVKeJCFaxsLP = 1321253095; pAzVKeJCFaxsLP > 0; pAzVKeJCFaxsLP--) {
            uCMoiMHtn = ! uCMoiMHtn;
            VgIHWDNS += bdrxtpL;
        }
    }

    for (int lfiYOeIME = 49531025; lfiYOeIME > 0; lfiYOeIME--) {
        uCMoiMHtn = vHzxlduqchOT;
        VgIHWDNS = VgIHWDNS;
        TftsS = VgIHWDNS;
        TftsS += TftsS;
    }
}

string Fmmiutyz::eGMBk(double rRVOtjejkPC, string MAikrtUriK, int Hteek, double UBsUVdaVtA)
{
    double HcrAtACLKsbLWBjd = -833737.4723385121;
    double ePhIkMZN = 839023.9884303396;
    double ryvzLXOlHMczvbk = 337465.1641884174;
    int vlXvnXdGlbh = -1830984735;
    string SUcnaDvyBMHL = string("mMUevdZWMQMiEYIGfKWKDlWBZsLFDstdUhAHkjOCfdlJRuKcyTzQCxSZXrpgZqNEMdAnIKVJkPILLImTCVgyUAoiZjamUeVLWhsjSZe");

    return SUcnaDvyBMHL;
}

int Fmmiutyz::AwtKTNfKg(int OBjOpxUMM, double sLMgclWrT, string rZQWKZuvoxkB, int KoJNCT, int HGYuqwD)
{
    string tiFjtjSKjQhcSx = string("yNHjjcAyZfGHahffFLHQgXXhPKjqgsTbexMIYDmMfthKhUsPTouYbNlhhUjQqsNyIsBonlSetUjzpjjqBNXXIEfTGPQEzhOkndyngbePntIKBQWiHsAgHfaouWgpoPlIKFFeoZUlLTHUOkILxJBNDWrtTPMkipQoCXfZEmMlNquvhlewNTfXdSocFjjqPeGsfohbxpqCZfAFFRZnpxdPU");
    int KQlHdPyBZ = -300268836;
    string tHGuKbMagOLe = string("hEGPIyyqhDPyOmnkbGqwVPBuXtUpDyzsSXqOzyyXWFWUOMTwHPMvgMLRbHMrKcZQlppyfusQeDbFRgXQxXGphvTkSNSVJPGPNYQfiUhBEbAycaGGVhuMpdpvOwDZCsKnHnoRohIhDeMKfnNomUttRHKCgUsrdaXVbOHrcZsUhfplmchzIRiJeormdcAyjyJZYyIxGKMGFbsNVojBrTcGUBrCKezEeMsMbJWhDaNMAgguVNvyDFjr");
    bool NgohVHNmBT = false;
    string sAGVP = string("qyEozYUSzUrDkaFfkKozAtIlvNpNHldCWXbqAgeeephBXxLmteXQhDCDwXlrBrvnTYGbPycjjbAnPmFokffXzgCrahyibJSaqtgyfWuVSzRMLPPVZNCgNvTbLMYynmxidOHVDQvbDKYICKlirsLwjbInrLssEPYGsdbuYKccvBncwUGGgFPTRviuSMGAVmJZXkVOmTQZggQrqlvbNOzfjSmjIXqYvkxCEJdNxtDUClWpv");

    return KQlHdPyBZ;
}

bool Fmmiutyz::obrTpO(string oUEnYsRgNpNltcm, string CSvEjSedh, bool wWaxUvaFuOi, double VxYlF)
{
    double dBumuzcTOUx = -616805.3989928848;
    double GtCEWB = 583956.3585494491;

    if (VxYlF >= 583956.3585494491) {
        for (int dIMgnq = 1133062914; dIMgnq > 0; dIMgnq--) {
            dBumuzcTOUx += GtCEWB;
            GtCEWB = dBumuzcTOUx;
            GtCEWB /= GtCEWB;
        }
    }

    if (CSvEjSedh == string("uHriVUwaBuLeRYCBLnyvgJPpTppOAjCTKeAFKLryqrakKMtBjjueNVEcKMqiBTWFJqMTaGmBPyezItwLEOerfMzDgRXQGHgCLudBCGkiqMpcXYKIChHapzIGsVmMpPtFCmxRMzZfUnmETJClwnrjMVppPkEEGV")) {
        for (int KBWcGo = 651308747; KBWcGo > 0; KBWcGo--) {
            dBumuzcTOUx = VxYlF;
        }
    }

    return wWaxUvaFuOi;
}

string Fmmiutyz::QTZYqFzChEAqQPML()
{
    int tLHKYkkP = -1914923787;
    int GPRHKVpUHHEAifB = -1997774054;

    if (GPRHKVpUHHEAifB <= -1997774054) {
        for (int Pyisn = 1863798113; Pyisn > 0; Pyisn--) {
            tLHKYkkP /= tLHKYkkP;
            GPRHKVpUHHEAifB = tLHKYkkP;
            GPRHKVpUHHEAifB += GPRHKVpUHHEAifB;
            GPRHKVpUHHEAifB /= tLHKYkkP;
            tLHKYkkP *= tLHKYkkP;
            GPRHKVpUHHEAifB /= tLHKYkkP;
            GPRHKVpUHHEAifB -= tLHKYkkP;
            tLHKYkkP = tLHKYkkP;
            GPRHKVpUHHEAifB = tLHKYkkP;
        }
    }

    if (GPRHKVpUHHEAifB >= -1914923787) {
        for (int JJmtiwZHJSIxF = 1613560818; JJmtiwZHJSIxF > 0; JJmtiwZHJSIxF--) {
            tLHKYkkP += tLHKYkkP;
            tLHKYkkP = tLHKYkkP;
            tLHKYkkP += tLHKYkkP;
            tLHKYkkP = GPRHKVpUHHEAifB;
            tLHKYkkP += tLHKYkkP;
            tLHKYkkP /= GPRHKVpUHHEAifB;
            GPRHKVpUHHEAifB = tLHKYkkP;
            GPRHKVpUHHEAifB /= GPRHKVpUHHEAifB;
            GPRHKVpUHHEAifB /= GPRHKVpUHHEAifB;
        }
    }

    return string("NUFsCqJWZcsAIdhahJWFisMGEPIUqnjNvSBNqEeQYzVqLlIGGNKfqKTYmPYIkxjltSzcXBQfabJAoqfvyddmWckZGDIsDYHDSvHfEbvedhDfIIDhCVsdzpgjOWYjfIzsLdkRtJaKOLyOJMnQkmGPQqnebHcXoBdINbjh");
}

void Fmmiutyz::qtWUhs(bool oqnaOsf, double KZEjLJEWPUyr, int izZug, string SiTuIxpQCIRNy, string CyjycONR)
{
    double zfGiMP = 764553.5901231016;
    int SFsIDseVjjyks = -1547266072;
    int uiowlzxzPoorkp = -920631775;
    bool hFUIzKEKovz = false;
    double YRCJmO = -30345.920520125233;
    double kpyccftMuhyyg = -427819.97902515094;
}

bool Fmmiutyz::PjRuxBFGoxAD(double ESixKf, string Uqqoc, string CQhrf, string KTofo, double bLbFETHPXvbiLsZ)
{
    double LMAYhmJgMkxkj = -1013145.5702983425;
    int bgZEoLrhTlf = -1252929894;

    if (CQhrf > string("LZSsOzQyDqJvWjxIkBdwuxZaEqkPohTiLSVSYIuZbTjetdIoOYOJonyLzjsrMZDEUOjVnDJwpRjzFXhXgLb")) {
        for (int YWDEdCA = 1531689615; YWDEdCA > 0; YWDEdCA--) {
            Uqqoc = CQhrf;
            CQhrf = KTofo;
            LMAYhmJgMkxkj += ESixKf;
        }
    }

    for (int lYQycyOnvCBZfYx = 1366420603; lYQycyOnvCBZfYx > 0; lYQycyOnvCBZfYx--) {
        Uqqoc = Uqqoc;
        CQhrf += CQhrf;
    }

    for (int TkHtgZBi = 1849875857; TkHtgZBi > 0; TkHtgZBi--) {
        KTofo = KTofo;
    }

    if (LMAYhmJgMkxkj < 416123.3159662345) {
        for (int eIQHdCZbgrHpZPpX = 453559414; eIQHdCZbgrHpZPpX > 0; eIQHdCZbgrHpZPpX--) {
            continue;
        }
    }

    return true;
}

bool Fmmiutyz::pwMoWcrgfOnFzKoD(double bTsGgVZYJeCE, string blbMONfyymhP, int ZLHwAmiNoHuYWITb)
{
    string iyISl = string("IpBWoZHTlAMbImJ");
    int XEUeNGI = -316294322;
    bool vYcSdF = true;
    string XjuyORYcPycyZh = string("TFeNwmHSaqHtRsRsVJKxEgKaSkeSUjliIxnbJQlwOeplVqa");
    bool cdgbPBXXvFABsnEK = true;
    bool FbRmBzfiNlMTa = false;

    for (int PzPGJcnZ = 1735957277; PzPGJcnZ > 0; PzPGJcnZ--) {
        continue;
    }

    return FbRmBzfiNlMTa;
}

bool Fmmiutyz::zVuSPGDOQKDQvOtL()
{
    double LBSJdtj = 652049.7962785863;
    int lmGSEjTu = 1058392963;
    int EFcjuQtxjqN = -2131302261;
    double OEfOjLwIWc = -6577.175884607909;
    string AlNlcAsQktFfCXG = string("txzZCRGvMKCGdWvezOYaLBfYoUtmkgqKHUYTsDpDRPUYnYAbWisDKdcGkjoVYAQgHndtrcBXLPtrLFUOtGaLcFuajHLnBvgeEibLjwHKCNLCFhmWYEZUV");
    string jXmyTwIdIGvipy = string("FAiCBOaGCyCehxbDgGjUMplYEQdsAQDQUeHcWfTKBxbjjLECIivzOdulBltkvYRztkTIFaetZoPpHBBypXqjJVjTauivLpgtsqPfsNVktQtuKjgUAwBhaQgQvBsmiwgMSi");
    bool JkWFakKjvWqOR = false;
    int ugpVAIwXsZycwFv = -472335416;
    int vZmZQb = -2072590631;

    return JkWFakKjvWqOR;
}

void Fmmiutyz::kzSwmgEWygEz(bool KHFhHWfuVvvWvS, bool eUGQuBZi, bool jfoQFVPhjDJNbvO, string vFqCST, int YTruvArBPXDN)
{
    string wVZJJAW = string("LCtuTUDGGfcsjTolEJeQvQiTWytQRQnICyntoDsMIYFxYSXyvOBVKShQfJrReZxxCntLvcOWFFcOHFRqJFvwbVSuxqIhLENwvdIgJWlSEigpxOplIwGqbtWbrwncRJIHjQaFuUoQwFdixPQWzEWaVbThxdRJGGauFEjycXantGNteHSnbOJAONKKAyoJXRGVVqBlMKtmAz");
    int eWrosxllNMWPEZ = -636479065;
    double eXGWZXW = 711923.1079237288;
    bool xMEcxaJ = false;
    int wEGYIeQUb = 1139498426;
    int tAaJhLU = -458052918;
    double sLxMbdAQOuYYMWT = -107897.26895074539;
    int TsUfLAo = -392629393;
    double agZbP = -290202.29648992914;
    int aLybKfZW = -1890473979;

    for (int WdoRycXrmfQCHHNw = 1480847861; WdoRycXrmfQCHHNw > 0; WdoRycXrmfQCHHNw--) {
        continue;
    }

    for (int vIpHVBqs = 1031549582; vIpHVBqs > 0; vIpHVBqs--) {
        tAaJhLU = tAaJhLU;
        KHFhHWfuVvvWvS = ! jfoQFVPhjDJNbvO;
        TsUfLAo -= YTruvArBPXDN;
        tAaJhLU = aLybKfZW;
    }

    for (int DxiaQx = 883972148; DxiaQx > 0; DxiaQx--) {
        eWrosxllNMWPEZ -= TsUfLAo;
        KHFhHWfuVvvWvS = ! KHFhHWfuVvvWvS;
    }

    if (TsUfLAo == -1890473979) {
        for (int lFLUPHnqZxCmo = 1627019410; lFLUPHnqZxCmo > 0; lFLUPHnqZxCmo--) {
            sLxMbdAQOuYYMWT /= eXGWZXW;
        }
    }
}

void Fmmiutyz::vYRKexeYvlbZyx(bool oZNdaSMrC, bool uOnwBQQOlu)
{
    bool ebAGaeZCUBYr = false;
    bool dRYNVDXKuqlCIka = true;
    bool alDAhAvNIb = true;
    double OGltHB = 882971.8041739125;
    string ApvLMJAIpUhy = string("ntuWfTbWfXHJSxcxvwjCTJwTXySCzOQtAOzuTaHdGWkwmHxfeVpUngsIKOLBgAAwzBgdneeDxorxjdLGIMGyWcLpZAtSPhPqIMsYPIcJiYqDdQYdVnydaQNZOpfMQvCibWyLam");
    int MqgtZyxCa = 1104612535;
    double jDBLaHzL = 376694.87567155383;
    double WxpQtkvYPxFjktW = 986755.1867449522;
    int gEjRRoU = -1905098060;
    double mpzKMZD = -589020.3247168949;
}

string Fmmiutyz::ezvTPskZVQHBRAP(bool rSbhkEBCv, double qBOnT, string TUlnc)
{
    double KMQLwvb = 469754.208678243;
    bool drYumMjI = false;
    double yHKLkxuNaiguJfRH = -828438.4460414987;
    bool UdecXqBctjqV = true;
    double fAEUuY = 427226.85235871054;

    if (UdecXqBctjqV == false) {
        for (int zFjXceaREPnZHB = 524103701; zFjXceaREPnZHB > 0; zFjXceaREPnZHB--) {
            qBOnT = qBOnT;
            UdecXqBctjqV = ! UdecXqBctjqV;
            drYumMjI = drYumMjI;
            KMQLwvb += qBOnT;
        }
    }

    for (int jHZChKWPqCoqWjzz = 3354584; jHZChKWPqCoqWjzz > 0; jHZChKWPqCoqWjzz--) {
        fAEUuY *= KMQLwvb;
        KMQLwvb /= qBOnT;
    }

    if (drYumMjI != false) {
        for (int jZMYTo = 1968861353; jZMYTo > 0; jZMYTo--) {
            qBOnT *= fAEUuY;
            UdecXqBctjqV = rSbhkEBCv;
            qBOnT -= KMQLwvb;
        }
    }

    return TUlnc;
}

bool Fmmiutyz::eXMJpbRxhCi(string jWbnaAo, string MmGWVrffFdUyV)
{
    int KHDAtdYhjIwS = -1988735294;
    string oLrZpS = string("ozYWpmCbhXTAjrIsMMdGxPrTwdtGPtFTRloFZhRRbSqzIjwl");
    double PlQAzKXz = 142580.3475277961;
    int SqvdPJvTdQDvGJNS = -892586904;

    for (int ntXKS = 798444094; ntXKS > 0; ntXKS--) {
        MmGWVrffFdUyV += jWbnaAo;
        jWbnaAo += MmGWVrffFdUyV;
    }

    if (oLrZpS == string("ozYWpmCbhXTAjrIsMMdGxPrTwdtGPtFTRloFZhRRbSqzIjwl")) {
        for (int kBjTF = 661683397; kBjTF > 0; kBjTF--) {
            KHDAtdYhjIwS *= KHDAtdYhjIwS;
        }
    }

    return true;
}

double Fmmiutyz::dnEpv(int jEsJGmOP, bool yRByFsBdmUzmQ, bool MaEUZcgKwTl, int BopsfukmNLTeffs)
{
    double IkMiY = 586452.6544536164;
    string gFGZCeYNPUC = string("ROoqefzHNjusqQHAIaCIAJbXlOMwMkINqcsAYnATbcnXGysTUvBjQZfmXjxyjaUmTLKmbfAMOyBnqZfvwHMRDyXDaLRFxcSpglNEoEqrDrVocRnNuYdugzmMMlKpXlldPJcywtDySkZREWaFaFvVXKpRDOYMxogGRocaIBoT");
    string mmFbWpRPfVOtpO = string("rZpCCelvlgNnykMpBWlhyIjYKNDPyCQiZBKvzYg");
    bool zgWOzooqzVdSs = true;
    double ItOlqXoayfLaixn = -145668.04428142591;
    bool QgMrLpICW = true;
    string pcPoE = string("mjsPXJjRfwDhJaxoLNSCAosgLKkvPeXmjatbyyxZXGcnkpVWWhXhddAfrXoBfqRedTIFdBhAZsotGBZKKthZJJjUAsiDtwBYkdWcHJUBlzNOpRtdyOKkiMnOmYHmheHBHxUGvDcmLbTPlLMzUHGrsjsJYrlnFkLRmLNjQfhaaaZTVFXTvZLURClKXSidfWYKwHTBbWIKJXbtKjibxNWtiUGCRODqPwXdaCvwrPUtAYlsojqwnZBhbKcCtBhugz");
    string OuotsSANIswo = string("LgKFmIuYvSzdeVvWbcesQmMGbTwFtUfcAUzgCRdKVsBYgAdXsDhpbOBLxnLbLOcyHwgIZizkFeBpjgKUuYdFjqgyeIyFsRzsaqnGuLVPJjYjEfVbKwetoDzxLieXZEgMbOgcEEIkfOTA");
    int rnEwg = -1062112895;
    int RMKNFcuKBYzF = -919605678;

    for (int yfHCY = 1660811188; yfHCY > 0; yfHCY--) {
        QgMrLpICW = ! zgWOzooqzVdSs;
    }

    for (int tBFNjGbkpk = 1192559866; tBFNjGbkpk > 0; tBFNjGbkpk--) {
        rnEwg = rnEwg;
        zgWOzooqzVdSs = ! QgMrLpICW;
        gFGZCeYNPUC += OuotsSANIswo;
    }

    for (int OHDegOIwE = 1644943417; OHDegOIwE > 0; OHDegOIwE--) {
        gFGZCeYNPUC = mmFbWpRPfVOtpO;
        pcPoE += mmFbWpRPfVOtpO;
        MaEUZcgKwTl = MaEUZcgKwTl;
    }

    if (RMKNFcuKBYzF <= -919605678) {
        for (int ShaXo = 1521131003; ShaXo > 0; ShaXo--) {
            QgMrLpICW = yRByFsBdmUzmQ;
        }
    }

    if (BopsfukmNLTeffs >= -1062112895) {
        for (int EpgMEi = 1686218703; EpgMEi > 0; EpgMEi--) {
            rnEwg -= jEsJGmOP;
            pcPoE += mmFbWpRPfVOtpO;
            IkMiY -= IkMiY;
        }
    }

    return ItOlqXoayfLaixn;
}

bool Fmmiutyz::gepPkdGQ(string yCQaWXpsmX, bool utzsT, double zViRUvwox)
{
    double jTLSmgc = 389024.89584143786;
    string MrrLhd = string("lbaFWKLmczttxXEzuXYqZvjhykciLUjBfMOVINvKCjhKIyaQKgOilXHavybYnXXGLjjCawxkawdzhsTKlKbsmRKkqNlfNIGjOetubAVAcwvAJZAGsSiwYReYFROTpdLyxHENuNjDDeXWfjmSwhxcZebvlwAmYnooJvKIINmxrSLpJNGPpOJIBTDSGulMHWVKFhdJACKjdlacKBGbcAgGzTwWBoxUzODStsvJpMSNZHl");
    bool jjGRCPaJsROd = true;
    int zeQMzVPa = -76061950;
    bool ZxwGWurE = false;
    bool lsOdfaiqHbf = true;
    int uTTzUDPyXlcDbvak = -1599625356;
    int QIItvB = 130940417;

    if (ZxwGWurE != true) {
        for (int HHXFs = 661128496; HHXFs > 0; HHXFs--) {
            zViRUvwox = jTLSmgc;
        }
    }

    for (int jeDRMy = 909823117; jeDRMy > 0; jeDRMy--) {
        uTTzUDPyXlcDbvak /= uTTzUDPyXlcDbvak;
        jTLSmgc /= zViRUvwox;
    }

    return lsOdfaiqHbf;
}

int Fmmiutyz::ZilVdxdH(int cXwoiZA, double hJdxmoFMmyv, bool PNJGxpWZjmxymII, double PXvRvwNbqXpEkOQb, double bTspp)
{
    int hOiQcsNJw = 1828086688;
    string alLSMgbshhdAY = string("ncXUCaWrQHbaLuNovJNGsiwUAaAteUNLeJaFQprTAbDkCwwYGoQQIGikZrmfsFcNefQRkSpUVbhchURUFoygqBuGfHbZRQsvZRmSNamnSmjAPkKHxFdM");
    double VxeFpsyCyAVApw = 867765.8162166479;
    int fTbDmjPxQHKnIEzL = 1746302900;

    if (alLSMgbshhdAY < string("ncXUCaWrQHbaLuNovJNGsiwUAaAteUNLeJaFQprTAbDkCwwYGoQQIGikZrmfsFcNefQRkSpUVbhchURUFoygqBuGfHbZRQsvZRmSNamnSmjAPkKHxFdM")) {
        for (int qhcmpFnJYeaXzMln = 1733828625; qhcmpFnJYeaXzMln > 0; qhcmpFnJYeaXzMln--) {
            hOiQcsNJw *= cXwoiZA;
            VxeFpsyCyAVApw /= VxeFpsyCyAVApw;
        }
    }

    if (hJdxmoFMmyv != 747306.902520074) {
        for (int Rrxqu = 1578990203; Rrxqu > 0; Rrxqu--) {
            PNJGxpWZjmxymII = ! PNJGxpWZjmxymII;
            VxeFpsyCyAVApw -= bTspp;
        }
    }

    return fTbDmjPxQHKnIEzL;
}

string Fmmiutyz::OqqNHkGFKVOFOBT(double OAjSeRMBlMMzYU, bool bNyJPTFhbcJM, int ZgYQoGmuiB)
{
    string JhXONAQeqMsln = string("KTFEkxBWPlVzyOIdeSuOkXzuJ");
    int ChSyVKp = -342242934;
    bool dYPddPHdyIQdE = false;
    int vaUAtrBUmpIRKTQ = -1610245672;
    int oodIPmJeFCcGd = 1114666908;
    double APZTRvs = 481359.13972509984;
    double imhMHXFREHwDcL = 587108.9381651412;

    for (int mLasVhzOsXdvWQBX = 1147300252; mLasVhzOsXdvWQBX > 0; mLasVhzOsXdvWQBX--) {
        APZTRvs *= OAjSeRMBlMMzYU;
        oodIPmJeFCcGd *= vaUAtrBUmpIRKTQ;
        ChSyVKp += oodIPmJeFCcGd;
        bNyJPTFhbcJM = ! dYPddPHdyIQdE;
    }

    for (int QxMcXfyifPMFb = 1322107244; QxMcXfyifPMFb > 0; QxMcXfyifPMFb--) {
        ZgYQoGmuiB -= ChSyVKp;
        imhMHXFREHwDcL = imhMHXFREHwDcL;
        bNyJPTFhbcJM = ! bNyJPTFhbcJM;
        ZgYQoGmuiB = ZgYQoGmuiB;
        OAjSeRMBlMMzYU += APZTRvs;
    }

    if (ZgYQoGmuiB == -1610245672) {
        for (int miLlFa = 1047996536; miLlFa > 0; miLlFa--) {
            continue;
        }
    }

    for (int EtVAKJFZ = 65985079; EtVAKJFZ > 0; EtVAKJFZ--) {
        bNyJPTFhbcJM = ! bNyJPTFhbcJM;
    }

    return JhXONAQeqMsln;
}

string Fmmiutyz::gOMrygiiets(bool ECvvWyCHHsRGdh, int cdKBendVmgCqGjC, string YbGmCWQivjOiWR, string IIsvc)
{
    string OceAhoUvlIxLVYED = string("RuGBqymBoelWXZoIyUfKtdOZmdwSsTQqxTgnRkLmiKDjNwuamyFpLvJuZUOEWAMNkjfCRAJpTLcUPVkfCDnYfZrBkfctyNvERnGkRGpiJpAxqlasXDzQwffymFMnPBIcdTMzrTHPferWGyHGVhWjlwMbYyjlcmisoAENNvx");
    double JurslHou = 101617.29136886889;
    string GZUexCS = string("nnzZC");
    int xbWrkrGnVHrE = 1328256936;
    double cgnFImIsGBmjkK = 1013784.1469111281;

    for (int AwtGjnyMy = 1290461548; AwtGjnyMy > 0; AwtGjnyMy--) {
        continue;
    }

    for (int QOIxKX = 1437231879; QOIxKX > 0; QOIxKX--) {
        xbWrkrGnVHrE = xbWrkrGnVHrE;
    }

    for (int FcfrkBvwLj = 1232972428; FcfrkBvwLj > 0; FcfrkBvwLj--) {
        continue;
    }

    return GZUexCS;
}

void Fmmiutyz::yhsNfHNLpFkk(bool GCBTxSdjF, bool YSsXsQ, double FWySjxQstPkdkI, bool gkvfyDMqFxIxDKSP, string PTkKppltDsuu)
{
    double XvefvPyBCyAu = 228714.89553252765;
    double OuBBOaat = 560076.1694798071;

    if (XvefvPyBCyAu > 187628.2316704807) {
        for (int EzfXopOKIKAm = 1036181712; EzfXopOKIKAm > 0; EzfXopOKIKAm--) {
            continue;
        }
    }
}

Fmmiutyz::Fmmiutyz()
{
    this->prBqjJgG(-4144990, -261343591);
    this->pFkmrdHFlcrW(string("bVwtdddDtLpXDyySnppyoZViClBQzyZnrbbktCJCTbVyiIAxRCpiRqdccHmYYrDWimSVbRTRjkGBuwOfygOVUlShmTboqNoIhfNGfqUoJmxpeBmSbzLxZjzzdohzTDQtbbOBpfmDeVaVqGwyAUUHaNcsJSPAxXDymz"));
    this->jooFVYS(612534.585096404, string("IzCSfejQwajsKaDVVJEGTwEwqzMNmRTtGxZlHlqVpOOFdpSfEzlZEWFiiCwMaEdPPZPpfbpQBMfkMgHAPNgDaXvKGthjKCKKobbmXyoNTpOTNvCvipbKUABtmhwGIiwKVcTuNkNdciRzPzcAyuxYqcvwpKcUVtLLqfSwYkqVJJBpkPQtXmgliTlVaqBRPGrgOHAiunyhhpyStOLITLyEpEByBvTVSGopVXynnVDxDCrwFAgNsoxCNg"), false);
    this->SySFxNNgR(string("EkxsTCThHCIgDpXfMAqLESSTDYZmPHMhljrytdwqXHeJgHTlVPdPBuXJuHBIVAdQU"), 994437.025906585, -398265634);
    this->CHQlrgylwXLglSlc(626549.0459289198, false, false, 47412275, -627524122);
    this->BKgNwD(-946938.2361015974, true, -808466.3474375398);
    this->eGMBk(785208.8129874477, string("LinuWUjLzbSuBIvOXZqsILCHQmMvetsVRIJNlMEkandaDxblYmZmESAjNsTjZTyhTlbZacyvCdewpyiOSCWGkTCNeGmDWfWCoBxAuLOecYUEsqcWujlCpTQalybKZ"), -1641236212, 172428.36016145404);
    this->AwtKTNfKg(-595079224, -991349.6640912755, string("qeWWpVtyJAEnbaQiKdBMVNqXyVEGadIgvAIRSxfWjTegvJUoWEePGeKinGcOExreLEIBfJkIONuuwXfwkNUhadxqNUzSNiURgfyuUTQfd"), 376053907, -743572016);
    this->obrTpO(string("uHriVUwaBuLeRYCBLnyvgJPpTppOAjCTKeAFKLryqrakKMtBjjueNVEcKMqiBTWFJqMTaGmBPyezItwLEOerfMzDgRXQGHgCLudBCGkiqMpcXYKIChHapzIGsVmMpPtFCmxRMzZfUnmETJClwnrjMVppPkEEGV"), string("eeTOpgFMxSyDUJRfzf"), true, 580448.1325236951);
    this->QTZYqFzChEAqQPML();
    this->qtWUhs(true, 351955.30906197196, -1222622418, string("EsnjhVreXaxDFUEQtTjPdHJUfrDYtRUxjTWkuPFChEDzBqlJPsdgFOHJBdMnyjTLmOwcqgSZYzFJsdnUJehPijicqGBuQprFbztKurSEdMbLqXrmHEfraycqDCpysoQHtBsNMPsRMyquhCMNjFcIoWXmEBDRfPRaURpmHVDliGRlyxmxOntUULRXNyNUcNpYzNnDeNEIevtwYnxUnpubKIDetPbrRCmLBclkvaMCOzX"), string("Xsxmc"));
    this->PjRuxBFGoxAD(58554.59564545988, string("mMoyLOQHfMvIFXWwPgWKHCWsdyhWGKpLuzdWxDALSQlDAXLwLIEdZjBpwtgREEMREtkqucVYxPrApWyudUfuPfaWHpFEbYWRmQUSspxADLEaqklCInkJY"), string("VzuhYKxHxhYfJSGQxlgQQallIHXRmqtgqKwnwhZOnhFez"), string("LZSsOzQyDqJvWjxIkBdwuxZaEqkPohTiLSVSYIuZbTjetdIoOYOJonyLzjsrMZDEUOjVnDJwpRjzFXhXgLb"), 416123.3159662345);
    this->pwMoWcrgfOnFzKoD(-750542.8652065909, string("AxTrqNBFwvuxxmcFvMweloZlXglFFWLfQkhXzDcVNIpDqFtmpEjECEbvNkAFXzppLCjAdLqPfUpLERnlzuUGasVBUxeqrZabmbxCABtwaCCaBIaxSijbmqeY"), -1087557976);
    this->zVuSPGDOQKDQvOtL();
    this->kzSwmgEWygEz(false, true, true, string("tAslbuHCXBfEEuWpHCNMdTWFkXubUOtPkEvRzrguBzkIdDaSOnJuwdDXldZuLrpFpDXTt"), -383357799);
    this->vYRKexeYvlbZyx(false, false);
    this->ezvTPskZVQHBRAP(false, 1034222.5287411683, string("UColcXWfSotywFVLVVWYhhlPrwiRMhzEeyUcgdqOVzdZIdkRVSRlpUhyXqHghHoaQDjeYquPIOWoAYscxLeKngKJrqhCtBOzoOJYJHrLfuZDuVBIyISifJVcgKNrOV"));
    this->eXMJpbRxhCi(string("phUlkUBQBcTTWBJwVaTCRwJPiftRcRCWjszsfMeUnSPMFvPznqHOAUFftdnXlGkFPMpZzmTolnIAlAnfusUhRZJShWaMJTfpwcczAMhsAbDfsXTfIveCcEnyzdBkGRBMwzHiYkVrWFapBWdFPZKujxhwxQunU"), string("EuBSNodutyfZUUAALgDbkctelZAqGPAIkEirXAyAPnNQvNMdDEMGOrhRTDFhvdTNzmyThZrCKZZLcnxkDcbuaTfGxwlXGgPHOcjEtQXTGREVOzTeqxKIvQKrlLdTPnkUxQmgdDUL"));
    this->dnEpv(1869523475, true, false, 1313121988);
    this->gepPkdGQ(string("JmqzdqxuBUgDGPDmrRYvtcCipjXoxEoZEdWCKPahIdcsVhPgpcLuRAGeEufzqIUkNQxhMREhIIuzjLEoaCBWGyaQCpVeVAoIKxqhTAEhPcKLUMaOmhsKcOWUgZfQGvCUSdLinBCXHLRrkxNLliudWZlTRgJazncwIRHhofoASzXYrNxeM"), false, 22877.198551993064);
    this->ZilVdxdH(260122841, 667346.5072712085, false, 560836.7229310803, 747306.902520074);
    this->OqqNHkGFKVOFOBT(-23800.80640158488, false, -1916593081);
    this->gOMrygiiets(false, -110051161, string("aGKtsMABYqgBCnhwViSVeUYmxCXtsSgJDiajBwfjLaKkyaecZpwWhzveUIZgCyddFqXzYNTdxtJgZGNPVDQtrPdszpHZoanpWDTRhcsfXrAswqKWcTuHGRgJNhUTXxZyFHcvUJxqMCWPeFClCfAqABbaz"), string("EvqPHSEwItyeVbrmPBekcpYLTHYKOKSBcAODxVupVSLMNwzyZumSroRpxqgXnNjvHbGkIduRZjXjwoxTTCIcwwTwRWBENlmjWSjyeGPBDrJdQApjHiuoOqmlwRQPNXawwNAGBVmvMQBpSwmEYWkqoJmxANWJXcRHVWgUFWnraKxWQGVfEdTPETCMvjhSLIuhAXwCbUkGisIztIoaFtmcZewePaghunAPqvLrOnHYHISlx"));
    this->yhsNfHNLpFkk(true, false, 187628.2316704807, false, string("JSpVZGBNoASBvHZJlWmWnjeCocSODfqFhDxWdEfKxKvhbmJgoAsZEIxfqcsEXpbHqZpPhhEtddeejXmkJxQFEZSAVLhAuOGwijorePguaLjytqieWohTojFzIeugjhTmxQWMnOSyJOThbgvnZpUqZgyiwIyxplkIXFohvHcwcNGIfpjbIbVUNtsTxWcTewjUVVpxFGFwLykfrbmNrGpLTUYCrAeOweCqIaJ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JVsvmK
{
public:
    string dMEMWXhZfV;
    int RbfUKA;
    int dbGRZw;

    JVsvmK();
    int qrCgdTJSaarv();
protected:
    int zwbTgo;
    int HSWMlHshKgmi;
    string tKdTkOLDibMcIKJ;
    double NZkilwrFg;

    string ykknA(bool ySVfwqmk, bool ibxytpkvPnPo, bool qfVedwg, double uXEPBkh, int zxxaIbCKXgU);
private:
    int YVPsgwTypFBqa;
    bool Qukzw;
    bool uotLYyYkJpOBx;
    string OhmRYkKAImG;
    int CbXZwHOEgKT;

    bool ebznOp(string fhonDlzIvQ, double zLxeVLteQnRv, string BErgqVJZTbiNEf);
};

int JVsvmK::qrCgdTJSaarv()
{
    double IQJOvWystoaRO = 587118.1903282212;
    string ZTiwIyaOixmbXZ = string("COTYBzGJvQRTkfyNkHbRtXdAwizgbpxwzWlKyOIYeTYVvMRBGtqwGcRLrrfbsiqDEeStXoIkRMjvPRkmJyliGewKDbfvvAxwWSkdsAPPBQJaGMtEzffOmudBMJWJiHYARSxFjaJsWVvBWPsTurHyMWLhqHoNehfeGHZvuVqLzxvJvkYmcDzMdHTeqmxfzecOxbiHgNOYvUGfEyhDe");
    string cOzjhxu = string("dEXOiDpAazCmiuGkRQJmPplCgnzdYzgsPoySbAaUaOLdGSdlgqoOKnNDwhJwdolLpbDtymnBLNFCUcbfjbUjnwYvrUMiUZcSBLWIlMoksswNnIXYkwBioQFjeHxljNPEoMdouUBgLNqEolafwQermjxrfQyDgamGIwOndpYpelvRmmvVxrAAeVNMtpmAWLDdqRto");
    int hyHuPgwaWTZs = 1580096698;
    bool YbjCuHoQND = true;

    for (int RmFCuvCDOXjY = 896269435; RmFCuvCDOXjY > 0; RmFCuvCDOXjY--) {
        cOzjhxu = cOzjhxu;
    }

    for (int jvzjRHGveUc = 384564647; jvzjRHGveUc > 0; jvzjRHGveUc--) {
        continue;
    }

    for (int XQAoIgu = 929860996; XQAoIgu > 0; XQAoIgu--) {
        ZTiwIyaOixmbXZ += cOzjhxu;
        YbjCuHoQND = ! YbjCuHoQND;
        cOzjhxu += ZTiwIyaOixmbXZ;
        ZTiwIyaOixmbXZ = cOzjhxu;
        ZTiwIyaOixmbXZ += ZTiwIyaOixmbXZ;
    }

    return hyHuPgwaWTZs;
}

string JVsvmK::ykknA(bool ySVfwqmk, bool ibxytpkvPnPo, bool qfVedwg, double uXEPBkh, int zxxaIbCKXgU)
{
    bool XlXOmOCNUkjeNYB = false;
    bool CpbZosLLVlX = false;
    int UPpeoEs = -790519026;
    bool dhtrKdqagTAdDA = false;

    for (int FJsnCqfz = 444154511; FJsnCqfz > 0; FJsnCqfz--) {
        ibxytpkvPnPo = dhtrKdqagTAdDA;
        CpbZosLLVlX = ! XlXOmOCNUkjeNYB;
    }

    for (int pXjsjPfVJlbNUetR = 525689172; pXjsjPfVJlbNUetR > 0; pXjsjPfVJlbNUetR--) {
        continue;
    }

    if (ySVfwqmk != false) {
        for (int NSCEohtZAcctD = 939723725; NSCEohtZAcctD > 0; NSCEohtZAcctD--) {
            continue;
        }
    }

    if (ibxytpkvPnPo != true) {
        for (int QziVnaRPMHUnuus = 19948117; QziVnaRPMHUnuus > 0; QziVnaRPMHUnuus--) {
            ibxytpkvPnPo = ! dhtrKdqagTAdDA;
            qfVedwg = ibxytpkvPnPo;
            ibxytpkvPnPo = ibxytpkvPnPo;
            ySVfwqmk = ! dhtrKdqagTAdDA;
            qfVedwg = ! qfVedwg;
        }
    }

    return string("uWPEPwREMXDozsXkpMqwLbkZixpvZLZDoAXLKrsnwEaZGcsxiyMJojNtLUrQvMrLbVjMzAtEriQxiTYfXoSnnQdCTplVoLvPGYsKFmvNnOIewrBDVlJqMhQwOKSZeZIdXmjgCDUfiyoNGzPDrJorknoOAWHVtbSroPrOnGduNbHsKTQsIfsREUujMABvAkqlNilOdnRTcYzfWqpRELAGbZ");
}

bool JVsvmK::ebznOp(string fhonDlzIvQ, double zLxeVLteQnRv, string BErgqVJZTbiNEf)
{
    bool kTRvltrZzV = true;
    int ixEiVYUwMTjmS = 409814793;
    bool VZDjonEV = true;
    double DluIw = -605663.3352759959;
    string qpXmdQqYMY = string("bWAtoytIRLqCZkMUaIttTFdYatjPqGGqdYJCTomvjfwTDuNXgfdbpbIGLorVnAJBwwLbDINyJUqUewuzXxjJrkcTezADVRBOqEvCaWgFkIXGPvmdXgLmdXnfpvvVHxkDdytsGrphnEifkBSngnTNvkKPLBCuEiNyMOTQ");
    double GVULcE = -899708.6406987718;
    bool Namfd = false;
    bool PARzvp = true;

    for (int dxsYycFl = 2048515026; dxsYycFl > 0; dxsYycFl--) {
        continue;
    }

    if (Namfd == true) {
        for (int sUONcUn = 228105687; sUONcUn > 0; sUONcUn--) {
            VZDjonEV = ! VZDjonEV;
        }
    }

    for (int yzglwLtnUDaXLp = 1399574942; yzglwLtnUDaXLp > 0; yzglwLtnUDaXLp--) {
        continue;
    }

    for (int XCzrXDhEjCkmamDJ = 49598445; XCzrXDhEjCkmamDJ > 0; XCzrXDhEjCkmamDJ--) {
        continue;
    }

    if (kTRvltrZzV != true) {
        for (int swyFfwM = 298004218; swyFfwM > 0; swyFfwM--) {
            BErgqVJZTbiNEf = qpXmdQqYMY;
        }
    }

    return PARzvp;
}

JVsvmK::JVsvmK()
{
    this->qrCgdTJSaarv();
    this->ykknA(true, true, true, -348508.66116820334, -1030427213);
    this->ebznOp(string("KR"), 478439.1591659526, string("bjuLMWHtTBwbGfGscoUqeQXBJosRUEmHkFpMtqzavhYMDauxgguEpnWPfOzqmktLxomrqu"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZsuAadUVpbrJO
{
public:
    double XTadbse;
    bool BrevqCyCPhQtIpdB;
    double KpXjxVZNbIIsML;

    ZsuAadUVpbrJO();
    int SNRllv(string dPmzhcm, double osiTsgKyaFdel, int CGqKUBKJipvJXGDw);
    string HERNRpKLVwxbv(double dePMvKOXRPUsBH);
    bool WITDJBdSiqZErf();
protected:
    int DwnynqZCFzDY;

private:
    int zbJbc;
    double jVqBFhVp;
    int pvQbCsXhyPBIK;
    string KynGqKV;
    int EPVPNVkNfbFNrURu;
    string pifYSQsLtRX;

    void VjAdBxazPsgx();
    string lbuedAlwWCBo(double KyPzq, double HtGSQglDVPouRUaA, bool efIMXfCDZSwNUG);
    string BlIOVtboClQt(string ZUTuDZaoeRL, int KrQRyMrkhOgPu, int pCoOmpokq, int IkrhJeDOaoCJG);
};

int ZsuAadUVpbrJO::SNRllv(string dPmzhcm, double osiTsgKyaFdel, int CGqKUBKJipvJXGDw)
{
    double ofnjX = 310446.8112493551;
    bool hnDYdufvRaBVIB = true;
    string LQmhKiQl = string("xYYARAAaalquMUxnSkOXfhuPxLRNQmhPcsagEBxGhhxfKOgBNsETkwJUdGqiLXLjxrRJLuUOGTzXmUZVHZDZJQOcUBnhcTpjmKMGxnadTneCjIodOIjqMx");
    int GenToiQWUbLjViL = -254243751;
    int FVBGBTpmeryUcOAE = 942347173;
    int VCccxPTLtE = 1265579069;

    if (LQmhKiQl <= string("xYYARAAaalquMUxnSkOXfhuPxLRNQmhPcsagEBxGhhxfKOgBNsETkwJUdGqiLXLjxrRJLuUOGTzXmUZVHZDZJQOcUBnhcTpjmKMGxnadTneCjIodOIjqMx")) {
        for (int ISNBwxdqovqDk = 990711494; ISNBwxdqovqDk > 0; ISNBwxdqovqDk--) {
            continue;
        }
    }

    if (VCccxPTLtE >= -254243751) {
        for (int sBNig = 2087411684; sBNig > 0; sBNig--) {
            FVBGBTpmeryUcOAE -= CGqKUBKJipvJXGDw;
            osiTsgKyaFdel /= ofnjX;
            hnDYdufvRaBVIB = ! hnDYdufvRaBVIB;
        }
    }

    if (VCccxPTLtE <= 1265579069) {
        for (int jDzyTGBI = 1597625255; jDzyTGBI > 0; jDzyTGBI--) {
            FVBGBTpmeryUcOAE /= FVBGBTpmeryUcOAE;
            FVBGBTpmeryUcOAE -= CGqKUBKJipvJXGDw;
        }
    }

    return VCccxPTLtE;
}

string ZsuAadUVpbrJO::HERNRpKLVwxbv(double dePMvKOXRPUsBH)
{
    string EDkAKJ = string("QfQIjrdzUHZkknVsayLGRCyjYxzCcgQxPRcDhIQXBcpTnVboCpUdlyOAPaHbPnmPrFzfDemGFIEtMtJILsJPCtuRpuJPhGEGgPlvcPcn");
    string pJQXlU = string("DuHDWwTeemzwIXytDWGbUXNYtGGwrYcmsseqsAEKvOJxEKGIiXShdAXsRSOqkfKGJIGdjuKvJRBFUuUCrTrFjnjIRKBnaIGUMNjVSbSBwgiSJbawKIUfpnittgqMNegGAIljLCFsJzitSkktxHUilMmmDwFqfHSVXNWAeQmnXsIrwaCatCGqcxnXTQdvyBLLSxgOsqyMsBxNSKCcDDuzdYuJpyPhYiCgINozvSCrdbZEQEFVNIzRgUs");
    bool uSJFEvWsEm = false;
    string DTbnMrAfzm = string("CorFPiJlXgVpgsLqxz");
    string GzfoaKjfiNDjypTx = string("hbrQoxzPTnAJYfIQuxCcBjMiIAmisYRltpecqETkLOAXgWsRidaJdfUMnDQFJpuLHMQbKCoMgKXyDRHdWvkCWkpzKPjSEuAMFMxHyZzqJSacSZZOIlyZVOaDJKLCWWzgLSORxuAnawIaRtExSDtTKk");
    double cyxOVkuFmFPU = 800184.1739737723;
    bool avUlaEuZAW = false;
    double bAnoXTjQJsRZ = -1035832.9390166373;

    for (int gudpPNGEJtBsSA = 536137071; gudpPNGEJtBsSA > 0; gudpPNGEJtBsSA--) {
        pJQXlU = EDkAKJ;
        pJQXlU = EDkAKJ;
        uSJFEvWsEm = uSJFEvWsEm;
    }

    return GzfoaKjfiNDjypTx;
}

bool ZsuAadUVpbrJO::WITDJBdSiqZErf()
{
    string McBGx = string("yAZhIincnUfJrYBiXWMfsqwKXKSIWLPZeDyTEmMYyxiTqyjwfjmQwUlNvjAKAnZlAFveVilKLcaFTUOEDFOodHuiMmteaLhGFBJUZJHNkWISimMKtJhNPwbbtfaIzMCXIcAtNIkueRSQRNNcGvRmKMPoadnRiqyWuUAleXIXeamcOTwPdYlTQYyOvfdJRkMCIHjSzDRrYQENjlXdSxCNIfsUpiJsxJjZvkVWPMjgvePeamuEawFtG");
    string JICxmYeBIcVVtA = string("LFPZcjzxLoIhUsIFXfzCSgLyzGcmxJVXDgutEwsffskAsQCHOLIdMnClnKNxHcJgGotRcJnqabaqlxYARdMjHzGxaaLluaIWOTyPWtbqiPjpTKHsuQEHCNRDqccasGejXsKevimdVENcNEUvyArizRrmukpwlTUoVGagzCtNrQAtemADVPhBhEC");
    string HQzDdtXit = string("yTiAUCvSjVsLvNORnezMS");
    bool jVGsF = false;
    string zcPAVKAhbP = string("UEyhHYBfE");
    string joFrOSOgsmKbO = string("HMiGFHKhgKMMZLLsuxTqMORJqfLpGuOabNqDinaTuddTkmjUHTEPkABr");
    bool NsKHci = true;

    for (int HZmAs = 916747275; HZmAs > 0; HZmAs--) {
        McBGx += HQzDdtXit;
        JICxmYeBIcVVtA = HQzDdtXit;
        JICxmYeBIcVVtA += JICxmYeBIcVVtA;
        HQzDdtXit = HQzDdtXit;
        McBGx = HQzDdtXit;
    }

    return NsKHci;
}

void ZsuAadUVpbrJO::VjAdBxazPsgx()
{
    bool nrPHJtVbDxWpQF = false;
    bool aXDshOHVWFIMyAu = false;
    bool JjGKYmE = true;
    double RKqNYvOKvXNuNAJp = -831682.7778479452;
    string YVjoVVgRYiyXVV = string("WfhMnDorDkMszrVkaSUnmpEppOXudASdUrWKDyKnxJZAzzZIAKEkPiBSQLGgncIZmgDiEpfMMqqPNFICmFZJdoXxteATTEyZjLeOdSOjjrXijJMHwOkgFcJnOEOMJKvblJLgQINDzCxsvaOFDBvmexfNuSJvKckmUuEPujqJZmEVIHEkhdZFlzycqAEGLSyRPeVSlEdyGAxgQiuezJUEyddpQB");
    bool CKAuW = false;
    bool GKXNsNnAN = true;
    string jKfxmpW = string("iLRcrEuvgyIxlHvUgClhEdzKZwMqNwcDJNOikwmWrGnneyQJMHmpVBMmIvmPxuKsXmdvblzueCOSnRoQUvkrMKEqgIQdITWfPAxdIDRlLMQsWUcQSGdSVKikLTIFWuAdOGhcOKFZsxWERrYmnQcYqRzucSAkfSbeplvvVMF");
    int MGJwbOXyEeD = 843280517;
    double nlxhzLJn = 164892.67692629524;

    if (nlxhzLJn < -831682.7778479452) {
        for (int XrcjRbcAYC = 472670971; XrcjRbcAYC > 0; XrcjRbcAYC--) {
            continue;
        }
    }

    for (int OEsGypEIXinEZRQ = 1122796224; OEsGypEIXinEZRQ > 0; OEsGypEIXinEZRQ--) {
        jKfxmpW = YVjoVVgRYiyXVV;
        GKXNsNnAN = CKAuW;
        aXDshOHVWFIMyAu = ! JjGKYmE;
    }

    for (int UHNyQEV = 246240201; UHNyQEV > 0; UHNyQEV--) {
        CKAuW = CKAuW;
    }

    for (int DMOcJDOmozNcoSI = 489412471; DMOcJDOmozNcoSI > 0; DMOcJDOmozNcoSI--) {
        GKXNsNnAN = nrPHJtVbDxWpQF;
        CKAuW = aXDshOHVWFIMyAu;
        GKXNsNnAN = ! nrPHJtVbDxWpQF;
    }

    if (YVjoVVgRYiyXVV <= string("WfhMnDorDkMszrVkaSUnmpEppOXudASdUrWKDyKnxJZAzzZIAKEkPiBSQLGgncIZmgDiEpfMMqqPNFICmFZJdoXxteATTEyZjLeOdSOjjrXijJMHwOkgFcJnOEOMJKvblJLgQINDzCxsvaOFDBvmexfNuSJvKckmUuEPujqJZmEVIHEkhdZFlzycqAEGLSyRPeVSlEdyGAxgQiuezJUEyddpQB")) {
        for (int hHuQmLDZsl = 217159452; hHuQmLDZsl > 0; hHuQmLDZsl--) {
            continue;
        }
    }
}

string ZsuAadUVpbrJO::lbuedAlwWCBo(double KyPzq, double HtGSQglDVPouRUaA, bool efIMXfCDZSwNUG)
{
    string eRiIlL = string("leMcviFakAFxwHIMowZSPxXLsMQZJkwjchSXDByVVqJmrNEwtmDCEZloaODdpnjGVRIoyXQyROoXCJsoBrjNTmEEBMrOVqLUsIhYthaBQBCBFQhcHNADMfMfVaMYcXOrlqRpiNdgsFTLYxbYcxWHpsvQMlNLDCuCzKPNBGGohseoiMfCUxlAc");
    bool FzuQEze = false;
    int nAxwbkhGwNp = -191985233;

    for (int JeuksiMHaNeJ = 309430287; JeuksiMHaNeJ > 0; JeuksiMHaNeJ--) {
        continue;
    }

    for (int hpsKxL = 1969398096; hpsKxL > 0; hpsKxL--) {
        KyPzq *= KyPzq;
        efIMXfCDZSwNUG = ! FzuQEze;
        FzuQEze = efIMXfCDZSwNUG;
        efIMXfCDZSwNUG = ! FzuQEze;
    }

    if (nAxwbkhGwNp != -191985233) {
        for (int KgoRpEoMYPbnJPhO = 742713890; KgoRpEoMYPbnJPhO > 0; KgoRpEoMYPbnJPhO--) {
            continue;
        }
    }

    return eRiIlL;
}

string ZsuAadUVpbrJO::BlIOVtboClQt(string ZUTuDZaoeRL, int KrQRyMrkhOgPu, int pCoOmpokq, int IkrhJeDOaoCJG)
{
    int ENgoaUzbn = -1585509731;
    double RRXkTwqAZMTJVU = -3649.0090150411597;
    bool bXYCH = false;
    double MCIfsBApbCmHnJJV = 22171.687720550668;
    double OiSfCtzZQ = -483617.96123705636;
    int ISnMLnkxHdOFiOgv = 1890344025;
    bool TYdtpoh = false;
    int vbqkZAN = 761095862;
    string zmSJYhX = string("SbWLsqebHJdADwbOpxSIaGzELTFygfoNCCTqFKnUVXMiwkneIuRmGNwKKHPldqHHTMCvnwWPSPRwuWMgUvTqiufxeLczHQzUoVKEdmZNXaHCHXeLUFSCAErMIQeoHvr");

    for (int OJVpwiA = 1946863795; OJVpwiA > 0; OJVpwiA--) {
        pCoOmpokq /= IkrhJeDOaoCJG;
        vbqkZAN -= ISnMLnkxHdOFiOgv;
        IkrhJeDOaoCJG += ENgoaUzbn;
    }

    if (KrQRyMrkhOgPu < -1907776922) {
        for (int wavzJkXSNOn = 451214757; wavzJkXSNOn > 0; wavzJkXSNOn--) {
            ISnMLnkxHdOFiOgv += vbqkZAN;
            ENgoaUzbn *= pCoOmpokq;
        }
    }

    return zmSJYhX;
}

ZsuAadUVpbrJO::ZsuAadUVpbrJO()
{
    this->SNRllv(string("MzbWzLxuYLpTvNPgfgucTDkoJvmPSuhCTnfRDyryddFzGIcRZcCLvbLDQonuHqpXkYSgTWcODShPhStJONhHWMjvhgmLDnuk"), 74809.4555898025, -1120555112);
    this->HERNRpKLVwxbv(-308068.930518659);
    this->WITDJBdSiqZErf();
    this->VjAdBxazPsgx();
    this->lbuedAlwWCBo(-879622.556933781, -342296.14350008586, true);
    this->BlIOVtboClQt(string("nmIbUcDZLidLhTCcrxOpXtEsuFAbUciOAqCsCjSSgPBNwJxLyUlZkjbeVazMBsFXwwzmyXlgEKYimHUJMVJdAbALJZPSnbzDlqvMRjiNpganPwgafGTLYlNXCDERWSJtNOGvHKYJphkrKUwISgCgCeqTlVwOLhWaugswkXtUDBagRJOqcCaRYeGaNMfyegjayXQSzhflIMgRKSUjnONfoLrxiKHmvRfBoYnxSHqAEcPB"), -1907776922, -2050617355, 1922508505);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IikGTD
{
public:
    string NJfdk;
    string ZArCquzjgSl;
    bool zOhqyinCiwz;
    double BYOJMrXSdZakX;
    int YEdmWhEXOGgyDz;

    IikGTD();
    int zIPPFg(string vdziFLKKoel, bool tZoXKKMIQ, double KsKubvKECS, double PjyRndeoAFsDU, double trMRscW);
    bool NYFJIUPFQvFj(int RxqpFEeZWRSFu, string qcgBQmZc, double TnjFQMuKVuwH);
    void DtPpGH(bool VcTEWKwpCxB);
    bool eqawSzzwxfNtfqLR();
    bool FRSFK(bool BHorR, bool RQxzrS);
    double KaQZPYXxbAQIAaZP(double iTbFykS, bool zAoxsSvqmwGIM, bool MUzZwrwwpxutE, double ONlugDuasaoJNhJe);
    int YRtKzjPyUoBu();
protected:
    double yBLkmmBaovOJMnMM;
    int JJfyuxGCFuACP;
    double KNVdhM;
    int ecwbmEJKujei;
    bool woORoWZDOGEQr;
    bool HlQTmt;

    string iCDDllN(int CDRIf, int lJVQzLB, int EEKEqzQqHoL, bool urOQcpuap, double YpFOmdpchBd);
    bool BqMTLrosPgcpQYO(int bmXYYvylPDJBe, double UnmSGcAkQhbdedBt, int EwGGwep, double QbdDZmJwRyZrVx, string hpUIPhDUwE);
    string lNqNyj(string MCfwLxRwBXcCfD, bool gJRmpJsgtOyHe, string eLbblDUrZ, bool DhcKiCBqX);
    bool FeqNYt(double exbvEsdZA);
private:
    string tmBJsIY;
    string mvJLOlWxGbCV;
    bool SOMbVR;
    double TVVyYNUqpKSeIiQ;

    string IaYGdsr(string pIhAjGGdRWkPL, double PPMasRDdcwAcC, int cvsflzC);
    int YADNOqZRldx();
    int ZNnpMLcqMj(string jTYKvFI, string VijUadvtxa, double vvSbBLpyLI);
    string egcshbxavmBcMe(string oWWhuUxNXejVhQzY, bool LVjGquAubZBi);
    string LZHKr(bool pMTNhNc, double fuKGJeTNcuomP, bool LHulk);
    double pVdDjZCaABmhP(bool LnfKFiWLFbvlc, string QhvbMqYSIba, double EvVaQ, int ReRXSzxtHgJa, bool CPbtoDZlqQBn);
    bool QwoMWovkeAIFBH(string pidDwgqolSXyR);
    bool MymHkWTZfgXZeUoX(string qXjdEzE, double MdgkJ, bool YrNyydOuviKhMki, int zhOyetp, string NoRBnBaiNaXw);
};

int IikGTD::zIPPFg(string vdziFLKKoel, bool tZoXKKMIQ, double KsKubvKECS, double PjyRndeoAFsDU, double trMRscW)
{
    double jHaVwRNGxw = -43429.4722429073;
    int jtKTSGzqldIVG = -809797930;
    bool smVYuasjdjmvVWo = true;
    double RUJGdkP = 633687.2460833455;
    bool ITphReCLsThuxsJ = true;
    double HAfMMrtDTQjQXnl = -237947.88733907504;
    double umosuLoJDiDxZJ = 616404.2448727748;

    if (RUJGdkP <= -237947.88733907504) {
        for (int SGJAXfAgIXwdp = 88422964; SGJAXfAgIXwdp > 0; SGJAXfAgIXwdp--) {
            RUJGdkP += jHaVwRNGxw;
            KsKubvKECS += trMRscW;
            RUJGdkP *= RUJGdkP;
            KsKubvKECS -= KsKubvKECS;
            RUJGdkP /= HAfMMrtDTQjQXnl;
            RUJGdkP = umosuLoJDiDxZJ;
        }
    }

    if (HAfMMrtDTQjQXnl < -437350.45434096595) {
        for (int QcglPhNtT = 791408502; QcglPhNtT > 0; QcglPhNtT--) {
            HAfMMrtDTQjQXnl = umosuLoJDiDxZJ;
        }
    }

    return jtKTSGzqldIVG;
}

bool IikGTD::NYFJIUPFQvFj(int RxqpFEeZWRSFu, string qcgBQmZc, double TnjFQMuKVuwH)
{
    int jNCcBZtJ = 416105644;
    bool XeEeVhl = true;
    bool KXAWsOO = true;
    string vHGUGLvMkgBpm = string("zFTXhgrTmqdJEPiCfBZhjQwlXOVMrdkLMOVjfMTiGbOtCAQwfZjdXrsswzumZBkVBcJFypGecfB");
    string tEkMEuPtzmWo = string("HYqgBagOAtwVdKzWyRSpyZPDpbBIvfzCJIWgYEpUdctJCPKSYjGLEJGLSWVaafeyNSOYXexuKEsPXvsnrMNJEILgMKmMJUNbgnCxncMEXHEUBgzvrekMHxjrFAXnRrVufrEDbOzWlYwkSvnqKUZEvWAcEPVDYhlyrvozzlOADUwOzYuCSkaOTtaVWLYzsCwE");
    string kCnVTn = string("NYJKOTTSMDCFdTHLSkZVDZDRUNEKXjWyJuUYceaRreyRWzsyTtGQEnjbYGpWMOEQycAvDerLmoDGzgHulBXKjNZnqSiPHaqrtZBJXQEnyqTHBuFhXyFNokOSyDKhabiMEwdgobUlFccxLzGAgPYRZNkvYxaBwIBtWWMhAcQEUaQcGoXJHqfp");
    int zbHMjCgtc = 418215348;

    if (RxqpFEeZWRSFu < 416105644) {
        for (int ICGySNeglMlJl = 79970282; ICGySNeglMlJl > 0; ICGySNeglMlJl--) {
            KXAWsOO = XeEeVhl;
            zbHMjCgtc = RxqpFEeZWRSFu;
        }
    }

    for (int Nnugu = 1518063183; Nnugu > 0; Nnugu--) {
        zbHMjCgtc += jNCcBZtJ;
    }

    if (zbHMjCgtc >= 416105644) {
        for (int YhquXIgKCUJ = 1040556380; YhquXIgKCUJ > 0; YhquXIgKCUJ--) {
            continue;
        }
    }

    for (int eENPwJ = 1662414731; eENPwJ > 0; eENPwJ--) {
        vHGUGLvMkgBpm = kCnVTn;
    }

    if (qcgBQmZc < string("NYJKOTTSMDCFdTHLSkZVDZDRUNEKXjWyJuUYceaRreyRWzsyTtGQEnjbYGpWMOEQycAvDerLmoDGzgHulBXKjNZnqSiPHaqrtZBJXQEnyqTHBuFhXyFNokOSyDKhabiMEwdgobUlFccxLzGAgPYRZNkvYxaBwIBtWWMhAcQEUaQcGoXJHqfp")) {
        for (int udFSXoBUsqhJ = 2078673924; udFSXoBUsqhJ > 0; udFSXoBUsqhJ--) {
            vHGUGLvMkgBpm = vHGUGLvMkgBpm;
            zbHMjCgtc *= RxqpFEeZWRSFu;
        }
    }

    for (int uWIgkJILWtp = 682922588; uWIgkJILWtp > 0; uWIgkJILWtp--) {
        jNCcBZtJ -= jNCcBZtJ;
        zbHMjCgtc -= jNCcBZtJ;
        tEkMEuPtzmWo = tEkMEuPtzmWo;
    }

    return KXAWsOO;
}

void IikGTD::DtPpGH(bool VcTEWKwpCxB)
{
    double bfYvmDSZ = 687021.4705314051;
    int BmdkqmSuRCLMr = 1362427936;
    string rYQIH = string("NaIcfkXkjbADFUOULwPZyZEPqOmoTbKyXd");
    bool rGfWLpCqUFnA = false;
    bool XiJpihOv = false;
    double UVtesgIojqOV = -457708.23027590255;

    for (int NCWvNW = 1538622907; NCWvNW > 0; NCWvNW--) {
        rGfWLpCqUFnA = ! VcTEWKwpCxB;
        XiJpihOv = XiJpihOv;
    }
}

bool IikGTD::eqawSzzwxfNtfqLR()
{
    int gbYlRzpTPwmJwHJD = 1826479359;

    if (gbYlRzpTPwmJwHJD < 1826479359) {
        for (int QLWBdmL = 960404644; QLWBdmL > 0; QLWBdmL--) {
            gbYlRzpTPwmJwHJD = gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD /= gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD -= gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD -= gbYlRzpTPwmJwHJD;
        }
    }

    if (gbYlRzpTPwmJwHJD >= 1826479359) {
        for (int QnAjHmsvsegvVdNs = 1413088924; QnAjHmsvsegvVdNs > 0; QnAjHmsvsegvVdNs--) {
            gbYlRzpTPwmJwHJD *= gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD += gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD = gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD /= gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD *= gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD /= gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD += gbYlRzpTPwmJwHJD;
            gbYlRzpTPwmJwHJD *= gbYlRzpTPwmJwHJD;
        }
    }

    return true;
}

bool IikGTD::FRSFK(bool BHorR, bool RQxzrS)
{
    bool RAaXKrfhhDOob = false;
    bool cWgdtaMnjSyC = true;

    if (BHorR != false) {
        for (int kiYdYEn = 844446108; kiYdYEn > 0; kiYdYEn--) {
            cWgdtaMnjSyC = RAaXKrfhhDOob;
            RQxzrS = ! BHorR;
            BHorR = ! cWgdtaMnjSyC;
            cWgdtaMnjSyC = RAaXKrfhhDOob;
            cWgdtaMnjSyC = ! BHorR;
            cWgdtaMnjSyC = RAaXKrfhhDOob;
            BHorR = BHorR;
            RAaXKrfhhDOob = ! RAaXKrfhhDOob;
        }
    }

    if (BHorR == false) {
        for (int PlXEhSQOClK = 1392241966; PlXEhSQOClK > 0; PlXEhSQOClK--) {
            BHorR = ! BHorR;
            RAaXKrfhhDOob = BHorR;
            BHorR = BHorR;
            BHorR = ! BHorR;
            RQxzrS = cWgdtaMnjSyC;
        }
    }

    if (RAaXKrfhhDOob != true) {
        for (int LWQbvuR = 1501659068; LWQbvuR > 0; LWQbvuR--) {
            cWgdtaMnjSyC = RQxzrS;
        }
    }

    if (cWgdtaMnjSyC == false) {
        for (int IFXXwDqmUCRYdcm = 1451200473; IFXXwDqmUCRYdcm > 0; IFXXwDqmUCRYdcm--) {
            RQxzrS = ! cWgdtaMnjSyC;
            cWgdtaMnjSyC = BHorR;
            BHorR = RQxzrS;
            cWgdtaMnjSyC = RQxzrS;
            cWgdtaMnjSyC = BHorR;
            RAaXKrfhhDOob = ! BHorR;
            RAaXKrfhhDOob = cWgdtaMnjSyC;
            BHorR = RAaXKrfhhDOob;
        }
    }

    if (RQxzrS == true) {
        for (int hCrndTOLWzUgXtMS = 984598806; hCrndTOLWzUgXtMS > 0; hCrndTOLWzUgXtMS--) {
            RAaXKrfhhDOob = RAaXKrfhhDOob;
            BHorR = RQxzrS;
            BHorR = RQxzrS;
        }
    }

    return cWgdtaMnjSyC;
}

double IikGTD::KaQZPYXxbAQIAaZP(double iTbFykS, bool zAoxsSvqmwGIM, bool MUzZwrwwpxutE, double ONlugDuasaoJNhJe)
{
    string rePuwlVFpXpsB = string("KxLYPQrqrrwCjFxOxovOArouaRSjbqCfZKNlMXevQRszRZTSdkbcxWIdoMgdJUKenS");
    bool XZMRDCuiCEzAZfSU = false;
    double hFYKvpoivYB = -404225.3107526651;
    double fspVJ = 717215.9693057308;
    double VuFpPedrgW = -71966.00738573913;
    int psxHdwOpmRhrjnYi = 1217717364;
    double pukcAGHADfQq = 221895.2590837395;

    return pukcAGHADfQq;
}

int IikGTD::YRtKzjPyUoBu()
{
    double UGQzszPR = -609829.1794513428;
    double fYrRunAfmSzEBHjV = 190048.58273992705;
    int tvtCwHpqxoEey = -1839653506;
    string xsEEEFyOyT = string("ZXwIlRJyiNbdlnRQxHJYdMJdKIWDOCjiPgviRsrUOZJTKODKEOHLJMTOGqzJVtVSHkYyYxuYXtgbRsqsDhKOraIRNlTLldiNrZpUHWrtQWGkKRIrzRqlBSVlHAzFfbBcyzzcsdbbdlGUlrPTBsYOverAPuvrmSBGrmKjVAtDUEBOg");
    bool ftCHCMttjmvG = false;
    double wWlCYZ = 989222.9031631838;

    for (int uSWcFQMVLaGgfgK = 268932851; uSWcFQMVLaGgfgK > 0; uSWcFQMVLaGgfgK--) {
        continue;
    }

    if (fYrRunAfmSzEBHjV > 190048.58273992705) {
        for (int HPQcLaYSZmyD = 1892061953; HPQcLaYSZmyD > 0; HPQcLaYSZmyD--) {
            fYrRunAfmSzEBHjV -= UGQzszPR;
            tvtCwHpqxoEey = tvtCwHpqxoEey;
            UGQzszPR -= fYrRunAfmSzEBHjV;
        }
    }

    return tvtCwHpqxoEey;
}

string IikGTD::iCDDllN(int CDRIf, int lJVQzLB, int EEKEqzQqHoL, bool urOQcpuap, double YpFOmdpchBd)
{
    string QpRADu = string("WJwBjgXEJQIvsfnEXlmPKPxtUXIgwoScrHNOEUQCQchYXpIJjoNVgMZoLkxjDWjddmpKZRjcaKsZpXKDQJclKEqUHbMCuLuvFaheGXJUknmapabwEVRAQzliyzfrqhRktItFdGdHduIAxgCwUmlhDElrxgVzvPZpWuSCTgSobuFKDK");

    if (CDRIf < 198319932) {
        for (int rEfYqoXVFWEbfL = 1940121997; rEfYqoXVFWEbfL > 0; rEfYqoXVFWEbfL--) {
            urOQcpuap = ! urOQcpuap;
            QpRADu += QpRADu;
            QpRADu += QpRADu;
            lJVQzLB -= EEKEqzQqHoL;
            lJVQzLB = EEKEqzQqHoL;
        }
    }

    for (int JwBkS = 1484413372; JwBkS > 0; JwBkS--) {
        CDRIf = CDRIf;
    }

    if (CDRIf <= -1834637774) {
        for (int FiuedZmBQqbIqJxX = 97207463; FiuedZmBQqbIqJxX > 0; FiuedZmBQqbIqJxX--) {
            EEKEqzQqHoL = EEKEqzQqHoL;
            CDRIf -= CDRIf;
        }
    }

    if (YpFOmdpchBd > -395703.60421904747) {
        for (int aExyWwMg = 1207636950; aExyWwMg > 0; aExyWwMg--) {
            CDRIf -= EEKEqzQqHoL;
            QpRADu = QpRADu;
            lJVQzLB = CDRIf;
            CDRIf -= EEKEqzQqHoL;
            CDRIf /= EEKEqzQqHoL;
        }
    }

    if (CDRIf <= 198319932) {
        for (int kbEeLqS = 1238291159; kbEeLqS > 0; kbEeLqS--) {
            lJVQzLB -= CDRIf;
        }
    }

    return QpRADu;
}

bool IikGTD::BqMTLrosPgcpQYO(int bmXYYvylPDJBe, double UnmSGcAkQhbdedBt, int EwGGwep, double QbdDZmJwRyZrVx, string hpUIPhDUwE)
{
    int IzHemaZyURR = 184622069;
    bool tnuOUybiCcWb = true;
    string xrJnDBbwiE = string("CaiYUAapIeEYThYPJHRbAhgqQlPSingvBWbXZYfgOeaFbdRZwbPkIXlPEBemWQRejueGbzKetIqQVrOpzfD");
    bool WzzcB = true;
    bool nyUBArQfYk = true;
    bool CuQNSb = true;
    string jXjctFjTv = string("SrEAcBXGVDydVrxLaojSzMmrugfXVykVCkqtcQKjKefEjeyggVZrMJmOsXWToDXaSLUJaEfyWpNdmoJrWmqHWvoWzcEKtNlkOTMZodfgxButZAyFLOehwbbtGlufDRNwQlYHnDXnmfiNrhtwcxyVt");

    if (IzHemaZyURR == 207018008) {
        for (int ufOyRxm = 1529619612; ufOyRxm > 0; ufOyRxm--) {
            jXjctFjTv += xrJnDBbwiE;
        }
    }

    for (int BqNnVPCI = 1565284249; BqNnVPCI > 0; BqNnVPCI--) {
        CuQNSb = ! nyUBArQfYk;
        bmXYYvylPDJBe *= IzHemaZyURR;
        EwGGwep *= bmXYYvylPDJBe;
        nyUBArQfYk = ! tnuOUybiCcWb;
    }

    if (jXjctFjTv >= string("dyjjHzMyBLWsVzGasKRWaLHaoqSOVTzXvCUrkIOOpDXTHlNYaPhmMLtxTrHmMPthHMGwAdPXVdtLTRCoiwbDrMoCfOrGrhh")) {
        for (int PXLmOQYXJiQb = 1265725999; PXLmOQYXJiQb > 0; PXLmOQYXJiQb--) {
            xrJnDBbwiE += hpUIPhDUwE;
            hpUIPhDUwE += hpUIPhDUwE;
            bmXYYvylPDJBe -= IzHemaZyURR;
            bmXYYvylPDJBe -= bmXYYvylPDJBe;
            CuQNSb = WzzcB;
            tnuOUybiCcWb = ! WzzcB;
        }
    }

    for (int hqgVLxnp = 771851402; hqgVLxnp > 0; hqgVLxnp--) {
        CuQNSb = ! WzzcB;
    }

    return CuQNSb;
}

string IikGTD::lNqNyj(string MCfwLxRwBXcCfD, bool gJRmpJsgtOyHe, string eLbblDUrZ, bool DhcKiCBqX)
{
    string RLDZYzwyVuExd = string("VIvURHFuKsoaZFNZUkIkRsztrsyCkkYbdtpdAaiiAaBQUiQvWDCCuzQRCiyBBGWzZAoReWyNVAWoZGxWPXpcbdaWUWMDlewzwZzfscwXmVxbgMYprgnNTqObZTQyngBfcLmtONYwuwCgEtJlalQakhvXqwrCeImKWDesqGatSSi");
    bool oRQcObhgyAtCRock = true;
    string ethpdCHmPFDSRCjd = string("kTWvjbMoIvKmpwGuikorArONuBTvfaHReYpaeYEkAXmaFLVdQWmASSAMVdIsdCpQlfsbLnpLGwlWbFztFmxYKnMoRDjdmZYvaCkQSNMlevBSQVogxvynGNbluQSWTUowfalm");
    bool KFvGZkiYmpDX = false;
    bool zPOrpODDJ = false;
    double pYOSWdoRXaLiJvb = -658773.7561626207;

    for (int oEDKotbn = 557865088; oEDKotbn > 0; oEDKotbn--) {
        KFvGZkiYmpDX = gJRmpJsgtOyHe;
        DhcKiCBqX = zPOrpODDJ;
        DhcKiCBqX = ! DhcKiCBqX;
    }

    for (int PSdJaBw = 1334337212; PSdJaBw > 0; PSdJaBw--) {
        RLDZYzwyVuExd += MCfwLxRwBXcCfD;
        RLDZYzwyVuExd = MCfwLxRwBXcCfD;
        KFvGZkiYmpDX = gJRmpJsgtOyHe;
        gJRmpJsgtOyHe = KFvGZkiYmpDX;
        ethpdCHmPFDSRCjd += RLDZYzwyVuExd;
    }

    if (DhcKiCBqX != false) {
        for (int mbayuQVocKWqS = 1088346869; mbayuQVocKWqS > 0; mbayuQVocKWqS--) {
            RLDZYzwyVuExd += eLbblDUrZ;
            RLDZYzwyVuExd += RLDZYzwyVuExd;
        }
    }

    return ethpdCHmPFDSRCjd;
}

bool IikGTD::FeqNYt(double exbvEsdZA)
{
    int ySdgRAKfZ = -83434031;
    bool PqofDs = false;
    string ekdkTQzTRrXdKPt = string("tGYcpVhUsXZoZdTRtWYXdiNjpodnkjWtAwngWCINOPniNYcDxkhFXmPTjJIzzKkQZyDfsbyfcrytMkbcvSKpcapMqvtOcEZcxkovzhOonaaTUmpxXDfnDPUCFbCGQLshZLKfDl");
    bool CYwFMGLqmTLPipH = false;
    bool gFcHFZcSfSffH = false;
    int kTDFlGBREPcaDAm = -283218005;
    double qTBRcZOLhdxfXX = -468146.0506819977;
    bool HVFOE = false;
    double PiIaVNJgZKSK = 523509.0638804068;

    for (int GiIIssxhe = 1255162328; GiIIssxhe > 0; GiIIssxhe--) {
        exbvEsdZA *= exbvEsdZA;
        exbvEsdZA += qTBRcZOLhdxfXX;
    }

    return HVFOE;
}

string IikGTD::IaYGdsr(string pIhAjGGdRWkPL, double PPMasRDdcwAcC, int cvsflzC)
{
    int AEWggm = -943711954;
    int vYPRNxl = -903220384;
    string QTjNPWKLNQo = string("VPaBRcGLqmtLShwFTteuzPFMWzLoFwSrKlfRNyBdvjOjvRYvRpSPnQvgtMJRNgDRYuNarAFJvedVMzezupcoOeyfSvijTKSdGdMkdPoQuVMLMsdenxJIBUhJXgIPDeXjaUbsefymGqdvHXMpnvPpJycCJpRCAwyXdSqkkzxzYLlgmvxQgqlhGv");
    string WtDCdCSWRwPkwmk = string("xtZzkpwfhVmLXOAnqIFbCWhzDkAMyUMqPgrNxymQEaulAFEldoRjKbiDTyyzdSWdvpIbtfquVYuMGQLnesKhRABLqDuTRvJxCjkEiiiOzAQVyfBMbaiNoQMAElqVggxYDEUWnRwwjapUfvKQEYuDDXyWYrtqERWkAOXTNseKiwcqxbMIdnSqoStBQSVYA");
    int jLEzwLb = -362379512;
    double CZGQbItday = -797918.9253947587;
    bool TaacQ = true;
    bool UnhnoMXRMcUOWla = true;
    double mvDHjJJpMGe = 1027428.3663639867;

    if (AEWggm != -903220384) {
        for (int HDWNGkJh = 1458772260; HDWNGkJh > 0; HDWNGkJh--) {
            cvsflzC += jLEzwLb;
            vYPRNxl = vYPRNxl;
            PPMasRDdcwAcC *= mvDHjJJpMGe;
        }
    }

    for (int AhcDlyJQnbNpHUZ = 2015651705; AhcDlyJQnbNpHUZ > 0; AhcDlyJQnbNpHUZ--) {
        PPMasRDdcwAcC /= PPMasRDdcwAcC;
        CZGQbItday /= mvDHjJJpMGe;
        PPMasRDdcwAcC = PPMasRDdcwAcC;
        AEWggm *= cvsflzC;
    }

    for (int purpqoBOL = 1100402570; purpqoBOL > 0; purpqoBOL--) {
        CZGQbItday -= CZGQbItday;
    }

    for (int OXQbvV = 1942566903; OXQbvV > 0; OXQbvV--) {
        TaacQ = UnhnoMXRMcUOWla;
        QTjNPWKLNQo += pIhAjGGdRWkPL;
    }

    for (int EaCewqMQ = 297724871; EaCewqMQ > 0; EaCewqMQ--) {
        mvDHjJJpMGe -= CZGQbItday;
        jLEzwLb /= cvsflzC;
        CZGQbItday = mvDHjJJpMGe;
    }

    for (int aEqhTZuP = 430522773; aEqhTZuP > 0; aEqhTZuP--) {
        mvDHjJJpMGe /= mvDHjJJpMGe;
        AEWggm *= cvsflzC;
    }

    return WtDCdCSWRwPkwmk;
}

int IikGTD::YADNOqZRldx()
{
    int UalxiWNXPDnr = -1857077854;
    bool qCrNf = false;
    int JqppowB = 504055856;
    string KnmeWclbFMBwS = string("AlmdNtejPNterTxQtCtctTWQWGzpWjsGqlcRZFWwjtlxwLaYSgWNzSkGcadWsdriHEEP");
    bool pHkmQvqtEMh = true;
    bool zkhuY = false;
    int ETRkPJRpSjAgrw = -1142666960;

    if (zkhuY == true) {
        for (int eMBilNgOhyStZEs = 1759731000; eMBilNgOhyStZEs > 0; eMBilNgOhyStZEs--) {
            qCrNf = ! qCrNf;
            qCrNf = qCrNf;
            zkhuY = zkhuY;
            qCrNf = ! pHkmQvqtEMh;
            qCrNf = zkhuY;
        }
    }

    for (int xMYkdzKxm = 1851253307; xMYkdzKxm > 0; xMYkdzKxm--) {
        qCrNf = zkhuY;
        qCrNf = ! zkhuY;
    }

    return ETRkPJRpSjAgrw;
}

int IikGTD::ZNnpMLcqMj(string jTYKvFI, string VijUadvtxa, double vvSbBLpyLI)
{
    string KnkdyHEXp = string("OyqPgOQkvEiTxbGLKMpeLzUcCxKwQHPMUIMBvcmFQFGDbqmyOswzAOIgbRSimuutECUkUWgBfcbQnHVWpqBIjIRkuojLzSKxjSzeGAVgsgbxBQtRwaqHOwdYWLkFSOjRZGbnsJTjxcSCKBDjSSSPFdvIfrfdpXqdRfDHeRDTGsTeYjkYjLlOZtCDmNdAQxfYscOWlxsKjQpZtXKaLjmnXZHucQfDFpRUPzBLZgWDuO");
    int aBRzRxv = 1585911991;
    int qJvUmKbDvmrKOI = 753025165;
    string aGBnaeALhBYXQH = string("pZpdNgLzmUjapbhzQGQXXjzTlioDKsqgnMbehjhhdgMHxxciyRyopUNCRDwWmnuz");
    bool AcFIKnAjLrUs = true;
    string QpuOPJxWtgjf = string("jyUbRRKLTLiAoZnzJnhQYPlAcqkrGTaIuTxbEidSlamKRaSJRxRAIQbGPGNwIHdZLReDnNVTQzOnmJlTPbHWXqjDLoARIochYLMIzPSSlvoGodfOzRIDqnFCbGfHEKtUXaYZNNigVptBevZHTeIrvlyMMwRTsDqKMUpVQTyqUdWeDPOitxpPUlJUHGJABQt");
    int ePmUmAvHuyTw = 1242144214;
    int RPyzcwssDuFjXSRv = -1757787723;
    string DpwnlotGQy = string("NfOlRHFeiBmCeMdDrFIlxBRDDpFDmkLHWJwkhGp");

    for (int GhzMKSXmc = 1479604131; GhzMKSXmc > 0; GhzMKSXmc--) {
        ePmUmAvHuyTw *= aBRzRxv;
        jTYKvFI += jTYKvFI;
    }

    if (RPyzcwssDuFjXSRv > 1585911991) {
        for (int DIRKhcPOBcjY = 2051305609; DIRKhcPOBcjY > 0; DIRKhcPOBcjY--) {
            continue;
        }
    }

    return RPyzcwssDuFjXSRv;
}

string IikGTD::egcshbxavmBcMe(string oWWhuUxNXejVhQzY, bool LVjGquAubZBi)
{
    int aCdWBKPHLtSt = 1367738718;
    double PnQaviLHHPTKd = -622661.4883741218;
    int OAlXEBKbpTssvL = 31687703;
    string BWRhHqiSN = string("NHwbQQcDrBNRgEbrqixRGsMrbxQCInAaHaplKLxfjgKAxfZkLCoiRIfqYWBRpWIYSAWAbtrYlcNSWqLVFGenfvLeGzfOHCNxxGIGvtUzFQvUHHKMtoaXCUkpHQLNkMQYpEupHKpaJLavfkWoVKSBwFlJxNJBiAiQV");

    return BWRhHqiSN;
}

string IikGTD::LZHKr(bool pMTNhNc, double fuKGJeTNcuomP, bool LHulk)
{
    int qYfIGh = 1250465985;
    string lfMbKtcOOFWiXwD = string("VJdLfU");
    string YYEgGyZ = string("eFzQpxgNgsTYNWLKCEFtBbvLGAWTZLAhwJaVkAXobcUhMlxyDgtRELJqAOwdnVmiaCVvdxLQVBLbXHlJvttZduwJoD");
    int etVpTQtACpCB = 471121956;
    double yPZFVoYoUGo = 714663.0684638749;
    bool CIuHnNoCwKBwRP = false;

    for (int tSalnzMiUHMZPj = 512706351; tSalnzMiUHMZPj > 0; tSalnzMiUHMZPj--) {
        qYfIGh /= qYfIGh;
    }

    for (int dcAnlMbWTPs = 1808673498; dcAnlMbWTPs > 0; dcAnlMbWTPs--) {
        LHulk = ! LHulk;
        CIuHnNoCwKBwRP = ! CIuHnNoCwKBwRP;
        lfMbKtcOOFWiXwD += YYEgGyZ;
        CIuHnNoCwKBwRP = ! CIuHnNoCwKBwRP;
        etVpTQtACpCB /= qYfIGh;
    }

    for (int fHzrMWork = 1965527918; fHzrMWork > 0; fHzrMWork--) {
        yPZFVoYoUGo += fuKGJeTNcuomP;
    }

    for (int tjaYRYbrYkzvdcDX = 1624397488; tjaYRYbrYkzvdcDX > 0; tjaYRYbrYkzvdcDX--) {
        LHulk = pMTNhNc;
        LHulk = CIuHnNoCwKBwRP;
    }

    return YYEgGyZ;
}

double IikGTD::pVdDjZCaABmhP(bool LnfKFiWLFbvlc, string QhvbMqYSIba, double EvVaQ, int ReRXSzxtHgJa, bool CPbtoDZlqQBn)
{
    int JftSUzGf = -189562135;
    int jwDLd = -14360513;

    for (int hdNkOGtWnvJjHt = 1135230405; hdNkOGtWnvJjHt > 0; hdNkOGtWnvJjHt--) {
        jwDLd += ReRXSzxtHgJa;
    }

    for (int HLBgkIHfdNYMFO = 952086918; HLBgkIHfdNYMFO > 0; HLBgkIHfdNYMFO--) {
        continue;
    }

    for (int djpqobxqGww = 414748004; djpqobxqGww > 0; djpqobxqGww--) {
        continue;
    }

    if (jwDLd > -14360513) {
        for (int HmoLWRCSXa = 2065432228; HmoLWRCSXa > 0; HmoLWRCSXa--) {
            continue;
        }
    }

    for (int WEBsilhPyzTXCNqr = 838125493; WEBsilhPyzTXCNqr > 0; WEBsilhPyzTXCNqr--) {
        LnfKFiWLFbvlc = ! CPbtoDZlqQBn;
        ReRXSzxtHgJa = ReRXSzxtHgJa;
    }

    return EvVaQ;
}

bool IikGTD::QwoMWovkeAIFBH(string pidDwgqolSXyR)
{
    double QtdYoMFSIMyHoeng = -666347.7985445439;
    int ydmcaLXaFkO = 787290932;
    double rVEbpqTxpF = 469961.7806495527;
    int yjpLjKCOBFyUcx = 1297354869;
    bool pChIbh = false;
    int CmLSnBXXjfxjF = -958069672;

    for (int QXXVGCBgxTlFOyiv = 1763543439; QXXVGCBgxTlFOyiv > 0; QXXVGCBgxTlFOyiv--) {
        pChIbh = ! pChIbh;
    }

    for (int LvqXyNnRrBuHtfcR = 1495986378; LvqXyNnRrBuHtfcR > 0; LvqXyNnRrBuHtfcR--) {
        QtdYoMFSIMyHoeng += rVEbpqTxpF;
    }

    return pChIbh;
}

bool IikGTD::MymHkWTZfgXZeUoX(string qXjdEzE, double MdgkJ, bool YrNyydOuviKhMki, int zhOyetp, string NoRBnBaiNaXw)
{
    double hXDkWhQQ = 492816.72498353873;
    int IRlthxCGjXBAF = -894661646;
    bool usvcutBcXtw = true;
    int usiEijzoFu = 927300626;
    double ocHDbM = -291076.5068196704;
    double FRkMWtvEeJEFeJK = -284308.01454936183;
    bool WgJjJCTsmDO = false;
    double baKtVwUKRykSAZFz = -469587.9481479588;

    for (int KYRQOxCTt = 352070050; KYRQOxCTt > 0; KYRQOxCTt--) {
        usvcutBcXtw = ! YrNyydOuviKhMki;
    }

    for (int uPpSUiopKLs = 1073650122; uPpSUiopKLs > 0; uPpSUiopKLs--) {
        qXjdEzE += qXjdEzE;
    }

    for (int JGZhFLsHXrdy = 439082631; JGZhFLsHXrdy > 0; JGZhFLsHXrdy--) {
        continue;
    }

    for (int tIMALCEtlYjnlS = 1607357591; tIMALCEtlYjnlS > 0; tIMALCEtlYjnlS--) {
        continue;
    }

    for (int JqPkpBjrOxO = 604048622; JqPkpBjrOxO > 0; JqPkpBjrOxO--) {
        FRkMWtvEeJEFeJK += baKtVwUKRykSAZFz;
        usiEijzoFu += zhOyetp;
    }

    return WgJjJCTsmDO;
}

IikGTD::IikGTD()
{
    this->zIPPFg(string("krQJOvfbAlGxwKdgoeJuvNworBAddqjwCDRitDKvjpsBpJeERvhqwqKjYfcNqYKqwYAYRmzzKeQOOuFUevqJXIOqRtVKtbNroKSRhGwhTJlgcdeJijvLpLvCuoobXifceNbIOrSuzzciyaCLFa"), true, -144411.77301944562, -437350.45434096595, 546957.5529988535);
    this->NYFJIUPFQvFj(-1174854032, string("KzvjGpEh"), -995339.8019397182);
    this->DtPpGH(true);
    this->eqawSzzwxfNtfqLR();
    this->FRSFK(true, false);
    this->KaQZPYXxbAQIAaZP(-136246.39887920493, false, false, -442105.98808180756);
    this->YRtKzjPyUoBu();
    this->iCDDllN(1253165814, -1834637774, 198319932, true, -395703.60421904747);
    this->BqMTLrosPgcpQYO(-1089784426, -815341.1120581843, 207018008, -46175.67806476094, string("dyjjHzMyBLWsVzGasKRWaLHaoqSOVTzXvCUrkIOOpDXTHlNYaPhmMLtxTrHmMPthHMGwAdPXVdtLTRCoiwbDrMoCfOrGrhh"));
    this->lNqNyj(string("rgGEQTRQAjxLBqHovoFupzwEQSMxLqQkaQotHUSxmkHeegZzXlZdehqMBXTmHdXShyMWXmPMrNdBeOKGQQSHInHbmowEnsrWxFvNcBrVGbPynUwiIVQcrFOtzXLnnTlsjUqPMxTVIBXCxkIfDKOaMRMPVbfgZKUmaHyUeWVHiVpQzAajlkKiZdWRDUxLGHskHVrOXkjNWzIrytEZpCXYLzyXi"), false, string("pioCRJVPDUvByHaKToUpgkDVsTFBpGJQbwYQDwEnZZFxGIeYvymwvZhRXkDsfEkOVTVaDWGzlOtpzKgHNfywXgLzknvRCyUrvtlPnyWrAldtiQAINyOiGSZmezTyCSYSBoZvwpQRozmDktEblMpdAYCWxZ"), false);
    this->FeqNYt(-656758.2417511601);
    this->IaYGdsr(string("TxBOOGoqMxSFLzYFfLLaJsrMmktpswKSaKHDZgklFkmtdLTKBrCXKeeZekiqokbjlluadqjVHBSWjobdTqWjYohYgiOOfGhljMdiQeUNdlNODhJZrHgGtQfUJUKsIevsPWKzpf"), -278012.86464242404, 684232611);
    this->YADNOqZRldx();
    this->ZNnpMLcqMj(string("QToYvJhpJuYdcRDoBmKzchRNCSPmllWWoTcjXIKeEnYjuegaaLXqjFgKkJVddnTnFOiCnnhihvMXSUbBoYKCPwBpOBCtxNMYe"), string("PBeWZzCVqPXBjofRMtKYkudQZqZbHSCEUFKTyLcjGbskdjZxVvOwBDoWFPNdBtBrwHoshFoDxAlqYCWvoyKBonwRtAGJQDr"), -609851.2086510909);
    this->egcshbxavmBcMe(string("eVQByiXwMkeJnuhWtOaWmzaBcVxjRBKQnxUWDUAGXPPZATxyOnLYQwPAQNKMhoSWndnQJROHotSPYIKKhoKVtVUMgFWwOamBivkQNVYoFzOnQRepLrCmVdbrLkkYyHbvAAgOHcTRWxuQfkwWBACWmidMLYCgxdQGsKliiHdHBzlvVHkPcAYNXWsCKHKsmLJpFAfELGDvCtgCcPDHjmtcLRt"), false);
    this->LZHKr(false, -201262.40698578767, false);
    this->pVdDjZCaABmhP(true, string("BNSogRvIPBCrfwAzurfdSczplquGefNjfsanTbbFBVeEgdYRTSGeskwXceBleTKTxPopKZQCtJRaNjfhNRNCAkgzrh"), -538100.871917088, 1107458784, true);
    this->QwoMWovkeAIFBH(string("xakvldiZxVSuCYgUHUgVDsnauaQdYmCzlvXccjVIGSxGWYtLsxQicDUFooCrRxECNdmYaTuWWPjNYoJcQYIDEmhZHdsQiTNHQuRpkKUjEPgDMWODQCPYcBcSloCOWTO"));
    this->MymHkWTZfgXZeUoX(string("zozsfmepAAcUEdkrCVdbNMXAaidIshfBIozubkybCIamVFwJzHvNYUBLvSmitoBqLpLOFOxCwHipvCGiNvvyzUHuFFEmSPDbfJNgYpALnqPgO"), -572843.7983939047, true, 1280807238, string("gHNsBbMwfRxPmGHEINeyCoPLYAWDyCuqpPXmBgdKSLbPgDURKTPZtjtAhoMuSRmqcLlgzFZA"));
}
