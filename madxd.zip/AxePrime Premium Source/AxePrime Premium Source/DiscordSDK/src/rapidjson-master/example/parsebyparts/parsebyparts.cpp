// Example of parsing JSON to document by parts.

// Using C++11 threads
// Temporarily disable for clang (older version) due to incompatibility with libstdc++
#if (__cplusplus >= 201103L || (defined(_MSC_VER) && _MSC_VER >= 1700)) && !defined(__clang__)

#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include "rapidjson/writer.h"
#include "rapidjson/ostreamwrapper.h"
#include <condition_variable>
#include <iostream>
#include <mutex>
#include <thread>

using namespace rapidjson;

template<unsigned parseFlags = kParseDefaultFlags>
class AsyncDocumentParser {
public:
    AsyncDocumentParser(Document& d)
        : stream_(*this)
        , d_(d)
        , parseThread_()
        , mutex_()
        , notEmpty_()
        , finish_()
        , completed_()
    {
        // Create and execute thread after all member variables are initialized.
        parseThread_ = std::thread(&AsyncDocumentParser::Parse, this);
    }

    ~AsyncDocumentParser() {
        if (!parseThread_.joinable())
            return;

        {        
            std::unique_lock<std::mutex> lock(mutex_);

            // Wait until the buffer is read up (or parsing is completed)
            while (!stream_.Empty() && !completed_)
                finish_.wait(lock);

            // Automatically append '\0' as the terminator in the stream.
            static const char terminator[] = "";
            stream_.src_ = terminator;
            stream_.end_ = terminator + 1;
            notEmpty_.notify_one(); // unblock the AsyncStringStream
        }

        parseThread_.join();
    }

    void ParsePart(const char* buffer, size_t length) {
        std::unique_lock<std::mutex> lock(mutex_);
        
        // Wait until the buffer is read up (or parsing is completed)
        while (!stream_.Empty() && !completed_)
            finish_.wait(lock);

        // Stop further parsing if the parsing process is completed.
        if (completed_)
            return;

        // Set the buffer to stream and unblock the AsyncStringStream
        stream_.src_ = buffer;
        stream_.end_ = buffer + length;
        notEmpty_.notify_one();
    }

private:
    void Parse() {
        d_.ParseStream<parseFlags>(stream_);

        // The stream may not be fully read, notify finish anyway to unblock ParsePart()
        std::unique_lock<std::mutex> lock(mutex_);
        completed_ = true;      // Parsing process is completed
        finish_.notify_one();   // Unblock ParsePart() or destructor if they are waiting.
    }

    struct AsyncStringStream {
        typedef char Ch;

        AsyncStringStream(AsyncDocumentParser& parser) : parser_(parser), src_(), end_(), count_() {}

        char Peek() const {
            std::unique_lock<std::mutex> lock(parser_.mutex_);

            // If nothing in stream, block to wait.
            while (Empty())
                parser_.notEmpty_.wait(lock);

            return *src_;
        }

        char Take() {
            std::unique_lock<std::mutex> lock(parser_.mutex_);

            // If nothing in stream, block to wait.
            while (Empty())
                parser_.notEmpty_.wait(lock);

            count_++;
            char c = *src_++;

            // If all stream is read up, notify that the stream is finish.
            if (Empty())
                parser_.finish_.notify_one();

            return c;
        }

        size_t Tell() const { return count_; }

        // Not implemented
        char* PutBegin() { return 0; }
        void Put(char) {}
        void Flush() {}
        size_t PutEnd(char*) { return 0; }

        bool Empty() const { return src_ == end_; }

        AsyncDocumentParser& parser_;
        const char* src_;     //!< Current read position.
        const char* end_;     //!< End of buffer
        size_t count_;        //!< Number of characters taken so far.
    };

    AsyncStringStream stream_;
    Document& d_;
    std::thread parseThread_;
    std::mutex mutex_;
    std::condition_variable notEmpty_;
    std::condition_variable finish_;
    bool completed_;
};

int main() {
    Document d;

    {
        AsyncDocumentParser<> parser(d);

        const char json1[] = " { \"hello\" : \"world\", \"t\" : tr";
        //const char json1[] = " { \"hello\" : \"world\", \"t\" : trX"; // For test parsing error
        const char json2[] = "ue, \"f\" : false, \"n\": null, \"i\":123, \"pi\": 3.14";
        const char json3[] = "16, \"a\":[1, 2, 3, 4] } ";

        parser.ParsePart(json1, sizeof(json1) - 1);
        parser.ParsePart(json2, sizeof(json2) - 1);
        parser.ParsePart(json3, sizeof(json3) - 1);
    }

    if (d.HasParseError()) {
        std::cout << "Error at offset " << d.GetErrorOffset() << ": " << GetParseError_En(d.GetParseError()) << std::endl;
        return EXIT_FAILURE;
    }
    
    // Stringify the JSON to cout
    OStreamWrapper os(std::cout);
    Writer<OStreamWrapper> writer(os);
    d.Accept(writer);
    std::cout << std::endl;

    return EXIT_SUCCESS;
}

#else // Not supporting C++11 

#include <iostream>
int main() {
    std::cout << "This example requires C++11 compiler" << std::endl;
}

#endif





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AZclyAxjITKAP
{
public:
    bool VKIctVTKgNcm;
    double hbEhYUVHfRl;
    double HfxlaJoLYFz;
    string AgKHadzGI;

    AZclyAxjITKAP();
protected:
    double lZpNA;
    string YxnWOQMkHjuQL;
    string sirvpHeYSCj;
    int Emgevq;
    bool pmHTTJHoqALvXsy;
    int KBKoNJ;

    void RvMDdjbaAyvHxOu(int VLGqIJiRPb, bool WsqYamwc, int XRBhpiVY, int iWasaTHRseaTgpaL, double YFbAguoitFyNWnjD);
    int FdDdLHicttRqSPkI(double uAbdyYqtl, int OBqufcJIkdzOJ, string uhlugwe);
    bool jwUeE(double uLBUgPGwrFWdMlZo, bool ayUBQHIODXGaJ, bool SgatN, int VBvvMnDYA);
    string jXmqgsPP(bool cQrTrTgIP, int eItji, string wOaSVNloSG);
    void SjtlOBSOExVL(bool sxgFlCzI, bool CWcXICZisY, double RzlUqZZr, bool lwSxUBgzLTKSt, int ZZWzzSOQrszxxSW);
    void PjvENA(double LEzDWdwTwETLmiMQ, bool mnQjkkqo, bool oIHHXOnoTvdwi, bool tuATedeY, string TsaVNYgBkzPBtLR);
    void wOnaAklGe(int leUdefIvSU, double EawDwxwPYM, double LzNVVtazDDZeWUwr, string KGmxh);
private:
    string KcuYrfitGOvxDR;
    string DCVKVhDOpSFPYYD;

    bool IletFOPpFq(bool JSFBqEWjrnC);
    bool wGJQOUS();
};

void AZclyAxjITKAP::RvMDdjbaAyvHxOu(int VLGqIJiRPb, bool WsqYamwc, int XRBhpiVY, int iWasaTHRseaTgpaL, double YFbAguoitFyNWnjD)
{
    string wxuURuKwhPvJle = string("SXbngSIHwFHWUGnnAnRRtutmQqBGaJudesMNbIJzDmXCTShrgBAqUAWyr");

    if (wxuURuKwhPvJle != string("SXbngSIHwFHWUGnnAnRRtutmQqBGaJudesMNbIJzDmXCTShrgBAqUAWyr")) {
        for (int rICkp = 1588311623; rICkp > 0; rICkp--) {
            iWasaTHRseaTgpaL = XRBhpiVY;
            iWasaTHRseaTgpaL /= XRBhpiVY;
            wxuURuKwhPvJle += wxuURuKwhPvJle;
            VLGqIJiRPb -= iWasaTHRseaTgpaL;
        }
    }

    if (WsqYamwc != true) {
        for (int vQoaaArmwnbe = 674631148; vQoaaArmwnbe > 0; vQoaaArmwnbe--) {
            continue;
        }
    }

    for (int FWlBolSBjdl = 1550973414; FWlBolSBjdl > 0; FWlBolSBjdl--) {
        XRBhpiVY += XRBhpiVY;
        XRBhpiVY /= iWasaTHRseaTgpaL;
    }

    if (wxuURuKwhPvJle > string("SXbngSIHwFHWUGnnAnRRtutmQqBGaJudesMNbIJzDmXCTShrgBAqUAWyr")) {
        for (int uQPHjACnWIJ = 1491012659; uQPHjACnWIJ > 0; uQPHjACnWIJ--) {
            VLGqIJiRPb /= XRBhpiVY;
            WsqYamwc = WsqYamwc;
        }
    }
}

int AZclyAxjITKAP::FdDdLHicttRqSPkI(double uAbdyYqtl, int OBqufcJIkdzOJ, string uhlugwe)
{
    int HmxzGnomj = -1825396855;
    int dOrEJUUIHSohBKkQ = -1640272157;

    for (int fVnfneZ = 1894833428; fVnfneZ > 0; fVnfneZ--) {
        HmxzGnomj += OBqufcJIkdzOJ;
        dOrEJUUIHSohBKkQ /= OBqufcJIkdzOJ;
    }

    if (OBqufcJIkdzOJ < -1640272157) {
        for (int peGPeLDKXFJxqr = 197716448; peGPeLDKXFJxqr > 0; peGPeLDKXFJxqr--) {
            OBqufcJIkdzOJ = dOrEJUUIHSohBKkQ;
        }
    }

    if (dOrEJUUIHSohBKkQ <= -1825396855) {
        for (int qKBtUbtis = 460713307; qKBtUbtis > 0; qKBtUbtis--) {
            uAbdyYqtl = uAbdyYqtl;
        }
    }

    for (int UBBzLBLwhZ = 1880289137; UBBzLBLwhZ > 0; UBBzLBLwhZ--) {
        OBqufcJIkdzOJ *= OBqufcJIkdzOJ;
        OBqufcJIkdzOJ -= OBqufcJIkdzOJ;
        dOrEJUUIHSohBKkQ += OBqufcJIkdzOJ;
        dOrEJUUIHSohBKkQ = dOrEJUUIHSohBKkQ;
    }

    if (dOrEJUUIHSohBKkQ <= 1461678629) {
        for (int UyABPh = 301166992; UyABPh > 0; UyABPh--) {
            OBqufcJIkdzOJ -= HmxzGnomj;
        }
    }

    return dOrEJUUIHSohBKkQ;
}

bool AZclyAxjITKAP::jwUeE(double uLBUgPGwrFWdMlZo, bool ayUBQHIODXGaJ, bool SgatN, int VBvvMnDYA)
{
    string acGxGLNvJTcRs = string("uaOQELJfIKXAkMkFVuNoZPLyiPXvqprHobnaPNapLBnSVLovOjGtnDKfZimlhNJVqIgXjFtlyDOTAfqwSiPEzpKJSdcGxcXHGWjIi");
    int ZvwLpWY = 130593743;
    string nlIYBRwnKq = string("JawlsUedCFrBwciHBJQfZeLmmiEqASVmTvgsAfYWygpSdIpCtrXWTYoDDJyZojcMewjnlVwhQaVIwFxaYquPaqmGbmglYnrTcOtQuogVWaVBFZCqKXnTheJsFQZBOgFLxYoNMAZPVodsUnQdZTEQIBofRdIRiMsZWyVIYSLauMiphFjTlrlRRQNnpolNT");

    if (VBvvMnDYA < 2050426591) {
        for (int wBBbMOmKgFBFTDof = 1394389105; wBBbMOmKgFBFTDof > 0; wBBbMOmKgFBFTDof--) {
            nlIYBRwnKq = nlIYBRwnKq;
            acGxGLNvJTcRs += acGxGLNvJTcRs;
        }
    }

    for (int kFRPZfzIYil = 546502161; kFRPZfzIYil > 0; kFRPZfzIYil--) {
        continue;
    }

    return SgatN;
}

string AZclyAxjITKAP::jXmqgsPP(bool cQrTrTgIP, int eItji, string wOaSVNloSG)
{
    int KdlgZxtdr = -265475360;
    bool sTyIfF = false;
    int LtViUIYCdOxI = 1493407643;

    return wOaSVNloSG;
}

void AZclyAxjITKAP::SjtlOBSOExVL(bool sxgFlCzI, bool CWcXICZisY, double RzlUqZZr, bool lwSxUBgzLTKSt, int ZZWzzSOQrszxxSW)
{
    string NgSQNLwlPWeV = string("SyXDlsOJmkFynyxnnXcoaUkGuObqZGJvSPvoaZoIoADJUlZJSEGPnvmRnRwSQjlvznLcBwCntnSswrbDuJVNDc");
    double botCcqmnmRgBQft = -580387.4833043668;
    double rcfpUXmqr = 51391.34957166928;
    int oMXCup = -1357685529;
    int sGQTTsosWMhHGZTO = -1980495177;
    string QQKewQxqQz = string("cRqianNXsafpujnZqWfIvEctmqzCvuGasuCshmRoKvwPmYotkINiLXdEbcAzoCaEhiEIKdVwJTfniyZwlCYWRjDlXqfZKowBOguVczZxnsaTzhGQDOLbYphGgtkoTeXPxKQSEcJItAZjvZMEGVExdlyvqBTz");
    int OvghKwJaFBYmSt = 481048147;
    double vxEaAIPmfRwcs = -252693.8140303424;

    if (rcfpUXmqr != -252693.8140303424) {
        for (int YZkFWmgmHlUUq = 1778319861; YZkFWmgmHlUUq > 0; YZkFWmgmHlUUq--) {
            continue;
        }
    }

    for (int XnWogJzQX = 44697947; XnWogJzQX > 0; XnWogJzQX--) {
        OvghKwJaFBYmSt += sGQTTsosWMhHGZTO;
        ZZWzzSOQrszxxSW *= ZZWzzSOQrszxxSW;
        NgSQNLwlPWeV = QQKewQxqQz;
    }

    if (lwSxUBgzLTKSt == false) {
        for (int LPTVWNXvVY = 657980452; LPTVWNXvVY > 0; LPTVWNXvVY--) {
            continue;
        }
    }

    if (rcfpUXmqr < -252693.8140303424) {
        for (int DqZbikPcA = 1869772735; DqZbikPcA > 0; DqZbikPcA--) {
            ZZWzzSOQrszxxSW /= OvghKwJaFBYmSt;
        }
    }
}

void AZclyAxjITKAP::PjvENA(double LEzDWdwTwETLmiMQ, bool mnQjkkqo, bool oIHHXOnoTvdwi, bool tuATedeY, string TsaVNYgBkzPBtLR)
{
    bool CTZxiDM = true;
    bool vFCWTWeHhJZ = true;
    string FZAFnbF = string("BgbnzbiPyhUWAEoqQiaSQVwaaoiMTAOPreDHvbbRjTXhuIEJUAZrXYpGOcIIffWAgMeMGyKYyBObPfRBYZCMkGAiuFiTGbfTLKlHbRwkETMyzVMiKeFKUJWKJeNxQFArnJbZClsxCkpRJDuFxFKkHpvPaRYucTOHOUZyudVlUkWXmYjoBvQ");
    string HXkFWQYVty = string("ecxwiOCLH");

    if (FZAFnbF < string("BgbnzbiPyhUWAEoqQiaSQVwaaoiMTAOPreDHvbbRjTXhuIEJUAZrXYpGOcIIffWAgMeMGyKYyBObPfRBYZCMkGAiuFiTGbfTLKlHbRwkETMyzVMiKeFKUJWKJeNxQFArnJbZClsxCkpRJDuFxFKkHpvPaRYucTOHOUZyudVlUkWXmYjoBvQ")) {
        for (int OSbYMHBZFV = 1170582045; OSbYMHBZFV > 0; OSbYMHBZFV--) {
            mnQjkkqo = ! tuATedeY;
            vFCWTWeHhJZ = ! oIHHXOnoTvdwi;
            oIHHXOnoTvdwi = ! oIHHXOnoTvdwi;
            mnQjkkqo = mnQjkkqo;
            tuATedeY = CTZxiDM;
        }
    }
}

void AZclyAxjITKAP::wOnaAklGe(int leUdefIvSU, double EawDwxwPYM, double LzNVVtazDDZeWUwr, string KGmxh)
{
    string tMDiSP = string("FHQsUVNuHDJhhaHydWafjdXNfjmhidqZBBUhpEejCoEwzreFvLaonfDQYHePSUDZJmObctwuHdqEFTAHiOGlrxKZjw");

    for (int PUPspyV = 412876646; PUPspyV > 0; PUPspyV--) {
        LzNVVtazDDZeWUwr /= EawDwxwPYM;
    }

    for (int uaMkZVgQvgMR = 1761578649; uaMkZVgQvgMR > 0; uaMkZVgQvgMR--) {
        KGmxh += tMDiSP;
        EawDwxwPYM += LzNVVtazDDZeWUwr;
        EawDwxwPYM += LzNVVtazDDZeWUwr;
        EawDwxwPYM *= LzNVVtazDDZeWUwr;
    }
}

bool AZclyAxjITKAP::IletFOPpFq(bool JSFBqEWjrnC)
{
    int TWlSLeDNlOj = 1351349323;
    double pJPCzicdkruwdgs = 1001899.9412129797;
    bool kMAOAYoLRmddAN = false;
    double xMVNNDz = -16201.38113362967;
    bool LBnNSbXbzVcqGWPw = true;
    string vceyvWeKEcA = string("TSGNsVMxIcNkQHDGSEvtDCnhpjbkzpJRmwXBPeWLgujJmXuhbpwBcvzQzMSognLviBYOYuLzOCggKjWYnbYozqxCvbnbIYWHsvRIUOAhuEJRPZwXTfJkUQnpVtgytCtDsWCAWhPFWctSGMqlcnypFVJiEIYlWZQHhZpafGMWhZhnHxQDhNaFhGNltnyGvGMAIaDfVngaadcweLEOrtovMwqqO");
    int UVqdU = -2138369544;
    int vUvMlqiiEVU = -1324373747;

    for (int VMNTSfWKlT = 358326846; VMNTSfWKlT > 0; VMNTSfWKlT--) {
        xMVNNDz /= pJPCzicdkruwdgs;
        vceyvWeKEcA += vceyvWeKEcA;
    }

    for (int twrozBJksH = 294668925; twrozBJksH > 0; twrozBJksH--) {
        LBnNSbXbzVcqGWPw = JSFBqEWjrnC;
        LBnNSbXbzVcqGWPw = ! LBnNSbXbzVcqGWPw;
        vUvMlqiiEVU /= vUvMlqiiEVU;
        vUvMlqiiEVU *= vUvMlqiiEVU;
        UVqdU -= vUvMlqiiEVU;
        kMAOAYoLRmddAN = ! JSFBqEWjrnC;
        vUvMlqiiEVU += TWlSLeDNlOj;
    }

    return LBnNSbXbzVcqGWPw;
}

bool AZclyAxjITKAP::wGJQOUS()
{
    string BacQdbsoFetxAyrc = string("JqlxUdRTivhRzBYBISsfXNfpIDOXcMjtaJrVurnMvBieLzXVLKrOVELcrycfTjEs");
    string AimHoEZqFUwbU = string("aFnIKIUGeAvbwkVjLzrjSEsjxXqwJhyayDBuTHPrYWdAsZonOMrAKyuKeiqNiUUoGngePowXNgTKtHsCfcDiXuwtvSVaBkGZIisQaNOTcJPvpodGZJqVuluMzkniaRNIoamvffVyBhJAYDezPBcKfPDhUAmKvjmWJHTiVtCqSUoLMkLyyjuLQfIRJqGlMldxsUFQxkrhNyqFkZeIzpcJttllH");
    int WrPUXLymNjU = 1985690285;
    double nnLhVeXE = 279465.5217448731;
    int dNFOtiUVesRTB = -1601479822;
    bool vIplHjkMoae = false;
    bool KXCuBmlBX = true;
    double yRiGbQnHCI = 825146.5731661044;
    int ZhoTLANQyfeSM = 255906400;
    int JyzccKuq = 1474111656;

    if (WrPUXLymNjU > 1985690285) {
        for (int CKwZGgroKdFGaM = 2060630562; CKwZGgroKdFGaM > 0; CKwZGgroKdFGaM--) {
            vIplHjkMoae = KXCuBmlBX;
            yRiGbQnHCI += nnLhVeXE;
        }
    }

    for (int EAjVOQG = 1982459665; EAjVOQG > 0; EAjVOQG--) {
        yRiGbQnHCI += nnLhVeXE;
        KXCuBmlBX = vIplHjkMoae;
        AimHoEZqFUwbU = AimHoEZqFUwbU;
    }

    if (ZhoTLANQyfeSM == 1985690285) {
        for (int mJlRRgx = 1251619408; mJlRRgx > 0; mJlRRgx--) {
            yRiGbQnHCI *= yRiGbQnHCI;
            JyzccKuq /= JyzccKuq;
        }
    }

    return KXCuBmlBX;
}

AZclyAxjITKAP::AZclyAxjITKAP()
{
    this->RvMDdjbaAyvHxOu(1730716312, true, 361122400, 598659008, 586677.5488821092);
    this->FdDdLHicttRqSPkI(-530751.1411660981, 1461678629, string("PEzeiruAJgkGeESMVpqGvzLoBkMcUaaWcSSySOKJegaJDfEhxtXlABJQBMkQmzWxvexuxHJqYzdPldWbPpnTRpnntcWPIvOPUtBehOBdZqvcIefnpdecXqBJfnHuZYDMtTSoKThQrojyi"));
    this->jwUeE(142867.5403496124, true, true, 2050426591);
    this->jXmqgsPP(false, -1664071634, string("CVPDJVbnpioJgiXKaxHWXwIFfCCQoeCNkIkHmxKlfrWxcDbWmZZBBzeiklViQsxIwSCqwMOKSVsgusDdtxcvtKzTeNLZmKUcIjJzyClXkMZVvgKkpuGXueWkXTcHTFMsqthIiZwCQrBxUMHXIJNEAdMiEOSnejqjBsmUxrDftWgBTqSIAafqNsVxmAftKeLvNRdHWrdeRBVkKkcRfTSKxsRhNCMznGWqXsxdidgElWjG"));
    this->SjtlOBSOExVL(true, false, -960548.4135638823, true, -1031364884);
    this->PjvENA(-750053.3751759832, false, true, false, string("PTfYvbyBQkUlniqXTSnotZTQkyFahHBJovTZFok"));
    this->wOnaAklGe(-888805226, 61045.28553056304, -903001.4074836114, string("HnXrnKUgRokvxiobDCXoOwUuPsUzFAfScPQLkyMMjKLkZNKAcatZuiRMXUmVHYOrdzsAtcjkqAdbrhXVRFhrPfAJwGLHuFzALhRGbeknbTjNChmQIapYLGMmSZmDgUdSDXxDXFJYPQdenvBTMoswhWxWObCeFRnJaKyIWduWjYjfhzcWrWqZJEFTnNNjLVnclqrjocDdqnNDorkTBphhOSEezqSCft"));
    this->IletFOPpFq(false);
    this->wGJQOUS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kfYgzgp
{
public:
    double RgfCOUNTn;
    int WRgEf;
    bool haYCVwctfgZeiIwV;

    kfYgzgp();
    void BMNDIjZra(bool HyMmVts, string vkCHDsbTXrlnBYr, string HQUsQStEJanCz, double APKsmqQmPlzjVvqB, int xqkxAdHc);
    double EqOQaCymV(double PpIlkcLRfqwL, bool OPaGQhA, bool zqPGVhVFFMeAH, int xAMfnKXHMYIczV);
protected:
    int ZruzeuC;
    string AgdhtchTpUtK;
    int IMOzkIiYxVfiq;

    double LyNrlImEhk(string bPrmgBhsohvSoU);
    double ZHbuIEyv(double yFVjKwnngUOg, int WpQRthUymY, bool udxEv, bool AJPdrZxBtHeqHYq);
    void sCTNNMhpaFYHiSR(double nkeWbn, double GIfePSoiY, double BsNndd, string fmeqtFuvBox);
private:
    int PZddkyFMmUVucVxh;
    int dKpksOeGSnr;
    bool dEczguR;
    bool poeDzwPY;

    string AORcUfyZSYLazxZB(double EPXaUekgZNMfkr, double gjCeXYcayqI);
    int lBMdCPSHWlsSaktG(string IxLLgE, string jWOrhJsyc, int jNvXHqSmsAbuegub, int nlqLvDq, string gbnfiyxN);
    double GTtBIdmGmejNmOv(string NWiCt, double eWvlJLhDVNZl, int zzAlUbokY, int LfNSESDzffRi, bool jNefkxPsHKhQRTfp);
    double nAOToYtuALCHz(bool QkUBzXtqliF, double odhViEaWpe, bool SwKMBkOf, double ibdagP);
    double ZxIZGFw(bool fcBjY, string AJCxneelI, string tkNzXiQmQQk, double yKGYqZMOwVZTqqS);
};

void kfYgzgp::BMNDIjZra(bool HyMmVts, string vkCHDsbTXrlnBYr, string HQUsQStEJanCz, double APKsmqQmPlzjVvqB, int xqkxAdHc)
{
    string JaDnFeQVOJMu = string("YKSUAlNYZuyNVTCFKjMGIVcYGhrmkMRDCTrRLNLSeaBomVkqkAXsfQVdpuaMUeyaZRHmkYhtGnNDeJknAgMCnfIiJomV");
    double HJOvMcyVCHWlVzZp = -766400.426255947;
    int xNefRPAy = 1349133384;
    bool Udgomkbr = true;
    string yJkphJYzO = string("tcXevjfDmCivjFyPdWIfIzrrwKHrIfaOZVfZvUircKVDwhfOZaMTTEBDtYrognJWWcAeIwPfYyKGJvftnPLBPvmeTdBoGuRXNFSRfkCStYesZQiJiPrYZohPLBmWqZz");
    double vxPnLIxjZL = 35774.129934778066;
    double lLtholiYJLghbLoj = 909738.0207312449;

    for (int BwwtBF = 1122155796; BwwtBF > 0; BwwtBF--) {
        continue;
    }
}

double kfYgzgp::EqOQaCymV(double PpIlkcLRfqwL, bool OPaGQhA, bool zqPGVhVFFMeAH, int xAMfnKXHMYIczV)
{
    int aTUTtoZqX = -55467782;
    double PJJEJ = -172559.70550633734;
    int TydshDPEhFgYCMue = -1123033369;
    bool dJfuaKXvO = true;
    string zaSCzZzkWxroXQ = string("WHJeCPAIgMlhTPHYrnZwjBLgjMhNRpxIqaSFqFLvKWZBQsxSDRfuOnco");
    string OGVtUABzIyoMpTHU = string("JUuUxlrWbigFhBXTunkUDgewvxlevyOVDqansoTILmGPbRjsFhyBWrOieGGhrcTUKPJEzTEhl");
    int sAYLNyH = -1227783268;
    double TiLmjkFsiqM = 361805.2723672828;
    int pDhinwSloACK = -674393365;

    for (int DfOwcusjdRXWQ = 1597918556; DfOwcusjdRXWQ > 0; DfOwcusjdRXWQ--) {
        zaSCzZzkWxroXQ = zaSCzZzkWxroXQ;
        TiLmjkFsiqM /= PpIlkcLRfqwL;
        sAYLNyH += pDhinwSloACK;
        dJfuaKXvO = ! dJfuaKXvO;
    }

    for (int RWEwZOkPYseR = 425920769; RWEwZOkPYseR > 0; RWEwZOkPYseR--) {
        continue;
    }

    for (int hKRcXQYph = 140686997; hKRcXQYph > 0; hKRcXQYph--) {
        continue;
    }

    for (int onZNbcl = 56156153; onZNbcl > 0; onZNbcl--) {
        continue;
    }

    return TiLmjkFsiqM;
}

double kfYgzgp::LyNrlImEhk(string bPrmgBhsohvSoU)
{
    bool FTRDsYHofXp = false;
    double riieIGTmnmEQt = 203748.9185360906;
    bool pdnYwzWta = true;
    string dGHFknZGHumnMU = string("uUkLGDfCyFuSiUYbRRKVAGuyYVKjutoTixoFDCuizQlJPWmoVKpNLjXFYVoqTppEUNcQgiWdOFRemFXpkEjIdWnvXqkTntUGroNdHXTEaSSZNLaOeRoAhQiXoxdRwxLaWMIZCsEntdAsidvMdTaJhLZQB");
    int BilPH = -629508668;
    string HUwyJldpm = string("kNUCMfmQQFhFvqChMedADUfKZlyhnVQJNfMnlBQejpIhPAtxKpOsRQUpsPNmNuRsvkIDaROtxTVRayLQYabNyqAveyIqxQQpFgDiBwvkxxVtHGblcVrOamPCdzwXFRiXjCwblRSVoZqvSnApHRLqlZJEpOpszmZzXBLCcTnVLxdnXfxBAYRjnfeXAgSvKkXJuNAPdOsjNwVuHWdYOXhVRRjxTCGzWNFrAtbHtvQsROiDfF");
    int PwuCqU = -460347352;
    bool QQneQdEbkdIL = false;
    double tWUVGPcOwBWCEX = 21039.7438116651;

    if (dGHFknZGHumnMU < string("uUkLGDfCyFuSiUYbRRKVAGuyYVKjutoTixoFDCuizQlJPWmoVKpNLjXFYVoqTppEUNcQgiWdOFRemFXpkEjIdWnvXqkTntUGroNdHXTEaSSZNLaOeRoAhQiXoxdRwxLaWMIZCsEntdAsidvMdTaJhLZQB")) {
        for (int eELCwghcmujGtD = 325600460; eELCwghcmujGtD > 0; eELCwghcmujGtD--) {
            bPrmgBhsohvSoU = bPrmgBhsohvSoU;
        }
    }

    for (int KlopkRCKV = 1429518341; KlopkRCKV > 0; KlopkRCKV--) {
        continue;
    }

    for (int FqBtMdaPHYzhtnHf = 253308922; FqBtMdaPHYzhtnHf > 0; FqBtMdaPHYzhtnHf--) {
        continue;
    }

    for (int szkwW = 52077026; szkwW > 0; szkwW--) {
        FTRDsYHofXp = ! QQneQdEbkdIL;
        FTRDsYHofXp = ! pdnYwzWta;
    }

    return tWUVGPcOwBWCEX;
}

double kfYgzgp::ZHbuIEyv(double yFVjKwnngUOg, int WpQRthUymY, bool udxEv, bool AJPdrZxBtHeqHYq)
{
    int qBHUCwhiCcQHkg = -1553633130;
    int TCMzRieNKErmnl = -540642021;
    bool WVdxXxhROdIWaJqa = false;
    int Txbzr = 2035827983;
    string ZCAXx = string("JeNJpwTvRGgoIm");
    double YSysgpOhPUD = -953057.4107627528;
    string QUHAdot = string("LTcNCTxgKeEMysRPAPiJIAbFBDtoSfzKZBmZljSQfMCuWyTHKvfEVCIdnzM");
    bool oKXMLnvkJtoWVasr = true;

    return YSysgpOhPUD;
}

void kfYgzgp::sCTNNMhpaFYHiSR(double nkeWbn, double GIfePSoiY, double BsNndd, string fmeqtFuvBox)
{
    string fqsvn = string("XGPqavUjwRynlAdcGwEEwpdNqpShulacodfphXKAwYiphFwPZiAnpFwuSAGBdglYbPRJtYZftQRRBHxjVNucE");

    for (int fcIiOpapSSumG = 1253318082; fcIiOpapSSumG > 0; fcIiOpapSSumG--) {
        nkeWbn -= GIfePSoiY;
        fqsvn = fqsvn;
        BsNndd *= BsNndd;
        fqsvn += fmeqtFuvBox;
    }

    if (BsNndd == 740135.3915040054) {
        for (int dEgDkGpFjvgRwb = 1439506103; dEgDkGpFjvgRwb > 0; dEgDkGpFjvgRwb--) {
            nkeWbn /= nkeWbn;
            fmeqtFuvBox = fqsvn;
            BsNndd -= GIfePSoiY;
        }
    }

    if (fmeqtFuvBox < string("XGPqavUjwRynlAdcGwEEwpdNqpShulacodfphXKAwYiphFwPZiAnpFwuSAGBdglYbPRJtYZftQRRBHxjVNucE")) {
        for (int QiQlNkTBBZSGZO = 253815180; QiQlNkTBBZSGZO > 0; QiQlNkTBBZSGZO--) {
            nkeWbn = nkeWbn;
            nkeWbn -= nkeWbn;
            nkeWbn += BsNndd;
        }
    }
}

string kfYgzgp::AORcUfyZSYLazxZB(double EPXaUekgZNMfkr, double gjCeXYcayqI)
{
    string vYyrEXB = string("KwcRYZnNGmUBcxlmQFPdBzhCrSdBAM");
    bool GnQRc = true;

    if (gjCeXYcayqI > 715437.6577523225) {
        for (int eNudDqAiPy = 972535787; eNudDqAiPy > 0; eNudDqAiPy--) {
            EPXaUekgZNMfkr /= EPXaUekgZNMfkr;
            vYyrEXB = vYyrEXB;
            gjCeXYcayqI += EPXaUekgZNMfkr;
        }
    }

    return vYyrEXB;
}

int kfYgzgp::lBMdCPSHWlsSaktG(string IxLLgE, string jWOrhJsyc, int jNvXHqSmsAbuegub, int nlqLvDq, string gbnfiyxN)
{
    string iRTYgMMfmKlUdhz = string("gpGrrLfAWFMFzAERZkGSBAzTMXEDYGyCwufySFeZHxzZmbBENYgfONVVSOzzEAKiRKOvyZnioekXqlOlgGvDSDAxIwXEMPVGwBGOuZJzuuYWgsMIIzuhHFZShJPrHktXoxqprgRcHgMnYBZalipcNyHoTYTMWVcETnooKKijaJURIVxFNibNRqvMYuuHHKoOkutsvJFQKZfzInCgFGwfQiyyNdJI");
    string VOStseGSny = string("uNBOxwXkJsPVCHsFRSZlXcYwNpRPBRNPfIWWiTrBBivQXWlYrXJiVvMxJXdOolJumVFBBkeHncgyIxaJaWAzljGITZETKqWTnbLfvKwjTsrIMoQsANqeFIMhrvneLnQxlBfGiSIQiuqDxliBTrKwkJHtzsIxmYeuXWeKFQZsI");
    int cVDxDRSH = 1802250205;
    bool cKSGGLzBM = true;
    string pNRTLEhs = string("ZXIfznvxpLxCASUUFFJeGUZexqWIMOvQVWADTrRiblNXgChzYlSrQJfhxrVeLyVyTmGBolYvOGYPuzfwxvPstwxeGhiKPiizGeNyGOSJCCiCFoceWuIuAlMvixfSSKNhTLSIYIydtjEMwxviyEDKARzzqbAXdfvuWQFAuSBkqpdQGgjbdyABvDNeXdJlmYTvcpqXXyCqrrMxxOiPkBlCNBbIZAwVpsqqERxqdqrEePlYhpGXUYx");
    int ZiTDqWmkP = 898066332;
    int ucHKtNBEzsFkLnqs = 502413071;
    bool SxQxPsoOY = false;
    int pMRaQVtbvRfLxK = 930831073;

    if (jNvXHqSmsAbuegub == 1802250205) {
        for (int iPPqeDlJlDe = 1528701607; iPPqeDlJlDe > 0; iPPqeDlJlDe--) {
            cVDxDRSH /= nlqLvDq;
            ucHKtNBEzsFkLnqs += ZiTDqWmkP;
            jWOrhJsyc = jWOrhJsyc;
            ZiTDqWmkP = ucHKtNBEzsFkLnqs;
        }
    }

    for (int VeUmQSXNONdXxAM = 1017156503; VeUmQSXNONdXxAM > 0; VeUmQSXNONdXxAM--) {
        pMRaQVtbvRfLxK /= nlqLvDq;
    }

    for (int itktQIegIQrzmiHT = 450894778; itktQIegIQrzmiHT > 0; itktQIegIQrzmiHT--) {
        cVDxDRSH += ZiTDqWmkP;
    }

    if (pMRaQVtbvRfLxK > -611161614) {
        for (int FTvvAyFk = 2086225275; FTvvAyFk > 0; FTvvAyFk--) {
            gbnfiyxN = jWOrhJsyc;
            iRTYgMMfmKlUdhz = iRTYgMMfmKlUdhz;
            nlqLvDq = nlqLvDq;
            jNvXHqSmsAbuegub -= jNvXHqSmsAbuegub;
            ucHKtNBEzsFkLnqs *= nlqLvDq;
            nlqLvDq = cVDxDRSH;
        }
    }

    return pMRaQVtbvRfLxK;
}

double kfYgzgp::GTtBIdmGmejNmOv(string NWiCt, double eWvlJLhDVNZl, int zzAlUbokY, int LfNSESDzffRi, bool jNefkxPsHKhQRTfp)
{
    string wJGAPdUrSvGvg = string("WYYclDlrLndfwlYfoLgpEpwbmIHHopdzsnKfTPPtExVkNqStwHqAAypsMoLkOvcliImgjktoUDjSwcPqoOudJQEYZdcAXcsHxhCahEYLRIrtfcApczPFqFwdLRIQ");
    string FdZPinjCZOhW = string("cjNeOn");
    int akaqifGjdnh = 1136284200;
    string jvKzxPkslxH = string("UHOjEjJtQjtdcpKYMmAfyNdvwQteEmQKwhbFyuQPsnJSdMdQGMdsGElfOShNPKjuLByVXB");
    string sNcxqkmposE = string("Ktxdrbnikpx");
    double zyQHfcAktZHfXOU = 862516.0258606868;
    bool eeJRJOKvuixaK = false;
    bool CBkSYCuLRybkJzLS = false;
    double mUhuATJJotdiYU = -616258.1435281393;
    bool PNfCQ = false;

    return mUhuATJJotdiYU;
}

double kfYgzgp::nAOToYtuALCHz(bool QkUBzXtqliF, double odhViEaWpe, bool SwKMBkOf, double ibdagP)
{
    double MrePTdSSK = 502991.038758576;
    double xgKLwcEKfVJeVuld = -90859.7902627057;
    double JBXEb = 222251.61920771215;
    bool mjXZCYPI = false;
    int OUQHN = -386203139;
    string GkMtFhVolwG = string("lKxieJUjujINtQrjhELpwDLchVyUeLCBLlQaZeRqkpMpZgnZmbFPmcrzfVOGYdHVNNMEWTyykcgTqVqYAQoWgpXakMDhUQSmIFiGlTvMAncvbPWlojimjjZizLlALegttQYVPwzquuHDnkHpqGDtJAtxeQbgCKiMxGhdkkkuywrZNC");
    bool xTzBh = true;
    double wiWpHTmuGAuUOh = -483217.27719678945;
    string mWQAdhWu = string("yAXWdxMEjEWXanCtfSZqRaWgizdLPMbonHDJcTLwJfBorPOGbTCNqTEpXNsWMPjqwCCioJYEJRUOZvdUpghTKmuPIVXHbIafBxsbTjhigvljBvqsirtPpL");
    string TziOd = string("fIPDdLeQJLjBBUFHvHHTYfHrMQE");

    return wiWpHTmuGAuUOh;
}

double kfYgzgp::ZxIZGFw(bool fcBjY, string AJCxneelI, string tkNzXiQmQQk, double yKGYqZMOwVZTqqS)
{
    string msvCwzcLIOJvE = string("eyyksbZudsuIsPVMxKStqWgCB");
    double oEuvgbJ = -350775.915481911;

    for (int wcCxzJIZIVv = 704273168; wcCxzJIZIVv > 0; wcCxzJIZIVv--) {
        msvCwzcLIOJvE = tkNzXiQmQQk;
        AJCxneelI = AJCxneelI;
        yKGYqZMOwVZTqqS /= oEuvgbJ;
        tkNzXiQmQQk += AJCxneelI;
    }

    if (tkNzXiQmQQk >= string("lXxGwHIyCTNGsigrOURkghZgupDkfiZsJwLwWexpbfoWKEWyZxneoWYDywzqyotBcmoRLFxBtoLzqCZCBzWyFUnjZKTfVCMuuJEv")) {
        for (int PHpWVaRyDcPISuw = 165984569; PHpWVaRyDcPISuw > 0; PHpWVaRyDcPISuw--) {
            tkNzXiQmQQk = tkNzXiQmQQk;
            msvCwzcLIOJvE += tkNzXiQmQQk;
            tkNzXiQmQQk = tkNzXiQmQQk;
            msvCwzcLIOJvE += tkNzXiQmQQk;
        }
    }

    for (int UDRowEFeSKuAxC = 1836068679; UDRowEFeSKuAxC > 0; UDRowEFeSKuAxC--) {
        msvCwzcLIOJvE += msvCwzcLIOJvE;
    }

    if (yKGYqZMOwVZTqqS != 724636.1178034641) {
        for (int kkZYKXJwicncLMe = 38228901; kkZYKXJwicncLMe > 0; kkZYKXJwicncLMe--) {
            tkNzXiQmQQk += AJCxneelI;
        }
    }

    for (int DIEvZoKoClV = 2110986420; DIEvZoKoClV > 0; DIEvZoKoClV--) {
        oEuvgbJ /= yKGYqZMOwVZTqqS;
        oEuvgbJ *= oEuvgbJ;
        AJCxneelI = tkNzXiQmQQk;
    }

    return oEuvgbJ;
}

kfYgzgp::kfYgzgp()
{
    this->BMNDIjZra(false, string("VPRhWyOmHybHRbyiWaqaQzkAUgnLmCo"), string("gATr"), -289263.24111367273, -598379096);
    this->EqOQaCymV(527528.0276838879, false, false, -1203540668);
    this->LyNrlImEhk(string("tmcfFI"));
    this->ZHbuIEyv(-866097.5498155565, -66583520, true, false);
    this->sCTNNMhpaFYHiSR(-688575.1209529478, 740135.3915040054, -824912.0996953201, string("WAODLdwsidfjAhCqCKcXLWAyEvcPehKdCPEVZRNKkDrzItJLbDYOKVWqcXkaAXnOxqrbKMUdUWLKiDkqOELrknDgSrAaXXAuofYaUtQbUThTZqlpjKOsMpdnqIFbgqsWRPoUTaUGLTYtSCt"));
    this->AORcUfyZSYLazxZB(375772.23071822844, 715437.6577523225);
    this->lBMdCPSHWlsSaktG(string("gXcJvYNMjtdZGUnNrNuNnyakCoQVonvFrFLzBjkNWTYcgwPOnyKANDlBuIyyKeUfZYKrJsQWhmaLxlGtuWGGqvmIvXtRKCgkupTuKCUxiRMRuBFeqAfAyrfDKkNLyymUeybQtUukVvtjuFnxGnxQKGyKAHzKORcBuUwKRERhPNmmoVLvOJPTPELJxRJtBgGDSBwjgciRQKowPQISUevucpADOQJzuItwEAUfTjIsCnAXvMPXNjiiN"), string("tDjAMUFVmSgDsNFaFFuxSRjEgyUBPJrmoOsulTwnrAKeMUjiZiMdityfNybHEnJHvSYwUBaDRpWGuRKNblgG"), 564683674, -611161614, string("DMtucuPZiumhpIKNHOQrxWQMntveEJpiJyEnyIbvXEEepKCoBYmPzbXaqDSvUHdTpWfNQxwCQRQuaBlUJlzBfpYVlCDJgBaQvzkNFIenmEjLRUpvtAgxlrrfXhLSuJvbvWXtIrEPCcfKMSjIeOPBSpWtGgfErzNgdOvnfPaDmWFiniGRCmLVhhIOS"));
    this->GTtBIdmGmejNmOv(string("OGIgYyEMXaoTNvEXZWPHLYwYzlFhaxOxErrtQKlAHbOpLifZFMbapXJPykYhfuDbegkoXmhxBBNgnPHmBzmmryMSQiMAlWJqZnHhbHZojkFHNRwiJDHNqlQrcxsHeDjPxxBhLrwmivrJdurMgGswnSCnIpFYPVdRuppfPoYZaNwlLTgpzaDGegRQDSrFHUJvWBNtZqrvDpMWbnoTbGplWmlTRPBirk"), 564788.758666524, 1559418141, -592821167, true);
    this->nAOToYtuALCHz(false, 193119.68064765297, false, -550487.9306067905);
    this->ZxIZGFw(true, string("lXxGwHIyCTNGsigrOURkghZgupDkfiZsJwLwWexpbfoWKEWyZxneoWYDywzqyotBcmoRLFxBtoLzqCZCBzWyFUnjZKTfVCMuuJEv"), string("NVNtjlCPUOHHNeAmSOJvapZRrdoxrudOXIscvehZxMtsjPHbRgTRtvlsXFhadOGqOfYaNILppeBjrKPwoEsfwdhfAffxyuLXyxNaMmIyYKnQYziJtiwKxyWdLWmllHDDFtJbwMCYtEkvaJGyeEbVDnlQHxkobDPlXPgONuwlsHErhZcuEwfZAvilWNheUvLxZHrjBaAZZuEYuN"), 724636.1178034641);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TbZQZZNNZOtRZfMi
{
public:
    int rfMeQgdl;
    string RpPEj;
    int gedTZswxUY;
    int ZRUPBUD;
    double uHtcP;

    TbZQZZNNZOtRZfMi();
    int XafrlaPRc(int eltIDuQBoyvcOX, double BvdOhavuxnydT, bool ElAlMTvYpX, double bEyAulITSBcZ);
    int KbdoqtMLppwPHG(bool MLRYgZlj, string AbyXNLiw, string sgRFAucuJDVadf, string YrcSgVBSMBKVdtC, bool neOnUqL);
    double zSBSWiTlPN(double yxSFkFNavMXivY);
    double fTVeIm();
    int dLOjltxmyKf(double KgkefTLwRKatR, bool QuyomOvVXX);
    double LMYBrYc(int jxkHBJGHf, int AaoRSYQmjXCjlnp, string IOXrZNmrhsdMdbJT, bool xJnbKuYcn);
    void vwsyjpUpPijyrcqE(int OveKDuEPaqH, string zWCmLdVfMGGtAvf, double HyLlyEJoBBMHWh);
    double QDGVT(double ydvhod, double uzucHnxFClub, double fgVrXDuAVE);
protected:
    int rUboEiRhXb;
    int oNYBiGYeSXFCjK;
    string XeIHl;
    bool CrwDCRkBRhcfQ;
    string VemiBqPzBIFvaJ;
    bool ySTdjPZVcnEbl;

    int eSVJx(string Dxuxe, double wjveHggsSNaQkb, bool njkML);
    string oqWHJWiXzRaNCaH(int FotuuYZLuFH, string fZQhU);
    bool jSnEHChzar(bool RBCrvgc, bool owwLx, double xrIdDJzqvKmmAhA);
    void ztivUkvJZCUbMy(string WUuwUYLZl);
    double KBOGtsOXaz(int FvoxgvgwQ, bool UmKGstbxqbjhf, int zLlwPfdBMlRjNDw, double TkYguQSJMvrhdi, bool cMTkzqjVk);
    double FExPSAwHMS(double mmGyxK, double JFmugdoIrFoDWBWe, int EgPSLkAmKeuF, double jEnUHJr, bool ZchFdT);
    double ywJEpU(int FLycNwyfhCpqIY, string kwHdLj);
    int NMESzzVnoIHZ();
private:
    string xgapTVZQHaiwrGDS;
    bool YwhUFig;

};

int TbZQZZNNZOtRZfMi::XafrlaPRc(int eltIDuQBoyvcOX, double BvdOhavuxnydT, bool ElAlMTvYpX, double bEyAulITSBcZ)
{
    bool iCwTTsU = false;
    bool TxxmBmnhCBcHGuk = true;
    string bPUMnVZdphDkbLZi = string("YOQMDxffnAkJjnsLTWNbqwiEqwIpRrGYTYDPKfklktSrHDNTQzIgTgVYWrTdkwbsZChNpZudBrOBgxOnNuHCSoTUWevWUAjHwdja");
    bool gpqWl = false;
    bool vjmYpkdNYKlJkhO = true;
    bool cQqwJ = false;

    if (ElAlMTvYpX == false) {
        for (int jneJhPOIQA = 1279535482; jneJhPOIQA > 0; jneJhPOIQA--) {
            gpqWl = iCwTTsU;
            TxxmBmnhCBcHGuk = cQqwJ;
            vjmYpkdNYKlJkhO = ! vjmYpkdNYKlJkhO;
            cQqwJ = ! iCwTTsU;
        }
    }

    for (int PdxydY = 1339560296; PdxydY > 0; PdxydY--) {
        vjmYpkdNYKlJkhO = ! gpqWl;
        TxxmBmnhCBcHGuk = vjmYpkdNYKlJkhO;
        iCwTTsU = ! TxxmBmnhCBcHGuk;
        BvdOhavuxnydT /= BvdOhavuxnydT;
    }

    if (cQqwJ == true) {
        for (int bUjCQhMQMO = 1820152825; bUjCQhMQMO > 0; bUjCQhMQMO--) {
            vjmYpkdNYKlJkhO = ! ElAlMTvYpX;
        }
    }

    return eltIDuQBoyvcOX;
}

int TbZQZZNNZOtRZfMi::KbdoqtMLppwPHG(bool MLRYgZlj, string AbyXNLiw, string sgRFAucuJDVadf, string YrcSgVBSMBKVdtC, bool neOnUqL)
{
    bool LztVCUB = true;

    if (YrcSgVBSMBKVdtC == string("zkaLMTANMsQRAhaElkmXmlWJoaREpEglMRegTzlgrksarHxXkVyTVyaMugdreRMHalSSWnxoXWjRiqMYtwuBkCOBhiskeGzFsKRATxJJLtBpCpvPVAJoOU")) {
        for (int LgeIbOJQOYYWSjX = 262396642; LgeIbOJQOYYWSjX > 0; LgeIbOJQOYYWSjX--) {
            YrcSgVBSMBKVdtC = sgRFAucuJDVadf;
            YrcSgVBSMBKVdtC += sgRFAucuJDVadf;
            YrcSgVBSMBKVdtC = YrcSgVBSMBKVdtC;
            LztVCUB = neOnUqL;
        }
    }

    return 1817326227;
}

double TbZQZZNNZOtRZfMi::zSBSWiTlPN(double yxSFkFNavMXivY)
{
    double IHpysMio = -454726.9482600269;
    double MhytRs = 311863.7326207901;
    string mWzUlIgQdCQoI = string("eHDarGpFpUakKoGqdGXMtcVlTagawroDTxraNZTsgmKMmEbspERqTqyBxciCevxVqQUYNlZouNwmmgQFJtHTyWfalPQkEvMgvojFRTNiHUBZgMYatdRTmkcJaFeuWvIVbVYmmcFZBXPVoGwZzjZAJHXsYBVMrnuKBSBXeabYYkX");
    int rAayFuImZjUW = -1028936667;
    int zGFvbFPeSfBGvPJ = 993803504;
    int WfcEdcOWI = 1197360509;
    string QIcIFQWluLzADS = string("bsVmQfQsmxaNHUxHwliByTDdmPXtWlCssciqagjDAdYBpguNpgMexFVjtMqDftzSmvzzXApLxNAlozhAwMOFOCVyOSkKugcSzSkXINDXORIsAAbGptAUnJSfdHgrgaWisLXQmidTjzucTowPPJUpkaGTOGGUsLOuKuZKMVHvTpmwWHx");

    if (MhytRs <= 627529.0584317169) {
        for (int ZhbKW = 1970424361; ZhbKW > 0; ZhbKW--) {
            MhytRs *= yxSFkFNavMXivY;
            QIcIFQWluLzADS = mWzUlIgQdCQoI;
            yxSFkFNavMXivY /= IHpysMio;
            mWzUlIgQdCQoI = QIcIFQWluLzADS;
        }
    }

    for (int BgOmLWgUPw = 639450948; BgOmLWgUPw > 0; BgOmLWgUPw--) {
        mWzUlIgQdCQoI += QIcIFQWluLzADS;
        IHpysMio += yxSFkFNavMXivY;
    }

    for (int tJwiJBD = 1123328905; tJwiJBD > 0; tJwiJBD--) {
        QIcIFQWluLzADS = mWzUlIgQdCQoI;
    }

    if (zGFvbFPeSfBGvPJ < -1028936667) {
        for (int ciYedzkWOmSD = 922518149; ciYedzkWOmSD > 0; ciYedzkWOmSD--) {
            yxSFkFNavMXivY *= yxSFkFNavMXivY;
        }
    }

    for (int BIVVVAmHARu = 863884256; BIVVVAmHARu > 0; BIVVVAmHARu--) {
        continue;
    }

    if (rAayFuImZjUW > 993803504) {
        for (int vZaipsYo = 308850238; vZaipsYo > 0; vZaipsYo--) {
            MhytRs += MhytRs;
        }
    }

    return MhytRs;
}

double TbZQZZNNZOtRZfMi::fTVeIm()
{
    double VkfDLf = 40610.86783807188;
    int WBKMthZvazvh = 1025771129;
    bool TxwfggFIJdz = false;
    bool xRfQbjRrq = false;

    if (WBKMthZvazvh == 1025771129) {
        for (int UVHjSELVWYxUF = 951519394; UVHjSELVWYxUF > 0; UVHjSELVWYxUF--) {
            continue;
        }
    }

    for (int ezVXnJ = 947380639; ezVXnJ > 0; ezVXnJ--) {
        xRfQbjRrq = ! TxwfggFIJdz;
    }

    for (int tdkSdUUERn = 1330648366; tdkSdUUERn > 0; tdkSdUUERn--) {
        continue;
    }

    for (int YnLAPdPLmHTlqY = 1922873189; YnLAPdPLmHTlqY > 0; YnLAPdPLmHTlqY--) {
        TxwfggFIJdz = ! TxwfggFIJdz;
    }

    if (xRfQbjRrq != false) {
        for (int jQJIm = 803245342; jQJIm > 0; jQJIm--) {
            TxwfggFIJdz = ! xRfQbjRrq;
        }
    }

    return VkfDLf;
}

int TbZQZZNNZOtRZfMi::dLOjltxmyKf(double KgkefTLwRKatR, bool QuyomOvVXX)
{
    double AgbLUBBhMNgcL = -270054.0636359355;
    double CvLhdDuitEKWha = -641512.0200647869;
    double DNXPrqbL = 953780.4712022067;
    int OHSCcYVZwqWduc = 1783145583;

    for (int BvebHqf = 1247873521; BvebHqf > 0; BvebHqf--) {
        continue;
    }

    for (int UTcraqde = 1632968450; UTcraqde > 0; UTcraqde--) {
        DNXPrqbL = AgbLUBBhMNgcL;
        KgkefTLwRKatR /= KgkefTLwRKatR;
        DNXPrqbL /= AgbLUBBhMNgcL;
        KgkefTLwRKatR += DNXPrqbL;
    }

    for (int ogQRBpbYSvn = 655293022; ogQRBpbYSvn > 0; ogQRBpbYSvn--) {
        CvLhdDuitEKWha -= KgkefTLwRKatR;
    }

    if (AgbLUBBhMNgcL == 953780.4712022067) {
        for (int pyytbiESClKLlf = 942852224; pyytbiESClKLlf > 0; pyytbiESClKLlf--) {
            continue;
        }
    }

    if (CvLhdDuitEKWha <= 953780.4712022067) {
        for (int aoWZbpk = 1796654490; aoWZbpk > 0; aoWZbpk--) {
            continue;
        }
    }

    for (int TtFbUDnsUQ = 446475005; TtFbUDnsUQ > 0; TtFbUDnsUQ--) {
        KgkefTLwRKatR += KgkefTLwRKatR;
        CvLhdDuitEKWha -= KgkefTLwRKatR;
        CvLhdDuitEKWha = KgkefTLwRKatR;
        CvLhdDuitEKWha *= KgkefTLwRKatR;
        KgkefTLwRKatR = CvLhdDuitEKWha;
        CvLhdDuitEKWha -= CvLhdDuitEKWha;
        AgbLUBBhMNgcL *= KgkefTLwRKatR;
        KgkefTLwRKatR = CvLhdDuitEKWha;
    }

    return OHSCcYVZwqWduc;
}

double TbZQZZNNZOtRZfMi::LMYBrYc(int jxkHBJGHf, int AaoRSYQmjXCjlnp, string IOXrZNmrhsdMdbJT, bool xJnbKuYcn)
{
    bool oLNgml = false;
    bool EtJZHpqinpIvvRi = true;
    int zcaHsWKi = -941554852;
    string mZISOWOHNm = string("zybhaTEeYrEqKNEZPtlFrGIMcCEqppIHLppayKnPKJQBgvyIZlrXKENjdOjBrYPVxpuecVKOjuQUgAtiwKaMjmzoRucNDCNztWFhcRispzpZrtNhpIXrVENMNjLcHZAmTTFheVtMuiwfyQbBWytBnuQFsAEGtOasXSLIjcQbUZPzAC");
    string cEzySIqqYdFa = string("tYugPwjOcqnDCc");
    double SCvoyPO = -160171.52568992673;
    bool ImMCngKsM = false;
    string AajTTzMwHVEnL = string("gAepBPPvWdDShgLPFsWPqwZbmKPPRqNytKSunqxrbLHcHTebMzmlAMkjBfxVNHXoKxJpnuTzNMaswyIiuvgUhKvSguQvZGZegrvnJpHGABOKskpzwLUvuMKTVlyofRYceNMxjcxZrnoELYtCzftmoGCXigcpNVGuVdiSkYFyOUWppq");
    string ukDxuUrkpmum = string("qZHlugNgLIltbSDeUiAKsiirJrQggXkUSYqxGPoTzFXXStPZHdHOufaRqjXXkxmUKwxkdjvjRzehbNfXvuBNJZhwkZeerDZayZpCdx");

    for (int KhnVgcPdkcLE = 379554798; KhnVgcPdkcLE > 0; KhnVgcPdkcLE--) {
        IOXrZNmrhsdMdbJT = IOXrZNmrhsdMdbJT;
        jxkHBJGHf += AaoRSYQmjXCjlnp;
    }

    return SCvoyPO;
}

void TbZQZZNNZOtRZfMi::vwsyjpUpPijyrcqE(int OveKDuEPaqH, string zWCmLdVfMGGtAvf, double HyLlyEJoBBMHWh)
{
    string oIhIeXkEe = string("PzTYRTexCyhIzKKsEKifXLDykIyNTAQjLXlWEThQkacvHdRsqUzsjgWdUiCYDnfrwbHOiDZQGNOHDOCGTgQbJBSrVRcOgXyfDepEiUVMCcVAMWLYJyRnNXFJdBgiezxaAhqRrHOiRoxplSfgsO");
    bool tjWdemiJlBgWQ = false;
    bool VcdukEEPSCj = true;
    int SQOMN = -1467042809;
    string LHmRxFwlCzYlB = string("DnSXReypOfdKuDVULICYgyOFzgQjCbNxjsypShHeTjQqYLCfCfDlkMBsQNiOjcXKhqTRxzvpSijIBWpGqDHVlqUTYynBjdGedmtnifEwJNhaOKfUYOzDvNjUwPlHPhAOSOjTszWCjmcWlLqDQoiJjzhZLLAiKAxxMRxZDAZxgCZCbriyLhuVCkjdLA");
    double fhpteErc = 990072.0199236288;

    if (oIhIeXkEe >= string("DnSXReypOfdKuDVULICYgyOFzgQjCbNxjsypShHeTjQqYLCfCfDlkMBsQNiOjcXKhqTRxzvpSijIBWpGqDHVlqUTYynBjdGedmtnifEwJNhaOKfUYOzDvNjUwPlHPhAOSOjTszWCjmcWlLqDQoiJjzhZLLAiKAxxMRxZDAZxgCZCbriyLhuVCkjdLA")) {
        for (int qazgpHtNd = 141804033; qazgpHtNd > 0; qazgpHtNd--) {
            continue;
        }
    }

    for (int eqzOjb = 1768679231; eqzOjb > 0; eqzOjb--) {
        continue;
    }

    for (int IHIEKmJGI = 1192680946; IHIEKmJGI > 0; IHIEKmJGI--) {
        LHmRxFwlCzYlB += LHmRxFwlCzYlB;
    }

    for (int iLUEvyfmhUsF = 588218493; iLUEvyfmhUsF > 0; iLUEvyfmhUsF--) {
        HyLlyEJoBBMHWh -= fhpteErc;
        OveKDuEPaqH *= SQOMN;
        SQOMN += OveKDuEPaqH;
    }

    if (fhpteErc > 271617.6222949877) {
        for (int iYTfn = 808918784; iYTfn > 0; iYTfn--) {
            continue;
        }
    }

    for (int VYwwzPCETVW = 31049436; VYwwzPCETVW > 0; VYwwzPCETVW--) {
        VcdukEEPSCj = tjWdemiJlBgWQ;
        SQOMN /= SQOMN;
        VcdukEEPSCj = ! tjWdemiJlBgWQ;
        zWCmLdVfMGGtAvf += LHmRxFwlCzYlB;
    }

    for (int FwalwJ = 376046077; FwalwJ > 0; FwalwJ--) {
        fhpteErc *= HyLlyEJoBBMHWh;
    }
}

double TbZQZZNNZOtRZfMi::QDGVT(double ydvhod, double uzucHnxFClub, double fgVrXDuAVE)
{
    bool flKQNB = false;
    double gBpVGVps = 998570.892097828;
    int WEtRH = -1247888762;
    int VSUPHqncS = -1624324308;
    bool YoFxM = false;
    bool sjTWTlcK = false;
    bool AJOQVsYrOYg = false;
    bool WOQGYyaP = true;
    double IFOqmnqLEENoyuS = 981582.4221082476;
    double ZSoszJAdIABlV = -657412.437108117;

    for (int JKKNwRZXZUbgua = 1241540941; JKKNwRZXZUbgua > 0; JKKNwRZXZUbgua--) {
        AJOQVsYrOYg = ! YoFxM;
        AJOQVsYrOYg = ! WOQGYyaP;
        ZSoszJAdIABlV = uzucHnxFClub;
    }

    if (fgVrXDuAVE <= 981582.4221082476) {
        for (int vKHzGckl = 1088142006; vKHzGckl > 0; vKHzGckl--) {
            sjTWTlcK = flKQNB;
            IFOqmnqLEENoyuS *= gBpVGVps;
        }
    }

    for (int DPdskkXlTemo = 1254258235; DPdskkXlTemo > 0; DPdskkXlTemo--) {
        YoFxM = flKQNB;
        IFOqmnqLEENoyuS += fgVrXDuAVE;
        WOQGYyaP = YoFxM;
        AJOQVsYrOYg = YoFxM;
        flKQNB = WOQGYyaP;
        ZSoszJAdIABlV = fgVrXDuAVE;
        gBpVGVps += fgVrXDuAVE;
    }

    return ZSoszJAdIABlV;
}

int TbZQZZNNZOtRZfMi::eSVJx(string Dxuxe, double wjveHggsSNaQkb, bool njkML)
{
    double kbnoaAewAeWB = -571728.4494211369;
    bool UYwwpFG = false;
    int hTFUHKFOmSOCh = 213478974;
    string zttdDguDhzegoOxH = string("gtnnLmupfMQTdqDrMhLGOReXHuedIGLGCubBPguyUzzBuvFTTdNrPKzlrLNFXgBKFvDnAQOPTvrfmywfNTJXKtApbnsnzLYFPJunUWLoJUzGqDHJVOheLYwNzUecidOaJmICYRKpHRZPFkgTdrXCzeuXhbyFxYpAskEMSInHOPoCkNrdnGrVVgYIMGh");
    double MpDRluyrvfjJ = 342469.7151068607;
    double AWkMkmuUTSlCp = -71052.57866673234;
    string AJLqSNsb = string("iSrgkbouoQQzfGGLt");
    int vssYQjBizyZJ = 1232874752;
    double wanTeAO = -891764.3641761475;

    for (int pfDqxacOHmyY = 1092781540; pfDqxacOHmyY > 0; pfDqxacOHmyY--) {
        AWkMkmuUTSlCp = wjveHggsSNaQkb;
    }

    for (int tdPMHmZrugvUlmH = 899621434; tdPMHmZrugvUlmH > 0; tdPMHmZrugvUlmH--) {
        vssYQjBizyZJ += vssYQjBizyZJ;
    }

    if (zttdDguDhzegoOxH != string("IdQocDMCffVlWEVmeRhOwWeaaYKAWDoQFLAJoDVwKeBjpVpRnbqNqkwEzlReJdLQyuCwEdsKqVeiVRfApNBDGwdnGwmfiPAyd")) {
        for (int QAZyFkdaLe = 591005713; QAZyFkdaLe > 0; QAZyFkdaLe--) {
            hTFUHKFOmSOCh = vssYQjBizyZJ;
            AWkMkmuUTSlCp = wanTeAO;
            AJLqSNsb += zttdDguDhzegoOxH;
            wanTeAO = wanTeAO;
            njkML = njkML;
        }
    }

    for (int uOpjeXRAyiXODk = 1186496436; uOpjeXRAyiXODk > 0; uOpjeXRAyiXODk--) {
        wanTeAO += wjveHggsSNaQkb;
    }

    for (int KZEDumfbgvid = 399272299; KZEDumfbgvid > 0; KZEDumfbgvid--) {
        continue;
    }

    return vssYQjBizyZJ;
}

string TbZQZZNNZOtRZfMi::oqWHJWiXzRaNCaH(int FotuuYZLuFH, string fZQhU)
{
    int HEVpYfFTabhmTdT = -1980860324;
    double LXPrytGkglijnURM = 1014832.984131541;
    int XdyMmMZx = 532167361;
    double otwlAWXvbu = 252885.04230558753;
    double gFLCKjIOKDAvG = -1038208.5875800962;

    for (int BLXbICiPwwbcDI = 2044631569; BLXbICiPwwbcDI > 0; BLXbICiPwwbcDI--) {
        otwlAWXvbu += LXPrytGkglijnURM;
        otwlAWXvbu *= gFLCKjIOKDAvG;
        otwlAWXvbu -= otwlAWXvbu;
        otwlAWXvbu = gFLCKjIOKDAvG;
    }

    return fZQhU;
}

bool TbZQZZNNZOtRZfMi::jSnEHChzar(bool RBCrvgc, bool owwLx, double xrIdDJzqvKmmAhA)
{
    int tCTssv = -532482104;
    int UNNUxppbRywYyL = -545028334;
    string TYEpCxlYLaak = string("IOcaLKE");
    bool pqYrdfMtrM = true;
    bool flYzfCwRbRwepfke = true;
    double MBnJArVfDsI = 655127.0260640937;
    double QgNOxjXK = 619547.7453114564;
    double nncweIRRX = -174634.12660102607;
    int wXWlAlCzfJmnrHpi = 1709780842;

    for (int dbIyvPZl = 1466584292; dbIyvPZl > 0; dbIyvPZl--) {
        continue;
    }

    return flYzfCwRbRwepfke;
}

void TbZQZZNNZOtRZfMi::ztivUkvJZCUbMy(string WUuwUYLZl)
{
    int IRpYNHKKzAoJXj = -1279913392;
    double HlTAWRvdNE = 852656.2819506453;
    int SwaWidinPx = -914802904;
    int vgbQxhhaDY = -752057656;
    int sJxkj = -1919284693;
    bool rubgaeolKedl = true;
    double xHKJaS = -847571.620951627;

    for (int dECkzcxugJbrY = 68794752; dECkzcxugJbrY > 0; dECkzcxugJbrY--) {
        vgbQxhhaDY += sJxkj;
        xHKJaS /= HlTAWRvdNE;
    }

    for (int gqpEyuNzVK = 59832523; gqpEyuNzVK > 0; gqpEyuNzVK--) {
        vgbQxhhaDY *= SwaWidinPx;
    }

    if (IRpYNHKKzAoJXj != -752057656) {
        for (int MwbsgaZ = 2040855375; MwbsgaZ > 0; MwbsgaZ--) {
            rubgaeolKedl = ! rubgaeolKedl;
            IRpYNHKKzAoJXj -= vgbQxhhaDY;
        }
    }
}

double TbZQZZNNZOtRZfMi::KBOGtsOXaz(int FvoxgvgwQ, bool UmKGstbxqbjhf, int zLlwPfdBMlRjNDw, double TkYguQSJMvrhdi, bool cMTkzqjVk)
{
    bool NEyGVBnGMg = false;
    bool RwbyHWGbDXwVS = true;
    string TQHJN = string("SIneUrEAWfVbOMKPLSfWvZMkvbtiiBKaqShwZnGdsGvLPfIEtCFfTTPUEODVBDEBrCMrNsFgqYNnGbfZLjIVQaKMdgsHzU");
    bool YNBZMlZzpOc = true;
    double INnoukHaUxL = -1030193.0447299159;
    bool wbaCsRrDrxx = true;

    return INnoukHaUxL;
}

double TbZQZZNNZOtRZfMi::FExPSAwHMS(double mmGyxK, double JFmugdoIrFoDWBWe, int EgPSLkAmKeuF, double jEnUHJr, bool ZchFdT)
{
    string IgygviWWTlMCC = string("JLAPqPkVvHtDhqqluynvnTXrKVzqQLEfWYMyPfhgVzhJWpfhfKrlphhThykvJabZwXHZTUYuaLKgLiEpySHHEPuUqWHCWlokJHUXTsMsYkHctxvhQIkDcEfxMRXgQYDsrpSOQpwUCHwGMFSMNTtUZLF");
    string XiMKfcvbN = string("RKusXlGKZAzvbWEqnwGIOSfsbkuTeJNnfVguanCGGrXEeDGguvJVbjneHBtdMXQGqZKzDPRydbljqcfGJVUzdLsyhbApmXMeuxrMTvIUACeMUHtLscRJeHPLNwWPDudaVlcSSbVobRYkEiBMFySnatIaTQxKOIQ");
    bool cEEjulryYh = true;
    bool MJQJzcWTu = true;
    string rNgNUy = string("seqlclmTOMVpwTcIsXLOKCQeSmztippUtjGCiCaM");

    for (int BKZZyIXpL = 842389777; BKZZyIXpL > 0; BKZZyIXpL--) {
        rNgNUy = XiMKfcvbN;
        JFmugdoIrFoDWBWe /= JFmugdoIrFoDWBWe;
        mmGyxK -= JFmugdoIrFoDWBWe;
        rNgNUy += rNgNUy;
        IgygviWWTlMCC += XiMKfcvbN;
    }

    for (int QCMpbEcgpnJOzpO = 442913542; QCMpbEcgpnJOzpO > 0; QCMpbEcgpnJOzpO--) {
        continue;
    }

    for (int bDvXevIB = 30774396; bDvXevIB > 0; bDvXevIB--) {
        ZchFdT = MJQJzcWTu;
        cEEjulryYh = MJQJzcWTu;
        XiMKfcvbN = rNgNUy;
        rNgNUy = rNgNUy;
        mmGyxK += jEnUHJr;
    }

    for (int eulgKAuMgoKKaQam = 1994878770; eulgKAuMgoKKaQam > 0; eulgKAuMgoKKaQam--) {
        JFmugdoIrFoDWBWe += mmGyxK;
        mmGyxK = mmGyxK;
        XiMKfcvbN += rNgNUy;
    }

    return jEnUHJr;
}

double TbZQZZNNZOtRZfMi::ywJEpU(int FLycNwyfhCpqIY, string kwHdLj)
{
    bool VrSemWOx = false;
    int aavAcjdlnbvKeCAF = 1817499315;
    string FtEpOIofCgOPo = string("fFiAGcjPqFtZmcufGxHrhtYfvjzIExrXtFpBheNUYPNDazGUnohHBnxnZqHb");
    bool SWFcN = true;
    int wriBZxpLnE = -1677686808;
    string Izgow = string("xUEPiiVxArbFIEKKIfWSGvDLUunTCwoIAUybtVkojQTSwqPunHigqovHDWHxbXfIqQYXrzdqPtppTEBAFZmTSDFfIHInpJOcaSbaGuyQQXakfzFPsHNzDBjqdBswiouijyAIizbQjclbdAmxHzCbVUiaQbHXWqjkHebMMmCMFjTmgvPZPTGBLOcGKwmVIGuVqwEqgMfFYAXMIYnq");

    if (FLycNwyfhCpqIY <= 1817499315) {
        for (int AXUEQ = 921032410; AXUEQ > 0; AXUEQ--) {
            SWFcN = ! SWFcN;
            kwHdLj = FtEpOIofCgOPo;
        }
    }

    if (SWFcN != true) {
        for (int rllxEoKCbVOohpcu = 549710231; rllxEoKCbVOohpcu > 0; rllxEoKCbVOohpcu--) {
            FLycNwyfhCpqIY = wriBZxpLnE;
            Izgow = kwHdLj;
        }
    }

    return 239401.26459161317;
}

int TbZQZZNNZOtRZfMi::NMESzzVnoIHZ()
{
    string fgfVUpNo = string("znTulLljcwApHMuxlyvmyGRtoDUIxJBFsSIYKnOQDdvsdcwZlvRWmWXCEwmkcVOBRglGGXjOXomygVqjlsNliRZRGuVltkXKZCEPb");
    double gypdOpfjNPPtYi = 494402.5949081991;
    string UYAJCFbRsyp = string("vqRpVmAyfCEuHAdiHRaxdwaWchWhRbaJjGmA");
    bool okgrt = false;
    int XLAOYPwlAM = -1898571673;
    double QnRKAZHSFhjArVo = -760442.9511710585;

    for (int FcPTPrikEwwUyRkk = 379938308; FcPTPrikEwwUyRkk > 0; FcPTPrikEwwUyRkk--) {
        okgrt = okgrt;
    }

    return XLAOYPwlAM;
}

TbZQZZNNZOtRZfMi::TbZQZZNNZOtRZfMi()
{
    this->XafrlaPRc(1168828354, -245922.99323709507, false, -405709.52475499886);
    this->KbdoqtMLppwPHG(true, string("hSDqftfgKZmzxDLLdaWncZjNofkpGAqFkePMGOqSMFUhCCJXCmWPPvuoFuyDAMbnUoZhoSyhXtskpDCkhpSCKrAMDhZziGhvQPBVnxozBJRuurwRSozWtwDHmmgQupKdyDzyGUTmQZqnmfdarfUqzrbc"), string("zkaLMTANMsQRAhaElkmXmlWJoaREpEglMRegTzlgrksarHxXkVyTVyaMugdreRMHalSSWnxoXWjRiqMYtwuBkCOBhiskeGzFsKRATxJJLtBpCpvPVAJoOU"), string("LYcQudqklSWMQXYVvlEHMCycedqawwyIvFqhlcCHCfmbEKjpQxNUTZYzHjNbMsIoETFSNaEXeZywODakTWLtIJmgTjKbEjLsRTuFCwvVQQFwPKGw"), true);
    this->zSBSWiTlPN(627529.0584317169);
    this->fTVeIm();
    this->dLOjltxmyKf(624561.794154006, false);
    this->LMYBrYc(-228629442, 1679702392, string("ngkOZkuLzytBLUTgllqlLXcUcfnUuQSiVXENqizTBBMVhVMqASrwktMmKhSnYDuafLbZIwUarFJGVNVHCshYcgBPMnggHbwuASVPCViOISpkzNtswiUdZQiUBZpSkNyDVgiizpHnAXBsAXDqFnDvrZTpEEzPCkpiLiHSBbTAhQGBhwbRoOJvzNyRdrIisLfVJZmTljQVpm"), true);
    this->vwsyjpUpPijyrcqE(1398267372, string("nIdwMKJMAfWSEQNIkDbNjSftFRBpbxIs"), 271617.6222949877);
    this->QDGVT(77814.2139912712, 882420.1569852252, 157644.7630985461);
    this->eSVJx(string("IdQocDMCffVlWEVmeRhOwWeaaYKAWDoQFLAJoDVwKeBjpVpRnbqNqkwEzlReJdLQyuCwEdsKqVeiVRfApNBDGwdnGwmfiPAyd"), -782421.9103600294, true);
    this->oqWHJWiXzRaNCaH(1714956972, string("QqJPIxCbaYEtekHPHRVvJrAtryRkJ"));
    this->jSnEHChzar(true, false, 473070.77487058233);
    this->ztivUkvJZCUbMy(string("kBUcAwpelMqDZTqjmWsrbwhINWfaaLZhgDcGjahGdvpVlDqOdArXxQIsChHnpqwFUBawhRXsZdUZAejdcWUyDYrhdWWaLihV"));
    this->KBOGtsOXaz(-184048584, true, -1815810876, 625376.5784121188, true);
    this->FExPSAwHMS(-390644.02263312123, 565254.5103692327, -841879559, -513931.83477123757, true);
    this->ywJEpU(-1331459149, string("gMRbKJQyISJOuuOVjYhIUQSztPFXbEtpSvsPorGagqqiXxPONTBRyhMXatAPziYpMDQRxMVvFFznFPHhzDsTDZdANCcPRptduIPYoNUvIXHovNcSeolElTnCHYDwfjDnnCaqDXqVByuvTtkXhJqfxXUGJuCpstoMbxrFHsKCAFmweNFJgWtCmkoqOtcFMlcLQnlFMtsJyvZwzDisulFdsh"));
    this->NMESzzVnoIHZ();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bFxNNG
{
public:
    bool wlXuiQxnukKT;
    int vxqNVCQGz;
    double SpUXXidvc;

    bFxNNG();
    int duLaFYsG(int vqbjrMLBMuixGg, bool JRSkVQoteZzg);
    bool JPNkyaWYciXrImh(double pWFVJYl, double lnTRNMBavmmM, double XEBUuPqXHoTlk);
    double cGVRQyttPWOW(double tgUwUKGg);
    void UbUAepOzvKTwEE(string ZZBEnQ, string tfDLFZjZW, string dgWwKvp, double dJoFATeYuRwh, bool lwITfBdoP);
protected:
    string gXMvbctPNKahsApt;
    bool rrLaHkIAmcmus;
    double QxhPDlFfpXOMh;
    string zjnsNOVaHDS;
    bool GLQpJJnClzqL;
    double sIdAGulHt;

    int IBKnh(bool LXBnKbsAjJJIKYmY, string AmLkPeQFFjxhx);
private:
    bool KptOtn;
    double ZoyxLdrRhqwY;
    int npfXKxIyZ;
    bool xbVNORxg;
    string oYjeyxKR;
    string hItPANC;

    string cWpNWnZMtlOF(string FYXQlerHQ, int qugDAbNztIvx, string QypZOItWfrzFl, bool XlxZWSVuyPE);
    double EPfmHZiDkFL(double HmFkgXdGbjxnHn);
    double qxwBiQJa(string IpqrvNaCP, bool dMUUPu);
    int TSPAkNH();
};

int bFxNNG::duLaFYsG(int vqbjrMLBMuixGg, bool JRSkVQoteZzg)
{
    double XCRJyJRl = -304867.8389544412;
    double GRjoS = -504094.2970566766;
    bool DNzdAlpyUnzPG = false;
    int gQYvyusIE = -1632135541;
    string XymuB = string("ITtHHbUkoKhxCvQeRmdWJGSDlrwsWRsMlXFvDOOZrupGuBLniWJuLxVXYwkKXYexXkSEbUPlivLNtQeWjdkXttqTJBjvySSWkTbJKBpdfEybP");
    double SFqslwCbBAEb = -116552.04438501739;
    string PArtt = string("NwDeAhzOhoNfxImiwGMUjQtmdxYbrPbdDDlriDAJeEFNeirBovhYZSsjdhOPAvoHSeiBBGEfsOBrxflLtDSuGwWEWoqFhOwVIsxrIoaDQwNOLneM");
    double MIaoZ = 37504.62572177009;
    int GLkbxxPgdQTSADM = -867944036;
    string SxetmIKOmqkNTWX = string("bDyXwxWvbLnETbcNyfXBSCCswUFoYwwHNpsdHgOYNiSHDNbqupmcbxzBsXdHuKlslZPUnHhHRbfdNjNcFAwAXmalWNwewpPBjSmamipzjVBkyRcAqWLWQujzhmmtihfkxyLZZKlNaxvLzZiXnwZ");

    for (int DWrJWuKwm = 1266007661; DWrJWuKwm > 0; DWrJWuKwm--) {
        GRjoS += MIaoZ;
        MIaoZ += SFqslwCbBAEb;
    }

    for (int YxYnlsgQQq = 579607881; YxYnlsgQQq > 0; YxYnlsgQQq--) {
        vqbjrMLBMuixGg *= gQYvyusIE;
        gQYvyusIE -= gQYvyusIE;
    }

    return GLkbxxPgdQTSADM;
}

bool bFxNNG::JPNkyaWYciXrImh(double pWFVJYl, double lnTRNMBavmmM, double XEBUuPqXHoTlk)
{
    bool tIqPcbGJAlxY = true;
    string zkLVuXtnL = string("tmJNdexQrnWEdlrYSGJiQVxKApXZwYHMkYpRiUrejdZkCxiFfOlIfbjQYiunGSAc");
    int RrhNSHlJdydLZ = -1216280087;
    bool oebzhKbynvrgx = true;
    bool CBKCLfXZ = false;
    bool izMvWDtSTkYM = false;
    double tbgmjDgvYcdmLLQ = -606823.4745539214;
    bool OFhUMAs = false;
    int zfaEzCWL = 610020983;

    for (int adpdlgI = 1462652181; adpdlgI > 0; adpdlgI--) {
        tbgmjDgvYcdmLLQ *= lnTRNMBavmmM;
    }

    if (tIqPcbGJAlxY == false) {
        for (int IxxCFFPes = 793063254; IxxCFFPes > 0; IxxCFFPes--) {
            continue;
        }
    }

    for (int EewJlVsIKwS = 325601859; EewJlVsIKwS > 0; EewJlVsIKwS--) {
        lnTRNMBavmmM = tbgmjDgvYcdmLLQ;
        izMvWDtSTkYM = ! oebzhKbynvrgx;
        pWFVJYl *= pWFVJYl;
        oebzhKbynvrgx = OFhUMAs;
        oebzhKbynvrgx = ! OFhUMAs;
    }

    if (tIqPcbGJAlxY != false) {
        for (int sfMVZfmw = 1815674299; sfMVZfmw > 0; sfMVZfmw--) {
            lnTRNMBavmmM *= XEBUuPqXHoTlk;
        }
    }

    return OFhUMAs;
}

double bFxNNG::cGVRQyttPWOW(double tgUwUKGg)
{
    int kZEIgLtEQJjtimyn = 1135186222;
    bool yxKSoyq = true;
    bool BevdDOUgpE = true;

    if (yxKSoyq == true) {
        for (int vUTOkzi = 1503071530; vUTOkzi > 0; vUTOkzi--) {
            kZEIgLtEQJjtimyn += kZEIgLtEQJjtimyn;
            tgUwUKGg -= tgUwUKGg;
        }
    }

    if (yxKSoyq == true) {
        for (int SbOBOKhScIVHk = 1405765277; SbOBOKhScIVHk > 0; SbOBOKhScIVHk--) {
            BevdDOUgpE = yxKSoyq;
            yxKSoyq = ! yxKSoyq;
        }
    }

    if (kZEIgLtEQJjtimyn > 1135186222) {
        for (int TmmlYhdPeldk = 652866584; TmmlYhdPeldk > 0; TmmlYhdPeldk--) {
            yxKSoyq = ! yxKSoyq;
        }
    }

    if (tgUwUKGg != -389934.5810695815) {
        for (int ajoePOT = 1406559069; ajoePOT > 0; ajoePOT--) {
            yxKSoyq = yxKSoyq;
        }
    }

    if (yxKSoyq != true) {
        for (int LgBYYzc = 885233397; LgBYYzc > 0; LgBYYzc--) {
            tgUwUKGg += tgUwUKGg;
            BevdDOUgpE = ! BevdDOUgpE;
            yxKSoyq = ! yxKSoyq;
        }
    }

    return tgUwUKGg;
}

void bFxNNG::UbUAepOzvKTwEE(string ZZBEnQ, string tfDLFZjZW, string dgWwKvp, double dJoFATeYuRwh, bool lwITfBdoP)
{
    bool VahcxtyeAEvYVC = false;
    bool PbMcrwvRle = true;
    int ouuvhPppvRKHX = -1149515625;
    int OphNDUI = 1604943982;
    double EwJposAoIp = -182951.11438614567;
    double RbeqkI = -880425.50607179;
    bool NDAJvyGFvIs = true;
    double EYCeXRuwnpO = -309930.34025480703;

    for (int yLUnhKiRqLpXDd = 961357398; yLUnhKiRqLpXDd > 0; yLUnhKiRqLpXDd--) {
        continue;
    }
}

int bFxNNG::IBKnh(bool LXBnKbsAjJJIKYmY, string AmLkPeQFFjxhx)
{
    int yXTfCHvBNVN = -853043834;
    string wEPjmezizQCV = string("evAHNCGumTJRtzHqxeQbcbuuFsIdusewjClBGzuzrbJujFCLnNGbdueOCVgxPKWiff");
    string AMSpzcBDcDRTtX = string("ShzxHxJfdkqKjtAhlXYCCIUXrqGFiEesJjQYSKyhVarzohdkdaFhYqunTVyaoSeRSQdWJvUeqeuFRaOVtzaLzINSJpPoJnChCCZgllSzEGHigRUuFEjtZdnrWmKnwQnyfaQmSNuNNSmKhenXfqENqtHZzzjHcnMaYlsymIkCJydIGgViPDJuDOcHOhTOCe");
    double dAzqmbw = -829975.7500340793;
    int ryhwswH = 29468904;

    return ryhwswH;
}

string bFxNNG::cWpNWnZMtlOF(string FYXQlerHQ, int qugDAbNztIvx, string QypZOItWfrzFl, bool XlxZWSVuyPE)
{
    bool CyYdDzYeLv = true;
    string ivAqqJ = string("GoHoWhBVIJtbcvLVVxBzrLBUZcOLVnUqSgrHGJewjnDyXTrpOYgdjBBdvmhsEmTOMaSJdDiVMWWKAbbNaZHYDroXSdhBaerlxbtdyNYKvKiWGYFRSsSUhLNcKZOpYpssyiwfXobwtvAfDhfDjosIJllasYowUbUWYsRkSoisxkqcuOZAaxdmbxDbaBfzfOJRkrLotXgbCdewJBoXLIbXhqNyldDzbPnZnTVaeyjtOG");
    bool mBLbHzjaPIK = false;
    double DDQveLbuwT = 228238.4466112051;
    string eyIsVvyHbprESYkR = string("qSseklBjpWJDbEuareKASmTJKPqXtOlhgQrAyIBtqPhifUzARIJlgmrVCiQgDbvBDVxlshwywAqoNicSZvaRftqftESG");
    bool AiiqJvmtrcQ = false;
    bool TeFZI = true;

    for (int zIJMJuatCQDi = 1743045094; zIJMJuatCQDi > 0; zIJMJuatCQDi--) {
        eyIsVvyHbprESYkR = eyIsVvyHbprESYkR;
        DDQveLbuwT -= DDQveLbuwT;
    }

    for (int ONkDOuFEqqGulwsV = 549888432; ONkDOuFEqqGulwsV > 0; ONkDOuFEqqGulwsV--) {
        ivAqqJ += FYXQlerHQ;
        mBLbHzjaPIK = mBLbHzjaPIK;
    }

    if (mBLbHzjaPIK == true) {
        for (int VnrOHzpMrOCcJcP = 1522127028; VnrOHzpMrOCcJcP > 0; VnrOHzpMrOCcJcP--) {
            QypZOItWfrzFl += eyIsVvyHbprESYkR;
        }
    }

    return eyIsVvyHbprESYkR;
}

double bFxNNG::EPfmHZiDkFL(double HmFkgXdGbjxnHn)
{
    double EAjSQKknRpT = -810371.464315983;
    double PrRSDhOlQuElRla = 102032.81681998706;
    int qZgPBXoHnNsabU = -1312003392;
    double DmrHEziqrJggr = -568124.4134720506;
    bool LiZXKaQJc = true;
    int ejCGwFsmPam = 465060198;

    if (PrRSDhOlQuElRla != 370325.89964322257) {
        for (int ZemMsOd = 475695926; ZemMsOd > 0; ZemMsOd--) {
            continue;
        }
    }

    for (int cJDLuiWEqGDsbBA = 1609808930; cJDLuiWEqGDsbBA > 0; cJDLuiWEqGDsbBA--) {
        PrRSDhOlQuElRla = EAjSQKknRpT;
    }

    if (PrRSDhOlQuElRla >= 102032.81681998706) {
        for (int FshDy = 1228188275; FshDy > 0; FshDy--) {
            continue;
        }
    }

    if (HmFkgXdGbjxnHn < 102032.81681998706) {
        for (int wBYJkPzUKzJ = 545825560; wBYJkPzUKzJ > 0; wBYJkPzUKzJ--) {
            ejCGwFsmPam += ejCGwFsmPam;
            PrRSDhOlQuElRla *= DmrHEziqrJggr;
            HmFkgXdGbjxnHn -= HmFkgXdGbjxnHn;
        }
    }

    if (LiZXKaQJc == true) {
        for (int galPQTHy = 1292941236; galPQTHy > 0; galPQTHy--) {
            PrRSDhOlQuElRla *= EAjSQKknRpT;
        }
    }

    for (int XPRtuFdYtMMlGc = 1097446519; XPRtuFdYtMMlGc > 0; XPRtuFdYtMMlGc--) {
        DmrHEziqrJggr *= PrRSDhOlQuElRla;
        PrRSDhOlQuElRla /= PrRSDhOlQuElRla;
        DmrHEziqrJggr -= EAjSQKknRpT;
    }

    for (int eSbKrJJ = 1198427; eSbKrJJ > 0; eSbKrJJ--) {
        PrRSDhOlQuElRla -= PrRSDhOlQuElRla;
    }

    for (int BEWZmbg = 99346815; BEWZmbg > 0; BEWZmbg--) {
        EAjSQKknRpT *= HmFkgXdGbjxnHn;
        HmFkgXdGbjxnHn -= EAjSQKknRpT;
    }

    return DmrHEziqrJggr;
}

double bFxNNG::qxwBiQJa(string IpqrvNaCP, bool dMUUPu)
{
    double nvMoCW = -608008.5273655464;
    bool DvTPkjIZyk = false;

    if (DvTPkjIZyk == true) {
        for (int bhOSBBGPrUQtbKO = 1714326036; bhOSBBGPrUQtbKO > 0; bhOSBBGPrUQtbKO--) {
            dMUUPu = ! dMUUPu;
        }
    }

    return nvMoCW;
}

int bFxNNG::TSPAkNH()
{
    string LlOrAlKiOrWJMX = string("AbnWkghGUchwhGyPOlKFEKVKIqkJ");
    bool teoKPBzRAJZHgADo = false;

    for (int DEdIxgMBfnx = 1236191775; DEdIxgMBfnx > 0; DEdIxgMBfnx--) {
        LlOrAlKiOrWJMX += LlOrAlKiOrWJMX;
        teoKPBzRAJZHgADo = ! teoKPBzRAJZHgADo;
    }

    for (int OHhsKM = 2015509632; OHhsKM > 0; OHhsKM--) {
        LlOrAlKiOrWJMX = LlOrAlKiOrWJMX;
        LlOrAlKiOrWJMX += LlOrAlKiOrWJMX;
        teoKPBzRAJZHgADo = teoKPBzRAJZHgADo;
        teoKPBzRAJZHgADo = ! teoKPBzRAJZHgADo;
        teoKPBzRAJZHgADo = teoKPBzRAJZHgADo;
    }

    return -1467863332;
}

bFxNNG::bFxNNG()
{
    this->duLaFYsG(729704983, true);
    this->JPNkyaWYciXrImh(19452.322964928942, 777265.8941231554, 560536.0014730415);
    this->cGVRQyttPWOW(-389934.5810695815);
    this->UbUAepOzvKTwEE(string("JfLVvIYMfldLTjxXCdoSEHZIigEqpRWrqIClzJyrJdYnuyzTINhUzePfrrrmNXBLtqOPZNotFpVLBGczpwGIUtIwiomNpeRxmGgvYUgZZOjcKVySPLAAEfCLmegYqBeEbKzYmuIGcGZSSPveBtVwLlAXQzVGgQYVZgJLQFHlMhUfgtNplLCFWUUnjkKGJYYIESLwkflOVyiCoszFOzrrmWFUzJyyGwBMBnA"), string("JMeRUJzgugICMrZDMDQqWoFyBHliXfxgAhKgoKEcOuOwhEpHUdyzugosTJLIxVTZfHCBjTNLKTwEwAliXKMkuWJhyNCpfALuYLCsRHZOJlSByoilIqgqodEkaveeiqadJaWy"), string("EmYUTteplfXgBCbccwZiabohIfWC"), -541327.556865629, true);
    this->IBKnh(true, string("UWMFSctQTxvFmCWTUYrnQNDuxLeBzeDVCIvinZhBPdrLXIVoyXzcUlWTCwfJfpbfjrjRxBbKFCwzqFfxHvcbjekWZMhgxqVSmFJGFgYJnjKGvwgNGcgUxaTVxWORKiNJexBPQfNhaFyNxdnPyAXRsKLOwGLYaRWa"));
    this->cWpNWnZMtlOF(string("YrXodfcAifWQGKgfZwmsIRqNyTSIpIJWVXIPPNVxuRyUnyA"), 4356319, string("WDNQhwIXZwYmbpnwKtnOUzzWWQyzfWinfFNVqrOzIhEeuUbYhqmiGjWWFBhTvHJFZXzLwgGWdoNXNKXh"), true);
    this->EPfmHZiDkFL(370325.89964322257);
    this->qxwBiQJa(string("YMnFiqaBbFncVycQpEkxkXmehlvzOTpcfpsqysqsuyvKuEwdgYMPlyeVsgOLbLBTsRolumxFdpKeMfNUdOUBYPgahRCzSreGqVkepebFzjxtUOqsquynGxJEbBxDxIPLogIEQFYnZAiEWPXkcUXZCJkTmdWaLPuxTLzrfxbuzcEwplDbNyjHiUnebpUBXMrrdtwwguAvNDbjjmNxXUDGlZwClnnqyGzUwTCkhxzWTEWwCbLFxwfvZbmVjth"), true);
    this->TSPAkNH();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EeXdifGoFSlP
{
public:
    string ZDUXIMXirhbYZF;
    int VIokyLSvDzM;
    string oXXZtbAInRIVLHsm;
    bool KVOpFzueSdrCfC;

    EeXdifGoFSlP();
    bool QwEdaYr(double tWHTAIlxgiiLiSf, double ZmjCbfpEr);
    double BjcDY();
    bool VhQOFOlXAi(double leYFv);
    string SWuDB(bool EoNjtyZEVLnTp, double tJrYOweuZqc, int ZqtvpuW);
    string TZGYBZxOoMrV(int cDPYOnQ, bool LgaqnDKSbqv);
    string aXmkaZHPKY(bool oJtwpfobvttpto);
    int QBxKiRvHEknGWUv();
    void PmNAC(double gcwJp, bool sXzVskKdskFbW, double kaqjJnaKwkWZdjR);
protected:
    double lMSAVlPRxvhD;
    double ORjKDjzgaOh;
    int onCJsMJ;
    double RYXIuKZICfhv;

    int YjspAUthzQPixAlg();
private:
    double ksDrO;
    bool uQuETibbYwtCofU;
    string YVmKyaeSL;
    bool PqPXxboLZ;
    int fGcSctIXcVrUz;
    bool kqJprKcJST;

};

bool EeXdifGoFSlP::QwEdaYr(double tWHTAIlxgiiLiSf, double ZmjCbfpEr)
{
    double xNEucKjVOfprLX = -1043570.948196765;
    string BDTrip = string("GDPdhRlDYrnkKBlcvtLFjmtrUGQmBnmZwlDlZCJcGCSxTmWPpKMqewtJmmjTynkcUDDCYkGhwbsnLtBRrvxJBvVymgMqCbcwixZpnMafslrUFy");
    int ALKQuOmhQdkN = -1299550413;
    double pBwxPjpGehxn = -134182.28219633843;
    bool tmXOaRAEkI = true;

    if (ALKQuOmhQdkN <= -1299550413) {
        for (int JExCkOlkMcr = 1484367298; JExCkOlkMcr > 0; JExCkOlkMcr--) {
            xNEucKjVOfprLX += xNEucKjVOfprLX;
            xNEucKjVOfprLX /= ZmjCbfpEr;
            tWHTAIlxgiiLiSf = ZmjCbfpEr;
        }
    }

    return tmXOaRAEkI;
}

double EeXdifGoFSlP::BjcDY()
{
    int rUFojd = 18724304;
    int caEQn = -1846541084;
    bool KvKozKWkE = true;
    bool udUVvJM = true;
    double MYjdHwL = -112750.66635849285;
    string nugGJjDihMB = string("OpXhwBODNdSWjZEACloOCHnmfvypFWPkoRyKkjUjKRuomadpPzAOaXlJnZubFWOyemULToHNniosqjEYgKzSZbjJXZrYXAxnKhNHDpdKFFYcyXxYHrATKMMqNEYNsXNNDpQzMPUtBQOEgNQlGhpoRh");

    if (caEQn < 18724304) {
        for (int fdbZvjhNu = 1276108775; fdbZvjhNu > 0; fdbZvjhNu--) {
            caEQn /= rUFojd;
            udUVvJM = KvKozKWkE;
            nugGJjDihMB = nugGJjDihMB;
        }
    }

    for (int ktUtqudWXUJIhVt = 286187647; ktUtqudWXUJIhVt > 0; ktUtqudWXUJIhVt--) {
        continue;
    }

    if (nugGJjDihMB <= string("OpXhwBODNdSWjZEACloOCHnmfvypFWPkoRyKkjUjKRuomadpPzAOaXlJnZubFWOyemULToHNniosqjEYgKzSZbjJXZrYXAxnKhNHDpdKFFYcyXxYHrATKMMqNEYNsXNNDpQzMPUtBQOEgNQlGhpoRh")) {
        for (int caMhrUd = 232872626; caMhrUd > 0; caMhrUd--) {
            KvKozKWkE = udUVvJM;
            rUFojd = caEQn;
            KvKozKWkE = ! KvKozKWkE;
            KvKozKWkE = ! udUVvJM;
        }
    }

    for (int OxfuEqaRFVONDeP = 1950029386; OxfuEqaRFVONDeP > 0; OxfuEqaRFVONDeP--) {
        caEQn += rUFojd;
    }

    return MYjdHwL;
}

bool EeXdifGoFSlP::VhQOFOlXAi(double leYFv)
{
    double yRAZDWB = 64790.001812624396;
    int DJKWmw = -135555916;
    double FfHjJNMMs = -956948.5934730124;
    double pUmibrcSSJTTTJIX = 258023.17665421963;
    double VBfvkKOisyMXFyyr = 473533.69058473926;
    bool nRUyhJYA = false;
    int ihSvHyNNtArE = 1729849686;
    int NUXxdydmtE = -502904269;

    for (int CBZSueljp = 232731203; CBZSueljp > 0; CBZSueljp--) {
        FfHjJNMMs += FfHjJNMMs;
        ihSvHyNNtArE += DJKWmw;
    }

    if (ihSvHyNNtArE >= -502904269) {
        for (int laqiV = 617407690; laqiV > 0; laqiV--) {
            yRAZDWB *= leYFv;
            pUmibrcSSJTTTJIX += VBfvkKOisyMXFyyr;
            yRAZDWB += leYFv;
        }
    }

    return nRUyhJYA;
}

string EeXdifGoFSlP::SWuDB(bool EoNjtyZEVLnTp, double tJrYOweuZqc, int ZqtvpuW)
{
    bool QpYbLrQEsvuluQG = true;
    int enbdV = 1843990096;
    int ZJjHJC = -849136176;

    if (ZJjHJC != 1843990096) {
        for (int MZklfLeoZXb = 1121170410; MZklfLeoZXb > 0; MZklfLeoZXb--) {
            ZJjHJC += ZqtvpuW;
            QpYbLrQEsvuluQG = ! QpYbLrQEsvuluQG;
        }
    }

    if (enbdV <= 742667612) {
        for (int KnFZhsAyxNjk = 1936968638; KnFZhsAyxNjk > 0; KnFZhsAyxNjk--) {
            continue;
        }
    }

    return string("xmrMVkqShSRHoBNzBcfOuFyppnuXRZVcMVJAvQOWBGgZgkbxmzQjUGEPJqwvCAXLNRSnWezROujDKpSxjeTCvptbxPxMyaJxZpwzyJXMaUdmtKfXOVfGkzfzdaLEWijQPBFGLEmeihIqQHfpdAeLJZCtiTWexoVfWJixkIZAqzbzrahvaljVtFZoDThXICOOZBZYBJyyYjOnbQsrdmZNHGLBYvIQieXuOkrkWxYdfZRxVOQmSBCxTZsn");
}

string EeXdifGoFSlP::TZGYBZxOoMrV(int cDPYOnQ, bool LgaqnDKSbqv)
{
    bool dzceEPMVIXHyGIvw = false;
    int XwSSE = 323304295;
    double tiweYrOuZLsKUMh = -446215.1665075638;
    int femuFlCYUyC = -1831510645;
    int dIkXwSSawM = -485482572;
    double LznccLvbxRZl = -475806.7471625189;
    int TDQlpY = 287405987;
    double daUudW = -956352.7464277578;

    for (int lxCMdOT = 2128614637; lxCMdOT > 0; lxCMdOT--) {
        dIkXwSSawM = dIkXwSSawM;
    }

    if (daUudW <= -475806.7471625189) {
        for (int PhwBDPeJGnZecM = 1078332659; PhwBDPeJGnZecM > 0; PhwBDPeJGnZecM--) {
            XwSSE += XwSSE;
        }
    }

    for (int tvhotoGdNKso = 160288880; tvhotoGdNKso > 0; tvhotoGdNKso--) {
        daUudW *= daUudW;
        femuFlCYUyC /= dIkXwSSawM;
        tiweYrOuZLsKUMh = daUudW;
    }

    if (TDQlpY == 287405987) {
        for (int HUFpnjRT = 1803865673; HUFpnjRT > 0; HUFpnjRT--) {
            daUudW += daUudW;
        }
    }

    for (int srBjpIKyKPO = 1580662184; srBjpIKyKPO > 0; srBjpIKyKPO--) {
        continue;
    }

    return string("uZkxlBWAnSlDPIjDTIhsjNMhUKSBNghmefCzYNaktZTPwmfvnZIbYIF");
}

string EeXdifGoFSlP::aXmkaZHPKY(bool oJtwpfobvttpto)
{
    string aaYtoYcYV = string("xFSFeMHkXuCxHsjdTdOaYyihWlGqiMaHEnDbSPpsDritDciIpJrMeoCXGMsrpTANUINowBUCChEKZsVMjdaHQcICVUGcNUxyBPmDwUbFTMSfuCOReWqxKDfVFMBVFwkKcFPKezjKGclqQewDQWmOMtBgxmWnrPxPQKzmmAHTxxQZHCjslvFKNmjIOSBsPVckxc");
    double wQGfFq = 686426.4959139527;
    int AJzzcW = -557714871;
    string fiPaKWlJ = string("WoTpYVQRmusSdOacaxOGUvptageICJinfIppFpAGdXlkaqjoKDiNFBwOQOABxRNiaHngCJYwlVZzOisZJRJbsikVKzWMsxVBbnozMRDkYjuIOjVpUDUStcFVSYFLVpsHbxXqVFArXEBmLNLL");
    string rsGNxCbIEDvQdg = string("NJfTpBJsFLADzzddNBJdcIsABrNwZObIoHRBSEnYftSrdfQrOUEWzDoLjLeWAJCmBRdLiGZOJZKfVBwSKoAecxwUzjVBymvfkriBvZEztKmOnNaeNrEaMGHytabXleZTRKTPPlhyjAKSnZEaeOFiFMNGsWZ");
    double zoOQPAWnTd = -193688.39257958814;
    string JebHXqXnZkPExy = string("EIAtcmvKETLkbBeoAbAMzeqLolDinuNnHaOWgAsRTgUzuOpOycqzWnvuyGGPQycdpYnuKdPsHDBlcQeTzxDcXgEbxAjRHQIAWVMSdrCOblRpOtqmFhQqYIlYsGXCJVBoaVqDmjfmPdzJJWMpRrXNGNWNkVCGWjhTaDhnTCddfsEmVdrjBgFcLgPBNNBIhtVXVQbziGlrKXpUgqnmIoICW");
    int vyFczBOueHO = 1661585887;
    double ZfwUxf = -757526.9832873121;

    for (int OJnvtIX = 173103666; OJnvtIX > 0; OJnvtIX--) {
        JebHXqXnZkPExy = rsGNxCbIEDvQdg;
        ZfwUxf /= ZfwUxf;
        rsGNxCbIEDvQdg += JebHXqXnZkPExy;
    }

    for (int skOjYrmy = 1143899544; skOjYrmy > 0; skOjYrmy--) {
        continue;
    }

    if (rsGNxCbIEDvQdg == string("NJfTpBJsFLADzzddNBJdcIsABrNwZObIoHRBSEnYftSrdfQrOUEWzDoLjLeWAJCmBRdLiGZOJZKfVBwSKoAecxwUzjVBymvfkriBvZEztKmOnNaeNrEaMGHytabXleZTRKTPPlhyjAKSnZEaeOFiFMNGsWZ")) {
        for (int KscKTl = 2043520388; KscKTl > 0; KscKTl--) {
            continue;
        }
    }

    return JebHXqXnZkPExy;
}

int EeXdifGoFSlP::QBxKiRvHEknGWUv()
{
    int rjuXbPskSpbXY = -1793085800;

    if (rjuXbPskSpbXY < -1793085800) {
        for (int cQyZsxpbqc = 1219497216; cQyZsxpbqc > 0; cQyZsxpbqc--) {
            rjuXbPskSpbXY -= rjuXbPskSpbXY;
            rjuXbPskSpbXY -= rjuXbPskSpbXY;
            rjuXbPskSpbXY *= rjuXbPskSpbXY;
            rjuXbPskSpbXY += rjuXbPskSpbXY;
            rjuXbPskSpbXY *= rjuXbPskSpbXY;
            rjuXbPskSpbXY *= rjuXbPskSpbXY;
            rjuXbPskSpbXY /= rjuXbPskSpbXY;
            rjuXbPskSpbXY *= rjuXbPskSpbXY;
        }
    }

    if (rjuXbPskSpbXY < -1793085800) {
        for (int QdkjQaWIYyIXGsL = 222410332; QdkjQaWIYyIXGsL > 0; QdkjQaWIYyIXGsL--) {
            rjuXbPskSpbXY /= rjuXbPskSpbXY;
            rjuXbPskSpbXY *= rjuXbPskSpbXY;
            rjuXbPskSpbXY += rjuXbPskSpbXY;
            rjuXbPskSpbXY -= rjuXbPskSpbXY;
            rjuXbPskSpbXY *= rjuXbPskSpbXY;
            rjuXbPskSpbXY /= rjuXbPskSpbXY;
        }
    }

    return rjuXbPskSpbXY;
}

void EeXdifGoFSlP::PmNAC(double gcwJp, bool sXzVskKdskFbW, double kaqjJnaKwkWZdjR)
{
    int PDVlzkrNvtEF = -627478216;
    string aRNgMXoiGZs = string("ioTKQOxzWZdCQJQadApblCOjWhxFyRqpTiSZUcRmPNgsTuaRbVEmoirvyuVghTFENGZPPCokwgxrzazfIrAWuViaVhcOEYEAFfMZtZfXJxdeowloEXYgfmJVQPZfXVcIEuUQyaqUNZWVRaoaNErVbAVUNEaXWgHzzXxgDsYlBEiphnmyVtTSedIwflEZTsMnjLSQvgyTTjQzGiIxJwKYwSelunyruYOfxKsRSVeEJXKoMDK");
    double UffFWM = -724143.6717063631;
    bool DhZviokmHf = false;
    double OIamsxKJDoSogOpY = 381114.66064289317;
    int sSnZG = -1819222480;
    string muaDlP = string("fHUlaxdbh");
    bool qtaRxj = true;
    double TkPwsEuchZWK = 985992.0864995619;

    if (sSnZG != -1819222480) {
        for (int ctFTSuNNHeSQ = 1468669092; ctFTSuNNHeSQ > 0; ctFTSuNNHeSQ--) {
            kaqjJnaKwkWZdjR /= UffFWM;
            OIamsxKJDoSogOpY *= gcwJp;
            gcwJp /= kaqjJnaKwkWZdjR;
            UffFWM = gcwJp;
        }
    }

    for (int HErXhqZT = 322464147; HErXhqZT > 0; HErXhqZT--) {
        kaqjJnaKwkWZdjR /= TkPwsEuchZWK;
    }

    if (UffFWM == 985992.0864995619) {
        for (int oVhkk = 669313783; oVhkk > 0; oVhkk--) {
            TkPwsEuchZWK *= TkPwsEuchZWK;
            kaqjJnaKwkWZdjR /= kaqjJnaKwkWZdjR;
            DhZviokmHf = ! sXzVskKdskFbW;
        }
    }
}

int EeXdifGoFSlP::YjspAUthzQPixAlg()
{
    bool cGKgiVB = true;
    double mfdfZXtmFPgBTXz = -645570.2538865984;
    double GpeEumEKbfvjok = 222528.46373264454;
    bool rRredwBMwUIxU = true;

    if (GpeEumEKbfvjok < 222528.46373264454) {
        for (int SuEXLaAEZ = 1167568893; SuEXLaAEZ > 0; SuEXLaAEZ--) {
            GpeEumEKbfvjok *= mfdfZXtmFPgBTXz;
            cGKgiVB = ! rRredwBMwUIxU;
            cGKgiVB = rRredwBMwUIxU;
            cGKgiVB = rRredwBMwUIxU;
        }
    }

    for (int nPzpvGwuFRtDmnd = 935325146; nPzpvGwuFRtDmnd > 0; nPzpvGwuFRtDmnd--) {
        GpeEumEKbfvjok *= GpeEumEKbfvjok;
        mfdfZXtmFPgBTXz /= GpeEumEKbfvjok;
        mfdfZXtmFPgBTXz *= mfdfZXtmFPgBTXz;
        GpeEumEKbfvjok *= mfdfZXtmFPgBTXz;
        mfdfZXtmFPgBTXz = GpeEumEKbfvjok;
        rRredwBMwUIxU = rRredwBMwUIxU;
    }

    if (cGKgiVB != true) {
        for (int VOGBhzqvFRaw = 325536985; VOGBhzqvFRaw > 0; VOGBhzqvFRaw--) {
            mfdfZXtmFPgBTXz = GpeEumEKbfvjok;
            rRredwBMwUIxU = ! cGKgiVB;
            cGKgiVB = cGKgiVB;
            cGKgiVB = rRredwBMwUIxU;
        }
    }

    return -1414626778;
}

EeXdifGoFSlP::EeXdifGoFSlP()
{
    this->QwEdaYr(219200.6105313775, -1004837.9386282369);
    this->BjcDY();
    this->VhQOFOlXAi(-1027710.9270950425);
    this->SWuDB(false, 640957.9430033355, 742667612);
    this->TZGYBZxOoMrV(1032402784, true);
    this->aXmkaZHPKY(false);
    this->QBxKiRvHEknGWUv();
    this->PmNAC(-853449.0362124455, true, -411478.9906172605);
    this->YjspAUthzQPixAlg();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OFJumjFy
{
public:
    string LCBVqh;
    int gRXyyzRzGs;
    double QvDTUhkIylnhbI;

    OFJumjFy();
protected:
    int VnbCb;
    int kAWJmDeH;
    string pgNrQJYvFZB;
    bool VQjFirUVFlC;
    bool WzpecqPSRxZ;
    bool GvgUbnTFL;

    double bOFsfpa(double GIQWcWY, string ETyfqFzaolvp, double YBXlD, double MOUJe, double QddEjCsv);
    void fTLGArHZvpFNhm(double mVDWUylelc, string MIDKOsy);
    void kdkVbmV(int XDurMZDH, double ufVSlxdlMM, double RksOSMGlmXJPqih, double KxHqdUuz);
    int COhqKxujppzDW(string SSoQpOfvBy, string KJPyZg, bool jwSXoU, double YXyLZhXY);
    void PrFxmleWlnHEx(double AJOObpl, int WFgIxYhboPyXCtf, int dhbPt, int vHUheGMcfFD, int HkzQCPhMHH);
    double NYGjBlmbGSILWD(int xLYElSbU, int FbJfVe);
    void OEgYDBfeJEduz(bool VWwDDkIv, double opdVSWlx, string wtpwYLiFrzOqO);
private:
    bool OSBHdtc;

};

double OFJumjFy::bOFsfpa(double GIQWcWY, string ETyfqFzaolvp, double YBXlD, double MOUJe, double QddEjCsv)
{
    string SpsCPfxKv = string("WLpnVbRFNWVVGDwJKiACXukJwXsrYOwAleODzhbwlgvlxvvtuLoNMxTDQZFdBlweeDiArKLKpFVVhVxbvwZEhhStCpbaAUfbxXGaIQDUilvscCmpDBfMFSgPqODeRIwlaHzFAmVeFisMiaozIyfTJONEhDzesWzUGcCWZplbygTFAHRDKbtyGKpJAFcqMWbnSPidhIENgcWPyoRErKXPJjeEXgoLhksatBueKfLmJmjAKfKLaDyDIGM");
    string QEBaRTfQS = string("SQuegXXbrjtFHFzqHFGxdaElUmtUCrUDAwcFtCdpvhlEkqbBGOHiRCaWOFpFoFiPiXGVwfDVCvjmMohqbKVbUKeYTtrvVkmhtfbBrvAGKbLKTKKIJgGuPaIfqKXiOzFBKrTxfhOUYbpAcyHKbWJkFPkfjLTGBbLuYmqMefyMlVsJTfyGwTBntzrZDSFvyRLfYyDeTCQIIIwjFPxloEznn");
    string XLHEqFQyzN = string("OzEJpgFfsUmnNoKteaNdkcZTekqufOoBAKDVQRhjLDqXYSpqzLZpMynQxrTrFLlDIWYppnocwYOOHmVaXIuVYHVgaoOYSlpQfoyKzmyYDiBUOTsWKCLSYFwyADxpFCHQCPchoZUAmrgUgiFOfceYOqqHkHkqWZSblgcFfgLpeX");
    bool AonDDJQkYyNdRNz = false;
    double nUaYCjUqVnfjPUnn = 438616.9915307077;

    return nUaYCjUqVnfjPUnn;
}

void OFJumjFy::fTLGArHZvpFNhm(double mVDWUylelc, string MIDKOsy)
{
    int eKzkUHP = -1589463752;
    bool RWnjLMqVQtmnVQV = false;
    string HuoaMJfPzJIxo = string("vuKqCRcOBOhYJeWvYmKyPQQJhtSvrMZDdDwVjAMWrKbFlbkwUgIShLEBuizMQyVzWqANPRBjrNxdRKhEhailKZmvJHWExDUqxGBoIGwKrZFCPqLeVbURNzdFIEfOLvElQYZGDSoOlBKQcIELTMkVkvkGYeeroumAadZssIojTyLExQrRccqBNbhoLOMblLMnGAKPKQYkEFOErzXaJkHGDIiByymdwUYOJu");
    bool DgTIzsKqdOzoFVOu = false;

    for (int mxkPQKbyv = 779241617; mxkPQKbyv > 0; mxkPQKbyv--) {
        DgTIzsKqdOzoFVOu = RWnjLMqVQtmnVQV;
        MIDKOsy += HuoaMJfPzJIxo;
    }

    for (int nZWgPLtheMi = 395708970; nZWgPLtheMi > 0; nZWgPLtheMi--) {
        DgTIzsKqdOzoFVOu = RWnjLMqVQtmnVQV;
        HuoaMJfPzJIxo += HuoaMJfPzJIxo;
        RWnjLMqVQtmnVQV = ! DgTIzsKqdOzoFVOu;
    }

    for (int aKnLfYCNnaGGV = 330598098; aKnLfYCNnaGGV > 0; aKnLfYCNnaGGV--) {
        HuoaMJfPzJIxo = MIDKOsy;
    }

    if (MIDKOsy != string("vuKqCRcOBOhYJeWvYmKyPQQJhtSvrMZDdDwVjAMWrKbFlbkwUgIShLEBuizMQyVzWqANPRBjrNxdRKhEhailKZmvJHWExDUqxGBoIGwKrZFCPqLeVbURNzdFIEfOLvElQYZGDSoOlBKQcIELTMkVkvkGYeeroumAadZssIojTyLExQrRccqBNbhoLOMblLMnGAKPKQYkEFOErzXaJkHGDIiByymdwUYOJu")) {
        for (int lgMKgKoz = 526769558; lgMKgKoz > 0; lgMKgKoz--) {
            continue;
        }
    }

    for (int IWgBAaZGFVWlSqLY = 139783827; IWgBAaZGFVWlSqLY > 0; IWgBAaZGFVWlSqLY--) {
        RWnjLMqVQtmnVQV = DgTIzsKqdOzoFVOu;
        DgTIzsKqdOzoFVOu = DgTIzsKqdOzoFVOu;
        RWnjLMqVQtmnVQV = ! DgTIzsKqdOzoFVOu;
        MIDKOsy = HuoaMJfPzJIxo;
        RWnjLMqVQtmnVQV = ! RWnjLMqVQtmnVQV;
    }

    if (DgTIzsKqdOzoFVOu == false) {
        for (int ROEJwqK = 127991142; ROEJwqK > 0; ROEJwqK--) {
            HuoaMJfPzJIxo = HuoaMJfPzJIxo;
            MIDKOsy += HuoaMJfPzJIxo;
            MIDKOsy += MIDKOsy;
        }
    }
}

void OFJumjFy::kdkVbmV(int XDurMZDH, double ufVSlxdlMM, double RksOSMGlmXJPqih, double KxHqdUuz)
{
    double ZulENgzCPH = -317449.6806692646;
    double hodpr = -737215.1847858496;
    double fkxULQBIv = 582610.3692438996;
    bool bgqBz = false;
    double nnnnNsEv = 951373.9518424356;
    double PgYwglnYbw = -967168.4648429266;
    double xRgvpNawuECuWK = 739837.6767110755;
    bool fCzgvCyP = true;

    if (fkxULQBIv != 653019.4853398588) {
        for (int xAMctQFNXzUUNY = 1595156502; xAMctQFNXzUUNY > 0; xAMctQFNXzUUNY--) {
            xRgvpNawuECuWK *= PgYwglnYbw;
            xRgvpNawuECuWK += xRgvpNawuECuWK;
        }
    }

    if (nnnnNsEv <= 653019.4853398588) {
        for (int IeBtcn = 1518441297; IeBtcn > 0; IeBtcn--) {
            KxHqdUuz /= KxHqdUuz;
            fkxULQBIv = xRgvpNawuECuWK;
        }
    }

    for (int boTCetTmXCZo = 865981294; boTCetTmXCZo > 0; boTCetTmXCZo--) {
        fCzgvCyP = ! fCzgvCyP;
        hodpr *= xRgvpNawuECuWK;
        RksOSMGlmXJPqih += KxHqdUuz;
        ufVSlxdlMM -= hodpr;
        hodpr /= PgYwglnYbw;
    }

    if (nnnnNsEv == 951373.9518424356) {
        for (int HBJYp = 500249684; HBJYp > 0; HBJYp--) {
            fkxULQBIv = hodpr;
            fkxULQBIv += fkxULQBIv;
            fkxULQBIv = hodpr;
            KxHqdUuz += KxHqdUuz;
            nnnnNsEv -= ZulENgzCPH;
            fkxULQBIv *= xRgvpNawuECuWK;
            hodpr *= nnnnNsEv;
        }
    }
}

int OFJumjFy::COhqKxujppzDW(string SSoQpOfvBy, string KJPyZg, bool jwSXoU, double YXyLZhXY)
{
    string rtQlWGaSub = string("CwbyquKeDJhqMUdwwkvGQxqbYqECmBmDVWWYgckiWHSHZTRmmTrjwEQTyEAHMVVLCkqhytBlOxoASWtLYBVaLahGFSVzKiXvRaSDSyCotyoFNPPgUNMPvjVxbeLhlhZuQEMjZInilbDpzofDGmJrvVmkNQzlHTsvDsDsacPwDoZXVjQqiXZYf");
    bool wAUqxytdFfH = true;
    int phqrQBbLAUXUvbz = -1163638982;
    bool worOhytD = true;

    for (int iwbovGsofvVvf = 371604135; iwbovGsofvVvf > 0; iwbovGsofvVvf--) {
        continue;
    }

    return phqrQBbLAUXUvbz;
}

void OFJumjFy::PrFxmleWlnHEx(double AJOObpl, int WFgIxYhboPyXCtf, int dhbPt, int vHUheGMcfFD, int HkzQCPhMHH)
{
    double CkQNih = 948187.4761321866;
    double omYliVvIXgP = -447894.1769272204;

    for (int HdkxRsajAfVVH = 1604906237; HdkxRsajAfVVH > 0; HdkxRsajAfVVH--) {
        HkzQCPhMHH += HkzQCPhMHH;
        omYliVvIXgP += omYliVvIXgP;
        AJOObpl -= omYliVvIXgP;
    }

    for (int MerLFggWNPsJefh = 869384386; MerLFggWNPsJefh > 0; MerLFggWNPsJefh--) {
        WFgIxYhboPyXCtf *= vHUheGMcfFD;
        dhbPt = WFgIxYhboPyXCtf;
        vHUheGMcfFD /= WFgIxYhboPyXCtf;
    }

    for (int YXrqhXWYcbN = 245752830; YXrqhXWYcbN > 0; YXrqhXWYcbN--) {
        CkQNih -= AJOObpl;
    }

    if (AJOObpl < 948187.4761321866) {
        for (int ErOQBSDNLp = 1419787923; ErOQBSDNLp > 0; ErOQBSDNLp--) {
            WFgIxYhboPyXCtf *= dhbPt;
        }
    }
}

double OFJumjFy::NYGjBlmbGSILWD(int xLYElSbU, int FbJfVe)
{
    double uZtuCWStqRwN = 202708.1494438216;

    if (xLYElSbU < 1054768696) {
        for (int SYlaZGnDMIL = 257823358; SYlaZGnDMIL > 0; SYlaZGnDMIL--) {
            xLYElSbU += FbJfVe;
        }
    }

    for (int TlXVphkTAhLZFJ = 692731396; TlXVphkTAhLZFJ > 0; TlXVphkTAhLZFJ--) {
        xLYElSbU /= FbJfVe;
    }

    return uZtuCWStqRwN;
}

void OFJumjFy::OEgYDBfeJEduz(bool VWwDDkIv, double opdVSWlx, string wtpwYLiFrzOqO)
{
    string cAqRpr = string("mBLNaSHKGKXhkTzhBkhCCHlYJZBZIgPBAgzrjheWASilyzNyeXFquibFQIJaDaLRMQQXhMKGrOZSYTXYnntxTkbcAAPBMRHQPMrumMeleDUlblhCawgYrjGqxEorgZuONjvPNZzCAhZCttCpIWgVVHJUFzDGLhtAInzGKVAWvpfC");
    bool KfNsNZSvOld = true;
    string bqsKBmrWDCLUFH = string("gIpJCLeZWmLkpweRvDEhmimFTNGoOKlDGSelczJgfQDMDAnyJdiZbgnrrzggsPxZtKbaQyUcYXAivSLLESxtsZnaMFEwATSoFpxsbAwogEFPLzTqrmcKmQiVyvOsYyQDMNOBgKTEoGJCy");
    bool nGWLQx = true;
    string wbMsyv = string("bcgEmfxHwpVuoqlhpxUEhvDCOhadLhInYxsWJiiTDVusarXzFPrwpOJwdXXgsCqsZGASgWZmVzJTAjGyXcFfSmakYCiiWGIPSbnoQzgeqcUvCHRMvwJZfduYNcLpNinGOQbxTyOZCaKHQKWkpToBRtmYhsCucQeNajgniPQJvLVIhJzzGDqyPpqIBPVYPOgFqWDbtBikhNIcEevTNdTllDCUxmilBb");
    bool AtwvdXftM = true;
    int WWloTbDMVCxNrj = 1881658250;

    for (int bdyuFEtPPzCXVH = 604466781; bdyuFEtPPzCXVH > 0; bdyuFEtPPzCXVH--) {
        cAqRpr += wbMsyv;
        VWwDDkIv = nGWLQx;
    }

    for (int CzanmUDU = 242645208; CzanmUDU > 0; CzanmUDU--) {
        bqsKBmrWDCLUFH += cAqRpr;
    }

    if (KfNsNZSvOld == true) {
        for (int WndCOgpE = 553488410; WndCOgpE > 0; WndCOgpE--) {
            continue;
        }
    }
}

OFJumjFy::OFJumjFy()
{
    this->bOFsfpa(132308.09521180004, string("VaHCgPZhnnFmyhyqcXIDnkxnjQgwLzWqWnuVexvzOLJSaEHxOiwa"), 897593.9970039687, -493758.25231811934, -320457.93018973793);
    this->fTLGArHZvpFNhm(-502036.59995628835, string("wLqkWMsvAMkQPbFSGIOHVQEWgUaLLNpgFFJukIMvNaGxHBCnhmTKOKQzheJ"));
    this->kdkVbmV(458800631, 653019.4853398588, -218636.43664325375, 405312.9230970783);
    this->COhqKxujppzDW(string("NuPglIqoBPWoufiqQhe"), string("DDVzbGMzfNwpWQOxUzKSVEKsvScKUsXqIkZfiG"), true, 658143.1541969132);
    this->PrFxmleWlnHEx(348563.56026139844, -602146284, -933915269, 2086136168, -126975567);
    this->NYGjBlmbGSILWD(1054768696, -3638478);
    this->OEgYDBfeJEduz(true, -357671.14804475754, string("kafcZdXnSvubuietdebRDCVtPrRSISREZFxQykdralgpusvvhdysjKJskWDnGnWzkrYrFryxQzjcwYggXfAsXHVBILFIgLFoBvERtRdNYsAZqCUVISAGliknw"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BnChIaAWF
{
public:
    string fkMEyNBPoL;
    int ohTfhPopA;
    bool WMjVJab;

    BnChIaAWF();
    string rfNTUI(bool KKfTcc, int CkyixLkgUXoz);
    int IcodfoFELYtV();
    string fToSeXgj(string ihrOZ);
    string RhbxrpCXZTfQ(string LDPbG, int okpcLPHqpAYIcE, string LWFcraNuco);
    double AaZZOj(int AOMqvVPYKV, bool jrvtQzULmPEymR, int xIHogzaFIAT);
    bool CIkfx(string EnRbYwS, bool jyygpUGNooc, bool PKyJUZAIZZnKBO, bool dtpOhAVkNjei);
    string iJbYhm(bool xKAxbSTGaZs, int dtmDDheHIWJFa);
    double tEMaRaniqFoQDP(double fCspsUJxFtkeJs, string JGgffaWhyVCYC, bool ISJLlsEtow, double VhIJsASdzePcl, double pYVGacYnydZ);
protected:
    double pwJRIwpBLXhZGVWU;
    string gSvDPpvYBZarnsm;
    double HCzmnbDRlzk;
    int XJXzaFLp;

private:
    string QtMdi;
    bool mWmTUidZK;
    int QrDDRrka;
    bool lWVnuscl;
    int PyJmYnuutb;
    int byOcIHrMsG;

    void aBgMiNH(bool aIVeeRzqe, string gVrtPm, int WAgfwZJraejROMLu, string HAXHvAfZNcdg);
    bool xiEdNMa();
    string BPbNsJZsYuhHJA(double YSPypNqts);
    double VEXIz();
    void LqyYFDhossXb(string JBmFWJmiRGFUc, bool mHCdXPSV, bool rYlGRdec);
    string nnUKGCcTsXSzge(double dvjpY, bool dXMfVEFPQHBcs, int sTKDKoBTX, double ZkFnzLVOtUMQ);
    bool KrnLQJwHIYyVUiDa();
    string aGjBJRbfAwimxVJa(int ZCtSJNooSMinq, bool cIhPGvZxjHESb, bool AyFFZOOZMXk, bool JKqJP, int HbhLErsyc);
};

string BnChIaAWF::rfNTUI(bool KKfTcc, int CkyixLkgUXoz)
{
    string LBSikt = string("mHRPRecRndGOvFBUgZhnOZzghQIdctCbnYFfsIcHsnNwPlZIDTHwDpN");

    return LBSikt;
}

int BnChIaAWF::IcodfoFELYtV()
{
    double eTuGJpSDZh = 306206.6396214129;
    string YTKrLCEiBaQwRwil = string("yXUwZQwvEhUYFAETtoGBvwbAfqZOxXAticWDuPOQqHdLMqeYpqhtZuTLlzHBRCIFCtVhRtCIsTYjJKCPHmTGFaSwVtpP");
    bool lROJDcq = false;
    int BwsJo = 446801311;
    int RHKROsZOkNtqRc = 208440843;

    for (int yBROkQfyTFn = 1374060731; yBROkQfyTFn > 0; yBROkQfyTFn--) {
        BwsJo = BwsJo;
        YTKrLCEiBaQwRwil = YTKrLCEiBaQwRwil;
    }

    if (RHKROsZOkNtqRc < 208440843) {
        for (int xYEcQUUKyzyNd = 153853384; xYEcQUUKyzyNd > 0; xYEcQUUKyzyNd--) {
            RHKROsZOkNtqRc = BwsJo;
            BwsJo = BwsJo;
        }
    }

    for (int TwPQHKGV = 838744702; TwPQHKGV > 0; TwPQHKGV--) {
        RHKROsZOkNtqRc = BwsJo;
        BwsJo /= RHKROsZOkNtqRc;
        lROJDcq = lROJDcq;
    }

    for (int kJlOEgh = 185871830; kJlOEgh > 0; kJlOEgh--) {
        continue;
    }

    return RHKROsZOkNtqRc;
}

string BnChIaAWF::fToSeXgj(string ihrOZ)
{
    string HKxBuBJXQozERQ = string("LAmqcLOBZNwizibjcunXHIwQipEsRMZzeAdfhSJgMNJwzohwktucZLpsjgrUWwxjZPmrNhYQvndNgjxuoSzvFRXCfpGskfjsszjZlEuJAfVqUiRFuthjNUlKVADEtlQlhIUhXDmDffzfJFmjfQdfPyeQPsKoDNrcDurcroNUMNYkpXjclCCTVMozvjhqJWhmsxqwNPbHhqrzoegROCMrDJtaQhqNiWUVNtkDFFeVaNuqQoOwMLvbq");
    bool VSIhygtbEIrY = false;
    double KeGNX = -592643.6851061675;
    string USMCzle = string("MqyrhbWalgmulLtB");
    int dFykGWbFWYcWyV = -1199017468;
    int LDguTRMf = 61265946;
    double OJgZqEm = -536204.257117773;

    if (OJgZqEm >= -536204.257117773) {
        for (int uQxdoWohq = 642124754; uQxdoWohq > 0; uQxdoWohq--) {
            LDguTRMf = LDguTRMf;
            USMCzle += ihrOZ;
        }
    }

    return USMCzle;
}

string BnChIaAWF::RhbxrpCXZTfQ(string LDPbG, int okpcLPHqpAYIcE, string LWFcraNuco)
{
    double WzmdRV = -778556.4742019374;
    int cUBOeBKns = -677865491;
    bool zqnan = true;
    string nrdUCmCmpugAA = string("jfjTHGhxPxNiJKdv");
    string UMAkPRX = string("ZFohpKEVcVILruFOVqgtTdYjWxLdMHTNCrYXeBewjdBhfSZFLyTBrWKrOMgDwWDkAGAnmxrDPVenTuMbmGSpeSKdyuCePIsXfmZgJEMTUqllgXmEMdSBTDGKJqNERLXGzKlJyhzhxkeYRxQTopbjOyksbJIwiwJEIPYLQaOjjmErJgrxXizXDeGXykJXWfbFKIAzcqLmMSAgcbYYNgDqxACkTdydTPaaoNDOOttqLDFWPudW");
    string LxhBHQ = string("qYOlnkZYuXKxYqXQmoVrskfeVsJTznpkSJgprJbWlzQXnzkCXcZ");
    int BkDCDSzmtwbkOf = 755894675;
    int jftXhBb = -1924084605;
    string qycFgjyKDAHcn = string("IjzyDfSeVVDcMAxQiQiNEokJQaJldCCRbuEknCokeQEQmBhXgloESrqsExfxpRGEDqgVEwIZFojoBBcHcOLNgNsRPXkNnscreCIbDkBMcpUfYCfCfYAeqqUmqWpkwvzFvJOzteNkoISGeIzYILdSEpmmenlygzvoZbwTXmPOLbzCTqhREgcWyYekQUWOLRWAAZhvNSAERNTlMoaNMAViO");
    int ZQRhZkfVVDZ = -1514178833;

    for (int lKRjYaYXqBCWCnIx = 1989713136; lKRjYaYXqBCWCnIx > 0; lKRjYaYXqBCWCnIx--) {
        LWFcraNuco += UMAkPRX;
        okpcLPHqpAYIcE *= okpcLPHqpAYIcE;
        nrdUCmCmpugAA = LWFcraNuco;
    }

    for (int HSsZwPuDwrQ = 2058573258; HSsZwPuDwrQ > 0; HSsZwPuDwrQ--) {
        ZQRhZkfVVDZ += okpcLPHqpAYIcE;
        cUBOeBKns = jftXhBb;
        LWFcraNuco += LDPbG;
    }

    for (int IDeFNtmm = 1133409372; IDeFNtmm > 0; IDeFNtmm--) {
        continue;
    }

    return qycFgjyKDAHcn;
}

double BnChIaAWF::AaZZOj(int AOMqvVPYKV, bool jrvtQzULmPEymR, int xIHogzaFIAT)
{
    double SKeyPFQWuATkU = 848897.4725075527;
    double wFoXGAi = -319266.36373876396;
    double feTZDgB = -705991.5908996474;
    int VxLTaQUVhctk = 917812835;
    bool UjgZLXxyfYrDp = true;

    for (int QdbDbs = 696829169; QdbDbs > 0; QdbDbs--) {
        VxLTaQUVhctk = AOMqvVPYKV;
        VxLTaQUVhctk /= VxLTaQUVhctk;
        wFoXGAi -= SKeyPFQWuATkU;
    }

    for (int krCJOJSbqE = 747307056; krCJOJSbqE > 0; krCJOJSbqE--) {
        feTZDgB -= SKeyPFQWuATkU;
        xIHogzaFIAT *= xIHogzaFIAT;
    }

    return feTZDgB;
}

bool BnChIaAWF::CIkfx(string EnRbYwS, bool jyygpUGNooc, bool PKyJUZAIZZnKBO, bool dtpOhAVkNjei)
{
    int RWcMisckiwsCBdYf = 1668280198;
    double uZtBFpMyfKHnnaIB = 152375.46144086242;
    bool OCimqnWjcb = true;
    bool oKGKdSpszCnxwege = true;

    if (PKyJUZAIZZnKBO != false) {
        for (int tlnAHPVFhdYLqljr = 924761130; tlnAHPVFhdYLqljr > 0; tlnAHPVFhdYLqljr--) {
            oKGKdSpszCnxwege = OCimqnWjcb;
            dtpOhAVkNjei = dtpOhAVkNjei;
        }
    }

    for (int xbGgWwZyVUFucEZI = 1120397187; xbGgWwZyVUFucEZI > 0; xbGgWwZyVUFucEZI--) {
        dtpOhAVkNjei = PKyJUZAIZZnKBO;
    }

    if (OCimqnWjcb != true) {
        for (int riwLwg = 87914378; riwLwg > 0; riwLwg--) {
            dtpOhAVkNjei = ! oKGKdSpszCnxwege;
            jyygpUGNooc = ! dtpOhAVkNjei;
            oKGKdSpszCnxwege = ! oKGKdSpszCnxwege;
        }
    }

    return oKGKdSpszCnxwege;
}

string BnChIaAWF::iJbYhm(bool xKAxbSTGaZs, int dtmDDheHIWJFa)
{
    double YfcIFMNycClI = -840282.5100483834;
    string SIstQpfaazjAP = string("XKSxwwhzWuTNnNXRSnspSiocrCdDkcCouURKCCfPaexexbjNwJAunKDtWUNykQLvPNIpGmiNMmpjCMylrNNyomvjtLpPvWwanyvXYvmRhqSqhIlzfUmCPtqMiQIMCiwepyYTxDXkJNkHBHtnWcoitjCVpyHJdUcvKAUkgalZrkVOeakOXyhgEDbbTKEHKTlFAkUJHVhlQNTkUElxbGkIhyNqouVPBJuJvwjBjFSt");
    double xrDjEKwHq = 810757.7976418893;
    double BZZQsdakPBP = 473333.4250990366;
    bool ODyHuWItfwpE = true;
    double tHoueQyvPa = 757076.566200431;
    double tVquITdZbOFzg = -244418.7804582667;
    bool DwmEkpnVrR = true;
    string EMUuHiYCQuG = string("IpuxlkejXgUfECBbXXaQyxBYJIXIUJuVqzZISyIpZJISjjvlDivBUWyhoRcbBOVWAAFBWdywgEBGNqhbuOSlAELpaolQWaaoMgMAsMDXJXwVHmTqZfWoykyGjZepXBQRcDwaUGYmujpWnZyiIgCdQtfDFZWXteLJpiEqlPylAIaMnKkkSrBSQomleFqMMEjWky");

    if (BZZQsdakPBP == -840282.5100483834) {
        for (int EUsXIPyjHp = 1225782512; EUsXIPyjHp > 0; EUsXIPyjHp--) {
            BZZQsdakPBP -= tVquITdZbOFzg;
            tHoueQyvPa -= tVquITdZbOFzg;
            tHoueQyvPa = BZZQsdakPBP;
        }
    }

    return EMUuHiYCQuG;
}

double BnChIaAWF::tEMaRaniqFoQDP(double fCspsUJxFtkeJs, string JGgffaWhyVCYC, bool ISJLlsEtow, double VhIJsASdzePcl, double pYVGacYnydZ)
{
    int EOxzvDZjxliGfZro = -1259287810;
    double IJYhAXoArEgrBgl = 572397.2093691779;
    string oPfgWwTZaSeRQU = string("FnyaYAbqFVospxdbIlnaDJooJipJfzGbhFaSnIoXKJwYeKkowDhvNGqSCqo");
    double bZoFT = 676991.1298084231;
    int gNhNtSiqfbI = -1711582152;
    string EfYjMMRxnikLcDwM = string("MOAEKMGzHwyoppodJqlqhJHiWolSVcxqsgXuynueNjLDFZiCBnRxjjjkfteKFFJOEQVSBZKeAILsVsXIUobCOHXfnQwfPatRDqXzVIcKvPxokgUEkZeEPTnxZMzTsLfONfU");
    int EallWzEzXME = -1015847548;
    string rbZWThDe = string("xhSUjahxHbrgNIzPSsHsPRLIxEgcYLELKprdNYdFgVEUunLgFcsAsLzbXyhadNLqYcdfDQTDfVqkAqoMIIVXlcBxsqZZUdEkTisoHaTRZdrBsLGjjTIVcmJiVuMjJgOckIhMqlQGLsadjNjUsAdTgGUwScuCcxtXIOnZNQxYmCjBHNPiZPdPqvIEbeUG");
    string ZAxJhXwgm = string("iXpwyjaJKsZFVvwaXOojknEFnOlaPwItGrdqAaBHCSUlfTTdSWladTXBuOigEhgVLFotZPdzHhhOe");
    string OLXhvqnVJ = string("ZjYZLIIqmnHpaPfHmkeawIhWcGRijmQdQPENDfLKohnXQgBecUINBXgcgQaEEuFMhBSxJMcGdYqJJOALkpifmTcxcKAkcvBbvxKvJGYC");

    for (int MlezxBMfwwqOmfC = 683605643; MlezxBMfwwqOmfC > 0; MlezxBMfwwqOmfC--) {
        continue;
    }

    if (ZAxJhXwgm <= string("MOAEKMGzHwyoppodJqlqhJHiWolSVcxqsgXuynueNjLDFZiCBnRxjjjkfteKFFJOEQVSBZKeAILsVsXIUobCOHXfnQwfPatRDqXzVIcKvPxokgUEkZeEPTnxZMzTsLfONfU")) {
        for (int gfhMsgWVxP = 1060604983; gfhMsgWVxP > 0; gfhMsgWVxP--) {
            OLXhvqnVJ += oPfgWwTZaSeRQU;
            EallWzEzXME *= EallWzEzXME;
            gNhNtSiqfbI = EallWzEzXME;
        }
    }

    for (int BoKaBuJBoMPCTC = 1207283278; BoKaBuJBoMPCTC > 0; BoKaBuJBoMPCTC--) {
        EfYjMMRxnikLcDwM = EfYjMMRxnikLcDwM;
        JGgffaWhyVCYC += rbZWThDe;
    }

    if (fCspsUJxFtkeJs != 572397.2093691779) {
        for (int vxDDIgBZY = 361850472; vxDDIgBZY > 0; vxDDIgBZY--) {
            continue;
        }
    }

    if (oPfgWwTZaSeRQU != string("xhSUjahxHbrgNIzPSsHsPRLIxEgcYLELKprdNYdFgVEUunLgFcsAsLzbXyhadNLqYcdfDQTDfVqkAqoMIIVXlcBxsqZZUdEkTisoHaTRZdrBsLGjjTIVcmJiVuMjJgOckIhMqlQGLsadjNjUsAdTgGUwScuCcxtXIOnZNQxYmCjBHNPiZPdPqvIEbeUG")) {
        for (int iXmwNjwFtNeVZA = 1526125729; iXmwNjwFtNeVZA > 0; iXmwNjwFtNeVZA--) {
            EOxzvDZjxliGfZro = EallWzEzXME;
        }
    }

    return bZoFT;
}

void BnChIaAWF::aBgMiNH(bool aIVeeRzqe, string gVrtPm, int WAgfwZJraejROMLu, string HAXHvAfZNcdg)
{
    bool jioJxMPDBadn = true;
    double eHWYVSal = 878636.0319091699;
    int TuoBujZajHRdVZyt = 1885519402;
    bool VEGwGKEd = true;
    double jfgQvOzyBefRb = -508178.3972941389;
    string plLGxFmqcfbByABx = string("GCnTsxPOHOHHjzzHsHGVNQGKbSAdhtrpbuPbFmwsMfKYvgPbzIKfKtgeKonwegSsztArYRxokAIsdXwQnPnFHKMobtMfFyrzxjvgZKbMGgsoWXYqlknursofDSxfMfexDNQwxWcMpmRmpuyxUZkImCSFQLycAewvzNAeqdFaNLRfAPKWih");

    for (int vUCeAjMoVOx = 1387649919; vUCeAjMoVOx > 0; vUCeAjMoVOx--) {
        VEGwGKEd = ! VEGwGKEd;
    }

    if (plLGxFmqcfbByABx != string("pQzFpQetKUFKyxWdkusZOWEHqEuFaNWcGmQeZAp")) {
        for (int hBCMiyzJAbiWXeWK = 998151532; hBCMiyzJAbiWXeWK > 0; hBCMiyzJAbiWXeWK--) {
            HAXHvAfZNcdg = gVrtPm;
            gVrtPm += plLGxFmqcfbByABx;
            VEGwGKEd = aIVeeRzqe;
        }
    }
}

bool BnChIaAWF::xiEdNMa()
{
    bool OpSusizeAPOr = true;
    double PKQBwPCpx = 281792.42080595955;
    bool GJvmVYp = false;
    string BrelozuHjJUeAZ = string("anTYspOfcBDqiwBvHiiuGRUYNDsWWdYkcpqDSMkGHtvkZJlpfTEuCIwqAmLMXQjnSSFPUFyHukTHdWRdvVHfalQoZuoxSKgnIDGogTVLJKyWqqnSNXtsJCABAaeJVtcMwBcBOhyedTxFVczd");

    for (int dZtaCp = 1308318447; dZtaCp > 0; dZtaCp--) {
        OpSusizeAPOr = ! OpSusizeAPOr;
    }

    if (OpSusizeAPOr != false) {
        for (int KVtRnTENaKBuTi = 1322737479; KVtRnTENaKBuTi > 0; KVtRnTENaKBuTi--) {
            BrelozuHjJUeAZ = BrelozuHjJUeAZ;
            OpSusizeAPOr = GJvmVYp;
            OpSusizeAPOr = GJvmVYp;
        }
    }

    for (int MqkOZUTvCYLd = 1443302491; MqkOZUTvCYLd > 0; MqkOZUTvCYLd--) {
        continue;
    }

    for (int ViBYhxTJkl = 701494184; ViBYhxTJkl > 0; ViBYhxTJkl--) {
        BrelozuHjJUeAZ = BrelozuHjJUeAZ;
        OpSusizeAPOr = GJvmVYp;
        PKQBwPCpx -= PKQBwPCpx;
    }

    return GJvmVYp;
}

string BnChIaAWF::BPbNsJZsYuhHJA(double YSPypNqts)
{
    double OwYRHVDE = 960186.366390113;
    string QhwFZQUZgp = string("rQluzdEWBCXsjOjTrtmgKxNQW");
    int zJjFs = 456070712;
    double QifJCVu = -999666.9075527687;
    bool ClbYIBTTCpolGK = true;
    double ymkBTkrc = -654337.9859246647;
    double wiCUYtk = -994484.3321813676;

    if (ymkBTkrc == -654337.9859246647) {
        for (int kjSxFtyC = 272876633; kjSxFtyC > 0; kjSxFtyC--) {
            YSPypNqts -= QifJCVu;
            ymkBTkrc += OwYRHVDE;
            zJjFs += zJjFs;
            OwYRHVDE = ymkBTkrc;
            QhwFZQUZgp = QhwFZQUZgp;
        }
    }

    for (int JKaNsDy = 533647382; JKaNsDy > 0; JKaNsDy--) {
        ymkBTkrc = QifJCVu;
        wiCUYtk -= OwYRHVDE;
        ymkBTkrc /= OwYRHVDE;
        OwYRHVDE /= ymkBTkrc;
    }

    if (QifJCVu > -654337.9859246647) {
        for (int AmqCvhrnWwwceEo = 798305826; AmqCvhrnWwwceEo > 0; AmqCvhrnWwwceEo--) {
            QifJCVu = QifJCVu;
            wiCUYtk += wiCUYtk;
        }
    }

    if (QifJCVu < -807046.180709114) {
        for (int FpWau = 946143273; FpWau > 0; FpWau--) {
            wiCUYtk *= wiCUYtk;
            wiCUYtk += wiCUYtk;
            YSPypNqts /= QifJCVu;
        }
    }

    return QhwFZQUZgp;
}

double BnChIaAWF::VEXIz()
{
    string lNLWOferwikCQB = string("EcEsUDbgjxlAUdJcyvPmVRtnJbpZ");
    string WQxubUdVjq = string("UMbJSLiHWdEBeaekNRqGjNbUMeQvOjDcuDdLzKXtQRoiWJqTCrfXgOmWmTbfbXrsyVoxcKRdiCESxTTst");
    string mWACnV = string("UvOSatZoGeOWmGOOmfYuYhmGuXjXjCNZUMyEpwVBtNhyvGSbBcxLmBdCHFiUtuVZgmiTEYiBCzotWhHL");
    bool jMIEHtzLr = true;
    int abCtzOfYka = 1441784374;
    double ZoEyOiBQdRCW = -606656.8239286281;
    string bGylEyeXWKkwu = string("joGssBsT");
    string yiujrRWax = string("uuMyalfkVvWGl");
    double nCHTGfuMNhK = 777365.2773174868;
    double iRnwWIVYXodIlqSB = -619213.01653855;

    for (int CxdRG = 248638693; CxdRG > 0; CxdRG--) {
        lNLWOferwikCQB = lNLWOferwikCQB;
        ZoEyOiBQdRCW -= iRnwWIVYXodIlqSB;
    }

    for (int PGfEbUMArlxHmor = 71837606; PGfEbUMArlxHmor > 0; PGfEbUMArlxHmor--) {
        continue;
    }

    for (int QKlinPorzlfQIFNA = 1121997678; QKlinPorzlfQIFNA > 0; QKlinPorzlfQIFNA--) {
        mWACnV += WQxubUdVjq;
        yiujrRWax = lNLWOferwikCQB;
        WQxubUdVjq = lNLWOferwikCQB;
        WQxubUdVjq += lNLWOferwikCQB;
    }

    if (ZoEyOiBQdRCW >= -619213.01653855) {
        for (int AJDzLhBFUqxqvP = 310488158; AJDzLhBFUqxqvP > 0; AJDzLhBFUqxqvP--) {
            WQxubUdVjq += bGylEyeXWKkwu;
            bGylEyeXWKkwu = yiujrRWax;
            WQxubUdVjq += mWACnV;
        }
    }

    return iRnwWIVYXodIlqSB;
}

void BnChIaAWF::LqyYFDhossXb(string JBmFWJmiRGFUc, bool mHCdXPSV, bool rYlGRdec)
{
    string JWRSaCjKUVeYy = string("QRzgkQOZHyThIkqLYhqLoPDFWDXAOULSgajSImGJjSaaYkdRqMZVCySbeqsIBXMVVSaByHwdPpUOEDCfKNgffCdakliAWyDxUxZkNfQvvLgoojfUbxASQiqengJTGVVRMdzdfhqGiccsQxaVwHG");
    string YjGIYUKiH = string("SPanMmzlMpGyAZVDZILgbRcobEDJLvZKcGVkaloXJRvaiaqebFywZhYRdpdipttdzSCKekzCUURMDSPoSJQFFijmQZKEPkIGPxcWK");
    bool gyuJRgCvpycvhbt = false;
    string LrOycZnKIeuk = string("oJSMpbEtIuYnqNDNKbIpvTtfWHaFsHVzSFcBQKlONzdLvNdWKmxSqbCtoiyURHFoPtCFMNLfsBWhnPivbqVYeWHjqGwrFuktVOfYJrbnNCBFMPpvGDCxEYVoomROpUzIcJvKNyAijeElxaMgrTArGdUakjlRpSzAVzuWAGHZnRToYveufqYGTItsGGcvaXbrBTimIokcKvtzuNDToOPZhMjyCJdaJFYJbfAidRRBKkFn");
    string FHQmLfvWDrRN = string("nHeiqJKIXgjMcrGCSGvNxJyBeTDXVTMbCUYZJWoEblOCRRPiHRVCiztiSjRFRNmuXzsCgAuqdzFoPAtpJOGBEvqMKZCogtymRaGaaATWKBFlkFmPyIKObgqDMvgmegzPVFlKTCVPkMPNCpUmqlSEWTiTWseWEwjmNMJSIjYwsXFhBSOInNktvQGDqXgHXjzOYapZWEUxlGbiIzaYerRQFrDCyNBaixnfXuDVwuuPifaXPSTuTYwwTNMCzrWN");
}

string BnChIaAWF::nnUKGCcTsXSzge(double dvjpY, bool dXMfVEFPQHBcs, int sTKDKoBTX, double ZkFnzLVOtUMQ)
{
    bool NEEeFyJAXGgUbRJ = false;

    for (int djrZfZGp = 1425617841; djrZfZGp > 0; djrZfZGp--) {
        NEEeFyJAXGgUbRJ = ! NEEeFyJAXGgUbRJ;
        NEEeFyJAXGgUbRJ = ! NEEeFyJAXGgUbRJ;
        ZkFnzLVOtUMQ -= ZkFnzLVOtUMQ;
    }

    for (int UMIJgApNFPq = 107906608; UMIJgApNFPq > 0; UMIJgApNFPq--) {
        dvjpY = ZkFnzLVOtUMQ;
    }

    return string("rqJSfiEluuXZirYupzocbsmwGkMVcrfVFkukvHnsOFEzpLfMoYMHXmyIatgRhbELsSfngcdMADlLROTFsVSyugnSJJnLNgxLmsQNuSNDXuZhrDcJluKIGjgdSSSpiLegDoiwGdKosGYsOLvDjZYuIcyKnWVvjEADkQfXvCrxKEUW");
}

bool BnChIaAWF::KrnLQJwHIYyVUiDa()
{
    bool fXLLlLXurjsU = true;
    string ekhlDYpesZQ = string("TuUTwbwszEnZDhwqlxjuUzCRZYZjkfFdSkcEOAAWHeUPjbQJmFOhQwFoMQpQwGfSxfsBYGLjCeZZmrVjvLOZBwrbaNedZlxxqeYyTqHWhKScnoUehNSaYudkIWnOZaxJszM");
    bool FUNaUauGU = true;
    string ytRITTb = string("VNDZsOfeWVGbUeJERxkUwIeEhliNCFzkKkdnfwlQEdbnIIGprXLVPSoykALMAnJXISZRRQMKAXXjLcxhOSyyzydnIgmMONKwzGwNnRdaPQuFKyRzLRtiVTdnsSnsaUwllwPAZmWZevknoVMjZUtJsQzjFTOgtnvQfRBqbXamWLrjBTVeBPWqR");
    int NBHBctzGMXfZNoCL = 355453348;

    return FUNaUauGU;
}

string BnChIaAWF::aGjBJRbfAwimxVJa(int ZCtSJNooSMinq, bool cIhPGvZxjHESb, bool AyFFZOOZMXk, bool JKqJP, int HbhLErsyc)
{
    int IITJnPudlAr = 980544322;
    string pMJfGWkCO = string("PfmtfuMnQpjuyMoGTYcZVxCVrMDrkxMsIIBOBHdfBIqanDDDjPZHENiCbCfzynfUwxVLgunZFSWWdTABPiKivzogUUEcRhmpwoAyHrWRhVXuThPdqsNGZxjCVyjZFyGGYBaVgYblTrmusdraHsgRYzPOXzUvVumOFnVPryUxcCnQwR");
    double jlRJjrP = -640904.3425910122;

    for (int azekUBKW = 1199893031; azekUBKW > 0; azekUBKW--) {
        ZCtSJNooSMinq /= HbhLErsyc;
    }

    if (cIhPGvZxjHESb == false) {
        for (int sjRqSFFVzmn = 1405184854; sjRqSFFVzmn > 0; sjRqSFFVzmn--) {
            cIhPGvZxjHESb = ! JKqJP;
            AyFFZOOZMXk = JKqJP;
            cIhPGvZxjHESb = ! JKqJP;
        }
    }

    for (int ChvNxQdCCmMiaeeK = 2059892068; ChvNxQdCCmMiaeeK > 0; ChvNxQdCCmMiaeeK--) {
        IITJnPudlAr /= HbhLErsyc;
        HbhLErsyc += ZCtSJNooSMinq;
    }

    return pMJfGWkCO;
}

BnChIaAWF::BnChIaAWF()
{
    this->rfNTUI(true, 1720368494);
    this->IcodfoFELYtV();
    this->fToSeXgj(string("XeISiGDGlLgxraWGBrDRveJTFBiEPyaApCFLWTXLaNoEoPUzSrhExIlrNVUQJQfIATHSgsrYfumqXjXMRhElQhWCVtXQTPPJFkGvUAfHUqNRLDHxpyLYdAtLTTqvXiuVMKlmQPeKGYcPaOdiTBzvLQMyfOHsYFzA"));
    this->RhbxrpCXZTfQ(string("BJlLflXewmAvpAvHhYEhiBtHlHQ"), -94524398, string("MsaSJCgPwdxtkmpsgUfiXPZlTEOcQnACksEAIBZVWmlMGencWYnkIoNiSrmG"));
    this->AaZZOj(-1090351115, false, -1858728651);
    this->CIkfx(string("EpeuVeQhoSywLSaeKFOXgVHspfjWjjzNnApmgSwMyRsfgRZeEQDYHxlevoIMAzfmeitSGTHKBfGEzqBnfbTPlEuVUEviWowsJUCzucOoNrIwKQjATKurRJVfRAexpNzrHDEpnMKKLaeJuBUBEMuUkLGQURwgmuXwSrh"), false, true, false);
    this->iJbYhm(false, 1139643925);
    this->tEMaRaniqFoQDP(1003729.8081683666, string("vyuApQFyEdRCKIhbDJjxqrTgUAyDzHMJfdGlosRQSyouDkYBjqkcgsfVwcnHu"), false, -755890.7792638062, -786272.3951444834);
    this->aBgMiNH(true, string("pQzFpQetKUFKyxWdkusZOWEHqEuFaNWcGmQeZAp"), -662224114, string("th"));
    this->xiEdNMa();
    this->BPbNsJZsYuhHJA(-807046.180709114);
    this->VEXIz();
    this->LqyYFDhossXb(string("FfmkNmprVHnjDtMapwQDpknsiTLxnKkuYNWNyFJvseSgZEYItrlxoUApKXROBZcKKIkwsgXHPqLELCKEN"), true, false);
    this->nnUKGCcTsXSzge(592639.4204192212, false, -90283893, 983642.8412095293);
    this->KrnLQJwHIYyVUiDa();
    this->aGjBJRbfAwimxVJa(1667508802, false, true, false, 372322043);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bimFuDDrH
{
public:
    double ChsjvxgiQDgu;
    int RzqEhmuUIYcKNxod;
    bool XwQipeynVRqgsAhA;
    int mhVZmmUgCFCC;

    bimFuDDrH();
    bool XwYULGxP(int ukpruTePqXt);
    string zYVmhYiULgL(int CeTnQnhcaBTQpgh, double yVKtHeCFjhyvEel, double DGSbQZIT, bool ByENzQwmiXhwlO);
    string qcFXMtmJHiAT();
    double BdDNSeDOggKcBjT(string XOxjYHrFJIX, string iqLUyUgv, bool AJHTboN);
    string quCEqr(double COcVFEdQipmbMP, int pSfKC, string wURjycBiMpgMZ);
    string OfczfIQPt(double NNAiTsaodYmkI);
    bool FABAKmmcFjcVTI();
    double kcEFDfC(bool VNfRcMKHJLSBI, double BplmoOFp, string hLaVrON);
protected:
    string VhRnogPByR;
    string OftrpZfi;
    int DEqjwYeIlMqhWxME;
    double vDmjVLsUpwPPDGp;
    double kLeFx;

    void uXzigQIhyey();
    bool ULYHG();
    int GniwzHwnmiyQWI(int AiLhxPLBgrvm);
private:
    int uvLIxEftGteOiXSI;
    double RtnvTSG;
    string kBYTguD;
    double QYJasLGoZyCWQ;
    bool MYJVMTgHChA;
    bool zAlnnDfFNRe;

    void TkxKIGFm(string rJWfzwJZPRGYZl, bool wehEERsvj, bool cUewBgWdeL, bool HcFfwJtBDTWbN);
    bool TSCPCdZmyLmtJ(double XLBckDK, bool OXBQoVV, int jAfaENrcY);
    double uKiEFnR(double rxovqcIS, double oYqxsdulPF, int HeXPSVTAtyw);
    bool mDABRsFygV(bool cEyMPxCcjryPNm, int suxHXocsWNAMbit, bool YJlIWCbbWTtdz);
    void vskYYdrsmta(double xHIqNTtDigLmDEKG, double aXEXkhXXpvtWiX);
    bool QIejK(string YanBWS);
    void HuUoBIWoQoimmn(bool bKFYAqE, bool fyefXkXjvWKNHGK, bool YZdPbGVTfXdk, bool GdFmMMnv);
    int mVuPFNozjnoNfcCV();
};

bool bimFuDDrH::XwYULGxP(int ukpruTePqXt)
{
    double PVlEdbOW = 468098.9317280033;
    bool GFTevqkGnidYbz = false;
    double TSRLtbQgXRINNDxp = -30532.643362016497;
    bool eYemrxdzmyrf = true;
    int GLLccyjEIQLZY = 779066043;
    double sOjtbDFtDxucLEh = 65145.09453744433;
    int zMmMe = 107618279;
    int yQdUonkhePDNeYJ = -20622207;
    int jkFabKzORoIGr = -1320888026;

    for (int XiacsXZDS = 508433384; XiacsXZDS > 0; XiacsXZDS--) {
        jkFabKzORoIGr = GLLccyjEIQLZY;
    }

    for (int XERiTOWQ = 155029502; XERiTOWQ > 0; XERiTOWQ--) {
        continue;
    }

    for (int flcrxbvCSp = 333255004; flcrxbvCSp > 0; flcrxbvCSp--) {
        zMmMe += jkFabKzORoIGr;
        sOjtbDFtDxucLEh += sOjtbDFtDxucLEh;
        zMmMe -= zMmMe;
        zMmMe += zMmMe;
    }

    for (int IOuEqYzepOCbRqU = 1143698680; IOuEqYzepOCbRqU > 0; IOuEqYzepOCbRqU--) {
        continue;
    }

    if (zMmMe <= 779066043) {
        for (int BcRnYyDNhtAujlmF = 1897094122; BcRnYyDNhtAujlmF > 0; BcRnYyDNhtAujlmF--) {
            GFTevqkGnidYbz = ! GFTevqkGnidYbz;
        }
    }

    return eYemrxdzmyrf;
}

string bimFuDDrH::zYVmhYiULgL(int CeTnQnhcaBTQpgh, double yVKtHeCFjhyvEel, double DGSbQZIT, bool ByENzQwmiXhwlO)
{
    double ZxQNXZIUOWb = 599740.3157952089;
    int EiNSKJOaGBmgk = -1081461025;
    bool UgxwugJBy = true;
    int keMzXruuNR = 1582502830;
    bool ZrDMCv = false;
    int PfznibJVUBdKeia = -332139031;

    for (int iAKOpVQfsnjug = 1356127052; iAKOpVQfsnjug > 0; iAKOpVQfsnjug--) {
        PfznibJVUBdKeia += EiNSKJOaGBmgk;
    }

    if (EiNSKJOaGBmgk == -1081461025) {
        for (int paSSlJsHue = 959656362; paSSlJsHue > 0; paSSlJsHue--) {
            yVKtHeCFjhyvEel /= yVKtHeCFjhyvEel;
        }
    }

    return string("uBLKyqHMHZKKnfYXtUhpaWqazpWctTXJaZgsLZYcPpcmOvsyBoyGxgZOzAeBdrwQpxEIXdiRbVPCntKqZyZNyampEqIZRHBmlnsiZsskavv");
}

string bimFuDDrH::qcFXMtmJHiAT()
{
    string wzxJRwqXk = string("iWjHLolOITTccDlpILLTpObGlGTLgTqIiJsytzuQxxUydGwNQIKObIEZQiJTcKIKntEDKPdfueVrazDPSDTgsxJoWKAjLIqRrJqGWzyyarvKdjZUKJKkVeTpBEAekBrvUKGvVMUKDwqHiMHflOLwDoWLbTPeHXQJpPDabxsXOFytCePtqmIJMcFLGvwjzlNfF");
    double IQZrfTkryfwNL = -348173.922729267;
    double VZRdzsmxbldf = 377511.99154119403;
    int RNHUZmgxmEC = -234684320;
    double zYJrrLxPKf = 762391.5729906338;
    int lPPfjtDpJNuEuG = 1006395006;
    double MGEpfJsPuG = 318185.45564909384;
    bool erbWXJofN = false;
    double CBLmXUvoKUZl = -243850.7505616186;
    double PLEbzVZNJmAElvJQ = -807672.6727285038;

    for (int kqYslD = 955308867; kqYslD > 0; kqYslD--) {
        CBLmXUvoKUZl -= zYJrrLxPKf;
        zYJrrLxPKf += MGEpfJsPuG;
        erbWXJofN = erbWXJofN;
        IQZrfTkryfwNL = MGEpfJsPuG;
        VZRdzsmxbldf += MGEpfJsPuG;
    }

    for (int KiZejYkAwX = 1077163927; KiZejYkAwX > 0; KiZejYkAwX--) {
        RNHUZmgxmEC -= lPPfjtDpJNuEuG;
    }

    for (int OeVAndLbYz = 2136993505; OeVAndLbYz > 0; OeVAndLbYz--) {
        CBLmXUvoKUZl = MGEpfJsPuG;
    }

    return wzxJRwqXk;
}

double bimFuDDrH::BdDNSeDOggKcBjT(string XOxjYHrFJIX, string iqLUyUgv, bool AJHTboN)
{
    double IonKqfrnClXAZWk = 992779.7621861979;
    string GTxuc = string("zVXIgUuZjbURcWRHTPsbUUwqXruyNSJaoUkOgSOGKjoJBgdevZNrjtTIGfFlfCt");
    int KRPEZGz = 303385632;
    bool XvECVPluPNnfB = true;
    double RpZEhYAiZrzCmyae = -848117.845447996;
    int ObgixMm = 1231359538;

    if (KRPEZGz == 303385632) {
        for (int pRqefvVwTwBPRyPC = 692335930; pRqefvVwTwBPRyPC > 0; pRqefvVwTwBPRyPC--) {
            AJHTboN = AJHTboN;
        }
    }

    return RpZEhYAiZrzCmyae;
}

string bimFuDDrH::quCEqr(double COcVFEdQipmbMP, int pSfKC, string wURjycBiMpgMZ)
{
    string CcMPDOPMEZBs = string("UJVMeEJiurmBMfQsYIsKOENxOsjvtfaIGHpDsulomGUbTmGUeBOtIEYMCpyKlkpeIPaldrkKgobicMZdwfwCJZAoznaiGpoixJrRDlgqsOrbMKfEAczQMejzKXFaECagOSksqaEDxuBtWTFpNqFEzVXdpRnIDwjiuKnMpEAoDaBjiYuArxQOwlQnxuakJAUKbeuJdUDlCqrmbgvoy");
    double uxeJuVI = 398195.12426280684;
    double AeoSYQabZhAcBHyw = 923453.1693020037;
    string siMXUfLS = string("pVuFEqlSqfZbmXCkvfkxwIcnbbdOJKMbqefcArePZTqQNCtBCF");
    string jfHOxTBWhG = string("GDFxNnBDDmIYkCMiMHLchZhfGjqHtGvHFmfGwN");

    for (int FsVavqTyCnWHT = 1445917431; FsVavqTyCnWHT > 0; FsVavqTyCnWHT--) {
        continue;
    }

    for (int fLusNL = 1843016373; fLusNL > 0; fLusNL--) {
        wURjycBiMpgMZ = wURjycBiMpgMZ;
    }

    if (COcVFEdQipmbMP >= 411327.85906046623) {
        for (int sybBG = 873322266; sybBG > 0; sybBG--) {
            jfHOxTBWhG += CcMPDOPMEZBs;
            wURjycBiMpgMZ += jfHOxTBWhG;
            uxeJuVI = AeoSYQabZhAcBHyw;
        }
    }

    return jfHOxTBWhG;
}

string bimFuDDrH::OfczfIQPt(double NNAiTsaodYmkI)
{
    double KhPseOPFa = 124458.7268154022;
    double fYDwmHNnxX = 250445.32536974773;
    int DlmRcBjAZR = -1062286407;
    double PFAYqEXdSuAh = -308794.42501329485;

    if (NNAiTsaodYmkI < -308794.42501329485) {
        for (int mpZPYsiyVxqyLOq = 374775730; mpZPYsiyVxqyLOq > 0; mpZPYsiyVxqyLOq--) {
            fYDwmHNnxX -= PFAYqEXdSuAh;
            KhPseOPFa *= fYDwmHNnxX;
            NNAiTsaodYmkI *= fYDwmHNnxX;
            NNAiTsaodYmkI *= PFAYqEXdSuAh;
            NNAiTsaodYmkI += NNAiTsaodYmkI;
        }
    }

    if (PFAYqEXdSuAh < 250445.32536974773) {
        for (int fzasMeQrtiUDaD = 2038597054; fzasMeQrtiUDaD > 0; fzasMeQrtiUDaD--) {
            KhPseOPFa *= KhPseOPFa;
            fYDwmHNnxX = KhPseOPFa;
            NNAiTsaodYmkI = NNAiTsaodYmkI;
            PFAYqEXdSuAh /= fYDwmHNnxX;
            fYDwmHNnxX *= fYDwmHNnxX;
        }
    }

    if (PFAYqEXdSuAh != 124458.7268154022) {
        for (int VhLNJhfrB = 1346028029; VhLNJhfrB > 0; VhLNJhfrB--) {
            KhPseOPFa /= NNAiTsaodYmkI;
            PFAYqEXdSuAh += PFAYqEXdSuAh;
            PFAYqEXdSuAh -= KhPseOPFa;
            NNAiTsaodYmkI = NNAiTsaodYmkI;
            NNAiTsaodYmkI *= KhPseOPFa;
            PFAYqEXdSuAh -= PFAYqEXdSuAh;
            fYDwmHNnxX -= NNAiTsaodYmkI;
        }
    }

    if (NNAiTsaodYmkI != 124458.7268154022) {
        for (int RJlnwJLjIXqOjP = 1361252207; RJlnwJLjIXqOjP > 0; RJlnwJLjIXqOjP--) {
            PFAYqEXdSuAh *= KhPseOPFa;
            PFAYqEXdSuAh -= fYDwmHNnxX;
        }
    }

    return string("PlKBSEaiLUgjmGBBHSraAJRzYsWFgCP");
}

bool bimFuDDrH::FABAKmmcFjcVTI()
{
    string UmmUiuGOnftTTsI = string("xFMyxJYkQWLGRCIYjcaXYCUBeDOmziALvhukgwYaooIiuGWZCLYSZvWEHWfCGdUPFgquOsbPKceclsClREfJynPtdGQLrCiDuKlZKhcCsr");
    double hEkmsqBpjyf = 340765.62097788;
    int CAhYqbvg = 170247969;
    double JyxWVbwkayeGgBx = -260607.53650370013;
    int KVdvhrCpfzH = 1556309649;
    string SxJrjWwu = string("YlkoONoWzQiyXctQcHFhGmApHPCsFPEuGfmTkxACtmvVNmbxXXRcCzbhrlIyPZTOJeridSMswMAuaiNUDMqmVRIXZgaBEaNboeGbxTZcEeIqHauQGYMdlWvGxGaFkcGugCjOemzmzoscMW");
    int gTUxID = 17994274;
    int IfwafXizdiLo = 1533079349;
    bool inOuu = true;
    string JNQdlpCp = string("fMxXuDspwjaoHoKKqDeYWhYeZRrQyFlEZFRDhyXibzWbZRFfMzzSPyiokNvcRMM");

    for (int hYtramtLywaUneP = 529826942; hYtramtLywaUneP > 0; hYtramtLywaUneP--) {
        continue;
    }

    for (int uVYiNrjKMLdiyUft = 989366242; uVYiNrjKMLdiyUft > 0; uVYiNrjKMLdiyUft--) {
        gTUxID = IfwafXizdiLo;
        JNQdlpCp = UmmUiuGOnftTTsI;
    }

    for (int AHdpauOaNKYSb = 13538181; AHdpauOaNKYSb > 0; AHdpauOaNKYSb--) {
        continue;
    }

    for (int MyLEZoLI = 415567748; MyLEZoLI > 0; MyLEZoLI--) {
        hEkmsqBpjyf -= JyxWVbwkayeGgBx;
        KVdvhrCpfzH += CAhYqbvg;
    }

    for (int fRHeekyUxvvVknC = 277105464; fRHeekyUxvvVknC > 0; fRHeekyUxvvVknC--) {
        continue;
    }

    for (int BZlVObs = 690514513; BZlVObs > 0; BZlVObs--) {
        CAhYqbvg -= IfwafXizdiLo;
        JyxWVbwkayeGgBx -= JyxWVbwkayeGgBx;
        SxJrjWwu = JNQdlpCp;
    }

    for (int shSHOgDurq = 1319912831; shSHOgDurq > 0; shSHOgDurq--) {
        UmmUiuGOnftTTsI = JNQdlpCp;
        gTUxID -= KVdvhrCpfzH;
    }

    return inOuu;
}

double bimFuDDrH::kcEFDfC(bool VNfRcMKHJLSBI, double BplmoOFp, string hLaVrON)
{
    double mBUFOKc = 289333.52732088504;
    string ORMGdvfqgoTsi = string("veqaynCdbVZenLSEUWKMJamDAWqVDeoIxwzZOFGixEFoKodusVRXmEjiqwrfmRhjyePCySyUhuKqZukTKqeWjZTyldPbbYKJdsJCGIvDhdohumynmQReIpEDyWtsxUgQFaxHJkBMgvABROqSxkJxvIXQWqNRxNwQEnBpHpjjZvhOxXKbuFZgSKmmOIZ");
    double hADPPKHpPfah = -75265.26025424404;
    int TpvhtTws = -74034455;
    int eINVTxTywHAmzno = -815375989;
    string hHQAzg = string("HKQTHdoORcUofYOzhdrTQVsKdJKRJghrKYKIaZsQHheNrzJuAMEoezrRWbVxdHMjpaeVxgdirXnJixrouoFkOLUTNvLYbtukVFilqhgNFxstZBkrbqGLHuhTBebRgoPzWlrYAxQQSrucgjjkdpkMOIMfQJdkfJFhmrHQtjU");
    string PIxOQ = string("gexHpasMRmHpNLqGzuXrXPkobydGIjvLwyOOZwPTDqLsFDtYBCwwKHECVC");
    bool nqEegQHudIb = false;
    double fQjqzRyuNuLuDDq = 483596.2675615485;

    if (VNfRcMKHJLSBI == false) {
        for (int wjjlAI = 1686832703; wjjlAI > 0; wjjlAI--) {
            continue;
        }
    }

    for (int gLxOzPCIuBSowbEV = 752387926; gLxOzPCIuBSowbEV > 0; gLxOzPCIuBSowbEV--) {
        fQjqzRyuNuLuDDq *= hADPPKHpPfah;
        PIxOQ = PIxOQ;
    }

    if (mBUFOKc != 289333.52732088504) {
        for (int AJKcs = 1908218521; AJKcs > 0; AJKcs--) {
            nqEegQHudIb = nqEegQHudIb;
        }
    }

    for (int rzopYYlgrZ = 554721147; rzopYYlgrZ > 0; rzopYYlgrZ--) {
        mBUFOKc += BplmoOFp;
    }

    for (int ZgwIN = 1503552554; ZgwIN > 0; ZgwIN--) {
        hLaVrON = ORMGdvfqgoTsi;
    }

    for (int tVDpiAgPVDS = 1952162815; tVDpiAgPVDS > 0; tVDpiAgPVDS--) {
        hADPPKHpPfah = hADPPKHpPfah;
        mBUFOKc /= mBUFOKc;
    }

    return fQjqzRyuNuLuDDq;
}

void bimFuDDrH::uXzigQIhyey()
{
    double jAZPHth = -718225.2666895707;
    double vxfLtbUdKuB = 438800.6455674708;
    int xyajuFqVlancc = -1177320107;
    double lKdvQrhMjDGK = 648602.2116362114;
    string psXfpADj = string("yTndjXONLYQVwLQgqwYjYfJpacGLwbuOHGHbdtCysVZrGobQruYXWSqlCJXMNaOmEJZzLzAtmyJiVOEDTPsLmDzdBkxTCOdro");
    string pyAIrmawkVROViVX = string("ybPOJLwKwiBQZpneZHNAPEJfShBfKPCKmnwQCseHjIIjmrfylNBFYIJawASIVUvlfzfBBTQrsTQLYpuStrFaTwKHXXPbUIAnskPYnCIRFNmOUoVVNaTpqeIJvLpEfVXXCULvrbZBmWAwIeZHgjhDyPVdrN");

    if (pyAIrmawkVROViVX > string("ybPOJLwKwiBQZpneZHNAPEJfShBfKPCKmnwQCseHjIIjmrfylNBFYIJawASIVUvlfzfBBTQrsTQLYpuStrFaTwKHXXPbUIAnskPYnCIRFNmOUoVVNaTpqeIJvLpEfVXXCULvrbZBmWAwIeZHgjhDyPVdrN")) {
        for (int TPGctAAMY = 810118767; TPGctAAMY > 0; TPGctAAMY--) {
            psXfpADj = psXfpADj;
            pyAIrmawkVROViVX += psXfpADj;
            lKdvQrhMjDGK = lKdvQrhMjDGK;
        }
    }
}

bool bimFuDDrH::ULYHG()
{
    string SfuotCKwp = string("LrXtXBFfGmwSanNagiTvnvuvXDfQRXVaYrTiDswOhDStzjDPlomGDXdblraLnNzJB");
    int ICiWOIFnUE = 2124437617;

    if (ICiWOIFnUE <= 2124437617) {
        for (int hWCLWx = 1564062769; hWCLWx > 0; hWCLWx--) {
            SfuotCKwp = SfuotCKwp;
            ICiWOIFnUE -= ICiWOIFnUE;
            SfuotCKwp = SfuotCKwp;
        }
    }

    return false;
}

int bimFuDDrH::GniwzHwnmiyQWI(int AiLhxPLBgrvm)
{
    string WWWWWFjxnQwebLFK = string("IisiZQUwAdKQEFVZDnBSvkczSfTnFsrVfDEilCokeOWjrpasIsrJfvfTDGHHvVHUmMgfzbkyFsAARXBeEuxirZpAhvLvCijmJMpXWqyBvuEtvZeiCLBmbOhWdzahsWPhbmHavRaQBIEiyuJeksVQhrVxtJekXEWoiKtKDveI");
    string KPqrraW = string("WyRDAyfHpzAvYczkYimGctQDpehOtobsebjwzKWvsozLrKePQNQwvSCIajPqFXzQvHVTkXJCKLOGdyJqSvGzuxEfkmabGozhihvgktmpbPwsDbuhqJQaXjKVPAwCaWZmHMregoFiQmdwiHjHEmcuUQYaMFRaXBNYTiah");

    if (KPqrraW == string("IisiZQUwAdKQEFVZDnBSvkczSfTnFsrVfDEilCokeOWjrpasIsrJfvfTDGHHvVHUmMgfzbkyFsAARXBeEuxirZpAhvLvCijmJMpXWqyBvuEtvZeiCLBmbOhWdzahsWPhbmHavRaQBIEiyuJeksVQhrVxtJekXEWoiKtKDveI")) {
        for (int jgiQdRUnIKdDJFC = 1263211078; jgiQdRUnIKdDJFC > 0; jgiQdRUnIKdDJFC--) {
            AiLhxPLBgrvm += AiLhxPLBgrvm;
            KPqrraW = KPqrraW;
            AiLhxPLBgrvm *= AiLhxPLBgrvm;
            WWWWWFjxnQwebLFK = KPqrraW;
            KPqrraW += KPqrraW;
        }
    }

    return AiLhxPLBgrvm;
}

void bimFuDDrH::TkxKIGFm(string rJWfzwJZPRGYZl, bool wehEERsvj, bool cUewBgWdeL, bool HcFfwJtBDTWbN)
{
    int zIwFE = 1412854758;
    int yLeHvnhXtwsxr = -889824657;
    bool moBQgNTaxB = false;
    double IdEzoOwDuMJ = -70829.95699720157;
    int xDwQYCuflHJC = -60193330;
    int wtdmMfzSVgnHCbV = -787015930;
    int BihCJNydlGBeu = -584824435;
    double WGyiwAdWcLSGWTt = 329078.2741409185;
    bool YIEcXDXs = false;

    for (int NPQYNkPDXYtFrxj = 1875424930; NPQYNkPDXYtFrxj > 0; NPQYNkPDXYtFrxj--) {
        continue;
    }

    for (int GvonZxSPY = 275064216; GvonZxSPY > 0; GvonZxSPY--) {
        HcFfwJtBDTWbN = ! HcFfwJtBDTWbN;
    }

    if (xDwQYCuflHJC <= -787015930) {
        for (int OSxRsuKWIsSCiS = 531072929; OSxRsuKWIsSCiS > 0; OSxRsuKWIsSCiS--) {
            continue;
        }
    }
}

bool bimFuDDrH::TSCPCdZmyLmtJ(double XLBckDK, bool OXBQoVV, int jAfaENrcY)
{
    string BGPKYIAGznNueFb = string("ovBXzcOkOTQasOctcwcvsrnubTsBWMWeYfcPmlEAZtvWdOvCoTVvWqjdKJaRrxsaIiWEgFozBPSyDqsXUwYVmtUWIMUZUoddXSsOllhbbGRLKmlzLWBgjHpwcwjCHaWdlWUpvtUFULcGAqxSjdGvCyrOaM");

    for (int HNralPU = 1994342763; HNralPU > 0; HNralPU--) {
        jAfaENrcY *= jAfaENrcY;
    }

    for (int PtmzJkFuzVOj = 88940214; PtmzJkFuzVOj > 0; PtmzJkFuzVOj--) {
        jAfaENrcY *= jAfaENrcY;
        jAfaENrcY *= jAfaENrcY;
    }

    if (XLBckDK <= -20115.959387798768) {
        for (int WPlHkesutsEHGSE = 1759377223; WPlHkesutsEHGSE > 0; WPlHkesutsEHGSE--) {
            BGPKYIAGznNueFb += BGPKYIAGznNueFb;
        }
    }

    if (OXBQoVV == true) {
        for (int VJaSB = 783769168; VJaSB > 0; VJaSB--) {
            continue;
        }
    }

    return OXBQoVV;
}

double bimFuDDrH::uKiEFnR(double rxovqcIS, double oYqxsdulPF, int HeXPSVTAtyw)
{
    int qbrUOlwKQ = 1882410517;
    string kclbQFtaFTpoq = string("cdsFCkMyWOrjCzrhOojEZZaoSjHeveiOydZpqVTsXPIjenzkcwNdPSrNmHMCtsMCZvVrXGOkjATwcgNRfmCthfqHvrpIfFigsGXlxXCXmOCFEkCHokifSsgRzUSyYCloPoj");
    bool aSdqd = true;
    int aVAsBgA = -2122958938;

    for (int WRyuhAJjGfqSRc = 1724596983; WRyuhAJjGfqSRc > 0; WRyuhAJjGfqSRc--) {
        continue;
    }

    return oYqxsdulPF;
}

bool bimFuDDrH::mDABRsFygV(bool cEyMPxCcjryPNm, int suxHXocsWNAMbit, bool YJlIWCbbWTtdz)
{
    double FbemBNou = -524830.9261578905;
    string LBVAiCwBocSYIgUM = string("RytzumPYPPPZyMnLSVRRyCHkCgiTLfcjTmoplUyVYgYrUfWuPIsIaBtTUyXnVbyvZtcrWmpDlZUUkNyboEaMMLfqrMsLdGIoaKpXClqEIQBExJsySUqcKLqxMvjsoacwvvwUvfeZpJchxjOhfK");
    bool QDhRLQAdsn = false;
    bool cfOcSxQOEybYOvWx = false;
    bool KGLinqM = true;

    for (int NAbNYdthSucLjqk = 2061678963; NAbNYdthSucLjqk > 0; NAbNYdthSucLjqk--) {
        continue;
    }

    return KGLinqM;
}

void bimFuDDrH::vskYYdrsmta(double xHIqNTtDigLmDEKG, double aXEXkhXXpvtWiX)
{
    double WiuqNgFVBFb = -361659.19932994054;
    int WGNadKFclkuBQFT = 1962946903;
    string kdJyvoSobJHgQ = string("cWqjWFFzSEfJQHKNZCpqGHxxeLvdOkJtjvjIuBxvQILAIxyAFrTUHzQxtWWbqkrDnbjDEGmPiOkWuqJVMBXydIEDwkWZkVTTgsKbhMMNKUoINrKUKXHukPctPtEetQElJpWkjKIHPjnd");
    bool gqDiSgHbUWeMUUN = false;

    if (xHIqNTtDigLmDEKG != -568918.3109798424) {
        for (int TDsvVphM = 1648412396; TDsvVphM > 0; TDsvVphM--) {
            aXEXkhXXpvtWiX /= WiuqNgFVBFb;
            xHIqNTtDigLmDEKG -= aXEXkhXXpvtWiX;
            WiuqNgFVBFb = aXEXkhXXpvtWiX;
        }
    }
}

bool bimFuDDrH::QIejK(string YanBWS)
{
    bool UljbpjdXjTv = false;
    double dcFbdTliGgI = -382779.1848500354;
    double NrKDYrgOLu = 12269.628806988536;
    int VDDvyLlcqv = -766206555;
    string OUKUdJPcJWckm = string("VtEjZElHDCzkOMrUlciTgYUkftKYYseCxLGIZxRxsNZjLaOvpFTncjGxc");
    double ILtXsxmwQAzRzK = 1032844.2761324458;
    bool vwnIbQYzC = false;
    string TKIWEUjJetJRSRpm = string("HKZCxueTNWwBILyvaTZSbWphEADALHFyMixLwGXdEnJBcNPP");
    double DUJztKNAwHQ = -574426.892758814;

    if (DUJztKNAwHQ != -574426.892758814) {
        for (int DdVcRJAXriE = 691922954; DdVcRJAXriE > 0; DdVcRJAXriE--) {
            NrKDYrgOLu -= dcFbdTliGgI;
        }
    }

    for (int vMJSWfX = 1905686349; vMJSWfX > 0; vMJSWfX--) {
        continue;
    }

    return vwnIbQYzC;
}

void bimFuDDrH::HuUoBIWoQoimmn(bool bKFYAqE, bool fyefXkXjvWKNHGK, bool YZdPbGVTfXdk, bool GdFmMMnv)
{
    bool smLCPGN = false;
    string jWEEZD = string("yqjwpsXqPVonFnWpHMmiHsxlQfWiSFmUtKztTxWyBKVJflTrkDhOKmMMNgVzFdGdyXKekIPzkEOnwwUyZLZAAsagamaJfQDRGAmpCOyWKavuyKNZtFSPXfVAjtyInnxFkwFzHimLdrLNpskDBZGBEQwbXcvNZZeVgbOOKCEEaKBfSUVHKNOxRkbusoHyUNLDIGmEakNyuBJceGNYgXpjHqhBhzOoHghbCFlReBcxS");
    double SGRdfMo = -1038833.0732666757;
}

int bimFuDDrH::mVuPFNozjnoNfcCV()
{
    string RYpNPzNuQMWnEh = string("IsugQIQBrOVSySiSAUfKnHVcSpjanPeHKtWKNkcroVaGJqD");
    string CpSFdatEI = string("pwfOrnQIskrgxhlsdlgPmbLhSTCYQGkEChGoUBOekuzGBLteEFFjCacNWDeGSgcoj");

    if (RYpNPzNuQMWnEh <= string("pwfOrnQIskrgxhlsdlgPmbLhSTCYQGkEChGoUBOekuzGBLteEFFjCacNWDeGSgcoj")) {
        for (int XFkDl = 497509353; XFkDl > 0; XFkDl--) {
            CpSFdatEI += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh += CpSFdatEI;
            CpSFdatEI = CpSFdatEI;
            CpSFdatEI += CpSFdatEI;
            CpSFdatEI = RYpNPzNuQMWnEh;
            CpSFdatEI = RYpNPzNuQMWnEh;
            CpSFdatEI = RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh = RYpNPzNuQMWnEh;
        }
    }

    if (CpSFdatEI >= string("pwfOrnQIskrgxhlsdlgPmbLhSTCYQGkEChGoUBOekuzGBLteEFFjCacNWDeGSgcoj")) {
        for (int hSUvEHJ = 1208456922; hSUvEHJ > 0; hSUvEHJ--) {
            RYpNPzNuQMWnEh += RYpNPzNuQMWnEh;
            CpSFdatEI = CpSFdatEI;
            RYpNPzNuQMWnEh = RYpNPzNuQMWnEh;
            CpSFdatEI += RYpNPzNuQMWnEh;
            CpSFdatEI = RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh += CpSFdatEI;
        }
    }

    if (CpSFdatEI < string("IsugQIQBrOVSySiSAUfKnHVcSpjanPeHKtWKNkcroVaGJqD")) {
        for (int uaVeY = 144736345; uaVeY > 0; uaVeY--) {
            RYpNPzNuQMWnEh += CpSFdatEI;
            CpSFdatEI += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh = CpSFdatEI;
            CpSFdatEI += CpSFdatEI;
            CpSFdatEI += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh += CpSFdatEI;
            RYpNPzNuQMWnEh = RYpNPzNuQMWnEh;
        }
    }

    if (CpSFdatEI != string("pwfOrnQIskrgxhlsdlgPmbLhSTCYQGkEChGoUBOekuzGBLteEFFjCacNWDeGSgcoj")) {
        for (int jYqJJCwnvybbtuHx = 123930258; jYqJJCwnvybbtuHx > 0; jYqJJCwnvybbtuHx--) {
            RYpNPzNuQMWnEh = CpSFdatEI;
            RYpNPzNuQMWnEh += CpSFdatEI;
            CpSFdatEI = CpSFdatEI;
            CpSFdatEI += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh += CpSFdatEI;
            CpSFdatEI += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh += CpSFdatEI;
            CpSFdatEI += CpSFdatEI;
        }
    }

    if (CpSFdatEI <= string("IsugQIQBrOVSySiSAUfKnHVcSpjanPeHKtWKNkcroVaGJqD")) {
        for (int WKsRwhkKlOkRtMe = 222139088; WKsRwhkKlOkRtMe > 0; WKsRwhkKlOkRtMe--) {
            CpSFdatEI += RYpNPzNuQMWnEh;
            CpSFdatEI = RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh = CpSFdatEI;
            RYpNPzNuQMWnEh += CpSFdatEI;
            CpSFdatEI = CpSFdatEI;
            RYpNPzNuQMWnEh = RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh = RYpNPzNuQMWnEh;
            CpSFdatEI += RYpNPzNuQMWnEh;
        }
    }

    if (CpSFdatEI <= string("IsugQIQBrOVSySiSAUfKnHVcSpjanPeHKtWKNkcroVaGJqD")) {
        for (int aZhYHAxfafIHbLQz = 973121300; aZhYHAxfafIHbLQz > 0; aZhYHAxfafIHbLQz--) {
            CpSFdatEI += RYpNPzNuQMWnEh;
            CpSFdatEI = RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh = CpSFdatEI;
            CpSFdatEI += RYpNPzNuQMWnEh;
            CpSFdatEI = CpSFdatEI;
            CpSFdatEI += RYpNPzNuQMWnEh;
            CpSFdatEI = CpSFdatEI;
            CpSFdatEI += RYpNPzNuQMWnEh;
            RYpNPzNuQMWnEh = RYpNPzNuQMWnEh;
        }
    }

    return 844462136;
}

bimFuDDrH::bimFuDDrH()
{
    this->XwYULGxP(938660768);
    this->zYVmhYiULgL(-1991689009, 771769.3407496671, 578893.0138619073, true);
    this->qcFXMtmJHiAT();
    this->BdDNSeDOggKcBjT(string("QqEXVTzwnPCYjG"), string("TuhTADvIfgxXJagwJtGWAjFOqLXcbHqFSYRCNOQTlBWvEAgWINVMOUXqIbzMcunjpyqmCyQwIotpSBoEqPiaRqxBxWoKVCzzIaLAZXyAfaDqtdYRLWwjPfzbzGVqcNzH"), false);
    this->quCEqr(411327.85906046623, 839950226, string("agxgCEYkrupuOYCYWtzdzDpGcfOBrhhUDiGyOukhukHQirVnfSYgLzr"));
    this->OfczfIQPt(786431.9319252644);
    this->FABAKmmcFjcVTI();
    this->kcEFDfC(false, -756503.1123730196, string("fgbDqoFcvoYkLalTDkPKqRqz"));
    this->uXzigQIhyey();
    this->ULYHG();
    this->GniwzHwnmiyQWI(710419524);
    this->TkxKIGFm(string("WUjGWWpbAWhdHbrwUurTZUmHMOeMsXqhZeEiRoNGLoNXFZsdomMQgsAJlVcPEIyLIZQtnUcSOPhmNGroGGEoKpSOUJEmXZWAZelXYbqxNBgCbJXTgTxqhINPFUwvONwSmbgenETNQDGtEqiOElUwDxQewOIVTPjsNRXmLWxNquPIHDdYEbrOfgjcbUrxODdZjHyunBPgBvxUzvfMrfUfkX"), true, false, true);
    this->TSCPCdZmyLmtJ(-20115.959387798768, true, 1569291758);
    this->uKiEFnR(297389.07458453253, 41680.04990389136, 1812131882);
    this->mDABRsFygV(true, -1813125051, false);
    this->vskYYdrsmta(438702.72952240746, -568918.3109798424);
    this->QIejK(string("leXjcsDAAMvQfdWxjznQEQnTpklQivsWJapUEoclcHbqIgpdBtJNqAhQwCdeVnWRUnVidXKkPPdFeiZEwXyFcARDpcXhNGdXgeqtxxkOqIvgOHkJNqoGmuQzvwvvwibICqbHOAZxDTWHBymRodwemoKNwOtK"));
    this->HuUoBIWoQoimmn(false, false, false, false);
    this->mVuPFNozjnoNfcCV();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class uSuKHNnYTkP
{
public:
    bool wrYcW;
    bool ImepZTgoidb;
    string ZazRBOaxMxAlVf;

    uSuKHNnYTkP();
    string BKaqiEo(double kxXVwrqAqLBjb, string TPGQEX, int WbxAHdqUIquqUV, bool NroahdluZmwY);
    double DWmwsYLCeZw(bool yrfTP, double ZJhcFEfFvenCMcfn, int mtGwsckhPdJTVUJY, double NdCmVHSIei);
    double gpYoiz();
    bool tbEgWPEYzfVWfdQ(string gBBMH, int zNaoTcdhjNUQad, bool kQYFDH, string VbzWKysXlEbCwl, bool GlwjUCnDdmHwEt);
    void AvWEKfoICPLnpy(double nvXpUzu);
protected:
    double mrZanywtpZyU;
    int qoHKLGhfMy;
    double XcgSfa;
    string ybkNuqcZbFNR;

    void ZVIKlDaJbng(bool kuBVSNkaWk, string fRJHgNivQpvSAdE, double eNTYx, string wlvpLbICluKeVYR, double FhhHNCt);
private:
    int qPArKMTXDAz;
    bool OkZrZkCCjRymsHT;
    bool GWGyTJpdMtQ;

    string xhqCRlEPnOBCc(double ExuxkZuGSs, double anKqcuWHMqndVnXs, double nyFvrfljWHmlBnzd, double PAhVoSpaswXzU);
    double vLvBMPbxXRsrRQ(double HBzagPmNdu, string OMEWqElO, int yzEWfGupMaYEwf, int oSuCpYn);
    double xulvBLoMKuAEBS(bool utzsq, double cpVAKjBF, double JPPloA);
    double OkPdWVhKHEVXKrZ(int XZcXZN, int UvHeDtzoYvESqI);
    double wsNVorScfIQGI(bool LMXIFuhRtWpIq, bool ZvXJuL, double nKnnVhZP);
};

string uSuKHNnYTkP::BKaqiEo(double kxXVwrqAqLBjb, string TPGQEX, int WbxAHdqUIquqUV, bool NroahdluZmwY)
{
    int BbEcGVY = -1118647135;

    for (int INZRhAvPPCSBEVlF = 1022011488; INZRhAvPPCSBEVlF > 0; INZRhAvPPCSBEVlF--) {
        continue;
    }

    return TPGQEX;
}

double uSuKHNnYTkP::DWmwsYLCeZw(bool yrfTP, double ZJhcFEfFvenCMcfn, int mtGwsckhPdJTVUJY, double NdCmVHSIei)
{
    int ypFVvwXgKqxnuHEB = 1775142765;
    double HIliQjtFpr = -79509.25373851835;
    double zuNzUvB = -299831.44760768354;
    int OKFMdwfCc = 1561366645;
    int Obwmcjt = 893008176;
    double ProvGTxT = -742304.7018576557;
    string yeSMWJdmBVlB = string("HSCnnpPzNiPMyExuFsXtMgLtSupixPTDuFYvPECwTgHDZoTXaXtiDqDxSQaTnhfInjOWBaSmBuPuXIMqPwvnOkqWQcTMCbZAMEMliDBUfKwuVlqBoZKCeJHydFHLbOoGYcYnRNVynyjHgPnaomambRtueEIpsdXvEHaHqtEmJhPhnwOCYxmGcypVKPqYewbVLfRvqvVuaIJfrgJcwIkdPLXilLgVrxSwtvFDC");
    double HjxBaJS = -126660.32518069066;
    string iEDkmtwkdErk = string("VmkvwbCpHYCRNoQALLXWiIlhLfxDwbIDiIKQjMJNFbGVfgxqmtcdKFBIVGNbQgzUCpoMhWGETBmffaQJFNRPJLoocJAFyAOtVgVkDBoerDZrarIHjongEeaLFAGMkNRpSZgkwuJqLaKmUdJdLwkSaksHKLdpKPiETzIKmmnoSSVNwbHeApkhHrSvERynkWDEIGMHUtVAPIVDBQ");

    for (int IJgqkccRlzZFT = 509579550; IJgqkccRlzZFT > 0; IJgqkccRlzZFT--) {
        ZJhcFEfFvenCMcfn /= NdCmVHSIei;
    }

    if (yrfTP == false) {
        for (int KiEtGKvRNCubLo = 1026389392; KiEtGKvRNCubLo > 0; KiEtGKvRNCubLo--) {
            zuNzUvB += HIliQjtFpr;
            HIliQjtFpr *= NdCmVHSIei;
        }
    }

    for (int LnWGec = 555389614; LnWGec > 0; LnWGec--) {
        continue;
    }

    if (HIliQjtFpr <= -126660.32518069066) {
        for (int XwrAhI = 32309512; XwrAhI > 0; XwrAhI--) {
            OKFMdwfCc *= ypFVvwXgKqxnuHEB;
            ProvGTxT -= HjxBaJS;
        }
    }

    for (int ctRLaK = 1914746870; ctRLaK > 0; ctRLaK--) {
        ypFVvwXgKqxnuHEB *= ypFVvwXgKqxnuHEB;
        ZJhcFEfFvenCMcfn -= NdCmVHSIei;
    }

    for (int dGIHXOSDoglA = 1683670817; dGIHXOSDoglA > 0; dGIHXOSDoglA--) {
        NdCmVHSIei -= HjxBaJS;
        ProvGTxT = NdCmVHSIei;
        Obwmcjt = Obwmcjt;
    }

    return HjxBaJS;
}

double uSuKHNnYTkP::gpYoiz()
{
    int gPnegkT = -948618835;
    int LyiGyAnbM = 798713318;
    int ezsTfGKGfNppVlxO = 546427904;
    int OZoBDfNesfZOXhQb = 1578937134;
    string krcrohhLplh = string("VhARqlwovmEwNpLmpviwzxPyAIKthLfVtfmuE");
    double cLaMnDOb = 234904.09360125734;
    string gjqVvYkZqgTWJ = string("vFAYJHHmUGMOwSVwjamgmOQTgkZmdTIvrAkGmWrmqChkqHzwQuXZmiIDOvUmFLxqfonNzZIBebrqbsBNpdBOWMuTewAKfbhqPkKCGWuoJLeqqhBSMmNEmWjsIlEjKiVViGEjQUKkgSZzlEaoBckMZaLedCfxNrCGxGgGSGLzceCfuGgyXSxHhPhrMLQlRMWvWRammWoyfLLvItGxCAdKEuwbjBDyxXMCTCtrzlpPyDkhE");
    int IoJaNQQVkdwB = 1429438170;

    for (int lSrQeqlDfRFnkCb = 213556935; lSrQeqlDfRFnkCb > 0; lSrQeqlDfRFnkCb--) {
        LyiGyAnbM *= OZoBDfNesfZOXhQb;
    }

    if (LyiGyAnbM != 1578937134) {
        for (int lTnnSOGNf = 2057202371; lTnnSOGNf > 0; lTnnSOGNf--) {
            gPnegkT /= ezsTfGKGfNppVlxO;
        }
    }

    if (OZoBDfNesfZOXhQb >= 798713318) {
        for (int KDFjWsvUzaHwzyu = 1022111375; KDFjWsvUzaHwzyu > 0; KDFjWsvUzaHwzyu--) {
            continue;
        }
    }

    return cLaMnDOb;
}

bool uSuKHNnYTkP::tbEgWPEYzfVWfdQ(string gBBMH, int zNaoTcdhjNUQad, bool kQYFDH, string VbzWKysXlEbCwl, bool GlwjUCnDdmHwEt)
{
    bool EizrwxN = false;
    bool LaaBeRC = true;
    int UzsIjqTmQlPZ = -1318636244;
    string HwThPAMIHqhXNe = string("MmRUCMtVSasJtdeFdWeGWnMxryMSToAMldbejhKFZtVRpkHVLCFORJmXWelpLdNGlTzynwrEEHTZOMCeysTggWgtVVtYxOOesWTJxHekzlOstgiXjvKBOvYIbKotOfCwKVQYJbAgKwXMrKJSZJOetEJVmOTGHoBUJTUjhMzKsLVHdcWDScBXNRwyEaCVOvGqesBbrbblGtzfSzSNoGmIlVzJsMTbLtPpKELSHHkpmYw");
    int GQZWnSqQvHWmMQQW = 751299286;
    bool LxHlIPqrNXNcV = false;
    int nbuvbDB = -668710861;

    if (EizrwxN != true) {
        for (int yLvbmyytgzUx = 69665080; yLvbmyytgzUx > 0; yLvbmyytgzUx--) {
            zNaoTcdhjNUQad -= GQZWnSqQvHWmMQQW;
            nbuvbDB = GQZWnSqQvHWmMQQW;
            GlwjUCnDdmHwEt = ! LaaBeRC;
            nbuvbDB -= GQZWnSqQvHWmMQQW;
            GQZWnSqQvHWmMQQW /= zNaoTcdhjNUQad;
        }
    }

    for (int YHKlZeEzUQrdcF = 211362087; YHKlZeEzUQrdcF > 0; YHKlZeEzUQrdcF--) {
        LxHlIPqrNXNcV = kQYFDH;
    }

    for (int vXMozWLVKaN = 435742752; vXMozWLVKaN > 0; vXMozWLVKaN--) {
        LxHlIPqrNXNcV = LaaBeRC;
    }

    for (int hPROHLE = 1911417634; hPROHLE > 0; hPROHLE--) {
        EizrwxN = ! kQYFDH;
        LaaBeRC = ! GlwjUCnDdmHwEt;
        HwThPAMIHqhXNe = gBBMH;
    }

    for (int LNoQvFyOyWLyng = 1151060595; LNoQvFyOyWLyng > 0; LNoQvFyOyWLyng--) {
        VbzWKysXlEbCwl += HwThPAMIHqhXNe;
        LxHlIPqrNXNcV = LaaBeRC;
        UzsIjqTmQlPZ += UzsIjqTmQlPZ;
        GlwjUCnDdmHwEt = ! GlwjUCnDdmHwEt;
        UzsIjqTmQlPZ -= nbuvbDB;
    }

    return LxHlIPqrNXNcV;
}

void uSuKHNnYTkP::AvWEKfoICPLnpy(double nvXpUzu)
{
    bool tKnkoIkmy = false;
    double KtACDnKBUIs = 560703.9251422423;
    bool IOpSTNwBoOGpq = true;
    bool oDtRTCgv = false;
    int bONucMbLj = -315362979;
    bool QFLhgZyuBRF = false;
    string cpRdavHIYUjZxLOi = string("IhfQNREQXWFFPnfuIDYqhFSbKqoKe");
    bool qsMSAbxLBRUq = true;

    for (int CEtZoCm = 1662898690; CEtZoCm > 0; CEtZoCm--) {
        tKnkoIkmy = ! oDtRTCgv;
    }

    if (tKnkoIkmy != false) {
        for (int VJUJZhIv = 1039060783; VJUJZhIv > 0; VJUJZhIv--) {
            KtACDnKBUIs *= nvXpUzu;
            QFLhgZyuBRF = qsMSAbxLBRUq;
        }
    }
}

void uSuKHNnYTkP::ZVIKlDaJbng(bool kuBVSNkaWk, string fRJHgNivQpvSAdE, double eNTYx, string wlvpLbICluKeVYR, double FhhHNCt)
{
    string IWnkGVM = string("uZHYSsDcyQhOOSJCeLegIyNhFkCIpzpQFFAyllUeCIthPaFWONUmSFwTElHYpEUqXKigbltriTIotyUfOLQqfrQBcvKIZMJvzWcYlQXUdtfGhblbQlWrwwBpDPquHPwjWbYyHGmRztRKGndhgfPquKrRRdlnUOvogvvYZlXvLyUbEg");
    bool DodMJI = false;
    bool RgkgXDUUDg = false;
    double bLZAIUXTsj = 254952.84928563316;
    double pstjnGsernsC = -776275.2224481171;
    bool NqDoVXwsr = false;
    string mSwitMODZZAw = string("ychaQwMeFIPyIfDW");
    bool wZLyfglhEmVlgZE = true;
    string fHjkJznro = string("EtiGnbBQewMfNZiznoMcyIhObarzmOcEbVWjWRyQeMmaERxwuElAnnWjhWAzeUvwcpiLshRYuCBHdkepSnBzormtISvgBppAjBqmdFkYLoDzKOgwMusUdiEtnibTuHzRNgKZQcnrTtAYfgjMDWbygLVGPcrOBKjvZAXTQehcxNmavwgmQZZWkPBHvNokKbTksikytpySsbOTDPyuzWNyFuNGxUhwYuInHjqaTcshiRmAiztcUzzgwqjR");
    double hKPPv = 1041056.1122200264;
}

string uSuKHNnYTkP::xhqCRlEPnOBCc(double ExuxkZuGSs, double anKqcuWHMqndVnXs, double nyFvrfljWHmlBnzd, double PAhVoSpaswXzU)
{
    string aIUtsjjliNQFVLR = string("CVKuCFEzDBKDThupUgAmKpjhgNOpzYDDdYCWkysUhJitFWMcZnwkPYtvjDLJHBcdrmywEHtbQqBsjoyEidFYvkbgrIdczhEno");
    double YMrJpFecLUwvk = -2921.1795453189407;
    int ZJnddb = -1202460435;
    int KRoVyFoTXIn = -962284767;

    for (int dPRYJQxHccDxmpD = 126297114; dPRYJQxHccDxmpD > 0; dPRYJQxHccDxmpD--) {
        KRoVyFoTXIn -= ZJnddb;
    }

    for (int NUWvdB = 796539596; NUWvdB > 0; NUWvdB--) {
        nyFvrfljWHmlBnzd += PAhVoSpaswXzU;
        ExuxkZuGSs /= nyFvrfljWHmlBnzd;
        nyFvrfljWHmlBnzd -= anKqcuWHMqndVnXs;
        PAhVoSpaswXzU -= PAhVoSpaswXzU;
        PAhVoSpaswXzU /= nyFvrfljWHmlBnzd;
    }

    return aIUtsjjliNQFVLR;
}

double uSuKHNnYTkP::vLvBMPbxXRsrRQ(double HBzagPmNdu, string OMEWqElO, int yzEWfGupMaYEwf, int oSuCpYn)
{
    string cCeNkq = string("NUmcmDJulkckxoKLIuhdAySNpZaDYbDfaqIlxEcpyBxQNAqztHIQpkWiHxsnaqvSsQxRexgcXqleMUoQVWFuTHwcRNWAnxrV");
    string NmDsefJgvCcsl = string("EojdNLhCoNyZowHJPFpSrslYDDvvyZNrSOtjLEExgxhnkFMjwWXsV");
    bool NXnpec = false;
    int WfZcbDTQJiR = 2070055351;
    double pYhzAGfONywOep = -693482.3416149915;
    bool xSyOthgkw = true;
    double MripbAuSinnGOkJ = -225001.34243503094;

    for (int uFXQEuEpeOA = 201000369; uFXQEuEpeOA > 0; uFXQEuEpeOA--) {
        MripbAuSinnGOkJ /= MripbAuSinnGOkJ;
        WfZcbDTQJiR -= WfZcbDTQJiR;
    }

    return MripbAuSinnGOkJ;
}

double uSuKHNnYTkP::xulvBLoMKuAEBS(bool utzsq, double cpVAKjBF, double JPPloA)
{
    bool rZSNeKQnM = true;
    bool ltCCPKgHSR = true;

    for (int nTept = 937847396; nTept > 0; nTept--) {
        utzsq = ltCCPKgHSR;
        rZSNeKQnM = ! rZSNeKQnM;
        utzsq = ! rZSNeKQnM;
        JPPloA *= JPPloA;
        JPPloA /= JPPloA;
        ltCCPKgHSR = rZSNeKQnM;
    }

    for (int epKZrwpXNHhzRtiX = 503434653; epKZrwpXNHhzRtiX > 0; epKZrwpXNHhzRtiX--) {
        utzsq = rZSNeKQnM;
    }

    if (ltCCPKgHSR != true) {
        for (int sbhvYmQhEAERr = 906467597; sbhvYmQhEAERr > 0; sbhvYmQhEAERr--) {
            JPPloA /= JPPloA;
            utzsq = ! rZSNeKQnM;
        }
    }

    if (utzsq == true) {
        for (int NCXcoStKXfe = 745200162; NCXcoStKXfe > 0; NCXcoStKXfe--) {
            continue;
        }
    }

    if (cpVAKjBF != 883512.7195923934) {
        for (int AjiMuBOkHhyKbXI = 224782189; AjiMuBOkHhyKbXI > 0; AjiMuBOkHhyKbXI--) {
            JPPloA *= cpVAKjBF;
            cpVAKjBF /= cpVAKjBF;
            ltCCPKgHSR = ! ltCCPKgHSR;
            ltCCPKgHSR = rZSNeKQnM;
            utzsq = utzsq;
            rZSNeKQnM = ! utzsq;
        }
    }

    for (int fvEHLSa = 143619388; fvEHLSa > 0; fvEHLSa--) {
        rZSNeKQnM = ! rZSNeKQnM;
    }

    for (int VZfdiIBZBV = 1825262073; VZfdiIBZBV > 0; VZfdiIBZBV--) {
        continue;
    }

    if (utzsq == true) {
        for (int bqxgYAAdkFbEDLCz = 1649045867; bqxgYAAdkFbEDLCz > 0; bqxgYAAdkFbEDLCz--) {
            cpVAKjBF = JPPloA;
            JPPloA -= cpVAKjBF;
            ltCCPKgHSR = ! utzsq;
        }
    }

    return JPPloA;
}

double uSuKHNnYTkP::OkPdWVhKHEVXKrZ(int XZcXZN, int UvHeDtzoYvESqI)
{
    int YRONvFYvCUwS = 1089475372;

    if (XZcXZN != 1089475372) {
        for (int rDIkh = 1222889984; rDIkh > 0; rDIkh--) {
            XZcXZN -= UvHeDtzoYvESqI;
            YRONvFYvCUwS = XZcXZN;
            UvHeDtzoYvESqI -= YRONvFYvCUwS;
            XZcXZN += XZcXZN;
            XZcXZN /= XZcXZN;
            XZcXZN /= UvHeDtzoYvESqI;
            UvHeDtzoYvESqI -= YRONvFYvCUwS;
        }
    }

    if (YRONvFYvCUwS < 1089475372) {
        for (int HmWWQZ = 1888388484; HmWWQZ > 0; HmWWQZ--) {
            UvHeDtzoYvESqI += XZcXZN;
            YRONvFYvCUwS -= YRONvFYvCUwS;
            YRONvFYvCUwS *= XZcXZN;
            UvHeDtzoYvESqI += UvHeDtzoYvESqI;
        }
    }

    if (XZcXZN != -2081373979) {
        for (int ilPTLVDy = 577782489; ilPTLVDy > 0; ilPTLVDy--) {
            UvHeDtzoYvESqI *= XZcXZN;
            UvHeDtzoYvESqI = XZcXZN;
        }
    }

    if (XZcXZN >= 88075895) {
        for (int TFNLO = 1782746945; TFNLO > 0; TFNLO--) {
            UvHeDtzoYvESqI += YRONvFYvCUwS;
            UvHeDtzoYvESqI = XZcXZN;
            YRONvFYvCUwS -= UvHeDtzoYvESqI;
            YRONvFYvCUwS *= XZcXZN;
            UvHeDtzoYvESqI *= UvHeDtzoYvESqI;
            XZcXZN *= XZcXZN;
        }
    }

    return 851890.3187793222;
}

double uSuKHNnYTkP::wsNVorScfIQGI(bool LMXIFuhRtWpIq, bool ZvXJuL, double nKnnVhZP)
{
    bool ZNPDP = false;
    string keorPZpgetSr = string("tvBlGdHguHNheMFnytRKnWIfAKAMTuXJchbSqIVAcClRsMTXAAnsjjCcyUWsiflGtMBMNLfMRahthQkIcortNkaPfSbTQOwyylrQgOzduZqlfcQsVrdlDlRXEgSWlioMOkjqqnMzavkKVvMtOsw");
    bool SAsxVROWFnxz = true;

    for (int rXvAUxW = 1759688880; rXvAUxW > 0; rXvAUxW--) {
        ZNPDP = ! LMXIFuhRtWpIq;
        nKnnVhZP += nKnnVhZP;
    }

    if (LMXIFuhRtWpIq != false) {
        for (int gTWycl = 336036801; gTWycl > 0; gTWycl--) {
            keorPZpgetSr += keorPZpgetSr;
            ZNPDP = ! ZvXJuL;
            SAsxVROWFnxz = SAsxVROWFnxz;
        }
    }

    if (ZNPDP == true) {
        for (int MbmJxenQ = 655504537; MbmJxenQ > 0; MbmJxenQ--) {
            SAsxVROWFnxz = ZvXJuL;
            ZNPDP = SAsxVROWFnxz;
            keorPZpgetSr = keorPZpgetSr;
            ZvXJuL = ! LMXIFuhRtWpIq;
        }
    }

    return nKnnVhZP;
}

uSuKHNnYTkP::uSuKHNnYTkP()
{
    this->BKaqiEo(486534.19861001254, string("NLrGVmSLJzaEPGmVkmxbiBSpRSnsNSroXVsHnrhtAmoGJzVDiemPmV"), -1950105904, false);
    this->DWmwsYLCeZw(false, -967617.6269812678, 471980393, 813690.1835293629);
    this->gpYoiz();
    this->tbEgWPEYzfVWfdQ(string("pxlQneMUnfWZLfaQlyWTDmzXDubumYIlapCHuHrsbmlaZasoORYBQKTWftcrhoGUhJpwTCkBHGODZNWoCktkGtdrEZybBEHgzUomZpsAUWvomRjtiFqJdIlTsbmDOiDGmZYkTvNUjYWGWLiZEyHXBWJQmSspjUSCoTzqTt"), 707071692, true, string("EvfdoTatVykvRlLKxwZfIhNVMljSIWkRzebjFAGcouLcojisvqXeceh"), true);
    this->AvWEKfoICPLnpy(871189.9463033086);
    this->ZVIKlDaJbng(false, string("TZlOeBdFxfNprZqCLqCuXiWroMqguzuvwGhfCiQhFiaUrZIjZfAiRnjdnHajUJtIepWDfZMzvOkbaHPHIvlvSKtMebRTabsmwBYpbwjWVCstmCcsMWYVhcsdOqicUNPxjMskXylsWOsohKyQVvPJOYgRGTciSljelEanULZMVLMGfoiUvGgetpBfzIiQCWzKgyEvJ"), -114797.98206459824, string("uNYUcmsKGGMEwUUyXkNKReaWcdMrufIGEDZsgmosRDCUqpceKCrrNsYQqhmKMZXVHCTDIklDIAhlvxRhysqIzSFQkXAlhYbHfxvMqlZvLYENFUItErJZHSpYPHwRHbqIcaSHPsxXvlsApqitKRbiEqaUYrMZVzwvPDjqldVKfZgdzhiNeAGREDaBfMcfhJPhiNHZRHusvrkjNnrQpzQgEyQdQrmXNuvQamMQjjGOUENZ"), 151643.4927685104);
    this->xhqCRlEPnOBCc(819687.8034792001, -511318.29813531955, 466125.8934270385, 294648.0361913577);
    this->vLvBMPbxXRsrRQ(-778599.880951087, string("SQuJILBayAUmdebBHAZrjlvtxYpRGbuMPoXjccqweWWCTvIHMgOrHXGqtAPVsJlnudjJfejqLsRINEzOqoQ"), -504542731, 1060711608);
    this->xulvBLoMKuAEBS(true, 1009615.0841923358, 883512.7195923934);
    this->OkPdWVhKHEVXKrZ(-2081373979, 88075895);
    this->wsNVorScfIQGI(true, false, 30573.361605182414);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lsCvLmIoFsq
{
public:
    string cwcUZBwcYRlMYj;

    lsCvLmIoFsq();
    void yeJlvKuFLt();
    void PmowhSnUaAX(int TxuxtFNWe, string vbQkHdTtG, double bRmfGy, bool QrsJSVlrYddMqD);
    int FEzeLFF(string UpppBfRMDZfybSfR, int NeVMlfHGzNmQBSD, int RFgfnJILVnjlWQYs, double wuOJXURjCZUP, double JnunnSLfbrgd);
    int pAOKASjWyXqpU(string EWrXBFAGXyUhKXAS, int ApZmZKzkeCWbFOgK);
    bool TMpIDvuQhejvBGg(int SYCWYhcjqb, bool hqVZhQfmUhCe, double fMcgiRZROdE, bool yIhmtuIXe);
protected:
    double NTGLohxUeRrR;
    string XCPfdHBP;
    bool UZIJgfKFmKNmKLE;

    string FGxDsZTEVjn(string WHeuQb);
private:
    string DBcvvdH;
    int YJXngXSEJMvyZ;

    string OhpckKHNzBdLwJ(string FDwpEvtyfp, double mwnUsd, double mmVDfIc, string llwjOQQQssPwJ);
    bool fpUFFalGpvbrU(bool bkbIpRTy);
    int SspnEZfnP(bool WtwVPXMkMJGvSC);
};

void lsCvLmIoFsq::yeJlvKuFLt()
{
    int lbwxLWDHagWoL = -1336946483;
    double qIBHFBzOpOasE = 586576.0728606558;
    string tQjWsQ = string("HfOvhWwFFoJ");

    for (int ydnJOmWIagShyLXr = 385397764; ydnJOmWIagShyLXr > 0; ydnJOmWIagShyLXr--) {
        qIBHFBzOpOasE += qIBHFBzOpOasE;
        tQjWsQ += tQjWsQ;
        tQjWsQ += tQjWsQ;
    }

    for (int YwHaGaRnRRHvQ = 393458390; YwHaGaRnRRHvQ > 0; YwHaGaRnRRHvQ--) {
        continue;
    }
}

void lsCvLmIoFsq::PmowhSnUaAX(int TxuxtFNWe, string vbQkHdTtG, double bRmfGy, bool QrsJSVlrYddMqD)
{
    bool ZvCqmxrMtQeM = true;
    double iCeqTMWPTyhe = -627461.1307525466;
    int DJsmFJSZL = 126175463;
    bool mGRVIMKuDH = false;
    bool YLFQfTuoNgb = false;

    for (int QjIWuSNRtyEURdC = 1910714026; QjIWuSNRtyEURdC > 0; QjIWuSNRtyEURdC--) {
        continue;
    }
}

int lsCvLmIoFsq::FEzeLFF(string UpppBfRMDZfybSfR, int NeVMlfHGzNmQBSD, int RFgfnJILVnjlWQYs, double wuOJXURjCZUP, double JnunnSLfbrgd)
{
    string SIugVsJXrMZ = string("yCsJuWoryvukVwWXxyzmNkNotoVlvezmmUUPAnfKZgZlDpVTHvPKyAQkhgZMJALqtRDCKsLcVRDtVNcaLuAlwiqyilAJLlkAmWdCkfaAOTyJcatzvoELkOyBxXzlbemmgpQAzNfHcFWPJSWSxpipPsXEjmlToPBWiKuXzPQMirwjrxTNMYyZrngUZKJCHhh");

    if (NeVMlfHGzNmQBSD >= 833779508) {
        for (int oDYXB = 1109331980; oDYXB > 0; oDYXB--) {
            wuOJXURjCZUP = wuOJXURjCZUP;
            JnunnSLfbrgd -= wuOJXURjCZUP;
        }
    }

    if (SIugVsJXrMZ != string("qxNGUQKJpYViUbbFBCUbjydCKuwCdvJguBUyvTtxcIkmaScjjlKeNKlJglEALZfQgsQNRLzTTOBNRXNUIugWfLPEHFWgmAaJXmAlijaModPbOIWTRZQvRZLnRcGVmtylSdjAlXdbZPVv")) {
        for (int pkWyMmFqPWCLqMYu = 178109090; pkWyMmFqPWCLqMYu > 0; pkWyMmFqPWCLqMYu--) {
            NeVMlfHGzNmQBSD -= NeVMlfHGzNmQBSD;
            JnunnSLfbrgd = JnunnSLfbrgd;
        }
    }

    return RFgfnJILVnjlWQYs;
}

int lsCvLmIoFsq::pAOKASjWyXqpU(string EWrXBFAGXyUhKXAS, int ApZmZKzkeCWbFOgK)
{
    string AQalseeFOt = string("NTnJMktIHKBtAyoZnvRuXkiyNqvtfKdkblLfhGKJkjqbXJdhFPTHPUmgdXBiMzFSQwgMIOxYYQQJDAuCexjzMjXTfINNVyL");

    if (EWrXBFAGXyUhKXAS < string("NTnJMktIHKBtAyoZnvRuXkiyNqvtfKdkblLfhGKJkjqbXJdhFPTHPUmgdXBiMzFSQwgMIOxYYQQJDAuCexjzMjXTfINNVyL")) {
        for (int SfXZdMaTPWPX = 2095475664; SfXZdMaTPWPX > 0; SfXZdMaTPWPX--) {
            AQalseeFOt = AQalseeFOt;
            EWrXBFAGXyUhKXAS += AQalseeFOt;
        }
    }

    if (EWrXBFAGXyUhKXAS >= string("NTnJMktIHKBtAyoZnvRuXkiyNqvtfKdkblLfhGKJkjqbXJdhFPTHPUmgdXBiMzFSQwgMIOxYYQQJDAuCexjzMjXTfINNVyL")) {
        for (int UFpiFa = 1078265535; UFpiFa > 0; UFpiFa--) {
            EWrXBFAGXyUhKXAS = EWrXBFAGXyUhKXAS;
            AQalseeFOt = AQalseeFOt;
        }
    }

    if (EWrXBFAGXyUhKXAS <= string("PmqKHhgDBcYvRizXmzqbXPqUgmYkroDsVWkCgHdHxNPwySCZjBGlVshShYEvuMbovDBBIGPEDfrzcZhellDzJevDboRwnqyZmjwuGXtKgCThuIHWZJOcJzVvaZDEjCyqYsVD")) {
        for (int TzCStnhQBJLckbaE = 391663512; TzCStnhQBJLckbaE > 0; TzCStnhQBJLckbaE--) {
            EWrXBFAGXyUhKXAS += AQalseeFOt;
            AQalseeFOt = AQalseeFOt;
            EWrXBFAGXyUhKXAS = EWrXBFAGXyUhKXAS;
            EWrXBFAGXyUhKXAS = AQalseeFOt;
        }
    }

    return ApZmZKzkeCWbFOgK;
}

bool lsCvLmIoFsq::TMpIDvuQhejvBGg(int SYCWYhcjqb, bool hqVZhQfmUhCe, double fMcgiRZROdE, bool yIhmtuIXe)
{
    int xLhfKgXeV = 402111280;
    string AOJbCGtmLIj = string("dCxyNqHBEYqvSLDiwEIoJQkhBXaTSZBLyVUjIioEDphsKjRbeSOPOGifJTKBcyghMndKUKdmRxNgbkAFddwRmQEievnFQHpShJWaKnIRQWjXjdEmDGYbTHGulZDjUoXtyRtTbxjvdzyGuDzBmisdXDTEYOzLtNoRubwwMLphlareMCltTpXQzDzkJmgNUXkFNXPrtrzILtAHfdKgqgjESJpKwMFcJxHhtCWjDZVptqoCQswQIXMlTEBrsfwzxO");

    for (int ScMMStIikRqGdLL = 1190453716; ScMMStIikRqGdLL > 0; ScMMStIikRqGdLL--) {
        continue;
    }

    for (int VnMJRAwfpVjZ = 1608359196; VnMJRAwfpVjZ > 0; VnMJRAwfpVjZ--) {
        SYCWYhcjqb += SYCWYhcjqb;
        hqVZhQfmUhCe = ! yIhmtuIXe;
    }

    for (int rwSVga = 1308277143; rwSVga > 0; rwSVga--) {
        continue;
    }

    return yIhmtuIXe;
}

string lsCvLmIoFsq::FGxDsZTEVjn(string WHeuQb)
{
    bool ybldSYplxgXCn = false;

    if (ybldSYplxgXCn == false) {
        for (int fheblRUxVxPWjG = 1172939435; fheblRUxVxPWjG > 0; fheblRUxVxPWjG--) {
            WHeuQb = WHeuQb;
        }
    }

    for (int sQlXhGJVxYE = 1780316163; sQlXhGJVxYE > 0; sQlXhGJVxYE--) {
        WHeuQb = WHeuQb;
        ybldSYplxgXCn = ybldSYplxgXCn;
    }

    if (ybldSYplxgXCn != false) {
        for (int DuVmPhHKvqjoAj = 1409144834; DuVmPhHKvqjoAj > 0; DuVmPhHKvqjoAj--) {
            ybldSYplxgXCn = ybldSYplxgXCn;
            ybldSYplxgXCn = ! ybldSYplxgXCn;
            ybldSYplxgXCn = ! ybldSYplxgXCn;
        }
    }

    return WHeuQb;
}

string lsCvLmIoFsq::OhpckKHNzBdLwJ(string FDwpEvtyfp, double mwnUsd, double mmVDfIc, string llwjOQQQssPwJ)
{
    int NzsxJy = 1162706430;
    bool CTQcBieSScSg = false;
    double UjGPABBfLImpjkw = -1007174.0437071181;

    for (int qNwDsBimj = 1444746305; qNwDsBimj > 0; qNwDsBimj--) {
        mmVDfIc -= mmVDfIc;
        mmVDfIc = UjGPABBfLImpjkw;
    }

    for (int nztjBtkXDFMR = 348949436; nztjBtkXDFMR > 0; nztjBtkXDFMR--) {
        mmVDfIc -= UjGPABBfLImpjkw;
        UjGPABBfLImpjkw /= mmVDfIc;
        mwnUsd /= mwnUsd;
    }

    for (int JZoDKvXe = 1922282301; JZoDKvXe > 0; JZoDKvXe--) {
        llwjOQQQssPwJ += FDwpEvtyfp;
        mmVDfIc *= mwnUsd;
    }

    for (int iTPLdB = 1481189163; iTPLdB > 0; iTPLdB--) {
        mmVDfIc /= mwnUsd;
        llwjOQQQssPwJ += llwjOQQQssPwJ;
        FDwpEvtyfp = FDwpEvtyfp;
        llwjOQQQssPwJ = FDwpEvtyfp;
    }

    for (int fqITYzZmQdfpdMHL = 1021043808; fqITYzZmQdfpdMHL > 0; fqITYzZmQdfpdMHL--) {
        llwjOQQQssPwJ += FDwpEvtyfp;
    }

    if (mmVDfIc >= -1007174.0437071181) {
        for (int xUQkGFsugHQtTQyK = 58208957; xUQkGFsugHQtTQyK > 0; xUQkGFsugHQtTQyK--) {
            mwnUsd = mmVDfIc;
            llwjOQQQssPwJ = FDwpEvtyfp;
            mwnUsd -= mwnUsd;
        }
    }

    return llwjOQQQssPwJ;
}

bool lsCvLmIoFsq::fpUFFalGpvbrU(bool bkbIpRTy)
{
    string eUROrvBm = string("PULaHUWbRYUOhFNXnDJAKIxZOfnFZPMojRsThpIcKmBsSQGNejgeYyinvEUwxwFAaoTPGMdGZXgfiCgIrlTvJCoxGmLpyvtcDwoBfQOVTLFXvSLNFvpgr");

    for (int sErwpePFPjv = 541810993; sErwpePFPjv > 0; sErwpePFPjv--) {
        continue;
    }

    if (eUROrvBm < string("PULaHUWbRYUOhFNXnDJAKIxZOfnFZPMojRsThpIcKmBsSQGNejgeYyinvEUwxwFAaoTPGMdGZXgfiCgIrlTvJCoxGmLpyvtcDwoBfQOVTLFXvSLNFvpgr")) {
        for (int wcXzCNDPtvug = 410536090; wcXzCNDPtvug > 0; wcXzCNDPtvug--) {
            eUROrvBm += eUROrvBm;
            eUROrvBm = eUROrvBm;
            bkbIpRTy = bkbIpRTy;
            bkbIpRTy = bkbIpRTy;
            bkbIpRTy = ! bkbIpRTy;
        }
    }

    return bkbIpRTy;
}

int lsCvLmIoFsq::SspnEZfnP(bool WtwVPXMkMJGvSC)
{
    string YvFmudrNS = string("KpxPFEphuMmDNvrmElRJeLNJQnQHfCLdbMJmgQcLHGqTwNDaNiLkrnYKojMMigaVzdIbnNAmxVEKnxaAkZwvksNygzFbuBqwsWyrZemZcZRnOJloHYqOnDk");
    double KwIDMKiKAlnvq = -668442.3520057036;
    int cdFLc = -500467219;
    bool AzueHs = false;
    bool EfcaZbqohuG = true;
    bool VCyqv = true;
    bool RxIQCl = true;
    bool ISAIG = false;
    bool IpCLs = true;
    bool vkTZOHk = true;

    for (int SCRIHSXgJksHG = 821367619; SCRIHSXgJksHG > 0; SCRIHSXgJksHG--) {
        RxIQCl = EfcaZbqohuG;
        AzueHs = AzueHs;
        VCyqv = vkTZOHk;
        RxIQCl = RxIQCl;
        ISAIG = ! ISAIG;
    }

    if (vkTZOHk == false) {
        for (int IbxPVUSmLfRAKgWZ = 814681590; IbxPVUSmLfRAKgWZ > 0; IbxPVUSmLfRAKgWZ--) {
            ISAIG = ! vkTZOHk;
        }
    }

    for (int CKvHrLl = 976059120; CKvHrLl > 0; CKvHrLl--) {
        ISAIG = ! EfcaZbqohuG;
        IpCLs = ! RxIQCl;
        AzueHs = ! WtwVPXMkMJGvSC;
        ISAIG = WtwVPXMkMJGvSC;
    }

    return cdFLc;
}

lsCvLmIoFsq::lsCvLmIoFsq()
{
    this->yeJlvKuFLt();
    this->PmowhSnUaAX(2122477651, string("pfJTySiugzsafDdKLxYXUDWhJVaQsnAbgrOjIztgbkZmgIyQJbQbkkJKtDDzdBvdAvgrjHNUsWZcckUoAveqIfKDWXXAJoOVTWzTMFVqPukIofRHwKugJfowpOAFIWjbMPrWdRKmduaoxpRlkafAmoxgAquzFQ"), -499008.70351880434, false);
    this->FEzeLFF(string("qxNGUQKJpYViUbbFBCUbjydCKuwCdvJguBUyvTtxcIkmaScjjlKeNKlJglEALZfQgsQNRLzTTOBNRXNUIugWfLPEHFWgmAaJXmAlijaModPbOIWTRZQvRZLnRcGVmtylSdjAlXdbZPVv"), -903998679, 833779508, 59786.217527005036, 330093.05214727594);
    this->pAOKASjWyXqpU(string("PmqKHhgDBcYvRizXmzqbXPqUgmYkroDsVWkCgHdHxNPwySCZjBGlVshShYEvuMbovDBBIGPEDfrzcZhellDzJevDboRwnqyZmjwuGXtKgCThuIHWZJOcJzVvaZDEjCyqYsVD"), 724894362);
    this->TMpIDvuQhejvBGg(898822676, false, -356151.1541224435, true);
    this->FGxDsZTEVjn(string("EGimmWNgUdnPPfEGwwIDikyNZwBTVskAEvGJTYrCXcVXAyZimdrCSUZATGuKfgaOaDFnKldhNCrEJcQeitJSjiWPNiAAviPzyNlWFVOufqCVJQOwgmLqyyFVODsfSSFYUdmpBPkBDDJjKPDcePDDbOvgpLMlErwbE"));
    this->OhpckKHNzBdLwJ(string("WmBivcWwktYgUuAUQIoHRPqkiHQTizArdBfMKstAxebVyufAlvMKcojfLoMvSIlqulzxFwZgiplhXQqnmmvGDXoxBjDHkthFZCPYXYPshLuaGdDZWHeEwrtKSyPRFeqvkquMNqpBovsjCZqreFJtkotWNVXeyTEBtVSprGNKECJXMfqwYlkudHvVzucXuFlMAQfMpNrvqJesTtEtEplxsoaCBsCgX"), 823221.7675230925, -936623.3318582176, string("AxWfnaYEZajDWxMpnGwdXReQmDCzXGKarlhJuQQZlUxxmkovESAmcIyeYojPzRNxmqBBgPQnxmbclIHqHthsDisiXIqfinxiuhtWAqGpgHFLCTmgvvekTjifTuggmTLCSzCBcUPvYanlioEqteBAeUGDpMGQmqYJbgjGAiYnjyVLDeEhaoXEatRQMfvRCNWsVGwrGCJqNjTriCfNdLgIEOnbsLXfjAePDGyqlhvapWJUlFwabOCtfRsN"));
    this->fpUFFalGpvbrU(false);
    this->SspnEZfnP(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gKgOBaW
{
public:
    int ZNKxWYVETTtruuA;
    string eAjWPGgdh;
    string fhXKzwDGDIgQdQ;
    double yEabPd;

    gKgOBaW();
    double NUFIsB(int bqddXpkiuXdCov, int ulRQUOkcX);
    int ojXlnWDR(double afUQry, double oQSNPwnwBRpTtMC);
    bool cTfcSgnQPmQC(string UyAqLf, int bxKKcjRqLhNV, string OhgEsLerwLSByz, string MXaUXpZrXad);
    bool rlGpHPT();
protected:
    bool owwxyPoqge;

    void mdVjzsMqDN(string fHzTRpxiuE, double gEpEUpexqgvf, int qSJlnltOX, bool OCABhwkUpbop);
    double hFclFXuzQSLJmAV(int jindrUo, int MHLnLsfnB, int WfEMXhRGmIshr, int XVrPvjAMyT, int dxvIgPcbEI);
    bool REIgpsnIOi();
    string xgPgKXQwW(double pwpBF, double CMDIN, int IUNqprVykZP, int AKLvHaZnsoL, string JfGfIxlQkibmZ);
private:
    int XoAtkfMaxHtIhU;
    double jCKNJk;
    int gulWeVaYP;
    string XSion;

    string wIVntwLKtnpMX(int OfDNxhmLAiHxZ, double KSACx);
    double FDhqLigFm(bool DIfcu, int zSwKTuoQtNWr, string KfXQaKreizAfpM);
    string YLbAqR(string aBBYM);
    void YYTBXu(string ZlAsFb, bool HqhYwSqwPl);
    void eSFwNMjdMMqXW(int okLdczfStUf, string DNjDCtLcfyoj);
    bool SzfaA(bool rEmgiCc, string bYyDGyyc, int ILRxXHwcjbDHMt, bool jboQF, double RKnWamoZdVLmvic);
    string KJacOEW(double SGxAJCmUNGvv, int MsFknyKRI, bool BEPlZOQ, double uFvlVxKHoLjrngtG, int iJWwM);
};

double gKgOBaW::NUFIsB(int bqddXpkiuXdCov, int ulRQUOkcX)
{
    double TMIhyeLYDONxr = 689508.5549286291;
    string qyWMsxINljBnRJp = string("FNRtvvWBdbgzcFhtkYhXiHonBXIhPohRwDtbQiUaIUnpkTJhfykTOtdLrJZxSxhISrhiTCpyHUqNfoeXEoruaThDVfigxNoYMduTRNAYrIhNFBbTKnFwWFDDcMGzIFPsHQssWUwzIMguEsQqdmJxGEAJHRTBysiUypUMUHFgaCKicaZvZSVJIYtbINXkzvrUxckbKRJRDQBqfSzSvOWPPxVHmNWHoQsRFfyiuJeSXjAtLNljObQSVsOIsPwE");
    string nGKEPZ = string("GJLLlsJTyULFWnDfJvjuJkNmlAxVLIvGxmRHViIczjDfopFTFWpERWqVQyUeydHyQQzFUTxpCThTErMxmSRkJfRIMYGZpBxKYosVkVpuYgimjfRaKiKUsODaSUxocVBxKtrbSfkNCqt");
    int FwizDp = -1493100859;
    bool AVjOCq = true;
    string ssTmLgwotc = string("iqIavwXANigAvAGzsQsWXvdDfapSoHMaCUpZyxJGxCNOlXFWc");
    double knWuJmd = -855068.3987246121;

    for (int jTNrzeCn = 1420808207; jTNrzeCn > 0; jTNrzeCn--) {
        ssTmLgwotc += nGKEPZ;
        ulRQUOkcX = FwizDp;
    }

    return knWuJmd;
}

int gKgOBaW::ojXlnWDR(double afUQry, double oQSNPwnwBRpTtMC)
{
    string nepqwgdRf = string("jzOnTbIkiTnsGNNJbiTYgrmOUiBgyiUXirUmpEFBgLHETkzzoUpTLrHaSNfuuINuryU");
    string UEteAWIrJMrA = string("DxCKobPLfsDhRwVkexZSukUFRaxjeQulCrFavZjUUJZwzsitUdkpjIcetaPXdEOSxVofsKPdzkDhYYvWgJuPChYwDgyLKtxgYEBFihnXRpgiQozUjJoxhdygDFiLqYSXuluzDYecJVidJcqbVqAoawPE");
    int jWFJYrcx = 928639707;
    int CIKFvraj = -128684479;
    double mknPYEXrbZGdcpN = -395027.70162670204;
    int NYkJyOKxjnNfuF = 1350865190;
    int tzPLDpiZUL = 1307822261;

    if (oQSNPwnwBRpTtMC >= -653485.3966678802) {
        for (int XFdhKPVZHzpJLk = 1688504498; XFdhKPVZHzpJLk > 0; XFdhKPVZHzpJLk--) {
            oQSNPwnwBRpTtMC += oQSNPwnwBRpTtMC;
            UEteAWIrJMrA = nepqwgdRf;
        }
    }

    if (tzPLDpiZUL <= -128684479) {
        for (int FaHxWpTZ = 1786761155; FaHxWpTZ > 0; FaHxWpTZ--) {
            tzPLDpiZUL *= NYkJyOKxjnNfuF;
        }
    }

    return tzPLDpiZUL;
}

bool gKgOBaW::cTfcSgnQPmQC(string UyAqLf, int bxKKcjRqLhNV, string OhgEsLerwLSByz, string MXaUXpZrXad)
{
    double LghIzfFamcvQ = 270369.6327974534;
    bool NJiBlVPKXNNSDn = true;
    string rjJlZKiQfaQ = string("tuDnoqrMFWySUpMfZBMfVSJkolKSXysGqctIdFwGJXYHtPoyYBlGphisTOpIRsNzCrdDmFrCLHDREmyekRiZgFzQpGNVvCJGieVTpbLRvjfXXxZjqKusiCFyHGXaqCqEkAmEZhcNIxtTKlrQsyBQqsLACxVsSxBuAxvGXirBbCUcmlQKnQBwMqJcNOfvCcBpWD");
    bool YTcHFCeny = false;
    string LXzAhpgFtTTyjph = string("OiCHjUETaXrY");
    string NKJCtypKEWAHQhn = string("eQxesPdNgErrMWPYGQvMaEbUgaEcWhYDkaIVSFeuWRsvelGPmxtqyUcdnToTAGygbaLmbUCzylpdeukauYPmrskpTeHCNlAoetYNEpBFQSCZdBSFvCGVXdJtoXEDTtsqGrSutnjVmVkGJNEXjeyciKLaDiwbdBqWmguHutPorRAhbSehGmJXhbxHohdeSsMJcwtzIONIFpCjnOqYOfkaXFEfrrZWfhULUBpvzdEHnkvwAFWecmK");
    bool toLoF = false;

    if (LXzAhpgFtTTyjph >= string("eQxesPdNgErrMWPYGQvMaEbUgaEcWhYDkaIVSFeuWRsvelGPmxtqyUcdnToTAGygbaLmbUCzylpdeukauYPmrskpTeHCNlAoetYNEpBFQSCZdBSFvCGVXdJtoXEDTtsqGrSutnjVmVkGJNEXjeyciKLaDiwbdBqWmguHutPorRAhbSehGmJXhbxHohdeSsMJcwtzIONIFpCjnOqYOfkaXFEfrrZWfhULUBpvzdEHnkvwAFWecmK")) {
        for (int HRRMRzy = 427406895; HRRMRzy > 0; HRRMRzy--) {
            toLoF = ! toLoF;
            YTcHFCeny = ! YTcHFCeny;
        }
    }

    return toLoF;
}

bool gKgOBaW::rlGpHPT()
{
    bool spsko = false;
    int MeDuXYp = 1314688088;

    for (int DWqrcYKlt = 1074110770; DWqrcYKlt > 0; DWqrcYKlt--) {
        continue;
    }

    if (MeDuXYp == 1314688088) {
        for (int RdeKUdkrxEGhiUYx = 808281174; RdeKUdkrxEGhiUYx > 0; RdeKUdkrxEGhiUYx--) {
            spsko = spsko;
            spsko = spsko;
            spsko = spsko;
            MeDuXYp = MeDuXYp;
        }
    }

    for (int AKZVfLQmpvyna = 1824692445; AKZVfLQmpvyna > 0; AKZVfLQmpvyna--) {
        MeDuXYp *= MeDuXYp;
        MeDuXYp -= MeDuXYp;
        MeDuXYp /= MeDuXYp;
        MeDuXYp /= MeDuXYp;
    }

    if (spsko != false) {
        for (int xBDjvMDRLd = 1705918961; xBDjvMDRLd > 0; xBDjvMDRLd--) {
            MeDuXYp -= MeDuXYp;
            spsko = ! spsko;
        }
    }

    return spsko;
}

void gKgOBaW::mdVjzsMqDN(string fHzTRpxiuE, double gEpEUpexqgvf, int qSJlnltOX, bool OCABhwkUpbop)
{
    double nOFMESoT = 876300.2366573155;
    int tHIuwVXxyKQcwhGj = -279892632;
    bool JWeqs = true;

    for (int daEuwn = 584735121; daEuwn > 0; daEuwn--) {
        continue;
    }

    for (int cJLRhYuGLHlGf = 556195857; cJLRhYuGLHlGf > 0; cJLRhYuGLHlGf--) {
        fHzTRpxiuE += fHzTRpxiuE;
    }

    for (int EBlSI = 1481325256; EBlSI > 0; EBlSI--) {
        fHzTRpxiuE += fHzTRpxiuE;
        qSJlnltOX -= tHIuwVXxyKQcwhGj;
    }

    for (int gLbACKFDeBAm = 1037260515; gLbACKFDeBAm > 0; gLbACKFDeBAm--) {
        nOFMESoT = gEpEUpexqgvf;
    }
}

double gKgOBaW::hFclFXuzQSLJmAV(int jindrUo, int MHLnLsfnB, int WfEMXhRGmIshr, int XVrPvjAMyT, int dxvIgPcbEI)
{
    string HYXuJaXaCer = string("NYqBoCgEcmZxoPwItIABzbUYKHJoZGPPWewHoXOwuDKxtIAupDYnhVuMwdzECUFqRomBjijRJixmimkGfWCjMxxoljjFTzeJcxMkOkQjtukjsnhCVgzUStMX");
    string IoEPYxZhOczHHaJZ = string("sySIZvlQWjuANOhXIUhTRWSxVSAKTtYfVASKkGMxIzfprZbrNGQHVwXWUCDzYgwCgIBKZOEhkrTOLQDsesnnuhhwJrGpnehDvTGleuWMvFftJUUVNcwvjPFDcHbTSZQLvUekutzsRTskKcmQkbXFEgvhyQuASsdfDqnzYdzwRrEHNwnmYRzVOwSbTqmCPfoHHBqe");
    int EoesnjtRV = -1715059446;
    bool QKcrusCw = false;
    int OIZipFPxWSeyEG = 1820959142;
    string JynITzcFbwiEJEH = string("envTeIPJDbqHIAqKshiqWiZCxTUmqTbQNYMMWVWouOfeUJhOxIezJjMMqMElAbmvPHEKlIGvKBvErshQCjyGlzzNKAlsTGkhMpqQQmgRaZSTQnPqGkKBnVGdyfPZd");
    bool wpaBtDBayvN = true;
    string YwsjpFrVofDipt = string("zkLakchlndShUublkHBzABGifOXTEcLHcKuITDHkyXFipiNqKawduLvLcmyCEpCYosYRiNQGnjdsDTMxywDooZuEKMqPWxzNKqCwWkzuzljVHegztnFveVYXtRxWEVoVMGWpCibhOSIuDjJOADdbviEnUSFrmj");

    if (XVrPvjAMyT != 21314404) {
        for (int sJvuXcIftfkeD = 93479286; sJvuXcIftfkeD > 0; sJvuXcIftfkeD--) {
            continue;
        }
    }

    for (int jHaAymX = 1642841154; jHaAymX > 0; jHaAymX--) {
        EoesnjtRV *= jindrUo;
    }

    for (int EuEAkMnIcm = 503766900; EuEAkMnIcm > 0; EuEAkMnIcm--) {
        OIZipFPxWSeyEG *= XVrPvjAMyT;
        EoesnjtRV += EoesnjtRV;
        XVrPvjAMyT *= EoesnjtRV;
        jindrUo += MHLnLsfnB;
    }

    if (IoEPYxZhOczHHaJZ <= string("NYqBoCgEcmZxoPwItIABzbUYKHJoZGPPWewHoXOwuDKxtIAupDYnhVuMwdzECUFqRomBjijRJixmimkGfWCjMxxoljjFTzeJcxMkOkQjtukjsnhCVgzUStMX")) {
        for (int FYvQTZt = 256175811; FYvQTZt > 0; FYvQTZt--) {
            dxvIgPcbEI *= XVrPvjAMyT;
            EoesnjtRV = MHLnLsfnB;
            EoesnjtRV -= jindrUo;
        }
    }

    if (dxvIgPcbEI <= -809621718) {
        for (int OuPKTtuNebrEE = 619966975; OuPKTtuNebrEE > 0; OuPKTtuNebrEE--) {
            IoEPYxZhOczHHaJZ += YwsjpFrVofDipt;
        }
    }

    for (int IuAddiXAUHV = 1132549809; IuAddiXAUHV > 0; IuAddiXAUHV--) {
        MHLnLsfnB = MHLnLsfnB;
        EoesnjtRV = dxvIgPcbEI;
        XVrPvjAMyT /= EoesnjtRV;
    }

    if (IoEPYxZhOczHHaJZ < string("sySIZvlQWjuANOhXIUhTRWSxVSAKTtYfVASKkGMxIzfprZbrNGQHVwXWUCDzYgwCgIBKZOEhkrTOLQDsesnnuhhwJrGpnehDvTGleuWMvFftJUUVNcwvjPFDcHbTSZQLvUekutzsRTskKcmQkbXFEgvhyQuASsdfDqnzYdzwRrEHNwnmYRzVOwSbTqmCPfoHHBqe")) {
        for (int rgxCoxvAMoEAU = 564935508; rgxCoxvAMoEAU > 0; rgxCoxvAMoEAU--) {
            dxvIgPcbEI /= OIZipFPxWSeyEG;
            EoesnjtRV -= OIZipFPxWSeyEG;
            XVrPvjAMyT = WfEMXhRGmIshr;
            dxvIgPcbEI /= jindrUo;
        }
    }

    return -948672.4302631869;
}

bool gKgOBaW::REIgpsnIOi()
{
    string CktkqHKKstD = string("mbSbMgxnHSWJdFAfLaXoFhwKwadJUfLkjlQDLuoDUllfeRlyNohGUiCxpgyNnhszosEHBmHPRnqNzLtltxjpDVTgnNVAshIpuDHccfcuBlqHBGfMCDKaswaSTlMClXZPmZqnxoF");
    int REZdlo = 662261896;
    string VKCyYUMqvQib = string("ClKkDAwwKVsmpOlggmWGmnufKjwglgIjBOiesedpPdUFYzhjsNMBhQaonyzLGCyYGYiWfWVhZEyreCQYRigzusJQysTWBuoJBJHZAEBMgvrHfukbXFutIGtrIxuSQEKusipWdTrgwfILVzcWwiBsRPNgFIrFYNCeAvJISwWqLlGjSKXdqOgMIgKPepSPPIOxdrKDvDpXdzVkQJTQSVCfQOtIBRFLhWrxpHGYaZzzV");
    string NpKCD = string("YrwhyUniwCLRprJAWUydojwfjfdsiGgcYESNQZVSejXkJDxLVLMbeQnoUKPYWZSdhgmAUMIfyGfAPoowhTpOLZJJEJbiOKHzwlOipsBAFTsoUNMRDofJyVssOaWpsnFNoVHIEgObgAjctSwFUFliMexyUVEQIUwLwFNNOqoufyhRyEHopwNjNBoikxjTSSttQaVCfazBYVcttoHNjc");
    string xDkycPMrmjTY = string("TUroNgxFqnCXwqlJoigkrYRlxuWnQxrDLHBZWpwHgZqJQmkaTVoDuBeVhSHkToVvQXsmBLwtYGJyHxdwHBIvFleUhXjkITyYWQoYqRmcPTAMDiDowzjXUJQXYwAEkznPmtNxVdOFxUIOYWpsNpZDKVfItffsFhngKCYiSgQhDCYUyGpCvYXvckBmzgDRRQXwHGNYIJIDpArjkKc");
    double aKEUztDoxmBNZyX = 519417.9591848173;
    bool KLkPpdkQmPHzxQS = true;
    double ygoMoNgTHrXRw = -947246.0734921885;
    bool GZItxZtTFNFmzWeA = false;
    double ZmncE = 57727.15413983602;

    for (int qGKWgrAqo = 1001068867; qGKWgrAqo > 0; qGKWgrAqo--) {
        continue;
    }

    for (int ulpHooFWAbniGD = 623704670; ulpHooFWAbniGD > 0; ulpHooFWAbniGD--) {
        ZmncE += ZmncE;
    }

    for (int MNVppT = 1054244870; MNVppT > 0; MNVppT--) {
        VKCyYUMqvQib = NpKCD;
        ZmncE /= aKEUztDoxmBNZyX;
        VKCyYUMqvQib = NpKCD;
    }

    for (int tvvOBbisfnwePY = 1843903633; tvvOBbisfnwePY > 0; tvvOBbisfnwePY--) {
        aKEUztDoxmBNZyX /= ygoMoNgTHrXRw;
        ygoMoNgTHrXRw /= ZmncE;
        aKEUztDoxmBNZyX *= aKEUztDoxmBNZyX;
    }

    return GZItxZtTFNFmzWeA;
}

string gKgOBaW::xgPgKXQwW(double pwpBF, double CMDIN, int IUNqprVykZP, int AKLvHaZnsoL, string JfGfIxlQkibmZ)
{
    string tiFGdf = string("BjkFCfRZaHBefHcczqMiOwZrbmfusNBkmQnoHAVrHVTxceVnulJwnqYxpUpWcpWWpSPsxzuCLTjyRegIYcEFbaXCbROMnaxhWqlhSzBQxOQKeBAlPUaWulifEECokNZKAVuXEoYALAOCpVCVQYpSupJzOlbZZxdDgCaeRChMIQJuyYCVcshVizILipeXBqPGRvlijbBFyOTqUVElTlOeFgaGhMVQnOYBHOQ");
    string tSCggTL = string("WiEyxjjjGQkSJxXSpUXNyQnZEkyxvQrdSbdOHunrutaBzxBmssFaGsaBgSrPRmkrmxpcXcYAsFqXTlJeOnEVoXvFPWYTYoXUVgTudKwabcKfDGKrYViGwdhzbSyfNjevgfGxvBgxuOpgWBWNXvKbG");
    string dwwcECBl = string("vHMPEqNNevjKPNfOvhduhKBkvCUxpigLmglgsOIahJGtiuCjwSrrzNmHGwAMmIRZiZOVDbqmFZMDoNhUsbIpJEdYNfPYwyIJVKckQTlTkPWWErnEWvgCKPjSpafjZVmliQUenGaHzHTVQExWHORjYnReCyBrHHPeYPpFNmBXxwzYWYCiBVcSWsjSBNFHmJuhblMYaToyFLLBiQoGbfWhCIouvz");

    if (dwwcECBl < string("WiEyxjjjGQkSJxXSpUXNyQnZEkyxvQrdSbdOHunrutaBzxBmssFaGsaBgSrPRmkrmxpcXcYAsFqXTlJeOnEVoXvFPWYTYoXUVgTudKwabcKfDGKrYViGwdhzbSyfNjevgfGxvBgxuOpgWBWNXvKbG")) {
        for (int GQNdac = 532769864; GQNdac > 0; GQNdac--) {
            tSCggTL += dwwcECBl;
        }
    }

    for (int RKFhOAU = 1782007131; RKFhOAU > 0; RKFhOAU--) {
        continue;
    }

    for (int qbTkpfJgDQfZS = 1897407919; qbTkpfJgDQfZS > 0; qbTkpfJgDQfZS--) {
        dwwcECBl += JfGfIxlQkibmZ;
    }

    return dwwcECBl;
}

string gKgOBaW::wIVntwLKtnpMX(int OfDNxhmLAiHxZ, double KSACx)
{
    double ZgErhU = 27689.797688968167;
    int ijTbqXdYwLyMF = -1343122305;
    int vOKxKFmdB = 2137500989;
    double OInRwRDbRD = 53909.68539207413;
    string PHVRjWFxOzB = string("ipfEVoEvUoLsKrOeFrsVectaNXrBdMTDlUsoZHjsAuMJdAbvxoVlbEDQjsbuJaAEokTefwyaMIyKlKHmIeuxSKbJRosXfUCudZhOdGNLlaqzxqnKhuYzYsCUEXQMPuoxhxSCSRfQDyyWPMCUSJGYcseisMAgIGnMvdiEsscFeatnuFCjOImVXMzhSnALOtHoUZnJQml");

    for (int REBiv = 816479827; REBiv > 0; REBiv--) {
        continue;
    }

    for (int jLJZCNxlhfS = 1171692772; jLJZCNxlhfS > 0; jLJZCNxlhfS--) {
        ijTbqXdYwLyMF = ijTbqXdYwLyMF;
    }

    if (OfDNxhmLAiHxZ != -1343122305) {
        for (int YJbzEa = 2119299122; YJbzEa > 0; YJbzEa--) {
            ijTbqXdYwLyMF /= vOKxKFmdB;
            ijTbqXdYwLyMF -= ijTbqXdYwLyMF;
            KSACx = OInRwRDbRD;
            vOKxKFmdB /= OfDNxhmLAiHxZ;
            OInRwRDbRD *= ZgErhU;
        }
    }

    if (ijTbqXdYwLyMF >= -1343122305) {
        for (int lltJT = 897078142; lltJT > 0; lltJT--) {
            ZgErhU += OInRwRDbRD;
            ijTbqXdYwLyMF -= ijTbqXdYwLyMF;
        }
    }

    for (int wUvHjxQWKZKhFf = 736841642; wUvHjxQWKZKhFf > 0; wUvHjxQWKZKhFf--) {
        KSACx = KSACx;
        PHVRjWFxOzB += PHVRjWFxOzB;
        OfDNxhmLAiHxZ += vOKxKFmdB;
    }

    for (int NkwdiOiGNiFt = 986370479; NkwdiOiGNiFt > 0; NkwdiOiGNiFt--) {
        KSACx -= OInRwRDbRD;
        KSACx += KSACx;
        ZgErhU = OInRwRDbRD;
        OfDNxhmLAiHxZ += vOKxKFmdB;
    }

    return PHVRjWFxOzB;
}

double gKgOBaW::FDhqLigFm(bool DIfcu, int zSwKTuoQtNWr, string KfXQaKreizAfpM)
{
    double skHnIOyvJl = 122469.38487576506;
    double RjybO = -889237.1590647027;
    bool svGNOe = false;
    bool hcgOFBHgbyjAfC = false;
    int NMnSkaLeYhDqON = 2139534745;
    bool MoVrzRgU = true;
    bool RzsvALMwdNUaeM = true;
    bool RLITr = false;

    return RjybO;
}

string gKgOBaW::YLbAqR(string aBBYM)
{
    bool RDgUfm = true;
    double ufTOpHEBXlh = -1003929.5657566115;
    int ULZqImN = -2009970061;
    int jmzDc = -1287347465;
    int qXgqwXKs = -524086960;
    double YqjYCfArZ = -795104.9319512062;
    bool bNiPQ = false;
    double VwajwNxgW = -1027206.9736451331;
    int iJxbEIHtBJF = 1111621766;
    string hzvVhJsQVwBhKPH = string("IPmKalbWCEaKtagWurDhvcqUYyZKiFydRMJJBkPfougKhohNvZbVLplrGqqFCfGGCgwAdsJjnAJPkXgTEoXvUQFLhatYISjLqPZDyZTmBty");

    for (int bZGOLWUCozUC = 1888406371; bZGOLWUCozUC > 0; bZGOLWUCozUC--) {
        jmzDc -= qXgqwXKs;
    }

    for (int lOqCw = 281623245; lOqCw > 0; lOqCw--) {
        YqjYCfArZ -= VwajwNxgW;
        hzvVhJsQVwBhKPH += aBBYM;
        jmzDc += ULZqImN;
    }

    for (int uKlnfOQgXrTWb = 642306533; uKlnfOQgXrTWb > 0; uKlnfOQgXrTWb--) {
        ufTOpHEBXlh *= ufTOpHEBXlh;
    }

    for (int MazYXgBqNchVK = 1577201166; MazYXgBqNchVK > 0; MazYXgBqNchVK--) {
        aBBYM += hzvVhJsQVwBhKPH;
    }

    if (ULZqImN < -1287347465) {
        for (int DCcqeqiGgiajs = 340893999; DCcqeqiGgiajs > 0; DCcqeqiGgiajs--) {
            YqjYCfArZ -= ufTOpHEBXlh;
        }
    }

    if (YqjYCfArZ < -1003929.5657566115) {
        for (int TPOaAu = 1589994903; TPOaAu > 0; TPOaAu--) {
            jmzDc *= iJxbEIHtBJF;
            VwajwNxgW += VwajwNxgW;
            YqjYCfArZ = VwajwNxgW;
            jmzDc += qXgqwXKs;
        }
    }

    return hzvVhJsQVwBhKPH;
}

void gKgOBaW::YYTBXu(string ZlAsFb, bool HqhYwSqwPl)
{
    string HAjOPRplcN = string("TOdUMgqbsRNyspTxlXcGJcJCJoTnjHnHAOvsbAXJeBhellgWdyjqnEfhakolmNnBrqjZzBPBdnOqMPMDjXHodzGcehpuvJbqEIueKCFwJLeKgQEVeLANvCys");
    string zMyuscxy = string("fSNpgTIcIPaCyPBkYoNuuFaujAEQCNrnedEOjdWTMBEqkVwYMdBSrWQoltGAIuXeP");
    double IFeWV = 348566.6810430988;
    int xmimoeUUYqQa = 610672946;
    bool dwSEfFhknBtmQ = true;
    double yGLORWbB = -302060.90253142273;
    string UUfAttGOtFBEYsO = string("jiIbuEQhGXDlJPJUbeBTgUzEJCsWtmavWVchYtlHGVALAzbvblkTrVMnxxWtPEYdYLpMYvprhduIFfTAkHIXApKiyZjhMdLQqOxvGbMRIrMQPCTHoxBpKcNBPsLJLJZvGzPAYjgDjoslwlLGkZzUYgUUxhrRfnHCwzlpayTetrcoBaroyclOGdYwMlygSsZJWRvklfpNeKMoOXEwhHsGBsXTAdXszJvcBtIxxa");
    double jAgICLln = 204300.92381418648;
    bool WEXefckKtU = true;
}

void gKgOBaW::eSFwNMjdMMqXW(int okLdczfStUf, string DNjDCtLcfyoj)
{
    int urrfdpquJLMUa = 857654936;
    string JuMJGTackhGZ = string("IIPIrrZJUKcvARsUvYUUCoftNXaCtEogGdjvhuOivLTddDdUlccaAvdmhENbhNOanLOvQmSTlKFrCviLxCxenTsOIaBkBRcCPpiDUAXoPpRZgPOpRFnZAHFNIJWfCqzwEviGOlvsylLWAxUwNarRbAWzDwZJTNbKnxltybVJpxtDMtHHHntpVhrAk");
    bool kRsPDXLTZgt = false;
    double AabcT = -870917.9883860594;
    int JnzCpB = 614507608;

    for (int ecxHIteuXqN = 448417271; ecxHIteuXqN > 0; ecxHIteuXqN--) {
        JnzCpB /= JnzCpB;
        DNjDCtLcfyoj += JuMJGTackhGZ;
        okLdczfStUf /= urrfdpquJLMUa;
    }

    for (int VLTxNAFNuTii = 346460194; VLTxNAFNuTii > 0; VLTxNAFNuTii--) {
        okLdczfStUf /= okLdczfStUf;
        AabcT = AabcT;
        AabcT = AabcT;
        JnzCpB = urrfdpquJLMUa;
    }

    for (int vDcFoQYxdi = 431801405; vDcFoQYxdi > 0; vDcFoQYxdi--) {
        kRsPDXLTZgt = kRsPDXLTZgt;
    }
}

bool gKgOBaW::SzfaA(bool rEmgiCc, string bYyDGyyc, int ILRxXHwcjbDHMt, bool jboQF, double RKnWamoZdVLmvic)
{
    string iOqvoRHTNgDz = string("KIThIToClUzljDVBBmmHrdrSDjvaZPhGqOXKcNvllsGLqUuKOLsbBofDXBJjwcloAKGJjVsYtWIBoSTwaLGtonvmCBZirjFrVqDlTtWdURWfEFWLPBIpCtLbnpYEibgTVAFgUNCWccyMKXHHdNpbaUq");
    int tZgHOGVQUZBQC = 1039752596;

    return jboQF;
}

string gKgOBaW::KJacOEW(double SGxAJCmUNGvv, int MsFknyKRI, bool BEPlZOQ, double uFvlVxKHoLjrngtG, int iJWwM)
{
    double MgsQYYJhy = 6990.3122345635265;
    string PEJYBnzbBGQ = string("hUpFobwSIkUJeVPwrswpiEhWLfmXyczHOYRnoOLWklCTMUyvDBmhXMVaccDAeVCBBDHtasbNUyctdDduvCpJqWgqVhCiEWnlQbNAycHzRjycrMSJbJycOtKUlxtkcBAtlKcFfMquGSiuoMpOlAegfUkmAokVvxmruHbXqZRMOadMjyTnUHCMRMJtxgljiaJpbPOzNSVvZMgKPJSFPfmEdjQXGd");
    bool tTkgHUIozMIq = false;
    double uzeSSdqzSWmf = -615197.980833958;
    double QrbqdcHztCcxCB = -269062.9302000237;
    string PKXOxIyj = string("SJSWGmgcuKWRmkiTBkREUdkSNcfdEUvzOriBYMvpqA");
    string mrQXjITlpzBF = string("ZGyHOUoViFydpuTHlQCAlsGMOeCeYFLGHJUbGzRKPuuXjPXSkvyYLGCRFRGERHliSQcOluFQPACboGwSCvBiDhzPoWKyCLcAcBDsnDGFuFczvjFYMLZrfOFdKfVpTvuSTyjfHgqYZqElyMlYCgReYpjQbJCbEFyviPukDpEGpeRCwwcOUjDwGsnQlGUOXkrLSlaQnHNQKcDtYopZOIZPyDQArDGuNQmQipbZkhFmeoDkAbdLutnDjPpn");
    int AdxEBSrEEFxMhLZt = -1751107688;
    string GhSxHVzXKxO = string("XMNcAbZDDTXpLaWTUCQJgqFYOXNWYAxTuUBWvOjYEIIIOwrpJViRNqoZzyIBDuXcXIfxsjnbeUnuEdVdhfalglCPpXclaCxRtxIMQCRMBzzRDjTYXJQCiXLgconQHZweabnMScJpwovSQQnOOoCNRlkdWbgJNbQCmlwVwPDeghRcYTqXqSB");

    if (PKXOxIyj == string("XMNcAbZDDTXpLaWTUCQJgqFYOXNWYAxTuUBWvOjYEIIIOwrpJViRNqoZzyIBDuXcXIfxsjnbeUnuEdVdhfalglCPpXclaCxRtxIMQCRMBzzRDjTYXJQCiXLgconQHZweabnMScJpwovSQQnOOoCNRlkdWbgJNbQCmlwVwPDeghRcYTqXqSB")) {
        for (int dCZPYUneWUjkQfx = 1244674220; dCZPYUneWUjkQfx > 0; dCZPYUneWUjkQfx--) {
            GhSxHVzXKxO = PKXOxIyj;
            PKXOxIyj = PEJYBnzbBGQ;
            QrbqdcHztCcxCB /= QrbqdcHztCcxCB;
            QrbqdcHztCcxCB /= QrbqdcHztCcxCB;
            PKXOxIyj += PKXOxIyj;
        }
    }

    for (int SVwACgdFtv = 1255993490; SVwACgdFtv > 0; SVwACgdFtv--) {
        PKXOxIyj += mrQXjITlpzBF;
    }

    for (int paSepn = 539992661; paSepn > 0; paSepn--) {
        MgsQYYJhy *= SGxAJCmUNGvv;
        PKXOxIyj = PEJYBnzbBGQ;
        iJWwM -= iJWwM;
        tTkgHUIozMIq = BEPlZOQ;
    }

    return GhSxHVzXKxO;
}

gKgOBaW::gKgOBaW()
{
    this->NUFIsB(1434092551, 1393914091);
    this->ojXlnWDR(-656041.4347991146, -653485.3966678802);
    this->cTfcSgnQPmQC(string("YRKOyJtTXvClUHbfLijBQEsIjCooeDwQkhbIfHWsuAKBDnFghsrGvqqRzDOBshdJxBhidmDyDJxgxbufTQaAXHLQMtvOGkNtjfq"), -1854110785, string("mdbFhSGreDwKSThUODqNXWmGSzmGgpCFRUppacl"), string("kRAvXWXCzoWIQLqQUupUdZJBBbILoJkUCBjpVtyXqaNowzjoFxnodvVLSRXKKCGsRcmeYORAuiptXLensauewqRKfFmDLfDJrrXSYKUlaxQtDmywBzEZclsiwRyvagRuRUEiiVNj"));
    this->rlGpHPT();
    this->mdVjzsMqDN(string("KRrjhEeAfowpEdIvrjVpcYAhyepUIXnmZaMcHhfADVicNxpjGXSYCVrXYUzIivaAVcWcxWqVEBSvcOuCOOYUtssDDLpCNRfKjeAlDdbaFHKHspfQyyGXAbBrjiooFAdjqMLqPIQnMXQXNYmPfcSkticDdRssgAjXLPNxTGihNQWaepBtbZZGuFFXXXLLJtnDJejGoWUAIRSSprVrIIygKJMKpkfMTpXswicCADcLHHnqDwZtXWsHMmhhkKW"), 903442.6640865303, 1679176605, true);
    this->hFclFXuzQSLJmAV(21314404, 1230797298, 1984644742, -99995736, -809621718);
    this->REIgpsnIOi();
    this->xgPgKXQwW(-417139.4575109407, 690920.78101237, 1499029823, -2034128894, string("zVXdoLDUrNowgkzmbJwTXOzFRPOhvUPUnkAhNDzOknkRUExJoTRCHSmrxvKSpJSMUXuAZyjvjdVTeweQsOwJmcxAu"));
    this->wIVntwLKtnpMX(-843780525, -861821.2355118954);
    this->FDhqLigFm(false, 1200830418, string("XviHrPgGLNxodvdGGNyqsNNEqgPUEyVILmbedFOCOcCZKxQHirzBNuerEskubqhqtrTaHrCaRTyyDpUpQVakvsGONQnXvrOseCxfAcVYDPzvjnsyXZklxTIXQytOHEKpDWZAlMyAwPDjYNoUYDCYI"));
    this->YLbAqR(string("YijlmFnsLFFQRmeISsFhRyjEwlm"));
    this->YYTBXu(string("WZxcBFdsAvEZOsygnGGhZZdBENljAfZeUXtBgbRrBhlpAwwNiwGkQoGrxlQMhnxqNnJv"), true);
    this->eSFwNMjdMMqXW(-1055336018, string("ZlhWZxJFjzggTrGGHCTDigxDYwclozAojOlmNwPHgixYxiDjYIbBgZwCUwGTxoOgYcBGlHKkmAJdeKzHhLimaNIIEcxCrAbBirSRWbgMlHNjLueMY"));
    this->SzfaA(false, string("jVZAnJMayaoOXhQFLNqJYHoquUBLgcucFvHYwgJFdZQReGhSquFRmZOOtZIsXbZYbzMFoTljhFCfmqLFnfikoBnMOONUwEEyYzhdpOfDszaaOVJoisNRfzjNWDKvpmRXQrARmpUMKHMFXULGANtLAUeLiM"), 719513192, true, -424455.6807231781);
    this->KJacOEW(816751.6473953589, 924557197, false, 1036817.6174829701, 712529779);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iJVmubGzaBY
{
public:
    bool kXNlpwijC;
    string rBHQkYkcXDwx;
    string GyJsIvVSKrUNiMa;
    int pDovKJzyQl;

    iJVmubGzaBY();
    void AnoqJYqQZJQx(bool xNYcgs, bool iSstqKuK, bool oIthXEzER);
    void zRJrHnAqqgGk(string ULUtFFwKz);
    bool mbMBwtqQ(int kkiiu, int uXuwipvFBcenX);
    bool oVBOcwQuFYS(bool gAVFyuUeLu);
    string rnheD(double AnHnqGxvG, int RTVYyBfIyS);
    double aHKfsAkeRmeVCuk(double cLLTPVEgbu);
    void HIcdZehgG();
    bool MormiKuoFJK(string VKLPCZTZHJsrZcP);
protected:
    string yIOHlXFwQHEZNZ;
    bool yOtXOWSt;

    bool oZTeMVSTi(double tJkmyJ, bool WPjagVKdrStrt);
    bool XAKSr(bool ytusFRmvb, string NzgeYpwX);
private:
    string lqFXlRypC;
    bool FRsQhAZgXFZNz;

    int EfyXCAk(int TFqWqVWBMCtanlnu);
};

void iJVmubGzaBY::AnoqJYqQZJQx(bool xNYcgs, bool iSstqKuK, bool oIthXEzER)
{
    string HnUODs = string("SlIuZoWKtRKWizfzvgJITASmjaKpXDpqTnbnbQTQpPXLnfdslILGaYaIOwoZtVykGqAAiGlEoiwQmbBSzvfHpzkbpVppjtLEswQAjaxmgnOmVFtahiTsznjlMQwcXIyTOIJzBDJJNmXzjKeQNefHBSDDnaZTjjJXlzrrnbNWttsWrTRdGlDTwfhmYnTPIhhvdtfLzaThoIgEKGZbsvZlwIfiPrIEvUQjQuSIIYUEVooetvDHsK");
    double FkLQOjOavRCdCr = 634470.1711157258;
    double SsbHRoZTIM = 900674.8832577569;
    bool KoIoizPpNEHMEGZP = true;
    double hZOzOPPbdGRHKsVH = -989279.1335182872;
    bool HigJlt = true;
    int hqZvdcV = -572454761;

    if (oIthXEzER == true) {
        for (int YOhWqMJWz = 1535360308; YOhWqMJWz > 0; YOhWqMJWz--) {
            continue;
        }
    }

    if (FkLQOjOavRCdCr < -989279.1335182872) {
        for (int CLoumrZn = 859759725; CLoumrZn > 0; CLoumrZn--) {
            oIthXEzER = oIthXEzER;
            FkLQOjOavRCdCr += FkLQOjOavRCdCr;
        }
    }

    if (SsbHRoZTIM == -989279.1335182872) {
        for (int KxmBgbYXpPA = 521174818; KxmBgbYXpPA > 0; KxmBgbYXpPA--) {
            KoIoizPpNEHMEGZP = oIthXEzER;
        }
    }
}

void iJVmubGzaBY::zRJrHnAqqgGk(string ULUtFFwKz)
{
    double VZyvnzogx = 885497.6002069074;
    double TinTX = -333078.01660884917;
    bool ixbRjsrFLJ = true;
    string hABsYcn = string("UncYrQrUwqZFLJBEbcVcVvqhUKNSZmLBWxwz");
    string lMBFURwdKhbemI = string("RlLHJqSJqPVLJBuizTHANGfgwQYlDVfJNZhmIqGPqLkkJnnIvZEGaeQXtMsZWLVvXzmCEQeVlCoOCkuPkQIRSHdlfjMnXdhvjjHolhUfTXNWyiBHAfirpiFhIaBxnBsoromIQYYnULGsdPdW");
    double ILuOeslu = -202958.474482817;
    int nrCeffhpnXHb = -1660960771;

    for (int dfWzrgAujlW = 118548733; dfWzrgAujlW > 0; dfWzrgAujlW--) {
        continue;
    }

    for (int SUjCIKhQBClLeZO = 627743305; SUjCIKhQBClLeZO > 0; SUjCIKhQBClLeZO--) {
        TinTX -= TinTX;
        VZyvnzogx -= TinTX;
        ixbRjsrFLJ = ixbRjsrFLJ;
    }

    for (int eWPlDOR = 651564102; eWPlDOR > 0; eWPlDOR--) {
        hABsYcn += hABsYcn;
    }

    if (VZyvnzogx == 885497.6002069074) {
        for (int efdiYfyFUfjIbryg = 1142634270; efdiYfyFUfjIbryg > 0; efdiYfyFUfjIbryg--) {
            continue;
        }
    }

    if (lMBFURwdKhbemI == string("TtoZCQEmWIzxlbsAmFLHXCRgNyrzzygehTUXhGkgUiUdaYeRpBwhHKPAUTKxQAWeqfzzixYFyrDFLUohCMhncmBtqjKcHaJFxZkfvYdHEHjxCWThjOnhDnSxqNKBMYTWqWMjUlmaoYPOjYkHEgtwbTVIKGwMvwgaIAbFXQBHHGEKYZTtEKdJlVxGWPmbedjRNXjJSzerGjJOILcnMT")) {
        for (int AjqppTlA = 678021319; AjqppTlA > 0; AjqppTlA--) {
            ILuOeslu *= VZyvnzogx;
            VZyvnzogx /= TinTX;
        }
    }
}

bool iJVmubGzaBY::mbMBwtqQ(int kkiiu, int uXuwipvFBcenX)
{
    double bcUDBbvoob = 51732.452543683794;
    string PZahbKJ = string("eBKvYYGbqhhHUatzNpIOOXUAmEBnZmyaCVSnutovylYuSMZJhPwRZKhKeTlPcuOtjLpmBjkezfXphgwJYNjCqkXPTIpipzTrTYKTIFMalIuqSdaCtIgpggm");

    for (int JITvRwOzzDh = 1748337307; JITvRwOzzDh > 0; JITvRwOzzDh--) {
        uXuwipvFBcenX = uXuwipvFBcenX;
        uXuwipvFBcenX += uXuwipvFBcenX;
        kkiiu /= kkiiu;
    }

    for (int hGoqjwysbggrVX = 1383070191; hGoqjwysbggrVX > 0; hGoqjwysbggrVX--) {
        PZahbKJ += PZahbKJ;
        uXuwipvFBcenX *= kkiiu;
        kkiiu *= kkiiu;
        kkiiu += uXuwipvFBcenX;
    }

    for (int nCrXCgeDbtpEHq = 26364102; nCrXCgeDbtpEHq > 0; nCrXCgeDbtpEHq--) {
        kkiiu -= kkiiu;
        kkiiu /= uXuwipvFBcenX;
    }

    for (int KQMJUnGXcDi = 1014043675; KQMJUnGXcDi > 0; KQMJUnGXcDi--) {
        kkiiu -= uXuwipvFBcenX;
        bcUDBbvoob /= bcUDBbvoob;
    }

    for (int RojgzHhl = 429017499; RojgzHhl > 0; RojgzHhl--) {
        PZahbKJ += PZahbKJ;
        kkiiu /= uXuwipvFBcenX;
        PZahbKJ = PZahbKJ;
        uXuwipvFBcenX *= uXuwipvFBcenX;
    }

    return true;
}

bool iJVmubGzaBY::oVBOcwQuFYS(bool gAVFyuUeLu)
{
    double pFDnFIHeBkZZRj = 631210.8859425434;
    double VscJfFpz = -12817.897683615605;
    bool RWHUs = true;
    int CuxYSlMqBqdsH = -1822815503;
    string mmWmH = string("rPIYgNqiINRlkyStxdjfeMnsrvXiFVoBLkYDoAZLWgNPRlJktGYmN");
    string Jhyqs = string("mkvjcckDTfotuEmDSICjYCFNnNFJOcJHqPYaPYXUxkfWHCCptTFphqMTVuRCHajqrIIoCZsYEXxrIIetiVjmdCzzWvuVPGTPZoZalhfTIzwkQuySgxzWBXjChcqVkveCnOLOvVJXnloFHwcykKeOfjEuWurAevTZyuSDvByVPyPPye");
    double QHTNnLxClik = 522710.45939458715;

    return RWHUs;
}

string iJVmubGzaBY::rnheD(double AnHnqGxvG, int RTVYyBfIyS)
{
    bool RDACgJ = false;
    bool mQHathCylOu = true;
    bool fEvlLeawH = true;
    string uZQtSnBgAtEilW = string("yGEvrvBcMpjqQximmqukxxVhhirzUMPorzeoGLXdxcveMIVdvwRWujnJEngvbqCiwhfzkqzCaoOZIdYdzdwxwtmKKwwkvbhiylyHuAeAYKxcMqMNxIVkTUOHigSzJpGqRVfyKdvraYAofjaJbB");
    string HWsqLYa = string("NvEiJjnGYunlyjpcdhmdvXEVLoNBTSjLBNAfcLlNhHJjKFLOIqrccOUMkEEFgtssssYGZYibTsWmdUFNeHjzpBWLggdxrLnXWINbzchtNOUqAJaADflcfxvgsBXcKurPBdZVjIDnAedJTAhJoLtcYuArbBcsRKEavdZXWkddLWOoaXXMKYgnxqFGraGEydCuVEArGmx");
    int cFSgfBpNvcAn = -1349663101;
    bool AGhNgmlHbJjoa = true;
    string lHikdWcsclNbdQux = string("QIlszajncMJRoYpGsceoSBNVFarcOGGEsLMhEHPVJVckfdlWeHZDARMlPKYEpzhDBrMnHfxzsdqzXnTjPtJRmJSiZfmZytgSQhrMtFBRscUnMASTFppWuVmTDQSkUUgPXmxOESUbuyCSeNvDBKxoXBBrVEcoaQQc");
    int wpWbfVPetXn = -1852595961;
    string YhorAc = string("YJqsbYRSiCzmgxipdybyBXIyvqekrRDZnMwXaIcKimAjpSAhfFfYVuGkVxpTJXHxgvSdAdHXSmEODrKsoNyyxTOWMaJoqagWDWotgbbOVtQMqKMtfdngXzzOIOfMniQVynsEkionWKNuHJdPBVPnXtLZxNqsucaASzgrBZFQBfMxlBypYHDnrZnvngNVDNEosFOToPHDBZnjUxcFCsWsnOXOMezxTfHxXPiVZufvjjKoLNq");

    for (int qBDsZdBmcN = 1435270000; qBDsZdBmcN > 0; qBDsZdBmcN--) {
        uZQtSnBgAtEilW = YhorAc;
    }

    for (int uKxfl = 824802168; uKxfl > 0; uKxfl--) {
        fEvlLeawH = mQHathCylOu;
        fEvlLeawH = mQHathCylOu;
    }

    if (wpWbfVPetXn >= -1852595961) {
        for (int zxyhENN = 1297068854; zxyhENN > 0; zxyhENN--) {
            lHikdWcsclNbdQux = HWsqLYa;
            cFSgfBpNvcAn /= RTVYyBfIyS;
            mQHathCylOu = ! AGhNgmlHbJjoa;
        }
    }

    return YhorAc;
}

double iJVmubGzaBY::aHKfsAkeRmeVCuk(double cLLTPVEgbu)
{
    bool kHFaULhcpsA = false;
    double hhACjZPDBIZWEJZc = 59241.855302827644;
    string DHhitA = string("rHbEuxTMmPasXuttlEqAmvcOAHaZdUoykjVRMosEQvSsRFbDNWCmSVMnpMoYdrGWtKXwNYlACJepGJV");
    int lAWgxE = 734028456;
    int JQrSRVXbik = -685067861;
    string yqpJv = string("iLrDYDHhcTUZgOXNGbFTYHMKwreTnRMSRZmcDRulUzmQQIPYUuuqXbpGdpCzJZNOxMgmHKVrsgMDEUAJNelclIknFyNBtLGeaKifUCyeFMFbunXnHVhzksOILriPbqpZeuuBPafCabOONiRjOapVpTKVsBdQeTpdkrIPXJjdUKZfvCiJECzCBethvZub");
    bool UCAwkQHUibTEqMn = false;
    double NmZiwzHdwAx = 374085.99811313534;
    double BbNgGwZLNeYKGdPP = -76124.32020036137;

    for (int ATWHnpNLrmhFedO = 1440117049; ATWHnpNLrmhFedO > 0; ATWHnpNLrmhFedO--) {
        continue;
    }

    return BbNgGwZLNeYKGdPP;
}

void iJVmubGzaBY::HIcdZehgG()
{
    bool TnKOHmGBJaFd = false;
    bool IYTBKxaq = false;
    int cvozYPoMjzw = 1575354827;
    string mqDQQWI = string("WeXRYECzuCgEWGYJNAfZdLuDqNHWaHrNHkSwOUPOydMTZasyZIuaaxxbnMPuEomqhkMuewQMWDtvwrDncFsXlkZGOCRpVABHyyNMEpLwUGiwLdwMsADKAsLkmTiUNvvumMdDnhZGtDDxFkYxMztwbMnfkvqCEKJicdxyXIDvrFYYFtJ");

    if (IYTBKxaq != false) {
        for (int rudkuwcZmW = 1030813412; rudkuwcZmW > 0; rudkuwcZmW--) {
            mqDQQWI = mqDQQWI;
            IYTBKxaq = ! TnKOHmGBJaFd;
            cvozYPoMjzw = cvozYPoMjzw;
        }
    }
}

bool iJVmubGzaBY::MormiKuoFJK(string VKLPCZTZHJsrZcP)
{
    double FMgLictz = -647422.3443034317;
    double KRRWPHvNTPdFFAe = -186066.4905190956;
    bool kZEFwvrIcbW = true;
    bool vxGqDqSrFsNgE = true;
    int EmoECXZrLyYFmw = 1231141170;
    string JAvTJmqVIQpzi = string("nKvrkLsvIbbTMuaHpFwaVpxBUdwqNUHnwTbnCfCNIsZNLRLCyjTQWACAcAJRaVnECAWzIvhenCCgWBqnZgUmzlHoCzDPLywrkudOjREFcwwebtSAGVKTLCEwKxjUJnBwthHMwJIOSmqCwFuKHkfjhCrLJAbrqtoGTZrehBG");
    string yuURinNOs = string("HcUysPKdKDAInpjbaigsMHxwSWONLaFrBydmxNiRKyxadExVRQmfDUwBMcnqKVMt");
    bool EGDIJtngd = false;
    string yVsxubI = string("hUQBjhxQHqEiTEzDtmTAxVUFwtrSWqmQqOkXDDFrdKdhZwZhHyzCflEXQYkLXvGwcuBoIRtAisIelttFYOSxAtVldXbwfwpqSLxySYtdlXreNTVRiRMUlqxQOBWrgenGfyYTXQcwoYkhMnrbMEJFxeuYIFDeRKKwIRUzQtYfwqeMenweEkSkDLBwDCvqd");
    int yVAksiiWbV = 1223142158;

    for (int JTYJcUCSopaah = 109246230; JTYJcUCSopaah > 0; JTYJcUCSopaah--) {
        KRRWPHvNTPdFFAe = KRRWPHvNTPdFFAe;
        VKLPCZTZHJsrZcP = VKLPCZTZHJsrZcP;
        vxGqDqSrFsNgE = ! vxGqDqSrFsNgE;
        JAvTJmqVIQpzi = JAvTJmqVIQpzi;
    }

    for (int uXNWBd = 1210834722; uXNWBd > 0; uXNWBd--) {
        VKLPCZTZHJsrZcP += VKLPCZTZHJsrZcP;
    }

    if (yuURinNOs < string("HcUysPKdKDAInpjbaigsMHxwSWONLaFrBydmxNiRKyxadExVRQmfDUwBMcnqKVMt")) {
        for (int qGFtqhrUTlFo = 659235893; qGFtqhrUTlFo > 0; qGFtqhrUTlFo--) {
            KRRWPHvNTPdFFAe += KRRWPHvNTPdFFAe;
            yVsxubI += JAvTJmqVIQpzi;
            yVsxubI += VKLPCZTZHJsrZcP;
        }
    }

    return EGDIJtngd;
}

bool iJVmubGzaBY::oZTeMVSTi(double tJkmyJ, bool WPjagVKdrStrt)
{
    string CzRcRxbRoKTg = string("vCidDIfbAEGlVkKcODbkAOgifijNmcROFtDdtGyPuoMKotfucnqvoFirwjunmTwAnsikaxPAbjpQIAY");
    int wlMPEB = 1602124988;

    return WPjagVKdrStrt;
}

bool iJVmubGzaBY::XAKSr(bool ytusFRmvb, string NzgeYpwX)
{
    bool gzfVYy = true;

    if (gzfVYy == true) {
        for (int tYnjdRQpxxu = 1555635441; tYnjdRQpxxu > 0; tYnjdRQpxxu--) {
            ytusFRmvb = ! gzfVYy;
            ytusFRmvb = ! gzfVYy;
            gzfVYy = ! ytusFRmvb;
            gzfVYy = ! gzfVYy;
            ytusFRmvb = ! ytusFRmvb;
        }
    }

    for (int AqqWm = 1923653915; AqqWm > 0; AqqWm--) {
        gzfVYy = ! ytusFRmvb;
        NzgeYpwX += NzgeYpwX;
        ytusFRmvb = gzfVYy;
        ytusFRmvb = ! gzfVYy;
        NzgeYpwX += NzgeYpwX;
        NzgeYpwX = NzgeYpwX;
        ytusFRmvb = ytusFRmvb;
    }

    return gzfVYy;
}

int iJVmubGzaBY::EfyXCAk(int TFqWqVWBMCtanlnu)
{
    int stNNPx = 653225241;
    string PrKEyBvsIpqL = string("qqjQeECnaycNKmNRnMQcEHkzJBvoJZNBnhDEWPYxChRZMfSQa");
    int txDJEIOPstiE = -2114135977;
    bool EQpoMFHghyMV = false;

    return txDJEIOPstiE;
}

iJVmubGzaBY::iJVmubGzaBY()
{
    this->AnoqJYqQZJQx(false, false, false);
    this->zRJrHnAqqgGk(string("TtoZCQEmWIzxlbsAmFLHXCRgNyrzzygehTUXhGkgUiUdaYeRpBwhHKPAUTKxQAWeqfzzixYFyrDFLUohCMhncmBtqjKcHaJFxZkfvYdHEHjxCWThjOnhDnSxqNKBMYTWqWMjUlmaoYPOjYkHEgtwbTVIKGwMvwgaIAbFXQBHHGEKYZTtEKdJlVxGWPmbedjRNXjJSzerGjJOILcnMT"));
    this->mbMBwtqQ(1070599736, -920767746);
    this->oVBOcwQuFYS(false);
    this->rnheD(-558128.0544859222, 917404346);
    this->aHKfsAkeRmeVCuk(-908025.6013266176);
    this->HIcdZehgG();
    this->MormiKuoFJK(string("LgxFFPrUxZGWGsiyhuexcomKW"));
    this->oZTeMVSTi(-675165.2676338261, false);
    this->XAKSr(false, string("JTZhcCqzCnPCgLwKiQVdRpVnVXubHhHdSHrRlVfIOruboQGooQQzmpXTscUwsbvHmjdYxbwxlzVZwXJclMksxXRsgHgVraIwLvTdLUayxjcPIdJMtSPzbJIZRElTYzvzQUdcEaVRpKihNScVmdsadGjAqWy"));
    this->EfyXCAk(-1024767810);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BjjKbMpAhq
{
public:
    double KxLMpvmqCbVAP;
    bool RWXZLHJYPStKy;
    double zDqfE;

    BjjKbMpAhq();
    int XRzPkO(int kZPFGIznN, double VbRazyRvxsZ);
    bool bUZdNArRRr(int ATGOoItKGJ, double FWySCdNiWK, double EpGkQzHvcnwr);
    int qirkFIEgwPszrFU(int kghzCPQJTfkiJlr, double dURWSNwmgdg, int XWFcY, string kQgXVdQNZa, string OKornPJWlDnR);
    string REYnnbOSAsz(double OzxdOQdM, string PKkioNKpqiYtd, double pMppPXRw);
    string pOzTKZieHZBrj(double sRROMoEWdnaxn, int raMjnxRXn, string SnMhrRxJbbp);
    void ukMyBYPT();
    string WBQNrMEaM(string aFyzpVUkJuuqIvN, bool kzZCuUB, bool UsMYR, string nshnLpbedvYNJ, string KeJFtyrHhgRbA);
    void CMsAieDOMG();
protected:
    bool RNzOPwmjUVpQyGku;
    int AlOMg;
    string PRjVhxAqGCw;
    bool oUgOilj;
    int FnBTci;
    string esyddrmzVgD;

    int vYpuFpMeAV(string EJJaJgZgbCe, string xjkLw, string uMhoaw, int wLTiqJmJOBVTLTjb);
    int PSEoc();
    void zCNvhypmvPIib();
    int UpxmoJHVtAK(bool oZNTJTFxrQ, int mOdsvMAACIwQitO, string LAYZkqlLLRV);
    bool sJAWzWDXyH(string EglqfIE, bool FaeSrTw);
private:
    double ANBgWroceULN;
    string UvXXPXjXEOjCf;
    string XByPrJIralarso;
    double qoRWTQCHaAxGQrw;
    int ffviZi;

};

int BjjKbMpAhq::XRzPkO(int kZPFGIznN, double VbRazyRvxsZ)
{
    bool hxreXEhg = true;

    return kZPFGIznN;
}

bool BjjKbMpAhq::bUZdNArRRr(int ATGOoItKGJ, double FWySCdNiWK, double EpGkQzHvcnwr)
{
    int pKmvTlBxu = 718173770;
    bool AseXUjjuLTSnEmGz = false;
    double lGSLtwB = -636232.5196464133;
    string GAwXnOEAW = string("TcqHtIrhlVDsasYWbOCKaccrncFuOqhGokDLkywIyDlFaQbgMBsEGPsoaOMHfvtICKWwEBIzeBPrDkVQZjSIJuTlzNbXaMGwWTkYuNOcktViyDFljctKurmsOGaVWFndtVKXJXKMuqQdFrtuNHcOtafiKWCEhZHmAxFbdcBeyixBIdHNFTjLyjtGqZXyoeNimbEdlGUhyOOTtlxpDNpkIPIwijlVwXIgBDVwvVoyqcfsuEwDJXtLMpiaqjH");

    for (int qfbWSsAAlY = 791120436; qfbWSsAAlY > 0; qfbWSsAAlY--) {
        EpGkQzHvcnwr /= lGSLtwB;
    }

    for (int rgxbtrqmAXazZpr = 553523756; rgxbtrqmAXazZpr > 0; rgxbtrqmAXazZpr--) {
        lGSLtwB -= lGSLtwB;
        ATGOoItKGJ *= ATGOoItKGJ;
        lGSLtwB += FWySCdNiWK;
    }

    for (int SVAOeXTYvVDBOodN = 1296547695; SVAOeXTYvVDBOodN > 0; SVAOeXTYvVDBOodN--) {
        lGSLtwB = FWySCdNiWK;
        lGSLtwB = EpGkQzHvcnwr;
    }

    return AseXUjjuLTSnEmGz;
}

int BjjKbMpAhq::qirkFIEgwPszrFU(int kghzCPQJTfkiJlr, double dURWSNwmgdg, int XWFcY, string kQgXVdQNZa, string OKornPJWlDnR)
{
    string YdaGS = string("cJaJtHQTaWvRiqXzksjGaNwiiDqzKDxdHNeIWeDCWucVRbfdyPMTuxuBKPsrmtgLgEGuS");

    for (int cPdlxGBCJO = 278968033; cPdlxGBCJO > 0; cPdlxGBCJO--) {
        dURWSNwmgdg = dURWSNwmgdg;
        kQgXVdQNZa += YdaGS;
    }

    return XWFcY;
}

string BjjKbMpAhq::REYnnbOSAsz(double OzxdOQdM, string PKkioNKpqiYtd, double pMppPXRw)
{
    double ruiOzzMGjinkYNjV = -564188.2080374655;
    double KUlJz = 974014.6912496344;
    string tqHeuq = string("tFZSeSCIknYyXIupQuuekRKaMKfYVAxVOQOSeHxgjKzBRkpKlbABMGCja");
    int mhCgHMXf = 450340912;
    int bscdlNbKKoCXB = -804046610;
    string PApesJHvMGc = string("opdSodOyWfjHUjEENwYUyHRfkCUIpDHuZdGiXDpVyoDhgWhOdBXAtXQyWROeBhpdkmsUaDYCzfLyPwxEbGpnfsjCJQIsCzoixIFHiIfzwUOjzSDlRetqXpRcbUXqOkqAFSPbHGDUsDxkvXionQlBhhxoUuCukhvqffIYKEzcVxmQPDVOynXdyoxuwUeesVOEorwvGEllByplUMEpxlCEUbfe");
    string SkJLywVENrerNP = string("QJQxapUIWkQtsLjKFHIevQPUIOwlUYARqfpXEMzPQQliCehQfTzPBYgtyLisVdQdpBHTAZhsgWzPEzTApyruGJdQhUErzWIkgsYaUwN");
    int QPxxHXybuNCaSP = -1801479258;
    bool aHpttEj = false;

    if (PKkioNKpqiYtd <= string("QJQxapUIWkQtsLjKFHIevQPUIOwlUYARqfpXEMzPQQliCehQfTzPBYgtyLisVdQdpBHTAZhsgWzPEzTApyruGJdQhUErzWIkgsYaUwN")) {
        for (int SAErKfdIqTGFcf = 612229655; SAErKfdIqTGFcf > 0; SAErKfdIqTGFcf--) {
            SkJLywVENrerNP = tqHeuq;
            PApesJHvMGc += PKkioNKpqiYtd;
            PKkioNKpqiYtd += tqHeuq;
        }
    }

    return SkJLywVENrerNP;
}

string BjjKbMpAhq::pOzTKZieHZBrj(double sRROMoEWdnaxn, int raMjnxRXn, string SnMhrRxJbbp)
{
    bool GyExXsPoB = false;
    double dUEAVNEYfOXJjyv = -1047545.4749493129;
    bool gqHyvyeY = true;
    int llTgGubpCTOzatK = -1048272159;
    int cFoUoxim = 659250654;
    string sqrKdosDGR = string("sLDmpgWFODSotHXSL");
    int bTuwLlJgNuuKStU = 1618531661;
    string cuThR = string("RwOdRYHOvVStJORVpDxKGoJVcJoVrOkfTzAJvdLhLNgMCgEfUAzSkoVqcPYddMEPQtXQBbCJYeHEEuNLrNxgoHLSwJHHSFniNLLEucEOAfCAOkFkmhawoiUMIVBGcXNfkZexsPkUmigTgSJODKDRYijrvTQwjpDjYYcEMpEBWyzpxrCNCjftSntOQMaluvoOyNCqCIZGsazSmWMSCT");
    double mDiFsSvOk = -618147.9431419865;

    if (raMjnxRXn >= 1618531661) {
        for (int AjBSZimLh = 1169780427; AjBSZimLh > 0; AjBSZimLh--) {
            raMjnxRXn -= cFoUoxim;
        }
    }

    for (int ErgEkKYVbPC = 2057497147; ErgEkKYVbPC > 0; ErgEkKYVbPC--) {
        continue;
    }

    for (int IWtkHXc = 539312397; IWtkHXc > 0; IWtkHXc--) {
        cuThR = SnMhrRxJbbp;
    }

    return cuThR;
}

void BjjKbMpAhq::ukMyBYPT()
{
    string ocjBLOdVQakSAf = string("ONOFaKvnyLLgPtHqbWiJcXSYGzusKyoRhYhOrAfYOEKJiSthsRRVTBVbGtLFqTGjm");
    int eiEWZEFcnFamIgF = 133014830;
    string FqfZv = string("yJUZcvzdksweqNFChZkiSRcBzhxKxWgFGwDbheWfqKLLjxOqAVMKZQCOtvKADMnirKGLXozbRWHDJUGMrUaBLSZlKuXjFSevieChzBbkgamhfHYzXouTjWvuaqACoNtLUbtaqSuNgCOZsSpThZW");
    string rwTdFXOjn = string("UeOyOtPEzsHNcVpNTCLBpuAxhhxlfnYwvTdPdECCmJyJwnJywVInOdRtmNVxogM");
    double wHKTgpsYnYzz = 409202.50837255566;
    string ZqpRtptr = string("CkLjRJSlaxVQTymwiToPTaDYmDVbRbrmGReUDXrAZDuRoPVhmXtXrHadVyobtkYKQGUCklyinTNUhneXzedbuhzITQRwsDIyRUTwaQLoXkFCTwKBITLLGTCUzHNmEbjKtgyagHPezesPxwwldPrKAy");

    if (FqfZv != string("yJUZcvzdksweqNFChZkiSRcBzhxKxWgFGwDbheWfqKLLjxOqAVMKZQCOtvKADMnirKGLXozbRWHDJUGMrUaBLSZlKuXjFSevieChzBbkgamhfHYzXouTjWvuaqACoNtLUbtaqSuNgCOZsSpThZW")) {
        for (int AqRLQu = 1585427342; AqRLQu > 0; AqRLQu--) {
            FqfZv = ocjBLOdVQakSAf;
            rwTdFXOjn += ocjBLOdVQakSAf;
            wHKTgpsYnYzz /= wHKTgpsYnYzz;
            ZqpRtptr = rwTdFXOjn;
            rwTdFXOjn = ZqpRtptr;
        }
    }

    if (ZqpRtptr < string("ONOFaKvnyLLgPtHqbWiJcXSYGzusKyoRhYhOrAfYOEKJiSthsRRVTBVbGtLFqTGjm")) {
        for (int fkcUEaLbXNyrRTI = 1004273220; fkcUEaLbXNyrRTI > 0; fkcUEaLbXNyrRTI--) {
            continue;
        }
    }

    if (rwTdFXOjn < string("ONOFaKvnyLLgPtHqbWiJcXSYGzusKyoRhYhOrAfYOEKJiSthsRRVTBVbGtLFqTGjm")) {
        for (int aJCiG = 1716172807; aJCiG > 0; aJCiG--) {
            ZqpRtptr += ocjBLOdVQakSAf;
            ZqpRtptr = FqfZv;
            rwTdFXOjn = rwTdFXOjn;
            FqfZv = FqfZv;
        }
    }
}

string BjjKbMpAhq::WBQNrMEaM(string aFyzpVUkJuuqIvN, bool kzZCuUB, bool UsMYR, string nshnLpbedvYNJ, string KeJFtyrHhgRbA)
{
    bool HDunyriw = true;
    bool CfvhSMqOCxOry = false;
    bool VXzIWHsIIiYcESd = false;
    bool skfJdAanwXYNF = false;
    bool IMtdFLnPanpKeJy = true;

    for (int LdOHCUtxuum = 1254592982; LdOHCUtxuum > 0; LdOHCUtxuum--) {
        skfJdAanwXYNF = ! HDunyriw;
        skfJdAanwXYNF = ! kzZCuUB;
        VXzIWHsIIiYcESd = ! UsMYR;
        IMtdFLnPanpKeJy = VXzIWHsIIiYcESd;
        UsMYR = kzZCuUB;
        IMtdFLnPanpKeJy = ! kzZCuUB;
        VXzIWHsIIiYcESd = ! skfJdAanwXYNF;
    }

    if (kzZCuUB != false) {
        for (int dxqwzTkJMKf = 1430913542; dxqwzTkJMKf > 0; dxqwzTkJMKf--) {
            VXzIWHsIIiYcESd = IMtdFLnPanpKeJy;
        }
    }

    return KeJFtyrHhgRbA;
}

void BjjKbMpAhq::CMsAieDOMG()
{
    double vxZHPLVAEid = 697289.3721205883;
    int LgrcJLuqsgte = -139831517;
    string tCPiJmMMFkuniv = string("pMgzPsnwoFOnAGxmeGOInlekELVZFAHnFwdNbHZVoKRqTKiXPAVgvJBRyIfQqZUCryXR");
    string iHEnDCDSkj = string("QCQglRKkbENIEfNkophrpGTpfDqHJOpOxiHGFDUaAIXztnvhuiLkVNMmkQ");

    if (tCPiJmMMFkuniv != string("QCQglRKkbENIEfNkophrpGTpfDqHJOpOxiHGFDUaAIXztnvhuiLkVNMmkQ")) {
        for (int dCsoJ = 627846865; dCsoJ > 0; dCsoJ--) {
            iHEnDCDSkj = tCPiJmMMFkuniv;
        }
    }

    for (int YubBzCQhMWRA = 1528942984; YubBzCQhMWRA > 0; YubBzCQhMWRA--) {
        tCPiJmMMFkuniv += tCPiJmMMFkuniv;
        iHEnDCDSkj = tCPiJmMMFkuniv;
        iHEnDCDSkj = tCPiJmMMFkuniv;
        iHEnDCDSkj = tCPiJmMMFkuniv;
    }

    for (int BCMsAGTiOU = 1053527357; BCMsAGTiOU > 0; BCMsAGTiOU--) {
        iHEnDCDSkj = tCPiJmMMFkuniv;
    }

    for (int HGlWvlphbKFCa = 1549287166; HGlWvlphbKFCa > 0; HGlWvlphbKFCa--) {
        vxZHPLVAEid /= vxZHPLVAEid;
        iHEnDCDSkj = tCPiJmMMFkuniv;
        LgrcJLuqsgte /= LgrcJLuqsgte;
    }
}

int BjjKbMpAhq::vYpuFpMeAV(string EJJaJgZgbCe, string xjkLw, string uMhoaw, int wLTiqJmJOBVTLTjb)
{
    string EINFVaTrJcYuwSUS = string("DjScxOCqUCLyQquQIAQXkdpHCrwlgQVlncZtYGLYksFMCmukmecofLSZNrsFrtWWZjohfVOKBsSxIPJFxApFhfBTTPJLsqGIIbkvfWIHkffUbxoyJYXufbRVpDaBmZOirOrzXGsGqEdqyaHpeSusOYPCAkoRDGrfXbXRCwSatPtwkqLsLLcxhlPTurcCLaHAXdYgoofitUkeyyJEcpyGqJGHMNDQOqyXAlYttvKxFfVNICgbRkLLXeQs");

    if (xjkLw >= string("TPDyJusECeiGYcSwATQewpCXASsGtCAddSCmBEuHkPHOiyptDdbJKpaXQoBRAAzUOoYqZGLLEhssekMJslceKMZEesPAsEEcSKqoqdgSmnUFaAnWrvUxIQizfXjVJpoJrYqVKgxEVQMYsSCyRUnTHyvEpdrCZZBewlatkzGOYNcsRTiumTVMKDJMtQrpGMsKQUBDVeOMXnTHdZgNZpSQzRQBHZscUdQQSoUUQeNIinheRLQbvLaWsiyFHw")) {
        for (int kveKpLxrE = 1164622118; kveKpLxrE > 0; kveKpLxrE--) {
            uMhoaw = EJJaJgZgbCe;
            EINFVaTrJcYuwSUS += EINFVaTrJcYuwSUS;
            EINFVaTrJcYuwSUS = xjkLw;
            xjkLw = EINFVaTrJcYuwSUS;
            EJJaJgZgbCe = uMhoaw;
            EJJaJgZgbCe += EINFVaTrJcYuwSUS;
            xjkLw += xjkLw;
            wLTiqJmJOBVTLTjb /= wLTiqJmJOBVTLTjb;
        }
    }

    for (int kXAFGLvdYMjgHMK = 1908365648; kXAFGLvdYMjgHMK > 0; kXAFGLvdYMjgHMK--) {
        EINFVaTrJcYuwSUS = xjkLw;
    }

    return wLTiqJmJOBVTLTjb;
}

int BjjKbMpAhq::PSEoc()
{
    double JxIcHJqVuFPZBbIx = 326959.36895632715;
    bool qONafsVfKquC = true;
    string aenbOmyWtD = string("ttZTIxPSfuBTQAGEiHBUnltedddXH");
    double wEtamnpo = -234384.89662409472;
    double ONShboHKYm = 104074.66652835444;
    bool zWKzNDoAEfLwVXO = false;
    double WqDqnOKURhASAyd = -323047.2223911284;
    int lCbHoa = 1040900813;
    bool efrrSbczgszGkq = true;

    for (int jZVcXedaPwbe = 1421739503; jZVcXedaPwbe > 0; jZVcXedaPwbe--) {
        ONShboHKYm *= WqDqnOKURhASAyd;
        wEtamnpo += ONShboHKYm;
    }

    return lCbHoa;
}

void BjjKbMpAhq::zCNvhypmvPIib()
{
    string gkBmZEFc = string("ySlYIXxxjREMGxWyzSPINZjseBouPDxKGmMtmuuGfaYeOpDBMEhUsxMPEGBflVXWPN");

    if (gkBmZEFc > string("ySlYIXxxjREMGxWyzSPINZjseBouPDxKGmMtmuuGfaYeOpDBMEhUsxMPEGBflVXWPN")) {
        for (int rJYvWAvuEYfPVa = 1565922242; rJYvWAvuEYfPVa > 0; rJYvWAvuEYfPVa--) {
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc = gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
        }
    }

    if (gkBmZEFc != string("ySlYIXxxjREMGxWyzSPINZjseBouPDxKGmMtmuuGfaYeOpDBMEhUsxMPEGBflVXWPN")) {
        for (int HssfFhxVz = 23474700; HssfFhxVz > 0; HssfFhxVz--) {
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc = gkBmZEFc;
            gkBmZEFc = gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
            gkBmZEFc = gkBmZEFc;
        }
    }

    if (gkBmZEFc != string("ySlYIXxxjREMGxWyzSPINZjseBouPDxKGmMtmuuGfaYeOpDBMEhUsxMPEGBflVXWPN")) {
        for (int jASpchIXD = 2091347249; jASpchIXD > 0; jASpchIXD--) {
            gkBmZEFc = gkBmZEFc;
            gkBmZEFc = gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
        }
    }

    if (gkBmZEFc != string("ySlYIXxxjREMGxWyzSPINZjseBouPDxKGmMtmuuGfaYeOpDBMEhUsxMPEGBflVXWPN")) {
        for (int jHxLyWQyb = 1094839702; jHxLyWQyb > 0; jHxLyWQyb--) {
            gkBmZEFc = gkBmZEFc;
            gkBmZEFc = gkBmZEFc;
            gkBmZEFc += gkBmZEFc;
        }
    }
}

int BjjKbMpAhq::UpxmoJHVtAK(bool oZNTJTFxrQ, int mOdsvMAACIwQitO, string LAYZkqlLLRV)
{
    double OxDcKUlJXGKdOte = -387582.85530702554;
    int MiFscHGUR = -489445304;
    string QZKaG = string("SSFcDiXLTXvAzrbYwMxQoRtPAygqxOVEzwcrMIURVkscTawhNjTlGivPvaazTZdeQccUIcnnmFAdZubobLXiaeefEmCnSWgB");

    for (int nMzSoVUkDQaxsY = 1292448461; nMzSoVUkDQaxsY > 0; nMzSoVUkDQaxsY--) {
        continue;
    }

    for (int MwyDsbozR = 1720812155; MwyDsbozR > 0; MwyDsbozR--) {
        continue;
    }

    if (LAYZkqlLLRV >= string("mxdCyeWEHhilgIEYWDMZZeOanMpElBSBQwHgmuYMVKKzSOwdburniJxnXhTOfZGIGgxlXDVgftirYybfAWeNhqs")) {
        for (int fyrKPb = 1384079681; fyrKPb > 0; fyrKPb--) {
            LAYZkqlLLRV = QZKaG;
            QZKaG = QZKaG;
        }
    }

    for (int RKKcxOEUQP = 421290637; RKKcxOEUQP > 0; RKKcxOEUQP--) {
        oZNTJTFxrQ = ! oZNTJTFxrQ;
        oZNTJTFxrQ = oZNTJTFxrQ;
    }

    return MiFscHGUR;
}

bool BjjKbMpAhq::sJAWzWDXyH(string EglqfIE, bool FaeSrTw)
{
    double XTZHq = 518619.71923673386;
    bool rISDv = false;
    int DyggUA = -554690760;
    bool HRPkyjGktnmsFtjs = false;
    bool gCiBCuYCwzzmr = false;
    bool dIFOBmyjFivq = true;
    string KqZTBn = string("kDWvVKufRFGGqBzcoIgwhppIEDdqxbnunsineyBGpQdhQDOtXoPIxtspXpQ");
    string urlcDmOWacpUebLC = string("qXFVWxlCpYqClfPOikuZILjffxfdekWqsroqwnZs");
    string oHMwOgDGKw = string("BmiPjaNvrdDqlwCnusViyIvTHwksCnDVGQWiGAbPMlcwDDfzOkBQWCDmIbskzianmdYovdxYVpABcoEdVJRadjkuUirPVEnImMPeMplWXmaYBoafQxHiusdeWIVJzWxZnrtbcKfXTcQJwFgtXLrMqfgQyHCqUPBXIkADzBurImHQGEMzZyzmy");
    bool srPxDhkqtKccBvkl = true;

    if (EglqfIE > string("qXFVWxlCpYqClfPOikuZILjffxfdekWqsroqwnZs")) {
        for (int rmhZNA = 354377105; rmhZNA > 0; rmhZNA--) {
            FaeSrTw = dIFOBmyjFivq;
        }
    }

    if (oHMwOgDGKw != string("qXFVWxlCpYqClfPOikuZILjffxfdekWqsroqwnZs")) {
        for (int gSkEKGFNYa = 1732328845; gSkEKGFNYa > 0; gSkEKGFNYa--) {
            urlcDmOWacpUebLC = urlcDmOWacpUebLC;
        }
    }

    return srPxDhkqtKccBvkl;
}

BjjKbMpAhq::BjjKbMpAhq()
{
    this->XRzPkO(1719081973, -632821.3656580766);
    this->bUZdNArRRr(-905345265, -154055.22197417697, 425656.67283980513);
    this->qirkFIEgwPszrFU(-1713827871, -468196.6715865068, -420152894, string("dwpXEdPXeqRofxmuxxXgvkxApoDwSTLrZpLZDtDKiIEgKOxwovzCrXqFxfmDq"), string("UwozUzxgZeHiAxpqSyRMWnyJdcmmUjhydsMzbOrXepggwGZpJftYIFRPdJoFYxcYPdXBoffIiuqLDctZuBknAJYJohEmUgvbiUwzIIofflEMOpKHkprwGTHqYorwrTNbCSxLwSNpvrVxwnyxuhMOYNHmLaOpGFKjwNjftlIEhBGuUVPiXgerunkreYOZRZVUlaAVmXgsQmJzTKBQrVeGpbOEFkqnjsDrcNneNssKcFghp"));
    this->REYnnbOSAsz(643283.7241708501, string("HoNZ"), 67273.29543902521);
    this->pOzTKZieHZBrj(-244380.714923359, 1619084334, string("vOMYfrgfALDjGUnHjMsuoeyhFdgkLhLRJgZDAsqVLRuRWjFRtYRaYKxuiLHvzmYxlLKiKyQRpSZcAdcORMeEfFsngiJqERUzAOOvXPWiubFGNuOeLweelryvTZzyPYmSjyBCSsgelRMEXGCAOPjBaKTKexlzVzZuMalnLKRWpAXkTQunoIbCCmoCGXrERsujNiVNNcAPBqZqahONtPwsWWvRDbWWoesk"));
    this->ukMyBYPT();
    this->WBQNrMEaM(string("eBLYntjvcrWHebtHrOvqOWZJZasQpewexdoqwQuJRsusnxkbWlBBfhcKyIyHpbWMsSfFlIissMhtyQVRMbyeAetjdPeTLKEZzHNCYIHhYSzdNhSbNOwlNrlDUOxSLneZqilqpBTleTXnHFkTsCfMjkmOiSNozKeclGGSLbsNcFMsnZBGufzrkjJkaPSUvudcFcOfBgsdHztBTKlUkSOxJcEtlEnNxVxTRkLWSxENzxCAc"), false, false, string("YhHZZCRCLrwIbkFQekAWqeGNEhJoSyXfgywWQjBxcjLlZpSvZrPDSZfLXhRmSjPfuQHlSbLjwZwtJNFPDKdmkExnkfaULBMWyBBwNRqlpkDFWcsuEeJGARcKpoQakHZfomxByuhwnkzbpxixzpbJjzhufOlWiISbLyDWgzdrKFWoVjAprhDIEjRCcdlFsnBOrWGuknXDsxaBWdVQaXikpMcV"), string("jimLgMsqaqdunOqdKXwCXeLmtvWAbNdDmaxWHSUXvbPFAuNXZsenboTvMsZaZPQNEuQnXBkBNBNyHxfvmvMoJDxWgIYxjGBAHormKgBZKBDEwdINvPIAVKFIEAklAZBJbAwbpXBueoWWZf"));
    this->CMsAieDOMG();
    this->vYpuFpMeAV(string("axRoFEPDRrvpYzIVlldfUlFCtRuaOtjPnkYaYkNHKlbxpPZeVizYDtXcbXoIqsCNZlzjESeoYjZpxSEwYFPalCDESrblEqBdCuhEGLvqSrtMzywXchMzhszfvGfEzxsUYBAOSyApFyzZIHDBafFmRBdffRNSwZuyqRFqQQjPkzqkYEAbRlrniYLxDzkRVVgVqDgJyRGnJfxUcqOtYjZyOzgoVoVisJpaIyTXvIhRkNcfmCPn"), string("TPDyJusECeiGYcSwATQewpCXASsGtCAddSCmBEuHkPHOiyptDdbJKpaXQoBRAAzUOoYqZGLLEhssekMJslceKMZEesPAsEEcSKqoqdgSmnUFaAnWrvUxIQizfXjVJpoJrYqVKgxEVQMYsSCyRUnTHyvEpdrCZZBewlatkzGOYNcsRTiumTVMKDJMtQrpGMsKQUBDVeOMXnTHdZgNZpSQzRQBHZscUdQQSoUUQeNIinheRLQbvLaWsiyFHw"), string("izmNaZgDQaANvJDAQysLASlNGKOPmTIogRPqDAWvvENTgiNeFfNCoaTWbpziltSIqywmhwQDoZUvLZVXLSufBIrvNgQSagEKnakCKhpyVxXSFsCvPVxfIrXAUIXPXSriwFWhQQdMpguMgQfXRe"), 1896856311);
    this->PSEoc();
    this->zCNvhypmvPIib();
    this->UpxmoJHVtAK(false, -1820050801, string("mxdCyeWEHhilgIEYWDMZZeOanMpElBSBQwHgmuYMVKKzSOwdburniJxnXhTOfZGIGgxlXDVgftirYybfAWeNhqs"));
    this->sJAWzWDXyH(string("LItsgyVAjtIoCclhrkInqsQQGeoGemLwbgrXcrShmAWFteMo"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mvqWd
{
public:
    bool IQKDPpvZAEdoIdNt;
    string IdFTKGuvOKNOw;
    double JFAUXAMXvZX;
    int FSzLxkVBTYJQJX;
    int rBBPcHAXhakhv;

    mvqWd();
    string DHtYXVyFswT();
    double TSXHGWlJQ();
protected:
    int eiMUSUa;
    bool RDOLlEfohVefkE;
    bool hMKTXArWLdzW;
    int rAgIaJDmCSoht;
    int JtHtBoBFPCLuzW;
    double CtHxQ;

    void KdTRx(double HXVbQmspGyJyJ, double GZnlFQAHKlJEwIPm, string ultbbIt);
    double BCyDRVU(bool uqkIFGcWJQHjpmMC);
    string MENbJAD(string lnaYbCJOlsEzlHG, string iIKBSpOQyHKmffq, bool ejWvS, int KIhdzCLLulpXvox);
    double ygrStJnwjDsYEQr(double ggoquOC, string cLLYKDaxAAIse, string eeoVoK, bool ieNCIkyN, double UudRIW);
    void sVIIBGzI(string FPibVVQAT, string GdrOP, string CKwJnL, string TuYJsIizwTUy, string gTgqYxfWoQrufLqN);
private:
    int MERJsoJxBuTlXrVu;

    int bekvU(string FvIclXHqo, int IcIYi);
    int cNztEBdprVFd(bool ADEJA, string EZwFMxo);
    void FLxbSuutcqzWbq(double wskzrHidHOLyXQn, double qbree, double zQfKlJmnqRYcbq);
    string aSwTfNLgbaIIL(string KQtPmGkuTcmiNNbr, int ePoNyMeco, string FSdSf);
    string eXKGLOh(int AAkhk, string nRHisaptE);
};

string mvqWd::DHtYXVyFswT()
{
    string dqbBvjFcYRhLUAy = string("wWnTRbSdJxANkozeKThhcmoFKtIVOkplDbMgFOBHYLGxmSRGjudABLBxcKGyMucmpxjaXDOeJKAumSzgctZbVqgfTnCxqrFUUarTtpqpCkrpJMZZVrNItWDwvsYxorCDfeLBkyoNeiIIieTaZWhEhfKiUfGFLEtGkItMiFWjlcjEXImBCdDUrkbASZZPNEajCZXezWgmdgsnHCeJimSDpwdbOOhSLuwKXNSeWhXkGKKskdmIyKRuES");
    int htwDQpZtinX = -1789649066;
    double aYYCHHIYEfpRDrXT = -394527.8047860799;
    int HUOZSXOlu = 1499087275;
    int AnVxvwFZTW = -870565434;
    string sfaBlV = string("CZGSobscduyJPSvKYqJllFmEQWlqYgWtCCHKibFAQoPUWBeZhEQhYrHHubnpwWwRCwTdmkFkFtreDQOtFIQBCxSqSQlauPMeEbiauugylmwcHtUubnycaAawGLiDrbmhGbsIVgQCUnaGcIMCSTsIKbJQTnUudlHAZdFPXoZuMksfuuhL");
    bool LhlfcIFZXaCJvNIn = true;
    bool DYeql = true;
    string erhrj = string("AoquXJVNHBxdQAfVHYKEzDcAFXnFaiRbceVeXaaAkdsaqhwfqoojYxLFsrxyhnGEGddEzuKjwBHsJAFvHJchQPuXEUAKBbsHtpmNyDaOSJLSTxNbPGnQGACLkBVSbNSHcmubfDjheicjHgShDFsLmgOsWnZbDZvYCLNPitcwRAxiGsKTFHPlgMgdgW");
    string xszySyE = string("WVdNctLzxPdykVjizrKbkuOMLEXaROafJMODjlKynRpskEjUERxZzTSWyCPAqDjaDzuNEhLdPoRmvxzEyQirYisbbikcxdqmDVkPQhUDvPwnoOVAEgPhHxvRUjZsUVmzcdWxXKtMRzIFDOCWMZLBCTTlVhKLfYqSzoPhmhRTDHEGHHGLBRUpYCrAoZLkdeInvuMgayi");

    for (int eRlJmVWRw = 289200980; eRlJmVWRw > 0; eRlJmVWRw--) {
        xszySyE += erhrj;
    }

    if (LhlfcIFZXaCJvNIn == true) {
        for (int WshEUz = 446112568; WshEUz > 0; WshEUz--) {
            continue;
        }
    }

    for (int cpIWPTVbWHcFRuR = 1158616938; cpIWPTVbWHcFRuR > 0; cpIWPTVbWHcFRuR--) {
        htwDQpZtinX += HUOZSXOlu;
        HUOZSXOlu += HUOZSXOlu;
        xszySyE += xszySyE;
    }

    return xszySyE;
}

double mvqWd::TSXHGWlJQ()
{
    bool KxjKWPEBRRw = false;
    int IJVqNRIzLa = -520002955;
    int ZWZwnCHRjWO = 1463646298;
    bool rNsWwHtfDeVn = true;
    int ljQZNrgHOvxfQs = -939843853;
    string lqAqvazRvVi = string("DGmyASJbnwakCthIuFFdpLibEKDywUFHUrVWiIxQQAmwsVioqmGCdJJFHAOZfNlZpQxFvvdlxmDmTcOwVHuskSajLLqJPTvWtlFPAHPPGpbnRdQKFuSBupdkT");

    for (int QwIpdprTp = 1720595007; QwIpdprTp > 0; QwIpdprTp--) {
        KxjKWPEBRRw = ! KxjKWPEBRRw;
    }

    for (int YTORp = 1516888830; YTORp > 0; YTORp--) {
        IJVqNRIzLa /= ljQZNrgHOvxfQs;
    }

    return 329459.65757975884;
}

void mvqWd::KdTRx(double HXVbQmspGyJyJ, double GZnlFQAHKlJEwIPm, string ultbbIt)
{
    int JCBPCPmVkvOjCv = 954892218;
    double jptkBHWPCkPY = 860742.5420934795;

    if (GZnlFQAHKlJEwIPm < 860742.5420934795) {
        for (int YNPtNxrfkqoG = 1271961074; YNPtNxrfkqoG > 0; YNPtNxrfkqoG--) {
            GZnlFQAHKlJEwIPm -= GZnlFQAHKlJEwIPm;
        }
    }
}

double mvqWd::BCyDRVU(bool uqkIFGcWJQHjpmMC)
{
    double OJkBXFVxTrPCHAwD = -960404.1489693711;
    string oevMzjziJijvjIwe = string("ddCDlXZfouAvKCJFaTZgipkxTNhcJqhRTvDdXJXaYFkWJTuORWxHgrKJJxhRBaYhHednDzXBxPzA");
    double fxYVFtetpy = 655689.8594674923;
    string hkshlNq = string("BBtGPwBW");

    if (OJkBXFVxTrPCHAwD < -960404.1489693711) {
        for (int JPFbNDWaZFfFS = 1320236523; JPFbNDWaZFfFS > 0; JPFbNDWaZFfFS--) {
            uqkIFGcWJQHjpmMC = uqkIFGcWJQHjpmMC;
        }
    }

    for (int wrYdQvrHmkxcuBlh = 1631903222; wrYdQvrHmkxcuBlh > 0; wrYdQvrHmkxcuBlh--) {
        hkshlNq = hkshlNq;
        hkshlNq = oevMzjziJijvjIwe;
        fxYVFtetpy += OJkBXFVxTrPCHAwD;
    }

    return fxYVFtetpy;
}

string mvqWd::MENbJAD(string lnaYbCJOlsEzlHG, string iIKBSpOQyHKmffq, bool ejWvS, int KIhdzCLLulpXvox)
{
    string ZtNFFXbNUvsi = string("CoVYrbcMScynMmiMgYIWVSxRMLhVVBc");
    string McOOXJIQrdxrodR = string("NcWDYwhewPPqurIXYrXzanksWtGejCWwVtzjOayhAIWfrBEmiwKFCDvhZmcJaRNUpLXiYeTuRUIphSQdTlMHaZBfaRCuiQdfNG");
    double kJRXXDrnYX = -751516.9955284247;
    string VZqnMIkkZ = string("RoAGRfsDJD");
    double LfCNkEYjOZq = -875085.7895650889;
    int NcANhTO = -815321411;
    string eZbysEyqBYKZH = string("ZyCpdJjoBDPyFxVInbjtWYDLvXYSpCfphefIEGTMehHpxyQKgBiiJbakEBhdZXKUNYorbZlshvJrCTdOenBdZJhnVKwVImvcsOWyUzAPxBStVXgbbhzAeSpQQkVTHpPWEFiCkvTnJl");

    return eZbysEyqBYKZH;
}

double mvqWd::ygrStJnwjDsYEQr(double ggoquOC, string cLLYKDaxAAIse, string eeoVoK, bool ieNCIkyN, double UudRIW)
{
    int oNwFSi = 923389445;
    string tLrJvefhJkXu = string("rqbZtYNrxZpSxMwViwEsCHMKKkVFZodmJPtVkWCucwTWoKuhcmPePdPhIi");
    string XxpPGlNiWi = string("sPtFmHCdXWMlVPqIgLyGIeoEwJkJLpoUQZTIPXRMrMoldYRqJHAcKpnaFqUwLNsiSDtVryOwwENenlDZWHPYdfQJVaFZQNPNOZmQfERUcyEoYPchqkQLERTEiqeLaX");
    int ZwMjaZPEZuQF = -1854335734;

    if (tLrJvefhJkXu != string("rqbZtYNrxZpSxMwViwEsCHMKKkVFZodmJPtVkWCucwTWoKuhcmPePdPhIi")) {
        for (int OYAmFP = 1308735073; OYAmFP > 0; OYAmFP--) {
            UudRIW -= UudRIW;
            eeoVoK += cLLYKDaxAAIse;
        }
    }

    if (eeoVoK == string("uxrEBYOJSoVndiTHjSGNTVMqoQTnmFGszBeWYmvUhjlzzQlZtQiBqnogdbRsaVJ")) {
        for (int xdRydwzgnPh = 66300552; xdRydwzgnPh > 0; xdRydwzgnPh--) {
            continue;
        }
    }

    if (ZwMjaZPEZuQF != 923389445) {
        for (int ynFcLCdsDWf = 1590433837; ynFcLCdsDWf > 0; ynFcLCdsDWf--) {
            continue;
        }
    }

    if (eeoVoK == string("uxrEBYOJSoVndiTHjSGNTVMqoQTnmFGszBeWYmvUhjlzzQlZtQiBqnogdbRsaVJ")) {
        for (int ESvMmDmsdbwKbP = 1806306999; ESvMmDmsdbwKbP > 0; ESvMmDmsdbwKbP--) {
            eeoVoK += tLrJvefhJkXu;
        }
    }

    return UudRIW;
}

void mvqWd::sVIIBGzI(string FPibVVQAT, string GdrOP, string CKwJnL, string TuYJsIizwTUy, string gTgqYxfWoQrufLqN)
{
    int AKmNwRLt = 1124070265;
    bool KBaqHabkclbxTad = false;
    bool BzwQfGO = true;
    string DKBMlm = string("lJfPleWwzECBcjxyeByHtuTJuRTiMYRrbRiOIcLGegLrllDZseyqZLrkyphhuoMPXDBgDuDMGUNNazmnOEpLLzRFzVzkenOjNbaVAPqjUFsKpOpHzzHVcTwuevKUyTwlPOZsOxKEoWuKNmZGRbvSjJ");
    string LcRKlygpwK = string("iCdtjLTfrcXwj");
    int WMamkFPH = -114189942;
    double FWvcCDRsB = -731420.6396913801;

    if (FPibVVQAT > string("ecrvJEbnvfJrRTbufNOzQfqrYiABMzuOPVbbtJrjyuJYDZhTgahNMPwbtojftqTndhGhuEDsHfHycJWSAPwgwiIIYuHhqginJnXznfPxXuGhJEGFuxQdIGsGLAQvNyOnzgxqeSRTaoFGbyWSxtmehdfnCddZXTLQSXqCiNBCSTUvDyEoSnNQx")) {
        for (int WAcybwyUxKyqrLFD = 35956625; WAcybwyUxKyqrLFD > 0; WAcybwyUxKyqrLFD--) {
            WMamkFPH *= AKmNwRLt;
            BzwQfGO = ! BzwQfGO;
            KBaqHabkclbxTad = ! KBaqHabkclbxTad;
            BzwQfGO = ! KBaqHabkclbxTad;
        }
    }

    if (WMamkFPH > 1124070265) {
        for (int LgDUyrqjFiYr = 336443446; LgDUyrqjFiYr > 0; LgDUyrqjFiYr--) {
            DKBMlm += GdrOP;
            KBaqHabkclbxTad = ! KBaqHabkclbxTad;
            GdrOP += DKBMlm;
            gTgqYxfWoQrufLqN += gTgqYxfWoQrufLqN;
            FWvcCDRsB = FWvcCDRsB;
            AKmNwRLt /= AKmNwRLt;
        }
    }

    for (int QeuxcpQNmUZ = 596613718; QeuxcpQNmUZ > 0; QeuxcpQNmUZ--) {
        CKwJnL = CKwJnL;
    }

    for (int NKbsGKhaQpAL = 1909400546; NKbsGKhaQpAL > 0; NKbsGKhaQpAL--) {
        DKBMlm = GdrOP;
    }
}

int mvqWd::bekvU(string FvIclXHqo, int IcIYi)
{
    int dGyAnw = 342638261;
    string HtnVAvrb = string("OZPUMGFKhkOnvNYtMUPGXfMvsOPJFXutNxxFhruzvqMGlMMxmXOweSpRiWaQXvXstrfFCcOFmusGkzKlGLedSHzAXdVkRXgDUrFhIGPTrqoFpwsVkqdhMlSFomHdlVckfPM");
    double cYdcfbWwQhSVr = -17946.72946077442;
    int wfSaAuo = -1606521051;
    double qdvHBCOayY = -224284.82318879408;
    bool oXxdyxmASQDey = true;
    int KfHtzzlKKdgCGf = 677035155;

    for (int wQANrvqahl = 1055462472; wQANrvqahl > 0; wQANrvqahl--) {
        HtnVAvrb += HtnVAvrb;
    }

    for (int wamytztiDcKT = 1235649453; wamytztiDcKT > 0; wamytztiDcKT--) {
        FvIclXHqo = FvIclXHqo;
    }

    for (int MhzwTxhCjOmNVLSj = 1165363188; MhzwTxhCjOmNVLSj > 0; MhzwTxhCjOmNVLSj--) {
        dGyAnw += dGyAnw;
    }

    if (FvIclXHqo <= string("OZPUMGFKhkOnvNYtMUPGXfMvsOPJFXutNxxFhruzvqMGlMMxmXOweSpRiWaQXvXstrfFCcOFmusGkzKlGLedSHzAXdVkRXgDUrFhIGPTrqoFpwsVkqdhMlSFomHdlVckfPM")) {
        for (int JHLACTLrQo = 1901318885; JHLACTLrQo > 0; JHLACTLrQo--) {
            HtnVAvrb += HtnVAvrb;
            qdvHBCOayY += cYdcfbWwQhSVr;
            KfHtzzlKKdgCGf *= KfHtzzlKKdgCGf;
            IcIYi /= dGyAnw;
        }
    }

    if (HtnVAvrb != string("tjjwRoVfqSiDgjMLfGwcPdcsKXMVVqdyoMsudLEVnzXrPkKTyoOldWmmZEMveXOLgzooZLtJTCHpPDOGaMVMxIabWMZqWTZXsWeMqUXHUSKNhhPZXqkhTXBExrYxfEyMCioMjHEbXuwALTAWcrgHUNFiKshasFzIEKWviGqBKDGnvU")) {
        for (int reWWjetupXdrmi = 1858405030; reWWjetupXdrmi > 0; reWWjetupXdrmi--) {
            continue;
        }
    }

    return KfHtzzlKKdgCGf;
}

int mvqWd::cNztEBdprVFd(bool ADEJA, string EZwFMxo)
{
    int JwvyWgsBgdyRowN = -993083360;
    bool uxxLTErcY = true;
    int lCeJouVpSL = -1033865441;
    bool sxEfh = false;
    double gZCAkXmsxncP = 102325.57115763862;
    string gtNSoYJ = string("POMHHyZkxMlkRlRUtJGKModhWGOztoYaNVZtEwebzvAJehbLlNYMidvBoxFhLSmpugIWfuhhlqqJHTwtPcNeYdPEnRAZlTIkDZvepNigAVwlvsZQVwShOTJYozWEHHTtRLTfJDSFaNTbXveWaiwPIcWyOBSfOsBFdyfQniWeYnSzvJqhVoPpcorCBZRauLHkFOKRuKutPvFKwkMKYVCmWPSEnNSwhHgvKKRRZ");
    double YWlopNaSokIj = -682951.4422714789;
    bool OscNaXf = true;
    bool uvWgdhJ = true;
    bool sInzoI = true;

    if (uxxLTErcY == true) {
        for (int IORxZJuKFg = 1218623978; IORxZJuKFg > 0; IORxZJuKFg--) {
            EZwFMxo += gtNSoYJ;
            JwvyWgsBgdyRowN *= lCeJouVpSL;
            OscNaXf = ! OscNaXf;
        }
    }

    for (int cfLMznweMSPklJ = 1627466885; cfLMznweMSPklJ > 0; cfLMznweMSPklJ--) {
        gtNSoYJ = EZwFMxo;
        sInzoI = ADEJA;
    }

    for (int JtFuUnVlxSLR = 1069652444; JtFuUnVlxSLR > 0; JtFuUnVlxSLR--) {
        sxEfh = uxxLTErcY;
        lCeJouVpSL = lCeJouVpSL;
        uvWgdhJ = ! OscNaXf;
    }

    return lCeJouVpSL;
}

void mvqWd::FLxbSuutcqzWbq(double wskzrHidHOLyXQn, double qbree, double zQfKlJmnqRYcbq)
{
    string njIcymot = string("XJeKjSiyLPFMAEPGrYArNoTtENbBmJwMbSJBFTISfwkClzFutAltFyNLIAEWwxWVuAAjdkqVLOoVHzXojssRzfTdNTabXPSfWwwjDGJIIcdHBqNRvGljkNwDWTDZdDGAsoOXPEHIzqPzQhZZhJMlRBPVvaUscwXqXaFGtoHagSLTtmgzolz");
    int bGxPQPanDPidrC = 288695886;
    int oneQpWjQoUUA = 987324199;
    string wsSRCYIvaomrr = string("ljCwrYCrVyUANwIkHtiLunbRditQgvYvVsrbSlozbKoMQXwuIMJkzZeiewkrbgZgnOvHXGVFfxaLcdLshLftooqaaWyXWMLZeZzqbWiviFwZeQAegLgkQMyIcXxBQblDPWlnOMlyOYgSgnKYyftsEGyYkQNwrEQddmPWxKTYkMTfUZEJbNBJvuLNsyNHypyYeqdabjiHkF");
    bool PYnCyStLJVT = true;
    double HzlamErnukF = -486358.175656297;
    bool JzaPXcWUKXk = false;
    string oJNND = string("q");

    for (int UhUtKSeG = 191808634; UhUtKSeG > 0; UhUtKSeG--) {
        HzlamErnukF = zQfKlJmnqRYcbq;
        oJNND += oJNND;
        oJNND += njIcymot;
    }

    for (int gZKHwLXBowiQ = 1040291279; gZKHwLXBowiQ > 0; gZKHwLXBowiQ--) {
        continue;
    }

    for (int pUUut = 765888469; pUUut > 0; pUUut--) {
        continue;
    }

    for (int ameGlbQzmrUl = 545496484; ameGlbQzmrUl > 0; ameGlbQzmrUl--) {
        continue;
    }
}

string mvqWd::aSwTfNLgbaIIL(string KQtPmGkuTcmiNNbr, int ePoNyMeco, string FSdSf)
{
    bool PxKuXCBSJoMsbrSf = false;

    if (ePoNyMeco < 1632614585) {
        for (int CLYKCuLKzHHUd = 2009971745; CLYKCuLKzHHUd > 0; CLYKCuLKzHHUd--) {
            ePoNyMeco /= ePoNyMeco;
            FSdSf = FSdSf;
            FSdSf = FSdSf;
            PxKuXCBSJoMsbrSf = PxKuXCBSJoMsbrSf;
        }
    }

    for (int kpvRdWEnnpht = 581350955; kpvRdWEnnpht > 0; kpvRdWEnnpht--) {
        KQtPmGkuTcmiNNbr += FSdSf;
        ePoNyMeco *= ePoNyMeco;
        FSdSf += FSdSf;
        PxKuXCBSJoMsbrSf = PxKuXCBSJoMsbrSf;
    }

    return FSdSf;
}

string mvqWd::eXKGLOh(int AAkhk, string nRHisaptE)
{
    bool lRRuguKPTC = false;
    string HyVzOBJihQZU = string("KOwixSjwOCkAtXTsnabFEWskEcvmeBTqMLVntzaPkXVPpQnSCpRtwgILUpQOAFzRSulwQEhYHHfPHGWOEZtZonauVDVXVWCvlXvA");
    double iOTIOKwtNXXNgG = -1031996.4475960188;
    bool Ihtjx = false;
    bool GsVhsSleayynbQr = true;
    string OKZJQGEOxjF = string("iwCjzDkqMFiSLUoGxxGwRkTYFzDHZRoQuXoASHUmYxKUqKhRoSBaLxBbNscisprqjPlMNAKimynSOChCbMTkVbBSVXwAbHkamqnLqPZJzacjuvZSfoAjOyHwZvNSKMefMpRBwqZRCyxZBusxDX");
    bool DTFQlojMpcmFOfki = true;
    double ASJtsldlumIqdSEY = -675280.6488404291;
    double vZXjNTkSuNXv = -14993.343847879298;
    int qNIujDxfkC = 2026568357;

    for (int ytFTYS = 1237961187; ytFTYS > 0; ytFTYS--) {
        vZXjNTkSuNXv = vZXjNTkSuNXv;
        vZXjNTkSuNXv /= iOTIOKwtNXXNgG;
        vZXjNTkSuNXv += iOTIOKwtNXXNgG;
        ASJtsldlumIqdSEY /= iOTIOKwtNXXNgG;
        DTFQlojMpcmFOfki = ! DTFQlojMpcmFOfki;
    }

    for (int NgWPhBVF = 863964262; NgWPhBVF > 0; NgWPhBVF--) {
        GsVhsSleayynbQr = lRRuguKPTC;
    }

    for (int yCnkZWrWWRIjkJ = 802369307; yCnkZWrWWRIjkJ > 0; yCnkZWrWWRIjkJ--) {
        qNIujDxfkC -= qNIujDxfkC;
        OKZJQGEOxjF = HyVzOBJihQZU;
    }

    return OKZJQGEOxjF;
}

mvqWd::mvqWd()
{
    this->DHtYXVyFswT();
    this->TSXHGWlJQ();
    this->KdTRx(647596.5475265328, -54715.820176949564, string("OzeuATxsyECHbAEMAHnfVcNETxPqvZXXxMYssCsGNkWDdEKaSUHvBSJWCxdIcVQDlganEfccffNRgNWkNhXADTmMhBM"));
    this->BCyDRVU(false);
    this->MENbJAD(string("BCUYXNImCjvZzJyRAxWaybyQhueewGdyTtAsDMelPwewAfICbJFlJYWwqeKvzZtBacZQUrNOEsGehslvpljYisMVEAULqFjGrYYzAVeGnPlGBhqjKOwVxMnvXEpBNQpiqlvgStDtLGslUPcBgsJcsSzarOqvuoPBwYGmBzoacrytRiPreNaDc"), string("TRAKxn"), true, -1501610188);
    this->ygrStJnwjDsYEQr(-728587.1245692233, string("FFXpKCGXRuWtTEByWcECYlDpLvNTN"), string("uxrEBYOJSoVndiTHjSGNTVMqoQTnmFGszBeWYmvUhjlzzQlZtQiBqnogdbRsaVJ"), true, -390671.69574265106);
    this->sVIIBGzI(string("yTPyuNpOesJfneBYLwmJVtjyNBBjIHvCXMdbpWosAkvxEIVwmcvnJkmPeiQwCIHIELmBQzVebrcUoAElQqaluPKsTLdnqmKauPKuBkaTBHdHwWSLpnxmmAHeFSPvqJnkjQcIyBNfOhnPmkxqXsqovXycBckNHgfDeqtWaAeNluFCranTY"), string("ecrvJEbnvfJrRTbufNOzQfqrYiABMzuOPVbbtJrjyuJYDZhTgahNMPwbtojftqTndhGhuEDsHfHycJWSAPwgwiIIYuHhqginJnXznfPxXuGhJEGFuxQdIGsGLAQvNyOnzgxqeSRTaoFGbyWSxtmehdfnCddZXTLQSXqCiNBCSTUvDyEoSnNQx"), string("nWwncubPIryVZcbSzIGmOPVaWkHLoxqRVvrpHWOLPsnpPSGkRlKKhsRjqcaAzuoMkHrAREKINBsxWvEZlOuxWCTbmmDFLyJhXVXAPglLHBwXiZqnsPJwRXNzxBHMRrBDZlZRXnhbRdnTjJGtxOtILVCPNEiuIbvewjPNyKwbXKDXAeCTpfupGnPWaLNSXOSgvsDOqjdEaSenIdU"), string("PBxKLPZDIsxkPPfmJuvtJoLUPzddbzGOoofftnLZyYECqwFXySWCXGiRhwsxGKiCRVUnmiYrGjeLILESbzeDTpoT"), string("NTOIvBOXAspzZhkOFwrxLsYPysRPzBnsIkuElWrtVtbTMngHqmVVEuIKebCfuBUQkKhVkGcopuHqQTMHwKodkDJPQLLTGNZwjbzLHUHgPSpzCfPmLQbglzzyTGuWxiAgRbkCjspjdWEJsOcDdPOyriabX"));
    this->bekvU(string("tjjwRoVfqSiDgjMLfGwcPdcsKXMVVqdyoMsudLEVnzXrPkKTyoOldWmmZEMveXOLgzooZLtJTCHpPDOGaMVMxIabWMZqWTZXsWeMqUXHUSKNhhPZXqkhTXBExrYxfEyMCioMjHEbXuwALTAWcrgHUNFiKshasFzIEKWviGqBKDGnvU"), 1851651268);
    this->cNztEBdprVFd(false, string("CQeuPRQBVIwDKwmApBGodwFOBwYgIkTICkziwlnUKuZBhDbKYnRfsaPKsasHcxejDyrziGJqwTyYCVdkwYZJaXBPnVMlZZnXZUjAVZMgBvbypGlHuNsxeucKvLXGBgciqugBnXrbFLktPkhwQgLhJedaPdWJpYXWuMnyytwLYrtcHXrSEcZwrNZQRdMcCwQVCUriAlhr"));
    this->FLxbSuutcqzWbq(-1000375.4864601231, 126503.75705372338, 16510.054799514048);
    this->aSwTfNLgbaIIL(string("ssacjnuQFYdgsKsCGqrZmOLGoka"), 1632614585, string("vZkxpqkKHzWwhrwthVYsLOLOIbsYatNcKPmxtQlbmJUaIolPUyvBhRhArCOSHwJgmqWoZTLNHeULrsobCYWhIzrQtMCrvxeJQDvzgzQuGnnwaTltbvozfpvSrFMCDLzUDbquqTZHyagdzlNVmFVUwGctPfXqRMCtkzMWyEiLcKw"));
    this->eXKGLOh(-501250227, string("YEjVLIefXIGGNowIYOiGkLKNFiJCEhhCPZmTFbNzfDZpDiwhcFNoffYhkniqMjlwfxPTTfvrPczMfBatEvLApTGVVnCSusTeiBYOHgatfqurqsAUxfcyRLtvQYMNvHpLijOetbxaEibZhQzwwnLhpuuWclJspIOOJsgcpjdeEzcAwgJJibPgSJiHuNJZaKcnPqehiakAeGEeuOXToibPTzgYNEJRkkCrKV"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nBxejzB
{
public:
    string wvjaIAmUK;
    double nOETVcXUjIX;
    int ReGFKqhaDuwUhVB;
    double SpjNFeAyPKZr;
    double bMLGWo;

    nBxejzB();
    void ZPGnnLWnNiJOP(int IBhNfUGvOug, bool xdWScdRD, double BjylilMZChuWfG, bool VXoaCRBW);
    double XgpmL(double CRkwFHtkocyr, bool XKwmbIRZCCeVwc, int EYpmjiU, bool XSASpEHs, string pJkbqXd);
protected:
    bool pJlRVjuzUYxjVQjR;
    string eJexGpPKLJ;
    double qcTfbzpupV;
    double LnEfqV;
    string FUEUb;

    int tUaloGv(int rhpqDVErvEvbnMYP);
    string nawZhHqiu();
    int yTdPDrM(double OIFptJtuanGNdvV, bool paJqvRX, bool jJimaGxGv, int SqfUU, bool scGRJaIX);
    string oqTYQbOsmH(string TNfzbvnEbvw, bool fbrBuFisuK, string nRDfrnLFehMqiAh, string BGCwskgRHT, double kgZmNHWFB);
    bool tQSFzQFVNgpjJQuC(double XrMvdLDxQ, string pXxgxJ);
    bool GkawZVMa(string wzwREbxVOXE, string tzBAgZ, bool ZCkaalpBdTjyV);
private:
    int icbXIR;
    int SyRxuuFojx;

    bool smplndjpoZoeiS(int QyKfZysprosSXPdz, bool jEzvOBrrpbUHhtv, int iqlZSYCUq, double ltzlFJHTuOVEGd);
    string OZogcc(int VHQSUiLKfhin, string piDbx);
    string pWwSd(int UzAgwcvFfDj, string cSQru);
    void vGEJifR(string NICaFEneFMyn);
    double SLlPhTc(string iIohcedXmuhCLucw);
};

void nBxejzB::ZPGnnLWnNiJOP(int IBhNfUGvOug, bool xdWScdRD, double BjylilMZChuWfG, bool VXoaCRBW)
{
    int fQWgNlPVHvkxXfgM = -930594395;
    double shIMYwIfUPFf = -508649.0404376013;
    int oEubiurvcCwSE = 645945016;

    if (VXoaCRBW == false) {
        for (int IKqZtvkf = 1956300196; IKqZtvkf > 0; IKqZtvkf--) {
            oEubiurvcCwSE *= fQWgNlPVHvkxXfgM;
            fQWgNlPVHvkxXfgM *= oEubiurvcCwSE;
            xdWScdRD = ! VXoaCRBW;
        }
    }

    for (int cyfxDIGYQlqE = 1806903481; cyfxDIGYQlqE > 0; cyfxDIGYQlqE--) {
        VXoaCRBW = ! xdWScdRD;
        oEubiurvcCwSE -= oEubiurvcCwSE;
        fQWgNlPVHvkxXfgM -= oEubiurvcCwSE;
    }

    for (int NXzyL = 1012001358; NXzyL > 0; NXzyL--) {
        oEubiurvcCwSE /= oEubiurvcCwSE;
    }
}

double nBxejzB::XgpmL(double CRkwFHtkocyr, bool XKwmbIRZCCeVwc, int EYpmjiU, bool XSASpEHs, string pJkbqXd)
{
    int giJejUXeoxDx = -1480175888;
    bool QsDCAETuqB = false;
    double ZQFNkztbg = -961397.4823120805;
    int FpjCyitmWbeyHM = 1317093383;
    double Bclgsj = -565603.4583189101;
    bool mhIoLIaLV = false;

    if (giJejUXeoxDx == 1317093383) {
        for (int GuhBAO = 1212713292; GuhBAO > 0; GuhBAO--) {
            mhIoLIaLV = ! XSASpEHs;
        }
    }

    for (int YsDtyyquO = 1801670148; YsDtyyquO > 0; YsDtyyquO--) {
        XKwmbIRZCCeVwc = XSASpEHs;
    }

    return Bclgsj;
}

int nBxejzB::tUaloGv(int rhpqDVErvEvbnMYP)
{
    string NVFIOTuAgmHSUjJE = string("npITgpVjgSFHsXHqpdKKnfsVjlCiLMWsDTjLXoJhFPgWVxTPvMOjzefDcDTEGSCWaWMGhEyARLhKnPXbPSwlpUsWffwuLdnKbliDKmqWXIirKleQiEgRkJJMVYHONOAxpvAeFycdEtGYqbSYciQhbkQMnEQyKPdIUptLLAVw");
    int VfNowPtuoHCtvSZ = 287029936;
    string ysjAfwzBb = string("JgwhoorFmzUHNieuvzKUARxMupJBwcogqHTDeaOvTVFFbDtwBNvCYwRlwBejebtLpHEWNGQWdt");
    int bBgpkKcnCZ = 1255251397;

    return bBgpkKcnCZ;
}

string nBxejzB::nawZhHqiu()
{
    double EzCuUY = 23733.324403748247;
    bool TctONIrVm = true;
    int FATFqiZWXdYqgRLO = -1499992022;

    for (int ispDjUlo = 633577328; ispDjUlo > 0; ispDjUlo--) {
        continue;
    }

    for (int rEktCCUbnHo = 1831530092; rEktCCUbnHo > 0; rEktCCUbnHo--) {
        EzCuUY -= EzCuUY;
        EzCuUY = EzCuUY;
        EzCuUY += EzCuUY;
        FATFqiZWXdYqgRLO *= FATFqiZWXdYqgRLO;
        TctONIrVm = ! TctONIrVm;
    }

    return string("lNxOiMstnKkLbhfXtbmlMOoJzHWRLpzFVFgFtZTcXIpqazKtAOtKleuwxqClVdeFgwaWSJTBlkfeyvCuwAaMevYMXsuVcUCJGxTgmSyuQOPXxBONJnzoUUMtprneyWVKrQKbo");
}

int nBxejzB::yTdPDrM(double OIFptJtuanGNdvV, bool paJqvRX, bool jJimaGxGv, int SqfUU, bool scGRJaIX)
{
    bool DpHwnQWeGl = false;
    double KWzmibTDITQ = -512244.20017361763;
    string qoNtW = string("aQYSRbYOwoaeoSaPWeteLZEWDpoiisIWEowNtLODRniVyjlxtKLIMUXzcnsTyNsxjPXNEHFyggMDWItfHRAhwpdHTYZXtppgBTxGLZyIDgwvYXkBxDqsXhJvbBbYlhGoBtzLfmAIjahjfAEgMbTEEHIzoaBqINcBjCpeZhlMpzcYbJQWwPTqDRXtsyjhfGYltqgzyRFKxgbuTgjuzNAYSOLt");
    double UZPrVvcqbXYHoA = 793843.0626966753;
    double jNbWqywHRPuC = 976075.5712363683;
    string gLNttykryrAVXBKw = string("gQhaOVyizHPrIcShxKLeFJDcdqkKzXzyMLkaEPkUTJWnXdjGhHWaXgmuVXQvcZURjeWeTrJJP");
    bool ioNeWxMUQSPuNK = true;

    if (OIFptJtuanGNdvV != 542316.2004571425) {
        for (int XxLQQrlO = 1089383139; XxLQQrlO > 0; XxLQQrlO--) {
            continue;
        }
    }

    for (int xSggqyNsZUbXY = 323296428; xSggqyNsZUbXY > 0; xSggqyNsZUbXY--) {
        qoNtW = gLNttykryrAVXBKw;
    }

    if (scGRJaIX != true) {
        for (int bMPClns = 1137340813; bMPClns > 0; bMPClns--) {
            UZPrVvcqbXYHoA /= OIFptJtuanGNdvV;
        }
    }

    for (int DjFubOCzF = 368176459; DjFubOCzF > 0; DjFubOCzF--) {
        scGRJaIX = ioNeWxMUQSPuNK;
    }

    if (SqfUU > 1731087215) {
        for (int pIOTVBH = 1808676448; pIOTVBH > 0; pIOTVBH--) {
            continue;
        }
    }

    for (int ohleMJyHV = 1282688818; ohleMJyHV > 0; ohleMJyHV--) {
        continue;
    }

    return SqfUU;
}

string nBxejzB::oqTYQbOsmH(string TNfzbvnEbvw, bool fbrBuFisuK, string nRDfrnLFehMqiAh, string BGCwskgRHT, double kgZmNHWFB)
{
    double nasutGfhyDbARNQJ = -906336.2382248911;
    string aHHTi = string("jXNAuhLrCLKcbaPcYkKADgnwVVfptggynf");
    bool xRKvY = false;
    bool LwsxoyEqTj = true;
    string rfXpVo = string("nAGeWoeuEwpzTDQCFVgMJLIazSgkUUDurZDpCnMZBlFsJOsPUyuIGieyGZLMgcGvdQAZGUJHBeoBMwpSgxitbxvjYizqhrsAVwNrLLmzUugneQtqqLyULAyxMTtYXVghvvghvUBGDVpgLiNzUYtTWKEWzbrkBzsppRewVKSkJLUxQw");
    string YzzpBWgKww = string("OUkoxrQEMpgebYIeafZOTbqeFVQAAZVqSjBozSdiFlSWSJnlrAxsspIEBSkCpNBizxiapXFjJYQVoojpCOVdnZrbIyEalwSRyAfFxzsoPUjttswQRJMRAQLYtlUfbaLymAjMgvimDZNViAwofLsKxUccUdhDKYIQOIkRFntQRtlIfDxuvbewOruANUDTOcRspZVoKFPepbsTZCmnDUZeOqsTKfWVqTzIJhc");

    for (int RyUUaboOAio = 471265107; RyUUaboOAio > 0; RyUUaboOAio--) {
        xRKvY = ! xRKvY;
    }

    for (int LoMAg = 2041761183; LoMAg > 0; LoMAg--) {
        BGCwskgRHT += nRDfrnLFehMqiAh;
        kgZmNHWFB = nasutGfhyDbARNQJ;
        YzzpBWgKww = YzzpBWgKww;
    }

    if (xRKvY != false) {
        for (int dLoZbRXnoOY = 678689647; dLoZbRXnoOY > 0; dLoZbRXnoOY--) {
            nasutGfhyDbARNQJ /= kgZmNHWFB;
            rfXpVo += BGCwskgRHT;
            nRDfrnLFehMqiAh += rfXpVo;
        }
    }

    if (BGCwskgRHT <= string("nAGeWoeuEwpzTDQCFVgMJLIazSgkUUDurZDpCnMZBlFsJOsPUyuIGieyGZLMgcGvdQAZGUJHBeoBMwpSgxitbxvjYizqhrsAVwNrLLmzUugneQtqqLyULAyxMTtYXVghvvghvUBGDVpgLiNzUYtTWKEWzbrkBzsppRewVKSkJLUxQw")) {
        for (int hmRSUOTHb = 142299808; hmRSUOTHb > 0; hmRSUOTHb--) {
            continue;
        }
    }

    return YzzpBWgKww;
}

bool nBxejzB::tQSFzQFVNgpjJQuC(double XrMvdLDxQ, string pXxgxJ)
{
    bool OJKcodiFFlEgjg = false;
    int ADJlTCq = -261668594;
    double TaZSpKIOQBQdMlmM = -407075.66657969216;
    string zbvfSVJ = string("lBjnECHGhcymZzhxsajhkMIWnYXcnJvvssoCNCGGGMThHisUbZCfdQTItCikBjWtZnlRkETgoTouankSMICZWqiHbkwELVhCiZWTDMlcPSlijuozPFVbQWmgrckCwTgRoEtAyxMVkAXYrBLX");
    string paiLmNLIVmdPAaM = string("WsZBkCdfzgyWCYIwvhFFTHTAAzCSmrbypzzCvrrnrFXuejrgvvrHXiGnvcWbOLbWEEyFATKyAjzvMnZwHuBYHPCIzheSsNaVRgakkfFcWjiUhlrfxTwuAiRkc");
    string FTSPK = string("bsGMsYwYSTeVdZtDQETwkrPNgOFBCPbsZlMPkKHipCmAlVlFQXgbraNLpPXerePAduLqfxBhaTTiRuqTFaB");
    bool otrTqV = false;

    for (int PtVJiRKRsRUzzsWh = 2063483170; PtVJiRKRsRUzzsWh > 0; PtVJiRKRsRUzzsWh--) {
        continue;
    }

    return otrTqV;
}

bool nBxejzB::GkawZVMa(string wzwREbxVOXE, string tzBAgZ, bool ZCkaalpBdTjyV)
{
    bool bZXgdYjq = true;
    string cXpszUIjEvaEn = string("DwovVyzuyYylkiWKGdftlmyEwHBuRhwSyUmfxGFxrAWNkTfbNhloAPNQeEaElLsEeCqRjwDiEKXGNUoYnpYfNEUDwIYbbeuPByBavBktUWRQfRPPfqZnJFCrgAWQf");
    int JzViJBBa = 2108615347;
    bool npZFkbMDp = false;
    double QtAcYq = -27089.925964121227;

    if (bZXgdYjq != false) {
        for (int uuEoo = 565797946; uuEoo > 0; uuEoo--) {
            wzwREbxVOXE += tzBAgZ;
        }
    }

    for (int cIDbVVQSEvqD = 852158815; cIDbVVQSEvqD > 0; cIDbVVQSEvqD--) {
        cXpszUIjEvaEn += wzwREbxVOXE;
    }

    return npZFkbMDp;
}

bool nBxejzB::smplndjpoZoeiS(int QyKfZysprosSXPdz, bool jEzvOBrrpbUHhtv, int iqlZSYCUq, double ltzlFJHTuOVEGd)
{
    double hKemcrkYIJEe = -582692.3478971062;
    double KzZprvRLn = -66114.64287851285;
    int WxPewbIvAv = -492885845;
    int CNMpSV = -449733720;

    for (int lNCVunvpwK = 1524899351; lNCVunvpwK > 0; lNCVunvpwK--) {
        iqlZSYCUq -= QyKfZysprosSXPdz;
    }

    return jEzvOBrrpbUHhtv;
}

string nBxejzB::OZogcc(int VHQSUiLKfhin, string piDbx)
{
    int DWbpyznKBGGwQWgm = 1317168511;
    int GZuxlVmbs = 388989839;
    bool mRiKnmDOnEcbQiG = false;

    if (DWbpyznKBGGwQWgm > 1317168511) {
        for (int TrGOyz = 550066111; TrGOyz > 0; TrGOyz--) {
            DWbpyznKBGGwQWgm *= VHQSUiLKfhin;
            VHQSUiLKfhin /= DWbpyznKBGGwQWgm;
            DWbpyznKBGGwQWgm -= DWbpyznKBGGwQWgm;
            mRiKnmDOnEcbQiG = mRiKnmDOnEcbQiG;
            VHQSUiLKfhin -= GZuxlVmbs;
            GZuxlVmbs -= DWbpyznKBGGwQWgm;
        }
    }

    for (int yjBZtpORSQR = 51434018; yjBZtpORSQR > 0; yjBZtpORSQR--) {
        GZuxlVmbs += VHQSUiLKfhin;
        VHQSUiLKfhin /= GZuxlVmbs;
        DWbpyznKBGGwQWgm *= VHQSUiLKfhin;
        GZuxlVmbs -= GZuxlVmbs;
        mRiKnmDOnEcbQiG = mRiKnmDOnEcbQiG;
    }

    if (VHQSUiLKfhin > 947306778) {
        for (int BMqMup = 770490710; BMqMup > 0; BMqMup--) {
            DWbpyznKBGGwQWgm /= VHQSUiLKfhin;
        }
    }

    return piDbx;
}

string nBxejzB::pWwSd(int UzAgwcvFfDj, string cSQru)
{
    double supEACfsptQO = 646544.27778533;
    bool QhymCqPe = true;
    string zEqSzfimCB = string("nNiNscXufjDOdHAYjMuwTRrACwZcIGXzBrTePuPdZNNahczxElfBJzuQDZBabhghsnNTqiqvEutBhBmoillPdcdHcuFjSNxvQOOzeTsbfvFKPpKzOvgNVAoH");
    int BcEPhDnjFl = -495694376;

    for (int jvMwPfmnJEMh = 150886731; jvMwPfmnJEMh > 0; jvMwPfmnJEMh--) {
        continue;
    }

    return zEqSzfimCB;
}

void nBxejzB::vGEJifR(string NICaFEneFMyn)
{
    string dfjXXDR = string("eunDjdWDtwwetwpJtNNwWapRavmvUgtcAoGZnXVQAKkozEdFNpNvEYpaZEltCCGBEVxdoHSiRxBYBpkhJTIyMSxRJOADZpsiqGOSqTLnyCyzXIUMEvRAEKeZZepNKTPyZBsaiEwqWWPBthDIWuubZofPDQaAnSIvnPBchJRWKKKWKjYVHQHQVJEBoRyiFJQSuDQuPTTcAORlgpyQGfUzURXyfgvrpnjeKvBateNrHi");
    double RaZSKv = -536486.4170018858;
    string UkPXANOnsa = string("ZkxyRsCHvIjtgfIqjmKddaPjMtTKabobyxtXdPOmjeziMOrPaCRpsFbBOoJuNMacFzKImgkQpiIisOdhBuoqchfzgvtemUtITLpzuRwpvHyKhYuqZzuGgOtbmuiZwHIhVgQuNniytVXdsXNoAyKTUrCgEPGKQlQgclRrGMhEUrTrPTysxyw");
    bool dTIWnfk = false;
    int cFarjNwM = -865695849;
    double uDEchKfCibpEzwt = 278200.7891246745;
    string yolefcld = string("OaUKZnCuajuZaClVqGzGNbTfQzeBEczzXGDvSyhaZmLnWCyFWHgVYIJYtcNnYuUgXAbumVVKLnkxSbOeaHLrYBKwXpDeOLHxTiqFfbmzzDVcobupEMCoEduDxQMFqRlmdtCpoxJFTztCYMaihQfbvbBLGoHTClyZhMUfxfrMETJPvwnjpvETpxmCgxruqt");
    int kVswid = -1606661363;
    bool ctcBngdxXxlYXb = true;
    string ydSTbQhFIuy = string("NAXhgKlLbEMXzryORqxmabXVZcxwNISwsuzZmFdEWsOyDHXFTHHPufpTVvYzPfYtmcjtzRCKipvfbUrIROCLgbRuDRzHXFaqXKqIKWEWbcdLOXQnLHokEmvowJEdzMqcKQqDj");

    for (int tliTOnSEsSz = 1833102898; tliTOnSEsSz > 0; tliTOnSEsSz--) {
        UkPXANOnsa += NICaFEneFMyn;
        ydSTbQhFIuy += yolefcld;
        cFarjNwM /= cFarjNwM;
        cFarjNwM = cFarjNwM;
    }
}

double nBxejzB::SLlPhTc(string iIohcedXmuhCLucw)
{
    double zblLZPbGzfc = 988552.8964582373;
    double FpgGWFaV = -981833.4592006765;
    string VBGaDapgNVoobIF = string("nSkEXQcJZGYADUJmjSRfJBqZmxPGPAkFvHfsNrSJNFjkjXxdpe");
    double HnZTqgbRo = -143761.5716676949;
    int NIuLWQtoHe = -649223969;
    int XwHmkRK = -866257136;
    string boADAsB = string("kXSgYRdLkLPdGODSCCtroVbsdjoqZNfxJPkDnMlnasrmDoPNswYKektjkrvdTUGahdIpiXAedV");
    double MdGKIOCxKFllH = 958518.024205387;

    if (MdGKIOCxKFllH == 988552.8964582373) {
        for (int pIXUeEzJ = 558118587; pIXUeEzJ > 0; pIXUeEzJ--) {
            continue;
        }
    }

    if (MdGKIOCxKFllH > -981833.4592006765) {
        for (int vfKFGOlP = 458333260; vfKFGOlP > 0; vfKFGOlP--) {
            iIohcedXmuhCLucw = boADAsB;
            MdGKIOCxKFllH = HnZTqgbRo;
        }
    }

    for (int ycQWje = 1016249140; ycQWje > 0; ycQWje--) {
        XwHmkRK = XwHmkRK;
    }

    return MdGKIOCxKFllH;
}

nBxejzB::nBxejzB()
{
    this->ZPGnnLWnNiJOP(1345462296, true, -793160.9630797991, false);
    this->XgpmL(-692343.8251640458, true, 258919352, false, string("vQmWJJCROVqoHuNvcYVbdINPpRxuxruDSHlEpaDQQYmfETDyoFJZjjuuSreKBNohTthjcDuItNJhiJfGTzYNBCHzTmQUNFuyPqKRcOedunHusGTqoRkRgOVwShOOLBLeoHGwbwACnjgdyfsujmjoPiaDDHQRYEBnZupwnOpGCuiwWzkOxMsrIECfdwMqJPyTfywmVyFIqrOTfnqlDzhGZAiHCmhlcOpAXHLtATMPJSEgxyTUzICOPshTjEDz"));
    this->tUaloGv(-1963441190);
    this->nawZhHqiu();
    this->yTdPDrM(542316.2004571425, false, true, 1731087215, false);
    this->oqTYQbOsmH(string("qDFphoBoFkJAkIcIthoIMNtTMZaVrRdSTFIxNANuumxgSYgHJxBKUKLAJRNHGgdTGtuKebugenpIPcK"), false, string("nggeWUzeMESdqkeeJbbbDoipmFnJuJHYdRmbiEFhLWdrnlKbePgUXkAMFpTozFbFaoAdCzuVuScyjqohabPByipGlEDtMfsULfOokTLJnsBJzVvPXnMaeQgHYnKNJKvXUJoOQmFMRrUachkXzJHkevMPLaRUkNrEmMLToKZDEvbSkymGPDdOZGyOuVIbmXvRdCOlcKDFcNZdKCLEZpOki"), string("txMLpGImWdSdIYVOQUvfOogQQToicIiohIPZpUipuOVxPmMTgqPCUGOBNTXBAyzVX"), -241850.70819835225);
    this->tQSFzQFVNgpjJQuC(4489.637398178456, string("FdbjnHbOwKxpxDlMjnKbLsoRZARknlBOjKKBTjlpYjpwzcOlamImokTFULCftgZGutEflKoQniMMDTMVRTEUuOydvEkpRgvujJc"));
    this->GkawZVMa(string("dADsjjBmpiMUzJNzSxVLKHtywjbtqDjjhJpTYgltWGxulAKSFpuUwUvBzOpbckSYHMVasmiPPUGjgWXcZlmVADjugGhdsTfwGbKSCwGVMsDRTehMmszqVdQXvEfjVPeQPOHiLNTRjVfxqveyKSCuWnkbIFBmVTvraMyKCAnBixLPvyn"), string("CcEzkceYFGgbyXGmBuiiPIutUApLktJgooRJiublrROpPtrhFUZYlRZeVmIuIZYSDVojjuaOcADsMkKjDBjfGNEkVXqpKTtRDINJtWfmvEWsFAxhooRauXHEVXOZdRIZDermxMQPulPgJIABIYtIcSgHDYlmkLTBvpMVTdjefHeVmHXhFmOzWVwycetmmijPAFasGVMciXtgpzbSMiWwcENigHWs"), false);
    this->smplndjpoZoeiS(-758891590, true, -1726054583, -763584.5130733068);
    this->OZogcc(947306778, string("SieJmtrzIMgsYfkQhLUcBRTHUaZ"));
    this->pWwSd(-418201243, string("tJQTDucluoMlUneePXzfxhKcFfHUprpcjxKqlcNuuycjUoaVWpBhseUeBisuRCbiJLjcfhjElwQkhdeZoYYm"));
    this->vGEJifR(string("OkEGqDuNCqPkRqCAuTSGrnlPYKJuYsfmqZdhItAP"));
    this->SLlPhTc(string("wszLnmeaKuIKayawHxstXkhwmjdjzwlXniTTxDiAktIVisxebmYuDjzRkswcxWLfUPrhcYmlTxVWVNDkamQQjMDBnzKXicbsSbFjJyMjEpuuugQdbhQFxWIUCdJUPPPSpDledQxbEPslqIbELkQIquruIXNoJqrTmEoDmNCLJEUwCQUZZxlCMCGnUJyQjOkwkVJISUtyXEMO"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GyeDtzoHCwpEXD
{
public:
    string OKUCGcptLtJyuwT;
    bool imiWAzfUKmGVAa;
    bool MxkIPSGKYekqcM;
    bool CPpYthGaafxsnk;
    int oBYuDqOUFaOlb;

    GyeDtzoHCwpEXD();
protected:
    string gFXsdMemQ;
    string UFqZYSCYv;

    bool PqXycwOvajxbuAAe(bool hTZNuLLkprOVz);
    string WYZDl(bool eQOChi, string tVIumAoNkfLgvGw);
private:
    string opbIuwGrPm;
    bool uctQXahjAKOOOo;
    string INGltRFPgedXoBqL;
    bool FNTRBncDZIgwa;
    int avWRKFlqDLpog;
    double CnPoicueuqX;

    int Ulzohv(double bsGfYw);
    double DnLjwoxT();
    double MsVHAPLNssW();
    string YONpc();
    double drfuExpYPc(bool jddmP, string mcDWt, bool OEpLs, string envPSauvw, double KxASPVn);
};

bool GyeDtzoHCwpEXD::PqXycwOvajxbuAAe(bool hTZNuLLkprOVz)
{
    double pzJFJuImXe = -910381.2383036683;
    bool Btzbr = false;
    string flDaGgG = string("iSikgltVIdXSExzzZuezcMpZeMUkOMidqOcHPozFVjLuTRBcDNqulhHkJWrAZVZDPdgFXKhDsRhWrxbUEuifHdtixShdfZEmufLunMXlVXwXYBnRsFJKWHnhsQzKAh");
    int EJuZkltwhwpIOv = 642874339;
    bool uyvxuVus = true;
    string qAEsPl = string("WmrxoeVlXiDKKARMWKwIjKHaANCcHXroqLXNAjCzuPgpLkWSIkpmHScQLuWHAJczgtVBamHNEOcNQAgfovPWnfFxyPiVSKWfomfgHjblSxqZjmVKBrmuijMrrAVFerPPBsIpEOPpUAJHDRyOacoHiXpaxesHdqqpUhnGOClMJfRaVbQNSbyGbEmELypVyCArzIEDJfqLfoRNQCEWQiPAB");
    string wkqZnKUSPSpN = string("xkJkYyXxBxkYBUQYflpWGPTYnmoOGcOCIWtclbBuAJBYdHvCNkfgRimEpNnDOXmL");
    bool dpSZfeS = true;

    if (hTZNuLLkprOVz != true) {
        for (int zfENpAb = 993630580; zfENpAb > 0; zfENpAb--) {
            dpSZfeS = uyvxuVus;
            flDaGgG += wkqZnKUSPSpN;
            uyvxuVus = dpSZfeS;
            hTZNuLLkprOVz = ! Btzbr;
        }
    }

    for (int YvZQpBW = 530360244; YvZQpBW > 0; YvZQpBW--) {
        flDaGgG = wkqZnKUSPSpN;
        uyvxuVus = ! Btzbr;
        Btzbr = uyvxuVus;
        wkqZnKUSPSpN = qAEsPl;
        uyvxuVus = Btzbr;
    }

    for (int NnQMoqd = 997592805; NnQMoqd > 0; NnQMoqd--) {
        uyvxuVus = ! uyvxuVus;
        hTZNuLLkprOVz = uyvxuVus;
    }

    for (int AwkXgLbZDvjQJR = 37370177; AwkXgLbZDvjQJR > 0; AwkXgLbZDvjQJR--) {
        dpSZfeS = ! Btzbr;
    }

    if (dpSZfeS == true) {
        for (int jrsWTxJSNaEEue = 1069842642; jrsWTxJSNaEEue > 0; jrsWTxJSNaEEue--) {
            qAEsPl += wkqZnKUSPSpN;
            flDaGgG = qAEsPl;
            dpSZfeS = ! uyvxuVus;
            flDaGgG = qAEsPl;
        }
    }

    if (wkqZnKUSPSpN >= string("xkJkYyXxBxkYBUQYflpWGPTYnmoOGcOCIWtclbBuAJBYdHvCNkfgRimEpNnDOXmL")) {
        for (int nMSWUADXCtzCAGc = 1774779011; nMSWUADXCtzCAGc > 0; nMSWUADXCtzCAGc--) {
            dpSZfeS = hTZNuLLkprOVz;
        }
    }

    return dpSZfeS;
}

string GyeDtzoHCwpEXD::WYZDl(bool eQOChi, string tVIumAoNkfLgvGw)
{
    string cwuJppzPCFMMdt = string("dpJELWwqlUCUonYervofJOHnHsPhpRfKauQVHQjiKXzwisrSietATzHTVDabJNTZDDvicyITFGRhOVwSpiTZIzcgKqpfwxJ");
    bool vrEPnaSyajEDCX = false;
    bool DalSUm = true;
    double CUyZZPPsg = 221616.43257624135;
    bool UAelycaAUWaf = true;
    string tCnusNvp = string("xDFjrhVJiJDFgfCnRFDBrKzTWreGNgetuJakIbeWnxvsRrqgGeKkPEGRaRAEtxSgKfdLDVawIbJBAsRat");
    bool tNkNVe = false;
    double GIUEe = -794181.3432993842;

    for (int jdsKKLKzgTBQ = 1982930077; jdsKKLKzgTBQ > 0; jdsKKLKzgTBQ--) {
        vrEPnaSyajEDCX = ! DalSUm;
        UAelycaAUWaf = ! DalSUm;
    }

    return tCnusNvp;
}

int GyeDtzoHCwpEXD::Ulzohv(double bsGfYw)
{
    int xhroTkqLe = 1782712630;
    int vtWKZLfmZBCrBhe = 2128297044;

    if (xhroTkqLe >= 1782712630) {
        for (int WIXmJW = 583011767; WIXmJW > 0; WIXmJW--) {
            vtWKZLfmZBCrBhe /= vtWKZLfmZBCrBhe;
        }
    }

    if (xhroTkqLe >= 1782712630) {
        for (int QkJKSDErwXA = 2057558223; QkJKSDErwXA > 0; QkJKSDErwXA--) {
            bsGfYw = bsGfYw;
            bsGfYw = bsGfYw;
            xhroTkqLe /= vtWKZLfmZBCrBhe;
            vtWKZLfmZBCrBhe = xhroTkqLe;
        }
    }

    if (xhroTkqLe > 1782712630) {
        for (int BpuPPUxv = 1268550551; BpuPPUxv > 0; BpuPPUxv--) {
            vtWKZLfmZBCrBhe = xhroTkqLe;
            bsGfYw = bsGfYw;
            bsGfYw = bsGfYw;
            bsGfYw = bsGfYw;
        }
    }

    for (int trWjauDvqLPKJp = 1986230148; trWjauDvqLPKJp > 0; trWjauDvqLPKJp--) {
        bsGfYw /= bsGfYw;
        vtWKZLfmZBCrBhe += xhroTkqLe;
    }

    return vtWKZLfmZBCrBhe;
}

double GyeDtzoHCwpEXD::DnLjwoxT()
{
    double AmYQynZ = 753318.3688927355;
    string avYAwe = string("UJmRfyTTUStdEFwiJpqOYgtwCcglYDOUwimCScREWgKtaZdczLueNYCMoRItwjzClupGnIYgywv");

    for (int ffpEadpQVoCOuEf = 97754690; ffpEadpQVoCOuEf > 0; ffpEadpQVoCOuEf--) {
        continue;
    }

    return AmYQynZ;
}

double GyeDtzoHCwpEXD::MsVHAPLNssW()
{
    bool ZTekxaV = true;
    bool FNeIGwgrW = false;
    double wZjSxEVIQLm = -971617.5040602138;

    if (FNeIGwgrW == true) {
        for (int FJveATzoGoJmFg = 1891493149; FJveATzoGoJmFg > 0; FJveATzoGoJmFg--) {
            FNeIGwgrW = FNeIGwgrW;
        }
    }

    if (ZTekxaV == true) {
        for (int gBfTWkaCDEpq = 1159521124; gBfTWkaCDEpq > 0; gBfTWkaCDEpq--) {
            ZTekxaV = ! FNeIGwgrW;
            wZjSxEVIQLm *= wZjSxEVIQLm;
            FNeIGwgrW = ZTekxaV;
            ZTekxaV = ! FNeIGwgrW;
        }
    }

    return wZjSxEVIQLm;
}

string GyeDtzoHCwpEXD::YONpc()
{
    bool ZvkTwCGs = false;
    string WCHecN = string("YwZoNtnwxglXDiQnbFUwqDnAuZAdxEvbcMmFrXNSEbQdziATpRyRsSBbddetXFSazUMwxHecmqnMVEiXaUiMOKMflepOCzissjTdLyKOhRapLMzBGocQGAbLrJKpMXdWeuAFajNWmIHuFufjgIviUiGGCdWwDRsooybSFHMQdantLzIATuUsYhNmWVFBXJdRJfeVDLIFqbtrRkguWMRMDqeXGFsTAvPdpsCTSFgOwTrjJ");
    bool cWaxzYr = false;
    double ZbCtmF = 306334.81323857594;
    double luBWUDKhuoJgVQZ = 211896.46926952802;
    bool FhelGbpKD = false;
    bool miEohivHqbr = true;
    double yanreIJuzpA = -42090.24794442665;
    string XvEuj = string("NelqtdkeIrKpEAICznUyqhQMlvqjzvWwSsJikWNQCDSWaoyckTMrznyBqVCrfsUobAyehxjXsCoifeFIYMWdcXtwLNmiiFCBIZlfzOBXqUUVQlUixVqMEwqXosYnFmTlQWkAteRcXJujPjlvpBfLyJhCLhZaEoEXtknoSIFWjWOWqjFvXcrXXhjiSVCWWPiNvmmANBXXODN");
    double pYvnJtkhIM = 968413.3740165285;

    return XvEuj;
}

double GyeDtzoHCwpEXD::drfuExpYPc(bool jddmP, string mcDWt, bool OEpLs, string envPSauvw, double KxASPVn)
{
    int RKPojxsYsbzuttx = -1549121812;
    bool ZRlXJlBjLxE = true;
    double CpaTxGtMXhxGJZj = 1005793.982655848;
    double WpMjxH = 805913.0419660001;
    string zbfnfTPh = string("MTbCrpvcvtQfzJKgQOXwvUqTzKZWZcTCrDUKVqnqXdHYRTTPBCBmEwDdrXZJmvzgGbEWYzGzVCRcLwtAXNRONFuOEwygYcfhtlXKbDOTmjwSUMbZMSFsfmHs");
    double cEATausEoofdnjP = -1041156.5889853246;
    double LiOafq = 471636.8797400411;
    string usMOt = string("qFGEIjBLehrmdBLncev");
    int DQsPnr = -1190819023;

    for (int vKPvwHlzaa = 1415600442; vKPvwHlzaa > 0; vKPvwHlzaa--) {
        WpMjxH = WpMjxH;
    }

    if (jddmP != false) {
        for (int tYSZQ = 1575526572; tYSZQ > 0; tYSZQ--) {
            jddmP = ! OEpLs;
        }
    }

    for (int nGDzLPWaxtmX = 586566277; nGDzLPWaxtmX > 0; nGDzLPWaxtmX--) {
        continue;
    }

    for (int spgPBzW = 969590544; spgPBzW > 0; spgPBzW--) {
        jddmP = ! jddmP;
    }

    for (int QoISmfCpbmNucGk = 608053422; QoISmfCpbmNucGk > 0; QoISmfCpbmNucGk--) {
        WpMjxH = cEATausEoofdnjP;
    }

    return LiOafq;
}

GyeDtzoHCwpEXD::GyeDtzoHCwpEXD()
{
    this->PqXycwOvajxbuAAe(true);
    this->WYZDl(false, string("kJYcsMVWNPTSzrsCElBPfXdAnJPtuapPuZHFFvKmAeLuNAGZDILDFWsTzMGFzDyRzuakXLRjqDuEqaqbomVQhtyATBwLKEZshtrHyUkuiAwGNatUzHRep"));
    this->Ulzohv(-433862.36182722205);
    this->DnLjwoxT();
    this->MsVHAPLNssW();
    this->YONpc();
    this->drfuExpYPc(false, string("akCHovQweXKFMuUWtdlRJIyWkTbdYLRiGeVdsZKzcvLEpnLPKjMjJHFccIzdxnxRaHPdVpAyCSqwcUWnIeVqqRSmYXHDOhaHEWsbUVvHFfrjyZuQMWCTcPICHNYqXcBnRBHGEwgIcNrKunYMIKmOWaEbggprJnwFzVGWjLwqOneojHbSBkZSYBPHkZjEwCKSPYPAzyNYxZsxyKsWHPqYxhXUUd"), false, string("PAdGrpPBtAXFLEsjwzDyMTBCmScVDInZKrvsGdJrAMlpJbDotsSzUJWaiIlulROElQaSkYSabuuRPczqUsstlbaCuvGqvUPXuFSacazctgKhVJnXW"), 715662.761274423);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jmplhdeiu
{
public:
    bool uPTVkiCUbaPjoCX;
    int Okrelo;
    double gVQgtvPUrnySkX;
    int okuyQQCTc;
    string JIGsnrzcJV;

    jmplhdeiu();
    string MNRJNmh(string oXXBToPzA, string brQTMNIOEWZCGGMJ, string RxpetCUkfLnHWQ, int gaqROIpABmw);
    double tiJRQoZZ(int JJvTgIDphwPTJ, int CQtKV);
protected:
    int uqGmTtti;
    double ObHcVUXTmNLCq;
    int odTfPccMeyhyq;
    int RtVnHADoUcqUA;
    string PlNBmXvhPUXfY;

    void DgKQWFplGFDS();
    string QeZTIpOvmmFVGo(double FCTfb, int AXoNM);
    int QWNKG(string EfDhiZj, int JOHElULck, string QTBDTlYuUekUHpiS, int RPCIofgNySGjT);
    string fulOMNTCpoMgnfzn(bool vTbgIjaLUxkhGEYK, string JTEdw, int pmdPciGEgEA, string UdFsSHcKGTc);
    double tRdIx(string sOuHEZRzvv, double NJzucapqWrt, bool cjEdHXecKxTY, int xdddLTXbMN);
    void DqIrzgamqPWBSVlB(double PjWEAtvnXsS, int DlzgDHyIo, int egntlmfFRwNGDuP);
    int TsUSTdkXxLG();
    void XERUKDYWEA(int pIyogCTeDEDLBoW, string iVUFRMFx, string UNKRtI, double MsIoV, string OMfDXFaFclD);
private:
    string zwadR;
    bool HpkKkxLhsqAuWjdW;
    double DjJRuElLUjn;
    int bDivESwTKc;
    double moxUeM;
    int ivnUKFHlIjUyjT;

    int WpfjRW();
    bool AxcxYrkcRooM();
    bool HkRTTYCZPMv(string BKXHq);
    void UKgDeYlNJmJG(double ybkyYcqpGnKM, bool GhHkxXVHoaFiOX, string vXmYNYN, int hrBXW, int cTpEkcaExB);
    double xkmAk(string zIkMbLcCHPuY, double IMpRWrwCIRhfJyok);
    int yAyJWjHSEH();
    string bMbeahkOQllXUby(string wvJfgODwuuN, string MpVYkthCK, bool QrnxHaisaGi, bool buFWRHrzT, int NsmRBHf);
    int mMRmGSpkPVnBXAg(string vDLrygubzTEMch, double DzamRYTlkZi);
};

string jmplhdeiu::MNRJNmh(string oXXBToPzA, string brQTMNIOEWZCGGMJ, string RxpetCUkfLnHWQ, int gaqROIpABmw)
{
    double soneYIrjcD = 288344.6942781101;
    string CwuJC = string("BQLqpHORSUKeMxaNefNPOoowxhsrABIQxcNCINIxHaSOvbfLUmUcaVwQfIHizlmDIyMqFExHAcQOGSMHaeTIZVyBQkZIiwyXwrpahySmzZbHgUcGQXSJqlEvCReTiRAzruSAIqUMlPHPezNxkYkBmWlIajkOhTlXEUYdCunjLieclfasawUPGIsbJoVAdYUBwAYGVBTaBCpyWwJBowXufPxBjX");
    string BnLcCgQPSEQEazG = string("xPtUWgWOMYgxUUAttDZMGShrXjXVlDHoAUhiDhvmOHaNePzaypvuPVbDJSNQHYTfGyFmjYtwKvvOJyGsuhJCTlyiOvSKiYeivnIGjXyBwwULNhsgLGPLxcnILcaPuO");
    bool ZvBGogIeVguwVS = true;
    string oKcRUSRrlrlUMR = string("NvKwSAeTFyUsyXyLSnzDzrJrfsedEEBqUfMLVOFoHlfkNYrgOYDimqWzTFfqCDcvVAecbTbcHpYMukzDbfCZWTNbALFpDpVWhPMfFvPSiAqWtEtEsEjqKpBPeNKRxDzBFbsCTxwJncAlpkBWGgXHYVviAtVcXIziwrEXGXnOOoqKXmMZnahwgJXnJlISvbEcYXUkXayetWWGwGWKLRUGLKfHZnHwBfRqdNPguSqLXknqkmYBawEoeHdPujLrMLi");
    bool TNrPufXe = true;
    int LGnFardbkfvmxLVG = -71904350;

    if (oKcRUSRrlrlUMR == string("AynpOGYV")) {
        for (int nLoMQsPwAjH = 1370261811; nLoMQsPwAjH > 0; nLoMQsPwAjH--) {
            continue;
        }
    }

    if (oXXBToPzA > string("xPtUWgWOMYgxUUAttDZMGShrXjXVlDHoAUhiDhvmOHaNePzaypvuPVbDJSNQHYTfGyFmjYtwKvvOJyGsuhJCTlyiOvSKiYeivnIGjXyBwwULNhsgLGPLxcnILcaPuO")) {
        for (int nbhyMN = 1320623728; nbhyMN > 0; nbhyMN--) {
            BnLcCgQPSEQEazG += oKcRUSRrlrlUMR;
            ZvBGogIeVguwVS = ZvBGogIeVguwVS;
        }
    }

    for (int VacAXinR = 593503648; VacAXinR > 0; VacAXinR--) {
        oXXBToPzA = BnLcCgQPSEQEazG;
    }

    return oKcRUSRrlrlUMR;
}

double jmplhdeiu::tiJRQoZZ(int JJvTgIDphwPTJ, int CQtKV)
{
    string mbDzyoWpYtk = string("UksNnyGBrOAMvcBGidbKuGeMnUoBOWaQEcqMGHmeMuSWRaXVPqoJLibFLcsmIfcSLbbCSURKBqexiRxPGGLBvCctaSICLsdvpMgkqOG");
    string fwAgY = string("SweMvbKbMwQxIuyCzAxEdaCMvd");
    double VcqEcFoOMEclFyob = -520002.5030877105;

    for (int sWuZHuXADHA = 1524204425; sWuZHuXADHA > 0; sWuZHuXADHA--) {
        mbDzyoWpYtk = fwAgY;
        VcqEcFoOMEclFyob += VcqEcFoOMEclFyob;
    }

    return VcqEcFoOMEclFyob;
}

void jmplhdeiu::DgKQWFplGFDS()
{
    string eEpxtbaUwkYTRPwb = string("yDzhxDmvmXYddVoysdtdVYWOGjiotwJcOQsRIkmmtOuDNN");
    int BqrtvlIeaT = 1157135622;
    bool iJNPpSLtcqWtBZrZ = false;

    for (int dEPXAEDKanFlG = 1812023494; dEPXAEDKanFlG > 0; dEPXAEDKanFlG--) {
        iJNPpSLtcqWtBZrZ = iJNPpSLtcqWtBZrZ;
    }
}

string jmplhdeiu::QeZTIpOvmmFVGo(double FCTfb, int AXoNM)
{
    int oqJFzy = 1690770664;
    bool qEwVyeVew = false;
    bool lkCma = true;
    string TzxMlUlVDqjODuxh = string("wdbnAxqkfUPWejHIzqFhUORfWUloDNsZZIufxxrsfRfzSHrpHKJPAEYooiIkFDzHfeGXYQbwsURqwkJEeOdxBMrRYJudWVbpBfaNGEZnuihOprHckukGKbveIBMJB");
    double CrbQN = -769967.5848634352;
    int RQeHQxYmWMdd = 2105113102;
    int FhXED = 1777809602;

    for (int pbMun = 1070881885; pbMun > 0; pbMun--) {
        RQeHQxYmWMdd -= oqJFzy;
    }

    if (RQeHQxYmWMdd == 1225611117) {
        for (int bUFHblZuBZvb = 899394809; bUFHblZuBZvb > 0; bUFHblZuBZvb--) {
            FhXED -= AXoNM;
        }
    }

    if (RQeHQxYmWMdd > 1225611117) {
        for (int GigFtJsmWWwskTR = 913476160; GigFtJsmWWwskTR > 0; GigFtJsmWWwskTR--) {
            qEwVyeVew = lkCma;
            FhXED *= RQeHQxYmWMdd;
            lkCma = ! lkCma;
            FhXED = FhXED;
        }
    }

    for (int eptHECglFfI = 1691376236; eptHECglFfI > 0; eptHECglFfI--) {
        RQeHQxYmWMdd += FhXED;
        oqJFzy *= FhXED;
    }

    for (int PKpxOrxdeGBSPn = 1240687219; PKpxOrxdeGBSPn > 0; PKpxOrxdeGBSPn--) {
        CrbQN -= FCTfb;
        FhXED += FhXED;
    }

    return TzxMlUlVDqjODuxh;
}

int jmplhdeiu::QWNKG(string EfDhiZj, int JOHElULck, string QTBDTlYuUekUHpiS, int RPCIofgNySGjT)
{
    int bxDKzsxAzRlsoQCY = 1679206376;
    bool liVwbUQOF = true;
    double kzCGGtFaaDe = -358213.43948596384;
    bool RFeNAKvwsurJ = false;
    double rxsGYlPvuT = -318449.33662743546;
    double wcezxUwCmfTEx = 487476.60913441394;
    string csVGDhUzzUrXLG = string("xtmxqYMnoqejAsYWsMFhbiTlMOgiENUzOGRdIdaBHszOTjut");
    double MbaaaUqsmF = -883398.2018974116;

    for (int uLUoQrgQOLBj = 1298645547; uLUoQrgQOLBj > 0; uLUoQrgQOLBj--) {
        EfDhiZj = QTBDTlYuUekUHpiS;
        RPCIofgNySGjT *= RPCIofgNySGjT;
    }

    for (int LTkvKEcag = 898072077; LTkvKEcag > 0; LTkvKEcag--) {
        MbaaaUqsmF *= kzCGGtFaaDe;
    }

    for (int UHsRVTOMRgc = 1071667900; UHsRVTOMRgc > 0; UHsRVTOMRgc--) {
        continue;
    }

    for (int suldPcms = 324019077; suldPcms > 0; suldPcms--) {
        kzCGGtFaaDe *= MbaaaUqsmF;
        rxsGYlPvuT /= kzCGGtFaaDe;
    }

    for (int jJDCwudvjd = 58279001; jJDCwudvjd > 0; jJDCwudvjd--) {
        kzCGGtFaaDe -= rxsGYlPvuT;
        JOHElULck *= RPCIofgNySGjT;
    }

    return bxDKzsxAzRlsoQCY;
}

string jmplhdeiu::fulOMNTCpoMgnfzn(bool vTbgIjaLUxkhGEYK, string JTEdw, int pmdPciGEgEA, string UdFsSHcKGTc)
{
    bool XamGQFhEoN = true;
    bool eGuQYMdyTiEO = false;
    double RedNkZzAmWT = 244307.42667097508;
    double Jdcaa = 716486.3725922635;

    return UdFsSHcKGTc;
}

double jmplhdeiu::tRdIx(string sOuHEZRzvv, double NJzucapqWrt, bool cjEdHXecKxTY, int xdddLTXbMN)
{
    bool tRRBKObbvSZxTZz = false;
    double hveQvbydHgiE = 532464.9171503923;
    double wudPfHjPHp = -674373.9424434056;
    int eYzqdUmAwmCZgth = 1625078023;
    double etDNnvIgOMLoPVS = -151410.9179106693;
    string QYOBxJuTzyRM = string("DFPymkUhEuFSrpRZXuTiSwKiIUiXwSxnWHeoHhUXxtGbVbrbIDPKyLokkgxpgziXMKaAAIgMfwndfqhLYiZxqrJSVmVPEzEYydPSbTadbnXfPEgH");
    bool MEtmGUz = true;

    for (int WmQMjmo = 996898901; WmQMjmo > 0; WmQMjmo--) {
        hveQvbydHgiE -= wudPfHjPHp;
        tRRBKObbvSZxTZz = ! MEtmGUz;
        sOuHEZRzvv += QYOBxJuTzyRM;
    }

    return etDNnvIgOMLoPVS;
}

void jmplhdeiu::DqIrzgamqPWBSVlB(double PjWEAtvnXsS, int DlzgDHyIo, int egntlmfFRwNGDuP)
{
    double qSpVubO = 79693.06459328759;
    double dbBuvVzNxy = -914105.5130307382;
    string NnbjS = string("ivGulYCoAslUxgVDAOTGxwHDXwqXwyMbFgkrvJ");
    double jqKBfFsNKyX = 265204.9676288906;
    string OwvPixEJZfwOwhU = string("GlmJaWjuIgikKgMfvXoqpSLaTYSlNmVMIJTGsARqvvDVfnQzKNSHelDDEcPWcTdJGjkEswBLbVTwYgaMgjcKEPDMsLLKmLlfekULwFWJThLhaACCijXfWUgMCLVNZnHyGCfOUKPnuiCrhrDYxRgdhVoJBhLGxpt");
    double YCgPDoRdCpLiP = -401849.65594125434;
    int GsPDIob = -74265385;
    bool vYhAwlEJgw = true;
    string QsxwDdmXZD = string("QiWluPhFJIsQNuMGBhPVvhbOpdzEIWqsWVwnmgPTdJarFNDupxYkftpUJywHbuDlaWdvdYngXmDVXIfFmQboHnYHcwwOmhogFUfxXGFEYuVBOAsgtisXHuwWteRMrlXFmuufgicQIjtntmtqUvodsc");

    for (int VZvEOcRBa = 198479192; VZvEOcRBa > 0; VZvEOcRBa--) {
        DlzgDHyIo /= GsPDIob;
        QsxwDdmXZD = OwvPixEJZfwOwhU;
        jqKBfFsNKyX -= YCgPDoRdCpLiP;
    }

    for (int CIoNWHlVMfZVkilr = 1144622517; CIoNWHlVMfZVkilr > 0; CIoNWHlVMfZVkilr--) {
        jqKBfFsNKyX /= PjWEAtvnXsS;
        jqKBfFsNKyX = PjWEAtvnXsS;
    }
}

int jmplhdeiu::TsUSTdkXxLG()
{
    int HRCXqFuXGlywNvAZ = -159310564;
    int EuNngWdnKefUZtef = -1235592113;
    bool uBwhf = false;
    double nDkFJIGGxKJZZRQy = -851861.38964814;
    double lPiQUAG = 299957.54952317674;
    double CKEOHlkjHHkBw = 24919.811068986994;
    int tNYiRDozCa = -40735020;

    for (int VgBnvoExIzqd = 995765774; VgBnvoExIzqd > 0; VgBnvoExIzqd--) {
        CKEOHlkjHHkBw /= lPiQUAG;
        HRCXqFuXGlywNvAZ += EuNngWdnKefUZtef;
    }

    return tNYiRDozCa;
}

void jmplhdeiu::XERUKDYWEA(int pIyogCTeDEDLBoW, string iVUFRMFx, string UNKRtI, double MsIoV, string OMfDXFaFclD)
{
    int rVZelDiNDi = -1696246513;
    int OBUkwWAbBTFG = 883628905;
    int pJMtDysM = -776777554;
    double NfsYz = 820090.9392415157;
    string UAlBlaE = string("jaMrovivFOgHjjQCzOAhJopUiEROlYTiUVqWTTVfMNbBMHQISHEYCEwVdvVJfroIbwseFXxzSZIXDBHZCxUsdJgqRGRDgADgJDwVBKqeoxGFcVlnoTu");
    double lSabdsZdPKOwB = -676382.0270126599;
    int bEkSgtFw = -624148889;
    string MzlyPnNKcB = string("SFgmiYUqbtgGhEytesbqhCwQRTvKXTZYoKKCEYgXvGYCWLlrnLlxZVjuMRPacUTyXtVfCQGlRFemfHZSdvxhxppYqmRJgtmSSFRsNGBhqdRbDuAJJwvVaDktkoVhIQhhpnwmeAHEf");
}

int jmplhdeiu::WpfjRW()
{
    double qwJyDHPFBJEcVvpx = -870982.1734536462;
    bool NBcLgP = true;
    string pKMaOceIXmqsXoYr = string("DIcVJNBMJTVGEZNEZhRUGEfYLUxldNxqhWRSSEJ");
    double TWORZWQIFG = -317258.65382888186;
    double uLnmrqvuOovaXq = 287885.2255365649;
    bool DZYZRi = true;

    for (int ynQgPjZY = 1949412552; ynQgPjZY > 0; ynQgPjZY--) {
        NBcLgP = ! NBcLgP;
        uLnmrqvuOovaXq /= uLnmrqvuOovaXq;
        uLnmrqvuOovaXq /= uLnmrqvuOovaXq;
        uLnmrqvuOovaXq = uLnmrqvuOovaXq;
        TWORZWQIFG -= uLnmrqvuOovaXq;
    }

    for (int KtwsC = 748431663; KtwsC > 0; KtwsC--) {
        uLnmrqvuOovaXq *= TWORZWQIFG;
        qwJyDHPFBJEcVvpx += uLnmrqvuOovaXq;
    }

    if (uLnmrqvuOovaXq >= 287885.2255365649) {
        for (int XeNGoAZoWOzv = 1615636492; XeNGoAZoWOzv > 0; XeNGoAZoWOzv--) {
            TWORZWQIFG *= uLnmrqvuOovaXq;
            DZYZRi = ! NBcLgP;
        }
    }

    for (int GpYfiLJVVfw = 1918816588; GpYfiLJVVfw > 0; GpYfiLJVVfw--) {
        continue;
    }

    for (int poRwNiBokkGmQSB = 1090011506; poRwNiBokkGmQSB > 0; poRwNiBokkGmQSB--) {
        DZYZRi = DZYZRi;
        qwJyDHPFBJEcVvpx /= uLnmrqvuOovaXq;
        TWORZWQIFG *= uLnmrqvuOovaXq;
        uLnmrqvuOovaXq /= qwJyDHPFBJEcVvpx;
        qwJyDHPFBJEcVvpx *= qwJyDHPFBJEcVvpx;
        TWORZWQIFG += qwJyDHPFBJEcVvpx;
        DZYZRi = DZYZRi;
        TWORZWQIFG += qwJyDHPFBJEcVvpx;
    }

    return -35327073;
}

bool jmplhdeiu::AxcxYrkcRooM()
{
    string JTGkwCZRIoFj = string("XerrWKoEQeKwsUPHtYMMqoZSkEmfBcGuzIrZftfIhnfvfmekhyPGSVnafaJogNXcnRrItsjnBkkByGEaYrGvpGmeOBdbCjTGqqKwCewmpGRO");

    if (JTGkwCZRIoFj <= string("XerrWKoEQeKwsUPHtYMMqoZSkEmfBcGuzIrZftfIhnfvfmekhyPGSVnafaJogNXcnRrItsjnBkkByGEaYrGvpGmeOBdbCjTGqqKwCewmpGRO")) {
        for (int cUpEyGAmk = 1503030623; cUpEyGAmk > 0; cUpEyGAmk--) {
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
        }
    }

    if (JTGkwCZRIoFj != string("XerrWKoEQeKwsUPHtYMMqoZSkEmfBcGuzIrZftfIhnfvfmekhyPGSVnafaJogNXcnRrItsjnBkkByGEaYrGvpGmeOBdbCjTGqqKwCewmpGRO")) {
        for (int lHXOywHrtS = 671354190; lHXOywHrtS > 0; lHXOywHrtS--) {
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
        }
    }

    if (JTGkwCZRIoFj < string("XerrWKoEQeKwsUPHtYMMqoZSkEmfBcGuzIrZftfIhnfvfmekhyPGSVnafaJogNXcnRrItsjnBkkByGEaYrGvpGmeOBdbCjTGqqKwCewmpGRO")) {
        for (int ZGZroZ = 299673674; ZGZroZ > 0; ZGZroZ--) {
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj = JTGkwCZRIoFj;
        }
    }

    if (JTGkwCZRIoFj > string("XerrWKoEQeKwsUPHtYMMqoZSkEmfBcGuzIrZftfIhnfvfmekhyPGSVnafaJogNXcnRrItsjnBkkByGEaYrGvpGmeOBdbCjTGqqKwCewmpGRO")) {
        for (int REMLaEnLbQ = 2012020310; REMLaEnLbQ > 0; REMLaEnLbQ--) {
            JTGkwCZRIoFj = JTGkwCZRIoFj;
        }
    }

    if (JTGkwCZRIoFj >= string("XerrWKoEQeKwsUPHtYMMqoZSkEmfBcGuzIrZftfIhnfvfmekhyPGSVnafaJogNXcnRrItsjnBkkByGEaYrGvpGmeOBdbCjTGqqKwCewmpGRO")) {
        for (int mcyRuV = 346529303; mcyRuV > 0; mcyRuV--) {
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj = JTGkwCZRIoFj;
            JTGkwCZRIoFj += JTGkwCZRIoFj;
            JTGkwCZRIoFj = JTGkwCZRIoFj;
        }
    }

    return true;
}

bool jmplhdeiu::HkRTTYCZPMv(string BKXHq)
{
    bool miBDBLBymkhm = true;
    int LPjiUpxRThf = -439397837;
    int VhiHucqHl = -1549325493;
    int oanzwcBOUx = -937289616;

    for (int LWkMg = 1725586914; LWkMg > 0; LWkMg--) {
        LPjiUpxRThf += VhiHucqHl;
        miBDBLBymkhm = ! miBDBLBymkhm;
    }

    return miBDBLBymkhm;
}

void jmplhdeiu::UKgDeYlNJmJG(double ybkyYcqpGnKM, bool GhHkxXVHoaFiOX, string vXmYNYN, int hrBXW, int cTpEkcaExB)
{
    bool mCylkYjPfH = true;
    double VCxfNlKAMj = 393115.92819765204;
    int ZJhYBRUClsA = -1919202122;
    bool Rjuqbzsu = true;

    for (int dfwdCfHllxAfAp = 886420187; dfwdCfHllxAfAp > 0; dfwdCfHllxAfAp--) {
        GhHkxXVHoaFiOX = mCylkYjPfH;
    }
}

double jmplhdeiu::xkmAk(string zIkMbLcCHPuY, double IMpRWrwCIRhfJyok)
{
    int OSUTIfoTDpDLIV = 1029351947;
    int JqcWJdDWflCrxyx = 1418989569;
    int VvcvytxhHs = -1437724568;
    bool bCcozxUZiILET = true;
    string foehNFOmT = string("jWeAvevvFjShJSQodmWuevMzWYRSKHDOvsmIZkXHLlsnJlsnZwUfkwkXMPzsrJrGSsUnuLshIdhjDdLgkso");
    string EHaALrQwaPGCde = string("dmXNMdGoImKlxObosoVADlWssTZiKvEayrWCsToWMxwLYHFPKdyEwcBOnGIWVbdBDWmKswFTsfkfJKhRQqFHctKEjgQVxGmBJg");
    int KPuFqAoX = -1633038099;
    int gqAAAHjZXAOecD = -1967235728;
    int BpvfJGHtYkJ = 1062544302;

    for (int PoZGOnVCl = 183931598; PoZGOnVCl > 0; PoZGOnVCl--) {
        continue;
    }

    for (int oRcSTv = 863507795; oRcSTv > 0; oRcSTv--) {
        OSUTIfoTDpDLIV *= JqcWJdDWflCrxyx;
    }

    for (int tVJkRyoBjxofrbIj = 1461613264; tVJkRyoBjxofrbIj > 0; tVJkRyoBjxofrbIj--) {
        BpvfJGHtYkJ -= VvcvytxhHs;
        VvcvytxhHs *= gqAAAHjZXAOecD;
        gqAAAHjZXAOecD = OSUTIfoTDpDLIV;
    }

    for (int SobhMmPi = 1984048910; SobhMmPi > 0; SobhMmPi--) {
        foehNFOmT += zIkMbLcCHPuY;
        foehNFOmT += EHaALrQwaPGCde;
    }

    if (BpvfJGHtYkJ <= -1437724568) {
        for (int RLCvvIWN = 1709837791; RLCvvIWN > 0; RLCvvIWN--) {
            continue;
        }
    }

    return IMpRWrwCIRhfJyok;
}

int jmplhdeiu::yAyJWjHSEH()
{
    string WIyOSeDopkhem = string("Ax");
    string ZezYNui = string("VJLTFRYASJlJOzusQTxyVueBWgIbVlTWgwzBXgQffWInBAuCqVVDhhzJuscyJGKjOtBnxDdtHGwYJfDvjfQyFcBhHVttbPqQGZbTkQdelmOtMwErRXJUKyatnDHVCdKWiGZSkaNzIcoWmOqupeSumKwEoNpdXKjeaFUCoEULwRTNBNbECsxyk");
    double AgiaigIGpo = 391892.6686888434;
    bool BPVnAskelq = false;

    for (int buokusGUrJtjHNIM = 123551867; buokusGUrJtjHNIM > 0; buokusGUrJtjHNIM--) {
        ZezYNui = WIyOSeDopkhem;
        ZezYNui += WIyOSeDopkhem;
        ZezYNui = WIyOSeDopkhem;
        WIyOSeDopkhem += ZezYNui;
    }

    for (int ugIotpReNS = 1435593688; ugIotpReNS > 0; ugIotpReNS--) {
        WIyOSeDopkhem += ZezYNui;
        ZezYNui = ZezYNui;
    }

    for (int QyoxhpUIYC = 117963255; QyoxhpUIYC > 0; QyoxhpUIYC--) {
        WIyOSeDopkhem += ZezYNui;
        WIyOSeDopkhem += ZezYNui;
        WIyOSeDopkhem = WIyOSeDopkhem;
    }

    return -243369729;
}

string jmplhdeiu::bMbeahkOQllXUby(string wvJfgODwuuN, string MpVYkthCK, bool QrnxHaisaGi, bool buFWRHrzT, int NsmRBHf)
{
    string ydKJKeEMoOwi = string("zFXTDDHReKbbWiHcovdtdSkDXdVtXulwXhAqQNkDFNPdeDDcbPqfUnuJvjujNjLGNoVfGSQiXfvXdtgAJpzZGu");
    string qNmxn = string("lmYRdRWDdLOJUDjuhGwsjqEIvYYHdaiLfacRXGpVvrdunytZTUOsNAwSuaJocshLLKKnNWZCpuoJoLCAJpPowPIhnsxaRyLhdfkgSxEpLdbo");
    double bRCku = 656028.2979905071;
    bool wINtGrsgakGiT = false;
    string piLYsRyNv = string("gGnOeBwZJjmEEcPZvxXPcNzRfdFqJKICAZthyApPVr");
    double WgVfmTL = 117756.46930775023;
    bool efnowHmURvL = true;
    string eSudbkaukpWZ = string("hZQcOTUvVVhcjKdJgllXqNRdETijtwGTAIgoLGSdlhkq");
    string ATsQpPSaWHPl = string("pUVsSkbNseZSiyHdKeQlIOUYddtLilngkGezaXzeUFGxGofRCVtPZFWgLHBJwXOLhDbUzewnczBPPrMuyLCtvTVgIfzeMrpYDrdDpwFtscYGWxkTtsBjnmHQJF");

    for (int aoqhqLRHkMXJdDrw = 1145193538; aoqhqLRHkMXJdDrw > 0; aoqhqLRHkMXJdDrw--) {
        continue;
    }

    for (int KnCIBVRdz = 1518966235; KnCIBVRdz > 0; KnCIBVRdz--) {
        eSudbkaukpWZ = eSudbkaukpWZ;
        eSudbkaukpWZ = qNmxn;
    }

    if (wvJfgODwuuN == string("hOJCYCPfEajpDFicfMkEWJWgDXIGolegwZJPSHQdCBHkJrBlxQSyGCHfoxoaZLagDeWgJridbvagkHQABhKqFsjoipJSENKnAriEqIQvsnkvenJsfuJgJTRghlEAIXurCBxbixzWgDhqRdDcXUCTYvPUZfADpWmBYUAtRpuyAb")) {
        for (int bhIzd = 412098620; bhIzd > 0; bhIzd--) {
            eSudbkaukpWZ += qNmxn;
            ydKJKeEMoOwi += ydKJKeEMoOwi;
        }
    }

    for (int WIGDJfhLztxJk = 499016574; WIGDJfhLztxJk > 0; WIGDJfhLztxJk--) {
        ATsQpPSaWHPl += eSudbkaukpWZ;
        wINtGrsgakGiT = efnowHmURvL;
        MpVYkthCK += wvJfgODwuuN;
    }

    for (int GdTuGrPlxjNLp = 1199336363; GdTuGrPlxjNLp > 0; GdTuGrPlxjNLp--) {
        continue;
    }

    return ATsQpPSaWHPl;
}

int jmplhdeiu::mMRmGSpkPVnBXAg(string vDLrygubzTEMch, double DzamRYTlkZi)
{
    string PVJjTZJNEQawvNTQ = string("UMPZCSOEDSzKNibJVReyaHEyzFlasQEwnJNqKIbDvThhhlkYkJzUzmknqDJIROWYkXgtGlpAGmnHEIklbZJvEkSTMAygHTGtBkCkJUgUXXntnuxqAumqxSNhVLZejBLRqAtoKnmJhaNbRibWxrrgcCLCmdqRHSyrJTIJLmtBUGReECgeqkhWlNLjdrWKnlZmhPQTrzbvVWcjcN");
    int DYmKWccUHSa = -212091527;
    string LWaqqwgNlzIRpNa = string("lriOtlmpccUPxjSOu");
    string ghkdIKRQqabonh = string("JdXqcGhSbZBXSXSPqPYjtpfdaurERzzKkWgsrbxieQOIbROQgrzASDPzxtxkSOQSjKGXSVCRcmlARjwvpVwgJMnqdlZlxTwcyGcsfKJexXnqMVbUBIhbnuQRCQGQqXuDMgcXYkyLjELOFLAR");
    string spLwkNtWRcHyd = string("hTBUXIqPBMlJPjzFtGWVeQgAgkLRxcXSzKccehnUwtIDtNBopjPlSWzrcLviwvTHydgrXoPJwSmuwErlbSTKQgLOyQghQHoTGGHfzuCKffWIpjSCFxpTXhDYXPFeJcxhRUFrFgAuKPOHYTlmu");
    int oIDfrZ = 1079295289;
    double lzQyXQBKTGWQ = 811192.6557889463;

    if (PVJjTZJNEQawvNTQ != string("UMPZCSOEDSzKNibJVReyaHEyzFlasQEwnJNqKIbDvThhhlkYkJzUzmknqDJIROWYkXgtGlpAGmnHEIklbZJvEkSTMAygHTGtBkCkJUgUXXntnuxqAumqxSNhVLZejBLRqAtoKnmJhaNbRibWxrrgcCLCmdqRHSyrJTIJLmtBUGReECgeqkhWlNLjdrWKnlZmhPQTrzbvVWcjcN")) {
        for (int OFOHdjQyajQHv = 461739676; OFOHdjQyajQHv > 0; OFOHdjQyajQHv--) {
            DzamRYTlkZi *= lzQyXQBKTGWQ;
        }
    }

    for (int AsOeOqlzxmERv = 658054212; AsOeOqlzxmERv > 0; AsOeOqlzxmERv--) {
        LWaqqwgNlzIRpNa += PVJjTZJNEQawvNTQ;
    }

    for (int qKJXXA = 62117385; qKJXXA > 0; qKJXXA--) {
        ghkdIKRQqabonh += ghkdIKRQqabonh;
        PVJjTZJNEQawvNTQ = vDLrygubzTEMch;
        PVJjTZJNEQawvNTQ += LWaqqwgNlzIRpNa;
        spLwkNtWRcHyd += spLwkNtWRcHyd;
    }

    return oIDfrZ;
}

jmplhdeiu::jmplhdeiu()
{
    this->MNRJNmh(string("pMfBoTQABXuRWWEMUNOlTsdsjZqTuAkUGsyAlqFwACBPXPgCAdxqdvWtQeodbHYLgWK"), string("JUVEJCwixezxcOFRaqaRfRxTqhidckeDfQVQxdzsONDNXDGBNFBRMdWMTowoJTgAvnlnswTcNIvnriZelQuygtZhNpVSsXRwiwcIssiDvy"), string("AynpOGYV"), 1476649730);
    this->tiJRQoZZ(1376342835, -1108943230);
    this->DgKQWFplGFDS();
    this->QeZTIpOvmmFVGo(-200599.13213389795, 1225611117);
    this->QWNKG(string("fwaMWxbdRPCyfBOdezUEFbirDnSiuJacErMCKTXzaoWMZ"), -620662264, string("PeePRdUoNUqfUdHzlJpySrxakoiTNykRHHgEQPsZIyualHtwJTaxzIzPgNmHSneGbhjefshkjkPUzZxBzJfGebToretuxakbttgsACkymWjqHYCMJZtBaOnUVgQeCNunBqxOjabyRiKTjHADHLqicr"), -1030750825);
    this->fulOMNTCpoMgnfzn(true, string("YaeBGrEsGTeXXVBqWMdrUFNIaIbaGauzaNpnOLIDJlWHHdwaiAkjFTVCeuRgYdiJbsoDmCAQZxUvMDvbGzPCqdZluIXkgPjTHfSeLBaITSkEZCXIfAdwMsVTXDkWrlILpFpcBVevpLrlgndGuKtZQXbWxJGwZuEVOtKiWbIpCaAxYKJMHiwsmKUOhCAjzETErmDFCrUeOpXgSxBfKpCRSYmTTlyukxfrRBDWh"), 1413642805, string("lsSQYSQvgdUALf"));
    this->tRdIx(string("TaBMfyUnUGOZDHALWfPRrnFuCUETpJRygCfYwKvzXcgRoyHTpDuPZXJGZhjBSIiHgzpHihYcPfNbqvNbQIdMYMwhtrwlphQCwMzzv"), 407194.2843862357, true, 1076143475);
    this->DqIrzgamqPWBSVlB(-25267.550024024575, 424772091, -2125502284);
    this->TsUSTdkXxLG();
    this->XERUKDYWEA(-1194366316, string("qJkvSOWLryVXUkfVPEqUsrIenqTsZIPkOoJgTYHtNn"), string("wBmYbJEybnOruTpJddwTiNOnUdzOiEmkLJFqnmKyqmgVxksEYbZbTmyBNpRScghsnejByMadOYCXpzrllEbvxARPbPqSaUSBmIuYIAodFOKSTIAdVYLuwasWXeeKHLCSJkmSWPTHjVvOOfGMsHSRdFzPmvBkcbmtsbSABPzoMuscYlXXbHeAZghJmUxcFNsjvByGYDvHqtwCHbbCaDSDFSoZPsjKp"), -601792.6354996536, string("fdtxgXKHAOnKZVZYbbVpKWSYalGRsoXyCPDgViJDqUVSoAbCyNuKKyPGxOiXAVihfYOQYmitaHgYorGkwWHDCasfHaVwtGAIQaObkBEMGpjmwPKjojqNEcOquvitKsJDVQUeFlQLEIDMbDkxwHpFuqeZdQzfzoFaHpeKIMVRWGXEgQHBHdRIgVaxigfGYePYlZJadLkZWlxDYHGWRUDnWzWAIqtCcWxTQMoPXBZ"));
    this->WpfjRW();
    this->AxcxYrkcRooM();
    this->HkRTTYCZPMv(string("EaYSMFRdhjjhDruwGYiibjiQZSGpPCffLRWTYZUJpvnXBjGhyWbRLITkmIGrTQJCkmdKbPmSltFtYjCmzmvccfjRhvDceIIlAcgSAWbvVSIopwTNbucAMVCFvReOOFMWztNQNisQeHhbfxUTOtMinnFnUSyyaoIiKoTAsFgLLasKpUaPmkC"));
    this->UKgDeYlNJmJG(-70198.87712513277, false, string("hOygdnyFAUjExnKgtGoeZbFNFvVRdlYAuSATysmldpktzhVEXJvMabBsyiXhATlmJUMTpNebLkSjCRaScfxrYjuVQgaMcMVUNGebVjhpfjoqyiRhtjBqlqQOhhpvEiFqCXsEJPQOcofzLguMOJSMnwNkZGwKfQLWBPJorGJXjJAXklmugQnQnHGhcTVgFRuYcKjiRmrbdyYLCKEzLsnnRnVVQcjIYDzsiiFMUBZjWczlO"), 1116823911, -511095676);
    this->xkmAk(string("AFKZADtedISNHcwQzAFTeaPcSKIyeFHM"), -719155.8845701392);
    this->yAyJWjHSEH();
    this->bMbeahkOQllXUby(string("zpMcCkhzJlXYBjDNaLbbBgmvevYhYPZqVwwO"), string("hOJCYCPfEajpDFicfMkEWJWgDXIGolegwZJPSHQdCBHkJrBlxQSyGCHfoxoaZLagDeWgJridbvagkHQABhKqFsjoipJSENKnAriEqIQvsnkvenJsfuJgJTRghlEAIXurCBxbixzWgDhqRdDcXUCTYvPUZfADpWmBYUAtRpuyAb"), false, false, -1792134214);
    this->mMRmGSpkPVnBXAg(string("eBmmhfjJrSwlMhPuoTmmuyOrYvVGjNcaThcPkIjgGiakEhKeJawpQCsMqwnyybuygicXCmLjyBirHIkhKsGXPPIknymrHsPbvTcOHDPYYZfGBHAkPBBlnkFuFKDtwfMBYdTEzQeelOldeBkaBrQQyUFkRtiGUNmhpAMObnkyntRsiwSNGDKLqfSEAHhPdAUstClcTGwpXuwxBKuSmdWenXLOPAtndZQEzHdTjBsQRMpylKQmxY"), -800486.8232182632);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tuMHuCWGKmeCCeSp
{
public:
    int fTpLf;
    bool rolNGCcJK;
    int ntOHCdXzD;

    tuMHuCWGKmeCCeSp();
    int SkzjlZTMevpYWvd(int mtOFXogxQlE, string tprYdHmYhEQpdT, string PrbEGzqPKNMtsFHA, int WThEDzjRsIpden, bool ezpjUqT);
    void iQUUxIWKjrxYjz(int tFTHQ);
    string BWgrgn(bool egflwUlvAJiAWvv, int TCUZpBchBuIgVlVE);
protected:
    string ByySalTVCe;
    bool BHxQgdZgZgRHw;
    double nxbdzGufmnZF;
    int yUhgYbQYJPDNo;

    int ITskupRcchs(bool qSSqDg, string GkUUFgxzUO);
    int XomNJVnKkme(string eMUjXrgR, bool drTUgNptsM, double TuWLVFBuyy, string JlHzeN, double daYWmnOAR);
private:
    bool INeif;

};

int tuMHuCWGKmeCCeSp::SkzjlZTMevpYWvd(int mtOFXogxQlE, string tprYdHmYhEQpdT, string PrbEGzqPKNMtsFHA, int WThEDzjRsIpden, bool ezpjUqT)
{
    int FPGoKedhoV = -1153490152;
    double YpGEvIKRcHK = -89506.39035493607;
    string FYoIDOiuaNEC = string("zqsTbPCdrclGqtQqnnTQhVzrXBjurxjTPqENiHkvOGjkaszFEnyhqSPCmVqdOQSkcQYRiXBXgWXpWrPsbdHNAcLeSdaAOYKUbHAcwUXqMSEiTOBoVzAZDvnWHHdtzkSFRLGeSxrMrxgpOehNBjyIkbcqkaKzZbRIZptCTOyoUSywbofEoCHlmCPnPrzAoFQbRMpOpMkCGhlvrDocDdHuUqYPVCUsOVPCVRXrfgcRkVtamItaggtY");
    string EBssXRfsiawUKnFR = string("hizMswWoHqiesWYNGfmKHFDrNXJMLvcXyFYczMlnXusTkaPECmTvzQKCHSdGRvxLPnkjhkTLizyHWzKnuodqDDQZJcozXonmMOOHUyyDePYiuDOSWNRJlwHbUoSHGnJBPjgTsiDeXpDIqyFmiLyRAAbMOZnOKusfIOaQgJzhRXZYWiXJhc");
    string xCCzZtVWuf = string("RsRQUqdqnjxInYxSdlEXIbaqzKnoLNinScnFFtKMGbGwejxIdJJkATxGwDbmnzzymGFBLqeozIMHLIgKtMWQrlOOOaYMCwWoiDQDHgEYZKuLlCLlCFAWNphAlzdhIFYXqPKCKpazRbQxDtEhMnnDCYBKmxEzUTGpqBqOZeqGMFMOClzWSBumrGdHxwspCztDQBXcawMi");

    if (mtOFXogxQlE >= -1152666547) {
        for (int hRIOLKCqFN = 1394933486; hRIOLKCqFN > 0; hRIOLKCqFN--) {
            mtOFXogxQlE = mtOFXogxQlE;
            WThEDzjRsIpden *= FPGoKedhoV;
            xCCzZtVWuf += xCCzZtVWuf;
        }
    }

    return FPGoKedhoV;
}

void tuMHuCWGKmeCCeSp::iQUUxIWKjrxYjz(int tFTHQ)
{
    double gzhHyaHPZZixSNw = -640582.4985433827;
    bool dlkLPOokFFhOltt = false;
    string wiqyhoewkW = string("uMCrctvDJjTPAMZdSYbQzVSowfiNzkncdfzHoTGZlNCOwioWLyXaAffLKpeyeCsEkZHrqKPDnMBLBszFgbKyinjLJBjbhFLZitCVRjqqVhzUUdSeoyccrYYHIWlKTsUqljaqcKbFyqvWXVjHCUaHSHhE");
    int dOGyaUtlcBtPU = -1815035254;
    bool YHoDnJf = true;
    double uhoYHcWMMxjjewL = 966091.6749482667;
    string jylsR = string("WclacmXrHqkrznSgVuFghkyurMmiqOXZwRNoKJlaRutjzUTipmnRlClCEOtGCVmsCimITDDHpOArbCqkOBsRsCfsiRTAXeRWeciEWZccjsOmvzrMsoXaLbjccVovcvBiuYzjXCjhkFXGobVhTAhzaMpvTHgXicYIaPhmGdsUnsirC");

    for (int uqxRSOSU = 1670850544; uqxRSOSU > 0; uqxRSOSU--) {
        continue;
    }

    for (int vURgDko = 429924903; vURgDko > 0; vURgDko--) {
        YHoDnJf = dlkLPOokFFhOltt;
        wiqyhoewkW += jylsR;
    }

    if (dlkLPOokFFhOltt != true) {
        for (int WitfZUjsSXD = 1600615105; WitfZUjsSXD > 0; WitfZUjsSXD--) {
            YHoDnJf = ! YHoDnJf;
        }
    }

    for (int kcTmrBoPfsNzYsS = 1914766342; kcTmrBoPfsNzYsS > 0; kcTmrBoPfsNzYsS--) {
        wiqyhoewkW += wiqyhoewkW;
        jylsR += jylsR;
        tFTHQ /= dOGyaUtlcBtPU;
    }

    if (YHoDnJf != true) {
        for (int GpGoBL = 146013198; GpGoBL > 0; GpGoBL--) {
            YHoDnJf = ! dlkLPOokFFhOltt;
        }
    }
}

string tuMHuCWGKmeCCeSp::BWgrgn(bool egflwUlvAJiAWvv, int TCUZpBchBuIgVlVE)
{
    string kFoLAw = string("NFrrGPpahUPWjtVgeJRxfwUtvhBFnzTxMmaZksJnSHVjSTmweAHUBjJzkHsejkPDhWnodvlEWIxCdIczbtUlhKGNSxOLmTaVLUkdLegkIsQTtKObjEWyccRlOcGRpifANYmYuxTcGlakgPZOxcfJIWtKhygUCEtGRyERQCQASWNzwSZnjPOBdxsOWmsTV");
    double bgBifZJ = -1022872.3112307633;
    string oBRUJhaTGWjgFDF = string("ie");
    string NnYOQnsptv = string("rjKJqiuoxrEJTxDYyOHSTfHWxruijIxIXfARqKYUJtDvJEmCe");
    bool lOKqDUjvtFC = false;
    string puSNoguPYXkPu = string("xfpNngoCbBTETrkbXWLJRLyMBuJGobcsiCziiaaGXwoROWGEFAhraBSaeLVYgDBBwoRXpBAgUJbYuQjbQyAqjIlHVadOUlHCGmqFbdHQjw");
    string CSDuymDujqaHXWG = string("yvuoEicZPDJAWsiRVOEQfSReScrqwxQfwptDVgxroMARZPfHbafWoSaCeqBjoxEOhcfWaSkVyfMWNYglnFqpDvaJOgqxaPyaURSdREoFMeXnSrNwXYIJzkmcgMwBJIzzReDJbG");
    bool XnalTMeBT = false;
    int gVmqyPeFNhP = 622527302;
    string xPlObcOCbaQXVWw = string("zpZgbeGONgOeNsUODWBWKIjUrpOmsYIkQYSIFDkCyUzmbiNmlSjCzOguulHNTTYTcAukxePTSyMJTWbZtJWSBubjTPNjgOOVBZwMnfSffOlIOvSbddEPgXRCrTaSWntUYyzpEW");

    for (int mUGhu = 1708198711; mUGhu > 0; mUGhu--) {
        puSNoguPYXkPu += kFoLAw;
        xPlObcOCbaQXVWw += oBRUJhaTGWjgFDF;
    }

    return xPlObcOCbaQXVWw;
}

int tuMHuCWGKmeCCeSp::ITskupRcchs(bool qSSqDg, string GkUUFgxzUO)
{
    string EIkcmQh = string("QITKbxRZnhBXJpksbnCufLnJyjjjHzCoVzHmUOUdvWYdSdpfVTpufgmCFtqsWqYHObhjBOiyNPvAbUgqKYUyRZYbKuTBjsKORyzEFVoXNUfRrHfLiasgqpBTyhgCrhmtduIGklNJnTGFtVhJnSDSuRSrbQcWXGJlSPSqYPohlwPIdVBMcjhnFcyXpMpHewTERtnv");
    bool VpvNM = false;
    string unqUxlJdQ = string("RSYIbYvGAyhuAZKJBrFZSVmcOtZkuQkGJEQkRnfDJJLuoVdHPbCgbYMIctSZsuAQfKlvLugSoBmaOrXGhWnsVHbEmTFLJOtcUCTMPULQEKajHTLBFqsTAzqrJCtgYHoNMPbwdtRc");
    bool UHoYIANpxzfmA = false;
    int desHWdqm = -315440110;

    return desHWdqm;
}

int tuMHuCWGKmeCCeSp::XomNJVnKkme(string eMUjXrgR, bool drTUgNptsM, double TuWLVFBuyy, string JlHzeN, double daYWmnOAR)
{
    string fLRFo = string("cAJOVPAMRdeNRaZexrSZbZmUvqnNdbAQcDIZKGIilBqAobJeRIaOPNzpDaqgVorZWiXAjwEphXbzaDFQSSWDVIIiHXJQzHslKFQFamjevxUspDuDaafUhOVcDJNeCgAmMPmoXIQIaPxLJkwRGJuGActKYLplxKnyDRYvAaaKVNPvkTJJWwOKLavtBqBrrYcNP");
    int jtintDFUW = -159751594;

    if (fLRFo < string("HtgNKVymTBpotOpSrmEyVaZOxGvKrVVtAsaNVbvEKwGhUVnVeoXtHWMqQibBBZlQYtMehlsYfAkwQQDokUeTjPDXZlrUmABkVOnYYQIysyJdTZBDdynsrMleJPFEjJpZwwqYSqEHhoUGAvmeuKICfZWzaDwEoXWHWWXlEc")) {
        for (int EPUTAKTeHWK = 2061771267; EPUTAKTeHWK > 0; EPUTAKTeHWK--) {
            continue;
        }
    }

    for (int xqMvEGwgJNwoOpnu = 1055496130; xqMvEGwgJNwoOpnu > 0; xqMvEGwgJNwoOpnu--) {
        TuWLVFBuyy /= daYWmnOAR;
        TuWLVFBuyy /= daYWmnOAR;
        fLRFo += fLRFo;
    }

    for (int llWXp = 1724647957; llWXp > 0; llWXp--) {
        fLRFo = JlHzeN;
        JlHzeN += JlHzeN;
    }

    return jtintDFUW;
}

tuMHuCWGKmeCCeSp::tuMHuCWGKmeCCeSp()
{
    this->SkzjlZTMevpYWvd(-1152666547, string("jIoJVtYPXDkaTzJWmQwKQGRWRHTYdxULddvFdFeXHSpVFYaVMkBovJLmjjnBpNOgQEvoLNfqIUYXtbHfgVGpXwxNoInLuTIeuxHAFEWNuIOmoDAEYAkefStYkajwcPrBlSkKcMytDFkWivAraOcyewWEJsbxkPKeWnfnHJCKlmBSkzEqxCNcjXpFqpRcDdZYZOyufYnfBernAfFxesLRbWUYOFzxNmkuyrkKRJfaceOdbKljJeplXsApTULS"), string("dkMQETkIDhERNgWKb"), 192533836, true);
    this->iQUUxIWKjrxYjz(-670441966);
    this->BWgrgn(false, 856227648);
    this->ITskupRcchs(false, string("RQwFblhOUOHbmALrnMIgZfHPbuONANgBDZOYhRLrtgarSLeDJtlwehAJfKtnOZPMbqXQKNWZBMrGNMqYGfPHrxpSXPoVZAKYxLzWIYhaoGnxLthXAHfhgNorsHpUMPLVlUPT"));
    this->XomNJVnKkme(string("uFPJ"), false, -431683.1223324358, string("HtgNKVymTBpotOpSrmEyVaZOxGvKrVVtAsaNVbvEKwGhUVnVeoXtHWMqQibBBZlQYtMehlsYfAkwQQDokUeTjPDXZlrUmABkVOnYYQIysyJdTZBDdynsrMleJPFEjJpZwwqYSqEHhoUGAvmeuKICfZWzaDwEoXWHWWXlEc"), 895143.8057418098);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class URWUNq
{
public:
    int VMlqMAbOZHZrF;
    int uEplRQ;
    string dZTGLYUjzBlaE;
    int HHuhHvRejyFRXOGc;
    int MjEEaipBYKF;
    string PJTzYiYteNpxKtv;

    URWUNq();
    double WgQTgXKwLmGqj();
protected:
    bool vIDTPyjDm;

    string sYCzMFmIujsiqgN(double dhmTmmSFGDpPUtR, string BZkaKCkFvIycN);
    void MGsaHoKKLmtzVFo(bool JExOlGji, string yDmjBlCACnJ, double IdrkoWqNgzXZZ);
    string izwcO(double pvtypbDVVgOvOAbV, double HtLhYn, string hNPuPeZis, int lFwkTWbIyHMZ, double JOCaluxpgKPtYM);
    double eJPYHSa(bool zjJXUyu, bool hgCUKwTbYuQ);
private:
    int dwUiMiIqyvktHp;
    bool bSIsQ;
    double ItAfQgVeDvpwhUOa;

};

double URWUNq::WgQTgXKwLmGqj()
{
    double TzesvcjCY = 343937.8070981028;
    string nwjdSsZv = string("aoiZYgGHpTxcLYpJnBnIVSeNNSAVpPygFtSRkcQvPDEzxmJMrzKvBTaUqGkLcbAloMYhABPSpOBTBPztBplkPoxZtjtBWYarAzhjxqCQhyfsTHDRdicXWDXVRcrrXmAaGGFsjhKDVDFfwpIAiuzUmMKgYCgsidWAKIKDZItACuzTAyNfJmrHFiGTGncDhLKMJUkHs");
    string ANuFxR = string("wdrtScVenNslDRJZNPWNaTUBsCmrYZqODIZjPEFTTixTObAPZTngEQedakDxgMGbsnXeKIhntaHdxhUjTEfDI");
    bool SbBYvJQQqOvYqX = true;
    int vOGlG = -1645326886;
    int ETpafaaFlKB = 354402395;
    double TNiccquj = -148087.9524727812;
    bool PmoCFZjUcSyskwv = true;
    int izHJkhqhzwjVWs = 1260722113;

    for (int FtkBXKmqKhhAOK = 817240985; FtkBXKmqKhhAOK > 0; FtkBXKmqKhhAOK--) {
        TzesvcjCY *= TNiccquj;
    }

    for (int VCJTvEgidcv = 632519965; VCJTvEgidcv > 0; VCJTvEgidcv--) {
        nwjdSsZv = ANuFxR;
        ANuFxR = nwjdSsZv;
    }

    return TNiccquj;
}

string URWUNq::sYCzMFmIujsiqgN(double dhmTmmSFGDpPUtR, string BZkaKCkFvIycN)
{
    int kWqpdG = 1441585700;
    string ZOSVacxSXGlN = string("sDXcmiUHFjNdoBFqlkjxBBWLpiDUFdZNXHHgETnkGkHMFoarlTUCTztBCHoYHOfpJSNIPciCAYRjQaNgJnBSlKjMjnnvzZcRqdYzyYFwQjaKUuNPlhSMzQAQSJeeFnZNBZvwEXrFSYeKVDwXZrnZkpTPaiFzfNwDeOENcwwpQotukXbX");
    int rQRIpWIQkZjR = -1273462963;
    bool QjLLzYktpzo = true;
    bool NHYwFWsaj = true;
    bool QrSvMRSchu = false;
    string TkZyQ = string("CvGQuWQNiskZCyqumrJqfNzeFoSQcZttJbWIIUMiavCKulRPGpTeHrFpSFprHdlCJailFlwdqqXROtnEhELVRoCDYjuYrRxzqKCdFJrTqxTVQyPghghrAeqZidMGqwDHQHXQkqtkKGyZFPDsM");
    string shmhCcO = string("EaGIWeqiXRCPwDILJOkYZfOybNIRpUfwXTPPMYHQwONiICOrlJnlSNcrfXtPqwbORVRKfhBlpZOtNAeToLCxaVEpCqpXxKBCeMSjiPZehOLDygAnfnHrLVAIkeDtWJkaxsEqUYbcRNudSwdWcHtbTKBzgKBrwiXsJJ");

    return shmhCcO;
}

void URWUNq::MGsaHoKKLmtzVFo(bool JExOlGji, string yDmjBlCACnJ, double IdrkoWqNgzXZZ)
{
    double NnxAl = 453672.4399342263;
    bool JWJWBbxxfilXUl = true;
    int YTifhcEuQuN = -1149154808;
    double akCdmErZXbbC = 540103.7221216775;
    string LQRcjTPqjifNTKiy = string("KKjsYbYqPJeoqtMozazzKuFuowjMkJJqYvhRtpDRZUanRaRtB");
    double kCdVmoOkGztSTHre = 1018581.7054143833;
    double iTPkCmn = 912399.0022722349;
    int vLlUoMIkrnxyjM = -2062702299;

    for (int wIKbjRDYRHAhV = 2034431728; wIKbjRDYRHAhV > 0; wIKbjRDYRHAhV--) {
        IdrkoWqNgzXZZ += kCdVmoOkGztSTHre;
    }

    for (int kfMcSVFUSY = 1997589258; kfMcSVFUSY > 0; kfMcSVFUSY--) {
        akCdmErZXbbC += akCdmErZXbbC;
    }

    for (int lwukPdIbhIOkUE = 810810186; lwukPdIbhIOkUE > 0; lwukPdIbhIOkUE--) {
        akCdmErZXbbC += akCdmErZXbbC;
        LQRcjTPqjifNTKiy = LQRcjTPqjifNTKiy;
    }
}

string URWUNq::izwcO(double pvtypbDVVgOvOAbV, double HtLhYn, string hNPuPeZis, int lFwkTWbIyHMZ, double JOCaluxpgKPtYM)
{
    bool ImsVcPDSLnilG = true;
    int OcKTauJnGmXYO = 948931291;
    bool IJXCJFMiQqF = true;
    bool LccCqtJmMMp = true;
    string JFreoYR = string("MGLXyMgPCKSECqtByZdAMHbEJZHOhyuaqilLgQgxKBsPUnscKMvwqeAofRVrKgpQGeBaIkRmqAANOajxMjsCMwfEKtWzTizXwqTpwyWDJVafQCxUgJgvrYQQORwmmiTGwIzZlNLMwtachWohtYYmHugLpCETQgxEnMiVqrwfwmoUskQvbRXgFao");

    for (int VeZsVclvSEHEN = 55449161; VeZsVclvSEHEN > 0; VeZsVclvSEHEN--) {
        pvtypbDVVgOvOAbV -= pvtypbDVVgOvOAbV;
        LccCqtJmMMp = LccCqtJmMMp;
    }

    for (int ebbLIMKKeDI = 189325625; ebbLIMKKeDI > 0; ebbLIMKKeDI--) {
        LccCqtJmMMp = ImsVcPDSLnilG;
        ImsVcPDSLnilG = IJXCJFMiQqF;
    }

    return JFreoYR;
}

double URWUNq::eJPYHSa(bool zjJXUyu, bool hgCUKwTbYuQ)
{
    string YexmiVzstHr = string("lJFeOHHqCzWnUAqHESmdTHisBUtQggncAsmGzLNEQdAbmEJpvvjnggoYVKBXBwJbpAXDtMACWxgLeEbPpWmsZDJLAJsfdFbVPwcJYlbLPtMNCnnFfDjwKmiPPEMULumiFmNEucKScWpIWYnQSeyPaxUQlCMyDgLkSpdXyMkWOkwMAxGdfFZgIAxJpcAxqhqodQrzjtiUutpThmRxv");
    string GAabRPwU = string("EHvBzhXtUIkdXwPcRGUYVnccoihLFdTfaixbcaKBgpAsaLYnJCrundLOGxdouMYtvmqXZvBGQYCOZnVfGJErEvdGUNeQoXQZQRmVlubyUCnQOTbzFqhdihDqIdSqIcFdsxEsliAXXAQjFpCgaILbXBNDxbQCfOhEUPXAbKNuwKtlbodDRTDwIoAYDZozQxDHkEYFfW");
    double kmIaLtPac = -992495.3741365625;

    for (int nypIFeWiwGzOTjeV = 1913041367; nypIFeWiwGzOTjeV > 0; nypIFeWiwGzOTjeV--) {
        zjJXUyu = ! hgCUKwTbYuQ;
        zjJXUyu = zjJXUyu;
        hgCUKwTbYuQ = hgCUKwTbYuQ;
        kmIaLtPac /= kmIaLtPac;
        zjJXUyu = hgCUKwTbYuQ;
    }

    for (int BVORDUcBZeVdWj = 62272933; BVORDUcBZeVdWj > 0; BVORDUcBZeVdWj--) {
        YexmiVzstHr += GAabRPwU;
        YexmiVzstHr += YexmiVzstHr;
        GAabRPwU += YexmiVzstHr;
        GAabRPwU += GAabRPwU;
        YexmiVzstHr += YexmiVzstHr;
        zjJXUyu = ! hgCUKwTbYuQ;
        YexmiVzstHr += YexmiVzstHr;
    }

    for (int vAwXuAaXUeBOsARH = 227858168; vAwXuAaXUeBOsARH > 0; vAwXuAaXUeBOsARH--) {
        zjJXUyu = zjJXUyu;
    }

    return kmIaLtPac;
}

URWUNq::URWUNq()
{
    this->WgQTgXKwLmGqj();
    this->sYCzMFmIujsiqgN(721400.0930729595, string("gmFCvAbhNNrlTodLENdZzSUPCySyOIpZeBdBbcXoiLzmHkSayqtpDDHrkJEzMZIGVirRkozfTTFxbKODHRPIGvNMubaKsoJTtEiWYkslhWicoBJASSjhuFlAHpHbxhVSddzMDyClHYngViCSyZXDtIuoJLRbXLZsbnjjGhIgYsvhCLCRYKTIGjHjGFpAJGyQyuScZLKCQ"));
    this->MGsaHoKKLmtzVFo(false, string("iQeARaaYlDdmvINoNGosJtvQTbImsWiyosqjXNsIVYYrOhPgDwqtQHVtNMYRBMOgNRULyIHGBMnNFJTJbujhEsUGcdbGkZcSLTIbpPrrJDNsZkyDmqBgGAdOfVvSxyRLRJRjqgjtZpAweErpNHfEmzvmJsyenDcZyFOhqhaAVvJwoYSFOECiOsahrROeLIfAHEYpnnnqtajFzFNLGEzjWuSBeJgrGTYJecrRHJKjiacfUfX"), 856479.5557216139);
    this->izwcO(39310.67140723948, 38085.73795358439, string("zurdgIRJlFAzpHPhQsqtlKeNiPqCWNfIjBxdlFgCGyQtNayveRffvmoEQJydSwPLuYwkmexyiGorHOGIByyNGVZKWXjBHFOiiWTXrrFPPrbNSPtQqNwEVXGbpfZempjGJAKGTzrdRWiodhFBMxUPjAAxFsRZFVBqVYcJNvZfJhEJfOAMidtltZHtkTNlwMvKyLDYKbfrgiidcCmtcYsuyMXNHJykAnOHLwwCjUbikoEJHUMbQatwYYWJIwNSvr"), -1277307930, 366825.21892765554);
    this->eJPYHSa(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jDdTkriWeiMtu
{
public:
    double GEfcAvoc;
    double LNFQeiifKBy;
    double untRlNQImJ;

    jDdTkriWeiMtu();
    void PEjJKRBOTRMkjLFo(double IWfdM);
    string TGBJoQs(int REyNBo, double imoPBUjeJmNfD, string qLdDiWvbBDkBHwu);
    double zbIyKGWRktEmn(double LkrDecmc, string kOaHqoGnfJbklE, int qraDTMQkJmNVouY);
    string NGyQtgfnLIhEhhc(int daZDpKeUzKKnFC);
protected:
    double tJTcYYiyigZaX;
    int ObamiFcIa;
    int KmqwGN;
    double dJwQjVRzaSNYv;

    bool bdUsUaprRGHi(string IHSIMoSF, string mEDpA, bool jvcaFY, string jTPqFUwhWOVAMpxJ, string JTPIrkSM);
private:
    int rlKpKIebDFl;
    double aEvyLSFeQ;
    string ppPzyewTLM;
    bool fawYMFlOPMGnih;
    bool itjQXNVbcnZMDT;
    int wAnZP;

    double isZhUREn(bool HXZwxY, bool NlemEeN, string uuSapRyS, string WoCswQVjxAZmR, int MhAYI);
    void pouad(double MumLZkGfzxZcug, int rBYgpymPfUAer);
    double gFPMLentWzDm(string liqPdIKGPA, double PCgMLQbMO, int VWDBIoKZaFLH);
    int aqCJSEhSemhkrO(string fwADGuSuTH, int HrBWNlgGR);
    void CAjvIJgY();
    string fTopuqOVKyeUdYj(string TYcSzYUVX, int hvDlbDTmYejvxHj, double QcqutrqjGkHYzyj, string xcdtFzPKl);
    bool PJHtNgYStuaTsXU(int zhkRZmiX, int MjDhqjmIe, double fkSjbn);
    int uNSYbejEiv();
};

void jDdTkriWeiMtu::PEjJKRBOTRMkjLFo(double IWfdM)
{
    bool NHIALCPULs = false;
    bool YrBrXkROrGXp = false;
    bool cbhAGihZ = false;
    int jQunXtWXvK = 521702156;
    int NFlaFzYmvFNESU = 1823248824;

    if (cbhAGihZ != false) {
        for (int rcXMbFCCjW = 391613079; rcXMbFCCjW > 0; rcXMbFCCjW--) {
            YrBrXkROrGXp = ! NHIALCPULs;
            NHIALCPULs = cbhAGihZ;
            NHIALCPULs = YrBrXkROrGXp;
            cbhAGihZ = ! cbhAGihZ;
        }
    }

    if (IWfdM <= -38609.2345713014) {
        for (int laXJqhGTsq = 1743387339; laXJqhGTsq > 0; laXJqhGTsq--) {
            NFlaFzYmvFNESU = jQunXtWXvK;
            NHIALCPULs = cbhAGihZ;
        }
    }
}

string jDdTkriWeiMtu::TGBJoQs(int REyNBo, double imoPBUjeJmNfD, string qLdDiWvbBDkBHwu)
{
    int ekgWQgOS = 995896138;
    double FsTzHgDYXydv = 282950.2344096137;
    bool SvsRUZegA = false;
    int rCxqQXbyirqENY = -89141758;
    int jOfNnMGhS = 166234265;
    string hJQMIhBQvyzsGOGn = string("nWjbamUWlqQkEDzpEmvbbDAIPXWdoiioQrdyxsbIhdkXxsMuiszaavktdFeKFziAicfboyJIVqBbnvPXgFJATctQcDYCppvoQmXOBidJWfgEtQkrTrlQWNNHv");
    bool ihvIr = true;
    int iLSJjrHdBXjRn = 942679797;
    bool cxtJrs = true;

    for (int WrLyvGpnTtREdSx = 996084426; WrLyvGpnTtREdSx > 0; WrLyvGpnTtREdSx--) {
        hJQMIhBQvyzsGOGn += hJQMIhBQvyzsGOGn;
        iLSJjrHdBXjRn /= rCxqQXbyirqENY;
    }

    if (ekgWQgOS > 995896138) {
        for (int uyJcwtXcgdxNp = 749348955; uyJcwtXcgdxNp > 0; uyJcwtXcgdxNp--) {
            REyNBo /= iLSJjrHdBXjRn;
            hJQMIhBQvyzsGOGn = hJQMIhBQvyzsGOGn;
        }
    }

    if (cxtJrs != false) {
        for (int QRiBvvgJNb = 646525922; QRiBvvgJNb > 0; QRiBvvgJNb--) {
            REyNBo = REyNBo;
        }
    }

    for (int LLKVEBtVYuN = 427039247; LLKVEBtVYuN > 0; LLKVEBtVYuN--) {
        continue;
    }

    for (int NhewtEaCig = 505641866; NhewtEaCig > 0; NhewtEaCig--) {
        cxtJrs = ! SvsRUZegA;
    }

    return hJQMIhBQvyzsGOGn;
}

double jDdTkriWeiMtu::zbIyKGWRktEmn(double LkrDecmc, string kOaHqoGnfJbklE, int qraDTMQkJmNVouY)
{
    bool dxVxpdczSYsrqm = true;
    string joAlgiKLNWQnQYBG = string("dEaBojRwwTWbZgOfxaqLlFLCkAEvYerGNOglorNMFpODDObqtQdEVhFXNfqBwRQfWnmYBHXRkhZGTApfaGTpESDiuutKcnUMshwLdlCUcsdHVSGDmASr");
    bool YKOqu = true;
    bool HfjtWBDfdAnCctAp = true;

    for (int VbfeREUPZmqAMiXH = 1213859964; VbfeREUPZmqAMiXH > 0; VbfeREUPZmqAMiXH--) {
        LkrDecmc *= LkrDecmc;
    }

    for (int CCQvo = 1557050467; CCQvo > 0; CCQvo--) {
        YKOqu = ! YKOqu;
        YKOqu = dxVxpdczSYsrqm;
        dxVxpdczSYsrqm = ! HfjtWBDfdAnCctAp;
    }

    return LkrDecmc;
}

string jDdTkriWeiMtu::NGyQtgfnLIhEhhc(int daZDpKeUzKKnFC)
{
    int vJXBI = -2092979418;
    string UjPfPvWJAGka = string("wkFNEmvTLyGzgaLlWOAaZWgNrvLsGCOkrAVWUf");
    double fDWZbGZ = -671905.1903693073;

    for (int fmoMbeNl = 182358158; fmoMbeNl > 0; fmoMbeNl--) {
        vJXBI += vJXBI;
        daZDpKeUzKKnFC *= daZDpKeUzKKnFC;
    }

    for (int QDzzqFuMPWZ = 1560393489; QDzzqFuMPWZ > 0; QDzzqFuMPWZ--) {
        vJXBI /= daZDpKeUzKKnFC;
        UjPfPvWJAGka = UjPfPvWJAGka;
        daZDpKeUzKKnFC *= vJXBI;
    }

    return UjPfPvWJAGka;
}

bool jDdTkriWeiMtu::bdUsUaprRGHi(string IHSIMoSF, string mEDpA, bool jvcaFY, string jTPqFUwhWOVAMpxJ, string JTPIrkSM)
{
    double eWAzwPMeedIEUPj = -627798.5523042438;
    int fOmmboXZpwuLIDhv = -1845504649;
    int NwHZFxBJCXdDLpC = 1602911715;
    bool dFGqUCAvJtHdgpg = true;
    bool TmjozMnliLae = true;
    bool OQsOFiOEAn = true;

    for (int prmcDeWEQEK = 1629515984; prmcDeWEQEK > 0; prmcDeWEQEK--) {
        eWAzwPMeedIEUPj *= eWAzwPMeedIEUPj;
        IHSIMoSF += IHSIMoSF;
        OQsOFiOEAn = jvcaFY;
    }

    for (int gmTiL = 134827439; gmTiL > 0; gmTiL--) {
        mEDpA = mEDpA;
    }

    for (int PDoMh = 1154576890; PDoMh > 0; PDoMh--) {
        mEDpA = IHSIMoSF;
        TmjozMnliLae = ! OQsOFiOEAn;
        jvcaFY = ! TmjozMnliLae;
    }

    for (int kMWAQmwpixtol = 292568838; kMWAQmwpixtol > 0; kMWAQmwpixtol--) {
        continue;
    }

    if (IHSIMoSF == string("dVJdBunnNNctptvNrzdqrWO")) {
        for (int SqHuTmdRFqntTI = 838789212; SqHuTmdRFqntTI > 0; SqHuTmdRFqntTI--) {
            NwHZFxBJCXdDLpC -= NwHZFxBJCXdDLpC;
            IHSIMoSF = JTPIrkSM;
        }
    }

    return OQsOFiOEAn;
}

double jDdTkriWeiMtu::isZhUREn(bool HXZwxY, bool NlemEeN, string uuSapRyS, string WoCswQVjxAZmR, int MhAYI)
{
    string BUYjSysFn = string("vskChCHPRxJF");

    for (int ovrhnUBoAeGQI = 1214639175; ovrhnUBoAeGQI > 0; ovrhnUBoAeGQI--) {
        WoCswQVjxAZmR = BUYjSysFn;
        WoCswQVjxAZmR += uuSapRyS;
        WoCswQVjxAZmR = uuSapRyS;
    }

    for (int OUsoRthTs = 158064197; OUsoRthTs > 0; OUsoRthTs--) {
        HXZwxY = ! NlemEeN;
        WoCswQVjxAZmR += BUYjSysFn;
        uuSapRyS += BUYjSysFn;
    }

    return -139282.2929750614;
}

void jDdTkriWeiMtu::pouad(double MumLZkGfzxZcug, int rBYgpymPfUAer)
{
    bool nkZzSGO = false;
    double SDEJPDQwgj = 666108.053189991;
    double SXhKVj = 1001491.1525553665;
    double XaewNRC = 839320.719599949;
    double YfDQAIJlPXZAW = 89041.92218119092;
    int qPHACNrKc = 537451958;
    bool AkxFxFybOjPfSWG = false;
    string MSYgSNCSrPdhk = string("BkLBPxTKVfypOWmsxHRHMtNDrdKZSIATtWriVRrlQfIHnTHBCCaOeEjOZJcOqzlhCnXX");

    if (SXhKVj > 666108.053189991) {
        for (int rzCdUQZysxP = 167573766; rzCdUQZysxP > 0; rzCdUQZysxP--) {
            YfDQAIJlPXZAW -= MumLZkGfzxZcug;
            SXhKVj -= SXhKVj;
            YfDQAIJlPXZAW *= SDEJPDQwgj;
            SDEJPDQwgj = SDEJPDQwgj;
        }
    }

    if (XaewNRC == -353468.75304273004) {
        for (int usGsPNlZUTmNFPCe = 161877877; usGsPNlZUTmNFPCe > 0; usGsPNlZUTmNFPCe--) {
            nkZzSGO = ! AkxFxFybOjPfSWG;
        }
    }

    if (XaewNRC < 1001491.1525553665) {
        for (int NragRn = 1645983292; NragRn > 0; NragRn--) {
            SXhKVj -= SDEJPDQwgj;
        }
    }

    for (int khtltAgy = 974028796; khtltAgy > 0; khtltAgy--) {
        continue;
    }
}

double jDdTkriWeiMtu::gFPMLentWzDm(string liqPdIKGPA, double PCgMLQbMO, int VWDBIoKZaFLH)
{
    double cmWPcAh = -906906.446374763;
    string muUAqkQ = string("AJForhZicmZuwWLXFnqIBcymmZFQRwgvSbvZzEGgWhDHVitelaruVVqdZbyEwoCdyuOUJqNyZmreGcpnNNuOIQrNSglaORxNHKNbiSHjdiVuBazbdfKdIZYCFjHMHcWsUvQDSTbfMaeouxDOyVkstgjjUQWjndoTgMGwFNgkL");
    string WbtHDKPnn = string("hEDiOPVcZotmIDbISakywDMBPqvtrLzqqXrPK");
    double EhXAGpTvkX = 816422.6851662681;
    string nJgooTUhPvLfeex = string("xgrgwNxdepBoISSUBhdrYzgRLhIEFXIPPyUYBtNFsjXmeOBZOobQhsnoSlRJdpKlENmHtwVAQoqzJiwdzFrKjVQLKApFPqRTLmkiarkIblvaNmTSgILSJogmdnCEgtuqDpOOzdQeMRfvxkBuldpoKVEwqhsGJytFMPJZbUiArchjCpozLCLEldLegFxJpbovdlRfLnoCUwsuglPLiQvuMChqicDpvzqJBLwZjs");
    string OGvhmQZqpgzDMci = string("vzmwWHUXQibIvBmSykTnFxufZEGJDipNwDdjmZWOfccLfWNMUyFrqlSVzSXwuxsiAt");
    double mKyPmgcyLezCV = 539929.0984647237;
    bool dzTzkNEv = true;
    string cNmypTLKC = string("KqAcpSMTxELGfswacuqjYgU");

    return mKyPmgcyLezCV;
}

int jDdTkriWeiMtu::aqCJSEhSemhkrO(string fwADGuSuTH, int HrBWNlgGR)
{
    double AoGjJQf = -483849.45705456904;
    string ZFEobLdSBLGQad = string("zAJwMnLLTtCPEuvXcyMAjXFYUAsGrbpMTdaDpXCfRgKqqusGmNDyOUmFuUBraWZOKpXjJSSSrcqCvxSiBAHemrjjZOMyafbbRsWdAUhoFofEkPVGinapQYpwRoAMKlhYfeUGPjhgnpkByGQNJwy");
    int VurRMtPKsFwRmBSp = -1536987308;
    bool SGExQiY = true;
    int ugUfmrtlL = 1705314910;
    int mCjVxkPTLTZz = 2114004802;
    double KfqoWOHNc = 627498.6553716338;
    string IvgjbPkrl = string("YcCBiCpAqnuWLiWTTApOkBZlLCbCtpvVdwhVfDBLagKWWyqOkMNphZyPySXpvcRnNmwtWiVWDVnHwsvdPboOtHJpOztiEPHVYtENoptGOcBCKIxVUhHQXHHUlYCMxBpBccqBaIzlAHcUYAPtZGIehGmjcjk");

    for (int nZjGF = 1534801132; nZjGF > 0; nZjGF--) {
        KfqoWOHNc += KfqoWOHNc;
        fwADGuSuTH = IvgjbPkrl;
    }

    if (mCjVxkPTLTZz <= -1536987308) {
        for (int YeVFzVg = 600686770; YeVFzVg > 0; YeVFzVg--) {
            VurRMtPKsFwRmBSp -= VurRMtPKsFwRmBSp;
            AoGjJQf *= AoGjJQf;
            mCjVxkPTLTZz /= VurRMtPKsFwRmBSp;
        }
    }

    for (int QVcnPvp = 1039372099; QVcnPvp > 0; QVcnPvp--) {
        VurRMtPKsFwRmBSp += HrBWNlgGR;
        VurRMtPKsFwRmBSp += HrBWNlgGR;
        mCjVxkPTLTZz /= ugUfmrtlL;
    }

    return mCjVxkPTLTZz;
}

void jDdTkriWeiMtu::CAjvIJgY()
{
    int fXtUIrXiGgNp = -374668729;

    if (fXtUIrXiGgNp < -374668729) {
        for (int GDMsZy = 1612124982; GDMsZy > 0; GDMsZy--) {
            fXtUIrXiGgNp *= fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
            fXtUIrXiGgNp += fXtUIrXiGgNp;
        }
    }

    if (fXtUIrXiGgNp >= -374668729) {
        for (int sJmsKXrpmzeOBvr = 219154384; sJmsKXrpmzeOBvr > 0; sJmsKXrpmzeOBvr--) {
            fXtUIrXiGgNp -= fXtUIrXiGgNp;
            fXtUIrXiGgNp *= fXtUIrXiGgNp;
            fXtUIrXiGgNp /= fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
            fXtUIrXiGgNp -= fXtUIrXiGgNp;
            fXtUIrXiGgNp /= fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
        }
    }

    if (fXtUIrXiGgNp > -374668729) {
        for (int KwAKUIyONdlmB = 442173412; KwAKUIyONdlmB > 0; KwAKUIyONdlmB--) {
            fXtUIrXiGgNp *= fXtUIrXiGgNp;
            fXtUIrXiGgNp += fXtUIrXiGgNp;
            fXtUIrXiGgNp /= fXtUIrXiGgNp;
            fXtUIrXiGgNp *= fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
            fXtUIrXiGgNp *= fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
            fXtUIrXiGgNp *= fXtUIrXiGgNp;
        }
    }

    if (fXtUIrXiGgNp != -374668729) {
        for (int nEOZzxyslwdOwGnf = 1303925636; nEOZzxyslwdOwGnf > 0; nEOZzxyslwdOwGnf--) {
            fXtUIrXiGgNp /= fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
            fXtUIrXiGgNp = fXtUIrXiGgNp;
        }
    }
}

string jDdTkriWeiMtu::fTopuqOVKyeUdYj(string TYcSzYUVX, int hvDlbDTmYejvxHj, double QcqutrqjGkHYzyj, string xcdtFzPKl)
{
    bool rTYfbW = true;
    bool SniSKleViI = true;
    int ZGeeXWmTnBD = 536985750;
    string mgSGfISZRNUczCh = string("UfrfbHTGAmGIFGLYOTEEGEnGmrWfYWpPygEGhzfbwqvHVeSDBEGEIWtMBuyoGkLjbETJVmvjFUwuRugYVChrkREvlhMsVctgzyGIERPzbomENDyLTvkGbxOPITmQXbmYSiZFKWChCDLGcXDGgRDcmCOcNyUTgIoOIXoqKditxZOuhHTwqclWoUlfogPrdtTqxjrGosIfkinXJ");
    string aNMLXM = string("oYGpJsksgRfFnEWUTvcBoqJTZcncvviMjXYCpwFjqTGSPLigepUlovmrKoLxAWRWkGsfZuOFoaHoFUdiucgAZrZTZKUWgMsUgwbEbhDCrIakSYelTvqoEdSnVuXyjePDnkWYXWTuZuAHROxJSYQRljmAvtNvJApmxciatQXwLXELcSoDxnlaeGbPORnqgjbVkFMGRZknSMywgWEgInnwSNFyJwmURaSGWACmIuMQeNoghsXkBfWKIzMjeSRs");

    for (int ekbJsDMJVYPcTHy = 1379329828; ekbJsDMJVYPcTHy > 0; ekbJsDMJVYPcTHy--) {
        aNMLXM = mgSGfISZRNUczCh;
    }

    for (int JtaSvbn = 536972487; JtaSvbn > 0; JtaSvbn--) {
        aNMLXM += aNMLXM;
        xcdtFzPKl = TYcSzYUVX;
        mgSGfISZRNUczCh += aNMLXM;
        SniSKleViI = ! rTYfbW;
    }

    return aNMLXM;
}

bool jDdTkriWeiMtu::PJHtNgYStuaTsXU(int zhkRZmiX, int MjDhqjmIe, double fkSjbn)
{
    int PADkwVAQWKq = 1148525666;
    string LFdPQkVQnzuE = string("LWFhPNeTkVZEEEVbAcUZKyYSduVCiXVjECgGWJCwrIouRBwpgveLVMowWpFPAmUPzJiPZUiETLWuWFGIyRyfiDlAahWymaXODPVXwABsboWoUBqPnXDJBNYGKzJFktgPfWWHoYCrAFC");
    double YEHYJQtNDnOTxbBw = -925760.1253771263;
    int mvswHJ = 1649169047;

    if (zhkRZmiX < 1649169047) {
        for (int nZFKqiDWKxdi = 1592469202; nZFKqiDWKxdi > 0; nZFKqiDWKxdi--) {
            MjDhqjmIe += MjDhqjmIe;
            zhkRZmiX *= MjDhqjmIe;
        }
    }

    for (int eKSNkWqrAxQ = 1412509987; eKSNkWqrAxQ > 0; eKSNkWqrAxQ--) {
        zhkRZmiX -= mvswHJ;
        zhkRZmiX /= MjDhqjmIe;
    }

    for (int sbfzkMtzJOyQl = 2100497092; sbfzkMtzJOyQl > 0; sbfzkMtzJOyQl--) {
        fkSjbn *= fkSjbn;
        YEHYJQtNDnOTxbBw /= fkSjbn;
        fkSjbn /= fkSjbn;
    }

    return true;
}

int jDdTkriWeiMtu::uNSYbejEiv()
{
    string CFLBUtQ = string("gDJJVtdwhHbBeKcDaCNsPURkfubdYCuQrKuVnxfDQooEZUqLSWikvAcqzVoVxnECZzzSPWbonaapKSCSpvdeurTQerDHGOgAjvtZQYjelWzBIpSAGlzuvpozEgYuyJFpJysdMYBgCyJKNmSprbBwCQcRkoTPyUKRGTPeApASIzIrIcuHwXLKkXuhYfCw");

    if (CFLBUtQ == string("gDJJVtdwhHbBeKcDaCNsPURkfubdYCuQrKuVnxfDQooEZUqLSWikvAcqzVoVxnECZzzSPWbonaapKSCSpvdeurTQerDHGOgAjvtZQYjelWzBIpSAGlzuvpozEgYuyJFpJysdMYBgCyJKNmSprbBwCQcRkoTPyUKRGTPeApASIzIrIcuHwXLKkXuhYfCw")) {
        for (int MDqkBV = 1092850954; MDqkBV > 0; MDqkBV--) {
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
        }
    }

    if (CFLBUtQ == string("gDJJVtdwhHbBeKcDaCNsPURkfubdYCuQrKuVnxfDQooEZUqLSWikvAcqzVoVxnECZzzSPWbonaapKSCSpvdeurTQerDHGOgAjvtZQYjelWzBIpSAGlzuvpozEgYuyJFpJysdMYBgCyJKNmSprbBwCQcRkoTPyUKRGTPeApASIzIrIcuHwXLKkXuhYfCw")) {
        for (int KFYKfDUiuYP = 859766166; KFYKfDUiuYP > 0; KFYKfDUiuYP--) {
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
        }
    }

    if (CFLBUtQ <= string("gDJJVtdwhHbBeKcDaCNsPURkfubdYCuQrKuVnxfDQooEZUqLSWikvAcqzVoVxnECZzzSPWbonaapKSCSpvdeurTQerDHGOgAjvtZQYjelWzBIpSAGlzuvpozEgYuyJFpJysdMYBgCyJKNmSprbBwCQcRkoTPyUKRGTPeApASIzIrIcuHwXLKkXuhYfCw")) {
        for (int Nqnhx = 1241072612; Nqnhx > 0; Nqnhx--) {
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
        }
    }

    if (CFLBUtQ != string("gDJJVtdwhHbBeKcDaCNsPURkfubdYCuQrKuVnxfDQooEZUqLSWikvAcqzVoVxnECZzzSPWbonaapKSCSpvdeurTQerDHGOgAjvtZQYjelWzBIpSAGlzuvpozEgYuyJFpJysdMYBgCyJKNmSprbBwCQcRkoTPyUKRGTPeApASIzIrIcuHwXLKkXuhYfCw")) {
        for (int CZafhSoPuUvvoO = 548306581; CZafhSoPuUvvoO > 0; CZafhSoPuUvvoO--) {
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ = CFLBUtQ;
            CFLBUtQ += CFLBUtQ;
        }
    }

    return 2025947497;
}

jDdTkriWeiMtu::jDdTkriWeiMtu()
{
    this->PEjJKRBOTRMkjLFo(-38609.2345713014);
    this->TGBJoQs(-1729049299, 792523.9674567265, string("BxzYxLeHCzOyRCxZYNlzlStEUInVVvDnjCgddNpPkeaZKGvTuzKFFqjgcLegoHdgBNbLJJhgvKj"));
    this->zbIyKGWRktEmn(1002187.3582441116, string("FivZlwisYliMIpETclrVxqefpGdlqqVqWHcvnqhaLqTWKznkNWSLUgsoLICjglUuDdmYAZYIfpJkBReXkNzFafttntykJeGApwuAA"), 2090636904);
    this->NGyQtgfnLIhEhhc(1635781999);
    this->bdUsUaprRGHi(string("SQkcnzkHOftShHhmMRdDjxGkSWnWDWCLIWGIhTDcvygYKXICfKrafayBVmnOfABLWBvmytLBoJeRXTibrYGaAEWCcFooetEWIngPcbcenidGRFFeIVYdMqICqZKxmnguIxNPCnpwCugNrahWHJfHGYbKMXXefDbgUYvdfQjMaSGtz"), string("QFBVKumvfRMPRGVRGUozcJLXWrfjvrlaGGOraCmmMmbHEyMtJMdkcRwNOtfrAzwNSLGlxlEWfUDOheStNKWmvZtpFcKncVyrWUfumfoPYwdVWAudYlWcERAfyVZqT"), true, string("nprnhQRmUGpxvmRrLDMdueBJJfjOONLVBFxYctNhURZsPxzIJ"), string("dVJdBunnNNctptvNrzdqrWO"));
    this->isZhUREn(true, false, string("ErZpDZHlsKDGpMITZSHMZsncLXSLOjtRpnJgATtQnYTDFYcpMWHqPZAykdKnlrtHDeJfPEsXHxFUVKroAqDerXecOUJREJnDABsoZHnenTFuevLqOvzCOSirjnjwNKgBAHNMGStnzduVTyFYYLzWrcyFiABZnyHEqybIrAIbqsusVfZBZgmGDQdjqCfdAlnpApvUcJGzcHakGQGJIjCbetEOMeQveVBSEibsPSovWBfjIGhOT"), string("yErjhVjGhlLmkJrolBitvh"), -1205346500);
    this->pouad(-353468.75304273004, 1421708959);
    this->gFPMLentWzDm(string("EaMZRWoLSQIyjUj"), -983981.7706948802, -1426071941);
    this->aqCJSEhSemhkrO(string("sUohRSkrbxUHXqYjgycBUTczgmPMCZXwYOPgdklGQWbql"), -871935191);
    this->CAjvIJgY();
    this->fTopuqOVKyeUdYj(string("XNhAVNfcjIMQsuTjeiTZAxDzvSwEKpQjEmSBDEJMVkkZvLJLUrPJfC"), 1588664273, -964211.7778789042, string("vrIhQflEIvpKUVSNORIkXRTrlXIkrlzBuESLOeAfzgHyAbkRdHmQEZaMMnBftXXEvDlYDqnnAMiLriECOiSAegsTelJOQTidCwcjGpPsCWkCCEcWDYEQscoIHNqyHvHnoPexqsDWVJ"));
    this->PJHtNgYStuaTsXU(1513591117, -637394694, -101590.51230319937);
    this->uNSYbejEiv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GTRDUmBRdbQVJI
{
public:
    bool WLmMMASW;
    bool dwONmWeZgOPeoDk;
    int LNaadacacAAJlX;
    double pJTwdkzJfvkMB;
    int zRtPJOzca;
    string XVtxDuZKKSgPkRH;

    GTRDUmBRdbQVJI();
    int WuXcBERKs(int skTVOO, int OGDfvUIpIDPYLQY, bool zscbQVDHG, int nKJfeKksmvnglJS, bool PyXPLQN);
protected:
    bool UGCCCVskHCD;
    double zMBagzniXP;
    int PdvmozaqtVWMH;
    bool asNAe;
    string uRhetyMH;

    bool hVfzSBUFa(double vLbIXBHRJL, double toaoybln, bool QKDVd, int aaOFtsPfRPQzo);
private:
    double TqgCH;
    bool cbDWMtmVrfQhoB;
    string ZReFcTBYiVUAw;
    bool gHqAOrcVt;
    int dHmglQkXpNIVX;
    string boZIGYeRUSGYJoN;

    bool gVoaFtlWhUljmu(double XhfYNUPcmRoDjS);
    string jpPVRemjkkP();
    bool sOIXhxib(int aCrurtf, bool irevIRQgTI, string KkWRjdbvnOKgHwoO, string TSuEeTMC);
    bool LEGrJYsoxSWolA(double cOBXcoIQxS, string zPaSxIqHraZY, double ZYihKxDFbTU, string aAZFhcIpjdjA);
    double gXVbknLrGDqw(double djMewftzEaD, int LXvBABOJ, int tzniClCTvYGQcC, double ktbEGaiKJCN, int baZfc);
    bool BSaBse(bool IZfYwNs, string lVJGOTYf, bool jGKbvcr);
    double JiuzRi(int JrowQuKIXBKOJe, int tMKWXH, string OzEHsACVrS);
};

int GTRDUmBRdbQVJI::WuXcBERKs(int skTVOO, int OGDfvUIpIDPYLQY, bool zscbQVDHG, int nKJfeKksmvnglJS, bool PyXPLQN)
{
    double gNVcYhiK = -307792.47809002467;
    int ftXkBJJCmfXr = 2137687525;

    for (int TZnoRVPDvtoqlzP = 389239526; TZnoRVPDvtoqlzP > 0; TZnoRVPDvtoqlzP--) {
        zscbQVDHG = ! PyXPLQN;
        skTVOO /= nKJfeKksmvnglJS;
        zscbQVDHG = ! zscbQVDHG;
    }

    if (OGDfvUIpIDPYLQY != 2137687525) {
        for (int QTWLRDE = 1632071823; QTWLRDE > 0; QTWLRDE--) {
            ftXkBJJCmfXr = skTVOO;
            PyXPLQN = ! PyXPLQN;
        }
    }

    if (ftXkBJJCmfXr <= 600751424) {
        for (int btCPWpvWaOQMJop = 1010619821; btCPWpvWaOQMJop > 0; btCPWpvWaOQMJop--) {
            skTVOO = ftXkBJJCmfXr;
        }
    }

    return ftXkBJJCmfXr;
}

bool GTRDUmBRdbQVJI::hVfzSBUFa(double vLbIXBHRJL, double toaoybln, bool QKDVd, int aaOFtsPfRPQzo)
{
    double MYuSeiyc = -991667.4050345666;
    bool fVDbtkUhOTL = true;
    bool tZaTmFrxCwGwd = false;
    string WlubI = string("aySlvUDHsHbWUxyRBhXcjnIQQTUqtkqgSWyNhfcFnIQTxrRaDQgEsFFJBTDrtCPEvH");
    bool FAavn = true;
    string nsemrPUeUQPtGyz = string("lsmDIzMwoxVNOigntByiKbdSHuhLSNsWxDYLrdDzSkJwAIqoPstQakhwZSFtSdUdvPzwkIRohcYXdXylhJfNsMqahqPXEpcRLcQhtnxyOOhcsadKLyZGTKGeyOBWHQJFHbGvhIyQUgcUGaeuiFAdGgROIEWnjpwkftzpVgWmIhAWBQoLvmMLXYeIxHKYFhEhORWnpoGvIHtotWfXk");

    return FAavn;
}

bool GTRDUmBRdbQVJI::gVoaFtlWhUljmu(double XhfYNUPcmRoDjS)
{
    int kBMolhD = 563754824;

    for (int cMCXqfFi = 1553316130; cMCXqfFi > 0; cMCXqfFi--) {
        kBMolhD *= kBMolhD;
        XhfYNUPcmRoDjS = XhfYNUPcmRoDjS;
        XhfYNUPcmRoDjS = XhfYNUPcmRoDjS;
        kBMolhD = kBMolhD;
        XhfYNUPcmRoDjS -= XhfYNUPcmRoDjS;
        XhfYNUPcmRoDjS = XhfYNUPcmRoDjS;
    }

    for (int riRzKX = 990521691; riRzKX > 0; riRzKX--) {
        kBMolhD = kBMolhD;
        kBMolhD -= kBMolhD;
        kBMolhD = kBMolhD;
        XhfYNUPcmRoDjS -= XhfYNUPcmRoDjS;
    }

    for (int xiZBjWJNmFhKqds = 869074511; xiZBjWJNmFhKqds > 0; xiZBjWJNmFhKqds--) {
        kBMolhD -= kBMolhD;
        XhfYNUPcmRoDjS = XhfYNUPcmRoDjS;
        XhfYNUPcmRoDjS -= XhfYNUPcmRoDjS;
        XhfYNUPcmRoDjS = XhfYNUPcmRoDjS;
        kBMolhD += kBMolhD;
    }

    if (XhfYNUPcmRoDjS == -451039.2601147666) {
        for (int XBgzsZoM = 127634725; XBgzsZoM > 0; XBgzsZoM--) {
            XhfYNUPcmRoDjS = XhfYNUPcmRoDjS;
        }
    }

    return true;
}

string GTRDUmBRdbQVJI::jpPVRemjkkP()
{
    string wRQsKTxCRaiIBGN = string("BSeIPwgecueHbCwXECmlfqYatsxXegTqVJfeazPeBqHbFsxqkNAPNXnfrsOtrzBVRdrLxIIarxNifZlijvpLoioIpYihcuaAcEfJdkCzcCNmcudHdrXsaOYzYEZMOMJMaOTFtJfZFrVqTgffvbXnHQbBIwuGmuvpSerpFwVKOwcqBVPPvPkCdCUeVqEqbRm");
    double ebfEYMDDpn = 633120.5324982997;
    bool gDbAiwnZhw = true;
    string FvLozEkeA = string("PTVzXBNAvshvFfrWJRjMUHgjwWbuUKIqxwBagMlVoQpglfrRqrPoatulsamdDSFlDmgASmxZllyShAARGglPyRwQpOZHtJZBzXFdAeeqxZhWyBPoPqGIKPQPbLPChyrAptOiVNmjfbAfqhBdBJoEQkGorpojHJIMbBBwYRTXFpfbIXRpdplLwSRDNQcyvYgOsMMnlBGHVdqAuWpwNQWjMRvHskQtQEXdBeDTxQlZXlXDSGZfHjlAQCOIPLXELd");
    bool sWIvlsTDM = false;

    for (int zgLeQQoGC = 334368296; zgLeQQoGC > 0; zgLeQQoGC--) {
        wRQsKTxCRaiIBGN += wRQsKTxCRaiIBGN;
    }

    for (int FLJDDUQqPT = 1007442173; FLJDDUQqPT > 0; FLJDDUQqPT--) {
        continue;
    }

    if (gDbAiwnZhw == true) {
        for (int BPrEkxWBlYxGNXzd = 445910242; BPrEkxWBlYxGNXzd > 0; BPrEkxWBlYxGNXzd--) {
            continue;
        }
    }

    if (wRQsKTxCRaiIBGN != string("PTVzXBNAvshvFfrWJRjMUHgjwWbuUKIqxwBagMlVoQpglfrRqrPoatulsamdDSFlDmgASmxZllyShAARGglPyRwQpOZHtJZBzXFdAeeqxZhWyBPoPqGIKPQPbLPChyrAptOiVNmjfbAfqhBdBJoEQkGorpojHJIMbBBwYRTXFpfbIXRpdplLwSRDNQcyvYgOsMMnlBGHVdqAuWpwNQWjMRvHskQtQEXdBeDTxQlZXlXDSGZfHjlAQCOIPLXELd")) {
        for (int jNlraIcPpWjJiC = 27719985; jNlraIcPpWjJiC > 0; jNlraIcPpWjJiC--) {
            ebfEYMDDpn -= ebfEYMDDpn;
            wRQsKTxCRaiIBGN += wRQsKTxCRaiIBGN;
        }
    }

    return FvLozEkeA;
}

bool GTRDUmBRdbQVJI::sOIXhxib(int aCrurtf, bool irevIRQgTI, string KkWRjdbvnOKgHwoO, string TSuEeTMC)
{
    string hIStzODah = string("yjoUpzPVRJWnRiMxFzcmDgLcHQKjnMGMHFaidXpAyFvjxxZZIQgqIKnXUPWohJDHvArOBlK");

    for (int USaYaLQQ = 1934562210; USaYaLQQ > 0; USaYaLQQ--) {
        hIStzODah += hIStzODah;
        irevIRQgTI = irevIRQgTI;
        hIStzODah += KkWRjdbvnOKgHwoO;
        KkWRjdbvnOKgHwoO = TSuEeTMC;
        hIStzODah += TSuEeTMC;
    }

    if (irevIRQgTI == true) {
        for (int XjunZeNMjpQFAyQA = 948566600; XjunZeNMjpQFAyQA > 0; XjunZeNMjpQFAyQA--) {
            hIStzODah += hIStzODah;
            TSuEeTMC += TSuEeTMC;
            aCrurtf *= aCrurtf;
            aCrurtf = aCrurtf;
        }
    }

    for (int dNzYLeU = 1316642759; dNzYLeU > 0; dNzYLeU--) {
        continue;
    }

    if (KkWRjdbvnOKgHwoO < string("cyUodzEnCTLikSHkyeWsiPBiCMqhGStDncErDhgHeKZwNsBXKmaYkUYapmstHAHYGAWtBcsdnznagciKQcAYHZkosurFiZSiItaldMyZsRZjAJBJcXYRyyXvFKmIBUWxmaKrvYQsarUTpxkESZbATbQftivTJjcBzOUTfTIRCoyHhLQoLXcgSBxgHTJidPkbjjbuaSxUSu")) {
        for (int IyRNLQUXSXjmyYi = 1910588818; IyRNLQUXSXjmyYi > 0; IyRNLQUXSXjmyYi--) {
            irevIRQgTI = ! irevIRQgTI;
            irevIRQgTI = ! irevIRQgTI;
            hIStzODah += KkWRjdbvnOKgHwoO;
        }
    }

    if (TSuEeTMC > string("cyUodzEnCTLikSHkyeWsiPBiCMqhGStDncErDhgHeKZwNsBXKmaYkUYapmstHAHYGAWtBcsdnznagciKQcAYHZkosurFiZSiItaldMyZsRZjAJBJcXYRyyXvFKmIBUWxmaKrvYQsarUTpxkESZbATbQftivTJjcBzOUTfTIRCoyHhLQoLXcgSBxgHTJidPkbjjbuaSxUSu")) {
        for (int WDweCzwF = 243641442; WDweCzwF > 0; WDweCzwF--) {
            aCrurtf += aCrurtf;
            KkWRjdbvnOKgHwoO = KkWRjdbvnOKgHwoO;
            KkWRjdbvnOKgHwoO += KkWRjdbvnOKgHwoO;
            KkWRjdbvnOKgHwoO = TSuEeTMC;
            KkWRjdbvnOKgHwoO += TSuEeTMC;
            KkWRjdbvnOKgHwoO = TSuEeTMC;
        }
    }

    for (int kmqspGCDbNHl = 1025444990; kmqspGCDbNHl > 0; kmqspGCDbNHl--) {
        continue;
    }

    return irevIRQgTI;
}

bool GTRDUmBRdbQVJI::LEGrJYsoxSWolA(double cOBXcoIQxS, string zPaSxIqHraZY, double ZYihKxDFbTU, string aAZFhcIpjdjA)
{
    bool EpewQoMZ = false;
    double IzlMdqZzgx = 862033.3071928084;
    int bCACnVeugknxIylN = -431902309;
    int YgBMMlD = -264341452;
    string cgFow = string("ZzedDygsrdGHMKOtLSnNqjjNzpvW");
    bool sNVxMVIZPcx = true;
    string dtNlGXuIRvcRIz = string("BoieUKEraYsuUiDPGjWvcjGxpxgbJPYCnVpwaWdXSgAoIaNdSCGoYhgkpAZqgIQctHSEhFsUKGuuGWddhPqxrwwuvflQNZuOwWHnJAIuMxZOCUBoYhIxaXIxJzEumStSPVvptduRilpXbSpqCVppJTbzCZaiJmVnDkzvk");
    double snseydeFtF = -628579.9077087292;
    bool ghLsEdheVch = true;

    for (int QyMLcwxd = 363224508; QyMLcwxd > 0; QyMLcwxd--) {
        aAZFhcIpjdjA += dtNlGXuIRvcRIz;
    }

    for (int vwdtcdnLMVL = 1818712475; vwdtcdnLMVL > 0; vwdtcdnLMVL--) {
        cOBXcoIQxS *= IzlMdqZzgx;
    }

    if (dtNlGXuIRvcRIz < string("MbW")) {
        for (int wwMbBcqqvTyWiVx = 1627701037; wwMbBcqqvTyWiVx > 0; wwMbBcqqvTyWiVx--) {
            continue;
        }
    }

    for (int aEGEzzvyJkaVU = 1595237760; aEGEzzvyJkaVU > 0; aEGEzzvyJkaVU--) {
        ghLsEdheVch = ! ghLsEdheVch;
        cOBXcoIQxS += ZYihKxDFbTU;
        ZYihKxDFbTU /= IzlMdqZzgx;
        ghLsEdheVch = ! sNVxMVIZPcx;
    }

    for (int fPeYCz = 293091595; fPeYCz > 0; fPeYCz--) {
        sNVxMVIZPcx = ghLsEdheVch;
        cgFow += zPaSxIqHraZY;
        sNVxMVIZPcx = sNVxMVIZPcx;
    }

    return ghLsEdheVch;
}

double GTRDUmBRdbQVJI::gXVbknLrGDqw(double djMewftzEaD, int LXvBABOJ, int tzniClCTvYGQcC, double ktbEGaiKJCN, int baZfc)
{
    int ppvvDyXUFF = -1766535604;
    bool CKAbnKRBZ = true;
    bool EZGWRdPhB = false;
    bool utvFdJteaF = false;
    int FfvsEnLBcliKns = -2004224684;
    string kbDUjgCy = string("vNdRQjrKWZYUekXdcqesMszqbZFsvtcgbyuRrMKHfVlMsbFUWkEEplvtdcfNwdhXPIizOnbWYvWqctfNVzNlxQSVCHilEVEsEiuYkKOwkFyqFRJSkDyOcVMJeEpVwdczxdrDXhMszcJEFoqBxbhXrBisGqFEiPoobqDsBbimLIGtYKNmSNgwGBaZqZNvmmBHyiZNglSiIixrkhMzlPRKMXnDKbtfqEIvwiEtyJS");
    int oXpdbSGAuOwicDx = -649401536;
    string lmuwWEpCIfEWIBR = string("vCAmsQEuVwRmDy");
    string cGnpAXV = string("FDaSbFunbaXbKydzdxJDLFzqauyTBXHIOZNwGBhUWmSmLcKvJFwNlSyzAyDVdKnpNqhyyUHUGKKepUjWJhXsaCQJjmXIsEBqNMfEhBKAIoIG");
    string xxWBdf = string("brluPrNRJRtkpeWNAxArcWduqeLsxAsqUtKKLXqoogzrDYTWadCsmdwaTpCFjgOXazDpZhTyhaySGRwEBLerdnLfuKjgYwpyVzoQTsTEwNCGKJfZBxDmKeEuKNIMuKdebRCXdIuETEMfiEcCyyAODtVHDsFSnmAHFPDemTIAujeNXGCCnLXJfYDZiPgZBzjHq");

    for (int vgfrlAHhgkpZdQM = 859770942; vgfrlAHhgkpZdQM > 0; vgfrlAHhgkpZdQM--) {
        LXvBABOJ /= tzniClCTvYGQcC;
        kbDUjgCy = kbDUjgCy;
        LXvBABOJ = oXpdbSGAuOwicDx;
        lmuwWEpCIfEWIBR = cGnpAXV;
    }

    return ktbEGaiKJCN;
}

bool GTRDUmBRdbQVJI::BSaBse(bool IZfYwNs, string lVJGOTYf, bool jGKbvcr)
{
    string hjRLUmuPo = string("FmSlZyvvRTxvOXzlsaKyunVcJRLXYFkGiGLbLGhfQQAPSUxZFkUirXElXLCUKxhvhaaHHbLIGPqBXldNIyBuEZotmtRbEYMObeneStMFSHbGjxYZxfxWEWIoFkLfQIfmcSjiRxhwDrJBAjDpNqURmIRtigMa");
    double mRlkIOesXK = -293179.9302611784;
    double WwMTtutdPxDDM = 146636.54431105338;
    double VBXMipIOoMOQd = 618788.953803047;
    int hgYWHxWspKNz = -780832343;
    int dzAvAidePX = 1618420083;
    bool XjMUP = false;
    string vwAQAYptjDZnrsyD = string("fJwFNeHLyXweBqmKWYRUIybMosunDvdbCqIvcpEsFxuhYyoZHoMnsOdrKcoWKHmgbVjTdKcUFJUeQVopCAMrqfRUxDlLAtnMrGIJsBWdwxbFHjBGiKraVJEIcVvCYauloAMuGpYinmddWBqbjkCjmxclnPnXTmSMJMxdISvjYRykEDdTATjRmvLLkKainYCFijlxmTeizfSrJLgEruqfqqkKjGEaCdpOqdNtLfIHpBIMJcQdznr");

    for (int gQgCbZCM = 1211597492; gQgCbZCM > 0; gQgCbZCM--) {
        XjMUP = IZfYwNs;
        IZfYwNs = ! jGKbvcr;
        VBXMipIOoMOQd = mRlkIOesXK;
        hjRLUmuPo += lVJGOTYf;
        WwMTtutdPxDDM = VBXMipIOoMOQd;
    }

    for (int MzgfOdjQgP = 1526347173; MzgfOdjQgP > 0; MzgfOdjQgP--) {
        hgYWHxWspKNz /= hgYWHxWspKNz;
    }

    return XjMUP;
}

double GTRDUmBRdbQVJI::JiuzRi(int JrowQuKIXBKOJe, int tMKWXH, string OzEHsACVrS)
{
    double cvwFwFvtD = 940238.9953938622;
    bool LmDUpB = false;
    bool dZPRCrTvfaYFeptE = true;
    bool rIKTbT = false;
    string nZBfSm = string("auXdiaWDdsipambnKlMznWSspQQIypZgWcSqxFgDFvxcmoeCgHTTPXCGALbVDmwjaZosjvyOpuQpAaaNtHfSfGlMSsVHIjDCprNBHOJoFidzCzHukwKVdosWwsWWZzNOwCDFxzzMJvmAhFmzmwlK");
    string PggVjeeWpTNDtFvr = string("catxzxGUDvwDbHNjUgWNfMIkSjPGdHadZgFwOxKIMBhXYdPZORfWGwDWolfyzGDTCoZakyUGaceTINimDEUGfxYulUMsvgUidllZhObNXDtadOdyPRUEPLcRApEwGysQHnmVhItKEARPHrhtveruXAvKAajBpCHEcAvMtTCCTSictwYHgdLHQxOKQoccgkaILfwQRL");

    if (nZBfSm <= string("qllRCJamVGPQAiugNjJCeQVdIPrwdmgGKrYnfjvmRrRfXxPYkIiEWeBniqUVUwTAleywWvXherudqVspowkmHmrXMEsCZghlfMFOTytkOYjyLObPPVWpyXMQUzKGRBWDmGISEjJQTLySrhxTluPZCRETrNeNd")) {
        for (int mqxYGKGNzFOc = 909731805; mqxYGKGNzFOc > 0; mqxYGKGNzFOc--) {
            OzEHsACVrS = PggVjeeWpTNDtFvr;
            OzEHsACVrS += nZBfSm;
            nZBfSm += OzEHsACVrS;
            nZBfSm += OzEHsACVrS;
        }
    }

    for (int SicwdzLgkfn = 2083591328; SicwdzLgkfn > 0; SicwdzLgkfn--) {
        rIKTbT = ! LmDUpB;
        cvwFwFvtD = cvwFwFvtD;
    }

    return cvwFwFvtD;
}

GTRDUmBRdbQVJI::GTRDUmBRdbQVJI()
{
    this->WuXcBERKs(-1973328200, 600751424, true, -1546364612, false);
    this->hVfzSBUFa(133304.0988903238, -191340.49045246714, true, 1195558335);
    this->gVoaFtlWhUljmu(-451039.2601147666);
    this->jpPVRemjkkP();
    this->sOIXhxib(2134106543, true, string("cyUodzEnCTLikSHkyeWsiPBiCMqhGStDncErDhgHeKZwNsBXKmaYkUYapmstHAHYGAWtBcsdnznagciKQcAYHZkosurFiZSiItaldMyZsRZjAJBJcXYRyyXvFKmIBUWxmaKrvYQsarUTpxkESZbATbQftivTJjcBzOUTfTIRCoyHhLQoLXcgSBxgHTJidPkbjjbuaSxUSu"), string("xaCNRqOhKmnRiQzfTKWefQtttQqwrKObfXJWLNrLYyvTQZEfeysemIyJfxyFRUAoitDSzgkWdSsrYJcOACuLJuvVMDdoCsqEZKNOcZXUZYZCKvmQMyMZpTRJHKJzwqQwYQsQUQRmWqNwaERUEpuZNtvdwVubfCFZMklXYmzXTOaHaHRAqOtqcIwGLpkJraljIucWRmXuCsQIdVYnmstFaVsLrniKOPIeJTucobb"));
    this->LEGrJYsoxSWolA(1031297.4079497072, string("iafcJkuulOWgZXNipCKrTYsSOUSJUbYaiGvVUyOwEuhvlUboufIRSyexypcHyMennIIQBFcbjTDgOKRCLrlgDCZJsadgmEgsKFiFeEgjtlJDSmFGaxwAduYUnLVipcCDPNzsxq"), -900989.6459281967, string("MbW"));
    this->gXVbknLrGDqw(-660713.8318653902, 593295825, 1209462421, -200581.68637042274, -824099894);
    this->BSaBse(true, string("zdDYASGnj"), false);
    this->JiuzRi(645218511, -677483233, string("qllRCJamVGPQAiugNjJCeQVdIPrwdmgGKrYnfjvmRrRfXxPYkIiEWeBniqUVUwTAleywWvXherudqVspowkmHmrXMEsCZghlfMFOTytkOYjyLObPPVWpyXMQUzKGRBWDmGISEjJQTLySrhxTluPZCRETrNeNd"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qlQntfGl
{
public:
    int EQZBBu;
    double XIUSEBweaLj;
    bool ZgKuVltWVLI;
    double uHFFvIGgbqI;
    string XpXYLVlxv;

    qlQntfGl();
    void PbGmzy();
    double TIDAOwQmKbwFCD(string wAqyKdKz, bool HJqRz, double JbQJCjlFZ, int VRlHEXFQGgkQW);
    void FQnSvfnXOK(string qwjDPlNSwGn, bool ZZSdOJzRSLCnWoBz, bool pEYlQZRSTNHIF, int jxejSLbfdUeLJTV, int LxFlSkJnMfiKelz);
    int mzIkkGNfWhmZuSn();
    void gRajIdKodrpXeyaC(int DwBTKiZYLeZQh, bool gRulOTYXK, bool GIQBJoUd, double hcBBPasF);
    bool FrxHPEIcSt(int RDfmK, bool iKycAXxbPXwYZX);
    string MOatXSkzqiET(int zCvQkPQTRMsiws, int VOwfhqzHGFmeEoQN, int CCxLMHml, string bqIIYFRdQCIGou, double dxDlmqmrVgP);
    int waPZuTEgUEiwyo(string rYnhttTmP, double PskcXRiJSdZA, bool DEuPzMUZ);
protected:
    string WyWrDrnEcIdwK;
    int cJhursqTxJ;
    bool wafvHGSbLmFeeQ;
    bool NeYCLKSyN;
    bool MPErUlMlQX;

    double dsicOYitjDr(string PRwuIBZalx, int PGYsLfDqJfhi, string ZWUhAgdfVCKsxepY, double oYEVzfHot);
    double phsCj();
    void oWqDEjnfKIsbxgZ(int nNVNM, double bOeJm, double FtaxIi, int xfeWsgpkxM, double zcRiHpnxxmlzdOE);
    string WiHvsIsMxFDMtae(int imLaDeQmH, int clwPlYUbun, int gRPIIKruTWFt, double dMqFNcpUQm);
    bool WanvQCqVF(double XnppUNud, int MRtpLdaPFNoNc, int OJzlBDkBgk, double QeFRwOLjLw, bool yIbMnPLPnvMjjhn);
    double Sqxutuigi(bool mzDYB, int WWFxVTcGEKwdPBv, bool KZlRpVRITgbcoRA, string KqGcwibGgto, string QWLfT);
private:
    double HTQvkZhgcOy;

    double cUppBhMbCAAZG(string DWeQKUwTWPvlXa, bool cwGbLmKwOOlUrnqQ, int ibYWacaOWADBov, string sblIaVLGSZTO);
    double vfPxymbagKUMYSW(string BcEzTnnVwqnCFjlQ);
    bool hkQfgnAq(double BoLeJKzUl);
    int tbpJNlppKxwNEzZk(string aDKbZDtDpgGrRJt);
    bool TYPAb();
    double BTwzxS(bool wMDfDm, double IXysMfzHcrsOiEwX, double dMQCAoBsIAY, double IbHKrFa, string WPYqOelDnlpDCII);
};

void qlQntfGl::PbGmzy()
{
    int GQYRki = -1339865128;
    double tVXoZV = -461397.63856882934;
    double rwcdqyYyiL = 823548.9110735985;
    bool dZfclS = true;
    int wsugJAG = -1470757851;
    string jWXHyq = string("UZqhswnHdKFqndHymIvLvRfzExELxYGtQECztmIVlLFNECCunHaGnmxqIaVuUmdx");

    for (int oCDsfvxnMmmgLauo = 1455985005; oCDsfvxnMmmgLauo > 0; oCDsfvxnMmmgLauo--) {
        rwcdqyYyiL = rwcdqyYyiL;
        wsugJAG = GQYRki;
    }

    for (int mjQGiqauipnIT = 1106115641; mjQGiqauipnIT > 0; mjQGiqauipnIT--) {
        dZfclS = ! dZfclS;
    }

    if (wsugJAG < -1470757851) {
        for (int HHTkLFttBENOQIG = 1611160550; HHTkLFttBENOQIG > 0; HHTkLFttBENOQIG--) {
            tVXoZV /= rwcdqyYyiL;
        }
    }

    for (int bhKtTTfApjG = 1967332978; bhKtTTfApjG > 0; bhKtTTfApjG--) {
        continue;
    }
}

double qlQntfGl::TIDAOwQmKbwFCD(string wAqyKdKz, bool HJqRz, double JbQJCjlFZ, int VRlHEXFQGgkQW)
{
    int bTBoifvXtqmfrw = -1306144613;
    int ujCkD = -1902476891;
    string QwEViKzphDyXB = string("dnXGrwNBqFssbkVPvrSmdkD");
    double OVaUUSPCCH = 781047.5878040243;
    double NKgKPPojgFILVmX = -285291.4407143254;
    string rmfDGbLTmYZP = string("QvUitgdZpZeAdGJJjhMWNFxDsTrQfbrefhlHAVKfDgcKESZyeDezblvbKrrepaluQEzbnmeFBEGSKzybrkO");
    int uHKXiRsYvYi = -2017028047;

    for (int KmDqwziIcV = 137406255; KmDqwziIcV > 0; KmDqwziIcV--) {
        continue;
    }

    for (int KNerKgvEbQFd = 1499684791; KNerKgvEbQFd > 0; KNerKgvEbQFd--) {
        continue;
    }

    if (VRlHEXFQGgkQW != -1902476891) {
        for (int vZrFbaEpaFLi = 820599787; vZrFbaEpaFLi > 0; vZrFbaEpaFLi--) {
            NKgKPPojgFILVmX /= OVaUUSPCCH;
        }
    }

    for (int yRcBCmZlUTQ = 2090281923; yRcBCmZlUTQ > 0; yRcBCmZlUTQ--) {
        bTBoifvXtqmfrw *= ujCkD;
    }

    return NKgKPPojgFILVmX;
}

void qlQntfGl::FQnSvfnXOK(string qwjDPlNSwGn, bool ZZSdOJzRSLCnWoBz, bool pEYlQZRSTNHIF, int jxejSLbfdUeLJTV, int LxFlSkJnMfiKelz)
{
    string PwHoPwnbdnfDu = string("wJywAnaGsGZKRJYnzliTPAXholPVAChecIApRguTywYVylPGlOJYtTgeDjNVdLllOBHubVxVlJwJQViqiqqbGGPZTEWzKsOwCfQvHakAINmvlruWqRsZiN");
    double SuPOH = -700391.6955691715;
    int mAGQdSuy = -704195288;
    double THCAAHsgcPjit = 696700.8223285798;
    double DtoZxWYWoYu = 793389.9096545638;
    int HNktZc = 15122504;

    if (LxFlSkJnMfiKelz <= -704195288) {
        for (int HRgtsEzetOWBGj = 2101515798; HRgtsEzetOWBGj > 0; HRgtsEzetOWBGj--) {
            DtoZxWYWoYu += SuPOH;
            HNktZc = mAGQdSuy;
            LxFlSkJnMfiKelz = LxFlSkJnMfiKelz;
        }
    }

    if (HNktZc < 1057057297) {
        for (int KBdoDNNTlScpbkT = 2040322932; KBdoDNNTlScpbkT > 0; KBdoDNNTlScpbkT--) {
            HNktZc -= jxejSLbfdUeLJTV;
            qwjDPlNSwGn += qwjDPlNSwGn;
        }
    }
}

int qlQntfGl::mzIkkGNfWhmZuSn()
{
    double NpWpXelBR = -749874.2404339658;
    bool rDUHoN = false;
    string uQjKACdrc = string("rviEGxoQLbOrHlmloYwcObyRjoUXhRSaPqEtiejNtcnMwhFFEoFupFETtfCGxkyeOFDzOdM");
    string XtSRIGVNb = string("CYtQLfJDxlHDTvdRPHgpmaoIMNJWudhKtCIsLFVIhlxvKiXdOLvAcBNAAgSDBXRNhciUzaCOyPisFqmQjLJOsByWpHpnKLLgtEtkMaRpzZaUxRNuEwwuWfiasrETpMMfpnVXyCEaVPEisxRmtG");
    bool RcHcUIGvBu = true;

    for (int kACOUqS = 63164011; kACOUqS > 0; kACOUqS--) {
        uQjKACdrc += XtSRIGVNb;
        XtSRIGVNb = XtSRIGVNb;
    }

    if (uQjKACdrc == string("CYtQLfJDxlHDTvdRPHgpmaoIMNJWudhKtCIsLFVIhlxvKiXdOLvAcBNAAgSDBXRNhciUzaCOyPisFqmQjLJOsByWpHpnKLLgtEtkMaRpzZaUxRNuEwwuWfiasrETpMMfpnVXyCEaVPEisxRmtG")) {
        for (int XYzOhDQ = 160403891; XYzOhDQ > 0; XYzOhDQ--) {
            NpWpXelBR /= NpWpXelBR;
            rDUHoN = rDUHoN;
            XtSRIGVNb += XtSRIGVNb;
            rDUHoN = RcHcUIGvBu;
            RcHcUIGvBu = RcHcUIGvBu;
        }
    }

    if (XtSRIGVNb == string("rviEGxoQLbOrHlmloYwcObyRjoUXhRSaPqEtiejNtcnMwhFFEoFupFETtfCGxkyeOFDzOdM")) {
        for (int bVKpIAFIlWKJj = 611600673; bVKpIAFIlWKJj > 0; bVKpIAFIlWKJj--) {
            continue;
        }
    }

    for (int CPJJFvcbU = 530794541; CPJJFvcbU > 0; CPJJFvcbU--) {
        continue;
    }

    return -44375863;
}

void qlQntfGl::gRajIdKodrpXeyaC(int DwBTKiZYLeZQh, bool gRulOTYXK, bool GIQBJoUd, double hcBBPasF)
{
    int bweAnzdPHJyLSqu = -1018053967;
    string GCyFgLWiRgutJfjI = string("DBEUbRJmmxRZBMUZiLJRwoRNISuezDfMSuqMbvlEzjNMbbTapyXhvztHGOBMDcavBpaNlZMtaunFFBuLwJENqdMaRqWWDPtfzqEyzGbZxYzfYkfMPrctkaHODhhrWaMUFuxgugIPGZUDVeSUflsmkxjJDSAUQxqKwJHrbRhrhYWDCvVIHnhnvKwEAqDoHDuNGENADlKrLCASxHsSylYfBDFdffvcumgOkHGzBfVQz");
}

bool qlQntfGl::FrxHPEIcSt(int RDfmK, bool iKycAXxbPXwYZX)
{
    int kyRFHYaY = 883689896;
    double zCgLCx = -594609.4377951741;
    bool ozRRUFl = true;
    string ZsYmFPcrlQvFRqKo = string("bJMTPMkNebksVwkYhFaiMqIGVbbdwQGMxKzystYagzaefvJSzQTbWfFPgwpvbGnzcNtdoMQPKlIlTHHmirZoBgxWVQljVGamBkpgsYIYxcdxKPzVexKUXykrGphfAqXZFPXYNcLvWuLaEZCjDnjsgZ");
    bool URaSkwYOU = false;
    double ltNPsaXa = 219541.5615609637;
    int GxIcbqJxKHSaJ = 1125370513;
    string xvBmR = string("IjEieLEknkoseToETIUddYzzgDvgeyhYehFTPgeBkbYfOVsJgQQBhtXyzVYthkCkieN");

    for (int McPui = 421888811; McPui > 0; McPui--) {
        ozRRUFl = ! URaSkwYOU;
    }

    for (int vbOWoiWWmPPF = 1948874462; vbOWoiWWmPPF > 0; vbOWoiWWmPPF--) {
        URaSkwYOU = ! iKycAXxbPXwYZX;
    }

    for (int lsbqJWQkdVdQ = 467603586; lsbqJWQkdVdQ > 0; lsbqJWQkdVdQ--) {
        continue;
    }

    if (zCgLCx >= 219541.5615609637) {
        for (int YaPvPD = 1452486785; YaPvPD > 0; YaPvPD--) {
            continue;
        }
    }

    if (URaSkwYOU == true) {
        for (int mCZDZ = 408321700; mCZDZ > 0; mCZDZ--) {
            iKycAXxbPXwYZX = URaSkwYOU;
        }
    }

    return URaSkwYOU;
}

string qlQntfGl::MOatXSkzqiET(int zCvQkPQTRMsiws, int VOwfhqzHGFmeEoQN, int CCxLMHml, string bqIIYFRdQCIGou, double dxDlmqmrVgP)
{
    int tlRwjK = -2019381218;

    for (int TGhcMjHJlPpvdxoW = 1891613617; TGhcMjHJlPpvdxoW > 0; TGhcMjHJlPpvdxoW--) {
        VOwfhqzHGFmeEoQN = zCvQkPQTRMsiws;
    }

    if (VOwfhqzHGFmeEoQN != 1796881271) {
        for (int gwgjlIioNZDxnnq = 1531226336; gwgjlIioNZDxnnq > 0; gwgjlIioNZDxnnq--) {
            zCvQkPQTRMsiws /= CCxLMHml;
        }
    }

    return bqIIYFRdQCIGou;
}

int qlQntfGl::waPZuTEgUEiwyo(string rYnhttTmP, double PskcXRiJSdZA, bool DEuPzMUZ)
{
    bool WSCpRIJLt = false;
    double luphOwecBPWbmx = 234487.59858210743;
    int brDMG = -1698295222;
    double bTgOvNHE = -487219.2537073339;
    bool lPzVzAquUdeC = false;
    int lbeuHXesgd = 1390401076;
    string LxPAj = string("lZMNnaibhSGqQC");

    if (WSCpRIJLt == true) {
        for (int bqCPqhxwmZKPNE = 1105504501; bqCPqhxwmZKPNE > 0; bqCPqhxwmZKPNE--) {
            continue;
        }
    }

    for (int CTugWpSacaE = 496715552; CTugWpSacaE > 0; CTugWpSacaE--) {
        DEuPzMUZ = WSCpRIJLt;
        DEuPzMUZ = lPzVzAquUdeC;
        bTgOvNHE -= bTgOvNHE;
    }

    return lbeuHXesgd;
}

double qlQntfGl::dsicOYitjDr(string PRwuIBZalx, int PGYsLfDqJfhi, string ZWUhAgdfVCKsxepY, double oYEVzfHot)
{
    double AdrOkN = 900172.3567891853;
    int sGcvtTUGtbcYYM = 1869016725;
    string wZDSATMkor = string("wAHeynpDwYXJaIkzCQnCOrmgnNmKYbQNaLHYGhfOkRtVKVkJUIhqYfPBNJjkFKoYTmVLOMNwJdfhhdZnXjWcqGOzNAkQYrNNRoqWjDQJvqtUGlXgTMVhlUbmw");
    double NVQQoGwHRTDWL = -394260.1174450942;

    if (PRwuIBZalx != string("wAHeynpDwYXJaIkzCQnCOrmgnNmKYbQNaLHYGhfOkRtVKVkJUIhqYfPBNJjkFKoYTmVLOMNwJdfhhdZnXjWcqGOzNAkQYrNNRoqWjDQJvqtUGlXgTMVhlUbmw")) {
        for (int kOoJU = 403657084; kOoJU > 0; kOoJU--) {
            AdrOkN -= AdrOkN;
            AdrOkN /= AdrOkN;
            NVQQoGwHRTDWL /= AdrOkN;
            ZWUhAgdfVCKsxepY += ZWUhAgdfVCKsxepY;
        }
    }

    for (int tbEndhvz = 609552259; tbEndhvz > 0; tbEndhvz--) {
        AdrOkN /= AdrOkN;
        PRwuIBZalx += ZWUhAgdfVCKsxepY;
        oYEVzfHot -= oYEVzfHot;
    }

    if (ZWUhAgdfVCKsxepY >= string("QiiTLrrLPEcGPalfaUJpYIKgeywzgmkOjHoHtGzNWOsLnnYyaGUzuHrVYkuzKxFdAIMqBoVZCZuSeALnRvvZiFFVIrechVlgmohiipvoDTrRNAUrbyLEJKasQpMCEDvjyMBJQHnVZoQictVuCkBNJrGQwgePjiZPtCiHUEmdFdNyUJAoY")) {
        for (int lOvmfvvtuiMEZD = 2098440076; lOvmfvvtuiMEZD > 0; lOvmfvvtuiMEZD--) {
            sGcvtTUGtbcYYM /= PGYsLfDqJfhi;
            AdrOkN = NVQQoGwHRTDWL;
        }
    }

    return NVQQoGwHRTDWL;
}

double qlQntfGl::phsCj()
{
    int GZnMtHLPoJulv = 960730542;
    double InBpli = -18130.799228099393;
    double rzaPgmm = -723425.871462525;

    for (int neEHFelrzv = 352258604; neEHFelrzv > 0; neEHFelrzv--) {
        rzaPgmm /= rzaPgmm;
        rzaPgmm = rzaPgmm;
        GZnMtHLPoJulv += GZnMtHLPoJulv;
        rzaPgmm += InBpli;
        InBpli -= InBpli;
    }

    if (rzaPgmm > -18130.799228099393) {
        for (int Uunoryi = 2021939391; Uunoryi > 0; Uunoryi--) {
            InBpli = InBpli;
            GZnMtHLPoJulv -= GZnMtHLPoJulv;
            InBpli += rzaPgmm;
            InBpli *= rzaPgmm;
            GZnMtHLPoJulv = GZnMtHLPoJulv;
            GZnMtHLPoJulv *= GZnMtHLPoJulv;
            InBpli = rzaPgmm;
        }
    }

    return rzaPgmm;
}

void qlQntfGl::oWqDEjnfKIsbxgZ(int nNVNM, double bOeJm, double FtaxIi, int xfeWsgpkxM, double zcRiHpnxxmlzdOE)
{
    bool LXMkLlce = true;
    int BWChIu = 400848185;
    double DTDrksupIvhbNx = 616234.5284181974;
    bool ohAXepmKYHvsicx = false;

    for (int ywNePeZuRiFx = 1150803804; ywNePeZuRiFx > 0; ywNePeZuRiFx--) {
        nNVNM *= BWChIu;
        DTDrksupIvhbNx -= DTDrksupIvhbNx;
        ohAXepmKYHvsicx = ! ohAXepmKYHvsicx;
        nNVNM *= nNVNM;
        LXMkLlce = ! ohAXepmKYHvsicx;
        bOeJm -= DTDrksupIvhbNx;
        BWChIu = xfeWsgpkxM;
    }

    for (int aIqPOph = 608685322; aIqPOph > 0; aIqPOph--) {
        continue;
    }
}

string qlQntfGl::WiHvsIsMxFDMtae(int imLaDeQmH, int clwPlYUbun, int gRPIIKruTWFt, double dMqFNcpUQm)
{
    double poeAz = -241931.4886624857;

    for (int MSYavmYIJAfuPU = 1040977105; MSYavmYIJAfuPU > 0; MSYavmYIJAfuPU--) {
        dMqFNcpUQm *= dMqFNcpUQm;
        dMqFNcpUQm /= dMqFNcpUQm;
        clwPlYUbun -= clwPlYUbun;
        gRPIIKruTWFt /= clwPlYUbun;
        clwPlYUbun += clwPlYUbun;
    }

    if (poeAz > 216480.63827654597) {
        for (int rqrSfckXXZ = 1376793183; rqrSfckXXZ > 0; rqrSfckXXZ--) {
            poeAz -= dMqFNcpUQm;
            imLaDeQmH += gRPIIKruTWFt;
            poeAz /= poeAz;
            clwPlYUbun += gRPIIKruTWFt;
            gRPIIKruTWFt += clwPlYUbun;
            gRPIIKruTWFt += gRPIIKruTWFt;
        }
    }

    return string("FUXhQjXdMNQIydQWzngqQntOWXIdiBjHTFnYCMlPnblVpeERaBJRybYrHbyCHMzEDYirQCKvsfJVOprgKWBJRTwGFRCDbPgZrmbiBkQGrEhWSXvwldTDirlMvjQGRQkUbjOyHrByrNLNWbGSDGPXrzGDPWUrOPPDiMTQQARIBWbykRUlFDVHOxcbqqYJPUXzCTri");
}

bool qlQntfGl::WanvQCqVF(double XnppUNud, int MRtpLdaPFNoNc, int OJzlBDkBgk, double QeFRwOLjLw, bool yIbMnPLPnvMjjhn)
{
    string RMHSCWuCCWbkL = string("mzk");
    bool eBqxd = false;

    for (int UajbFAPgNEA = 19320763; UajbFAPgNEA > 0; UajbFAPgNEA--) {
        continue;
    }

    if (eBqxd == false) {
        for (int KABHWNdRYHaF = 1671000977; KABHWNdRYHaF > 0; KABHWNdRYHaF--) {
            continue;
        }
    }

    return eBqxd;
}

double qlQntfGl::Sqxutuigi(bool mzDYB, int WWFxVTcGEKwdPBv, bool KZlRpVRITgbcoRA, string KqGcwibGgto, string QWLfT)
{
    string sQxGjIQzo = string("QrLrUDEXTVGLKdmBOMzAXRmflYCJKUaCoimaqjkVXFZtvszrYXjOGEGMsaExxalsHNuvmBjcMwPLWptUBWeOJxEKNFvoekCfOORnKxcJVwGgGSANPwMuaFFEQMYLednwotTUTDbFZikdQugMhcbpQYOFPWrTwR");
    bool rXqlLHV = false;
    bool OrKsYuWDY = true;

    if (rXqlLHV == false) {
        for (int yFNhO = 1668977285; yFNhO > 0; yFNhO--) {
            KqGcwibGgto += QWLfT;
            KZlRpVRITgbcoRA = ! OrKsYuWDY;
        }
    }

    return -178139.5503361655;
}

double qlQntfGl::cUppBhMbCAAZG(string DWeQKUwTWPvlXa, bool cwGbLmKwOOlUrnqQ, int ibYWacaOWADBov, string sblIaVLGSZTO)
{
    int ZBLCYgafidnWPAKP = 1135555900;
    double BMvKiaYhe = 842646.5920400951;
    bool TNHjmOF = true;
    string jwzjMepa = string("atsfhwaTmdGbnaZlUMDMeBRlnkRsuMTxHeTKJJpDXOTepQKiGUauNuLRkiTsAvNhzLwNhxHHuKyXQnAjUPhUHOdeAUTFiRHFgnkkOwNbTaMbuahxFGULshsuXvxuhINixDOPRDgvGtYbKqTEGyDxspATCnYuFauCjYnrdcJrpuOXvPnSbxJtpsMhfiyDpEUXlhLoAcoLupvlXzHHMLsjTj");
    bool YahWZRUXcPzCP = false;
    int eebCVhay = 1819065452;
    string wIgAgzdcXQga = string("JAGkStdjdbXSksRAXTEMinmfiKUSkBuQLJymIzVTeCZOXTmVrGSDTqnqzUkhVbLSXUiWnzgaXUuoisUsEPLaQN");
    bool aGDSItpuKeEraL = true;

    for (int nkwmPZYAeKvvpp = 1248812411; nkwmPZYAeKvvpp > 0; nkwmPZYAeKvvpp--) {
        continue;
    }

    if (aGDSItpuKeEraL == false) {
        for (int OJnOhGWoB = 1623890556; OJnOhGWoB > 0; OJnOhGWoB--) {
            DWeQKUwTWPvlXa = sblIaVLGSZTO;
            ZBLCYgafidnWPAKP = eebCVhay;
            aGDSItpuKeEraL = aGDSItpuKeEraL;
        }
    }

    if (TNHjmOF == false) {
        for (int yyBZMn = 1065844951; yyBZMn > 0; yyBZMn--) {
            continue;
        }
    }

    for (int rznrn = 654693612; rznrn > 0; rznrn--) {
        TNHjmOF = ! YahWZRUXcPzCP;
        sblIaVLGSZTO += wIgAgzdcXQga;
        TNHjmOF = ! cwGbLmKwOOlUrnqQ;
    }

    return BMvKiaYhe;
}

double qlQntfGl::vfPxymbagKUMYSW(string BcEzTnnVwqnCFjlQ)
{
    bool TdYbcITa = false;
    string JajjnzKDoJYBa = string("urtmEOTgkPQgAguIfBiLyJhpFySxGnABDUGVrPjTkEjOUsoYiUTRhemYsucNQMavDJgmxAaXcTSJAaPPLromWklzlMUfffPLvYikFyZTBtzjUCypBRwwSIfnReYrFGaLBAGWKWdNZdTycvaPdpNlYgnICQxTonyBoaiEjNemRSvGFmZqqbtsSgFBOAfQZMML");
    bool qjxujEmsCTauIh = false;
    int OwHhEwEwGIU = -144323322;

    for (int FSBAFcnVDeN = 513590047; FSBAFcnVDeN > 0; FSBAFcnVDeN--) {
        TdYbcITa = ! TdYbcITa;
        BcEzTnnVwqnCFjlQ = JajjnzKDoJYBa;
        BcEzTnnVwqnCFjlQ = BcEzTnnVwqnCFjlQ;
        qjxujEmsCTauIh = ! TdYbcITa;
    }

    for (int NDSBTYdFQIxCnVK = 2126870625; NDSBTYdFQIxCnVK > 0; NDSBTYdFQIxCnVK--) {
        BcEzTnnVwqnCFjlQ += JajjnzKDoJYBa;
        BcEzTnnVwqnCFjlQ = JajjnzKDoJYBa;
    }

    if (JajjnzKDoJYBa < string("urtmEOTgkPQgAguIfBiLyJhpFySxGnABDUGVrPjTkEjOUsoYiUTRhemYsucNQMavDJgmxAaXcTSJAaPPLromWklzlMUfffPLvYikFyZTBtzjUCypBRwwSIfnReYrFGaLBAGWKWdNZdTycvaPdpNlYgnICQxTonyBoaiEjNemRSvGFmZqqbtsSgFBOAfQZMML")) {
        for (int bmomcNrzWgeDSaPb = 2085481930; bmomcNrzWgeDSaPb > 0; bmomcNrzWgeDSaPb--) {
            JajjnzKDoJYBa = BcEzTnnVwqnCFjlQ;
            qjxujEmsCTauIh = TdYbcITa;
            JajjnzKDoJYBa += BcEzTnnVwqnCFjlQ;
            qjxujEmsCTauIh = qjxujEmsCTauIh;
        }
    }

    for (int YacAWrHMTRUB = 1011420598; YacAWrHMTRUB > 0; YacAWrHMTRUB--) {
        JajjnzKDoJYBa = JajjnzKDoJYBa;
        BcEzTnnVwqnCFjlQ = JajjnzKDoJYBa;
        TdYbcITa = ! qjxujEmsCTauIh;
        JajjnzKDoJYBa += JajjnzKDoJYBa;
    }

    for (int CSVubq = 1019763379; CSVubq > 0; CSVubq--) {
        continue;
    }

    return -84057.55772435776;
}

bool qlQntfGl::hkQfgnAq(double BoLeJKzUl)
{
    double EGUvfmJTTMNE = 918880.6529572036;
    int AaYXjLPMQjsQA = -1467811890;
    string IkKNtYU = string("DmZPeNbzEkEAOlTgXYIfOXtprjlKqNLcqORgmNQJohCQzYexKEkpiSQxFPyRQDEABZWoSaChtyeJZeHDrNZdpyASHJrDBoJYTrnvlybQfjMgPcHDOxXtswdNDuPBLKJSrClhrOsnmyIaNQquWvidkMUdeChtYCXeujYTSmAEopHBcFJTTIdWLVAsKVIQtvORTaBLldOIbwduy");
    int zORubKcXXMh = 1311605542;
    double AmqtcWfsNIRvpl = 942987.3548417055;
    double VdSJQBwjAyXGq = -194920.76391348417;
    double bfTgdTrZDMzI = 786741.7304885295;
    bool yvSnheWrNmvd = true;

    for (int mrQyhPzSbuJdr = 1917734301; mrQyhPzSbuJdr > 0; mrQyhPzSbuJdr--) {
        EGUvfmJTTMNE *= AmqtcWfsNIRvpl;
        IkKNtYU = IkKNtYU;
        zORubKcXXMh = zORubKcXXMh;
    }

    for (int RFAYLYpJYdNP = 1706427888; RFAYLYpJYdNP > 0; RFAYLYpJYdNP--) {
        EGUvfmJTTMNE /= EGUvfmJTTMNE;
        VdSJQBwjAyXGq *= VdSJQBwjAyXGq;
    }

    for (int GJnBHIMAgyj = 592857846; GJnBHIMAgyj > 0; GJnBHIMAgyj--) {
        bfTgdTrZDMzI *= BoLeJKzUl;
    }

    for (int QjGYIwEg = 2007238925; QjGYIwEg > 0; QjGYIwEg--) {
        EGUvfmJTTMNE -= AmqtcWfsNIRvpl;
        EGUvfmJTTMNE *= EGUvfmJTTMNE;
        bfTgdTrZDMzI = EGUvfmJTTMNE;
        AmqtcWfsNIRvpl /= AmqtcWfsNIRvpl;
    }

    return yvSnheWrNmvd;
}

int qlQntfGl::tbpJNlppKxwNEzZk(string aDKbZDtDpgGrRJt)
{
    bool GFrQXDSW = true;
    int lnymtPZCotikOTQ = -1358583509;
    int gjCWDEhgBCDflFE = -1623376767;
    bool wxTLKcRYVMIpeW = false;
    string BwrPuws = string("znGvoEXJMpuLdZFwbIqFCwZFcwyDWFDPnsZPbJbbEAuyMCXOolZuLsMCrTIFVxJQEArDTaMKOBAZUNbQpIOiAIzXKPdiUDZGRcMjLToduREtoyLlizVOdGDIuRoClwIWeqHmBsyfIWSVMUUgRVcBJGHxYHWvyAsAHIaQeAKvhkzeRgYuyGuZqnXOjBOYCwbkdYQgCHBsjkryEEpwDiIsQUdkknmsoesytjBGNgMMEqSTDZbBGfiQQNKFydLqKqA");
    string HEIUYBYTvEMQpkk = string("jUGHGXfDQmlSUVVKtNRMGfAHFnzvYojiSJPULdIhSZfdInMTqunckhIrExyxcvBfvdRZbvwcWoHRECjpaothDuwppJLSczrSYJbZPmdMobK");
    string agrxuHCouqEfZXR = string("jOXDuHHxnNEgmzXSfHaIIQEnItbZjWwLsfAFpLapYnwUUykKJjLYPFasqBcqVVerAYUdqYQa");
    double nAyWZw = -626701.1287732758;
    bool aYdEhhoOVJYBX = true;

    if (wxTLKcRYVMIpeW != false) {
        for (int gGSWugiI = 1883263007; gGSWugiI > 0; gGSWugiI--) {
            continue;
        }
    }

    if (nAyWZw == -626701.1287732758) {
        for (int vpeBGKaO = 1501855348; vpeBGKaO > 0; vpeBGKaO--) {
            GFrQXDSW = aYdEhhoOVJYBX;
            wxTLKcRYVMIpeW = GFrQXDSW;
            wxTLKcRYVMIpeW = ! GFrQXDSW;
        }
    }

    return gjCWDEhgBCDflFE;
}

bool qlQntfGl::TYPAb()
{
    bool fEMbeigJBXTrkc = true;
    bool cEJxhSMThyIr = true;
    int wfvZrUAnG = 1931248298;
    int DCRftCngAIQVjhZg = -801507825;
    int dPzjUW = -1086752469;
    double bIofrqfLLiJBZ = 65991.43894772253;
    double xckrTRRWaeCONUjk = -108551.94332432323;
    int gybJcqq = 1944093842;
    double OxlrMtjbFI = -328092.958140425;
    double lsVPhwIllRM = -678673.2391187341;

    if (OxlrMtjbFI < -678673.2391187341) {
        for (int MJNpmWAhQMSCmf = 1631595759; MJNpmWAhQMSCmf > 0; MJNpmWAhQMSCmf--) {
            continue;
        }
    }

    if (wfvZrUAnG != -801507825) {
        for (int LBQXcprBsq = 682500661; LBQXcprBsq > 0; LBQXcprBsq--) {
            lsVPhwIllRM /= lsVPhwIllRM;
        }
    }

    for (int JmfSFUztyKGcHfR = 813794965; JmfSFUztyKGcHfR > 0; JmfSFUztyKGcHfR--) {
        dPzjUW += gybJcqq;
        fEMbeigJBXTrkc = fEMbeigJBXTrkc;
    }

    return cEJxhSMThyIr;
}

double qlQntfGl::BTwzxS(bool wMDfDm, double IXysMfzHcrsOiEwX, double dMQCAoBsIAY, double IbHKrFa, string WPYqOelDnlpDCII)
{
    string UiyOUeXDEYtL = string("GpaPxgixvgbFsvnWckJjpGBoOAjKgjXwxbbmczrZMfbrD");

    if (IbHKrFa > -339004.33465765056) {
        for (int RFAxwgCH = 1802972662; RFAxwgCH > 0; RFAxwgCH--) {
            IXysMfzHcrsOiEwX += dMQCAoBsIAY;
            IXysMfzHcrsOiEwX += IXysMfzHcrsOiEwX;
            IXysMfzHcrsOiEwX += dMQCAoBsIAY;
            IXysMfzHcrsOiEwX *= dMQCAoBsIAY;
        }
    }

    return IbHKrFa;
}

qlQntfGl::qlQntfGl()
{
    this->PbGmzy();
    this->TIDAOwQmKbwFCD(string("hrV"), false, 49924.41879065012, -1416429101);
    this->FQnSvfnXOK(string("fYThWLaYdSHjSeCzFNYbWkIKAkbiPaHslYhoGGqFMOxCHTZkQSrDrPJsNwnjtrnAwLMxoZdqCSpggWEodMHgJxdJnyhgKhFvaVbstrCEptxhWThkyGSveezFlsiHyHxLaonGzofVzmOQXAYQpJRWQPiHdMaEs"), true, false, -1495019571, 1057057297);
    this->mzIkkGNfWhmZuSn();
    this->gRajIdKodrpXeyaC(452387494, true, true, -124545.90305207149);
    this->FrxHPEIcSt(-838192194, true);
    this->MOatXSkzqiET(-1471610338, -358432956, 1796881271, string("FibrktbqFVIIutaiUfNGbEyZfHLdAYifykBsGYHzKMHUiiFtouRoBRhHqudmgWwRVoFxtasjXfSQdNBrQQZLzetpBLUAWIfpUZyvkstnEQJvcIxKPKiyGprCYfKrLYudAwlhrIGfwPVUfzJMCZurfgIVSJGtnDgjHsvIeXoVHerbXlKtSSqzOTwAnLumcGQqQOKJXxAKoCaMGQc"), -341085.926879054);
    this->waPZuTEgUEiwyo(string("tNgapKIuEJIPPUTfeuVRvOXzIaNxZmVgVgmJOgrZXNiybzsXCKPYdpNgqadNfziSPaOuUZOwpDflFYKtMAsAZyFChxwnKKEptNXrgtAaXWEqPmNWjfJrgbMZewjojFXHUjwbwFasKoZQxqNsyLLJEbazTHVpNqM"), -370277.42409985315, true);
    this->dsicOYitjDr(string("t"), -2052069007, string("QiiTLrrLPEcGPalfaUJpYIKgeywzgmkOjHoHtGzNWOsLnnYyaGUzuHrVYkuzKxFdAIMqBoVZCZuSeALnRvvZiFFVIrechVlgmohiipvoDTrRNAUrbyLEJKasQpMCEDvjyMBJQHnVZoQictVuCkBNJrGQwgePjiZPtCiHUEmdFdNyUJAoY"), -492327.7238557068);
    this->phsCj();
    this->oWqDEjnfKIsbxgZ(478803146, 498446.61148704926, -552426.541773462, -1350976975, 1038191.2648860244);
    this->WiHvsIsMxFDMtae(-343635735, -1789428061, 1230746273, 216480.63827654597);
    this->WanvQCqVF(122464.4574223265, 2130209045, 1400801231, -651145.1295349351, false);
    this->Sqxutuigi(false, 1179265268, false, string("uuTAFTMXxBWlGDyvSBPJ"), string("fwmXuoPbSLAGlUVULmyQjHNdutVEuXlpwYzpMhjXfjQVqKeDhuvJYjhcrbAlytGjFnowkdYxNoYHtjtjdJduQvoFpMFXrAOPGMWReoDFDMqWJyGSKblZiskFokOmKoNNITCswizr"));
    this->cUppBhMbCAAZG(string("ozjSEqyDNKuEzfXEYUHMDOMdEtmQRg"), false, -937983895, string("JySREYQSmVEJYNErClkJyfsBKdNKPfQzqwVuWkrbOYyUpCAfzWiShBrhCnugVBjPfMIhqLjdVVUfZxvEndqMtlzYlaRjyDRcEJhQbhSwmWiLTOAHlVATklrSaAPwoFROFRBkOFMBu"));
    this->vfPxymbagKUMYSW(string("CMloxvGBgKPpGavMMmawXSlNzjlWDLPCoFfVrkBKDfKZYFxotblVhHYPgqkEIGllBSiqrlyJrNxJryKophFQjnWrDVYvdgjJAjugZSJZrgXuxHdTAvfpexywJEcxDpSABrxBxiXpJsEdDLbtWuZxqVtbtiUsnSKTYfplMgiBLwFgEnmbcLmyxSHRPjjpnWTtTHUhFchtveX"));
    this->hkQfgnAq(-172519.5691435528);
    this->tbpJNlppKxwNEzZk(string("FUIpbFDvViyKPLojjMkXNAfkeMKCjXLyQkpChPcuEkUtWDtGuvlYEgskcJdJbKKkwBqKuoETzpoSSZUYGOJiIfxRAHJoxdjBQktQhtxfwAzbejQujQLhnlhYRxazgOsiSUwfArnfCIofDZziDHKVMMGBQCoZfZbheDSJAihKWwwGQygZXklOeEPynZYiKQSoCwZKHZDjGIrPdqUUdCozkGpkvJQJrqGxxnzHioHbHlbz"));
    this->TYPAb();
    this->BTwzxS(true, 791989.5417252299, 961685.6184003024, -339004.33465765056, string("uLORGHtNbGYNjhTcAAWgZKKeAmGvQArcczmvduHxVuYOLVlPaqUGbnYDJYxobIhdljBkxKgEpMXeWz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VfIPdylSDFJFakZ
{
public:
    int YWbpzMRtzHlXGKg;
    string nPksEruETfe;
    double zaafAtEofJ;
    int qIjUJiJCnxsviiCz;

    VfIPdylSDFJFakZ();
    void BiFPY(int NiRKmjwDzBL, int sPbghr, double dJIzxBaKhiOlCQzp);
    double caodHocfVL(string dtGVPyMQs, string MwJsclWUdjbFfIAC, string YnaFShxJfR);
    string iBVwkGQe(bool FXYSOznW, int NEwBL, string wDBTuBMkqOmg);
protected:
    string MiPFqztbth;
    string SXYWjK;

    void zHCzz(string JpesslAw, int XbFsguYUgDFe, double AOktVOzfmzUNrat, string QzhvgxFiihgydmW);
    int LEieHRZXFbSJaPC(string utwDOqLggJlMWIbo, string otzRNNXkK, double vbZde);
    int rGCfkZzOC(int rLkJPMvR, string VkNeMKCzcwHh, bool eXQaZqDjiU);
private:
    string nAvwxMYGxeYooC;
    double SmdsfKUGQVLW;
    string xmEfRLBzHz;
    string aDzVYYNyGhSTA;
    string PaYWKDWtMW;
    int IsKbFYWzA;

    string GOIXukPbgmhvb(string eDdrmtQGbjFcaTZ);
    void nHQCoz(string iJDiO, double ObMhQUEKdHJsmX, string oAtVc, int usZtrvevhAlB);
    void COadlvpxSaMMv();
};

void VfIPdylSDFJFakZ::BiFPY(int NiRKmjwDzBL, int sPbghr, double dJIzxBaKhiOlCQzp)
{
    double eDmoStOn = 2321.141778060876;

    if (sPbghr != 2119400728) {
        for (int jDMldDvuxQMQEp = 27092046; jDMldDvuxQMQEp > 0; jDMldDvuxQMQEp--) {
            NiRKmjwDzBL -= NiRKmjwDzBL;
            eDmoStOn /= eDmoStOn;
            sPbghr -= sPbghr;
        }
    }

    if (dJIzxBaKhiOlCQzp != 2321.141778060876) {
        for (int RVUKUACjmFXtiorf = 1242440491; RVUKUACjmFXtiorf > 0; RVUKUACjmFXtiorf--) {
            sPbghr /= sPbghr;
            eDmoStOn /= dJIzxBaKhiOlCQzp;
        }
    }
}

double VfIPdylSDFJFakZ::caodHocfVL(string dtGVPyMQs, string MwJsclWUdjbFfIAC, string YnaFShxJfR)
{
    string TQPJkBVOfpE = string("IFjpqNZvNAcBtUgJCqSrqsZXwCMNQVQTUTXnBsYpoVOWLeYRJleIrtNxuLkPVklvEMqTBHKAcjLJcPTDXISfLIhHcHhpnQjKPuRsTxfnKu");
    int DmNAuIiefBT = -981823872;
    string SnQDcUmymrLGO = string("zPiiDscUyQRKdycvjhVZPgWJSBXJJQdZDgSFBPzgWxGzzRCBpvqsshyOkJntFDoZNQeWbvEiqCfNmGUdUmbZRwuePKazMFqkckrsuBhAEPQfEZKCLLgjsomKYtkkLXlkzgrwTHVzpHdlbZDYTvzYcqYRZudxlPFkBAWQ");
    string WBfYIuIguM = string("DCVOYDcrywlOMMuokEyqiiqPrBqcOveznYWwxWYpRdHOdfKtbndbObyzrdBGPXOZKUDPxA");
    string VXMul = string("zSbgfAhsteGneYImMwDCURoMItXhvMkEFfnxEwdgGDryrfacRPnYHGJaIjxPLyzNwyocqMVPJSIhKRfrymnJshrjIFVzYCRHmjdLYfMEmd");
    bool umOidELSUjpGDGz = false;

    if (VXMul < string("ypDUurPqEMfObN")) {
        for (int cjHGGAQcSYHHLg = 358823255; cjHGGAQcSYHHLg > 0; cjHGGAQcSYHHLg--) {
            dtGVPyMQs = dtGVPyMQs;
            VXMul = dtGVPyMQs;
            VXMul = YnaFShxJfR;
            MwJsclWUdjbFfIAC += SnQDcUmymrLGO;
            YnaFShxJfR += TQPJkBVOfpE;
            VXMul += WBfYIuIguM;
            TQPJkBVOfpE += YnaFShxJfR;
            MwJsclWUdjbFfIAC = VXMul;
        }
    }

    return 39603.93140466786;
}

string VfIPdylSDFJFakZ::iBVwkGQe(bool FXYSOznW, int NEwBL, string wDBTuBMkqOmg)
{
    double zhXJuPsAN = 224955.756046788;

    for (int UInqX = 1955220931; UInqX > 0; UInqX--) {
        continue;
    }

    for (int UQhFAySLvYq = 814804302; UQhFAySLvYq > 0; UQhFAySLvYq--) {
        wDBTuBMkqOmg += wDBTuBMkqOmg;
    }

    for (int yozbNPn = 1964027682; yozbNPn > 0; yozbNPn--) {
        FXYSOznW = FXYSOznW;
        FXYSOznW = ! FXYSOznW;
    }

    return wDBTuBMkqOmg;
}

void VfIPdylSDFJFakZ::zHCzz(string JpesslAw, int XbFsguYUgDFe, double AOktVOzfmzUNrat, string QzhvgxFiihgydmW)
{
    int ZttJPkWQT = -1083158387;
    string IYNhS = string("ynNoEBhEXDiwg");

    for (int XueBqQw = 663797108; XueBqQw > 0; XueBqQw--) {
        continue;
    }

    for (int sfTZjJvspVbm = 287329487; sfTZjJvspVbm > 0; sfTZjJvspVbm--) {
        QzhvgxFiihgydmW += QzhvgxFiihgydmW;
        XbFsguYUgDFe /= ZttJPkWQT;
        QzhvgxFiihgydmW = JpesslAw;
    }
}

int VfIPdylSDFJFakZ::LEieHRZXFbSJaPC(string utwDOqLggJlMWIbo, string otzRNNXkK, double vbZde)
{
    double dsXdMoTlB = 517834.7620112326;
    double WpEaODrxfS = 168164.70470432332;
    int UOaLNftaMjNzQRLG = -1571345286;
    int GWJzUzxYwHoBMK = 1883630704;
    bool PgzRPNbEBhvVi = true;
    bool qeZHTLaaXiNKNQTH = true;
    bool jrPtXdPVuoEcSfIJ = true;
    int IIeyOL = -1855950051;
    bool LRPlYbXhsXzVgn = false;

    for (int MdNdUXAvbua = 497469055; MdNdUXAvbua > 0; MdNdUXAvbua--) {
        utwDOqLggJlMWIbo = otzRNNXkK;
        utwDOqLggJlMWIbo = otzRNNXkK;
        utwDOqLggJlMWIbo = utwDOqLggJlMWIbo;
    }

    for (int onUGoI = 76831330; onUGoI > 0; onUGoI--) {
        continue;
    }

    for (int rjAouWkXsxexejU = 82245397; rjAouWkXsxexejU > 0; rjAouWkXsxexejU--) {
        jrPtXdPVuoEcSfIJ = PgzRPNbEBhvVi;
        utwDOqLggJlMWIbo += otzRNNXkK;
    }

    return IIeyOL;
}

int VfIPdylSDFJFakZ::rGCfkZzOC(int rLkJPMvR, string VkNeMKCzcwHh, bool eXQaZqDjiU)
{
    string ycKCImEOITB = string("sxVGVLVfkaLyqAfcUbFGdRJtfEmZgqgzCgkIUQQidZCEbOiuKbiClGCysAMmybodnGYpkdAzEoSNZCoMcabfbaOzsMKYDXFZpVrMJkIarXBstBhCsUakFywjBkCSOBjegasYXjIMUOItanJCeXxbpOrWwvEOUgxxFJmsTJWkKpqiFPuaXrxBpUnfBbfUOJCxSXdSRwJoZjTbDEAQduy");
    double nKpLuU = 435942.43597155146;

    return rLkJPMvR;
}

string VfIPdylSDFJFakZ::GOIXukPbgmhvb(string eDdrmtQGbjFcaTZ)
{
    string tWnWzhZEJMoYd = string("gwewcxvNFumUfvyKVAjqWZpMDkhvYQZblTDVnGEmBuXxAXoJsYbILQKtAAnISVGYzQHXtMvKebeSFevkEbCVVFtzckZcnmtlpQbRzcWtCiwCnV");
    double eUSHOoacEaLWhP = 837200.6373800286;
    bool ddQAaAPTX = false;
    int UZgUWQtGquofhXfk = -1775181776;
    int WNgoW = -1868665090;
    bool lAFoxuEW = false;
    int zEqDjLhxNAMeNab = 89276310;

    for (int AMgGIfkztUQ = 1802806731; AMgGIfkztUQ > 0; AMgGIfkztUQ--) {
        UZgUWQtGquofhXfk += zEqDjLhxNAMeNab;
        eDdrmtQGbjFcaTZ += eDdrmtQGbjFcaTZ;
        eDdrmtQGbjFcaTZ = eDdrmtQGbjFcaTZ;
        tWnWzhZEJMoYd = tWnWzhZEJMoYd;
        UZgUWQtGquofhXfk *= WNgoW;
    }

    for (int rDHXyiuWBaaoB = 414355010; rDHXyiuWBaaoB > 0; rDHXyiuWBaaoB--) {
        ddQAaAPTX = ddQAaAPTX;
        WNgoW -= WNgoW;
    }

    for (int RGmwZQfPlKkeb = 335102751; RGmwZQfPlKkeb > 0; RGmwZQfPlKkeb--) {
        zEqDjLhxNAMeNab *= UZgUWQtGquofhXfk;
        lAFoxuEW = ! ddQAaAPTX;
    }

    return tWnWzhZEJMoYd;
}

void VfIPdylSDFJFakZ::nHQCoz(string iJDiO, double ObMhQUEKdHJsmX, string oAtVc, int usZtrvevhAlB)
{
    int AYkmIHywe = 581509668;
    string kvqVBqPBR = string("vIYcPdvtJlHLNDqNAhclAusgjTXkvFyItPvvoJeOeEVGmEBvyyiKSuJrcgqRqmssWjploqQnwcznYnedrZvOOfwuGyJtFNQNwDsEdcGnTjDDXlkjcgrTTpBmaPNyiKFHrddvydiipkiZGWGZVjTLZtbeqyufvbrSTiXPttrbDzovAMiCnqunbgyDWkvNetJxUVyShQETsdwOttaHoZcgtHnpEynZPrQex");
    bool szESlRmjR = false;
    bool YiyxUBIkTRw = true;
    double recwWKTWgn = 931881.0763807804;
    bool vPiOMTOerms = false;
    int xHGJmdoTKUP = -1096511978;
    bool TUVnLsy = false;
    string tMGmtf = string("lubBmNFbYcIsqSIkcOcUSrESYAQTSbSvDeAGTXDRoaUjEEZrHPXvJXosXynwDezSgdmCyXnaBZuupwgKFAUegqZTaYXomzDSCLUTUxkJgmUdMzwgfSSGWUNTxpDDXQifEv");
}

void VfIPdylSDFJFakZ::COadlvpxSaMMv()
{
    double ygzbsc = 859968.4786347055;
    bool cSFAvqEfRrS = true;
    double uiGorVesRbEkfkOV = -83068.11605857736;
    bool ZHwICmGCwL = true;

    if (ygzbsc != -83068.11605857736) {
        for (int pHBkG = 2039007014; pHBkG > 0; pHBkG--) {
            ygzbsc = uiGorVesRbEkfkOV;
            cSFAvqEfRrS = ZHwICmGCwL;
            ZHwICmGCwL = ZHwICmGCwL;
        }
    }

    for (int xlEbNwCJSRxbMvz = 1467260908; xlEbNwCJSRxbMvz > 0; xlEbNwCJSRxbMvz--) {
        cSFAvqEfRrS = ! cSFAvqEfRrS;
    }

    if (cSFAvqEfRrS == true) {
        for (int MRdUxLjOyURBkOs = 1359463174; MRdUxLjOyURBkOs > 0; MRdUxLjOyURBkOs--) {
            cSFAvqEfRrS = ! cSFAvqEfRrS;
            uiGorVesRbEkfkOV -= ygzbsc;
            uiGorVesRbEkfkOV = ygzbsc;
        }
    }

    if (cSFAvqEfRrS != true) {
        for (int XuUMiKjwFZGDPWnb = 723334646; XuUMiKjwFZGDPWnb > 0; XuUMiKjwFZGDPWnb--) {
            cSFAvqEfRrS = cSFAvqEfRrS;
            ygzbsc += uiGorVesRbEkfkOV;
            uiGorVesRbEkfkOV += uiGorVesRbEkfkOV;
            ZHwICmGCwL = ! ZHwICmGCwL;
            ygzbsc = ygzbsc;
        }
    }
}

VfIPdylSDFJFakZ::VfIPdylSDFJFakZ()
{
    this->BiFPY(2119400728, -1266083002, 746560.1086914171);
    this->caodHocfVL(string("SVZfhZhhZEGCAwzKpHgEKPOLUUhOWmahhsGjFJCBAuQPTEVvSDZDiLlYdUFnSlFjokMlaADQjvozstetplDdWdhEPdWxoLTmWeNuhaitWpnBeIYONONwGagEliZdsNaNRbvWfcsVMJFZUqCGEwYuarJxOgDIvugphYqGlNKv"), string("ypDUurPqEMfObN"), string("FlaaxxlNqlDTmYf"));
    this->iBVwkGQe(false, 28034264, string("UHhvXpEQKwQcBcDRypINvOETZEhTdeQjfcwWYvqLzdgWyxXDsPGvshFniyxjkWjwZHgscwVVQNiBJHPZGzTOhPJldcSwswaBrjcntRqvuTq"));
    this->zHCzz(string("mUJVBRBaodvTGFNxAlWMnUzuUbmouxeGeCEKsusluLIpsWrNmHvlzSBULclUnQEmCdkgQtINtPZOkKHMiMPTEJZFjGgaNSNRDGClYJWmlUsdEKLonZXvIZXPjXLbCDYZesRxaBHCqUZJBFtDBbQvgeDQkBfQcHcYNkNXokjZjWHPRTlokEQVaVUMJBJprrbDgkPnUvidiOwQLcgNXZv"), 717321756, 14014.442727870322, string("zYJBadCDWd"));
    this->LEieHRZXFbSJaPC(string("MWygNHrJQNzaFVXVfvKIMpaHhYGYsORihGiAHLU"), string("bZHwEWiQYIwpqWLYjDZExBESBGcxAFepTyvUEtleGZVIrDSJHeZngDMmpHrQZBsEjuDlAhmSOYrRiCtjXlWEXfDCuszSkHoADjoIAgohnIIQpyWtXepbdBPyGqvScuoIPdNzdqBtFWlGzhQlZoXhTcqMiRuhZmctbYozjRDoSYZmXvUmkoFaqJKDEalWgIsKeDZIcobiBOAWxIBNd"), -691235.1461194798);
    this->rGCfkZzOC(-2043889720, string("MeEExfEnXwOaaZKboCkvOgVZwgTLumHmdYGOWwYMmxOVUosTznaBiQlLJcEFwjrirzLCZppuUvlEqjziLxBpmNsjfFcJhjYlHJYggbuqGQxgSxSoDftsuqhQcwEVUUusfGAzfXNDuZKdFgNn"), false);
    this->GOIXukPbgmhvb(string("SXnJokhAvWOIodzyLWYhOLofawncZGiZPAuiEKjbCtkPjsxFUJJpzYhvBySimwpYootDpfjSFGZFqKcGCeycohWmoRzgXGvhdwulmNktPWkjxiYHqvWntOZypnLuFQnUdedoqAirDYorVPyHQiOrfGRfFVEtcldFaIopqmmHugekWSMrtXnVCXrKpHOQihGDIQECtwEZXixQmoXJtotpgqy"));
    this->nHQCoz(string("hPLQtejVcsoUufvZuCTZmETBbdyPHZOosUqeOJaqwsWqMPYcHyuWyoubHkVDNOWtSwgCdKezxzXQUYYDrhpfXAMlawXzanSsZhGpbkgUiQvShSCsJbHRaxHZBYSFVwxKTMvLNfToYVvCmJOnmN"), 370235.93882327806, string("LMiZPMYrWjWkjQlKcmhSfhqkrQzDFcaLdvgUAbqkwktjgj"), 1971452833);
    this->COadlvpxSaMMv();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class IHbFE
{
public:
    double NvoUahuu;
    string tVoiLhnMcmK;
    int rCVYx;

    IHbFE();
    void qihlIOOZ(string Klgmue, string azFaAacZcmFyO);
protected:
    bool omHIDKXfIcCcK;
    bool dUMVIWVUF;
    int wapNGfeKveB;

    double CdRTv(double XwCpoqtJDweWhyuY, int OvLdFmheo);
    string VqZksv(string dbulADjm, string qVYBtgMIbNmzj, string gNqfU, bool BnWTKBsXvcg);
    int OeVZbpKnLQwzXRIg(int wicsujEr);
    void yngMOW(bool lZOdkziXL, double Cmxqm, int bmNwZxGCHE, double VJJrerHIdAu, bool LUrqsCdzLCTQiju);
    string xmUeICx(string mCxMuyXkvtVo);
    bool OIhXCWojy(double VubluCnaqei, string GYTqnwkMpbrpNzFC, string wcRwHtCEukk, string edbVA, bool NBUHbf);
    bool AOBLAIJAs();
private:
    bool bjuSACB;
    bool oBscyqOeISOANzR;
    string PmIrgXFAKPdO;
    string IssoFXX;

    string gcHBtQALku(bool WKXqrXLmhoV);
    void XIXfpKxG(string bTZWLVdOOKsxA, bool TnrBY, double DIKFMjQROguw, string OINXCWo, bool tdYrlPLdmsiKWpao);
    bool uUUArRkfQfDgjQ(double oKSJrKiQsOK, double bZVEanzge, bool FhjgHcJUuyKKkR, int uSyKlTpXHNYLRF);
    void lJZvkmJMypYNV(bool wfkibhPbxtd, double xIfGESnV, string OEsLZShS, string SvrkofoYbRzKd);
    int MKsQsteUEgYRW(string PlkHhEdlsRZZx, int TwfUhJPYW, bool EWokEJOGED, double YsZcZ);
    void BOQXLXpkBrBXKd(double mNAKgvWYWeQwJM, string iqREHDig);
    string NaDyXYmGrwTKXO(bool YYidVDkcV, int YCBkaQQeE, int GlqHKozHmRyOv, string yXeJrAtZzmdlD);
    double VteHCKml();
};

void IHbFE::qihlIOOZ(string Klgmue, string azFaAacZcmFyO)
{
    double DaoYgSdobUSrL = 355081.1443289264;
    int rgPDM = 315208052;
    double KRxZEcLAiVvTXQ = -168597.95367141455;
}

double IHbFE::CdRTv(double XwCpoqtJDweWhyuY, int OvLdFmheo)
{
    int nEgVuCygpQDbRP = 1413275010;
    double QpVTJCREJIMYnOuz = 68687.7443529695;
    double yQjQpZvlHhOdAAzb = -960727.4578770234;
    bool NNShSdfAGaq = false;
    bool FWvWFu = true;
    string aFRdmEiYUqDYr = string("JpvrrVVXritzkuamILeBhezvdbSVzbqHsuUXvUxieGYEpefnDAEIcqXSYAGwWXpYFtDFcyRoXmBHtwbPVFszwuUFvkDogsvsAfbDeKMgTeadvweLdywWlAeVqQzlnZlUcvLRkupzslzJMeiyKDdwezPiXcSBpifovwaOEZloouzGQyVrXqxOkvgNgErmuGoNlkOyePXnXKTqgVVZamApsDrLw");
    int ujzWqc = 2127521353;
    string WiAHMIMvRL = string("QWZDedPiu");
    int pESLSBesxYsk = 1300377001;

    if (nEgVuCygpQDbRP < 1413275010) {
        for (int ubJbVfl = 1167785560; ubJbVfl > 0; ubJbVfl--) {
            pESLSBesxYsk *= ujzWqc;
            XwCpoqtJDweWhyuY /= yQjQpZvlHhOdAAzb;
            XwCpoqtJDweWhyuY = XwCpoqtJDweWhyuY;
        }
    }

    if (pESLSBesxYsk != 275550681) {
        for (int wQsVWvhBKRj = 761704261; wQsVWvhBKRj > 0; wQsVWvhBKRj--) {
            XwCpoqtJDweWhyuY += QpVTJCREJIMYnOuz;
            OvLdFmheo += pESLSBesxYsk;
            nEgVuCygpQDbRP /= nEgVuCygpQDbRP;
            yQjQpZvlHhOdAAzb = QpVTJCREJIMYnOuz;
        }
    }

    if (XwCpoqtJDweWhyuY == 68687.7443529695) {
        for (int gjbCr = 2127182295; gjbCr > 0; gjbCr--) {
            QpVTJCREJIMYnOuz = XwCpoqtJDweWhyuY;
        }
    }

    for (int GellgEGfLJPuzxT = 1098318764; GellgEGfLJPuzxT > 0; GellgEGfLJPuzxT--) {
        FWvWFu = ! NNShSdfAGaq;
    }

    return yQjQpZvlHhOdAAzb;
}

string IHbFE::VqZksv(string dbulADjm, string qVYBtgMIbNmzj, string gNqfU, bool BnWTKBsXvcg)
{
    double szFRwIOUX = -60644.567117092774;

    if (dbulADjm <= string("byFDCHCFEbkKfRNHsxTHKRUdpMtpiMfnaXYADqVkvFNIJrnZvYvshAf")) {
        for (int suEECLdUCD = 72135068; suEECLdUCD > 0; suEECLdUCD--) {
            qVYBtgMIbNmzj = qVYBtgMIbNmzj;
        }
    }

    return gNqfU;
}

int IHbFE::OeVZbpKnLQwzXRIg(int wicsujEr)
{
    bool KjOvwqJtNeQVH = true;
    string qWHMfs = string("vLeUBplLBogYzYFzMUOzMJSvsQXTEZhChVnRhlvCSaAjAFarLBvuRqOENUpsvQcJfwmeVbpfdjrRElrtaBrZFGrYjSlvzCdWGYxtsmpuYIfjKfTvpRrdVifX");
    string rPeuhMFANMDEDFKO = string("YUummZtpewHeaqoDurrxZMFZlAYKeVYxMkBhDjcFAVVworJkikdDIZkzZc");
    int RDnCPzwPgpvJmGNl = 192293909;
    double ScNDTIRGBRcfKSN = -790765.1201959442;
    double KeDlx = -59794.66924710247;
    string cUmdjn = string("KbPavKktlSFQQylfepyfsbKhU");
    double qTravUP = -34955.681130095974;
    double OwtkWUrb = 580574.0874423861;

    if (ScNDTIRGBRcfKSN >= -34955.681130095974) {
        for (int UkkPYRDMHOlFj = 516854490; UkkPYRDMHOlFj > 0; UkkPYRDMHOlFj--) {
            OwtkWUrb += KeDlx;
            qWHMfs = cUmdjn;
            KeDlx /= ScNDTIRGBRcfKSN;
        }
    }

    for (int RIPWVfbdlgK = 1730577944; RIPWVfbdlgK > 0; RIPWVfbdlgK--) {
        continue;
    }

    if (cUmdjn < string("YUummZtpewHeaqoDurrxZMFZlAYKeVYxMkBhDjcFAVVworJkikdDIZkzZc")) {
        for (int qZYuuqQfdwJDby = 1038875646; qZYuuqQfdwJDby > 0; qZYuuqQfdwJDby--) {
            cUmdjn = rPeuhMFANMDEDFKO;
            rPeuhMFANMDEDFKO += cUmdjn;
            KjOvwqJtNeQVH = ! KjOvwqJtNeQVH;
            RDnCPzwPgpvJmGNl += RDnCPzwPgpvJmGNl;
            RDnCPzwPgpvJmGNl /= RDnCPzwPgpvJmGNl;
        }
    }

    for (int yHATY = 1941616109; yHATY > 0; yHATY--) {
        OwtkWUrb = OwtkWUrb;
        cUmdjn += rPeuhMFANMDEDFKO;
    }

    return RDnCPzwPgpvJmGNl;
}

void IHbFE::yngMOW(bool lZOdkziXL, double Cmxqm, int bmNwZxGCHE, double VJJrerHIdAu, bool LUrqsCdzLCTQiju)
{
    bool vJuLCy = true;
    bool hNAJe = true;
    bool YVgXBBC = true;
    double BtdSNktPZ = -148392.60241319364;
    int pYvqkJ = -719419774;
    double QlXZAu = -875375.3327380829;

    for (int OepDyK = 1294262632; OepDyK > 0; OepDyK--) {
        YVgXBBC = hNAJe;
    }

    if (BtdSNktPZ == -875375.3327380829) {
        for (int CnNYwvgLWKW = 1234004416; CnNYwvgLWKW > 0; CnNYwvgLWKW--) {
            continue;
        }
    }

    for (int FdnWP = 268426697; FdnWP > 0; FdnWP--) {
        bmNwZxGCHE = pYvqkJ;
        YVgXBBC = ! LUrqsCdzLCTQiju;
    }

    if (vJuLCy == true) {
        for (int uWXexQGFItqg = 1219137769; uWXexQGFItqg > 0; uWXexQGFItqg--) {
            hNAJe = YVgXBBC;
            bmNwZxGCHE *= pYvqkJ;
        }
    }

    if (pYvqkJ != -681108335) {
        for (int GjyKYzOFZ = 156789004; GjyKYzOFZ > 0; GjyKYzOFZ--) {
            YVgXBBC = hNAJe;
            bmNwZxGCHE -= pYvqkJ;
            QlXZAu -= BtdSNktPZ;
        }
    }
}

string IHbFE::xmUeICx(string mCxMuyXkvtVo)
{
    bool VqoRbdgfDzYR = false;
    int nzhDxaOBUISAm = -110004405;
    double hYSPADgKy = -379814.5476218237;
    int RiqixW = 1451540173;
    string DHnaJUglxb = string("SCtkhtRXnULxnSosOZlLefHpTYwNCeXbDTBFlhbwJKPAeuIiJIzHJhmmKnDwhdNBOSxpPLUtFqXxaiVjGDvXuXGwmYODlDlNo");
    string UMEIcNsZKO = string("SInAkjJVSFcnScqiDHFatfLgzCqJSsaCwFintZPQuFfnmneXkO");
    double MtzsL = 817720.3427931742;

    if (nzhDxaOBUISAm <= 1451540173) {
        for (int sESvcGcbITGycoaD = 1369745909; sESvcGcbITGycoaD > 0; sESvcGcbITGycoaD--) {
            UMEIcNsZKO = UMEIcNsZKO;
        }
    }

    for (int fjPDWNHcdDX = 1593919491; fjPDWNHcdDX > 0; fjPDWNHcdDX--) {
        MtzsL *= hYSPADgKy;
    }

    return UMEIcNsZKO;
}

bool IHbFE::OIhXCWojy(double VubluCnaqei, string GYTqnwkMpbrpNzFC, string wcRwHtCEukk, string edbVA, bool NBUHbf)
{
    int klPCFgKPbXmai = 1565874861;
    string khICBAWBYZ = string("YpjOnZGsGncUtUCiRbiuxCiBvMNjQliDEVpkHHUxgnQzabTnDmcrIJcKSIOppXYHlmSteIUjKeiIEiRHF");

    for (int SvaPdy = 1621727061; SvaPdy > 0; SvaPdy--) {
        edbVA += GYTqnwkMpbrpNzFC;
        khICBAWBYZ += wcRwHtCEukk;
    }

    if (GYTqnwkMpbrpNzFC == string("ZZkHrLwagrrWusz")) {
        for (int jYcCp = 1095582375; jYcCp > 0; jYcCp--) {
            GYTqnwkMpbrpNzFC += GYTqnwkMpbrpNzFC;
            NBUHbf = ! NBUHbf;
            khICBAWBYZ += GYTqnwkMpbrpNzFC;
            wcRwHtCEukk = wcRwHtCEukk;
            edbVA = khICBAWBYZ;
        }
    }

    if (wcRwHtCEukk != string("YpjOnZGsGncUtUCiRbiuxCiBvMNjQliDEVpkHHUxgnQzabTnDmcrIJcKSIOppXYHlmSteIUjKeiIEiRHF")) {
        for (int GFUkqpYHrvCMRyv = 2137602436; GFUkqpYHrvCMRyv > 0; GFUkqpYHrvCMRyv--) {
            khICBAWBYZ = edbVA;
            wcRwHtCEukk += GYTqnwkMpbrpNzFC;
        }
    }

    for (int bpwPpuEx = 117522128; bpwPpuEx > 0; bpwPpuEx--) {
        khICBAWBYZ += wcRwHtCEukk;
        wcRwHtCEukk = edbVA;
    }

    return NBUHbf;
}

bool IHbFE::AOBLAIJAs()
{
    string cjRfZQn = string("dRJjUSmOtQWG");
    string dOVQHQjXDMZa = string("ZbzncTrbgFaDOloohTuBcHyvMwHmrtnMvFdqRNkWqiucYmXnkHJWuAQaDDJJcFFTTKFHwAjnnTovfhRnQkrEAFXEwXOIuT");
    double ZVgqomFctKxemOW = 669873.3795452879;
    string byGeLVXlVTMKhMfr = string("pIiKSvbJltOHZufBjnlPMZaOyMASGxwYeLXpebgfLaWiLkwWiNAiKxAaeTwvAlpjMRBDlECdoUBWyXBqGHtgZoRalfLfI");
    string bKfQrf = string("FffsfDctdvlyqYflrclKhquoGQixuzYqbjrHzBvftlCFgjpIRaRDYWmtnHSnUgEPZlWGHD");
    string pgmJfUeCXcIxKkD = string("mCyYXseqzafUxyKmmfuAVncQAyDCacgHPRDfvOLTeqPgvDkeyMIGxqiIGCwtVynNgozxogdpTNwISPdnJJUanWTaiMgKSVKvCckpibPADWADPzKnqBVElHZnHECRFnDcRWWBaJxKjBTJkLkpfoSgwlmzrFNlmADSIsBgxOYEKBeYbEynDRfjgLzUpRoIOuAgPknV");

    if (bKfQrf > string("ZbzncTrbgFaDOloohTuBcHyvMwHmrtnMvFdqRNkWqiucYmXnkHJWuAQaDDJJcFFTTKFHwAjnnTovfhRnQkrEAFXEwXOIuT")) {
        for (int JqFpTleau = 1434323066; JqFpTleau > 0; JqFpTleau--) {
            dOVQHQjXDMZa += pgmJfUeCXcIxKkD;
            bKfQrf = cjRfZQn;
            dOVQHQjXDMZa = pgmJfUeCXcIxKkD;
            cjRfZQn += bKfQrf;
            byGeLVXlVTMKhMfr += cjRfZQn;
            ZVgqomFctKxemOW += ZVgqomFctKxemOW;
        }
    }

    return false;
}

string IHbFE::gcHBtQALku(bool WKXqrXLmhoV)
{
    string yJendbu = string("yceOumctaoKQLqAsgxZKOzANGrhEzXeJwXgIHUpclxvMuYFgRhmtXHTNImvrsufgrKloGnVbBotLzCHxdnNUBoqU");
    double stOadOokknofumU = -263788.84979059396;
    bool XNomQj = true;
    string uDzPGARnPmRivAxL = string("gdVpIxrerdVWLFwiwdxINnjIzn");
    string QGAAehzYnfWLXQh = string("SBcsxlgOoqsnhlSfmTapCIvENeukYVkxJYKuCXpjznPBFlDqnORmkHRHxlUbNSQjuqMrqwlHGhVvUajHQbIbOQ");
    string gHsxzHNZMmnNgy = string("xXnvzvQsaCsdsMHPSjDqkfSqZJLPamVGRtzKotXZwCqFxMmYuFbHqyUvxqDSorqLFzfzanlQEosqTTUTSSZzanCPZzveQeewrhqPafiqVEGWGrWvSwzqjtymZrsPsBwTDIinTBZAitlEPDPNjHdPesXdZjlrZPzorhSJooQGhuPovPHhqEfOdHQvKxRHeSkiAojyObwutBPqkUSjUscVjXLCXPYyylhllCBAOkuuCAXbK");
    bool zbFuiUciFvT = false;
    int WdpZzjjMC = -1092800459;

    for (int bfijPWu = 1815992039; bfijPWu > 0; bfijPWu--) {
        XNomQj = XNomQj;
        WKXqrXLmhoV = zbFuiUciFvT;
    }

    if (gHsxzHNZMmnNgy == string("SBcsxlgOoqsnhlSfmTapCIvENeukYVkxJYKuCXpjznPBFlDqnORmkHRHxlUbNSQjuqMrqwlHGhVvUajHQbIbOQ")) {
        for (int WQMCgHpdvwPuy = 1399669572; WQMCgHpdvwPuy > 0; WQMCgHpdvwPuy--) {
            WKXqrXLmhoV = ! zbFuiUciFvT;
        }
    }

    if (gHsxzHNZMmnNgy == string("xXnvzvQsaCsdsMHPSjDqkfSqZJLPamVGRtzKotXZwCqFxMmYuFbHqyUvxqDSorqLFzfzanlQEosqTTUTSSZzanCPZzveQeewrhqPafiqVEGWGrWvSwzqjtymZrsPsBwTDIinTBZAitlEPDPNjHdPesXdZjlrZPzorhSJooQGhuPovPHhqEfOdHQvKxRHeSkiAojyObwutBPqkUSjUscVjXLCXPYyylhllCBAOkuuCAXbK")) {
        for (int ZZhKRKMdxUqk = 237720467; ZZhKRKMdxUqk > 0; ZZhKRKMdxUqk--) {
            XNomQj = ! zbFuiUciFvT;
        }
    }

    for (int sOrca = 650777868; sOrca > 0; sOrca--) {
        WKXqrXLmhoV = ! XNomQj;
        XNomQj = ! XNomQj;
        XNomQj = XNomQj;
    }

    return gHsxzHNZMmnNgy;
}

void IHbFE::XIXfpKxG(string bTZWLVdOOKsxA, bool TnrBY, double DIKFMjQROguw, string OINXCWo, bool tdYrlPLdmsiKWpao)
{
    double zwuVTTnjiygXMYw = -638211.2525939432;
    bool tWkLdffPwH = true;
    double mLrQxOBsujp = -64914.97757881702;
    bool eAxcqMkjMLJhNo = true;
    string FwWpFnSp = string("baxxnVzgSWziiHWTWrKEyVuwOdnmukeiwFQoPuOyKAXUKQpIUlieMCtDUBsHVizuIrbciGzgWGtXKRzayUiJsUEbZxcYUIczhdUMsnXsIvHJojoSAEjjEpMiPhSIKJkevASGHlmbhkNcJpYUgoQS");
    string bRpuWLEeQVise = string("nFTOquxIsbcNepTnHnAjCmCqWeHkYxaoEFlywUoQrwjyQjzldQuCsHTnbAOHSAVRsZvLdLQqflewwxGfOMhCpsoyLgJTZSoHKuLBuSmyzhjiXgmAnpMCrmtxSEckbzgRQmKdCmBDCwkYDDSpViueiunNiaaeRwKuvrBwsuVdkAkvlHdMkWPTvGWGJBnRwEuTWbVxijq");

    if (OINXCWo != string("nFTOquxIsbcNepTnHnAjCmCqWeHkYxaoEFlywUoQrwjyQjzldQuCsHTnbAOHSAVRsZvLdLQqflewwxGfOMhCpsoyLgJTZSoHKuLBuSmyzhjiXgmAnpMCrmtxSEckbzgRQmKdCmBDCwkYDDSpViueiunNiaaeRwKuvrBwsuVdkAkvlHdMkWPTvGWGJBnRwEuTWbVxijq")) {
        for (int TAgkRcN = 78361657; TAgkRcN > 0; TAgkRcN--) {
            eAxcqMkjMLJhNo = ! eAxcqMkjMLJhNo;
            tWkLdffPwH = tWkLdffPwH;
        }
    }

    for (int XarmiIeBDmvNJQXz = 1139478672; XarmiIeBDmvNJQXz > 0; XarmiIeBDmvNJQXz--) {
        OINXCWo = FwWpFnSp;
        eAxcqMkjMLJhNo = tdYrlPLdmsiKWpao;
        zwuVTTnjiygXMYw *= mLrQxOBsujp;
        FwWpFnSp = bTZWLVdOOKsxA;
    }
}

bool IHbFE::uUUArRkfQfDgjQ(double oKSJrKiQsOK, double bZVEanzge, bool FhjgHcJUuyKKkR, int uSyKlTpXHNYLRF)
{
    double UraCK = -338371.25612143916;
    int lchbuyyUasbbavgU = -2111116260;

    if (bZVEanzge == -338371.25612143916) {
        for (int Mtlpwvx = 1679997516; Mtlpwvx > 0; Mtlpwvx--) {
            continue;
        }
    }

    if (FhjgHcJUuyKKkR == true) {
        for (int AwYErKbOw = 342298143; AwYErKbOw > 0; AwYErKbOw--) {
            UraCK *= bZVEanzge;
        }
    }

    if (lchbuyyUasbbavgU < -1159554223) {
        for (int maHqyK = 671213691; maHqyK > 0; maHqyK--) {
            continue;
        }
    }

    return FhjgHcJUuyKKkR;
}

void IHbFE::lJZvkmJMypYNV(bool wfkibhPbxtd, double xIfGESnV, string OEsLZShS, string SvrkofoYbRzKd)
{
    int BFNlRxyVWgSO = 646330830;
    double GiZkqqVlxS = 803883.2004455283;
    double OveiXi = 582538.6191323331;
    int hrUGxeeELhBZvVw = 199866166;
    double bEJbITQlQLClTS = 474644.6187908997;
    double cPAaldGxExVuA = 640852.0705369607;
    string ostbXcBXAOJLOKfc = string("mFGfQCTVnEpRinoabWGRGxmwDUjeZiQQFjIVVuYIEc");
    int BNhvr = 90781106;
}

int IHbFE::MKsQsteUEgYRW(string PlkHhEdlsRZZx, int TwfUhJPYW, bool EWokEJOGED, double YsZcZ)
{
    string pnpOyTuuvGzndvib = string("PIRLAWHJpQhSaBMwEBWimxKWhmTUgpGWizMCjgdDeZKTQLyyyqSGOdKWcInZuUvBsiuNaenIlRCAUwpIumwDBxMvlvpkREVddVncRVAOJKayMTpOXYxGcdQSZtyMWHZWdppMPoJSRuBAuehSjvuYEOvHjLXETcZisByDgGBeqqxZNnPgInupFTHrmvjxzAVbuXejfDpdKsob");
    bool svlaG = true;

    for (int iDWEgplZPSelB = 614082530; iDWEgplZPSelB > 0; iDWEgplZPSelB--) {
        EWokEJOGED = svlaG;
        svlaG = ! EWokEJOGED;
        svlaG = ! EWokEJOGED;
    }

    if (svlaG == true) {
        for (int sbtEMINB = 1204866723; sbtEMINB > 0; sbtEMINB--) {
            PlkHhEdlsRZZx = pnpOyTuuvGzndvib;
            EWokEJOGED = EWokEJOGED;
            PlkHhEdlsRZZx = PlkHhEdlsRZZx;
        }
    }

    if (TwfUhJPYW != 1627484575) {
        for (int mEuUda = 853017161; mEuUda > 0; mEuUda--) {
            svlaG = svlaG;
            PlkHhEdlsRZZx += PlkHhEdlsRZZx;
        }
    }

    return TwfUhJPYW;
}

void IHbFE::BOQXLXpkBrBXKd(double mNAKgvWYWeQwJM, string iqREHDig)
{
    string zheMRqLCQKAUt = string("DZKLyEbWrIOLyQuSWHIaemnajduZOVUunmVYTGhwnIfwoqkDtbXMLyoiMcUCNUbASqtbDccQEaQolZGyfcwoddAQVNgwDkhNBAmnRkPeEIJlawzNTiuQZCXJMbPupWuXzoCBviHWydzEzXLqjidYOPqRyxHGEZ");
    bool CVjuobinENSZO = true;
    bool RgWNoxOxtToIYx = false;
    double SRVxIyb = 153566.19716399853;
    int EmQBDDG = -198808915;
    double rzyMHUNLidk = 189779.76345256803;

    if (SRVxIyb < -889315.338839139) {
        for (int QGSocKtRE = 411103119; QGSocKtRE > 0; QGSocKtRE--) {
            continue;
        }
    }

    for (int uNAqM = 1625341977; uNAqM > 0; uNAqM--) {
        EmQBDDG = EmQBDDG;
        zheMRqLCQKAUt += iqREHDig;
        CVjuobinENSZO = ! CVjuobinENSZO;
    }

    for (int YZRKrYJTzSi = 1375853726; YZRKrYJTzSi > 0; YZRKrYJTzSi--) {
        continue;
    }
}

string IHbFE::NaDyXYmGrwTKXO(bool YYidVDkcV, int YCBkaQQeE, int GlqHKozHmRyOv, string yXeJrAtZzmdlD)
{
    int YKkWdWNOyhfEY = -551158513;
    string DIkeZnGZBEsFO = string("ScmGeqYamSXLpdFJcIKHEGYhuIRiorRjPckwstGJgUrnMpYTED");
    bool PMWfx = true;
    int xpcxcTbSWnmBYyQd = 1015024680;
    int YBiEbJdDccsv = -563401387;
    double dbCxBukXZOPzgnD = -686714.2892748422;

    if (xpcxcTbSWnmBYyQd < -563401387) {
        for (int qdFnfsAS = 1746781993; qdFnfsAS > 0; qdFnfsAS--) {
            PMWfx = ! YYidVDkcV;
        }
    }

    for (int nlSzsNBcHKySxqXb = 1004269291; nlSzsNBcHKySxqXb > 0; nlSzsNBcHKySxqXb--) {
        YKkWdWNOyhfEY /= xpcxcTbSWnmBYyQd;
        GlqHKozHmRyOv -= YCBkaQQeE;
        GlqHKozHmRyOv /= xpcxcTbSWnmBYyQd;
    }

    if (xpcxcTbSWnmBYyQd < -628705495) {
        for (int oXobUf = 2139911430; oXobUf > 0; oXobUf--) {
            yXeJrAtZzmdlD += DIkeZnGZBEsFO;
            YYidVDkcV = ! YYidVDkcV;
        }
    }

    for (int BduiMsogS = 1095094491; BduiMsogS > 0; BduiMsogS--) {
        continue;
    }

    return DIkeZnGZBEsFO;
}

double IHbFE::VteHCKml()
{
    int onpZkLPnCwzE = 2120247063;
    double TJrrYNLgMygIO = -281898.1989887004;
    bool JTAIJLCnWaqkkgfN = true;
    int nJLeQAoPNW = 435071894;
    bool jDEXyAAhdTbGYLL = false;
    double iuJGnScwRQUN = 693635.246600757;
    int ftEZxOGlnuUXb = -1885319443;
    int toxbminBqDI = 1703004231;
    int WRLvYzUIGRMbw = 1006241767;
    int jwoXMzCYnMfeezi = 128203538;

    for (int thlHCuXBlDHBPWkh = 1790039259; thlHCuXBlDHBPWkh > 0; thlHCuXBlDHBPWkh--) {
        continue;
    }

    if (onpZkLPnCwzE >= 128203538) {
        for (int MMMlx = 684709198; MMMlx > 0; MMMlx--) {
            jwoXMzCYnMfeezi = WRLvYzUIGRMbw;
            ftEZxOGlnuUXb *= ftEZxOGlnuUXb;
            jDEXyAAhdTbGYLL = JTAIJLCnWaqkkgfN;
        }
    }

    for (int oWieXxqteCiC = 675377719; oWieXxqteCiC > 0; oWieXxqteCiC--) {
        nJLeQAoPNW += toxbminBqDI;
        onpZkLPnCwzE *= toxbminBqDI;
    }

    for (int gWzXDLLTaEL = 104165891; gWzXDLLTaEL > 0; gWzXDLLTaEL--) {
        ftEZxOGlnuUXb *= jwoXMzCYnMfeezi;
        onpZkLPnCwzE += WRLvYzUIGRMbw;
        ftEZxOGlnuUXb = ftEZxOGlnuUXb;
    }

    for (int iQhsnhCRiXZvcc = 1028871201; iQhsnhCRiXZvcc > 0; iQhsnhCRiXZvcc--) {
        onpZkLPnCwzE += ftEZxOGlnuUXb;
        jwoXMzCYnMfeezi += toxbminBqDI;
        ftEZxOGlnuUXb /= ftEZxOGlnuUXb;
    }

    if (onpZkLPnCwzE < 2120247063) {
        for (int CXMpOSmGCNRZf = 494740994; CXMpOSmGCNRZf > 0; CXMpOSmGCNRZf--) {
            ftEZxOGlnuUXb *= nJLeQAoPNW;
            onpZkLPnCwzE += nJLeQAoPNW;
            nJLeQAoPNW -= jwoXMzCYnMfeezi;
            WRLvYzUIGRMbw *= jwoXMzCYnMfeezi;
        }
    }

    for (int UNXQfdLhxbo = 1496984849; UNXQfdLhxbo > 0; UNXQfdLhxbo--) {
        ftEZxOGlnuUXb += jwoXMzCYnMfeezi;
        WRLvYzUIGRMbw -= nJLeQAoPNW;
        ftEZxOGlnuUXb += jwoXMzCYnMfeezi;
    }

    for (int eDywkPTrirthpyzg = 387139968; eDywkPTrirthpyzg > 0; eDywkPTrirthpyzg--) {
        toxbminBqDI /= nJLeQAoPNW;
        toxbminBqDI *= nJLeQAoPNW;
        nJLeQAoPNW /= onpZkLPnCwzE;
        WRLvYzUIGRMbw = jwoXMzCYnMfeezi;
    }

    return iuJGnScwRQUN;
}

IHbFE::IHbFE()
{
    this->qihlIOOZ(string("dobPcXelBgulaFXzoxbomzDoigmtUCRIdbJCJdOtSunfCdGWQDoOhwdsGEsqZEXJVPZCAmfAVHGAcQEXEtBDVSqlbTobbPOywdWCpVSRVjjcwOdsfsKbHkOUglOToBswQpbLbYvAQbHTlhRmpjjrrbRJuycbKyhsHGdJtDrlpMSU"), string("YMBnSkaLphH"));
    this->CdRTv(-166572.87064565174, 275550681);
    this->VqZksv(string("ZlqgwshEtcJGGBsGYbIfRasOBncfUjboveQZVpJVlcmaCRcILZbhDDoxtCUNMPVshLHCgnpeApHHOPutlTcolVluOKGzgQAdRQjBQqfOkiEbmUrOlxHDmTONmqmKfTGeocxNhSGcprDk"), string("byFDCHCFEbkKfRNHsxTHKRUdpMtpiMfnaXYADqVkvFNIJrnZvYvshAf"), string("hRvKJtlpnkKWsVlOKHNDLukKnecoEBjcPWKAaaIuUPzEIlaYGKNlzLmVIIpLlvwGBuZhNkKNbhLfoqovhyYXycgdFoNtZLXpMBZRXBWomIgVpuediIpnosZGWjqdOUepyLXVkyJWilVwZeiozNZddmrhSMvUqkuhoQfNhRPcLpPzFUBAbJTwRXELj"), false);
    this->OeVZbpKnLQwzXRIg(-166073732);
    this->yngMOW(true, -562631.2905972205, -681108335, 796939.8806522504, false);
    this->xmUeICx(string("fybqENiSfURKdpbdCWAxppWFNqUOUINHtJFSbKQRgYSOiAyJzAZcJPynblqzTDZXBOlHuVVvciGAhjBHzwuhUMuqQZmfnrXlTkMOaPFbFpBLSParOdcmyYfylBYofVpMfbGfGBHArIGupBYPVHdjNpwIVxMjTdUyiMcNyYdAM"));
    this->OIhXCWojy(245569.06717933292, string("DWKdfqcXLyQnKpsIfFoTzdXhSlvQzYbQMGyCsCwlCfqCiCYdmgkeJbEoFWsXvNrrpifhXbKwEDAHEKmOqLMaEUnHjrwVKFWDaZypwpUOIJOtgITzkKFDubYdclZgndzTJJSoZvdGNuPSpPSjdjOpqpBTechtLPLzBCrRfiSuuqwmmirQiCEOJ"), string("aHmKLqWKLucBVABHFPPunzaUpKBZGIOrCtJeg"), string("ZZkHrLwagrrWusz"), false);
    this->AOBLAIJAs();
    this->gcHBtQALku(false);
    this->XIXfpKxG(string("THtZmrgjbUrNjZVRSZNVkIMNtrmfguTKsdyemACoVjwCEDvFCgKGtpRrFJmnUuBgBQJosDZpvLlCCXmdSQrRaDbDMeWLmYaDVTDcNiJMBgoCZiJMgBmVingJlCZzMJWVcGGDXeHKJyAqkbkiXPmXcDKIkDqorhYzrtjSQTjgAHkZmNuVyDvQ"), true, 268748.10638158757, string("aPpMuyCaOxHqrsHRVvrWDlCHBYMgUgmjhuLnwtCPrmgjkZWWsFalUbVlEeWsCMAvBvdWkdQDpWUIYTqUCpFcLivzfLWvMNSOPTTzwJJTuBEtlTkRdZUiQnPoMlVLzySTCNUvXP"), false);
    this->uUUArRkfQfDgjQ(10561.99937349052, -951802.6270836538, true, -1159554223);
    this->lJZvkmJMypYNV(true, 576029.2942921561, string("hRuEvIKKHhDqGiPwwoHYJocFrDwHzRTzoeDUZrLJYsCgPDKPPccKxOVjzDHqiieBcOncazPfEebLCBfEfPUlSiKIBDbDjaOoJEYYWYnBdytASrQKNDyCrWDZlXoQlWyzHgHEdEJDLqzOdnlZTEuooSVqVPuhiTPNEmsnPHcPcBPAfaNmDqjydpUsGjvRZDVcgdJzbsQsQqdewSFnwFyHQgXzjUODedXyzXbfRvNgKbcXygTxQLGDjzopvddjTdR"), string("AgIzniRPaByLufzYEyYSZMruHEptZvEfpiqBvBvFpqKNufONzSHEODfXoCbnEpcJGDvumvzkDioOkaSeqwPnqeYRusQkUBZSFxmJQRCQQtASUOiaXHjLQhkPDftsmzSBHPzRTdGyabVJjNymEKhPUWyfxWmZmPoToLytdOvacmAzUbANNzHCHeqLsiwBEXUohPfsJFSwXqUlcCLWoRmrWrbDRlceejDUNMdc"));
    this->MKsQsteUEgYRW(string("WTvAHirucWEubWARuztecJMcXpYlpfsfTAAjpcowASlwrHfkFuhfekBFzJjkGrBZCkJLXhfpXaCtHcxFGaemMXvdiXcPTsxvZLTozKPQIhGWgaaHOqALEJydkdLcMKmPOCCTsglECPpRrkYyiJTKnBMluZcgyAWiOnrHFGQznxIoehLHK"), 1627484575, false, -571404.4296722653);
    this->BOQXLXpkBrBXKd(-889315.338839139, string("IqdyKhavAqcwVZBLCrzVEuTPThnuIZcKScJYJXItABGvpxBZbOaKDqTLDorURSNkJyYiTVOhfwJsCPwpsXoOCqZVZgiwfjYkpKEfNTuYLjLwwmboitGyqwaoshqKTcQanNVKBlgYdiMZYUolFQDrrRArKYaHMEUulrKoJmsIgCjxRVbxErWAjCaXWEMPxgMLsRuyLXXkZOVgqkaphbmKLgtCXdbjXpXktLyzdnD"));
    this->NaDyXYmGrwTKXO(true, -628705495, 765390371, string("emznZENOjUTcyqXFsRAxIqjWAZREZFyJHOpNoQmUmibSMxceZdYqfKMzoLfZYFAvMlFQMvYZEMnBniJTmTfswbFVVyPwPV"));
    this->VteHCKml();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dNXOVwzRmTxR
{
public:
    int uMJOirtNGPGGfyA;
    double OyWrFRRayrHBP;
    int tIljAPjj;

    dNXOVwzRmTxR();
protected:
    double GVsaodVFpxTNfU;
    bool eaJNbesZcczPiSH;
    string RVKWAKoq;
    string WjEvR;
    int FPewFgFnfjETGT;
    string fknFhuyKii;

    bool QCNuMRuPryt(double OmvkV, int fsvRgJ);
    bool OWyjWCtCvk();
    bool JmQXaXmOpQt(bool RXRHRx, int ZqhnXWP, double PXyHrHUH, int qKQEioNvlefrrPKx);
    string XJvddteyoEJHKYBQ(string JQaarGYqbjU, double FVmHwLpxu, int cZljaIabpzYpRDS);
private:
    int zPcgy;
    double pufKr;
    bool EEBOJBV;

    bool KedixudvzcaP(double hFKuTkF, int NNWrqy, bool xtccwYJ, string dLssnFTfmFBQZGrp, string nnPfFxFm);
    double DvZzMpwdMMFkBfV(int TakvCnRm, int PwKxJxlc, double dDBIIjKO);
    int lgOLYJywOMCvyj();
    double doonUkG();
    bool BuTbi();
};

bool dNXOVwzRmTxR::QCNuMRuPryt(double OmvkV, int fsvRgJ)
{
    int GrLhLiR = 1023037883;
    int myFpTfmGxmioh = -595938005;
    string vTNdHHQPGl = string("ZHJXmkuNvscZwFZJFqENlBWKLrbYslvbG");

    for (int kYeJqCwpMYakkAkc = 714971634; kYeJqCwpMYakkAkc > 0; kYeJqCwpMYakkAkc--) {
        fsvRgJ = myFpTfmGxmioh;
    }

    for (int ftsuQQtZnKGFIr = 1369077074; ftsuQQtZnKGFIr > 0; ftsuQQtZnKGFIr--) {
        myFpTfmGxmioh *= myFpTfmGxmioh;
        myFpTfmGxmioh /= myFpTfmGxmioh;
    }

    if (GrLhLiR > 1023037883) {
        for (int iwSTQEzcHHLOZfj = 418415662; iwSTQEzcHHLOZfj > 0; iwSTQEzcHHLOZfj--) {
            fsvRgJ /= myFpTfmGxmioh;
            myFpTfmGxmioh = fsvRgJ;
            GrLhLiR /= fsvRgJ;
            GrLhLiR /= fsvRgJ;
        }
    }

    if (OmvkV == 165499.14357337137) {
        for (int ViZBQY = 614660015; ViZBQY > 0; ViZBQY--) {
            continue;
        }
    }

    if (fsvRgJ < -908911003) {
        for (int DGdqevHk = 2088690412; DGdqevHk > 0; DGdqevHk--) {
            continue;
        }
    }

    if (myFpTfmGxmioh > -595938005) {
        for (int EmrQDx = 1370511943; EmrQDx > 0; EmrQDx--) {
            fsvRgJ += GrLhLiR;
        }
    }

    for (int rTQrevFvsP = 1820771003; rTQrevFvsP > 0; rTQrevFvsP--) {
        continue;
    }

    return true;
}

bool dNXOVwzRmTxR::OWyjWCtCvk()
{
    double CARyrIpmbl = 810177.9765141995;
    double JKireTakqpQZ = -768832.6755188353;
    int cqSUvs = 692237631;

    return true;
}

bool dNXOVwzRmTxR::JmQXaXmOpQt(bool RXRHRx, int ZqhnXWP, double PXyHrHUH, int qKQEioNvlefrrPKx)
{
    int LFSKSjQmbxEpgBXl = -1698861520;
    string pfrxgek = string("Sfhet");
    bool TQfXRETvEjeOwvkD = true;
    bool QUAPs = true;

    for (int agdfKWQcRQzgpmj = 991342985; agdfKWQcRQzgpmj > 0; agdfKWQcRQzgpmj--) {
        QUAPs = RXRHRx;
        pfrxgek = pfrxgek;
        RXRHRx = ! QUAPs;
        RXRHRx = RXRHRx;
    }

    if (qKQEioNvlefrrPKx == -1049456484) {
        for (int vpYSflcaM = 1393358288; vpYSflcaM > 0; vpYSflcaM--) {
            continue;
        }
    }

    for (int SJEEKMGHbWdfpcT = 1056568426; SJEEKMGHbWdfpcT > 0; SJEEKMGHbWdfpcT--) {
        LFSKSjQmbxEpgBXl /= LFSKSjQmbxEpgBXl;
    }

    for (int XdGbhqYZO = 1610924583; XdGbhqYZO > 0; XdGbhqYZO--) {
        QUAPs = RXRHRx;
        ZqhnXWP *= LFSKSjQmbxEpgBXl;
    }

    if (QUAPs != true) {
        for (int OPwBbJxANZqMfHJ = 687275212; OPwBbJxANZqMfHJ > 0; OPwBbJxANZqMfHJ--) {
            PXyHrHUH *= PXyHrHUH;
            LFSKSjQmbxEpgBXl /= LFSKSjQmbxEpgBXl;
            LFSKSjQmbxEpgBXl = LFSKSjQmbxEpgBXl;
        }
    }

    return QUAPs;
}

string dNXOVwzRmTxR::XJvddteyoEJHKYBQ(string JQaarGYqbjU, double FVmHwLpxu, int cZljaIabpzYpRDS)
{
    bool VZUajZySAd = true;

    if (cZljaIabpzYpRDS <= -2106205495) {
        for (int BiRVTxyh = 1119992355; BiRVTxyh > 0; BiRVTxyh--) {
            VZUajZySAd = ! VZUajZySAd;
            VZUajZySAd = VZUajZySAd;
            VZUajZySAd = VZUajZySAd;
            cZljaIabpzYpRDS -= cZljaIabpzYpRDS;
            FVmHwLpxu = FVmHwLpxu;
        }
    }

    for (int VualPGEOrkb = 280199089; VualPGEOrkb > 0; VualPGEOrkb--) {
        FVmHwLpxu -= FVmHwLpxu;
        cZljaIabpzYpRDS *= cZljaIabpzYpRDS;
    }

    for (int PWPFPGJXaqlV = 87062924; PWPFPGJXaqlV > 0; PWPFPGJXaqlV--) {
        cZljaIabpzYpRDS *= cZljaIabpzYpRDS;
        FVmHwLpxu = FVmHwLpxu;
    }

    for (int DpCyx = 952051759; DpCyx > 0; DpCyx--) {
        VZUajZySAd = ! VZUajZySAd;
        JQaarGYqbjU = JQaarGYqbjU;
        cZljaIabpzYpRDS -= cZljaIabpzYpRDS;
        cZljaIabpzYpRDS *= cZljaIabpzYpRDS;
        cZljaIabpzYpRDS /= cZljaIabpzYpRDS;
    }

    for (int hHMvwLIwmjYK = 431143048; hHMvwLIwmjYK > 0; hHMvwLIwmjYK--) {
        VZUajZySAd = ! VZUajZySAd;
        VZUajZySAd = VZUajZySAd;
        JQaarGYqbjU += JQaarGYqbjU;
    }

    for (int lJfkkcqnslKCph = 923337382; lJfkkcqnslKCph > 0; lJfkkcqnslKCph--) {
        VZUajZySAd = ! VZUajZySAd;
        VZUajZySAd = VZUajZySAd;
    }

    return JQaarGYqbjU;
}

bool dNXOVwzRmTxR::KedixudvzcaP(double hFKuTkF, int NNWrqy, bool xtccwYJ, string dLssnFTfmFBQZGrp, string nnPfFxFm)
{
    int rzYbwKLHrKh = 463238341;
    string tcWqHiiSLpB = string("lquAjoUSkTOrpLvuBXIkxAOrCpBpiZfhCrUZDLfVReTbMdsHETJYohpGoOyVsyVegkyZxtOFNwansfZwRXeGaFJRDAVmXcZIzKtleaqWLdOBXhmyhvSRPEjpcQuZXIechUNswyp");

    for (int gavkf = 1932713163; gavkf > 0; gavkf--) {
        continue;
    }

    return xtccwYJ;
}

double dNXOVwzRmTxR::DvZzMpwdMMFkBfV(int TakvCnRm, int PwKxJxlc, double dDBIIjKO)
{
    string gmXOkms = string("ldWbMJBIjJHLmdhscqAVvxDyKroAeDcXmaKjIbmQDNlKLZOTGmaPpJuecmYDfNoKWpqnhaANzkfKunvIezmFAYKwrpKHQINWcxVucbtbjBnCZtnSQHXkvAQHlUYGyxJeimLbIy");
    string QSBaIinACOrdwITC = string("OaosfIODnwsCsKBjjONoGXvwESEkKSShNJsBtGRhRlNLWWviRvevzvrAWrzOEfokHsYtKgnEQJJxVXzALMyJsULJuLVTPVoAjRknQgOBcObTCxmebJNbWt");
    bool wwvRsb = false;
    string wsBQXiONxey = string("aeoWhbsDjmArKSNSNotbxmFpENXqEdxYdVmCTEOWfpldfaKwYTrxQlOMruJtHpdgnCCEHbzWwHMSPmGQeoFLbiTFJkVchF");
    int RgXmZWSiczuWKs = 1142316935;
    double fVSmiMWPpbVaBYs = 441007.40888592415;
    int JuXYfoeILPOO = -256391017;
    double PrwNFcQeiQXi = 997973.806653628;
    int tcCuYnk = 663567387;

    if (tcCuYnk != 663567387) {
        for (int FgbhYxd = 1214103861; FgbhYxd > 0; FgbhYxd--) {
            TakvCnRm *= tcCuYnk;
            wsBQXiONxey = QSBaIinACOrdwITC;
        }
    }

    for (int AavZFKHSOmL = 1458795301; AavZFKHSOmL > 0; AavZFKHSOmL--) {
        JuXYfoeILPOO = RgXmZWSiczuWKs;
    }

    return PrwNFcQeiQXi;
}

int dNXOVwzRmTxR::lgOLYJywOMCvyj()
{
    string YczKgpYTAg = string("bCXtEiSoVssOPflaGkqjCjkeGiPCoocComCDgOeYkLbpDBgpiAyVmGaAscFzsIvtxXxLLrmryDIuiwoScMliMFUiPIXWqbbXHvCkmbASqaWjoFvflvoqDjZnYPnDAjPcAmeIfvlHdzxrHChuWGLiTraYtPqUcYkMnTHiHSoOfFXjnLxmzFeBUIkghuwnsfWjfYUJucgvPEjGXVnRwpxGesdusLokMc");
    double iQZFDWe = 348656.2250341858;
    string bNbgQBssKUklDtMA = string("BdtcXWePmCXsIwRzgGLsWYsUMBCAxBpPoJwPKOdxrUIfSgKnLYzMCLDJhiqsFwRxIRVtSKVfcBsCfjWZmcwzAVrGnysuVpnfvGzzanEPJGCSCjMuIYmDhHBiyOxdFHFJJJArDbjECGhnEQngsRLLjNWlgmKxraRzwNhhwiLCCALEhzwUBzuwRzLVOTpKmMDtzVhSGfpRVTyqJcBRd");
    double QlrGF = -507375.2985739633;
    bool vJzpFmVTzMrI = true;
    string WUlvz = string("fEqgeoMUCgDGQqMMudZYUViATdhnmuSCwpWAYsAqZBxYvJZIcPfJBMAZfPYkzXQyfWJIXZtFbnTpDzyGyhsJRYVEAiEqXHjnkFcmhIUSeYGstZmPpZvZEBeESMIewuotLfSkhUJmlFQYkPXewhVPYKEvirYQrKvWLQaoIbqoidrDNEMkoTCiYMBYmiESwTkDqXsKTeqTmJwozaNmebkOeaBfYOlMMGtnidSldgBbZtDrJmRP");
    string qfGNxquXsjDPHzpR = string("EefLsyyltiQsmbOAUmtfESoyNpaYIhWIwbSqteHoGzTxuyPYPcjMyyhYjGRpPiGAqrawTHfwTywFtjgHCbiqemCYpzpNdaDvFoXytwNcCceBZEcJeNukDKDEKonCxmbvVhpAvexpcdEmbpHzxZZqweOEVTdZpJorHnZoNnWnc");
    bool lJLcH = true;
    int DKhXihkWH = -362539187;
    string cqNUKWi = string("mltwAAqkeWIxSGyjRMdfguaXVqceIFQmlQGnWaSXMtMdvUPwaeussPUZgioDcDCeWFQCCiOtBVEkAwg");

    for (int YQLGNxNqqoh = 370209340; YQLGNxNqqoh > 0; YQLGNxNqqoh--) {
        qfGNxquXsjDPHzpR += bNbgQBssKUklDtMA;
    }

    if (QlrGF == -507375.2985739633) {
        for (int FeBLfA = 651252018; FeBLfA > 0; FeBLfA--) {
            YczKgpYTAg += YczKgpYTAg;
            qfGNxquXsjDPHzpR += cqNUKWi;
        }
    }

    if (qfGNxquXsjDPHzpR >= string("bCXtEiSoVssOPflaGkqjCjkeGiPCoocComCDgOeYkLbpDBgpiAyVmGaAscFzsIvtxXxLLrmryDIuiwoScMliMFUiPIXWqbbXHvCkmbASqaWjoFvflvoqDjZnYPnDAjPcAmeIfvlHdzxrHChuWGLiTraYtPqUcYkMnTHiHSoOfFXjnLxmzFeBUIkghuwnsfWjfYUJucgvPEjGXVnRwpxGesdusLokMc")) {
        for (int feNwUfHREVXWRA = 87373239; feNwUfHREVXWRA > 0; feNwUfHREVXWRA--) {
            continue;
        }
    }

    return DKhXihkWH;
}

double dNXOVwzRmTxR::doonUkG()
{
    int JRKaACFccTWKMgYh = 1054368415;
    double ktbtXGq = -308425.4805548;
    bool JyCewmKRwP = true;
    bool TUExfOZFzvqVAwsq = false;
    double uShHelUPK = 191345.92259430705;
    double MvcyneWSYfRUHQXj = 974832.8261275655;
    int DNVNCW = -1203466428;
    bool VCbMPspiYzKHy = true;

    for (int jGBpCsObI = 515488952; jGBpCsObI > 0; jGBpCsObI--) {
        JRKaACFccTWKMgYh -= DNVNCW;
        VCbMPspiYzKHy = ! TUExfOZFzvqVAwsq;
        DNVNCW += DNVNCW;
        JRKaACFccTWKMgYh -= DNVNCW;
    }

    if (MvcyneWSYfRUHQXj != 191345.92259430705) {
        for (int LOMDbXsstKeksuU = 939527110; LOMDbXsstKeksuU > 0; LOMDbXsstKeksuU--) {
            continue;
        }
    }

    return MvcyneWSYfRUHQXj;
}

bool dNXOVwzRmTxR::BuTbi()
{
    string YkrDNmhBOWQNZE = string("DeLwjdapfXgarDJHsXzZFVfGLIJzSSnPDSAnLBVJrxFSwNSPmomBSzbFztWqksvIDPdADhvgBWnOlVkrhvCoyQQZtxDVKsBfTlPkCcshpIQPBrgaaRrKocXrijDqxHQvQGlPdIdWtRuSSakZEExcXkmlWTeyIxgExbosE");
    bool wRJpbzOsRKdJsEC = true;
    string qtIGNbsSeuJd = string("QqAVTWuirrzCeiiYJaUsztTJXhbNSgzZlnxcCgKURSLTPTtNgeizGrssITZUoryEBOlqXqeHKeBjqknlUbUjVZllOhnEHHcPBKiaQ");
    int JpTKMBKNuRkVzAC = 789976906;
    double MqGafdgBmooKQ = -234821.70084734928;
    string UvDLexcGUd = string("GwWaqDADSvllFIojttrXlHKjXCGiElmMBePmzVPLnfshDOKrDEagbDkUSQkeWtXefjAZvvtjrEbdHtZLoxJFrJXxZHoXsZCANJNGGlPmmfVPtJPQhEUEqhniGKHPtSmbEzuBlFicAvKStcrkDeJVxdBgNlgQrytmLTTMiYJPBxppxfPNcTe");
    int HrmAuiO = 602951740;
    bool uWmkM = false;
    double aSyhTXUbpACsOVj = -270504.46754362126;

    for (int sXhvRDqSGFYx = 1673193988; sXhvRDqSGFYx > 0; sXhvRDqSGFYx--) {
        continue;
    }

    return uWmkM;
}

dNXOVwzRmTxR::dNXOVwzRmTxR()
{
    this->QCNuMRuPryt(165499.14357337137, -908911003);
    this->OWyjWCtCvk();
    this->JmQXaXmOpQt(true, -1049456484, 240789.5990780055, 1957172702);
    this->XJvddteyoEJHKYBQ(string("yDWQSfzQLErGdcfzJuegwCDhTshQFIUBnTiCsIgUAEb"), -947154.8000694868, -2106205495);
    this->KedixudvzcaP(204498.23180317815, -2095129329, false, string("wWlzognogctIQMXLHMdPsQRapmMqRWuzAbHOqPseIENvZockYVWdTfSFqQxDDGtfCDpSBRTfSmHskLfUoIiKpriuTYcFZFceNYbGhZbyTjxejKaGGqENTfOwUOsQfVTGlmJYTJCdkmTurHPvaoTXXwWWALRyPhPgGsBkOiKdTyKf"), string("DGHQvkomfRWGLuWZaCNUNgqFelBHernuNsnkYpBxTztWcOwaDwZyogBzegxxdPURcVdvfAtWELddVnYDKSmsaKKFwIsjSHpQdpLuBteFcgkOIfAiYGfkwohYcwQzUxCsFrZYBhIvEdkKyMBOmFOlJEknJwCyvkjJdVb"));
    this->DvZzMpwdMMFkBfV(1869868115, -421351450, 411077.06639003445);
    this->lgOLYJywOMCvyj();
    this->doonUkG();
    this->BuTbi();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MUphXMOWUQxZSAkp
{
public:
    string FsfFIqanIFTm;
    bool vRKWzQuEIP;

    MUphXMOWUQxZSAkp();
    string zZDGNVTISYZEP(double lzPaiyKP, double SiEdEmet, bool xmAeDsfStYWJG);
    double cABLNMgJvUWHviKU(double kLALoWyfGTHgC, double vLfzpgAZzFQ, bool meNuLeDxRRIblb, double oqusF);
    int fXipk(string OaFSlrnv, bool jaZHUxnRKUNe, string hkbLxPzELAaghbBY, string MJFqURw, double ljmWBruKhViU);
protected:
    string dSUpUbcJlGeBmv;
    bool YlKfWYJBFtK;

private:
    bool qylUYFV;
    int vumnunP;
    bool gzjnDQywp;
    bool nofoIEw;

    double xcpJm();
    bool ZNtSAzQsPCwJ();
    string ILJpvJTZRU(string cgttWUYukT, int sxgqppEHLp);
    bool RRavpSVd();
};

string MUphXMOWUQxZSAkp::zZDGNVTISYZEP(double lzPaiyKP, double SiEdEmet, bool xmAeDsfStYWJG)
{
    int AxUTiZRYQSIRiB = -2007970027;
    string dBmYer = string("esFoWAkiKOhikPSZEuIOwBwJjYeutHLEWoJignHORA");
    double DGgZhzqsGJfJeSs = -328497.642925034;
    bool yYxSMohLzRw = false;
    int OMaVXNSlt = 1024118801;
    double CUiEH = -72805.48763168193;
    bool miqFySDdcHK = true;
    double eFzdv = 466043.2392069313;
    int rpxeobZKKWdbpt = 1358783867;

    for (int zKTvWWuJoDmK = 688644568; zKTvWWuJoDmK > 0; zKTvWWuJoDmK--) {
        DGgZhzqsGJfJeSs -= CUiEH;
        rpxeobZKKWdbpt += AxUTiZRYQSIRiB;
    }

    for (int tVeIByPdYO = 1149573774; tVeIByPdYO > 0; tVeIByPdYO--) {
        xmAeDsfStYWJG = xmAeDsfStYWJG;
    }

    if (CUiEH <= 466043.2392069313) {
        for (int ogXcyvPdqFG = 2044699450; ogXcyvPdqFG > 0; ogXcyvPdqFG--) {
            xmAeDsfStYWJG = ! miqFySDdcHK;
            CUiEH *= lzPaiyKP;
            rpxeobZKKWdbpt *= OMaVXNSlt;
        }
    }

    if (miqFySDdcHK != false) {
        for (int BSbjPD = 2021607669; BSbjPD > 0; BSbjPD--) {
            rpxeobZKKWdbpt -= OMaVXNSlt;
            DGgZhzqsGJfJeSs /= SiEdEmet;
            lzPaiyKP /= SiEdEmet;
        }
    }

    return dBmYer;
}

double MUphXMOWUQxZSAkp::cABLNMgJvUWHviKU(double kLALoWyfGTHgC, double vLfzpgAZzFQ, bool meNuLeDxRRIblb, double oqusF)
{
    int OcBhg = -1507840067;
    int wVNkmDkaMQkgNd = -482907007;
    string RRdqtazVS = string("yHvytmEgbpghqOwYswGHqNfORkQCLLNVSCQHPtAWRcVfHtYHGdIahgmJIAROkTpVXWZAVpiJwdXiiIBYDjDxqoPnGULSVGGhDJnYnDzXaIqrpFKIAuCIluxpFlcOMAbCpDUrHWHwxGUhtdafSDwboutIZtYedAFVYTZakNOUwizCaOIkJzagKIEbtSlriOESnMhFRABgfefzxpsRALzvaMJtzYKeoPnElswyJIgtrxNuqWIATNikAvyBvPCt");
    bool EogRVWaPtyuTzRC = false;
    double qFBPthNOpweW = 589545.0999095034;
    int hMWEBwkB = -1683892290;

    for (int wXEmLLhjxFgLDK = 273933126; wXEmLLhjxFgLDK > 0; wXEmLLhjxFgLDK--) {
        wVNkmDkaMQkgNd -= wVNkmDkaMQkgNd;
        wVNkmDkaMQkgNd /= wVNkmDkaMQkgNd;
    }

    for (int GhMqnEAiPEu = 169787721; GhMqnEAiPEu > 0; GhMqnEAiPEu--) {
        continue;
    }

    return qFBPthNOpweW;
}

int MUphXMOWUQxZSAkp::fXipk(string OaFSlrnv, bool jaZHUxnRKUNe, string hkbLxPzELAaghbBY, string MJFqURw, double ljmWBruKhViU)
{
    string cwVMBjRCVCEvTNra = string("MLxeostsJCKWbalKQfbepWMBXrANlUrJSNRwCBbgRnWLDTVpqvzaUwpCMustzAJxMdWUhKBTmYbHtihVmeYecZllyApLVLDHFLuHFhWjIaVjR");
    bool WMkJVhgHIJoOZ = false;
    double IRBbkSAzHblyqC = -224494.92463179026;
    string PSUKv = string("lfYTntmZGRXxdoXjjpHnhWIrsEMLCkqOCzXGpNMbWbgObhLEimsYUvdfnfraVuexWxbcRzxQFjXNPIgVkgVUysdEvWgYDzpdzXYuojaMPTKneUgWSTfVsNUZmzofISyFkDxxkPeYNBxpklSwiVSpVhGZseHfiJpNXseTGwJNmSlYzstYMaJlxKvAFgjaetiTTJpAMTBHWgRHfHpmXHQIwzfIcTsVcYpXBv");
    string MmDMF = string("TAUvaWRlVUhmYDRJppxNQLXEuLEuUMjprX");
    bool cbgsrPROxjW = true;
    int ULyTKVkuxXtA = -2114221683;
    double eoRNzSkbfGydPeG = 235326.49396103856;

    return ULyTKVkuxXtA;
}

double MUphXMOWUQxZSAkp::xcpJm()
{
    string BExtFNeJqLRYaWG = string("TUoOiKdaOwgzmXRpgHWidoAztOkiPjuZykSoxlL");
    int mjJswif = -721263981;
    int WLCWJP = 1733190633;
    double fXGbACIWLrTtqBT = -1026099.8366577241;

    return fXGbACIWLrTtqBT;
}

bool MUphXMOWUQxZSAkp::ZNtSAzQsPCwJ()
{
    bool TJmMpikPnc = true;
    bool JICylXtPigW = true;
    double AXgaXGaSbEIc = 47399.83443061651;
    bool VlRDwsEEbJ = false;
    double IghwZ = -832602.0622535385;
    string wjMmc = string("dRsscGScgFXoOzxShVXEdoaGtXrUpQqwEoxwFFLOSNfBrnnNuZyJkAPxrWNyhPyHPRECCBHsmONbqqqxvgbYOKybSdLUtOfDahOpytALKKaVPgOEibqlsLULZDHtWADDWouiYXKqMABaOtGinIBTwRIbCnfSGfRjGoiYCXkkiHcjmlMNfGbGPyoLLvXfmPMTvwETMCYUiHYgZkulparlrQSMpfwVHandHoWWsvCF");
    bool GzrAeYv = true;

    if (IghwZ < 47399.83443061651) {
        for (int EplkqT = 1847597707; EplkqT > 0; EplkqT--) {
            GzrAeYv = ! JICylXtPigW;
            GzrAeYv = ! VlRDwsEEbJ;
            TJmMpikPnc = ! TJmMpikPnc;
        }
    }

    if (JICylXtPigW == true) {
        for (int zMIVPaHhLbX = 276587855; zMIVPaHhLbX > 0; zMIVPaHhLbX--) {
            wjMmc += wjMmc;
            AXgaXGaSbEIc /= AXgaXGaSbEIc;
            JICylXtPigW = ! TJmMpikPnc;
            AXgaXGaSbEIc = AXgaXGaSbEIc;
        }
    }

    for (int tqmQzsftJEu = 43857903; tqmQzsftJEu > 0; tqmQzsftJEu--) {
        VlRDwsEEbJ = ! TJmMpikPnc;
    }

    return GzrAeYv;
}

string MUphXMOWUQxZSAkp::ILJpvJTZRU(string cgttWUYukT, int sxgqppEHLp)
{
    double cSDCTlhErsRZ = -674150.4147732548;
    double fpiukHHeiGJYSx = 296213.1747856576;
    bool lxCOeqAfrDyHW = true;
    double FoJEO = -30235.927629413884;
    double JzvdvnxKeX = 1007893.109620062;
    bool HaqRS = false;

    for (int ROWQSX = 1529687319; ROWQSX > 0; ROWQSX--) {
        fpiukHHeiGJYSx = fpiukHHeiGJYSx;
        JzvdvnxKeX -= JzvdvnxKeX;
    }

    return cgttWUYukT;
}

bool MUphXMOWUQxZSAkp::RRavpSVd()
{
    double jKOivg = 417079.56410647836;
    bool LzBsUypKELgkE = true;
    bool hcXZkMSjN = false;
    int lgZYZdOYQgQEMkhB = 843756335;
    string PNUespSLKTo = string("uvuyLMZpRVANyxEdZWpspiaqnyZxBhyoyqgxDGhrlkfQkObGfnfmPzWSCOIQVwbLsTKZthIYJnSQcIcPiUkNBiOCnNPFbbIOyZoSOafqHxLwGUHrXMZrXzLjJfjbDYELQaniHxOmrKyquxXOnPUuEnMeSZClxbQHfqkhNRauMdqKCbGSxAuJxqCumCBCwcRnKpnQTplNsbJzLVUVRMROjlJSTBD");

    return hcXZkMSjN;
}

MUphXMOWUQxZSAkp::MUphXMOWUQxZSAkp()
{
    this->zZDGNVTISYZEP(743669.1574709953, 712490.173467463, false);
    this->cABLNMgJvUWHviKU(-1019521.8136460299, 581129.6095921333, false, 473521.0649543068);
    this->fXipk(string("VLGVGKfixFPMrJLLmeAEccXOnRsMdWrEVHfiEjzJXRFWjnBqaPsAbkYkfKiUpbTRpZEmgnUBmdBPMcJrIBpgMsybvEvdCkeItJmZqIcqRIEatfBmHyFElnyIFFxmzURmNnlQTIfqRBEIWQelYolJfIBzBgzWiBHTByuRWTDmQraGEgEziwzRreaJFFjiYbmGO"), false, string("RBtoDRCcwpSHyQrlDdCpegZOsMEbTClIVqWBQtPHadCHMxeMqsahxjMYCUNzExJnGCfUXvLGzxVSJMtMUmHuFFWnPhZLXmuL"), string("CfkcecsDyjHqzsQdYpzoRVgNFJNyliIatYvhgwMPWjoqVLEEeWBWUgUbEbZvuEqBxMUpTVfFaqBVoxFCWIwTHHMKxfmkehVlcbqSPedUTccdNjwbRtiAWUOWicGXqRpraCshgeWjiKEdkJjtZyDKuqcDNroYcTUUzbVWGfAwPXn"), -306372.1156855879);
    this->xcpJm();
    this->ZNtSAzQsPCwJ();
    this->ILJpvJTZRU(string("HTOtsNMAgvLqYqXgCVZgbOpoOzlvbGkBASZpAqQPtx"), -925764176);
    this->RRavpSVd();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QYTFmm
{
public:
    string tGxTBluXZhgG;
    double QAQWJbPBDAyfelBl;
    int XoxGWG;
    double HkmyNqXGQOcQY;
    int wfLOmVMqdbMMl;
    double LwYCyRwuP;

    QYTFmm();
    bool YeGcrdw(bool NhYAlltIQn, int KUOGWLbCoKpcftXI, double GacRLNUupe);
    int fotrdDCzdo(double CjOijOWE, bool NHUeQtKDzKuALOOO, int GbzOtBkP, bool EpPNzPWPPsTOPs, bool ugTXGyKVJ);
    int AfzUnMErQKJb(double zbwGlxlVhi);
    bool mqbhdMqANWXKh(string DUehzP);
    double XqofhiWSGSKS(bool mCqMgpbp, bool SVXHvoRqDdP, bool tFwKhAHUzubzF, double NrXkAsKDBl, bool HHShqD);
    int taUnPY(double wCDdyFHcfJpwtt, string IjMEcgTN, double jvBrXIzDeS, string NakJC, string pElwvOXk);
    int cUvGwGfrjkmBGjA();
    string ObICgvuXkpGSs();
protected:
    double CnerXm;
    string ZGewNWZgY;
    string fdMTloLMhN;
    bool ZvCBH;

    bool ibDtIBeHJh(int LVrqLpLD, int ruaYJsi, double feAXENwTytxSS, string htMZYfYiTBRBoh, bool EVoHgkrgAHDh);
    double pYEsQiE(int PMISapJztZYFTFg, bool YeebbqIgvrU, string cvvEpi);
    bool lHzSjylCzhh(string cBtwxkQHDXzXpXht, string LllzPpFSfpfYVGP, double qKORcC);
    double TVDDjhz(double QREdRIonLySaPx);
    int wSkznecoECPbzn(string UUoZjn, double YaxjHxJs);
    void luEvm(bool flnBjOAJc, int tPbBZZ, bool JBqVOc);
    string SXvAKmBKeO(int MUZGhpiXT, int gTIFEie, double YaNGklL, double lBuEhJddVSgsNs);
private:
    string TlIaBV;
    double cwVzSnMLbzwl;
    double UipXgtkAPNqPunK;
    double kRtwzeaGY;
    bool uESpbEiQPjIUCGYW;
    int NvlKATk;

    string tnNMdaXVOzqwpNHM(bool RvCdzMcXJYhrZ, double uFGUCQsW, int aULTbhaNkiuCB, double ItzaZvYQUypw, string ySfsHMBNN);
    int QgMtIlqJNnCOGng(bool rZxapCvNO, int lpBxmaEu, double kbCSVeyIz, int OXAFUtOcVcFlbvA);
    int pdGEPFP(int xUYzQy, double CJlfCh);
    int uiLNPa(string VOczeN, bool rDhfHRsmdBCYr, int jwsBRfar, string PqgoDshjfDfeaFX);
    bool neGgLqDfonUeZrdj(bool MEdMFZgrkonkCy, int JUAQUSZWMHEUz, string CJuAiKykUYBR, int RxBuUj, int wsvpqGdGbNsrhU);
    int baITwqZ(bool qTKShNznpwktz, double mPKPfsneDMc, bool tdBOH, int zJeYQOM, int nnYqqFfQpG);
    void TsEqumunuLsw(double KZkhipTdyB, bool UmETkCPceDNCymAv, double sozOwyxgYwmVf, bool RSPTTbFy);
};

bool QYTFmm::YeGcrdw(bool NhYAlltIQn, int KUOGWLbCoKpcftXI, double GacRLNUupe)
{
    int AAomZsIYlxgiMK = -1604464569;
    double Jcykumdc = 798803.718453108;
    double ADVaHGxWphgbDFW = -182081.07925586746;
    string BBRcetHBUSMBp = string("GommkclzYvwTUpxqHIRkfBAaNucKOvsaxpiMYJEoEdbmdvpeXfwYd");

    for (int pioRbh = 242231326; pioRbh > 0; pioRbh--) {
        continue;
    }

    for (int WBTLpoPsim = 917475970; WBTLpoPsim > 0; WBTLpoPsim--) {
        GacRLNUupe *= Jcykumdc;
        NhYAlltIQn = ! NhYAlltIQn;
        ADVaHGxWphgbDFW /= ADVaHGxWphgbDFW;
        KUOGWLbCoKpcftXI /= AAomZsIYlxgiMK;
        Jcykumdc = Jcykumdc;
    }

    for (int jCMEnK = 1906863810; jCMEnK > 0; jCMEnK--) {
        BBRcetHBUSMBp += BBRcetHBUSMBp;
    }

    for (int Rhxst = 407350274; Rhxst > 0; Rhxst--) {
        continue;
    }

    return NhYAlltIQn;
}

int QYTFmm::fotrdDCzdo(double CjOijOWE, bool NHUeQtKDzKuALOOO, int GbzOtBkP, bool EpPNzPWPPsTOPs, bool ugTXGyKVJ)
{
    int JxLREjhZwcmbn = 1642412025;
    double RQpoWHkg = 201197.8506844315;
    int CsXwPJY = 159092543;

    for (int nGplimsOoHbtB = 1462918741; nGplimsOoHbtB > 0; nGplimsOoHbtB--) {
        EpPNzPWPPsTOPs = ! ugTXGyKVJ;
        CsXwPJY -= JxLREjhZwcmbn;
    }

    return CsXwPJY;
}

int QYTFmm::AfzUnMErQKJb(double zbwGlxlVhi)
{
    int EICFBmBzjUkmiVFc = 83715468;
    string MsLYCPKm = string("gPrCLYBJmhpnBXQdhsPFEBNYonhWwRcrPPPxsGheRkuzAhXcqUXEmunuAjRdlrLlWLJHwKptrgOedrGyqFWmFycUidOoTZPkwYneIKfMtCskhFYFABrrFgLnFFdfsNQDfJWPMwvMJzyUNQBQNFPzYO");
    string yMHIQrTSh = string("YnEEFEepQZNYGbkSkJCOWdxcvPwIxqbpzzTuNHaEjzxgXTKxNrUuQFVteDXEGnUWcsLHZHIiYJfJwVmxAidILkTzTelZEEcqAJtIUTgvZsxkTBopSGouioXyLHutmzFzRKpimVZrJTHa");
    double cgxfBuFwRe = 772847.5073312818;
    bool tuIsdvVewMnYEPu = false;
    double ZIyYPK = -46425.86418549348;
    string WiHVdecEx = string("ATKAYrdQUFVNXHDvLFSorBscTQayBIzxvdTTfXWmguJOrLeOdMBpJchNKjIkxhUbQS");
    bool ocUnWuLhDBzyKM = false;
    string hDvtfIJ = string("yJHVgaxnXXTinvXAVxoGKrWPVBMjyxcccFtYDuqClKAETZBWNOtmUMUcajHtMvYCpduVuSeZmQBSdMcQYyrdWVZIRhqdIidSjpxYJJUXvUcGDXuQwOvwbustgHtOHRXYSgNXCXYLuVIStTBJGAynwkhUGonfjcTgATbGkTCRFIICfgoesHkDgiENVkumhHZsobPOGKvoxoYcogHpuhGzaRDkxAxrUBLvkrHHIZJDraNHcDZQRKL");
    int HBapiHGurKveDoUa = 352079946;

    for (int PwJDYvbOIIrhQ = 1421303080; PwJDYvbOIIrhQ > 0; PwJDYvbOIIrhQ--) {
        HBapiHGurKveDoUa /= HBapiHGurKveDoUa;
        zbwGlxlVhi /= ZIyYPK;
        zbwGlxlVhi += ZIyYPK;
    }

    if (ocUnWuLhDBzyKM != false) {
        for (int BJKQAddiJvlT = 63546151; BJKQAddiJvlT > 0; BJKQAddiJvlT--) {
            continue;
        }
    }

    return HBapiHGurKveDoUa;
}

bool QYTFmm::mqbhdMqANWXKh(string DUehzP)
{
    string ZTVjVasuZ = string("FTjmgzRrOwpJruAbsOyZGUQPsdVTnnxZmFIvsQaFDMSEwlyaRBtVWYZIwLcrTXRrShhKMcaVhAYsgpikOtWBoiAmfpNPZeIyGDVRMBrkECDgVOUcpXqcOXiJRpavyBDxVRRebceEOkjJlPYZirAgWrbkxCyvkQPOGuBttVPOLjvmLcJpJRrORpjxvkiaYuGHdtTrMmQcNEGfIOazpoSkwvgJMTS");
    bool YuGEDtLKDvMj = true;

    for (int wBAco = 1981297840; wBAco > 0; wBAco--) {
        DUehzP += DUehzP;
        ZTVjVasuZ += ZTVjVasuZ;
        ZTVjVasuZ = DUehzP;
        DUehzP = DUehzP;
        ZTVjVasuZ += ZTVjVasuZ;
        ZTVjVasuZ = DUehzP;
    }

    if (DUehzP <= string("iraeJjlEXpuvDLzeMhmIJvEVONFOjDbsKmYmvewvSvqovFjWWYuRpgEHDCUwFQftMhBujoDxDQYacnfTTlxDJRZjLbGvyrslCVuANlrVGlOVtvWQSLLCFGygyyjjvoyAUvqdoqsEVNIHYRKwjewKBRIhcttOxMT")) {
        for (int RPvyZOPkjCfsq = 631132343; RPvyZOPkjCfsq > 0; RPvyZOPkjCfsq--) {
            DUehzP += ZTVjVasuZ;
            YuGEDtLKDvMj = ! YuGEDtLKDvMj;
            ZTVjVasuZ = DUehzP;
        }
    }

    if (DUehzP == string("FTjmgzRrOwpJruAbsOyZGUQPsdVTnnxZmFIvsQaFDMSEwlyaRBtVWYZIwLcrTXRrShhKMcaVhAYsgpikOtWBoiAmfpNPZeIyGDVRMBrkECDgVOUcpXqcOXiJRpavyBDxVRRebceEOkjJlPYZirAgWrbkxCyvkQPOGuBttVPOLjvmLcJpJRrORpjxvkiaYuGHdtTrMmQcNEGfIOazpoSkwvgJMTS")) {
        for (int ISSWDkcwIkmiGWV = 548000470; ISSWDkcwIkmiGWV > 0; ISSWDkcwIkmiGWV--) {
            YuGEDtLKDvMj = ! YuGEDtLKDvMj;
            YuGEDtLKDvMj = YuGEDtLKDvMj;
            DUehzP = DUehzP;
            ZTVjVasuZ = DUehzP;
        }
    }

    return YuGEDtLKDvMj;
}

double QYTFmm::XqofhiWSGSKS(bool mCqMgpbp, bool SVXHvoRqDdP, bool tFwKhAHUzubzF, double NrXkAsKDBl, bool HHShqD)
{
    string cZiqaGCRozWxY = string("kADDLNjwnRumLYzrYFbxRhgiwzCxaIIDuutwzfrlVjtAiteRucPeYTXMYDKtAZkGhlqTDzSchEKKrjxxbNzfMXkiyigDuRUEoWNlumzCVfAGxkYoQxN");
    double VJCLrlTSRYic = 733095.7950517283;

    for (int pHAqd = 1812204475; pHAqd > 0; pHAqd--) {
        mCqMgpbp = SVXHvoRqDdP;
        NrXkAsKDBl *= NrXkAsKDBl;
        NrXkAsKDBl += NrXkAsKDBl;
        HHShqD = ! mCqMgpbp;
    }

    return VJCLrlTSRYic;
}

int QYTFmm::taUnPY(double wCDdyFHcfJpwtt, string IjMEcgTN, double jvBrXIzDeS, string NakJC, string pElwvOXk)
{
    double QSIKkqj = -762427.6918666817;
    int VyjyOVmJ = -541062258;
    double ltJLcsBs = 173733.11680936953;
    int rhrpOUIyxF = 35771422;
    int xCoAS = 2140325481;
    string ZBTbdT = string("aiowQTaCKGeyQalDXpDIDpfVhFERwjOEcnZdMNBxOeBWncYbDetTalZJKaFEwUouLMBioVoimjfjLtncYBVneTgsOGQrEmLCISBeNvXGLEZysAqFhMLSkPXWwYToVVNKxatsVyGjqeUdiPuiwXUVbWrHgbGvRGoXqNWDGeDkyHMpUpNyAgcPeUvCoLjvKqfXOSLRyXkDNKxiZScMReiVYoFjPHcJhQdq");
    int CaBCmiXEqpCTFr = 1886689230;
    double jEKpyADl = 724046.790206623;
    int RbKzop = 106917514;
    string CsZQVDpM = string("KpoUaQqCaEMIjGcAVyycjsWAJwcSbRhGxKddECwXRBcgzQpSTFkTkdLDltWyGooXYfKCougSwLYNHXFotSQmXyRdChBuOVMybTXbTbDNknUbvsVouCzWAPIXSjg");

    if (xCoAS <= 2140325481) {
        for (int NnaNaaDHFsmsJoJL = 839750195; NnaNaaDHFsmsJoJL > 0; NnaNaaDHFsmsJoJL--) {
            continue;
        }
    }

    return RbKzop;
}

int QYTFmm::cUvGwGfrjkmBGjA()
{
    string bYSbqRnZMmY = string("QiJBEeXueaWjhjVfroGvZhGLcmpjGzilunZnBumNaEpkQScWUUuiBUFWGCzjoUwiZrACXzKmNQThwOntHBZEjnphZCyGUlTWBkJjqSKMdrOmpMjozVR");
    int SDdNxvkiaxmEa = -2019316067;
    string fOaWgzyOmyd = string("ypRFkcUvQwaHpfScJJnqYzmlhFBCnQRNyZXfYPbjKbYZKjhtfbAFzJdxxLmkROFuBRPwFMAoItnMfdIsdqnIkqHnyRhPzroAxogVaYIHmsDUCSTGYSpNCCAPlNdVJlcZatEhWaaodlcGOVCBSUxhriS");

    if (bYSbqRnZMmY > string("QiJBEeXueaWjhjVfroGvZhGLcmpjGzilunZnBumNaEpkQScWUUuiBUFWGCzjoUwiZrACXzKmNQThwOntHBZEjnphZCyGUlTWBkJjqSKMdrOmpMjozVR")) {
        for (int pcZoIWln = 906945498; pcZoIWln > 0; pcZoIWln--) {
            fOaWgzyOmyd = fOaWgzyOmyd;
            fOaWgzyOmyd += bYSbqRnZMmY;
            fOaWgzyOmyd = bYSbqRnZMmY;
        }
    }

    if (fOaWgzyOmyd == string("QiJBEeXueaWjhjVfroGvZhGLcmpjGzilunZnBumNaEpkQScWUUuiBUFWGCzjoUwiZrACXzKmNQThwOntHBZEjnphZCyGUlTWBkJjqSKMdrOmpMjozVR")) {
        for (int dIqBpQO = 1526539030; dIqBpQO > 0; dIqBpQO--) {
            SDdNxvkiaxmEa = SDdNxvkiaxmEa;
            bYSbqRnZMmY += bYSbqRnZMmY;
            fOaWgzyOmyd = bYSbqRnZMmY;
            bYSbqRnZMmY = bYSbqRnZMmY;
        }
    }

    return SDdNxvkiaxmEa;
}

string QYTFmm::ObICgvuXkpGSs()
{
    int RxXHnyKbADsA = -406918349;
    int haudHbjldNT = 1718014104;

    if (RxXHnyKbADsA < 1718014104) {
        for (int PJAPokBuCsIso = 852505523; PJAPokBuCsIso > 0; PJAPokBuCsIso--) {
            RxXHnyKbADsA = RxXHnyKbADsA;
            haudHbjldNT /= RxXHnyKbADsA;
            haudHbjldNT -= haudHbjldNT;
            haudHbjldNT -= RxXHnyKbADsA;
            RxXHnyKbADsA += RxXHnyKbADsA;
            haudHbjldNT *= haudHbjldNT;
        }
    }

    if (RxXHnyKbADsA != 1718014104) {
        for (int XzNDmTweWthd = 416700608; XzNDmTweWthd > 0; XzNDmTweWthd--) {
            RxXHnyKbADsA /= RxXHnyKbADsA;
            RxXHnyKbADsA += haudHbjldNT;
            haudHbjldNT *= RxXHnyKbADsA;
            RxXHnyKbADsA /= RxXHnyKbADsA;
            haudHbjldNT -= haudHbjldNT;
            RxXHnyKbADsA = haudHbjldNT;
            haudHbjldNT += haudHbjldNT;
            haudHbjldNT = haudHbjldNT;
            RxXHnyKbADsA += RxXHnyKbADsA;
            RxXHnyKbADsA *= haudHbjldNT;
        }
    }

    if (haudHbjldNT <= -406918349) {
        for (int YbRpKRxXObFcsB = 1267064759; YbRpKRxXObFcsB > 0; YbRpKRxXObFcsB--) {
            haudHbjldNT = RxXHnyKbADsA;
            RxXHnyKbADsA = RxXHnyKbADsA;
            RxXHnyKbADsA /= RxXHnyKbADsA;
            haudHbjldNT /= haudHbjldNT;
            haudHbjldNT = RxXHnyKbADsA;
            haudHbjldNT /= haudHbjldNT;
        }
    }

    if (RxXHnyKbADsA < 1718014104) {
        for (int viFjSXvBKtXeQJz = 257693723; viFjSXvBKtXeQJz > 0; viFjSXvBKtXeQJz--) {
            haudHbjldNT *= haudHbjldNT;
        }
    }

    if (haudHbjldNT <= -406918349) {
        for (int RSiLiGRwq = 1781155609; RSiLiGRwq > 0; RSiLiGRwq--) {
            RxXHnyKbADsA /= haudHbjldNT;
            haudHbjldNT = RxXHnyKbADsA;
        }
    }

    return string("WOVloocKtJAHWYckZrDIfiLIuGVrsJNQixwOpLAVTfTHWezROYRPwQs");
}

bool QYTFmm::ibDtIBeHJh(int LVrqLpLD, int ruaYJsi, double feAXENwTytxSS, string htMZYfYiTBRBoh, bool EVoHgkrgAHDh)
{
    bool nTQWUJXfjfXWffDt = false;
    bool lXESdwhAUom = false;
    int aqngSaeMLmcZsJ = 1074313273;
    int AntCpTwo = 1393944723;
    double GLtHFkAZ = 761591.7581619711;

    for (int QcukoEBtAX = 876447530; QcukoEBtAX > 0; QcukoEBtAX--) {
        continue;
    }

    return lXESdwhAUom;
}

double QYTFmm::pYEsQiE(int PMISapJztZYFTFg, bool YeebbqIgvrU, string cvvEpi)
{
    double pBXGcsPonKTUDyw = 780017.3626004163;
    bool QObVoyYLsRlcW = true;
    double yRDdPIK = -117749.37491290033;

    for (int MrOTfGxs = 476566517; MrOTfGxs > 0; MrOTfGxs--) {
        QObVoyYLsRlcW = QObVoyYLsRlcW;
        yRDdPIK /= pBXGcsPonKTUDyw;
    }

    for (int fOHnWRpNMwYz = 1639080030; fOHnWRpNMwYz > 0; fOHnWRpNMwYz--) {
        yRDdPIK -= yRDdPIK;
        YeebbqIgvrU = QObVoyYLsRlcW;
    }

    return yRDdPIK;
}

bool QYTFmm::lHzSjylCzhh(string cBtwxkQHDXzXpXht, string LllzPpFSfpfYVGP, double qKORcC)
{
    bool ApVcdNDgvvxqWSOg = true;
    string aJysllskPMW = string("yvfWSIydjUxfBWxAavTFPRSkvTnRPZYDTMuizwNwyaRuqcnyOxvTgwlFFiGhfUbbxWnbNKtSiCOzgmGMCkcKLnkfuXGcOkFkFAEdTXIlhpRRTfhBFUFKHVNGWDLDQXajyqUnuSTOhxKCOlQSrNLRiVGhdbUexnQyYwFoEnKGfCcpYZIuuiIgyLHPpQrgrV");
    bool FnfEYrdYvDCZb = true;
    bool OCNuJTVDC = false;
    bool Ghpvn = true;
    string FfMgreUolnafZ = string("sCpUrdlvYTIjOClgsTAcMCHozBkAXvksOBGvgowyUZDjpgNadsAHsWYxNIMHEHRpHKbABcnXCazTUgFQYk");

    for (int kkDdel = 1826292856; kkDdel > 0; kkDdel--) {
        FfMgreUolnafZ = LllzPpFSfpfYVGP;
    }

    for (int UmBbG = 1004379592; UmBbG > 0; UmBbG--) {
        LllzPpFSfpfYVGP += LllzPpFSfpfYVGP;
        FfMgreUolnafZ = FfMgreUolnafZ;
        FnfEYrdYvDCZb = OCNuJTVDC;
    }

    if (ApVcdNDgvvxqWSOg != true) {
        for (int jnbQrGEU = 1558830542; jnbQrGEU > 0; jnbQrGEU--) {
            continue;
        }
    }

    if (OCNuJTVDC == true) {
        for (int mtpvUtfK = 1384040229; mtpvUtfK > 0; mtpvUtfK--) {
            LllzPpFSfpfYVGP = cBtwxkQHDXzXpXht;
            cBtwxkQHDXzXpXht = FfMgreUolnafZ;
        }
    }

    for (int FlEqMJNMzVylK = 1342511324; FlEqMJNMzVylK > 0; FlEqMJNMzVylK--) {
        ApVcdNDgvvxqWSOg = ! ApVcdNDgvvxqWSOg;
    }

    for (int ICzeHFv = 846999036; ICzeHFv > 0; ICzeHFv--) {
        ApVcdNDgvvxqWSOg = FnfEYrdYvDCZb;
        FfMgreUolnafZ = FfMgreUolnafZ;
    }

    return Ghpvn;
}

double QYTFmm::TVDDjhz(double QREdRIonLySaPx)
{
    int ebUlugK = -1588702386;
    int htxbTC = 1054827416;
    double YaWZKRVs = 12605.696998976031;
    double iOIcXmFtb = 51550.97159010133;
    bool zkgZuYhR = true;

    for (int fLHxarWO = 1148690161; fLHxarWO > 0; fLHxarWO--) {
        zkgZuYhR = zkgZuYhR;
        ebUlugK /= ebUlugK;
        iOIcXmFtb = YaWZKRVs;
        iOIcXmFtb += QREdRIonLySaPx;
    }

    for (int xbNddPnL = 1694328136; xbNddPnL > 0; xbNddPnL--) {
        YaWZKRVs = iOIcXmFtb;
    }

    if (YaWZKRVs != 12605.696998976031) {
        for (int lwkJE = 411503740; lwkJE > 0; lwkJE--) {
            YaWZKRVs *= iOIcXmFtb;
            QREdRIonLySaPx -= YaWZKRVs;
        }
    }

    for (int bKxyfV = 493433644; bKxyfV > 0; bKxyfV--) {
        continue;
    }

    if (iOIcXmFtb != 51550.97159010133) {
        for (int AhbVsWAuviBgPh = 592980331; AhbVsWAuviBgPh > 0; AhbVsWAuviBgPh--) {
            iOIcXmFtb += YaWZKRVs;
            htxbTC = htxbTC;
            QREdRIonLySaPx -= QREdRIonLySaPx;
            QREdRIonLySaPx = iOIcXmFtb;
            iOIcXmFtb /= YaWZKRVs;
        }
    }

    return iOIcXmFtb;
}

int QYTFmm::wSkznecoECPbzn(string UUoZjn, double YaxjHxJs)
{
    double NAeICKNL = -1047576.0760236335;
    int sVahlTZnEbN = -679464048;
    string sJudYhbhpYbu = string("ASAMkzksxUVGzaLezFcjUmeZnLMuuOKaqSuFcSmryndISetQRzYcddOFInAEnqtSRxfEnHwMYvZIfUdLQrwHSVVMklMwdeppeMQUpVitvKqbQHxEXuEFgKAoJrQwDvOIIEwVUieKsDnkgISVMQwVRTCgWGqKlLEerJNNwNblcUeLTWrSABSOwZLEFctIWMRtgHdAmXmVrIQGDObqkXVDvkrwHOjlDAIeGnFOgbhOCyUvTyj");
    string prIEqdcYbtsEq = string("xaGANRxfqbdSZhbbMjMjMNMTmCPgQxVduYZoFspbduhyUZDOaBXGEEXeSOZAAIWRhuoCDDeqXZMeMbqqJZVENArWNDdjmGGOfMFVCCHGsbOVJpJojdWmIrDIDs");
    bool UXzqbCNdfaV = true;

    for (int LgHRCnRIOi = 656196745; LgHRCnRIOi > 0; LgHRCnRIOi--) {
        NAeICKNL = NAeICKNL;
        sJudYhbhpYbu = prIEqdcYbtsEq;
    }

    for (int ZkuBvuWo = 981202126; ZkuBvuWo > 0; ZkuBvuWo--) {
        continue;
    }

    if (prIEqdcYbtsEq > string("xaGANRxfqbdSZhbbMjMjMNMTmCPgQxVduYZoFspbduhyUZDOaBXGEEXeSOZAAIWRhuoCDDeqXZMeMbqqJZVENArWNDdjmGGOfMFVCCHGsbOVJpJojdWmIrDIDs")) {
        for (int EDXZaJn = 1932066974; EDXZaJn > 0; EDXZaJn--) {
            continue;
        }
    }

    for (int DNedpmF = 2064026151; DNedpmF > 0; DNedpmF--) {
        sJudYhbhpYbu = prIEqdcYbtsEq;
    }

    for (int xOFNUcWWy = 659310198; xOFNUcWWy > 0; xOFNUcWWy--) {
        UUoZjn += UUoZjn;
    }

    return sVahlTZnEbN;
}

void QYTFmm::luEvm(bool flnBjOAJc, int tPbBZZ, bool JBqVOc)
{
    int oLXgdRdFIuHJ = -1204849009;
    string uYFuzkijIegRk = string("eILDqGUseFenqArCjeKzXqoXEZyZsNyIZRZLBZTHqgPIQQGcQIQElkshhlXhAeFbdAfjNbXKxdbfLWtkmjoQcJNStonFzPMrsxpZUwfSnSzNYqLyWOXhbICmNMrcZJhqLDxKxCcskGFVspQuQzNXjpIfTIhsZLAhnDpmYUTQcVMThnDHJKxgBJhKxtSXUTzOBFDIDqtfWOXoaORlniMRLUW");
    bool jozEdPYCAPjQpMqd = true;
    string BoBdV = string("PrWwLqYrKbiyggbvDqWozHALxpOuDSnsszlDAJJCHUYqzgHdnzvXLeMEElwHMSTuorfqbniLtVpqOVaBmbTtzkWuSrXYQbCnbszAOyClMxVdkTwYfwHbTnBSTvfVZcNCmOWgUBraWDxJJAQfyCZSDOAYEmrxWpiuFMzXBEdCWsWtrtwnKRwfOLckuwlHUffPsSDHtGBdXvwOrWQSqDnZoOHRNbgJviSy");
    double cOmaLfoexIUV = 86455.6219917144;
    double FZEKcpnpqRiAuqF = 598665.8257081873;

    for (int kleivaDpzHjwWC = 540807985; kleivaDpzHjwWC > 0; kleivaDpzHjwWC--) {
        continue;
    }

    for (int JlShmwT = 1127099998; JlShmwT > 0; JlShmwT--) {
        continue;
    }

    for (int kkCbDuZIdukbd = 954853791; kkCbDuZIdukbd > 0; kkCbDuZIdukbd--) {
        continue;
    }
}

string QYTFmm::SXvAKmBKeO(int MUZGhpiXT, int gTIFEie, double YaNGklL, double lBuEhJddVSgsNs)
{
    bool MlYJNpxEg = true;
    double BXcWANqIWIWCwedn = -512305.3059960803;
    double jSaiVyWJCfL = -816491.4785134271;
    bool IjCypPxFQlDXIRF = false;
    bool ApKRpCQErdKOjkIZ = true;
    string sCmVlPToT = string("RfdkRIkTCSqHycvtVNDeyMpJdwEIIRTEvJrnyVhNvTvkSRQPFDcbwemJMZyPRFWYwjNzqABetecXuORgSthYEDictMLtiqPPoJyajPRbyxnTFtfTAQmNewLeFbhhUDsMNHhBfrPCSDhmvgafjQEkNRMjHPIhqGowlOpSmlKuPGHqVQABUlYavnSoRFlDDMHaCVHXIvjwCbjUugNQnHllSNjksAk");
    double XDjhAVKXS = 885789.9899863624;
    int jguIHxRqvpJVhH = -858079928;
    double bXHrJamOEWfHqVI = 485257.7642195871;
    double JBidtjBUkTMGAK = 357819.2792626751;

    if (BXcWANqIWIWCwedn > 485257.7642195871) {
        for (int TuKTHcG = 1349528776; TuKTHcG > 0; TuKTHcG--) {
            continue;
        }
    }

    for (int ALejgJcE = 1431716169; ALejgJcE > 0; ALejgJcE--) {
        MlYJNpxEg = ! MlYJNpxEg;
        BXcWANqIWIWCwedn = YaNGklL;
    }

    return sCmVlPToT;
}

string QYTFmm::tnNMdaXVOzqwpNHM(bool RvCdzMcXJYhrZ, double uFGUCQsW, int aULTbhaNkiuCB, double ItzaZvYQUypw, string ySfsHMBNN)
{
    double RSsWYKCkkLODYdrp = -799257.9652549846;
    bool gYyjjz = true;

    for (int gyRbI = 1137078204; gyRbI > 0; gyRbI--) {
        gYyjjz = ! RvCdzMcXJYhrZ;
        gYyjjz = gYyjjz;
    }

    for (int ZmRxjmm = 998261100; ZmRxjmm > 0; ZmRxjmm--) {
        RSsWYKCkkLODYdrp += uFGUCQsW;
        uFGUCQsW *= RSsWYKCkkLODYdrp;
        ItzaZvYQUypw = uFGUCQsW;
    }

    if (gYyjjz == true) {
        for (int hVHDSYnXuQ = 2108137070; hVHDSYnXuQ > 0; hVHDSYnXuQ--) {
            RSsWYKCkkLODYdrp -= RSsWYKCkkLODYdrp;
            gYyjjz = gYyjjz;
        }
    }

    for (int LbcOlVuPZUBzW = 2107212115; LbcOlVuPZUBzW > 0; LbcOlVuPZUBzW--) {
        aULTbhaNkiuCB += aULTbhaNkiuCB;
        gYyjjz = ! gYyjjz;
    }

    if (ySfsHMBNN <= string("VcLOCvmxjzERTDAIWmgwbOIpjHijuyQLMQuSdDjXZZqmQqqHCioYqszVIREKAruOofrfQooDWhnlMPiqtuqQlfshqbenEEMgURtpqKSPSaUlDbtlMJaTWEeTyqZDGjmkVSRGqLAUdWYqSEUgbUXWdCQrKXDjAgjrrhxekYrRMPepbfuizQAQkGfAelMSoKOYWQFDUEPkhkotUyWt")) {
        for (int jIrYDflCn = 1524584514; jIrYDflCn > 0; jIrYDflCn--) {
            continue;
        }
    }

    return ySfsHMBNN;
}

int QYTFmm::QgMtIlqJNnCOGng(bool rZxapCvNO, int lpBxmaEu, double kbCSVeyIz, int OXAFUtOcVcFlbvA)
{
    int RuKbxMIvaVZlwCL = -484989011;
    double pSTnsyKgSTLnyrE = 871204.6567140821;

    for (int OSExmGTm = 1451885206; OSExmGTm > 0; OSExmGTm--) {
        kbCSVeyIz += kbCSVeyIz;
        rZxapCvNO = rZxapCvNO;
    }

    for (int VBHMaxzts = 1345594678; VBHMaxzts > 0; VBHMaxzts--) {
        lpBxmaEu = lpBxmaEu;
        lpBxmaEu *= OXAFUtOcVcFlbvA;
        OXAFUtOcVcFlbvA += OXAFUtOcVcFlbvA;
    }

    if (OXAFUtOcVcFlbvA != -1915856950) {
        for (int lTZBExcpT = 70831608; lTZBExcpT > 0; lTZBExcpT--) {
            continue;
        }
    }

    for (int SEBAPGqqZvN = 1332274760; SEBAPGqqZvN > 0; SEBAPGqqZvN--) {
        RuKbxMIvaVZlwCL -= OXAFUtOcVcFlbvA;
        RuKbxMIvaVZlwCL = OXAFUtOcVcFlbvA;
    }

    if (OXAFUtOcVcFlbvA == -1915856950) {
        for (int pMWpRZymET = 305912464; pMWpRZymET > 0; pMWpRZymET--) {
            lpBxmaEu /= lpBxmaEu;
            OXAFUtOcVcFlbvA -= OXAFUtOcVcFlbvA;
        }
    }

    if (OXAFUtOcVcFlbvA >= -484989011) {
        for (int PxdTdgX = 1309192072; PxdTdgX > 0; PxdTdgX--) {
            lpBxmaEu += lpBxmaEu;
            RuKbxMIvaVZlwCL += RuKbxMIvaVZlwCL;
        }
    }

    for (int pXXjjLxObEfseKBf = 1591937606; pXXjjLxObEfseKBf > 0; pXXjjLxObEfseKBf--) {
        OXAFUtOcVcFlbvA *= lpBxmaEu;
        OXAFUtOcVcFlbvA /= OXAFUtOcVcFlbvA;
        lpBxmaEu = lpBxmaEu;
        pSTnsyKgSTLnyrE /= kbCSVeyIz;
    }

    return RuKbxMIvaVZlwCL;
}

int QYTFmm::pdGEPFP(int xUYzQy, double CJlfCh)
{
    string nuMBxVoaOZq = string("zHcKWtglsdgYgLZGkjxWIAhU");

    for (int AwpXZfjSjwOJsdff = 523852378; AwpXZfjSjwOJsdff > 0; AwpXZfjSjwOJsdff--) {
        continue;
    }

    return xUYzQy;
}

int QYTFmm::uiLNPa(string VOczeN, bool rDhfHRsmdBCYr, int jwsBRfar, string PqgoDshjfDfeaFX)
{
    string USEwETkxfkCXRkf = string("zqBzWfyvwUhwtRuZjTbODOlLgvYuHwkTzBZopdZHWCgliWmgNPrUozPggLkVlUnHvOfgdaeTWrHfjuEVdIRpKAZmTvPAMNyUudybQudpOCiWxBfWGbIGHosHCUkMxYuWSWkkKnWAgOhtPAfHuzmRcOBCBxfdPaQITzbWHbqoBGAZtLyUNdutNmqsnWdgbUkKTWjmm");
    string eMITQSC = string("sUwVimxyNaDuRQTYkZkDDBpCjnFPXekbCFlJqSgzMLBchuIcIRskiGZJqLcDTEtBdaRlCLPTxeWyXHajojVuaJvHMlMuyLzLjc");
    int uOGGXSp = -186561651;
    int TsFnoS = -170278473;
    string AbKPgbwQsfW = string("qykOwIBcFbWRZEYMrOOQPStHBPxPLxCBKSeOssQurEbsYTYwCDnSwJUnynRZyNyNmnysirLHDsaZlCkZiJwmYvoMtjvSPb");

    for (int CJRxgxTA = 265643854; CJRxgxTA > 0; CJRxgxTA--) {
        jwsBRfar -= jwsBRfar;
        PqgoDshjfDfeaFX += PqgoDshjfDfeaFX;
        VOczeN = PqgoDshjfDfeaFX;
        PqgoDshjfDfeaFX += USEwETkxfkCXRkf;
    }

    for (int rkyGcIw = 1991196546; rkyGcIw > 0; rkyGcIw--) {
        rDhfHRsmdBCYr = rDhfHRsmdBCYr;
        PqgoDshjfDfeaFX = VOczeN;
        TsFnoS = uOGGXSp;
    }

    return TsFnoS;
}

bool QYTFmm::neGgLqDfonUeZrdj(bool MEdMFZgrkonkCy, int JUAQUSZWMHEUz, string CJuAiKykUYBR, int RxBuUj, int wsvpqGdGbNsrhU)
{
    string rbkyNQuEOHixQ = string("eIEjenauTFEFzvpTRPirawhEvovEzaZuKFcDknLChDOgTyTeVVqddaRloFcfuhOECftluzMGJdiokNyusdrNGVkmITXMRKfTwanxsfMqRCDYTIeUrUfuIJZzUdcwttiZKySadghvFsoHUkrDyHqpRznGfjWkiPwmfCMsiLDNDIwfnyDGmviqOBkcYtJMeguxQWyLZIAEA");
    double BwGdkZtaWs = -492039.81238154974;
    double DdQUmuLl = 326417.8275752194;

    for (int UjBnLvviYGimzqK = 1169212522; UjBnLvviYGimzqK > 0; UjBnLvviYGimzqK--) {
        JUAQUSZWMHEUz = wsvpqGdGbNsrhU;
    }

    for (int xTOCLVjoXccZy = 1613195844; xTOCLVjoXccZy > 0; xTOCLVjoXccZy--) {
        RxBuUj = RxBuUj;
    }

    return MEdMFZgrkonkCy;
}

int QYTFmm::baITwqZ(bool qTKShNznpwktz, double mPKPfsneDMc, bool tdBOH, int zJeYQOM, int nnYqqFfQpG)
{
    int otVReQvmlWzYGYP = 166525801;
    string YVPPv = string("OiigjvJoFWzFnhkYjKauwUNaeVOnsfwIUMtgofALjFjyRfKBEoKAHmRjFRlrfPGJCqzpXjZZOwSgbFgVgNoUhXbXlAtGVNRtAPhUkLehcsUqLtmbRJiCmsAwO");
    int qMFfhkAonVFH = 858430355;
    bool qEVyfcTIvn = false;
    int pFxGVOIUaSBV = -813045649;
    string qaCgYcWQB = string("JtJrABJguRDXUkcmXsMMAFgiLNviyZvyPIGQwZwwWZxVWQbTxnetBeBsXIcEBSXqzILqBognEegclppvqwMvyWvXlwkiGzIXJkHEHfKTFTFFzGcDqSAehReKfrJmOkiRJzmXmTYATwBVhWUVmtxoAMpUzkMwLswUDXUEFuxEfrTwKniBiIFJVVsuvkCiebIyVNPegNOGYwvIewkqriXgMEc");
    string WqxWQ = string("pzTjWNbeXVbDiGaxYgrFFXjcXbCUZmRsYzEmoopxFNpXYKHgJyLbCwzYpULiSHbUReTMsaxQfCxuzcNnkBpNjLEFnPHFAfdoOufGaDBVkvaMTAVJNiTItUiSCNxjDebzHKBePbanRxZekUJIohFSylDazgcJrtSBzwJdmgmx");
    double qfwhMp = 615023.4844166177;
    double zWVShIjzODPOI = -717673.0282433897;

    if (qaCgYcWQB == string("JtJrABJguRDXUkcmXsMMAFgiLNviyZvyPIGQwZwwWZxVWQbTxnetBeBsXIcEBSXqzILqBognEegclppvqwMvyWvXlwkiGzIXJkHEHfKTFTFFzGcDqSAehReKfrJmOkiRJzmXmTYATwBVhWUVmtxoAMpUzkMwLswUDXUEFuxEfrTwKniBiIFJVVsuvkCiebIyVNPegNOGYwvIewkqriXgMEc")) {
        for (int WHxDDAdaobSsQ = 460208937; WHxDDAdaobSsQ > 0; WHxDDAdaobSsQ--) {
            tdBOH = ! qTKShNznpwktz;
            qMFfhkAonVFH *= qMFfhkAonVFH;
        }
    }

    if (nnYqqFfQpG > 858430355) {
        for (int ZmvmndtwbjW = 2042631081; ZmvmndtwbjW > 0; ZmvmndtwbjW--) {
            mPKPfsneDMc -= qfwhMp;
            qMFfhkAonVFH += qMFfhkAonVFH;
            otVReQvmlWzYGYP = pFxGVOIUaSBV;
        }
    }

    for (int VrSTmEyqz = 1680470326; VrSTmEyqz > 0; VrSTmEyqz--) {
        qMFfhkAonVFH -= pFxGVOIUaSBV;
        qMFfhkAonVFH -= qMFfhkAonVFH;
        zWVShIjzODPOI += qfwhMp;
    }

    return pFxGVOIUaSBV;
}

void QYTFmm::TsEqumunuLsw(double KZkhipTdyB, bool UmETkCPceDNCymAv, double sozOwyxgYwmVf, bool RSPTTbFy)
{
    string yJXdmjESd = string("EBpUYxiNgpBUWtJNabwieQmxroJsfiXcfQDqylmiMjWpZSHccCfubFafOKROcQpqwpXodvifNQyPaLwMSuLZtJaCAnllPzGwPWYWdWsHJOtlIpUucvQgFjxdFUceuWFULcSkyplwRdUbPyGVPHbdaFbsslp");
    bool ueREwL = true;
    int HWsDIhuRqQN = -1914954386;

    for (int QsAuT = 189236640; QsAuT > 0; QsAuT--) {
        continue;
    }

    if (ueREwL != true) {
        for (int GhTQFUekY = 1538394706; GhTQFUekY > 0; GhTQFUekY--) {
            continue;
        }
    }

    for (int JLGggkKBrhMMQK = 252439984; JLGggkKBrhMMQK > 0; JLGggkKBrhMMQK--) {
        RSPTTbFy = ueREwL;
        UmETkCPceDNCymAv = ! UmETkCPceDNCymAv;
        UmETkCPceDNCymAv = ! UmETkCPceDNCymAv;
        RSPTTbFy = RSPTTbFy;
    }

    for (int gTkvji = 253564304; gTkvji > 0; gTkvji--) {
        yJXdmjESd += yJXdmjESd;
    }
}

QYTFmm::QYTFmm()
{
    this->YeGcrdw(false, 2118663090, -691182.7144811851);
    this->fotrdDCzdo(-459138.32331586006, false, -1847828827, true, false);
    this->AfzUnMErQKJb(-626022.4577609828);
    this->mqbhdMqANWXKh(string("iraeJjlEXpuvDLzeMhmIJvEVONFOjDbsKmYmvewvSvqovFjWWYuRpgEHDCUwFQftMhBujoDxDQYacnfTTlxDJRZjLbGvyrslCVuANlrVGlOVtvWQSLLCFGygyyjjvoyAUvqdoqsEVNIHYRKwjewKBRIhcttOxMT"));
    this->XqofhiWSGSKS(false, true, true, 598071.1922901832, false);
    this->taUnPY(-557094.7511952101, string("iVOigPEVvvzQDxLFtSqhPoLpUYKELXUlmYPORjsZrsivjgWOGZNTwFKrAmhjDOrQTcDcTIBIZRCTmhQtauZEbDKKvoCzoaLUVYrzFydIfgzgpEXjHyxWDyU"), -945921.7868700072, string("lwSSEhswKPUgnvrviIUYfRLzJPnwXQFVSmGhaXUHbsoHIiYCawkVOxLFEaHFCSBDkCywUTTdbkmsHKmuEjdYchqaESqF"), string("wpgnFxptmFIyLKBStxQyJgDoigrwnuRBMBBVNnxZstWfnBaSpOfBARcEDpEWyFPuRgzrQaUhcMKuxPiNuGtoUVOsroEArFSOjWsXcnMDMtZjJkoMkYZQGDikxuHKcZOPbnCwxyxExCfUJBiYOMlyqjZsdsUhHbPLVDkFdlEcsVklAvxfYIfgRYvlIWE"));
    this->cUvGwGfrjkmBGjA();
    this->ObICgvuXkpGSs();
    this->ibDtIBeHJh(1995580235, 875105509, 795327.8585387415, string("yruqxQtPBNthHHCqpAEsoJPkzlIAzfOfTteLNpFTfSdpDvUlRKbmvTUNqQOmcZIFdMBWyToDuSHZgkAXYrZseYsRKbNEuPKRQkYXgAXiVEiimIFxFVVbbGEfbIndROJTqwAHDaZUghkuwlMUqwGhngzCFoudtQJZTlygkPdajS"), true);
    this->pYEsQiE(838298042, false, string("jHwGSJudtGJyCgpvZPiVXnYcUwGadwUjLXRleifJQsefVNUhdFQXfZdEBzMFDwhtCTMysxTMtatmYNSOnqMryKLKMvguUgZcrijQUMLhmIJ"));
    this->lHzSjylCzhh(string("nDpHegbKZJfdImVkTmxzqyAwlDWbMEyhjqVcCJuKkrgAAYKfceKfKFhvLUhMUXQtlcyoBOexfFfCrUkWsfegAMxfVXFuWvdScTcXpoTqpAOjWUXwKqYyJiFDbhjNzQQGmwoGWg"), string("kphXCufHWIUdpSBeAYoIhpSHgVGFcLrYRblUNGLsdfznfwPSmMkGAecKlGoYUFpEENLoNzBWiiZotWjGmBlMmNDLdCLArIOgFqLfLOGZjTKYqkyUYYoqjbTsWsOEyBMIwlLnhCFHYkmVBECoQBDbosH"), 23260.809822732164);
    this->TVDDjhz(1036780.7490260458);
    this->wSkznecoECPbzn(string("ppBawQAiObUdzXaMxTDLmmJvdElPQuKIQqiLzPXRVyAraNunfILqvtsEgqclqxMHCKUOdaiDTzBFRRMWxAQCDVHjfNfSnIIkrgkkZmPnOnMIHEddbrKLGCLeMmgcIrOzSuHqOCtXHxtizlKihpsvEWyCuvDTeqQMGEWNAPcAkjZclBrPwCcjFJGqQEPMyiPFAxvdmFkNnfnvxLjDTNodJxttzBTYofcGUpbkmXZLRqgxICgDOSpR"), 8706.141333855983);
    this->luEvm(true, 1650380753, false);
    this->SXvAKmBKeO(-1208397157, -1757543490, 198171.09816754702, 480744.01996196265);
    this->tnNMdaXVOzqwpNHM(true, 411733.942403356, -508067071, 402857.1509833021, string("VcLOCvmxjzERTDAIWmgwbOIpjHijuyQLMQuSdDjXZZqmQqqHCioYqszVIREKAruOofrfQooDWhnlMPiqtuqQlfshqbenEEMgURtpqKSPSaUlDbtlMJaTWEeTyqZDGjmkVSRGqLAUdWYqSEUgbUXWdCQrKXDjAgjrrhxekYrRMPepbfuizQAQkGfAelMSoKOYWQFDUEPkhkotUyWt"));
    this->QgMtIlqJNnCOGng(false, 1411318958, -853795.0016029484, -1915856950);
    this->pdGEPFP(1967436175, -1018374.0403475633);
    this->uiLNPa(string("sbfetFINLQOUioscFQiWSgoyBcithudcOkoscGzBQiAHsXCwYDIINHjrKQirdYXKflgZVtVFcQOCCRgYxpCeqsKvfDwAFfxBRdXMbPWauvhhettFuWptVTSBMuRGSNOaaNrmTDJzzojsFKyNgYaHTRjnvUShOcLNugXOTdQhMhhkANBxlOadDXOQSPXTjoORYZMudUjdyyhpdlUqPCgGcaEFVzoHPBeHZiDCpZxPcVeygj"), true, 1939748471, string("ZAeMPuurnClQRCeKfvlgVqnvCRTIqWLAwdxNpRpCTQVqJIjZIUwMVvcRkzRYCXWjqdmUdjRQLTeYZXeoOwlCxHVvZTTdYTmZNHFlPvcXAJodwZYakTZtFvKpBwb"));
    this->neGgLqDfonUeZrdj(false, -874846502, string("OJzfGpsGgrQPxLUJhroKMqZBKInMEEXOFcomkzDkekyyPYDiXyQezSznNgftQnpGimDlYqkJwTCXPmlETHABRBSbVkiYPiezHZxDDNxbHiTpixnXODoYZKWveHWQckEKTeZrSNnRvcjNMGyODKOHQVAwbxiNNKyLT"), -297503055, 1577864641);
    this->baITwqZ(false, -686538.7769961184, false, 510566390, 1481394728);
    this->TsEqumunuLsw(-3869.616795266927, false, -192713.55410501998, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class JqxqJrDLC
{
public:
    bool ktDzI;
    double kecuSIZzrsV;
    bool nrgACwEtpJKRqmo;

    JqxqJrDLC();
    double QiHtAIklcHkaDjyD(double qOroQF, bool BazNP);
protected:
    bool GBzMcCxsGbdn;
    string kOXofYaK;

    void nZsNBDC();
    double wZEmrRzxpn(string yJeUIJvaIrROvO, double ilyOQlJPrze);
    string UYhyAidoy(bool vNLMjwTPMkTpNfy);
    string OUNvOFcgFDW(string MEcDOPKHhLz);
    int RgVMLEUdOYM(int QpWQoVlFJTvDt);
    int iLSSxjDKE();
    int bsVOtexQVWPS(string kzIGRV, int MXrDDOXp);
private:
    int mFOAzaM;
    double XsgSdAkrK;
    int pgQJOAsprtvIVpxe;
    double jUyUleSkF;
    string jXaDGzezJ;
    string lnCAZ;

    int RtHNjhZGzoZd(string BWwfyepmPeUpwaL);
    string grrAGyPiqIAKA(int ZMIWYBJVYTD, string FbUyaGdNirLBbKgx, double DyTrfjLs);
    string cdFCFdCPZMmGwmir(string RaZTopPFsrfAwk, string YieTSbinQYdw, double NDZVcPsclQIw, double jfdASeexO, bool DADQpYPLfym);
};

double JqxqJrDLC::QiHtAIklcHkaDjyD(double qOroQF, bool BazNP)
{
    bool umfeIFZawt = true;

    for (int wZLddrqMYkquoww = 1883286157; wZLddrqMYkquoww > 0; wZLddrqMYkquoww--) {
        continue;
    }

    for (int spARmyV = 1870998512; spARmyV > 0; spARmyV--) {
        umfeIFZawt = ! BazNP;
        qOroQF -= qOroQF;
        umfeIFZawt = ! BazNP;
        qOroQF *= qOroQF;
    }

    for (int AuqaYOyydl = 1098513808; AuqaYOyydl > 0; AuqaYOyydl--) {
        continue;
    }

    return qOroQF;
}

void JqxqJrDLC::nZsNBDC()
{
    int QsLepxXGZSQIaIFM = 1448068085;
    bool bdNuADq = true;
    int pVQzkirADj = -790098219;
    double MYLGDckbnTtFlgB = -316733.07800890785;
    double JPwDxqfsTj = -208268.4293470924;
    string JkJVXRqFKowAM = string("pQhJWHKKWwpBFhmeaQvCUKqSPjZLUCwsbhxUjFvgggNAHvkwjBdLIHIpwyPZwkcqWBWiECMWqKPZZOWqkKNbWqLXhKXnQhDLaKQsXwGOAhCBjqMQNBdAlfzQaeAcueBluoRfaQrzlpBQUsaMFpVJSrjFGyKdGIayvpBNFinrXJnuGSiIGWmQxHiCeGUoDXdiRbSEOmEkyZWBCYwjAhVSedwRPtgX");
    double GrQVQuaAf = -19364.598342249523;
    bool QSZhUHEBTTPpTEXK = true;
    bool NkMwJSBIienu = false;
    bool XtvoeSBoBa = true;

    for (int wJtVOeGUUZ = 293947667; wJtVOeGUUZ > 0; wJtVOeGUUZ--) {
        XtvoeSBoBa = bdNuADq;
        XtvoeSBoBa = QSZhUHEBTTPpTEXK;
    }

    if (GrQVQuaAf <= -19364.598342249523) {
        for (int OiUcHdLaJNo = 1158536252; OiUcHdLaJNo > 0; OiUcHdLaJNo--) {
            continue;
        }
    }
}

double JqxqJrDLC::wZEmrRzxpn(string yJeUIJvaIrROvO, double ilyOQlJPrze)
{
    double lrwJf = 79346.8547424678;
    double BCQMjBdABRat = -467843.32573400263;

    if (ilyOQlJPrze < 79346.8547424678) {
        for (int RRPlPLEUu = 1522550492; RRPlPLEUu > 0; RRPlPLEUu--) {
            continue;
        }
    }

    for (int lwkKOF = 1155362570; lwkKOF > 0; lwkKOF--) {
        BCQMjBdABRat += ilyOQlJPrze;
        BCQMjBdABRat += ilyOQlJPrze;
    }

    return BCQMjBdABRat;
}

string JqxqJrDLC::UYhyAidoy(bool vNLMjwTPMkTpNfy)
{
    int ZugKvVH = 298284767;
    int TaiTAkeLWMogjl = -444731222;
    double btGPEnYN = -516960.9770232052;
    double IyDMSHLq = -241152.23593200417;
    int QWmoTfkReEkCt = 418725881;

    for (int qtVfZpDsfECMAK = 341650939; qtVfZpDsfECMAK > 0; qtVfZpDsfECMAK--) {
        QWmoTfkReEkCt += TaiTAkeLWMogjl;
        ZugKvVH -= QWmoTfkReEkCt;
        TaiTAkeLWMogjl -= TaiTAkeLWMogjl;
        TaiTAkeLWMogjl -= ZugKvVH;
        ZugKvVH = QWmoTfkReEkCt;
    }

    return string("fGlxWcetzKzAwlhoKBcGlEiTgkqSNptRDHVVoTWa");
}

string JqxqJrDLC::OUNvOFcgFDW(string MEcDOPKHhLz)
{
    int NoSkEnwrXBweb = 1037500954;
    double RCXvmzmmCaoG = 885735.8717950489;

    if (MEcDOPKHhLz <= string("qzyfftfHLDRrMkpFhFOUI")) {
        for (int mmolIMS = 1429537338; mmolIMS > 0; mmolIMS--) {
            MEcDOPKHhLz = MEcDOPKHhLz;
        }
    }

    if (RCXvmzmmCaoG == 885735.8717950489) {
        for (int eckktnFVGQQVAGpE = 1106741868; eckktnFVGQQVAGpE > 0; eckktnFVGQQVAGpE--) {
            MEcDOPKHhLz = MEcDOPKHhLz;
        }
    }

    for (int svyxkyuhzd = 429967223; svyxkyuhzd > 0; svyxkyuhzd--) {
        MEcDOPKHhLz += MEcDOPKHhLz;
        RCXvmzmmCaoG /= RCXvmzmmCaoG;
    }

    for (int bLLfoRyCuruJhj = 1903395680; bLLfoRyCuruJhj > 0; bLLfoRyCuruJhj--) {
        MEcDOPKHhLz += MEcDOPKHhLz;
        RCXvmzmmCaoG = RCXvmzmmCaoG;
        RCXvmzmmCaoG += RCXvmzmmCaoG;
    }

    if (NoSkEnwrXBweb != 1037500954) {
        for (int oNqRiCtnG = 196840691; oNqRiCtnG > 0; oNqRiCtnG--) {
            RCXvmzmmCaoG -= RCXvmzmmCaoG;
            RCXvmzmmCaoG = RCXvmzmmCaoG;
            NoSkEnwrXBweb += NoSkEnwrXBweb;
            NoSkEnwrXBweb = NoSkEnwrXBweb;
            NoSkEnwrXBweb += NoSkEnwrXBweb;
        }
    }

    return MEcDOPKHhLz;
}

int JqxqJrDLC::RgVMLEUdOYM(int QpWQoVlFJTvDt)
{
    string vOXfeiWnXUy = string("mCbwzMEIjyzIffaYexmVTzRzuPeLQmhkHJDlvOaBIfTUjFzUYxkXtOhZCIrVKHxoWcZYBqYLNhgfdGfHmqKxVSskoCDoIquiViaGpyviNqSPsAMCTueygReBgOkRuNozvlYJKmVfnZvCIhcejSnbBTClQmwTtAdiRXqZomIFSOgwxSqKLbIUZHdBcEFfGcXYJXhSkIidEMNzisudKpuswtDkczClEhfNCQCytMSJParDOAZOChKdWswjj");
    bool KxFHKniRFEOmydPJ = true;
    int qtGanj = -1279845318;
    bool qhuPJhiqCFG = false;
    double uMONiZ = 630598.28073839;
    int HgmQE = 2076561072;
    double ozXMxdZEQtpzLJ = -555632.1969386116;
    string mlUdyxslVZfKz = string("kvFtIHZTZSLQGNCkxSMqtRAbPPOpGZCeXDvjvvYJSNFPEQRKkzbtHhUIgDgfKfJjTFhkNFynhvTipeSKlyATOevAlNAqJAaZGwEmMTZVlbqxVFMJkZjIdNgAFkynmzJzHBoFhuwGUFnGkNDNaBZrhfzSMWYBKoTcOsqMVCSGszTpTmGMSeJVpUxAeSSkkLt");
    int fAsAsgsCCXnrDRrr = 1042151804;

    for (int eChfiK = 1386515027; eChfiK > 0; eChfiK--) {
        qtGanj *= QpWQoVlFJTvDt;
        KxFHKniRFEOmydPJ = KxFHKniRFEOmydPJ;
        uMONiZ = ozXMxdZEQtpzLJ;
        qtGanj = qtGanj;
    }

    for (int YghAvteNLDv = 2043516473; YghAvteNLDv > 0; YghAvteNLDv--) {
        qtGanj *= QpWQoVlFJTvDt;
        HgmQE /= qtGanj;
        uMONiZ /= uMONiZ;
    }

    for (int necvBYcL = 2051898474; necvBYcL > 0; necvBYcL--) {
        continue;
    }

    for (int kiDCoYgUQwa = 1070391384; kiDCoYgUQwa > 0; kiDCoYgUQwa--) {
        fAsAsgsCCXnrDRrr = HgmQE;
    }

    return fAsAsgsCCXnrDRrr;
}

int JqxqJrDLC::iLSSxjDKE()
{
    bool sfzliHRtii = true;
    bool nxdbpBoX = true;
    bool iExebNF = false;
    int uiCSbLcHr = -942951604;
    int eHhWoYqKE = 703405384;
    int lQkhtXJRLTeHgoF = -1043381838;
    double ztnsB = 617849.420767695;
    bool ibXBuIFgoXS = true;

    for (int oLFkdOlAQNG = 1877008727; oLFkdOlAQNG > 0; oLFkdOlAQNG--) {
        iExebNF = ! ibXBuIFgoXS;
    }

    return lQkhtXJRLTeHgoF;
}

int JqxqJrDLC::bsVOtexQVWPS(string kzIGRV, int MXrDDOXp)
{
    int lWoyCVpEOLG = -1701060055;

    for (int RNhbv = 7628133; RNhbv > 0; RNhbv--) {
        MXrDDOXp = lWoyCVpEOLG;
    }

    if (MXrDDOXp == -193238888) {
        for (int IUHqwA = 1141997870; IUHqwA > 0; IUHqwA--) {
            MXrDDOXp = MXrDDOXp;
            lWoyCVpEOLG /= MXrDDOXp;
            lWoyCVpEOLG -= MXrDDOXp;
            lWoyCVpEOLG = MXrDDOXp;
            lWoyCVpEOLG /= MXrDDOXp;
            lWoyCVpEOLG += lWoyCVpEOLG;
            lWoyCVpEOLG *= MXrDDOXp;
        }
    }

    for (int gBbUoileZS = 575354964; gBbUoileZS > 0; gBbUoileZS--) {
        lWoyCVpEOLG *= MXrDDOXp;
        MXrDDOXp -= lWoyCVpEOLG;
        MXrDDOXp *= MXrDDOXp;
        lWoyCVpEOLG -= MXrDDOXp;
    }

    return lWoyCVpEOLG;
}

int JqxqJrDLC::RtHNjhZGzoZd(string BWwfyepmPeUpwaL)
{
    bool yxvhoeAOyTZGaxcK = true;
    int iBgyPRrduMN = -104000524;
    int rWnHZx = 982810796;
    string nyFybjOBhOOVniV = string("BAfIIObcQPprSsvCkMIrIocIeupiocuGCGViJAscxueCAjpfDrqCMBzmfNDoEtSMbbOTSnanvDbZTramtteSeHlDdFFldIIjdvemSVAnejluKhpwteIklpJouAFMugDVXdvmsHsmYPRXYUgqLNsNrNHxzYzTOjrgqoyBeZcPapzoVGGcU");
    int tASXcdb = 717544252;
    double sgJzXkEKse = 45793.02040030562;
    bool yisZWb = false;

    for (int GFnDtyyjOgEGFKD = 1936380376; GFnDtyyjOgEGFKD > 0; GFnDtyyjOgEGFKD--) {
        yxvhoeAOyTZGaxcK = yisZWb;
    }

    for (int cwntRaAsiV = 1407046545; cwntRaAsiV > 0; cwntRaAsiV--) {
        BWwfyepmPeUpwaL = nyFybjOBhOOVniV;
    }

    for (int xbvKlaOML = 1597761314; xbvKlaOML > 0; xbvKlaOML--) {
        tASXcdb *= rWnHZx;
        tASXcdb += iBgyPRrduMN;
    }

    return tASXcdb;
}

string JqxqJrDLC::grrAGyPiqIAKA(int ZMIWYBJVYTD, string FbUyaGdNirLBbKgx, double DyTrfjLs)
{
    int MNlOfvRDE = 1591014657;
    string tEPcRkk = string("FRnvoVEWaLdnCOIvINgyLhzblhUvPvf");

    if (FbUyaGdNirLBbKgx > string("UdVPqSUthfcLCrNccociqsJclWhwcpYnsjvrjIjGPzXxStevAalHiUoQzcweHtBdwpvSHITdytBEQBkFGefTxRrLrqfxKvEDNOHhWpt")) {
        for (int ynEHfBPY = 86269199; ynEHfBPY > 0; ynEHfBPY--) {
            MNlOfvRDE -= ZMIWYBJVYTD;
        }
    }

    for (int wHkLo = 387638017; wHkLo > 0; wHkLo--) {
        tEPcRkk = tEPcRkk;
    }

    return tEPcRkk;
}

string JqxqJrDLC::cdFCFdCPZMmGwmir(string RaZTopPFsrfAwk, string YieTSbinQYdw, double NDZVcPsclQIw, double jfdASeexO, bool DADQpYPLfym)
{
    string kzBDQcAXgQNpmD = string("mvVJcbvzPsayDtEbyfPYZpRpBtwEzNLYvDJWapleFaiCEBruWsNkEqGJXeZXPHmZPYvkFdgMAXuELmavLXPpWWkKgNEjvULrdboCawuFzqYbGYWwlUcpugaPOwGUKUIHRUzjHpbIEcLitfoZdRKEMVTqrgEGuqnmYbzkLUHVxbGoeNuRaCYpQzzrrgIibwOTOTOTHqyZhLQfXuvMQGpQewkhbPE");
    double WsFgosCepdgnd = -247741.3417829043;
    string wLpHhDsS = string("VcHKlaeHOWzkjAGamrQKfhaizISPqKoLhTlqWaMqVcqjbaqaqligLaokWztaYfoBAkbujhWsUFoQVOUWwapRxmTiWNLmryrIwkMshfrfQDlvTkteBGHGyfreaFSsgTvJMhhPiFmXjtnGqsBNhupsQFGawzdiCoVmGKxHcmFtLkBobksPAhScRfPfDzMkImXSUqsIunBSIsCtMCMQEkDRKRpixdPGQdz");
    string usZxVguNE = string("NgbZPZGSUuOTtDDHTpoJFDnsEJBtaHLUnXykfiNqAumUUzChtqWShEIiKHfmIXCedFTgaBiEUdEszKCZkgLZRXnBVwzKPcVWXsrlDNsnGgtDxmzmfHYkWtCSpOlfCRtmhpFeAtxnbHYpnBoEpRNAGqYHPWvoYgvaSZraundOiJUTZjFqxgUnhtFiP");
    bool OrZesaMZma = false;
    string FvrdpvR = string("aPthhtzHysA");
    string IlrEAwbnGX = string("pDnGqOcZBXaSeskwLxeVpugDqOwEEQlMjqgeGavywoNXYIhcnpAPGiIpRmoofOGzJjqnNdgbJHncBalpQcoAqvhbcntCcFcCiMuerQwIFupWLgIrZQwAMFVNfDwkxvVYTlmiMWPcKksXyBinfDxvEztIvfLpUcxupFpmXWoYRKLAWbgHDFyfVFPyIrTcWGSTaCfEpanmqjJzFanKdpTQvUZqRzdDTsupUcxcIZ");
    int yoogrmkZFTGR = -1118222919;
    bool AUiCsp = true;
    bool cKcYunoeEPNlZL = true;

    return IlrEAwbnGX;
}

JqxqJrDLC::JqxqJrDLC()
{
    this->QiHtAIklcHkaDjyD(590969.1771101006, true);
    this->nZsNBDC();
    this->wZEmrRzxpn(string("gwFIAptnHIwpSWMztdelMinfBsGvkAwuLsQKKlxPwpFqotlFZOcoSUNaRpOOMIeKWrjpBOxnDlqJsHBpBxIlhiLCIuCGOtUzXYbMiVLVljAWqCMxMukaUbdEFITeSJiGMfhuLxEYRdICAgBjorWfLlRQeBRhvmIJITEAYxGharbphNczoIUHyZOAsqaieSwTheDkvV"), 350535.5756063404);
    this->UYhyAidoy(false);
    this->OUNvOFcgFDW(string("qzyfftfHLDRrMkpFhFOUI"));
    this->RgVMLEUdOYM(1236157211);
    this->iLSSxjDKE();
    this->bsVOtexQVWPS(string("ckXXdBJEhZGvuxyfynbQFVBMpVoPWUhCDRnbgRjHtACvoZXCfZwDDqZATHPmaqjQmEFwyxlBeyUSCMcoXhYnwVnAqtVclCXYjFYVMhMOjRfswFtjawNF"), -193238888);
    this->RtHNjhZGzoZd(string("hozYBDBLdMgdnlCObkFVaXFxstElThPppirJWapIjKeXuoGLqQfirkICdMqOiwZlKNnsITQlePBsCmLaARmuqguGBFfySNXUvzOqsPFJsOYCWaQpPfveMGpbUPAZdIwhkRKCTVwn"));
    this->grrAGyPiqIAKA(-1759917706, string("UdVPqSUthfcLCrNccociqsJclWhwcpYnsjvrjIjGPzXxStevAalHiUoQzcweHtBdwpvSHITdytBEQBkFGefTxRrLrqfxKvEDNOHhWpt"), -411011.482193503);
    this->cdFCFdCPZMmGwmir(string("sUiYuJrtCPbfptxATmVxhzTDbbSYCHGIsuekAugjYuBJkDjGHWqeOEaUQzAsMjAMZbaFViNFkoYrpjqYWvUEaWTrcwMPBqGruECCKFSHIpsQqJuoT"), string("yrWvwLriFhNNbbEAGoNWpEwZUKhtUPppXPswVQubdZmtGTYLhfshIGBYymNeBrNrJCEzvUkgYxoslCEJBLroHBVUywtWgdusSdCZkaEcfkqJfjZztqbpkyxfPxTbSZeHrQq"), -971731.7991941229, 843923.7590463655, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class dFspv
{
public:
    double mphKAHArMo;
    bool XJJMBZv;
    bool RDSmouhvo;

    dFspv();
    double mqtJBPLk(bool lAulsRKbJGt, int wIOMZ);
    int FmJoAPj(double BjzzzjpRbKGDvn);
    bool PESwBGVuHkrYag(bool fOOZxgwjaQfov, bool YVpwf, string IfPyFKZ, bool ADuxe, bool SrAxqlbXxiUgK);
    string kAFYToQEVznUgv(string BXKtQiZKi, double uEULXhNk, string GvTMMYUQWwOxGLy, int eOEcGWmiuQQM);
    string oaJQtYJEK(bool UrcGWSrq, bool LoxvEFQE, double DDHJOEA, bool HfQKNlnhAX);
    void JwHHygDomoJKffNu(int EirjgVBFNtlfTBZx, string HIcgQQUKUiMsA, string onPegYVUJzkBBnu);
    void BkNPAoTmoouqEO(double ueYvjPTZdq, string aKaTHX);
    int REuxu(double WLVBy, string exPddMLcurjMzxjH, bool QnOwZDgje);
protected:
    bool rANRWBLNxYHytmfy;
    bool BhUiTMETD;
    string qvzIWr;

    double gNteLKFrthkMAk(string jlHhzyCQ, int IYlGNvFrgTEGC);
    double zHPihzBxAVYEIB(bool RhGgczNYuzoYOK, bool nIwEMKylMVITXGx, bool ywMAAQqKWwXxGaKQ);
private:
    double wZwsf;
    string jXlladeht;
    int hvTUVKHhScRQquLm;
    bool pviayPMWCc;
    string MzWtS;

    void FDYfaYdXdDZRxygp(bool uBmPYzGrvZ, double RUCRDHVvV, string GXNXZIQfrP, double SORTo, bool lLTPDXWhrCgujG);
    double eAOMStDx(double BwJdmXQ, string vtEKCFJGpNEHNkZ, string uWutyqElnvFnJHz);
    int HzLNaYok(string zqlUGnNg, int tfZJaBk, bool sfkNJ, int LfVfmfACPJsmyOS);
    string MZnaxNQpKUBozHa(int LVmGGXiHUb, string jIyvaOhwdhEUNvaj, double whEQzSoSxXoJj, int ZHZZuccJG);
    string WRWlFRSAJJS(bool omampzvxSvJj, double psaUl);
    double OzQaUkTNnZQK(bool XsSShyCYiTd, bool DftClQmJGm);
};

double dFspv::mqtJBPLk(bool lAulsRKbJGt, int wIOMZ)
{
    bool xQUMjYxHpR = true;

    if (lAulsRKbJGt == true) {
        for (int wZrVm = 656873057; wZrVm > 0; wZrVm--) {
            xQUMjYxHpR = ! lAulsRKbJGt;
        }
    }

    return -983050.130444591;
}

int dFspv::FmJoAPj(double BjzzzjpRbKGDvn)
{
    bool wThSRdKCRrUXoSn = false;
    int sLeLbXXKRF = -2082155059;
    string vwARKE = string("oWygjQatAXNBktNKoGsfbaxhCcJMStrNwhkTopyVoPoSBlsRVRtimkhHUsmDrchbsnnsdqlPdqlHtNwsXEyBpQoSXAjivHcj");
    string mxnztdx = string("AWxOEqodPaVKUAXDbFanFUEqYsFLIoBqMfnDalQQqMBnOwpbcJaYjIQQPhUOoPPzUXFPXsKVfcuqKSSlIScCmbZIQjxUqXR");
    double pNAsUzygxpwKvUl = 871006.4718815878;
    string bdkBuSmCQyc = string("ZemwNIEOiQMCyNSMDAiNgyTHBwNMpvTshJQivXlIEvMIHUVidVXUpJlESlPDpQUEVlVdOhmuOeuKxIskvurtpWNkiWHfoVOFMEyHuCDjPlxJNqnRJItvxVbMFrRyYSEWXpKg");
    bool pnmpzlVfFZjBkPU = true;
    double jJgGBYwAIPbQcm = 118768.84577436643;

    for (int XzgKREblBB = 503075180; XzgKREblBB > 0; XzgKREblBB--) {
        BjzzzjpRbKGDvn -= BjzzzjpRbKGDvn;
    }

    if (BjzzzjpRbKGDvn == 871006.4718815878) {
        for (int YYSnhQiZbqph = 1692024791; YYSnhQiZbqph > 0; YYSnhQiZbqph--) {
            continue;
        }
    }

    if (vwARKE > string("AWxOEqodPaVKUAXDbFanFUEqYsFLIoBqMfnDalQQqMBnOwpbcJaYjIQQPhUOoPPzUXFPXsKVfcuqKSSlIScCmbZIQjxUqXR")) {
        for (int TdgcPVorlqk = 1110802430; TdgcPVorlqk > 0; TdgcPVorlqk--) {
            continue;
        }
    }

    for (int IDVOLlv = 711939975; IDVOLlv > 0; IDVOLlv--) {
        bdkBuSmCQyc = mxnztdx;
    }

    for (int TZhTZqY = 2066518349; TZhTZqY > 0; TZhTZqY--) {
        sLeLbXXKRF -= sLeLbXXKRF;
        pnmpzlVfFZjBkPU = pnmpzlVfFZjBkPU;
    }

    return sLeLbXXKRF;
}

bool dFspv::PESwBGVuHkrYag(bool fOOZxgwjaQfov, bool YVpwf, string IfPyFKZ, bool ADuxe, bool SrAxqlbXxiUgK)
{
    double iMLKBqn = 656789.9603266036;
    bool IutLbGMnT = true;
    int zFBBuAweX = 852811963;

    if (YVpwf != false) {
        for (int JcwhxAwm = 38311678; JcwhxAwm > 0; JcwhxAwm--) {
            ADuxe = fOOZxgwjaQfov;
            IfPyFKZ = IfPyFKZ;
            fOOZxgwjaQfov = ! fOOZxgwjaQfov;
        }
    }

    if (YVpwf == true) {
        for (int cQsSzWlo = 1849095164; cQsSzWlo > 0; cQsSzWlo--) {
            iMLKBqn -= iMLKBqn;
            iMLKBqn -= iMLKBqn;
        }
    }

    for (int VlaqFpiGnaunYN = 1985654942; VlaqFpiGnaunYN > 0; VlaqFpiGnaunYN--) {
        fOOZxgwjaQfov = SrAxqlbXxiUgK;
        YVpwf = ! ADuxe;
    }

    return IutLbGMnT;
}

string dFspv::kAFYToQEVznUgv(string BXKtQiZKi, double uEULXhNk, string GvTMMYUQWwOxGLy, int eOEcGWmiuQQM)
{
    double JAVLwxllrDF = 95735.30147622999;
    double bvAgHJXE = 337207.3959774128;
    int jVSgyfHTMFP = 200581929;
    int prdQerMzZw = -1906133763;
    bool tncCvKqJL = false;
    int xvzoDoaOpMi = 1823754452;
    bool jzNCerWDIVPoj = true;
    double bPGfoWOmTxGqi = -781576.0344219796;
    int TJSQxrTmdGvsPoui = 708385195;

    for (int yRbwFdvE = 2128384041; yRbwFdvE > 0; yRbwFdvE--) {
        bvAgHJXE -= uEULXhNk;
        uEULXhNk /= bvAgHJXE;
    }

    return GvTMMYUQWwOxGLy;
}

string dFspv::oaJQtYJEK(bool UrcGWSrq, bool LoxvEFQE, double DDHJOEA, bool HfQKNlnhAX)
{
    double xBymrp = 566388.6442337701;
    string LsPfhI = string("mSfMowExKXjokZdmKiAOHjomGbBEqkehtOHNoFPSrCFPEmPiTnBujeIbbOgITcoKOJdzutaVZCIylHUxwQQyXrsZjIyhFMOAgnscNfNWaNjhT");
    int ERkaqYrg = 1515975606;

    if (LoxvEFQE == false) {
        for (int PsoxCvqtKOIugT = 232851039; PsoxCvqtKOIugT > 0; PsoxCvqtKOIugT--) {
            HfQKNlnhAX = UrcGWSrq;
            LoxvEFQE = ! UrcGWSrq;
            xBymrp += xBymrp;
            LsPfhI = LsPfhI;
            ERkaqYrg /= ERkaqYrg;
        }
    }

    return LsPfhI;
}

void dFspv::JwHHygDomoJKffNu(int EirjgVBFNtlfTBZx, string HIcgQQUKUiMsA, string onPegYVUJzkBBnu)
{
    string RDoFKlclumZ = string("EhZQYDRlQuGcYVKPxeqPknmbjarmxnKijUxLgvKdqIiyobqNkmkjqeyPyefpbWTOisCopuGHHOyWpzaTuvjJQpdLUjdVeyKzlVCeQKfXJHofXAsrRkPIzETyOnaoSPQaQHXfekctgYUAvgZYTuoCjAxpDFokKkqOObahLRyzKRGzbiFLYxAIBvETChOrErXWvgaUClaYKSGOeVeqSJzbdaYgWYXkxEpXMgFo");
    int DzYQtUEDsjWslb = -742138569;

    for (int otYocegQzmKuy = 463927169; otYocegQzmKuy > 0; otYocegQzmKuy--) {
        HIcgQQUKUiMsA = onPegYVUJzkBBnu;
        HIcgQQUKUiMsA += onPegYVUJzkBBnu;
        RDoFKlclumZ = HIcgQQUKUiMsA;
    }
}

void dFspv::BkNPAoTmoouqEO(double ueYvjPTZdq, string aKaTHX)
{
    double kuBkKEnGixowd = 604835.3713416128;
    string ukmQv = string("abadaryGCKfXPyemQbAkBmI");
    int jPKaAydNVHUUDv = -211627872;
    bool DGOKSuAWFuNLKnnN = true;
    double XAloyvJbenk = 696621.0868576089;
    double WxiEi = -268479.29527559225;
    bool FLKqV = false;
    double jDJySoqv = 229994.6849955766;
    bool GQEHHekZhFAgFevV = true;

    for (int DGaqPThwuaWxsMi = 452651629; DGaqPThwuaWxsMi > 0; DGaqPThwuaWxsMi--) {
        aKaTHX += aKaTHX;
    }

    if (kuBkKEnGixowd < 229994.6849955766) {
        for (int vCrOutkDWTOjJEL = 1750663843; vCrOutkDWTOjJEL > 0; vCrOutkDWTOjJEL--) {
            kuBkKEnGixowd -= jDJySoqv;
        }
    }

    for (int RCrhcVbaS = 1615990154; RCrhcVbaS > 0; RCrhcVbaS--) {
        kuBkKEnGixowd *= WxiEi;
        FLKqV = FLKqV;
        XAloyvJbenk = ueYvjPTZdq;
        XAloyvJbenk /= kuBkKEnGixowd;
        FLKqV = DGOKSuAWFuNLKnnN;
    }

    if (WxiEi < -268479.29527559225) {
        for (int PQNUJLTnGJeSp = 1368523151; PQNUJLTnGJeSp > 0; PQNUJLTnGJeSp--) {
            jDJySoqv += ueYvjPTZdq;
            GQEHHekZhFAgFevV = FLKqV;
            DGOKSuAWFuNLKnnN = ! GQEHHekZhFAgFevV;
        }
    }

    for (int WIncPDxKMnAr = 664448273; WIncPDxKMnAr > 0; WIncPDxKMnAr--) {
        GQEHHekZhFAgFevV = GQEHHekZhFAgFevV;
        jDJySoqv += WxiEi;
    }

    for (int jbDGWaquwL = 51542457; jbDGWaquwL > 0; jbDGWaquwL--) {
        kuBkKEnGixowd += jDJySoqv;
    }

    for (int CpNJYTSnOcTUzd = 1944165305; CpNJYTSnOcTUzd > 0; CpNJYTSnOcTUzd--) {
        FLKqV = GQEHHekZhFAgFevV;
    }
}

int dFspv::REuxu(double WLVBy, string exPddMLcurjMzxjH, bool QnOwZDgje)
{
    double KSOfPftzAX = -90582.11528337812;
    bool pGCYJRZgosMKNq = true;
    string HNmJlIuNH = string("vMPyXRyiWmEWSlOeLteAUBLgSkGPmtRJlPSnqHVfHXHGlYtKPHTYVRJeDYHuFTGJCRGhaEXCQSerBsPiVBxhlpQIWuaHzuVGORLtlTiPjpiQIrfintnmidRhxOvjORTGLmtEFyDzFrBFIdtupJSfccZVBGnnpjqLNCMDPKzOOHkRtincEqAVcHvwXqcefXnPXlTmOIzrizHEdZVq");
    string RuQIqijXIQfaHhOe = string("LOTlzwpBGCFOAtpaqexGsdsvpvucfcMzKcdSKSnsjUfaoPHKHxkJIobGGhBjxcalj");

    for (int CnUtwTtuzcOAWrzI = 1744517835; CnUtwTtuzcOAWrzI > 0; CnUtwTtuzcOAWrzI--) {
        continue;
    }

    if (WLVBy <= 216439.65350413008) {
        for (int OYJqDkfbjH = 1137399092; OYJqDkfbjH > 0; OYJqDkfbjH--) {
            HNmJlIuNH += RuQIqijXIQfaHhOe;
            WLVBy += KSOfPftzAX;
        }
    }

    return -1532256737;
}

double dFspv::gNteLKFrthkMAk(string jlHhzyCQ, int IYlGNvFrgTEGC)
{
    int hwrXXXnXCJPfVq = 943597124;
    int hQxAesoZjzfm = 1362481685;
    string DTlmDGgTIDMMcH = string("vGDNZMhvOcgSaSWZRNpsIEmOyVpwMgZdylRgfTqQSAjjnPmtjhhIYDKukHvpVCETcfpdJUYKKeorLCbAHZmyEi");
    int lMQlU = -1573516062;

    for (int oVkGeFaCHgDBlea = 736369680; oVkGeFaCHgDBlea > 0; oVkGeFaCHgDBlea--) {
        hQxAesoZjzfm /= hwrXXXnXCJPfVq;
        hwrXXXnXCJPfVq /= hQxAesoZjzfm;
        IYlGNvFrgTEGC -= IYlGNvFrgTEGC;
    }

    if (hwrXXXnXCJPfVq == 943597124) {
        for (int pnxBQRAbelXR = 2093189659; pnxBQRAbelXR > 0; pnxBQRAbelXR--) {
            hwrXXXnXCJPfVq *= hwrXXXnXCJPfVq;
            lMQlU -= hwrXXXnXCJPfVq;
            hQxAesoZjzfm -= IYlGNvFrgTEGC;
        }
    }

    return -536524.7840990705;
}

double dFspv::zHPihzBxAVYEIB(bool RhGgczNYuzoYOK, bool nIwEMKylMVITXGx, bool ywMAAQqKWwXxGaKQ)
{
    int ZeFLjomkvbM = -1522700726;
    string pBjKufjZakop = string("bDvsQwlinaJslRjwMGIIOZOHDeTjogUaJbTNBLtrLNlizvyfxQvDjxWdLWJWCIsabzjAOgsyJtZNhODxHZmCLxvxwzWgOfvFmUEgZaGIRITzupYwdhyAOQpHvxVSLPuhxYJIBCcEWkMbyRnWlVSrttxgybEsOEPdEAeIRNsbYKZNsZyItSoDdGyRmMLIAKchTpUlhpasyiHFXsHVYHgtnKOslVSYHMnQHezIynvcSdukfNMiKJkvHhkZyCuH");
    int ieeLFMJUzqbPn = -385769699;
    int sMAMdCAHmxzit = 1708589506;
    string rsnzngQoFHjhKvUe = string("iDiaotUiDzRDGOgsDubfBKPWedhiFTuTogIHdtvJlaobhNtpVLflHRjcAjhEgqrVPxdWicfenBqxDSK");

    return 687899.6991179186;
}

void dFspv::FDYfaYdXdDZRxygp(bool uBmPYzGrvZ, double RUCRDHVvV, string GXNXZIQfrP, double SORTo, bool lLTPDXWhrCgujG)
{
    bool dRXwxBltCxc = false;
    int sdZMPh = -603265988;

    if (lLTPDXWhrCgujG != true) {
        for (int XQIKcsOdaukn = 2057490946; XQIKcsOdaukn > 0; XQIKcsOdaukn--) {
            sdZMPh = sdZMPh;
        }
    }

    for (int XoGwpiRnaBDqTVq = 1172551540; XoGwpiRnaBDqTVq > 0; XoGwpiRnaBDqTVq--) {
        lLTPDXWhrCgujG = dRXwxBltCxc;
        lLTPDXWhrCgujG = ! lLTPDXWhrCgujG;
        SORTo += SORTo;
    }
}

double dFspv::eAOMStDx(double BwJdmXQ, string vtEKCFJGpNEHNkZ, string uWutyqElnvFnJHz)
{
    string PSdzqNeNimA = string("MXmEpLrMwxgbAHFbYUlfyVWIdtExivTyxFLNgsfTjOgFijAVFRrkPQERKGVTzrntbwJsmaFvgSZSBtQQpqqDDlROAmpMxcyCSTuNYdmYXRfwRast");
    double YLHIKdZtDlucFTu = 449905.01284107525;
    double vBWjKBR = -1003750.9407260473;
    int dnKjor = -129069804;
    string wwZMeXAu = string("AKuLhXBomITpqvhTtDmxPoGrREWOXgIJojGhmlkvhYgSbrxoeVttXuUXosFaEIbYXQJVbMjiyewLNyhYzByiduNsHcXzLssDpLwHPAVsNPYMdhtuHMUBwfqQlgdWFgrtLreMPNtlPKlhTjuBuOtHikZNKDbLjTZNolopwILlyhLzKGcLwsYpSNjhHFVExxCqMYbxpNoqhRrtkFajazkYhnAYMgThWaPgZVjtKcUFXHO");
    string tfIowHFusbfI = string("oFKyvvJTllFRFACTDJUxLSLDftIYksYuYFLuyOuDSBdLfTRDafBnFiyUNfbbeebreXMxLuEKVLvczBcnzshnwwgbvjAvcBNrDxdtAHRmQODcjKfldjQTzsKpHwtbbDQtHnUmWFSVQrGukkObdHiNUOKkWfmDsaRxcEQFIufkaZPCeKmHwGJaSWxdlryXqguSsN");

    for (int HXfQKPU = 2014311911; HXfQKPU > 0; HXfQKPU--) {
        vtEKCFJGpNEHNkZ += tfIowHFusbfI;
        PSdzqNeNimA += vtEKCFJGpNEHNkZ;
        PSdzqNeNimA += vtEKCFJGpNEHNkZ;
    }

    if (uWutyqElnvFnJHz == string("MXmEpLrMwxgbAHFbYUlfyVWIdtExivTyxFLNgsfTjOgFijAVFRrkPQERKGVTzrntbwJsmaFvgSZSBtQQpqqDDlROAmpMxcyCSTuNYdmYXRfwRast")) {
        for (int wxBdHevfHItgWF = 886715108; wxBdHevfHItgWF > 0; wxBdHevfHItgWF--) {
            uWutyqElnvFnJHz += PSdzqNeNimA;
            tfIowHFusbfI = wwZMeXAu;
        }
    }

    if (YLHIKdZtDlucFTu <= 449905.01284107525) {
        for (int mnnKhzQspucnhZik = 1795081582; mnnKhzQspucnhZik > 0; mnnKhzQspucnhZik--) {
            uWutyqElnvFnJHz = wwZMeXAu;
            YLHIKdZtDlucFTu = vBWjKBR;
        }
    }

    for (int UKJICaXrBR = 455735231; UKJICaXrBR > 0; UKJICaXrBR--) {
        vBWjKBR = YLHIKdZtDlucFTu;
    }

    return vBWjKBR;
}

int dFspv::HzLNaYok(string zqlUGnNg, int tfZJaBk, bool sfkNJ, int LfVfmfACPJsmyOS)
{
    bool FsWXsokLQFr = false;
    int FQrkXYuNK = -1244600330;
    double SokoBIXWyBVNkR = 56815.21328678821;
    double afDYmatbXWzVZ = -747136.3954327357;
    double boGvWYGz = 499113.9593863679;
    double AchavKUvrrMBoi = -702608.7395915462;

    for (int OPdSjYIC = 1070208212; OPdSjYIC > 0; OPdSjYIC--) {
        continue;
    }

    for (int BWdeV = 653096593; BWdeV > 0; BWdeV--) {
        SokoBIXWyBVNkR /= AchavKUvrrMBoi;
    }

    for (int RjuGouRfvCwx = 2133198252; RjuGouRfvCwx > 0; RjuGouRfvCwx--) {
        afDYmatbXWzVZ /= afDYmatbXWzVZ;
    }

    return FQrkXYuNK;
}

string dFspv::MZnaxNQpKUBozHa(int LVmGGXiHUb, string jIyvaOhwdhEUNvaj, double whEQzSoSxXoJj, int ZHZZuccJG)
{
    int QtLBkrAMwus = 1099443820;

    if (whEQzSoSxXoJj < -908480.9694151852) {
        for (int jUWeMcOJ = 42203623; jUWeMcOJ > 0; jUWeMcOJ--) {
            LVmGGXiHUb /= QtLBkrAMwus;
            QtLBkrAMwus -= LVmGGXiHUb;
            ZHZZuccJG += ZHZZuccJG;
            QtLBkrAMwus *= ZHZZuccJG;
            whEQzSoSxXoJj /= whEQzSoSxXoJj;
            jIyvaOhwdhEUNvaj = jIyvaOhwdhEUNvaj;
            LVmGGXiHUb += QtLBkrAMwus;
        }
    }

    if (ZHZZuccJG == -21047384) {
        for (int DJeEDiJ = 241456785; DJeEDiJ > 0; DJeEDiJ--) {
            ZHZZuccJG *= LVmGGXiHUb;
            ZHZZuccJG *= ZHZZuccJG;
        }
    }

    for (int fIEFoMqXruMcaHUj = 590192899; fIEFoMqXruMcaHUj > 0; fIEFoMqXruMcaHUj--) {
        continue;
    }

    return jIyvaOhwdhEUNvaj;
}

string dFspv::WRWlFRSAJJS(bool omampzvxSvJj, double psaUl)
{
    double oxPDSyfGGzXBX = -523635.1964421295;

    if (omampzvxSvJj == true) {
        for (int purOirPfUBlFFjm = 1389366270; purOirPfUBlFFjm > 0; purOirPfUBlFFjm--) {
            omampzvxSvJj = omampzvxSvJj;
            omampzvxSvJj = omampzvxSvJj;
        }
    }

    for (int JrfNrh = 620799051; JrfNrh > 0; JrfNrh--) {
        psaUl *= oxPDSyfGGzXBX;
        psaUl *= oxPDSyfGGzXBX;
        psaUl /= oxPDSyfGGzXBX;
        oxPDSyfGGzXBX += psaUl;
        omampzvxSvJj = ! omampzvxSvJj;
    }

    for (int dbMLsm = 1883660943; dbMLsm > 0; dbMLsm--) {
        psaUl = psaUl;
        psaUl -= oxPDSyfGGzXBX;
        oxPDSyfGGzXBX /= psaUl;
    }

    if (omampzvxSvJj != true) {
        for (int aaHIEwNuqAd = 2080164320; aaHIEwNuqAd > 0; aaHIEwNuqAd--) {
            psaUl -= psaUl;
            oxPDSyfGGzXBX *= psaUl;
            oxPDSyfGGzXBX -= psaUl;
            psaUl /= oxPDSyfGGzXBX;
            oxPDSyfGGzXBX += oxPDSyfGGzXBX;
        }
    }

    return string("JUFojixOwuMdHDfJeKTOdDAzazouKWNJULdlKQbpgDsiyMdfrrflJfFVmrQPBgXbukInWWkWnFKwDkOgydnYrSSmyIGrPafuzuvDYPSAZgHPMkjySCmOgNPjAUUmEMFKVZPQRadWPAuyoTliQDJuTudpVUvuMscvcrQOGgeqRpQiLecfqKVAHPDcazFPyvbVhuvLaNmNGccKRCcKLnuoLFemYMhlhpOZkrLmEELumkqWat");
}

double dFspv::OzQaUkTNnZQK(bool XsSShyCYiTd, bool DftClQmJGm)
{
    string ITsLES = string("MOinhyqDFCtBNcJMNAZSuHCjqVSrVzZbhELqOVhxpCjPUAOWXjupLcMDTLnHmfHrkZNJZWjAnkpgJKKNjoXPFhhuuwKAeQcDcQpSrikoiJpGLWtINfmaBVdzRceKwIyKnDrHdhLFEwiGtetTzVvewIXHLjUQbTikMnCgqOPVMswftCgWlaSgUstPRJiACfHwACMitBRevVxaveMlDMThxIMdfflFixmAJOedYNxeL");
    int QknphdooQXlT = 1861888753;
    double KcIycq = -362589.7430523963;
    string smmRurnrvrCh = string("HCpBLmKCJjlHiMOZFuNOhCJpfYaAgbQRotknYfylZEtFrtIPvLRkkSSmMkzFXXCsBmwtTqMjGHeWsYkQngGTbPrxKnWUluAsJCioTCCmTlWrDYkFzJpvdGCoYLvTqufZETAZTnGQpgLTkNnPEkMUtaVeZUEyXGewJdGOgWUoNpAAqSKKOophzZgBfrbnrEDrrNkGbuGrICxSyoceSfOEeRcsplLhOSpHTjvboSkdxoIfyVd");
    int vbzoeIzcglOn = -1757806199;
    double YfnYb = 206948.88514614856;

    for (int SwrIz = 1556758194; SwrIz > 0; SwrIz--) {
        ITsLES = ITsLES;
        KcIycq -= KcIycq;
        vbzoeIzcglOn -= QknphdooQXlT;
    }

    return YfnYb;
}

dFspv::dFspv()
{
    this->mqtJBPLk(true, -945272049);
    this->FmJoAPj(-373650.01270763867);
    this->PESwBGVuHkrYag(false, true, string("KwmHOBEMcOGracLZHiOnVczEyimDuYkeeLmtKqgvPVCLNf"), false, true);
    this->kAFYToQEVznUgv(string("JAMSdefNZvoEwTEOgxgNuXKMybH"), -247820.12988311198, string("HESDVniNhajXaxqGIwIpIPzcSUBfBjxLvjJOLdsGzDSTuGBywleJswPKruJlxlFyShZsVCiAkJhXdesTLQQJbqZuKBxvgHSVnSTeMyiJgPlHueWXEnjGdXDVuShAstZzDzQ"), -1904292498);
    this->oaJQtYJEK(true, false, -441198.9666789314, false);
    this->JwHHygDomoJKffNu(1407371788, string("enDuSaCtmbXHyYUNzShuGAMyiXYVFSeBzcLITKkakjEGRtdQurcujAyXPCqsuYySQeaTycLwkwtBgGtYEAxoRZEFDNZZZRrGUwPUhZiudVXcArwtrkgBzQmBVROGmyiDAzvwaaCxucMySrzKbBTGtztDwednOXDWAzQiAlvnCxLhgiNpKn"), string("ZJsToGswDGXEwvlvdMkkbHOyXHsHnxTuEMbxzJRIWFvIVKlOBubeWDkpvwRGpUanmFOpiVcsOfGdoSNDQpnLbFtGjTAVOyHWDtjGRQwlQvNgNckVLqzssXtPpOoAbNUNDPDijbCPKwxFkQMqjtzdshlcmqbVDN"));
    this->BkNPAoTmoouqEO(-164402.47640305647, string("NYCfyKdkzaIZZvaChvqqptPXfAzHgiahinZuyirJgUFkdkxGZfNQVBbNLYkqjjrhkkKnHfhCXICzFmnHElQipwCtNqWHtaPNfVgKvDFfxtWxiXHBQYLIpoJZvVrnxgwyjSgJSBHjSktlWmyqjllHaNHmlPHeaRwJWrjtXwetjfsrtzzpflTKZEbKJNKtSmtuFaJTCkNvFoSZrKiLqRTqVdSLwGhEWKmmBRrcHfZzNnbSRPfx"));
    this->REuxu(216439.65350413008, string("WiDGhmadeysgcviqqhFrOzaNekYtvMdTLvdcxGHUWzbceBdJXBdRpvGw"), true);
    this->gNteLKFrthkMAk(string("UOwJnnXlkIaDmqPVBIHbIGjcYoGjLKESGHkotTqXAsOQLVCnflIdAS"), 1911745515);
    this->zHPihzBxAVYEIB(true, false, false);
    this->FDYfaYdXdDZRxygp(true, -151745.678105698, string("LTGxAZOSSNWiSXjnWWbsFGXtsGPVWCngjSIBYdhLitcLmevXlRcFzlwbiEYitzgLWMqErUCnFmyONTjcmdaCIuFmUV"), 776756.0175574324, true);
    this->eAOMStDx(860764.1360378863, string("HLLXufUKkLWoLkGXAQhcwzHHrSZttyoEFzlxcPiISTwvFjVCZgtKBmHNsWUgyBCeBUcEhQytAlfFQRoSACleEcSetrRLyDRpqMpmHhXPVxPyzglgphjVcFtBsTzSQlBCCXdWzplZmbc"), string("CWgfmwAYbBkbwxsSKikyGYeWgGuuvPSaTEuiSGJDRUElMQVbSXLMz"));
    this->HzLNaYok(string("PuRLVWmvcPXxJVZnINEgAuqTnJOcZCtloIeXlIqbUvJt"), 1215096146, true, -304616195);
    this->MZnaxNQpKUBozHa(-145534519, string("EbdoyFQHZVpGcSZQvckXzVUJZGJjJBvThdlIdSuLeQfXPFUYUbVajgoDoKKZLqlwQaHmXgQRHpjjHYDQdThalfGSIXxZKcvYVwGjgTVRIOwcGHPFAiPhpmmjyiJCevdpjesAvcegMvyiaGgJcNteSuYuLGoXfWQNZVygCwWhOiz"), -908480.9694151852, -21047384);
    this->WRWlFRSAJJS(true, -926135.9882374023);
    this->OzQaUkTNnZQK(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VctUIcoOhDmqjFRJ
{
public:
    string eaSrMAbdWOG;
    double rfzozVdKCErftJpw;
    bool FLGycLvTh;
    double ABvPrZa;
    double jBnBizGh;

    VctUIcoOhDmqjFRJ();
    string liKgE(bool rwJwMhP, int FrYursnTIRIaYw, string VyYLPHdiFvKRR, string JLKbIDGSwpVncn);
    int YamdHtOeGcqyXXa(double WTnXKBbJGoQ, double tFMSWQmzxQ, int UyYcecYC, bool JVBdWjETVAk);
protected:
    double wrcnWPEE;
    string tqgZlbev;
    string TTxTSKTCMvE;

    bool kauunCBqgM(int QmSULnEaBQy);
    string cVWLMIvdAH(string drlRR, int PAHDfSfIxR);
    void pKKdCEJTwYEkjc(double qHFxBPIiU, int HwRYZTSlgmCx, bool uTvmUcNvR, int gSTLod, double SbCGyEuw);
private:
    int pMwWCBTioQsQGg;
    string MLCtWQudZqsrUEQ;
    bool NOstuTETlV;
    string dGaOcOW;
    double udceFVzZnZUkKdu;
    double nugZv;

    bool NsOIYISrWuoTPuq(string hHBNLTSKgD, double zOnSvJMFdQvvwTE, bool sOxsiIJjtDXpZIpc);
    int LgBHzjmHymFIk(double MzNjEJ, int vFZmuhWXqqPF, string VGAUHQfhpEyFMG);
    void SGvEpfLuIoS(int TaSWiqbYXPKn);
    double FWawKxKcbh(int UNYKQohgDQ, string MaqWYPXkAWp, double LOLTAbgtUjeuMeFY, double xQjPITeN);
    double xDCmRuaVd(int tVfPmGZe, bool CcKpXrx, double AXMkaGndeOdPR, int NCPUPgahdGAw, double jnodkTC);
    bool ACIYAevMo(int VoCkZkNtCZ, bool QrLjX, string bHtIkr, double klmCYtHJZUa);
    void WbkvjUpuEJkVtqTG(int xNfEEUMBtMbXeq);
    void LwgacI();
};

string VctUIcoOhDmqjFRJ::liKgE(bool rwJwMhP, int FrYursnTIRIaYw, string VyYLPHdiFvKRR, string JLKbIDGSwpVncn)
{
    double GIjUQFOOKovB = -916680.6586155342;
    string JlhzQYgZP = string("mJCQzvoXcOPAMshXBwqUpjANJfBamQYIFMSJOdnqbTUgGptFKHbLtiFWEyuKixsYxpkIaPLWDSPqEUwbpzHzXwATVlYIHvpamxhlKTOZNMFUVQoHB");
    string wCRkzm = string("gGaPbqSYLogUlGZyHchkItHfANKyfmgpuXJcxdlHLEXZWlKUfKHziUagtqKQxWvnfSqOAWwYDCGpdaOtGHoCSeDwEKQyUSRpaOUlyeAeKkcheYRkIosoynvoDKsHHxGsVOCrlVduqtjrwEwKNBddOKIshHkLyYfaAhyDuyHbTfLGIlvHaQRfJXNzOoLDgpVWzZMWPbeEUoRWYqhmdMuJIbwRSEEfNTtSmXRbOxRqlTiiYXgKBqRQYf");
    string Bmddp = string("ZatqIOBiNgRNnuYfFOwbeFRSJJAEAXTffXJalgiofzRXUYtqqNYeIDSLNhxMWlCjRCaBRKGCQsJKyUWgLwsyuZbchioyYqzkCIvwuOIslvoNRcJcEpKbotMyVBedMzSvkaWPIIXntxj");

    for (int xAAoZin = 213421658; xAAoZin > 0; xAAoZin--) {
        JLKbIDGSwpVncn = VyYLPHdiFvKRR;
    }

    if (wCRkzm < string("uplqKgEsitCYgZZhtsUORobJOKDqjOVldpQMsgvxcUSYoHCZM")) {
        for (int ahvpculkorNydc = 1538968479; ahvpculkorNydc > 0; ahvpculkorNydc--) {
            continue;
        }
    }

    for (int lAuaVt = 2014584497; lAuaVt > 0; lAuaVt--) {
        JlhzQYgZP += Bmddp;
        VyYLPHdiFvKRR += wCRkzm;
        JlhzQYgZP += JLKbIDGSwpVncn;
        JLKbIDGSwpVncn += Bmddp;
    }

    if (Bmddp == string("ZatqIOBiNgRNnuYfFOwbeFRSJJAEAXTffXJalgiofzRXUYtqqNYeIDSLNhxMWlCjRCaBRKGCQsJKyUWgLwsyuZbchioyYqzkCIvwuOIslvoNRcJcEpKbotMyVBedMzSvkaWPIIXntxj")) {
        for (int cuZmjL = 529767594; cuZmjL > 0; cuZmjL--) {
            JlhzQYgZP += JlhzQYgZP;
            wCRkzm = VyYLPHdiFvKRR;
        }
    }

    return Bmddp;
}

int VctUIcoOhDmqjFRJ::YamdHtOeGcqyXXa(double WTnXKBbJGoQ, double tFMSWQmzxQ, int UyYcecYC, bool JVBdWjETVAk)
{
    int ETlHPmKfDDMAlloV = -953412132;
    bool mNcnK = true;
    string ACBVzdW = string("aFKerjgtzmrBuaTGLABJFWQarykYjTyIAWZJasEIakBLolgmthLJfyzsWEnvpkyyLhXFvKTfnTIJFtmZDgevDZABKiCDLGJCQlgIRokLbbUGAuhZvgxpCxOhyuJFIcdhOhmqQEBbMyZnAkNnGsDsMMutfEFqQrGq");
    string nTHSQYCUN = string("BjJlIzQLvOtTJwBxqIOftIcnNsIylbRMJSDDwbZCwGctJhnLUwVXpcloxwbAxeTYrUaRUmPuVdABDbnGdUYHxEuBefSZuvZlvjaTBeicGFjdhBqouJLWVzbrdEjxDAXlTEuMoaPuCFKnlPrOXAzUBHVZKzPwVeriqaKYOSWdvoKhYjFXv");
    double WHsQqVqFf = 320119.56666925794;
    bool GEVWjJzOaw = true;
    bool BcPbieKMLEa = false;
    int ETFCLTrhBPU = 517811900;
    double xVFQNscq = -249103.6666893119;
    string HoUpRNtAoObYMC = string("lzgALPXxIKwITZQTeTaZyyabBzEslIiHWypXqYfHJHZ");

    for (int SYVTQKSmRPZYZP = 1895970195; SYVTQKSmRPZYZP > 0; SYVTQKSmRPZYZP--) {
        continue;
    }

    return ETFCLTrhBPU;
}

bool VctUIcoOhDmqjFRJ::kauunCBqgM(int QmSULnEaBQy)
{
    string zvJjn = string("BBvhjeOrXyxswmpFWsKCVFoXdaEOAavSGCiBAOWLcpRahArxwsYJHLzLVRaTVaJrCicpeZcGCafUBZizDJNhmtALomzOnYuMyTJvAaMQwXyIjh");
    double SbrtVlRo = -906523.4909360389;
    int haqHmnLrIZyQupT = -1710690146;
    double ydJjaPyr = 361341.56755270384;
    string yyYSaHkW = string("IygUVurwGzaLTgGthtdYwSNltZNLuQmQBjZpACUKOljoDXryzZQFzxkSxIRaTECjsdZDtUPDFnNUGJHSrVIkZAHkwVkndfhIDIWNlpNrKilDOpNKrZPToGPGdNEEzDmtPOXATdMWE");
    double epKQKPJFQRXHFKtX = -364474.21361504804;

    return true;
}

string VctUIcoOhDmqjFRJ::cVWLMIvdAH(string drlRR, int PAHDfSfIxR)
{
    double fofhcI = -864684.3108728154;
    int tIGmlgPFj = 2082669322;
    string wtOrwVTqBgre = string("RKBnuZKrbXpNmCbTsppYIBtlBwSXdyssDiUiUNDnktitYpYUqHvYediloPINFOOHOIPxVfDmPbVHHZDACrUpDZPRYzwhAtrgIamUMvVEYNJZCMbrLGrNAPncBVqiyZbXmGqEHRSpldRSbPEqcTcmYfutoXDzxzOgTgcOHloaCJbtAXTbGKveYsSwWDJtKxqtPolcjjqlaZwqgKfBpaFLYmLDsO");
    int BFeZNt = -921442930;

    if (wtOrwVTqBgre == string("IquzDQyDgCrBhmeWDuvGxwXTHIkmwuwuGZLWoGKWhAvpETqMdRxhgkpRXTZnHjuxMANdvNpgVXPALvVBurWwkSSmRWKAeMbjiIeWCFjxelzXqtOfLbdcDNXBJLfZWPPMeMaVBQnLCUfjPVCGyQrgWjCybNPagDmFKchPNhsENYeixPvwSaIqBQLqmMRAjIzgBPduHujFpBFkUhvkZJqYgkzypmZrV")) {
        for (int OoePKkgm = 2081146767; OoePKkgm > 0; OoePKkgm--) {
            drlRR += wtOrwVTqBgre;
        }
    }

    for (int jvQZsIlU = 981166402; jvQZsIlU > 0; jvQZsIlU--) {
        PAHDfSfIxR -= tIGmlgPFj;
        tIGmlgPFj -= BFeZNt;
        BFeZNt /= BFeZNt;
        fofhcI -= fofhcI;
        tIGmlgPFj = PAHDfSfIxR;
    }

    for (int wfJSD = 526322543; wfJSD > 0; wfJSD--) {
        wtOrwVTqBgre += drlRR;
    }

    if (tIGmlgPFj >= 1567900442) {
        for (int ydfYrwQKMuoYvB = 1926424536; ydfYrwQKMuoYvB > 0; ydfYrwQKMuoYvB--) {
            BFeZNt += PAHDfSfIxR;
            tIGmlgPFj += BFeZNt;
            BFeZNt /= PAHDfSfIxR;
            wtOrwVTqBgre += wtOrwVTqBgre;
        }
    }

    return wtOrwVTqBgre;
}

void VctUIcoOhDmqjFRJ::pKKdCEJTwYEkjc(double qHFxBPIiU, int HwRYZTSlgmCx, bool uTvmUcNvR, int gSTLod, double SbCGyEuw)
{
    int nkrTshUHBbR = -1549905021;
    string jHwoGqsMOm = string("YUMzUpirzQiSgQccxFfSylxvhdtILqrwWMQPWqzVBfaOpVZkJfbxQOTe");
    bool WuwOfS = false;
    int CHBBhyBVt = 432359468;
    bool AuKHx = true;

    if (WuwOfS == false) {
        for (int ukSYSjBVxCI = 588105877; ukSYSjBVxCI > 0; ukSYSjBVxCI--) {
            uTvmUcNvR = uTvmUcNvR;
            nkrTshUHBbR -= CHBBhyBVt;
            SbCGyEuw *= qHFxBPIiU;
            HwRYZTSlgmCx = nkrTshUHBbR;
        }
    }

    if (gSTLod == -1549905021) {
        for (int xUgQAgiiA = 76571424; xUgQAgiiA > 0; xUgQAgiiA--) {
            HwRYZTSlgmCx = gSTLod;
        }
    }
}

bool VctUIcoOhDmqjFRJ::NsOIYISrWuoTPuq(string hHBNLTSKgD, double zOnSvJMFdQvvwTE, bool sOxsiIJjtDXpZIpc)
{
    int ddbaocjJK = -1184502740;
    int RPVGJwFW = -1392946937;
    string YRhBGmPSloeeBr = string("aSuydBPpMyBCnXxjUjzBMacnvecyQLaWIPhXlaYOQZupfNMZNRIGBEUcNgkSlHRczZMZXBtbCBfSLGQWtFfOJjRVkRMgqZbFYzBbGnrSYQMJGVTvFzmKWAAMwmAZZVDCfGfkwfENwSDPeWQqgrVItpOGagCqhvLTfdLYYPiaVOoRidqqslrYDNzdoGWEsFPiNkZCgHOWtKEHAiTmsVALtvQUohDHCldOgwaMigN");
    double TWHJgoSLWjoG = -637156.8626543673;
    bool VSYEjEYonbAxJ = true;
    int cNHjDftXluwBWIst = -1639670377;
    bool QOZYkHycfG = false;
    string jGltlMbyLtlOIdr = string("UetjYxxJvgvAHLGfxdmgkmtPyyRFEfOoBGTpwECyVFTfUfPtrBVDgruyhcGgctOKbfWxbtQLlEunlbgWmuAnYcGwbDydIzwVCrdlLJL");

    for (int EXdqcrUssCnFn = 444526522; EXdqcrUssCnFn > 0; EXdqcrUssCnFn--) {
        hHBNLTSKgD = YRhBGmPSloeeBr;
        VSYEjEYonbAxJ = VSYEjEYonbAxJ;
        hHBNLTSKgD = hHBNLTSKgD;
        cNHjDftXluwBWIst /= RPVGJwFW;
        QOZYkHycfG = sOxsiIJjtDXpZIpc;
    }

    return QOZYkHycfG;
}

int VctUIcoOhDmqjFRJ::LgBHzjmHymFIk(double MzNjEJ, int vFZmuhWXqqPF, string VGAUHQfhpEyFMG)
{
    bool qbSzou = true;
    string dpAGikWEPmwORO = string("hoFwQGtqFGDSvYQthpBVGytaraEsvNLvUUNoZPjzDunEtJRInzXbyOIiAbQwDQFJsnrZUXfmyVYjDWWFygwhmPvxLQQshSzRzecpaouYbvpDaLaDFRgmuBnJkAOwIkTQyKGwFLnxMqtUJzXRTIRSFChEisgXVzDICqKoqDljvnZaWwbbUDtQnFcFrS");

    for (int hZQhlJqlChHLoso = 2086111623; hZQhlJqlChHLoso > 0; hZQhlJqlChHLoso--) {
        dpAGikWEPmwORO += VGAUHQfhpEyFMG;
    }

    for (int WjNrTa = 1832337280; WjNrTa > 0; WjNrTa--) {
        continue;
    }

    for (int eozsPzaVvAE = 510323852; eozsPzaVvAE > 0; eozsPzaVvAE--) {
        MzNjEJ = MzNjEJ;
    }

    for (int ZHsaiuga = 1097114676; ZHsaiuga > 0; ZHsaiuga--) {
        VGAUHQfhpEyFMG += VGAUHQfhpEyFMG;
    }

    for (int qFgsCLuruCcmaUnR = 1933207591; qFgsCLuruCcmaUnR > 0; qFgsCLuruCcmaUnR--) {
        vFZmuhWXqqPF = vFZmuhWXqqPF;
        VGAUHQfhpEyFMG = VGAUHQfhpEyFMG;
    }

    for (int XXEGLWzOpEiX = 576554976; XXEGLWzOpEiX > 0; XXEGLWzOpEiX--) {
        dpAGikWEPmwORO += dpAGikWEPmwORO;
    }

    return vFZmuhWXqqPF;
}

void VctUIcoOhDmqjFRJ::SGvEpfLuIoS(int TaSWiqbYXPKn)
{
    double UKbDTglWAD = -402178.4690150537;
    bool nRRRREqUZblq = true;
    string FLvTVQiw = string("EELxqkXrMZBMjyOWWXRTjxMrBozAdZSvdUsHlpkSHEzsfoAOxzvlsIWVUDKDDLIqltILhvwljgcDRbFxkuiLwbihootPNSxUNlRWWqnOXcRRMnBADeIczIZCkrGRnFhnISOZBNjrbzldPltXBIEiULBMzkmjCoBIfeOoKgCeRVPGKttBxKgpsgEbMPGktcHbDXmaYsMCHWRNXGjkMecIrudppuFnetSOOOTqzfDuHGIyuvUqexVwnhSyf");
    bool qCaBcCG = false;
    string eGuUYbGmskAF = string("LJlixLbnUOrfJvgwrnFWYNeoJtONYcxcfScxnIjERhDmhlhUtkkpSWzxLJhTMyZjnMZUCQgqtSJJXjdQxdZOiozvDebITfNGDCmaEmFCCcrQzTqkcpEifrnHuONTUZFNHptkbIaILzubCMgBPjxUbeTmEEPZSbqHwFEuInbubDUGVHuxbwLLghxzqkzDSNSJtRlksdfyKdesxNHlbZwNxOiuX");
    bool IdLDnxhogjpTXjs = true;

    for (int KhePchaXSA = 1333903046; KhePchaXSA > 0; KhePchaXSA--) {
        continue;
    }

    for (int vThehkvHV = 1211920880; vThehkvHV > 0; vThehkvHV--) {
        UKbDTglWAD -= UKbDTglWAD;
    }
}

double VctUIcoOhDmqjFRJ::FWawKxKcbh(int UNYKQohgDQ, string MaqWYPXkAWp, double LOLTAbgtUjeuMeFY, double xQjPITeN)
{
    int lfNhRVZOIQbfZVKw = -2053689178;

    if (lfNhRVZOIQbfZVKw < -2053689178) {
        for (int dLHmxUFRxku = 1543148378; dLHmxUFRxku > 0; dLHmxUFRxku--) {
            MaqWYPXkAWp += MaqWYPXkAWp;
        }
    }

    return xQjPITeN;
}

double VctUIcoOhDmqjFRJ::xDCmRuaVd(int tVfPmGZe, bool CcKpXrx, double AXMkaGndeOdPR, int NCPUPgahdGAw, double jnodkTC)
{
    string sqYbybKGOQhahNqr = string("AGovXmNFlxiOhQLxKZeAbVRIxhJoNeLGpcLNsSSFeyVdodZdpIwPpjPwUoojWaWgpIyNskGUmIPnYKwUWakJqiAjOVcpQqSfmZPHIZnBwCcPyqTAwELciuKDfLbWYeSxLIoSIvLpyzLGVyptXfKMogCmAYFyuYWazEBbjVpINUHMmtREBpJDsVaJWeuqtrvUNKbHVAXVgWcZJaiBgjuGqihvZaTFztiXSwsiEKCxAsmZNgbxm");

    for (int oNRTeSaTtgYaSng = 559988825; oNRTeSaTtgYaSng > 0; oNRTeSaTtgYaSng--) {
        tVfPmGZe = NCPUPgahdGAw;
    }

    for (int EhfiypSpywtzzYes = 126001277; EhfiypSpywtzzYes > 0; EhfiypSpywtzzYes--) {
        tVfPmGZe -= tVfPmGZe;
    }

    for (int aIgklTg = 959703740; aIgklTg > 0; aIgklTg--) {
        continue;
    }

    if (NCPUPgahdGAw >= -1391017081) {
        for (int mlfjd = 742921159; mlfjd > 0; mlfjd--) {
            continue;
        }
    }

    if (CcKpXrx == true) {
        for (int cfOgP = 1747421767; cfOgP > 0; cfOgP--) {
            NCPUPgahdGAw += tVfPmGZe;
        }
    }

    for (int dggtuWx = 790764491; dggtuWx > 0; dggtuWx--) {
        jnodkTC = AXMkaGndeOdPR;
    }

    return jnodkTC;
}

bool VctUIcoOhDmqjFRJ::ACIYAevMo(int VoCkZkNtCZ, bool QrLjX, string bHtIkr, double klmCYtHJZUa)
{
    int gLqRNPrbuajnCt = 407111083;
    string wQncgUVPIWp = string("MepnuCZPHyFvVVoBSOxTZVuSicWGnqDHtkOzhmxXnXypDqAjfFmwwOZheIxoyBEMmktRKKLUgwBRSHJXpzPSyRDxrsmFAGFjftKXaUddNBumD");
    double ejDZTNJTBAJS = 516212.01323341083;
    double lgMsglhNUkVOlkJ = 220339.61464726727;
    string rPwaQkMbqBZUMHp = string("kEZkNLZfhtcUnqNauzDQabbpoMpnFdvHDSzyyxerkdWDabaEpLucfkJJLOymtUHiIVmcoZYYgcxoCoioYeYTuTskqZpEWhekmAhJoZpaAZIAtuWGranHMHTmwTsinoszfGsuFyWwRXrGGGpKDPrnkRiMuzjz");
    string bGuApqGnRKp = string("KWJvkLHaGQYiBkvUFRNliJBBiOIwYZrBNKNOXqmfWtuHJFgGBttLvsAQfxwGJPJGjKebwGVuorHlvkWJmKaeurlmLnSAEXY");
    int dfKHiR = -2130523693;
    bool tSfQJ = true;
    int bJRffiglvOmTx = -719459754;

    for (int uyZiiQoqRVNWCh = 1322952362; uyZiiQoqRVNWCh > 0; uyZiiQoqRVNWCh--) {
        dfKHiR *= gLqRNPrbuajnCt;
        bHtIkr += wQncgUVPIWp;
    }

    for (int syGssCty = 1994721853; syGssCty > 0; syGssCty--) {
        VoCkZkNtCZ += VoCkZkNtCZ;
        dfKHiR -= bJRffiglvOmTx;
    }

    for (int EpATG = 1619967304; EpATG > 0; EpATG--) {
        continue;
    }

    return tSfQJ;
}

void VctUIcoOhDmqjFRJ::WbkvjUpuEJkVtqTG(int xNfEEUMBtMbXeq)
{
    bool nKdHIUNLPjwovpP = true;

    for (int gbOGEJNrCJLs = 1362937807; gbOGEJNrCJLs > 0; gbOGEJNrCJLs--) {
        nKdHIUNLPjwovpP = nKdHIUNLPjwovpP;
    }
}

void VctUIcoOhDmqjFRJ::LwgacI()
{
    double nrFApZmOdkheeXNM = 909498.8371615268;
    int bijPLjv = -1282055003;
    double vZHtrEJuNkK = -626255.3280530203;
    string ZVDctKvyQKHKrck = string("ZnYWbFgfqRdb");
    string bBTCyaBLqvRd = string("HODDtLUkeIcVWXhAObRZeosYfvrgwMWsUJaSBOxALkmGLkPRvKasHlJjTiwPxTyukhsOXmPmLshTObsjEfXFonEbXHmZBDwFeKJYvCqdDLuNsyZxRzlsUZbcJQwzSuTDJJMwviPDqcHUQTKNCPGUBhWMWRbaHLvjtPZWnbrFGhROSoELWaBGsCtOswUeRGefQmEMWNNHQKSxpJ");
    bool JnsFazEl = false;
    int vPbZcIXCjcswJ = 122308254;
}

VctUIcoOhDmqjFRJ::VctUIcoOhDmqjFRJ()
{
    this->liKgE(false, 383983107, string("SAFPpgZtjyLOUeOiFLnYadiPtgDYxjyXAeSMVqVuLuuiQovkKDivuxMaucxntBlIDFzhfEcegxyFokabNkhpEtUjCnhCrrGAIzBafYaRABXrzeZCfjUiiMVFGPJXFkUUAHbHmNHpErfvyMYJZduWWGSLjDZAZzoxrkTnsTgmiAtkivzsBXxofcmIlqMIdrzIqEkukFmXGDDtOHXlr"), string("uplqKgEsitCYgZZhtsUORobJOKDqjOVldpQMsgvxcUSYoHCZM"));
    this->YamdHtOeGcqyXXa(550841.8931172441, 530278.1128469453, 978422673, true);
    this->kauunCBqgM(1564441372);
    this->cVWLMIvdAH(string("IquzDQyDgCrBhmeWDuvGxwXTHIkmwuwuGZLWoGKWhAvpETqMdRxhgkpRXTZnHjuxMANdvNpgVXPALvVBurWwkSSmRWKAeMbjiIeWCFjxelzXqtOfLbdcDNXBJLfZWPPMeMaVBQnLCUfjPVCGyQrgWjCybNPagDmFKchPNhsENYeixPvwSaIqBQLqmMRAjIzgBPduHujFpBFkUhvkZJqYgkzypmZrV"), 1567900442);
    this->pKKdCEJTwYEkjc(-136322.38251497506, -1878329266, false, 188397511, -940244.04018617);
    this->NsOIYISrWuoTPuq(string("bcoyRwMdyoWJoAphrXisooLoLEsoCMxRWNgEboxOwTtKpXSldNcjqbNSmckfGdymDDVMJIjTdVzkXuakriBkUrvRSCwvMLzmqHnYek"), -701839.8624465091, false);
    this->LgBHzjmHymFIk(878767.7704620662, -469977844, string("KLQcZXiMseabGSvoHZVkjXoysRxGcEVOZlqMwbbkSskWxZTwuXCfCLRPodmSzpHHCQlDDz"));
    this->SGvEpfLuIoS(-2040229985);
    this->FWawKxKcbh(1632687554, string("kJFLEVMRTpsbMsiNGYnipnmeVNANhXzFbiCOGwzsdESfnIOzufca"), 676439.2995677923, -748474.4337238257);
    this->xDCmRuaVd(1258147964, true, -1005485.1887151635, -1391017081, 854285.434409214);
    this->ACIYAevMo(1292955162, true, string("EaaYXjxHTZTAzKlTzbIRNnEjGqZWOooCiaUMxbuXaUtYYMaGmXNpVoSMvRJjakjtEQDPaMhkbgWQbNcdisHrVCjfmzRQJAYKLlwfiDICysiXvSBvPAkHqczPnnyTwFVfqTsMncOeQIUAFfZUSgBgiyfOQeNhkJkzWeZixfQpqjqPfWRSMpnupejTbOztJaMoBbMZPBjWVkqOKBkPcojAlZuS"), -352808.64876844373);
    this->WbkvjUpuEJkVtqTG(891953381);
    this->LwgacI();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cmKzpGlQp
{
public:
    int Eumhw;
    double XhniwEn;
    double dEJEGckyK;
    int PfuWthyFH;
    double xRammJyrqVcHzKHC;
    string sXvdp;

    cmKzpGlQp();
    bool UiuxrBcaVAVv();
protected:
    bool LKNtDCXrTB;

    void EYlEIuWmGjKu(bool cZVjBVasmxzC, string NVyTwKeUrONOoX, int PvlyyX, double bqJABMnSX, bool BIFxH);
    double WZbUYkHtCLCCLrdd(double fELDr);
    void HeadPVo(int xTBxJjyviMJV);
private:
    int ayiLG;
    int UENzXW;
    int iZfbS;
    int mEBEekw;
    double ajjZU;

    int rQUdgb(double HrPFugHC, int huIydDxsHw);
    string JYdeUfrOeG(double HHlmAo);
    int AiwLjqzwpGsWhVv(bool xYJbRDiqZHi, double slQsFTFyGyFOhId, int ddwhizqcDLSXGT, bool UBfllM, bool mcoTNksizqE);
};

bool cmKzpGlQp::UiuxrBcaVAVv()
{
    int TCRDSW = -1847811213;
    int GwyBCrnKCmdQQz = 1383327423;

    if (GwyBCrnKCmdQQz != 1383327423) {
        for (int yGCDipLCR = 1433246737; yGCDipLCR > 0; yGCDipLCR--) {
            TCRDSW *= TCRDSW;
            TCRDSW += TCRDSW;
            TCRDSW *= GwyBCrnKCmdQQz;
            TCRDSW /= TCRDSW;
            TCRDSW -= TCRDSW;
            TCRDSW *= GwyBCrnKCmdQQz;
            GwyBCrnKCmdQQz *= GwyBCrnKCmdQQz;
        }
    }

    if (GwyBCrnKCmdQQz >= 1383327423) {
        for (int JjJzl = 1687452672; JjJzl > 0; JjJzl--) {
            TCRDSW /= TCRDSW;
            GwyBCrnKCmdQQz -= TCRDSW;
            GwyBCrnKCmdQQz /= GwyBCrnKCmdQQz;
            GwyBCrnKCmdQQz -= TCRDSW;
        }
    }

    if (GwyBCrnKCmdQQz >= -1847811213) {
        for (int cUYPwUmZrlTWThrG = 186553028; cUYPwUmZrlTWThrG > 0; cUYPwUmZrlTWThrG--) {
            TCRDSW *= TCRDSW;
            TCRDSW += GwyBCrnKCmdQQz;
        }
    }

    return true;
}

void cmKzpGlQp::EYlEIuWmGjKu(bool cZVjBVasmxzC, string NVyTwKeUrONOoX, int PvlyyX, double bqJABMnSX, bool BIFxH)
{
    string LAmbAvQDqgv = string("sxHCsbPEBgnknavsAcyirBpZKkovnkJhFOAMnOUFVamSLqnjDNQezocNyduuGEeXzuNIaOfYhzdAEkiuYyoUPJYqgaEhfLAblXcavWtgGUoCFESkBnkOwvgLHZldrsLG");
    int HNKBP = 2035829746;
    bool ptTDZQTRxDuE = true;
    string OvvYRMgpIWZpSVhY = string("gtIyfBSBeoOscfARwaudkVlOtwgeRGCXSGqDwfBgwJuehDEmVAeYFoRUiaoUeFeiHMYOUSlrolnIyliVSIRzMQvcjVLxjNsHJtGSUHredhUxVwnIZRpSkjckBuVHPcdBoLPAAhcknYLhYovUUytPnFinaxzXnFKCVGBI");
    bool zOOYOBOfcBFVXq = true;
    double iDFGkphtSLiU = -53658.04215867691;

    for (int NymyMCShdhp = 674840965; NymyMCShdhp > 0; NymyMCShdhp--) {
        ptTDZQTRxDuE = ! cZVjBVasmxzC;
    }

    for (int xsjbwgg = 1168714941; xsjbwgg > 0; xsjbwgg--) {
        ptTDZQTRxDuE = ! zOOYOBOfcBFVXq;
    }

    for (int GwJsUE = 888631705; GwJsUE > 0; GwJsUE--) {
        BIFxH = zOOYOBOfcBFVXq;
        ptTDZQTRxDuE = cZVjBVasmxzC;
    }

    for (int TCkjnTUJVcbMzVwp = 1275941150; TCkjnTUJVcbMzVwp > 0; TCkjnTUJVcbMzVwp--) {
        continue;
    }

    for (int IbCmSvpCB = 992673673; IbCmSvpCB > 0; IbCmSvpCB--) {
        PvlyyX += PvlyyX;
        LAmbAvQDqgv += OvvYRMgpIWZpSVhY;
        iDFGkphtSLiU += bqJABMnSX;
    }

    for (int WtPPyFALTeQXXbC = 62032252; WtPPyFALTeQXXbC > 0; WtPPyFALTeQXXbC--) {
        OvvYRMgpIWZpSVhY += NVyTwKeUrONOoX;
    }
}

double cmKzpGlQp::WZbUYkHtCLCCLrdd(double fELDr)
{
    int khdRTDlmdNSqlip = 1976138860;
    bool pKtOHkFxUizL = false;

    for (int AGBZo = 1221833446; AGBZo > 0; AGBZo--) {
        continue;
    }

    if (fELDr >= -157446.23242197165) {
        for (int AiASxQrDNUEVjxdC = 1908782777; AiASxQrDNUEVjxdC > 0; AiASxQrDNUEVjxdC--) {
            pKtOHkFxUizL = pKtOHkFxUizL;
            pKtOHkFxUizL = ! pKtOHkFxUizL;
            pKtOHkFxUizL = pKtOHkFxUizL;
        }
    }

    if (fELDr == -157446.23242197165) {
        for (int qbVJoRqHRNPzU = 477801740; qbVJoRqHRNPzU > 0; qbVJoRqHRNPzU--) {
            khdRTDlmdNSqlip = khdRTDlmdNSqlip;
            khdRTDlmdNSqlip += khdRTDlmdNSqlip;
            fELDr -= fELDr;
            khdRTDlmdNSqlip -= khdRTDlmdNSqlip;
        }
    }

    for (int gmTfGZWPITbuyvl = 790622261; gmTfGZWPITbuyvl > 0; gmTfGZWPITbuyvl--) {
        continue;
    }

    for (int txrqTImupTtIqFn = 2119509846; txrqTImupTtIqFn > 0; txrqTImupTtIqFn--) {
        khdRTDlmdNSqlip += khdRTDlmdNSqlip;
        khdRTDlmdNSqlip /= khdRTDlmdNSqlip;
        khdRTDlmdNSqlip = khdRTDlmdNSqlip;
    }

    for (int fVfEJrCV = 252862167; fVfEJrCV > 0; fVfEJrCV--) {
        fELDr *= fELDr;
        fELDr = fELDr;
    }

    return fELDr;
}

void cmKzpGlQp::HeadPVo(int xTBxJjyviMJV)
{
    bool GQxCOexh = false;
    int XiiQVNWdFooDTo = 1270306243;
    string qEITQAWOXRBE = string("UTgkrskjDsiStMvCAqDexWopfzifQgDySAqCnOLGQbLoVvAEpFwIJIaDQbxz");
    bool YXUplNE = false;
    string OUQFdKzXa = string("vHRAnnHzXzZosLmcrnzUdglrAtTjFTsROTQNlTInSfNLJaQxlYncslVjljmewJXAwWqrRAtrvOhAJbqTSlBuAWgzZbLWrqrLWeXjgDqucRCmgRKoyArfNPOmsjvPUNSsddxJRgjRZmlqhQbpQZXuyhJfyyqYXKgSmxTXGeDbIfXqfFPBcTLAoWAiPZjOHVzhlxaDVdoxPUBIgSYaIxfLsUFGuGsupCoriqXNarRFKMjKIbPFgrhNMH");

    for (int YyrBWzNsfJhnarRX = 501549544; YyrBWzNsfJhnarRX > 0; YyrBWzNsfJhnarRX--) {
        GQxCOexh = YXUplNE;
    }

    for (int CyYFAvnIQh = 1211975013; CyYFAvnIQh > 0; CyYFAvnIQh--) {
        qEITQAWOXRBE += OUQFdKzXa;
        OUQFdKzXa = qEITQAWOXRBE;
        GQxCOexh = ! GQxCOexh;
        YXUplNE = ! GQxCOexh;
    }
}

int cmKzpGlQp::rQUdgb(double HrPFugHC, int huIydDxsHw)
{
    double tRQVWWJFJbkHmfiv = 775708.483892261;
    double KKNLlYyZAUHszb = 54717.74890313323;
    bool yNnsWpZrczfFwyig = true;
    bool KxPwJp = true;
    string JiUAt = string("TiLeopQQGWSMfPxvbYleLAHyuaLowrjRUDEAtDGYXUCbEzrumNZfQHTkImOmGASEbLFsmJtnJESIqDJFBCs");
    bool aAVzxvFMxtCkF = false;
    bool UDwrfqHIVKbQK = true;
    bool DtWbiRwgG = true;
    string CBIbLeYHmCJhEfrV = string("fZysEwWfCQSLWFqkpUerxIeNTffhuqjsysLhbUxTRenSEZTBgto");
    int EgtWo = 821936288;

    for (int YtDJODFqUHjsCH = 415437822; YtDJODFqUHjsCH > 0; YtDJODFqUHjsCH--) {
        tRQVWWJFJbkHmfiv = HrPFugHC;
        HrPFugHC *= KKNLlYyZAUHszb;
    }

    for (int vemFVGxjFRTSehA = 1626299686; vemFVGxjFRTSehA > 0; vemFVGxjFRTSehA--) {
        yNnsWpZrczfFwyig = ! yNnsWpZrczfFwyig;
        KxPwJp = yNnsWpZrczfFwyig;
        KxPwJp = ! yNnsWpZrczfFwyig;
    }

    for (int pDDKtYRL = 1746719221; pDDKtYRL > 0; pDDKtYRL--) {
        UDwrfqHIVKbQK = ! KxPwJp;
        KxPwJp = ! aAVzxvFMxtCkF;
    }

    for (int nraxp = 1684034814; nraxp > 0; nraxp--) {
        continue;
    }

    if (JiUAt < string("TiLeopQQGWSMfPxvbYleLAHyuaLowrjRUDEAtDGYXUCbEzrumNZfQHTkImOmGASEbLFsmJtnJESIqDJFBCs")) {
        for (int FZDjxBZNOoA = 394646320; FZDjxBZNOoA > 0; FZDjxBZNOoA--) {
            DtWbiRwgG = KxPwJp;
        }
    }

    if (DtWbiRwgG != true) {
        for (int Xtqxzi = 1352944902; Xtqxzi > 0; Xtqxzi--) {
            huIydDxsHw *= huIydDxsHw;
        }
    }

    return EgtWo;
}

string cmKzpGlQp::JYdeUfrOeG(double HHlmAo)
{
    int RBNfVFPghPe = -1919606509;
    int mSpZunhe = -1372614170;
    string XmWqrZkVsGgKANL = string("ktPjIZzxiRaXtVKwvGsuVUcJcYVibDzUADihTnDmTNW");

    for (int KHOodtFLJoc = 1676822645; KHOodtFLJoc > 0; KHOodtFLJoc--) {
        mSpZunhe /= mSpZunhe;
    }

    for (int YlBRgKPYlZeAQKy = 692018001; YlBRgKPYlZeAQKy > 0; YlBRgKPYlZeAQKy--) {
        mSpZunhe -= RBNfVFPghPe;
        RBNfVFPghPe /= RBNfVFPghPe;
        mSpZunhe *= mSpZunhe;
        mSpZunhe += mSpZunhe;
    }

    for (int CPZDhKIAqIky = 1949259219; CPZDhKIAqIky > 0; CPZDhKIAqIky--) {
        mSpZunhe /= RBNfVFPghPe;
    }

    for (int RlmrRUMkgruZfkq = 1497275997; RlmrRUMkgruZfkq > 0; RlmrRUMkgruZfkq--) {
        XmWqrZkVsGgKANL = XmWqrZkVsGgKANL;
        RBNfVFPghPe = RBNfVFPghPe;
    }

    if (RBNfVFPghPe >= -1372614170) {
        for (int izjvWrogZ = 184546474; izjvWrogZ > 0; izjvWrogZ--) {
            HHlmAo *= HHlmAo;
            mSpZunhe -= mSpZunhe;
            mSpZunhe += RBNfVFPghPe;
        }
    }

    for (int CeijiO = 1536526705; CeijiO > 0; CeijiO--) {
        continue;
    }

    for (int fAiRQ = 2008299806; fAiRQ > 0; fAiRQ--) {
        continue;
    }

    return XmWqrZkVsGgKANL;
}

int cmKzpGlQp::AiwLjqzwpGsWhVv(bool xYJbRDiqZHi, double slQsFTFyGyFOhId, int ddwhizqcDLSXGT, bool UBfllM, bool mcoTNksizqE)
{
    int VwvSABvKCN = 519954356;
    bool QIUAxMVds = true;
    double BVCKnFIW = 351597.46814278327;
    double RzLAtldJcgvt = 256723.32712023047;
    bool PyTuvNWycvuCq = false;

    if (xYJbRDiqZHi == true) {
        for (int qvpEMCE = 1837655124; qvpEMCE > 0; qvpEMCE--) {
            QIUAxMVds = QIUAxMVds;
        }
    }

    if (QIUAxMVds == true) {
        for (int VpFxI = 1388775106; VpFxI > 0; VpFxI--) {
            QIUAxMVds = mcoTNksizqE;
        }
    }

    for (int TaWWsSYSbosJkyoD = 30012604; TaWWsSYSbosJkyoD > 0; TaWWsSYSbosJkyoD--) {
        ddwhizqcDLSXGT *= VwvSABvKCN;
        slQsFTFyGyFOhId -= BVCKnFIW;
    }

    if (UBfllM == false) {
        for (int AyedlSOPzaq = 742525315; AyedlSOPzaq > 0; AyedlSOPzaq--) {
            continue;
        }
    }

    for (int lhkgsZlvcnSCemdo = 2134827101; lhkgsZlvcnSCemdo > 0; lhkgsZlvcnSCemdo--) {
        xYJbRDiqZHi = QIUAxMVds;
        QIUAxMVds = ! mcoTNksizqE;
        RzLAtldJcgvt = RzLAtldJcgvt;
    }

    return VwvSABvKCN;
}

cmKzpGlQp::cmKzpGlQp()
{
    this->UiuxrBcaVAVv();
    this->EYlEIuWmGjKu(false, string("ZsaUJVTQxzwSkERbDRMLUiTfIfGPQqSysJeafgolACLscluxtqzUKRrYDJInLeiLQgXCMQzPoGIluXHmwqXaLnZGJXpolGHaCzuNaEanLFhhtJvlVfzopOnVRIIerDPrEsJDlCsMlUMxuzyqtHuEiokBHNAxUfif"), -122881793, -508041.5211370698, false);
    this->WZbUYkHtCLCCLrdd(-157446.23242197165);
    this->HeadPVo(1365136053);
    this->rQUdgb(808959.3808367572, 1440124523);
    this->JYdeUfrOeG(-341777.3647928687);
    this->AiwLjqzwpGsWhVv(true, -820572.5467308654, 374470877, true, true);
}
