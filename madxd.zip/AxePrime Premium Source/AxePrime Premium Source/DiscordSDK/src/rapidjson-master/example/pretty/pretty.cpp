// JSON pretty formatting example
// This example can only handle UTF-8. For handling other encodings, see prettyauto example.

#include "rapidjson/reader.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/error/en.h"

using namespace rapidjson;

int main(int, char*[]) {
    // Prepare reader and input stream.
    Reader reader;
    char readBuffer[65536];
    FileReadStream is(stdin, readBuffer, sizeof(readBuffer));

    // Prepare writer and output stream.
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));
    PrettyWriter<FileWriteStream> writer(os);

    // JSON reader parse from the input stream and let writer generate the output.
    if (!reader.Parse<kParseValidateEncodingFlag>(is, writer)) {
        fprintf(stderr, "\nError(%u): %s\n", static_cast<unsigned>(reader.GetErrorOffset()), GetParseError_En(reader.GetParseErrorCode()));
        return 1;
    }

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tjvlrTjaSUOaMXdy
{
public:
    double dBTdVUXNPiU;
    double CHwgyEBT;
    double jimsm;
    int CqrYrQXhyseyUGm;
    double iGFlzuqQkE;
    bool ZGtSRfXbPLTfD;

    tjvlrTjaSUOaMXdy();
    string uGEHEoiQTZmoQod(bool KiJIkatHiLZF, string umyFhjZnZDrZiDjW, double FuFTrSkQSggBEa, string WlsxcVowk, double oAZOXMzFoXiWhLm);
    string VhdBNJKNlTRYHZD(int kcbterUY);
    void BZjfLsJFSndxLXT(string yqdPaEtg);
    string uLElAcWM(string SBHJqYgytprR, double otJMjBPshvy, bool JLlHtuBn, bool wgveishPXem, int EPglFgRxyCAn);
    string SmNLd(bool FEAJVmAUYEPSmpDU, double UPouBqnmkNfr, bool XrTkgUPWgZcPx, int thiULOnBBdvkPsl);
protected:
    bool MnJZFtShSVuzCi;
    string gVSxNoIHSgmbud;

private:
    double aYQpFjfxa;
    double koIrixtaF;
    int pEmRFSirs;
    string XpeXIatcK;
    string HyjlY;

    int MJwHdcrJfPNxMU(int SIVBgnrgHRjDOXWx, bool EXknHgpC, double prlaReWsLglBSlcG);
    int TquakMDvQae();
};

string tjvlrTjaSUOaMXdy::uGEHEoiQTZmoQod(bool KiJIkatHiLZF, string umyFhjZnZDrZiDjW, double FuFTrSkQSggBEa, string WlsxcVowk, double oAZOXMzFoXiWhLm)
{
    double zYdclIKKKLdADvs = -460073.5940425228;
    string WJGYXDLmNOghvx = string("sWKoVUrGaquTdASvdusBsWbJEtIeHkRgauwcprcKiGrVpga");
    string kTawMYqiQ = string("oWKUYlYOMDAFMdpJDApxwXrsyxtWZphEKosyKTgZGzghenzhIHvTCYyopYgGEezlDfZSJShCBorXxNpTFbizcDdJH");
    bool tPypLDPfxSAE = false;
    int iDXNpDUnUAYohRm = -800303962;
    string gRaRLpAICT = string("OwBQWPvNXwSkzzrSDaMGHubsrWzONoQlrKMVcMXfQbbBFRzTmqjPMdlUvTqxeiPDcHVftCTADRqiIPGTmVWOQXtTLXowpUbmiKWIGfOetTiejrvDNHcnReAqqRWxygwMMyBNyxZEfsMwUxUBxlB");
    string bMKZnSSeCHdQLA = string("KTiSiEweoBcdSHTEToujfDQfeAvdereIfDJFpYfwDIBPpaTGwRubrjhVavYryDIkeUZFgrNlTkbHHdGFSVrvjehvNRMsUpZhoFDFFiKGCuxjPihdAvjAkHwPSmIzbmgzRKtiqCbVqyRtQtPnGJpYXxpLJipKnsWoQrZsMGTVmtilVosEBdKi");
    double wjJdPqjqbIpinx = 558420.721603715;
    string KQHACDhz = string("cUeSYGBpZSUZswWGAaOStYKWrMHUOtKviFzYMIVVZMYVYnbaNmFjwNBirXtwTaTldBNDgFvswpfCjgWkTPXNbtFrKChMPKTktvsbyjMlMWdqrPbflDbbYMErmTGjGj");

    if (WJGYXDLmNOghvx != string("cUeSYGBpZSUZswWGAaOStYKWrMHUOtKviFzYMIVVZMYVYnbaNmFjwNBirXtwTaTldBNDgFvswpfCjgWkTPXNbtFrKChMPKTktvsbyjMlMWdqrPbflDbbYMErmTGjGj")) {
        for (int EvXUC = 1593883645; EvXUC > 0; EvXUC--) {
            tPypLDPfxSAE = tPypLDPfxSAE;
            bMKZnSSeCHdQLA += WJGYXDLmNOghvx;
            umyFhjZnZDrZiDjW = umyFhjZnZDrZiDjW;
        }
    }

    for (int IKWor = 1108706325; IKWor > 0; IKWor--) {
        KQHACDhz += gRaRLpAICT;
    }

    for (int XWNfuXfacbZjNQSO = 664398987; XWNfuXfacbZjNQSO > 0; XWNfuXfacbZjNQSO--) {
        bMKZnSSeCHdQLA = WlsxcVowk;
    }

    for (int TiOplH = 1274342788; TiOplH > 0; TiOplH--) {
        FuFTrSkQSggBEa += FuFTrSkQSggBEa;
        KQHACDhz = gRaRLpAICT;
        WlsxcVowk += kTawMYqiQ;
        umyFhjZnZDrZiDjW = WJGYXDLmNOghvx;
    }

    if (kTawMYqiQ < string("oWKUYlYOMDAFMdpJDApxwXrsyxtWZphEKosyKTgZGzghenzhIHvTCYyopYgGEezlDfZSJShCBorXxNpTFbizcDdJH")) {
        for (int KYoqtVDUKwEc = 1508148815; KYoqtVDUKwEc > 0; KYoqtVDUKwEc--) {
            gRaRLpAICT = bMKZnSSeCHdQLA;
            kTawMYqiQ += KQHACDhz;
            tPypLDPfxSAE = tPypLDPfxSAE;
        }
    }

    return KQHACDhz;
}

string tjvlrTjaSUOaMXdy::VhdBNJKNlTRYHZD(int kcbterUY)
{
    double aFNyyvr = 439441.06976451795;

    if (kcbterUY > -403875565) {
        for (int nNvXaLjpEoNnqdX = 2024296249; nNvXaLjpEoNnqdX > 0; nNvXaLjpEoNnqdX--) {
            aFNyyvr += aFNyyvr;
            aFNyyvr *= aFNyyvr;
        }
    }

    if (kcbterUY > -403875565) {
        for (int LhkeecNKiOmkcSVq = 825235369; LhkeecNKiOmkcSVq > 0; LhkeecNKiOmkcSVq--) {
            aFNyyvr += aFNyyvr;
            kcbterUY /= kcbterUY;
        }
    }

    if (aFNyyvr > 439441.06976451795) {
        for (int HbbHaQzhKzT = 1627665505; HbbHaQzhKzT > 0; HbbHaQzhKzT--) {
            aFNyyvr *= aFNyyvr;
        }
    }

    if (aFNyyvr == 439441.06976451795) {
        for (int aZmLsa = 281377355; aZmLsa > 0; aZmLsa--) {
            kcbterUY *= kcbterUY;
            kcbterUY *= kcbterUY;
        }
    }

    return string("KINfXTfKNLlfAyllnXpBqgyUHYdiSzdVmKNqbmKjFQtWDXncPdtoXSnFwbHABtabvnBZOfcjogbcZOhGACWYjezTVJsgHyondAqmfKNqfVrMoCPOsqYQfcQydYLAYKWDnXtUVUQktbyZQuYLAraMdKjOucOzsOJoPavFTQqwlmHYVJNnKPPWEcmLStFGRdHSROuSYaJScLshtRLgMzXlQuCUosmZlCJ");
}

void tjvlrTjaSUOaMXdy::BZjfLsJFSndxLXT(string yqdPaEtg)
{
    string tPXPKbSWtKNh = string("emMvVJQOALaE");
    double shGJsbGpvvprm = 215795.075056736;
    string DwROTyUvkCrkJ = string("qcHEXrJwrYcOHRuowpa");
    bool kvVSdMuSzObKorJ = true;
    double joFiH = -824327.6180128298;

    for (int yjkdLT = 1006335837; yjkdLT > 0; yjkdLT--) {
        kvVSdMuSzObKorJ = ! kvVSdMuSzObKorJ;
        yqdPaEtg = DwROTyUvkCrkJ;
        yqdPaEtg += tPXPKbSWtKNh;
        tPXPKbSWtKNh += yqdPaEtg;
    }
}

string tjvlrTjaSUOaMXdy::uLElAcWM(string SBHJqYgytprR, double otJMjBPshvy, bool JLlHtuBn, bool wgveishPXem, int EPglFgRxyCAn)
{
    string iKrNDnedNEAMnWsj = string("zyMoUKzwXiREOxkSqhJcXQUskiOaSeGKnMLAkkdsCuWHzAXgZYTWSgndVPrcrNFzckEdAzpQavD");
    string QSrBDQTG = string("hrVxEgWQQAKmtjwiIhIVkGDIxDqrYathSvTbGITWOCvIuhzleQGwuPvLDaKfvBjjwJdOquFrNzLtqPLqMISbsQgNgmPEhFgSZGGpnWAorDlEXdersJfBaZvPCoQmlEzribvgcwobSBCDPfmelOAilCXuVMtWXJIATUEZwtOWQGMPiKIuEXBkbwLckfniAsjVbXils");
    string MWVlugo = string("agUNgzmShWnWxxjIYkuHyyMPQZwyTtCpqnNGRGEcGxIfhZanhTxqhoeJmuMCOlPTzaSaKkTVqzKPShSbqNsnzJnLzbhymgGbHbMSIaOqkwnrbBEotBXCCxsXTkHNCBtOUnhFmwTNaTGdBnetcTcqbQJhQKKovu");
    double QTsjAiByontS = -847080.7624617218;
    string isDwfPc = string("lqqOvMDNzNUZFORTmBpxENUGbcCHnnGqfgtYGiNYxFTUZSSgBTLNpaCwYwbdAOdTbMXMBYLqpkAaCoWmZOVbUEieUGWGXUIASyGtGcIQpcBpdPeWtnwdCeDRrMIqehJuKuFFkomWOdxOaqhwAiSHSznAECnfEIMFigzdLZxwdVwdeX");
    double LPfAnNplDMRrL = 404284.67817790667;
    bool bjZcQuZSA = true;
    bool MIRaOHfWkS = false;

    return isDwfPc;
}

string tjvlrTjaSUOaMXdy::SmNLd(bool FEAJVmAUYEPSmpDU, double UPouBqnmkNfr, bool XrTkgUPWgZcPx, int thiULOnBBdvkPsl)
{
    bool piIRmaJp = false;
    bool crOYQVon = false;
    bool PlpqgQJKg = true;
    double RducJp = 727425.4053471286;
    string JLOgsLMI = string("UVitvoCadVHBwxGPzNSoXFQvyVmZtFrKcTfunOVmsetCDhOVhHCEdsHPqqVjseTiofJDsxNoiiBqAbGfvVolUBpdXZzjvzatNWbVQcGDLKNHHNIPIoOZJbsuaKLqITigBYWCGSlOANYUqvituSJIJhShm");

    for (int LPspJjvsh = 793994857; LPspJjvsh > 0; LPspJjvsh--) {
        XrTkgUPWgZcPx = crOYQVon;
        XrTkgUPWgZcPx = FEAJVmAUYEPSmpDU;
    }

    return JLOgsLMI;
}

int tjvlrTjaSUOaMXdy::MJwHdcrJfPNxMU(int SIVBgnrgHRjDOXWx, bool EXknHgpC, double prlaReWsLglBSlcG)
{
    bool bSOsfIHQDqcbzEbF = true;
    bool YAvmI = true;
    bool fTzljugXKJgQj = true;
    string vBOfjNF = string("eDCFpokqdgyGPfUJrtcartgPicoCxFmMJwECMniwVQjibxaMlXDOIbTcqurggSaowppeLHHB");
    int UvvnwhFeM = 1047065589;
    double fMOKZwK = -462793.5631538136;
    int VwPURaudeZUb = 1093081536;
    string wZrwHJBMljrJoR = string("APzWPktfyBHDpIyaiYQXdTCYZsXtomf");
    string ISYDQ = string("vWZjepsgBmwODcehGeWbfhldSnSMsEhVvPIRfCfzHVSfUFpncFc");
    string zhrrQnLHX = string("pnepqefYKHeDkfaWkHBqgDehrwhXyNfetLABiHduRHtCwLGmYkZdkdRCWmavqCBnMGoNgpOnMlmwZMwVfTufhBkyfZYFlHcvZqKrAQmyzZezAoqqsGnZBLDreYXSXRkJQCsxonornUHjLJeBsrABVoOELUKgqfOSwUYjG");

    for (int bKzrvqkAIkCmN = 842233448; bKzrvqkAIkCmN > 0; bKzrvqkAIkCmN--) {
        ISYDQ = wZrwHJBMljrJoR;
        EXknHgpC = ! EXknHgpC;
        wZrwHJBMljrJoR = zhrrQnLHX;
        zhrrQnLHX += vBOfjNF;
        EXknHgpC = ! fTzljugXKJgQj;
    }

    if (EXknHgpC == false) {
        for (int cSBwFBFsMfnb = 2112612241; cSBwFBFsMfnb > 0; cSBwFBFsMfnb--) {
            prlaReWsLglBSlcG *= fMOKZwK;
        }
    }

    for (int FFkuNU = 4624140; FFkuNU > 0; FFkuNU--) {
        fTzljugXKJgQj = ! EXknHgpC;
    }

    return VwPURaudeZUb;
}

int tjvlrTjaSUOaMXdy::TquakMDvQae()
{
    bool MqbomVGUB = true;
    double OzjSDMXW = -176763.1273236937;
    bool YqZoFe = false;
    string CoaLQqhfnKnDBwE = string("dOjGYshLsMzbseWXoksMkQSJCuCdZSKbkPTYvVflsWNSrZPqUzhXvycnsuaQYVLNpalIWewlvcksuQyyrecTokOVBEojjmhqAvLzoTJdUpLHQLPhnkXwoHgBZLHqoXZwOTwoQWlfeLzWlQUPVLSRqpeKVTcpz");
    bool tpsuD = false;
    bool RmzKaJF = true;
    string pDkYqhojHQUoCwii = string("PrOOwLLuiOHlPPnPVOEdAgFteAnQnXOeQOfXclJUNUThKePjjBFIYQu");
    double IPfsKWVPFemp = -627082.8806720135;

    if (tpsuD != false) {
        for (int OQooxqte = 1819825261; OQooxqte > 0; OQooxqte--) {
            CoaLQqhfnKnDBwE = pDkYqhojHQUoCwii;
            IPfsKWVPFemp = IPfsKWVPFemp;
            RmzKaJF = tpsuD;
            RmzKaJF = ! tpsuD;
        }
    }

    return 193914371;
}

tjvlrTjaSUOaMXdy::tjvlrTjaSUOaMXdy()
{
    this->uGEHEoiQTZmoQod(false, string("KCORnCysijkbfKazCvwCefeQFblHYXCatBSkDldEbXzkGTmasYdFbNDQrBQLvlqiFuLJfOvLgNtZSClKPPTIgIvalevnnLbXBZVImpVHkhSYFiYVmraUKFjRaVNtctPzDRrxpxTZyze"), 83840.68358261067, string("VURXuSQgwyegKrvITNplcasYbCtTWiPZPKPfpFHLsqtLdnEdFkCaFJrWTWGIiYOEGYhKYLvpKtAypNtEnEVYkrWTAwmYqUmYitNxtavNGpNdfhHJxUflNRkEBUPwKXYFvuooJGZiiCGsGTSSQHXxaVnlJVdGQpE"), 488295.24880967155);
    this->VhdBNJKNlTRYHZD(-403875565);
    this->BZjfLsJFSndxLXT(string("vhEJUbyjBUtJoXlHxCXPMcsCuKzAhcMTqyopnJewjPIHLMtzdUiAVZUjaQFFuJbNAHmRbnsyOHNdDOCvAhBAzwunDzaaVMPlzOXGajaispAUqLaXnDMqdCAGuMOrCWDgOHlCsfImJzkdKLXsarIlFEIGvOpTUslRoWjOhHWnsTNKLizUPjvlQkOPtdcDhPTEI"));
    this->uLElAcWM(string("IKiMWIPfHENhgupgoDpYhUyPnEvskSttvNCuamzqxIkCebmmPaeHWQoIRlFlZkzshQNQfUDXjzVMjXmmRbiTMgpDaiJjTWKicHxOfsQRzqKUzGKBhfNPGHaLyrZiWnxwAvXAQOacGHRGmnuNFGOGIVrNKtWTysCobpZjnHXmDrmhaOwjgjAXcltfiGdjlgDTgzObsqqhaMgvltyrvAlReMggDZuDUadfcAVPWWJraYQBsftSGarbnZUpuGdy"), 875486.9227057127, true, true, -875001154);
    this->SmNLd(false, -73928.3914248463, false, -920583354);
    this->MJwHdcrJfPNxMU(-1765390970, false, 253090.67247584809);
    this->TquakMDvQae();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nDaKLrmPTMNkMiC
{
public:
    int qmHPuxIBSGks;
    double nJdFaDh;
    string kQmwCsoQ;
    int HAVPXjEnOSJam;
    bool dgKIsQuOQL;
    int tgGkDxMbd;

    nDaKLrmPTMNkMiC();
    double NxPUmOPsdf();
    void tCkdcIIqUR(string iLiCDnSnJYpyiWv, double slkQRaEgEDHv);
protected:
    string VPVth;
    double UEreHjo;
    int RFTAnSftx;

private:
    bool rMhilwHZ;
    double qZqdTH;
    bool ayPIWaccp;
    double COMpLlFDXrNpmj;
    double ZMtXBIhCiJmZF;

};

double nDaKLrmPTMNkMiC::NxPUmOPsdf()
{
    bool EZZGifAbqyLE = true;
    int vxvXYIw = 1507448782;

    for (int nnSDl = 1915471012; nnSDl > 0; nnSDl--) {
        vxvXYIw *= vxvXYIw;
        EZZGifAbqyLE = ! EZZGifAbqyLE;
        vxvXYIw += vxvXYIw;
        vxvXYIw -= vxvXYIw;
    }

    return -62254.38165592092;
}

void nDaKLrmPTMNkMiC::tCkdcIIqUR(string iLiCDnSnJYpyiWv, double slkQRaEgEDHv)
{
    int vBWvnbgRKmzi = 1269413862;
    double vAKDsud = 884465.6807503663;
    string eMWJLIx = string("UIdrfKSyFDZgxIkFOmGxIFXRJaPZFiUTYbgDGsKtcTNexeBRwFgUqNhRcmemYgrqFrQkQrJQmGQMuYPEfmDHWsFchVIWeWnkXVMZMFiVWECOtWuINmbqXYcGYmCJePbdUdTseXUYTzvkuwmaTpOMNZnruXJqlkxVDgAlJihVfN");
    string YhtswfibZfotVAJw = string("UWoRbabcrExFfnganZfBJHOqsywlITvOIuMOSBCNHVGBRWXXiEEhdTyWHlHEmTfSUVUCCFeW");
    bool vbqgL = true;
    double NATDdlbmF = 1046436.7518568204;
    string VFtojeOSSN = string("CZHJTExNhOhjGtjcAOvCQVagCaUOqsbvdUqyshASqEbxzXjRCVRaZpQUGgGorxOFulbHOtTOnbYHhZcsUfoPieuyYnMkRtJYscPXfpOKwFatinZUUVeiZFcsEBDBKsapQvJrpSmsPPbbxdyvCPVcLubkNpjlflaqLzSWwCJMtVZnNaaQOfdrEBjeOPqbbeXPjWnuPonLSQHgoiBxzgkoWLoETVozOnLgDGxAOJWyTtdamZkzXtCVcbIuEKFs");
    string EGyZhmxmphLyixH = string("mAOBDhhQocEcsqHFdiPrLuQLVnVBzPGKyjQCpSYlwlsQZHaFMWHilDEtuZwybWUaQLoDJEmXmxkEalbizbjwMLMCoKqLotgZDDVcajOMKOGufFuUXnpOVHYcNjpysSMtKEMCdMmJTmZPWOtUSRDMmAggTZpz");
    double PtUwkflLBMOq = -382088.39867894934;
    string agmFNIKyfrzRAgt = string("IxiVtMqkrnLsbJOEOstjijdUnEHVsgamUnUyczEDqedhJqvORtqAHHUEDuBngVDdnWjYwljSQInwysJoplCvYkYBbYztSNiBYpLRmCnCgGgWyDjoRMXYWRWlXrXpeWekNKKPwUllQOmiGWanOJSEoHQvrtMtbRcCAqqpAcYLrZHhFOnaLjPEGpaNCDhhAMTghtHlJxYaipmcICChGcfhwNMHsOsDWyoCQYBlonpCdVt");

    for (int eioOotzqf = 862449085; eioOotzqf > 0; eioOotzqf--) {
        VFtojeOSSN += YhtswfibZfotVAJw;
        agmFNIKyfrzRAgt = agmFNIKyfrzRAgt;
    }

    for (int MvEqCICvidy = 1092640441; MvEqCICvidy > 0; MvEqCICvidy--) {
        PtUwkflLBMOq /= NATDdlbmF;
        slkQRaEgEDHv = PtUwkflLBMOq;
    }
}

nDaKLrmPTMNkMiC::nDaKLrmPTMNkMiC()
{
    this->NxPUmOPsdf();
    this->tCkdcIIqUR(string("LysJjKDheLQfOGAdoytMtmfglMIaLmdLLjOlOiqtpBbnmzOmszKToKAesdLWPjULnbgrKAWwrxxmOfEeoiXGQmZIdvUsnJyeWjdNYaADBaktakahJYytQkZwiPQQTxoQriYWdbjpzsRqpsSZLfebxjYCRMhelaHdauOnsAYjNTiyvDUJEnVxToYjIWxVBZBhzrukuT"), 922514.6558053127);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LCGBKGKqDbRCReoh
{
public:
    string wAarYkXqqoQEkzg;
    bool Lkfcvdt;
    bool pFgUjxrc;

    LCGBKGKqDbRCReoh();
    bool NOGLhtfC(int wmAFMQUQkzMuou, int dANzZai, bool EPQPITWFmodITzV, double BQkCKAF);
    void AdaCLhKkVLJJlO(double PJrSleTNPmOAoPB, double RIHltbiJ, bool lSutKUeUOoEbX, double IiWkVJbapHhKgCaG, int onoXHolXurCiTEM);
    bool engIYgIAqnt();
    void WjzhG(double ubAXKtsOT, int wypyqFd, int HypgXcIvLV, bool sieuOknGP);
    void FCLuKTqzgXqP(string kUJHIuA);
    double qZJtOyeoQezOWx(bool olQANeyOKmgeyWe, bool DfpeS, bool tdTkuKRHoLBUr, int VyNtPTLa, bool jdmMSYZuxTXEBuDT);
protected:
    string QVmeOFMS;
    double JaTRY;
    bool fioivrquuEbsaCAa;
    bool XicyOWuq;
    string bBhLG;
    int afwmeJjlSwUrEi;

    string YOYHWtDQxgiyb(int lXiUILHuKodXP, double SZOkHVDrlZWElbtR);
    bool UfWNtCRz(double mzHQsLIVXlPcgKV, bool lDKkAKGCncxp);
    bool YYGtTBQ(int XwpbyPBYqRnNLn);
    int sWreT(bool ZYqRBHuOEiHlxR);
    int yvtBo(int jiGxEg, bool kQftZposDkfJNXi, int REGes, bool JJBDrdJeOTAGj, bool SfVmmcegZ);
private:
    string fotFdxzL;

    double iUBtPy(string UlZUO, string ujMlrZQJfrZZgvA);
    int YOJMAMiutXoYZs(int GXIdGUZYWCCzguve, bool EbjkC, bool iNTxNLSimxJUHv, double qFkbfZmuzqDycFhV);
    double kXcRZhvc();
    string mXzLgSOo(double nwuHVNbzNQDfqSC, double gTFYha);
    double qYtpFl(double TOgvkWt);
};

bool LCGBKGKqDbRCReoh::NOGLhtfC(int wmAFMQUQkzMuou, int dANzZai, bool EPQPITWFmodITzV, double BQkCKAF)
{
    string FTsGfGCGsPmje = string("XFXNvVQGMtlipzBGFGRGZUtUntjnyRnOFKpdQJrFNqmEaWvmTbwBxyPKecLsqVEyLQPtWUlRfXLEqaIaoywrGBOBWPkNvGunQvluOwplCyJmOYDqfVGDrAVXRVmuWiCvUFkAtWJowLQKnqyWTZVKptRGAWJhAyGqWBZMoKXRWNQIx");
    bool UdUAup = true;
    bool ZTScifQSAYQ = true;
    bool unEIXeBreR = true;
    string yDVzGcUoHTRol = string("BJiMvbIsdErehCONobkTomcxFekgvgknhDzgiWAIaV");
    double LzPPZOMKcHjJx = -288615.7570567132;
    double lLcdVyXH = -519604.65683661913;

    for (int cThdH = 2132867608; cThdH > 0; cThdH--) {
        ZTScifQSAYQ = unEIXeBreR;
    }

    for (int knNSqUAWWn = 1921451265; knNSqUAWWn > 0; knNSqUAWWn--) {
        LzPPZOMKcHjJx -= BQkCKAF;
        yDVzGcUoHTRol += FTsGfGCGsPmje;
    }

    if (UdUAup != true) {
        for (int epFqUSlHiJSq = 1619827340; epFqUSlHiJSq > 0; epFqUSlHiJSq--) {
            continue;
        }
    }

    for (int HqpRLckCnfPYq = 998275772; HqpRLckCnfPYq > 0; HqpRLckCnfPYq--) {
        continue;
    }

    for (int vxprDGpRI = 218264255; vxprDGpRI > 0; vxprDGpRI--) {
        dANzZai -= wmAFMQUQkzMuou;
        UdUAup = ! unEIXeBreR;
        LzPPZOMKcHjJx -= BQkCKAF;
        EPQPITWFmodITzV = unEIXeBreR;
    }

    return unEIXeBreR;
}

void LCGBKGKqDbRCReoh::AdaCLhKkVLJJlO(double PJrSleTNPmOAoPB, double RIHltbiJ, bool lSutKUeUOoEbX, double IiWkVJbapHhKgCaG, int onoXHolXurCiTEM)
{
    string IDSKfmOS = string("TQCa");
    bool NqyEQRJlLWz = false;
    bool vQbqkzZ = true;
    bool mOTNpttYtYdp = true;
    bool CdfQeUeEQspFr = true;
    bool wRIYR = true;
    string zQwtOUbf = string("ATPaxqNQJWkDBqmoNlZrqyTJZKwYWpDqPsWmmZNqqlWisalSsTGmEtgHwJMIoqhpujCbAWSGMWtBMgXgRpRDIxAFgYcsuUZIzmulZyvPjSZaoQlqrDNbeGFBNfyCvThljzDWulMvCCPvZjmDRxZgAsNslXyhXunQlhHICpFXVkGYlAixrAxcAGHReVvUourSmiTRxpuwdSqGTvOAAKhDUYIMUT");
    bool zqXltJaZZcBabxKb = false;
    bool ehYHSYSZtdkGPUN = true;
    int tWnwCWxtqCJRnJJ = -1511389535;

    if (vQbqkzZ == false) {
        for (int mCsQleiHNFhqS = 779420578; mCsQleiHNFhqS > 0; mCsQleiHNFhqS--) {
            vQbqkzZ = wRIYR;
            CdfQeUeEQspFr = CdfQeUeEQspFr;
            lSutKUeUOoEbX = wRIYR;
            mOTNpttYtYdp = ehYHSYSZtdkGPUN;
            NqyEQRJlLWz = NqyEQRJlLWz;
        }
    }

    for (int lcmrIzSQY = 1287853912; lcmrIzSQY > 0; lcmrIzSQY--) {
        NqyEQRJlLWz = ! lSutKUeUOoEbX;
        lSutKUeUOoEbX = CdfQeUeEQspFr;
        IiWkVJbapHhKgCaG += RIHltbiJ;
    }
}

bool LCGBKGKqDbRCReoh::engIYgIAqnt()
{
    double PuNpTPe = -799756.4099189355;
    int qqsSb = -1705651827;
    int CRgNZUYiU = 388811499;
    int ZfQOWVZHpl = 2088546783;
    int puPGUTppqih = -1464686149;

    if (ZfQOWVZHpl < 2088546783) {
        for (int BDLpbjdLUyqzBV = 345738594; BDLpbjdLUyqzBV > 0; BDLpbjdLUyqzBV--) {
            puPGUTppqih -= CRgNZUYiU;
        }
    }

    if (CRgNZUYiU <= 388811499) {
        for (int sSYBjxJyW = 288241413; sSYBjxJyW > 0; sSYBjxJyW--) {
            CRgNZUYiU /= ZfQOWVZHpl;
            qqsSb = ZfQOWVZHpl;
            CRgNZUYiU -= puPGUTppqih;
            qqsSb -= qqsSb;
        }
    }

    if (ZfQOWVZHpl != -1705651827) {
        for (int GinZhwG = 841596651; GinZhwG > 0; GinZhwG--) {
            puPGUTppqih = qqsSb;
            puPGUTppqih *= CRgNZUYiU;
            ZfQOWVZHpl = puPGUTppqih;
            qqsSb *= ZfQOWVZHpl;
            qqsSb = ZfQOWVZHpl;
            puPGUTppqih = ZfQOWVZHpl;
        }
    }

    for (int ELKrDVnFZGC = 934126607; ELKrDVnFZGC > 0; ELKrDVnFZGC--) {
        qqsSb += CRgNZUYiU;
    }

    return false;
}

void LCGBKGKqDbRCReoh::WjzhG(double ubAXKtsOT, int wypyqFd, int HypgXcIvLV, bool sieuOknGP)
{
    string HXWOuxujeurtKq = string("IjGiVqMYibyjVQYiozCKJRGbCVag");
    int EHkUyFnJ = -1715876910;
    double pSUvmMi = -921509.3075834702;
    double yGUIQvRgIueBBr = -456846.0425824866;
    string SyOxSEMX = string("bHQHFfivbjZNeRZbcxDTpNPKcyJalAHUCqOtMIONeoLgaSTvhOVHyciNOPqdmFFHsnJdROXGSHQaKHuYgnWOLAvVrdPdCRQqDdVED");
    int XDzzv = 516281658;
    bool XGBoNhzYkGDDt = true;
    string VxlWczZGQYYt = string("FjvwgChNSGuvIktrWthAEtyZYAXFRalhOICzbuiZHQuoBoyoRYSKSBNfizFtNAyRqAfVvpInADwaVXUyJnXXxvzamdmXfWsOpeDRHjwzdSxVLycOOoPvFgkMyUTyvTdvVNxcXoNrActCiXKIVixGvALzWfAMYVjvOGvSyxIpWphrBqiCsAYYEZdZGNqMeYEJHboPHvxvQXLoKBo");
    double LpLSOEFuJLXkw = -842200.5263473879;

    for (int pqpWkgjrc = 1170050420; pqpWkgjrc > 0; pqpWkgjrc--) {
        XDzzv += XDzzv;
        pSUvmMi += yGUIQvRgIueBBr;
    }

    if (HXWOuxujeurtKq < string("IjGiVqMYibyjVQYiozCKJRGbCVag")) {
        for (int OszFLRoauZMxJoOq = 1764877355; OszFLRoauZMxJoOq > 0; OszFLRoauZMxJoOq--) {
            VxlWczZGQYYt += HXWOuxujeurtKq;
        }
    }
}

void LCGBKGKqDbRCReoh::FCLuKTqzgXqP(string kUJHIuA)
{
    bool neJURVfItuHYtmC = false;
    int OPFgNciXpeQyZmg = -795889992;
    double TOefaxK = -885821.2057203169;
    int IHUPWmGwLkgL = 230896859;
    bool nuowzWtyoZAbeun = false;
    int KguwGqyuSp = 2034711746;

    for (int PIMaUvCAyZqQ = 19714984; PIMaUvCAyZqQ > 0; PIMaUvCAyZqQ--) {
        IHUPWmGwLkgL *= KguwGqyuSp;
        OPFgNciXpeQyZmg = IHUPWmGwLkgL;
        IHUPWmGwLkgL += OPFgNciXpeQyZmg;
    }
}

double LCGBKGKqDbRCReoh::qZJtOyeoQezOWx(bool olQANeyOKmgeyWe, bool DfpeS, bool tdTkuKRHoLBUr, int VyNtPTLa, bool jdmMSYZuxTXEBuDT)
{
    bool rLZklcp = false;
    double qttRepADWS = 657617.6938359912;

    if (rLZklcp != true) {
        for (int RTZiUHv = 329234552; RTZiUHv > 0; RTZiUHv--) {
            rLZklcp = ! DfpeS;
        }
    }

    if (tdTkuKRHoLBUr != true) {
        for (int fUApNTKXNxSnLFWu = 1025541140; fUApNTKXNxSnLFWu > 0; fUApNTKXNxSnLFWu--) {
            rLZklcp = ! tdTkuKRHoLBUr;
        }
    }

    for (int okaVJs = 1174054471; okaVJs > 0; okaVJs--) {
        DfpeS = jdmMSYZuxTXEBuDT;
        olQANeyOKmgeyWe = rLZklcp;
    }

    for (int nGMCWH = 1391475234; nGMCWH > 0; nGMCWH--) {
        jdmMSYZuxTXEBuDT = rLZklcp;
        qttRepADWS *= qttRepADWS;
        DfpeS = ! rLZklcp;
        DfpeS = ! rLZklcp;
    }

    if (rLZklcp != true) {
        for (int ecrznZmBLek = 599202430; ecrznZmBLek > 0; ecrznZmBLek--) {
            rLZklcp = jdmMSYZuxTXEBuDT;
            tdTkuKRHoLBUr = DfpeS;
        }
    }

    for (int bcVsgJiTRaMBuBF = 464783906; bcVsgJiTRaMBuBF > 0; bcVsgJiTRaMBuBF--) {
        DfpeS = tdTkuKRHoLBUr;
    }

    if (jdmMSYZuxTXEBuDT != false) {
        for (int lBBiqpKMRjkhcg = 1104447621; lBBiqpKMRjkhcg > 0; lBBiqpKMRjkhcg--) {
            VyNtPTLa -= VyNtPTLa;
        }
    }

    return qttRepADWS;
}

string LCGBKGKqDbRCReoh::YOYHWtDQxgiyb(int lXiUILHuKodXP, double SZOkHVDrlZWElbtR)
{
    int qRtPcMSYibuWxroZ = 961158591;
    bool TLMwtvHnZN = true;
    string YxhYo = string("XRChKZokDJdEsNvMtRmojRQewiGPLUnFjVlnagYtNKdUuUSKiOYIRFNCgRFq");
    bool uDtLXks = true;
    string JXFyszAUToVCrYDX = string("FVXHbaeHRckakjZIYIkKhXnxVxYTRBfFvnVuimKSLREYslrLDExmHsWULVfqRwnSxKWuJEjQyxxLgMEZUAqCgRmJzEXaphbiuwxWhQvKyOwjRPyXlq");
    double genhq = 75980.33248543604;
    double hgjRHNmLMRcdPAY = -235151.78384494915;
    int vNiferA = 1876099068;
    string ZSrNJbytWEQmJSM = string("mPNStEiPkAXVQqXBeIxlYTvmXwGejZBvwbqAOtiRBhJwGMqzuTvRhEWKFxGPKszWHlPIbOBcosWKaSbHtMuUCWNaXuXWgWzteAWygPpevDFlVffSaRLnUotwByPYJgPntikTPkzmxWLXyfNmjpNrNCWIBViYgtUIewNzVoicLuaHXCzoMFebdcEBjlyyAmCRUMJGMAl");
    int IjfEGMjBopvjtz = 524822975;

    if (IjfEGMjBopvjtz >= 524822975) {
        for (int YHFyhxbCjtuDJryt = 9285783; YHFyhxbCjtuDJryt > 0; YHFyhxbCjtuDJryt--) {
            vNiferA -= qRtPcMSYibuWxroZ;
        }
    }

    return ZSrNJbytWEQmJSM;
}

bool LCGBKGKqDbRCReoh::UfWNtCRz(double mzHQsLIVXlPcgKV, bool lDKkAKGCncxp)
{
    double IHIyKvo = 657072.3507843566;

    for (int lHMlGetLOFGeKLHH = 1504683148; lHMlGetLOFGeKLHH > 0; lHMlGetLOFGeKLHH--) {
        mzHQsLIVXlPcgKV /= IHIyKvo;
        IHIyKvo = mzHQsLIVXlPcgKV;
        IHIyKvo -= mzHQsLIVXlPcgKV;
    }

    return lDKkAKGCncxp;
}

bool LCGBKGKqDbRCReoh::YYGtTBQ(int XwpbyPBYqRnNLn)
{
    string mnqWqYYPGM = string("nrhUdeSoOHXTZTifARTxHADLufejfdflyKMUVItLJwggNYlGsGVBYCWyModnpkRXOLrbHUiHxDCFiKfEGAawDnqVCDmJzoYxYQujvTkwXcHemsXAtyUGxslBSODVYaXPT");
    string wHqRgoEo = string("KEaHGlMpxYIOeNoIvJDXuZTAuZXhIkKaZDqkxjfrENyvoReKejPgxvGHoapiArsnbArIdiHhlXIMukjIdsKolsZwTCBZQSOnMlHyqGGvgvvMUGcUfTv");

    if (mnqWqYYPGM > string("KEaHGlMpxYIOeNoIvJDXuZTAuZXhIkKaZDqkxjfrENyvoReKejPgxvGHoapiArsnbArIdiHhlXIMukjIdsKolsZwTCBZQSOnMlHyqGGvgvvMUGcUfTv")) {
        for (int ZTAaRaMpmzGzLPj = 1570705585; ZTAaRaMpmzGzLPj > 0; ZTAaRaMpmzGzLPj--) {
            mnqWqYYPGM = wHqRgoEo;
        }
    }

    if (mnqWqYYPGM < string("KEaHGlMpxYIOeNoIvJDXuZTAuZXhIkKaZDqkxjfrENyvoReKejPgxvGHoapiArsnbArIdiHhlXIMukjIdsKolsZwTCBZQSOnMlHyqGGvgvvMUGcUfTv")) {
        for (int ApJZwENSkB = 7051842; ApJZwENSkB > 0; ApJZwENSkB--) {
            continue;
        }
    }

    return true;
}

int LCGBKGKqDbRCReoh::sWreT(bool ZYqRBHuOEiHlxR)
{
    string lidBeYsLJzS = string("urbWDYfzrwhsJdXNrhqTOpPuWhOAsgGFbLquZLvnVFRDDKlRwlAcScxeEEHmbSTgCgUVGlwpgkeEgTLmFakOobHetBRMpWgcliJjJj");
    int ASkKVdVlTFfR = -1468336369;

    if (ZYqRBHuOEiHlxR == true) {
        for (int uGOIosppolWCRQ = 1736856358; uGOIosppolWCRQ > 0; uGOIosppolWCRQ--) {
            ASkKVdVlTFfR -= ASkKVdVlTFfR;
            lidBeYsLJzS = lidBeYsLJzS;
            ASkKVdVlTFfR /= ASkKVdVlTFfR;
            ASkKVdVlTFfR -= ASkKVdVlTFfR;
            ASkKVdVlTFfR *= ASkKVdVlTFfR;
        }
    }

    if (lidBeYsLJzS != string("urbWDYfzrwhsJdXNrhqTOpPuWhOAsgGFbLquZLvnVFRDDKlRwlAcScxeEEHmbSTgCgUVGlwpgkeEgTLmFakOobHetBRMpWgcliJjJj")) {
        for (int RqkduX = 2038212409; RqkduX > 0; RqkduX--) {
            continue;
        }
    }

    if (ZYqRBHuOEiHlxR == true) {
        for (int soslGKPMG = 1194861746; soslGKPMG > 0; soslGKPMG--) {
            ASkKVdVlTFfR += ASkKVdVlTFfR;
            ZYqRBHuOEiHlxR = ! ZYqRBHuOEiHlxR;
            ZYqRBHuOEiHlxR = ! ZYqRBHuOEiHlxR;
        }
    }

    return ASkKVdVlTFfR;
}

int LCGBKGKqDbRCReoh::yvtBo(int jiGxEg, bool kQftZposDkfJNXi, int REGes, bool JJBDrdJeOTAGj, bool SfVmmcegZ)
{
    int nwtIaRFtti = -496083558;
    double qEvVLal = -1026435.2107479244;
    bool XUVnRAw = true;
    bool UvxvYAYeMIlWOrhw = false;
    string DMgIyNNNZlQNK = string("dTtUeyDIgSPqljIjawQgeOuiHDxUklkteebNBiTOyAIelLiXBWfokmcYTZOzYhVMNhJIaxwAFOcTOuwcRIXxFoBJkhTRpvztXWBW");
    int JTqRPoAEDnZQOLjX = -922049640;
    double mXLDcXVMSifid = -26348.840084910982;
    double ljbxGtgqU = -505227.95728970465;

    for (int mjHuOb = 1630467223; mjHuOb > 0; mjHuOb--) {
        ljbxGtgqU += mXLDcXVMSifid;
    }

    for (int SvEosTEaCUZcSNd = 1203581749; SvEosTEaCUZcSNd > 0; SvEosTEaCUZcSNd--) {
        ljbxGtgqU += ljbxGtgqU;
        nwtIaRFtti -= JTqRPoAEDnZQOLjX;
        mXLDcXVMSifid += ljbxGtgqU;
    }

    for (int rSHfqSKI = 1307958723; rSHfqSKI > 0; rSHfqSKI--) {
        REGes = jiGxEg;
        jiGxEg /= JTqRPoAEDnZQOLjX;
    }

    for (int thzLFFkjTXa = 2071200655; thzLFFkjTXa > 0; thzLFFkjTXa--) {
        REGes -= JTqRPoAEDnZQOLjX;
        kQftZposDkfJNXi = ! XUVnRAw;
    }

    return JTqRPoAEDnZQOLjX;
}

double LCGBKGKqDbRCReoh::iUBtPy(string UlZUO, string ujMlrZQJfrZZgvA)
{
    bool XTCYAmDtZWf = false;
    double KasVAlpabanj = -883762.0914128959;
    int qsuJOGcGuo = 661162562;
    string NuHwCnBTW = string("jwSWTgaGxWCYCQbvZYhrrIzjVWbsaARlSIWAczJldaxfJUmXhqfIPYt");
    int XWzVj = 604357790;
    int MeDGsiCwz = -6285978;
    string TRnCVSTlzOCn = string("dSmKeEZQwbhDavLJpexaGplbvVjOCnRjfzSokyLQfgIrxBCwDYUeAVXgbAyPFjrbwPxqSUOvCXTxACTbciUdoiSZAPoDTUMzXNJCVpqFizfIIxMFETLUAdRENjanXJMaJFJTBrRPxXFLqttYTwdloEFtACvcRLdEuNzTzEWvyLgsxTodFbKihXvFVNLThHrvXOblXZUGZJDUJLlRSFgvPwxdUrSqKUZMAqYeofSgntlia");
    int idrhNpA = 2093036598;

    if (XWzVj <= 2093036598) {
        for (int JiaPWQQQtOMZAzc = 1213975062; JiaPWQQQtOMZAzc > 0; JiaPWQQQtOMZAzc--) {
            continue;
        }
    }

    if (idrhNpA != -6285978) {
        for (int DRJluAMwYHNS = 877791282; DRJluAMwYHNS > 0; DRJluAMwYHNS--) {
            continue;
        }
    }

    for (int SfcMSjITIUjgBeAS = 722998794; SfcMSjITIUjgBeAS > 0; SfcMSjITIUjgBeAS--) {
        ujMlrZQJfrZZgvA += NuHwCnBTW;
    }

    for (int bDykeweOP = 558922265; bDykeweOP > 0; bDykeweOP--) {
        MeDGsiCwz -= MeDGsiCwz;
    }

    for (int akLyrirTaH = 1747929663; akLyrirTaH > 0; akLyrirTaH--) {
        UlZUO += UlZUO;
        XWzVj = MeDGsiCwz;
    }

    for (int UTyAImY = 387752960; UTyAImY > 0; UTyAImY--) {
        idrhNpA *= idrhNpA;
        XWzVj = idrhNpA;
        KasVAlpabanj *= KasVAlpabanj;
    }

    if (KasVAlpabanj < -883762.0914128959) {
        for (int ecVdGfQEnlwNHaq = 1117180239; ecVdGfQEnlwNHaq > 0; ecVdGfQEnlwNHaq--) {
            TRnCVSTlzOCn = TRnCVSTlzOCn;
        }
    }

    return KasVAlpabanj;
}

int LCGBKGKqDbRCReoh::YOJMAMiutXoYZs(int GXIdGUZYWCCzguve, bool EbjkC, bool iNTxNLSimxJUHv, double qFkbfZmuzqDycFhV)
{
    string NcZlvAhkYZ = string("PGfsODtiMwiAUcyvvQhGjHnAynrvqvWMuhAHuHCtIoZlIzrcbJdHJiEfKdQrfLkBipxuIVzqYugfqebItKPQEGu");
    double yREIlbPOqRMXQV = 187080.45059319626;
    bool fZIqdjFscPvf = false;
    double hDttG = 469188.49402315664;
    double zwWhMiG = -1000905.8850893665;
    bool lpHiffeWQdq = true;
    double diRnvNgdIDaS = -648012.5349594618;
    bool VttnlQzojKVs = true;

    return GXIdGUZYWCCzguve;
}

double LCGBKGKqDbRCReoh::kXcRZhvc()
{
    bool FkpzqPFkmMoi = false;
    string kctdFl = string("AXQPAztmbzUpOqmBuVlmwgZxRdLYrSSteSGngWvfpFTBIprRHOWAfXIxsyNoCxAGdkZQWiuhXHMezAodpUYndgzkMsRpx");

    for (int kqJgxgxWDlVR = 1409612456; kqJgxgxWDlVR > 0; kqJgxgxWDlVR--) {
        FkpzqPFkmMoi = ! FkpzqPFkmMoi;
        FkpzqPFkmMoi = ! FkpzqPFkmMoi;
    }

    for (int XVubeU = 779599743; XVubeU > 0; XVubeU--) {
        kctdFl += kctdFl;
        kctdFl += kctdFl;
        FkpzqPFkmMoi = FkpzqPFkmMoi;
        kctdFl = kctdFl;
        kctdFl = kctdFl;
        FkpzqPFkmMoi = FkpzqPFkmMoi;
        kctdFl += kctdFl;
    }

    for (int LGWsbWTHK = 395780036; LGWsbWTHK > 0; LGWsbWTHK--) {
        kctdFl += kctdFl;
        kctdFl += kctdFl;
    }

    return -577785.84463301;
}

string LCGBKGKqDbRCReoh::mXzLgSOo(double nwuHVNbzNQDfqSC, double gTFYha)
{
    int LGOcxGPjA = -406205963;
    int hJAqiqzG = -333531715;
    string rqMYMvIEzyVwLdm = string("tjZcQDWMfFfXlmHUVmsVnvLMKWQHCRaFuNTsqMXlNXVSXqniNxJsMAyMZiSImPvCnqbAsExBIrpLGPxDtQajihlNnRpNQAHcxpjTeSgbQFXWqrTVrBZQoTylesNkOQZGMjQfIZXkSsJMFEUGrwMSFCbTrFTymtkchABgCmhOgCTTAmIAhzznpBJFIGqfQHvCWlvEKxHiSqctDpoumRMqbuFJpqSMNsvumvhVtCurOgA");
    bool LDazVXEdLCiez = false;
    int VhmacDHxbjip = 1982042303;
    int TZdUdKWhHIhGh = 107495839;
    double xaqjeBltfUJlWRsP = -466339.174448956;
    string FPnAgzux = string("DnbeummJfTeKLHMGYyrNKGfGWAWmdjwbjuyfLtFdBvfmugMIjrqnYZncxDqJmjKISynsstNoyEvuNaohHSUiaqPcvWDuZbfgNNghfRrarUFLrUzImknwCaJEhEInvcBxKBeFiHIJYcjVClLMaXkXvaEvSYjdnlxHCGaQrWvUheozdvstpICNBRXlrvPOaKJTJHkCqPCsoAjxkTmZLbNIFq");

    for (int ljFVYHKqaCDQ = 140652394; ljFVYHKqaCDQ > 0; ljFVYHKqaCDQ--) {
        hJAqiqzG /= hJAqiqzG;
        VhmacDHxbjip /= VhmacDHxbjip;
    }

    for (int gnwKSxj = 1160273742; gnwKSxj > 0; gnwKSxj--) {
        hJAqiqzG *= hJAqiqzG;
    }

    for (int BOrUngKAyjeI = 1552324891; BOrUngKAyjeI > 0; BOrUngKAyjeI--) {
        LDazVXEdLCiez = ! LDazVXEdLCiez;
    }

    return FPnAgzux;
}

double LCGBKGKqDbRCReoh::qYtpFl(double TOgvkWt)
{
    bool jQuCIIHkYS = true;
    double BZtRGCQJsmjN = -20299.95134932225;
    int ssuCBBMoKj = -397284396;
    string IVKABcb = string("xdZwxTqvOHcndOLdqsIhbpKCjzQKzjfqYRBtiJpGDRujIsIYxwPOkUWmSrtjysykAelfObiVSPnmORitrGoOUJOEQGqcpLNSQXVSkVqReREjAjFRwZxhgyHzwWhcaeWMSwOMNDIitWnKhnjTKQNtkSYyEUnSXkytubosfADmwfeQKXyktBfWJgKIBONixGRj");
    int rZqqFtnkrTUz = 1764489131;
    int GsVirIBA = 1962914631;
    bool IBfWVnSRlKNcKzp = false;
    bool UGFvJ = true;
    bool JpHcMmtIKiHm = true;

    for (int SvgPkklMOFbk = 113818149; SvgPkklMOFbk > 0; SvgPkklMOFbk--) {
        JpHcMmtIKiHm = jQuCIIHkYS;
        IBfWVnSRlKNcKzp = IBfWVnSRlKNcKzp;
    }

    if (IBfWVnSRlKNcKzp != true) {
        for (int UNDyyPKdGrMhhY = 2109256946; UNDyyPKdGrMhhY > 0; UNDyyPKdGrMhhY--) {
            IBfWVnSRlKNcKzp = ! IBfWVnSRlKNcKzp;
            JpHcMmtIKiHm = jQuCIIHkYS;
            ssuCBBMoKj = GsVirIBA;
        }
    }

    for (int eqHVTRLlvHp = 998560178; eqHVTRLlvHp > 0; eqHVTRLlvHp--) {
        GsVirIBA /= GsVirIBA;
        IBfWVnSRlKNcKzp = ! UGFvJ;
        JpHcMmtIKiHm = IBfWVnSRlKNcKzp;
        GsVirIBA /= GsVirIBA;
    }

    for (int LsuQAVILsTmfQ = 483172346; LsuQAVILsTmfQ > 0; LsuQAVILsTmfQ--) {
        jQuCIIHkYS = ! UGFvJ;
    }

    return BZtRGCQJsmjN;
}

LCGBKGKqDbRCReoh::LCGBKGKqDbRCReoh()
{
    this->NOGLhtfC(-1749728809, -469663455, false, -392386.0337016923);
    this->AdaCLhKkVLJJlO(493887.9533111704, -215146.34581979655, false, 60449.46510202014, -2006123572);
    this->engIYgIAqnt();
    this->WjzhG(110226.10415122937, -375301010, -1113410677, false);
    this->FCLuKTqzgXqP(string("DtYehIsJPsmjJkEyNRTbvOaYwq"));
    this->qZJtOyeoQezOWx(true, true, false, 1485727868, false);
    this->YOYHWtDQxgiyb(-427136172, 844145.064399798);
    this->UfWNtCRz(-84135.86040390254, true);
    this->YYGtTBQ(-408908837);
    this->sWreT(true);
    this->yvtBo(-2067022753, false, -499801500, true, true);
    this->iUBtPy(string("UdjktNQfnQcJSuPFkkrfGqlmDGCbELiuiPOAxtuaeDlkH"), string("eOkAuivwUyyhlpMrHjoBtkXKLaqCCDTNuOYZNdcWvFrYjfIVVdXLRZhACqEwlghzxwhmuXGSQgaJnLASAsASSjqtYCYL"));
    this->YOJMAMiutXoYZs(-1158005916, false, false, 718725.0627017019);
    this->kXcRZhvc();
    this->mXzLgSOo(619280.4250664879, -860902.1284280749);
    this->qYtpFl(-909781.4534379077);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sQlJurkQQK
{
public:
    string ynFVyOGosRF;
    double bpUyEqyFxbyTc;
    int eTkTMvwSyyXGzE;
    string eOZlNcABsJsBo;
    int ljIbLYstSeILGf;

    sQlJurkQQK();
    int QPPCYsTUc();
    bool HCPSVnS(double LUEcM);
    bool gHjqtaAJ();
    double FFYPL(bool QyZEafAU, int cMmalEj, bool aBNHZrxWGtgBRuOM);
    int XJJlqScl(int SSVEVUmKMwvTGxk, double lIwMgulyQfZqxmKT, bool BwCdibpVbNYj, bool BvfKpQtZIYngE);
protected:
    string Ehjdz;
    int sqmwyPTRnRd;

    int YaOCTEpWpf();
    bool lBOAiWE(bool IEGEvvBdwap, string bzhxhuciDHLip, bool DTZdWDe, string kuioNfbsRrOk);
    string ElsrphiSq(int pedAADUJJktxILk, bool BuLZReibRnjVwe);
    string VrpwuBH();
    int gazwQiqEGjk();
    int PekgdTxC();
private:
    bool aVjchXAxSTMlPa;
    bool oUmBmrKiSkLH;
    int EALWQIXcWeXf;
    double lMzqqqanL;
    int hqVtLUjwSMTdE;

    void HjnKQeQIG(double gsAwqdoXfAoUHOr, double CmUNCyxWpkMImlCh, int mqcatTwMGi, int LmttWPABPPdY, string lLWDgzn);
    string RzhVJf(int UZgYkvkVTr, bool uHZBKdsrMjSs, string ghYfULhmQI, bool DNpdwTgI);
};

int sQlJurkQQK::QPPCYsTUc()
{
    double WKgbRlYpblxV = -1027622.9957622016;
    int PoWinzzC = -1143975111;
    string RfbDCpvD = string("qKohHTuoFbmwGSPnZGPRabEDbUXCrjsGnUzfGDzdRdBpVacjDktXEYipRfFOgjuhdJdyNOQkjFIFUZmWZhLvqPTAxwdsUcDBuCnoOSioWRfpQXyUfDG");
    double OKiktGHKaT = -333548.81364176865;
    bool CsKefz = true;
    string IjYiHVZ = string("rmroIqkEsMUToCfOgPyqsYsUHQDVcoIfOnfwiAseCCARBUmDWpJlcOoUQytbmnQWKvIGfRzLpcpKJraIqKPXfGuSuTLFfUMJUCljgmkQDusxEZqETyqrAReOlPEjSGBNEaVeGKktBSiRantMDqqGrJJOoXybKdOwZsYezCTxjpfgVHTHbDidOnCVxrrltMDcJaFPXfvvLZuY");
    string ZMGCuVreosv = string("BwclYnHDLkwBaDebiTzbcqMiKZxTpDsfKDraMrfRDRvnXZUpgcVknBjNnrSuSSflGHjiSzPSEnUYtCZNVdzxLSWsGhDtULfqjWswoMwBvvbRLtpNOivupzKwrpoHrRHEOpPhLZ");

    return PoWinzzC;
}

bool sQlJurkQQK::HCPSVnS(double LUEcM)
{
    double xKmxVjedHLkFaSrM = -121019.69059907987;
    int ALUhSZLeebWNR = 455916213;
    double PAZWmpQCACbS = 265886.0210165418;
    int kkhLXzQK = -380303626;
    bool QOIIkrdD = true;
    int wKkgtFVjG = -1017954012;
    int PEYhG = 763809108;

    if (ALUhSZLeebWNR >= 763809108) {
        for (int wKKTBbjCuqUXVb = 465768463; wKKTBbjCuqUXVb > 0; wKKTBbjCuqUXVb--) {
            PEYhG -= kkhLXzQK;
        }
    }

    if (kkhLXzQK != 455916213) {
        for (int pdhyPygcSOl = 1694113773; pdhyPygcSOl > 0; pdhyPygcSOl--) {
            ALUhSZLeebWNR = kkhLXzQK;
        }
    }

    if (PEYhG == -1017954012) {
        for (int jOiINlHMr = 1503619373; jOiINlHMr > 0; jOiINlHMr--) {
            xKmxVjedHLkFaSrM -= LUEcM;
            LUEcM = LUEcM;
            kkhLXzQK -= PEYhG;
            ALUhSZLeebWNR = ALUhSZLeebWNR;
        }
    }

    for (int cpLeUCXG = 736097712; cpLeUCXG > 0; cpLeUCXG--) {
        LUEcM = xKmxVjedHLkFaSrM;
        LUEcM -= PAZWmpQCACbS;
        PAZWmpQCACbS -= PAZWmpQCACbS;
        PEYhG += kkhLXzQK;
    }

    return QOIIkrdD;
}

bool sQlJurkQQK::gHjqtaAJ()
{
    bool UvTVmildpmwN = false;
    double bYRKWbQkJzegr = 435793.9823393844;
    bool llNHNYpbHZlTJm = false;
    string jNUIi = string("RxpOSCMxBsSMrlHHHEWbygZGltmRCAabrUfrYjVvSwtnjBjgYLbrtlbNNPKjmehoDIdolhSnCzlMqRGvLLEKjtLdIKuJiqZCSToceyVplQYgVkDSRozlrjGTLyIGeWpbPwEUTxgGLerBYMvDFICjwojgwstPRUPYmGdYSYzzFpqMkjiHJFesHpreunAtfacAPZxRCGVxSowJAygAZQpJzPKcxTBRAADEnFXn");
    double fGFDTXLX = 205223.46392499807;

    for (int uQSZmiviGxn = 2132832498; uQSZmiviGxn > 0; uQSZmiviGxn--) {
        llNHNYpbHZlTJm = ! llNHNYpbHZlTJm;
        UvTVmildpmwN = ! llNHNYpbHZlTJm;
        fGFDTXLX /= fGFDTXLX;
    }

    for (int lkOnGEHjeP = 331853771; lkOnGEHjeP > 0; lkOnGEHjeP--) {
        UvTVmildpmwN = UvTVmildpmwN;
        bYRKWbQkJzegr = bYRKWbQkJzegr;
    }

    for (int yNmbuITi = 1617535527; yNmbuITi > 0; yNmbuITi--) {
        bYRKWbQkJzegr += bYRKWbQkJzegr;
    }

    return llNHNYpbHZlTJm;
}

double sQlJurkQQK::FFYPL(bool QyZEafAU, int cMmalEj, bool aBNHZrxWGtgBRuOM)
{
    string fmoRYJh = string("uYPOoiYrhnwMLqsDVQFLgFHDqCATHKrhtLhnWFTsKEYMcnuueRpgxPVJdfcJldAvmneiCduDPifLvszeZMWuchAYQbojejqgBaRfyKcffqTeEYCehlwPbSAjLaWmayrSBOwFecLKkJVwfUCuwPJixwbgVkJMeKjpFCPBzrUoVsHMMagOksKzAVkjeekaWVfqonGCYIkOBBNlAhwgmmPVOFuKlexDAJlXTcV");
    bool RbSKG = true;
    bool JLXlRAsJ = false;
    int UNbFPOMjsNo = 850436637;
    double TsxgnCi = -500204.9169681373;
    int jFKiYtGLwFTOHvuQ = -33188383;

    for (int pNlyfBQTm = 825357863; pNlyfBQTm > 0; pNlyfBQTm--) {
        continue;
    }

    for (int mOUBMLrY = 1398962626; mOUBMLrY > 0; mOUBMLrY--) {
        RbSKG = QyZEafAU;
        RbSKG = ! QyZEafAU;
    }

    return TsxgnCi;
}

int sQlJurkQQK::XJJlqScl(int SSVEVUmKMwvTGxk, double lIwMgulyQfZqxmKT, bool BwCdibpVbNYj, bool BvfKpQtZIYngE)
{
    double feCdtzcDUvAjLY = 177298.15375889407;
    string gEFnfkquk = string("jXGRYUfvchDSTOkmStODcKqSzZJDSrYRPEkeKfhDrbprkfpzYYvHGdVXaiffkcjIAWpoescSwZvjZ");
    int KztIG = -2022439542;
    bool DzovrZKsg = true;
    int wOnpGOrPAXKy = -479051167;
    double ncyJyoiTkREBl = -469193.1316991166;

    for (int fOVhOXUJLfa = 1362996859; fOVhOXUJLfa > 0; fOVhOXUJLfa--) {
        feCdtzcDUvAjLY += feCdtzcDUvAjLY;
        DzovrZKsg = ! BwCdibpVbNYj;
    }

    for (int fCOXXRwjkbY = 132289525; fCOXXRwjkbY > 0; fCOXXRwjkbY--) {
        DzovrZKsg = BwCdibpVbNYj;
    }

    for (int ZYQhlUxAh = 585245192; ZYQhlUxAh > 0; ZYQhlUxAh--) {
        continue;
    }

    return wOnpGOrPAXKy;
}

int sQlJurkQQK::YaOCTEpWpf()
{
    string JHYCSLWux = string("utKGPgiQiFedrBASKYuuYRHVifejOYzsUnReVDUmwLRElhXuqYLxcSuyOTXNoJjfRYckRjmpKfQNDilKKVfwEhooPGVNZcKZCAHggIteZdUvPxHWJdDOzIWKFUhvFEpYbyhitoTwgzuVxLnjoEudEhdsLawMiSTmDcuJHJbmxQofbVuMezkZXtRPfWAMWhIWcbENFZavYSiGWVozjTeAmwPm");
    double tGiOsLJoMM = -263514.9082834784;
    string SbOpVXOI = string("KikpnCKzMeUptxPpjtKZRInzdNKwYHdDgpcEMEHcTJiRdxAsdRRAHVUtugTOauOtVDHCEdGZoBlUeqmkVBaOyjKOIALAcqEDmgaTgSyhRgiXqMUmCqIXcJWKsnyTMD");
    int rOBnQycuKfQXN = 923540360;
    double SXlphwhpiNdISeq = -951177.5628845674;
    double GytYIfIpCGDb = 40946.22667423771;

    for (int qjiny = 1850654265; qjiny > 0; qjiny--) {
        GytYIfIpCGDb = tGiOsLJoMM;
        GytYIfIpCGDb = GytYIfIpCGDb;
    }

    for (int IDfUGIvbHJMcCMpP = 615331795; IDfUGIvbHJMcCMpP > 0; IDfUGIvbHJMcCMpP--) {
        GytYIfIpCGDb -= GytYIfIpCGDb;
    }

    for (int ntBFiCsGvTiQvQG = 791030227; ntBFiCsGvTiQvQG > 0; ntBFiCsGvTiQvQG--) {
        JHYCSLWux = JHYCSLWux;
        JHYCSLWux = SbOpVXOI;
        JHYCSLWux += SbOpVXOI;
        JHYCSLWux += JHYCSLWux;
    }

    return rOBnQycuKfQXN;
}

bool sQlJurkQQK::lBOAiWE(bool IEGEvvBdwap, string bzhxhuciDHLip, bool DTZdWDe, string kuioNfbsRrOk)
{
    double FVmzZOEvnNBrC = -762501.7518917251;
    bool RqrBNDXRixy = false;
    double fDgCteKfW = -987754.7979628218;
    double LdfeY = 59110.02745372225;
    bool huASnq = false;
    int uecjMbeg = 229554653;

    for (int dhNMh = 1333921174; dhNMh > 0; dhNMh--) {
        continue;
    }

    for (int xseYOTRH = 407411700; xseYOTRH > 0; xseYOTRH--) {
        FVmzZOEvnNBrC = FVmzZOEvnNBrC;
    }

    if (huASnq != false) {
        for (int KrhrwmilTVm = 1229508254; KrhrwmilTVm > 0; KrhrwmilTVm--) {
            RqrBNDXRixy = ! RqrBNDXRixy;
            huASnq = ! huASnq;
            bzhxhuciDHLip += bzhxhuciDHLip;
        }
    }

    for (int DEOcKgsRZtb = 2146415220; DEOcKgsRZtb > 0; DEOcKgsRZtb--) {
        DTZdWDe = ! DTZdWDe;
    }

    if (FVmzZOEvnNBrC <= -987754.7979628218) {
        for (int ZTwWz = 629139765; ZTwWz > 0; ZTwWz--) {
            continue;
        }
    }

    for (int FzhHEcmOeZub = 475885286; FzhHEcmOeZub > 0; FzhHEcmOeZub--) {
        continue;
    }

    return huASnq;
}

string sQlJurkQQK::ElsrphiSq(int pedAADUJJktxILk, bool BuLZReibRnjVwe)
{
    double KFwzibBMWkVTkwRM = 1042257.9497696353;

    return string("MlUuiNfRZTodLCDPedzkQHlvcbunuUehtdIUGvWMCfEhj");
}

string sQlJurkQQK::VrpwuBH()
{
    string VaOiylQQRCyZ = string("dMKuZMFHQBpiiMeAAPgzdUNowSuUzvFmlSgDlmeXSABewENqWpYCEcUowikIvmLJbaLihvvoVpZIOIbxnGdPFKvUvyTNJXKHJxZOrhCfLHOLPeBsxGInMHtWynnGEFwNXIwaTaVGVXljvEbELfWvOqUkabStPUsXipHXcySlIGnOsfUyLiZ");
    string IrKJdo = string("jIIlXAxRN");
    bool CAaqoOqwfmzBrFM = false;
    double KhiGBzfpzhAwKLP = 852545.6727506163;
    string lYXrTqVXZMBeq = string("UgPPlkIAeeuaomNLIzTfrPHuBFJUEQNGAhEwdnGLALHWOQaYmHzMFtUVRjIMTmnslYqlIZfMArItLTbyKEeuriryUePwrUFNilNYWUSoyivjMAhSGorPsSQkpUwPsXTZDb");
    int NJDmcbMcMXQZfWR = -525835994;

    return lYXrTqVXZMBeq;
}

int sQlJurkQQK::gazwQiqEGjk()
{
    int JAoGrHjD = -727375310;
    double xeFJFX = 45875.4034152867;
    double SahdXS = -956157.5093869129;
    int EbyCybYrLcmRKuoR = -458387253;
    int VyARKubFPmr = 1538489927;
    bool CUOcNrHpkD = true;
    double JENjGvwBFDnh = -227.78939809081464;
    bool AGErFwIukqOQ = true;
    double ZewKq = 248373.47168765045;

    return VyARKubFPmr;
}

int sQlJurkQQK::PekgdTxC()
{
    bool xffjTKU = true;
    int lfvJIN = -1472694629;
    bool lGQXcvtZKg = false;
    int OydLJvXwzKVIpg = 901857457;
    string vVCAgFKPiXhXO = string("HxKXMGsjyiNxmGeNztKygaINH");
    int wYlOVTgRQ = -916215072;
    int gZtHjgt = 439966869;
    int xkFRZsNoNAEKMYa = -1994515610;
    bool YoUkZUNkw = true;
    bool DjMqk = true;

    if (xffjTKU != true) {
        for (int KXfsF = 854710064; KXfsF > 0; KXfsF--) {
            gZtHjgt -= wYlOVTgRQ;
        }
    }

    for (int GPQQbgjJJBtN = 1867561473; GPQQbgjJJBtN > 0; GPQQbgjJJBtN--) {
        lfvJIN = xkFRZsNoNAEKMYa;
        gZtHjgt *= lfvJIN;
        DjMqk = lGQXcvtZKg;
        xkFRZsNoNAEKMYa = wYlOVTgRQ;
    }

    for (int LuvEoRozbcz = 1667257188; LuvEoRozbcz > 0; LuvEoRozbcz--) {
        OydLJvXwzKVIpg /= xkFRZsNoNAEKMYa;
    }

    if (xffjTKU != false) {
        for (int RJmbDEDfix = 1925640177; RJmbDEDfix > 0; RJmbDEDfix--) {
            xffjTKU = YoUkZUNkw;
            xffjTKU = ! xffjTKU;
        }
    }

    return xkFRZsNoNAEKMYa;
}

void sQlJurkQQK::HjnKQeQIG(double gsAwqdoXfAoUHOr, double CmUNCyxWpkMImlCh, int mqcatTwMGi, int LmttWPABPPdY, string lLWDgzn)
{
    double WmeFM = 491262.20884713525;
    bool HnqHqFsZI = false;
    double OdSFntD = 19219.48012110251;
    bool zwEZLwR = true;
    double ekeEAnkiJzwo = 719079.8754058334;
    string IlSEJVNMvrtwAiet = string("WYdMkgNORepwcASrifcPwPvSLZeVmMnVyldSGO");
    double UhzyIHp = -371519.30657301267;

    if (WmeFM <= -811014.2417068911) {
        for (int aEyMkDfUsakJdb = 1441342063; aEyMkDfUsakJdb > 0; aEyMkDfUsakJdb--) {
            gsAwqdoXfAoUHOr /= gsAwqdoXfAoUHOr;
            gsAwqdoXfAoUHOr *= OdSFntD;
            UhzyIHp = OdSFntD;
            lLWDgzn = lLWDgzn;
            lLWDgzn = IlSEJVNMvrtwAiet;
        }
    }
}

string sQlJurkQQK::RzhVJf(int UZgYkvkVTr, bool uHZBKdsrMjSs, string ghYfULhmQI, bool DNpdwTgI)
{
    double XefYPlyCHgdfSbzt = 856106.8941989355;
    string SGSXpzbyMTzdBxd = string("ZpTqeNGqnBiluGhLpqdtwjhfHjaFeAhgSFevmWteUMjNkLxlZyiAMaGRLIWGqygPHhz");
    bool joOlNhHcTEqK = true;
    double OmqGNyEqw = 846079.9562597983;
    int sxjEehvqqIXKQ = -140974333;
    string fpSpC = string("ULjEcXbAUHkaZIyIgqWmWhTiNHryketBwLpJSrHvfaxgDBHKOsgDUjiNgtQnkCRHnFHtpxHWmXrOmcMOnSHQiWLugpYWgmPwyVQAVAHAGFEEDyOKDryEdDanpnVlTOVzqHkQquhfWZpQOieWoMFZbiggGAdRFcPpFZcpuPdAJUiSroOQFxWCejrLHVKnRGHzrSYDxfhwGFVpojOLHcXCDond");
    double pOUpdK = 824544.1852092341;

    if (joOlNhHcTEqK != true) {
        for (int QsHEKDuTzns = 1825849377; QsHEKDuTzns > 0; QsHEKDuTzns--) {
            SGSXpzbyMTzdBxd += ghYfULhmQI;
            XefYPlyCHgdfSbzt += OmqGNyEqw;
        }
    }

    if (OmqGNyEqw == 856106.8941989355) {
        for (int ekDnbTpqMHP = 1326750650; ekDnbTpqMHP > 0; ekDnbTpqMHP--) {
            continue;
        }
    }

    return fpSpC;
}

sQlJurkQQK::sQlJurkQQK()
{
    this->QPPCYsTUc();
    this->HCPSVnS(-209725.41852825662);
    this->gHjqtaAJ();
    this->FFYPL(true, -500145255, true);
    this->XJJlqScl(-2145952394, 364608.5711854164, false, true);
    this->YaOCTEpWpf();
    this->lBOAiWE(false, string("EtSXXQBlJhWRVGSMhVroCsgMjnfgYBWnPfMkRxJrFIBdSypJVpmkncUkQlZLZTaKFklMkfoFoGVAdsokoKhMxBbXCwZH"), false, string("GbGyBZnlUEITsVRymdxJPhMNxZNEgMMlEBwfakegnKhREaxCirFOMKSprufOlALDKoVNODpTjtvJqYzOWDpzhqbYdBtcxulplSlgtbyZEZYEqZnlxVopTVJTXNFQZgqKbhBzkCRNbiJmYdWFlNqQemZTZRrsZBdVEnZrrLujboxhdqinUIUPfuoikCahQiFDtcklVubkVDWMaxZrEHmrvm"));
    this->ElsrphiSq(608003537, true);
    this->VrpwuBH();
    this->gazwQiqEGjk();
    this->PekgdTxC();
    this->HjnKQeQIG(-46760.48297942929, -811014.2417068911, 1015317923, -1251748538, string("OQimHGILgajKm"));
    this->RzhVJf(871998037, true, string("LcAIibwWHeZYYTIDEDLlSWyWmrxMaYDAvkzNUKYvcuGptlEKeSnguhrFFCCFZzkXJQxcFCtdBwCuzhjyfnYMSeCrzwIKHvNZFwxuohUCdGnXhLPNOxWEuBaEMFgjFVMvjGXqteVl"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kEsRXipVBvlt
{
public:
    bool HtMTjUPWb;
    string MMCzGERdCqzmskS;

    kEsRXipVBvlt();
    double ZEJPfNl(double FEpFaqbyu, string EmZZIybw);
    bool puUdHLpBoaISmAj(string rGwSw, double BLvgHHz, bool EwgOZCVYM);
    bool kCoCnLaaSiFW(int bzluMuCRqCLKc, string PlJGHMtZFihQ, double bmOtaWIZs, string VSfWazVlDk);
protected:
    double TjXErMgc;
    int QbohbUaQJpZ;
    string uddEbtCyuN;
    int mfrmCCBMnrlG;
    string DdjxaxbMZVVGwzj;
    string sTpXM;

    int jWzgYiP(double XyHZvAjnqZXKDtn, bool QJthLOEodIMCPI, int OYwNOipUt, double pzNHhYwuriRmAr);
    int jhuoJyyQNF(bool tYGqCFRQHlzAMjGB, int WKfyyRx, double jVjFzGFn, int GrDJNbqsTWXpSf, bool aTlrAMcflcXKOHq);
    bool mGYcJrAM(string ixgPRnWmY, int xjmljCLieYJ, string rKCmrOl);
    double hSzKOjjADl(bool bLvfpNER, double srpUHWz, string QiRMcnhcxnmMUU, bool sQsvQGrhLRIINfdc);
private:
    double WCRUqvRXPkQ;
    bool CNZyeTcnVgDp;
    int HGprwxVbiaCbfwtV;
    bool RRccqCBlYJi;
    double CyNIIfXahfeaZlK;

    bool YNcIPYfYDbKccghd(string ikLGEK, double nDmbTr);
};

double kEsRXipVBvlt::ZEJPfNl(double FEpFaqbyu, string EmZZIybw)
{
    string FbGuI = string("hmAalBwXjTcssipZYtkyCDCVDUhcNwdHhoXoAgWamjRmfZiTPeXGUVLtaSrYnXNqzgtdOpqJXHuENNnKMNzBoXnfyzRVbDNKgjUDAjnmuVsDgSuhHfMScCQJzdRHuVwTCWUSNKrAVauEnfZXrktcpZWXZXAqtHjEeoahqkvJRTXZJzohwxvWGDvWRWrHPHTWNgPqXzYU");
    int GerytNUAUwz = 1743549215;
    double JUORNJ = 912842.8461114191;
    bool BPtJaQMwROa = false;
    int BJkOhy = 1705544656;
    string MTsQeIkXjgVBYb = string("HRyxdNKZRDUjntmRjwztFlSKfomsIFgdrQknSCZiIHxafetLlzIOKnhwgfVSpbdAeChHZMWXEhxbLjgdeMCGEpIATDzeYUtzbnEiJSpjEucSxjIyZMCVtDyWXzVbHoAbCGvvrvmJHfZFyWkMpMFGsmbshecFGDqgFBQXgwDqopuJXEWEKuvQxuFNjTOIxjbyaqCzeHUFFFxswKmPkuwlFmHeSdUfWEbhePaSLuTvkbbFpPuFI");
    int toJKIFqwWsnM = 124374860;
    double uhLGwXIWVQcoTN = -690288.7650411074;
    int oPSmoDWdkn = -416973127;
    bool gjVULbTy = true;

    for (int GafEDwFsZ = 1712498119; GafEDwFsZ > 0; GafEDwFsZ--) {
        continue;
    }

    for (int mjIoqUinUT = 1372817817; mjIoqUinUT > 0; mjIoqUinUT--) {
        JUORNJ /= JUORNJ;
        BJkOhy = oPSmoDWdkn;
    }

    return uhLGwXIWVQcoTN;
}

bool kEsRXipVBvlt::puUdHLpBoaISmAj(string rGwSw, double BLvgHHz, bool EwgOZCVYM)
{
    string JKDyYei = string("oIHLVbgrSRjQBJwMGirxEIUEsaxFRkAHLeKtVpZsCPtbUiFP");
    double MHpTCbwplkDMZF = -264838.5168445351;
    bool pJcEbp = true;
    bool iHtUbbRL = true;
    string BYhOJTgOFiKi = string("DZqSVKwLYgYZOMrlIsVCmYbtHLtHBGzbyThGdPjFeUTVXaXBPuHlNFOxuljscFSzxirkSCVeBdZHFeWHjKlBkTbCgkSDamfoDwOzjsbbbwwlgTuFsjHDTUSwnmvNjFuenhcbfsliNRNjoSCkLnYpZJXgtcBkbVRATbqhMaVgQcBLgcWVqproHLYqNQAAPntUBwlXhFosnIwGRqBibqtwAmyHaZPoYPsRnBTGepPxHXScgvyYbWUEHjSatUPVj");
    double kfgoeqDPVJYg = -709111.3728604831;
    int JqTcRO = -285414602;
    int jzSAcZA = -1139764636;
    bool ySQZJlncSae = true;

    for (int DdZYrjMKqqqICX = 1597655186; DdZYrjMKqqqICX > 0; DdZYrjMKqqqICX--) {
        jzSAcZA -= jzSAcZA;
        ySQZJlncSae = pJcEbp;
    }

    return ySQZJlncSae;
}

bool kEsRXipVBvlt::kCoCnLaaSiFW(int bzluMuCRqCLKc, string PlJGHMtZFihQ, double bmOtaWIZs, string VSfWazVlDk)
{
    double DzqCXVvfVxaPkB = 798889.5155702033;
    int JeJPwT = -1319941613;
    int UeINCTPSZ = -111349946;

    for (int qeLbmNOHrL = 1857299652; qeLbmNOHrL > 0; qeLbmNOHrL--) {
        bzluMuCRqCLKc += UeINCTPSZ;
        bzluMuCRqCLKc += bzluMuCRqCLKc;
    }

    for (int sMazsbzWJe = 1421172560; sMazsbzWJe > 0; sMazsbzWJe--) {
        PlJGHMtZFihQ = VSfWazVlDk;
        DzqCXVvfVxaPkB /= bmOtaWIZs;
    }

    if (UeINCTPSZ < -1319941613) {
        for (int lROsdYZx = 1499245177; lROsdYZx > 0; lROsdYZx--) {
            JeJPwT /= JeJPwT;
            PlJGHMtZFihQ = PlJGHMtZFihQ;
            VSfWazVlDk = VSfWazVlDk;
            JeJPwT = bzluMuCRqCLKc;
            bmOtaWIZs *= bmOtaWIZs;
        }
    }

    for (int GvcmiOXWBwML = 444556312; GvcmiOXWBwML > 0; GvcmiOXWBwML--) {
        DzqCXVvfVxaPkB /= DzqCXVvfVxaPkB;
    }

    return false;
}

int kEsRXipVBvlt::jWzgYiP(double XyHZvAjnqZXKDtn, bool QJthLOEodIMCPI, int OYwNOipUt, double pzNHhYwuriRmAr)
{
    double ZPxSnV = -738375.0530820304;
    int oMBJcyOY = 634304928;
    int cMdYAEqnY = -1670747694;

    for (int OuAxARBmUrh = 80505153; OuAxARBmUrh > 0; OuAxARBmUrh--) {
        OYwNOipUt *= OYwNOipUt;
        oMBJcyOY = cMdYAEqnY;
    }

    if (cMdYAEqnY <= -1501385977) {
        for (int CNpUPVnQSnGOh = 497883688; CNpUPVnQSnGOh > 0; CNpUPVnQSnGOh--) {
            OYwNOipUt -= cMdYAEqnY;
            OYwNOipUt -= cMdYAEqnY;
            XyHZvAjnqZXKDtn += ZPxSnV;
            cMdYAEqnY += cMdYAEqnY;
        }
    }

    for (int DWCoOqpD = 2062721240; DWCoOqpD > 0; DWCoOqpD--) {
        oMBJcyOY *= OYwNOipUt;
        XyHZvAjnqZXKDtn *= XyHZvAjnqZXKDtn;
        ZPxSnV -= pzNHhYwuriRmAr;
    }

    for (int lMNfymxuS = 928308241; lMNfymxuS > 0; lMNfymxuS--) {
        oMBJcyOY = cMdYAEqnY;
    }

    return cMdYAEqnY;
}

int kEsRXipVBvlt::jhuoJyyQNF(bool tYGqCFRQHlzAMjGB, int WKfyyRx, double jVjFzGFn, int GrDJNbqsTWXpSf, bool aTlrAMcflcXKOHq)
{
    bool NRbCVHfy = false;
    double NlQvykRj = -445775.8273343265;
    bool YNyfVqBURLMlgP = true;
    bool ZXNbGDOK = false;
    double vmfmrmgFGU = 35504.09966905243;
    bool IepXtmie = false;
    string vxjkUFkaldqb = string("ghHMLdbRmmLrpZYdFRZuHoynACOKaNxWjpbtnIyITlZCiFpgcXJQrSjvFOaDrFsSZLaYGLOJHOkneeHFZLAFKnkrzCXWIazaAiOwiUsTrxxBJTHiytjOjMkINafSAbJGzUXdUQaGydDZnLHvRaPRapTrauZtfq");
    int PTRPMRLjxt = 510451084;
    bool ntMfLEVAgXc = true;

    if (YNyfVqBURLMlgP != false) {
        for (int PBkiJjAzEpNJz = 811146635; PBkiJjAzEpNJz > 0; PBkiJjAzEpNJz--) {
            WKfyyRx /= PTRPMRLjxt;
            IepXtmie = ! tYGqCFRQHlzAMjGB;
        }
    }

    for (int jYfBKjmvTV = 143449349; jYfBKjmvTV > 0; jYfBKjmvTV--) {
        tYGqCFRQHlzAMjGB = ZXNbGDOK;
        NRbCVHfy = ! ntMfLEVAgXc;
    }

    return PTRPMRLjxt;
}

bool kEsRXipVBvlt::mGYcJrAM(string ixgPRnWmY, int xjmljCLieYJ, string rKCmrOl)
{
    double atWjVNdWgRjmZVG = 872756.5158697816;
    double vQwqNZM = -91723.0070918209;
    string HsNHINIV = string("ghQltLxCBIIHpaOkaNCkaHABegePOLqzvhVYdwGHYDydyRHMAiyOifdHdHREjDcDQifShfPPmVNXgVRbetCQEYcYvliczyWBJxOAjNvxMLdDdMqkQBkeHzSeAEHIhPUMOaUxbkKbFjxCLcDuCubwBEgUBAJqDlTqSALLcLROpWvcWPvePZMigeefBcHestYeBhjbXA");
    bool UFGadmCSGcrVHvQt = true;
    double TIGJGdyRtIXVT = 521485.31313377;
    string PuEbT = string("jnbXKrluatDkPJRQtzGChTFpPXzrLhVIXQggIYFXFPBddIbNICSSovGymmjnuO");
    string SROENAODlvqBfs = string("UNSjGztBddnMzdwvYMGRUFrWMpDEbRWpmbolMAnZcpPXzqRYsdMavFNLYXTpsoteYyPeRYntnzoVErNBpbYfLZbZHCPaPoaclTPFzceIOrNpxmpZkoyYuAvnSUHyWqwaflSDsiLlfgAQiiMqqXICjekjsLPjVXiohVEhDnMDGoOpEOvrwhFohchaoYFWyxQSqOjeEFvZcPFNNjKxXmvqJGaEsoyWwcIEZVBZcIHSeObhuT");
    string QaSHvBLSAvGUtjxC = string("QfNpyMGdMYQmyBkkXKSMeJwYgOnuKtOZpbBILuOLSBEoFuuZTbyxpOUPkvkhKNFunup");
    string vhRGEdWdku = string("mRAevBTVvPuUuKmpuhvZfCvtTqtzlfWoeToEGXLVkFsjNkSbToQKONHhJuQPAtbjdpvlTZLVpXkjlmVDYyWGodeiiJwWgHrmyyqnarXUlVGQfwzwBqMvXaeurJNeIGhYnazfeRv");
    string uXBHbRRoEEMQ = string("uUfqYFrrgSGsSyUMOpurCiUZHMBZIkKrdqmcEJdSljdspGbHdDZQVrTcNGXLUQHUYnffWYMrQqicslEiaFkfkAZnyLFBzYhRCkdnfJfhTODmxDrdYNvhLWBlcRwTvegjMydxNfSxAqejjBBvtrlCoByebqtqGoMMCFKXzYWnUAttpiNlriuXDNNzpWAKZvLOF");

    if (uXBHbRRoEEMQ == string("baLjJbWHzpqnhcFNxjgyvLvHkqDgDvzNAGZTpiGeKyLqIQOxmlHeCxNNYCcNDnvbFSBYKHHnRCKtrmNsFNCqonTnUTtCLfmLBBTLVBnWoYOKYoGXDJuaUDHUrqZOQXghIdeslCSOTVergIyvqSyMYfSqPKzY")) {
        for (int tUvvkKJg = 394054162; tUvvkKJg > 0; tUvvkKJg--) {
            PuEbT = QaSHvBLSAvGUtjxC;
        }
    }

    for (int wxxmTTxwKUm = 1008439270; wxxmTTxwKUm > 0; wxxmTTxwKUm--) {
        TIGJGdyRtIXVT -= atWjVNdWgRjmZVG;
    }

    if (TIGJGdyRtIXVT <= -91723.0070918209) {
        for (int pNnZvQDkuOr = 1377635457; pNnZvQDkuOr > 0; pNnZvQDkuOr--) {
            PuEbT += ixgPRnWmY;
            vhRGEdWdku = ixgPRnWmY;
        }
    }

    if (QaSHvBLSAvGUtjxC <= string("jnbXKrluatDkPJRQtzGChTFpPXzrLhVIXQggIYFXFPBddIbNICSSovGymmjnuO")) {
        for (int xcijl = 8454114; xcijl > 0; xcijl--) {
            vhRGEdWdku = QaSHvBLSAvGUtjxC;
            vQwqNZM += vQwqNZM;
            HsNHINIV = QaSHvBLSAvGUtjxC;
            QaSHvBLSAvGUtjxC = PuEbT;
            UFGadmCSGcrVHvQt = UFGadmCSGcrVHvQt;
        }
    }

    return UFGadmCSGcrVHvQt;
}

double kEsRXipVBvlt::hSzKOjjADl(bool bLvfpNER, double srpUHWz, string QiRMcnhcxnmMUU, bool sQsvQGrhLRIINfdc)
{
    string CHWJBChEZFb = string("ASSUWNQFIYXSYIwvOemJfnVUzXeyJESZXXulmEiXPZWnwtbVJjEBEkP");
    string VTjtrWrijJo = string("RKgY");
    string cQjpXjJFOE = string("LbWKzYBdGlgLAICWtHkqLNQzxjfKWGVYDtNxhvSXmcconadIxEhENOBZgpJoIYyiaHGsbGJTEjLstIvKCnFXGWMADldDrCYMYaUEgdvpxwnWBAGcXuhHeCWZWNpEzLrXkdAkHtTySPwjVcjiUkHxJcvsGkVmJlYxunfthyhWiTvcZhoiowxtFbJVPEKUmQeyXKVQmKcnfiJsIFFOETjcWCGVlCRUDc");
    double seIGsbZqwZg = 507761.5104888726;
    int wyuyhJFeb = 1774286592;

    for (int WgfgtXxFHTK = 1191984890; WgfgtXxFHTK > 0; WgfgtXxFHTK--) {
        srpUHWz -= srpUHWz;
    }

    for (int iyGpRqONGmgh = 2081241273; iyGpRqONGmgh > 0; iyGpRqONGmgh--) {
        CHWJBChEZFb = VTjtrWrijJo;
        QiRMcnhcxnmMUU = CHWJBChEZFb;
    }

    for (int tRGcgLwiKSXmqP = 1892965580; tRGcgLwiKSXmqP > 0; tRGcgLwiKSXmqP--) {
        cQjpXjJFOE += CHWJBChEZFb;
    }

    return seIGsbZqwZg;
}

bool kEsRXipVBvlt::YNcIPYfYDbKccghd(string ikLGEK, double nDmbTr)
{
    bool jnhDFm = false;
    string CpKlnnD = string("aABPSOYWtfSgxZYAVBsKrnZwI");
    int NTTnlYqJOsYiVmdP = -940819159;
    double uTxUpjwMGhHG = 261770.2517199475;
    bool RAmpdiLLiVKOgLu = false;
    double naLjoCiEp = 192707.90240852945;
    double qhQIjDkidf = 940330.3275133272;

    for (int kBMURkyRTNrNUQ = 1331679593; kBMURkyRTNrNUQ > 0; kBMURkyRTNrNUQ--) {
        continue;
    }

    return RAmpdiLLiVKOgLu;
}

kEsRXipVBvlt::kEsRXipVBvlt()
{
    this->ZEJPfNl(483091.00528585707, string("ETXnOFmaiXipiXuyNQYxTVZNCkzNTtGdGGBjbxVGXlbuvXpCIwUqJn"));
    this->puUdHLpBoaISmAj(string("QOvxMUbwZDLdpJvDKlNCMmgHpfbgqQgsOKBUIKKNwWFkAiiocLmFiNgiAqdrnddCxbyCnJtKnCTVndyJIJRwdtiUKBtnzAlTjtA"), -643181.3182262303, false);
    this->kCoCnLaaSiFW(888860686, string("iXxNVWWAKEyuJQKnFEWrCzQsWvOGfcIWOxRDMlURAbVyRgtNxXqOcANEjozgQmzlTtBRXJsxTpiqLoXqNVJBxaALSqJunDeGfnKqKHsIFAXCwHYGTNHsMrLkRgqUDSsCNaiBwqUm"), 203509.38729011302, string("GXzmTjujCUXapvdKtGJLppOXEcUDdkoHNomOEqAGfKEhGEHieupUoCAFOjdlvNXIzKSpThLvYETxvbKGRuhebFNrFduAgOezUfNEkiyijWQCxmfJoyCCNgHquLLrcDJynHoPvtWbouzPdcyfSSVlUjNIbitxMQEdtkBkoNIEAcxWTvGKCTYLTCwmfyByZJkwssiScNWEOeb"));
    this->jWzgYiP(-591740.2764229568, true, -1501385977, -884962.2719629138);
    this->jhuoJyyQNF(true, 2103815392, -1010760.1458365907, 1702485894, false);
    this->mGYcJrAM(string("baLjJbWHzpqnhcFNxjgyvLvHkqDgDvzNAGZTpiGeKyLqIQOxmlHeCxNNYCcNDnvbFSBYKHHnRCKtrmNsFNCqonTnUTtCLfmLBBTLVBnWoYOKYoGXDJuaUDHUrqZOQXghIdeslCSOTVergIyvqSyMYfSqPKzY"), -2067812560, string("qRwJPzVkqxgjKZSpojnfMHECywhfUxSSftZDRSgATehnYeWmCNrbQkwaqZfrHRBfFQdbhBDCRQlWCvuLzmCkROiiFMVDhgcvqzcaxYZNXqnsBlZLVamwwEnqenjQksWMbiWGenmyjMLYzSlMVbJtcEZDxDqMSRhDtgfzigrgiqdEMfJcNOgXrcJlKPSzgsqHB"));
    this->hSzKOjjADl(false, 323587.379573309, string("dWHdwwudLzTYUysLYRPseMtSPPScfXDrrsnuCoxZMErdkfdTkdjiszXfohiDrSLeeXLTOgwcqfJrspGdtbWWCojRPWcWuuQExCFsgrCCICgKUB"), false);
    this->YNcIPYfYDbKccghd(string("rNWoMchLgujPyptUsmLplpAjrwIlKqNSPibgFJZBfULeHynlhlErZKrtFA"), -428450.4140772076);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hqpnXujjhyFn
{
public:
    bool JbtAeMJPyMi;
    int ZATsyGocoOpMobo;
    bool ABidWzZLczqSaNF;
    int MyMTzNNb;
    double PRHeLK;

    hqpnXujjhyFn();
    bool eItHgBQK(string kGhnBwVTdtq, bool SvFoEdcOQoQi, double vgTgQDohrXKbfD, bool nTUUROtVLF, bool jrdpVkd);
    void OLRUPqdnQoiCDTOy(string MYOQWXfa, double LqZFVvkJnEkmmQVb, double TryLrGoiv, int zVFwqpufoMXlzk);
    double hiHIXoocXuTc();
    int ZebsIzutP(string yyqtlpwvntdsX, int IFysRhiFMok, int HwJVFqTJEnaWQudp, int fdtmihgh, double wHefP);
protected:
    string OAEVQ;
    double xzRTTjlv;
    double vhnhOgeNpkHhyo;

    double rAwsufP();
    int fAFwbdVV();
    double qKvLD(string QjeDu, bool BLywbJsumdWq);
    void ZyZsjgUjb();
private:
    double qXgGSFpSAfQEq;
    int pJyXhbdJwwTLbD;
    double yoNKU;
    bool IkxrCGAXZB;
    bool PzLGYnkhVXjAUp;
    double vgkspXqc;

    double jXmKVYKDX(bool GFoKfvVlFsbc, int uiyhSb, int FBMcdaIh, int nsHyKQDmgRfi, double gHsHRNHtQje);
    string EOFWoi(string qDZYhjtuE, string eglGUKqiVOiB, double PJSmSUR);
    bool RRfMVcLFbjK(bool bFEzLVDdf, string SNFsLLctCvGaYd);
};

bool hqpnXujjhyFn::eItHgBQK(string kGhnBwVTdtq, bool SvFoEdcOQoQi, double vgTgQDohrXKbfD, bool nTUUROtVLF, bool jrdpVkd)
{
    double UJAqjQUSWvoUuT = 734143.2948434665;

    if (SvFoEdcOQoQi != false) {
        for (int efqANGYxS = 1741485185; efqANGYxS > 0; efqANGYxS--) {
            vgTgQDohrXKbfD += vgTgQDohrXKbfD;
            vgTgQDohrXKbfD -= UJAqjQUSWvoUuT;
        }
    }

    for (int czsiRILmHR = 496006975; czsiRILmHR > 0; czsiRILmHR--) {
        UJAqjQUSWvoUuT -= vgTgQDohrXKbfD;
    }

    return jrdpVkd;
}

void hqpnXujjhyFn::OLRUPqdnQoiCDTOy(string MYOQWXfa, double LqZFVvkJnEkmmQVb, double TryLrGoiv, int zVFwqpufoMXlzk)
{
    string seZmuFlxTz = string("haSphVixRCoAIwwSWmshRxpRVeBEkPwVzqDXuQFxpYrSgdEgmYvshUeGgcwNgLVAZLCHaGyXxaFkMkSPAkLdikhUVRXxkmSIdClZJQkdPzhJQnsHOXOhEttkHPSABhmygQARUIaKwyvgjudLPFHFrbOVcZfWnNXcotiJqXpdSpCRDtGsjhDdYQLkPyf");
    bool KbQHNQinbnr = true;
    int iKXgJip = -665473747;
    string tbOrAnA = string("ahiAQprJjGNtiWRrKEktmHYNbqepGYoubVyAbvEQWNJSuRBYbZCbcQgzWNbzVcdWfwkweWjeoiqmndVziZtMHyPxYaVTXUrTbJZaieOZBgMvDpRmbJqbqMyjRyhKKRHdMqgZrlTNKoAwUz");
    bool mKePtMLmNRTX = true;
    bool bILSAUp = false;
    double WqGWXMZqEFXp = 69147.37558393103;
    bool WlxbJf = true;
    int jGkKKYXJQje = 362695902;

    for (int XgGcTQWVpetJ = 2105397713; XgGcTQWVpetJ > 0; XgGcTQWVpetJ--) {
        tbOrAnA += seZmuFlxTz;
    }

    for (int nsjeuTA = 1953291159; nsjeuTA > 0; nsjeuTA--) {
        continue;
    }

    for (int sfcyjSfCuaKz = 543768128; sfcyjSfCuaKz > 0; sfcyjSfCuaKz--) {
        continue;
    }
}

double hqpnXujjhyFn::hiHIXoocXuTc()
{
    bool IkRkmhLF = false;
    bool qQIisJjhhDja = false;
    string jtrdRseuiUTK = string("rjDQErQGEnkDIiucUNTMoDltfbfmsifQoxfaBdxKEhLuyloxlzjVGvgkMWedeqpOWrlItqIQhZUxlwvqlhwAjNVxs");

    for (int HOiFRcgFvpmvuFM = 98087078; HOiFRcgFvpmvuFM > 0; HOiFRcgFvpmvuFM--) {
        IkRkmhLF = qQIisJjhhDja;
        jtrdRseuiUTK += jtrdRseuiUTK;
    }

    if (qQIisJjhhDja == false) {
        for (int KoFSsseKUfqpv = 470643866; KoFSsseKUfqpv > 0; KoFSsseKUfqpv--) {
            qQIisJjhhDja = ! qQIisJjhhDja;
            IkRkmhLF = ! IkRkmhLF;
        }
    }

    for (int AGsIaRndVXhD = 1213828235; AGsIaRndVXhD > 0; AGsIaRndVXhD--) {
        continue;
    }

    for (int UJOCDzsxfusOiQd = 1038875748; UJOCDzsxfusOiQd > 0; UJOCDzsxfusOiQd--) {
        jtrdRseuiUTK += jtrdRseuiUTK;
        IkRkmhLF = ! qQIisJjhhDja;
    }

    if (IkRkmhLF != false) {
        for (int msqvIqB = 587725427; msqvIqB > 0; msqvIqB--) {
            jtrdRseuiUTK = jtrdRseuiUTK;
            qQIisJjhhDja = ! qQIisJjhhDja;
        }
    }

    return -224921.89064165746;
}

int hqpnXujjhyFn::ZebsIzutP(string yyqtlpwvntdsX, int IFysRhiFMok, int HwJVFqTJEnaWQudp, int fdtmihgh, double wHefP)
{
    int gqMmPQ = -1649444499;

    if (IFysRhiFMok > 1188442105) {
        for (int ZMUoWmKjcXsvwV = 1367424412; ZMUoWmKjcXsvwV > 0; ZMUoWmKjcXsvwV--) {
            gqMmPQ *= gqMmPQ;
            gqMmPQ = fdtmihgh;
            HwJVFqTJEnaWQudp /= HwJVFqTJEnaWQudp;
            HwJVFqTJEnaWQudp = fdtmihgh;
            IFysRhiFMok -= IFysRhiFMok;
        }
    }

    return gqMmPQ;
}

double hqpnXujjhyFn::rAwsufP()
{
    string HYcclSot = string("TKOLocARgWIbXnFfmyj");
    bool yKyQvPt = false;
    string ktgtg = string("ejDQjMqAEMZTtisViofrHPyjeLmGoUqINBZjcpRRiFtEmMTdhquuUOYjOYKHswFqANypUDQVMqKXxBP");
    double VQrhe = -995375.695964576;
    string QKSZQRCbIBlOk = string("zmPqTQJkfnUkwNUAGtygrmHbSqRoitWXjBrPbgGwqsVvAtYLmZNgVZVQRrykZjPwkMcWdYDHAPXYa");
    int ZfAbThlSfOcZkgV = 1823402372;
    int kypSLvTNWLVGyFq = 124423570;
    string lUqJQuU = string("qfCYdiMVIrDyDXfXFTDidsnowLjNPgLaSPsbVpJDiUWEbGoRPrwwJDlChIvEEEMegtOQQdENLgidPTiTespdAwAUJtqufDurFwTwPUEmsQqHOlSdfIrxGCBHhiojrFnGYENxOqsiEsvmfXAiSNnoPXsjscF");
    bool DIYYTdv = true;
    int VWPaehfqCSbAB = 653110071;

    for (int cUrlwyMinHxIfQVp = 1147295438; cUrlwyMinHxIfQVp > 0; cUrlwyMinHxIfQVp--) {
        DIYYTdv = yKyQvPt;
        lUqJQuU = QKSZQRCbIBlOk;
        VWPaehfqCSbAB = kypSLvTNWLVGyFq;
        lUqJQuU += QKSZQRCbIBlOk;
    }

    for (int rAIcxCUMMgZGDyOu = 1952674712; rAIcxCUMMgZGDyOu > 0; rAIcxCUMMgZGDyOu--) {
        DIYYTdv = ! DIYYTdv;
        ktgtg = HYcclSot;
    }

    return VQrhe;
}

int hqpnXujjhyFn::fAFwbdVV()
{
    bool uIxPggkUz = true;
    int iXQnVukdArE = -396360582;

    return iXQnVukdArE;
}

double hqpnXujjhyFn::qKvLD(string QjeDu, bool BLywbJsumdWq)
{
    string WhaDnAEqyB = string("gkKFQCyjLadoMwwoXvIwXsQCYvRDyFjtlFOjLztqVhKegjzkCLBGMIcMCMQVHcLeXDlFOvDBetVEFmKKcbIibFWPpqEeMfyLf");
    int pljhT = 1055889957;

    if (QjeDu >= string("uphOnYWsYQqpfWGskXWmbYOiFQkjZVuKGsSAnEwNUwhsLkAmNhmmloHzofhWuzTTvntpyddCsUgcAIorRinJHOjmKpztdTKCoYjAmNVvBEUOdbK")) {
        for (int YNrpPVmWmPFTjAd = 988415320; YNrpPVmWmPFTjAd > 0; YNrpPVmWmPFTjAd--) {
            QjeDu = QjeDu;
            WhaDnAEqyB = WhaDnAEqyB;
        }
    }

    for (int FztiE = 2123741006; FztiE > 0; FztiE--) {
        pljhT += pljhT;
    }

    return 66224.88984046102;
}

void hqpnXujjhyFn::ZyZsjgUjb()
{
    int VOCVg = -848349562;
    bool oBLWTeNXRyhuX = true;
    int tkFxiIUKr = 1575193571;
    bool VvcGWMadE = false;
    int arGMYZfhuzjsD = 613238805;
    double rAyZmnCpHmEdG = 540436.7827194008;

    for (int xSvloGBYI = 1202499723; xSvloGBYI > 0; xSvloGBYI--) {
        continue;
    }

    if (VOCVg <= 613238805) {
        for (int gfrdMZYgsEqhHT = 647149699; gfrdMZYgsEqhHT > 0; gfrdMZYgsEqhHT--) {
            arGMYZfhuzjsD = VOCVg;
            rAyZmnCpHmEdG = rAyZmnCpHmEdG;
        }
    }
}

double hqpnXujjhyFn::jXmKVYKDX(bool GFoKfvVlFsbc, int uiyhSb, int FBMcdaIh, int nsHyKQDmgRfi, double gHsHRNHtQje)
{
    string lpirfT = string("qcFWdLUkiUNsMAXMBAcYLuUKtzZejakKKBtuquQIUAGrPUEGhOitrKebeJKGIpbxlEDCiFMiiTSHXnKOjxuMmZDBqPUPdUTyXXxHziTN");
    bool uehvVOYLzbovFfO = true;
    string dAuAjpuVuG = string("bItZaHKOqvunhCWowesmRWoaVhQpKJlssFoPOryyRhVxqLnosnbCWsOVzbjVpANUTWRoDhYStqSXeDNvcPzgozxYbxb");
    int jolVtLYggLPnMWH = -839292528;
    int yoLhngfutUftXz = 1025688358;

    for (int PCTsbbwvxrku = 1430158524; PCTsbbwvxrku > 0; PCTsbbwvxrku--) {
        uehvVOYLzbovFfO = ! GFoKfvVlFsbc;
    }

    if (uiyhSb == -254634790) {
        for (int kXqVpQ = 1564294641; kXqVpQ > 0; kXqVpQ--) {
            continue;
        }
    }

    if (uiyhSb < 1025688358) {
        for (int HqfNwgAMd = 1622913729; HqfNwgAMd > 0; HqfNwgAMd--) {
            nsHyKQDmgRfi /= FBMcdaIh;
        }
    }

    if (lpirfT != string("qcFWdLUkiUNsMAXMBAcYLuUKtzZejakKKBtuquQIUAGrPUEGhOitrKebeJKGIpbxlEDCiFMiiTSHXnKOjxuMmZDBqPUPdUTyXXxHziTN")) {
        for (int NeeHOZQzqrAIG = 687840902; NeeHOZQzqrAIG > 0; NeeHOZQzqrAIG--) {
            lpirfT += dAuAjpuVuG;
            FBMcdaIh *= FBMcdaIh;
            yoLhngfutUftXz += uiyhSb;
        }
    }

    return gHsHRNHtQje;
}

string hqpnXujjhyFn::EOFWoi(string qDZYhjtuE, string eglGUKqiVOiB, double PJSmSUR)
{
    double gqIlCSboETm = -618826.2621003999;
    int MZRljeBcz = 1638798227;
    int UkMZl = -1245793319;
    bool kzwIElIumwoTW = true;

    return eglGUKqiVOiB;
}

bool hqpnXujjhyFn::RRfMVcLFbjK(bool bFEzLVDdf, string SNFsLLctCvGaYd)
{
    int jtuldB = -989348837;
    string pLfBsGcIvtTe = string("SxuhIiVxHEscjZthquHPQrODwmLUWUhcGxrfeSQyKrwlyvHfGdpSKkgRJbsyWKecOAzgtdKzOydQgfLelzgQtOLZUgMkKcZMhFZhDfnWFQQXQMbPoQwMVJgINKYnViNIxEyGwZLQVulkAnsGnAylUBEYgbhOLEovrzvxGnd");
    string aimlZIE = string("JbdkCkyFQEMsuHdPqEJdSNSyfUxhayzlvlArUWWggQTycSlJddGGGLrBWCCNcewnDoWLSOdDyWMmqqMyuBwBjqbYVvkbBGEiiwBPJcovhEVKNcO");

    for (int qrCjopZ = 548435083; qrCjopZ > 0; qrCjopZ--) {
        aimlZIE += pLfBsGcIvtTe;
        aimlZIE = aimlZIE;
        SNFsLLctCvGaYd = SNFsLLctCvGaYd;
    }

    if (aimlZIE < string("SlUSWhDrBRbeOzfwouHrriqKiHpLHesrZJRCMMMUIVRbtBAHNdbsTNneXRydmssCHGbVeNyrVBDXfxNMdEdCCyloDuAlPaYTcXlCFxmXyxRmLSUvaOkwARoDKZiTQxOPtVEcmGyfAJchpumChimESTeohKXkrZiDbaQFhZb")) {
        for (int dfmKTXGs = 1738180442; dfmKTXGs > 0; dfmKTXGs--) {
            SNFsLLctCvGaYd = aimlZIE;
            bFEzLVDdf = bFEzLVDdf;
            SNFsLLctCvGaYd += SNFsLLctCvGaYd;
            pLfBsGcIvtTe += pLfBsGcIvtTe;
            pLfBsGcIvtTe += pLfBsGcIvtTe;
            SNFsLLctCvGaYd += pLfBsGcIvtTe;
            aimlZIE += SNFsLLctCvGaYd;
            pLfBsGcIvtTe += aimlZIE;
        }
    }

    return bFEzLVDdf;
}

hqpnXujjhyFn::hqpnXujjhyFn()
{
    this->eItHgBQK(string("ExVNFxAuWWaZIvAVXxPfNmbyhKiBhpRJgFuecgmDDTyweYpnYIKjXRcvosgcjURCYqxNQqhiiGOdqhpWnhUIiWLVTWGvsTDexODFbyNhfvWzkAGscpcxvcSptWwTAbRwUAdGUwEREkCwxwdRxBqstiIkYmvoNVREJcmEbTKTkxIfrtRAkUKQnhSfnrNVKErrYNsRYPHjObEVUABeJmaReFlsBZTorBpsLYmYaNewLAcZSzOtoYweCYRAy"), false, 509841.07720387, true, false);
    this->OLRUPqdnQoiCDTOy(string("cijIJlSatdhiqUAfeZgvLfFMStYzluWoxNLxwYdhcOoGvaTXmAXLMOyOyUrFFdRGrSnoxaCzJjUMDvQQZRmbffSNUBmcwLPayLmalklOVmiIu"), 150216.04342057818, 847575.4933150201, -68535610);
    this->hiHIXoocXuTc();
    this->ZebsIzutP(string("aTbtY"), -900474666, 1188442105, -1812711746, 362063.2282499247);
    this->rAwsufP();
    this->fAFwbdVV();
    this->qKvLD(string("uphOnYWsYQqpfWGskXWmbYOiFQkjZVuKGsSAnEwNUwhsLkAmNhmmloHzofhWuzTTvntpyddCsUgcAIorRinJHOjmKpztdTKCoYjAmNVvBEUOdbK"), false);
    this->ZyZsjgUjb();
    this->jXmKVYKDX(false, -1725943132, -1175342665, -254634790, -756810.996863328);
    this->EOFWoi(string("JswQTdwdDAjxzSSkMorDCAClEIuDcPHbZkTJNuOxOFhNAapoIgcKSKrqTIdBZHmxcfbDPGfidRRmdvCoHWaxNVNehqzdeYXKVAEiZTXytQPzxeppNkkLvTKISpmbRDeQDOeOtiObUcYFusPVUGbsPDqiMpRDCI"), string("kjzVHAJjnopRAuapztoxXasmrzOHmCJzdFKPtPvJhzdrEULQcvmAQPRpsMlNXCpUGuSQD"), 327121.9678519342);
    this->RRfMVcLFbjK(true, string("SlUSWhDrBRbeOzfwouHrriqKiHpLHesrZJRCMMMUIVRbtBAHNdbsTNneXRydmssCHGbVeNyrVBDXfxNMdEdCCyloDuAlPaYTcXlCFxmXyxRmLSUvaOkwARoDKZiTQxOPtVEcmGyfAJchpumChimESTeohKXkrZiDbaQFhZb"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DIRPG
{
public:
    bool YzwYSubZtA;
    double svLxl;
    double uXZGULPkyG;
    double kXGlGCzq;
    string pxdWfUwrKUSUCq;

    DIRPG();
    double PJTdmuvVugQJaFMt(double NQUFqbLYMwX, double jgbpZXYmT);
    bool MEbmybg();
    string pUrDVAAeogDheJHQ(string gkgcDpntcBA, int FgVrUPFgbXtZYc, string wDqldDHOqf, bool GKIqFsJu, double tBMzxZyIosSMLy);
    void FIkoXj(int hUEtv, int HaPHKGo, bool BvOuGGiJALaY, bool RfiLIfKt, double LiAXDJK);
    string mJJer(bool NjVlWhmwtKXoiYcK);
protected:
    string OaRRdjpLxq;
    string faOxKqSFuzaT;
    double SHyqIs;

    int LVwmMJDsZ(double vGVjCKnlgpBZmKN, int LXALYKgsOgyh);
    bool pZOoMpHykK();
    void WWtNeRyW(string OTDGqZhRXPw, string NKLTCSQwZvkKFs, string rqrhBntllpOLou, string ibvfxu, bool boHwIdDgsjkfM);
    bool WIosORkQ(int dVMiYjSYUyGaBH, int OLApkkiNGVzyCf);
    int IWRTyVSEQbvchXeX();
    bool uhyEKb(string xviRDWqcaqTo, string bxIsFLNZMP, int BEzXi, double kxhfrmphNWx);
    bool nVgeX();
    bool dmPJG(double uaUvYCa, double bBfsmqMMnNyk, string aQVIy);
private:
    bool WECrbM;
    int pKCEIdU;

    void xzKcm(double WFTBHAoagk);
    void BnmqCMS();
};

double DIRPG::PJTdmuvVugQJaFMt(double NQUFqbLYMwX, double jgbpZXYmT)
{
    int VqyHNNafpdZqPdM = -696151210;
    string WZgsdbtSOuxAtHl = string("KVDOmUBVcmoHCZdOHnwbIbHYdybrATjVogFrJwzNsJyAtSbpXifnLXiawRomUrmyzuazhHQTCiuCakekxlFmWnfTRzLAUoRObmZFxHFTqvJuBJcEhJDsAoXGVQJrbWFCgDLLnxmRlxoeGNICqZGBDnvMvUyaeWMJNmCuLmOTqhiEZKrTaQDHVeVZpwveZxFWXBRnYxbrlbcHzBCfvJoEAsmMxWbuQOmgmetQrOEFGd");
    bool bXkHfnAGQtseeav = false;
    string GMkwybRfFgt = string("qRpAxwTPUWUGUkzCZG");
    string zTISNxuzHiWsde = string("gbetqjtLoqfgFfFkGPqooIUhthtNcQfkmBZbrAAPUdyAiddjVatKbyoQFtXAfCXNThwFAUsuBC");
    string aofQM = string("dNswuSmfecDUjoRbnBcwMLmcVBfTToHLedkqZzSLYoDLYFCbtvWmPFEaRNmWIzyldWznHAgoaLAbAdcArlSCmJNixiUHOWczyUKJFFicmMDCxkrpMJIflgRQJRczsJGvhsXOCLdOOxTIIpSAbILyDCdukRigcevNzVWwBVOGbIVbEELyvMeAdtHDYqfmsKTZCFbm");
    int SNzNNAkTmJjP = 1654943234;
    string xDFfZvGLCYH = string("QdRKAECbMnyyOXARhAwzzurAvlwpQUPGPhvn");
    bool whDrBknFGEC = true;

    for (int LYoASjsP = 654617796; LYoASjsP > 0; LYoASjsP--) {
        NQUFqbLYMwX *= jgbpZXYmT;
    }

    return jgbpZXYmT;
}

bool DIRPG::MEbmybg()
{
    string nPHGUjv = string("rJqbBcByjlSgXvZDjNqEfeEOGdLqcWjzIVbkRQuTfqCaRgYZdteOTdcOmlOquKhaxargRjQykvWvHiXPWdUIStwdnRubtxNMJgcYhKYAyUDDsBGoKVMYwbTtRPMDJwHmtvZVmpEsbpwhnfaxGWpZRbeykIszKsGfvBHGUsvfQNuaNOfyMCOFTEVjRsLHBPtbRHyehqVHwXVHEMHfcMebXHWpqnSnN");
    double urQEaEh = 179226.02260025628;
    int YaHJUCLKnLENw = -989631195;
    int gLTsUC = 314939856;
    string EKmlrtVxVqC = string("lvqqqqloDXaoMeAPAQJzIVfOZOcQwhboStquIZdgVDJOLdDZexKBYuHhhEpmUYjbGxJmWPJRBgFmlYYTUgHZbtlyZkxbRUJGGvHPvnoDdxVlvpSkBezLINiioYEtjpZYEZhFXaCqFfNeYFhAsFmhyAaHVrqUScFRZPQXpuJLlHHBnCNqttDtynPRoEODSmxj");
    int BBXbDA = 1497273609;

    for (int hOPeLMsOJcIUKkK = 906762505; hOPeLMsOJcIUKkK > 0; hOPeLMsOJcIUKkK--) {
        continue;
    }

    return true;
}

string DIRPG::pUrDVAAeogDheJHQ(string gkgcDpntcBA, int FgVrUPFgbXtZYc, string wDqldDHOqf, bool GKIqFsJu, double tBMzxZyIosSMLy)
{
    double ftNod = -851281.0755281181;
    int DCJkFyuUbUMZ = 1329144321;
    bool wwrdMYiSBjrdH = true;
    bool WnRGVYKda = true;
    int SpipizaqPby = 1892120606;

    for (int SsfWo = 1992767711; SsfWo > 0; SsfWo--) {
        continue;
    }

    return wDqldDHOqf;
}

void DIRPG::FIkoXj(int hUEtv, int HaPHKGo, bool BvOuGGiJALaY, bool RfiLIfKt, double LiAXDJK)
{
    double ahaeJzoTSDaAyqF = -181150.47409572545;
    int QyIDEmOOQIRdgLhe = -1082610781;
    double MsbxkonJdqaj = 216132.6305671517;

    if (ahaeJzoTSDaAyqF == -683674.3652396288) {
        for (int XQZMyoj = 791513850; XQZMyoj > 0; XQZMyoj--) {
            RfiLIfKt = RfiLIfKt;
            QyIDEmOOQIRdgLhe = HaPHKGo;
            LiAXDJK *= MsbxkonJdqaj;
            MsbxkonJdqaj = MsbxkonJdqaj;
            QyIDEmOOQIRdgLhe *= HaPHKGo;
        }
    }

    for (int zaVERainm = 1953261744; zaVERainm > 0; zaVERainm--) {
        continue;
    }

    if (ahaeJzoTSDaAyqF > -683674.3652396288) {
        for (int mKOZquSzaMnHuQnJ = 1621780915; mKOZquSzaMnHuQnJ > 0; mKOZquSzaMnHuQnJ--) {
            hUEtv = HaPHKGo;
            LiAXDJK -= MsbxkonJdqaj;
            LiAXDJK = LiAXDJK;
            BvOuGGiJALaY = ! BvOuGGiJALaY;
        }
    }

    if (HaPHKGo >= -1082610781) {
        for (int cJfQHi = 456351632; cJfQHi > 0; cJfQHi--) {
            continue;
        }
    }
}

string DIRPG::mJJer(bool NjVlWhmwtKXoiYcK)
{
    string JjUtvIpFDDz = string("KkTSTdCWadgXWaQQNBWhdACxDloCPYjtfuIWuYhTJemLtHBUbjOFSHmonPkAPeacOeMIDGYutFvkvkyjcwCIgNJuJsMRUWxUODZSDIoClHKDgkFSVFOoiPEDMkmuqsJDcxS");
    double AuDwZFVLF = -223934.3378875027;
    bool fWHiQW = true;

    if (AuDwZFVLF > -223934.3378875027) {
        for (int hcobpHXMcVtS = 152620236; hcobpHXMcVtS > 0; hcobpHXMcVtS--) {
            continue;
        }
    }

    for (int ZKanf = 1023173488; ZKanf > 0; ZKanf--) {
        AuDwZFVLF *= AuDwZFVLF;
    }

    for (int sWefNYROfaIij = 96447080; sWefNYROfaIij > 0; sWefNYROfaIij--) {
        fWHiQW = ! fWHiQW;
        NjVlWhmwtKXoiYcK = ! NjVlWhmwtKXoiYcK;
        AuDwZFVLF *= AuDwZFVLF;
    }

    return JjUtvIpFDDz;
}

int DIRPG::LVwmMJDsZ(double vGVjCKnlgpBZmKN, int LXALYKgsOgyh)
{
    double lsQLzwajYKErT = -362825.56832211;
    double cSEVdqBej = -549507.7077310489;

    for (int vApWKbqJujDqOnv = 1111594819; vApWKbqJujDqOnv > 0; vApWKbqJujDqOnv--) {
        vGVjCKnlgpBZmKN *= vGVjCKnlgpBZmKN;
        lsQLzwajYKErT += lsQLzwajYKErT;
        LXALYKgsOgyh += LXALYKgsOgyh;
    }

    for (int yvfpGF = 217801084; yvfpGF > 0; yvfpGF--) {
        cSEVdqBej = vGVjCKnlgpBZmKN;
        lsQLzwajYKErT = cSEVdqBej;
        cSEVdqBej -= vGVjCKnlgpBZmKN;
        vGVjCKnlgpBZmKN += cSEVdqBej;
        vGVjCKnlgpBZmKN /= lsQLzwajYKErT;
        cSEVdqBej -= lsQLzwajYKErT;
    }

    if (vGVjCKnlgpBZmKN == -362825.56832211) {
        for (int amUeGTZAjeiMAV = 1664922179; amUeGTZAjeiMAV > 0; amUeGTZAjeiMAV--) {
            cSEVdqBej = cSEVdqBej;
        }
    }

    for (int ilfaly = 516197118; ilfaly > 0; ilfaly--) {
        lsQLzwajYKErT += cSEVdqBej;
        LXALYKgsOgyh += LXALYKgsOgyh;
    }

    return LXALYKgsOgyh;
}

bool DIRPG::pZOoMpHykK()
{
    bool AZsoqjYlQJiZOCt = true;
    double jGdviMnCpIRIjZ = 297525.3309444759;
    bool LHUWlArQXarrL = false;
    int ssyOQPxysIf = -1593966509;
    bool RrxusgWCajgPsgeN = false;
    bool zxTCOpfxkSSa = true;
    bool awdynIqxOr = true;

    for (int pFtyzjybBxNFxxdU = 2124629680; pFtyzjybBxNFxxdU > 0; pFtyzjybBxNFxxdU--) {
        continue;
    }

    if (RrxusgWCajgPsgeN == true) {
        for (int ELRlD = 295931701; ELRlD > 0; ELRlD--) {
            continue;
        }
    }

    for (int UnvbY = 2059842675; UnvbY > 0; UnvbY--) {
        LHUWlArQXarrL = ! zxTCOpfxkSSa;
    }

    if (zxTCOpfxkSSa == false) {
        for (int XMTFBpN = 18606314; XMTFBpN > 0; XMTFBpN--) {
            LHUWlArQXarrL = ! awdynIqxOr;
            LHUWlArQXarrL = ! AZsoqjYlQJiZOCt;
            AZsoqjYlQJiZOCt = RrxusgWCajgPsgeN;
            RrxusgWCajgPsgeN = AZsoqjYlQJiZOCt;
            awdynIqxOr = ! AZsoqjYlQJiZOCt;
        }
    }

    for (int tLETfBVwrez = 277571115; tLETfBVwrez > 0; tLETfBVwrez--) {
        continue;
    }

    return awdynIqxOr;
}

void DIRPG::WWtNeRyW(string OTDGqZhRXPw, string NKLTCSQwZvkKFs, string rqrhBntllpOLou, string ibvfxu, bool boHwIdDgsjkfM)
{
    double vSOxdGlVRj = -741450.3456385595;
    string edXvhSxs = string("ojRGIKtidoEBvDmTFCFkIbRrJeiqIzrFpKtJPIHHWXcNdXvDlvj");
    int CmUAJrKhQAaSsbC = -1105709523;
    double FhLflmqqjzodwPuT = -213418.776347997;
    int OhviZJfXiQQCJIoW = -1328520835;
}

bool DIRPG::WIosORkQ(int dVMiYjSYUyGaBH, int OLApkkiNGVzyCf)
{
    string SswWsBAjd = string("IkZmHoOyNcFcmtLQtIFnqVgWBuMepsioEPCHpBbtwcKlwwGwrCOsdINCqKQFNCVuosBOLGsdlEPrKL");
    bool wBwcPd = false;
    bool iXZtUgJIa = false;
    string TdknbmAkkTxBXb = string("OHCbYazQdwzGIRrCkRIDtoHUcqeqKBFvIhQDphDUxiAXdLKDfWaXYDOLTmOKrbWNREsMdcLERpGwjjPGtsqLasTQvhEaUuRimFynvuTvgIqPLbAvnlcjdxpiontxrXJzjcabGlCmZYbvVVhMHeasMj");
    int PlfnNRWOeK = 664420707;
    bool BMsryDVJEYRNbJU = true;

    for (int zztxItqaYyfcnIST = 513069794; zztxItqaYyfcnIST > 0; zztxItqaYyfcnIST--) {
        TdknbmAkkTxBXb += TdknbmAkkTxBXb;
    }

    if (dVMiYjSYUyGaBH <= 664420707) {
        for (int sCEiNAyYYv = 1782957668; sCEiNAyYYv > 0; sCEiNAyYYv--) {
            BMsryDVJEYRNbJU = BMsryDVJEYRNbJU;
            dVMiYjSYUyGaBH *= PlfnNRWOeK;
        }
    }

    for (int rrPDtQoU = 595726707; rrPDtQoU > 0; rrPDtQoU--) {
        wBwcPd = BMsryDVJEYRNbJU;
    }

    if (TdknbmAkkTxBXb >= string("OHCbYazQdwzGIRrCkRIDtoHUcqeqKBFvIhQDphDUxiAXdLKDfWaXYDOLTmOKrbWNREsMdcLERpGwjjPGtsqLasTQvhEaUuRimFynvuTvgIqPLbAvnlcjdxpiontxrXJzjcabGlCmZYbvVVhMHeasMj")) {
        for (int WoXplMqfsjEV = 2018793248; WoXplMqfsjEV > 0; WoXplMqfsjEV--) {
            BMsryDVJEYRNbJU = wBwcPd;
        }
    }

    if (wBwcPd == false) {
        for (int fhDyujaYLly = 1403930528; fhDyujaYLly > 0; fhDyujaYLly--) {
            iXZtUgJIa = iXZtUgJIa;
            iXZtUgJIa = iXZtUgJIa;
            dVMiYjSYUyGaBH /= dVMiYjSYUyGaBH;
            wBwcPd = BMsryDVJEYRNbJU;
        }
    }

    for (int nbscNDMCaite = 789421700; nbscNDMCaite > 0; nbscNDMCaite--) {
        TdknbmAkkTxBXb += SswWsBAjd;
        wBwcPd = BMsryDVJEYRNbJU;
        iXZtUgJIa = ! wBwcPd;
    }

    if (wBwcPd != false) {
        for (int wIyKVGoeZisfCg = 1239484325; wIyKVGoeZisfCg > 0; wIyKVGoeZisfCg--) {
            BMsryDVJEYRNbJU = ! BMsryDVJEYRNbJU;
            TdknbmAkkTxBXb += SswWsBAjd;
        }
    }

    return BMsryDVJEYRNbJU;
}

int DIRPG::IWRTyVSEQbvchXeX()
{
    string PkRakM = string("UAeYtCRosdJnyGGuGlObicmmbOeTdjETddONixSeLrBxhcKqHeQNMOqABSeBiGutMERhyBXAOJXOJJtJlHSuqVVQxvByjdcaYwuzzX");
    bool YkYZTcBh = false;
    double kvDtJjXetPziAQ = -696595.9104267531;
    double VgQmuMOfTk = 669988.7184835873;
    bool GiLWyOfgGeHNx = true;
    int WWQtbbbcyD = -1773076584;
    int LxivFAB = 575664905;

    return LxivFAB;
}

bool DIRPG::uhyEKb(string xviRDWqcaqTo, string bxIsFLNZMP, int BEzXi, double kxhfrmphNWx)
{
    string omzyE = string("ljjsXLUJFcNVCyUqysBYCIAfDmLCxRRndXOLUawXqvJeMQjoMzBxdJoHsEWLrkMXwofWamWEOGAaaaUzGQQuqUITeMz");
    string txHSS = string("CzYfYqtdesXCqBnqGlEvUtZgDEOuTXNLNbdcrzYVHdeceCfdvpbmElmufgLhZFFySujCPzfQeEjTINURNRvGBovbVtUjQsmEnjgWpZRSPCIYfoEnbGMWSxrdFlQLasENYXQXPJiFBgXjpDPyXzBYbDjLjMZPKhUjRQruwOROLtpgYplCzobmbENvcmmnQJNeGJHMuEhTTqRHazdmbiJfOICITVjLPqhZxAFRKxjPhUdmccbblrRmHgh");
    int rvfKPPZwjzjxOt = 1480680061;
    string usfZBlXUBqGceoUW = string("QGekcrRhiEfKnfTEksEOHFjyZeYqfkgtyrAsNZoRYRTViATPacpyfVnFUMnaFrFxgVMcYPFvEFNgNVmiwMZvupwrAlLXTGTVzdJWadwwIuveDKuTkj");
    double fJcjJrSGBxvcRd = 295971.84421357804;
    string YmlxvvseYFiigiCp = string("tkTNTiryDeocQirgKvimoJTIHUSxjyWUGmacQacDDIiCqovlfEIMlGueCIYZxIaKVyWoUKk");
    int jZwaHFhvSrC = 72196676;
    bool olQso = true;
    bool vhcaHDTwOV = true;
    string alRNWaBJPP = string("vHmlbsTKlsCAJdcJEbVEcjOsFUwFAfMkdJdpoOVHxrrOlUUJyQKQsyilxjPVoNqNTKNeviSLKp");

    for (int aCxDU = 1135054880; aCxDU > 0; aCxDU--) {
        xviRDWqcaqTo += omzyE;
        omzyE += usfZBlXUBqGceoUW;
    }

    return vhcaHDTwOV;
}

bool DIRPG::nVgeX()
{
    int mHpZhB = 1282567858;
    string owJRFPSXhsKHDCO = string("XscxrbcpOPwJrBvthtHZhexLZDuDgBgHaOTdUMrvGWKXUsWQjYSugoDQNcRqdJMzaBLwnHvJMilgiuPZYdkhjZpKh");
    double OkYkUGClOVp = -575211.8269950913;
    string xGTyavJTU = string("WerotNwVpmQCwjZwQsVnnggYHJvIkenaBhQdYjFZOXZADPGrctzqWKZOndemWNtxSHNZoMcJmnYflKsMJKTqOgSnfzcZGXRGQDWnwRmaCOcsepjqRRIVYQtbnAaeoy");
    int NKCPNWR = 1026846728;
    string UwTlTByLZah = string("TrutGNgkLvFuvjBpbwDAjOgXViopRnJwiyQgOmeBWPsolZxLfUWmouDpuiVHDzPMKLNlPtUJKPjjVNSTxBRvQtfHMxVyooxUyDeptYcrnwRzoPsZhyzXxoXGhW");
    int yGuRWz = 23174808;
    int zbjDFJNCHuyajbf = 1053618500;
    string ErkvzPxgqx = string("twZHNRujPiDIVFCFyuowEeaTWhtKQIFUOBgmuEihuYKgkDQnYMaSRZiVCJlw");
    bool qiPZztWfDryepa = false;

    for (int quExANDVGrTWePl = 1953164034; quExANDVGrTWePl > 0; quExANDVGrTWePl--) {
        zbjDFJNCHuyajbf = mHpZhB;
        ErkvzPxgqx += owJRFPSXhsKHDCO;
        xGTyavJTU = owJRFPSXhsKHDCO;
        OkYkUGClOVp /= OkYkUGClOVp;
    }

    for (int raiTkMYrigDQ = 1016604177; raiTkMYrigDQ > 0; raiTkMYrigDQ--) {
        zbjDFJNCHuyajbf *= yGuRWz;
        yGuRWz *= yGuRWz;
    }

    return qiPZztWfDryepa;
}

bool DIRPG::dmPJG(double uaUvYCa, double bBfsmqMMnNyk, string aQVIy)
{
    string wSrlvpUgsJpWKsRg = string("eadagGqMhCfgIAqwDNPxEQqpmrMsaoKpnLdTOJFRPdcYIDqZabbAMfDaTHnNsPzPvzLeUfgyoOxezVgENbysGMWy");
    bool SkLHxgZTZjirfjeD = false;
    string SKCpn = string("PW");
    string QZOIiwMXS = string("rPMsjUhFCEeYicZDhrgkWIAoJGRNdMswMvsQCOXeFArbcLktDZIbZJShuZNpUwRpFHecQuDesClOTFCQzFzeajczstTTBjStvKqcBsFptLRkMHEnqNswIFogfPeakBMwJcKusrCVXUYcchvclajTZJVfSbtNeeBVFWD");
    bool JolPtbKCvmmghsI = false;
    bool RWoSMBfOY = false;

    if (bBfsmqMMnNyk >= -677708.6468391207) {
        for (int sTArOZomgXUw = 1608171097; sTArOZomgXUw > 0; sTArOZomgXUw--) {
            RWoSMBfOY = ! RWoSMBfOY;
            SkLHxgZTZjirfjeD = ! JolPtbKCvmmghsI;
            SKCpn = aQVIy;
        }
    }

    if (SKCpn <= string("tmzEyYojBiyGMYqxZbZtgnvdrHvVYWAfcKLKkvojLqtCZFDfaKJgSDPpPBBcXoATmWHfzRbOygRYXFiDFaExEesguMmSmssjvmxxHgcnAcgLPcxVVoudEardYqJJjAGLiFoPVGTOdJgArwUpdOObSJKDeCkMkGRcDjSfgft")) {
        for (int xYQFHJp = 1979973535; xYQFHJp > 0; xYQFHJp--) {
            RWoSMBfOY = RWoSMBfOY;
            bBfsmqMMnNyk += uaUvYCa;
        }
    }

    if (uaUvYCa >= 1034392.1740898135) {
        for (int zKRkvWaUyVG = 1303153405; zKRkvWaUyVG > 0; zKRkvWaUyVG--) {
            continue;
        }
    }

    return RWoSMBfOY;
}

void DIRPG::xzKcm(double WFTBHAoagk)
{
    int kxucfnL = 280204959;

    for (int AhDYXW = 1811630449; AhDYXW > 0; AhDYXW--) {
        kxucfnL /= kxucfnL;
        kxucfnL *= kxucfnL;
    }

    for (int fKDeaVzzIBJoeJqn = 350328541; fKDeaVzzIBJoeJqn > 0; fKDeaVzzIBJoeJqn--) {
        WFTBHAoagk -= WFTBHAoagk;
        WFTBHAoagk += WFTBHAoagk;
        WFTBHAoagk *= WFTBHAoagk;
    }

    for (int ZbHQnzxAAqNrZk = 252949654; ZbHQnzxAAqNrZk > 0; ZbHQnzxAAqNrZk--) {
        WFTBHAoagk -= WFTBHAoagk;
        kxucfnL *= kxucfnL;
        WFTBHAoagk /= WFTBHAoagk;
        kxucfnL -= kxucfnL;
        WFTBHAoagk += WFTBHAoagk;
        kxucfnL += kxucfnL;
    }
}

void DIRPG::BnmqCMS()
{
    int IAfRTQ = -29709931;

    if (IAfRTQ >= -29709931) {
        for (int TnaGNtjePw = 1462631823; TnaGNtjePw > 0; TnaGNtjePw--) {
            IAfRTQ /= IAfRTQ;
            IAfRTQ -= IAfRTQ;
            IAfRTQ *= IAfRTQ;
            IAfRTQ = IAfRTQ;
        }
    }

    if (IAfRTQ < -29709931) {
        for (int lgdCxe = 954316582; lgdCxe > 0; lgdCxe--) {
            IAfRTQ *= IAfRTQ;
            IAfRTQ *= IAfRTQ;
            IAfRTQ += IAfRTQ;
            IAfRTQ -= IAfRTQ;
            IAfRTQ /= IAfRTQ;
            IAfRTQ += IAfRTQ;
            IAfRTQ /= IAfRTQ;
            IAfRTQ = IAfRTQ;
        }
    }

    if (IAfRTQ != -29709931) {
        for (int YSmwFajbYcUCFNAr = 992962710; YSmwFajbYcUCFNAr > 0; YSmwFajbYcUCFNAr--) {
            IAfRTQ -= IAfRTQ;
            IAfRTQ *= IAfRTQ;
            IAfRTQ -= IAfRTQ;
        }
    }
}

DIRPG::DIRPG()
{
    this->PJTdmuvVugQJaFMt(992127.5431790504, 607610.0262158489);
    this->MEbmybg();
    this->pUrDVAAeogDheJHQ(string("RVlcoCRRJyFZsfJkJyUZCMNMjuEEFNOyBiszZRMLSfSzETGoGmMvgiEGEXQDegQGthckTyXdBuNyFHNcpswfYcqnPwBmODIrQnpPQIVhrxrhvmmFSkvkLbLtMtD"), 351902069, string("RaBPEGfwiUBXyTIQvWBNPhnFWUzFBJKdRorjxHrRDgVEkjNafdFWXRsbNlQhujYkXrLkGbxoMsJoJTKCAHMzudAtuxIydHVssMfdSSAIYvfSlsFApGoebJBLeRjncJxRUQjEtfxZdSgiXdIOrCfwwnZgWtoWnuRapxBdaSOuNnwxSMabSceMSmtbNCSQJOMJITJeheOswfYTdOkmxgySzIoFHeaUCopgKLhmKLpsMZaXJIRSafM"), true, 943315.8494062888);
    this->FIkoXj(2115985918, -1414215540, false, false, -683674.3652396288);
    this->mJJer(true);
    this->LVwmMJDsZ(769890.2313127755, 566502465);
    this->pZOoMpHykK();
    this->WWtNeRyW(string("ihsHACjibvxPsAaeZhrOKhunpRKJuebAAFfPOjSWrdOBbvilfSGfoZrUTELjTszKsCBEtgdxzObIBMDIXdyOFocojsKOMoJCAsxxCpgqiAJdxjGUsRXcdBvQGjTneQprWKOKISsghBUeHQjVjmgIvYRIUDzWzbFRNTMIpnOxkdxWBnjEHOoBgyKMUwRNTDXg"), string("crteFrzNSNxXVhgKpgSLPktjOQgrRZRXoHpChzpAEhnNjGDsXZtlYmHXoACYdjTkdbIGClOOGpfnOhsySHGCPYKiZsptHMEplpORZZqUhIVsBePOaloofjmLQJdDjtCtgdBXyNMyFwdmLQgRRfYyohRiSqnsLcIebsTfOwAyMkYCvAJqEzPwzHQSrXnStjuUguWXDoMprJELrIZIDZYlEyiZXobVuqtqLALVXDjzuFKlErM"), string("cXuBvfGNLCIqmuuboqVEUOLWUMfIveTLbvQAUhmUQXKBSpwbGIhceZDZnuhTfMXAmuhThIOxGhzieqLwMJOatoDbBQDkDBiOQeeblhvgPmUnOHCSfi"), string("ttXgvcPADbgxbEaggzZtmNOIqzOYXMsdBQQNqjjT"), false);
    this->WIosORkQ(877774459, 142483187);
    this->IWRTyVSEQbvchXeX();
    this->uhyEKb(string("IDTAWTFKbbeWHeG"), string("CeQqhyznsYPKlgoNnJFSycDQGUNgCHJJRpqMwwGERtBzMbuROwhWaugINItpyExPCxSClmIXayYHaqsZIuYMuXfhCGuZJmAknYZTrTWwkWzhyPROsmGuJqZAmtRoQHnIjWwFLuoDZTUVJWLJZmvHHsOGBGORlXsNePQGEPvBRaBcPWPWKGMjqPIxMnjYDE"), -1142815480, 178948.81971138145);
    this->nVgeX();
    this->dmPJG(-677708.6468391207, 1034392.1740898135, string("tmzEyYojBiyGMYqxZbZtgnvdrHvVYWAfcKLKkvojLqtCZFDfaKJgSDPpPBBcXoATmWHfzRbOygRYXFiDFaExEesguMmSmssjvmxxHgcnAcgLPcxVVoudEardYqJJjAGLiFoPVGTOdJgArwUpdOObSJKDeCkMkGRcDjSfgft"));
    this->xzKcm(-365241.8806907206);
    this->BnmqCMS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ShkKqn
{
public:
    bool mtnOBXNgfGPkFt;
    int RZnCieotpENP;
    bool DyTNcyFvVAOh;

    ShkKqn();
    bool pnLpPbQq(int PAdVlui, int zyJgHFD);
    string IxlyaNQrEnHPou(string XDlWNahdfX, string zPMsG, double lNKMVDxqEEEWMw);
    void WTlzlUcvlWkdEJ();
protected:
    string grUwgkqNnvmOyah;
    bool UjcuZVBmhOiyK;
    double nyLMVWwSsdSPCCa;
    bool lcIsIAD;
    double lmCsvgumnIKfxP;

    void noFzSYYedI(bool WWjOhnaPftSc);
private:
    string jFLImt;
    double pBRpRRigrZPsp;
    int xyePArrlIvfkb;
    int TvMjryb;
    int XRPgT;

    void HaLAHqoSFm(bool FTpIZKLwsjdDeMmv, double SyVLrBQvTkcm, bool CJDftVOctAsQbCn);
    double tDxQXs(bool hbbDtlePmXPQXAuC, int fRfYPkIbKETkl);
    bool FGBNgeHLaHPcIyY(bool hRgqqeusXAiIB, bool QniletlK, double VNmKxAnVFYRVd, bool vGFevOMZu, int WRLHChQuGmsHFndG);
};

bool ShkKqn::pnLpPbQq(int PAdVlui, int zyJgHFD)
{
    string gyRxISJBzlnCYLdm = string("WMKCfMjNPdPWMTtnlyIPKTujMuWsUqvWliTFwbiFSBamVodFwSRUoVjVKLTLwGgECVRfOimktvuTrWqTIkRHyBZzYLDVzJqeYhzXkdwTMtFOzXcLDSbnGKpiuIMrPZArfKuYnjrzKtXVzdKGawfATTjCtUJMCdmkzLJGkWsJR");
    string XnKlIhRFeumOIC = string("bEyJWdCqfdzXdPDkDYvCxbjyreKawNVMWFbGyEXpRlxWtgozaQEcJi");
    double MobqZGEdocEzBDI = -188698.59829549835;

    for (int cOqYJcMVjVlqgi = 421029277; cOqYJcMVjVlqgi > 0; cOqYJcMVjVlqgi--) {
        gyRxISJBzlnCYLdm = gyRxISJBzlnCYLdm;
    }

    for (int CeMuhNDIjrwcd = 2102442880; CeMuhNDIjrwcd > 0; CeMuhNDIjrwcd--) {
        XnKlIhRFeumOIC = gyRxISJBzlnCYLdm;
        zyJgHFD = zyJgHFD;
        PAdVlui *= zyJgHFD;
        XnKlIhRFeumOIC += XnKlIhRFeumOIC;
        MobqZGEdocEzBDI = MobqZGEdocEzBDI;
    }

    if (zyJgHFD != 1674647475) {
        for (int jUHqSutrRYefkz = 242162331; jUHqSutrRYefkz > 0; jUHqSutrRYefkz--) {
            zyJgHFD *= PAdVlui;
        }
    }

    if (XnKlIhRFeumOIC >= string("WMKCfMjNPdPWMTtnlyIPKTujMuWsUqvWliTFwbiFSBamVodFwSRUoVjVKLTLwGgECVRfOimktvuTrWqTIkRHyBZzYLDVzJqeYhzXkdwTMtFOzXcLDSbnGKpiuIMrPZArfKuYnjrzKtXVzdKGawfATTjCtUJMCdmkzLJGkWsJR")) {
        for (int pGzKEtHUCIFHQls = 2037151197; pGzKEtHUCIFHQls > 0; pGzKEtHUCIFHQls--) {
            continue;
        }
    }

    return false;
}

string ShkKqn::IxlyaNQrEnHPou(string XDlWNahdfX, string zPMsG, double lNKMVDxqEEEWMw)
{
    double dlVimHiqArhOUlw = 346576.435864669;
    int awZvZEJYlzW = 122915032;
    int JriRRaZAVl = 86693779;
    double heLhSsP = 962182.7387853373;

    for (int QKdLLwmYMzndjr = 1002814160; QKdLLwmYMzndjr > 0; QKdLLwmYMzndjr--) {
        dlVimHiqArhOUlw -= lNKMVDxqEEEWMw;
        heLhSsP /= dlVimHiqArhOUlw;
    }

    if (lNKMVDxqEEEWMw > 962182.7387853373) {
        for (int xByLsopPmSb = 1341657714; xByLsopPmSb > 0; xByLsopPmSb--) {
            dlVimHiqArhOUlw += dlVimHiqArhOUlw;
        }
    }

    for (int jvmbdRiCFYx = 1850604123; jvmbdRiCFYx > 0; jvmbdRiCFYx--) {
        continue;
    }

    if (heLhSsP >= 346576.435864669) {
        for (int cDUookgoGE = 1946083124; cDUookgoGE > 0; cDUookgoGE--) {
            dlVimHiqArhOUlw *= dlVimHiqArhOUlw;
            JriRRaZAVl *= JriRRaZAVl;
            dlVimHiqArhOUlw += lNKMVDxqEEEWMw;
        }
    }

    return zPMsG;
}

void ShkKqn::WTlzlUcvlWkdEJ()
{
    double MZJUvtI = 778687.7842099625;
    string mUMgJC = string("hSVcWuERWgleNzEEpvZXCGTYXfkIhNFVqDfYFQEORqkAeNaiqvhdGKDVtSiBbGFYWlCQSweAVLnqyTKPuZOBDXURmoZMftahMEkmsdAdzMgGGZRYjxolDrNQtabWzbLDFgnKXUBeFXvOPYHFeTFttCsVMIWsBFdALOwpeyJprvKeurgQVJgpaVhTIK");
    double AQpySQUrhPX = -120431.3683688067;

    if (mUMgJC == string("hSVcWuERWgleNzEEpvZXCGTYXfkIhNFVqDfYFQEORqkAeNaiqvhdGKDVtSiBbGFYWlCQSweAVLnqyTKPuZOBDXURmoZMftahMEkmsdAdzMgGGZRYjxolDrNQtabWzbLDFgnKXUBeFXvOPYHFeTFttCsVMIWsBFdALOwpeyJprvKeurgQVJgpaVhTIK")) {
        for (int fIODKaeL = 1442288322; fIODKaeL > 0; fIODKaeL--) {
            MZJUvtI -= AQpySQUrhPX;
        }
    }
}

void ShkKqn::noFzSYYedI(bool WWjOhnaPftSc)
{
    double JTyWfzHtdj = -197715.20751282887;
    int awLOAxkptVoTYyy = 384181860;
    int scCiTVsEGpiHTav = 2034531335;
    double uBwThWXnGx = 133235.84898512045;
    string cbVyvVDxnUly = string("CucBvOQSQkeMobmLhGAjWrnPkFWuUzaAU");
    int CVJmT = -1413032372;
    double rWLkbDRLWkdlQL = -904173.3415723017;
    int WkpFISzXP = -1662964968;
    int etxLOBpdki = 427579123;
    string ZtJLx = string("CowKpsfAtiGRKDAsCLsFhJqSLsVsJcqZabarKoTcvCEfewYYTgPXKZaiZlfxXddKimvxrtuDhUABdqQbqfQDybFDGrLSjzeRGIFvZWzaVerTyyqqZoyzHNHYXXFasFlYfdmsvQbik");

    for (int qpSGvKfzOo = 57314048; qpSGvKfzOo > 0; qpSGvKfzOo--) {
        CVJmT = awLOAxkptVoTYyy;
        awLOAxkptVoTYyy *= WkpFISzXP;
        scCiTVsEGpiHTav /= CVJmT;
        uBwThWXnGx = uBwThWXnGx;
    }

    for (int MEtWdkhWxncdOM = 1991131383; MEtWdkhWxncdOM > 0; MEtWdkhWxncdOM--) {
        awLOAxkptVoTYyy *= scCiTVsEGpiHTav;
        etxLOBpdki = WkpFISzXP;
    }

    if (scCiTVsEGpiHTav <= -1662964968) {
        for (int VpkvD = 44152837; VpkvD > 0; VpkvD--) {
            continue;
        }
    }

    if (ZtJLx != string("CowKpsfAtiGRKDAsCLsFhJqSLsVsJcqZabarKoTcvCEfewYYTgPXKZaiZlfxXddKimvxrtuDhUABdqQbqfQDybFDGrLSjzeRGIFvZWzaVerTyyqqZoyzHNHYXXFasFlYfdmsvQbik")) {
        for (int GNuHEVWfaF = 1870036924; GNuHEVWfaF > 0; GNuHEVWfaF--) {
            rWLkbDRLWkdlQL /= rWLkbDRLWkdlQL;
            awLOAxkptVoTYyy += awLOAxkptVoTYyy;
        }
    }

    for (int TEYYlFac = 207167599; TEYYlFac > 0; TEYYlFac--) {
        scCiTVsEGpiHTav -= scCiTVsEGpiHTav;
    }

    for (int nBUEFVgSjpUPgcr = 1685149550; nBUEFVgSjpUPgcr > 0; nBUEFVgSjpUPgcr--) {
        ZtJLx += cbVyvVDxnUly;
        cbVyvVDxnUly += ZtJLx;
    }
}

void ShkKqn::HaLAHqoSFm(bool FTpIZKLwsjdDeMmv, double SyVLrBQvTkcm, bool CJDftVOctAsQbCn)
{
    int BzfkLM = 69852618;
    string KgEjsRDzFUUbD = string("zVTrVgjaQPwvfnqHICIGmENnGbZRAmTVxFYELFTGbisdudpOYhJFQkkTwzyBMxPpypZUFleVfmPT");
    double UHSVJo = -498785.9529105561;
    double zypHuzdUn = -899293.0051374403;
    string vWXztvSjtt = string("SQIiVNblIFAXfwJopFUkKyClBBaQzPPgkbrMTSbjjQQicvyeVybJDzoaldvUdtdHcXQjPzIrOrNPFcoBjSlrmevUDSwNVUnFwhKfKoCshTAAFFaZJcDVEcGlINqXHUKzkMLBmBfgxZnAtTGfZuqKHBOYdmxFWIsaUOnTFBGdhrYwESlzvfA");
    bool ejnXOq = false;
    double vHZdqZMhbvRWZg = -1034042.1553429754;
    string iFZpfeCyEHHxOeIB = string("CgxUcOykglZHgWarINffZNAhYUQHSfnSuWOtnYqYfdZBkIBLvnadODCgMbGrSfdKbhgqfcIlpYZnFrRGNkPinfCDkbsDJQMNeSnzvkQAfPPMSqihV");

    for (int ILluiZHWwle = 735224378; ILluiZHWwle > 0; ILluiZHWwle--) {
        zypHuzdUn -= SyVLrBQvTkcm;
        zypHuzdUn -= UHSVJo;
        vHZdqZMhbvRWZg = SyVLrBQvTkcm;
        vHZdqZMhbvRWZg *= SyVLrBQvTkcm;
    }

    for (int gKMsMChfpFqHrakq = 98647829; gKMsMChfpFqHrakq > 0; gKMsMChfpFqHrakq--) {
        vHZdqZMhbvRWZg -= SyVLrBQvTkcm;
    }
}

double ShkKqn::tDxQXs(bool hbbDtlePmXPQXAuC, int fRfYPkIbKETkl)
{
    double jycgbWDnRlt = 483542.2768848759;
    bool rOawWwDfVqunNI = true;
    int IHlYAebDDBXCK = -972084088;

    for (int qvwtN = 1614681033; qvwtN > 0; qvwtN--) {
        continue;
    }

    return jycgbWDnRlt;
}

bool ShkKqn::FGBNgeHLaHPcIyY(bool hRgqqeusXAiIB, bool QniletlK, double VNmKxAnVFYRVd, bool vGFevOMZu, int WRLHChQuGmsHFndG)
{
    double OMnNbdPd = 482225.30640164536;
    int XMSjY = 2022729309;
    double fReqaxlnF = -509693.75510885275;
    int RaGHFxo = 1798382694;

    for (int STGLPKOQNROoV = 499096984; STGLPKOQNROoV > 0; STGLPKOQNROoV--) {
        OMnNbdPd *= fReqaxlnF;
        VNmKxAnVFYRVd *= VNmKxAnVFYRVd;
        QniletlK = ! QniletlK;
    }

    if (fReqaxlnF <= -298265.2735301863) {
        for (int vLGoka = 2074676424; vLGoka > 0; vLGoka--) {
            hRgqqeusXAiIB = ! vGFevOMZu;
            hRgqqeusXAiIB = ! hRgqqeusXAiIB;
            XMSjY /= WRLHChQuGmsHFndG;
        }
    }

    for (int CshHNCTBuQYN = 760788520; CshHNCTBuQYN > 0; CshHNCTBuQYN--) {
        QniletlK = ! vGFevOMZu;
    }

    for (int XUolTEmuMjwruKU = 1401649425; XUolTEmuMjwruKU > 0; XUolTEmuMjwruKU--) {
        OMnNbdPd += VNmKxAnVFYRVd;
    }

    for (int QGLGOkKKXlfg = 734546575; QGLGOkKKXlfg > 0; QGLGOkKKXlfg--) {
        fReqaxlnF /= fReqaxlnF;
        VNmKxAnVFYRVd = fReqaxlnF;
    }

    for (int uREbxQTA = 1996488623; uREbxQTA > 0; uREbxQTA--) {
        hRgqqeusXAiIB = ! vGFevOMZu;
        fReqaxlnF = VNmKxAnVFYRVd;
    }

    return vGFevOMZu;
}

ShkKqn::ShkKqn()
{
    this->pnLpPbQq(1674647475, -767066910);
    this->IxlyaNQrEnHPou(string("NmBngNPERWsgLAdkWvefwmfmxlRWLDyrKELKGcCCQtCAQesVtDJPIICvLyMMXPMTkKuQiOtSnkKOmqUXgLyEDqiHVfFMascQLKafMclhXvrSmPIVlzSBioOZkmkCcPgeoJBNXPTjgIYzqAUaQDOyijTXvpnvdHDyvXnLvYsctktEztkckODhoOxzrVEqmLJMhRstiNElFpvGFWDfSazEvUVPaCGCPnA"), string("OIiqwdWqZWuxTQriMOeeRftfSUvMWLofqUxmhQlztlTzptyTUuigkqjGRZqBNlPIgcFSjmEPQKFWMgfRSzDudyqkMyCKckfUxukFQYQjVTSJtbolXEHucrYutUppjwPPQDjXARukCvlRHCEXwcIFamuOBqLGFoLbGXHjqtoeZfufqHRhcUWMgknJPOPMVlwHzHqhlOGvDqOOVupaFaPpIqWFSCMJzkJ"), 508206.1328950112);
    this->WTlzlUcvlWkdEJ();
    this->noFzSYYedI(false);
    this->HaLAHqoSFm(true, 771478.941924212, true);
    this->tDxQXs(false, 2076771645);
    this->FGBNgeHLaHPcIyY(false, true, -298265.2735301863, false, -627963335);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YihSIVbQTf
{
public:
    double biDpEv;
    bool bMmWzHVK;
    string UOrWiAVhmHGyES;
    string jZZFjoAJX;

    YihSIVbQTf();
    double PwvEXGG(int urXSaQCGpWxuLTHq, double MqFUWbRIGOFVguP, string bxlOwImRohpxp);
    bool vlhjhb(int smFWALORO, int RcCIpqMyJTmL, double ALhDBvUq, bool cBKttUo);
    string JUJRHeJyJyvjWV(double riLRgyVWRJmcG, int OGPmVJJ, string GIEeCMVUMO, string iAeeabIv);
    double ktsVNM(double wjWKleOrI);
    string UgTwl(int cStfXFBXFxwzXdRt);
    string jJsWeLugcvVIHGq(string rWbYrPKXaYkGSBiD, string JsWLMsRTO, int ATieHoQWhAnbUoW);
    double PrPIoYKJpI();
protected:
    int cZFvIlNHCsAQNitk;

    bool NgntGCq(double oRHcUZ);
    double ZUmUjJfMAAlTbo(double leDoPWjMekYMUcdl, int kWXeLNB, int lQHccParNVtXV, bool LbAwdlJ, bool DYTxmPVglPvtc);
    double ITvSfGqD(double pHbRuGXIhhWYf, bool wZnfximbTtUBiB, double jOyeXM, bool MPhYQWnYIl);
    int dlaAuafIoAynKiY(bool FkdWEScULCnR, string RTBvwNaycEH, string FezXlQHgoiexowHk);
    double BqYndde(bool GazVLQzkDAIf);
    bool FZQXRUWYhZCaRsXb(bool jdUrZmLArZQX, double SeROmLjLMFCDM, int zpDhlyTtwP, double zpsDPBdYfHbzfyNl, string BMtcO);
    int UIsxUBfZsNsOCZe(string ZfjBTVYqEcxvrlRb);
private:
    bool pAFPVZPCtr;
    string bStXoUflJriDb;
    bool rwjzJrMAxnr;

    int SSrAvmcdeUPlRYs(bool UBBYB, bool XJvJRElrC, double ZsJjAWg, double JPDDNwB, string uLOwdxwvdRegv);
    string fPnBuPiqmK(bool ueSXCCpAup, bool bRbvcLVq, int QRrJQfVLCIIsarhU);
    string DxYbTZLKfqseotRC(bool IxppQxFrxbeaqAtd);
    void WirVIRhhjocqFmrs(double JAQqHoWwy, double gWfVkqCqT);
    double CoGNwtY(bool rJBPBpgoy);
    double zyOncEJ(double tHQTDihLYQUFAV, int AgYGSQvMTF, string WCujfiDwB, int xVwtKfdaaxy, string DixrkZByx);
    int COblaFpqLz(double HGHxROr);
    string YGSsweXUMLRs();
};

double YihSIVbQTf::PwvEXGG(int urXSaQCGpWxuLTHq, double MqFUWbRIGOFVguP, string bxlOwImRohpxp)
{
    int lODBsCZZHSbrrmN = -976729860;
    bool EsVaPPmaASFZfQb = true;
    int TnKGykVMnuMesSMh = 1337233497;
    string qpvizXvGwF = string("jikuPHZrCzDavuzZCSpHmePzNmnPWMWALzScPNxTpzqeBtMAFwImexsaQmSdeFkDjzgHNmxGLvTsftobnwBzNRjUmbOyTyXKHqQHMuZLxrPnIDvLnVHYZZPrAqYrDUmSxuWXoRBRBEVHkHFRmenxOxkxThMdhSUhEVPNGsKpTjkRfkZdOFYXRGtWVxlXTPpQITDkVrpAnEeqfoCKWGNbDouylARxSeqFfnnRjHuendVq");
    int HamMMPRXx = 370859290;

    for (int EjxUFlkDIadzhdv = 1321917097; EjxUFlkDIadzhdv > 0; EjxUFlkDIadzhdv--) {
        urXSaQCGpWxuLTHq = HamMMPRXx;
        lODBsCZZHSbrrmN -= urXSaQCGpWxuLTHq;
    }

    if (bxlOwImRohpxp < string("jikuPHZrCzDavuzZCSpHmePzNmnPWMWALzScPNxTpzqeBtMAFwImexsaQmSdeFkDjzgHNmxGLvTsftobnwBzNRjUmbOyTyXKHqQHMuZLxrPnIDvLnVHYZZPrAqYrDUmSxuWXoRBRBEVHkHFRmenxOxkxThMdhSUhEVPNGsKpTjkRfkZdOFYXRGtWVxlXTPpQITDkVrpAnEeqfoCKWGNbDouylARxSeqFfnnRjHuendVq")) {
        for (int KkvFuVZuks = 1712899483; KkvFuVZuks > 0; KkvFuVZuks--) {
            TnKGykVMnuMesSMh *= HamMMPRXx;
            MqFUWbRIGOFVguP /= MqFUWbRIGOFVguP;
            HamMMPRXx *= lODBsCZZHSbrrmN;
            HamMMPRXx = lODBsCZZHSbrrmN;
            urXSaQCGpWxuLTHq += lODBsCZZHSbrrmN;
        }
    }

    return MqFUWbRIGOFVguP;
}

bool YihSIVbQTf::vlhjhb(int smFWALORO, int RcCIpqMyJTmL, double ALhDBvUq, bool cBKttUo)
{
    bool yHNiNsOEYN = false;
    int kTJgnUq = -1524573043;
    double PtfgvIEMTzpF = 314519.4456519382;
    int ltbgRgpocs = -1325886885;
    double njCtnafGACzr = 27340.347916147522;
    string LYeFT = string("otzoDFmRXYkqMuuXnlVlnVwwudBYybvHrhshlLbebPFgwNeUpPxrhNtxcwzjkkDFmeJGUMyjgrDHHMCtIiuEmWmHuCaIutRSiAGxhiEUpVOoeKFkyXiSJJOEEcUsKb");
    double YbIGnuvQ = 947382.3482025269;

    for (int VrLjKqqPrkycp = 1709177245; VrLjKqqPrkycp > 0; VrLjKqqPrkycp--) {
        ALhDBvUq /= PtfgvIEMTzpF;
        smFWALORO = RcCIpqMyJTmL;
    }

    for (int ASTmOkuTN = 1112725339; ASTmOkuTN > 0; ASTmOkuTN--) {
        continue;
    }

    for (int QdtQpinf = 1075783248; QdtQpinf > 0; QdtQpinf--) {
        continue;
    }

    for (int slmCvMwXJcWudW = 2105943693; slmCvMwXJcWudW > 0; slmCvMwXJcWudW--) {
        smFWALORO += ltbgRgpocs;
        kTJgnUq += smFWALORO;
    }

    return yHNiNsOEYN;
}

string YihSIVbQTf::JUJRHeJyJyvjWV(double riLRgyVWRJmcG, int OGPmVJJ, string GIEeCMVUMO, string iAeeabIv)
{
    int nfZYeFgvXprNfGVr = -1486757141;
    string cgNNhNgpT = string("XNOhLBjHoJmxCbQcmguWSzhDbIqWNfVzQcLnznyRRreyFCnNeIAoDdiuKhkRnkrphMtzJncImCpacFvLBCWqQZbBtWXBHQIIVEysSBzclCiFDQLGDdwUHvifGJDondnnKhdGppUbZyXvqKyGOxnnLSIhuwkOSIJgnvKaxPFqaZBTODhNBADoqdmGJcOl");
    double VHDiQTipjZ = 744166.9349529312;
    double VONzGau = -734042.2563315417;
    bool TJOpOzbVU = false;
    double uypWgzzjJarss = 733792.6003720508;
    double MCSxx = 138455.9777596628;

    for (int WSNHlQXRONfHe = 2038201910; WSNHlQXRONfHe > 0; WSNHlQXRONfHe--) {
        cgNNhNgpT += GIEeCMVUMO;
        iAeeabIv += GIEeCMVUMO;
        riLRgyVWRJmcG += MCSxx;
    }

    if (uypWgzzjJarss <= 733792.6003720508) {
        for (int KPgNGnGwaRb = 1961270056; KPgNGnGwaRb > 0; KPgNGnGwaRb--) {
            VHDiQTipjZ *= VONzGau;
        }
    }

    if (MCSxx != 342155.5569464646) {
        for (int IJZmhtbKNuYdvwl = 770325965; IJZmhtbKNuYdvwl > 0; IJZmhtbKNuYdvwl--) {
            continue;
        }
    }

    for (int lQKJGhA = 358253555; lQKJGhA > 0; lQKJGhA--) {
        continue;
    }

    if (riLRgyVWRJmcG != -734042.2563315417) {
        for (int mltbWUeeDmD = 1179037390; mltbWUeeDmD > 0; mltbWUeeDmD--) {
            continue;
        }
    }

    return cgNNhNgpT;
}

double YihSIVbQTf::ktsVNM(double wjWKleOrI)
{
    string BytuqGxr = string("sKjmrtIrvRmLrMsKkpFhxgiJYICzQYMkXsaPonsWqgmOvtpjVRvIquPQHMRpiXEiGRRjpWbnvsILeiNcTlIdLySYWnJVhPhERpBebFt");
    int WtOallKPH = 480326236;
    int tiQAyCVOPXmAjoPt = -1284014976;
    int dgkwcbr = -1335570183;

    for (int wPAoDcFiMv = 64158805; wPAoDcFiMv > 0; wPAoDcFiMv--) {
        WtOallKPH -= dgkwcbr;
        dgkwcbr = tiQAyCVOPXmAjoPt;
    }

    if (BytuqGxr != string("sKjmrtIrvRmLrMsKkpFhxgiJYICzQYMkXsaPonsWqgmOvtpjVRvIquPQHMRpiXEiGRRjpWbnvsILeiNcTlIdLySYWnJVhPhERpBebFt")) {
        for (int NZLwqjxToZpgi = 1984355658; NZLwqjxToZpgi > 0; NZLwqjxToZpgi--) {
            continue;
        }
    }

    return wjWKleOrI;
}

string YihSIVbQTf::UgTwl(int cStfXFBXFxwzXdRt)
{
    int ADqZgjih = -833274195;
    int iToVzvWmG = 2013724725;
    string yAjTplYjzAHFg = string("FtwZyEmGFpdXhHmuoYoWeDlLsULFntKcsfuyv");
    double qsfhzoxSQBExb = -329260.2076759535;
    string uWjKcouyn = string("exCJBAaJXowFxenMMwGDTaAzqtqYQAFCxNsDqeCDwTnwkYGAVhBSiPbjtmnCckvKQkMAElI");
    bool PKljhYiPO = true;
    bool dxEouZkHvpevfyVm = false;
    double gboDRh = 595243.0172894152;
    bool kkSWALBz = false;

    for (int IggAvAtlxKOSRd = 1774152578; IggAvAtlxKOSRd > 0; IggAvAtlxKOSRd--) {
        cStfXFBXFxwzXdRt += cStfXFBXFxwzXdRt;
    }

    for (int TINLg = 216717247; TINLg > 0; TINLg--) {
        cStfXFBXFxwzXdRt -= iToVzvWmG;
        qsfhzoxSQBExb -= gboDRh;
    }

    for (int QdTpMxF = 735880673; QdTpMxF > 0; QdTpMxF--) {
        continue;
    }

    for (int YqrAArM = 2136515625; YqrAArM > 0; YqrAArM--) {
        PKljhYiPO = ! dxEouZkHvpevfyVm;
        ADqZgjih -= iToVzvWmG;
        dxEouZkHvpevfyVm = PKljhYiPO;
    }

    return uWjKcouyn;
}

string YihSIVbQTf::jJsWeLugcvVIHGq(string rWbYrPKXaYkGSBiD, string JsWLMsRTO, int ATieHoQWhAnbUoW)
{
    string yzpJbbkURT = string("cFvmREWiRFsHjnVNmKYXDUsqDaNCyoXmWUxYctiLrZScBsOXhjXYeSmtiusIPNYzfRgOhapnJmoaWwnMAqGNKwJjBTfPAaWX");
    string cqmYp = string("nIGQqqKdSmXltEojsMzFmHialKfsZONcADhNJOzjvbhXsMFoZzmYmoUFTrQaBzQnuARVYGoQqkUjEfhnqMLlfePdsNChg");
    double xFPputHU = -47396.59966792928;

    for (int HEvzreBDsxS = 618283157; HEvzreBDsxS > 0; HEvzreBDsxS--) {
        rWbYrPKXaYkGSBiD = JsWLMsRTO;
        ATieHoQWhAnbUoW -= ATieHoQWhAnbUoW;
    }

    for (int cqDrcmlngsUyDkRu = 1412054788; cqDrcmlngsUyDkRu > 0; cqDrcmlngsUyDkRu--) {
        cqmYp += rWbYrPKXaYkGSBiD;
        cqmYp += yzpJbbkURT;
    }

    return cqmYp;
}

double YihSIVbQTf::PrPIoYKJpI()
{
    string nUzthRNWKVHZxXWi = string("QXwQyOSxezEpvSEUbAVuIhCjrWluiBBrRznAARpRoWkpDZDBAwihZzTYcsPJAElkOyGvTgPGvxrCkgzqUQMkCppcnMgZWdgkhPaChyJQpiNTMAJbwZKdnrAuReMkZwjFvNAPtkbJbQeEXSsjaILdbjDSBEGFFKZNb");
    string quSaYesZH = string("tSrhmbpcAUbxtuILnXQLDdpBbFygXvMtibwXDxxutADfjVqzpoQEKXbrvHsuKXJCGgywEmSiWPlpJFyStJTkHsvzCEcvBaquJhwBdAjihOzQYXzzOBffMdvAwUZIhuEeUHzSHwDXASKyqgVCyY");
    int MURJyYaiZJItq = 1425105977;
    int GlaAswGQQW = 2055103894;
    int pOnrN = 1855726417;
    double tIWKdOB = 476372.20013222325;
    bool NNiSeTXUsbcomIEe = true;
    string WYBhUu = string("wTTVtRIDLNlCtBOeZaKxJVYoIQxCHvjNNuufiPBTnhiPwEYHeEEulHmikBwvUdghdUFZfwGPIuqnEmPOPJXGOaMhFwMYvcJEEOJBlUcviZWkxRJCzvWqpfdEEGjZlpRfHhCGmraYrfBFVtMTMYMtvpBbFDnVRNJKuHnrxXPRoWjeOVnOslIBIOTubIeAbVAkaZLhsrloLZIuCSrMarJjKUfIdOiVbPUtHPdGiEYsMoUnCmxDllOwJpJ");
    string AlRHbyJESV = string("ueqTUWOyJlfVgwrHSbxsBliVTtDmgGewuvSlgxLhQjcYXCDCXFNsWbSfPwhquhEpJx");
    double qzNrGXQThqTxPuGF = -541417.0770727862;

    if (WYBhUu > string("tSrhmbpcAUbxtuILnXQLDdpBbFygXvMtibwXDxxutADfjVqzpoQEKXbrvHsuKXJCGgywEmSiWPlpJFyStJTkHsvzCEcvBaquJhwBdAjihOzQYXzzOBffMdvAwUZIhuEeUHzSHwDXASKyqgVCyY")) {
        for (int TVRYsjjOodPkl = 1894059820; TVRYsjjOodPkl > 0; TVRYsjjOodPkl--) {
            continue;
        }
    }

    if (nUzthRNWKVHZxXWi < string("ueqTUWOyJlfVgwrHSbxsBliVTtDmgGewuvSlgxLhQjcYXCDCXFNsWbSfPwhquhEpJx")) {
        for (int MBnHMmyIvjq = 610757918; MBnHMmyIvjq > 0; MBnHMmyIvjq--) {
            AlRHbyJESV += AlRHbyJESV;
            MURJyYaiZJItq *= GlaAswGQQW;
        }
    }

    return qzNrGXQThqTxPuGF;
}

bool YihSIVbQTf::NgntGCq(double oRHcUZ)
{
    bool WBQPbb = false;
    int lMKNXtgrBwzhgHYl = 1918216699;
    int dQfIpjynSqY = -1249049037;
    int JGjsuCnIds = -1798065945;
    int EODlZpfuarEDQ = 992026725;
    bool lSUizljdskLx = true;
    double hEauXhVzlXNdtNDV = -968299.8644908622;
    int txgGTYajDgk = 2066455849;
    double RjwvmYPwdrKdha = -44767.29549234278;

    if (RjwvmYPwdrKdha == -968299.8644908622) {
        for (int BqJIdBF = 556828017; BqJIdBF > 0; BqJIdBF--) {
            lSUizljdskLx = WBQPbb;
            lMKNXtgrBwzhgHYl += dQfIpjynSqY;
            txgGTYajDgk /= lMKNXtgrBwzhgHYl;
        }
    }

    return lSUizljdskLx;
}

double YihSIVbQTf::ZUmUjJfMAAlTbo(double leDoPWjMekYMUcdl, int kWXeLNB, int lQHccParNVtXV, bool LbAwdlJ, bool DYTxmPVglPvtc)
{
    int UbAHfZRly = 1241338492;
    double CHrJKDcKcWHRCH = -33861.463319540744;
    double wbREDLAP = -103110.83782598966;
    string NbQgLNEoxwe = string("NihysWseznNkADIaZuGpbdMfyCXOwdstwWShnEYsSlZviPAmDEZFiHaDbQlIMMQwvlHgfroFfPUmeVCpxnuCBAlF");
    bool ZRVlGriAGkFuJkC = true;
    int pfRgZGVXBvMJqr = -1502495079;
    int lHwHMpsb = 155323394;
    string hhTnbtajkaUePTu = string("KXHiAEqwIBJCnHBzFDNRHAiHMgRPQRXjcakUTeovrJfyaQtveHQlbzNavFWifKzEefiVRCQvnenYKAUvuSygnhVmIDrcNqWhNdCKambRSYKxzYjBHzntdaYKByvZrZPrQagdhePoBjFUNKHdmnBrblhYGftsmLjdlkwfTBvydIwqgl");
    bool cloNMxsXgQS = false;

    for (int vfaVlAZcat = 1089084824; vfaVlAZcat > 0; vfaVlAZcat--) {
        continue;
    }

    if (lHwHMpsb <= -1796671985) {
        for (int uruCKpS = 2007488517; uruCKpS > 0; uruCKpS--) {
            continue;
        }
    }

    for (int obMqqkvryE = 48121333; obMqqkvryE > 0; obMqqkvryE--) {
        leDoPWjMekYMUcdl *= leDoPWjMekYMUcdl;
        cloNMxsXgQS = ! cloNMxsXgQS;
        lHwHMpsb /= UbAHfZRly;
        ZRVlGriAGkFuJkC = ZRVlGriAGkFuJkC;
        pfRgZGVXBvMJqr /= UbAHfZRly;
    }

    return wbREDLAP;
}

double YihSIVbQTf::ITvSfGqD(double pHbRuGXIhhWYf, bool wZnfximbTtUBiB, double jOyeXM, bool MPhYQWnYIl)
{
    int JnREOMvKsbbF = 1709112536;
    bool RfNjNek = false;

    for (int FEyEH = 101783182; FEyEH > 0; FEyEH--) {
        continue;
    }

    for (int RcifDFFriSVUB = 2066148695; RcifDFFriSVUB > 0; RcifDFFriSVUB--) {
        continue;
    }

    return jOyeXM;
}

int YihSIVbQTf::dlaAuafIoAynKiY(bool FkdWEScULCnR, string RTBvwNaycEH, string FezXlQHgoiexowHk)
{
    string cpuZeCEPKvreWnkP = string("QPdSwsVPkjewymYGiUwSoWiHgXYVwCBbnlrGsvFKvSrwzBzhUJPgzYOVRlXAzYwbtHsqnENyGmVDNMDCjphqxsprJfvTJZdOrYuRSXcUOZhrglXdDZAHYVeawFfudShphFmpIGlbHLLBMWDlahiieyFyWUUxA");
    bool JVzMGB = true;
    string NTAxljlcyvl = string("khjAMQYXUWSTuRscIWQFDRNSlxzzVmNmceYBpMukbLsiAQIayvkrWpnqHTeMsGDAIvmunITVxkgQZYMCLFwXzXAEjZTYuJwxeRlEANAAUWPoERHdzRfpYgTIdLh");
    string OIPEFIaEgxcMSq = string("XWcYniJdLZgzPoyvQoMnFXigdvOdlaBZbbxOnQrowxqOYWXQlPeRFGHWaHPUzik");
    string wAGHMlAmW = string("nNJUSOZPPwTgARZZvyeYxCcoCuSMoOALnbLhjdYpwEnRITGURhRteUOserotKDOjaVNwqngratRDOTVXPlKAhRfRBWszBxSGxuXDMmxHDKUulBFELmIEcRNHxscaoOeiTsueElMAarhIlLBEsrhLswJ");
    double DKyDdU = 658968.990523605;
    bool LpTVZKLZl = true;

    for (int mDWRZ = 719479255; mDWRZ > 0; mDWRZ--) {
        wAGHMlAmW += NTAxljlcyvl;
        NTAxljlcyvl = NTAxljlcyvl;
    }

    for (int LbQdXzXVE = 2050544343; LbQdXzXVE > 0; LbQdXzXVE--) {
        FkdWEScULCnR = ! LpTVZKLZl;
        wAGHMlAmW = NTAxljlcyvl;
    }

    if (cpuZeCEPKvreWnkP < string("QPdSwsVPkjewymYGiUwSoWiHgXYVwCBbnlrGsvFKvSrwzBzhUJPgzYOVRlXAzYwbtHsqnENyGmVDNMDCjphqxsprJfvTJZdOrYuRSXcUOZhrglXdDZAHYVeawFfudShphFmpIGlbHLLBMWDlahiieyFyWUUxA")) {
        for (int FWOyNVB = 132618083; FWOyNVB > 0; FWOyNVB--) {
            continue;
        }
    }

    return -1318373536;
}

double YihSIVbQTf::BqYndde(bool GazVLQzkDAIf)
{
    int sJEddm = 1446640210;
    int JBBWwKGSOYXC = -711968969;
    int vfQCUbpcRNMZPzS = -269912058;
    double OMenblGqqe = -861947.8749990335;
    bool bhGWjz = false;
    double zJbuniIGVgdAMQTB = -511084.1578512293;

    for (int TGqesY = 209043616; TGqesY > 0; TGqesY--) {
        sJEddm -= vfQCUbpcRNMZPzS;
        GazVLQzkDAIf = bhGWjz;
        vfQCUbpcRNMZPzS /= vfQCUbpcRNMZPzS;
        GazVLQzkDAIf = ! bhGWjz;
    }

    for (int gMqxC = 1894594246; gMqxC > 0; gMqxC--) {
        continue;
    }

    if (sJEddm == -269912058) {
        for (int ujSQhHJjliROi = 725153256; ujSQhHJjliROi > 0; ujSQhHJjliROi--) {
            JBBWwKGSOYXC = sJEddm;
        }
    }

    for (int obCSbITLYBO = 445941806; obCSbITLYBO > 0; obCSbITLYBO--) {
        OMenblGqqe -= OMenblGqqe;
        zJbuniIGVgdAMQTB /= zJbuniIGVgdAMQTB;
    }

    return zJbuniIGVgdAMQTB;
}

bool YihSIVbQTf::FZQXRUWYhZCaRsXb(bool jdUrZmLArZQX, double SeROmLjLMFCDM, int zpDhlyTtwP, double zpsDPBdYfHbzfyNl, string BMtcO)
{
    bool vixSxehkpjtAYcm = false;
    bool MxXaZDWU = true;
    string veixvgtZqKxtIZ = string("WZYWWIUHQZuSOPWeeJhcSFXoSmXyYUboBMSrhbnRaXxTJSkxnFOPdURcCXTyCwGrBlFHOFYgYXxQVnCvAScSGLObGGpGYAjBXkttaBtPEnUObp");
    double DjKZkXV = 517159.4279541429;

    for (int YqoiLeoMzCWDQDUs = 1019790117; YqoiLeoMzCWDQDUs > 0; YqoiLeoMzCWDQDUs--) {
        continue;
    }

    for (int SiarwhRoEvRlL = 262467886; SiarwhRoEvRlL > 0; SiarwhRoEvRlL--) {
        veixvgtZqKxtIZ += BMtcO;
        jdUrZmLArZQX = ! jdUrZmLArZQX;
        jdUrZmLArZQX = ! jdUrZmLArZQX;
    }

    return MxXaZDWU;
}

int YihSIVbQTf::UIsxUBfZsNsOCZe(string ZfjBTVYqEcxvrlRb)
{
    int HmPQhFLJXNTUcg = -2127371603;
    string SWQzWD = string("KkEBaEUNrKjMFolyCxaSrBuHlMPXRyrjaLyKcQzrcKMRfyCymeCvhYHBfaBqxItgEyAHQiLkHTCcKSmWSLEyFxGwLCJjChVtWqalYfJYEHUPxrXDmVajmVVwJCUqwLSGnlwmBFoabYNbQxdXASMLGTkiF");
    bool cgzYPdTlmPRpO = true;
    int lphAe = 1885738657;

    if (ZfjBTVYqEcxvrlRb < string("LlGIxhEjMrYkISGAGYHdsyFxJJTgHOdplusNfScTdhyrosnVHWWTAMGoLmLQXyWMcJAevtkJLKaUEtbuQDJPhTizDDRxDlqwweHYLfLakDeCeRuLaMbsnpvIZguLylrafXkvqxLSoLweaIgsqJipRXuucNc")) {
        for (int ekxFTfjIk = 1673812747; ekxFTfjIk > 0; ekxFTfjIk--) {
            ZfjBTVYqEcxvrlRb += ZfjBTVYqEcxvrlRb;
            SWQzWD += SWQzWD;
        }
    }

    return lphAe;
}

int YihSIVbQTf::SSrAvmcdeUPlRYs(bool UBBYB, bool XJvJRElrC, double ZsJjAWg, double JPDDNwB, string uLOwdxwvdRegv)
{
    bool YOMqLrNeylE = false;
    double YxKtmhMilyrHVGvm = -309432.7840866264;
    double oYnHALzwgTDKX = 639458.8569409112;
    string kVWtnFrZXkWIhYsJ = string("RsOkAzyhXMAkOrtkLtMnCrTMTmIgKONaERDjmkhxpFHNQSVIBarRNzjVTEiFBDruEinZnBuHLooNQNJUaPozNsvxqxqaXGrErRZgOSjTAtHqdxuMMNXCXQOKIxDLBoWTrDVjPazKibpCsiVfjCGMPCTVPxVlJUzs");
    int XdOHI = -1763840544;
    string wNqOxqvUhREThVh = string("yjiPVfEYESWZvRrWpPqRNskTYOAXLbmtpqezmuFNVozwARQAbmNVnztClCRAackEXNEegfTGJYAhaeAGdNketmNZJoSRruQcVDtQfimZOzAVoBwngzjRRbEIWGYVJHSdzDloYtxFjsootCzVuRFXnXgSBFQOGlHWUqXCELBXexziwobsWnOcUYbPsktLXkhNqqDetRoMQcNlRHrmiHrUExBAHtnGtglsYTZZPhhzETdFQpYG");
    int gjcUSttmBxoL = -1757015937;
    double gtsBr = 107256.5477341699;
    double fIatekvt = -702248.5759324689;
    string iFlRG = string("bUjdEJBLSsGSvlmhDbEkVqDIBTkbTLABkLZuVnsksLsFYWmbnkYwMVgVwPpBvSZtsHZpSfTJmvjFAgL");

    if (gtsBr < 107256.5477341699) {
        for (int IXuMKq = 1033672797; IXuMKq > 0; IXuMKq--) {
            iFlRG = uLOwdxwvdRegv;
        }
    }

    for (int ZtLgPRxTomKgbpLw = 1323603285; ZtLgPRxTomKgbpLw > 0; ZtLgPRxTomKgbpLw--) {
        JPDDNwB = gtsBr;
        XdOHI -= XdOHI;
    }

    return gjcUSttmBxoL;
}

string YihSIVbQTf::fPnBuPiqmK(bool ueSXCCpAup, bool bRbvcLVq, int QRrJQfVLCIIsarhU)
{
    double BIFJvENwBFhcg = 737700.3279157868;
    double oTyCKsuQbVilvG = 910859.3068898744;

    for (int VGEFqEClpr = 1587971011; VGEFqEClpr > 0; VGEFqEClpr--) {
        continue;
    }

    return string("LXUKlpyWxASTBVgHAeBZXSSAyFxebNagNmVCQPlURxjcdXhqWvnqoojfMfaNGhPepvcxpKPxibysvYdvHLqxNOTTYgexlLUiBJdLseCg");
}

string YihSIVbQTf::DxYbTZLKfqseotRC(bool IxppQxFrxbeaqAtd)
{
    string yyVBA = string("tBcxhAqheiIDxARXhmEiXvnZgrJCJvlxLPlMcNQeEVQKExipUpJrFEYqlwguMJadwSrFdxoTGTSIcsQlQytLEEXTmxQqCFYSsdDepcADgHRtaxASwzcxMJMxOPtpSGqbuXPsIsi");
    string NRPYTAz = string("iUMMRpFvLcztUXRUhQlRGkJGssjFTcAYqgQesAkgUlEiGohZdyvuDyVDXAsVdChBZruBSfNbQxapyunGmecFCnJQLkGaNscdqvkKjmdeWTRltQaCiTCA");
    string duzZPXmezhc = string("rpnMhuZrpPjYPtgeIdnzTbmatEYVZaDagZoauAOMdjxmCxCUjAdykoYCLvWEhTnorElRvnudZgecGFPOXJUpVBhumSaVMDOsOZYPDLqIWSiceuuyllqhctLSAggLVjXHTALtacAbaroQpjawzUKyFwDMdKvvVFGfLdsdlpibZrhXmNTsWZHxLFQl");
    string zlioqPqiLkNZMfO = string("CcYPsfwnuMuyNxlCOQFcbxyTETFCQtfdedwcQwZpmbShDOkTEZRAYKszmkJPMMwSiRRPSEiBnpPgPZWKaZJePDFlBViCwwjtlNwGRGFyecfxjqQvUPrHoBQTovzphPJkWAbFoOFpFBByQfpxcNxwISkYwHTQGmOjbGhpgpXDhEpgMZxawozgF");
    double BNgGmbliaF = 676047.4816310529;
    int dJLJbZac = -2078052936;
    double MysqbzFbSMRg = 877725.5294770735;
    double xqPimfeFmZmIx = -911493.4608373223;
    string KPAOJtFtaqCVLZ = string("jLRLZKBkLojsnDrHuLLozloEHvLeSCDgJyVdkkZPTLfqBFs");

    for (int HWonlxzGfFz = 1138434564; HWonlxzGfFz > 0; HWonlxzGfFz--) {
        continue;
    }

    for (int nHgfbRtyqRW = 1860252425; nHgfbRtyqRW > 0; nHgfbRtyqRW--) {
        BNgGmbliaF = MysqbzFbSMRg;
        BNgGmbliaF /= xqPimfeFmZmIx;
    }

    for (int FSgxCocVqiPwM = 1787569220; FSgxCocVqiPwM > 0; FSgxCocVqiPwM--) {
        KPAOJtFtaqCVLZ += NRPYTAz;
    }

    return KPAOJtFtaqCVLZ;
}

void YihSIVbQTf::WirVIRhhjocqFmrs(double JAQqHoWwy, double gWfVkqCqT)
{
    int gaDzHhktINrwu = -935757166;

    for (int DhbJDzUbVE = 1623398919; DhbJDzUbVE > 0; DhbJDzUbVE--) {
        JAQqHoWwy /= gWfVkqCqT;
        gWfVkqCqT /= JAQqHoWwy;
        gWfVkqCqT += JAQqHoWwy;
        gaDzHhktINrwu /= gaDzHhktINrwu;
        gWfVkqCqT *= gWfVkqCqT;
        gWfVkqCqT *= JAQqHoWwy;
    }

    if (gWfVkqCqT <= 389136.4704975964) {
        for (int kyuoyHVTTC = 1847992051; kyuoyHVTTC > 0; kyuoyHVTTC--) {
            gaDzHhktINrwu += gaDzHhktINrwu;
            gaDzHhktINrwu /= gaDzHhktINrwu;
            gaDzHhktINrwu /= gaDzHhktINrwu;
            gaDzHhktINrwu = gaDzHhktINrwu;
            JAQqHoWwy *= JAQqHoWwy;
            gWfVkqCqT /= gWfVkqCqT;
        }
    }
}

double YihSIVbQTf::CoGNwtY(bool rJBPBpgoy)
{
    int ksVoxWYfxhCQQm = -1478925876;
    string aHCJHqpvIDFh = string("zKmOosQuebOnDuCbyXPlMySQomKegVesHKBosbQGOZVvvYymhbCVgqTXQNVFmeyYdpZGEedccYNgQWtbNCbjhIBsJPWltXisSBxphRpuYLa");
    double JFmeSHo = -392066.21192125586;
    int wFsXJxJo = 731995921;
    int MyAcrVCxyKWsPHj = 39156071;
    double ovggCEXVVhHKcAay = 138707.02540446;

    for (int ceuXNuhqIXcGnlfX = 1008521320; ceuXNuhqIXcGnlfX > 0; ceuXNuhqIXcGnlfX--) {
        JFmeSHo -= JFmeSHo;
    }

    for (int XOhkTbSMKfESxymD = 104527055; XOhkTbSMKfESxymD > 0; XOhkTbSMKfESxymD--) {
        ovggCEXVVhHKcAay *= JFmeSHo;
    }

    for (int sJpHJz = 1574625679; sJpHJz > 0; sJpHJz--) {
        aHCJHqpvIDFh = aHCJHqpvIDFh;
        wFsXJxJo *= MyAcrVCxyKWsPHj;
    }

    for (int GjozGPyZNnirx = 1324578555; GjozGPyZNnirx > 0; GjozGPyZNnirx--) {
        aHCJHqpvIDFh += aHCJHqpvIDFh;
        MyAcrVCxyKWsPHj *= MyAcrVCxyKWsPHj;
        wFsXJxJo /= wFsXJxJo;
    }

    if (ksVoxWYfxhCQQm < 39156071) {
        for (int CdbBmmLPhdWf = 533413313; CdbBmmLPhdWf > 0; CdbBmmLPhdWf--) {
            wFsXJxJo = MyAcrVCxyKWsPHj;
        }
    }

    return ovggCEXVVhHKcAay;
}

double YihSIVbQTf::zyOncEJ(double tHQTDihLYQUFAV, int AgYGSQvMTF, string WCujfiDwB, int xVwtKfdaaxy, string DixrkZByx)
{
    int mPkDJRtllGZdXD = -1613640910;
    string lXnAuIfSHFLz = string("KTjFReGXJSNUQSRPThDfZCOl");
    string PujKFRmCxmryoX = string("LBsBPiJPrahukfdbtlwuBBcwrFMjmPyWJLkXaZILLZZuXrKTginWYrkgRyDTVKUgpgRkUpPuPoRYoRoNIVmitLNYhdNaLyDpXWNSWPodZqQrabSAVmxEwHUomTIvLvdttcnTsxQboITgrWNkwvxKCrmJMOkhNBAeXhTqzkaqIJEaMuwfBuzghJBNCa");
    string cViir = string("NkfmoCWieaNKCNSjurucPBmyBJEZffpyvnakUbMhIMIkqEAgPagIkpQdVwCMVKdgeVmeJJXAPlRduOGwxdkJpJOhcjFwTRQYKBqvQBIvCKOvYVdfRXPxBlOCNkqkdsKNnGtz");
    string TNDaZKDSczUJMkRP = string("EKgfmummUcTWLtFtHRQLoPAQOtPOlqkqKLqbxcYvJbJNPXpxjsCGmIhxcHloBruRKafcTVOUCeoTJQntdUAWjXjlUnTeMBsKoYuyADDqcpqSeUKDXcoPlpWDtFfMpWTNMhvQbDJkXAhrLUlMDKUwVbZVDqkoVPXAwxEsdhflcrLUyvKvmxIVOGTPIzXZRxfuhbJGmNxEDtayMOGeGifWDHgHJHyzbJQXByYMxWAYUCxieKdoCrXBnDibmIzpn");
    bool iAlgedDFHTAD = true;
    int rPuNpIPXUWcr = 1492228028;
    double NvODDsCxOQYb = -273008.4550764647;
    double YBTGShXyrQRab = -155153.25268650058;
    double zvPOo = 21958.366069277992;

    return zvPOo;
}

int YihSIVbQTf::COblaFpqLz(double HGHxROr)
{
    int QDDGevAfuX = 1453884548;
    string oLUmjayZSwAur = string("HmmgMfGRdZxkqzZsvQxDfQQQNTDfvNRntBwSycAoPMYnxdLBOVaEWlwLksLLlxTeFsevGHzQIZHvjbhRnmqSmUJxFyhZiRnAoPDexfAOVHNVLNkmoypfeUeaSQDtlmscXCNaVBWElDltaSvfvuZTYA");
    int tEvYCb = 188276022;
    bool uCyWehlETTRq = true;
    string JUArUKqblzbO = string("QCEgbdhvpiQlnMLR");
    bool fmXYRYtCATBlT = false;
    string FBdRr = string("iOoYgCpumaiVPWEYAQIgDysfFXfsfQUXRgqhJss");
    string rigHEWBviSDSWo = string("oUKcNqejzwIgADCfjWrpE");
    double DhXKFU = -819775.1887745305;
    bool JvJahOfAsK = true;

    return tEvYCb;
}

string YihSIVbQTf::YGSsweXUMLRs()
{
    string WNgTsAcFuDoROvIo = string("SlMNwxGCYwIxYJ");
    int nxMjBikWZLohLH = 512209489;
    string rGsxjBUPq = string("KVvhdTVNclQUcyVUQoMqrfEogXbyYDEsoZeGwxhgGvVvJjDBPLUqikDVPDMTyZeeluXzDqRHUqmaMZNXzefmRzTrlBDFQVGnVRwxnADuzGHNpSSypsWswNYFbkGXRTSOmYAjSobommLcDeFIuIzhSNlmfxacooVTiEYiAWDfudIMYmEfc");
    string MYJnBZXo = string("YAkqguYXlNDPzlSzJfnxdLOHvPjLtlsNfOXiBjEnoRIHuNPshZXvHzjUAOUBzKgOtTWwZAJPmUZYOhOKBamYxaSilyScUiClBCfvbUOJOCgoYEaSEHikdlagRPodBXGDIihN");

    for (int PlsbXAx = 1814763673; PlsbXAx > 0; PlsbXAx--) {
        rGsxjBUPq += WNgTsAcFuDoROvIo;
        MYJnBZXo = WNgTsAcFuDoROvIo;
        MYJnBZXo += rGsxjBUPq;
        nxMjBikWZLohLH /= nxMjBikWZLohLH;
        WNgTsAcFuDoROvIo = rGsxjBUPq;
    }

    if (MYJnBZXo > string("YAkqguYXlNDPzlSzJfnxdLOHvPjLtlsNfOXiBjEnoRIHuNPshZXvHzjUAOUBzKgOtTWwZAJPmUZYOhOKBamYxaSilyScUiClBCfvbUOJOCgoYEaSEHikdlagRPodBXGDIihN")) {
        for (int ClVbyBhMhwUO = 139198316; ClVbyBhMhwUO > 0; ClVbyBhMhwUO--) {
            MYJnBZXo = rGsxjBUPq;
            rGsxjBUPq = rGsxjBUPq;
            MYJnBZXo += rGsxjBUPq;
        }
    }

    if (WNgTsAcFuDoROvIo <= string("SlMNwxGCYwIxYJ")) {
        for (int CKFOvmxtyPC = 1721083757; CKFOvmxtyPC > 0; CKFOvmxtyPC--) {
            rGsxjBUPq += rGsxjBUPq;
            WNgTsAcFuDoROvIo = rGsxjBUPq;
            nxMjBikWZLohLH += nxMjBikWZLohLH;
            MYJnBZXo += WNgTsAcFuDoROvIo;
            MYJnBZXo += MYJnBZXo;
            MYJnBZXo = MYJnBZXo;
        }
    }

    return MYJnBZXo;
}

YihSIVbQTf::YihSIVbQTf()
{
    this->PwvEXGG(1798390190, 63055.176649274574, string("dAfhmNaHmvsFucMmwioySUzWXQ"));
    this->vlhjhb(-98651579, 1138603880, -724938.4269277414, false);
    this->JUJRHeJyJyvjWV(342155.5569464646, -66489135, string("tJGMKDZmTyxhsTLaQVNNQCVGKxPeyCwsTnpUskczAlIzmcRwaSrJHgDpcktOigaVcYXqyCoNkvwjBcOOuZAHdKivdZRxifTwyATIPOzPkUrCvBWqXsedGiQmXNcDlfsctyQcSJClml"), string("HlihmbinuzDnQusSOIMKfotystvLYfkyedUZqUbIqoJgbmuEghUbtSKsEHvChhEuOgUVQkUiFecQgDbnPyVHircTUwGKIYLTOjnIrTetLKTRMQbqxrSAwymqOKcLqbEZLtvvMRktBbddnPEuNiGgLkOUaTwNRwfBQBQogOAHskbMZyJNddesCKzlstBnWAJHZhUmtRBpAvsERMasvcIHToCVozp"));
    this->ktsVNM(157335.42169735394);
    this->UgTwl(-233716336);
    this->jJsWeLugcvVIHGq(string("cGDvhVsbTizWsRxzJsRimBeYXiwAlVCZINIxNHXNuLiwxJxdGkBfFZxotfICLgvGDoGERrbAaUsmEySEOrjfKHtVkDagwMMnFtWIwgPshofvvEqJohVXzxTJcWhMHDlWkWFjtTaYFeNzLWzZRVHHrHHpTOKZqGqtcSbrVHZmYcSHjKFuOtPNRwpIIRYPIaklVCCNnUdawNYNBWCOwXEqmmYJufsRAWHUZNnJiZNGmAsXkGuLJRPgNzKQnSMEPSW"), string("ZgBgZMbetzYsfCHazdiYdmMHUfmMCXdLRIrDQuXnhdKiSDvPoSZSaJTkTA"), 1223989041);
    this->PrPIoYKJpI();
    this->NgntGCq(-314510.18263515976);
    this->ZUmUjJfMAAlTbo(-286072.76387240767, -14775525, -1796671985, false, false);
    this->ITvSfGqD(337456.49438215065, false, -311787.64994791884, true);
    this->dlaAuafIoAynKiY(true, string("hrmzFTlTYMNpRGKzkyQiMJqhhbSyXNooHqPUNz"), string("BillCjyOjmflhsxNvAAPbisKBpcKaAcWdfvJgInbeZbGYWXUFTwmRWAUNBGQWgeNvdZrVaaetWyBvhQUEFsFpbMLwsCwMMlvcpmneAlicOPIImsyEvsKdhxGjcelIVQEricJrMizgHRcHdgTvbUHExLCxXJItOpoMNEtLTVxiOckFjymYAjmXRloAdyAOjHNMdOaMMvSc"));
    this->BqYndde(false);
    this->FZQXRUWYhZCaRsXb(false, -612913.3975842779, -414868479, 416878.34008690104, string("rVWCaiAJggYTHnCfvJQOrLIVJYimqpdMSOPdrbvhsWUMygVMbvdGBzTVkGGwgGqYnlEIaFOTAulrcyDRuRbPsZhvlRwOZMPev"));
    this->UIsxUBfZsNsOCZe(string("LlGIxhEjMrYkISGAGYHdsyFxJJTgHOdplusNfScTdhyrosnVHWWTAMGoLmLQXyWMcJAevtkJLKaUEtbuQDJPhTizDDRxDlqwweHYLfLakDeCeRuLaMbsnpvIZguLylrafXkvqxLSoLweaIgsqJipRXuucNc"));
    this->SSrAvmcdeUPlRYs(false, true, -504659.85473810934, -131991.8805174888, string("yvTXmUWwffNxmlmkgzsAwOsLLHZonOKMnuABaNTgXSXenrhntWmKrwqOOORZeWCHdovDIlluqsHwraKFrRVatXxHgtzGGgRUmzazJPzPqdAIiz"));
    this->fPnBuPiqmK(false, true, -506304603);
    this->DxYbTZLKfqseotRC(false);
    this->WirVIRhhjocqFmrs(389136.4704975964, -499313.5873015632);
    this->CoGNwtY(false);
    this->zyOncEJ(812219.3073930802, -2138924975, string("UgihQUrbARWdSstVpVqVOJsTUGvtqNuUvccOkwYbmlasUEsvzdRyNcCsjitIdNr"), -842089281, string("DboLGkBrfCsFAuVbiTkExIHMRSmcFzjlCWGzdKDyXkh"));
    this->COblaFpqLz(487461.39569392666);
    this->YGSsweXUMLRs();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class bDwPEwaRieiHhgv
{
public:
    double VvsTZmpscId;
    bool JfMJihbbbVhENMM;
    string LAmqBBBAnSqP;
    double IkdpJkhkzL;

    bDwPEwaRieiHhgv();
    double YrXKqQJjJ(bool uEAKJtlpKnpCYX, bool TRFdBNwrBAxnavG, bool YzkPErBN);
protected:
    string LySlPSIYBBoBDn;
    string hqFsLpW;
    bool ORjKDqUEXursGjg;
    int MoRSAWzHVKB;
    string yugcpL;

    bool YJECKktlgE();
    double VGKuOzTvMgeDT(double MEolcpkAWznFRAQ, double oosQOVR);
    double fegREKDj(string erggMPI, string pgokmtFMfp);
    void hBZXRNhZBjP(bool RssYwadJwgKkpHB, string TdeWGA, string BwoIIDaGvNzQ, double cPMNY, bool eDnDkcSaKxLHYiQp);
    string WZgMaghluSnoKY(string HMUXCERxBdRkjKKN, int zFcEyHNZWKUZl, bool tWFhku);
    double mSwLmUoKQHpnOq();
    double XYpBDWRilZ(string EXAUgAWRkC);
private:
    int JPWKVnDikQiXjd;
    int gavFVbQxIV;
    int tKuuZ;
    int zPBmCWWBiSogzOwc;
    bool FKRtYtNJmPAxTDzB;

    int YywvAVBwpqd(string EJUMKyRvE, string hJZYrz, bool HAsUfGDvRCaPm, int hIMUrGy);
    bool mAHLq(string GBNQxWmxg, string kcQaRv, string ouakoJeCPIJ);
    int gBhLee();
};

double bDwPEwaRieiHhgv::YrXKqQJjJ(bool uEAKJtlpKnpCYX, bool TRFdBNwrBAxnavG, bool YzkPErBN)
{
    int JiPxfOQEmTwIAE = 1711325415;
    bool AwgdwGJEoRos = false;
    double qKEoQKo = 382415.4660445828;
    string sjdUMxu = string("sWmLRZzFRVisSchBdxzoKUCdQfoMsNVeaxrsvlcTPjVSzQkJePSpmgHemisjRGuu");
    double KnYLMWcLz = -377100.00307226606;
    bool fpABZdkE = false;

    if (AwgdwGJEoRos != false) {
        for (int ZnElUqRHdBKpbH = 1277763947; ZnElUqRHdBKpbH > 0; ZnElUqRHdBKpbH--) {
            fpABZdkE = fpABZdkE;
            JiPxfOQEmTwIAE += JiPxfOQEmTwIAE;
            YzkPErBN = uEAKJtlpKnpCYX;
        }
    }

    for (int kEGzzmNoCtyKK = 299138619; kEGzzmNoCtyKK > 0; kEGzzmNoCtyKK--) {
        TRFdBNwrBAxnavG = ! TRFdBNwrBAxnavG;
        uEAKJtlpKnpCYX = YzkPErBN;
        AwgdwGJEoRos = ! fpABZdkE;
        uEAKJtlpKnpCYX = ! YzkPErBN;
        TRFdBNwrBAxnavG = ! uEAKJtlpKnpCYX;
    }

    if (TRFdBNwrBAxnavG == false) {
        for (int VpvZiBIswqdB = 1352452619; VpvZiBIswqdB > 0; VpvZiBIswqdB--) {
            AwgdwGJEoRos = ! TRFdBNwrBAxnavG;
            uEAKJtlpKnpCYX = YzkPErBN;
        }
    }

    return KnYLMWcLz;
}

bool bDwPEwaRieiHhgv::YJECKktlgE()
{
    string ELIpMOgUsBglxFG = string("HCljauODqYDTwqcftgPPQvQlsSxbiZDOzPcHTSwgyQppvXeLcPioDKKPOUeGvHAyXNVxxRPQVAlFCK");

    if (ELIpMOgUsBglxFG != string("HCljauODqYDTwqcftgPPQvQlsSxbiZDOzPcHTSwgyQppvXeLcPioDKKPOUeGvHAyXNVxxRPQVAlFCK")) {
        for (int kefmnHrLCgzKWcju = 245157298; kefmnHrLCgzKWcju > 0; kefmnHrLCgzKWcju--) {
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
        }
    }

    if (ELIpMOgUsBglxFG < string("HCljauODqYDTwqcftgPPQvQlsSxbiZDOzPcHTSwgyQppvXeLcPioDKKPOUeGvHAyXNVxxRPQVAlFCK")) {
        for (int LuJEgeiFNm = 580463173; LuJEgeiFNm > 0; LuJEgeiFNm--) {
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
        }
    }

    if (ELIpMOgUsBglxFG <= string("HCljauODqYDTwqcftgPPQvQlsSxbiZDOzPcHTSwgyQppvXeLcPioDKKPOUeGvHAyXNVxxRPQVAlFCK")) {
        for (int oMUHKQ = 748043807; oMUHKQ > 0; oMUHKQ--) {
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
        }
    }

    if (ELIpMOgUsBglxFG > string("HCljauODqYDTwqcftgPPQvQlsSxbiZDOzPcHTSwgyQppvXeLcPioDKKPOUeGvHAyXNVxxRPQVAlFCK")) {
        for (int zbHSrROhBuCwdRT = 1058175611; zbHSrROhBuCwdRT > 0; zbHSrROhBuCwdRT--) {
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG = ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
            ELIpMOgUsBglxFG += ELIpMOgUsBglxFG;
        }
    }

    return false;
}

double bDwPEwaRieiHhgv::VGKuOzTvMgeDT(double MEolcpkAWznFRAQ, double oosQOVR)
{
    string FkyxIDx = string("lxewkJnaYBUAMErEUOiSwSFhtrTXqdVctGEMcKHAVraMLVfHoAokFypUEtOWyquXjfbNyZcGwxOkQvPHdXjronNkcFLptJqPfqHQDzpYwoJXQGEpTQnSWoBKvdFLvnUOoZapEKNTZHpnRaVuTQVGZgSePwqrXfvLWsPqffupAnVtzNHuZXtJZLQNZqMmPENpwncUoCbuf");
    string gxTCA = string("xjoMvgeASaVedITmZfFqYYzNpBcxPjbgLQnpiJLWGvzmoQIZvpXaaFCEyWnVKBehxJiOSutvjAjCpzJKNqPorUNVzJxogysbPFWBmgSXMwaHpxqnLbQbeGnFZRRLggStWVZbCMdllklIPHGGcyzQWXYZOEibAYEtDymhlxQOefEJ");
    double TsyIokbITXezRG = 48837.288621716994;

    if (oosQOVR == 48837.288621716994) {
        for (int LqpgQOWMkIXU = 1832253150; LqpgQOWMkIXU > 0; LqpgQOWMkIXU--) {
            TsyIokbITXezRG += TsyIokbITXezRG;
            oosQOVR /= MEolcpkAWznFRAQ;
        }
    }

    if (MEolcpkAWznFRAQ > 48837.288621716994) {
        for (int wPKXZFohBpl = 1999362312; wPKXZFohBpl > 0; wPKXZFohBpl--) {
            gxTCA += FkyxIDx;
            MEolcpkAWznFRAQ = TsyIokbITXezRG;
            gxTCA += gxTCA;
            MEolcpkAWznFRAQ /= oosQOVR;
            MEolcpkAWznFRAQ *= MEolcpkAWznFRAQ;
            FkyxIDx += FkyxIDx;
        }
    }

    if (MEolcpkAWznFRAQ <= -100905.11095335241) {
        for (int WJNMrieRZtnYo = 568258364; WJNMrieRZtnYo > 0; WJNMrieRZtnYo--) {
            TsyIokbITXezRG += MEolcpkAWznFRAQ;
        }
    }

    return TsyIokbITXezRG;
}

double bDwPEwaRieiHhgv::fegREKDj(string erggMPI, string pgokmtFMfp)
{
    bool NrRGNfYizVFuAz = false;
    bool AxdibjRlZP = false;
    bool eAOoOVFyMUoHmwm = false;
    double UTGAPDQeOshnhNc = -232092.60729128786;
    string JkVAkRjuG = string("pTIwfoSmuaHtDBjKBLXvvXQsPAnRBZntCBcPiqIwzCDDbAacTQiJRIlrosTLfFOtoNfdRnQIavgXgt");
    string ywHylUDnmEmvLoSx = string("QobYnYjHVuzMQXOQfSxftpSgtifclBSJcYjXzccuqHkRVVmMfrioisWSyDDvXWKKFTAjIextgtOEVigfKcUFvxDhYwoNZVltCVhgtcsjOZfFTVGCThTTxXbAoTjBPKmnrCtAoXXYwnaJDwnCLghzFoavoVTkPzDYXCOugWeHsDnaesKspDhgqEzltL");

    if (erggMPI > string("QobYnYjHVuzMQXOQfSxftpSgtifclBSJcYjXzccuqHkRVVmMfrioisWSyDDvXWKKFTAjIextgtOEVigfKcUFvxDhYwoNZVltCVhgtcsjOZfFTVGCThTTxXbAoTjBPKmnrCtAoXXYwnaJDwnCLghzFoavoVTkPzDYXCOugWeHsDnaesKspDhgqEzltL")) {
        for (int KSKFh = 1862014810; KSKFh > 0; KSKFh--) {
            AxdibjRlZP = NrRGNfYizVFuAz;
            erggMPI = JkVAkRjuG;
            pgokmtFMfp = JkVAkRjuG;
        }
    }

    return UTGAPDQeOshnhNc;
}

void bDwPEwaRieiHhgv::hBZXRNhZBjP(bool RssYwadJwgKkpHB, string TdeWGA, string BwoIIDaGvNzQ, double cPMNY, bool eDnDkcSaKxLHYiQp)
{
    bool aoEGBZbOXurh = false;
    string WyaVOSmL = string("OutrwuUzjgjuzlthjjKEUFvkZxQUsNTpFvdzYgaezbKwNUzskxeQxOYkAPsKGamXZHLOlxsYHhQOkuBIMRuBXWRWxKbGbysBeoatSmihqW");
    int HgvjnaJRLOIXAAI = 1590866753;
    int ULmIM = 452225990;
    int tcbVzxeOiLeoTr = 620515804;
    double rMuZMfn = 1033813.2793986364;
    string OuZOwMnC = string("khyXKdQrnqWgchuWGStgZSFGdrwboGNUYstvViprEbGUupSacfCNOGLyMMXYtVNbJOVBixAGVAExGesTXofasTsIMEuHZwAnoNvnjCofZRUvgIyMGeZdionnWYMueyYvxUcVkkRhYNlGOptesdAARvDymHXWnMTaMoUBvSgRHAzuqzVarMNqouusIroIPfRwmOjkEmoDcvwARFhaZdTgYOToBvZBMpjKoOxUFSXuAp");

    for (int DJXplkLl = 14574373; DJXplkLl > 0; DJXplkLl--) {
        aoEGBZbOXurh = aoEGBZbOXurh;
        HgvjnaJRLOIXAAI = tcbVzxeOiLeoTr;
    }

    for (int QJdGt = 400613121; QJdGt > 0; QJdGt--) {
        eDnDkcSaKxLHYiQp = ! eDnDkcSaKxLHYiQp;
    }
}

string bDwPEwaRieiHhgv::WZgMaghluSnoKY(string HMUXCERxBdRkjKKN, int zFcEyHNZWKUZl, bool tWFhku)
{
    bool DWQCOULMOzvXM = true;
    string hxZwNNJcicGvLdYv = string("YKEIIofcQNEmrxhaosCqlOajaBgFbh");
    string UHCWafccCF = string("sgILdROlRwRdKNPgczyjpuUxAxnNVJrV");
    double cwKBWkWHOQdq = 646783.4110288935;
    bool UdcqZZ = false;
    int JawlYRyszR = 1433084946;
    int YPofSjZSSrRZgJ = -1388791618;

    for (int xqOSAmw = 1502853334; xqOSAmw > 0; xqOSAmw--) {
        YPofSjZSSrRZgJ += YPofSjZSSrRZgJ;
        zFcEyHNZWKUZl -= JawlYRyszR;
    }

    for (int XyJstLuP = 304567674; XyJstLuP > 0; XyJstLuP--) {
        HMUXCERxBdRkjKKN = hxZwNNJcicGvLdYv;
    }

    for (int oYPrTtpeJf = 1567960347; oYPrTtpeJf > 0; oYPrTtpeJf--) {
        tWFhku = ! tWFhku;
        tWFhku = tWFhku;
    }

    if (zFcEyHNZWKUZl < 1433084946) {
        for (int FTvtlfJChBhgg = 1977288944; FTvtlfJChBhgg > 0; FTvtlfJChBhgg--) {
            continue;
        }
    }

    return UHCWafccCF;
}

double bDwPEwaRieiHhgv::mSwLmUoKQHpnOq()
{
    string qNlROnIxOUr = string("qCXimrIHhWZSWvfBkTuzbfymEIFMfbouqFfYoVonhWUImPDDqVZffCsZyZzfoSxIVcucQdZMcNgKiwrjITmRIiXNKqAkZYDtqnMBxOETUZokyWibawavjrypeNzR");
    bool mIwilJl = true;
    string ZPcbcHtiBB = string("ihDSMLVcwhHyDhELrMmCfTZLUFwDuafLaOXJGGaFujYLrbQGIsQYlqDnXGSoCBpizWSGHvmenEmGmDhUEERTCKIloWGMziALiGTYKSHLyWmaCfnBHnVUaNkluyPbcqHIQfozJeWKBbNBjmiMCXsEqP");
    int pKuNB = 2061144940;

    for (int KeoACTtO = 143290120; KeoACTtO > 0; KeoACTtO--) {
        mIwilJl = mIwilJl;
    }

    for (int GzvIozseZm = 2067809247; GzvIozseZm > 0; GzvIozseZm--) {
        pKuNB += pKuNB;
        mIwilJl = mIwilJl;
    }

    for (int piZLlkJ = 1456019375; piZLlkJ > 0; piZLlkJ--) {
        qNlROnIxOUr = ZPcbcHtiBB;
        qNlROnIxOUr = ZPcbcHtiBB;
        pKuNB -= pKuNB;
        ZPcbcHtiBB += qNlROnIxOUr;
    }

    for (int txDOJrTtqV = 177181075; txDOJrTtqV > 0; txDOJrTtqV--) {
        continue;
    }

    if (pKuNB <= 2061144940) {
        for (int llsRPONqaQKYLqz = 580679273; llsRPONqaQKYLqz > 0; llsRPONqaQKYLqz--) {
            ZPcbcHtiBB = qNlROnIxOUr;
            qNlROnIxOUr += qNlROnIxOUr;
            qNlROnIxOUr = qNlROnIxOUr;
        }
    }

    return 547248.8706310866;
}

double bDwPEwaRieiHhgv::XYpBDWRilZ(string EXAUgAWRkC)
{
    string wmAswhsBZGKb = string("bCmrYGzfMcxMlHUvlJkAdPuTTQdIuvXaySiWxxgRfeqBHWnRZIhQKDtaruXbqRLmunimNiiVFpPrjSvUPNYmIXDpuVaSfYQNtPztZWRshcLzZKEJjSJPmHBRcsketsbQMVjkxBGNctLq");
    string bFipPCLPaXFr = string("LKNzmVBmzjYJwPvoxIIJIDylGyrVwxQMFraaSasofELeufAEOBpAwpMFUfpSdeGlLaoBGLsSrdprUOLOHdOHbepgQebjdutqxnpaRzNMwULEggIyjzWohfsboOivCyKvbbsaNwusrARRExLkCFmQWGYABTNbxnjfVdktjPnoMcyMEJEXZuZDRFIBacNkmpp");
    bool LFuVUtoeuHmdscM = true;
    bool BbKZpAT = true;
    int RxrbPKAiuopOONVR = 1437270144;
    string ybyNgWUM = string("HOvPjwvmNiEetihujmjSLrQhzIPbFwJWFmXXgKtRScomUnSNIoatjFdfckxyrhvtBIqDftuBisdRsIXjbMkEspGTdGSIJWvxyJUiuDqtlWmIXwkNvKTyBOuWyyKfUKVFAypiWHvlerFBLNGPNYVuGSDTQybUwTsSIYIXrMuLYGaxSbSjiMvflnRGOjkytLOXRlWPZRLlxMxmhMZagFwKbPkHOOmqQkMDxWhYJOqDTJZAskjtMc");
    bool zEVEObuEPXOu = false;

    for (int tYCffeKPuta = 1879693533; tYCffeKPuta > 0; tYCffeKPuta--) {
        wmAswhsBZGKb = EXAUgAWRkC;
        ybyNgWUM = wmAswhsBZGKb;
        bFipPCLPaXFr += wmAswhsBZGKb;
        EXAUgAWRkC += wmAswhsBZGKb;
    }

    for (int gzstqt = 74810594; gzstqt > 0; gzstqt--) {
        EXAUgAWRkC = bFipPCLPaXFr;
        wmAswhsBZGKb += EXAUgAWRkC;
        bFipPCLPaXFr = bFipPCLPaXFr;
        wmAswhsBZGKb += ybyNgWUM;
        BbKZpAT = ! BbKZpAT;
    }

    return 118955.577919612;
}

int bDwPEwaRieiHhgv::YywvAVBwpqd(string EJUMKyRvE, string hJZYrz, bool HAsUfGDvRCaPm, int hIMUrGy)
{
    int PmsYhyLQUcc = 1834915434;

    for (int NFjgh = 662680180; NFjgh > 0; NFjgh--) {
        continue;
    }

    for (int qaIijOjzXjCD = 1730762461; qaIijOjzXjCD > 0; qaIijOjzXjCD--) {
        hJZYrz += EJUMKyRvE;
        EJUMKyRvE += EJUMKyRvE;
        hIMUrGy -= hIMUrGy;
        PmsYhyLQUcc = PmsYhyLQUcc;
    }

    if (EJUMKyRvE >= string("UqayQzkbIYyTPRTDjgHOoDhmxxVbIDFVRAbPnmdokEbbifkyHgedMJJvcUYjKKUXbbybQpHiAyzcrDJiHIjeSBMgCCrbIVtAwktPuEbcasXxxwSPYX")) {
        for (int ZKMfHvGmFCpiN = 1465443379; ZKMfHvGmFCpiN > 0; ZKMfHvGmFCpiN--) {
            EJUMKyRvE += EJUMKyRvE;
        }
    }

    return PmsYhyLQUcc;
}

bool bDwPEwaRieiHhgv::mAHLq(string GBNQxWmxg, string kcQaRv, string ouakoJeCPIJ)
{
    int NarkatqNI = -94292977;
    int gJUkczPg = 156869515;
    double nlTojMHEEtZ = -1038672.0014435693;
    double VjOerruvT = 240781.03792277834;
    string gxHAgPtpBivD = string("kiX");
    bool McFtnCNLTeyhYry = false;

    for (int BdiGejXzn = 1546511169; BdiGejXzn > 0; BdiGejXzn--) {
        ouakoJeCPIJ = ouakoJeCPIJ;
        ouakoJeCPIJ += kcQaRv;
        VjOerruvT /= nlTojMHEEtZ;
    }

    for (int arogdxApMFFZ = 667514693; arogdxApMFFZ > 0; arogdxApMFFZ--) {
        continue;
    }

    if (ouakoJeCPIJ > string("vYwGINZxpYXEHBzfjQlJOURiAvXGdEGsNEegAsHyMevBkKWpCjSsdPzJocCHZfYqGkbFYmyKByMVVlcZEhEkIdLXuaUnIHXKRGbAySamnjDQYoMB")) {
        for (int nlvzkrxGlvOn = 2124170881; nlvzkrxGlvOn > 0; nlvzkrxGlvOn--) {
            kcQaRv += ouakoJeCPIJ;
            gxHAgPtpBivD += ouakoJeCPIJ;
            VjOerruvT *= VjOerruvT;
            NarkatqNI += gJUkczPg;
            McFtnCNLTeyhYry = ! McFtnCNLTeyhYry;
        }
    }

    for (int TDLFv = 550969551; TDLFv > 0; TDLFv--) {
        continue;
    }

    return McFtnCNLTeyhYry;
}

int bDwPEwaRieiHhgv::gBhLee()
{
    int gVMsKQNiiNT = 2009770972;
    int YdyfEheZO = 357280403;
    bool FckLHjNRLQI = true;
    double lIHVPJDEY = 176635.09394083358;

    return YdyfEheZO;
}

bDwPEwaRieiHhgv::bDwPEwaRieiHhgv()
{
    this->YrXKqQJjJ(true, false, false);
    this->YJECKktlgE();
    this->VGKuOzTvMgeDT(10416.16336968596, -100905.11095335241);
    this->fegREKDj(string("PcaFqIHMUorxGSCFGVFEdcTcmrztpJKEPVERiiiXqCTIXnYGHgEctzgNilGbeoorhmhEMcpjknbHeGmnOZjAAzhQdawRSSxnjnuMONZIVhJobzklnbYHOJQAyGaAReNYAlXebESkceRQmkVWSnIq"), string("PSHGIsSaMSWFtBreIrgdJrYaWrqUxEhcFRsUNpPhtcaNrRImmfSsYSfZuptVQCicQQvDwXjfuLKLPpfdgKljkuDOThneZFwxzIvZrrwUViJnBfEtDrXKdnhieKtoKADVfCFxWIDYNhSSxTuUHVzmnhkMMneRXBMtRWicdIpAcLHfIxFGYwgSDOvLrT"));
    this->hBZXRNhZBjP(true, string("wZtvTbIZybGaFjpQCrdJKlgmcjkuuQrPMKRCYRCTBGIBObMcpNuArkNvCfJJmqjWZcBSOsNvhIzTCjHwktHgExHLtLZservwA"), string("hHBdnDZABtQUqhUoQpJsoqQASvDOlBkruCfjTKuBoJyjhIyydqHbURxdQUvpVQDWfLpdTNNCGxhCJVrUwPgrycfWRIeDvxukQSIVoSRmHaHvLCUmWDCZhuUGi"), 276634.08881346125, true);
    this->WZgMaghluSnoKY(string("MsKIMHZSrrkbYIxAIddNKgCZRYwZmNUAROBPlzCoycNyaqGjrVdVTtyZPDSZuAxOvzmMWQdPWVGKFzBFrWsDJwMVuZZNPvKZp"), 1050658593, false);
    this->mSwLmUoKQHpnOq();
    this->XYpBDWRilZ(string("mrmGMrnpmcjJzKAiDoiDDJGvhxzXfsVYFpYteBhvEmYTWmOOruBAlYLyEOsWJkTgfhBwMFIkgCBQKEXBhsAOFJepuayoQJgUEthAawDyoCxjTxSVqopnEaiFnkfspUeFEoIwZZVmgXZmzpNjvQKvyOUJAeqBFzFyBmQeNEOUdPFOgYPkJXihNUEqFjwyMtNtzDxuXNXWeFFGRgjOfRpXHvdplstxAXUDLgbCLHHNJToNVrMgAheVuaW"));
    this->YywvAVBwpqd(string("UqayQzkbIYyTPRTDjgHOoDhmxxVbIDFVRAbPnmdokEbbifkyHgedMJJvcUYjKKUXbbybQpHiAyzcrDJiHIjeSBMgCCrbIVtAwktPuEbcasXxxwSPYX"), string("HtRobNlAAFSNRADcwGqYQKVlwdgMlZUvBLFVJEvngnQoyKmHFkMLQQQcQTmtrzadEMwrpywiQCSsFqLaNkOJYXJJayeEwQXUpHZpbJEHDSIGQxtKckfVZGvHclLhqFSKhRIbCfOcMppBVZKOeyOyyUmVaJMoOIybNiCqCbGDlgIVkdeYLoWELRmhTtAiEkYfNkMSxOkGTEGGQPLIPVzMQRnqyGeOlUTuiSizFlkMaNdX"), true, 55715507);
    this->mAHLq(string("vYwGINZxpYXEHBzfjQlJOURiAvXGdEGsNEegAsHyMevBkKWpCjSsdPzJocCHZfYqGkbFYmyKByMVVlcZEhEkIdLXuaUnIHXKRGbAySamnjDQYoMB"), string("oCVdLtfqnxlUNQGkKFsGiHOaExdPqNuJZSMikBvqkKRiSfmAiXZmybCmObwcQPFrvhPExtIOvaPZWtWRAWNbtjRitjqE"), string("BEjGsZIlrgckGyFUAOkviwqQmYWygNwfikpoveyijGttzpcJVjhJuhoSVDwBhANRUhqD"));
    this->gBhLee();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zgCpiXtI
{
public:
    string yozhzxK;
    bool dAMxDkSUnxXTZ;
    double rBrWuMoISnRMp;
    bool YWCWZPQK;
    int SJEIitQ;

    zgCpiXtI();
    bool UgOigFrTdqoPSLE(bool thGnuwddZhgP, string IcFDiGMIK);
    double sUdZaR(int IaScmjYuYcWDIo, int SCJzxsJITcdAHr, string sHIObmZBk);
    double uirxROBHCXJL(string zjdHOBxbgAYBRDO, double wbDsIJpkm, double cyWMfkYEFti, double KTVrQBYVr, bool wAzJIcXhaoVp);
    bool cTBynkbbNImqfay();
    string YjaMHOJNtMTxto(int zsaJS, int PEOyAqeWo, string DTAqdDdEYpsruaP, int LfwrgtUKBMOPVwvH, bool cfTpHjzF);
    bool QUuqpa(bool QgeGVXzlqeQk, string ZxJZjMifBIbGwZyR);
    double SpBKDkNUEUO(double EhdNMMwMbJmkf);
protected:
    bool RLoyoXbFTqjlRXp;
    bool aLyQGNqD;

    string oofuZonqRqLx(int YoXXWBsdyt, string mKaRNSQV);
    bool rtFAK(int KfaAZejkHtlJA, int aUrmYbbCjlzd, string UwbslNCdPFKfLuQ);
    bool mUXTZakmvDwenooI(double ONolANHxRN);
    void APpKdYFAlMR();
    int EITAnjfkXjb(bool brIHvNYmWMbKqbjP, bool tRjsv, bool eLncAA, double DuVquhwKeSrS, int eedAnpIEMuANgrJ);
    string aFZBqEVvdFEXIEI();
    string ONaabOC(int hMHwZV);
    int DovOYQY(int UlnyezpUi, int GOrXlEdXsOKD, bool gDeWRxSKCy, int WFHtWQI, int AuWlKCTrOAFYk);
private:
    int vvOhBQtE;
    string CqhtcrvFuvxibvbP;
    bool GKAJlETLoVebOR;

    string FwLxuGtQ(string kOyEWcjZxkgfzpOJ, double eGbDqvzhPlw);
    bool qyJrSpFNrrClGhea(string eiNEUe, string EyUcKighee);
    double FMzaiSM();
    int brPcKOg(int VkkJKC, bool vYPFinA, int puANqYatxuAib);
    string VeXJevurPNRUw(int tjBpDM, int tKwyXHApJXg, double KLJFHUclhbORFkR, string zuedUOZTJGiHNi, bool yzWIeIeeFmkQGf);
    bool smWVEGtOMLqwcrX(string UEeII);
    int xHuptBwaVI(bool gnRYK, string OoAbfmwdas, string OPHctULuO, bool TNseaJSsa);
};

bool zgCpiXtI::UgOigFrTdqoPSLE(bool thGnuwddZhgP, string IcFDiGMIK)
{
    bool VEwwGmkXquereOUf = false;
    double bNCCqIPuTHZfxltQ = 687102.7061767456;
    bool qwzctVtMJJRUAY = true;
    int QGrSvQMQKV = -339944744;
    double EECjdhgwZCDtYJKa = -151113.7140106104;
    int yFlpoCKMgA = -1490432646;
    bool zLhAXj = true;
    int fZytaHvTIPGIT = 1611978279;
    double VtZmwnGWFfxubhSf = 165618.3354052591;
    double YUpLmeEgsL = 515467.6745679134;

    for (int XBwNTimMA = 337264051; XBwNTimMA > 0; XBwNTimMA--) {
        QGrSvQMQKV = fZytaHvTIPGIT;
        VtZmwnGWFfxubhSf = bNCCqIPuTHZfxltQ;
        qwzctVtMJJRUAY = ! thGnuwddZhgP;
    }

    for (int QCZrcN = 304044859; QCZrcN > 0; QCZrcN--) {
        IcFDiGMIK += IcFDiGMIK;
    }

    for (int NDBlLHrqZAgGXJKa = 480792281; NDBlLHrqZAgGXJKa > 0; NDBlLHrqZAgGXJKa--) {
        QGrSvQMQKV /= fZytaHvTIPGIT;
        zLhAXj = ! zLhAXj;
        QGrSvQMQKV *= fZytaHvTIPGIT;
    }

    for (int gwZZBpTLH = 2094505795; gwZZBpTLH > 0; gwZZBpTLH--) {
        qwzctVtMJJRUAY = ! VEwwGmkXquereOUf;
    }

    return zLhAXj;
}

double zgCpiXtI::sUdZaR(int IaScmjYuYcWDIo, int SCJzxsJITcdAHr, string sHIObmZBk)
{
    bool kvKSkXQJzbVVKGdP = true;
    string PBSMbMCFpWKwvE = string("WPIAAgmCijHptimZRHofSoWstorAstQqOGIlivrsnwIYvlaTmbPGyDOtCWupoDojQROVFtsRabJwxjGSYwBZouVipppdRRqPELcwyWAbiZZwkyWYalzQgwRuyOxJNfjGFQSlmiwDjhDZMwVySFKEXzYRYrQLXWsFlgGnYGtqRYJytfdjsOTKpspzgmODrIDKUhHBPVFfgqgVFzKF");
    int CGjiJWUtIY = 360364381;
    double EvbsjdN = 135245.59812241694;
    int iXCapxaffQ = -637396702;
    bool ofdfLAastPTuJ = false;
    bool TOJypZph = true;

    for (int CvPayfQtov = 493261470; CvPayfQtov > 0; CvPayfQtov--) {
        CGjiJWUtIY /= CGjiJWUtIY;
        CGjiJWUtIY += IaScmjYuYcWDIo;
    }

    for (int MQNvnnP = 245220991; MQNvnnP > 0; MQNvnnP--) {
        IaScmjYuYcWDIo /= IaScmjYuYcWDIo;
        IaScmjYuYcWDIo += SCJzxsJITcdAHr;
    }

    return EvbsjdN;
}

double zgCpiXtI::uirxROBHCXJL(string zjdHOBxbgAYBRDO, double wbDsIJpkm, double cyWMfkYEFti, double KTVrQBYVr, bool wAzJIcXhaoVp)
{
    string vcSYUUgWUCCnsqLk = string("wXscWaaWMT");
    bool OjbCljUwaJzdtunF = true;
    int iGZPnL = -952542842;
    string UVyXrdSZSjKeOhjn = string("tjNaFbuyuowkXVjGIYxRunyRUlPaBFRhHJNwIvzRVPgbETeVDYXDGYSPlNFZFTzhfrfRSJQCJrNjXTFaTegcrzhhwRAqPJQCOCgCDuysnmVCXnQRwViKlRVJlbbSofIjFqEUmgXVohkhFYeVYidcsTcmxx");
    double xxTYWtokej = 572135.0533497258;
    bool ApgIWvIZVvMxsGT = false;
    int ceEcRwTyfehx = 1337132836;
    bool IRwjRVfAZfE = true;
    int bjVRvIFKBMnlXIlI = -1476377382;
    double XnJNRxsS = 622626.9520516827;

    for (int YRnBAvtKsnTmARF = 194924671; YRnBAvtKsnTmARF > 0; YRnBAvtKsnTmARF--) {
        wbDsIJpkm += wbDsIJpkm;
    }

    for (int xtHncZF = 804287735; xtHncZF > 0; xtHncZF--) {
        wbDsIJpkm += cyWMfkYEFti;
    }

    for (int IXJHJGoRNFOU = 1570927674; IXJHJGoRNFOU > 0; IXJHJGoRNFOU--) {
        XnJNRxsS /= XnJNRxsS;
        vcSYUUgWUCCnsqLk += UVyXrdSZSjKeOhjn;
    }

    if (iGZPnL <= -952542842) {
        for (int BkXsGcpLXrhilEcK = 2025283980; BkXsGcpLXrhilEcK > 0; BkXsGcpLXrhilEcK--) {
            xxTYWtokej = XnJNRxsS;
        }
    }

    return XnJNRxsS;
}

bool zgCpiXtI::cTBynkbbNImqfay()
{
    bool rOiCHBUD = false;
    double LuqpzwZELVrK = 742969.310793711;
    int HWmcvtQN = 1256339283;
    int KdUXFHrvYmCHJgQh = -1122429180;
    int AkCSsFXeRMnos = 2090265766;
    int SwLwiNrf = -1881310179;

    if (AkCSsFXeRMnos <= 2090265766) {
        for (int NkjBguGnm = 1138474979; NkjBguGnm > 0; NkjBguGnm--) {
            SwLwiNrf = AkCSsFXeRMnos;
            LuqpzwZELVrK *= LuqpzwZELVrK;
            rOiCHBUD = ! rOiCHBUD;
            AkCSsFXeRMnos /= HWmcvtQN;
        }
    }

    if (HWmcvtQN <= -1881310179) {
        for (int zPhtFRStEfiqt = 718616176; zPhtFRStEfiqt > 0; zPhtFRStEfiqt--) {
            KdUXFHrvYmCHJgQh *= HWmcvtQN;
            SwLwiNrf = KdUXFHrvYmCHJgQh;
            KdUXFHrvYmCHJgQh += KdUXFHrvYmCHJgQh;
            HWmcvtQN += AkCSsFXeRMnos;
            rOiCHBUD = rOiCHBUD;
        }
    }

    return rOiCHBUD;
}

string zgCpiXtI::YjaMHOJNtMTxto(int zsaJS, int PEOyAqeWo, string DTAqdDdEYpsruaP, int LfwrgtUKBMOPVwvH, bool cfTpHjzF)
{
    bool OuklNJQfKy = true;
    string PIdmbtAKqbOcwq = string("SYVBldxNoRSZKGuhqFSHWVHGETiCZMagaHIKsneeKEdiShfNBpsDFxBbjHibKIIlFEnSMmLyClOsWtRIzqEjlgzNieIZGbBosfbzBUZMBsLKmnyyjXjtKEkOamGZcbleFRNojUsfoXWcqPkvVltmmXKfpBBRSqKSLSgkcRxRnqaJOUsXoiVvmvQzjmSCKLHOhWCTVqvqXBztJmpNQitiGgRarepqndawcnvFeimZEyUQoKUDEpUrPQYHajrSio");
    string mPMIYevvFdgogFV = string("rvrFwPrNrfxDcuhTVNaEhSJXHdrvMsCoXJgOpjdShlAwPABTjFgPTuTZvyCAVYlXaqdNYiNfggAnJBJtvvWVIRtSRsafjPbKgofCdxLfyUvyMIAU");

    return mPMIYevvFdgogFV;
}

bool zgCpiXtI::QUuqpa(bool QgeGVXzlqeQk, string ZxJZjMifBIbGwZyR)
{
    int Jhiqs = -419840098;
    int NimbXllETcTkxubI = -1345861340;
    int QWTwiDekKeZFucg = -1810475335;
    int VJcLrXkfEp = -1238720081;
    double stigDP = -700635.8613730703;
    bool VUkui = false;
    bool RIvhUDKMNd = true;
    bool MFGZK = false;
    double POxbciMAFWYLSD = -113910.77759373248;

    for (int LnujLpieN = 989942265; LnujLpieN > 0; LnujLpieN--) {
        ZxJZjMifBIbGwZyR = ZxJZjMifBIbGwZyR;
    }

    return MFGZK;
}

double zgCpiXtI::SpBKDkNUEUO(double EhdNMMwMbJmkf)
{
    int PhJbrO = 713932529;
    bool kKSYjB = true;
    double OXALcDBn = 506783.2654026926;
    int uecZfKTecKmuzLLS = -834904216;
    double IpriQTtz = -1005262.0588488451;
    bool qGEMNOAtjthfx = true;
    string WbGRZToL = string("DOxtqIBVtjxpuvebRiOReERbPahMJOIAKDELpoaYRbEubPyNOVwlbxDUEisBHiyuxNBmblDStBLWOJHs");
    double SqYJRHLcxas = -241909.36868502;
    double rCZjYvaIUTLIoHcR = -444066.8848589875;

    return rCZjYvaIUTLIoHcR;
}

string zgCpiXtI::oofuZonqRqLx(int YoXXWBsdyt, string mKaRNSQV)
{
    double OgiJzqEIwkpW = 312656.6003477257;
    int NgdDrilLoEymL = 1983079413;
    double OhCRsYwso = 931198.0361046275;
    bool tVscPFd = true;
    int XEmssJcdppYRVc = 2055281922;
    string xwlBPkapFTC = string("YUcOzWoXLEHFuctxbAyGbvJOKhLlUwZqr");

    return xwlBPkapFTC;
}

bool zgCpiXtI::rtFAK(int KfaAZejkHtlJA, int aUrmYbbCjlzd, string UwbslNCdPFKfLuQ)
{
    string ohJFRqtMbroYAQ = string("vioyypaHXILPlWRJWtiWBZcUIydZtsIOApnWgsbswUEcWjcpQRVNLOYkSTFfiaXIuBXQlgqNDcHwJNBZpZMovKTwSFokDXogDRgKQEPDYBiccWxROorkVTBsfrxVGtUnDEyvyYVqdblcVUTTLGgRqjMSWognRAYzHCFZapZsFWOeCrdjqjTiMIgXcCWjHxpvxxMULgxzRnUDrqhMhMY");
    double DVJwgjrgRkr = -218098.1385065197;

    if (aUrmYbbCjlzd < 854315028) {
        for (int oWmSYlGD = 1190481719; oWmSYlGD > 0; oWmSYlGD--) {
            ohJFRqtMbroYAQ = ohJFRqtMbroYAQ;
            UwbslNCdPFKfLuQ += UwbslNCdPFKfLuQ;
            ohJFRqtMbroYAQ = UwbslNCdPFKfLuQ;
            UwbslNCdPFKfLuQ = ohJFRqtMbroYAQ;
        }
    }

    if (UwbslNCdPFKfLuQ <= string("vioyypaHXILPlWRJWtiWBZcUIydZtsIOApnWgsbswUEcWjcpQRVNLOYkSTFfiaXIuBXQlgqNDcHwJNBZpZMovKTwSFokDXogDRgKQEPDYBiccWxROorkVTBsfrxVGtUnDEyvyYVqdblcVUTTLGgRqjMSWognRAYzHCFZapZsFWOeCrdjqjTiMIgXcCWjHxpvxxMULgxzRnUDrqhMhMY")) {
        for (int LDqFfyCSO = 1563463917; LDqFfyCSO > 0; LDqFfyCSO--) {
            aUrmYbbCjlzd *= KfaAZejkHtlJA;
            ohJFRqtMbroYAQ += ohJFRqtMbroYAQ;
            KfaAZejkHtlJA -= aUrmYbbCjlzd;
            ohJFRqtMbroYAQ = UwbslNCdPFKfLuQ;
        }
    }

    for (int HPAtvHm = 432121972; HPAtvHm > 0; HPAtvHm--) {
        UwbslNCdPFKfLuQ = UwbslNCdPFKfLuQ;
    }

    return false;
}

bool zgCpiXtI::mUXTZakmvDwenooI(double ONolANHxRN)
{
    string NjXpVXlbEf = string("bhGbbAscOucRsVQjHABwmJncosMpfZemwmChDTiwspOSHBLJnVlm");
    string gvyrGvLVqOPP = string("EjkNnMjlrKXDJsOBECNeGqqGEtOUNwbeDYqppBkDYpzSHixvqaahhIHellOBZHNhfyFYaJwQpKvffMTNbiXmknexFZIBZmbwmBRdj");
    double cBHJb = -22153.808243365245;
    double PnaGuJxZWPjjUpJ = -228882.607048872;
    bool VnKCxo = false;
    string jISycAJPkcyyv = string("GWqyaEkakDwhZlwhipSPzaCLjBKRBjzRFyyffmNSNcjhtoZZAkwkHJYekbrJcNWKxekRWESNXzmaGiOYMoHlCfNGjLRBdyHetGSsqYWrhTfmALCZyFIyuTWFvbLvCVtgfNFYhukvmSzSOTxUxxUNZzbeRKhsAbXaUMwylMvzGMieDNSwswMFQxbwDcrAMdXFTBcrQxAtzqCyTVpmPlbtwDzjCzmxgeeMskNGrbFSKKxSDVecrOGrkhny");
    double AzVMzMpP = -835990.2720185427;
    bool lCeFKPtVScN = true;

    for (int wFgwWT = 1138632118; wFgwWT > 0; wFgwWT--) {
        ONolANHxRN += cBHJb;
        gvyrGvLVqOPP = gvyrGvLVqOPP;
    }

    if (cBHJb <= -228882.607048872) {
        for (int CPUSAZFHZbQ = 131876841; CPUSAZFHZbQ > 0; CPUSAZFHZbQ--) {
            ONolANHxRN += cBHJb;
            cBHJb *= AzVMzMpP;
            AzVMzMpP = ONolANHxRN;
        }
    }

    for (int PCXpYi = 1599900438; PCXpYi > 0; PCXpYi--) {
        NjXpVXlbEf = NjXpVXlbEf;
        ONolANHxRN -= AzVMzMpP;
    }

    return lCeFKPtVScN;
}

void zgCpiXtI::APpKdYFAlMR()
{
    bool vngSWBU = true;
    double KznRGgMobSmvhcG = 374792.92266184336;
    int alxcBSxFRNyBJ = -343228330;

    if (KznRGgMobSmvhcG != 374792.92266184336) {
        for (int RIpBImLEOO = 1736442308; RIpBImLEOO > 0; RIpBImLEOO--) {
            continue;
        }
    }

    for (int JSnIbdoL = 595282103; JSnIbdoL > 0; JSnIbdoL--) {
        alxcBSxFRNyBJ *= alxcBSxFRNyBJ;
        alxcBSxFRNyBJ *= alxcBSxFRNyBJ;
    }

    for (int kYCJNqwugoi = 1215217098; kYCJNqwugoi > 0; kYCJNqwugoi--) {
        alxcBSxFRNyBJ = alxcBSxFRNyBJ;
    }

    if (KznRGgMobSmvhcG != 374792.92266184336) {
        for (int MtinVHzcmHf = 361737227; MtinVHzcmHf > 0; MtinVHzcmHf--) {
            vngSWBU = vngSWBU;
        }
    }
}

int zgCpiXtI::EITAnjfkXjb(bool brIHvNYmWMbKqbjP, bool tRjsv, bool eLncAA, double DuVquhwKeSrS, int eedAnpIEMuANgrJ)
{
    string JIUajBjYYQB = string("vIXioMQyUScBMWXTULmMKSclMgnjSwpVDwVWpSAtezmgsVoNLTcagrmjVgShwaDRJdhjbHdnksTtKpobvXlSwGgcHtypnwDOVXqbhpdmRLoJxVaDRodwEnRAEoMauJGvkabtHbnmtvIHwtsseiBcfPnGHGUhPdkVwCuZgouHiJpjSGSkHjgaIKVCNqulnBxgdEaynuPxXhPPCcYSBLlJUEyEazJwROzmnjcbMvRnWzTkimoKhGgnUKDHhOSWUED");
    double HJukrf = 684748.3376385423;

    for (int SQqcVoRZV = 69533193; SQqcVoRZV > 0; SQqcVoRZV--) {
        tRjsv = tRjsv;
        eedAnpIEMuANgrJ += eedAnpIEMuANgrJ;
    }

    for (int uVCoBbJg = 767009505; uVCoBbJg > 0; uVCoBbJg--) {
        DuVquhwKeSrS -= HJukrf;
    }

    return eedAnpIEMuANgrJ;
}

string zgCpiXtI::aFZBqEVvdFEXIEI()
{
    double BdoHNrFvdB = 572734.4197501874;
    string sQzWSKsYNpBAJNZt = string("jqMDrmTsyHkgQgAeEPKZiKyiBywGMFjkKNjmveRTqmHfioqfzSByevSabETrnluuxcqgOQKqEJXBaekBjMvdnIhCKqmRtAJXjPXuENwqEuIAIzUasgMwSbtQwgtugXFMHcucbdtMlVZpIlxZdgelPdFJUHlQNRaWEcKpRaKFjwTmzSvVmPBHsRf");

    if (BdoHNrFvdB < 572734.4197501874) {
        for (int dsyeToGXEzOHW = 7433722; dsyeToGXEzOHW > 0; dsyeToGXEzOHW--) {
            sQzWSKsYNpBAJNZt = sQzWSKsYNpBAJNZt;
        }
    }

    for (int MolOZwUxNJOFNeR = 472548813; MolOZwUxNJOFNeR > 0; MolOZwUxNJOFNeR--) {
        sQzWSKsYNpBAJNZt = sQzWSKsYNpBAJNZt;
        BdoHNrFvdB += BdoHNrFvdB;
        BdoHNrFvdB /= BdoHNrFvdB;
    }

    for (int KnITECukofjQyIl = 375867414; KnITECukofjQyIl > 0; KnITECukofjQyIl--) {
        sQzWSKsYNpBAJNZt = sQzWSKsYNpBAJNZt;
        BdoHNrFvdB *= BdoHNrFvdB;
    }

    return sQzWSKsYNpBAJNZt;
}

string zgCpiXtI::ONaabOC(int hMHwZV)
{
    double VefEcWYnvS = -846039.8540467726;
    bool xPmQmxEDFe = true;
    int IOjpGEBHTMWSA = 1886047891;
    bool ZLRJmeCQPCuFf = false;
    double zYudldl = -71653.54203472019;
    bool SXOJXaTfdtp = false;
    string iClxkhLNjnXCst = string("tKkKzPpcPGQrrUSoOuQnCiIjeamkIyrmQEtpHGIILmgZplmAcMXqgtTnCNiLjodSPIwihkhGQFByKCvwmYRLJWaWhLslvUuFZnLWrJdnZTeJYUzWysdjMmgkjcVEVaUEGsMwMZMsIIjzzpJpQdTuRwQhQMSuKRRtxMTFmQUY");
    bool TsByfrDkFZ = true;

    for (int bsMbPB = 841229639; bsMbPB > 0; bsMbPB--) {
        iClxkhLNjnXCst = iClxkhLNjnXCst;
    }

    for (int cDSCpoSixLMbl = 275990547; cDSCpoSixLMbl > 0; cDSCpoSixLMbl--) {
        TsByfrDkFZ = ! xPmQmxEDFe;
        TsByfrDkFZ = TsByfrDkFZ;
        ZLRJmeCQPCuFf = ! xPmQmxEDFe;
        zYudldl = zYudldl;
    }

    return iClxkhLNjnXCst;
}

int zgCpiXtI::DovOYQY(int UlnyezpUi, int GOrXlEdXsOKD, bool gDeWRxSKCy, int WFHtWQI, int AuWlKCTrOAFYk)
{
    double XWIHmuVUgcEBASx = -906518.1607454788;
    int LlLjmPa = -1266542392;
    double GKMdlaT = -904252.0544502285;
    int VIwkZiqFiEtWpAtJ = 1155669770;
    double hFlmncQLReKDs = 196124.08096359627;

    if (WFHtWQI != -1041774237) {
        for (int QOXPXOk = 1910626739; QOXPXOk > 0; QOXPXOk--) {
            continue;
        }
    }

    for (int JkMXmnOwp = 892902355; JkMXmnOwp > 0; JkMXmnOwp--) {
        XWIHmuVUgcEBASx *= GKMdlaT;
        WFHtWQI -= LlLjmPa;
        hFlmncQLReKDs -= GKMdlaT;
    }

    for (int NopClFj = 1125726764; NopClFj > 0; NopClFj--) {
        UlnyezpUi /= LlLjmPa;
    }

    for (int wwOvrAUoHIz = 612943135; wwOvrAUoHIz > 0; wwOvrAUoHIz--) {
        WFHtWQI *= VIwkZiqFiEtWpAtJ;
    }

    return VIwkZiqFiEtWpAtJ;
}

string zgCpiXtI::FwLxuGtQ(string kOyEWcjZxkgfzpOJ, double eGbDqvzhPlw)
{
    string xBFntovYKn = string("ontackdmbIhqCCccZVZIOZwRnBPVziIqJoZRUEhkDettyVZjKFDuTgGncUWZZXObTnYlQvCrlFRHSzmACSDBQilfXljzheO");
    double vTVPb = 471315.6213452909;
    int XsGGOqDYksORcs = 239788328;
    bool eAuec = true;
    bool FVLnWOfgoN = false;
    int AbtmXriZWZ = -887738777;
    bool FXoIeAzTXQpqGpbn = true;
    string lRAKkHvpL = string("OfvVErinILOqcMRHAJJXZyOdhaPeHrXGpiNBbncaVRCLNMNKpuXAaNBhnHzFbZyHKhWdSohZTVuxGMcugFbazpWOtNuTNbhrDsyLHFRlMMubnDUsQmmgApLfZxjLhRaJUKSerEsZEYvTcSmbCtWEYH");
    bool zZOhlfNmPlS = false;

    for (int UgkQjOVjpmefKnz = 327621778; UgkQjOVjpmefKnz > 0; UgkQjOVjpmefKnz--) {
        vTVPb = vTVPb;
        xBFntovYKn += kOyEWcjZxkgfzpOJ;
    }

    return lRAKkHvpL;
}

bool zgCpiXtI::qyJrSpFNrrClGhea(string eiNEUe, string EyUcKighee)
{
    bool zhkIWTSY = true;
    int zzgsb = -1012662564;
    bool kCGeIWOf = true;
    double sCLcq = 390611.98183367896;
    int IoxPJQPLuA = -1554757413;
    string sKBQjhnxleguKY = string("VcqBzaNXsTEZJtleSWScfmEyzYTYasTioAzNgyphFBRbbqIaxNpWYkaUEJOlYDzmRSmdgrwNssAEhPqioTHczNarGAmbizJTiypbQaDaTpg");
    int aQCZF = 922773509;
    bool MHfoCRzWCSiATY = false;
    double kjIHMNIUtvB = -586542.9385290216;
    int LqJIaC = 1751920180;

    for (int BTvBcYku = 1695404628; BTvBcYku > 0; BTvBcYku--) {
        kjIHMNIUtvB += kjIHMNIUtvB;
        kjIHMNIUtvB = kjIHMNIUtvB;
    }

    if (EyUcKighee <= string("NpqPtJcAdmYmBcNSuRwlgPbAkTpjTBTpxJBHsOnBFWPCHYbozFQtKqTLkLdNDFFvANhcHKylxKIcBlsxOOtVhyQtASBBXjhpOYAfMedHSschVBcTwVpdQEEskdmTrzsnekXAcWxsLbKVbJxIniYtSBLjt")) {
        for (int POrHkBhS = 11366970; POrHkBhS > 0; POrHkBhS--) {
            IoxPJQPLuA -= LqJIaC;
            zhkIWTSY = zhkIWTSY;
        }
    }

    if (eiNEUe < string("VcqBzaNXsTEZJtleSWScfmEyzYTYasTioAzNgyphFBRbbqIaxNpWYkaUEJOlYDzmRSmdgrwNssAEhPqioTHczNarGAmbizJTiypbQaDaTpg")) {
        for (int PwalpToqi = 980952211; PwalpToqi > 0; PwalpToqi--) {
            sCLcq += kjIHMNIUtvB;
            sCLcq += sCLcq;
            sCLcq -= sCLcq;
        }
    }

    for (int PvkDVXoVmHAA = 1474241565; PvkDVXoVmHAA > 0; PvkDVXoVmHAA--) {
        aQCZF -= aQCZF;
        zhkIWTSY = MHfoCRzWCSiATY;
        IoxPJQPLuA -= aQCZF;
    }

    for (int HKiVWsKcI = 1264997343; HKiVWsKcI > 0; HKiVWsKcI--) {
        continue;
    }

    return MHfoCRzWCSiATY;
}

double zgCpiXtI::FMzaiSM()
{
    double MsxMuIFJtrd = -1041091.3766813916;
    double hlYzRD = 348236.4118621723;

    return hlYzRD;
}

int zgCpiXtI::brPcKOg(int VkkJKC, bool vYPFinA, int puANqYatxuAib)
{
    bool mNfumHw = false;
    double lPdTeXHSQkBVb = -807998.1875872203;
    double tkUFSJ = 74960.21451200702;
    string UZKfcKlWTggtZcmb = string("JZnXgdfggAQsTKklGPnoGadYunriljnEeiQFiuPmHhZBuowhCIeTMOdwOYWtcRDdayJaNPnfjTrVdjeTWdRCefMBzDrCHhlUyFlCxHjnKMOaXmbxmKsMvlmynwoXrPqwCeTzViMmQfYGydImfabtIJTCfdTYzsqMFjntbsLzEBMwYcOnYPhJOLYB");

    for (int jylQTaigy = 857484718; jylQTaigy > 0; jylQTaigy--) {
        tkUFSJ += tkUFSJ;
    }

    for (int UtUtMRlEaRA = 1473256938; UtUtMRlEaRA > 0; UtUtMRlEaRA--) {
        puANqYatxuAib += VkkJKC;
        tkUFSJ = lPdTeXHSQkBVb;
        puANqYatxuAib = puANqYatxuAib;
    }

    for (int pMnCadailRgtDE = 90743981; pMnCadailRgtDE > 0; pMnCadailRgtDE--) {
        lPdTeXHSQkBVb += lPdTeXHSQkBVb;
        UZKfcKlWTggtZcmb += UZKfcKlWTggtZcmb;
    }

    for (int EvLEKYzeeIVqU = 2136160428; EvLEKYzeeIVqU > 0; EvLEKYzeeIVqU--) {
        puANqYatxuAib = puANqYatxuAib;
        tkUFSJ *= lPdTeXHSQkBVb;
        lPdTeXHSQkBVb = lPdTeXHSQkBVb;
    }

    return puANqYatxuAib;
}

string zgCpiXtI::VeXJevurPNRUw(int tjBpDM, int tKwyXHApJXg, double KLJFHUclhbORFkR, string zuedUOZTJGiHNi, bool yzWIeIeeFmkQGf)
{
    bool znOfpZmV = false;
    bool VivhdoVfjlzzW = true;
    string laRZFUpN = string("dUBhRYKVThmlCeBPhhzySDGXVKOyxxbkikPCQDYXnezHjOqFWprCyPNLixBdpGGgXLrMZJZTixpLHEUvAJXZBBPVJXgqADDxzhCDsnxVWEWOZJYZADPIZffwfPjuETiAHfA");
    string EAOip = string("bUJLmpUheivqVLhFpJsBojzaZFbFPAlzhubgDWAEBAwXqCipOFmRacIeraqVpMrkowxVMpWlVRspywZVxcITRSSduUlDRBjDDpEgfqadHoALUKuPc");
    bool WZNEKmnRAt = true;

    for (int fehhNkjYvGK = 1561210301; fehhNkjYvGK > 0; fehhNkjYvGK--) {
        continue;
    }

    for (int xaICxzGIcdZsTXA = 638765718; xaICxzGIcdZsTXA > 0; xaICxzGIcdZsTXA--) {
        continue;
    }

    return EAOip;
}

bool zgCpiXtI::smWVEGtOMLqwcrX(string UEeII)
{
    bool tmUGEVXwP = false;
    string FqHjJeMPiSZU = string("bZmzfQxIrTJNkSuKOgqgEkdwUuUsaFtdgCmHkDvdiOEfcTGSMODqYtyBUBhoFtUDQ");
    string cxkxBU = string("ANGvkaTVcmcFcnCNSUPScjpQBcxjvyIqMSNVfdUHYuRjIIsGkBORgQFFCLEkhYtGGO");
    bool EUSVlLFpjprK = true;
    double KSbRjrkxYqZZtw = -644346.9624984252;
    string ZzYoLcOTG = string("PHxAdJzOvZezfGwEqLBvINNCcKDcILRwyZRJOCmfZlzHlkccKkBXjwHPOMvfShSesUIglvgbdlQRyrQoneJdBUshftsAoaiunIXrzWTIwCNeFAvtvzaHTEyjkNuYDsNAoOmcdUpgFny");
    string UpyfMGx = string("uYMmPBTtfRgjgyKJKzJPHMKiZkbSteiBivTUhorNIfgHqaiuMgTNdJNoSjZerhBITpmdTGHeFoCIFrFRBmDtcQYUAzPgjLbgmgAeOhsIjyesoYIPOxgnIRoFPgfOgzNKVJFQvsyxyClMWrwtcmtBMvCvFMvaFMEkjBjybHBbhfnofbUmGOctKWZmodbhbpLnQDQlkmrbsRKfVVGnMHfuGuLYPddFWhBxQUXepCkcCEHBBB");
    double BEHhmPMH = 462869.6261835044;
    double tGWTX = -888513.4168379264;
    string ySNGMSYiffKB = string("GXVyLfbdrtOuvjmBzamtkWdwVRhxnOptbnWWpmXRFIUrNYGoStJEdqVkNFUPXwGVHVPRgSTyjPzghgDLObCwQHFUThCwBZYNWYUpjIsqBdGCU");

    if (tGWTX != 462869.6261835044) {
        for (int qEumvJecetMfJ = 1254692053; qEumvJecetMfJ > 0; qEumvJecetMfJ--) {
            cxkxBU += ySNGMSYiffKB;
        }
    }

    if (UpyfMGx == string("oVRUSbHfSAQPdxmWLXEtOxwOoeVa")) {
        for (int yHsVTWxi = 263972800; yHsVTWxi > 0; yHsVTWxi--) {
            ySNGMSYiffKB += FqHjJeMPiSZU;
        }
    }

    return EUSVlLFpjprK;
}

int zgCpiXtI::xHuptBwaVI(bool gnRYK, string OoAbfmwdas, string OPHctULuO, bool TNseaJSsa)
{
    double GkdPowprNrjkt = 77794.4279942239;
    string CmCnNWLFNgFrAi = string("NUYkZbgDOyWiRXHQgXtHxonQsRDwsNrFNVboGJazHBDctrJzwxuUGeNTOBKuzmsQOPnMMbwnhPTeHTljLlfGalMzapenBfGRvgyjmnhqrvJdpypdTJlyQoRQVNcrmBfPkvXEBhWLLZeyjMMCRnrbyqBzTZzoDBDGvAYKzuAAoqUgYOtwMxCPKtoNkWDeDNXdpAcFVaKhogXFynzIGi");
    double UkHAPa = -875748.6556581663;
    string NhhkhEyodXAPB = string("dfZCTHrBvOaKrNwBtCPloadycOayXOfBSwDRbNrOUmmRbKeBpkRwWjeyYVCoDqkuGXbLSKUJYYofLjhtpjgEfgkqPdwB");
    bool cUWYtxlPQxPnCLo = true;
    string cOgHiTO = string("rkJzhnBbZqWibxqijRzNroHcmzSEsrSZlFGeJietMEviCkLWiiLAZhEciZgdQ");
    bool sajbqauk = false;

    for (int UIKmxCWEuoxmzB = 267712426; UIKmxCWEuoxmzB > 0; UIKmxCWEuoxmzB--) {
        continue;
    }

    for (int saOuApuXO = 1268858656; saOuApuXO > 0; saOuApuXO--) {
        TNseaJSsa = ! sajbqauk;
        cUWYtxlPQxPnCLo = sajbqauk;
        cUWYtxlPQxPnCLo = ! cUWYtxlPQxPnCLo;
        OoAbfmwdas += OPHctULuO;
        NhhkhEyodXAPB = cOgHiTO;
    }

    return -327511448;
}

zgCpiXtI::zgCpiXtI()
{
    this->UgOigFrTdqoPSLE(false, string("DzEXqdVABBTCRexEizNQKDfVdpdeBNquzKKUgLbsfPKWKRLarqoeAeMEgYiVkZeuvOwRAvFkoAXRcDTqOLzj"));
    this->sUdZaR(-189179945, 1119286390, string("EaOwXFplBRjTSmwefepViUKTzmdEbHrgiSmXmJoNgrMndezkLnbBPVfByfBvNQFPFsEnDGwuyznlPNWrbdNiwKNKjEQbMFGOyGgqpREUwCnHZKDBHpDWjvXSCjinlHvtATFXqGBjFWmvOsWezFObrfavJwZKCoAUwjAxKysvXeWjTgZHhiHMoqAAtDsiGRPOWminTHNQbsKKRBCjrcfsiAryUbfsV"));
    this->uirxROBHCXJL(string("igvTiZfEqoRiSQUgIgJLIUeYVaUYmLhaxMkYnveRYmLpRgxSSLnfPlKFKUNpsyFNGYgFcxKKGso"), -296071.1028109173, -814689.2470195519, -160095.78133806636, true);
    this->cTBynkbbNImqfay();
    this->YjaMHOJNtMTxto(574507988, 1546921938, string("JJNHiAuZFBXJInyHSTTbFEEVvGQcmCtrWBEHLtSTzZzzKUnStGHGalNpNBADXosGYvdkABZZijKTRZXmsUShsvVMDYkSthbwBwIOyRYvjdhpj"), 1037807085, false);
    this->QUuqpa(true, string("qsBVEqyTNSWgfvIZoXFzCzxCagmfkPmiklJkMhvcQUYVNriNZUebmOFiIiAXLXUWNTHajChlFiggcqquTPwEsVgoPstKqwNMTjPOWPxohCyfZkreavpiqieNeTWtzfXdnHVYxSKOTasUcMdEbyCyCfXBCQmvfwnNZxatYMPQlZjKZWmuoUYwlaqCBpwIpicPpAiTAKKQQVGacFwOxn"));
    this->SpBKDkNUEUO(823016.7156763849);
    this->oofuZonqRqLx(-296432259, string("ouayHIZULofmUAxSrBEhLOqoxaQblAMqrrnvIpkeLdfCkoyWybOM"));
    this->rtFAK(-702758349, 854315028, string("DFskwtBgVcDsaZNTBpChorukhyROfEKjtcNDdfQgSvlbQaJcWlvUVfkBjJxtdPhuvsXJhmOGRxuLIrwaXEJHCICxiDGLgvFBSwllGyahqFDOovWyXMNyVOG"));
    this->mUXTZakmvDwenooI(-936769.7684089519);
    this->APpKdYFAlMR();
    this->EITAnjfkXjb(true, true, false, 172081.5059533127, -982459712);
    this->aFZBqEVvdFEXIEI();
    this->ONaabOC(-21780153);
    this->DovOYQY(-1041774237, 1437446688, true, 920204935, -1328734958);
    this->FwLxuGtQ(string("HVgcnrxBGhwQdQVqZMWAbaTyumejSeyjvKWTIAyZfrZVbhNswtYcLYqpGQQnDQnxBMOGllNiKRkjvUxOvjnFVGAmSQnqnecMhMkNdIGikROkSBpKkhFzhLvpKkFJTkSvjyXBJSERSchBFXf"), 139287.78396847672);
    this->qyJrSpFNrrClGhea(string("uOIntzsdHlhNTnqbKWFxIFyDfhDqicizZNftOVMOepqWoXPueKyOyVoeUJBWkmVOONQPzlIFmenfRejLGCoKLojFWXctaNgsMgJETGIMLkrCDbkAEwzUhgQVgWjeeXzhuCuhHyspvmqGCwzdMHsHBLLkSzUDDTTnVoDclZVrUnTgVMkTLMAlDeGCuSIwahtuhhXTLHKqnDzXtHrCUgJhfgkcPRiusFnpxZizvmYXYO"), string("NpqPtJcAdmYmBcNSuRwlgPbAkTpjTBTpxJBHsOnBFWPCHYbozFQtKqTLkLdNDFFvANhcHKylxKIcBlsxOOtVhyQtASBBXjhpOYAfMedHSschVBcTwVpdQEEskdmTrzsnekXAcWxsLbKVbJxIniYtSBLjt"));
    this->FMzaiSM();
    this->brPcKOg(868359616, false, -1912140086);
    this->VeXJevurPNRUw(-549160220, 1027634101, -398139.5829545314, string("gwNDkAYNaWDjoraEiptntVpFwcjPpilxjKwNiELdyDRzTfXqWRJBeQWjpWWNkyUXzNfEJhDzDDTVXrtTaZLElGwMZRAHFRbgtNAHrqVUQPCS"), true);
    this->smWVEGtOMLqwcrX(string("oVRUSbHfSAQPdxmWLXEtOxwOoeVa"));
    this->xHuptBwaVI(false, string("ptWLCTMQPeaMfWSUifLqgXwTybjPlMVNrymKRnGfYArauzpAuEadePzTYMFmntMcrlbzQgawzkpjHKErDiOwePbBFohSJaoHpisfqxGkpWvURqrsIrPblAksoYQalvbNNexYKB"), string("C"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fVNGig
{
public:
    int vQSAbzuXFYsRtLm;
    bool lEdswAHPtKwJfQpX;
    int XKnjcskOzguOfZ;
    double OpEZbw;
    double fplLYyT;

    fVNGig();
    int zmZpppN();
    double FGlRrPGQdbf(double hToBqlcXbk, bool ardyxtFXATvtDcz, string FsbMbvinTHnjbIx);
    void woRfIOnj();
protected:
    int BgPbfUD;
    int CXXyoZ;
    double oWvZYe;
    int KOFACnwrNjPWxTP;
    double ZOKVrvqvzGW;

    double nLMKDQI(int NSDIi, int ltXWv);
    void MqvITSbj(bool LzWsFti, int lfjfGjUYqGz, bool tvVBxDRfAu, double jUCPaPQTgyNXzY, bool lVWLbg);
    void yeZGa(bool FZiNtKS, int WXVQNiqxQ);
    bool wQxQHfFdNYEHUhKi(int NQSEDsBJQfqfxK, int dNJsLm);
private:
    string MlKrqpJjyDNxmHO;
    string GjWwBuXzwfZM;
    string LKqywNTzNfnXQ;
    string UTZGEK;
    int oKJqTbFmeg;
    bool XSAngcCkaQrxCZq;

    int bcVHEzHZ(int DsbAdd, string eRXDFsPegM, bool iIIGU, double qNCIvWWSBfltdi);
    double JbAxHPdCdDvtc(double lVrLkH, int LdFeL, double CeOQxdTLCgf);
    void wAfqiO(bool mfjxOub, double xzYFbPnfVCDgNO, int hiKZWClKEUXXKXfn, bool NOKAMyIsMKVMOpAJ);
};

int fVNGig::zmZpppN()
{
    int uMNvnpsuuFCi = -2016571231;
    bool pQECySHUIqvsOVjl = false;

    for (int yZyaevy = 1618822735; yZyaevy > 0; yZyaevy--) {
        uMNvnpsuuFCi += uMNvnpsuuFCi;
    }

    if (uMNvnpsuuFCi != -2016571231) {
        for (int HEoiOqhqCnd = 1004317424; HEoiOqhqCnd > 0; HEoiOqhqCnd--) {
            pQECySHUIqvsOVjl = ! pQECySHUIqvsOVjl;
        }
    }

    if (uMNvnpsuuFCi >= -2016571231) {
        for (int IMTHEDkpsBMCxq = 983820044; IMTHEDkpsBMCxq > 0; IMTHEDkpsBMCxq--) {
            pQECySHUIqvsOVjl = pQECySHUIqvsOVjl;
            uMNvnpsuuFCi = uMNvnpsuuFCi;
            pQECySHUIqvsOVjl = ! pQECySHUIqvsOVjl;
            uMNvnpsuuFCi /= uMNvnpsuuFCi;
        }
    }

    for (int ZQsylso = 725930766; ZQsylso > 0; ZQsylso--) {
        continue;
    }

    for (int kfnoJh = 952101316; kfnoJh > 0; kfnoJh--) {
        pQECySHUIqvsOVjl = pQECySHUIqvsOVjl;
        pQECySHUIqvsOVjl = ! pQECySHUIqvsOVjl;
        pQECySHUIqvsOVjl = ! pQECySHUIqvsOVjl;
        pQECySHUIqvsOVjl = pQECySHUIqvsOVjl;
    }

    if (uMNvnpsuuFCi < -2016571231) {
        for (int uAxzqXZOcjlatf = 493644040; uAxzqXZOcjlatf > 0; uAxzqXZOcjlatf--) {
            continue;
        }
    }

    return uMNvnpsuuFCi;
}

double fVNGig::FGlRrPGQdbf(double hToBqlcXbk, bool ardyxtFXATvtDcz, string FsbMbvinTHnjbIx)
{
    int JFQAEWLgWszq = 1155586986;
    double wvXbNNAgK = 788919.0041242578;

    for (int evVuAEJfn = 1332451790; evVuAEJfn > 0; evVuAEJfn--) {
        wvXbNNAgK += wvXbNNAgK;
        hToBqlcXbk *= hToBqlcXbk;
        FsbMbvinTHnjbIx += FsbMbvinTHnjbIx;
    }

    for (int oqHGvegeE = 417581542; oqHGvegeE > 0; oqHGvegeE--) {
        FsbMbvinTHnjbIx = FsbMbvinTHnjbIx;
    }

    if (hToBqlcXbk > 1040541.3042208798) {
        for (int BexhYsLSgpyxAh = 91978551; BexhYsLSgpyxAh > 0; BexhYsLSgpyxAh--) {
            continue;
        }
    }

    return wvXbNNAgK;
}

void fVNGig::woRfIOnj()
{
    bool IUYNJwwpPEkTmm = false;
    string ylTcdFFKxEyakUol = string("gJxNeucAIJsuwTbnESxsXAdRBbHzIoMRAczDlEowJKzIcMVRUWyXfHLFjdGFUnoVhMFihDXVoTjMkZWeRKZbWJKfkLheKTCCvXVNpGkJslrfJakXnGZVeMRBYBVBLpAKiwQaZtzNXulUHMAQTHdaOjnBaPNmuyMdshsYtuJCcKmBONzscdrqfTJQvxNeFJRi");
    bool fOvnEmhzdm = true;
    string fgJTC = string("JNHzorQrUTYANtSQuUcu");
    int LUjuTUYoFCqAIh = 2016496390;
    int UIUejMvuZWyBcYPm = -801232339;
    int XMkfPZEGT = 1475353900;
    string CTnQC = string("uYKcpzTRUnpsFXFjqUzH");
    bool rLAQV = false;

    for (int rohdRaJZXAHWDw = 435467677; rohdRaJZXAHWDw > 0; rohdRaJZXAHWDw--) {
        continue;
    }
}

double fVNGig::nLMKDQI(int NSDIi, int ltXWv)
{
    bool bDHrm = false;
    bool WDBIbdltfpOncYt = true;
    string gaFvD = string("tPZDBHVVGQjADxnuYDnZliIdDJZaOzIlhbsiNlxsuCftwlMXODNeIelYNzbAFtdnjFupmREEPHXgaBwmrYRriWUoWtWYBRkoosfdTYkAaBEyFFredBWwhJxXBkKdMSLNocAgErGIVNQoCcdUFzwmXqduDQMMOYACtLhJaKwkLQdMCSMjSnzppSCRTjBxaXdsyUtGf");
    int sruRzKEEEv = 1704545220;
    int zxGwpzKYUUQdRU = -1972952459;
    bool FNAcXxuerVBRy = true;
    bool McFOeGvOKPto = true;
    double ZEKHIRGzAk = -981955.6043674577;
    int FBKhLeMoqwhQrnpL = -711856811;
    int ldCevdrC = -117154180;

    if (sruRzKEEEv == -1972952459) {
        for (int hvKCyneIJkEaDH = 125257093; hvKCyneIJkEaDH > 0; hvKCyneIJkEaDH--) {
            FBKhLeMoqwhQrnpL = ltXWv;
            McFOeGvOKPto = McFOeGvOKPto;
        }
    }

    if (ldCevdrC <= 770179798) {
        for (int cCKaesyMtH = 1688520478; cCKaesyMtH > 0; cCKaesyMtH--) {
            FNAcXxuerVBRy = ! bDHrm;
            McFOeGvOKPto = WDBIbdltfpOncYt;
        }
    }

    if (ldCevdrC != 770179798) {
        for (int ldRSs = 770361613; ldRSs > 0; ldRSs--) {
            FBKhLeMoqwhQrnpL *= NSDIi;
            sruRzKEEEv += zxGwpzKYUUQdRU;
            sruRzKEEEv *= ldCevdrC;
            FBKhLeMoqwhQrnpL += NSDIi;
        }
    }

    if (ZEKHIRGzAk == -981955.6043674577) {
        for (int CxYpdr = 1268883270; CxYpdr > 0; CxYpdr--) {
            WDBIbdltfpOncYt = ! McFOeGvOKPto;
        }
    }

    return ZEKHIRGzAk;
}

void fVNGig::MqvITSbj(bool LzWsFti, int lfjfGjUYqGz, bool tvVBxDRfAu, double jUCPaPQTgyNXzY, bool lVWLbg)
{
    bool irYDocRAxtjHGYMx = false;
    string inWZYDK = string("NCOawvvahAKeFvOzaVdmNDSMApHXqh");
    double WZzcYH = -294828.9016550064;
    double dvaGvd = -499283.5135872555;
    bool RCbxN = false;

    for (int jBbpM = 1079205270; jBbpM > 0; jBbpM--) {
        continue;
    }

    if (LzWsFti == false) {
        for (int KIoTkxBQg = 1974656810; KIoTkxBQg > 0; KIoTkxBQg--) {
            lVWLbg = ! lVWLbg;
            lVWLbg = irYDocRAxtjHGYMx;
            LzWsFti = ! tvVBxDRfAu;
            irYDocRAxtjHGYMx = irYDocRAxtjHGYMx;
            lVWLbg = lVWLbg;
        }
    }
}

void fVNGig::yeZGa(bool FZiNtKS, int WXVQNiqxQ)
{
    string xkOukJEZJzgOqSs = string("ZcPWhIYlQvOfuxudOdIrQCSOBYaTUxtYebhDJFPXjZmjqAPtqUIpzmgOFCSJKKHECBWKNAFoPtpQVfmIRpmZdlCBPTTLuXlneKlgLQQcWNgHcDdArvhMkQmgyIHUosgfEDBAdfDYwhtlpvlOBNPAbNISeFvbKkvpaZvSJeLVAShLTXfcrgDTFhQCeCoyXjierMSpZhlMOm");
    string SiPvt = string("NHEbXCZGfXwBVmDfHfaZtElFXGWIJrrOLFHpKblkiZyBZrpauefjsDmHyVoGbUSaYfnZswZfgYvBROJaOjEmGZJMQTOqATSekbvOpccUBhijvJOSCYelFNCkKCvRQmQhwthedxYVsXbBqySfxteoPfGwqoJWcdPgkGECqRWIVYQTEQEYnMrLICETkhFPtfMOPPGOZLPzuFJPsaxCsCiBwgRMTLXYvvAhqSgjflCfWvWpHIEBq");
    double GEymYSyxrVLo = -452769.36463953543;
    string LayadMJpuemcxSh = string("xACYxOjXyBGbEFyePRIycIqFCWgRaCJWDCPsjAaVqTFhUOHjlv");
    int tKkcxdWge = 928585551;
    bool EvrwxWnvIFxet = false;
    int SqhKAVTUHkU = 655076317;
    int nSvyjQWGOej = -110047973;
}

bool fVNGig::wQxQHfFdNYEHUhKi(int NQSEDsBJQfqfxK, int dNJsLm)
{
    int tCWVqLmNjD = -316917432;
    double rfjcJliPom = 565137.8047087081;
    double vDxdkGOtoTpZAzx = -977622.4920110134;
    int WMptb = 1478456964;
    double nvVtN = 56766.96503092879;
    int ULcbDBaTezaCbZ = -1702427064;
    string xjHgpyojpJ = string("gPAMLZTRSfQjjkBTnPQomeoeBZnovGwyTDRdAwmcTFlomkaWsWqNreVfyNrjOtYShDJeSZegqAMmMgvthYEfoDYuJebhKargvxuMadXlDbdvrCSburkPWDNrsCdXWIUSVolVifEYIFgYgBnPogadbEAhuHAyiqAxzdqAqXRiBueMWSCQj");
    double nBnBRxVQsijCtOkU = 960921.8547025388;
    int cDTvzmWIcmogW = 2013166493;
    int zKbKphyvkvwpiREi = -1523208463;

    if (cDTvzmWIcmogW != 1478456964) {
        for (int nLDMhIYIACPu = 244975113; nLDMhIYIACPu > 0; nLDMhIYIACPu--) {
            nvVtN -= rfjcJliPom;
            WMptb += WMptb;
            zKbKphyvkvwpiREi /= WMptb;
            zKbKphyvkvwpiREi = NQSEDsBJQfqfxK;
            zKbKphyvkvwpiREi = zKbKphyvkvwpiREi;
        }
    }

    for (int ehDJCetcvui = 1080665890; ehDJCetcvui > 0; ehDJCetcvui--) {
        nBnBRxVQsijCtOkU /= nvVtN;
    }

    if (NQSEDsBJQfqfxK <= -316917432) {
        for (int AsFdP = 700642161; AsFdP > 0; AsFdP--) {
            zKbKphyvkvwpiREi /= zKbKphyvkvwpiREi;
            ULcbDBaTezaCbZ += tCWVqLmNjD;
        }
    }

    for (int WQzPeckZSjo = 1208814854; WQzPeckZSjo > 0; WQzPeckZSjo--) {
        cDTvzmWIcmogW = ULcbDBaTezaCbZ;
        NQSEDsBJQfqfxK += WMptb;
        cDTvzmWIcmogW += tCWVqLmNjD;
    }

    if (dNJsLm >= 2013166493) {
        for (int ApqkuonqjWEbFWjm = 2111712225; ApqkuonqjWEbFWjm > 0; ApqkuonqjWEbFWjm--) {
            dNJsLm += dNJsLm;
            tCWVqLmNjD -= ULcbDBaTezaCbZ;
        }
    }

    return true;
}

int fVNGig::bcVHEzHZ(int DsbAdd, string eRXDFsPegM, bool iIIGU, double qNCIvWWSBfltdi)
{
    string SkdxviBrG = string("ZvFVfpjwEsjbVNdoqROyGooSeDzftROMnUadNKCqginSHAzywiRtSWadovWoFrvcfoJNTqyRIwQezkUDrKUSycCmDXGAjhJeVbdYqIjJRuJHivoDDVVIrtzOCQSZiiPwxxE");
    int KbMtG = -960132877;
    int TxMTWUmDFFHmC = 1129167063;

    if (iIIGU == true) {
        for (int KZculXatSkaEIDL = 1359873410; KZculXatSkaEIDL > 0; KZculXatSkaEIDL--) {
            qNCIvWWSBfltdi *= qNCIvWWSBfltdi;
            DsbAdd *= DsbAdd;
            KbMtG -= TxMTWUmDFFHmC;
            eRXDFsPegM = eRXDFsPegM;
        }
    }

    if (TxMTWUmDFFHmC != -960132877) {
        for (int PSKvASzYteiV = 706340596; PSKvASzYteiV > 0; PSKvASzYteiV--) {
            TxMTWUmDFFHmC *= DsbAdd;
            iIIGU = ! iIIGU;
        }
    }

    return TxMTWUmDFFHmC;
}

double fVNGig::JbAxHPdCdDvtc(double lVrLkH, int LdFeL, double CeOQxdTLCgf)
{
    int QeJGghryCqSU = -1808473774;
    string HIpfh = string("FejrgstifmmFtqPSUDxDhjWWZiaDQcWeEZEwOSzRXigwdktFoCztaOIuLtpfZyPIBaOgaVrYSCsVwZuNieHnsmarLlAiXrZAfqLCEUVPrblsPuyJNhFSVywQoWKHYLbzkVxKSAJGxaJaMYvoLRJzmFkeehRGytSXqLPDnWQrGXEdbOxljfLHMqZODeZOLZtQiNtQkoUHaEfPzlDbAbengHNGunSYsgkQIxEdVuKyNVtvD");
    double YwTuJXkTQqWNF = -301521.507033068;
    string elrwPWOsFHuh = string("mQrCtpgcYQeEBQMjGZYiJeMClkeAIyvEyVXEIAwvrSczTxYXyNIoVuRuLRxDSQVAJiiWtYVpHdCQWbfaKZoyTfTOPZVzhlTMGZSUluEHWUUEy");
    string ZSrGjT = string("vbxXCvAihtKPYTGUcEBVeeJfzRDmVCjFOtNgLPPRjUrluFgiTfDe");
    string vPBefKgxQS = string("JkeceTnAkmXYjUyPGAngSrqqjxfYzroGebBLgcJPVhMizHEXzeJGzUZbNEWMeMVZtHBbMDQPLYpkBJTWsdWWBLGreisqikeBxzhySjnNoWgXoKwrnJQlOMybDfNXZofZctnnry");
    int eVPnXMccTZEyyZhX = -395881194;
    string unSgVTOSgfMIiG = string("EezyQUZFORk");
    double iMfZdNrMdiq = -1006921.7501737751;

    return iMfZdNrMdiq;
}

void fVNGig::wAfqiO(bool mfjxOub, double xzYFbPnfVCDgNO, int hiKZWClKEUXXKXfn, bool NOKAMyIsMKVMOpAJ)
{
    string KiVrZKOHXS = string("TYytYTrlrxYGoglffYkmdCiHWmCqaXdudBZYPxXjJgwsWxHrIwjkbuYWxJFKEfRQRPfeDeXEzaBpbwBaqzqZYDdGfzolaoLtJ");
    bool fcEek = true;

    for (int injddhSDZc = 218433368; injddhSDZc > 0; injddhSDZc--) {
        fcEek = ! NOKAMyIsMKVMOpAJ;
    }
}

fVNGig::fVNGig()
{
    this->zmZpppN();
    this->FGlRrPGQdbf(1040541.3042208798, true, string("NlFKyEFLqxxRQEDOqnHGNnPasgNlDYuBLBeORJdKTlvMLYUMUuVverpMeLPxaTmpfbBftRqzarrzjSwwVFHKoBUUvnisbcOmxffgZlAYAagXVTByTqpsDYvGSpvAxjprOGEsObOKdHsYxjPL"));
    this->woRfIOnj();
    this->nLMKDQI(770179798, 1212888158);
    this->MqvITSbj(false, 367750550, false, -513858.43693299533, false);
    this->yeZGa(true, 827543666);
    this->wQxQHfFdNYEHUhKi(84904218, -253336132);
    this->bcVHEzHZ(1021895608, string("kqjPRazDpipcDarjCqzAAUPVZQhBKjdxwxyYBIqDxLNBpFDCmVWoCEYHZBHemGuNnnfGAVChfhKUcPOmdbGabSPhguLLInGOHuYCNXscaBQVtzpFQoAQLUFupgFTfmtUQfbrfOxwH"), true, -477263.79450552183);
    this->JbAxHPdCdDvtc(303125.0855321635, -508473544, 423503.0233378051);
    this->wAfqiO(false, 450491.29890070687, 1579693313, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XOWXwalFxvpnnU
{
public:
    bool HXaeDrendBGl;
    bool fQfCOQYflLzLutn;
    string AiimqQ;
    bool suDdokoHLeKek;

    XOWXwalFxvpnnU();
    string HaPYlxYCTuoZ(int mzQwIorpwkCZvMLb, bool TGHlLh, double PyPdELvkpv, double cfqZyyreHfBHAhHq);
    double SMmOGjo(double WDeKJvgXAPjLvp, double mFQvHLkrtGb, bool dCUJQKoYrQYqH, bool UsiMwgAxp, int KZKtublerzaacV);
    int JZQVeuEaGpKLxdGn();
    void kVmqZkEWlbeJ(string szFstEkIdILjAgj, bool lYCEFQiWTzIvovqt);
protected:
    int RsQpFon;

    void tfiux(string TBVEhVKx, bool Jblbngvlarm, string YFHntdrYTveDjp);
    string ZsMwj(int SVIPjXG, bool eteGYMXL, double gQufvrmFUOPL, bool XbfQqtfd, int gCEdJxqewE);
    int liMqPdNwA(bool dUQrjteTrHMelTFX, bool ClkeaOo);
    bool HHssGarWNxBrLaUt(string eAEiEmyCHyPxcuP, int pSujnlkuSDM);
    double YnoaHGiZLnnGm(string dTpPZfoebUwP, bool rbMETwYTyWqS, bool uLFHPpUf, bool PiQDoIVKuqZrU, double yqmmnX);
    int gYuXqWvfhvNqd(bool VgmtbPrL, string dzdTf, double ddGywubCH);
    string eVLrHFtjh(double jGJraaItpXLqFWZj, int MFYuKi);
    void vggocQXkerMgaAXf(string lwupWXmViy);
private:
    string zFYZMgCsALJaAtb;
    string bvMyMdebUhAk;
    int YHOdtI;
    double mpSHhA;
    bool VHEpZQreLyJLasYr;
    bool ZMtahTJ;

    void EVLOSFkJaqVvEcqA(string IOGdd, bool XdcVZsjFriYCSo, double PcQchyrlhV);
    void AEAeckPJlKmAsO(bool NgSSzsuwzuX);
    void tUdQAbkyukD(int RHZCmX, bool RlzfTPVt, double ofucJNnGno);
};

string XOWXwalFxvpnnU::HaPYlxYCTuoZ(int mzQwIorpwkCZvMLb, bool TGHlLh, double PyPdELvkpv, double cfqZyyreHfBHAhHq)
{
    double qJfZNdQgwyKnqwp = 637437.5454507245;
    double UAZDove = -306975.5100868475;
    bool mnEvSnOeXLkU = false;
    bool xvIvkMGEiUpDM = true;
    bool NGIYoninhE = false;
    double tyOtLp = 684180.4282666867;
    double zzdrsDiZQudrWCYx = 876116.6224587718;
    bool txlDovo = false;
    double QkoxJ = 171999.81224829826;
    bool qmdYgKpJonkNBx = false;

    for (int ouagvJGqV = 684068407; ouagvJGqV > 0; ouagvJGqV--) {
        NGIYoninhE = ! xvIvkMGEiUpDM;
        cfqZyyreHfBHAhHq = tyOtLp;
        zzdrsDiZQudrWCYx += cfqZyyreHfBHAhHq;
    }

    if (zzdrsDiZQudrWCYx >= 207190.1115210085) {
        for (int QsZeb = 557053371; QsZeb > 0; QsZeb--) {
            qJfZNdQgwyKnqwp = zzdrsDiZQudrWCYx;
            cfqZyyreHfBHAhHq *= cfqZyyreHfBHAhHq;
        }
    }

    if (UAZDove != 637437.5454507245) {
        for (int INciQiZXRSaXpAH = 2087525218; INciQiZXRSaXpAH > 0; INciQiZXRSaXpAH--) {
            continue;
        }
    }

    return string("LAQROUMuCjdNcbwlQfiCMQuNjBslmqygyzKrlhurswfPYzhtIXjRTwiSXgFAFZqqFRkcFnDJRuntAtYMbhIsWaGvGQCzJoTGoeUXmQvAHpebCTgIpXHQvtEzVAAUoQxNVrXeHIzLklmaSjkkBxoChJLEgonoMiFJJuUXBuireobdMhlUJEVHnXmOqVkTjLysveSEivreAWrUPPBCgbLwmWKBwcmIusn");
}

double XOWXwalFxvpnnU::SMmOGjo(double WDeKJvgXAPjLvp, double mFQvHLkrtGb, bool dCUJQKoYrQYqH, bool UsiMwgAxp, int KZKtublerzaacV)
{
    int IxKmNcrjjAfGmaYh = -61106192;
    double xzqhqhI = -975115.3483932618;
    double yfYRCGxkvDbBL = 641638.6459978666;
    double ytunxlNlxBqUFPS = 1029972.4162403097;
    bool oLpgUv = false;
    int OYhIgCozJqsxIgdC = -1742630218;
    string JSLWCm = string("HdCiRnXElyPablcDfPxxVjPJKEewwPzTISvsLWwuRatyHGNjiRiRDsnAQ");

    if (xzqhqhI != -644399.9922693757) {
        for (int wcycjjPz = 1819591124; wcycjjPz > 0; wcycjjPz--) {
            WDeKJvgXAPjLvp /= mFQvHLkrtGb;
        }
    }

    if (OYhIgCozJqsxIgdC > -61106192) {
        for (int tJLfeQP = 2068031165; tJLfeQP > 0; tJLfeQP--) {
            continue;
        }
    }

    for (int cjJqLlIoxVCDEXO = 147473889; cjJqLlIoxVCDEXO > 0; cjJqLlIoxVCDEXO--) {
        dCUJQKoYrQYqH = oLpgUv;
        JSLWCm = JSLWCm;
    }

    return ytunxlNlxBqUFPS;
}

int XOWXwalFxvpnnU::JZQVeuEaGpKLxdGn()
{
    int SMpXGKKdnWpDBh = -287135629;
    bool QYAAefqwLL = false;
    string JmaQno = string("RODlYOAsHg");
    string tEMAuAWffgZShoM = string("NdWdMvXfbYhvBnBKGcWfkHLQvoKAtaLStKwEGjatpcOoWfFqgnHiOcBPSeCiihvZ");

    return SMpXGKKdnWpDBh;
}

void XOWXwalFxvpnnU::kVmqZkEWlbeJ(string szFstEkIdILjAgj, bool lYCEFQiWTzIvovqt)
{
    bool ImKDCyB = true;
    string obUMisfMvgeTiJQs = string("EHarZkEpRuLznYQvIwJMuOEbZrEbgUsllKvWqJ");
    bool bwFEAGnF = false;
    int hqnGbZOlfoXR = 1637519856;
    string FTVfwnmSL = string("cFFEmipTpVdBrZZebizXGKyMNyyaXGXRpdodplSCvKlNEUyVTtDOqrjVWoZQfgvzlkRsXJGvXONIcpOeQQzKYFIwChecBpOPwskjDrW");
    int bfnOT = -1899796885;
    string feXnZHdNCdjzwE = string("LDSEqaUJqvoVhVtXloVNjaZaxttgKBBHEZnKLSLkmqblgahbzYWteyTVxXiGrZbMUJDSmyAoUvJvzEaqnQqOVeTOBKlhdVOoMOHKyycBNbStRhtKMUHYmmXHvhfTjdPTukmkaLhiCanwBfYCCiRFoKJtwkMNuauYekVZiNxPqpnpzsJCUsOcAjhHVjxQGrRhdYORozKhSqOTmZXTNdOtGtSptorRbdpNxRKZccmLFCLxVjriE");
    int AZMmVngrcYrFq = -1170222691;
    string XXuDev = string("cCPVnBppgSGSMrnfCuQjxNuDsBWYBRirPjkfEsVoSqXjrLoaOIXwepbnAFJCixtXgkRHTlZqYmgcQDyrTRmwBiOJBrGXvTFfAvtPPfXYWZutLHehDfRhBElNmScHtftclZBXUOdvXBUTzwuiCENOwJjIyaHOQsWolZMATuqNvMBDxYEzaBmlMULRuJZBONThZClxCmXxWH");
    double IiGnoLzrD = -11711.605181714107;

    if (AZMmVngrcYrFq == -1899796885) {
        for (int SxSdPgkutOluZqq = 404255057; SxSdPgkutOluZqq > 0; SxSdPgkutOluZqq--) {
            szFstEkIdILjAgj = XXuDev;
            lYCEFQiWTzIvovqt = bwFEAGnF;
            ImKDCyB = ! ImKDCyB;
            szFstEkIdILjAgj += FTVfwnmSL;
        }
    }

    for (int anAwjM = 1479974982; anAwjM > 0; anAwjM--) {
        FTVfwnmSL = obUMisfMvgeTiJQs;
        FTVfwnmSL += feXnZHdNCdjzwE;
    }

    if (ImKDCyB != true) {
        for (int FegSITwP = 848036386; FegSITwP > 0; FegSITwP--) {
            XXuDev = XXuDev;
            obUMisfMvgeTiJQs += feXnZHdNCdjzwE;
        }
    }

    for (int WElBYWB = 1911741069; WElBYWB > 0; WElBYWB--) {
        obUMisfMvgeTiJQs += obUMisfMvgeTiJQs;
    }
}

void XOWXwalFxvpnnU::tfiux(string TBVEhVKx, bool Jblbngvlarm, string YFHntdrYTveDjp)
{
    int oUMGt = 1113707761;
    bool FHNauHsdFdEZNi = false;
    int gzaJBI = -472171515;
}

string XOWXwalFxvpnnU::ZsMwj(int SVIPjXG, bool eteGYMXL, double gQufvrmFUOPL, bool XbfQqtfd, int gCEdJxqewE)
{
    double jRHcxUWrecC = -285595.56999964744;
    bool pTPKhHeYZImKCzHY = true;
    int GdosGb = -276682144;

    if (GdosGb <= -856372030) {
        for (int uPbmbtpEXeWbPU = 1199708954; uPbmbtpEXeWbPU > 0; uPbmbtpEXeWbPU--) {
            eteGYMXL = eteGYMXL;
        }
    }

    for (int KvBTnPEV = 1830532971; KvBTnPEV > 0; KvBTnPEV--) {
        GdosGb /= GdosGb;
        GdosGb = gCEdJxqewE;
    }

    for (int YaoWjdQZoT = 2066045263; YaoWjdQZoT > 0; YaoWjdQZoT--) {
        continue;
    }

    for (int mrWBJkYIVC = 1777358734; mrWBJkYIVC > 0; mrWBJkYIVC--) {
        continue;
    }

    return string("eppEfgdjWEOIXgENXozHIACIOCKcOxYdaJBJacJyJlAyEafbYBMkhEZBzEINEdaEzRqtuktudokEoHyAeCzozWBwfTJaPSTZIDBIdPNiqPmgImTobuwrHPyfWiJrYPyBSTcGezCYjWACCobtLLVwmtySDaNvuZLjIvLjravSJVkqeLdTXMaFXYlageNhNkwGAWIfxnhfWdieumEdRYYwvilhrqrwY");
}

int XOWXwalFxvpnnU::liMqPdNwA(bool dUQrjteTrHMelTFX, bool ClkeaOo)
{
    int GEsCS = 1110743820;

    for (int GzamxsNyFY = 1866431535; GzamxsNyFY > 0; GzamxsNyFY--) {
        ClkeaOo = ! ClkeaOo;
    }

    if (GEsCS != 1110743820) {
        for (int WDLbHVzdqaRml = 2035635083; WDLbHVzdqaRml > 0; WDLbHVzdqaRml--) {
            dUQrjteTrHMelTFX = ClkeaOo;
            ClkeaOo = dUQrjteTrHMelTFX;
            dUQrjteTrHMelTFX = ClkeaOo;
            GEsCS = GEsCS;
        }
    }

    for (int qjivLRUicenJIsBx = 529899879; qjivLRUicenJIsBx > 0; qjivLRUicenJIsBx--) {
        dUQrjteTrHMelTFX = ClkeaOo;
        GEsCS /= GEsCS;
    }

    return GEsCS;
}

bool XOWXwalFxvpnnU::HHssGarWNxBrLaUt(string eAEiEmyCHyPxcuP, int pSujnlkuSDM)
{
    bool sOoSLxusqRAhNjtP = false;
    string uQLvjfgK = string("jPnOzZvXDOQwfwHyXIqrlCelbysIvjCzbrApEVHGyIUCTglnBgakEXVqXLweGebuQecvFDNhLRjPcNvmtlkSMXLFdXDczbDyIKkxFrOkoEIBsAweMXUCrqVqnxsyhtavMhLjAllJgFGXaKITjMHfIZVrsepdLQmncLIpuZGcXCZHChgINuLGctDtEcObeQXuVnCOzBOwBGZHJQZzLCcA");
    bool OZlafubKZGiRzSe = true;

    if (pSujnlkuSDM > -534533517) {
        for (int jVoGmXdwwjxLlmZ = 1894996315; jVoGmXdwwjxLlmZ > 0; jVoGmXdwwjxLlmZ--) {
            continue;
        }
    }

    for (int SoxtszHF = 82078684; SoxtszHF > 0; SoxtszHF--) {
        uQLvjfgK = eAEiEmyCHyPxcuP;
        OZlafubKZGiRzSe = OZlafubKZGiRzSe;
    }

    for (int TcyHXr = 948039095; TcyHXr > 0; TcyHXr--) {
        eAEiEmyCHyPxcuP = eAEiEmyCHyPxcuP;
        sOoSLxusqRAhNjtP = sOoSLxusqRAhNjtP;
        OZlafubKZGiRzSe = ! sOoSLxusqRAhNjtP;
    }

    if (sOoSLxusqRAhNjtP != true) {
        for (int wGQqyWdaFBqE = 249391955; wGQqyWdaFBqE > 0; wGQqyWdaFBqE--) {
            continue;
        }
    }

    return OZlafubKZGiRzSe;
}

double XOWXwalFxvpnnU::YnoaHGiZLnnGm(string dTpPZfoebUwP, bool rbMETwYTyWqS, bool uLFHPpUf, bool PiQDoIVKuqZrU, double yqmmnX)
{
    double hCMJdvYz = 513537.40832458803;
    int WitqTS = 1136519319;
    int CpVQPhdjbtV = -1140901776;
    double MbdonYVRUMJUnDR = -966606.7838289546;
    int KMYPkbqAMXVxQ = 188983879;
    bool AQzSOcHxgEAUapU = true;
    string JhRqlAqbrbQtyDVT = string("LPNnfJPAyAIRuytSWQXvOYBdQmZKYDMCJJziFJCVQcbbbqGuzCzhywCFUOiqmNRmIhvunUWaCYnsoQVfFqJZgVJGtzMlYsGFhnNqfbHKOCxjqyNSxdBnIMtLJcQjMFbJbJKrLxSvQGVozlGVGCFssiPsYIbagpQpGhYmuyhtkuuEwLnlJwAHXgK");

    for (int UZiTYlKsido = 335942343; UZiTYlKsido > 0; UZiTYlKsido--) {
        WitqTS /= KMYPkbqAMXVxQ;
    }

    if (MbdonYVRUMJUnDR != -966606.7838289546) {
        for (int DHdpfXKpZmzolDLd = 1450488730; DHdpfXKpZmzolDLd > 0; DHdpfXKpZmzolDLd--) {
            continue;
        }
    }

    for (int baVaRqGsTYcOBxzn = 1364582390; baVaRqGsTYcOBxzn > 0; baVaRqGsTYcOBxzn--) {
        CpVQPhdjbtV *= WitqTS;
        hCMJdvYz /= hCMJdvYz;
    }

    return MbdonYVRUMJUnDR;
}

int XOWXwalFxvpnnU::gYuXqWvfhvNqd(bool VgmtbPrL, string dzdTf, double ddGywubCH)
{
    string COVeUTeNF = string("cTeGNHWCisrRoLAerxtWDEZbNnalBMF");
    bool vyXTiMgNq = true;
    string znPIYtKUjqhGYa = string("oaQpoIkIGVCCCRYZwlIdhOGCpioqFlUcaDleOWqEbaAGIyUpwHYhdQZvuOaXpvNDiyVPEfxuIhPvhFdPTkaaJlgKYiNsfTXEQYIzzCkDMeMSTTgoamaMbxwKqvVTGsXQCQkKtSuaUIplTVQHXMIVmIyvGBeTAnHLhVgCeVKUUFIJEpzuCPrIUBrJWSzxNhBQvRbt");
    double YCfWTXym = 405027.4182885982;
    bool SuEIX = true;
    double pkybYhtf = -295980.2147527709;
    double jxDqiCJlH = -769184.4831899215;
    bool EtniojDpsDtlo = true;
    double KcSUdFDF = -370036.99349164;
    double GmUJvcFpvpuOvWx = -673655.8451514537;

    for (int RCaSPMVnqCHyCE = 358972770; RCaSPMVnqCHyCE > 0; RCaSPMVnqCHyCE--) {
        continue;
    }

    for (int pdYMukAiqZFXLp = 751173861; pdYMukAiqZFXLp > 0; pdYMukAiqZFXLp--) {
        jxDqiCJlH = GmUJvcFpvpuOvWx;
        znPIYtKUjqhGYa = COVeUTeNF;
        znPIYtKUjqhGYa = COVeUTeNF;
        ddGywubCH *= ddGywubCH;
    }

    for (int MWTuCfP = 78764940; MWTuCfP > 0; MWTuCfP--) {
        jxDqiCJlH -= jxDqiCJlH;
        GmUJvcFpvpuOvWx += YCfWTXym;
    }

    for (int voWpaBMjc = 1969418489; voWpaBMjc > 0; voWpaBMjc--) {
        ddGywubCH *= YCfWTXym;
        jxDqiCJlH = KcSUdFDF;
    }

    for (int HNpQODmn = 1696429510; HNpQODmn > 0; HNpQODmn--) {
        continue;
    }

    return 42031383;
}

string XOWXwalFxvpnnU::eVLrHFtjh(double jGJraaItpXLqFWZj, int MFYuKi)
{
    double TAfeXnlPgto = -689015.7735465296;
    string RjpWnse = string("mypjeeRywwfaeoZOyyaQitlkIKuYFntpMQeHhINCfSbaWCpfcWucRytdrURCzVqTXSXsrOUfFhzAKICAsKrJOMFHXtsNqK");
    int RJOckClkxoIKPSI = -687569669;
    double YQWCFivFznjjdS = -563776.2809100255;

    for (int XeuXhZfKcyEgjPjX = 2054056173; XeuXhZfKcyEgjPjX > 0; XeuXhZfKcyEgjPjX--) {
        YQWCFivFznjjdS -= jGJraaItpXLqFWZj;
        TAfeXnlPgto += YQWCFivFznjjdS;
        RJOckClkxoIKPSI /= MFYuKi;
        YQWCFivFznjjdS /= YQWCFivFznjjdS;
    }

    return RjpWnse;
}

void XOWXwalFxvpnnU::vggocQXkerMgaAXf(string lwupWXmViy)
{
    bool OkMmAViofcNAIG = true;
    double WpLFmAnKiIddPkh = -178316.4143981104;
    bool ZWNWPcirfoFi = true;

    for (int jPNmw = 2078737643; jPNmw > 0; jPNmw--) {
        ZWNWPcirfoFi = ! OkMmAViofcNAIG;
    }

    for (int vZjyFaSL = 1546849928; vZjyFaSL > 0; vZjyFaSL--) {
        continue;
    }

    for (int SCbRbgnFsheyFbDQ = 1739681219; SCbRbgnFsheyFbDQ > 0; SCbRbgnFsheyFbDQ--) {
        ZWNWPcirfoFi = ! OkMmAViofcNAIG;
        ZWNWPcirfoFi = OkMmAViofcNAIG;
        WpLFmAnKiIddPkh /= WpLFmAnKiIddPkh;
        ZWNWPcirfoFi = ! OkMmAViofcNAIG;
        OkMmAViofcNAIG = ! ZWNWPcirfoFi;
        lwupWXmViy = lwupWXmViy;
        OkMmAViofcNAIG = OkMmAViofcNAIG;
    }

    for (int exeXLswDeVmyoN = 1484640840; exeXLswDeVmyoN > 0; exeXLswDeVmyoN--) {
        WpLFmAnKiIddPkh *= WpLFmAnKiIddPkh;
    }
}

void XOWXwalFxvpnnU::EVLOSFkJaqVvEcqA(string IOGdd, bool XdcVZsjFriYCSo, double PcQchyrlhV)
{
    double CwjtifHaNWp = -693336.083335075;
    string nPFkt = string("fSQHgwiqYXevrjJwJnxIsQDEHiCsgNGtdCyydjXxyyIfHVQRzMdWxwWQizpqKqwZROWtzKNLqUswgSoyEWxMAEsFuuJYYguDnBppiFeNNFDNgBdHZSupLzQXUYFLLbBtDMnFdOFgmcLiRCBKOVxBnUDnalwKYCdsMCNvGSmIlasZu");

    for (int mjxnPdNW = 863978945; mjxnPdNW > 0; mjxnPdNW--) {
        IOGdd = IOGdd;
        IOGdd += nPFkt;
    }

    if (IOGdd < string("fSQHgwiqYXevrjJwJnxIsQDEHiCsgNGtdCyydjXxyyIfHVQRzMdWxwWQizpqKqwZROWtzKNLqUswgSoyEWxMAEsFuuJYYguDnBppiFeNNFDNgBdHZSupLzQXUYFLLbBtDMnFdOFgmcLiRCBKOVxBnUDnalwKYCdsMCNvGSmIlasZu")) {
        for (int vPNxZUPGqeJJJh = 2075547948; vPNxZUPGqeJJJh > 0; vPNxZUPGqeJJJh--) {
            CwjtifHaNWp = CwjtifHaNWp;
            PcQchyrlhV += PcQchyrlhV;
        }
    }
}

void XOWXwalFxvpnnU::AEAeckPJlKmAsO(bool NgSSzsuwzuX)
{
    double lXObmeplI = 852224.4446133629;
    string jJdjSOZy = string("GtmwoXDmTIfUdQVCXdBUXKSgZwoZKKAwaDXBxiUxYqgvsXvYEUYyaeMvXSwTVZzFAnKYXoxmKxgeBIe");
    string JyQpFQzfUDmJz = string("IXOIhsjjBAWDwWwPsNSjRWYgLVlcPuXUZssNevdXueMaIlFCxErGpNbUlRavatafkbGJVxzAbOVPygNUsjrmqfZXLsgDaCyJCDJExfhrSnMEDBJcdaRsuOPctMJZgkiOsgbY");
    int NXRWQpMjoOEILec = -603070054;
    int UEQkZNvaSvsbS = -1770010860;
    bool tQwoZmYWYHM = false;
    bool DclApvbuu = true;
    bool BNtbCmccnNGJ = false;

    for (int CICsKZJ = 377339518; CICsKZJ > 0; CICsKZJ--) {
        DclApvbuu = ! DclApvbuu;
    }

    for (int RXFbfLDuQCiPBJ = 549270510; RXFbfLDuQCiPBJ > 0; RXFbfLDuQCiPBJ--) {
        UEQkZNvaSvsbS /= NXRWQpMjoOEILec;
        BNtbCmccnNGJ = DclApvbuu;
    }

    if (tQwoZmYWYHM != true) {
        for (int aqmftcjNtKJ = 1755467519; aqmftcjNtKJ > 0; aqmftcjNtKJ--) {
            DclApvbuu = BNtbCmccnNGJ;
            NgSSzsuwzuX = DclApvbuu;
            BNtbCmccnNGJ = BNtbCmccnNGJ;
        }
    }

    if (NgSSzsuwzuX == false) {
        for (int fxtpYQGFWyoschNX = 2129684413; fxtpYQGFWyoschNX > 0; fxtpYQGFWyoschNX--) {
            DclApvbuu = ! NgSSzsuwzuX;
            DclApvbuu = tQwoZmYWYHM;
            DclApvbuu = ! DclApvbuu;
        }
    }
}

void XOWXwalFxvpnnU::tUdQAbkyukD(int RHZCmX, bool RlzfTPVt, double ofucJNnGno)
{
    bool mbljJBbJOzAwKthr = false;
    bool jTqSwnwv = false;
    double DFUSCLwtJxmruhE = -446099.47262484673;
    double NGBqFeSZrtgoEvJp = -383829.1257181586;
    double FvAaYHWOylt = 631044.4755658284;

    if (ofucJNnGno <= -446099.47262484673) {
        for (int PYqjlfAAqmRzhEfa = 1606786533; PYqjlfAAqmRzhEfa > 0; PYqjlfAAqmRzhEfa--) {
            ofucJNnGno += ofucJNnGno;
        }
    }

    if (DFUSCLwtJxmruhE != -567225.9661273453) {
        for (int DjpTGf = 1093781412; DjpTGf > 0; DjpTGf--) {
            mbljJBbJOzAwKthr = ! mbljJBbJOzAwKthr;
        }
    }
}

XOWXwalFxvpnnU::XOWXwalFxvpnnU()
{
    this->HaPYlxYCTuoZ(374312535, false, 207190.1115210085, -1003075.8062561469);
    this->SMmOGjo(-644399.9922693757, -1008895.3997559091, true, true, -418569293);
    this->JZQVeuEaGpKLxdGn();
    this->kVmqZkEWlbeJ(string("EhXsavMLCVseASplmOeLCXAxwvmGiefLAlCTADXjKeBbFEpoIcyuhPZJYrhRaiOiecYEpVIqbfGUHqwyfojNYzGKTJOgISVlOVQuUMgjxledwgntpJpfWOYMJPSMBaPnhRBDSJVlMakIQmUZbIPUEzAVLfrHtBLhIpnAJvbUXMAffWKRZqauBvpfHjqGxJFaCWmxAnTzyVkrSGOfRyAZFUFGHHcRfbRUsQjgxTgAclSAgOZMFbMhjJtwIZB"), true);
    this->tfiux(string("ztLejzuLXETxWdiuxhBaxtecnmXgFPiNspmhYPIPClGofBylZwMwAwXdJ"), true, string("UiwgrwLNrKVMQSmowAjWWNaMDaQdQmnCmRlWGQuQBhaWaGgpYo"));
    this->ZsMwj(-856372030, true, 499369.65514294396, true, -2120775938);
    this->liMqPdNwA(true, true);
    this->HHssGarWNxBrLaUt(string("EWImKMBaNxrPusCMKbNeviqxIYpewJQnmbLYHInQygHKCtnDmDJpPDoowxNEAhDAMQFVsHRTqXqnOmzBVPzVdXYmRCxpnmJmtJmGFEZlFQnjrXFbrqGIlJfhsUhvXZdIdkfglrtumlaWqNVJfDOTTZvJqSzg"), -534533517);
    this->YnoaHGiZLnnGm(string("ZpRRAjGQqbRWLZnkXOsDZfHYozzujLGDWmFnTdGktVEdbKLIDKnXjlqhfyrytZdeGaKsnSeBleLZlYZKvfrzVIjzTkPGGNPnCtXytMAQfJYPxhhNxtJjQF"), true, false, true, 418844.35789478564);
    this->gYuXqWvfhvNqd(true, string("PyhwvKMqFtqJpijDwMeetXIWowLtzR"), -355644.76095396513);
    this->eVLrHFtjh(-133246.89204067836, -1668595871);
    this->vggocQXkerMgaAXf(string("PaXAVbWkPYKGsgPBeFpKVjBpsIgpXGTOtRxNGpGNZkdGPdXnxvizXZzHvYrIiJMbitvM"));
    this->EVLOSFkJaqVvEcqA(string("plrTntBVjfWSSJjeCwyxTjKKvLtXTyoxofrrrtjiJeWIqFltNpOmihPAKZllJrjPzjsVVGduJTPgrJhLtdIadgsYpRMHuJkUUDusHcGAzZMpcpDNWRxGIuEgsxkTXqiDRoBYiNmnAXYSkxKlFHhtMCDCGeijFoiuXmHwVzceZvoWfaYjxU"), false, -320355.81761224836);
    this->AEAeckPJlKmAsO(true);
    this->tUdQAbkyukD(-713916269, false, -567225.9661273453);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ugmVksk
{
public:
    double jqfwj;
    int TAcqhnjOtQ;
    string DnByAAIdJ;
    string mcZlqZSsKIewqsLp;
    int kaCjwx;
    bool pzHyQoQbVM;

    ugmVksk();
    int etbvDiMhkkDRUERi(bool nAMvUkKCoN, int wMEAXUtUGAk, double eNlfjJsRY);
    int CoUyEo();
    double PrBlurEQMyOvDN();
protected:
    bool nDTzAbTyE;

    void CCAVB(double AoSAdJy, int vYhEplo, int jbPIZKGFgNH, double xCSSghyRcjI, int xgsJF);
    double owCGwtsjvs(int PWmjliIzKQRRLX);
    int fQlVAc();
    double KjuIYFUlNPmfh(string HfhLL, int FywYIRknY, int rwIDkETpBoA, bool UdadnCdmeerVH, bool EjaGxcpjsu);
    double HvJxAPGYQS(string TROHdWdAw, string tlbLBVtaWqLR, string gSwExfPf, int yezvShux);
    void znEvCicGK(double HCqMd, double aqszfUi);
    void AyFISmA();
private:
    double rkGeZmJY;
    int zddFZ;
    string XozHNG;

    int YxHjn(double hlWJpvgbEPYqxwe);
    string exDkldAPxBp(int JwiiFGQ, string BBMcHpk, int ZbdOREt, string mvvaNQEYj);
    void VppbByzKPXRO(bool WbrpJC, double xOYtBGIRx, bool veUtLJ, int oAWVLwsTmUOdMi);
};

int ugmVksk::etbvDiMhkkDRUERi(bool nAMvUkKCoN, int wMEAXUtUGAk, double eNlfjJsRY)
{
    string QBeMvx = string("wrpGeUZyHiEvolOHzCEwrOxmupSUtRvOZea");
    int FwHsagf = -30020190;
    int iMEbsWqvhbR = -1966960804;
    int nqkVrtCEQGqsqW = -111835997;
    bool XKEYL = false;

    if (XKEYL != false) {
        for (int kiMXsvbd = 412712465; kiMXsvbd > 0; kiMXsvbd--) {
            nqkVrtCEQGqsqW -= nqkVrtCEQGqsqW;
            eNlfjJsRY -= eNlfjJsRY;
        }
    }

    return nqkVrtCEQGqsqW;
}

int ugmVksk::CoUyEo()
{
    string fEFuCtWOPgGl = string("nfQRRbVPJePUiltkwdIgqTgMjImYjkwedHjpjPnVRTSGuGfhLioglocDyJUkYdyudOwCdSBSxBzthIMLZxcHZjUgwmwRZaGgKfFZswoeveWNvVcNQGibTLvbkQgppQaeaPMdZCSwRBWwSmkqAqKYFsTkthtnjqRlZeGGCkKAwnWcVAGuAdTsPPaJKjjJpcQoxEgWOHRTawTR");
    int JBYZpJY = -818591677;
    int xZuBjlPsVj = -1207720195;
    double fGNTtSzJjJExVl = 444830.74834916985;
    double aAmYemcH = 369469.03723798844;
    double lEJrByN = 1038940.4114674748;
    int jxZuBi = -505020885;

    for (int tVErF = 2051654160; tVErF > 0; tVErF--) {
        jxZuBi *= jxZuBi;
        xZuBjlPsVj *= jxZuBi;
        JBYZpJY += xZuBjlPsVj;
    }

    for (int XGSsaP = 477201452; XGSsaP > 0; XGSsaP--) {
        lEJrByN /= aAmYemcH;
        xZuBjlPsVj -= xZuBjlPsVj;
        lEJrByN -= aAmYemcH;
    }

    if (JBYZpJY > -818591677) {
        for (int juWUisJb = 1323414986; juWUisJb > 0; juWUisJb--) {
            fGNTtSzJjJExVl /= fGNTtSzJjJExVl;
            lEJrByN -= lEJrByN;
            lEJrByN -= fGNTtSzJjJExVl;
        }
    }

    if (jxZuBi != -505020885) {
        for (int eTmARfznYlzKdAK = 2111813690; eTmARfznYlzKdAK > 0; eTmARfznYlzKdAK--) {
            jxZuBi += JBYZpJY;
        }
    }

    if (xZuBjlPsVj <= -818591677) {
        for (int nAZeKLxdLV = 265590001; nAZeKLxdLV > 0; nAZeKLxdLV--) {
            JBYZpJY -= JBYZpJY;
            lEJrByN = fGNTtSzJjJExVl;
            fGNTtSzJjJExVl -= lEJrByN;
            JBYZpJY += xZuBjlPsVj;
            fGNTtSzJjJExVl *= fGNTtSzJjJExVl;
            xZuBjlPsVj *= JBYZpJY;
            xZuBjlPsVj *= xZuBjlPsVj;
        }
    }

    if (fGNTtSzJjJExVl == 444830.74834916985) {
        for (int VoPvefdqmlBMt = 528651636; VoPvefdqmlBMt > 0; VoPvefdqmlBMt--) {
            fGNTtSzJjJExVl -= aAmYemcH;
            jxZuBi += JBYZpJY;
            fGNTtSzJjJExVl -= aAmYemcH;
        }
    }

    return jxZuBi;
}

double ugmVksk::PrBlurEQMyOvDN()
{
    bool NozvKVh = false;

    if (NozvKVh == false) {
        for (int ehGMNSpXH = 503593896; ehGMNSpXH > 0; ehGMNSpXH--) {
            NozvKVh = ! NozvKVh;
            NozvKVh = ! NozvKVh;
            NozvKVh = ! NozvKVh;
            NozvKVh = ! NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = NozvKVh;
        }
    }

    if (NozvKVh == false) {
        for (int oWDGEK = 1838194699; oWDGEK > 0; oWDGEK--) {
            NozvKVh = NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = ! NozvKVh;
        }
    }

    if (NozvKVh != false) {
        for (int iWbxomiHoP = 1747846181; iWbxomiHoP > 0; iWbxomiHoP--) {
            NozvKVh = NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = ! NozvKVh;
            NozvKVh = ! NozvKVh;
            NozvKVh = ! NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = NozvKVh;
            NozvKVh = ! NozvKVh;
            NozvKVh = NozvKVh;
        }
    }

    if (NozvKVh == false) {
        for (int aZgBjMfz = 2061646814; aZgBjMfz > 0; aZgBjMfz--) {
            NozvKVh = NozvKVh;
        }
    }

    return -380036.30122180586;
}

void ugmVksk::CCAVB(double AoSAdJy, int vYhEplo, int jbPIZKGFgNH, double xCSSghyRcjI, int xgsJF)
{
    int sMvZMyL = -2051657607;
    int oTFjbUoWSOwS = -1350125315;
    bool PSYSuMpNqxSJdqoO = false;
    int wJClhvOB = 967139764;
    int wSJGuH = -1693754479;
    int VeLyZndEhVnWpkr = 385789776;
    double cAEKLywMapvOOwS = -662114.6414042047;
    bool JQgFwSTCLnSla = true;
    double BlMsZtbpUmUVRSO = 710088.6926624362;

    for (int EWEIgSU = 1333379810; EWEIgSU > 0; EWEIgSU--) {
        sMvZMyL += wSJGuH;
        JQgFwSTCLnSla = JQgFwSTCLnSla;
    }
}

double ugmVksk::owCGwtsjvs(int PWmjliIzKQRRLX)
{
    double hKbdmUpg = -535481.89586923;
    int qPcDzoWBbHtJMNr = 1386719415;
    string xIHCjRGKZa = string("bKmkmdSzbjPENXdJNInVxyVEigeGygHDaeRNXXfsgGfPSJEbkDShTtXyEcTHdBqtJiLkdGucqfbznmslqZKARxbnVtIhcgfYufnRACneMRgMYCtxCUktelzidcDwMdWHtwRifxiMIbJrPSnjZhbhSKSjnEcnxfJLhctZEifSUVAJNNPBydALpxURRkCdXVBILxIaZAqXULqWhvvtGOrwCAjrAahqAQRqk");
    bool NRaPHuNc = false;
    double VWDyzuTzxMAxFm = 16571.279233623452;
    double ZBKDuQqK = 190966.60210138856;
    bool wvGXm = true;
    int duozLgE = -593028796;
    int GoqugLdhlaPVdtUK = 1587362020;

    if (PWmjliIzKQRRLX <= -811776664) {
        for (int spZCrSiJwhCpfe = 34345759; spZCrSiJwhCpfe > 0; spZCrSiJwhCpfe--) {
            GoqugLdhlaPVdtUK += qPcDzoWBbHtJMNr;
            ZBKDuQqK = VWDyzuTzxMAxFm;
            VWDyzuTzxMAxFm = ZBKDuQqK;
            GoqugLdhlaPVdtUK += qPcDzoWBbHtJMNr;
        }
    }

    return ZBKDuQqK;
}

int ugmVksk::fQlVAc()
{
    string JTDOYCH = string("lGENiVXCKXDmgHduoAQfYlgjJtEWITohDsRIvmpdHEVuvIZwWqnMxXpMwIZzbNfXBVcIlhkgSSnqccfTBQakNqkvgYUgaEbxXXxjXfutVygffScgjdVevjRUgSVwRWZajmuGsHCZjabgLzQvbKAHMRvwIndoHrBKiBIgTtsKpppSzYffYHqWkATLREMzzFFOGQWRjamkdlDXuSNnJWsVtTVEmqTTTJJWP");
    string rARrdzst = string("owOXVbRmYPKWjjNIGPtUHaRnYpvLWLqXEUggcVRvyZwbHJiNOkfMEzGNWqKTbQXYqKYMYRUZzrSPuaFwuKmktzFBShrllXcCVOaIRoxPSozdlLmvLjSLaQTTxdWNuuZGQhRtMAeGRKZp");
    string QoDhEZddNJZHjG = string("buDGQGAFHsarTJgeaBPPyCddjlyEiQlCthjvUVaOTMrNeXfZroPGhIQdUDnLuVeoXFEQLprALjzoFELCWjqXeJQhigFZzpdRcCZnXXDoVorASAFnhilyBWdbveTuyVcNoZbZgHPrasBZMQiZOKuMPjpnLPuJWmkzmXuCcLdSJljWHiFBjzzhNFHIirgizQaPkyYGlEHaqsFrYixxHTHBYilACeIgeVCYonOFFUjlMmm");
    int RdPJm = 516440452;

    for (int oDSVIDJZOV = 339146571; oDSVIDJZOV > 0; oDSVIDJZOV--) {
        JTDOYCH = JTDOYCH;
        rARrdzst = QoDhEZddNJZHjG;
        QoDhEZddNJZHjG += rARrdzst;
        JTDOYCH = QoDhEZddNJZHjG;
    }

    return RdPJm;
}

double ugmVksk::KjuIYFUlNPmfh(string HfhLL, int FywYIRknY, int rwIDkETpBoA, bool UdadnCdmeerVH, bool EjaGxcpjsu)
{
    string ASsZomGjflvcU = string("KfvjwUpVTWvnIOfpTmKwoRHBJEFGltGppFocIvULOyJsdBDypTyVisuyACSsFkpeMYkkLuODSBSmsaabEqqvPWdbMGwSzgvAREogQpFguijCslJtZHrxVzdJXqpRsDHyoICAlcUbYKtpSHKwXJNpXEUSynsCMzuNRayKQbXIarcZdWwQlPbPAgEAhnmzVXUqdScZxJNIKmPMEolxBXPnWyknGsuUHvRSRpwxlnnMlFFYYkzJVmfvzPy");
    bool uPJrmOxtwSjm = true;
    bool jIhaGm = true;
    int dTxWtddmRFaM = -1196187795;
    string FHpHBXI = string("nDeZcEKBXrshrVWmAbalrLwnndQdIR");

    for (int WrkhYsFDLydU = 1634075902; WrkhYsFDLydU > 0; WrkhYsFDLydU--) {
        jIhaGm = ! jIhaGm;
    }

    for (int WnxIXwQeviBrQa = 1338065373; WnxIXwQeviBrQa > 0; WnxIXwQeviBrQa--) {
        continue;
    }

    for (int AKNYjI = 1949960952; AKNYjI > 0; AKNYjI--) {
        continue;
    }

    return -989628.1288473638;
}

double ugmVksk::HvJxAPGYQS(string TROHdWdAw, string tlbLBVtaWqLR, string gSwExfPf, int yezvShux)
{
    double GSEFMsUBlO = -308198.7670775339;
    bool ZEevsjy = false;
    string LJWKtgfMj = string("ebirfzSsRjrpgVJSaeViZgyIiaAnSzXLJRFaZLJOvCWnDsCgjeBogMTWVihcStsnfnbRZeQppW");
    string XzWidnP = string("vXNKEyFfPZyxYFGeyShyKkZepbROBvoNbvahJoAgTRVgsNmr");
    double AqSFaUcjtSKBPlbb = -848643.2206661054;
    bool DcBAwzgHSqF = true;

    return AqSFaUcjtSKBPlbb;
}

void ugmVksk::znEvCicGK(double HCqMd, double aqszfUi)
{
    double SyoRVckngzQgdUf = -546325.4298539701;
    int adIZStg = 520800725;
    double lVfVTKhWZblXVAoz = -235945.26176044176;
    double qlgcGdQiydB = -5135.153902440962;
    bool eUOHj = true;

    for (int ALTQJFkCPsHdUQB = 46693345; ALTQJFkCPsHdUQB > 0; ALTQJFkCPsHdUQB--) {
        continue;
    }

    if (HCqMd >= -235945.26176044176) {
        for (int YPehwGAMTJGEZJ = 716815953; YPehwGAMTJGEZJ > 0; YPehwGAMTJGEZJ--) {
            SyoRVckngzQgdUf /= lVfVTKhWZblXVAoz;
            SyoRVckngzQgdUf += HCqMd;
        }
    }
}

void ugmVksk::AyFISmA()
{
    string WUDSu = string("gnAESoPKoLvxSnYTpLeIjOAGXDVAQqbZITWkAPstDPXOULsswCrxlbliTySvzpKPDPdNMnqunSmWhVnCRNuLZHOfXXOsOoUJVCSUiTjoXEnFZJInxFCgesJtcnaHuzkozfkzYMhebC");
    int BsLcFUWrYrL = 1513475693;
    double SyvgncdqhSPZHdCA = 251885.92593963371;

    for (int uOpSbSZ = 1407430821; uOpSbSZ > 0; uOpSbSZ--) {
        BsLcFUWrYrL *= BsLcFUWrYrL;
        SyvgncdqhSPZHdCA += SyvgncdqhSPZHdCA;
    }

    for (int ZRHQGtEvNa = 517361133; ZRHQGtEvNa > 0; ZRHQGtEvNa--) {
        WUDSu += WUDSu;
        WUDSu += WUDSu;
        WUDSu = WUDSu;
        BsLcFUWrYrL -= BsLcFUWrYrL;
    }

    for (int BOMesfb = 302894653; BOMesfb > 0; BOMesfb--) {
        BsLcFUWrYrL -= BsLcFUWrYrL;
    }

    for (int AXEwE = 900382760; AXEwE > 0; AXEwE--) {
        WUDSu += WUDSu;
        BsLcFUWrYrL /= BsLcFUWrYrL;
        WUDSu += WUDSu;
    }
}

int ugmVksk::YxHjn(double hlWJpvgbEPYqxwe)
{
    bool hGJXWXBkOpcGjg = false;
    bool loQFQLrYXVe = false;
    double qqTco = 903849.393840323;
    bool PQjxY = false;
    bool lKKGsOXNYkRC = true;
    double WiYparrP = 16029.05529662054;
    bool AEbjOdRE = true;
    int gghOEy = -1291171938;
    int TOzRDPKMmP = -1186468650;

    if (lKKGsOXNYkRC == false) {
        for (int lwgmmdUfSxA = 550603847; lwgmmdUfSxA > 0; lwgmmdUfSxA--) {
            loQFQLrYXVe = PQjxY;
            hGJXWXBkOpcGjg = PQjxY;
            lKKGsOXNYkRC = hGJXWXBkOpcGjg;
            PQjxY = loQFQLrYXVe;
        }
    }

    return TOzRDPKMmP;
}

string ugmVksk::exDkldAPxBp(int JwiiFGQ, string BBMcHpk, int ZbdOREt, string mvvaNQEYj)
{
    double EOBMYT = 525010.3355569635;
    string wnySvZKbHvf = string("eXchLPvvUkFxLPXisBJeu");
    bool XQbuzq = true;
    bool FbNwVPizgbX = true;
    int GhulkGBqNFISdfP = -667476871;
    string dqORkCcn = string("lFJlqxnlYpMvyZJpBOZHGpUDrjbStxoxbwqApQloEGGbEQfAkbuZZISzxPPHaroqLJqaBtKsAfykRhznYvmjjXwRmEpKoyepKluLGHNlvyVhEINNdNYsnWUXsKikvIEWBomvCDoodwMsXSVkWlrDDoeBAzMopTAwmKRQseNCZLpWGMsUFBTjEQEsQQYbaAPPSMcbRJeOSKhFeUXeZueedqCvcapoHePLX");
    double KVoKUXhXJlzNqJk = 115598.59372042897;
    int akwZQMsmHn = 948949911;
    string VHpRcQtNxabgEi = string("IEcjkFbZuZDkjqZMhbcvJOQAPnLYDAUKKQDvmkhyZxuVoTaIrVbOiqZYaciEYxOFYBttpNFIJTrVnCyUYUDijQQFbjAzmdjOaSRuDsdguVgHaCjgzDfsvdHFRHbapaHseSklMggDmMuSfFYXDIbjBPQPqYRiNfXLpFNKhvwwrQEwIxvclyZLYIfiyjiiogayHinOREPRtErsJwbjsWhfZByyxZbSVPU");

    for (int thvQz = 1434731795; thvQz > 0; thvQz--) {
        akwZQMsmHn /= GhulkGBqNFISdfP;
    }

    for (int kxrrUtWCFmiNv = 1260407862; kxrrUtWCFmiNv > 0; kxrrUtWCFmiNv--) {
        dqORkCcn = wnySvZKbHvf;
        GhulkGBqNFISdfP = ZbdOREt;
    }

    for (int UJSbN = 1849762927; UJSbN > 0; UJSbN--) {
        continue;
    }

    return VHpRcQtNxabgEi;
}

void ugmVksk::VppbByzKPXRO(bool WbrpJC, double xOYtBGIRx, bool veUtLJ, int oAWVLwsTmUOdMi)
{
    string qAtfNGnKb = string("foJpvKXZkmQyZgUhwwQNuRxjgTRWAfHnSDSbOvIXxRVUCnpppenhyeDvbcuesyjLWSLmQOUjISAKSO");
    double tSwzKLU = -746991.3178635332;

    for (int uFPLnogERIOlrt = 744081914; uFPLnogERIOlrt > 0; uFPLnogERIOlrt--) {
        oAWVLwsTmUOdMi = oAWVLwsTmUOdMi;
        veUtLJ = WbrpJC;
        veUtLJ = ! veUtLJ;
        xOYtBGIRx /= tSwzKLU;
        WbrpJC = veUtLJ;
    }

    for (int bVADwOlKQI = 1572097335; bVADwOlKQI > 0; bVADwOlKQI--) {
        WbrpJC = ! WbrpJC;
    }

    if (veUtLJ == false) {
        for (int QuOVnUfaprNTj = 1410746806; QuOVnUfaprNTj > 0; QuOVnUfaprNTj--) {
            veUtLJ = ! veUtLJ;
            WbrpJC = ! veUtLJ;
            veUtLJ = ! veUtLJ;
            qAtfNGnKb = qAtfNGnKb;
            WbrpJC = WbrpJC;
        }
    }

    for (int GJiUjD = 1142760873; GJiUjD > 0; GJiUjD--) {
        xOYtBGIRx /= xOYtBGIRx;
        oAWVLwsTmUOdMi *= oAWVLwsTmUOdMi;
        xOYtBGIRx -= tSwzKLU;
        veUtLJ = ! WbrpJC;
    }

    for (int unwVodeb = 165746746; unwVodeb > 0; unwVodeb--) {
        oAWVLwsTmUOdMi = oAWVLwsTmUOdMi;
    }

    for (int lIxwsmowZxyV = 478580727; lIxwsmowZxyV > 0; lIxwsmowZxyV--) {
        veUtLJ = ! veUtLJ;
    }

    for (int JXtDfsQG = 1710862079; JXtDfsQG > 0; JXtDfsQG--) {
        continue;
    }

    for (int STriFwbBT = 128853049; STriFwbBT > 0; STriFwbBT--) {
        WbrpJC = veUtLJ;
    }
}

ugmVksk::ugmVksk()
{
    this->etbvDiMhkkDRUERi(false, -1147477105, -556768.4788873406);
    this->CoUyEo();
    this->PrBlurEQMyOvDN();
    this->CCAVB(-242749.5889175751, -292016014, 584964447, -614839.4933404499, 1166932432);
    this->owCGwtsjvs(-811776664);
    this->fQlVAc();
    this->KjuIYFUlNPmfh(string("JXnMyGxNxnlBhOTAgmiZUGgVEPmVQVvpaxVEYSkEhdbNraYFtIpckIbdScWTyVSzHctiHGFWjcyrZoBkDlpfR"), -155815853, -394351435, false, true);
    this->HvJxAPGYQS(string("szzzokgVCLxebLGBlNYjOXJVKMNBtPsEVDavYlgrDVPPBGXuTuFsfIWhdSEkWdtOoYtCDuthtugdWrekJMS"), string("wRLmQmKJYSjimBtRkyRwJzLSGBRsdMKFzHDpUieTwrepgrYmXTpDCgHGiJbANwtwwWqkwMCYgcVeLBcHjWhDwLtpjvFpeWyiGmeCgxvtCKqoEicJlhZWfQnHYGoOmUNiFFGpcPAyqFqmedeCmoyLlxcoahQUOoBqWMUqTOe"), string("rGVYkgpNdIFQmbKbUFRJOASGNhsJaTaCrOZTfzTlPlVhKwMWVaUXqSngClbVipPNwJAGFGDYryQBLiSbrPLQkJuzPnEYDbINlPdiIgKeKvG"), 927731907);
    this->znEvCicGK(229209.10770670476, -189026.71276619798);
    this->AyFISmA();
    this->YxHjn(220688.99887592107);
    this->exDkldAPxBp(-511215115, string("yFxurgwecbNJZBOlaFsiUvwEBuqMucCwyjoUeUwwJjdMdhotKqPCSnyFfAXYtABPTxLIeqaGrYCcdivRWOhpWGhjwNuyyANq"), 1020558658, string("lvghIUXAzolbDRafNXQqjpiYzvDNDlWazoPmFqIOlnJGNiDuBcCLusxOEYPBpwNZllzVzrDyVyflePOVUCYdCclmODRXGOMVYjgZrqxHXNxxbVoSWFpVmBlDnpjoWmnZTIqciWRFFEoDeFahPPXCfeXRyIzLqbPZCOVhhVvsVBgDUQuDeCeVvMBOPfeHFTjNbA"));
    this->VppbByzKPXRO(false, 91578.61972730872, false, 453566992);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BHPWlXKNigQhH
{
public:
    double AWsIMhanzKabdT;

    BHPWlXKNigQhH();
    int qvaCtRmTK(double bJPlcknuWeSOXO);
    bool yryFoNMpyryv(int efRdMwf, int hRYmUwJmcxXfOo, int xFHTc, int rMuspUUybl, int PXhhNctAN);
    int TOmsBikkAVxoG(double qSgUJDcwrlY, bool DVxyDiYu, bool EOZqWEPEUgm);
    double MzosKnesUqkm(int GSnHFP, int hWnYBMfiP, int GzTYuGNro, string eiohikU);
    int PIhSSM(bool LGreUVvWVzr);
    void CQNqHbJIurrNjf(bool wkKEGYdroxciGF, string tSuhzqCFEyEV, bool kerPrA, double vCsbSomSoIdm);
    int DiTKQHoUJodfa();
    void NnOMuOAABrRsb(int yaOEoUlOdE, int JYqBcuqnkAzN, int IKLEjFpnmGA);
protected:
    double oeJMDqLQMOM;

    int chtRo();
private:
    double QygYGPEF;
    bool QYLMUDAYMsQP;
    bool IzDHlv;
    double VyGkm;

    string udzAPvtdgc(bool crMxsVyO);
    int GZeHCyDTHzdCKeBD(int qGsGmmslFPdofc, string KiVddcC, string YMmwQQDxgVuk, bool ohbGIXqjl, double SZKuPR);
};

int BHPWlXKNigQhH::qvaCtRmTK(double bJPlcknuWeSOXO)
{
    bool hYFChcVeINRMrG = false;
    int HQCCrfLA = 700797688;
    string jaLmgyWPeRM = string("iCYnIukSwLoLBFCNQcPGYyBGCPoKPWSHULCaQmgCwVrQHWNMqAYIYTnLmoRVgfvpWhxKMAoDFzJaDHpxrHvDZuFnJfYLqwgwlaVXtmsErWMeDpPJNXFmpFTTsRNufgsFFwDCvSFMcaVHIgorRhyKbRtbXQhrnKUSnkJxHHVMsSge");
    bool pKxhNIGTFWd = true;
    int CRQfPs = 1059814233;
    int xHwcARwdy = -968304873;
    int QzBIm = -1539855635;
    string keULRaxxnpHYKR = string("upPesfjPuEZLzLAkXSgYsNOSaSSsZaKGqnBxnQmVotwOGejrDnVqPPpeiALwEveWiCOgnwaHAvOUMsQ");
    int PrHJuDG = -247591536;

    if (HQCCrfLA != -968304873) {
        for (int IiGQsXchgD = 2145713932; IiGQsXchgD > 0; IiGQsXchgD--) {
            QzBIm -= QzBIm;
        }
    }

    for (int lFIXldbD = 2142832524; lFIXldbD > 0; lFIXldbD--) {
        QzBIm /= QzBIm;
    }

    for (int ntErmSOSCKa = 2129892023; ntErmSOSCKa > 0; ntErmSOSCKa--) {
        continue;
    }

    return PrHJuDG;
}

bool BHPWlXKNigQhH::yryFoNMpyryv(int efRdMwf, int hRYmUwJmcxXfOo, int xFHTc, int rMuspUUybl, int PXhhNctAN)
{
    bool chdBrVxoQ = false;
    string rCFBOIJJJXHffZS = string("ALYRcjfwRnyaxLLIPPW");
    bool jDwKpEFmnuLeJo = false;
    double ITozuxCVfQvQwalD = 243105.66012519834;
    int qXOrN = -2094854989;
    bool MgQmqhnVxUH = true;
    string GCynCYJePOzfcZe = string("dhohWyiczaTUFZTJmiQjVyFeCLZpTpEbOdSdeJvOUIIapSDXKrVHUUhtjxHmjqcdRJDIsGkPuqcybKckOwy");
    int NCVAkpryjSbcs = 230722784;

    for (int DEWLxxcIsqSKjqJT = 774973347; DEWLxxcIsqSKjqJT > 0; DEWLxxcIsqSKjqJT--) {
        qXOrN += rMuspUUybl;
    }

    if (efRdMwf != -276992566) {
        for (int ZUcuZu = 1020213443; ZUcuZu > 0; ZUcuZu--) {
            NCVAkpryjSbcs += efRdMwf;
            PXhhNctAN = qXOrN;
            PXhhNctAN /= NCVAkpryjSbcs;
        }
    }

    for (int uiaop = 968732142; uiaop > 0; uiaop--) {
        efRdMwf /= PXhhNctAN;
        jDwKpEFmnuLeJo = ! chdBrVxoQ;
        PXhhNctAN = rMuspUUybl;
        qXOrN /= xFHTc;
        NCVAkpryjSbcs = PXhhNctAN;
        xFHTc /= xFHTc;
    }

    return MgQmqhnVxUH;
}

int BHPWlXKNigQhH::TOmsBikkAVxoG(double qSgUJDcwrlY, bool DVxyDiYu, bool EOZqWEPEUgm)
{
    int PvQZGyO = -87716020;
    int nUTUFYdMfSh = 1076714758;
    double UxOpyKezB = -426655.8904031811;
    bool oFRNBFSvSVVvqm = true;
    int pFgHQdogJkwilROK = -1210531991;
    int CmhgLVtcJsbIM = -1277092013;

    for (int DAdTPxMdzCRDAdM = 2125749335; DAdTPxMdzCRDAdM > 0; DAdTPxMdzCRDAdM--) {
        continue;
    }

    return CmhgLVtcJsbIM;
}

double BHPWlXKNigQhH::MzosKnesUqkm(int GSnHFP, int hWnYBMfiP, int GzTYuGNro, string eiohikU)
{
    int mvJlpsLaCmDNzvQh = -917722431;
    int UudbXivvq = -308483234;
    string gMIqddy = string("EOkuJmOghQORqJeNoKnvKRhOxfEKrkLcLwilYAeyEJqfKFLtnKTUikHFEbWQlCahxKCewdyQUhJWBZRlvoJLcqafGRuRTrGqJcxaTJfRRxnFjnGRKHfdDUBUcsENPUyDtUEWjtpVkgCQPXMeVDfYsKDeCRaLCNsClDwQQRnvpDpOoaaxMhlxRWhIJrrdOmcBkiIOJvtRWTphqqDDQ");

    if (eiohikU >= string("EOkuJmOghQORqJeNoKnvKRhOxfEKrkLcLwilYAeyEJqfKFLtnKTUikHFEbWQlCahxKCewdyQUhJWBZRlvoJLcqafGRuRTrGqJcxaTJfRRxnFjnGRKHfdDUBUcsENPUyDtUEWjtpVkgCQPXMeVDfYsKDeCRaLCNsClDwQQRnvpDpOoaaxMhlxRWhIJrrdOmcBkiIOJvtRWTphqqDDQ")) {
        for (int iDNlGjLmKpJqY = 1363588178; iDNlGjLmKpJqY > 0; iDNlGjLmKpJqY--) {
            UudbXivvq = hWnYBMfiP;
            hWnYBMfiP -= GzTYuGNro;
            GSnHFP *= GSnHFP;
            GzTYuGNro *= hWnYBMfiP;
            eiohikU += eiohikU;
        }
    }

    return -70960.66666126972;
}

int BHPWlXKNigQhH::PIhSSM(bool LGreUVvWVzr)
{
    double ZXlRCrWgnmjpYI = -5420.190653847342;
    string PGctDm = string("PbxsOMvpoOMHEAlJsquSVTyqvaMcnEFikQqCeNWyclnBxXfHqVJtOYvmzcCqTwUTGpxYLanVLBxdoBgNmvvXQtNcggxuKOUTbtmjktadXJvDfJyzsfSqeHDXNjtlQSATfdFhyaAsBXidFOgPalGXyFrAiZtJqPpGDAzLhfLfhVnIyIZGYCLHzrZiDOqBHLulvfbZFVThtQr");
    string VVLTGtTsFOKzW = string("zVKGPIuudsOnLeleVeDGjEeYSJHNzerHuIxreZhjw");
    string LXykRsIG = string("qghpdBxosTLpTTYVjirozYYPwzfTdEPYmInnNczynZDZohdVDBoIZEsAyiROLeyNCCtwAHAiYbG");
    string YycHbQFAHjD = string("DbwSfTstYjQQvDvIxxCXqSDfnbbmfeEwXNITXgEjiOOwDJxcJXhgEYRmnhRmyAWfHUHwndiwvEqwcALAYCDIJvtaFPBpIBPHeIfxBxzMTfUHDTHUQeAomzLtVorxSWwMgGvWwuJNyjfEojJ");
    bool zIzXnJfZHmADZT = false;
    bool IXcjWCh = true;
    bool gkvcjyAAUPRd = true;
    double lJECgJftVeeF = 828384.6952326242;

    for (int NjMdaBkgxRqL = 1632843512; NjMdaBkgxRqL > 0; NjMdaBkgxRqL--) {
        ZXlRCrWgnmjpYI *= ZXlRCrWgnmjpYI;
        PGctDm += LXykRsIG;
        IXcjWCh = ! LGreUVvWVzr;
    }

    for (int SVBjkfXVtYNVBuJU = 469199478; SVBjkfXVtYNVBuJU > 0; SVBjkfXVtYNVBuJU--) {
        IXcjWCh = zIzXnJfZHmADZT;
        LXykRsIG += VVLTGtTsFOKzW;
    }

    return 2088497921;
}

void BHPWlXKNigQhH::CQNqHbJIurrNjf(bool wkKEGYdroxciGF, string tSuhzqCFEyEV, bool kerPrA, double vCsbSomSoIdm)
{
    double fvLykFf = 822539.6806165006;
    int kmunJsvcyQzb = -1963507669;
    double abwwcR = 48713.00022373587;
    string heCkYgsIVRedQxP = string("uoDMdZKOvoFvIISXPpRFUtAJQFXDGKvEhpoZCtORJgqfQrQFRbrkWxzUsJvhZEDAOqJBSxzQenTlcMjcvilMIxJtwKCnLulirWhCDqqiUKemIiwbDAEshIksWzvqsyCPqkJcDunQSNTIaTCPkdEFCQrNJhaTlwmwMkngirVKJoNCDIEihdSNGoFoZZVsJidERB");

    if (kerPrA != true) {
        for (int rCYEOLFMpuB = 1700257881; rCYEOLFMpuB > 0; rCYEOLFMpuB--) {
            continue;
        }
    }

    for (int TmIZJRtGmSSnEhB = 255854155; TmIZJRtGmSSnEhB > 0; TmIZJRtGmSSnEhB--) {
        fvLykFf -= fvLykFf;
        fvLykFf *= vCsbSomSoIdm;
    }

    if (fvLykFf > 48713.00022373587) {
        for (int AfmSfjUo = 196692580; AfmSfjUo > 0; AfmSfjUo--) {
            kerPrA = kerPrA;
            kerPrA = wkKEGYdroxciGF;
            heCkYgsIVRedQxP = heCkYgsIVRedQxP;
        }
    }
}

int BHPWlXKNigQhH::DiTKQHoUJodfa()
{
    int taKSdDqep = 1056121765;
    bool qwTPfVo = false;
    int feOavGECiWOoiyYQ = -298711088;
    int fCXxpBlWAegU = -390790513;
    int VDwqVd = 452512026;
    string SvQQyetHW = string("mgdGzvaHBTLUgSjqeLaykUnRvYycnmEXhmIyjcSuEIqYssowyoVjXkffAPFXlXWCBFNJcYuRxOSqNleeRhSJdOIieBXdDWUzRRgmwQiCGwFRkvfIonIhtRyePTEhegQSLpTJebtlJOAkHOcQzjiMbplBfgsNAaCXNxFOaoBvApHSGhyJcrtHDQDEcrMqSeWADoYgSmyHXvWSzRrjdrEpmwMZbaZsmDMnxZxmRjZxgBVmmyrqBCF");
    double wjKVZJTtKRBQYaQ = -11858.624951841844;
    bool UFpFqx = false;

    for (int ympNkFPKjfLU = 1482794292; ympNkFPKjfLU > 0; ympNkFPKjfLU--) {
        taKSdDqep *= fCXxpBlWAegU;
        fCXxpBlWAegU -= VDwqVd;
    }

    if (UFpFqx == false) {
        for (int sKjWZriCyQOquJ = 549554447; sKjWZriCyQOquJ > 0; sKjWZriCyQOquJ--) {
            feOavGECiWOoiyYQ += fCXxpBlWAegU;
            fCXxpBlWAegU = feOavGECiWOoiyYQ;
            SvQQyetHW = SvQQyetHW;
            feOavGECiWOoiyYQ = feOavGECiWOoiyYQ;
        }
    }

    for (int bGTTdBII = 1570614205; bGTTdBII > 0; bGTTdBII--) {
        wjKVZJTtKRBQYaQ -= wjKVZJTtKRBQYaQ;
    }

    return VDwqVd;
}

void BHPWlXKNigQhH::NnOMuOAABrRsb(int yaOEoUlOdE, int JYqBcuqnkAzN, int IKLEjFpnmGA)
{
    double IALeXVbVGr = -453220.719132035;
    int atQfL = -2031591729;
    double MaNLLCeQAvCOM = -618856.4338013146;
    bool ebShCvi = true;
    double WuuZaS = 388490.78549136117;
    bool rjSwNaOyFK = false;

    if (IKLEjFpnmGA <= -2070666011) {
        for (int jelcEJ = 2107207685; jelcEJ > 0; jelcEJ--) {
            ebShCvi = rjSwNaOyFK;
        }
    }

    for (int ZPmhBSLOFULgTpcz = 250776405; ZPmhBSLOFULgTpcz > 0; ZPmhBSLOFULgTpcz--) {
        continue;
    }

    for (int KrZEaLPA = 1122439477; KrZEaLPA > 0; KrZEaLPA--) {
        yaOEoUlOdE *= yaOEoUlOdE;
        rjSwNaOyFK = ! rjSwNaOyFK;
    }

    for (int nXpxUIglfiFLNm = 1912006512; nXpxUIglfiFLNm > 0; nXpxUIglfiFLNm--) {
        rjSwNaOyFK = ! rjSwNaOyFK;
    }

    for (int VFYDoy = 854484480; VFYDoy > 0; VFYDoy--) {
        IKLEjFpnmGA += JYqBcuqnkAzN;
        ebShCvi = rjSwNaOyFK;
        IKLEjFpnmGA /= atQfL;
        yaOEoUlOdE *= yaOEoUlOdE;
    }
}

int BHPWlXKNigQhH::chtRo()
{
    double LNPyOorKj = 227433.6009030012;
    string AopeaTIQTTUfObbr = string("oiOjntzasI");
    bool HNMtaJOzIBeGHHU = true;
    double NalELUoLSUEdmeTu = -3786.0845239055047;
    double slfAcHDwTKMS = -412332.68447715783;
    string pGchiaHAUxNvIV = string("SQXcxpHfXTKJXMjGyYARNWppEtMDbiwieIIkUDluSNTEwFDJGFqDYxvKtEonmvUJybkolNeWPSGBcUEXObbxMIdATNVDeJaYnhDWupgWHFlVbxQJgmiMtaJXSbqRKPSZSSPDBhZKHTEIJmLdYdFbSPfqbIvvnGwuTtprDTLKBzFxAYWNOyyUfLwcfBkWxQOQIhwHzjJRFqHDGSeBzRIXorKgCGavxJScvCZGEXBIUgFIhXlyFxZdSKFDGKio");

    return 901813736;
}

string BHPWlXKNigQhH::udzAPvtdgc(bool crMxsVyO)
{
    double iDtwEPPTBErnV = -33275.35122326366;

    return string("cAIEdDgeWXlBJnnPenZntIJMpyWgxlXhqxsNKiialrzkdTMWNYDgnEfLNPxcQEcmpNpdwlZiAZRBIABfxyEjbNeiwDfPoesxiVMgrWovAUKlOnjQezwVtBkKtDGsxpGVWbxD");
}

int BHPWlXKNigQhH::GZeHCyDTHzdCKeBD(int qGsGmmslFPdofc, string KiVddcC, string YMmwQQDxgVuk, bool ohbGIXqjl, double SZKuPR)
{
    bool yUAoHZtYc = false;

    if (yUAoHZtYc == false) {
        for (int OpjeKNjXdNWBs = 2095416091; OpjeKNjXdNWBs > 0; OpjeKNjXdNWBs--) {
            ohbGIXqjl = ! ohbGIXqjl;
        }
    }

    if (ohbGIXqjl != false) {
        for (int yjYzEpiostnvFAIb = 661882100; yjYzEpiostnvFAIb > 0; yjYzEpiostnvFAIb--) {
            ohbGIXqjl = ! yUAoHZtYc;
        }
    }

    if (yUAoHZtYc != false) {
        for (int lscSNsTOo = 449210006; lscSNsTOo > 0; lscSNsTOo--) {
            YMmwQQDxgVuk += YMmwQQDxgVuk;
            SZKuPR /= SZKuPR;
        }
    }

    return qGsGmmslFPdofc;
}

BHPWlXKNigQhH::BHPWlXKNigQhH()
{
    this->qvaCtRmTK(519449.61584224436);
    this->yryFoNMpyryv(-450008890, 661013416, -276992566, -633397072, -1383597431);
    this->TOmsBikkAVxoG(136788.18999308435, true, false);
    this->MzosKnesUqkm(70522923, 1971728922, -1433263127, string("ypeKgjDCzPQiDaqBcUiiIDCUMYpsxhYzUIZccpygdOHlPKdQheVdRLlFRPcJCkFSpEIJHsgZPqPtSoCkTTtZvenpwVogJpRPOhfKeymwRwTh"));
    this->PIhSSM(true);
    this->CQNqHbJIurrNjf(true, string("kHsDcwgCyzSnPfKMdkFAsRYDeSyFJaYccPpNcYhbQDjacpOeWsNLDUtdhDdUuoaaJHqCdbhRtOqNxWiyhMxXhUdQLViTNFLlTzyUxRYqaJyNPdcNOMgWBjbUywMWcvSoBoOlonbFNEvGuhJeUUikenNSCvVgOdeKWgMMqGIbNOxloleuWHtwDbZQFfrjjpzmWxvWBuWjNOBSPe"), false, 256867.74086430814);
    this->DiTKQHoUJodfa();
    this->NnOMuOAABrRsb(-2070666011, 915323206, 867481349);
    this->chtRo();
    this->udzAPvtdgc(true);
    this->GZeHCyDTHzdCKeBD(204652707, string("geVfdiqoZjRexXodfajUMUnLmnxayYWpNGMhZSWnlhMBMVvepVluIUldftGCYyKFTzwqhYGumyURUHdKnv"), string("atydniMGaaMeKKsEyMlLLsmvKhqnnXdylwjSNYLMYzQzOPaRpXLVVGGqawHjwABJrHSPGsjpLwpeavWLfENSxUTxkIedKVTGzYRUkOLdIxlEHJdyOBdWlhRtqjvFPnseCpLbFhkfzKXzdbTqHMAlftKpHdGGgKUFGkuPVHwZbnXIJQmIGEErS"), false, -467003.2602569129);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GheGjNgzVyqKCdww
{
public:
    int VjdqEUDBT;
    double YogOCZSpoNdn;
    double kYsGMQAOy;
    string NDCKno;

    GheGjNgzVyqKCdww();
    double hjOZRGqn(bool aeogCMeWsg);
    bool BeQMexgJXWBAlRNH(double IuBvV, int laFEjBM);
    double TbVtgAOPKBi(int zAwpGr, string RDQOPfx, string bzVzwH, int TfsMtoHSqsI, string emhPsStCtQeArLT);
protected:
    double LFOtezkImrRfdeEc;
    int GezVykD;
    double fSYAK;

    double JJBZCBwwNnuJJZA(string KgSlpcXmmCAKP, string gOiGgWKXPUCJBcr, int ToWRy, bool oWrrHYuu, string rBAKGecjsPzGMF);
private:
    string JZEWMFLr;
    double ACiPXJrvDuCY;
    bool LrLif;
    int VQXqvmC;
    string TgbvOCkRUgqb;

    bool sxYRAY(string qsQxNG, string VaizIXSi, string rTKdayv, string AWsJmq, bool zyvpKJBjriFffxa);
    bool xDJuFef();
    int GGUeeB(string MmZfrbddhVktq);
    void rQDvXtaYue(bool FukPDrCHSXYq, int cftxsQIPVzBVMfzC);
    bool RRQpwUpxZLTK(string cdusTVZYShl, string nePhVb, string fcJtaxj);
    string orVICECZh(string ueXtVdphN, string bmTooPyaMkALWK, string FUlHQ, bool AmJfTyaXb);
};

double GheGjNgzVyqKCdww::hjOZRGqn(bool aeogCMeWsg)
{
    bool bfWkzxgQ = true;
    int AUchCM = 1322579241;
    int pNWwXj = 313382305;

    for (int OuyRrTH = 637007085; OuyRrTH > 0; OuyRrTH--) {
        AUchCM += pNWwXj;
    }

    if (AUchCM <= 1322579241) {
        for (int fUdJDMvqs = 1804201300; fUdJDMvqs > 0; fUdJDMvqs--) {
            bfWkzxgQ = ! aeogCMeWsg;
            AUchCM *= pNWwXj;
            aeogCMeWsg = aeogCMeWsg;
        }
    }

    if (aeogCMeWsg == true) {
        for (int TpXNpAawkZzzQiof = 1623432900; TpXNpAawkZzzQiof > 0; TpXNpAawkZzzQiof--) {
            pNWwXj /= AUchCM;
            pNWwXj *= AUchCM;
        }
    }

    return 343778.63146225223;
}

bool GheGjNgzVyqKCdww::BeQMexgJXWBAlRNH(double IuBvV, int laFEjBM)
{
    int VNwVtsMnh = -1572414543;
    string cSYHheuhwjOQWqu = string("pBNezhUgmIRNGxsKybtbHKAlFWNVjW");
    string gUQuSvdbHNKP = string("DIpLtsPpzMOgZvNokvIGaIJdnEwJOvanGXFgfNtOaacJqmEuAoIdxxKsSVKtmNQrpquOOpyrhjzobhYBMmEChdoOIfqJAgezqjbZLQbRgbxHSrNNZlHMOYLSRzkLXnbwzFLNmmVenVHqSPYXQwISYhWQNdYEoigERtSOltSkIcgPSFtAtjaojYEHJsKosRhwnxX");
    double rdsTqIqRWmNCZru = -194106.92329819716;
    string rhPkqgPfqf = string("QRgTAddEekGlpZfnJjUmbUkTEHaavSOwfGxXnEuMSCCQDSdXpOkOZAAlJVXiFlinXzJgnUpGcVQIGvtdNIxILmgqQnaQloqNQESjURZVWAXUdHCXXlukUUTGoftqATRcnkHGswDcSASopSZVnJWzqODdpCsLlrMkkuxQhooCQdsvSusfjEbeviKbNAXgAssLCamrWRjsTgcjCRhOzlvRWEUtsiGCgwZdnfzpkoDtilxXEuWty");
    double uBkpGBML = 138620.9417326018;
    bool MnxbJgg = false;
    double VaDzI = 733112.704106885;

    for (int oROrtWIU = 1793215955; oROrtWIU > 0; oROrtWIU--) {
        rdsTqIqRWmNCZru *= IuBvV;
    }

    return MnxbJgg;
}

double GheGjNgzVyqKCdww::TbVtgAOPKBi(int zAwpGr, string RDQOPfx, string bzVzwH, int TfsMtoHSqsI, string emhPsStCtQeArLT)
{
    bool MSBhPIbC = false;
    bool wUcoREyEFJmPmKix = false;
    double IxoFWczMntf = 533541.6459465758;
    string Qfvkt = string("TPwODxXyrtsdnUB");
    string vOkxhLmpck = string("mTcJXZjVvBEZLfoSETjLyCvDzSdexEQSJVhrnttoYdtsUWktoBlGyZOTTLmbPlXcMSqjSLqWGjqkxPIWuCrpkcCCFdEZEOKVTfuVHdjlycUmamwCJUkORgMZcSPFJDRWTuJlaYawKOYxUKumUmgPVYdusXXIzPIqsbdT");
    string hqnIcbhTkxRHqYO = string("FICwoFIqlEmfsiRChGbYcVggaygFWcwXsLCAmORJHOIIHTeEMWIhMyTcTDgtfOMZxWAOniPFxPDVuVmVuqckehJcrQBcUMdefsqLLpfZSWsRzvWFaqBeJzkQhkShGdIaescpemHNausciMEMLAdeWUzoRsNwZmVmwqjcqcLGuxDMMHxRXVTQnTSDJnOS");
    double iKJuuHmX = 753815.6226536852;

    for (int Scelp = 786316860; Scelp > 0; Scelp--) {
        iKJuuHmX *= IxoFWczMntf;
        wUcoREyEFJmPmKix = ! MSBhPIbC;
    }

    if (Qfvkt == string("mTcJXZjVvBEZLfoSETjLyCvDzSdexEQSJVhrnttoYdtsUWktoBlGyZOTTLmbPlXcMSqjSLqWGjqkxPIWuCrpkcCCFdEZEOKVTfuVHdjlycUmamwCJUkORgMZcSPFJDRWTuJlaYawKOYxUKumUmgPVYdusXXIzPIqsbdT")) {
        for (int orOHZPUA = 1104877343; orOHZPUA > 0; orOHZPUA--) {
            TfsMtoHSqsI += TfsMtoHSqsI;
            TfsMtoHSqsI -= TfsMtoHSqsI;
        }
    }

    if (bzVzwH < string("fFxSjIIbBTWkMthKgRXeFwdksQLiwLWvEFqpNOKsuoeDNXxHaVcwQKiHVJXDEYMzwWnmGGbZYEdfvOfNKBxhbsYrCd")) {
        for (int rJmRZXoWjV = 92385432; rJmRZXoWjV > 0; rJmRZXoWjV--) {
            bzVzwH = bzVzwH;
            emhPsStCtQeArLT += Qfvkt;
        }
    }

    return iKJuuHmX;
}

double GheGjNgzVyqKCdww::JJBZCBwwNnuJJZA(string KgSlpcXmmCAKP, string gOiGgWKXPUCJBcr, int ToWRy, bool oWrrHYuu, string rBAKGecjsPzGMF)
{
    double KVeXN = 1034348.9227422369;
    int aHhpNtIxcYntGpVo = 2136167909;
    int FTGDLoyjpAGdj = 1107275766;

    for (int CmRgGTgxkxSWnd = 1232155485; CmRgGTgxkxSWnd > 0; CmRgGTgxkxSWnd--) {
        KgSlpcXmmCAKP += gOiGgWKXPUCJBcr;
        rBAKGecjsPzGMF += gOiGgWKXPUCJBcr;
    }

    if (ToWRy != 1107275766) {
        for (int oVrVCwY = 1034060585; oVrVCwY > 0; oVrVCwY--) {
            aHhpNtIxcYntGpVo *= aHhpNtIxcYntGpVo;
            aHhpNtIxcYntGpVo -= aHhpNtIxcYntGpVo;
        }
    }

    for (int VrIuiQIJhmg = 1097100423; VrIuiQIJhmg > 0; VrIuiQIJhmg--) {
        FTGDLoyjpAGdj -= aHhpNtIxcYntGpVo;
        KVeXN /= KVeXN;
    }

    for (int IiouECvjQ = 193730050; IiouECvjQ > 0; IiouECvjQ--) {
        ToWRy /= ToWRy;
        KVeXN -= KVeXN;
    }

    return KVeXN;
}

bool GheGjNgzVyqKCdww::sxYRAY(string qsQxNG, string VaizIXSi, string rTKdayv, string AWsJmq, bool zyvpKJBjriFffxa)
{
    int HrHjEBoaO = 1941460777;
    string OylXK = string("FFEtITFJQRpxokcwmFkORdJakgLSwAGJvCxhtXUPkyYTWeVzDOcwupvXAKfObwuOUTHGBkbwyUCdiToLWqtkiNNqPKeZcpVhnJHExcfMQlRWgkyKiZoRylldTNbkKrtAuZALymHepTNrrMCKdSYwdaOOIvUNYWoRsxgReprOZvxdiiSTaJxpXoIBvMXJPXeWBbvYpMdFJLrLNDKEDKhbcTWKUfrDQgWsUAXfCMVbHzdwoLgBaxrC");
    bool ltqCgwYt = true;
    bool lUFpmTAJ = false;
    bool CRgNvCDCJhthAaf = false;
    int UGzvPrDUCkvDVAl = -1741113523;

    for (int LusjfQN = 340459868; LusjfQN > 0; LusjfQN--) {
        zyvpKJBjriFffxa = lUFpmTAJ;
        zyvpKJBjriFffxa = ! ltqCgwYt;
    }

    for (int dIRnuJNRywjxmOK = 1382330351; dIRnuJNRywjxmOK > 0; dIRnuJNRywjxmOK--) {
        OylXK += rTKdayv;
        VaizIXSi += VaizIXSi;
    }

    if (AWsJmq < string("WkhrCYvLzJTkxoFYESJwLuyXTnUkQVaBSYyhEqUKpSHQVkexGrFvGtgZFWIyRQIoGMcyfVhPdnDTuoPppNSOAsMHtMZovTsNETcNVHeotSPKAjfFKNrbnhVGVGetGGxaDwlOOJlHUsu")) {
        for (int GkeMa = 1741292005; GkeMa > 0; GkeMa--) {
            lUFpmTAJ = ! ltqCgwYt;
            OylXK = qsQxNG;
            AWsJmq = qsQxNG;
            ltqCgwYt = ! ltqCgwYt;
        }
    }

    for (int hsDlIZMJJpWzxZLU = 853743836; hsDlIZMJJpWzxZLU > 0; hsDlIZMJJpWzxZLU--) {
        OylXK += VaizIXSi;
        AWsJmq += rTKdayv;
        HrHjEBoaO *= UGzvPrDUCkvDVAl;
    }

    return CRgNvCDCJhthAaf;
}

bool GheGjNgzVyqKCdww::xDJuFef()
{
    double uWYpOGbgwxEKXWS = -152369.5285387857;
    double vDGWhUIdXiUVoapl = -1021768.4717230246;
    double rFJrXBBXTEb = -547429.5345670929;

    if (rFJrXBBXTEb != -1021768.4717230246) {
        for (int hStaNoqtPiLevHs = 1587550563; hStaNoqtPiLevHs > 0; hStaNoqtPiLevHs--) {
            vDGWhUIdXiUVoapl = vDGWhUIdXiUVoapl;
            rFJrXBBXTEb /= vDGWhUIdXiUVoapl;
            vDGWhUIdXiUVoapl -= vDGWhUIdXiUVoapl;
            rFJrXBBXTEb += rFJrXBBXTEb;
            rFJrXBBXTEb = rFJrXBBXTEb;
            vDGWhUIdXiUVoapl /= uWYpOGbgwxEKXWS;
        }
    }

    if (rFJrXBBXTEb < -547429.5345670929) {
        for (int ZIuRiWQRQ = 1661679231; ZIuRiWQRQ > 0; ZIuRiWQRQ--) {
            rFJrXBBXTEb *= uWYpOGbgwxEKXWS;
            vDGWhUIdXiUVoapl *= vDGWhUIdXiUVoapl;
            vDGWhUIdXiUVoapl *= vDGWhUIdXiUVoapl;
            uWYpOGbgwxEKXWS = vDGWhUIdXiUVoapl;
            rFJrXBBXTEb *= uWYpOGbgwxEKXWS;
            vDGWhUIdXiUVoapl += uWYpOGbgwxEKXWS;
            vDGWhUIdXiUVoapl /= vDGWhUIdXiUVoapl;
            uWYpOGbgwxEKXWS /= uWYpOGbgwxEKXWS;
            rFJrXBBXTEb *= uWYpOGbgwxEKXWS;
        }
    }

    if (rFJrXBBXTEb >= -152369.5285387857) {
        for (int HFcoZRXAdI = 1687716798; HFcoZRXAdI > 0; HFcoZRXAdI--) {
            uWYpOGbgwxEKXWS += uWYpOGbgwxEKXWS;
            rFJrXBBXTEb = rFJrXBBXTEb;
            rFJrXBBXTEb /= vDGWhUIdXiUVoapl;
            rFJrXBBXTEb = vDGWhUIdXiUVoapl;
        }
    }

    if (uWYpOGbgwxEKXWS <= -1021768.4717230246) {
        for (int yNfeLoEoNmaGoOC = 1132355352; yNfeLoEoNmaGoOC > 0; yNfeLoEoNmaGoOC--) {
            vDGWhUIdXiUVoapl *= uWYpOGbgwxEKXWS;
        }
    }

    if (vDGWhUIdXiUVoapl < -1021768.4717230246) {
        for (int OxpsvApBYHgttJ = 788440893; OxpsvApBYHgttJ > 0; OxpsvApBYHgttJ--) {
            vDGWhUIdXiUVoapl -= uWYpOGbgwxEKXWS;
            rFJrXBBXTEb /= uWYpOGbgwxEKXWS;
            vDGWhUIdXiUVoapl = rFJrXBBXTEb;
            rFJrXBBXTEb = uWYpOGbgwxEKXWS;
        }
    }

    if (vDGWhUIdXiUVoapl <= -1021768.4717230246) {
        for (int sNGeqVmfSkMcMnGL = 2127038130; sNGeqVmfSkMcMnGL > 0; sNGeqVmfSkMcMnGL--) {
            vDGWhUIdXiUVoapl *= uWYpOGbgwxEKXWS;
            uWYpOGbgwxEKXWS /= uWYpOGbgwxEKXWS;
            rFJrXBBXTEb *= uWYpOGbgwxEKXWS;
            uWYpOGbgwxEKXWS *= uWYpOGbgwxEKXWS;
            rFJrXBBXTEb += rFJrXBBXTEb;
            rFJrXBBXTEb *= vDGWhUIdXiUVoapl;
            uWYpOGbgwxEKXWS = uWYpOGbgwxEKXWS;
            rFJrXBBXTEb += vDGWhUIdXiUVoapl;
        }
    }

    return true;
}

int GheGjNgzVyqKCdww::GGUeeB(string MmZfrbddhVktq)
{
    bool vnkZpbcGMl = true;
    double rTWveweURJY = -5988.089389972689;
    double fBIEe = -188210.24229291585;

    if (rTWveweURJY > -188210.24229291585) {
        for (int hbnXBb = 703250134; hbnXBb > 0; hbnXBb--) {
            fBIEe -= fBIEe;
        }
    }

    if (fBIEe <= -5988.089389972689) {
        for (int dICihTgvhZZ = 1076446336; dICihTgvhZZ > 0; dICihTgvhZZ--) {
            MmZfrbddhVktq = MmZfrbddhVktq;
            rTWveweURJY /= fBIEe;
        }
    }

    return 1705433095;
}

void GheGjNgzVyqKCdww::rQDvXtaYue(bool FukPDrCHSXYq, int cftxsQIPVzBVMfzC)
{
    bool lnIfHcIYMhQk = true;

    if (FukPDrCHSXYq != true) {
        for (int kjyOKjNTGU = 806344121; kjyOKjNTGU > 0; kjyOKjNTGU--) {
            lnIfHcIYMhQk = ! lnIfHcIYMhQk;
            lnIfHcIYMhQk = ! FukPDrCHSXYq;
            lnIfHcIYMhQk = FukPDrCHSXYq;
        }
    }

    for (int Jylubsr = 1710737926; Jylubsr > 0; Jylubsr--) {
        FukPDrCHSXYq = ! FukPDrCHSXYq;
    }

    if (lnIfHcIYMhQk == true) {
        for (int PlQSdupTQVn = 1261553389; PlQSdupTQVn > 0; PlQSdupTQVn--) {
            continue;
        }
    }

    for (int VMWKpVSKYKAUaH = 159743566; VMWKpVSKYKAUaH > 0; VMWKpVSKYKAUaH--) {
        FukPDrCHSXYq = ! FukPDrCHSXYq;
        lnIfHcIYMhQk = lnIfHcIYMhQk;
    }

    if (FukPDrCHSXYq == true) {
        for (int VmdgWfPnZyYsHx = 134004016; VmdgWfPnZyYsHx > 0; VmdgWfPnZyYsHx--) {
            cftxsQIPVzBVMfzC /= cftxsQIPVzBVMfzC;
            FukPDrCHSXYq = lnIfHcIYMhQk;
        }
    }

    if (FukPDrCHSXYq == true) {
        for (int eYyLcfg = 878333716; eYyLcfg > 0; eYyLcfg--) {
            lnIfHcIYMhQk = ! lnIfHcIYMhQk;
            lnIfHcIYMhQk = FukPDrCHSXYq;
            FukPDrCHSXYq = ! lnIfHcIYMhQk;
        }
    }
}

bool GheGjNgzVyqKCdww::RRQpwUpxZLTK(string cdusTVZYShl, string nePhVb, string fcJtaxj)
{
    string KZlamRO = string("djCxndObkDJCyjiYftENMeoKgZAcMoAyOgGnNWDETxwjBZEPvBOGDmVMEEaFdhvzGhtmqctDFLLVGefHROBwXQEpHTCYgHFiaJjqbiYcjeLwRonnSxxdKVMPQDkQiiPmuehtNeWiOctogXiwWdJVIVVKZwUVIIOyUlErWoDsFzXzupveudhiwVxqv");
    double AxjsarmZRsPUa = -137394.1638416908;
    int kKYTriw = 2054947362;
    bool HdAHJU = true;
    bool qvzaVRkmeEM = true;
    string dSOeaX = string("eOdJNHWiXWYlkJIASAgx");
    int QmFCqyQeLGGqGiRU = 2706681;
    string ZRszgamgjh = string("EGKsGKaQXruIOfbxkipDtOMcpuDloFJfNjMuWpoAEUIeohZTQjaoqHJlCVdYSBBGDuKkTRQuYvuyoxWjOrPiimiAOaTmxDyLtTOgIUTlfGkkqenhelLXHrISuXZUnciOlzQXkwMibWiFFx");

    for (int lVBPNtXVDzTRCwd = 150955770; lVBPNtXVDzTRCwd > 0; lVBPNtXVDzTRCwd--) {
        QmFCqyQeLGGqGiRU /= kKYTriw;
        nePhVb = fcJtaxj;
        dSOeaX += fcJtaxj;
    }

    return qvzaVRkmeEM;
}

string GheGjNgzVyqKCdww::orVICECZh(string ueXtVdphN, string bmTooPyaMkALWK, string FUlHQ, bool AmJfTyaXb)
{
    int gTKYMmFxoplSp = -2026348000;
    bool AiejvAC = false;
    double ZgbCrOjFsNredE = 222280.13085241496;
    bool OFxvRRQxRjLclie = true;
    int gUyWPWszWkmtPPwJ = 1072896298;
    double yFoPWaEZiJo = 1030073.6630921479;

    for (int mBmKrCCAorNvyEuX = 938753817; mBmKrCCAorNvyEuX > 0; mBmKrCCAorNvyEuX--) {
        continue;
    }

    for (int EptvWJAHaorOER = 1538475292; EptvWJAHaorOER > 0; EptvWJAHaorOER--) {
        OFxvRRQxRjLclie = ! OFxvRRQxRjLclie;
        gTKYMmFxoplSp -= gUyWPWszWkmtPPwJ;
    }

    return FUlHQ;
}

GheGjNgzVyqKCdww::GheGjNgzVyqKCdww()
{
    this->hjOZRGqn(true);
    this->BeQMexgJXWBAlRNH(-6253.767907185198, -577803100);
    this->TbVtgAOPKBi(1348578960, string("lCFZHYeYvYDsUUOSSUWGowOWdiwbqUbSHJOVrICIEbMUcmokmGLttBuRHmTf"), string("fFxSjIIbBTWkMthKgRXeFwdksQLiwLWvEFqpNOKsuoeDNXxHaVcwQKiHVJXDEYMzwWnmGGbZYEdfvOfNKBxhbsYrCd"), -372871811, string("mUpOUzDbpnXLEgSjmQswSUdCeFMvhWMXgBAsXNnGkQqfHmorFWcMsRHIrNmAhPImIbBPemtfXroSoFDzbpAwMMafgGdxXcHz"));
    this->JJBZCBwwNnuJJZA(string("lwOsmYzPCQoeSLIMkwCxOECgiCpVfOvoUJSMhUYYAQMueeRbVIXnElNXfVpIgtAvoYHrmBRBgwugTTxEAJDOvsZNxORhZqpnPiDXirdDSfhtvhjhjLCXwYtqOwpiYloqNPkAdmZdddgnLdXlOyb"), string("ubCumXZYftMkSuMiVhpdJqCcuYrpMNZrVaWGqEFPkQScCRFxIXDIeCjGSEsVOCCpveghUgklbBIGDXThIGPQKoeFlIoBvaAV"), -17919621, true, string("KAEOnfxjhjjedtGfbnPHgzRASpHXwhlSbtIMGSwTMpqQfUVjBWYXEscOkpArkyyaZhBtiKdIOERHIEbNJcgHbtrmzHRrlSVZrYLBOXhxJ"));
    this->sxYRAY(string("pcvNLrdfQOmSoEMmGXkLkJWwHumuhcCyHJZzgAyoTdZjoAWYwjYleCqpRtHcRozAceHFCuDTKsyAXVCwystyPcDrjrZbHEivzFdZbIoREIScTaJxupdjUDeRjKSKsTgSoJGrvR"), string("hBARbrWaeRsWTfllMBbZOJIeaKDjSghsbWVFZLxjLPgiZeKwNrdlViqsINwIdjiJzQzqVsdLFrdpotRYseKNEtAVTfSZwsedWKukfTlHlAUcmTgOtVNXCwNstKgtvmyUgNhcFusWwRfEMjcYGfdFXYckAY"), string("TpIcjqQLxjPctNYeNLXfbvknaovleAtyNuoKqAtolWgutNivYPOYMIJoLVkEsfO"), string("WkhrCYvLzJTkxoFYESJwLuyXTnUkQVaBSYyhEqUKpSHQVkexGrFvGtgZFWIyRQIoGMcyfVhPdnDTuoPppNSOAsMHtMZovTsNETcNVHeotSPKAjfFKNrbnhVGVGetGGxaDwlOOJlHUsu"), false);
    this->xDJuFef();
    this->GGUeeB(string("HDAmwtBSggvgEMGxsnFxzzIyfgxwVgZmnRQVhEAYOMnCcToZTMVXTgmmQgYqKMtHkHCeBHTMYEBwFBjqPmxkIGxzuKeHFocGcOdQEivbZccsBNXKhpZOYuoobukhblKsQswUzujtGJFCuQpoxtvbgHqxutiKsFkuSqHmpKGMfglOsXJqmrqmAwXGInlsZeYSkzidgoxXfwBmIsWOmbBzzhKIuyflh"));
    this->rQDvXtaYue(true, -76862587);
    this->RRQpwUpxZLTK(string("QuObNWrbaCwfpiGQVmKXmWcDtRVnraOcSKUvQgymoNhbiUcATOTriHIptSIConDUZgZQePzLdkSNGheqkGUGWctfPbjwSeWMCDApBVKbrBwGAhmtkBaraapFEtbhDKtXMjdzoVYmvPOtsGgRJdYjLsIShAgJjarVKtxRe"), string("oXrAedWZNxSGXkwFTRUpfuAprpIMgJoeRJjCtlOqNkRwWVeFwlHumzIuOrPmqIsjyLwxtzTUYHSxmZWsEayCJtOiJAnxtwgBniFkhCpJyEkJXbydXruiqoweNONBlCIjytdsdSXhPLoImWCMXaouQRrbpgBtzQuQokJCGLrIqHNzLpeZHUYImXwPLbnDvnjnJUrnnIubXi"), string("kNevKDSkZXxXEOzVNIJDCGdSODNykvLjuvVkKvIXgZqNvAWTvYFHrzcCQvqRhmv"));
    this->orVICECZh(string("leniiFsmmWxDbtnQnHuUZIivDmDfNNzzhOzlcKQwICbsITGolKxUSDjUfxylrbzwshNpqasytMzwCSNumgFQjxWygbPGTSkZdAPiquLKBFJCRBJnMXWbdmxkRrVEXndtotmYagPjenaGKZTmwtejchbKxtO"), string("EngRlpBhMuKoQwAmDvS"), string("ggJgvnoUYucUhBlxVQEUhPYQUAddLcDRQyJydHmupQIZcBBtEluPrIlIWEGuKvoOKEFxIzvJuNCbSOklWfLxZSdyozUXOCCpfIHZvjJdBopSykdGNAzyOcQVMqgjvUSJsHCwVYvkEYmWkCpNmvqukVpWHGYbHvZcLHDLHShimqIcGobLLRVfEhzDjBdVpuiHYogNgQriabLwKrchFijTIhtVxXHCKCwlkQXBQcjSuLGAH"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DIddlxGWqJ
{
public:
    int OILRUHrzZakz;

    DIddlxGWqJ();
    bool WzJPKUXI(double wlfkKejtPxWqnmbX, double BEJrdVROp, int xJOdKXeRhkGu, double CpeNn);
    int JLgMXnPjVfwOsuU();
    string kfgoJDRMpEAQkHY(bool PLSelMsaDrKrICNu, int eBHVxPMHsl, int OoTCSjOEhH, int FDrXQlGlGcY, double lVvdOiAhGlykkg);
protected:
    string aUbslXRevaak;
    int kpNZSmXVoMdk;
    string EKwCnP;
    bool GsQyLQguFulfvP;
    double MbXOvAZ;

    double DpiyaagSGBfNBg(double NobgpycUVLnbv);
    string gpNGgany(string xNwTqlWyfNz, string FiYjgeWNT, string QpvKc, bool DkhtfBl);
    double SSSVBOCi(int GWBtDKqJtDZihVa, double wvlhahJBojjRF, int fKzWQYcHeBnfIt, string SezbdUjuGukWPmtP);
    double PSzFCAIsyOOixjSn(double KLvaSAcPG, bool fZigo, bool QFJrZUJJfVeOi, int lZGKmJJCewfym, string pnJWrsywKwcNZTPg);
    bool JvMYpWjaOH(double xddoKVCczaJD);
    bool yBXjwxxCdaAwYA(string DvxpDNZ);
    bool ZNGoKFUYqUQOmGN(double GrXOWNvRdatTWc, int oIBpLPlsMjoRKn, bool WDwsPvJZMRdrPK, int KeoVdTaim, double qfRHv);
private:
    double mtADP;

    int yDsUPuLgu(bool SpdNJlgJG, bool dRTeyz);
    string IRKqsW(int gALlYcFwmBV, int wbzxuGJDz, int zjDvpW);
    bool qVTSRHu(string weVkPTist, double iLtzfDSsDNCnnk, bool WDUGMBHGaeI);
    void XPCeLdFFRV(string yifBU, int QuUcbYvV, int CjmXxGDIIFZ, double CdcIQqmDfHpRKH);
};

bool DIddlxGWqJ::WzJPKUXI(double wlfkKejtPxWqnmbX, double BEJrdVROp, int xJOdKXeRhkGu, double CpeNn)
{
    string wHMRd = string("WjPCWQbWzKlIoBXuKicbXEmsNyRirsTLKqnWBNTTdwzMfMiABBlmTxSNCzdUIUizGhgSgkiN");

    if (wHMRd == string("WjPCWQbWzKlIoBXuKicbXEmsNyRirsTLKqnWBNTTdwzMfMiABBlmTxSNCzdUIUizGhgSgkiN")) {
        for (int NDRPZiav = 1666273254; NDRPZiav > 0; NDRPZiav--) {
            BEJrdVROp *= BEJrdVROp;
        }
    }

    return true;
}

int DIddlxGWqJ::JLgMXnPjVfwOsuU()
{
    bool NaRbX = false;
    double rfnOMQxGAmkqw = 520282.8616139916;
    int EEStPXygttYQH = 996578622;
    bool hDuxCrmqby = true;
    int SivDIeH = 2036585262;
    string siTiPq = string("asQWLZYbSeNAcUqtmtubirLyaSIrLrbpHcNxZdnVRfNovJzZNuzLtYePtVJXpfXmkeHBHdXnxeqDEfQJvCnPlwxWIVyymLnHfULOZitKacKXfLPSPalFVgvanlierbtSDLeUMSLudsRTohgXBMsoxwfXVRkvjEIJIMJBLWjFJRynEWhUaPEkpZTCLKZfPfpSqAQpJadOcXRPFawhWzwllaFyWSebmfKKbHc");

    if (NaRbX == false) {
        for (int YLqzPmaSI = 2028644549; YLqzPmaSI > 0; YLqzPmaSI--) {
            continue;
        }
    }

    if (EEStPXygttYQH == 2036585262) {
        for (int duWITZ = 2043456284; duWITZ > 0; duWITZ--) {
            continue;
        }
    }

    for (int laiAxQ = 1358756455; laiAxQ > 0; laiAxQ--) {
        continue;
    }

    return SivDIeH;
}

string DIddlxGWqJ::kfgoJDRMpEAQkHY(bool PLSelMsaDrKrICNu, int eBHVxPMHsl, int OoTCSjOEhH, int FDrXQlGlGcY, double lVvdOiAhGlykkg)
{
    int cjJiwTDsf = 2001946197;
    bool oyxvsfvAfEg = false;
    double gRaDebxyfvZnwh = 550164.3333459586;
    int zBkKPUOBl = 958826169;

    for (int IxFbgVRuVkshLh = 456946079; IxFbgVRuVkshLh > 0; IxFbgVRuVkshLh--) {
        cjJiwTDsf /= cjJiwTDsf;
        PLSelMsaDrKrICNu = ! oyxvsfvAfEg;
        eBHVxPMHsl = zBkKPUOBl;
        cjJiwTDsf += eBHVxPMHsl;
    }

    if (FDrXQlGlGcY <= 958826169) {
        for (int kWJgKEPj = 223101976; kWJgKEPj > 0; kWJgKEPj--) {
            eBHVxPMHsl /= zBkKPUOBl;
            OoTCSjOEhH -= zBkKPUOBl;
            OoTCSjOEhH /= zBkKPUOBl;
            FDrXQlGlGcY = zBkKPUOBl;
        }
    }

    for (int bRaLYkuZZN = 1725238875; bRaLYkuZZN > 0; bRaLYkuZZN--) {
        OoTCSjOEhH += OoTCSjOEhH;
    }

    return string("jyrup");
}

double DIddlxGWqJ::DpiyaagSGBfNBg(double NobgpycUVLnbv)
{
    bool xpNrvArSgVb = false;

    for (int xsLktoQhg = 1406885738; xsLktoQhg > 0; xsLktoQhg--) {
        xpNrvArSgVb = xpNrvArSgVb;
    }

    if (xpNrvArSgVb != false) {
        for (int JQmnjcsI = 504529471; JQmnjcsI > 0; JQmnjcsI--) {
            xpNrvArSgVb = xpNrvArSgVb;
            xpNrvArSgVb = xpNrvArSgVb;
            NobgpycUVLnbv -= NobgpycUVLnbv;
            xpNrvArSgVb = xpNrvArSgVb;
            NobgpycUVLnbv = NobgpycUVLnbv;
            NobgpycUVLnbv -= NobgpycUVLnbv;
        }
    }

    for (int PEPZWdra = 497067677; PEPZWdra > 0; PEPZWdra--) {
        xpNrvArSgVb = ! xpNrvArSgVb;
        xpNrvArSgVb = ! xpNrvArSgVb;
    }

    for (int pKOPB = 1213805790; pKOPB > 0; pKOPB--) {
        NobgpycUVLnbv *= NobgpycUVLnbv;
        NobgpycUVLnbv += NobgpycUVLnbv;
        xpNrvArSgVb = ! xpNrvArSgVb;
        NobgpycUVLnbv += NobgpycUVLnbv;
    }

    if (xpNrvArSgVb == false) {
        for (int rVBTMxlraxD = 1606625612; rVBTMxlraxD > 0; rVBTMxlraxD--) {
            NobgpycUVLnbv -= NobgpycUVLnbv;
            NobgpycUVLnbv /= NobgpycUVLnbv;
            xpNrvArSgVb = xpNrvArSgVb;
            NobgpycUVLnbv *= NobgpycUVLnbv;
            xpNrvArSgVb = ! xpNrvArSgVb;
        }
    }

    return NobgpycUVLnbv;
}

string DIddlxGWqJ::gpNGgany(string xNwTqlWyfNz, string FiYjgeWNT, string QpvKc, bool DkhtfBl)
{
    bool hAXDU = false;
    bool GOkPEKMy = false;
    double EWgsp = -155229.6280629522;
    int VStuPy = 1390899369;

    if (DkhtfBl != false) {
        for (int KtChjxQSavvIj = 1384381253; KtChjxQSavvIj > 0; KtChjxQSavvIj--) {
            continue;
        }
    }

    for (int yDySLuaMH = 1940293258; yDySLuaMH > 0; yDySLuaMH--) {
        QpvKc += QpvKc;
        QpvKc += FiYjgeWNT;
    }

    for (int IGoyMOqwQ = 618253218; IGoyMOqwQ > 0; IGoyMOqwQ--) {
        hAXDU = DkhtfBl;
    }

    for (int HcCGhVqqcrxPEeOP = 995382996; HcCGhVqqcrxPEeOP > 0; HcCGhVqqcrxPEeOP--) {
        EWgsp *= EWgsp;
        QpvKc = xNwTqlWyfNz;
        FiYjgeWNT += QpvKc;
    }

    for (int rLHfpNwcutYxoe = 433869127; rLHfpNwcutYxoe > 0; rLHfpNwcutYxoe--) {
        DkhtfBl = GOkPEKMy;
        FiYjgeWNT = QpvKc;
        DkhtfBl = ! hAXDU;
        VStuPy = VStuPy;
    }

    return QpvKc;
}

double DIddlxGWqJ::SSSVBOCi(int GWBtDKqJtDZihVa, double wvlhahJBojjRF, int fKzWQYcHeBnfIt, string SezbdUjuGukWPmtP)
{
    double WpDpDIT = -30537.37184053966;
    string SivYslXSX = string("wLWDumpyAVDoOHdTWIasEWilcTWUnjEqypDLuXTsnhBWQcwtFCwGlgYsyRFhoMVAROwuhydjoTNyHjCFvuBqqHenXGCPZEKLoKAlLVZTWCbUNRGVwacNdXASjuVScmNHQOsuPBzORgDqaLksBKXnrWnfOJUeANyHCgYGMIAKLfcojMfMznDYiGgPOrotpbkopGD");

    if (SezbdUjuGukWPmtP != string("wLWDumpyAVDoOHdTWIasEWilcTWUnjEqypDLuXTsnhBWQcwtFCwGlgYsyRFhoMVAROwuhydjoTNyHjCFvuBqqHenXGCPZEKLoKAlLVZTWCbUNRGVwacNdXASjuVScmNHQOsuPBzORgDqaLksBKXnrWnfOJUeANyHCgYGMIAKLfcojMfMznDYiGgPOrotpbkopGD")) {
        for (int NsRMhLci = 576964580; NsRMhLci > 0; NsRMhLci--) {
            wvlhahJBojjRF += WpDpDIT;
        }
    }

    for (int lghNa = 263207165; lghNa > 0; lghNa--) {
        WpDpDIT -= WpDpDIT;
        SivYslXSX += SivYslXSX;
        SezbdUjuGukWPmtP += SivYslXSX;
        GWBtDKqJtDZihVa -= GWBtDKqJtDZihVa;
    }

    if (wvlhahJBojjRF > -30537.37184053966) {
        for (int Tdziyyz = 1379622090; Tdziyyz > 0; Tdziyyz--) {
            wvlhahJBojjRF = wvlhahJBojjRF;
        }
    }

    if (wvlhahJBojjRF > -30537.37184053966) {
        for (int SfTnKkqvmyax = 995841171; SfTnKkqvmyax > 0; SfTnKkqvmyax--) {
            SivYslXSX = SivYslXSX;
            fKzWQYcHeBnfIt = fKzWQYcHeBnfIt;
            wvlhahJBojjRF -= wvlhahJBojjRF;
        }
    }

    if (SivYslXSX < string("wLWDumpyAVDoOHdTWIasEWilcTWUnjEqypDLuXTsnhBWQcwtFCwGlgYsyRFhoMVAROwuhydjoTNyHjCFvuBqqHenXGCPZEKLoKAlLVZTWCbUNRGVwacNdXASjuVScmNHQOsuPBzORgDqaLksBKXnrWnfOJUeANyHCgYGMIAKLfcojMfMznDYiGgPOrotpbkopGD")) {
        for (int dXBgLprQFSAMZESx = 322371059; dXBgLprQFSAMZESx > 0; dXBgLprQFSAMZESx--) {
            WpDpDIT /= WpDpDIT;
            wvlhahJBojjRF += WpDpDIT;
        }
    }

    for (int nmecK = 1070924728; nmecK > 0; nmecK--) {
        continue;
    }

    return WpDpDIT;
}

double DIddlxGWqJ::PSzFCAIsyOOixjSn(double KLvaSAcPG, bool fZigo, bool QFJrZUJJfVeOi, int lZGKmJJCewfym, string pnJWrsywKwcNZTPg)
{
    string DCcbZicojpS = string("MCeTvqiPDoKFyoiHUCWZqEnUgsQozSAEYeveHDVezjXWGqQmOjDCARxZvOnYqmhHaeRPWlXamQbyaQKldKTczOzVcBIQIGtNEfZrxTHvnwimAeSmBwJetWNmAICxVL");
    bool FuOquvP = true;
    bool hGrpyykCIaiicIJk = false;
    string qwsRKLfwH = string("mPwJTcJOQkAzIBqBtbpkkwakuvEAkWNSsXzdhkrwFVpDZfEeEszNgzdVuYxeXjfcOQGDOvftWaNxoqYIpEHxMwDoraUOiBaAgrVYRb");
    string hYFpyXoqhinZ = string("uDfRLCNknlYWNevGQwBHrrEqGFWaaMuRDyzRPCuZhEFhThntekNoVhyEGSqxLbmjxsvAJmJURdXhOmchXUYUKgcMHYZrMDxpVcDWpClAAqllqtZekqEAavUswycyIKUBcaqhRgFHiJODzgimdtwSdybHNYsuulDtgBpzOHcmPfceTTGplOjJgIGKyAhSGcodEwZsueiCoibaFvuohtCpHQTivnOCNcgMtOtoKDAAcIYeaBDnAakmC");
    double IVNcCjTccX = -736500.9379507328;

    return IVNcCjTccX;
}

bool DIddlxGWqJ::JvMYpWjaOH(double xddoKVCczaJD)
{
    double nnrVruAVu = 830624.5993800223;
    string ycgoNNAnFPOoY = string("jMvCxDCYBxUJOBeIHSMKhujDWZfrLAlhSKGHfaXapEplbzGuwVOFtJHbYkhapHvAEQLBANpftiaILIltABGMqJbnRKHpDkBnOxhqFthECLQecWIGGSXhgOMAPxZiqLlnOLpKymuHx");
    string IIhTPRNEjMeDQb = string("KlfDnWIbUGmZAUriXfKkQEHNjmkhwLXaQeSfmQGLtzvDZMKKgqnRAprXROovaXozTTwHctjNZWZVEzJIUhdysIVNKU");
    string ACDtxiu = string("mLQcrNfWeBHGhYeOZifClXwYEJZmYjItodimkrqUBWHQQEvcGPSTsELfLje");
    bool wgNgdYpbhuwx = true;
    string GGSwkspbafdi = string("jngtjnpereozwQHvBICswTBfGYbLytDONlWYMleTqggmNZswf");
    double rEYlcnNz = 397264.4192959611;

    for (int XvamoaxziwKQa = 1193487568; XvamoaxziwKQa > 0; XvamoaxziwKQa--) {
        wgNgdYpbhuwx = ! wgNgdYpbhuwx;
        rEYlcnNz /= nnrVruAVu;
        rEYlcnNz = xddoKVCczaJD;
    }

    if (rEYlcnNz >= -580671.7617060542) {
        for (int AEaRz = 1343898504; AEaRz > 0; AEaRz--) {
            rEYlcnNz -= rEYlcnNz;
            GGSwkspbafdi += ycgoNNAnFPOoY;
            xddoKVCczaJD /= nnrVruAVu;
            rEYlcnNz *= nnrVruAVu;
            IIhTPRNEjMeDQb += GGSwkspbafdi;
        }
    }

    if (xddoKVCczaJD == 397264.4192959611) {
        for (int esIiMPfr = 306668463; esIiMPfr > 0; esIiMPfr--) {
            GGSwkspbafdi += ACDtxiu;
        }
    }

    return wgNgdYpbhuwx;
}

bool DIddlxGWqJ::yBXjwxxCdaAwYA(string DvxpDNZ)
{
    bool KBAMyatCV = false;
    string xgoARnUXIc = string("lCiffOSnBGpRcnnkojqVjPNVpYAcKnmEubvyAjCXykkbbDSVmGAioOxdSQdqcrbfMnrcSiinAcpyhssitaopqdykYCCTgwppWNylscpvsaRORBaKupEvzpXdPyuFprgnZJZmebQveKvHleVDvcsqxcedFELnhwA");
    string xsBnqL = string("xaApxliBAVTwaWfKQAgoHxsLiLCicskRBJCiTQiDVyRDtVPpATbyPDesHcQUKvFqegpzfvjtLLMBGOIaRpduVYEdGNBrVnyofjeKHAmBkgCPhqLZObcrSEmXiecautCLSHEsNDTmwlvjRNxHEAjjXKJFQtLhoYwxhZJEMYmBrzdpquQOtEkWLpBhicmNSZNEVTnyjrCdPovUygrWHbSUPKoutVnTTbPoyDdfozzbGJrGD");
    bool ZbbFPwhPMp = true;

    if (xgoARnUXIc < string("xaApxliBAVTwaWfKQAgoHxsLiLCicskRBJCiTQiDVyRDtVPpATbyPDesHcQUKvFqegpzfvjtLLMBGOIaRpduVYEdGNBrVnyofjeKHAmBkgCPhqLZObcrSEmXiecautCLSHEsNDTmwlvjRNxHEAjjXKJFQtLhoYwxhZJEMYmBrzdpquQOtEkWLpBhicmNSZNEVTnyjrCdPovUygrWHbSUPKoutVnTTbPoyDdfozzbGJrGD")) {
        for (int GXBoOc = 1413020385; GXBoOc > 0; GXBoOc--) {
            continue;
        }
    }

    if (KBAMyatCV != false) {
        for (int kiDhKpCcBEMCL = 147300718; kiDhKpCcBEMCL > 0; kiDhKpCcBEMCL--) {
            xsBnqL += DvxpDNZ;
        }
    }

    return ZbbFPwhPMp;
}

bool DIddlxGWqJ::ZNGoKFUYqUQOmGN(double GrXOWNvRdatTWc, int oIBpLPlsMjoRKn, bool WDwsPvJZMRdrPK, int KeoVdTaim, double qfRHv)
{
    int KLiQmvTyhm = 1105548583;
    double WCvCBqWK = 425331.5801149236;

    for (int zLvlAtS = 1968273617; zLvlAtS > 0; zLvlAtS--) {
        KeoVdTaim += KLiQmvTyhm;
        qfRHv += qfRHv;
        WCvCBqWK = qfRHv;
    }

    if (GrXOWNvRdatTWc < 580657.7510330061) {
        for (int JnNZumlTGIBeUlDW = 1508185825; JnNZumlTGIBeUlDW > 0; JnNZumlTGIBeUlDW--) {
            WCvCBqWK *= GrXOWNvRdatTWc;
            GrXOWNvRdatTWc -= WCvCBqWK;
            WCvCBqWK /= GrXOWNvRdatTWc;
        }
    }

    for (int jzKLkGoEe = 1646916494; jzKLkGoEe > 0; jzKLkGoEe--) {
        WCvCBqWK += WCvCBqWK;
        qfRHv += WCvCBqWK;
    }

    return WDwsPvJZMRdrPK;
}

int DIddlxGWqJ::yDsUPuLgu(bool SpdNJlgJG, bool dRTeyz)
{
    int DxHnipgvwxNWU = -1723182870;
    string ArKXiPS = string("WXeqiHdSyeymOyTCWATiWciVJIcStxlPuvnCjKPpAfHBfCZrkAMoOuDBpYDfUxUJUlgOOfGqRHeBLEXhWNHpfNoUbAzyeGDBGpxMyYiqmuWttexLuVjgsJuAQygVWPMQDayNNAqpvaemWKKS");
    string ffhkHTOcLKm = string("tYzGeLbrKBMRXPUVGQmMSDlfZBEPLgJSWFXJyDbHdWbBXQmoFxUcCEqazTSdgqalZXXDuvIkepmuvIqZyDdEtPvXpUFZLNuqTbghkGrrkKpcYvlMyDKnQzWWoEsfoUXulcSSIzxpcCnrhkLLMVanTSqMdfoZvtoisXBXfQeClYLrCeADWOzoQpsftDtLRLVVMnqCpXHABLnxUpqiinTwZqpORp");

    if (ffhkHTOcLKm >= string("WXeqiHdSyeymOyTCWATiWciVJIcStxlPuvnCjKPpAfHBfCZrkAMoOuDBpYDfUxUJUlgOOfGqRHeBLEXhWNHpfNoUbAzyeGDBGpxMyYiqmuWttexLuVjgsJuAQygVWPMQDayNNAqpvaemWKKS")) {
        for (int gIVNWOwVEsTZuJX = 636554030; gIVNWOwVEsTZuJX > 0; gIVNWOwVEsTZuJX--) {
            ArKXiPS += ffhkHTOcLKm;
            ArKXiPS = ArKXiPS;
            dRTeyz = ! SpdNJlgJG;
        }
    }

    return DxHnipgvwxNWU;
}

string DIddlxGWqJ::IRKqsW(int gALlYcFwmBV, int wbzxuGJDz, int zjDvpW)
{
    double RxrbOmbPTDeCE = 332159.21129109367;
    string NZZaMfSHRxTy = string("nHJnbLTNiCfJgaiFJZgtQospddntkYvoHEuLUvjDYgdvSTfBGJfnfmvHLuAatDZihjCFZxMkCQlyYvxAiyOGKHxnTiBKfTNHbfBpbzjBBVOPpujdhbimJOfYPfvxGegnDfFokulcVzHyjJKRhGtztLodlTUZtZjuGhtUxRzsKRJMVGUzYqacSibEskALPzfXmCxvOVdTOofTljKsHrMkuwYMFXYWg");
    string uDKLcH = string("STNRoiUhMaJPxukudauDRUJdvcPMneFfQilKSCHtnmTvyOmayHGpGiuoKZQCYQKeiOq");
    double iwWnShj = -251604.9592625751;
    int kVvvumpWkA = 1174355162;
    int TmhrWFVhtnjPDY = 1555666813;
    int mehRaKvVbp = 1635778024;
    int lPACFwECTFqzmIaP = 370507106;
    bool RZYJzOqeWdJpsLr = true;
    int MMNIkjRht = 1625960821;

    for (int PEViHpErARsiVZVY = 135318932; PEViHpErARsiVZVY > 0; PEViHpErARsiVZVY--) {
        RZYJzOqeWdJpsLr = RZYJzOqeWdJpsLr;
        gALlYcFwmBV *= wbzxuGJDz;
    }

    if (wbzxuGJDz <= -785341386) {
        for (int IYekpjDKb = 217163936; IYekpjDKb > 0; IYekpjDKb--) {
            continue;
        }
    }

    if (NZZaMfSHRxTy == string("STNRoiUhMaJPxukudauDRUJdvcPMneFfQilKSCHtnmTvyOmayHGpGiuoKZQCYQKeiOq")) {
        for (int NDPNergLH = 424950124; NDPNergLH > 0; NDPNergLH--) {
            wbzxuGJDz /= mehRaKvVbp;
            TmhrWFVhtnjPDY = zjDvpW;
        }
    }

    for (int sVGDKCMQ = 1424452779; sVGDKCMQ > 0; sVGDKCMQ--) {
        MMNIkjRht += wbzxuGJDz;
    }

    return uDKLcH;
}

bool DIddlxGWqJ::qVTSRHu(string weVkPTist, double iLtzfDSsDNCnnk, bool WDUGMBHGaeI)
{
    bool gqLssSCFNGVAIO = false;
    string rxXlG = string("yUsbRuMeQBGxIWefFuux");

    for (int QdCKeYtXPLdt = 1797028861; QdCKeYtXPLdt > 0; QdCKeYtXPLdt--) {
        rxXlG = weVkPTist;
    }

    return gqLssSCFNGVAIO;
}

void DIddlxGWqJ::XPCeLdFFRV(string yifBU, int QuUcbYvV, int CjmXxGDIIFZ, double CdcIQqmDfHpRKH)
{
    int UpIqMrcWRNvn = 478340144;
    string BgPYiFrZeSMeCfv = string("fEXbMguibqDhNsLIDLbNAoQAXkoTRprxfLtABQrmmUPeMhiQcmzOHryrDEKdScZbsqWgpGzhv");
    int rmeFEIM = -503039990;
    int QhzTs = 965583049;
    string DdtuCIqLByp = string("aCjCBIJmyMxuZoDvAnTBPqrjwkUCcCINxSrpbDcCEeYAMzVOlCUWqhVDOxRntWEhbDogFFAQeXGhkhzDsOJBQZJXyxETyulWKPkdCWdwjJwtUJcsFVLrsGQUNSaUYofgwFwyuFyQoBEQyIbdvnNAkuJaYGXMgRQSOQvJlidYFbxeuPrVmAxVWteOayQhJHj");
    int bGEVlKNhmFJQ = 16876867;
    int gCYOBXPkNSQXSR = -1518384095;

    for (int pWukjFGoOHOYC = 2003522089; pWukjFGoOHOYC > 0; pWukjFGoOHOYC--) {
        BgPYiFrZeSMeCfv = BgPYiFrZeSMeCfv;
        UpIqMrcWRNvn += gCYOBXPkNSQXSR;
        gCYOBXPkNSQXSR /= rmeFEIM;
        rmeFEIM += UpIqMrcWRNvn;
        BgPYiFrZeSMeCfv = DdtuCIqLByp;
    }

    for (int KlDExWZI = 1301501546; KlDExWZI > 0; KlDExWZI--) {
        continue;
    }

    for (int GHUFjicujl = 700842192; GHUFjicujl > 0; GHUFjicujl--) {
        UpIqMrcWRNvn += QuUcbYvV;
        CjmXxGDIIFZ += UpIqMrcWRNvn;
        DdtuCIqLByp = BgPYiFrZeSMeCfv;
    }

    if (CjmXxGDIIFZ <= 478340144) {
        for (int uhMgkYyJiGrERPr = 264575346; uhMgkYyJiGrERPr > 0; uhMgkYyJiGrERPr--) {
            DdtuCIqLByp += yifBU;
            BgPYiFrZeSMeCfv = DdtuCIqLByp;
            gCYOBXPkNSQXSR = rmeFEIM;
            QhzTs /= QhzTs;
        }
    }

    if (QhzTs > -1518384095) {
        for (int UaHGcgLYlkaXUGeI = 1382707286; UaHGcgLYlkaXUGeI > 0; UaHGcgLYlkaXUGeI--) {
            bGEVlKNhmFJQ /= QhzTs;
            CjmXxGDIIFZ /= rmeFEIM;
            rmeFEIM = QuUcbYvV;
        }
    }
}

DIddlxGWqJ::DIddlxGWqJ()
{
    this->WzJPKUXI(-156153.56033048744, -854362.7390726794, 1189858405, 960287.8564215061);
    this->JLgMXnPjVfwOsuU();
    this->kfgoJDRMpEAQkHY(true, 1921284652, 243447577, 1308332543, -1011934.184087035);
    this->DpiyaagSGBfNBg(-140410.13999843385);
    this->gpNGgany(string("qGSIZ"), string("VMKDwjeSVCZIfjavLFhWvOwYSAhaHkAXCilwcrvvzEmtNOytgQNIzloNdpcUmsfcZapCkDyDBqBqjidGMegENTTFvxHTRZjolINoLkFVyblIiSbdMOiBObxJEXqwqEijXiggCBabiEYITyAbfcouHpardlNzZuETqBqVfrtGXTmqhQSAWyubGTZeRsqfsAO"), string("DfEdaWBWiUDuvVKlEolbTonbpIurWroKwrzMgqfCUNFMheEQhDQkwhIouAWnMgYHFvTMFklRFFWflvlIXsjAJzFKrYilCKscbKZUKghVOppVwGYlWTVKdsFdMrbCFfZrksKPjDATzbAfZgCFFCmGusgpVgVtCiOBrXLuSgbygmPDOSdDdcibvkoaINflhXd"), true);
    this->SSSVBOCi(-720258842, 181649.88513345944, -1437964135, string("aQewYqegveRKyqCjqiPupqiqEQtQvyGwzltSbDfZsAnVfnDeNslEFTIGepAlEgWPYesQDrAZlSUQRczvjJaRTJrtPFEPMxsDQzAubipuHRhzcUWksgNCAzLrnkddOGRGNQYsrnsQtvlpUvxvJwKoeofEyxCjaPabDxezmWWdQmmZzNXKqCCaaPGAeHdPpefTvwArvHevMVSqdTuWsXRlqQcemKAycTphDHykKCKLMrKK"));
    this->PSzFCAIsyOOixjSn(-592835.7341654801, false, true, 2110928227, string("qhsuhfXSyamYvhfagooXolrDgeSXsHtqeMuDIgXahXeUDiHDHWnOpaxqzvzVKMjCsEQIpdKDzIazCGahczwKPLChRbzRrcxXAqzuApDivWJmQBQqkwIBnYTWnOzQPqXdMKxVqbtRkgfishEifCifeTukuwQfmsBJULLDHSAHHgsocYSzfrZOOWVqNGCFWHzohfUfuTgtRGAGJHsvgBcsPlEHvOZic"));
    this->JvMYpWjaOH(-580671.7617060542);
    this->yBXjwxxCdaAwYA(string("juqFNuAdhkXJtcBvoRhAFWrwErtNpIqffsNvfldfLAHxCdxflvHJgOHCKCrJlfkcUkubltTrSsvoyiHsppHQnOhUpVPDubuPdmAewVoJbDtxNePZzVBbKXIbRjhsnARurPJbvQbPyaCScBkpbUwpMBigupsoyTyBsGUKBqyrYuDsIMGERhEvyTeTzKJkIBGUZMpVmvHInCTqCeSfqPdbjGviFzEljgV"));
    this->ZNGoKFUYqUQOmGN(580657.7510330061, -680955714, true, -553241963, 813363.063019647);
    this->yDsUPuLgu(true, false);
    this->IRKqsW(70848701, -785341386, -968617203);
    this->qVTSRHu(string("IYxuAoABvKnLbhLGVmvxrpLqUcqvLdEHYeFMbtdBOpwwWwiYVCWakVYltxEbSrmSuvHTNLaGuHpzhcAIOXryLFteJSPPyF"), -217875.25413092144, false);
    this->XPCeLdFFRV(string("KxWaPyCyhAnDIOWeznVPxZWPOpEitysJdhjUgKDCOrYBVkIlNbAUVDJePlocKNLUnjPCvWvObgOFkCZNjohpHsUoOmrgFVFxrgUcEuGtyJIpmBvKoyKQwQBVRjHifPOhCEZlqGlVzNViqCOVCcBFXykycSXexnJaTzxcPBsMMLoTtDpBWnfDFPAqEyFsvsbSMThOs"), -99562882, -1614041495, -889727.2616848944);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ljSTGpXPupg
{
public:
    bool GftOx;
    bool lzPGCz;

    ljSTGpXPupg();
    double IluqumRpVjeocWzE(bool MNZbQUi, double dUSFnJMeGhCZRG, bool ZwUxRgmVF);
    bool pwvNHxJAc(string xahfnhgfhfO, bool IcBaufMkPjxL, int LjTxqHVgEuNZQ);
    int eDGOLWuYLxMSDM(string MtRpGLbWnPkYA, bool SelHwBlKJpGy, int icXOXbyf);
    double miwrJMSliSVEgDq(int ZDlLHX, string mrGruqFm, string DNSTlTLfYEQrwzWv, bool fReORLPlrUnDPwb, int yduznyILdQFKSZ);
    double yKdMBkw(string BQHnTvRS);
    bool uNiSVU(double rZeDPOA, int RuuyfflTxVXRpo, string pKRLXANm);
    int PtgERtpo(string VJMDScacp);
protected:
    double cCVEY;
    bool KNRKIkn;
    int MNQMQhgtSjyhK;

    double CHXpIcyrKAa(bool lTJnqoWRPzwD, double XoJvHvVmfLQdVsgV, double KbvykkkJjpaG, bool dSlKEQAq, bool rsXEPOIvQgyH);
    void RcuVyuyLn(string BsZWqXIpi, string vMiSsOWFmuIuvttC, bool YURIi, double EwWYZwbvcNCXmPCJ, bool CtqFoZQQmtnE);
    void QVkyQQ(double nPShtNJTPZ, bool UMiXvb, bool xddzOYkgovEPayh, bool TWXUjueZHUH, double IksyDIlZhgZV);
    int eduXuRLUfqAzWOJ();
    bool LJeTqYD(string HtUeaC);
    string AURzX(bool MoGexTXOPeUM, double IrtatoAqQTIOJ, bool dJAhIc);
    string iKNdkIAEWuQmpHXY(int QmRxrwzx, int AfpGQfJfhByspp);
private:
    bool tfLHWs;
    int QlOrozKZTLwYzO;

    int HUrjVpRmLbCLJngd(int LzRITRwxrgicZssN, string hbYeMrtl, bool gIYdQQMfch, int vyBFE);
    double GFdzNkcR(bool jMpyAgdED, int pVRIVyRmfKPUObT);
    double LNmOUnhqcBoGlDU(double rFLSx);
    string HzbYyfytP(string WTdURDAjSWCJP, string MzcswO, int vPVqWzvWf, int pPPgNFSKtK);
    string ELuulq(string CXugzWoBbLqJ, double PTwZFAFiRjnZtq, double dFWvHQX, string WtJnuEYhQBgaR, int mNomhQnV);
};

double ljSTGpXPupg::IluqumRpVjeocWzE(bool MNZbQUi, double dUSFnJMeGhCZRG, bool ZwUxRgmVF)
{
    double nhUXJfreWFdwcFx = -970069.4306242843;
    double lOxiurxseLfP = 328407.47004235507;
    bool JdSNxN = false;
    string kvyCcuFe = string("RPRfdhYLjHVFaZsBJGWalqUwHvjDOGeIiMtRLZsdWxGPAeRPjtJNUHIGfasZPGmpSKpZGKsNmcEXYKoVnkkTleBWVSELyxQcZZKfaLcdmJuIMmnLtSrEIliyXYZwMVWoBDjMTnONbhQafeMAjvcNtGsdySYfTGNRmxSreffABrJrXyGOWJVAIoSPFKYphAqfj");
    int ugKcjfeXynLHi = 1724519631;
    int UkSUCuub = -1288806289;
    double XpYFqGRzgMXC = 754543.0325660578;
    int cwvSjQLY = 2114165363;
    double bVrFPhqU = 239270.85991353414;

    for (int DltdDuPB = 246315992; DltdDuPB > 0; DltdDuPB--) {
        continue;
    }

    if (lOxiurxseLfP >= 239270.85991353414) {
        for (int WAZlnLmNZpvBDF = 710565864; WAZlnLmNZpvBDF > 0; WAZlnLmNZpvBDF--) {
            bVrFPhqU = XpYFqGRzgMXC;
            ugKcjfeXynLHi *= cwvSjQLY;
            UkSUCuub += cwvSjQLY;
        }
    }

    for (int jkiNQiJgyIYkvzUf = 651468762; jkiNQiJgyIYkvzUf > 0; jkiNQiJgyIYkvzUf--) {
        continue;
    }

    return bVrFPhqU;
}

bool ljSTGpXPupg::pwvNHxJAc(string xahfnhgfhfO, bool IcBaufMkPjxL, int LjTxqHVgEuNZQ)
{
    bool lDtaFo = true;
    string qQpJJRvB = string("VaRItKywAOuYHmtxVDpJroMWMMaXBjwJXSUYLnemBFbxxvjIETkUPKFKdnIbTsYquaNAJioVJgAgNcGntFzZCpLegjILFcqcSUMGChemdPBEGpibBRihDeltCqzCdSCAoxtOzXtKuIJaNsdockojHYZWtkGGo");
    double ETCJYOqJiVLnCOd = -897814.2599607788;
    int LLhTaALVP = 1514266656;
    double bXSLYTbtWDNPWa = 29729.07321247269;
    string heaAjNxWXEDfPS = string("vUiffcUkyfWzVHlTuNIYDthDpjMjdtFLFOAgyBNaOrazYehBQCnHveIxsZIVqzDdudjCZxgAUePdrqoCsTPrbUjBUZpvxaFCGJYJUeNlFIHAPiTSvlLgykKeiPfyrkbuzVKbMbMpryJJSUVYgQHxXoNaXkJEOHzwkTvQUzjUSYWLrLNaBKqeNdlaqvwWaBCCalGjzUcflyqBFlV");
    double GLILKAUk = -59381.08278779388;
    double UhZOoglk = -286660.256543373;
    string PSYLMIJLk = string("vCCKWkAESMyoodLkNOZktvdWABrjgKojViPiBNRLxadyAbFTYdRXGfadRMPUiAJhdkvRBZeDtmUrMEHiUNXoDaLzFyGYJNzflMSmPNcXromIHQSjdvNMLAHxnxMLihiqCAhCQMkKXthnGPjWQgcVxNJYZfKpKWOcmsBqOFWXMRpGfdKbmlzXnKnZIaIV");

    for (int IopZRWvfmGxaptgL = 353362873; IopZRWvfmGxaptgL > 0; IopZRWvfmGxaptgL--) {
        LLhTaALVP /= LjTxqHVgEuNZQ;
    }

    for (int RGXfgFCDFId = 908674596; RGXfgFCDFId > 0; RGXfgFCDFId--) {
        qQpJJRvB += qQpJJRvB;
        GLILKAUk /= bXSLYTbtWDNPWa;
        UhZOoglk = ETCJYOqJiVLnCOd;
    }

    return lDtaFo;
}

int ljSTGpXPupg::eDGOLWuYLxMSDM(string MtRpGLbWnPkYA, bool SelHwBlKJpGy, int icXOXbyf)
{
    bool DoLiI = false;
    double riSPbAZZ = 931453.290901523;

    if (SelHwBlKJpGy != false) {
        for (int zqkoP = 490416378; zqkoP > 0; zqkoP--) {
            SelHwBlKJpGy = ! DoLiI;
            MtRpGLbWnPkYA += MtRpGLbWnPkYA;
            icXOXbyf = icXOXbyf;
        }
    }

    return icXOXbyf;
}

double ljSTGpXPupg::miwrJMSliSVEgDq(int ZDlLHX, string mrGruqFm, string DNSTlTLfYEQrwzWv, bool fReORLPlrUnDPwb, int yduznyILdQFKSZ)
{
    string LbdaTCajkSgJLq = string("prufhFUhaKnKJWRtAANQbWfzMOVUntPVNngPFHgTOychDjuZJcmtAdCgWybEJlmoUAkQkkVLXJCApQjcvDpLMqdCqmGVoTbpOIxQXZTxxZjSAj");
    bool fyrcgmHJt = false;
    string PjjBSWMDHWetjc = string("coyqEHiJabRyzXXjISOjYzwBuZnXTcUVtnlzkZAHCunacfCsGJTBBdMwgsAWZzxKXiIMbgxCUpXbOZrIZafUciJSzQZOoPkRpQfVAQqnfbGDafpcPKWnUJmAZZxQsHdPXpuMsmiDxNwBKtOCAeDpYWKeqantGjossMNoGewbeEPXJjhTjgAaMYjwufmOkuQuxWpWQRNfIqHk");
    double mRtqirpxCCicL = 794121.4957154854;
    string lDculsgXCl = string("MqCKQFcHQyppNIBjbDBMrzIGoOMvyNqBVcAuhfCoIJLFualWrXOeqIbrQMtvwvFDbNhuvTvWVLohHfuzZBexATKMbeEMbPemiWULVbLCeqUCJRBMNdubjsBicAfOsbvYpbjQuAVq");

    for (int UOglrUV = 1509090808; UOglrUV > 0; UOglrUV--) {
        DNSTlTLfYEQrwzWv = DNSTlTLfYEQrwzWv;
        fReORLPlrUnDPwb = fReORLPlrUnDPwb;
        PjjBSWMDHWetjc = mrGruqFm;
        mrGruqFm += DNSTlTLfYEQrwzWv;
        PjjBSWMDHWetjc = lDculsgXCl;
        LbdaTCajkSgJLq += PjjBSWMDHWetjc;
    }

    return mRtqirpxCCicL;
}

double ljSTGpXPupg::yKdMBkw(string BQHnTvRS)
{
    bool nvhIwQLc = false;
    bool ETLUEOxkB = true;
    int TEgowjH = -1620658141;
    bool FUKsDdGVgkKkvqmF = false;

    if (FUKsDdGVgkKkvqmF != false) {
        for (int siLMcLylKOGnekf = 744261579; siLMcLylKOGnekf > 0; siLMcLylKOGnekf--) {
            nvhIwQLc = nvhIwQLc;
        }
    }

    return -207068.66206640328;
}

bool ljSTGpXPupg::uNiSVU(double rZeDPOA, int RuuyfflTxVXRpo, string pKRLXANm)
{
    string ouYwWmRJhEs = string("SmYTiCkuvmdWTOUVCbLfFltDqXAYJoKxlrqjcOYoVSZRUxRiBxMTrrLwCdCfdgmairNiPFhIckjyZlWaRUPKRvzb");
    double DhDnUcKqaHirMnYe = 1027118.0094800805;
    string iqnYXbl = string("OYGvmJEKgooGusxkWSVPtOYKvKgzWsCPKCUkqsIUUGIHvjwRXQeamdgzFaXjKfdJANiSooPwURNXVppEXJxuxduwcgPFfGnAlrFuPnGjlwQCEVwsgrNXxgYFTwSAmcrKiAFcQdMLVwBOBZhunKEUYfxRoaFwjTZHaSZHPkAmsjKJUSHGgxNGtwZTeLoxArqxbKKbTuHsxbGMPWcvJpWkjnnLlZAdKbUuuEQ");
    double ilkeYVfRYWUwBiCb = 606633.3336930604;
    string wBqBMGLuZ = string("cgkeWwOBnOpsaYdLRtSuuEAtqbEtQUxSyJqCpLERtPeuRCJIzyHzrNOtDedteeAcEAUgkjxlnXdXxDRvSdVLESHcqGzJMshfFXmubCACpuUhShNqAurYaiMqNYaHOqXXVEsUzrFYggTIAhObsIYljRFEbDAdOleTIsxIFJJgwLPblZkJjgYBqdWCgSSUxXQQjIbhTolzOxQTzhxFpUkEf");

    if (ilkeYVfRYWUwBiCb <= 1027118.0094800805) {
        for (int OhOYDbWRlwtrHRO = 84866418; OhOYDbWRlwtrHRO > 0; OhOYDbWRlwtrHRO--) {
            wBqBMGLuZ = ouYwWmRJhEs;
            ouYwWmRJhEs += pKRLXANm;
            rZeDPOA -= ilkeYVfRYWUwBiCb;
        }
    }

    if (pKRLXANm >= string("LdQIENdfVqDBpIGTOyaDSNxNMDULuVcJCSGCMADGKhDaAOWSdaSshNbzFDPDHbSeviIojqPFdQuZPkVbuMIXYeZv")) {
        for (int rPyNQnvMiiECqD = 948299511; rPyNQnvMiiECqD > 0; rPyNQnvMiiECqD--) {
            rZeDPOA = DhDnUcKqaHirMnYe;
            pKRLXANm = ouYwWmRJhEs;
        }
    }

    return true;
}

int ljSTGpXPupg::PtgERtpo(string VJMDScacp)
{
    string GFdjGHKjSFyp = string("zirvlTWqQhfLPaQPFTAWKMPDBDIzYuMzpBBcFScyTsytxNdbRQLOwAheATwyxPXtVQVHfmNVcuGwFKiGCvjYntCjYwcDxxZOCPUrkDWrpVgJXsoSYuXwIEbWguGBstAJjKdApCziRTPOLRDZXdHvIwORSiCiKeHoJTJqrDucmWjbtIdhJSISAxGvfAMoAgErQNlcGWUAGHHbPweplthKgGPhkuiLWJROXTHyCpYDdIPMxQmxYZbpSyRC");
    string THUYhMfNSnp = string("hirUUiYxdwiKfPToPHHhnMwahtDjam");
    int gcymrHCoXYzigj = -2096559796;
    double kEMfagJLbI = 947809.6979334361;
    int uDPsUwoC = -1239151777;
    string tZwDXKSket = string("BmdjnkaMgEKGUCkptKrWCFaSHqNAUuqKQWCOGspSZCtTzztAzAacMcaEKqFSsukEPKuSSWwgvcuWgOpUToMFprnHpEJyFGQYhAyWblUHszjvFuzLMXYtBvuVsWpofcTUfmefPnisJbghdnrpLnTxXZObGspFvBIcFgsbafylPjiHVtULKRyNgNBkiZOAPGFJ");
    bool WLzXMxmQBdXg = false;
    double mskHodnglX = -465071.35399936873;
    int kqBNSkgVYcfGeN = 1043039971;
    string HqDkC = string("NAMEjkeKGNXPtRvrrZUygEftCeHdxAsfzWolQECvfdTMZTutiSJYDTzWxZyTXjtnJLbfMLjOQvZaTbFWMkhMCjTfRM");

    return kqBNSkgVYcfGeN;
}

double ljSTGpXPupg::CHXpIcyrKAa(bool lTJnqoWRPzwD, double XoJvHvVmfLQdVsgV, double KbvykkkJjpaG, bool dSlKEQAq, bool rsXEPOIvQgyH)
{
    int WzixJioEAyOxfOSR = -491404879;
    bool jnNptvkprNViIC = true;
    double CSCfcaodH = -503347.4020418889;
    double GXlCrTOEHKVXrX = -245011.4812818901;
    double TxPpxHOjOe = -644840.0073501917;
    string gQMpERXaBpIPAh = string("YXlUxHlaoiruUyGmgOQnjBGCIuvftigqxpOvZwWnjPmovtgRbBaAvEyCUvXBdFUqqYIyQhaONFQPqVgFlgnTpiDbYmQcKqMNuGpxoYRMoACkeNmdzutgrwXdFZLITbGv");
    bool CaWDBThAKytgWM = true;
    double bwJwtPmexhwfLi = 944574.318305682;
    bool EEWAmQZWyR = true;
    string eYANYjiNHguL = string("qLBsrpyPBDZFDjQDAHflfLqletpQlbuyQcwUISgZOnrvgWakDOjbzqDgGuIChsloYgUOPkGYEVjqdjaTCBJELlluaqPOWfqWrLKXIiNvWnDGhipmrmooreDOzlUFbTXEcdYZcgGeBFmcGpMmGOFVoKMpnQtNdoxSRPdechQWiZkUYjLqeWvUUQzErhxdhBPXKjxEAjfmL");

    if (CaWDBThAKytgWM != false) {
        for (int eeatfgdlW = 235979921; eeatfgdlW > 0; eeatfgdlW--) {
            rsXEPOIvQgyH = lTJnqoWRPzwD;
        }
    }

    return bwJwtPmexhwfLi;
}

void ljSTGpXPupg::RcuVyuyLn(string BsZWqXIpi, string vMiSsOWFmuIuvttC, bool YURIi, double EwWYZwbvcNCXmPCJ, bool CtqFoZQQmtnE)
{
    double jKZPRAYaQbF = -849051.6626172423;
    double dhKjqLn = -594637.774227292;
    string gfykxiWOzXK = string("AJvaJSAYrsLonbRytcvQJhwrnzhQjoCRBHrILnGxajwVevruPu");
    bool ULSbFNg = true;
    string LyWxa = string("ogVkHmpwnkZCRRLwadMeQkNUhppwYjMkLXcPhgtsmTMplRBAbhxqmKHKYwRIVcyWWmqZhubYLqfRCpfISWnqZXygCcPPHZvTVcJEbMFxOgJRpdUdPxvloUDFUhfpucvWxOABfTXL");
    double lBXVNsDUmCf = 323403.39368090994;
    string zaiqaaNQuM = string("yGfCYpumMhTKCdjOPMZAeUYASoXUVoLeLFKObTwGNKEAAzgxxxNOZbaiOgPCFprxXepEJUiRzrAtrRHbGLSarSHXkPBJgJXDaidRtKuYLxeJFZSIESDPJj");
    double SxDxIxkTBOnAGIN = -17713.784541811903;
    string aYZduRpr = string("SznVRzgcXKyIVHyQLyRKFCtcOzFbAQoXolsqpKepgpgOQGHVOMyuMGmRytUXNwdLrbVEpkrtgWuAXBQjUHBhoMBmNTmYRDGPewTivVdLqwieJsjhDveIEStruvnRcExWcKPPNBjbXLlyoArVHfsKUTCkVTPerurADgfeuDJGFaWQLKnGpAjtLsscguCWtInY");

    for (int VstIVlsJDGqaG = 848585898; VstIVlsJDGqaG > 0; VstIVlsJDGqaG--) {
        LyWxa += vMiSsOWFmuIuvttC;
    }
}

void ljSTGpXPupg::QVkyQQ(double nPShtNJTPZ, bool UMiXvb, bool xddzOYkgovEPayh, bool TWXUjueZHUH, double IksyDIlZhgZV)
{
    double MJpLBmfgvZOzVj = -1001771.8156853629;
    double QLiMuqpVZXXfzzby = -576449.6099606263;
    double jPBpxfgsGsRgaGLe = 327166.69238965807;
}

int ljSTGpXPupg::eduXuRLUfqAzWOJ()
{
    double MjHkoBO = 751266.6100362496;
    int FGdsOtZhAmul = 329688413;
    int qNcFxpsrwhd = -279912477;
    int MXkOrzVZucrAf = -624497915;
    string BjvqYUHh = string("MurugureLwnJfhDcGsIKbPBkuEdExAVgFEwlRRJXGXJdyaUYOWWUboriMArwjgCqDiteWYfGZHDl");
    int hRQoWjYQzNeRj = 440295281;
    bool ekWfFhaFTeTmmMVk = false;
    bool wQVLvli = false;

    if (FGdsOtZhAmul <= 440295281) {
        for (int KvQISNAzqRRU = 1105196927; KvQISNAzqRRU > 0; KvQISNAzqRRU--) {
            qNcFxpsrwhd *= qNcFxpsrwhd;
            hRQoWjYQzNeRj /= FGdsOtZhAmul;
            wQVLvli = ! wQVLvli;
            ekWfFhaFTeTmmMVk = wQVLvli;
        }
    }

    for (int kMxHJiTKMMfnQZik = 565651164; kMxHJiTKMMfnQZik > 0; kMxHJiTKMMfnQZik--) {
        continue;
    }

    if (BjvqYUHh != string("MurugureLwnJfhDcGsIKbPBkuEdExAVgFEwlRRJXGXJdyaUYOWWUboriMArwjgCqDiteWYfGZHDl")) {
        for (int gTNFUsKJVxu = 830213551; gTNFUsKJVxu > 0; gTNFUsKJVxu--) {
            MjHkoBO += MjHkoBO;
        }
    }

    if (MXkOrzVZucrAf < 329688413) {
        for (int zSNrKG = 1921814551; zSNrKG > 0; zSNrKG--) {
            FGdsOtZhAmul += MXkOrzVZucrAf;
            MXkOrzVZucrAf *= MXkOrzVZucrAf;
            hRQoWjYQzNeRj /= FGdsOtZhAmul;
            wQVLvli = wQVLvli;
        }
    }

    for (int RuXCpWeKriTFwldB = 1730333280; RuXCpWeKriTFwldB > 0; RuXCpWeKriTFwldB--) {
        FGdsOtZhAmul += MXkOrzVZucrAf;
        MjHkoBO /= MjHkoBO;
        MXkOrzVZucrAf += FGdsOtZhAmul;
    }

    return hRQoWjYQzNeRj;
}

bool ljSTGpXPupg::LJeTqYD(string HtUeaC)
{
    string nKjGrXIBqSg = string("ePakBlaoTcTPLvgvDWLaOWrnTuCTLztJSeIQxYnHAAqAdqMdyiNWnRQdZfggTTZLMdoLPltdYZWHGIauonPpDGvWKZkGiWjJuzhYCfnxZnLjlWuyoHOLEVDYEhKvKGPffSnoAfIhUUvm");

    if (nKjGrXIBqSg == string("ePakBlaoTcTPLvgvDWLaOWrnTuCTLztJSeIQxYnHAAqAdqMdyiNWnRQdZfggTTZLMdoLPltdYZWHGIauonPpDGvWKZkGiWjJuzhYCfnxZnLjlWuyoHOLEVDYEhKvKGPffSnoAfIhUUvm")) {
        for (int eRcLmWcx = 1810118461; eRcLmWcx > 0; eRcLmWcx--) {
            nKjGrXIBqSg += HtUeaC;
            nKjGrXIBqSg += HtUeaC;
            HtUeaC += nKjGrXIBqSg;
            HtUeaC += nKjGrXIBqSg;
            HtUeaC += HtUeaC;
            nKjGrXIBqSg += nKjGrXIBqSg;
            nKjGrXIBqSg = nKjGrXIBqSg;
            HtUeaC += HtUeaC;
        }
    }

    if (HtUeaC < string("ePakBlaoTcTPLvgvDWLaOWrnTuCTLztJSeIQxYnHAAqAdqMdyiNWnRQdZfggTTZLMdoLPltdYZWHGIauonPpDGvWKZkGiWjJuzhYCfnxZnLjlWuyoHOLEVDYEhKvKGPffSnoAfIhUUvm")) {
        for (int sdpNaDXewcyIr = 730867149; sdpNaDXewcyIr > 0; sdpNaDXewcyIr--) {
            nKjGrXIBqSg = HtUeaC;
            nKjGrXIBqSg += HtUeaC;
            HtUeaC += HtUeaC;
            nKjGrXIBqSg = nKjGrXIBqSg;
            HtUeaC += nKjGrXIBqSg;
        }
    }

    if (HtUeaC != string("YWzxmgTRhpSuUvCugXhDrTPHhgQuejMeESZXAbgotzYkJPQouSsTBWTWcuYMcVrtcbEGNUMjeiAlIPDUCsXEdkRPHRsMhVJXQiMwXpJxmOYCUGNoEplZvBYmPiMoBzzLNJiCcGbk")) {
        for (int iyjznjBskAHLn = 1593947964; iyjznjBskAHLn > 0; iyjznjBskAHLn--) {
            nKjGrXIBqSg += HtUeaC;
            HtUeaC = nKjGrXIBqSg;
            nKjGrXIBqSg += HtUeaC;
            nKjGrXIBqSg = nKjGrXIBqSg;
            HtUeaC += nKjGrXIBqSg;
            nKjGrXIBqSg = nKjGrXIBqSg;
            HtUeaC += nKjGrXIBqSg;
            nKjGrXIBqSg = nKjGrXIBqSg;
        }
    }

    return true;
}

string ljSTGpXPupg::AURzX(bool MoGexTXOPeUM, double IrtatoAqQTIOJ, bool dJAhIc)
{
    int XuzsrEQLrFjbZE = 1821896975;

    for (int UoIgdbLAnlSGFB = 1659622010; UoIgdbLAnlSGFB > 0; UoIgdbLAnlSGFB--) {
        dJAhIc = ! MoGexTXOPeUM;
        MoGexTXOPeUM = MoGexTXOPeUM;
    }

    return string("TJDdMEVFSkrtMmrKPUkVmEOVJushyTrJdDXrkGvjTNyfAisFyLPZmdpWKPAmkLLkfQggAPtakevUOhNaEzFpbeceCGywHTcGYRRkWbDGfYBxbbhWIiblCCOnxnDZHdegaNJUvSFrZqzInQgPlyNaxARdmShWZKZZhRQYWPRhmNubVEggmhCYtlRNJVAYKLgNPLxnYNnCVipBKFKlDcvwKlxZgkzzdqesdmdArhXpruDMvlhuHJJ");
}

string ljSTGpXPupg::iKNdkIAEWuQmpHXY(int QmRxrwzx, int AfpGQfJfhByspp)
{
    bool XFxVCPU = true;
    bool qVKGhxLmuhxWNbGj = false;
    string JeSTYJQed = string("pGVyuqZOULixtpacoOURFpHYikKfFDErerehaJbnTudRmDLAUCXdKyremMrWMHkvGqfnwpQWomyaVplMihkbeqCFkPiXCyvyYvmAWZEebKtxGwqUMnOSObvisFgUlzVUTXKTKSULJCSVQaACTijuMoJU");

    for (int xWjhjIdqv = 423381840; xWjhjIdqv > 0; xWjhjIdqv--) {
        continue;
    }

    for (int PtWDOMlvRueXKzV = 606386094; PtWDOMlvRueXKzV > 0; PtWDOMlvRueXKzV--) {
        qVKGhxLmuhxWNbGj = ! XFxVCPU;
    }

    if (XFxVCPU != true) {
        for (int GMNKybIFFkhhs = 2077839641; GMNKybIFFkhhs > 0; GMNKybIFFkhhs--) {
            continue;
        }
    }

    if (AfpGQfJfhByspp == 1759620487) {
        for (int ekHddGSNkECKnx = 1871194766; ekHddGSNkECKnx > 0; ekHddGSNkECKnx--) {
            QmRxrwzx *= AfpGQfJfhByspp;
            QmRxrwzx *= QmRxrwzx;
        }
    }

    return JeSTYJQed;
}

int ljSTGpXPupg::HUrjVpRmLbCLJngd(int LzRITRwxrgicZssN, string hbYeMrtl, bool gIYdQQMfch, int vyBFE)
{
    double WqbUemxKSJcFCQ = -930481.8927362243;
    string SlqJSoOEvcpFdd = string("HqGgUoqCWNXtdXNjXQjsChQCFYLlcGkUvdsjhPypzAGVhSXHGDxulvRDaENFetYOGhLyczV");
    bool PKqwO = true;
    string LoHLLnLBgPlV = string("qbejiybhlYVtuYKhGWgIxHaHDqhFTXEwqUpZbgFXtTAFoEgQLxkcnRaZDprpgUqOSgprgEjoBQxJDBputOEJAFNPDgGYPwWJWbVKRklPETgPNQyKdQmsGWWpJENgzPEGeZXmUyqGUmeTkvb");
    bool tyPUezHaCEebv = false;
    int fGYsdlHvPk = 1036844242;
    int bNvTOnyc = 1056613690;
    double ZWnbWq = -910656.0550153801;
    int XUWqdWviFLrftPj = -1823667455;

    for (int WkeJbBjVkKzH = 2030322387; WkeJbBjVkKzH > 0; WkeJbBjVkKzH--) {
        bNvTOnyc = LzRITRwxrgicZssN;
    }

    return XUWqdWviFLrftPj;
}

double ljSTGpXPupg::GFdzNkcR(bool jMpyAgdED, int pVRIVyRmfKPUObT)
{
    double llAbis = -467570.8050502107;
    bool vxVVUjoFgOmrZUpH = true;
    double EvkJpaqqTTbmFeV = 7722.357046262113;
    bool sBKHriEcDXpi = false;

    if (sBKHriEcDXpi == true) {
        for (int ptUaatRSdjPxKUVn = 597292318; ptUaatRSdjPxKUVn > 0; ptUaatRSdjPxKUVn--) {
            vxVVUjoFgOmrZUpH = ! vxVVUjoFgOmrZUpH;
            vxVVUjoFgOmrZUpH = jMpyAgdED;
            EvkJpaqqTTbmFeV = llAbis;
        }
    }

    for (int EJRbQHsO = 150742259; EJRbQHsO > 0; EJRbQHsO--) {
        continue;
    }

    return EvkJpaqqTTbmFeV;
}

double ljSTGpXPupg::LNmOUnhqcBoGlDU(double rFLSx)
{
    int AwXCa = -1507076599;
    double LSTQRMk = 181683.54444275165;
    int qVFgUmbSeKE = -258240706;
    string ynUKOehPdmgR = string("TvhvEOmODLumk");
    double YxbjvPJhEWdVH = 234186.34273634077;
    int kHrhOMwRhZS = -788889459;
    bool RHJMomvBOro = true;

    for (int YTiwOtOlasFVW = 299449626; YTiwOtOlasFVW > 0; YTiwOtOlasFVW--) {
        YxbjvPJhEWdVH = YxbjvPJhEWdVH;
    }

    if (kHrhOMwRhZS > -1507076599) {
        for (int TxVvVJdjW = 521051287; TxVvVJdjW > 0; TxVvVJdjW--) {
            AwXCa /= AwXCa;
            LSTQRMk += YxbjvPJhEWdVH;
            AwXCa /= kHrhOMwRhZS;
        }
    }

    if (YxbjvPJhEWdVH != 277438.7335790128) {
        for (int uRdKqCZwwbdol = 30897176; uRdKqCZwwbdol > 0; uRdKqCZwwbdol--) {
            YxbjvPJhEWdVH += YxbjvPJhEWdVH;
            ynUKOehPdmgR = ynUKOehPdmgR;
            kHrhOMwRhZS /= kHrhOMwRhZS;
        }
    }

    if (qVFgUmbSeKE > -258240706) {
        for (int bVQFJJTPOyAootO = 617962131; bVQFJJTPOyAootO > 0; bVQFJJTPOyAootO--) {
            continue;
        }
    }

    return YxbjvPJhEWdVH;
}

string ljSTGpXPupg::HzbYyfytP(string WTdURDAjSWCJP, string MzcswO, int vPVqWzvWf, int pPPgNFSKtK)
{
    int FyRscsMMZSH = -1827345044;
    int nEygizhbwBbYU = -1011803700;
    string uPRQDtexTvDdt = string("kxtXgShHxgEQTbvxlJagaGdRyYxggAzSMExJAnvdFpemhREukJivkToxHyVMnggrFuNIlMkANsItDvr");

    if (FyRscsMMZSH >= -1011803700) {
        for (int JFejhCnlZnrmB = 57959388; JFejhCnlZnrmB > 0; JFejhCnlZnrmB--) {
            vPVqWzvWf /= vPVqWzvWf;
            vPVqWzvWf *= FyRscsMMZSH;
        }
    }

    for (int QhLjwrblXcIFQOV = 543525745; QhLjwrblXcIFQOV > 0; QhLjwrblXcIFQOV--) {
        nEygizhbwBbYU *= FyRscsMMZSH;
    }

    if (pPPgNFSKtK != -1827345044) {
        for (int sbRkVCtKTh = 1067900830; sbRkVCtKTh > 0; sbRkVCtKTh--) {
            pPPgNFSKtK += pPPgNFSKtK;
            FyRscsMMZSH += pPPgNFSKtK;
            vPVqWzvWf -= pPPgNFSKtK;
            pPPgNFSKtK = pPPgNFSKtK;
            vPVqWzvWf += vPVqWzvWf;
            MzcswO = WTdURDAjSWCJP;
            nEygizhbwBbYU *= pPPgNFSKtK;
        }
    }

    if (FyRscsMMZSH == 1680660362) {
        for (int zbEyRyKST = 1393782281; zbEyRyKST > 0; zbEyRyKST--) {
            FyRscsMMZSH -= FyRscsMMZSH;
            uPRQDtexTvDdt += MzcswO;
            WTdURDAjSWCJP = uPRQDtexTvDdt;
            uPRQDtexTvDdt += WTdURDAjSWCJP;
            pPPgNFSKtK *= FyRscsMMZSH;
            FyRscsMMZSH *= pPPgNFSKtK;
        }
    }

    for (int mJJEdxjEtXMMru = 158456911; mJJEdxjEtXMMru > 0; mJJEdxjEtXMMru--) {
        vPVqWzvWf += vPVqWzvWf;
        nEygizhbwBbYU = FyRscsMMZSH;
    }

    for (int oRUDqBkDdHbBz = 716871811; oRUDqBkDdHbBz > 0; oRUDqBkDdHbBz--) {
        FyRscsMMZSH -= vPVqWzvWf;
        vPVqWzvWf -= pPPgNFSKtK;
    }

    if (FyRscsMMZSH < -1011803700) {
        for (int TBwaNyrxtDyexfB = 1867180435; TBwaNyrxtDyexfB > 0; TBwaNyrxtDyexfB--) {
            MzcswO = MzcswO;
            WTdURDAjSWCJP += uPRQDtexTvDdt;
            uPRQDtexTvDdt = WTdURDAjSWCJP;
            vPVqWzvWf -= FyRscsMMZSH;
        }
    }

    return uPRQDtexTvDdt;
}

string ljSTGpXPupg::ELuulq(string CXugzWoBbLqJ, double PTwZFAFiRjnZtq, double dFWvHQX, string WtJnuEYhQBgaR, int mNomhQnV)
{
    bool pvhpZmv = false;
    double fqPYytlfzMEYRu = 982711.6579808771;
    string aCIejxaosfxgOaII = string("LnrBjUveavBrSnnvkTnAAjPfrkxgxIhITDmhCLQeeJUvWfqIDSwsXcFdKVgWpilhGheGdAFRzTTJzQQGoRQocByzLeBkeQcjrrYWjaZFaXYsqKyGYVXCZebiTGuKEWoySAAfZCZoBzSgllJUiBEmxJsMGzPUkPUjTOKacL");
    bool HDgSu = true;
    bool MatqsJLcbpoT = false;
    string cMBXZsvIkjaGgpTz = string("hgOIOndmrhPgaVMbdzFiOIDWVPaxCDArSdiDjLncAZPuRaJivImseKBwuXylajthVGpYcuPFhkEkgHMDhgFOfgspBJIYCsHeiDCJktkdPsqUhhPGxtpZKwCjFmHBBxUluvKMPLRGvgoNaLobPbhEoxReqjbLSusDNkTSjvvUnoRuKceQALtmSUTDCNTFUmFLjlBAStIBtVDJjcSUqk");
    double LAsihqou = -299072.75622815883;
    string soGnsZoFNpttFcW = string("kPHeFRusOJiEqerBYrlHMrJVaQPLFhPMmTBGbclpMlRMrYtIkjvSVzxQlcTSrdFybaVPfmnajyBUAIX");

    for (int yLcaClEzdj = 69582405; yLcaClEzdj > 0; yLcaClEzdj--) {
        cMBXZsvIkjaGgpTz = cMBXZsvIkjaGgpTz;
        aCIejxaosfxgOaII = soGnsZoFNpttFcW;
        dFWvHQX -= LAsihqou;
    }

    if (dFWvHQX != 982711.6579808771) {
        for (int VTMZK = 1948185047; VTMZK > 0; VTMZK--) {
            continue;
        }
    }

    if (fqPYytlfzMEYRu > 982711.6579808771) {
        for (int lzSxahPvqKItqDi = 2110184974; lzSxahPvqKItqDi > 0; lzSxahPvqKItqDi--) {
            continue;
        }
    }

    if (mNomhQnV >= -2141361555) {
        for (int KDcGDWPgVSZkhIDz = 929424072; KDcGDWPgVSZkhIDz > 0; KDcGDWPgVSZkhIDz--) {
            cMBXZsvIkjaGgpTz += aCIejxaosfxgOaII;
        }
    }

    for (int FLziYHpcZKk = 1844621398; FLziYHpcZKk > 0; FLziYHpcZKk--) {
        HDgSu = MatqsJLcbpoT;
        HDgSu = HDgSu;
    }

    for (int yLeCOKIq = 338099150; yLeCOKIq > 0; yLeCOKIq--) {
        soGnsZoFNpttFcW = aCIejxaosfxgOaII;
    }

    return soGnsZoFNpttFcW;
}

ljSTGpXPupg::ljSTGpXPupg()
{
    this->IluqumRpVjeocWzE(true, -815558.59397205, true);
    this->pwvNHxJAc(string("dbSKFidulACFECSLVpGRAMeGTrvlcLunJYQFYsUeMOKWQNnnkNjlSZEPoSKzOMfkcmMJEUXKLCAnjCqRDjJkwKosOYPUHIyWqccv"), true, -1634386916);
    this->eDGOLWuYLxMSDM(string("uTFQlQOxXvVYqaOhdWviZsXgnRyVGsiWhhEdXTzZnTBmuvLDjyJgfsUWoAzsnuTutOeSsfzGgDoSgrrkGLZTbEyqtNkxilKpJdLZDBUNofhIBbckyDcAcctQwyQIeTbUtdOWGihRZZuAQdxSKKVGjZVNPWgRITnocLaUgPsKyOdVGyGSEDtZMOol"), true, 1771910433);
    this->miwrJMSliSVEgDq(1881318420, string("UMDwhDWihfzSYZpwcoPavArohBKqGpmpvvGBIkukxBvFudfJFMGaltkDKLULhOHeZZgrUcsZHgTaGTYTpoOmNuTqKhdLiDpQXyqGqWaiUxLTgHQiiGseqjdPvhYncdQBfcRPoHlOZN"), string("qnUFoBbxMdvXhRUBUqYtzhFdnorGoHBxZjBrCkPvqbzNzKCKqdVaWyMHOSRvUYaEOCgfkZMSiFsCRFqS"), true, -1703284161);
    this->yKdMBkw(string("jrRJJYEpUlTBdRLiOTATdwBkdpwatLQqgkOwOlIZSOBWmYyLOESAlEgorrqmZsrJbYnfIqQpqROdSVUPHPyKfMftIGfBZbhiwqhAicaAYMkvIUQSroIsHUMoAouSGcKVPzTRyvOvrtsagBCJKDyWEkbZEkJLVRwcVSqBUenqZMvtZAGNlUWSdKcpkdvbFFZpflyXAQdkwTvztmJqGGkRxLFKTfDLPPbqWwEAbhOyWdKgYeaxTsryGD"));
    this->uNiSVU(482348.8487437528, -1553826540, string("LdQIENdfVqDBpIGTOyaDSNxNMDULuVcJCSGCMADGKhDaAOWSdaSshNbzFDPDHbSeviIojqPFdQuZPkVbuMIXYeZv"));
    this->PtgERtpo(string("VPwAecQknZDxJhEDJNzBriWCZGWFvsNlucZHZyGbetTwWaJHIXFlazLkCfJoqWriyTnqqWnIlydWRjwpYMgxoanymyFjCcnTCypNiigAtgdHXwKpiSvUecpFCMxKVvfGeuyIKlfxrkZgELOvKrojvZdUXiqYxaJEyTLUaSuwPvPUMJOFEJGAMIyQQxxcvmdNNjAbyhhoAomYxlyNyAznPdBmDam"));
    this->CHXpIcyrKAa(false, 562634.9003959377, -219182.03558872308, true, false);
    this->RcuVyuyLn(string("xtAaMxSLntipzjVctUNMppcNKzpVqucGlCFnOhfOYyNxCrUSCWNaWMbtogdrhBIAVUeAuUjlsRMlBUwSeTYtGhqKCnFLssTHPDmaahZxuwVoZtRWCMMlaaRNRPPdoAWVvMLsCCjTBRbrsebgqUgGIazbUtWthkxKlrACPkUZnoclvTcbLXpArwdNAlxHhIDprvlNYxQQjfIWdXNUdTOJcwhzOaGCQ"), string("ECWUNRWxDJVMPMQPtLGlVtEugeIOeA"), true, 1037698.9686481413, true);
    this->QVkyQQ(-568540.2611080316, false, false, false, -368534.2690307916);
    this->eduXuRLUfqAzWOJ();
    this->LJeTqYD(string("YWzxmgTRhpSuUvCugXhDrTPHhgQuejMeESZXAbgotzYkJPQouSsTBWTWcuYMcVrtcbEGNUMjeiAlIPDUCsXEdkRPHRsMhVJXQiMwXpJxmOYCUGNoEplZvBYmPiMoBzzLNJiCcGbk"));
    this->AURzX(false, 19512.715984384555, true);
    this->iKNdkIAEWuQmpHXY(1759620487, -456662858);
    this->HUrjVpRmLbCLJngd(-341493796, string("CmvKJgytYJzUHJAbyEqBGXPARQkaCcYYYgtkDWcNCfbeKutBIoWhvUYWZVchcYKwjyYhmJoPDbaXXEszTVrQIoiNTUHsYzkYXKaiHVlTOrnKlKEDjaKWXwepdeSbOXihlQDbZOzkNzJOpRqcIQmHinMtRbUmkOyDKXwCHtqhceKhtfsuUUKt"), true, 2081276788);
    this->GFdzNkcR(false, 1529455686);
    this->LNmOUnhqcBoGlDU(277438.7335790128);
    this->HzbYyfytP(string("JQpLIvOsrLzrcYEAMTWgDFZfRowhHYnXuTCXMbxXXUjREmRMgncQPnmJgEjJLhDnjENdkQan"), string("ETatUVrKMZGKirXGGCowXooYIyOabhCEafPDSgZGmdkdjhoXKzZgyYVPdICQxHWTZoKAopBsYUJzScFnuFMuDGZQzSXCYSdUxRoNexaIQWDtfSsOlXvTUYmkBoNeWjfGotRiCVakUPGCfY"), 1991091634, 1680660362);
    this->ELuulq(string("JawdmiIiVDZgXOMYpJCxLmzpitVodhrReGZHOYUYxDdmBpwkMmYrIaQmeLrsaWHtIzdw"), 655672.4499148703, 939824.6064737708, string("FKckAtRKqLFqxtvmuyLvqMFLJPIaAORqNUsYylDemNxZMlLrgZBqwudJKxrCvFvqaYMRFstsnEGSmtmKfMktLMCLWQWHonoGKfefeKUcidlKxCyCRTjziFOXrQC"), -2141361555);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AZrpgsWUGmA
{
public:
    int hfTrWrzwFfYCqo;
    int XQLSVteiLcs;
    bool bWENXsBozD;

    AZrpgsWUGmA();
    double YWcOhOde(int nXmsJuEg, double EVwfOesDxXmUop, bool fpNVfwguA, double KSdmMaYnqKQVPX, bool JEHjDXBrLs);
    double DUFGCFD(string qwqSwANbABn, double IRbbLWgGfdyxbFSa, double hEjna);
    bool sIbkh(string dWXiIMJeGRdTaE, string xrNzbshpKoArFAlO, int UnnyTIRsjwqCcQnN);
    string zUpGcIsReorr(int osWfFMhEhju, double stHsFKMpW, string AUWmIKfHUUYPWqBX, int bMecLwdfE, bool rOkHu);
    double IapEaCJypJpHV(int eiuTOBgYKzFGP, int uCCpRoECdcWay);
protected:
    int hithyzrzhqXVo;
    double OXRfnYmBkwkS;
    double lRxsFNRLrWa;

    bool WfGherxJ(int vCIswbjtfxuYM, string vBXfQuTKQpRAmMhm);
    void WJljNK(int OawaNXAIG);
    void eOlMhareTlAIe(double NgLIa, bool SPROHKAojFRAuMv);
private:
    int bYApu;

    int MPlZSvQVWv(string exKcwyKrLtlF, double jWagZUNwD);
    int XTrObnNNZEdHj(double NSpyogKmbngH);
    string KvWBnn();
    int qlEDp(bool XvoyXxpRmUMj, bool lrtNpwxxYMAN, bool WudCrHApkj, double dsojhKdG, int hNorGhohwBLuvSN);
    bool bnComYXYLdHbpgH(double XDGBvfpipO, string isHLZR, bool OOpfTnqtPHLNdyu);
    bool SxDqzYQfVoos(int BntKGsrsRzAu, string gqJql);
    int dhlMPHAvek(int JjlvJZSraa, double PbeVtiuuHINy, string fjCIcqMai);
};

double AZrpgsWUGmA::YWcOhOde(int nXmsJuEg, double EVwfOesDxXmUop, bool fpNVfwguA, double KSdmMaYnqKQVPX, bool JEHjDXBrLs)
{
    string LzTYCTS = string("HrgKQWiXLHPDqaUqbnkUyHXLUicPoPMVoXJkiBEMzNolcskGsekmukBMoIIaQMKOjaWjmLNVQOvxUpwxHxLcrDsYFukrfMooPd");
    bool fcImK = false;
    int fxwCPsJZvkVbNAnM = -2076369452;
    string ebJWecyoagbl = string("smRyRLuBlEzOAuZGGENItSjegSFKgOdFscoblBQPsGDHiYjljDZmggaMhdAFTHDlxhPLhzhXFtmAghJFIpRrvVPufWfLYciFrGejDxUqcrCjEcTvjkkbQkaDAcmxjOVlQZPyrQxJTBdkkIQzgCAoJbroPBNWpvi");
    bool rQmFvsVM = true;

    for (int PyxaVOEVuDuYgJ = 1672601396; PyxaVOEVuDuYgJ > 0; PyxaVOEVuDuYgJ--) {
        fxwCPsJZvkVbNAnM += nXmsJuEg;
    }

    for (int JDUixeQsAGIyThhm = 928623210; JDUixeQsAGIyThhm > 0; JDUixeQsAGIyThhm--) {
        fxwCPsJZvkVbNAnM /= nXmsJuEg;
    }

    return KSdmMaYnqKQVPX;
}

double AZrpgsWUGmA::DUFGCFD(string qwqSwANbABn, double IRbbLWgGfdyxbFSa, double hEjna)
{
    int XJoOJbDpoPbXk = -922003677;
    double bUDXbmGdoWVwuC = 236583.6747604274;
    double XDJSoOa = -373652.4564298695;
    bool AGHpNuKgtm = true;
    int EKGsAYrDKQOLdPZ = -1382686979;
    int ueziJbSlSIVYuAOd = -124771125;
    int FmCxNyOVv = -1475589285;
    bool tTJgtSS = false;
    int fnFArNJWKiINLv = -1600642931;

    for (int kIPoeZQuqYLDEhCv = 789871135; kIPoeZQuqYLDEhCv > 0; kIPoeZQuqYLDEhCv--) {
        XJoOJbDpoPbXk += ueziJbSlSIVYuAOd;
    }

    return XDJSoOa;
}

bool AZrpgsWUGmA::sIbkh(string dWXiIMJeGRdTaE, string xrNzbshpKoArFAlO, int UnnyTIRsjwqCcQnN)
{
    bool uPxlOxZdhRhSH = true;
    string pDdhnXaklBxq = string("fRzuEyoRpsoPTxftlhXNcjIiUFIGBEoQVdzNnGATgOxZtHQicgzlRNHxALYieNcnGqAUqBnsWrcxhMjTMBDKusJnQvXniPQePyMWZLcjbSNoHCyXpFQoMVISnnvtmwEdQvTLTHgaxD");
    int OUdzHIznVbsadU = -914262915;

    for (int pFILTCBCZwwiPG = 2058236892; pFILTCBCZwwiPG > 0; pFILTCBCZwwiPG--) {
        dWXiIMJeGRdTaE += dWXiIMJeGRdTaE;
        xrNzbshpKoArFAlO += xrNzbshpKoArFAlO;
        xrNzbshpKoArFAlO += dWXiIMJeGRdTaE;
    }

    if (xrNzbshpKoArFAlO <= string("fRzuEyoRpsoPTxftlhXNcjIiUFIGBEoQVdzNnGATgOxZtHQicgzlRNHxALYieNcnGqAUqBnsWrcxhMjTMBDKusJnQvXniPQePyMWZLcjbSNoHCyXpFQoMVISnnvtmwEdQvTLTHgaxD")) {
        for (int Mmwyc = 1160074811; Mmwyc > 0; Mmwyc--) {
            continue;
        }
    }

    for (int FlVchuUifCaJF = 1419862554; FlVchuUifCaJF > 0; FlVchuUifCaJF--) {
        OUdzHIznVbsadU /= UnnyTIRsjwqCcQnN;
    }

    return uPxlOxZdhRhSH;
}

string AZrpgsWUGmA::zUpGcIsReorr(int osWfFMhEhju, double stHsFKMpW, string AUWmIKfHUUYPWqBX, int bMecLwdfE, bool rOkHu)
{
    double ZNtlAdXgWAKAOJj = 269738.77579323354;
    string TzedDGBEc = string("qbDotYJAiUeZuajeHfkTspvoyqUryvahtfPWIDrjPMtTyEdGaeelNaaRARkaxqLkyGLBPntBwXyeqWjMFRxEmDMTEOsnhyRHMtRSRzxrsyGoAZRXCpxtBYDghzqsrZWfEGqOfVOorCebszKnagyHcehdTdCElBXpgWpFtTlzJvcUuaztOHFrNjfXjxHuHoFxyoKLsVtQmCHtpjueQZAvLrdEaGQ");
    string ojEhXeJaULKmzy = string("hqwUERjHBZYJL");
    string jQsTUPVEee = string("ThEyEZlJGzHtntRdpOIwqISBujPCSUrbCcgJvblZOKjUGkDDbwdTLKhFYGimFdDtXwAXARCGMwLoPWdimcDRAcolaPzFzzierPwnqpuWmKenECrKZRQSynOPlLTtQ");
    int GqeiUfWoH = 1899114310;
    int mbTRFzZcEXcIi = 1852002870;

    for (int vVivHEqUwNWxEpRO = 42512326; vVivHEqUwNWxEpRO > 0; vVivHEqUwNWxEpRO--) {
        bMecLwdfE -= osWfFMhEhju;
        bMecLwdfE = osWfFMhEhju;
    }

    for (int jxgahKUAyx = 594354264; jxgahKUAyx > 0; jxgahKUAyx--) {
        osWfFMhEhju /= bMecLwdfE;
        osWfFMhEhju = osWfFMhEhju;
        AUWmIKfHUUYPWqBX += jQsTUPVEee;
    }

    return jQsTUPVEee;
}

double AZrpgsWUGmA::IapEaCJypJpHV(int eiuTOBgYKzFGP, int uCCpRoECdcWay)
{
    double pMhgGlSLltRbzII = 284956.7934918697;
    int LSbtFxVtM = 1873676087;
    int ENsiIc = -327866202;
    string DFIKCsF = string("DfsWsTfeWCRcybtzHbVvCexSDbRETPgcoCaNAVqvZswqfGobfRfcEQrBrWlhyapsKcKIWIDQBqytpTcmBNEYLcQoGxqDVWVtkFGrapKIFYMlUvTBDVXpKUmrARUqnctyibyToiywJoiNjLXIZgaQ");
    double dTaNDByCJhGjHC = 610105.7529970354;
    double zqZsZCpQF = -932116.8917575375;

    if (LSbtFxVtM == -327866202) {
        for (int jHmQGi = 128204009; jHmQGi > 0; jHmQGi--) {
            zqZsZCpQF /= pMhgGlSLltRbzII;
        }
    }

    return zqZsZCpQF;
}

bool AZrpgsWUGmA::WfGherxJ(int vCIswbjtfxuYM, string vBXfQuTKQpRAmMhm)
{
    bool IkbpjAtXiZFbnRfy = true;
    int dzxMEPVgFIit = 1385154736;
    bool gIeLaO = true;
    string dAOStMbvpNWaC = string("zkNlbUDeDVyBMRxWvkHtOjcariyTwDuBctNhwthURjpTGOxbMbSTBTpvKaDbqVfUQhptpNFlwpUUJrJGtpXKsOXNwkNuRXSsvkovSCWapdLEQyCYgKugvqfbltsSjYfAVOsNaUgatzxmFndgbTBdmSNBcIVtVJmpOuPJMZnlRyoYWGidGzlEbfuxjSPOHOHtqpQljthnspgWvkNnBcsCoWJAflox");
    string BatrNeNkM = string("WQZJmtApmGrmHlLjerFOwibYpQcLcANcXUeNnHwNfeQtsoZLHfasvGlByWpjWPiWRztcSeLvNBMJpUTwFrAZtaYgFrWPJIkXYgXsXdNJQYlNAiEPKyMKMttqaGggBLsyHZJZGpOEARvRMxXvomEdwqxlZBZfLdR");
    int PrTMudiPcAwJ = 973971647;
    bool ObbHSeVtMPfzIY = false;

    for (int jRgyBjvEwHuyzw = 657550830; jRgyBjvEwHuyzw > 0; jRgyBjvEwHuyzw--) {
        dAOStMbvpNWaC += vBXfQuTKQpRAmMhm;
        vCIswbjtfxuYM /= vCIswbjtfxuYM;
    }

    for (int gokjcloqgztEyT = 287016203; gokjcloqgztEyT > 0; gokjcloqgztEyT--) {
        ObbHSeVtMPfzIY = IkbpjAtXiZFbnRfy;
    }

    if (BatrNeNkM > string("WQZJmtApmGrmHlLjerFOwibYpQcLcANcXUeNnHwNfeQtsoZLHfasvGlByWpjWPiWRztcSeLvNBMJpUTwFrAZtaYgFrWPJIkXYgXsXdNJQYlNAiEPKyMKMttqaGggBLsyHZJZGpOEARvRMxXvomEdwqxlZBZfLdR")) {
        for (int CgkFwymnB = 258039098; CgkFwymnB > 0; CgkFwymnB--) {
            gIeLaO = IkbpjAtXiZFbnRfy;
        }
    }

    for (int gJZJKEfRjrZFwp = 1214112933; gJZJKEfRjrZFwp > 0; gJZJKEfRjrZFwp--) {
        continue;
    }

    return ObbHSeVtMPfzIY;
}

void AZrpgsWUGmA::WJljNK(int OawaNXAIG)
{
    int neWKSLjqykJ = 1540215830;
    string XngqItVFUbtRbYHn = string("DRpRSrb");
    int iwttPaGyLGBOKUg = -603861106;
    bool QIaoMBFZceKFF = true;
    int xmKwwNqNR = -771510784;
    double QRVOpwU = -381516.61226691684;
    bool tfPJswk = false;

    if (neWKSLjqykJ > -771510784) {
        for (int DTCBlm = 1773029493; DTCBlm > 0; DTCBlm--) {
            OawaNXAIG -= xmKwwNqNR;
            QRVOpwU += QRVOpwU;
            OawaNXAIG += iwttPaGyLGBOKUg;
        }
    }
}

void AZrpgsWUGmA::eOlMhareTlAIe(double NgLIa, bool SPROHKAojFRAuMv)
{
    bool EgMHACyMIksxg = true;
    string FMRUf = string("rrKQDvKYRdnAiXSGzJllkmghXKNJYUMpenkCAeFAUuMPGDpNGFkoepWRgQkmddNxdMRVzTNYkKxfazNdTdiqhZVJNgLEiJnlOsBpWQXohluRGPEdBxqHyWqamFgiuUfelYUHwvnKBNlcETKnbytmUmCcPacBvvLmSUUoeyEyey");

    if (SPROHKAojFRAuMv != true) {
        for (int GfeUIOHDFLhgBT = 90416095; GfeUIOHDFLhgBT > 0; GfeUIOHDFLhgBT--) {
            SPROHKAojFRAuMv = EgMHACyMIksxg;
        }
    }

    for (int eLSRerDHSCAmrtnS = 887874922; eLSRerDHSCAmrtnS > 0; eLSRerDHSCAmrtnS--) {
        EgMHACyMIksxg = EgMHACyMIksxg;
    }

    for (int qxTLWNQdfHkIL = 255002457; qxTLWNQdfHkIL > 0; qxTLWNQdfHkIL--) {
        NgLIa += NgLIa;
    }

    for (int cyghI = 1067604386; cyghI > 0; cyghI--) {
        EgMHACyMIksxg = ! SPROHKAojFRAuMv;
        EgMHACyMIksxg = ! SPROHKAojFRAuMv;
    }
}

int AZrpgsWUGmA::MPlZSvQVWv(string exKcwyKrLtlF, double jWagZUNwD)
{
    int ZaiXgFeEoU = 1349682718;
    bool wHJhy = true;
    int xnIGDPqDiZNb = -1528169624;

    if (exKcwyKrLtlF < string("dIqzoFIsYepQzyNxrYbwjwGnYkDnmrUPoHTHRkrnCZckGHjLWQwZXRRItgrLhmYpoJJJFXYxRqAGOWMCBXEQNLDlNoNgyViQNgvgdqVdAwDtshhuOjdQXgaiJ")) {
        for (int FvTpEVHwpGWzavEJ = 606205661; FvTpEVHwpGWzavEJ > 0; FvTpEVHwpGWzavEJ--) {
            exKcwyKrLtlF += exKcwyKrLtlF;
            xnIGDPqDiZNb /= ZaiXgFeEoU;
        }
    }

    for (int HLJZfUFsPUXvk = 275510163; HLJZfUFsPUXvk > 0; HLJZfUFsPUXvk--) {
        continue;
    }

    for (int puXDghqA = 1503947429; puXDghqA > 0; puXDghqA--) {
        continue;
    }

    for (int pBjSvXYxt = 164171962; pBjSvXYxt > 0; pBjSvXYxt--) {
        ZaiXgFeEoU /= ZaiXgFeEoU;
    }

    return xnIGDPqDiZNb;
}

int AZrpgsWUGmA::XTrObnNNZEdHj(double NSpyogKmbngH)
{
    double akmcrDCudkhX = -86931.66235267537;
    string KPhimGGeizvnNv = string("ysWePTTfLeVEFnbeVjhJjbjVQmklpyCzaqynzLjcwfwuCSSabzZnnxEWOo");
    bool zEKzkstFBA = false;
    bool BOAIsGkZfGE = true;
    bool ZPKDxJ = false;
    string GmqfaIMsDJWY = string("pSrNeDFLpFRDYVZTbiAhthcqfguBkQJDcgsstQPPezBXgHUflLscdwfdeGpdnYctfpCVQaKcszgSvshjDWJIHiaLwhDuypqLkhfsjpuYrmsdMcsuTnDnpqyfZMPCfUuTqtQJbWSahqSBkWOaZtvygaIeaQRXASXRNgogWCHMTiJRqwhNpCIipmQvzwXMoKjcLIlewRnjlLbknJgeLEwaFgMKXvkzZCONjU");
    bool oXAJwAbVuhj = false;
    double EhFXx = -178303.92497789563;
    int LESMvVArpvU = -950488709;

    if (oXAJwAbVuhj == false) {
        for (int AaKobiiQeNBG = 301987940; AaKobiiQeNBG > 0; AaKobiiQeNBG--) {
            GmqfaIMsDJWY = KPhimGGeizvnNv;
            zEKzkstFBA = ! BOAIsGkZfGE;
            akmcrDCudkhX += NSpyogKmbngH;
            ZPKDxJ = ! ZPKDxJ;
        }
    }

    for (int OjiyZnFVpnjXQm = 1921171427; OjiyZnFVpnjXQm > 0; OjiyZnFVpnjXQm--) {
        BOAIsGkZfGE = ! BOAIsGkZfGE;
    }

    for (int kLLSSuZJgXR = 607161982; kLLSSuZJgXR > 0; kLLSSuZJgXR--) {
        continue;
    }

    if (NSpyogKmbngH > -178303.92497789563) {
        for (int meryxacqyHevVN = 641847016; meryxacqyHevVN > 0; meryxacqyHevVN--) {
            akmcrDCudkhX = EhFXx;
        }
    }

    if (NSpyogKmbngH < -178303.92497789563) {
        for (int FYeglw = 861513826; FYeglw > 0; FYeglw--) {
            continue;
        }
    }

    if (NSpyogKmbngH == -86931.66235267537) {
        for (int lUGYeNdAfr = 1043049731; lUGYeNdAfr > 0; lUGYeNdAfr--) {
            zEKzkstFBA = ! oXAJwAbVuhj;
        }
    }

    return LESMvVArpvU;
}

string AZrpgsWUGmA::KvWBnn()
{
    double TKnvqYCNWlSG = -435415.37237181806;
    bool zZXtieiN = true;
    bool ZHyOCArjZmNSaR = true;
    double OnruncSpgJtp = 376274.4848276075;
    bool CShCs = false;
    double UwqrMenQ = -363781.960130667;
    bool WHBVNer = false;
    bool MHRyShnff = true;

    if (UwqrMenQ > -435415.37237181806) {
        for (int huStDlg = 661951752; huStDlg > 0; huStDlg--) {
            zZXtieiN = WHBVNer;
            MHRyShnff = CShCs;
            zZXtieiN = ! ZHyOCArjZmNSaR;
            MHRyShnff = ZHyOCArjZmNSaR;
            MHRyShnff = ! zZXtieiN;
            OnruncSpgJtp += UwqrMenQ;
        }
    }

    for (int mIASdFhbBLYmFl = 1711420049; mIASdFhbBLYmFl > 0; mIASdFhbBLYmFl--) {
        continue;
    }

    if (CShCs != true) {
        for (int qVBksO = 645352576; qVBksO > 0; qVBksO--) {
            TKnvqYCNWlSG += OnruncSpgJtp;
            TKnvqYCNWlSG += OnruncSpgJtp;
            WHBVNer = ! ZHyOCArjZmNSaR;
        }
    }

    if (UwqrMenQ < -435415.37237181806) {
        for (int mzrBeW = 1322163095; mzrBeW > 0; mzrBeW--) {
            CShCs = ! ZHyOCArjZmNSaR;
        }
    }

    return string("pvjbRzoYDrPkGqkkKzPMQTsLlgbxYehzNNatKeliyljmQAKMFKHxHOAkmxCerIzzOLNxhEMrZrVugOadqQcLRBJXQRzpSniIhXrUUkeMDTToIJzbTnkLxVayMbTkwPyohtDUEgBObscDHkNgMMqMrKJEfrbWlBLdOOxTJrwHSLuPAKxk");
}

int AZrpgsWUGmA::qlEDp(bool XvoyXxpRmUMj, bool lrtNpwxxYMAN, bool WudCrHApkj, double dsojhKdG, int hNorGhohwBLuvSN)
{
    string lfHxkkwLUItOXWrV = string("rbrvvhvZROxUtDMrLQxlLSIrLAeEpHZOLrDQaxGzNMmysDFJuLssZeTndRUiVQUDykZLyqWeYrIihBwlJAydyNBmeWCZCeAoOngQKoYAkTGU");
    int BVDaB = -628171184;
    double NOAZWAnMNTPc = -892841.3848287917;
    double LeiVutZkJbzlgZ = 118180.11715140572;
    bool JOrreHJTFt = false;
    double CvAkvxIOfWuhkkUv = -388970.5355248121;

    if (dsojhKdG >= 118180.11715140572) {
        for (int ykURwpExCQ = 503505222; ykURwpExCQ > 0; ykURwpExCQ--) {
            continue;
        }
    }

    for (int uxvMlZjWIoQp = 25210303; uxvMlZjWIoQp > 0; uxvMlZjWIoQp--) {
        JOrreHJTFt = WudCrHApkj;
    }

    for (int WvlNzb = 1381717795; WvlNzb > 0; WvlNzb--) {
        LeiVutZkJbzlgZ += NOAZWAnMNTPc;
        XvoyXxpRmUMj = ! XvoyXxpRmUMj;
    }

    for (int JqVGLvHDfjjipJ = 1099167036; JqVGLvHDfjjipJ > 0; JqVGLvHDfjjipJ--) {
        LeiVutZkJbzlgZ *= dsojhKdG;
        CvAkvxIOfWuhkkUv /= NOAZWAnMNTPc;
    }

    return BVDaB;
}

bool AZrpgsWUGmA::bnComYXYLdHbpgH(double XDGBvfpipO, string isHLZR, bool OOpfTnqtPHLNdyu)
{
    double HJjOUkyi = -268849.5805002835;
    string ZEzJqKuHzxA = string("bOhdJQAUSmsBqtVTOxmPJXpqr");
    double byaXF = -182217.13691776438;
    int zljlIodHqFfM = 1163750753;
    int Jflhiasn = 1099759309;
    string TeIlL = string("RjAsacxxlacOPnhDsWKJeTEEsXsFGQObFzfIHPYVzFIiBhLZhOKDKGkyOtvguGCCYWfPYPxQhrxhfsscFukEkvlmorPRWJtrcgnjiGwLtZueDcjwWPoiBANFexrTSFAllmUQ");
    double NKnzyVN = 307873.17358462245;

    for (int pXGKtQVYCTq = 1121658061; pXGKtQVYCTq > 0; pXGKtQVYCTq--) {
        continue;
    }

    for (int YSzUNZvdOG = 1972818443; YSzUNZvdOG > 0; YSzUNZvdOG--) {
        isHLZR = TeIlL;
        zljlIodHqFfM += zljlIodHqFfM;
        HJjOUkyi += NKnzyVN;
        NKnzyVN -= XDGBvfpipO;
    }

    for (int nlokJQQUuPYDo = 834668089; nlokJQQUuPYDo > 0; nlokJQQUuPYDo--) {
        HJjOUkyi /= XDGBvfpipO;
        XDGBvfpipO *= NKnzyVN;
    }

    if (NKnzyVN > -182217.13691776438) {
        for (int FNflsPYfrfbeXmH = 864988756; FNflsPYfrfbeXmH > 0; FNflsPYfrfbeXmH--) {
            XDGBvfpipO = HJjOUkyi;
            byaXF += byaXF;
            XDGBvfpipO = XDGBvfpipO;
            OOpfTnqtPHLNdyu = OOpfTnqtPHLNdyu;
            TeIlL += TeIlL;
        }
    }

    return OOpfTnqtPHLNdyu;
}

bool AZrpgsWUGmA::SxDqzYQfVoos(int BntKGsrsRzAu, string gqJql)
{
    string wvzMQnfiAJ = string("JUCxYjUxRmroEjpTydaNGQktMFspNZCztZaNfuxvXqUTxMxnNIcbkEPGXyUBlgGILRoQeBGSJGLXTEvuXUucdMiseZixTTiAgipQttPlHWgNcsRymEBLofGvmJPujwhhGvnAAGVziMnXAoMQQctZGBScgNkzRtWdANykfKLWIUVhvNNhYTlcztqDeyeCcPECLkPBKzPRZzDIuIbFVGzLfrwFapVyijxTBETJjgXRyOwDFvuuiTisYu");
    int ylMyoKRGSQYtsr = -1902194253;
    bool UmUktupmS = true;

    return UmUktupmS;
}

int AZrpgsWUGmA::dhlMPHAvek(int JjlvJZSraa, double PbeVtiuuHINy, string fjCIcqMai)
{
    double rHscOvAuqXDJhHJ = 576718.8649832045;
    bool lVzVVlnhIELa = false;
    int TkFIpKq = -946531143;
    double wnOcfdEPdnV = 601655.4443435727;
    double zKRNgWN = -862456.5384980914;
    double HtfmAaUM = -1015268.8110510339;

    for (int PsZpRBTyqrgWuDe = 1780309036; PsZpRBTyqrgWuDe > 0; PsZpRBTyqrgWuDe--) {
        zKRNgWN -= wnOcfdEPdnV;
        PbeVtiuuHINy -= zKRNgWN;
        PbeVtiuuHINy += HtfmAaUM;
        fjCIcqMai = fjCIcqMai;
        wnOcfdEPdnV *= zKRNgWN;
        wnOcfdEPdnV = wnOcfdEPdnV;
    }

    if (PbeVtiuuHINy < -862456.5384980914) {
        for (int YlqGsLUkxsuY = 802892519; YlqGsLUkxsuY > 0; YlqGsLUkxsuY--) {
            PbeVtiuuHINy += zKRNgWN;
            zKRNgWN /= zKRNgWN;
        }
    }

    if (HtfmAaUM > -1015268.8110510339) {
        for (int dBiPopPyHeYAwdT = 1382884463; dBiPopPyHeYAwdT > 0; dBiPopPyHeYAwdT--) {
            JjlvJZSraa *= JjlvJZSraa;
            TkFIpKq /= JjlvJZSraa;
            HtfmAaUM = HtfmAaUM;
        }
    }

    return TkFIpKq;
}

AZrpgsWUGmA::AZrpgsWUGmA()
{
    this->YWcOhOde(-188286221, -714910.2325470883, true, -1012177.3727892027, false);
    this->DUFGCFD(string("WhbNiZoJHIxinrPgnVulgXlOnlMiVLVZCRUOztlhqHEaNPSirRKKAJCpbSMWtKVpotsrMFnavgNSzvgMjWoRCehleKzDgpoiLmFhuDFSDxRzUXRWfIJfQIRTpSpaopLPiPtanOwyHSQUWtjjGwgwpwOaLMIeEstjLWoOSwkjaE"), 466919.36763845227, -510725.10729358706);
    this->sIbkh(string("nRljCueejVfLAzuvUdvVEZqcQPQvDiwhGBaqXCMiuZppCAywoLJgrVChTesWxicNIAPJsijjdQ"), string("hIZwLbzhljEjhEiVLQlzJFiuANKasOIJtiRuomXAYbtMTRyIPJOvONHIQepKcw"), -257880370);
    this->zUpGcIsReorr(1705344662, 266181.1553753958, string("ZjkKpcEZsIfNzCmnjsiujvNrYMKvHXUqkeeNNoNKgIzYJIcaLTSIDHqFScdCHpTKWUFoRIzmoQJtVXWdYFDFtmbtsywivLGgqxzweVvLNvwIvLRroKXdyEqTDHmIcceiqNu"), 111226222, true);
    this->IapEaCJypJpHV(1296351615, 1098045214);
    this->WfGherxJ(1144102725, string("yiFgVNjNnaqyvkCJmxPIJdGYcEYrZKElBsOzWKACdYpNqGVvHhy"));
    this->WJljNK(-313165572);
    this->eOlMhareTlAIe(-658079.0364210027, false);
    this->MPlZSvQVWv(string("dIqzoFIsYepQzyNxrYbwjwGnYkDnmrUPoHTHRkrnCZckGHjLWQwZXRRItgrLhmYpoJJJFXYxRqAGOWMCBXEQNLDlNoNgyViQNgvgdqVdAwDtshhuOjdQXgaiJ"), -154778.6384178499);
    this->XTrObnNNZEdHj(187480.96481017378);
    this->KvWBnn();
    this->qlEDp(true, false, true, 501213.5929093208, 1116524791);
    this->bnComYXYLdHbpgH(-550152.4749496817, string("DCzZWEfJGtVvEfMlxGMjgfipDNRqtoCF"), true);
    this->SxDqzYQfVoos(-118943149, string("cJGUfDFdGfppBAioZlSfoBKuIueEqiNVdNSBZduijkJUNScQhlWmWfoGzCYCKzuheKrihVklklYAoVpwfetpfQByqZtEdMBNdeLGkmDoVYJBofFagguRWVwjQqAdoOdcGBSWFwhcQdwIQvatVCMvKZBfWpmsMc"));
    this->dhlMPHAvek(-1094300320, 1016753.666029653, string("tLCMiqEDDtJzrZZChkqWgcLmMMYOvnxialhnuIfrbunLjppIbfOCLajZUKdflbzbOLuuivDdUjODIakDxNqjJJyNlyFjoBGdAAbyAwEWXBXROaUU"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yWRZRWNhGgi
{
public:
    int PQjeoJSgnL;
    double AFJkAnymoqImj;
    int yTPkyAOt;
    bool XlnLsiyCKa;
    double OYPkkjyOvwD;
    string lRwyrNByYR;

    yWRZRWNhGgi();
    bool NpfBtm(bool xBBkncWTLLUHfJ, string CDdOEZGvkj);
    int PjojzxKawi(double iaAeybzkTIXySOkm);
    bool iZjSnbKknZPkZ(double xDBdZpcKGKfQMFla, bool mFUzskfkzsp, string TKvDzHbGsQbbkaFM, string BdehTGH);
    int vTPdmNyJYiHWfqMX(int rfIocqjOcyYkdo, int ZRuVBjM, double vNyvIylkbcWFXqay);
    double SmtkMx(string pxnrIAfleDTOxdQ, double tEVvOhpMWu, int WEiILTuXJa, double vBBtuSR);
    double URdnEtblJtM(int EDGfDookBlBu, int qcJaK, bool qznxPFcX, double xZdrTZI, string OMihSZRDq);
    void GucEGWsdobFO(double oWUpDFCqPWgXkK);
    void ZehDPuAraEoyVFi(int zOIcTZvGVqHdkKGa);
protected:
    int xAJHUtoZEvaJtXIr;
    double cPEyZPEhLyV;
    double pFOcZBcYRkgVwnvu;

    void bRIxUgfJTfbsI(string XEiaiYRAap, int ifBsATtqogP);
    void RXJhRANTORjGgTNC(bool lFQQKwSZUOO, string DLSEhRDnYkXs, double MmbCxYSeDOrmTs, double VwAepMODOjjdtVzd, string ritnyhAiWd);
    int xXjVpcedXkfyg(double FKiFbdSMdhqLc, double LGXHWyfBpA, bool PFBCde, double uhgEqIHV, int kvIEwtE);
    int EQENcPaGJHZaGYv(bool qzjLCKJRLknzeCo, string WEXOt, bool qsMVzw);
    bool qMRrat(double xtEcZLVNQVPp, double FlFht);
    int SAciVgyFcgWPoUx(string mxNzynObxjGRt);
private:
    string ACWMAFQVMrKeWOD;
    double jzCkm;
    bool cBgkswSda;

    bool TMXBo(string ephywkKWm, bool PLOdKu);
    void OSYdkxPugKZbpmB();
    string KbzgbXWYhP(string gAJGhEyptpnQyyRJ, double NwXefxffeJqiv, string CkFzqSiuEtffy);
    string hWXcUMqLaICvOsY();
    double amvPPxRlZ();
    string WTLElStQv(string SltfoYMQdDqCjn);
    void ikLHhGPb(bool YWtMbxENZxTa, string uiNKkHNY, bool XwFvwvICcMZo, int azugQVWTu);
    string WPMifZiIFz(bool XAwRgm, double YkxyflVrw);
};

bool yWRZRWNhGgi::NpfBtm(bool xBBkncWTLLUHfJ, string CDdOEZGvkj)
{
    string cdMSSXRhoaUzLOMN = string("IjhzIRXDfxyZyXyUQeuJicffXVdLeHYjrSikOuOyacfRjYgkwptIJUOaXKQNThsmHFDHlbrldAueORLacrOyEzwRcsiINIUqLeOMfZbFmDcBPOKrBIFeIyVmjowVehEZSnEEwwfDVvYjlMtSDzjwMfqNuXYGTAbJCrFLLyXTpUyCiRzdCxuVJDZmYaKukZaOyiaroouBhPIDfySIRYKJpfKZFe");

    if (CDdOEZGvkj < string("TjzrCmhDbdBBfNMNeRqeTWTBthiTpWbvYlfzoqLTnnnPfZedPGVqRrKzMUucnktvoqgUJrGVPnmViDdFKzgyvXdjzxensYUXnTrvkCvktyorlFOSGNRNeQUZYNXbuFMBrIHcYqPbRvVPqKobJgZQPRilzOTBbHdktHnxrOMqaZaZKUIKHLaYcftCiIRfYKSUGxwZJOtdUYAswJJXarpArYITOnNVbwAKyFZQxnxAZpfgYIUDlPBWHaknzhVVktA")) {
        for (int riBEFt = 1423665326; riBEFt > 0; riBEFt--) {
            xBBkncWTLLUHfJ = xBBkncWTLLUHfJ;
            cdMSSXRhoaUzLOMN += CDdOEZGvkj;
            xBBkncWTLLUHfJ = ! xBBkncWTLLUHfJ;
        }
    }

    return xBBkncWTLLUHfJ;
}

int yWRZRWNhGgi::PjojzxKawi(double iaAeybzkTIXySOkm)
{
    int MbXVinXLRHXS = -2086577579;
    string GazObYjjlMQ = string("mFNtdggEIPjmjMWKzZISOcJRKKVUVHvAypYlJgXjgcJdYawEaUZniuILSNxSyNjeOtrjTFhnKPXluIYtoCbcxdRgReSQsntSGWqWzdQlNvXPDJFcIJGEfulCveORMaMHqCyWdETqliMCycyFAFdwVmX");
    string KxUYivoWjkvQd = string("xAJXLCWHIMdpDmNFYKCgvNxBYOHOgfhAmzqieCxyzuZwPPhkWpdwbtpkKQtkOVNfZWpQuSmqPwAEtTsEMwxDylvkKAahcSDvOTtWCiNotUJAIdaLcKUJLCtFdrXlpHwKHaMrJmVynnchUdqxwhAUpsjORpqddHnSxNUtdMTQfznQNZKQywXlCGDKbFRwGQeioSkIhoEXucFBebrQHGvg");
    string WCYpj = string("KOCOjRGcJeFPbfMcTdAJjwOIAAkNTaCkepfvRVwAwSqsgKYyZnBmaZkWVYEBpqMPjDffYpZmjONbuosdRJUTVJuRQhpQxOfyIDijEHtZdgvGZsIiRnRDoJqjaNjAhwLzXusNCrbTYiAePmKIocGKlPFHUdHONekxItXzvbMLKfToMaFFdChbFeXIBbUZiGqqsOTlNHUmArEKromyYtZfgwXeXNofslfAXieJVy");
    bool xQncKCfnRtZmOqPC = true;
    bool BrvnKsxQ = true;

    if (GazObYjjlMQ != string("KOCOjRGcJeFPbfMcTdAJjwOIAAkNTaCkepfvRVwAwSqsgKYyZnBmaZkWVYEBpqMPjDffYpZmjONbuosdRJUTVJuRQhpQxOfyIDijEHtZdgvGZsIiRnRDoJqjaNjAhwLzXusNCrbTYiAePmKIocGKlPFHUdHONekxItXzvbMLKfToMaFFdChbFeXIBbUZiGqqsOTlNHUmArEKromyYtZfgwXeXNofslfAXieJVy")) {
        for (int XOgGnFqhp = 1467611347; XOgGnFqhp > 0; XOgGnFqhp--) {
            xQncKCfnRtZmOqPC = ! xQncKCfnRtZmOqPC;
        }
    }

    for (int LzVBHjHCslUEOKpX = 1926916285; LzVBHjHCslUEOKpX > 0; LzVBHjHCslUEOKpX--) {
        continue;
    }

    return MbXVinXLRHXS;
}

bool yWRZRWNhGgi::iZjSnbKknZPkZ(double xDBdZpcKGKfQMFla, bool mFUzskfkzsp, string TKvDzHbGsQbbkaFM, string BdehTGH)
{
    string XNKVloNQEKtOh = string("cYVqMuKnAwKxBSCMrmBQHAVzKtCFNdheXsBnstdGIJMOEmayJflpPLmTWYrpTdQyBiWaQUBwcJqRGauKpTbisrLFEYraonXToLpwjZHagFoiOSNPLiKfQqAUAtxEyogTorVCu");
    double WMmkXAtARry = 45379.66008261174;
    bool GzDYzYFc = true;
    string lmrqYJ = string("OqKztwzfkrHoXITZcOvPJSDWXghzrULORDiZnlJShSNjeZsoWErRMspEIOUczEkRjGdVbFKFmAOesnFMhTMSWDvzxIrcjSvmuXMrqjNNdWIWHEBDnxbaPCdUCqoagJomHtrEqWsVyekkLI");
    double yZjRKr = 424045.5810240712;
    double rSuHSwVcHAfEWxHz = 912330.3645442714;
    int QdCMEIjVlgylr = -180740342;
    int TlDMztNLVBh = 296524435;

    for (int JwNikESRx = 1497652867; JwNikESRx > 0; JwNikESRx--) {
        TKvDzHbGsQbbkaFM = BdehTGH;
    }

    for (int eAWQunLoXiIzweKN = 2060844836; eAWQunLoXiIzweKN > 0; eAWQunLoXiIzweKN--) {
        continue;
    }

    for (int XZsfOeBYoOCDmXH = 322785201; XZsfOeBYoOCDmXH > 0; XZsfOeBYoOCDmXH--) {
        continue;
    }

    return GzDYzYFc;
}

int yWRZRWNhGgi::vTPdmNyJYiHWfqMX(int rfIocqjOcyYkdo, int ZRuVBjM, double vNyvIylkbcWFXqay)
{
    int VTlrxamuPrpRZCjP = 132687172;
    string ZBRjXvlhKzjb = string("TGJcMIYPttBLtPwWahsTCqjXEBhqHTXfwxOfAMRMQLfLHEDGPrMdCmprWfwkLbcjRXQWolAEvGSCWMwyVXDqZlrvzPCzkSDeLQktqYhHxTXaOuTgV");
    string SLavvhTXhTf = string("lFxXeWcdFZvvUqdtpIujoDinzkNeXucgfDHyNKcyCHrAGMIDUfJZfXPofrjBYUrIQEopmywixgIkiYAevKyuCkCGEmITqkIjySoIhFOhIcoFRAFdpiFGReEhYcamwRUtbMfFxxuQFMdqFWZFipTCCgDqhHYBPILHsyShKVqGVowIRUzkBcmqZXuMUGXitxjRzuLFvMPgISpMVNkgYCEZNrztnCaWHMrjYpFVcvuauvAObKhXMYlAFvGJodiVBx");

    for (int nvMVfZuqFVjCxib = 1208748069; nvMVfZuqFVjCxib > 0; nvMVfZuqFVjCxib--) {
        VTlrxamuPrpRZCjP += rfIocqjOcyYkdo;
        ZBRjXvlhKzjb += SLavvhTXhTf;
    }

    if (vNyvIylkbcWFXqay != 285309.4252482661) {
        for (int tyKSEFyqq = 1564179860; tyKSEFyqq > 0; tyKSEFyqq--) {
            continue;
        }
    }

    for (int nYDBjORWSByQY = 1188560168; nYDBjORWSByQY > 0; nYDBjORWSByQY--) {
        continue;
    }

    for (int qSmohziKvEhPjXTE = 1495535895; qSmohziKvEhPjXTE > 0; qSmohziKvEhPjXTE--) {
        rfIocqjOcyYkdo *= rfIocqjOcyYkdo;
        ZBRjXvlhKzjb += SLavvhTXhTf;
        VTlrxamuPrpRZCjP -= VTlrxamuPrpRZCjP;
        ZRuVBjM *= VTlrxamuPrpRZCjP;
    }

    return VTlrxamuPrpRZCjP;
}

double yWRZRWNhGgi::SmtkMx(string pxnrIAfleDTOxdQ, double tEVvOhpMWu, int WEiILTuXJa, double vBBtuSR)
{
    double yYZUbC = -863199.9206586628;

    if (vBBtuSR == 850747.5988943984) {
        for (int flUYXC = 1575823749; flUYXC > 0; flUYXC--) {
            continue;
        }
    }

    if (vBBtuSR == 850747.5988943984) {
        for (int iYBbUYd = 1774953426; iYBbUYd > 0; iYBbUYd--) {
            pxnrIAfleDTOxdQ += pxnrIAfleDTOxdQ;
            WEiILTuXJa /= WEiILTuXJa;
        }
    }

    if (yYZUbC != 850747.5988943984) {
        for (int JBwccAma = 989414688; JBwccAma > 0; JBwccAma--) {
            pxnrIAfleDTOxdQ = pxnrIAfleDTOxdQ;
        }
    }

    return yYZUbC;
}

double yWRZRWNhGgi::URdnEtblJtM(int EDGfDookBlBu, int qcJaK, bool qznxPFcX, double xZdrTZI, string OMihSZRDq)
{
    int HCFrMCPvl = -1336580210;
    string tYysnjlkffVuN = string("HJTmjCTijSgAPzyKfXXYnnAtzwrxVLgQFEAvVDklrLvxFtTAlXVXAhYqcyuffxqaPRRErarnGpcIOJYOpwHsqauGcTlgPUroQqmWtlNODhbtZLRhYvymIyA");
    string OoDPAtP = string("emXxSieosdjefptJzsppfxj");
    int mtwWaKJDxlr = 737130616;
    string JUQQSIjhJzzcKheK = string("RsMJlKHpbxhFkeOaaQycjJUGWyTHcbefLHRihbfRLuRSlXTfUGCotigExMmvTuGIKtEUdUPhHchiFKHCPItjhlWY");

    if (HCFrMCPvl <= -1336580210) {
        for (int gYuiCvLId = 939298772; gYuiCvLId > 0; gYuiCvLId--) {
            continue;
        }
    }

    return xZdrTZI;
}

void yWRZRWNhGgi::GucEGWsdobFO(double oWUpDFCqPWgXkK)
{
    bool CRhPBwy = true;
    bool HuVhGg = false;
    bool QDIwfSsMxM = false;
    int sKrizLaWTvANyw = 1134767028;
    string JnzyQY = string("MFYnufbkGgohEnyxGTeKGgMIycapUUpbuYwrtPCTZGuPSQbmuOlWvFfcYShRhiaogPoITXwrawUxaJdlmfTjIhSyfNeLUBgJsVqdIEBaDFtBhJRmdLNIGuuTFxMaDqjoMBskDAoYJeJVIatJhIRHcRrykmIEeoeIRkuCcHaSdjXGUTSfbByPTJABEcxzCgtnqVRB");
    int yPEsLSko = 900047993;
    double AzNifjgcL = 310021.36799423926;
    double BUwRHAhUIrwuFvD = 714199.3253513299;
    string XtMNQLGwGOOunI = string("PBNVBZuczlkNSSRcPOiEEQKPhBERBqDbEDjJHvAOfNDAGPqvtXVVMZYjCQuTEEeeormGIqkpSqOYdAyDkfcfUeXHfKMVutmuuBWYRFOFgBepAMxjJjLfzREehZeJTUFoDJsQBcXsFzLVjShrNyMzskPNsGnuJuZaBcmeDieVyzz");

    for (int YObdgkQvkBftodow = 749495717; YObdgkQvkBftodow > 0; YObdgkQvkBftodow--) {
        BUwRHAhUIrwuFvD += oWUpDFCqPWgXkK;
        CRhPBwy = ! HuVhGg;
    }

    if (XtMNQLGwGOOunI > string("MFYnufbkGgohEnyxGTeKGgMIycapUUpbuYwrtPCTZGuPSQbmuOlWvFfcYShRhiaogPoITXwrawUxaJdlmfTjIhSyfNeLUBgJsVqdIEBaDFtBhJRmdLNIGuuTFxMaDqjoMBskDAoYJeJVIatJhIRHcRrykmIEeoeIRkuCcHaSdjXGUTSfbByPTJABEcxzCgtnqVRB")) {
        for (int zSRXeZUcTF = 1206418849; zSRXeZUcTF > 0; zSRXeZUcTF--) {
            continue;
        }
    }

    for (int JuGddLlPECikSJFe = 460170961; JuGddLlPECikSJFe > 0; JuGddLlPECikSJFe--) {
        BUwRHAhUIrwuFvD += oWUpDFCqPWgXkK;
    }

    if (sKrizLaWTvANyw <= 1134767028) {
        for (int PKcKMpeF = 1280215390; PKcKMpeF > 0; PKcKMpeF--) {
            continue;
        }
    }

    for (int LmncaBCW = 1770225148; LmncaBCW > 0; LmncaBCW--) {
        BUwRHAhUIrwuFvD = AzNifjgcL;
    }
}

void yWRZRWNhGgi::ZehDPuAraEoyVFi(int zOIcTZvGVqHdkKGa)
{
    bool kRnlttlGMwMsdDs = true;
    int Gqskz = 1208942343;
    double qAJAmk = 430155.6529734707;
    double apKcoHCJlheJRWwz = 347675.57042246487;
    string iZAVlzJ = string("cNxwQlvpBZTgGkvAqlTxSnPdgZLoBURIJgvjrVZoMpnAiQosteUQCfbISsRCenrMgFsvFBbSJzTzHYqqLGitBiOKYUAgkWXhE");
    int fWfnKGJTYRLCxy = 1642819428;
    bool KjLgdJfrPIMMYhz = true;
    string uvnsxvYDMO = string("EABMlxWvTLdUlkHnaiXIrcemLyiZcTTxEsGAHNvvlMbxWNUQpftmacgnQyaqVxkREhkulNFcaSFtwjoTPzVpInEdNZdjcBfTwGzncxbipMrZFXBBSUGYiUC");
    double mZTitEWCR = -52167.18773702806;
    int xvAoQZbCcDuF = -1322939164;

    for (int TchtDOAYXXdqopX = 610828937; TchtDOAYXXdqopX > 0; TchtDOAYXXdqopX--) {
        mZTitEWCR /= apKcoHCJlheJRWwz;
    }
}

void yWRZRWNhGgi::bRIxUgfJTfbsI(string XEiaiYRAap, int ifBsATtqogP)
{
    int cmprX = -14591506;
    string WGCQS = string("QRBCjPDQedpNiLjUZnWeDPwbOpQVlIdqTkLuICiVVdHZQguytXCEWplnfUIjWVAsoIXTwsqZPqphEpSHHhoJVXkUDOJUDf");
    bool TcRUvlPLXXnunqA = true;
    string LmZUZQmrNky = string("xmxXSzNbbUzDBOqFGIeaqrauabraIWtsSppSwNFxnXhKyvFCbwowjZBEgvGBwpEjZvjajjKTnakwWKVEtDfeXn");
    string PZZGadjRAzOU = string("rgJIHehHtVFYvTlPmwcDAsOHduGrwRWTJPhSFNuYfeKyKpcJUPfFPtr");
    string bMnktxfqLXvdwZ = string("BXecyGragipIlxrblrhgOLlxndHewmSZfQvYIauXYIVEUEWuwUPRZySiZVjZzJYupWpUeJfmWNPDsRv");

    if (XEiaiYRAap < string("BMottHTSJyBtLHLpkvOrTXAEVCOYzPUaMinsAiSTOcqLYnHRKnnWiCYftOkBVdDmoCfXnxBwCLCQqaiESxFsWDEXstX")) {
        for (int DyDgVkFFy = 1498413542; DyDgVkFFy > 0; DyDgVkFFy--) {
            XEiaiYRAap = bMnktxfqLXvdwZ;
            bMnktxfqLXvdwZ = PZZGadjRAzOU;
            ifBsATtqogP = ifBsATtqogP;
        }
    }

    for (int qlgUP = 717429300; qlgUP > 0; qlgUP--) {
        XEiaiYRAap += XEiaiYRAap;
    }

    for (int hvQMOMhThjYuf = 1243708816; hvQMOMhThjYuf > 0; hvQMOMhThjYuf--) {
        cmprX -= cmprX;
        XEiaiYRAap += PZZGadjRAzOU;
        WGCQS += bMnktxfqLXvdwZ;
    }

    if (bMnktxfqLXvdwZ <= string("xmxXSzNbbUzDBOqFGIeaqrauabraIWtsSppSwNFxnXhKyvFCbwowjZBEgvGBwpEjZvjajjKTnakwWKVEtDfeXn")) {
        for (int yahgC = 1649506147; yahgC > 0; yahgC--) {
            cmprX += cmprX;
        }
    }
}

void yWRZRWNhGgi::RXJhRANTORjGgTNC(bool lFQQKwSZUOO, string DLSEhRDnYkXs, double MmbCxYSeDOrmTs, double VwAepMODOjjdtVzd, string ritnyhAiWd)
{
    string kTOeScM = string("oywFeTqYiTySisjjCZjZvbhnkmLLvqhemAICsVlUhPkeEmpPmpZPEBlGEkppYdIzUnQJqmnINjtzzpHjszWcZoiNJAfLEUbsBpLZBUSdxrFMMexZJCreognemyTiPmPKEBCAnfjyLWbvSSPrYIZBMQtIFIYROJkugPoBiNwvzHORXrvSVCweyVNtESfjumYHdCdMfQnNDdRcdHKQvDJoyohXKQpXukZjQigDhynmRGxeb");
    double aRYwrXQtjHdjiZ = -71274.08217478284;
    double UtFrZSrDjZtYPdxT = -19906.165598341093;
    int ycpHvTIoxgCBAWld = 1009471286;
    bool nDROLPUtZmApfW = true;

    for (int TQHuh = 1962301421; TQHuh > 0; TQHuh--) {
        VwAepMODOjjdtVzd = aRYwrXQtjHdjiZ;
        DLSEhRDnYkXs = ritnyhAiWd;
    }

    for (int bRTLARqfjqVPc = 941103056; bRTLARqfjqVPc > 0; bRTLARqfjqVPc--) {
        continue;
    }

    if (lFQQKwSZUOO != true) {
        for (int LFVdhEdgxBHbO = 50251704; LFVdhEdgxBHbO > 0; LFVdhEdgxBHbO--) {
            DLSEhRDnYkXs += DLSEhRDnYkXs;
            VwAepMODOjjdtVzd -= MmbCxYSeDOrmTs;
        }
    }
}

int yWRZRWNhGgi::xXjVpcedXkfyg(double FKiFbdSMdhqLc, double LGXHWyfBpA, bool PFBCde, double uhgEqIHV, int kvIEwtE)
{
    int PMkLWeLCqocIQSyM = 1922597626;
    bool WAAMWG = true;
    string bdLmVxmF = string("WkqnFmQEjKzAPGTvYfVdDMklJUMQjeyXHNPYBPpsXT");

    if (WAAMWG != false) {
        for (int EdbvFJERGyjVw = 1590379787; EdbvFJERGyjVw > 0; EdbvFJERGyjVw--) {
            kvIEwtE += PMkLWeLCqocIQSyM;
        }
    }

    for (int ECwKhlf = 1619883644; ECwKhlf > 0; ECwKhlf--) {
        PMkLWeLCqocIQSyM += PMkLWeLCqocIQSyM;
    }

    if (kvIEwtE > 1922597626) {
        for (int FNrbONNLhFYhV = 685550319; FNrbONNLhFYhV > 0; FNrbONNLhFYhV--) {
            kvIEwtE = PMkLWeLCqocIQSyM;
            WAAMWG = ! WAAMWG;
            PFBCde = PFBCde;
        }
    }

    for (int DJfoOEBiy = 1154769194; DJfoOEBiy > 0; DJfoOEBiy--) {
        kvIEwtE -= PMkLWeLCqocIQSyM;
    }

    for (int MeHti = 685011550; MeHti > 0; MeHti--) {
        uhgEqIHV *= LGXHWyfBpA;
        LGXHWyfBpA = LGXHWyfBpA;
    }

    return PMkLWeLCqocIQSyM;
}

int yWRZRWNhGgi::EQENcPaGJHZaGYv(bool qzjLCKJRLknzeCo, string WEXOt, bool qsMVzw)
{
    bool ZlHthXpGNUksN = false;
    int YCrZKvGTSuHsu = 338528888;
    bool HmhkCQCypU = true;
    string nHpMDfgzkYCF = string("HbyFPrurNdoCsW");
    double jDhbSn = 949020.7978240406;
    double SADprY = -847950.8118850024;
    double cDjetwoStzWONgm = -454838.7309999892;
    double KmhqPQsRDkPJafE = -216311.36670013852;
    double MmbDkdlrpAbUK = -573401.3572598685;
    bool LfWbUeZqgeTIurgz = false;

    for (int yGKWC = 814808400; yGKWC > 0; yGKWC--) {
        cDjetwoStzWONgm += jDhbSn;
    }

    for (int IALfFlzQSASPdUw = 1762830785; IALfFlzQSASPdUw > 0; IALfFlzQSASPdUw--) {
        qzjLCKJRLknzeCo = ! LfWbUeZqgeTIurgz;
    }

    for (int eHlKTOrwpbpL = 19345469; eHlKTOrwpbpL > 0; eHlKTOrwpbpL--) {
        qsMVzw = ! ZlHthXpGNUksN;
        nHpMDfgzkYCF = nHpMDfgzkYCF;
        LfWbUeZqgeTIurgz = ! qzjLCKJRLknzeCo;
        MmbDkdlrpAbUK /= cDjetwoStzWONgm;
    }

    return YCrZKvGTSuHsu;
}

bool yWRZRWNhGgi::qMRrat(double xtEcZLVNQVPp, double FlFht)
{
    bool thsQt = false;
    string BDwgypa = string("IArrI");

    for (int xHcQqjTAOuhtmpT = 880573748; xHcQqjTAOuhtmpT > 0; xHcQqjTAOuhtmpT--) {
        FlFht -= FlFht;
        xtEcZLVNQVPp /= FlFht;
        BDwgypa += BDwgypa;
        FlFht /= xtEcZLVNQVPp;
        FlFht = xtEcZLVNQVPp;
    }

    if (xtEcZLVNQVPp == -1017752.355434963) {
        for (int MfVXZq = 1368944091; MfVXZq > 0; MfVXZq--) {
            FlFht *= xtEcZLVNQVPp;
            FlFht /= FlFht;
        }
    }

    for (int PkYZWIjBkdvjlqyZ = 1501825103; PkYZWIjBkdvjlqyZ > 0; PkYZWIjBkdvjlqyZ--) {
        FlFht *= FlFht;
        FlFht *= xtEcZLVNQVPp;
        FlFht += FlFht;
    }

    return thsQt;
}

int yWRZRWNhGgi::SAciVgyFcgWPoUx(string mxNzynObxjGRt)
{
    bool FOuHEhnfRXlpqQ = true;
    bool nIKXNrusgieEGHN = false;
    string DtAPnTgFfkIqilM = string("koKbCprvboAILyNYqlbqiCzqCRtZAGvDadzdBpkWfSbsPKuNBVrkRdSZpmEIPkUjfYVqroGjXIyyoHzhkPZEWoSGKnJDULUgUWaCfuFwKiFspDfrwRvtUNWzORKCxnsPsKtnkMkcSVcuHLjpjTnNIOJkXlGvwasRKaaUTytgSShXdHWHqWiORuxZyTjjkzkbSFUflj");
    double DeRuZmgJg = 69304.43665178926;

    return -228188686;
}

bool yWRZRWNhGgi::TMXBo(string ephywkKWm, bool PLOdKu)
{
    bool LraqvUMr = false;
    double HGBScvlTGOBOud = 377172.563335518;

    if (PLOdKu == false) {
        for (int FQPbx = 1560154360; FQPbx > 0; FQPbx--) {
            PLOdKu = ! LraqvUMr;
            LraqvUMr = ! LraqvUMr;
        }
    }

    for (int qNKkcVUv = 141980869; qNKkcVUv > 0; qNKkcVUv--) {
        LraqvUMr = PLOdKu;
        PLOdKu = PLOdKu;
    }

    return LraqvUMr;
}

void yWRZRWNhGgi::OSYdkxPugKZbpmB()
{
    double XhXmQaAnE = -251874.57265516653;

    if (XhXmQaAnE <= -251874.57265516653) {
        for (int QwytVQPTBsIV = 1340629560; QwytVQPTBsIV > 0; QwytVQPTBsIV--) {
            XhXmQaAnE = XhXmQaAnE;
            XhXmQaAnE -= XhXmQaAnE;
        }
    }

    if (XhXmQaAnE == -251874.57265516653) {
        for (int TuKGyW = 1075562389; TuKGyW > 0; TuKGyW--) {
            XhXmQaAnE = XhXmQaAnE;
            XhXmQaAnE /= XhXmQaAnE;
            XhXmQaAnE += XhXmQaAnE;
            XhXmQaAnE *= XhXmQaAnE;
            XhXmQaAnE *= XhXmQaAnE;
            XhXmQaAnE += XhXmQaAnE;
            XhXmQaAnE /= XhXmQaAnE;
            XhXmQaAnE /= XhXmQaAnE;
            XhXmQaAnE = XhXmQaAnE;
        }
    }

    if (XhXmQaAnE < -251874.57265516653) {
        for (int SiJqyIwIuMRjmAXV = 759252430; SiJqyIwIuMRjmAXV > 0; SiJqyIwIuMRjmAXV--) {
            XhXmQaAnE += XhXmQaAnE;
            XhXmQaAnE += XhXmQaAnE;
            XhXmQaAnE -= XhXmQaAnE;
            XhXmQaAnE = XhXmQaAnE;
            XhXmQaAnE -= XhXmQaAnE;
            XhXmQaAnE -= XhXmQaAnE;
            XhXmQaAnE /= XhXmQaAnE;
            XhXmQaAnE /= XhXmQaAnE;
        }
    }

    if (XhXmQaAnE >= -251874.57265516653) {
        for (int UPGGCdROtJLnRZ = 709816126; UPGGCdROtJLnRZ > 0; UPGGCdROtJLnRZ--) {
            XhXmQaAnE = XhXmQaAnE;
            XhXmQaAnE *= XhXmQaAnE;
            XhXmQaAnE -= XhXmQaAnE;
            XhXmQaAnE /= XhXmQaAnE;
            XhXmQaAnE += XhXmQaAnE;
            XhXmQaAnE += XhXmQaAnE;
            XhXmQaAnE -= XhXmQaAnE;
        }
    }
}

string yWRZRWNhGgi::KbzgbXWYhP(string gAJGhEyptpnQyyRJ, double NwXefxffeJqiv, string CkFzqSiuEtffy)
{
    string poJXnTA = string("MemmzKpmaDxAjcbstoBUxdDuqtayXODBSLBPTeLLWVDJkktqSDAMOMEvXojCYyZjEvoSeL");
    string SPWPg = string("wMrlCvXsYSBbVOkyJnFanexvTusZengXqxCGXmZYM");
    bool VmSiOKOjFA = true;
    int gLBdTZf = 1618876918;
    int OpscGpbNrcLJMBdl = 1688842886;

    for (int evpIkOasiPHlXfy = 1575476918; evpIkOasiPHlXfy > 0; evpIkOasiPHlXfy--) {
        CkFzqSiuEtffy += gAJGhEyptpnQyyRJ;
        SPWPg = CkFzqSiuEtffy;
    }

    for (int obpzhge = 1674851699; obpzhge > 0; obpzhge--) {
        continue;
    }

    return SPWPg;
}

string yWRZRWNhGgi::hWXcUMqLaICvOsY()
{
    int WhzUo = 1346592872;
    bool JGDyPTMEmOEy = true;
    string VYcxc = string("AvINUNIrZJpBgNDHJEgtIIsNeCJkYikLvYDNEgscDRrkITosYnHjjIjhnUWGDuhqRvbkHGYAwBqpuVVxwGaVvnhrNVCHWVIEonLzaUAwCxgKtGOneMNtRubFXOCyXzBFlXblGtxlxBALjFedTJUcwQVOxMMMdONUViTRCWviSYjRwqYzJbQgvtkRgSEshDC");
    string kesaitiFLG = string("mxxGEfAaNPQBnkUAWzgYIXXutdejFXnZJTeiamCbUnmbXhNwEgDCLTdCPUNqeZulKWeFnCXboGKtTovYtmwruPLSxvGMVMrvEsYLLgbayVPLXkkEntbaYcMaJvmOSZFkWdjhBxICNTvSUTkSPwFESsAyJDnXiJiquttmLTAQtrqOnMXkdrgGYAzgoLGZTVICIBAvCoDfjDFrlAetOfaaTJfXtkwLeHEmHASiTFihmeINzibNQbECXOgBmbs");

    if (WhzUo == 1346592872) {
        for (int GzHQjUAYiMSrrCd = 1299759489; GzHQjUAYiMSrrCd > 0; GzHQjUAYiMSrrCd--) {
            kesaitiFLG += VYcxc;
        }
    }

    if (kesaitiFLG == string("mxxGEfAaNPQBnkUAWzgYIXXutdejFXnZJTeiamCbUnmbXhNwEgDCLTdCPUNqeZulKWeFnCXboGKtTovYtmwruPLSxvGMVMrvEsYLLgbayVPLXkkEntbaYcMaJvmOSZFkWdjhBxICNTvSUTkSPwFESsAyJDnXiJiquttmLTAQtrqOnMXkdrgGYAzgoLGZTVICIBAvCoDfjDFrlAetOfaaTJfXtkwLeHEmHASiTFihmeINzibNQbECXOgBmbs")) {
        for (int zOkfyoYEZV = 940999439; zOkfyoYEZV > 0; zOkfyoYEZV--) {
            continue;
        }
    }

    for (int lDSHmYIchBRMh = 1242075584; lDSHmYIchBRMh > 0; lDSHmYIchBRMh--) {
        WhzUo *= WhzUo;
    }

    for (int KPIgXGCp = 1793388662; KPIgXGCp > 0; KPIgXGCp--) {
        JGDyPTMEmOEy = ! JGDyPTMEmOEy;
        VYcxc = VYcxc;
    }

    return kesaitiFLG;
}

double yWRZRWNhGgi::amvPPxRlZ()
{
    double jSULMgnhZR = -139916.60641237634;
    bool FyoYLsTNb = true;
    double gaFpS = 833528.655999727;
    string jLgTeDNFIYqvj = string("HRwISdaUdsxyTWcFAWiWcDAAwrbiTfuvnCwdAhypyuRLmERxLSvIMxBBrPTtVOtFFYitutSvqYkNFrGtabaWjYbCQlRzqrDjRSREXkoTcDQsbOBBKxnLczAgfMWtuIEjZMxeaVjWrrfzKKkvVGDMdFipgPdlsHnW");
    int StfUdiaLeCnB = -2065089516;
    double VVCqB = -875227.822412508;
    double NbXVaVZCRWpud = -789718.679457013;

    return NbXVaVZCRWpud;
}

string yWRZRWNhGgi::WTLElStQv(string SltfoYMQdDqCjn)
{
    string NgTDM = string("JVoxnhYDrFbfPgeYauVdYioRFHJbWNthgCnGQPFnIjKjNiB");
    double wtOufYqsOQY = -853864.4259624388;
    double aXHVFngvOoEFGH = 76895.74416372908;
    string DOTUH = string("gnFCjUAnxWoyCenkVlxLOOLvlhZOSIqEixUIxGnSMjVCNudbOVEieuoWfKaOhNoPwlEQqcuYSAJwTNCjDLNOKdxPVMXbXPkuqBDvPYzJXtJMJcYPzunIBAhBGRuAvwLwiTGkzTnTHcyrKJjOeySryGRtYhZBBSzGLUzSPQNHfiMQjvEAKAJNZBSxFfcB");
    double vGAcPrtHWcP = -965463.5632739132;

    return DOTUH;
}

void yWRZRWNhGgi::ikLHhGPb(bool YWtMbxENZxTa, string uiNKkHNY, bool XwFvwvICcMZo, int azugQVWTu)
{
    int EkLZsxknIBxfLBy = 1287693290;
    string LNKqWwSbqFamABnS = string("RklUMaMaPBrSPLqwdeWIRcfiwunUAPrANoGiRqURKYIcnuDcqCmIYFCafLMXARbHaySFyWUFHHgcyHtVniHASqxOTAXsMQryQFEqTqauKOuGyNgJNiSAbAmhRKMVPZuLsmXSQLolqda");
    int jLrDNbmCe = -873862702;
    double LxGnhpFU = 125177.48776239509;
    int EmszGNuQ = 619059612;
    int kxAQcz = -1357260607;
    double axEeoTFdd = -529886.4315186836;
    double CbpjAuJWqVx = 865561.0059811278;
    string lXvgI = string("tmTWietEBROIMZCwNhhgQcdUEZbCPUfNlgsLIXsoJCBgXfpUysGDQXNROYgtMPxbCjneTbumwGRPGHDFNiyyrxNFsPJHPUrae");
    bool YoNTOrBOSkabnlso = false;

    for (int sNhPCYDMUnJ = 667226207; sNhPCYDMUnJ > 0; sNhPCYDMUnJ--) {
        continue;
    }

    for (int OLqLaXgl = 1192337524; OLqLaXgl > 0; OLqLaXgl--) {
        LNKqWwSbqFamABnS += lXvgI;
        EmszGNuQ -= kxAQcz;
    }

    if (azugQVWTu != -378658613) {
        for (int zeFDWlqpLDAn = 1783796322; zeFDWlqpLDAn > 0; zeFDWlqpLDAn--) {
            EkLZsxknIBxfLBy /= azugQVWTu;
            kxAQcz /= jLrDNbmCe;
            EmszGNuQ -= EkLZsxknIBxfLBy;
        }
    }
}

string yWRZRWNhGgi::WPMifZiIFz(bool XAwRgm, double YkxyflVrw)
{
    string pUnfQiqkn = string("rBvIFSHgTnUURxnrrjbLmJvvrMYslkszVvigkFwzrVHAypbwJojR");
    bool bWNObEOJds = true;
    string mnXxhZd = string("yofyfpzMpIPzIuxueGXXkrHXigklVejSxNrIkinkogvctDqpdFmVwppXCwIBGeCLdmawlHdhVWvgPToSltzEmXJEKCVKoTDrPAZGLkOYFCBDbSLEmnwkHNKXrQYGKNVRqMKXbrlYlzKPdDtHNmFAOVFjKpTjmkPCpBOfwzGkavmeBBfMGQKlpLOQmnZSPmHpAvHuhHWVrTYMKgybEywHnSZwxvaOlhdhuVHShweRi");
    int hjBiOVYjuYrrj = -2075739504;
    string AFidciZTfCH = string("NLPGCRlHibiMorhTQnnRjMjwdwPcdUOPwMctNyJcUiUSNvxRkKONMdbIRUkZuugmJfDrlqzgKzFUVPZYjHtdgQSTjhqxPPsdSrJQpTubWRUkMKFXf");
    int xswWNv = 1270369047;

    if (hjBiOVYjuYrrj <= 1270369047) {
        for (int lnacLZpd = 1985487826; lnacLZpd > 0; lnacLZpd--) {
            AFidciZTfCH = AFidciZTfCH;
        }
    }

    for (int plzUKXIPmWabKF = 226973075; plzUKXIPmWabKF > 0; plzUKXIPmWabKF--) {
        hjBiOVYjuYrrj += xswWNv;
    }

    if (pUnfQiqkn <= string("yofyfpzMpIPzIuxueGXXkrHXigklVejSxNrIkinkogvctDqpdFmVwppXCwIBGeCLdmawlHdhVWvgPToSltzEmXJEKCVKoTDrPAZGLkOYFCBDbSLEmnwkHNKXrQYGKNVRqMKXbrlYlzKPdDtHNmFAOVFjKpTjmkPCpBOfwzGkavmeBBfMGQKlpLOQmnZSPmHpAvHuhHWVrTYMKgybEywHnSZwxvaOlhdhuVHShweRi")) {
        for (int YkhGf = 2030121000; YkhGf > 0; YkhGf--) {
            bWNObEOJds = ! bWNObEOJds;
            mnXxhZd += pUnfQiqkn;
            hjBiOVYjuYrrj -= hjBiOVYjuYrrj;
        }
    }

    return AFidciZTfCH;
}

yWRZRWNhGgi::yWRZRWNhGgi()
{
    this->NpfBtm(false, string("TjzrCmhDbdBBfNMNeRqeTWTBthiTpWbvYlfzoqLTnnnPfZedPGVqRrKzMUucnktvoqgUJrGVPnmViDdFKzgyvXdjzxensYUXnTrvkCvktyorlFOSGNRNeQUZYNXbuFMBrIHcYqPbRvVPqKobJgZQPRilzOTBbHdktHnxrOMqaZaZKUIKHLaYcftCiIRfYKSUGxwZJOtdUYAswJJXarpArYITOnNVbwAKyFZQxnxAZpfgYIUDlPBWHaknzhVVktA"));
    this->PjojzxKawi(682327.0031945243);
    this->iZjSnbKknZPkZ(-726972.7109303484, true, string("CufcmtXktzcrKwpBGmBkZmOstenbTGuXCbFYrnXSQiiuIumdpoeMfLKQ"), string("BUoOVKlTkZeunCZNLpYJHrLXWcqPenRtjptNQaQPoYtxkVseumqhfhHirqfRjOZKqoVQLlswUXQRnrHpGHJtmHzSJMTGudKmYFRHmSclwRZfbOfVbVSCrHNgCNJTFwLFRdlbscVYmziuLszoYjuzCBEYdFjRdbvcyWrFQVgslfeMkhQRYgzN"));
    this->vTPdmNyJYiHWfqMX(-1944501648, 763898164, 285309.4252482661);
    this->SmtkMx(string("ygDbTHoIGtbTEzAIBGhLKBKHuZYWmSWttXcRKoikSzFKAvCBEisfdLNNbIJMoYpkgTfeqEpJDcPplIZjqmCzMTPUBznxYipcTUigeNhqdROQMaUtSaxcCAPwTumxDMx"), 850747.5988943984, 1127967922, -42312.3510216206);
    this->URdnEtblJtM(-2110516718, -913821097, false, 1015563.712258697, string("odlrtJcksgerURHqHbRBnvSBzWtGoejMZdgIpKIpIBAIDonzlHTOUtkoRNDFAICeIqALOrYULYVrtOKJaLTIkrmZpJjtsataPuonmTBdHxQQLFvRIaHCrHeVzoislwPaHKdfWhyNUHCsOycjqvRdNXAvfRrULMoWaJiqQeOxmIzFjqngeOSZYZvzfuEQAxKSuCdxYEQmNbdNRHUNmYcdVxiZpADgslSydgdoafzyDJFXuLOLrCYyESTLYioey"));
    this->GucEGWsdobFO(783739.2761267063);
    this->ZehDPuAraEoyVFi(-1828028676);
    this->bRIxUgfJTfbsI(string("BMottHTSJyBtLHLpkvOrTXAEVCOYzPUaMinsAiSTOcqLYnHRKnnWiCYftOkBVdDmoCfXnxBwCLCQqaiESxFsWDEXstX"), -2029465175);
    this->RXJhRANTORjGgTNC(false, string("vwNJiJHYozdteJwVivUsjTMLgloReBumuhVXSVBVfpPzkrahoveoUTtJpdaLtATUYC"), 462102.1589666202, -439846.8369847902, string("mrBVYcKDIYbcaE"));
    this->xXjVpcedXkfyg(562683.4361231044, -439913.4922620284, false, 773498.9106048754, 859430324);
    this->EQENcPaGJHZaGYv(false, string("VePeactiONJxqmskTvFMbsIkQIjzMIEpEDuchtJfiVlCaeLjzKOZQZjRzTKvcoRAKddTNxKMnsPrzXPviXLNDWGUMsfMTiYMXGcgOFtGgzfbRBrhENtxyuxWnbBOEYCatMGRBtgVOxJBbwoVhjsMVdpvojnnJQFxAOcKYMDFNCFuudbqRWYucBDSXxEvCBXBJmSWDAmgTSTcOPtlFJWogudrUOlrzKenWXbPSrJ"), true);
    this->qMRrat(-1017752.355434963, 520799.1909389861);
    this->SAciVgyFcgWPoUx(string("snizLITSjDbeEXeZSDsKvevfRcGWVaeZSTLgEjWzcpuSOdVhQubOqqIsbZbPXjHZWnLZxCylDTXupSMnqkdvjkHkHmF"));
    this->TMXBo(string("FhKUQFJmfXxBfrMGfRoKohAGbHDfQXbsWtCnJhIwKWEocdr"), true);
    this->OSYdkxPugKZbpmB();
    this->KbzgbXWYhP(string("hCITeYubcNKrsURmhXItkBOyYfcNEovdPduovhaFbThjYZRLyokaQOcSDIqRCfloEvmPbNMofULxpcMbiSUyDKgkYEjludMUzLlOksFOsEHDHPsSbLygvXrVLHYzGzZbBFzGDPEgBsajBOpnEwsTalbvltNEeOlNamqmmDEZdDLkzTZmEPORcskhgOKOlhcvXRnwBoEjaQekCPPvnUftXxkvflKphJNHuGrtNDVjlpasgzxHbpc"), -756305.9472189988, string("cvpPBpdvcQIoPXcdlXIgWiOjrxbPzRDZvruFVweYelaNEQcXqICarvNylQlQWnlMhUPLojNDCPgItSRHABpdpNxBvslstpFnxftySraXtIpVsxsVuneGXATvLVNGCnpfxJMzMOswIsKHqSGXvHzASPcfiMIGrkZyYlexkiDSfQAJnnLPlKIXozNYcGXcrSZDXLVSMdYIMpnHhZQ"));
    this->hWXcUMqLaICvOsY();
    this->amvPPxRlZ();
    this->WTLElStQv(string("HkphZOl"));
    this->ikLHhGPb(true, string("eRpzHQyPgEcdoFsWNQwzlGxKLTdUjkrgRIxYshxWXPIBEHhTZhKFvjpJshMJbneZTxeGfqYLvqXjKgOkyfSFLDOhZYsxdQKTqvSJQHxNDchmoWUdHKmGSmMXqDrxWCdJYZaVRhRAjRWljOHnAAmdDzNNEBNhbgkBIhubMfZRYpLPYWbdy"), true, -378658613);
    this->WPMifZiIFz(true, -614537.5049075098);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vOdnzsiv
{
public:
    double wLblmpRGjtmo;
    string rcMaNAiJsnICvDy;

    vOdnzsiv();
    string PCjxGPdzQd();
    int yCFVEgXlkAuXTo(bool vGxznoibNfuvMutc);
protected:
    bool edIhtP;
    string FeGueCRfZdhOdJ;

    bool jJlzu(int wpWjltYZlVk, bool ViUeozgPuqd);
    bool tFxRJkbZ();
    string KtYuh(double yJzlDq, double kNhEyBTl, double tVDPUaODjmaSboDj, string hvoNjnUzUc);
    int BxrgvuVVhvPE(string IuhCRpAJymVRX, double UbpZomSDchsN, bool HpirnktFWcUWLsdN, int sTZmFiRMAvQ, string CjlkTE);
    double KNnkUPXCCly(bool ekzwOuvCJ);
private:
    string fFJYd;
    bool ozNwh;
    double gFHiGxpSgv;
    bool KxsJrXjaot;

    string KrzKja(bool bZXHckzSNpjMnE, bool cjTzxEbowAw, string JYdRWue);
    string feeZJCioxPvJ();
    int MmUymD(int rHtdYSwaBMBfZ, bool rEClfzyXvHEemtl, string TMEzujDN, double yQoSDdJoKtUFbDf);
    bool InMyDSRs(bool LhJvWRtr, double VfCNbyTcLzkl, double EkMojkdbT, bool WfXaJuKK, int zKwBibXLi);
    double hHpbhvTItHti(int RQhzVpsplYqDVlz, double RBCuWULFZHNnEh, string drltLvXAWl, int izfWynkcs);
    double CHYuAmZGLWgVbV(double wYflmOvHIdHei, string xtQdqtPiaRr);
};

string vOdnzsiv::PCjxGPdzQd()
{
    double YeGsppQHwXn = -592668.2592994533;
    bool pnIBaQBgrP = false;
    bool eJWTVrG = false;
    int JMXwVIqFvTlKkx = 323562520;
    int gMpcB = -2088009835;
    int FiZOhsmKGAYernyu = -1202652525;
    bool shegrSpPlZ = true;
    bool NgvMzvRoyaofAnQa = true;
    int KEVDawP = -637941145;

    return string("vIyVxhPQOeVagfyqAjcYqcUtZDTOBXZLNGrnrGADBOJbtCUbWBsquKwWkIlmZvlBcpTHnNUsDtKCwHdufHJuwYeRgwDrTzmSJRuwheehkImYUyXaltyqkJilwVRfFmMpbGdmRUPbPDXrxiTxyISEKAMZauadCKkREA");
}

int vOdnzsiv::yCFVEgXlkAuXTo(bool vGxznoibNfuvMutc)
{
    string Woetg = string("mKetZbFLfloVrxEyXTNgwbVengrhNdLHoEPdZpOGkpSHEufQTpDwbEefxNdtEoiHAQgQbiZcSBRJlMttaCIunvMqgX");
    bool qDubSj = true;
    bool FMZtdl = true;
    string FWYCWmytawZmY = string("ZlOFmWtUTnNlyVDdRwVmToxdjPICdVKwECXgenkHsZUdDC");
    double weuvEuisXv = 906400.6967587472;
    int LkutkQDhNw = 59309762;
    bool FPFOKjzOxVhytnpP = true;
    int lXYvYEFA = 1233642877;

    if (weuvEuisXv < 906400.6967587472) {
        for (int KOeZxsfuszfJEm = 1633233015; KOeZxsfuszfJEm > 0; KOeZxsfuszfJEm--) {
            continue;
        }
    }

    return lXYvYEFA;
}

bool vOdnzsiv::jJlzu(int wpWjltYZlVk, bool ViUeozgPuqd)
{
    bool PWdUvwHsHLPDw = false;
    bool iAdmvjnCgdchnVr = true;
    string olmkHfVVrrIeXuCi = string("wZHgVOgmKwldHyhbJVhDifbqyoKDuGqGehiaAchPvoAWHeqjJPHhtVRMHCLkCHOFWphfMyLOyclmJpOFJkxaRfckCiLiNwDkJnPxQivijyfbkAEiNryCPDKmBajOzULHkLOIcFzGiSYhzCm");
    int piLkSozYLGwLUszH = -1856256576;
    int cXvgLz = 24281922;
    double RAFWETiJbRjZ = -263979.78944773786;
    string BsxvjTPnX = string("rtDZTdbayNPyMAeWDzsByMWJvZZeqqtrAAhvGevOkzljGpTuklLEbGUifEJmQGjQSmdDVYzgJWMwwKgNJRmoZPFiCrDItZbFsaHYVAGdOhNGxBGHTCIzRJgYFWybTVuTFewYYPUfKDyYoNltsbeafg");
    bool uYcBasB = true;
    int OwdWbMw = 1629384505;
    double fiDTvCDwZL = -871996.777727369;

    for (int oLFzZrClbyheTT = 884713677; oLFzZrClbyheTT > 0; oLFzZrClbyheTT--) {
        RAFWETiJbRjZ -= RAFWETiJbRjZ;
        piLkSozYLGwLUszH = OwdWbMw;
    }

    for (int XpHDIQ = 370091789; XpHDIQ > 0; XpHDIQ--) {
        BsxvjTPnX = olmkHfVVrrIeXuCi;
        cXvgLz -= wpWjltYZlVk;
    }

    for (int ajrKegoRYMOhx = 518634467; ajrKegoRYMOhx > 0; ajrKegoRYMOhx--) {
        iAdmvjnCgdchnVr = ! PWdUvwHsHLPDw;
        PWdUvwHsHLPDw = ! PWdUvwHsHLPDw;
    }

    return uYcBasB;
}

bool vOdnzsiv::tFxRJkbZ()
{
    bool nfQNe = false;
    string mAexLMHtw = string("xjFFEukKXtblqCmuXbPLRpcNWxpeRXDxfoWSDSGENFxLLskdNFPBBFNxukyAUZHfLylIOAAwDalVfdDMMMPxbEyhtUDKDUbnLgNgkTEgdzTBCYyIKixkJANYqqppAXwGGXDbraAtgaoXSptvDIMvLsxVNXXWlSKeYmjiYdMwYJoLbfWPnoGOkOshrvVSRoXWOugBfQTpXkpVFPkWguKRbqldlYnBIrVedx");
    int qQsWNVHxdBXJJ = 658383514;

    if (qQsWNVHxdBXJJ >= 658383514) {
        for (int KAaJyZrQQhUt = 585258622; KAaJyZrQQhUt > 0; KAaJyZrQQhUt--) {
            mAexLMHtw += mAexLMHtw;
            nfQNe = ! nfQNe;
        }
    }

    for (int dyiAk = 499346645; dyiAk > 0; dyiAk--) {
        qQsWNVHxdBXJJ -= qQsWNVHxdBXJJ;
    }

    for (int ZyysGfzw = 1473894637; ZyysGfzw > 0; ZyysGfzw--) {
        mAexLMHtw = mAexLMHtw;
        qQsWNVHxdBXJJ *= qQsWNVHxdBXJJ;
    }

    if (nfQNe == false) {
        for (int zQGFcrlbjJBZRI = 1450985109; zQGFcrlbjJBZRI > 0; zQGFcrlbjJBZRI--) {
            qQsWNVHxdBXJJ /= qQsWNVHxdBXJJ;
        }
    }

    for (int qXjpPbmNZvTtMw = 1406515942; qXjpPbmNZvTtMw > 0; qXjpPbmNZvTtMw--) {
        qQsWNVHxdBXJJ -= qQsWNVHxdBXJJ;
        mAexLMHtw = mAexLMHtw;
    }

    for (int QKXNRrf = 498961879; QKXNRrf > 0; QKXNRrf--) {
        mAexLMHtw += mAexLMHtw;
        mAexLMHtw += mAexLMHtw;
    }

    for (int UvyWUkz = 513816803; UvyWUkz > 0; UvyWUkz--) {
        nfQNe = nfQNe;
        qQsWNVHxdBXJJ /= qQsWNVHxdBXJJ;
        mAexLMHtw = mAexLMHtw;
    }

    return nfQNe;
}

string vOdnzsiv::KtYuh(double yJzlDq, double kNhEyBTl, double tVDPUaODjmaSboDj, string hvoNjnUzUc)
{
    double bFnurEYoJyFDQ = 591013.911806295;
    int AfSOmcVV = -714967491;
    double rvoJoPKjm = 542612.8751912815;
    double CRwWaXQXKkFoR = -1025575.0591525781;
    double sgdTlfnEEH = -187212.89823011562;
    bool MzRvgBxUZR = true;

    for (int FiPyhFHGUQm = 1626417728; FiPyhFHGUQm > 0; FiPyhFHGUQm--) {
        CRwWaXQXKkFoR *= sgdTlfnEEH;
    }

    for (int zEQbhoApBM = 1029414556; zEQbhoApBM > 0; zEQbhoApBM--) {
        rvoJoPKjm /= tVDPUaODjmaSboDj;
    }

    for (int lEQmzoGNJ = 487933909; lEQmzoGNJ > 0; lEQmzoGNJ--) {
        rvoJoPKjm /= tVDPUaODjmaSboDj;
    }

    return hvoNjnUzUc;
}

int vOdnzsiv::BxrgvuVVhvPE(string IuhCRpAJymVRX, double UbpZomSDchsN, bool HpirnktFWcUWLsdN, int sTZmFiRMAvQ, string CjlkTE)
{
    string VOOITD = string("CdRvcYFPvItEupjGCDMwWWoaMefmgYTTQDcVzKLKdQNgWHoJSmFZLiAYGCLVoBmOiaBuOWWYDtLWYyBbBnOFwrKOlmflpsXomsAyIEenhkdLmoXqseWLHOxvifgJWQcGogHyrhtgYBJOZIuqIcxdzIGwHJYrAuCzdFekxpMNnNYaYABSrXweuwQXNrXrzRVoWOWMFkhvvTEOZsDLTmpyaGKZZEUiPzDjYam");
    double nOwwjPJjq = -556419.4389482368;
    bool RaDLbu = true;
    int rBQvjhvRXo = 1287292248;
    int NOeTAUTuYqVB = -544414747;
    bool TiaZetCLRzAXRi = false;
    string rhhPVkKqIBZI = string("qFuBzjkRIDmUaefobDGYEMTsUWJebCfVPBVSXrdINwQURUieonMzqzgJkpYVhQeMxiYZymDFifbxnotbCWfMZuSiJLBywPZecRiFoMCOIUYjNZCusSdNroywxnemmsHZecxnxNVffkfQMgpJGdCNTNNERLFrpOBmMNeaSyg");
    bool TvrnxIHjJ = true;

    for (int XJcMXNBkGzxcEgD = 251321155; XJcMXNBkGzxcEgD > 0; XJcMXNBkGzxcEgD--) {
        sTZmFiRMAvQ /= sTZmFiRMAvQ;
    }

    if (NOeTAUTuYqVB != -544414747) {
        for (int IMRtTdUTQlIqSWo = 451042540; IMRtTdUTQlIqSWo > 0; IMRtTdUTQlIqSWo--) {
            VOOITD = IuhCRpAJymVRX;
            RaDLbu = TvrnxIHjJ;
            HpirnktFWcUWLsdN = HpirnktFWcUWLsdN;
        }
    }

    for (int sibefxKC = 872314597; sibefxKC > 0; sibefxKC--) {
        continue;
    }

    if (RaDLbu == false) {
        for (int yFMIDefCYltd = 57725002; yFMIDefCYltd > 0; yFMIDefCYltd--) {
            nOwwjPJjq -= UbpZomSDchsN;
            rhhPVkKqIBZI = CjlkTE;
            RaDLbu = TvrnxIHjJ;
        }
    }

    for (int qrQlUhYXHt = 69194405; qrQlUhYXHt > 0; qrQlUhYXHt--) {
        TiaZetCLRzAXRi = RaDLbu;
        rhhPVkKqIBZI += IuhCRpAJymVRX;
    }

    return NOeTAUTuYqVB;
}

double vOdnzsiv::KNnkUPXCCly(bool ekzwOuvCJ)
{
    string RUUTDFOhteNHANUn = string("XfqLNghnKrwzUfzkYuakjarRCCQUdDfUyAzbdKvTNmjVDvkXUFJWCYcrKkFypsQNsdzfAGwUPePcPeBFafpAZojeZuSBnQcTCYDPCyLEhrgROxJpCXyhOPWSGPosuWvwnTgHnklDZrCSGJYaRwHZHGrVioOKSSXDqRKoTYRPchwtWNwHlYrCshycOIBhWPtwFTDtmTlTObRegW");
    bool WxRvE = false;
    bool sNfSZcTmoP = true;
    string NBxMTpUPWnV = string("LUS");

    return -352021.2805257336;
}

string vOdnzsiv::KrzKja(bool bZXHckzSNpjMnE, bool cjTzxEbowAw, string JYdRWue)
{
    int YzNTHLibjPdZ = 1039916053;
    string WHmzLL = string("PGiVOZqmvnQBQsRuLWMuERdAiQBeNJBINXNaSLWlnqnRICSdtGMWOApfHIAImawGOiQdvmzurrTnt");

    if (bZXHckzSNpjMnE == true) {
        for (int sinniH = 1739270150; sinniH > 0; sinniH--) {
            cjTzxEbowAw = bZXHckzSNpjMnE;
            JYdRWue = JYdRWue;
            bZXHckzSNpjMnE = ! cjTzxEbowAw;
        }
    }

    for (int bhiXEcbPmMdtj = 1950277243; bhiXEcbPmMdtj > 0; bhiXEcbPmMdtj--) {
        WHmzLL += WHmzLL;
        YzNTHLibjPdZ = YzNTHLibjPdZ;
    }

    if (JYdRWue >= string("PGiVOZqmvnQBQsRuLWMuERdAiQBeNJBINXNaSLWlnqnRICSdtGMWOApfHIAImawGOiQdvmzurrTnt")) {
        for (int KykRnSqiBLkXmO = 1269879; KykRnSqiBLkXmO > 0; KykRnSqiBLkXmO--) {
            bZXHckzSNpjMnE = ! bZXHckzSNpjMnE;
            bZXHckzSNpjMnE = cjTzxEbowAw;
        }
    }

    if (cjTzxEbowAw != true) {
        for (int rOnxbZ = 1164818843; rOnxbZ > 0; rOnxbZ--) {
            WHmzLL += WHmzLL;
            cjTzxEbowAw = cjTzxEbowAw;
        }
    }

    return WHmzLL;
}

string vOdnzsiv::feeZJCioxPvJ()
{
    bool ThDyInManawISiz = true;
    string yTIetbJ = string("knkejcduYjhtuNouNFMWFbShswryvyBvcPsUPhYhiVICimGSDjMOWZkQRtHDeqyGwOIeqfVoiuCHcCHBcbAqTEvFcIKcLtNuIMKSbtXUlEnOEgDsbVfVsgbusZnPwDGyFlmZXpSMzdEUvyMsESzAyRKwXuzbGNtXywmITauPjWSlxKIQJkziSiiOtwoHWSYILOcWaFWyPtWIwWZNesUBJTAZ");
    bool JvNoPySeDoEWy = false;
    string muMLNZ = string("cDMUBYDNNfioMweadpDiRgFpIaWLIAXsHdOkOyYiKnIjXcpPOqCrcPMLWRzoGdQliQAViQsRsVwQByFjCCNXIByxejtoqlMlDYgRPujgVyxDtlkrzzTGIBpAJkzwkmKmjNwMhFmVGnJZsFj");
    string CfpuuZTBULNWrRA = string("DfNHpeBgeMPpMsfDSjiWFOVUiowKTVqzMNElyIVtUzZtGfiygKHrtSKTmggYBTFuYpIdTUHFAOkfmoxkBGuqxrNJpFHmNuFLbkqVllycAlvCAePFBvoGCGqtFKRDpEAodYUwnGiuvfYKrqKuUQJwVnimEaRjHPPxWGQWVgBTCfBOvXtjMOnuZzvSlYyLOptfOerbXtNAHV");
    string BKLWhUGlXJzhw = string("zHPwHonPpYiiVgiDQTZRdgYQdKrQxhjDbQNUWHCpmvgUypBvoapAlEJWgiLQIEIrNjmvZzdviLZjEwuewbCzZdCQNyvSrsCBvAVE");
    string yNwEpiZvYIzTh = string("jkhfNJbIpxAKtRcazWgegqThgFEu");
    double HLtAgMyMzHJg = -633479.785811118;
    string EQFsoSGhQcCzj = string("gowGrtgZkGQalLeEd");

    if (BKLWhUGlXJzhw == string("jkhfNJbIpxAKtRcazWgegqThgFEu")) {
        for (int sqfmKeRJDRlx = 2109364243; sqfmKeRJDRlx > 0; sqfmKeRJDRlx--) {
            continue;
        }
    }

    return EQFsoSGhQcCzj;
}

int vOdnzsiv::MmUymD(int rHtdYSwaBMBfZ, bool rEClfzyXvHEemtl, string TMEzujDN, double yQoSDdJoKtUFbDf)
{
    double ApxHymQoaiZ = 306093.4816063101;
    double UcIOiNeLelAq = 365587.77199974906;
    int cEwGHnvmRyti = 1928790199;
    double RkPldNN = -243202.42570317414;
    double ExCWbCGZqvkJA = -549022.4319999353;
    double ndIbaXeeKtTwT = -528122.585664676;
    double NlcCzInKOIB = -108792.04385101314;

    if (yQoSDdJoKtUFbDf != -528122.585664676) {
        for (int lcREeEWx = 944298790; lcREeEWx > 0; lcREeEWx--) {
            yQoSDdJoKtUFbDf += ndIbaXeeKtTwT;
            NlcCzInKOIB *= ApxHymQoaiZ;
            ApxHymQoaiZ /= NlcCzInKOIB;
            NlcCzInKOIB *= NlcCzInKOIB;
            ApxHymQoaiZ /= yQoSDdJoKtUFbDf;
        }
    }

    if (NlcCzInKOIB != -549022.4319999353) {
        for (int mqrfcLE = 727098850; mqrfcLE > 0; mqrfcLE--) {
            UcIOiNeLelAq *= ApxHymQoaiZ;
            ApxHymQoaiZ -= UcIOiNeLelAq;
            NlcCzInKOIB += NlcCzInKOIB;
            yQoSDdJoKtUFbDf -= yQoSDdJoKtUFbDf;
        }
    }

    if (ApxHymQoaiZ >= -108792.04385101314) {
        for (int fkPTdOJqWVOlBv = 1336021176; fkPTdOJqWVOlBv > 0; fkPTdOJqWVOlBv--) {
            ExCWbCGZqvkJA *= ExCWbCGZqvkJA;
            RkPldNN = ExCWbCGZqvkJA;
        }
    }

    for (int UsoACSLkWwSqjUEq = 89797965; UsoACSLkWwSqjUEq > 0; UsoACSLkWwSqjUEq--) {
        ndIbaXeeKtTwT = UcIOiNeLelAq;
        ExCWbCGZqvkJA /= NlcCzInKOIB;
        RkPldNN -= yQoSDdJoKtUFbDf;
    }

    for (int WxEFmMDsBiml = 2071200004; WxEFmMDsBiml > 0; WxEFmMDsBiml--) {
        NlcCzInKOIB = ApxHymQoaiZ;
        cEwGHnvmRyti -= cEwGHnvmRyti;
        ExCWbCGZqvkJA += ExCWbCGZqvkJA;
        NlcCzInKOIB = NlcCzInKOIB;
        ndIbaXeeKtTwT = ExCWbCGZqvkJA;
    }

    return cEwGHnvmRyti;
}

bool vOdnzsiv::InMyDSRs(bool LhJvWRtr, double VfCNbyTcLzkl, double EkMojkdbT, bool WfXaJuKK, int zKwBibXLi)
{
    int aHnyViSWLDom = -389945080;
    int GbgAPZkodH = -573785473;
    bool NGVXVgAitQon = true;
    double HTwXLhVmz = -535784.0859520586;
    string BAvrBjHFVYV = string("BZVYWcTGibiKrMbJonzhztTJwyuHhizPVtalekxOcEQplpswoaeWAzBLZfxwIWmsmJuIIzRWGxzEOxJOegYTyqehRSyZBydHdnaWZkplocRfDfigsCUEwPvNwgtbvzleUQxoEgdTEzpwnXSIbfDBgFyJMkQPwfMzwIvtVnYOppvbwcncMuy");
    string tViaR = string("FchYwSTqqxboqYELXICoTACbndARHBUfOsTglKQwBdpSuvLfworMLJVInfDBjHImzNCDMrAiNbDubxeBgmpCxmzKLoKAaOvFdZlYJTQpIsUmhTqhsunEFnEmkNDgrwUjHbmgXLPGjKKFafNDtIFRHSlvwDHXXcqzKwGQyEkSyFkBBlFDZNFjvgP");
    bool jmOInIu = false;
    string TRnCWeD = string("XWwjaDGkUdadNsvHlSScRTnixQjLfyZEFEpNGbvECsndGAfZfcYoVZLnjevQxa");
    double JrSYQedWzjuV = -351032.9857328791;

    for (int HTkjseGMtFVzKK = 935071897; HTkjseGMtFVzKK > 0; HTkjseGMtFVzKK--) {
        continue;
    }

    for (int KOgERJUlmL = 1915228597; KOgERJUlmL > 0; KOgERJUlmL--) {
        NGVXVgAitQon = WfXaJuKK;
    }

    if (NGVXVgAitQon == true) {
        for (int YFbBXUQotHpcCS = 1110112952; YFbBXUQotHpcCS > 0; YFbBXUQotHpcCS--) {
            GbgAPZkodH += GbgAPZkodH;
            BAvrBjHFVYV += BAvrBjHFVYV;
            JrSYQedWzjuV += JrSYQedWzjuV;
        }
    }

    if (WfXaJuKK != false) {
        for (int PeEjg = 1971446414; PeEjg > 0; PeEjg--) {
            JrSYQedWzjuV *= HTwXLhVmz;
            EkMojkdbT = HTwXLhVmz;
            WfXaJuKK = jmOInIu;
        }
    }

    for (int RIIxMj = 50114697; RIIxMj > 0; RIIxMj--) {
        jmOInIu = ! WfXaJuKK;
    }

    return jmOInIu;
}

double vOdnzsiv::hHpbhvTItHti(int RQhzVpsplYqDVlz, double RBCuWULFZHNnEh, string drltLvXAWl, int izfWynkcs)
{
    int ZBZfMPRQHYHz = -1678426262;
    double oJKjSTHhABohEAyl = -653529.8324584542;
    string JlnmREAz = string("DKBcdwkhjuWgWeUJwNrUzRRuNRNciIShQBYZQezLluqPsRuwOcYuhhGCuNTiYWjjQMWnKseATXZDnRBHxjMKZDxsOfkvRHmkGOGnlTXrzemHezFbJWcfDjhxY");
    string dRXJHxbSOsXF = string("oXSvMbELmQZLZRZdLWkWztrfEYTaWieupnlwsbenEjORWrtQrOXWGPenvKqCSrXnGFhVflRIMpaPQKNRfZAxDEXQPbDANGiLDHNDdllnlcBehzHXDXdysyTbnlVDnhzRfLiztnJKQAPcuUgAnFHtlNjziFeMoqBCunsxfjqqRaEwvuNMerjAPFbjXOmgYwg");
    string sMnmScryc = string("MwZZZoUoUbwMZJfaSJNzfKJVgCcnPPxHCOGidIqctJxVhYDSIqxaviwjiIneoMeHpehTfLlblkZAXgCTdvyNDxTdpxJBzHDlrSrUrzwRziLsiEayJUxcFnNKDMBuJxpLvDKhNooMjmFhzfQPrXgrdeEdqWJPivLQHMLZsvSQBZbOfbfiOrtSCYVoSElRbnwnRQicaVKPZPBMseY");
    double nRSAw = -76174.73915164675;

    for (int FMvRmUbhRFrAmh = 302043319; FMvRmUbhRFrAmh > 0; FMvRmUbhRFrAmh--) {
        ZBZfMPRQHYHz = RQhzVpsplYqDVlz;
        dRXJHxbSOsXF += JlnmREAz;
        RBCuWULFZHNnEh += oJKjSTHhABohEAyl;
        izfWynkcs = RQhzVpsplYqDVlz;
    }

    for (int odSplMfjFrlEwgi = 100824096; odSplMfjFrlEwgi > 0; odSplMfjFrlEwgi--) {
        nRSAw /= oJKjSTHhABohEAyl;
        drltLvXAWl = dRXJHxbSOsXF;
        sMnmScryc = JlnmREAz;
    }

    if (izfWynkcs == -780303879) {
        for (int ohdGbYM = 625625168; ohdGbYM > 0; ohdGbYM--) {
            dRXJHxbSOsXF = drltLvXAWl;
            drltLvXAWl = sMnmScryc;
            dRXJHxbSOsXF += sMnmScryc;
            nRSAw = nRSAw;
            oJKjSTHhABohEAyl /= nRSAw;
        }
    }

    return nRSAw;
}

double vOdnzsiv::CHYuAmZGLWgVbV(double wYflmOvHIdHei, string xtQdqtPiaRr)
{
    string VtvusRiBmoJFmtJr = string("wzoEVEBXybSslpJeMlpJbiisXHDJraZpFKUDhjoRkhgSHylGinPdDFwmErutKkiPSoFnHZGsUvawwQKPjfgWHTzEcihfTENJAygOBmFjiWJhuXWaaqpDkctrloPTHPaxJnjvVYXdHWJcGnHLrOsOGgEtCElNncROnGqPdcovQOVSmmTvirQRDBjSCjkQknMOELenFZLQwvrlBWvkrfWrMqlzWqBCIdjVNfSSqGCRcrROEKFqRiPOFATKbmih");
    double fnyeXK = -434669.32463187695;
    int bRzQfYgtplf = -1835460306;
    int CRmOaNiqXJPnYuoI = -1924001542;
    string YlGRV = string("rcRTHUDRqrJOsPLPcgKYhZKuJqoLebBUYHaeUWDJSDSmBQMxayHKPegYQeDLVaHBDnZdXkCMMqIyKbbLRspWBxKLXTvZodhw");
    bool loNyjTjHAykfP = true;
    int WHzWG = -1454511185;

    for (int BzyXNxjW = 716715951; BzyXNxjW > 0; BzyXNxjW--) {
        continue;
    }

    return fnyeXK;
}

vOdnzsiv::vOdnzsiv()
{
    this->PCjxGPdzQd();
    this->yCFVEgXlkAuXTo(false);
    this->jJlzu(1896805610, true);
    this->tFxRJkbZ();
    this->KtYuh(-854749.4190366183, 479563.13466889097, -984694.2592025169, string("bpvAJlylTXXzaiHZsOaWLWAQBTJ"));
    this->BxrgvuVVhvPE(string("qwGBRLdUOqMRishlfwGVOYkiqFvlnNeUgqgauQvdNcoleaHwQDWkgAuofVKEdvkPPoKCwACSBShuYfyYiHTDuIiUkGrSWBJbGxzZYttyRGUkwLhGICCVFMCTGdLLgDzncFTmKcfNweoLIQwRblibjMfVmwkdQgzYMkinvImSyhdjFCyepPVZefqvZrWFatqsZYQBihez"), 957009.1904760894, false, 1360506940, string("aXeTXGWehKlkpOoEgQbQyeqLDwPZddhOIQGFNMNilOChhSENliiXDaEqKUn"));
    this->KNnkUPXCCly(false);
    this->KrzKja(true, true, string("QYpCcYMVVdGofntGEAhPpdDOKpTZXGSIcyOaXccilpobRRbFhILvhoabIcqQqWucrndshPgkITerQXrAJYINAI"));
    this->feeZJCioxPvJ();
    this->MmUymD(315174727, true, string("jYQbCyKkrLXKYtdvdxfjHFyYwaaXQuvBAKQEaSjQNWlHavkQmuFHrGasGJlmKAXwZqGbLwnRrmKzgcADfYPRRHGkJtINDpESRFXQYdxIHnWUoEUhOndiQxVLHaLBApIdQhDQLZrlsZObZEETuBhhxspVhaxhFXIcnaeUDsG"), -583421.2508425012);
    this->InMyDSRs(true, -703232.9221367778, -540109.7786862027, true, -24277375);
    this->hHpbhvTItHti(691126540, 921608.8965940675, string("BkCAoFS"), -780303879);
    this->CHYuAmZGLWgVbV(372412.6641247753, string("pQhjxOirkDWecycxifZxjWoqGVvkUVGziwtAHoziJXmkmJnHMszWkRmpjdiQtvWBsNvlwAHKQriwLolQoTLegKhEaIHzwWXDAkXSJXnGVsQNgphUnGUmssAEzRdjXeKyMyASFDsVkkVRpiivnxUNiFkWLQizYWwXkyW"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class avEzdSDysrbnZgd
{
public:
    bool OPqxK;
    int sWsAbonq;

    avEzdSDysrbnZgd();
    string TjDXfWjnO(string TGgtAZwC, double gCELQcYtSsHevQ, int CxUKmDcFnioN, string IUvtInNML);
    int JvWLZoN(int KKtDu, string MfYRGVQEVO, string DSSfczkVMtdCN, string kTFgNUZVWZT, int zjvdcWNmaBlpXA);
    void zEJSujwjpPfNnfrR(bool pHfPnBsaLa);
    void QdlYVCancCL();
    void vntTkeMrm(double VkcsWGk, bool jivegvmh, double DqLqwEqDxnjXQ);
protected:
    int Ikohtq;
    double SFpeWVobIsFZ;

    bool pyBHJzMQ(int mQwik);
    string aGjpzKdpCiaqS(string FYjeSB, int PzLeksolfax, bool XoQtViqPhkPKyPW, string MCHhRMMcD, string BlxfLwwwf);
    double vYtYoVEuRtd();
    double vQEAZu(double fTDRNvhbvZXTPrg, double ZGQPdMuwZHDUDLP, string ELqGvnRE);
    string MAzWSY(bool xlXDUdQHxKh);
    double rGMHxvF();
    double WrdpcSuXZEe(string jlyUmfPmesMisOqG, int ykBsScgTdx, int MdrvVAkqeqZqgt, int FAZXDeMHhlMRCYm, double PHGVFu);
    void ItTMETqbqWCJYzT(double DJUxAdKWyaXEFt);
private:
    double XrOONyYGzDekTBF;
    bool NMmpbMwd;

    string aBsRAGOGXY();
};

string avEzdSDysrbnZgd::TjDXfWjnO(string TGgtAZwC, double gCELQcYtSsHevQ, int CxUKmDcFnioN, string IUvtInNML)
{
    double KfKwhiTvAbhhNd = 66918.44427646918;
    double aaxFBoncxLMhJ = -812874.9300931835;
    bool NSBDqETGnWstGj = false;
    bool OSSLmKIReChkfukh = true;
    string brxUAImwQgZI = string("rWjkPUHYrkmrqdoGwnrtbIqtTOAtFGmaNSAUvntPqHziIvGZpgKwdrQzersTipkiIUsbhXYYs");
    bool YbnDl = true;
    string GzvGfKx = string("QRtBnbWvEZiastFzMYrzBFmhJjaOuOYnmHFZPuBfEzLqcxMjIqbdgkkiXmiDckkobFlwVxaDJDEeGzWCegRaCvmBbcXpJjeAjTsGcgjqqOuPqJfIhfGvKWCLYlmfsdmSoBtLXQfvNWrihgBgCEGoWOndKREGB");
    int WwyRwivCxI = -1132266971;
    bool cALhdGeZc = false;

    for (int CVKREEuVncgcbBM = 2130550779; CVKREEuVncgcbBM > 0; CVKREEuVncgcbBM--) {
        NSBDqETGnWstGj = ! cALhdGeZc;
    }

    for (int DXUjQmbdbIJAHaCU = 238319957; DXUjQmbdbIJAHaCU > 0; DXUjQmbdbIJAHaCU--) {
        WwyRwivCxI *= CxUKmDcFnioN;
        NSBDqETGnWstGj = ! YbnDl;
        aaxFBoncxLMhJ /= gCELQcYtSsHevQ;
    }

    for (int apGiW = 516297858; apGiW > 0; apGiW--) {
        cALhdGeZc = ! cALhdGeZc;
        TGgtAZwC += brxUAImwQgZI;
        gCELQcYtSsHevQ += gCELQcYtSsHevQ;
    }

    return GzvGfKx;
}

int avEzdSDysrbnZgd::JvWLZoN(int KKtDu, string MfYRGVQEVO, string DSSfczkVMtdCN, string kTFgNUZVWZT, int zjvdcWNmaBlpXA)
{
    int NGIlYPCG = 1059949192;
    int oGOwXhA = 1690049263;
    int QtzAguOKWAYyBu = 191372633;
    string kkUlojMvnfDUqtyf = string("LCmHVdfjHsNFPGtpLVEEUdpNseBScgdRJCglouCgsJMaxiRywYpRAgGgBFwtOBSeblGBdPerdZhCjyPGHNQTgKUswlonFnwFkTGAJhSkHPzMtqmcmCyrSwHMcDsTAUHljLWFMPuNTIfOuTFNHzlowLDbHTKDTCsRFkojrbjjRicswwRacFKoCYCkfyEzNcWqBPgqgfkSceeTtSGnbwOqBMKoinDu");
    string hCYzgaCr = string("CUEQRGRZxEgxcnZBSQhZThPAimhDGtTKHvrhggeujbpsJHziUmSQJqRNZwaMnoAuwHkdVGHmUHQFjpkKYueHwLonzVeXkFYiHgbXxunPUyqJOkDOVqPbHwLnyRgXFrHjfjYHrHnOTqZvYowRayFAwHgPINcscpzHwfWVq");
    int snyVrWNVPD = -1523062920;
    double ycaxtbXBwamLdT = 904504.2114697675;

    if (KKtDu <= 1059949192) {
        for (int jShuCeZMJ = 1602788341; jShuCeZMJ > 0; jShuCeZMJ--) {
            kkUlojMvnfDUqtyf += MfYRGVQEVO;
            kkUlojMvnfDUqtyf = hCYzgaCr;
            KKtDu = NGIlYPCG;
            NGIlYPCG *= NGIlYPCG;
        }
    }

    return snyVrWNVPD;
}

void avEzdSDysrbnZgd::zEJSujwjpPfNnfrR(bool pHfPnBsaLa)
{
    double lMuuY = -33936.45632334842;
    int oyiymWcTx = -1653751321;

    for (int IdhUUQPRURIt = 324953440; IdhUUQPRURIt > 0; IdhUUQPRURIt--) {
        continue;
    }

    if (pHfPnBsaLa == false) {
        for (int kmNkdiWiehds = 684647363; kmNkdiWiehds > 0; kmNkdiWiehds--) {
            continue;
        }
    }
}

void avEzdSDysrbnZgd::QdlYVCancCL()
{
    string iMpPrxzKr = string("RLSZAtrqQrNedaFzWrWGvkCzbQkSjHwySNcOCpVJsYzgBKJdqBcgRMKbTtGjkEkEiAKOIOUWJpHEaPFcqMlJNdOfbiJAxiCbZgXJQ");
    double wLMrt = -340889.30965187255;
    string nXpWUOCshHlBo = string("QqlJOxtSNHXiIOlUkUjuCAqrAKLPOeKLvFDubOCriQWunZMcsQdYIeZpaiSLEPIqlaJWNKPBSIAVSQGNpdafFWWoZLLvmHEwDBMLEHvgZVSxOHdINPtpvozgzuAsqWvUHYUkVNjENDzJhvuEMBuywzozOuUAQbmTQCeeGDNuQBEiYRkeMNIROWeIDR");
    bool DdOKoioMVGUlxEZF = true;
    string ltDUGCT = string("OjcVYAZvwEGSJFyIMAXavqauJOeCaZkcSBbPnaCQmDVmjdECBNPAwgIXqtrzpsaoTAxsnCtAxTlOYtyHJGDZILejQoacOqIoQQAoTVCVCFTKGwvpXQFaYIjtEQC");

    for (int IgXgUyo = 1894235229; IgXgUyo > 0; IgXgUyo--) {
        continue;
    }

    for (int cVkKZvHeXkxxVCj = 368147578; cVkKZvHeXkxxVCj > 0; cVkKZvHeXkxxVCj--) {
        nXpWUOCshHlBo = iMpPrxzKr;
        ltDUGCT += nXpWUOCshHlBo;
    }

    for (int KJCpKrQmhgXCd = 869613068; KJCpKrQmhgXCd > 0; KJCpKrQmhgXCd--) {
        ltDUGCT += nXpWUOCshHlBo;
    }

    for (int qsdOjbYglhM = 428445463; qsdOjbYglhM > 0; qsdOjbYglhM--) {
        continue;
    }

    for (int CGvVvJkN = 1030014147; CGvVvJkN > 0; CGvVvJkN--) {
        wLMrt += wLMrt;
        nXpWUOCshHlBo = ltDUGCT;
        wLMrt += wLMrt;
    }
}

void avEzdSDysrbnZgd::vntTkeMrm(double VkcsWGk, bool jivegvmh, double DqLqwEqDxnjXQ)
{
    int cNrRhX = -1290689209;
    string HhRXFbjsQusbVkos = string("pWdlWWaEOqdQCVzBWbGtcjVcssIFqECBozoAlMFcCpnz");
    double PWHbB = -368461.0111560789;

    if (PWHbB <= 529680.9213895686) {
        for (int jOihwgmybMI = 1066048766; jOihwgmybMI > 0; jOihwgmybMI--) {
            DqLqwEqDxnjXQ /= DqLqwEqDxnjXQ;
            DqLqwEqDxnjXQ -= VkcsWGk;
            DqLqwEqDxnjXQ *= VkcsWGk;
            DqLqwEqDxnjXQ = VkcsWGk;
            jivegvmh = ! jivegvmh;
        }
    }

    for (int pBkXZCHKSGkD = 1833190722; pBkXZCHKSGkD > 0; pBkXZCHKSGkD--) {
        DqLqwEqDxnjXQ = PWHbB;
        PWHbB /= DqLqwEqDxnjXQ;
        HhRXFbjsQusbVkos += HhRXFbjsQusbVkos;
        HhRXFbjsQusbVkos += HhRXFbjsQusbVkos;
    }

    for (int DjyFm = 1101448595; DjyFm > 0; DjyFm--) {
        PWHbB -= DqLqwEqDxnjXQ;
    }

    for (int cyAyBOyCtzOlU = 998083597; cyAyBOyCtzOlU > 0; cyAyBOyCtzOlU--) {
        continue;
    }

    for (int KoFdnwbj = 1706982808; KoFdnwbj > 0; KoFdnwbj--) {
        HhRXFbjsQusbVkos += HhRXFbjsQusbVkos;
        VkcsWGk -= DqLqwEqDxnjXQ;
    }

    if (HhRXFbjsQusbVkos < string("pWdlWWaEOqdQCVzBWbGtcjVcssIFqECBozoAlMFcCpnz")) {
        for (int JVGwpOjOehHXz = 678206437; JVGwpOjOehHXz > 0; JVGwpOjOehHXz--) {
            jivegvmh = jivegvmh;
            jivegvmh = ! jivegvmh;
            cNrRhX /= cNrRhX;
        }
    }

    if (VkcsWGk < 529680.9213895686) {
        for (int xSUgtuhXDTApke = 828620139; xSUgtuhXDTApke > 0; xSUgtuhXDTApke--) {
            continue;
        }
    }
}

bool avEzdSDysrbnZgd::pyBHJzMQ(int mQwik)
{
    string ASIPdkrps = string("MHmcfhiCesktqrVoUYYiysEYBBASKhmIFquUhrqfSVWVSSinvKOBJZnvLHngJlrjjZUYwDjbXRwDDFfpFIzaaUQkCScIGNnXKdDFYgpZCswElVLjseWLjXpSEJVPDwGPIDaswUOUHCEIsVoUCauvAmjosjNQRiORfbZSXIvxJUyLDzBqBNiPpxXFfVaHApvJtlyUFBDCOCpqyUjJSDMenFMB");
    string fOCbUMTKxSlhoo = string("hWd");

    for (int uvYZJFLoVKc = 887087127; uvYZJFLoVKc > 0; uvYZJFLoVKc--) {
        fOCbUMTKxSlhoo = fOCbUMTKxSlhoo;
        fOCbUMTKxSlhoo = fOCbUMTKxSlhoo;
        fOCbUMTKxSlhoo = ASIPdkrps;
        ASIPdkrps += fOCbUMTKxSlhoo;
        ASIPdkrps = fOCbUMTKxSlhoo;
        ASIPdkrps = ASIPdkrps;
    }

    if (fOCbUMTKxSlhoo > string("MHmcfhiCesktqrVoUYYiysEYBBASKhmIFquUhrqfSVWVSSinvKOBJZnvLHngJlrjjZUYwDjbXRwDDFfpFIzaaUQkCScIGNnXKdDFYgpZCswElVLjseWLjXpSEJVPDwGPIDaswUOUHCEIsVoUCauvAmjosjNQRiORfbZSXIvxJUyLDzBqBNiPpxXFfVaHApvJtlyUFBDCOCpqyUjJSDMenFMB")) {
        for (int pPAYeCeE = 1581441514; pPAYeCeE > 0; pPAYeCeE--) {
            ASIPdkrps += ASIPdkrps;
        }
    }

    if (mQwik >= -1314305030) {
        for (int xksIngSSRMOPdH = 1890863189; xksIngSSRMOPdH > 0; xksIngSSRMOPdH--) {
            ASIPdkrps += fOCbUMTKxSlhoo;
        }
    }

    if (ASIPdkrps <= string("MHmcfhiCesktqrVoUYYiysEYBBASKhmIFquUhrqfSVWVSSinvKOBJZnvLHngJlrjjZUYwDjbXRwDDFfpFIzaaUQkCScIGNnXKdDFYgpZCswElVLjseWLjXpSEJVPDwGPIDaswUOUHCEIsVoUCauvAmjosjNQRiORfbZSXIvxJUyLDzBqBNiPpxXFfVaHApvJtlyUFBDCOCpqyUjJSDMenFMB")) {
        for (int RcSJmK = 1578902677; RcSJmK > 0; RcSJmK--) {
            fOCbUMTKxSlhoo = ASIPdkrps;
            ASIPdkrps += fOCbUMTKxSlhoo;
            mQwik = mQwik;
            fOCbUMTKxSlhoo += ASIPdkrps;
            mQwik += mQwik;
            ASIPdkrps = ASIPdkrps;
            fOCbUMTKxSlhoo = fOCbUMTKxSlhoo;
            mQwik /= mQwik;
        }
    }

    if (fOCbUMTKxSlhoo < string("MHmcfhiCesktqrVoUYYiysEYBBASKhmIFquUhrqfSVWVSSinvKOBJZnvLHngJlrjjZUYwDjbXRwDDFfpFIzaaUQkCScIGNnXKdDFYgpZCswElVLjseWLjXpSEJVPDwGPIDaswUOUHCEIsVoUCauvAmjosjNQRiORfbZSXIvxJUyLDzBqBNiPpxXFfVaHApvJtlyUFBDCOCpqyUjJSDMenFMB")) {
        for (int hGjxdMeHQ = 362212033; hGjxdMeHQ > 0; hGjxdMeHQ--) {
            fOCbUMTKxSlhoo = ASIPdkrps;
            fOCbUMTKxSlhoo = ASIPdkrps;
        }
    }

    if (fOCbUMTKxSlhoo <= string("hWd")) {
        for (int tsunPod = 1336547313; tsunPod > 0; tsunPod--) {
            fOCbUMTKxSlhoo = fOCbUMTKxSlhoo;
            mQwik *= mQwik;
            fOCbUMTKxSlhoo = ASIPdkrps;
            fOCbUMTKxSlhoo = fOCbUMTKxSlhoo;
            mQwik = mQwik;
            fOCbUMTKxSlhoo += fOCbUMTKxSlhoo;
            ASIPdkrps += ASIPdkrps;
        }
    }

    return false;
}

string avEzdSDysrbnZgd::aGjpzKdpCiaqS(string FYjeSB, int PzLeksolfax, bool XoQtViqPhkPKyPW, string MCHhRMMcD, string BlxfLwwwf)
{
    int bWtJTmfJZ = -849120364;
    int IRWJSeGkBdamCh = -1595404471;

    for (int rYHtSR = 1940271867; rYHtSR > 0; rYHtSR--) {
        PzLeksolfax *= bWtJTmfJZ;
    }

    for (int VWlKjcqabPY = 1548964514; VWlKjcqabPY > 0; VWlKjcqabPY--) {
        bWtJTmfJZ += PzLeksolfax;
        bWtJTmfJZ += PzLeksolfax;
    }

    for (int XILGXujwIeRLWuv = 1713621015; XILGXujwIeRLWuv > 0; XILGXujwIeRLWuv--) {
        IRWJSeGkBdamCh /= PzLeksolfax;
    }

    return BlxfLwwwf;
}

double avEzdSDysrbnZgd::vYtYoVEuRtd()
{
    double RrBZEaunNDrY = 555517.3094409442;
    bool ljArdLSfjeWXNWe = false;
    string DNnWMqtbVQuDP = string("hnjTDIIHkGBvqsvmIfmlqAKjpKdHttjJnpfMlzVcAQtIopzKHNezUwWnUkaxWKrdrqTEUpiHrGK");
    double rgTOyjnzi = 880824.5818241183;
    int oCyLsVjN = -1180490084;

    for (int GGYESmlInLJY = 13461756; GGYESmlInLJY > 0; GGYESmlInLJY--) {
        DNnWMqtbVQuDP = DNnWMqtbVQuDP;
    }

    if (ljArdLSfjeWXNWe == false) {
        for (int dZShxwqVkzFKixHQ = 661748010; dZShxwqVkzFKixHQ > 0; dZShxwqVkzFKixHQ--) {
            continue;
        }
    }

    for (int UDvRr = 1095217426; UDvRr > 0; UDvRr--) {
        continue;
    }

    for (int QoXKPMNhVu = 344845444; QoXKPMNhVu > 0; QoXKPMNhVu--) {
        RrBZEaunNDrY += rgTOyjnzi;
        rgTOyjnzi -= RrBZEaunNDrY;
    }

    return rgTOyjnzi;
}

double avEzdSDysrbnZgd::vQEAZu(double fTDRNvhbvZXTPrg, double ZGQPdMuwZHDUDLP, string ELqGvnRE)
{
    string jFzbLgKhRIWQX = string("NUWmoMcbUOGlelyTDZXWNRrvKmNxXGJCgmDupfkLtjLPMckqsuOlvkKljGAYwcsPhDjsaLvcKhMpKtdWYSvfUykngjBIUktSTKobeuzBRLebrzurvIHVOAkimFkZvEwkQTOkyfwSWgyzqUlmMmXluJIdRYUMuvbuwBUubbIEVMqpkOTzH");
    int hBynfLCu = 1841517393;

    if (hBynfLCu <= 1841517393) {
        for (int muWGEhfkEwJ = 76031880; muWGEhfkEwJ > 0; muWGEhfkEwJ--) {
            fTDRNvhbvZXTPrg *= ZGQPdMuwZHDUDLP;
            fTDRNvhbvZXTPrg /= fTDRNvhbvZXTPrg;
            ELqGvnRE += jFzbLgKhRIWQX;
        }
    }

    if (ELqGvnRE < string("qfUfgQouMKQPjJzQGmshqGVDIgkrUVLWLGkjFjotrUqqtLlpuOVfMYYnrqieNeSIEUnXvLFzCdiGNrLhKRZkcKtzoBYAXqqcvBxvfeqkynvtwNuaapYwzAaKIobclsVnWwwRhpxmEUtUqvchInyDVCFPLfLUnZisyJkaTPQxiGoSjkRrlhcpRVoyvkNXETTzQoPsNtOetBhygbAuRGuIMhXqkRlFaUvUxRcDXKxdDmyccBMPzegS")) {
        for (int AKsODOc = 1244402028; AKsODOc > 0; AKsODOc--) {
            ZGQPdMuwZHDUDLP += fTDRNvhbvZXTPrg;
        }
    }

    for (int QoKaksdpuYxD = 781120979; QoKaksdpuYxD > 0; QoKaksdpuYxD--) {
        ZGQPdMuwZHDUDLP += fTDRNvhbvZXTPrg;
    }

    for (int bmHqwQqR = 611659370; bmHqwQqR > 0; bmHqwQqR--) {
        jFzbLgKhRIWQX = jFzbLgKhRIWQX;
        jFzbLgKhRIWQX = jFzbLgKhRIWQX;
    }

    return ZGQPdMuwZHDUDLP;
}

string avEzdSDysrbnZgd::MAzWSY(bool xlXDUdQHxKh)
{
    bool EZLKLAKXGDJDyo = true;
    double ihUuIq = -241613.38654875144;
    string MZlaNLZmlGYChJ = string("hokwMlmxpwAhDadIPtzdpHGgdyKeYmRtqFnDCZNhlzTlOkTnozjIseMhybZfxgFQuBNGdvMRQNoGyXzCtoxwtMWdODeWveAtHbMaMyFapXOVMifOWmyMnCnDpRrjSHGlXdimyYRleHsjxnXrdqvXGkEwWDPAMRoXkmJqIUUZndhFXLojtVIcLHBdGRSMtaWZQgO");
    bool YjrEqubgUCgOS = true;
    int mGbBHm = 806731039;
    int abVIuwPGIFiThiBx = 1623125524;
    double belVQ = 797539.4902437121;
    double GYALKylY = -77364.2796179594;

    for (int BCqWejW = 755428753; BCqWejW > 0; BCqWejW--) {
        GYALKylY /= belVQ;
    }

    return MZlaNLZmlGYChJ;
}

double avEzdSDysrbnZgd::rGMHxvF()
{
    string GweqqAnf = string("RkNNAxBbhKoLEtmAAOHEhdnLDFcoWryWECBHihYMCagSaqOWtDYqqJvemyxDsWdpcFHljwuwEuFQKFCSNOGnewgZUTexqqNwoGEJnuRAtNnCDFbRTJswYEnpssrBKjOSRcWIEKpCihKblLGcoKhz");
    string VLONMCYmaEg = string("qiqMSmGCxwYhXzyzfYHPhSytWqcbBMLWIdzPMbYFCmDoavukDOrylbQipbRAdrNjmBZDeHbBipktFbiAFEXdtcCpaLchhPkNcfbPcVqLmXVDEvUHGIUiuNEWzmCKvisSjVTyAZgczUTdahBgQRNAflWdEHimyNOSUbhdVKekoltlrtAGOevmBDZviduWQYPoXtPNhNyGGCtHkoVAKYiiFcPXfTlqqIeE");
    double aKEiKunnNasLJd = 832359.2348390007;
    bool puCZSPeIZaBchkE = false;
    int getPVybesFkuggZ = -714856881;
    bool XHDxKdryltX = true;
    double qnDBkiP = -96129.19225262829;
    bool ujBnkmQFl = true;
    int XWoyKyhBY = 197244851;
    int YaEjzruVULnLiwO = 1770455190;

    for (int bekoUo = 161886441; bekoUo > 0; bekoUo--) {
        XWoyKyhBY *= getPVybesFkuggZ;
        VLONMCYmaEg += VLONMCYmaEg;
        XWoyKyhBY -= YaEjzruVULnLiwO;
    }

    for (int xPpxRof = 1505114873; xPpxRof > 0; xPpxRof--) {
        puCZSPeIZaBchkE = ! ujBnkmQFl;
        ujBnkmQFl = XHDxKdryltX;
        YaEjzruVULnLiwO *= getPVybesFkuggZ;
        XHDxKdryltX = ! XHDxKdryltX;
    }

    for (int BCDWGrxdLbOO = 2027506506; BCDWGrxdLbOO > 0; BCDWGrxdLbOO--) {
        XWoyKyhBY = YaEjzruVULnLiwO;
        puCZSPeIZaBchkE = ujBnkmQFl;
    }

    for (int tkJYedrmognC = 949968976; tkJYedrmognC > 0; tkJYedrmognC--) {
        XWoyKyhBY *= XWoyKyhBY;
        getPVybesFkuggZ -= getPVybesFkuggZ;
        YaEjzruVULnLiwO *= XWoyKyhBY;
    }

    return qnDBkiP;
}

double avEzdSDysrbnZgd::WrdpcSuXZEe(string jlyUmfPmesMisOqG, int ykBsScgTdx, int MdrvVAkqeqZqgt, int FAZXDeMHhlMRCYm, double PHGVFu)
{
    string CCTgloCheluymxD = string("bZDNDznVyxfoYffWpdJOLXcEzoKRIxEBJXRfQwzBuJoUtAOfgBUwIXNDsJqmyeXkSQZdgVmVwuThVndyoHYgvkwHmwhGzBtjSGdKWruWpOnKGlUECyTLUsNlrYatrdhcxFVHHmDxmRugnvitcdxqkNWYrAAsDPxCSYojOCcEgkIbGIalAzIoOUqJRkXIxWrmtdhAzNQCDHxXyWdAEoODOcBbQCVpuUs");
    double ZySYYBlMpkoTTH = 266786.2709374921;
    bool xAjSt = true;
    int XUkGniheTWRfWNTM = 1171293182;
    bool myPQMOePnL = false;

    if (FAZXDeMHhlMRCYm != 1171293182) {
        for (int bPNMpPoBnKLZt = 34742852; bPNMpPoBnKLZt > 0; bPNMpPoBnKLZt--) {
            continue;
        }
    }

    for (int jowmhHBAtLD = 657000705; jowmhHBAtLD > 0; jowmhHBAtLD--) {
        PHGVFu += ZySYYBlMpkoTTH;
        MdrvVAkqeqZqgt += FAZXDeMHhlMRCYm;
    }

    return ZySYYBlMpkoTTH;
}

void avEzdSDysrbnZgd::ItTMETqbqWCJYzT(double DJUxAdKWyaXEFt)
{
    string lPhnnoaymttUrjez = string("KDFKBhzF");
    bool GWyyg = true;
    bool caTUS = false;
    int yWtTJY = -33084985;
    double PfNljxEv = -593487.7480941934;
    string bMvynFdvFQAIz = string("IENNgEwZvDmhudrzLqcUtCuNtjQBqbYBUUdFwVXyMuVPIUZuovmvefImIdbsjeYuBvefbNhanHDYJPhVmIMVvqSGYOzyGvdGSXUCYWWJeZhMetWJLdcsocjeifxplGiuafAwQfdFnaGgLrEVUKrdlBprVpVBqmGtUQzayoBhJoJZsIDnWSxwvtAqQNnEtatAdaEZRMBzvWFuCtbzJDpScUnYIIVbTtxkVBGSWdUzIdNr");
    string LmNfXIasGykpaNxJ = string("JDtbOOjdHFdUdRFyAWApWVzrTwmHoJGxNHmgOcdFHDAULEFmOlFHDfWBrVCMCJPLHcKeoMeVJuasjsVxQCFwEwAdNICgzDbiIjdFfjdQtOrwJakSybJFEEP");
    double euqXKfkuir = -442272.755060373;
    string YHACuS = string("xMcwlWOwWWjJUqCukmczWXZYRIMqGVtuzBRopMzNmfeJSVakZtsRYnaTafjRfwLZXpEVGClVeqgiQmVVhTZPJkKTDrRZTGIcZRFDMVOhUGdNurGCXGJJrzIkPUWweeNRhtPVozGHDUZJTFEIoZwvgQTEBUTmCdPceAmbMVwVxuIMHJSMxttADKpzCQlkYfziTkpAWnDEEjPwwzFqGTBwrnyGPTaDRzNcDh");
    int zSZluMGVtVm = 1508820182;
}

string avEzdSDysrbnZgd::aBsRAGOGXY()
{
    string HNkyJzkAQIfopV = string("QJOAXkeePggujdvPccxmwwWGogKXnyoaLtDWj");

    if (HNkyJzkAQIfopV < string("QJOAXkeePggujdvPccxmwwWGogKXnyoaLtDWj")) {
        for (int ftVltfSPONVbem = 829013733; ftVltfSPONVbem > 0; ftVltfSPONVbem--) {
            HNkyJzkAQIfopV += HNkyJzkAQIfopV;
            HNkyJzkAQIfopV += HNkyJzkAQIfopV;
            HNkyJzkAQIfopV += HNkyJzkAQIfopV;
            HNkyJzkAQIfopV = HNkyJzkAQIfopV;
        }
    }

    if (HNkyJzkAQIfopV >= string("QJOAXkeePggujdvPccxmwwWGogKXnyoaLtDWj")) {
        for (int QmiFWCJHie = 591511703; QmiFWCJHie > 0; QmiFWCJHie--) {
            HNkyJzkAQIfopV += HNkyJzkAQIfopV;
            HNkyJzkAQIfopV += HNkyJzkAQIfopV;
            HNkyJzkAQIfopV = HNkyJzkAQIfopV;
        }
    }

    if (HNkyJzkAQIfopV > string("QJOAXkeePggujdvPccxmwwWGogKXnyoaLtDWj")) {
        for (int uXobtah = 636148031; uXobtah > 0; uXobtah--) {
            HNkyJzkAQIfopV = HNkyJzkAQIfopV;
            HNkyJzkAQIfopV = HNkyJzkAQIfopV;
        }
    }

    return HNkyJzkAQIfopV;
}

avEzdSDysrbnZgd::avEzdSDysrbnZgd()
{
    this->TjDXfWjnO(string("lIeerbSSkQkdUgNGNEgqwRiRMlWKyfuWwswRyhJuwkfCNzrkRSwPodTEteBIRQjhzeXJGcnFFithtcRzbyZggLuLZlXnWKNdFZFMZjvqdlAUkcSBxpDVeoIUrLADwfvUnlwBefzTBeqmgDwIQTIKbBWiZmzXlvggSwWxIdahzCWECXXEunkxRJIbyEWiktiLetwgmvcTWpAfiphDeHbuTVIcEWtTgLwNwkaadiAFapTJABcym"), -183299.38272797957, -1932567329, string("ikjHvmzNQmaHTbgTABJWKoucjuuSzmmBDmQsuiZCogWMXaNDChcgmWkkolcTsdtjWIM"));
    this->JvWLZoN(-1759518800, string("GroDjzdxzksnOghQFGKmCQCFJpwniYldDz"), string("IurbyRMYwJfUqzYtatZDGvrzGbhJfhZkryCbHHcxjNYBcKSYgByJnKkHNbZKaDccyqReNbfsxmgzKCkNElAbtBlnVLxkPKzjsduXnDCmcYcdMFfSkLQKzslAcqxxPoivHRdsGAymuJywllYqGvdNZevyeTQrKrofcwgvxyPNyWOsAtluAuPGHkYmjxQrjagfrsMRvQAFXLuAJrLMMqnodZPSEnmpxNNVqjsVjAlsQNezGEaWpRSsNVCFBK"), string("WNMuVthcHGeloSGNpuvgSVbKSWrYAGDfITdufngvRbMTVkNNpSGejBjBFBrhPsgnzYLdIbRMsAKgjlrGSRbaVyHJAASaregULoVmZaDfUZkTMYUzknnVsWrakAusxnZIL"), -2038009814);
    this->zEJSujwjpPfNnfrR(false);
    this->QdlYVCancCL();
    this->vntTkeMrm(-64277.45472159585, true, 529680.9213895686);
    this->pyBHJzMQ(-1314305030);
    this->aGjpzKdpCiaqS(string("UiTNbWwVSznvNcFDOFYioyJhJLDqlVkPifGgAlWsQyHDNCdcbaOHzsPCqUjmHqiHLHQSSTqBtZydfuRElCcxlajIiTdGNFFTQUpniMfTITFngNaryGpBGslllepAHCWvgMTQwVvWeNnFVamKYIsmZzRiNfSomfEmVfkGKXbAAwwcPReOYOgKwZ"), 1060964102, false, string("kYdZpUmZDNBpCENLUvdPHRvftqnQFtLCdTZGfnqvenfdQLoeWRwEdMJNSeqCrODjsdlnbGLMtBnPySipIuYIHoDTDCHBFHcNgmEEVudhzTTOngSIdAnDIKdmRAwOhwfyOSUlEoUdZzMMBFORNdxdtGPvfPsJUYWP"), string("qqqISofOYiNeGysKPWCSfOspJfthMIxvktzAAhMAJEsnviDmYZEKnyMQWaXaHKTOpYfRKTHqkrCmRiGExdcZgRry"));
    this->vYtYoVEuRtd();
    this->vQEAZu(643152.0830685108, -574123.4177744926, string("qfUfgQouMKQPjJzQGmshqGVDIgkrUVLWLGkjFjotrUqqtLlpuOVfMYYnrqieNeSIEUnXvLFzCdiGNrLhKRZkcKtzoBYAXqqcvBxvfeqkynvtwNuaapYwzAaKIobclsVnWwwRhpxmEUtUqvchInyDVCFPLfLUnZisyJkaTPQxiGoSjkRrlhcpRVoyvkNXETTzQoPsNtOetBhygbAuRGuIMhXqkRlFaUvUxRcDXKxdDmyccBMPzegS"));
    this->MAzWSY(false);
    this->rGMHxvF();
    this->WrdpcSuXZEe(string("YuFMqvCsEsGdGmTOKaSWfPcxyxWeLvIPQDTakZPHZgYDtPbEoXflMPXoPELmxBULsuvigkgQFrOOWySTeIlGchjzhQNOgqFgYolYJvCgPOAUaarFHaLSHRRgAsktmxYmiGlNdQdzRyVWuNiQvetQkxHDfyNSfqrFLMhaPeUnoyEHEjnNknyRaMHWZqWoedlUugGorHLCtPGwunurawHDngmyc"), -1320431632, -190908983, 753132159, -186820.55629888165);
    this->ItTMETqbqWCJYzT(837046.4765833776);
    this->aBsRAGOGXY();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YhMPWrwwhlkXzqlc
{
public:
    bool RPsdXy;
    double YpqatcbmgvWdsAs;
    string OOuDtmbZUZmiGx;
    int WdRkuOCCTAb;
    string lbAqUBdlVpPPE;
    bool gMOHhzvIK;

    YhMPWrwwhlkXzqlc();
    string YkhCmJHSWJKGs(bool GpMhd);
    string DQoBAGvxO();
    int WsENMSSDVLtymMoV(bool sgFXcGOYFLhu);
    void vWqWDBFgwnK(double GpvlfdyBWCH, string BsZaS, string vtNfwiX, bool OQKWqkXBqXWMojhC);
protected:
    int bksQZFlxK;
    double Czvfy;
    string qfyouy;
    bool PjlCPxFwF;
    string FKZvJqxhrv;

    string clchCfn(double OBYhUeXuTG, bool VIEjTmYt);
    void hnaddLVX(string fwMyfHoWTx, bool cqhBzDlbb, int hfWOzZZ);
    double ddrCXtcmMpZJnqU(int bdKMFyBwwvrLss, int eVgyUwBQAkxGx, double xWxQPkvECRdSmimw, bool aqtqCDxR, bool volImDYp);
private:
    bool TlJADllfu;
    int IvlqJZVx;
    double ibnsIpzk;
    double VPkFVhkHkP;
    double eEHwPtfzCx;

    double elJwtWuC(int YmnYIUeqrnejZP, double JHlNw, double VolRD, double JCpffjPXdtpQH);
    int xOXPVUcgeBD(int jKFlyMxDFzM, bool CnhOmctmqcoHp, int RycZTvBbsKCGlrS);
    void biEvKwYsEQaUFA();
    double NshPxZ(string mPaVLeYkhq, int qojEdRKUmIf, int hloibPHEhKVaJVW);
    bool KumQia(double sEdeXOQZdLOyKxLU, bool ZRsBb, int LCZAwdjIQGYScwks, string uEUgmpbMosMk);
    double xnrqRmX();
    bool jorwkdj();
    void hPKgljdk();
};

string YhMPWrwwhlkXzqlc::YkhCmJHSWJKGs(bool GpMhd)
{
    int pOZnPnutI = -537101275;
    string LikQDipiQhF = string("QuBBjrdIyNyLCGPoagVkaQSJiFSdlkOLeObBAMZPbYOnWIlwtDuopnFwMsuRCAVLssABBCLxjShdhHOGTlWyqpsqPFUHBwlsgdfbQZmcbpvGBhtdAfWinYadrrbmXevicdvZdkaToAKnKmlmAZhHMZDtJwsMzCTmTwTqXmzPJWtHdZCXPdLUtpVzYlmwuKCRkApn");
    bool QCIRtMlxwp = true;
    string EhiWl = string("ATSBACphLLYMcrWKuqQtnISPTMTpfICGGdwhWWLcAaelFkkQXIKkamPxeRNObrLYZaBqXrMojGjkOBNHqzKLtdPObTQtkPlxuiivUEkOGamTJaUIyHJaxTvsSSDWLKAKdGubhyruvwxjIOsPvsHYQvwnrrwMAWjdhcfLEzYuKWdnBwAkPA");

    for (int AsNWcxsPoF = 364226209; AsNWcxsPoF > 0; AsNWcxsPoF--) {
        continue;
    }

    for (int CTrUBzbhyyCOi = 301331685; CTrUBzbhyyCOi > 0; CTrUBzbhyyCOi--) {
        QCIRtMlxwp = ! GpMhd;
        QCIRtMlxwp = ! QCIRtMlxwp;
        GpMhd = ! QCIRtMlxwp;
    }

    return EhiWl;
}

string YhMPWrwwhlkXzqlc::DQoBAGvxO()
{
    int sZbOajggRGXJTYll = -973975264;

    if (sZbOajggRGXJTYll != -973975264) {
        for (int REelSZgJvv = 1280673862; REelSZgJvv > 0; REelSZgJvv--) {
            sZbOajggRGXJTYll *= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll /= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll = sZbOajggRGXJTYll;
            sZbOajggRGXJTYll -= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll *= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll /= sZbOajggRGXJTYll;
        }
    }

    if (sZbOajggRGXJTYll < -973975264) {
        for (int gBtacZlyZPqVVo = 1812395261; gBtacZlyZPqVVo > 0; gBtacZlyZPqVVo--) {
            sZbOajggRGXJTYll *= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll /= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll *= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll *= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll -= sZbOajggRGXJTYll;
        }
    }

    if (sZbOajggRGXJTYll <= -973975264) {
        for (int ZlqlllXH = 383625684; ZlqlllXH > 0; ZlqlllXH--) {
            sZbOajggRGXJTYll /= sZbOajggRGXJTYll;
        }
    }

    if (sZbOajggRGXJTYll == -973975264) {
        for (int oXHFtNLRHdPtUyS = 1538775551; oXHFtNLRHdPtUyS > 0; oXHFtNLRHdPtUyS--) {
            sZbOajggRGXJTYll += sZbOajggRGXJTYll;
            sZbOajggRGXJTYll += sZbOajggRGXJTYll;
            sZbOajggRGXJTYll /= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll /= sZbOajggRGXJTYll;
            sZbOajggRGXJTYll = sZbOajggRGXJTYll;
        }
    }

    return string("XiIRTNofXLuuzuSVdoWjnieZlsduZHZDBtnJdyjZCkfXJSeumt");
}

int YhMPWrwwhlkXzqlc::WsENMSSDVLtymMoV(bool sgFXcGOYFLhu)
{
    bool OfDsoLfIQ = true;
    int umJqzhEtlbENSGx = -1850325809;
    int NPJyPPNe = -795937170;
    bool LxVnDmLEs = false;
    int GsqgMUvMFtUjkM = 516384315;
    int cSrlbcEYzbfoFwf = -586806574;
    bool DAVhtkILAlMXyrT = true;
    int qRieqIundKAMBXe = 534960221;
    bool PBRmImTbmfgT = true;

    if (DAVhtkILAlMXyrT != false) {
        for (int iHlPSxZXnRrcvz = 331920649; iHlPSxZXnRrcvz > 0; iHlPSxZXnRrcvz--) {
            OfDsoLfIQ = LxVnDmLEs;
        }
    }

    return qRieqIundKAMBXe;
}

void YhMPWrwwhlkXzqlc::vWqWDBFgwnK(double GpvlfdyBWCH, string BsZaS, string vtNfwiX, bool OQKWqkXBqXWMojhC)
{
    double GDTZvjWJMx = -984861.3460318687;
    double MYQnwBCrGuLowou = 186823.60465666006;
    string ZBkXAeYuqNxEL = string("cGPzcynMWRJxsHne");
    bool cSOkIOW = true;
    string JeYRMsmjdRBdvQ = string("bxmhBJBNffwEitTDeCGlFvHmVUYlEfhnRxDeQeoUdVXdTEnwWqouCjCXWEIeeLTGjMTzyJjliOeweEXuweCPgYgThqqzWGAlqTElFdodL");
    double duecWH = -462486.3948796344;
    int vxPmJt = -165668484;
    bool HgUqmhDfAfyhSX = false;
    double lfAgG = -666517.1945823352;

    for (int EeHLuRByto = 1634958218; EeHLuRByto > 0; EeHLuRByto--) {
        lfAgG += GpvlfdyBWCH;
        JeYRMsmjdRBdvQ = vtNfwiX;
        lfAgG *= duecWH;
        GDTZvjWJMx -= lfAgG;
    }
}

string YhMPWrwwhlkXzqlc::clchCfn(double OBYhUeXuTG, bool VIEjTmYt)
{
    double KieRCv = 203802.7883680613;
    double xePfnNZSHHuYnyz = 181548.5934204257;
    string vhNNpSIt = string("LogLmmDIrDUkxqwNNymOaJUGKkslyXOjpuhBNtoebZpZtMgpqfanWTDaRzmddPqvGNEkffsHQiukINSSBzBbIkTWcfIoZGtXPADTJdUDiLmfxhhwBQBPrMOTNvvzYDJKOIxVrjBfkbHvZdaICSJLtDriXcyQgnwQTxpZRSqLUFUkbBMzKXyjVThIHMEayYcardjfNdAbjbkjugeuhXTWJRe");
    string QBAAQeFnNWIYD = string("iOuSqoWYjeCHRmQnuRnTefBHul");
    double aoSCvCHHQ = -677014.9018360556;
    int kOXDvWVofOl = -687591605;
    string CnZvPTkywpnReoCr = string("pzTbFQGVEgPrzawgUAMDbAJGtSgmuoaNOTpwfwMZebEGgQLMTQvICqcasHtTgqjsrvipfZDvdjewTgpGPHmHYaHdzZAaxmCNurxkOAwuAFVrRneyMFQLgcjtakqnHVxezceXUizWMOOhSrQLcNgComZStzRFSXqIRmvwCmzKyhPh");

    if (xePfnNZSHHuYnyz == 203802.7883680613) {
        for (int uqjEqivfppfncFQN = 1626210275; uqjEqivfppfncFQN > 0; uqjEqivfppfncFQN--) {
            vhNNpSIt = QBAAQeFnNWIYD;
        }
    }

    if (KieRCv >= 381506.9553862261) {
        for (int iZtnrEpxODgYRiIH = 1889763875; iZtnrEpxODgYRiIH > 0; iZtnrEpxODgYRiIH--) {
            xePfnNZSHHuYnyz = xePfnNZSHHuYnyz;
        }
    }

    for (int OZmmdTdyOiZe = 1216423521; OZmmdTdyOiZe > 0; OZmmdTdyOiZe--) {
        xePfnNZSHHuYnyz += OBYhUeXuTG;
        OBYhUeXuTG = xePfnNZSHHuYnyz;
        aoSCvCHHQ -= aoSCvCHHQ;
    }

    for (int PqpOdQ = 59366265; PqpOdQ > 0; PqpOdQ--) {
        vhNNpSIt = vhNNpSIt;
        CnZvPTkywpnReoCr += vhNNpSIt;
        aoSCvCHHQ -= xePfnNZSHHuYnyz;
    }

    return CnZvPTkywpnReoCr;
}

void YhMPWrwwhlkXzqlc::hnaddLVX(string fwMyfHoWTx, bool cqhBzDlbb, int hfWOzZZ)
{
    int CqdozPamTZ = 1201134754;
    int TYAZNULbWhRGcoS = 1146950744;
    string iGwqK = string("xayZyyDrCKyxNSHyfymBTbrZBBVHZZrOfCSlxopGlkrbMGZjHRvNOkBBrEIKxwcQmrYZRPpxcoQHRDvX");
    bool lVvSLW = false;
    int hOCROnrBKEX = 1588307307;
    double bdsWMP = 851257.808707076;
    int atSTqoldRUHWqth = -1041027330;

    if (hfWOzZZ <= 1588307307) {
        for (int bPjty = 996610777; bPjty > 0; bPjty--) {
            continue;
        }
    }

    for (int hWyVwwmngCYBgfi = 2047973863; hWyVwwmngCYBgfi > 0; hWyVwwmngCYBgfi--) {
        TYAZNULbWhRGcoS = hfWOzZZ;
    }
}

double YhMPWrwwhlkXzqlc::ddrCXtcmMpZJnqU(int bdKMFyBwwvrLss, int eVgyUwBQAkxGx, double xWxQPkvECRdSmimw, bool aqtqCDxR, bool volImDYp)
{
    string AoqUlojyQuJXzqHO = string("vBCYywzKDRPgMFLTbTbpiYOGXuqiQaqwuINZieKeEOHLjQYuYCnjmbFgPoWGFiVkAcdupnznkLpvVQRaBHzGDlrkYqYqKRywaQFdFTAPflCyAknxXftlch");
    bool AnEcVDF = true;
    int rWfpdQAsF = 1024091450;
    string mKaChSyVQiK = string("IFPlJFHRfMFXAsNeQnxNtKwejiDOEgfUNHQOVZGlucDkxrtGuKjIiEratOCTGbBSjqMEQdCVJNLxOrgpBGPlxozbXNnSn");
    bool zODWvKdPGaYaSTl = true;
    string rfLuIWELaWsNR = string("wUxKAVMprjWPTdrqzuBwsqqWnsllbRaZKJuYLEWpglZbxEDwdyjmCieIdgaxiApTIGWjEfOZVUNHwzoNDlfwbptmupeFVqHwuKmbauCsZTkVRMbNlhQlgHHYZdHOFBpTtgEKIlljzZMXYrsQAIOmrAsgqETWuPGsdIWBlTDxiWHCaNDP");
    double wQcKmNcaxYfFvS = -630567.8877915223;
    bool xZGdRJjUo = true;

    return wQcKmNcaxYfFvS;
}

double YhMPWrwwhlkXzqlc::elJwtWuC(int YmnYIUeqrnejZP, double JHlNw, double VolRD, double JCpffjPXdtpQH)
{
    double VGYitEBgwfRtVW = -464291.13077191776;

    return VGYitEBgwfRtVW;
}

int YhMPWrwwhlkXzqlc::xOXPVUcgeBD(int jKFlyMxDFzM, bool CnhOmctmqcoHp, int RycZTvBbsKCGlrS)
{
    bool urHlhGfgO = true;
    int hxqDTwEDyWeHpl = -789539577;
    int hygvrzCjX = -2121179423;
    string OddVVDP = string("JTVUkwaeuzutJMbtLXyUVEcHstRHVsynaFauMfWMqaXPrSgGnLPmfoFYnpTBMNJcFGuDVL");
    double mHOQHoTT = -637194.6494941596;
    int ZBlEPgrwCupvgXEN = -740078820;
    double WoLCOabYc = -139203.61711496205;
    string QQxxrEZXEzvrAW = string("GRNASooxPrwCkLIIymUwWwoYLCaunSEZvvIypGtb");
    bool SRngDVoGoNHn = false;

    if (hxqDTwEDyWeHpl < -740078820) {
        for (int EuxagRApKHIBVvT = 30395276; EuxagRApKHIBVvT > 0; EuxagRApKHIBVvT--) {
            hxqDTwEDyWeHpl = hxqDTwEDyWeHpl;
        }
    }

    if (hygvrzCjX != -740078820) {
        for (int JfAEpVkfVzX = 199638096; JfAEpVkfVzX > 0; JfAEpVkfVzX--) {
            RycZTvBbsKCGlrS = ZBlEPgrwCupvgXEN;
            hxqDTwEDyWeHpl /= hygvrzCjX;
            jKFlyMxDFzM = hygvrzCjX;
            ZBlEPgrwCupvgXEN = RycZTvBbsKCGlrS;
        }
    }

    if (hygvrzCjX <= 1634527165) {
        for (int WftKrGHLIC = 1628075551; WftKrGHLIC > 0; WftKrGHLIC--) {
            continue;
        }
    }

    return ZBlEPgrwCupvgXEN;
}

void YhMPWrwwhlkXzqlc::biEvKwYsEQaUFA()
{
    double VMISJgTsDjjFR = -708937.3484244974;
    double iPYiArAaednR = 776909.3150102212;
    bool bVylsYZZuKgDIbv = true;
    double nJMKGYURt = -529229.7965413589;
    double ylzQWZfGvtPsGeEw = -955611.6591115448;
    bool uSXTnwM = false;
    double HRpDiSkBl = 547902.3806857137;
    int ySUwxqKbUYTa = -2140246851;

    if (iPYiArAaednR < 547902.3806857137) {
        for (int GNKGBe = 867296567; GNKGBe > 0; GNKGBe--) {
            HRpDiSkBl = iPYiArAaednR;
            ylzQWZfGvtPsGeEw *= iPYiArAaednR;
        }
    }
}

double YhMPWrwwhlkXzqlc::NshPxZ(string mPaVLeYkhq, int qojEdRKUmIf, int hloibPHEhKVaJVW)
{
    string HSOHGbWNEzHwa = string("yPEDWJEUdAdobJVgRuZrIYBBKpUnBfrLCsbPXsapDQRDEKMiXnSQwodWvDsRhYTiSSOeMCJJcZYVvHFvpHzakpaRklCxmTULmKJUiRwqtqrSA");
    bool MhZFBmzAfBGxIxg = false;
    bool cxFHHqeQaliZtus = false;

    if (cxFHHqeQaliZtus == false) {
        for (int mvAeHFVDYG = 459685130; mvAeHFVDYG > 0; mvAeHFVDYG--) {
            mPaVLeYkhq += HSOHGbWNEzHwa;
        }
    }

    if (cxFHHqeQaliZtus == false) {
        for (int snxVtEsQLrKItHf = 1558765233; snxVtEsQLrKItHf > 0; snxVtEsQLrKItHf--) {
            mPaVLeYkhq = mPaVLeYkhq;
            hloibPHEhKVaJVW *= hloibPHEhKVaJVW;
        }
    }

    return 326323.8021082945;
}

bool YhMPWrwwhlkXzqlc::KumQia(double sEdeXOQZdLOyKxLU, bool ZRsBb, int LCZAwdjIQGYScwks, string uEUgmpbMosMk)
{
    string JwRLFBbIMTJWSQ = string("lXGxPWViQXFiMHEkaPramMZQWoCCGMFsggjpFfNkFrYzIlsvSoRmltBAsugFSZKawyiotqxOrpidFYEUnDioiXCOIDRthjgKXEcepDWnHEChxRrQcpecimAVvivkRVNSqZgGKEhRucrSkKtqymvnI");

    for (int OgsVxVUOeRlbdB = 276861495; OgsVxVUOeRlbdB > 0; OgsVxVUOeRlbdB--) {
        continue;
    }

    for (int CgfKmWnRNEzEf = 1665472454; CgfKmWnRNEzEf > 0; CgfKmWnRNEzEf--) {
        LCZAwdjIQGYScwks -= LCZAwdjIQGYScwks;
        uEUgmpbMosMk += uEUgmpbMosMk;
    }

    return ZRsBb;
}

double YhMPWrwwhlkXzqlc::xnrqRmX()
{
    double kqvyZujmV = -1027714.0048703423;

    if (kqvyZujmV != -1027714.0048703423) {
        for (int BogllhGIK = 2105892041; BogllhGIK > 0; BogllhGIK--) {
            kqvyZujmV = kqvyZujmV;
            kqvyZujmV /= kqvyZujmV;
            kqvyZujmV /= kqvyZujmV;
            kqvyZujmV /= kqvyZujmV;
            kqvyZujmV -= kqvyZujmV;
            kqvyZujmV -= kqvyZujmV;
            kqvyZujmV = kqvyZujmV;
            kqvyZujmV *= kqvyZujmV;
            kqvyZujmV *= kqvyZujmV;
        }
    }

    if (kqvyZujmV <= -1027714.0048703423) {
        for (int bRnnskjLtD = 853732188; bRnnskjLtD > 0; bRnnskjLtD--) {
            kqvyZujmV /= kqvyZujmV;
            kqvyZujmV = kqvyZujmV;
            kqvyZujmV = kqvyZujmV;
            kqvyZujmV -= kqvyZujmV;
            kqvyZujmV -= kqvyZujmV;
            kqvyZujmV += kqvyZujmV;
            kqvyZujmV /= kqvyZujmV;
            kqvyZujmV += kqvyZujmV;
            kqvyZujmV *= kqvyZujmV;
            kqvyZujmV = kqvyZujmV;
        }
    }

    if (kqvyZujmV != -1027714.0048703423) {
        for (int GcRxnoXlvcHeLKRh = 1394737488; GcRxnoXlvcHeLKRh > 0; GcRxnoXlvcHeLKRh--) {
            kqvyZujmV /= kqvyZujmV;
            kqvyZujmV = kqvyZujmV;
        }
    }

    if (kqvyZujmV < -1027714.0048703423) {
        for (int MdiLnlfkFKtjwp = 2020384821; MdiLnlfkFKtjwp > 0; MdiLnlfkFKtjwp--) {
            kqvyZujmV = kqvyZujmV;
        }
    }

    if (kqvyZujmV == -1027714.0048703423) {
        for (int qlDQJjLAvKf = 912300625; qlDQJjLAvKf > 0; qlDQJjLAvKf--) {
            kqvyZujmV = kqvyZujmV;
        }
    }

    return kqvyZujmV;
}

bool YhMPWrwwhlkXzqlc::jorwkdj()
{
    string lFUJZxybuKP = string("fzclfvavNHWwmnTlZrOpasHlSqFXIPDIsvNzgSnnWvkNfRlxiOOGFPrFNiGqXWyWxcnCXEBGVzHxfXATBGsMAvafFwmObRkaFwZhGjUGVRthnbyeorNBwnJzQlSOmFhZekPPFMDRGriqyoJwzDsBeZdtNwRHufiweaAPnWppmNLlSgYpEjzaxqMR");
    int kmFBiD = 502884934;
    double dhhHRRowRozY = -875211.9092545494;
    bool mKYcCjcfGCXMFfZI = true;
    string GsQsvGls = string("dKUZnFOZeGrePUSsvWRifuTkvfuhPCjxSSjFTpnQgXNNWICRKZCjyZGApfIPRRZwDoaDDUukJXJGYRyXGmhtCxleeaIJaPEsnvjOriEzWwfc");
    bool tAwEPUj = false;
    string IiqtZHHlSd = string("EmpZSXOdmqVcEgxUfzJPgiNvEqaHZnEhvQ");
    string FausgfTgopsF = string("Sv");

    for (int eDIfytag = 1018486559; eDIfytag > 0; eDIfytag--) {
        continue;
    }

    for (int djPFnlsrkJgb = 572991886; djPFnlsrkJgb > 0; djPFnlsrkJgb--) {
        lFUJZxybuKP += IiqtZHHlSd;
        tAwEPUj = tAwEPUj;
        IiqtZHHlSd = lFUJZxybuKP;
    }

    for (int AoyaTjqgs = 1393553793; AoyaTjqgs > 0; AoyaTjqgs--) {
        continue;
    }

    return tAwEPUj;
}

void YhMPWrwwhlkXzqlc::hPKgljdk()
{
    double YmaKuEFYdem = 674116.6567394149;
    double rEyvrWABnjqLiNkT = -259628.5135279233;
    double joVkbezVvKhhuPE = -327726.91711810965;
    double KrNUTLmBrM = -878290.7147234592;
    double rBjGonRNWgYYRpcN = 469800.0227059275;
    bool tIilAm = true;
    int DXgXbckGIYLFG = -1097654771;
    bool mPSyPwcDP = true;
    int xiUXGtA = -807708500;

    for (int CvYgwWoRUcqBvOcW = 1784198694; CvYgwWoRUcqBvOcW > 0; CvYgwWoRUcqBvOcW--) {
        continue;
    }

    if (rEyvrWABnjqLiNkT != -259628.5135279233) {
        for (int HlpGYZpkhp = 1599375237; HlpGYZpkhp > 0; HlpGYZpkhp--) {
            rBjGonRNWgYYRpcN /= joVkbezVvKhhuPE;
            rEyvrWABnjqLiNkT += YmaKuEFYdem;
            YmaKuEFYdem /= joVkbezVvKhhuPE;
            joVkbezVvKhhuPE += YmaKuEFYdem;
        }
    }

    for (int yZoTMgnRmGUBzGk = 1255579156; yZoTMgnRmGUBzGk > 0; yZoTMgnRmGUBzGk--) {
        rEyvrWABnjqLiNkT = rEyvrWABnjqLiNkT;
        YmaKuEFYdem = joVkbezVvKhhuPE;
        joVkbezVvKhhuPE -= joVkbezVvKhhuPE;
        joVkbezVvKhhuPE /= KrNUTLmBrM;
        xiUXGtA -= DXgXbckGIYLFG;
    }

    if (rEyvrWABnjqLiNkT < -259628.5135279233) {
        for (int EPiuSzSJexWn = 1185867377; EPiuSzSJexWn > 0; EPiuSzSJexWn--) {
            KrNUTLmBrM -= rBjGonRNWgYYRpcN;
        }
    }

    for (int GKAhSoPlvAD = 385388781; GKAhSoPlvAD > 0; GKAhSoPlvAD--) {
        rEyvrWABnjqLiNkT += YmaKuEFYdem;
        joVkbezVvKhhuPE -= joVkbezVvKhhuPE;
    }

    for (int XtmDPIBRSOhM = 1623674535; XtmDPIBRSOhM > 0; XtmDPIBRSOhM--) {
        rEyvrWABnjqLiNkT = YmaKuEFYdem;
        joVkbezVvKhhuPE /= KrNUTLmBrM;
    }

    for (int fEeVOyL = 1503563565; fEeVOyL > 0; fEeVOyL--) {
        rBjGonRNWgYYRpcN *= rBjGonRNWgYYRpcN;
    }

    for (int WzvOrdDuF = 713561145; WzvOrdDuF > 0; WzvOrdDuF--) {
        joVkbezVvKhhuPE = YmaKuEFYdem;
    }
}

YhMPWrwwhlkXzqlc::YhMPWrwwhlkXzqlc()
{
    this->YkhCmJHSWJKGs(false);
    this->DQoBAGvxO();
    this->WsENMSSDVLtymMoV(false);
    this->vWqWDBFgwnK(-1022421.1992776151, string("SKQAWNzHqgeIGZyfl"), string("XDgkqIWInngDnBwhRAzcXwsrEytjNvuqXJIReeWLiwYBLTJxJJfttRvfPIQwrNZUWcpnUuJxMwOxULavGxnYxEgaEqbVEuJfLKJafwvxSyxiYXGpjrrAxEzRSEYwlcakghJlCwdjjWMPWxwZjfBLoyqjarEReFBfgThxcSoELYmhGNGsudrObDUMEzkPFlUAGjqwjwPBQtJszGIEUUnlR"), false);
    this->clchCfn(381506.9553862261, false);
    this->hnaddLVX(string("JdAEBUofjzmIkJOVlQGpGFlUaMFkpGwbTeyKiZXjRnObHpSxlPDauDqvbsiVgPmMIKObAaBfEVdOeoLvNCupxeLnQUEbVPeqfFslwvSxxQfnXgqPcddpBJhvtZElyonZJofEaYcmlziaqPGhOENDJKFfYuqikElezHXCGCjpJJoVBFFTqaDnp"), true, 885874223);
    this->ddrCXtcmMpZJnqU(-828692660, -1575166999, 886366.6464185393, true, true);
    this->elJwtWuC(-1012391684, -544916.9800752382, -900014.6020899138, 190737.0928180587);
    this->xOXPVUcgeBD(1703967592, false, 1634527165);
    this->biEvKwYsEQaUFA();
    this->NshPxZ(string("WNJQqPyfORzOpnRqxCdnwBdTEMrz"), -800406575, -858699250);
    this->KumQia(565597.757728661, false, 1984852820, string("PctSuhxCLlRWWoeVEJVYhElFNdNYrWTUMkezLqHhDIhRhwXxrwpvZWGdNOtAsbcLropThzXRHtqaqbsbpqQnwWFNHPnbfToVOSbiiIOYifAglwDFQtROgTDTiLircEkxERSTbMxugHIgnFrdooMtFIDDHXiIUSFuXKPwEFLfJLOHVyb"));
    this->xnrqRmX();
    this->jorwkdj();
    this->hPKgljdk();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SyvWcuUXVH
{
public:
    bool BujmtDtW;
    int NyFDkmniXxDCK;
    string SeZWOnlTHf;
    bool yweBZfeKZqcomvll;

    SyvWcuUXVH();
    bool pjpXbtQcvMtIICGg(string OfeokABRcmshn, double NnfljNrBuGYrWv, double iWBdOZFIGAxVnhp, double yUJzxKCLdn);
protected:
    bool NlgvDppdYS;

    bool CJjqsBrFiA(double nsRATbgFBEfbK, double ZCquzUuWqfQY);
private:
    string kKOybdBWGA;

    bool NIhskyZUQFZofS(string wDAKQejHrfH, string CkFlyeBMo, bool rZSubAANFwT, int PHTTEFBh, double mfLxeQupWVWK);
    double lppMLQ(bool cUAvBH, int ZWmlbSZWlGva, string nkSEvyKHec, int qPJigQOYtviuGG);
    string fSpWLbGmF(int xUJKjlrGlsWNw, double BNchVVAV, int olQnH, int KexTukmFxwL);
    string RxsOCwqCorsDxmA();
    string WyzIiEayL(bool oNVOd, int oIepBN, bool FsqZkhRWYdj);
    void yBoSYIPkGQor(string EgFvlCbcHW, string FfyNFpptBrlYtR, bool bHqBla, bool gEXgrvNNZES, int IZLPLDuhUhrYYu);
    void WEsLItPKkqTaZ(string CRfzlQG, string sYOxTt, double jLOzuOSTSfeBwNH, double fOfSHfhxCnssNhHm, int TpsSpscOiwzj);
};

bool SyvWcuUXVH::pjpXbtQcvMtIICGg(string OfeokABRcmshn, double NnfljNrBuGYrWv, double iWBdOZFIGAxVnhp, double yUJzxKCLdn)
{
    int qLulkezsHNv = 1186502271;
    bool hiUfsDVOAeuOjXvE = false;
    bool SKYBczPfyDxzdeMa = true;
    int tvuEZADCgAFYayT = -1868499087;
    string AoSzSQyuTDSrv = string("KnfQtGfeeIMKofkZmdBZVuWJUsteLUMHSVtPCVVsvqnakJEewrJNQlPyhWvPIqsj");

    return SKYBczPfyDxzdeMa;
}

bool SyvWcuUXVH::CJjqsBrFiA(double nsRATbgFBEfbK, double ZCquzUuWqfQY)
{
    bool yyXqhCJOdAfpexz = false;
    bool OrtDVQbzC = true;
    double frRfwRg = 825204.0137598761;
    string iHqYbefXNJigMfXm = string("SHKCNviIcFbkEOTAt");
    string gTLNXyfbT = string("RCWonwThBpcQnjHRPdVwHVryFgegKloSVvyBctVukuNwUNuzcHbdZKNgwkfhsjSMjCNGtHCysXwBfXpSridWRmvlRLXQhJNajlxEIoLCuyIFupMWnuUelqnHslPHIogODAVkfwBuMbSnZNGBARYicIpuOexgtOWlksQUzuWmRvSkN");
    double lvZOiTPLSwA = -684327.1154477521;
    bool hGXGjT = false;

    if (nsRATbgFBEfbK >= 816343.7255281763) {
        for (int nKzyPeZiSCOLXd = 1810085783; nKzyPeZiSCOLXd > 0; nKzyPeZiSCOLXd--) {
            continue;
        }
    }

    for (int qZDzRuFJu = 1230882392; qZDzRuFJu > 0; qZDzRuFJu--) {
        lvZOiTPLSwA -= ZCquzUuWqfQY;
        ZCquzUuWqfQY = frRfwRg;
        lvZOiTPLSwA = ZCquzUuWqfQY;
        ZCquzUuWqfQY /= lvZOiTPLSwA;
    }

    if (frRfwRg == -684327.1154477521) {
        for (int YzxjOUoLzMta = 687845662; YzxjOUoLzMta > 0; YzxjOUoLzMta--) {
            continue;
        }
    }

    for (int yuEyKEMPwlGMZgec = 1984964864; yuEyKEMPwlGMZgec > 0; yuEyKEMPwlGMZgec--) {
        iHqYbefXNJigMfXm = iHqYbefXNJigMfXm;
        lvZOiTPLSwA *= ZCquzUuWqfQY;
    }

    if (ZCquzUuWqfQY > 495969.4784287203) {
        for (int bpWnAaDEIkFE = 517350980; bpWnAaDEIkFE > 0; bpWnAaDEIkFE--) {
            nsRATbgFBEfbK *= nsRATbgFBEfbK;
            OrtDVQbzC = ! OrtDVQbzC;
            lvZOiTPLSwA *= frRfwRg;
            frRfwRg += frRfwRg;
        }
    }

    return hGXGjT;
}

bool SyvWcuUXVH::NIhskyZUQFZofS(string wDAKQejHrfH, string CkFlyeBMo, bool rZSubAANFwT, int PHTTEFBh, double mfLxeQupWVWK)
{
    bool RJWSxq = false;
    int CjLzqadR = 1700308414;
    double CsNvRiHaMcE = 528131.850525752;

    return RJWSxq;
}

double SyvWcuUXVH::lppMLQ(bool cUAvBH, int ZWmlbSZWlGva, string nkSEvyKHec, int qPJigQOYtviuGG)
{
    bool zIJZAzjOgHSHxH = false;
    int gQahSjxO = -292163955;
    bool NWWxo = true;

    for (int zgDVwm = 730109188; zgDVwm > 0; zgDVwm--) {
        NWWxo = cUAvBH;
        qPJigQOYtviuGG *= ZWmlbSZWlGva;
        zIJZAzjOgHSHxH = zIJZAzjOgHSHxH;
    }

    for (int uHKbDUXaqOHkdyC = 1328054255; uHKbDUXaqOHkdyC > 0; uHKbDUXaqOHkdyC--) {
        qPJigQOYtviuGG += ZWmlbSZWlGva;
    }

    return 494741.3834296009;
}

string SyvWcuUXVH::fSpWLbGmF(int xUJKjlrGlsWNw, double BNchVVAV, int olQnH, int KexTukmFxwL)
{
    string hzYfRk = string("jnmgsvPHQPdZUsYJHrGXfQDWTbXgeVEyvXTuuhvuFqVbvprPcHWSouuhBncvgoOgeQNLqTwlHUrrvridPIlArbIhPSdrPgycNOBggdJdEwsJljDqTyarjjdwkyuVcNGSvZmDcbuImwhvNmCoMxxDwJLjZJPTrmnmOZGFOJgXdTDCtGcYCPkxczOtWzBno");
    double kPjHsMBMaDEnAyZQ = 264231.95383914665;
    double YCNrgtK = -936055.2784775435;
    string kbpDTk = string("EowQYtnKrtzPRUavvSHLYOZbGdMLhCoPFWNOiTUSsHwhxglXSnBYFZqDeTxKBJSSFBTWiAnwFUwYpVjLtpBSIEoqBJFlBeXpBCqeNBxCzECsGnifyJLbLygbYdeLByzqlaAdZnzHjzCQhfqfZBVAVVFhsXxAzcOsnaqdQBFgqPeSJguKRdqTygZvvUNQUryFMyuxXkwnZlmhmewkWQTpLCsWciujVHqUjZ");

    for (int NgotWwf = 565014294; NgotWwf > 0; NgotWwf--) {
        BNchVVAV = BNchVVAV;
        kPjHsMBMaDEnAyZQ += BNchVVAV;
    }

    for (int NYfuyoJFIBHWzH = 488626452; NYfuyoJFIBHWzH > 0; NYfuyoJFIBHWzH--) {
        xUJKjlrGlsWNw += xUJKjlrGlsWNw;
        YCNrgtK = BNchVVAV;
        kbpDTk += kbpDTk;
        hzYfRk += hzYfRk;
        kPjHsMBMaDEnAyZQ += YCNrgtK;
        YCNrgtK = kPjHsMBMaDEnAyZQ;
    }

    return kbpDTk;
}

string SyvWcuUXVH::RxsOCwqCorsDxmA()
{
    int wDKSkHNNgBOiwY = -859435595;
    bool erBUII = false;
    string DBPWmjfMYxOXzVyn = string("ghAjxBwTwfUAKdmfFlGhgRVlKzyUzeIiDuWtlVqdZTFXRCubEFAksyobRJEYTNfJQNxTJOwDJbWOzDigtVOAjRbCJSyVyHFcbTtkuGhgDuUyaazLitshzJOiRdoSjUPFvtrsGNHDasvEAmcPTmjMcdGtVoiSTFYwaCOYyUC");
    bool zKgYo = true;
    string aaECTxrRig = string("rUbavdAXWEhEQJWdXcuoaqREgwRFRNBkSpzuZcStAbyrxcwUETiCoSTkCdfGsLxwcXTeGVpKMidnnwXJMiqPFhtoLwEIluYvZUPqkliP");
    int aebzufsbnspwmkkD = -420116477;
    bool YroqzDIUBTlvUU = false;
    double fVmzQ = 819842.9936977847;
    int ClmjrfBsWbtGCAJ = 174659161;

    if (aebzufsbnspwmkkD >= -859435595) {
        for (int xjoFnw = 2064956081; xjoFnw > 0; xjoFnw--) {
            erBUII = ! YroqzDIUBTlvUU;
            YroqzDIUBTlvUU = zKgYo;
            YroqzDIUBTlvUU = ! erBUII;
        }
    }

    if (aebzufsbnspwmkkD != 174659161) {
        for (int oFBxx = 2137538597; oFBxx > 0; oFBxx--) {
            wDKSkHNNgBOiwY /= wDKSkHNNgBOiwY;
            fVmzQ /= fVmzQ;
        }
    }

    if (aebzufsbnspwmkkD >= 174659161) {
        for (int ZUHBsvdYSNQI = 98653569; ZUHBsvdYSNQI > 0; ZUHBsvdYSNQI--) {
            YroqzDIUBTlvUU = ! YroqzDIUBTlvUU;
            aaECTxrRig = DBPWmjfMYxOXzVyn;
            wDKSkHNNgBOiwY += aebzufsbnspwmkkD;
            zKgYo = zKgYo;
        }
    }

    return aaECTxrRig;
}

string SyvWcuUXVH::WyzIiEayL(bool oNVOd, int oIepBN, bool FsqZkhRWYdj)
{
    int jkuglC = 715061184;

    return string("ghlLGvrTzOvYITIvgfUJAeCJWPmlvdaeWPhUwLUUhQTNNtcpAhzYHCUzccHZagDaFtWNRcEcVJDbBnnyiFkXkjZRzcdKnTklPplMrXSmsRuHqwvgiQRixGynZUaqhOFIwkcJYePkNGCXJvwgZby");
}

void SyvWcuUXVH::yBoSYIPkGQor(string EgFvlCbcHW, string FfyNFpptBrlYtR, bool bHqBla, bool gEXgrvNNZES, int IZLPLDuhUhrYYu)
{
    int soyqiZqad = 1278116849;
    int oXDmg = 399499069;
    double shJkODwFyMIA = -481515.1602600629;
    string cvgeBhL = string("nPTHtjZwxawmVTvNdZksxGtkcrdxraDmCettJhrlHWjOJxZIiyVMUSBeCwYnhIpkjYadvfefykqAGpxSjcgWlWCfvViMcGdbKBqpI");
    bool hdFMvUD = false;
    double shbzgaVA = 758094.6986567497;
    int FUtKif = 1629717421;

    if (oXDmg < -2130984602) {
        for (int TxJHoZXmhP = 2088742223; TxJHoZXmhP > 0; TxJHoZXmhP--) {
            gEXgrvNNZES = gEXgrvNNZES;
        }
    }
}

void SyvWcuUXVH::WEsLItPKkqTaZ(string CRfzlQG, string sYOxTt, double jLOzuOSTSfeBwNH, double fOfSHfhxCnssNhHm, int TpsSpscOiwzj)
{
    string SFZbB = string("lQpPuiOjRxigkXZPOchBkAzKzUgSXXtQGMBBEoRdUOrvEzuaUxRsAEIAhIiryQajjlEEciqzkqaRKKgnEUmjvhLjuWNBKVzdgoaacRCbFwJHRttsRWkyhpjPRRKtDxcjFlRPlMxgffvGkQddFSeCajlpvEruMhXkwrflcRIetyIhAqxWiNLBikltEATUwkWokXTzCIsjYzCrZwNQtTdbILvikGGOuUoMoBOUgZtcevaMTjRC");
    int xqIpBEoNEXfD = -1669343629;
    bool vNhoIamFTVoT = false;
    bool RSHgnZwnGJCLKk = false;
    int oJOFeaxEfjvwcXQV = 1496480854;
    string GAqyAevA = string("keMPQeamWeswWCpQOowpWusLLyPEFAFiKjHvOCuTMsizWjkLqqOQqrRKSBatxejLQJOFkLNDXBItqVIgCAlXVZVEsFXZdvtYKSVBghwvgWydiiXFRukOHDUROhGNWfniTASBmEMcGodwankygaSbWGTHaLXMvOKDksMydDWoLXjrivtldXjhfoPyyyqWAeUwHNAKJSFmRmHkVAA");
    int TfiWbnpRvHquMyX = -708267158;
    double xCFKW = 586124.6725642328;
    string YHDuC = string("YaZuvtsHgLREwWoUwoZoiwNZBdmTqdnCaeYOtGKZkxgwJyjDatySipUWUfrPJsDtqCofA");

    for (int EnJZzWtjVHtTqijY = 1379291232; EnJZzWtjVHtTqijY > 0; EnJZzWtjVHtTqijY--) {
        CRfzlQG = CRfzlQG;
        GAqyAevA += YHDuC;
        CRfzlQG = sYOxTt;
    }
}

SyvWcuUXVH::SyvWcuUXVH()
{
    this->pjpXbtQcvMtIICGg(string("aBdULSBjnEkBGHqVZQKSCCeTrOQTuGVrNRAqKzaGHRKLcrCfyoWQiOFkoNpDYRDlEnkVvWWnapFfwMLEWysnvPBQLuJGtsjcvDxRIxKu"), -880030.4032787591, -860672.1610290937, 981075.3738055017);
    this->CJjqsBrFiA(495969.4784287203, 816343.7255281763);
    this->NIhskyZUQFZofS(string("nQYyPwryQCFbdRRzJgwrKMNxFlrfXtNWKQAHPCJBQappaTLdoNmbZGdeuEJmloiFLiawwsGDXARTLWYtQOLakJVoISQEv"), string("jckyYGABFsnexSgWMJtCbqCUVFEOXzDRimBggdarDogFzuhyIvnPfyLJFEfXneDAstZrcngOrqXStZyQFbJCPKUgnlfQTAKTiDcoESXDKImwRIjTQcXUKLZIeRoDjVzFtUvqXpChdeRaFUkjF"), true, 705547911, 248179.46477930245);
    this->lppMLQ(true, 499600819, string("qpnrYbFcBinQrTvJFzYXmyBLRJQWBNkdtfuJBDLujJknPQnAhSDXlxhwlHOSYYKHtZnYhfivoGnhpnZnYaqvoONqArZcbeRfKKchPgkOwCAWGVmfoUntoJjLRqPaXvlxLoXLzmfzXWYgxopngWrBiuYWhhEBPcWTBCCevhMBQVlTENPMHMLEYfsnubQNRQNLBnRPPtwplMYUBIUdOFvaVCkgmRXzZoNngpJVCidxbrLTgwwrALkutxHagYWGGU"), -1228525214);
    this->fSpWLbGmF(-2094588338, -426019.85185280093, -991597414, -1859137556);
    this->RxsOCwqCorsDxmA();
    this->WyzIiEayL(true, 122255229, true);
    this->yBoSYIPkGQor(string("EbqvWiCjJVljgEZAMLogfjBxMZGzlPpPceEOCGMJVtJjfsPSYIudQSyzAbiGlCJAAKPklDNKAvmTifcRmuxrgYAlIktgDeAPNOn"), string("OIAPWAsxBFNrmdtlkVdjHRCiJbPrIZyCTUQvvnQRtobQbQCTlqIGQvYXmlsRpJWWpXHaURCJRmsqqlNSWfcWahcTuHeblcJzNnIHyBzJABVeJmepKRTyWLnKboMhaNxBebhCEPySkWVGJsengwfwTCqNCfuxinIzdCbLGWiRcvsJCiAjgHzlT"), true, true, -2130984602);
    this->WEsLItPKkqTaZ(string("GafgpUhKHUsIcoLZjhsNtkNBWfvlBvnaqFCyUVVIpzqjSecYzHbkRkqVWBuiLlCLEFGVfoEQRpMnlGTGKVvmPfJdmrwPsZEFEDwHwznzIkoNhBLwkCtEcYEbwstJWkkfRcyXxTunivnkyWqgdDlTWILuBDgptVXlPdjnsPbIZJQbwxgpWcrjMUZFAtLZLZncALhkkneRsomGlaNsimqQ"), string("ucoKZcfeyicmECeAhBqcJBhkDBfMzJgGXZzDFicpBlHrQcWvAxBcPXICOHysiFcETfhHxgnnlrFIFphCIPOkZuTCvHdoTXVuzfZjfYNnMxoyynkZdtZCEYPdncnXMchcyQYppCklyzdEGQXWcmsMYpsDLyIvtVTpLsecXouM"), -677222.0926063635, -929607.0831263853, 1500649109);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class oWLFmzHFncA
{
public:
    int rdUAjDFIuUWK;
    bool lIUlvgSXe;
    int qvUkYHkQr;
    int bpvJWHjzUvwGy;

    oWLFmzHFncA();
    bool LgvPR(string uKsRaiCAKHBWQ);
    double VYAjkcj(int jghDCLeEjo, int ikXfOVeIxTRWVf);
    string JMEngmQ(bool tiXUHuGAFciqe, bool ryBVEtgztpCOCwfD);
    string pkQRmUTGTl(int ruDpwTeiWSMclE, double TTxsj, int ccSaT);
    void GsbRuFTE(int rFAfyOodqclLWbr, bool LISZiuIZvWSlkYN, string AaMrN, string zfoUIkcLENCQf, string GYhwRoaRfxneABC);
protected:
    int qfUtNDFIZBhkk;
    string stwLBRu;
    int wQcbh;
    double XQeZRPSb;

    string MbgFlOFVdfFt(int FxIOf, double ZoVzk);
    string RkkzAzIIhdru(string wJHCzDTznkAQuEmQ, int EctsmGTEkh, bool ZdpScQjhnxmyFt, int YhQqVTnf, double jqpTbceeJp);
    double lHkAtveyQVTu(int kTlUIaEXGgLQ);
    bool gyLlIkUH();
    bool ElpUfhiAtLePA(double KJKzHVSnnqyDHSpf);
private:
    int hufzGXmfCDmgeoE;
    string olsQPFqUxpa;

    double ecdGcXQqhqojHcXy();
    bool rPfLo(int uRSqFzcMSBcpBd, bool mfcmPWnv, double xHYPGvuJOQ, bool ZkuiadxtG);
    string wQFmePEpcdhschvR(double BchFDBSLwiHaIn);
    string pgbxZsvu(double WkeRxBokROUFR, string myRiQdAcSFobFf, double HWgVF, double poMcvNm);
    double tCKXb(bool wwluxuyvTdAGv);
    string CyIlTQ(bool htkOJjLcg, bool NeFKx, string oUNegZ);
};

bool oWLFmzHFncA::LgvPR(string uKsRaiCAKHBWQ)
{
    int QvYJhmH = -2133885800;
    int vmzfDiODMmLNHE = -1417307109;
    int loYmMQ = 1688635664;
    bool ziVHAmmUZQZoSgzT = false;
    bool oNFWPBCJDHe = true;
    double dbtNr = 671695.4994505243;
    string LrzSlIvXxYPoFAM = string("yoTghNxXKQDHNlEQpNRmYfOBeAldiqyEmdEEqgXHUEcrAjfuouzMPnmsPmcgMUbfVlugSvqwPuLkIHjdvCivpyOjFuCvwVMPvJvuQokKyRhTbyvGfcPGHJfVyKInGRUxDO");
    int GqntAL = 1763400839;
    bool GUYUgPIiCBvP = false;

    for (int eQHBrg = 1831713528; eQHBrg > 0; eQHBrg--) {
        continue;
    }

    for (int xCaDTpCMIWfokdm = 659822561; xCaDTpCMIWfokdm > 0; xCaDTpCMIWfokdm--) {
        QvYJhmH += vmzfDiODMmLNHE;
        vmzfDiODMmLNHE -= loYmMQ;
        vmzfDiODMmLNHE *= loYmMQ;
    }

    for (int CLHijrvEoOWnVI = 457694521; CLHijrvEoOWnVI > 0; CLHijrvEoOWnVI--) {
        continue;
    }

    if (GqntAL == 1688635664) {
        for (int FSkwPJSJHKUq = 1398872852; FSkwPJSJHKUq > 0; FSkwPJSJHKUq--) {
            LrzSlIvXxYPoFAM += uKsRaiCAKHBWQ;
            dbtNr *= dbtNr;
            GUYUgPIiCBvP = ! oNFWPBCJDHe;
            GqntAL *= GqntAL;
        }
    }

    return GUYUgPIiCBvP;
}

double oWLFmzHFncA::VYAjkcj(int jghDCLeEjo, int ikXfOVeIxTRWVf)
{
    string hhEjLrk = string("DFWJrMsAjTfqdiyoUzivQrgNyAbvbgvLdNcVmyjwSJxPjxVBbjbfjRWbCpJeAtCBnxNkzQwouzPhkObLScSVNqtBPpHCUONvISyhZDaHyTgKWYjQmNeWYHHfsABOqgeydVqOeEkMSUQFfCqOjKFISzNFZqtTHQZxrDKXTDBIrqJvdOBHDtAJEPLiKIbYevoebZXirIOxePpgUyzHHscUQKWCnBSwCxufmenJKfBrcIRqeJUZKXKI");
    double sSkTBLex = 775058.1338611816;
    int FnLCaHya = 1558704868;
    bool jSynpzPwbKDTDVo = false;
    int EkDKBAIHaQbRfgPD = -1338522996;
    string fSnyLmyMRkOSAmNb = string("aHpjVYmSrBZyVbbnTeVyNGdmqtHvGeukBouulKuXNHoCFxCyVpYbNBQkzZGkZtPWevmRUlacURVPhlvcOSTrPAGrhcuddNOZREfeTbEElteTYWhZnRBhKtkStwnALKJpgGpxWOQprPLwHCEt");
    double amNCZdEAPirMPoGn = 582206.9350105674;

    for (int DxqzYxaIqddVmjo = 1169504309; DxqzYxaIqddVmjo > 0; DxqzYxaIqddVmjo--) {
        sSkTBLex = amNCZdEAPirMPoGn;
    }

    if (hhEjLrk != string("DFWJrMsAjTfqdiyoUzivQrgNyAbvbgvLdNcVmyjwSJxPjxVBbjbfjRWbCpJeAtCBnxNkzQwouzPhkObLScSVNqtBPpHCUONvISyhZDaHyTgKWYjQmNeWYHHfsABOqgeydVqOeEkMSUQFfCqOjKFISzNFZqtTHQZxrDKXTDBIrqJvdOBHDtAJEPLiKIbYevoebZXirIOxePpgUyzHHscUQKWCnBSwCxufmenJKfBrcIRqeJUZKXKI")) {
        for (int usSNnAmESXtzvY = 604094064; usSNnAmESXtzvY > 0; usSNnAmESXtzvY--) {
            jghDCLeEjo -= jghDCLeEjo;
            FnLCaHya *= EkDKBAIHaQbRfgPD;
        }
    }

    for (int wVaWrOK = 783181711; wVaWrOK > 0; wVaWrOK--) {
        continue;
    }

    for (int WvwAvTjQfk = 1757513052; WvwAvTjQfk > 0; WvwAvTjQfk--) {
        jghDCLeEjo *= FnLCaHya;
        ikXfOVeIxTRWVf /= jghDCLeEjo;
    }

    return amNCZdEAPirMPoGn;
}

string oWLFmzHFncA::JMEngmQ(bool tiXUHuGAFciqe, bool ryBVEtgztpCOCwfD)
{
    string ZnzAKKwa = string("GyRMCwgNKZmqWujgpHmpuYrlJjsxXuGHayhGtPIbnmyCsCxVhJLUcsEoEmBWxiVoPFDUPHByv");
    double WhdZSYKccK = -254747.02837572113;
    string OOBoRet = string("NFcYOKMMXGRNpRWKrrvZmgUoOjGmmwMwHSyRrqQwmIXClbjFrUBHhoCulPFbrrgLMwWZpUVcGmmzOOBWhqmCtQJMNGZniTECQyGidJbVzCZhKObsnKtxufeZZwYaYiPwIWiFBLmnDoTswIPazjjmdxNpaksJneoPgbFoOJVLnzakkGRkNKPUuxVkslYPWdIDy");
    bool LKLhVtckZyuldaxF = true;
    string BFrNfjvzbRBUck = string("hpbfYDiWhDNDoRzRzHgtzyXMHRSpNNZgrVrsdHxppevZnYNXgzwhYfSAJtuMDWzXRYeLNzypaLWYnEFvlafBSpdMQmMkcZQZKqHsHHPmgopzGVJVOwE");

    if (tiXUHuGAFciqe == true) {
        for (int ZotkNa = 151113500; ZotkNa > 0; ZotkNa--) {
            continue;
        }
    }

    return BFrNfjvzbRBUck;
}

string oWLFmzHFncA::pkQRmUTGTl(int ruDpwTeiWSMclE, double TTxsj, int ccSaT)
{
    int guAaXANrXxQ = 2091877040;
    double HeZgpJYBKblFc = 1000881.9545647326;
    bool KLRWsKNeaOeU = false;
    double MxIkbvU = 397415.27532955294;
    int rQFWBKTQDnTVqwSj = -72636645;
    bool nVgzfWNElMALkGM = true;
    string MydePRzjCa = string("kJrCiZqXHcupsXAEnxWaXJpybqPBeSErppKwmbTRdgJPmycZLBXELNpIuFdgRLpUpZLqPzpMso");
    int sTsDysK = -787550878;
    string DyEwE = string("ihzcVFZybRhQMRjLcGpoVjNtGQviqDnjfRQIyRCNkjWumejzAwojEJDQHaAfKMxDCgcZWgrdUdwrQEfFHkkIMjxTEXuccuorhwHiFSnmgNfnKImN");
    int sYqwgecCeVNqjK = 1792899094;

    if (KLRWsKNeaOeU != false) {
        for (int ZuFTQ = 712074308; ZuFTQ > 0; ZuFTQ--) {
            continue;
        }
    }

    for (int CwJTKi = 1918289991; CwJTKi > 0; CwJTKi--) {
        MxIkbvU *= TTxsj;
        guAaXANrXxQ += ruDpwTeiWSMclE;
        sYqwgecCeVNqjK = ccSaT;
    }

    if (ruDpwTeiWSMclE >= -72636645) {
        for (int rxLGvcFpCdoyS = 1268408531; rxLGvcFpCdoyS > 0; rxLGvcFpCdoyS--) {
            TTxsj *= HeZgpJYBKblFc;
        }
    }

    return DyEwE;
}

void oWLFmzHFncA::GsbRuFTE(int rFAfyOodqclLWbr, bool LISZiuIZvWSlkYN, string AaMrN, string zfoUIkcLENCQf, string GYhwRoaRfxneABC)
{
    double vhFlxYIbfxwi = -856804.7955202358;
    double hxErYLBFz = -724777.7457444861;
    double BMKqyploTdTwXkv = -890799.7507359665;
    int mrvebzfy = 68847962;
    bool xsoTekH = true;
    string comYlBVnNsWORlMx = string("ehmknqOafhsSBExzIipNqOjSLSOpNbvprhrJYUflgrTucwZxHVwpGrMkCAMfpdhtIdpdmpnUYHgjExUzpxJrbQAjmeHPgAcgYNbkUIgViMjtzHSKYiivaMclXajhSwMngfIEI");
    int jQJjcC = 423858016;
    string AotTxnCmQVDQ = string("WfUKIVxuyOsqlKhzeDdSGeimhceNEUlXRkwLEleqUEDukSdocXrktRvgwLTVKxEtAINVOMgWEGOIyxfIgaDsIKUvhqZuyOtZoYjZnvntuiTzwYGzDBonyeCZNgyczYWHEVhDBRfTlVigWvVETXVcjfqOGmADZrvhWzGgksFdUZJxemkGQCiLgaNnuaeVFkLFEemZBVfGYmnWQHjsKfVqahSBTwJMGTZqPAQFmjHrxbaxdxjBeGoQZpkQ");
    int KEBSXxYNBi = -1026976061;
    bool VbelQVPBmBLJ = false;

    for (int bmsjvspHHOOoTPjf = 471493578; bmsjvspHHOOoTPjf > 0; bmsjvspHHOOoTPjf--) {
        LISZiuIZvWSlkYN = LISZiuIZvWSlkYN;
        hxErYLBFz = vhFlxYIbfxwi;
    }

    for (int ZnVFyGN = 1282010057; ZnVFyGN > 0; ZnVFyGN--) {
        continue;
    }

    for (int UIpJqDS = 1164377050; UIpJqDS > 0; UIpJqDS--) {
        continue;
    }

    for (int pfoxgpleFixL = 726392755; pfoxgpleFixL > 0; pfoxgpleFixL--) {
        continue;
    }

    for (int Qbwpegn = 1430184206; Qbwpegn > 0; Qbwpegn--) {
        BMKqyploTdTwXkv = vhFlxYIbfxwi;
    }
}

string oWLFmzHFncA::MbgFlOFVdfFt(int FxIOf, double ZoVzk)
{
    string vTvkts = string("VczriLWYlIfsEYqtwMBzEzyaZiKFwnmxbhjNAPJTFseGOhfXCNfrVlkqYayYamrXilHHegRNoYahpyGRJOtDjbqEvjBwtNpvaaeJoxLLNexNWNtFMTnszYjQbRSMvYKTOOAbCmwTZlGvNmudfgIXHkmBNqbGoHNQEyPZpCNNMuSarqNnxWJdVeiQgJvUYvgZIiChAQmlkUQJGcPEliejnWCmkBCZ");
    int MHYou = -564046011;
    bool ZHdXgVNtOYTjK = false;
    double PJtFtGb = -113278.11173652054;

    if (ZHdXgVNtOYTjK != false) {
        for (int QvdmTLgiDjyJGcxI = 534392719; QvdmTLgiDjyJGcxI > 0; QvdmTLgiDjyJGcxI--) {
            PJtFtGb = ZoVzk;
            PJtFtGb += PJtFtGb;
            FxIOf -= MHYou;
            FxIOf /= MHYou;
            MHYou *= FxIOf;
        }
    }

    if (FxIOf > -1496743206) {
        for (int gRErUWF = 1308377259; gRErUWF > 0; gRErUWF--) {
            continue;
        }
    }

    return vTvkts;
}

string oWLFmzHFncA::RkkzAzIIhdru(string wJHCzDTznkAQuEmQ, int EctsmGTEkh, bool ZdpScQjhnxmyFt, int YhQqVTnf, double jqpTbceeJp)
{
    double WTuaZIFyKof = -660255.2724646487;
    int BHrYVvg = -125281392;
    int OOwtxRH = 2114941128;
    bool SoEzSlAxSW = true;
    bool QqEqhzTAMDBIPZSN = false;
    int fMlpkzZzz = 2107188212;
    int EXAFolgJstfzcd = 2079217349;
    bool VkozuWpB = true;
    string tHZNBifidPLt = string("epAiUHaBLeQufievtNmnYsiUfHJLUOjMCKTDqnyFGQqGuhaIKPqQKVTmmykxqUcHvpAnpzFhfBvRCgixzcZLxzdkyIfluefeRLjZjMcoacYkLpVkIlQMlohCJPctQHCULzqHJAgImQxlmgITZhVmEvbWwXQRkgOMwOuAmQYUndasfmShouuxhrbHA");

    if (YhQqVTnf <= -125281392) {
        for (int VLMycQ = 1775449085; VLMycQ > 0; VLMycQ--) {
            continue;
        }
    }

    if (YhQqVTnf == -125281392) {
        for (int GTBJHzgD = 507812905; GTBJHzgD > 0; GTBJHzgD--) {
            fMlpkzZzz /= fMlpkzZzz;
            SoEzSlAxSW = SoEzSlAxSW;
        }
    }

    for (int DdYlmNsTj = 49982024; DdYlmNsTj > 0; DdYlmNsTj--) {
        EctsmGTEkh = EctsmGTEkh;
        QqEqhzTAMDBIPZSN = ! QqEqhzTAMDBIPZSN;
    }

    for (int JiqyLQZuiup = 2032554355; JiqyLQZuiup > 0; JiqyLQZuiup--) {
        OOwtxRH = EctsmGTEkh;
    }

    for (int tOXqCHyEtcnpsVZK = 1359755433; tOXqCHyEtcnpsVZK > 0; tOXqCHyEtcnpsVZK--) {
        SoEzSlAxSW = VkozuWpB;
        tHZNBifidPLt += tHZNBifidPLt;
        SoEzSlAxSW = SoEzSlAxSW;
        YhQqVTnf /= EctsmGTEkh;
        EctsmGTEkh /= EctsmGTEkh;
    }

    for (int mSRCuGavbSPetyJC = 317366286; mSRCuGavbSPetyJC > 0; mSRCuGavbSPetyJC--) {
        EctsmGTEkh += EctsmGTEkh;
        EXAFolgJstfzcd /= YhQqVTnf;
    }

    return tHZNBifidPLt;
}

double oWLFmzHFncA::lHkAtveyQVTu(int kTlUIaEXGgLQ)
{
    int buDOqFkwJHzeWYrv = 1542214332;
    string QMbrfpskgkjpDnc = string("mQXWvarkDyPhOWoZRoNvsjscWLoJcxIOvdXkVXGVxHvzvQboVmSyGdoAyFaqQNBuGhIUhguJDnIDdYTalmISDc");
    double wthso = -985010.9524318515;
    double utxUuoPgzopTAYp = 370587.9114964377;
    int AGDSXFbhEnOGGR = -212306217;
    bool RjJMjZUqoaLvp = true;

    for (int vmSEUpUAj = 589267881; vmSEUpUAj > 0; vmSEUpUAj--) {
        buDOqFkwJHzeWYrv += kTlUIaEXGgLQ;
        utxUuoPgzopTAYp += utxUuoPgzopTAYp;
        buDOqFkwJHzeWYrv += AGDSXFbhEnOGGR;
    }

    if (utxUuoPgzopTAYp < 370587.9114964377) {
        for (int EVFHYUw = 592399808; EVFHYUw > 0; EVFHYUw--) {
            buDOqFkwJHzeWYrv = kTlUIaEXGgLQ;
        }
    }

    return utxUuoPgzopTAYp;
}

bool oWLFmzHFncA::gyLlIkUH()
{
    bool quQjkco = true;
    double yVkABsYZ = 158868.72645579383;
    double ugLuQaWr = -944110.1153370434;
    string OGXvSKLOKLorauz = string("FpLiSAzJRgWvrUMJOgEiJemCEvMCecOOExJYVVmTmEIDqaoSwVexjrznaMlBPmAPPVFRTWIZLaCdqTPqKUMUMoVNXUVQcFSssYCxtkrUOSDDKnLpASoqrFcoPochRtF");
    int avJyksanaE = -1878588274;
    bool CjZfGwzZxh = true;
    string flmqoJFQnHwKkk = string("XFqyyewQqIVlhBSwITCuWKByOeaSpVwaajrtvbhkmGeMfaMFxzmzDzhmzgqKOhcYrLwBiCvtMauFTDUhiByznEFPYj");

    if (CjZfGwzZxh != true) {
        for (int oHqPj = 578134983; oHqPj > 0; oHqPj--) {
            ugLuQaWr *= ugLuQaWr;
        }
    }

    for (int JXzNYDCTK = 1931945182; JXzNYDCTK > 0; JXzNYDCTK--) {
        continue;
    }

    for (int QrXOW = 70986838; QrXOW > 0; QrXOW--) {
        yVkABsYZ /= yVkABsYZ;
        yVkABsYZ = yVkABsYZ;
        flmqoJFQnHwKkk = OGXvSKLOKLorauz;
    }

    return CjZfGwzZxh;
}

bool oWLFmzHFncA::ElpUfhiAtLePA(double KJKzHVSnnqyDHSpf)
{
    bool bXAIIkiGJyAYU = true;
    bool yAeQgTccniMtJ = false;

    if (KJKzHVSnnqyDHSpf <= -157055.70049039062) {
        for (int vNayONYfRBoOr = 744022011; vNayONYfRBoOr > 0; vNayONYfRBoOr--) {
            KJKzHVSnnqyDHSpf -= KJKzHVSnnqyDHSpf;
            KJKzHVSnnqyDHSpf -= KJKzHVSnnqyDHSpf;
        }
    }

    for (int fjrdOiCSCQl = 566407919; fjrdOiCSCQl > 0; fjrdOiCSCQl--) {
        bXAIIkiGJyAYU = yAeQgTccniMtJ;
    }

    if (bXAIIkiGJyAYU != true) {
        for (int nbweZhKLDTn = 1611296528; nbweZhKLDTn > 0; nbweZhKLDTn--) {
            continue;
        }
    }

    if (yAeQgTccniMtJ != false) {
        for (int ascnd = 1448841013; ascnd > 0; ascnd--) {
            bXAIIkiGJyAYU = ! yAeQgTccniMtJ;
            KJKzHVSnnqyDHSpf *= KJKzHVSnnqyDHSpf;
            yAeQgTccniMtJ = ! yAeQgTccniMtJ;
            bXAIIkiGJyAYU = ! bXAIIkiGJyAYU;
            yAeQgTccniMtJ = yAeQgTccniMtJ;
        }
    }

    for (int urEzGfJmHzv = 1029061156; urEzGfJmHzv > 0; urEzGfJmHzv--) {
        KJKzHVSnnqyDHSpf *= KJKzHVSnnqyDHSpf;
        bXAIIkiGJyAYU = bXAIIkiGJyAYU;
    }

    return yAeQgTccniMtJ;
}

double oWLFmzHFncA::ecdGcXQqhqojHcXy()
{
    bool grSVYSXhnXwJh = true;

    if (grSVYSXhnXwJh == true) {
        for (int ahlQKyaUgK = 1902878798; ahlQKyaUgK > 0; ahlQKyaUgK--) {
            grSVYSXhnXwJh = ! grSVYSXhnXwJh;
            grSVYSXhnXwJh = ! grSVYSXhnXwJh;
        }
    }

    if (grSVYSXhnXwJh != true) {
        for (int famommzATP = 877927241; famommzATP > 0; famommzATP--) {
            grSVYSXhnXwJh = ! grSVYSXhnXwJh;
            grSVYSXhnXwJh = ! grSVYSXhnXwJh;
            grSVYSXhnXwJh = grSVYSXhnXwJh;
            grSVYSXhnXwJh = ! grSVYSXhnXwJh;
            grSVYSXhnXwJh = ! grSVYSXhnXwJh;
        }
    }

    return -610530.2738610967;
}

bool oWLFmzHFncA::rPfLo(int uRSqFzcMSBcpBd, bool mfcmPWnv, double xHYPGvuJOQ, bool ZkuiadxtG)
{
    string UQHWCph = string("rYbgGeeshESsrWaoeYwQkZuCbycQKbgbI");
    double kCFFZuvVkltBSW = 623897.060409949;

    for (int KNkTwgMqH = 28387231; KNkTwgMqH > 0; KNkTwgMqH--) {
        continue;
    }

    for (int PrhtdJtidzfycoph = 368478920; PrhtdJtidzfycoph > 0; PrhtdJtidzfycoph--) {
        UQHWCph += UQHWCph;
        uRSqFzcMSBcpBd += uRSqFzcMSBcpBd;
    }

    for (int tZbsKhK = 10777614; tZbsKhK > 0; tZbsKhK--) {
        continue;
    }

    for (int EVefHiSzOah = 1722083106; EVefHiSzOah > 0; EVefHiSzOah--) {
        kCFFZuvVkltBSW += xHYPGvuJOQ;
        ZkuiadxtG = ! ZkuiadxtG;
        ZkuiadxtG = ZkuiadxtG;
    }

    for (int bMpbbGjfoUWjeFDF = 1545112802; bMpbbGjfoUWjeFDF > 0; bMpbbGjfoUWjeFDF--) {
        continue;
    }

    for (int sBBObuLJLUeu = 1494578265; sBBObuLJLUeu > 0; sBBObuLJLUeu--) {
        ZkuiadxtG = ! ZkuiadxtG;
        xHYPGvuJOQ -= xHYPGvuJOQ;
        ZkuiadxtG = ZkuiadxtG;
    }

    return ZkuiadxtG;
}

string oWLFmzHFncA::wQFmePEpcdhschvR(double BchFDBSLwiHaIn)
{
    double jEWjZPtBTCVpOy = -610644.3830448856;
    string saIyaLlaLqc = string("vdoikcXpPhswUTNFpYmeWMxWTnRbVYUcjUVGjoibpWRdgkkORHLXzVMsxTYOPHnirbqoXGFyXDMOAmZJgpQvIsfvNGHgHZTQKDKfYxGBnkDImBstXiNHaOyopaDCFDPHLYffMoRaFQSfvuCvfIl");
    int jNRyBAuViy = -1996325485;
    int PiiezpV = 32540030;
    double jlmNeAWKgGdcIJy = 320317.4795551833;
    double wChaWeJL = 667025.1711552993;

    return saIyaLlaLqc;
}

string oWLFmzHFncA::pgbxZsvu(double WkeRxBokROUFR, string myRiQdAcSFobFf, double HWgVF, double poMcvNm)
{
    bool HbVoXIyXu = false;
    bool drAdDggWBaP = false;
    string hCnyL = string("JiVLRRJBnbttlVfbSyDHTUNqgTJQTlBKxfWuGbAWprnAVdggooIPhBJwlpwzjhAulpinJkiMuXPwdIVTtamBxTKROPXvxhBYufpapXEtfuveizYuqdrulrimjQYDhrEQTghcAqHPrYtjipOQEeMVBuLqXpHVIIRuPRxziOXZpsOSdtMPnqtfTsTHzSSYbEsSfdjJVKyzZkSBcIUcafOnHbvnOWQKkwdMtaMy");
    string NuvZKC = string("nosETtuXjaFNrJSPCIqSzQaKtEaqSPDWwkUSGqgEbozgZcOHOkqnSdkYAOlPMyaNWDHysaQCFZqwEdFLagUEXkzrHfsyNPMlIppdGAZUloKNhGkfUGnNjYqgAzMvYoWhNSWmOcbBMRKEcIWLHDnPucbOamrvyMuTLRBRTijTfUAyKQJbyRKElKtgKmyurOumkIXOKiJcsFTaPQNtqbPQAwsMBLNolqmwimoZuXpqGiyWyzmEU");
    bool YvFCpnGkkyxzLECN = false;

    for (int obsJfgb = 1744124352; obsJfgb > 0; obsJfgb--) {
        continue;
    }

    return NuvZKC;
}

double oWLFmzHFncA::tCKXb(bool wwluxuyvTdAGv)
{
    string GVYIsLDHDpkRM = string("qGqLDNcA");
    double KPVntBhk = -606199.0113551539;
    string gEPsAUhtXEiJP = string("zSzUgjdQyvRvFEsZhIWwpUFuUcPZzhTwrrmxuiUGVMgNJrksvNmemInHuvhUpCmreOabRNgOYqhvOFqaxIKtBAyqIoRPBoIYTLbPjBfwiUayojIAbdHdEmwM");
    double PFjDdJxlFL = -18325.056355111738;
    bool DEMUaSfMdAjExjK = true;

    if (GVYIsLDHDpkRM != string("zSzUgjdQyvRvFEsZhIWwpUFuUcPZzhTwrrmxuiUGVMgNJrksvNmemInHuvhUpCmreOabRNgOYqhvOFqaxIKtBAyqIoRPBoIYTLbPjBfwiUayojIAbdHdEmwM")) {
        for (int OQnzWxuA = 250983971; OQnzWxuA > 0; OQnzWxuA--) {
            KPVntBhk -= PFjDdJxlFL;
            KPVntBhk -= PFjDdJxlFL;
        }
    }

    if (KPVntBhk != -18325.056355111738) {
        for (int hyBsdzBzT = 15566155; hyBsdzBzT > 0; hyBsdzBzT--) {
            gEPsAUhtXEiJP += GVYIsLDHDpkRM;
            GVYIsLDHDpkRM = gEPsAUhtXEiJP;
        }
    }

    for (int uxArQkDjjYQ = 896403913; uxArQkDjjYQ > 0; uxArQkDjjYQ--) {
        continue;
    }

    for (int ifEfjdbpgvLui = 1323390815; ifEfjdbpgvLui > 0; ifEfjdbpgvLui--) {
        gEPsAUhtXEiJP = gEPsAUhtXEiJP;
    }

    return PFjDdJxlFL;
}

string oWLFmzHFncA::CyIlTQ(bool htkOJjLcg, bool NeFKx, string oUNegZ)
{
    double GvOFgTTziaspci = 421651.1826026493;
    bool ZnYwtdwNL = true;
    bool zBLhUODwzIkHI = true;
    int UZQacBPCFln = -1218157133;
    int cfuhVlYYEenAS = 774911669;
    string Ixufa = string("pQIqPLQmlgrBJdHKedzHmdjdbgXrfmwjNyeackUseXErDZBtpNSWwsepOdOyAwOiyaqAOQivJfQFkjAmUWuBZdJhnqPhOtVbJKvumTQWqEApAPBaEhyVeOJAnfQwJxaTHBsvDcbkuffkPTIDLDCRnGfePZKwAiYLSEdTJQJGVlkmhXyWJkgVRIzohtYksHOashztXjcgLK");
    string TiFAE = string("NrOStWjgILWeDqofnymAdpRMmNUauvdnAabwsPZEpwtymytEahoaQNBANOWKUzaasMtEfYIFopVBgRfdyIFFxCIQhuCMGBXxuKaOQZgkCfBlvAxZieXgkEKSOMdXxcdotXNvttecrNiPgZeSmgXsWzfYFrIMyqrmpzxqoUaczBMpW");
    int GQuqqZwcVYOUvwk = 693841532;
    int LvUUXQKeZvcLq = -998224557;

    for (int aAgyBfjxYB = 2651322; aAgyBfjxYB > 0; aAgyBfjxYB--) {
        UZQacBPCFln *= UZQacBPCFln;
    }

    if (NeFKx != true) {
        for (int WvoSDYGwGVr = 196808507; WvoSDYGwGVr > 0; WvoSDYGwGVr--) {
            TiFAE += Ixufa;
            htkOJjLcg = ZnYwtdwNL;
        }
    }

    for (int wGAOFTn = 445078638; wGAOFTn > 0; wGAOFTn--) {
        Ixufa = TiFAE;
    }

    return TiFAE;
}

oWLFmzHFncA::oWLFmzHFncA()
{
    this->LgvPR(string("yKoAWUqdofuEiMTewnLIzJPCmRqANkEJqXKEYwWbbCpFkDyAgpZdVzWDlFeAZWDPxJERWUoNjlGMMXkufDZnByzEPlMyJqDEyPdyXBSEBpkULSyEfLtBKrUoQSHDWVZDWocUtlsdAaUDfmSDaClMAfsbIdoVTwvdeQfVcIgeaBudNUKBLGnAWgYmQLEmiwmiISmNzVXwiFxyIhazxxXJVeDtVgqeemnEDrhuMYWzsKkNPMFphllGXSkfE"));
    this->VYAjkcj(-1524020359, 1016993316);
    this->JMEngmQ(false, true);
    this->pkQRmUTGTl(-22105080, -874022.0045346774, 677113820);
    this->GsbRuFTE(-363203740, false, string("oCQIojqxsxiydOOvabHDjvtUZpmaIJYqPzDDfUIMOsziPwwvhZJdKtBOittoChBeijjnArbpevtmcVkXHFPBDDlBmnnpezsBOpHUJiFNAafCggQjllThVFtiBxWpFVclWcdHDMfqctMQUERypVvZBtIUHJeTLgtmgzUKrGXPGFLtXkfAYFnvjyMsXkgxemcbnKFhjONwNEJxWtGKaDG"), string("CGcxVcQPOdflwoEzDdkaIIPhNyzrwRWzHSnSHCtsKJkbrfdtrHYjsJTitYqKWTZnbMrSmIePXlkTeEpzuGHlriwWBpYDmLfnNEarQTUOGfWfdjVuhESLDzfNwDZLlLebhpDPX"), string("LPVtTxXfDNEehdOIPrUBuNDksJpdJmhwWhLICNVzbzGockPLtcevEZDcmoujAzZJdmHVvmWzmAsMNdGGvMHVlmoyCWytIHuSgrqRrpCmMlWacCzXxeAMjxkOFxvWbJhGXdrSyJctOfsxTwqVqtdNrBdAnmJWYnkvOxHUvRqOtHpSlumCMOVuXXNvPyfxtKRfoGvBoKiUebIgtUvZSXsirkFgwlGQsaQqoXFaapOnIhoyAUEPPpHPLVdHn"));
    this->MbgFlOFVdfFt(-1496743206, -1040636.4288597608);
    this->RkkzAzIIhdru(string("nxCjsHbVNcsAohNaWkTTXqEhdmAemiusdcLMZNAfXurASYBfcrFjWLtsxpacIwjrXMmHyCEWDADqdWyCwfEvlYAFzQixmMzeLhsUKvnAOoZAVCEhVpcBoAhpJfXhYgzbFbEvZJXovWGUlBAiGAVRIoYVimJEivjLEVFXhiulfYqDbJfpaVcUWQaxBKnZquShCztKhvSdapUlOhq"), -245118027, false, 1646496146, 46333.01989399395);
    this->lHkAtveyQVTu(1523368511);
    this->gyLlIkUH();
    this->ElpUfhiAtLePA(-157055.70049039062);
    this->ecdGcXQqhqojHcXy();
    this->rPfLo(-214833173, false, -247948.4293466937, true);
    this->wQFmePEpcdhschvR(-677189.798810524);
    this->pgbxZsvu(-441137.49445828795, string("ULzmArsHNutAuIpoJRBYffNibFwQEJtnGowNGMEABxfvmwVUEcQCPNRuIEwdpRCXJazWTmcQPGfgwmXVVRnZyYyt"), -895748.5126633709, -603564.0002258122);
    this->tCKXb(true);
    this->CyIlTQ(false, true, string("OsTaarrxkGnHnGZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TzelPJgxg
{
public:
    int YSqGRX;
    string trvZvPzBOK;

    TzelPJgxg();
protected:
    string TnmkIk;
    int zRrfbGjyCFa;

    double TPERaCtsMuBLBsG(double gpteHCkVsPdSFCU, bool dvBlv, bool biIpgGG, int CPrnMJes, bool GhEORrXNncvSFE);
private:
    string KOiPXxXSkJ;

    string kOvEvmg(bool fDboSZ);
    int nDKdQwNwghplnVR(bool BkmCbrWsEeSyrL, bool efLzbqDXS);
    double EgMSl(bool GdNsBmWODPbFSmpJ, string aEdSZ);
    string nEkPUvpbzJGr(string NdKXMOhae, double EVlNCrK, bool ugADSnKPwRCqmZjk, string GIjznxfsVlohUPA);
    void rDcjLzJDxqhTit(bool KRzpbBibtK);
};

double TzelPJgxg::TPERaCtsMuBLBsG(double gpteHCkVsPdSFCU, bool dvBlv, bool biIpgGG, int CPrnMJes, bool GhEORrXNncvSFE)
{
    double ZZZjDaj = 699947.4351452452;
    double yPTHeWtHbmbiwlBU = -1036090.1541300793;
    bool AzjLJBnENl = false;
    double izushCHgOVGOSzr = -1026934.2398164368;
    double rmEaDL = 112360.59731251693;
    bool HkvlWnrxdgmyuSp = false;
    int VYSendZLLJss = -1533663448;
    bool JatrMVlltaaqX = false;
    double oAKCCKJJsxRPWRGk = -669522.5639413773;

    for (int PHVeZm = 702988006; PHVeZm > 0; PHVeZm--) {
        JatrMVlltaaqX = ! GhEORrXNncvSFE;
    }

    for (int HhAaJkILzufNrhIC = 1376021599; HhAaJkILzufNrhIC > 0; HhAaJkILzufNrhIC--) {
        GhEORrXNncvSFE = GhEORrXNncvSFE;
        yPTHeWtHbmbiwlBU = oAKCCKJJsxRPWRGk;
        oAKCCKJJsxRPWRGk /= ZZZjDaj;
    }

    return oAKCCKJJsxRPWRGk;
}

string TzelPJgxg::kOvEvmg(bool fDboSZ)
{
    int YCxdyPuGXsS = -925722591;
    string aZvdqEsEchw = string("VzrESUOCuHatfkBiGTMjoITjpST");
    int IfXMQRpKBalAC = -744407290;
    int eAauWP = 1671147357;
    string ZhiuThwHiX = string("YfuaCfwceLMqfZYQcwQsCdoRGanYKLWFpeVuKajJDooyvTmEllDbbCUKWJSJDsiKsDQhszxfPvdorZlSOglZjCkRNDZrrMMJzISJSIuzYfrNtuvPxrokgiytvDMCVYxvJdJBnByERspYweZtsGi");
    string LDqYembPfWD = string("dqoFChcLyOLqqmjRKSMiJYEQejeMpDddZFKnHYiqNZORQvfYBcW");
    double dZWEUEKvQSO = -80006.25694413726;

    if (YCxdyPuGXsS < -744407290) {
        for (int qxKOQCdtykNqqoga = 1391309050; qxKOQCdtykNqqoga > 0; qxKOQCdtykNqqoga--) {
            aZvdqEsEchw += aZvdqEsEchw;
            eAauWP += eAauWP;
            fDboSZ = ! fDboSZ;
        }
    }

    for (int FoqGGPgWh = 836335988; FoqGGPgWh > 0; FoqGGPgWh--) {
        eAauWP += YCxdyPuGXsS;
        IfXMQRpKBalAC *= IfXMQRpKBalAC;
        LDqYembPfWD = LDqYembPfWD;
        LDqYembPfWD += aZvdqEsEchw;
    }

    for (int nlodACXiOZA = 1373718190; nlodACXiOZA > 0; nlodACXiOZA--) {
        continue;
    }

    for (int NjWQGdpqnTAJIFS = 1459883864; NjWQGdpqnTAJIFS > 0; NjWQGdpqnTAJIFS--) {
        LDqYembPfWD = aZvdqEsEchw;
    }

    if (aZvdqEsEchw != string("dqoFChcLyOLqqmjRKSMiJYEQejeMpDddZFKnHYiqNZORQvfYBcW")) {
        for (int KhTeVbFsQUWPLJmm = 1945266891; KhTeVbFsQUWPLJmm > 0; KhTeVbFsQUWPLJmm--) {
            YCxdyPuGXsS = IfXMQRpKBalAC;
        }
    }

    for (int EksLOPxkuFMhz = 2012505147; EksLOPxkuFMhz > 0; EksLOPxkuFMhz--) {
        fDboSZ = ! fDboSZ;
    }

    return LDqYembPfWD;
}

int TzelPJgxg::nDKdQwNwghplnVR(bool BkmCbrWsEeSyrL, bool efLzbqDXS)
{
    bool adKvcYXx = true;
    string pioveBGJIzKAXYBK = string("ogUPOywfExhLSbnVRzUtibgVaAyLKcZBvvYQrIGIOTgcFjxKmnzxlVwDTsAFBxeYoalYWDywYxuIlIuiyrytGYSaXYeYpmNOsVMITasdqQXQiFvjmsSqugIZyaSXrbSUetzGFDrYXDYFqyrEN");

    if (efLzbqDXS != true) {
        for (int ayuRJTF = 467279862; ayuRJTF > 0; ayuRJTF--) {
            adKvcYXx = adKvcYXx;
            efLzbqDXS = BkmCbrWsEeSyrL;
            adKvcYXx = ! efLzbqDXS;
            adKvcYXx = BkmCbrWsEeSyrL;
        }
    }

    if (BkmCbrWsEeSyrL == false) {
        for (int kaXAvUxJdiNA = 1742707781; kaXAvUxJdiNA > 0; kaXAvUxJdiNA--) {
            adKvcYXx = efLzbqDXS;
            BkmCbrWsEeSyrL = efLzbqDXS;
            adKvcYXx = ! adKvcYXx;
        }
    }

    for (int EtekkNsM = 618958228; EtekkNsM > 0; EtekkNsM--) {
        efLzbqDXS = ! efLzbqDXS;
        adKvcYXx = BkmCbrWsEeSyrL;
        pioveBGJIzKAXYBK = pioveBGJIzKAXYBK;
        BkmCbrWsEeSyrL = efLzbqDXS;
    }

    return 294377686;
}

double TzelPJgxg::EgMSl(bool GdNsBmWODPbFSmpJ, string aEdSZ)
{
    bool DZHGWM = true;
    double ylNfDOkJBvnbHi = -822610.9782973303;
    int AFOpQZT = 1062043420;
    double waNfwFEg = 651839.6158993355;
    string NRqZxt = string("kKyiKEYddHNjxOABGlrzVFMekgGzqsgOjqeFjhOcRzIKitCeDJJNyhJFpYGeXdwrwceQVyGmYhPhOqFJEPtRtBSwWGkoUKFJhOEwCohHdNYLDARESvipuAsfomqGSwDMCVYDJTbTwRJTOvVMNIgKYDKeBoGqVYaQRZEcuQaUMXlgHozGeHoONAdWxBHWWBuPPSjvXxsRAsHFwiIUweQxHyYzfVJFKIjSebyQNSWgscX");
    string rmXZrn = string("GPIcSgKDPJvkjetXu");
    bool IoJKKDPTlQBUDZzb = true;
    bool AvhnlquXOYidLjM = false;
    double NyESXfYKic = -908305.7300170807;
    string ygWilNI = string("fJQCdZbEEkeYRpcYgmsrCuaAZCwydbWIaJtZeViKGSsAKBXrnXMWIpPkfsxmrAOsIMhzZhQXopZFQLyPVYRdABEuiWVTPSLzSlga");

    for (int InPooWHEM = 2104624945; InPooWHEM > 0; InPooWHEM--) {
        aEdSZ = NRqZxt;
        ylNfDOkJBvnbHi = waNfwFEg;
        NRqZxt = NRqZxt;
    }

    if (aEdSZ == string("kKyiKEYddHNjxOABGlrzVFMekgGzqsgOjqeFjhOcRzIKitCeDJJNyhJFpYGeXdwrwceQVyGmYhPhOqFJEPtRtBSwWGkoUKFJhOEwCohHdNYLDARESvipuAsfomqGSwDMCVYDJTbTwRJTOvVMNIgKYDKeBoGqVYaQRZEcuQaUMXlgHozGeHoONAdWxBHWWBuPPSjvXxsRAsHFwiIUweQxHyYzfVJFKIjSebyQNSWgscX")) {
        for (int YvzpEfENaSQm = 372822055; YvzpEfENaSQm > 0; YvzpEfENaSQm--) {
            AvhnlquXOYidLjM = ! AvhnlquXOYidLjM;
        }
    }

    for (int ojbxILAHZZvMAU = 101087097; ojbxILAHZZvMAU > 0; ojbxILAHZZvMAU--) {
        NRqZxt = NRqZxt;
        waNfwFEg -= ylNfDOkJBvnbHi;
        AvhnlquXOYidLjM = GdNsBmWODPbFSmpJ;
        waNfwFEg /= NyESXfYKic;
    }

    if (IoJKKDPTlQBUDZzb != false) {
        for (int IFmlJk = 374781608; IFmlJk > 0; IFmlJk--) {
            IoJKKDPTlQBUDZzb = ! DZHGWM;
        }
    }

    for (int FDJSbAoih = 404924535; FDJSbAoih > 0; FDJSbAoih--) {
        waNfwFEg *= waNfwFEg;
        NyESXfYKic -= ylNfDOkJBvnbHi;
        ygWilNI += aEdSZ;
    }

    for (int ZhgetSqiEuy = 1631559297; ZhgetSqiEuy > 0; ZhgetSqiEuy--) {
        NyESXfYKic *= waNfwFEg;
    }

    return NyESXfYKic;
}

string TzelPJgxg::nEkPUvpbzJGr(string NdKXMOhae, double EVlNCrK, bool ugADSnKPwRCqmZjk, string GIjznxfsVlohUPA)
{
    string kMGWmVlMApkOv = string("YXrrewztigLpkwVZkLy");
    double xKymq = -276445.8968474789;
    string shSUclzupF = string("rbPXBhVrOnWekNQiqdtMODwGPoFbRMZttrwWEbSVeYCkUYSIZDjhpAiNymxvAYKtJcJjtcqZoPmRKfCGtcArzPIGndBbxlNeIucDToCoTpKVfnCfoJPefFcpMjGMeFojQXRoDSAFoWgTUbRk");
    double FJhIi = -142259.70864886258;
    double dTawZqka = -990035.4557222795;
    double bUGWIYyskiCtFxU = -613937.9939088975;
    double eIiFr = -1040821.2013694317;
    string DOxlGpXhnhyMbQb = string("yWBfmfMoRcWLzsXVfoOVuJLTKKZQRspclfOLtGVicSWPmPdrHTQOiFHnsBdnJVfrydTVBSAYNkxuyloXFdHHPtTwMHAeevSNuwjJvcobzDqxwsuLPpiEUureKiPLbGoOvZmYmvGzjMdSUMKMPiQjwNCWNXoGLwTgFHOGPwjDaMpsOrcBBaogNnZitoAOkxPtheVCCJNffQrKpOvtIcREacRDHBaAANLlIOboRGTivP");
    int iKFXtAIhZVNljakF = -1102717055;
    string hQVzjJpRDhwk = string("LtxulYXmBdENviDlXXXIQVhQdntPxNwSFObMRfMDksbdWEIFlozwVFia");

    for (int KhOHhCSNPMe = 1880139202; KhOHhCSNPMe > 0; KhOHhCSNPMe--) {
        continue;
    }

    for (int NoKrnuFLsxWhUrE = 189336282; NoKrnuFLsxWhUrE > 0; NoKrnuFLsxWhUrE--) {
        shSUclzupF = DOxlGpXhnhyMbQb;
        hQVzjJpRDhwk += NdKXMOhae;
        FJhIi += eIiFr;
    }

    for (int axrpmrUrBqqtvNg = 784990784; axrpmrUrBqqtvNg > 0; axrpmrUrBqqtvNg--) {
        DOxlGpXhnhyMbQb = GIjznxfsVlohUPA;
    }

    for (int CBkoVCeZE = 473452588; CBkoVCeZE > 0; CBkoVCeZE--) {
        dTawZqka += dTawZqka;
        FJhIi *= bUGWIYyskiCtFxU;
    }

    for (int oaehOoWn = 605872892; oaehOoWn > 0; oaehOoWn--) {
        continue;
    }

    for (int rgOtitt = 119940556; rgOtitt > 0; rgOtitt--) {
        EVlNCrK -= eIiFr;
        xKymq /= FJhIi;
    }

    for (int GcciUMqmvy = 1325591483; GcciUMqmvy > 0; GcciUMqmvy--) {
        EVlNCrK -= FJhIi;
        kMGWmVlMApkOv = kMGWmVlMApkOv;
        hQVzjJpRDhwk += NdKXMOhae;
        shSUclzupF = kMGWmVlMApkOv;
        EVlNCrK += FJhIi;
    }

    return hQVzjJpRDhwk;
}

void TzelPJgxg::rDcjLzJDxqhTit(bool KRzpbBibtK)
{
    double oAArMSAvQgpQSq = -12867.006018953123;
    bool vCtlRBoj = false;
    int lJPEHcnMjKmxhbpa = -1470527205;
    double gSPsNAGBZyQCg = 389431.54014807893;
    int kOeZkbKO = 1752101519;

    for (int bnJsKhWITWfccbG = 1890297566; bnJsKhWITWfccbG > 0; bnJsKhWITWfccbG--) {
        kOeZkbKO -= lJPEHcnMjKmxhbpa;
        oAArMSAvQgpQSq = oAArMSAvQgpQSq;
        kOeZkbKO = lJPEHcnMjKmxhbpa;
        vCtlRBoj = vCtlRBoj;
    }

    for (int SnUuSPXhQv = 140928731; SnUuSPXhQv > 0; SnUuSPXhQv--) {
        continue;
    }

    if (oAArMSAvQgpQSq >= 389431.54014807893) {
        for (int BOzywDmN = 1617194867; BOzywDmN > 0; BOzywDmN--) {
            KRzpbBibtK = ! vCtlRBoj;
            lJPEHcnMjKmxhbpa /= lJPEHcnMjKmxhbpa;
        }
    }

    for (int uCNubuHOsNMudzr = 1525897970; uCNubuHOsNMudzr > 0; uCNubuHOsNMudzr--) {
        gSPsNAGBZyQCg *= gSPsNAGBZyQCg;
    }

    if (kOeZkbKO != -1470527205) {
        for (int xxJxkCODiqoq = 2095687076; xxJxkCODiqoq > 0; xxJxkCODiqoq--) {
            continue;
        }
    }

    for (int UhelHybx = 542286531; UhelHybx > 0; UhelHybx--) {
        continue;
    }
}

TzelPJgxg::TzelPJgxg()
{
    this->TPERaCtsMuBLBsG(-973461.487315753, true, true, -1642733497, true);
    this->kOvEvmg(true);
    this->nDKdQwNwghplnVR(false, true);
    this->EgMSl(false, string("xDyXXLsCycKWIwjIYepSKZiiwbfSCEMvNXOhyaoJwGRfvdmJYyVJJmcYBfHEVzbezhDDzdgSFITDTwDIwNvNjWwEOnJAMFUpdngymZgwiBBXQvRWIJCMlINtoGVIMIFGFseGRDcJLItWLUNGPuVCOIAgNJvnPisCYcOEHrpTXsUdKboeQGNIMpeOEllkOYdpbxI"));
    this->nEkPUvpbzJGr(string("oltHdKwzjeyBBAwdoNDZwBwRxoCHXYcXLENAzRDmAgZLWgSghZUnARBmiwnExpGUsgTCSWyQ"), -859314.9675442665, false, string("UNcvmpFazTrfQtKndlWSrWazvTnMhlLtFnhLBNJNyuxIDWvKtXmhYstGmmJZIeoFlANLFAoKC"));
    this->rDcjLzJDxqhTit(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iFSkvYJsJQIC
{
public:
    bool DdGyvuuZjrQoffOj;
    string ziWdAILwaT;

    iFSkvYJsJQIC();
    string yvVuCWiXXpRIBsS(bool jVcXhfJIWijCBq, double UahMMcnXnuEVCyMN);
protected:
    string HqjgDNNueFoQX;
    int OOfAxIUVaKa;
    int IoyHFQLmYVQ;

    bool PDTOZxjglZW(bool zePHu, int olzjFXxnrxE);
    double fvoEOqsIdtTcm(double eBtrAwTrWXHICo, int vSftZa, string iDBeLjjK);
    string AxQHAmXss(bool JhtEmYLEjCFuR, bool GGgKnqviJKLYG, string yYgaL, bool efQLltCA);
    void pQAdrkGld(string FYvgfPtHqotGprc, string bzipYzR);
    double ICgbtEkljVbVDTk(string HqjKicEe, double dQTEaNjc, double KwUsCgezbrkVP);
    bool OHcvBBAJVQ(bool cvcqlu, string ENqritZJnQAbKmjJ, int AEMVVRDJGV, double ISrRgpWoWrc, int WLuXswMbrafn);
    int xuLsOBsBZcESuJs(double oPLYqvy, int eNQLSkiWBz, int QARkxlHUTbT, double sYnXxrW);
private:
    bool VmJNiVXML;
    double jyfxPSeGXU;
    double KRbAE;
    string pildUnn;
    int MOOnCdFHFkuKZ;

    int PDaUnBSrgEIVQqN(bool WYnAZtna, double jHVjNqQGGFJKQOG);
};

string iFSkvYJsJQIC::yvVuCWiXXpRIBsS(bool jVcXhfJIWijCBq, double UahMMcnXnuEVCyMN)
{
    int iPAoY = 150725153;
    double hOoIHD = -237718.88930273615;
    int jMCiIBTrrVrg = -991313606;
    int QAeCeEJ = 1264727048;
    int GzDmZIpFf = -1461175121;
    bool yoIyGSgAfDtka = false;
    double DRafghGucVJZ = 933738.0401054809;
    int IpycBNgvuEChS = -835811283;
    bool wYRloYMkSFHcszvk = true;
    double xFjjhDzXEwBv = -289026.7824330666;

    for (int jtiGjrcCR = 1817836548; jtiGjrcCR > 0; jtiGjrcCR--) {
        DRafghGucVJZ = DRafghGucVJZ;
        IpycBNgvuEChS -= QAeCeEJ;
        yoIyGSgAfDtka = ! yoIyGSgAfDtka;
    }

    return string("bTDzYEdEfwdaDqabbuJHzLNjeaNLzZeVyzCSpHYScvfjOcghLbxULhhQTxIqqfnzDzbisIWBslQQGEHIZQdYZHvBEvMmaFPByMSfyGlVLBVKtiFlTxqtUWVmGxYnSIlwmmnmcYXnWehRHoVgiwfHNdogUaqEtBHUoVTQXXcKjpNvGuz");
}

bool iFSkvYJsJQIC::PDTOZxjglZW(bool zePHu, int olzjFXxnrxE)
{
    double iSguVCubSODZj = -393930.86879050836;
    bool iNlMRxWSTz = false;
    bool RSFnx = true;
    double wAwcG = 600916.5329686211;

    if (iNlMRxWSTz == false) {
        for (int HYRFJvzUFtwpfYa = 1702476213; HYRFJvzUFtwpfYa > 0; HYRFJvzUFtwpfYa--) {
            RSFnx = ! RSFnx;
            zePHu = iNlMRxWSTz;
            RSFnx = ! iNlMRxWSTz;
        }
    }

    if (RSFnx == false) {
        for (int qdyqbkP = 1535722692; qdyqbkP > 0; qdyqbkP--) {
            iSguVCubSODZj /= wAwcG;
            iNlMRxWSTz = zePHu;
            iNlMRxWSTz = ! iNlMRxWSTz;
        }
    }

    for (int EYsrMuWDwlIaDuOv = 871865157; EYsrMuWDwlIaDuOv > 0; EYsrMuWDwlIaDuOv--) {
        wAwcG -= wAwcG;
        iSguVCubSODZj -= iSguVCubSODZj;
        iNlMRxWSTz = RSFnx;
        iNlMRxWSTz = iNlMRxWSTz;
        olzjFXxnrxE *= olzjFXxnrxE;
    }

    return RSFnx;
}

double iFSkvYJsJQIC::fvoEOqsIdtTcm(double eBtrAwTrWXHICo, int vSftZa, string iDBeLjjK)
{
    bool VXFuhB = true;
    bool QwFMyNPMmLN = false;
    bool cQKhbIPNravgR = false;
    bool zzuOMwotGjxeWK = false;
    double OnZziTrnc = 854186.1567916557;
    double vKeIA = -597597.4130269374;
    string KfGMtd = string("SNLgRLqjzAXzyEGwdtGjhxozIyTNpnrTskVQCVjzmPqLLKcmWgdwhrvcliqCTEnKhkGkPtNUpvPYPEZcEJQfgXhuogDkfgcacucKQaFYEGkqBStkSvwqezrwRmMymfQUhftNETxbGziXAqFLRZJWPirqPzdhZSFvwGcvOwRjHvAlzGqdcwZTU");
    double YwuDXcNImAXgL = -3756.71484710545;
    double TdqJAb = -270644.44801613106;

    for (int HnTXwJHpQwccjdO = 625168271; HnTXwJHpQwccjdO > 0; HnTXwJHpQwccjdO--) {
        VXFuhB = zzuOMwotGjxeWK;
        zzuOMwotGjxeWK = VXFuhB;
        VXFuhB = ! VXFuhB;
    }

    for (int YZNEhNLHF = 450100999; YZNEhNLHF > 0; YZNEhNLHF--) {
        iDBeLjjK = KfGMtd;
        OnZziTrnc = TdqJAb;
        YwuDXcNImAXgL = vKeIA;
        VXFuhB = VXFuhB;
    }

    for (int MXoPWuHKJL = 1259054128; MXoPWuHKJL > 0; MXoPWuHKJL--) {
        continue;
    }

    return TdqJAb;
}

string iFSkvYJsJQIC::AxQHAmXss(bool JhtEmYLEjCFuR, bool GGgKnqviJKLYG, string yYgaL, bool efQLltCA)
{
    string HXyWpBlUivdb = string("uLVShGnISYlNCaEZiSQEicouVWpCDJrXYxYnczgZXHUTsmxtLZlXJfwtcQQVsJISMKVKMGJgFlUwfhJNGadcpkPBMKSBYhcaNVDIeZlZoouxQjluiXmMUluTqacbmRJHPUHIlBhIMLWAiPKTeUPsxGRhUKcCtLETyuTBSFNckaQJtdOOOZnTPcxWbekAKTNmTxBALJImBjohdMwJpDUYjzPIuzA");

    if (yYgaL >= string("uLVShGnISYlNCaEZiSQEicouVWpCDJrXYxYnczgZXHUTsmxtLZlXJfwtcQQVsJISMKVKMGJgFlUwfhJNGadcpkPBMKSBYhcaNVDIeZlZoouxQjluiXmMUluTqacbmRJHPUHIlBhIMLWAiPKTeUPsxGRhUKcCtLETyuTBSFNckaQJtdOOOZnTPcxWbekAKTNmTxBALJImBjohdMwJpDUYjzPIuzA")) {
        for (int jnWroQRtxNqsSJve = 615564274; jnWroQRtxNqsSJve > 0; jnWroQRtxNqsSJve--) {
            GGgKnqviJKLYG = ! efQLltCA;
            GGgKnqviJKLYG = efQLltCA;
            efQLltCA = efQLltCA;
        }
    }

    if (GGgKnqviJKLYG != true) {
        for (int jNVuRwkihgxi = 1691801666; jNVuRwkihgxi > 0; jNVuRwkihgxi--) {
            JhtEmYLEjCFuR = ! JhtEmYLEjCFuR;
            yYgaL = HXyWpBlUivdb;
            efQLltCA = efQLltCA;
            yYgaL += yYgaL;
            HXyWpBlUivdb += HXyWpBlUivdb;
        }
    }

    return HXyWpBlUivdb;
}

void iFSkvYJsJQIC::pQAdrkGld(string FYvgfPtHqotGprc, string bzipYzR)
{
    double HmwvdRsjwQsl = 329733.44983310613;
    bool qUPPwk = false;
    double oSbwyTtBwYh = -719640.2179685085;
    string kRFJkvdaSgTBaZDN = string("BwKhRamBnAARrgsZwvEwGUXUCuhRgnoNwrrKvHBQxlSQnaMAROzLWVNHNNPWBseKvjOsTUnKXXAGZVAREgQyCQINshvXVLtVBKVuurIWilpFvPXXEOufRaUwQPpfbHrhRZtTngOQ");

    if (FYvgfPtHqotGprc != string("oqLELzwQdkySIAEqbIfXDUiBiRjHQsYQGmoghUjLoFrQGVZllDaAUxRFpFDFuLitUKHtYOzfEsKCIhKAStvuEBnoKZWAyBURMQsUtFdbZMSWWumlsQWFpYMcdoMmYtDgHOzRMDwEfXCcelihTQLBzB")) {
        for (int ZWtBEJyt = 1614108339; ZWtBEJyt > 0; ZWtBEJyt--) {
            continue;
        }
    }

    if (qUPPwk != false) {
        for (int GirUVPzczdPhJ = 1013638698; GirUVPzczdPhJ > 0; GirUVPzczdPhJ--) {
            HmwvdRsjwQsl -= HmwvdRsjwQsl;
            kRFJkvdaSgTBaZDN = FYvgfPtHqotGprc;
        }
    }

    if (qUPPwk == false) {
        for (int itiKuuWbZLsHv = 444390631; itiKuuWbZLsHv > 0; itiKuuWbZLsHv--) {
            qUPPwk = qUPPwk;
            bzipYzR = kRFJkvdaSgTBaZDN;
            bzipYzR = FYvgfPtHqotGprc;
            qUPPwk = qUPPwk;
        }
    }

    for (int tJGRIUdWJKPUc = 182612373; tJGRIUdWJKPUc > 0; tJGRIUdWJKPUc--) {
        bzipYzR += kRFJkvdaSgTBaZDN;
        FYvgfPtHqotGprc += FYvgfPtHqotGprc;
    }
}

double iFSkvYJsJQIC::ICgbtEkljVbVDTk(string HqjKicEe, double dQTEaNjc, double KwUsCgezbrkVP)
{
    bool TFfzhdleLn = true;
    double zzdscBzxrJxSbH = 671520.1755059168;
    string BbKoQTs = string("vLkdbkCfZFKOusMhNdCuxFarXRcAIVgktNfublMtxorzqJSBysksMfSrteHGMkjaOWWZSjpomXluEqkizZYVRTUxliyaeXpMYwYuGDXoilaHIehMWnOxRmWJCiKuVYMIDTJffNfQKzyRKyOumYFAmyVamBlZhErMvgfOJBgktBUmzocPklXntEN");
    string bRHLOWAFQyiL = string("viZGAwXeKStehRbcSrvKDeRKOCCNcsFEc");
    int aapgrgqAlL = 1059145136;
    string rkbiqizQbghu = string("MzOVopkxmsdIqhXPkMiVjMQiblqDCiPxIleRVqPYTVHJSMaUQsXvDqCSMiPaydhMFHuLnbypjjOnqEmHojEeuYqJinmyEYwBHNkIKFqpclEkqAdVPWDjjuWxNOoSSSzXttecUarCBGxvnDMlxIJJHrEArhRFqNXunAjBiwNzTZwoJXliXXwjXLCXXA");
    bool ijxrhQI = true;
    bool NuuGXyVROzFvuU = false;

    for (int kXOTMgOlVWGo = 2010032424; kXOTMgOlVWGo > 0; kXOTMgOlVWGo--) {
        NuuGXyVROzFvuU = ! ijxrhQI;
    }

    if (aapgrgqAlL <= 1059145136) {
        for (int ZSIznPw = 2095766206; ZSIznPw > 0; ZSIznPw--) {
            HqjKicEe += BbKoQTs;
        }
    }

    return zzdscBzxrJxSbH;
}

bool iFSkvYJsJQIC::OHcvBBAJVQ(bool cvcqlu, string ENqritZJnQAbKmjJ, int AEMVVRDJGV, double ISrRgpWoWrc, int WLuXswMbrafn)
{
    string zQOBdM = string("mqnPmCXxos");
    string yyEIHCCCKqKHRniF = string("nSgEHDGEdEFrxKrnebGFxewMLEQchpkvlajYKBPXjSgDubnrbRCcNcvUPHtGrvQbaHjcREPegixzpJdkZDCRHhXYNoEWx");
    int YIuybVmOfrfIxuT = -349032555;
    double aJvBVJQjQMTo = 599645.3761885719;
    double HWUIxBgYhH = -760121.0234524016;

    for (int kycPcwYuZnqspFv = 1575325315; kycPcwYuZnqspFv > 0; kycPcwYuZnqspFv--) {
        continue;
    }

    for (int ovBroIUGtJorl = 1053243602; ovBroIUGtJorl > 0; ovBroIUGtJorl--) {
        WLuXswMbrafn += WLuXswMbrafn;
        WLuXswMbrafn += YIuybVmOfrfIxuT;
        ENqritZJnQAbKmjJ = zQOBdM;
        yyEIHCCCKqKHRniF = yyEIHCCCKqKHRniF;
    }

    if (WLuXswMbrafn < -349032555) {
        for (int eyewZUZiln = 1626113570; eyewZUZiln > 0; eyewZUZiln--) {
            WLuXswMbrafn = WLuXswMbrafn;
        }
    }

    for (int EsrnjFJxhoqU = 1175295631; EsrnjFJxhoqU > 0; EsrnjFJxhoqU--) {
        HWUIxBgYhH += HWUIxBgYhH;
        ENqritZJnQAbKmjJ += ENqritZJnQAbKmjJ;
        WLuXswMbrafn += AEMVVRDJGV;
        ENqritZJnQAbKmjJ += ENqritZJnQAbKmjJ;
    }

    return cvcqlu;
}

int iFSkvYJsJQIC::xuLsOBsBZcESuJs(double oPLYqvy, int eNQLSkiWBz, int QARkxlHUTbT, double sYnXxrW)
{
    int OoDzuqPS = -1303338785;
    double wtoLJs = -736689.9168610174;
    bool ztLQfuyjW = true;
    int UgnKkpIoWoAA = 1780532877;
    string WiVlAatrLqeDfAO = string("XpqCbjrqMmonhWGKAKWmbvftRPMDUJAlRhLlLpjNhfeVgiRCAeIxVILilAeyWCzNVUdFShlZglnDfEzCWTbPxYHWIVqXsqJsPsmFRZCjUpLZfaorRIKErRWbAISvGbGGxMgNDpMdlyjhieiKOqHhaFbEllrHIrucTiiLDTCVOEjXMzBckmfifkJFzXdqBAqKxhBkhKWQaogqjpgPnrlYFviuysPXDASuBzZTnBmJmybbhPFH");
    double KpJdsgPwkB = 539601.0481426617;
    bool YmQSEMyDEOa = false;
    bool aRslNFLl = true;
    int ayNZSmSfpcuXVu = -2037633410;
    bool GDvSgCwBxjjHpCW = true;

    for (int OekyQYzdSUSI = 940415263; OekyQYzdSUSI > 0; OekyQYzdSUSI--) {
        continue;
    }

    if (oPLYqvy < 539601.0481426617) {
        for (int KEOcReTPKq = 2132764789; KEOcReTPKq > 0; KEOcReTPKq--) {
            oPLYqvy *= KpJdsgPwkB;
            QARkxlHUTbT += UgnKkpIoWoAA;
            wtoLJs = KpJdsgPwkB;
        }
    }

    return ayNZSmSfpcuXVu;
}

int iFSkvYJsJQIC::PDaUnBSrgEIVQqN(bool WYnAZtna, double jHVjNqQGGFJKQOG)
{
    bool PfIuDHKnFxfImJyq = false;
    string KDzIbjLKWeSmRdg = string("MnEWtAzqiquIitbbxZdnxMjKPYxcqvhsJoHgMZcPIEpVuPqgaUfcGpUykcQfFbiRuFwXjkhwxInxQMDClzcFOGpLEDWMbTLIHaxiZsZShGjkKynXuirzwhTezoVweYrjDuptiobooJRIW");
    double CHBXivKQCTLCIvS = -720766.4414408966;
    double qJNRWbR = 756126.2812102898;
    bool dvdPnEKU = true;

    for (int TVuUuuvSOET = 53960129; TVuUuuvSOET > 0; TVuUuuvSOET--) {
        qJNRWbR -= jHVjNqQGGFJKQOG;
    }

    for (int HvUxFHowprdEpAp = 978938695; HvUxFHowprdEpAp > 0; HvUxFHowprdEpAp--) {
        jHVjNqQGGFJKQOG = jHVjNqQGGFJKQOG;
        PfIuDHKnFxfImJyq = WYnAZtna;
        dvdPnEKU = dvdPnEKU;
    }

    for (int WVLQVtvmCsJb = 761006094; WVLQVtvmCsJb > 0; WVLQVtvmCsJb--) {
        dvdPnEKU = ! WYnAZtna;
        WYnAZtna = WYnAZtna;
        KDzIbjLKWeSmRdg = KDzIbjLKWeSmRdg;
    }

    return 1214068628;
}

iFSkvYJsJQIC::iFSkvYJsJQIC()
{
    this->yvVuCWiXXpRIBsS(false, 192087.74328331364);
    this->PDTOZxjglZW(false, 891653432);
    this->fvoEOqsIdtTcm(-602848.4906951886, -717684144, string("NjNSjljfbHgdwtwqWUJyPmGzaTGHLkauPmFOhziADAEBNwhRVrKaldriqNwnsseHVMEnBvqQmWWDyatPpuOSVnHMCRFTFABsDSbrLOVnukEdShdztkEHYHfMNDvRNGvSnrRMteWLhhneiRgUqXCITTkbBXjLDjvkiCNYXUWSsrqqAy"));
    this->AxQHAmXss(true, false, string("zrpOyEqLElllnezEwlYFrsjFMbkVBMBchyqGOjU"), true);
    this->pQAdrkGld(string("MzapKWRfbjbvuCFrLuLqgoKKtbSdEzLQWTFtszSmeEFicxhCWHorXmNuRWXzuwyoBQDBfTHzniaEVMWkrYzUoLznrmpeJVwpaKXXRNgOgEmvoKZjRqOuMNTVHQJSOb"), string("oqLELzwQdkySIAEqbIfXDUiBiRjHQsYQGmoghUjLoFrQGVZllDaAUxRFpFDFuLitUKHtYOzfEsKCIhKAStvuEBnoKZWAyBURMQsUtFdbZMSWWumlsQWFpYMcdoMmYtDgHOzRMDwEfXCcelihTQLBzB"));
    this->ICgbtEkljVbVDTk(string("ZQnLqOFtuAcvaSYjqOiyaAOnvqVnADDWuaiDjIGfCPxwRwqKvRGORtzCPhpREkJKJmjySKnkyspxiScYmyEkTheuYEhcouakkIhCZSUbADqLJRNtOltfTPgtLoNDntdPXdU"), 535306.3905360682, 178394.61797014117);
    this->OHcvBBAJVQ(false, string("NQqMXQczetexpgsKSDPdDojRlalWtHRYaxwbEhKhvHaulOFJBuRCTRNnZpzaWUyCiUxRSOAjPaWnEjpzFDvbgAURdeIZJiSNvLUAufTGvlOUKUhCbXcKdIOYdXOKsWontqfEjvwWcmIXnpDgEvpofexFcaoxktGOeOHbxfAxzdOBRMywbqrjgfveXBdCuMdhVgDTnoEMOymy"), -1980104212, -1016411.6436538426, 1852004999);
    this->xuLsOBsBZcESuJs(-292441.25539053034, -1416227169, -2077666289, 900542.1700731486);
    this->PDaUnBSrgEIVQqN(true, 805827.2459583281);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ugrhqXFcPNmrBG
{
public:
    bool VNxTRvOMuDanBkbq;
    string mzlpogWl;
    bool XCLfXjAu;
    string IciDvjnagaiCIV;
    int YmWffkfx;

    ugrhqXFcPNmrBG();
    string upoSWedX(string UxgAKB, string LoVcdGvSNy);
    double mbqid(string zQwBIylhosDOWBSt, double qekheUQrpIbFUX, bool YxeLwBwhfkzbDiAc, string OtQhDEGFwTeeE, double EsgCJGigKYRa);
    string ktidGcgX();
    bool mXKXzfQwDQmX(int CZawLrYdgCdNGQ, string LdTVQ, bool LALryUNHyrpi, bool krKLhcIvKTGb, int MhmSeCyBg);
    int wzHyInC(int dElbbWwxvHDy);
    double CUycrLHWOzED(string RRhacSjTCItfk);
    void NgOOl(double LHqtKyg, double vlasoT, string vPwJGSEme);
protected:
    string qfdBGjixMXLnIQ;
    double fBzHT;
    string qMZTmIChzu;
    double wYbVRGYpfuhlg;
    double hBQvrzuzohAlB;

    bool MMvLadj(bool BGnUyfNBrkJMz, bool FcWngdsbWjPlVVW, string YBmBuU, int HxPNiVVrYrBR);
    string gaYJIx(double sUXITCjml, bool nwFWqNSGvEWInf, bool cMKcJCNdHKomeH, string wDPnxTwyZmIPC);
    void UpLTIxNKTE(bool XCjqogTka, double hAKNbQhXB, string qgAIIoMQFoRIrFO, double ZuPOcSIMzH);
    bool UqONpMxRFYrij(bool WVEAhD, int EoqVDbma, int bABhX);
    bool CrxhcZlPK(bool WRdNgu, bool KISJxjhsGyYI);
private:
    bool zMxGlfhBz;
    bool lNZkFdrzstx;
    int SyYyKkgCfQ;
    double SCDXtkPnYIkxkZdN;
    string UrMKcgaVtlKluPf;
    double kNiKNtXVjPagSCWG;

    bool gGRBDPDihvd(bool MgADM, string ymGUQFQp, double YRduaVo, bool QAwffzQjMooOi, int bBwtpPjOnQcYB);
    void XbkECwoOrddKbas(int KktmC, string rgqfRXXhOqBv, double WcklBdcYiVPweWO, string QBhsnIUwhbqBfq, int euMUpcdrwbyklAQ);
    int TMTJA(string uEHNccSwgPyY, int SEGVkhu, double zdbqqVenawVMW);
    string YfQgLmQjgVLmNC(bool GpXUMnLiqqH, string HmibEYJfBZoFss, bool QeVNOoiNe, int EwYKCZILfxsae, string cIBiDP);
    int ziPSB(string nBgiMRELUjxzA, double VWjbTecBMlxMTjp, double TpEjrQO, string sWkZkqadWCH, double QTcKyVBhLGhj);
    string gqKQT(bool MzGfUrdTcJA, string CSXjJqMdNTSHeKa, int IGQdDDLnotjQr, string ZMoDITXdkUI, string rtNouWDkM);
};

string ugrhqXFcPNmrBG::upoSWedX(string UxgAKB, string LoVcdGvSNy)
{
    double LmmztsFOVqpUbfJl = -870745.0205687258;
    double qLktjIHVqI = -5668.692546648744;
    string NCEtmeNIWEhOncY = string("IjolGblyMeiVPTniDiuxnsoWDmmpOPSwRHIaLboAPLoOopCKWUpWbtJBPrIcOhgbgxJNhrwRtbFWvWtiSeoAXRviZywYYDlGOFhmV");
    bool ySdtGYFRPUcRKvbp = false;

    if (LoVcdGvSNy > string("IjolGblyMeiVPTniDiuxnsoWDmmpOPSwRHIaLboAPLoOopCKWUpWbtJBPrIcOhgbgxJNhrwRtbFWvWtiSeoAXRviZywYYDlGOFhmV")) {
        for (int enRJXR = 632166537; enRJXR > 0; enRJXR--) {
            qLktjIHVqI += LmmztsFOVqpUbfJl;
        }
    }

    return NCEtmeNIWEhOncY;
}

double ugrhqXFcPNmrBG::mbqid(string zQwBIylhosDOWBSt, double qekheUQrpIbFUX, bool YxeLwBwhfkzbDiAc, string OtQhDEGFwTeeE, double EsgCJGigKYRa)
{
    int DsinbpsewokuwDPg = 1488179569;
    double brOWGJnuAox = -754601.513844568;

    if (brOWGJnuAox > -754601.513844568) {
        for (int DILDnaojwoNKmo = 1579116346; DILDnaojwoNKmo > 0; DILDnaojwoNKmo--) {
            EsgCJGigKYRa /= EsgCJGigKYRa;
            zQwBIylhosDOWBSt = zQwBIylhosDOWBSt;
            DsinbpsewokuwDPg *= DsinbpsewokuwDPg;
        }
    }

    for (int lepNdOaiOkw = 96173275; lepNdOaiOkw > 0; lepNdOaiOkw--) {
        brOWGJnuAox *= EsgCJGigKYRa;
        qekheUQrpIbFUX *= qekheUQrpIbFUX;
        OtQhDEGFwTeeE += OtQhDEGFwTeeE;
        YxeLwBwhfkzbDiAc = ! YxeLwBwhfkzbDiAc;
    }

    return brOWGJnuAox;
}

string ugrhqXFcPNmrBG::ktidGcgX()
{
    bool HuAOvOBcLH = true;
    int lJaCMBEJxLX = 327808108;
    int EsQdoeYdSFsSEELG = 425750613;

    for (int TOdNGISancxvgliE = 681665116; TOdNGISancxvgliE > 0; TOdNGISancxvgliE--) {
        HuAOvOBcLH = ! HuAOvOBcLH;
        lJaCMBEJxLX += EsQdoeYdSFsSEELG;
    }

    return string("cNVFfHuClZKGaLeJxUNkZIYBdMWWcbKiuTJauPGPrcjoCIStlAlqWysDajooaGnYGrrrHJLmoFkcpfquhMFkSXJiDYwYxkaGKZvtxUDueokBsDNnJTOkloCuhgXsFSglJsJKEuraUTpERdhcBFrZKdrltrSODAvlsthhngsPvu");
}

bool ugrhqXFcPNmrBG::mXKXzfQwDQmX(int CZawLrYdgCdNGQ, string LdTVQ, bool LALryUNHyrpi, bool krKLhcIvKTGb, int MhmSeCyBg)
{
    string KxGBY = string("teGxaeOkyScaJPambaJkXNHQIpaMvWxylYYGEKsIwIXAgjaggLjEnkqFNzMRcd");
    int SmeEMus = 1435816413;
    double RcBWtdquEfXEW = -543074.0046415309;
    double QxqnVtIukvbf = -877712.2828171622;
    string OJWZiaaT = string("GKLfRVqTlUDmVKKNZNfuSSpIGafIPJHcgPoXugDmGkXjkPOftxfAaMTLSSq");
    double OOYKfvokEhr = 568023.356749451;
    double mmdydoFLSeGRX = 437184.02313163335;
    int rhMlZVjsMW = -1801332749;

    if (mmdydoFLSeGRX != 568023.356749451) {
        for (int rZpoLV = 919268284; rZpoLV > 0; rZpoLV--) {
            MhmSeCyBg += CZawLrYdgCdNGQ;
        }
    }

    for (int uIgOrvldC = 2095541771; uIgOrvldC > 0; uIgOrvldC--) {
        SmeEMus -= MhmSeCyBg;
        MhmSeCyBg = MhmSeCyBg;
    }

    for (int phsDOXuV = 565170090; phsDOXuV > 0; phsDOXuV--) {
        LALryUNHyrpi = krKLhcIvKTGb;
        CZawLrYdgCdNGQ = MhmSeCyBg;
    }

    return krKLhcIvKTGb;
}

int ugrhqXFcPNmrBG::wzHyInC(int dElbbWwxvHDy)
{
    bool PjPkEqLbW = true;
    string fhpSoFUnLrNm = string("jgxyFzsXXtesjisqdbOlbIEiuCopxUKhceDppFRTHsjMpLTFrIpmpKjTFlevslNxfaYqoQXltLMvcHkolelozLMGHPzsXDfHhsHFUjbVlLRjOTYiAteOiOpQzzuXRGTraYCflggldlnXejFKhDVrKLUZFcxJrnAkxYKeyTlWXyGeNvYwXlCBUTtItJczbcpgFH");
    double rAxanIkHmhaiNhof = -819856.4737120394;
    bool rDXFLFhJyTAtP = false;
    int aYlQHCgPmt = -1972097751;
    string hEyUQmhmlKVenYMr = string("HYBfaqhTvhCIpSmvgkBSEEHDLqlTNwxIlDiYapzPCfWZrdCVUBQpuIWbrzykxOojLvTrltACVgXvmRWlHzVKUmBNtDsDMISnCcdUPKwyorVfEzizftbawZMIeJcDylxXpJZtPdhwlREbNZwieFxrMocmOcIkvyshFsHhzrRgWXiFCUlfVHxsYRXokHqffqwbT");

    for (int QnzOWhWY = 1260301400; QnzOWhWY > 0; QnzOWhWY--) {
        rDXFLFhJyTAtP = ! rDXFLFhJyTAtP;
    }

    if (PjPkEqLbW != true) {
        for (int XEkjYIKITmYlD = 1696950148; XEkjYIKITmYlD > 0; XEkjYIKITmYlD--) {
            rDXFLFhJyTAtP = rDXFLFhJyTAtP;
        }
    }

    for (int yYUogrTMJbtaEs = 1882178731; yYUogrTMJbtaEs > 0; yYUogrTMJbtaEs--) {
        dElbbWwxvHDy -= aYlQHCgPmt;
    }

    return aYlQHCgPmt;
}

double ugrhqXFcPNmrBG::CUycrLHWOzED(string RRhacSjTCItfk)
{
    int bDkATIVaZJbQ = 1602635643;
    string NEGmJuwyLtoYCRE = string("EsoQzKqA");
    string OOeNXAAIjzVPad = string("hwAHlBhJeDcqjwfwzbeWWAaoZhFGROZKLDqCAJQPdQrRAbykodNHtyNrlWwQquvLLJmkEzdMLHDVtUSUvVFCyRiPFGUhQTPTpVmxybWvUKbIQWbiElmknVfSyUgbtuFosAfrVcZlyanTSLGlOARXsQRWPfOjmEEMwYisYVxwFJkOpIOCCoUrcNOIeefZemjSdapwsHQhWLneJhfbLhaNfQGqu");
    int hPjZtXQ = 207456041;
    bool wKKxzzfGPMzUxdD = true;
    string ZmUFz = string("DjumdtUzSZhroawaULbEdGCVYJtMvGKfobJBnwNXTUclbZfpLDsmrGShFjVAQideuXxDelODhxbGnZXAxlLuwUfEaFchTjtTSrWgaeOoPrCwdFjHrTpNtFrozmnXaCJAKqsJoMcnqmTNgCYPFCDSEbkfdHxjscOPnWLAoSBrPulnSjEONEIlrfn");

    for (int jJfHiCJncb = 998004867; jJfHiCJncb > 0; jJfHiCJncb--) {
        OOeNXAAIjzVPad = NEGmJuwyLtoYCRE;
        OOeNXAAIjzVPad += OOeNXAAIjzVPad;
    }

    for (int AzPwssMKJQxFW = 293552062; AzPwssMKJQxFW > 0; AzPwssMKJQxFW--) {
        continue;
    }

    for (int SmJYrTlTl = 1921870837; SmJYrTlTl > 0; SmJYrTlTl--) {
        ZmUFz = RRhacSjTCItfk;
        OOeNXAAIjzVPad = RRhacSjTCItfk;
    }

    if (RRhacSjTCItfk == string("hwAHlBhJeDcqjwfwzbeWWAaoZhFGROZKLDqCAJQPdQrRAbykodNHtyNrlWwQquvLLJmkEzdMLHDVtUSUvVFCyRiPFGUhQTPTpVmxybWvUKbIQWbiElmknVfSyUgbtuFosAfrVcZlyanTSLGlOARXsQRWPfOjmEEMwYisYVxwFJkOpIOCCoUrcNOIeefZemjSdapwsHQhWLneJhfbLhaNfQGqu")) {
        for (int EkiukIf = 1921707900; EkiukIf > 0; EkiukIf--) {
            ZmUFz = ZmUFz;
            ZmUFz += OOeNXAAIjzVPad;
            NEGmJuwyLtoYCRE = RRhacSjTCItfk;
        }
    }

    return -881936.47099032;
}

void ugrhqXFcPNmrBG::NgOOl(double LHqtKyg, double vlasoT, string vPwJGSEme)
{
    int YCOUDmnsDn = 1674061152;
    bool nooNVJhPIXeG = true;
    double hQADYsdfEcHIS = 203643.24007598346;
    int AYXGFoqh = -116600742;

    for (int sSmFVKiXWjQ = 1253160365; sSmFVKiXWjQ > 0; sSmFVKiXWjQ--) {
        continue;
    }

    for (int CiLgeyAGQ = 102582187; CiLgeyAGQ > 0; CiLgeyAGQ--) {
        continue;
    }
}

bool ugrhqXFcPNmrBG::MMvLadj(bool BGnUyfNBrkJMz, bool FcWngdsbWjPlVVW, string YBmBuU, int HxPNiVVrYrBR)
{
    bool hMgzMjxVr = false;
    string dpVHZwqBDavaIUKW = string("MdwnzgOhMDBSwmxAzHpqUDUyzEaAjZEDwjlWrHAGlYgnCOSFul");
    double QnXxewJPa = 115006.11232143106;
    int ltAIzuWosIsMFBk = -216528957;
    string sOjQrGg = string("enwRWdzOmzwkYbKzwyZbqqUKXjULPDHwMTVjdlqCPWaRwZgmcVyJilAAeOcHhPtgTRWCbbMUCViPJrFApELMgVQFypgjvbMHDaKpMPvysnKhABtgQwciYgloaORrPDIouhbukFMfMKvylqPdMdBtAccQeldSFmOxxIpImBMIpFLFqgwTJSM");
    double JMaGzfKYjoqiB = 60940.859542063365;
    int slotuZda = -133059688;
    double ieWnNZlwXwgxw = -1004781.9505826123;
    string fYuOg = string("bWaziwFcawpPmnsfYAMZvOJkivDqbPPDhSKZPBoEhFnRLlpgKkQGEjwgUFDSWsjNbhYzjjvEpBbVYAWUQCMHHpylhf");

    for (int SqmRKvUT = 344100533; SqmRKvUT > 0; SqmRKvUT--) {
        sOjQrGg = sOjQrGg;
    }

    for (int KHQGJkcwE = 1062660832; KHQGJkcwE > 0; KHQGJkcwE--) {
        continue;
    }

    for (int fHaSfaZcL = 1427677785; fHaSfaZcL > 0; fHaSfaZcL--) {
        ieWnNZlwXwgxw /= QnXxewJPa;
    }

    if (ltAIzuWosIsMFBk >= -133059688) {
        for (int PxuSBrSHq = 622128322; PxuSBrSHq > 0; PxuSBrSHq--) {
            sOjQrGg += YBmBuU;
            JMaGzfKYjoqiB -= QnXxewJPa;
        }
    }

    return hMgzMjxVr;
}

string ugrhqXFcPNmrBG::gaYJIx(double sUXITCjml, bool nwFWqNSGvEWInf, bool cMKcJCNdHKomeH, string wDPnxTwyZmIPC)
{
    string hkVrpbZadKIgY = string("LganPbkKTpUktOyPZcTFbDadNzJhKspfzdXNMDNNnKSrNbKzAfABvVXgHemRNxmueArmPKVjRkoVsmIvzmfhVcQWyxzLTMiKHagvqqcRuAaXDJQVlyNFAeSuTYzmSKLyNWsuymBATQISDLlhNBZMWFbkAfTiEPNggOmrHTIeOhiMAeAWNmShvhdHaSp");
    int nCmiyU = -766131066;

    if (wDPnxTwyZmIPC < string("LganPbkKTpUktOyPZcTFbDadNzJhKspfzdXNMDNNnKSrNbKzAfABvVXgHemRNxmueArmPKVjRkoVsmIvzmfhVcQWyxzLTMiKHagvqqcRuAaXDJQVlyNFAeSuTYzmSKLyNWsuymBATQISDLlhNBZMWFbkAfTiEPNggOmrHTIeOhiMAeAWNmShvhdHaSp")) {
        for (int mXynMeIvmQYFE = 1345321173; mXynMeIvmQYFE > 0; mXynMeIvmQYFE--) {
            nwFWqNSGvEWInf = cMKcJCNdHKomeH;
        }
    }

    if (hkVrpbZadKIgY >= string("kMltSpQIdbzeLwqFhjdOHCbjxOacJaUGzZlTBfAulsgJhXGEiwKdypUQgZkPCYhGghlucwhpXUbRWSfUmULlTyLZmmJEleafRuSuGzKtfPLYxKudlKQgOXJtsLgOlyyyjhwWSfCQErmbqb")) {
        for (int YMMMur = 1797304024; YMMMur > 0; YMMMur--) {
            continue;
        }
    }

    if (wDPnxTwyZmIPC < string("LganPbkKTpUktOyPZcTFbDadNzJhKspfzdXNMDNNnKSrNbKzAfABvVXgHemRNxmueArmPKVjRkoVsmIvzmfhVcQWyxzLTMiKHagvqqcRuAaXDJQVlyNFAeSuTYzmSKLyNWsuymBATQISDLlhNBZMWFbkAfTiEPNggOmrHTIeOhiMAeAWNmShvhdHaSp")) {
        for (int XVnursxffZSZuYSb = 1716869169; XVnursxffZSZuYSb > 0; XVnursxffZSZuYSb--) {
            wDPnxTwyZmIPC += wDPnxTwyZmIPC;
            wDPnxTwyZmIPC = hkVrpbZadKIgY;
            nwFWqNSGvEWInf = ! cMKcJCNdHKomeH;
        }
    }

    for (int JxzbiTiRQNGx = 474599338; JxzbiTiRQNGx > 0; JxzbiTiRQNGx--) {
        nwFWqNSGvEWInf = nwFWqNSGvEWInf;
    }

    for (int xoTlAWC = 1647846686; xoTlAWC > 0; xoTlAWC--) {
        hkVrpbZadKIgY += hkVrpbZadKIgY;
    }

    for (int HWxPYJlRFzw = 107879116; HWxPYJlRFzw > 0; HWxPYJlRFzw--) {
        cMKcJCNdHKomeH = nwFWqNSGvEWInf;
    }

    return hkVrpbZadKIgY;
}

void ugrhqXFcPNmrBG::UpLTIxNKTE(bool XCjqogTka, double hAKNbQhXB, string qgAIIoMQFoRIrFO, double ZuPOcSIMzH)
{
    string bBLmTNqhPgrbPo = string("yrciTZFHEDAcPygUdINzgRVfQcAUkcmSdfDgkDDgTfxMaNesHkwowzSFVQrLmDbxbZmNmTCwdRmeQiJMHKwvRtacZqrtCUdRtjJszJNZqrKUkaoawdkDKvUNSrqjQIwsFivHZdAMMDyCRSNgpvdgslczKRZcWoatYeXbJTGkedxMmHXvMEXsmzAZBrPVBSwaTzWlVqsZjWfIngj");

    for (int MzNVBKHHrERLXSxs = 1323430593; MzNVBKHHrERLXSxs > 0; MzNVBKHHrERLXSxs--) {
        ZuPOcSIMzH *= ZuPOcSIMzH;
        qgAIIoMQFoRIrFO += bBLmTNqhPgrbPo;
    }

    for (int jRBTtGd = 2020319850; jRBTtGd > 0; jRBTtGd--) {
        ZuPOcSIMzH -= ZuPOcSIMzH;
        hAKNbQhXB /= hAKNbQhXB;
        ZuPOcSIMzH += hAKNbQhXB;
        ZuPOcSIMzH /= ZuPOcSIMzH;
        ZuPOcSIMzH -= hAKNbQhXB;
    }

    if (hAKNbQhXB >= 786860.2099883363) {
        for (int DiyYCeAHmwCaO = 1895812039; DiyYCeAHmwCaO > 0; DiyYCeAHmwCaO--) {
            hAKNbQhXB = ZuPOcSIMzH;
        }
    }

    for (int vwXUdOoVQHtvp = 1770081672; vwXUdOoVQHtvp > 0; vwXUdOoVQHtvp--) {
        qgAIIoMQFoRIrFO += qgAIIoMQFoRIrFO;
        hAKNbQhXB = ZuPOcSIMzH;
    }
}

bool ugrhqXFcPNmrBG::UqONpMxRFYrij(bool WVEAhD, int EoqVDbma, int bABhX)
{
    int grVKReTPne = -602159941;
    double uFTSG = 218704.95680095552;

    for (int wuzVFYOsFTfga = 207131178; wuzVFYOsFTfga > 0; wuzVFYOsFTfga--) {
        grVKReTPne += EoqVDbma;
        grVKReTPne /= EoqVDbma;
    }

    if (bABhX > -660266419) {
        for (int lbUbOWzCV = 646575684; lbUbOWzCV > 0; lbUbOWzCV--) {
            grVKReTPne *= bABhX;
            WVEAhD = WVEAhD;
            EoqVDbma = bABhX;
        }
    }

    if (grVKReTPne < 740122183) {
        for (int ebuIXPfTsrOP = 2759171; ebuIXPfTsrOP > 0; ebuIXPfTsrOP--) {
            bABhX = grVKReTPne;
            EoqVDbma *= bABhX;
        }
    }

    return WVEAhD;
}

bool ugrhqXFcPNmrBG::CrxhcZlPK(bool WRdNgu, bool KISJxjhsGyYI)
{
    string AWUeNONwMiExKW = string("ajkjANVSNeNjAeJfvfzVppTzBkvUCMWfWUSWjeSeBCVBqaEBcerDNiSWBxTgGERBAqHzKFGYlz");
    bool cZqhI = false;
    bool ESIJDB = false;
    bool hBYUPj = true;
    bool cdTRLRs = true;
    string DlsGxy = string("jSfHsuddvYucWMBCwKfZPCvRMeueltOcIjikpZrNmAvoXwZgoHJVaQvJKusqcMqUvCsXVPdSCdBGvYkBDTzSgbcYafrZJAufezOwWVRKjrhjTEpCTDdzclJPlVudoiBUkfpPmfNjpRqeZxAXNFiHEjhYhCQBrLkJPkkbLlHiKkpqaxuECoeIdPTkcRIYTfcPlnNemeggfsbcIvwrwUkfrvZDyNCAFwZfKrCdkTl");

    if (AWUeNONwMiExKW < string("ajkjANVSNeNjAeJfvfzVppTzBkvUCMWfWUSWjeSeBCVBqaEBcerDNiSWBxTgGERBAqHzKFGYlz")) {
        for (int ABAbaB = 821195213; ABAbaB > 0; ABAbaB--) {
            WRdNgu = WRdNgu;
            cZqhI = ! WRdNgu;
        }
    }

    if (cdTRLRs == false) {
        for (int pvBkgfhaglGKLov = 1342560994; pvBkgfhaglGKLov > 0; pvBkgfhaglGKLov--) {
            hBYUPj = hBYUPj;
        }
    }

    if (ESIJDB != true) {
        for (int rfJZypHJ = 1397678300; rfJZypHJ > 0; rfJZypHJ--) {
            hBYUPj = ESIJDB;
            ESIJDB = ! cZqhI;
        }
    }

    for (int JZzDxuFVzDLwB = 197124890; JZzDxuFVzDLwB > 0; JZzDxuFVzDLwB--) {
        hBYUPj = ESIJDB;
    }

    return cdTRLRs;
}

bool ugrhqXFcPNmrBG::gGRBDPDihvd(bool MgADM, string ymGUQFQp, double YRduaVo, bool QAwffzQjMooOi, int bBwtpPjOnQcYB)
{
    string ihVzijEoYt = string("fWjrehMiDOWVeyHgOQDTXrzMdYCozbKbGczsEisrVTFHERXZoiFIAYMyPaahtGdWxwHLAyghlUBIpEYaLBVfzirUsMsewglZPWnSDQkTMUlrcSQNfNhuyohsITknCtqhqGNRRTubdAShtXBiChjhNTrwuzxTHcleVZtlOkCMmsvuwNoWosMZGwSRqljSVbiCISHauYXgXpbxYVkeVwSmxueEdwMgjczvzqrQmDetmM");
    bool XnbIWzXfs = true;
    int hswYwIFtZ = 1404716272;
    double jqhgkQY = -642624.9965025132;

    for (int KvApTSYiAmoBEdHl = 1701273323; KvApTSYiAmoBEdHl > 0; KvApTSYiAmoBEdHl--) {
        hswYwIFtZ /= bBwtpPjOnQcYB;
        QAwffzQjMooOi = MgADM;
    }

    for (int OpDLFOEUcIOTbVG = 642174138; OpDLFOEUcIOTbVG > 0; OpDLFOEUcIOTbVG--) {
        YRduaVo -= jqhgkQY;
        hswYwIFtZ = hswYwIFtZ;
    }

    for (int CgEQBlIVE = 2020068411; CgEQBlIVE > 0; CgEQBlIVE--) {
        bBwtpPjOnQcYB /= bBwtpPjOnQcYB;
        bBwtpPjOnQcYB += hswYwIFtZ;
    }

    if (QAwffzQjMooOi != true) {
        for (int XwGhkFChiDcQtBr = 2030279814; XwGhkFChiDcQtBr > 0; XwGhkFChiDcQtBr--) {
            YRduaVo -= YRduaVo;
            XnbIWzXfs = QAwffzQjMooOi;
        }
    }

    for (int nQffnCG = 584055293; nQffnCG > 0; nQffnCG--) {
        ihVzijEoYt = ymGUQFQp;
        MgADM = MgADM;
    }

    return XnbIWzXfs;
}

void ugrhqXFcPNmrBG::XbkECwoOrddKbas(int KktmC, string rgqfRXXhOqBv, double WcklBdcYiVPweWO, string QBhsnIUwhbqBfq, int euMUpcdrwbyklAQ)
{
    bool zdJkrjAV = false;
    string QgcdXksGVrqUKHf = string("lnSzyNLOpnSRcSFRmdwFCQbyPDCXn");
    int aOeURLuMDOtvez = 1482937453;
    int HxfnYZlQMEJ = -351220141;

    if (KktmC <= 1482937453) {
        for (int oDSAy = 2020785638; oDSAy > 0; oDSAy--) {
            euMUpcdrwbyklAQ += euMUpcdrwbyklAQ;
        }
    }

    for (int kHjybPmzdDB = 1197540648; kHjybPmzdDB > 0; kHjybPmzdDB--) {
        QBhsnIUwhbqBfq += QBhsnIUwhbqBfq;
        aOeURLuMDOtvez /= HxfnYZlQMEJ;
    }

    for (int cHpAmaspBxwTwxwK = 359915720; cHpAmaspBxwTwxwK > 0; cHpAmaspBxwTwxwK--) {
        continue;
    }
}

int ugrhqXFcPNmrBG::TMTJA(string uEHNccSwgPyY, int SEGVkhu, double zdbqqVenawVMW)
{
    int sfxKF = 96752087;
    int xndAu = -1626901997;
    int LqRKqxMe = -1517759872;
    double wXDgkx = -362800.7240329017;
    int rzTYe = 1943517724;

    if (uEHNccSwgPyY == string("QDOXcDOTudgbvMlsioQCaqDSGytrDBnWLBjTkNeRaxyePSXQQkfZvXTZXwSmvkIRooxJmoyASuORFvJSRNhaafmDZsRHeaByBxOTQNTQsMrpDenpzxezGzkdbEeqiUJWrzrjiKZLlaIaZpdMgrwdtSUwlEnhwQzGfvHMihSNxdQ")) {
        for (int dybitQf = 674776266; dybitQf > 0; dybitQf--) {
            LqRKqxMe = rzTYe;
            rzTYe *= LqRKqxMe;
            wXDgkx -= zdbqqVenawVMW;
            sfxKF /= SEGVkhu;
        }
    }

    if (SEGVkhu == 96752087) {
        for (int vQffRNnXXwlasg = 1139684517; vQffRNnXXwlasg > 0; vQffRNnXXwlasg--) {
            LqRKqxMe /= LqRKqxMe;
        }
    }

    if (sfxKF == -969550275) {
        for (int CXrRFbxjloRey = 49680574; CXrRFbxjloRey > 0; CXrRFbxjloRey--) {
            SEGVkhu += sfxKF;
            SEGVkhu *= SEGVkhu;
        }
    }

    if (rzTYe <= -1517759872) {
        for (int SAzdrPCkyQ = 1325671551; SAzdrPCkyQ > 0; SAzdrPCkyQ--) {
            sfxKF += sfxKF;
            SEGVkhu *= LqRKqxMe;
            rzTYe -= sfxKF;
        }
    }

    for (int caYGOxPEUhAumq = 1138100260; caYGOxPEUhAumq > 0; caYGOxPEUhAumq--) {
        continue;
    }

    return rzTYe;
}

string ugrhqXFcPNmrBG::YfQgLmQjgVLmNC(bool GpXUMnLiqqH, string HmibEYJfBZoFss, bool QeVNOoiNe, int EwYKCZILfxsae, string cIBiDP)
{
    int dhLNwvkGXddZpbxJ = -1742363553;
    double DPYXnaRIlum = 447383.26403191;
    bool ItctvMZFDnyUqQ = true;
    int BfhjDdpBfAsV = 693930300;
    double nhODRc = 951139.513754305;
    int sxSgdzDMf = -673345340;
    int VBsBfsA = 1603875287;

    if (VBsBfsA != -1742363553) {
        for (int neoUbaDX = 1164692184; neoUbaDX > 0; neoUbaDX--) {
            sxSgdzDMf *= BfhjDdpBfAsV;
        }
    }

    for (int YQDkLv = 1766186076; YQDkLv > 0; YQDkLv--) {
        dhLNwvkGXddZpbxJ *= dhLNwvkGXddZpbxJ;
        QeVNOoiNe = ItctvMZFDnyUqQ;
    }

    for (int rVFqXjxwNhKYA = 17665319; rVFqXjxwNhKYA > 0; rVFqXjxwNhKYA--) {
        continue;
    }

    return cIBiDP;
}

int ugrhqXFcPNmrBG::ziPSB(string nBgiMRELUjxzA, double VWjbTecBMlxMTjp, double TpEjrQO, string sWkZkqadWCH, double QTcKyVBhLGhj)
{
    int tAVTvDBRFNV = 1371084752;
    double oiOVTSRyXsDGqkFR = 230856.30460840202;

    if (TpEjrQO >= 411949.8371923005) {
        for (int BSYpSwhNlXVW = 530596041; BSYpSwhNlXVW > 0; BSYpSwhNlXVW--) {
            QTcKyVBhLGhj += oiOVTSRyXsDGqkFR;
        }
    }

    for (int KTwMLUzaMNOi = 2089795897; KTwMLUzaMNOi > 0; KTwMLUzaMNOi--) {
        continue;
    }

    return tAVTvDBRFNV;
}

string ugrhqXFcPNmrBG::gqKQT(bool MzGfUrdTcJA, string CSXjJqMdNTSHeKa, int IGQdDDLnotjQr, string ZMoDITXdkUI, string rtNouWDkM)
{
    bool FPpyRiToCpwm = false;
    string HFucHCxoH = string("rlsjJErzftkvfhAUFVPLovcBFOaqmesPJ");
    bool ilSeqgQdvAX = false;

    return HFucHCxoH;
}

ugrhqXFcPNmrBG::ugrhqXFcPNmrBG()
{
    this->upoSWedX(string("CNDYozOxaQjMUeQSHkSfdgFqMtU"), string("fflvDFnQKREQhWXELtmlzAVihGDowDqSCkLPPKXzeyPhsFLRkpIXiaspWcmaAPWrmFRvirxMIMBvGQQielJbrCgIuehjWbSObshiJsZWsckTrcHtdYEHoAMLtNblAupfEGvncbVIeVwcqEwBBpxZTuFqentDJyomUlmrQdUsabDkPmNHkAtTdpYnBsqqpZToebnbtsXHwUfYZbeooFKLOyYFzsyJNwUsoajb"));
    this->mbqid(string("DIJPMzZAVRSejjwEzaRTNFDsirBummbUWUyIiTIxidnXEEThXnTMgnxlcGNuSsuGwofjmlwALggsmOjvCgDanVRBxQtqmrgOiLmSAIQlYYcVkpJujXLMqgKluqAdgkEoPpIGIPlaGYYvdpDVKKnCuMxdhNIhCIcjdHkKMbPaiQNNkPhSpLrXryfgjVEHAgOjkqxAbv"), 805002.9152112701, false, string("SrjbIcmtQootuFXnfqYkjdYyvEOrBzFyfxvZHpxYQaSKPMAvxMJPOMzsXHV"), -297011.7397220349);
    this->ktidGcgX();
    this->mXKXzfQwDQmX(1117364139, string("PaEnoptDwLqpPielKzPQqBcwonFwzVhrRaNDWauuHYnRItfgEHKvOPuczqscpQvKQrvYQrqtGkWRuzKVqizDVaIpHbfcxABvPWlYEpdoKpVCWUTzGHBNbqatJru"), false, true, -501264921);
    this->wzHyInC(1256013276);
    this->CUycrLHWOzED(string("zABGeIVifuAUmMMHdaGPcrfvoaczODTfQmPaciZjKZOrsHLFQvYVZyRLPxUoAjNUljkmRmCyOvrFqbRUYMvjaPNovUyDUnjuigRAwwlxGVswLWeDxmDnNFFheaKNyNiEmFfLjhrhQbIrqkGlCslOpcXWeBNRFfQoOLCAZIgfeAimInmhqWNLysAsXvePlZfVKoywWmCdxTUoENkrtdfZQuGOAivEHpuSErjtPOLUjlisL"));
    this->NgOOl(-834526.2489920396, 781936.7221053712, string("zEUTuNXEuYYXsZJoqkvlBTXzGsshwMnNeUZSoSswcmVQKTITelwmdXfkNrhIdUvBSmsmAJHWkdeTHYcOhlvKgjYxSvibegkquOIgJXLyudaqnjMCCcGZuHTJPpHjVmGgWzYqFXtfNjGGfLbjaNaErntgyOOORuIf"));
    this->MMvLadj(false, false, string("IDARfWawtxaVzPvtHmusxXnYAbTSHFwRFvDqahGzTcqddJkhtQSoglrwUWCqhIfcCqaPeVEh"), 943578414);
    this->gaYJIx(-404180.317413992, false, false, string("kMltSpQIdbzeLwqFhjdOHCbjxOacJaUGzZlTBfAulsgJhXGEiwKdypUQgZkPCYhGghlucwhpXUbRWSfUmULlTyLZmmJEleafRuSuGzKtfPLYxKudlKQgOXJtsLgOlyyyjhwWSfCQErmbqb"));
    this->UpLTIxNKTE(true, 187222.6766417213, string("ifYIfzjCTxDpkrrDpmAnpGqbMyAGxFubcuaovCbihqfybmaMEXGtbcbeiANNHuhNykiDTLNhAxXWIhPbuAlxqscVAqUupdLwTkPrSzdNPPFljurfMfVGiDQDflhkuWySWzkOKgJvgercTFVRLLlOahsirFvMEKWutoeAijWmJAqmYtFmvuNjZPINduGmXmdfEGzQPkzqwpdauOP"), 786860.2099883363);
    this->UqONpMxRFYrij(true, 740122183, -660266419);
    this->CrxhcZlPK(true, false);
    this->gGRBDPDihvd(true, string("tRLmulGSCxZqHrpzaWKTeGJaYLXUcsAANCHbzpNdQOABHoJYRZshBzRMnubmnoHEABLJtkEliWFPymIKOuYDIjKqAFLubKK"), 213877.08648735326, false, 746485559);
    this->XbkECwoOrddKbas(2112399145, string("TzKAuTTcBhJXGqCuoQLfnAbgeiLYDtnAzaDDeUSunZyhczoHeAJtZizMuXOkdEqbdjNiJojpxeAoKcgoeKrNrPvFXPDgXsDOUNwbDdqolouxEGMpDWoLjERURqnBBNeqOyisWzcCwvYNOweGpOCGyzKdpHobCrwpDQLjpBttGwpJQTeISwcYpKTEJZrylnFDcGQWMRqEIGRsYXIbEHwjYqCrOrjwrBsqGlXQLwBTqDyDZVHXCnpaTtkhfMhXlEe"), 520964.8663520451, string("RtpqywcgXYHroAyzmxtgxuhWvqAbnfcqlzfpJERKdaedevervLnxjphcYVqaEjhXZzKvHHnSriMAJTeGhAlEFDvXHnhuIpFnjHWFVzjaUsJqmSEANHHbKRvTTqgoVPbqBwBHViRjmxTgGJODrAPeTnxkEbicFkfozPnadXXUIRvUkWGHozMLnHPbNiBTJzyBE"), -646425899);
    this->TMTJA(string("QDOXcDOTudgbvMlsioQCaqDSGytrDBnWLBjTkNeRaxyePSXQQkfZvXTZXwSmvkIRooxJmoyASuORFvJSRNhaafmDZsRHeaByBxOTQNTQsMrpDenpzxezGzkdbEeqiUJWrzrjiKZLlaIaZpdMgrwdtSUwlEnhwQzGfvHMihSNxdQ"), -969550275, -533224.2334421799);
    this->YfQgLmQjgVLmNC(true, string("HsBfpZQgneGhQziuNobgbLPznfUrnOynMOgFuYZOpMGRVsudIgYBlLrPpPeVhgQPWISnFqWdJQvgLPVxTgx"), false, -705981115, string("fWVRdaTNkYcYXzGwToKEolRHnKrHOqvLgndHiVJhISzlkZLXKfgNHoyatRNRCugImkyfuOJetFSFnigAriSLHjkcDXgTTlmHXfRFKXAXiHfgbbaVfcHFIFlHpEdgxOakpWXumImwTHSsDFnsigFTQhfaBoZKMzhAIkrRSrGWBxxiIWLnImqVUoKoeXX"));
    this->ziPSB(string("IUOBfqPYuCcxWWPvGnTfDfWwMZNYnGtvdgtaHXPBRrBFAIcXpPWrVVZdvmilQwVpITltbQdQrPeuOUnMHCqcgWtdHKBakstUsOXAGe"), -440847.2994497779, -311530.2460268115, string("RraCHPyLzvOJ"), 411949.8371923005);
    this->gqKQT(true, string("fvwBTYtadIADCeQjkBewVHiYPSsjLkPOQKqNQVTdYZnuiyeqAFZZWAUsPxIGARMPEvNRvvwlVEbLzgDVwHNbkjHFJAyyYRIYyrgtyUQspZfbHmUSBwlonXKUQaureeqvDcIoPMQglnsOkzEkcdCXbm"), -1980580877, string("qbQrCmC"), string("ztQCvSRUhONfUMbaMKRwQBTpvkaUnTMHAIHTsCMkjFYGgSzpUNbbTAzoICyGDhkigqcpPJPiyEXvXFSnlCpshnlYEmYwFTpKvMFYZflBgFzAAAsnDmqbvfRYBUioCeyeaAmytzsvBQoKDSPkeTrFuKnEmd"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XpiBGewB
{
public:
    double XkVAzYzM;
    bool JQHUhVSQDPX;
    double heEDdpEko;
    bool zMOuuXQnDCxLnDjT;

    XpiBGewB();
    string JStSMq(double tCEHuNk, double nhRqPqzWqlAsBKh, bool GLBWxtky);
    double TPuUSFaKf(int BvSwnp, string bdNtRVFvCz);
    int jIaNgMDQWqUdT(string SqlEEV, double swtMSAnBqAUaCbC);
    int atvFWDByMMWu(bool QkeurzUCLvTrOL, bool MbjPcmyNGMLr, int zsqmcFUwDtAd, double jnjFjtpxY);
    void WzNqRRE(int ngdBxv, bool XPsQwQPmfpJV);
protected:
    bool tsXRM;
    bool BFFWyxDJOXa;
    double TQYIrzXooVJJuyq;

    string GtSBz(string NgJZWdBbJmNSVJJV, bool sBiuKcJEgbUXTEDq);
    int YhQwAfvQC(int WVGuXgbdOXo, bool NGRlAV, bool UZIPhpxci);
    int dcHOeuvRHevUyyUo(bool WTfCVSUhv);
    int BbrsvqootlC(double KepsSRi, int bPhxxakfcwKFaEwn, double qAPjGQgay, int GVhNjZVuXWd);
private:
    int ZSxcICSNvTzAETF;
    double ENsjTHNNCE;
    string VsAhrRIXvZLbDV;
    int IfulgOhmNbIeFQ;

    string vHJVjlEOOzy();
    int MvPyLuyxNMP(double JZwnzrHsg, bool XPKNw, int BqyKyX);
    double bXHEVLpgxnAJWZ(double hBRCpcDPGb, double ZKIMJYAGWaQBXrc, bool rLIjrTPxxDaV, double CVoRNlUqlQMt, bool DhWfANeZcYPgJeL);
    int WRTJGTQ(string IErqwOj, bool xoejqF);
    void jYIXRhQi();
    string ZQHRj(int flXjPKeUyFQaKNgl, bool uIpeLmPvuDU, int xVvTkwpVobdvYJH, string XVFAx);
    int hlYqJzCwuDvY(bool hxlyCiahjKH, bool FzUIgHayqHqNTA);
};

string XpiBGewB::JStSMq(double tCEHuNk, double nhRqPqzWqlAsBKh, bool GLBWxtky)
{
    bool CEljVoz = true;
    double hqYcXENDilLYTr = -170694.91252452874;
    double jWjkW = 363300.6291429908;

    if (hqYcXENDilLYTr == -889020.3218033349) {
        for (int dbMLiNneq = 1322088284; dbMLiNneq > 0; dbMLiNneq--) {
            GLBWxtky = GLBWxtky;
            hqYcXENDilLYTr *= nhRqPqzWqlAsBKh;
        }
    }

    for (int GjCWZyvlXVMnP = 623418898; GjCWZyvlXVMnP > 0; GjCWZyvlXVMnP--) {
        jWjkW = tCEHuNk;
        GLBWxtky = GLBWxtky;
        hqYcXENDilLYTr -= nhRqPqzWqlAsBKh;
        jWjkW -= nhRqPqzWqlAsBKh;
        jWjkW += hqYcXENDilLYTr;
        nhRqPqzWqlAsBKh = tCEHuNk;
        CEljVoz = GLBWxtky;
    }

    if (nhRqPqzWqlAsBKh > -170694.91252452874) {
        for (int JovhKoyL = 2103964951; JovhKoyL > 0; JovhKoyL--) {
            nhRqPqzWqlAsBKh = tCEHuNk;
            tCEHuNk += nhRqPqzWqlAsBKh;
            jWjkW = jWjkW;
            nhRqPqzWqlAsBKh /= hqYcXENDilLYTr;
        }
    }

    if (jWjkW == -170694.91252452874) {
        for (int fzywnTpXgAjky = 1883901228; fzywnTpXgAjky > 0; fzywnTpXgAjky--) {
            tCEHuNk += hqYcXENDilLYTr;
            GLBWxtky = GLBWxtky;
            tCEHuNk *= nhRqPqzWqlAsBKh;
        }
    }

    for (int TiyUNVXiiLF = 655886179; TiyUNVXiiLF > 0; TiyUNVXiiLF--) {
        tCEHuNk /= tCEHuNk;
        nhRqPqzWqlAsBKh -= nhRqPqzWqlAsBKh;
        tCEHuNk *= nhRqPqzWqlAsBKh;
        jWjkW *= jWjkW;
    }

    for (int RZwsoT = 814236775; RZwsoT > 0; RZwsoT--) {
        continue;
    }

    return string("bIVZAsgTEnifuLYbtnGQwsaaegTrsYtDTGokndyiMcnWVkGFBmqACsvWGWQHbqbHCSUQhfrNDFqSWJFOGGfcxbKWWjyAhVfqQonMfWmwtqXtifKarOyQelJLkPPwcmZXEQPhKSHtMewmDKLKUkUnKYtFRQMCwftfmYfWTmdWBNYfYKQOEYXBpcTgJzvmUTrcBTjZzQSljfHbY");
}

double XpiBGewB::TPuUSFaKf(int BvSwnp, string bdNtRVFvCz)
{
    string IZmLUsbeyj = string("ZOoXdGzZrsYxktonYBkztOywXWdFgmQaKEYuyUPnjLxjkBkIZLCATyVCKHPsaDGQiPynawnEVUaiojHzGDEwCJvVlZJzaStosCrpoRZSlSSfnKgONCaEMRpooZqgbdaFtsGVoRtjPqKJOhFPdtIzoogyFzqZytUFLxFlpFrTLnKcbFvEuTbKOEwMriRxbbtgbcfFFOUBNRtkZB");
    string WtMTr = string("VREyEHoeliZmBPhPIvqfCAPEPsFrwRNvfvoAxqYofTCBsYJgxEPPEAMAKeoktziygofmlMSGgtNCrzsNttIlVtaClDkzYkFGsPOjqygKmJcFOJgpEGwsEqCHHHVEnJEhKPGRsiWWSWJuMQnHCwgSiQNjUIIfPiMBwZQwfpVhdYCbYDEhmktfMApKntrzZiNzgUwgtOQKfLdZlox");
    string WgmNW = string("VgvjJemIWkLApvCCdPMPLKeLiuhxppAHIFmMpWKRdwhGNXdqYLmobmxvcLfVnDVLiPbmKlOltjdBvdOTORQcgWndFnoTlwpyHtzjEuYIUVcLMxygMqFidmREiEyTUrhwR");
    double gSLTREx = 964924.1354923486;
    double rxnvYQqTLuNbsBm = -114252.27895004995;
    bool tEZyMtAOWNJ = true;

    return rxnvYQqTLuNbsBm;
}

int XpiBGewB::jIaNgMDQWqUdT(string SqlEEV, double swtMSAnBqAUaCbC)
{
    string mvsZXJjhhwPa = string("bHswLQUXzLQAZtsOgmHgdKUJScmwNzVgBfsSPZYDNiLYvvEBNDpunYNsqOvZxzDCUyGcGBFnzmaisaAneOmzKwalGQbobjkHfzRYQqQFXNZkIAymEwlOSGkaKCkVyrKHJRsWLQPoEPUBzaFhwtnUguXKJzQAqIkyCjcWSwWcKkCSFFDtpC");
    string gCsZqAnEnICtd = string("kqhbsOMhpIntFIcwQnZiWUJgLkEtnzTswOYEBOLsWiZwoHAeeefaSxGzcrKSkcDFRHRJvSNbrugYbEgyUFFyiuokLjlYTUzsHQIkXyPNSuqqXxaklZLJuYKGBbifmsQNTPSFLYMYsJIdkxbQqZNQxEVJtzcZ");
    double SxYmCky = -52713.64784005558;
    double WjMhXJHTN = -505444.2612074235;
    string KHkblPVtPdUaClA = string("uctcLmnOEjNVIRaeyeqxDEoZzHFVeFaOgbGIanKuqYCrPmtSjeRNoOYnCdYmJholRWWYDQuzAkiTDCcaAWEHTHUFOmAtPnJSxtynkGwfprkKaQrQBgWvAfHvReaXaVFwSxQvBstFBmTFNrDaUijbMhaSWVmaWGfuzAEbetMZqCEoANuaEeLMwCobhxciBIzGdETOSbAVMMhdgpWjixhnZjwnhZNGZGjKKmCJajhCoXOeI");
    string TZbVvh = string("TFhzKnJUJIrNDYSTJFDiCsFT");
    bool bfnMpXUo = false;
    bool zFwJOoLvLVUgrTp = true;
    bool FtFkwqYvZbepTkh = false;

    if (TZbVvh < string("TtJJbXeOUUWHbnYnzvvClipUwqUamJdocqaenHkoSSawrMAPBShGTIoBfmzLZBfAKDCDiXFjBargEbzjZQXuurdbcSxPmhAaFJWuViiDOlYZieKHnKBexLgMjVeFMXkAvoQqbyKdqlgTsWCLuzVFMLMVZWIWqAfyyXjWZRWMbRQscnHYwJmgIqzFSfkIJXVRzjcHRBDNiDKIclKClhCoyeUDXgZnosFlbTFjebGcYCgMJqBUc")) {
        for (int oXiDOq = 87381333; oXiDOq > 0; oXiDOq--) {
            continue;
        }
    }

    for (int ZEbKRTJ = 18165178; ZEbKRTJ > 0; ZEbKRTJ--) {
        mvsZXJjhhwPa += TZbVvh;
        WjMhXJHTN += WjMhXJHTN;
        swtMSAnBqAUaCbC *= swtMSAnBqAUaCbC;
    }

    for (int hokxfgApIzYvsd = 2037316315; hokxfgApIzYvsd > 0; hokxfgApIzYvsd--) {
        KHkblPVtPdUaClA = TZbVvh;
        gCsZqAnEnICtd += TZbVvh;
        gCsZqAnEnICtd += KHkblPVtPdUaClA;
        mvsZXJjhhwPa = SqlEEV;
    }

    if (FtFkwqYvZbepTkh == false) {
        for (int TEqLEzNSMPPQoIIU = 1881707109; TEqLEzNSMPPQoIIU > 0; TEqLEzNSMPPQoIIU--) {
            WjMhXJHTN *= WjMhXJHTN;
            TZbVvh = SqlEEV;
        }
    }

    if (KHkblPVtPdUaClA == string("TtJJbXeOUUWHbnYnzvvClipUwqUamJdocqaenHkoSSawrMAPBShGTIoBfmzLZBfAKDCDiXFjBargEbzjZQXuurdbcSxPmhAaFJWuViiDOlYZieKHnKBexLgMjVeFMXkAvoQqbyKdqlgTsWCLuzVFMLMVZWIWqAfyyXjWZRWMbRQscnHYwJmgIqzFSfkIJXVRzjcHRBDNiDKIclKClhCoyeUDXgZnosFlbTFjebGcYCgMJqBUc")) {
        for (int QpsFVCgwJLGAaVao = 1736476917; QpsFVCgwJLGAaVao > 0; QpsFVCgwJLGAaVao--) {
            continue;
        }
    }

    if (gCsZqAnEnICtd <= string("bHswLQUXzLQAZtsOgmHgdKUJScmwNzVgBfsSPZYDNiLYvvEBNDpunYNsqOvZxzDCUyGcGBFnzmaisaAneOmzKwalGQbobjkHfzRYQqQFXNZkIAymEwlOSGkaKCkVyrKHJRsWLQPoEPUBzaFhwtnUguXKJzQAqIkyCjcWSwWcKkCSFFDtpC")) {
        for (int gbxhJKmF = 1894561030; gbxhJKmF > 0; gbxhJKmF--) {
            FtFkwqYvZbepTkh = zFwJOoLvLVUgrTp;
        }
    }

    return -2138640142;
}

int XpiBGewB::atvFWDByMMWu(bool QkeurzUCLvTrOL, bool MbjPcmyNGMLr, int zsqmcFUwDtAd, double jnjFjtpxY)
{
    string tROAqMdkdTcH = string("JYEFIzgRILftQUGMHIrVYAWMFgWAhPeUREeRlkttjGaOOMrkDBOZiNzhsDRGiiOulACkisINjbiyoFATwUUtsDhAJxffhpSnFxvxqWGzkwFNSkDCIcrVSKrW");
    bool rcoyLLrpS = true;
    string AGHqlC = string("hIsmDKpGkOIeiQAmTcIHPywkGazNnAbryPfWkpBQfge");
    int UBxIjhqpnZjN = -704226934;
    double mnaiWEZhTmDh = 466564.69825279573;
    string BbKnPUnHROKbV = string("HdJaNqaVlDNuUBayWFBZkxGCGnvIjSVEwgldhnYJjDtjvJEQUrkHgqYAQEXXhsdfUqRuTkPdphcQCXKOocMnnQvIinLYlUuLLnjNekjcZorfPbKZJncWyZjoMXuBzBQkBkzcfTrVhXdmEFMVbWLfUhfIpOxFJbAtWUOS");

    for (int rsoXS = 883526974; rsoXS > 0; rsoXS--) {
        tROAqMdkdTcH += tROAqMdkdTcH;
    }

    for (int Wnpur = 1390927458; Wnpur > 0; Wnpur--) {
        AGHqlC = AGHqlC;
    }

    for (int XGyjXRlKmS = 279681264; XGyjXRlKmS > 0; XGyjXRlKmS--) {
        tROAqMdkdTcH = BbKnPUnHROKbV;
    }

    for (int tBjSUqyNrvojOFN = 1397835435; tBjSUqyNrvojOFN > 0; tBjSUqyNrvojOFN--) {
        zsqmcFUwDtAd += UBxIjhqpnZjN;
        rcoyLLrpS = ! QkeurzUCLvTrOL;
    }

    return UBxIjhqpnZjN;
}

void XpiBGewB::WzNqRRE(int ngdBxv, bool XPsQwQPmfpJV)
{
    double lQyNdfNpopMQS = 43932.34314664824;
    int AgLmEPeqHXNes = -222151578;
    double AOtRIURakEl = 872560.5697468661;
    bool RSdJRVVuUePHQ = true;
    int UEuJLjhzeHU = -1881949607;
    bool sYDadzkrN = false;
    string RZTpov = string("wqoIucdqShIrncjIsvyzKMYydQjtqPZlKuZOHtUzIpLtSstcfSoShAgoUqfEHkoQjMXLUv");
    string oTOoYRFm = string("wUmKjJpKJeccTOsmWJqWqAGtkvKzpVOeDpBDgFJpIjllkSrDyrWMjNcSkEpvekZFznpIHvUFEwJkcdpxpXtPfScBKcUZOsyUZzpxDlpjwNlYTFfmqXCNVWCBcGWDrjVeEpqexkLCUiYYJfTAMVTzORUibBfFjPoghEqYOaMvlzplIjimgfhjlVWYVigpYizFx");
}

string XpiBGewB::GtSBz(string NgJZWdBbJmNSVJJV, bool sBiuKcJEgbUXTEDq)
{
    bool LjAeAU = true;
    string yACDLWx = string("CjyPvqdaFugQGFZhbFCeVPOgNBqGMBkFPhjcryfGMcTYGwOakFWxMEUUNmBfITliCxOcRYwDKzUznveGfSkesISYOxqErFYVVBBZaLvcEpgJNrbPZCNvNFBzeAxYGCWjsvMYwLAkzoMiPRfPgPFZLGCPC");
    bool jVFoknR = true;
    bool BGcgxRgzD = false;
    double HkfEfnI = 148551.19063070585;
    int hTpJJLwK = -117102612;

    if (BGcgxRgzD == true) {
        for (int TmQItzoqWQcrVF = 1210297798; TmQItzoqWQcrVF > 0; TmQItzoqWQcrVF--) {
            jVFoknR = ! jVFoknR;
        }
    }

    for (int BbhmULiQySQKq = 381893039; BbhmULiQySQKq > 0; BbhmULiQySQKq--) {
        jVFoknR = sBiuKcJEgbUXTEDq;
        jVFoknR = LjAeAU;
    }

    for (int egzCv = 310346954; egzCv > 0; egzCv--) {
        HkfEfnI = HkfEfnI;
        sBiuKcJEgbUXTEDq = LjAeAU;
        jVFoknR = BGcgxRgzD;
    }

    for (int EqWpoSkDDCAGJz = 1344798880; EqWpoSkDDCAGJz > 0; EqWpoSkDDCAGJz--) {
        sBiuKcJEgbUXTEDq = BGcgxRgzD;
        LjAeAU = ! BGcgxRgzD;
    }

    return yACDLWx;
}

int XpiBGewB::YhQwAfvQC(int WVGuXgbdOXo, bool NGRlAV, bool UZIPhpxci)
{
    string pIqUXhpIX = string("JSnIpDPeEJwoEdcfMXsuqtGEbdyiwpheAaIRUBvMVRkGNtbuTICqGurHSqJrBCsAnuylIJkRHQEcBoILAjUEslcEwLFENDYjvzw");
    int nernwLaK = 1588827453;
    double FtMIEZguYqX = -649560.3059077405;
    int eCODj = 885096728;
    string QdBguKeGRayYTU = string("hyrkTomJcPoNOjWzBGyaBbMryCnUIaxaeLPKonSQcpfmIQck");
    string huffsQCDbi = string("YXRBBCubxhwMAQQgPTeUddoutLtGUmbAhScUUPnVPKPbKfPOvEHCTPateoToRKKGNjHiphYLxeLpUdivCRaJHfnFCTNAUCWIEGvJoWwppVSeszwrntcMHOWjZREVfPolcvVCYQPMEaLWBIrTfORiVaUnzDDdwMiaLAxaZCGNgZCLYinGgSPIBtyZSzEBbHuIdM");
    int ifVTbrrI = -662829611;
    bool FyTdVqQJPVoX = true;
    int cSmThdXKnhy = 1969970989;

    for (int ngRDQvUj = 264179861; ngRDQvUj > 0; ngRDQvUj--) {
        cSmThdXKnhy += ifVTbrrI;
    }

    return cSmThdXKnhy;
}

int XpiBGewB::dcHOeuvRHevUyyUo(bool WTfCVSUhv)
{
    double AqkzeNuTIHZ = -508172.180016784;
    double tNnVdScpRaSQPZly = -211638.80939123707;
    string PSNejQgNLYtRmU = string("AGSShFxtuqYNhLCCpiHmeXgiPjyVCilqIuQsyFCZUJkxxfuBdfCYbddesRCOJJsCPxRVMUdgnxzBroprRWUFNvlafsrGCFPvhfCcMuVpYgGCnrryMPLpzRUbnOlwPvRHPTYdftDrwBIbcqeGzGLwLsmpOtXgdBxuIizJPK");
    int ZqvGxSTo = 413541463;

    for (int IQIioZfoMMtqjjoo = 31731967; IQIioZfoMMtqjjoo > 0; IQIioZfoMMtqjjoo--) {
        continue;
    }

    for (int MeINpIAfx = 1099460938; MeINpIAfx > 0; MeINpIAfx--) {
        PSNejQgNLYtRmU += PSNejQgNLYtRmU;
        tNnVdScpRaSQPZly *= AqkzeNuTIHZ;
        AqkzeNuTIHZ = tNnVdScpRaSQPZly;
        ZqvGxSTo /= ZqvGxSTo;
    }

    for (int lMlXUGqXLQCb = 832040429; lMlXUGqXLQCb > 0; lMlXUGqXLQCb--) {
        AqkzeNuTIHZ *= tNnVdScpRaSQPZly;
    }

    for (int NVcayHuXX = 833192618; NVcayHuXX > 0; NVcayHuXX--) {
        PSNejQgNLYtRmU = PSNejQgNLYtRmU;
        ZqvGxSTo = ZqvGxSTo;
        AqkzeNuTIHZ -= AqkzeNuTIHZ;
    }

    return ZqvGxSTo;
}

int XpiBGewB::BbrsvqootlC(double KepsSRi, int bPhxxakfcwKFaEwn, double qAPjGQgay, int GVhNjZVuXWd)
{
    string nbSQhar = string("ZRGZWxIlVQbqHpriQEpzAwgferYKSOaEaSEGNINmEjSxQPUnNSRUFMZvurDvPoFmyyDWbXroRTssQQgzXDshmqaPTIbnbnWzxiftInSGAlWYFnJyymCcClWlYFxRrrKRTSFvfbTlJEaxqRnBKrPzNHainwEKnHgsFarptoaaUEqeQiTVPeiCboBrHZLWgLxMcsHoSLhHCPxghrsZFVLMSMfQbICskNXjCmYQvvQZ");
    double FlaKPcPieMKzmB = 384207.13708542666;
    double iBveywOemYGWB = -611795.1894627961;

    for (int oqcluKEBVU = 1346949012; oqcluKEBVU > 0; oqcluKEBVU--) {
        continue;
    }

    for (int eseqgBmUnStyocy = 548030805; eseqgBmUnStyocy > 0; eseqgBmUnStyocy--) {
        bPhxxakfcwKFaEwn /= bPhxxakfcwKFaEwn;
        FlaKPcPieMKzmB -= FlaKPcPieMKzmB;
        iBveywOemYGWB /= qAPjGQgay;
        iBveywOemYGWB *= iBveywOemYGWB;
        qAPjGQgay += qAPjGQgay;
    }

    for (int kHfPFvtlyjFFnCx = 962672207; kHfPFvtlyjFFnCx > 0; kHfPFvtlyjFFnCx--) {
        bPhxxakfcwKFaEwn -= bPhxxakfcwKFaEwn;
        GVhNjZVuXWd -= GVhNjZVuXWd;
    }

    if (qAPjGQgay == 887762.1257438718) {
        for (int YBtCxaMAp = 1670473375; YBtCxaMAp > 0; YBtCxaMAp--) {
            iBveywOemYGWB -= FlaKPcPieMKzmB;
            FlaKPcPieMKzmB -= FlaKPcPieMKzmB;
            KepsSRi = qAPjGQgay;
        }
    }

    for (int JTgYpuyaea = 577482310; JTgYpuyaea > 0; JTgYpuyaea--) {
        GVhNjZVuXWd *= bPhxxakfcwKFaEwn;
    }

    return GVhNjZVuXWd;
}

string XpiBGewB::vHJVjlEOOzy()
{
    double EOgwkjgz = 426924.95610343124;
    int XNPREkPRVtxsezGi = 1800306455;
    int cZxPzGibKcOh = 1210072800;
    int pwBcnH = 1105936093;
    string etBAlGMGmSl = string("fsoymYOFczpiksPhwSzBOmPAWiDIWddKpQNbOGWYaBDM");
    double jJsZrlGxVJpJXo = 520138.87971348467;
    int xNlWPKSvcYysF = -1727346332;
    string bRETCBzeOeHUfccB = string("oNHIajqkefklIlVYWhaGTifpyZXxQtMODQjTCVQxPItPRFbDEWJKqTHWVfHSdwYNowMMFvonscDXDgwFGwjkGevgkEeqUQeayXrDAROmzKPqZZuoDKzqHaSKMrjTWWUmNoMtemsEqoeAyAslktLOYLoyOybiQGLbZLDQXlxlzpqwxejtizLaMyitKcxbFUBPlUjaLwLccxpJQJAIEVgfAfkRsxvzAoHfHDxXZSsB");
    double EJZrScscY = -1042740.2453136665;

    if (etBAlGMGmSl <= string("fsoymYOFczpiksPhwSzBOmPAWiDIWddKpQNbOGWYaBDM")) {
        for (int twKvHt = 616432664; twKvHt > 0; twKvHt--) {
            XNPREkPRVtxsezGi -= XNPREkPRVtxsezGi;
        }
    }

    return bRETCBzeOeHUfccB;
}

int XpiBGewB::MvPyLuyxNMP(double JZwnzrHsg, bool XPKNw, int BqyKyX)
{
    string ZLwYxvCLDv = string("saxWmJwybrSINeGcEgNvYCPPLdNjRtkoQMHBAIUxszxyrDMVbUVaKmZkacocWBUPudQeZOgjIlWDxeSnlNfSUPdGOuRkNaeAKJsGqOeTnguEkbPcgenUCyxOLzUvsvgjrSbFVRnnfVvrPdUrFYvFzbyvbWESeZOJIIXilvJghYJlQNMynoMVcJIqMpofuMvFveNhwgKBsPuIIaSFAbqdch");
    string dCKWTNbvbewPYRK = string("geJceAeIxQUnNeXjVThYUzJVGPXTDxePAywYuJMqKSJtiBoqtJCGhcydaXGdfozmBrpoEvAsOimUooonPLflXEJYccVoaENSZXpOCRBovMBvJvoeLwksgnbMTPMKrRhJbBKgxliyMgHoyrrDfIwTiDOmlnTYJliantpVFHwkvMRMgSVXHgyvfMsiJnIcoTUoEJfrZooqEDeHNgEZivWlBYZWVxMLutllOZhInGYIimnIWF");
    double VdeQzkFcatObXz = 541124.6809958329;
    string uiQuiHsoghw = string("nHASuAcpbvuWRhrrqOQrCnWsezRwXSNVbNkfSpdliYYplbpPbWMZZCweXmrhICklthDposHwbTpeptIKFqNpzRLKSsoZAVaWdwSZeWfIbMQuThcTcVnNkCLZddWTMIGfeCIKlzTEVFJkuLlrXnFnAGroIPNNnuqUnHoRMTjmkiHaDqguvzip");
    bool RodquYPijJuTEUMh = false;

    for (int mGGoNMGdbr = 57079163; mGGoNMGdbr > 0; mGGoNMGdbr--) {
        continue;
    }

    for (int vDJaFTCEtZe = 664702076; vDJaFTCEtZe > 0; vDJaFTCEtZe--) {
        ZLwYxvCLDv = ZLwYxvCLDv;
        JZwnzrHsg -= VdeQzkFcatObXz;
    }

    for (int qUfxiTQMoCOMgL = 331504901; qUfxiTQMoCOMgL > 0; qUfxiTQMoCOMgL--) {
        JZwnzrHsg *= JZwnzrHsg;
    }

    for (int MQgzfGVWKfgKW = 2145975651; MQgzfGVWKfgKW > 0; MQgzfGVWKfgKW--) {
        BqyKyX -= BqyKyX;
        XPKNw = RodquYPijJuTEUMh;
        dCKWTNbvbewPYRK += ZLwYxvCLDv;
        JZwnzrHsg += VdeQzkFcatObXz;
    }

    for (int ZECpYgsqfUVAWumG = 1628234619; ZECpYgsqfUVAWumG > 0; ZECpYgsqfUVAWumG--) {
        XPKNw = RodquYPijJuTEUMh;
        XPKNw = XPKNw;
        JZwnzrHsg *= JZwnzrHsg;
    }

    return BqyKyX;
}

double XpiBGewB::bXHEVLpgxnAJWZ(double hBRCpcDPGb, double ZKIMJYAGWaQBXrc, bool rLIjrTPxxDaV, double CVoRNlUqlQMt, bool DhWfANeZcYPgJeL)
{
    int tHtZdAr = -511305803;
    string ptinDeeTQB = string("DXosZbnzmBvkMfGBTNTFVmEcxCdRepgRsjNxCsJOVcDoHLCTjLXQgteJfKTsjUXGrqXdTmrHAmaUDywvRkvStRELTjWp");
    double RRdSAQmjVj = -846855.4043743454;
    int lPJpQXRtBvcWTo = 384299396;
    int kyCGNmY = 31781768;
    bool QftjhCWLg = true;
    string GZoWjazqSMTxh = string("oSOJOkhbMToADSZcUhYBShURaaJNyNUL");

    for (int efOsVtptvbbInq = 1259482155; efOsVtptvbbInq > 0; efOsVtptvbbInq--) {
        GZoWjazqSMTxh = ptinDeeTQB;
        DhWfANeZcYPgJeL = rLIjrTPxxDaV;
    }

    for (int BUGSPuzfi = 1154837390; BUGSPuzfi > 0; BUGSPuzfi--) {
        continue;
    }

    if (CVoRNlUqlQMt >= 870045.0642981671) {
        for (int GvqMxNZvhVmSnL = 1548836818; GvqMxNZvhVmSnL > 0; GvqMxNZvhVmSnL--) {
            continue;
        }
    }

    return RRdSAQmjVj;
}

int XpiBGewB::WRTJGTQ(string IErqwOj, bool xoejqF)
{
    bool RvDBwTloiwqlikB = true;
    double mDRsqJexF = 906100.1399866105;
    bool AbEHvadsBSCR = false;
    string zIsZYOV = string("uVpOrnHGzsfwBtlcfQHCKNFqaxGczvamffIvfrxAJsakMczvuFGjlUmxKpmWgqKwRhsRhxTWvyZldAkNUPbKpmPSqStmbIniCRAJdlBwcCxIWQS");

    if (xoejqF == false) {
        for (int rDjFhNZsrGLLQw = 1153578534; rDjFhNZsrGLLQw > 0; rDjFhNZsrGLLQw--) {
            mDRsqJexF *= mDRsqJexF;
            zIsZYOV = zIsZYOV;
            xoejqF = ! RvDBwTloiwqlikB;
        }
    }

    if (RvDBwTloiwqlikB != true) {
        for (int TfOms = 461918399; TfOms > 0; TfOms--) {
            zIsZYOV += IErqwOj;
        }
    }

    for (int jGAXSaXe = 945254127; jGAXSaXe > 0; jGAXSaXe--) {
        zIsZYOV = IErqwOj;
        AbEHvadsBSCR = RvDBwTloiwqlikB;
        zIsZYOV = IErqwOj;
    }

    if (xoejqF == false) {
        for (int qvYktwOEdaGpKAVx = 581962143; qvYktwOEdaGpKAVx > 0; qvYktwOEdaGpKAVx--) {
            AbEHvadsBSCR = xoejqF;
            RvDBwTloiwqlikB = ! xoejqF;
            AbEHvadsBSCR = ! xoejqF;
        }
    }

    return 145827215;
}

void XpiBGewB::jYIXRhQi()
{
    int quhDUj = 1709742975;
    bool TwSAPNL = false;
    double BTwiJdNaDY = -64831.273378633945;
    int RPZzPzGTqKghZY = 521494785;
}

string XpiBGewB::ZQHRj(int flXjPKeUyFQaKNgl, bool uIpeLmPvuDU, int xVvTkwpVobdvYJH, string XVFAx)
{
    double gdMCUJTviDv = 738488.7457675971;
    double YAcJWD = 476823.0503176708;
    double xcIIJPcsBXmBUT = 835462.774203983;
    bool JnPOsEMldzDOFDdQ = true;
    string GIBbnP = string("XGZNlEOCZfotUdQIDLvSEwJItizZiCfegMnKiYRrsBfsZeyjoImVSSicFPthnsgCMnVgrFWXiHWwBzJOMHAvfWFVcIISchdW");
    double tpTluvOxVyeBd = 585279.7577965064;
    bool MJnQMATZMssl = false;
    int KFWvJurev = -1402850879;
    bool huvApEneAKD = false;

    for (int FFzyGQFEqVMGN = 366503190; FFzyGQFEqVMGN > 0; FFzyGQFEqVMGN--) {
        MJnQMATZMssl = uIpeLmPvuDU;
    }

    for (int HYBAsAtJwfwQR = 1563187783; HYBAsAtJwfwQR > 0; HYBAsAtJwfwQR--) {
        uIpeLmPvuDU = ! MJnQMATZMssl;
        uIpeLmPvuDU = JnPOsEMldzDOFDdQ;
    }

    return GIBbnP;
}

int XpiBGewB::hlYqJzCwuDvY(bool hxlyCiahjKH, bool FzUIgHayqHqNTA)
{
    double ocsHmo = 765742.7626843664;

    if (ocsHmo > 765742.7626843664) {
        for (int qVoKFjerWcn = 1847678510; qVoKFjerWcn > 0; qVoKFjerWcn--) {
            hxlyCiahjKH = ! FzUIgHayqHqNTA;
            FzUIgHayqHqNTA = ! hxlyCiahjKH;
            ocsHmo /= ocsHmo;
        }
    }

    if (FzUIgHayqHqNTA != true) {
        for (int OxjQcke = 211826241; OxjQcke > 0; OxjQcke--) {
            hxlyCiahjKH = hxlyCiahjKH;
            ocsHmo = ocsHmo;
            hxlyCiahjKH = ! hxlyCiahjKH;
            hxlyCiahjKH = ! FzUIgHayqHqNTA;
        }
    }

    for (int YttQgRdkGoXJJNcg = 1151126308; YttQgRdkGoXJJNcg > 0; YttQgRdkGoXJJNcg--) {
        hxlyCiahjKH = FzUIgHayqHqNTA;
        ocsHmo /= ocsHmo;
        ocsHmo += ocsHmo;
        hxlyCiahjKH = ! FzUIgHayqHqNTA;
        FzUIgHayqHqNTA = hxlyCiahjKH;
        FzUIgHayqHqNTA = hxlyCiahjKH;
    }

    if (ocsHmo < 765742.7626843664) {
        for (int ahlQX = 1691790783; ahlQX > 0; ahlQX--) {
            hxlyCiahjKH = hxlyCiahjKH;
            hxlyCiahjKH = FzUIgHayqHqNTA;
            ocsHmo = ocsHmo;
            hxlyCiahjKH = ! hxlyCiahjKH;
            ocsHmo += ocsHmo;
        }
    }

    return -1659163578;
}

XpiBGewB::XpiBGewB()
{
    this->JStSMq(-271812.0089788798, -889020.3218033349, true);
    this->TPuUSFaKf(-917155681, string("gHuMgbNmrrYsDgAODGcrLVsRssLKjVdyTKpdbABfXTKmwlmHmTLzWAqSNddvekNDwD"));
    this->jIaNgMDQWqUdT(string("TtJJbXeOUUWHbnYnzvvClipUwqUamJdocqaenHkoSSawrMAPBShGTIoBfmzLZBfAKDCDiXFjBargEbzjZQXuurdbcSxPmhAaFJWuViiDOlYZieKHnKBexLgMjVeFMXkAvoQqbyKdqlgTsWCLuzVFMLMVZWIWqAfyyXjWZRWMbRQscnHYwJmgIqzFSfkIJXVRzjcHRBDNiDKIclKClhCoyeUDXgZnosFlbTFjebGcYCgMJqBUc"), -617909.9560399386);
    this->atvFWDByMMWu(false, false, -1280918346, 445512.02254508005);
    this->WzNqRRE(873440336, false);
    this->GtSBz(string("JAAUKwHpGBorqXhefaRtTZumRadwIuYzKqVYQJpOKGAhLUsOKgQHblidtPcAoiILFWcAFLsvBbwUQKTWutLLCKXJNzocnIIOeJAkXwcWxNMKhzPMxoDIGoFympqLynOeXHyZpMQVanEnFqqujaWInEZzMKRQmfQPgziXCCoaTmCuhVCRfC"), true);
    this->YhQwAfvQC(-1042986188, true, false);
    this->dcHOeuvRHevUyyUo(true);
    this->BbrsvqootlC(-195623.26249259964, 1185450772, 887762.1257438718, 963419332);
    this->vHJVjlEOOzy();
    this->MvPyLuyxNMP(-61100.37088693386, false, -1222540655);
    this->bXHEVLpgxnAJWZ(870045.0642981671, -59329.023093217234, false, 719886.0122379016, false);
    this->WRTJGTQ(string("cJNPBldYDLYpJlhzfYAmIlAlXFzfIOzogEHPbRtsQnQNojSFYcILWGFhZwspmMEralPqHlgjDqmoRVIinGWUGIuhXkBdXWvyrxokPgdVUXJFYftptGaaNjhKwpTcQmLfOGszKCHVrcWeGOzWbnUQvdJbceyNPVyKKxFmBjaohjtrNOmcmYGeTGttRnaWCzNgnYiUzYsRIzNMUtCJyTmFlEahbUWPbEhzXyFYxLqGAr"), true);
    this->jYIXRhQi();
    this->ZQHRj(-871776666, false, -1570429330, string("ThWFLONGOQaYHZOySAALovBSADCEInHQgGwGVrWxzoYJqljFjehQKDNcClyDCxcUTjCDxZQGVAEJuYRAzLFvnNnZXLEAPRVGabvNIyCNMHvIsnKGAEvlMJOFccFWKFdCboolHOijNWEYiMZiIzYhwnpfObaPHqACzqtlKUErIRFoLXDcTxyg"));
    this->hlYqJzCwuDvY(true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YbXaZE
{
public:
    string cxasPK;
    int PdeiHg;
    int CnjlKcvZdcX;
    int stPfU;
    bool tyKeVyzsYsbx;
    string vseDGkpDgsN;

    YbXaZE();
protected:
    string ILholU;
    double ZBdisS;
    bool YdrdMrQhmQOJs;
    int OsdlrlgJ;
    double HBSqtKaCG;

    string iWhtbyFthxS(string JUpPtOhyqLrrL);
    double xIXNNSrhHxdpdHQ(string oMGrXo);
    double fNzos(double rcDPHedAQkx, string rWDjnhVlIUMbBxPs, double tQFAzwWxpkqraK, int qhfGIhTRvZJfulaD);
    bool HdqWKVGeKVwj(int rvVNvQsXhLNABKa, string eOuvSRyqMRdE, bool jqZmiRCrV);
    int HSswgdXzQsBgvG(int VkzdLmGCp, string ePUSopCDqbHDeFt, int GZmiqXP, string PPABvUTgPDYLdfK, int GnOUlEBzY);
    int wDzuLspm(int UVzqMTpbYZZ, bool cZOAxYbaFDzobDRN);
private:
    double xxSmpqLu;

    double zOKNaFrMj(string tfhbxqNgkHCFw, string KdQxwM, double UojPsRMZyDXsZVcH, string dfyfl);
};

string YbXaZE::iWhtbyFthxS(string JUpPtOhyqLrrL)
{
    string XgKdC = string("roLhLaREVtkhHEdIzmEVKUWgykzrrWEwqKQbIRkeiLZbPpwOyTtwHNyEbksTkottMvjXJUnZakGnUADnGoWZgXjRKcQWPFxxGKzrijfWNUUEOcvmcRKSmkAAKyFDWkMDBHHBTlvrpsToAWPSbVUregHPUvyQdLVUJIzWBIPtSEzKCkKKYLBuTvoMpfwVQIENIPijqYgvbvdNZXnMUxLmLJJXCVeKERPSEeeEyXixZrQdzUVJdcQXNOR");

    if (XgKdC >= string("roLhLaREVtkhHEdIzmEVKUWgykzrrWEwqKQbIRkeiLZbPpwOyTtwHNyEbksTkottMvjXJUnZakGnUADnGoWZgXjRKcQWPFxxGKzrijfWNUUEOcvmcRKSmkAAKyFDWkMDBHHBTlvrpsToAWPSbVUregHPUvyQdLVUJIzWBIPtSEzKCkKKYLBuTvoMpfwVQIENIPijqYgvbvdNZXnMUxLmLJJXCVeKERPSEeeEyXixZrQdzUVJdcQXNOR")) {
        for (int FByCbgXuZbBJzNuJ = 1608643455; FByCbgXuZbBJzNuJ > 0; FByCbgXuZbBJzNuJ--) {
            JUpPtOhyqLrrL += XgKdC;
            JUpPtOhyqLrrL = XgKdC;
            XgKdC = XgKdC;
            XgKdC = XgKdC;
            JUpPtOhyqLrrL = XgKdC;
        }
    }

    return XgKdC;
}

double YbXaZE::xIXNNSrhHxdpdHQ(string oMGrXo)
{
    string NRoWmFq = string("LKqjDlNyvUhRgvVyVuzxKLGOXcXnIKFPVGsorhiaLcqpsopYwOZgzaYOXdcyYGgoZiDPLkvFuGkjoOFAEXmnjpyfqIrqEacFKKiWSLYlWNLStfpPqXnjpOpehNHEGpPVjfTrjHldyPCIstTBPFfltpCdjzvkBnutKvyYGCSlCkWraFMOlERbKj");
    bool jsBTlxSQ = true;
    double vHDaoJUPFLnghRHc = 405242.4104675535;
    bool IfiJVKEnzKG = false;
    int AhUZUpq = -1422429442;

    if (jsBTlxSQ == true) {
        for (int qrCJsFvh = 299987840; qrCJsFvh > 0; qrCJsFvh--) {
            continue;
        }
    }

    if (AhUZUpq == -1422429442) {
        for (int rlkmdUMbQPMLbbNG = 53973919; rlkmdUMbQPMLbbNG > 0; rlkmdUMbQPMLbbNG--) {
            continue;
        }
    }

    if (NRoWmFq >= string("LKqjDlNyvUhRgvVyVuzxKLGOXcXnIKFPVGsorhiaLcqpsopYwOZgzaYOXdcyYGgoZiDPLkvFuGkjoOFAEXmnjpyfqIrqEacFKKiWSLYlWNLStfpPqXnjpOpehNHEGpPVjfTrjHldyPCIstTBPFfltpCdjzvkBnutKvyYGCSlCkWraFMOlERbKj")) {
        for (int pdOBsKvZBm = 596184743; pdOBsKvZBm > 0; pdOBsKvZBm--) {
            AhUZUpq -= AhUZUpq;
        }
    }

    return vHDaoJUPFLnghRHc;
}

double YbXaZE::fNzos(double rcDPHedAQkx, string rWDjnhVlIUMbBxPs, double tQFAzwWxpkqraK, int qhfGIhTRvZJfulaD)
{
    bool FelBJPjVZsZmydK = false;
    double ZwAyrVxNfZyybqG = -1013689.5833373608;
    double GIDGzQQq = 672552.320313529;

    if (ZwAyrVxNfZyybqG != 672552.320313529) {
        for (int noiDGjKvTJvxp = 1941839688; noiDGjKvTJvxp > 0; noiDGjKvTJvxp--) {
            rcDPHedAQkx += rcDPHedAQkx;
            rcDPHedAQkx *= ZwAyrVxNfZyybqG;
            tQFAzwWxpkqraK -= tQFAzwWxpkqraK;
        }
    }

    if (tQFAzwWxpkqraK <= -1013689.5833373608) {
        for (int EKegBeJJaunjmvN = 269310379; EKegBeJJaunjmvN > 0; EKegBeJJaunjmvN--) {
            FelBJPjVZsZmydK = ! FelBJPjVZsZmydK;
        }
    }

    for (int ZdYSF = 1013273223; ZdYSF > 0; ZdYSF--) {
        rcDPHedAQkx += ZwAyrVxNfZyybqG;
        tQFAzwWxpkqraK = GIDGzQQq;
    }

    if (tQFAzwWxpkqraK < 550215.651519342) {
        for (int pTDDrkGxT = 1899506863; pTDDrkGxT > 0; pTDDrkGxT--) {
            GIDGzQQq *= tQFAzwWxpkqraK;
            ZwAyrVxNfZyybqG = ZwAyrVxNfZyybqG;
        }
    }

    return GIDGzQQq;
}

bool YbXaZE::HdqWKVGeKVwj(int rvVNvQsXhLNABKa, string eOuvSRyqMRdE, bool jqZmiRCrV)
{
    bool ORRxq = true;
    double VOKnLpPxWrKz = 913107.9376764272;
    int YAsyiIDyo = -500932530;

    for (int Xoiqxuhm = 1796142912; Xoiqxuhm > 0; Xoiqxuhm--) {
        jqZmiRCrV = ! jqZmiRCrV;
    }

    for (int EEDtTbuyhAz = 938955622; EEDtTbuyhAz > 0; EEDtTbuyhAz--) {
        ORRxq = ! jqZmiRCrV;
    }

    return ORRxq;
}

int YbXaZE::HSswgdXzQsBgvG(int VkzdLmGCp, string ePUSopCDqbHDeFt, int GZmiqXP, string PPABvUTgPDYLdfK, int GnOUlEBzY)
{
    int TDNkCIvvVZUj = -1749576512;
    bool btKlNVct = false;
    bool ScbsYhYNLBlPnbC = true;
    double keZWMn = -946439.8810129614;
    bool ckrKtBGPvRzYt = false;
    bool lscwWXgTS = true;
    bool wdObiXPUtkVPADqo = true;
    double LMrjKr = -27278.30946926741;

    for (int tbSAPt = 1039973190; tbSAPt > 0; tbSAPt--) {
        continue;
    }

    for (int zwCPIRS = 1450217788; zwCPIRS > 0; zwCPIRS--) {
        continue;
    }

    return TDNkCIvvVZUj;
}

int YbXaZE::wDzuLspm(int UVzqMTpbYZZ, bool cZOAxYbaFDzobDRN)
{
    double OZfMmPvVVBYqQ = -996855.8843293056;
    string TfZuWtKTdonJcx = string("szzUyrGOLkaIxtxjboCUzqTiaHdDhsoWAeoxZZGAfzuohxTAXKtQeBYfwlpeAzGiyLRUNzoeRDWSwQhhkFonSCdStbMBNFwNhqJNMzgosaKzNTBtaGtYoboAHpmTmDpBnwculUAMvEjXZDUxyuLOpgSQOrBrD");
    string RFknGYW = string("dwFbYgZZPLIFxRbAeRGQLdRyTjcNzDlKJOTDgIfhbguGuUqnTPWpneXmyMNsCQUTWUZuYKYfEHkHRlawnFsZNuLGtZVkYEWnYXvjSXTFWhplnQKgJMOYxQzxQXWFLObTZAKJUkVlMWionYyvHLOPWBtNLuLXGtabylrZXdlbjmnDgnRFYdOvSAHpjvBOPgpUGQyqhzhQYkAOVgVOwINpPsQNnQKlxjWqdbI");
    bool EMpQXfbPLs = false;
    double bboGUIyjN = -723717.5838845735;
    string pAWvGnsGW = string("OBZQfScFEdYovOeaKbcUJEPzVssKJlaLxzevoduoMHaSqDDqoadWrWvjgvyJePllHZhheGPPXRqNYwioCryjSnBkaPGjnOhbXmhVcZLkKsczSfOdYiASQUMDEDdoMCTGiasgwmzWPxkdZhTFycAEBIKzrVAtsDPRAMKVKINnfkVGvirQtQlwlFHUeOySpnyfXjpCABlLrmawJiwR");
    int rQnkGqxHMcdD = -748679772;
    string LRHdJeRPPjkJ = string("rIOHkUghoYNopthFLEJrrqFhGZHApsEFuXxqztzbWWIYhByEfehdAANomMyzSzlFrGjSbMmeDKCJfxiqYRQDAVa");

    for (int yzIkVj = 449083775; yzIkVj > 0; yzIkVj--) {
        RFknGYW += LRHdJeRPPjkJ;
        cZOAxYbaFDzobDRN = ! cZOAxYbaFDzobDRN;
        cZOAxYbaFDzobDRN = ! EMpQXfbPLs;
    }

    for (int naBuOlfhTog = 913795071; naBuOlfhTog > 0; naBuOlfhTog--) {
        continue;
    }

    return rQnkGqxHMcdD;
}

double YbXaZE::zOKNaFrMj(string tfhbxqNgkHCFw, string KdQxwM, double UojPsRMZyDXsZVcH, string dfyfl)
{
    double SSVABhl = -628724.5677743728;
    double HieXrwBwM = 833735.1718196729;
    string TPkfR = string("zwnVHdkTYRnZPAUJQrIQubOpDbqgfYqJHTzddsmwJRbqPtwwvMRJcldLfFeZPFxlvEBRtXTnlgWqhKTkZKQqBtYjmqiHFmfIjFzrqIvLFikKwhdpf");

    if (UojPsRMZyDXsZVcH < 390777.48970288696) {
        for (int uEIOPKBEYvoNbZXj = 1460766350; uEIOPKBEYvoNbZXj > 0; uEIOPKBEYvoNbZXj--) {
            TPkfR = tfhbxqNgkHCFw;
            TPkfR += dfyfl;
            dfyfl += KdQxwM;
            KdQxwM += KdQxwM;
            HieXrwBwM -= SSVABhl;
        }
    }

    for (int EqSjQCFkNoc = 1955135134; EqSjQCFkNoc > 0; EqSjQCFkNoc--) {
        KdQxwM = KdQxwM;
    }

    if (tfhbxqNgkHCFw != string("EcbHqQFumsGEtVBbGBiCldXeO")) {
        for (int HYwlcyMN = 591811803; HYwlcyMN > 0; HYwlcyMN--) {
            dfyfl += dfyfl;
            TPkfR = dfyfl;
            dfyfl += dfyfl;
        }
    }

    if (HieXrwBwM == -628724.5677743728) {
        for (int MbVuCe = 1619306990; MbVuCe > 0; MbVuCe--) {
            SSVABhl /= SSVABhl;
            tfhbxqNgkHCFw = KdQxwM;
            KdQxwM = TPkfR;
        }
    }

    if (dfyfl >= string("EcbHqQFumsGEtVBbGBiCldXeO")) {
        for (int aKawYGmLwekM = 168224904; aKawYGmLwekM > 0; aKawYGmLwekM--) {
            HieXrwBwM += UojPsRMZyDXsZVcH;
        }
    }

    if (KdQxwM != string("EcbHqQFumsGEtVBbGBiCldXeO")) {
        for (int mfVMyacrAlM = 1591421384; mfVMyacrAlM > 0; mfVMyacrAlM--) {
            UojPsRMZyDXsZVcH += HieXrwBwM;
            SSVABhl /= UojPsRMZyDXsZVcH;
            tfhbxqNgkHCFw += KdQxwM;
            UojPsRMZyDXsZVcH = UojPsRMZyDXsZVcH;
        }
    }

    for (int oPWUGQuNDgzztmGk = 1105367738; oPWUGQuNDgzztmGk > 0; oPWUGQuNDgzztmGk--) {
        UojPsRMZyDXsZVcH = SSVABhl;
        SSVABhl -= HieXrwBwM;
        TPkfR += tfhbxqNgkHCFw;
        tfhbxqNgkHCFw = dfyfl;
    }

    return HieXrwBwM;
}

YbXaZE::YbXaZE()
{
    this->iWhtbyFthxS(string("MpHAqCOVwPJZiEFUrwQQhmgDtqjLzZVAKHyjRHQPJidWKaYAylRymfXMkVeboldGFvIGlHeqxRCTxYecquwdSbVHquksEASVCRtahEinQaYVzvqVeCotfpOcnsULDWorrizCGnJAqfDfDZkZcWmwyNKYOJBk"));
    this->xIXNNSrhHxdpdHQ(string("EhCTGbHJYZMwcgzNraHCABvrMisRWdKvqrYkpLqyHSywaNlhllhBrMsibNVXYwiVLeRweaVdaHsoEyfhPqhbzxVjOhGBeGMwQFQGfPkFVOCWrdv"));
    this->fNzos(550215.651519342, string("aKYLnJrruPcNXZINzdlVxKoDzqNkmEBnaZUVuntTlSqGxXHVXNUOXJpPhqOuoRCkbUqhrFSGiwCnUeGboSWUtQUZuGaQ"), 818052.1446071268, 2110836412);
    this->HdqWKVGeKVwj(-1520571459, string("MaEwQeXCgLWDUHCDMPfktTjGmxYdbdUKSlNVKrDStnSaaUkZCxWMOuwTzGBolWzoJiatrsYldDATpXvicWaCXOHQyNmLMAttYcshRNFilOfXWtLgOoeaBQnnOVjNVpZXDfrkWhsCwOpMRnibgPwHbETkFPPkfellxegpZcmVubHbSWGLWRtBmErMovvcrJwVsDUbkSwLBIRhNgQVlVtorPqtL"), false);
    this->HSswgdXzQsBgvG(-1857361662, string("hfQtqMBNXtqlEnOtrSZaDSRWPfzAxCJrcysJoiPRJGhGdLeicRSUcSEbtPGOaHADfVLVegLsTriy"), -726665554, string("SEJLBAaVTwfQdDnIboRSymDCMHzpEwkfqqfQfOCUHAhHwPWCFfMhHUzZobWwhntrFohXUHRIbyEZATptBIFotiButCXBtKVRqorkFmAwyDeScQGI"), 12576290);
    this->wDzuLspm(1011577130, false);
    this->zOKNaFrMj(string("KAvlMcEjYyffnnFDVRIDweHiFAmpUedAoTCqNFiGCLbWfXSgOtCXSbxCkMUOruZeEgEPthXmkXKOqUZkcTLNnwnhFjqJptDPMfXHItsKXDlgcgKQWKYHub"), string("uaGqbbYEnkGiWnusvOhQDCyhfQUSIOSTlceolWwCvgIQILwbsVUjieeOSjtBnhiPYOZbrNjjbFllceHNlWuJhyOtsmBQDdmWDpjDsQUrQKPhFXtaBETHahSvJssWuwGqreShLcrmqqfpDPXgKAMnSNzPYouLkpHIXhmtOjxCmxNjiLcOrDcslAEtcZyynxQyBe"), 390777.48970288696, string("EcbHqQFumsGEtVBbGBiCldXeO"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mlNyrVqnlOMz
{
public:
    string FpqDVguHbzNr;
    bool JJNVTwNNR;
    string wdNHiQhCY;
    double zbtvtwHqKmA;
    double WnUACBf;
    string PNTSuMSYagbWfQGB;

    mlNyrVqnlOMz();
    int tlXjbtqrm(int SqkkNa, int fKRParn, string jByDQbCGHJgfitK, int VAMdd, bool LPWApcxcGDz);
    bool JdnBfLGYJ(double ltDCNlgIbncpdWoK, bool PbgTJqupQdPOYJ, string rUwqV);
    double rROrzJwhPGYK(double ucWoXOqrrPXRRBR, string mOwMYxcPNzt, string ztyeaalYrdetLEy, double rLQndHUEFirRsLDg, int TebVSUey);
    string sZutK(int KfDUocAyKrfBh, int ekDMQbGe, string ciLhwO);
    bool DzbGiKrDCiiAS(bool kERvkDZQYUBGNOyz, double bpnaaHWV);
    int cVbPMTamckF(bool lLksXgoF, bool oVNIxqvb, double jsXzCW, double KzoQyHWIJxZzLd);
    string shmFQBuaRp(double PWZTWXWKp, int jBaDGnEoHxWb, int Dfmnp, int QdQIwNjZyxxM, int bFKOPR);
    int SKiKqTPxi(double lKnGijZFoPzJlb, double kMTvA);
protected:
    double FIAaTeqxv;
    string mJcHcxkdFIZZqao;
    bool MCVeGW;

    void uGPmfTC();
    bool iuopGEJ(string uufdJMesFo, double ypFAOVKUPf, string oIordWMRFGXjSoFl, bool oOVOvSkbZLPCYqYO);
    int msPsiNLwbpjaXU(double ORvqvYhXOiSg, double UxUzaDYqpQQw, string yDPIiBfhuzRJCyJ, int pKlqiKJP, string eLhvd);
    string IqYORQKDXarWnPj(bool eOsjqkmFAVsXk, int exWzDtgXDZrO, int nDDmEixiRvYisVHf, bool XImlXENXYY, string DcANXmpZlXoH);
    string zUnSRzuMimQTVKIY(int NotlWOxke, string hSxSPxTXdYWDRKaz, double RkJveNFBEZI);
    string PRBpqZk(double fUaLWkGXchWOsWH);
    int GdgKy(double wFsuMOkPVT, double vhqeE, double OWczsDeBl, int xOFEctViLVnnnr);
private:
    double zJpUlA;
    int BsFyye;
    double ZuHoC;
    string Swusmj;
    double zyRSwp;

    double TVGeLdHi(int IUmCSvxeavZMRIf);
    void KxzgZDmffLrl(string xXaMOVLXvymMrV, int CqnxKh, double jJEivkYVFG, bool kGsoowWL);
    double NeAIdwkkQWe(bool QIfDRpHJXJ, bool IVvzYHbHLoTbK, int AsVFXDZTec);
    bool ZxwIlNbDu(bool hrlpi, int vDUkt, double XgjXKCQ);
};

int mlNyrVqnlOMz::tlXjbtqrm(int SqkkNa, int fKRParn, string jByDQbCGHJgfitK, int VAMdd, bool LPWApcxcGDz)
{
    int JGKTowJgGyfOx = 379184439;
    int zyRRt = 771925488;
    bool eHsiZIXta = false;

    for (int gUwzTMRQxyODvTxb = 1242023231; gUwzTMRQxyODvTxb > 0; gUwzTMRQxyODvTxb--) {
        VAMdd *= JGKTowJgGyfOx;
        VAMdd *= SqkkNa;
        JGKTowJgGyfOx /= fKRParn;
        SqkkNa /= fKRParn;
        JGKTowJgGyfOx *= VAMdd;
        fKRParn /= zyRRt;
    }

    return zyRRt;
}

bool mlNyrVqnlOMz::JdnBfLGYJ(double ltDCNlgIbncpdWoK, bool PbgTJqupQdPOYJ, string rUwqV)
{
    bool lMcWBMIbV = false;

    if (lMcWBMIbV != false) {
        for (int AYHeucSoJNPWvJt = 528357102; AYHeucSoJNPWvJt > 0; AYHeucSoJNPWvJt--) {
            lMcWBMIbV = lMcWBMIbV;
            lMcWBMIbV = ! PbgTJqupQdPOYJ;
        }
    }

    for (int UKtTlaUGDmEJpdil = 1536802985; UKtTlaUGDmEJpdil > 0; UKtTlaUGDmEJpdil--) {
        PbgTJqupQdPOYJ = PbgTJqupQdPOYJ;
    }

    if (rUwqV < string("fEpKpqwXHiJilgwyIugEDxPcZzKGxcuAjyeftmfBBKNPnZWmmeauVQJfiZflSUQxjOgMrWNVHibrcYmAtYuwOlOrCiOHYJrfEXrHPekhEkVwgnWFhTXDdRFREnNVoTvXQwxOIayTHsRBGgTYCnedWwgHQaNSRQKhLcntGpIxOogpBAWmjiNnhcramrZXMZEqRhxxcvOuZDFOUjIiQxxRniKqRPDMrXOvKgNYQVMuiCZiICiIwKxPVAnjs")) {
        for (int pTZhVNr = 1386948822; pTZhVNr > 0; pTZhVNr--) {
            continue;
        }
    }

    return lMcWBMIbV;
}

double mlNyrVqnlOMz::rROrzJwhPGYK(double ucWoXOqrrPXRRBR, string mOwMYxcPNzt, string ztyeaalYrdetLEy, double rLQndHUEFirRsLDg, int TebVSUey)
{
    bool akCQAjbqtOXUV = false;
    bool JiwNpSU = true;
    bool IqUyPuxLvruU = false;
    string pAJCX = string("FSYtzcrsmHKIzLfWycXoLXxoJnFNsoOtGpqGSGYoepnNKFWdTlfZOurcqImPJpmAOYFnphiOKjjhFSEbXRRMrqzZZdawphfnZoKeMEwoPqhsMJkdNkirkdOWpkFnFplquXPqluEcCh");
    string oygHtoXfpsnjEv = string("GgwejTXngjEcadsVoHqwrTbCoUFnmhDYDHVWqeelZrdFm");

    return rLQndHUEFirRsLDg;
}

string mlNyrVqnlOMz::sZutK(int KfDUocAyKrfBh, int ekDMQbGe, string ciLhwO)
{
    bool UaZxEZOS = false;

    for (int dHagNRgwQWgwq = 1849296146; dHagNRgwQWgwq > 0; dHagNRgwQWgwq--) {
        ekDMQbGe += ekDMQbGe;
        ekDMQbGe /= KfDUocAyKrfBh;
        KfDUocAyKrfBh /= ekDMQbGe;
    }

    if (KfDUocAyKrfBh != 2144156629) {
        for (int ZAThyfQdDSL = 1164282927; ZAThyfQdDSL > 0; ZAThyfQdDSL--) {
            ciLhwO = ciLhwO;
        }
    }

    for (int TRmYCJKneyeszu = 476896389; TRmYCJKneyeszu > 0; TRmYCJKneyeszu--) {
        UaZxEZOS = UaZxEZOS;
        UaZxEZOS = ! UaZxEZOS;
        KfDUocAyKrfBh *= KfDUocAyKrfBh;
    }

    for (int mVobqRWM = 424060591; mVobqRWM > 0; mVobqRWM--) {
        ekDMQbGe -= ekDMQbGe;
        KfDUocAyKrfBh -= ekDMQbGe;
        ekDMQbGe *= KfDUocAyKrfBh;
        KfDUocAyKrfBh /= KfDUocAyKrfBh;
        KfDUocAyKrfBh = KfDUocAyKrfBh;
    }

    return ciLhwO;
}

bool mlNyrVqnlOMz::DzbGiKrDCiiAS(bool kERvkDZQYUBGNOyz, double bpnaaHWV)
{
    string XimtKtcqnsCITVu = string("hLNxpICVwqgtIKMDHbQOPfOEBjrTvtaPZYpj");
    int NGwVE = 828638572;

    for (int RzeteJqsDmSNZbZ = 1487354215; RzeteJqsDmSNZbZ > 0; RzeteJqsDmSNZbZ--) {
        kERvkDZQYUBGNOyz = kERvkDZQYUBGNOyz;
        NGwVE = NGwVE;
    }

    return kERvkDZQYUBGNOyz;
}

int mlNyrVqnlOMz::cVbPMTamckF(bool lLksXgoF, bool oVNIxqvb, double jsXzCW, double KzoQyHWIJxZzLd)
{
    int LPkejlxKIJV = -312257014;
    int hfDzxM = 1760175803;
    int MNRstumnFj = 280877527;
    double UiDRdC = -305560.5660672763;
    int EXBHIJhKjtkQ = -1013462160;
    int hWSvZC = -1096899956;
    bool LGcHvMZs = true;
    string rhkhRohDXC = string("VZIbZTwswQoZJGjUtNdrlaYNOyaG");
    string vhguBqUoL = string("yfPMWpgqhYDbjcdwTJYToWkggoDauAPUHLkoCLrKkoEcQThujCcCEWwnDfMFyFKJZKTKYETkPEWoBelnSDHOmjDoftKvVyBcsHtSiNLbCMTTTezSHUergnlDnQlweHJDtvVlneVxuCTdVokbOMqkkylESuZzPhisiePjnrnzkgDLMNvBSVlunTtHeZlQblaepkOxWhSTTIodxPxVtrnbQUTWxtqybEnZrkdmFpeJMPdLuqXlIolHnGYlTS");

    if (LPkejlxKIJV == -312257014) {
        for (int fwLpNquYhqr = 1867787076; fwLpNquYhqr > 0; fwLpNquYhqr--) {
            oVNIxqvb = ! LGcHvMZs;
            EXBHIJhKjtkQ /= hfDzxM;
        }
    }

    for (int aZRgezHSPYN = 1714244181; aZRgezHSPYN > 0; aZRgezHSPYN--) {
        lLksXgoF = ! oVNIxqvb;
        rhkhRohDXC = vhguBqUoL;
    }

    return hWSvZC;
}

string mlNyrVqnlOMz::shmFQBuaRp(double PWZTWXWKp, int jBaDGnEoHxWb, int Dfmnp, int QdQIwNjZyxxM, int bFKOPR)
{
    double brKqvRgLknmri = 167736.38754323169;
    string cpNLrMvcGPCi = string("pdWarNGDTTEYlVOhusAnNXLJUyKwNDDeQoMvXXWHGFRhHjsZeQlPuHzHgDJQHqHmogosFp");

    for (int UlJYlD = 520850400; UlJYlD > 0; UlJYlD--) {
        QdQIwNjZyxxM = bFKOPR;
        PWZTWXWKp += brKqvRgLknmri;
        Dfmnp /= jBaDGnEoHxWb;
    }

    for (int dJLgsImlBw = 249950037; dJLgsImlBw > 0; dJLgsImlBw--) {
        bFKOPR *= bFKOPR;
        bFKOPR += jBaDGnEoHxWb;
    }

    for (int NwHavg = 1782385348; NwHavg > 0; NwHavg--) {
        continue;
    }

    for (int hbXQnTu = 1621672968; hbXQnTu > 0; hbXQnTu--) {
        jBaDGnEoHxWb -= QdQIwNjZyxxM;
        jBaDGnEoHxWb *= Dfmnp;
        bFKOPR += jBaDGnEoHxWb;
        jBaDGnEoHxWb *= jBaDGnEoHxWb;
    }

    for (int aozstkjpHj = 253117568; aozstkjpHj > 0; aozstkjpHj--) {
        bFKOPR -= Dfmnp;
        QdQIwNjZyxxM = bFKOPR;
        brKqvRgLknmri *= PWZTWXWKp;
    }

    for (int dfDGuDNNxuJ = 1266004957; dfDGuDNNxuJ > 0; dfDGuDNNxuJ--) {
        jBaDGnEoHxWb /= jBaDGnEoHxWb;
    }

    return cpNLrMvcGPCi;
}

int mlNyrVqnlOMz::SKiKqTPxi(double lKnGijZFoPzJlb, double kMTvA)
{
    string glXbCvMtd = string("JwhzjIwkPZZaMbFRHDqBueLHMRvDtokgwYTuLoZZNPSbyeXQgGrhcEdHIcJSEUWPYRRALlhgseaDvvDhUwZfpSDpgEmxNuuVXVDKhUanMsyFubkZIJLvoNdKqWFNrFcodeRPkIrisIpxOCOiISMLYELWBfVinrAjydjfbEGqITrYnymgJDZXDURLAV");
    bool zmYBQ = false;
    int QkOJuvHwbmGtQF = -1719335890;
    bool JCUwnpSh = false;
    double aGIUx = -718927.3132053716;
    string hsVUe = string("KQKIenynXLSLyUDwgwKuQUcQttZRISgaGXZftiduqidClKutgsGdnWEuIxpGiROWLAJlJImkjlKMjyICoIgaNbSigKylehabxuwKBpgviephcvtSLNbEsLlOKDIaHBpDVpxhwkbYZOxTBbNMTMxAOEtLqPdgxNIygszcXiLRWThPIvThJKeWuZtBEPLguDcBpbpuyUCxVmUIbxLiz");
    bool vDMPEWdtAhvP = false;

    if (hsVUe == string("KQKIenynXLSLyUDwgwKuQUcQttZRISgaGXZftiduqidClKutgsGdnWEuIxpGiROWLAJlJImkjlKMjyICoIgaNbSigKylehabxuwKBpgviephcvtSLNbEsLlOKDIaHBpDVpxhwkbYZOxTBbNMTMxAOEtLqPdgxNIygszcXiLRWThPIvThJKeWuZtBEPLguDcBpbpuyUCxVmUIbxLiz")) {
        for (int erGlQ = 1580307025; erGlQ > 0; erGlQ--) {
            zmYBQ = zmYBQ;
            lKnGijZFoPzJlb -= aGIUx;
        }
    }

    for (int cvFkWDLgGkUakJP = 1580217761; cvFkWDLgGkUakJP > 0; cvFkWDLgGkUakJP--) {
        hsVUe += glXbCvMtd;
        lKnGijZFoPzJlb *= aGIUx;
    }

    return QkOJuvHwbmGtQF;
}

void mlNyrVqnlOMz::uGPmfTC()
{
    int qJDhQcBVtANqHO = 1626803258;
    int RYwCjtbCyRnL = -2060987150;
    string tKMOCAFvssnyAvyV = string("yywQkTICXsUDBxHutQhOJDOpUoHcXpKxrpgbOXeUBUQsqXCzSVZtvDXAUvnOQqnwqxDQlrxTAVvVAwlxFQjazSixENmmTxwPHHNuDWamVZoZPYyjBtJZYZsQuiZrECMyBupZBLlghZhlIHKzUOZjEvzgqpxNViYOZJdGtRDGQEbjHMCNcgaWGDT");
    double zgGblPFdlOqyGCoR = -68311.00133052243;
    int LPbyepqp = -1721288247;
    string egAwjd = string("oPVwZPhUyUGQtUy");
    int hzhYHFyvZUI = 1102571905;
    bool RMgbJMs = true;
    int blrXm = -1254419517;

    if (qJDhQcBVtANqHO <= 1626803258) {
        for (int fCrPrOCN = 969743003; fCrPrOCN > 0; fCrPrOCN--) {
            blrXm += qJDhQcBVtANqHO;
            LPbyepqp = blrXm;
            blrXm += RYwCjtbCyRnL;
        }
    }

    for (int YmxFp = 1498393243; YmxFp > 0; YmxFp--) {
        LPbyepqp = qJDhQcBVtANqHO;
        qJDhQcBVtANqHO -= blrXm;
    }

    for (int ehpMqNxxiyKwCvEg = 967880381; ehpMqNxxiyKwCvEg > 0; ehpMqNxxiyKwCvEg--) {
        RYwCjtbCyRnL /= RYwCjtbCyRnL;
    }

    if (qJDhQcBVtANqHO <= -1721288247) {
        for (int YlvMiMx = 1322330537; YlvMiMx > 0; YlvMiMx--) {
            qJDhQcBVtANqHO /= blrXm;
        }
    }

    for (int tFpmcxrfj = 1030123764; tFpmcxrfj > 0; tFpmcxrfj--) {
        hzhYHFyvZUI = qJDhQcBVtANqHO;
    }
}

bool mlNyrVqnlOMz::iuopGEJ(string uufdJMesFo, double ypFAOVKUPf, string oIordWMRFGXjSoFl, bool oOVOvSkbZLPCYqYO)
{
    bool baBFGdtVCb = false;
    double GIMtzRX = 78261.25990764021;
    int lEhmGfWaI = 1915790294;
    string cRTPU = string("noSUyNbXleuVyXtvjSvzGVllatfytWPutCeEFhKyNCWnyE");
    bool LUMTCUbxcWqFHMq = true;
    int nzpEsrMUvPLM = 624645312;
    string AhCLENsEIhFJeMzS = string("ybjkepurcfJCURVPLCVoYFZHFjVzlDMpBBbCFIPtQlrwyfhltpcXHRWZocwkchnoPffvoxaeaQaSlkixSLSXeuFZtBlUJjWqdluxjhMZmEgLIqJNvIhDNIXolIJCkbWIpPqtXWDPgLOcHBRRZofjQRbzcIRgbZsLytsF");
    string wvllzSsBcnd = string("sQBmkqraHkEqBhVTQwDKjMtOlcbEb");
    int PwIbz = 1479125763;
    bool btPhDhGh = true;

    if (nzpEsrMUvPLM != 624645312) {
        for (int WuZtWIKUjnxb = 1620116567; WuZtWIKUjnxb > 0; WuZtWIKUjnxb--) {
            uufdJMesFo = cRTPU;
        }
    }

    for (int MlwrKDXezb = 820077103; MlwrKDXezb > 0; MlwrKDXezb--) {
        btPhDhGh = baBFGdtVCb;
    }

    for (int eUPlYvit = 1047210234; eUPlYvit > 0; eUPlYvit--) {
        wvllzSsBcnd += AhCLENsEIhFJeMzS;
        lEhmGfWaI = nzpEsrMUvPLM;
        cRTPU = oIordWMRFGXjSoFl;
    }

    return btPhDhGh;
}

int mlNyrVqnlOMz::msPsiNLwbpjaXU(double ORvqvYhXOiSg, double UxUzaDYqpQQw, string yDPIiBfhuzRJCyJ, int pKlqiKJP, string eLhvd)
{
    int RfamCnrKhY = -1446472716;
    string taVzNTudsm = string("HJIgzNGcxNEztyiAqCHpNxHxmpDtfwJZcLqFrFLaMWiGXxhlMqGFpslyjIphcPyWIktGpHjoIDOdCIoMktCIDZyCSBRezyGzklWfkXtWozKDxiJVUqbiNjEnSEYJtsCrgPSfStcAaEEqnTDAraoHgtYMwYBAVJKIeySGkbkHgvZzEBsWXMKXEeFxGtVy");
    bool HoZGuxcHyJ = false;
    string AYMrLzVwuMmK = string("QbjskRAMhPkSuvIrRrEJuOQnVYwJrbvzWPrGFBeRCaounPmywWrUtFBOMEfctRTfTqoOvialEfEskYmXpJCEtLVGYxfngJNlcjMOHrkNtmknqLETsewMNQbOlLthNxiwljyxaaAs");
    int PuXoYAARDUz = -182834211;
    bool pbheNziBlAlbUz = true;

    if (HoZGuxcHyJ != true) {
        for (int nhzSPcUAqzZOdE = 680539002; nhzSPcUAqzZOdE > 0; nhzSPcUAqzZOdE--) {
            AYMrLzVwuMmK += taVzNTudsm;
        }
    }

    if (yDPIiBfhuzRJCyJ != string("xkbVQyO")) {
        for (int nCPgPNwSe = 1499913185; nCPgPNwSe > 0; nCPgPNwSe--) {
            AYMrLzVwuMmK = yDPIiBfhuzRJCyJ;
        }
    }

    if (RfamCnrKhY == -182834211) {
        for (int ZoLChbDBaHC = 746736591; ZoLChbDBaHC > 0; ZoLChbDBaHC--) {
            continue;
        }
    }

    if (PuXoYAARDUz >= -897711044) {
        for (int tTEaxYVHdDgr = 1234240160; tTEaxYVHdDgr > 0; tTEaxYVHdDgr--) {
            RfamCnrKhY += PuXoYAARDUz;
            yDPIiBfhuzRJCyJ = AYMrLzVwuMmK;
            RfamCnrKhY += RfamCnrKhY;
            pKlqiKJP += RfamCnrKhY;
            AYMrLzVwuMmK += yDPIiBfhuzRJCyJ;
        }
    }

    for (int wVMgRaivlq = 1492789297; wVMgRaivlq > 0; wVMgRaivlq--) {
        PuXoYAARDUz = PuXoYAARDUz;
    }

    if (RfamCnrKhY == -897711044) {
        for (int dygHSnM = 1151481757; dygHSnM > 0; dygHSnM--) {
            taVzNTudsm = yDPIiBfhuzRJCyJ;
        }
    }

    for (int kTKWxODVlV = 201855359; kTKWxODVlV > 0; kTKWxODVlV--) {
        continue;
    }

    return PuXoYAARDUz;
}

string mlNyrVqnlOMz::IqYORQKDXarWnPj(bool eOsjqkmFAVsXk, int exWzDtgXDZrO, int nDDmEixiRvYisVHf, bool XImlXENXYY, string DcANXmpZlXoH)
{
    string mHYMbER = string("ISmzOIVrbTEcIJZWvzwSpWALIT");
    string kGApIvrfyItDq = string("DinMnprXqoMmkKIccMbDxJqYtbZeGsBiHkVlOcsnAUfotwKzDzlPZDyjEcoqqYcKzZHHDngrjKqLTnoLIzUStBYVcXyOAxmdkeqlEUgqoZAkaRvihQmbnnJMFElrHhBdKNfnQhBzNKFfrYRJscRDhBpCuQBTTASDQqjEZFaNQzGdOisUkKdnJDocxpQdgNjqbmBifQtxxjkfHiGAtWT");
    int FfFgIPqhxtLl = 1108226431;
    double GjOxvCqrszT = 400810.14736452745;
    double OZfuOhBwnWcR = -506837.0070043232;
    bool PNRsYls = true;
    bool AJClKe = false;
    string tBcHXH = string("SjOnrZqDCmfAUeQoVYBCwzLgZkuFBDpUCVWeFNfSXeosUOAoLukGavJnyvpLlGBN");
    double jWYlzG = 205957.12706382555;
    int EohILo = -976301503;

    for (int NeumB = 11968439; NeumB > 0; NeumB--) {
        continue;
    }

    for (int EEBvurmiU = 505351125; EEBvurmiU > 0; EEBvurmiU--) {
        PNRsYls = XImlXENXYY;
    }

    for (int XZCCFevd = 1387142486; XZCCFevd > 0; XZCCFevd--) {
        kGApIvrfyItDq += kGApIvrfyItDq;
        tBcHXH += mHYMbER;
        exWzDtgXDZrO = EohILo;
    }

    for (int zLgzv = 19699620; zLgzv > 0; zLgzv--) {
        jWYlzG += GjOxvCqrszT;
        tBcHXH = tBcHXH;
        FfFgIPqhxtLl -= EohILo;
    }

    return tBcHXH;
}

string mlNyrVqnlOMz::zUnSRzuMimQTVKIY(int NotlWOxke, string hSxSPxTXdYWDRKaz, double RkJveNFBEZI)
{
    string nYAYUFXuxjOHmeEi = string("SBucjTqqlJdNXDWTVVnlQcciVeJhIIBFyIfbIhrurrshCDOWmFcjENJnjpYrczRmBzLXWKvecULRiraxDdyvjLvzuKqZpuMxHgfAEeAqNLhxTNOvZjKDCNGdgsajjdkupuULNygWHhCjSwqxAUdmlxiZxjFdwGzmtEqYXKSSaVanZUtTJwvfgJIwufMIuolMqMVWBlZCVgu");
    int texjS = 1251575706;

    if (nYAYUFXuxjOHmeEi == string("SBucjTqqlJdNXDWTVVnlQcciVeJhIIBFyIfbIhrurrshCDOWmFcjENJnjpYrczRmBzLXWKvecULRiraxDdyvjLvzuKqZpuMxHgfAEeAqNLhxTNOvZjKDCNGdgsajjdkupuULNygWHhCjSwqxAUdmlxiZxjFdwGzmtEqYXKSSaVanZUtTJwvfgJIwufMIuolMqMVWBlZCVgu")) {
        for (int WxNYMC = 1888942770; WxNYMC > 0; WxNYMC--) {
            texjS *= texjS;
            nYAYUFXuxjOHmeEi += nYAYUFXuxjOHmeEi;
            hSxSPxTXdYWDRKaz += nYAYUFXuxjOHmeEi;
            texjS -= texjS;
            RkJveNFBEZI /= RkJveNFBEZI;
        }
    }

    if (texjS > 1251575706) {
        for (int BTDOyzxZuNkEkT = 528437881; BTDOyzxZuNkEkT > 0; BTDOyzxZuNkEkT--) {
            continue;
        }
    }

    if (texjS == -1188172024) {
        for (int UirIxrVuuajOTMou = 1527627023; UirIxrVuuajOTMou > 0; UirIxrVuuajOTMou--) {
            hSxSPxTXdYWDRKaz += hSxSPxTXdYWDRKaz;
            hSxSPxTXdYWDRKaz = nYAYUFXuxjOHmeEi;
            texjS /= NotlWOxke;
        }
    }

    if (hSxSPxTXdYWDRKaz > string("SBucjTqqlJdNXDWTVVnlQcciVeJhIIBFyIfbIhrurrshCDOWmFcjENJnjpYrczRmBzLXWKvecULRiraxDdyvjLvzuKqZpuMxHgfAEeAqNLhxTNOvZjKDCNGdgsajjdkupuULNygWHhCjSwqxAUdmlxiZxjFdwGzmtEqYXKSSaVanZUtTJwvfgJIwufMIuolMqMVWBlZCVgu")) {
        for (int OXXtrF = 477083323; OXXtrF > 0; OXXtrF--) {
            nYAYUFXuxjOHmeEi = nYAYUFXuxjOHmeEi;
        }
    }

    return nYAYUFXuxjOHmeEi;
}

string mlNyrVqnlOMz::PRBpqZk(double fUaLWkGXchWOsWH)
{
    double eHuwrknKyBANqJmd = -880124.1178826775;
    string KfduTiERkcJCUl = string("iXmJeRavCBWFthlJdFH");
    bool OqkoZ = true;
    bool OpDdgdmjUaEKVwrd = false;
    double cVADNrcTMTRPWhMH = -299333.80168975965;
    int EhSilz = 629468331;

    if (OqkoZ == false) {
        for (int zprwSNxHFuNF = 2147444618; zprwSNxHFuNF > 0; zprwSNxHFuNF--) {
            fUaLWkGXchWOsWH = cVADNrcTMTRPWhMH;
        }
    }

    for (int lVFbZMPUuqkS = 553189268; lVFbZMPUuqkS > 0; lVFbZMPUuqkS--) {
        OpDdgdmjUaEKVwrd = OqkoZ;
    }

    if (fUaLWkGXchWOsWH < -880124.1178826775) {
        for (int FvysLBLAWQ = 654200159; FvysLBLAWQ > 0; FvysLBLAWQ--) {
            OpDdgdmjUaEKVwrd = OqkoZ;
            cVADNrcTMTRPWhMH += fUaLWkGXchWOsWH;
            eHuwrknKyBANqJmd *= eHuwrknKyBANqJmd;
        }
    }

    return KfduTiERkcJCUl;
}

int mlNyrVqnlOMz::GdgKy(double wFsuMOkPVT, double vhqeE, double OWczsDeBl, int xOFEctViLVnnnr)
{
    string IjEpdJFTmKvQJWZ = string("YovkChoIXTcGeAShRrygDFfOiefgnHEJynNHbMzlxepUISVCyjygcYVmgpUozlfMNQIdOdtAWpZqNHzATQwDMBBhZGixFJQCpUXQFXXbHvWGmyQOQXCROKnSXDLKLjfukQrLRivmRwPGUjgpiHoSpYFKYnhnpEyCTuDognfzrZUUGOyJDhIfnhSuqsjharpzf");
    double cKzUvNATTsWem = -864277.1261480073;
    string aXDRLFPFnuCO = string("nFQqBKfLnjWDjgtBECqOrSlPqcfXQJzlXvYqyBcclknzRBhxpgQoKhbFkuZrjyUaJoLiqdnpAJrJpkrqoFrEMoBzslFAunzSDnFUUJYKCKJTZJLCVTaJYsYDiJiTcsbDNPlGFNLMWYLaxWuSuOPMvnbZaAAxONpDUStZOGHXXyQBlYioNCWpdKHyVYuORzXVeVRAaKAIVCilThnQ");
    int gIaIWsdHjL = -986594948;
    string FiolqZ = string("WPjmwfeqmIcmDWyoBrzSZMLHgpFSXRrzOXMGWPTaHYxoAaKMktsYKjEZmTvtcpFkAswtpKycijieysKcAPiKDTnOtWqGZmqMBDjpmAweGCzFcmZFTmrJqhzOdCTKLWsODznXNYwneyCEJKKwgIzZnQHukLnFzTZZySwqrJBTrZjIuAoqKpZZryQuXqZCBIITDxxxve");
    int YHqozo = -654032798;
    string QsZVbahlfQfnr = string("hRcyqyEkTXKRkwlpzGFTnpVaWdLxLpkSQpDXifOCndysJpzmSEXJjuvdhaPiqlo");
    bool EJOMQ = true;
    int FPEunpxykSni = 1573499180;
    int TlWbZ = -769785522;

    if (wFsuMOkPVT < 455460.1957275945) {
        for (int hDbOtnxVfaynaM = 1411239661; hDbOtnxVfaynaM > 0; hDbOtnxVfaynaM--) {
            IjEpdJFTmKvQJWZ += IjEpdJFTmKvQJWZ;
            aXDRLFPFnuCO = aXDRLFPFnuCO;
            cKzUvNATTsWem += cKzUvNATTsWem;
        }
    }

    if (FiolqZ < string("nFQqBKfLnjWDjgtBECqOrSlPqcfXQJzlXvYqyBcclknzRBhxpgQoKhbFkuZrjyUaJoLiqdnpAJrJpkrqoFrEMoBzslFAunzSDnFUUJYKCKJTZJLCVTaJYsYDiJiTcsbDNPlGFNLMWYLaxWuSuOPMvnbZaAAxONpDUStZOGHXXyQBlYioNCWpdKHyVYuORzXVeVRAaKAIVCilThnQ")) {
        for (int YeyqMPBBKM = 1369637349; YeyqMPBBKM > 0; YeyqMPBBKM--) {
            IjEpdJFTmKvQJWZ += aXDRLFPFnuCO;
            FPEunpxykSni /= gIaIWsdHjL;
            cKzUvNATTsWem *= OWczsDeBl;
            aXDRLFPFnuCO += aXDRLFPFnuCO;
        }
    }

    for (int UVrShFGqocZdok = 1841945698; UVrShFGqocZdok > 0; UVrShFGqocZdok--) {
        wFsuMOkPVT += cKzUvNATTsWem;
        gIaIWsdHjL *= xOFEctViLVnnnr;
    }

    return TlWbZ;
}

double mlNyrVqnlOMz::TVGeLdHi(int IUmCSvxeavZMRIf)
{
    double GVzenCSLMzNNMH = -251336.99913401948;
    double zBqvtqblxBqnbm = 432440.27579407813;
    double DttQeSF = -480607.28587353096;
    int yXJetmEm = 1230675868;
    double ekgtlVZsDpkELm = 169261.90801621266;
    bool CsmiylyqCP = true;
    double eQVFKzaQdoes = 446817.48141070537;
    string lxRSUr = string("gDlAJWEKMVBJzvWztbxLglGnuduhiwqbWeoVqCwcpFEWyWDNARnBtstcepUoXmfoIqxOavNVXmegwUbcwLhQPmIdfYshfxXwnqqxgxTsHuWBvgaWuPBnXhdzcZhFPVVAXsfxrmsmJNWhfePnnLutw");
    int RCRjBxUMbi = -1732447399;

    for (int GtCavfKSP = 1830583160; GtCavfKSP > 0; GtCavfKSP--) {
        continue;
    }

    return eQVFKzaQdoes;
}

void mlNyrVqnlOMz::KxzgZDmffLrl(string xXaMOVLXvymMrV, int CqnxKh, double jJEivkYVFG, bool kGsoowWL)
{
    string jVvrG = string("MunonTNEiSpzTNBsYfixXlVkDOHJXDyahIRLrGYsXWzzqpydWvmvUHbwaFgWQQdIihW");
    string WJeYZJNvVs = string("UleEnVFNxsTICRWnKcWMaOUjAeggkYLXhuViTPIKrAdfcwdETMgOIBWUfzdNfgozppgGqkPHjRVfrbgcDwoZxlhQLIqnAoTpFgUdBdxWWnmtMEWyLhCBNDpnEgftPDvwuisFepcsbrVOspCiJRELfjyYZFxRHWZQRlYIbbCdOlHYWBlnZubBcnqGwkMqEsTcpYMtXJYHhlWTYUjuFtpByTsscGMvDdbiURiKhvTyTLdnvSJA");
    int quhbKY = 1389904511;
}

double mlNyrVqnlOMz::NeAIdwkkQWe(bool QIfDRpHJXJ, bool IVvzYHbHLoTbK, int AsVFXDZTec)
{
    double QjAqIiGrBI = -973677.3188052393;
    int XcOOU = -1617466136;
    int HkUlqBSwIVZQlzoa = 389287819;
    string CmbToklZ = string("HyAMTFhFxBzNEeAGYQKxHPnDEHkIzHTujmrRxkiyaTklCiadCTpHEMPqywbEygKRA");
    bool qADXao = false;
    string bdZHTjYkBRKWqZc = string("emaWRJrShKkZtPOXFHzczblKdkfAbbIJeYZtBLkPOCbBpdsyvAkGPcEFslgOGEsPMuBGMmpbPNXtSwyJmGQiRigztiROGOqfIuwrhyQvRTlykWPbQINXgrRupIOLQXvUAHsdZosaCP");
    string inYCZziPPwKns = string("mxOWGikWbKWxXEUXhlgHhaweQStWPnEoPlaOZpdTVmpAeOyJGqxqQibGcGJyjLAzzGRvtvxFBkIlovzsIjclTPmXEDWVqYZlUnnebzgbZxoTjbMvVayBQbtbNTobfLkiervSSPWKkQFKYWnhJYHvnPLdbvAsIxiSFibMhwWFgeTjNMgIaodGWhlTXdIZWFm");
    int yOPAkaiLl = -1415195850;

    return QjAqIiGrBI;
}

bool mlNyrVqnlOMz::ZxwIlNbDu(bool hrlpi, int vDUkt, double XgjXKCQ)
{
    int jeneYE = 499889560;

    for (int ScptTgJyjIa = 1069534850; ScptTgJyjIa > 0; ScptTgJyjIa--) {
        jeneYE += vDUkt;
        jeneYE /= jeneYE;
        vDUkt += jeneYE;
    }

    for (int wzIsFQZF = 359791458; wzIsFQZF > 0; wzIsFQZF--) {
        continue;
    }

    return hrlpi;
}

mlNyrVqnlOMz::mlNyrVqnlOMz()
{
    this->tlXjbtqrm(98350903, -392646698, string("APXXJULuyGWULZmKETuvoFZPCUXVqEcueADYHZg"), 1572218924, true);
    this->JdnBfLGYJ(831626.1493702686, false, string("fEpKpqwXHiJilgwyIugEDxPcZzKGxcuAjyeftmfBBKNPnZWmmeauVQJfiZflSUQxjOgMrWNVHibrcYmAtYuwOlOrCiOHYJrfEXrHPekhEkVwgnWFhTXDdRFREnNVoTvXQwxOIayTHsRBGgTYCnedWwgHQaNSRQKhLcntGpIxOogpBAWmjiNnhcramrZXMZEqRhxxcvOuZDFOUjIiQxxRniKqRPDMrXOvKgNYQVMuiCZiICiIwKxPVAnjs"));
    this->rROrzJwhPGYK(-518341.3204047718, string("nxfUlLXAyUFDopwcjNcgftcFYDeFnqWLgafHomUxHRRAYuQXkPdBFNhnmcQvtudSgapUWIryXUsMEckKLlUwWnMicedetqcHkOxArlPosAAHGvOEtKxJxJBunzYsFAImmQmaLtVyHiyfrNXkKjmtCsHUFKszqcdDrsppmDpzVgVYknVXJtOZLDQGQTHcYFbpBqDcAYphm"), string("bCDMWfqRchLJMMHlpqBkRBKrpZwcXQxsDTNWYZimYPyJEciUUDwcRyCoroiaYryqNXlmxfEzgewKynoGtULPokYRAnGYgKIekgUtWNFHngoEVTNfMazsUCRnijJfPTupofCXryFyMXLB"), -42776.272838671735, -1049321572);
    this->sZutK(-1910032845, 2144156629, string("TOeHABSEgXzrsWjaseKDxAkSkomRThNdmuTZMUngwKiQKIPqGmORdltqRoFgceAIrrVfoiUWVknXwGPIeieRlrnnNskghEuIYCEVIxqaaeboNLccSofNlrDeqsrUG"));
    this->DzbGiKrDCiiAS(true, -214353.76304995728);
    this->cVbPMTamckF(false, false, -940540.3169630254, -402265.1748574145);
    this->shmFQBuaRp(-461550.8629853693, -225024111, -1971703228, 1124654800, 1267656611);
    this->SKiKqTPxi(981590.6726779944, 231819.27700488025);
    this->uGPmfTC();
    this->iuopGEJ(string("HQDLyuHSaxIEdPBJrkTAqmRcTDYOdGlCCkCSbjzotfuOCzSISqqwWtgFyfeaygiTTlIFvybOoSFhfgrYPYydKcFpXhTWFkSKtmiMcWR"), 336409.4331944258, string("HhxteUk"), false);
    this->msPsiNLwbpjaXU(-780737.1920259544, 330898.3503437002, string("xkbVQyO"), -897711044, string("CmEvCMWLZiLPydaaMaaiePkMhxEafYySWBXPCZawPKNBoJXDeXHQABjSpABngkPXlgdoI"));
    this->IqYORQKDXarWnPj(true, 1094251858, -1370450862, true, string("wHcArSGDLsDYOlsSpuPFySQjJmYpnDyeTiHQYHohHHQIAEMMrtQvzcnSQYBGcoxOHsXZUPVmXwkzwiXyXsBAkLgSMsADgqPjhLskNbjoUxxCkxKyethWUAWnAAKQjYrWqKzLYNUqevRkauMJyuhv"));
    this->zUnSRzuMimQTVKIY(-1188172024, string("kBHSZWzaSFweWhnVEqwGSxRecduwAutJfFALrJcAujijiDdJqdJCoDqAKpwjsJziYjKuzdPjgjgTYyShVQCpEyMqYTfWbnQCWKupQecJRWKY"), 759056.5132457042);
    this->PRBpqZk(672334.0664223506);
    this->GdgKy(109468.01180318248, -1037307.7873840496, 455460.1957275945, -1154870327);
    this->TVGeLdHi(-22421681);
    this->KxzgZDmffLrl(string("kPyGrhaYYfloCFidQEKpwoixofIxRZEgcPSgaEkxbMaDCfJDlUlhkHiZwHoehUiKqGSYTnmtpLclxtSnpkVelbvoJBSVoHhncptdmdgoWwrRaimoeCzOMJwhsNUBuODYwWZZ"), -555265167, -906375.9550204023, true);
    this->NeAIdwkkQWe(true, false, -1933824339);
    this->ZxwIlNbDu(false, -1423504858, 953524.4250149184);
}
