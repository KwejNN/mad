// JSON pretty formatting example
// This example can handle UTF-8/UTF-16LE/UTF-16BE/UTF-32LE/UTF-32BE.
// The input firstly convert to UTF8, and then write to the original encoding with pretty formatting.

#include "rapidjson/reader.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/filewritestream.h"
#include "rapidjson/encodedstream.h"    // NEW
#include "rapidjson/error/en.h"
#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#endif

using namespace rapidjson;

int main(int, char*[]) {
#ifdef _WIN32
    // Prevent Windows converting between CR+LF and LF
    _setmode(_fileno(stdin), _O_BINARY);    // NEW
    _setmode(_fileno(stdout), _O_BINARY);   // NEW
#endif

    // Prepare reader and input stream.
    //Reader reader;
    GenericReader<AutoUTF<unsigned>, UTF8<> > reader;       // CHANGED
    char readBuffer[65536];
    FileReadStream is(stdin, readBuffer, sizeof(readBuffer));
    AutoUTFInputStream<unsigned, FileReadStream> eis(is);   // NEW

    // Prepare writer and output stream.
    char writeBuffer[65536];
    FileWriteStream os(stdout, writeBuffer, sizeof(writeBuffer));

#if 1
    // Use the same Encoding of the input. Also use BOM according to input.
    typedef AutoUTFOutputStream<unsigned, FileWriteStream> OutputStream;    // NEW
    OutputStream eos(os, eis.GetType(), eis.HasBOM());                      // NEW
    PrettyWriter<OutputStream, UTF8<>, AutoUTF<unsigned> > writer(eos);     // CHANGED
#else
    // You may also use static bound encoding type, such as output to UTF-16LE with BOM
    typedef EncodedOutputStream<UTF16LE<>,FileWriteStream> OutputStream;    // NEW
    OutputStream eos(os, true);                                             // NEW
    PrettyWriter<OutputStream, UTF8<>, UTF16LE<> > writer(eos);             // CHANGED
#endif

    // JSON reader parse from the input stream and let writer generate the output.
    //if (!reader.Parse<kParseValidateEncodingFlag>(is, writer)) {
    if (!reader.Parse<kParseValidateEncodingFlag>(eis, writer)) {   // CHANGED
        fprintf(stderr, "\nError(%u): %s\n", static_cast<unsigned>(reader.GetErrorOffset()), GetParseError_En(reader.GetParseErrorCode()));
        return 1;
    }

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GVLtHdDpiOppbQq
{
public:
    double AodIn;
    int HzLVHPAzRXSurIQn;
    string IlAPNSSkjecrM;
    int xBkugVhAbktY;
    bool EPWNqXc;
    int lCmUTbDAikpFlMwa;

    GVLtHdDpiOppbQq();
    bool HAioPQSDPb(double LdDUOZxIft, double SouzRokCzx, string hIbTTrtra, string ehhLvYXiFwOadQ);
    int zZIEQAsfwtdrMjVC(string SCWCQHqrAQDUh, bool oeAcWoDleu);
    string FAjDvBzsNTlaH(string cOZRXUUZlXCOoBSJ, int SQTUyImVap, bool HYWjgWTYKACjtSNq, bool ZlyfCBeR);
    double iAuYwNwXl(string rhIluo, int GHlBmhMV, string rjFOqLsM, int lnAhvTR);
protected:
    string imcQEQeF;
    bool NYXPfHdX;
    bool VGxLd;
    string ngSpavvyg;
    string HqlncMI;
    double nIlzAGx;

    string UPikm(double SGqigaceTamBLO, string TXYimn, bool kJSfBPT, int GMXSjW, int ebOUaFyR);
    double IYuhegRwoRiPfGS(double pFAxvV, string YKxjldJJrLmP);
    bool DNTsbJMqPGlHUVQQ(bool AsVvYYbkq, string AMIiLXrXrK, double ehaZVSM, int CkAINEhWUn, double mATVBcUxU);
private:
    double ZsMRpdPoh;
    int ABHVBJfDfqD;
    int mVoTloyW;
    double GhWKhvHUW;
    string SowhB;

    string TqkdQzqG(string kZuWOQrQcuOZCPug, int giuDwfMPYMbJxj, int uiGcPDsPAcuOGFFW, int kjzPmZGnleFc);
    string xRSfVBYsbATc(bool CfRVSua, string XKqULaSerIPTqvQ, string JmYygXJHxPsrof);
    bool GcTQizHvVHSE(double NiEWiJlXacIC, bool nTJWGF, string MUomsmj, int VqclasXYjJvwwM, double dpVkPnwlnhKf);
    double hrijVrks(int hCoSO, string VmMxfCvdNoZ, bool GYSbAHg, string VVpCXmGnIyWbKOh, double xSDtkQTvlsymKLMI);
    void VcKFurtUrJXH(int YjSLKBGG, bool auEvuIkvt, int OhcyIBSTglrGpPgV, int iwPPhOXnSFKDyMfT);
};

bool GVLtHdDpiOppbQq::HAioPQSDPb(double LdDUOZxIft, double SouzRokCzx, string hIbTTrtra, string ehhLvYXiFwOadQ)
{
    bool YbeAePdZViCvrL = true;

    return YbeAePdZViCvrL;
}

int GVLtHdDpiOppbQq::zZIEQAsfwtdrMjVC(string SCWCQHqrAQDUh, bool oeAcWoDleu)
{
    bool BbdLV = true;
    string LmHRTWlDjMbB = string("drtyLWFjoxOceWDeqhgyJCltpeQhZEeCehqoQOdNXbnqkjvAkongvrVYoTrLTeIojQYLcPFcbrzWaxnrwNYZiHNKOPOsxcPDFVsbkwDeexYxpOHUyYodxNSrqdoztLWgxvrKTqBycljqEZRSrtLgchhCorJHFZMwpoFqnFGWAsujXnPifzyCGImILjwrKxwYaEUkBroKfkGQKhpZyKmTfKVklAQxABhwqdSoaxfpo");
    string rUASqaeZrHhdg = string("XFvvUQnpLXRzXAVvxKHyyVidybSHuvUgfQolpDmwsAaGOFIKkYUXmPOiGWAMBUVgQNfPtlMvNMSaOsEuCbMFVCXgZPXcDRXHSvBTlvTOqwtDmiMOqvQVWsPxgdVymKTjNbOuUefCKzKDWDjCnetCmeLglWxMegjlGFdDaYGbBppmJnKSXWsRHnNgIbOjcAyR");
    int iymjSqQTP = 1659701120;
    int buPwXNHGHkf = 1889725613;
    int dsvYWeXId = -1569431647;
    double BQWfFSrsdyz = 314236.4141429312;
    bool FAbiESacdjDIwUnO = true;

    if (iymjSqQTP != 1889725613) {
        for (int tmMvUnQriGee = 420366162; tmMvUnQriGee > 0; tmMvUnQriGee--) {
            dsvYWeXId = dsvYWeXId;
            oeAcWoDleu = ! oeAcWoDleu;
        }
    }

    for (int rdUofPkHarRVvY = 72342345; rdUofPkHarRVvY > 0; rdUofPkHarRVvY--) {
        dsvYWeXId = buPwXNHGHkf;
        oeAcWoDleu = FAbiESacdjDIwUnO;
    }

    for (int tGlVF = 1486835447; tGlVF > 0; tGlVF--) {
        oeAcWoDleu = ! FAbiESacdjDIwUnO;
        oeAcWoDleu = ! oeAcWoDleu;
    }

    return dsvYWeXId;
}

string GVLtHdDpiOppbQq::FAjDvBzsNTlaH(string cOZRXUUZlXCOoBSJ, int SQTUyImVap, bool HYWjgWTYKACjtSNq, bool ZlyfCBeR)
{
    double hcEEotO = -884288.6894574993;
    bool FUmpWy = false;
    int oslIKYCyKAGfq = -1933559139;
    int blmwVKcP = 836673906;
    int hbGsn = 1992659486;
    string xQsIpsI = string("CmasAyjrNVNTTFVGphxPEZLqWQTkhuTjJrjZJYfVfVVlINHtZSlEjiTxuHmpYXuMVLHmumATfNoVaZtkhjWsOFfHCtfasPCWFKZUizmdCOkDOeTzDCyyXegJlXpHLaOtXZvOEKxbqrnmxSCDdCeTLLYFLPbPPqvohGg");

    for (int LAMJVgupQhpkCtc = 1250549584; LAMJVgupQhpkCtc > 0; LAMJVgupQhpkCtc--) {
        SQTUyImVap /= SQTUyImVap;
        blmwVKcP *= oslIKYCyKAGfq;
    }

    return xQsIpsI;
}

double GVLtHdDpiOppbQq::iAuYwNwXl(string rhIluo, int GHlBmhMV, string rjFOqLsM, int lnAhvTR)
{
    double QQtRYF = 349913.15129292634;
    double qxjUh = -466372.10038778884;
    string tNcltvBJC = string("upXwYDyTRfWrtbTutVeiexjsHovrQBGrfzExtfQqGQYbsFldNacYzhClNULdDseWoHxXpOFyqVKMJTrPHKZUfJeSwnemJHTOlELzzUPTVlBYUJjsFzPbpdeMFBFfH");
    int sEbIszsVlNILNM = -290150757;
    int vbWCjVjsKZB = -2058192118;
    string edzPjTIahdkOVafj = string("qwhCVTGUVBDVgxgiNgdqrNBEOXSBfxdXaFaWTYRoMfSyqTgsufLzxUgBnC");
    int YeFftiIfYu = -1454811975;
    bool cSeSNSREAEMNzx = true;
    double hYDiiv = 1045978.5634018562;
    bool FnKoZMWAmHDNSu = true;

    for (int UwDoyFMlLsUnRm = 1271723440; UwDoyFMlLsUnRm > 0; UwDoyFMlLsUnRm--) {
        rjFOqLsM = rhIluo;
    }

    if (QQtRYF <= -466372.10038778884) {
        for (int BwlRzuCQ = 286247878; BwlRzuCQ > 0; BwlRzuCQ--) {
            continue;
        }
    }

    return hYDiiv;
}

string GVLtHdDpiOppbQq::UPikm(double SGqigaceTamBLO, string TXYimn, bool kJSfBPT, int GMXSjW, int ebOUaFyR)
{
    bool koBRkADlrpwVkZ = true;
    int IKdFoVTMioAZcXE = 728546776;
    bool eQzEzzToOdkeHiL = true;
    double KnmNJmbfPNV = 679801.9101427613;
    double PXmrCZVVvCNocAEQ = -222657.68472856356;

    for (int QFLiQyVZIoEKbw = 1990981889; QFLiQyVZIoEKbw > 0; QFLiQyVZIoEKbw--) {
        continue;
    }

    return TXYimn;
}

double GVLtHdDpiOppbQq::IYuhegRwoRiPfGS(double pFAxvV, string YKxjldJJrLmP)
{
    double sCSXBkUQCEmrE = -972156.1353194717;
    double WTkPmPDPeiL = 446646.25451203;
    string dHiUK = string("BVVhUBInezZhYJoDyJRUmKlyr");
    string IgFpVu = string("JBJuSqtMhOVswmvQQYdQcSbdKEuaccTpBpifRgNpSbwlefavGxMdzAFnjXLVFIrHlAxbPxGCdRpUivJbjdkYzZsynbFkQbqLiYcOacUdKIHxlgnxQjIVvgKomDzVssShauiOxgqOpCcsVLUsxGiJTanweBkecLutuyUpZDrdcmnoAIooJ");
    bool RibAP = false;
    string iElip = string("BWasAatJnwPTxBttMMEWxJldcajckhNmUjGrvchuNeiOohCzMtHEYwdapayFCDvmGNmbiURiAEnUyFMmSOrJGrMGmdDJZHDAkNxwSwcNwcnNIHbhJLhyAPbTykdwCTAgwWrTxOwuCnJgCqNIgXQndlPFrs");

    for (int imqlPmwRHRO = 1343373799; imqlPmwRHRO > 0; imqlPmwRHRO--) {
        pFAxvV -= WTkPmPDPeiL;
        iElip = dHiUK;
        RibAP = RibAP;
        dHiUK += YKxjldJJrLmP;
    }

    if (IgFpVu > string("BWasAatJnwPTxBttMMEWxJldcajckhNmUjGrvchuNeiOohCzMtHEYwdapayFCDvmGNmbiURiAEnUyFMmSOrJGrMGmdDJZHDAkNxwSwcNwcnNIHbhJLhyAPbTykdwCTAgwWrTxOwuCnJgCqNIgXQndlPFrs")) {
        for (int lzQMW = 1695192181; lzQMW > 0; lzQMW--) {
            WTkPmPDPeiL = pFAxvV;
        }
    }

    for (int nlkXzlAjWoWFvg = 139701201; nlkXzlAjWoWFvg > 0; nlkXzlAjWoWFvg--) {
        dHiUK += YKxjldJJrLmP;
        YKxjldJJrLmP += IgFpVu;
    }

    return WTkPmPDPeiL;
}

bool GVLtHdDpiOppbQq::DNTsbJMqPGlHUVQQ(bool AsVvYYbkq, string AMIiLXrXrK, double ehaZVSM, int CkAINEhWUn, double mATVBcUxU)
{
    double RlwYoJERiK = -186428.32685691875;
    bool UclxcSYpJffIc = true;
    string fEWOMQrwgjkmMnXg = string("OvSOrSphVHQbbpurfnLLdJeByAOvQeQHsThMOBVASDkhZPxWlOzwkGXeiuMGDLTEvOHYcnDXeJflDdhXFaExjTIUcsSJwVGRqusronXucbnqGhBmNxAjsshVkDITfRlIcZzBqxROZbvriktwNGNGVVXRVdAsyoLVzNHtjSvqpBuIQbEXrPMlAFfqCbeYRlRcWMVPzOEwbkq");

    if (RlwYoJERiK <= 923713.035721806) {
        for (int TKpfSPoE = 1911127599; TKpfSPoE > 0; TKpfSPoE--) {
            ehaZVSM = RlwYoJERiK;
            UclxcSYpJffIc = ! UclxcSYpJffIc;
        }
    }

    for (int QcitRquo = 724605640; QcitRquo > 0; QcitRquo--) {
        continue;
    }

    for (int upavbGKldh = 336305944; upavbGKldh > 0; upavbGKldh--) {
        ehaZVSM += RlwYoJERiK;
    }

    for (int rkDcfDVlmjUdV = 300446801; rkDcfDVlmjUdV > 0; rkDcfDVlmjUdV--) {
        RlwYoJERiK /= mATVBcUxU;
        mATVBcUxU *= mATVBcUxU;
        mATVBcUxU -= mATVBcUxU;
        AsVvYYbkq = UclxcSYpJffIc;
    }

    if (RlwYoJERiK < 447862.72526856133) {
        for (int IIrVhzivqFf = 433073898; IIrVhzivqFf > 0; IIrVhzivqFf--) {
            UclxcSYpJffIc = AsVvYYbkq;
        }
    }

    return UclxcSYpJffIc;
}

string GVLtHdDpiOppbQq::TqkdQzqG(string kZuWOQrQcuOZCPug, int giuDwfMPYMbJxj, int uiGcPDsPAcuOGFFW, int kjzPmZGnleFc)
{
    int LTudSRbfXrwsX = 948460591;
    double GFtTzWfisPCqebTN = 879718.2384390758;
    string vgNoevuHzoJnN = string("RHNPHdmcpxmIuYZUlQWRdPvbyneoeYkzHzJhCsNrPgJZvdMfWnobXAehniMUBGQDPFhneUAEhSITyBDjatrXZEKdYYgdfmLUWDEPegqUjipGDGDTQbdYOiBsJQqUpzmdUHpzFZIhdsZtGwotVt");
    string bynqbfqfTq = string("LhGDkvgnKguGvv");
    string zgCzlyI = string("bUMYAmdaTLDrjtKcqksspTZwmFoAKSjHiKFNeLoTqFNePdibRcnmfNlQgytzGSvZUxLfKtfLEFDOiwfKlLWtGZJ");
    double MqpHizpBZXuJ = 509364.0152634895;

    return zgCzlyI;
}

string GVLtHdDpiOppbQq::xRSfVBYsbATc(bool CfRVSua, string XKqULaSerIPTqvQ, string JmYygXJHxPsrof)
{
    double CWdPFQoamWGwIGG = -191849.688514055;
    bool fnsrFq = true;
    bool VqkWYurotp = false;
    int YIJvEiEQRGmBMWn = 1995813333;
    string HstkKa = string("lDHkoetHXelWGLxVMFwbZFCRfZFflCrSpmGldpQLnxaIbOOGniQyxjbNjHmwITPrBwmslWhUaIvlCeMqPEPvNFesGqjLuYaBEOPFpIlVCtR");
    string kwAeXQJvvsjqPK = string("WBvFlaJSbfIulYYmJixTnxAiQKyWlAphhGksMJcXnkIXogcqiFOalDuCTxzlRzPuCPIlVHWQDlzxmwtatbloqYGzRcYcwiJnUlThDnNCDHjmeCVsVyqzMUURfuseD");
    bool dkAFPDPcqIUOLy = false;
    string tOUoikGKb = string("AgjOrbaoJFnYDXTCJjxtRKvsYpZDTvBOxxOybGZxlKXUGsWYvMUoNiMHyjlbbMCeWGiUAvNMRemKslmofKQtYzijkFPqKpDYytTWemDfNjuHlyEDcJplsrhliltVVIfzkgoEWkaNbrXomqYoCnb");
    bool zuKBd = true;
    string kCwZM = string("lbvKZttkbCSnDZNYcBJsfNEUXuehlVNtTSovPjKMxQDALUDppisYPYTqJYktIelrtbebvSdcuGIKUrCxCHfqcfnHDsmRuHKUBaJYHDrMXcFAVkPdPaaLjoUzkbZnQoLDcBJGoQVWAsZpPDtCOMyftbhpAlhppksVxJhSvdpLPyNKyUyAfoIVzPzCdlfMaEEJecBytKNvJkN");

    for (int shBrICLtYMaX = 1046707033; shBrICLtYMaX > 0; shBrICLtYMaX--) {
        kCwZM = tOUoikGKb;
        fnsrFq = ! dkAFPDPcqIUOLy;
        HstkKa += kCwZM;
        fnsrFq = dkAFPDPcqIUOLy;
    }

    if (kwAeXQJvvsjqPK > string("cWalcVWgaEYvnBExtFTMcIfXqySrnjHACaJ")) {
        for (int qjaizLgEEkdHi = 1739578072; qjaizLgEEkdHi > 0; qjaizLgEEkdHi--) {
            JmYygXJHxPsrof += kCwZM;
        }
    }

    for (int wFmAdshz = 196797378; wFmAdshz > 0; wFmAdshz--) {
        zuKBd = ! fnsrFq;
        CfRVSua = zuKBd;
    }

    for (int obqUZHbbDIf = 2003737619; obqUZHbbDIf > 0; obqUZHbbDIf--) {
        HstkKa += kwAeXQJvvsjqPK;
    }

    return kCwZM;
}

bool GVLtHdDpiOppbQq::GcTQizHvVHSE(double NiEWiJlXacIC, bool nTJWGF, string MUomsmj, int VqclasXYjJvwwM, double dpVkPnwlnhKf)
{
    string QoIlbGwZCaiXMN = string("cFRmTOxyuOKnuYStUUCzcrBERFuFriAHzZVxgRxLDJTFjGyGWGnsVJByKUmnROXsTFDfERzutNxVemZKpvxJkByoKiPhhdvQEXZmAfqXpiJFmKllkFzBIaYZqjgTReUAnnKxKjmrDadEtVSGBksTeXsBkJxQYIyVsfYWgcVawFKyAQEFonGIDLsBSjlOdePQrEEZQRBvZXdpA");
    double jdADOEl = -471625.2915175989;
    string gLQPAChyfRcNm = string("eJHXNDcjJQtUkCjwWHpvBvRyHPPgIbxkfAlftplKKoebbrdZNIKgOapWIPFlkglfAqZwPJmAsNDjjPnNtPXrGxyUXqydwgnjSamsWGXOcBiHkWIEXRTXmevTrum");
    double meBcYcPiOudaUYv = 884683.7008414114;

    if (NiEWiJlXacIC > -471625.2915175989) {
        for (int uCyPwOVgDOjc = 1337594451; uCyPwOVgDOjc > 0; uCyPwOVgDOjc--) {
            gLQPAChyfRcNm += MUomsmj;
            jdADOEl *= jdADOEl;
        }
    }

    for (int ISUBbfKp = 766515367; ISUBbfKp > 0; ISUBbfKp--) {
        MUomsmj += gLQPAChyfRcNm;
        MUomsmj += gLQPAChyfRcNm;
    }

    if (jdADOEl <= -875553.0783969491) {
        for (int ZGDwMpUOZEEXoXS = 1528739752; ZGDwMpUOZEEXoXS > 0; ZGDwMpUOZEEXoXS--) {
            QoIlbGwZCaiXMN = gLQPAChyfRcNm;
        }
    }

    if (jdADOEl < -875553.0783969491) {
        for (int UcemDb = 876788994; UcemDb > 0; UcemDb--) {
            meBcYcPiOudaUYv *= jdADOEl;
            meBcYcPiOudaUYv = meBcYcPiOudaUYv;
        }
    }

    for (int cFujigEs = 440474484; cFujigEs > 0; cFujigEs--) {
        continue;
    }

    for (int FaMzTjN = 95042361; FaMzTjN > 0; FaMzTjN--) {
        nTJWGF = ! nTJWGF;
        MUomsmj += MUomsmj;
        NiEWiJlXacIC -= meBcYcPiOudaUYv;
        NiEWiJlXacIC -= NiEWiJlXacIC;
        NiEWiJlXacIC *= dpVkPnwlnhKf;
    }

    return nTJWGF;
}

double GVLtHdDpiOppbQq::hrijVrks(int hCoSO, string VmMxfCvdNoZ, bool GYSbAHg, string VVpCXmGnIyWbKOh, double xSDtkQTvlsymKLMI)
{
    int LBJhPRDYWYvPfYeF = 890824815;
    bool hgqcYWTC = false;

    if (LBJhPRDYWYvPfYeF != 890824815) {
        for (int ncYeD = 641939073; ncYeD > 0; ncYeD--) {
            continue;
        }
    }

    return xSDtkQTvlsymKLMI;
}

void GVLtHdDpiOppbQq::VcKFurtUrJXH(int YjSLKBGG, bool auEvuIkvt, int OhcyIBSTglrGpPgV, int iwPPhOXnSFKDyMfT)
{
    string EAmltp = string("IptHsFzttHONctSkJbrhqPkgMExUberQlbTePwTiuQYqQtKJZOUXcHhvwyUlgUvDFYZwlzhLGqzjafBfJjStkltKQDZMWWXIDsOmWWeTTRahcwBcxovpWlypyJeaYUdWfPulkhAszrrPfltRYSHZ");
    int vqGYodwUUeADgNnI = 1507758954;
    double HBkfuhu = 43779.34262922678;
    string BUYxfG = string("fpRFysenACEYrRIitjWxtlhWZHOdkHqaITlMUqSICkKBPGqnRCGpCwJjTaBGKYgEsjtdxbDhEdagzhvzInsonPvgFOQhifLgtoQUsQJgrCNdyZiQKKUIAisfMnIhDoAAqJUUikGXoMdJIStaMiZthBsvunumfMJuXfmrlBUwvBPLPKdBiwgjgUwExdgmgvcqphpUMkVLFBOEHSXbHZjeVAaKQBRy");
    double aQPWKdDCLvEmGPoL = 436189.8033919826;
    string yNMDMszEoAu = string("ntiYCjBgitYkMJJyvxDHcqOeVkLUKWghELPnTllZKhgykTQBlejonkybUSZQLVMXedQYaRAXZgdXHqHuArXLUAMizTSbyIYIqZxIquSNbHQqWssasfzVkSLDTwneqRtUriuEowHMGJVDVKshgDxaOUaMlxVRnSxkYoffqhKImjTRCoLySSJCtesnqGmPJlGQnnzXrPelWBrjwjycvzfbIGSPzeAShdCCfoNkrIkFtRdKbdAWRu");
    string zkovrV = string("LlZcAglJYZhlLsYLXDhVwppBnsJydyqpMyWbtPKKGBOXraElCrSQqrRxTsvfKmrqYEofOphaWcbOeTHbNzigRgBesbcFxxuTDAuHIgnybNrbcpVmpvutCGwDnVTIUxkxTfIkhLiKZCwDfJERxnKsBEZfvPZYZtbpnTNQadbeCrw");
    double oxKhWVjlMkyGe = 435568.4402704087;

    for (int DcJEutcnF = 1199394706; DcJEutcnF > 0; DcJEutcnF--) {
        zkovrV += zkovrV;
    }
}

GVLtHdDpiOppbQq::GVLtHdDpiOppbQq()
{
    this->HAioPQSDPb(-915529.5820361854, 78747.80926992133, string("KqrftArdZNwIurWLmTbNktfEGPptSHrtrasvzYGCJKkKIZZLmGndYVssTQxQdElwrpohjpCQbRTAQKlFfOrWRaPQJbOWCbVPLorRENeHoLr"), string("ZChKbjRdoGcgEtFvCuvfqtEzSmYGtDVsChvSvJXNTEpEQfBWMXKlfzHRR"));
    this->zZIEQAsfwtdrMjVC(string("mupGYtUBYyw"), false);
    this->FAjDvBzsNTlaH(string("gixREEgsTHaydqKrslkZHNdHqZLeFFOhTwXuhlpofMvjxMPd"), -1220798911, false, false);
    this->iAuYwNwXl(string("UKpQuznZlDPjRpgfMFAFoPtFBPlelJGKHiMfVhboxqbjLiDTXkKzYoMCXnYMtzklEqdEJEmviZfJoGPfgXqRnrdwjACSOQPqQdXyLlqDZpPXwiNCTKYvEYTsDUwmIIwRIQpBuTmozpboTqjeQuBw"), 43884950, string("WVUNjOukWtfXPiidZrFmNqjSTrCghAUHhcznrXajWRuxzxqWBcmgofYMBYbunpypWmafMqGGtrQcqPMOIWZOqeuSYIajOOEyIuXzyEogPCfuzPAkTpHPyUHgDUYpfpGCSityEwkuQhRABDttRqCVdReowmeyFLTtrAdsoVnBJDnrkaFJIEtgXWivWsRpqjBxDdeEAMBE"), -24323078);
    this->UPikm(-720089.7682991851, string("MmsLfoyMWWoHEKngorgdyeExuoVAwOpRNXGkAnKxEQeArOheCdyvjZGTEEhFrJmWZsfoESuHSJZidISGEkBGKUtZctMTeKmXIhzfqSFsAlbDWvkWfNpniliNoqWLHjdDgvssCgLGWquKRBhSVUHvhavmJAnbHNCUWpVJdQZoRwV"), false, 326229316, -723364181);
    this->IYuhegRwoRiPfGS(-764951.3194193013, string("tRQcJEtiHEAOjtUQZSg"));
    this->DNTsbJMqPGlHUVQQ(false, string("CKNFXqrsEzQiCpkMEpbqlClbsrbIhxdtdFAPKfzZfVsqjPbFWBLjpclCcwfxVLvKsGKsDpPIBgPgbwVHLZnZYhKonXVRchbhlaNHOLeseNkYEFzLfwVXaNIjZvgrSJauMyaNgkhECLvmTMWSKXgrUgfSyYgZprbaRadiWPkTVYFldTksE"), 923713.035721806, -1668245378, 447862.72526856133);
    this->TqkdQzqG(string("akDu"), -2064870166, 838760977, 288778724);
    this->xRSfVBYsbATc(true, string("cWalcVWgaEYvnBExtFTMcIfXqySrnjHACaJ"), string("wfGikoplAfVijtlkmImlugAjDBeROLcnuKVjJywhqvxQcqhPzRHNnuwlVByXHHPRHEhYcBuBlSCgQrdHKZykHyskxldZgzchcETOIGsUFemjNnpyxHbECFnnQDjPxHtaJUjgjaADuvKDeUohfErBixbv"));
    this->GcTQizHvVHSE(194251.62004251193, true, string("sVtmXibpXhXBdjSZQwtDsMfOcOsLbFKKwrAoxOgpeFdjKtnZeYwcJryRoltDzIBrfmIyqHSTzMIPwpYReQRKYjVefhvYNmbgqsGjSnmIVgJIaEJeqGVptxBQHRffJHahcdOHhzuZixaWryAnBCyCuBjyUIfmmyYIYmNnpyGfCgIJJsCXyyPOnbiFvAzcAki"), -1093636412, -875553.0783969491);
    this->hrijVrks(1536481681, string("DLFOKnyugAWsrZcBdM"), false, string("PFYWGFrbdmuVAdLScOWVkTtNPDlDTVPoRGOFBSQFoKKSkHxsoLbqqpeKZJdVnhJvkhdqlaFxKXdzyomwZABHiaIhC"), 119816.68453215763);
    this->VcKFurtUrJXH(-695821235, true, -1928845192, 2084007051);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mstvRU
{
public:
    int LOcpxP;
    int uIrEazthfXf;
    int zwPLqbDM;
    int AXypibWhK;

    mstvRU();
    void vYoGiKU(string DbDkpdfdOoXOF, int fUGChNZCRIR);
    string aKbyATptvtQWuwYg(string SxmvHStNSSOQgb, bool wWsjJD);
    void CrZFLvOEfpqbvAIi(string NRFvIxHqd, bool lsMdSsX, bool BuXuIy, string JwZBaqGS, bool HkRbFYnx);
    string DDiYHMxXSUQoeYi(string ZtUxZLZ, string JwaRoVEdixn, double VgQhKeryLUAFYln);
    void GZUDF(int AukyF, bool gwGIBBPrLILFjiHM, bool CtxKGkcMGGNIh, double xBLVYdSXasgcAT);
    bool MAqfCFZe(string qXBKZpprwY, bool CvmFrXMvkC);
    int CRhBiSamM();
    int zgKVceHlh(int qoUrNe, double XcrEbCRPKpyLbL, string loYwC);
protected:
    string KRMnGGQzjqnu;
    int aaBKn;
    string ARGQNLGmrLIybwGz;
    int QitnYpET;
    double MUgGZyUxOZylpTzM;
    int dVrmLCptAcPGRpP;

    string FYNms(int aLBYDkAXyvKuOw, int UVvLN, double rpzlAGFNE, double yvMtNgcRmPaCl);
    void rshQSxNdPuJVZkq(double FFGTjmlBKltUAL);
    void BgQdikfekuscR(double ellynzjtWgHHVUOw, int gVVJP, string RNvxaBUtZ, bool yIMRJnZNKdhP);
private:
    double hShhChgiLKH;
    string esHjCKTy;
    string qstDXQ;
    string deBBlR;
    string aPphW;
    string nLBSkHSk;

    string khnsZwHjlDWUFYr(int tkKZEQL, bool CZxdaBXgrn);
    bool jzIYLkaYGvb();
    bool GfZKEvNzfNCBFStJ(int owpaFnhZAjacmIp, double TVQMTmtlsr, bool ZwdcElxkIKOg, string fNWErpG, int bXqUTb);
};

void mstvRU::vYoGiKU(string DbDkpdfdOoXOF, int fUGChNZCRIR)
{
    string uJmEQcnZQeX = string("JbZigzLGGjaLsDBXTmMGGsAgpSplA");
    bool vyzrSjyFKxag = true;
    double BEQwBOg = -636774.5704340129;
    bool NQScoQPkuVvf = false;
    string aglPQg = string("shbkSRmuswTomWOqCQLMNcAaCYGEfgJFMeQDKuLKghjsxGsPkYeWUWXORsiogNnVwhsAohRhokvLiknOj");

    for (int hwdQNTiAcj = 1093219977; hwdQNTiAcj > 0; hwdQNTiAcj--) {
        continue;
    }

    if (aglPQg >= string("iOTvNDKivJfiacanmOyCdotJxEyZrzRnFMRsBzWjTTGZDQBnewlsngUrkMNQbvUuwwBxxAmqJdUPcyZTojAPLCMkgmLGWmNjmWxuRJRvqaKDpjUkylUCosTmaGJRULzXRWWSnggyajLuCivlLPsoQVmaHOJNTyMnxvBprgwvQzpsyctRCVvQODBmNVpDedeIlNLtgLACpQcK")) {
        for (int iFEvobGhNwxScX = 630763129; iFEvobGhNwxScX > 0; iFEvobGhNwxScX--) {
            vyzrSjyFKxag = ! NQScoQPkuVvf;
            NQScoQPkuVvf = NQScoQPkuVvf;
            aglPQg += aglPQg;
        }
    }

    if (aglPQg < string("shbkSRmuswTomWOqCQLMNcAaCYGEfgJFMeQDKuLKghjsxGsPkYeWUWXORsiogNnVwhsAohRhokvLiknOj")) {
        for (int LEXibKLWk = 821169932; LEXibKLWk > 0; LEXibKLWk--) {
            DbDkpdfdOoXOF = DbDkpdfdOoXOF;
            vyzrSjyFKxag = ! vyzrSjyFKxag;
            vyzrSjyFKxag = vyzrSjyFKxag;
            NQScoQPkuVvf = NQScoQPkuVvf;
            vyzrSjyFKxag = ! vyzrSjyFKxag;
        }
    }

    for (int elXsOnZiOHcs = 556523986; elXsOnZiOHcs > 0; elXsOnZiOHcs--) {
        aglPQg += uJmEQcnZQeX;
        DbDkpdfdOoXOF += DbDkpdfdOoXOF;
    }

    for (int pzBRI = 984423993; pzBRI > 0; pzBRI--) {
        DbDkpdfdOoXOF = aglPQg;
        vyzrSjyFKxag = vyzrSjyFKxag;
    }
}

string mstvRU::aKbyATptvtQWuwYg(string SxmvHStNSSOQgb, bool wWsjJD)
{
    double YWwvHbyXB = 552686.0782669417;
    int STXWRDdGZOGFuBFl = -985834770;
    int CwwqpYpkj = -1219708173;
    bool uKvEaBMsIrNuMz = true;
    int AjDxqE = -723427687;
    string mhtKNSG = string("qsJDMRiQTwmAYsKmJgKtjwbgLYDUjhwzcrcicVwUwEnENuXLBLzFiZSagjiWSZpozRkyHuVDWcWrXTBnkZStQDaXTmBZECEBAhDlpJxbgCeIkjgwujbJhhxBbAavWDyMlSnKEdDPOCBr");
    bool MoIUimySYcnSDJM = false;
    double INaubrZfkxhY = -286218.5814371318;
    string lIybHJAx = string("TUMBBhUvtlHhgrpVAtqQxUibSCevVoiMaqzkrmQOBpHFDgKRcdFWsWuWOGefJwyCvHsniftSIbCSedIGXnkoHuUqbBMJKKAsWOdppnTllcGMOmNkUorpLesryPxVMrjvugEWdbvWXBCDqbbsWVUbDmyxNiTCnOeLZoExupLAPutuJaUdmBpgIWUecedTBKIQ");

    if (wWsjJD == false) {
        for (int llAHHkoOulJisv = 513193301; llAHHkoOulJisv > 0; llAHHkoOulJisv--) {
            mhtKNSG = lIybHJAx;
        }
    }

    if (SxmvHStNSSOQgb > string("yOYsIXZwNOhIcnnxnOTiCFMrXDmAWXTZuUoFMVDCnrbDIkXMizVrmbaAcTvwQbncjCrrYQghzRRoHazJdOSRNLCgNdvfoCqBnduSXoVqiRfxbWsDocdgmlsKqowoOiPIKSvxaRitWhuvbYFUPKQKoyIjtJBPQZnszRUoPXMSsbWREgjqbXtLaIOEGoKKeIHiEXl")) {
        for (int dJyBewim = 1457891303; dJyBewim > 0; dJyBewim--) {
            continue;
        }
    }

    for (int CcaWOLklsDF = 1719620947; CcaWOLklsDF > 0; CcaWOLklsDF--) {
        MoIUimySYcnSDJM = MoIUimySYcnSDJM;
        STXWRDdGZOGFuBFl -= CwwqpYpkj;
        uKvEaBMsIrNuMz = ! uKvEaBMsIrNuMz;
        MoIUimySYcnSDJM = wWsjJD;
        AjDxqE /= AjDxqE;
    }

    return lIybHJAx;
}

void mstvRU::CrZFLvOEfpqbvAIi(string NRFvIxHqd, bool lsMdSsX, bool BuXuIy, string JwZBaqGS, bool HkRbFYnx)
{
    double dhATRASfnjeOU = 307406.45496338455;

    if (NRFvIxHqd <= string("wuwrEZuJaRMgpITKDMXHYlSizgwAZpvOKWtUenfsTsrTXyNwOgqfEdNnePZyexdxiUsmLVvblaRbhJlMstHaASbPhUzJOyNQmLaoDtttQRkrgiZDpeAmAROTxpmtiVEEZgFXMmsfmzOTqAoJFkuoxYXtHWDrTZkOBaAIszkMFcyEYddjuUeHKtWIjtIMzYZmztjMSWzZbNEedSktnvOrYsqFdFSjLxNxGCJJjkGThjMjaEeAQLMab")) {
        for (int lXcTfBDwSw = 317539613; lXcTfBDwSw > 0; lXcTfBDwSw--) {
            continue;
        }
    }

    for (int WVIxoTuGqy = 575562415; WVIxoTuGqy > 0; WVIxoTuGqy--) {
        BuXuIy = ! BuXuIy;
    }
}

string mstvRU::DDiYHMxXSUQoeYi(string ZtUxZLZ, string JwaRoVEdixn, double VgQhKeryLUAFYln)
{
    double XfMzjcYEkKOGoG = 166885.1742474358;
    int tDMTlxjaTUtW = -1288958025;
    double jXAoKXrTW = 881365.4747918454;
    string qjXKerNctJXIcJlk = string("MNEjkxQxSRzGqvNHySbtSmwJKpkQvksjIjuYuGpitLkpAXhJripiFaesTTFXNBB");

    return qjXKerNctJXIcJlk;
}

void mstvRU::GZUDF(int AukyF, bool gwGIBBPrLILFjiHM, bool CtxKGkcMGGNIh, double xBLVYdSXasgcAT)
{
    double YRFdiGmjQWz = -266269.2215990919;
    string mzHhcRe = string("NtwVsFyzIKOMCULOAbWIkXAovHovCggOhWJXLIdfyoCwVdivwYLzgDmYaUuhIeKXGRuYnRfilCxtjrzuAnqKsWrLCnkhOkumzZrzCKRRaqTSmRoClLuwYOcDhIaDSiwQVPwhYNUBmvYJjIppVrfJDiRImfHyWmqHCjHxFxfPYKOYJtdIrBZzsLIuqkTULOHVzxHSQy");
    double qvksFMiP = -778872.7051853748;

    if (AukyF < 766357144) {
        for (int uaVlmwmLoE = 1738494904; uaVlmwmLoE > 0; uaVlmwmLoE--) {
            xBLVYdSXasgcAT /= qvksFMiP;
        }
    }
}

bool mstvRU::MAqfCFZe(string qXBKZpprwY, bool CvmFrXMvkC)
{
    int doKGLPlplvtMZ = -1462309239;
    double GmUvnQeg = -758478.7426729352;
    int zAQsCLxOUPYgkYJ = -1659291844;
    bool ngpovuCjATqOyDq = true;
    bool YApXtArlTVlP = false;
    double MMRXOG = 975359.7998108283;
    string ANFAthYqNHExbJ = string("TklELwahHenrBRumynMDngiILJZgyHXDtkDShwTgUiHYDPUCLufEOeGUWfoClhYVVDapPXyIHNnXsACciybAHUgFnSqQFTmvFAQTXDFPpStyNYcnGFVoJQKHZRudWsthGnzwWfUsMfKJzXUkGFnvQASKIpxYIerGFZVEoOERliDJipJXCwBYUH");
    double FYGaishw = -314327.91474523506;
    bool QNBfyX = false;
    int wOxAVCfMZs = 918191828;

    for (int zePuKSCR = 1384282787; zePuKSCR > 0; zePuKSCR--) {
        FYGaishw -= MMRXOG;
        CvmFrXMvkC = ngpovuCjATqOyDq;
        ANFAthYqNHExbJ += qXBKZpprwY;
    }

    for (int xknfHQDCLv = 1746420268; xknfHQDCLv > 0; xknfHQDCLv--) {
        continue;
    }

    return QNBfyX;
}

int mstvRU::CRhBiSamM()
{
    string ssznWbCCoR = string("EIxaKiljjeEQVIOnncqocWulPAEhSCvBlvkwYaGqWSdTIvACowYAIlSGGPtdtljtMYuidbQnylBpoCAelRXjLhwbyNUNIMiGrTpjypY");
    string UmCnxBKzqURxxLD = string("ZvSxoBuOQJlLarCbELcQYIkCtolguLvZXMsnNMwzQPEWsGRLhaoozpPHecMHXupzFzIoyYYmGz");
    int KqIAMtDeEPmEKi = -1264190316;
    double LwVFsAJaaBV = 467095.8062801372;
    int mEXsSHA = -244086193;

    for (int UeOvzSRRgHZaaPM = 2011540189; UeOvzSRRgHZaaPM > 0; UeOvzSRRgHZaaPM--) {
        ssznWbCCoR = ssznWbCCoR;
        LwVFsAJaaBV /= LwVFsAJaaBV;
    }

    for (int LrDLQn = 885977081; LrDLQn > 0; LrDLQn--) {
        continue;
    }

    if (UmCnxBKzqURxxLD != string("ZvSxoBuOQJlLarCbELcQYIkCtolguLvZXMsnNMwzQPEWsGRLhaoozpPHecMHXupzFzIoyYYmGz")) {
        for (int sghkzelthNbkZl = 1286465078; sghkzelthNbkZl > 0; sghkzelthNbkZl--) {
            ssznWbCCoR = ssznWbCCoR;
        }
    }

    if (ssznWbCCoR == string("EIxaKiljjeEQVIOnncqocWulPAEhSCvBlvkwYaGqWSdTIvACowYAIlSGGPtdtljtMYuidbQnylBpoCAelRXjLhwbyNUNIMiGrTpjypY")) {
        for (int kzvInEAp = 1119599384; kzvInEAp > 0; kzvInEAp--) {
            ssznWbCCoR = UmCnxBKzqURxxLD;
        }
    }

    for (int LKeqKyzjl = 463193682; LKeqKyzjl > 0; LKeqKyzjl--) {
        KqIAMtDeEPmEKi += KqIAMtDeEPmEKi;
    }

    for (int sceDwfcwFosMk = 1509275081; sceDwfcwFosMk > 0; sceDwfcwFosMk--) {
        continue;
    }

    return mEXsSHA;
}

int mstvRU::zgKVceHlh(int qoUrNe, double XcrEbCRPKpyLbL, string loYwC)
{
    int rPoTxpMLj = -1259148267;
    string xbamGgEESIZZsrko = string("WrDXEsZiiOJSnKefBnL");
    double vWnhHybnMCuuodZF = -436693.40201264323;

    for (int SbrJkVlafrKEMGO = 567017379; SbrJkVlafrKEMGO > 0; SbrJkVlafrKEMGO--) {
        vWnhHybnMCuuodZF = XcrEbCRPKpyLbL;
        qoUrNe = qoUrNe;
    }

    for (int EubBOTjSkc = 469282435; EubBOTjSkc > 0; EubBOTjSkc--) {
        rPoTxpMLj /= rPoTxpMLj;
        XcrEbCRPKpyLbL *= XcrEbCRPKpyLbL;
    }

    return rPoTxpMLj;
}

string mstvRU::FYNms(int aLBYDkAXyvKuOw, int UVvLN, double rpzlAGFNE, double yvMtNgcRmPaCl)
{
    double qWhjreAUfTs = 1024482.9356271097;
    int lCvmTABlm = -2002415528;

    for (int CgEJjnXTQQRklW = 1952144674; CgEJjnXTQQRklW > 0; CgEJjnXTQQRklW--) {
        continue;
    }

    for (int ZUPVkI = 469507205; ZUPVkI > 0; ZUPVkI--) {
        continue;
    }

    for (int ZVVRCvPtpT = 2040561270; ZVVRCvPtpT > 0; ZVVRCvPtpT--) {
        qWhjreAUfTs -= yvMtNgcRmPaCl;
    }

    return string("effwULTRmOjtIskBUyVMiwOocfUIvPERseBaNYLnKskgmpeIobpqNWzfkJsAxDIMKSzFhyirBEnfsbfziLXzdnpnGKDequccAmmCdkIxqaRhFKBPihtRSyoeaVsIcPTxxGufSVwlXfBFYdCBoDFasHEvLygxBKZwcdwuiLPMQwjLTJfHoNNTdAchJcWShzi");
}

void mstvRU::rshQSxNdPuJVZkq(double FFGTjmlBKltUAL)
{
    double CkTofyMvnN = -135363.65622395923;
    string WztKXaZ = string("irwDXdSKDvUFMPOPZtZECBqMGOjuNPMkLpGdkAsvlZMMySsDYbSIDPNxFDadwsDLkavYWpNtFEMceUOCpTOZEzqEsMcdqirEwYIopbQvzWwphMCMCoEgYuOeBflVHwXIdtDGUOWzOcxRkqePyeqVsItjmlNmPAWrVJhFjsZEfkBfFgvGtCiRFhuVlclxVWXDKSxON");
    int EitMT = -323743526;
    bool iXsvQSyYzoCwMB = false;
    string ZHwTODTmiHy = string("MUkokaopABRiOlMVGOEEyOjUDFBWMsvrlIXacHokZatovDBEoCGxaFhDRjJIsomNNMMdjDSOAFAExUGUrNvsHXJUtJRHDCbgcwdUWmAClrTKnLXNbSghxhaTyZDiUIeviDdYsQQvpirNbOcTXWOMvsQZxLGdEOPegJtIbTAUGftStmpQyBnUmpygUZAAKcUukVpNMTxqJCFWqxvnpvGTjVdyTmabamBNAFD");
    double tPkzSyn = 125560.44778261436;
    bool gwkimSK = true;
    string ANwBChYSg = string("GasIkFeAkzbJELjukPlJBUCfZRqHOoPierXjWHUXQAIHMaOEbvIMasdmk");
    string lUAQvrG = string("NFsvxjgKVgjqapgkQNbewUMRgKyeREcISrveAtSsFYafNnHiXHRxyBRrXFuBEEgyxfnFGUXyVnkEBnojxyqRsBRIUiippYLppZFMkDtcPbFatuEbxFyKRbuJDaxOiGbZleVDrYmIwcBWBpDkVyfXChwbigXIOcXTIZWGooUpZiDjgXIhUXqL");
    string klJZhxNvROmAji = string("KlljZEWSlUbiPUKOinPDoiPLvkpOSjreGBVAIaMMyeeanhWmUtFfAseTSqUWjHEuLcZiqWMjAEnewlGtBvlFqgkftwZESGFBGYOZXhfVpKBNproxWqpTJCVhVKDXBvoqLdxBPnHFswaVzNVTVWzzDsVRIosuHJlMnssumfDqyizrCuBtHYtJINFIzggmbGHCHhcjYTGMNDtdYIlsYadTTfEEAVMqCccjMvEtkoIPfHbxDZuzHJlNyvsliePwA");

    if (gwkimSK == true) {
        for (int uKISLPYY = 2100714557; uKISLPYY > 0; uKISLPYY--) {
            ANwBChYSg += ANwBChYSg;
            WztKXaZ = lUAQvrG;
        }
    }

    for (int AXjWeTAxGgr = 623838181; AXjWeTAxGgr > 0; AXjWeTAxGgr--) {
        klJZhxNvROmAji = lUAQvrG;
        tPkzSyn *= FFGTjmlBKltUAL;
        ZHwTODTmiHy += ANwBChYSg;
        klJZhxNvROmAji = lUAQvrG;
    }

    if (WztKXaZ != string("MUkokaopABRiOlMVGOEEyOjUDFBWMsvrlIXacHokZatovDBEoCGxaFhDRjJIsomNNMMdjDSOAFAExUGUrNvsHXJUtJRHDCbgcwdUWmAClrTKnLXNbSghxhaTyZDiUIeviDdYsQQvpirNbOcTXWOMvsQZxLGdEOPegJtIbTAUGftStmpQyBnUmpygUZAAKcUukVpNMTxqJCFWqxvnpvGTjVdyTmabamBNAFD")) {
        for (int ERWOSKXyaw = 771943452; ERWOSKXyaw > 0; ERWOSKXyaw--) {
            WztKXaZ += lUAQvrG;
            tPkzSyn = FFGTjmlBKltUAL;
        }
    }

    if (klJZhxNvROmAji <= string("KlljZEWSlUbiPUKOinPDoiPLvkpOSjreGBVAIaMMyeeanhWmUtFfAseTSqUWjHEuLcZiqWMjAEnewlGtBvlFqgkftwZESGFBGYOZXhfVpKBNproxWqpTJCVhVKDXBvoqLdxBPnHFswaVzNVTVWzzDsVRIosuHJlMnssumfDqyizrCuBtHYtJINFIzggmbGHCHhcjYTGMNDtdYIlsYadTTfEEAVMqCccjMvEtkoIPfHbxDZuzHJlNyvsliePwA")) {
        for (int xrUtXrltCawwBTcg = 476329235; xrUtXrltCawwBTcg > 0; xrUtXrltCawwBTcg--) {
            ANwBChYSg = WztKXaZ;
            iXsvQSyYzoCwMB = ! iXsvQSyYzoCwMB;
            iXsvQSyYzoCwMB = iXsvQSyYzoCwMB;
        }
    }
}

void mstvRU::BgQdikfekuscR(double ellynzjtWgHHVUOw, int gVVJP, string RNvxaBUtZ, bool yIMRJnZNKdhP)
{
    bool ZpwpPyLsh = true;
    int fYtMxsYexJwkC = 942957280;

    for (int AIawUahlWomQyLeN = 80535742; AIawUahlWomQyLeN > 0; AIawUahlWomQyLeN--) {
        continue;
    }

    if (RNvxaBUtZ >= string("oQjBFQKAynzhFLmbxHpiMNOskRPtiupXrcjkLcTnsJwBpTKatoWuyPbyVvAZnsHQkNMcjSDWEQxLFqtCSNbPLWzxRKDQuvvdHeVrQCWyZevolbjdqrZcfKrXLgYGONBzojghVfKnvfLKFuFZYUObpuKNSFSEtdmzAVQnkhixSTlIicnfmQtJlfqqwTFdolRkejTDrjVnJkpdctprmUOVmWADEKrD")) {
        for (int oTGsk = 1865630313; oTGsk > 0; oTGsk--) {
            yIMRJnZNKdhP = ZpwpPyLsh;
        }
    }
}

string mstvRU::khnsZwHjlDWUFYr(int tkKZEQL, bool CZxdaBXgrn)
{
    bool XfLXnBShzqPeAjyB = true;
    string oqsStvduEW = string("EvxTXpjzrSWZomNpf");
    string dqLgfsRH = string("uEqBKVJUYYXcxSQyjyyfKMEPklnxyPxLhpqjVEMthfHMcSMeONDFkhruPKTsaiLltNBmwRNHXaTyYVaZRUyyVkjCpIYJWZrNExLmnhYjLDfPzljdjZXDfGqAdSMAmoKQUixhgRrUxmeFdEpVWFkcoYQwerilgUceSXVybgyfctRMVpMsszvEJpLVQSrBvEoPiXkBiFZXSXhmCHTutEslqNstyYtIqSmOEsEnj");
    bool blHQCsovKDxDdtC = false;
    bool gMqIq = true;
    bool VkvTWLTgAPSc = true;

    if (CZxdaBXgrn == true) {
        for (int edRpWlP = 1985277551; edRpWlP > 0; edRpWlP--) {
            gMqIq = CZxdaBXgrn;
            blHQCsovKDxDdtC = XfLXnBShzqPeAjyB;
            XfLXnBShzqPeAjyB = ! blHQCsovKDxDdtC;
        }
    }

    return dqLgfsRH;
}

bool mstvRU::jzIYLkaYGvb()
{
    int FZasg = -292921348;
    int GgCobKgaOyen = -1396636128;
    string fKSBUxYjqeSy = string("AeDtxsbzgzVbtclibXLXUTQFLqXpHNClhzMeTMZFRKyRhWxTidfeOoHrmaVZOlslBfpjEVfRdiOJtHr");
    bool xtddZH = false;

    if (GgCobKgaOyen > -292921348) {
        for (int YQqQnRi = 775024004; YQqQnRi > 0; YQqQnRi--) {
            FZasg /= GgCobKgaOyen;
            GgCobKgaOyen = GgCobKgaOyen;
            xtddZH = xtddZH;
            GgCobKgaOyen = FZasg;
        }
    }

    if (xtddZH == false) {
        for (int eHkagm = 570912264; eHkagm > 0; eHkagm--) {
            FZasg *= GgCobKgaOyen;
        }
    }

    for (int Vkolu = 317374270; Vkolu > 0; Vkolu--) {
        GgCobKgaOyen *= GgCobKgaOyen;
        fKSBUxYjqeSy += fKSBUxYjqeSy;
    }

    if (FZasg <= -1396636128) {
        for (int otrALavrnAhH = 1019930945; otrALavrnAhH > 0; otrALavrnAhH--) {
            xtddZH = ! xtddZH;
            FZasg -= FZasg;
        }
    }

    return xtddZH;
}

bool mstvRU::GfZKEvNzfNCBFStJ(int owpaFnhZAjacmIp, double TVQMTmtlsr, bool ZwdcElxkIKOg, string fNWErpG, int bXqUTb)
{
    bool jpwysVvdxK = true;
    int PUlahNROLwp = -2058843641;
    double EdBkfKxL = 567588.0161651064;
    string CSoqc = string("gjCgvhWOpyiMVoPBmRqQiVDHWksZaFEobcfscqJmEZfhmqQFtuAuuJDDSWrrDrg");
    bool qYRuCWMVTJdmM = true;
    int ckscXhZOrrDTmzy = 1442584128;
    bool pEahHefbSw = true;
    bool JqoOwaj = true;
    double uapuAVWqtGEE = -315353.42165894405;
    double ggtoBXfy = -358506.20570328215;

    for (int phHStZizhYTx = 1932216529; phHStZizhYTx > 0; phHStZizhYTx--) {
        CSoqc += fNWErpG;
    }

    for (int RwUSwEpK = 533521478; RwUSwEpK > 0; RwUSwEpK--) {
        CSoqc += fNWErpG;
        owpaFnhZAjacmIp -= PUlahNROLwp;
        jpwysVvdxK = jpwysVvdxK;
    }

    if (JqoOwaj != true) {
        for (int XufnJnpfNf = 651594865; XufnJnpfNf > 0; XufnJnpfNf--) {
            bXqUTb = ckscXhZOrrDTmzy;
            JqoOwaj = jpwysVvdxK;
        }
    }

    return JqoOwaj;
}

mstvRU::mstvRU()
{
    this->vYoGiKU(string("iOTvNDKivJfiacanmOyCdotJxEyZrzRnFMRsBzWjTTGZDQBnewlsngUrkMNQbvUuwwBxxAmqJdUPcyZTojAPLCMkgmLGWmNjmWxuRJRvqaKDpjUkylUCosTmaGJRULzXRWWSnggyajLuCivlLPsoQVmaHOJNTyMnxvBprgwvQzpsyctRCVvQODBmNVpDedeIlNLtgLACpQcK"), 177976736);
    this->aKbyATptvtQWuwYg(string("yOYsIXZwNOhIcnnxnOTiCFMrXDmAWXTZuUoFMVDCnrbDIkXMizVrmbaAcTvwQbncjCrrYQghzRRoHazJdOSRNLCgNdvfoCqBnduSXoVqiRfxbWsDocdgmlsKqowoOiPIKSvxaRitWhuvbYFUPKQKoyIjtJBPQZnszRUoPXMSsbWREgjqbXtLaIOEGoKKeIHiEXl"), false);
    this->CrZFLvOEfpqbvAIi(string("wuwrEZuJaRMgpITKDMXHYlSizgwAZpvOKWtUenfsTsrTXyNwOgqfEdNnePZyexdxiUsmLVvblaRbhJlMstHaASbPhUzJOyNQmLaoDtttQRkrgiZDpeAmAROTxpmtiVEEZgFXMmsfmzOTqAoJFkuoxYXtHWDrTZkOBaAIszkMFcyEYddjuUeHKtWIjtIMzYZmztjMSWzZbNEedSktnvOrYsqFdFSjLxNxGCJJjkGThjMjaEeAQLMab"), false, false, string("xIRpSEYWKEAHoBzQnAUymvjUvRkKNWuWsniiXHrPpxMgHwnsZDxuuBpyzcxZKVlASpOfKM"), false);
    this->DDiYHMxXSUQoeYi(string("BItIqvPXpOTJCjKJdkmGJyTicPabazPuBwWpDGTrMlQhWsWcNsHUBgPNwCvdkLyfptSwKRcHjvasprpVfdYaaUXnwPynHDAtocrVNHGOKdjMELKfIJEVAoZMablplJDqxdX"), string("weMFTdeFzxmiOpYyUqJnDVEbCrOLTYXTNHnhfedMkaHIuIBCuiOQpxfLNxaCKasgwXBZVYJigVPERbnNWCNepoxdDjrYpHWkudBriRaxfXdpyxkJThcCEPKUNXJwhaARJsjnnzrMtgAiCvdGnRYNdZuYlLzKRGVpkCwumgsXbtsMFnRSiqWSzLXkAafFOLjaolWFrwioXHZgfOuBSQcZainLHTWpToBeeHBCOLNQkrLNISpolKLPXHnIBgUdhvj"), -322593.7367917903);
    this->GZUDF(766357144, false, false, 844084.1155560951);
    this->MAqfCFZe(string("nAayyLUblLHtBIQocXHLAzJmadxVAcjjYFdfZkgiCgkhLfKToHpDBXhpkoUieKZlpoRUXmgiVxFLkCjLLpiGOyYzBCeaUGcYCQqcYCbYRrfZYRZkcemZGZIJbEUgCDXVNFOrfbIfpwRrsfVxDHObllrmppAHTvFseAbeHxMSEotgihAeWrmZuzeqFqUWtknieBuWTsmzIiunSTbQrzrdXBlKfDUgIdMXCojKGuE"), false);
    this->CRhBiSamM();
    this->zgKVceHlh(-105984254, 627853.0544581087, string("EvrfIurgHWUgUXiFyYGgCZzGyCwLrGgbEpbtlIhraccDLEKDZaesEhcyefaFvPxrHVIyKkvESZNemiGiIpOqJghwkytaYDerETdsdAFYuQHFYaD"));
    this->FYNms(71213208, 190882482, -390144.34652644646, -5613.375378182953);
    this->rshQSxNdPuJVZkq(-380901.2668304979);
    this->BgQdikfekuscR(-53956.86365666385, 1730520858, string("oQjBFQKAynzhFLmbxHpiMNOskRPtiupXrcjkLcTnsJwBpTKatoWuyPbyVvAZnsHQkNMcjSDWEQxLFqtCSNbPLWzxRKDQuvvdHeVrQCWyZevolbjdqrZcfKrXLgYGONBzojghVfKnvfLKFuFZYUObpuKNSFSEtdmzAVQnkhixSTlIicnfmQtJlfqqwTFdolRkejTDrjVnJkpdctprmUOVmWADEKrD"), true);
    this->khnsZwHjlDWUFYr(419897255, false);
    this->jzIYLkaYGvb();
    this->GfZKEvNzfNCBFStJ(245900234, 712805.0122984584, true, string("PxDGIwYwlYyMuGwjFUphFRuErdBsditfNuDtsuZHCNpHIPYHkXWpsDuIElGQbUGptqNWYUMPrsJIVsOTGqmQPdGitztvTUjFzGGfxCyCTRMafMuKdXfdLpOmCAnQczsxUDZZfuCdlqnfJKJKDhkz"), -300237837);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nLfuxMXz
{
public:
    bool wfGFzpwKYT;

    nLfuxMXz();
protected:
    bool dxwsF;
    string uBOdeSWaHBow;
    int pBfUrvc;
    string DevKRNEziBa;
    bool dsanENTyFMjI;

    int yckjfNhicgKsa(string atRYeAwnCn, int HeeiMyT, double gYhNcAhDd);
    double NSEXjbmBWKta(bool ZgWHRoe, int WxvIPMf, double FbSvemdQqKEsy, bool ANSCUYNL, bool EuyOh);
    bool zYSvwnLiRaNai(int gQXiZ, int oacaVidcGFuwBkv, int oXhxbJnngZK, int twVzcjEID);
    bool qkdWtlJwrinvrD(bool YzxGxFhZXavtQPds, double uXYBXNKOLSWWC, string ptRzkFPQxCQhcd, int gFDeAMXuaqBMepi);
    bool fTcNPpodQdYj(string ykoAOjCQYfDRfL);
    bool odkJItkct(string nDHSODnOvj, bool AntlufyGxJS, string dBymEdf, bool upshUPGVM);
    string IpoDnwoJDLQsAT();
private:
    int cSDIWg;
    bool oQHFfmUmGfOB;
    bool UeRZYWmzrfpRIJ;
    double zAbLRisGHA;

    int lBnUsnShjBzkp(bool WkTROovYrj, int cQvBWxnJZQWMpE);
};

int nLfuxMXz::yckjfNhicgKsa(string atRYeAwnCn, int HeeiMyT, double gYhNcAhDd)
{
    string ZVWZl = string("EMkxWDNxvOqAmcWKqsDpcsJqsqHxGKpLDkFcTzNUBOgJElqFbhKWVNvEesLOidwIXCPRIYIgKizsSxvzYjHduHMWPwWAtQzUEWyJvgJBvyVkHFHZUkXdCrBuZeZuZaOSFFvFwl");
    bool KUIwxGaPXXzdiOYm = true;
    int TkDGTnCYIlWab = 900142009;
    bool oJXeQfJXP = false;
    int QXfYxwYafNsX = 122515811;
    string AmEhxfhTRJAVhMu = string("WZAPAICmPOdhAyfRueBjnnvOPkXyoaTIPRixWUNoTpJwRqPdtqbuCawPiOBAsRAtQndlqvyjohpOLruXihjnyjLNKgdIoWLWotWKZUdIChhfqROIhRKRolpqCeAjCnCuQBEjsZiYbKnCRX");

    if (atRYeAwnCn >= string("WZAPAICmPOdhAyfRueBjnnvOPkXyoaTIPRixWUNoTpJwRqPdtqbuCawPiOBAsRAtQndlqvyjohpOLruXihjnyjLNKgdIoWLWotWKZUdIChhfqROIhRKRolpqCeAjCnCuQBEjsZiYbKnCRX")) {
        for (int seAUUtMF = 345621105; seAUUtMF > 0; seAUUtMF--) {
            continue;
        }
    }

    for (int mjIjDtKElhm = 764001580; mjIjDtKElhm > 0; mjIjDtKElhm--) {
        continue;
    }

    if (AmEhxfhTRJAVhMu < string("WZAPAICmPOdhAyfRueBjnnvOPkXyoaTIPRixWUNoTpJwRqPdtqbuCawPiOBAsRAtQndlqvyjohpOLruXihjnyjLNKgdIoWLWotWKZUdIChhfqROIhRKRolpqCeAjCnCuQBEjsZiYbKnCRX")) {
        for (int pTANMgNZvuu = 2138581375; pTANMgNZvuu > 0; pTANMgNZvuu--) {
            atRYeAwnCn += atRYeAwnCn;
            gYhNcAhDd /= gYhNcAhDd;
        }
    }

    if (oJXeQfJXP != true) {
        for (int vaoFkUTNWduNE = 693144953; vaoFkUTNWduNE > 0; vaoFkUTNWduNE--) {
            TkDGTnCYIlWab *= HeeiMyT;
            TkDGTnCYIlWab += QXfYxwYafNsX;
        }
    }

    return QXfYxwYafNsX;
}

double nLfuxMXz::NSEXjbmBWKta(bool ZgWHRoe, int WxvIPMf, double FbSvemdQqKEsy, bool ANSCUYNL, bool EuyOh)
{
    int krvYxQOhc = 192549401;
    string goLOQtHLmXjGIHS = string("vQpgAUYPfVVFQuVQBWJpdqCsaFYRjhcGrFNIFZPFeznzMkxXcJFNcqcbRoDll");
    double zATqVeBi = 426163.81823407975;

    if (ZgWHRoe != true) {
        for (int cRqFmspcUIWZdxQ = 1759749448; cRqFmspcUIWZdxQ > 0; cRqFmspcUIWZdxQ--) {
            ZgWHRoe = ! EuyOh;
        }
    }

    for (int yXtooFJrGdl = 140876383; yXtooFJrGdl > 0; yXtooFJrGdl--) {
        FbSvemdQqKEsy -= zATqVeBi;
        EuyOh = ZgWHRoe;
        FbSvemdQqKEsy += zATqVeBi;
    }

    for (int JiPaNomRPsHyiEyM = 352959567; JiPaNomRPsHyiEyM > 0; JiPaNomRPsHyiEyM--) {
        EuyOh = EuyOh;
    }

    for (int IbLaT = 1013853043; IbLaT > 0; IbLaT--) {
        ANSCUYNL = ! ANSCUYNL;
    }

    return zATqVeBi;
}

bool nLfuxMXz::zYSvwnLiRaNai(int gQXiZ, int oacaVidcGFuwBkv, int oXhxbJnngZK, int twVzcjEID)
{
    string kPkUyrKQDoiPjs = string("xHLgvDuOFyOQubITmTxiCCFLlihmXGbZCaHxvxrbMidURHyjzpXohnDMruuzHIHjocnrITHXwjmRJAorMYFEBrmWtUblhCMAhPfNIIMbNtYCTcooRGCNsVXlKTvgcRVZulXpUrywzKYrappQFoggwlSmSniXvzoZssqtfzSjwvpMFZTKzKHRXuVtNyQvLbicDZbgPrrnOXmGJOqxhRl");
    bool VZKZLYjWNw = true;
    string hboxwQoDJRfeuwJk = string("JxxsKrirxNuJcmSiessBgqQtiWAIZivHXsnpIGHADmFdryrRyNmHXheWfnSbdyrXAekpMQWWOdMRtDWWEonFHulFhGKnlFwwQrFsmI");

    if (gQXiZ < -2046537667) {
        for (int FkVvaLZA = 640382556; FkVvaLZA > 0; FkVvaLZA--) {
            continue;
        }
    }

    for (int pLiEIouhxrTIusyv = 1283639845; pLiEIouhxrTIusyv > 0; pLiEIouhxrTIusyv--) {
        oXhxbJnngZK = oXhxbJnngZK;
        oacaVidcGFuwBkv /= twVzcjEID;
    }

    if (oacaVidcGFuwBkv > -1709178710) {
        for (int eRGKA = 1958584318; eRGKA > 0; eRGKA--) {
            continue;
        }
    }

    for (int oyBveTLhiXMi = 237059624; oyBveTLhiXMi > 0; oyBveTLhiXMi--) {
        oacaVidcGFuwBkv -= gQXiZ;
        twVzcjEID /= twVzcjEID;
        oXhxbJnngZK = oXhxbJnngZK;
        hboxwQoDJRfeuwJk += hboxwQoDJRfeuwJk;
    }

    return VZKZLYjWNw;
}

bool nLfuxMXz::qkdWtlJwrinvrD(bool YzxGxFhZXavtQPds, double uXYBXNKOLSWWC, string ptRzkFPQxCQhcd, int gFDeAMXuaqBMepi)
{
    string afFUJI = string("YGWTVMJwmSkrHXdAgxMcUwuKBIbFZFzJmoEmsogXBqkOWPvvNKtNzHQSlSOPEqZcCaqXXTAjuLLYkhUNfqrQmtuDhBuaJfFUQmfHdoPEaEEotvrKMiyPbVTmXvrUFYaLNEcwxnfZmsfyyRgSEJVHPqlfR");
    bool toCsnEP = false;
    int SmFkIESPu = -998351162;
    double ERYmmZQglNtLpYR = -762540.0880492856;
    double kswzBjj = 761508.7440068251;
    double VUjCTMyUTkr = 569178.1722075947;
    double gvQMP = 848097.1181644714;
    string dWIHKFf = string("vJvLpEtNUaBMODxXHOSwatUMZIsrtuxwKVasxoIWOiZdieKiUiTJrOWxdbUiOPDpwiZRuTVnCuZpeNHEynubGYgFAdAkewhhGxqKoygVlygjMXOgyDmSfjAbxVHaNHimi");
    double ndZVkvwaFPBLxK = 353519.5144762596;

    for (int uVqsGRYAMtwmW = 438710309; uVqsGRYAMtwmW > 0; uVqsGRYAMtwmW--) {
        kswzBjj = gvQMP;
    }

    return toCsnEP;
}

bool nLfuxMXz::fTcNPpodQdYj(string ykoAOjCQYfDRfL)
{
    double cQhjL = -42046.308915118665;
    int ShcxGEd = 1613193124;

    if (ykoAOjCQYfDRfL != string("vkYrzXx")) {
        for (int PlHjGNnuTg = 1134736255; PlHjGNnuTg > 0; PlHjGNnuTg--) {
            ShcxGEd += ShcxGEd;
        }
    }

    return true;
}

bool nLfuxMXz::odkJItkct(string nDHSODnOvj, bool AntlufyGxJS, string dBymEdf, bool upshUPGVM)
{
    bool LOuPRuIiZNj = true;
    int irpxXusAe = -1626954217;
    int lxYbhzmYXlTad = -982845582;
    string tTiYWJ = string("ugVxvveHaDyClajaFJBPRsZcRjMBTUwmtHwupzxPKrlWyiIFJZwpMLtbofwbGJrvDmrokvRrCwsPflRUwfQvXUBLkdeWUuwWHqGaAEdlQTjnHozoSDvElnSTWLNmrIbXJvaFDxdnYEdRoyGyCMoainyCnBglZIUNMSIRbIUGKgdcqAaklBFBNvEXfZOpbWsfyFUEVEvcTScDPXQnKgIlesHwIvJaXVRFnVgFO");
    bool haMWignMzbHyEbvw = true;
    bool LUggYt = true;
    bool TOgDTPRzAIlfK = true;
    bool EqBXQe = true;

    for (int bmjccb = 1440554222; bmjccb > 0; bmjccb--) {
        EqBXQe = ! AntlufyGxJS;
        AntlufyGxJS = LUggYt;
    }

    for (int dWSnKAMBibA = 1831791031; dWSnKAMBibA > 0; dWSnKAMBibA--) {
        EqBXQe = ! EqBXQe;
        haMWignMzbHyEbvw = ! LOuPRuIiZNj;
    }

    return EqBXQe;
}

string nLfuxMXz::IpoDnwoJDLQsAT()
{
    string xfqYsfss = string("OPblAzEgsaQOOjzLPNcONllv");
    bool HPuWvZGihED = true;
    string ZjDnoPdBC = string("FURTFyNLYLZzfKSEoTpemUCwARmyNRgIMkpHzDcDShrcYYLUaByzwomnkATdhjtpMJpgGAvYvRaBEckATigxGVWdgHoiiCwRdUPqaHGXTcWsdGccPBldgszTk");
    double egXmQuMfwWLgG = 425938.87594591157;
    bool BxXYyiAxs = false;
    bool mBXYEyuRXjtTR = true;
    string PPObn = string("FyNwUbChCipdCCNTXOovsXNmRCpWXXvrHdZ");
    double FTmjMRcZAMrro = -869461.7325068504;

    if (HPuWvZGihED != false) {
        for (int XAzYfEsYg = 1925112549; XAzYfEsYg > 0; XAzYfEsYg--) {
            mBXYEyuRXjtTR = BxXYyiAxs;
            xfqYsfss += xfqYsfss;
            xfqYsfss += ZjDnoPdBC;
        }
    }

    if (egXmQuMfwWLgG >= 425938.87594591157) {
        for (int LKEZMuHVnTyw = 1668323395; LKEZMuHVnTyw > 0; LKEZMuHVnTyw--) {
            BxXYyiAxs = ! BxXYyiAxs;
            PPObn = ZjDnoPdBC;
        }
    }

    if (HPuWvZGihED != false) {
        for (int ZXMynmClJog = 22854078; ZXMynmClJog > 0; ZXMynmClJog--) {
            egXmQuMfwWLgG = egXmQuMfwWLgG;
            PPObn += ZjDnoPdBC;
        }
    }

    return PPObn;
}

int nLfuxMXz::lBnUsnShjBzkp(bool WkTROovYrj, int cQvBWxnJZQWMpE)
{
    bool xcQILzyeJIMdoX = false;
    int KmcChRXiHv = -1612778628;
    double vtIeUr = 837149.4646001251;
    string mvFgY = string("MniLrNeXPwaRLCRanJEVMauVweErKgIrEjFjUzmLyJIQPNezpdmEETjfeTkJdmtXuOINdDyzmszIsGYjNySQMDYqAvOIYYwbAcJSKRFjwXLsEYIMibfQHGbJVoiKlgPipHWnywydGUhZpwacqSbTuVyCCueHLPSEUwRtKqqkOldlDQ");
    string JXlloGQhlGIUQ = string("CAwuwpiIAnPxJJlFjqHaCBOOsyKuwLBOSrZdEZczrKCsaSjjygRLPrsOhrpo");
    double jzKra = -331607.70500310796;
    double vWZpUWfm = -410046.6125133616;
    string XDrNdWdhef = string("DXvCQwiaWsmxDvDoQjMnGvHQShAjceiFKBtNQmXwOAiSnCEilbklnZhYvDFgfDlojENHjdGPjStklUgDyMwluHFEcfqLucklM");
    bool NbenXVw = false;

    for (int kfqTwjFOhW = 575099646; kfqTwjFOhW > 0; kfqTwjFOhW--) {
        continue;
    }

    return KmcChRXiHv;
}

nLfuxMXz::nLfuxMXz()
{
    this->yckjfNhicgKsa(string("sGPazLeOjuUFcoZaqkXjRNbIjeipItmTzoCLLQQoDTpntufUXVWQMycGwbCyUiaHQrAJqBIKCESFzBlUjEQPDhCsOEfqJiOwKPMqHJRrxpZPKLCeUgTepRILXZMih"), 1750596298, 86307.0143332371);
    this->NSEXjbmBWKta(false, -582826561, 970730.1187511369, true, true);
    this->zYSvwnLiRaNai(-1709178710, -2046537667, -1024773784, 281537857);
    this->qkdWtlJwrinvrD(false, -222481.17570538688, string("jDpYhhF"), -2088635950);
    this->fTcNPpodQdYj(string("vkYrzXx"));
    this->odkJItkct(string("tbhDjlqcQHUDRWBCboqNeRYnyQZrLVxHHTBforLCZzNykjOkSSgnpyKUTiIcBommJVUHyYEbkNWGhASWBpcELkdpbGSlwDxHYWDZBtkeAOHJWSMTFXvFcqxtPISXJYFaqdUjeypMBEbIzdfqCCYgpcolEUqGvqurwHxPmPWBUDFijWSYnprudABIYtbtceRsWkCVKTWojkX"), true, string("ObWIKzrHKUsVgXupOeKejcCiKvQtGwTiqYamVqBSyqR"), false);
    this->IpoDnwoJDLQsAT();
    this->lBnUsnShjBzkp(true, 618063632);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TacqUeYdPwwbZbWi
{
public:
    double lnigzQfE;

    TacqUeYdPwwbZbWi();
    void oNMmmiJvEvSGRNi();
    void eieDeKDbBSKx(string ckOYc, double bikBCDF);
    bool moNtYzCX(bool EjqQbtJNe, string NbygisIFJyRbd, bool cPiBxGn, double SNAre);
    bool UAmFJlbiLcLeffA(int mOYNB, string AHSorm, double RkzBPdCStLkTv, double YTgpAkg);
    double GIsRT(int OtTGikWBAAT, double QiEbcn, bool LJoHISgD, double pMKAaJKoWnqTeeQ);
    bool AiAEfoAXJ(string kpQUippL, string HWIdkGPZnJ, double nfrDxhVwN, string fBtEVmobaqEd, string aVuEgGCICC);
    string fuExYwCAkpL(int taqNNhtuHzAKHhHd, int LdBuyI, string CgtOrKFBSUrpI, int PvRUMtJZPjmKHh, double PhrJKFWsAkrdzIOE);
protected:
    double JfWYBPLruInwdL;
    string yEvlUl;

    string kVZscnWBlN(string zRivvhVhoR, string dkoUlcsm, bool btBIHAsPk, int XEzLOJiv);
    double PiCTnhWKuOkZky(string VsouWvgjRUAUG, bool hxEJZblxJd);
    void hPAjZokdK();
private:
    bool DxBvAkdf;

    double GZdtQM(int LISLuiIFwpIfM, string fHGcTaluBfZFXbh, string vcxjUnE);
    void ckKCiP(int kKvbCvfvgzxAh);
    double SgZLiLnI(bool WMwLPyQfjQ, double lBIPq, bool EZEzzgs);
    bool xLwwUrV();
    bool iozZKLcZgITU(bool HuHOqmlfnqdGKf);
    bool FMKXMbTHeQ(int jQCruuYrljrkRYJ, string EtAJQ, double YZovGaYdVRfzWy, double eiOzGrFHlJcxsKA, string VHEPGFKksd);
    int sbhmeJlhqtysc(int mHTHjpqcbVwbW, string nATcUUrpIwMKqQq, double aDQTUjNmoWolbS, int nSzqwtE);
};

void TacqUeYdPwwbZbWi::oNMmmiJvEvSGRNi()
{
    string MtesqWRm = string("SqqdnRLZwajpXjnETOPjBeBQvrljYJBWyzJhLDOuVUqIYhYByCqxaJQeboWQkJooOzcORyWkZSSGIcmbZ");

    if (MtesqWRm < string("SqqdnRLZwajpXjnETOPjBeBQvrljYJBWyzJhLDOuVUqIYhYByCqxaJQeboWQkJooOzcORyWkZSSGIcmbZ")) {
        for (int drILHFQFmbNN = 56547559; drILHFQFmbNN > 0; drILHFQFmbNN--) {
            MtesqWRm += MtesqWRm;
            MtesqWRm = MtesqWRm;
            MtesqWRm += MtesqWRm;
            MtesqWRm += MtesqWRm;
            MtesqWRm += MtesqWRm;
            MtesqWRm += MtesqWRm;
            MtesqWRm += MtesqWRm;
        }
    }

    if (MtesqWRm < string("SqqdnRLZwajpXjnETOPjBeBQvrljYJBWyzJhLDOuVUqIYhYByCqxaJQeboWQkJooOzcORyWkZSSGIcmbZ")) {
        for (int aTakcaflRm = 1660796844; aTakcaflRm > 0; aTakcaflRm--) {
            MtesqWRm += MtesqWRm;
            MtesqWRm += MtesqWRm;
            MtesqWRm += MtesqWRm;
            MtesqWRm = MtesqWRm;
            MtesqWRm += MtesqWRm;
            MtesqWRm = MtesqWRm;
            MtesqWRm = MtesqWRm;
            MtesqWRm = MtesqWRm;
            MtesqWRm += MtesqWRm;
        }
    }

    if (MtesqWRm == string("SqqdnRLZwajpXjnETOPjBeBQvrljYJBWyzJhLDOuVUqIYhYByCqxaJQeboWQkJooOzcORyWkZSSGIcmbZ")) {
        for (int YVSifv = 1820822764; YVSifv > 0; YVSifv--) {
            MtesqWRm += MtesqWRm;
            MtesqWRm = MtesqWRm;
        }
    }
}

void TacqUeYdPwwbZbWi::eieDeKDbBSKx(string ckOYc, double bikBCDF)
{
    bool PlmslPJiFI = true;
    bool kzXaD = true;

    for (int oPlcRNKQz = 969053457; oPlcRNKQz > 0; oPlcRNKQz--) {
        PlmslPJiFI = ! PlmslPJiFI;
        PlmslPJiFI = PlmslPJiFI;
        kzXaD = ! kzXaD;
        PlmslPJiFI = PlmslPJiFI;
    }
}

bool TacqUeYdPwwbZbWi::moNtYzCX(bool EjqQbtJNe, string NbygisIFJyRbd, bool cPiBxGn, double SNAre)
{
    bool SkMdDQ = false;
    double csKGUoQneRBpaKo = -638285.8508611909;
    double ahcXgWTYTzglE = -999625.6629925801;
    int atuanahsHfRorW = 876057280;
    int FCoVVqlSaO = -700697598;
    string TaAPJwiLvaY = string("EEXJiNZsbitbvAqczSeASrwibvsAfpzjfdGdtNLEFAzEnUmDIsmdWiPkBgOAkKrQmLRoFyfUzwQhrWdTLNCnCYOAjnHaiWRxtqYDoQDfGpWldKlDcJTABcJZqTnnSuMXMDflAPFAZIiepVdPIVWYzeNQEGsfPGgiapKoBIIVZutLXXxEDEbbRSmFQzsCpQjDwRxoWTkhWkcBOyVdPkSBvltGhB");
    double TldimrsoZXGtced = 325060.2575453559;
    string alJud = string("uXhoHXPMGdHXeKyXRfQeQvpQBoqYleCgehpJEYFvqhSvcNZwVyumkaFPzNrgDhSYPgEvfqbKidzCtxwuAnxgIFMToBoXZhFupgOhqDYCK");
    string eQNxzlqheOMpV = string("SDZMwLkTesOCadSPOpykZijGtVThbmUWHLXlAvfTUzoVoXEcYXnoByGfvqBElWoVxJvnWfupDTVMhPvRWcMoJDjiYQxzUEHJpYywyTyMxyCgxxiIwoHJVbJvrsNpFObgTXODwlQDmGFaHQDPNYjkpOSNwHzZpHIPxCNNlgyCGAZHAeymoAbBFxyfOxJLicLdJqlommqcNkIEmKecfekGyoyvWaiWZXApcKiLWqJvVbpBacT");
    string brTMtOws = string("JGcFMmKbnvMNIEKZxAYggKLascnWvclrIbMNnzJLTjfYxzEQQjPnEvwXEezmhvXVljTmUmLsUuJDgguSwKwxvqyoogVGcCotfYLXcXDulSHNQficKAdbJugblPtaOKWnFkbOCghMPxFvCLTGstGKZBUlKDYKIJzVovMPLVQrPxuQvYeIofgQUgXuexkDkNkByvxbDkaGGZyRlacXAlkUj");

    for (int GEScXEGd = 852037810; GEScXEGd > 0; GEScXEGd--) {
        atuanahsHfRorW /= FCoVVqlSaO;
    }

    return SkMdDQ;
}

bool TacqUeYdPwwbZbWi::UAmFJlbiLcLeffA(int mOYNB, string AHSorm, double RkzBPdCStLkTv, double YTgpAkg)
{
    string bLJNXpyYvZ = string("ACRTIyZCvAZVRyHwRVNbxIiqJwYZOXKroBjoMghJjXeNIrsXQcpEHAlwURmTmLauUfHDJRnOKRJnDVhHJwmErwaWyqBVjSysFVUYaxsKrnEKEqFlEtMLYTMZVsBVhQBBLxGpNeyM");
    bool LshddgBJC = true;
    string bfERSCP = string("oUcFIaLcAiSWCsBahdJlMNOMcEvDcCccJAUQeGPAxxDOpRAXcOGTxyzOoFCNznBEOinYQVzGrPYbndWJTLOQGUltCnsOsbgrREZKEDuwyJVzvpqYjHhIUqebNtoCuwBszcahURXYNvphhLMrOLxjArGBBlMaCBPreZYhxqnBmKIJHcZXYykHighCrZgtFZHEjUGSDVn");

    return LshddgBJC;
}

double TacqUeYdPwwbZbWi::GIsRT(int OtTGikWBAAT, double QiEbcn, bool LJoHISgD, double pMKAaJKoWnqTeeQ)
{
    int ycPzuOb = -1704656727;
    double RDtYzIPCyrzRnTy = -137876.66362148267;
    bool ZHYxSwpvYcxikdr = false;
    int vaAKFuYoYcMuR = -1529911200;
    int gWRRuKDJku = -313251080;
    bool xpQPMQT = false;
    bool IDslKonMsJJoB = false;

    if (vaAKFuYoYcMuR < -1529911200) {
        for (int upMkIkgFpgeYo = 1705854404; upMkIkgFpgeYo > 0; upMkIkgFpgeYo--) {
            ZHYxSwpvYcxikdr = ! xpQPMQT;
        }
    }

    for (int esgvoVR = 132558685; esgvoVR > 0; esgvoVR--) {
        pMKAaJKoWnqTeeQ *= pMKAaJKoWnqTeeQ;
        OtTGikWBAAT -= gWRRuKDJku;
        LJoHISgD = ! IDslKonMsJJoB;
        IDslKonMsJJoB = ! ZHYxSwpvYcxikdr;
    }

    for (int XMQlhtAQcDamk = 1671101555; XMQlhtAQcDamk > 0; XMQlhtAQcDamk--) {
        ZHYxSwpvYcxikdr = ! ZHYxSwpvYcxikdr;
    }

    return RDtYzIPCyrzRnTy;
}

bool TacqUeYdPwwbZbWi::AiAEfoAXJ(string kpQUippL, string HWIdkGPZnJ, double nfrDxhVwN, string fBtEVmobaqEd, string aVuEgGCICC)
{
    string MJrjiDjfudzWM = string("qqfQRxqQDEZwMwFbezWyBUTfBPrYVqJGpHPzWzTLjroEuTUsQbrHXdBUZMYrrbLdKhBkoeKvRTnXmPTRIlpalSKOSK");
    string tgQCtxHjQckM = string("CwdSJzvmbeCUOMrVGsfBYYEYFLXxBaLVYkWOjnMmLShNkmFvYcRMcklKWsnEePeYCMRLGLcbaPWAwMgGpcVCqDbyWDAiRcDgTtvpeFBKWyEbmlAZBiqfFiwPecrxDnHYlqNVbNWyeLaHfwqoxMbAYbeyvGROkCwelxbSzyfBQKSxyrqcIRgVjtqfRJzveHKisxhvIBXSDkWWMwtXnyLEyYWguBHgNtydCyLtmzrDz");

    if (fBtEVmobaqEd > string("PfRYcMHcJSeaKfZSYitSlES")) {
        for (int vvSrKmgSc = 917248526; vvSrKmgSc > 0; vvSrKmgSc--) {
            MJrjiDjfudzWM = HWIdkGPZnJ;
            aVuEgGCICC = kpQUippL;
            fBtEVmobaqEd += tgQCtxHjQckM;
            HWIdkGPZnJ += fBtEVmobaqEd;
            fBtEVmobaqEd += MJrjiDjfudzWM;
            MJrjiDjfudzWM = aVuEgGCICC;
            aVuEgGCICC = MJrjiDjfudzWM;
        }
    }

    for (int pCuFVW = 643042656; pCuFVW > 0; pCuFVW--) {
        fBtEVmobaqEd += tgQCtxHjQckM;
        HWIdkGPZnJ = aVuEgGCICC;
        tgQCtxHjQckM += fBtEVmobaqEd;
        MJrjiDjfudzWM += kpQUippL;
    }

    if (nfrDxhVwN <= 715934.717685074) {
        for (int JiVgpiQovRqA = 1932985326; JiVgpiQovRqA > 0; JiVgpiQovRqA--) {
            MJrjiDjfudzWM = aVuEgGCICC;
            HWIdkGPZnJ += fBtEVmobaqEd;
            fBtEVmobaqEd = aVuEgGCICC;
            HWIdkGPZnJ = aVuEgGCICC;
            kpQUippL = fBtEVmobaqEd;
            nfrDxhVwN = nfrDxhVwN;
        }
    }

    if (kpQUippL <= string("qqfQRxqQDEZwMwFbezWyBUTfBPrYVqJGpHPzWzTLjroEuTUsQbrHXdBUZMYrrbLdKhBkoeKvRTnXmPTRIlpalSKOSK")) {
        for (int ybhNxC = 508807613; ybhNxC > 0; ybhNxC--) {
            kpQUippL = MJrjiDjfudzWM;
            HWIdkGPZnJ = aVuEgGCICC;
            kpQUippL = HWIdkGPZnJ;
            aVuEgGCICC = tgQCtxHjQckM;
            HWIdkGPZnJ += HWIdkGPZnJ;
            fBtEVmobaqEd += tgQCtxHjQckM;
        }
    }

    return true;
}

string TacqUeYdPwwbZbWi::fuExYwCAkpL(int taqNNhtuHzAKHhHd, int LdBuyI, string CgtOrKFBSUrpI, int PvRUMtJZPjmKHh, double PhrJKFWsAkrdzIOE)
{
    string DpdEkYaHWiqdvLyW = string("wPiuCzUndRXkaSWaPbqzsDIUHnaXbIamAjIasLnFqHprllNlpMxEgvORqSWzDkPLLCdEXBYSrLUXByHXuUrkFvyBSeFddKFBjWNfpYjIBCRkWwdXVyqFEKgmRFFYksRKziSDwzzfsQmGxwbqSoioliBstMyJSKJnYgLJduxswWyPfcqamHVcIMNBvrBcdISDZRnkeeoJaOjYpUpZBFCtVNPMJODYYiqNGwcOzBNQJfCJmhrd");
    string LYuwkoRdfQgReSb = string("lUYabEsDseMHheuccFDqdVXkptGqYMjpgdMuhmWzQhZKoLLKjwKbBj");
    bool WBPzlVbUYpLKA = false;

    for (int iEXbOtMspd = 952338590; iEXbOtMspd > 0; iEXbOtMspd--) {
        LdBuyI += LdBuyI;
    }

    for (int qCvsw = 1669066917; qCvsw > 0; qCvsw--) {
        CgtOrKFBSUrpI = DpdEkYaHWiqdvLyW;
        WBPzlVbUYpLKA = WBPzlVbUYpLKA;
        PvRUMtJZPjmKHh /= taqNNhtuHzAKHhHd;
    }

    if (LYuwkoRdfQgReSb < string("wPiuCzUndRXkaSWaPbqzsDIUHnaXbIamAjIasLnFqHprllNlpMxEgvORqSWzDkPLLCdEXBYSrLUXByHXuUrkFvyBSeFddKFBjWNfpYjIBCRkWwdXVyqFEKgmRFFYksRKziSDwzzfsQmGxwbqSoioliBstMyJSKJnYgLJduxswWyPfcqamHVcIMNBvrBcdISDZRnkeeoJaOjYpUpZBFCtVNPMJODYYiqNGwcOzBNQJfCJmhrd")) {
        for (int FtgrOgDlbfEIsC = 2008000224; FtgrOgDlbfEIsC > 0; FtgrOgDlbfEIsC--) {
            continue;
        }
    }

    return LYuwkoRdfQgReSb;
}

string TacqUeYdPwwbZbWi::kVZscnWBlN(string zRivvhVhoR, string dkoUlcsm, bool btBIHAsPk, int XEzLOJiv)
{
    bool kIsKldFaWtEN = false;
    double ojRcSJlgkEH = -661341.8135416546;
    string LsusmvwLaajiya = string("sLjFbJNQJbjYKZpOArMwZgL");
    string uQfPLnwmbD = string("ffojSpjeDoVLmPDPvEKbDZVKRKylbnEKDYNjjjnKhoFpMwuCdbybSviVlobUARsBWCczXlFxnsnbrxRssqRbzvuZDRpysVwFxhTjAqGxQdYEhskaUiTwFnxZdGgJ");
    string KBUFLmLWolc = string("KqkWFvgrnOgRMqWfMQFHqvpVcieHruDChlINXXyBfcZhZHzwbRVbkkqjuSBaENhXobETafgffJwASwarNyGjzIAFKYuhkdpYqkkDltWOzcRpjKTrRkVnGrLWpTwxXTAeSQMnSfaVmYZoJGySZQXpvtGUFWDGIOYkrXXqqBcoOxqDSrswKCMxfkXBoAIyRMHstqzbshluAcCBvpGpovFLblGDkRPYkHA");
    double UjdgHZI = -758650.8977389856;

    for (int LYMFp = 446040021; LYMFp > 0; LYMFp--) {
        dkoUlcsm += zRivvhVhoR;
    }

    for (int NODqatqtNgpTCvd = 1898025805; NODqatqtNgpTCvd > 0; NODqatqtNgpTCvd--) {
        continue;
    }

    if (zRivvhVhoR != string("ZBiyLldnTgntUtlogAEwoZdFNJPdxIgyNlIpgD")) {
        for (int rpHbdKbeMjWHMia = 810000251; rpHbdKbeMjWHMia > 0; rpHbdKbeMjWHMia--) {
            continue;
        }
    }

    for (int UucmsQrBgGgCO = 374865403; UucmsQrBgGgCO > 0; UucmsQrBgGgCO--) {
        continue;
    }

    for (int xLKVQtWKKRfyXqxk = 1440735024; xLKVQtWKKRfyXqxk > 0; xLKVQtWKKRfyXqxk--) {
        dkoUlcsm += KBUFLmLWolc;
        KBUFLmLWolc = uQfPLnwmbD;
        KBUFLmLWolc += dkoUlcsm;
    }

    return KBUFLmLWolc;
}

double TacqUeYdPwwbZbWi::PiCTnhWKuOkZky(string VsouWvgjRUAUG, bool hxEJZblxJd)
{
    bool oRVXxJ = false;
    double QoTdCGrS = -41996.52249727605;
    string PMUILBDFWsgipC = string("oZCWJzRnlqQXOgkvJlXrQxQGvWpdWvfMPTRKpziRNcSExgWGKFjqrEXzCiSEybSDEbtfpCGmpqBNCiZgeWgyqufreQSnSSljwDqRmGLdOISnWQGHIjlMZItWrcsesQmLQFDHBCzbSZEmtfbZfAzFXwQnMmCFhVFTPJGTQsRxdjDssipKJvPMaGDmskjjrzgHuSMVBWKyQIXasgigzAaprPyLrhKhZyyAoABls");
    int iPeSNVBxgHGwULL = 434666056;
    double fmRqzFRabjrwMdU = -988188.8619490825;
    int LdYOHBtstbDWR = 1120289528;
    string dRHIKh = string("uDLMYQIlClGpYoIEV");
    bool ePNMbytMTeROFqu = true;
    int DumtODSDe = -904180791;

    if (DumtODSDe <= -904180791) {
        for (int KFcPERuI = 2109444500; KFcPERuI > 0; KFcPERuI--) {
            ePNMbytMTeROFqu = oRVXxJ;
        }
    }

    for (int EIiHPWolxmcQp = 400048743; EIiHPWolxmcQp > 0; EIiHPWolxmcQp--) {
        PMUILBDFWsgipC = dRHIKh;
    }

    for (int sKtmGBYodcyb = 1073965145; sKtmGBYodcyb > 0; sKtmGBYodcyb--) {
        hxEJZblxJd = ! ePNMbytMTeROFqu;
        oRVXxJ = ! hxEJZblxJd;
    }

    return fmRqzFRabjrwMdU;
}

void TacqUeYdPwwbZbWi::hPAjZokdK()
{
    string mxItxEEm = string("cMUXZmMmIzFVtwdrShgweYFHgmoEZFqTqLbHONIuMiBJypKRLkiAnlxRNWfOXWMseszdtBzAdluPgMlUmQafPxGeMjsaWcCHLGRzTozwRjyCNaLTveaEpJwAeFeCUIdBTYqXkDjWBRgKTIophaqNXNPiqYDSGwwlsuDAjAWPruoQfvYNdNxJvTuwVgMqZ");
    string olgNOkLq = string("GddVxolhIMAnCxpOQAFpGmbRyhAbRTFjQwwRiJpRYRXaBkDFQmpAQgUaugCnATFwoJmrxAUBeJfBpkxLxFKahdYmnJqknuvxZWYrKWIdOBeCloRjDALECqDDcVJxcGuVsExWuCHaNOsgRMPsSAvZLJPMMJKxJWSdKatckxrpEqXZhyNwULXpEmtkvDdKKKtqyAKRkeeHptVHzTMMNkakEHxFzeVYBDghRSvtvFHzrN");
    string YjbDDVhDIKuOXY = string("uqTfMUlrYAEHsdBdcLORwZOdGjUiiQvwZNyWhZXWCXePMTXAFCGlHkkCJqvZhAIUVVPxfEGqXhel");
    int fDAtFb = -1322444917;
    string ASBVWKCSx = string("PKQtyzguGUHAkohBChMvNyiBaMvXIBkREuRzfOjfleTagSksmBevydCFIJnwHPUeMYmJqywVtrbRvMzXmRwZslUUFmJjuWMygCmSbEBfHrKDljiCDziLXEHGJCZGKlFXfXsFsEwODoSXYRyBpSTVflCyglMTGyRvEPKFdGjyEefUvFQvZhobKzRtDTjWNUiCTaveHiSEDKdOj");
    int eMyiZ = -1267423620;

    if (mxItxEEm <= string("uqTfMUlrYAEHsdBdcLORwZOdGjUiiQvwZNyWhZXWCXePMTXAFCGlHkkCJqvZhAIUVVPxfEGqXhel")) {
        for (int dQdzbJyzRfMLKZJ = 395694452; dQdzbJyzRfMLKZJ > 0; dQdzbJyzRfMLKZJ--) {
            YjbDDVhDIKuOXY = ASBVWKCSx;
            mxItxEEm = ASBVWKCSx;
            fDAtFb = eMyiZ;
            YjbDDVhDIKuOXY += YjbDDVhDIKuOXY;
            ASBVWKCSx = mxItxEEm;
        }
    }
}

double TacqUeYdPwwbZbWi::GZdtQM(int LISLuiIFwpIfM, string fHGcTaluBfZFXbh, string vcxjUnE)
{
    string nOfKkBR = string("VUsAeBcQeruSmizfRpejZXLJaUfIyADJhajTbIkjDuNxfTgtFkYeJjYwBcQQXVJBgCxrGnCnBWhkPzyNEKBsGoSfkbkqsHHaODoWRCnsxHngpUTorhRlvLQzsDgFkerqsgbfhOlVRQNiBKriIjdaNYlEBI");

    return -618991.1014150865;
}

void TacqUeYdPwwbZbWi::ckKCiP(int kKvbCvfvgzxAh)
{
    double AMYoElLgekfwtx = -505142.90324884024;
    string RPIuipjoWgbleKMe = string("sDwWGKIiizrVrWjdOlPiyaLAVdwawsxXYZPXkfvYShoByHRQuUVKJJzBMRBITBilJZJQvOjlGtNeoHcYIUoRZw");

    for (int tsSTLleChTWDO = 80368505; tsSTLleChTWDO > 0; tsSTLleChTWDO--) {
        RPIuipjoWgbleKMe = RPIuipjoWgbleKMe;
    }

    if (RPIuipjoWgbleKMe >= string("sDwWGKIiizrVrWjdOlPiyaLAVdwawsxXYZPXkfvYShoByHRQuUVKJJzBMRBITBilJZJQvOjlGtNeoHcYIUoRZw")) {
        for (int QtvpBukMxnZMzx = 1057489515; QtvpBukMxnZMzx > 0; QtvpBukMxnZMzx--) {
            AMYoElLgekfwtx += AMYoElLgekfwtx;
        }
    }

    for (int HjJkzhCdiGgOfLN = 1797779229; HjJkzhCdiGgOfLN > 0; HjJkzhCdiGgOfLN--) {
        RPIuipjoWgbleKMe += RPIuipjoWgbleKMe;
        kKvbCvfvgzxAh -= kKvbCvfvgzxAh;
    }

    for (int sUypYPGlBuuhHEe = 1150820120; sUypYPGlBuuhHEe > 0; sUypYPGlBuuhHEe--) {
        kKvbCvfvgzxAh *= kKvbCvfvgzxAh;
        RPIuipjoWgbleKMe = RPIuipjoWgbleKMe;
    }

    for (int pwZYJxcncpnnag = 612860344; pwZYJxcncpnnag > 0; pwZYJxcncpnnag--) {
        AMYoElLgekfwtx += AMYoElLgekfwtx;
    }

    for (int PrjPdlqRvFmPvq = 817889508; PrjPdlqRvFmPvq > 0; PrjPdlqRvFmPvq--) {
        kKvbCvfvgzxAh = kKvbCvfvgzxAh;
        AMYoElLgekfwtx -= AMYoElLgekfwtx;
        AMYoElLgekfwtx *= AMYoElLgekfwtx;
    }
}

double TacqUeYdPwwbZbWi::SgZLiLnI(bool WMwLPyQfjQ, double lBIPq, bool EZEzzgs)
{
    string OZUIgNcmFfJhDtH = string("gmUDwlngWfuiIgQYaZcaFDTkAhiVygxjdWOlqdbrFGIwXDSlDIEiMqJIDnVsoRAJrhVjiWAXDBTRaHCRJkLCWaDHdYOBBhUQIJbSLqyJFlFdORBlLhNVHmCgJbDxFTVfObruuOAubiTDEAWJuaGSzAtowOowyOvYoQLxcwxGSeEygNtoUszybTrVXrJ");
    bool HaPgMieytfF = true;
    bool BtxGaOHJB = false;
    bool BZcxRBvsFviHKS = false;
    bool APrPUpJplu = true;
    double rZSAigMKJV = -547501.5914938982;

    if (lBIPq >= 827368.6553263486) {
        for (int nvgkZOamlGCQl = 1084744479; nvgkZOamlGCQl > 0; nvgkZOamlGCQl--) {
            APrPUpJplu = HaPgMieytfF;
            EZEzzgs = EZEzzgs;
            WMwLPyQfjQ = BtxGaOHJB;
        }
    }

    return rZSAigMKJV;
}

bool TacqUeYdPwwbZbWi::xLwwUrV()
{
    int anFIqZCDeHxBUlHa = 1641715421;
    double lAyZJ = -211583.44122895083;
    int GnasxgPyJfZmv = -1704888708;
    bool HiFCTwpMl = true;
    int qcgtIoQEJMCKiEBJ = -454493969;
    bool NPLptJ = true;
    string UzmZsJ = string("mqxQaKcjrEvXeBavNPMDBNxBWxbniRDJNKIGVaVfmxmmZdJiGDkehYdsUAgcwKWnRfnRESnyOaHmhxtEUSriOBiFsnNNHPBwwXZfVTCQceHLsRjhGgUbxPGFlXJQoaOH");

    for (int sdmvpd = 150584857; sdmvpd > 0; sdmvpd--) {
        qcgtIoQEJMCKiEBJ /= qcgtIoQEJMCKiEBJ;
        NPLptJ = HiFCTwpMl;
    }

    return NPLptJ;
}

bool TacqUeYdPwwbZbWi::iozZKLcZgITU(bool HuHOqmlfnqdGKf)
{
    int faKveljwUQE = -284675408;
    int bkLQGrOSG = 1721938664;
    string xjhxIvrgSrnMZ = string("nZpgwkMCcnQtMUfOvyOkmDxApNiInzzWsJFXDgWCCZlyBzgJpBUCKaBfcAxrWFPgDEWnCGLLqYrcMtCCgUTzmxjvUohzIb");
    double MWHhYUErMjRJVe = -637399.4690310409;
    bool eVDSBBGoCFkujNnY = true;
    bool IiUDUN = false;
    double BCfQNsUxcJ = 377278.22010134783;
    double PuzoQEPkXQhr = 1046790.1180982626;
    int CTqvdUZuXMmXffNz = 1706509218;

    for (int TaYFOjcaQPnDtc = 1560022831; TaYFOjcaQPnDtc > 0; TaYFOjcaQPnDtc--) {
        continue;
    }

    for (int qdSdrQ = 1414168297; qdSdrQ > 0; qdSdrQ--) {
        IiUDUN = ! eVDSBBGoCFkujNnY;
        BCfQNsUxcJ = MWHhYUErMjRJVe;
    }

    return IiUDUN;
}

bool TacqUeYdPwwbZbWi::FMKXMbTHeQ(int jQCruuYrljrkRYJ, string EtAJQ, double YZovGaYdVRfzWy, double eiOzGrFHlJcxsKA, string VHEPGFKksd)
{
    string NvcWwkeDHUvAaa = string("jLaDMOKelqlBPWBwReNcNaCKQHeVMolOyFUNpeznzigfVzPwlJzhqflJfuFpplGEAyFcriasFYubzqniOMmAtVpXKQUpQUudXGpNSCEKHDYlbPkTPyNAqZHwtnvrRGfAFCVgsvLkxqjwYQcrViqRsMLnQnHqAMneAtOKfFyiux");
    int KeRynqEdSzqHqczT = -2062713019;
    int ZfbuJTq = 2143880320;
    int qwSHnoAdduP = -175374544;

    for (int MhgJW = 2105364601; MhgJW > 0; MhgJW--) {
        continue;
    }

    for (int zfpjcKNRv = 1523266954; zfpjcKNRv > 0; zfpjcKNRv--) {
        eiOzGrFHlJcxsKA += eiOzGrFHlJcxsKA;
        NvcWwkeDHUvAaa = VHEPGFKksd;
        qwSHnoAdduP /= jQCruuYrljrkRYJ;
    }

    return false;
}

int TacqUeYdPwwbZbWi::sbhmeJlhqtysc(int mHTHjpqcbVwbW, string nATcUUrpIwMKqQq, double aDQTUjNmoWolbS, int nSzqwtE)
{
    bool YDKFBTgpT = false;
    string ipapiJHsxQMBsW = string("SAOgHhJQqTGghuYfwRqkOlMTOPBRPSaKJDNjUdpGYnCjPNIQpZDBGigNChEMpscRncdAUTvEpWhbylKCaUjcJDjWsEycALGtHxAngqjDhsKCaqnAOBoiWBsKKIwuLycFmvYbkkeKiVzNActMRporUztoSLMYCaJUDMIvPIEiyrQGhUZvtqGwwTOzwDRxSxhyTAiDetFyfXsnEZXdbzXpHHHgONcGYMOePBnogbnZuJQfeZcTlFtpzQA");

    for (int TGPJTuE = 2027493063; TGPJTuE > 0; TGPJTuE--) {
        continue;
    }

    return nSzqwtE;
}

TacqUeYdPwwbZbWi::TacqUeYdPwwbZbWi()
{
    this->oNMmmiJvEvSGRNi();
    this->eieDeKDbBSKx(string("NysouXiHYdXfoFkcdsXRBKCxJvpFPyVESTdxGsPmyrgaNphsoQMrHqfxbONJZvzXrisxSiItIHAVniMKCdjdWFNxyfeCxoDPvEALhUKviiWKyGTuyBsZHkBhyltsIrijqpbSfPRdSzxDLXLyTmMiFtvXotOyqNkXDzzblrfXnjAcrFVOhXTEbTdDLzVcbMxP"), -206334.82096260344);
    this->moNtYzCX(false, string("cvgFqeaDheEfmWsfKWeJQRRWPTNMulCQGGzKHNGjDqsfEqcQIuyAtgQnQpfzgnHanyJBQkMmUtIlRCuIZPOBnGVPKnBWKlVmhNFWzaNCBUeeBouQaXTGsWOPBPwMIsSMdBVVHsEszLFRDaKIYXkaPlCkrMxBENYRaf"), true, 894870.1016250405);
    this->UAmFJlbiLcLeffA(-1454984038, string("qLSHyHyIwpOKpgLXizUMHnYmlGgPOPNcwqwQTtmbClkfjudkJsTcLfduqiiuJydEntjnEazXiJtLHPKgzdXdDGGgidVcaNlilBjSxJjkFYJ"), 106161.62318157063, 915155.6418384691);
    this->GIsRT(-1763486565, -457133.86241430964, true, -359848.71428029315);
    this->AiAEfoAXJ(string("GqzCPCHBwze"), string("hRoUEvNfSKyQoXURMkygETKHHGxbyPXjhmaZZXjGSoMVyIfYINMirvqVyvrGdGlONfLIfKFtMKXMWSfNpFSvDoaDnLrkrntTsnJyYEyJYuwxAjaqUDBFOXjtecXszgkODOArjrJQCWypNuOXsUjNknbntSwFYkgJkrNYrjPqvBE"), 715934.717685074, string("PfRYcMHcJSeaKfZSYitSlES"), string("eMkwyJEKogMSdbnYylnLBpncTziERhCVXVQEsIZKXVZtttzHJnIdsgpEiFFEYWEjozTnFzulQQeyxSAGbtCotTnljnVQtkFTCKSWismyEQJgDpPBGIBWYbDncNZxaSxCjYboUCwXLnWdvLIrXUfaCryvwWuQuIKqSuloPFoNBfIIrKtiEqbynnNvTxjY"));
    this->fuExYwCAkpL(-837123805, -225640978, string("ufgSLEaACkvYKRwcejjqKQIcCjkGn"), -2008095212, 147724.2253323826);
    this->kVZscnWBlN(string("ZBiyLldnTgntUtlogAEwoZdFNJPdxIgyNlIpgD"), string("ftpxfxlRNSobnzzgfGDWUFUHiEineVTKXycjGCdULNbndgKhpYdVlWNHVcqSsYGVuvTQQznaz"), true, 2066396806);
    this->PiCTnhWKuOkZky(string("uPOcuSXQbhUNxORLtGHNfzINrRvmZmkwxioRtciAzQFGhUglAeEpsFKxVMcbHyAswCS"), true);
    this->hPAjZokdK();
    this->GZdtQM(834162215, string("dOQkFddTMJxSadZHUxMLNwmHrhjZEdCwNjhkbrDUDHvPdNcwyyqkqJmadTxyuBpItBnnJCSgVslMQKoXraSQIzArrEutIaupuLEWPMCepJTfrMyreJAfIKwAuRea"), string("RWdwpKBzvyCklTYJAztcIyzzgAzzOkcxmKnDqqtnhqlVlzDxviPsrxSvKdizIItNDZvtFBJcbAIwGxyvxrQEFllZCStlEr"));
    this->ckKCiP(-873568391);
    this->SgZLiLnI(false, 827368.6553263486, false);
    this->xLwwUrV();
    this->iozZKLcZgITU(false);
    this->FMKXMbTHeQ(-722743197, string("FykGPBrEJvdPWkUYKyXKdOTzbnwKcVsirznSyVwLlOaeVNltPWSrvfUAnoHfQqbRuOEDEHSCOZCzXBnCNHYNgDmMCFCJqfSaCHLkLGYDXwFpElVxDSzHiQTWuAUyvxqkPOqywBbWWcj"), -374041.92669814674, 634434.5915415025, string("oSsQOLhukVaGupCLsLKguKWPJqGJMyEQUbFMQIGP"));
    this->sbhmeJlhqtysc(-197884912, string("vleCnLEfAokeRRGYmhagca"), 91772.45993678021, 2125178581);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SDqpiHlZ
{
public:
    string GKygHxibj;
    string EzfaERC;
    string NVtkebzpun;

    SDqpiHlZ();
    string XvEXjJKyxEemSyuR(string ocKAYDCrLnO, double SlTnhdTVtBrXxV);
    double QvHhwvukA(int FwmOsdarW);
    string HHomqwZ(string DjGhdgFWsbzeMujw, int ChgJnTBC, int kLmbGLWVOEaSQ, int TgzQwvsdhptsmBb, bool JkLsM);
    bool BHqkz(double TDXRiuiRI, string KIIJG, int poQbCtsSxO, string gFGQt, bool ZNucpWA);
    bool wAlqSqXiyyXU(double rHHkmODusALln, bool xDLAIZcCHkn, string GLEjPKO);
protected:
    double FSwnSM;
    double ZodKtaVLqarWr;

    string psQMculFFAhyxQtc(double qxRYzs, bool RNoRbyGIjfY);
    int iygSLqhcgrOJQbg(string kKeKrYtPfvMRw, bool rufUFirLKw, bool DYXZFOu, bool eeUpgNgfGDkMAVL, bool KDnnNCKZcsh);
    double TxpFjd();
    string DWVFjt(int LkbTYUmCTReNCBG, int idUYWgJliHx, int YPuguxTLJFjZTMIr, string aeuDBHhBY);
    string nuyTuVNMKiMNj(string rPpTkClcG, string jOcSDnTFjkZj, string QKbWyrVhhfOJoh, string WxsKGda);
    bool nmiqYkPgNqAkKnVq(bool geqcQyYAuynwc, string MSylPsFcyMWcDs);
    bool OTZBF(string FTrOAnV, string eXRqOmcwdsjn);
    double cuYNQWzmRivDmdd();
private:
    int VwLsridcpopJV;
    string rLnZKyOXe;
    string pEExfKIjxHOOuzta;
    double dlHJRFxzDMJo;
    int susDgAjji;
    string WdfBJtavRQ;

    void SlmOURpSbYu();
    string eNqPgebiNF(double FYtPomKxUJtsKTyX, int AjjwJGT);
    int wcdoUointOsBR();
    int qqyBytHyiIDah(bool sdDNVFkZNZ, double EXUuCics, double TNKSdAfwTjK);
    int HbtOcL();
};

string SDqpiHlZ::XvEXjJKyxEemSyuR(string ocKAYDCrLnO, double SlTnhdTVtBrXxV)
{
    bool YgUAHb = false;
    double nPwqWy = 221500.30569287014;

    if (nPwqWy != 1016856.1651388938) {
        for (int IowNwPligwImmAWT = 377818634; IowNwPligwImmAWT > 0; IowNwPligwImmAWT--) {
            ocKAYDCrLnO = ocKAYDCrLnO;
            nPwqWy /= nPwqWy;
            ocKAYDCrLnO += ocKAYDCrLnO;
            nPwqWy -= SlTnhdTVtBrXxV;
        }
    }

    for (int aYHoafTByVrtcZ = 165773923; aYHoafTByVrtcZ > 0; aYHoafTByVrtcZ--) {
        YgUAHb = YgUAHb;
    }

    return ocKAYDCrLnO;
}

double SDqpiHlZ::QvHhwvukA(int FwmOsdarW)
{
    double BuIqGafGmzmEPvoE = -360098.35385147814;
    int VPsLlAZpl = -682656180;
    double YoTCnBF = 130315.25680746464;
    double KhDBNyVpeOWKuzE = 847817.6046139374;
    int YZKMS = -29654474;
    bool GakvAzLp = false;
    double jDzIrusSPKQpoVP = -919614.3054040549;
    string FddgEIBR = string("CpszjiUjmlqTsBDLKbYQGQbIMdfEkqxyWzdOtzHBUGdGVcfADbwFpGLOnmVgDfoKtxGZaJlodvDzvzHVTUvQkbkkZXXCKBRqcpvHpEudWVPHVwtomuTlsQeHUUsEpybeNSRSFuvDnllLBgoCpZvoajdeorvwsGhXHkyDTYJfVXzGriyLkYEOZQGwhEMoazpSOQonjaVNJjcdmmFjIKgyuZulmqPYDrSaNZxRxqdMOEgbUEWdMwfo");
    bool mCOBDoMXtYcV = true;
    string LlDVMGgzKsv = string("XyxeqAaubfEQVyIPEwWuKRtsZG");

    if (jDzIrusSPKQpoVP > 130315.25680746464) {
        for (int fWiHHE = 136573130; fWiHHE > 0; fWiHHE--) {
            FddgEIBR = FddgEIBR;
        }
    }

    for (int aAwGtiYaFeb = 1629906754; aAwGtiYaFeb > 0; aAwGtiYaFeb--) {
        BuIqGafGmzmEPvoE /= KhDBNyVpeOWKuzE;
        YoTCnBF /= BuIqGafGmzmEPvoE;
    }

    return jDzIrusSPKQpoVP;
}

string SDqpiHlZ::HHomqwZ(string DjGhdgFWsbzeMujw, int ChgJnTBC, int kLmbGLWVOEaSQ, int TgzQwvsdhptsmBb, bool JkLsM)
{
    double MDveSNOSeHpmkn = 794278.3688463948;
    int XHxNpRUmz = 780816072;

    if (ChgJnTBC != 780816072) {
        for (int VXPcMWt = 1932617329; VXPcMWt > 0; VXPcMWt--) {
            XHxNpRUmz = ChgJnTBC;
            ChgJnTBC /= XHxNpRUmz;
        }
    }

    for (int FIZPbQvclCNoRIvP = 696316217; FIZPbQvclCNoRIvP > 0; FIZPbQvclCNoRIvP--) {
        TgzQwvsdhptsmBb += XHxNpRUmz;
        TgzQwvsdhptsmBb /= XHxNpRUmz;
    }

    for (int kLHgmpSnEan = 1569495644; kLHgmpSnEan > 0; kLHgmpSnEan--) {
        DjGhdgFWsbzeMujw += DjGhdgFWsbzeMujw;
    }

    for (int IIKbiNdzM = 1180006855; IIKbiNdzM > 0; IIKbiNdzM--) {
        TgzQwvsdhptsmBb += ChgJnTBC;
    }

    for (int nijAhzCvmPlwVUUt = 2024342484; nijAhzCvmPlwVUUt > 0; nijAhzCvmPlwVUUt--) {
        TgzQwvsdhptsmBb -= ChgJnTBC;
        ChgJnTBC /= TgzQwvsdhptsmBb;
    }

    return DjGhdgFWsbzeMujw;
}

bool SDqpiHlZ::BHqkz(double TDXRiuiRI, string KIIJG, int poQbCtsSxO, string gFGQt, bool ZNucpWA)
{
    int honfggck = 712330257;
    int DIGscidnxdRH = -1506849934;
    bool nqBroq = true;

    for (int fdJyoBVDllzpbyYi = 1606313104; fdJyoBVDllzpbyYi > 0; fdJyoBVDllzpbyYi--) {
        continue;
    }

    for (int XcxloJGIfDRramz = 93157274; XcxloJGIfDRramz > 0; XcxloJGIfDRramz--) {
        nqBroq = nqBroq;
        TDXRiuiRI += TDXRiuiRI;
        nqBroq = ZNucpWA;
    }

    for (int NofCJqyOUmaZoq = 214031540; NofCJqyOUmaZoq > 0; NofCJqyOUmaZoq--) {
        DIGscidnxdRH += poQbCtsSxO;
    }

    for (int LNorRxAKRjApdCkB = 99259343; LNorRxAKRjApdCkB > 0; LNorRxAKRjApdCkB--) {
        ZNucpWA = ! nqBroq;
    }

    return nqBroq;
}

bool SDqpiHlZ::wAlqSqXiyyXU(double rHHkmODusALln, bool xDLAIZcCHkn, string GLEjPKO)
{
    int buVpDBgMdNZ = 1423372881;
    bool Raszrz = false;
    bool oKPviWgvzntvMw = true;
    double igvOtcv = -449788.3083027534;
    int znkUXhOTWUZQyZZb = 799902481;
    string TKjjl = string("DBSBaKYSYjTANKrcgunSkz");
    int dOlPciX = -1414559065;
    int NrGuTZRMS = 427115055;
    bool ghiwFSFECvZwrvt = true;
    bool IeIsgRw = true;

    for (int AEuCkwy = 766124398; AEuCkwy > 0; AEuCkwy--) {
        NrGuTZRMS *= znkUXhOTWUZQyZZb;
        xDLAIZcCHkn = ! xDLAIZcCHkn;
        buVpDBgMdNZ -= buVpDBgMdNZ;
    }

    for (int GXovNKEFhKFFUrDZ = 2015818968; GXovNKEFhKFFUrDZ > 0; GXovNKEFhKFFUrDZ--) {
        xDLAIZcCHkn = Raszrz;
        znkUXhOTWUZQyZZb /= buVpDBgMdNZ;
        znkUXhOTWUZQyZZb *= dOlPciX;
        znkUXhOTWUZQyZZb += NrGuTZRMS;
    }

    return IeIsgRw;
}

string SDqpiHlZ::psQMculFFAhyxQtc(double qxRYzs, bool RNoRbyGIjfY)
{
    string yESIJipsywUWXj = string("aaeYpwOaoqfCJrqNiqbngrhflkANTwmktLBfQvouolCBcrdfowySogkEi");

    for (int nKSXGOuzTXiult = 775697557; nKSXGOuzTXiult > 0; nKSXGOuzTXiult--) {
        continue;
    }

    if (yESIJipsywUWXj >= string("aaeYpwOaoqfCJrqNiqbngrhflkANTwmktLBfQvouolCBcrdfowySogkEi")) {
        for (int NxoRCy = 921959189; NxoRCy > 0; NxoRCy--) {
            yESIJipsywUWXj = yESIJipsywUWXj;
            yESIJipsywUWXj = yESIJipsywUWXj;
        }
    }

    for (int vEUYTbgiSgzfH = 673342747; vEUYTbgiSgzfH > 0; vEUYTbgiSgzfH--) {
        continue;
    }

    for (int WlCSiYvwCna = 1949081947; WlCSiYvwCna > 0; WlCSiYvwCna--) {
        qxRYzs = qxRYzs;
    }

    if (qxRYzs != 1015683.6926363796) {
        for (int ejbOihpQ = 881125426; ejbOihpQ > 0; ejbOihpQ--) {
            qxRYzs -= qxRYzs;
        }
    }

    return yESIJipsywUWXj;
}

int SDqpiHlZ::iygSLqhcgrOJQbg(string kKeKrYtPfvMRw, bool rufUFirLKw, bool DYXZFOu, bool eeUpgNgfGDkMAVL, bool KDnnNCKZcsh)
{
    double zbOYPnsqdI = 557802.7325515897;

    for (int oihfWggm = 941489893; oihfWggm > 0; oihfWggm--) {
        KDnnNCKZcsh = ! rufUFirLKw;
        DYXZFOu = ! KDnnNCKZcsh;
        DYXZFOu = ! KDnnNCKZcsh;
        eeUpgNgfGDkMAVL = ! KDnnNCKZcsh;
        eeUpgNgfGDkMAVL = DYXZFOu;
        DYXZFOu = ! eeUpgNgfGDkMAVL;
    }

    return 946670768;
}

double SDqpiHlZ::TxpFjd()
{
    bool pNKWlulxT = false;
    bool WexxZhDxa = false;

    if (WexxZhDxa == false) {
        for (int BGSeNCExSDZ = 1808702922; BGSeNCExSDZ > 0; BGSeNCExSDZ--) {
            WexxZhDxa = ! WexxZhDxa;
            WexxZhDxa = ! WexxZhDxa;
            WexxZhDxa = ! WexxZhDxa;
            pNKWlulxT = ! WexxZhDxa;
            pNKWlulxT = WexxZhDxa;
        }
    }

    if (WexxZhDxa != false) {
        for (int TDRmpduY = 1361042735; TDRmpduY > 0; TDRmpduY--) {
            WexxZhDxa = ! WexxZhDxa;
            WexxZhDxa = ! WexxZhDxa;
            WexxZhDxa = ! WexxZhDxa;
            pNKWlulxT = ! pNKWlulxT;
            WexxZhDxa = pNKWlulxT;
            WexxZhDxa = ! pNKWlulxT;
            pNKWlulxT = ! WexxZhDxa;
            WexxZhDxa = ! WexxZhDxa;
            WexxZhDxa = ! pNKWlulxT;
        }
    }

    if (pNKWlulxT == false) {
        for (int dwDhGQIR = 1328027202; dwDhGQIR > 0; dwDhGQIR--) {
            pNKWlulxT = ! pNKWlulxT;
            pNKWlulxT = ! pNKWlulxT;
            WexxZhDxa = WexxZhDxa;
            WexxZhDxa = pNKWlulxT;
            WexxZhDxa = pNKWlulxT;
        }
    }

    if (WexxZhDxa != false) {
        for (int CVpfBSLpsA = 2073345384; CVpfBSLpsA > 0; CVpfBSLpsA--) {
            pNKWlulxT = ! WexxZhDxa;
            WexxZhDxa = ! WexxZhDxa;
            WexxZhDxa = WexxZhDxa;
            pNKWlulxT = WexxZhDxa;
            pNKWlulxT = pNKWlulxT;
            pNKWlulxT = pNKWlulxT;
            WexxZhDxa = pNKWlulxT;
            WexxZhDxa = ! pNKWlulxT;
            WexxZhDxa = ! WexxZhDxa;
        }
    }

    if (WexxZhDxa != false) {
        for (int wLYUpQyGlVwc = 716794944; wLYUpQyGlVwc > 0; wLYUpQyGlVwc--) {
            WexxZhDxa = ! WexxZhDxa;
        }
    }

    if (pNKWlulxT == false) {
        for (int FrgDz = 1709926326; FrgDz > 0; FrgDz--) {
            pNKWlulxT = ! WexxZhDxa;
            WexxZhDxa = ! WexxZhDxa;
            pNKWlulxT = WexxZhDxa;
        }
    }

    return -214544.141639731;
}

string SDqpiHlZ::DWVFjt(int LkbTYUmCTReNCBG, int idUYWgJliHx, int YPuguxTLJFjZTMIr, string aeuDBHhBY)
{
    int sLMFyGWwLPDv = 1878106513;
    int DbIzNWqzZULirq = -1677320223;
    int IZmibQBwPAFvEdJ = -1812832422;
    string xzUbOiolAAdOewo = string("pQYVSeDQbAIjXPGTSMrHMqObQgwtOHSEodACmsBbVeLpSDDWrObVpZQPVKpeIXwVWFpZkeCzcrPhMeHHWKfidyqlrBylqpemouKqWesSWjwZwugTyBfbeuJOTgpkSMRIxoGS");
    bool TSZLpU = true;
    bool WaeOOuUjlZrdlaT = false;
    int cFIOesBfNRhBgM = 1662309054;
    double vmfjNzWvjpTg = -195059.52401697452;
    string aKfTSfybNCbMLM = string("GlsZWqlrBdnutqZAXhnXyzBtUvKfyyIdsrOvyGxKcXJavcr");

    for (int zfDgyEmuwQse = 932611757; zfDgyEmuwQse > 0; zfDgyEmuwQse--) {
        WaeOOuUjlZrdlaT = TSZLpU;
        idUYWgJliHx -= cFIOesBfNRhBgM;
        sLMFyGWwLPDv /= YPuguxTLJFjZTMIr;
    }

    for (int qjkcCblhPPnkgt = 1571541945; qjkcCblhPPnkgt > 0; qjkcCblhPPnkgt--) {
        cFIOesBfNRhBgM += idUYWgJliHx;
        cFIOesBfNRhBgM += LkbTYUmCTReNCBG;
        YPuguxTLJFjZTMIr += DbIzNWqzZULirq;
        idUYWgJliHx -= IZmibQBwPAFvEdJ;
        WaeOOuUjlZrdlaT = TSZLpU;
        IZmibQBwPAFvEdJ = LkbTYUmCTReNCBG;
    }

    for (int goWhXIk = 913408898; goWhXIk > 0; goWhXIk--) {
        YPuguxTLJFjZTMIr -= cFIOesBfNRhBgM;
        IZmibQBwPAFvEdJ *= YPuguxTLJFjZTMIr;
        DbIzNWqzZULirq += idUYWgJliHx;
        IZmibQBwPAFvEdJ += sLMFyGWwLPDv;
    }

    if (TSZLpU != false) {
        for (int gWUqOLw = 588441633; gWUqOLw > 0; gWUqOLw--) {
            idUYWgJliHx -= DbIzNWqzZULirq;
            cFIOesBfNRhBgM = cFIOesBfNRhBgM;
            YPuguxTLJFjZTMIr += YPuguxTLJFjZTMIr;
            YPuguxTLJFjZTMIr = YPuguxTLJFjZTMIr;
        }
    }

    if (sLMFyGWwLPDv < -1677320223) {
        for (int ERDjlptWuZAfTVl = 391539835; ERDjlptWuZAfTVl > 0; ERDjlptWuZAfTVl--) {
            cFIOesBfNRhBgM /= idUYWgJliHx;
        }
    }

    for (int mQPjLjBmpmdUjf = 821882359; mQPjLjBmpmdUjf > 0; mQPjLjBmpmdUjf--) {
        TSZLpU = ! TSZLpU;
    }

    return aKfTSfybNCbMLM;
}

string SDqpiHlZ::nuyTuVNMKiMNj(string rPpTkClcG, string jOcSDnTFjkZj, string QKbWyrVhhfOJoh, string WxsKGda)
{
    double BRdAIA = 829284.1833513855;
    int egFuMoDTSl = 712024445;
    bool HWzBkjNdmjzZ = true;

    if (QKbWyrVhhfOJoh != string("QIwHsZgsTdGEomKBpQeNBIiGwZJjJDyCPjYWDOFgtIQgkLjhLHQmhZBBqfxsPeibUtUokEvhExf")) {
        for (int aZfCpunbbHAILu = 964192140; aZfCpunbbHAILu > 0; aZfCpunbbHAILu--) {
            continue;
        }
    }

    for (int oIcZXrzPajDw = 1152641823; oIcZXrzPajDw > 0; oIcZXrzPajDw--) {
        WxsKGda = WxsKGda;
        jOcSDnTFjkZj = jOcSDnTFjkZj;
        QKbWyrVhhfOJoh = WxsKGda;
    }

    for (int fOeCdJGfKj = 465012563; fOeCdJGfKj > 0; fOeCdJGfKj--) {
        jOcSDnTFjkZj += WxsKGda;
    }

    for (int dFFvmHVSt = 1396274543; dFFvmHVSt > 0; dFFvmHVSt--) {
        jOcSDnTFjkZj = jOcSDnTFjkZj;
        WxsKGda = QKbWyrVhhfOJoh;
        jOcSDnTFjkZj = jOcSDnTFjkZj;
        BRdAIA = BRdAIA;
    }

    if (QKbWyrVhhfOJoh > string("QIwHsZgsTdGEomKBpQeNBIiGwZJjJDyCPjYWDOFgtIQgkLjhLHQmhZBBqfxsPeibUtUokEvhExf")) {
        for (int hthKLVEFERR = 1056661365; hthKLVEFERR > 0; hthKLVEFERR--) {
            QKbWyrVhhfOJoh = QKbWyrVhhfOJoh;
            rPpTkClcG += rPpTkClcG;
            HWzBkjNdmjzZ = HWzBkjNdmjzZ;
            WxsKGda += jOcSDnTFjkZj;
        }
    }

    return WxsKGda;
}

bool SDqpiHlZ::nmiqYkPgNqAkKnVq(bool geqcQyYAuynwc, string MSylPsFcyMWcDs)
{
    string kEgjEzMYAM = string("kDCbJJtfXtcVbrQhDeifkvlMrBHDdvEEjTZOtskPuhyxqioNzaiiJHlroUAFLJRDGblhXfjfbvbvxazcJDBtMqgpSBhZksmXmBraUrYmiViQaYkwgPgckalzFGiDeoVCWormfoaSrHJkSmtlCoVbwDPzszvaqpeaTqygcCIjucmXRCxExJHIdGIIPgdJsfCsgfzchRhXcTYgxlNGQaXfsbnfeMvbGZDqnIyTzfILyTKqiMmblNMNQB");
    string NjsQaogZsesHVNS = string("vFCCKRPWLIVkVUqAAKhJITwKVymzWDld");
    int hVzDKbTpO = 1188223417;
    bool ouSLSHC = false;
    int xedSkLkYhwaFrdR = -227072502;
    double wXPdjguB = 817449.0777220003;
    double bEDmUJZz = -875899.910139568;
    double FfRfeC = 689737.8927190823;

    for (int VYuYcEKVqjAInbH = 1583380363; VYuYcEKVqjAInbH > 0; VYuYcEKVqjAInbH--) {
        FfRfeC /= wXPdjguB;
        MSylPsFcyMWcDs += MSylPsFcyMWcDs;
        kEgjEzMYAM += MSylPsFcyMWcDs;
    }

    for (int jrhUkJTR = 186138578; jrhUkJTR > 0; jrhUkJTR--) {
        continue;
    }

    return ouSLSHC;
}

bool SDqpiHlZ::OTZBF(string FTrOAnV, string eXRqOmcwdsjn)
{
    bool gqGcEDbbDWqlq = true;
    int wWkbTYhMte = 1732762317;
    int tVMKDrPK = -986834824;

    if (eXRqOmcwdsjn != string("xpavCuMkDRBWCSbKNDeaQURCmLPBebRZegXFjKdUtXaNvfVkGGyTifmbOOtrxsDJoohqLvZkOLivTYmDYbXioO")) {
        for (int xVRNXsFhEWoeqfb = 459650354; xVRNXsFhEWoeqfb > 0; xVRNXsFhEWoeqfb--) {
            eXRqOmcwdsjn += FTrOAnV;
        }
    }

    for (int noXCVWup = 1689805665; noXCVWup > 0; noXCVWup--) {
        FTrOAnV += eXRqOmcwdsjn;
        eXRqOmcwdsjn = FTrOAnV;
        gqGcEDbbDWqlq = ! gqGcEDbbDWqlq;
    }

    for (int SGbrlDRzVYJP = 1881270452; SGbrlDRzVYJP > 0; SGbrlDRzVYJP--) {
        eXRqOmcwdsjn += eXRqOmcwdsjn;
        eXRqOmcwdsjn += FTrOAnV;
        tVMKDrPK *= wWkbTYhMte;
    }

    if (tVMKDrPK != 1732762317) {
        for (int gSvsMY = 416801981; gSvsMY > 0; gSvsMY--) {
            eXRqOmcwdsjn += eXRqOmcwdsjn;
        }
    }

    for (int aRJGc = 220503873; aRJGc > 0; aRJGc--) {
        continue;
    }

    return gqGcEDbbDWqlq;
}

double SDqpiHlZ::cuYNQWzmRivDmdd()
{
    bool nQfwTs = true;

    if (nQfwTs == true) {
        for (int CAHSdWthfPyetL = 344302622; CAHSdWthfPyetL > 0; CAHSdWthfPyetL--) {
            nQfwTs = nQfwTs;
            nQfwTs = ! nQfwTs;
            nQfwTs = ! nQfwTs;
            nQfwTs = ! nQfwTs;
            nQfwTs = nQfwTs;
            nQfwTs = ! nQfwTs;
            nQfwTs = nQfwTs;
        }
    }

    return 559361.5216888742;
}

void SDqpiHlZ::SlmOURpSbYu()
{
    string suYQff = string("vtDXPlciKdGEPmWKCwoWUfGhDJEiSzjlLOXKIpWRruqyYiUYGtpIDEWeJ");
    bool coMcD = false;
    double MhtbDdE = 172756.7469757544;
    int XEUBvbCEYWm = -1954874431;
    double KSdaXodlaNJAAxP = -422757.75079545454;
    bool rvPyvGoCJOQjXGn = true;
    bool JZxygw = true;
    int UGZZxfWGFR = -1312617185;

    for (int DnaVz = 86077382; DnaVz > 0; DnaVz--) {
        continue;
    }

    for (int SKxymADxhwlnTPi = 1034326218; SKxymADxhwlnTPi > 0; SKxymADxhwlnTPi--) {
        coMcD = rvPyvGoCJOQjXGn;
        rvPyvGoCJOQjXGn = ! rvPyvGoCJOQjXGn;
        KSdaXodlaNJAAxP -= KSdaXodlaNJAAxP;
    }

    for (int zGHvPrPYhAOIOui = 1761893277; zGHvPrPYhAOIOui > 0; zGHvPrPYhAOIOui--) {
        rvPyvGoCJOQjXGn = ! JZxygw;
    }

    for (int yUAvoQEWy = 1704308652; yUAvoQEWy > 0; yUAvoQEWy--) {
        XEUBvbCEYWm -= UGZZxfWGFR;
        KSdaXodlaNJAAxP /= KSdaXodlaNJAAxP;
    }

    for (int zEXdP = 1244557099; zEXdP > 0; zEXdP--) {
        rvPyvGoCJOQjXGn = JZxygw;
        UGZZxfWGFR *= XEUBvbCEYWm;
    }

    for (int SJPSQoLDgU = 793816144; SJPSQoLDgU > 0; SJPSQoLDgU--) {
        KSdaXodlaNJAAxP *= MhtbDdE;
        XEUBvbCEYWm += UGZZxfWGFR;
    }
}

string SDqpiHlZ::eNqPgebiNF(double FYtPomKxUJtsKTyX, int AjjwJGT)
{
    string NIVZfUpX = string("mRJDAxCkVGMXcBQsRcOsguLnCQPmmnGmUhoUIEFMArsCwDqatYajPzRRtDGxRxHerlQhUhMadRBvbEwNyZktUEnsDidShsJaSfXWbJgdIwUAhEgBdHxLTTGVWknqXmRdQJwwmxABjQDVzuXGTIHsRXrYSVsUNIwrcRIriZdbMjVoNmORWjVlCEyohDfdgSNmLkgniBoHsUzVkPJu");
    string SfEjdeWhceq = string("ppIysVvMKoVevnmHZyLYlTdEKruPCVXdeonryKTKxMyMbHgsFIWrBDqjWDRECchrBXhOvvoIfdGkaEspYVsbWMAd");
    bool EJAZdpeLkS = true;
    string MwHKzDcCM = string("dkMPbLIqLRPdzskcHTUaUsrjOAKGonNRIeWhmYihTloNlZTyaiVxOVHUAYkmhCgAIZANOEQCRqydqGEvwPnHObyrdZfxegOZmzaXoRFaWiZJpgqWRZPFtQkuIjGarywPtlnfXOzbRODTwRjlnCqszJGXrLnvHTIwYkncMmBvoyEuWFtjFAenNdDgunBLJQiROrLDSQzPBsTTZeOnqBXkPLGfFlIBgweeUPPQzvYsTTbrwqjVemxTYQPAtSRJE");
    double mUFsbanCXDSr = 907643.2033763924;
    double UQvGlDHdvLKKFw = -589355.8770104428;
    int kNuZlWIZ = -682122500;
    int vfkwwjLOMvDJoUMq = 36044329;
    string JSkAZHcEpxOPCpPG = string("nkCoCxvBqhikABWKNxqBxnHUmJVvhRkqsUFNQdaTAbfUhetvIyvpoSQOjPxeTSGXYBICwYZAyDhjcsCsXTuSiGxvCnhdVmJXnBqjCRioSsTcrAPpVYleMPAZXvJyvehSnrBjjGBpLLSfwPxuNfHdIUCyjnMByIkFoQFCYcNUyTZJhGtfXNBUSkMNOCCUXBGnqPciDKwhumFUzbvxmeBgQQrlTdoOCaLNxqiEUeILqHcsawfeLnIaDLB");
    int SgJrUozD = 705368112;

    for (int ApPCWFFO = 268575662; ApPCWFFO > 0; ApPCWFFO--) {
        UQvGlDHdvLKKFw /= FYtPomKxUJtsKTyX;
        UQvGlDHdvLKKFw /= UQvGlDHdvLKKFw;
        SgJrUozD -= kNuZlWIZ;
    }

    for (int lbDzRaNmpYFr = 1464937341; lbDzRaNmpYFr > 0; lbDzRaNmpYFr--) {
        continue;
    }

    for (int yHrIlCYdbgwx = 144414058; yHrIlCYdbgwx > 0; yHrIlCYdbgwx--) {
        kNuZlWIZ *= kNuZlWIZ;
    }

    for (int CPNPS = 2141809220; CPNPS > 0; CPNPS--) {
        UQvGlDHdvLKKFw -= mUFsbanCXDSr;
        FYtPomKxUJtsKTyX /= mUFsbanCXDSr;
    }

    if (MwHKzDcCM <= string("mRJDAxCkVGMXcBQsRcOsguLnCQPmmnGmUhoUIEFMArsCwDqatYajPzRRtDGxRxHerlQhUhMadRBvbEwNyZktUEnsDidShsJaSfXWbJgdIwUAhEgBdHxLTTGVWknqXmRdQJwwmxABjQDVzuXGTIHsRXrYSVsUNIwrcRIriZdbMjVoNmORWjVlCEyohDfdgSNmLkgniBoHsUzVkPJu")) {
        for (int aSHKBXuUasjLxOmu = 1776410023; aSHKBXuUasjLxOmu > 0; aSHKBXuUasjLxOmu--) {
            UQvGlDHdvLKKFw *= FYtPomKxUJtsKTyX;
            kNuZlWIZ = AjjwJGT;
            AjjwJGT -= vfkwwjLOMvDJoUMq;
            vfkwwjLOMvDJoUMq += vfkwwjLOMvDJoUMq;
        }
    }

    for (int YmvEb = 366576370; YmvEb > 0; YmvEb--) {
        AjjwJGT /= kNuZlWIZ;
    }

    return JSkAZHcEpxOPCpPG;
}

int SDqpiHlZ::wcdoUointOsBR()
{
    int lgfXECnzhuL = 1055783367;
    string YfgKSPLTaQl = string("DuJXrnoDDCdoPyLwIyfPZwSTsSQlMotsQDxbOGBzfDqWjTqHHpvOxvBYaXcvofxmPjIUfJRZuppbJOGVavUEPdZUctuMuWUBIpdBRpBYaJLZuJiYRcesjgYgmBPVehmuvDmSWpPwRCgdggCkfJBRDJcFJYuumYrseINELcduGdElTychYnUIUzcKIOfeKwWLPCcDANsJKkSaqrftBLUHqdbBbcqrZrfHIHUtFVugNMDShSBunHuJARn");
    bool jpZktnY = false;
    string jeHgYpP = string("MDBUEZmYGppbktqDLAnYHFZwMKAsVxRmAVPODWassVA");
    double hpsWZkwJuMeFsw = 587451.5035743242;
    string ZOErgIWeBTlFaKV = string("axosQaBOQocyHfobSRraJw");
    int xSvtuFsoUuETzui = 214694228;
    double ZNLRTk = 139189.07058497323;
    double BrEsAnzmtyhlk = 257415.5097306924;
    int fEdntgufnqU = -799681670;

    for (int vytydMQbSy = 1732183204; vytydMQbSy > 0; vytydMQbSy--) {
        ZNLRTk -= BrEsAnzmtyhlk;
        YfgKSPLTaQl = YfgKSPLTaQl;
        jeHgYpP = jeHgYpP;
    }

    for (int JTCERGdTtMMGHeQC = 285992829; JTCERGdTtMMGHeQC > 0; JTCERGdTtMMGHeQC--) {
        ZOErgIWeBTlFaKV += jeHgYpP;
        jeHgYpP += ZOErgIWeBTlFaKV;
    }

    return fEdntgufnqU;
}

int SDqpiHlZ::qqyBytHyiIDah(bool sdDNVFkZNZ, double EXUuCics, double TNKSdAfwTjK)
{
    double DVoLNJXmh = 979555.1901886148;
    bool pzlpoKtxKa = false;
    int OmJTgRskMsCoxLJC = 1128432170;

    if (sdDNVFkZNZ != true) {
        for (int hkYOhDXaxlPRUd = 163398309; hkYOhDXaxlPRUd > 0; hkYOhDXaxlPRUd--) {
            TNKSdAfwTjK = DVoLNJXmh;
        }
    }

    for (int wihqeEHQQpybJlH = 1695203089; wihqeEHQQpybJlH > 0; wihqeEHQQpybJlH--) {
        sdDNVFkZNZ = ! sdDNVFkZNZ;
        sdDNVFkZNZ = pzlpoKtxKa;
        pzlpoKtxKa = sdDNVFkZNZ;
    }

    for (int UUYSkSoDO = 1846276806; UUYSkSoDO > 0; UUYSkSoDO--) {
        EXUuCics -= DVoLNJXmh;
    }

    return OmJTgRskMsCoxLJC;
}

int SDqpiHlZ::HbtOcL()
{
    bool dofntkXLfABmvLQ = false;
    double NiqYVpvfLpDC = -907541.2836774096;
    double VSgWHLaWBLb = -352192.9864628299;
    bool vJTEr = false;
    bool rnHzW = true;
    bool UiNIXIVYZRAyQuxl = false;
    int hKRlmbqTjlQ = -1646009141;
    double KZPsFbMN = 615021.6295592472;

    for (int GYxON = 396906490; GYxON > 0; GYxON--) {
        vJTEr = vJTEr;
    }

    for (int StlcgSyPqW = 1567198749; StlcgSyPqW > 0; StlcgSyPqW--) {
        continue;
    }

    for (int kjkdbQSIqynuAcN = 722857891; kjkdbQSIqynuAcN > 0; kjkdbQSIqynuAcN--) {
        VSgWHLaWBLb += VSgWHLaWBLb;
    }

    for (int LAbeQTJlLgXPGU = 985991868; LAbeQTJlLgXPGU > 0; LAbeQTJlLgXPGU--) {
        dofntkXLfABmvLQ = ! dofntkXLfABmvLQ;
    }

    if (UiNIXIVYZRAyQuxl != false) {
        for (int SrJjnpWvApopbVi = 26821975; SrJjnpWvApopbVi > 0; SrJjnpWvApopbVi--) {
            UiNIXIVYZRAyQuxl = ! UiNIXIVYZRAyQuxl;
            rnHzW = vJTEr;
            hKRlmbqTjlQ /= hKRlmbqTjlQ;
        }
    }

    return hKRlmbqTjlQ;
}

SDqpiHlZ::SDqpiHlZ()
{
    this->XvEXjJKyxEemSyuR(string("djoHUBdodrdBpbPBlaFbOJESXViGJEPtnfgAqcWgMpCFjCbKtIgSdzyMcnzEYSQgvALYmbuQIenhGjZCTvOlinTcYvhqlAYuozfUmMHqyAuWhuXYfufLMuesyKaGcmModDGhJYloZazzjahCcrkYdutHRdluKemVQuHHirOheqqjRe"), 1016856.1651388938);
    this->QvHhwvukA(750249384);
    this->HHomqwZ(string("XUtoVVCNVeYrLahhZPDymauMquAeOolXQbZlchBxBsRSBLKsppQxyWvWhVOuLWjALYTCLHEUCpCF"), -1875005621, 1147331420, -462759190, true);
    this->BHqkz(-22137.82915857668, string("FsVRxCgCDyFgWNXmdmXLpjdHLRCfQceRbJZzPaLaDWKQmlbVVOQSLIMglLBVePvVqKBlwMDPpDhTvvjgrsjEtgMsJuYdcdCZAeoQiDKmohiefJroiuCllSQsKXRCPKiFEtuCQSPKLHtEEthZBrYTXDGhKdeyQneEYSiXPuxrwqduKXIsoetWEHnXrapKcVIj"), -821886860, string("RfagqdHDTZeHImBODcmsthewQHHxrXElRLVIBbmHfXCGRWZhZMXJDxWQJBTdklNuFjQluKbKYpcaoZzPcQOvvCMvJRGCU"), false);
    this->wAlqSqXiyyXU(122087.66603379912, true, string("hRoRVtrJAklxXoOcWCgdEhTRodefvZBpRvrLiMElzZJihRfizYPfxqzDZKkLtZzJrcqKKIwUnVKRnbNEPFLqxPmDjGnrHeERIdI"));
    this->psQMculFFAhyxQtc(1015683.6926363796, false);
    this->iygSLqhcgrOJQbg(string("zBnEeOotwJWyZFQkLMVfOYkUuVLsXHqWdhEPoylzIHZzqVxdgkwxwicQfDsCAJcSQgOWoSbZuZwTCgaqfkbUKqPrCIYqjEzMAMFcMltzfUjhLUugFXAYIajqbgLsSuCERqGQtgBEqFgnSierAnHIxDTIxSF"), false, true, false, true);
    this->TxpFjd();
    this->DWVFjt(1722226123, 1046890530, -79806940, string("yWRNAVSnJrIRVqGSqahMKxNMzrkQAkEsAYoYJAoKFopGWYvRKNCaFMycdCPITPLEonDMfcVedfZshZEXbOlODAzkfUmHBAeMZjmwyOayhtvgRiYWXGPLogURxCuxhuMnTFgSgEqvqTOvQKOjjqpHYQaIfaDworCikYZHcbJDvi"));
    this->nuyTuVNMKiMNj(string("gaoWEnPMWpBZKWKIfzFuDAmidRwBDEuYGwgoYBGQsiSAdqWwcgkwWhFNQzwjUSmnYEbRDrVKqdnbbTzuuPxHDBSUGCoOrPWCtINUfoE"), string("QIwHsZgsTdGEomKBpQeNBIiGwZJjJDyCPjYWDOFgtIQgkLjhLHQmhZBBqfxsPeibUtUokEvhExf"), string("lgIfFFlRvKXwYyyMsDZMjMxNCSEoGPXqkuHatmoaiGzkXkiCGkMIhOUsUniChQyvVrRrsRDmMvDXXQjwrWHILHfeoeUurQcjlbkARNJZwJvYHAKSiiU"), string("NHaKCLJugRAVGRPkXQssIPrgqorhnSVsFZkEkLAkruFFGUeDRkmRtapbzAMBdTslLfFeDZayXuqfbLetUqzaboPLkuzUdhKofyyGJspJErtUAjQjIKYTwsNoLEdbtQGlZdnAvihDeUwlZCQ"));
    this->nmiqYkPgNqAkKnVq(false, string("NoQJwiNPTteVGjbhDUTEEDcaFwUPhTO"));
    this->OTZBF(string("SpuyOeKcfeZLaLW"), string("xpavCuMkDRBWCSbKNDeaQURCmLPBebRZegXFjKdUtXaNvfVkGGyTifmbOOtrxsDJoohqLvZkOLivTYmDYbXioO"));
    this->cuYNQWzmRivDmdd();
    this->SlmOURpSbYu();
    this->eNqPgebiNF(-405511.9060815008, 212132157);
    this->wcdoUointOsBR();
    this->qqyBytHyiIDah(true, -861316.5742585983, 614037.4662422114);
    this->HbtOcL();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class KfKqzf
{
public:
    string dKiefYbYrc;
    bool rqViXpoxAghz;
    bool gRYiVDPuUgzL;
    bool FAKidNwVjqVB;
    string OZPUFMfPtRr;
    bool SvcZWWcTPZjGs;

    KfKqzf();
    int mrcMmSpINynNRGe(bool ENfaVAwohd, int vbbcChRg, double uybUnFMoSFJgh);
    void uRqwOTjlNsZ(bool juOifRdRaAeGYbe, bool XxZJqqhyMhyITLmk, double kZZRDStgBEIJM);
    string xiBTjouNknlA(double fiJNHbOFRigKhZt, double FrtkaCWvIjv, int HDqLtF);
    int xykTrVgwy(double iOgEur, bool NJMRVFnUvMxH);
    bool DHcNPtBCvEEiZF(bool DRQARtPpAHi, int LxdHqeLJKMDOBVw, string FIVfcAPDb, string NtydAs, double XphsbyweMIjrVAt);
    string VWzjraWHVYaB(string VDyztOOIOwLbpl, bool xeTZbRR, int fYwTaMdhhL, int DIPLDHbZxgIsFtMk);
    string imERLu(bool JaDFNiuM);
protected:
    string IUjmWKLPIZpscW;
    string AczUNgiejQt;
    double fcOFCzPBHzYG;
    bool DAbes;
    int pkZtT;

    int LgLzU(string aakGM, double tSlGAfnwmBwV, double HyEaxJIAtB, bool kqyFOKKi);
    void XUJyutjstBvelR(double ieTSgpm, string gYCuKyM, int dGomTpsNLCxNtj, bool uyqyWEjNh, double timsaE);
    double ioVqP(int DixNtypirzDbYN, string xaFEMPHwDOE);
    string aeVvNjFNTQ();
    void mTdzoHhskpdOZJS(int JqGBOCfHy, int TvJjwWDVrwfRviE);
    string zpeXnQARSgqxI(int VYmuIjwIbmB, double nHOlxqfFYFZes);
    void aGpcinDNuQckaaUA();
    bool xExHETcLI(double REYXEPWrleA, bool AdNagPT, int JTnOTZgVGeVK, double UsvFOLR, bool uzavZVySeUpSxXHJ);
private:
    bool kPRywaGUsn;

};

int KfKqzf::mrcMmSpINynNRGe(bool ENfaVAwohd, int vbbcChRg, double uybUnFMoSFJgh)
{
    bool sYggKMh = false;
    int EBtpGIGYgNbgAznX = 961439235;
    double yPGUFhspeSghzZ = -835425.4754883191;
    double TGDkvKrxx = -898899.0692525256;
    bool sJzBySfpYLQydFiH = false;
    bool MXhLSXfJbBPQ = false;
    int ynvZiuAaxyIjuWV = 139783443;
    string CnMJrNv = string("FEsGOtqvxdmLKlbqpbeGVFrwsLyajQPaOZKhZmjcMmpdpfkgxEPeRtZvJVNhKg");

    if (uybUnFMoSFJgh <= -898446.7800960037) {
        for (int JBAclNeDikXaflry = 323294605; JBAclNeDikXaflry > 0; JBAclNeDikXaflry--) {
            continue;
        }
    }

    for (int LmdaLWwHOaCt = 846802142; LmdaLWwHOaCt > 0; LmdaLWwHOaCt--) {
        yPGUFhspeSghzZ *= TGDkvKrxx;
        ENfaVAwohd = ! ENfaVAwohd;
        ENfaVAwohd = ! sJzBySfpYLQydFiH;
    }

    if (ynvZiuAaxyIjuWV != 139783443) {
        for (int UprxKo = 41881343; UprxKo > 0; UprxKo--) {
            MXhLSXfJbBPQ = ! sJzBySfpYLQydFiH;
        }
    }

    for (int nyLExR = 1462278008; nyLExR > 0; nyLExR--) {
        ENfaVAwohd = sYggKMh;
    }

    for (int YRYueJeCrTNsLF = 1495020822; YRYueJeCrTNsLF > 0; YRYueJeCrTNsLF--) {
        yPGUFhspeSghzZ /= uybUnFMoSFJgh;
    }

    return ynvZiuAaxyIjuWV;
}

void KfKqzf::uRqwOTjlNsZ(bool juOifRdRaAeGYbe, bool XxZJqqhyMhyITLmk, double kZZRDStgBEIJM)
{
    string IZLWJYT = string("dJGMyZwzEhdOzndDNIjVNYcNCormwhYnJYyxeccqQtHGCfWJMeXDOGcuIPSbpaYHxRiMslA");

    for (int NFJDNAFubLh = 987366201; NFJDNAFubLh > 0; NFJDNAFubLh--) {
        kZZRDStgBEIJM *= kZZRDStgBEIJM;
    }

    if (kZZRDStgBEIJM != -807576.0121854973) {
        for (int wQiGYwnANtroTgzP = 1698518323; wQiGYwnANtroTgzP > 0; wQiGYwnANtroTgzP--) {
            juOifRdRaAeGYbe = ! XxZJqqhyMhyITLmk;
        }
    }
}

string KfKqzf::xiBTjouNknlA(double fiJNHbOFRigKhZt, double FrtkaCWvIjv, int HDqLtF)
{
    int BSGBNjLJFVDbgIz = -2102243290;
    bool cOrRdfRSUdDAEBtn = false;
    double wulSjrL = -19536.93738844069;

    if (fiJNHbOFRigKhZt > -863658.9458770629) {
        for (int OfAfaUv = 669920787; OfAfaUv > 0; OfAfaUv--) {
            wulSjrL -= FrtkaCWvIjv;
            BSGBNjLJFVDbgIz -= HDqLtF;
            fiJNHbOFRigKhZt -= fiJNHbOFRigKhZt;
        }
    }

    for (int QXJmKMJLuMYR = 1415949833; QXJmKMJLuMYR > 0; QXJmKMJLuMYR--) {
        FrtkaCWvIjv += fiJNHbOFRigKhZt;
    }

    for (int hZwbyxRxFEGHAXxj = 250254750; hZwbyxRxFEGHAXxj > 0; hZwbyxRxFEGHAXxj--) {
        FrtkaCWvIjv *= FrtkaCWvIjv;
        FrtkaCWvIjv = fiJNHbOFRigKhZt;
        fiJNHbOFRigKhZt += FrtkaCWvIjv;
        BSGBNjLJFVDbgIz = BSGBNjLJFVDbgIz;
    }

    for (int ZGCBVH = 1815555965; ZGCBVH > 0; ZGCBVH--) {
        wulSjrL -= wulSjrL;
        fiJNHbOFRigKhZt = wulSjrL;
        BSGBNjLJFVDbgIz -= HDqLtF;
    }

    for (int NUnmukuqqxgYDqBZ = 625264990; NUnmukuqqxgYDqBZ > 0; NUnmukuqqxgYDqBZ--) {
        HDqLtF *= HDqLtF;
        cOrRdfRSUdDAEBtn = cOrRdfRSUdDAEBtn;
        FrtkaCWvIjv -= wulSjrL;
        FrtkaCWvIjv -= wulSjrL;
    }

    return string("eNnBVVhFVCizSDPtOpnFivkHtHp");
}

int KfKqzf::xykTrVgwy(double iOgEur, bool NJMRVFnUvMxH)
{
    string mnVId = string("xdSnPlYGCmrSVBzznMqDPAKhEPHZOPXgSsnsUKOUSToMFlWVmEGkXFAHxDEbMUkmqdOnxQcIxSnwFkzDTucjoaLmkDUaLJHZQlAgLAVJHjQxTlINiAXLfjAZginSTGUArHWcbwWqYvIcgjesvSNEQEtHJUFYxRPuGuoxABtIrGckSZdcRgRwqwRayseJwooVSvhsUHwfLLaxaZPBlunnmargsjCHINIEOdekls");
    bool EGQbRBnJVkUTemkS = true;
    string tJPpKnpvwUZqhtlQ = string("WfmVvSclCYYYuaHQOBWNPBvCFuVNkFEyPIyualQoQdSVjfWEZPXwsLOTYETcTBZDlxRoChoPIUZaNkQoqXYOTLLRmNGtgEPzItZJSRNAVYcujOjotgbivyDjIzsesgMmvoYVOPNXJbAsizGdVmPIPXOOczzQC");
    double rWrsQeMXjHwx = -825674.1549587647;
    bool OpQvHCzRX = false;
    string ARioDtq = string("pPkzEGnPg");

    for (int urDwSshWbSryfDFR = 1818348019; urDwSshWbSryfDFR > 0; urDwSshWbSryfDFR--) {
        tJPpKnpvwUZqhtlQ += tJPpKnpvwUZqhtlQ;
        tJPpKnpvwUZqhtlQ = ARioDtq;
    }

    if (tJPpKnpvwUZqhtlQ < string("WfmVvSclCYYYuaHQOBWNPBvCFuVNkFEyPIyualQoQdSVjfWEZPXwsLOTYETcTBZDlxRoChoPIUZaNkQoqXYOTLLRmNGtgEPzItZJSRNAVYcujOjotgbivyDjIzsesgMmvoYVOPNXJbAsizGdVmPIPXOOczzQC")) {
        for (int lSTiYLOjpOTp = 835244484; lSTiYLOjpOTp > 0; lSTiYLOjpOTp--) {
            EGQbRBnJVkUTemkS = ! EGQbRBnJVkUTemkS;
            ARioDtq += ARioDtq;
        }
    }

    for (int hSTzHHY = 2120591908; hSTzHHY > 0; hSTzHHY--) {
        NJMRVFnUvMxH = OpQvHCzRX;
    }

    for (int PCFYxeacTWu = 147261259; PCFYxeacTWu > 0; PCFYxeacTWu--) {
        NJMRVFnUvMxH = ! NJMRVFnUvMxH;
        EGQbRBnJVkUTemkS = NJMRVFnUvMxH;
    }

    return 495978936;
}

bool KfKqzf::DHcNPtBCvEEiZF(bool DRQARtPpAHi, int LxdHqeLJKMDOBVw, string FIVfcAPDb, string NtydAs, double XphsbyweMIjrVAt)
{
    double PShbhlRVcxrKBfcX = 342885.52428725373;
    int dzoJasBmaFhoGl = 278601843;
    double bZsjAWoPV = -909350.6020452394;
    string taoLlV = string("SwhYKnLJyWzojONCZVBfFdstNiOXajwvIQpolvqZnWUjQDGjdZILkIYUMzJkZwRpoXLofeMIbvwOauVdghJkmzPzXWFVFoOKpcAnpBfjCFsYFpYdIUZqjXeNBRSPXBmnPuIdpVupcIOoyKhJiFaVVbEWjJsEuWlrdrAwITVBFhUIFihnvAmaIAsMfMMDLsduqP");
    bool wIBZwXfRaBRn = true;

    return wIBZwXfRaBRn;
}

string KfKqzf::VWzjraWHVYaB(string VDyztOOIOwLbpl, bool xeTZbRR, int fYwTaMdhhL, int DIPLDHbZxgIsFtMk)
{
    int PQPFcPilRQS = 385431272;

    for (int dsKtXvrx = 518197067; dsKtXvrx > 0; dsKtXvrx--) {
        PQPFcPilRQS += PQPFcPilRQS;
        fYwTaMdhhL -= fYwTaMdhhL;
        PQPFcPilRQS -= DIPLDHbZxgIsFtMk;
        fYwTaMdhhL = DIPLDHbZxgIsFtMk;
        xeTZbRR = ! xeTZbRR;
    }

    for (int ZjaPOkQZVa = 1213199772; ZjaPOkQZVa > 0; ZjaPOkQZVa--) {
        continue;
    }

    for (int UmIrbc = 1748800838; UmIrbc > 0; UmIrbc--) {
        continue;
    }

    for (int lcsiVVfYQJFYAn = 830259062; lcsiVVfYQJFYAn > 0; lcsiVVfYQJFYAn--) {
        PQPFcPilRQS += fYwTaMdhhL;
        DIPLDHbZxgIsFtMk *= fYwTaMdhhL;
    }

    return VDyztOOIOwLbpl;
}

string KfKqzf::imERLu(bool JaDFNiuM)
{
    double IhPPPtgRfbpst = 141362.40106345544;
    string lxTNxp = string("hlfpLJkQQIqtEapdhAHjsnyWolaeFNwVfrnUBDUlASMIGpbZmsxGpniEqmIMtIrVjsdUBTJbSaNEXZlHTzQHZqjokZDyxIRbRpOQVEqXab");
    string xuKaNIQHD = string("ovLBgEsXRyrAMmREHqlifhlDQtBrjJRBRRnpwcdxkFwEXNoBeQkiThErpyiPcjDZHGMsJvKpjXfyMLevDABZMJVYKSLbsWkrqLurmubbhAoKpbrYnVrpszJKWhNGMMNVORRiqeIsXVuOVzPBcougsqCmNxusAjucF");
    int uheGOK = 1880872889;
    bool oZdzuHF = true;
    double dydWeCOhDZ = -312678.5400820717;
    string TjnyHDoYxJLU = string("PEVRUhxOdkCLRkOEDsafIkzeJLZPcYsUmqYDucbVtrSBeDitALICenFXoHbxwNIgmNqUidUOdfNDZrdisRsZhIJHDBThLJlvhjdCYSyJUJdilVRCzmMpUyqcuZbhVFRPJeISNfZALycYJPLTfh");
    double mlFoIrmspqRACd = -973302.4727995257;
    bool XlvAUWHizYdpBTPU = true;

    if (IhPPPtgRfbpst <= -312678.5400820717) {
        for (int jTCuzdfHJzc = 282883062; jTCuzdfHJzc > 0; jTCuzdfHJzc--) {
            mlFoIrmspqRACd = mlFoIrmspqRACd;
        }
    }

    return TjnyHDoYxJLU;
}

int KfKqzf::LgLzU(string aakGM, double tSlGAfnwmBwV, double HyEaxJIAtB, bool kqyFOKKi)
{
    int rqrQI = -1651986809;
    double bGlhhrvkcVZjKUbR = 16758.68065403539;
    int INXhHfqwF = 1839801530;
    bool KaflUCalkOfKADoH = true;
    string YiSHJbrHqoTlwNTf = string("hzbtwvxAcbYioePieYYRBoavbaZQAjIURXiMNtaMQWpFzBesQhJSXnaucVbHJ");
    bool kHzkf = true;
    string yiykwQRc = string("TbqNUJCLVxLWkxojmdiuPvTIsoZKiOadITHhZAEYVFgkqjXpxlUkvQxGGQQFCgRMvCWTDxzcXmFpfxQirvJbogNaiepCAwKTPEzoZUbCDXzByIsflsUUcScWRHEElyqwdqVeGsSrhtuCWoafEnMMzWxzAanWfxvTxazozoDvMISxllvgROyUBEeJmsBByECwuzrDgLgAknVmWElvpx");
    string Alrhazz = string("WffAlyWSysFtXHOlwqDyCdiKKNFFfeixKoKFMXRfhVfWMcefHtnBSHtljVGMdWwxFhYsoaUjwhPMrtrUqvYusURLgpIXkihpBoekjjufyeDhmheKiTxIpgaejGxrfulXQgwxPMBCWw");
    double yIZfjcOpClpWEyF = -746665.3894778438;

    if (Alrhazz == string("KBkIfMOeICKBOnjlSiPaM")) {
        for (int iYyrEAQJhCY = 602893698; iYyrEAQJhCY > 0; iYyrEAQJhCY--) {
            kqyFOKKi = kqyFOKKi;
            tSlGAfnwmBwV = bGlhhrvkcVZjKUbR;
        }
    }

    for (int BxUkCJZDhjNT = 33426260; BxUkCJZDhjNT > 0; BxUkCJZDhjNT--) {
        yiykwQRc = yiykwQRc;
        yiykwQRc += aakGM;
        bGlhhrvkcVZjKUbR *= HyEaxJIAtB;
    }

    for (int uOldVjxcRMDlmi = 940481577; uOldVjxcRMDlmi > 0; uOldVjxcRMDlmi--) {
        continue;
    }

    if (aakGM < string("KBkIfMOeICKBOnjlSiPaM")) {
        for (int exJUsAHsvUBCI = 642456636; exJUsAHsvUBCI > 0; exJUsAHsvUBCI--) {
            continue;
        }
    }

    return INXhHfqwF;
}

void KfKqzf::XUJyutjstBvelR(double ieTSgpm, string gYCuKyM, int dGomTpsNLCxNtj, bool uyqyWEjNh, double timsaE)
{
    int OVoBGY = 1505221179;
    string VEMkTlbCOlwy = string("TkOMrEpomdcvnKIukbDsIHQPzgtEYzpPDsyWPRfQsZvLvyZwLTrvmYqxLMEmYTHWwGXfHhrenjOBFXJXqKBMiKCreSVkXNUCBQfXiqHeHnsQXDQkcsgEEnyUbehvQqGrTJBVCJCjNqILjPNEqRQRQNlLUVoZlfKZGCtfOKHEpcPqRwKXSViHoCVElWkgWncUCtQqCicmrszC");
    double sccIdqzzrChiYI = -358554.1343835978;
    int WOjLGVJJAY = 1463116348;

    for (int RazOrbHVDZL = 215263548; RazOrbHVDZL > 0; RazOrbHVDZL--) {
        dGomTpsNLCxNtj = WOjLGVJJAY;
        WOjLGVJJAY += dGomTpsNLCxNtj;
        sccIdqzzrChiYI /= sccIdqzzrChiYI;
    }

    for (int FYbXiyPwcl = 190230610; FYbXiyPwcl > 0; FYbXiyPwcl--) {
        dGomTpsNLCxNtj += dGomTpsNLCxNtj;
        dGomTpsNLCxNtj *= OVoBGY;
        timsaE /= ieTSgpm;
        timsaE /= sccIdqzzrChiYI;
    }
}

double KfKqzf::ioVqP(int DixNtypirzDbYN, string xaFEMPHwDOE)
{
    string szHtzCgN = string("MehfqVJFMSgqfCcCEZJibGlaOOlezHUXOxIBuBGAwadOTlYcliLFbqowuvAbXIzAQIRgpNwXTVsQCdBwHtsjOdKRWFOkqbTMHqokARFpyypXgqigIWBLdURsKUQRZRmFtjAShEWiCsFESOUPvRdhVzwKGujEGw");
    double IkeIMy = -778339.154240459;
    double eEUlYR = -1042306.6656517492;
    bool vwfldj = true;
    int pzDghXHHjWlSQ = -552875928;
    bool BIYGMrr = true;

    for (int mdQmQEvTq = 1119231542; mdQmQEvTq > 0; mdQmQEvTq--) {
        pzDghXHHjWlSQ = pzDghXHHjWlSQ;
    }

    for (int tPfcmTGGJQ = 897116950; tPfcmTGGJQ > 0; tPfcmTGGJQ--) {
        continue;
    }

    for (int lMYhqztzwmScgl = 198406992; lMYhqztzwmScgl > 0; lMYhqztzwmScgl--) {
        continue;
    }

    if (vwfldj == true) {
        for (int nEwKrkmnF = 14727574; nEwKrkmnF > 0; nEwKrkmnF--) {
            continue;
        }
    }

    for (int nqvPEEGqIlmugab = 1489332786; nqvPEEGqIlmugab > 0; nqvPEEGqIlmugab--) {
        DixNtypirzDbYN -= pzDghXHHjWlSQ;
        DixNtypirzDbYN = DixNtypirzDbYN;
    }

    for (int lPmJuBlW = 1947705778; lPmJuBlW > 0; lPmJuBlW--) {
        szHtzCgN = xaFEMPHwDOE;
    }

    return eEUlYR;
}

string KfKqzf::aeVvNjFNTQ()
{
    bool iNBxbmU = true;
    double ZxfSKXf = -725840.2369949563;
    double rCojuzxVcgM = 806381.2353673475;
    int EyJWnGs = -1248932574;
    int cOqvUZaZXMwgmR = -804293936;
    bool YaKZTXYtUW = false;
    string yrmSKDomRct = string("hEnDbmmdWuMHERLHzhPJyDoRYnTMecVaduYlVKNpNXDIdPZoelZHnKoLRsChhiXHCTOoLnSlpVgrJeaIwiivMtHJOLgqzdxuzkEDIrfzQPcjYGoQHDPtsJHbAlcSijrZZOCegNUUMZqzmTCxvAZKISwsNiBPURNPwNbfadGfDgiJGUEreKoaquFcjqZCmL");

    for (int EnRPxWQGkR = 842501308; EnRPxWQGkR > 0; EnRPxWQGkR--) {
        YaKZTXYtUW = ! YaKZTXYtUW;
        EyJWnGs /= cOqvUZaZXMwgmR;
    }

    for (int ebaajr = 1128120663; ebaajr > 0; ebaajr--) {
        EyJWnGs += cOqvUZaZXMwgmR;
        cOqvUZaZXMwgmR *= EyJWnGs;
    }

    return yrmSKDomRct;
}

void KfKqzf::mTdzoHhskpdOZJS(int JqGBOCfHy, int TvJjwWDVrwfRviE)
{
    int fxNNhSxDGh = 423397879;

    if (JqGBOCfHy >= 1930548801) {
        for (int rjcltouSeV = 820414793; rjcltouSeV > 0; rjcltouSeV--) {
            TvJjwWDVrwfRviE /= TvJjwWDVrwfRviE;
        }
    }

    if (JqGBOCfHy >= -407239720) {
        for (int ZURHPopztvjue = 235842643; ZURHPopztvjue > 0; ZURHPopztvjue--) {
            fxNNhSxDGh *= JqGBOCfHy;
            JqGBOCfHy -= JqGBOCfHy;
            JqGBOCfHy *= JqGBOCfHy;
            JqGBOCfHy += JqGBOCfHy;
            TvJjwWDVrwfRviE *= fxNNhSxDGh;
            TvJjwWDVrwfRviE += fxNNhSxDGh;
            JqGBOCfHy += TvJjwWDVrwfRviE;
            TvJjwWDVrwfRviE /= TvJjwWDVrwfRviE;
        }
    }
}

string KfKqzf::zpeXnQARSgqxI(int VYmuIjwIbmB, double nHOlxqfFYFZes)
{
    bool OAXEyOxGkxzvKGu = true;
    bool UBektWsZumFe = false;
    int TbEVpMZ = 746095585;
    string EEWxryXhIAdfdgqG = string("TArmjQHdfROwlrydGKNwATrnTXUZPJcxvuFMlCREJLbHndewHqYMwTIANXzEgOoKLPwSgwkLAcMQOpnREpARRdtiqRQwrolllhezsFEQLchnQZIOhUMCnNPRbOmWvzmIY");
    bool ZRQgHCFpmFxp = true;
    bool KoBSxfrs = false;
    bool sZlbirCzpe = false;

    for (int xhPQZRNRyezjYuM = 1775349789; xhPQZRNRyezjYuM > 0; xhPQZRNRyezjYuM--) {
        ZRQgHCFpmFxp = OAXEyOxGkxzvKGu;
        UBektWsZumFe = ! ZRQgHCFpmFxp;
    }

    if (OAXEyOxGkxzvKGu != false) {
        for (int qrvatfuZx = 187828476; qrvatfuZx > 0; qrvatfuZx--) {
            OAXEyOxGkxzvKGu = UBektWsZumFe;
            VYmuIjwIbmB = VYmuIjwIbmB;
            UBektWsZumFe = ZRQgHCFpmFxp;
            OAXEyOxGkxzvKGu = ! UBektWsZumFe;
            OAXEyOxGkxzvKGu = ! OAXEyOxGkxzvKGu;
        }
    }

    if (OAXEyOxGkxzvKGu == false) {
        for (int KfsMgrE = 304498184; KfsMgrE > 0; KfsMgrE--) {
            UBektWsZumFe = ZRQgHCFpmFxp;
            OAXEyOxGkxzvKGu = ! ZRQgHCFpmFxp;
            ZRQgHCFpmFxp = sZlbirCzpe;
        }
    }

    return EEWxryXhIAdfdgqG;
}

void KfKqzf::aGpcinDNuQckaaUA()
{
    string XdZaaUMXueuGIUH = string("foIWhMCoWQvvjyNzLHQBnvkyFCiWaGfVNPgirIsjfaNengbQYTzObSlYsSpEoRQvMwqfVYmiqbMSWwooRtJgKbqoDYMvMciVeZjUaPtoKxTzDyDdk");
    double HOtMAvKJJaq = 184775.01003457498;
    int XAYZj = 1288190798;
    bool CQlhADMKsbYY = true;
    int xsxNM = -107521375;
    double ZahVReJ = 83027.93957386377;
    string axekxv = string("bdZGwxhLAgDEKaNpEKkQZLksYDJDwtHMpLaTJAeqMtuwuoggkzJCKtemgSSeAIrfwFLD");
    bool gofqnc = true;

    for (int rPQQPoDQBZaTeH = 389774814; rPQQPoDQBZaTeH > 0; rPQQPoDQBZaTeH--) {
        continue;
    }

    if (gofqnc == true) {
        for (int TSDBAxdlurMWlgC = 2006939754; TSDBAxdlurMWlgC > 0; TSDBAxdlurMWlgC--) {
            xsxNM = xsxNM;
            XdZaaUMXueuGIUH = axekxv;
            CQlhADMKsbYY = ! gofqnc;
        }
    }

    for (int pVFiPUJcePyk = 729500222; pVFiPUJcePyk > 0; pVFiPUJcePyk--) {
        XdZaaUMXueuGIUH += axekxv;
        HOtMAvKJJaq += ZahVReJ;
        xsxNM *= XAYZj;
        gofqnc = ! CQlhADMKsbYY;
    }

    for (int buBtBTsofHI = 1108217808; buBtBTsofHI > 0; buBtBTsofHI--) {
        HOtMAvKJJaq = HOtMAvKJJaq;
        axekxv += XdZaaUMXueuGIUH;
        XdZaaUMXueuGIUH = axekxv;
        XdZaaUMXueuGIUH = axekxv;
    }
}

bool KfKqzf::xExHETcLI(double REYXEPWrleA, bool AdNagPT, int JTnOTZgVGeVK, double UsvFOLR, bool uzavZVySeUpSxXHJ)
{
    bool vBIQe = false;
    string yPalNI = string("mNpCBhHZVvAaDEOcimMyHhVGClwVpTswMPXCteXCrGFOhIcwdjxlAFdnJbaXuAJnqBIEjAywqCrSzcKKimjDhSYiaYhJDkPxkNTylZVNwcFOfPKLOdKVOaFzMAqZnGVpZUTBmThAGLBwlTlhWIpSXZzbtCgomyMQGWvryXpLDPtbuiVINWGOcuBeBHtNaqofSkOp");
    bool WHLUEtRhJ = false;
    double hsrxkZOQKEKP = -181698.36463063335;
    string Tcdua = string("bNYOpjJJTDyYXoQRaakZHkwgYuOzglnarwmjBuuVgdQcgcYpSUzrsJfnGlULjKPBgYITydANGsOqnsWNgPIAoVrrJclAEnkymYySrxVCchtQQtEYDlDNXsYZnfIOmParavrXuSbSQmXGOuRkEKNQDeXTZagRihxv");
    bool hVJqNallCLp = false;
    bool xbvSiLJ = true;
    string QkQEkwUgKkTHv = string("jSnApCTlxqImKhLxRqJUtTwHSlUNkacjEQJIcxFbIHIYizwUQAjGateqDJrSPlkxr");

    for (int JOKvM = 1690544649; JOKvM > 0; JOKvM--) {
        UsvFOLR -= UsvFOLR;
    }

    for (int mdYJXQNYm = 1034218655; mdYJXQNYm > 0; mdYJXQNYm--) {
        yPalNI = Tcdua;
    }

    return xbvSiLJ;
}

KfKqzf::KfKqzf()
{
    this->mrcMmSpINynNRGe(true, -1959883242, -898446.7800960037);
    this->uRqwOTjlNsZ(false, true, -807576.0121854973);
    this->xiBTjouNknlA(621707.3784822285, -863658.9458770629, -1586509334);
    this->xykTrVgwy(937079.2032963196, false);
    this->DHcNPtBCvEEiZF(true, -549699023, string("RxQcSZcMuUEeoFfVVDinBBdqkaAGCCaHWQnaLYGnOTDeEjtMclxZhFdQxSfmXvLcwhzJOsUpWfPmbVPdpDoWsVLfxswxlfNykC"), string("sbeavzeHlbxbkiisQsmFAySwBgiLdEAXaZkjYSBPDqehidWpfXShKGpIPbZSLLhMhUmwEDlMkOysInyiQIOxFSEUwRUKKiRxBsYAvUSKOmnUnERwhwTjkcyYywTYAFuWcnrHByWqRcCItZnoXFJGrvfRmmfPtdVuXllDwsjJMpChSEZpjIDhsFJyHdVgjbofiHq"), 573927.5702435109);
    this->VWzjraWHVYaB(string("wPPOhKhGMVYhyYAyqpoLFPMAGhrEfuxhPLKQwKPbOlNpMSCaCYRgGyIzyTBaSMMGdnxrSNQBKenUyluSpftmKUdOwIbDbQbnj"), true, 592835706, 1030393023);
    this->imERLu(true);
    this->LgLzU(string("KBkIfMOeICKBOnjlSiPaM"), -453287.5326884779, -825614.102986799, true);
    this->XUJyutjstBvelR(-994761.8957686443, string("bLgWEuImjHXQJuqsCPnlAZyZEwTcfYeeUkwPsXbFcLxiCVAlmColGliVcSmVXOsrRnDBAxPPrlzcS"), -42350609, false, -968809.8721855698);
    this->ioVqP(-370540474, string("PAdSdNJcfkLZNvcQnLGIYaSTiPIVmXcHlMdchRWijXMAaLJRxaGXLuJfoRUYSsLgDzKsRrQSizQWsWgVbMppoDKUQUbJNPVvhqSlOCMxVeEtGWoZWpLjwwzTLxKGbiDXGtFPrTETFxeeBEpnCSxpdiHoUtyRBsjzPXQZdNWUOkmkiOlbSMxImhvwKCwCyPKZDN"));
    this->aeVvNjFNTQ();
    this->mTdzoHhskpdOZJS(1930548801, -407239720);
    this->zpeXnQARSgqxI(-2127728153, 830984.8262828266);
    this->aGpcinDNuQckaaUA();
    this->xExHETcLI(369107.53006326524, false, -544410937, 688722.4641531252, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PHTnCHZOAryBS
{
public:
    double Pcmkj;

    PHTnCHZOAryBS();
    string UtqnkDAnEX(double oUlEjfuRbwEyXePv);
    void ocHYpfsoGz(string WsxlvsAM);
protected:
    bool WXXnwJcaZx;
    string AhFXPsmxvdN;
    bool PjFxnpIbhPp;
    double WJxEZOgpt;
    int VQyHqGe;

private:
    string uYjpwy;

    void PcjHlaFAj(bool OYDmBRJIKO);
    int GtuVUhZfwrwh();
    void mRdUYEZ(bool QGindAXImaR, string lCkrkKI, string YDrLEadAALmIto, string mBBNphOH, string ThzHr);
    int xEZAKFFNAzWk(string jsGabfHmLlnQNoOq, int aCbZbXdwDKx, int dzZKDHiXYeKGn, string RxinvrcbfS);
};

string PHTnCHZOAryBS::UtqnkDAnEX(double oUlEjfuRbwEyXePv)
{
    double ehNSIAbpaeiC = -658988.9801284196;
    double zwZgIEBfwlOSf = 606228.5183528662;
    int xNywdYqCzRpM = 1325016129;
    bool zvnCETYFliZqnja = true;
    int zJIlZqqNgzewdRh = 1125697059;
    bool dsntP = false;

    for (int VcchezGdhO = 1326692694; VcchezGdhO > 0; VcchezGdhO--) {
        continue;
    }

    return string("SDevZXvcxbLRDDHzrYOmOtZSQcdQrgYJquybwfEVKgMtJMkRbGFKCTHohPLmLwYmBBoGBYijx");
}

void PHTnCHZOAryBS::ocHYpfsoGz(string WsxlvsAM)
{
    bool dVjNkIC = false;
    int ohaeGSAZQB = -1751261250;
    double BJKfwhXau = -974945.1123171428;
    bool FpHjU = true;

    for (int vpelcUrfz = 1079508776; vpelcUrfz > 0; vpelcUrfz--) {
        continue;
    }
}

void PHTnCHZOAryBS::PcjHlaFAj(bool OYDmBRJIKO)
{
    string hmDsHotStkNStxL = string("xXexfCnNVqQSCFQWlNJLxlZJHCadLvbySmRCVPUFooaOKBOjBuGEjHamwCDXMzgcYzfZiYtamfHDmzyNZmESyrhTzFNUlPJXZYzHJJdZXJSRWzWzLcadVDXEFHtNVFvNnUcPHcPIKHHuYVsxgrtUibkScfseIVYAKBkxQYtRHcjkhsESgKYGsczzYvUOHBMHyFdEPOhvBD");
    int uaaxPmwbfWPjtJH = 1069466991;
    double KatzvlnxAMfHFY = -268786.42549210845;
    string zuRSAHpEpP = string("guBnDAbOqTBpxcztDXgXblTEbvfqggPfphcYybfucAlKNwwaUEMZKYsFQSqBQMGhVPOhWMzxJkPWyUFyndrpsQ");
    int JadpjuF = -1763679009;
    int XBBoxxjOHHkR = -71353743;

    for (int FAEdN = 1912503; FAEdN > 0; FAEdN--) {
        zuRSAHpEpP = hmDsHotStkNStxL;
        JadpjuF -= uaaxPmwbfWPjtJH;
        JadpjuF -= JadpjuF;
        hmDsHotStkNStxL = hmDsHotStkNStxL;
    }

    if (uaaxPmwbfWPjtJH >= -71353743) {
        for (int CqQLovZfGmCJnFd = 2134313631; CqQLovZfGmCJnFd > 0; CqQLovZfGmCJnFd--) {
            XBBoxxjOHHkR *= uaaxPmwbfWPjtJH;
        }
    }
}

int PHTnCHZOAryBS::GtuVUhZfwrwh()
{
    double XQGDZmEYmumhHggb = -394400.051448484;
    int hIkUsfFQbeWUDlE = 41182788;
    string ZxLMyBHoBpzYd = string("FpiqndKReJqegvNrLEvJiEapaOzpdoXNhD");
    int kLmfaMuBhQrP = -1228696947;
    string QtTuSluzBgtGoOi = string("eAPiRkbyTvlQhTpBbzTUafHfQcNgqHlNvEveYdAOBpCXwRiPHmcrvEiDDZAQErBQcYFZWJsBpOFZrenHKJBrAVhyjURmQwUaDpXRzBKgmWpeiQVblAuEuDA");
    bool FJnsIlwGatEb = false;
    string SJFgkOWEpeGd = string("gGGYdiexkGPXGvcHGZHbhiaKPkeHlMeYjpyWNsiYkPWRGVrNBuESbvvCvpePgrhJfMbDGPdXIWPapeELznSGdPHCHKZQGToJSidNiMEjVPCDidreMjNAFEuFEHkWaLBYASGqkehkQhAJvWmEGLrwJSVjRyywdTsIsFMBpPchhVMICTakvMaMEWbPxKeNdLJUqMIqzMyoaPtDPrUgQcxTHgpjTwrCTQqEmmP");
    double bDnAB = -774578.0419867921;

    if (SJFgkOWEpeGd <= string("eAPiRkbyTvlQhTpBbzTUafHfQcNgqHlNvEveYdAOBpCXwRiPHmcrvEiDDZAQErBQcYFZWJsBpOFZrenHKJBrAVhyjURmQwUaDpXRzBKgmWpeiQVblAuEuDA")) {
        for (int MuHot = 169446094; MuHot > 0; MuHot--) {
            kLmfaMuBhQrP /= hIkUsfFQbeWUDlE;
            QtTuSluzBgtGoOi += SJFgkOWEpeGd;
        }
    }

    if (QtTuSluzBgtGoOi >= string("FpiqndKReJqegvNrLEvJiEapaOzpdoXNhD")) {
        for (int RIvnlKm = 774942518; RIvnlKm > 0; RIvnlKm--) {
            continue;
        }
    }

    for (int ELakFQvGbtCHoaLj = 322255537; ELakFQvGbtCHoaLj > 0; ELakFQvGbtCHoaLj--) {
        continue;
    }

    for (int ieNRv = 1627432921; ieNRv > 0; ieNRv--) {
        hIkUsfFQbeWUDlE -= kLmfaMuBhQrP;
        SJFgkOWEpeGd = ZxLMyBHoBpzYd;
        bDnAB = XQGDZmEYmumhHggb;
    }

    if (SJFgkOWEpeGd > string("FpiqndKReJqegvNrLEvJiEapaOzpdoXNhD")) {
        for (int AdpLabFdf = 119009982; AdpLabFdf > 0; AdpLabFdf--) {
            continue;
        }
    }

    for (int UIrbMSQETpCKfSmv = 1996212520; UIrbMSQETpCKfSmv > 0; UIrbMSQETpCKfSmv--) {
        hIkUsfFQbeWUDlE /= kLmfaMuBhQrP;
        kLmfaMuBhQrP += hIkUsfFQbeWUDlE;
    }

    return kLmfaMuBhQrP;
}

void PHTnCHZOAryBS::mRdUYEZ(bool QGindAXImaR, string lCkrkKI, string YDrLEadAALmIto, string mBBNphOH, string ThzHr)
{
    string aVufEERrTzvwft = string("FfLhOEreFVtGjzgiErTIwqOMRrlDWEhrKCzIDWeOARGmsrcsMIJAoqymymkfrIvgJFgHTHAnDFoXDeKKtzIDqlGzYIdoszFqzssQoBAQTSoqZfZos");
    int QoYzdIPIwDCTBJy = -2029721374;
    double KrRdwLD = 542924.4596608594;
    int PQbrVBI = -1156424854;
    double ettjduyRRu = 202463.8052688417;
    int TcWoC = -1664933176;
    bool TfPBFcz = false;
}

int PHTnCHZOAryBS::xEZAKFFNAzWk(string jsGabfHmLlnQNoOq, int aCbZbXdwDKx, int dzZKDHiXYeKGn, string RxinvrcbfS)
{
    int UDPvToQDww = -693455596;
    double htCCGKLhI = 535484.6038606362;
    double HEJAbelcEdUOP = 735552.6860669728;
    int AYaClHENeqyg = 598118232;

    if (UDPvToQDww != 1705493770) {
        for (int xfmxwcdckBDu = 1751532319; xfmxwcdckBDu > 0; xfmxwcdckBDu--) {
            continue;
        }
    }

    return AYaClHENeqyg;
}

PHTnCHZOAryBS::PHTnCHZOAryBS()
{
    this->UtqnkDAnEX(-520675.96737710346);
    this->ocHYpfsoGz(string("WnjPrIkkCZJrdWGRFBEKvlHuhoegJxFjMRnGcfLfGoLmKlaLetePOielJqIUmCcAzXioynVEACHdeYEaKAJCROaCXqOCpoxrDatyIbKgrTascFOstgJHIaJrsDKsiKRUeTgOOOaCsLQuGmXCkApMDWTJELrzIquhbgdguqAtJQBorQPjNNNmytsXAZAXaGvgGwnXcqFCFYSbsjWwzFyCSqNMPIqwUDWvEnvvjyLJaEOnMaTzJixQARCsaWZ"));
    this->PcjHlaFAj(true);
    this->GtuVUhZfwrwh();
    this->mRdUYEZ(true, string("npXQOtptGZgbJlYGXfSSpeIGFycQGoLDgbDvhKrJdeFTPhAhQVXDYAtXIeZvlTfSVrpfOnNsgIOjenFQXwPAbMqYLkIrnFIAyzmlpJWhHeRsOemYVgvkzeYrIODJaxVQzAhtCXlRcHkSjSYODypsSYrMVEAM"), string("deHwMkHfXTDmAXUTYNzNSrodzRLzkzXqUbcTRAoTLZyKMYFOFaMJfAnJxRLtYmBSfcafgSEIIYziQFlGJyWyHEggTj"), string("JqZXoycBavwpwKBmJANqhdMViuyWzuzQOJZrzKFnRmYvzhlTwrUyqgPCsTvKLnWIdqECiYPZoHVoRrOxTPM"), string("jACogFiuWFThSUpdAofzFpNrAkhSFUTXiwOFuvAUMorJXUrkKueSXHRrCusUvYMmFCrtLoxCpIksYedSQKwtbXQSkZYWKPKbxyAhmBUvwfzLowKuNNnceqZiGEesECcMYXCEAnVIEhbBCnboJLtexXHgSxITyJfdWDumrTQnHNbKUyoITfzofnJdCpAguEXKPO"));
    this->xEZAKFFNAzWk(string("sTPbWBDxSMhNTOoPuDFbHZrrfVcBMJljuFBnBKYkIyZhinOBCgcgUmUxnpPqNtXNUsOuQNUBgeLSIKvXcklWSAVCcbGxwlTMuLgbldGfQjgyCjwPbZufqZcdJcJdcqwNWGEUMgcdeYkhDgFbHzk"), 1705493770, 1153501431, string("yvQRHMtUMesTSYHFnYgUhKYycBYMGgideNzeSYZvUkoxcoJSSJQFFsJrbNCPKYRRfBOxYdTtiwGaNhCRwIBIfWtnz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class BOkzSpCs
{
public:
    string ICtzJfjG;
    int OesYYXRnRs;
    int hGhZTee;

    BOkzSpCs();
    void FqxEuNxBQRdag(string QoGasHNCBRr, double hRRsguGbWNKZ, string YxBjwzPo, string kNzVLS);
    void kKLAFCV();
protected:
    bool QLqwXPZBCDNlQE;
    int SnwgZlFSq;
    string MVfnCPUELR;
    int YaqEjGaXFlwYqhAW;
    string SsOyLwPqtyTVvT;
    string ICGdipCHMG;

    void cCMzOLVyTGGcsxGI(bool zNqPAMxTYOlce, bool emubFOtxeJyGCkc, bool cvemfJhyTkjRMsJ, int lqgWByo, int AfpwayuzdbW);
    void ZDcjrjcSrM(double NDKoxgrQzbLZg, double VCPAIafIszFD);
    string IbFXdo(double IFQhGdLB, double QTCSmJ, bool LDwqkrR, int TriYhCSW, bool trOKgIgG);
    double LpMQbsWMxicPmvQ(string aIKgfxzQPWy, double xAKmSLBvIWKYFXl, string sexfSduAmQlSuuwl, bool HlCAd);
    void JrYUjXcO(bool QoqDAoENbJNVrS, int CcxHIPkLs, double gBZOa, string ABnILSUDIKtl, double lndSEc);
    int XBYndjmaXJ(int wllNhoKaAaca, bool FMOOdY, bool qQpQrGUXP, bool eTmEgnRnW, int ISZdmsIM);
    void tNJSNC(double DwrAVYtsYEdQ, int OvTuDoXzBQU);
private:
    string YxzSrJWi;
    string tCGmTv;
    bool wCMwjHfyaap;
    bool uvJXltOXwHwyxJ;

    void tUnoYP(bool bruIA);
    string NiMKnOFEr(string EzVFk, double xEgtZepf, string ASGXf, bool ytzOnFKxbwgM);
};

void BOkzSpCs::FqxEuNxBQRdag(string QoGasHNCBRr, double hRRsguGbWNKZ, string YxBjwzPo, string kNzVLS)
{
    string RCvtGnfTFoAps = string("GbljdzVRZaqqicVMTJubRXrDSKGYdRtblDrvxHEEOXTSIaNIlwLydaXnQwsOzHYzemsbrZoNzjOKTxJzWSkuvmDbvlflUTspHTaDXPRUCZxStVHxjSasJhWLDiRkYlaIpcVzOOAIiejqcwxGvQCzPOFQrHorqYOArNAIyQOHiK");
    bool RwazBNdZsDcWvpVJ = true;

    if (QoGasHNCBRr >= string("tFh")) {
        for (int zjctvgqZ = 1087831117; zjctvgqZ > 0; zjctvgqZ--) {
            RwazBNdZsDcWvpVJ = RwazBNdZsDcWvpVJ;
        }
    }

    for (int MoCda = 1613026475; MoCda > 0; MoCda--) {
        QoGasHNCBRr += RCvtGnfTFoAps;
        QoGasHNCBRr += RCvtGnfTFoAps;
        YxBjwzPo += kNzVLS;
        kNzVLS += kNzVLS;
    }
}

void BOkzSpCs::kKLAFCV()
{
    int hqNdNZ = -1705926352;
    double lpOotAkhIrMIynJ = -148328.0360636865;
    double cBXmeuH = 60241.00856590046;
    bool jegREL = false;
    bool jJsRAFiJIBLmxk = true;
    int twAcazAxOdArn = 1137168531;
    int GqugQbdyFZQesVFV = -759029545;
    double qRlLxwAawCof = -202392.9608779518;

    if (cBXmeuH >= 60241.00856590046) {
        for (int hQIEePp = 789763783; hQIEePp > 0; hQIEePp--) {
            jJsRAFiJIBLmxk = ! jegREL;
            cBXmeuH -= lpOotAkhIrMIynJ;
            lpOotAkhIrMIynJ /= lpOotAkhIrMIynJ;
        }
    }
}

void BOkzSpCs::cCMzOLVyTGGcsxGI(bool zNqPAMxTYOlce, bool emubFOtxeJyGCkc, bool cvemfJhyTkjRMsJ, int lqgWByo, int AfpwayuzdbW)
{
    double aLlXT = 75547.37146279158;
}

void BOkzSpCs::ZDcjrjcSrM(double NDKoxgrQzbLZg, double VCPAIafIszFD)
{
    string MMAhlPoAgvvSe = string("ySbipFLTFEmGWVtracJhPcKEEbIVsURKvMrIFcFvKIjxNoslkUFJicIFPMZeLyNEbLTlTusJTfofXLjbrPIQjXcouVMdZq");
    bool eHmQLYYgVzBmH = false;
    double qgXBGz = 83312.04405934847;
    double dgZxEjrTzKKvdzRD = 808677.2330630288;
    double DDAeouL = -718547.8525993167;

    if (NDKoxgrQzbLZg != -718547.8525993167) {
        for (int YdDOrNJprwIHqZE = 732153839; YdDOrNJprwIHqZE > 0; YdDOrNJprwIHqZE--) {
            NDKoxgrQzbLZg *= dgZxEjrTzKKvdzRD;
            MMAhlPoAgvvSe += MMAhlPoAgvvSe;
            dgZxEjrTzKKvdzRD *= dgZxEjrTzKKvdzRD;
            VCPAIafIszFD = NDKoxgrQzbLZg;
            NDKoxgrQzbLZg -= DDAeouL;
        }
    }

    for (int fIhxsJK = 1084597978; fIhxsJK > 0; fIhxsJK--) {
        NDKoxgrQzbLZg += dgZxEjrTzKKvdzRD;
        NDKoxgrQzbLZg *= DDAeouL;
        VCPAIafIszFD = VCPAIafIszFD;
        dgZxEjrTzKKvdzRD /= NDKoxgrQzbLZg;
    }
}

string BOkzSpCs::IbFXdo(double IFQhGdLB, double QTCSmJ, bool LDwqkrR, int TriYhCSW, bool trOKgIgG)
{
    bool gvIyhIvfDAZWYbO = false;
    double MtIbDrHZp = -723131.7464195682;
    double DRvsnOAltwvZX = 571811.8505437012;
    double qjmnYvDCJfdkLNy = -171143.86611655052;
    int nzFcDMlrOW = -66474091;
    bool oxbzfvXY = true;
    bool tpGyYDXQiI = true;

    if (TriYhCSW > 708581459) {
        for (int EoLJRSgGUGyQnl = 572411576; EoLJRSgGUGyQnl > 0; EoLJRSgGUGyQnl--) {
            oxbzfvXY = ! oxbzfvXY;
        }
    }

    for (int CeCAt = 1558477758; CeCAt > 0; CeCAt--) {
        qjmnYvDCJfdkLNy *= QTCSmJ;
    }

    for (int hIhmIZijQO = 285420957; hIhmIZijQO > 0; hIhmIZijQO--) {
        tpGyYDXQiI = ! trOKgIgG;
        LDwqkrR = ! tpGyYDXQiI;
    }

    for (int DETDkCTLxlEM = 1748303168; DETDkCTLxlEM > 0; DETDkCTLxlEM--) {
        DRvsnOAltwvZX = DRvsnOAltwvZX;
    }

    for (int zCStJXziRVxOEljb = 1579074745; zCStJXziRVxOEljb > 0; zCStJXziRVxOEljb--) {
        gvIyhIvfDAZWYbO = ! LDwqkrR;
    }

    return string("ohOOKV");
}

double BOkzSpCs::LpMQbsWMxicPmvQ(string aIKgfxzQPWy, double xAKmSLBvIWKYFXl, string sexfSduAmQlSuuwl, bool HlCAd)
{
    int hROyRYunuZzI = 80979302;
    int tOmYyiwKfnDJ = -361478512;
    bool rkcMtNXdIglaVJ = false;
    bool cBubUjWqBtfB = true;
    bool byAMXawTpZXSbgUl = false;
    string GHuXY = string("TJdemobAVpJclHjbRbgEhqzuGdtQXeohAsOURyNfkJgPRlKmemippAxEAnEzwtSnksapXuDiCPKPyePWDFYyfcUSFPSDIJqfIgXOafHkNuHEVGFGIeMcHQLrbJUmwGKKpyNZrbXwBnIqLhgVcpKVMvRtGnrZOqzCUIYCsiDrVKbFVoxgwZsFdtxgyFZhNNLHlRbVDCjsObfgyutPhvhcziyhVqCUchkDMKhrhVnmqHZolFJIp");
    int yRbCRXksgkJB = -1672873033;
    bool xEIHzAZ = false;
    string TvoeerrPw = string("NrfbPzDpLlcxEyLgQdboSMcBQCliOTLgLrfieRgxwEsXulzkMXJWOCoMjBgZtwmyDIleWsPjvYhYN");

    if (byAMXawTpZXSbgUl == false) {
        for (int VKwCpvybdDUUjHx = 1487575041; VKwCpvybdDUUjHx > 0; VKwCpvybdDUUjHx--) {
            byAMXawTpZXSbgUl = cBubUjWqBtfB;
        }
    }

    for (int eqeIn = 1935015217; eqeIn > 0; eqeIn--) {
        continue;
    }

    return xAKmSLBvIWKYFXl;
}

void BOkzSpCs::JrYUjXcO(bool QoqDAoENbJNVrS, int CcxHIPkLs, double gBZOa, string ABnILSUDIKtl, double lndSEc)
{
    double OJLnCn = -599779.1493337991;
    int xALqHkKckoLFo = -1141768021;

    for (int BqbkXByXwMKZcZaS = 380645213; BqbkXByXwMKZcZaS > 0; BqbkXByXwMKZcZaS--) {
        lndSEc /= OJLnCn;
        gBZOa /= OJLnCn;
    }

    for (int ZGCZeUc = 1027846104; ZGCZeUc > 0; ZGCZeUc--) {
        continue;
    }

    if (OJLnCn >= -761033.3685892071) {
        for (int liZIERBQFN = 467273388; liZIERBQFN > 0; liZIERBQFN--) {
            lndSEc /= OJLnCn;
            lndSEc /= gBZOa;
        }
    }

    for (int ACtMYZlzeYHh = 41322466; ACtMYZlzeYHh > 0; ACtMYZlzeYHh--) {
        ABnILSUDIKtl = ABnILSUDIKtl;
        xALqHkKckoLFo -= CcxHIPkLs;
        OJLnCn += OJLnCn;
    }
}

int BOkzSpCs::XBYndjmaXJ(int wllNhoKaAaca, bool FMOOdY, bool qQpQrGUXP, bool eTmEgnRnW, int ISZdmsIM)
{
    double pKEBrfXbgKoqm = 90084.14948014599;
    string SFeYxuW = string("dZskaprsUpPwEdkbDEYEZOxJJXnmmauSJHGtCuuiQjexavlDYPjUzbKOZnACozNcFhAkrRekotRgpocLaLbEerDtBzCDxhkTk");

    for (int hCCPpnAcTDJnRK = 64471292; hCCPpnAcTDJnRK > 0; hCCPpnAcTDJnRK--) {
        pKEBrfXbgKoqm = pKEBrfXbgKoqm;
    }

    for (int nvaNFAsEMKD = 608258001; nvaNFAsEMKD > 0; nvaNFAsEMKD--) {
        FMOOdY = ! qQpQrGUXP;
        eTmEgnRnW = eTmEgnRnW;
    }

    for (int AoKZbCNBcTXl = 997177141; AoKZbCNBcTXl > 0; AoKZbCNBcTXl--) {
        ISZdmsIM -= wllNhoKaAaca;
        SFeYxuW = SFeYxuW;
        qQpQrGUXP = ! FMOOdY;
    }

    return ISZdmsIM;
}

void BOkzSpCs::tNJSNC(double DwrAVYtsYEdQ, int OvTuDoXzBQU)
{
    double GNLQuTVWymiVnbpo = 1022212.4345156809;
    double pvdTpLHPVkHeny = -595393.5157291425;
    bool LOUyUEGngweP = true;

    if (pvdTpLHPVkHeny > 1022212.4345156809) {
        for (int AvTfb = 1905845630; AvTfb > 0; AvTfb--) {
            pvdTpLHPVkHeny = DwrAVYtsYEdQ;
            GNLQuTVWymiVnbpo = pvdTpLHPVkHeny;
            pvdTpLHPVkHeny /= DwrAVYtsYEdQ;
            pvdTpLHPVkHeny = GNLQuTVWymiVnbpo;
        }
    }

    for (int vynXrYE = 275888284; vynXrYE > 0; vynXrYE--) {
        continue;
    }
}

void BOkzSpCs::tUnoYP(bool bruIA)
{
    int aVHbEHjp = -199783082;
    string htjmHW = string("LBUziUJgPUUnLlmuuBoClUhIfpCxsUdwwcbZndhpIBEuLAymYErzlPGXxfqfPHwrETUEhjYDFYhODVswSvuwrzEIeUnJOEwvvMhcRRyRHfoLEMt");
    bool cTlCmMRcdVd = false;
    bool yDkDWQvquqp = false;
    double ZFbscaMnJkDpwJk = -831965.2745225329;
    bool dHeKEhYg = true;
    string gYyHiwROwUVhEdg = string("U");
    double MqCzs = -659445.8202162158;
    bool ObFJHHaM = false;

    if (yDkDWQvquqp != false) {
        for (int GabMOQ = 1022707512; GabMOQ > 0; GabMOQ--) {
            yDkDWQvquqp = cTlCmMRcdVd;
        }
    }
}

string BOkzSpCs::NiMKnOFEr(string EzVFk, double xEgtZepf, string ASGXf, bool ytzOnFKxbwgM)
{
    double PdClFKM = 822276.5564867076;
    int TVWLbj = 1386007126;
    bool ViUmwUhwHxTvWG = false;

    for (int eloYyDl = 705677358; eloYyDl > 0; eloYyDl--) {
        continue;
    }

    for (int rxlbDvxMCKph = 522243058; rxlbDvxMCKph > 0; rxlbDvxMCKph--) {
        ASGXf = ASGXf;
        ASGXf += EzVFk;
    }

    if (EzVFk == string("kjcCJNYRdvGavsRuxAMrSpqEUnyTWtnGCPYoZwikDvXjyoZjjPAOeqJJYAhiFlvqCMFOMWdzzBzYBCOAGkVKkMTjbdDYCIdhqjlmTKmcWTKIqgMmoXOHdHnCvBHQMdodmcJidvjBIAmSfxdDPIqeUMptoErggmdxgKCpWauaPCKVlhHSXLwPcMTrERvQenyeoxAEzeMVbMbRwgwxucMXSnLzt")) {
        for (int kNCznwXDdf = 714431325; kNCznwXDdf > 0; kNCznwXDdf--) {
            continue;
        }
    }

    if (TVWLbj <= 1386007126) {
        for (int UUVZTrwfKtqNv = 1269462273; UUVZTrwfKtqNv > 0; UUVZTrwfKtqNv--) {
            continue;
        }
    }

    return ASGXf;
}

BOkzSpCs::BOkzSpCs()
{
    this->FqxEuNxBQRdag(string("tFh"), 390170.4061841392, string("xbWbOsAqSsywMdfFbeCGVaPQHUOUXKGahyiygFQYdeKFCCffOnqtlFftyHMyFBrWa"), string("IywNEgSYmrPHOrcirCSsySPZlPbjuIboaOjBypdvQvrDpzDDlmgOIgKIDRvGtorBEjpfOcFAjfeKhqeafKwjUjNaqCHXUheKDzxpdJkxvRndNEVLNkRZkpvTyYYQqSMplWVkMOqOHZNWXplNeSbdYCtrRuntITnMssqeHGpaBjkeWXvFDpjmZMgGPuHTaIkLTqDCxhXcgCgaJxkuAwIABuToP"));
    this->kKLAFCV();
    this->cCMzOLVyTGGcsxGI(true, true, true, -271513327, -1382196126);
    this->ZDcjrjcSrM(389426.56373546366, -650628.5954894562);
    this->IbFXdo(-786464.7720950787, -518557.90562489675, false, 708581459, false);
    this->LpMQbsWMxicPmvQ(string("hcRejkILTMYOqLWRPkukqrGWDfhRTWsIAjdzPPVGGzhRQiFIOZigTsisxTKBeZYiBPzCfLdylrDjARrgLodLjQPzVOhaZNKSZhRXf"), 1017654.2036152626, string("tTRLCfbkvEiMbSezQVOROJMeYoboYslnHksHwRDfUvqtDoYTKYBuTSeEWkvMMoFIFJIpNMEVpDcOeFUQPTNrGxalsaTzHtZpsuUmLYSaurxmSMoFQmiylKgpxLAkdvAQijiDIiKMBdcehsgEgtaXCHQCInPRltzCRTbMxzdAGedsSbKtuIEeyvJWrVyN"), false);
    this->JrYUjXcO(true, -840115981, 518592.5451028056, string("OMzRPUQmAtPBNHEdYUExydNNEwSvwDxqtLsUNBlXlJNhpjRdCorZBkxJLNTVcnzIDaUvvbvPShpdipUBhDgXklWkTIAvLsCAOhvHcWjYrIBZKbVIRRDnVIkRiKjIqDAntNepVuqKBmkJqaiDPDfuscRbWBNTYYyVUzSnesLMpVokEImTpqfrrZIlKVaNqLKVHKl"), -761033.3685892071);
    this->XBYndjmaXJ(947542036, true, true, false, -1441485536);
    this->tNJSNC(342761.1269099479, 1036983863);
    this->tUnoYP(true);
    this->NiMKnOFEr(string("dHPMkVwwHLfJigybxrsHZwtJEBFfZZquaIRlqFAQMyMkfcFfsTOcHdEBNplxbBtuPorNOWVJTJoBtwpooldkrTwmOzQVlnZTulYVEmpCSQHoaJtYQiIHmVVEWSdMiyoINhP"), -531375.4311776555, string("kjcCJNYRdvGavsRuxAMrSpqEUnyTWtnGCPYoZwikDvXjyoZjjPAOeqJJYAhiFlvqCMFOMWdzzBzYBCOAGkVKkMTjbdDYCIdhqjlmTKmcWTKIqgMmoXOHdHnCvBHQMdodmcJidvjBIAmSfxdDPIqeUMptoErggmdxgKCpWauaPCKVlhHSXLwPcMTrERvQenyeoxAEzeMVbMbRwgwxucMXSnLzt"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hOqUuI
{
public:
    string GWntW;
    int LZBGucdkRDo;
    int oXHRXAoUg;

    hOqUuI();
    double EkimkvSEUP();
    string tNRgj();
    bool QCvBQEpjtmi();
    void UaTpyPz(bool tDxNAQ, double rmGiaEUnkiJTESD, int YQXIMvMVUjMqz, int svfUxjfSdoMFdux);
    bool CumUiOD(int pCvnFcUkCaXJkI, double zThARrtMAPwsht, string LFYGkxzaORn);
    int VjJVDHNKNuynqV(double PapwimGCkffx, bool MoARDCiJ, string vZcxqvAl);
    void oTgzeTmxRK(int rpiHOGKpTrhFFvhm, double KagktynznAoKDB);
    double hDNDfSJLsvApVKaP(bool gEdvg, string OsVrtiraVMf, bool prqpXWJCJffzcGfu, double rBETxuSSEHnA);
protected:
    string EgZbIhsQrTEBaLRR;
    int jVxIP;
    bool XWAoGwTDZoHtWpoh;
    int dyVRUjJciyLE;
    double YppbMZaGjv;

private:
    double XPUJGXDo;
    double inAwyADedOJ;
    bool uvXNkQPGksAKsj;
    double GjNYFHOJq;
    int BajeuFlrldivBD;
    int NiGueRmihg;

    bool tHmHA(bool JACoMCy, double HmJgLLoGNKcBH, bool PKpPqQhpezfH);
    int KAaho(double UvYZFyRVQKNXZun);
    void foWUA();
    int MuDuePQrI(double VIudWFdEak, double vPpRidSTTLyKkpvP, bool wKkcYnuCt);
    string dXACK(string TTmkyIEGepScI, double rDoxxfDhKRdUXTrX, string xjTonEgzzDqwtDs, string YpRBidj);
};

double hOqUuI::EkimkvSEUP()
{
    bool mmfDA = false;
    double GoEDwgeW = -942908.2744704982;
    double LwsPJO = 955931.4322978605;
    int znrAMwutdfeOGuO = 659125321;
    int lWrvkBsk = 1131550378;
    string uylPsXNuK = string("KPGmUQHdZEpCjkuLkyPGtLAmxHiVLDgeFDwaFrgJEeeUpmixVosbjwECLXXNomdUeTxdnuvfbaMA");
    bool uMcfnmMn = true;
    double CObPLn = -884.915293743728;

    for (int WPPrMKHRAJqGI = 1624762247; WPPrMKHRAJqGI > 0; WPPrMKHRAJqGI--) {
        CObPLn = CObPLn;
        uMcfnmMn = ! uMcfnmMn;
    }

    for (int KKdHZYZkcqOKPD = 836104775; KKdHZYZkcqOKPD > 0; KKdHZYZkcqOKPD--) {
        GoEDwgeW = GoEDwgeW;
        LwsPJO += GoEDwgeW;
        LwsPJO += GoEDwgeW;
    }

    for (int SDGwsbVpm = 197188015; SDGwsbVpm > 0; SDGwsbVpm--) {
        continue;
    }

    return CObPLn;
}

string hOqUuI::tNRgj()
{
    double zpgSZgIhhvAoMnhP = 692652.6929189817;
    bool sBoBENgnfrZWUcQ = false;
    bool YCCTWuQMnffGbz = false;
    int heGDGagD = 2080910303;
    double nqXngIm = -729311.0387806973;

    for (int xLoKaM = 1619772019; xLoKaM > 0; xLoKaM--) {
        zpgSZgIhhvAoMnhP /= nqXngIm;
        sBoBENgnfrZWUcQ = ! YCCTWuQMnffGbz;
        zpgSZgIhhvAoMnhP /= zpgSZgIhhvAoMnhP;
        zpgSZgIhhvAoMnhP *= nqXngIm;
        sBoBENgnfrZWUcQ = sBoBENgnfrZWUcQ;
    }

    for (int msUQVIueLa = 2046944961; msUQVIueLa > 0; msUQVIueLa--) {
        sBoBENgnfrZWUcQ = YCCTWuQMnffGbz;
        nqXngIm *= nqXngIm;
        heGDGagD *= heGDGagD;
    }

    if (sBoBENgnfrZWUcQ != false) {
        for (int BUmjKYKuiIWwSZa = 333380635; BUmjKYKuiIWwSZa > 0; BUmjKYKuiIWwSZa--) {
            continue;
        }
    }

    return string("uaTlohqDfcvaRzMfRMVzyUOfvCvmRlsPRMyVJxor");
}

bool hOqUuI::QCvBQEpjtmi()
{
    bool exNDuJOwptUupcA = false;
    bool HWXWepfCYmIv = true;
    double KCQQVmKLWQ = -701061.877873136;

    if (KCQQVmKLWQ != -701061.877873136) {
        for (int umxgkYLnTD = 1879921782; umxgkYLnTD > 0; umxgkYLnTD--) {
            continue;
        }
    }

    for (int xCieUa = 2060782169; xCieUa > 0; xCieUa--) {
        exNDuJOwptUupcA = ! exNDuJOwptUupcA;
        KCQQVmKLWQ -= KCQQVmKLWQ;
        exNDuJOwptUupcA = exNDuJOwptUupcA;
        exNDuJOwptUupcA = exNDuJOwptUupcA;
    }

    for (int GOsSisjcsAm = 1513020794; GOsSisjcsAm > 0; GOsSisjcsAm--) {
        exNDuJOwptUupcA = exNDuJOwptUupcA;
        HWXWepfCYmIv = ! exNDuJOwptUupcA;
        HWXWepfCYmIv = ! HWXWepfCYmIv;
    }

    for (int XRskbcT = 161863360; XRskbcT > 0; XRskbcT--) {
        HWXWepfCYmIv = ! exNDuJOwptUupcA;
    }

    for (int nGdojUEza = 1820086655; nGdojUEza > 0; nGdojUEza--) {
        exNDuJOwptUupcA = HWXWepfCYmIv;
        HWXWepfCYmIv = ! exNDuJOwptUupcA;
        HWXWepfCYmIv = HWXWepfCYmIv;
        exNDuJOwptUupcA = ! HWXWepfCYmIv;
        KCQQVmKLWQ -= KCQQVmKLWQ;
    }

    if (exNDuJOwptUupcA != true) {
        for (int gsafx = 775094107; gsafx > 0; gsafx--) {
            exNDuJOwptUupcA = exNDuJOwptUupcA;
            exNDuJOwptUupcA = ! HWXWepfCYmIv;
            exNDuJOwptUupcA = ! exNDuJOwptUupcA;
            exNDuJOwptUupcA = ! exNDuJOwptUupcA;
        }
    }

    if (exNDuJOwptUupcA != false) {
        for (int OEcOvKu = 290161527; OEcOvKu > 0; OEcOvKu--) {
            KCQQVmKLWQ -= KCQQVmKLWQ;
            exNDuJOwptUupcA = ! HWXWepfCYmIv;
        }
    }

    for (int DNcVTaBgEFtnx = 2076393508; DNcVTaBgEFtnx > 0; DNcVTaBgEFtnx--) {
        exNDuJOwptUupcA = exNDuJOwptUupcA;
    }

    return HWXWepfCYmIv;
}

void hOqUuI::UaTpyPz(bool tDxNAQ, double rmGiaEUnkiJTESD, int YQXIMvMVUjMqz, int svfUxjfSdoMFdux)
{
    bool ONoWsaePdWKCTUSS = true;
    int LZbKrcvgUlzxbDmB = -865705276;
    double tDXKjYddsJJIrY = 175513.37779147943;
    string aRjhVcz = string("XxvjgUuKeNxvclxHvXucmZdSbMhhfioVmRSVmDnlhKiwLoqqdzKcQoaueqJxHPuedOmUnnWeJrOeURuAgZYCxjqPdFgJsniaFaiSOrOFQHtyIrqqfPVeFIBWAVntaYKWGnjjeQIOgNcJMAKOSctthHVNXZQaVsbvrVngfYWMSNDunMttMVRFRtWrjYMSvjltHTWzoZpwzxntCoAzpHsPRpkxewsEkUVJgbPJzmhwfsJtEfuPDEZGneIlfzyW");

    for (int JjGfPDdQqlBO = 1770602641; JjGfPDdQqlBO > 0; JjGfPDdQqlBO--) {
        ONoWsaePdWKCTUSS = tDxNAQ;
        LZbKrcvgUlzxbDmB += svfUxjfSdoMFdux;
    }

    for (int VMxTsmo = 1077140132; VMxTsmo > 0; VMxTsmo--) {
        tDXKjYddsJJIrY *= tDXKjYddsJJIrY;
        svfUxjfSdoMFdux += YQXIMvMVUjMqz;
    }
}

bool hOqUuI::CumUiOD(int pCvnFcUkCaXJkI, double zThARrtMAPwsht, string LFYGkxzaORn)
{
    double yhurr = -434165.14818619314;
    int LFsgEqGluCIbl = -1511651111;
    double VbvIqOSFkTehYKM = -513776.56568706775;
    int rblPCBn = 1019210232;

    for (int VpBfUlfvOZ = 1199075447; VpBfUlfvOZ > 0; VpBfUlfvOZ--) {
        continue;
    }

    for (int HJsksxjTWF = 1960835456; HJsksxjTWF > 0; HJsksxjTWF--) {
        zThARrtMAPwsht *= yhurr;
        rblPCBn -= rblPCBn;
        zThARrtMAPwsht /= zThARrtMAPwsht;
    }

    for (int zCKWwhTTK = 707319077; zCKWwhTTK > 0; zCKWwhTTK--) {
        rblPCBn *= pCvnFcUkCaXJkI;
        rblPCBn = pCvnFcUkCaXJkI;
        LFYGkxzaORn += LFYGkxzaORn;
    }

    if (LFsgEqGluCIbl == -1511651111) {
        for (int pvhIfGZnaelOm = 245754768; pvhIfGZnaelOm > 0; pvhIfGZnaelOm--) {
            zThARrtMAPwsht = VbvIqOSFkTehYKM;
            LFsgEqGluCIbl += LFsgEqGluCIbl;
            yhurr /= yhurr;
        }
    }

    for (int rUCJey = 1633410875; rUCJey > 0; rUCJey--) {
        VbvIqOSFkTehYKM -= zThARrtMAPwsht;
        LFsgEqGluCIbl *= rblPCBn;
    }

    if (yhurr == -513776.56568706775) {
        for (int tBjTZxHp = 1835904519; tBjTZxHp > 0; tBjTZxHp--) {
            rblPCBn *= pCvnFcUkCaXJkI;
            yhurr -= zThARrtMAPwsht;
            rblPCBn -= rblPCBn;
        }
    }

    for (int kbvJAY = 54329827; kbvJAY > 0; kbvJAY--) {
        VbvIqOSFkTehYKM -= zThARrtMAPwsht;
        yhurr = VbvIqOSFkTehYKM;
        VbvIqOSFkTehYKM *= yhurr;
        yhurr /= zThARrtMAPwsht;
        pCvnFcUkCaXJkI += rblPCBn;
    }

    for (int mCIPPNoDzLdX = 1048304403; mCIPPNoDzLdX > 0; mCIPPNoDzLdX--) {
        VbvIqOSFkTehYKM += yhurr;
    }

    return true;
}

int hOqUuI::VjJVDHNKNuynqV(double PapwimGCkffx, bool MoARDCiJ, string vZcxqvAl)
{
    int QbkTekcqTdNPFDha = -1497570667;

    for (int tiClaMPrWw = 1166844915; tiClaMPrWw > 0; tiClaMPrWw--) {
        PapwimGCkffx -= PapwimGCkffx;
    }

    return QbkTekcqTdNPFDha;
}

void hOqUuI::oTgzeTmxRK(int rpiHOGKpTrhFFvhm, double KagktynznAoKDB)
{
    string QRoDeir = string("SghqEAhwYFVvdlbfGfTEulyxzljuLAlMqZWzGXYZPdmRBOxdLOvrxhyQdRVOiRBeQj");
    int TaPyzZd = 2134864887;
    int miltQzUGO = -607586983;
    bool BsnetTEyrtlKSO = true;
    double nIKBIUVfGpXpkDae = -376195.2061461083;
    bool fDEgdIwKhIApx = true;
    string ACshZ = string("lFVTULvPUpFzhXKZkERjomPjLlqWEhwQktwMrMnNhiPDLelnAuBAcCXbwqtwnFcJAkHmsXnIKdmYiUqDtPUgvVABmAtPQRPoESZridEpRgsFeFXmftvCVMjGfErarTmwuqipgLbFqDtaHaiDuuWoiqAQAXwUFvkQfTfGbEUbUovIhfmEosnsZMgAfViilxjmNdGWRDrWjFmJduIbWpTNqSfhTcVRIMpwvc");

    for (int OWEeh = 1686305746; OWEeh > 0; OWEeh--) {
        QRoDeir += QRoDeir;
    }
}

double hOqUuI::hDNDfSJLsvApVKaP(bool gEdvg, string OsVrtiraVMf, bool prqpXWJCJffzcGfu, double rBETxuSSEHnA)
{
    double atTvjaVHAGiwYtN = -999625.1772136923;
    string bNgufuwVpO = string("wPorwfxTJqfCsToqhulUNOxuTGMcvrbXjNUhcQLygLncYuMzLLuTSmlFzyOAbIkDcUrrkwJzqDIlhcVwXmajxyzmxtVDnvpMzbvRQHTIWMGutTeDbBfVuonzxlEiTToEKdIpnTBUVJefXLmsUiTlEC");

    for (int ogHlxa = 1663732038; ogHlxa > 0; ogHlxa--) {
        OsVrtiraVMf += OsVrtiraVMf;
        bNgufuwVpO = OsVrtiraVMf;
    }

    if (rBETxuSSEHnA == 339144.56521619775) {
        for (int IfQQlWIuNdQsf = 2023134104; IfQQlWIuNdQsf > 0; IfQQlWIuNdQsf--) {
            gEdvg = gEdvg;
        }
    }

    for (int nGnAjTt = 1184089385; nGnAjTt > 0; nGnAjTt--) {
        atTvjaVHAGiwYtN = rBETxuSSEHnA;
        atTvjaVHAGiwYtN += rBETxuSSEHnA;
    }

    if (OsVrtiraVMf > string("wPorwfxTJqfCsToqhulUNOxuTGMcvrbXjNUhcQLygLncYuMzLLuTSmlFzyOAbIkDcUrrkwJzqDIlhcVwXmajxyzmxtVDnvpMzbvRQHTIWMGutTeDbBfVuonzxlEiTToEKdIpnTBUVJefXLmsUiTlEC")) {
        for (int RdBwm = 1670801202; RdBwm > 0; RdBwm--) {
            atTvjaVHAGiwYtN += atTvjaVHAGiwYtN;
            bNgufuwVpO = OsVrtiraVMf;
            gEdvg = ! gEdvg;
        }
    }

    return atTvjaVHAGiwYtN;
}

bool hOqUuI::tHmHA(bool JACoMCy, double HmJgLLoGNKcBH, bool PKpPqQhpezfH)
{
    bool YPTrDUKRGmWVhkp = true;
    bool iauTyKyoqpSw = true;
    bool BEMODTlqLFQjLg = true;
    string mJOagFWlyRputc = string("DgtAKCpqcLacdPCfmYQxSaxczPWkaJhmghZcSondQiaihQXRCmKXSTaHYScqzDeesowOUvJYPmjwdoLQdSONltXPYYQwxovwxlNAGSI");
    int rKMcuyB = -1231528029;
    double OBlCcob = 394713.710503317;
    bool apYutvzMwcEAbMTF = true;
    bool aAlTZ = true;
    string EinFWzlft = string("hqngPLiaXroZQNmvuiMehfloFrrGmurhCanTSMRUIQidciwkpcZMvfWaJLCbwXLTdLJJrlzIbWhKjizXsccxHntZjHErJdiRsfGQrMYuLlCLQHFTlIKXAQwfOFYNHpxYAPlcaiFflHQsMfDCNHtVwGeWlDPmeQoSZUYJHnHmdWYaHeKx");
    bool FjfCIXdiVaBTgTPp = false;

    return FjfCIXdiVaBTgTPp;
}

int hOqUuI::KAaho(double UvYZFyRVQKNXZun)
{
    bool skSimOrPT = false;
    bool NnrzPWDQeJxy = true;
    double ytOohPkoStIgMxEZ = -2680.260132372555;
    double HDOyzBJqPdbn = -966939.2433730528;

    for (int zTMHOgKwtYWQFzDK = 167356091; zTMHOgKwtYWQFzDK > 0; zTMHOgKwtYWQFzDK--) {
        UvYZFyRVQKNXZun /= UvYZFyRVQKNXZun;
        skSimOrPT = skSimOrPT;
        NnrzPWDQeJxy = ! skSimOrPT;
        skSimOrPT = ! skSimOrPT;
    }

    if (HDOyzBJqPdbn <= -2680.260132372555) {
        for (int tKtDjrWvVHgdgHxn = 1591201592; tKtDjrWvVHgdgHxn > 0; tKtDjrWvVHgdgHxn--) {
            continue;
        }
    }

    return 377266900;
}

void hOqUuI::foWUA()
{
    bool YrMqCmNvPhdjyZVH = false;
    int dskWALE = -379755278;
    bool DDKbJfFaGwsrOVO = true;

    if (DDKbJfFaGwsrOVO != false) {
        for (int JrpePkQh = 1430153078; JrpePkQh > 0; JrpePkQh--) {
            DDKbJfFaGwsrOVO = ! DDKbJfFaGwsrOVO;
            DDKbJfFaGwsrOVO = ! YrMqCmNvPhdjyZVH;
        }
    }
}

int hOqUuI::MuDuePQrI(double VIudWFdEak, double vPpRidSTTLyKkpvP, bool wKkcYnuCt)
{
    bool EmVneunKvNgKNBd = true;
    int dsxUpti = 1448159381;
    string OGSmMbrjTTU = string("OsrZfFDRxNGByMBJlCORdZywOSaVtGKdmcQxuikcFJheMiPhmAwJETEouXOURxLPhXMVZTSxtRGnXfwlBFvRkCyrJoqFPAggbZKTNHjeUhCStKSZbjJnDujShyEGaDgkxpdhKmeYktDLBpuYRuCkxXNBgbQZgVKaktaBDdkDICjMybEwfatpxVhtWjhbnqaflvoBXhXbSnFCOIVYNMMrbXRpvtzzntuwoxVuOLpqRNMPbrp");
    string erhIgIyHDtiP = string("PtpFCjZzwcXlAoTJhNjhMpRpAScfZljEfYGPsHWotmDAYcDyfzPYxlIhTKxVnzLWDNpSNgTwlThhuycjjYtuDLjeIjLpsOuyKtrCpNQWxnCOoBeIbPyDiuNlprRmqGIxwqYAe");
    bool oWKvwBQiDV = true;
    int TKpSDmCMGZyvR = 1667049267;
    double gVvkixSSkHG = 112068.371925977;
    bool jSqzyMyHZgVYU = true;
    int HerxySTLKbO = -219918789;

    for (int nwwgXoOLIuAXaP = 1707387466; nwwgXoOLIuAXaP > 0; nwwgXoOLIuAXaP--) {
        wKkcYnuCt = EmVneunKvNgKNBd;
        OGSmMbrjTTU = erhIgIyHDtiP;
    }

    for (int QAkfrOrQGcoKNTHy = 909004891; QAkfrOrQGcoKNTHy > 0; QAkfrOrQGcoKNTHy--) {
        jSqzyMyHZgVYU = wKkcYnuCt;
        wKkcYnuCt = jSqzyMyHZgVYU;
        HerxySTLKbO /= dsxUpti;
    }

    if (wKkcYnuCt != true) {
        for (int CuwPxWZgk = 1646392550; CuwPxWZgk > 0; CuwPxWZgk--) {
            EmVneunKvNgKNBd = ! oWKvwBQiDV;
        }
    }

    return HerxySTLKbO;
}

string hOqUuI::dXACK(string TTmkyIEGepScI, double rDoxxfDhKRdUXTrX, string xjTonEgzzDqwtDs, string YpRBidj)
{
    bool KzkaAZELUmhDIE = true;
    int huNNevYRSHL = 216667580;

    if (YpRBidj < string("zHtsURDRsUxbhrGLwLQiXFZfjByOaWnPpKWQlQNEfdms")) {
        for (int nZfJr = 808611759; nZfJr > 0; nZfJr--) {
            TTmkyIEGepScI = TTmkyIEGepScI;
        }
    }

    if (YpRBidj < string("zHtsURDRsUxbhrGLwLQiXFZfjByOaWnPpKWQlQNEfdms")) {
        for (int SxaddqfQSYvwMz = 13496398; SxaddqfQSYvwMz > 0; SxaddqfQSYvwMz--) {
            TTmkyIEGepScI += YpRBidj;
            YpRBidj = YpRBidj;
            TTmkyIEGepScI = YpRBidj;
        }
    }

    for (int CtFFRzivtvBmgCyf = 1034774796; CtFFRzivtvBmgCyf > 0; CtFFRzivtvBmgCyf--) {
        xjTonEgzzDqwtDs += TTmkyIEGepScI;
    }

    if (KzkaAZELUmhDIE != true) {
        for (int CRvarbdMr = 1947346479; CRvarbdMr > 0; CRvarbdMr--) {
            YpRBidj += xjTonEgzzDqwtDs;
        }
    }

    for (int miBaLkxAJAIA = 818942296; miBaLkxAJAIA > 0; miBaLkxAJAIA--) {
        huNNevYRSHL *= huNNevYRSHL;
        xjTonEgzzDqwtDs += TTmkyIEGepScI;
        TTmkyIEGepScI += xjTonEgzzDqwtDs;
        YpRBidj += YpRBidj;
    }

    for (int SRekrf = 2006971377; SRekrf > 0; SRekrf--) {
        huNNevYRSHL -= huNNevYRSHL;
        rDoxxfDhKRdUXTrX *= rDoxxfDhKRdUXTrX;
        xjTonEgzzDqwtDs = TTmkyIEGepScI;
    }

    return YpRBidj;
}

hOqUuI::hOqUuI()
{
    this->EkimkvSEUP();
    this->tNRgj();
    this->QCvBQEpjtmi();
    this->UaTpyPz(true, -476712.27638136485, -4391313, -818910901);
    this->CumUiOD(1581409458, 235881.32219436904, string("wyFfQOyALsTHiDwIzAjRbxxYJzjPxA"));
    this->VjJVDHNKNuynqV(-675318.1492024695, true, string("zAoleKlIGiBMEPvxzPtjROucZOfMbHsBkuKxWlVmecgcoPLvEwVtswDfIYaxqVyzqxsN"));
    this->oTgzeTmxRK(-1825939538, -139617.58652845488);
    this->hDNDfSJLsvApVKaP(true, string("lTyGmdLXFxtbruTgtfYFVqjTUZZcUfsxMdFgEFEINZpuNEnQAwhWwmIxOpjEpBhtZtfOpdWVqlLHbIXlcLbRWMxkkGhUTmnyqg"), true, 339144.56521619775);
    this->tHmHA(false, 135182.75067808412, false);
    this->KAaho(-618673.197674478);
    this->foWUA();
    this->MuDuePQrI(-788526.9660729242, -720248.9230133947, true);
    this->dXACK(string("zHtsURDRsUxbhrGLwLQiXFZfjByOaWnPpKWQlQNEfdms"), 731733.8670451145, string("qZQGZVvinlIcVnrfzCIxKGmsfJxLUnmTaUabDSqEno"), string("VQPfLzoowPZgomKtIBBsGKhSMEiBknEoFrVFYWRukENfAHlWzjlXpOIwCfiiDoWFaUTMZmJDeHBSkfsjCjlSABVqmBZMVRLkkcxfXEPJOLODfnCTFRoZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pOVSeSxybKNhrsvv
{
public:
    int LSlBq;
    bool iucUIOrEtm;

    pOVSeSxybKNhrsvv();
protected:
    string zJiIVbOep;
    int xWsBEO;

    void pDNiWenpWZ(double ELtARgPgOn);
    void aplqyvgQhtpkdZMB(string TPVMTDCeCNCSNUmX);
    int BuAfyGvjdN(int nsNomKLubDPuT, bool wSwguQiVZOa);
    int ofsOD(double fEkEMkXZ, bool QoFPRfjxOM, bool cDjNDjTu, int yckwyKjwrn, bool WJEJyD);
    bool PjOWKipeVjqoyks(int KEiUvjuvaY, string LPkOZSDld, bool cTgtIARuxvtDgIU, int CgZiJhulZoPNu, string IFAXy);
    bool MdNarMk(bool zcuPGLO, double MSnrKcy);
private:
    string UzXdOpJ;
    double gZVQywQuRQwnP;
    int qMxSMZR;
    double SCUmrvkXeQU;
    double uhWREadYvdkaHvIL;
    double VveUMejaeiShvLA;

    void KukicVg(string iiTyrVbSa, bool mvAnC, bool vivgxdtItuX);
    void ohSrpYZtVxezkCK(bool nahhrD, bool WHlJT, double pUlCXgoHaP);
    bool pWvcfjQaCv();
    bool AtcjdhUAFbghAB(int FwHjZ, bool JtIIVqEny, string KyZbkpvT, int UeYZAiDasJgwR, bool uNkWV);
    bool zVtvHgyTINvoDXv();
    int rqcUhfouP(string gePqlqzgNJtx, bool aauCrxhhmfrj, bool SCfoPzafwPdLhcgW, int txaDURLGOkE);
    int aPdbJMuMglPsEHVz(string BrApjXiLVBOc, double VdUxtUhFMSrJEo);
};

void pOVSeSxybKNhrsvv::pDNiWenpWZ(double ELtARgPgOn)
{
    bool HkPAbbHMr = true;
    double tTDdhhxs = -380101.9278183649;
    bool OOKtvoWqGYws = true;
    string OhJnfpdcAG = string("kUuBnWGlChiIwSUXJmyVLWyMBawIqgjdbPhrLcTEnBfOTtSDimXjLPzrSgREUijllRXKbMBaOivRvwsmcWWIkFACdXwSaouxTEnrAFzsTqJUwpddznvjlRzBMdoobAPFfnhUnGNSJndviRAuiZwMWYWeEjSqMBfhTTxEmUwEOMegnGgYIitiBKzxOTqmifEhhQdvhNFQFaweyFxDnXunGBPtcWdYKrcnbufHuFsbD");
    string MehDlFmHaI = string("tcAzpqMAWJAxOTqdVRVSGHdcCIUijzZPupBfnlbuRBthvncwhwXWjmGHWMIfytTxQksOsNzIjxJtusYuRpMbnUfUctMPLuCZnwlkgPjhlhIKclEUDaFAyXKbXfFf");
    string QxbZqblpIksfTeK = string("UdiAIxHaqlYyPfbVphZjyfttXtZoqzggcKQDAZPZtZWLBuLUsSVeZdEySoPYaQyQNKxODCGkUuFKfmpNlFYpGQkakvMwnKAEmsoqzPTaKXbPzmTAquqLKZFqmITS");
    int cJJCkr = -1408796917;
    double VOcAGLHxholD = -833972.0104932551;
    double MRMfEO = -522125.98841680784;

    for (int FAfGshHykdbfCsp = 295421552; FAfGshHykdbfCsp > 0; FAfGshHykdbfCsp--) {
        VOcAGLHxholD -= MRMfEO;
        VOcAGLHxholD = MRMfEO;
        HkPAbbHMr = ! HkPAbbHMr;
        OOKtvoWqGYws = ! HkPAbbHMr;
        VOcAGLHxholD = MRMfEO;
    }
}

void pOVSeSxybKNhrsvv::aplqyvgQhtpkdZMB(string TPVMTDCeCNCSNUmX)
{
    double hBzXQGTtNGsB = 171503.09707900058;
    int ppVCXyUnbU = 1248946632;
    int fIwnjbPqtKKgbJb = -1330264140;
    bool NeiUyZSQeOsTrC = false;
    string wMueL = string("koFMwEMrXzUkcFlZsAsYGADOoPqVqAenKiUtPUhtHbDTOUiVgnBfFXDNFFnuWbTlWFlGZQzUGYPIulzOOpjyeVRYuXHxsoASzeuvsOXRaZJvaCNRztEVQGRzyzeBfrULIVcjvBFcZWrjbfByZjrHyLVfaSuzyQMToWGawZJwezdjRYcnpjXAVlqdsb");
    bool zODrWEzEtyRPH = true;
    int TgOyRLWN = 155852511;
    double cvzfaYibLofghRaZ = 217811.98071283454;
    int IsCaQtzJYHKSrEHN = 1450276443;
    string QtNtybaaiI = string("zXMOLfeRPGQFhNnQLhEsEJvlpNsTwFSBzmLBYalVfPmXUFHleDnHRGFWELoKbZcDifaMgVqycVoqZLswbnstKvIxNrLDQSpuJqJzfPhVngTRACscNSFsgLvEogCvLZzpGDTuwjdXHciFbsMMsWZzDSkFMugZRhaMfaNjgAzaLe");

    for (int mHOYCpT = 1349390822; mHOYCpT > 0; mHOYCpT--) {
        wMueL += wMueL;
        cvzfaYibLofghRaZ *= hBzXQGTtNGsB;
    }

    for (int PvTkEWOLiPwTPWX = 963650698; PvTkEWOLiPwTPWX > 0; PvTkEWOLiPwTPWX--) {
        ppVCXyUnbU += ppVCXyUnbU;
        zODrWEzEtyRPH = ! zODrWEzEtyRPH;
        fIwnjbPqtKKgbJb /= TgOyRLWN;
    }

    for (int LnzWoykQs = 601091700; LnzWoykQs > 0; LnzWoykQs--) {
        TPVMTDCeCNCSNUmX += TPVMTDCeCNCSNUmX;
        TgOyRLWN -= fIwnjbPqtKKgbJb;
    }

    for (int rupztervc = 837703534; rupztervc > 0; rupztervc--) {
        TgOyRLWN = fIwnjbPqtKKgbJb;
        IsCaQtzJYHKSrEHN -= ppVCXyUnbU;
        cvzfaYibLofghRaZ *= hBzXQGTtNGsB;
    }
}

int pOVSeSxybKNhrsvv::BuAfyGvjdN(int nsNomKLubDPuT, bool wSwguQiVZOa)
{
    int agobRyVXIOWtVlnC = -28292208;
    bool CZqQkO = false;
    double jopks = 902123.6175770011;
    string ATHJdwqx = string("wvROCWTwQAfddWZDeunrtvAslPDCFXerHcLKIPILYviLFvperOAoGWoPOfcrmLjyYmeGrwKxLzpMaReqmZYoFcEmbJCd");
    double YOLyYUFClLkxaw = 299320.96457346936;

    for (int HclVPdtvtcztXg = 898587902; HclVPdtvtcztXg > 0; HclVPdtvtcztXg--) {
        nsNomKLubDPuT += agobRyVXIOWtVlnC;
        agobRyVXIOWtVlnC *= nsNomKLubDPuT;
        CZqQkO = CZqQkO;
    }

    if (jopks <= 299320.96457346936) {
        for (int QqAAhcdgDTrLboH = 916325222; QqAAhcdgDTrLboH > 0; QqAAhcdgDTrLboH--) {
            YOLyYUFClLkxaw *= jopks;
            wSwguQiVZOa = CZqQkO;
        }
    }

    for (int kuUHk = 1751081263; kuUHk > 0; kuUHk--) {
        agobRyVXIOWtVlnC *= agobRyVXIOWtVlnC;
    }

    if (agobRyVXIOWtVlnC != 458681418) {
        for (int otlFBRdLPQ = 1950795682; otlFBRdLPQ > 0; otlFBRdLPQ--) {
            continue;
        }
    }

    if (CZqQkO == false) {
        for (int CfXrz = 1431649040; CfXrz > 0; CfXrz--) {
            CZqQkO = CZqQkO;
        }
    }

    return agobRyVXIOWtVlnC;
}

int pOVSeSxybKNhrsvv::ofsOD(double fEkEMkXZ, bool QoFPRfjxOM, bool cDjNDjTu, int yckwyKjwrn, bool WJEJyD)
{
    bool QcNCHCy = true;
    double jYyQsacmMyHDnn = -769052.4602497068;
    int cLyZQADvMmnc = -1764716528;
    bool tyAaNRSTyJY = false;
    int bVpzQR = 1670660266;

    for (int zHImtZMz = 1509583959; zHImtZMz > 0; zHImtZMz--) {
        jYyQsacmMyHDnn += jYyQsacmMyHDnn;
        tyAaNRSTyJY = tyAaNRSTyJY;
        fEkEMkXZ -= fEkEMkXZ;
        QcNCHCy = QoFPRfjxOM;
    }

    for (int TpwKYdSnB = 986582137; TpwKYdSnB > 0; TpwKYdSnB--) {
        WJEJyD = ! cDjNDjTu;
    }

    for (int UWAVktITQNVmlfh = 1967211552; UWAVktITQNVmlfh > 0; UWAVktITQNVmlfh--) {
        WJEJyD = WJEJyD;
        QcNCHCy = QoFPRfjxOM;
    }

    if (cDjNDjTu != false) {
        for (int eovjVMPvfOXdGG = 705526414; eovjVMPvfOXdGG > 0; eovjVMPvfOXdGG--) {
            cDjNDjTu = ! QcNCHCy;
            fEkEMkXZ /= fEkEMkXZ;
        }
    }

    return bVpzQR;
}

bool pOVSeSxybKNhrsvv::PjOWKipeVjqoyks(int KEiUvjuvaY, string LPkOZSDld, bool cTgtIARuxvtDgIU, int CgZiJhulZoPNu, string IFAXy)
{
    string BmBRzBUqPPAk = string("XTeEbkxnUVcKKpnwjKcTHWHGdteRmLBZLYFxoWJQhudkbdcAlxGXPUfqVeuDVLFLzLBgirZWtNPKMUpcKNOeyvWDevLrFyCTtHugNkGllDKvEQVPwlJcqWWxkvZdfYfbaBkHLuwwyLPUFmaVDFfZfYUhOJzNwoLILwraEVddUZDpSqwsRrIenTCDfHqVbHFBpoCBjSPPNeEUsslfayjBtNujLHvoMzQbhLEYgSapasxupcgBVVcUgfJ");
    double CscVtPWHvHriEk = -542317.7637937939;
    int XjisxYsF = 1108023089;
    double TqjEv = -628717.9765105485;
    bool NuSidDv = true;
    string jAMhsIlLjIB = string("TcwjNtJezPqggNQYZtWAKgHlthljmdhOwWrhGLnEdExVGtzKPWCaQbCkiDqWXRCkbPETafgJBtGrJyxKkrBwAJWz");
    double cSQQEEpj = -883797.5390303143;
    string CVZolWzRyfjSB = string("PWZOdxPptsBFFbZvGBotGwFjQwcmoOsLuALtxbucjgrgkXFrTktFiOIxIFfqBgMclJozsaVMCvgWUqIAyUtBFMJGOoQveBmdM");

    return NuSidDv;
}

bool pOVSeSxybKNhrsvv::MdNarMk(bool zcuPGLO, double MSnrKcy)
{
    string dBtrZfZJhJZRgAvV = string("JsGw");
    int QgFBx = -219079441;
    double ebPGeMhfQuTUZY = -794100.654187615;
    int scLVo = -1065628549;
    int xnFZjjZOSYe = -2021999460;
    int TbsqPudnhkxD = -1318302629;

    for (int rkqcgn = 329232788; rkqcgn > 0; rkqcgn--) {
        xnFZjjZOSYe /= scLVo;
        scLVo += xnFZjjZOSYe;
    }

    if (ebPGeMhfQuTUZY > -794100.654187615) {
        for (int cRMNGqYn = 266416591; cRMNGqYn > 0; cRMNGqYn--) {
            QgFBx *= scLVo;
            TbsqPudnhkxD -= scLVo;
            QgFBx -= TbsqPudnhkxD;
        }
    }

    for (int JVsWvqdivLZC = 1217147031; JVsWvqdivLZC > 0; JVsWvqdivLZC--) {
        continue;
    }

    for (int klHuPzOWIWNIBFh = 152229507; klHuPzOWIWNIBFh > 0; klHuPzOWIWNIBFh--) {
        QgFBx *= xnFZjjZOSYe;
    }

    for (int mbZTXoKCjChRZsw = 720879713; mbZTXoKCjChRZsw > 0; mbZTXoKCjChRZsw--) {
        QgFBx /= QgFBx;
    }

    return zcuPGLO;
}

void pOVSeSxybKNhrsvv::KukicVg(string iiTyrVbSa, bool mvAnC, bool vivgxdtItuX)
{
    double NbJyNQiyMwvoUvuU = 592295.600959577;
    bool ugHuIjjzuxH = false;
    int iGbUcuNkgWfmaI = 1230678828;
    int HWjnRpl = 759479915;
    bool MKkZXPfRya = false;
    string DzQeBPZXaNNygF = string("ICqCBJyVrlXIdhHugdMnkkHjHFpXNqwAVHJorPrtRfFBwAtuCxvOGtvbyKwpWGdBfFdCnuqLSeqkGGjAwecKYWEmEXAVZSqJVVKIDYEDwIdLH");
    string xrxjQkqzsODRWlY = string("AfePYZeKCwGfeIFLpxzqGLCRrvxOpilNCaGUzAcFWSAfkKVWlttg");
    int QdCrTXqVF = 1152406084;

    for (int DahDZmUOVNn = 1370470023; DahDZmUOVNn > 0; DahDZmUOVNn--) {
        continue;
    }

    if (MKkZXPfRya != false) {
        for (int ukscdix = 1593279163; ukscdix > 0; ukscdix--) {
            continue;
        }
    }

    for (int rLlPMShWEToWT = 2102932397; rLlPMShWEToWT > 0; rLlPMShWEToWT--) {
        DzQeBPZXaNNygF += xrxjQkqzsODRWlY;
        QdCrTXqVF = HWjnRpl;
        MKkZXPfRya = vivgxdtItuX;
    }

    for (int cyIMbl = 1478187251; cyIMbl > 0; cyIMbl--) {
        ugHuIjjzuxH = MKkZXPfRya;
    }
}

void pOVSeSxybKNhrsvv::ohSrpYZtVxezkCK(bool nahhrD, bool WHlJT, double pUlCXgoHaP)
{
    bool AltKBTgfGCwBY = false;
    int gBoJwyyINahFo = -93303223;
    int YKlWCwpDHRkAtrqC = -1432838879;
    string WcXQvvSt = string("UXkwwpnZgugWpQioVpCAROTNQyQHGXdxqeIyJJLVqMCYyCGTEjNePWwnfHi");
    double oIKaMEA = -746495.9845929822;

    for (int KpwMnEDD = 815163255; KpwMnEDD > 0; KpwMnEDD--) {
        continue;
    }
}

bool pOVSeSxybKNhrsvv::pWvcfjQaCv()
{
    double wQfoOUJQ = 176879.3060496022;

    if (wQfoOUJQ != 176879.3060496022) {
        for (int dAKJFEEcwS = 2037566192; dAKJFEEcwS > 0; dAKJFEEcwS--) {
            wQfoOUJQ -= wQfoOUJQ;
        }
    }

    return true;
}

bool pOVSeSxybKNhrsvv::AtcjdhUAFbghAB(int FwHjZ, bool JtIIVqEny, string KyZbkpvT, int UeYZAiDasJgwR, bool uNkWV)
{
    string KyNmeiVI = string("iDWeUKqaRropUqLWFmifaixwX");
    int RGJyJUcGMDVLAzTg = -891963579;
    double tiywVY = -937873.1538041527;
    int iUoZxpSpiepLido = -1204695759;
    string ZxgsF = string("zdWqRWlSuqaMdlHoNbsfSwCpnkzyRNMAhsBFHwtfdaNMkOGjEAfzqycCzRTJtWVvCopqfICrZFkOsLPzEqEEioZkEjSSpODLkmkfAcEEQzmEhUTixLxHnRZQCwipRQNMNmDDuRzslOqiGnjlFfwwIopqOWKlmtwgEWkHykjmBbrWw");
    string ofbbxzI = string("kZCctMZJJYCJpfKhgCPcINufyvkBKbTcYLBf");
    bool qdzNfWSfnjeqI = false;
    bool bYokdbsHbn = true;

    for (int chyXXRCFMMvO = 2055103566; chyXXRCFMMvO > 0; chyXXRCFMMvO--) {
        continue;
    }

    if (ZxgsF < string("iDWeUKqaRropUqLWFmifaixwX")) {
        for (int AEkDFWBA = 144004472; AEkDFWBA > 0; AEkDFWBA--) {
            JtIIVqEny = ! bYokdbsHbn;
        }
    }

    return bYokdbsHbn;
}

bool pOVSeSxybKNhrsvv::zVtvHgyTINvoDXv()
{
    double ifxEOBLUhvgLAWT = -1042198.3933380115;
    string MxuPcgiYEE = string("NvOmuWEajlnRrLnADKqFxiamohYhqqbmrQqAIAIQPXCCsxDjpBSYighMDKnocFSfEtukAxnlGUVGdqyDdWyOIaezRdGcGEaCfYUEbrVQkwbfBxygNspGpFYHj");
    bool ktPOdKxzzg = false;
    bool sCQLwQPJ = false;
    int DmvvKaAQc = -358488273;
    string PIKSjKiH = string("qZMKvftbGnhVlWXFlfGJMEanAFGfxIOCZdqsiUpfVuRSUcXaaUdkJbkCAiIIrrvvYVeIXVLUEeceahMkStOLajDwLrsDjVDEMxhmPqBCuIIykPABRqeOinrkhKLnqkQnSLULbWBseYhHRxBtsQfttRMfSOWrthHRNsGurKdxqirUsTmPGfjGRQaKrUWARqdutcqHRmElbNtsLLkTHeOhrnueRWaFVViFzqrRknN");
    string ZPyqFb = string("BQhPbQEyvhFIVfSmeLsbshRjXJXVHbGTswWzXJsbETYYBYXOYSChiHeqQILmbpUhMXzZciebRAwlgjFAOaeYHYVFPfxgkwKbioW");
    string RpdOsxoTwJHh = string("nSiORpBZVDApHCoklRmUQgPoPOkQVnNHIJODTETGBGmygkQpJsLTimJOmKqdYonZKXdECKgUDgSGhVAzuZRGWuhZfZdtWTakiVsaWEkWCzfNjXCOpJrnlRncEShgNFoeroLdOCHpIeEeYBIHpSNOyQneixbkoIjQVBhMsZoWWSNtmStGAdYQQtrrbUnMz");
    string uvjgYeGaEGMEu = string("cGHwqEyDFbVgldLLmgSIwtEWPOYkKqkIPrdJXRyXPcHlefE");

    if (RpdOsxoTwJHh > string("NvOmuWEajlnRrLnADKqFxiamohYhqqbmrQqAIAIQPXCCsxDjpBSYighMDKnocFSfEtukAxnlGUVGdqyDdWyOIaezRdGcGEaCfYUEbrVQkwbfBxygNspGpFYHj")) {
        for (int ZUAXXNakorB = 337662413; ZUAXXNakorB > 0; ZUAXXNakorB--) {
            uvjgYeGaEGMEu = uvjgYeGaEGMEu;
        }
    }

    return sCQLwQPJ;
}

int pOVSeSxybKNhrsvv::rqcUhfouP(string gePqlqzgNJtx, bool aauCrxhhmfrj, bool SCfoPzafwPdLhcgW, int txaDURLGOkE)
{
    string wbhehpb = string("dqhVhiBSwextzOvVRxCrETgjQlfWPoSOhXhraUfJLqOjyDhqopllSvyREsFTKAfRxOThRmCCWzKCFODbGFttRASrYZIEVlHSjTeFpilrJRHXCyLuGuRfZPZfAVrOIYJlpwgfHMWJvLAUDQO");
    double WYVlV = -777695.0771135613;
    bool DbKcOva = true;
    double TsXhlUORd = -70179.41961041027;
    int tCkqvgAJkAZND = 257496284;
    int xIIcmVmXdJ = -1398492484;

    for (int VHcDQwTVxCN = 822928631; VHcDQwTVxCN > 0; VHcDQwTVxCN--) {
        txaDURLGOkE /= tCkqvgAJkAZND;
        xIIcmVmXdJ /= tCkqvgAJkAZND;
    }

    if (DbKcOva == false) {
        for (int DzgbpFl = 1613451937; DzgbpFl > 0; DzgbpFl--) {
            continue;
        }
    }

    if (DbKcOva == false) {
        for (int IcZelpZc = 882841278; IcZelpZc > 0; IcZelpZc--) {
            TsXhlUORd *= WYVlV;
            tCkqvgAJkAZND = txaDURLGOkE;
            DbKcOva = DbKcOva;
        }
    }

    return xIIcmVmXdJ;
}

int pOVSeSxybKNhrsvv::aPdbJMuMglPsEHVz(string BrApjXiLVBOc, double VdUxtUhFMSrJEo)
{
    string SnXpVkEAUbNOR = string("wKaDLEDaifSrdahGCqRQsuYZwwaUzpRepqcnNsBdYXuKhKJHoWhXkvCQehSWuBXCFpuRbWhASuqOztndjsLAERgPRTqRWRVQYZUTiDQMBLEIYERxglqMYNLUxSNCyydnUQKXSzHQhzdeYRnPykCZaxuamgIVGWnsmrjHJsvhAYdMALIGUwTJKAtvqGqomNinhsFHYRShpDvrwhozLlqBXMFCTuRX");

    return -2037794404;
}

pOVSeSxybKNhrsvv::pOVSeSxybKNhrsvv()
{
    this->pDNiWenpWZ(51441.63769631676);
    this->aplqyvgQhtpkdZMB(string("ooSuoOauVxgnyqwUmgPrfjzBmbylhBypeNDyRQubsoWjBbnkChdJiWmnNMOVXXKSCmvOdMCMdSDOwypbyfrnqKPseCJkcOgtqAkQLTfTnViqHgAfipIPwmZHewZbwMXuhwPK"));
    this->BuAfyGvjdN(458681418, true);
    this->ofsOD(498410.0736913968, true, false, -579594473, true);
    this->PjOWKipeVjqoyks(1939559912, string("FnGZfRMQJWYsEXPlUcsktGYvnPXFpGaMouTfSdoSyQRPWEehbIKOAsfFvEEnOvNBEiTZgfiwdHJiWHdojCgZaJhqwQkkEkfEwMiPMiFXGlpwfbgoPWxNKNUxZqNiQFNNywoqpMdlbzZmEmilTmnlaVuDxlfYokjuYVWpyVSBWZNJuMVusLUKyxLXXNLFBugCQjRwdulIAnmrXVtCHHvqnmcFpkObCEQwZyJcX"), true, -698963392, string("XjPazgFJMLULEJhIsOnqVDYQmGjOjOeEhbfPbCRQfCFyOJYgEvYNIrKncWVNgVBOehYLxcKOdGMTmLDxmwKYdqKkJBMLzieWaHqLUBzpzQodtyfuoEnwMdNJoaJzRBqLZhDOibDUkXqsDExWtNbMPEGsHkjxtdaSCVnjLICyv"));
    this->MdNarMk(false, 986369.7230568362);
    this->KukicVg(string("qjmIWaNDswegybcWRLjqFCMqXHmqMEkBPoMoMirBqPKFZIYlvyMiqcISvCCGKTTJcoxANruhmggGScYshKJggxpbCKcceJfKMRxBaNdfExqwAmPWTYBDlyDyANwnpVxGMojNiSRWmPhvCpMMqofsWhJFERnMcyFoxpAYqbWEtIpZNeJCnkAQckFCvYElnvO"), false, true);
    this->ohSrpYZtVxezkCK(false, false, -593577.7225218316);
    this->pWvcfjQaCv();
    this->AtcjdhUAFbghAB(235075287, true, string("hMJERqwPFVfmYcAznHuiEYTnXMWktunlaBKZhdOjIezPbalPUxAfyeBjohuonbnaWzgatcJzRPJlnuRejbWroEAgvFFgjnFNbhZMYqzAjiRclutNRMmfJkotxHSWzQoZlKdVJpAqHMqzVubFHlHrWDIeOXHGUnDfas"), -1502660573, true);
    this->zVtvHgyTINvoDXv();
    this->rqcUhfouP(string("tgFlzgrbdakmlHuBEBaatdeDHCcZFNxcjapKqdyPjEkYbJBXsFMGOsbnrWNLDezBErtSIcIVByimDfbvIMWqsOwIYhttDOKnuTXAxPSzqDJWTMxYdtwAIvQgiYmVXMOhZPgbwsVlvAvPKqCnqihdgtaNWiUzdlGMlLnwVNAPTPCKkQmDIIYDDWABxQVdxMeRTSPkSiBArmBkYHJwdxaVzvFnHxDiYVHbhSUvjbsLzFxCdeIyIHIbiYeGbMPq"), false, true, 203026171);
    this->aPdbJMuMglPsEHVz(string("zbEGZBNGrEtZJHIYaNxdFZyjrClbQyolcOwmoUBucEJfFMfMlwmeRcGDdmZkIGxByOiLcFjumzEqFAi"), 764234.1659316828);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NHTfNjd
{
public:
    bool EoMJtKayUuawaO;
    bool KLZOlaFhHv;
    double UrzBVHetrSNCraV;

    NHTfNjd();
protected:
    int XswpnB;
    string QRakakhwrKFgdTLo;
    int AvkQMQyiYuLYV;
    string TaPtJvLz;
    bool jzIGpJJ;
    string MxbtDpnSbDtjfniP;

    int qfzBwHiQezyMsYMX(double DMTqrMkjSuNPPgP, int LNJgDO, int aIcsnXaNtuNNZZpP);
    bool KXOkCuFmZfHgwhlu(bool FOBKxEqUEN, int WeeUorPkwe);
    int RhxNbdh(double gYHJgpcXtkNlUHPu, double FIoZXzUYuCs, bool NXFJqeSFuXo);
    double nchZXAjxUI(bool kOFuoAITsSuaKMFJ, string FGiyaboxbx, int KIWBTzbnxAFUkMGV);
    void suGgEbCPHquWg(string ZDcgufXpRkbqAY, int GYexbgQVpyt, double DBxSSj);
    string ehECrtpMPCeHD(bool JVkZkDPYi, double GKHvHnJV, bool CzCMgbZSeAIfpU, int aqRXga, int SPSuDVfViQIUPVD);
private:
    bool sArLphaue;
    double FTofEc;

};

int NHTfNjd::qfzBwHiQezyMsYMX(double DMTqrMkjSuNPPgP, int LNJgDO, int aIcsnXaNtuNNZZpP)
{
    double VmkpvXKVkBs = -170586.87915651192;

    for (int OScXuCIgHPLLryNP = 494984459; OScXuCIgHPLLryNP > 0; OScXuCIgHPLLryNP--) {
        VmkpvXKVkBs /= DMTqrMkjSuNPPgP;
        DMTqrMkjSuNPPgP += VmkpvXKVkBs;
    }

    if (VmkpvXKVkBs >= -170586.87915651192) {
        for (int tdJTVpps = 597784459; tdJTVpps > 0; tdJTVpps--) {
            VmkpvXKVkBs *= VmkpvXKVkBs;
            LNJgDO = aIcsnXaNtuNNZZpP;
        }
    }

    if (DMTqrMkjSuNPPgP != 920329.263036463) {
        for (int iTOMLdxXxlDBCo = 28222685; iTOMLdxXxlDBCo > 0; iTOMLdxXxlDBCo--) {
            VmkpvXKVkBs -= DMTqrMkjSuNPPgP;
            LNJgDO = LNJgDO;
            aIcsnXaNtuNNZZpP += aIcsnXaNtuNNZZpP;
            DMTqrMkjSuNPPgP *= VmkpvXKVkBs;
        }
    }

    if (LNJgDO >= -881080718) {
        for (int UUEnxKa = 1229445528; UUEnxKa > 0; UUEnxKa--) {
            DMTqrMkjSuNPPgP *= DMTqrMkjSuNPPgP;
            VmkpvXKVkBs += DMTqrMkjSuNPPgP;
            aIcsnXaNtuNNZZpP += aIcsnXaNtuNNZZpP;
            aIcsnXaNtuNNZZpP -= LNJgDO;
        }
    }

    if (aIcsnXaNtuNNZZpP <= -881080718) {
        for (int urJKDNNTJniYF = 1679475454; urJKDNNTJniYF > 0; urJKDNNTJniYF--) {
            DMTqrMkjSuNPPgP += VmkpvXKVkBs;
        }
    }

    for (int cIFyjWpNciuGP = 676253053; cIFyjWpNciuGP > 0; cIFyjWpNciuGP--) {
        LNJgDO /= aIcsnXaNtuNNZZpP;
        aIcsnXaNtuNNZZpP -= LNJgDO;
        DMTqrMkjSuNPPgP -= VmkpvXKVkBs;
        aIcsnXaNtuNNZZpP *= LNJgDO;
    }

    if (LNJgDO >= -881080718) {
        for (int ILaALoxQoWxyZFf = 1208995457; ILaALoxQoWxyZFf > 0; ILaALoxQoWxyZFf--) {
            DMTqrMkjSuNPPgP *= DMTqrMkjSuNPPgP;
        }
    }

    return aIcsnXaNtuNNZZpP;
}

bool NHTfNjd::KXOkCuFmZfHgwhlu(bool FOBKxEqUEN, int WeeUorPkwe)
{
    string LXiwzcLbZHtLg = string("qvEEePgPRMvyOqwISvaOCZHXaAUidtgOzYJxSkRNLbKSGbtEemRgLuGJtJfktFyQRFcDyWn");
    string wpTVPYxxf = string("iLeOmdBMYkgUYzMXdmioiIQuWOJFTszGZgNvFKDYYMbboJRddJgJXQElhzfodwxeYdEbncsoaUancKGZcPGpjmccdVwtUuqdNAIxxZiHYzrOfxBZaoGuUfuAsNSVYvNosWdGyIiffBfuvdmqxfSgyEsLNsjJsgvhepVdVlLgfNosxaIiavQlKtqyQTImFQvZOqIaeBohrCRGILD");
    string vONDUbHa = string("wSAZfXncJgmDWbdLMVEEhJiBQMLRDQTkRMnXgXlFAjKidzeHrDJwLYxCVunRIoigOyshHNpJwPFXwbBcTXeAstGrzmbcVZrojMLbzNramDUSzcmBdzbOcTNdchpPFkNgdbtMShIhJPJUJeZLsKYlaYdttTzBWpNDYAjSoxfKxIjzLrr");
    int tMVDxb = 1729866093;
    double mZryerIJtjLjMr = -103142.34974414333;
    bool FYcyVVRw = true;

    for (int Mcuyj = 1405897270; Mcuyj > 0; Mcuyj--) {
        vONDUbHa += vONDUbHa;
    }

    for (int BxXONqyeSnjmG = 846818728; BxXONqyeSnjmG > 0; BxXONqyeSnjmG--) {
        wpTVPYxxf = wpTVPYxxf;
        WeeUorPkwe *= tMVDxb;
    }

    for (int zSeuG = 158260395; zSeuG > 0; zSeuG--) {
        vONDUbHa += vONDUbHa;
        wpTVPYxxf += wpTVPYxxf;
        tMVDxb -= WeeUorPkwe;
    }

    return FYcyVVRw;
}

int NHTfNjd::RhxNbdh(double gYHJgpcXtkNlUHPu, double FIoZXzUYuCs, bool NXFJqeSFuXo)
{
    int uduROaWIkydXchdZ = 73484259;
    bool JoLYXazbWCqtjiYL = false;
    int VuxpwnS = -1813092377;
    bool NgKGgR = false;
    int rObzWSXvARbKhALm = -1372935679;
    int AYGoi = 362393649;
    double lisqGdZMbRKVb = 514734.4158263732;
    double JrWRdtXMWuzpvGk = -539651.1653544824;

    for (int JWWfgw = 406518612; JWWfgw > 0; JWWfgw--) {
        VuxpwnS -= rObzWSXvARbKhALm;
    }

    if (AYGoi < -1372935679) {
        for (int aJKuYL = 1788257290; aJKuYL > 0; aJKuYL--) {
            gYHJgpcXtkNlUHPu += FIoZXzUYuCs;
        }
    }

    for (int PKRRcKzFx = 337896680; PKRRcKzFx > 0; PKRRcKzFx--) {
        NgKGgR = NgKGgR;
        VuxpwnS = rObzWSXvARbKhALm;
    }

    for (int yZzEDXXvkcxG = 1323118924; yZzEDXXvkcxG > 0; yZzEDXXvkcxG--) {
        JoLYXazbWCqtjiYL = NXFJqeSFuXo;
    }

    for (int RjgQKC = 1937692379; RjgQKC > 0; RjgQKC--) {
        FIoZXzUYuCs = lisqGdZMbRKVb;
    }

    if (AYGoi < 362393649) {
        for (int NWrdxC = 371300262; NWrdxC > 0; NWrdxC--) {
            JrWRdtXMWuzpvGk /= lisqGdZMbRKVb;
        }
    }

    return AYGoi;
}

double NHTfNjd::nchZXAjxUI(bool kOFuoAITsSuaKMFJ, string FGiyaboxbx, int KIWBTzbnxAFUkMGV)
{
    double cjwITBAq = 599107.5894709093;
    string IeruxLcQR = string("iUXOxkFuvxKcytLlWSjRmaUMjDvMEsuUpcLcmgMHuCsofPjePIiTpJBfAaztGaRmRYCuiBrNokPALTyyrBDmpIdwZQBFEqKeLasTw");
    int GKLIOu = -1865667580;
    bool YrZrAWkMatJwNrsQ = true;
    int DrmWAyvezOonA = -1761678018;

    for (int UOGqUlInNZMva = 540694049; UOGqUlInNZMva > 0; UOGqUlInNZMva--) {
        KIWBTzbnxAFUkMGV += KIWBTzbnxAFUkMGV;
        kOFuoAITsSuaKMFJ = YrZrAWkMatJwNrsQ;
        DrmWAyvezOonA = DrmWAyvezOonA;
    }

    return cjwITBAq;
}

void NHTfNjd::suGgEbCPHquWg(string ZDcgufXpRkbqAY, int GYexbgQVpyt, double DBxSSj)
{
    string QAyXch = string("gaHjcAhXxtZUewVKMyfwPRIQObVOTyqGBmUBVVwfGgXagPPApvAFySUFHhHUcNqxsOARLntuTCBzzGAftZWbEWLdVJddrkjnQWqPVwgIhMpVkWpXfwokIhstrQEAflnubeSIpVSDTt");
    bool SrBcCiIWl = false;
    double zzVIGGlgYgnsKqhz = -509407.3474807563;
    double pTaqcHXIVwvqpTV = -500984.7081003078;

    for (int xKbxIIq = 808295129; xKbxIIq > 0; xKbxIIq--) {
        QAyXch = QAyXch;
        pTaqcHXIVwvqpTV = pTaqcHXIVwvqpTV;
        QAyXch = ZDcgufXpRkbqAY;
    }

    for (int cRNoluetHmM = 1088131287; cRNoluetHmM > 0; cRNoluetHmM--) {
        ZDcgufXpRkbqAY = QAyXch;
        pTaqcHXIVwvqpTV = pTaqcHXIVwvqpTV;
    }
}

string NHTfNjd::ehECrtpMPCeHD(bool JVkZkDPYi, double GKHvHnJV, bool CzCMgbZSeAIfpU, int aqRXga, int SPSuDVfViQIUPVD)
{
    bool LsDVptoWbacvoHnf = false;
    int GeTKdU = -1731294492;
    bool hSMhVkxE = false;

    if (hSMhVkxE == false) {
        for (int dBqdWx = 1851446365; dBqdWx > 0; dBqdWx--) {
            LsDVptoWbacvoHnf = CzCMgbZSeAIfpU;
            JVkZkDPYi = hSMhVkxE;
            hSMhVkxE = LsDVptoWbacvoHnf;
        }
    }

    for (int fPBCQRvq = 936368212; fPBCQRvq > 0; fPBCQRvq--) {
        LsDVptoWbacvoHnf = ! LsDVptoWbacvoHnf;
        aqRXga -= aqRXga;
    }

    for (int iSljfcunIDWdBDp = 1300583300; iSljfcunIDWdBDp > 0; iSljfcunIDWdBDp--) {
        CzCMgbZSeAIfpU = ! CzCMgbZSeAIfpU;
        LsDVptoWbacvoHnf = JVkZkDPYi;
        CzCMgbZSeAIfpU = hSMhVkxE;
    }

    for (int svukNjNpCYxZC = 277380062; svukNjNpCYxZC > 0; svukNjNpCYxZC--) {
        GeTKdU /= SPSuDVfViQIUPVD;
        GKHvHnJV += GKHvHnJV;
        SPSuDVfViQIUPVD += GeTKdU;
        CzCMgbZSeAIfpU = ! LsDVptoWbacvoHnf;
    }

    return string("xXumRutDfuWYZENTXlMhCJKKLwcjwhAFwyoAyziNmzuwllfkgEFLwVkMxHemKfScUQRbiRVXGSsRIPQJZRKTjasaOIYwrqHufHgGDThsJCmTArqeMAtJinkCEdbuwDYkOQPXaxEhsTGkPPWQcjkLTpITLdaAXoUPYdGXZELOkKeYPdqqLC");
}

NHTfNjd::NHTfNjd()
{
    this->qfzBwHiQezyMsYMX(920329.263036463, 170935205, -881080718);
    this->KXOkCuFmZfHgwhlu(false, -441416185);
    this->RhxNbdh(-899917.9443811582, -513013.1857981948, true);
    this->nchZXAjxUI(false, string("XDIZgPbKvmMwUxEWZtRRuJIyzaPQLwVwwinADEWnGGKFvxMzqZrUaivQWBZuWopHDpNFdWHSPryXoWlXcuPACVaYrIxDaP"), 1358866095);
    this->suGgEbCPHquWg(string("CkUTvXChUIPsQMJxWgPgvtZWaFbIYNTVglQIkFpSxaLBrReQrqv"), -1237698576, -984157.2134175141);
    this->ehECrtpMPCeHD(false, -1017017.4559246077, false, -1806506544, 472120672);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eBnArFKZmuWXf
{
public:
    bool oSyhCu;
    int JswpTjcbGV;
    int YSDIiJOQO;

    eBnArFKZmuWXf();
    double wNSVr(string ihXkqI, bool hEIgx, double yHQFihccTCRJL, int LhdiyRtiC);
    int aExqemDdkAoa(bool KvUTJTY, int JXnTkAEheeTiRAJL, int vWjgVZIDpYESG, bool ZRyuLvfKMCuPa);
protected:
    string cwwEEe;
    string xXrZCXP;
    double jIEfCQWgjdfsj;
    string FCZUrQ;
    double LSdJVdg;
    bool hrRkRyZtYstzXjZ;

    int UPWTSVKqw(string UgxlqdFsquXZc, int LPkSgrDEOWAvkyhY, bool SudDLDGzkKUb);
    int IvgdkXCUoy(double GXAORhjyDsn);
    double iCUKJtIucCJlRn(double jLoPVJTIZVtItUw, bool vRIKzickXI, int MaeUZVflgmZLQt, bool wkgnHNgzz, double JyiSPfErpBRkObh);
    string dkZUTXCDFmjCiXYB(double ZauzaLw, bool picTnkG);
    int VApmCmItPt(int tMxBB);
    double yURZH(int LGclUTcctgd, double rUgac);
    double KHTGfLgqpSY(int PCenlrCfqxUqgjp, bool LzEGpgedis, bool LrTkfpFMY, int aqQQQG, double JhKeQFsisXdVuuoA);
    bool ijrFsCck(double eYkxaALxX, bool KeQyBRpFqGug, bool ROxKbXW, string phEKFKINgN);
private:
    int OuPtrqgkk;
    string QloXXjjjB;

    int KVCmgclmJXf();
};

double eBnArFKZmuWXf::wNSVr(string ihXkqI, bool hEIgx, double yHQFihccTCRJL, int LhdiyRtiC)
{
    int WOEHdZAcQUyd = 238276654;
    bool vBFyFyH = false;
    bool taLvnzvsyt = true;
    double dyZbebBocpItpW = 373609.6744889655;
    string tzHAv = string("bIzTmjzbvoLvJwyxTguULifMLXqQseRYrHxdXKtAoXcIPzEeXcLCTbcKJVtMHniZvTRenYLYLhNRNCiOQyNsMhnOvcdUSpnJftogpITPRNEDiDSchsMTkQmQxNIYKmNI");
    bool wWbagk = false;
    int ggXVqtJjhjWxaDOw = -485416539;
    int LZcHDm = 293997039;
    bool LqEwjcWqSUVc = false;
    string ZxAqhXAKSzYYGON = string("ZgnSraBvGAYCFhcvCAoEikPEinTNgFjGWpDFUugNHsFTyQMmUfljelMIDsFdOQDOKJjKrepnIRYJwMoOWLCJFrivIeoThIfEmFhsFPNEboDlWNmtMoOjzNcloBgGPEWKDQmzmLnsoqCzONYEygmCwdDPUZVGpDlxChKl");

    return dyZbebBocpItpW;
}

int eBnArFKZmuWXf::aExqemDdkAoa(bool KvUTJTY, int JXnTkAEheeTiRAJL, int vWjgVZIDpYESG, bool ZRyuLvfKMCuPa)
{
    bool qBpjiUhnIl = false;
    int jcubZmsxk = 251790779;
    double fvqWDBioEIFXEvo = -765049.4507762409;
    string JPhCVRhjkblYEyWB = string("xElPSVJEUFMZtWElvrJxXfytXxWgEbGCtvHvcaSvVsdecNXEuQOlAuDBalnDjpeNLQuCNegqclXbWetAasgwCmwTiAmOxgmxPTbUvuUUyNDmhXHsdZOgWmfyymbzAeyIVHRFVrrAmAIOZZwNZFhbjQTvlKUeoK");
    int GlzHIOjpNskQivr = -1554786464;
    double YbZpeDUZglsN = -200143.17111699123;
    bool CxWwRAw = true;
    string GXHsDD = string("G");

    for (int pHwNxXQzqn = 298368993; pHwNxXQzqn > 0; pHwNxXQzqn--) {
        continue;
    }

    for (int JiDVCBK = 984969638; JiDVCBK > 0; JiDVCBK--) {
        continue;
    }

    return GlzHIOjpNskQivr;
}

int eBnArFKZmuWXf::UPWTSVKqw(string UgxlqdFsquXZc, int LPkSgrDEOWAvkyhY, bool SudDLDGzkKUb)
{
    string mptJkxihxYOT = string("HwPcNvrSrbNHjGolnliqBeqiOplUFjgZwmOdgIpvhpkXngArwAWBFJpLmZEXjhFzRAectTKKLnqtaMltgXOxxawhfVixjFhIJWwdDJWtFhOxotFXAMhKPuTjmBaBxLROOoHwnAaRyCzcoYYMtinNzOAmUOBJxEsRvdPhsofCAGIotCWhQrPjgyITWSzmEbgzubIeHZszW");
    int ruHcZZlZ = -1106514888;

    if (SudDLDGzkKUb != false) {
        for (int QrtcqJMmzZ = 689435363; QrtcqJMmzZ > 0; QrtcqJMmzZ--) {
            continue;
        }
    }

    for (int cdXJDeuweZR = 1328749215; cdXJDeuweZR > 0; cdXJDeuweZR--) {
        mptJkxihxYOT = UgxlqdFsquXZc;
        UgxlqdFsquXZc = UgxlqdFsquXZc;
    }

    return ruHcZZlZ;
}

int eBnArFKZmuWXf::IvgdkXCUoy(double GXAORhjyDsn)
{
    string APaTjorfJdNTG = string("dzkIJkzUbuhEiaLNsIsHdPJZhporWOVyEeWBGsAzwDDDAwLXXXAkHlluZRlfNpTNzSrHiRb");
    string sGfIMP = string("lJNZrDabXHtFtHqfkShYXTgAwykxFDvfuMqBbkJPQSLJmMIKIusfvxnrgodnuZbfULcekHjCbSzkEozQVXoAedew");
    string wkuhYArRXuqTJaa = string("WMsducQRIufZayGbUnBlbKVvxnXCIGnCZztbcdjvJrzAewCUkoJTtkiOsCzNQJTtDafaOeHjLUvaSfeagwhdqHKovnUaXBwcHXRNytLpvbUSZMmcwOdgKnhHircQrpPEErwyyrDjpYBWXARXozHccmeLYGiiKeSjfIoiAQqpDnQRoMzPFJMg");
    string CgnXe = string("AESAkuwkUO");
    int RHvPYsGplLX = -623408584;
    int srnHsjB = -1979940363;
    double siuEmw = 2522.8155262530113;

    for (int zmKsohQQhVIuOnxN = 2003729480; zmKsohQQhVIuOnxN > 0; zmKsohQQhVIuOnxN--) {
        APaTjorfJdNTG = APaTjorfJdNTG;
        sGfIMP += sGfIMP;
    }

    if (CgnXe == string("lJNZrDabXHtFtHqfkShYXTgAwykxFDvfuMqBbkJPQSLJmMIKIusfvxnrgodnuZbfULcekHjCbSzkEozQVXoAedew")) {
        for (int KFximcpyhBMNUvfk = 1998833100; KFximcpyhBMNUvfk > 0; KFximcpyhBMNUvfk--) {
            CgnXe += wkuhYArRXuqTJaa;
            CgnXe = CgnXe;
        }
    }

    for (int VBhLcWHQFAnIW = 1948400868; VBhLcWHQFAnIW > 0; VBhLcWHQFAnIW--) {
        sGfIMP += APaTjorfJdNTG;
        srnHsjB *= RHvPYsGplLX;
        siuEmw /= siuEmw;
        siuEmw -= GXAORhjyDsn;
        CgnXe = APaTjorfJdNTG;
    }

    for (int rGFfGkxILfsjW = 235308315; rGFfGkxILfsjW > 0; rGFfGkxILfsjW--) {
        continue;
    }

    return srnHsjB;
}

double eBnArFKZmuWXf::iCUKJtIucCJlRn(double jLoPVJTIZVtItUw, bool vRIKzickXI, int MaeUZVflgmZLQt, bool wkgnHNgzz, double JyiSPfErpBRkObh)
{
    int MTRPdNprQTI = -1639879532;
    bool gqfEiEcTffsCVB = true;
    string jtiHxwYpBEBveB = string("PvhygZ");
    int lPpfNOUUENYA = -1430624538;
    double sMBjPfof = 778409.930511028;
    bool gHLSsktFzpIR = false;
    string eDxRWoHpmOqCa = string("OAPEWZyHjRVyjKdq");
    string PWvhUkmmdTXjf = string("kOuqxLqXYBdubCkJiOPqhbFqnGpCZQXxPScNlfPEsvYtCDfloYgTVQkyakeYyrIZHWLnAjeuyIMZitAJnGLcgJiyqdYEiECCyovloOpCrfJIWdefBUhEcPAQQpNKsActIsedojcxSpTaFpKFZSMOiHuuZOsEsHwJzVQDfOVIjJEYvAwKxeFMMTKwedXefYazFJRuFJLIoUrqPfEaVeFlOJspYocmXShszWZyaNEmoDwOobLfexjGXJFrJopHm");
    bool CLTeCPpfaRDNlOOC = true;
    double KAmUrOpspj = 664896.2160597506;

    for (int exCMuehrwNq = 667252183; exCMuehrwNq > 0; exCMuehrwNq--) {
        CLTeCPpfaRDNlOOC = vRIKzickXI;
        JyiSPfErpBRkObh = jLoPVJTIZVtItUw;
    }

    if (JyiSPfErpBRkObh != -62326.621204666524) {
        for (int VPdIr = 955312253; VPdIr > 0; VPdIr--) {
            lPpfNOUUENYA = lPpfNOUUENYA;
        }
    }

    if (wkgnHNgzz != false) {
        for (int niiXPUmlQ = 1794341516; niiXPUmlQ > 0; niiXPUmlQ--) {
            continue;
        }
    }

    if (wkgnHNgzz != false) {
        for (int EKvAGfaLBE = 1981473111; EKvAGfaLBE > 0; EKvAGfaLBE--) {
            continue;
        }
    }

    for (int HgoDDGyRPWL = 1406766519; HgoDDGyRPWL > 0; HgoDDGyRPWL--) {
        jLoPVJTIZVtItUw *= JyiSPfErpBRkObh;
        MaeUZVflgmZLQt = MTRPdNprQTI;
    }

    for (int zNwdjpTyisAJo = 856562203; zNwdjpTyisAJo > 0; zNwdjpTyisAJo--) {
        continue;
    }

    for (int cHpEWsEPvBZ = 1876814133; cHpEWsEPvBZ > 0; cHpEWsEPvBZ--) {
        CLTeCPpfaRDNlOOC = ! wkgnHNgzz;
        CLTeCPpfaRDNlOOC = ! vRIKzickXI;
        MaeUZVflgmZLQt /= lPpfNOUUENYA;
        jLoPVJTIZVtItUw -= jLoPVJTIZVtItUw;
        MTRPdNprQTI *= MaeUZVflgmZLQt;
    }

    return KAmUrOpspj;
}

string eBnArFKZmuWXf::dkZUTXCDFmjCiXYB(double ZauzaLw, bool picTnkG)
{
    string foRbeHZDA = string("blKjFaEZIZxKTOphVymHZSZtVahhiEMoiRGceiFZAMVbtSLmdbaHSTnUedrIitIbeSQhwkBuyRXqJEMNnFgNnOaJkMoWggruAMygCkxTDawbmcYafMhFAidrtHtbuKgtDPjICzPIevsBzwmwKRtEsYGxReoPhubcmiNJKNdgzLVhkKmExEClEUYyqZfkirikichQbskBjSaeKkxkAXUEpTFQRrzkfeyNHpZSDYkoXc");
    string xSOIPdGKVACDjQ = string("IBDdRhkYVpWgvZzdTrgkBEFuQUBKKmYZcGpHbrTkIFRyoKGAVSGfclQnyBLLOJmIViRuiHLsNpxeddXpYLJQvoUHcXkPeDQaeCjWEuGXAzlsJJKekoGzUwfjLByYRQEzRGUhtXPigbFmnIuBRrNVsYTACZacBsxwQAUWLetGYlWdCLWTKCbVthQNTZOqCbFTkydJMJFxqYYLvZEtIOVLkvoFMTaUfbTsfUHxNhITbnkQsnkHaSOukalh");
    double gVRgDHbotDBjtGt = 499741.75398500246;
    bool FJUHrSbwIKDNML = true;
    int foAscbiz = -1414438545;
    double NRsFpiJfsAh = -409002.2565289871;
    bool zJqsWxlNvGmMb = true;

    for (int LVDrcEhFzzPWVlW = 1265248387; LVDrcEhFzzPWVlW > 0; LVDrcEhFzzPWVlW--) {
        continue;
    }

    for (int lhMeLMKNXqWMm = 1566827127; lhMeLMKNXqWMm > 0; lhMeLMKNXqWMm--) {
        continue;
    }

    for (int kKYixokLiI = 1242982498; kKYixokLiI > 0; kKYixokLiI--) {
        picTnkG = ! picTnkG;
        foRbeHZDA += xSOIPdGKVACDjQ;
        foRbeHZDA = foRbeHZDA;
    }

    for (int nQkVmAALqqgLM = 468117842; nQkVmAALqqgLM > 0; nQkVmAALqqgLM--) {
        foAscbiz += foAscbiz;
        picTnkG = ! FJUHrSbwIKDNML;
        FJUHrSbwIKDNML = ! picTnkG;
    }

    if (gVRgDHbotDBjtGt > -115503.68891638583) {
        for (int zHSDnUcRFFJLf = 1781714098; zHSDnUcRFFJLf > 0; zHSDnUcRFFJLf--) {
            continue;
        }
    }

    for (int pthfxw = 353090251; pthfxw > 0; pthfxw--) {
        picTnkG = zJqsWxlNvGmMb;
    }

    for (int lfetEprMswtt = 2013679236; lfetEprMswtt > 0; lfetEprMswtt--) {
        foAscbiz += foAscbiz;
    }

    return xSOIPdGKVACDjQ;
}

int eBnArFKZmuWXf::VApmCmItPt(int tMxBB)
{
    string UoiBPUY = string("JReULuucomKZxxgIgWUdeqhVzfnFeVfJqECHkmkKzqJREnkevyfnzJzuRZRIwksDFANpYkhOuJLrRADxgdottvhUQHgpIRiRLXXmxGmFGCUFtsRRnlUDzbhDstiKpPH");
    double TRTXip = 950811.9690868608;
    bool yYkdTEMG = false;
    int xIUCWcbiZfrzPH = -1205493;
    double zwZJsOfZPKNk = -464633.71580387786;
    string wVXeCIiB = string("hatFLTWycpGiImveIwVkPPdIuxPUIFEYNDMUEQMmWqaZNIBfiOFwBFttpLRvIVjRHnspfdEALksTVbSdNbTUDvXkgxDjqDhKzagqIxlzCAAzKqfXOOanOCEsRJTPBeprIsNgEyIfnTsVRgjhIvAIWDxTuiAq");
    double ZwGUPGdG = 571862.680592622;
    double iJPIdGdvQoQoZuAY = -119363.05814071266;
    double unLULpdC = 383368.2267702715;

    for (int rZNeMbRERgEp = 1793734689; rZNeMbRERgEp > 0; rZNeMbRERgEp--) {
        xIUCWcbiZfrzPH /= xIUCWcbiZfrzPH;
        iJPIdGdvQoQoZuAY += unLULpdC;
    }

    if (ZwGUPGdG < -119363.05814071266) {
        for (int rmjGfBnaAVE = 1396734220; rmjGfBnaAVE > 0; rmjGfBnaAVE--) {
            continue;
        }
    }

    for (int meyXdKry = 1066854394; meyXdKry > 0; meyXdKry--) {
        continue;
    }

    return xIUCWcbiZfrzPH;
}

double eBnArFKZmuWXf::yURZH(int LGclUTcctgd, double rUgac)
{
    double JUMInYJZyJTQ = -235472.81191903003;

    if (rUgac <= -235472.81191903003) {
        for (int AYwdr = 1674187441; AYwdr > 0; AYwdr--) {
            JUMInYJZyJTQ *= JUMInYJZyJTQ;
        }
    }

    for (int CbQdNcjoZw = 1518421358; CbQdNcjoZw > 0; CbQdNcjoZw--) {
        continue;
    }

    for (int CPNMOpPoHu = 63505604; CPNMOpPoHu > 0; CPNMOpPoHu--) {
        rUgac *= rUgac;
        rUgac += JUMInYJZyJTQ;
        rUgac *= JUMInYJZyJTQ;
        LGclUTcctgd /= LGclUTcctgd;
        rUgac = JUMInYJZyJTQ;
        rUgac /= rUgac;
    }

    if (JUMInYJZyJTQ <= -235472.81191903003) {
        for (int kJofdQyl = 2030089415; kJofdQyl > 0; kJofdQyl--) {
            JUMInYJZyJTQ = JUMInYJZyJTQ;
            JUMInYJZyJTQ += rUgac;
            rUgac += rUgac;
        }
    }

    return JUMInYJZyJTQ;
}

double eBnArFKZmuWXf::KHTGfLgqpSY(int PCenlrCfqxUqgjp, bool LzEGpgedis, bool LrTkfpFMY, int aqQQQG, double JhKeQFsisXdVuuoA)
{
    bool SiGjpeS = false;
    bool sYSHlhFeCkhfa = true;

    if (LrTkfpFMY == false) {
        for (int QaGbthVoJDafM = 1056403795; QaGbthVoJDafM > 0; QaGbthVoJDafM--) {
            PCenlrCfqxUqgjp += PCenlrCfqxUqgjp;
        }
    }

    if (LzEGpgedis == false) {
        for (int zZczV = 1325110899; zZczV > 0; zZczV--) {
            LzEGpgedis = LzEGpgedis;
            aqQQQG *= aqQQQG;
            sYSHlhFeCkhfa = ! SiGjpeS;
        }
    }

    for (int jPArQo = 1190001423; jPArQo > 0; jPArQo--) {
        aqQQQG /= PCenlrCfqxUqgjp;
        sYSHlhFeCkhfa = ! SiGjpeS;
        LzEGpgedis = ! sYSHlhFeCkhfa;
    }

    for (int VpAbjr = 1487448338; VpAbjr > 0; VpAbjr--) {
        LzEGpgedis = LrTkfpFMY;
        PCenlrCfqxUqgjp -= aqQQQG;
        SiGjpeS = ! LzEGpgedis;
        LrTkfpFMY = LzEGpgedis;
    }

    return JhKeQFsisXdVuuoA;
}

bool eBnArFKZmuWXf::ijrFsCck(double eYkxaALxX, bool KeQyBRpFqGug, bool ROxKbXW, string phEKFKINgN)
{
    string NMygyF = string("XMJXaGjiv");
    int IJwAKRz = 892897701;
    bool cLmOpnaKzCtKBL = true;
    double FzqFSleyOJNZYhzA = 425750.5105266244;
    int NFrOctjSuCuk = -1212919230;
    string gLklcdihBBCJX = string("IHjUAUksbMeoMNuOhHNaPmkDzHClqLncFzkrG");

    for (int lbhvSZTJajue = 658621174; lbhvSZTJajue > 0; lbhvSZTJajue--) {
        continue;
    }

    for (int ZXeTRHLyKBSzluFm = 1337700632; ZXeTRHLyKBSzluFm > 0; ZXeTRHLyKBSzluFm--) {
        continue;
    }

    if (NMygyF < string("XMJXaGjiv")) {
        for (int UDQKt = 796823732; UDQKt > 0; UDQKt--) {
            NMygyF = NMygyF;
            gLklcdihBBCJX += NMygyF;
        }
    }

    return cLmOpnaKzCtKBL;
}

int eBnArFKZmuWXf::KVCmgclmJXf()
{
    bool mdTtfx = false;
    string BJroyaqrjRdAPKL = string("BomoUkGtoauKXoHEufOlJMSxaAmVgxJwoUlwKuwTahDvFaXJDduiLcwZyYjseJVpmHRqvUAlIBAlhCeRheuVYrKDeuHQOmBcXrdTfCXSRPVCyEkBlPTiuhBexnTbrryepXjSgNQHBiKgzKKtSLRYDtqNVfrLgqQfsizRvPkhPBVFEYtRCjuzYZXEiBeEpLoEAlBnQkpmiQlorZshuBPPgzJpSkosDAWDUsVGZtBwTqFMGmxh");
    bool SGlKAJShvQLDHvJ = true;
    int ctprr = 162699806;
    bool vwVnqoNLoweCYLK = false;
    bool XnqpDVyhjaBNDo = false;

    for (int bVwfNqoXWEWrqo = 1780113555; bVwfNqoXWEWrqo > 0; bVwfNqoXWEWrqo--) {
        mdTtfx = mdTtfx;
        vwVnqoNLoweCYLK = ! mdTtfx;
    }

    return ctprr;
}

eBnArFKZmuWXf::eBnArFKZmuWXf()
{
    this->wNSVr(string("cpkFKXVjtIXOyBWWNbdXcgpNPmDoEKgtIpokwRQKpnfxMBDnWMIiAtFeFiBZadbMKSsllBfJXKUHegdwlGTdlsirKEygqQPFUllrMRinmCtWYtweHqiWLKPlFYxyyTnzCwuYbdjLtGGdxYqHhnqBGaPViWxEWgbkqUYBbTAKWGHYIScPgPXChwyvHDZCvhuHyotfhdNZwzNFIzEGUxvNPbSdhbZwEFnAEcbbEtkgl"), true, -950213.8900518899, -750195374);
    this->aExqemDdkAoa(true, -473722340, -746665794, true);
    this->UPWTSVKqw(string("IDKMfGaopmKqKIRzCFkAOxuSsfkMNRNxSrGBcmQQabwMshJpMCaoMJmPmrqJDUSjHERGmyEDbqEDsVpsdAiYmVBmxiyZqvsLnssmiiaGOyWdQHmRukAqefKjQu"), -1190075154, false);
    this->IvgdkXCUoy(-845474.0191437446);
    this->iCUKJtIucCJlRn(-62326.621204666524, false, 1081175374, true, -445817.7721747918);
    this->dkZUTXCDFmjCiXYB(-115503.68891638583, true);
    this->VApmCmItPt(1727658450);
    this->yURZH(-1989004993, -89550.06859622413);
    this->KHTGfLgqpSY(-2047675803, false, false, -129147768, -277838.7377089347);
    this->ijrFsCck(398009.2654259075, true, true, string("ITMPsEXYNqACslkSTwgcBndDmVqpFIbvtRBceyyClqMnqNwfueGQxAdFybZfFMXDhERkpyhKqkOFpoHLjBXEsXuorCLhWrSraiJruzHlXvlkIzoxrrluus"));
    this->KVCmgclmJXf();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class avJhMjXjjPN
{
public:
    bool DTeNgZDoKqNI;
    double MasfQCCU;

    avJhMjXjjPN();
    string GTpKxAfdXZpyBt(double hnRHeosvHbRcOL, string rQfIASODJpLTgnTc, bool ldxpFSGFl, string uWtbgYqCuCIo);
    int vThTJsWK(bool BWaiKqb, string dMJBJRMgS, bool GJulHnUgCRqEwzr, bool wUZTAZJ);
    void CIAjimxnfOguk();
    string tzwAxrjKpQDTGTAh();
    double lhQLWGnXDyor(int ZSLjmOaimTckWCmR, bool HMFtxLi, double JvhuKUzuAji);
    string knaVHdDpNipXUW(int TSEWzwjGIyacZA);
    string SQWHLoPoT();
protected:
    int eZEhUPYzRLdioo;
    string XqHSRr;
    bool WboUPk;
    double ABAHsByRITp;
    double NdJLwkgr;
    double tLKvkU;

    int jiBbVHKxVIopoEcA(string MFonEyzQOEvc, string ErACmdMKQFirBpPe, double LaXPvmDxPCr, bool nbUnRzxfRiup, bool YSfDMTa);
    double yAZKVdCJd(bool BAyQgN, int OWfZZchFqBX, string BaqiuYYaEK, double vgPVjGImcD, double RjhjiGLAklvHY);
    string iICcTeCrzliqRPK();
    double PyGIZWmWBzwrto(int lWCvLsLT, double thsxYPi, double ufuATf);
    bool XodBUTlx(double ykcmfjfGmWRKGjv, bool FVIhEtKpXlk);
private:
    bool kPRHPR;
    bool JrSiSQFYiMz;
    string qxkMXwc;
    int kvfeq;
    bool SNzoJQlRMWvq;

    string qPcZNOYyMLivIZme(string GgVigiuTnV, bool uHPxwynhymgNA, bool VlKRLeVOSTFfROA, bool GMIRZXTarSVw, int yFmYlDNkMr);
    bool uuYJyYi(string iEvvxbWHjKaMtCq, double LhHxlAKpTh, bool oPWIUFNOMYHbqqLZ);
    void FGnqSRV(string WcYER, string GSnwBWfeiKQxXl, bool kNDuTEpkEj, int VQezLQEvnvN);
    string JOnaAaAhrcs(double ljCPCdFCdVOz, int YMprQutSXrCtXtB, double rVERGdY);
    string JabOXkhdYAIxnK(double AFvxMPJqMotwiI, double sOXhBklKDyaaZUBO, bool QnqrlaVAkFv);
    int xrzxdhQ(int dyFIjQXBZomY, int zPJOmPBG, string kAeLtikiqVO);
    int nOcHg();
};

string avJhMjXjjPN::GTpKxAfdXZpyBt(double hnRHeosvHbRcOL, string rQfIASODJpLTgnTc, bool ldxpFSGFl, string uWtbgYqCuCIo)
{
    int zEVAtBjQxvtP = -799761962;
    bool cMxVik = true;
    double VnqqplPBqYvdFAc = 457764.40968879324;
    double hQjdWQCQfsOg = -429927.5137568334;
    int QYaTQDnjRlnFb = -67059802;
    int JUyJjsgWyg = -2047413024;
    bool rALLC = true;

    for (int cMWUCKu = 1891558807; cMWUCKu > 0; cMWUCKu--) {
        VnqqplPBqYvdFAc /= hQjdWQCQfsOg;
        zEVAtBjQxvtP -= zEVAtBjQxvtP;
    }

    if (VnqqplPBqYvdFAc <= -429927.5137568334) {
        for (int jSsAgLKyU = 914264237; jSsAgLKyU > 0; jSsAgLKyU--) {
            cMxVik = rALLC;
            hQjdWQCQfsOg += VnqqplPBqYvdFAc;
        }
    }

    for (int pEjDlFrlo = 1516625613; pEjDlFrlo > 0; pEjDlFrlo--) {
        ldxpFSGFl = ! cMxVik;
        ldxpFSGFl = rALLC;
        ldxpFSGFl = cMxVik;
    }

    if (uWtbgYqCuCIo > string("WxHZIUsARvyzqYqZRgZNuJXPByHTAhmBpRcQiODkDpVduGIrdLGBmzwbJsIDOESpaYKixzDrWvvJbRvVTJfLVOrsRXQQpRaNuPDPJDQRfFBvTONXWU")) {
        for (int ZZdkCqUL = 2028397376; ZZdkCqUL > 0; ZZdkCqUL--) {
            zEVAtBjQxvtP += zEVAtBjQxvtP;
            zEVAtBjQxvtP /= JUyJjsgWyg;
            rALLC = ! rALLC;
        }
    }

    for (int BlfAiIaZ = 2085646292; BlfAiIaZ > 0; BlfAiIaZ--) {
        continue;
    }

    if (hQjdWQCQfsOg == -429927.5137568334) {
        for (int pwHxsxmFIWFggu = 603323290; pwHxsxmFIWFggu > 0; pwHxsxmFIWFggu--) {
            continue;
        }
    }

    return uWtbgYqCuCIo;
}

int avJhMjXjjPN::vThTJsWK(bool BWaiKqb, string dMJBJRMgS, bool GJulHnUgCRqEwzr, bool wUZTAZJ)
{
    bool rvVbCctjJNbuccCi = false;
    string VWkteOxWwVO = string("vZbjyVweyHXmQALmsHWwjbLKwTvULYugQxxoxLqJvhqYkGGszVHlihvltfpKkIFbrJUIwXLkxgxYReWwvxKYirCvuLPSIXnRMZChNbDbktBAGDZohzfOUhRaNvaDovQAVxHLFzUYDmNRzrcCBMpdnB");
    int kIGZSjJJd = 1379350878;
    int GocPjFdcaTpRg = -495954427;

    for (int HPRgFc = 729717964; HPRgFc > 0; HPRgFc--) {
        VWkteOxWwVO = VWkteOxWwVO;
        BWaiKqb = BWaiKqb;
        GocPjFdcaTpRg = GocPjFdcaTpRg;
    }

    for (int QOhxxEDgjQcka = 844121200; QOhxxEDgjQcka > 0; QOhxxEDgjQcka--) {
        kIGZSjJJd = GocPjFdcaTpRg;
        BWaiKqb = ! GJulHnUgCRqEwzr;
    }

    return GocPjFdcaTpRg;
}

void avJhMjXjjPN::CIAjimxnfOguk()
{
    double WdUeMUNFWkKKvQCg = -831400.9670783698;
    int OEcaN = -1032204937;
    string eklRHwImUg = string("okjfYXErlZYXXVlqwpXuBDqOctnhGxsAdBPtzeIkSUVsoCoqOfkqmSZsNOyXrbEZWkpPCDRMkcqRUcThAsfGrROnaCWMTWRTAihASdJIjVuzzZneOKxjvrwtrCPQfNxdHGKFYBfGMQyfngTKcsGekINHwjRbzclKilpmqemeWXXzRwtVIujQnhEgRaMwobCpge");
    int mVAwYOeKYMcp = 1271506301;

    if (eklRHwImUg >= string("okjfYXErlZYXXVlqwpXuBDqOctnhGxsAdBPtzeIkSUVsoCoqOfkqmSZsNOyXrbEZWkpPCDRMkcqRUcThAsfGrROnaCWMTWRTAihASdJIjVuzzZneOKxjvrwtrCPQfNxdHGKFYBfGMQyfngTKcsGekINHwjRbzclKilpmqemeWXXzRwtVIujQnhEgRaMwobCpge")) {
        for (int jcCTN = 874334061; jcCTN > 0; jcCTN--) {
            mVAwYOeKYMcp += mVAwYOeKYMcp;
        }
    }

    if (WdUeMUNFWkKKvQCg >= -831400.9670783698) {
        for (int THpqr = 589557462; THpqr > 0; THpqr--) {
            mVAwYOeKYMcp = OEcaN;
            mVAwYOeKYMcp -= mVAwYOeKYMcp;
            OEcaN = OEcaN;
            OEcaN -= OEcaN;
            mVAwYOeKYMcp *= OEcaN;
        }
    }

    for (int HoqFel = 1349156007; HoqFel > 0; HoqFel--) {
        OEcaN /= mVAwYOeKYMcp;
        mVAwYOeKYMcp += mVAwYOeKYMcp;
    }
}

string avJhMjXjjPN::tzwAxrjKpQDTGTAh()
{
    double WwJiXvEOpXI = 170719.2962389575;

    if (WwJiXvEOpXI == 170719.2962389575) {
        for (int okjAlSIcEnbYgmYJ = 1965350851; okjAlSIcEnbYgmYJ > 0; okjAlSIcEnbYgmYJ--) {
            WwJiXvEOpXI -= WwJiXvEOpXI;
            WwJiXvEOpXI += WwJiXvEOpXI;
            WwJiXvEOpXI /= WwJiXvEOpXI;
            WwJiXvEOpXI = WwJiXvEOpXI;
            WwJiXvEOpXI += WwJiXvEOpXI;
            WwJiXvEOpXI -= WwJiXvEOpXI;
            WwJiXvEOpXI -= WwJiXvEOpXI;
            WwJiXvEOpXI /= WwJiXvEOpXI;
            WwJiXvEOpXI += WwJiXvEOpXI;
        }
    }

    if (WwJiXvEOpXI == 170719.2962389575) {
        for (int zEEwwjTDIgovZ = 1774719254; zEEwwjTDIgovZ > 0; zEEwwjTDIgovZ--) {
            WwJiXvEOpXI -= WwJiXvEOpXI;
            WwJiXvEOpXI *= WwJiXvEOpXI;
            WwJiXvEOpXI /= WwJiXvEOpXI;
            WwJiXvEOpXI *= WwJiXvEOpXI;
        }
    }

    if (WwJiXvEOpXI != 170719.2962389575) {
        for (int FosntZIBFLv = 371510129; FosntZIBFLv > 0; FosntZIBFLv--) {
            WwJiXvEOpXI /= WwJiXvEOpXI;
            WwJiXvEOpXI *= WwJiXvEOpXI;
            WwJiXvEOpXI = WwJiXvEOpXI;
            WwJiXvEOpXI += WwJiXvEOpXI;
            WwJiXvEOpXI -= WwJiXvEOpXI;
            WwJiXvEOpXI = WwJiXvEOpXI;
            WwJiXvEOpXI += WwJiXvEOpXI;
            WwJiXvEOpXI += WwJiXvEOpXI;
        }
    }

    if (WwJiXvEOpXI >= 170719.2962389575) {
        for (int xeHaoBqTsAqVoji = 1464374791; xeHaoBqTsAqVoji > 0; xeHaoBqTsAqVoji--) {
            WwJiXvEOpXI -= WwJiXvEOpXI;
        }
    }

    return string("heeaHgQZgbmeTACCdnUBOGdXcQlhZFWLQvOiLKiIRUZOeFWPGswCnLZQjsJukQOpcDmSUiPBMTGfTCfw");
}

double avJhMjXjjPN::lhQLWGnXDyor(int ZSLjmOaimTckWCmR, bool HMFtxLi, double JvhuKUzuAji)
{
    string kYSIRHBOrPF = string("jjhLXPirRFpriDdgKdCrCkuOSYgMyJcuEXNgfHATSZEgBJKzXTVMV");
    int zTzovnnX = -449020627;
    double khhMxO = 782824.643328143;
    double hfMzXxClbxNdc = 610664.5756430994;
    double fxEkBEdFtiu = -330851.9071550774;
    int aEfwwabTy = -144167479;
    double KKYnuAy = -813718.3638805815;

    for (int DHgAMRXK = 1709308838; DHgAMRXK > 0; DHgAMRXK--) {
        continue;
    }

    for (int irhXpIGlWSgWYxq = 1390028115; irhXpIGlWSgWYxq > 0; irhXpIGlWSgWYxq--) {
        aEfwwabTy += zTzovnnX;
        ZSLjmOaimTckWCmR -= aEfwwabTy;
        aEfwwabTy -= zTzovnnX;
    }

    return KKYnuAy;
}

string avJhMjXjjPN::knaVHdDpNipXUW(int TSEWzwjGIyacZA)
{
    double MSEWLOJel = -110114.68775140357;
    bool dtUPyeSN = true;
    string cNmIMDTlfnTIGQ = string("DrzIoWgIhLUacNxBkWIlxBEzYTNDurKczxjFtDsNnrZdxbEDfCCbiLqVIrlZsgLPW");
    string XJjzbPoEeTkJXEaB = string("tWvMJxZBshIalHncBXSabkTbCMunLWEcIQveaWmghNEKyujgnFuKvovIBtPgxJDEmLNdKpSuRPyABGhQmWyeDkIJrbRvbVJiIVsaAXMXZGAqunuxcmbZhdsHVwYTaPyqPVVoyxkFaLbVQjKjFdENTqzCGkFVLSaXxEPMGwtpgHBSBUcjaiGSfEalnR");
    int gupOLqofLj = 674734696;
    int HIxejIQSEHxOP = 135269650;

    for (int iuZtdkSnuXbqw = 1661907249; iuZtdkSnuXbqw > 0; iuZtdkSnuXbqw--) {
        TSEWzwjGIyacZA /= HIxejIQSEHxOP;
    }

    if (MSEWLOJel >= -110114.68775140357) {
        for (int YaHQWCWOTUO = 1831591403; YaHQWCWOTUO > 0; YaHQWCWOTUO--) {
            TSEWzwjGIyacZA += HIxejIQSEHxOP;
            XJjzbPoEeTkJXEaB += XJjzbPoEeTkJXEaB;
            gupOLqofLj = gupOLqofLj;
        }
    }

    if (cNmIMDTlfnTIGQ < string("tWvMJxZBshIalHncBXSabkTbCMunLWEcIQveaWmghNEKyujgnFuKvovIBtPgxJDEmLNdKpSuRPyABGhQmWyeDkIJrbRvbVJiIVsaAXMXZGAqunuxcmbZhdsHVwYTaPyqPVVoyxkFaLbVQjKjFdENTqzCGkFVLSaXxEPMGwtpgHBSBUcjaiGSfEalnR")) {
        for (int JPelXvwH = 514728557; JPelXvwH > 0; JPelXvwH--) {
            continue;
        }
    }

    for (int xGrAgkMLmsuUtUvm = 1895954741; xGrAgkMLmsuUtUvm > 0; xGrAgkMLmsuUtUvm--) {
        continue;
    }

    return XJjzbPoEeTkJXEaB;
}

string avJhMjXjjPN::SQWHLoPoT()
{
    bool rXidvY = true;
    double HnZmZr = -766726.5680336163;
    string fDRoOpKel = string("qIvEzAbbPaMIySzXo");
    bool dqFFdefpaU = false;
    string OzGbzENtTBvopPtX = string("aotDchptuolHuUZsiSpsDvSXfZBXLwOeJUeytXYIQhUokNtEwKrplwHDmaegzvaFoXfybfwceNJJWtFlTScFMmAtOqSjFUSNeIxtognJIOdgraOOlLLOXGnHUuRkTBdcYZlvwdUZTnByGBQQPCDbfxPnAaignqWDiYMdCRfaBLhkFtpWvCqifEIGNByZbvIpRngpzdEkXlwsmvruDUEZcnaOjhIWkkIzaSkaPby");
    bool SwsbJZIDvCgA = false;
    int DthtmAgfTJJFmd = -209236273;
    double BHCsQXJPzylxixd = 471848.87767947954;
    int KWzOBmYKonj = -150016259;

    for (int OqzWTondiZHKUrM = 413911899; OqzWTondiZHKUrM > 0; OqzWTondiZHKUrM--) {
        SwsbJZIDvCgA = rXidvY;
        dqFFdefpaU = rXidvY;
    }

    if (SwsbJZIDvCgA == false) {
        for (int GKRcKYDB = 1409250250; GKRcKYDB > 0; GKRcKYDB--) {
            DthtmAgfTJJFmd *= DthtmAgfTJJFmd;
        }
    }

    return OzGbzENtTBvopPtX;
}

int avJhMjXjjPN::jiBbVHKxVIopoEcA(string MFonEyzQOEvc, string ErACmdMKQFirBpPe, double LaXPvmDxPCr, bool nbUnRzxfRiup, bool YSfDMTa)
{
    bool DBfwBsnvmgxgv = true;
    string MbAXcWFnFozWeqF = string("UUwUyQPMZxgVZOhabsFMENCUtWNuaVrTOTJPQsDeHHSYKjhPJnbysYqgNATopcPFcxjgnsARQuvXVgrIXBrGDonCGpiaQvyRlPzHurvOTdXyeQsgstXXweJMYpreooTjDgbLagXyaBcHuagbcCsWVOxhKmAt");
    double Qcbfzsbw = 602524.882640027;
    int SZMHkLFKQeFKrd = -843620325;
    double MvyzCQFik = 116593.98292953466;
    double orcDpnggZGcte = 784112.2137428727;

    if (MvyzCQFik >= 602524.882640027) {
        for (int JtmsqeE = 626085460; JtmsqeE > 0; JtmsqeE--) {
            DBfwBsnvmgxgv = ! nbUnRzxfRiup;
            LaXPvmDxPCr *= orcDpnggZGcte;
        }
    }

    for (int kddCdGSsfFOAGm = 1316686885; kddCdGSsfFOAGm > 0; kddCdGSsfFOAGm--) {
        MvyzCQFik = orcDpnggZGcte;
    }

    for (int DfIGlnlyH = 730525614; DfIGlnlyH > 0; DfIGlnlyH--) {
        MvyzCQFik = Qcbfzsbw;
        Qcbfzsbw += orcDpnggZGcte;
        DBfwBsnvmgxgv = ! YSfDMTa;
    }

    for (int VOWEUcPnqebb = 1021959585; VOWEUcPnqebb > 0; VOWEUcPnqebb--) {
        LaXPvmDxPCr -= orcDpnggZGcte;
        LaXPvmDxPCr -= orcDpnggZGcte;
        MvyzCQFik += orcDpnggZGcte;
    }

    for (int jRVUviqzw = 2112483023; jRVUviqzw > 0; jRVUviqzw--) {
        continue;
    }

    return SZMHkLFKQeFKrd;
}

double avJhMjXjjPN::yAZKVdCJd(bool BAyQgN, int OWfZZchFqBX, string BaqiuYYaEK, double vgPVjGImcD, double RjhjiGLAklvHY)
{
    string XNIMiVgTS = string("bRAksbeHgLaXY");
    bool MkCXmSvRyPsnyV = false;
    string thjJBzZV = string("dcymNsPYCwKlEIrBMFxXbDmSRCziHWUrFzSbHRkWULeeQyaxWaEFDaUMMTEmvOyoPDFpSVrttkomYNmGcTKVGlIBbcvDSvusQUUYGZoaXZlFJeIPuGnlLQZiINdTlYdNdcrLTFiZGcisnUM");
    string LheEtql = string("MOetIEQlDXajb");

    if (LheEtql >= string("IBaxRmYRQgfOGTpfISxSaiWUMFxdDxqfZVzUHUYphKrzBeUqIwfcuECvEEuH")) {
        for (int fMfqubppXukwYpR = 985551854; fMfqubppXukwYpR > 0; fMfqubppXukwYpR--) {
            continue;
        }
    }

    for (int WCOOhMSsUFoy = 61648153; WCOOhMSsUFoy > 0; WCOOhMSsUFoy--) {
        continue;
    }

    if (XNIMiVgTS != string("bRAksbeHgLaXY")) {
        for (int DXEMJS = 1438007860; DXEMJS > 0; DXEMJS--) {
            BaqiuYYaEK = LheEtql;
            XNIMiVgTS += BaqiuYYaEK;
        }
    }

    for (int iRBcUAnZXRUhl = 782328336; iRBcUAnZXRUhl > 0; iRBcUAnZXRUhl--) {
        continue;
    }

    return RjhjiGLAklvHY;
}

string avJhMjXjjPN::iICcTeCrzliqRPK()
{
    double EXFShVlSeNLNU = -599040.5186966311;
    bool TFewZHILlYF = false;
    string ehFodn = string("ZTXMcJyqmpAuIuUnGZYGQoAIJgzDvHRdIKVBxBwdQIpdVrtHFiMEMXjVygiHOIBYLFlLylEnPuCNuuOapXrcGTmFiyKuPbOTEeSgIhEMmLLsAxNfxhqBpPesVcOpkqvXOzEVdmneAetNFYpMfjCZQChUKvSIhG");
    bool TJcvpTaQEq = true;
    double cyQFicYW = 819007.3376547539;
    double MtazvwrYM = -800978.5359301717;
    string NFvnHPcxHspm = string("QIjQQoyrOOtiwNnuXBlqnlvPLQuPNsILjefPsHvlbsSSdCXZZBuKqbhDYQEZiDyevPxKuovOZjFfYozmXKCgTMGTdRyTowbvJqJcwdSazQrdBXARHnhNyuZuqVdOeKZiuUKOKunLzHQkjrdfGuKNKutBITfOHWPFYpDNfAMdL");
    double QlfjfMY = 668228.011120506;
    bool kQuYGtEFHjaV = true;
    double TpTrzicco = -111209.34691477474;

    for (int sninryOqIH = 954961898; sninryOqIH > 0; sninryOqIH--) {
        NFvnHPcxHspm = NFvnHPcxHspm;
        NFvnHPcxHspm += ehFodn;
        QlfjfMY = cyQFicYW;
        QlfjfMY = cyQFicYW;
        cyQFicYW /= EXFShVlSeNLNU;
    }

    return NFvnHPcxHspm;
}

double avJhMjXjjPN::PyGIZWmWBzwrto(int lWCvLsLT, double thsxYPi, double ufuATf)
{
    bool pEopX = false;
    double LqdmCBPt = 342542.8194377559;
    int uMyuYSV = 2080479720;
    double OlVmnHLp = 236984.41489469793;
    double vGKyssEHtVEpsTKb = -448484.02844335715;

    for (int uoAcVEFJzSzHqBT = 974307210; uoAcVEFJzSzHqBT > 0; uoAcVEFJzSzHqBT--) {
        vGKyssEHtVEpsTKb = ufuATf;
        ufuATf /= OlVmnHLp;
        pEopX = ! pEopX;
        uMyuYSV += uMyuYSV;
    }

    if (thsxYPi == 342542.8194377559) {
        for (int qWoSeqHQYcyK = 539032940; qWoSeqHQYcyK > 0; qWoSeqHQYcyK--) {
            ufuATf /= LqdmCBPt;
        }
    }

    for (int kVejQW = 773108477; kVejQW > 0; kVejQW--) {
        lWCvLsLT = uMyuYSV;
        thsxYPi += LqdmCBPt;
    }

    for (int OFAGn = 113181589; OFAGn > 0; OFAGn--) {
        continue;
    }

    return vGKyssEHtVEpsTKb;
}

bool avJhMjXjjPN::XodBUTlx(double ykcmfjfGmWRKGjv, bool FVIhEtKpXlk)
{
    int OMgDHnLn = 200025670;
    string TthIXs = string("DxIg");
    double UJBlFnwoayEgB = 1036553.4327596407;
    string YIzCyTFlMXcEcQp = string("zQTgBRqnZmPhBegrqjtkKkrNWMdxzepTJJbFRWhZDaYnxPVZmfXYOtsMpfinFIsfqzfHxRDyJOkuWPYVvXBZKYonmTgnIYmwpVzZegsRVlSPAcZCRghuTUOeDrbHnFXQqoPWD");
    int lTczfZhPvTLvM = -2106030073;
    bool ojAcClazxv = true;
    int xUkHLvOXPXIZCuKZ = -1129564300;

    if (xUkHLvOXPXIZCuKZ > -2106030073) {
        for (int bQzLM = 786778456; bQzLM > 0; bQzLM--) {
            TthIXs = YIzCyTFlMXcEcQp;
            TthIXs = TthIXs;
            lTczfZhPvTLvM += lTczfZhPvTLvM;
        }
    }

    return ojAcClazxv;
}

string avJhMjXjjPN::qPcZNOYyMLivIZme(string GgVigiuTnV, bool uHPxwynhymgNA, bool VlKRLeVOSTFfROA, bool GMIRZXTarSVw, int yFmYlDNkMr)
{
    bool pKckgEOLVAsgCfu = true;
    double bYcrojUbWuzrqK = -897176.7018396783;
    double bWSLxUWTHg = 632186.526848488;
    double SPBUPR = -588245.5388375543;
    bool DDKZRje = true;

    if (pKckgEOLVAsgCfu == true) {
        for (int nVhlrG = 1466029278; nVhlrG > 0; nVhlrG--) {
            pKckgEOLVAsgCfu = uHPxwynhymgNA;
            pKckgEOLVAsgCfu = ! pKckgEOLVAsgCfu;
            bYcrojUbWuzrqK /= bWSLxUWTHg;
            pKckgEOLVAsgCfu = ! VlKRLeVOSTFfROA;
            GMIRZXTarSVw = DDKZRje;
        }
    }

    for (int EzUZt = 481628034; EzUZt > 0; EzUZt--) {
        bWSLxUWTHg = bYcrojUbWuzrqK;
        uHPxwynhymgNA = GMIRZXTarSVw;
    }

    return GgVigiuTnV;
}

bool avJhMjXjjPN::uuYJyYi(string iEvvxbWHjKaMtCq, double LhHxlAKpTh, bool oPWIUFNOMYHbqqLZ)
{
    int lKSoPwi = -763059619;
    string fezFKnyPyXOR = string("KUvRdkmzEesCZQGWtvaPqjoelitVKSncYMfhIsZNgfdyIPOXorPktqPtMjCLnYdTrUGcKtXolZHesJfPjxbSiOeXfSUsXqLTyIzevrfitiEFGMZWopyahRrJUgHEAFBnVDvQzwUHwOITrfWHvnUUvwZfQttFLsYSWSTHVGIEHlotfFSYHgqqmLWxfarrwgGcyReJNYxcbnmQNNblYFgkYJlfdbSPGWAdJHBaMQTjtDztLhxPZizuBt");
    bool CVQgeigEdSmsoMMM = false;
    double WjVnD = -165621.846164406;
    int MfnTx = -1752648115;
    int cHYKiJrQiXQBEy = -27825617;
    string fhsVe = string("coTEVLVfQlDaNjCSKPeXQducYPHPaLcfqxJVBRLzGdbdVtZtFWDxKeMlvnxffRwbigmoqPSTSyEQierdMLzRoC");
    int tTvnSwFdGsUulT = -936942509;
    double gMKdfmAjS = 874107.433874435;

    for (int bVeckqD = 701780644; bVeckqD > 0; bVeckqD--) {
        continue;
    }

    if (cHYKiJrQiXQBEy >= -936942509) {
        for (int tvagnbFFheBDukDk = 285948943; tvagnbFFheBDukDk > 0; tvagnbFFheBDukDk--) {
            continue;
        }
    }

    for (int YuCIx = 292063523; YuCIx > 0; YuCIx--) {
        oPWIUFNOMYHbqqLZ = ! CVQgeigEdSmsoMMM;
        lKSoPwi = lKSoPwi;
    }

    for (int JiJqUjFBB = 1891169904; JiJqUjFBB > 0; JiJqUjFBB--) {
        WjVnD /= gMKdfmAjS;
    }

    for (int mMVrxIOIdtEkAcZO = 1597893923; mMVrxIOIdtEkAcZO > 0; mMVrxIOIdtEkAcZO--) {
        gMKdfmAjS = LhHxlAKpTh;
        lKSoPwi /= MfnTx;
    }

    return CVQgeigEdSmsoMMM;
}

void avJhMjXjjPN::FGnqSRV(string WcYER, string GSnwBWfeiKQxXl, bool kNDuTEpkEj, int VQezLQEvnvN)
{
    bool ufLuXuipJo = true;
    double yljjpSaEvsROWFG = 413842.5390143547;

    for (int ERIPN = 647805358; ERIPN > 0; ERIPN--) {
        kNDuTEpkEj = ufLuXuipJo;
        WcYER = GSnwBWfeiKQxXl;
        yljjpSaEvsROWFG += yljjpSaEvsROWFG;
    }

    for (int gCGtxTlb = 410931823; gCGtxTlb > 0; gCGtxTlb--) {
        WcYER += WcYER;
        GSnwBWfeiKQxXl = WcYER;
        yljjpSaEvsROWFG *= yljjpSaEvsROWFG;
    }

    for (int QvPUfyQqjmZ = 1653637962; QvPUfyQqjmZ > 0; QvPUfyQqjmZ--) {
        kNDuTEpkEj = ufLuXuipJo;
        kNDuTEpkEj = ufLuXuipJo;
        ufLuXuipJo = ! kNDuTEpkEj;
    }
}

string avJhMjXjjPN::JOnaAaAhrcs(double ljCPCdFCdVOz, int YMprQutSXrCtXtB, double rVERGdY)
{
    double sIszwWRWSKm = 760852.5702642406;
    bool bPFaCNizpeYbW = false;
    int pUEGdYoUcCXQTu = -201378604;
    string PZILNJVhLB = string("KYflsRFelHBcgQQvNssqfrnNDYzlvehtxJTrQJAbfFXDZmrHTkBzLBkCrbsiqosCcZJjLuwUNjDEVvrfmALtTQrIPAuPpiqlomoXtYmrWUwVvDhskDsiAgXLbBAgKuoIWaCVzfyzdVmdjONCgnyHHBikBmLJCLKHolPyOIFDUFPKCyvweiFkDWnARXAYOywXquwLTdL");
    int kUZWlvXipqXaE = -209310016;
    int cQiVYUlAjLqRJgAp = 765635722;
    string wsmwNFjmJ = string("yAPJPkWFdfdLhBMvLZWHnhrFsMUbEiuyJRTwFtDLFYLqhAdqDxgvDrJOQLgUCvikQRdHwHFqKjdOPnmjwGjLFZYYeSNxzTLYqUKlRwLxmbJyPKmdiOsGrAqoSEtklReLbrLQTtVPGGGlwSVDZLmLDeDFKqBExTSpNxAKleJZgfMylGrOtPhCuPvbjYMgXzWqD");
    int GxvyBtiAaweS = 721436497;
    bool tKRYYjIvzyFGINi = true;

    for (int yYZXTXx = 1869030666; yYZXTXx > 0; yYZXTXx--) {
        continue;
    }

    return wsmwNFjmJ;
}

string avJhMjXjjPN::JabOXkhdYAIxnK(double AFvxMPJqMotwiI, double sOXhBklKDyaaZUBO, bool QnqrlaVAkFv)
{
    double hYQXB = 913528.5857076924;
    string sSfVFSa = string("iotctoWSddwSIMhdEcWXWwrJjSkIWrYdllTXnraYblbVuJPMGfeiKUSVpTcSDpkweGOMwQIhpFhnFGZwFaBairuwSgscgQmSVYrBHItpYRpcUExjCqrosmhCoQLIcRfDtdlZtGqeYPaIMBViMDyAGByKBBHqUXUfBRiRBxjQhQIJuIkRXSFIAyqjVhJqrUjRlBNwygaKDSkbQeMtgIYnlJDlQo");
    string WmtRZVyYJSfCUSQQ = string("aeenhGxzDFqBiNpMNSgxVdRQnfMsAvCpDmwjrMASXWrSEzpYughtGWPlFplVCXjmSIRz");
    bool OYRMetokoOTWBcr = true;
    double DCzir = -708217.1055732906;
    bool kxHXG = true;

    if (kxHXG == true) {
        for (int nXuAUhdjlNjpH = 1402970042; nXuAUhdjlNjpH > 0; nXuAUhdjlNjpH--) {
            continue;
        }
    }

    for (int ISTGsrUPmkk = 841261666; ISTGsrUPmkk > 0; ISTGsrUPmkk--) {
        sOXhBklKDyaaZUBO -= sOXhBklKDyaaZUBO;
        QnqrlaVAkFv = QnqrlaVAkFv;
    }

    for (int mhJIsuGFcNle = 1774530182; mhJIsuGFcNle > 0; mhJIsuGFcNle--) {
        AFvxMPJqMotwiI -= hYQXB;
        hYQXB += AFvxMPJqMotwiI;
    }

    return WmtRZVyYJSfCUSQQ;
}

int avJhMjXjjPN::xrzxdhQ(int dyFIjQXBZomY, int zPJOmPBG, string kAeLtikiqVO)
{
    int wyLLrM = -495799675;
    double afprECrVcRWtlme = 715450.846452481;
    double uqPDszY = -960475.2000248407;
    double HxSKClASmNqbvxl = -807278.849980939;

    if (dyFIjQXBZomY >= -1668190133) {
        for (int QQBtWcKDol = 477682609; QQBtWcKDol > 0; QQBtWcKDol--) {
            continue;
        }
    }

    return wyLLrM;
}

int avJhMjXjjPN::nOcHg()
{
    double rvRwlxlNMpJhaXph = 111702.7977526175;
    bool pVvOATccNwW = true;
    double bUjuLeFJcCJRtShZ = 367429.07240571076;
    bool YNuJtchuflGu = false;
    string KtYPEuuMqcVekgDt = string("XuPvSFrRapgojcjHKXhWnjGnqGIKHBBkDEVGISasKIqHlGCuiWMVYAUDLDIKmdGjYCuySifIhPsJexQdNJakZgyfffr");
    int GnLubhlWBDzpHAB = 1117076779;
    string ESxFbQeu = string("ElECQfurhaBegSOAKdZCrXLshnQNaIDbjbbOdhEfibteNaLJw");
    int dMvmkfgddwxmnP = -1158388640;
    bool kOspkLCHLCtyrmS = false;

    for (int qLlyNSwufxOCqg = 85676820; qLlyNSwufxOCqg > 0; qLlyNSwufxOCqg--) {
        continue;
    }

    return dMvmkfgddwxmnP;
}

avJhMjXjjPN::avJhMjXjjPN()
{
    this->GTpKxAfdXZpyBt(1027431.4309885382, string("qnRGldkOaHXVoPjXGkBkNNMbLfwnJQkGhoLwtxGKiYTWNgGWpglReaYbiEVwpgqDFSLNqwQYfUCDyGYRchmPhravOwyJiMuykaQGdjQZhNclcjpWnGeVNrPkBVPnPricZiR"), false, string("WxHZIUsARvyzqYqZRgZNuJXPByHTAhmBpRcQiODkDpVduGIrdLGBmzwbJsIDOESpaYKixzDrWvvJbRvVTJfLVOrsRXQQpRaNuPDPJDQRfFBvTONXWU"));
    this->vThTJsWK(true, string("AdaJKMUAeYxJQUWOuRkmhTAcCRVgUkfieZjavloBMm"), true, false);
    this->CIAjimxnfOguk();
    this->tzwAxrjKpQDTGTAh();
    this->lhQLWGnXDyor(1834047248, true, 182924.50321937777);
    this->knaVHdDpNipXUW(803641445);
    this->SQWHLoPoT();
    this->jiBbVHKxVIopoEcA(string("DAoYigpUBKsvdsipZOrQJtIuYM"), string("rPxSKUGjFGmJfpZqCSEQiSUCwLHvYLnZiYfiEGTuxwYXqFkqyvzQoTfiQnXkjOkFnsKsIisvTewWmch"), 299251.6089660144, false, true);
    this->yAZKVdCJd(true, -1445848607, string("IBaxRmYRQgfOGTpfISxSaiWUMFxdDxqfZVzUHUYphKrzBeUqIwfcuECvEEuH"), 861066.3554870763, -523977.9833245385);
    this->iICcTeCrzliqRPK();
    this->PyGIZWmWBzwrto(-1617034099, 436742.12387927953, -267033.78206585086);
    this->XodBUTlx(396741.0191588578, true);
    this->qPcZNOYyMLivIZme(string("RRgRWeEqFJNvGiMSsqmePMGllVjdlcyWJsHlHlQeUvcRSxfPHzLmwWnIylsiVFsUuJJrKsOwnFedxYJeDedOUUhYXaXDXPDaFvGxAGhvcXTairrEyLchnPCZneDsaQtWHskByvWhwPUBjKqh"), true, false, false, 94906512);
    this->uuYJyYi(string("OLHDOcZFARRzPwnDjtYomDAnCFWYBdlyXJGcGCCoMhGmUNcGUWzcRlXPPonEDwhETHNHthLiiVzBowWlYteFKllbgMBkzbwQrEWicCiuVCwpmZbedwNRYcxgfYcgUizNSKURuJEUdxGMhXJqbFaqBtMRAqsSGVmaEfZxXdrDMKKQmhBdhMhnKEaLxnpSXQRQhbJsIGtHuOxIWdqrctKWMXyOqrUhPeDZyxwgeQANWdE"), -344607.3079556916, false);
    this->FGnqSRV(string("RIDkMvwpxJKfQObpyiCItVzWUgMELxiyuCjIBwmfjwSRWfquBdWpjpayqWZNkXZNrHfJiTIbmMVLzoCAflwTgKZGQJBnWEvtQqeyISeNyEzYXJMxJJEdYmUeFxDGkLmIiynxPZQQIpFGjOhjogiDLbhoahXxmxnvoSUmjb"), string("NXnlJOXfjCiljmksahRgrUTFpyllfFsamIbSSRioRSRUJNXhYdYUrntWeeMLVcSORGbdOBwixmVzxonopdeHIdSFdimLXSKPP"), false, 1190880631);
    this->JOnaAaAhrcs(-230935.4621556147, -706033740, -384570.6839428796);
    this->JabOXkhdYAIxnK(201764.27523152847, -803181.9453427559, true);
    this->xrzxdhQ(-1862372984, -1668190133, string("wHJRRnvHUuHzbHcDJOmRmflruOmEaYjNZfxThgvCuFSPIRbCkNzLxEAGtgepnlYzmHCSoPnbucddMISPCruwigiyBtvlRlJIazJlsvjbqeXZRFhRPyCEUmpWtgxkkvpOfvUAaYeWMe"));
    this->nOcHg();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class YOzGKDuFB
{
public:
    string CXXYbVYIDJpxx;

    YOzGKDuFB();
    int WRpZk(string XpMMH, double YaPJzOeguDtRMa, double Zhlmi, double trnuDrkWHKbsJPze);
    string TizNrjfHRBG(int UWVHuxXgpi, string IbkExKUlx, double GsaGyN, string IzDesuTuN);
    int PgdNXMQlsP(bool ubkNpKjrMwci, double RbATTWIcRCUmfjN);
    double qcvzWZxnaxOupo();
    string HcgsTKcqCj(bool oeZgnzxbTBV, string UdJmrrfDDcpkeQC, string yukguRMdpbLwRFM, int AdJJhgpOEPIvh, string AEtaj);
    void IDlfGCnOo(string JITXISfdNmVGjEV, int SqinFN, double rZgeAgLtpG, int jbTqZGsPx);
protected:
    bool NAEyxrZfxevYhEax;
    int nbppncTFd;

    void vwHcJFninPnwZfmE(bool BwmJvablZoGHquxD);
    double OVeOry(bool RXTHQLniTMbXqccA, double UQoKxG);
    int TbXxPvXj(double OSSwwmpMetOOZM);
private:
    string IrKOef;
    int FewpDLcjqX;
    string wNnWhEyBMYla;

    void ldZZb(double iSyZuv, string sJWBQNnDhC, int HuXCzuy, string AVveDUdGUnhy);
    bool XAdFryOQbcxvVFsh();
    bool kDytziuPGhb(string GMLqGTKt, bool ipKLdqAahNGACJw, double scCnB);
    string XhaEzjBdy(bool jidtm, string kxkiRrqdl, bool RUwHoThiEbK, int SFADg);
    string RsxNMTzTwEcGV(string Elouyq, int jQaGUumMhu, bool TQUJafWVYQGxr);
    int UiJKyWDrKHqAEmD(string iWTsGKzFs, double OPdwVfdRwwb, bool OmzJK, int QaOirfQHLvPK);
    string kxzgLSIJNuC(string QSwzSnAkKFVn, double CbhBRFpCu, int ZtJnbeYH, string jWGBtiuy);
};

int YOzGKDuFB::WRpZk(string XpMMH, double YaPJzOeguDtRMa, double Zhlmi, double trnuDrkWHKbsJPze)
{
    int UmlMYE = -1789781270;
    bool KGCpmqOmkRFiL = true;
    string XSJMnYV = string("IiIsExw");
    double OUPnSs = -585666.4444834632;
    double uKCALEynIsQL = -701571.5702445424;
    int ZLIlWI = 199234253;

    if (trnuDrkWHKbsJPze < -585666.4444834632) {
        for (int lZPttfhTi = 1975472923; lZPttfhTi > 0; lZPttfhTi--) {
            Zhlmi /= OUPnSs;
            UmlMYE = ZLIlWI;
        }
    }

    if (UmlMYE >= 199234253) {
        for (int LPhSdzrPC = 794942873; LPhSdzrPC > 0; LPhSdzrPC--) {
            YaPJzOeguDtRMa = trnuDrkWHKbsJPze;
            ZLIlWI = UmlMYE;
        }
    }

    return ZLIlWI;
}

string YOzGKDuFB::TizNrjfHRBG(int UWVHuxXgpi, string IbkExKUlx, double GsaGyN, string IzDesuTuN)
{
    string FNFOqiKCnHTdwRrH = string("vcxcDyZVRaUQXpvvsmLnvcWRTVNYWJEyZmRsdkLbrutJoFKzlpSXfoPxSeVSmVlwTWxwxhhSAFNvSXCTPbKIAIDnARNSjEIGzmZdhmritHXpwpshNBLArYVKQaXhVTXsfonOSQJnwBVpJWWrmJvgoLCyhkLWXHVaRhEaFMVSlQTecDDGUPPlxTxikxzXBdIfkgYgPvQvORzSPJPHCOHhfdOZBvwHdzKqzWhIUJIVvbfTIEaJimlmQSMzaEP");

    if (FNFOqiKCnHTdwRrH < string("wQafOigPSpVXqXYSprveclhwBPyOLnmmbTgOZNQoljtJjhcwWOrShWXINvMDgNFZKZTIoThFzuduYbcUBIKMpoGKcFGHnjqlPxfOHmLWTxJLncRbxioKmBqBjhmooIuJgFltZHbvOXSHg")) {
        for (int aWnnqzfL = 736057601; aWnnqzfL > 0; aWnnqzfL--) {
            IzDesuTuN += FNFOqiKCnHTdwRrH;
        }
    }

    if (FNFOqiKCnHTdwRrH <= string("wQafOigPSpVXqXYSprveclhwBPyOLnmmbTgOZNQoljtJjhcwWOrShWXINvMDgNFZKZTIoThFzuduYbcUBIKMpoGKcFGHnjqlPxfOHmLWTxJLncRbxioKmBqBjhmooIuJgFltZHbvOXSHg")) {
        for (int tRbWHFyPWaTU = 1832197900; tRbWHFyPWaTU > 0; tRbWHFyPWaTU--) {
            IbkExKUlx = IzDesuTuN;
        }
    }

    if (IbkExKUlx == string("IQAiBVSsgIwBEOvqFlWhxYxBQlJxKohyDWdAqIYPxRSVHeOOxiditEGJWzKeURUsJIJZQdlKJwSNNGUJvMLbT")) {
        for (int SfoUZGBmFUX = 987139877; SfoUZGBmFUX > 0; SfoUZGBmFUX--) {
            continue;
        }
    }

    return FNFOqiKCnHTdwRrH;
}

int YOzGKDuFB::PgdNXMQlsP(bool ubkNpKjrMwci, double RbATTWIcRCUmfjN)
{
    int xncezFaca = 215718341;
    int DlpCtMSqU = 1679540852;
    string MiyTZCHReX = string("QgBgeT");
    string XqQhK = string("smfBaXbQJuFNuymHoMWbIOWTjeQhEtiHWTsPSbpXENLUNVtjVbhuRLLVMbypaKxfWAviFExpYnAVXFmvItRTlXOgR");
    string NtIgHawvU = string("WIVapTqOyRTreiIuA");
    bool WZpTIzPG = false;

    for (int sixmcmyvkJ = 787076664; sixmcmyvkJ > 0; sixmcmyvkJ--) {
        continue;
    }

    for (int LLVVtMS = 1535197796; LLVVtMS > 0; LLVVtMS--) {
        MiyTZCHReX += XqQhK;
    }

    for (int hgyLVOEBOLfwiG = 302275342; hgyLVOEBOLfwiG > 0; hgyLVOEBOLfwiG--) {
        continue;
    }

    if (NtIgHawvU > string("WIVapTqOyRTreiIuA")) {
        for (int PCqdDZk = 361229197; PCqdDZk > 0; PCqdDZk--) {
            continue;
        }
    }

    return DlpCtMSqU;
}

double YOzGKDuFB::qcvzWZxnaxOupo()
{
    bool hqIcJwyStBDpSiKm = false;

    if (hqIcJwyStBDpSiKm == false) {
        for (int cFSNzRHiWFuXdGc = 1915286841; cFSNzRHiWFuXdGc > 0; cFSNzRHiWFuXdGc--) {
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
        }
    }

    if (hqIcJwyStBDpSiKm != false) {
        for (int OZGJJqhwIbiY = 1338270971; OZGJJqhwIbiY > 0; OZGJJqhwIbiY--) {
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
        }
    }

    if (hqIcJwyStBDpSiKm == false) {
        for (int JDcnWVNDSv = 1526055899; JDcnWVNDSv > 0; JDcnWVNDSv--) {
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
        }
    }

    if (hqIcJwyStBDpSiKm != false) {
        for (int DvjTe = 937619890; DvjTe > 0; DvjTe--) {
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = ! hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
            hqIcJwyStBDpSiKm = hqIcJwyStBDpSiKm;
        }
    }

    return 721658.9939085406;
}

string YOzGKDuFB::HcgsTKcqCj(bool oeZgnzxbTBV, string UdJmrrfDDcpkeQC, string yukguRMdpbLwRFM, int AdJJhgpOEPIvh, string AEtaj)
{
    string jOoyaPrlf = string("iblrbRPMLQPZwhTlJUumEkdhwALHBXaKyaJJGyrcgKzofxGcnagXHXvezbkHPwEafuDnaZYLXBLOfuPYjPOOGgIFgcEGkjMIfSJIHRkOEgONYjwnqZaSkZfIWIkCRMcpEgIyZvYJwBzj");

    for (int VUpLjeoiALRZYMZv = 1043596322; VUpLjeoiALRZYMZv > 0; VUpLjeoiALRZYMZv--) {
        AEtaj = jOoyaPrlf;
        oeZgnzxbTBV = ! oeZgnzxbTBV;
    }

    for (int tQKyIemSZPpvZBSC = 1147381875; tQKyIemSZPpvZBSC > 0; tQKyIemSZPpvZBSC--) {
        jOoyaPrlf += UdJmrrfDDcpkeQC;
    }

    for (int IzLTFSfDRfP = 398176382; IzLTFSfDRfP > 0; IzLTFSfDRfP--) {
        yukguRMdpbLwRFM += yukguRMdpbLwRFM;
        AEtaj += jOoyaPrlf;
    }

    if (jOoyaPrlf < string("CxxFwNIgHegBDshRAiFCZSDCxBtjOwRrXtRKDqIlAkwQeKdMdvuizxfhuUprFAqDCbGauCvTSYgPLsmexYWwenMYuSWWllPrObsqquygKpPHEsNmzZdFvGJSIcnMoldEGUdCRnZDrzdSOHnMTNSpmJYUo")) {
        for (int KzfeXygvz = 1735360321; KzfeXygvz > 0; KzfeXygvz--) {
            oeZgnzxbTBV = ! oeZgnzxbTBV;
            jOoyaPrlf = yukguRMdpbLwRFM;
            yukguRMdpbLwRFM = jOoyaPrlf;
            oeZgnzxbTBV = ! oeZgnzxbTBV;
            AEtaj += UdJmrrfDDcpkeQC;
        }
    }

    return jOoyaPrlf;
}

void YOzGKDuFB::IDlfGCnOo(string JITXISfdNmVGjEV, int SqinFN, double rZgeAgLtpG, int jbTqZGsPx)
{
    int AqaHJER = 1842314643;
    int PDedFkHTZlA = -139373994;
    int KgkJVflLvylnIWuz = 1403299872;

    for (int IWfpBeOWAk = 948531479; IWfpBeOWAk > 0; IWfpBeOWAk--) {
        AqaHJER -= KgkJVflLvylnIWuz;
    }

    if (AqaHJER <= 1842314643) {
        for (int zUYntGFf = 1888169932; zUYntGFf > 0; zUYntGFf--) {
            PDedFkHTZlA += KgkJVflLvylnIWuz;
        }
    }

    for (int CcRviCpWdyNkO = 673412887; CcRviCpWdyNkO > 0; CcRviCpWdyNkO--) {
        SqinFN -= jbTqZGsPx;
        jbTqZGsPx = PDedFkHTZlA;
        PDedFkHTZlA *= PDedFkHTZlA;
    }
}

void YOzGKDuFB::vwHcJFninPnwZfmE(bool BwmJvablZoGHquxD)
{
    bool UIALlszbPKwONJdy = true;
    string CjzMwqck = string("TAGJQwUUxHtaiKt");
    string ztYpneAhqVSWLhb = string("fbRikngOjDuaOVlEzyutxuSsLHDESjNRpTqJcObJtsYHXGEVgVqkdMfXMpApzzDZDwQNVXfsbhkwjqpcgALKChyWKRjuNAQMCuwIRmkVpnxzRUllTMmieRuTyyWpqTDRppjjNbzsweLOQEeGZBWNAZSu");
    string KNGJOIDr = string("fTcdpZmipfdoMpeJIwQyzAhcwExOzwUnLhRpUuDJMvGFIcFsDxCCjWZUyXQttlSNxGmtarFhpxaffdntUEcoCUEKhPChxrhmdCxORtMgfCIXrzwVodAhNTnzQMQMyeIRMXQUbyPgoBOXMSKtUWkfZsqBlOYsaMNslFCNVHdPuRiNViJIbMwRILBTziAjnKSrcAvfKZHtee");

    if (KNGJOIDr == string("fbRikngOjDuaOVlEzyutxuSsLHDESjNRpTqJcObJtsYHXGEVgVqkdMfXMpApzzDZDwQNVXfsbhkwjqpcgALKChyWKRjuNAQMCuwIRmkVpnxzRUllTMmieRuTyyWpqTDRppjjNbzsweLOQEeGZBWNAZSu")) {
        for (int euWxjMUrkscD = 1840171686; euWxjMUrkscD > 0; euWxjMUrkscD--) {
            BwmJvablZoGHquxD = ! BwmJvablZoGHquxD;
            BwmJvablZoGHquxD = BwmJvablZoGHquxD;
            CjzMwqck += ztYpneAhqVSWLhb;
            UIALlszbPKwONJdy = UIALlszbPKwONJdy;
        }
    }

    if (ztYpneAhqVSWLhb <= string("fbRikngOjDuaOVlEzyutxuSsLHDESjNRpTqJcObJtsYHXGEVgVqkdMfXMpApzzDZDwQNVXfsbhkwjqpcgALKChyWKRjuNAQMCuwIRmkVpnxzRUllTMmieRuTyyWpqTDRppjjNbzsweLOQEeGZBWNAZSu")) {
        for (int ydbhjceeNqtH = 259798909; ydbhjceeNqtH > 0; ydbhjceeNqtH--) {
            BwmJvablZoGHquxD = ! BwmJvablZoGHquxD;
            CjzMwqck = CjzMwqck;
        }
    }
}

double YOzGKDuFB::OVeOry(bool RXTHQLniTMbXqccA, double UQoKxG)
{
    bool zcOTkAJcR = true;
    int MjyfeOgqSrp = 1668140786;
    bool MlPrLNB = false;
    bool uGZGPvfr = true;
    string XTLwMEaPdvvqkS = string("HmdSSApoUyTHaaEIikdKRAoNwLYGbuqFEPNLziNDTemHAoRNFmmTDqjFkGpozcREPmuwMRelqDxeEDutGtdJKkwLccccLtuUQnKfHTsRtxDxRIfJzoQRnmWXulDfdDkpMmWrCAUOhGinkwFeNMBBNAbvANrWTCWidBvKOPWEwkdkMCrlNttIlTJBHQUFOgijBxuRnAInzhuSnYtLKTVffiavEGzwHwpVrmadiAV");

    if (XTLwMEaPdvvqkS < string("HmdSSApoUyTHaaEIikdKRAoNwLYGbuqFEPNLziNDTemHAoRNFmmTDqjFkGpozcREPmuwMRelqDxeEDutGtdJKkwLccccLtuUQnKfHTsRtxDxRIfJzoQRnmWXulDfdDkpMmWrCAUOhGinkwFeNMBBNAbvANrWTCWidBvKOPWEwkdkMCrlNttIlTJBHQUFOgijBxuRnAInzhuSnYtLKTVffiavEGzwHwpVrmadiAV")) {
        for (int kwCOPM = 1975622817; kwCOPM > 0; kwCOPM--) {
            MjyfeOgqSrp += MjyfeOgqSrp;
            MlPrLNB = MlPrLNB;
            RXTHQLniTMbXqccA = ! RXTHQLniTMbXqccA;
        }
    }

    for (int baUnQsEUIQ = 258275920; baUnQsEUIQ > 0; baUnQsEUIQ--) {
        MlPrLNB = zcOTkAJcR;
        RXTHQLniTMbXqccA = RXTHQLniTMbXqccA;
        MlPrLNB = ! uGZGPvfr;
    }

    return UQoKxG;
}

int YOzGKDuFB::TbXxPvXj(double OSSwwmpMetOOZM)
{
    int DczNzgBo = -1221736372;

    if (DczNzgBo >= -1221736372) {
        for (int xkHRMetyKpnIic = 1972830928; xkHRMetyKpnIic > 0; xkHRMetyKpnIic--) {
            OSSwwmpMetOOZM -= OSSwwmpMetOOZM;
            OSSwwmpMetOOZM = OSSwwmpMetOOZM;
            OSSwwmpMetOOZM = OSSwwmpMetOOZM;
        }
    }

    for (int YGHndRDqCRIZ = 326383783; YGHndRDqCRIZ > 0; YGHndRDqCRIZ--) {
        DczNzgBo -= DczNzgBo;
        OSSwwmpMetOOZM -= OSSwwmpMetOOZM;
        OSSwwmpMetOOZM /= OSSwwmpMetOOZM;
    }

    return DczNzgBo;
}

void YOzGKDuFB::ldZZb(double iSyZuv, string sJWBQNnDhC, int HuXCzuy, string AVveDUdGUnhy)
{
    string NJAKUJhjSc = string("fZzABsAJyTAXeYBZEzcXBLOugBilCVGREKhkyHEZmkBKWjonPkkylJpChLlvQOfNEPNhlLSZdVhTJPawaNhxCxEOHYtNmGHcCNfFPxdEZjOcYxqINYHhQHFnpgbReGuICJoIGQzMaqCPiUgrCruEDBEPWXlRcGXVALhfgqpIEByEGmNfWuUokfVrGzohdBhNWXEjpWgLVZ");
    bool BfpKYFlqesyhB = true;
    bool fJjNuzrtJrAi = false;
    bool ZnexpQJPnTOX = true;
    bool rSFhdYIPLnjur = false;
    int AbwaMAn = -765394672;
    bool MuQwxOfKWCsijGz = false;
    double crfwrn = -891937.712261322;
    string qfTLXofNiufm = string("wyl");

    for (int pithuWtMXsN = 662381841; pithuWtMXsN > 0; pithuWtMXsN--) {
        MuQwxOfKWCsijGz = BfpKYFlqesyhB;
    }

    for (int oCDTGsMGyTk = 1034167720; oCDTGsMGyTk > 0; oCDTGsMGyTk--) {
        fJjNuzrtJrAi = ! BfpKYFlqesyhB;
        qfTLXofNiufm += NJAKUJhjSc;
        AbwaMAn = HuXCzuy;
    }

    for (int obzIOaTqma = 66908156; obzIOaTqma > 0; obzIOaTqma--) {
        crfwrn /= iSyZuv;
        AVveDUdGUnhy = qfTLXofNiufm;
        rSFhdYIPLnjur = rSFhdYIPLnjur;
    }

    if (rSFhdYIPLnjur != true) {
        for (int ckpgLAttK = 2146501500; ckpgLAttK > 0; ckpgLAttK--) {
            ZnexpQJPnTOX = ! MuQwxOfKWCsijGz;
        }
    }
}

bool YOzGKDuFB::XAdFryOQbcxvVFsh()
{
    bool maZgNJLEUkvx = true;
    int AuDNWqCApIysLrcJ = 426937370;
    bool ftLUVv = false;

    for (int hVXtyCEwYnni = 630125476; hVXtyCEwYnni > 0; hVXtyCEwYnni--) {
        maZgNJLEUkvx = ! ftLUVv;
        ftLUVv = ! maZgNJLEUkvx;
        maZgNJLEUkvx = maZgNJLEUkvx;
    }

    if (maZgNJLEUkvx == false) {
        for (int UhfIUVcKiSGqqU = 1911644394; UhfIUVcKiSGqqU > 0; UhfIUVcKiSGqqU--) {
            maZgNJLEUkvx = ftLUVv;
        }
    }

    for (int KmfDBCCX = 888631981; KmfDBCCX > 0; KmfDBCCX--) {
        maZgNJLEUkvx = ftLUVv;
    }

    for (int PWFLZoWijjASnbK = 454731779; PWFLZoWijjASnbK > 0; PWFLZoWijjASnbK--) {
        continue;
    }

    for (int RryESYNTweEp = 926615793; RryESYNTweEp > 0; RryESYNTweEp--) {
        maZgNJLEUkvx = ! maZgNJLEUkvx;
        AuDNWqCApIysLrcJ += AuDNWqCApIysLrcJ;
        AuDNWqCApIysLrcJ /= AuDNWqCApIysLrcJ;
        maZgNJLEUkvx = ftLUVv;
        maZgNJLEUkvx = ! ftLUVv;
        AuDNWqCApIysLrcJ = AuDNWqCApIysLrcJ;
    }

    return ftLUVv;
}

bool YOzGKDuFB::kDytziuPGhb(string GMLqGTKt, bool ipKLdqAahNGACJw, double scCnB)
{
    string dWNBMjFWKnsGs = string("eZrGkaaholcISHZFAydbUQwCPDyoDQPAkcHmXxtRsDwBkAQJRvYNbuTxFjruKGIaBqJrKvCwecKXwLhYsKEPcrBRBHcclIsHIOzpaQBtbpJxNYPITYtGykYSTGUfnQIFPSjULCCZyCwHYZhCbDYfMdFjyXSvHXrVliZhrmBtALZaqnUQsaGdFHKXsFxeaVssoadDvyzrNeYJif");
    int NWujvyhSZuE = 1353092854;

    for (int FWezE = 2100065920; FWezE > 0; FWezE--) {
        continue;
    }

    for (int vzoSSDdGuDKNnhFn = 576353960; vzoSSDdGuDKNnhFn > 0; vzoSSDdGuDKNnhFn--) {
        GMLqGTKt = dWNBMjFWKnsGs;
        GMLqGTKt = dWNBMjFWKnsGs;
        dWNBMjFWKnsGs += dWNBMjFWKnsGs;
    }

    if (dWNBMjFWKnsGs > string("VRRszazWgchaAtEEXFBEpViDlVREhdsmFFyMuysvpTryqrTljXSbgVYtaxlQKQbMNaHiKWUOGYOlUkwHkkMjLBGWTIsKltcpFSixzvZTwOWzpuCqHvLzJcOfHNNMfBjKAZkrwNAicFehTpYJtlkKQIHoEJUOQVbadDRtarwCjEiRVmzLQbJLZGMrutZitnTbEveoUfAUJHUQSgYeZAembvQJmbaZgErtNuAj")) {
        for (int kCfgEvynqeu = 895126723; kCfgEvynqeu > 0; kCfgEvynqeu--) {
            dWNBMjFWKnsGs += dWNBMjFWKnsGs;
            dWNBMjFWKnsGs += GMLqGTKt;
            dWNBMjFWKnsGs = dWNBMjFWKnsGs;
        }
    }

    return ipKLdqAahNGACJw;
}

string YOzGKDuFB::XhaEzjBdy(bool jidtm, string kxkiRrqdl, bool RUwHoThiEbK, int SFADg)
{
    int OpjGwmwFUeLlwmw = 961699115;

    return kxkiRrqdl;
}

string YOzGKDuFB::RsxNMTzTwEcGV(string Elouyq, int jQaGUumMhu, bool TQUJafWVYQGxr)
{
    bool niGOOMMPUaA = true;
    bool CYumLbacpxVAAcXA = false;
    string GwuBfyOfWnOQb = string("xKMJKjizgKAWKwNgYUxPEWzIbwFsaKvkOxMSGLUzHmMiNDyZkmiZQEDnHbtZyzsoUhvwMSCULNIiRzySAcUxGQkTRkUogvWiVrhvDybMSTDuoKdAvoSUyAXiBYOLhQrOgFtIYAfrzyuTWffEaLsmdOgWN");
    string LJLdTF = string("jqNDEqTfwzAZyaeQcevRETuqwmzrHLJEtIEOypBkdHwMAcgVHTLkeOTvsuniLyQblesSMgnWIpyZQYGhHGFMOyjOikZJciMuktFcJU");
    double CkIKJHirdLKfKqd = -111714.82934324181;
    bool vukVI = true;
    string CrsNMIwJtzfYCV = string("RizovkldsorAFgwmOdXQsbFjvHBTJOxFpIPHAUMqANKrklzjFaMdgjxWvfnwbUDFpSIfHrLdQlPIbGSDxfLcQwXheDpzrFaEWrbkWhJjJyBbhTZHHnbHDscqIJAGXgwcLriaMXNnExpLCMgohrhkSLBnZEyg");
    double LIJdcTAVkabQ = -42433.93353516683;
    int BLTtj = 1656723482;

    for (int SKkzg = 1623638559; SKkzg > 0; SKkzg--) {
        continue;
    }

    for (int nqOSMZdYsji = 992665200; nqOSMZdYsji > 0; nqOSMZdYsji--) {
        BLTtj += BLTtj;
        CkIKJHirdLKfKqd = LIJdcTAVkabQ;
        GwuBfyOfWnOQb += CrsNMIwJtzfYCV;
    }

    for (int jniLfcqKpG = 1137932048; jniLfcqKpG > 0; jniLfcqKpG--) {
        CYumLbacpxVAAcXA = TQUJafWVYQGxr;
        GwuBfyOfWnOQb += CrsNMIwJtzfYCV;
        LJLdTF += LJLdTF;
    }

    for (int YWMJHd = 1010567744; YWMJHd > 0; YWMJHd--) {
        CYumLbacpxVAAcXA = ! CYumLbacpxVAAcXA;
    }

    for (int wfyKnUqAjxAf = 1597464105; wfyKnUqAjxAf > 0; wfyKnUqAjxAf--) {
        vukVI = ! CYumLbacpxVAAcXA;
        CrsNMIwJtzfYCV += CrsNMIwJtzfYCV;
        LJLdTF = CrsNMIwJtzfYCV;
    }

    return CrsNMIwJtzfYCV;
}

int YOzGKDuFB::UiJKyWDrKHqAEmD(string iWTsGKzFs, double OPdwVfdRwwb, bool OmzJK, int QaOirfQHLvPK)
{
    bool GWWwQQPUzmau = false;
    int TWbELuBEvOyNQVdl = 1550140375;

    for (int ercFlpSAgtM = 762724356; ercFlpSAgtM > 0; ercFlpSAgtM--) {
        GWWwQQPUzmau = ! GWWwQQPUzmau;
    }

    if (GWWwQQPUzmau != false) {
        for (int jJIJTczMrNx = 499715116; jJIJTczMrNx > 0; jJIJTczMrNx--) {
            QaOirfQHLvPK /= TWbELuBEvOyNQVdl;
            OmzJK = GWWwQQPUzmau;
        }
    }

    return TWbELuBEvOyNQVdl;
}

string YOzGKDuFB::kxzgLSIJNuC(string QSwzSnAkKFVn, double CbhBRFpCu, int ZtJnbeYH, string jWGBtiuy)
{
    string rwIBydL = string("cPgHDrLrmhIkRddAtzvnqDIMQHhazTNncNLXHgTuoRvGnvGhUwNkWWmvWmMLIOCvbMNjWXAWETagJZixoDfWIZXcZRCVtWeZBJlHTaFFDLPcvEEOOnDCoXFYrAbYLcR");
    bool yNEnSvK = false;
    bool CYuGuqAyuBi = false;
    double QSWFXSHVqkNaOpaL = -316352.0603695041;
    double WJiyAQXCXERrRdWh = 614955.8373618085;

    for (int cmKmFCmUjk = 1076849210; cmKmFCmUjk > 0; cmKmFCmUjk--) {
        continue;
    }

    for (int SXRxxBTbxcs = 594109665; SXRxxBTbxcs > 0; SXRxxBTbxcs--) {
        CYuGuqAyuBi = yNEnSvK;
    }

    for (int ExUXMjG = 937257312; ExUXMjG > 0; ExUXMjG--) {
        QSwzSnAkKFVn = QSwzSnAkKFVn;
    }

    for (int LfXFMbtSOWfbXOt = 799687844; LfXFMbtSOWfbXOt > 0; LfXFMbtSOWfbXOt--) {
        jWGBtiuy = QSwzSnAkKFVn;
    }

    for (int HXEAs = 1480079129; HXEAs > 0; HXEAs--) {
        WJiyAQXCXERrRdWh /= CbhBRFpCu;
    }

    return rwIBydL;
}

YOzGKDuFB::YOzGKDuFB()
{
    this->WRpZk(string("bmLtzqIcFPammgGKsVeWcWWYuaAXhLsljqFaaVVbsLngrWUvblictBHxTagDnnQoIoVzuPMkapEebEccDoaoodxmVHVIhJwyMUiUgPLEXJrcRTpObpcBYeimaJkjLRXjOSqjkfMNj"), 221284.653708394, 988839.7817415037, 691564.3832897521);
    this->TizNrjfHRBG(1967788571, string("IQAiBVSsgIwBEOvqFlWhxYxBQlJxKohyDWdAqIYPxRSVHeOOxiditEGJWzKeURUsJIJZQdlKJwSNNGUJvMLbT"), 89848.95575247008, string("wQafOigPSpVXqXYSprveclhwBPyOLnmmbTgOZNQoljtJjhcwWOrShWXINvMDgNFZKZTIoThFzuduYbcUBIKMpoGKcFGHnjqlPxfOHmLWTxJLncRbxioKmBqBjhmooIuJgFltZHbvOXSHg"));
    this->PgdNXMQlsP(false, 30787.873480640967);
    this->qcvzWZxnaxOupo();
    this->HcgsTKcqCj(false, string("bjeKTyUFpsDbYNBxNoABIGRWyBKIvzVlFdfTSmeHiSmqHiARkirgGbZlmfiHbSNZrQSxgYXSphgDJNUQCXTIUcEAQkCpQxfHlyjhGBXcOSgrHEJsahWYXJRIIwvFpKjij"), string("CxxFwNIgHegBDshRAiFCZSDCxBtjOwRrXtRKDqIlAkwQeKdMdvuizxfhuUprFAqDCbGauCvTSYgPLsmexYWwenMYuSWWllPrObsqquygKpPHEsNmzZdFvGJSIcnMoldEGUdCRnZDrzdSOHnMTNSpmJYUo"), 172863432, string("fKLJFMhJKiHFDRdtrhjfKpSvnUrHUjGhyZtWgiFsOrzsVFqkllGKXbrkLSsiiNOIbUuIQtLyeYuKsfPYbKaGmvgWVdPNhAWCwvdkPCARXVHs"));
    this->IDlfGCnOo(string("WYoNIIlEJXEmQMFcypsXBzDIbVcUBLwQuabEWRFrmGsNPCpNyYpFHyDVjCqyTInJBJuwnwCuSDHxmqQftVZXjIMAmVqJpUnrUYGRfZWFeESUdZEvGvnDuBWmqTujywsArruxsTkPqCyKGedFFgiCDosONnSVTxTjThMZoRFaaKGJtWlJVBBrSeWThOcklwbwwBOcuCqnviBp"), 1303975459, 957340.2213561807, -1752688672);
    this->vwHcJFninPnwZfmE(true);
    this->OVeOry(true, 453420.78262452956);
    this->TbXxPvXj(-379579.4613312132);
    this->ldZZb(-395313.73116040527, string("zuKOCQHH"), -149033805, string("hXHXVgbTbwTpxIrFetXFhJleXsulVRpOFkzOODgAnqhMbuBxbEqLWLvsRRPoAHUugPNsCYefQddOzjHpHMGjcPlvpviMKVwnNJobRBJmIaayydJhsclFzUpzwSjIIEQceLbCvjuWcQxneVnkYtDLYMJVRWKDXAcyEKOVyWHOIYuSqBfPaRGlyvPhTQilBMgIBCkfpULAzpnLFeCpXTlraHnjDkOGVwQfVFKmVuxEmDSDCxtpoBoloudKSxQBrz"));
    this->XAdFryOQbcxvVFsh();
    this->kDytziuPGhb(string("VRRszazWgchaAtEEXFBEpViDlVREhdsmFFyMuysvpTryqrTljXSbgVYtaxlQKQbMNaHiKWUOGYOlUkwHkkMjLBGWTIsKltcpFSixzvZTwOWzpuCqHvLzJcOfHNNMfBjKAZkrwNAicFehTpYJtlkKQIHoEJUOQVbadDRtarwCjEiRVmzLQbJLZGMrutZitnTbEveoUfAUJHUQSgYeZAembvQJmbaZgErtNuAj"), false, 138408.4692247718);
    this->XhaEzjBdy(false, string("mPHJYzNsJrsMuKyoLQgoimkIwVtGXhbUvnxXlmWhZIhIPtrOpoImDEmkfVTjeapkShcGcxxZUcVrYKYoEzuWzKYKzbBxLqJiwleNBvRRBEHJmNmkfEnovLoJpGLEUHegLPkoEtPUymbBVtLEzPqaFPMZbNeYhAXQLUSXRqLIzKsFOWUhNlCuEhKUU"), true, -333911751);
    this->RsxNMTzTwEcGV(string("kZrgsRdMJPzKpLwlgWbe"), 1049808868, false);
    this->UiJKyWDrKHqAEmD(string("yAaffVnRCKWydkutnThNzQVDsmECGHRKzQRkZrzuvcKSlpyIEyzBLvMhCkhhXZTxeVuXyYnozGrQtYSgCPtPnNqWvzNGYcvFNtdLdxvwrZaDoYVytlEoaQwWayBKHxJGWxMlNkwWXEhNMKyiVGOugMREZsWhBqXurOmKBfyxylCnWLQgAMLpmsHKL"), -137702.08262171416, false, -1929496903);
    this->kxzgLSIJNuC(string("nPiClBlNPHONTcdwYGHcZGJoCRmDNQqWPkBvKfZakEZBPvZJxqBBFQhXbRggRnFcNkHBVatVRsXVQCzDFPeFlmCezXDIOXnNZfzIYzHIrRgWwKLnHqKLODEUOiCxtSABRLwlRaNbwwonwiDfuRzOzLHbrmCQveRbrHDazKZLhmQpcvCasayGefyzbnmmtkSKQLJdBbfvAbgXWCdOmBnQyIxNCWRpOkkhuopTgV"), 552496.1448726525, 1562971043, string("ZGhfVKzDSVGqcoznWrBmFkXMAOylmDJNMxTzQyDJGXoibHWZZLXsqISYCCXduvaWHAjlvukQZfjzjeYaCjswMbqZMwnZyKAVqFaFISybPDjvesZIqqYktCwGwQmsqJEDGXLOEEHkwpTJPqABxmpntZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CBgveMxQagz
{
public:
    double buCoGYcQbA;
    bool rhdvumbmzyt;
    double OgRqlNVfb;
    int xVumQ;
    int VinhBDbGWnCmqigh;

    CBgveMxQagz();
protected:
    bool ZCttiwA;
    bool mnLLNUnaZAVRW;
    bool oOHFNEjf;
    double xIPeHNVUJ;
    int XITszxM;

    int mAdVgtH(string CbgptnXMDH);
    void uozTMZvBojFUWQIl();
    int TTRoHHRdssHl(string beDgPnR, double cECwswYd, double shoIoFrAb, string pxCykmSpgtv, bool tKQQovMvDzZLI);
    string xjQSpmVRCj(bool PlcpCoW);
    int bULEVtD(string xABob, bool SvXrijZqTXpIKUS);
    double NkzmOBEsDLzAPJ(int CxQrYCIeREGODK, bool eMLuswanRLjORMM, int WWfos);
    void KgDLmM(int yFbOBtbO, string UAeCjdAaUxmjoP, bool DKOXojRHdZ, bool yFmEAerwqYQ, double RSMBq);
    void UKDOaScV(bool xpuNRmh, string CjUmLWpKSb);
private:
    bool KjykQSGFZUvuTaU;
    string oAqbmqjDV;

    int ewDEhaeOMaWmt(bool axLJkZqdKx, double CMNWo, int eefRFofn, string kiUimWiKCqUI);
    double xeGORsk(bool qGacVyflgf, string RxAPazZj, string IZXkZlfAK, double ncjGzYLSGavqJk);
    double YiaqVyKB(int gruxz, double TjNrbVeqPYd, string cECUwP, string nlBEQdg, double VfTvZX);
    double teatiBuEy();
    string WglcxwWwDp(bool JBKLmrKIZSKU, int EKoyMxRPhElsmQB, double ThmhHH, bool IlZAS, double DYmlEWvYENh);
    double EiPPUou(string PEHwl, bool XsaYoK, bool fdRcRUEYry);
    int UiEKw(string qWEsBiwl, int jVXZqyUh);
    string DQdfCW(string iBJaTw, bool hSEJYYumv, double TBAjkBgzaw, double TsDYxASfV);
};

int CBgveMxQagz::mAdVgtH(string CbgptnXMDH)
{
    bool nKnTP = true;
    bool UkePdef = false;
    bool DPxPsm = true;
    double BouDLT = -539987.9671190672;
    double pgLmFubGjAmsE = 87559.07292918555;
    string UkUVuYUxwif = string("lsvguRhXnMQgRycfoxCeudwFoAopVXMxaTcUlcmVtJPHfgHUyzzTjprGGXogazbiaLbrNEpzOLQCBvLLcbDjWIEWziCxneRsiYgPmaAaWAsokBljnoFQEnxwCXqBQWmXkJeescqckhQNXeAoCaymGbfdFMzosaOreFAPpFaZvoiCjCXQI");
    string OLRrbkLvmY = string("DQbeuFGiInktovlynkSdvUiAiBJKgKWaCywjREavQHvFTrzvpLvqtljRXSKMNrziuBXliSeZRCKpIZTkfPHnmsjtwEFriKbXgEBnYLxLzLwzkEValDJkzSNDw");

    if (nKnTP == false) {
        for (int vBNEVqTGnHrO = 389028754; vBNEVqTGnHrO > 0; vBNEVqTGnHrO--) {
            nKnTP = UkePdef;
            DPxPsm = ! nKnTP;
            UkePdef = ! nKnTP;
            CbgptnXMDH = UkUVuYUxwif;
            pgLmFubGjAmsE *= pgLmFubGjAmsE;
        }
    }

    return -2119166222;
}

void CBgveMxQagz::uozTMZvBojFUWQIl()
{
    bool hAyKlLc = true;
    bool GoJMJVXJP = false;
    int dofSBpoHvgL = 1808870453;

    if (GoJMJVXJP == false) {
        for (int EeswrIWepGvq = 927641536; EeswrIWepGvq > 0; EeswrIWepGvq--) {
            GoJMJVXJP = ! hAyKlLc;
            GoJMJVXJP = hAyKlLc;
            hAyKlLc = GoJMJVXJP;
            hAyKlLc = ! hAyKlLc;
            hAyKlLc = ! GoJMJVXJP;
        }
    }

    for (int APUVsyDYIMwz = 374526415; APUVsyDYIMwz > 0; APUVsyDYIMwz--) {
        GoJMJVXJP = GoJMJVXJP;
    }
}

int CBgveMxQagz::TTRoHHRdssHl(string beDgPnR, double cECwswYd, double shoIoFrAb, string pxCykmSpgtv, bool tKQQovMvDzZLI)
{
    double gDmIl = -882362.5773469794;

    if (gDmIl <= -418437.007021563) {
        for (int MtdOxsNcVMGs = 1974139774; MtdOxsNcVMGs > 0; MtdOxsNcVMGs--) {
            beDgPnR = beDgPnR;
            pxCykmSpgtv = beDgPnR;
        }
    }

    for (int TpHlqZgOrsak = 1082548806; TpHlqZgOrsak > 0; TpHlqZgOrsak--) {
        continue;
    }

    for (int JfXDeSV = 1162107825; JfXDeSV > 0; JfXDeSV--) {
        gDmIl -= gDmIl;
    }

    if (gDmIl == -295580.4481696567) {
        for (int ztShPoFbQEwZd = 854414187; ztShPoFbQEwZd > 0; ztShPoFbQEwZd--) {
            tKQQovMvDzZLI = tKQQovMvDzZLI;
        }
    }

    return -39888129;
}

string CBgveMxQagz::xjQSpmVRCj(bool PlcpCoW)
{
    int RYiBpnZwDKbN = 518581078;
    string ltMfcFojQQMv = string("NVUpbsjZOQPJLfBxQEccSAwHLLWGFzDBeeGsYGUYKHTxkxVukCaaskVclzbEBsaqNdJgwlqUlRyltRAyHsLkztUUleTvKLColNdamWADbfnfBEwKkCSLhMbRrrpkZOUvqcZZlQFulmPWEXTpTWroTrAsISXNuqucgBOmXUZeRQDDbETeeIf");
    double WzWhlLmupFx = 254537.27594036807;
    double unQhryxuuveoDrBi = 734326.1591745295;
    double gYzKbFIkJGLV = 852859.7725406754;
    double SzbtngychojyPcaM = 1008742.6786539265;
    int JUGXHG = -247567748;
    string ELLDskzvyDFsUrr = string("pgaQCmdmlNAoqHFiArXHontwEJOhmdFaJltDindb");
    bool eqSLFmxfoKIq = true;
    double EYHwJQuCmjFRQ = 729316.2378598966;

    if (SzbtngychojyPcaM == 734326.1591745295) {
        for (int JoPnDhwInT = 1976600197; JoPnDhwInT > 0; JoPnDhwInT--) {
            continue;
        }
    }

    if (PlcpCoW != true) {
        for (int iYQVofiQV = 2081360452; iYQVofiQV > 0; iYQVofiQV--) {
            EYHwJQuCmjFRQ += WzWhlLmupFx;
            ELLDskzvyDFsUrr += ltMfcFojQQMv;
        }
    }

    for (int FaHVPhmdOzUlr = 1341495974; FaHVPhmdOzUlr > 0; FaHVPhmdOzUlr--) {
        EYHwJQuCmjFRQ += unQhryxuuveoDrBi;
        JUGXHG = JUGXHG;
        EYHwJQuCmjFRQ -= gYzKbFIkJGLV;
    }

    if (unQhryxuuveoDrBi >= 729316.2378598966) {
        for (int QFZkbTUwUvjOcSQ = 1070714523; QFZkbTUwUvjOcSQ > 0; QFZkbTUwUvjOcSQ--) {
            unQhryxuuveoDrBi += EYHwJQuCmjFRQ;
            JUGXHG /= RYiBpnZwDKbN;
        }
    }

    for (int btCaJdEWqV = 1605615010; btCaJdEWqV > 0; btCaJdEWqV--) {
        continue;
    }

    for (int gMebvyLoNikohKnI = 1076953511; gMebvyLoNikohKnI > 0; gMebvyLoNikohKnI--) {
        gYzKbFIkJGLV = EYHwJQuCmjFRQ;
    }

    return ELLDskzvyDFsUrr;
}

int CBgveMxQagz::bULEVtD(string xABob, bool SvXrijZqTXpIKUS)
{
    double bLxywnOQa = 367377.772642412;

    for (int WDccfOcU = 416798989; WDccfOcU > 0; WDccfOcU--) {
        xABob += xABob;
    }

    for (int yfbltcR = 9480732; yfbltcR > 0; yfbltcR--) {
        continue;
    }

    if (SvXrijZqTXpIKUS != false) {
        for (int YtAttet = 1388296016; YtAttet > 0; YtAttet--) {
            bLxywnOQa += bLxywnOQa;
            xABob = xABob;
        }
    }

    for (int FxsGCWRvm = 1246074160; FxsGCWRvm > 0; FxsGCWRvm--) {
        bLxywnOQa = bLxywnOQa;
    }

    for (int CIYMAgvEXDhP = 1779989694; CIYMAgvEXDhP > 0; CIYMAgvEXDhP--) {
        bLxywnOQa -= bLxywnOQa;
    }

    if (SvXrijZqTXpIKUS == false) {
        for (int kTZZCnoaMx = 658340073; kTZZCnoaMx > 0; kTZZCnoaMx--) {
            SvXrijZqTXpIKUS = ! SvXrijZqTXpIKUS;
            bLxywnOQa += bLxywnOQa;
        }
    }

    if (bLxywnOQa >= 367377.772642412) {
        for (int OxMUiNiMMGKeWJx = 2065584431; OxMUiNiMMGKeWJx > 0; OxMUiNiMMGKeWJx--) {
            SvXrijZqTXpIKUS = SvXrijZqTXpIKUS;
            SvXrijZqTXpIKUS = ! SvXrijZqTXpIKUS;
        }
    }

    return 1085458019;
}

double CBgveMxQagz::NkzmOBEsDLzAPJ(int CxQrYCIeREGODK, bool eMLuswanRLjORMM, int WWfos)
{
    string yqzhVrG = string("rwhjGzTqrAdgwCYFCGtCdwDlLjqCuhxkSCxLhduoOeUZOBEPwDNZtPEHmcYX");

    for (int sLItpsmOfIeiV = 2072804522; sLItpsmOfIeiV > 0; sLItpsmOfIeiV--) {
        eMLuswanRLjORMM = ! eMLuswanRLjORMM;
    }

    return 623216.3744717075;
}

void CBgveMxQagz::KgDLmM(int yFbOBtbO, string UAeCjdAaUxmjoP, bool DKOXojRHdZ, bool yFmEAerwqYQ, double RSMBq)
{
    string OiQog = string("uHuAbtxDMiSCsxaCMAXpmaWMfGhGMYipRDoNXarwcrGllGcTYWSvQhFUHzXdXXvnbqTBbJfEZeotibXnVlryipJyfsvGZWnwqZiFnAcwqePNhoIGDcQobbxKbqzzBsCVVLVvmmiuQDkEQMCNjkKvoOiBObWgVCIskJMJkVEYacqTFdGUnDXaJLHqfuOvZyzwPlVVaeEvOIPvMKUtRzb");
    double ynyzSXZLszxqeX = -638115.9541010772;
    string nMbjmvTRJl = string("byoXmCZIKZyXlVyLKrobIDyHRiGWZFLosZhrlRHGJXwQxOYfCeBCGwRqNweETvasZuQiuDSmoFNKjUpRhYiBmATBnaUwIEZIhdlPdCBmPphVFgIpBxNrqXhIiksRCcUDrIpIBhJbcZPttqurnfaBcZQOokaWvchJVcYAchNFcBGgMGoPthBkLiVWynJrPAxiOjSGaYforpyOAxULhWWrSRqkuQJumvhthjOhaVuwIUmg");

    if (yFmEAerwqYQ != true) {
        for (int bRIOdpJja = 1373471739; bRIOdpJja > 0; bRIOdpJja--) {
            RSMBq -= RSMBq;
            UAeCjdAaUxmjoP = UAeCjdAaUxmjoP;
            ynyzSXZLszxqeX /= ynyzSXZLszxqeX;
            RSMBq *= ynyzSXZLszxqeX;
            UAeCjdAaUxmjoP = UAeCjdAaUxmjoP;
        }
    }

    for (int RrpwEYvNuTQXlV = 319697202; RrpwEYvNuTQXlV > 0; RrpwEYvNuTQXlV--) {
        continue;
    }
}

void CBgveMxQagz::UKDOaScV(bool xpuNRmh, string CjUmLWpKSb)
{
    string orkkHAE = string("lsEtzOLlOXRsGMMCLzKugjalnYvwTcKaivPBJptInSarLvYvlCLmHaRToejyiYeodhqVCWsjqJNfjiuqoItrlqjkQpJZOHLRNZjYnDLLaoiEBidujDUDBJDDTJVkd");
    string kYSBluJwXIfyw = string("boAOvCmsKzfloOVajTsRvdGOQnsyQAtNMSdtvHwyyOAfClyjMvnuZxfOnGxIOtCLKYxRYluYgStBjrDJDHUxoykIdcyWxnnPVkDMWSftDWlComJuQJUaaJ");
    double gNcoOtWEzQiMuFYI = -1009077.6590324147;
    bool XnJKNWkiHT = false;
    int JUARabikh = -238537324;

    if (CjUmLWpKSb > string("xzcXFcSsFmQTctRgfmpvMLGYSVytEQAuAmyEZvhHJsuJHMQurzsbZdhbHKFsokgHuhsvxDREFVvRrWytrmFbvHUbaVUYHoeCKugQMUQSbGaSQmiaQTJcQngHJFTxvmTxOYMICWjOtgTpkQuFGTHRzvBxcaOEoFVhbIXNuLaNeoewneaqfGcvFbNTkhGpOKiXlFWtUTlPvljeRYrCBBxJppUzEWjGFmmhcUUoWKjqYhLRvflkJYVMDz")) {
        for (int xKhwdLSCcjU = 1116890471; xKhwdLSCcjU > 0; xKhwdLSCcjU--) {
            continue;
        }
    }

    for (int mxWxvuXp = 2072400391; mxWxvuXp > 0; mxWxvuXp--) {
        XnJKNWkiHT = xpuNRmh;
        xpuNRmh = ! XnJKNWkiHT;
        orkkHAE = CjUmLWpKSb;
    }

    if (CjUmLWpKSb >= string("boAOvCmsKzfloOVajTsRvdGOQnsyQAtNMSdtvHwyyOAfClyjMvnuZxfOnGxIOtCLKYxRYluYgStBjrDJDHUxoykIdcyWxnnPVkDMWSftDWlComJuQJUaaJ")) {
        for (int BGeUhnmywHwTlAV = 629571932; BGeUhnmywHwTlAV > 0; BGeUhnmywHwTlAV--) {
            xpuNRmh = ! xpuNRmh;
            orkkHAE += orkkHAE;
            kYSBluJwXIfyw += CjUmLWpKSb;
        }
    }

    for (int LLXoiJjntOgFhiZ = 278484814; LLXoiJjntOgFhiZ > 0; LLXoiJjntOgFhiZ--) {
        orkkHAE += orkkHAE;
        JUARabikh /= JUARabikh;
        kYSBluJwXIfyw = CjUmLWpKSb;
    }
}

int CBgveMxQagz::ewDEhaeOMaWmt(bool axLJkZqdKx, double CMNWo, int eefRFofn, string kiUimWiKCqUI)
{
    int VBUpeJxgpJoQxL = -425297127;
    double dbmaHVfGm = 863816.407159096;
    string GvNZvHkcjWgWda = string("GJofMnddvsgKppSbAHDipcFwqCyoyouFQHqonT");
    int xIjXRvWjsQsAibo = 621466196;
    int yQTvQXHUy = 1673738468;
    string oIOKAuiwlWS = string("JzIhdpypYsynHbzcsyklQXkkROOhFpisqmecEjaWdLxWKRqKtJZfpcUMpePvIJZtflvAbMZCcyqCDAwBEkcBeNkvDwIhsyzQRpaTMfcdtFYjdPzdGvFVFcBxvycLuJdKdRwfhBimqkkFazNirkvyZSVKbO");
    int JhqNFXynNjNPza = 450868236;
    double nmEhnLqCIRdnFDRe = 1031930.9368757836;
    int TYAvLLLvlz = 738533645;

    if (xIjXRvWjsQsAibo >= 738533645) {
        for (int AwsnTLcneDeH = 179533759; AwsnTLcneDeH > 0; AwsnTLcneDeH--) {
            continue;
        }
    }

    for (int IuWxKMFlH = 1972291312; IuWxKMFlH > 0; IuWxKMFlH--) {
        xIjXRvWjsQsAibo /= xIjXRvWjsQsAibo;
    }

    if (TYAvLLLvlz == -425297127) {
        for (int IqBrByAZlqaLcTT = 1250167835; IqBrByAZlqaLcTT > 0; IqBrByAZlqaLcTT--) {
            JhqNFXynNjNPza += xIjXRvWjsQsAibo;
            TYAvLLLvlz -= eefRFofn;
            xIjXRvWjsQsAibo = eefRFofn;
        }
    }

    return TYAvLLLvlz;
}

double CBgveMxQagz::xeGORsk(bool qGacVyflgf, string RxAPazZj, string IZXkZlfAK, double ncjGzYLSGavqJk)
{
    double EWEsSoYSI = -945921.3700272458;
    bool TIZYTWFjqwLIbMbu = true;
    string LloNZsmrs = string("xoxGybkwLAPLJEgzIziXQiJegVLXxUprvrMLKhGrbDNVUDZLKLARUIqviBBQcDRkcMaJJIcuWXvoxddJnCunPwfoGExinhTOHiEDsXZKFVgZJCnwKxPFfyVuspoNjdLjBUMNAHsbcUJOJNxuLvsKIejcXxJElgfnbEPpuiPOjOfOWwrzKLqzVMFexYfhCwEZIgtANgFggyEIeNJcrkTscqLYaQwFZqSruYvng");
    bool cbdICvOj = false;
    string AYBWPHfx = string("RuIKEFlqKvZAMGmaBGEFbmkjgpFuKXdzRJnfPchFkkhtIEHQxSddSYcasmFhRfQBPdDYagPdbFBSgRqpLWKUmnOdzrOAXPjzZTUXVOQyicWuQlNtvhHjdWvhIshBxuOjqeaE");
    bool bqKTN = false;

    if (IZXkZlfAK >= string("QEhrfTQjOBOWKcxswghwYNGLLtVXxeoJtDwDoETgsZNCEvtaglHniUkAINEMxwJOLHvfnVPPrxRPglINLrQXzxGSSlXxiNmhqcxvwlQERRkLoDpOOgfHMkrYhahPttorCqemqPmJYIsSKAfIJNWsyOwUPSOdjJDaPvigtxwt")) {
        for (int wzaYTVKw = 1974732172; wzaYTVKw > 0; wzaYTVKw--) {
            bqKTN = qGacVyflgf;
            cbdICvOj = ! TIZYTWFjqwLIbMbu;
        }
    }

    if (TIZYTWFjqwLIbMbu != true) {
        for (int vNvdZYfXMlhrnCJH = 1758216344; vNvdZYfXMlhrnCJH > 0; vNvdZYfXMlhrnCJH--) {
            continue;
        }
    }

    for (int JFytDJeuVd = 1400076214; JFytDJeuVd > 0; JFytDJeuVd--) {
        AYBWPHfx += RxAPazZj;
        LloNZsmrs = LloNZsmrs;
        RxAPazZj = RxAPazZj;
        bqKTN = bqKTN;
    }

    return EWEsSoYSI;
}

double CBgveMxQagz::YiaqVyKB(int gruxz, double TjNrbVeqPYd, string cECUwP, string nlBEQdg, double VfTvZX)
{
    string clgsxDM = string("npiMUOEThsXOHntEzcBbSmYoFMoNNaJgofvwhEPxtkJnSxHvGiXvlQaCblwnLEosUaCQhHfXkMoKRqiW");

    return VfTvZX;
}

double CBgveMxQagz::teatiBuEy()
{
    string YRFHBmm = string("hjgpKWpJVldwDYxWwJbqVqJdqmjCySuhAMNAgwbTuORXRyeXzFLnYRbeNCQtYivyYySWvTaPUjleHtpsmXEFWPwKxTKZIzsbkSgrUmvCytTqRYwTXyTkPjNNx");
    bool dahJcKY = true;
    int mQHcGPAPDUPgN = -129282789;
    string qmCQYh = string("MKxLmwMPyvPO");
    int CdslQUoj = 2054330036;
    string udDSdnBDxkTgmZ = string("hhgEwLoaOtibjQWmZDqbcGRXOTIlrtCTuOZTDJTeOjtufOYMkWTIreyGMAsnZkVJkVWTgYdZMHpRaSbknOoNozPIwEpgAAIAdZZxO");

    for (int seeqwoMeww = 41013187; seeqwoMeww > 0; seeqwoMeww--) {
        qmCQYh += udDSdnBDxkTgmZ;
        qmCQYh += qmCQYh;
        CdslQUoj = mQHcGPAPDUPgN;
    }

    for (int htbbezYcIZztCNj = 2014110123; htbbezYcIZztCNj > 0; htbbezYcIZztCNj--) {
        udDSdnBDxkTgmZ = qmCQYh;
        mQHcGPAPDUPgN += mQHcGPAPDUPgN;
    }

    for (int CftwGahtjlSRtvk = 349165103; CftwGahtjlSRtvk > 0; CftwGahtjlSRtvk--) {
        qmCQYh += qmCQYh;
        dahJcKY = ! dahJcKY;
    }

    return -590883.5560083393;
}

string CBgveMxQagz::WglcxwWwDp(bool JBKLmrKIZSKU, int EKoyMxRPhElsmQB, double ThmhHH, bool IlZAS, double DYmlEWvYENh)
{
    int IFtnO = 2038131782;
    double tNNiFJQsCU = -249035.53017520963;
    string deknyhQirFsDpi = string("GNxgeYvUWzjZXgIWyDnruEUMsGGKZobjbztALiRYBUvEPimDwcXMCKbyvPKaQXuxlRjCTZoDjAIoTcQSvMDzqCPbdXFELJboLiscncBjHTINBzgtpurzLlwqrBlSrwrskLsliuxbScOHCtOVuMIvEHuhgmfmggfBNNkFdNBYDqkHKrWjeKSVgcGwCsBhehhQFrjmzolQfoiefiWMmAjkMushHhFIfmlZUxbRaCjOTnwzqpAhxZwNueKpCnEoiHW");
    double KFKmSldpllq = 952314.0661034212;
    string ZGaQVSZgqniiAX = string("mTghJFlbnHwhOpDIPqsTdTKzBcjEQQqawxoXjnAbWxImyzCoLBzf");
    string QAOuenFe = string("lqINziIrnLDtyixSQGZsmTAvDLFhJdvpXEeLjQlqswvSdwRbvtTyxyOoVKimquADoaicXGNrhuVuUzCGZpkzERJzEIEJDwqQJwrHQfroVBaGlUkbVnWNEFkPtAkgtepBkyOzREGsdVrXsCKbsXqSTiaBCktuszmapXJpChSEnBMTHZfCftcTaCWAbCYFPK");

    for (int cyzqysAKeyZ = 934994006; cyzqysAKeyZ > 0; cyzqysAKeyZ--) {
        KFKmSldpllq += KFKmSldpllq;
    }

    for (int kNChBZXkwwJHH = 1933434891; kNChBZXkwwJHH > 0; kNChBZXkwwJHH--) {
        QAOuenFe += deknyhQirFsDpi;
    }

    for (int wxOaEYnlRb = 891583449; wxOaEYnlRb > 0; wxOaEYnlRb--) {
        tNNiFJQsCU = DYmlEWvYENh;
        KFKmSldpllq = ThmhHH;
        DYmlEWvYENh *= tNNiFJQsCU;
        IlZAS = ! JBKLmrKIZSKU;
    }

    if (EKoyMxRPhElsmQB >= 1858184127) {
        for (int PCCTc = 1502180333; PCCTc > 0; PCCTc--) {
            ThmhHH *= KFKmSldpllq;
            ThmhHH -= DYmlEWvYENh;
        }
    }

    for (int TgieMdlLk = 1045030196; TgieMdlLk > 0; TgieMdlLk--) {
        DYmlEWvYENh /= tNNiFJQsCU;
        EKoyMxRPhElsmQB += IFtnO;
    }

    return QAOuenFe;
}

double CBgveMxQagz::EiPPUou(string PEHwl, bool XsaYoK, bool fdRcRUEYry)
{
    double iUEntBIlYTVietLr = 29056.759049447897;
    double fawEaY = 142482.90452225416;
    double rvHqtpafqJji = 762793.0984920493;
    bool SgqnVuYm = true;
    string doFMtUaYYxZzu = string("OPkIdWsqIljiJfAmLJEiOKrqFcwuiZKdNbyLZqUSjkfOEnAXDyRqQNPMpsyavmyuRnLaCnAOrKrKcgkIZqAeYiXvNrJpqYCkWkQtFPmNfLUkctPUUsSPlDdwDcWEqOCZBkFuRPSttGsqoXQJGePtDmIOVeKUSMlQMffIvwScufWPZaQscfaVMaMudqYOkJLiGrybGe");

    if (XsaYoK != true) {
        for (int EEjMnxGQrSDLYwE = 643114747; EEjMnxGQrSDLYwE > 0; EEjMnxGQrSDLYwE--) {
            continue;
        }
    }

    if (SgqnVuYm == true) {
        for (int rUGFzqRHBF = 1864263469; rUGFzqRHBF > 0; rUGFzqRHBF--) {
            iUEntBIlYTVietLr *= rvHqtpafqJji;
            fdRcRUEYry = ! fdRcRUEYry;
        }
    }

    if (fawEaY <= 762793.0984920493) {
        for (int KyJwEbGpnK = 139681119; KyJwEbGpnK > 0; KyJwEbGpnK--) {
            SgqnVuYm = XsaYoK;
        }
    }

    for (int aZXPVOLNjSeT = 1789363145; aZXPVOLNjSeT > 0; aZXPVOLNjSeT--) {
        iUEntBIlYTVietLr *= iUEntBIlYTVietLr;
    }

    for (int HxjqZsyB = 1816245115; HxjqZsyB > 0; HxjqZsyB--) {
        fdRcRUEYry = ! SgqnVuYm;
    }

    if (iUEntBIlYTVietLr < 762793.0984920493) {
        for (int xgzaJUXKdVZaOD = 1780435040; xgzaJUXKdVZaOD > 0; xgzaJUXKdVZaOD--) {
            rvHqtpafqJji /= fawEaY;
            iUEntBIlYTVietLr -= rvHqtpafqJji;
        }
    }

    return rvHqtpafqJji;
}

int CBgveMxQagz::UiEKw(string qWEsBiwl, int jVXZqyUh)
{
    double AYUyeRQsqOx = -1041868.6889541437;

    for (int yPddHfKrZGnmHKWR = 275196829; yPddHfKrZGnmHKWR > 0; yPddHfKrZGnmHKWR--) {
        qWEsBiwl = qWEsBiwl;
        qWEsBiwl = qWEsBiwl;
    }

    if (jVXZqyUh != 1139574112) {
        for (int rQpPKfFBi = 921027031; rQpPKfFBi > 0; rQpPKfFBi--) {
            qWEsBiwl += qWEsBiwl;
            qWEsBiwl = qWEsBiwl;
            qWEsBiwl = qWEsBiwl;
            jVXZqyUh /= jVXZqyUh;
        }
    }

    for (int qIyxsMb = 691230454; qIyxsMb > 0; qIyxsMb--) {
        qWEsBiwl = qWEsBiwl;
    }

    return jVXZqyUh;
}

string CBgveMxQagz::DQdfCW(string iBJaTw, bool hSEJYYumv, double TBAjkBgzaw, double TsDYxASfV)
{
    int KddWOgsOni = -379317690;
    string xzjesJcEnFG = string("wdmMJaIjsvbnyNAcvaybynfGdLmyStvDwJmGnBaMJgOzUoudfHakHVekDIoYlGqGByaXUaSXBPGEHaWclNjkeFxaqbCcRUJpqCycDMwNJAmAnXRzzOnkfaKwy");
    int RuiRDowUGeWMhnsm = -1858865057;
    double miMMCzpdYg = -545702.5078953855;

    return xzjesJcEnFG;
}

CBgveMxQagz::CBgveMxQagz()
{
    this->mAdVgtH(string("CrCjhVLbvZRjtHPtwQNkLONzFAGvorPxwURO"));
    this->uozTMZvBojFUWQIl();
    this->TTRoHHRdssHl(string("MO"), -418437.007021563, -295580.4481696567, string("wlmmAUIQqEzHzDPjOTyIfJvZnEmrhBrLCbgBZGXjeNodxDqFpaWEjAQQOZMCCNKWsZAVozDmsFsWItxzBWjKlIDUkoelCpCSGglaRaEskRtxsaRjvcfkVxMSnVrdJNvjulzKSZJGnBKDbcHYGtSHbrlGYeoZahdKyYxKXvSdiCfLFHLAzQMhcwpq"), false);
    this->xjQSpmVRCj(true);
    this->bULEVtD(string("ErTebMdiucRbYsXWKvSqnbFtKzhkSmCsjCUgkbbxozPVnKyDGLnKGXLXuhOCloHsPFiIxRAIwrjDtfGyLJBHlDIvtpGwTPflAgQPtYNmlxTBRngjaWTe"), false);
    this->NkzmOBEsDLzAPJ(874404514, false, 1726442334);
    this->KgDLmM(267791705, string("sOXPjHLVYFkWvuIPQoGHyWhJSUlSJkMAtlTPqJxZReGbYvrzHtRCrTYfjxZiEAchgFkyJGMUtQJPvezFhkzKhAmZbRTdxVSGfhmpMpEtJihcDyBpVdpPfUHYuVaTbszuCZSsfVVjeOoSvBlqUwyBrAvmQUxlRzzKyEjsGn"), false, true, -70480.53042674513);
    this->UKDOaScV(false, string("xzcXFcSsFmQTctRgfmpvMLGYSVytEQAuAmyEZvhHJsuJHMQurzsbZdhbHKFsokgHuhsvxDREFVvRrWytrmFbvHUbaVUYHoeCKugQMUQSbGaSQmiaQTJcQngHJFTxvmTxOYMICWjOtgTpkQuFGTHRzvBxcaOEoFVhbIXNuLaNeoewneaqfGcvFbNTkhGpOKiXlFWtUTlPvljeRYrCBBxJppUzEWjGFmmhcUUoWKjqYhLRvflkJYVMDz"));
    this->ewDEhaeOMaWmt(false, -322809.74383869005, -1820092606, string("uZodhBFymkaZOoSQxHexstCtHOEDfwJAytuptDWYLmBrgRiyMKEDpbtPynirqrZhrYzShobaxpnsttRrjrzonypzOYwtkWVUQTBuFirOSlVknPtgRwozzXGkPdEFcUiQdnLfcADisLgzKVXbYCFoulqPBFTuLEPUinpbtyKFnll"));
    this->xeGORsk(false, string("UfnJcYqwadBgXSYfspvmCrUxRapbatOLWoYYiYHBqSQheIzdphXyiKfPyAzKAdLXeuFMpelbrzVqCkk"), string("QEhrfTQjOBOWKcxswghwYNGLLtVXxeoJtDwDoETgsZNCEvtaglHniUkAINEMxwJOLHvfnVPPrxRPglINLrQXzxGSSlXxiNmhqcxvwlQERRkLoDpOOgfHMkrYhahPttorCqemqPmJYIsSKAfIJNWsyOwUPSOdjJDaPvigtxwt"), -107.78171439471066);
    this->YiaqVyKB(2102938698, -383340.54367838555, string("hQqHAAYThRjOgJoemrNcmSSeprYyQzVHyEuyQFItcXfESVWXAKUXWGIldnwPtSwHjZKGuTDCdHkzVfkHhSlhfDrQJGgnsTKPcJjnTEXY"), string("IrzUNuZQDtjOZXnKRrliMoOrRiulKihQgnFPCxNyvjfnaTDRJjbOVbmbHIjkNzptzGgeaHPHFideTiTJOslBkviyBEVVZlNHzlDpzywshfumVxBIZKSpnrbXiNWWVGyUuoXFFmhJdBRLooDYELyvlzKqVowybfCmMTSdnXSjbsZQkmROSPqKHelfWkNONQfGUwQfGmGlE"), 106352.21373751361);
    this->teatiBuEy();
    this->WglcxwWwDp(true, 1858184127, 946135.486761599, false, -252965.18426863803);
    this->EiPPUou(string("yLkOtPEEZjlarmWgUCxPcKNECJOPi"), false, true);
    this->UiEKw(string("YfpqitgQUjOfpYlcEOw"), 1139574112);
    this->DQdfCW(string("GHuqPygfMjHMDxgfMLMzVobihIQSvlRQJHkOVhtIjOQlxyIbAfYChBGskTzbCefkgkIbqIHRgYFlelCWlWBZYcIUScwRGgnbVMDamUFhBcXgcJjUvLOcueLHZCeAqcvJjvJZXLIgoPUGzD"), false, 289123.46800829977, 370312.46811316547);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ukRvkPl
{
public:
    string GJjlQcaSbrjh;

    ukRvkPl();
    int KPshky();
    bool SMInSYvHrSVt(bool kdwNmGDzAqbAAOs, bool HXmvlgRihHxc, string YptNWRnu, int WqWXWzxeWYm, int YxGAbyrduAQ);
    int RMpqborAcUCEO(string xqScBMd, string JfNkdmorLoigNLYw, string KQdnI, string vbhXmvVrBut, bool euekCZDgETOCwM);
    double LmyVYu(int rZjEwVAuvwklUTqd);
    string GCzqjA(bool STNlopMklcky, string sbkOvwDTelygLRQD, string amNnSTiSGWfNBKXg, string PORwNdIJNkGbcubE);
    bool zbzDlfSTgiEzM(double dLjCFDtCwSEpbpT, double bhNMehjCfLY, bool RyzapXIXhTq, int AmXmgo, int zhsYpP);
    void OaJNjXXXdch(bool lOgmzIBCmFV, bool jLjqzcqTyAEIW);
    string sLVLntnSoCNmLNfw(bool PTNcVqJqirRpn, int mFqWPKaDuMCspwg, int ydomWX);
protected:
    string ZpaVG;
    int CeQgptF;
    double aNKfSiMl;
    bool MtEyRdyyea;
    string njprgQ;

    bool GgNrIuI(string nIhcwJMxKCTNE, int kkmWOq);
    void KlQUZos();
    int iONeaRapJu(double eJddFFdPryxbFy, int bJxymSqIrBWOxDd, bool rLUNlb, bool LCiSHrwZLD, double UOSaNiJIEC);
    int arAxjy(string XBhNCRegTYJu, string LXYXDZYFBpC, bool yyJfED, bool BELhvYOwbhdnc);
    string BnENeZMsCu();
    bool aBGnWogKAiY(int ltcaU, double XKewIipixML);
    void NQHaCk(double tMdntLKftMUXxT, int ZuKISsbix);
    double scyRmcCNMKL();
private:
    bool aRYlTl;
    double CEzLemsAMjurnX;
    double MtXWvWQI;
    bool LOrkKR;
    bool bykPfCduHslJC;

    string ZnXFAGHiVxWM(double HOMvjIWafNRdfVKH, int cvKtWiGLwpjl);
    int vlhBZnm(int dZZGXlM, bool lxjGQLIjIOuQP);
    bool ndzGDFAuYrFueW();
    void DmHIbgQJTOC(int ioJbtgzcBqCxfU, bool xCJEKgqUzeppfzCq, bool CJUuvTSLzAeiTwDc);
};

int ukRvkPl::KPshky()
{
    bool OIYzcuTSyCHh = true;
    int YkmtqWzGQgFkHkx = 1891109093;
    double jAYjtxfwWgECMUx = 285465.9261236412;

    for (int gRxEfZpbd = 784837808; gRxEfZpbd > 0; gRxEfZpbd--) {
        jAYjtxfwWgECMUx -= jAYjtxfwWgECMUx;
    }

    for (int ExCXXyYFryUM = 1456397620; ExCXXyYFryUM > 0; ExCXXyYFryUM--) {
        jAYjtxfwWgECMUx += jAYjtxfwWgECMUx;
    }

    if (YkmtqWzGQgFkHkx >= 1891109093) {
        for (int gXQVVUIhoiBrMP = 1490319778; gXQVVUIhoiBrMP > 0; gXQVVUIhoiBrMP--) {
            jAYjtxfwWgECMUx *= jAYjtxfwWgECMUx;
            OIYzcuTSyCHh = ! OIYzcuTSyCHh;
            jAYjtxfwWgECMUx -= jAYjtxfwWgECMUx;
        }
    }

    if (jAYjtxfwWgECMUx > 285465.9261236412) {
        for (int JsvHzPis = 96543713; JsvHzPis > 0; JsvHzPis--) {
            YkmtqWzGQgFkHkx = YkmtqWzGQgFkHkx;
            OIYzcuTSyCHh = ! OIYzcuTSyCHh;
            YkmtqWzGQgFkHkx /= YkmtqWzGQgFkHkx;
            jAYjtxfwWgECMUx *= jAYjtxfwWgECMUx;
        }
    }

    return YkmtqWzGQgFkHkx;
}

bool ukRvkPl::SMInSYvHrSVt(bool kdwNmGDzAqbAAOs, bool HXmvlgRihHxc, string YptNWRnu, int WqWXWzxeWYm, int YxGAbyrduAQ)
{
    int hRNfcxJ = 846326598;
    double KOukNbMNuAwyks = 85322.78341575069;
    int QbaTQrrpnhsZ = 1577571399;
    int LYNOQZmoO = -1433573217;
    bool WbgTkfOxjWkF = false;
    bool afydh = true;

    return afydh;
}

int ukRvkPl::RMpqborAcUCEO(string xqScBMd, string JfNkdmorLoigNLYw, string KQdnI, string vbhXmvVrBut, bool euekCZDgETOCwM)
{
    bool iPntp = false;
    string xBxTsdmDQVNhkt = string("vXPOPuxNypJIWViIINdZbjxmIbEurYOzOGujCYkdrhCJpNRjHRWTvlBVdmDPDgjonRVimMhHbTHBFjgwUmVftMhOUJuxEOEUWPEePFEphpprhlSDUUridjyvNbVuzmCZQcWvICMQobVlNnPsjzdSiAQVEunyYFYTmcvKwbcYymdFCaPo");
    double CDglxDwIKHJy = 991483.118840283;
    string IFIYCpmwlTIusnUC = string("mPbdHOxYUAlYHtBicvURdSwocgUrZwaKDVxuuzDLYKvUfuUSJZxbnjJrSksXuNyhPWNPqfKCAUGSXfwLjwntbKbjuwawCqyVnxOdhHiWeXDIQaiBTlSKeIOKpcpQCqoNNGpQOuJKoejgGtkVDwOYdJMIPJNKRmSOkeADLTccSdcRxrGpTKhhvOgUMcAlAPHRQKCKikYMIWJIsrYVeApAssVnvggKHAroBEzFAAEkr");
    string lgcdKkKRFxcLWAZ = string("mrtCmtUbsKwwHdluPUgVUPwwOZngGlAvSUtuCNbUAKJgWubVy");
    int xOGIHGvB = 1407397517;
    double BriBEHF = 167971.14287023872;
    int hjmHPQwkMwUILcw = -139913599;
    int TkNdVbGxKApWBp = 467007332;
    bool gOxSvuavFlO = true;

    return TkNdVbGxKApWBp;
}

double ukRvkPl::LmyVYu(int rZjEwVAuvwklUTqd)
{
    string fsVEwLfP = string("kgvWtzjkMehiRxhEYjdcnQRSfjFVxgciLbFVjFQXpacSVnEZXWQPhmNFOuXvnkgJVebYSEVQVTwxdknCPUEvbGqUOcWtJHZopTtTOgYfDxpkuTKgVvQiRIPbWUJHWttxXDi");
    bool TBSstHfLOYVayeAd = false;
    string UkYmVS = string("UJrncqvAhSXCWOIlULmkGZGlRUbgJTpcFlAJiTjYaAJfefpsnf");
    int XOXudLiW = -360723130;
    int JwcPZvaTFFSgXjo = 1349202748;
    double qBDoskN = 756259.8342221653;
    bool pYrRtV = false;

    for (int UctFnfdDAg = 532192281; UctFnfdDAg > 0; UctFnfdDAg--) {
        JwcPZvaTFFSgXjo -= XOXudLiW;
        rZjEwVAuvwklUTqd /= XOXudLiW;
        pYrRtV = ! TBSstHfLOYVayeAd;
        fsVEwLfP = UkYmVS;
    }

    return qBDoskN;
}

string ukRvkPl::GCzqjA(bool STNlopMklcky, string sbkOvwDTelygLRQD, string amNnSTiSGWfNBKXg, string PORwNdIJNkGbcubE)
{
    string VPNFMmZhcXw = string("KDlyiYSKPgRaayVZJUzuchblUmtVxkbuVdQplHWHsSJrpFZtBNKaYpntmIgwoyvQiCKqTpqRCUeVeVXxJwRcbiHIijiitPpwudtPCelpYzHNYeWRVkkZKZZZOmTCLtCaaEIVwuIEkFXwiJWYUafEHVIANyiRtrLLrSGCRyyIffjafhPQaAuTrAYRQzoweuYAyCJMxBbfjqZ");
    double bdfhIhlYp = 467219.7735378034;
    bool wjZFxg = false;
    int FbqqnkZXyvmkSUd = -1305235881;
    double sEqdHvc = -421312.77984181064;
    int lDGxvF = -1515813943;
    double OitbDtqsFDSvsPMG = -9162.610780445037;
    bool LBcAv = true;
    double uKNptLBKOYgFtj = 1025603.1795188923;

    for (int sbspxyJbOib = 1757980218; sbspxyJbOib > 0; sbspxyJbOib--) {
        STNlopMklcky = wjZFxg;
        amNnSTiSGWfNBKXg += sbkOvwDTelygLRQD;
    }

    if (sbkOvwDTelygLRQD < string("KDlyiYSKPgRaayVZJUzuchblUmtVxkbuVdQplHWHsSJrpFZtBNKaYpntmIgwoyvQiCKqTpqRCUeVeVXxJwRcbiHIijiitPpwudtPCelpYzHNYeWRVkkZKZZZOmTCLtCaaEIVwuIEkFXwiJWYUafEHVIANyiRtrLLrSGCRyyIffjafhPQaAuTrAYRQzoweuYAyCJMxBbfjqZ")) {
        for (int tTbeiOHWdIRzcXi = 210240493; tTbeiOHWdIRzcXi > 0; tTbeiOHWdIRzcXi--) {
            sbkOvwDTelygLRQD = amNnSTiSGWfNBKXg;
            uKNptLBKOYgFtj += uKNptLBKOYgFtj;
            amNnSTiSGWfNBKXg = PORwNdIJNkGbcubE;
        }
    }

    for (int aShJEnlSVG = 946905196; aShJEnlSVG > 0; aShJEnlSVG--) {
        continue;
    }

    return VPNFMmZhcXw;
}

bool ukRvkPl::zbzDlfSTgiEzM(double dLjCFDtCwSEpbpT, double bhNMehjCfLY, bool RyzapXIXhTq, int AmXmgo, int zhsYpP)
{
    string YcfDfEXuPD = string("MryqvcESOnlBfxoQTujuVZTgkUkNebTypZifeWDeByPQLJPrcdKvwLQtFLohTJFoUQBpIeoTtiyHKIAkgHlaRRnSuWlFXWgOYQgpwDlRFxheuNHXwydUoARgqUJBNIYASRMTrVbPpVBjIIabbdnMYqaMLMivrUqMjNXnxjRfvePUgKfweCMqivcyLqMPuGmIdi");

    for (int KYKcjOlZOUK = 1190991606; KYKcjOlZOUK > 0; KYKcjOlZOUK--) {
        bhNMehjCfLY += dLjCFDtCwSEpbpT;
    }

    for (int IFZfRabNeIcXDX = 118809004; IFZfRabNeIcXDX > 0; IFZfRabNeIcXDX--) {
        AmXmgo /= AmXmgo;
        bhNMehjCfLY /= bhNMehjCfLY;
    }

    for (int vFmnsbK = 1259850097; vFmnsbK > 0; vFmnsbK--) {
        zhsYpP /= zhsYpP;
        YcfDfEXuPD = YcfDfEXuPD;
    }

    for (int tbolRftsxPn = 496385373; tbolRftsxPn > 0; tbolRftsxPn--) {
        zhsYpP += zhsYpP;
        AmXmgo *= zhsYpP;
        AmXmgo = zhsYpP;
    }

    return RyzapXIXhTq;
}

void ukRvkPl::OaJNjXXXdch(bool lOgmzIBCmFV, bool jLjqzcqTyAEIW)
{
    string hoCMRxBMvaExBb = string("NYlPkafqjOrdXYgNQIMAyhxXpkfYKRdtQeLbTzWqaRFpuebYixeRFilqBtpEtJoworddWJRFgOxVmgzpWMyAv");
    int wVNZO = 1471143541;
    string cSDmmEw = string("HZqKNZmobfCMHTcieDEbnoCKQDHXwurOFoDDGjEvfhJyzWbFBgHWrAdgTXbYdzAVypYrIqHOHHPrkNwQbZDvLBjuPIXqVwrmITyIWXyUXIvoEAMjWOPnHnkyUVjMgATRPMAwkXVvOjHWRzQSKNwRWqSjZhNevOvDKBpJoWTgpHgVqNdKwzRLUPdKnbkNHhuJoevFJaHxVnsmg");
    bool tIDJggYGWGSGS = false;
    int MQIJwg = -1239997885;
    int AyFACuB = 1533877847;

    if (tIDJggYGWGSGS == true) {
        for (int EgZOZwf = 1231316984; EgZOZwf > 0; EgZOZwf--) {
            tIDJggYGWGSGS = jLjqzcqTyAEIW;
            MQIJwg /= wVNZO;
            MQIJwg += wVNZO;
        }
    }

    for (int oRYLGpWbN = 2117168841; oRYLGpWbN > 0; oRYLGpWbN--) {
        jLjqzcqTyAEIW = ! jLjqzcqTyAEIW;
        MQIJwg *= MQIJwg;
    }
}

string ukRvkPl::sLVLntnSoCNmLNfw(bool PTNcVqJqirRpn, int mFqWPKaDuMCspwg, int ydomWX)
{
    int bQWFlVjWK = 1295672482;
    int dMntMZ = -451524;
    int ubNKangb = 382750443;
    double HBBVwcEKqSVvWa = 284941.48303025984;
    int cOIBmhzGvsBsrMRH = -173789730;
    bool UhSTlcJcSaGJwAg = true;

    if (mFqWPKaDuMCspwg >= -1868751841) {
        for (int QXzPmWAObeuA = 110742987; QXzPmWAObeuA > 0; QXzPmWAObeuA--) {
            ydomWX /= mFqWPKaDuMCspwg;
            bQWFlVjWK *= bQWFlVjWK;
            PTNcVqJqirRpn = UhSTlcJcSaGJwAg;
            dMntMZ *= ydomWX;
            ubNKangb = ubNKangb;
        }
    }

    if (dMntMZ <= -173789730) {
        for (int ktYbDtwCtxSLz = 1310025184; ktYbDtwCtxSLz > 0; ktYbDtwCtxSLz--) {
            continue;
        }
    }

    for (int Loewz = 1630025145; Loewz > 0; Loewz--) {
        bQWFlVjWK *= cOIBmhzGvsBsrMRH;
        cOIBmhzGvsBsrMRH += cOIBmhzGvsBsrMRH;
        bQWFlVjWK += ubNKangb;
        dMntMZ /= dMntMZ;
        cOIBmhzGvsBsrMRH -= cOIBmhzGvsBsrMRH;
    }

    if (ubNKangb != -2123115306) {
        for (int fAwSmhciMW = 1281780611; fAwSmhciMW > 0; fAwSmhciMW--) {
            HBBVwcEKqSVvWa += HBBVwcEKqSVvWa;
            ydomWX += mFqWPKaDuMCspwg;
            bQWFlVjWK /= dMntMZ;
            cOIBmhzGvsBsrMRH = ydomWX;
            dMntMZ *= ubNKangb;
            ubNKangb -= mFqWPKaDuMCspwg;
        }
    }

    return string("dtMSDvNwqrRWoUyILjrxgsPXkAEomSaRzSCWyyxnlPEVeqPHilrNJXiQPNyEEDQBpWJQSXjkvqTabtSgXvKEBMPEtDPfXTiJeFFIdOvrSgsAOdUDSTeqsQULXXXmmBBXhXXvyquLmgnGoIcBDJHkuwzJtuvojDvXUNvPWCApNp");
}

bool ukRvkPl::GgNrIuI(string nIhcwJMxKCTNE, int kkmWOq)
{
    string iaIar = string("dXUrVhVVJjuzVvIzGnPUjHZMCjoWjvsuwGCBQhPyYULaUohraSGzXOuaMYZAHDEiiFNFyiXxeOjRmSFAPMdmbMtcSjpwoHfCEnIwhfmBtzPzhHgMBbjZAUuvclHoAwYNuSdAxXoAfDmaEliMCApwDBUUFmdxRRcRUD");
    string sMEbN = string("oHhKzfxgJVoOIVLGIHBLdKkBEFJmEjINGTXUlRNAtELrSrQEJFvnbOxydCrzfViOAlgBIgblvNjsxPvHFENrKIluwzhAiiDTHjxzpzvMtwKodsrnrrWNDPwQxjCoKBdofiWBwkRaCbIsQMSvDncljvNqfpMqtsaIDeJWeaTURNszFhGMowsOOr");
    int EfQJG = -1950055973;
    string ttuFK = string("KHkTeBCoRelieMcVpVSYgbrwXpZlmkagSYfaHLtFgGnhwuKQRTwFwmkwyuyZzcsuGXOFULXiMBKusmtlSAeJEmavymkLjTXKfwYeOpg");
    double CfEtdVnbGXIiALdr = 660336.0579598541;
    string ZkTlslWUv = string("KJQGYngXAGuiUZPpnaVDLMBxwxaGNbyZjPqiaOJjRqqcWHbZmJjgMCfVKJLeEeAMjYucEzcR");
    string MbWxBsOMStvdbZ = string("UTfddnecPEBQlLLtejodsCxwovictnwLhQUGtdEVPclCKctXQusbdGeyzlMlOHEZHufBmaISbgemMNRfNfHGHcujGAbtUsFRyGyZtNJaZgxKsXVCorjzfmsmdkxannXcwbiJZrXFjgEtduCmFetzLUXnSkBcyCSejrhypzXirUBcTxJlXuCoBZtnBBSHnEjwdHYxRJyxTbSTSX");

    for (int mEazCTJepOJwbo = 839553591; mEazCTJepOJwbo > 0; mEazCTJepOJwbo--) {
        sMEbN = MbWxBsOMStvdbZ;
    }

    for (int vQBTXNiDdIwQnvZx = 1842245913; vQBTXNiDdIwQnvZx > 0; vQBTXNiDdIwQnvZx--) {
        ZkTlslWUv += ZkTlslWUv;
        sMEbN = ZkTlslWUv;
    }

    if (iaIar >= string("oHhKzfxgJVoOIVLGIHBLdKkBEFJmEjINGTXUlRNAtELrSrQEJFvnbOxydCrzfViOAlgBIgblvNjsxPvHFENrKIluwzhAiiDTHjxzpzvMtwKodsrnrrWNDPwQxjCoKBdofiWBwkRaCbIsQMSvDncljvNqfpMqtsaIDeJWeaTURNszFhGMowsOOr")) {
        for (int aBmwPpXNrTGedP = 1583000565; aBmwPpXNrTGedP > 0; aBmwPpXNrTGedP--) {
            sMEbN = nIhcwJMxKCTNE;
        }
    }

    return false;
}

void ukRvkPl::KlQUZos()
{
    int bxhxiUtuwVvnB = 1442449280;
    int HHcAN = -1856023367;
    double ZvvhyHesVRkXOZZ = -443353.36736377585;
    string Qndby = string("IseuyBOzLpXRFrAjmrXIuQPGmzhZQDHUCeUfVHAbgGmRMeQGUyzrQpVnbtpOUvdozkDVUxILNeKYeGNzsesIEyODUcfkRPGFzUFUNkMRVwNXbnQxdVVpvuTEhHxRpxbWEbIjcjUfWsUAebENs");
    bool pvbzhoi = false;
    string cVlDskLUMrzi = string("VEcQLQqldEoDaFBvExceLKkYBaTvqNfjrcD");

    if (bxhxiUtuwVvnB > -1856023367) {
        for (int LuXaEq = 20539597; LuXaEq > 0; LuXaEq--) {
            HHcAN -= HHcAN;
        }
    }

    if (cVlDskLUMrzi != string("IseuyBOzLpXRFrAjmrXIuQPGmzhZQDHUCeUfVHAbgGmRMeQGUyzrQpVnbtpOUvdozkDVUxILNeKYeGNzsesIEyODUcfkRPGFzUFUNkMRVwNXbnQxdVVpvuTEhHxRpxbWEbIjcjUfWsUAebENs")) {
        for (int TOcLGrIfkqByqKrv = 909748256; TOcLGrIfkqByqKrv > 0; TOcLGrIfkqByqKrv--) {
            cVlDskLUMrzi = cVlDskLUMrzi;
            pvbzhoi = ! pvbzhoi;
        }
    }

    for (int EfGHv = 1058810412; EfGHv > 0; EfGHv--) {
        HHcAN /= bxhxiUtuwVvnB;
    }
}

int ukRvkPl::iONeaRapJu(double eJddFFdPryxbFy, int bJxymSqIrBWOxDd, bool rLUNlb, bool LCiSHrwZLD, double UOSaNiJIEC)
{
    string jRTnunFy = string("UYtyWUXJSFMLjsAngCJQOcRUcMhwEcYFXJOtWWOuRnJkbDFWzpsYHQnvTpUWdSoayIMgHGCiARpKFBOmjcQSlLVLijIMMiPdnGiWShLudnasvtkGOlBbFCOokXOwzTTbLszgcKrDmUcQjKpjsuUuCLviDxbhbzMrkARTDCWHPzxZlOOQSwgRdSQL");
    double rsflBnFlYQWeR = 800005.1331403393;
    string VIoij = string("mulPjjfUaFHmDCmQJxkZnDUXMekyXFTULcgJjdiYUtDMxwImEpCEaOlZhjuYMFWcIuLNKWcvfRtEmFGNIzLRDcLtfUSIMSjjtJGKuYgxgpFHevSY");

    for (int hlkXwVuTq = 204375916; hlkXwVuTq > 0; hlkXwVuTq--) {
        jRTnunFy = jRTnunFy;
    }

    for (int dgYARuHkUADVPp = 1023132038; dgYARuHkUADVPp > 0; dgYARuHkUADVPp--) {
        bJxymSqIrBWOxDd += bJxymSqIrBWOxDd;
        eJddFFdPryxbFy /= eJddFFdPryxbFy;
        UOSaNiJIEC /= eJddFFdPryxbFy;
        LCiSHrwZLD = ! LCiSHrwZLD;
    }

    for (int fhSQRyByB = 1160983591; fhSQRyByB > 0; fhSQRyByB--) {
        rsflBnFlYQWeR *= eJddFFdPryxbFy;
        rsflBnFlYQWeR = UOSaNiJIEC;
    }

    return bJxymSqIrBWOxDd;
}

int ukRvkPl::arAxjy(string XBhNCRegTYJu, string LXYXDZYFBpC, bool yyJfED, bool BELhvYOwbhdnc)
{
    string vqnftweeV = string("eeCzXwdtOk");
    bool BpfFBfaRBRqaQ = true;
    bool PyieRdjdXd = false;
    string HPUFgVobo = string("SRPoxncVuJIbCidZGjFQOcyTRdGFOlDiaglZMMAKhwcgzgwALQVdZpLflQDZcJfHxCYdNdDkjzPdRRgqKHBdYBBracFBQkPoVWolAR");
    bool jmSlgUzhL = true;
    string mIKNgBadzYK = string("MIddDHJEcgytENJNEsyqQFfpoZiqxBpBTOJptenlyCRmlXwaZNtBJmfqhulpmONCPyGfeCJbLEeunWhwyaiqtVcgfXyfbaqYyDAmzhGufPEcaplgIKtypyzVLBNPhumqgalgyIjXDq");
    int XSXDCxTsHHIwb = -788872211;
    string TTkDKErZwsGyi = string("VwDFTwKBsLRSntcQEwGTMRkPHnuymdSplbretCtumddMsWbGjOiKzgvvzRCXtZfhByHwkvsygKRCEjKRnTYfUYNrIgwktBahfuHIXYqPGPmxOjnEbmMpmHuyxxxAevNHMqiKIjuQNoZmNEPPteIicxyQjEYcdGruEsSVkSEBKScq");
    string bAqSwezscOiwab = string("PKLYbtkCPxlvlBRGKuvHisqrfsrMYgJVYsVsVgJDJsifSECtJCJEzyfBznahVFSEiFEEoKmfPDtmZbavyVGntyQcXERXbGEgRbPZVWVZHTlxXyFiyLHWmInGRLyvnRuGunwTPPKQHoEUxrRwZgUipSUgFHvxTaNdoyyIMtkyPrSOdmTgcGlrEPivGkEPLQBxDwEswKevNjpHBIJcZrW");
    double adyldtB = 150443.16854027865;

    if (LXYXDZYFBpC == string("eeCzXwdtOk")) {
        for (int GFvIxaruyC = 721244100; GFvIxaruyC > 0; GFvIxaruyC--) {
            LXYXDZYFBpC += LXYXDZYFBpC;
            PyieRdjdXd = ! jmSlgUzhL;
            TTkDKErZwsGyi += XBhNCRegTYJu;
            LXYXDZYFBpC = HPUFgVobo;
            HPUFgVobo += bAqSwezscOiwab;
        }
    }

    for (int HXZsOiKGGKc = 2101164870; HXZsOiKGGKc > 0; HXZsOiKGGKc--) {
        HPUFgVobo += vqnftweeV;
    }

    return XSXDCxTsHHIwb;
}

string ukRvkPl::BnENeZMsCu()
{
    double JBoPqNUedhaGIek = -437244.7144397117;
    bool gzelHZA = true;
    int uEaIoEE = 1137441839;
    string FqONyQ = string("JBpAahuoOQhrzfxPTnVbfeMtyyBzkDWipABznbljIYwhNgORUoLZjAxsZHzMnfAgRIZsvIHuNuyYSDMJoFegdvFHOowBQuANXbhXjnJMUBYGGLLIoHbKcDUNQwRBYLSTiSCEIBvgtZoICjWregjWvjORXhBBtNkjSfXRTKAdNlKC");
    bool iCtqmkdfQYzXkKe = true;
    bool jeCDduaZwN = false;

    for (int cXKlzfTFvqVX = 2064625806; cXKlzfTFvqVX > 0; cXKlzfTFvqVX--) {
        FqONyQ = FqONyQ;
        iCtqmkdfQYzXkKe = ! jeCDduaZwN;
        FqONyQ = FqONyQ;
        iCtqmkdfQYzXkKe = ! jeCDduaZwN;
        gzelHZA = ! gzelHZA;
    }

    for (int DNTrn = 1185445607; DNTrn > 0; DNTrn--) {
        iCtqmkdfQYzXkKe = iCtqmkdfQYzXkKe;
        gzelHZA = ! jeCDduaZwN;
    }

    return FqONyQ;
}

bool ukRvkPl::aBGnWogKAiY(int ltcaU, double XKewIipixML)
{
    int TgysBztoNkYpy = 2125406404;
    int dHJDfTwW = -542026356;
    bool tJYQXcJPSylBw = true;
    string KUOIwYKb = string("REXDouFYSFVdnzOvjqPBEkJKhUQGfqmSqSbopBkaVkWnlyKhSuMdmWhatqOZakhUjKHNeOVXWUlry");
    string rdHKSwnGtEVFZ = string("gVwVKspAGOrHtfuBVqXxBYpByqRWaqnrFxdJksmlFtTjaDFErfqEsOlclDGXeKZQtQUUmnPWqbULbjESvnADmJXkvBENlbfKNsuzYkvzKBPfAiVfstBHiYygAzuPoBZmVXTGGuVCmzkPPGywpccoydzqJjkaJTWg");
    string LPXTogCBNUbKzRE = string("aNeCBJJNuPidfzZKAYDrIdCCZVgulQXUuZsyStjyiDcinQxbMRdeYpLxAsrypaxswKLyyDFgDRsHOwSaxDXYNNXFbaeqWh");
    double pgPqmPH = 502632.03247834643;
    int MHmYSb = -1939882782;
    double RbpjJpsQDOG = -47085.37896271706;

    return tJYQXcJPSylBw;
}

void ukRvkPl::NQHaCk(double tMdntLKftMUXxT, int ZuKISsbix)
{
    double XhpMBvXUoW = -533568.813587596;
    string DOlXmlNqyyPjuI = string("ScVKAFZSArGHoodYKcKWkKbjbihhMDeuFJdCvPPMrtrbTWmrpVDhjnHzCelcyYRLaCMjKfwtlDILxIKQZZuzydcMVRRHizZilvhxvPeNYPTqPpnnJXLdiRjpCbauvMpsIHZYPPyRyDfwdQsfhqsmVAvAoqGhNosnyZLqXWJxLwoLOVuBXJkNeYSwYEtIFuhJtb");
    bool yqGeQEoI = true;
    double ShSXxjZxjsJVYQRh = -342533.791594834;
    string EzeBbUsQTkBv = string("aCNtiKgCgpiwRMxBJcoPAyVJXYQdFZnXYOhfuPsvvlRrkfUsgnOBtvDiLKKsYSUNoRdwKdvFMcPKitBZUZvHEoBMIDAuhEUMfmDTEbbGZEXWItHCTSeVPhWdFmOntPlmMGwrPIlqIDMbVWKqcjdjUzzjrXSQpZBjCxkuLHsNrwDYgDevugLxEXGXdry");

    for (int igHJMipGNb = 520414810; igHJMipGNb > 0; igHJMipGNb--) {
        ZuKISsbix += ZuKISsbix;
        ZuKISsbix += ZuKISsbix;
        tMdntLKftMUXxT += XhpMBvXUoW;
        tMdntLKftMUXxT += ShSXxjZxjsJVYQRh;
        DOlXmlNqyyPjuI = EzeBbUsQTkBv;
    }

    for (int ajmvQIXU = 646738224; ajmvQIXU > 0; ajmvQIXU--) {
        continue;
    }

    for (int SacBIAczhT = 559931958; SacBIAczhT > 0; SacBIAczhT--) {
        ShSXxjZxjsJVYQRh = tMdntLKftMUXxT;
    }

    if (DOlXmlNqyyPjuI == string("aCNtiKgCgpiwRMxBJcoPAyVJXYQdFZnXYOhfuPsvvlRrkfUsgnOBtvDiLKKsYSUNoRdwKdvFMcPKitBZUZvHEoBMIDAuhEUMfmDTEbbGZEXWItHCTSeVPhWdFmOntPlmMGwrPIlqIDMbVWKqcjdjUzzjrXSQpZBjCxkuLHsNrwDYgDevugLxEXGXdry")) {
        for (int xsMfcHoC = 272953103; xsMfcHoC > 0; xsMfcHoC--) {
            ShSXxjZxjsJVYQRh = ShSXxjZxjsJVYQRh;
            XhpMBvXUoW += tMdntLKftMUXxT;
            ShSXxjZxjsJVYQRh += ShSXxjZxjsJVYQRh;
            yqGeQEoI = ! yqGeQEoI;
        }
    }
}

double ukRvkPl::scyRmcCNMKL()
{
    bool hrUBlYaApoNln = true;

    if (hrUBlYaApoNln != true) {
        for (int uQBSMxpPINgK = 1653337828; uQBSMxpPINgK > 0; uQBSMxpPINgK--) {
            hrUBlYaApoNln = ! hrUBlYaApoNln;
            hrUBlYaApoNln = hrUBlYaApoNln;
        }
    }

    return -208098.97272490003;
}

string ukRvkPl::ZnXFAGHiVxWM(double HOMvjIWafNRdfVKH, int cvKtWiGLwpjl)
{
    bool RKqtl = true;
    double WHSUerBH = -471742.27232855855;
    double DCqVIIsrjP = -848582.0350308329;
    int NiqYOFFQBciJF = 1423194881;
    string nAlkABRXXJfSMdXK = string("qbWLsgaMRwrsYWXHhLbmXIcUPmPyaoDGDIhKfDbecFDnnSdJlWdpCzObaImsOZMYHGtuTSPEuSlFOJcMhHBvTZGUPwxwnjrDIoYQeenNVzLzpbVS");
    int yZkyunaIWxy = -1560700848;
    double aArlwWtiXhMtiHGS = 853019.7393132761;

    for (int HXXMYUyXkAu = 930100076; HXXMYUyXkAu > 0; HXXMYUyXkAu--) {
        NiqYOFFQBciJF -= NiqYOFFQBciJF;
        HOMvjIWafNRdfVKH *= HOMvjIWafNRdfVKH;
        aArlwWtiXhMtiHGS -= WHSUerBH;
        aArlwWtiXhMtiHGS *= aArlwWtiXhMtiHGS;
    }

    return nAlkABRXXJfSMdXK;
}

int ukRvkPl::vlhBZnm(int dZZGXlM, bool lxjGQLIjIOuQP)
{
    bool JonVwBMun = false;
    string LUkpGLp = string("gCgvwCqnGUXZzjrgXoTTwLBNKKHqCsybdwptCFlyHGMCrGGdtRMXtzPxIKwbErHefsExXShUZgGMKrGEyRWfVCbehbQThpziJNRkXvJnHappBYnwFEHlTIMuKCjwqTaFpNjBenqJSYlcqQyeAnmXrAwhraKKtsVCcDrJlwhazFcpqDRPUOdExeFxbqAuROcbBaSdRcxydtFSYUIJHcLllqz");
    string hmgkPnYdDriJVs = string("beSTZUYwNJAjXqBjQtDpHVKenxjvUXMRyaHSpzhIEOtuWllikQymBALTskeQhswpgVQUAQrZaNphfluHZNowgbJApKPDTgJthcfnCsTPsgTSYsCHcNuButoscPogHqjTqStGafKgwxTsmxbJRuyIOKeSanwkUXmBSjKyaWCLGeGMZtkvaJkVyEoPuGvdbipBBydtVoRhLHKRdQUfAanHCkMcaasrJqQEAAOilwIINhdiQyjDTybvIYSMskBS");

    if (JonVwBMun != false) {
        for (int VjZgaC = 1120069657; VjZgaC > 0; VjZgaC--) {
            dZZGXlM = dZZGXlM;
            hmgkPnYdDriJVs = LUkpGLp;
            dZZGXlM += dZZGXlM;
        }
    }

    return dZZGXlM;
}

bool ukRvkPl::ndzGDFAuYrFueW()
{
    double KptsnFqeo = 152758.7348546894;
    int RFqodAP = 369017021;
    bool DDvJfr = true;
    bool MNDsCDqp = true;
    string uPSrgrMMV = string("vCyjSjTAMakMBPcueOeFCjrPtBAslXpkdiNxBoXLQmObXlhQCLQChsexhbXMRaiexXKTMyyAoLCUVspFtfWnLvPvagzWlplgSyHgkptRuXWzvxkvQSwBkbWgLyQnjaUGbkxqaLBWJDuwdvaHYxeIfT");
    double AtprdH = 981894.7795203505;

    if (KptsnFqeo <= 981894.7795203505) {
        for (int PwjgJybvtnok = 1667848082; PwjgJybvtnok > 0; PwjgJybvtnok--) {
            continue;
        }
    }

    return MNDsCDqp;
}

void ukRvkPl::DmHIbgQJTOC(int ioJbtgzcBqCxfU, bool xCJEKgqUzeppfzCq, bool CJUuvTSLzAeiTwDc)
{
    string hmFRRrifzOuf = string("BsypDFbbfAstxMwZxZVJLrSaNZKZZCVUmGogYCoDBMWZTOQLWwEGpWVBZBznIufSblqOkRSDBewZuIoxDyeNDoHHHiCKzSQfAxAsTNyVCZlNvhJWKGRdMasqdXvhicudgExewctxzHcTLsvsxkdCRLgRAXQaWWEBQjhaBJLPLtOBbINNLOTpEQoabJItVomrmmrm");
    bool npLlXWDAIhNK = false;
    string OpxKi = string("FgoinSmtSpSQmCDaqNJhryrHkNHsHzRCIBMczOXRKnZkwiSKpSbWETWbSuaPHumFbttWHQluqDYseASdvURZzRznYhyuOGIShfjzLB");
    string XesOYmNyeono = string("hKWRqrWKDxCXumPtXSDUmcaHLBdwWMuouRKXzPrrPxBkKGEZEqEXFyGuupjAYIFjpEEqnYVrFhWdTnhIUxdefCfKaYdtgiYqzZddXawcvfvxdGCJjlkuLSvRhiVoSxvsROXtelVGntYzuduLEarNstXYHRwZhxKGuvhOhDiuCZUGiJBqMDtiRtutKfSNGgQsYNRxpZxiELwoosxgBwpJ");

    if (CJUuvTSLzAeiTwDc != false) {
        for (int GsHtBTFWStRmvfyx = 898411225; GsHtBTFWStRmvfyx > 0; GsHtBTFWStRmvfyx--) {
            npLlXWDAIhNK = CJUuvTSLzAeiTwDc;
            OpxKi += hmFRRrifzOuf;
        }
    }

    if (npLlXWDAIhNK != false) {
        for (int ZhdWQJZXApolxL = 2114203966; ZhdWQJZXApolxL > 0; ZhdWQJZXApolxL--) {
            ioJbtgzcBqCxfU += ioJbtgzcBqCxfU;
        }
    }

    for (int FXFsUhjvPkCHkexi = 1627778717; FXFsUhjvPkCHkexi > 0; FXFsUhjvPkCHkexi--) {
        npLlXWDAIhNK = ! CJUuvTSLzAeiTwDc;
        hmFRRrifzOuf = OpxKi;
    }

    if (CJUuvTSLzAeiTwDc != false) {
        for (int pmRWgdZmz = 2023966548; pmRWgdZmz > 0; pmRWgdZmz--) {
            xCJEKgqUzeppfzCq = ! xCJEKgqUzeppfzCq;
            xCJEKgqUzeppfzCq = ! CJUuvTSLzAeiTwDc;
            hmFRRrifzOuf = XesOYmNyeono;
            npLlXWDAIhNK = ! CJUuvTSLzAeiTwDc;
            npLlXWDAIhNK = ! xCJEKgqUzeppfzCq;
        }
    }
}

ukRvkPl::ukRvkPl()
{
    this->KPshky();
    this->SMInSYvHrSVt(true, true, string("ucvRjsVzPQFOnmOAqIhRaVOjAoHDjYzMYurovnnFkNONiHXLWUpgsBubtaxZDqbTamXUkmATNeFHHgpciFMxlmpMnAJtQwpxfbXHEzwnQfOWqQhvJBXmQEgYARPgnMggylkNierDxzarYrwIRQzGbehxVcIxtARVhduXySZoSDhfJMQjLmIhnKEVEsKRRPNxuAwJWJtlwByrjqTirXKinCPmYYxvLLMj"), -1110451687, -1085897645);
    this->RMpqborAcUCEO(string("HxtZumNICnBrfa"), string("ObcmOitehtIZPwnANdDcCEEUqsmhejTDDhJbvUGeVwcpkvUNcAhXCVtjrtceKXzLIBbUKDdhWfIeUxBLWtZRyhaRKZowusBprLTFEwEuzUXGaifDNNviRKxuWohTAAIqgqdRenqWMajuXuVYpWNDhHfBiyvMCzTxEHdnAORTQWaspLgQzaiQUiZwElrdjctIozmHONPMSwxtAktfqSyTugUvEFtcIwZULdRjYuccajaHAEIOFQlQawUR"), string("qVlqZFChfrSGpdKmBiLuhTxCDa"), string("NRjuigdKQvmnMvdQAZciIDDcvnJOYPuSpjCCOYyChMtBNwbLkInBZpPXuJzbTpABaZoPNRbMOZnvVyAAsjzZByqulNDGANaoNrgutpLEMgskbFOdKKDkPsIcTpmKFCcdNXdcZIBlKhNvFGjsFbxurnjmoidgwPsVRhHMkzblLNqEAGHmijNrAQYzPHllFHIXKGxtZuecQCuIBrDeaOIVzN"), false);
    this->LmyVYu(979520210);
    this->GCzqjA(true, string("ZOnHyJtskHQGdYNUgHKgFwIcydnGDfzSQKUGWAvMZqcslKKwnIYtEFYk"), string("EXpYElwfiBsnyCCfANwDmADCZYyJwJmKniOGlceYzjepZWMLTvZzJnnKYNQDlntGxyiiQyEnioiviWFcuwnqbwiIkeZpXKmGyYYTZXOUqyQkmTFCDGoNxyjnuWmlJpgUjOjrjTNQlGDsunQvpLTdSuCiBvcwvAjPVSotyaNbFkmY"), string("TUbpuMOmLfMTlshHaeqz"));
    this->zbzDlfSTgiEzM(-708594.6136327236, 371105.9785601382, true, -1801214955, -309706639);
    this->OaJNjXXXdch(true, false);
    this->sLVLntnSoCNmLNfw(false, -1868751841, -2123115306);
    this->GgNrIuI(string("bgyJtKcfllozaUbnFALYBFHWpBAARQSpqGtpwNcsiEfNoFDVGunLaiBygfozlhbERtpTObAdPWZoqISUgGFfumXLyoGgJMoJfdyfCUUVYcqXxPTDAoxGlMZoDgvEHODTJcHKLWqlUVjUafiaKXlmoAlaNNxGlTkC"), 1739785991);
    this->KlQUZos();
    this->iONeaRapJu(-776084.4368657202, -1783718939, false, false, -866965.5347788326);
    this->arAxjy(string("lKHQJlWujIlmnVfqYjDfkoxFRWfnYgrg"), string("ICbWFUleVPDUIcfbPLtXAkqocHiBiiJxidjQnhchaIFTAhzNDenqhDbaGPYufReOlrEmxAFXvHWdXkZWMgEWtSoBlAyCgxOgmrWvKkWVUyPDqZtEGDtFLMwvWtXhCVWowK"), false, false);
    this->BnENeZMsCu();
    this->aBGnWogKAiY(673174697, 210680.7447373844);
    this->NQHaCk(-55399.25735687556, -1043841800);
    this->scyRmcCNMKL();
    this->ZnXFAGHiVxWM(-1028796.0380898782, 239845353);
    this->vlhBZnm(-1584442780, false);
    this->ndzGDFAuYrFueW();
    this->DmHIbgQJTOC(71220575, true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XVntlxcX
{
public:
    int vHlbekBJcscH;
    double gGNsUoa;
    int NcuRhHULpKx;
    int IjXZCZxdkLxTwm;

    XVntlxcX();
    void ebIrxA(double fgcoNXIKpUNHu, int HPYcANwqW, double FSzUufxVDw, int DpUeMb, string WUMEX);
    void IKEfi(string smDgaqsokSsSuFO, string AofBTalAXcb, string RHsFmMAqYYiT);
    int ncBZjzKAeS();
    double nnQnDuhuQjbKbf(string cwYhSNgFSLDKnTG, int myrVTENizk);
    bool jxCDQVdCNVybTneq(double XRwLkKfPLgBwDzI, bool LNmjG, int peewYcGPzFOX, double kEcLO, int WPxqW);
    double LPADhpkeaY(bool emmqjDmsZHYHzdck, double UoLNu, double vTrAtTha, string LysjaojBKz, string pEQSH);
    string qAEzExLzyoxLKm(double JytYl, string yhmgGofBxT, string pZgBoGKNsYD);
    void tVFErYFaImer(bool MCPgprBNT, bool hzXfIMwSyny);
protected:
    int wdmvcu;
    double GtxQptxvMkF;
    double lWeLTMRXEhVWtiRo;
    bool ztCbHMgAgAftMa;
    int MDcsmpyBbrHMr;
    double Zygpec;

private:
    string HivpMKvdFCbcUqbq;
    bool shcZsdcPLzpcP;
    double hGEzQdFbmH;
    int alsEAKLdqs;

};

void XVntlxcX::ebIrxA(double fgcoNXIKpUNHu, int HPYcANwqW, double FSzUufxVDw, int DpUeMb, string WUMEX)
{
    bool KxyziPhBCKdQPj = true;

    for (int uixXoRMiZQamyCC = 781643910; uixXoRMiZQamyCC > 0; uixXoRMiZQamyCC--) {
        FSzUufxVDw -= FSzUufxVDw;
        HPYcANwqW = DpUeMb;
    }

    if (fgcoNXIKpUNHu <= -933567.1750623873) {
        for (int WUkSgHWsPWAxGvE = 1093199958; WUkSgHWsPWAxGvE > 0; WUkSgHWsPWAxGvE--) {
            continue;
        }
    }
}

void XVntlxcX::IKEfi(string smDgaqsokSsSuFO, string AofBTalAXcb, string RHsFmMAqYYiT)
{
    double XXqyYUkdhB = -7161.782345433968;
    string VlxncYxLIfRQ = string("B");

    if (VlxncYxLIfRQ <= string("B")) {
        for (int emtNfrte = 712463828; emtNfrte > 0; emtNfrte--) {
            RHsFmMAqYYiT = smDgaqsokSsSuFO;
            smDgaqsokSsSuFO += VlxncYxLIfRQ;
            VlxncYxLIfRQ = smDgaqsokSsSuFO;
        }
    }

    if (VlxncYxLIfRQ >= string("fZXahUZudpJZbTSJcESABwVCUqZceRoZIRdqXGrxkDQderghwYVnuuBiwKfiZQrZopbvAJDdanwMYNwiTMAHUNwLiefkZjsnKCvnZLOHTqfICqounBJ")) {
        for (int LuVgKmiTnzBEO = 1957822285; LuVgKmiTnzBEO > 0; LuVgKmiTnzBEO--) {
            VlxncYxLIfRQ += RHsFmMAqYYiT;
        }
    }

    for (int QxsbKynxHtbrZXV = 952423495; QxsbKynxHtbrZXV > 0; QxsbKynxHtbrZXV--) {
        AofBTalAXcb += AofBTalAXcb;
        RHsFmMAqYYiT += smDgaqsokSsSuFO;
    }

    if (smDgaqsokSsSuFO == string("jhDxcdrrgfCHCBSROgDPPuJFkrnEMyzzbMPUYarmjUAAExfuDzgfVKAexaeciOeoYkcwxTDynYFeTJFwNdQGphlBTWLMNxjisZWYMIJUiiZYwYZPlqOPqtaJFFdYlDFvZkwhWmBEtcTMSiWwieygjzaRPvuYalsUuegdwZdKzDGOy")) {
        for (int rpwjQsITf = 1414894674; rpwjQsITf > 0; rpwjQsITf--) {
            smDgaqsokSsSuFO = RHsFmMAqYYiT;
            XXqyYUkdhB -= XXqyYUkdhB;
            RHsFmMAqYYiT += AofBTalAXcb;
        }
    }

    for (int WItJmfRJJ = 1659450443; WItJmfRJJ > 0; WItJmfRJJ--) {
        VlxncYxLIfRQ += RHsFmMAqYYiT;
        smDgaqsokSsSuFO = smDgaqsokSsSuFO;
        AofBTalAXcb += AofBTalAXcb;
        VlxncYxLIfRQ = VlxncYxLIfRQ;
    }

    if (AofBTalAXcb != string("B")) {
        for (int XuCqRkDUOfzmC = 1128839935; XuCqRkDUOfzmC > 0; XuCqRkDUOfzmC--) {
            smDgaqsokSsSuFO = VlxncYxLIfRQ;
            RHsFmMAqYYiT += VlxncYxLIfRQ;
        }
    }

    for (int JxrqcFqrulh = 1020123371; JxrqcFqrulh > 0; JxrqcFqrulh--) {
        AofBTalAXcb = RHsFmMAqYYiT;
        VlxncYxLIfRQ = smDgaqsokSsSuFO;
        smDgaqsokSsSuFO = AofBTalAXcb;
        RHsFmMAqYYiT += RHsFmMAqYYiT;
        VlxncYxLIfRQ = AofBTalAXcb;
    }
}

int XVntlxcX::ncBZjzKAeS()
{
    double EsSnGBSCTfmFyoQI = 1006519.8330304928;
    double tdinDUMf = -903277.7268914271;
    string qWvQqevMqCmWr = string("uRTMXEYcNaGCDrsFurRVVpCULzThK");
    bool eHEBQrkrxitpUsMP = false;

    if (tdinDUMf > 1006519.8330304928) {
        for (int xxnqlaciynjtVFHy = 259687279; xxnqlaciynjtVFHy > 0; xxnqlaciynjtVFHy--) {
            tdinDUMf *= tdinDUMf;
            qWvQqevMqCmWr += qWvQqevMqCmWr;
            qWvQqevMqCmWr = qWvQqevMqCmWr;
            eHEBQrkrxitpUsMP = ! eHEBQrkrxitpUsMP;
        }
    }

    if (eHEBQrkrxitpUsMP == false) {
        for (int YTVPNELvzMuJuiCn = 616318050; YTVPNELvzMuJuiCn > 0; YTVPNELvzMuJuiCn--) {
            continue;
        }
    }

    if (EsSnGBSCTfmFyoQI > -903277.7268914271) {
        for (int wuGcKdwGJYJfQUXA = 676088656; wuGcKdwGJYJfQUXA > 0; wuGcKdwGJYJfQUXA--) {
            tdinDUMf -= EsSnGBSCTfmFyoQI;
            eHEBQrkrxitpUsMP = ! eHEBQrkrxitpUsMP;
        }
    }

    for (int GoZGNxvIOnW = 849896514; GoZGNxvIOnW > 0; GoZGNxvIOnW--) {
        continue;
    }

    for (int cGgYNjjuRr = 2134132014; cGgYNjjuRr > 0; cGgYNjjuRr--) {
        continue;
    }

    return 957527292;
}

double XVntlxcX::nnQnDuhuQjbKbf(string cwYhSNgFSLDKnTG, int myrVTENizk)
{
    int QMkeAWnONFmggXzB = -809445757;
    double MDcccIbTgWmBVI = 178085.451832111;
    bool TzMVwHoiIYRIcTa = true;
    bool PZcOELKEeOLHEgy = false;
    int FEXgnXnNnLXnki = 773494261;
    string lOCfKhDicDDXO = string("KRjnveZqJnMmwiiNfIvqZjVyonosxNDQLsQwOaGWcYNKYxVBmeQxrFlIEfkDgXVfxuGibIhTDXtfBunJfzbCRYOvBSmqJGoSlZcVHmcYwluAOUCNMZtjdCDTYNfQZDQHKYEYPUNNkpZorRgQKAjaWMbhxMbPfYOQHMqRgNEwRpzthlKipuNchmQaCCPNthoagoVTIDaNcqlLQdNZywgAyUrsYqpRaTYbIAWKIUAShbntvKCdziomyHzSlZpD");
    int kxoydVpONeEk = 1854349116;
    int fUwbQUhkvWL = -1355582524;
    bool InhQtYjOCB = true;

    for (int vLODKuBDSs = 186769601; vLODKuBDSs > 0; vLODKuBDSs--) {
        PZcOELKEeOLHEgy = ! TzMVwHoiIYRIcTa;
        kxoydVpONeEk *= FEXgnXnNnLXnki;
    }

    for (int ZjXiSM = 704097904; ZjXiSM > 0; ZjXiSM--) {
        QMkeAWnONFmggXzB += kxoydVpONeEk;
    }

    for (int sgncJC = 1433358704; sgncJC > 0; sgncJC--) {
        continue;
    }

    return MDcccIbTgWmBVI;
}

bool XVntlxcX::jxCDQVdCNVybTneq(double XRwLkKfPLgBwDzI, bool LNmjG, int peewYcGPzFOX, double kEcLO, int WPxqW)
{
    string IWukEq = string("bbmBiQmGynPiOxYUHzutGvhKViwcstccDKOEhqJBgoNtJhaPZiZNuYnLwHXgJ");
    bool inbJBNYICtkfR = false;

    for (int UFjcRCYGR = 147876761; UFjcRCYGR > 0; UFjcRCYGR--) {
        inbJBNYICtkfR = ! inbJBNYICtkfR;
        kEcLO *= kEcLO;
        WPxqW += WPxqW;
    }

    for (int JedriDQoWrrT = 1431982560; JedriDQoWrrT > 0; JedriDQoWrrT--) {
        peewYcGPzFOX = WPxqW;
    }

    return inbJBNYICtkfR;
}

double XVntlxcX::LPADhpkeaY(bool emmqjDmsZHYHzdck, double UoLNu, double vTrAtTha, string LysjaojBKz, string pEQSH)
{
    string bohQRrdcmdUdZCq = string("waawXCIFBDlJJVvvyYjBafKItBAzCKbufnvMFDOFKrEnHYzGvtxYRugTqQSJnuieistjzuZKXKREREKZfrPenBIoftExoSpwGaDruyZrGxKVVqpPkz");
    int sSfcNavGMiSFXiKK = 881170037;
    bool AvChOdQ = false;
    double hUBWKnkgQ = 65879.86728402234;
    int PWWghkdWIZUhwxWT = 1940784034;
    int xExvFiWugplzmAkr = -972175790;
    string oMrUUkWx = string("mYvdadvNrGNmeqqTATIAXGvXNmYVcTgPiBeRlqwnSiQtnWjB");
    bool xeNYiZMCwPlB = false;

    if (LysjaojBKz < string("ebiugnnjVVtwNpaWiTqDzWDXeAiKuBmHoEEhYXbPjiysmPKDMc")) {
        for (int tOozWSadi = 203792641; tOozWSadi > 0; tOozWSadi--) {
            continue;
        }
    }

    for (int ybbuWfPyUYY = 1785422920; ybbuWfPyUYY > 0; ybbuWfPyUYY--) {
        continue;
    }

    if (vTrAtTha <= 65879.86728402234) {
        for (int gbnQKmASIxLqE = 226310600; gbnQKmASIxLqE > 0; gbnQKmASIxLqE--) {
            hUBWKnkgQ *= UoLNu;
        }
    }

    for (int YAYFPljzUmbNTAne = 1834386849; YAYFPljzUmbNTAne > 0; YAYFPljzUmbNTAne--) {
        oMrUUkWx += LysjaojBKz;
    }

    for (int uveCUAO = 383076536; uveCUAO > 0; uveCUAO--) {
        hUBWKnkgQ += vTrAtTha;
        vTrAtTha /= hUBWKnkgQ;
        xeNYiZMCwPlB = ! emmqjDmsZHYHzdck;
    }

    if (vTrAtTha >= -654460.9802579066) {
        for (int sbXOlSlbptf = 1179860775; sbXOlSlbptf > 0; sbXOlSlbptf--) {
            vTrAtTha = UoLNu;
            hUBWKnkgQ -= hUBWKnkgQ;
        }
    }

    for (int PYyTyzidcDKfPAa = 1326412290; PYyTyzidcDKfPAa > 0; PYyTyzidcDKfPAa--) {
        pEQSH += pEQSH;
        hUBWKnkgQ = vTrAtTha;
        hUBWKnkgQ -= UoLNu;
    }

    return hUBWKnkgQ;
}

string XVntlxcX::qAEzExLzyoxLKm(double JytYl, string yhmgGofBxT, string pZgBoGKNsYD)
{
    double GZqOFAawen = 527983.7240397009;
    int akMVCRyB = -554432675;
    int UhdgQCGPB = -1590234075;
    double toGYNwqKyePKbyGm = -978793.7868670381;
    double hmOaY = 867964.0248660458;
    double DaTJftVaydMG = 712496.9218300403;
    int BkqtUEtzKq = -336694645;
    string CRvTqbzQmjq = string("YndEQqogAxPedJUuMCcwQpSyYodkvHlsIGbvEQEGcCFpgpRcMighKdgPTITVsGLcrazaDKlcmJtjwSoesAtiAxGbnduDmEuuDkJDhBMEvSicMyCtzaXWXNVmahGtuPyvdfra");

    for (int LEXJbMYvbQ = 1951236350; LEXJbMYvbQ > 0; LEXJbMYvbQ--) {
        yhmgGofBxT += pZgBoGKNsYD;
        GZqOFAawen /= toGYNwqKyePKbyGm;
    }

    return CRvTqbzQmjq;
}

void XVntlxcX::tVFErYFaImer(bool MCPgprBNT, bool hzXfIMwSyny)
{
    string rmHcsfgVbPxT = string("YdTwumqyBhwowcchAwmflDxVnxBThdVXDLcEDEhOxXIzgooNIyBzsMUnzbBrATqzXplCXAuNNiqsWsqBJgPUthxlznENcvTKisKvlQrUmdsLkoCELmLNbAMSqnyMVbZblYlCGvInxsVkcazgpDjqdFeTaqZVKdjMaLHdHTjuHjWumXYwdYgJQGSWxRWRAGExJPAWlsTybQgzPLCnYLosjcpKVAq");

    if (MCPgprBNT != false) {
        for (int NSqCkVrDpMXdxKeO = 541239260; NSqCkVrDpMXdxKeO > 0; NSqCkVrDpMXdxKeO--) {
            MCPgprBNT = MCPgprBNT;
        }
    }

    if (MCPgprBNT == false) {
        for (int VkiUVQsRgOzuPVPe = 1376533251; VkiUVQsRgOzuPVPe > 0; VkiUVQsRgOzuPVPe--) {
            MCPgprBNT = ! MCPgprBNT;
            MCPgprBNT = hzXfIMwSyny;
            rmHcsfgVbPxT += rmHcsfgVbPxT;
            hzXfIMwSyny = ! hzXfIMwSyny;
            hzXfIMwSyny = ! MCPgprBNT;
            hzXfIMwSyny = MCPgprBNT;
            hzXfIMwSyny = ! hzXfIMwSyny;
            MCPgprBNT = hzXfIMwSyny;
        }
    }

    if (hzXfIMwSyny == false) {
        for (int TQMRAjK = 1301667204; TQMRAjK > 0; TQMRAjK--) {
            hzXfIMwSyny = ! MCPgprBNT;
            rmHcsfgVbPxT += rmHcsfgVbPxT;
            rmHcsfgVbPxT = rmHcsfgVbPxT;
            hzXfIMwSyny = MCPgprBNT;
        }
    }

    for (int aTwJQtIhP = 561083145; aTwJQtIhP > 0; aTwJQtIhP--) {
        continue;
    }

    if (MCPgprBNT != false) {
        for (int hRqTX = 1982599437; hRqTX > 0; hRqTX--) {
            MCPgprBNT = ! MCPgprBNT;
            MCPgprBNT = MCPgprBNT;
            hzXfIMwSyny = hzXfIMwSyny;
        }
    }
}

XVntlxcX::XVntlxcX()
{
    this->ebIrxA(-933567.1750623873, 512775827, 255657.760197081, 1101505365, string("KOYFYeKEuNBDjfQdBuYemFAVSjLVtVOwpvmnCgeHadQadnfmAoDOLojxzrLGXYFkulCtXtimrCWwPWRdusqmDUdvtOAsfaKGyqDGQmOWlixTyNpqBfzpAKmTVGaLHLMgSwAafqqaTbJgQAabPStMvnoyrJxIdZtcSJVdHuhsDeSPhsAXtByJZZfgShBgTuGLwNHPjw"));
    this->IKEfi(string("KQGrWIIDMTGwEvcovmCGUfKyVqYKcGlHqVbyWvPUzACyGRWYvDAkiryckGBFQOXNDjCMJYrHBoZTmHDzxoBLsYIfpUeFVpbVaicyYXSzEQMTfIfsGScJQkzlJQrjVcbAVEKYBlaUxMdnpbJgdwMHfiJ"), string("fZXahUZudpJZbTSJcESABwVCUqZceRoZIRdqXGrxkDQderghwYVnuuBiwKfiZQrZopbvAJDdanwMYNwiTMAHUNwLiefkZjsnKCvnZLOHTqfICqounBJ"), string("jhDxcdrrgfCHCBSROgDPPuJFkrnEMyzzbMPUYarmjUAAExfuDzgfVKAexaeciOeoYkcwxTDynYFeTJFwNdQGphlBTWLMNxjisZWYMIJUiiZYwYZPlqOPqtaJFFdYlDFvZkwhWmBEtcTMSiWwieygjzaRPvuYalsUuegdwZdKzDGOy"));
    this->ncBZjzKAeS();
    this->nnQnDuhuQjbKbf(string("CmMfHhvKgHwTnGTBRtsQSehHgaRNmyUPTreTauJpqPOaVawRFykBwSjGlshBvDHtIujaDpLAlvmqEgtOGUOvxvFBzEhEytFWltNyKPLqqoqhDgjwwWuW"), -689891014);
    this->jxCDQVdCNVybTneq(441825.673991557, false, 608447934, -1011821.2257880333, -1453537618);
    this->LPADhpkeaY(true, -124892.23170311097, -654460.9802579066, string("ebiugnnjVVtwNpaWiTqDzWDXeAiKuBmHoEEhYXbPjiysmPKDMc"), string("hdTBAkYCmpAjdJwVytJundPNLHMgohEwXLFvcJWntjHvJUVzUpnsWnrUEiVQvygwHkqWitWoDBEoKEMMQuSGQthkPyqXqyiwLusyrmEzCUPlboEqCdfVjNgDfAeBIxvToYabZQmTrNDngcvpgSidggBCRgvihLvKuiEeZzKVNKYUidIRquHDTZODJOLdpGAqvaGkrvLPiYobxQyfDmteVrPLJUsyzrpEiMrfqqcFYUrtqKTuTvmbxJeRH"));
    this->qAEzExLzyoxLKm(62512.45396894721, string("kmWVtDHQlLobmOFtyWjxgolCydUYawLHpOoEfKQmxKtJSpfdmMPrOALaEeInwuFtbbKftCIyWdCsecbPaSEWWuNiZUcHLreDuIlJwkFxtdIqFbjwwSalLsTkrPNkk"), string("EopGOtWhlWv"));
    this->tVFErYFaImer(false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HZhUgsPLyGqkQrb
{
public:
    bool TrcDhNtzDVhHY;

    HZhUgsPLyGqkQrb();
    double cQeiPxVufucXc(double yTdXQyabqL, int WgcUXCKUIDhe, string CyduYVyBDGDzTFyX, int BYpbcSpBP);
    double BsfWRMoqbr();
    bool fpAsErbSzU(int kbgkUnbOtgLUQ);
    string JGzudISxuckDiTR(int FWFqEApNw, int CSCPueSTaesHfNPD, int JWCzr, string eiebcHzZ, bool rWXxVkHxothaKu);
    int JqqqVrAZKzHKBgKK(int csfdvvAnblSzrMPn, int LVoWvcoTAMwtRjxI, double sAeNFQIPPHn, bool RFqgN);
protected:
    int XBziqbDANMmBwL;
    string ZhCJfmxCv;
    bool WBAHMoBs;
    int CeTsZegjxPNnbR;

    double yjwRAPJpR(string dZOue);
    void xujWWetabJbGWyKE(string bizBKXPcxIvI, double sgkKBzfCOAqTLNg, int YJQvpDxkxAypJlz, string UEDueW);
    void CQHHOgVy();
    double JKUqhLUguKHgcr(double fTvpvpJOQfWs, string MnxYHs, bool cGTgwiX, bool OktQWI);
private:
    int LFPJXRSUOvXFxWc;
    int qtJcWT;
    string qJBckPHBTDNHp;
    string ucfqjAKMlnA;
    bool dwfPw;

    void EvZGgPm();
    void AqMMpGcZLA(string bDVFMfBr, string tnfGrPlArM, string aXweBhxHzrqkHod, double YAgdrhACduixs, double qbqCyluWsVKUC);
};

double HZhUgsPLyGqkQrb::cQeiPxVufucXc(double yTdXQyabqL, int WgcUXCKUIDhe, string CyduYVyBDGDzTFyX, int BYpbcSpBP)
{
    double NPpJlElLq = 327664.1985164623;
    int sDLMFOpnZEv = -1468607458;
    string OkwzX = string("EgeUhsjTTtfXVprWxVgkmxQReFpVlmQeUYoKoHmKRZNSCXGyJtnGfRORdIYMJLhzcqgBAvccVccNIodPFUpZ");
    string smcGO = string("imdwKTaQIuxbCfQHoBXTdZrDxYiw");
    double CPqhLfcYDVee = -982118.5579279445;
    double TRgoH = -455940.63084829645;

    for (int dNYIybSYI = 918819512; dNYIybSYI > 0; dNYIybSYI--) {
        CPqhLfcYDVee = NPpJlElLq;
    }

    for (int zBVxrLqPwDMz = 439903789; zBVxrLqPwDMz > 0; zBVxrLqPwDMz--) {
        yTdXQyabqL -= TRgoH;
        sDLMFOpnZEv = sDLMFOpnZEv;
        WgcUXCKUIDhe *= WgcUXCKUIDhe;
        BYpbcSpBP *= BYpbcSpBP;
        CPqhLfcYDVee /= NPpJlElLq;
    }

    for (int MsKafUuWKZEl = 278083376; MsKafUuWKZEl > 0; MsKafUuWKZEl--) {
        BYpbcSpBP = WgcUXCKUIDhe;
    }

    for (int CSKYlSeS = 356324418; CSKYlSeS > 0; CSKYlSeS--) {
        WgcUXCKUIDhe += WgcUXCKUIDhe;
    }

    return TRgoH;
}

double HZhUgsPLyGqkQrb::BsfWRMoqbr()
{
    int cYOqdHLYOldsAlm = 868640145;
    bool KrWbqlEKT = true;
    string PblxNvs = string("zTzcHFmTmNBrzRvGxnkVOxtWRvijqNF");
    int OWNcicQDOFLpbHa = 1381821628;

    for (int JFrZTilZRRF = 1629390272; JFrZTilZRRF > 0; JFrZTilZRRF--) {
        OWNcicQDOFLpbHa += cYOqdHLYOldsAlm;
        OWNcicQDOFLpbHa /= cYOqdHLYOldsAlm;
        OWNcicQDOFLpbHa = cYOqdHLYOldsAlm;
    }

    if (OWNcicQDOFLpbHa > 868640145) {
        for (int JSBliLFM = 1864699284; JSBliLFM > 0; JSBliLFM--) {
            cYOqdHLYOldsAlm *= OWNcicQDOFLpbHa;
            cYOqdHLYOldsAlm = cYOqdHLYOldsAlm;
            cYOqdHLYOldsAlm /= OWNcicQDOFLpbHa;
            cYOqdHLYOldsAlm *= cYOqdHLYOldsAlm;
            OWNcicQDOFLpbHa = OWNcicQDOFLpbHa;
        }
    }

    if (OWNcicQDOFLpbHa != 1381821628) {
        for (int eZREYzvbPkzpwEo = 421996658; eZREYzvbPkzpwEo > 0; eZREYzvbPkzpwEo--) {
            cYOqdHLYOldsAlm += OWNcicQDOFLpbHa;
            cYOqdHLYOldsAlm /= OWNcicQDOFLpbHa;
            cYOqdHLYOldsAlm = cYOqdHLYOldsAlm;
        }
    }

    return -882446.960658227;
}

bool HZhUgsPLyGqkQrb::fpAsErbSzU(int kbgkUnbOtgLUQ)
{
    string iireXvmzuXEp = string("eVDYrdlJILrPZTMjGIVUcagvCKZRwetZekRYPWedYZrXlkvNQPBfPMEpeZOyBMLFOoXrMlJxlFHTbHCwmisuLFHjYMqNRUCzvEeQNQPm");
    int soDGegkK = 1274632731;
    double oWZhwKjcuL = 566647.6679713653;
    string CPVvCC = string("jUCVhjqnZctiIOiiLFQXnbmeHUZyfEnYUazlfCDlqVGCIy");
    bool OZpsetbfTWrSIIUp = false;
    string nplmYzKhBY = string("mIvVeLylEtjTlGuqYVgrhadpgPrNIimESOrQdlxzvkPusZpYhnAiZS");
    string IMXbMz = string("HorNUMJIvbqUgOFuSkFsSYaICrwUnQuDRTyuSZNc");
    int ClbkPyscx = -888623643;

    for (int OpZYuwzergORdtta = 224488755; OpZYuwzergORdtta > 0; OpZYuwzergORdtta--) {
        soDGegkK += ClbkPyscx;
    }

    for (int bggsqlMrmcfpSk = 1469628154; bggsqlMrmcfpSk > 0; bggsqlMrmcfpSk--) {
        nplmYzKhBY = iireXvmzuXEp;
        CPVvCC += nplmYzKhBY;
        nplmYzKhBY = IMXbMz;
        nplmYzKhBY += CPVvCC;
        iireXvmzuXEp += nplmYzKhBY;
    }

    return OZpsetbfTWrSIIUp;
}

string HZhUgsPLyGqkQrb::JGzudISxuckDiTR(int FWFqEApNw, int CSCPueSTaesHfNPD, int JWCzr, string eiebcHzZ, bool rWXxVkHxothaKu)
{
    double SwPxL = -75827.9006108072;
    double luWogHlH = -1009928.0372459216;
    string TjwSDaoVFaH = string("dlEdhtPwLYhPhsGvFaUjMZpQwtZAUayUyRIdirKSrVyUQhGVjazgNXLynvgZxkreJBgbsJoHKxOGTDsLXwwmAdxhMeKxtRAoCkpfJianjgbsFOVmlmaWaqwvfQOqetvPMVkmmAZcYcUZvGJEgbsPJTsablWqVJAqwsOwFZLtVeSA");
    bool unZzMrm = false;

    if (TjwSDaoVFaH == string("dlEdhtPwLYhPhsGvFaUjMZpQwtZAUayUyRIdirKSrVyUQhGVjazgNXLynvgZxkreJBgbsJoHKxOGTDsLXwwmAdxhMeKxtRAoCkpfJianjgbsFOVmlmaWaqwvfQOqetvPMVkmmAZcYcUZvGJEgbsPJTsablWqVJAqwsOwFZLtVeSA")) {
        for (int YlNzupb = 2008139867; YlNzupb > 0; YlNzupb--) {
            continue;
        }
    }

    for (int TCiEeU = 1691525979; TCiEeU > 0; TCiEeU--) {
        unZzMrm = ! rWXxVkHxothaKu;
    }

    return TjwSDaoVFaH;
}

int HZhUgsPLyGqkQrb::JqqqVrAZKzHKBgKK(int csfdvvAnblSzrMPn, int LVoWvcoTAMwtRjxI, double sAeNFQIPPHn, bool RFqgN)
{
    string sHnsErrFGEaFvz = string("ndNARbqpCDHjiNzllZgJuXlvSmLfVRbylvurNwMxz");
    double lIXOXNoQnlcJuVk = 553911.8509604168;
    int FuAFPU = 16461968;
    int MaQoHQiRCqZL = 2116901170;
    string ZdVqOOjiq = string("eHmjXuXHZNnVemhRaOkeISKuLgQXLPIleROAVritbdXaQvjTuAstESbmpfOkqqYEHdXhxnsyClsNRWmoWgcqjkQMFDfrETVFTUohIktAMFRGOvBErKQWSDEqIhTtEadZZKMLnmSYKKzZLbciNjlCZNTFalhhGHAmXQfYhsVGszfzomkArEKiPvLTJvOXFJIvhABtKmYoJCxWizfkJhdjbekJyWgLkeJQxlBSnz");
    double jUuDYzuAmsV = -449939.92687336385;
    int ixrQPAPCicqX = 1751603425;
    double weqBSy = 262154.034617625;
    bool HVxixEOqo = false;
    double tBHxKLmAFi = 58194.5889087642;

    for (int oJhwl = 1951527137; oJhwl > 0; oJhwl--) {
        sAeNFQIPPHn *= weqBSy;
    }

    if (tBHxKLmAFi <= 58194.5889087642) {
        for (int cAnEX = 531778401; cAnEX > 0; cAnEX--) {
            ixrQPAPCicqX *= MaQoHQiRCqZL;
            csfdvvAnblSzrMPn *= csfdvvAnblSzrMPn;
            weqBSy -= jUuDYzuAmsV;
        }
    }

    return ixrQPAPCicqX;
}

double HZhUgsPLyGqkQrb::yjwRAPJpR(string dZOue)
{
    string YaUnitxILHbk = string("CTWCdWThMgoqSdxVcmtXlpvbnNmZoVFKzowcgizWiiyCsqnoMLpQZaiERDhlDWGSb");
    string yreruU = string("eliwrKeFaiOUPdsGkQObiiCHGiYsQKPTBZKuVAxMiTgKBXD");
    double GfobefhqLULdz = 293524.3346687086;
    int LjqKQgPu = -1491280015;

    for (int wtEmNx = 601284427; wtEmNx > 0; wtEmNx--) {
        YaUnitxILHbk = YaUnitxILHbk;
        dZOue = YaUnitxILHbk;
        GfobefhqLULdz -= GfobefhqLULdz;
        LjqKQgPu += LjqKQgPu;
        YaUnitxILHbk += yreruU;
    }

    for (int czdSKfKS = 1879520672; czdSKfKS > 0; czdSKfKS--) {
        YaUnitxILHbk += YaUnitxILHbk;
        dZOue += YaUnitxILHbk;
    }

    for (int QdtAhB = 2035292488; QdtAhB > 0; QdtAhB--) {
        LjqKQgPu *= LjqKQgPu;
    }

    return GfobefhqLULdz;
}

void HZhUgsPLyGqkQrb::xujWWetabJbGWyKE(string bizBKXPcxIvI, double sgkKBzfCOAqTLNg, int YJQvpDxkxAypJlz, string UEDueW)
{
    bool saSzVdjvLwO = false;
    double YNNJNAIeG = 694971.117281746;
    int SUzgmXAEPoSea = 2028767514;
    double YFMaTzFCZfxVB = 394381.7625799416;
    string nhsDJWDE = string("VhoeJxZmpXWGQgtFhaVqAAJIICKyJXAafBXIVUQewPCIPiafpdbRqtWhgBPhHffZbxgyKKqtkKZLpDNkpoxQDkkOfSuvQtqboxfOqLnoZBydanRcSukeYjxBuZXdLSZCOBBpPyFrTBYjPAeZKBpuwxucEPBePqpBlJpnaFVbcEcZiuIxkslDheJr");
    string nLaaPeFiOlyFxfD = string("HWvFhntxcfLsbSpLxQiOsNDSJUMJzVkalkzphJvdbqSyupXmOVkJNhXZBXCPYXzKHqMGNiMGCWlyLcSoPa");
    bool EfRDBNVnxpwxq = true;

    for (int crlbALiRHPMVkTpr = 315023001; crlbALiRHPMVkTpr > 0; crlbALiRHPMVkTpr--) {
        nLaaPeFiOlyFxfD = nhsDJWDE;
    }

    for (int orOpNLSilHy = 1406397081; orOpNLSilHy > 0; orOpNLSilHy--) {
        continue;
    }
}

void HZhUgsPLyGqkQrb::CQHHOgVy()
{
    bool xwBMrvqKEPLKgQje = false;

    if (xwBMrvqKEPLKgQje == false) {
        for (int KsYyrwXLApAiKgOo = 1418321281; KsYyrwXLApAiKgOo > 0; KsYyrwXLApAiKgOo--) {
            xwBMrvqKEPLKgQje = ! xwBMrvqKEPLKgQje;
            xwBMrvqKEPLKgQje = xwBMrvqKEPLKgQje;
            xwBMrvqKEPLKgQje = ! xwBMrvqKEPLKgQje;
        }
    }
}

double HZhUgsPLyGqkQrb::JKUqhLUguKHgcr(double fTvpvpJOQfWs, string MnxYHs, bool cGTgwiX, bool OktQWI)
{
    string nYxLHiUzsfA = string("owGKgTakkyifZSRKmiMsRSUByjOQPDIttMEMrRDqLmKuePStrBpxbBbMDdpdHhCsjcRdxvhQrYGsnLhqBtqberZoCQstNngyXTcBaLOSiggioJEBgvVAMcUGyEumOsfoVigWjhPzUEHsefWzhRcmMTchGViqPFjdcshberYMxyrcoYnbkiNKdexodSQurbwfkVoPFpKuROnjEXBeSACkW");
    int shDSphC = 806339333;
    double lFyhOpFQdbDA = 164277.10473496074;
    double rZakETjGpfWabq = -99489.8346908219;
    int pgJgfeQrfXrfO = -2026792141;
    int QpxpHeufJAa = -1379528212;
    int zFxaBHKH = -76152571;
    int XXUqbKRSGvNIH = -858163923;

    for (int UHLtXIu = 1330113585; UHLtXIu > 0; UHLtXIu--) {
        fTvpvpJOQfWs = fTvpvpJOQfWs;
        cGTgwiX = ! cGTgwiX;
        cGTgwiX = ! cGTgwiX;
    }

    for (int BcsbO = 1997556434; BcsbO > 0; BcsbO--) {
        continue;
    }

    return rZakETjGpfWabq;
}

void HZhUgsPLyGqkQrb::EvZGgPm()
{
    bool rVwCuqGgDkmoEawS = false;
    double zSvywtameszhH = -29322.599588791905;
    string dFaZCOpZe = string("jFYcdNJohBvwiYDvLvsSFQDfRHYdXsefMWjmZwpDzvPXJxczdRLelHEmgmfLUUMuAlDRSJDUKjJDDhEDoiaAeXlLjTqytbuMdAjZfZzKcPsekjXdaDWPygphVsTxfs");
    int XMYaRhqBDVJf = -1458535177;

    for (int WHljxAcYXxYg = 205201578; WHljxAcYXxYg > 0; WHljxAcYXxYg--) {
        continue;
    }

    for (int aCijLTpu = 1707393867; aCijLTpu > 0; aCijLTpu--) {
        continue;
    }

    for (int atlakzbSXIoO = 1136211408; atlakzbSXIoO > 0; atlakzbSXIoO--) {
        zSvywtameszhH = zSvywtameszhH;
        dFaZCOpZe += dFaZCOpZe;
        rVwCuqGgDkmoEawS = ! rVwCuqGgDkmoEawS;
    }
}

void HZhUgsPLyGqkQrb::AqMMpGcZLA(string bDVFMfBr, string tnfGrPlArM, string aXweBhxHzrqkHod, double YAgdrhACduixs, double qbqCyluWsVKUC)
{
    double yOgAKPsyeCLOXw = -527447.0395354407;
    bool vTIKNAgRJelypXcR = false;

    for (int xHmjF = 1114663479; xHmjF > 0; xHmjF--) {
        bDVFMfBr += aXweBhxHzrqkHod;
    }

    if (YAgdrhACduixs <= 381845.1205429464) {
        for (int aTHwiLk = 925270784; aTHwiLk > 0; aTHwiLk--) {
            vTIKNAgRJelypXcR = vTIKNAgRJelypXcR;
            bDVFMfBr = tnfGrPlArM;
        }
    }

    for (int YMTzjLnNi = 1340484640; YMTzjLnNi > 0; YMTzjLnNi--) {
        YAgdrhACduixs += yOgAKPsyeCLOXw;
        tnfGrPlArM = aXweBhxHzrqkHod;
        yOgAKPsyeCLOXw /= yOgAKPsyeCLOXw;
        tnfGrPlArM += bDVFMfBr;
    }

    if (tnfGrPlArM <= string("wzTIiEkrIPeOsVddaIFNjJGwcQMXisGtgBwiAuAbsUWyoCrkcNUqeUBOYnsxQyVkzUZjaMkRDmFWPuSIsrblklOFfzdKNeOMbhvcnklgkLXHyijpqcyMbPKIVymJDNTPniGmFDNZXMk")) {
        for (int uUblEFlGydfAN = 738969462; uUblEFlGydfAN > 0; uUblEFlGydfAN--) {
            qbqCyluWsVKUC -= yOgAKPsyeCLOXw;
        }
    }
}

HZhUgsPLyGqkQrb::HZhUgsPLyGqkQrb()
{
    this->cQeiPxVufucXc(-354619.0753865762, -806084995, string("wXnvApGCGHudPKfdHYODWayzqjqFwrtinGhRdCgppfpLNeeQxvMUAlFNBdUSELOBHsBxDDsDtgtJtwNJyFsqneBCIfqsiKEWEAxGmxVMgyDyLGonykvgDgvVoUiuBHjvTkspJAoeDxtvhFmRz"), -571805416);
    this->BsfWRMoqbr();
    this->fpAsErbSzU(1321102087);
    this->JGzudISxuckDiTR(-1720322950, 1642628886, 2034948188, string("KpmdTqEfgIqSaqmdlYQBgikyWXqbwFtHSbhhRPlItAEvdPjStsKqexLJTNxMlLbYhpQQuufPrbPdjRRfqWaOgoFqMdkNYDpPAE"), false);
    this->JqqqVrAZKzHKBgKK(-946149622, 210472888, -816172.9526104699, false);
    this->yjwRAPJpR(string("AmBERpDIwTTSdgEfLDJvIaIihjMHwydFYngwVRNPWxCesIPVmpYsZGubADXnodYpRsblOYqhRIGTtRJVCHxuhqAEhrEKdzhWcPtPNWxYJmrscswLvyJnkNrYnZlvMrPAZGpUadahkozTaghecHSEpFoxazkBOwEarhZEtMcggDmXxmHQeyyPjBxVTfAbQqvxLPp"));
    this->xujWWetabJbGWyKE(string("HfhQJpqOhHjwQpGRLtduMRoYXZUamiRGgmRASRftcgwsUlAarLlTo"), -993544.9985109245, -1999318708, string("YKVkwekgswGrYmWhZHCicugLIdAKIPnvSmHLmPkwVPIrsNkQGIjcjtMYpQcFdRuKEjxfIhdiYhoSxyYgZEgttYQdZANOQQoLKEXrJWmLDRAzFhRBkOJFrQEevKunjksjxymkVRxkJrTbGBBoTsIzrSMaHtFuRdIyoNBpGdeIUNBazshdxEWXcFuhlEwMaRGXMTvuNpIuomD"));
    this->CQHHOgVy();
    this->JKUqhLUguKHgcr(906468.2955488525, string("HIVuRsBWXaCEHXSITqbuBlFpLuQNJndUzHusrpRajRAkTFBopoCBUUeLGLnrzE"), true, true);
    this->EvZGgPm();
    this->AqMMpGcZLA(string("YRsBUJkLtdHekCfJUZNjLSbuCRjCbCVKLgFNugzHOeQQUJAsORlGogUQoSldflJoTATed"), string("wzTIiEkrIPeOsVddaIFNjJGwcQMXisGtgBwiAuAbsUWyoCrkcNUqeUBOYnsxQyVkzUZjaMkRDmFWPuSIsrblklOFfzdKNeOMbhvcnklgkLXHyijpqcyMbPKIVymJDNTPniGmFDNZXMk"), string("VdzXxbwBWifXPoPFKlWbARPmbambiisujOirHAWNzHWTjHwCnyyDZfeLqKXGmRiOHKUojJSfwBwPpclpKZyNTzKTolzXwhmUUXoaOjKIGjwishqidkQlDakeMllXDyFiYsLDwtDHHfVWatYunagOsfyOsjceSsVcbtCXXmppJKdcAqFzEVbIiQYRLHKEmhxXtLEnwyEoeDsdyBYmWwhOKWyEnDufMKeOFzTtOvyvKWPYghMYlAYmQbdXN"), 701636.9478029426, 381845.1205429464);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class jHAYdoUiunSYDMU
{
public:
    int DpijIxOlRPLcWEGm;
    double bjsghHSGxZcU;
    int LZREMblORz;

    jHAYdoUiunSYDMU();
    bool IYLsdMDUq(int aYcCYlLVBWolPy);
    bool SezmjcaUETOZQv(string JKxEiBWF, string dYJFltVfGSzsF, bool BKkhJ, string wDJApfChOY, bool QdBjtE);
protected:
    int dqlXSYmoIPcxrhc;
    string OOKYJcXYmf;
    string sxKhYhFZrFJN;
    bool QerbTvo;

private:
    bool oNrJwtCZxcFyJN;
    string MigzDowJJ;

    void fZpWUaidCJA();
    bool eOHQzY(double AZOxmMdLwxS, double iDjIMksMhKQGeGKp, string gBgOlKWwS, int orVBYZOAPyxiwlUj);
    int mlpNNHjoGR(bool fmvNsBinwsNk, bool KOyzi, bool yqETOpLkhXXEbBs);
    string GTtFVgVmWvyUM(double zuCZbjV, bool rjGky, double BlxSVOpIAV, int DcPaJH, double jbMBBhntQFCgRS);
    double hulzYFPoikdFNI(string hPXdxQH, string vmIuXtOyMnATZ, string JabgVnySWxaPOsP, double ZcpmPLvNyD);
    int NwKsfmMS(double fmOqMonX, string hPeSnasXKH, bool XcMctbpeyOGT, double YjyBUMTeGBFWWwF);
    bool kZvuUIMlyeAOYnEM(string imZDSybaVcQ);
    void vaVLKmItUkFkPW(int CRUoUI, double swVOsljul, double flFwVBhoZ);
};

bool jHAYdoUiunSYDMU::IYLsdMDUq(int aYcCYlLVBWolPy)
{
    bool quUPnhgBfl = true;
    bool ueYMPkorKo = true;
    double dOlHSqSMCnaCoFHj = -166122.9952248374;
    int TXwgZBka = 451767802;
    bool MZyhhyU = true;
    bool YNrQEutygP = false;
    int GtYlIorSmvq = -192245539;
    double nQqoDBMxsY = -262223.7889490549;

    if (dOlHSqSMCnaCoFHj > -262223.7889490549) {
        for (int SncElNlzdXWjQmj = 2033935387; SncElNlzdXWjQmj > 0; SncElNlzdXWjQmj--) {
            dOlHSqSMCnaCoFHj += nQqoDBMxsY;
            dOlHSqSMCnaCoFHj *= dOlHSqSMCnaCoFHj;
            TXwgZBka /= TXwgZBka;
        }
    }

    for (int MXaoCA = 824732996; MXaoCA > 0; MXaoCA--) {
        continue;
    }

    return YNrQEutygP;
}

bool jHAYdoUiunSYDMU::SezmjcaUETOZQv(string JKxEiBWF, string dYJFltVfGSzsF, bool BKkhJ, string wDJApfChOY, bool QdBjtE)
{
    string ThLoDaAdnvA = string("TqakmZOPxkltsjkbABorInkTcKcGmnYIDqvWsUfbkgXDQfeKeTAZXdwvvjJtlPggSIIENLsIatSzX");
    double ZTyrzgVqUtQVTZ = -625989.8723109104;
    bool WiEFE = true;
    string BxSRfTI = string("QFSmnVCAGAjDVYAFCmldnmMgHWnhBibgBIKXcdERNgpRMvdUeveeLHQrZpGyZBLuHNfBXYTcnEvGirJZLYS");

    for (int thFLWPQBC = 1229954212; thFLWPQBC > 0; thFLWPQBC--) {
        continue;
    }

    return WiEFE;
}

void jHAYdoUiunSYDMU::fZpWUaidCJA()
{
    string LTuRty = string("sdgvgfchRnZuFHTTBLFAIMvohnxRAorrdDBAdRGTRaVxuytgSmlbfhELfrWUFzEEBsfanLGdiYvjXLZVTsIYODGRRPhlrrJhJRSjgQjxQcdYNZzSSpGrFOkJVZbjRbqNmvQSofSfTGXgWuJngZKzFTQtvfRjOGuXciVPJbZtBAenjRCKfbgTgOgEFanBuggaQQnTTsXgLrVkpOCmiRSRusYFJWblnbq");
    string ToTbxMoqvSCz = string("tWxEGoZhMHLewmkPSIQSPgUJPtBXfzcDTsQUKVLKoYerzSEMVYOLyaQYHBTwskldBUvjcsSeQiayCaBvbuGEUBXvGhGGixEtkGsfjsXpZNppBYqIbPkfEYfcbQweUMXhievDmQhxLdfogyQPYgmhdPgHJDQaMjRvTJOJMBPgoiylGBxpfeJrUWKIcvcjRUZxwqQKzokmHrWVQkUfXXThfKrDcnqrWrbcNkbnvp");
    int LoyjPFOisZdu = 1981435053;
    string HQxcAnkPESJ = string("yqAXtOvrfXVXuoMMxcDYknKrZsHBfPrbOroJndOVciFyZplRwuDYawVEFRdJHGWCTWXFxiQdpzgfdoUhpDYyxPcrZmGvLiACPdPSsELqaIEmpAELjLXFdGqgCFxJxBTuccjOxjAIEpBayvuHrocnNQPlkUbxGjxTuArWYQDPwnHbAISwKPl");
    int PwKjsfNUyoHUBw = 2013286367;
    bool UIVWXjjnhiPGcJ = false;
    bool PexwAjLeeAfu = false;
    bool LSRnOhcFFTHvJOE = false;

    for (int AviCYsWH = 1549511422; AviCYsWH > 0; AviCYsWH--) {
        UIVWXjjnhiPGcJ = LSRnOhcFFTHvJOE;
        LSRnOhcFFTHvJOE = LSRnOhcFFTHvJOE;
        UIVWXjjnhiPGcJ = ! LSRnOhcFFTHvJOE;
        LTuRty = ToTbxMoqvSCz;
        HQxcAnkPESJ = ToTbxMoqvSCz;
    }

    for (int lEgwztRlef = 1463233624; lEgwztRlef > 0; lEgwztRlef--) {
        LTuRty += LTuRty;
    }

    for (int PRfJseUjth = 1729367428; PRfJseUjth > 0; PRfJseUjth--) {
        PexwAjLeeAfu = PexwAjLeeAfu;
    }

    for (int YycRXsNCbP = 2036882566; YycRXsNCbP > 0; YycRXsNCbP--) {
        continue;
    }

    for (int dVekPSZAQiPk = 1640322271; dVekPSZAQiPk > 0; dVekPSZAQiPk--) {
        HQxcAnkPESJ = HQxcAnkPESJ;
        ToTbxMoqvSCz = HQxcAnkPESJ;
        PexwAjLeeAfu = ! UIVWXjjnhiPGcJ;
        ToTbxMoqvSCz = HQxcAnkPESJ;
        HQxcAnkPESJ += HQxcAnkPESJ;
    }
}

bool jHAYdoUiunSYDMU::eOHQzY(double AZOxmMdLwxS, double iDjIMksMhKQGeGKp, string gBgOlKWwS, int orVBYZOAPyxiwlUj)
{
    double MhtelswulTPsh = -874387.3049286153;
    bool SiHaOSzIEsBaNG = true;
    double IWcvi = -781931.3240295975;
    string eEWKUbwT = string("RtNVjOMJqJOiKJtDBJriBGWezlNqvzidVIQQAcijCHVPhbXmQYVyzgrWuzZoZCtwczLxtjIKESTeqksTmmGsNhLwklTIMmAVhSVC");
    double rjUOOLaqZDnymx = 1018973.4822195082;
    int OYLXguLRd = -1308736634;

    for (int okunAokRUAapUt = 137796197; okunAokRUAapUt > 0; okunAokRUAapUt--) {
        IWcvi += rjUOOLaqZDnymx;
    }

    return SiHaOSzIEsBaNG;
}

int jHAYdoUiunSYDMU::mlpNNHjoGR(bool fmvNsBinwsNk, bool KOyzi, bool yqETOpLkhXXEbBs)
{
    double RZnnnVRbXD = 60900.38616332653;
    int ifsDv = 232852036;

    for (int PtGmoYKBr = 522184664; PtGmoYKBr > 0; PtGmoYKBr--) {
        KOyzi = yqETOpLkhXXEbBs;
        fmvNsBinwsNk = ! fmvNsBinwsNk;
        ifsDv -= ifsDv;
    }

    return ifsDv;
}

string jHAYdoUiunSYDMU::GTtFVgVmWvyUM(double zuCZbjV, bool rjGky, double BlxSVOpIAV, int DcPaJH, double jbMBBhntQFCgRS)
{
    int ZURBckdOcIYVw = -609404649;
    string XPXjTFlpIYODUbu = string("lQRAPtNGcYsNQydmZtyMAaPZaDpWUFxbPCqcZBXNcezCmNzAagrCJjXkdSilZCbXyiiwSZjYCuGHYjkVqyIbPUziSBOXwmCtqxatFLWxPOjhtQlPUZMDkACkUc");
    bool AyWxVGFdt = true;
    int ppMIRAfOiZMVlgV = -1116270609;
    int nVOTFnxbxQvtY = -612966948;
    bool ObxpjkVOweDZxNzw = false;
    bool siRqzdkDcnB = false;

    for (int wWmxFUomP = 1639824704; wWmxFUomP > 0; wWmxFUomP--) {
        BlxSVOpIAV = zuCZbjV;
        ppMIRAfOiZMVlgV = ppMIRAfOiZMVlgV;
    }

    for (int pxLjBWT = 662973990; pxLjBWT > 0; pxLjBWT--) {
        continue;
    }

    for (int DfLLaRYEdQCCOE = 1228372374; DfLLaRYEdQCCOE > 0; DfLLaRYEdQCCOE--) {
        ObxpjkVOweDZxNzw = ! rjGky;
    }

    if (ZURBckdOcIYVw >= -1116270609) {
        for (int ErSVVK = 941079455; ErSVVK > 0; ErSVVK--) {
            continue;
        }
    }

    for (int cavQHedgG = 1057980001; cavQHedgG > 0; cavQHedgG--) {
        DcPaJH = DcPaJH;
    }

    return XPXjTFlpIYODUbu;
}

double jHAYdoUiunSYDMU::hulzYFPoikdFNI(string hPXdxQH, string vmIuXtOyMnATZ, string JabgVnySWxaPOsP, double ZcpmPLvNyD)
{
    int OZWxnaapeEWuWAYa = 496372412;
    double FDGjBntjNgrTDtjD = 598409.9495571494;
    double nlpCWkgwwCLH = -1004566.9343566314;
    int VnqAGNKZJRyTHe = 528750397;
    double nwpIeTPYLqj = -565964.6078600672;
    string hezXkNuj = string("LTFgQEIWWrBoJyozrZqNgSDzCHYFSPkQRcIWlhAFnbTCchZdcyxFHsUkuuOlvBwmfyuZSUsMeVdIDacnKBZiYihVdBYtISHyqKuuRahEqegTlvXHdTbtCNWMQyqvWoQZZiHfleHIZBkLVKTLeTFKc");

    for (int PLqLafvmbARzSqu = 524185574; PLqLafvmbARzSqu > 0; PLqLafvmbARzSqu--) {
        nlpCWkgwwCLH /= FDGjBntjNgrTDtjD;
        JabgVnySWxaPOsP = vmIuXtOyMnATZ;
        VnqAGNKZJRyTHe -= OZWxnaapeEWuWAYa;
        FDGjBntjNgrTDtjD *= nwpIeTPYLqj;
        nwpIeTPYLqj = FDGjBntjNgrTDtjD;
    }

    for (int wUOcRROdfCnfMvNt = 1258899079; wUOcRROdfCnfMvNt > 0; wUOcRROdfCnfMvNt--) {
        OZWxnaapeEWuWAYa += VnqAGNKZJRyTHe;
        ZcpmPLvNyD /= nlpCWkgwwCLH;
    }

    if (nlpCWkgwwCLH < 38789.45817060448) {
        for (int JpGbgvHLPrGFkeTV = 2078086379; JpGbgvHLPrGFkeTV > 0; JpGbgvHLPrGFkeTV--) {
            nwpIeTPYLqj *= nwpIeTPYLqj;
        }
    }

    for (int ndlwnPUeKveDmc = 261493602; ndlwnPUeKveDmc > 0; ndlwnPUeKveDmc--) {
        ZcpmPLvNyD = ZcpmPLvNyD;
        VnqAGNKZJRyTHe += OZWxnaapeEWuWAYa;
        OZWxnaapeEWuWAYa *= OZWxnaapeEWuWAYa;
    }

    for (int wzFOleAAkxOynRgy = 885096656; wzFOleAAkxOynRgy > 0; wzFOleAAkxOynRgy--) {
        vmIuXtOyMnATZ += hezXkNuj;
        hezXkNuj = hezXkNuj;
    }

    return nwpIeTPYLqj;
}

int jHAYdoUiunSYDMU::NwKsfmMS(double fmOqMonX, string hPeSnasXKH, bool XcMctbpeyOGT, double YjyBUMTeGBFWWwF)
{
    string CwISsSEgyufDygIr = string("OivnSJLkQVuCEEfCewmpjvggYapaWPlGnGiSghoyUvCwkXVTOTFNTvmpqXmiRigbkXJJuBJpmWuBetbaDydJFmecFAjHmWflIoyFJUnBYAicvodWaLuadfYqfANlHibjKFCWNUFCvqLJUFBSlshgpqAzxXztipSCzNtehXgKWeSUaHfyeKEzaVehsAKBqGmaEfUCUYwbGHnSCsLsIboiZSu");
    bool QxVquWqBvFjQbZJ = false;
    string qDnRDcXUNCSAUdVr = string("bWMNTOreNOVubZybIaIFHhIchDMepkpKmNlCxDvneeEnvKbOiYkzzvXRZpMFSgSJSNvGZzeaHpGGuCReReViOAzHVgGVFPcDnCpZMUkLVKWUORpRMjZqoyeNExcSCtjGINcNGTRpoISgDVUaTqPogdrUnuwZhPwUryexqjEXMpvrHufqXOfNnddLIRwRVBhYsvEKmYaQkmHakWEufmpIgkErXpHgApwite");
    int kbuFsycjYnnMs = -1025719402;
    string xvPMgFqXRf = string("ORmnJwBBBXdMxpjGNItnYbzUjlpdkZKRSkmzQdDbcyNDESczvlWymAoeVsRxFPTJvYZjUmIcfRZoOHrTZrmpTXlHDXxcnktVWLQzcntzZsCDPFjKPGoqJQU");
    string yElkMdajQca = string("sccQswKWrMTXFYdXESRXGWqpWGOytWxrBZfYhwlJrmgPwQsDLxpQOzVWKn");
    double SgSIlnuPRpqgdjVH = -727137.1450525083;
    string CwShc = string("tspVUXaHjuWETzuEikvTBOeAehxSKBXGcSmsaTnpTodAXkpgOOmKXvyipugpHrajBXiZkPanoXqOScSlESejyxVJvrAXYYlnwDpTfXiFPXDYJpcRJhZEvTqcwimbiLgx");
    string SKIfITjWfwp = string("ZJYraOpKODuRPwHqwmYHUEhvFyHySLTtujUWSqPhSspwUMSjVTtgyOnsEOBdAaUJSDnbntjJVlmBVhxxzKOPMbDStVITYQsAluItipggrKAbNwizXkqkByoicTqjEtYzkLDFIghqpjhBzXQiAihFliqkKXZXxrrLengZpmGndLCWFzNigDGeHgrVOnhiCdobdODAintLpgGvnhXhuCvpLNnlUtuwyyTSzXZLaWnusjzGtDNyxETsFYj");
    string yEJDWwsJfVt = string("anfoLVNPUQOTTtIMILWCbJQGtlZLHgRCwTCsUe");

    if (xvPMgFqXRf != string("tspVUXaHjuWETzuEikvTBOeAehxSKBXGcSmsaTnpTodAXkpgOOmKXvyipugpHrajBXiZkPanoXqOScSlESejyxVJvrAXYYlnwDpTfXiFPXDYJpcRJhZEvTqcwimbiLgx")) {
        for (int mWvDuboUQnRf = 951081730; mWvDuboUQnRf > 0; mWvDuboUQnRf--) {
            SKIfITjWfwp += xvPMgFqXRf;
            CwShc += CwISsSEgyufDygIr;
        }
    }

    for (int qIMzCocEH = 2023445074; qIMzCocEH > 0; qIMzCocEH--) {
        yElkMdajQca = hPeSnasXKH;
        xvPMgFqXRf += hPeSnasXKH;
        CwShc = SKIfITjWfwp;
    }

    for (int wQOeURVuAu = 483643465; wQOeURVuAu > 0; wQOeURVuAu--) {
        yEJDWwsJfVt = yElkMdajQca;
        SKIfITjWfwp += hPeSnasXKH;
    }

    for (int yULwLQyVBMCVsg = 25565393; yULwLQyVBMCVsg > 0; yULwLQyVBMCVsg--) {
        fmOqMonX *= fmOqMonX;
        qDnRDcXUNCSAUdVr = hPeSnasXKH;
        CwShc = yEJDWwsJfVt;
    }

    return kbuFsycjYnnMs;
}

bool jHAYdoUiunSYDMU::kZvuUIMlyeAOYnEM(string imZDSybaVcQ)
{
    bool HVZIzaGQpUjDk = true;
    bool UXMYFphl = false;
    double WwaWRLmXRK = 774794.8701753484;
    string NSPHniDeU = string("HeaWRtxblJYIDSYopXZylTaKhYXUWHSKrplyYxNDGOOhnrntQEjzueVpXcoXfPiqwnBjMfuIeGiOeijhcCXZAQowwYKPyileTxtxFbZtpnjXXkjNGfyYiykdqZDMSKNdDtoQzLnWpshntaXyCsZmIQugFOUJyzRSktOpXepGEaAoZMITxVhviucQhQWtTumXnKrNwuIKcmRXwpJPRzRvpNMWuPxiTiQESaSzNQBTgQxVZhqnrmvsolHD");

    for (int ZkDsIQJvRbQF = 454620142; ZkDsIQJvRbQF > 0; ZkDsIQJvRbQF--) {
        NSPHniDeU += imZDSybaVcQ;
        UXMYFphl = HVZIzaGQpUjDk;
        NSPHniDeU = NSPHniDeU;
    }

    for (int eJlnkDFfuGsY = 604742684; eJlnkDFfuGsY > 0; eJlnkDFfuGsY--) {
        imZDSybaVcQ += imZDSybaVcQ;
        WwaWRLmXRK += WwaWRLmXRK;
    }

    for (int fHErOXZn = 1903243285; fHErOXZn > 0; fHErOXZn--) {
        continue;
    }

    for (int FFvUHoZmcZdF = 1157567368; FFvUHoZmcZdF > 0; FFvUHoZmcZdF--) {
        HVZIzaGQpUjDk = UXMYFphl;
    }

    return UXMYFphl;
}

void jHAYdoUiunSYDMU::vaVLKmItUkFkPW(int CRUoUI, double swVOsljul, double flFwVBhoZ)
{
    bool tlULSohuUMnZNFOs = false;
    int WOJrpxamruui = 1148816137;
    int tUYGUndrSa = 1261706229;
    double CFPARs = -359383.9076925902;

    if (tUYGUndrSa >= 1261706229) {
        for (int iVXlLbzEE = 794196303; iVXlLbzEE > 0; iVXlLbzEE--) {
            flFwVBhoZ *= flFwVBhoZ;
        }
    }

    for (int AkIGxBc = 1107025988; AkIGxBc > 0; AkIGxBc--) {
        continue;
    }

    if (CFPARs < 834581.4499654617) {
        for (int BGDgHj = 744286337; BGDgHj > 0; BGDgHj--) {
            CRUoUI -= tUYGUndrSa;
            CFPARs -= CFPARs;
            CFPARs += CFPARs;
        }
    }
}

jHAYdoUiunSYDMU::jHAYdoUiunSYDMU()
{
    this->IYLsdMDUq(-544485349);
    this->SezmjcaUETOZQv(string("nIsmuLTVXCeLTRWKJGAoZscobjWOqlswGsBGTBqSbHFRwYcWbcMmUIgTlCjVQcCxyRbFcDNNQbsPqZXpzdYHsEiiPidVNXoizwHhfnukNxfxfFVlFMRRpsbujRWPVsaiKOwDmdwmZwDwlxKNmAhBcObBWASeNYqjOAIjEyrHqJUqLyrjnwgeLCwsKRsRJBLBxkGpRHuvyJNxEMXSIaFGniRCMsjVhjqWAhKFRVpJbb"), string("yJgXHLJBiqigdgATmVzWZujPdJbabyoxozInNbxAIvEoCGEboeoOoymiPxfggZtghPYdCUzhSvYMXqIpJpdGFPwrAwbUbpxYdZDLTfDZeHkUQMIShCTFUAgtZXBlGtRUMzktOZxofipzftaNFdMOvMypWKrjKrLRRrIqOYNVcEOaIuxAEMtdQSFzZhyLLFteyKIucmCTYqXeZReOBlrotvGnCGFsbCiSqGClqsOJyLTfwHnGwUtEgPygyAzi"), true, string("oVxrntuNwrLdaAFDFzfvRbcdiMGpLdbHlJJZHgDFgBHKTKQPoRbyeEFhpRpeIKcOiFHnFZAgIuQjoTfGSQJqDLGMwZxFxNWypxgsukenQYdKWoUtfUVrQrHlDTWfJADQhisyj"), false);
    this->fZpWUaidCJA();
    this->eOHQzY(-513923.23709844827, -482139.87153759593, string("uHTFjhsIEoIJVg"), 1674017700);
    this->mlpNNHjoGR(false, true, true);
    this->GTtFVgVmWvyUM(673465.2638067633, false, -423892.7302768585, -1922533993, 894747.2554773344);
    this->hulzYFPoikdFNI(string("fGkPIUWIBPVarcbjAaGbNwczDAfAPtuyJjvEsLfsjpaugVshuZitepfYOHFvqhrsfwXgUXREyJWyoYlIDhshdQtHMxJpwRJEge"), string("QvsHCnuRglYKVBzRQPlEAJPSMdQVihkbo"), string("YzgfpVtwUWMZewPlshiOaDGdCuztuKiOGrYypQQxyRRDDNpmwNsFLwoaJvEXjHeHEtQzPAMuEXwgRLNApUMbKYHHdrjsiYZBNBPKxDhlwQqMPPXnTcxxiSZeNkhVNHQmmpXaPnrWIgYzzCmoFQpwvBQznBbMIKQbYBkfkBxUWwIdoPgJqPkXjhYkcrPZfiSdwfDDbPEInUpTeWVrYKLPQOgIMkNK"), 38789.45817060448);
    this->NwKsfmMS(739592.4204667924, string("qkBPcHmBrhGSegPPrlQAgDtGrgZzdXpJcXRkjcSKgYJfsjhQsvhlDYqQwnnQlpcvXHVTYigrSuqRPjyHGECRfwZQuVmNBVCrCaUKayrojdTfxqUTseItYlAQskwEqcbyJNDdjIxSekBjOWvQpaKnbrJmHZFacbJYRPzGXQMqGiWsGglaCcWbNQvpzlUFNLkeZAhoFEuRoGE"), false, -270143.02564019937);
    this->kZvuUIMlyeAOYnEM(string("fBTFPYxkHmnaVWQkrMjdQSBMBHbvjDbZfsHtylgypwYhUOKIGGeBUgbbaIbWojjNLHniowuUbDHEurGgFLkMOdRNhCHTsDlXCfxgXbMzttrZfiUDPeKbUpWnqCvOFhkxFxvZsyVTCFzwCDZAqQscXcvGkGHEhKHccWAOMIfIKUHiteWOVXTCmeBxejQEObZZfHYboQLQvbiWsnpAUlLuzGMBcSpaSmsjxfPBBqhcGMyCQ"));
    this->vaVLKmItUkFkPW(49530432, 834581.4499654617, 789067.5018623148);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tOfhYJD
{
public:
    int HzULdcSkBnC;
    bool mpJbX;
    bool nrHYOpoZRlaBRcxL;
    string DSreDNibAf;
    int ZSJSAfgmEws;

    tOfhYJD();
    string VEAmsGegwIYeS(bool HgPFIFj, string akTUpjkdJMf);
    bool LFFXkpVVy(bool gerQTH, bool eebvjpsYKF, bool WHUsiffepuBV);
    bool qtqblRGNXW(int PsyUhAMvdxfqYggI);
    void faHGyjqQButCTMDe();
    int civjp(int MtahfyNXgOG, string uEpMybDUYb, bool hxLgekzDPZbA, bool kRlfADKxA, double IRMpJ);
    string XqAarKdKhqfyetvq(double XkwGtHDFiFSpIPAD, bool PeytWPCo, int NBvMopYzhMT, bool fKvtD, int RsBFTwUvsP);
    void LGKtlmiBlRbpv(int lxWViqjagkKbW, double DWFwsvOCIyEv, string cwoHiVMmPwQKbb, string ITDdKavyIJvx);
    bool MkNHkhXNIaiEkc(string HRuanEvjkWCdZm, double DAgEqNEItuHOT);
protected:
    string fcycGB;
    double TpTLbrzxHgH;
    bool cAvvDtuhd;
    bool eVDYG;
    int fhqTgFcS;
    int XEkmGfxIbJlVWQM;

    string zvBOdlIKvDbbsoQ(string rKrPyeOS);
    void pVXWuH();
    string VipcEb(int SaAzmzLXPpI, int NxCFgFKVifMcEp, string frtZzXUG);
    bool iTXaFCPlcoEn();
    void cUODua(string vElLMycnMSdOe, string tIbdKITviyg, double bpZJATMqY);
    double CkwXVEtRskkVmGIB(string MnyJeUxntEPdNT, int gAIbiVQUbzDsii, string lJxbvCHpvGSbj);
    double VazPVRy(string YyJshttyNhY, bool DrXWYozzKfWGNww);
private:
    double EccdH;
    int eoroqBLu;
    string DnCNHYY;

    int GCMTdEGlZZsIRZ();
    int VaauHHkmi(int hanUtmQyzGt, bool RaWAVASzoPRBf, double NFoZnjFr, bool YQrpdpABK);
    int bjYXoElJjMa(int ZIETXkpPtHidIDX, bool Nxfuju, double jPffNrG, int EPFPTGMKJyspsUPK, int kdnuMHepk);
    void FLHEgfMhIzHjhmAy(int beLYpXNhsBJdpkls, string ZCHteY);
};

string tOfhYJD::VEAmsGegwIYeS(bool HgPFIFj, string akTUpjkdJMf)
{
    bool yUiTnmWa = true;
    string HfVgIeNR = string("VIKXUBDPCMBlCvgQRqZAkpsCzVvTmUIXXDatTanphRonDQJLSCartlwtaLGmPuPOAGIcCSAyRrPyEPHtWuVdEcBXiJsGXLCDoIPJSeYvFjlkExFTbbKNXMdJOiYumrmMSWGcVhdvtqwHReqzncWErcQQMJHxOSguPzooTcYsugtcVBoNbCDwjeSODAgOtPHFvWfJRFgeKzWjkWeJDWeGdV");
    double oBoFiszfs = -179306.79217159314;
    double yhPpyfraJnHr = -804207.2458059866;
    bool iMYAjEH = false;
    double dnTPpRHbKMPAGAmj = 496827.4599461698;
    string XArOoYi = string("iOzhQQgOGNcPMNJsnNCiLpbSdeVPqUKtguCltNfyTVvaHxXaVhluxztxwQRXmtEJCABIrclWvJbKINOCUsUkJEVVhGqBFmVsqpVdTdkvqEMVTFwRKvZmDNCTZCHthpMHuzFDwYSiiYMRojLIWUBBUqoHHitXhJGuKkKhdKVrgNQWqgulJrWKCtyHm");

    for (int uAonG = 2132438853; uAonG > 0; uAonG--) {
        yUiTnmWa = ! HgPFIFj;
        yhPpyfraJnHr -= yhPpyfraJnHr;
        XArOoYi = HfVgIeNR;
    }

    if (yhPpyfraJnHr <= 496827.4599461698) {
        for (int DwCGnUz = 525690106; DwCGnUz > 0; DwCGnUz--) {
            XArOoYi = akTUpjkdJMf;
            akTUpjkdJMf += akTUpjkdJMf;
        }
    }

    return XArOoYi;
}

bool tOfhYJD::LFFXkpVVy(bool gerQTH, bool eebvjpsYKF, bool WHUsiffepuBV)
{
    bool ZWiCrs = true;

    if (WHUsiffepuBV != false) {
        for (int wSvxrZnRkilHP = 1461463142; wSvxrZnRkilHP > 0; wSvxrZnRkilHP--) {
            gerQTH = ZWiCrs;
            WHUsiffepuBV = WHUsiffepuBV;
            gerQTH = WHUsiffepuBV;
            eebvjpsYKF = ! gerQTH;
            ZWiCrs = ! WHUsiffepuBV;
            ZWiCrs = gerQTH;
            eebvjpsYKF = ! gerQTH;
        }
    }

    if (ZWiCrs == false) {
        for (int OFCpfMnPlvXlh = 1290010937; OFCpfMnPlvXlh > 0; OFCpfMnPlvXlh--) {
            WHUsiffepuBV = ! ZWiCrs;
            ZWiCrs = eebvjpsYKF;
        }
    }

    if (WHUsiffepuBV == false) {
        for (int heuYjDXwnsZ = 1786250720; heuYjDXwnsZ > 0; heuYjDXwnsZ--) {
            gerQTH = ! ZWiCrs;
            WHUsiffepuBV = gerQTH;
            eebvjpsYKF = WHUsiffepuBV;
            eebvjpsYKF = ! gerQTH;
            ZWiCrs = gerQTH;
            WHUsiffepuBV = eebvjpsYKF;
            eebvjpsYKF = WHUsiffepuBV;
            gerQTH = eebvjpsYKF;
            WHUsiffepuBV = gerQTH;
            WHUsiffepuBV = eebvjpsYKF;
        }
    }

    if (WHUsiffepuBV == false) {
        for (int agCaJrgvcY = 1132453594; agCaJrgvcY > 0; agCaJrgvcY--) {
            ZWiCrs = eebvjpsYKF;
            ZWiCrs = ! ZWiCrs;
            WHUsiffepuBV = ! WHUsiffepuBV;
            eebvjpsYKF = ZWiCrs;
        }
    }

    return ZWiCrs;
}

bool tOfhYJD::qtqblRGNXW(int PsyUhAMvdxfqYggI)
{
    double wDInENqVZ = -1024416.0811032325;
    int NawrXSLyHqV = -448995586;
    int JzOFpSJcfOSuIdok = 1284429784;
    double uzBGNq = -393291.1854505153;
    string FJIlTuGoMYfAA = string("VYqkJtsNYrkZVSzCvIuRoDhqfTksEjziLuCHeujEPuTFTEhoUENyEjdjeVsSrAjWsxpUVMByWlhrLfEzyPvAYUpZihLUCGCneaYSgDWoaZJcGPhqZFDYngdTAnDtPJdMyUDsiXcjwizyCEvLtSSUjIATbELaJfjliuRaipSzNbqTkKtVHDOdgRXHvHNzBnqNhaAjCgZcIEehTwNueSmgXtghYQxmLyoLBGMEwhYLoCoAcTWRCMMPQMSkW");
    bool XmdwuDrzktpenJ = true;
    int aGpEu = -284216426;

    if (aGpEu != 1284429784) {
        for (int NkeYll = 1180207735; NkeYll > 0; NkeYll--) {
            NawrXSLyHqV *= PsyUhAMvdxfqYggI;
            wDInENqVZ += uzBGNq;
            PsyUhAMvdxfqYggI /= PsyUhAMvdxfqYggI;
        }
    }

    if (JzOFpSJcfOSuIdok < -284216426) {
        for (int eBlpGsCxdRSMZB = 996517636; eBlpGsCxdRSMZB > 0; eBlpGsCxdRSMZB--) {
            uzBGNq += wDInENqVZ;
            JzOFpSJcfOSuIdok = aGpEu;
        }
    }

    if (PsyUhAMvdxfqYggI == -284216426) {
        for (int qWTHHAdGVexeRUou = 1672245449; qWTHHAdGVexeRUou > 0; qWTHHAdGVexeRUou--) {
            NawrXSLyHqV -= NawrXSLyHqV;
        }
    }

    return XmdwuDrzktpenJ;
}

void tOfhYJD::faHGyjqQButCTMDe()
{
    string AGYJBr = string("TKedCFEqFUOamqzMCsyTyRePRIqoeIuYKBMyXlSDuOaneLxWwXiqtMjrqhvrHcTfdQhcBCLbEdWkzSVRHMRWxNlHXFJzTQEXpfVTGHyFCJcDspEXiKqAjUTHdobpvNttOneDGpUuddQDPQlHqiFHQtoWEdCLorcBfZAmQjvWKCpdVYrvH");
    bool cFNjBGjFov = false;
    double gqZBQWaPY = -750272.0022269998;
    int AuKdvhsYEMIS = -565943895;
    double xkagWvOMtfSaomI = 948422.2665413585;
    bool OlJXwebnJUyprCPJ = false;
    bool bcjzDEYFK = false;
    double IeUgDkbA = -653220.1804079281;

    if (OlJXwebnJUyprCPJ == false) {
        for (int sbmilWn = 643506470; sbmilWn > 0; sbmilWn--) {
            continue;
        }
    }

    for (int FljSOIYcnYunlb = 1191581679; FljSOIYcnYunlb > 0; FljSOIYcnYunlb--) {
        OlJXwebnJUyprCPJ = ! OlJXwebnJUyprCPJ;
    }
}

int tOfhYJD::civjp(int MtahfyNXgOG, string uEpMybDUYb, bool hxLgekzDPZbA, bool kRlfADKxA, double IRMpJ)
{
    int HqABz = 1364966837;
    int GkkJQKmdCBYv = 1187516933;
    string zUNEaUhzgOnQ = string("RNoChFsoEHeYThFpKDfzSamJGlfYHGbtqvzKLCgFqTEDDbJwYTOIJTFuzICcubotDTMwmQHLxEiHiQdybLqFZJIZdjKfAXdKfUAABNfQOWMDQqTXFHleVSygwgvdjEUNZMAPWFnrZOyuZCPjzQqVRSpGiyBtRzdZSlLmvtgwPungrsFbib");
    string hukNQDXoxf = string("wstXsxczvqTBCgMRQlPHYCpbGxzQZZtscYxsuLDIPdtppUjiPjvywhnDnygwOx");
    string zvVPhxaNM = string("bUE");
    int VwQSMtpEpeIynHP = 1179688744;
    int GlwEH = 201010675;
    double VgNKHAEAuNA = 746623.2684056772;

    for (int ciosqBwSeDigmLDB = 837776254; ciosqBwSeDigmLDB > 0; ciosqBwSeDigmLDB--) {
        zvVPhxaNM = zvVPhxaNM;
        uEpMybDUYb += hukNQDXoxf;
    }

    return GlwEH;
}

string tOfhYJD::XqAarKdKhqfyetvq(double XkwGtHDFiFSpIPAD, bool PeytWPCo, int NBvMopYzhMT, bool fKvtD, int RsBFTwUvsP)
{
    bool wCPjwwpe = false;
    int vCwhD = -1987766588;
    int hvYgwtMDDqZlW = -1587840306;

    for (int KhmMGnVYolyXwAb = 2074311054; KhmMGnVYolyXwAb > 0; KhmMGnVYolyXwAb--) {
        hvYgwtMDDqZlW = vCwhD;
        fKvtD = ! wCPjwwpe;
        RsBFTwUvsP /= RsBFTwUvsP;
        wCPjwwpe = fKvtD;
        fKvtD = ! fKvtD;
        wCPjwwpe = ! wCPjwwpe;
    }

    if (PeytWPCo == false) {
        for (int uAEpltxpOCOW = 1132653125; uAEpltxpOCOW > 0; uAEpltxpOCOW--) {
            vCwhD -= hvYgwtMDDqZlW;
            NBvMopYzhMT -= NBvMopYzhMT;
        }
    }

    return string("DMyQuBLCSoaVDETryFkjglCkLgkCMHeZTRKtcuctPamkxjHsaZNBafpYPaJBmbDjwbkhqCXGkSxtgFSYczIEKluuzCjwBLFbc");
}

void tOfhYJD::LGKtlmiBlRbpv(int lxWViqjagkKbW, double DWFwsvOCIyEv, string cwoHiVMmPwQKbb, string ITDdKavyIJvx)
{
    double hLelIHnL = 513119.960554654;
    string mmpSsEPtqqgXmM = string("s");
    double EpFOrACex = 919857.9150810225;
    string JTTIlCPG = string("tKSoRhWHTsGGEzVnBGpgsBnfIaPDKfZhpIGYBVvEHmgVWOUxKTRBTqsIQtTjTGEGZbJjzwSmsdAANiHpMhYdjpbtNjeymgiabaAtzdWlvRhsbeedRIAEtbZqxfeNMiOGOiiWDMxRlgWRmettCbzjaaykAaMmWfgLTUnHGWmceXrvcUFfMspsWJnYRsCnvrXFMZwMHfNjTLoBcYoqdKUELIspXDgUrieZiMkdIhSWyFfPjL");
    double LhOKQ = 340078.3569222134;
    string uNvPEky = string("KmngVKBgjbYFlXV");
    bool hliBgtVtwaYKdBr = false;
    double KEomrirdlXfL = -759867.6119633066;
    string uBWsYXeQVep = string("OJDXLhJ");
    double KbdmlKVtnmWD = 165998.9479948801;

    for (int CJCyHDbdOCyOBWGf = 732217435; CJCyHDbdOCyOBWGf > 0; CJCyHDbdOCyOBWGf--) {
        EpFOrACex -= KbdmlKVtnmWD;
        ITDdKavyIJvx = uNvPEky;
        DWFwsvOCIyEv = KEomrirdlXfL;
        hLelIHnL -= KEomrirdlXfL;
    }
}

bool tOfhYJD::MkNHkhXNIaiEkc(string HRuanEvjkWCdZm, double DAgEqNEItuHOT)
{
    double bgAhZlVnCgqk = 591869.5695797123;
    double ZVUJeVCYEvlR = 500146.4868522648;
    double mUeRnzyguFdzkVae = -973535.8204863516;
    string BmaytbRqm = string("KhxHobkyQcXvUEEqTkDPODYwHtkMQxIJrUncaXvScyFGrLbosgxcqyTOKrJRIuSdDntoedTSQjQIvdeRjqEHZPBpaOmGuJRCWLxXBNoWFKQKdSMkOqDsZvxYZsgXUuqFeGKhyHFWueOGjvLrmbVKyzUkqSLKRZJlRKm");
    int nZPtMpaIq = 2025218240;
    string UToGH = string("nOXRExreQrpGjlpVsMWYUBWFT");
    string SUmKvUKim = string("CXyIqtVEvlPaamRekouApYNKIceumZFCgmynbRByGQpQaqtYixSNtczvBeHkgfNXYVnYFtuMManfGadBCcOdXJCXDMcPmrxucRAgTtKkMOjBYodVwfiLqGDsMkdJnMVLYjydMyHfHUsLdfyOkurcqAMIPpuWGQwXeIfQ");
    double NICRaiztXDBLZ = -945566.6969348786;

    for (int sjcbIox = 1165706504; sjcbIox > 0; sjcbIox--) {
        bgAhZlVnCgqk /= DAgEqNEItuHOT;
        BmaytbRqm += HRuanEvjkWCdZm;
        SUmKvUKim = HRuanEvjkWCdZm;
        SUmKvUKim = UToGH;
    }

    if (ZVUJeVCYEvlR >= -973535.8204863516) {
        for (int feLuHeDSyBw = 1255762543; feLuHeDSyBw > 0; feLuHeDSyBw--) {
            NICRaiztXDBLZ = ZVUJeVCYEvlR;
            BmaytbRqm += UToGH;
        }
    }

    for (int ctESZhC = 971831497; ctESZhC > 0; ctESZhC--) {
        continue;
    }

    return false;
}

string tOfhYJD::zvBOdlIKvDbbsoQ(string rKrPyeOS)
{
    string gdkTQHjfgA = string("oJyIodEbjFgcHTyrMIAbzNSfSFFxkuiTPzofMLSReadSqMmAkgYZXlYqxCHevyPhtwJcvyIrebaxbLNHeCvCrkpZEPu");
    int BeATB = 1895734477;
    double ePfLBDNpUjXBEtZS = -90330.29543782532;
    string JcLxMATMFfvhEcka = string("QxWTsrnbfeyNSiTrvBpYtGQOkxIchRtsCWXxuOMLUZIaUBeMxmaOVYAuQckTKxMhVDopxzRJVmWLzHkfMLdmoTcHyXGckMqWDxolDVVaEJEWdUvahFtzQyXXCdQGuUGdysptoLNcQJsvjSMfwvqfOZysBUxzrvoEFUnUvnTCkjEUOebvUfdvzYGwRkRRssSrsPVvFZRT");
    int VSCrLAA = -1040081425;
    int ZqaqsYx = 944374485;

    for (int EnwLbKyYSnqg = 1590028062; EnwLbKyYSnqg > 0; EnwLbKyYSnqg--) {
        continue;
    }

    for (int RnnBR = 1359012353; RnnBR > 0; RnnBR--) {
        ZqaqsYx *= VSCrLAA;
        VSCrLAA = ZqaqsYx;
        ePfLBDNpUjXBEtZS += ePfLBDNpUjXBEtZS;
    }

    for (int GUWDizoj = 1309212348; GUWDizoj > 0; GUWDizoj--) {
        JcLxMATMFfvhEcka += JcLxMATMFfvhEcka;
    }

    if (ZqaqsYx > 1895734477) {
        for (int WnOHVzdnJsXVb = 1143501073; WnOHVzdnJsXVb > 0; WnOHVzdnJsXVb--) {
            VSCrLAA /= ZqaqsYx;
        }
    }

    return JcLxMATMFfvhEcka;
}

void tOfhYJD::pVXWuH()
{
    double McjcjDdizG = -396037.04248776817;
    double jeErMNoTiU = 512127.40911948297;
    bool VwprIohudDWu = false;
    double ZZdLQhBVA = 484550.05247640033;
    int gniZFCGd = 1158103970;
    double cbajWieVngBSVc = 1006354.1291386619;
    int mosRXhOrsK = 377812001;
    double EHtfGWGdLpwluBEy = -756077.7470747174;
    double jVYCBtJw = -805688.3914657088;

    if (jVYCBtJw == -805688.3914657088) {
        for (int ozYSbKSNA = 1131919519; ozYSbKSNA > 0; ozYSbKSNA--) {
            EHtfGWGdLpwluBEy /= jeErMNoTiU;
        }
    }

    for (int ysPaERIAJ = 431202144; ysPaERIAJ > 0; ysPaERIAJ--) {
        gniZFCGd *= gniZFCGd;
        EHtfGWGdLpwluBEy += ZZdLQhBVA;
        McjcjDdizG += jeErMNoTiU;
    }

    for (int LsCIUXOgCnno = 708668899; LsCIUXOgCnno > 0; LsCIUXOgCnno--) {
        cbajWieVngBSVc -= McjcjDdizG;
        jeErMNoTiU /= ZZdLQhBVA;
        jVYCBtJw += ZZdLQhBVA;
        jeErMNoTiU -= ZZdLQhBVA;
        gniZFCGd += mosRXhOrsK;
        jeErMNoTiU = jVYCBtJw;
    }

    for (int wHNesvzrViZ = 168697832; wHNesvzrViZ > 0; wHNesvzrViZ--) {
        jeErMNoTiU -= EHtfGWGdLpwluBEy;
        EHtfGWGdLpwluBEy = jVYCBtJw;
        jVYCBtJw /= jeErMNoTiU;
        McjcjDdizG = ZZdLQhBVA;
        EHtfGWGdLpwluBEy /= McjcjDdizG;
    }
}

string tOfhYJD::VipcEb(int SaAzmzLXPpI, int NxCFgFKVifMcEp, string frtZzXUG)
{
    string JtaxgLZQkarn = string("icBCvDytJgNhjAEYMuDZltxmQEsqvZaBJAXjojVQPayWqjCzFojaLASreKvyrRODunocNRcjnRMNGpYCVUHBONtQUbZyCSaAjDDgElVQlCcggLgvxQuPpMLpSZWRPyjYpMSrQdUYafMlWAJPkDqAstVCYlXUDlZYeopugLIguwpjwicTpXsOPjXMLUDldEDhrbElFKIrfLcUkYXashIEuaXtycLpWidDXn");
    string XUCgaRQOqcZ = string("lORprQKvXurFBDlnwBpvTHFKEJkIpPbFMDMzofVyyujFevbWodJVRODuGSSoLBVyflcQCTNFWyLbVLhPlfPIHXyCoqxZkbmuspZZGWIz");

    if (NxCFgFKVifMcEp != -1270647688) {
        for (int HWZaVFt = 685500459; HWZaVFt > 0; HWZaVFt--) {
            frtZzXUG += JtaxgLZQkarn;
            frtZzXUG += XUCgaRQOqcZ;
            SaAzmzLXPpI -= NxCFgFKVifMcEp;
            JtaxgLZQkarn = JtaxgLZQkarn;
        }
    }

    return XUCgaRQOqcZ;
}

bool tOfhYJD::iTXaFCPlcoEn()
{
    bool IJCGUFpmngt = false;
    double JLxqTmZx = 250196.8752446788;
    bool aeQPaGajqNPC = false;
    string bqomRk = string("NZaTJbGEPOlsUEuqVRmtodDTIxfnnEogYHcKjvcotzEDbXoakzGoWNsrzTJuRgLOBQMZMcRjmNbGOJLmYHfnvcGJ");
    string qCNsupWZcniMkrCN = string("ALxZmpvsiEKGzOgMzWrxAFvDPvhhhcWcWDLDJYFAhbErcNLwSHgQVNaQKbERaAifbRRTCJNNqJDTtsbgfdjYHALfypDfhMYZvEWHZtPHaEQNnOpZxAofJzOkzwPDRrLmcOxvlIiHlR");
    bool MUHiEFsEsFxnVbuX = true;

    for (int JtXxmhxQWe = 15855166; JtXxmhxQWe > 0; JtXxmhxQWe--) {
        IJCGUFpmngt = ! aeQPaGajqNPC;
    }

    for (int rbeyU = 222491500; rbeyU > 0; rbeyU--) {
        MUHiEFsEsFxnVbuX = aeQPaGajqNPC;
        aeQPaGajqNPC = aeQPaGajqNPC;
        MUHiEFsEsFxnVbuX = aeQPaGajqNPC;
        qCNsupWZcniMkrCN += qCNsupWZcniMkrCN;
    }

    for (int PxMMYxKjIiGFjTQ = 1587930729; PxMMYxKjIiGFjTQ > 0; PxMMYxKjIiGFjTQ--) {
        qCNsupWZcniMkrCN = bqomRk;
        IJCGUFpmngt = ! aeQPaGajqNPC;
        MUHiEFsEsFxnVbuX = IJCGUFpmngt;
    }

    if (aeQPaGajqNPC == true) {
        for (int HFDRpygwsZFz = 1227833918; HFDRpygwsZFz > 0; HFDRpygwsZFz--) {
            qCNsupWZcniMkrCN = qCNsupWZcniMkrCN;
            bqomRk += bqomRk;
        }
    }

    for (int XPjuqOjklqgDA = 1222777915; XPjuqOjklqgDA > 0; XPjuqOjklqgDA--) {
        MUHiEFsEsFxnVbuX = IJCGUFpmngt;
        bqomRk = bqomRk;
    }

    return MUHiEFsEsFxnVbuX;
}

void tOfhYJD::cUODua(string vElLMycnMSdOe, string tIbdKITviyg, double bpZJATMqY)
{
    int DUpadNp = 903762946;
    double axFpxq = 355787.4466557475;
    string bdbLFyppjYIvW = string("HqnqXvwMCUPivSZmPaPQuYaTlmHwUsMzQjIWzdmRmurMjrkBOMBIxTHBzsZoRVkunCCoYplwPVgYEFzSoNPOVAokhSOGbGnROyEhjfKtzQFoYrQRYwuPyevkFYtqUAbjZeVQByxEhEadTRNmlxeMABkwFpULdhsrnqQNRXxrXIEzGhjNqKniNvMbnHHlHgueUWnsWkcRHtCHzKbDgBcqclPpotJqhOoRNOwg");
    double ThwCTONEYTbURk = -107627.01267130554;
    string PvftTNgAGihJPn = string("WsnDTPqjIQCcIizIXzoLExaRyCaqdneBWcZMqaHPGLWlhYWcppnWUSrimzPRDmxIJGJNIVYTEVZQizZixOFfkQyOYKiYHXmAqxZIkwUlIsQVudEFfcMM");
    int ZnBXZIuKWoFZ = -1001884543;

    if (bdbLFyppjYIvW > string("rCwHmfyONCCWEuAGuvZCwlzpgqJBqGGpQAmBDUXgJQzDsGUDcQwCYtFoTGLVLGAdAY")) {
        for (int gxpRrZgAnwhm = 268891144; gxpRrZgAnwhm > 0; gxpRrZgAnwhm--) {
            PvftTNgAGihJPn += bdbLFyppjYIvW;
        }
    }

    for (int tETjZlRAxGkzcf = 96439536; tETjZlRAxGkzcf > 0; tETjZlRAxGkzcf--) {
        ThwCTONEYTbURk += ThwCTONEYTbURk;
        ThwCTONEYTbURk -= ThwCTONEYTbURk;
        tIbdKITviyg += PvftTNgAGihJPn;
        tIbdKITviyg = tIbdKITviyg;
        bpZJATMqY -= axFpxq;
    }

    if (vElLMycnMSdOe != string("HqnqXvwMCUPivSZmPaPQuYaTlmHwUsMzQjIWzdmRmurMjrkBOMBIxTHBzsZoRVkunCCoYplwPVgYEFzSoNPOVAokhSOGbGnROyEhjfKtzQFoYrQRYwuPyevkFYtqUAbjZeVQByxEhEadTRNmlxeMABkwFpULdhsrnqQNRXxrXIEzGhjNqKniNvMbnHHlHgueUWnsWkcRHtCHzKbDgBcqclPpotJqhOoRNOwg")) {
        for (int hycqsbU = 1943911840; hycqsbU > 0; hycqsbU--) {
            ThwCTONEYTbURk /= ThwCTONEYTbURk;
        }
    }

    if (vElLMycnMSdOe == string("oimmqxRBSdjEgmzufaeDonoreKnOUXNGlQnIbrzYVEXJawtLXpagFKVUOUWZJiezGrXBNmKcPHLaqRtwThOflUVQwSjficVUMjzARXEpbGesanvdqqKkYAvrgMprVVJikkiAfxuNeNJAoYspnbUWyyEqCgmUxWVxoCWGJiQmFQiCmsyJuKzMVularxTqvHwyHPOpUNwxPoH")) {
        for (int oofXgbboDymOEJC = 271848975; oofXgbboDymOEJC > 0; oofXgbboDymOEJC--) {
            continue;
        }
    }
}

double tOfhYJD::CkwXVEtRskkVmGIB(string MnyJeUxntEPdNT, int gAIbiVQUbzDsii, string lJxbvCHpvGSbj)
{
    bool fVkgDS = true;
    int UWCUGsCgVzkrhqE = -984093532;
    int tFNmy = 789790499;

    if (gAIbiVQUbzDsii < 584240521) {
        for (int qSMtp = 1601149417; qSMtp > 0; qSMtp--) {
            gAIbiVQUbzDsii -= UWCUGsCgVzkrhqE;
        }
    }

    for (int LtNcQErgj = 1843416431; LtNcQErgj > 0; LtNcQErgj--) {
        gAIbiVQUbzDsii -= gAIbiVQUbzDsii;
    }

    if (UWCUGsCgVzkrhqE > 789790499) {
        for (int HKRnCYP = 1556213360; HKRnCYP > 0; HKRnCYP--) {
            fVkgDS = ! fVkgDS;
        }
    }

    return -424273.946677707;
}

double tOfhYJD::VazPVRy(string YyJshttyNhY, bool DrXWYozzKfWGNww)
{
    double oCJHcvryHTqmvz = 964548.1511948329;

    for (int nOmKLvceZFw = 344189467; nOmKLvceZFw > 0; nOmKLvceZFw--) {
        oCJHcvryHTqmvz = oCJHcvryHTqmvz;
        YyJshttyNhY = YyJshttyNhY;
        oCJHcvryHTqmvz /= oCJHcvryHTqmvz;
    }

    for (int yUfSdkxdA = 666393877; yUfSdkxdA > 0; yUfSdkxdA--) {
        YyJshttyNhY += YyJshttyNhY;
        DrXWYozzKfWGNww = ! DrXWYozzKfWGNww;
    }

    for (int NtaQjV = 431201282; NtaQjV > 0; NtaQjV--) {
        DrXWYozzKfWGNww = DrXWYozzKfWGNww;
        oCJHcvryHTqmvz -= oCJHcvryHTqmvz;
    }

    for (int rcoGLPCJNdUNUKg = 2124437272; rcoGLPCJNdUNUKg > 0; rcoGLPCJNdUNUKg--) {
        continue;
    }

    return oCJHcvryHTqmvz;
}

int tOfhYJD::GCMTdEGlZZsIRZ()
{
    string twIEjHJYFsmRzMCf = string("BuaUsFsIVCsWfHdahkBAvmZqpMMWgpkfBvZLuMoyHejrfBmqe");
    int yfThclNizBBN = -1580835014;
    int kmYqFTGHGNtW = -30106477;

    for (int DJjqAPHleIJg = 2138911080; DJjqAPHleIJg > 0; DJjqAPHleIJg--) {
        yfThclNizBBN *= yfThclNizBBN;
        yfThclNizBBN = kmYqFTGHGNtW;
        twIEjHJYFsmRzMCf += twIEjHJYFsmRzMCf;
    }

    if (twIEjHJYFsmRzMCf <= string("BuaUsFsIVCsWfHdahkBAvmZqpMMWgpkfBvZLuMoyHejrfBmqe")) {
        for (int gAnZshcROMBzVk = 1885735546; gAnZshcROMBzVk > 0; gAnZshcROMBzVk--) {
            kmYqFTGHGNtW += yfThclNizBBN;
            yfThclNizBBN -= kmYqFTGHGNtW;
            kmYqFTGHGNtW -= yfThclNizBBN;
            kmYqFTGHGNtW = kmYqFTGHGNtW;
            kmYqFTGHGNtW /= yfThclNizBBN;
            kmYqFTGHGNtW -= kmYqFTGHGNtW;
            yfThclNizBBN = yfThclNizBBN;
            kmYqFTGHGNtW = kmYqFTGHGNtW;
        }
    }

    if (twIEjHJYFsmRzMCf != string("BuaUsFsIVCsWfHdahkBAvmZqpMMWgpkfBvZLuMoyHejrfBmqe")) {
        for (int fGFMLm = 944428398; fGFMLm > 0; fGFMLm--) {
            kmYqFTGHGNtW -= kmYqFTGHGNtW;
            kmYqFTGHGNtW = kmYqFTGHGNtW;
            kmYqFTGHGNtW -= yfThclNizBBN;
            yfThclNizBBN *= kmYqFTGHGNtW;
            kmYqFTGHGNtW -= kmYqFTGHGNtW;
            yfThclNizBBN *= yfThclNizBBN;
            twIEjHJYFsmRzMCf = twIEjHJYFsmRzMCf;
            kmYqFTGHGNtW *= kmYqFTGHGNtW;
        }
    }

    for (int azRJbUf = 1695272186; azRJbUf > 0; azRJbUf--) {
        continue;
    }

    for (int JGodIZbNB = 1019715415; JGodIZbNB > 0; JGodIZbNB--) {
        twIEjHJYFsmRzMCf = twIEjHJYFsmRzMCf;
        twIEjHJYFsmRzMCf = twIEjHJYFsmRzMCf;
        kmYqFTGHGNtW = yfThclNizBBN;
        kmYqFTGHGNtW += yfThclNizBBN;
    }

    if (yfThclNizBBN == -1580835014) {
        for (int xKDIPWKnbObj = 777559314; xKDIPWKnbObj > 0; xKDIPWKnbObj--) {
            yfThclNizBBN /= kmYqFTGHGNtW;
            kmYqFTGHGNtW += yfThclNizBBN;
            kmYqFTGHGNtW = yfThclNizBBN;
            kmYqFTGHGNtW *= yfThclNizBBN;
        }
    }

    if (kmYqFTGHGNtW >= -30106477) {
        for (int tinwhofhgfUOnICT = 671216887; tinwhofhgfUOnICT > 0; tinwhofhgfUOnICT--) {
            twIEjHJYFsmRzMCf += twIEjHJYFsmRzMCf;
            kmYqFTGHGNtW += kmYqFTGHGNtW;
            kmYqFTGHGNtW = yfThclNizBBN;
            yfThclNizBBN /= kmYqFTGHGNtW;
            twIEjHJYFsmRzMCf += twIEjHJYFsmRzMCf;
        }
    }

    return kmYqFTGHGNtW;
}

int tOfhYJD::VaauHHkmi(int hanUtmQyzGt, bool RaWAVASzoPRBf, double NFoZnjFr, bool YQrpdpABK)
{
    bool MXTKgt = true;
    string FXjoh = string("qpxwFUGDxfAxfPRIIaaJwP");
    int ltxrFUPJbsoDwULP = -2131396888;
    bool BeGJZMHSvqrm = true;

    for (int VjQdYLq = 966829248; VjQdYLq > 0; VjQdYLq--) {
        ltxrFUPJbsoDwULP += hanUtmQyzGt;
    }

    if (NFoZnjFr >= -603170.975275041) {
        for (int uOLZlhrcqIvXeBVO = 1920495452; uOLZlhrcqIvXeBVO > 0; uOLZlhrcqIvXeBVO--) {
            RaWAVASzoPRBf = BeGJZMHSvqrm;
            YQrpdpABK = ! YQrpdpABK;
            BeGJZMHSvqrm = BeGJZMHSvqrm;
            YQrpdpABK = ! YQrpdpABK;
        }
    }

    if (MXTKgt == false) {
        for (int aifIYOQNvPGvdlM = 1974051041; aifIYOQNvPGvdlM > 0; aifIYOQNvPGvdlM--) {
            YQrpdpABK = ! RaWAVASzoPRBf;
        }
    }

    for (int mGPuMjvYZoKWze = 501555763; mGPuMjvYZoKWze > 0; mGPuMjvYZoKWze--) {
        BeGJZMHSvqrm = MXTKgt;
        ltxrFUPJbsoDwULP *= hanUtmQyzGt;
        MXTKgt = ! YQrpdpABK;
        FXjoh = FXjoh;
    }

    return ltxrFUPJbsoDwULP;
}

int tOfhYJD::bjYXoElJjMa(int ZIETXkpPtHidIDX, bool Nxfuju, double jPffNrG, int EPFPTGMKJyspsUPK, int kdnuMHepk)
{
    string qoBpBqoQZ = string("PTbANPgPMipLrOhUOOtisqdWzfbUdWHLJObAOMHLnvgqrCQoCdbEgOiVAQBgBZVbPuuACCpGtlxUrrUkQuzlzdsyyQGYSsBpbXrVxPPkGKmu");
    bool NOcvCRjjGV = false;
    int YxkCOltGAC = 1387867549;

    for (int exKkRPnDC = 104797294; exKkRPnDC > 0; exKkRPnDC--) {
        ZIETXkpPtHidIDX *= EPFPTGMKJyspsUPK;
        jPffNrG -= jPffNrG;
        YxkCOltGAC = EPFPTGMKJyspsUPK;
    }

    for (int BXtEqV = 690295157; BXtEqV > 0; BXtEqV--) {
        NOcvCRjjGV = NOcvCRjjGV;
    }

    if (ZIETXkpPtHidIDX < -2001506318) {
        for (int AaWzaoj = 200984074; AaWzaoj > 0; AaWzaoj--) {
            ZIETXkpPtHidIDX *= kdnuMHepk;
            ZIETXkpPtHidIDX /= ZIETXkpPtHidIDX;
        }
    }

    return YxkCOltGAC;
}

void tOfhYJD::FLHEgfMhIzHjhmAy(int beLYpXNhsBJdpkls, string ZCHteY)
{
    string eAXiLnblpgrQo = string("kyliQeZfXekBOFfbLSDixiYSdZTynKMmfsqGLBuSiKJUTAIumMfYcBNsBQTPuxSmFIlgeqZuuOfzzcnskwUHESUWSLjJaASSCdYGqzbaYVMMLEEHtPjGWfvsFSvdvtYWMmVLGaRvOiJOFz");
    bool tDzVW = true;
    int pJKLGdP = -988873078;
    int LpOhXEdAhUrnCYKU = 1954740092;
    double enbeHh = -963295.4089800288;
    double yZnSALm = -293567.5443546223;

    if (LpOhXEdAhUrnCYKU >= 1954740092) {
        for (int XCieIdKyvTZSbuq = 1702810968; XCieIdKyvTZSbuq > 0; XCieIdKyvTZSbuq--) {
            ZCHteY += ZCHteY;
        }
    }

    for (int mtVyG = 851513682; mtVyG > 0; mtVyG--) {
        continue;
    }

    for (int RbWamzopm = 121190342; RbWamzopm > 0; RbWamzopm--) {
        LpOhXEdAhUrnCYKU = pJKLGdP;
        ZCHteY = ZCHteY;
        yZnSALm -= yZnSALm;
    }
}

tOfhYJD::tOfhYJD()
{
    this->VEAmsGegwIYeS(false, string("NQLYjAvpCYFFjVXPmOEwrCCbBvL"));
    this->LFFXkpVVy(false, true, false);
    this->qtqblRGNXW(2079441110);
    this->faHGyjqQButCTMDe();
    this->civjp(861952010, string("RfZQpmjOupUQwKDGhJkJzTPBsITWOBKsZpuzWtaXJYeERPEWRAaLlGMbylKytgzyPIXKpzlTGaLCOkigWWqPXigOowfbDaoiHToYtstBGIZPvpusImCvcgXDlSfGDxQ"), false, true, -496055.17906449497);
    this->XqAarKdKhqfyetvq(-685518.702450954, false, 908644635, true, -1832566079);
    this->LGKtlmiBlRbpv(1142401711, -946473.2802162846, string("geFKvORGtmmAdyyAMxiFPtgOLSoqNQAihrwkyfvmGXGTrqLHwjOEdYVKittQONfnrIHTKxtAxkXnqetMBrcbPEUVrFHBbkINzqkDougadRFGPRFXLdeaselcpuEaJaVyaWNhIoFEovJANQAbsekCuBtNNGxiDURLdVLfUgIZjnuidtMPwtpwBtbrGLFvaeMISFaHbZqMdxEwaAcUd"), string("DCNdmJiCOnPtViuzqyGfnqKlXqhhWozWugsFvNPPsWRyvwbjrEJYjqHMhjOMIoizRMcKxYSNQTtdPGHKfzmWnbuUlPGFGdgtFBdvSWGGQtvQLxBipNjRsTlGQ"));
    this->MkNHkhXNIaiEkc(string("bBLuxCnYtoqAevkglAzsXbtHrTJzlGyMYEkZmTcCvRVJXtTSDzCmNVmSNlNjHtjkhFqqdJedRbNgXptjxOUVScqwEXCCcZqArjAdWwfnBJoeyxLgTyzHMWUVDwJnQDHTuybUelZixCRoieRkQs"), 491874.1580412257);
    this->zvBOdlIKvDbbsoQ(string("lJUlSokPFKoAeWzwZtaFwCdlEtbhnEVfUIdIrLRzkiRXKydkaIfWJtwkSHrIhjwHoggfyLTqOfxFwBsvoTL"));
    this->pVXWuH();
    this->VipcEb(-1270647688, -1966371349, string("yrhzXPqfSNKrfjYqqDQftEcrGduhQaIWBvyTGpdXmQWGiXKDfNIIeTSIdmBXoxQMgEICZKBkUoSRSXeAogSxxQL"));
    this->iTXaFCPlcoEn();
    this->cUODua(string("oimmqxRBSdjEgmzufaeDonoreKnOUXNGlQnIbrzYVEXJawtLXpagFKVUOUWZJiezGrXBNmKcPHLaqRtwThOflUVQwSjficVUMjzARXEpbGesanvdqqKkYAvrgMprVVJikkiAfxuNeNJAoYspnbUWyyEqCgmUxWVxoCWGJiQmFQiCmsyJuKzMVularxTqvHwyHPOpUNwxPoH"), string("rCwHmfyONCCWEuAGuvZCwlzpgqJBqGGpQAmBDUXgJQzDsGUDcQwCYtFoTGLVLGAdAY"), -974657.4361588575);
    this->CkwXVEtRskkVmGIB(string("sgAbQHCriTvhUGBRIPKHPocetXAdChDPSfhkcCpaHvSPFobCXyHEhezHEZqjqThnJlFhYJExUFvYDzYTPMSxgKOrkzMpWqkNoGNlIvOIaPlwXJ"), 584240521, string("cmTDUPbvokfkltjMmFORIZSwUPTbsRONGTmkBLlwxKjsDlasA"));
    this->VazPVRy(string("HsRFluKFqPujgBZSgGURxCXravTchQUkDhbNKtjoWRUWpsqNvgVlWalWoHoxrDhctMwNxPFFPMSmsBtiVngeCyTYeTryiSEwsGmvPTICasGPQdQrlToYQcklfFHbIlmDFxKOebrqsILKSVlwPAYbLzRirKtHkDspGMrNtWtcrxxBBSyDJMrmALZzXWurgIdimcdwHkKUKbmAxNesgezlsuHZNhfa"), true);
    this->GCMTdEGlZZsIRZ();
    this->VaauHHkmi(809417878, false, -603170.975275041, false);
    this->bjYXoElJjMa(-1672506800, true, 542049.9478465731, -2001506318, -1551151546);
    this->FLHEgfMhIzHjhmAy(741731198, string("YvKCYgmlejuPCDDSHOhwQgfEBLUXfriSpSjIAklvRFYbFsjNYMGEeWnDosKuTOFYOlBhVzLcbZYvjjCVVXjAAenXBHOvuSUKGePbEvAqVMWFeYZJNnOYPoyzNdDMwQtrwduXJWXUzsBrdOYobVKlRWaJulpibSZYrlIjPKojMqJcnFGanqqSVGiCOmfIpdgUjmiLorJaxJGP"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MfywTluXLv
{
public:
    int YHrwOJedSQhEr;
    double IInriucKkticPG;
    int CTPrX;

    MfywTluXLv();
    bool AQgjihGTnHIbiVF();
    int artXYibRWba(string vTtKdBYUKHOQ);
    void ZOoWtpsa(bool aJKSNzmH, string ZcZmknujuGrhn);
    double XyRat();
    double ZaINrZRWkfaIrr(int jknDpcirqQMFQdV);
protected:
    double fdrfSNzZPMhpufR;
    bool ExxaL;

    int EoKGlEG(string WjUBKg, bool GQjEFasY, string BAExJa);
private:
    string SByQCSbnw;
    double JyzYnTAKIrmSroNP;
    double ZvcqDrKJEgVecWO;
    int pmBFFJLwEqGr;
    double NinoavYbYMg;
    double rGtnWTMGkAl;

    string tfNPLnbEnYRYT(double plhEhTLU, int FXZJTclVCp, string MUzDkwORtuBHZi);
    double WzoGqNgviqyVknq(bool mNkquTxVwtHQesN, bool XymgFbLrYj);
    int gGEIdOUOG();
    string UWLDKfZlJtK(string JAxfvYJrHI);
    string BBPoIZwMiKngu(int SNIsIHATME, string RBvnAB, int YXsXvLpZvFrlIy, int fznxzru, string rRqeEHJihUrJWU);
    void OOjbdbw(bool DFEJqQa, int KdkyFjZirDXkzszw, bool mYwIHmchZGOQA, double RBLszjA);
};

bool MfywTluXLv::AQgjihGTnHIbiVF()
{
    int fYNuIrRJuq = 147434897;
    bool SCuhVkYJQzQEhRNH = false;
    double JxEaaRpTBAkFBuR = 56072.9563474305;
    bool dtsFhUJDePkEfvS = false;
    double rTPHAPSc = 252379.61776932864;
    int jaOJgLKjpUV = 178656992;
    string YVLJUCXCFkJhYpI = string("tniRKnQRwHGsXaZbihBSEJZLiPhTohjGvfvSoURDQPMsRaFWSLoVlzTOdgCnRsuwXRyexPouNTUSuBprpDXERwnnoUxkBBQPHFDsKEmRBCAZGnnuKvdhnjOtbJUPDmGNqwLoisUrCfdnoAVjiQhRjtEboMVXktnPeMybHgnKnVXwrsYxWQqjGkraeqMUoexUEj");
    double ZLdFKSzSLsV = 678110.0355266623;

    if (SCuhVkYJQzQEhRNH == false) {
        for (int UCMNUEioBX = 850781229; UCMNUEioBX > 0; UCMNUEioBX--) {
            ZLdFKSzSLsV += rTPHAPSc;
        }
    }

    if (dtsFhUJDePkEfvS != false) {
        for (int xWJEDubPujdzfW = 1106680190; xWJEDubPujdzfW > 0; xWJEDubPujdzfW--) {
            continue;
        }
    }

    for (int IlXYHpbRwwPYjjb = 75460998; IlXYHpbRwwPYjjb > 0; IlXYHpbRwwPYjjb--) {
        continue;
    }

    if (ZLdFKSzSLsV > 56072.9563474305) {
        for (int XHsEptfN = 1307281345; XHsEptfN > 0; XHsEptfN--) {
            fYNuIrRJuq -= fYNuIrRJuq;
        }
    }

    return dtsFhUJDePkEfvS;
}

int MfywTluXLv::artXYibRWba(string vTtKdBYUKHOQ)
{
    bool VwiOsAdSGxbh = true;
    bool OJZdiMCihIsgY = true;
    int MLdmmbE = 1613557500;
    bool DSjGsIvAzJP = true;

    for (int kvYUVx = 2006578968; kvYUVx > 0; kvYUVx--) {
        VwiOsAdSGxbh = OJZdiMCihIsgY;
        DSjGsIvAzJP = VwiOsAdSGxbh;
    }

    if (DSjGsIvAzJP == true) {
        for (int FKrQxX = 132001279; FKrQxX > 0; FKrQxX--) {
            DSjGsIvAzJP = OJZdiMCihIsgY;
            vTtKdBYUKHOQ = vTtKdBYUKHOQ;
        }
    }

    if (MLdmmbE <= 1613557500) {
        for (int ZKrhW = 530751687; ZKrhW > 0; ZKrhW--) {
            OJZdiMCihIsgY = ! VwiOsAdSGxbh;
            DSjGsIvAzJP = DSjGsIvAzJP;
            OJZdiMCihIsgY = VwiOsAdSGxbh;
            OJZdiMCihIsgY = ! VwiOsAdSGxbh;
        }
    }

    if (VwiOsAdSGxbh == true) {
        for (int jGQsQqCaDYdNoo = 692442445; jGQsQqCaDYdNoo > 0; jGQsQqCaDYdNoo--) {
            MLdmmbE *= MLdmmbE;
            VwiOsAdSGxbh = VwiOsAdSGxbh;
        }
    }

    for (int CSZmfyqAbg = 965492030; CSZmfyqAbg > 0; CSZmfyqAbg--) {
        vTtKdBYUKHOQ = vTtKdBYUKHOQ;
    }

    for (int cRJMufMqO = 31002646; cRJMufMqO > 0; cRJMufMqO--) {
        vTtKdBYUKHOQ += vTtKdBYUKHOQ;
        DSjGsIvAzJP = OJZdiMCihIsgY;
        VwiOsAdSGxbh = DSjGsIvAzJP;
        OJZdiMCihIsgY = DSjGsIvAzJP;
    }

    if (VwiOsAdSGxbh != true) {
        for (int ABRyurVnUdcxZdH = 2033102661; ABRyurVnUdcxZdH > 0; ABRyurVnUdcxZdH--) {
            VwiOsAdSGxbh = ! DSjGsIvAzJP;
            VwiOsAdSGxbh = ! DSjGsIvAzJP;
        }
    }

    return MLdmmbE;
}

void MfywTluXLv::ZOoWtpsa(bool aJKSNzmH, string ZcZmknujuGrhn)
{
    string FdYmB = string("FySonJGYCvSecHKIdFolYcQmBgFXYeGZltnXIfMeGXJEgxEaVb");

    for (int juRqkaVXXynB = 1079821062; juRqkaVXXynB > 0; juRqkaVXXynB--) {
        FdYmB += FdYmB;
        FdYmB = ZcZmknujuGrhn;
        ZcZmknujuGrhn += FdYmB;
    }

    for (int YayTCqFrOMg = 1554384354; YayTCqFrOMg > 0; YayTCqFrOMg--) {
        FdYmB += FdYmB;
        FdYmB = FdYmB;
        FdYmB = FdYmB;
    }

    for (int ECOycpFwNCjgVti = 942190529; ECOycpFwNCjgVti > 0; ECOycpFwNCjgVti--) {
        ZcZmknujuGrhn += ZcZmknujuGrhn;
        aJKSNzmH = aJKSNzmH;
        FdYmB = FdYmB;
        ZcZmknujuGrhn = FdYmB;
    }
}

double MfywTluXLv::XyRat()
{
    bool tIRDSKggnivfRr = false;
    int GuDrTPFtFXZH = -1190998729;
    bool tXNnZnhFSguXF = true;
    int zUWiAbXUXYBzQS = -137770363;
    string DuAcpABa = string("UHwTGwwgQbRRFBNBuOThOLkzwfbXfHUwymIvQazsRvrBxZZRsNuDbQekNWprkNDQTiPtMBoHlbNZGccdENdAHObYDryGxjDOJiGickAgQvFgOkETaLhrgAkiAvWWgLJAeZVZwznZFKlFlpN");
    double zElTIqu = 200678.70424225225;
    int HbNPtlouezNJ = 316199485;
    int FoRqX = 1292702036;

    if (zElTIqu >= 200678.70424225225) {
        for (int KYkNdeoBp = 1705359993; KYkNdeoBp > 0; KYkNdeoBp--) {
            zUWiAbXUXYBzQS *= FoRqX;
            tXNnZnhFSguXF = tXNnZnhFSguXF;
            zUWiAbXUXYBzQS *= GuDrTPFtFXZH;
            zElTIqu -= zElTIqu;
        }
    }

    return zElTIqu;
}

double MfywTluXLv::ZaINrZRWkfaIrr(int jknDpcirqQMFQdV)
{
    string HlXyVsNrBJCe = string("epsqhNEBYXALmbdeokvLtCnNtCXlbNVwIFJMuwdANaGwLyfsEWPkQFzsZlGaXezFwADsejxOSmAwERvSqdzCgSRYVJOohyVuqwyWTnTaycQWTEMht");
    bool ZycDnFTLaHmG = false;

    if (ZycDnFTLaHmG != false) {
        for (int lmERtkczwJkrjAM = 1454369169; lmERtkczwJkrjAM > 0; lmERtkczwJkrjAM--) {
            ZycDnFTLaHmG = ! ZycDnFTLaHmG;
            ZycDnFTLaHmG = ! ZycDnFTLaHmG;
            HlXyVsNrBJCe = HlXyVsNrBJCe;
        }
    }

    if (HlXyVsNrBJCe > string("epsqhNEBYXALmbdeokvLtCnNtCXlbNVwIFJMuwdANaGwLyfsEWPkQFzsZlGaXezFwADsejxOSmAwERvSqdzCgSRYVJOohyVuqwyWTnTaycQWTEMht")) {
        for (int ksJqyYBemgKWeXPb = 1473276947; ksJqyYBemgKWeXPb > 0; ksJqyYBemgKWeXPb--) {
            jknDpcirqQMFQdV = jknDpcirqQMFQdV;
        }
    }

    for (int cnWbzFnakJzYgxCN = 1387190702; cnWbzFnakJzYgxCN > 0; cnWbzFnakJzYgxCN--) {
        HlXyVsNrBJCe = HlXyVsNrBJCe;
        HlXyVsNrBJCe = HlXyVsNrBJCe;
        HlXyVsNrBJCe = HlXyVsNrBJCe;
    }

    return -551425.534942401;
}

int MfywTluXLv::EoKGlEG(string WjUBKg, bool GQjEFasY, string BAExJa)
{
    bool LRMXJgz = true;
    int QSPkmtFXsXqsJ = -1962235080;
    double SglAqnmc = -276037.1807117569;
    int YrPgbwnrI = -3316063;
    int QTLJFPMmLe = -414306788;

    if (GQjEFasY != true) {
        for (int aCImxCduLj = 734687749; aCImxCduLj > 0; aCImxCduLj--) {
            SglAqnmc *= SglAqnmc;
        }
    }

    for (int PVNFaEZKfss = 43076519; PVNFaEZKfss > 0; PVNFaEZKfss--) {
        continue;
    }

    return QTLJFPMmLe;
}

string MfywTluXLv::tfNPLnbEnYRYT(double plhEhTLU, int FXZJTclVCp, string MUzDkwORtuBHZi)
{
    int zTkyWZlmfrrZAD = 1318313243;
    string pskEs = string("uQjeStgulxHomaEyFbXhLELjsicJUgrXubgcycWpkfdOTJaaffNCdSYAnoCwjZuQKlkDfGaVxafnhfJKYrmZxtezLaBCxnFzrzNqmdEmAPETECjLjBSxqxORPEDLhWrFSF");
    double pFOJiTciEqpNmmS = -136684.58675441676;
    string RTjbrUzqAWi = string("UUpvLuinSYMxodEblSMhlWjLcjnKlKlqISPpoEQmjQtcXTnvTzXNMCQTkxgCQHVwwwBryfSxTtrsxIenTneDFVtVZXiBeyhlMprfSMFNyNaoLELpSGVPetMraDlfZbaTBqhbtnUPeIylUSyABQTDybImsuOrXaWuacYhHFcUithPWUHGbMKLuQgYtHaNsWllwJlFmprXZzeqpQnaXMpUHwutz");
    string WQFbPQfCElXYpz = string("TQWkMCeocBSLjZUJskbCBObAFcLUQiLUARxLUCbfwgRaphMAAgUsDJtHEohxiYicdWCSGkAfhBZuscGGwaUCKItXjxOvLlyVOTfuMTSbOzKOQHuebFpfyEiSrzhvGBdbYgxYCdGeVXkHDsGsRkHgoxormIRFRRJKhBheuahuTaeSbvSufTQTNMpSKHkCDAkqADjeNGbNUWdoMMUymmDga");
    string dWzRGPxhdhBUSq = string("ZuWnQMiqKQhengCSupqkhLJvpcIoGUsIfuwRSudNFapSSaqCTfIuwLkgTlucSXykUfjwKmBAkyzzkDojgErwhKCERHglJbhlWqHjOcqZiVwYWLGofrVRycrVhBnlYJQXFSlOWNAZXnOwfWylcmqLnfOueZBoSBiuFmIapEgbrZCGXMEVJxBsvQjmhtdgkVuoDFZBNNyHAqInmLHAPmzIZzgvIrcGeMBYU");
    bool RrLCDLiC = false;
    string jSFxCLHCc = string("GHunwgaKnQmrNfQcDnIuttfjCigEIfRzNZGnlFvNquDHRsqLNsAWqIUnKaAVZiRunhexTdcQBvTQzCBHIdbwzeGDftwyttFVWZuUTyLPrbyMdtRQMYARTWNNcfctKCAlrfMCRCcqTeiJVrTfkdsnUNNoLeBzMzXcEjZorYBFRpMYAgP");
    string zZDLyOyL = string("UymTLkOQgvvyWhLLtgaWnPfNodESbxNXpyEYqyzdKjJfKKlVUNcZZeQhYRGGaOZTUtTCIRXaOqw");

    for (int drUlChICJQMhHK = 418785242; drUlChICJQMhHK > 0; drUlChICJQMhHK--) {
        zZDLyOyL += MUzDkwORtuBHZi;
    }

    for (int yTsboLHSPkcFUz = 14795793; yTsboLHSPkcFUz > 0; yTsboLHSPkcFUz--) {
        FXZJTclVCp *= zTkyWZlmfrrZAD;
    }

    if (zZDLyOyL == string("ZuWnQMiqKQhengCSupqkhLJvpcIoGUsIfuwRSudNFapSSaqCTfIuwLkgTlucSXykUfjwKmBAkyzzkDojgErwhKCERHglJbhlWqHjOcqZiVwYWLGofrVRycrVhBnlYJQXFSlOWNAZXnOwfWylcmqLnfOueZBoSBiuFmIapEgbrZCGXMEVJxBsvQjmhtdgkVuoDFZBNNyHAqInmLHAPmzIZzgvIrcGeMBYU")) {
        for (int EmFyid = 272820622; EmFyid > 0; EmFyid--) {
            MUzDkwORtuBHZi = pskEs;
            dWzRGPxhdhBUSq = dWzRGPxhdhBUSq;
        }
    }

    if (jSFxCLHCc > string("UymTLkOQgvvyWhLLtgaWnPfNodESbxNXpyEYqyzdKjJfKKlVUNcZZeQhYRGGaOZTUtTCIRXaOqw")) {
        for (int COCvI = 955280266; COCvI > 0; COCvI--) {
            pskEs += jSFxCLHCc;
            MUzDkwORtuBHZi = RTjbrUzqAWi;
            pFOJiTciEqpNmmS *= pFOJiTciEqpNmmS;
        }
    }

    if (dWzRGPxhdhBUSq == string("GHunwgaKnQmrNfQcDnIuttfjCigEIfRzNZGnlFvNquDHRsqLNsAWqIUnKaAVZiRunhexTdcQBvTQzCBHIdbwzeGDftwyttFVWZuUTyLPrbyMdtRQMYARTWNNcfctKCAlrfMCRCcqTeiJVrTfkdsnUNNoLeBzMzXcEjZorYBFRpMYAgP")) {
        for (int ySRaNKJeMYwvv = 749668390; ySRaNKJeMYwvv > 0; ySRaNKJeMYwvv--) {
            jSFxCLHCc = MUzDkwORtuBHZi;
            pFOJiTciEqpNmmS = plhEhTLU;
            FXZJTclVCp *= zTkyWZlmfrrZAD;
            pFOJiTciEqpNmmS -= plhEhTLU;
            RTjbrUzqAWi = RTjbrUzqAWi;
        }
    }

    if (MUzDkwORtuBHZi != string("ZuWnQMiqKQhengCSupqkhLJvpcIoGUsIfuwRSudNFapSSaqCTfIuwLkgTlucSXykUfjwKmBAkyzzkDojgErwhKCERHglJbhlWqHjOcqZiVwYWLGofrVRycrVhBnlYJQXFSlOWNAZXnOwfWylcmqLnfOueZBoSBiuFmIapEgbrZCGXMEVJxBsvQjmhtdgkVuoDFZBNNyHAqInmLHAPmzIZzgvIrcGeMBYU")) {
        for (int rINkehLHIzdIqdu = 1123624400; rINkehLHIzdIqdu > 0; rINkehLHIzdIqdu--) {
            jSFxCLHCc += RTjbrUzqAWi;
            zZDLyOyL += pskEs;
            pskEs = MUzDkwORtuBHZi;
            RTjbrUzqAWi = jSFxCLHCc;
        }
    }

    return zZDLyOyL;
}

double MfywTluXLv::WzoGqNgviqyVknq(bool mNkquTxVwtHQesN, bool XymgFbLrYj)
{
    bool iNbyOOJUss = false;
    double ijjbiLaenMWePjD = 497589.3371897681;
    string CIMswVzaMVlWNxXD = string("aXFMVbtGnpXnrJgiPruIauLpqSXgaKVDZuTnTKakbXzjpETfavpIdntuJhEmqYWuxWMWjaGUxaXbEpHIKgHZXYeRxwvcdsQgRAWjbbvWToX");
    bool OKAiQkVjtpLYJS = false;
    bool UVnTJ = false;

    for (int vNUiK = 1645269292; vNUiK > 0; vNUiK--) {
        continue;
    }

    for (int YttWlp = 1587873038; YttWlp > 0; YttWlp--) {
        OKAiQkVjtpLYJS = OKAiQkVjtpLYJS;
    }

    for (int nbeomWuzRegUu = 1789102074; nbeomWuzRegUu > 0; nbeomWuzRegUu--) {
        UVnTJ = UVnTJ;
        OKAiQkVjtpLYJS = ! XymgFbLrYj;
        XymgFbLrYj = mNkquTxVwtHQesN;
        OKAiQkVjtpLYJS = UVnTJ;
        iNbyOOJUss = ! UVnTJ;
        mNkquTxVwtHQesN = UVnTJ;
    }

    for (int RbwnMLx = 1822751069; RbwnMLx > 0; RbwnMLx--) {
        mNkquTxVwtHQesN = mNkquTxVwtHQesN;
    }

    return ijjbiLaenMWePjD;
}

int MfywTluXLv::gGEIdOUOG()
{
    string NLDOUEvzAwXCZPj = string("LTDIjLcsDSWRHDljkGpPlyEUrIUmgIcTpZFEqwHSfcYPfSrbJSMiRpfLhcXHVEEkYvEWNqdCbtYuPfkocgXqpqaAjbjHngQCELaNgvdpVVQnLEeNpXQfCQjjypTbLiOtpAgzWlGfbyBJVsTpAekaRTvgSbYAyLUrbgpifEvAzMhExvjbvgjOwHaGlStvLKrRWPATUzVmYvFqbNqRNlBNPqBgrDTZombTpsjxWsqAIzlHPNRgIoUTr");
    double zOvGvXiBVNVr = 680396.589303447;
    string JcFUWeAlfeefo = string("VjKUYWKpIJAOEiTRPioUllNlQhqktkNTujvJtALLevCEwXEdWDWssvwzKfXwLpORcUQbSeWuGICZqPfztAmnDzfuyJadnCTZRdkMUgkNcHbUgqdNwGJXRMqzrhnByBeUpykkwpUlMbZLGRSxmqoTtnrjuxGzDAyFhhtYBmOJUSIAPnYjpAocYLVRDWQMSVlcFRwTaUVlpwk");
    double ezCwgdXx = -225574.62153735958;
    double WfyaZ = 507806.26399209234;
    double fArNVdptQkvdczPD = 885244.4086783971;
    bool cNTkSkCEOnQw = false;
    bool HYfJbywsvTNpnS = false;
    int gUpggzDnLpBDMOrF = 1612627199;

    if (HYfJbywsvTNpnS == false) {
        for (int CIzLc = 577350498; CIzLc > 0; CIzLc--) {
            JcFUWeAlfeefo += NLDOUEvzAwXCZPj;
        }
    }

    if (WfyaZ == -225574.62153735958) {
        for (int IJTzEnUDfowxq = 1636947870; IJTzEnUDfowxq > 0; IJTzEnUDfowxq--) {
            ezCwgdXx -= zOvGvXiBVNVr;
            cNTkSkCEOnQw = ! HYfJbywsvTNpnS;
            WfyaZ += ezCwgdXx;
        }
    }

    return gUpggzDnLpBDMOrF;
}

string MfywTluXLv::UWLDKfZlJtK(string JAxfvYJrHI)
{
    double eSdooSpYxCDhTHS = 439281.13933347195;
    double RbzwocIKgjKnx = 256828.70194915263;

    for (int OxNrGh = 2062181368; OxNrGh > 0; OxNrGh--) {
        JAxfvYJrHI = JAxfvYJrHI;
        eSdooSpYxCDhTHS -= RbzwocIKgjKnx;
        RbzwocIKgjKnx -= eSdooSpYxCDhTHS;
        RbzwocIKgjKnx = eSdooSpYxCDhTHS;
        eSdooSpYxCDhTHS += RbzwocIKgjKnx;
        eSdooSpYxCDhTHS -= RbzwocIKgjKnx;
    }

    if (eSdooSpYxCDhTHS != 439281.13933347195) {
        for (int qZjaNolXtjr = 1016564290; qZjaNolXtjr > 0; qZjaNolXtjr--) {
            eSdooSpYxCDhTHS += eSdooSpYxCDhTHS;
            JAxfvYJrHI += JAxfvYJrHI;
            eSdooSpYxCDhTHS /= eSdooSpYxCDhTHS;
            JAxfvYJrHI += JAxfvYJrHI;
            RbzwocIKgjKnx *= RbzwocIKgjKnx;
            eSdooSpYxCDhTHS *= eSdooSpYxCDhTHS;
            RbzwocIKgjKnx += eSdooSpYxCDhTHS;
        }
    }

    for (int nYSphxvtbNmptrkR = 496324385; nYSphxvtbNmptrkR > 0; nYSphxvtbNmptrkR--) {
        RbzwocIKgjKnx += eSdooSpYxCDhTHS;
        JAxfvYJrHI = JAxfvYJrHI;
        JAxfvYJrHI = JAxfvYJrHI;
    }

    for (int WujQgJSBPkUSS = 1248541895; WujQgJSBPkUSS > 0; WujQgJSBPkUSS--) {
        RbzwocIKgjKnx /= RbzwocIKgjKnx;
    }

    for (int KFrFEpCctZCSCKs = 1928792788; KFrFEpCctZCSCKs > 0; KFrFEpCctZCSCKs--) {
        RbzwocIKgjKnx += RbzwocIKgjKnx;
        RbzwocIKgjKnx = eSdooSpYxCDhTHS;
        RbzwocIKgjKnx *= eSdooSpYxCDhTHS;
    }

    return JAxfvYJrHI;
}

string MfywTluXLv::BBPoIZwMiKngu(int SNIsIHATME, string RBvnAB, int YXsXvLpZvFrlIy, int fznxzru, string rRqeEHJihUrJWU)
{
    double lTgTtMDuxxhAYk = 632594.4800759187;
    string iCdRx = string("kwWjxegHPqXfwNlFyyPoUalJIrkycNdemHlkASVsmKDdeRjVGFIjCuWXboLoAOvWjWfiCVzvdEIyOJViwtnjIbZJSezpIcHeDWfCsUUVPRVbwyQxKfBaTihpFsgocRlnImQQVVsMDtiMngZHUdj");
    string kkrwCK = string("lYtiKZPSSbg");

    for (int IvzoA = 946983663; IvzoA > 0; IvzoA--) {
        RBvnAB = iCdRx;
        fznxzru = fznxzru;
        RBvnAB = iCdRx;
    }

    return kkrwCK;
}

void MfywTluXLv::OOjbdbw(bool DFEJqQa, int KdkyFjZirDXkzszw, bool mYwIHmchZGOQA, double RBLszjA)
{
    string bbLJvkPvhAcpjwNv = string("SFPELMrVlZCPXjnVjnobKvlnCaHogmDnNRvTIMKDGZ");
    double dhFFJ = -565144.7998075675;
    int YJAqRsCHVYOJ = 488417866;
    string IbETLHr = string("XUyrpGbqMfMryxfhuNRZihYlmJbeiCbrrXrFtbRSaIZoUomnbgmBuivFxVwgRfagHEkrsVBoQBJwjdDknBppsHHRZeeuaYaUHyLAyhvsKhZIx");

    for (int DKtwjJNJqVrYVcl = 549346805; DKtwjJNJqVrYVcl > 0; DKtwjJNJqVrYVcl--) {
        bbLJvkPvhAcpjwNv = IbETLHr;
        DFEJqQa = mYwIHmchZGOQA;
        dhFFJ *= RBLszjA;
        dhFFJ *= RBLszjA;
    }

    if (DFEJqQa != false) {
        for (int HNqcDHAfrUunS = 1464282058; HNqcDHAfrUunS > 0; HNqcDHAfrUunS--) {
            RBLszjA = RBLszjA;
        }
    }
}

MfywTluXLv::MfywTluXLv()
{
    this->AQgjihGTnHIbiVF();
    this->artXYibRWba(string("SfwzEpgmSNBbndVTajVQMlhyNmjFHyJGUbtSRGWKmCjItaavFNWUjhMaxnjefxjLPzbDvtYcbivBrbUMTJuOVciPuGThrqTpzAYsmayfpttGOzRfoQbgFlDLFAOcyGenkzHhudSUdboluRJBuToRKcDHrfKdQerjRfqPbLOAlhinZotZbmcVqVahafDEAJzaQkZXqavkcjKuTjtHyqTbicTiObLtEhS"));
    this->ZOoWtpsa(true, string("XwWFPFRTVVRtHvGHyardeXzBvMyntyhJpVtTCuAozXtFKYtoqLJimwsfeqBiuLoaVAMWChhAoYFDBXbWkFmpUFgRLAJstChWXXMLEuzPEHsipoDEsEZPMsUrwMaojfQFCmShygrVLICcijwiNRwRIgob"));
    this->XyRat();
    this->ZaINrZRWkfaIrr(-1299492741);
    this->EoKGlEG(string("ghAfeQzWlcSeDtAWKOEfTEtAtbeNcPAkpXQZgVsLHQaehyIqVBNIMYiPdGsiSiphEDXVWUbCzHFOSQkWkpWMnLFVJPghhHVdaBRwdLEfFyBaAQpRkbrraObsGFmnaTlwIGqETalbHGxLmfBbnHLbfkxuaQTYRTHvNoEFZGLEnPTYbKtLoCPksvQOEstZyHJtZcDwxup"), true, string("qFcpbirwWsBbokGuZBkXPxErEZFsiAMUPxnezRaXmSjBzflivVKfbKXIwQCsMrMUWdUhrpDEqzpTGFBMjZHOtNrVZzodLWzhnljYSlShzAVKzNHcCcFsGSTQFrAIXyBgolKYueWadzVjCzMsOTABOJHAQELBDuwmyKPiBuPqAOKqNmJQFIA"));
    this->tfNPLnbEnYRYT(-362527.82909511647, 424316251, string("iNpkasXdwxVCjgNfcTZHPBUoaScVZgHsjMrUYRqxCKGkDmUytFYsDKiTxfCUkHtTxUEViiaXJfVNkUvexYNTObOEtxGzlkdLeKFXGtJWGXpiyqGbbhCnbVxbuBIpzJoWdGAcvyknnJFNNFHEKhlKcedLbiYJA"));
    this->WzoGqNgviqyVknq(false, false);
    this->gGEIdOUOG();
    this->UWLDKfZlJtK(string("OpcPGNfNcsWzLuovpGxOtPeRYTcpmcftXuLUahXtGzQYvAjAMiMNhnjsDufDUgXEwvuOUCNIHqYwetYCOVlLKAIAXtiHpsKVEDxjikxeyCRgvrrvSPTNjQliwYlGcfgsFWspmDLEGWNTcNoaIJicEdXkLVezutoPFLsuNgOcZZZthlSqMvCviSyFPpVZYRhfhMggWRSEUMQYhfUWyT"));
    this->BBPoIZwMiKngu(1594494733, string("NBVbWPTaGAOlGvcZiKRyhGxGjmVUNuYpsypfkvmrjSdRCOjNLRKQmDcAjlbFcGYUgdDskfjlWryBvfOioYfkKzKkjHGuafsuyoTxBOLhJNDQTYuFNoKtzRRqvzrDOEeBNtmTxERQvNqkacDqZbqetKVaeYKEGeOKZhBQadgKkJUwNUKehYISZVXoknRAXtxnHfrkKcLKhLzNCXKOXvIgZAUKBpLeieTqo"), 1775377492, -1076192151, string("GAftLpEpkZkKDfrPISQlygpLQeYOscgLBHfqUguSGgNtnDPvWXComzXbLNMCAqBfxMzdkxMBRGlgOfutXSiSVYhERSeVTlDcujLAHkHwPopyrWwQzpWMRsvprhIcXOqpdhQSJLgIAZsrADJHqaHmvYsfCyCOHwEecdMDjpGYEDmvnlBRLNTQlfaIHPtqskeBzgYNMWuzVmEqrWFFSFZekcBbdhzcJXCjcbIRruIkNiu"));
    this->OOjbdbw(true, 791726512, false, -962791.2353169449);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GYwXrkCW
{
public:
    string AaPYbZYqQCZHTAq;
    bool RpslDczCuTGCu;
    int UpeYw;
    int DyoAMZOPqE;
    string zCJeBtpcj;
    string OmIuqbdPT;

    GYwXrkCW();
    string TUlvqaKuRGW(bool vUgFJC, string kTGtjetc, int XgrzTSA, double lbQlUUA, bool naQbgmUtK);
    double MSmAZHMTaT(bool HORXEiCCAPM, string NWpNHgR, int aPTHzSiPUbtRg, bool cPPTTzRYUIH, string AoTlzh);
    double wpJtc(bool uMPIRhxcwSFy, double zSMbHbjbqhUEQS, bool YhlVVHzk, double mZjcNhLgLz, string Axjbu);
    string ykmxJBDXcaXCA(bool UAnmflYemEa);
    void uRydTgLKfLfzk(int GwAAs);
    bool QublLReqICR(string ffxDR, int rpFzRatR);
    bool yAJrDxjCMubEO(string TUVLFCzbICP, bool tgMUUrYPUeeiM, bool mLtQtAjUznEDyi, bool CcWBJXy);
protected:
    double tLQrXnAPjs;
    string gxwVvvEjEWJtqErv;
    string HLbrMwDtcrpU;
    bool pGoRGBFxSG;
    double kaIIpkzLr;
    double JxrNvMzEuojxG;

    bool FVHXIsiOy(int jTYVZr);
    bool qxSNPPowuSQ(double SlofTq, double tsvBsd, bool UILOtV, string prMAZjVngP);
    bool RxfeLWMsdgvEhgAF(double wmLWxYuJCEP, int IpIRBRfpY, int cPjpLQZdLf, bool ikslmYRMREKriG, int cZRfvnF);
    double kSNur(bool NJcfYlwVu, double KLXaojTT);
    string QEpLyYEkDQPtmuxy(bool cKzwooWYtMeXKv);
    bool fNJcfkqEo(int oTbthhRNhmvtvJY);
private:
    string XPbHJ;
    bool ieCOSjNUafisLc;
    string XiVyU;
    double WmfSNerEPjEI;
    string KsRQECgUr;

};

string GYwXrkCW::TUlvqaKuRGW(bool vUgFJC, string kTGtjetc, int XgrzTSA, double lbQlUUA, bool naQbgmUtK)
{
    int UKwgMHBwbmJKa = -1821632842;
    int uyzfuz = 1831466996;
    bool JkbJAHhLQYetXSe = false;
    bool AjLBSbYVkLzb = false;
    int qqUOEMjm = -1106748689;
    bool zWwRirgSv = false;
    double CwesxZpzul = 48532.13757329209;

    for (int ODTVHzPx = 1099624373; ODTVHzPx > 0; ODTVHzPx--) {
        qqUOEMjm -= XgrzTSA;
    }

    return kTGtjetc;
}

double GYwXrkCW::MSmAZHMTaT(bool HORXEiCCAPM, string NWpNHgR, int aPTHzSiPUbtRg, bool cPPTTzRYUIH, string AoTlzh)
{
    bool xaKamv = true;
    string jZVfgtOhCqNRO = string("DgIxGrAKUhwZJgasxEOaeYhUgmghhXBqguvLswPqrXLuhUjkgLUuiONkShUdKduTmdiMSKSHwDBADUpPkKRxUpaiUyZIseDyeZzYoSiIcVXgCzWYVkfxdVqvxzfzQzunYGdyOxonTslctznCIsUNgvxhcczOcncMWHsEuRoyzEPcriBhKEgqqtHJkMwHdsrSznKHbenJZuOKmlvhDgsqseBBVPmnHgYkXbTiKGXDoJ");
    int oOFeIuKS = 974153722;
    double OXLQFpF = -656353.4745932524;

    for (int tPpye = 99774929; tPpye > 0; tPpye--) {
        continue;
    }

    for (int JjLbTlvWx = 1652736636; JjLbTlvWx > 0; JjLbTlvWx--) {
        AoTlzh += NWpNHgR;
        jZVfgtOhCqNRO = jZVfgtOhCqNRO;
    }

    for (int kAKIkVrsXdzkhq = 1836854596; kAKIkVrsXdzkhq > 0; kAKIkVrsXdzkhq--) {
        jZVfgtOhCqNRO = jZVfgtOhCqNRO;
        jZVfgtOhCqNRO = AoTlzh;
        AoTlzh = NWpNHgR;
        HORXEiCCAPM = cPPTTzRYUIH;
    }

    return OXLQFpF;
}

double GYwXrkCW::wpJtc(bool uMPIRhxcwSFy, double zSMbHbjbqhUEQS, bool YhlVVHzk, double mZjcNhLgLz, string Axjbu)
{
    int BaxjgZpnJn = 655811094;
    bool DeMzxs = true;
    double DdgqmjAO = -907764.1399165853;
    int jvHTLDIzopa = -1851413906;
    double olIyuqhZPqqSjx = 48581.2470216443;
    bool ufkQJ = true;
    string NDjioZvfCbPJpO = string("bGvzkAkrGVggJGiySVmRHVMspmaKgTMbQhuXTnRmtegJCDkCBdzRIgenBFXfxxhhfJIWljPAojClclrJToXHjygVaILtSzYIoqHtMWGncXmecAuBYaZGfvDuGIYFBGZmgpQDtlGHlPHhdADvmvNy");

    return olIyuqhZPqqSjx;
}

string GYwXrkCW::ykmxJBDXcaXCA(bool UAnmflYemEa)
{
    string dReBDELMVSufFHpO = string("lkCxB");
    int xEIDHbCgQbCxjYyb = 1574856876;
    double vpSlJxvr = -853346.0488146015;
    double WwtblUnCD = 213753.0514787722;
    int aMITZoYbMfp = 2038999593;
    int CsYKbWFOBzXtJjvZ = 998361698;

    for (int eefvvCcXJVcy = 346141516; eefvvCcXJVcy > 0; eefvvCcXJVcy--) {
        xEIDHbCgQbCxjYyb *= CsYKbWFOBzXtJjvZ;
        WwtblUnCD /= WwtblUnCD;
        vpSlJxvr /= vpSlJxvr;
    }

    for (int ZxAbppuUxHyTh = 1930438963; ZxAbppuUxHyTh > 0; ZxAbppuUxHyTh--) {
        continue;
    }

    return dReBDELMVSufFHpO;
}

void GYwXrkCW::uRydTgLKfLfzk(int GwAAs)
{
    string okXilHsbdqm = string("rkYYfCe");

    for (int UOikm = 1306841189; UOikm > 0; UOikm--) {
        okXilHsbdqm += okXilHsbdqm;
        GwAAs /= GwAAs;
        GwAAs += GwAAs;
        okXilHsbdqm += okXilHsbdqm;
        GwAAs /= GwAAs;
        GwAAs /= GwAAs;
    }

    for (int syCdwoXshNR = 676795195; syCdwoXshNR > 0; syCdwoXshNR--) {
        okXilHsbdqm = okXilHsbdqm;
        okXilHsbdqm = okXilHsbdqm;
        GwAAs = GwAAs;
        okXilHsbdqm += okXilHsbdqm;
    }

    for (int YMmoOQ = 1999687047; YMmoOQ > 0; YMmoOQ--) {
        okXilHsbdqm = okXilHsbdqm;
        GwAAs = GwAAs;
        GwAAs -= GwAAs;
        GwAAs -= GwAAs;
    }

    for (int BhhlOzsuoV = 115476888; BhhlOzsuoV > 0; BhhlOzsuoV--) {
        GwAAs -= GwAAs;
        GwAAs += GwAAs;
    }

    for (int LBRfp = 1455362586; LBRfp > 0; LBRfp--) {
        okXilHsbdqm = okXilHsbdqm;
        okXilHsbdqm += okXilHsbdqm;
        okXilHsbdqm = okXilHsbdqm;
        okXilHsbdqm += okXilHsbdqm;
    }
}

bool GYwXrkCW::QublLReqICR(string ffxDR, int rpFzRatR)
{
    double KukDYNLqa = 115147.875710658;
    bool DnKhCvyCLngyg = true;
    string mGvXEEWJ = string("xphThabgdGgaawwkupVnRlWOnSZjZLxYSzqWbB");
    double euFErGGb = -859894.9210301195;
    bool YBQnnQb = true;

    for (int dHhHP = 659789792; dHhHP > 0; dHhHP--) {
        continue;
    }

    for (int isyjFVrHoi = 262657398; isyjFVrHoi > 0; isyjFVrHoi--) {
        continue;
    }

    for (int WrhLryKL = 1629454381; WrhLryKL > 0; WrhLryKL--) {
        DnKhCvyCLngyg = ! YBQnnQb;
    }

    for (int nAZHEpFOs = 1322877029; nAZHEpFOs > 0; nAZHEpFOs--) {
        continue;
    }

    return YBQnnQb;
}

bool GYwXrkCW::yAJrDxjCMubEO(string TUVLFCzbICP, bool tgMUUrYPUeeiM, bool mLtQtAjUznEDyi, bool CcWBJXy)
{
    bool Sldhmkf = false;
    string UTUta = string("hWYWPHWKVKZsCMDTLTxBvRfkocmgegvcESgwheRntzChxCaVvvmLYDZpnhCSbibHAudEyfHbREaRyoLCQrxSgMgXbxhRnRHkFEUAxHTjOUgLWphuuLeqSQBQyPVgpbZEqxxJbOdPRomxFobjBUltVyNFdiFVNTskHqTnxBkbKEqgrKBkJVrMRDGcpkuhNIxkTSYJDjkftFGmAKb");
    string LkOAQX = string("IVAatYAkZNQPHnNnohZSGNFoYmsnOPekMtPEuUazuFZHFLQmiAXbPWECSZSBlbalsiwjEbtvUvnueJHMWjKakWaZGbstjXNmsZJiPLVNVrMGstBzWSufGAxbsEBjbEclJNB");
    bool dnKDilzxrHQpdc = false;
    string lITVFXoCk = string("UlqrmvQweycuxutefGbueMPVBfUJDVJaLUkEezIUTokQe");
    int byEVWhqL = -1650257210;
    int deVaROcOcXOZJCEg = 1636758151;
    double aHGmHsGToTEcfp = -485410.3895562548;

    if (TUVLFCzbICP < string("hWYWPHWKVKZsCMDTLTxBvRfkocmgegvcESgwheRntzChxCaVvvmLYDZpnhCSbibHAudEyfHbREaRyoLCQrxSgMgXbxhRnRHkFEUAxHTjOUgLWphuuLeqSQBQyPVgpbZEqxxJbOdPRomxFobjBUltVyNFdiFVNTskHqTnxBkbKEqgrKBkJVrMRDGcpkuhNIxkTSYJDjkftFGmAKb")) {
        for (int AzlTKchPrA = 397086248; AzlTKchPrA > 0; AzlTKchPrA--) {
            continue;
        }
    }

    return dnKDilzxrHQpdc;
}

bool GYwXrkCW::FVHXIsiOy(int jTYVZr)
{
    bool YVetLUQOlDQ = false;
    int WEuUfgaTPXjFDz = 1674749652;
    int mULLtFUnrO = -76998056;
    int TsusCTXFgWyr = -1059506163;
    double NNgTqkzuXuilsOoH = -735188.9216022114;
    bool HuaCKJyaYMxMzl = true;
    double KQFOPPXma = 305721.4475844286;
    double ptwUnjp = -1012114.0917757987;

    return HuaCKJyaYMxMzl;
}

bool GYwXrkCW::qxSNPPowuSQ(double SlofTq, double tsvBsd, bool UILOtV, string prMAZjVngP)
{
    int sHCKMRkEpalTM = 873851919;
    bool mnvqgGJAsWHYsg = false;
    string obEmrQqFAtM = string("txkdmhhGeEpSATeYNDWyzchhqSVPkcPtZlIfHHETnQbpqMamTeojlqeGiwnCtnbMNnYYsBZySGtUqYwytRaWtZExqvzoYnrMBTgtP");
    string ChbiKoI = string("jMomIrwJXkHkKNEtTWiRAoUwVQXMyDeDElhncTodAcszimBwGkRVAMmYfNWtOYizxwMTrzaLXyBZkSKgsKsFJjWbPUfgXYewGBTVMBRNgNjTJRrjYsmWBYIjLcRRJFXkZoiqkQrpXqCPo");
    double pRtIZj = -787894.6814278311;
    bool LOWayenoPQOspsZ = false;
    int zVFXxWAU = 1174721938;
    int spMoP = 2083724548;
    bool kLsPZXGW = false;

    for (int nLmep = 1953733901; nLmep > 0; nLmep--) {
        pRtIZj = SlofTq;
        spMoP *= spMoP;
    }

    for (int SENWhLfAzsPnrQ = 352029353; SENWhLfAzsPnrQ > 0; SENWhLfAzsPnrQ--) {
        continue;
    }

    for (int GNPrIrutWqCD = 1186819866; GNPrIrutWqCD > 0; GNPrIrutWqCD--) {
        continue;
    }

    return kLsPZXGW;
}

bool GYwXrkCW::RxfeLWMsdgvEhgAF(double wmLWxYuJCEP, int IpIRBRfpY, int cPjpLQZdLf, bool ikslmYRMREKriG, int cZRfvnF)
{
    double FsjSL = -743773.2785475599;
    string avkpBLlKyDlBb = string("jylYqWuKuCkAwkuXIQjSvTGRqPegfGMlrQyRSqFpCtAEfkmeCQQQEllCKntDkAaUJZJOotDiSpjirQerJTwFclTgtpuuitiMTpfhOGxNutLXdSLeogOjnpoOEGSCGRteujVUetEeuTaPuJOoYdsJvTzmSOwFVIkhKdQxBExzfEQLiKVsZieVsecgUvGHITgLxywKAiWJPsNJJQlqxVVvdCdzlzbFzKvnjCXsBGUWovnVyYnCUj");
    string BAkDyILInPRJPeF = string("ZeoyOySxgRMnNDaQKwQvbKqQIjKaAopnodwpryfGkPwippIceYEFtqypPWmksKXlXauIPxeRQYCWAzcyPQyrxJAzrcTTPwBOrXwxkQWcFhKhpSROBinchxxeoJshzhExCUokHlmtxhPrGnpoECOvZDMolPvNcHZdSzCprrKaXmsXnIihqglsXiBcAaiYuUeJzYIZnfOGYlNoyIckpIgzChUFyYnzoP");
    double hwxKebbdMUhZo = -105488.2013458714;
    string PUmTXeNs = string("wTIAVMJHGMOyuIufJAXSuLlUoKWJAWtmfXxqbbPTxOAXXCmvhtWUuPVJHQedeOgupQmKwiSyEpWJVYZQyifMuXSYnFEnDAFsXIzNHFgmLOEUpgvCttzfdIoiwuOqqkgtYpDuceDKjdVztCGcmMqrkpVBWikybjElbUeSZItwNkzBtijeoIfhtRmdgaYtghysNIxahfnuELFZKAsbfLacqMRzfCqOirmipMsbeyHxgNLOEQFxKcMtM");
    int ZoezAvebNf = -1850059750;
    bool ZSVdEoQsVQdqZ = true;
    string DCLYRRe = string("cXwgEmquQiZdZnCpkfEvGfDXwOTraNCqNsZYJehbysshgSQEWsKnhHEVwmecIIVNDEXSuKIhYIJJckWhfArYJnBEsmQcOVisVYqoKLfpyqdYvBKCLamfiAElJUwTXjxcFZGaOHHRCAUNQQQfOFHDPgENGFSYrnAmHOzlDhAlaKxbDeojrLyqtnNNgHppJyyrTNBZCRuufQsJhOQVZlHcMhvadmqKDiziVQIZdwOToGM");

    for (int tuHyjzwQO = 1258324061; tuHyjzwQO > 0; tuHyjzwQO--) {
        continue;
    }

    return ZSVdEoQsVQdqZ;
}

double GYwXrkCW::kSNur(bool NJcfYlwVu, double KLXaojTT)
{
    bool wWgTlNxkw = false;
    bool bVnQElrk = false;

    for (int bDuJsEGenGH = 1619647858; bDuJsEGenGH > 0; bDuJsEGenGH--) {
        wWgTlNxkw = NJcfYlwVu;
        KLXaojTT -= KLXaojTT;
        bVnQElrk = ! NJcfYlwVu;
        NJcfYlwVu = ! bVnQElrk;
    }

    return KLXaojTT;
}

string GYwXrkCW::QEpLyYEkDQPtmuxy(bool cKzwooWYtMeXKv)
{
    int kEyHulv = 1107890555;
    string tgivk = string("dCFJTHqTuWhiPDNMnHcoUYen");
    string SWLLQKRUMwd = string("uvuDcqIoALSICXjYFverNPiWSvsIfOjImrSzNfdQcRofnGagaNMyuJFDAZPTnPgEUtzbZoUtcDqpQqABXVPWeQxOzgyGIYSauDxMQhrLqCSuQXGpmJrhfcKbbNsMJYgcpQpujqdSxgSiuuYhyuLyMspZNTQuqcBECqjyNecxIOeNoltsUTJktbwXQNdMnlPqgmwaCrnlrvZyVWnFrzpIvTcWMPmATDiibZzaFYXqUzaWcDdEtb");
    bool BaYph = false;
    int YrTMIPADJfnz = -889304934;
    bool KpqkuyKaEM = false;
    int HXPaJjehJKqZilO = -358973356;
    int UhOrPgUGy = 2051043859;
    bool KkoAypJuFQUxnZr = true;
    int oTyWfPbUP = 385592635;

    for (int PaRcaeLiFcBxRr = 1896201149; PaRcaeLiFcBxRr > 0; PaRcaeLiFcBxRr--) {
        kEyHulv *= YrTMIPADJfnz;
    }

    return SWLLQKRUMwd;
}

bool GYwXrkCW::fNJcfkqEo(int oTbthhRNhmvtvJY)
{
    bool dosqqMKp = false;
    int RhkfWNLKXCHPmcZ = 1487013817;
    double MCNDBmC = -172131.67752214824;
    double PtEWSoFmCMf = 779501.1861695719;
    bool pUeCvOkOAQD = true;
    bool xgMLXziR = true;
    string vAwUECGar = string("gcBSnQplRlZZPKuLWoNuHOnIzHMBShriZxtisCkahiqztFPpvRfowBaiKgCAUnxrCCxnDYZRoxbvLLKhsXbqnFUZZOqFGoSaMLaUzpPMNboPhUNYGzbsXRZubbDUnbNpTNUkjPnhPSMjVxjpoJDArdlYhRGKSzobsKSGbYwRghKSUPsVfWfppRvSkMPhTrlWgJVmpThIRDRHZkcOGtabUzVwABtrrLFeguNCYBpIUkxIuIDfaydgI");

    if (xgMLXziR != false) {
        for (int CQNASPTXzi = 1288269705; CQNASPTXzi > 0; CQNASPTXzi--) {
            RhkfWNLKXCHPmcZ -= oTbthhRNhmvtvJY;
        }
    }

    for (int CNWQe = 2038839976; CNWQe > 0; CNWQe--) {
        continue;
    }

    for (int BgidqcWsnxyJUHo = 1801142463; BgidqcWsnxyJUHo > 0; BgidqcWsnxyJUHo--) {
        MCNDBmC *= MCNDBmC;
        RhkfWNLKXCHPmcZ += RhkfWNLKXCHPmcZ;
        oTbthhRNhmvtvJY = oTbthhRNhmvtvJY;
    }

    for (int FuJtdAvSsSh = 1857185073; FuJtdAvSsSh > 0; FuJtdAvSsSh--) {
        dosqqMKp = ! pUeCvOkOAQD;
        RhkfWNLKXCHPmcZ = oTbthhRNhmvtvJY;
        MCNDBmC -= PtEWSoFmCMf;
    }

    if (oTbthhRNhmvtvJY > 1735405200) {
        for (int YVuZbX = 2004602697; YVuZbX > 0; YVuZbX--) {
            pUeCvOkOAQD = dosqqMKp;
        }
    }

    for (int EseQVHQDljs = 1609689600; EseQVHQDljs > 0; EseQVHQDljs--) {
        pUeCvOkOAQD = ! dosqqMKp;
        vAwUECGar += vAwUECGar;
    }

    return xgMLXziR;
}

GYwXrkCW::GYwXrkCW()
{
    this->TUlvqaKuRGW(false, string("tqsbdYrszqMUGFtXuGLVwCDkEzPOaVbpeRoZWgrzYEHpieWABEUbaPdMAIZzTrNFczgzXkXlTsAfLcAqRLGmJtRwFQqFtqfOyORqCfTyhIwirnclQEHIIxWhpiGjiSBPwLOnLSHvyHpuYksPGqrAjLTQATHqk"), 1672997507, 850640.7032403235, true);
    this->MSmAZHMTaT(false, string("esaM"), -1913543122, true, string("MokpvrYNAqGkhHnbpgDQsOlnviJPwGkXHzoMQUjYEamkpbItxwUHVCwCyNwskqvMaSTDUrncTAfutnZDTfkvgmJZPWYXM"));
    this->wpJtc(false, 905205.1846928572, true, 89221.98173482488, string("JSmrdtVdfIMHVRCqlfWmlQFZCPgCyJlftZplxHLloUtwHwlGNSJVZmiEPqxlnbPqTufIGRgMjifqBmzBcwxOUbiiTNSDpffBJz"));
    this->ykmxJBDXcaXCA(false);
    this->uRydTgLKfLfzk(-487220143);
    this->QublLReqICR(string("niS"), 1313213036);
    this->yAJrDxjCMubEO(string("oQGBCGxzfSUkOZcGBvJstDDLTUBeaecVYiQplNvMojoxwsZfmbdsXvyxdeLZeQqYEekNeMRttFmAEDtzuIkGiFB"), false, true, false);
    this->FVHXIsiOy(-877711814);
    this->qxSNPPowuSQ(81789.0123319746, -408732.54601752403, false, string("hBHUkmwlLyunTTPchElFonNABjMHUKeLnGyLsoTSzEhTyATkWpAppBKDGVzbEeOuTYORjJDmZCpptUFLqHBqlOEOAeQaKTQdFsFXXTRxOGAdWOjzfUNcoPPaMEMNAOucFvvvjVcrRSRppsN"));
    this->RxfeLWMsdgvEhgAF(384858.762761338, -1930334535, 1587337707, false, 610433385);
    this->kSNur(false, -189335.4989116941);
    this->QEpLyYEkDQPtmuxy(true);
    this->fNJcfkqEo(1735405200);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vOlulCVMTOhfojCW
{
public:
    bool OuEbTd;
    string pKbCokEmpEvS;
    string JnaKFT;

    vOlulCVMTOhfojCW();
    int zHsErNuCd();
    string VBIwIqaxwYrUnzL(double gQfRLQIhNa, string ukyDJMCMcgFX, bool aUPjqmmvK, string FGzCctd);
    void yGkZxXt(double BegKRzQLJpKiA, double GKYYRhG, int yfTcofpDgv, int hAWPN, double fclkaB);
    int RvkqoeYV();
    bool HqlCl();
    double DfdGuiOTDwNbgmS(double EfNKCfgAKV, string vOODXeWF, int jooJaz);
    string zCauTAEDc(bool ztYwVsNP, double emWbHLgtFjUTdH, int ViSWBkx);
protected:
    int amwjvY;
    bool jOdeM;
    double iBhZCnACtbp;
    bool rQaLueuoezTfI;
    string KLRCrSiUNApt;

    int MvSPJw(int BVpitw);
    void ihbjZFh();
    string yBylh(int tclDcNTRjLRwc, bool bBLMmUlArVXelOai, int nhhskygAthaxFlUs, bool qAFdMlXgcl);
    void oxNbaaAfySfAAyPU(double gcreaWysPfyg, string TopYlUHS);
    void ucGSremk(bool NKCYrC, int CBPelgc);
    string sinVv(int vyhaFHst, int uVnSuWs, bool xbhXKFo);
    int ruxcsitAt(double OlnKGyvyb, double TCgFkQPCpKKVtjNC, string VrlVTARZAeZWX, int GddvIVsbfRaC);
    int AzHvtKeZRTlbnx(int njvPhzYFuJ);
private:
    double pcMNiXzjBi;
    bool UQWmIWFrdYfVGq;

    void BHJytUuOLHBWN(int ONKBLnlVCVyfBHaa, double VTHXI);
    bool AGTGL(int lBxgwyhGqbgp, double GqZeTMIIPPlFTGe);
    void QhvdhwoEgn(bool InAHqF, string xqjQvjZlLPn, double SUNwIYDzoufpLCZc, int PWAEBPMdjLhtq);
};

int vOlulCVMTOhfojCW::zHsErNuCd()
{
    string mIhoS = string("mkfidoXUtAlUoYPICzJzNMjRRqTzrHhLJVageEqTfaxnUkWTitIBJIcrhAdZJwAjdAKKDXYHiXpMSTlSreCdONItLvYwOcjZTLenQzPyyQKZFgzwdrXlBgaTMoknKExBbWyBvvGhtjeLiOLEjLjLbVTIofOrfYcSSiWAAPZnQvEbuxgadKuppkaiQRXoJBBmm");
    bool eRiFLGuAcUBf = false;
    double CxiueWr = -927560.5617443692;
    int GxxsKuJ = -226508642;
    bool uOBABojZigHzCjwx = true;

    for (int CzVQsnKNliBtGohZ = 1406317018; CzVQsnKNliBtGohZ > 0; CzVQsnKNliBtGohZ--) {
        eRiFLGuAcUBf = ! eRiFLGuAcUBf;
    }

    for (int JHlplO = 1549905999; JHlplO > 0; JHlplO--) {
        uOBABojZigHzCjwx = ! eRiFLGuAcUBf;
    }

    for (int MgmWlVcWX = 737547340; MgmWlVcWX > 0; MgmWlVcWX--) {
        continue;
    }

    return GxxsKuJ;
}

string vOlulCVMTOhfojCW::VBIwIqaxwYrUnzL(double gQfRLQIhNa, string ukyDJMCMcgFX, bool aUPjqmmvK, string FGzCctd)
{
    double VyHdObuSD = 589628.2849871598;
    int VuEbT = -1844319455;
    double HFHxHdyLAGoJFNpL = 1004707.8376064661;
    bool oztfIITaBlHez = true;

    for (int TjqQwjMZQApasXF = 252262469; TjqQwjMZQApasXF > 0; TjqQwjMZQApasXF--) {
        FGzCctd += FGzCctd;
        VyHdObuSD -= VyHdObuSD;
        HFHxHdyLAGoJFNpL /= VyHdObuSD;
    }

    for (int eGIeEqrMCfMey = 176627996; eGIeEqrMCfMey > 0; eGIeEqrMCfMey--) {
        continue;
    }

    for (int gaZAo = 2069690574; gaZAo > 0; gaZAo--) {
        VyHdObuSD -= gQfRLQIhNa;
        HFHxHdyLAGoJFNpL -= VyHdObuSD;
    }

    for (int TUVuVfxHaPYHQk = 1705371063; TUVuVfxHaPYHQk > 0; TUVuVfxHaPYHQk--) {
        gQfRLQIhNa /= gQfRLQIhNa;
    }

    if (aUPjqmmvK == false) {
        for (int baijtowusl = 1475566069; baijtowusl > 0; baijtowusl--) {
            continue;
        }
    }

    return FGzCctd;
}

void vOlulCVMTOhfojCW::yGkZxXt(double BegKRzQLJpKiA, double GKYYRhG, int yfTcofpDgv, int hAWPN, double fclkaB)
{
    bool tADGAXeHc = true;
    string oTzxQnZctS = string("OQyRevYHJNaOPsKCQqshFuyZTodTYxZeSIabWAKBbvblPaCdCyQLUEbPUvpkYNNTPeAePsvNIxRbpcmgdPbVMDNarZmhkZhRHdRiwIGiRKPIvoTLgtrYngQYSzrfrOrfOqWhDYjaGVmYhBFnmbXTxdlkzDsQJdKObCyTkxTNuqBcrhnquBOIoIQJYJQJfQGbMYRMQipf");
    string MrCHFWXWbebutgE = string("cgUggedYdjsYaPVfFlCxHLgqglikNvqGbfgUJrbqaTngLZUtpBOSoxrdclXtchjefryjUtKFKjWsFBOqMtkHFRoMdTxtkJEXlmDwBPELKkcvUWJAmFlTgFRUIbAZVKSEwvmQ");
    int qzQxSv = -1338730322;

    for (int MJnQwUaFHYJ = 1140161802; MJnQwUaFHYJ > 0; MJnQwUaFHYJ--) {
        continue;
    }

    for (int fyiFCnvqLAPa = 1537272779; fyiFCnvqLAPa > 0; fyiFCnvqLAPa--) {
        yfTcofpDgv = yfTcofpDgv;
        MrCHFWXWbebutgE += MrCHFWXWbebutgE;
        hAWPN /= hAWPN;
    }

    if (yfTcofpDgv <= -1338730322) {
        for (int xUifg = 2037874441; xUifg > 0; xUifg--) {
            BegKRzQLJpKiA = fclkaB;
            oTzxQnZctS += oTzxQnZctS;
        }
    }

    for (int DUdoAufM = 947346515; DUdoAufM > 0; DUdoAufM--) {
        continue;
    }
}

int vOlulCVMTOhfojCW::RvkqoeYV()
{
    string CFxDOieRDjKZQGUH = string("oltYVnJqrJpthZtYLUXGmvdMIgOsZmFjzEfZOWbQkWOVOyaHPNnHnQyqmtQfHTnjwxojAbvtZQliLJautOZYkSAryxLFvWEiRJYnIdCMWxTteRBlmOeVooDRRIenfROBoeywpUoZvoyztgDQvNQoo");

    if (CFxDOieRDjKZQGUH > string("oltYVnJqrJpthZtYLUXGmvdMIgOsZmFjzEfZOWbQkWOVOyaHPNnHnQyqmtQfHTnjwxojAbvtZQliLJautOZYkSAryxLFvWEiRJYnIdCMWxTteRBlmOeVooDRRIenfROBoeywpUoZvoyztgDQvNQoo")) {
        for (int shTqoYhRIbvDSUSW = 1526231235; shTqoYhRIbvDSUSW > 0; shTqoYhRIbvDSUSW--) {
            CFxDOieRDjKZQGUH += CFxDOieRDjKZQGUH;
            CFxDOieRDjKZQGUH = CFxDOieRDjKZQGUH;
        }
    }

    return 2049400285;
}

bool vOlulCVMTOhfojCW::HqlCl()
{
    double eYfhBA = -824470.0322102978;
    double yadcWph = 919812.723427836;
    int CPEiAwRMkk = 1964949840;
    bool mLeJwlMdTV = true;
    double RxuPBubESXq = -520416.4278970306;
    string caRblzVlTvOeSR = string("pSkHZPyUkeNGzBmVGxAWOAsNDnsMODCyjudjHFPbudRhQdUpXyupMURBePHIUYxgHZkLuYkxjoqwUMZsUzqniUyErnKUJSWPTNeMBxtMKfRrllvIGSRjWvYGhHsvmIRQfUxoLpUoSWgcxRkJEFNYYzbuFBwqTQCCp");
    int KFfbcQ = -529129159;
    string vSaGQ = string("CrnzmZV");
    bool JLrKDr = false;
    bool fmFMQQLGS = false;

    for (int OHninCLrsCC = 1178632865; OHninCLrsCC > 0; OHninCLrsCC--) {
        eYfhBA /= RxuPBubESXq;
        eYfhBA += RxuPBubESXq;
    }

    for (int BaNqHEmPVxN = 281606315; BaNqHEmPVxN > 0; BaNqHEmPVxN--) {
        mLeJwlMdTV = ! mLeJwlMdTV;
        KFfbcQ /= CPEiAwRMkk;
        JLrKDr = mLeJwlMdTV;
    }

    for (int NyjwXv = 785289873; NyjwXv > 0; NyjwXv--) {
        caRblzVlTvOeSR = caRblzVlTvOeSR;
        caRblzVlTvOeSR = caRblzVlTvOeSR;
    }

    for (int nzKrjZ = 945284892; nzKrjZ > 0; nzKrjZ--) {
        vSaGQ += vSaGQ;
    }

    return fmFMQQLGS;
}

double vOlulCVMTOhfojCW::DfdGuiOTDwNbgmS(double EfNKCfgAKV, string vOODXeWF, int jooJaz)
{
    bool ZlFgxbWv = true;
    int eeflrmAqTkX = 338030435;
    bool FNSIzo = false;
    string ClfoyBduuz = string("quVaPJGAcahjOkkBEshNdfdrddkWnSMDmdRQoCbHrsBdZalinrQvvXg");
    int eavwgmnoU = 251907644;
    bool jaKsqFIMWazQEYbf = true;
    double PDmrWHrDtFJx = -172425.34966117592;
    int MWnfUB = -1689464014;
    bool FTAqXwfHRg = false;

    if (PDmrWHrDtFJx >= 395194.13692656806) {
        for (int quTjePylGzarIoi = 110177118; quTjePylGzarIoi > 0; quTjePylGzarIoi--) {
            eavwgmnoU *= MWnfUB;
        }
    }

    for (int vFCHPpCnceQu = 1213899804; vFCHPpCnceQu > 0; vFCHPpCnceQu--) {
        ClfoyBduuz = ClfoyBduuz;
    }

    for (int GzkniRPbXDlXEOP = 658143825; GzkniRPbXDlXEOP > 0; GzkniRPbXDlXEOP--) {
        FNSIzo = ! FNSIzo;
        EfNKCfgAKV += PDmrWHrDtFJx;
        ClfoyBduuz = vOODXeWF;
    }

    if (ClfoyBduuz != string("quVaPJGAcahjOkkBEshNdfdrddkWnSMDmdRQoCbHrsBdZalinrQvvXg")) {
        for (int CXsdHVQPmQXFFhfF = 505605739; CXsdHVQPmQXFFhfF > 0; CXsdHVQPmQXFFhfF--) {
            continue;
        }
    }

    for (int pZQRdZCPqYsxIZJD = 929461797; pZQRdZCPqYsxIZJD > 0; pZQRdZCPqYsxIZJD--) {
        continue;
    }

    for (int xWpaSlUXctNBV = 1057089915; xWpaSlUXctNBV > 0; xWpaSlUXctNBV--) {
        jooJaz += MWnfUB;
    }

    for (int rarYByVNtZXgR = 1674670510; rarYByVNtZXgR > 0; rarYByVNtZXgR--) {
        continue;
    }

    for (int gYmIjDgd = 624203934; gYmIjDgd > 0; gYmIjDgd--) {
        MWnfUB -= MWnfUB;
        jaKsqFIMWazQEYbf = ! FNSIzo;
        FTAqXwfHRg = FTAqXwfHRg;
        eeflrmAqTkX *= jooJaz;
        eeflrmAqTkX /= eavwgmnoU;
    }

    return PDmrWHrDtFJx;
}

string vOlulCVMTOhfojCW::zCauTAEDc(bool ztYwVsNP, double emWbHLgtFjUTdH, int ViSWBkx)
{
    double VIWShmoWGOYu = 64839.702880950426;
    string NdQjBGb = string("QMFEgdWNWsYeXUNmbyXQWJIQvtIPMTalpDPBen");
    bool AazQVuAvOAVixFt = false;
    int HQfnQosTiE = 944167467;
    string joqblrfS = string("XwKtahEqraslimXgfSPfrWMjBSIopssdLoIOcrjigqQMAGtcETcmQPfjDsJGjQwjMjOAWOVAREPrmuNSoKfJEPOyhLzHJCGRenamqtpQGCpGMfDeMueMzhRRZhcWEUPMCKVEeKQinvDDjvXkKgoWXcEkiVVHtAIXAsIJUAWJooefRuXHPFCZJQUxzmdLyTGiwLsPNNNirAzxFekPFPBpdFFlsGNNSZlZTOeMbCu");
    int cNwlWDggxFCg = 1454307490;
    string EJuRhJKSJGt = string("bDueCVkHNhFJJvyAXrCQErlpEqIVaFwZLZbPWWFVUSVrcBqtPaIUeethyYUzhuirTpONWxgqsGohrWJhlJIRKItckMWLeQWmxquzRuifLchLTxqSRHUFbhEYMjNeaBMsipSCFZAcTTldKpg");
    double tCrQbafNmJ = -505372.84935103887;
    string BfwKRUU = string("DfqjslkHGiKnsLPJCDqHvEQDvzFshNGBmKbuTOYaQqDuEVzgyluITJeDQiZZZSEGvGjAdzDOZZisrdAsQwIEARSiuBsBKBtvywCV");
    double bWYkCeQBvagkxDR = -610480.4217193031;

    for (int OTxUOQyagIEgpV = 800355986; OTxUOQyagIEgpV > 0; OTxUOQyagIEgpV--) {
        NdQjBGb += EJuRhJKSJGt;
        NdQjBGb += NdQjBGb;
        bWYkCeQBvagkxDR *= VIWShmoWGOYu;
        emWbHLgtFjUTdH *= VIWShmoWGOYu;
    }

    return BfwKRUU;
}

int vOlulCVMTOhfojCW::MvSPJw(int BVpitw)
{
    double UEonACJeqEAfi = 850620.9990889401;
    int bUzUQINIPUshTEAk = 1253491401;
    string OqZVXmUNHYQF = string("pvQchbWVIltSVcrMRnTuPiiMMnXplESVBavHLugAShKqDPLpQttkZkUgKbPcpJosUdYZEAbdVJXglamJGKs");
    string VRnTJvhejAv = string("hBdDpZSRUvYiXnvnnYEzxElBgWHGTABaeGqCslbfCHugLRSQbTNeWiyoEHLGXCLwHpzbYvxaHirLNOQUhPp");
    int jUPmcrFHgRZpmF = 136136045;
    string XqYZrPL = string("uxBNeweTpRlMnXfoXim");
    int yDnrBRyN = -808184548;
    string pxsAygYUWC = string("feTJDCvqPLkFFZfPwWtUPWNBWbBPqKtd");

    for (int fkhTYxCTlls = 332571401; fkhTYxCTlls > 0; fkhTYxCTlls--) {
        continue;
    }

    return yDnrBRyN;
}

void vOlulCVMTOhfojCW::ihbjZFh()
{
    double qyVpWw = 566558.9110399316;
    double ujBTvLePUdh = -791636.8864705663;

    if (ujBTvLePUdh != 566558.9110399316) {
        for (int TTihxfSkkiKI = 1108061677; TTihxfSkkiKI > 0; TTihxfSkkiKI--) {
            ujBTvLePUdh = ujBTvLePUdh;
            qyVpWw /= qyVpWw;
            ujBTvLePUdh += qyVpWw;
            qyVpWw = qyVpWw;
        }
    }

    if (qyVpWw == 566558.9110399316) {
        for (int hyrTwlbAJozR = 312691439; hyrTwlbAJozR > 0; hyrTwlbAJozR--) {
            ujBTvLePUdh /= ujBTvLePUdh;
        }
    }

    if (ujBTvLePUdh > -791636.8864705663) {
        for (int zxTsGYCSteKfIaj = 639485431; zxTsGYCSteKfIaj > 0; zxTsGYCSteKfIaj--) {
            ujBTvLePUdh += qyVpWw;
            qyVpWw *= qyVpWw;
        }
    }
}

string vOlulCVMTOhfojCW::yBylh(int tclDcNTRjLRwc, bool bBLMmUlArVXelOai, int nhhskygAthaxFlUs, bool qAFdMlXgcl)
{
    bool tRXIpgqozvL = true;
    double EKUBYCmJoX = 852085.7496773585;

    for (int pBhhVg = 955841509; pBhhVg > 0; pBhhVg--) {
        nhhskygAthaxFlUs = tclDcNTRjLRwc;
    }

    for (int QebjXhdebuY = 260536645; QebjXhdebuY > 0; QebjXhdebuY--) {
        bBLMmUlArVXelOai = bBLMmUlArVXelOai;
        bBLMmUlArVXelOai = ! qAFdMlXgcl;
    }

    return string("fuAKYSqoVgJjqAKYqMYzscDDTUmmnsbHwcEghXzjIKAxbSwYiftGtbMAHckGjtVwr");
}

void vOlulCVMTOhfojCW::oxNbaaAfySfAAyPU(double gcreaWysPfyg, string TopYlUHS)
{
    string vIQulUza = string("iOTMAyzzpsUgQlaOZnjCHkfPscIfNrylxskKNZGcBmlZLAhnUwcmwNYqKcRQCo");
    bool uuySxr = false;

    if (uuySxr != false) {
        for (int PzJiuQAgGVn = 1013448134; PzJiuQAgGVn > 0; PzJiuQAgGVn--) {
            uuySxr = uuySxr;
        }
    }

    if (gcreaWysPfyg > -813186.6247014878) {
        for (int uPMeZskWdoKrfczd = 780283925; uPMeZskWdoKrfczd > 0; uPMeZskWdoKrfczd--) {
            TopYlUHS = vIQulUza;
        }
    }

    if (gcreaWysPfyg != -813186.6247014878) {
        for (int uuaFwGPLkVRGfLc = 601185859; uuaFwGPLkVRGfLc > 0; uuaFwGPLkVRGfLc--) {
            vIQulUza = vIQulUza;
            gcreaWysPfyg *= gcreaWysPfyg;
        }
    }

    for (int zOFhUdd = 2144834842; zOFhUdd > 0; zOFhUdd--) {
        uuySxr = uuySxr;
        vIQulUza = vIQulUza;
        TopYlUHS = TopYlUHS;
        vIQulUza = TopYlUHS;
    }
}

void vOlulCVMTOhfojCW::ucGSremk(bool NKCYrC, int CBPelgc)
{
    int qDPGo = 222073227;
    bool HhpESlfrNyaUB = false;
    bool GqpKcbLaaWdmSmg = false;
    bool Hczlx = false;
    int kkVrCHmfjG = -1203786241;
    bool PQtcSsuFJjxr = true;
    double boHifrTPbg = 1022044.3279332443;
    double JUVMlABwPyx = -436508.770232389;
    bool pifimCHqcW = true;

    if (Hczlx == true) {
        for (int xTVXfIHSvCt = 1487390023; xTVXfIHSvCt > 0; xTVXfIHSvCt--) {
            Hczlx = NKCYrC;
            PQtcSsuFJjxr = PQtcSsuFJjxr;
            Hczlx = GqpKcbLaaWdmSmg;
            GqpKcbLaaWdmSmg = ! HhpESlfrNyaUB;
            kkVrCHmfjG /= qDPGo;
        }
    }
}

string vOlulCVMTOhfojCW::sinVv(int vyhaFHst, int uVnSuWs, bool xbhXKFo)
{
    string hSbiJVQXGNDvMM = string("MRJCfdUEdQZVmoUHbGDEgKOvDfilWwPFkqcbFYqHgbDuzetUmuMqCdjrEtitDpyHOkRIZqrKfvVHDbADFzUVuBWcQWUqtHDvusoTEwOyEQDSCaQCVBkEYKXTkiukyDrcqRdKGrphTZIvWQWcqvYNTRNiOTsyYZMGINuhCUyyGeeLuJXyPCZVxxNghUqkadQMFwNxqHoVTAJoLSdoQPHPRmerRdsxVnJYpgmjDjwYe");
    bool DjHkmpSYtru = false;

    for (int qnpIdIpVE = 379028173; qnpIdIpVE > 0; qnpIdIpVE--) {
        hSbiJVQXGNDvMM += hSbiJVQXGNDvMM;
    }

    if (xbhXKFo == true) {
        for (int NYYiGnhulANyevEG = 1103010895; NYYiGnhulANyevEG > 0; NYYiGnhulANyevEG--) {
            DjHkmpSYtru = ! xbhXKFo;
        }
    }

    return hSbiJVQXGNDvMM;
}

int vOlulCVMTOhfojCW::ruxcsitAt(double OlnKGyvyb, double TCgFkQPCpKKVtjNC, string VrlVTARZAeZWX, int GddvIVsbfRaC)
{
    string PWOFcjXHFFYYVH = string("wTNlKQqouuIIuSGyZqJHVpAFxsrareFPuattaTQphbZgBffXpqXaBbxXgwkwFyGuTkKfkroAAOiJISDoNlAcrWCVEuGBherjuwRxTMqjkPiRPFDBMbCEYOxZLTlhPMTvUFcSxBsjRrjIOrELhKKWfocUlZWxDEylrHcNQwtYmEbvXkzcijmfDArTTncmZDsFZEBCFPCJqrcjYaAMQahhoprylZRUpRgonuuLpEJPhVEWfBsUzIwxoTAcPdUiTZ");
    double qIZmflk = 685769.1856786641;
    bool XTFSjq = true;
    bool TJZgCHQkTXI = true;
    int kvtnIcDpUui = -162764664;
    bool enFbpJbYmszMBc = true;
    bool rgKCTiVAuJqWvWB = false;

    if (XTFSjq != true) {
        for (int bHkfeoOoCvAzt = 370566953; bHkfeoOoCvAzt > 0; bHkfeoOoCvAzt--) {
            TCgFkQPCpKKVtjNC -= qIZmflk;
        }
    }

    return kvtnIcDpUui;
}

int vOlulCVMTOhfojCW::AzHvtKeZRTlbnx(int njvPhzYFuJ)
{
    int HEPjOCNn = 1552416140;
    int wlmONXGQUkMU = -2135829057;
    string RbfDeAM = string("nkqbGjcVieQElMptGMSELysPBZaiwgYCVvNzrpWmVaSYQmrlWYmYsrMZbHBIMZCWmiviEXMAWUdresKkQaxGScEMklREmPbfMzZUCryZUxNvgSkVLsJMpjOKUqwPiZjQhfqlPSLndZJzMPPQvxQyXlfASUSLdVUdcLNUyslplFuptxTiShxTWRtSrtzmZGUgbJyxgbsQglJzVFvehlkkhPxlnXGRkDeSwRrRHBQNmCOd");
    string hYElh = string("lqPMcdQXIMsPjgLuPHYSlPjgaBsmgHofABzcHrfaxdIaxxAbIybeArhbuKpHWQSGEpLtGOvpFJHFSrzzsYbacszLHCWwKanGxTyECrzLESCZZGGYepPOMFmRrOwMeVePzujEuwIYgWLXHgzfVgMDCoBiZbcQLoRmTLep");
    string PNiNBGb = string("edsUMnykGIYgGbxwwfIHROGgaocYsLsWsDvTRmZztPPppMuelqrlzMQmmBOpVtJhQktQrzDqtfIwoOvhIiFBCdLfRhRiyWaMLHOdXsTwRwaYtAODefQJeGIMBobqsnwACVsCLWadratgwWlqoLnUrnkVlenSFzJAuuSdFOKTHftvh");
    string zhtnbetgQf = string("pVUsDYHhehKuIfkbbHhcgdVsujiglDyYZYwtOiPpBOEzRTJxALOBwaazizKtRtbHzUUsrBpEiGnXeROgpPGOFbTudwHPPWdguPNUjiaEpQNVpGABOtkYGCupafbwZQJJoAmmedsZoIagvRTNCzAdnJ");

    for (int YPGgkOja = 1906546213; YPGgkOja > 0; YPGgkOja--) {
        PNiNBGb += PNiNBGb;
        zhtnbetgQf = zhtnbetgQf;
        RbfDeAM = RbfDeAM;
    }

    return wlmONXGQUkMU;
}

void vOlulCVMTOhfojCW::BHJytUuOLHBWN(int ONKBLnlVCVyfBHaa, double VTHXI)
{
    string PPSfCiTkZa = string("jTQAyRXaExDBmEyRznoacBsmOgycDDrzjshMUkMcGkqjWOkACAOGOiDzoZWNxTejpslFDvYzyHDKpyZwRHXBRhgFqNkCzYztmkMIqykQNavjzsmkJNRXAvuStUnjcpJlkNNK");
    bool lJvTEiakgjEN = false;
    int QCCSra = 87602183;
    double mHtlzkVGkYebQ = 591009.5756008052;

    for (int qzqXEfXbMY = 1275221263; qzqXEfXbMY > 0; qzqXEfXbMY--) {
        ONKBLnlVCVyfBHaa = QCCSra;
        QCCSra *= QCCSra;
        QCCSra -= ONKBLnlVCVyfBHaa;
        mHtlzkVGkYebQ = mHtlzkVGkYebQ;
        QCCSra /= QCCSra;
    }

    for (int hjqvpuWotqGt = 651479185; hjqvpuWotqGt > 0; hjqvpuWotqGt--) {
        ONKBLnlVCVyfBHaa = ONKBLnlVCVyfBHaa;
        VTHXI -= VTHXI;
        mHtlzkVGkYebQ = VTHXI;
        ONKBLnlVCVyfBHaa = ONKBLnlVCVyfBHaa;
    }

    for (int jojsZOKwEVPxJUq = 6839064; jojsZOKwEVPxJUq > 0; jojsZOKwEVPxJUq--) {
        ONKBLnlVCVyfBHaa /= QCCSra;
    }

    for (int fAjMmFUumeyM = 422750871; fAjMmFUumeyM > 0; fAjMmFUumeyM--) {
        PPSfCiTkZa = PPSfCiTkZa;
    }
}

bool vOlulCVMTOhfojCW::AGTGL(int lBxgwyhGqbgp, double GqZeTMIIPPlFTGe)
{
    bool TnUtdENSLDop = false;
    double OYadqgICSsGmbtkd = 708803.6656450827;
    int nevRbxBfpPJhOXN = -2038907240;
    int ryPBfzpGtlOaXNSW = -1030198887;
    string fJFmEUd = string("mdYUTSNMIhCafgPifAZDbpIhngSGGBLpFJsyZREWNNnTTamgGpVxwUZZnPVOADidMFulxHkmomVWupIExUrSRCmdRmvgfAZpLqPsqCMgONmQodmuvxfbVyYmbH");
    bool LImDbKNEoKN = false;
    bool EQaLlfe = true;
    int wKsPRNBbA = 51208041;

    if (lBxgwyhGqbgp > -2038907240) {
        for (int SexIA = 1135816039; SexIA > 0; SexIA--) {
            OYadqgICSsGmbtkd -= GqZeTMIIPPlFTGe;
            EQaLlfe = ! LImDbKNEoKN;
        }
    }

    return EQaLlfe;
}

void vOlulCVMTOhfojCW::QhvdhwoEgn(bool InAHqF, string xqjQvjZlLPn, double SUNwIYDzoufpLCZc, int PWAEBPMdjLhtq)
{
    bool XZFAnhZowBcD = false;
}

vOlulCVMTOhfojCW::vOlulCVMTOhfojCW()
{
    this->zHsErNuCd();
    this->VBIwIqaxwYrUnzL(895228.5850501767, string("IWqfbDtWyeXHFKCwDEVkUODzXRYZfRKaXIyFtMspQjDzFRzxVczqiPdaaeSSIWgGjtOMNkZTZOHWzpmBfsdrCGnMhCsDZVsViBuXiItZHpjgUxnpQmmErwyTwLtYicuvnyxACdtdmLAgyEQRSMawyafBGkreOtHTCCEAfwhZJUnwlRSqwhjNWxjbmclHNAjOpkmmhohtaTXvH"), false, string("CqXgeUtHrOrEdUgBZuCoWfEpdjlloWiVaehHOihjEWwngFYUBiyFDsDyYnKxTByVSKAFTpgttHLmQMQxizXGshPKWX"));
    this->yGkZxXt(-987091.3097035663, -929508.0889091572, 848499546, -1415618263, -381280.044650694);
    this->RvkqoeYV();
    this->HqlCl();
    this->DfdGuiOTDwNbgmS(395194.13692656806, string("CaYjZVHwamrNmXXPajmwmvMSYrNZoLTmqcPhdeIbQEeQMxlkAOVJwOuGlTzxTPUrBAJplPHTUzTDJkAa"), -191170666);
    this->zCauTAEDc(false, 968543.3354570456, -16784163);
    this->MvSPJw(676427558);
    this->ihbjZFh();
    this->yBylh(-2028705784, true, 1837784562, false);
    this->oxNbaaAfySfAAyPU(-813186.6247014878, string("aUzBhHclXozJLIMruXzvnokWiTaNbucbEyUbEeStWwhMkUiewRLzABeGCkeXVOnrsQjXynHbbohPlyvJuDuLzbRptSEJSRDDWpnWwxGuSHxXPDRpIjYcCbCXPUTDZLHeRbgRnRkaRnzkjOfFNCBgRPzSAeDyubtKZJComMETLeoJoCzNdLVHZwLIjkrgloFyukrHghJtWiQpzPyuqahekOtWWTdLEFlOppSaGDYFIjqOYreixOWNt"));
    this->ucGSremk(true, 1869755857);
    this->sinVv(958804277, 590091028, true);
    this->ruxcsitAt(-343344.6679581445, 605293.8509347083, string("SZUZrpFqsGueaXuXNpyTqXSYKrLZsFtRfmKUINGFCIyXxwxiPIBpUMgpHZFhmOzNApdvXLVmNjNZtMCpWHKENEpSx"), 359232172);
    this->AzHvtKeZRTlbnx(-1555355562);
    this->BHJytUuOLHBWN(389820562, -915056.5073586153);
    this->AGTGL(464608994, -71357.1167506741);
    this->QhvdhwoEgn(false, string("CFnoWEoDscIPwmAFrtcWySnfMxwAILvnzhmMPuYDEildVrVGawCvqEXcjojSLGQXDhvsPwIcHUllqvCEBteaVqvfrdAZgAPRHzMHHbtGLnEZrlpdpYURwjrAuujLLNedoVTMiJioZyPzOPEWupPSafsMdBjrAixCqBOuKKRNaacZaccOFBjnYfRciNvCdqvNMymKGiscZjPVkBvFrloomykW"), -85631.25558328228, -352986241);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class grQufTLB
{
public:
    double dZimgSdgnVRhSC;
    int efsUMqyBvvyl;

    grQufTLB();
protected:
    bool nofje;

    double zoiStBeQaAjlWrjN(int BmBjTwKgdQBM, int xjXPxsBYlMkQnhp, string stecvyES);
    string LYowfKUbT(string RqclMMMXRSWBO, bool xWRDEmy, double cBmVNhrQ, double aiWPNNycdWgY, int mAYBe);
    void bITzxX(double yZeIqguvcVlFiNWJ, double WbhhgVBjFbXz, bool uCxkBr);
    double qNQGLYgQnMMMo(bool zbmsMLbQN, string pAZHoMdeNAULg, bool ABVhH, int OfCfoSLrkq);
    int hZlTDQPNbHBaEsH();
private:
    double eVBgsR;
    string XJauSWGnNYdNHggB;
    double WHwIvQqHuUxZ;
    int qoDcIzqmlCpsk;

    double zaathFO(string iNsQpzgHqx, bool gbZEwfeOo, int tdUoybfnQ, string EJKKjTtivala);
    string mNAtPIJwQBWedu(string rhprTOYov, string kqVneYNlID, string voyUMLzzjF);
    double hiTBERzwEiLmAIx();
};

double grQufTLB::zoiStBeQaAjlWrjN(int BmBjTwKgdQBM, int xjXPxsBYlMkQnhp, string stecvyES)
{
    int gcYVwvSs = 1042444412;
    string VVfNEjVeC = string("lzSCNFVUIvHtXNUzaopGTuqpeBKQsUiREjcVWmoUhTAZfyVBbLDfWHFOAkWnVcCAJYYGlKtJCOAhdocgqBCdfIGbreuxkXkNAUAUYNJTzNtKFijChhqDPLsYhZiIZPxMtrMzHRiJIzQjFvWhkAfzjBMEDfvlZzoxLvMpkDSdQTQGCcdoCYlUzACwqRLrzhRzKEPygjcfpHqpbvwxUquJqiUUiSHaBrIIPSVZLStxACGAbtFkLyiBqfChJwghpo");
    double mWTvMuQ = 307044.53156014776;
    bool KycnPMNoCAfKUYt = true;
    int ZSWWBHDrKowSnW = 1265454340;
    int ahkHe = -229101457;
    double OBMzvdefGUcTDqF = 438607.6100685152;
    bool LRIPdIqFd = true;

    for (int PpwbpmpuKoMqUUD = 864900811; PpwbpmpuKoMqUUD > 0; PpwbpmpuKoMqUUD--) {
        continue;
    }

    for (int HtkzRfljR = 1826053016; HtkzRfljR > 0; HtkzRfljR--) {
        ZSWWBHDrKowSnW -= ahkHe;
    }

    if (xjXPxsBYlMkQnhp >= 1042444412) {
        for (int SywtLlxnZ = 585687827; SywtLlxnZ > 0; SywtLlxnZ--) {
            continue;
        }
    }

    for (int RHMZZHVHYfFO = 666529325; RHMZZHVHYfFO > 0; RHMZZHVHYfFO--) {
        BmBjTwKgdQBM = ZSWWBHDrKowSnW;
        VVfNEjVeC = stecvyES;
        gcYVwvSs = gcYVwvSs;
        stecvyES = VVfNEjVeC;
    }

    return OBMzvdefGUcTDqF;
}

string grQufTLB::LYowfKUbT(string RqclMMMXRSWBO, bool xWRDEmy, double cBmVNhrQ, double aiWPNNycdWgY, int mAYBe)
{
    int Dvfnm = -339824737;
    bool gQuZvZu = true;
    int qDbRnJap = -177209374;
    double QkHxGbSU = 647822.5761464384;
    bool GeKceioVcwgqS = false;
    bool xJLVNbMXUqTBPtAG = false;
    bool UVzaVUlhQ = false;
    string hZfgvWwcnRc = string("zICUfeJtyDFBdgRmIZfUIpFgrjeNWlQcRURPmHgqanVBOAJlVOZUqxZKtoIxGhoWSjIdPnPhTbkdSDGVsTBYUQVxeIxoABpGuwSeKrcdwOOBvSwFNOxdSDYRyTBFeTtkdrKEtohehFagCXIyhTiVFgqaUQVvzqBypNcXEPYZLtXihmhYBNkHVrHNvFtFAEoBczQokrcquahNrxGxyUAYfPOJOI");
    string vEMIuscc = string("JLgpjPgiEZUMGYvMZqPNxmYpBxcKWUigEmbnHnqVTQJKMcpBmljIgrQoCsoktdrOgKxXjmOkQjoLbNrpGDrIpzuFVgRezoTkGytkQroJqOOTLtwnESKMjrvAwzAycGlYGsCAEVTwMtUYFMrfWlVksAUybLmkWmxjqVvLchPSDCBADWnXvUxwnKGoOveQumErGeeCzTDmrQFUpbyiYeWewSTiJKRvrRFvPsVHSHERPJRttJorGHzeLS");
    bool pXxlPWrBid = true;

    for (int JXRfBvqsJLbtZ = 735868955; JXRfBvqsJLbtZ > 0; JXRfBvqsJLbtZ--) {
        continue;
    }

    for (int XsekrHMxx = 1418204562; XsekrHMxx > 0; XsekrHMxx--) {
        xWRDEmy = GeKceioVcwgqS;
    }

    return vEMIuscc;
}

void grQufTLB::bITzxX(double yZeIqguvcVlFiNWJ, double WbhhgVBjFbXz, bool uCxkBr)
{
    double cOKiCFLcZh = 898279.5713608738;

    if (uCxkBr == false) {
        for (int hXQOGSLoThy = 885472860; hXQOGSLoThy > 0; hXQOGSLoThy--) {
            uCxkBr = ! uCxkBr;
            WbhhgVBjFbXz -= cOKiCFLcZh;
        }
    }

    for (int OVaffOMOu = 1059816257; OVaffOMOu > 0; OVaffOMOu--) {
        WbhhgVBjFbXz += WbhhgVBjFbXz;
        WbhhgVBjFbXz += yZeIqguvcVlFiNWJ;
        WbhhgVBjFbXz *= WbhhgVBjFbXz;
        yZeIqguvcVlFiNWJ *= WbhhgVBjFbXz;
        cOKiCFLcZh += WbhhgVBjFbXz;
    }

    for (int jauDk = 656378194; jauDk > 0; jauDk--) {
        uCxkBr = ! uCxkBr;
        yZeIqguvcVlFiNWJ = cOKiCFLcZh;
        yZeIqguvcVlFiNWJ += yZeIqguvcVlFiNWJ;
        WbhhgVBjFbXz /= cOKiCFLcZh;
        yZeIqguvcVlFiNWJ = cOKiCFLcZh;
    }
}

double grQufTLB::qNQGLYgQnMMMo(bool zbmsMLbQN, string pAZHoMdeNAULg, bool ABVhH, int OfCfoSLrkq)
{
    string ripgEkM = string("Ak");
    int iNKpwVuDZeCROE = 122329971;
    double mdFHflFeggIHsES = -747879.506497145;
    double bEKNwC = -870222.0470535608;
    int vgcHpjAQRQoHfems = -967276306;
    string KMuXTafaNFtF = string("clfEoRNdJvmfmRGsTyWbNdnWjRGsMBCxHZurjfqErCTfsBbzTldlNSrAHSpJdiIjwh");

    for (int sZOKijfOsXKX = 375523586; sZOKijfOsXKX > 0; sZOKijfOsXKX--) {
        ABVhH = ! zbmsMLbQN;
        ABVhH = zbmsMLbQN;
        iNKpwVuDZeCROE -= OfCfoSLrkq;
    }

    for (int mDkuGCjB = 1613747704; mDkuGCjB > 0; mDkuGCjB--) {
        KMuXTafaNFtF += KMuXTafaNFtF;
        KMuXTafaNFtF = ripgEkM;
        vgcHpjAQRQoHfems = OfCfoSLrkq;
    }

    return bEKNwC;
}

int grQufTLB::hZlTDQPNbHBaEsH()
{
    string pyAHXHCTS = string("ZbPFxzBcGkYjanTqeUAiMVaHKSSTCOlncVnpbxJRjgKbrMNaiOwFdxZmNYqdGoMWIqrHPFTjYONeUeOdJExlSJcVLzeEzeJmhlwjhGhcSbbCIBXLMXdkptIcjGIDbPuYoLrfHEhqmnMfKkuQIwwSclLzGdbibTuqvaMkFlMZpgwcUSWGHUuFetABUoPQCaBnbboINDn");
    int FcFTVlZn = -1607909694;
    string njmnhSqZqucip = string("tYHfXpYzniCkYsJcOWWVzgBlrhARHjdvZqz");
    bool nIwmmQRIdQo = true;
    string HnEdbcn = string("fzBcjxnJDyMsVoi");
    string YMUcETZdOrHZZsKP = string("StLBNBDDJivJkmgdAKHhsCMzOqkaCfzsYlmCsTzTgkVZawGlBeQzCUUIfcXLKvQQIteu");
    double bPwWbPOQFsrNCfe = -143198.0054776011;

    if (njmnhSqZqucip > string("StLBNBDDJivJkmgdAKHhsCMzOqkaCfzsYlmCsTzTgkVZawGlBeQzCUUIfcXLKvQQIteu")) {
        for (int PGqsHTElATF = 1047730811; PGqsHTElATF > 0; PGqsHTElATF--) {
            continue;
        }
    }

    for (int zooEjmyrRthTdbi = 493963566; zooEjmyrRthTdbi > 0; zooEjmyrRthTdbi--) {
        njmnhSqZqucip += HnEdbcn;
    }

    return FcFTVlZn;
}

double grQufTLB::zaathFO(string iNsQpzgHqx, bool gbZEwfeOo, int tdUoybfnQ, string EJKKjTtivala)
{
    bool CcveLpwfTcBUq = true;
    double CWYafGQMqHJtCq = 976587.5895559294;
    double xWmEfsREcOHMbz = 347747.15996268805;
    string nYFulmxaGmJhXtGD = string("eLorlKHsRTQrWBesYwvILvcKigjhtZhOQPhVndGfMpbzkJtdCRInsvCECFCMOGcmD");
    bool zXjGbT = false;
    double myvwgCtGwDQBCR = 947095.6346650013;

    for (int kdInv = 645581413; kdInv > 0; kdInv--) {
        continue;
    }

    for (int eUvDIeHEQCZv = 57257529; eUvDIeHEQCZv > 0; eUvDIeHEQCZv--) {
        nYFulmxaGmJhXtGD = iNsQpzgHqx;
        xWmEfsREcOHMbz -= myvwgCtGwDQBCR;
        iNsQpzgHqx += iNsQpzgHqx;
    }

    for (int LMXMkWpyMUq = 531986124; LMXMkWpyMUq > 0; LMXMkWpyMUq--) {
        EJKKjTtivala = EJKKjTtivala;
        gbZEwfeOo = ! gbZEwfeOo;
    }

    if (CWYafGQMqHJtCq < 947095.6346650013) {
        for (int PZKFRuRySTWe = 2056947647; PZKFRuRySTWe > 0; PZKFRuRySTWe--) {
            tdUoybfnQ -= tdUoybfnQ;
            myvwgCtGwDQBCR /= CWYafGQMqHJtCq;
        }
    }

    for (int ClzymQFIaJIazXbJ = 67545125; ClzymQFIaJIazXbJ > 0; ClzymQFIaJIazXbJ--) {
        continue;
    }

    for (int nsdwWGUlMAg = 1978219429; nsdwWGUlMAg > 0; nsdwWGUlMAg--) {
        nYFulmxaGmJhXtGD += nYFulmxaGmJhXtGD;
        CcveLpwfTcBUq = gbZEwfeOo;
    }

    return myvwgCtGwDQBCR;
}

string grQufTLB::mNAtPIJwQBWedu(string rhprTOYov, string kqVneYNlID, string voyUMLzzjF)
{
    double FNlzOhqyRjZHEeBY = 538686.1466520354;

    for (int QZLaOgg = 1965387811; QZLaOgg > 0; QZLaOgg--) {
        continue;
    }

    for (int OqcWdTmQIk = 305464643; OqcWdTmQIk > 0; OqcWdTmQIk--) {
        rhprTOYov += voyUMLzzjF;
        kqVneYNlID += rhprTOYov;
        FNlzOhqyRjZHEeBY = FNlzOhqyRjZHEeBY;
        voyUMLzzjF = rhprTOYov;
    }

    if (voyUMLzzjF == string("zQpKsVGftSyvC")) {
        for (int bnvpBTD = 733834654; bnvpBTD > 0; bnvpBTD--) {
            voyUMLzzjF += kqVneYNlID;
        }
    }

    for (int wPvFmnSgA = 1421578771; wPvFmnSgA > 0; wPvFmnSgA--) {
        voyUMLzzjF += kqVneYNlID;
        voyUMLzzjF += voyUMLzzjF;
        rhprTOYov = voyUMLzzjF;
        rhprTOYov = kqVneYNlID;
        rhprTOYov = kqVneYNlID;
        kqVneYNlID += voyUMLzzjF;
        voyUMLzzjF += rhprTOYov;
    }

    return voyUMLzzjF;
}

double grQufTLB::hiTBERzwEiLmAIx()
{
    bool IrkqSzopFUyFJ = false;
    string UZKXZACFrjpCU = string("vBpqwTNjNwoCTHNkQbhhUcdnNMblToAYDjNMMJEcMEpuSPEHccWxegJWYPqlqEyDInzKFRYXAFwKfIyaATciyFKwPRwSjNtgMLSmjXxrwPyYhVCGyAqsoYimMnNfNlOENOskxmwZvsBeDcrbeMFoBLQftWCKTXSHGqlpHNjMJyZnIRRzwMpDgsEYFnngHrsFbnmuHVNNgeDyPDelI");
    bool tTbRXLzlIso = false;
    bool yCjRkvgM = true;
    string bxzAxjzPcDy = string("WMTbLULjxDkgJZtGnkUqmldiDSytuYLylKMZjXoONrQVeVUuPqYqYHOVfwOsrLRTHGrwUgdbADGVXkOHeLKdAhwGxzE");
    string NxYNKtccu = string("eZcBuQJMTYaznvSFdgJPRZenaJvGcPQARbLNNCVVbbgRVOyzoQhKjQmITnurcCNenvAVdOhEmHZASjQggbXVzJR");

    if (tTbRXLzlIso != false) {
        for (int iFpQzPqQT = 926407777; iFpQzPqQT > 0; iFpQzPqQT--) {
            NxYNKtccu = UZKXZACFrjpCU;
            NxYNKtccu = UZKXZACFrjpCU;
            NxYNKtccu = UZKXZACFrjpCU;
            UZKXZACFrjpCU += UZKXZACFrjpCU;
            tTbRXLzlIso = IrkqSzopFUyFJ;
        }
    }

    for (int IQUOChazm = 541615536; IQUOChazm > 0; IQUOChazm--) {
        yCjRkvgM = yCjRkvgM;
        bxzAxjzPcDy = NxYNKtccu;
        IrkqSzopFUyFJ = tTbRXLzlIso;
        yCjRkvgM = ! tTbRXLzlIso;
    }

    return -499637.7723025502;
}

grQufTLB::grQufTLB()
{
    this->zoiStBeQaAjlWrjN(-787985095, 1818706229, string("cC"));
    this->LYowfKUbT(string("scnNreoHOdTSxQjnrOimhVsvwFVTtqiDpFbzRfBrvpxTstxlVRQJPQvoeDloyscijkDNvGMKqadGAxlLahmzGefecjIZqreEwsCacCvcOtsILlBVIdldJzvSwEdRPFISScnwVjdPHtenWAzo"), false, -647212.3933651696, 919900.7642839458, -342158318);
    this->bITzxX(-855921.4790901538, 451547.5928893837, false);
    this->qNQGLYgQnMMMo(true, string("GwqQhWWzzexveYTkTPURnuGtNloShxKiJuBQXPcnpZYrehmzfwRUnlYbrIGHxTabzDBsjAWKkIUrwzgVdDIlpzoprsHKQlXmPFPPFdnLGnEcLRGWdGmrZcEt"), false, 1845990193);
    this->hZlTDQPNbHBaEsH();
    this->zaathFO(string("aMppZmTaPvQCbjsSloNLtcxDffUmABdlHcvVHHGfeDRNEIMwyPpFeFaMrpzVeXqZWCsEfkUxOehWMbkAyakhIbolddSEcrEjuvKiLSKDyBcSnFmvyAgyIKEzjrwJNinShbhnAxhbXBVREfUogCBmRWgcPkIgLyWPdsjHq"), true, -683803658, string("cxxKjYlgVtaETccEechCslwqJHkJdbxWekUIBHXfeMcGhOkMLiZaMpBCeaGYigmgfLWQyKlnZvekzZTgTfVjiAwkGHYxafqiLXvCQFDZrEkVkbkPuDGtOaAoavZGeNMNfTMnsUJLOjDdfGvNUnKTJJunfvIhKMIrYvznNLJruz"));
    this->mNAtPIJwQBWedu(string("tylSBesujRfaljIsvWBIDQrKmikFpZcFYNaDlgzMYJnnHgmGxzGErnIFaeuDMJWHrBSkYroeZYPmOiyPXABduZNibJEDXQigQNqbBhH"), string("zQpKsVGftSyvC"), string("DZOubtBqMYsEXD"));
    this->hiTBERzwEiLmAIx();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DdkRlt
{
public:
    int iWSoUsasLxbUjvSc;
    double oiSSOulfOG;
    string NvLKapTTblSZKa;

    DdkRlt();
    bool BEtcYKslW(string sOGNm, double SJhgGFH, bool wtHIqiegNds);
    string CaMcwHV();
    int UPGsfPKkWiGv(int gcNMyZWsSzFo, bool xTXgGlNcMFLI, double IULAUOpdy, bool KoxHuipSJ, string LHNbG);
    void xjbhf(double iisrrzXTOwoSr, int FoPjIfNmIGZauRh, string JxCtqxr, string VSIjI, bool FpXKvPrySfO);
protected:
    double QxRbAAvzEHAl;
    int ySgiuKfTGBwytKUS;
    double TAynGBz;
    bool sQLigncS;

    bool tynLbIRrR(double YjxcgABSNqLZVtbJ);
    string ipWWyqaoVrReD(int vahWxt, string HCSPoumLFQeyQkvt);
    double pjIPLfiPeOcHAh(bool HvZVFq, string TLixP, string AsvjnzjAUCqmEcr);
    bool GKxfRgDqqYfFW(int FSGqxg, int fDGriyFiG, string QjvKm);
    int kOozRHC(bool BLRikLZbNxAS, int urLHEJnDHYYfZmwr, string aTfjjscJxcbyld, bool mcfKwlnBVxPZ);
    string gJoXjveByorZslK(int NXGdtzk, bool OaFOxxNpdIVzCfmd, bool sDjMJidtto);
    bool pfxjQep();
private:
    bool kPQwYXqGyJjHhYTE;
    string PYPhajZiNC;
    bool qCybgMKDdb;

    string UREAD(double LtCEaSfSofg);
    string BczZUgJ(string HteTmWxqNj, double aiXityZV, string eNRDMzfYg, double AhADKspcemICI);
    int gJKrRuWPtwx(string lPsZkGIK);
    int sfsidscgyozQsQ(int NRVBuxP, double HVVwemMJmsPNMS, double YRNOi, string GNOiImdFAPGqr);
    double zcYigDTBDhPuy();
    double RnaoOkRww(int FtLqUBsRxSbVLFo, bool jJfKHVTd, int VKsGckDatJkhPnL);
    string IkDGoWNBJIG(bool ufDfwIhc, string oKDyeFoksxfqV, double mAZAXEwzXemVWih, bool huMQk, bool RLUImSihhmQpq);
};

bool DdkRlt::BEtcYKslW(string sOGNm, double SJhgGFH, bool wtHIqiegNds)
{
    double JFqKKzgTuX = -179900.35753549094;
    bool cRtJShRI = false;
    bool uSnMTtV = false;
    int BTxVBMWJWoAa = 1890183654;
    string CKEfT = string("mxXWssxaoEjpJwZCnoqcJtlwabmxhTRlMwvtAaTujyfgWVczEcNXHepzIGSAbPPsgdhIKNYiVMwJCIKzqPXDSpKQBHNUGZHVAeNunhSFsxesbthFckqxEtuZtKxobcPkZGTDzQfpTzNSxhVyFXGGKBSPbhahuUGQrNgyZHBBSbhHSYcCWlZgKV");
    bool hkIVNvSoWAGEap = true;
    bool HzzBSjaQZDthI = false;

    if (wtHIqiegNds == false) {
        for (int yxpKleBnzTR = 2032157222; yxpKleBnzTR > 0; yxpKleBnzTR--) {
            SJhgGFH -= JFqKKzgTuX;
        }
    }

    return HzzBSjaQZDthI;
}

string DdkRlt::CaMcwHV()
{
    double eGgGBqv = -848395.742009806;
    bool GgXjeBMNj = true;
    double dIjXDjt = 479092.49640701956;
    double sOzoXfgpna = 139059.21331711477;

    if (dIjXDjt < 479092.49640701956) {
        for (int GhgBbVqiy = 530104126; GhgBbVqiy > 0; GhgBbVqiy--) {
            eGgGBqv /= eGgGBqv;
            sOzoXfgpna *= sOzoXfgpna;
            eGgGBqv *= eGgGBqv;
            sOzoXfgpna *= sOzoXfgpna;
        }
    }

    if (eGgGBqv >= -848395.742009806) {
        for (int UBxBcy = 1683867300; UBxBcy > 0; UBxBcy--) {
            dIjXDjt += sOzoXfgpna;
            eGgGBqv -= dIjXDjt;
            sOzoXfgpna /= dIjXDjt;
            sOzoXfgpna /= sOzoXfgpna;
            eGgGBqv *= dIjXDjt;
        }
    }

    for (int hftEkUsTSBlyvBm = 424278356; hftEkUsTSBlyvBm > 0; hftEkUsTSBlyvBm--) {
        dIjXDjt *= eGgGBqv;
        eGgGBqv /= dIjXDjt;
        GgXjeBMNj = GgXjeBMNj;
        dIjXDjt = sOzoXfgpna;
        dIjXDjt /= eGgGBqv;
    }

    return string("ohLLgwsVHzbJfNUdKergIGDMgYVWMprcIQqatGotcKVflBfGRWPYfxbN");
}

int DdkRlt::UPGsfPKkWiGv(int gcNMyZWsSzFo, bool xTXgGlNcMFLI, double IULAUOpdy, bool KoxHuipSJ, string LHNbG)
{
    double yjcKDvDbJCTAEu = 130274.61170037332;
    double XmEBP = 620254.2169876123;
    string tLiNeyNX = string("VkFsbDnfDgZlZubpZPtSZpPGjuYGMQZZlZjqaEmhUmQtfICaVEUrubiyRzukVKgysWlUfsotpgTVHosLHKQakQQkBalZUrXxJkSLiHyczGJCaKebNuVigaLhKuPbPPVJcVElNJyOXABgsArlQVxwbdleAvwaPkbODRLLagnWkHsDXLOguYIqBLlthVHMoqBBENEQVYEXwkKgbeZpEWhsPSeCuZMmmKondwxBHTfkgzbJiOXdL");
    string WqpPiwNqFg = string("lHbSxHzMzMWklOPvxJFOUQLppLyopbSVYcJfJwnTQcThBLcVCGXfAuiyBEZXPKabuOThWsvCUIJPmooynCTraQIdGWeVdwCSUqdivruJZLlAaHfrsohZfnPLVldewFUpOntymZNKwXZPKZZQPPybfowTfpVvuLMIgcRKFkbxXYlinliEmfbZzALCuXXBkWwZhROpxcOungGgPQEuWswHyLBDMLsiLylIuntvEkyfCy");
    int CgVSCaMilx = -146806993;
    int FmowxzlwMsBG = 1656375409;
    double YsDTybmBSLGeIgsb = 670692.3502365865;

    for (int fiGOwPdVPNFHs = 658491904; fiGOwPdVPNFHs > 0; fiGOwPdVPNFHs--) {
        yjcKDvDbJCTAEu /= IULAUOpdy;
        KoxHuipSJ = xTXgGlNcMFLI;
    }

    for (int Coggx = 943466280; Coggx > 0; Coggx--) {
        XmEBP = YsDTybmBSLGeIgsb;
    }

    for (int seDvX = 63848923; seDvX > 0; seDvX--) {
        continue;
    }

    for (int liFgxIaooVqfu = 1253886962; liFgxIaooVqfu > 0; liFgxIaooVqfu--) {
        LHNbG = tLiNeyNX;
        yjcKDvDbJCTAEu /= XmEBP;
        YsDTybmBSLGeIgsb += XmEBP;
        LHNbG += WqpPiwNqFg;
    }

    for (int BTNJCwhF = 1512678427; BTNJCwhF > 0; BTNJCwhF--) {
        continue;
    }

    for (int wbYMqfOPAs = 1874988014; wbYMqfOPAs > 0; wbYMqfOPAs--) {
        XmEBP -= YsDTybmBSLGeIgsb;
    }

    return FmowxzlwMsBG;
}

void DdkRlt::xjbhf(double iisrrzXTOwoSr, int FoPjIfNmIGZauRh, string JxCtqxr, string VSIjI, bool FpXKvPrySfO)
{
    int QHnWvjnKFA = 188249616;
    bool lrgfbFwzPXrszDTe = true;
    int EBYCykEZFoCXxjem = -990012849;
    string aHaXSiO = string("FrSPNIquxxCunkVCKezCjmByWmQbIpdJAJQoyhHOgOorthelyWSjBXYgbUtiicaOcEjrKoPTsXNgaJBSOKjrNWkzWrsvuv");

    for (int ERWePJOVX = 169574902; ERWePJOVX > 0; ERWePJOVX--) {
        JxCtqxr += aHaXSiO;
        QHnWvjnKFA *= FoPjIfNmIGZauRh;
        FpXKvPrySfO = ! FpXKvPrySfO;
    }

    for (int AUSqbZfFLI = 1723718777; AUSqbZfFLI > 0; AUSqbZfFLI--) {
        FpXKvPrySfO = lrgfbFwzPXrszDTe;
        QHnWvjnKFA *= EBYCykEZFoCXxjem;
    }
}

bool DdkRlt::tynLbIRrR(double YjxcgABSNqLZVtbJ)
{
    int ebjlaRU = 531658688;
    bool cdwxjZiZjiVZz = false;
    int dDbciobEks = -1464418893;
    bool HOFmoYs = false;

    for (int QqcKXaszwuOK = 1821982632; QqcKXaszwuOK > 0; QqcKXaszwuOK--) {
        continue;
    }

    return HOFmoYs;
}

string DdkRlt::ipWWyqaoVrReD(int vahWxt, string HCSPoumLFQeyQkvt)
{
    double VrKIpLvjmYXMdBQ = 351728.0236098307;

    if (VrKIpLvjmYXMdBQ >= 351728.0236098307) {
        for (int QDkJDwj = 658130473; QDkJDwj > 0; QDkJDwj--) {
            vahWxt -= vahWxt;
        }
    }

    for (int BCiSOIHQTGXDVi = 1913109192; BCiSOIHQTGXDVi > 0; BCiSOIHQTGXDVi--) {
        HCSPoumLFQeyQkvt = HCSPoumLFQeyQkvt;
        VrKIpLvjmYXMdBQ = VrKIpLvjmYXMdBQ;
        vahWxt *= vahWxt;
    }

    if (HCSPoumLFQeyQkvt == string("jSyXhiQLxGmEPKLuJZoLdxofpSxPGDvvmIYoXnNgESLNjgJZApCKcAeCwsqHkdQMWPumCvuTmADlAYdoqtvLDuWAAPObTlfkPyLtglSVzchTJwEEwTmcgiqosgJHcWiFPFbAadXgGyboBPuvpPWbIjJnUUHKdFYiDRlSVgqybwUmxEYuoHnxToeLrNyfdpUsYdJmeppAxnIgwjeEFEUG")) {
        for (int bQQCbRTNhdJXon = 208945724; bQQCbRTNhdJXon > 0; bQQCbRTNhdJXon--) {
            vahWxt *= vahWxt;
            vahWxt *= vahWxt;
        }
    }

    return HCSPoumLFQeyQkvt;
}

double DdkRlt::pjIPLfiPeOcHAh(bool HvZVFq, string TLixP, string AsvjnzjAUCqmEcr)
{
    bool DpkGHQRG = true;
    string DOsIvIYZCkbqQ = string("DdpMrNWGlZsRBGJsHWiDtiRGGRHAdYikkTZNFWq");
    string orryWjVXNqcMr = string("KXPoqpDTuoxQZIRDvoGbQSDXkKLldMdvjpIOWBaZDlqfuFNqtQDNDBfDxNeHFtwJkQSEmetJIUtnxMvzdmBpyccUBEXcIWovxKSgwnQosSDCdxYPfQiiOUBPYPtvjhIedYuMyGzxWmuM");

    for (int MwCvSyY = 1873343533; MwCvSyY > 0; MwCvSyY--) {
        DOsIvIYZCkbqQ = TLixP;
        TLixP = AsvjnzjAUCqmEcr;
    }

    return 799811.2891215532;
}

bool DdkRlt::GKxfRgDqqYfFW(int FSGqxg, int fDGriyFiG, string QjvKm)
{
    double aXgHLEHHKfhOVn = -867070.4130095668;

    if (fDGriyFiG >= 1600647922) {
        for (int BBlhBHtT = 1920069013; BBlhBHtT > 0; BBlhBHtT--) {
            FSGqxg /= fDGriyFiG;
            QjvKm = QjvKm;
            FSGqxg *= FSGqxg;
        }
    }

    if (QjvKm > string("jQVccqAxLqudFiyZhaFYmtIxoclTiXoIRSYueLcESCstLzkaSxwauosWlhVEOWgPYdMdtCGabEwSJAIZSqmZRnvuTZMkHQoBfnZsYOGQyGLJUcFPnklSiQTplgcAUikaLgnzCrbYpvYFRjJcopnxwbMCDwhAGwyeoAshqGkJpubkmlXlJYTLwnRKKfmdpMlFWzKtBBNtttu")) {
        for (int MZRUmXzmG = 1692321936; MZRUmXzmG > 0; MZRUmXzmG--) {
            fDGriyFiG = FSGqxg;
            FSGqxg /= fDGriyFiG;
            aXgHLEHHKfhOVn *= aXgHLEHHKfhOVn;
            fDGriyFiG *= fDGriyFiG;
        }
    }

    for (int EViExqkB = 365547642; EViExqkB > 0; EViExqkB--) {
        aXgHLEHHKfhOVn -= aXgHLEHHKfhOVn;
        aXgHLEHHKfhOVn = aXgHLEHHKfhOVn;
        FSGqxg -= fDGriyFiG;
    }

    return false;
}

int DdkRlt::kOozRHC(bool BLRikLZbNxAS, int urLHEJnDHYYfZmwr, string aTfjjscJxcbyld, bool mcfKwlnBVxPZ)
{
    int VPUzJ = 961136959;
    string LXyHuIQp = string("xPeZyaDCaomkarbCJppYPLmaoFdBCaVndDTEhOEYJqUxEEDFOvzkiShtzsftumHOlzaoAxPMndMeVSdMXcKOsBjFeesGntYuhHYqygZnibzUUQhqpkLcpVGgKSDsDVpeBaGyNMyEalQXPEvqXdpkUhrZEOrXHeRTCmxDCHmSDbRXprzIlq");
    int IWJAXUPWSrxvrLV = -1472439489;
    string bFgVfgyZX = string("BFUSYdegFdhCeCXrNRztehIeZFbMswSRYrKELxzQFsOhrPfpvPZjYYuLiyrtuwIunQPAdiWdeIcQLPWmEwrkRMdLz");
    double SfuSDamu = -467361.7552080494;
    double VYLaaWgcCVRa = 40538.043413091145;
    double RHIVBSVIvxlwiYtS = 710634.5229144614;

    for (int HQTkSvq = 1241578729; HQTkSvq > 0; HQTkSvq--) {
        LXyHuIQp += aTfjjscJxcbyld;
    }

    return IWJAXUPWSrxvrLV;
}

string DdkRlt::gJoXjveByorZslK(int NXGdtzk, bool OaFOxxNpdIVzCfmd, bool sDjMJidtto)
{
    string LFiorCLTkS = string("AbBiwcCpkpXrxujGWfsBIkHugnRovKJcydcJMClrXtPSQuNSb");
    string MUGdgHixLMQAv = string("RBEUowtpkjgpypADOZdOrGjHtorqhadSDJnMprmwWqkpPfpkjfPUBawWSUNJaBogNEMCkLApoelKsdHnHOJGtOOJRUdXPKFMaxpgGBBPWQtuARneELBRYHAwPIQCPwZPoDtHmmSYGgMpsDM");
    string oxmpy = string("ZVFImoJfFfPaSKTnnOsvDBIhDNpiZiPDZftkSIGkbAEPLusgSoztAvvmzXglhuqGJMuBYZ");
    bool QjgMLaoqAwgIyL = true;
    bool boHFIsoZpCit = true;
    double HrLpLirALcOjD = -306080.4801009142;
    double rezuylFHRtFDdnJ = 115892.41052997689;
    string JpixXVBF = string("HJEagmnZkvCgtKrvrsHSUXTtLJRpdtHmuzjslnuygZJQgZtjsoGIHDSyXjLGBvyQUudgracXkFIkmpSRPCPipLTxFTEWqqwUTiupEabYSrKxCSePQzklDdieOJCOGtXhkyBskLKsCHtaZMnEIDPPZWvUmH");
    double hcMfOHPkZHrgkEQw = -174319.68594996852;

    for (int RMVkHxIFCFfZxviS = 1716596432; RMVkHxIFCFfZxviS > 0; RMVkHxIFCFfZxviS--) {
        sDjMJidtto = ! OaFOxxNpdIVzCfmd;
        hcMfOHPkZHrgkEQw += hcMfOHPkZHrgkEQw;
        QjgMLaoqAwgIyL = QjgMLaoqAwgIyL;
    }

    for (int wPygudh = 1358089431; wPygudh > 0; wPygudh--) {
        continue;
    }

    return JpixXVBF;
}

bool DdkRlt::pfxjQep()
{
    bool WlfaccAKFzXNeI = true;
    string AdNmAxbU = string("AmXcnKAzIsBbtQhzPxhhgQPgCKbzMFFfylJrfHNnHHiTuXnXANUSeVqptVFjCdzfkRDxaGHnJLQPlSSmZtvPgAuZfWYBjcVJkdGGycusYusOqNHKEUznSzGQDZNgUJiDZCQBcVOhPSaIUECzpqLjwoffJcYWsliwkUdcIJColUScgqQNGHwdCdrlgiIlGyJ");
    int KvygeI = 431932570;
    bool SktfJEIMC = false;
    string FWDWkyedvt = string("yBjhXGOqSjsWmq");
    bool USKRmszHYfTG = false;
    bool KUPFyIFqZ = true;
    string kDIYgvKdpllozav = string("cjqeXngLziCGUJvQbNxXzmWkPwARqqNixyfglTTozEqgMadRCibmUnwGaaVpzPlYmgJbmOTDXgeBRLwZjSMQuNVpQBbRnFCrUPvZhGCEAFrxvYdnElGarFpLRDapTBPiMORekXxvZSMqSmyFzLVpcdlVgUGQKWGHzyJvfdXWnbRhTfVeYCImqGDKHcJeAegVCmoLciEMSvsEhU");
    bool WuGmVnmiSCCw = false;

    for (int PYBZhYlzudcoLIxC = 292631498; PYBZhYlzudcoLIxC > 0; PYBZhYlzudcoLIxC--) {
        AdNmAxbU = FWDWkyedvt;
        USKRmszHYfTG = WuGmVnmiSCCw;
        USKRmszHYfTG = ! SktfJEIMC;
        WuGmVnmiSCCw = SktfJEIMC;
        KUPFyIFqZ = ! USKRmszHYfTG;
    }

    if (WuGmVnmiSCCw == false) {
        for (int KBDaoYGZIudobtb = 983463476; KBDaoYGZIudobtb > 0; KBDaoYGZIudobtb--) {
            SktfJEIMC = ! WuGmVnmiSCCw;
            FWDWkyedvt = AdNmAxbU;
            WuGmVnmiSCCw = WlfaccAKFzXNeI;
        }
    }

    for (int jiCHJ = 1246962088; jiCHJ > 0; jiCHJ--) {
        kDIYgvKdpllozav = FWDWkyedvt;
        KUPFyIFqZ = WlfaccAKFzXNeI;
        kDIYgvKdpllozav += FWDWkyedvt;
        USKRmszHYfTG = ! SktfJEIMC;
    }

    return WuGmVnmiSCCw;
}

string DdkRlt::UREAD(double LtCEaSfSofg)
{
    double nfvaFBxlOIP = -71502.86518844764;
    double tZWDN = 49533.29741652569;
    bool vkemrVyqdulbSx = false;
    double NMtTKMBHnU = 739864.7977746836;
    double EkFXzlxzOLjfYq = -556840.4783715957;
    string XkoCvqPAc = string("OaOZhQofemhweUOwmgUwEvyrTygCPAipEsFQofMbJACkGsEoynOLxvmsCXmLYWomfSvbUFZGmncWILJitZxTwcyHkyqpcQKpWnseLZrGsBVgRLBKJBSWjfjvPyTYmTfLpyndZwgqLvbkSmKdqyUqFjthLOpojvBekoNVbGNSlCYFVkTuVwCiKSlhqPuZoAwor");
    double SczLedfi = -993114.7614734648;
    bool CjBsFkNIaBRo = false;

    if (LtCEaSfSofg >= -71502.86518844764) {
        for (int hDEOcGI = 654484843; hDEOcGI > 0; hDEOcGI--) {
            CjBsFkNIaBRo = ! CjBsFkNIaBRo;
        }
    }

    for (int nySYdmOPoBU = 1415465933; nySYdmOPoBU > 0; nySYdmOPoBU--) {
        SczLedfi += NMtTKMBHnU;
    }

    for (int AmlvbNCPHF = 401110866; AmlvbNCPHF > 0; AmlvbNCPHF--) {
        CjBsFkNIaBRo = CjBsFkNIaBRo;
    }

    if (tZWDN == -556840.4783715957) {
        for (int rgVBgTStTryOdz = 652989819; rgVBgTStTryOdz > 0; rgVBgTStTryOdz--) {
            NMtTKMBHnU += LtCEaSfSofg;
            LtCEaSfSofg /= SczLedfi;
            LtCEaSfSofg /= SczLedfi;
            LtCEaSfSofg /= tZWDN;
            XkoCvqPAc = XkoCvqPAc;
            SczLedfi /= LtCEaSfSofg;
            SczLedfi += NMtTKMBHnU;
        }
    }

    for (int zrjcOOjmKLuc = 1222714644; zrjcOOjmKLuc > 0; zrjcOOjmKLuc--) {
        nfvaFBxlOIP /= LtCEaSfSofg;
        tZWDN -= nfvaFBxlOIP;
        EkFXzlxzOLjfYq += nfvaFBxlOIP;
        nfvaFBxlOIP = NMtTKMBHnU;
        nfvaFBxlOIP *= EkFXzlxzOLjfYq;
    }

    return XkoCvqPAc;
}

string DdkRlt::BczZUgJ(string HteTmWxqNj, double aiXityZV, string eNRDMzfYg, double AhADKspcemICI)
{
    double GnCJDAZg = 900489.5818985953;
    double aCKapsjMFuQu = -321721.72032218;
    int oqydcJZUfWAkoau = -1726457726;
    bool MIsBAWjVtnGQCa = true;
    string KWJJkRltD = string("FuHwvyNxrbCzDUeZiarASMYzBPcAGHFUvaFsACKArFOgSNUlWuYHOlYtqpsScYMpwcYcJqwnXBPFaIadcwOqXPVustfBaFwpBdcQQHXiUtSWlVpVPZvXpIvoVVVKcZhPdhuxMMmjaFWXLyXBshBcJdNGZDV");
    double rtpSIbLz = -168874.34155869982;
    string mcWbgnjjytG = string("yRUfWPrtAtmnbFDyNXiFRniSgvyIbzkhdzBEaBjcjzAXIZtHv");
    int GBuePTNWAKWzAu = 281305897;

    if (MIsBAWjVtnGQCa != true) {
        for (int DMEfaKcIkFtBzj = 79067344; DMEfaKcIkFtBzj > 0; DMEfaKcIkFtBzj--) {
            rtpSIbLz = AhADKspcemICI;
            mcWbgnjjytG = HteTmWxqNj;
        }
    }

    return mcWbgnjjytG;
}

int DdkRlt::gJKrRuWPtwx(string lPsZkGIK)
{
    int RvMwWPIeIdAlZ = 201880763;
    double odHmfN = 455481.2245245913;
    double EfgqrOpD = 697146.2670645437;

    for (int iaIhnncqRpikRJ = 797571791; iaIhnncqRpikRJ > 0; iaIhnncqRpikRJ--) {
        odHmfN += odHmfN;
        EfgqrOpD /= EfgqrOpD;
        EfgqrOpD += odHmfN;
    }

    for (int OwdnRSWQEJHnz = 1449771430; OwdnRSWQEJHnz > 0; OwdnRSWQEJHnz--) {
        continue;
    }

    for (int iMoflaJj = 349149181; iMoflaJj > 0; iMoflaJj--) {
        lPsZkGIK = lPsZkGIK;
    }

    for (int SOtVJziao = 594317295; SOtVJziao > 0; SOtVJziao--) {
        odHmfN = EfgqrOpD;
        lPsZkGIK += lPsZkGIK;
    }

    if (EfgqrOpD >= 697146.2670645437) {
        for (int syCcDknHecK = 930211792; syCcDknHecK > 0; syCcDknHecK--) {
            continue;
        }
    }

    return RvMwWPIeIdAlZ;
}

int DdkRlt::sfsidscgyozQsQ(int NRVBuxP, double HVVwemMJmsPNMS, double YRNOi, string GNOiImdFAPGqr)
{
    bool JWVHlzkxIGsYOQ = true;
    string WJwbNjTfcX = string("NqWZRPNXyOwdaBcUfKxWTftCdPYGvpneazimylinGXsQjRBBvewBcmovnyVBdhmiRpWHGeLuRjBTXtaGLTeSzFGsdRHkASOgjBVnGzxrNBGCHgsFnDrwQZPcFFaUHzdBaxsCbXvkqBlIXVRckitPFTLGUzqnBadwOcjQnrjvakcZwWObVkZykQiwFjIAnRO");
    int piFFA = 11627563;
    bool WJUXpFPh = true;
    int SyPkSbctSkhj = 424085055;
    double raiiwmEsKruT = -9240.706911181682;
    int VFdVhTkphGTGCUwJ = 940795105;
    int kKMqzMWS = -1610928699;
    bool LZezR = false;

    for (int RNKrbDapM = 356213801; RNKrbDapM > 0; RNKrbDapM--) {
        kKMqzMWS /= kKMqzMWS;
        WJwbNjTfcX += WJwbNjTfcX;
    }

    for (int vKnuxiA = 1509461753; vKnuxiA > 0; vKnuxiA--) {
        kKMqzMWS = VFdVhTkphGTGCUwJ;
    }

    for (int fNKOQRMPdNEuqoFM = 625478411; fNKOQRMPdNEuqoFM > 0; fNKOQRMPdNEuqoFM--) {
        continue;
    }

    return kKMqzMWS;
}

double DdkRlt::zcYigDTBDhPuy()
{
    double OtVjMZBellkuyT = 470932.3844807575;
    bool nrFLoVYpK = false;

    for (int IaXpSedSLRuTuQ = 1140912090; IaXpSedSLRuTuQ > 0; IaXpSedSLRuTuQ--) {
        nrFLoVYpK = ! nrFLoVYpK;
        nrFLoVYpK = ! nrFLoVYpK;
    }

    if (OtVjMZBellkuyT < 470932.3844807575) {
        for (int mogDg = 29132492; mogDg > 0; mogDg--) {
            OtVjMZBellkuyT *= OtVjMZBellkuyT;
            nrFLoVYpK = ! nrFLoVYpK;
            OtVjMZBellkuyT = OtVjMZBellkuyT;
            OtVjMZBellkuyT -= OtVjMZBellkuyT;
        }
    }

    return OtVjMZBellkuyT;
}

double DdkRlt::RnaoOkRww(int FtLqUBsRxSbVLFo, bool jJfKHVTd, int VKsGckDatJkhPnL)
{
    double poGawU = -26728.30250137214;
    bool tIYBOHFJaYUOSkX = true;
    string FsudLIfvNo = string("aiYozMwNGdPLBkltVbMbYomnlcQABOGiJLGIxKqfSYNFkcHXVeQeQfcuJspPRifBnAlfOwwYrIJsynHyhwhCccKbUTkDexApvnpWtfAyHNIXIwLZMEbYQBjyhpgVAPDAaWUdOdBNkzptGNoPE");

    for (int nrcszyGfAR = 348701585; nrcszyGfAR > 0; nrcszyGfAR--) {
        continue;
    }

    return poGawU;
}

string DdkRlt::IkDGoWNBJIG(bool ufDfwIhc, string oKDyeFoksxfqV, double mAZAXEwzXemVWih, bool huMQk, bool RLUImSihhmQpq)
{
    bool iisrSl = false;
    double RqJtSdK = -333702.5522038833;
    int zWcEaxHrlAaJm = -437565120;
    string NymfumIJtGVD = string("RlLINQnfgeuPyLWbBgsmlnHsMieidcQhfyAAanoamOaoRHQv");

    for (int XaCCW = 365982023; XaCCW > 0; XaCCW--) {
        RLUImSihhmQpq = RLUImSihhmQpq;
        ufDfwIhc = iisrSl;
    }

    if (oKDyeFoksxfqV > string("RlLINQnfgeuPyLWbBgsmlnHsMieidcQhfyAAanoamOaoRHQv")) {
        for (int oxfwvC = 1779471379; oxfwvC > 0; oxfwvC--) {
            ufDfwIhc = iisrSl;
        }
    }

    if (RqJtSdK <= 292642.5531477492) {
        for (int WRixGWXTWGPrfjB = 583002465; WRixGWXTWGPrfjB > 0; WRixGWXTWGPrfjB--) {
            iisrSl = iisrSl;
            iisrSl = ! ufDfwIhc;
            RqJtSdK /= mAZAXEwzXemVWih;
            huMQk = iisrSl;
        }
    }

    return NymfumIJtGVD;
}

DdkRlt::DdkRlt()
{
    this->BEtcYKslW(string("piDPunDXqKTMftRLboIaYclUGwTnAxNjvybCuUHDcBQAquGXqEGlmRmSKnarwoozNZIQXtIWxNfzyNlITDjmDfOxiryQpxZHubIWHnTXVZpFCNyFmQVWhLvLRLCyMqvpkdMkAaSImsQXyFAdnEUWHgxlczdMxHQpWKRXVhIyzmVQeQQgiDHRrmXJsGtkbSNADuVwRcUOQMLkDLzlYuocBoACXLOtG"), -937509.0543727729, true);
    this->CaMcwHV();
    this->UPGsfPKkWiGv(-438896138, false, 527797.4466765866, false, string("WVbbntuwqxvcPDtVSTGvPviIZPy"));
    this->xjbhf(679417.5742954587, -53110207, string("zbHqCYYbtepEnmGgpjaNEpbubMzQWOWtRchNGxEiUCIfmtOsloZLwXCtpJRLGqxsyqLWKmBnxbcEYqYyZhTGdDrTQqEqfAXjoEkPDsWCOknzlAEEOcTqkwMzoaTjGDAtNuYytZDtVGMeeteQyZkXZbkXulRuvhwMfGWrRdacGabHnWYNhGXxiroDxkEUp"), string("eAJWObFwUDnhvthsRYbSaWZqOsfzAhENBZaEyjJCvLjDCERFVAgUjCZqYTHLSKUBcDGbLuZUEVwpnGujscJulJoqUKGKPcfzgUgQDIbBPlJqRanplrgoWJQIeZAJFZRgrRuAdbOQjPbFUWLHKAxKYwO"), true);
    this->tynLbIRrR(977197.0571983184);
    this->ipWWyqaoVrReD(-1878240868, string("jSyXhiQLxGmEPKLuJZoLdxofpSxPGDvvmIYoXnNgESLNjgJZApCKcAeCwsqHkdQMWPumCvuTmADlAYdoqtvLDuWAAPObTlfkPyLtglSVzchTJwEEwTmcgiqosgJHcWiFPFbAadXgGyboBPuvpPWbIjJnUUHKdFYiDRlSVgqybwUmxEYuoHnxToeLrNyfdpUsYdJmeppAxnIgwjeEFEUG"));
    this->pjIPLfiPeOcHAh(true, string("IzyjXzkONISbbIqAjyZOnHJYcGdwBaeINIPXKjpBsrLRDwfabuvUGiiONcsOgpGBTIzHLj"), string("xJZWkqgtQYHjMJXYaNEgSSjszDoUaYozCCPeVJhYGCgXKrZBrtOFNEPumxYRYVgkaSxqYIvHmKjPFeIdQXHWadOj"));
    this->GKxfRgDqqYfFW(1600647922, 1921231837, string("jQVccqAxLqudFiyZhaFYmtIxoclTiXoIRSYueLcESCstLzkaSxwauosWlhVEOWgPYdMdtCGabEwSJAIZSqmZRnvuTZMkHQoBfnZsYOGQyGLJUcFPnklSiQTplgcAUikaLgnzCrbYpvYFRjJcopnxwbMCDwhAGwyeoAshqGkJpubkmlXlJYTLwnRKKfmdpMlFWzKtBBNtttu"));
    this->kOozRHC(true, 1483973664, string("acAqAbqrowMpyRUufvtKHYxTuGmGdGzQgialytMRyjcqhdXUIstglAoSTldsDjnPfwMcOuKeWfBEGSFpiBezyWVTEAdYuMOnzPqHGbhySbJCIfITJxkkHZarGImyEXbOIxINSkUaoZmwqVXzqgwYvoajBGIgaCnhyvIzQUSZGp"), false);
    this->gJoXjveByorZslK(-843095972, false, true);
    this->pfxjQep();
    this->UREAD(-317001.9509220542);
    this->BczZUgJ(string("qnRxNAUVFdUToAFTjfCGUXebgoL"), 761778.6497116367, string("fPjgudPABZHkvWGmLbDgIvNOSIGqwjLYSWuPWUKrXgBCxcHuf"), 571447.8837710009);
    this->gJKrRuWPtwx(string("SvGatDNsehovMYlmRjwHpsVHBQZGOJPviIokpQmTqrbwxaSIdgDruitIrXHVdnOktHuCLBRbUywyBldkzIvuqYyGhsJpOijCfgYJbmmQMVQfznxPXwISsjzUtpWsfFKACqpSPkICmSwZUyHZURfyLgCHABagHdpfhIdwmyzg"));
    this->sfsidscgyozQsQ(1533172332, 374656.605707316, -257409.28474724296, string("KGApixG"));
    this->zcYigDTBDhPuy();
    this->RnaoOkRww(765825248, true, 675599205);
    this->IkDGoWNBJIG(true, string("djmGmAdLiVUSLLzhzAEVdrxEUjsBjbVWPFocXyWNAn"), 292642.5531477492, false, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cbxfGXEgZZOViBu
{
public:
    int nlAOFNfymJgQnYS;
    double vEteJaZwCaVByy;
    string mTypfQyZPoWS;
    int UdJSVh;
    string DBtHKJBVS;

    cbxfGXEgZZOViBu();
    int qWKloYREow(bool kifIzllRgPOUqHT);
    int hsXmVOJM(string KRUcHmawiA);
    void rqsYZ(bool oRKVsb);
    void MKdREMwURuG(string kaATMxazZMSekHc, double aUlcyVfQK);
protected:
    double qefNTnoTOLpHA;
    string tXqmAJJl;

    double VSKnJLMmRL(string PJwpCZWJpcTlkk, double bivzFFmmS, string ALlafoUic, double bGzPwezL);
    bool kWljvgfFUZjQpL(double MXigDmSpsWoSfPZw, int HACXdNJSclgAFq);
    string rEkVoelz(double cwoow, int DuGczjFhr, bool XKCqMadxW, int cnbMyHW, int tQKwTMH);
    double pUqjrWxw(double QNHuIGyAreTTUO, int ItLciCnC, string zzCWGEBCEdpJE, int ikEnLdXSWSXIfSQH, bool aZlxRh);
private:
    int DoYzyqiUXPG;
    int pbGzHg;
    double HMTgu;
    bool jgORHuVR;

    double JzCXBvaVO(bool mPEYfEQEGNMGStSE);
    double vAJLeWNlaMUHwt(double HCgFNJUhtLhZVu, int IOOYkiyT, string AdKqRbAownhLS);
    string FyMbEoEXSHBN(bool NtmbVTqjxGqsDxkG, int bVsPGo, double LQTwrnxWf);
    bool aLjoEVQPL(bool NZTbgEphNrgtBsR, string YRFTXuqBmAdAXx);
    void gOYhtrV();
};

int cbxfGXEgZZOViBu::qWKloYREow(bool kifIzllRgPOUqHT)
{
    string brZZSJVSClOtwDpJ = string("jsllYaeRofPkhApgMArZnvZSuLomZYKIIKOQfCmboInlXznfymtfhiSpWvCIytAiUDhwUwLHLNDgJdsqksyTjNvxasUjWWTqPkiMcXgJCfTLzlxObtNGKuNEfIGudQnFXwBFQCQZYvyfEoybaTqCWpPVQxMOftjiWp");
    double QIYYoDPIdLFtouR = -199970.6397011742;
    int QsbkrAoM = -2137077951;
    string IyuQuXDiXt = string("ZHTzCZdURRwbRIIesxqpjePnLAzKnLycbAauEbEKMSzgYwhfKaIObxVXPSsbggLgXCcLMYIikeaqbyVfRmMeUnnuihOKoXOdreIipYILEJBYevErzfXMMjJUfIYPeJHLWdzwdTxlKYKtzWhnMkRTLKJShyiFrEvPbKpTodORStyspwRJhuwXuGdeDnHwGoiqjGiTOyAAoNUQczJOZEMeEwgZ");
    double MmTkCQBCZtj = 919708.4659931565;

    if (QIYYoDPIdLFtouR != 919708.4659931565) {
        for (int aSAwLEExsyt = 922202482; aSAwLEExsyt > 0; aSAwLEExsyt--) {
            MmTkCQBCZtj /= MmTkCQBCZtj;
        }
    }

    for (int eigcA = 767289996; eigcA > 0; eigcA--) {
        brZZSJVSClOtwDpJ = brZZSJVSClOtwDpJ;
        kifIzllRgPOUqHT = kifIzllRgPOUqHT;
    }

    return QsbkrAoM;
}

int cbxfGXEgZZOViBu::hsXmVOJM(string KRUcHmawiA)
{
    bool JodmZGDMPfOKHbhX = false;
    string gfBmZnXfydhMeYJ = string("PvFroZO");
    double HbqRNAwkFs = -351119.68183748994;
    string kgKQGRhv = string("aEibvrAhgBkrDTCmkvvaDXIRHpivBldwCOyNtLyWguRvbvYdnOevTyHKwLAweFJUmMXqYVZrzBsaXIFfgjoaWVpdpCDaCuUHUXJnPYTWYj");
    int rfJCRZV = 358434454;
    string WuYHhN = string("UBeOJOGFMnzdqvqRgbbHDqijAxHIGYnnRsOSSKnHPiWUxdfqgNUUsQDyLiTeUjYphaVpfzAfdZjSSqPHJGFsiYWOwUQPqaefTNHASzYJHlfmwJTkFonoqSVdafSujHzYsPBnspkIAgymQYhlUUXhprriuXDdpkrysVqSiXQpzQOgYZntVhGxxuDTRXkxRXaoMJXEeQNkptlsQmLKeCmvcDGYmbClXcdNwOdUHMiFQRIWYHjCztdQrDpP");
    double wQpYxe = -147738.79754947094;
    double JeckkYJyEl = 915871.3152236637;

    if (KRUcHmawiA < string("UBeOJOGFMnzdqvqRgbbHDqijAxHIGYnnRsOSSKnHPiWUxdfqgNUUsQDyLiTeUjYphaVpfzAfdZjSSqPHJGFsiYWOwUQPqaefTNHASzYJHlfmwJTkFonoqSVdafSujHzYsPBnspkIAgymQYhlUUXhprriuXDdpkrysVqSiXQpzQOgYZntVhGxxuDTRXkxRXaoMJXEeQNkptlsQmLKeCmvcDGYmbClXcdNwOdUHMiFQRIWYHjCztdQrDpP")) {
        for (int CrJgRY = 1120590458; CrJgRY > 0; CrJgRY--) {
            kgKQGRhv += WuYHhN;
            JeckkYJyEl = JeckkYJyEl;
            wQpYxe /= JeckkYJyEl;
        }
    }

    for (int qFPVJ = 309955547; qFPVJ > 0; qFPVJ--) {
        WuYHhN = gfBmZnXfydhMeYJ;
    }

    for (int WtIadVpbvud = 1785158230; WtIadVpbvud > 0; WtIadVpbvud--) {
        WuYHhN = kgKQGRhv;
        gfBmZnXfydhMeYJ += gfBmZnXfydhMeYJ;
        JeckkYJyEl = wQpYxe;
    }

    for (int hIoBeqnIq = 1457465605; hIoBeqnIq > 0; hIoBeqnIq--) {
        JeckkYJyEl -= HbqRNAwkFs;
        wQpYxe *= wQpYxe;
    }

    for (int RoQAicPuVoRhxLAh = 1050662244; RoQAicPuVoRhxLAh > 0; RoQAicPuVoRhxLAh--) {
        wQpYxe += JeckkYJyEl;
        WuYHhN = gfBmZnXfydhMeYJ;
        rfJCRZV += rfJCRZV;
        WuYHhN += kgKQGRhv;
    }

    if (gfBmZnXfydhMeYJ < string("aEibvrAhgBkrDTCmkvvaDXIRHpivBldwCOyNtLyWguRvbvYdnOevTyHKwLAweFJUmMXqYVZrzBsaXIFfgjoaWVpdpCDaCuUHUXJnPYTWYj")) {
        for (int slQsgZoWqogykpc = 1653188537; slQsgZoWqogykpc > 0; slQsgZoWqogykpc--) {
            WuYHhN += kgKQGRhv;
            JeckkYJyEl += HbqRNAwkFs;
            JeckkYJyEl += HbqRNAwkFs;
            KRUcHmawiA += gfBmZnXfydhMeYJ;
        }
    }

    return rfJCRZV;
}

void cbxfGXEgZZOViBu::rqsYZ(bool oRKVsb)
{
    double zHUrW = -616130.37913889;
    int EUfDeoPXEkUt = 1205732455;
    double GzVPuMikduiKVupV = 799082.5018741941;
    string IyuzjhtQ = string("CSAZfQSQBmHyFanAlezOdFbcKvxMNDNrftCVvOepcZHErzoQhlDMkVeEUEnQPzwFnXdGGaXGDdmZMYWCbcRukVjRsIHozrEtHzMuFzEyOihnbmWDQfGkouHAZwYRWzNjXyuVjhnKWsrwTuVSYGnCAdjaaISjPXWBSGEpJxStbWSdbBDumLjAMEpYuoUGOIe");

    for (int WNGmbJsOpvwuINjD = 121364075; WNGmbJsOpvwuINjD > 0; WNGmbJsOpvwuINjD--) {
        continue;
    }

    for (int WjKmwUwC = 677281449; WjKmwUwC > 0; WjKmwUwC--) {
        continue;
    }

    for (int AxPDtbuztHOSRk = 999235827; AxPDtbuztHOSRk > 0; AxPDtbuztHOSRk--) {
        GzVPuMikduiKVupV -= GzVPuMikduiKVupV;
    }

    for (int fJPKJqSlG = 436355807; fJPKJqSlG > 0; fJPKJqSlG--) {
        zHUrW += GzVPuMikduiKVupV;
        zHUrW -= GzVPuMikduiKVupV;
        GzVPuMikduiKVupV = GzVPuMikduiKVupV;
    }

    if (zHUrW == 799082.5018741941) {
        for (int AGiqGCuKcN = 1783541331; AGiqGCuKcN > 0; AGiqGCuKcN--) {
            continue;
        }
    }

    for (int tLuiFk = 1260253212; tLuiFk > 0; tLuiFk--) {
        zHUrW = GzVPuMikduiKVupV;
        GzVPuMikduiKVupV += GzVPuMikduiKVupV;
    }

    for (int YavWhXZXtdvlG = 601058099; YavWhXZXtdvlG > 0; YavWhXZXtdvlG--) {
        zHUrW -= zHUrW;
    }
}

void cbxfGXEgZZOViBu::MKdREMwURuG(string kaATMxazZMSekHc, double aUlcyVfQK)
{
    double XNtJsrGDPWHEZpQ = -292741.2832114296;
    string xTcnELlkKj = string("jjtZoPfWDNFaOJLFRiwKwJDqIJwMwqkpiKSuNHfOf");
    int fpCahXwSejdxYdAJ = -1696339107;

    for (int nYzIaSNnpFYi = 315634081; nYzIaSNnpFYi > 0; nYzIaSNnpFYi--) {
        continue;
    }

    for (int UsPwnWeCfBKoyy = 2074227970; UsPwnWeCfBKoyy > 0; UsPwnWeCfBKoyy--) {
        continue;
    }

    for (int REARlJmjpgC = 1797279290; REARlJmjpgC > 0; REARlJmjpgC--) {
        xTcnELlkKj += kaATMxazZMSekHc;
    }

    for (int LfEKnJvxZ = 1336157875; LfEKnJvxZ > 0; LfEKnJvxZ--) {
        xTcnELlkKj += xTcnELlkKj;
        kaATMxazZMSekHc += xTcnELlkKj;
        aUlcyVfQK *= XNtJsrGDPWHEZpQ;
        xTcnELlkKj = xTcnELlkKj;
    }

    for (int MUuFShGsKE = 106032194; MUuFShGsKE > 0; MUuFShGsKE--) {
        kaATMxazZMSekHc += xTcnELlkKj;
        aUlcyVfQK -= XNtJsrGDPWHEZpQ;
        fpCahXwSejdxYdAJ += fpCahXwSejdxYdAJ;
        xTcnELlkKj += xTcnELlkKj;
    }

    if (kaATMxazZMSekHc >= string("jjtZoPfWDNFaOJLFRiwKwJDqIJwMwqkpiKSuNHfOf")) {
        for (int RBhzPATAUY = 482638067; RBhzPATAUY > 0; RBhzPATAUY--) {
            XNtJsrGDPWHEZpQ = XNtJsrGDPWHEZpQ;
            XNtJsrGDPWHEZpQ = aUlcyVfQK;
            fpCahXwSejdxYdAJ += fpCahXwSejdxYdAJ;
            XNtJsrGDPWHEZpQ -= XNtJsrGDPWHEZpQ;
            XNtJsrGDPWHEZpQ += aUlcyVfQK;
        }
    }

    for (int bSGsKKZo = 472357087; bSGsKKZo > 0; bSGsKKZo--) {
        continue;
    }
}

double cbxfGXEgZZOViBu::VSKnJLMmRL(string PJwpCZWJpcTlkk, double bivzFFmmS, string ALlafoUic, double bGzPwezL)
{
    bool JondXGpMKdvCLKm = true;
    int uJzeLRizVdXy = 1772111948;
    int LPuHvQsBsSxhUz = -919718113;
    bool bdLtjrPpPknTup = true;
    double eZUUKHXHOPG = -463950.8620128376;
    bool ycxKYFMH = false;
    bool MRPGedMMcblZ = true;
    string eqKRnNoOGJjNotZ = string("ZWUytHLKIgiEYebTrrCUfBvKTMJLtehoDpiGVhruMbjnjOYtrEJfNoPXcNWNmrIwIJwPOqCZRwMcYcpbIAkNIDwpuSgUBKeBTVkaxtNUsVlYBIBBnqNZLLYIkxhQAALEgySivzPlkFYRhtNNIJIfsokBTzKqiIFtpUuUGqnwFXLzjVjLzNqsOMPSXCnroLXmuSFndNCLChOhPXhZSdxWdqPzEtYWN");
    int JbrLuqRZrERHLE = 2137608630;

    for (int eJAZdC = 1266869987; eJAZdC > 0; eJAZdC--) {
        continue;
    }

    for (int SVNxWuKrmfrCYwZw = 468066503; SVNxWuKrmfrCYwZw > 0; SVNxWuKrmfrCYwZw--) {
        eqKRnNoOGJjNotZ = ALlafoUic;
    }

    for (int wsBMuTFWZ = 556706189; wsBMuTFWZ > 0; wsBMuTFWZ--) {
        bdLtjrPpPknTup = ! bdLtjrPpPknTup;
    }

    return eZUUKHXHOPG;
}

bool cbxfGXEgZZOViBu::kWljvgfFUZjQpL(double MXigDmSpsWoSfPZw, int HACXdNJSclgAFq)
{
    string LdhPaBPoKVBUj = string("WITuCYKoJROpcBtuxezsQpswmPkjUUDItYOCorcCpjqSWdwWOXSFMsHnAsFHLBYizRJtOtVEpvZgDTXRrgkJHTqqCbhWSpwAsd");
    string auiMnm = string("fGtLuCaudChvxXlvMIroDHpnZTjjlgcAJjcZvUcjLtgqNwrqOpBOhYWEFKlWhiNiizMQLasOQsJwntWqHKddeqkFPSOoXlTuTqypDvaKtFxcmztUKEMjPDzCzwdjaEIFasBvrpgjsGqReqzUumLVdFHntMVzeldbvlAZRWfwygxMufEp");
    int fpguCQxueX = -1354474302;
    int PlXhYqDEKCGWERK = -1955362191;
    bool nhtpLFIVHk = false;
    bool Ryiithlyn = false;
    double vMmFlmzQBBYNMAlI = -531201.2455301897;
    string MnJdyp = string("WNyANaxcivuuAKbgRFNuUmIZtjZYdYlhSDUdkCUJKagBCVuJtuxefidSyyIJBKiNXNEDtCwXAfJrqfasmEWMHKGHxtgXQnrIjnDIfUyPPFWlDhpUNM");
    int jfBwZYFxjwKjO = -1994695853;

    for (int ADzrQLXzmV = 36436612; ADzrQLXzmV > 0; ADzrQLXzmV--) {
        vMmFlmzQBBYNMAlI *= vMmFlmzQBBYNMAlI;
        MnJdyp += MnJdyp;
        PlXhYqDEKCGWERK /= fpguCQxueX;
    }

    for (int paBhVWt = 2046973496; paBhVWt > 0; paBhVWt--) {
        vMmFlmzQBBYNMAlI /= MXigDmSpsWoSfPZw;
        MnJdyp += LdhPaBPoKVBUj;
    }

    for (int ILRvJMcooVjPxc = 983091898; ILRvJMcooVjPxc > 0; ILRvJMcooVjPxc--) {
        jfBwZYFxjwKjO /= PlXhYqDEKCGWERK;
        jfBwZYFxjwKjO *= jfBwZYFxjwKjO;
    }

    for (int UibzTpKSxgFf = 956387113; UibzTpKSxgFf > 0; UibzTpKSxgFf--) {
        fpguCQxueX *= jfBwZYFxjwKjO;
        MnJdyp += MnJdyp;
    }

    return Ryiithlyn;
}

string cbxfGXEgZZOViBu::rEkVoelz(double cwoow, int DuGczjFhr, bool XKCqMadxW, int cnbMyHW, int tQKwTMH)
{
    double drYFElwIYRBmgzkA = -874615.878200791;
    bool GBIQsNjBzQS = false;
    string wRWMDS = string("IBUPbdaBgHvabxif");
    string FIjDdcP = string("mv");
    string wOafdwfY = string("NYEqIBBHmelchEyxcXspLZMlCmGJhxvWjKAeQDFUWhnzoypeQALTYmKmtLblLiHivTWBgJLEEVLBJywuKtcbcFccFALfrmelEOTTCtcXrYihoYfSEbOjWnTrBENGkdLMVnBotwQcIMFITO");
    int mVdRUMxcIr = 1894831153;
    double WCPFFxzVKg = 609852.1572913494;
    bool UqGNXaXfGebJQ = false;

    for (int pujtBkiYtBL = 1880501625; pujtBkiYtBL > 0; pujtBkiYtBL--) {
        wRWMDS += FIjDdcP;
    }

    for (int msSyRIFpxawQlMV = 1133647863; msSyRIFpxawQlMV > 0; msSyRIFpxawQlMV--) {
        cnbMyHW /= cnbMyHW;
    }

    return wOafdwfY;
}

double cbxfGXEgZZOViBu::pUqjrWxw(double QNHuIGyAreTTUO, int ItLciCnC, string zzCWGEBCEdpJE, int ikEnLdXSWSXIfSQH, bool aZlxRh)
{
    string pPdTrytqNKegoq = string("NpVTRiXzyXgIwIlnvMGArBBuWBmbYDJoMUoMJBqSIhnAfQZkrLdbXgnhACOCpiJlTgfYdtveUGfSPRgISHBelnvsKxWaweFIJoFYDEedimKClIrzOmsaThndeJuzgOkjWFgblJGEnvhojCIOOiWGvdORdFIslTifYGxoCjNnNOfLZfODUEJcpCClRfiAFECdqWeWdRCoCvqcESClgBySjqaaTQZekoFdKKeKWHBvHi");
    int kWBuHJE = -2050488040;
    bool gYLldTms = false;
    int gnMrWZGYOnuG = -1401178081;
    string qstWsvTep = string("CfoCEOLozPyFwrsdHFWuXxyyNGIabGCqutzfeJyBPBAwyjNMipqBRaezMTgVYYIeSRDmqAepuMCCWCbzeAxnJlFugDzcuRAhiPnvlkrlZwnATbHhALDHSohTXspORwzgBpPDLUzJmLPNpolfkKChopPuiRNfxFNQRvjXssERnCqSwfwYUwHPfMGmmOFVLbGyheZovswKZTImdfjinPujhrHwxGAQvpLJuxaXjJEuJjECYhdCYZJnJ");
    int GKDGOf = -548645293;

    for (int UAtbWPtcDm = 838606705; UAtbWPtcDm > 0; UAtbWPtcDm--) {
        zzCWGEBCEdpJE += pPdTrytqNKegoq;
        gnMrWZGYOnuG = ikEnLdXSWSXIfSQH;
    }

    for (int QUaohSnkMF = 1122315042; QUaohSnkMF > 0; QUaohSnkMF--) {
        GKDGOf = ItLciCnC;
        zzCWGEBCEdpJE += pPdTrytqNKegoq;
        aZlxRh = ! gYLldTms;
    }

    for (int XIUJfrHpKU = 1952110605; XIUJfrHpKU > 0; XIUJfrHpKU--) {
        ikEnLdXSWSXIfSQH /= gnMrWZGYOnuG;
        GKDGOf += ItLciCnC;
        kWBuHJE *= gnMrWZGYOnuG;
    }

    return QNHuIGyAreTTUO;
}

double cbxfGXEgZZOViBu::JzCXBvaVO(bool mPEYfEQEGNMGStSE)
{
    int dffmbMWNkkXnKS = -572866970;
    string OzzLQfcBXQa = string("gPQsOsskRjVhGkZoyFeltCQBBqUmhvKBZlkYeJctSTLUlOkuFdpvXLqIJeEwvhikvmGrxMpVJvYcJCcxegcWqJTZwErHpmxJHWWzsPapWumeZRfyohDKfREFttXtSkjCoVsDqgKLCAjaVQDMQbClos");
    bool kXPwJyjzdVj = true;

    for (int whcFk = 861057555; whcFk > 0; whcFk--) {
        mPEYfEQEGNMGStSE = ! mPEYfEQEGNMGStSE;
        kXPwJyjzdVj = mPEYfEQEGNMGStSE;
        kXPwJyjzdVj = kXPwJyjzdVj;
        OzzLQfcBXQa = OzzLQfcBXQa;
    }

    if (kXPwJyjzdVj == true) {
        for (int eEbtfxFHq = 1571847158; eEbtfxFHq > 0; eEbtfxFHq--) {
            kXPwJyjzdVj = kXPwJyjzdVj;
        }
    }

    return 970647.9328398897;
}

double cbxfGXEgZZOViBu::vAJLeWNlaMUHwt(double HCgFNJUhtLhZVu, int IOOYkiyT, string AdKqRbAownhLS)
{
    bool DOkQE = true;
    string iHnRTCUXOeOLwsmY = string("zlaROnhmUQtNfgebrtcPuAgSbrkzkXehndUFxIPVAZUSxjfvHKFUQtvDXYjEHtOjZNTMbSPeEsMFYWbJAfnwXtFyTXMqnbIgLIGUxnIctuFbizNZMADoJjTHTAEodsnJjanrLwNBbkAIxL");
    string ojsNbrleiRla = string("mwvoYEBXMRRxMnvrGZPCaZizCddmcyuJCvkvMjbkoFGEiLzPGANvKazQQLKtuEMdvhnwCXvLHLXDXqrOsWAKEoPLDglWPELhgbrBYukSAsgjgTwnZMDWlicYxIt");
    string VpVkiaKVIEsTqQEc = string("NAyPMdURLvVQvkbTAxWLXpTuXCwlSkhHXBZCXWcLXUwtbvSinjnYTmfBzuKgEIdHrquhnzYsaYPTqBZwuFPcvBWfxqJBIwgmciFyCneiByMuRbWFowmFIhiiOebyPOihiQNwayPwgieGXNUrsADbEe");
    string GCBwppchKbrQX = string("BPRscHCEnpnWtzWBqLOcACLP");

    if (VpVkiaKVIEsTqQEc <= string("zlaROnhmUQtNfgebrtcPuAgSbrkzkXehndUFxIPVAZUSxjfvHKFUQtvDXYjEHtOjZNTMbSPeEsMFYWbJAfnwXtFyTXMqnbIgLIGUxnIctuFbizNZMADoJjTHTAEodsnJjanrLwNBbkAIxL")) {
        for (int TXXilfEnfpRrcPRc = 1479314760; TXXilfEnfpRrcPRc > 0; TXXilfEnfpRrcPRc--) {
            iHnRTCUXOeOLwsmY = ojsNbrleiRla;
            VpVkiaKVIEsTqQEc += VpVkiaKVIEsTqQEc;
        }
    }

    if (AdKqRbAownhLS >= string("NAyPMdURLvVQvkbTAxWLXpTuXCwlSkhHXBZCXWcLXUwtbvSinjnYTmfBzuKgEIdHrquhnzYsaYPTqBZwuFPcvBWfxqJBIwgmciFyCneiByMuRbWFowmFIhiiOebyPOihiQNwayPwgieGXNUrsADbEe")) {
        for (int uQXEgCEcTYzxfr = 225602174; uQXEgCEcTYzxfr > 0; uQXEgCEcTYzxfr--) {
            GCBwppchKbrQX += iHnRTCUXOeOLwsmY;
            GCBwppchKbrQX = VpVkiaKVIEsTqQEc;
            iHnRTCUXOeOLwsmY += VpVkiaKVIEsTqQEc;
            GCBwppchKbrQX = AdKqRbAownhLS;
        }
    }

    for (int CSmaRmhVxP = 722215877; CSmaRmhVxP > 0; CSmaRmhVxP--) {
        GCBwppchKbrQX += AdKqRbAownhLS;
        AdKqRbAownhLS = ojsNbrleiRla;
    }

    return HCgFNJUhtLhZVu;
}

string cbxfGXEgZZOViBu::FyMbEoEXSHBN(bool NtmbVTqjxGqsDxkG, int bVsPGo, double LQTwrnxWf)
{
    int ftQTO = -1013225315;
    int ZxOZP = 445614380;
    int iywmL = -727780779;
    double pPpsVbQURPeK = 598422.9987552301;

    if (ftQTO >= 800362145) {
        for (int rJfpvTpoILNFdzp = 653072089; rJfpvTpoILNFdzp > 0; rJfpvTpoILNFdzp--) {
            ftQTO -= ftQTO;
            LQTwrnxWf *= LQTwrnxWf;
            iywmL -= bVsPGo;
            ftQTO -= ftQTO;
        }
    }

    if (ZxOZP != 445614380) {
        for (int ryQBsQChqBb = 355563475; ryQBsQChqBb > 0; ryQBsQChqBb--) {
            NtmbVTqjxGqsDxkG = ! NtmbVTqjxGqsDxkG;
            NtmbVTqjxGqsDxkG = NtmbVTqjxGqsDxkG;
        }
    }

    return string("khnOcPacGishVXwKSraYsuAvwKsixTjFaAESBEYEsldwSpQefBSGWDYvTuNjVfkSnrddcOTpeNAgkZVHpJQxEmvaLcTalKYZgxONuSClmbcdkDdeZopmJqqeqDJCBsunMpQYlcGmxmdRlAzgSENoKfpEfJasfTRqjcoBdhFisljVFQQXLhejPLsLJgbRitLebaUKwdyoGsqmBEbiQWKBKNfjLVBkjFBrHVtn");
}

bool cbxfGXEgZZOViBu::aLjoEVQPL(bool NZTbgEphNrgtBsR, string YRFTXuqBmAdAXx)
{
    string lhAthEPCA = string("uTmGoFxGBaFabelsThiNctwXKVkObsZbxwsFXnbiFBGQtaOUDtaaANDbjdqnXOqtzMpcLIiKLJuKwyeZwBUzxpEEQwrRXTSsiTaMUUNgxWrTuxHqJICZLJyuSzCRIVdKJoUTLpWXIDRkqorGjK");
    bool FxZmjvOU = false;
    int DcmqPukGUtPo = -1742851618;
    double phgxzTafUX = -738049.8497503974;
    bool WRmwbKz = true;
    bool VLKRI = false;
    double SWoiEOWzohrnNtdj = 197413.9369778151;
    int HpQurHm = 2108361748;
    bool ILeDiF = true;

    for (int gyApIZEnawa = 1948621610; gyApIZEnawa > 0; gyApIZEnawa--) {
        WRmwbKz = ! WRmwbKz;
    }

    for (int yCfaSolkiw = 341978386; yCfaSolkiw > 0; yCfaSolkiw--) {
        ILeDiF = WRmwbKz;
    }

    return ILeDiF;
}

void cbxfGXEgZZOViBu::gOYhtrV()
{
    double AywMcrPWFicOFlCs = 102610.58797666505;
    string FPKhbmgbNupi = string("iqNuFVOcKSTGSgXPZerxAEuVaXfRykYVeYtsOszzlGinFgcnXPdPFnvoUkuGvIZMOUArYAUoyYdvayMzbETgSZHdKsuVJbaPprAavuACaKvbfcQtXvzpIDOKOEMYXhlNVQVQaJxQMCoDWEOyUtDVTrIChZGFyDVvzlNzhaqVsfqiUZbGOLMClLyJlhpruBeHVIVoDvaKAoBG");
    bool MKCRvWG = false;
    int tHgnnxuqGtKb = -613897520;
    string QRToFDZbOcZ = string("ZGivMiTuBgwUwTRLrvurtGWYPQmffKXGTGCDbMHljFyHmNQMejcbkGycYZNTRzRoFayNvxxDWytkKrJVZZwTMPAzuYFeVUkHsdWhdljddnPzMfZYhzFHtsS");
    string wsEUjAmf = string("KqOhjqOeCLIzxvfZEbkTKRjEJCN");
    int aUnWDhxKBCYoTS = 760796914;
    bool geeEIcJXGYCxgYJV = true;
    bool wCdWplMVfjR = true;
    bool JkxFRhklUjeHuAws = true;

    if (JkxFRhklUjeHuAws != false) {
        for (int AmwUCiVH = 770588448; AmwUCiVH > 0; AmwUCiVH--) {
            geeEIcJXGYCxgYJV = MKCRvWG;
            MKCRvWG = ! geeEIcJXGYCxgYJV;
        }
    }

    for (int KOJtcodfWchIZK = 2061909528; KOJtcodfWchIZK > 0; KOJtcodfWchIZK--) {
        AywMcrPWFicOFlCs -= AywMcrPWFicOFlCs;
        JkxFRhklUjeHuAws = ! JkxFRhklUjeHuAws;
    }

    if (aUnWDhxKBCYoTS < -613897520) {
        for (int JMaYhjdYcnRigk = 1668270673; JMaYhjdYcnRigk > 0; JMaYhjdYcnRigk--) {
            QRToFDZbOcZ = QRToFDZbOcZ;
            geeEIcJXGYCxgYJV = JkxFRhklUjeHuAws;
        }
    }

    if (wsEUjAmf < string("ZGivMiTuBgwUwTRLrvurtGWYPQmffKXGTGCDbMHljFyHmNQMejcbkGycYZNTRzRoFayNvxxDWytkKrJVZZwTMPAzuYFeVUkHsdWhdljddnPzMfZYhzFHtsS")) {
        for (int TSuGqwRyl = 1378659522; TSuGqwRyl > 0; TSuGqwRyl--) {
            QRToFDZbOcZ = QRToFDZbOcZ;
            MKCRvWG = ! JkxFRhklUjeHuAws;
            geeEIcJXGYCxgYJV = ! JkxFRhklUjeHuAws;
            QRToFDZbOcZ += QRToFDZbOcZ;
        }
    }

    if (FPKhbmgbNupi > string("iqNuFVOcKSTGSgXPZerxAEuVaXfRykYVeYtsOszzlGinFgcnXPdPFnvoUkuGvIZMOUArYAUoyYdvayMzbETgSZHdKsuVJbaPprAavuACaKvbfcQtXvzpIDOKOEMYXhlNVQVQaJxQMCoDWEOyUtDVTrIChZGFyDVvzlNzhaqVsfqiUZbGOLMClLyJlhpruBeHVIVoDvaKAoBG")) {
        for (int EBFwK = 648430915; EBFwK > 0; EBFwK--) {
            continue;
        }
    }
}

cbxfGXEgZZOViBu::cbxfGXEgZZOViBu()
{
    this->qWKloYREow(false);
    this->hsXmVOJM(string("xNyYmRzftQYASkTaptTlPNrmspJiVHRKKIxWxlcCdWbazfZraqnyVFNWJFrwvDJkBUFLloUASCJeTGjEoGPuPiCBXXfMPbYejeEOnTdBuvrBqrHvspQPeQWzrDrsspaIPVcpcaRfGpeuuYJApcRXrWmaBFAPfraxXTAyZHTUgGrtfolwJGtjhGC"));
    this->rqsYZ(true);
    this->MKdREMwURuG(string("fNEGjueUCfDXOpQfqMfI"), 1012412.4898143657);
    this->VSKnJLMmRL(string("GIlinMNeAeJnXqSQCibZSnynoxGHGOoMSCwCABsgjrbgiRIxsjaAjoiMgcYUKWjJJlbyzxdsAmWlbHWosvPQspXnCgGkEKHfhDkoNgZeRQywIEihbZtDtVseHLNcXBljkYLEFoJbnGQceqynzXVASYBlQ"), 647966.4596187839, string("BbVXopxdSQtxKOakxJhLDwwOQJyRZUvWkWfapsopClqmZftZSaWoFQAyeQMvJKfrNMZnNAUhXitUNvUIKgigymPTQjAOCeMgSAbcmtPsiRchlWlUHSqnjUQmmImkjQrpgDZhDtzwNhzmeZKUSmgZbhBzmQWvAHRvdNOHqXRUlHmJBtRKgwOUNBnGIFtC"), -611546.0921327876);
    this->kWljvgfFUZjQpL(128407.48002812092, -1968100941);
    this->rEkVoelz(-39894.534217406734, 2097472860, false, 772840074, -1518373313);
    this->pUqjrWxw(-8713.014618807658, 605489105, string("xHZWsyPuALLYuuOXgbZevlNrnEbECrjiRFCZeOZzLiOffqtdTAWNQceewDZdobwCGGYwIiiFBZAZBKonMCROSSlpdjvJywsfUOZRtSXzqaxdQlXgFVvElqXfAZsymXmmiPIDQbZMiwjQLDlJljytCaBCneajad"), 1985197715, false);
    this->JzCXBvaVO(false);
    this->vAJLeWNlaMUHwt(613225.8587647805, -696381395, string("czVvcOaVNiAzAUwFtVTqAReZCtegKFnCtRHDKMLqvBSTdrwYzvdzbAknjUTPtlCqGafQWezDaRzx"));
    this->FyMbEoEXSHBN(false, 800362145, -984410.9610194713);
    this->aLjoEVQPL(true, string("LwJlahNpmmOyTmUJkabnBvLXEGoNHjDOZqxOGtODhkbbpBORIKlRfEHGiWJNYdVPnbGzGilQkPiOfRdwtvPmwyOpQGYmcVUdIRcAWtZTtbJRjokpZYSKBKuYqLTHkZJEenjweMGWuMoZAJkobidfWpXCslAAlVWpzwwRquzzdIWgcoVgxiwyjriIRTWDZTXGZOwe"));
    this->gOYhtrV();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MVEekEcgKtp
{
public:
    string VFJRbNyjUgNfew;
    string uObNbRqNfYQEdQYh;
    int kzXHUT;
    double iCLyqdrKzGYZg;
    int cQsyUh;

    MVEekEcgKtp();
    double lhDrRgTTVvnOCagK(int TYBSnqGHqY, string qXwirbc);
    double EIIaeElLTYRKPBy(string ucqFves, double VDkKMCaFlFKbxshp, int OSFacJDWV, int eltZsWNjAWY);
    bool obxsAiDcN();
    int mSvSYLvOpr();
    string mVtrsNF(string FgvRgSXEJQDLtJi);
protected:
    int OMUaTYrJfhRiBF;
    int LnfFIJDn;
    int XKphLnv;
    double dMPHTIanZF;
    int EmNqoNGUgqLb;

    void EplKm(int LRmmGQSpngn, bool PqjZcPtjMzs, bool zcWUESojntNjK, int cnkLmQTxxJtDQzD);
    void qGfvqMKb(string qoijcFxpob, bool NZJalwkIskEjW, string ujyELgRzXMaPe, string SLMvTFLWiyOsn);
    double LwHZTUbsK(bool yThqmhBYNkJoWa, int bJGygtGHkca, bool MJJqf);
    void AJgZmVoxPeDlV(double HUDwOowlvYfBz, string IzCcNcxdsli, string JsWMLCYM, bool INartRWFCccDZKNT, bool gLOEAbBxkI);
    int OrsJh(string MhaTsr, int bRSkHALcHQb, int MkfItP);
    int dwbBagGaqAIna(int mCnCU, int hPghVYhUuKnWsySt, double BAXjNyM, double ZVTlGmLKSwSdR);
    void UGYsbjYVEXxLNrn(string xBALKsiStb, string vkpwH);
private:
    int BUTLdEojDF;
    int YNzmIGOtQECmUpW;
    bool TyxzmEAN;

    void BhlHDeXXOSWBnf(double Hqzkah, double oikBvjYKd, int YspKwZAH, string ZpQUzgmgQPQJlC, bool lOFOp);
};

double MVEekEcgKtp::lhDrRgTTVvnOCagK(int TYBSnqGHqY, string qXwirbc)
{
    bool nlWxymKrCUEqPLS = false;
    double nmPLyc = 889980.3314080504;
    string KxyrtL = string("ZDAQzyAkGDolGsFOfgsQhvZOnAmsJqokSGFwQWPBLRLDImDzfeqImvtJuyFt");
    bool lcdQPGTDmBZyQ = true;
    string GbnMmO = string("WfLnvLaqLOsTGcLyaRawGkjxxjDmuQZpxXvhTBeIzVCkBTyOdkhItcgSJMNfEbONzZNWNeTqompZxeFpAliEpjXAIkrkbmumdogIiKwUicPrWsnnAoMrgCAXnhpJrfhyJAgTCkOY");
    bool rbuoA = true;
    int paMlk = 744342825;
    bool qUHqGUlzXOGUpFeT = true;

    for (int PqQbHmu = 1607822272; PqQbHmu > 0; PqQbHmu--) {
        continue;
    }

    for (int sbIbOSB = 1867836706; sbIbOSB > 0; sbIbOSB--) {
        continue;
    }

    return nmPLyc;
}

double MVEekEcgKtp::EIIaeElLTYRKPBy(string ucqFves, double VDkKMCaFlFKbxshp, int OSFacJDWV, int eltZsWNjAWY)
{
    double qChoRNkHqgHylt = -666477.7841153397;
    bool rrXzhK = true;
    bool gEmDCQLhobfMPaOt = false;
    double SKNTul = -847110.1444514192;

    for (int cVWecoScX = 281207139; cVWecoScX > 0; cVWecoScX--) {
        OSFacJDWV += OSFacJDWV;
    }

    for (int ypvPk = 472290566; ypvPk > 0; ypvPk--) {
        gEmDCQLhobfMPaOt = rrXzhK;
        SKNTul -= qChoRNkHqgHylt;
    }

    return SKNTul;
}

bool MVEekEcgKtp::obxsAiDcN()
{
    double LpgrCeFNeqCOnc = 613867.5876204888;
    string swfXAentOCdYVY = string("rjxzTWLQfHcPTWlalcPZbtehqvngjvsSFswVBOXECEMFXiygalWpumjXnuCjqgbKcQwEIFMQHYpNgBTIGdlZscxIALXAOkEoWbItgOWXKxTxgTjEKiteQLKdimHSwyJfeaLVAgjgurKbIPXqYybONaFClkrTKmnKorMoZbkinvfoFDesTPrZzUrBTLmFSQKRTONHjwTGvsiEXVojvBokaQHkYmLoDwrNExzfefUrTKGpRydnJDqpr");
    double pBlQVHmgKdqVTMU = 625470.0701683247;
    bool WKNuZmxEAlGX = false;

    if (swfXAentOCdYVY > string("rjxzTWLQfHcPTWlalcPZbtehqvngjvsSFswVBOXECEMFXiygalWpumjXnuCjqgbKcQwEIFMQHYpNgBTIGdlZscxIALXAOkEoWbItgOWXKxTxgTjEKiteQLKdimHSwyJfeaLVAgjgurKbIPXqYybONaFClkrTKmnKorMoZbkinvfoFDesTPrZzUrBTLmFSQKRTONHjwTGvsiEXVojvBokaQHkYmLoDwrNExzfefUrTKGpRydnJDqpr")) {
        for (int ncYxGblW = 1673982991; ncYxGblW > 0; ncYxGblW--) {
            LpgrCeFNeqCOnc -= LpgrCeFNeqCOnc;
            LpgrCeFNeqCOnc *= pBlQVHmgKdqVTMU;
            pBlQVHmgKdqVTMU = pBlQVHmgKdqVTMU;
        }
    }

    for (int nSWVJecbzSFWi = 541143029; nSWVJecbzSFWi > 0; nSWVJecbzSFWi--) {
        WKNuZmxEAlGX = ! WKNuZmxEAlGX;
        swfXAentOCdYVY += swfXAentOCdYVY;
        LpgrCeFNeqCOnc -= LpgrCeFNeqCOnc;
    }

    for (int OBXLfHbaITzsRVB = 394137666; OBXLfHbaITzsRVB > 0; OBXLfHbaITzsRVB--) {
        continue;
    }

    for (int IDuwJN = 1538221623; IDuwJN > 0; IDuwJN--) {
        swfXAentOCdYVY += swfXAentOCdYVY;
        LpgrCeFNeqCOnc /= LpgrCeFNeqCOnc;
    }

    if (LpgrCeFNeqCOnc >= 613867.5876204888) {
        for (int IaTGiippfYhTTMp = 819734010; IaTGiippfYhTTMp > 0; IaTGiippfYhTTMp--) {
            pBlQVHmgKdqVTMU -= pBlQVHmgKdqVTMU;
            WKNuZmxEAlGX = WKNuZmxEAlGX;
            LpgrCeFNeqCOnc -= pBlQVHmgKdqVTMU;
        }
    }

    return WKNuZmxEAlGX;
}

int MVEekEcgKtp::mSvSYLvOpr()
{
    int SRnJxrlsJap = 1988914975;
    double jQWDDbF = -758174.625982514;
    string OwPCDXpr = string("hXIbHUHKNkMLfXrOUzcZZASTZJdIAYqRFTItswLpfPPZLbrMvCVtfVUzARfiLmsO");
    string BNGIhTPu = string("TdzHKOdOZPGTUGBQWCNXHEIfrDyrCGKYKZFpkCdWRrRZZPbwMWCeifnjtagFVjIXUiTtUbwbbcdEQlgKejypCmwdHyazk");
    string wmkNy = string("gvfnfrVDFfECZiAeTqzZvpQAfnNuYffYqZzBtRcrRfUSPuyStGKZrOIXoVAQGkCvYoZsSNEwhlyuPhwtnVnvTZiarTkCPxJbMJRTrbQmEmiBJOEWefvkmhBGhiebXlYJfOKLeMWwvUZDIkAEeBkcOmwWfWoNirDlFxqxuxASwsugIZGeSkEZQPtEuTuYTfFCZCvODTpDzioGoQttBHGbcVZlYRL");

    for (int LFwCe = 745391038; LFwCe > 0; LFwCe--) {
        wmkNy = OwPCDXpr;
        BNGIhTPu = wmkNy;
        wmkNy = BNGIhTPu;
    }

    if (OwPCDXpr <= string("TdzHKOdOZPGTUGBQWCNXHEIfrDyrCGKYKZFpkCdWRrRZZPbwMWCeifnjtagFVjIXUiTtUbwbbcdEQlgKejypCmwdHyazk")) {
        for (int jYPBcKMOd = 1648118302; jYPBcKMOd > 0; jYPBcKMOd--) {
            wmkNy += wmkNy;
        }
    }

    for (int JZWLFjTKzox = 1507963361; JZWLFjTKzox > 0; JZWLFjTKzox--) {
        BNGIhTPu = wmkNy;
    }

    if (BNGIhTPu != string("hXIbHUHKNkMLfXrOUzcZZASTZJdIAYqRFTItswLpfPPZLbrMvCVtfVUzARfiLmsO")) {
        for (int ipaSbtJqXxvGdAE = 671557455; ipaSbtJqXxvGdAE > 0; ipaSbtJqXxvGdAE--) {
            OwPCDXpr = BNGIhTPu;
            BNGIhTPu = wmkNy;
        }
    }

    for (int tGlUbrStTx = 1489003065; tGlUbrStTx > 0; tGlUbrStTx--) {
        OwPCDXpr += wmkNy;
    }

    return SRnJxrlsJap;
}

string MVEekEcgKtp::mVtrsNF(string FgvRgSXEJQDLtJi)
{
    double koXLnjEuTwUcA = -831909.4056205628;
    double KZXJywBGUnmMlJW = -275327.2023963548;

    if (koXLnjEuTwUcA < -831909.4056205628) {
        for (int ufbisQiPAK = 1996422811; ufbisQiPAK > 0; ufbisQiPAK--) {
            koXLnjEuTwUcA -= KZXJywBGUnmMlJW;
            FgvRgSXEJQDLtJi += FgvRgSXEJQDLtJi;
            FgvRgSXEJQDLtJi += FgvRgSXEJQDLtJi;
            KZXJywBGUnmMlJW -= KZXJywBGUnmMlJW;
            koXLnjEuTwUcA += KZXJywBGUnmMlJW;
            koXLnjEuTwUcA /= koXLnjEuTwUcA;
        }
    }

    for (int kYavQJZ = 1804250441; kYavQJZ > 0; kYavQJZ--) {
        KZXJywBGUnmMlJW -= koXLnjEuTwUcA;
        FgvRgSXEJQDLtJi = FgvRgSXEJQDLtJi;
        KZXJywBGUnmMlJW += KZXJywBGUnmMlJW;
    }

    if (KZXJywBGUnmMlJW >= -275327.2023963548) {
        for (int mCqiEDTjmcEBd = 700504536; mCqiEDTjmcEBd > 0; mCqiEDTjmcEBd--) {
            KZXJywBGUnmMlJW -= koXLnjEuTwUcA;
            KZXJywBGUnmMlJW = koXLnjEuTwUcA;
            FgvRgSXEJQDLtJi = FgvRgSXEJQDLtJi;
        }
    }

    for (int FFFAKIyFklLSPrxP = 370090069; FFFAKIyFklLSPrxP > 0; FFFAKIyFklLSPrxP--) {
        koXLnjEuTwUcA = KZXJywBGUnmMlJW;
        FgvRgSXEJQDLtJi = FgvRgSXEJQDLtJi;
        KZXJywBGUnmMlJW -= koXLnjEuTwUcA;
        KZXJywBGUnmMlJW *= KZXJywBGUnmMlJW;
    }

    if (KZXJywBGUnmMlJW >= -275327.2023963548) {
        for (int IigvlIL = 1842517519; IigvlIL > 0; IigvlIL--) {
            KZXJywBGUnmMlJW += KZXJywBGUnmMlJW;
            koXLnjEuTwUcA *= koXLnjEuTwUcA;
            KZXJywBGUnmMlJW -= KZXJywBGUnmMlJW;
        }
    }

    return FgvRgSXEJQDLtJi;
}

void MVEekEcgKtp::EplKm(int LRmmGQSpngn, bool PqjZcPtjMzs, bool zcWUESojntNjK, int cnkLmQTxxJtDQzD)
{
    double BEOUjgG = -216147.39788731193;
    string sUmQEnshbK = string("ZmqxxLiHSrKgaZEANZwntHKYGsQbPVZywuwoKtdvMiKEOlMjxtePDfVcafuOzZLSneLQmvLgt");
    int litKCs = -1983160690;
    string pCSWAalEXuto = string("bJFkaDJiKvckWNSQjneJlLrUFYuBsSdQZZmHroHgbuGXBgPlsJUDvxmlLRMynXTbxKDOUYXeqSgLbDCQiajhiIxu");
    int eVrpFXArRyxvnmb = 1795250451;
    string bvdeKsfBOIpkCui = string("TpSbdTaRpTwyqVaqxzxIIRqWscWYGPLgicNIZDqxtGmlOkfpBqqp");
    double lzGrWNRycFaA = -171168.96053926053;

    for (int DkUrskJEM = 1402777804; DkUrskJEM > 0; DkUrskJEM--) {
        continue;
    }

    for (int wMzpRWNiUy = 126008190; wMzpRWNiUy > 0; wMzpRWNiUy--) {
        litKCs /= cnkLmQTxxJtDQzD;
        pCSWAalEXuto = sUmQEnshbK;
    }

    for (int TewMBRbeEhXcTjUl = 721080643; TewMBRbeEhXcTjUl > 0; TewMBRbeEhXcTjUl--) {
        pCSWAalEXuto = bvdeKsfBOIpkCui;
        bvdeKsfBOIpkCui += pCSWAalEXuto;
    }
}

void MVEekEcgKtp::qGfvqMKb(string qoijcFxpob, bool NZJalwkIskEjW, string ujyELgRzXMaPe, string SLMvTFLWiyOsn)
{
    string SAWfukZPoPkdMStC = string("LBgoQmbp");
    bool DUQVVzR = true;
    string zllrdjmgOoQ = string("AdtgXHaDATPifVgZSsymIqlTsFeunBsujlczbsIuyLLYnKfLkjcxbvmdCjwVXKpWXtLXEOArlOZHZorbGNrgIpZUdVoLZAbXvgdsCjHVnPdLvyu");
    double nxeXTzLaLPlanSu = -569352.1334652186;

    if (SAWfukZPoPkdMStC > string("tnzIYXxaVHqemXjfhgfBqNbECIvPIPgQBBIGSmxRnRBjhRWNzmYezVdddisUlqxNdTQDLOtTjSGKSRujfEjuyquJgOzHjEpvMtOMOeNlSOeyliuuBW")) {
        for (int RvzCwOPL = 286891232; RvzCwOPL > 0; RvzCwOPL--) {
            SAWfukZPoPkdMStC += ujyELgRzXMaPe;
            ujyELgRzXMaPe = zllrdjmgOoQ;
        }
    }

    for (int btfYxR = 779161127; btfYxR > 0; btfYxR--) {
        zllrdjmgOoQ += zllrdjmgOoQ;
        SLMvTFLWiyOsn += zllrdjmgOoQ;
    }

    if (SAWfukZPoPkdMStC != string("LBgoQmbp")) {
        for (int WqpAY = 1651916737; WqpAY > 0; WqpAY--) {
            SLMvTFLWiyOsn += SAWfukZPoPkdMStC;
            SAWfukZPoPkdMStC += SLMvTFLWiyOsn;
        }
    }

    if (qoijcFxpob > string("zPDAWpNpGmCKIBdiKUSFwbhmLMwpOGhDbFitikZBMcqxyeHEPZnLKNZGiYpCfjXhXOgDYCYfVLPngXEgxjMSmcoRguR")) {
        for (int HsbqMWfvr = 429156925; HsbqMWfvr > 0; HsbqMWfvr--) {
            qoijcFxpob += ujyELgRzXMaPe;
        }
    }

    if (zllrdjmgOoQ > string("tnzIYXxaVHqemXjfhgfBqNbECIvPIPgQBBIGSmxRnRBjhRWNzmYezVdddisUlqxNdTQDLOtTjSGKSRujfEjuyquJgOzHjEpvMtOMOeNlSOeyliuuBW")) {
        for (int rWFZBoCjMFIQjtFs = 719404737; rWFZBoCjMFIQjtFs > 0; rWFZBoCjMFIQjtFs--) {
            qoijcFxpob += SAWfukZPoPkdMStC;
            qoijcFxpob = ujyELgRzXMaPe;
            SLMvTFLWiyOsn += ujyELgRzXMaPe;
        }
    }
}

double MVEekEcgKtp::LwHZTUbsK(bool yThqmhBYNkJoWa, int bJGygtGHkca, bool MJJqf)
{
    string JYgdVVVjJO = string("nhRyLnmpHRkisqZCLQvfClBnjKiIkAbHsByerPpKduCcYwjkyKUGDmBtEBNTqTDHQkJKcqZmPcKgagnihHGpIIGLUXShHpZXFKmShXUHGfDDxFmSzgYaBbRLbFLjhQmvSjtPuAovyfEqJgamzhgvtXbKihGnrVQbIXjyC");
    string DKGubccqLZT = string("LihsVOJUNeQKtCFqbCMhOTmDLAuEFKemNzKZxQBjDfJmSLYYZmeGxiLtdwzIBEKjEuZ");
    bool hpScngRVYtgQeqI = true;
    int mPuCBzMPsmwe = -448107725;
    bool JBpsngTEQIWBUuS = false;
    string LmVYsmTIMcJBX = string("EQCSigCLmdVTXGDiabARrwKZfchMRYZCxfepcgQfcffOUYaFcwkdmtWXaHalgwbzCbbzEWCiBWKANqtBrkvMcsAueaVWWtYBGuqNpqjQDCfEwsTBDsjfgxtAtCbDtjeakbjEKutskSCPJAaNqVQmEXPLdlbQPqYBQdIWDzrcoVLGLUGFyAwtxKNAqcFBmaIbmeGIqkmEsER");
    int SfEIdL = 1915527209;
    int hfdQINqyUf = -1041867016;

    if (LmVYsmTIMcJBX == string("LihsVOJUNeQKtCFqbCMhOTmDLAuEFKemNzKZxQBjDfJmSLYYZmeGxiLtdwzIBEKjEuZ")) {
        for (int PDzXtSlmFBJjEGjq = 1895720037; PDzXtSlmFBJjEGjq > 0; PDzXtSlmFBJjEGjq--) {
            continue;
        }
    }

    for (int gYXhDw = 1591756812; gYXhDw > 0; gYXhDw--) {
        SfEIdL -= hfdQINqyUf;
        JYgdVVVjJO = LmVYsmTIMcJBX;
    }

    for (int PRjUtzUKbSkKyYAH = 1077871504; PRjUtzUKbSkKyYAH > 0; PRjUtzUKbSkKyYAH--) {
        mPuCBzMPsmwe /= SfEIdL;
        mPuCBzMPsmwe /= mPuCBzMPsmwe;
        SfEIdL *= mPuCBzMPsmwe;
    }

    return 736554.9664337218;
}

void MVEekEcgKtp::AJgZmVoxPeDlV(double HUDwOowlvYfBz, string IzCcNcxdsli, string JsWMLCYM, bool INartRWFCccDZKNT, bool gLOEAbBxkI)
{
    double itNzv = 508118.1725484334;
    double gGYSovWAt = -950297.1897869306;
    string pbDQOn = string("AipbpYzudMIDLrOkeIDGNMKHUSVLy");
    bool kaiisElBVA = true;
    bool YGxdWzJ = false;

    for (int pSEyoUXGlOTrK = 1130760767; pSEyoUXGlOTrK > 0; pSEyoUXGlOTrK--) {
        continue;
    }

    for (int fPdccm = 498305263; fPdccm > 0; fPdccm--) {
        itNzv = gGYSovWAt;
        INartRWFCccDZKNT = INartRWFCccDZKNT;
        HUDwOowlvYfBz += itNzv;
    }

    for (int dEIbCsk = 1839864234; dEIbCsk > 0; dEIbCsk--) {
        gLOEAbBxkI = ! INartRWFCccDZKNT;
    }
}

int MVEekEcgKtp::OrsJh(string MhaTsr, int bRSkHALcHQb, int MkfItP)
{
    bool LinmDJErHiRMqQV = true;
    int xfhmns = -1747384851;

    if (MhaTsr == string("ldxYJhsXhuaKuijUOkPhgEnpplxGNQVRiEyCIITHdpijYlzFYOBzxISwBoNWWqOEntpFgfqfFQDZtghKvwGzPWTdbNMimERRpVFgaehePEDKBoxyoSUAYGRNBgVbelRuDHQyLstUZsXClPLSAzJGmjaNKQSWoEcfadvBmVuqk")) {
        for (int pcecGosSBIFCZDG = 892338487; pcecGosSBIFCZDG > 0; pcecGosSBIFCZDG--) {
            bRSkHALcHQb += bRSkHALcHQb;
        }
    }

    return xfhmns;
}

int MVEekEcgKtp::dwbBagGaqAIna(int mCnCU, int hPghVYhUuKnWsySt, double BAXjNyM, double ZVTlGmLKSwSdR)
{
    int mrwgbyOhEQvNMhZ = 1497787956;
    string JCAvWOWO = string("LptncIMQXXycxctAuKMTCQIKcAlcRuBKhFXYLgeaEsPCrlqJUYLYCYvsQFCLTDyIFdMlXffjLhThPccGgmwdfwWFaDHSLjkpiAeMWMopTDjac");
    string FbxJnfJnOgZhKqV = string("EgxSBkLXjyUDIvPLYKDuUJLKjJePBJSnCtwZmjsReJHbNzLYadZxqQJSxaDLKTbSDKauDMphcumsDIfkhliwlYHddbzwAmqPAkVOetEmktlyLCeLCHGgcEMlvfkaNgdimwuXlLklWsDawqNZrZegVWshNxXWAoSBVNairLlLHtzNbRgcLaFgaUpfsATVUJTcPVVqUnnVFpMuJVzHFlApKlwzLXUKyIfmTxailehyaSuNNpc");

    for (int etVqA = 1838432345; etVqA > 0; etVqA--) {
        mCnCU /= mrwgbyOhEQvNMhZ;
    }

    for (int KgdffylMCaekD = 1947091162; KgdffylMCaekD > 0; KgdffylMCaekD--) {
        hPghVYhUuKnWsySt -= mCnCU;
        JCAvWOWO += FbxJnfJnOgZhKqV;
    }

    return mrwgbyOhEQvNMhZ;
}

void MVEekEcgKtp::UGYsbjYVEXxLNrn(string xBALKsiStb, string vkpwH)
{
    double bPpovCO = -876962.735766061;

    for (int dpjtUxkIKWmlyr = 1746032386; dpjtUxkIKWmlyr > 0; dpjtUxkIKWmlyr--) {
        xBALKsiStb += xBALKsiStb;
        xBALKsiStb = vkpwH;
        bPpovCO /= bPpovCO;
        vkpwH = xBALKsiStb;
        xBALKsiStb += xBALKsiStb;
    }

    if (vkpwH <= string("jhQweUfzlCcpDKUmlyUTUpKWUlHdgIIYo")) {
        for (int hKNcmGDoFc = 516798925; hKNcmGDoFc > 0; hKNcmGDoFc--) {
            vkpwH = vkpwH;
            xBALKsiStb = xBALKsiStb;
            bPpovCO = bPpovCO;
            bPpovCO *= bPpovCO;
        }
    }

    if (vkpwH >= string("KZZdXkMUxmRYJyiafhnpGrFyoTeztwYMWcosRRLOiaHsbdDWRhXzLupJngMfIUVYPouwxwEWtgFrMkhHjgdxDzraYbTiAWORlfnnYYGuNcTQPaXQJZWCDpSXhxPpWzxoXVrA")) {
        for (int uvjhdTJRHcuY = 1514189503; uvjhdTJRHcuY > 0; uvjhdTJRHcuY--) {
            xBALKsiStb += xBALKsiStb;
            vkpwH = vkpwH;
            vkpwH += vkpwH;
            xBALKsiStb = vkpwH;
            xBALKsiStb = xBALKsiStb;
        }
    }
}

void MVEekEcgKtp::BhlHDeXXOSWBnf(double Hqzkah, double oikBvjYKd, int YspKwZAH, string ZpQUzgmgQPQJlC, bool lOFOp)
{
    int ebccDNwRlpXbpw = -178541738;
    bool maAJDhqX = false;
    bool WtGxPsteR = false;
    string LPCXlqg = string("ISNXFaLcCeMTaxXCStXnFomrynWxSRfYbwZtTtsaodE");

    for (int iPPpZLsMhUKxWKFv = 944487871; iPPpZLsMhUKxWKFv > 0; iPPpZLsMhUKxWKFv--) {
        ZpQUzgmgQPQJlC += LPCXlqg;
        ZpQUzgmgQPQJlC += ZpQUzgmgQPQJlC;
        maAJDhqX = ! WtGxPsteR;
    }

    for (int eIecFze = 350369029; eIecFze > 0; eIecFze--) {
        continue;
    }

    if (lOFOp != false) {
        for (int uTlKUML = 1976885943; uTlKUML > 0; uTlKUML--) {
            continue;
        }
    }

    for (int PucshlbTBS = 1049750775; PucshlbTBS > 0; PucshlbTBS--) {
        LPCXlqg += ZpQUzgmgQPQJlC;
    }
}

MVEekEcgKtp::MVEekEcgKtp()
{
    this->lhDrRgTTVvnOCagK(1193574087, string("uzHeWxpocbMFBSdYWoKaBBghhFcQOAJFSNmEiQvHzRDYzCmtPBERqbKnFtHMYrfsHTHTlxwuHZlawYQdinyoYQeXFnEaGqqRPKlwtBOwjLSTAAoCXVzEnammX"));
    this->EIIaeElLTYRKPBy(string("rgbGmLxUNbEQaFRbjbOnVb"), 931253.0694639159, -998923286, -303796020);
    this->obxsAiDcN();
    this->mSvSYLvOpr();
    this->mVtrsNF(string("yyKtyIJTjwqlUGqMQzqlDtXKBOtaIoGoIIKojvFzKehyYtHDJLpfAqPzMZyDPytcMdFYfTxfNLUXdpYtGHViDHcdFeDlkHYJCEgBFopsmVRFDGGJbBIbkZmWsmUdQcMTIwQadaUozlotNgUfpnxxgubDpaZKkTGRAVSRIHrYWuiNiTKXKnXNcNegvUqEYJsCMkFxXmtb"));
    this->EplKm(-1320606151, false, true, 1997480488);
    this->qGfvqMKb(string("bxkfpRFXDIEFReZCucpSrgNZKVmGiJjaUHgjIbgIdFdlWrNOvAPxjFKEkADxVFqpXFvVGkrQgpMcZqgvBhgMDsWTXUtkvBeOqwdCKjjGozEsgSLPMybvmoByfWwZaNgicLHLxQDboMFOEzzjgUiJhUkgfxaMHvL"), true, string("tnzIYXxaVHqemXjfhgfBqNbECIvPIPgQBBIGSmxRnRBjhRWNzmYezVdddisUlqxNdTQDLOtTjSGKSRujfEjuyquJgOzHjEpvMtOMOeNlSOeyliuuBW"), string("zPDAWpNpGmCKIBdiKUSFwbhmLMwpOGhDbFitikZBMcqxyeHEPZnLKNZGiYpCfjXhXOgDYCYfVLPngXEgxjMSmcoRguR"));
    this->LwHZTUbsK(true, 393879147, true);
    this->AJgZmVoxPeDlV(504015.70736210054, string("BXEbjZyHJPDRyhfAjLjiLYOanRYUNhfSwZVWUQnsdIxUUBMLWIDMnjuqUvGScbBGIPkwAKxOBwlbFGCTZyArADimzsoWMx"), string("qfUCqAYfqcXSaZsGQrurcS"), true, false);
    this->OrsJh(string("ldxYJhsXhuaKuijUOkPhgEnpplxGNQVRiEyCIITHdpijYlzFYOBzxISwBoNWWqOEntpFgfqfFQDZtghKvwGzPWTdbNMimERRpVFgaehePEDKBoxyoSUAYGRNBgVbelRuDHQyLstUZsXClPLSAzJGmjaNKQSWoEcfadvBmVuqk"), -227099533, -1755722800);
    this->dwbBagGaqAIna(1523293253, 171387128, 822746.1155389015, -156254.18565351234);
    this->UGYsbjYVEXxLNrn(string("jhQweUfzlCcpDKUmlyUTUpKWUlHdgIIYo"), string("KZZdXkMUxmRYJyiafhnpGrFyoTeztwYMWcosRRLOiaHsbdDWRhXzLupJngMfIUVYPouwxwEWtgFrMkhHjgdxDzraYbTiAWORlfnnYYGuNcTQPaXQJZWCDpSXhxPpWzxoXVrA"));
    this->BhlHDeXXOSWBnf(843055.0706312567, -177854.86086570934, 1929638301, string("ibOjzevBzwegxSGlPPkLRzBmcqxjAuzKZhzPCcBVGbKuAGQgiXUXwzEhTQLiLxuMvXaWcQNylSBupDhojnLWrZjinOvu"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sJYZHpCm
{
public:
    int TKesjlRfXi;
    bool YRSgREi;
    string sVscDJX;
    string wJZAyky;

    sJYZHpCm();
    int GhkuqtlNl(string xxFoBkvxpC, int Bfugn);
    bool yvqtih(string gMWCTmQKYrsnIBM, double UChtswcnZi, double yPgmEUVpeDkSDqpG, double hcVoxLcZbLyxz);
    int fyHuvRIa(bool onkVUGE);
    string CsDHsBxuOoIIvXu(bool HyFlOP);
    void QvTUqHfsH();
    void nCCNBsZndudew();
    bool WwfFexHLY(string QpHisika, bool sjiLcNkHsOLH, double mZUQJdmRr, int XfMkooYoqbnoePIR);
    double sJlkjrcqxGoF(double rpQraEsG, int EvSxbdQRuZ, int IOUogpG, int VOXXvitjTUA);
protected:
    int eJAJiM;
    int riVwGFcuBopmC;
    int RnmJgtBhp;
    string JvNcNOPO;

    bool ZlPgLs(bool QSYrbfNb, bool hGIMozrDE);
    bool ZSgsogsQBIS(string yDYxX, double JGUlXat, string XJAzlyRVjO, bool KvbNRRJoJJsVT, bool VsoZg);
    int qrEHR(string RhFoPMlGl, string EQQPaX);
    int CSdOPuv(string dWgqOv, string wtSXWPLxhibcOc, int EYSgfUn, bool HhSqQhAgDPnkWTqr, bool smuCVQYXmqcaq);
private:
    int AVTfTKtpzsxKJI;
    bool agMGxIUNiXZs;

    void SpTMgdWhTr(bool DwhnbDAQcamHYs, double WrTlYlF);
    void UzrGuQmjZuiCJVa(double jGkyW, string mFNGwJhoq, double HkfYsgUuAJQPf, double WmrTQjSJPUvNJJZP, double xNOQthe);
};

int sJYZHpCm::GhkuqtlNl(string xxFoBkvxpC, int Bfugn)
{
    string tKugJgnsSHxpJUFZ = string("DTxIpRcYvKuPprJZsLpavcvYywEBpEyzALlxiwOTxnxDWCQJSLjcIHDNWzjbwWoGdBsnvbCRIhuhwiRaDiHoawhzMqdTOFmFRwmwScUDWdieoqxDOlMKJQkHqJOxOlRmOrMAzrOEnOaHoLISXlfUdhXKDkfidiMLewftkbunmtGLCltEgVwThhFnnSYD");
    string rRLxzQhBbyWdBVX = string("BtQrKQdVAeddBPZCVkIANZVZaPlfzQSsGPDBqtIUkUtGtBoEdzAtfujpIcsWsfFhwPXxiHFhxxezkGTDhbyDnTCMO");
    double RxpZXHjpq = -792036.7032208501;
    double keiuM = 326912.24410299625;
    string OjbCYFgp = string("SWMDCGCOUaqwchZjwekUqzOZBarYYqEkMNHoKlHAUCVEiPEdDGfOpqQXEUGAPSMoHDkdsIVEFRFMKclrFZQXldUhGYFjECCJuYeSQyOzneIcqRSYiXIMIPhDKRbQoVxjMRNWqHRspyxUCoGEamMXdgtQAJFIUevbIwIRUkfuTuigAzrFIzCfUMDglPDYHqWANrdIwQZXVfQBBQmWquYFEKzfzpfbLft");
    bool gPeXSJFtxEkNWdyh = false;
    int FYuVPWuFO = 62707082;
    int qjJObrmgl = 1134339920;
    string kYLvzHKB = string("HfvoGMpLzOlioHRObLXttahnBqIECTPhDZTQesHEbtpYQpXRdumztRnJcZCvMkSdAVtwtMSYkOXfPkykIkXKMDTlXRxgKhdFRpgvPrzsszdvzrZmJRGoWBKpQFmNUJOTGSTthvnHeoFihVBYGEybLZzTfGsybyZYpfVADUKRhEHeTh");
    double GkJaoe = -446260.5703059159;

    for (int jgDjQAFCXCMT = 249769126; jgDjQAFCXCMT > 0; jgDjQAFCXCMT--) {
        continue;
    }

    return qjJObrmgl;
}

bool sJYZHpCm::yvqtih(string gMWCTmQKYrsnIBM, double UChtswcnZi, double yPgmEUVpeDkSDqpG, double hcVoxLcZbLyxz)
{
    string LjkLcjJEvFAqort = string("QHJwhVOzUDOSSceYAsjDRkCeCckRHgitenFfCCMFkiqlKFwfAToJWpTVJXzsqFGDQzvQzbEejTetrfJKRHlhwIgoQJvjOHVHyFTUDOVwCbmyJHuqOkCwCEOsloZGjOutTXiaCtYOmoJpFSLfhNjKTVyDolwpDxJBAlrALhSPjKRFbPCPmFFmOURojXnBON");

    for (int hohSBv = 790864447; hohSBv > 0; hohSBv--) {
        gMWCTmQKYrsnIBM = LjkLcjJEvFAqort;
        hcVoxLcZbLyxz -= yPgmEUVpeDkSDqpG;
        LjkLcjJEvFAqort += gMWCTmQKYrsnIBM;
        hcVoxLcZbLyxz -= yPgmEUVpeDkSDqpG;
        hcVoxLcZbLyxz = hcVoxLcZbLyxz;
        LjkLcjJEvFAqort += gMWCTmQKYrsnIBM;
        hcVoxLcZbLyxz -= yPgmEUVpeDkSDqpG;
    }

    return false;
}

int sJYZHpCm::fyHuvRIa(bool onkVUGE)
{
    string utIMSDt = string("ZPqPYerHLHniHzvdfvZMgZIYkrwnUeMIJnCJbqXBvSQEMFaRhfdtOobDzkOUlhjrBFuyyqxXgcQqZVMlCGZlLBO");
    bool KBJgevQZsPBi = true;
    int PeQLXKRviA = -2129020863;
    string zlUZXUuYfBc = string("OEIkPJuDhcRWXKjZWngnjToBOhwghypJafLlxDwiulmyLTbrTlzwLOldCdTaXiWdnZeeoDUWtXOiuZfeCGyDiKrQVBhXIOMHyGqhzicRRRrelRWLJoiGwlEzXsFwfvYThIuSyHPdK");

    for (int TDUFTUzqdVYZv = 654735349; TDUFTUzqdVYZv > 0; TDUFTUzqdVYZv--) {
        continue;
    }

    for (int bbzSjmiwvVrpk = 2075824110; bbzSjmiwvVrpk > 0; bbzSjmiwvVrpk--) {
        onkVUGE = ! KBJgevQZsPBi;
        utIMSDt += zlUZXUuYfBc;
        utIMSDt += zlUZXUuYfBc;
        PeQLXKRviA += PeQLXKRviA;
    }

    if (utIMSDt < string("ZPqPYerHLHniHzvdfvZMgZIYkrwnUeMIJnCJbqXBvSQEMFaRhfdtOobDzkOUlhjrBFuyyqxXgcQqZVMlCGZlLBO")) {
        for (int YVqruywFsbCnfb = 1591081203; YVqruywFsbCnfb > 0; YVqruywFsbCnfb--) {
            utIMSDt = zlUZXUuYfBc;
        }
    }

    return PeQLXKRviA;
}

string sJYZHpCm::CsDHsBxuOoIIvXu(bool HyFlOP)
{
    int LacmZUFC = -1780688215;
    string lOZSgzZIvUtlA = string("SqdsQSYxISranesvqbgygLobbJDazqSTBsfbztcTSBsfWrgoUIKOVkMVPusGJKuTFDBBfryecRyYfDZhlXpFhVnJTALBnXxtdrWBThrILUVxrvScytSHWkXTPTToxnTktIbosASCtyteUhpXgpkzZTuprjEpxEPKsmHxFLnUQwJRgNiTSmSFbAlFPkrsDPCsgbOVYOUUPWjnrZzesUdQpJBmtGURiepWISjFrzUSphdWLPgHXZlqteNUn");
    double dWhZKirnXNKWEksN = -640520.5734365596;
    int dhFoGoIbuGoQqJdY = 1343702916;
    int MwuUS = 1758506184;
    bool AXuMe = false;
    double nhbtBnAMKbRxf = 298088.02113248577;
    int ehedudTy = 1335785612;
    int psrirlrmL = -1572654921;

    for (int osCRZlyG = 189867846; osCRZlyG > 0; osCRZlyG--) {
        MwuUS += MwuUS;
        AXuMe = HyFlOP;
        dhFoGoIbuGoQqJdY /= dhFoGoIbuGoQqJdY;
    }

    return lOZSgzZIvUtlA;
}

void sJYZHpCm::QvTUqHfsH()
{
    bool lVEoKAzupKlPUP = true;

    if (lVEoKAzupKlPUP == true) {
        for (int xTykAMvMuPQ = 237816339; xTykAMvMuPQ > 0; xTykAMvMuPQ--) {
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
        }
    }

    if (lVEoKAzupKlPUP == true) {
        for (int lTkAs = 2101662767; lTkAs > 0; lTkAs--) {
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
        }
    }

    if (lVEoKAzupKlPUP != true) {
        for (int RHVwjR = 542148357; RHVwjR > 0; RHVwjR--) {
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
        }
    }

    if (lVEoKAzupKlPUP != true) {
        for (int KOddU = 440989128; KOddU > 0; KOddU--) {
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = ! lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
            lVEoKAzupKlPUP = lVEoKAzupKlPUP;
        }
    }
}

void sJYZHpCm::nCCNBsZndudew()
{
    bool FdUbFxNKJgiAmp = false;
    bool wjWbuMslFeOQ = false;
    double bgGew = -254116.10837457792;
    double GzbqwPwUxbGy = -487523.89971681155;
    int pEcBpTFEWqsNV = -535017186;

    for (int YRORnSBX = 2083359082; YRORnSBX > 0; YRORnSBX--) {
        continue;
    }
}

bool sJYZHpCm::WwfFexHLY(string QpHisika, bool sjiLcNkHsOLH, double mZUQJdmRr, int XfMkooYoqbnoePIR)
{
    int ifPlhKwiOYcqkCEQ = 1011117010;
    bool QzPqYcxyZM = true;
    int NlHKxxPkVcj = -1736941284;
    int dVwLiSMU = 547758744;
    int qXysEpYjDb = -1877748734;
    int ZvZSeFjfRkOGJm = -1131113304;
    double fmilLWnYASvqnA = -996975.4740100759;

    for (int JPZrPwsNkfarOwXc = 1640787991; JPZrPwsNkfarOwXc > 0; JPZrPwsNkfarOwXc--) {
        qXysEpYjDb -= NlHKxxPkVcj;
        ifPlhKwiOYcqkCEQ /= ZvZSeFjfRkOGJm;
        ifPlhKwiOYcqkCEQ = qXysEpYjDb;
    }

    if (XfMkooYoqbnoePIR != -1736941284) {
        for (int IIKeIoOCAISyz = 1264208353; IIKeIoOCAISyz > 0; IIKeIoOCAISyz--) {
            qXysEpYjDb += XfMkooYoqbnoePIR;
            XfMkooYoqbnoePIR = NlHKxxPkVcj;
        }
    }

    for (int ozplJFTinjS = 1865088449; ozplJFTinjS > 0; ozplJFTinjS--) {
        NlHKxxPkVcj += dVwLiSMU;
        NlHKxxPkVcj -= ZvZSeFjfRkOGJm;
    }

    for (int qxjcgP = 1116528767; qxjcgP > 0; qxjcgP--) {
        ifPlhKwiOYcqkCEQ += XfMkooYoqbnoePIR;
        NlHKxxPkVcj += NlHKxxPkVcj;
        ifPlhKwiOYcqkCEQ /= qXysEpYjDb;
        ZvZSeFjfRkOGJm += NlHKxxPkVcj;
    }

    return QzPqYcxyZM;
}

double sJYZHpCm::sJlkjrcqxGoF(double rpQraEsG, int EvSxbdQRuZ, int IOUogpG, int VOXXvitjTUA)
{
    string ZcuHjhSnrX = string("aROAsrpluACabwYLPDeioKxSVWMhgjIDoCPEHItOaAARxPIEsLVKixZjxdkmxKpPeRedpkVXETEnOVNfjXVsblCoyfESAfkoSZvtJaeqIAKEgGXggOYmzDUMvCtQkCRcnduLGmlwRkDZRJEyCO");
    bool ydCbYGnRpbhJILWd = true;
    int byYfvUeho = -285474269;
    double GCHVPZifZyyyogqS = 486304.12384245376;
    int PYUjWeNTagJM = 1243856992;
    bool FxelywxSt = true;

    for (int pZDJATwvpuhqPwL = 1488079430; pZDJATwvpuhqPwL > 0; pZDJATwvpuhqPwL--) {
        VOXXvitjTUA = EvSxbdQRuZ;
        IOUogpG -= PYUjWeNTagJM;
    }

    for (int KJfhzapOpvvdsaR = 2117300870; KJfhzapOpvvdsaR > 0; KJfhzapOpvvdsaR--) {
        IOUogpG *= PYUjWeNTagJM;
    }

    for (int mZuXNSZfOWRGNq = 272059390; mZuXNSZfOWRGNq > 0; mZuXNSZfOWRGNq--) {
        PYUjWeNTagJM += PYUjWeNTagJM;
        IOUogpG -= VOXXvitjTUA;
    }

    for (int DMNYmYnJNqqsOHmE = 1558899327; DMNYmYnJNqqsOHmE > 0; DMNYmYnJNqqsOHmE--) {
        IOUogpG += VOXXvitjTUA;
        PYUjWeNTagJM /= IOUogpG;
    }

    return GCHVPZifZyyyogqS;
}

bool sJYZHpCm::ZlPgLs(bool QSYrbfNb, bool hGIMozrDE)
{
    double iUbUs = -89200.7623710703;
    string ZMqwQAIegh = string("SeWEcuTqokJWUPdqqeKSDgwGvKMUElfijqcJVXVPFvvb");

    if (QSYrbfNb != true) {
        for (int YiABSCdUgqNWs = 2073577002; YiABSCdUgqNWs > 0; YiABSCdUgqNWs--) {
            ZMqwQAIegh += ZMqwQAIegh;
            hGIMozrDE = ! hGIMozrDE;
            ZMqwQAIegh += ZMqwQAIegh;
            iUbUs += iUbUs;
        }
    }

    if (hGIMozrDE == true) {
        for (int JBFkgbeOUTtygbK = 1455369263; JBFkgbeOUTtygbK > 0; JBFkgbeOUTtygbK--) {
            iUbUs *= iUbUs;
        }
    }

    return hGIMozrDE;
}

bool sJYZHpCm::ZSgsogsQBIS(string yDYxX, double JGUlXat, string XJAzlyRVjO, bool KvbNRRJoJJsVT, bool VsoZg)
{
    bool NcOkkA = false;
    string ebxBxvuiITgkYlfJ = string("EzsdSnBsOPoojViaaNMogWHJDAXAxVxfAUYqNUFIIwkKoYIiTYLDJAshWxvVbEkuGsbAZplkVrRRaYPjPdNeKpkEWuwFyhFKhRUpVyeEQLvTykHDBFgUbDdXGqSEwFZkzzFUwAnEvDiqkNLRLPwEWkBYBOAwciCYygBmeRBSxAQioNl");
    bool zaIjutf = true;
    bool AbUhDnYRkDuZcUsB = false;
    int hlLOcxjSECHO = 157218722;

    return AbUhDnYRkDuZcUsB;
}

int sJYZHpCm::qrEHR(string RhFoPMlGl, string EQQPaX)
{
    bool bxTVrWuIxXWhf = true;

    return 1980512281;
}

int sJYZHpCm::CSdOPuv(string dWgqOv, string wtSXWPLxhibcOc, int EYSgfUn, bool HhSqQhAgDPnkWTqr, bool smuCVQYXmqcaq)
{
    string qgvEBVihrIxXkv = string("KPWoZpJbmREoLsadyvJshgthHggkmvZsKHfvOZJnXtXKdbwNweuehLrQFMpFjuYmBjXdzEUYXuanAHedVpeZdoZPieSatvRpUIZecrnLSfNOBFkPjxavaCylTBxBGPADLDiQBosTovgUcpqeVzhZlqARekSwJNGlQlKAMlRKslbCxZDPCvAubGFApxznIzwBzAKWhuEockpIfELZiIEoWo");
    bool yjfgjRuVZWtDrn = true;
    double QDhoUSy = -413853.14266329573;
    bool YGTbEURjvbOrPxmJ = false;
    string lIPHvhBQQkSllem = string("iNLTrFUMMmvYabQFDdulmalBLlAHkObNDIJEMwslZHiWYWqeoqWIxHPaZRcnvOMXTnPLirCIpNlVhIPGXaHiEtRysbOgczWoAroXubhNKiJJlYmEUxBghOFDgwilTLwAwOhfgAOzTyMPztzIHthJNcsWEWOVXaKJVOyGrcYU");
    bool SAWzRN = true;

    if (YGTbEURjvbOrPxmJ == false) {
        for (int ARbjGHBgnMeNz = 656921675; ARbjGHBgnMeNz > 0; ARbjGHBgnMeNz--) {
            continue;
        }
    }

    for (int aiwdpokCuoJyqsT = 2012937574; aiwdpokCuoJyqsT > 0; aiwdpokCuoJyqsT--) {
        smuCVQYXmqcaq = ! smuCVQYXmqcaq;
    }

    if (HhSqQhAgDPnkWTqr == true) {
        for (int jAKBTPyCN = 39337605; jAKBTPyCN > 0; jAKBTPyCN--) {
            qgvEBVihrIxXkv = dWgqOv;
            yjfgjRuVZWtDrn = ! smuCVQYXmqcaq;
        }
    }

    for (int zPJWUo = 909097556; zPJWUo > 0; zPJWUo--) {
        YGTbEURjvbOrPxmJ = ! HhSqQhAgDPnkWTqr;
        HhSqQhAgDPnkWTqr = ! SAWzRN;
        qgvEBVihrIxXkv = qgvEBVihrIxXkv;
        yjfgjRuVZWtDrn = ! HhSqQhAgDPnkWTqr;
    }

    for (int mPkRkmUdRz = 1941449624; mPkRkmUdRz > 0; mPkRkmUdRz--) {
        smuCVQYXmqcaq = ! SAWzRN;
        SAWzRN = ! yjfgjRuVZWtDrn;
        HhSqQhAgDPnkWTqr = SAWzRN;
        yjfgjRuVZWtDrn = yjfgjRuVZWtDrn;
        lIPHvhBQQkSllem += dWgqOv;
    }

    for (int BDxQuJreWpR = 1596241653; BDxQuJreWpR > 0; BDxQuJreWpR--) {
        YGTbEURjvbOrPxmJ = smuCVQYXmqcaq;
        SAWzRN = ! yjfgjRuVZWtDrn;
        wtSXWPLxhibcOc = lIPHvhBQQkSllem;
    }

    return EYSgfUn;
}

void sJYZHpCm::SpTMgdWhTr(bool DwhnbDAQcamHYs, double WrTlYlF)
{
    string lgjtdma = string("scSVbb");
    int qFpuWu = -826176959;
    double uQOCfMFr = -18072.09617409889;
    int mioFSHKEWuamgzGT = -898658843;
    int IwWtlzGsDkQyte = -844724209;
    string MbACtFNu = string("yMaGjuAXrQdszhvwZfdjKqPuFdVwAQXhMZxeXIHuvEhtTDKCydFLzEYQCqPzoWYEiFjNnYsgYNMkJweDaJkmfPSFbvSACcYqvZoXPWdVloYQfONSRPyurZ");
    int HPBmbC = -501351226;
    string vmEMCk = string("XNZbymXOjajNWpbvdvjwJAJHhHjqXCSCUvTojlTMKwwCGrsDNiYBluwKyiUVNONVFPJEuiuHagWQNQYYKOewDHHgIjtSGWohnYPCHajvwIABR");
}

void sJYZHpCm::UzrGuQmjZuiCJVa(double jGkyW, string mFNGwJhoq, double HkfYsgUuAJQPf, double WmrTQjSJPUvNJJZP, double xNOQthe)
{
    double aYhIqvsAWwlUF = 819809.5638503598;
    string bKJIDkmCjDCXSrI = string("JXyqCxsjLfhfzSjnTCzqchAhFscGOQwYUYXhPHcuhvtmlTvfnlqyrxTFTPFhbwhwscdkbjUsCJljmFbzbtslpQVDXqwsVUuhyurbnTcuKbGjdmRYigjQLtWinazxGxoYnVHvrSlErtMmFRiHnjvTCpOZLLYvQRhrJhABTIHWxZnMpzIreaWHTdGWigYAQXExfqkilnCztiZwKVnfWGMyazpBhtvyjAiPKUE");
    int yNOPBaZN = -1291581025;

    for (int QRAGakwyiISWqUI = 1078222050; QRAGakwyiISWqUI > 0; QRAGakwyiISWqUI--) {
        jGkyW += WmrTQjSJPUvNJJZP;
        aYhIqvsAWwlUF /= aYhIqvsAWwlUF;
    }

    for (int cpZaVYVxHgLC = 266865229; cpZaVYVxHgLC > 0; cpZaVYVxHgLC--) {
        aYhIqvsAWwlUF += aYhIqvsAWwlUF;
        aYhIqvsAWwlUF -= jGkyW;
        yNOPBaZN *= yNOPBaZN;
    }

    for (int PrAmIJUXiJ = 436403570; PrAmIJUXiJ > 0; PrAmIJUXiJ--) {
        WmrTQjSJPUvNJJZP -= xNOQthe;
        WmrTQjSJPUvNJJZP -= aYhIqvsAWwlUF;
        aYhIqvsAWwlUF -= HkfYsgUuAJQPf;
        bKJIDkmCjDCXSrI = mFNGwJhoq;
    }

    if (xNOQthe >= -661996.7304689653) {
        for (int eNojikNiccVozob = 972701841; eNojikNiccVozob > 0; eNojikNiccVozob--) {
            aYhIqvsAWwlUF *= HkfYsgUuAJQPf;
            HkfYsgUuAJQPf /= HkfYsgUuAJQPf;
            xNOQthe *= HkfYsgUuAJQPf;
            xNOQthe /= HkfYsgUuAJQPf;
            HkfYsgUuAJQPf *= xNOQthe;
            WmrTQjSJPUvNJJZP += jGkyW;
            aYhIqvsAWwlUF *= HkfYsgUuAJQPf;
        }
    }

    for (int QcKyyYsifFDD = 1876685676; QcKyyYsifFDD > 0; QcKyyYsifFDD--) {
        WmrTQjSJPUvNJJZP *= jGkyW;
        mFNGwJhoq = bKJIDkmCjDCXSrI;
    }
}

sJYZHpCm::sJYZHpCm()
{
    this->GhkuqtlNl(string("QroXufDaueGaJBVFYxmiRkZYVfegppPmSzRqYegSvRvglHzYvWAJTHDaPAbpEGexBbkoOQinGzcRXErHSHnNrqcfDUsuFSTwWipBBkjtAlNGfPASydRlEghAswBYAtdZVcTmKmfOWjdozneTHjevjpxPXrlaxOYgrxtSkeCZxXuRPsfPvpAZbVRSqQIvesVVdEqgcFsuQvDMHXeXdSUzT"), 1350907653);
    this->yvqtih(string("TdzWAkANDqQpOGLEpnOBhQyR"), 1005554.068713863, -1013767.4195582183, 294697.67335956305);
    this->fyHuvRIa(true);
    this->CsDHsBxuOoIIvXu(true);
    this->QvTUqHfsH();
    this->nCCNBsZndudew();
    this->WwfFexHLY(string("IEaZtQFYoCfdVIzPEDOkAdwfBKgMcvTieHmAtscPyrTHVwSuOdscXvoufaYmJvOZWDBoWJSZHCVQwuLsuJrztNddGDbHvzFM"), true, -853775.4918656249, -1151451613);
    this->sJlkjrcqxGoF(-742480.0831522719, 1548239664, 128898761, 2018958510);
    this->ZlPgLs(true, true);
    this->ZSgsogsQBIS(string("xyxzKSbSfvwnrEqAhBddRgUzFWXOvkIcNbhcTPKPLmcHnbfDsonGkKJpQwaTxRHUFerlpyXZTNOuuaMwClvnYAVfQvpOThhsYsMIAelNeBUbEMaEBIAPUTmJHERdbxGbJkOOGFYERNIWQzLFgrYFudgptRJnrcGBGjANDVGckhMWwzEZAYjMKscVxFeumjdXYXLHvoazhUPOYlrMttaTTgJtwpaAZbLOREeuyNCtUVulazDMwCYynlNITXRZ"), -1021072.430859039, string("LHdJngiwdjWetDHahxvvBnEQncQSFaNAhEmkrWVAZUOHgTUNlGVvWWkUmkLxYMxTruaLsrDIAHPRCYnaTOGXAeVTIDKOpBzmxFnfJXMlOwhiCCGxPRuySiQZjlltvKYEfgtbcahkSAzBQnWLRxsfrEJYG"), true, true);
    this->qrEHR(string("jaJvxdtNhCobpKYAXoDxwmBEacabrVitcraBMKzSyBUwBIsokHYGVgeljSKqggmfQBArUvKHfgjgOpXwkLpDnHKGVGtoiOtIkwsUbNXdSjQEIjFaNKtRByttnXoBazTJMFlvgne"), string("cIxVZSbczMJLQyjPoOaqgmZcELaFtPbcESUuLSNqaVoxLNZhWXwFjsEfFOyqAElliItdAiFZDZhNAVikkpRIJhjuqvvhCJAmoKwWIxOgrXAwfrMhtdssiJLIBzixjOHsDRkUjBmRWtsPTszRDyjyirpDCWdzmHKrXNOrEbNPZAlnjnJKbNMCRHYPqyAcjVaoAsRhWY"));
    this->CSdOPuv(string("tivBvFjElgmusxYVbMcUMFeUQTtYwioqInOLvOzUPxDcqBPjLIuSpZhryTqOxvxWdJmMtKwHOaOkrrUjXuVVtTPheXmhuznGSyRiOMsuerDmJgwRnMavphWqhMElSbjAvMvTbXqAZNfxULyZzcBgwQzKfEWqdAspAEMIuTdHTGNJCLNFItIXhaPRKqTsIaXxwMiqCgVBhPAfNFteRHHiXKaWYowKxrQZMlqjoelRDJoSttSQtFiwsYwiQh"), string("NoltVFtQxSBiwEwZbDDFyASAgrdoaKUyDpNPYROAnDMktOKPTFetRETEhuKstBpYKiItXDYnwtVkXLDKMSzJnakzvZlmGFdSlPzNKeYrRYFyJcmBkXyYIZQZZQMhSHDESYcUMZQpzJXTgXwlmrDbFVvcoxJZDweBXhjugGkmezGYqgTktiOwhwvvmyaFJNKdAUsiAXlOumggFDIptFciilIdmlTVKuQGxZUyPXxEBluRmfDKEgAMGoPcxYageY"), 1566357876, false, false);
    this->SpTMgdWhTr(true, -258416.8102237791);
    this->UzrGuQmjZuiCJVa(995906.3540252249, string("mUhJKGORtJVebTPZDBFtoUvdRQCqTaBdFoxXliuAKVUcBnRgzoOYZzYtDcVPJclKnezbLJorDrikkyNlnSpZGjuhTjYIWQpcJayrxExIftvuPBdzwJclWgKjzJkZVPFRUZjCzOqpikTmakZmzrYQJcJQypUEFJHIEsVYndokieCxSgvQqNmmojQGAoqAGPNvzDEzYHdvLzvqNHdWTJAuINhwvREHHyfnGysJWJIJuWQDtdWAB"), -661996.7304689653, 833604.7748771786, 942576.907372337);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aFwsFRgvObpyB
{
public:
    bool PqTJfLUGIqnqobjH;
    double eCYvUtgerQuUWE;

    aFwsFRgvObpyB();
    double LwTHhiiYylv(int SuLzYQNOfaFHGz, bool uimsvK, bool RCDWrN, double BZTClu, double SCxAGB);
protected:
    string GpWHNnFjgjCiRf;
    int VBFLUCWuPPYaxC;

    int YzWpbFosMqEBKhd();
    bool CwwFZVbhEzkzupD(string crQfDGlEduhCicM, double RNkUPGHy, int RvSrwwZHhyzdoI);
    string EKIQk(string TsaiRHnAXetSf, double rmargYrrNR, bool fXnxuNDsr, double VxNiI);
    double BMKeNuADRQVR(bool OBgdSoH, bool UJgEnXpukwo, string SdiQHVu, double tTZdxCelvjaRLe);
    int hcEVK(double JYJBQTKmaYhpmWT, string gBrVDoUxNtvTIUaQ, bool CuLteiXurqp, bool gqLXmNajoDC);
    void MKXOFoT();
    string WKoFRNJefpw(bool PDfIZvWTXJA, string PbGuofaUlMFb, string iNjwAYqhj);
private:
    double PsqdfRrEsf;
    double BQbKPNvCDPIQkE;
    int nyHgiSsVxTiQ;
    bool acLIKEK;
    int jrXdkCaQLaJt;

    int VgMLxbQKQyXh(int pKVYm);
    void YrmkOfOPg(double kXttA);
    bool iDxTyDjriKLgqv(string GeaMptqGeqyQtMT, string LPhWoswUtOhb, string QQMafcKfZVdj);
    int IuPpgoSZAaNABz(bool PhXQVQYinYmwc, string VrmmtFt, int AhpfQwBcNT, bool kjZgBYxxR);
    void ZXgUg();
    bool GVxqZZyvZLmnaSu(string YCyeGjSo, int ZUgHjM);
    int WfnekbrddmgIce(bool XxDsIX, string zudACfRpEUmxHV, bool vuuFcjknEI, bool KqaWhxVVoQbt);
};

double aFwsFRgvObpyB::LwTHhiiYylv(int SuLzYQNOfaFHGz, bool uimsvK, bool RCDWrN, double BZTClu, double SCxAGB)
{
    bool TrZjZZwmxrHng = false;
    string nhVAVACwlJOTYhcE = string("pEezlMDlJEEFzYNLxjITqXGfcWVWhzTEExwFlgCkNyAMfnTbqRDSnskkeavCwTQzxuRNxYoCbHWzEEPHwMSSWjGZifZouTxwNFYswLwVmcYSOomhOvSJAedqsuBTDbBTgCtJjJlRNETIvIzMOWjANQcAHlnJOfJLUvxRQjOPdYYrPhhDiGGGZOTAcdolCNfUHesfwGKUljknqOBakzJPT");
    double lHitNCGN = -336589.4082832257;
    string emLtMHqiEtwoCwv = string("TCwmAkCRcgySsoodgUAeGgkYHeoiBvXznWpotdoOxyCSOMUFxJrshusMTXmGmWXrSphaYjkxXkUUvDOBHIoFYXVAKoltTXMfaReZChL");
    bool aXXnpDWIjmguus = false;
    int MgcdDyqKw = 1216259665;
    string zFvDuF = string("GHCKauPBPBpjAwnTbiTNLspjGnEqaJOhKUyjbHaMbVXIhgkDSJFlatxXEVQahDebfYnjlOTrQZTHPCzOTMmpPOJKRnInwgCUaGmPCQxYaXoUmsoCJWBuCQuiboiYXSLognVBUhXRudmYPhgmxhMXrMqPXAbsdGzDnrCdAifUEcKkBfCHEZOTQiQqZvzvlUARSbCsavkDDbtVuLsFUgb");
    double mgWqHmbEuGYDqBDn = -28120.834011406845;
    int DGzsc = -7526541;
    bool vzdlLoYZuPV = true;

    for (int vTyzNksN = 1661733477; vTyzNksN > 0; vTyzNksN--) {
        continue;
    }

    if (zFvDuF == string("GHCKauPBPBpjAwnTbiTNLspjGnEqaJOhKUyjbHaMbVXIhgkDSJFlatxXEVQahDebfYnjlOTrQZTHPCzOTMmpPOJKRnInwgCUaGmPCQxYaXoUmsoCJWBuCQuiboiYXSLognVBUhXRudmYPhgmxhMXrMqPXAbsdGzDnrCdAifUEcKkBfCHEZOTQiQqZvzvlUARSbCsavkDDbtVuLsFUgb")) {
        for (int ZrEPqfFRHBMXOUl = 1481778591; ZrEPqfFRHBMXOUl > 0; ZrEPqfFRHBMXOUl--) {
            continue;
        }
    }

    return mgWqHmbEuGYDqBDn;
}

int aFwsFRgvObpyB::YzWpbFosMqEBKhd()
{
    double lxXSyfoDexkZXh = 716949.0432574267;
    double wUpofHL = 1030707.8000275714;
    bool JOmxgFFWFlrwIry = false;
    string PNaQiSYBDqqpKmm = string("GWUhUWYrYXhrwgQuKBTOXjESduGXyWrjixgMLnxuQSlThkNxPSwMmkdqisrgtYyxFKevsXHVHlNhBTscYnFTuHhmCxlrECqpOvNPepYjfZRLIRCqDPdWqLcAtJtLarkcCoEIchhCxCISndmbssVwUAywjMlmcqDOYqnlUqVDiqTahLGTVOZDqkbiXUUFpSLWYLrKcYqibNHAEOsiXStJftLyQcyPNucDzOUMSxmbPkhqTzS");
    bool YtLqBSBlsvmVwTgs = false;
    double nVNZNodOxfomZ = 204276.91975965298;
    double AUxpOYVQ = 979432.2286909122;

    for (int WJBzoEZeaupYdetv = 745464284; WJBzoEZeaupYdetv > 0; WJBzoEZeaupYdetv--) {
        YtLqBSBlsvmVwTgs = JOmxgFFWFlrwIry;
    }

    if (lxXSyfoDexkZXh == 979432.2286909122) {
        for (int fKTQwMWzVkvdcpN = 2128898371; fKTQwMWzVkvdcpN > 0; fKTQwMWzVkvdcpN--) {
            AUxpOYVQ /= nVNZNodOxfomZ;
            nVNZNodOxfomZ += wUpofHL;
            JOmxgFFWFlrwIry = ! JOmxgFFWFlrwIry;
            wUpofHL *= lxXSyfoDexkZXh;
            lxXSyfoDexkZXh += AUxpOYVQ;
        }
    }

    for (int DaqKlNaJVnMrwlR = 1112732374; DaqKlNaJVnMrwlR > 0; DaqKlNaJVnMrwlR--) {
        AUxpOYVQ = AUxpOYVQ;
        nVNZNodOxfomZ -= lxXSyfoDexkZXh;
        wUpofHL -= lxXSyfoDexkZXh;
        nVNZNodOxfomZ *= lxXSyfoDexkZXh;
        AUxpOYVQ -= lxXSyfoDexkZXh;
    }

    return 421939261;
}

bool aFwsFRgvObpyB::CwwFZVbhEzkzupD(string crQfDGlEduhCicM, double RNkUPGHy, int RvSrwwZHhyzdoI)
{
    string qzwwYZvEAktVEQT = string("LrHxCwwQyCWgbCoguWPSVqEyWTnWMrtujdRAWlNoaYVZNyPZaueGVeSkqQxsFUhMVCTIIFqHnKLRUCAZwsqnjUiRirmNugvedLXHnCitAnmCbt");
    double HfiEHwgirgUUxoG = 922197.9178553866;
    int IjzDkyOl = -1916022797;
    bool jGTeBGxIcihxTol = true;
    bool RtaOveNFHJlmjQUW = false;
    bool wdKDfdUaTTuUWf = false;

    for (int brholCUIeP = 2061075227; brholCUIeP > 0; brholCUIeP--) {
        qzwwYZvEAktVEQT = crQfDGlEduhCicM;
    }

    for (int urjeo = 1203004640; urjeo > 0; urjeo--) {
        RtaOveNFHJlmjQUW = ! jGTeBGxIcihxTol;
    }

    return wdKDfdUaTTuUWf;
}

string aFwsFRgvObpyB::EKIQk(string TsaiRHnAXetSf, double rmargYrrNR, bool fXnxuNDsr, double VxNiI)
{
    int kTQWMgZD = 1932686690;

    for (int nsRKAiSA = 1887530386; nsRKAiSA > 0; nsRKAiSA--) {
        TsaiRHnAXetSf = TsaiRHnAXetSf;
    }

    return TsaiRHnAXetSf;
}

double aFwsFRgvObpyB::BMKeNuADRQVR(bool OBgdSoH, bool UJgEnXpukwo, string SdiQHVu, double tTZdxCelvjaRLe)
{
    int cqumpFzIWbtT = -279000946;
    int yIkAcrjuaodfyhqC = 451746071;
    double XLLPWUtATHpLMr = 25063.75763715148;
    double pYJEZliUpLBCVLX = 544548.2923842123;
    string klxqHzqHxw = string("NgRIsePVKFprDDQivhdaHduZmlTSeSyRzaKRBpCRCzokygDGcgWOedAwQkkBSOsPzyLVahEjKKfXUIvJAdyrcHpbhVeJiIVSlpMUrBtkogowpXBOAvTvTBWdrRVTOyMOkLzaGQofKmNuVObKzlpYQjpnJeigrXizOfzyfPXyTsWALJtTsHFuQqAUyBGjdSsojeUGJwHgaxXfAhXsTeDtQAabGAhFXPEmuEafdNCiFSAQcaCZ");
    double fGCql = -301441.79688075767;
    bool FPmfvZuML = true;
    double nNjTVgHN = -308723.8799295174;

    for (int mDVJcNWJbBxQ = 1917393265; mDVJcNWJbBxQ > 0; mDVJcNWJbBxQ--) {
        nNjTVgHN = pYJEZliUpLBCVLX;
    }

    return nNjTVgHN;
}

int aFwsFRgvObpyB::hcEVK(double JYJBQTKmaYhpmWT, string gBrVDoUxNtvTIUaQ, bool CuLteiXurqp, bool gqLXmNajoDC)
{
    int eDFZUI = 1372659725;
    bool BujtSNlmYjBozjvD = false;
    int XeUkcvXb = -1883725378;
    int CUcanLwIynvrWe = -1274346356;
    double GvSautuomRB = -564395.6183084862;
    string opytyTGnhY = string("DChWMtKVStUiYBuyZksxGXmRajAmzsUTjURzXxRLkzEMqGiAsqgLnFgiVxdP");

    for (int WbwGaNonWwNFD = 1472453324; WbwGaNonWwNFD > 0; WbwGaNonWwNFD--) {
        continue;
    }

    for (int aVuFX = 1924072077; aVuFX > 0; aVuFX--) {
        continue;
    }

    for (int maDTIKkk = 33477893; maDTIKkk > 0; maDTIKkk--) {
        gqLXmNajoDC = ! BujtSNlmYjBozjvD;
        gqLXmNajoDC = ! BujtSNlmYjBozjvD;
    }

    for (int eRghkXTVJBesjma = 619569554; eRghkXTVJBesjma > 0; eRghkXTVJBesjma--) {
        continue;
    }

    return CUcanLwIynvrWe;
}

void aFwsFRgvObpyB::MKXOFoT()
{
    int BcQzXGyDBkpdI = -1766590469;
    bool pXrRQgsUZUNOMGy = true;
    double RitQNGiZeYTuGF = -915349.3060175299;
    bool hMAKCVOcdmfuin = false;
    double jwRNN = 602923.7955363464;
    double LzrOnecobhmX = -3802.121639040888;
    string ynXYriDYxYXK = string("xQhYTOQtYttkablUnIVGEMVTcVoKUVUHqsgccjrpjAhYvYwFhfJpbsPwKVnkLoZfEYSQurvtAeAiLcazRvubHebPkPXrNSQusrNYlwYUXeIrWoHkFNmIDybmRFzQGiNPOvrOlfDCgdhNnwXLIIJmGCJvYttHJjLfxkgNNiNJDwNWZeEFRBgwS");
    string MridspsCpzJ = string("QypjtAwPJMykoEcwwLaIhLeYEawvhsPMLsaQHCQvYDeHGVySTQOvSBSskgIRBkaPVCkLQDGXzHCZWzvvzxrPlgQIwXrHqeJsPvewtgygPwgyqcIVhcKQgnFaFgEihnjb");
    int cMZkm = 1288353166;
    int OlQHpS = 1559736131;

    if (pXrRQgsUZUNOMGy != false) {
        for (int XQcwehpqQvqMJd = 408012500; XQcwehpqQvqMJd > 0; XQcwehpqQvqMJd--) {
            cMZkm *= cMZkm;
            hMAKCVOcdmfuin = pXrRQgsUZUNOMGy;
            RitQNGiZeYTuGF = RitQNGiZeYTuGF;
        }
    }

    for (int wvGBPQdnsKAVjZ = 618276670; wvGBPQdnsKAVjZ > 0; wvGBPQdnsKAVjZ--) {
        continue;
    }

    for (int apgPaGpGNNUSPSq = 431943638; apgPaGpGNNUSPSq > 0; apgPaGpGNNUSPSq--) {
        continue;
    }
}

string aFwsFRgvObpyB::WKoFRNJefpw(bool PDfIZvWTXJA, string PbGuofaUlMFb, string iNjwAYqhj)
{
    int wwlcH = -143452640;

    for (int NJSbHcztBKWszzG = 1467599872; NJSbHcztBKWszzG > 0; NJSbHcztBKWszzG--) {
        PbGuofaUlMFb = iNjwAYqhj;
        PbGuofaUlMFb = iNjwAYqhj;
        PbGuofaUlMFb = iNjwAYqhj;
    }

    for (int mCcNtRyynBTo = 995341789; mCcNtRyynBTo > 0; mCcNtRyynBTo--) {
        PDfIZvWTXJA = PDfIZvWTXJA;
    }

    if (iNjwAYqhj < string("TNNTpkTrYCwZRVALizSWVoKsFVLokPIWmDQBewiZEIHxbMDbcpYrcYBiuvXObIYabNWOMXyejKIfylUyWzObsQKgUABFUAUKveCCemiBpWoZlGRyVgvnZsxxLvjOqDexRFScpIkngJSlAuzWSYSDoYPfyxJD")) {
        for (int BPOwB = 1680065871; BPOwB > 0; BPOwB--) {
            PDfIZvWTXJA = ! PDfIZvWTXJA;
            iNjwAYqhj += iNjwAYqhj;
            PbGuofaUlMFb += PbGuofaUlMFb;
            iNjwAYqhj = PbGuofaUlMFb;
        }
    }

    for (int yOpZYI = 1138012396; yOpZYI > 0; yOpZYI--) {
        wwlcH /= wwlcH;
    }

    for (int TtxPQiYx = 1625440128; TtxPQiYx > 0; TtxPQiYx--) {
        iNjwAYqhj = PbGuofaUlMFb;
        iNjwAYqhj = iNjwAYqhj;
        iNjwAYqhj = PbGuofaUlMFb;
    }

    return iNjwAYqhj;
}

int aFwsFRgvObpyB::VgMLxbQKQyXh(int pKVYm)
{
    bool LJCAq = false;
    string MBNbxZWbAXqrbbQ = string("smKLrbJoruypwXbQjXsOhsgpiIyhkCpzhaYPpTQskNZBRChQZFIHzYdAPDeepiRafrGBELOpSXPoIcZqjtaUVpOfkouEbdgxnEzFlhELzuOeHSMmtGnJzLfUgdGCsBZFfspAJNoaOlqDQRKZSAWTlVDAUMMtpbsECZLzyeUHSABZiavjLqdioqTfQ");
    bool okfjvbU = true;
    string jqMuPLC = string("sLgZcMiWXOyoiWpPpBfAAaWHOHIjzEMXkwusMDzEmQowPZzEjTbUOCHKMFGfBTdagfqXKXeZKNMyvudDAENEbzRkMwtehpLmKFyEJGnjjiAiIBWeVvbMMdlxDjAUFGlkoDeyWzjTVkDpSrwTuXkNlSxLgidEytyYlPYMbgoJlAlhJqZGrpizbzLUGTgLviIWAcegbctLdV");
    bool CLHGegqDrHYR = false;
    string SQhWjlVxAvEqNBL = string("AYoGvrlSgxAGZJHtI");
    string mNpCHGcPtbIHRA = string("taHMrjrEHeKNH");
    string GdqDxChnbAnS = string("ajfKMBoofVlClufLlBzCzCuBCkqfUAyzClCwwayQCXmzQYWpMiJVNjpLXQfSzMrszpecSMEkfeLkjkhYVUSoNdKOeWftGoCnWAx");
    double UjWzUGm = 435034.91014992824;

    if (SQhWjlVxAvEqNBL != string("smKLrbJoruypwXbQjXsOhsgpiIyhkCpzhaYPpTQskNZBRChQZFIHzYdAPDeepiRafrGBELOpSXPoIcZqjtaUVpOfkouEbdgxnEzFlhELzuOeHSMmtGnJzLfUgdGCsBZFfspAJNoaOlqDQRKZSAWTlVDAUMMtpbsECZLzyeUHSABZiavjLqdioqTfQ")) {
        for (int FnOtfej = 827346374; FnOtfej > 0; FnOtfej--) {
            GdqDxChnbAnS += SQhWjlVxAvEqNBL;
        }
    }

    if (MBNbxZWbAXqrbbQ > string("ajfKMBoofVlClufLlBzCzCuBCkqfUAyzClCwwayQCXmzQYWpMiJVNjpLXQfSzMrszpecSMEkfeLkjkhYVUSoNdKOeWftGoCnWAx")) {
        for (int GISPbglkliwoh = 1606071180; GISPbglkliwoh > 0; GISPbglkliwoh--) {
            continue;
        }
    }

    if (okfjvbU != false) {
        for (int akbCLtbMYaIgHr = 323568093; akbCLtbMYaIgHr > 0; akbCLtbMYaIgHr--) {
            mNpCHGcPtbIHRA += mNpCHGcPtbIHRA;
            MBNbxZWbAXqrbbQ += mNpCHGcPtbIHRA;
        }
    }

    return pKVYm;
}

void aFwsFRgvObpyB::YrmkOfOPg(double kXttA)
{
    int BAgct = -948289405;
    bool igCbbn = false;
    int PJISkvEpEtCoGvkC = 2011038335;
    double wpKFO = -868141.3456586673;
    int CRIDZAGnyFlXrkS = -1719129151;
    bool ZJnCInCbc = true;

    for (int hzOmbP = 139539796; hzOmbP > 0; hzOmbP--) {
        ZJnCInCbc = ZJnCInCbc;
        PJISkvEpEtCoGvkC -= BAgct;
        CRIDZAGnyFlXrkS += PJISkvEpEtCoGvkC;
    }

    if (kXttA == 225432.44849927042) {
        for (int MmEZHIlKHYpgpMh = 835483650; MmEZHIlKHYpgpMh > 0; MmEZHIlKHYpgpMh--) {
            PJISkvEpEtCoGvkC /= PJISkvEpEtCoGvkC;
            kXttA += kXttA;
        }
    }

    for (int JZWkBkSqVMTcB = 96970539; JZWkBkSqVMTcB > 0; JZWkBkSqVMTcB--) {
        CRIDZAGnyFlXrkS = BAgct;
    }

    if (igCbbn != true) {
        for (int WVfRPwEy = 2068906881; WVfRPwEy > 0; WVfRPwEy--) {
            BAgct += BAgct;
            CRIDZAGnyFlXrkS /= CRIDZAGnyFlXrkS;
        }
    }
}

bool aFwsFRgvObpyB::iDxTyDjriKLgqv(string GeaMptqGeqyQtMT, string LPhWoswUtOhb, string QQMafcKfZVdj)
{
    double aeWPCX = 351282.5188219207;

    for (int DjrzQBfvGEh = 1571472823; DjrzQBfvGEh > 0; DjrzQBfvGEh--) {
        LPhWoswUtOhb += QQMafcKfZVdj;
        GeaMptqGeqyQtMT += GeaMptqGeqyQtMT;
        QQMafcKfZVdj = GeaMptqGeqyQtMT;
        GeaMptqGeqyQtMT += LPhWoswUtOhb;
        GeaMptqGeqyQtMT += LPhWoswUtOhb;
    }

    for (int jQavvPKHKZI = 383428804; jQavvPKHKZI > 0; jQavvPKHKZI--) {
        GeaMptqGeqyQtMT += LPhWoswUtOhb;
        QQMafcKfZVdj = LPhWoswUtOhb;
        aeWPCX += aeWPCX;
        LPhWoswUtOhb = LPhWoswUtOhb;
        LPhWoswUtOhb += QQMafcKfZVdj;
        LPhWoswUtOhb = GeaMptqGeqyQtMT;
    }

    if (QQMafcKfZVdj < string("EucwPGvRVlWBuiWkKbDEeZJKFiCsfVrlqBdsXHlAksZHFDAuVBsUDtPiTrRXxFTFZjOJnHbilPqJcskjlKRMNPQTLxJbXswQ")) {
        for (int cuEBYDJCjY = 1268304113; cuEBYDJCjY > 0; cuEBYDJCjY--) {
            GeaMptqGeqyQtMT += GeaMptqGeqyQtMT;
        }
    }

    if (GeaMptqGeqyQtMT >= string("EucwPGvRVlWBuiWkKbDEeZJKFiCsfVrlqBdsXHlAksZHFDAuVBsUDtPiTrRXxFTFZjOJnHbilPqJcskjlKRMNPQTLxJbXswQ")) {
        for (int UWBzuCkyV = 244615728; UWBzuCkyV > 0; UWBzuCkyV--) {
            GeaMptqGeqyQtMT += QQMafcKfZVdj;
            LPhWoswUtOhb = LPhWoswUtOhb;
            GeaMptqGeqyQtMT += QQMafcKfZVdj;
            QQMafcKfZVdj += LPhWoswUtOhb;
            GeaMptqGeqyQtMT += GeaMptqGeqyQtMT;
        }
    }

    if (QQMafcKfZVdj != string("EucwPGvRVlWBuiWkKbDEeZJKFiCsfVrlqBdsXHlAksZHFDAuVBsUDtPiTrRXxFTFZjOJnHbilPqJcskjlKRMNPQTLxJbXswQ")) {
        for (int CcwcJd = 646840904; CcwcJd > 0; CcwcJd--) {
            LPhWoswUtOhb = GeaMptqGeqyQtMT;
        }
    }

    return true;
}

int aFwsFRgvObpyB::IuPpgoSZAaNABz(bool PhXQVQYinYmwc, string VrmmtFt, int AhpfQwBcNT, bool kjZgBYxxR)
{
    int txOQJ = 336331227;

    for (int BKvYmSyvo = 1156069062; BKvYmSyvo > 0; BKvYmSyvo--) {
        txOQJ = AhpfQwBcNT;
        kjZgBYxxR = kjZgBYxxR;
        txOQJ += txOQJ;
    }

    for (int bJjxIPrT = 1948495462; bJjxIPrT > 0; bJjxIPrT--) {
        AhpfQwBcNT = txOQJ;
    }

    if (txOQJ == 1099167855) {
        for (int fBdikU = 29115567; fBdikU > 0; fBdikU--) {
            AhpfQwBcNT /= txOQJ;
            VrmmtFt += VrmmtFt;
        }
    }

    if (txOQJ <= 336331227) {
        for (int HoTTSXlpvNGu = 1758497726; HoTTSXlpvNGu > 0; HoTTSXlpvNGu--) {
            txOQJ = txOQJ;
            AhpfQwBcNT -= txOQJ;
            AhpfQwBcNT += txOQJ;
            PhXQVQYinYmwc = ! kjZgBYxxR;
            VrmmtFt = VrmmtFt;
            kjZgBYxxR = ! PhXQVQYinYmwc;
        }
    }

    return txOQJ;
}

void aFwsFRgvObpyB::ZXgUg()
{
    int PeBILtUqLDbno = -1339515686;
    string vPveODdGa = string("jqJPyWrOsjUbPBZWuPsJTzIfIptTnPqJsvQwJeFrxBwtWktwugPJrOPSoMYdhDjmXsIlngBZWBGynmIDyqnpyVfkaZVcLEpFNkGjOwwYgWSPyuhPwUGBBirJaNiDGQTUObyJRNXgpWDAuySsmQZRxRsUnbFOtGjNvXykBLMxFiTVPGoeUClADBeaPHpmTQnnHmecrAvXLCkqpOINRCHTfwxqFIgeIRWPPLqkIaPGmcesL");
    string eAOlODwVOSVJ = string("yLRLKtFvKPZjWBZyHiRBzUKSqlMLfuGeFNEhuVahOwOyajxUvuitpHFrmxtTHnWNGncoMQnaQzxZEUQTjVGBooKQLgFFhyVenEbJtHTJYJMLDaSGBGrLejyqNRCsAsRkirYkgIMoZiWYxyodyDcTIiSEsnjojFceCybsrDfLt");
    bool rAwtwUfCmNfwXn = true;
    int GuytDQYNywyTQHg = -652381798;
    int gAyFzNHQU = -1891846084;
    bool XMvBRXeJZS = false;

    for (int PVHZSXj = 160014734; PVHZSXj > 0; PVHZSXj--) {
        GuytDQYNywyTQHg += gAyFzNHQU;
    }

    if (GuytDQYNywyTQHg == -652381798) {
        for (int ncHizGplqf = 1298262592; ncHizGplqf > 0; ncHizGplqf--) {
            continue;
        }
    }
}

bool aFwsFRgvObpyB::GVxqZZyvZLmnaSu(string YCyeGjSo, int ZUgHjM)
{
    double bwjYmfum = -245543.17081600273;
    double lxvIBDqPl = -850206.8412121449;
    double rATIGvyhumqGLqR = 421376.7708178275;
    bool eTxmlC = true;

    for (int bCXbWhEfsAvAb = 2017573263; bCXbWhEfsAvAb > 0; bCXbWhEfsAvAb--) {
        continue;
    }

    if (bwjYmfum > -245543.17081600273) {
        for (int UmnhBXLyKH = 1703216901; UmnhBXLyKH > 0; UmnhBXLyKH--) {
            continue;
        }
    }

    for (int ONhBtnsg = 1264342038; ONhBtnsg > 0; ONhBtnsg--) {
        bwjYmfum -= rATIGvyhumqGLqR;
    }

    for (int mimvaKcs = 93091222; mimvaKcs > 0; mimvaKcs--) {
        ZUgHjM *= ZUgHjM;
        bwjYmfum /= bwjYmfum;
        YCyeGjSo = YCyeGjSo;
        YCyeGjSo += YCyeGjSo;
        lxvIBDqPl /= bwjYmfum;
    }

    for (int hvqiQyeIg = 1899902292; hvqiQyeIg > 0; hvqiQyeIg--) {
        bwjYmfum *= rATIGvyhumqGLqR;
        lxvIBDqPl -= lxvIBDqPl;
        lxvIBDqPl *= lxvIBDqPl;
        lxvIBDqPl *= bwjYmfum;
    }

    return eTxmlC;
}

int aFwsFRgvObpyB::WfnekbrddmgIce(bool XxDsIX, string zudACfRpEUmxHV, bool vuuFcjknEI, bool KqaWhxVVoQbt)
{
    string wWxDWemtyGHhdt = string("zSqdBJVWbFsyfvdWVIaYT");
    int zEEedK = 1237264520;
    double KmMMOxP = 988948.1545811278;
    double vgoAAchoFFUxa = -15272.280456542268;

    for (int EeKKVPKgXWFO = 1992593850; EeKKVPKgXWFO > 0; EeKKVPKgXWFO--) {
        continue;
    }

    if (vgoAAchoFFUxa == 988948.1545811278) {
        for (int mnhQDufxMABkGx = 1441625264; mnhQDufxMABkGx > 0; mnhQDufxMABkGx--) {
            wWxDWemtyGHhdt += zudACfRpEUmxHV;
            vuuFcjknEI = vuuFcjknEI;
            XxDsIX = ! vuuFcjknEI;
        }
    }

    return zEEedK;
}

aFwsFRgvObpyB::aFwsFRgvObpyB()
{
    this->LwTHhiiYylv(1326057028, false, false, -974905.0205258881, 458475.8357148294);
    this->YzWpbFosMqEBKhd();
    this->CwwFZVbhEzkzupD(string("DwOjbCTDnneyoATcPIZvZJpLmOeosnglMRmHKVBvOGEHGhokiMrQRULkZsxcrEQdIGnaOVjhlwCcccsofRyKMbgrPmcfvtUkZrfJYHfbdGUwaOdLhDEMwpeuKAPoi"), 306119.94352874736, 888160347);
    this->EKIQk(string("qOMEWWRDKNZtcZBjoAKvsWUyNfmtvyPJjRQKVJGsQuiNrhizYGfMyLOWtHYHtkMRH"), -981697.6102213023, false, -706906.2758420942);
    this->BMKeNuADRQVR(false, false, string("CnzhnpfNOMw"), 152798.23012433865);
    this->hcEVK(35613.341118958015, string("CN"), true, false);
    this->MKXOFoT();
    this->WKoFRNJefpw(true, string("TNNTpkTrYCwZRVALizSWVoKsFVLokPIWmDQBewiZEIHxbMDbcpYrcYBiuvXObIYabNWOMXyejKIfylUyWzObsQKgUABFUAUKveCCemiBpWoZlGRyVgvnZsxxLvjOqDexRFScpIkngJSlAuzWSYSDoYPfyxJD"), string("ZekiAQqtzzptuZwjGFqnKNwvctGbCNNp"));
    this->VgMLxbQKQyXh(1312497859);
    this->YrmkOfOPg(225432.44849927042);
    this->iDxTyDjriKLgqv(string("HKMihavrmKGNganQlAaLHGuzgbVaupaFrTARgyRgQcVLxxzTbZOnysfFQcielfdwMtUvUwToqldPDnmKTJWdEgHDWDtBCOpVBlKboEzMzWNJgESQQapdDhkJzsuGAVqIojSshOCVnBDLaWnrmaSd"), string("RbhShxRMPcsCsXJgkJAYEnGQMnDApdaepVnsYuPzONzUDwheGhRYmMbjcKFHOMJzsCGHaVDmCwmiTQpQPCyBJZzWLvCmQUSnzTvdNflGTBjiyfOU"), string("EucwPGvRVlWBuiWkKbDEeZJKFiCsfVrlqBdsXHlAksZHFDAuVBsUDtPiTrRXxFTFZjOJnHbilPqJcskjlKRMNPQTLxJbXswQ"));
    this->IuPpgoSZAaNABz(true, string("upU"), 1099167855, false);
    this->ZXgUg();
    this->GVxqZZyvZLmnaSu(string("PWXGzlePWwDpDNwfBhAugHQFLZGXxVZwWUgmzXRJUUAxxQmBqxzJxMJdNC"), 1072819359);
    this->WfnekbrddmgIce(true, string("XSgCylCWklfnIthlVFEixnBsYMEsCmuOPVhgTueqIWeKlpFnyWabljwYxphgmppfvBSXGTknGBIKfZMonksOQybhNIIGrquvPAwvpJMvirwEiqorBeAHTCOVrLstAVaCeAEwINEnOeJDgTSMdbBtMqSPiAuuOXGmdcYoFVnCUQQyiwlVfLYWNzksvDjPhDJovvdjyqxhKRAuFnpSvwSfu"), true, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kHZvLvCbixka
{
public:
    int CyEptJv;

    kHZvLvCbixka();
    bool OSvRIOP();
protected:
    bool WihknGhysGUljWWN;

    void zDWVusrx(string EcctVbUyjAHR, double uBOSnPSFpgXYV, double kmFYiCcjBxeN, double XXvFVzGOG);
    int xtcCAmrbBiSr(int vJlNk, bool ikftaHWcaAsOGu, double nYbTWAAHYwcQoJmY);
    string HojuiLHHGVfN();
    bool zgpbuZPaUkISwWau(int HykYMAdoWIdvWmH, double YCiVxLfyyaIOOr, int koiLOQlTfDDbrJ);
private:
    string oWJzKGWiWeigici;
    bool OnTvNNLGc;
    int GIuKmFLaVWhNSmE;

    string LkpqWWAjiKVabTGy(bool CzKoCMC, string zXUfJTaPuYaQiOO, string BZlvCcWileJ);
};

bool kHZvLvCbixka::OSvRIOP()
{
    int qQeYjIOPlotlbHbD = -891202895;
    int sPxfIxBSiYvUVLq = -551607973;
    double xjIlmCAVzaI = 583283.2380209061;
    double yuuhBRAUinJ = -659691.0282528667;

    if (xjIlmCAVzaI <= 583283.2380209061) {
        for (int sbuyznbPVfjDxC = 794676561; sbuyznbPVfjDxC > 0; sbuyznbPVfjDxC--) {
            xjIlmCAVzaI = xjIlmCAVzaI;
            qQeYjIOPlotlbHbD *= qQeYjIOPlotlbHbD;
            sPxfIxBSiYvUVLq = sPxfIxBSiYvUVLq;
            qQeYjIOPlotlbHbD *= qQeYjIOPlotlbHbD;
        }
    }

    if (yuuhBRAUinJ <= -659691.0282528667) {
        for (int qIGQNUsOMiag = 1050733869; qIGQNUsOMiag > 0; qIGQNUsOMiag--) {
            xjIlmCAVzaI = xjIlmCAVzaI;
            sPxfIxBSiYvUVLq -= qQeYjIOPlotlbHbD;
        }
    }

    if (yuuhBRAUinJ < 583283.2380209061) {
        for (int hNnsUVLKLwavXYp = 415477859; hNnsUVLKLwavXYp > 0; hNnsUVLKLwavXYp--) {
            qQeYjIOPlotlbHbD = qQeYjIOPlotlbHbD;
            qQeYjIOPlotlbHbD /= sPxfIxBSiYvUVLq;
            sPxfIxBSiYvUVLq /= qQeYjIOPlotlbHbD;
        }
    }

    for (int xSCoPdkAfmvXJ = 312381241; xSCoPdkAfmvXJ > 0; xSCoPdkAfmvXJ--) {
        yuuhBRAUinJ *= yuuhBRAUinJ;
        sPxfIxBSiYvUVLq = qQeYjIOPlotlbHbD;
    }

    for (int JLIUsZSDJFFnY = 620614913; JLIUsZSDJFFnY > 0; JLIUsZSDJFFnY--) {
        sPxfIxBSiYvUVLq /= qQeYjIOPlotlbHbD;
        sPxfIxBSiYvUVLq *= qQeYjIOPlotlbHbD;
        xjIlmCAVzaI *= yuuhBRAUinJ;
        sPxfIxBSiYvUVLq -= sPxfIxBSiYvUVLq;
        qQeYjIOPlotlbHbD = qQeYjIOPlotlbHbD;
    }

    if (yuuhBRAUinJ <= -659691.0282528667) {
        for (int AHDIPnzv = 1487879450; AHDIPnzv > 0; AHDIPnzv--) {
            qQeYjIOPlotlbHbD -= sPxfIxBSiYvUVLq;
            xjIlmCAVzaI -= xjIlmCAVzaI;
            xjIlmCAVzaI *= xjIlmCAVzaI;
            yuuhBRAUinJ /= yuuhBRAUinJ;
            yuuhBRAUinJ = yuuhBRAUinJ;
            sPxfIxBSiYvUVLq *= sPxfIxBSiYvUVLq;
            yuuhBRAUinJ = xjIlmCAVzaI;
        }
    }

    return false;
}

void kHZvLvCbixka::zDWVusrx(string EcctVbUyjAHR, double uBOSnPSFpgXYV, double kmFYiCcjBxeN, double XXvFVzGOG)
{
    int FAtye = -136357242;
    int uUoVSZJnFbdc = -1183132700;
    int ABGWGvtT = -1219014117;
    int YwxgtvgveFuyCoWm = 652264339;
    int vOMqAMDW = 469149507;
    int ZVvorg = 235552391;

    if (ABGWGvtT > -1183132700) {
        for (int ZQEHGm = 863632435; ZQEHGm > 0; ZQEHGm--) {
            ZVvorg *= vOMqAMDW;
        }
    }
}

int kHZvLvCbixka::xtcCAmrbBiSr(int vJlNk, bool ikftaHWcaAsOGu, double nYbTWAAHYwcQoJmY)
{
    int FfsIb = -1930519832;
    double fVwWbozBsc = -212377.4069288205;

    for (int IuYIr = 1524506956; IuYIr > 0; IuYIr--) {
        continue;
    }

    for (int NfjDKmDSxvY = 281492960; NfjDKmDSxvY > 0; NfjDKmDSxvY--) {
        nYbTWAAHYwcQoJmY -= nYbTWAAHYwcQoJmY;
    }

    for (int bAmTsoJmYNiqo = 57552432; bAmTsoJmYNiqo > 0; bAmTsoJmYNiqo--) {
        nYbTWAAHYwcQoJmY = nYbTWAAHYwcQoJmY;
        fVwWbozBsc += fVwWbozBsc;
        fVwWbozBsc *= fVwWbozBsc;
    }

    return FfsIb;
}

string kHZvLvCbixka::HojuiLHHGVfN()
{
    int BwbduHShTWKZEich = -753583307;
    string xxFmbFZBkwUu = string("osmLTdfuedje");
    int wsstsLVBb = -52500940;

    if (BwbduHShTWKZEich == -52500940) {
        for (int IeBaaTaHHSLiFTBQ = 1065504759; IeBaaTaHHSLiFTBQ > 0; IeBaaTaHHSLiFTBQ--) {
            BwbduHShTWKZEich = BwbduHShTWKZEich;
            wsstsLVBb -= BwbduHShTWKZEich;
            xxFmbFZBkwUu += xxFmbFZBkwUu;
            xxFmbFZBkwUu = xxFmbFZBkwUu;
        }
    }

    if (BwbduHShTWKZEich == -52500940) {
        for (int bQMwH = 1474355904; bQMwH > 0; bQMwH--) {
            continue;
        }
    }

    for (int LXzvRYDdlEXL = 208645036; LXzvRYDdlEXL > 0; LXzvRYDdlEXL--) {
        continue;
    }

    if (wsstsLVBb < -753583307) {
        for (int NqSAtcjXfJiBQX = 823485467; NqSAtcjXfJiBQX > 0; NqSAtcjXfJiBQX--) {
            continue;
        }
    }

    if (wsstsLVBb != -753583307) {
        for (int HnUnkPpdGkY = 830401659; HnUnkPpdGkY > 0; HnUnkPpdGkY--) {
            wsstsLVBb += BwbduHShTWKZEich;
            wsstsLVBb *= BwbduHShTWKZEich;
            wsstsLVBb = wsstsLVBb;
            wsstsLVBb /= BwbduHShTWKZEich;
        }
    }

    return xxFmbFZBkwUu;
}

bool kHZvLvCbixka::zgpbuZPaUkISwWau(int HykYMAdoWIdvWmH, double YCiVxLfyyaIOOr, int koiLOQlTfDDbrJ)
{
    string uOPiL = string("cTTQLWcXYnPcQmJfKJwbxuhwqKVkZRyqFIVyJBVhPzJqfWrBERPPskhSDwINJgUWjnNtVuYsKfIkdYdqarSzqOGVKwguryxKaDzwEdYzPauQjFMTwsasaLaJEooIzratEpaCUdZoPfvpFQtfeunWQTPYXLgLuXItzPxiJqssZFmgClzLKxFswrPpqOmUfchVHdIdiATlMExqrBjYr");
    bool eZBYEubl = false;
    string uknQqoPiMAJi = string("pGHnHmeYIRQDNESBqnXbcHrravcoZePPPKHUXfwcWVWkwPeQBXRemtAIEwKFVntoNjqBExhKxWTmuolBywYknNoFgSXcUWsmThJZoJNrVSqxOMUohctcORAwiLXBEDpIfYAcFvoqoxRJlqugFjJcljLTOKrBtRaTuBQvDLppzpfYLSBGpovpEvBvWuoTIXodMTahUfquSDVxHsvYemTbrghpWzUzlSmnYXOqfLAD");
    int OXBJBi = 1085806664;
    string TciDtXWcvQcnccOr = string("YWtelTNvacZRWTSmHoORXjzfsGRrhMajmZikpZipxMOFZcChOjrh");
    string OknJiRnVgGDYL = string("zhJjFsiQnBDfUEoJAmytMULinCNHcGTtnqulcqPWQByCPvTBfvHFvedXZQVHNvnmuMSrsDWgUbhFedMomrDLKqtOtBMMTHQkSLitDqKaEFlIboXMCfeRLHldoltcTCrLzJuvulcEZOkZTUkNbYVCpYfUVXrtglRJQmTQTfRqnMuBtAIjDqfHxY");

    for (int GXKwVZKFxOHC = 651026565; GXKwVZKFxOHC > 0; GXKwVZKFxOHC--) {
        TciDtXWcvQcnccOr = uknQqoPiMAJi;
    }

    if (eZBYEubl != false) {
        for (int rAwbODKqxlJHZsSX = 2081927821; rAwbODKqxlJHZsSX > 0; rAwbODKqxlJHZsSX--) {
            uknQqoPiMAJi = uOPiL;
            uknQqoPiMAJi = TciDtXWcvQcnccOr;
        }
    }

    if (OknJiRnVgGDYL != string("cTTQLWcXYnPcQmJfKJwbxuhwqKVkZRyqFIVyJBVhPzJqfWrBERPPskhSDwINJgUWjnNtVuYsKfIkdYdqarSzqOGVKwguryxKaDzwEdYzPauQjFMTwsasaLaJEooIzratEpaCUdZoPfvpFQtfeunWQTPYXLgLuXItzPxiJqssZFmgClzLKxFswrPpqOmUfchVHdIdiATlMExqrBjYr")) {
        for (int SyiLCCsGR = 1286635890; SyiLCCsGR > 0; SyiLCCsGR--) {
            OXBJBi = OXBJBi;
            koiLOQlTfDDbrJ -= koiLOQlTfDDbrJ;
        }
    }

    if (uknQqoPiMAJi < string("zhJjFsiQnBDfUEoJAmytMULinCNHcGTtnqulcqPWQByCPvTBfvHFvedXZQVHNvnmuMSrsDWgUbhFedMomrDLKqtOtBMMTHQkSLitDqKaEFlIboXMCfeRLHldoltcTCrLzJuvulcEZOkZTUkNbYVCpYfUVXrtglRJQmTQTfRqnMuBtAIjDqfHxY")) {
        for (int GmhxzmN = 565501349; GmhxzmN > 0; GmhxzmN--) {
            uknQqoPiMAJi = uOPiL;
        }
    }

    return eZBYEubl;
}

string kHZvLvCbixka::LkpqWWAjiKVabTGy(bool CzKoCMC, string zXUfJTaPuYaQiOO, string BZlvCcWileJ)
{
    int BssmM = 1726351904;
    double loYFtLDvrlGf = 762650.9462005856;
    bool WKFyCOafnRze = false;
    int WIVWtemIExxT = 863853848;
    string qlwVbnXnXTYLi = string("UusOvtdMNAGvgxoIxMoKhHTlfZcdTFHJirQmMgvLcWYhGlznXOMLtvdSOmacwaVzhHUQZeujhxYItxsPYSbKz");
    double sqDQZf = -587612.2127307344;
    double StXPSVQeLY = 589027.7617926638;

    for (int wJZwQPwyJQLNzQR = 911702080; wJZwQPwyJQLNzQR > 0; wJZwQPwyJQLNzQR--) {
        zXUfJTaPuYaQiOO += zXUfJTaPuYaQiOO;
        sqDQZf /= sqDQZf;
    }

    return qlwVbnXnXTYLi;
}

kHZvLvCbixka::kHZvLvCbixka()
{
    this->OSvRIOP();
    this->zDWVusrx(string("PhpOygvzzavEVaynWrRTboIFHFLHNKGhVrIjnWlTuNbbPA"), -314097.20353095484, 919569.6837739795, 781609.5784679339);
    this->xtcCAmrbBiSr(183781084, false, -658444.2199922586);
    this->HojuiLHHGVfN();
    this->zgpbuZPaUkISwWau(-639372058, -525033.5887036503, 788144266);
    this->LkpqWWAjiKVabTGy(true, string("FrxV"), string("UuFuXokmxJfJRsDcgPJYTeJXehDogCRsDLlMphVNmVUuPoSRDeaHdOaYEfbgxgdPRgccexGxHWuHfVaDJmwwmnFSNrWPRRLwYLJfhoXzFfDLyOTXppylsJeldgkApEAokEODoshgolyMvYHqHNSZrZGUyJqREuFxmQSOpIaZCxHOthNfYtkJRQsaWTRzAbTy"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class NtcjK
{
public:
    int tONACkgTkxTE;
    string ROPDA;
    string HiPqa;
    double FCKWkxBHNpNIVR;

    NtcjK();
    double zCaBdEQuK();
    bool wvpZbFtxopPuS(double PNlvEDVNYGeavk, double aXaPwUfjhlhu, double HdHThJlhg);
    bool waMbRsYfP(int zRheY, int pYBHfSFAJoMijS);
    void CJQeVHN();
    int QpiSGGvPgcD(int QkaTDRy, int DeurmpM, string RAvNwjeBkVpvg, double iNDuyBPGccR, string mMkpYLhLEswdxK);
protected:
    int wrzrtsxeCfw;

    double XSoXfxEEayhBJYUB(string fBZalgJmjAYg, int yWruvnlDcNRlAw, int eplHvOKyG);
    double ZTkHU(string SOCFidbFCrNR, double NDfCVE, double puEtCuiILdYjO, int FUmxGYCV, string rcBqDklH);
    bool VVTJUQPT(double JRdJIeRu, int kSfTQYFtzrG);
private:
    string bKMNmLOEGJTB;

    string AqgaTSQpLBpTxi(int JVEgBmIU, int cFAkiRng, int FDQsDVJgCVGR, double BvsXh);
    int FETTimCACGOwHE();
    int sAnYztBFCXXns(bool pUAchFyT, int oFyvzXgTc);
};

double NtcjK::zCaBdEQuK()
{
    bool MCZgk = false;
    double plJCy = 100451.40488724182;
    double mEpzMadeDybuwxE = -496297.8738213636;

    if (plJCy != -496297.8738213636) {
        for (int EXkLkdR = 1437014562; EXkLkdR > 0; EXkLkdR--) {
            plJCy *= plJCy;
            MCZgk = ! MCZgk;
        }
    }

    if (MCZgk != false) {
        for (int tTlCPrqShXzZNyq = 941915812; tTlCPrqShXzZNyq > 0; tTlCPrqShXzZNyq--) {
            mEpzMadeDybuwxE /= plJCy;
            mEpzMadeDybuwxE -= plJCy;
            plJCy /= plJCy;
            plJCy *= plJCy;
            mEpzMadeDybuwxE = plJCy;
            plJCy = mEpzMadeDybuwxE;
            mEpzMadeDybuwxE /= plJCy;
        }
    }

    for (int dxHrnVoGclFeUv = 1189775560; dxHrnVoGclFeUv > 0; dxHrnVoGclFeUv--) {
        mEpzMadeDybuwxE += plJCy;
        plJCy = mEpzMadeDybuwxE;
        MCZgk = MCZgk;
        mEpzMadeDybuwxE *= plJCy;
        mEpzMadeDybuwxE -= plJCy;
        plJCy += mEpzMadeDybuwxE;
    }

    for (int YunMxaxMzTvFXQg = 855767670; YunMxaxMzTvFXQg > 0; YunMxaxMzTvFXQg--) {
        mEpzMadeDybuwxE -= plJCy;
        mEpzMadeDybuwxE += plJCy;
        plJCy = plJCy;
    }

    for (int vGrvJemzSVifFxv = 1321583195; vGrvJemzSVifFxv > 0; vGrvJemzSVifFxv--) {
        mEpzMadeDybuwxE += mEpzMadeDybuwxE;
        plJCy += plJCy;
        MCZgk = ! MCZgk;
        mEpzMadeDybuwxE -= mEpzMadeDybuwxE;
        plJCy *= plJCy;
    }

    return mEpzMadeDybuwxE;
}

bool NtcjK::wvpZbFtxopPuS(double PNlvEDVNYGeavk, double aXaPwUfjhlhu, double HdHThJlhg)
{
    string IoctxShoL = string("mTCkEKsdwfZwJiWowCyYBzFlbSjbvGLriVePLwddQgewrZNXQTWdNxifBteVKamjFXOcgBMSuQhaxMZqbJAMYPLKZtxWrmNirQdoU");
    int DbOAeZwCgLECuGx = 260227263;
    string gIxpanCql = string("CYfKBKDHwlYFRBtqoiMGTwawCNplrUljDdKDzGaMuuScMgkAkkoSnQIWjqBqVroLZzhLTeGPcsKKdAobKxDmlct");
    int YBwJxwXXAz = -1326556272;
    string BOUThQWaWqwanVqX = string("txlLXquINoSRrSQMgrcfafPoSCiLBChQPICFYhZArITVefIsIbDIuiENsEhdVajgvSGifgaUKJPMOLzzkJYPpMMmghySgjqgzovPCIpGMuXCooqHH");

    return false;
}

bool NtcjK::waMbRsYfP(int zRheY, int pYBHfSFAJoMijS)
{
    double ObIQKy = -937457.7640175035;
    string vxrErsVRPOVbBUe = string("oqimOImhgPhlWhkhgQjkGQrPFdkpGflTQmcqOzOFMspTdUaPHVBtLSVDbGkDXMAJSZdDyVKwCaWXVnYynsbeAhfuvmkhjPxjSqtjYYQNWqwANbIbRZq");
    bool QMGpfTNpZ = false;
    bool AWqXxisAY = true;
    int fmUlam = -424273393;
    double WGAJIAgyd = -609012.1853824875;
    double gPFpvnKKTFiAXSeY = 325671.81824931584;
    double EiuQhpImLyGkFD = -62678.87475884308;

    if (fmUlam > -84643765) {
        for (int iXikTSGjugtNoN = 467721158; iXikTSGjugtNoN > 0; iXikTSGjugtNoN--) {
            ObIQKy *= gPFpvnKKTFiAXSeY;
        }
    }

    for (int XDHRd = 1613567707; XDHRd > 0; XDHRd--) {
        EiuQhpImLyGkFD *= ObIQKy;
    }

    if (gPFpvnKKTFiAXSeY == -609012.1853824875) {
        for (int eTkYWSV = 1751638277; eTkYWSV > 0; eTkYWSV--) {
            gPFpvnKKTFiAXSeY /= EiuQhpImLyGkFD;
            WGAJIAgyd /= ObIQKy;
        }
    }

    return AWqXxisAY;
}

void NtcjK::CJQeVHN()
{
    double sCvaJJ = 360262.0369750318;
    string hNvSbrwyfiOJUSo = string("URXGzUJQYyQSWuxZpaFOEckLFtswfsiyvusBJvkWZbZSQIaGyfvvrCLGuaqXqXLhubTFFpHSwVGWWvQAqBRPNfAsQRWjDqCizKRSujbQzSeclRhsKkhEFQNtNkGSNBJMgbB");
    double QCcyjyesNdvuqQX = -657165.3437806646;

    if (hNvSbrwyfiOJUSo > string("URXGzUJQYyQSWuxZpaFOEckLFtswfsiyvusBJvkWZbZSQIaGyfvvrCLGuaqXqXLhubTFFpHSwVGWWvQAqBRPNfAsQRWjDqCizKRSujbQzSeclRhsKkhEFQNtNkGSNBJMgbB")) {
        for (int EtsHuVZuE = 1633422549; EtsHuVZuE > 0; EtsHuVZuE--) {
            continue;
        }
    }

    for (int jYBrOuRhB = 1528688777; jYBrOuRhB > 0; jYBrOuRhB--) {
        hNvSbrwyfiOJUSo = hNvSbrwyfiOJUSo;
        sCvaJJ *= QCcyjyesNdvuqQX;
        sCvaJJ -= QCcyjyesNdvuqQX;
        hNvSbrwyfiOJUSo = hNvSbrwyfiOJUSo;
        hNvSbrwyfiOJUSo = hNvSbrwyfiOJUSo;
        sCvaJJ -= QCcyjyesNdvuqQX;
        hNvSbrwyfiOJUSo += hNvSbrwyfiOJUSo;
    }

    for (int BoxrVi = 507841032; BoxrVi > 0; BoxrVi--) {
        QCcyjyesNdvuqQX = QCcyjyesNdvuqQX;
    }
}

int NtcjK::QpiSGGvPgcD(int QkaTDRy, int DeurmpM, string RAvNwjeBkVpvg, double iNDuyBPGccR, string mMkpYLhLEswdxK)
{
    double fTTbqwLHnnlJpfBQ = 492597.80923793965;
    string QkRbPjXsFLdvcKZ = string("KKCczmzpBjNcquWPYbZbGcEtqkpWZREECNqgLlZHvLbsKBkgboSmRfrLWVLGxZSPqGHpDbcMcykAYPOUsosZkgXPZppCnmAMOYhVvQggaaUTOYAsirARYDECJXaFPeDLcfnvMtlsixZdxppkSxuHGqHwMikvEfTqLgDUKOHeWTgqVuZEzHvZCwoNuqpICnkcyzRCxJyu");
    int gKRlDXIfyHXL = -19070224;
    double dnWpCfJf = 123555.32469528505;
    string QIGOcErroCVibpPS = string("lUvNAKekmFuFimCIzQBTvkueyIEWnEjqRWRrHXPhdibrTYskMQVRgVPkaRvePWGeLQIYnXDNkcePEBHSAYDoaLovPRDpAvRdgvagQsEyjlKILgwvXSakLMg");
    double XRazXMRHRBnz = 84432.66776823961;
    int tpNUNVpCED = 1523725691;
    int yyhLV = 2086117565;
    bool qLuyT = false;

    return yyhLV;
}

double NtcjK::XSoXfxEEayhBJYUB(string fBZalgJmjAYg, int yWruvnlDcNRlAw, int eplHvOKyG)
{
    bool DZuQCnmYqa = false;

    for (int rpdXHl = 1070234844; rpdXHl > 0; rpdXHl--) {
        eplHvOKyG -= eplHvOKyG;
        yWruvnlDcNRlAw = eplHvOKyG;
    }

    for (int sLojlAtz = 57819374; sLojlAtz > 0; sLojlAtz--) {
        fBZalgJmjAYg += fBZalgJmjAYg;
    }

    for (int tHedMCvVJ = 998314367; tHedMCvVJ > 0; tHedMCvVJ--) {
        yWruvnlDcNRlAw *= yWruvnlDcNRlAw;
        eplHvOKyG *= eplHvOKyG;
        yWruvnlDcNRlAw /= eplHvOKyG;
    }

    return 926443.4000482799;
}

double NtcjK::ZTkHU(string SOCFidbFCrNR, double NDfCVE, double puEtCuiILdYjO, int FUmxGYCV, string rcBqDklH)
{
    string hSpkZSXCMTAC = string("dcOwOdAWxKcgjfKDwDpQLWPWLoxMWsHhZqGJFpwiAlRtalyadessVgQLqgxgiutyCUjqHCBcvMCUJWmqXOkoPqJKuBsrPbibioaqootvnFwsQlgFkNYdcEXMujKujbXCqmLoYLyGiuTYBOcFwrubPghfWxHLwJVtrNrc");
    double kinthLtwt = -525296.1506436069;
    int naEPQlzSEgf = 1418870208;

    for (int SsiEQyDLQDhvb = 666150225; SsiEQyDLQDhvb > 0; SsiEQyDLQDhvb--) {
        continue;
    }

    return kinthLtwt;
}

bool NtcjK::VVTJUQPT(double JRdJIeRu, int kSfTQYFtzrG)
{
    int SzuFN = -817728415;
    bool votGCxll = false;
    int YVRTL = -1998254449;
    string RDWMEZfUP = string("oqcPUdvYeYvNIhOIinNQRruHrnAnQGwjBqXNBZPUXHelRGaMNfqNBYKmDYNt");
    int IzRFbpR = -1378955447;
    int QwZXeQhnGrfMazz = 1167970789;
    int QCOXXdLVJKT = 458206754;
    bool mLvhcTcK = true;
    double jVizTJzPX = -484602.7543854943;

    for (int vcfJNldPUDRgoM = 1174608925; vcfJNldPUDRgoM > 0; vcfJNldPUDRgoM--) {
        kSfTQYFtzrG -= QCOXXdLVJKT;
        SzuFN = kSfTQYFtzrG;
        SzuFN += QCOXXdLVJKT;
    }

    if (IzRFbpR != 458206754) {
        for (int UKyAygMqdg = 795435076; UKyAygMqdg > 0; UKyAygMqdg--) {
            QwZXeQhnGrfMazz -= QCOXXdLVJKT;
            IzRFbpR = YVRTL;
            SzuFN /= SzuFN;
        }
    }

    for (int VTdACu = 1724501157; VTdACu > 0; VTdACu--) {
        IzRFbpR = SzuFN;
    }

    for (int ZhCDpU = 1311793077; ZhCDpU > 0; ZhCDpU--) {
        SzuFN -= SzuFN;
        IzRFbpR += IzRFbpR;
        YVRTL -= QwZXeQhnGrfMazz;
    }

    for (int qrJVQWUdvWt = 954247702; qrJVQWUdvWt > 0; qrJVQWUdvWt--) {
        votGCxll = mLvhcTcK;
    }

    return mLvhcTcK;
}

string NtcjK::AqgaTSQpLBpTxi(int JVEgBmIU, int cFAkiRng, int FDQsDVJgCVGR, double BvsXh)
{
    bool DevnZOfFTlQ = true;
    double XBuksVffvsgkIxCz = 987599.120417494;

    for (int oISyQ = 177160311; oISyQ > 0; oISyQ--) {
        FDQsDVJgCVGR -= FDQsDVJgCVGR;
        cFAkiRng -= JVEgBmIU;
    }

    for (int iZVilfEhXRXP = 1013247868; iZVilfEhXRXP > 0; iZVilfEhXRXP--) {
        JVEgBmIU = FDQsDVJgCVGR;
    }

    for (int KFnaclXgu = 2017649499; KFnaclXgu > 0; KFnaclXgu--) {
        BvsXh += XBuksVffvsgkIxCz;
    }

    for (int EDHcJeXXCBHl = 1470853118; EDHcJeXXCBHl > 0; EDHcJeXXCBHl--) {
        XBuksVffvsgkIxCz = XBuksVffvsgkIxCz;
    }

    for (int kksSMaprnf = 1412319115; kksSMaprnf > 0; kksSMaprnf--) {
        continue;
    }

    if (FDQsDVJgCVGR >= 1483325348) {
        for (int hYmSMAOzdUpijR = 413813992; hYmSMAOzdUpijR > 0; hYmSMAOzdUpijR--) {
            continue;
        }
    }

    return string("aWLdepEdaoxnftvYhXjxwFssbTkGJIcCgyHfxtWgpRPrTOtZuAWyOOQXVIPMphrrIiGYxjuISpbWcHEuIBWXgkMNkiHcHTRCgDNvZuzwhtDLhrYnjfFxAoiDPfzQXngjQdocVhmnXhGETJqlGmtIQAZmUiVOSpmAuGswKISfzNwyjSqlEHaWhFqyXmIpWAeqjlYKDSPWKPGNFmTjUZfkurVxUzCplOUGstySzY");
}

int NtcjK::FETTimCACGOwHE()
{
    string jRIBcgTjpubn = string("gjXeYPuKRCGJEEIgzkhHFzPKgAcgcSINOGXhhRWZJzVAsmRSPIVcrwxkvrCAbrjtGNtmqLUIVVNGPxjvLhKRGkseZCwHQwJfHphFMiRkNYiAICPzYAdsAJUSoASzcGqGdTmnGDLlhRCAONWKexxHkLOgsvmNWBcSbRrnDJgOykVzacDuJgHV");
    string FOYsOHsVcgjZuR = string("MbiGergpkxhkBtmiEOOVhFhywRonTgwYXDgPvMgjtJESlCPMFbRyajLnVYstr");
    bool tFUAsJbc = false;
    int vnSyMNMouBMrV = -2073327192;

    if (FOYsOHsVcgjZuR == string("gjXeYPuKRCGJEEIgzkhHFzPKgAcgcSINOGXhhRWZJzVAsmRSPIVcrwxkvrCAbrjtGNtmqLUIVVNGPxjvLhKRGkseZCwHQwJfHphFMiRkNYiAICPzYAdsAJUSoASzcGqGdTmnGDLlhRCAONWKexxHkLOgsvmNWBcSbRrnDJgOykVzacDuJgHV")) {
        for (int LPENWcrx = 335263988; LPENWcrx > 0; LPENWcrx--) {
            jRIBcgTjpubn = FOYsOHsVcgjZuR;
            FOYsOHsVcgjZuR = FOYsOHsVcgjZuR;
            jRIBcgTjpubn += FOYsOHsVcgjZuR;
        }
    }

    if (FOYsOHsVcgjZuR > string("gjXeYPuKRCGJEEIgzkhHFzPKgAcgcSINOGXhhRWZJzVAsmRSPIVcrwxkvrCAbrjtGNtmqLUIVVNGPxjvLhKRGkseZCwHQwJfHphFMiRkNYiAICPzYAdsAJUSoASzcGqGdTmnGDLlhRCAONWKexxHkLOgsvmNWBcSbRrnDJgOykVzacDuJgHV")) {
        for (int GPMkLkxqa = 1097452011; GPMkLkxqa > 0; GPMkLkxqa--) {
            jRIBcgTjpubn = jRIBcgTjpubn;
            tFUAsJbc = tFUAsJbc;
            FOYsOHsVcgjZuR = jRIBcgTjpubn;
            tFUAsJbc = ! tFUAsJbc;
            vnSyMNMouBMrV -= vnSyMNMouBMrV;
            tFUAsJbc = ! tFUAsJbc;
            FOYsOHsVcgjZuR += jRIBcgTjpubn;
        }
    }

    for (int PXVFWg = 603703067; PXVFWg > 0; PXVFWg--) {
        FOYsOHsVcgjZuR = jRIBcgTjpubn;
    }

    for (int ECaHSq = 1911878445; ECaHSq > 0; ECaHSq--) {
        FOYsOHsVcgjZuR = jRIBcgTjpubn;
        tFUAsJbc = ! tFUAsJbc;
    }

    return vnSyMNMouBMrV;
}

int NtcjK::sAnYztBFCXXns(bool pUAchFyT, int oFyvzXgTc)
{
    double NgyWPGnAvyrHfHQ = -189530.81789682395;
    int HzrVWWxsN = -1587601546;
    bool YriMexQxsAUg = false;
    int mElYpRi = 209563005;
    double iHoZDDhVCuqa = -1037778.312069122;
    double XZkkXKOckdJJrjUb = 348884.26089958986;
    double iYyqrsiw = 666087.4513545443;

    for (int WCxKSkOrHYfUE = 1052734064; WCxKSkOrHYfUE > 0; WCxKSkOrHYfUE--) {
        continue;
    }

    return mElYpRi;
}

NtcjK::NtcjK()
{
    this->zCaBdEQuK();
    this->wvpZbFtxopPuS(261292.79378185855, -1013192.0624114807, 84493.55633435915);
    this->waMbRsYfP(-84643765, -1802124855);
    this->CJQeVHN();
    this->QpiSGGvPgcD(2120237553, -13072878, string("pqkoVjnaEygZwMkFwdySIlUVeklldL"), 807692.8004458488, string("GMEBSLfqyNanmlPvbYZOdEvvwpAVlDyXDsVGzTIEQnMElFwElUTPVvoHWNlWPhbYfnjgampdJKSMpHriOsXgCzRCVQxPukLvgWZxIExYGVNJBMvaiPE"));
    this->XSoXfxEEayhBJYUB(string("lUXccaDIadajIIoCmyiUIYDDtSNGEsjqmccDrpUygqlcIMhcbc"), -527211962, -1354308807);
    this->ZTkHU(string("zZwAiEdTRMHQYsqRsEskUrVOmYyYrerUGXbiqRXidgCtvRPIzcYbjhuNUiXIuklbijkDvZkAmtGeMIBgnoXginIVBJjiXdqyrVFRKDOJzbZftnyiJRUvovwJrHgZHvFlBlxJQizLeDIIJGEMMaRvPHeYgGELXQXmRENooLnVzGwideDuVXtQZ"), 192277.12453090947, 493054.6424771922, -1877954169, string("UoHhkIW"));
    this->VVTJUQPT(498798.0581393754, -1384656905);
    this->AqgaTSQpLBpTxi(-399568832, 1483325348, 21511508, 332614.6929074989);
    this->FETTimCACGOwHE();
    this->sAnYztBFCXXns(false, -2093535172);
}
