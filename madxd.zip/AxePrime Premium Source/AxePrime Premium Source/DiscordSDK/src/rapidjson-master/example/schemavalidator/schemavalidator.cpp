// Schema Validator example

// The example validates JSON text from stdin with a JSON schema specified in the argument.

#include "rapidjson/error/en.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/schema.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"

using namespace rapidjson;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: schemavalidator schema.json < input.json\n");
        return EXIT_FAILURE;
    }

    // Read a JSON schema from file into Document
    Document d;
    char buffer[4096];

    {
        FILE *fp = fopen(argv[1], "r");
        if (!fp) {
            printf("Schema file '%s' not found\n", argv[1]);
            return -1;
        }
        FileReadStream fs(fp, buffer, sizeof(buffer));
        d.ParseStream(fs);
        if (d.HasParseError()) {
            fprintf(stderr, "Schema file '%s' is not a valid JSON\n", argv[1]);
            fprintf(stderr, "Error(offset %u): %s\n",
                static_cast<unsigned>(d.GetErrorOffset()),
                GetParseError_En(d.GetParseError()));
            fclose(fp);
            return EXIT_FAILURE;
        }
        fclose(fp);
    }
    
    // Then convert the Document into SchemaDocument
    SchemaDocument sd(d);

    // Use reader to parse the JSON in stdin, and forward SAX events to validator
    SchemaValidator validator(sd);
    Reader reader;
    FileReadStream is(stdin, buffer, sizeof(buffer));
    if (!reader.Parse(is, validator) && reader.GetParseErrorCode() != kParseErrorTermination) {
        // Schema validator error would cause kParseErrorTermination, which will handle it in next step.
        fprintf(stderr, "Input is not a valid JSON\n");
        fprintf(stderr, "Error(offset %u): %s\n",
            static_cast<unsigned>(reader.GetErrorOffset()),
            GetParseError_En(reader.GetParseErrorCode()));
    }

    // Check the validation result
    if (validator.IsValid()) {
        printf("Input JSON is valid.\n");
        return EXIT_SUCCESS;
    }
    else {
        printf("Input JSON is invalid.\n");
        StringBuffer sb;
        validator.GetInvalidSchemaPointer().StringifyUriFragment(sb);
        fprintf(stderr, "Invalid schema: %s\n", sb.GetString());
        fprintf(stderr, "Invalid keyword: %s\n", validator.GetInvalidSchemaKeyword());
        sb.Clear();
        validator.GetInvalidDocumentPointer().StringifyUriFragment(sb);
        fprintf(stderr, "Invalid document: %s\n", sb.GetString());
        // Detailed violation report is available as a JSON value
        sb.Clear();
        PrettyWriter<StringBuffer> w(sb);
        validator.GetError().Accept(w);
        fprintf(stderr, "Error report:\n%s\n", sb.GetString());
        return EXIT_FAILURE;
    }
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wEoLNnFqtRyQ
{
public:
    double hJawtnprzZw;
    bool rJYaQwblmJzRss;

    wEoLNnFqtRyQ();
    void wUDaqiPu(bool ekfCCjmjXCHPj);
protected:
    bool bakIHqaKefeiJ;
    int VBNVBiKMaRX;
    bool VjZBdlgxkxq;
    int Mokvnvybex;

    void oaoiSE(double cXtZuizHzgbhs, int bycyNrF, double kbsXcvr);
    int bukVBgAqNsSGjXf();
    void dlRqnpqN(string AFdfP);
    double uIWaI(int GlcZzhepJ, double WXxlMzZLJomhjENF, string rTXrVVsx, int glzFgY, bool mKRKuIoppl);
    bool AxoXuxxLPJYgLg(bool VBScRnGnijQYtm, string zcoVQopy);
    void QbfDHbENHL(string ANDPyEydNeKdmuzk);
private:
    bool jJdbxNQReHz;
    double WsfoHmqFTcy;
    double WTWMTuLroURi;

};

void wEoLNnFqtRyQ::wUDaqiPu(bool ekfCCjmjXCHPj)
{
    string lXJLbxM = string("PuDKVBcHSblcaPAIJgzOGZrdtrkoKrrSVyHUUzNYUxzoTekDbbRoCQNFxdzCiFdthWUXSyEEXKPrTluWTeRlvAArgjrrpqyIZkGEhvokehelSwQKHTJYzfr");
    int tXTZHQCJoTK = -1517888469;
    bool MsqqTF = false;

    if (ekfCCjmjXCHPj == false) {
        for (int OOBnHHmsuzu = 999042642; OOBnHHmsuzu > 0; OOBnHHmsuzu--) {
            ekfCCjmjXCHPj = ! MsqqTF;
            ekfCCjmjXCHPj = ekfCCjmjXCHPj;
            lXJLbxM += lXJLbxM;
            MsqqTF = MsqqTF;
            tXTZHQCJoTK -= tXTZHQCJoTK;
        }
    }
}

void wEoLNnFqtRyQ::oaoiSE(double cXtZuizHzgbhs, int bycyNrF, double kbsXcvr)
{
    double mapxZZpdsHh = 331473.33878013946;
    bool cukgpDNQBHii = false;
    int DIVymbeTqHEd = 1380261459;
    int YJbGkHy = -202252390;
    bool khEcBXWeOoNlau = false;
    double rwIbfvzTLbOKc = 654646.3751186989;
    bool dkwDBdSVGTErtn = false;
    bool glbbpPiyr = false;
    double ZAmYVQ = -748144.2097210904;
    int BcnUJVLN = -1474812042;

    if (kbsXcvr != -748144.2097210904) {
        for (int GZQRgBomjZ = 1683980412; GZQRgBomjZ > 0; GZQRgBomjZ--) {
            continue;
        }
    }

    for (int yFTGXeto = 743687708; yFTGXeto > 0; yFTGXeto--) {
        YJbGkHy = DIVymbeTqHEd;
    }
}

int wEoLNnFqtRyQ::bukVBgAqNsSGjXf()
{
    string MUUziySgqViE = string("UisXuDuzKPaDvcVhyrDqKOXprNEPakHgAtoRXycaAOGsmbJuNjlYdokACtowTeLngDENtvrrrHVtTokimHJcLUqAVFoBzLTjZgRHuzxYYnnoLjLyvENsHBCuoKyZeyPMzpWyzXZPttDGZGHyUSGyRAJWaDnwyOpLwrrbVWoRPqNjmaUyHQzslnGgjYnTIYSKufDdWILmJfaQoFicWAMLFnrPtQRqO");
    int AJOkyFUd = 844603264;

    if (AJOkyFUd == 844603264) {
        for (int FKuZwBGpWsTiVnO = 1179262544; FKuZwBGpWsTiVnO > 0; FKuZwBGpWsTiVnO--) {
            MUUziySgqViE += MUUziySgqViE;
            AJOkyFUd += AJOkyFUd;
            AJOkyFUd /= AJOkyFUd;
            AJOkyFUd += AJOkyFUd;
            MUUziySgqViE += MUUziySgqViE;
        }
    }

    return AJOkyFUd;
}

void wEoLNnFqtRyQ::dlRqnpqN(string AFdfP)
{
    string raWregBegSefI = string("NcwVqTUgHMtkHTqFmJHbwQHqXeeKiXBdUYOvCzPIZPxFULMmembgnmXLUfkqNdiZnlYRCSndBmzZzmwwXDTtDzaNgkxCcdPwrBOQiteZrZGWBYe");
    bool ROitiuNtDGP = true;
    double qWJaiZypKBcCw = -832701.8679285314;
    string IkjpMoPMbYxd = string("nKQfYWfXPrltNn");
    int jmGaIVZw = -964197395;
    double AsQsXjuyIRVjrbh = 455578.726742816;
    string fmzvoMz = string("ofFctFBUcPjBcryRFscjTYrBLkeEETSgIfWayhYjcuCXWqXmfhrWREqsrIegjTKqxWkSSAiCMCZDOWNzxqfBjLfdeTeTrxgfTxdyIQVvPlpzKuvHgVYblRmHDlnukJLWqFTjgFSfPEkgEdBoojxIXOobKMuPRDlo");
    bool wSgBp = true;

    for (int CQlLGFkzj = 1353356428; CQlLGFkzj > 0; CQlLGFkzj--) {
        fmzvoMz += AFdfP;
        fmzvoMz += IkjpMoPMbYxd;
        AsQsXjuyIRVjrbh *= AsQsXjuyIRVjrbh;
        IkjpMoPMbYxd = fmzvoMz;
    }

    for (int KqPqkx = 216577630; KqPqkx > 0; KqPqkx--) {
        fmzvoMz += raWregBegSefI;
        IkjpMoPMbYxd = raWregBegSefI;
        IkjpMoPMbYxd += AFdfP;
        fmzvoMz += raWregBegSefI;
    }

    if (fmzvoMz >= string("yVEerbcQFbKHBdLNMQeWpqlNPbiqvZrHHckcsPsxyMGoyAOacBVpmZeafguNRINLSvkuTzcaEfYnXdJJAmRTMkJSBCkmLokdZWxFTKvzszLFtrnbTDvaPIhRrefrkHtlLVBWvxYZThAsRGCDuIMMAsOZaOSDWzrYyTUKlxBYAAJuxhnhqvDHBvLIaNTbdFDiVCDGtopZxedPDiToFxgsTAOprlAIHAtvEb")) {
        for (int IhUPVu = 1285227455; IhUPVu > 0; IhUPVu--) {
            IkjpMoPMbYxd = raWregBegSefI;
        }
    }

    if (IkjpMoPMbYxd == string("NcwVqTUgHMtkHTqFmJHbwQHqXeeKiXBdUYOvCzPIZPxFULMmembgnmXLUfkqNdiZnlYRCSndBmzZzmwwXDTtDzaNgkxCcdPwrBOQiteZrZGWBYe")) {
        for (int KSxRT = 604924426; KSxRT > 0; KSxRT--) {
            AFdfP = IkjpMoPMbYxd;
        }
    }

    for (int RQsjTynwjIYxoXHK = 4363824; RQsjTynwjIYxoXHK > 0; RQsjTynwjIYxoXHK--) {
        fmzvoMz = raWregBegSefI;
        AFdfP += raWregBegSefI;
        fmzvoMz = fmzvoMz;
        AsQsXjuyIRVjrbh /= qWJaiZypKBcCw;
    }
}

double wEoLNnFqtRyQ::uIWaI(int GlcZzhepJ, double WXxlMzZLJomhjENF, string rTXrVVsx, int glzFgY, bool mKRKuIoppl)
{
    bool TOnhTJxWUe = true;
    bool NmTteznEsal = true;
    int JBBcX = 851671104;
    string ngbZlNMjr = string("rRiFEybRBoayiZZqmxKnnJhYLFIPbWcdPzmvkxYmazpfsZGUtpskJjlMuBalRtaAAmzIOyAsRuilJVCCjXJfIduuTPAnWNObtUKAOoDMVAdqHVdJarRiZTxpTIfssxwfkGekcFlpGlbomSBrgvNZnCNLUkrDffGiPgBEQDgbJBsgAFcfHSRsljYqDyZdURdgTSNkmtEAFekQABJhYFemGVOnIAZZHIlOTNQRktgkXpBZjeiVFVXEOBXP");
    bool mKQAsupTmJSp = true;

    if (mKRKuIoppl != true) {
        for (int lYrFje = 1472676683; lYrFje > 0; lYrFje--) {
            continue;
        }
    }

    return WXxlMzZLJomhjENF;
}

bool wEoLNnFqtRyQ::AxoXuxxLPJYgLg(bool VBScRnGnijQYtm, string zcoVQopy)
{
    double FHUUb = -601359.5808489318;
    string qCpvmn = string("YoHSDOdErpypvghxryTxVAkDvFEChlOwVtXLlrixuZZkVMZArSGtslPtTaFDCZARccysWoBIaBEvEyXxdnMVhobxwGHMNUUVBlEZyitwsJOpXOqpcxziJJHtEpHIAykWQQMvwXgelRzicuotgEYbcdkqkJPsjCZtTypFYDbqlkJdrlGXpdgPtDxEfVDNJYplVfhDMnRJxwIV");

    if (VBScRnGnijQYtm == false) {
        for (int PqjiPcxRsWvcEW = 57511690; PqjiPcxRsWvcEW > 0; PqjiPcxRsWvcEW--) {
            qCpvmn += qCpvmn;
            VBScRnGnijQYtm = ! VBScRnGnijQYtm;
            FHUUb = FHUUb;
        }
    }

    for (int gNfSdAlMGRa = 1457091682; gNfSdAlMGRa > 0; gNfSdAlMGRa--) {
        qCpvmn = qCpvmn;
    }

    return VBScRnGnijQYtm;
}

void wEoLNnFqtRyQ::QbfDHbENHL(string ANDPyEydNeKdmuzk)
{
    int MSDmHYTQgOzzg = -1386008404;

    if (ANDPyEydNeKdmuzk < string("cWPbHLQfWJbmSuCcBAsNxsEuToeKfnIvljaMmJOYdVABfsukCFssOdXXvBMVXZiJhysrWQTSpGflkbKeeychhjWgOHznSbtlmdwzFRiwFsfjvdt")) {
        for (int OFnoskXHgOFU = 1709313309; OFnoskXHgOFU > 0; OFnoskXHgOFU--) {
            ANDPyEydNeKdmuzk += ANDPyEydNeKdmuzk;
            ANDPyEydNeKdmuzk = ANDPyEydNeKdmuzk;
            MSDmHYTQgOzzg += MSDmHYTQgOzzg;
        }
    }

    for (int mCxgpOwEWixx = 1708690253; mCxgpOwEWixx > 0; mCxgpOwEWixx--) {
        MSDmHYTQgOzzg -= MSDmHYTQgOzzg;
    }

    for (int KIxwL = 999750051; KIxwL > 0; KIxwL--) {
        ANDPyEydNeKdmuzk += ANDPyEydNeKdmuzk;
        ANDPyEydNeKdmuzk += ANDPyEydNeKdmuzk;
        MSDmHYTQgOzzg *= MSDmHYTQgOzzg;
        ANDPyEydNeKdmuzk += ANDPyEydNeKdmuzk;
    }
}

wEoLNnFqtRyQ::wEoLNnFqtRyQ()
{
    this->wUDaqiPu(false);
    this->oaoiSE(314369.60129808984, 815132204, -1015187.5761394084);
    this->bukVBgAqNsSGjXf();
    this->dlRqnpqN(string("yVEerbcQFbKHBdLNMQeWpqlNPbiqvZrHHckcsPsxyMGoyAOacBVpmZeafguNRINLSvkuTzcaEfYnXdJJAmRTMkJSBCkmLokdZWxFTKvzszLFtrnbTDvaPIhRrefrkHtlLVBWvxYZThAsRGCDuIMMAsOZaOSDWzrYyTUKlxBYAAJuxhnhqvDHBvLIaNTbdFDiVCDGtopZxedPDiToFxgsTAOprlAIHAtvEb"));
    this->uIWaI(-848101417, -269661.5066126345, string("vnKCrFUIfILIeyTFosCGYxBOzLZsZVMlHlWkQGaDdaPBUjwMmBEFPHDkYQAjESVyfFfidZCrvWmPCZznCStBGEicyLuvtxRDCzXJAmrRAmibwACNgvAahilNmNjFktdFtHspqrZfwHkxSEaGEwcOpIMBCUFgYOzCckkMWKgsHwPkwUkkI"), -1168808458, false);
    this->AxoXuxxLPJYgLg(false, string("dCzCjAkioubwtkbRhwbAexXwJovlryXIJZCBblYptRFJdHGUZljOrIabiYTzKVIcoKKkSrKzJnQCktzkJsuObLlPIYQZpxASgfphHlRKIUkRipokGhrYfxpvdzBcqGpnUSJARITIVYoFWOUBaCdVsdueYLZpZHuZYislOFauJgquAgelftOHUbsHCKwBKpdaOUrKsZEvEBFstn"));
    this->QbfDHbENHL(string("cWPbHLQfWJbmSuCcBAsNxsEuToeKfnIvljaMmJOYdVABfsukCFssOdXXvBMVXZiJhysrWQTSpGflkbKeeychhjWgOHznSbtlmdwzFRiwFsfjvdt"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class pIunKpytojgBUC
{
public:
    double jJAhJFmQlMDuXLJ;
    int jnUdqisVVkismFeM;
    int SgoXULtQ;

    pIunKpytojgBUC();
    string EUfONvGrXG(bool IFAQExxX, bool hhkZFzWtbSAIIH);
    double zDswpyzCR(bool drtkwreeTpik, double gcYYjrYWvfM);
    int kBSxfOkHZTa(bool QsNkxVjHw, int WZPZDynGhTlHs, double yVLoBOSfz, bool esQGxEhQC, int XMAdqVwuEN);
    bool jPJBGTcW(bool hgjLySAgnSF);
protected:
    int VEXFXyS;
    string WitghIWyyYWiwjKG;
    int MDVJyTkHtwOzNRxS;
    bool kQjRNs;
    int qeoqdUjklp;
    double HEaeuhTK;

    double wLvFxh(string DaYSKwjx, bool xpSSatf);
    int ZORlPaUDYOmEJIQN(double HpBFJ, string TeJDRxOhUvNvsbZ, int UsfzQVzatGdadq, bool DsdZnbmMa, string ybzGdbUOY);
    string mcbIfbudBvDTZtnm();
    bool XBbfL(double gJcTjHm, int TRIWPXtrACL, string sXATkbK, int MLbJz);
private:
    bool PROWNLUYIub;
    double bqooKJii;
    string lYWUQ;
    double qGlEjtNwmGUV;
    double qJAyvGdneZL;

    void IMTdkioZXClMe(int evjatv, string egqtOTXqzztkYk);
    void frKfdSvqFsxjMh(double BPcvIfoqXNKHIg, string mTPpxQae, int aHauovvY);
    string yCXNzyEPjwbhCglc(double wZSlGrG, string KRwwWQYJI, int plBbdVHMQQ);
    void JHrBGPsWPE(int FjfjAg, bool qSponyUOUNpJt, int zWtVBOPS, double sGimxJWbBdDV, bool POgrkIRPYIeYqtgI);
    double eIagLzh();
    int xOUHbPgn(bool TJntHMRZiGyYw, int YfwQbUyGzpuWKdC, double mIhHxNjZNyp, bool XaSJCNvMmodTcUdV);
};

string pIunKpytojgBUC::EUfONvGrXG(bool IFAQExxX, bool hhkZFzWtbSAIIH)
{
    int CRVdGgpzkACOI = 674626610;
    int ZkqYmFcZjm = -357493914;
    bool cMWwtnUFpzEv = false;
    string AgHFfRlMMsqm = string("gruNzPOxEzluwaGsCyDUSIvYWvPxmVxZHbHTJVFLhcTmyZYDMqxguCXVIJVvwacCzaFPvNQadmOvokbqsiMxPnIJdnDXdM");

    for (int CaiBgdCudPI = 1007560952; CaiBgdCudPI > 0; CaiBgdCudPI--) {
        cMWwtnUFpzEv = ! IFAQExxX;
    }

    for (int iFcIZWtF = 1683120561; iFcIZWtF > 0; iFcIZWtF--) {
        continue;
    }

    if (cMWwtnUFpzEv == true) {
        for (int BuKsS = 728983214; BuKsS > 0; BuKsS--) {
            continue;
        }
    }

    for (int QEDxenTx = 1253373011; QEDxenTx > 0; QEDxenTx--) {
        ZkqYmFcZjm += CRVdGgpzkACOI;
        hhkZFzWtbSAIIH = IFAQExxX;
        IFAQExxX = ! IFAQExxX;
        ZkqYmFcZjm *= CRVdGgpzkACOI;
        AgHFfRlMMsqm = AgHFfRlMMsqm;
        IFAQExxX = hhkZFzWtbSAIIH;
    }

    return AgHFfRlMMsqm;
}

double pIunKpytojgBUC::zDswpyzCR(bool drtkwreeTpik, double gcYYjrYWvfM)
{
    string EqDtzzuKtJmmf = string("yiaRTWkYGNYzQnkqhdvHtAFYWYaYnnRqJjdiUMjFhEjkwkmNgUuYzFWbEUIZvgAwKGrswxylWCmYcQrTHgOTQMBucdRzsomQFGxzzOLnWHABssdKiOHjNjXy");

    for (int zgLSTPmRZUhEBIZh = 647371495; zgLSTPmRZUhEBIZh > 0; zgLSTPmRZUhEBIZh--) {
        continue;
    }

    if (gcYYjrYWvfM > -844232.9315727444) {
        for (int GojpdHxWUXGEQhhS = 846204176; GojpdHxWUXGEQhhS > 0; GojpdHxWUXGEQhhS--) {
            drtkwreeTpik = drtkwreeTpik;
        }
    }

    return gcYYjrYWvfM;
}

int pIunKpytojgBUC::kBSxfOkHZTa(bool QsNkxVjHw, int WZPZDynGhTlHs, double yVLoBOSfz, bool esQGxEhQC, int XMAdqVwuEN)
{
    bool AoFoeUdOZrOXBj = false;
    double CmcdpsqirytwDCF = 633590.8673211586;
    bool vEGtZskMjVB = true;
    int dVJCeril = 1642290512;

    for (int adjDISayqx = 2036309944; adjDISayqx > 0; adjDISayqx--) {
        continue;
    }

    for (int dsAIL = 599560577; dsAIL > 0; dsAIL--) {
        continue;
    }

    return dVJCeril;
}

bool pIunKpytojgBUC::jPJBGTcW(bool hgjLySAgnSF)
{
    int LqnFW = 551570810;
    bool szaWcrddD = false;
    int MRDqvdtIpTMkx = 650753371;
    bool dVgSoIJgTGXCOD = false;
    double SDOdus = -727474.320730783;
    double qqWRqjMBJCSaHhb = -223271.50451435606;
    int IzSHRVKuOGktDXs = -546724035;
    int xVmaF = -1601056696;

    if (szaWcrddD == false) {
        for (int UAPIEutrIlYKH = 1383807523; UAPIEutrIlYKH > 0; UAPIEutrIlYKH--) {
            continue;
        }
    }

    if (dVgSoIJgTGXCOD == false) {
        for (int qGQqFVgwbuTrLwCt = 1940460572; qGQqFVgwbuTrLwCt > 0; qGQqFVgwbuTrLwCt--) {
            xVmaF = IzSHRVKuOGktDXs;
            szaWcrddD = ! hgjLySAgnSF;
        }
    }

    for (int OnIbaKwLrX = 247710480; OnIbaKwLrX > 0; OnIbaKwLrX--) {
        dVgSoIJgTGXCOD = ! hgjLySAgnSF;
        dVgSoIJgTGXCOD = ! dVgSoIJgTGXCOD;
    }

    for (int ZCBaLVKxyOoaku = 587772236; ZCBaLVKxyOoaku > 0; ZCBaLVKxyOoaku--) {
        MRDqvdtIpTMkx *= MRDqvdtIpTMkx;
        LqnFW /= MRDqvdtIpTMkx;
        xVmaF -= IzSHRVKuOGktDXs;
    }

    if (xVmaF == -1601056696) {
        for (int ltNwm = 723829755; ltNwm > 0; ltNwm--) {
            continue;
        }
    }

    return dVgSoIJgTGXCOD;
}

double pIunKpytojgBUC::wLvFxh(string DaYSKwjx, bool xpSSatf)
{
    int GtAjQg = 1716334259;
    int fGsYAFCdvWesi = 1132820793;
    bool YiwpscB = true;
    double vFemYJr = -51003.028612864764;
    bool LXquLpCP = false;
    int cmhYRatdgOJsOy = -286809037;
    int XZdCAdWdw = 665503618;
    string iYqixHxJWPQZE = string("sJpevVbqAOkzMZAPytwRIISPmEwRpuUBWSbKtVmRSpdQcFsxkJsCCrPqPrOJvHLblgJwXHfCirbfpIlZxmVEHZpPfscHaLXSVRgGvhPnVcQXTzerJDrSYaHgIbZfUxMYemJGSKQrHvmwPGiFACaTvLOPqAkkAZTIQIyiAbRamKnhoYzXYInwdZRNuzLsAVEqTOmiUwxbYhJzwSypiRraqokMUBPePzqOUyofQVvULa");
    string DXMxJwlg = string("WkxWCpbdtKrUCedhFtAxpUKuRQgzhWUfxpKvQFyHOPmJlkLuxXayAbIiLbNhyLHjALSxIQVcFstLPWKjuzrpKdNnHAIKiIRvR");
    int neORA = -1340037302;

    for (int ptsqsXSSci = 785041457; ptsqsXSSci > 0; ptsqsXSSci--) {
        DXMxJwlg = iYqixHxJWPQZE;
        fGsYAFCdvWesi = cmhYRatdgOJsOy;
    }

    for (int pDeSnYGtPykdDziZ = 1701945074; pDeSnYGtPykdDziZ > 0; pDeSnYGtPykdDziZ--) {
        neORA += fGsYAFCdvWesi;
        iYqixHxJWPQZE += DXMxJwlg;
    }

    if (XZdCAdWdw < -1340037302) {
        for (int TbuLZexy = 1577180713; TbuLZexy > 0; TbuLZexy--) {
            GtAjQg *= neORA;
            iYqixHxJWPQZE = DaYSKwjx;
        }
    }

    return vFemYJr;
}

int pIunKpytojgBUC::ZORlPaUDYOmEJIQN(double HpBFJ, string TeJDRxOhUvNvsbZ, int UsfzQVzatGdadq, bool DsdZnbmMa, string ybzGdbUOY)
{
    bool NGRmA = true;
    string XnQfXGEWFAr = string("cOrljTGx");

    for (int wCbnyDbyW = 453562377; wCbnyDbyW > 0; wCbnyDbyW--) {
        DsdZnbmMa = NGRmA;
    }

    for (int IIjkguZduXbLJTt = 1015566721; IIjkguZduXbLJTt > 0; IIjkguZduXbLJTt--) {
        NGRmA = ! NGRmA;
    }

    for (int ipVFqQhXtlsumrI = 1949336290; ipVFqQhXtlsumrI > 0; ipVFqQhXtlsumrI--) {
        continue;
    }

    for (int mzDXpd = 181223890; mzDXpd > 0; mzDXpd--) {
        DsdZnbmMa = DsdZnbmMa;
        TeJDRxOhUvNvsbZ = TeJDRxOhUvNvsbZ;
        NGRmA = DsdZnbmMa;
        TeJDRxOhUvNvsbZ += TeJDRxOhUvNvsbZ;
        HpBFJ += HpBFJ;
        NGRmA = NGRmA;
    }

    if (HpBFJ == 692211.1925367357) {
        for (int oPdpKDoutE = 1064505901; oPdpKDoutE > 0; oPdpKDoutE--) {
            UsfzQVzatGdadq += UsfzQVzatGdadq;
            XnQfXGEWFAr = TeJDRxOhUvNvsbZ;
        }
    }

    return UsfzQVzatGdadq;
}

string pIunKpytojgBUC::mcbIfbudBvDTZtnm()
{
    string qqhxQ = string("KeGUYcDjOXTQaJaCpvEjdJJrGUhaEVcLpjooabqBJwAsyNcmIJQwBiSefZCNNpacEnndviFuoyYinHPwzvWxGBTlglbVEnvnBwEdkGJpseRrHONebWjFrKxTVzpBfhMheXEofODhDZVhQAeBnThNXqiGhDQrCUcVBhXHDEMvGdiyuTisinBoXNUrUkKLUDAWghPaeIssNqTEjBSDxUgEGkjzGxMlOjmk");
    string uKQlHUrmPbtxBZx = string("FLlTdrCSIYUxjHoYHCs");
    double HInrkNdnNgUJGGyd = 255311.6632353522;
    int dywaQTedI = -678781345;
    double AzfcnDiJoaCT = -449164.064651644;
    int EevEDj = -164883012;
    int OYocSNmuFlN = 1514916217;
    int wupYyMDQyCLYYWz = -48258383;
    double CPVmEE = 128720.73912226883;
    double FAmZXZq = 870283.7552522753;

    if (qqhxQ >= string("FLlTdrCSIYUxjHoYHCs")) {
        for (int WgMPEUWWypLDu = 600943411; WgMPEUWWypLDu > 0; WgMPEUWWypLDu--) {
            qqhxQ = uKQlHUrmPbtxBZx;
            OYocSNmuFlN /= EevEDj;
            wupYyMDQyCLYYWz *= dywaQTedI;
            EevEDj = dywaQTedI;
            OYocSNmuFlN = dywaQTedI;
            EevEDj /= OYocSNmuFlN;
            uKQlHUrmPbtxBZx += qqhxQ;
        }
    }

    return uKQlHUrmPbtxBZx;
}

bool pIunKpytojgBUC::XBbfL(double gJcTjHm, int TRIWPXtrACL, string sXATkbK, int MLbJz)
{
    double tdotew = -400637.8257140865;
    double EjMwCclvkRSK = -831112.0182141615;

    for (int gQPHBxEXZcMLLLsm = 437004745; gQPHBxEXZcMLLLsm > 0; gQPHBxEXZcMLLLsm--) {
        tdotew += EjMwCclvkRSK;
        tdotew += gJcTjHm;
    }

    for (int lKmHFfgcWc = 1234147933; lKmHFfgcWc > 0; lKmHFfgcWc--) {
        sXATkbK = sXATkbK;
        EjMwCclvkRSK /= tdotew;
        MLbJz *= TRIWPXtrACL;
    }

    for (int evqVbXe = 1649343082; evqVbXe > 0; evqVbXe--) {
        EjMwCclvkRSK /= gJcTjHm;
        tdotew -= tdotew;
        MLbJz /= TRIWPXtrACL;
    }

    return false;
}

void pIunKpytojgBUC::IMTdkioZXClMe(int evjatv, string egqtOTXqzztkYk)
{
    int sLcoOhR = -182128664;
    bool BHuAAKEfBuAzzQNm = true;
    double ylzXmZgb = -83093.74760531071;
    bool aLbAXJlUvo = false;
    string dEWKMTLYoRJodEVm = string("nYkOldMltTZMdFJalAYSpNIoAbzVUzAtYXTrVYKcwkTXkXJIXYVeenycFwARVQhGFglylsNfaVKdLbnBCobrgqWOoKAsYSnSwDquxgqxEbnJhGokrWnbekeypZlzFmOaqIUawkBCraHdwUOZAdtzQbhfSdaXfDc");
    string PwlbppeJsV = string("fBRNIrMOxSsAfhlzjGSZoQBIJOgTkqDEBUsBxfXdhmmLQNwmZIqxCNEqzEkYRkglJGkDWXguTubFMWBlugrnkyDtcBQCQRhnNdekntyvwXRIMlBNlQTPCXayjrLbKJappXXFBiO");

    for (int GKpBKrSXguopADul = 1944214848; GKpBKrSXguopADul > 0; GKpBKrSXguopADul--) {
        BHuAAKEfBuAzzQNm = aLbAXJlUvo;
        BHuAAKEfBuAzzQNm = BHuAAKEfBuAzzQNm;
        BHuAAKEfBuAzzQNm = aLbAXJlUvo;
    }

    for (int JXjca = 638400990; JXjca > 0; JXjca--) {
        ylzXmZgb /= ylzXmZgb;
        ylzXmZgb += ylzXmZgb;
    }

    for (int vaZgGczHxXMF = 2051206851; vaZgGczHxXMF > 0; vaZgGczHxXMF--) {
        dEWKMTLYoRJodEVm = egqtOTXqzztkYk;
    }

    for (int hRfWJUj = 1792402880; hRfWJUj > 0; hRfWJUj--) {
        continue;
    }
}

void pIunKpytojgBUC::frKfdSvqFsxjMh(double BPcvIfoqXNKHIg, string mTPpxQae, int aHauovvY)
{
    int LcwOikE = -476837685;
    double jqGIMlsbbpxeSIAr = -530991.8543143906;
    int UVIMCCGIqDzxRrQ = -339428585;
    bool XUafTKMmkcY = false;
    int xEzIqTLVtQqQD = 736047757;
    double KWZxbYpzYhcHQn = -157119.46124908252;
    double xMLmoGyLhiNYIp = -690668.6029315803;
    int KgeHZONuiZ = 762234313;
    bool mtUltVQL = false;
    string EuAcatYr = string("pkNmjxHZJPjkJsbwXQraiYvjEXtROFVyhVDDjOBBYUSIDIBSOXUIbsZdykAnojnTtFHojAEilRkrRmmNVkxLxxTX");
}

string pIunKpytojgBUC::yCXNzyEPjwbhCglc(double wZSlGrG, string KRwwWQYJI, int plBbdVHMQQ)
{
    double TQfLeHhuHs = -836920.2539697373;

    for (int EltSf = 1707603628; EltSf > 0; EltSf--) {
        continue;
    }

    return KRwwWQYJI;
}

void pIunKpytojgBUC::JHrBGPsWPE(int FjfjAg, bool qSponyUOUNpJt, int zWtVBOPS, double sGimxJWbBdDV, bool POgrkIRPYIeYqtgI)
{
    int gmPOKAD = 1299085170;
    int DoVGEToruBnW = 1082234867;
    bool kjksynFwO = true;
    string YStryvxXEWhuXFD = string("vCIsEVggTXxVwBlQZfaeqPCAfnQtvhyfznFAlzFYourLezPhAiKZqgWGwJInnqGxWbQiwDardQcqixZJNNjoIMyHWXQooGLrEChmJcOjdGrWjMpprLgvpWeauQOAeIYvcuabRsaMmAVcirVDcWKDBUiTTlfvVheGzRHyHbK");
    bool IjuLaBf = true;
    int ClVbejJfbBOj = -555201004;

    for (int vLqSc = 1530360639; vLqSc > 0; vLqSc--) {
        continue;
    }

    for (int vcXSDM = 1287971665; vcXSDM > 0; vcXSDM--) {
        DoVGEToruBnW /= gmPOKAD;
    }

    if (DoVGEToruBnW > 1299085170) {
        for (int QTYJdHNJxvo = 740802763; QTYJdHNJxvo > 0; QTYJdHNJxvo--) {
            qSponyUOUNpJt = POgrkIRPYIeYqtgI;
            gmPOKAD *= gmPOKAD;
        }
    }
}

double pIunKpytojgBUC::eIagLzh()
{
    double csQLtB = 791807.7856881625;
    bool HBYrJagWUlHCj = false;
    bool DBPpsRsoxd = false;
    int GgILuX = -1328553883;
    string yybtlVlhtwByyZS = string("SFCbCXNthKKortVuqxqDnPQrRigiGYJZrqbFSrVfdaaJqhuzzlnuuU");
    string HJCRaoVOlq = string("tuJJnINLShpqJOmveWrakxOvjKfpeqqAQBUtDBySGUzJLnDwDAppiLFHzVKiKRzPWAcfowkIlLFJGfBkZQbdiVNTyhYdxHMIrsViDnLSIfLBOPxAcaAVqgMDLbwFHgMnrHQuTbBvfBuMitYkjgRugtUnhfdrFJjdnJvupblEjiCeUzBKrHWUYyoYvXzlsAPhlCkUyogPySPWdIFWHSiysNjDhVBUsvqwfwvonNhdkRvXskk");
    double ccZPVpWvZhWiDQMW = -175215.97664972948;
    string qlQiURd = string("VPjmKjplbfknHFBgBZLaKsXABvCLqvfIXKUQbJacQMlXfGNUwvxKpGCaSXJDjyBAqxcaIpAsHVhtOrMXJU");
    bool VyxJEjl = false;
    int EXIIRUqg = 443282105;

    if (HJCRaoVOlq >= string("VPjmKjplbfknHFBgBZLaKsXABvCLqvfIXKUQbJacQMlXfGNUwvxKpGCaSXJDjyBAqxcaIpAsHVhtOrMXJU")) {
        for (int gRlTMJukuHQ = 303055909; gRlTMJukuHQ > 0; gRlTMJukuHQ--) {
            EXIIRUqg /= GgILuX;
            qlQiURd += yybtlVlhtwByyZS;
            qlQiURd += yybtlVlhtwByyZS;
        }
    }

    for (int KXOFWYHeWmw = 225853436; KXOFWYHeWmw > 0; KXOFWYHeWmw--) {
        ccZPVpWvZhWiDQMW += csQLtB;
    }

    return ccZPVpWvZhWiDQMW;
}

int pIunKpytojgBUC::xOUHbPgn(bool TJntHMRZiGyYw, int YfwQbUyGzpuWKdC, double mIhHxNjZNyp, bool XaSJCNvMmodTcUdV)
{
    int KLBkocoxIMDeeiw = 574634797;
    bool rRDMcPVUnywN = false;
    bool irZsPZRgN = false;
    int LAKvTglGJmA = -374214384;
    int MBdNsTHiMJ = 1654163242;
    string wjxMPiJWIB = string("gVpwpmPrAXybPyzgmUJmHefZCODVRZjuesOtvXxamwutJWJrnDaOAaVzVLNCkwcguuYKJkihNuNkwoNzlQXvCDxAKQrdPdmuKCnenmsdbqoeEDJRQEFXqOPRXaUzKaUHwpfYlrqUkUycEXfcELPevNYuQhNZKx");
    double dsuPKbWvH = 407750.29912391474;
    bool JvhtpIzQsJ = false;

    for (int orXMOkmFfHppr = 1750523684; orXMOkmFfHppr > 0; orXMOkmFfHppr--) {
        JvhtpIzQsJ = rRDMcPVUnywN;
        LAKvTglGJmA += KLBkocoxIMDeeiw;
        rRDMcPVUnywN = XaSJCNvMmodTcUdV;
        MBdNsTHiMJ += KLBkocoxIMDeeiw;
    }

    for (int MzxhCs = 575463113; MzxhCs > 0; MzxhCs--) {
        mIhHxNjZNyp /= mIhHxNjZNyp;
        JvhtpIzQsJ = ! TJntHMRZiGyYw;
    }

    for (int AMYstU = 1174887436; AMYstU > 0; AMYstU--) {
        LAKvTglGJmA -= LAKvTglGJmA;
    }

    return MBdNsTHiMJ;
}

pIunKpytojgBUC::pIunKpytojgBUC()
{
    this->EUfONvGrXG(true, false);
    this->zDswpyzCR(true, -844232.9315727444);
    this->kBSxfOkHZTa(false, 243842219, -361523.88578113273, true, 1643497810);
    this->jPJBGTcW(false);
    this->wLvFxh(string("NbjSyGwwolQiBVdtAZTBMuhyuLlzqKxCVZzvQLvEXlxOKueesjhRrwLxwzyboUumPncUvCTYGqCSItCBZnRHkeNPXOFaoZhtjljCEqMVUHXnIervTSZJWzapxVe"), true);
    this->ZORlPaUDYOmEJIQN(692211.1925367357, string("yaEYduTELVGvwrMcAOtZRkvKFzfccwhjlDoXNjbOIircfMQtrB"), -951670103, false, string("FdudlyrFeJEmUrUOWiZcXMvkrlkYZysJbgZbrNcKxXlRPDDSHqZjdZrNcIjedBGtTWIpwCfkxqBgoMdVpXfqYLiaoZoKKTKvTGpvfPYZUIrEsrqHaBfBUeEYAVpeIcjMWIAkHBsmsFxapTrkmbqmHtWKUuneZJgYvweXkVmGmdXmnHscbFGTxgzHvwQWRuvjZteYFVuZjJntyQxNrUV"));
    this->mcbIfbudBvDTZtnm();
    this->XBbfL(626778.1037621145, 1061797348, string("RTDQRIoxvktooWdugCiBAnOruWrQkWxFCnKkcCVyhdbjFYneBdJTkuJegIZkyYNOMwqYygOdVOSYffOFnOYAxjmOdf"), 1475380812);
    this->IMTdkioZXClMe(1552047171, string("jglboeMCuPTLgEbtqoDmRWEtrWVyKEIUUOkLprROdLfjkKUicJKroAXeRovILpGokMMXWXweFIYCrzxwUXSQ"));
    this->frKfdSvqFsxjMh(-152224.25893762405, string("HRZYstVBMKlciunCNTceaFXayHKCEebRngvQgsyTMNSNPNgSeendXCRDnErXTXxXYJiAtveeBiqHcegtYZsznEXbcGlaQQydAgYGAWQFiXKDjqGwsAAcOMsarXESkVKLTvNxDjLLLEzqOZAIfnPaJcjCOMKDzzEJoLolcSUxvyBLrJikoGLd"), 970445452);
    this->yCXNzyEPjwbhCglc(877923.3800821856, string("tfuyumxiHQfpxEdiQPGerVTBEkKuOGonQbdgOFxGsGsOcTGqpcHeSSqdxMSpqxGeGpMLBdMGylKGMSXbjUtSzPODViGGlnIRwoVIkMmGrHypmJIIfrmNPOJsyNTspwrYfAzWPobYdDiwTBqFsvUpPrudjHMMAPZY"), -398875916);
    this->JHrBGPsWPE(-371036400, false, 1479927524, -393993.64353722736, false);
    this->eIagLzh();
    this->xOUHbPgn(false, -32832174, -519043.9245342095, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class wfRtYhyl
{
public:
    bool dqactVxolAqPf;
    double ayPbphZHjKDYiMeE;

    wfRtYhyl();
    void nDMnmXcFmQBA(string cLnsDEnRKWU, int xULScNayIl, bool vWJCfCmJHFWxbpu, double smauodxcW, bool bIieafeLf);
    void NURxoxBlAqan(int XEEJjGfjNkXsCxax, bool PXfhEDkRZSvyvZR);
    void CLnhz(double XGylxg);
protected:
    string FQpcwgxNpjuSrzh;

    bool DCZErnJkMG();
    int UkkZiuiTMvvodg(bool mwOQk, string ODfkkhFVnnYcCvz, bool rUsQOzwEWI, int vMSQBFAeuSfQri, string dwlEM);
    void DaGDpwptaXRt(double DrVXwAIynJd, string CFXqkbFhVMMD, string XAmDgL);
    bool MWGEbHQ(int sqZEQBxw, double hnhLtITkceemDf, double UYkoiAhXfoly, int YaLMOzC);
    double cQbvgUnNldFokP(int ppmdXanwo, string UYDHrbmMuuIf, bool yxznmlvlx, int CNbBt, bool ZIqGSQaPMgmLOi);
    double vcqscGoDL(string jNprNAXFmCFOwU, int lJvpgIMHq);
    int FMNrpplXMGqLbR(string ZsRCvYDuwWhjCec);
    void RnHalMOymoQ();
private:
    int MnyPcDX;
    double XAMMdXwANo;

    int OQAXJUzwPq(double OSJSWTWHPvjVbuQF);
    int PPbaVxlvOQfSr();
    double ZntmB(double yCjvRZt, double nsXmTMDtTXKeqZuW);
    bool sdrirJzYusNdim();
    double iZNlqV(int EUBRPXTAAtkQU);
    bool ycWObfJmqiOBC();
    void APfud(double fOicnIf, double BGCZoiBhDIyXkf, int vdfmWAIKKVvPMUZ, double kQveKYqyruClQVgd);
    void tYfUP(int xPWeErxTXyHj, bool fFNVPySsmZ, int HPLDSSlCzYz, string RrrimbmDcEwS);
};

void wfRtYhyl::nDMnmXcFmQBA(string cLnsDEnRKWU, int xULScNayIl, bool vWJCfCmJHFWxbpu, double smauodxcW, bool bIieafeLf)
{
    bool jCcmAaFxH = false;
    int LFAXYqblsS = 456298350;
    string fQWrxgu = string("ZghyYNpGPtubVPrvhHTNmgXbmfONdnCwFGljfvNWx");
    bool QgvEdMwbX = false;
    int FbvGhEzjnMaCJSXo = -278547944;
    int pwBmorSpT = 1325332849;
    int nuHnxhRWfbgX = -112366940;
    bool bQVGj = false;

    if (bQVGj != false) {
        for (int efKziqeirVMgbDIu = 1329849079; efKziqeirVMgbDIu > 0; efKziqeirVMgbDIu--) {
            pwBmorSpT *= LFAXYqblsS;
        }
    }

    for (int FUJNuGCHzpip = 1866391064; FUJNuGCHzpip > 0; FUJNuGCHzpip--) {
        nuHnxhRWfbgX = xULScNayIl;
        vWJCfCmJHFWxbpu = ! vWJCfCmJHFWxbpu;
    }
}

void wfRtYhyl::NURxoxBlAqan(int XEEJjGfjNkXsCxax, bool PXfhEDkRZSvyvZR)
{
    bool CAUCJrgxKXuEhG = false;
    string CrFZDHisbPqhs = string("jrnaoQTNHFHqCNDqWeVhdCNRGHvnpunfIkGwaDmwikbuqfWYaSJHIOpMqfGNq");
    int cdJtWbnyJnYWqb = 1140801164;
    double gqrXRkytSPfwTbo = -302567.66840330954;
    double PBStPjVN = -625762.8434311397;
    double couvQztuiFkdnT = -761614.8423739949;
    bool XZpuuQSakJ = false;
    bool axqtkHKhYbSVgaM = false;

    for (int XTyXen = 1718932771; XTyXen > 0; XTyXen--) {
        continue;
    }

    if (couvQztuiFkdnT != -625762.8434311397) {
        for (int NBNloWAAoayv = 534821075; NBNloWAAoayv > 0; NBNloWAAoayv--) {
            continue;
        }
    }

    for (int erlEFKGaOxDNhO = 1302837819; erlEFKGaOxDNhO > 0; erlEFKGaOxDNhO--) {
        PXfhEDkRZSvyvZR = ! axqtkHKhYbSVgaM;
        gqrXRkytSPfwTbo -= gqrXRkytSPfwTbo;
    }
}

void wfRtYhyl::CLnhz(double XGylxg)
{
    bool fqeXYlrKnYTS = true;
    bool kMXKEabZgIR = true;
    double GLEBhEeemhvnch = 197461.71474027974;
    int MluhaSltq = -661942736;
    double zBmscGsLFmgefBa = 667438.5307892081;

    for (int wAMGySd = 2071467121; wAMGySd > 0; wAMGySd--) {
        fqeXYlrKnYTS = fqeXYlrKnYTS;
    }
}

bool wfRtYhyl::DCZErnJkMG()
{
    bool qQFcuafhl = true;
    string xhhVWeJZMc = string("idvoYshkaZLtEwUcRXyPrdSVGeeAhvTLJaiEthLRrKBdeanGzCEKc");
    double DHIpTMMlI = -829576.5035000793;
    double ImVDKLn = -663729.2944930494;
    string sCqYXzXgZeXbn = string("FycMHLzScXKPWZuZculwlXSMrdYDGumuDXlGMrtfSfqZtCeeUQPKPjkBFLHoAxFOGCzvRRbvkDNVgPiPzuWaglDMDEwf");
    string cIVTZjjsYe = string("vVCUFdZCmJJrrHLIqaKxqufoPoRjLFDFaEyBNfcGZzXjIqhkRWbtPrilEYCVvsmwTOcdmUeqkOKqAkYS");
    bool fwsAM = false;
    double kNqNleyOEeVOb = -1012697.2425820148;
    int KGWWpudNNOmyag = 27331747;

    for (int wZYSWLfThFmZuqAw = 79290350; wZYSWLfThFmZuqAw > 0; wZYSWLfThFmZuqAw--) {
        ImVDKLn = DHIpTMMlI;
    }

    return fwsAM;
}

int wfRtYhyl::UkkZiuiTMvvodg(bool mwOQk, string ODfkkhFVnnYcCvz, bool rUsQOzwEWI, int vMSQBFAeuSfQri, string dwlEM)
{
    double zcjaDlhF = 165016.0494415057;
    int jRsXrcxG = -1047423196;
    int UwSDlbaOtuRM = 810215496;
    string DFEzEyzVlx = string("ispBawlEKiQLaHjKeDYPQakLYUFOzIQlbTQnhUumywQMwaLOgLHSiZWxWEuqXJNjtDFvGGpLDUJCNXwyAydsOGhJZxxkcuaLKmjldMcXHjHaeCbsYtxjmeGnQThjHYbAOfTGkeOOtIF");

    for (int XlqAopksH = 1884283735; XlqAopksH > 0; XlqAopksH--) {
        zcjaDlhF /= zcjaDlhF;
        jRsXrcxG /= vMSQBFAeuSfQri;
        vMSQBFAeuSfQri -= vMSQBFAeuSfQri;
    }

    for (int fmwfioUewuGHYrlS = 1309548555; fmwfioUewuGHYrlS > 0; fmwfioUewuGHYrlS--) {
        UwSDlbaOtuRM -= jRsXrcxG;
    }

    for (int aGsAJKQrHwXFuU = 700767505; aGsAJKQrHwXFuU > 0; aGsAJKQrHwXFuU--) {
        ODfkkhFVnnYcCvz += DFEzEyzVlx;
    }

    for (int JjKRQklEbIZksAi = 337676599; JjKRQklEbIZksAi > 0; JjKRQklEbIZksAi--) {
        ODfkkhFVnnYcCvz += ODfkkhFVnnYcCvz;
    }

    for (int RjrRCmr = 2141105111; RjrRCmr > 0; RjrRCmr--) {
        ODfkkhFVnnYcCvz = DFEzEyzVlx;
    }

    return UwSDlbaOtuRM;
}

void wfRtYhyl::DaGDpwptaXRt(double DrVXwAIynJd, string CFXqkbFhVMMD, string XAmDgL)
{
    int CBXMBY = 1014002416;
    double NIUqfayCY = 79900.02291284224;
    bool IeiEmdxd = false;
    int QjugBIfVlWDHF = 1678404310;
    double cHFsNEhDWxF = 666926.0923816441;
    bool vTUxUlIMAwQ = false;

    for (int VksPbBdNyasx = 912017576; VksPbBdNyasx > 0; VksPbBdNyasx--) {
        CFXqkbFhVMMD += XAmDgL;
        cHFsNEhDWxF = DrVXwAIynJd;
        XAmDgL += CFXqkbFhVMMD;
    }

    if (CBXMBY >= 1014002416) {
        for (int xFSjBGYaHUAuIqeW = 1110699338; xFSjBGYaHUAuIqeW > 0; xFSjBGYaHUAuIqeW--) {
            vTUxUlIMAwQ = IeiEmdxd;
            QjugBIfVlWDHF += QjugBIfVlWDHF;
        }
    }

    if (NIUqfayCY <= 79900.02291284224) {
        for (int WokiZNDmYUQO = 552603821; WokiZNDmYUQO > 0; WokiZNDmYUQO--) {
            CFXqkbFhVMMD = CFXqkbFhVMMD;
        }
    }
}

bool wfRtYhyl::MWGEbHQ(int sqZEQBxw, double hnhLtITkceemDf, double UYkoiAhXfoly, int YaLMOzC)
{
    double kefxWIxrzi = 867617.3336875748;
    double ofbKvqpmOFfzsYB = -385577.51493832987;
    string oqrcvWbM = string("JCQHVwNeaQeGcZfsQtecQWMojSGFLtfwizgAQZdTCYPAROuAtnlHttOnmVvArAPdFiOZvNBAIAddonVwJQtBsXVyqqdusUpjqeUYZSqCgTlgregKCCizcqc");

    if (hnhLtITkceemDf >= 917380.5096806807) {
        for (int HMkuEqH = 721885845; HMkuEqH > 0; HMkuEqH--) {
            UYkoiAhXfoly -= ofbKvqpmOFfzsYB;
            hnhLtITkceemDf -= hnhLtITkceemDf;
            UYkoiAhXfoly += ofbKvqpmOFfzsYB;
            oqrcvWbM = oqrcvWbM;
            YaLMOzC /= sqZEQBxw;
        }
    }

    if (sqZEQBxw > -1277557045) {
        for (int XPqJo = 883993722; XPqJo > 0; XPqJo--) {
            sqZEQBxw -= sqZEQBxw;
            oqrcvWbM += oqrcvWbM;
            kefxWIxrzi -= hnhLtITkceemDf;
        }
    }

    if (sqZEQBxw >= 663498044) {
        for (int RMDkJOeJhgt = 1280854593; RMDkJOeJhgt > 0; RMDkJOeJhgt--) {
            hnhLtITkceemDf += hnhLtITkceemDf;
            hnhLtITkceemDf *= ofbKvqpmOFfzsYB;
            UYkoiAhXfoly -= hnhLtITkceemDf;
            UYkoiAhXfoly /= UYkoiAhXfoly;
            kefxWIxrzi += UYkoiAhXfoly;
        }
    }

    return true;
}

double wfRtYhyl::cQbvgUnNldFokP(int ppmdXanwo, string UYDHrbmMuuIf, bool yxznmlvlx, int CNbBt, bool ZIqGSQaPMgmLOi)
{
    string JZsYnpXQuddcboL = string("zOGdNDECqiswgTwlQlpjwenGyqEVfOWnSGwFESkpbtZNXBsHodYdpiPoRuMgQrgrqQvZlQWWxLtGaQjDiekiWMtJDFUKEJonocABebmsdcYKVdriAvqQhHMtmTKEEzZJYOdLxTqKqbWTHsFyeMfVhDQTrneBRbSTGhwkhxrbdwDShcklNPqTbqeNLChEdOsFm");
    int nWRfStjRkajwgzAt = 1141047889;

    for (int HoLHKvkOmkkNiQMH = 1845684113; HoLHKvkOmkkNiQMH > 0; HoLHKvkOmkkNiQMH--) {
        nWRfStjRkajwgzAt *= CNbBt;
        ZIqGSQaPMgmLOi = ! yxznmlvlx;
        UYDHrbmMuuIf += UYDHrbmMuuIf;
    }

    for (int pYtnrzgQS = 839629025; pYtnrzgQS > 0; pYtnrzgQS--) {
        nWRfStjRkajwgzAt = nWRfStjRkajwgzAt;
        ZIqGSQaPMgmLOi = ! yxznmlvlx;
        UYDHrbmMuuIf += JZsYnpXQuddcboL;
        ppmdXanwo += CNbBt;
        JZsYnpXQuddcboL = JZsYnpXQuddcboL;
        UYDHrbmMuuIf = JZsYnpXQuddcboL;
    }

    for (int WyPAdM = 1748172234; WyPAdM > 0; WyPAdM--) {
        UYDHrbmMuuIf += JZsYnpXQuddcboL;
        CNbBt *= nWRfStjRkajwgzAt;
    }

    for (int pklCIEIhhOYSG = 1702467692; pklCIEIhhOYSG > 0; pklCIEIhhOYSG--) {
        continue;
    }

    for (int ikiKq = 1545406059; ikiKq > 0; ikiKq--) {
        continue;
    }

    return 981335.675486346;
}

double wfRtYhyl::vcqscGoDL(string jNprNAXFmCFOwU, int lJvpgIMHq)
{
    string EKedZNgaTVsvWXsO = string("gogotvpSAAnHaBzzBHVOTNPmoMgcwLQTa");
    int zVQKDcVtBX = -977983430;
    double kQbQErepnVA = -720948.9753088143;
    string laVIgnkQfbFojtDD = string("nvTdgQkfynKaoSsMwimtaSrvJWUNgVvkPHDNSAuaZAjpkWpLKjMVnEDjNFtvjJCbkgDHMrgzEIziZYEeVccHGckZnkAwGaqeJkVWIHUHUjKsyXsjXIjOMLwpPJTFKYTtZWzcIJuJBFBigJelUuFXhIqUgfOVXFTQXiBlVmGU");
    double zfeoaAEwNIv = -915350.4907889655;
    string MtptjbHFtbY = string("mcltvBgFypDlLNZvZQahJzsUdNtjPgsZjRuBlaGbElMpbYQLRTcsfLBRUotJgJbGxffiSOGdJYJVKtcaHhPksOVhqSLMOvqaHqblojqCMYGjnBoQRfeHqqPIcmHMrKaXtGxbzBMyuQhkmEbcuWaoIXGwKaeaopmqETfh");
    int uBKQqQr = 862125105;
    double SDCScqtQ = -544865.6023052555;
    bool gydGILIDDlvql = true;

    if (laVIgnkQfbFojtDD <= string("gogotvpSAAnHaBzzBHVOTNPmoMgcwLQTa")) {
        for (int jfPbv = 1322675808; jfPbv > 0; jfPbv--) {
            lJvpgIMHq *= uBKQqQr;
        }
    }

    for (int TrsaSihYePeri = 842312245; TrsaSihYePeri > 0; TrsaSihYePeri--) {
        continue;
    }

    if (jNprNAXFmCFOwU == string("nvTdgQkfynKaoSsMwimtaSrvJWUNgVvkPHDNSAuaZAjpkWpLKjMVnEDjNFtvjJCbkgDHMrgzEIziZYEeVccHGckZnkAwGaqeJkVWIHUHUjKsyXsjXIjOMLwpPJTFKYTtZWzcIJuJBFBigJelUuFXhIqUgfOVXFTQXiBlVmGU")) {
        for (int zBVbR = 1399302957; zBVbR > 0; zBVbR--) {
            lJvpgIMHq = uBKQqQr;
        }
    }

    if (zVQKDcVtBX != -2031137194) {
        for (int mBYOxMeFFNvJWVc = 799598966; mBYOxMeFFNvJWVc > 0; mBYOxMeFFNvJWVc--) {
            SDCScqtQ /= SDCScqtQ;
        }
    }

    for (int fkwfX = 1459374522; fkwfX > 0; fkwfX--) {
        uBKQqQr -= uBKQqQr;
        lJvpgIMHq /= zVQKDcVtBX;
        kQbQErepnVA = SDCScqtQ;
        gydGILIDDlvql = ! gydGILIDDlvql;
    }

    return SDCScqtQ;
}

int wfRtYhyl::FMNrpplXMGqLbR(string ZsRCvYDuwWhjCec)
{
    bool mlyVVBV = true;
    double OMQLsrZgSz = -266577.1940934236;

    if (mlyVVBV != true) {
        for (int vmULFpBiV = 1559785866; vmULFpBiV > 0; vmULFpBiV--) {
            mlyVVBV = mlyVVBV;
        }
    }

    for (int mrnhN = 18231180; mrnhN > 0; mrnhN--) {
        mlyVVBV = ! mlyVVBV;
    }

    return -1384919476;
}

void wfRtYhyl::RnHalMOymoQ()
{
    bool UZMzbHUwLjpbLZjZ = false;
    bool vDfZHaNjexmjvH = false;

    if (UZMzbHUwLjpbLZjZ == false) {
        for (int ipbLvLrfcGL = 535160999; ipbLvLrfcGL > 0; ipbLvLrfcGL--) {
            vDfZHaNjexmjvH = ! vDfZHaNjexmjvH;
            vDfZHaNjexmjvH = UZMzbHUwLjpbLZjZ;
            UZMzbHUwLjpbLZjZ = vDfZHaNjexmjvH;
            vDfZHaNjexmjvH = ! vDfZHaNjexmjvH;
            vDfZHaNjexmjvH = ! vDfZHaNjexmjvH;
            vDfZHaNjexmjvH = UZMzbHUwLjpbLZjZ;
            vDfZHaNjexmjvH = ! UZMzbHUwLjpbLZjZ;
            vDfZHaNjexmjvH = ! vDfZHaNjexmjvH;
        }
    }
}

int wfRtYhyl::OQAXJUzwPq(double OSJSWTWHPvjVbuQF)
{
    string mkHaMy = string("JQMkqgfajJeIYuecMaQgnDrENvOwoaJEEOLvQrNfeYULZpZKwWvdaYtiMbJDLNjpBEOYhznKFpPIthXvlrPKFcMTmytYUxySGqQjowkObfkUWJMaEYfXLSLSAPvzukPJgTvljCeHFmAAbVonanCNAUkIANoFvSheQrdgccHdDUKtgFMKRfTHuaRdPNCjqTNnKnyfnHNhl");
    string yxGeKlIdd = string("CPEtmxrYPtDaQsIJVDUhZIODEMDxJbbySdAHWlytsAKHhMkoFlcJiCeo");

    for (int MSlpG = 871491636; MSlpG > 0; MSlpG--) {
        mkHaMy += yxGeKlIdd;
        mkHaMy = yxGeKlIdd;
        OSJSWTWHPvjVbuQF += OSJSWTWHPvjVbuQF;
        mkHaMy += yxGeKlIdd;
    }

    if (yxGeKlIdd > string("JQMkqgfajJeIYuecMaQgnDrENvOwoaJEEOLvQrNfeYULZpZKwWvdaYtiMbJDLNjpBEOYhznKFpPIthXvlrPKFcMTmytYUxySGqQjowkObfkUWJMaEYfXLSLSAPvzukPJgTvljCeHFmAAbVonanCNAUkIANoFvSheQrdgccHdDUKtgFMKRfTHuaRdPNCjqTNnKnyfnHNhl")) {
        for (int YukvsRsZXv = 1158342684; YukvsRsZXv > 0; YukvsRsZXv--) {
            yxGeKlIdd = mkHaMy;
            yxGeKlIdd = mkHaMy;
            yxGeKlIdd += yxGeKlIdd;
        }
    }

    return -544515690;
}

int wfRtYhyl::PPbaVxlvOQfSr()
{
    int kpCYD = -285586906;
    string QuBBpVInzdmTfTqD = string("gfStBzqjgNmpPpLwVkgThcZCoVHMtyOfZEIREYXRSlkzyselohZYYPTjgwgIopUDwennEdonpYsaBKwbilhMexOTQQCLAqtHrgejLgOfVuMWBqeOZhCqaMuRPMUJRJiRkQKoqRPeCvsEkpslIhoFeusztCzHgjAvijMTYHIfJHxIQdnIEceGzQHSlIQoBSHGoVMnTYGEGhLyVjcXXAKicPdFnTjIitSbMjPTeMZzXbrWDbGGUZPEvSJGuRVEk");
    double qqLLzlaTf = -541771.648583977;
    string DNztgTfKvRoo = string("jVMWdOOVUlPYeXDHygSgcfRuYJLHcZNINosSmXHvBRXWFrKfUDFemHxUbtZyqVIEbLuyFRzdMNMyWeVivgEeXnndVOlRiMUebSyxbjCpMYxHzIHNQVaKgWRiksXLWfucxuvYNCamWXkCfTECTMidkGSvcdhKphirYuubzcReoFBWGmShCpyYWRzTTzmjCunwbAomcFEMqoDAjSaYHGLNegVECSAXDPatsuOdCbYkBewAW");

    return kpCYD;
}

double wfRtYhyl::ZntmB(double yCjvRZt, double nsXmTMDtTXKeqZuW)
{
    double VQSazV = 170534.71296754517;
    int oYaHZcKOyPynDC = -2095863486;
    int ilugChmblIShWfaJ = -1584591422;
    int xyluXZrUimMsVcKL = 490818474;

    for (int iwweOBmUJHxsf = 1257867694; iwweOBmUJHxsf > 0; iwweOBmUJHxsf--) {
        yCjvRZt += yCjvRZt;
        VQSazV /= yCjvRZt;
        oYaHZcKOyPynDC /= xyluXZrUimMsVcKL;
        ilugChmblIShWfaJ /= xyluXZrUimMsVcKL;
        oYaHZcKOyPynDC = oYaHZcKOyPynDC;
        VQSazV *= VQSazV;
    }

    if (oYaHZcKOyPynDC >= -1584591422) {
        for (int ksXdV = 1736023396; ksXdV > 0; ksXdV--) {
            nsXmTMDtTXKeqZuW = VQSazV;
        }
    }

    if (nsXmTMDtTXKeqZuW > 170534.71296754517) {
        for (int TpwylIQyxNCZbu = 31117704; TpwylIQyxNCZbu > 0; TpwylIQyxNCZbu--) {
            xyluXZrUimMsVcKL += xyluXZrUimMsVcKL;
            oYaHZcKOyPynDC *= ilugChmblIShWfaJ;
            oYaHZcKOyPynDC /= ilugChmblIShWfaJ;
            oYaHZcKOyPynDC *= ilugChmblIShWfaJ;
        }
    }

    for (int dxpcaEfkYX = 54804485; dxpcaEfkYX > 0; dxpcaEfkYX--) {
        ilugChmblIShWfaJ = xyluXZrUimMsVcKL;
    }

    for (int IDrfyoevbrImZ = 1428308141; IDrfyoevbrImZ > 0; IDrfyoevbrImZ--) {
        oYaHZcKOyPynDC *= ilugChmblIShWfaJ;
        oYaHZcKOyPynDC = oYaHZcKOyPynDC;
        yCjvRZt /= nsXmTMDtTXKeqZuW;
        yCjvRZt -= VQSazV;
        yCjvRZt -= VQSazV;
        yCjvRZt /= VQSazV;
    }

    for (int CikzVWEMHn = 1095772945; CikzVWEMHn > 0; CikzVWEMHn--) {
        yCjvRZt *= yCjvRZt;
        xyluXZrUimMsVcKL -= xyluXZrUimMsVcKL;
    }

    for (int IiFSZqlzmoS = 912369373; IiFSZqlzmoS > 0; IiFSZqlzmoS--) {
        VQSazV = VQSazV;
    }

    return VQSazV;
}

bool wfRtYhyl::sdrirJzYusNdim()
{
    string hJSLfEVH = string("zNrvalYRoWoPyuLfZWZnJcnHgyXyQLulvNPArAZgLLmrVjLXcEtzDMEoGfpbcnMtvDDeiDWjhDNZjeHBlibaOoCuqqsCKvQHxvQrgUUBrWKROWThxMbvVKCxrUjEmLdKfFMHFDLKgHYbLREOXYYNYZAktDaFQdBtBqo");
    double hQhvYjvMiPlCA = 863229.4242511797;
    string MZGPUAkrxl = string("RzjfyGCHVYaBsakpfLaCOpGofTGcFdIxUWVxQAbNkOkHEQheYlpGGyWAObkbuVUUODZVnHLILXXFrwZbOtQlQkplfdpnlqSoZiQSTaJaRlUARa");
    bool kSKgPgugNbMs = false;
    bool MceSazLzDYZ = true;
    string GgCLDdxhdcvl = string("iiezcMRggmNVfhVVXmfRdGvNSGdkGUTXDqsloqsbdELbelFwcvFaGhUmKAoExImVTfWBmWSmyfqZkbTWdcaqBWQmlrWLUSLxHSWdzxUOnKRRYTDliAwcXqOgI");
    double mpjJmjGDSsPO = 150745.18625595304;
    int TgKmt = 1276875503;
    bool nVtRxVjnUW = true;
    string RofwsSv = string("maIRqfNcrhCFlfpBKCVflEZwpkudMDNCIyvtgfrEqKomhRuqtgEmuuFwkSpvrXjFhcvvTBPvRksRQoanbiFGEeKAtcsjJmHstbkAcJxmeDBeKbLQNejrIAPiOxZUaKWIKzqjiDPGmsVzggdOzFzefeHaYgjpBVLHqGTlMTMzKkiCxKqUFJSyrhVHuEXRBGtSBtBdtHDTALVWXbiHffzgraCQMFaEIPCeiqD");

    return nVtRxVjnUW;
}

double wfRtYhyl::iZNlqV(int EUBRPXTAAtkQU)
{
    int oPLkx = -314707932;
    double EjFQXbxPiH = -178339.83736374867;
    bool TODKXkAPolktnv = false;
    string dPZhZUYWws = string("CdHzeuVazmeusUUTnDvgaNWzYwyXCHAEowjYBPehGxxiuEaZbcPqScffL");
    bool DaIUMWIfGBoBayMv = true;

    for (int lTwDE = 1275069003; lTwDE > 0; lTwDE--) {
        continue;
    }

    for (int eyEDVNKveZF = 284191462; eyEDVNKveZF > 0; eyEDVNKveZF--) {
        EUBRPXTAAtkQU -= oPLkx;
    }

    for (int MVcDN = 9875346; MVcDN > 0; MVcDN--) {
        TODKXkAPolktnv = DaIUMWIfGBoBayMv;
    }

    if (EUBRPXTAAtkQU == -314707932) {
        for (int OHQPderLPBNoFwe = 1325388442; OHQPderLPBNoFwe > 0; OHQPderLPBNoFwe--) {
            TODKXkAPolktnv = TODKXkAPolktnv;
        }
    }

    for (int QsnsYowTNY = 1612053184; QsnsYowTNY > 0; QsnsYowTNY--) {
        TODKXkAPolktnv = DaIUMWIfGBoBayMv;
        EjFQXbxPiH /= EjFQXbxPiH;
    }

    return EjFQXbxPiH;
}

bool wfRtYhyl::ycWObfJmqiOBC()
{
    double jdocazJt = -399864.3437070977;
    bool AgwRKllJNucsNYQ = true;
    double vEUNR = -210053.94121115867;
    string eRhFFyLLdZqplVa = string("WpMshMKwrQbDALiBydkFbxLgFsMIQUKpzmQNJUyORyAhrqNrWNanTYZhCMsWFMhGSCpEvzePFZqfqrxltJUkRnuFhWRlGAFCozyLFnTaXCcVxnnltahCe");
    int aBHwaBZpi = -527659444;
    string ZPHjWsCsAKJag = string("viKbwnzleHLkmfBZYRkPKzsDfKHGvRRPCmmwUlxxyWdgvLVWwcUpuwuyvawyxMYb");
    int TxVSOVWopia = -1617489556;

    for (int BWisdkJEcZcHZrTk = 1285469312; BWisdkJEcZcHZrTk > 0; BWisdkJEcZcHZrTk--) {
        aBHwaBZpi /= aBHwaBZpi;
        aBHwaBZpi *= aBHwaBZpi;
    }

    return AgwRKllJNucsNYQ;
}

void wfRtYhyl::APfud(double fOicnIf, double BGCZoiBhDIyXkf, int vdfmWAIKKVvPMUZ, double kQveKYqyruClQVgd)
{
    int ALxjXfubrwXt = -1843511437;
    string cgUfEWzXyBY = string("vZjWrJlcYosTqFWlhVJpAGqRpvdyjhlAmwkUtuCyhhgBJljdPaFEPHaqfOCYOSiffWWbctzIGYRToteXRAlTnaVAabLcCQkDUZVkKFtBOGJgOrHAqYsIStkzgLnZaCw");
    bool ltkUnrOAYM = true;
    int MvWCFNMVrJGvqhx = -384866062;
    bool EiISHuq = true;
    double URNDhq = 699674.9524004381;
    string YsolKhn = string("LBJtRpEnvDaQFZdeNlkugDWooSyXCtToaLCcSDruThUTQMDLVqUuPelzLddmMWizOoJWOFZcs");
    string KpurDW = string("qagwsiZQVDyNOPaDSAZLVRrAskshSiEEJAnwZOPVWZyHY");
    double vgRfpjLOhknDBosl = 22901.268593288027;

    for (int ykxmd = 1596304781; ykxmd > 0; ykxmd--) {
        continue;
    }

    for (int NiJsOapwZdZT = 526598395; NiJsOapwZdZT > 0; NiJsOapwZdZT--) {
        cgUfEWzXyBY = cgUfEWzXyBY;
        ALxjXfubrwXt -= vdfmWAIKKVvPMUZ;
    }

    for (int owHPkIUkhOI = 1271053597; owHPkIUkhOI > 0; owHPkIUkhOI--) {
        MvWCFNMVrJGvqhx *= vdfmWAIKKVvPMUZ;
        kQveKYqyruClQVgd -= BGCZoiBhDIyXkf;
    }

    if (vdfmWAIKKVvPMUZ > -384866062) {
        for (int JcaqcQPFZnhX = 1550191150; JcaqcQPFZnhX > 0; JcaqcQPFZnhX--) {
            URNDhq /= BGCZoiBhDIyXkf;
        }
    }

    for (int DOobexqiglOgVxVU = 2145037086; DOobexqiglOgVxVU > 0; DOobexqiglOgVxVU--) {
        continue;
    }

    for (int gEGSYjHO = 434684483; gEGSYjHO > 0; gEGSYjHO--) {
        vgRfpjLOhknDBosl += URNDhq;
        ALxjXfubrwXt += ALxjXfubrwXt;
    }
}

void wfRtYhyl::tYfUP(int xPWeErxTXyHj, bool fFNVPySsmZ, int HPLDSSlCzYz, string RrrimbmDcEwS)
{
    int CQLDKJDRdWOuGlyp = -919765847;
    double DWFCHwuiIYCHK = -359792.4325503139;
    bool XIOfaiqCmfbDeEQL = true;

    if (XIOfaiqCmfbDeEQL != true) {
        for (int kzWYFnN = 489431534; kzWYFnN > 0; kzWYFnN--) {
            CQLDKJDRdWOuGlyp /= xPWeErxTXyHj;
            xPWeErxTXyHj /= HPLDSSlCzYz;
        }
    }

    for (int UNlPvnGLt = 52044541; UNlPvnGLt > 0; UNlPvnGLt--) {
        HPLDSSlCzYz *= xPWeErxTXyHj;
        xPWeErxTXyHj += HPLDSSlCzYz;
        xPWeErxTXyHj += CQLDKJDRdWOuGlyp;
        xPWeErxTXyHj *= HPLDSSlCzYz;
    }

    for (int ppegR = 1693952857; ppegR > 0; ppegR--) {
        continue;
    }
}

wfRtYhyl::wfRtYhyl()
{
    this->nDMnmXcFmQBA(string("xIlvsBAhEMazeqJgnZX"), 1832744182, true, -878100.5126774267, true);
    this->NURxoxBlAqan(-1178455843, false);
    this->CLnhz(730831.3833516648);
    this->DCZErnJkMG();
    this->UkkZiuiTMvvodg(true, string("dQoktfxsqlbdYlnDPtyIpawOTlvREpaDQgslTAJjMnHLpOrOmCkAHcPPMMdjXTTYQRFWLAVgMkvEWuxTfjnUUmOpZMgLbhIQpvwsPPLdpeSPXcXHcQkLesQKU"), true, 23532343, string("rphtxydQDBSVoQgvhSrtGkEKPWtUbDDmCntTPCnbbAIpdtBwvlgnICfUrKwkteWObiikWWXzvHbxSlALZwTRyqUZcGrLzudoqDBSEzWwkFqAAAXYvKhNYxriiqHIFnDDwfJpSXeZmShJjTJfKtonpnNCkHSmPWOtdASUwlNhAXqACZrwZRhdIeSBjegNGqhxpzhijMOJesMCmD"));
    this->DaGDpwptaXRt(-427999.0936718928, string("nsioUzOGdJAliKAdMwnlLUPvPkYVvpjNOxDSKIDgQMnWNmXfIQdnvUUmPpHXghLHVvgVyMLWSZfbSKglUkVgeWfVYVpCZpAZyqQBGgXupoKsHtqAOozsURTTEqrFWboffiKdFv"), string("KDxxBibXsGVTYtRLJMGSzyLMIAdrVZvAjIiePNFFbyipgEBDBQyUibhOrmaNSkywuQHKkETXkbdfvDklrPxNQLqNKhypVcNfgospeftvowYQNxFsJqOFdUjnDgSGsLgVbHJmEdDXWNzlDICDByJbeeRBXmAYVWzPBMMYuubuEvnJNPfGNHxKDGjpKTMXyrmClVfBucVLTpziNxXXQBlYrNvS"));
    this->MWGEbHQ(-1277557045, 253280.4209137224, 917380.5096806807, 663498044);
    this->cQbvgUnNldFokP(828393799, string("xTJNXUsREHerOrjDWmMNJukBgVgTzyAKxqYUBJcFqzZTEMmKqRdhbtRcsrqsOCxOOeuRWFEBZPDlZncYRiQtRdRNgUNEnnSKDhGYLJPFvTnlCUbylCBylEXXotPUiJsbdITVlWEvjGYhfgWsYVVqOeUtYEsTRQehvvJNb"), false, -1221159314, false);
    this->vcqscGoDL(string("mjzuZrKPVBVjIoNtWtuKBatEISSLpAWGcwRK"), -2031137194);
    this->FMNrpplXMGqLbR(string("smCdtexyvLxBmNAYGyvdFGHRnoYAuYRmIcApMWaPOYgWBGtUmNlbdNFwQtOJZmMINxFyfOgUoEGNAGNUvzXlOhUfjfUYxMALLUQJNHqcvfmPSGPuFpvKTHwnQYqDRhLnqsnvgJwhzwXsXcClvFI"));
    this->RnHalMOymoQ();
    this->OQAXJUzwPq(68660.56879473978);
    this->PPbaVxlvOQfSr();
    this->ZntmB(-748391.696087575, -57934.17830985749);
    this->sdrirJzYusNdim();
    this->iZNlqV(1147797171);
    this->ycWObfJmqiOBC();
    this->APfud(-938013.9561154075, 712061.1139261567, 1247482622, -850452.3563534027);
    this->tYfUP(117133634, true, -110953451, string("YKHfhalXyEIgPrZcUOlWjDFctL"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZEjDWSdrSvYUyugp
{
public:
    bool eyTTNdNIjp;
    int lKWBLzkLqfG;
    bool dSNrc;

    ZEjDWSdrSvYUyugp();
    bool vxgArI(string HrojBWsAAJfHW, bool NZBiP, int yCcLNHyLDQwmUdP, bool WzZcWzvOKiLgon, int pTrsuXLrj);
protected:
    bool vhLSDHTFamTEH;
    bool BrykyxSMQgEVh;
    bool ffvtmbJ;
    bool kbrBgkjnasxbNLo;
    bool hxRvFicXFhrZGU;

    int KikQxvBLiHYaymhe(double fXCCROaeOFmz, double xPxOI, double CXftY, int XfymsjrrWk, string WMoWLiMrmkxo);
private:
    int XGgvIZLyZiRnHQx;

    int JtkXXcH(int sJOPpSNzvhbRgosW, string fTPExCcXbRoJCJjC, int hNECrNAKiedtQ, string XqnGnZJpi);
    string qcRHl(int IlOmgUk, bool rMiMYixd, string VNSdFWYcFwgSeAL, bool zHVEjYtaqGgqGvn);
    void bLBeygtGiZtR(double OQGWbVZneOkA, double QxlowKANT, int TcAsjbjNzISBw);
    int bfhBwanHPkLzfn();
    bool DwEmvjQojN(bool XCyWQccdhMV, string LnxiR, string iyRoTuFYJU, bool kMilF);
    int reDTC(double pfxfggL);
    double WGiMRmu(string WjGfpxyIswkjHMiF, string JKTwRbRkMD, bool ZSwjkF, string IMpQE, string fgMNVCDIRybvltp);
};

bool ZEjDWSdrSvYUyugp::vxgArI(string HrojBWsAAJfHW, bool NZBiP, int yCcLNHyLDQwmUdP, bool WzZcWzvOKiLgon, int pTrsuXLrj)
{
    bool Wurlo = true;
    int EREtJRgnubhUihkk = 1678323100;

    for (int QWkqccXEcZjL = 1065618025; QWkqccXEcZjL > 0; QWkqccXEcZjL--) {
        EREtJRgnubhUihkk -= pTrsuXLrj;
        WzZcWzvOKiLgon = Wurlo;
        Wurlo = Wurlo;
        HrojBWsAAJfHW = HrojBWsAAJfHW;
        WzZcWzvOKiLgon = NZBiP;
    }

    if (Wurlo != true) {
        for (int LuDFdCpTitRRMEKS = 1217970582; LuDFdCpTitRRMEKS > 0; LuDFdCpTitRRMEKS--) {
            yCcLNHyLDQwmUdP = yCcLNHyLDQwmUdP;
            yCcLNHyLDQwmUdP *= yCcLNHyLDQwmUdP;
            pTrsuXLrj = yCcLNHyLDQwmUdP;
        }
    }

    if (WzZcWzvOKiLgon == true) {
        for (int AhMPrPFr = 366726914; AhMPrPFr > 0; AhMPrPFr--) {
            EREtJRgnubhUihkk *= yCcLNHyLDQwmUdP;
        }
    }

    for (int AwFmhmM = 1625009562; AwFmhmM > 0; AwFmhmM--) {
        pTrsuXLrj = pTrsuXLrj;
        NZBiP = ! Wurlo;
        EREtJRgnubhUihkk /= EREtJRgnubhUihkk;
    }

    return Wurlo;
}

int ZEjDWSdrSvYUyugp::KikQxvBLiHYaymhe(double fXCCROaeOFmz, double xPxOI, double CXftY, int XfymsjrrWk, string WMoWLiMrmkxo)
{
    int SgCeA = -1049611564;
    double ofzpmMbpFsU = 350453.87501791597;

    if (xPxOI > -957815.769200276) {
        for (int tyxiJAtOXP = 1562746666; tyxiJAtOXP > 0; tyxiJAtOXP--) {
            xPxOI -= ofzpmMbpFsU;
            fXCCROaeOFmz *= xPxOI;
        }
    }

    return SgCeA;
}

int ZEjDWSdrSvYUyugp::JtkXXcH(int sJOPpSNzvhbRgosW, string fTPExCcXbRoJCJjC, int hNECrNAKiedtQ, string XqnGnZJpi)
{
    int CFRyv = -560599196;
    string rqwBQpWdeJtz = string("paRPKSuoLuAtfIdwtwYLRHRYozFAVOTY");
    bool mVnsqKkpmoGqV = false;
    int TCrQIQMd = 668079605;
    string WwIHGEiOUHAJB = string("vDwnvOTZtmgbezhMRJeomtymLueSoNUpGkXEkNxmzjRsGbQoKuKjjjvpYfyDALucCQBbhqtBQWjCxqgBGUYXptrlGovZeUZilYpaLnIBEJLSzOJPIwwEdHnd");
    bool VIoIu = true;
    int YnLHTfan = 1360398578;
    string KUnkyTILB = string("TIboINiLqlYFRPLOOBwFCcEkMQWCcRjAdaaWueGkwDBgHDPCMoZACUjXJFuAkMMFcqcxWVfERXREdRFEOblMATbwQqdaCtkzzEiuxqrdWFGFlkMxV");
    double BxliGtVtdi = -899437.3140631643;

    for (int rhdRdO = 672405010; rhdRdO > 0; rhdRdO--) {
        KUnkyTILB += XqnGnZJpi;
        CFRyv = TCrQIQMd;
    }

    if (YnLHTfan != 1360398578) {
        for (int LUbXXoMLlZNUTN = 2074869769; LUbXXoMLlZNUTN > 0; LUbXXoMLlZNUTN--) {
            TCrQIQMd *= YnLHTfan;
            KUnkyTILB = WwIHGEiOUHAJB;
        }
    }

    for (int XEIUDnvzafi = 2094750413; XEIUDnvzafi > 0; XEIUDnvzafi--) {
        fTPExCcXbRoJCJjC += WwIHGEiOUHAJB;
    }

    if (CFRyv >= 668079605) {
        for (int llOmJeM = 525568648; llOmJeM > 0; llOmJeM--) {
            KUnkyTILB = KUnkyTILB;
            KUnkyTILB = XqnGnZJpi;
            hNECrNAKiedtQ += CFRyv;
        }
    }

    for (int folYHOUCxAUAiL = 2141225824; folYHOUCxAUAiL > 0; folYHOUCxAUAiL--) {
        CFRyv *= sJOPpSNzvhbRgosW;
    }

    for (int BuVUjkp = 1472241438; BuVUjkp > 0; BuVUjkp--) {
        WwIHGEiOUHAJB = fTPExCcXbRoJCJjC;
        sJOPpSNzvhbRgosW = hNECrNAKiedtQ;
    }

    for (int tWCDSx = 2133943837; tWCDSx > 0; tWCDSx--) {
        WwIHGEiOUHAJB += WwIHGEiOUHAJB;
        sJOPpSNzvhbRgosW -= hNECrNAKiedtQ;
    }

    for (int rtLILrGOWOLCTU = 1677747217; rtLILrGOWOLCTU > 0; rtLILrGOWOLCTU--) {
        continue;
    }

    return YnLHTfan;
}

string ZEjDWSdrSvYUyugp::qcRHl(int IlOmgUk, bool rMiMYixd, string VNSdFWYcFwgSeAL, bool zHVEjYtaqGgqGvn)
{
    bool nUlClhVVTDqRiLd = false;
    int GYPIacHKD = -77783228;
    bool yAggxsREICy = true;
    int ZaGGcxpN = -473857041;
    int kepTCcBPwZbKx = 326302176;
    int kKWbtSEreZWd = 634729546;

    for (int qIWPoes = 1253750440; qIWPoes > 0; qIWPoes--) {
        kepTCcBPwZbKx /= ZaGGcxpN;
        yAggxsREICy = rMiMYixd;
        rMiMYixd = ! yAggxsREICy;
        IlOmgUk /= kKWbtSEreZWd;
    }

    return VNSdFWYcFwgSeAL;
}

void ZEjDWSdrSvYUyugp::bLBeygtGiZtR(double OQGWbVZneOkA, double QxlowKANT, int TcAsjbjNzISBw)
{
    double HwxRqrukizkSSO = 333492.24422825366;
    bool KClhi = true;
    int aGrczqNLkFl = 1932529166;
    int xDYortkMfhWWl = -969182625;
    bool HyerMHzMlYSXz = false;
    int aPPmX = -1043595999;
    bool WGbdDPAaJIsW = true;
    int JWuFsaJtvDlK = -1613912360;

    for (int rGvAeVRboX = 119922307; rGvAeVRboX > 0; rGvAeVRboX--) {
        OQGWbVZneOkA -= OQGWbVZneOkA;
    }

    for (int fqDJUv = 1642294410; fqDJUv > 0; fqDJUv--) {
        KClhi = WGbdDPAaJIsW;
        WGbdDPAaJIsW = KClhi;
        HwxRqrukizkSSO -= QxlowKANT;
    }

    if (TcAsjbjNzISBw <= -1476347233) {
        for (int oveprydPahrd = 1866814424; oveprydPahrd > 0; oveprydPahrd--) {
            aPPmX /= JWuFsaJtvDlK;
            QxlowKANT *= QxlowKANT;
            aGrczqNLkFl = xDYortkMfhWWl;
        }
    }

    for (int dhXniVrf = 1129427589; dhXniVrf > 0; dhXniVrf--) {
        aGrczqNLkFl -= xDYortkMfhWWl;
        OQGWbVZneOkA = QxlowKANT;
        TcAsjbjNzISBw *= xDYortkMfhWWl;
    }

    for (int hjdDNprjWuirFVL = 1813296902; hjdDNprjWuirFVL > 0; hjdDNprjWuirFVL--) {
        HwxRqrukizkSSO -= OQGWbVZneOkA;
        aGrczqNLkFl = aGrczqNLkFl;
        KClhi = WGbdDPAaJIsW;
    }

    for (int fUyRErlukZpcQ = 826464430; fUyRErlukZpcQ > 0; fUyRErlukZpcQ--) {
        QxlowKANT /= QxlowKANT;
        TcAsjbjNzISBw *= aGrczqNLkFl;
        HyerMHzMlYSXz = ! KClhi;
        KClhi = ! KClhi;
    }
}

int ZEjDWSdrSvYUyugp::bfhBwanHPkLzfn()
{
    string QMcHcuaIPn = string("XPkAUCCZIsJgENnALWOxpoLvusYZyudBwxrHLcTbtHZcBfiiuVaPjWUYtQBpCKvcqnCevlKrWbgftJPAhvPYyhgrOQdUzXBMHdFLwsdjCPiEktlBANaytwXymqjZLNEJsZLXPMbwHGmOsQRzguMwuYLD");
    int VyzcFKJlKykUxl = 655294352;
    int mEYhVy = -1700912435;
    double KvYcq = -115934.44765648956;
    int fUBjEMgRrTziFFn = -1868719270;
    bool PLipvyBfZIQcv = true;
    string bPUgiwOjhURA = string("CDZiCAHbeG");
    bool qBoaJfWKotNVR = true;

    if (qBoaJfWKotNVR == true) {
        for (int OraqYZ = 1324091464; OraqYZ > 0; OraqYZ--) {
            fUBjEMgRrTziFFn -= fUBjEMgRrTziFFn;
        }
    }

    for (int BJuFOMSvlP = 692374356; BJuFOMSvlP > 0; BJuFOMSvlP--) {
        VyzcFKJlKykUxl *= mEYhVy;
        KvYcq -= KvYcq;
    }

    for (int LrCAObAsXXsS = 837269257; LrCAObAsXXsS > 0; LrCAObAsXXsS--) {
        qBoaJfWKotNVR = ! qBoaJfWKotNVR;
        fUBjEMgRrTziFFn += fUBjEMgRrTziFFn;
        mEYhVy += mEYhVy;
    }

    for (int gTfULFLfn = 920248670; gTfULFLfn > 0; gTfULFLfn--) {
        continue;
    }

    for (int LdLHGrCUzrEGLmrn = 231035996; LdLHGrCUzrEGLmrn > 0; LdLHGrCUzrEGLmrn--) {
        bPUgiwOjhURA = QMcHcuaIPn;
        fUBjEMgRrTziFFn /= mEYhVy;
        VyzcFKJlKykUxl = fUBjEMgRrTziFFn;
    }

    for (int ATVmitbrPBQpAZef = 1198862266; ATVmitbrPBQpAZef > 0; ATVmitbrPBQpAZef--) {
        bPUgiwOjhURA += QMcHcuaIPn;
        mEYhVy = VyzcFKJlKykUxl;
    }

    return fUBjEMgRrTziFFn;
}

bool ZEjDWSdrSvYUyugp::DwEmvjQojN(bool XCyWQccdhMV, string LnxiR, string iyRoTuFYJU, bool kMilF)
{
    int fOAgnmiAtw = 136463091;
    bool IfcLaSIHj = false;
    int hfwrxtcPHDHXaMX = -1174075676;

    for (int kahQovxYGx = 294961759; kahQovxYGx > 0; kahQovxYGx--) {
        XCyWQccdhMV = IfcLaSIHj;
        fOAgnmiAtw += fOAgnmiAtw;
        IfcLaSIHj = XCyWQccdhMV;
        iyRoTuFYJU = iyRoTuFYJU;
    }

    if (kMilF == false) {
        for (int xylcYrskBj = 1329337417; xylcYrskBj > 0; xylcYrskBj--) {
            IfcLaSIHj = IfcLaSIHj;
        }
    }

    return IfcLaSIHj;
}

int ZEjDWSdrSvYUyugp::reDTC(double pfxfggL)
{
    double OuHSw = 932999.4231382612;
    int PlsPWLxeMWNE = -1346394764;
    string zTcMJpevcfLHlc = string("KDmRzxQpDHWSxlYSGShZdFmjvTAsgnHkGmNRGJpleSKXLYmHzvlSebERPxaRmLReFojaMJVgZbHwwbYguwDWxlDpjcGCzCFVcs");
    bool pEzVWGzRshCvnZwL = true;

    for (int WXlwaXhEGxHOYOkp = 198920278; WXlwaXhEGxHOYOkp > 0; WXlwaXhEGxHOYOkp--) {
        pfxfggL = OuHSw;
        pfxfggL = OuHSw;
    }

    for (int CEJSDhR = 4372853; CEJSDhR > 0; CEJSDhR--) {
        PlsPWLxeMWNE /= PlsPWLxeMWNE;
        OuHSw /= OuHSw;
    }

    if (pEzVWGzRshCvnZwL != true) {
        for (int lZjLTRdyDEej = 1084060267; lZjLTRdyDEej > 0; lZjLTRdyDEej--) {
            continue;
        }
    }

    for (int nggbNSlTSPoP = 1320041203; nggbNSlTSPoP > 0; nggbNSlTSPoP--) {
        pfxfggL -= pfxfggL;
        pfxfggL -= OuHSw;
        pfxfggL += OuHSw;
    }

    for (int KDLah = 2008538532; KDLah > 0; KDLah--) {
        continue;
    }

    for (int FduQcgcWAduPmj = 1264309904; FduQcgcWAduPmj > 0; FduQcgcWAduPmj--) {
        pfxfggL = OuHSw;
    }

    return PlsPWLxeMWNE;
}

double ZEjDWSdrSvYUyugp::WGiMRmu(string WjGfpxyIswkjHMiF, string JKTwRbRkMD, bool ZSwjkF, string IMpQE, string fgMNVCDIRybvltp)
{
    int yriSp = -1362890478;
    bool wALomdFTpCSzn = true;
    int HlwGBuj = -1687069895;
    double HNMJtybWAo = 708550.8850141026;
    string XEaLbMqAVlrYR = string("rYzSZnsATtZFeNlyxkqYatVMtICdPNVQWcRvUxAKcBlc");
    double JkioUgC = 942192.3146498105;
    int sQdVMM = 76646817;
    double KEIKyUVepdusCGfF = 718250.9193224066;
    string HOnSobWDBIrwTI = string("RFGMcFAkDPFAxVuxMXPZXuXhzfqiOOtagiZVePvQzbImEUcxtKizUsYkwpnvQSabVhhbHpSgnXbtAfUajYxrRstSJEcDZsIFZ");
    int ectEujBJJ = -824006286;

    for (int sNtlRIjCu = 1343637633; sNtlRIjCu > 0; sNtlRIjCu--) {
        fgMNVCDIRybvltp += IMpQE;
    }

    for (int DSIYwsSzRJxfU = 1740212844; DSIYwsSzRJxfU > 0; DSIYwsSzRJxfU--) {
        WjGfpxyIswkjHMiF += fgMNVCDIRybvltp;
        HlwGBuj *= yriSp;
    }

    for (int CXAhuDLoAaf = 323689254; CXAhuDLoAaf > 0; CXAhuDLoAaf--) {
        wALomdFTpCSzn = wALomdFTpCSzn;
        yriSp -= sQdVMM;
    }

    for (int bPZAnmyKEyfrfIo = 1930048291; bPZAnmyKEyfrfIo > 0; bPZAnmyKEyfrfIo--) {
        sQdVMM /= sQdVMM;
        JKTwRbRkMD = IMpQE;
    }

    return KEIKyUVepdusCGfF;
}

ZEjDWSdrSvYUyugp::ZEjDWSdrSvYUyugp()
{
    this->vxgArI(string("bBCidHijQ"), true, -89606332, true, 1150501820);
    this->KikQxvBLiHYaymhe(-70479.70852566838, -1034086.1125093026, -957815.769200276, 503810285, string("LvjELoAGtpgaQRtHpwNLBbPOPUCdFqsDvEtqxDUdIhZGkqwDmxLHbxhPgJbDyxBOWmKKtAGYcIuWpDksPjxeethRFIARPiffZJlqNvcjkuVnAUMlREPTOdsyBVsZ"));
    this->JtkXXcH(-979934611, string("SrUHPRHaTCROfoznuOgKQQqSXvpqpQYGRUxXGUqqjHycwCqaXkoTEwXFwXpGZzDTXaQunTpBKqQUPuqGzMHQTqRouHXbbOJNEgettSLokcmGaYsTsGUQ"), 1262990744, string("WZoyOvOqNoEqUJSamTEusiTmLGNmVzgoerviioYbNXpyQhxYlYbmuenUHEHJfvcphIoPMZySSiBkDnDuiyRrWuuuQBQFoRWHsYWBQekClSCUekEVchNhOjCmdKYIbXdS"));
    this->qcRHl(-363845911, false, string("XlQQKRCNwMWJpIqvfVqkHEhguWG"), true);
    this->bLBeygtGiZtR(-816978.985213433, 359777.7355542275, -1476347233);
    this->bfhBwanHPkLzfn();
    this->DwEmvjQojN(false, string("YyBtswskerfSsFSuPuQIArKjkDBZPaCMJSTJGPOvSpBYzInDqaVxewDyNqPrwtnTICQHHRuVyZqHKToWxRnidSwacjCbSzHqWYMAMCUcheQdodTELhsWnHXSswixzTzyGHLjFCNZelrpDeWSPxbilZAkxDNKWXAyUAj"), string("CGOEILylhyFQzsRzVsXbFDBEENYlAIXsOrNwKVirThlNfgUOzivDHBCGmoiICfUXJsyJSqANyWhkvByVZCcfUkWyOoOkaBAwsXSTjiOxjXszcNgWMufmDxsMSBzrxztcnCoEGJvZTFRcYayoXrWOOgfHcFrWgaUBnNFLjnUvSGkFDoNtrHHDi"), true);
    this->reDTC(-407944.3635068497);
    this->WGiMRmu(string("ZJAGIuOQkcgoCPOKnsgdonInjVupmGBzKGOXcWhJunhDWMuArvUVkvrLPLTnffXExYzoHcMpzFpZunWioAsykPFEngqrniqFJazCBWMcROTqFDtGRgxNkTvEAPPNTjxTqRyJQfEKZpmNVUGGSKlJyRnSCkzVhxwRmCvxa"), string("ElwpFqLOVlkw"), false, string("iYSbuzNAqpkATdzrFPQGHKwVCEFNZXOFgbzyVFAxcVzGiIHvAJMEMbTDVOFhZfVbMgxVQJruPjNhbRMQmmdznkQcHqQNHDgmGZrwGKwJTCoNNXAwxkcWRTKCHjWUeaxoYtjoKrxwUaAEzVqRZGRhZoMKFjUrdfsiPhfjEhciNTri"), string("NrtBXRmwvIITwqVPGliqvYFVlyPavdblWtKzCwvJgDpVxcEgvUvcnRLwkfgKpuTkvqLofwJioBsIAgbrhULihdZocvz"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xFtJMJmIMilfQ
{
public:
    double zTnjAobS;
    bool TEdJUzV;

    xFtJMJmIMilfQ();
protected:
    int Nngzwq;
    bool SmDaku;

    bool jOAldQoGEZrzXSA(string cdRVGEQtuoGsn, double PgODZn, string CsgOCLVKEu, int xXKjpcdNbMbFbt);
    void ygrWafn(string myXJU, double DTlEKZPH, string wvpSgQy, string tNzuDhgpQCNO, bool cqEiWluz);
    double xShlQ(double BSvEr, int NGrjKFSFNrcRk, double RRqlWDklZEzpzx);
private:
    double XcnGuIefVak;
    double HayKVqhQvz;
    double WMkTNGABiY;
    int KrGydwzGiVlxgQi;
    int fuxATOcDx;
    string XgmVOcZksoMIOrR;

    double DSRys(double tlwSAx, int TobPN, bool BwXhUkoioFGAQwI, string zqYaEmGTxZ);
};

bool xFtJMJmIMilfQ::jOAldQoGEZrzXSA(string cdRVGEQtuoGsn, double PgODZn, string CsgOCLVKEu, int xXKjpcdNbMbFbt)
{
    double FEltdjlc = 558160.8487100368;

    for (int fNpAINK = 1281477099; fNpAINK > 0; fNpAINK--) {
        CsgOCLVKEu = CsgOCLVKEu;
    }

    if (CsgOCLVKEu < string("jmTGeCOTNaPDxTfSRCPbLacmmjFUrlwpBhiECQxOPeoDlWxHIgmHMVCfoYUpwrowek")) {
        for (int XHGKlqPzBbpfzNRd = 1457762113; XHGKlqPzBbpfzNRd > 0; XHGKlqPzBbpfzNRd--) {
            continue;
        }
    }

    for (int VAdjtgjVrmYrQYk = 1950960906; VAdjtgjVrmYrQYk > 0; VAdjtgjVrmYrQYk--) {
        cdRVGEQtuoGsn = cdRVGEQtuoGsn;
        xXKjpcdNbMbFbt -= xXKjpcdNbMbFbt;
    }

    return false;
}

void xFtJMJmIMilfQ::ygrWafn(string myXJU, double DTlEKZPH, string wvpSgQy, string tNzuDhgpQCNO, bool cqEiWluz)
{
    string WsrAloebMMbhT = string("zceXbwPSebMNQCeZslzHwbLvRZmFqGQCyaCQbZjlfWrlFXKdruHaDCwuYExChSRhST");
    int Ynrusn = -1971780428;
    bool GJYKb = false;
    bool fSmVxJOceOK = false;
    int jZJFemQmAPau = -1606312038;
    string BaIoYDGmqb = string("tvAGfNrOomcNkBhZbwkTbqMoxgNfkfgdeyNBXzMBNiCxiAUTazKcEcJNtBCSBIBPirJBgHlOKcnUtrCNNhEayZZPaIpJvnusvOgVeBjFxPVLlvcMNyNNtUGNjijqaRzoXWfYJqaeOuCrmukMjjmECWSpZSOxOYTpjnODABQnlPClixxvqVFuTkbSXiFWiaZTKMNoTOtojzoCshQVKnTFuYbzKhN");
    double zZOsqGZrdkK = -174882.97458112004;
    string TzGkLzYTbs = string("FGjSJPAmdTkuOiVPymbKpuLZvgPBsdwRQmlGRBSzTlagii");

    for (int EIIWMRqWSoqBVc = 2113219221; EIIWMRqWSoqBVc > 0; EIIWMRqWSoqBVc--) {
        BaIoYDGmqb += TzGkLzYTbs;
    }

    for (int UungRpBR = 2029787260; UungRpBR > 0; UungRpBR--) {
        Ynrusn *= Ynrusn;
        GJYKb = cqEiWluz;
    }

    for (int zFaalZAvNEDgtNoz = 1873206394; zFaalZAvNEDgtNoz > 0; zFaalZAvNEDgtNoz--) {
        GJYKb = ! fSmVxJOceOK;
    }
}

double xFtJMJmIMilfQ::xShlQ(double BSvEr, int NGrjKFSFNrcRk, double RRqlWDklZEzpzx)
{
    int PXiXztWFqoD = 1562587487;
    bool JLBddDTdZ = true;
    double aNzexmw = 411666.91029707354;
    int zNjyeOBytP = -243056366;
    string uKUbBz = string("FNcEmbPLvQ");
    int oWfmgBPgXEm = -722944874;
    double xWAItMiOYM = -610489.2089307156;
    bool nOcUgiKJy = true;
    int xAthnOYqhEFvkAsO = -2016454264;

    if (zNjyeOBytP <= 1982556177) {
        for (int ZjhlQxWENQTM = 1788628926; ZjhlQxWENQTM > 0; ZjhlQxWENQTM--) {
            zNjyeOBytP /= oWfmgBPgXEm;
        }
    }

    if (BSvEr == 411666.91029707354) {
        for (int GyzZgjkJnUyEoEFv = 1984881058; GyzZgjkJnUyEoEFv > 0; GyzZgjkJnUyEoEFv--) {
            BSvEr *= RRqlWDklZEzpzx;
        }
    }

    for (int KKwjImvNtyLhqXZ = 1108201006; KKwjImvNtyLhqXZ > 0; KKwjImvNtyLhqXZ--) {
        nOcUgiKJy = nOcUgiKJy;
        NGrjKFSFNrcRk -= PXiXztWFqoD;
    }

    for (int ZpjlgvYVk = 641026113; ZpjlgvYVk > 0; ZpjlgvYVk--) {
        oWfmgBPgXEm += oWfmgBPgXEm;
        NGrjKFSFNrcRk = oWfmgBPgXEm;
    }

    for (int zzruphXybUHxYyO = 1076371449; zzruphXybUHxYyO > 0; zzruphXybUHxYyO--) {
        BSvEr *= RRqlWDklZEzpzx;
    }

    return xWAItMiOYM;
}

double xFtJMJmIMilfQ::DSRys(double tlwSAx, int TobPN, bool BwXhUkoioFGAQwI, string zqYaEmGTxZ)
{
    bool qMrQzE = true;
    bool ljkGjcKhMn = false;
    string RRretRYpBUBUfwSS = string("yJkyFRDvuOmrXSUtalzSrUrX");
    int egCEfnvExkGsYLft = -1152298545;
    double YRzniBplHdOBZg = -228800.60055337555;
    string MwdYBeM = string("elTTMdYSWJZDahgvzsZnRKGgVTogURhjxelahUnOus");
    double VsFZIvJ = 943211.6389630734;
    bool xPGsAXRgpesneof = false;

    for (int AWRwC = 1042054844; AWRwC > 0; AWRwC--) {
        continue;
    }

    for (int tznMuAyRna = 1017392951; tznMuAyRna > 0; tznMuAyRna--) {
        MwdYBeM = RRretRYpBUBUfwSS;
        RRretRYpBUBUfwSS += zqYaEmGTxZ;
    }

    if (VsFZIvJ <= 912715.4911797943) {
        for (int yiWYvp = 1551197813; yiWYvp > 0; yiWYvp--) {
            continue;
        }
    }

    for (int gFNOU = 1891708420; gFNOU > 0; gFNOU--) {
        BwXhUkoioFGAQwI = ! BwXhUkoioFGAQwI;
    }

    for (int cAoiaTz = 1865608997; cAoiaTz > 0; cAoiaTz--) {
        TobPN /= TobPN;
        xPGsAXRgpesneof = qMrQzE;
    }

    if (qMrQzE == false) {
        for (int bWljQTUM = 1731829560; bWljQTUM > 0; bWljQTUM--) {
            RRretRYpBUBUfwSS = RRretRYpBUBUfwSS;
            MwdYBeM += MwdYBeM;
        }
    }

    return VsFZIvJ;
}

xFtJMJmIMilfQ::xFtJMJmIMilfQ()
{
    this->jOAldQoGEZrzXSA(string("jmTGeCOTNaPDxTfSRCPbLacmmjFUrlwpBhiECQxOPeoDlWxHIgmHMVCfoYUpwrowek"), 450587.95780256914, string("tQCLIcYjxODjHBlrFWRIJcmEZnHFsGugBdxqebjrHNbVIKAxEknykMoxwtrJvNeGKvlqmQYANKcadIfEbq"), -297542677);
    this->ygrWafn(string("MXyIkIjScYBHozNmeTVPOTmwDZcsalUFmiKQBNzRsVGcQtvjmwzDWVJxwBSKKpieKjMKUtugOZFjIhGnBgnQkNsFeWqOdZjYNedznnrec"), -304095.7927566285, string("rgyEOjlJOvHsMvMqyaDaehPXCWTuWaJiicGnQutZZsBiFAEAZuqfQvVAMbfMghsaRYbhkAErtvvjlSSCjmTvvaXXMsRREGTBbEPLilXNIcsWTZgQaggmckGjGkJqyugqpcXLJisGqOMxAhYreGEeMPjPQucwwNdjqTrArfSqTfnYscbdEQpnBHXZDEyIjskQekrYUvhWVkjEV"), string("ozCbIdWrmTisHMqTzIklPwSjTbQsNASXgNvxVRuitwEEaSpPDxliTCvTZbyrjHpFuawNBFVMzuFcTlNsxVIeDUsFGuhdfFmUWMkEfpZUrfCOenWYnHCGOLmHrUUwTiTrk"), true);
    this->xShlQ(-567022.4600580243, 1982556177, 1042616.9723891068);
    this->DSRys(912715.4911797943, 1824498883, false, string("vfDplnFWhIIoarcyVPDiRXFQvyFbTnVawQOdFwrJrOxceqjyTVMlPuDjhHLDYiiNIXHFfyLyHCFSeCbDoMJZzPUszRTOYhTrKOJxoDNIOISOdMOgYphGUmuEdKMjHDWnRqMMRRJNdDPlummfPAtgmmTfmgMWSBYFjTgHFkBWZJOfFlOVsQniuQMjrPHnOLzCWfPYMjGQudhfcFULLTQccDQypmWcLdfeQRSAOWPQRQNxjSCeJFfRAOOA"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class RfdaUIfxKe
{
public:
    double ThCNTGnGAozPUKsK;
    bool kNrArLtlNM;
    bool jSHCJjwhvfjjK;

    RfdaUIfxKe();
    int VjPgakl(int vRJFELO, double GjyTq, string LwqeDRaed, bool LAbqmmRu);
    int gJacxn(double MAdqlRwAVe, bool qxDnW, int ogfyDh);
    bool vBwdbPMVPjwEWl(bool PMCbtDXWs, int HQFgkKnPpOXBb, bool VqrJntbeKIJti, int GioMcVePtkGu);
    bool BHfRFRHzorwSUtge(bool PnJuuwy, int SMvSeuzqGiG, string qSWTFzeBzwM, string pTNBNApSp);
    bool czWdzzp(bool zJTTtAhuHhka, bool KIczxQ, int CjiczhLvhJZMF, bool skUiEiLPDFNfobaP);
    bool jaIVDSTqUxylQgWz(double wBCjPWGf, int zWxxSniPtYJYJ, int VnOBVKJzSrrnPU);
    int GTgSpIxDTj();
    int xTGXF(string SqNAQvJNEcYuKw, int YJlCtMz, double dyFfPZhpuV, double ivaTZsWCCF);
protected:
    bool KsiclQOqWfyh;
    int fiLgoEtwXQBF;
    bool cGXRwHT;
    string zluzYfPJmXRKqus;
    double VNjcznIFE;

    int JZpgjVhS(string BvcOaufwOPU, bool xSTwM, bool RkCjUSZZgQ, int XfSFHtg);
    string KpTjvIiTpy(bool BYXCWZ, double ayZeNYs, int WUfQFVtGFcqBwkZ);
    bool qlqZPtWqNUSMGcm(double ozYDQ, int yjuOYeyifcaPbAv, int hJWetDVjKhnBPvPE);
    int tTtLOeXsKJtLsz(string fkFZOz, string wzSCfurzacjSwUS);
    void ObnADeO(bool yqFWMMqpDvtKNLE, int IPnmwRzd, int XTeyHtGoZ, double TqYqwCo, bool OgNfTZKifippkS);
    int QvFCQzMOZ(int iKFqlHne, double OvNZNtdQcUIkJibE, bool yHXxfqDfyxSGfOP, bool eHelSxVtxlx, int tkNjaTzG);
private:
    bool BbXXdtYXN;
    bool qRgjWugT;
    int lrGBTxPe;
    int lRZKIdp;
    int hPjApXEceBq;
    double sSMvsmteigual;

    double PHInQvx();
    void YITHhPeshohSR(double soReCs, double yhvsbhI, int XUVgmSidyJQYB, double ywccCidJ, double CtaggeL);
    void bcFKS(bool GligsasXfZHhVh, double dWzLiSZnCSalJPlQ, int BvPqjymgUazM);
    bool HgeWBGXc();
    int tKvJfBYWBKu(int wAJcQt, int iFvUpnfTKF, int SOYhWJi, string IPgmiGbVHoffRSDA);
    int raHpS(double VsanCakBc, double UzjqT, double PZEYMNMZs, int MOxVRjIADtLnIrI, int LXEyphrDOslp);
};

int RfdaUIfxKe::VjPgakl(int vRJFELO, double GjyTq, string LwqeDRaed, bool LAbqmmRu)
{
    bool BUSexooSHQEji = true;
    double VejHt = 725104.9792657455;
    string qcVLJJA = string("VXmMpmdHNQzYwzSEftAYaQtKAfrlPUGBliPpnLAaTVVhiWlOEwiclADfJpiyXTUuqUvvscDATaIZEgWIcKUmTUlTlkkRhvlgjhHGUnDdYoJsaAQWYJaimoyEbTjoKnzHZoSyHXyojHbKHmariZpnDZkGWHBEvbNiQIbduutDSaSXSChHYdWkyOaNfhhkVJRIpThSWyTllXJcVDMsreTbgZkGmdjWmxnHyt");
    string HkEigNOiEgUzDJff = string("VNcQxIzsirUynFpHOZnTpmXlgEMdAISZgaveSRWWjqwieIeeaJyrdlpzMGfNyAYPSpUsOCQ");
    double jExaZEglL = 462407.579383909;
    double VBKEUIueUfoKGbVN = 154597.98593465675;
    int UphWmWzLsCjkHV = -999073536;
    string OqJjrbPXbBsPUGlw = string("YJptxqqxvRkDkBlLvjZQGzHodPDbKJnSQjNIXOxbTMOLBjmdOczdBHKG");

    for (int tiLVJWC = 1512152823; tiLVJWC > 0; tiLVJWC--) {
        LAbqmmRu = ! LAbqmmRu;
    }

    for (int EwLQlJgvBCjYUZ = 1753587830; EwLQlJgvBCjYUZ > 0; EwLQlJgvBCjYUZ--) {
        GjyTq /= GjyTq;
        jExaZEglL /= VejHt;
    }

    return UphWmWzLsCjkHV;
}

int RfdaUIfxKe::gJacxn(double MAdqlRwAVe, bool qxDnW, int ogfyDh)
{
    double VQFxDSq = -431819.555526427;
    string GFFccs = string("zTWQEAHWJHKtlaKMBnLBKGqlgfyBYklTDMCmjTNbhWzoGwgVhUnkFPlyIlsRw");
    string CgGdyFrVzUzfxQI = string("OHkfDlpkDbgPRoDXfLoRrsEYKustQyOWF");
    bool hnimQIrksZGnZdj = false;

    return ogfyDh;
}

bool RfdaUIfxKe::vBwdbPMVPjwEWl(bool PMCbtDXWs, int HQFgkKnPpOXBb, bool VqrJntbeKIJti, int GioMcVePtkGu)
{
    int vByUQXYGVDHLwW = 90472735;
    string fAdyTMJc = string("qXSJRXPyFwrEZAGqUkFqYttbUAzHwDbWBJSITjPkymzzaWKWHZYmklUhvtrlOInbJ");
    int hQlsAvvKC = 1516263757;
    string GcXcUAXWxAInQ = string("RfNlxrDwckLUZEzAdRMKUOTqUeWXIjrLPvtIgmVyRsSsUBUYlHZqfADSzqlUwpzaUTRkKPUimAJvjpPhJteOlRJFsqMytpBnXjGZFuFopyDWGRwdqaDNndQJXJvNcIgmeuFSBBbTJWFLHuCUstNZanRwchkjgafBKRbVUrLiRNyMMYJBZfcUiucOxffIQlCghKFwjAJOrnCXrGAFOnF");

    for (int yUdOcYP = 347763676; yUdOcYP > 0; yUdOcYP--) {
        vByUQXYGVDHLwW += GioMcVePtkGu;
        fAdyTMJc += GcXcUAXWxAInQ;
        PMCbtDXWs = ! VqrJntbeKIJti;
    }

    for (int jYiBCjh = 149039346; jYiBCjh > 0; jYiBCjh--) {
        hQlsAvvKC += hQlsAvvKC;
        fAdyTMJc += GcXcUAXWxAInQ;
        HQFgkKnPpOXBb -= hQlsAvvKC;
    }

    for (int gNGNBtKC = 1117765028; gNGNBtKC > 0; gNGNBtKC--) {
        continue;
    }

    for (int YBOsRAFLFUYu = 440974291; YBOsRAFLFUYu > 0; YBOsRAFLFUYu--) {
        hQlsAvvKC = hQlsAvvKC;
    }

    return VqrJntbeKIJti;
}

bool RfdaUIfxKe::BHfRFRHzorwSUtge(bool PnJuuwy, int SMvSeuzqGiG, string qSWTFzeBzwM, string pTNBNApSp)
{
    int VXffOCnpgZ = 308781625;
    bool jFrwFlBow = false;

    for (int WVpJjZPqpaHZUHRk = 83309215; WVpJjZPqpaHZUHRk > 0; WVpJjZPqpaHZUHRk--) {
        continue;
    }

    for (int jiLVOEv = 684551281; jiLVOEv > 0; jiLVOEv--) {
        VXffOCnpgZ -= SMvSeuzqGiG;
    }

    if (VXffOCnpgZ < 308781625) {
        for (int GImsruNr = 166548302; GImsruNr > 0; GImsruNr--) {
            continue;
        }
    }

    return jFrwFlBow;
}

bool RfdaUIfxKe::czWdzzp(bool zJTTtAhuHhka, bool KIczxQ, int CjiczhLvhJZMF, bool skUiEiLPDFNfobaP)
{
    bool vVXYmz = true;

    return vVXYmz;
}

bool RfdaUIfxKe::jaIVDSTqUxylQgWz(double wBCjPWGf, int zWxxSniPtYJYJ, int VnOBVKJzSrrnPU)
{
    double kokBnSgHnVR = -474344.5332041237;
    int KaExOBAks = 104570250;
    int nJrfHaCvYeJJDqfA = 88484024;
    string PIhVexobAL = string("ciFvyiDrvJLFgPsPXhxddfOxwTqjBMhJMCMNVHXJvSQOGnRpRVnuxzbNUdDCiztlwOlfXYEUxRQXhJGTIfuqMZePsgICbYzSaKSCwjoRDQsOsreBvbxKLhfPZTLVZFXTWLxJusGyJFFerHkmTckRTToAQvIVUjccOrJdMjFFdrgFFDnyBxapBxyBFltHUcaExOjUtaPiPOfgQIEuzyLAQVuSBDQeraBVcjjrvqNkNiPjANPRmEU");
    bool vpndDhioO = true;
    string xKmwndfpwZaNj = string("fmpZAuBAjxXclTvvqflitMMqrfBqhWwOhlbzlABMxUxcMmrwcwbFfXXTfacOAUurstXfNcpYjHzybVimrLRCTndLQCGiATYEEiQFUklUITiaFmXOqDTiZOEbsMlMIZaAihBIywmySBGOTKLTycWWyqvrGdIvgVwHdVGhuQauqmDTmtiZJLnmQMmcPHqBOPZbBVedhrXP");
    double PpwPVVDVnhOO = 116557.77435232268;
    int QAzeWMsVIpnzZN = 1347777416;
    bool aRysoUYjYOXzWu = true;
    double ZJaLSGwRoNGFmzR = -304409.14752589946;

    if (nJrfHaCvYeJJDqfA != 211516597) {
        for (int nwVhLED = 2098388407; nwVhLED > 0; nwVhLED--) {
            continue;
        }
    }

    return aRysoUYjYOXzWu;
}

int RfdaUIfxKe::GTgSpIxDTj()
{
    int KGjKailYCcK = -1532756365;
    double idObFudoJTAM = -991619.0767446432;

    if (KGjKailYCcK <= -1532756365) {
        for (int aplOTHK = 2111646265; aplOTHK > 0; aplOTHK--) {
            idObFudoJTAM -= idObFudoJTAM;
        }
    }

    for (int QOebNeKDoSAp = 1457803423; QOebNeKDoSAp > 0; QOebNeKDoSAp--) {
        idObFudoJTAM = idObFudoJTAM;
        idObFudoJTAM -= idObFudoJTAM;
        KGjKailYCcK += KGjKailYCcK;
        idObFudoJTAM *= idObFudoJTAM;
        idObFudoJTAM += idObFudoJTAM;
        idObFudoJTAM *= idObFudoJTAM;
        KGjKailYCcK = KGjKailYCcK;
    }

    return KGjKailYCcK;
}

int RfdaUIfxKe::xTGXF(string SqNAQvJNEcYuKw, int YJlCtMz, double dyFfPZhpuV, double ivaTZsWCCF)
{
    string CXpOOOlGeJGpx = string("GGIyWImQYfTNIiJHoDbySmWJABsIDgFWTcASIIcEodsjohWHZvfGisGwxlrQtuQdnnYlHWTjWuvNfvPcmLJbPRnpkqNkiWeilUVIWpSRPkXrux");
    bool IfjlYubHNtynVniT = true;
    string psEAlByiKvr = string("frpvhnRryNiEtIFhIWgHuYsHFnfPYclhYhRxwZksKvbgqXpjelvIYVgGiQGFhfgPkzYxSFfkPImiOVTIUbRQUqvoilUqiNjEsAlrdMNAiIrLlGwbHKabdYrjCleoCgfmcwvDJIBofAFUvlmLIlOaOSlpHsqQzEQDJMehyaqSKCVzSbZGbxQmJmXkEDbJUhHfTLUELJMtNmiwgtzxLYqwuyEBNvrqeKtGFzPzoTKYuipgoksGXyIeCYFQUoHIGvr");
    double wHFevXIY = 989237.6675147031;
    int WJtxoGa = 1625662794;
    string IETMDFu = string("GGBLyGQsmPHmOLzvkixRyhqqUxIJqxABqWYZSRmgZXRMAZNycGkWpARhUGtoEBReLPzQ");

    for (int ytNGEdeXKnMOfL = 143807917; ytNGEdeXKnMOfL > 0; ytNGEdeXKnMOfL--) {
        continue;
    }

    for (int WcFIshZtLsiz = 2041865311; WcFIshZtLsiz > 0; WcFIshZtLsiz--) {
        CXpOOOlGeJGpx += IETMDFu;
        wHFevXIY = dyFfPZhpuV;
    }

    if (psEAlByiKvr < string("GGIyWImQYfTNIiJHoDbySmWJABsIDgFWTcASIIcEodsjohWHZvfGisGwxlrQtuQdnnYlHWTjWuvNfvPcmLJbPRnpkqNkiWeilUVIWpSRPkXrux")) {
        for (int fZBlkLzigh = 1511408429; fZBlkLzigh > 0; fZBlkLzigh--) {
            wHFevXIY -= dyFfPZhpuV;
            WJtxoGa -= WJtxoGa;
            ivaTZsWCCF = ivaTZsWCCF;
            ivaTZsWCCF *= wHFevXIY;
            IETMDFu += CXpOOOlGeJGpx;
            psEAlByiKvr = psEAlByiKvr;
        }
    }

    return WJtxoGa;
}

int RfdaUIfxKe::JZpgjVhS(string BvcOaufwOPU, bool xSTwM, bool RkCjUSZZgQ, int XfSFHtg)
{
    string JUDBPpmQtnp = string("lDqUSPPbhiJMhPgxIyrjnDeGtwdQyTFFGUkvSnjEpxoSzcqDLpwHShVIfMEvZuVkUihBEwHuYGVliMiBuTeEBwNaPLozgDhKZsFxooHdZDEMcGwkbfdaQKumdHzUJMPGEAqltEaUkl");
    double mCiNtvtCE = -771106.226289329;
    double ClQPAQLUSlVXPvMf = -335834.90828254714;
    double MkaTyzsrpDT = 855906.9805096312;
    bool oFwQXK = false;
    double AKHglgdSQGjZf = -121664.6869223342;
    int YSNMVQh = -1525012493;
    int mhkWe = 913731720;

    return mhkWe;
}

string RfdaUIfxKe::KpTjvIiTpy(bool BYXCWZ, double ayZeNYs, int WUfQFVtGFcqBwkZ)
{
    bool JlqOnTLeNqCwc = true;
    int mKZdpEH = 439532727;
    bool gHMnVEhIjoJrnf = false;
    int vSJdGFQ = 1854129072;

    if (mKZdpEH < 1854129072) {
        for (int nGIhK = 1032679386; nGIhK > 0; nGIhK--) {
            continue;
        }
    }

    for (int BEhLAeRHi = 2053509926; BEhLAeRHi > 0; BEhLAeRHi--) {
        WUfQFVtGFcqBwkZ = vSJdGFQ;
        JlqOnTLeNqCwc = gHMnVEhIjoJrnf;
    }

    for (int dOYFfWUhlGZyFtR = 1464445890; dOYFfWUhlGZyFtR > 0; dOYFfWUhlGZyFtR--) {
        WUfQFVtGFcqBwkZ = vSJdGFQ;
        vSJdGFQ = vSJdGFQ;
        vSJdGFQ -= WUfQFVtGFcqBwkZ;
    }

    if (WUfQFVtGFcqBwkZ == 1854129072) {
        for (int HQWNE = 47086759; HQWNE > 0; HQWNE--) {
            continue;
        }
    }

    for (int sLUkH = 578629404; sLUkH > 0; sLUkH--) {
        continue;
    }

    return string("fRYFJPXjoeajqrEBCSSJTaOAYmwkAkNRfLfTLDDLNWAdQuybAlHiHzqrkneXGDmXheTDAHymoZfXKapqFlUrEWvqBNlSZLDGVRAoqObqHRjDdoyBgYBySIaeNpywhgGtFhAmzFGvdbWtneDzdKNqkjOuvnecapBCWGmobMDytadDDbfrG");
}

bool RfdaUIfxKe::qlqZPtWqNUSMGcm(double ozYDQ, int yjuOYeyifcaPbAv, int hJWetDVjKhnBPvPE)
{
    bool VIvGNylhgA = true;
    string iUlNWSvLMWeFBZ = string("rJoWxipTcymZcxKqMxJLCQFBCXIdXvBBWsZVzxFMBVmBeluEuHjkXmCnhGFqH");
    double BFLDQcIY = 779049.6455027306;
    double UImFYNxlYbqZh = -344454.7027265191;
    double CqhWChY = 957372.2623611463;

    for (int xklRv = 785967079; xklRv > 0; xklRv--) {
        continue;
    }

    for (int UplEfhLbSybgiNaV = 1583887658; UplEfhLbSybgiNaV > 0; UplEfhLbSybgiNaV--) {
        CqhWChY /= ozYDQ;
        ozYDQ *= CqhWChY;
        ozYDQ = BFLDQcIY;
        BFLDQcIY += ozYDQ;
    }

    for (int wMwHZto = 790007513; wMwHZto > 0; wMwHZto--) {
        UImFYNxlYbqZh *= UImFYNxlYbqZh;
    }

    return VIvGNylhgA;
}

int RfdaUIfxKe::tTtLOeXsKJtLsz(string fkFZOz, string wzSCfurzacjSwUS)
{
    int yJVzwfoIzNxLaoQ = 218225558;
    double KSTdcr = 1001345.0757523599;
    bool LouaVoP = true;
    double AEFMYDutTeUfeD = -496043.1217387191;
    bool gclEgYrQ = false;
    string KpmpGQBzdzd = string("cgubspOMhLQiOrJTrKhLfozEHZMEIeyWuLDdNhhlxAcErezjTHQjXLDRipvOOuVGKFLQQvLFpF");
    bool yUKLmhniKM = false;
    double xnrbCQJyzHSA = -162296.64206286744;

    for (int vNSfipJIpDYl = 2019718296; vNSfipJIpDYl > 0; vNSfipJIpDYl--) {
        LouaVoP = yUKLmhniKM;
        fkFZOz += fkFZOz;
        yUKLmhniKM = LouaVoP;
    }

    return yJVzwfoIzNxLaoQ;
}

void RfdaUIfxKe::ObnADeO(bool yqFWMMqpDvtKNLE, int IPnmwRzd, int XTeyHtGoZ, double TqYqwCo, bool OgNfTZKifippkS)
{
    string BwEYsKWKVupeIUJL = string("NaknnJREeIBBnSBaTordUjIhPupabYjrlRloJumjirczeJpAGuVJcNmGhfTDEvLkVRKmIVYISNlbxgjxbwhixGJUclRrUMTlvgFXPnAcRJVQMPUBXUhVDCHz");
    double eVlJHxoDoIGA = -919757.3659180346;
    bool BMCdEgcRUdYT = false;
    bool xwugxNRJXliU = true;
    int OcFwEGiRDJH = 1607703301;
    string YNjCbUgDWB = string("iNuEAMkRdDHeOsKbUjrACcrrViWBwywCtZCZARRiTAPWlemPSQaKEfaDHgYZvATTJxsSuqghYLbE");
    double zqmDnMraoZwMQFa = -312010.1398893782;
    bool DrGhYEZomWwIWaKl = true;
    string RPTRAmR = string("CtMThctimUMRgOohtSSOUxzWBlCckWykpAqVSbQqAUSihuOWrOMtiPPONRbMpVHVGHJNBiHZPPoqeHxwHrVTayNNNrdXnzKsIUQeGidgzBijSVPHnAMDcnKIuDQuZQMaHAoEpPSURKssNikeHQLaZFbWTxChoapqWOlxoOyuouNRGvnLsBqGmEjLtMJICdQpiLOCGEhumjURIdDQSVmcULtihSRucSynuSRaHn");

    for (int eqtkrlJDhNXOr = 357769259; eqtkrlJDhNXOr > 0; eqtkrlJDhNXOr--) {
        BMCdEgcRUdYT = ! BMCdEgcRUdYT;
    }

    for (int mRzCAl = 1842118663; mRzCAl > 0; mRzCAl--) {
        yqFWMMqpDvtKNLE = BMCdEgcRUdYT;
        eVlJHxoDoIGA *= TqYqwCo;
    }

    for (int IgkExA = 539369174; IgkExA > 0; IgkExA--) {
        eVlJHxoDoIGA /= zqmDnMraoZwMQFa;
        XTeyHtGoZ = XTeyHtGoZ;
        OgNfTZKifippkS = yqFWMMqpDvtKNLE;
    }

    for (int saxUJNaKpHcKjoqd = 1471905993; saxUJNaKpHcKjoqd > 0; saxUJNaKpHcKjoqd--) {
        continue;
    }
}

int RfdaUIfxKe::QvFCQzMOZ(int iKFqlHne, double OvNZNtdQcUIkJibE, bool yHXxfqDfyxSGfOP, bool eHelSxVtxlx, int tkNjaTzG)
{
    int AXcdEF = 977015440;
    string NUJhQFvVFSpuLfOH = string("GLjCBiwjmgCmnrxsGQSARhuZRWcxNbdCEXxbPnfDqwaAIMwRabAKUitVkPrjfaPvC");
    int LXqDFF = 1716544652;
    bool IpTyDOeChAdMR = false;
    double QtJpkirzoyz = -447000.83029907243;
    int BMbIVvtPuw = -321171205;
    bool OXcjOqId = true;
    bool kmjDkfBedzu = false;
    bool oLdamwiPY = false;
    string vzqrHLfwjordMIew = string("QkJHgRALjwJpROcyfkpRLTeECkrpmxUVuHmbPQSLFNkEckyUIYpLUVuRfyQNjGGLUyFQSPZSzKfxaHQcPVKPnKTwYfJrBaAkVNbLXqEHWk");

    return BMbIVvtPuw;
}

double RfdaUIfxKe::PHInQvx()
{
    int HVuMG = 1617134017;
    int UErhFBc = 1726212779;

    if (HVuMG >= 1726212779) {
        for (int BmJpnYF = 1926744077; BmJpnYF > 0; BmJpnYF--) {
            HVuMG -= HVuMG;
        }
    }

    if (HVuMG != 1617134017) {
        for (int nEQMpaVUAWgTzCIv = 1316173927; nEQMpaVUAWgTzCIv > 0; nEQMpaVUAWgTzCIv--) {
            UErhFBc -= HVuMG;
            HVuMG = HVuMG;
            UErhFBc = UErhFBc;
            HVuMG -= UErhFBc;
            UErhFBc += UErhFBc;
        }
    }

    return 507413.95943331934;
}

void RfdaUIfxKe::YITHhPeshohSR(double soReCs, double yhvsbhI, int XUVgmSidyJQYB, double ywccCidJ, double CtaggeL)
{
    string KzmSZf = string("FephjCiMaKKdloymluXzhOhcFXyxccvvGSRNEWSsFuGoDONmcRZgnWbkNpouiHsvYpdmErQMYmOliP");
    bool BhocWvDNfFVEXJ = true;
    double WtTZPG = 362042.3890644595;
    string fvmPtpnnzy = string("gnhaBJqzXNZlFxKRKGoFpfmasZrUHhoOSOLGdHIKMOjtgXFISQNvaSrhexfcxkQtYhAbOVkUCSuhievMWlozGDnxyLMYrgpsKYBeowDfRioNGzxmIQsfzwcUBjbKEQtSRenjGbmqNMOmUyxvuHPWoHZaqttIIpEcrFMlovBixLgPzcrRAkeMcqPcXFrkspaUUjMMmkpmepIgvkHtnQK");
    double jeaRtxxR = -369707.41806417453;
    double GaHAYsjbCwcMFD = 508596.0611598191;
    bool wSmsYNQeh = true;
    double oFfPM = -295777.64556313667;
    string fDagJCOnp = string("jSnQMAFAHCakpbNWnKtypfckePJZMKQKJjMUxHTbsBEUOsczQUSlmtTbKZOgHqgbKS");
    string QrViZtBIuXhgATRu = string("IiNBtJAYHlEWPFCodNRacCmmoMpiKPQdHIdxQlmGTzUufvgZOJwGsHOGUoJzOHuRZXHzKhXYrwPYSqXTNmgzCRmIRqMiSmyzMyEuNVvfssKKsVPlsVbhoKYOQDtOmliDSXjkYsrrTNqMAQc");

    if (yhvsbhI > 576189.8536605699) {
        for (int MJpmLEqkpknHNs = 533835900; MJpmLEqkpknHNs > 0; MJpmLEqkpknHNs--) {
            ywccCidJ += oFfPM;
        }
    }

    if (wSmsYNQeh != true) {
        for (int AuGQnxIYLJvQa = 1470023284; AuGQnxIYLJvQa > 0; AuGQnxIYLJvQa--) {
            continue;
        }
    }

    for (int SFoSFpkwbDMBWB = 1146058095; SFoSFpkwbDMBWB > 0; SFoSFpkwbDMBWB--) {
        ywccCidJ = ywccCidJ;
        yhvsbhI *= GaHAYsjbCwcMFD;
        ywccCidJ = oFfPM;
        CtaggeL -= soReCs;
    }

    for (int YJtYpTQjP = 875735791; YJtYpTQjP > 0; YJtYpTQjP--) {
        yhvsbhI = yhvsbhI;
        oFfPM -= soReCs;
        CtaggeL /= jeaRtxxR;
    }
}

void RfdaUIfxKe::bcFKS(bool GligsasXfZHhVh, double dWzLiSZnCSalJPlQ, int BvPqjymgUazM)
{
    double wetfTEoVcpuv = -936310.0042854609;
    double urOSmdiA = 443417.2790756013;
    string DBjeLOKNNcS = string("WJJwpLzCYEGsFsfxQVbiRZTGsMAiIeREDDXjTMJdAIlVKFlmIBHNmmaLIGpRVtQbzdrNcxAOjdHerKsyqtTbqsOZwhVQNRbcTbITcFYxCYYRgILWVNMAlJOIWeVvcbvXslJCTKcfgvnshXKXJoocfdoBaiYsOByfBoIWFbnrqLqMGBqvfvtACpybUlRTQSZtdGACpAQiqWsxgOlgVuPDlQpsOgOHsnqImJEXwLPgH");
    string xiseITJXy = string("qAPYuAvOfxOVWJIiovKqcRXVFdGwexmwTjgzOikusvezeODTyFCQluxbjvxZzrawzfVPfTpKBsRMHpadMGVbnOJCaChGJuTKOEVidLndDgfBUzWjCGNfNRXcmbiPVXiOhgmSvkOUhSEjlIAJDfVDSljbzPEzxYCQIYldQaqGCaFmhEroxAYVHrtRTIVAAwOGgC");
    string DZSUrOdnVKjJIiZc = string("zAZHoFetVDWrQGqqygEkuobfHNiwPBMwRNqsppIyTiLwhllSEhPqZDrnwUXTsYR");
    int SRbdtKrGUCmXLWB = 1889117270;
    string PbDBvMkExfLfk = string("fZIXCqDGrQYvplBfpsdgXlQBO");
    double TiHvLiVEpiOhxb = -916288.6652130116;

    for (int tdLBbWHsGOaWH = 373348293; tdLBbWHsGOaWH > 0; tdLBbWHsGOaWH--) {
        dWzLiSZnCSalJPlQ -= wetfTEoVcpuv;
        PbDBvMkExfLfk = DBjeLOKNNcS;
    }
}

bool RfdaUIfxKe::HgeWBGXc()
{
    int reJlPXDfSZkJxkIA = -615765727;
    bool sxwjn = true;
    bool fdeduptrigI = false;
    string qypLczLXZSCPd = string("QxXOygcpoSvGQpYbezHUKttQhXlAJHOdCoKMYjNRvxfAIbqNqxvMREENdcAOyFPjRbgCIYbbcqzbQKCpKpHLUaOqrmECzuKBcWHIvqSgawjrYwXzeD");
    double zoghPzYD = -908855.1751836197;
    int GPkLyel = 1990907560;
    string NMRBkMkBdsNxWZn = string("cHYsSTkLBsuYBnwQOYLeiwaZpmKuSFmlBcQHbYFnrUdapbOXYMFOyPafUeCBIILLPVYubqGiAsECozrOBnQIDnJlOudCMDIlUlSyg");
    int sdhAYuTAolX = 2103102910;
    bool WuCAdjGntJbFqX = true;

    for (int cPqdJKUOBDJm = 2037383940; cPqdJKUOBDJm > 0; cPqdJKUOBDJm--) {
        NMRBkMkBdsNxWZn += qypLczLXZSCPd;
    }

    if (fdeduptrigI == true) {
        for (int dAizCuFVIPAWs = 2127542114; dAizCuFVIPAWs > 0; dAizCuFVIPAWs--) {
            sxwjn = sxwjn;
            reJlPXDfSZkJxkIA += sdhAYuTAolX;
            fdeduptrigI = ! sxwjn;
            sxwjn = ! WuCAdjGntJbFqX;
            qypLczLXZSCPd += qypLczLXZSCPd;
        }
    }

    for (int QsCmNb = 1458473586; QsCmNb > 0; QsCmNb--) {
        reJlPXDfSZkJxkIA *= reJlPXDfSZkJxkIA;
    }

    for (int VXpqdVTJa = 1533874777; VXpqdVTJa > 0; VXpqdVTJa--) {
        sxwjn = sxwjn;
        sdhAYuTAolX += reJlPXDfSZkJxkIA;
    }

    if (sdhAYuTAolX > -615765727) {
        for (int LAcsWuo = 1611355563; LAcsWuo > 0; LAcsWuo--) {
            sxwjn = WuCAdjGntJbFqX;
        }
    }

    return WuCAdjGntJbFqX;
}

int RfdaUIfxKe::tKvJfBYWBKu(int wAJcQt, int iFvUpnfTKF, int SOYhWJi, string IPgmiGbVHoffRSDA)
{
    bool NXkieiqUFTSP = true;
    string hHkRbhjEBMdsCz = string("mqJfgEfuHdIwjuTmILnoxKgHHkMErnEfaxbuFOqnyPTfpftrOHFiefNzMdyUlXKyRzHNYdgrYIjzBGnDtrIWtPRKfRQDORryGl");
    int GiVtfakDAM = -929371948;
    int ElihbppFVYDNz = 444839443;
    double wecMzkbBJgz = -638571.5308153377;
    bool fyJDHmsfe = false;
    bool KGBDyt = false;
    int UjxEGTFQ = 835964796;

    for (int gBfAJAajN = 1195525325; gBfAJAajN > 0; gBfAJAajN--) {
        GiVtfakDAM += ElihbppFVYDNz;
    }

    if (ElihbppFVYDNz > -929371948) {
        for (int jBHLvBpauUIczlpL = 1629371430; jBHLvBpauUIczlpL > 0; jBHLvBpauUIczlpL--) {
            continue;
        }
    }

    return UjxEGTFQ;
}

int RfdaUIfxKe::raHpS(double VsanCakBc, double UzjqT, double PZEYMNMZs, int MOxVRjIADtLnIrI, int LXEyphrDOslp)
{
    int KhLGhCCemiu = 1919213932;
    string spnpPWBcTS = string("EfAREqTIxjNxPRXrkQULXmnIsjVaoDqfVYbXCjvXgswNIvYhPHDCrZXwIdaiMPMjYKohNZOJUcFtZunrmKjxozZVwfXpajrNrFMfoJBYxiBowYOMdBnDRd");
    double UbVveFerPsjaggc = 584508.2079624352;
    string pXgfueTO = string("fUMegFFLWRzLzcspIZLuRDAkjN");
    string MMJYApJpq = string("hcwjVGJyXpTmXTzCjTMSzDqkLJWYpiGqpRshGLrTRakkzScMfUuhKqnTljhPqqj");
    string HqUhi = string("lZkPSBfKSqkfstUYTgzjThoiGBGYCOXokkcACVeJOufzUrBhikNXmYvwYZPtkwUsyIHjaPWfOHRwVopUsiweA");
    string lTJpfjiIEQxc = string("AVrlqggWBAdOEanzIbMjjbrvKEUXEekXF");

    for (int UxSSfr = 840512008; UxSSfr > 0; UxSSfr--) {
        continue;
    }

    for (int qUlAKTrJaEVF = 2146071730; qUlAKTrJaEVF > 0; qUlAKTrJaEVF--) {
        VsanCakBc = VsanCakBc;
    }

    if (spnpPWBcTS != string("lZkPSBfKSqkfstUYTgzjThoiGBGYCOXokkcACVeJOufzUrBhikNXmYvwYZPtkwUsyIHjaPWfOHRwVopUsiweA")) {
        for (int ocIPXBOTaBRVnKeF = 1535731957; ocIPXBOTaBRVnKeF > 0; ocIPXBOTaBRVnKeF--) {
            continue;
        }
    }

    for (int GUvggAA = 1107319177; GUvggAA > 0; GUvggAA--) {
        KhLGhCCemiu += MOxVRjIADtLnIrI;
        HqUhi = MMJYApJpq;
        lTJpfjiIEQxc += MMJYApJpq;
        VsanCakBc = UzjqT;
        HqUhi += spnpPWBcTS;
        MMJYApJpq += pXgfueTO;
    }

    return KhLGhCCemiu;
}

RfdaUIfxKe::RfdaUIfxKe()
{
    this->VjPgakl(-816801776, 836466.0736825585, string("QLWricqLLHKjRRVrpbHBxDBsSNPkJcjhuBnbBwJTvrno"), true);
    this->gJacxn(-994261.8065538828, true, -554189067);
    this->vBwdbPMVPjwEWl(false, -736716195, false, -737946395);
    this->BHfRFRHzorwSUtge(false, 830773721, string("EQLTJRcsHqOEygHEfjTtOXZrXEGVarGgyhIIEJtiWhYIcFcZiRKRsvvHffXgAXeOxDPcyetzzNzRYcnNAuUwlcPnLZJXKXJjtRukVhvMihBULVVMbbsAgyDcLCeHKSecdVoKKtmHmTNneuTTLPZavuqIFKy"), string("tIE"));
    this->czWdzzp(true, true, 1853730891, true);
    this->jaIVDSTqUxylQgWz(-706143.9354891672, 211516597, 1115048070);
    this->GTgSpIxDTj();
    this->xTGXF(string("IXrMtCOIhCLkeoNKSYuxJlAxEVSliJeNVQIhConaiCXZRNTOLOKagPETdufpdrfwYYM"), 733810901, 891786.652057524, -975289.003324077);
    this->JZpgjVhS(string("lWttNxjMpfYXOmBexpmFzuhYJiHFYCVIohhoZzfPWTWhRvdssRQrXczLBIGbbXTvHJNVFdXEbCiDNJEnhCccTPOsLkZASqARweUwAJBpxpOnwP"), false, false, -431279107);
    this->KpTjvIiTpy(false, -60271.65129971733, 1849957916);
    this->qlqZPtWqNUSMGcm(-150021.05991021733, 1843741386, 251282382);
    this->tTtLOeXsKJtLsz(string("ZLTUmnslPypsNWMPjppCiJTclNPLsYTjSqWmSrAseRnxdpUpKprcmLyzeRzcKRAYMWVlMsVoMXOFRZeFwjRZQKdYPmEVbpsGNUf"), string("pXMksBFWKjzgGz"));
    this->ObnADeO(true, -864526180, -88131937, 185665.61785570646, true);
    this->QvFCQzMOZ(1175461135, 608372.0651702167, false, true, -1406312721);
    this->PHInQvx();
    this->YITHhPeshohSR(-1011401.4926520903, -643226.5472405162, 749089938, -856854.7456768354, 576189.8536605699);
    this->bcFKS(false, -910695.9440137689, -179453557);
    this->HgeWBGXc();
    this->tKvJfBYWBKu(-2048534849, 2071317040, 554913471, string("xJfQposIayDcDEtxFSAxmJfCAurrNY"));
    this->raHpS(814111.0261856163, 849101.5373296945, -155461.20277469538, 1250756089, -1139138166);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zlNVRLoGxL
{
public:
    bool wTzAdLoG;

    zlNVRLoGxL();
    void FXzJIeXVyZSSp(double MjdQQa);
    string JLDmXN();
protected:
    string HyZkIp;

    int kuYKacQtQOlNYAD(bool GQykuus, double FiTPFzbe, int RgfXRsijq);
    void JUCwAoXw(bool UviOa);
    string uegRWtdwXksNZDIf();
    void aOtJU(int wkAVJ, double ARwUPXo, bool PtCQLPfYolj, bool DoiqFRzdsO, int OnbPDrKy);
    int nJWZLqHgAwoK(int VvtNQRkYay, bool DuqXDCgBHjqHcH, int wqvOdqudxnsrFh, string PZHCL, int yEyXnHvVQLidBSl);
private:
    string DXwqnMrs;
    string JEmRjCSIOOWe;
    double LyfmpCsBNuPMhNPa;

    string wWOcxIdFXwNqyU(double vGokHPjpVUk, int yeMrhrQsyIGwXMP, int JwSESnCJ);
    bool TgCUor(string BlvZoAQJjZV, bool pAvvBhxkDFmNvV, int OdGRJiVRb, double TKDXYngurS);
};

void zlNVRLoGxL::FXzJIeXVyZSSp(double MjdQQa)
{
    int gwGaUiMwftASFx = -1504676100;
    int WOCwwhHr = 411815486;
    int iGQQoYHpAFU = -1149824518;
    bool vrGplSklA = true;
    int KieMWhOdXXOMW = 2086152326;
    string htEnOKneK = string("fobbVJpCpOfmyOyeNLIUugeLgGnzQbhDFICzvNKVNRinPzBjxYCJpHUruptrPvfIVItkIYMJcGETLAyDxSxYTUhHRmyfnJtggYPgmVtsorbRAUAWVoNinOtaROuUWyqFiYjazgqeODVqqQkHarBZmUzSEqnNDvTzMjkZJBJwalWMfPFcDlEiIlfSdabgEyzuWUGZvgbxLQSMSZbpUfBYurnJuWlzxpS");
    int EVhjeFIflr = -1341637455;

    if (gwGaUiMwftASFx != -1149824518) {
        for (int fqnozlpxpNMG = 1712981081; fqnozlpxpNMG > 0; fqnozlpxpNMG--) {
            vrGplSklA = vrGplSklA;
            EVhjeFIflr *= EVhjeFIflr;
            WOCwwhHr = iGQQoYHpAFU;
        }
    }
}

string zlNVRLoGxL::JLDmXN()
{
    double vuGWJg = 205194.26884897889;

    if (vuGWJg <= 205194.26884897889) {
        for (int Mdvlg = 1793198305; Mdvlg > 0; Mdvlg--) {
            vuGWJg += vuGWJg;
            vuGWJg *= vuGWJg;
            vuGWJg += vuGWJg;
            vuGWJg *= vuGWJg;
            vuGWJg -= vuGWJg;
            vuGWJg /= vuGWJg;
        }
    }

    if (vuGWJg >= 205194.26884897889) {
        for (int DSPvrOIEkDNyc = 1208992817; DSPvrOIEkDNyc > 0; DSPvrOIEkDNyc--) {
            vuGWJg += vuGWJg;
            vuGWJg -= vuGWJg;
            vuGWJg = vuGWJg;
        }
    }

    return string("NhAdzzJrFoLOyuOansLENJlUhBHweJOdozfajXGmvxRWpKfkxJuZhtkIgwSnAhtGbSmPyXItakdMvHuRglzj");
}

int zlNVRLoGxL::kuYKacQtQOlNYAD(bool GQykuus, double FiTPFzbe, int RgfXRsijq)
{
    string EQzND = string("qZbpQIxWbgNLDMfmtcSoSswsIJgtxiIMNkikxKTbUzvfcUZkfYYpiLjZqrmAsmUYQYqicoesTQUkXsmuFLuld");
    bool LkHTLCAxkhIwAp = false;
    string yUSWJM = string("exkMsltFBeQgUBnopWTSakfzSNxgcvpfWAvWydRvaicCEPdbowxxVFpNIKcSwXSGTYIdNeVCfqcFUNdlfaDeHturtuyeNQpurcFWGXNOxdcyIjLeNJvUNbOxDLVGMAIZuIyNBlHjsmuBusoozwgKHqThnKtGdyIAuwNLqNlyzLWxBGJTDCWeepkyjBaTekFRzPvDKuyNNqdcJboDbjdrlJgFiaApwuvsWeeKKihUOFDr");
    double JbiiPcoUMOyxcIHj = 492726.56893351045;
    bool SlyGjE = true;

    for (int VLWeTDsQ = 94284235; VLWeTDsQ > 0; VLWeTDsQ--) {
        GQykuus = GQykuus;
    }

    for (int pVqGdjhEgmj = 1555061565; pVqGdjhEgmj > 0; pVqGdjhEgmj--) {
        continue;
    }

    return RgfXRsijq;
}

void zlNVRLoGxL::JUCwAoXw(bool UviOa)
{
    double hAITEGvOzAhxa = 997931.1653566406;
    bool VfYdRUNu = true;
    bool xVIBlGcbuL = true;
    string kUZhymGCjVKSFv = string("OtcEmAeLDBTDmrIfxApofJSbgjQKsJqJzVdMIAmLZLhzHvwgRTLfieywAbSNprLpkGXK");
    string miLdwutdiPYopg = string("yhtIHPBZxOcgDqsgWkQLTBDTHsBzvpPHzzqxOshnPtwvPEADRNiblYEItzIQEHdnBjDbnheECeOBHIdAzCpIpvgWQzQGykcLMuLoLuwucvAoWbvqRahAjzTmRBsfntdOaKjNyTSRkWulzjjGXnyyDKALPiPiPYBecCNtHVKfozuRKUllynmzyhSXyKciZcPvfNzsesshbFWFUonCmgzr");
    string LjryHpJhC = string("jQixPbeof");
    double aRQABicPr = 535103.3430887423;

    for (int kNkknQrmcjBMZ = 856489718; kNkknQrmcjBMZ > 0; kNkknQrmcjBMZ--) {
        UviOa = ! UviOa;
    }
}

string zlNVRLoGxL::uegRWtdwXksNZDIf()
{
    int TVXwfPXr = 49063226;
    double vlXrwN = -68798.68343279483;

    for (int qAGpHVuqEnhxVIyU = 240236862; qAGpHVuqEnhxVIyU > 0; qAGpHVuqEnhxVIyU--) {
        vlXrwN = vlXrwN;
        TVXwfPXr *= TVXwfPXr;
        TVXwfPXr += TVXwfPXr;
        TVXwfPXr = TVXwfPXr;
        vlXrwN = vlXrwN;
        TVXwfPXr = TVXwfPXr;
        TVXwfPXr -= TVXwfPXr;
    }

    if (TVXwfPXr > 49063226) {
        for (int DPyPc = 1327158108; DPyPc > 0; DPyPc--) {
            vlXrwN /= vlXrwN;
        }
    }

    for (int IxNOkjzjP = 1332527934; IxNOkjzjP > 0; IxNOkjzjP--) {
        vlXrwN *= vlXrwN;
        vlXrwN *= vlXrwN;
        vlXrwN *= vlXrwN;
        TVXwfPXr /= TVXwfPXr;
    }

    return string("lkAQgTsImwLWHfZJqgnNyebvJDUIVeUcELPbzprnNYvDxJfwDhlbCswwYhaxHpJJdlXDYfpHvJbJztjlKapyLsozQtcKeCczNukJMvFLbXRcieyknNYLXeLEOuriRVEQDEf");
}

void zlNVRLoGxL::aOtJU(int wkAVJ, double ARwUPXo, bool PtCQLPfYolj, bool DoiqFRzdsO, int OnbPDrKy)
{
    int DnrocnOmI = 2025402258;
    bool eYGWkTNNEf = true;
    string dJEJPyrqEbPO = string("jKoxLWZLtFqTfYqPeHXcOzaVLsVuVMBWcRKapptHMiYpamVnPFlNcnduzRlpGjJGiYXmhsXYRfxTtBIpqZMryqfEjBEUWRNhIwYqtdnlHRISCxdOzoTJhuYkimdOJLSesrIKJKBWQHWzAcSuEme");
    int uaQdKLziyuiGU = 1755102291;

    for (int izlivjsNqgBNNfi = 1368424387; izlivjsNqgBNNfi > 0; izlivjsNqgBNNfi--) {
        wkAVJ -= DnrocnOmI;
        OnbPDrKy /= uaQdKLziyuiGU;
        PtCQLPfYolj = DoiqFRzdsO;
    }

    if (uaQdKLziyuiGU < 2025402258) {
        for (int bquYTVi = 240443367; bquYTVi > 0; bquYTVi--) {
            PtCQLPfYolj = PtCQLPfYolj;
            DoiqFRzdsO = eYGWkTNNEf;
            uaQdKLziyuiGU += wkAVJ;
        }
    }

    for (int qhvTiLtb = 708159521; qhvTiLtb > 0; qhvTiLtb--) {
        DnrocnOmI /= DnrocnOmI;
        eYGWkTNNEf = eYGWkTNNEf;
        DnrocnOmI /= wkAVJ;
        eYGWkTNNEf = PtCQLPfYolj;
    }

    for (int aerUpqyvyTqOOe = 1263849800; aerUpqyvyTqOOe > 0; aerUpqyvyTqOOe--) {
        OnbPDrKy /= uaQdKLziyuiGU;
    }
}

int zlNVRLoGxL::nJWZLqHgAwoK(int VvtNQRkYay, bool DuqXDCgBHjqHcH, int wqvOdqudxnsrFh, string PZHCL, int yEyXnHvVQLidBSl)
{
    int PCcpEVN = 1404578881;
    bool nytfNzHgd = false;
    string JAvULMDgqMOHwg = string("sSljXKvWOPQivcVFphtNkwikWKAxoOXVUZehFBGNGscuGgLvBpsPcnLFjCDcTOev");
    bool TbPmyyQKtCnZsJyq = false;
    bool Lsycf = true;
    int BwnLpmk = 1362462616;
    bool pNXeEBTsiQeoqxhl = true;
    bool haxrVECBigQOK = true;
    string XDCdpozBJYqCkmTG = string("eKkNeEKlMXSVNJwomByMMthbrRXkijxiUnTTdTYnUfgWRtvjuAbGxuMGy");

    if (nytfNzHgd != false) {
        for (int cvxilf = 1140072764; cvxilf > 0; cvxilf--) {
            pNXeEBTsiQeoqxhl = ! nytfNzHgd;
        }
    }

    if (pNXeEBTsiQeoqxhl == false) {
        for (int TMeJf = 1916347798; TMeJf > 0; TMeJf--) {
            Lsycf = pNXeEBTsiQeoqxhl;
            VvtNQRkYay *= PCcpEVN;
        }
    }

    return BwnLpmk;
}

string zlNVRLoGxL::wWOcxIdFXwNqyU(double vGokHPjpVUk, int yeMrhrQsyIGwXMP, int JwSESnCJ)
{
    string tsPSdfsniWG = string("GOYTBzrkKAuohxHiXVQSStAPYOJhUbqrkZIGvHVmSvDLDIUXmKiQWcBfkXWSSwUHRjUhFnnFMWGNqrGRNWhwAFURBUvsdgfXdTvCZsLQkSQMTNIhvHqOTGjUB");
    string iHqzNIwF = string("QhfOSjXZSiHmeeyheqcKVWxNhCuvhsFSeyueerMnQbdjHoUtUHeWtXgrKfIxUFpTXYQxTdHYzQieZobkhvKqkOVbVPGWHxBd");
    double eZuNHwZXs = 461726.04076593084;

    if (JwSESnCJ > 672994479) {
        for (int mFwBoclERfzPyO = 393814339; mFwBoclERfzPyO > 0; mFwBoclERfzPyO--) {
            continue;
        }
    }

    return iHqzNIwF;
}

bool zlNVRLoGxL::TgCUor(string BlvZoAQJjZV, bool pAvvBhxkDFmNvV, int OdGRJiVRb, double TKDXYngurS)
{
    int AYHLqJArFEgD = 1583374303;

    for (int fkPKpqpZf = 154679910; fkPKpqpZf > 0; fkPKpqpZf--) {
        TKDXYngurS -= TKDXYngurS;
        OdGRJiVRb *= OdGRJiVRb;
        BlvZoAQJjZV += BlvZoAQJjZV;
        AYHLqJArFEgD *= AYHLqJArFEgD;
        OdGRJiVRb -= AYHLqJArFEgD;
    }

    return pAvvBhxkDFmNvV;
}

zlNVRLoGxL::zlNVRLoGxL()
{
    this->FXzJIeXVyZSSp(-15727.774142087468);
    this->JLDmXN();
    this->kuYKacQtQOlNYAD(true, 597639.0977130473, -1335295871);
    this->JUCwAoXw(false);
    this->uegRWtdwXksNZDIf();
    this->aOtJU(-11899521, 31426.39297094683, false, false, 611340727);
    this->nJWZLqHgAwoK(1390491318, false, -2041057767, string("rcbeuyBPOVwtvgTyEiRIzXuVJQkYdWlrTAJpmxsBiwwvJdsdeJahLGIQlPCvBAjYGCnXFfQlBOcowgEGMtHHxotYuASHDgKhoibUSDGKXamoyTouNDoIoHntsHnqRSMAkIWQEUDuhkDnzTISjQQhXdOQBuGOgCoDeUSORbmAcnvbdEpboxyQxJQYmuPZ"), -696957669);
    this->wWOcxIdFXwNqyU(399344.58862426324, -836983797, 672994479);
    this->TgCUor(string("XahjUWUhnZWRPohBZFbRFCtTunkDffPrZoyumxtdfegRJKwIdvmYcyCjRsFHKMVDQsDOPgcaCMYCecdaIlUAtCkmbZLQkurPBwlZzvHHlnBCwKdwmVYtddeXEzONkcoULDwkkhmVeQdrCwAICiukxYfPsPvzTeMsoFEfcojKCXhoiKpjaspCrljFwHLkFwzYBuwnQUrVctXFUrtVdmTxbhAKpJrQwDlHBMFatxrrCfbEkxykNKkYQ"), false, -1276869604, -513459.210333238);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DPXDC
{
public:
    double lOcdBBNZTcwnl;
    int jiVNJLzgtB;
    string DQaLbHZNhaOoDki;
    int NHbpkYVV;

    DPXDC();
protected:
    double KccTuHOYQ;
    int IBMQd;
    string ctbLQGuxTR;
    int GfMjTojPpxsECYIy;
    double WTbJMlLRsttxVNa;
    string lQAjbWQPb;

    int oERNNw(double RztyMtRxu, bool lHMlrqJF, string kAZzBztPXsGQqeMI, int qZjlwCchchZcco);
    bool DkBxiGEtKBgSqLq(bool ItGxjxt, string yxjuYVEGu);
    double rBjSwTbUqqZOzNMA(int KGaihfYSaXipzV, string zWbxz);
    int AjfsWLLlmiCKGd(double FqdCsMHGqpgw, string vJIZbVQyvYfBNfr);
private:
    bool ruugCoPmFvN;
    int BBxyTXSbMxSGatQA;
    string UlzMyaTq;

    int xiIzIcOrg(double jMAWzzmh, int sOakyLbPdP, bool ofhlpLRykvK);
    double IDeTQE(double ZfbKEPQu, double UbhYwoF, int aEmHZWrBYOxq, double TQhoCSstcjdCr);
    string kjxGjCgxnzdn(bool bbOaiDGZIZrd, string lDzihTOdjwccOOzC, bool SQnnqQbTUDyTc, string FyfTEbGsboWpEclK, int nwNhlgAbUXwzgu);
    string KnwbmVry(int DRKMr, double IXSwRxUQyaLF, string iwjpyYuvgByenA);
    bool XVwqtPxnIZXQ(int DKYuIGwaLG, double TwkkymdHjc, bool pUFgw);
    int wBrAgwjOhcZ();
    string YWbkKFmFkpl(bool hQsdAVZw);
    string uQBotUAnT(string COCBNfLQds, bool ssVtVhEegYYy, bool EQHyyGCbeMkiY, double ucZUNm, bool yDOurM);
};

int DPXDC::oERNNw(double RztyMtRxu, bool lHMlrqJF, string kAZzBztPXsGQqeMI, int qZjlwCchchZcco)
{
    string TrBvXnQ = string("xESRISECdZWtWzlqvZqKCKTyyoVRKmenMjqVrdRrQQTdTjzaOMJHmZQwzrwRjDUxFROEViWhMXIbwEThxZtPBTWEEJMoRDzXXCAnQPALKmUnLVMnVqhlMxrUTYHEGsTfTkJsQAgjnfEIDJBrLiYXUICIEqwGP");
    string RaDnAkGo = string("QoKDjPkdVlpvmsWnkZrVMZQZNJlMFjqIJHMjCVdSNbiqKTHSwhZFYYBfgJtIYgJQWYPViBdgXbmGpDeVeutCEUMGnqAHzFVhIpkanmgZdKJhtSXPHWrDvjeUUInxxgXgqyeiRXOpkiZlvJtRxWSKFdvRlGOKSGdZUofpqnQruspznzbnRUwnPHItvtKfvukGcfEiOlwUsoanSjLnFbgTeJImtPtHxuWCYvvriPGWOgqSaPmOvSUIkfgGWRMQ");
    double NluwyqxNOQ = 386022.6752799316;
    string EfGDn = string("cgDycTfxjNXEwaaJmochyIGQXhGRsXSRaCrRIOpWafUQinvXQFAnLqheYldMMepHNhkvClwEcXoGnesuIsfJGwRtDFyCbfFyRsSCkpruASmWYzrVSApgJpObUZjvnAbOkLCBTwcRPN");
    bool fAXmfmRUeYGdYT = false;
    string hnkkOVX = string("MhEwzpKcPOapxSfzCXlchodAizjwAIAnbzovLKPsXtgGqwXlnOOq");
    int LhQlNZFhbY = -2065471609;

    if (EfGDn > string("QoKDjPkdVlpvmsWnkZrVMZQZNJlMFjqIJHMjCVdSNbiqKTHSwhZFYYBfgJtIYgJQWYPViBdgXbmGpDeVeutCEUMGnqAHzFVhIpkanmgZdKJhtSXPHWrDvjeUUInxxgXgqyeiRXOpkiZlvJtRxWSKFdvRlGOKSGdZUofpqnQruspznzbnRUwnPHItvtKfvukGcfEiOlwUsoanSjLnFbgTeJImtPtHxuWCYvvriPGWOgqSaPmOvSUIkfgGWRMQ")) {
        for (int KWxWyeENRAce = 1095213566; KWxWyeENRAce > 0; KWxWyeENRAce--) {
            lHMlrqJF = ! lHMlrqJF;
            RztyMtRxu += NluwyqxNOQ;
        }
    }

    for (int VidGBNVVSchaxCky = 638111241; VidGBNVVSchaxCky > 0; VidGBNVVSchaxCky--) {
        continue;
    }

    return LhQlNZFhbY;
}

bool DPXDC::DkBxiGEtKBgSqLq(bool ItGxjxt, string yxjuYVEGu)
{
    double avIRNaOOkc = -42427.64259778427;
    int SRJnaiX = -1304539237;

    for (int bxnrhpZe = 557337047; bxnrhpZe > 0; bxnrhpZe--) {
        SRJnaiX -= SRJnaiX;
    }

    if (yxjuYVEGu < string("lIhROEzLvkrQOvgyrAMVxsVvrmeKltYDkYjSpJzHtwEEmLrapLLXPqkSicFLROuVsrbLxDEfBtETfWpCocXSVdHShmZgSzJmrLwFomHrFWOdbagkRQUbZTZydHHjRkLRusfcqfnQaF")) {
        for (int USuxDRzg = 392422461; USuxDRzg > 0; USuxDRzg--) {
            SRJnaiX *= SRJnaiX;
        }
    }

    for (int VDrik = 415049629; VDrik > 0; VDrik--) {
        continue;
    }

    for (int wXHCgRJsbPZUu = 809097078; wXHCgRJsbPZUu > 0; wXHCgRJsbPZUu--) {
        avIRNaOOkc = avIRNaOOkc;
        yxjuYVEGu = yxjuYVEGu;
    }

    if (avIRNaOOkc < -42427.64259778427) {
        for (int eDWRrUJsOggEO = 347317650; eDWRrUJsOggEO > 0; eDWRrUJsOggEO--) {
            SRJnaiX /= SRJnaiX;
        }
    }

    for (int ivxcKL = 1860825358; ivxcKL > 0; ivxcKL--) {
        avIRNaOOkc *= avIRNaOOkc;
        yxjuYVEGu = yxjuYVEGu;
        ItGxjxt = ItGxjxt;
        SRJnaiX += SRJnaiX;
    }

    for (int tXLkxV = 1587022115; tXLkxV > 0; tXLkxV--) {
        continue;
    }

    return ItGxjxt;
}

double DPXDC::rBjSwTbUqqZOzNMA(int KGaihfYSaXipzV, string zWbxz)
{
    double Deoyz = -491451.25329766056;
    double qLGidUB = 580121.5455828506;
    bool xTNErM = true;
    int AJPiVHwwnrlzhzZk = -551542302;
    double eVeWGkSOq = 750459.5752715826;
    int PBUDkIWpWqYsi = -490916344;
    bool wKfuL = true;
    double DxZuRCTPrToGt = -390142.2156458482;
    int RiCVaIYex = 2072859506;

    if (Deoyz < -491451.25329766056) {
        for (int BMEHPFmfBPeswWMU = 888831205; BMEHPFmfBPeswWMU > 0; BMEHPFmfBPeswWMU--) {
            Deoyz /= Deoyz;
        }
    }

    for (int PWnsguMprPGL = 1813814489; PWnsguMprPGL > 0; PWnsguMprPGL--) {
        PBUDkIWpWqYsi = PBUDkIWpWqYsi;
    }

    return DxZuRCTPrToGt;
}

int DPXDC::AjfsWLLlmiCKGd(double FqdCsMHGqpgw, string vJIZbVQyvYfBNfr)
{
    bool wGYpCfwe = true;
    int mpKJmyQdHj = 17773513;
    string QyfNoZ = string("mgCNkKfwOAigKWgUThtymPsKTHCaOrCowQAkBuhUFgoSNCDexPuyGZsUtIKZqBrQMVsPOSGONgadhMyuGHeLsCOZpekbPmCdvPhbgSPjbnaUqvSbaAmssKTfjBlfzAfXsPlmcsTFrGDAgbAiBWLqbsBeITCRfiSKYRtZIUugyKaodFjQXRNdGMGHuaUedRqytOorjaEBaGEXIneYHCyYgfpUHzWcLCavFHXxQITWWgWfmRrwBbvVt");
    double igUqRirfCOv = -31961.795449361336;
    string OkIpJkpeAGNXrj = string("ypFuKUCeTCRZROhprYvXpuqu");
    string qKBWpaqWkWfry = string("BlrkOuYOAsVJDLCrawazY");
    bool AscowXcjzWlZwops = false;
    double DbSXnvBcAiSmv = -907535.2942245892;
    int vNmxSqMkcMW = -371959302;

    for (int Pzghstd = 958683611; Pzghstd > 0; Pzghstd--) {
        vJIZbVQyvYfBNfr += vJIZbVQyvYfBNfr;
    }

    return vNmxSqMkcMW;
}

int DPXDC::xiIzIcOrg(double jMAWzzmh, int sOakyLbPdP, bool ofhlpLRykvK)
{
    int AYSKs = 1440565420;
    int PHDIuqEhb = 1403964454;
    string ERQoiWqUbVt = string("efxJpKwzypOhdTQGCskcNGJawTjHpsgpTMGSCshQZiMgOovTgzujqeWBciTChAUWiVweKGsuUzmeawPUQrxiaRnzGyZoGRDoGIxkuYVhuRRsFWCsmWLViqLpAACvNRhCxQlVgdJSbmpclIjOgCciSgswEktzZBuQpeGipAcffzaWsTsOUOEgoippjPLzxjwlwTUQjTIiehQWuJAHHbYWdyEdAklsKttogoTeGXCFc");
    string SiUKJROalt = string("CMWZCwfRjBMiCjSXFGqXdYviMUvIpvwJhMjVvxYZorEfUwGguckaFMrPxAsOGWIMULPKxdcMvwYrxwGZYVhcdbBMqLXazCAOMFCtvzajkKIjbHqmFwNOQMtTPeDRmYVGxADesQcUTKagzqYsdgcLwcQkVdbdKgNhTqhrAyvLKYzQTUPkmiCeXSLQfXyOltIQLQzMgQXKvtHdytnKrHSYGdwxtrcEIIpsgdjMqArmdyMUiJDZNCm");
    int htFCKcj = 1866305206;
    double MRGlI = -764756.6699176691;
    bool TvOMtaHTiDvU = false;
    bool bzCOTOvvWPxm = true;
    int XHFZuAZzd = -104428185;
    string XZtcchMQsTPcYUn = string("IHTEXGPBsvKgJiJWQPJiNaTpAauhnEQleqnnWXsYBNBtlNHvL");

    for (int UZaESQNd = 1882739908; UZaESQNd > 0; UZaESQNd--) {
        htFCKcj = AYSKs;
        bzCOTOvvWPxm = ! ofhlpLRykvK;
    }

    if (sOakyLbPdP > 1403964454) {
        for (int phHvVaQnLkl = 1580444267; phHvVaQnLkl > 0; phHvVaQnLkl--) {
            continue;
        }
    }

    if (jMAWzzmh <= -764756.6699176691) {
        for (int ItIIKbAPLQxPm = 1104859957; ItIIKbAPLQxPm > 0; ItIIKbAPLQxPm--) {
            bzCOTOvvWPxm = ofhlpLRykvK;
        }
    }

    if (TvOMtaHTiDvU != true) {
        for (int haToUlorGdJotZ = 36803893; haToUlorGdJotZ > 0; haToUlorGdJotZ--) {
            sOakyLbPdP = htFCKcj;
        }
    }

    return XHFZuAZzd;
}

double DPXDC::IDeTQE(double ZfbKEPQu, double UbhYwoF, int aEmHZWrBYOxq, double TQhoCSstcjdCr)
{
    int kgKILPvmU = -1765912114;

    for (int SdXHLffyJMkO = 1211127417; SdXHLffyJMkO > 0; SdXHLffyJMkO--) {
        ZfbKEPQu += UbhYwoF;
        ZfbKEPQu = ZfbKEPQu;
        UbhYwoF += TQhoCSstcjdCr;
    }

    for (int ZPyrwcf = 1130458398; ZPyrwcf > 0; ZPyrwcf--) {
        aEmHZWrBYOxq = kgKILPvmU;
        aEmHZWrBYOxq += aEmHZWrBYOxq;
    }

    for (int cEdShXogjJnvkLvn = 567431415; cEdShXogjJnvkLvn > 0; cEdShXogjJnvkLvn--) {
        aEmHZWrBYOxq = kgKILPvmU;
    }

    for (int OXQFbSIrDCQWduD = 1959288752; OXQFbSIrDCQWduD > 0; OXQFbSIrDCQWduD--) {
        TQhoCSstcjdCr = ZfbKEPQu;
        kgKILPvmU *= kgKILPvmU;
        kgKILPvmU *= aEmHZWrBYOxq;
        UbhYwoF = ZfbKEPQu;
        kgKILPvmU *= kgKILPvmU;
    }

    for (int Upedrim = 1540668033; Upedrim > 0; Upedrim--) {
        UbhYwoF /= TQhoCSstcjdCr;
        aEmHZWrBYOxq += aEmHZWrBYOxq;
    }

    return TQhoCSstcjdCr;
}

string DPXDC::kjxGjCgxnzdn(bool bbOaiDGZIZrd, string lDzihTOdjwccOOzC, bool SQnnqQbTUDyTc, string FyfTEbGsboWpEclK, int nwNhlgAbUXwzgu)
{
    int rHQRkhJtr = 572091958;
    double WnpOylwgYC = 297857.93113411224;
    int NTUPaKPlPcoZKe = 1767042444;
    bool tJsNllibeQX = false;

    for (int ZPSCHgJGaShW = 147839718; ZPSCHgJGaShW > 0; ZPSCHgJGaShW--) {
        continue;
    }

    return FyfTEbGsboWpEclK;
}

string DPXDC::KnwbmVry(int DRKMr, double IXSwRxUQyaLF, string iwjpyYuvgByenA)
{
    double PbYUQGiaumpzieu = -545333.9228873879;
    string VeFCJKJCCl = string("DjuJPgPAZOBTyGHpnJzmANsgtJXXpWtKXXLZFNWtDjXyEztpcVryLeVjetMLaqWHPqiiNYwaiKyEQYeudxOIDuQjFfztHUkcYKYPJkDpbsovuIWjCDfioGYjzgNtQarabPMIyFqAEZiLapeKLNKiDFzLgVCzuqCVQkGGKKyuZPjEkqpXVPammWASGOZXKuJRmIiAjagpqADDfNRoVkpMkqXKOuK");
    int caiDMOwfAvExb = -1622876314;
    double xdBQNLwzlzjlF = -428764.4651792987;
    double fzBAmPTO = -275102.33159738925;
    string NOkUrpRKahmO = string("TsJjXMFCbjitinWzvmPHoeJwKXgrpkJFkFDzPLMPwKIBRpkxOrqhPoWPisUpHnNVVzILkvrsUCzhATelqkDaQckBBpZacIfUJfJfyoKOvJp");
    double UXdTjeDzBnbt = -879930.6315059665;

    for (int uRGXE = 578155549; uRGXE > 0; uRGXE--) {
        UXdTjeDzBnbt *= fzBAmPTO;
        PbYUQGiaumpzieu /= PbYUQGiaumpzieu;
        xdBQNLwzlzjlF -= UXdTjeDzBnbt;
        IXSwRxUQyaLF += xdBQNLwzlzjlF;
        NOkUrpRKahmO = NOkUrpRKahmO;
        xdBQNLwzlzjlF -= IXSwRxUQyaLF;
        iwjpyYuvgByenA = NOkUrpRKahmO;
        caiDMOwfAvExb = DRKMr;
    }

    return NOkUrpRKahmO;
}

bool DPXDC::XVwqtPxnIZXQ(int DKYuIGwaLG, double TwkkymdHjc, bool pUFgw)
{
    string IldLWTjbxEb = string("BzzJVvJFeI");
    bool hlnwzmrAdv = false;
    int DtcpeiE = 738091462;
    string ZReEJ = string("IvOQzWxdIKmcZmRkqQZKOgJwUcIUzIoMgIXXzRBFBwjQEnrssQIUUeGLvJQpZlGVCyMHJwxKwkWJYDIYOaLHWLRYXgIdMGtCCegLqoEPeJERvyfNzbZJeokYweDnanIgdtMfIgHHAtVCuk");
    string tYSYqLYHkNux = string("LHHXEAorDhrIElMXXuftcXZyiUCtDIVPVeNUSuqGKIQtcqqHG");
    bool sQrTBRVbjfuZG = false;
    double uvmqClGO = 457969.514659471;
    int iVobqOdS = 2123363219;

    for (int XajUVxdFr = 1782488491; XajUVxdFr > 0; XajUVxdFr--) {
        iVobqOdS += DtcpeiE;
        IldLWTjbxEb = tYSYqLYHkNux;
    }

    return sQrTBRVbjfuZG;
}

int DPXDC::wBrAgwjOhcZ()
{
    string vKmwhbSlcmuLew = string("AoXeEAAhzhElPccHWhnDIItkSwvnaQiNKcvWnIgCyIfuikrpGVHhRQWSvGCHyTSRhMrYEwbgSZArvJm");
    bool tOllDpAlfTK = false;
    double nbGucZbbFxnKoZ = -706362.4183494181;
    string HdKIyY = string("bCPEaTGpmTDtAgFtrJNpcHNLzLqpzWSQsadhU");
    string KjhWUiBqC = string("pDYFsAHX");
    double YuxHwlhq = -454163.9366417857;
    string fXVVVlPrBDz = string("uvLrYbzdWUFDNvFHIPYnQwoCDkuDfjYuLKbRTbkHTDWmYguVESpjiiTEOKkPlMnPeditOieLDphKHRMmnLVVguAZufiOEFRkZZZfODMJQrjaLscWOdGnhrPXSPjcRJnNaMogkUNTfeStEqQUJiCaMCswwGOdbjmmdWDGEWSlXmFNkglmrPepQOrPvmiTcMjcKWlUXzkiPnLGuDCVxrQqeeCOqUszaBEjiIpLDqWtfMhsHLsDBRdyS");

    for (int OTjAkNupbkrin = 813036454; OTjAkNupbkrin > 0; OTjAkNupbkrin--) {
        tOllDpAlfTK = tOllDpAlfTK;
        KjhWUiBqC = vKmwhbSlcmuLew;
    }

    for (int dxHHpseAn = 1203074822; dxHHpseAn > 0; dxHHpseAn--) {
        continue;
    }

    return 1043725725;
}

string DPXDC::YWbkKFmFkpl(bool hQsdAVZw)
{
    double mBDykodFxmKdoG = 950440.9597630824;
    int seBjGD = 17190132;
    bool mwdZYx = true;
    bool HZQdEOXtxv = false;
    double GMqeweSz = -402608.18486443197;
    bool LOPMCLLvHq = true;
    double whQSjbOmSYxzXE = -758872.1237939827;
    bool toTbQF = true;

    return string("MudlGmtpMXPKFgvqEimleHIvUdEcYMcgYDhIDsQRbcKAwAoOpgOWEafIFmKfLyGtwsnSpWGERdxvzVPUFgewXziZjFzfPlkmkoNGsYQZhGV");
}

string DPXDC::uQBotUAnT(string COCBNfLQds, bool ssVtVhEegYYy, bool EQHyyGCbeMkiY, double ucZUNm, bool yDOurM)
{
    double sPRBBBBYE = -683438.9917734634;
    bool YcHaSiKDWKQLJ = false;
    bool wHrVKNZ = false;
    double LLPPxvdxMdEZ = 557138.3763061755;
    bool lJaLiUoGOCaWs = false;
    int qaeUEj = -1483789874;

    if (EQHyyGCbeMkiY == false) {
        for (int ZlXkmdsdo = 528215142; ZlXkmdsdo > 0; ZlXkmdsdo--) {
            wHrVKNZ = EQHyyGCbeMkiY;
            ssVtVhEegYYy = ! YcHaSiKDWKQLJ;
        }
    }

    for (int BHPfcTG = 36636819; BHPfcTG > 0; BHPfcTG--) {
        YcHaSiKDWKQLJ = ! yDOurM;
        LLPPxvdxMdEZ -= ucZUNm;
    }

    for (int AAMYZrZLhAlMz = 979365843; AAMYZrZLhAlMz > 0; AAMYZrZLhAlMz--) {
        ssVtVhEegYYy = ! wHrVKNZ;
        EQHyyGCbeMkiY = ! yDOurM;
    }

    for (int kNqFZZKjURIccY = 396156894; kNqFZZKjURIccY > 0; kNqFZZKjURIccY--) {
        ucZUNm -= sPRBBBBYE;
    }

    return COCBNfLQds;
}

DPXDC::DPXDC()
{
    this->oERNNw(-178413.95645434398, true, string("yUJhdlotUboTPBkQvlMJutadQpflMmKym"), -808799527);
    this->DkBxiGEtKBgSqLq(true, string("lIhROEzLvkrQOvgyrAMVxsVvrmeKltYDkYjSpJzHtwEEmLrapLLXPqkSicFLROuVsrbLxDEfBtETfWpCocXSVdHShmZgSzJmrLwFomHrFWOdbagkRQUbZTZydHHjRkLRusfcqfnQaF"));
    this->rBjSwTbUqqZOzNMA(-1582793625, string("oEYgbuIFeYIiRIaFuZvAEQUkEVjjCbzASRdUJPlOieUrxTycrasUhEgKRfKOQbvdFZjosxqLciErISusilEofNzzPvvNIBDCgnnxOCZuIybXxTdTGMCONRkmHBgSUPMSHsSJtBboMYZGqNgDmXoxvKdmcBDrpOfI"));
    this->AjfsWLLlmiCKGd(725774.780846621, string("iGdGXAJLezxWTJChtuSwTepHsxTcynboTOhIxtIOhUWwtJxWtWcNeKDUEhNALYFWAklEUeWJPupaVEhxTVsloMMvClvBrAVndYapYbudoWdPknzxOaMidpuqxuScVLPcBzbFSNOIqWhMDdXhKBV"));
    this->xiIzIcOrg(597427.6618182601, -1008732382, false);
    this->IDeTQE(443664.7281057934, -940027.2152684499, 1365215713, -1003081.1206044842);
    this->kjxGjCgxnzdn(false, string("XZAQPzLeWyETOptlmomqlXEjAYScIxbQvChhDJSXxCrrXRNISgPMwtvhQIzRPUpqxLJzniYxTWujBkJYfkMZsQUQbHeukCZPlIsYtQNVQVgFtYNOtjuuJLrkSCKtbfDPGtVKWo"), true, string("HwNcwUueZYcyaUplbPlnGWQAJMoZZFywKLpHTgODkUQGbZHLxTXGQgTHRkpkJRozehJuqwIMYNLQGlrbmWSLCEHDbnrvrXDLVUaCpYMcwdjBxgNQTRuZbUzWOUrtboApKjRqUCQjvkwcHWauSVMKZUrSzrTQDxpEcKhUcsZhcRAKkHCHPObKSzTKnUaOWMXNIRfzWulNFYZKmcAUQpldHxXgglrfZG"), -36404077);
    this->KnwbmVry(-1581073825, 143854.50904934076, string("hHNZKeoEtVaCuwvskYfxQFjdJjgrBzfwhbxHDCxeKkWubRryHYwkLYfHxuyyfQnUczLcTwClaKOqYnXDZMEuzYMgbyMUaggYucvbpLOrFvMOeUrYoqnftqPMNESWsVrlUTmCLNuAZaNJhEZDSMMazyhSOjWUckFAjreKbSgrZEGrNARMgwgXVNduNcnVOwSUTWtKXKdaSkMILENtWtgplBhvTxEVK"));
    this->XVwqtPxnIZXQ(-74051476, -28814.30427432535, true);
    this->wBrAgwjOhcZ();
    this->YWbkKFmFkpl(true);
    this->uQBotUAnT(string("EyLrrE"), false, false, -698639.7611243436, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FynIyrCzG
{
public:
    int JiWSoR;
    bool QldXdG;
    double OIrIfVwwulam;
    bool TtkleVhb;

    FynIyrCzG();
    double JtaTs(bool hFIeBtAFgDX, string UkrAis, string vhGkhXoiviq);
    bool rsxPFDsFRPgmDK(double dQqYWY, int DVcaABqBPFaeQz, string uzBDBs, bool TIcSCSvN, bool cRbPljw);
protected:
    string XhxLDVkns;
    bool MEJYswjUrdnhTB;
    string WdYOGvyzlXK;
    bool pAIRrWQ;
    int QWPydfAtGBwCJb;
    bool yUWoASMNJ;

    bool XTHhlS();
    double AUdHzAdkVjGtr();
    bool jBmQJpLIqtVZBRL(string iuBlGwUkBL);
private:
    string OXaWzbrzW;

    bool sMWyGAkZ(bool JzMqfZEZpkXocT, double qvkIJgxfJnuBtj);
    double hRknuyjbM(int mvxxJ, int vzdWQIc, bool qbTiDbUMeffD);
    bool bMIWSWwdC(int cHgPOCkWstGVc, bool igEQwSPKAzt, double jVQCIlIM, string VcCdUWEQ);
};

double FynIyrCzG::JtaTs(bool hFIeBtAFgDX, string UkrAis, string vhGkhXoiviq)
{
    double AGcjSn = 20613.0719898554;
    int LzEOwnRCj = -1822306958;
    bool fKbIOWgWzkwuqK = true;
    int GBddmvafKIelj = -1589993038;

    for (int UgUAFexJLTGGq = 831536040; UgUAFexJLTGGq > 0; UgUAFexJLTGGq--) {
        fKbIOWgWzkwuqK = fKbIOWgWzkwuqK;
    }

    for (int uAmJLXwlJuQeKgj = 981232646; uAmJLXwlJuQeKgj > 0; uAmJLXwlJuQeKgj--) {
        fKbIOWgWzkwuqK = ! hFIeBtAFgDX;
        hFIeBtAFgDX = fKbIOWgWzkwuqK;
        fKbIOWgWzkwuqK = hFIeBtAFgDX;
        AGcjSn = AGcjSn;
    }

    for (int dYLiUldtgXe = 1112721596; dYLiUldtgXe > 0; dYLiUldtgXe--) {
        UkrAis = vhGkhXoiviq;
    }

    return AGcjSn;
}

bool FynIyrCzG::rsxPFDsFRPgmDK(double dQqYWY, int DVcaABqBPFaeQz, string uzBDBs, bool TIcSCSvN, bool cRbPljw)
{
    string JDEIcDXZCBMPSTO = string("bFZqqhMKpDwPmwsNmLusZVicPxhdhGayVthzOTDCHsRpxijdLmwzCDCpGGFmWRrdmpOfeWPFmdgotDzuAalbyStCWSBERmplfLsedHhPUflsVTeEyVfFpmMoVQHLXpTDovNNbxtnvAYaZUCdBquCxJdtXAIoNgFocQvDhTXIzgrLlupZZyaFKUBsVKtxwwitaWJmlYArZifcbOpLyVuAiWFfcrpUgfkNBEZEnKCLlsbrSarFiugVJZmX");
    bool IvoIInZfSc = false;
    double TTUotwLXIEfzAv = 108825.84331357777;
    bool SOZZKsHCsy = false;
    double YxZjlG = 67286.90852291824;
    string bExFrzcMIye = string("jyQXWPGWesniQrpIjMPBPGUznCSsXdewiNQqmtGOOtRcFlXtxshLCVWIjUN");
    string ulCsiwzUeVmxq = string("HxMGswNYcWHOHnUotmlINhZLHUQEoehtamTPqJHPaXDysjhFMxLQBzHzbBVCQDTXIeRNOsKXLEhTuGVTpfLZCFAGFfuIlAqryMIhShuYSSEBjEhLNLqRkKwxR");

    for (int RozVPAsZdIgC = 403084163; RozVPAsZdIgC > 0; RozVPAsZdIgC--) {
        continue;
    }

    return SOZZKsHCsy;
}

bool FynIyrCzG::XTHhlS()
{
    int WVSkiX = -1592002765;
    bool WCWgSqKAu = true;
    int QQhgdwwSHxfMkRx = 41549179;
    int lzXgyOocjvwSDv = -1384758550;
    int ewRJKoekNiSe = 1066782231;
    bool kgklV = false;
    int KNWrgdhMsvRJO = -1566634993;
    int bLLBINPrQuG = 106515104;
    bool vginIr = true;

    if (WVSkiX == -1384758550) {
        for (int PLYBZRmDaGrqXiS = 484355578; PLYBZRmDaGrqXiS > 0; PLYBZRmDaGrqXiS--) {
            ewRJKoekNiSe += bLLBINPrQuG;
            ewRJKoekNiSe -= WVSkiX;
        }
    }

    if (KNWrgdhMsvRJO > -1566634993) {
        for (int uWDtGZIugXMxD = 1880956813; uWDtGZIugXMxD > 0; uWDtGZIugXMxD--) {
            vginIr = kgklV;
        }
    }

    if (lzXgyOocjvwSDv != -1384758550) {
        for (int PVPyeGRgPPbJ = 347211432; PVPyeGRgPPbJ > 0; PVPyeGRgPPbJ--) {
            ewRJKoekNiSe *= KNWrgdhMsvRJO;
            bLLBINPrQuG += lzXgyOocjvwSDv;
        }
    }

    for (int sJSvUdsgJYUMNAAY = 513381149; sJSvUdsgJYUMNAAY > 0; sJSvUdsgJYUMNAAY--) {
        QQhgdwwSHxfMkRx *= bLLBINPrQuG;
        bLLBINPrQuG = KNWrgdhMsvRJO;
    }

    return vginIr;
}

double FynIyrCzG::AUdHzAdkVjGtr()
{
    double dyqJpGXQl = 150202.9985362205;
    double cBKeQdBQMZBvArz = 944957.8815828206;
    bool UFZyP = true;

    if (dyqJpGXQl != 150202.9985362205) {
        for (int lRCYUAxJsZqoiyIx = 621222774; lRCYUAxJsZqoiyIx > 0; lRCYUAxJsZqoiyIx--) {
            continue;
        }
    }

    for (int VYEnTfVmxDMZsqVo = 774081552; VYEnTfVmxDMZsqVo > 0; VYEnTfVmxDMZsqVo--) {
        UFZyP = UFZyP;
        cBKeQdBQMZBvArz -= dyqJpGXQl;
        cBKeQdBQMZBvArz += cBKeQdBQMZBvArz;
        dyqJpGXQl *= dyqJpGXQl;
    }

    for (int lUHwbjGIsbqPNjEN = 1384952289; lUHwbjGIsbqPNjEN > 0; lUHwbjGIsbqPNjEN--) {
        dyqJpGXQl += dyqJpGXQl;
        cBKeQdBQMZBvArz -= dyqJpGXQl;
        dyqJpGXQl += dyqJpGXQl;
        dyqJpGXQl *= dyqJpGXQl;
        cBKeQdBQMZBvArz = cBKeQdBQMZBvArz;
    }

    return cBKeQdBQMZBvArz;
}

bool FynIyrCzG::jBmQJpLIqtVZBRL(string iuBlGwUkBL)
{
    int ddjLAjQFDXLGGjWC = 1081971456;
    double EfaTUCFagfsgB = -364722.6553806894;

    if (iuBlGwUkBL == string("vsicASLkOuGvQKcZyvdeLdmknDOMFylptcmjVlkPoZuxpaBFnBhMcTjIipWolzSpcloeynIbWjYQisvrAsOQskgkasPZDsyxQkkdSyvVBJdNRyvDfQVXxdPabkTsUNuklhUCIpoqHgEMhIGZyEBxJauakKrXgzAiYPNVGgZphTvhfEBcCvBafFnyrLLUKNkoXkXjQOQwuyxpufbgsMBiJeIkLDHtLoUOcMPLxfKCcopNeJtTuq")) {
        for (int KHCrNNJ = 325179535; KHCrNNJ > 0; KHCrNNJ--) {
            ddjLAjQFDXLGGjWC -= ddjLAjQFDXLGGjWC;
        }
    }

    for (int iKKMQ = 312395979; iKKMQ > 0; iKKMQ--) {
        ddjLAjQFDXLGGjWC *= ddjLAjQFDXLGGjWC;
        EfaTUCFagfsgB -= EfaTUCFagfsgB;
        ddjLAjQFDXLGGjWC = ddjLAjQFDXLGGjWC;
        ddjLAjQFDXLGGjWC -= ddjLAjQFDXLGGjWC;
        EfaTUCFagfsgB /= EfaTUCFagfsgB;
    }

    return true;
}

bool FynIyrCzG::sMWyGAkZ(bool JzMqfZEZpkXocT, double qvkIJgxfJnuBtj)
{
    double VeUNUH = 166842.36833162067;

    return JzMqfZEZpkXocT;
}

double FynIyrCzG::hRknuyjbM(int mvxxJ, int vzdWQIc, bool qbTiDbUMeffD)
{
    double jWNVuKdVOa = -956859.437677839;
    int TTSCZsId = -1432588095;
    string VaGQidxDPebfi = string("ZTlbVIRUmObJGZhAbTsGiRoiPWTCesamFzFKubUPubXugFVEuOatRfwNpZIooXZphee");
    bool dkXTKSGueeK = true;
    int dDzMo = 1226086263;
    int mWAdfA = 1353219067;
    double kTnMijxqMatTfDwv = -355981.9825592913;

    for (int HTTqtZJbEVbImZ = 1435357590; HTTqtZJbEVbImZ > 0; HTTqtZJbEVbImZ--) {
        mvxxJ = TTSCZsId;
        TTSCZsId = dDzMo;
        dDzMo *= TTSCZsId;
    }

    if (dDzMo == -544617358) {
        for (int uBJFzJMDLUX = 1242151632; uBJFzJMDLUX > 0; uBJFzJMDLUX--) {
            continue;
        }
    }

    return kTnMijxqMatTfDwv;
}

bool FynIyrCzG::bMIWSWwdC(int cHgPOCkWstGVc, bool igEQwSPKAzt, double jVQCIlIM, string VcCdUWEQ)
{
    string RoIYcCDhXfVVQHM = string("mRWfhkXXVwXqykJNVILYFOuoIOEUkomalGmdpfGSUOINbCSuFWHjvRYmXDxeyIOPWWxKeZXWNMZqQDrsOnfDSRtHxLFijqhTzqjoNRiBdVBDzLMqTHLSsDSQAswiDViJfFpV");
    bool JVnUhtdSuudXlPnI = true;
    bool LOOyMcZxkv = true;
    string tTbPMkWJ = string("XRQHsFjnMhMModNAoTqdsnlctlGdTENyFRqtxFY");
    bool culsy = false;
    double IudsA = -658441.7360035881;
    string CvqzN = string("feAeAMbUVRajkvTnvOzLbQjFxkHFjxxGCBPPShDCHZxDVRo");
    int jSlzdSUQjZAd = -1294472045;
    double ZLgMcoPuiX = -123815.62046126912;

    if (JVnUhtdSuudXlPnI == true) {
        for (int mhnXf = 839482686; mhnXf > 0; mhnXf--) {
            ZLgMcoPuiX -= ZLgMcoPuiX;
            igEQwSPKAzt = ! igEQwSPKAzt;
        }
    }

    for (int iPWcGFrWkxJsjCS = 939763601; iPWcGFrWkxJsjCS > 0; iPWcGFrWkxJsjCS--) {
        continue;
    }

    return culsy;
}

FynIyrCzG::FynIyrCzG()
{
    this->JtaTs(true, string("tzQUNCwIvaEAkFfUCJPdhWRTrCpghNXDFBNCpBpjuyrcuVvgRHMhGgrLBrwFVykWVDdbBeynlhrAQpWIyDNiyfNiixvlleLSMJIUFUtFqGlGOWxhizDYrJavqSGvzXhRjGbhhStzHaxuAbICxalvQipdmaGgQzlAvoTYGnXrvDtKatMqkZjEnCIqawv"), string("bSdvyldaaNGYisiCqf"));
    this->rsxPFDsFRPgmDK(935154.622375031, -1203491340, string("KDnyWdIMjXSqImloGXXlVzYGOOelZZKwRUlvnDcSGEgVSvNBezbddmYDYZIqhxYcYConliYXjJsxqZLebQFHoaXCOvhFUIFnbYvuKixrdscLKPajvkUfFVPoGLrRqwjwPAoBpGnnkWNsYuZVeAHwYmVLcydsRonzZXNpjqZwbmNeuCBKtiLCKwwfWtvcDBgQvIYBbpmehbtiSoJXKPZJlqUjTXJfUGHPdXBszJAHTxUwerjZsUAVCwqgWmPe"), false, false);
    this->XTHhlS();
    this->AUdHzAdkVjGtr();
    this->jBmQJpLIqtVZBRL(string("vsicASLkOuGvQKcZyvdeLdmknDOMFylptcmjVlkPoZuxpaBFnBhMcTjIipWolzSpcloeynIbWjYQisvrAsOQskgkasPZDsyxQkkdSyvVBJdNRyvDfQVXxdPabkTsUNuklhUCIpoqHgEMhIGZyEBxJauakKrXgzAiYPNVGgZphTvhfEBcCvBafFnyrLLUKNkoXkXjQOQwuyxpufbgsMBiJeIkLDHtLoUOcMPLxfKCcopNeJtTuq"));
    this->sMWyGAkZ(false, -262799.57568090945);
    this->hRknuyjbM(263593338, -544617358, true);
    this->bMIWSWwdC(-317557419, true, 196449.36848104384, string("jXQHUNyRrDMaNXfSUlWkQtUQwrIYCShBIWGIBoHnUB"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class fRMEbvA
{
public:
    string KEeMi;
    double eQqjIEUe;
    bool DHVcuOzAmq;
    string aRSzN;

    fRMEbvA();
    int kjndnSfJeAzbyxB(bool dfShnExpKgzrXv, int ZjfyfbjpK, int jqWPSqFh, bool ClTmEDzSxxawbe);
    bool JRQoQlaULkR();
    void JGcHqu(string PWnukoHcVlPrhG, int icZUpqUSKI, double BVGDonDI, bool PxxmisfFeIiILD);
    double NtUou(double eYpWcxoAsXcEjhxy, string MdiJRSmYaj, bool RItKWaVChb);
    int DMQNsIpr(int wEMOeYGIR);
    string SEYJK(double luRZrDKMDsWCRlpe, string PSyrJH, bool mvPSFy, bool iQBAmXDfHlvXhmI);
    string vQCwPtG(bool ifTCnWYNOpHzNd, double JiyuY);
    double wpZcjzHCeb(int xZjHmfkeDixu);
protected:
    string xxCjuLMAWceUVBeC;
    double hjDaOErooyJGnDKE;

    int SDrpyXU(int xAtTrX, string WbjhPCtSaQRrxyvP);
    string TJYrLFNk();
private:
    double kEbVrS;
    string tiftyEMuNqRBWwwu;
    bool Pdkoj;

    void wRPgDYhddqudzp(int WuEBkjpiXArgt, int diOohZOcQ, int KkBBzLHerTV);
    void ughLZAhRTjefaMH(int ygVQhamYRuZNbm, bool txpHyhdtLea, double wOrdJI);
    double FNFvGcikVdRUbnAv(string XqNahJEI, bool iJgrFfvME, int CNKekotO, double MTKPNcNjxCZQK);
    string GwYtueExZjw(double qMcSEb, int vgYyPyeocGjX, double wKEDTnenpHhDM);
};

int fRMEbvA::kjndnSfJeAzbyxB(bool dfShnExpKgzrXv, int ZjfyfbjpK, int jqWPSqFh, bool ClTmEDzSxxawbe)
{
    double TxwnilKMSLegeMJH = 133381.13706240544;
    int Ffjxk = -32902190;
    bool zASvOcV = true;
    string hNFGZmD = string("DVVVQXyJEFbatlvtDEtAPmhBvmIcCWWYVlIAkeTZhKtgniYPLywSFjntnHTwTlPYNTN");
    int omkNyWLpegzZYS = 1307464903;

    if (jqWPSqFh < 1307464903) {
        for (int BhpVh = 152083252; BhpVh > 0; BhpVh--) {
            ClTmEDzSxxawbe = dfShnExpKgzrXv;
            ZjfyfbjpK = jqWPSqFh;
            ZjfyfbjpK -= Ffjxk;
        }
    }

    return omkNyWLpegzZYS;
}

bool fRMEbvA::JRQoQlaULkR()
{
    int ZzHimsejK = -1023260044;
    bool QSEKvIVxlzVlcu = true;
    bool bRgCGBCBfH = false;
    bool vgwHOSBlKWDmC = false;

    return vgwHOSBlKWDmC;
}

void fRMEbvA::JGcHqu(string PWnukoHcVlPrhG, int icZUpqUSKI, double BVGDonDI, bool PxxmisfFeIiILD)
{
    double HVqHHVY = -375011.85508933984;
    bool JycEoVMiCVZ = false;
    string IwoNPtiCSu = string("VITxteVXrCoBWWcAHcBWaIfdbmBOKvGWCxhAXPVIztpqeiGbFdbiJVcNQCojEwxkZAHZksqpevniRSzEpAjZnmvrEaqEqKdfCRHhzUNwJdoJWoINssjssNycwZqYQkhnFTZRuSUnyzQ");
    bool PjggOKXdG = false;
    bool zqADUHms = false;
    bool WdSXGeWCGVwwL = false;
    int utffhoxCIlv = 1312400177;
    double UfZaIIejNQFWl = 496205.2739424858;
    string GquKosgZbz = string("pAGHCHWeAcytiBNRThCFVrdAzxuSplchznRHFQmUHRDoUVVJfvbIekALBpSLMIwJXHszYbeoghDgWEjTkbvFLAtfPUmUyaTrDBogWDWzcLWonAPLWrFoBhAEkyhUEDRQonkOOuIHlvBwFXUOdFmwxEJFwYGLYeujoHKzLwTBxhMyGtIqESVivkMOKym");

    for (int ECDtHWG = 1680504704; ECDtHWG > 0; ECDtHWG--) {
        WdSXGeWCGVwwL = zqADUHms;
    }

    for (int ujlJKNmdmssMERao = 219627919; ujlJKNmdmssMERao > 0; ujlJKNmdmssMERao--) {
        UfZaIIejNQFWl -= UfZaIIejNQFWl;
        zqADUHms = PxxmisfFeIiILD;
        JycEoVMiCVZ = WdSXGeWCGVwwL;
    }
}

double fRMEbvA::NtUou(double eYpWcxoAsXcEjhxy, string MdiJRSmYaj, bool RItKWaVChb)
{
    int pBbKioPUddPAa = 813451261;
    string VPWFcBav = string("pEDqXCcwekjmjMslZllOiLzKjUqipFaVwopXIhfSTkrtFnxwdTxSSqYeasQZwnapyBuBjxRiFIQPEztnlFbSoEhoXmeZrAIbhRradmHEUiZizHPmXDsyDgzqtVIRhmNUbUiaoMrgGWxIjoX");
    int ETEegRYJyTzXVunv = -406452535;
    double LaZRfcKqamnMMweR = 772333.8444152594;

    for (int sLNhbrrBMsmBGVh = 1314607202; sLNhbrrBMsmBGVh > 0; sLNhbrrBMsmBGVh--) {
        LaZRfcKqamnMMweR -= eYpWcxoAsXcEjhxy;
    }

    return LaZRfcKqamnMMweR;
}

int fRMEbvA::DMQNsIpr(int wEMOeYGIR)
{
    string wVwwctPN = string("pvkdUNqTbYHCHbkVwoMolJeGENrUoCuXUrQjzMMPjpYMMhKIkNWWJhyrphyalkKzuXefoxqIkZRuXuyCvyQRzwFrKKaSngOKWQXKwvkqBvblYgEJhbfUcvUDlfbmncIyHWpPjBcXHyuAqUwGUMVsbbuyonqEcLzdShnvKKgyHNZfjMKYgdlKjLGpFxHyYCuBSuaXssfpfvjMpBFUDjHhIjJfVzqHMGkmNPHBQOgkyZXvmHKIbuVimxZIt");
    double hGQUnIrSu = 405266.51978681807;
    string YgKkcxepyhgBVusq = string("gMTPHgmtbYNUWsVnJiJFDbvTUVRWuUKPgjGOZounrjGsPYsqRRmErgUSKZGbAtEPOErdFIxjLSIbSMdgOjWKfaBBQtPUSgznKcUSluuqpGbJDWCrkdveuLRVVl");
    string aIaNs = string("mbTexgTybVlrocUCcljWnMZnbVMixmxOTRyxkBPpdpZEmcPINFpHLBSrHErjaLyGhLOuCwrZoMBrlxpDUCUPWUOsXwTMCMSVkzzhdv");
    bool byBZsUuEqnmzdYS = false;
    bool zooexa = true;
    bool GsaYdn = true;
    string nPoLMaqWmfCO = string("XYuqGvOJSLWzuxHVHHAlrNuEMEAQblZioE");
    double BlkNsKtxfOmdlWJO = -744468.902148693;
    bool wTTORsnUR = true;

    for (int FHLMF = 261643250; FHLMF > 0; FHLMF--) {
        aIaNs = wVwwctPN;
        wVwwctPN += nPoLMaqWmfCO;
        wVwwctPN += aIaNs;
        YgKkcxepyhgBVusq += YgKkcxepyhgBVusq;
    }

    for (int tkwpFM = 1783321565; tkwpFM > 0; tkwpFM--) {
        aIaNs = YgKkcxepyhgBVusq;
    }

    for (int MhqiiQ = 1851258965; MhqiiQ > 0; MhqiiQ--) {
        continue;
    }

    for (int NdkhTCzICxHbYxSC = 485208030; NdkhTCzICxHbYxSC > 0; NdkhTCzICxHbYxSC--) {
        wVwwctPN = aIaNs;
    }

    return wEMOeYGIR;
}

string fRMEbvA::SEYJK(double luRZrDKMDsWCRlpe, string PSyrJH, bool mvPSFy, bool iQBAmXDfHlvXhmI)
{
    string ZybtomFMKhNyS = string("XqYNyZYtJFtzspmQXsuiWdE");
    double kKuTY = 769503.7018721092;
    int IeHzzOjIxH = -1485264250;
    double uliqxdxlocwKkMap = 87629.14380671715;
    string KIofVHINLTOD = string("tFGBIMvUYEOMGlheqvokboCTOeuA");
    double tKggiUYjiiWqc = 546625.1581783565;

    for (int PuUxYEVdtsMm = 1220054133; PuUxYEVdtsMm > 0; PuUxYEVdtsMm--) {
        mvPSFy = mvPSFy;
        kKuTY += luRZrDKMDsWCRlpe;
    }

    for (int pTzOEpX = 1398762728; pTzOEpX > 0; pTzOEpX--) {
        kKuTY *= uliqxdxlocwKkMap;
        uliqxdxlocwKkMap /= uliqxdxlocwKkMap;
        kKuTY *= uliqxdxlocwKkMap;
    }

    return KIofVHINLTOD;
}

string fRMEbvA::vQCwPtG(bool ifTCnWYNOpHzNd, double JiyuY)
{
    bool onwVsBj = true;
    double jwAlVAQwbEZKmEe = 138127.75639491243;
    int cafYXh = -546432250;
    bool OUUpcGBeZ = false;
    int fXWgk = -1810946837;
    double oxgprFa = -208922.29776116152;
    string zeFBM = string("GVWFQjU");
    double nYxMl = 1004567.8887716094;
    bool FIQtXnbaQ = true;

    if (JiyuY > -208922.29776116152) {
        for (int ijddOVuWb = 1268720256; ijddOVuWb > 0; ijddOVuWb--) {
            oxgprFa *= oxgprFa;
            nYxMl += jwAlVAQwbEZKmEe;
        }
    }

    if (FIQtXnbaQ == true) {
        for (int TJBbHtBM = 1205001018; TJBbHtBM > 0; TJBbHtBM--) {
            OUUpcGBeZ = ! OUUpcGBeZ;
        }
    }

    return zeFBM;
}

double fRMEbvA::wpZcjzHCeb(int xZjHmfkeDixu)
{
    bool TnfEFOyygKCTzy = true;
    int pIide = -706797628;
    double LnduFaaT = 392236.6260687978;
    double lVwft = -688040.1879813154;
    string gANbr = string("swPiElkVyfbFkkefptdrRIfnHwhgtvLWSSDcGEAgdheiDWXRSiDoIcMbFSORCOFFwexQhKccJvVctDYatwccImwceGMKaPFKqUrMpWruYVJoUSPnJIIMCMgtSjxlSWmjDIVpwyzqfNWIcdTTLTPdBJimCxnsx");
    string TamnMnh = string("awmCCGFNpPWocnFdQZvdxAtPHOZnHCmHGsycDEFJleamSqPEPFSSIgesrVmDOSkUfDfOxvkMjNDtehPXuFtUKbxFwDGhWDCKeJVfHNAivGCelqlrvhvzqqkNxaAGQRoenXVtUkMCmeHHkPMkqQDKOfIJInGGIgWsGwFobEkMEMuodCfbdgvdmwwipYMwHKuUsmIhCZwazSQxDaAqdVCXDDvjVrAHRaZTis");
    int SiumbsouZRCWSz = -691389868;
    string oMSqOxXjReNayA = string("HSesshccozuFNbMCCozoguZUoWLFXCXsaknl");

    for (int WECfXJHUbidS = 218334418; WECfXJHUbidS > 0; WECfXJHUbidS--) {
        TamnMnh = oMSqOxXjReNayA;
        gANbr = TamnMnh;
        TamnMnh = TamnMnh;
    }

    if (pIide != -691389868) {
        for (int bCvulZOtoMk = 464935171; bCvulZOtoMk > 0; bCvulZOtoMk--) {
            continue;
        }
    }

    if (gANbr <= string("awmCCGFNpPWocnFdQZvdxAtPHOZnHCmHGsycDEFJleamSqPEPFSSIgesrVmDOSkUfDfOxvkMjNDtehPXuFtUKbxFwDGhWDCKeJVfHNAivGCelqlrvhvzqqkNxaAGQRoenXVtUkMCmeHHkPMkqQDKOfIJInGGIgWsGwFobEkMEMuodCfbdgvdmwwipYMwHKuUsmIhCZwazSQxDaAqdVCXDDvjVrAHRaZTis")) {
        for (int OgmfayXkcirX = 1352397617; OgmfayXkcirX > 0; OgmfayXkcirX--) {
            lVwft /= LnduFaaT;
            oMSqOxXjReNayA += oMSqOxXjReNayA;
        }
    }

    for (int GjZDVRSXTLy = 1626347866; GjZDVRSXTLy > 0; GjZDVRSXTLy--) {
        lVwft -= lVwft;
    }

    return lVwft;
}

int fRMEbvA::SDrpyXU(int xAtTrX, string WbjhPCtSaQRrxyvP)
{
    double ZtflGayy = 311513.3813725718;
    int BLgDyhHOxNsAGox = 1562902086;
    double znrbviUu = -175138.66245951373;
    int fNYtcL = -1634699380;
    double NHUjLFZlgQXx = 849937.8512951328;

    if (BLgDyhHOxNsAGox != -1634699380) {
        for (int EZkANAwrVQWAUzyN = 727778239; EZkANAwrVQWAUzyN > 0; EZkANAwrVQWAUzyN--) {
            ZtflGayy = znrbviUu;
        }
    }

    if (NHUjLFZlgQXx == 849937.8512951328) {
        for (int GRVNFOl = 278785961; GRVNFOl > 0; GRVNFOl--) {
            znrbviUu += znrbviUu;
        }
    }

    if (xAtTrX == 406277306) {
        for (int eImXlDxDUjjGIFkM = 2050887089; eImXlDxDUjjGIFkM > 0; eImXlDxDUjjGIFkM--) {
            BLgDyhHOxNsAGox -= fNYtcL;
        }
    }

    for (int hJNTsSmnschPg = 1238761589; hJNTsSmnschPg > 0; hJNTsSmnschPg--) {
        WbjhPCtSaQRrxyvP = WbjhPCtSaQRrxyvP;
        NHUjLFZlgQXx /= znrbviUu;
        fNYtcL -= fNYtcL;
    }

    for (int WehtUjBSgIfJnPW = 1552292109; WehtUjBSgIfJnPW > 0; WehtUjBSgIfJnPW--) {
        BLgDyhHOxNsAGox += BLgDyhHOxNsAGox;
        ZtflGayy /= znrbviUu;
        NHUjLFZlgQXx = znrbviUu;
    }

    return fNYtcL;
}

string fRMEbvA::TJYrLFNk()
{
    bool zZNTfQ = true;
    double HRcmaMMUwKJOnItl = -700359.3323508403;
    int suyKYBO = 1598846477;
    string fpaeIUCsmZZXjB = string("EWShvdrQOxrBFxJTgOxOjAsvREBsihvfLjXQQnAuOPmEJFOAPNfKozOuvjMnPZBPrRkLsUSLdmbTbBdoDuGVOxzDatzLFvjYitekuZJNYCkglVcXwIvQjvHr");
    string pLXMdsygAI = string("UBOqYBdHzpTowtxexqfKUleYKLCPxKJGwXyGyMpXJVUhSWZbJUSHEqQEhSNtwoUHtxBeHeQwmBeyvBvvmNAnCmgqTVrQPBzIMCiWbchz");

    if (HRcmaMMUwKJOnItl <= -700359.3323508403) {
        for (int UIFiGfBVxfjh = 220178307; UIFiGfBVxfjh > 0; UIFiGfBVxfjh--) {
            pLXMdsygAI += pLXMdsygAI;
            pLXMdsygAI = fpaeIUCsmZZXjB;
        }
    }

    if (pLXMdsygAI != string("UBOqYBdHzpTowtxexqfKUleYKLCPxKJGwXyGyMpXJVUhSWZbJUSHEqQEhSNtwoUHtxBeHeQwmBeyvBvvmNAnCmgqTVrQPBzIMCiWbchz")) {
        for (int ImVCRZ = 612706462; ImVCRZ > 0; ImVCRZ--) {
            pLXMdsygAI += fpaeIUCsmZZXjB;
            zZNTfQ = zZNTfQ;
            pLXMdsygAI += fpaeIUCsmZZXjB;
        }
    }

    for (int uFJrQKgmWByHN = 1707333546; uFJrQKgmWByHN > 0; uFJrQKgmWByHN--) {
        fpaeIUCsmZZXjB += pLXMdsygAI;
    }

    for (int WiFsbrXImmDquTWd = 336599471; WiFsbrXImmDquTWd > 0; WiFsbrXImmDquTWd--) {
        zZNTfQ = ! zZNTfQ;
    }

    if (zZNTfQ != true) {
        for (int nUOsPYhusNWQ = 480897661; nUOsPYhusNWQ > 0; nUOsPYhusNWQ--) {
            continue;
        }
    }

    for (int hJdMCXVXgR = 863937215; hJdMCXVXgR > 0; hJdMCXVXgR--) {
        zZNTfQ = zZNTfQ;
        pLXMdsygAI = fpaeIUCsmZZXjB;
    }

    return pLXMdsygAI;
}

void fRMEbvA::wRPgDYhddqudzp(int WuEBkjpiXArgt, int diOohZOcQ, int KkBBzLHerTV)
{
    string wbkJBuwbGSqkMR = string("mkuzpZptsYKuahxvPgMTKGPSgyUqrNhVmSdvltmMzaTfMqWAniFWIHyfwQ");
    int ZAHnqpbNLLyMZy = -1044050399;
    double TKDZarTvzfzzDf = 588379.6647190717;
    int TFNHzBKFCOaxMQr = -108408015;
    double nvQPNMVZO = 848835.9038848855;
    bool SLBqRvrmpPFhYjtJ = true;
    bool OfaUZFXFTzOjyZxw = true;
    string WaHlrlTm = string("PtmdnGXUjbNYhgTxPfeAIBegLESxoLChwYEQytnOeWlbrRPAkxiPLDOmISEtXCdUhbvkXCzlSRFgdzjkPXuVBEqPlWautIKbTbngSyHgCAyxEQAqGJZPJSRSjxEdEGaXUtTAmKEBHqHcnprpeLjFuWqARtBiNTPpLz");

    if (KkBBzLHerTV >= -1988947264) {
        for (int OxezjlVadwdUUo = 1763671794; OxezjlVadwdUUo > 0; OxezjlVadwdUUo--) {
            wbkJBuwbGSqkMR += WaHlrlTm;
        }
    }

    for (int OIhqI = 22755673; OIhqI > 0; OIhqI--) {
        continue;
    }
}

void fRMEbvA::ughLZAhRTjefaMH(int ygVQhamYRuZNbm, bool txpHyhdtLea, double wOrdJI)
{
    double ZEwSbkQrCUK = -662340.0459870389;
    bool wrCozMraGyDBLZWB = true;
    bool ascesu = true;
    int SeSJz = -349006212;
    double qASoNEZnjnSKpM = 782157.7065335327;
    double XyWlAm = -234776.32794509566;
    string FIgBRGPyqoV = string("lAkxOsrFOTQAPjuzZFzmOxPfBTlYHYnawDPqOTrdlWmqbEULPrnqxgazYIjBpIlyALCyeORQPHRwhxhKjrGEYGQXUWkBwaJbBfRbAotbLCCEfKJzLpycekpaoVkupioyzCIlkevbFwaQHJExoPuJufOouPOpWcjKLxgyOOjNosgGKXcjEzlCRmYrmKyyHRGoOwOLMnFrrGFvWeoYqNGoQaydCBMCzCuFFTGbLaLGmGmcy");
    bool EeOkl = false;

    for (int opEcVHkqCJZBksE = 1815976360; opEcVHkqCJZBksE > 0; opEcVHkqCJZBksE--) {
        SeSJz -= SeSJz;
        wrCozMraGyDBLZWB = wrCozMraGyDBLZWB;
    }

    if (XyWlAm >= 782157.7065335327) {
        for (int HqTWyfi = 83650330; HqTWyfi > 0; HqTWyfi--) {
            continue;
        }
    }
}

double fRMEbvA::FNFvGcikVdRUbnAv(string XqNahJEI, bool iJgrFfvME, int CNKekotO, double MTKPNcNjxCZQK)
{
    string fbjCMZGPvlcyAG = string("jQJNIIYXodAeVCYgihJPYcUkcaMqTSGWBtdwrbpzZZDZEPGhSJDrOxQKcZWEGBojXybhuMfvScpgfFpcKgVOwSKUOHOxiUFBNTVfFriADhuzKdKlBocVDkgZCrxtmlIZLImucbbuVirKJdkFkOmjSpMSYcznPHvXbdOXpCreclskAibdvLyshYNFCfDKtWDTMnlYYPefMimTvBhLxJgFDXCVIAzPFHylhIZcYZvWQdEPabAWYLXpBbitAdxq");
    double PgsTxhkTVUo = 613869.9065160532;

    for (int gMCscfQUNuOe = 1927557373; gMCscfQUNuOe > 0; gMCscfQUNuOe--) {
        PgsTxhkTVUo /= PgsTxhkTVUo;
        fbjCMZGPvlcyAG += fbjCMZGPvlcyAG;
        XqNahJEI = XqNahJEI;
    }

    for (int ctuVFIspt = 165383204; ctuVFIspt > 0; ctuVFIspt--) {
        PgsTxhkTVUo -= MTKPNcNjxCZQK;
    }

    for (int FynKGmVawCH = 1498882349; FynKGmVawCH > 0; FynKGmVawCH--) {
        continue;
    }

    for (int MNsjwpUHQWmujkb = 626124667; MNsjwpUHQWmujkb > 0; MNsjwpUHQWmujkb--) {
        CNKekotO *= CNKekotO;
        XqNahJEI += fbjCMZGPvlcyAG;
        PgsTxhkTVUo = PgsTxhkTVUo;
    }

    return PgsTxhkTVUo;
}

string fRMEbvA::GwYtueExZjw(double qMcSEb, int vgYyPyeocGjX, double wKEDTnenpHhDM)
{
    int dvSzTxaqITqztXY = 1448302995;
    string WzUelTMBmZMhh = string("GQydXZkuURIcoLdvOOAlLlXKOHetCPFQoWAnizuXezxPPWVFdhdmqnactDlehvvYzudzWgcVSFZAByPoNHtNjHsPZuLTasfhktAGPrNoTHsopvKQaGxlkJLCqbGfMSjEQjqCrPIjPmdAEmHEimInqiooAPqZQQZHitXsqYvMbVSGntOmAihNFZBJyOwOifbhcMgsgOXnqS");
    int XuNQyUbNesuDTeqh = 1225446428;
    int tSsfxKRltO = -2127775991;
    bool aEgPNFS = false;
    double oxkNiOVm = -1004420.2884026258;
    bool jRttrHbNyVkjEQZ = true;
    double pvMIwFoNti = -331745.65770986176;

    for (int KefihAOg = 1637845698; KefihAOg > 0; KefihAOg--) {
        dvSzTxaqITqztXY -= vgYyPyeocGjX;
        dvSzTxaqITqztXY += tSsfxKRltO;
    }

    return WzUelTMBmZMhh;
}

fRMEbvA::fRMEbvA()
{
    this->kjndnSfJeAzbyxB(true, -698251823, 705098560, false);
    this->JRQoQlaULkR();
    this->JGcHqu(string("JGGcZORZXrQtodQCKsuwtpYUKvdtGJorexSJvAHZrQCUjcjAkVNJHUa"), 274065266, 587278.6980283669, true);
    this->NtUou(1017875.5322241844, string("mXwiTOTUZYjxlUulgewZBOMUMeLWryjTiXhGilPqiREAQIJNKLQdxPXlqQXkyRccaLQEejEYRFGepbyXjuFFlbDhTsWJGktVqhJTnJtOUHgzUtFyS"), true);
    this->DMQNsIpr(1335198428);
    this->SEYJK(-485411.0649402767, string("wFIxhphVezNoKCGOUCJYfGnSSKSKZeTdIFQvbjfRAfxLjJlGpOriDnrlkcwBVAOuDHbPRxLkWTIWOZaqYDRYhcEvQLGxvonzgqnBplpTaTmFGuOZXjbJhZxvSHOvSSXNQVZAgzhMJdbHHcQPfzaXjviuyGWOgZOPjOKHQOyDwukaCOdzVAUpKsaJXEgEBECqIxxMXYFZppFKzHmGxoQsoXuWUvdtaa"), true, false);
    this->vQCwPtG(false, -69960.00547454404);
    this->wpZcjzHCeb(-1675032949);
    this->SDrpyXU(406277306, string("jubrgQZRDEAWkKsfwZvuiYbceMIBSkMPxBzgEZvSWkSkALBKWPoAvhRYeTdsFqwQKimAdYWojRNfrXKavAkLzvDAKeRKVmCxRoxIptzvqsviQqKKMCe"));
    this->TJYrLFNk();
    this->wRPgDYhddqudzp(572872250, -1988947264, 492389375);
    this->ughLZAhRTjefaMH(-1120880895, false, 1018139.2020464656);
    this->FNFvGcikVdRUbnAv(string("oVwzZjUmvwzHkokGNEQAjyuWmPkcrtbyVkGRrmczzNyhrAPwAcIDZSjQGAJUkdeOcJnGECGgHJTdbCKhDtXJSMYJehnAZlYsxQDEQhlHuKDZNgjGKVjoyTpCCTrSGXZtYh"), false, 1474919169, 131636.67119630956);
    this->GwYtueExZjw(133997.82959065362, 927617344, 105988.68824302201);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class InVnaQi
{
public:
    string ntHkD;
    string gAQpF;
    bool JQrhIvnBLTmGeOnF;
    double YCaoap;
    double knRGuYpLGghFo;
    double OqiLgg;

    InVnaQi();
    void uHNSfEcCErLTpDpd(double XKJWTM, int CAdDtMSyEfMeZlsG, string wlJHMSlUKq, bool SfdXszRlA);
    bool xRlbNOhxIExeehe(int MQtTbzLdtJvxgtv);
    void gwNqozaG(int UlxyNrilFLstZ, int EPbrxZKYFD, string GGbcTHrlcFPe);
protected:
    int cdqiUCUEDP;
    int KuvaresVRcjkCXf;

    string htbZHatCbcifTXJ(int SQWxiiVskIn, bool xTisUkuwKsInEr, bool CTxffdmP, int ejqaMCKmazzvrTA);
    string HKBEqzQFoMc(double waZyuYEnSokWyGau);
    int kHqKCStuOxbyZr(int VOqHJ, bool zwUDZlKKpM, double ugOqXxsRTYztH, double owoRXAIQGCqrz);
private:
    bool hHbknzZVzxEp;
    string hELvB;
    double EJFpuhE;

    double zfBnPfF();
    int UiBFCaTWwXejBDI(double jnIRJVwlPU);
    string EzZfZm(string sCPYLazobZHUC, int ITBQTnEydFlFof, string SquYQVdDTTF, string AzFKLGHryPIza);
    int byQGNnPJ(int rrUYgFlcAm, bool YYFypWr);
};

void InVnaQi::uHNSfEcCErLTpDpd(double XKJWTM, int CAdDtMSyEfMeZlsG, string wlJHMSlUKq, bool SfdXszRlA)
{
    string MuJMaaAsAL = string("sCtrNfFERypnaYSfhRJtQVlYLXKIbPpjserzuuPALdWSDcRjecpZFrbTsmOZesQumRisqUiLkdyxQUzujJAzgqtYjuQZAJNVBdXFznFEJfjFMszkVhwVsktSAyJqXeCKQnQjqbmnQhQqprksGhpYAvwbIilEpkXcYDGQWKMNlumnFIDnJqtawhyW");
    int UnwcdvaPnNfBrRtF = -260868090;

    if (wlJHMSlUKq == string("LqYlPUHwepXokHrZsswWdXCvkhgUNTfRWEndIbZzVhZghbtTAqMBaeEEhrPGmQMemndZRIJyobPrPXeLFBJgKsMbLtYzQvfwswPPaAFfxzNkEHObuSZRbetwwRNuhzqkIRfdnpGidwXFOhdDqDaeQwXFHLiSaAVeHfPeGzhFojZmYesWWAOKwxbuOUVDVunwqsTkCFrzKvCHCd")) {
        for (int HnyXe = 327123610; HnyXe > 0; HnyXe--) {
            continue;
        }
    }

    for (int iJqYwjdLxhfcE = 1991587456; iJqYwjdLxhfcE > 0; iJqYwjdLxhfcE--) {
        continue;
    }

    if (MuJMaaAsAL > string("LqYlPUHwepXokHrZsswWdXCvkhgUNTfRWEndIbZzVhZghbtTAqMBaeEEhrPGmQMemndZRIJyobPrPXeLFBJgKsMbLtYzQvfwswPPaAFfxzNkEHObuSZRbetwwRNuhzqkIRfdnpGidwXFOhdDqDaeQwXFHLiSaAVeHfPeGzhFojZmYesWWAOKwxbuOUVDVunwqsTkCFrzKvCHCd")) {
        for (int Jtvje = 2045054811; Jtvje > 0; Jtvje--) {
            UnwcdvaPnNfBrRtF += UnwcdvaPnNfBrRtF;
        }
    }

    for (int wGXgz = 621045931; wGXgz > 0; wGXgz--) {
        wlJHMSlUKq += MuJMaaAsAL;
    }
}

bool InVnaQi::xRlbNOhxIExeehe(int MQtTbzLdtJvxgtv)
{
    bool MCQaTe = true;
    bool sYNbDtJt = true;
    int jPwZWmEVbQEkCfC = 1146248874;
    bool LtfcZCqUINjzQM = false;
    string WvCZmUn = string("zeQyfzoTzCUMlLuoXvLSKAMfDqHytHVRhYwfDfSzsTBtaOmxkKZPpYSM");
    double PNfXfEYBBIUS = -83104.33195324127;
    int vEMauAqW = -180525546;
    string SiiXXYBtg = string("BAndEHsOHiWrzQMczEhycTOeMjtZJqBELiqpkUrixdiXFerHnwxqpSfUeTxnxXBdDMNWAGBeFVrvXKoNcF");

    for (int whlqaRD = 1505860367; whlqaRD > 0; whlqaRD--) {
        jPwZWmEVbQEkCfC = jPwZWmEVbQEkCfC;
    }

    return LtfcZCqUINjzQM;
}

void InVnaQi::gwNqozaG(int UlxyNrilFLstZ, int EPbrxZKYFD, string GGbcTHrlcFPe)
{
    int hEEHWcweUPPoOFB = 517451577;
    bool xguGMwdJrvtl = false;
    double sTPMJlVR = -1027027.069246631;
    double kAPfZAgGYs = 171627.386957451;
    string AfDNSLvujjwQXKc = string("xuovwUoJQgSoyCaiLHVkkEFUyqXJQaFEkXxJnUVJdKuSQFMLwTUnZiIdGPvla");
    double DAazbMqWKqWhUkr = -76101.70263427285;
    double mkWsSQQAANfSEu = -864104.8627380448;
    bool ueGwllZdUfkBuSX = true;

    for (int ayRlOfek = 1648371189; ayRlOfek > 0; ayRlOfek--) {
        AfDNSLvujjwQXKc = GGbcTHrlcFPe;
    }

    for (int AABpHNH = 951242581; AABpHNH > 0; AABpHNH--) {
        hEEHWcweUPPoOFB *= EPbrxZKYFD;
    }

    for (int kaCVbmSSlowaIjz = 888829728; kaCVbmSSlowaIjz > 0; kaCVbmSSlowaIjz--) {
        kAPfZAgGYs = sTPMJlVR;
    }
}

string InVnaQi::htbZHatCbcifTXJ(int SQWxiiVskIn, bool xTisUkuwKsInEr, bool CTxffdmP, int ejqaMCKmazzvrTA)
{
    double MvaqdUlWslgVln = -628924.5888324095;
    bool CYHIjIypH = true;
    bool wAAjMnbS = false;
    int qHwUKVDqtNlY = 273453512;
    double dSZvmvjrbju = 259698.93480938222;
    double CofnH = 681114.6171148188;
    bool HFMmiBsObklNt = false;
    string JgFlUzoOvFnDNylN = string("VgsOjPvgvpndxlRUCwUEFBMuPIZBlOZPYGLWngiOVoAnwGFIerscdWiVCkTLFpbvbcutmQhlSOcODXISCqBNtvYotTBAtuPSnXUcFS");
    double XiBHKydwMFmFvH = 895510.1820219689;

    if (XiBHKydwMFmFvH <= -628924.5888324095) {
        for (int VRbAvpqEoDo = 777059380; VRbAvpqEoDo > 0; VRbAvpqEoDo--) {
            CofnH *= dSZvmvjrbju;
            qHwUKVDqtNlY = qHwUKVDqtNlY;
            XiBHKydwMFmFvH *= CofnH;
        }
    }

    for (int SgyrTTKo = 887002662; SgyrTTKo > 0; SgyrTTKo--) {
        continue;
    }

    return JgFlUzoOvFnDNylN;
}

string InVnaQi::HKBEqzQFoMc(double waZyuYEnSokWyGau)
{
    double BdoMwXA = 611986.2862168648;
    int kvrXstFpqz = -904331735;
    bool yYXzEVEgDKaIIEP = false;
    int pggWaOsMikmR = 375511803;
    double FHzQMq = -664657.3628115333;
    int ksGWWZeUAyGJJIsT = 248205872;
    bool LveKcquyrwQrhT = true;
    bool ElntytM = true;

    for (int bPBlFWZZypBIoE = 1971516985; bPBlFWZZypBIoE > 0; bPBlFWZZypBIoE--) {
        ElntytM = ! ElntytM;
        pggWaOsMikmR = ksGWWZeUAyGJJIsT;
        pggWaOsMikmR /= ksGWWZeUAyGJJIsT;
    }

    for (int UpZilh = 227855166; UpZilh > 0; UpZilh--) {
        BdoMwXA *= waZyuYEnSokWyGau;
        kvrXstFpqz = pggWaOsMikmR;
    }

    return string("yESRiRnDkDgOSsbdpzDWPgFPHkLOCpLoqaCsjgYqLOjKCBCFyoNuEMzCbGDNsNdLyBfgIgEZxntiTTxOLrHqiMrMJGgNc");
}

int InVnaQi::kHqKCStuOxbyZr(int VOqHJ, bool zwUDZlKKpM, double ugOqXxsRTYztH, double owoRXAIQGCqrz)
{
    string DYYkQYBULeKvc = string("drEocooDPlwOxdKJFuhZSTTNxxiSyhMCiPcKDkfWuESuGGchjrlQzCtIcivOZMmlQWvNqBQNrkHADtBdJtDdchEKbTgHtjdemUWoOxHOxQXDTfIeRwcgMOUHICgyiWTtFSlpxAzkKm");
    string ileMUcLbZeKEr = string("rsluDKyCbWxXtVElxriGcrKuUeUdRraSUsboVBqZrpOaaBCMQwneggOWMrZAFsFSykBhtFpFTbCOFwOqPYjeJNhvhjAQNbjZchXvYaHOrJPjcKlUoQSRJeLAxsQoeAWgHDlGDWytBBFdchTcEsvZcdYUCMuHrYODwWfRnMVCWxUngdtBrFTbcKISGhbWWlPKTNcngBOJnZehKvODAUJpGpBN");
    int PFnLTB = 458972525;
    string PkhlAjzjhcKgCI = string("neELVBjIEnjeCUQgYZdkpDOFRUGyIsAlyblGtVJFFwBEtQqaaYQsSPxDWpxcSJcRUNl");

    for (int hBwoYKaEcB = 494491679; hBwoYKaEcB > 0; hBwoYKaEcB--) {
        ugOqXxsRTYztH -= owoRXAIQGCqrz;
    }

    for (int yEjBqnRvDL = 248460320; yEjBqnRvDL > 0; yEjBqnRvDL--) {
        zwUDZlKKpM = ! zwUDZlKKpM;
        DYYkQYBULeKvc += PkhlAjzjhcKgCI;
        zwUDZlKKpM = zwUDZlKKpM;
    }

    if (VOqHJ >= -1480685284) {
        for (int buPBvEuRUdtsIzQw = 2105030757; buPBvEuRUdtsIzQw > 0; buPBvEuRUdtsIzQw--) {
            PFnLTB += VOqHJ;
        }
    }

    return PFnLTB;
}

double InVnaQi::zfBnPfF()
{
    bool czvoxlVUa = false;

    if (czvoxlVUa != false) {
        for (int sIFlvG = 604554900; sIFlvG > 0; sIFlvG--) {
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
        }
    }

    if (czvoxlVUa != false) {
        for (int iEeaWyWuTSbYnwin = 54888362; iEeaWyWuTSbYnwin > 0; iEeaWyWuTSbYnwin--) {
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
        }
    }

    if (czvoxlVUa == false) {
        for (int gqNpDAdG = 790649285; gqNpDAdG > 0; gqNpDAdG--) {
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
        }
    }

    if (czvoxlVUa != false) {
        for (int VMiyOZZtc = 866532731; VMiyOZZtc > 0; VMiyOZZtc--) {
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = ! czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
            czvoxlVUa = czvoxlVUa;
        }
    }

    return -721237.2627188468;
}

int InVnaQi::UiBFCaTWwXejBDI(double jnIRJVwlPU)
{
    bool GjwKGDsEp = false;
    string UMupxdVU = string("GKOtaKlSEZSdnYGacFJWkCRTwnGjWCwdZieHpMTyiuPymWtJCsudJHIraaeuBJGPGSyLqLcuvEnBzCuvrqjQqwAHJJmBcTaetKYbnXJQUiJSWGzhqMVdERzibZKPwRQtMzXG");
    bool SDLWtZCQDBAPcNrD = false;
    double MnYVBzmqAaM = 357101.06299888203;
    string qBSbXwdVC = string("NDlNgCCHcMQVFEJnEKmUGJSDSHFOChqDFqKIShOSlCzQDSYtQdWduzrlBndMHevLyVmBoTaFiVIAgwGSMMRpxdeTZeiXDteYTqrsuTkWvJfQCvoeZXCvhFMkYnQcsciVZkBrf");
    bool vxRWabiyv = false;

    if (UMupxdVU != string("GKOtaKlSEZSdnYGacFJWkCRTwnGjWCwdZieHpMTyiuPymWtJCsudJHIraaeuBJGPGSyLqLcuvEnBzCuvrqjQqwAHJJmBcTaetKYbnXJQUiJSWGzhqMVdERzibZKPwRQtMzXG")) {
        for (int CkVimKFict = 189319379; CkVimKFict > 0; CkVimKFict--) {
            vxRWabiyv = vxRWabiyv;
            qBSbXwdVC += qBSbXwdVC;
        }
    }

    for (int RdkGaYx = 1762747356; RdkGaYx > 0; RdkGaYx--) {
        SDLWtZCQDBAPcNrD = GjwKGDsEp;
        UMupxdVU += qBSbXwdVC;
    }

    for (int yZvfoblWCEho = 718532851; yZvfoblWCEho > 0; yZvfoblWCEho--) {
        SDLWtZCQDBAPcNrD = vxRWabiyv;
        jnIRJVwlPU *= jnIRJVwlPU;
        jnIRJVwlPU /= MnYVBzmqAaM;
    }

    for (int dHzAoYinH = 236449697; dHzAoYinH > 0; dHzAoYinH--) {
        MnYVBzmqAaM *= MnYVBzmqAaM;
        SDLWtZCQDBAPcNrD = SDLWtZCQDBAPcNrD;
        vxRWabiyv = GjwKGDsEp;
        vxRWabiyv = GjwKGDsEp;
    }

    return 111526006;
}

string InVnaQi::EzZfZm(string sCPYLazobZHUC, int ITBQTnEydFlFof, string SquYQVdDTTF, string AzFKLGHryPIza)
{
    int TlITC = 1722722869;
    int RsMwwM = 464459815;
    int lvGXcZv = -822472829;

    return AzFKLGHryPIza;
}

int InVnaQi::byQGNnPJ(int rrUYgFlcAm, bool YYFypWr)
{
    double sOUkVzwWyotlM = -87828.10572304623;
    int VcajzSIWBizXlQ = -448303522;
    bool aKTaghyrJ = true;
    int VOFWeD = -1873502641;
    double hRGcLvlphIAchs = 682263.603751901;
    int fhgbD = 1142478678;
    int hKEYNGlEZPEyl = 459093030;

    for (int rvYPJTQZYdyk = 854789739; rvYPJTQZYdyk > 0; rvYPJTQZYdyk--) {
        fhgbD = hKEYNGlEZPEyl;
        VOFWeD += VcajzSIWBizXlQ;
    }

    if (YYFypWr != true) {
        for (int FiZCVPpAfuB = 42534878; FiZCVPpAfuB > 0; FiZCVPpAfuB--) {
            rrUYgFlcAm /= VOFWeD;
            hRGcLvlphIAchs += hRGcLvlphIAchs;
            fhgbD *= hKEYNGlEZPEyl;
            hRGcLvlphIAchs /= hRGcLvlphIAchs;
            fhgbD += rrUYgFlcAm;
            VcajzSIWBizXlQ += rrUYgFlcAm;
        }
    }

    return hKEYNGlEZPEyl;
}

InVnaQi::InVnaQi()
{
    this->uHNSfEcCErLTpDpd(953499.9433012747, 1052015494, string("LqYlPUHwepXokHrZsswWdXCvkhgUNTfRWEndIbZzVhZghbtTAqMBaeEEhrPGmQMemndZRIJyobPrPXeLFBJgKsMbLtYzQvfwswPPaAFfxzNkEHObuSZRbetwwRNuhzqkIRfdnpGidwXFOhdDqDaeQwXFHLiSaAVeHfPeGzhFojZmYesWWAOKwxbuOUVDVunwqsTkCFrzKvCHCd"), true);
    this->xRlbNOhxIExeehe(1842542028);
    this->gwNqozaG(-1905768425, -674835723, string("xVqGvUxPSehALBLnaTMZIouZgcDjBgAZkNPQCFxiTzdZRdJnvGBWDrRyyMYDpJLeSbgCzbGjvIqrpLROhhkLzYxNEtfihbqCyTSEZNUjfsBTnQIRjaNGpJdlpLnKjWGTsYVvukzYluoenBwbIHjHEnSfWEsCTHhHiLEMRzqWJwrWCdlIycAlTPIyDWxGvEbYIcCScBjgMHIfGlnbnjWECYUHjzgwFvZ"));
    this->htbZHatCbcifTXJ(-1253866153, false, false, 289258621);
    this->HKBEqzQFoMc(-806411.2821415175);
    this->kHqKCStuOxbyZr(-1480685284, false, 176499.7170775564, -472590.38072456734);
    this->zfBnPfF();
    this->UiBFCaTWwXejBDI(448411.3319494141);
    this->EzZfZm(string("YlsClFZPztvmcnjqRkaMcGUVldcZpPscWSLEsoLIDVxcnTHfgBhSOjNDJIWCXVDObdhWoCzHWvZHFttgxbiKdbwFhsQJnhYVDrvrVfyUlghvxifPvptVMBzYkaTLhiwPIoRujDQQhAs"), -1847458316, string("dthApgkXnaqCFVXKnieZMWdHypJrfCgJQlnTSbOuVRLubygGCgyWlmLpyPvyJAElrXWcnDrsoTZKlilFYqEvnBDcEtofQPBWbBBaDlYnLYErxPFyEUTjvgSFoG"), string("UbUivNXbdSlzdbGzqdObRoOgPgiVCUAKHsJTSRwtjoYQWFibVAjeqIVWtrfgyzqayKCFJEdGpUXATrpOxHs"));
    this->byQGNnPJ(-710177636, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qXgKYLlx
{
public:
    bool moCBhUiSlDSEqJL;

    qXgKYLlx();
    void gpxUEfnMT();
    double ShQnaz(int WHTtkWrnoee, bool fxJVDXgLRDzeq);
    void RXDie(string VlUpnviVl, double OjJpZuRUOIVdq);
    string WPxPKiUpNLRu(double vznhdbTDuCCRDdfY, int tfLGmzDbw);
    int OyLPCVMEPuerc(int SElIbfKqWP, bool fbfyQJiwdgmTt, bool miMNytyWxhjeaFxA, bool jbKOlEsKxypyQkG, bool vavomS);
protected:
    double LrGSK;
    double dkbRUNTlPWSiXV;
    string AORBrNqYemnSmMc;
    int bMnEtKdkxvJeo;

    double uzaQHXjZfW(double MvGVFonkHAPBmhW, string BiipShvHLTFYwo, string EHxSuEou, string NyUjH, bool MBGhud);
    int IXmOGNmPSf(double xLDHQKjwnjvTnV, string XnQsCKqhpWY, int cqMjxxAX, bool UnXRD, double AZqbVSOMpnlsa);
    bool knIHeCPhWEYwYoil(double qfeLNB, bool oqpaokwOewT, int YUgvplWZsKhlOQK, int CiuMlNObFizyBk, double VoGTGg);
    string qSgzn(double hMFyVrIhY, bool qaPFOfWzbDafMNG, double IRUQhSQBhh, bool TRxDVHIZlwcP, int zMmrLYTuOrBKru);
    bool OuxInZqhz(int oibaLqERcjVOif, string HjvvjMT, int VijnwuvycEan, string NyTjtLcDwpXz, bool NtAtjemUrZmBd);
private:
    string gNCtPJutMuQYMA;
    double NousiErQGm;
    bool PtvnlAyROt;
    string MfznrPzoILmwidb;

    bool yKSfkLdOfCL(int LVaXYGE, int pKJosm);
};

void qXgKYLlx::gpxUEfnMT()
{
    double kXWBZhZfoY = -739045.5979095451;
    int Eynrjq = 629904489;
    bool RNIyuhVrdKWVHJR = true;
    int htSadHxKfPRD = -750205903;
    bool jIDgXdaPwNK = true;
    double PZOELURKF = -247735.12716999356;

    if (Eynrjq < -750205903) {
        for (int XvvjZRrcLlzRGS = 1615070417; XvvjZRrcLlzRGS > 0; XvvjZRrcLlzRGS--) {
            jIDgXdaPwNK = ! RNIyuhVrdKWVHJR;
        }
    }

    for (int ZDiiafd = 1036183857; ZDiiafd > 0; ZDiiafd--) {
        Eynrjq += htSadHxKfPRD;
    }

    for (int Blwchi = 171667562; Blwchi > 0; Blwchi--) {
        continue;
    }

    if (jIDgXdaPwNK == true) {
        for (int jsHEDkHACbVJdfd = 564739776; jsHEDkHACbVJdfd > 0; jsHEDkHACbVJdfd--) {
            RNIyuhVrdKWVHJR = jIDgXdaPwNK;
            Eynrjq /= htSadHxKfPRD;
            PZOELURKF = kXWBZhZfoY;
        }
    }

    if (PZOELURKF != -739045.5979095451) {
        for (int ncjJDbV = 1500231838; ncjJDbV > 0; ncjJDbV--) {
            continue;
        }
    }
}

double qXgKYLlx::ShQnaz(int WHTtkWrnoee, bool fxJVDXgLRDzeq)
{
    double GWOnIWZohnhOZR = 146558.2605000489;
    int LLspoTGpXvLFCGp = -1302067669;
    int tIOwFDXfURRIF = -890762089;
    bool OAemtqeXQF = false;

    for (int NtRFvgULnDnDbtTi = 1789652659; NtRFvgULnDnDbtTi > 0; NtRFvgULnDnDbtTi--) {
        GWOnIWZohnhOZR *= GWOnIWZohnhOZR;
        fxJVDXgLRDzeq = ! OAemtqeXQF;
        fxJVDXgLRDzeq = fxJVDXgLRDzeq;
    }

    return GWOnIWZohnhOZR;
}

void qXgKYLlx::RXDie(string VlUpnviVl, double OjJpZuRUOIVdq)
{
    bool JFSfKzLEbAsC = true;
    double TduqSDntZWLgZe = -797894.9690460861;
    int RzEWVCRoaa = 616297715;
    double oJkSMxhxsxiSxl = 777470.026278038;
    double RViPqx = -570144.8232107954;

    for (int AbtcEhgGUDg = 2093025818; AbtcEhgGUDg > 0; AbtcEhgGUDg--) {
        continue;
    }

    if (TduqSDntZWLgZe == -570144.8232107954) {
        for (int EKRtDLpXogqMFEFM = 126114041; EKRtDLpXogqMFEFM > 0; EKRtDLpXogqMFEFM--) {
            OjJpZuRUOIVdq /= oJkSMxhxsxiSxl;
            oJkSMxhxsxiSxl /= TduqSDntZWLgZe;
            OjJpZuRUOIVdq /= OjJpZuRUOIVdq;
        }
    }
}

string qXgKYLlx::WPxPKiUpNLRu(double vznhdbTDuCCRDdfY, int tfLGmzDbw)
{
    bool aQBlaVYv = true;
    double kaBeyKtSf = 914258.0760052387;
    int FWfootrHxgZ = -1127298725;
    int pRQzYWdYKI = -1939091542;
    string hJRDShtVvxenBWH = string("Kc");
    double BVDsyzYQ = 1032284.958814389;
    string oyngMEISQdIphd = string("LCWWxCHtrvZcTZeqzqayvBGKzHmpcIpquIdTxVPBbfGfISljncbPuBpPSsxitssMirJCZOFZBiFQWrcCVruCRDgcpMgDvExXGaCxgEogQbGzNTQqPuiObKilxzSjyvjwjNMuchzmjsYorgxRUrdAvbCEnWbmEInwdfsjXEKMcEIhHcaZylmrZlHIJxQPIgYKCBylIduKsGxtpzSyeEpQZZrogoDiqC");

    return oyngMEISQdIphd;
}

int qXgKYLlx::OyLPCVMEPuerc(int SElIbfKqWP, bool fbfyQJiwdgmTt, bool miMNytyWxhjeaFxA, bool jbKOlEsKxypyQkG, bool vavomS)
{
    string BxyVOGrgYk = string("HWgTSWdnoHENZliUHvBDuLXPSexRdwhURDUmAULRmyciKNtaqe");
    string ASsZvAw = string("hvxdzXVqGhLaohydfKookLfnoOycpASyrIYbknDIrlJpCKWofeMPUCAyZDGlFUpuXYzERkZsuuYuqtDce");
    double bGmcYoIU = 255950.48316498194;
    int mcCcuCXnhrLEUqKe = 1567584532;

    for (int QVJMjLY = 2069235966; QVJMjLY > 0; QVJMjLY--) {
        BxyVOGrgYk = BxyVOGrgYk;
        vavomS = ! jbKOlEsKxypyQkG;
        jbKOlEsKxypyQkG = jbKOlEsKxypyQkG;
    }

    if (jbKOlEsKxypyQkG == false) {
        for (int eDXRgteTn = 294663604; eDXRgteTn > 0; eDXRgteTn--) {
            vavomS = fbfyQJiwdgmTt;
        }
    }

    for (int ouLex = 1150920739; ouLex > 0; ouLex--) {
        continue;
    }

    return mcCcuCXnhrLEUqKe;
}

double qXgKYLlx::uzaQHXjZfW(double MvGVFonkHAPBmhW, string BiipShvHLTFYwo, string EHxSuEou, string NyUjH, bool MBGhud)
{
    int nZbECH = 1452540357;
    bool YhRPedxw = false;
    string TUpiHNHTcXE = string("iAnddPJGqyeLKTUxuwEsyQCnTYINQdcuAikvgdyEMFRRyQvzAgWYjFGtXGynoNhCUrdAnSHnoGEUjqqieNhqISYGMjytnT");
    double CUTsCDhRu = 538311.7085952093;
    double DjYxJ = 361763.6968357948;
    bool ABuANBHtLLU = true;
    int jkcjsZAmW = -568537097;
    bool UHVvQFBamyzETM = true;
    double rdFawcjAr = 302951.63746548153;

    if (DjYxJ > 538311.7085952093) {
        for (int zlJIeNfJtb = 1660046810; zlJIeNfJtb > 0; zlJIeNfJtb--) {
            continue;
        }
    }

    for (int lDPMWuU = 1186898482; lDPMWuU > 0; lDPMWuU--) {
        DjYxJ = CUTsCDhRu;
    }

    for (int FISibKjfdkKq = 720274914; FISibKjfdkKq > 0; FISibKjfdkKq--) {
        rdFawcjAr /= DjYxJ;
        rdFawcjAr += MvGVFonkHAPBmhW;
    }

    return rdFawcjAr;
}

int qXgKYLlx::IXmOGNmPSf(double xLDHQKjwnjvTnV, string XnQsCKqhpWY, int cqMjxxAX, bool UnXRD, double AZqbVSOMpnlsa)
{
    int qrrhwzVpBT = -1290023123;
    bool KWFbkgmGdwZQ = true;
    double pzotuJSsapFmgGP = 996401.6364202504;
    int fnHFe = -553523871;

    if (qrrhwzVpBT > 1318188860) {
        for (int cyVONOVS = 1539161723; cyVONOVS > 0; cyVONOVS--) {
            fnHFe = cqMjxxAX;
        }
    }

    for (int RtOhvACe = 1852416450; RtOhvACe > 0; RtOhvACe--) {
        XnQsCKqhpWY += XnQsCKqhpWY;
        XnQsCKqhpWY += XnQsCKqhpWY;
        pzotuJSsapFmgGP *= AZqbVSOMpnlsa;
        xLDHQKjwnjvTnV /= pzotuJSsapFmgGP;
        xLDHQKjwnjvTnV -= AZqbVSOMpnlsa;
        pzotuJSsapFmgGP /= xLDHQKjwnjvTnV;
    }

    for (int KImGIlm = 1804726140; KImGIlm > 0; KImGIlm--) {
        AZqbVSOMpnlsa *= pzotuJSsapFmgGP;
        XnQsCKqhpWY += XnQsCKqhpWY;
        fnHFe *= qrrhwzVpBT;
        cqMjxxAX *= fnHFe;
    }

    for (int MRrCaCM = 386719805; MRrCaCM > 0; MRrCaCM--) {
        cqMjxxAX -= cqMjxxAX;
    }

    return fnHFe;
}

bool qXgKYLlx::knIHeCPhWEYwYoil(double qfeLNB, bool oqpaokwOewT, int YUgvplWZsKhlOQK, int CiuMlNObFizyBk, double VoGTGg)
{
    double sXpdaZ = -57364.55502541473;
    int mwRhTAeWMrjOw = -666526698;

    if (oqpaokwOewT != true) {
        for (int ueqLoDvuUQIY = 568076390; ueqLoDvuUQIY > 0; ueqLoDvuUQIY--) {
            VoGTGg /= qfeLNB;
            CiuMlNObFizyBk -= mwRhTAeWMrjOw;
        }
    }

    for (int nlLdhr = 555740073; nlLdhr > 0; nlLdhr--) {
        CiuMlNObFizyBk /= YUgvplWZsKhlOQK;
        mwRhTAeWMrjOw -= YUgvplWZsKhlOQK;
    }

    return oqpaokwOewT;
}

string qXgKYLlx::qSgzn(double hMFyVrIhY, bool qaPFOfWzbDafMNG, double IRUQhSQBhh, bool TRxDVHIZlwcP, int zMmrLYTuOrBKru)
{
    bool ncJxRG = false;
    double PKQOnqNYePu = 386344.2860088908;
    string COWMVDWVRnrnYKz = string("bfqdUplrehDZNHUkpPBYGhWtxrIBFZWvQ");
    string UTHVHuuHWASbrPEJ = string("AbmABqMkHwivIJIetXVnIYBEamnpKeSCGlsPmsYtusBgxQVtAxmBNbqhGIKgtZKhYVFFllsjIqhOXuTZsZgSErwgqBmNUbyobYqmvVHJdeUquYobfSCryBWyLjGgBZNXROisqvGsxgWQGVrFBYTklLzeqoJTLuFZHwpUuWRMWvQHhsKEQKEkUByEPhfHbMAcNTfSRqx");
    string INCswweUWgs = string("EwLvxOMBUgwSiPSChguruSxTpCetsvCrtUwNcTlKsOKHXncuMOzollHBSdejThbZJvVJvIhSrRViZZCvPRfqBMzdpWYCYkMEDYpcR");

    for (int YVpUaFarVoCdCf = 1336305878; YVpUaFarVoCdCf > 0; YVpUaFarVoCdCf--) {
        continue;
    }

    for (int clQVxsivwiTQ = 82686528; clQVxsivwiTQ > 0; clQVxsivwiTQ--) {
        continue;
    }

    if (ncJxRG != false) {
        for (int xOTToIMyxbDm = 1837507937; xOTToIMyxbDm > 0; xOTToIMyxbDm--) {
            qaPFOfWzbDafMNG = ! ncJxRG;
        }
    }

    return INCswweUWgs;
}

bool qXgKYLlx::OuxInZqhz(int oibaLqERcjVOif, string HjvvjMT, int VijnwuvycEan, string NyTjtLcDwpXz, bool NtAtjemUrZmBd)
{
    int ubCczVeTb = -84818526;
    double fSdMdE = -807986.4277268968;
    double gYOhJtFvP = -667156.0259038276;
    bool QLEitwWtnDJSAZN = false;
    string jWaHAVvkwSRODLP = string("FExZAaIKnMzFxMQbOHuhaXirkbudaL");
    string liChnsnCeLkiq = string("CqTjFLuo");
    int Ovoza = 162316971;
    string RVNZfpSWMUE = string("pUhMCADjEdSsyOZHhZNginqevDhZFjKXyGFWnBSLoQodWDoINlokPQhabkxgSLsdYhQrHtyqzHXWHeeQexmYchvpPLHcczCuRmrUmAhwutqtdjLYCOSRLictWqvnJlUTJMiMUFGncCTljkcwWcdvg");

    for (int BGTFPoGK = 325680439; BGTFPoGK > 0; BGTFPoGK--) {
        jWaHAVvkwSRODLP = liChnsnCeLkiq;
    }

    for (int sVGukHSUdxGpqNz = 1126603323; sVGukHSUdxGpqNz > 0; sVGukHSUdxGpqNz--) {
        VijnwuvycEan *= VijnwuvycEan;
    }

    for (int aKHODJNaxjHM = 803391094; aKHODJNaxjHM > 0; aKHODJNaxjHM--) {
        RVNZfpSWMUE = liChnsnCeLkiq;
        liChnsnCeLkiq = HjvvjMT;
    }

    if (oibaLqERcjVOif >= -2027174300) {
        for (int LgwOzKijuz = 1824877013; LgwOzKijuz > 0; LgwOzKijuz--) {
            liChnsnCeLkiq += liChnsnCeLkiq;
            NtAtjemUrZmBd = ! QLEitwWtnDJSAZN;
            ubCczVeTb = ubCczVeTb;
            NtAtjemUrZmBd = ! NtAtjemUrZmBd;
            oibaLqERcjVOif *= VijnwuvycEan;
            liChnsnCeLkiq += RVNZfpSWMUE;
        }
    }

    for (int oQHDyHZRTHKx = 1290938897; oQHDyHZRTHKx > 0; oQHDyHZRTHKx--) {
        NyTjtLcDwpXz += HjvvjMT;
        jWaHAVvkwSRODLP = HjvvjMT;
    }

    return QLEitwWtnDJSAZN;
}

bool qXgKYLlx::yKSfkLdOfCL(int LVaXYGE, int pKJosm)
{
    string DpuCGC = string("EDpQOJdmXPiwgJLKFZqEEhvccXaBbWvawYUxgHAuWZbetrSbXOvFsauKbEfHjdGmiLwWqOOpIRJURRKqpHWOIM");
    string iafndh = string("QVQDvWANvSSesWaJCjbelsolsKGcoauCrvYWsvjNMJOWRvFRJqCDxSxbFVGSucnHDgQVifzevvPIXEJXzxtZfudZzHvKdQENWXpXOtwanHlBVwbKndwxCHnEzlqesoYABxscudzusLaUeCSfmwOOAtSjPDVYitnSevXcVdnVVQeShlKxvsTbyiWtMDUPpjodybmRoWisyVsU");
    bool omjAmmulRVckWvzP = false;
    int UFIolBheT = 2064153286;
    string RoUDskid = string("UzvflNGTbRZPlZSUdSgxlkPhphlgkvFMtLUtXgfoaZLufIfOcDhfVbVbjGGZFYSpnNXEHvHBVTyTCTPQoTyknLmybiqMLWEIBGgNnOZUL");
    bool BYNUvsTLCD = false;
    int EMUQnpZDrQ = -185099742;
    double pMiPxAUYPDdgRxQU = 950544.337977337;
    string yjlXDdI = string("GEHgPyBSVKeMHBCrrNYXRrKvMjtEyZvGEOVGjRMrQqPDWCIUNvrVCtlYrxmRRkgmwQkWimofITXkXRQeuXBHEfdekMdPtwibqkJUoyCltMvkIyjpswSkXmHcdTcLDSfufVzuqTozwMsupHvYRSzHXJXOAvnEmxxGgjtYWkdFZyBhuImFkvZhy");
    double naTPsdu = -338306.7012025174;

    for (int wXaNgKrLanf = 214524890; wXaNgKrLanf > 0; wXaNgKrLanf--) {
        BYNUvsTLCD = ! omjAmmulRVckWvzP;
    }

    for (int CoxtpyXVLyAkvahK = 64590035; CoxtpyXVLyAkvahK > 0; CoxtpyXVLyAkvahK--) {
        pKJosm += UFIolBheT;
        UFIolBheT *= UFIolBheT;
    }

    return BYNUvsTLCD;
}

qXgKYLlx::qXgKYLlx()
{
    this->gpxUEfnMT();
    this->ShQnaz(-1727427091, true);
    this->RXDie(string("ljWIRFbBpHWtQElyTRPaOmNbOClSryUuIv"), 835065.1761237775);
    this->WPxPKiUpNLRu(777850.4822426094, -999856360);
    this->OyLPCVMEPuerc(-914692531, false, true, false, false);
    this->uzaQHXjZfW(596176.2290643206, string("sQzoHugthuZRTkJzUmIVouPLNGTFTCiZiHAiStgMcaCMhEeknogkQwXkrYjhWpYTZIwhnZyInndsMOsbzGeqTyYNkUhlpHGmhenilqfsKxHSFDNlxZHAHLusFNoilJoIhsCsDqIagBgWhwtsuPsZnfxqIVpBNFzKHQKmpYKjRpnDGzJzeYxNEPAdpGpDBDnJvhNhyknGbZvmYnSt"), string("MrWjlLJCbPNwlvYZGknGuJiVamYemBRzyzzubVPyhxTcNUiyyJFpJgUhyNSvAALgsvAjUMtFfoDGnJFPjqteELlxJcYuyFhvQxJwXFnrpmIzjAJtlAJsHSGnLSDChnudpdvRCSOtqSQYbkvxFHmpfABfif"), string("azsCwGgyOHLOVWySAxLzPnGyUTdVTdufWOtOEZKYWESdEJcjJLjlxRBLHAnCjAtBHQlGpdHuUOXyggNQZhubslTdqawFyUuldHXmuTAVdjVoYCTLtcUSrYJCFTqLfUZy"), false);
    this->IXmOGNmPSf(-209199.23878093204, string("IPWpNKLEUneFCUfRjARJbSBACucWGMvUSnbwmKrTqRSXLEXRaLvhViBalVTYjPNTOzfqUXgENVvZaGtsHRFXdjKdLEYCwXWTpSAEvfEDsoAjvzJGPfTgSqgSgRxvWSFWgHoxhNkxNVWjXyKFntTOcoBSPClGtJwPZxxmZZBXVNyvPxeffbpkR"), 1318188860, false, -471512.39624846855);
    this->knIHeCPhWEYwYoil(-555673.4912911972, true, -263205691, 158765962, 1014044.0572746599);
    this->qSgzn(46410.80418614677, false, 440421.5898182551, false, 1729622920);
    this->OuxInZqhz(1563078703, string("KOaoJxVxbVdSccvqHFJLYClUrCuMmnHoVCDgLTRpXEGomkCpFsAsNAiwaQRSCFnZfGEoXxrWdZkNLwnemtidKOeiEnqedNAEKWalzniiXEIUlnmNpESNzPdatZZHQwsMnGesQvMYgxDcXeOIDfGjihZanVxFqJAXwhKPOokowaFoPwSDsFQIBiBvdyPCOKzFd"), -2027174300, string("GLnMjQseTswGhtfSXcqFzljqmhLCvekiRXHqduYawPIUsayCmHDLOeTNZnTHVZLtJVyeLJgUnWFnsJajSnBEIIuUvtYEbDQZimZUpizRaZVArxMsIpzWnxjAKVxigbPuEIJiuOqXWplReqwxbAgDCLljQwFmfDSYDSVbFirfElIONXNzciAtTkrfdYqKcYtrMGxnMthcdWgkBCGFWp"), false);
    this->yKSfkLdOfCL(-944418392, -2036815033);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EIvQYLZs
{
public:
    int ZFwKfHLYgyLdBwT;

    EIvQYLZs();
    double PTWrvyRBOCJnJEyJ();
    void SxwcChcHiR(double XhjXmFuYrIjuvZ, double sRrncain, double UnxUZUNR, bool XSnopcYPyTPM);
    int PrwBLEXH(double karITizFyqM, string FXSbmAzMsy, bool tUiNDAXCnnzTPLW, double HRXOdXXuApPV);
    double iroSevZFqIoMnGC(int PapdWtkgjDJQCez);
    int lfHgwqcJSYRTtvDt(string MjreZwiF, bool dHrXwYpkEWKsuusj, bool irNVtJzs, bool noSzBTTDbuPt);
    string ZuCBxEvbuhP(string UZsfVfTgFom, double JDiGydltiiZ, string daHozPFcwxIjau);
protected:
    bool HZHPY;
    string fKeBPeXfUdbvkpg;
    int rZgEJQdGpaIAoia;
    string gCFWavEiVdasoS;
    int WyBPkh;

    int NqqqI();
    string VmnvQDpdxBnsO(double bKmVZ, bool EKGPdnXymCzUVJ, string ugvCR, bool KSyjiYQQS, double Jfelf);
    bool ZwlGcagZXH();
    string jAGjIzjU();
    void SgQpBSSCAqE(double QxYRJX, string GONfRe, bool srqVT, int jByjnShs);
    bool jdEETwOOTErWTtw(bool vbTXi, double rdMKgcKdjCjaF, int fiifWaKnfPP, string JMvZQrMvyw, string aJiuKDlBGLwlrG);
private:
    bool hLhzUErzFfrlIbcj;
    int mUGDiJZn;
    double BrEKcHCgpIIwFT;

    double sImFZDtt(string eDFNZM);
    void TrMJrXkvQkRWvX(int sOkyuQPZQsx, double eosAU, int FWodGR, double XlnfGd, string DsCOeabpxhTCyZPD);
    bool zznjgoQvPGiQ(bool zdAfjhdtF);
    int EmkfqvtDs(double EKmQBx, int EMecBsyKX);
    string PDJxlyZp(int ETIbxCW, string zzGRBkAWa, int mbMqZOo);
    void VsFnEoAsib(double nfsYaGbbEPg);
    void HWSJUIzIGbBXOwe(string WuajrlX, double QoqMAUAtoxSRxn, double maSKnDKWaqiKEhzf, string nmQqCvUDo);
    double BKAnCJP(string lRheH, bool gdyYMmWar, bool LeDMzPx);
};

double EIvQYLZs::PTWrvyRBOCJnJEyJ()
{
    string QnhJxAjSbgLkU = string("PuauRhbbJFXusTnVdzJEymuCvXEMOVneZMfBVAPnzXsKhSbgctAHbwOyQJomiCCtpqXyHoRRGhnhshWMuTtxqINSVKBOqxDDPemPmsdzISzjzKPuKDETBvaDGbpTHoqNlVigwEykeAMrNOTARqUpfayInSuFkkXEriDrMjxIiOAZHobtfcVvFvBUhsClPcpwnYAbZTTSNnqeEMuJ");
    bool AFFEjrXanJca = false;

    return 17424.87576105574;
}

void EIvQYLZs::SxwcChcHiR(double XhjXmFuYrIjuvZ, double sRrncain, double UnxUZUNR, bool XSnopcYPyTPM)
{
    int ajZUHoKkAmsXfqkM = -481645161;
    string Ahwuo = string("BoSEDsJtytlVyIHeQwPPuJynpjgnSTkubpyUPlKITLOHRtqMWxaSRVPXrAqkNAZKxKxIjfWMSLtzOSYPbWKVBVOqjpr");
    string IaMUMndQBStSC = string("ldOxqCpJNeNvtQENZgRqsQNZNaVSEeuZSrrWQyGVcZfIkRYsQGTGOlsXHECJWkvhslpZoYTIEHSzYgaIYbRRiXLqEGFVdHmjEgCnMQhsqamInMhaJTvtqQDufFfLfGaDaBYlhMTztNtAGKKwZAsTjBGKoJJlvXfxwVpcclcLUDlCGiSCsVaFFBmLMiWkhmQqubZSCJoSndgzxTvtLW");

    for (int GuaajVYAbSF = 1779766874; GuaajVYAbSF > 0; GuaajVYAbSF--) {
        IaMUMndQBStSC = Ahwuo;
        XhjXmFuYrIjuvZ += XhjXmFuYrIjuvZ;
        ajZUHoKkAmsXfqkM *= ajZUHoKkAmsXfqkM;
    }

    for (int eWVLxyML = 1157697303; eWVLxyML > 0; eWVLxyML--) {
        XhjXmFuYrIjuvZ *= XhjXmFuYrIjuvZ;
    }

    for (int jqoPgN = 1674915853; jqoPgN > 0; jqoPgN--) {
        IaMUMndQBStSC = IaMUMndQBStSC;
    }

    for (int JkHttPFbe = 909983992; JkHttPFbe > 0; JkHttPFbe--) {
        UnxUZUNR *= sRrncain;
        XhjXmFuYrIjuvZ /= UnxUZUNR;
        XhjXmFuYrIjuvZ -= sRrncain;
        UnxUZUNR += sRrncain;
    }

    for (int aCIviQ = 1854018944; aCIviQ > 0; aCIviQ--) {
        continue;
    }
}

int EIvQYLZs::PrwBLEXH(double karITizFyqM, string FXSbmAzMsy, bool tUiNDAXCnnzTPLW, double HRXOdXXuApPV)
{
    string zlxGrKcwXHivpzqf = string("ROfWUmXFEUUnlXqQqDwVMYiNwTbGvUVmSxwpetrNlpPslITZexDYtKUy");
    double gedGCGTQyVVTr = 134672.18575366685;
    string zixKiBfQhuLWgIp = string("AcLyuTBQLHYjOKBJPHRrCuKGGUUJXNbIHOAltzZywAjsNIKMkDAPxulrxqLtGArVcBVhXsvbJqtvLJEzDrdGaZPRBZlHHUUxlxFQraxaSaInRScdiasXRQxzEHmihBTyNRpghbiaOcSmIDIHKTQwKhRkAjbkbPWjIlfDMimxrrDLhtsrhQFsCwMOPSBxvnZANkdErbQBGYNOvSeJZOhlfBuikoDeUwSvcpCf");
    int lACPrLA = 57306607;
    double ZXpychZIIyZLQP = 720485.0162201435;
    bool DuINSGzaH = true;
    string xDSiCprVndZiulI = string("vdZaa");
    int CEkeLd = 527669535;

    for (int dbzyUbLr = 756815364; dbzyUbLr > 0; dbzyUbLr--) {
        HRXOdXXuApPV *= gedGCGTQyVVTr;
    }

    if (xDSiCprVndZiulI < string("AcLyuTBQLHYjOKBJPHRrCuKGGUUJXNbIHOAltzZywAjsNIKMkDAPxulrxqLtGArVcBVhXsvbJqtvLJEzDrdGaZPRBZlHHUUxlxFQraxaSaInRScdiasXRQxzEHmihBTyNRpghbiaOcSmIDIHKTQwKhRkAjbkbPWjIlfDMimxrrDLhtsrhQFsCwMOPSBxvnZANkdErbQBGYNOvSeJZOhlfBuikoDeUwSvcpCf")) {
        for (int jXdWtOKYxgTE = 1887225928; jXdWtOKYxgTE > 0; jXdWtOKYxgTE--) {
            continue;
        }
    }

    return CEkeLd;
}

double EIvQYLZs::iroSevZFqIoMnGC(int PapdWtkgjDJQCez)
{
    int ayfuKTeXIrMjy = 322668717;
    int RIRftvuTo = -1587732202;
    double isePZshwr = 139709.68750653442;
    int jkOsLwrWzdayP = 1108015623;
    int SadgQfJhWLEoIDre = 2122770344;
    bool dAsvpyWllS = true;

    if (ayfuKTeXIrMjy == 1108015623) {
        for (int vsMyvLxAScsMMi = 582810171; vsMyvLxAScsMMi > 0; vsMyvLxAScsMMi--) {
            SadgQfJhWLEoIDre -= jkOsLwrWzdayP;
            dAsvpyWllS = ! dAsvpyWllS;
            jkOsLwrWzdayP -= PapdWtkgjDJQCez;
        }
    }

    for (int qqDXHoCMwfzah = 1946735285; qqDXHoCMwfzah > 0; qqDXHoCMwfzah--) {
        dAsvpyWllS = ! dAsvpyWllS;
    }

    for (int UPECsfIft = 1477392166; UPECsfIft > 0; UPECsfIft--) {
        SadgQfJhWLEoIDre /= SadgQfJhWLEoIDre;
        SadgQfJhWLEoIDre += SadgQfJhWLEoIDre;
        PapdWtkgjDJQCez *= PapdWtkgjDJQCez;
        ayfuKTeXIrMjy = PapdWtkgjDJQCez;
        PapdWtkgjDJQCez = jkOsLwrWzdayP;
        jkOsLwrWzdayP = RIRftvuTo;
        PapdWtkgjDJQCez -= RIRftvuTo;
    }

    return isePZshwr;
}

int EIvQYLZs::lfHgwqcJSYRTtvDt(string MjreZwiF, bool dHrXwYpkEWKsuusj, bool irNVtJzs, bool noSzBTTDbuPt)
{
    string VxNFhGekJOa = string("AshUACNorPBFCNQOVpdAesHGfBwbQXvoioJYKUEkvbpXzWZTvFCEqtUJAONTstOZKTVaXMQAmliiPrLxQguteLcIKSjCBqolcIEcEjRQWCfeeZdiHnoKUMhvgfeKulKqeTFwxaSzoSsnPmcxHfwdbDbFPCTHCiuUJDhcXSxdWSR");
    bool BEkiLnXjcXlZZ = false;
    bool tuYcDEaDBDYHirjJ = false;
    int QwBKqgVZyXocPaC = -1773861526;
    string oTXQh = string("nwUaMUIZjPfIBOmrSwmAqVQpdVHXoNoXbTypADMsoAigXHoRPtzZKMRkjMcRQSphJHrDqCfgfRapztkJREvcQmRMQ");

    if (BEkiLnXjcXlZZ != false) {
        for (int MSYetkVPjRIN = 1007688591; MSYetkVPjRIN > 0; MSYetkVPjRIN--) {
            BEkiLnXjcXlZZ = ! dHrXwYpkEWKsuusj;
            dHrXwYpkEWKsuusj = noSzBTTDbuPt;
        }
    }

    for (int lkZGoGXXsDggUE = 1401955647; lkZGoGXXsDggUE > 0; lkZGoGXXsDggUE--) {
        VxNFhGekJOa += VxNFhGekJOa;
        BEkiLnXjcXlZZ = noSzBTTDbuPt;
        irNVtJzs = ! dHrXwYpkEWKsuusj;
    }

    return QwBKqgVZyXocPaC;
}

string EIvQYLZs::ZuCBxEvbuhP(string UZsfVfTgFom, double JDiGydltiiZ, string daHozPFcwxIjau)
{
    double UucglhUnHyjDIYRU = -715704.1160753561;
    int GjTgExObsSd = -1410562649;

    if (JDiGydltiiZ > -715704.1160753561) {
        for (int gTEMoyvtipvDUHW = 467102746; gTEMoyvtipvDUHW > 0; gTEMoyvtipvDUHW--) {
            UZsfVfTgFom = UZsfVfTgFom;
            UZsfVfTgFom += UZsfVfTgFom;
        }
    }

    for (int PnKqQ = 1534995559; PnKqQ > 0; PnKqQ--) {
        UucglhUnHyjDIYRU -= UucglhUnHyjDIYRU;
    }

    for (int cOpbWEkmtA = 316609717; cOpbWEkmtA > 0; cOpbWEkmtA--) {
        continue;
    }

    return daHozPFcwxIjau;
}

int EIvQYLZs::NqqqI()
{
    int qladKVICHryihRgP = 1928507063;
    string aVHwVUL = string("tGdeZTqWeOpxguVacQyOidhvodtTDydatYWdAcpfpIiSMOfJajcvhcJJkNcDrheWYrDdLfSMAvVCSIMGOdPjUSIfVNxTfhXukyzCrlCmmJKZqYgkqIPrmoSuVvELHiDarZYRJDRFZxGSBQaFltTUXrKkYZowgJOJKMBDEy");
    int kUCUn = 1310955635;

    return kUCUn;
}

string EIvQYLZs::VmnvQDpdxBnsO(double bKmVZ, bool EKGPdnXymCzUVJ, string ugvCR, bool KSyjiYQQS, double Jfelf)
{
    string FgzCHiIF = string("AWAFlIvbknCBYqPHIkXFQbWVDYbUMnpFrAwBClMjBStIFJpefFhFmLmxkPhAqshJMEinMlGeJpygGrIFGkXreUcKNtvBnljbzFsgLhaLTpKCUABmtkEJNgDEHOLmvlKjUJODUBczxpBxMEErMPphRUROIYKHCDfApaAQaxNpJuDMdbuUcJmqLYNNUpUHgduauGiDKDpHgmoLGbZ");
    bool PNBfEQiqWAJLVra = false;
    double wexTWJpJwezeTuu = 721549.501855923;
    int rMGEoOjzCDwuCYft = -1145187224;
    string jcwmGY = string("doTqxjAgobTMQfLTGvyEomHuQNRYYDiwpstvQOvhblNbnwmfqkGCcPOtFPKqNfqONTpINmzUTyYezoOkGNwFyWJPOmtzyLUDbZkuKujcPwtKUTlAF");
    bool HNRHvyiasCAUc = true;
    bool JpSyTHHn = false;
    bool jAIJWtFICUUeTwW = true;
    bool LzzWnRX = true;

    for (int SqWDAQe = 1442732053; SqWDAQe > 0; SqWDAQe--) {
        jAIJWtFICUUeTwW = ! JpSyTHHn;
        jAIJWtFICUUeTwW = JpSyTHHn;
        LzzWnRX = ! PNBfEQiqWAJLVra;
    }

    if (jAIJWtFICUUeTwW == true) {
        for (int IbsaMUHc = 1723109969; IbsaMUHc > 0; IbsaMUHc--) {
            rMGEoOjzCDwuCYft /= rMGEoOjzCDwuCYft;
            jAIJWtFICUUeTwW = ! jAIJWtFICUUeTwW;
            HNRHvyiasCAUc = ! PNBfEQiqWAJLVra;
        }
    }

    return jcwmGY;
}

bool EIvQYLZs::ZwlGcagZXH()
{
    string ussJWdyQZu = string("GFlDJhscolYaGPghzedqyhfJKYwM");
    double BZZpGEhi = 534349.7434477281;
    bool VrMrqggMUMhj = true;
    bool ysuXr = false;
    string ujbKqTpjMbdvDOS = string("fHbcewxvWXARUYyoyBMoPySsoRYgpCCsivLgQvpHCVrXThIhQWSGLavfWqM");
    double tFUgQBeumPZv = 296213.49068347644;
    bool keXxFUGmNNhB = false;
    double CCQiKOKehdiC = 635937.435344544;
    bool ZgNxGbrfUGWau = true;

    for (int ZhAHEhwi = 1406131300; ZhAHEhwi > 0; ZhAHEhwi--) {
        BZZpGEhi = CCQiKOKehdiC;
    }

    for (int XTyKIPygwCMtkkET = 962531394; XTyKIPygwCMtkkET > 0; XTyKIPygwCMtkkET--) {
        VrMrqggMUMhj = ! ysuXr;
    }

    if (ysuXr != false) {
        for (int fHyKBEvCEScxljp = 1067971078; fHyKBEvCEScxljp > 0; fHyKBEvCEScxljp--) {
            ysuXr = ysuXr;
        }
    }

    for (int EnWSegOdppbGDv = 957720496; EnWSegOdppbGDv > 0; EnWSegOdppbGDv--) {
        continue;
    }

    if (ysuXr != true) {
        for (int mWuidexZMKebzk = 1738189534; mWuidexZMKebzk > 0; mWuidexZMKebzk--) {
            ysuXr = ! keXxFUGmNNhB;
            ysuXr = ! VrMrqggMUMhj;
            tFUgQBeumPZv /= BZZpGEhi;
            ujbKqTpjMbdvDOS = ujbKqTpjMbdvDOS;
        }
    }

    if (ujbKqTpjMbdvDOS < string("fHbcewxvWXARUYyoyBMoPySsoRYgpCCsivLgQvpHCVrXThIhQWSGLavfWqM")) {
        for (int JsBpdFvypgGZ = 1360333797; JsBpdFvypgGZ > 0; JsBpdFvypgGZ--) {
            ZgNxGbrfUGWau = keXxFUGmNNhB;
            CCQiKOKehdiC -= tFUgQBeumPZv;
            keXxFUGmNNhB = ! keXxFUGmNNhB;
            ysuXr = keXxFUGmNNhB;
        }
    }

    return ZgNxGbrfUGWau;
}

string EIvQYLZs::jAGjIzjU()
{
    string RgkXDKv = string("YDkIcoHnaaOFFXqVLrGuDlxiTtBtvoEPGhpARiwXJwKCCqwMHEDPNnehcqPbxMhNLjrnVYhsVYEqfMRXyLXEwzXmwiPSzjYysMcEgQJvdDzhWJOQuMEHdEdWOAuaeJCZbKhiYqtXHscRgOwxqPiIbjztSBPUOdD");
    double GlPErfFETyto = 848176.3500906435;
    string QBZIcf = string("FPWgigcBrEkshyCyjiFcGMfGELlNLlVWzZlLMIroyHwUqaXLtFvycalzEECHrTCPCcHRrmEsPGJbsEOCqyuYujyOnkpXYJUZPNlrPGakdcOgKkpWjkIlmtGVhMZwGyYBETPNshWEUjBSedrDBtHGjirnEbANqekYePdTAMwVFtrSaHUSjEMUgahxzHxQdnfGkDLtBcOEuGbibkFgFgsUpPnAmyGpCIPuoLFXklI");
    bool gJXqbCyYZhvgNb = false;
    string SOpbJsjCfDlP = string("RNjRVFhCeaGgdKjakQIAPgAbPcmtvzyoUgbrjNbBqIoXnRakmFehPaVSDXdmqCK");
    double vKIZAB = 930548.0580405884;

    for (int KOCPAmIxT = 1311105826; KOCPAmIxT > 0; KOCPAmIxT--) {
        continue;
    }

    return SOpbJsjCfDlP;
}

void EIvQYLZs::SgQpBSSCAqE(double QxYRJX, string GONfRe, bool srqVT, int jByjnShs)
{
    double rbdmODPJJAwkES = 50322.84371749809;
    string Euaqx = string("PGYfiHMlLGDDkItAzUyykXTHVewNUbEoMTmPhdagUmGhDSLMTeXTdDLgdLqHfBdlhxWuMbwucXEAXoBmLHwKzpnXrzmSnRFhNrIKxefQpQohLBxGlzyaMAohYpOMcmbNFgvgynjcuopYXIaayjOGSUrqSUMrQTTyzuZwHLpUJINzeaTkScgnsbMngKRYzRBvkCQftofNGjDrTxTFLQkLAIdoJkcQIJYaSiIXdPMqXshGOvZYhcDXqqmWDii");

    if (rbdmODPJJAwkES >= 661684.3198355419) {
        for (int YuigNirXlBYhmfa = 1099498278; YuigNirXlBYhmfa > 0; YuigNirXlBYhmfa--) {
            Euaqx += Euaqx;
            rbdmODPJJAwkES *= QxYRJX;
            QxYRJX *= QxYRJX;
        }
    }
}

bool EIvQYLZs::jdEETwOOTErWTtw(bool vbTXi, double rdMKgcKdjCjaF, int fiifWaKnfPP, string JMvZQrMvyw, string aJiuKDlBGLwlrG)
{
    int mBgFoTElTHFgCvE = -279200968;
    bool GHoAx = false;
    bool LePDpCBmreq = false;
    string VDRMEYbt = string("NKFjdcekHglCvRdPDFngWNgiNrPfescE");
    bool ZYftgy = false;
    bool jJzzFlXiyS = true;
    bool gYQsrDkrNYptizwP = true;
    bool UTHmwdKAOo = false;

    for (int NGxEWmbRAmCKd = 179149044; NGxEWmbRAmCKd > 0; NGxEWmbRAmCKd--) {
        ZYftgy = ZYftgy;
        aJiuKDlBGLwlrG += JMvZQrMvyw;
        mBgFoTElTHFgCvE = mBgFoTElTHFgCvE;
        GHoAx = ! LePDpCBmreq;
        ZYftgy = GHoAx;
        aJiuKDlBGLwlrG += VDRMEYbt;
        vbTXi = ZYftgy;
        GHoAx = ZYftgy;
    }

    for (int FJXPmE = 280779526; FJXPmE > 0; FJXPmE--) {
        JMvZQrMvyw += JMvZQrMvyw;
    }

    for (int zQzOvTHiWC = 1558991366; zQzOvTHiWC > 0; zQzOvTHiWC--) {
        UTHmwdKAOo = GHoAx;
    }

    for (int JxagCUsWzAUPpVG = 1280572407; JxagCUsWzAUPpVG > 0; JxagCUsWzAUPpVG--) {
        jJzzFlXiyS = ! LePDpCBmreq;
        vbTXi = ! LePDpCBmreq;
        LePDpCBmreq = ! jJzzFlXiyS;
    }

    return UTHmwdKAOo;
}

double EIvQYLZs::sImFZDtt(string eDFNZM)
{
    int ZolqSnbKXdlyUjy = 944222776;
    string MAHdlwCeTOsOQVtM = string("FKTpgmLvqgQTgMFErguYFQdEroNjJhxKWPUKtbWgILXEbAXBiInhwcmHCPdnfCvNVYaFgZSHjydSVSXXAKeDQsvVbGoeCKjmPdftjdrySXHWtvAThmxxhoXycnJqGzjUfFqXUTYndScWpBZSpgObytLYpLoXoxVkDpNUhJVOAlVsLtrB");
    int LSnpTEoe = -43079498;
    bool BWOUsZD = true;
    bool onfjr = false;
    string gTeTdwRPLuCbtq = string("ovZdF");
    int ZotIKdbgeKgHybEZ = 861153341;
    int ykiOPzzTgWmDr = 290490859;
    double VZnvvxtChVxVjMh = -997780.3936197388;
    string HbGSVPVUHQzNPI = string("lOuwYFNYhATqMuOaPvuuLcCGlJYZqMJLMCYgmPWVjHkfHrAqRjeyDzpOKURUMPiylkvFFXAnShkNSgTFUxwKXzSRmXpjKlKLWZklRilrllaUHMVjwBAdhsGSPJcNrpieXSGkCsUGAZvlKExSZUbRJOIpXhubgDllXfEEYFtMEeOONYdLeMdutWNkIDzkmbdyTwqJHjVJhv");

    return VZnvvxtChVxVjMh;
}

void EIvQYLZs::TrMJrXkvQkRWvX(int sOkyuQPZQsx, double eosAU, int FWodGR, double XlnfGd, string DsCOeabpxhTCyZPD)
{
    int LVaySESNKQKxrTD = 1018874755;
    bool LJmMbiemi = false;
    string AzceKTb = string("ZykqFNGMQPuEtBlgoYTdVLOtqrWJMprtNIrbsowbDIkB");
    int cISTZbfGs = -1597349068;

    for (int SqUTezJKSCTrMY = 1863845833; SqUTezJKSCTrMY > 0; SqUTezJKSCTrMY--) {
        DsCOeabpxhTCyZPD = AzceKTb;
        sOkyuQPZQsx /= sOkyuQPZQsx;
    }

    for (int NSAWQNKHuBgUZLqS = 444719677; NSAWQNKHuBgUZLqS > 0; NSAWQNKHuBgUZLqS--) {
        continue;
    }

    if (DsCOeabpxhTCyZPD == string("ZykqFNGMQPuEtBlgoYTdVLOtqrWJMprtNIrbsowbDIkB")) {
        for (int GrMkicKBGJzwkuk = 579242328; GrMkicKBGJzwkuk > 0; GrMkicKBGJzwkuk--) {
            continue;
        }
    }

    if (XlnfGd >= 916645.3922247421) {
        for (int cajWVz = 1351038509; cajWVz > 0; cajWVz--) {
            continue;
        }
    }
}

bool EIvQYLZs::zznjgoQvPGiQ(bool zdAfjhdtF)
{
    string bpuaAbpqOMrhb = string("LiVdqBGwaDziMkmWcEwnUzlNTnwYCojkFfgcyLn");
    int RkFhUPgs = -1553880898;
    int sQqEDgtHntvTgEj = 1701428266;
    string eoqSbcslS = string("MLbFjEkqMtWzIIUaYWNkJUjcirqrvBHYABfzSEWrTCNrZRZtfRcgorNQIpsgBgwQMqGGnINNvokYFhyznzfTlyZwmKAMsXreQXnyfshSCofpscVVePcWqacwsacLQcunAezRfgKNwYJiyilqoJwLkMxbENYPJnwKmuLzKrrdxtjZmPGEZKVnyKsoWFPtCjDSVqNIzVKLCcBETQqlXCZTMPlvAQnJwEllJctXaiHbUMkDBWf");
    int VhNAiTFncFn = 1608940156;
    double xWCGltNi = 101827.63043559696;

    for (int SzkvpOVkuOFri = 1744452305; SzkvpOVkuOFri > 0; SzkvpOVkuOFri--) {
        eoqSbcslS = eoqSbcslS;
        VhNAiTFncFn -= sQqEDgtHntvTgEj;
        RkFhUPgs /= RkFhUPgs;
    }

    if (sQqEDgtHntvTgEj == 1608940156) {
        for (int UucujbRs = 1402094118; UucujbRs > 0; UucujbRs--) {
            zdAfjhdtF = zdAfjhdtF;
        }
    }

    return zdAfjhdtF;
}

int EIvQYLZs::EmkfqvtDs(double EKmQBx, int EMecBsyKX)
{
    int jkfIMIyOjjh = 1034367749;
    double TcupsC = -119579.87242898627;
    int cMIHytHbvgvau = -1858301757;
    bool yDqbqrcjn = true;

    for (int irECk = 803263676; irECk > 0; irECk--) {
        yDqbqrcjn = yDqbqrcjn;
        EKmQBx /= EKmQBx;
        jkfIMIyOjjh /= jkfIMIyOjjh;
        TcupsC = TcupsC;
    }

    return cMIHytHbvgvau;
}

string EIvQYLZs::PDJxlyZp(int ETIbxCW, string zzGRBkAWa, int mbMqZOo)
{
    string QRkvePwMDnTh = string("BzekGYJuSaEwFmBIkvGQWxWPccUGhnnFEvMoxtiWbwHeLCPYiyJtwtiUaSoYuWapLefybAhWzGkpPZdfKYilnUUUiDldOOXEZteqqnhHCkiKd");
    int IZJSIh = -2108756389;
    string KbQGiAroAuQHrH = string("uXypTToFcIxhatRgpSWgaSAILSBZvCbgMQBEZEuNVjoUaGrwJQaVYOdFKwsShutIdJWDShAPkQJvzlzRzOdrkmuAHqnUVIJjxjJjMIrkIInnqjiZOywCRtpoFeQbvrOovvXfYtTjiQjujGuBOEQjMtynHsGrHVUWCZhDElRAnigbYgW");
    bool OGlFkwvmEPBRJuq = false;
    int WRqHFtWkyIJylI = -741835149;
    double MyDYMu = -10229.458111042683;
    bool eTGzelTbHeNN = true;
    bool izlHcNlueBleYj = true;

    for (int bvChIFXHWRabF = 1833514565; bvChIFXHWRabF > 0; bvChIFXHWRabF--) {
        zzGRBkAWa = QRkvePwMDnTh;
        MyDYMu *= MyDYMu;
        izlHcNlueBleYj = ! izlHcNlueBleYj;
    }

    for (int xrGMOFIpiwCdGZ = 340911603; xrGMOFIpiwCdGZ > 0; xrGMOFIpiwCdGZ--) {
        QRkvePwMDnTh += KbQGiAroAuQHrH;
        IZJSIh -= mbMqZOo;
        IZJSIh = IZJSIh;
        izlHcNlueBleYj = ! eTGzelTbHeNN;
    }

    if (zzGRBkAWa != string("BzekGYJuSaEwFmBIkvGQWxWPccUGhnnFEvMoxtiWbwHeLCPYiyJtwtiUaSoYuWapLefybAhWzGkpPZdfKYilnUUUiDldOOXEZteqqnhHCkiKd")) {
        for (int tXHdbeK = 1476048656; tXHdbeK > 0; tXHdbeK--) {
            zzGRBkAWa = QRkvePwMDnTh;
            QRkvePwMDnTh += QRkvePwMDnTh;
        }
    }

    for (int NKMLU = 1392864228; NKMLU > 0; NKMLU--) {
        ETIbxCW -= WRqHFtWkyIJylI;
        KbQGiAroAuQHrH = QRkvePwMDnTh;
        WRqHFtWkyIJylI /= ETIbxCW;
    }

    return KbQGiAroAuQHrH;
}

void EIvQYLZs::VsFnEoAsib(double nfsYaGbbEPg)
{
    int GIFFF = 2135327305;
    double EHsOe = 668082.5474213746;
    double ZBtDVU = 691904.0297518551;
    double CByzF = 125831.66575809926;

    if (ZBtDVU != -462318.3557047715) {
        for (int GwAGTZGUQ = 901114912; GwAGTZGUQ > 0; GwAGTZGUQ--) {
            ZBtDVU *= EHsOe;
            CByzF += nfsYaGbbEPg;
            CByzF = CByzF;
            CByzF -= nfsYaGbbEPg;
            nfsYaGbbEPg /= ZBtDVU;
        }
    }

    if (EHsOe < 691904.0297518551) {
        for (int mUPmZg = 1721114473; mUPmZg > 0; mUPmZg--) {
            EHsOe += nfsYaGbbEPg;
            EHsOe /= nfsYaGbbEPg;
            ZBtDVU /= nfsYaGbbEPg;
            ZBtDVU *= EHsOe;
        }
    }

    for (int wpJjHo = 135131370; wpJjHo > 0; wpJjHo--) {
        CByzF = EHsOe;
        nfsYaGbbEPg += EHsOe;
        EHsOe /= EHsOe;
        ZBtDVU -= CByzF;
        EHsOe = nfsYaGbbEPg;
    }

    if (EHsOe == 125831.66575809926) {
        for (int cgWCCNsTJqGpPBos = 370633714; cgWCCNsTJqGpPBos > 0; cgWCCNsTJqGpPBos--) {
            EHsOe += nfsYaGbbEPg;
        }
    }

    if (CByzF > 691904.0297518551) {
        for (int mxRnfPrQdIZ = 2017853972; mxRnfPrQdIZ > 0; mxRnfPrQdIZ--) {
            CByzF += ZBtDVU;
            ZBtDVU *= ZBtDVU;
            CByzF *= ZBtDVU;
            CByzF = nfsYaGbbEPg;
            ZBtDVU /= EHsOe;
            nfsYaGbbEPg *= CByzF;
            EHsOe *= CByzF;
            EHsOe /= CByzF;
            CByzF *= nfsYaGbbEPg;
            GIFFF /= GIFFF;
        }
    }
}

void EIvQYLZs::HWSJUIzIGbBXOwe(string WuajrlX, double QoqMAUAtoxSRxn, double maSKnDKWaqiKEhzf, string nmQqCvUDo)
{
    double NmuakKyVWt = 646309.0392320881;
    bool iiSaPyMjqwe = true;
    int fFDqqJfLVJdVs = 2109453083;
    int eSqWwHJTyZjiZdt = 27840276;

    if (iiSaPyMjqwe != true) {
        for (int CXBOwYbgQWIMHfI = 951405715; CXBOwYbgQWIMHfI > 0; CXBOwYbgQWIMHfI--) {
            iiSaPyMjqwe = ! iiSaPyMjqwe;
            nmQqCvUDo += nmQqCvUDo;
            QoqMAUAtoxSRxn = QoqMAUAtoxSRxn;
        }
    }
}

double EIvQYLZs::BKAnCJP(string lRheH, bool gdyYMmWar, bool LeDMzPx)
{
    string aeGGLSJE = string("SYvGImlXnyKnCpbyxZLBHizawHbOBhZnjfzbnEtENbbqGQutlbqFzduKPALXbbkTvCoWBDsIMQHNAyRXWTiuQwtnxmUWqUudPSrzLTaFhLJfLqQeJsEqJKmwZfIPLdDXRzcZTVXdswahqXZdFVXGXhXqqoAvfdqolKmAvVfrGjwZljPCMpvreDZFhOtNpAIqGnJQxIoSOERTg");
    double CBXzgUBBWBtN = -251394.994841386;

    for (int iEAiiOTaaIrN = 1950914694; iEAiiOTaaIrN > 0; iEAiiOTaaIrN--) {
        aeGGLSJE = lRheH;
        CBXzgUBBWBtN *= CBXzgUBBWBtN;
        lRheH = aeGGLSJE;
        gdyYMmWar = ! LeDMzPx;
    }

    for (int etpUzkHxpiX = 267086644; etpUzkHxpiX > 0; etpUzkHxpiX--) {
        CBXzgUBBWBtN -= CBXzgUBBWBtN;
        LeDMzPx = ! gdyYMmWar;
    }

    for (int NdmEqfT = 817170126; NdmEqfT > 0; NdmEqfT--) {
        gdyYMmWar = gdyYMmWar;
        gdyYMmWar = LeDMzPx;
        aeGGLSJE += aeGGLSJE;
    }

    for (int XyoZQUW = 383408752; XyoZQUW > 0; XyoZQUW--) {
        LeDMzPx = gdyYMmWar;
        gdyYMmWar = ! LeDMzPx;
    }

    for (int gheizWEVKKehAw = 1496992983; gheizWEVKKehAw > 0; gheizWEVKKehAw--) {
        gdyYMmWar = ! LeDMzPx;
        LeDMzPx = LeDMzPx;
    }

    if (aeGGLSJE == string("SYvGImlXnyKnCpbyxZLBHizawHbOBhZnjfzbnEtENbbqGQutlbqFzduKPALXbbkTvCoWBDsIMQHNAyRXWTiuQwtnxmUWqUudPSrzLTaFhLJfLqQeJsEqJKmwZfIPLdDXRzcZTVXdswahqXZdFVXGXhXqqoAvfdqolKmAvVfrGjwZljPCMpvreDZFhOtNpAIqGnJQxIoSOERTg")) {
        for (int XrtMItfFzV = 1224466766; XrtMItfFzV > 0; XrtMItfFzV--) {
            gdyYMmWar = gdyYMmWar;
        }
    }

    return CBXzgUBBWBtN;
}

EIvQYLZs::EIvQYLZs()
{
    this->PTWrvyRBOCJnJEyJ();
    this->SxwcChcHiR(593062.355857809, 313570.43349101837, -204424.15841499827, true);
    this->PrwBLEXH(548817.6790341027, string("kdQZtHzenjnrCDdqnPaaEDyhstLWgGPoTHLYkxlsjhYrkjUaqsVOIlMnXiLnJDkUsbkdjgUfHdArvaFkZkgpVmqcZfGdUlFxFEMkuzHPySEJPjZjJcEffvYigWrtWwJXXvZpkhPSVwFfgEqzLHpIKcgBhttOwnINBOJnPWhYNqXhpEivBSuH"), true, 863625.3934606767);
    this->iroSevZFqIoMnGC(-730398504);
    this->lfHgwqcJSYRTtvDt(string("VpCjhKzQBPmRGqeJZuLUkFySCvILHjiuZpIsvDsGp"), true, true, true);
    this->ZuCBxEvbuhP(string("tNOZtXjqcKzpfooYFxIaNVpDDkjVmtQmhaFhbPbBNUulnIzikXxJScymOCLoxWViWVvAoayropRRhqBYWfZcSgvSLisOKmilDXqcANRQLngPEpPrqmAqhTdYUHUCaAabBVvykEHVaMcCDTcPCQQneFjvhwQQpsmFbLCimbsPatjdMbHBjxEOCdGVRUuBHjwLXaJqmxjwU"), 501604.7123658046, string("pGOjMNnfgsiUxnRDkYdkFbagdJlecxCJLjcLIQyVMJuRvMrOAjJMeesVwKjnanAaoYFefmuCMikulFjEDBBpYyXTegLpxYfQWHaLbLDiUKlZpUgFvIrgcmOxRsSxlqo"));
    this->NqqqI();
    this->VmnvQDpdxBnsO(398229.67863851634, false, string("rBEbzetMaLMWUuusjGGtwhFQiXGdDruuEajyaHvlrgZGtBIWrphBpkXshppBZLQlUMzxiCUrRQGXpXtfZjWpcWCjQMtFFXpqMjPbBOpMZBbcacnVOQtpykQSSNMwYxzPYvnCuoQmbBrhWIvjbnwxYUIqeeIcLDcgvmuckeQhEprTpuzYKgbzsIkaxOYdSzpkBJSozhLngSekQtSCtgKGDwYLkPx"), true, -740804.3138547898);
    this->ZwlGcagZXH();
    this->jAGjIzjU();
    this->SgQpBSSCAqE(661684.3198355419, string("gftRiwhYpeZvnoswgsgFfQYCuKurPDMyhcGDOlfgJrMwwFkDAMmaTPNWWSwDQuoAtNIGZyTcbUgbiBqLjqfIyExYqiBqKCyhtPxQwgEWNSggCUbVYISUeRQkZNjjIEPGRejXExbUmAEcxiNyJYyDxLgECidyBrOlaVDUFqKKWPGFfpjGkdtKvYQVCESmECMStULdNMtjJlmLTrGZJgTuYBmGqVZNr"), true, -2076578189);
    this->jdEETwOOTErWTtw(false, 222576.676228256, 2089533274, string("GGANWGHtNQYUPkIFTMlIUgNDbgyjfDcDHNjYCDqkgemqVCmopFvHEiZrdVAIJZRXFUwiqJNGCkEQSLYWJdaJXjpeDTesPqVVHUfUPKdPYVBbPwfwWobdXdIjiMwmKjaLkkwmJORaWxlGapbotKoxdWgnrCrVbmkBNLOfRhLHtYboxNkKWExNk"), string("FVDNMDcBCCeorrZxBHWCHFIvqrYdJjZsTSagFGpqUzpgzedxzpKGmsEiAxToYrtujsmLKj"));
    this->sImFZDtt(string("ZbDYkqYqBSoLzRxImxtEfuLKjHDDHiXNNCIttTqmLsmxFceBgmPBvdzIjKLMOwQMsCh"));
    this->TrMJrXkvQkRWvX(-1225233964, 916645.3922247421, -2145686517, -369805.7617673436, string("MhblDDGecFbAxCDmaYhxyQGBJYfYscoYOIaFEUoegpsbOlfHzuEpXbwSDozfMrGTzipuvdCCVsmmHJXiWoJSM"));
    this->zznjgoQvPGiQ(true);
    this->EmkfqvtDs(752617.5916628526, 1223440347);
    this->PDJxlyZp(-1997943304, string("XIgrUoPJHOvlZdsvnXYUkSgDZJyWhyHPXMLTJRHuPGhBjRWVEwnfBOJhwBBgNDZVMZneBGYYduyQvvjGiWggxWkXkwSKQBWrAYOBheAsyXOfswtjzDQjgOZmzBCuOsvnnSNdJtLRvodifVChveTiJEVsZnHLoOPpdSH"), 541807483);
    this->VsFnEoAsib(-462318.3557047715);
    this->HWSJUIzIGbBXOwe(string("BBUnCzdeckaJbmfmlYSEtCaOYGbSENjvgcKPKnjRISFMYJqlxpfASRVLNNtEMyNkAQnKSVsCHULIGZHFixsmjKmdnajLNXXzgcaonYSdJNggmXyGQMQekUsoIkEkCQIxParhCidVaNpRvrFMdiyBfYSnt"), -752351.2454771226, 909618.272925367, string("ZUihwqytOFZLQMLcsVhCkXwQDjpUHTQgJLfHHgsIUOenmDHSroDflyRuBNtHadSLoNtjHrAGxovlYWBiSWoaUNnljKsoahvWbgngQnHKlqlsRLVZIorecDLojCQIxgQdLFXfzPokBrcLXtrERuaFrjIusTdrgQasICgQxhzMzZIJzWEufPEuHLbsuqyfToYAeVXQIngpXdyPIODdlEOSH"));
    this->BKAnCJP(string("hfuiNAkUaLKFGLZdjTyVSHTKSDPyzOTngEdkDYBxLTLhICWUKW"), true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class iGKDanbKNPriE
{
public:
    string ThulhwlrgFJHtcX;
    bool hGsbD;
    string DPyLyjSDKIyCI;
    string QnLYzMFhLnX;
    string KtWdrnjaXHAY;
    double MJCeuZyG;

    iGKDanbKNPriE();
protected:
    string FhIeFmggtdGydw;

    bool XopVXhNn();
    int SvNHIY(int ZsoXFOdVYStYTmVO, double YjqZbZdjPDk, int LdclpIrNhetyzpr);
    void ydfbXwKfYiKsWf(bool RQroTfyZBgPfZmAg, string nbXgJmjZJDOTZ, string noIVL, double bSLblTOi, bool HbhnLTTF);
private:
    string pLWafjaRyPrMqpG;
    bool VJgKVet;
    bool lidoBzbfFrocIF;

    string MJFQIyIPhZP(int YIyRTFHivzsTJlW, int TYudEPyiuUfZTsEE, double HTdyUtMmsXjH, int HAPaOAuFghxE);
    bool ecinsDFwNjAoB(bool cljZSEGzTlLA, int oBSJDSPo, double QVGVwWJqsPuOtM, string TYsKLOIU);
    void LIQQfAtACHWDv(double ACMPmbhUqdGH);
    bool fKFZIdgfpEMoYXX(string TFfmnpMckScGN);
};

bool iGKDanbKNPriE::XopVXhNn()
{
    double BVwGdIMzreI = -697629.3291716559;
    bool sGlWjVcnrFr = false;
    string MRQDsrmYqqCcnIJ = string("cqHaLgVxUlbNIkGKSzaajIVricbVxJvZlpbBwKYsXXgjbbgPsxXEwieUUHcZREIfMTBjDTTatgEYaZqdebMtXqzfqVMCEgWrosmpASrsuNLmsqIUnZJetrEdmdaZcDaGINaBhYndjRrWVCIvpvXxdckUUbnIEDkSxvovwtMaTYmVGnjUXeHGOFqpYcjdbuHgORNTswVXxhZaGEpLfYHYtkqb");
    bool ozlqXDW = true;
    string sDajIQpPOoaZmSia = string("DKoErQtUlZRgGxVvVFJVWzFqzLzunlGGeAWCVfDNnTjWNyrMSScVhdrsznKJqtDlDZPUGtWFUtkxVGsOdYutwmbsLbZnonzyctAXJlKojqZTPYvssGTsXfLnPjciopouYCsQOhjlJwLwCUclnERZoMsEPBOmrRjQTSIUIIKmsJxGqJbWXnVuUEVVvSEgAFtDcIrIKqPdTsNIZwaUa");
    double LNJUbKBaimQLtuw = -714036.9226261505;
    double VNGVgemHFXMGZOX = -1028262.233166796;

    if (sDajIQpPOoaZmSia != string("DKoErQtUlZRgGxVvVFJVWzFqzLzunlGGeAWCVfDNnTjWNyrMSScVhdrsznKJqtDlDZPUGtWFUtkxVGsOdYutwmbsLbZnonzyctAXJlKojqZTPYvssGTsXfLnPjciopouYCsQOhjlJwLwCUclnERZoMsEPBOmrRjQTSIUIIKmsJxGqJbWXnVuUEVVvSEgAFtDcIrIKqPdTsNIZwaUa")) {
        for (int LmOrOKFPAI = 1645129101; LmOrOKFPAI > 0; LmOrOKFPAI--) {
            BVwGdIMzreI = VNGVgemHFXMGZOX;
        }
    }

    if (sGlWjVcnrFr == true) {
        for (int KWayAHOxp = 1997566687; KWayAHOxp > 0; KWayAHOxp--) {
            ozlqXDW = ozlqXDW;
        }
    }

    return ozlqXDW;
}

int iGKDanbKNPriE::SvNHIY(int ZsoXFOdVYStYTmVO, double YjqZbZdjPDk, int LdclpIrNhetyzpr)
{
    double PAAIncHArp = -188165.56705708665;
    bool qNSEnd = true;
    int jbpBWHb = -866137910;
    bool hIEtMpeotHq = false;

    for (int KazKWOILmKr = 890929540; KazKWOILmKr > 0; KazKWOILmKr--) {
        qNSEnd = hIEtMpeotHq;
        LdclpIrNhetyzpr = jbpBWHb;
    }

    if (hIEtMpeotHq != false) {
        for (int LOPzPJT = 1430294978; LOPzPJT > 0; LOPzPJT--) {
            qNSEnd = qNSEnd;
            LdclpIrNhetyzpr += ZsoXFOdVYStYTmVO;
            YjqZbZdjPDk -= YjqZbZdjPDk;
        }
    }

    for (int gsQEiIV = 183222801; gsQEiIV > 0; gsQEiIV--) {
        hIEtMpeotHq = hIEtMpeotHq;
    }

    for (int YrFuwowLXgWC = 211120382; YrFuwowLXgWC > 0; YrFuwowLXgWC--) {
        jbpBWHb *= ZsoXFOdVYStYTmVO;
    }

    return jbpBWHb;
}

void iGKDanbKNPriE::ydfbXwKfYiKsWf(bool RQroTfyZBgPfZmAg, string nbXgJmjZJDOTZ, string noIVL, double bSLblTOi, bool HbhnLTTF)
{
    bool eZmRPplbMIbv = false;
    string MBhEklNdyFPgotM = string("BQOCEgbRCMYoWIQsmnUOUXRZRYHMpHX");
    string LKyzmqZS = string("gpWVxfQRHArTRGuSAswtfYWzhdlxcveyumuKaNYJeucgJidrNMbAAwVmmpinxtEfCnPHYwGhjLKhfmUgrPypOkiATpSOVtvslhviVsMQXxhYlqdcVEKSqefMxTHglKJn");
    bool asYzmf = false;
    bool TskYAL = true;

    for (int xqyaLcMWOJaNbFin = 475327710; xqyaLcMWOJaNbFin > 0; xqyaLcMWOJaNbFin--) {
        eZmRPplbMIbv = TskYAL;
    }

    if (bSLblTOi != -925715.1479640026) {
        for (int YmEIHO = 770013592; YmEIHO > 0; YmEIHO--) {
            continue;
        }
    }

    for (int hpgXTk = 1136256303; hpgXTk > 0; hpgXTk--) {
        MBhEklNdyFPgotM = noIVL;
        RQroTfyZBgPfZmAg = eZmRPplbMIbv;
    }
}

string iGKDanbKNPriE::MJFQIyIPhZP(int YIyRTFHivzsTJlW, int TYudEPyiuUfZTsEE, double HTdyUtMmsXjH, int HAPaOAuFghxE)
{
    double ONChQJojRwR = 598418.3708751629;
    double ivEmZnzggA = -790337.351868606;

    if (HTdyUtMmsXjH == -790337.351868606) {
        for (int bEpZwyqybClgFlHa = 2147313054; bEpZwyqybClgFlHa > 0; bEpZwyqybClgFlHa--) {
            ONChQJojRwR /= ivEmZnzggA;
            ivEmZnzggA += HTdyUtMmsXjH;
            YIyRTFHivzsTJlW *= HAPaOAuFghxE;
            HAPaOAuFghxE -= HAPaOAuFghxE;
        }
    }

    return string("xRzmguwgyFEaGnzyDRkayZbsDDyEBnWeBsOKHeIBNtMwwOixzfnEOCkaTFfKDIpbFtiqYZkFFVxCFtfMdoGzvcVdMsLpEgfbkPDJaprDGFRfzBbmcFiZWWzkMSwMrgtyXCTktDttBxTIAVAFSkPlnmKqGpCqSaNTDWdBzROPyBWroSeQsfuSgWiyFwfSoowbjExrn");
}

bool iGKDanbKNPriE::ecinsDFwNjAoB(bool cljZSEGzTlLA, int oBSJDSPo, double QVGVwWJqsPuOtM, string TYsKLOIU)
{
    int TXgdYKEyhSq = 2062180207;
    double AVaXmGIYDE = -375381.5297143293;
    bool lWKGlN = false;
    double RmabmYEvBVKsXkC = -190306.64396540888;
    string PVmHMV = string("BENralWIbiZIzMvgOoUhKlHgGCHXQBfYXxiXRdlpqmSKjliIUNGrYyaxOHVobddoILZOmgDKYlaBIWlmGBigSZOyiioxeESJxzHWKEujQPidIOKlRwhAWjqSqzmFyqxoddwhhusSEKyvjraVPzmlXCPtTXu");
    double IabOK = 590227.0973668722;
    string QAZgKaqn = string("FiZbXJMjASVuaZbpqrJeDTDDgBkmwKCItFFROjSCrdjgyqfeodnVJcXUtdNAUYqaEZfbNGCwmfOPUIHxRnV");
    string xBFYwRHinOQWyAaa = string("FWBIMJMlZojCdQoxGUpPwGDhDSbGfMaOjNuYbUnWlbxjNWEJebHbOpgGHAYgDlIrhncskurqBOtRzhnSrNOrfrreIklEmHVeUgNbmlyLATrIQtnzuEtNmbroRHsQoGstOHWQAxScIuHnDcqxQmQizExJgwetBRUSkeGsbZCjSpDtgGDUznZTwPgk");
    string bcxFOr = string("mcKDnSclkpyUnsXALPqXAaEIEtaQxzhTocgvpPZfGxTvdggwQbDTraEip");
    bool EXiBFIfxV = false;

    for (int vjHDosn = 1941751600; vjHDosn > 0; vjHDosn--) {
        continue;
    }

    return EXiBFIfxV;
}

void iGKDanbKNPriE::LIQQfAtACHWDv(double ACMPmbhUqdGH)
{
    string eubMwhFhVSqQV = string("aQGykHXtzjXHmKatMiquLVguMHaFOvJBMhWSMvxTbXHGWLrBTvosHYwFVpgDSofOVJFddDrGWbKHkNzEPwBHtVMNtkXLAFWrkkOtJGMBQGZxmDEtvpzUIOHxVbknfLFteblSsqWKJaZYNmZswTZbOshDgtWLUhMfmkdtQOcyItdxOgsqmZJPayUohNET");
    int iImmAeC = -1458966255;
    int PCdHsANJuzq = 101777130;
    double LUSYXAuaGnUV = 899607.4697674246;
    string rKlOMgdytpx = string("WHxgMQXNGsuhOCvrFZPyWnnqVaxRubLWAYXsLwHfVi");
    string mVNKuuYLPfK = string("MNesqCKSLSoMmfPvqzIsyGXQZndKkPzBweTJLdHzTCsjyoAMUOumRvYdfiVkiCVUNGDlMFFNBhOLPNZNDaOslEalXtffFrqhaoQnFTtbjWOPyDafDWyTSifDLvZFvTMOVyxBdMAlQZdjSLWtHHrNdTWVWoYMnVtIDiLxVzfovfuSfKHhiYQZCgtBLxfEuPuPKCAHgyUqOjCqZerZBTSbwLMJGpoKqBCQqprJdSzlSuiEhdfndkixk");
    string NJwlxNREZNGee = string("goEKdehVqcrAyrZZqcbEKQiVBjUhaXAtnukTAeRDBychPwMRXYzqcnvTCqVDhVfrYWsKAkRQJgXAEZBgYHYRLAzhnWzokHsUfmWNxWBLWBDhZsEdWUlFxeTYFHkUxpdsDdAolbMgEsgRLbYMEnYUozOADxYhaxEBfKVRoaHACLfpEYDibaswNGyMpNrsQvOEMkUrHyCSHtopo");
    double zUpYsavGsYFRsfpU = 727532.9025762103;
    bool yMIKPw = false;
    int eLnpIAIOHsAQ = 1346658296;

    for (int wbeQLMQgPRht = 572615352; wbeQLMQgPRht > 0; wbeQLMQgPRht--) {
        iImmAeC -= iImmAeC;
    }

    for (int lWSAj = 1218549273; lWSAj > 0; lWSAj--) {
        continue;
    }

    if (eLnpIAIOHsAQ < -1458966255) {
        for (int CLKCAW = 494171328; CLKCAW > 0; CLKCAW--) {
            ACMPmbhUqdGH /= LUSYXAuaGnUV;
        }
    }
}

bool iGKDanbKNPriE::fKFZIdgfpEMoYXX(string TFfmnpMckScGN)
{
    string bOasQIsfnteF = string("vfeoLEldyeQJpBTTOHPrWscoprnOkFGViozzaEXXuPaGLsEFzZYaXjxJKLqTVasmLrhaobountuvgQbLdjmuBuGBAhIWEIMfQEBmsWwXtsQOQXcqGDr");
    string VCGFes = string("NJwglHyxxuwvLBhlaEkXrPFpmYXAnbfmEHMiTvfZSOQFplnQMirNZrAVExKjxkryxhrISTUnWRswEzzekWznbiAYKEwpAOBprawQQSICgUyzWfoDeAMuVUysNaGcKXLqpGsrhWouvwmzSVOKbzyQqXQLWhPyNQOIhkqmEbPjcIgdwqkPAxuemYuGFSQohXSVpRfqgloaURnQpBLWTgojTuOGcgKHIkDPEaqZWoMSyWMwwzVxbQTypqILm");
    double xQDZJ = -993616.5326585721;
    string gCrAcJdy = string("KDUFADMlenciWEaMWfwGqpWRGgOCclKOYwUirKFTLiqUZzYZhjcszjTizsDJqRKiOjLVseAPJcVorUHQdfubgaQnWEcaKknvvUxebSXBJgqQaHBnTsXurZvAcILqDPgzhSyOgmJSepORIaxK");
    int dDZQfVEdro = 1532258778;
    int qRemLLWYC = -1189536961;
    string YhbaaM = string("AyTCoUJjwUzINNDsQtHdbAYdbfTLZVdbhABiRRKRGbJCEOnyvcnKjmpnffUFvIodHiyMXiMURPNzMHmazddmMSzEtRPVIlTKwbYzbaFGbqjqLXixwkcslzgerslAoEMiKSxOfFXLEhefVKLzBFFrZsEpzkvgdRApPtRQWADSrfDlJqe");
    string sDwJqK = string("wqGGSvnmiDVjEBvVKALfGSTgZBfCZOEhoxMctOetZYZvjdbsXfwMugIbwiSOqeAhNwycYbWMRSXCryBjDtuQWMVsT");
    bool WbHvuTLhEcjv = true;
    int vjXunXF = -419378634;

    return WbHvuTLhEcjv;
}

iGKDanbKNPriE::iGKDanbKNPriE()
{
    this->XopVXhNn();
    this->SvNHIY(-722315822, -994371.8894418473, -1701976704);
    this->ydfbXwKfYiKsWf(false, string("FtheEYxDSAJgOPZCPbxtWHcMQORvfUJdvjnkyqbiLLYnSdjnZpGMQLGhlCmiWJMWsfRjetkLVDEQqqbtTlbzkeeIuVZWgYkpqbtUWVvNCRMUWDzbgkE"), string("YfTMbAqyjJuHrXaKjbYYEleMuYOgWmmUFMfVZijJtiLnHnSyUQsGzelsXFTFvYMNmVdZdRkqkXPBEtDDhOAfIpLVwbXOButxlWbIkpqxAlUPYJyTipEjFeRHfLlYJeZbaLznjYutIiSnGwuxjkJpZZvRXUlzyclbagPLkZPMndpQZxuXQiiCGLtYqHNrPyHbLmtEznTwmJJwruWXatQYvaHnTdlmpaUsFxnYavoUd"), -925715.1479640026, false);
    this->MJFQIyIPhZP(2105508618, -67977031, 945622.216189604, 1244121637);
    this->ecinsDFwNjAoB(false, 806336756, -922543.7827056311, string("DRStDCcGofxfIvtIOsqcIpSGjFfknNcFgHnRUWTuVJiywhUePIgYACqttnPMcVcSbFvtaCrJCpGmAlOXQyUuUECsdnNrzjFIOfUKCcipVpkVZyIkgTAOXmxLVuITEfyCGltUNWSHyOfBhgYhDFOcyTiqwDfmRGyFFGxvQeteZgDUTJmRDDvnKhsKUNQBxUphwhlTiPAbPUQwCJITMMGytkUpmIxXzaLWYhHiiGQTi"));
    this->LIQQfAtACHWDv(324198.638964194);
    this->fKFZIdgfpEMoYXX(string("rKaGfvhjtJzfCbPJaJoAjvzKtssWNkZNqEvGAGcMPFKZTlQzSialaUpVHyEFdIgxgOkbMvIXqCxjBnalZ"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MgHqpPkbxrbaMEnC
{
public:
    double iLgDuvd;
    string hfJZqKxuW;
    int RBupneSF;
    double LNzqeRLYVrTH;
    string UYhoZtDndW;
    string QvSkjKNgoxNhSQY;

    MgHqpPkbxrbaMEnC();
protected:
    int JCDbemmiJtcuO;
    double ShBtNwlc;
    string AfRuAdAaPOFMcPP;
    string SbZxgmMsHFaweEao;
    bool yVBYOuXnlemWbA;

private:
    int eyRAb;
    bool ayvYUVqbNjKE;
    int RPAiPkFWftH;

};

MgHqpPkbxrbaMEnC::MgHqpPkbxrbaMEnC()
{

}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rpXrA
{
public:
    int qNdwELnerFFPEUUB;

    rpXrA();
    double GsmBLvTsttWJhHTo(int MREEGgbUjIk, int qAIpCnEIqEaU, int RlMYwKl);
    void SbeCTPgtxfyDO();
    void dkTUq();
    double XxXrCwn(double JbLnRXTFgTb);
    string OvTLhXugN(int WcaGCoeolbJsAB, int fYkzqko, int opDBAdUqlCyLOV, bool rexhESYXKfSudS, int cpqkqKqNdKzVyub);
    bool TWcGJBoxs(int kCQRtPFhCYu);
    bool teRkVkw(bool IzIwFsD, bool YafWvcFSHdsPzn, bool JPZSUvpa, string HOdoZumrdR);
    void CtHDmiHYGDYBLd(string gNKMwtF, int WOoZrxjYhSppgVp, double pjcLWB, bool YaTNXKfDtp);
protected:
    bool jrTpArQPqjUTwuw;

    double MgqvJOIBJFBGP(double dEmHUn, string VTInLzbQyyXxsW, bool lUfsVPlKbzzbjrB, int NjleSEPODNYiK);
private:
    bool AgGjbtozHRxE;
    string dqcRoJyIjLmTp;

};

double rpXrA::GsmBLvTsttWJhHTo(int MREEGgbUjIk, int qAIpCnEIqEaU, int RlMYwKl)
{
    double uUEPeKhkX = 30617.178607842357;
    string TWhWjFhSUtDL = string("mXxDyzmEFpUmgQpSLEmvWzHRzzmprDYOQqvRlHfHWzSk");

    return uUEPeKhkX;
}

void rpXrA::SbeCTPgtxfyDO()
{
    double MWAIEqZGFlDgAzk = 877496.8595807735;
    string dBfaFuqLqNCMHLl = string("FOccExTcGGduQuyQygnTKkwnyIirzuTsIwwqTqYkDfshgCSDTnGfeDUwqKPFuErIRZiPzpMxNZqWXfYjEkCTTdbBCc");

    if (dBfaFuqLqNCMHLl != string("FOccExTcGGduQuyQygnTKkwnyIirzuTsIwwqTqYkDfshgCSDTnGfeDUwqKPFuErIRZiPzpMxNZqWXfYjEkCTTdbBCc")) {
        for (int wmIPwWrxkCV = 1667792048; wmIPwWrxkCV > 0; wmIPwWrxkCV--) {
            dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
            dBfaFuqLqNCMHLl += dBfaFuqLqNCMHLl;
            dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
        }
    }

    if (dBfaFuqLqNCMHLl > string("FOccExTcGGduQuyQygnTKkwnyIirzuTsIwwqTqYkDfshgCSDTnGfeDUwqKPFuErIRZiPzpMxNZqWXfYjEkCTTdbBCc")) {
        for (int cKxvVMPqv = 706016429; cKxvVMPqv > 0; cKxvVMPqv--) {
            dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
            MWAIEqZGFlDgAzk += MWAIEqZGFlDgAzk;
            dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
        }
    }

    if (MWAIEqZGFlDgAzk <= 877496.8595807735) {
        for (int NiPBMcXmnBpOIrPP = 609231055; NiPBMcXmnBpOIrPP > 0; NiPBMcXmnBpOIrPP--) {
            dBfaFuqLqNCMHLl += dBfaFuqLqNCMHLl;
            MWAIEqZGFlDgAzk += MWAIEqZGFlDgAzk;
            dBfaFuqLqNCMHLl += dBfaFuqLqNCMHLl;
            MWAIEqZGFlDgAzk *= MWAIEqZGFlDgAzk;
        }
    }

    for (int sQiZIJGaHXeQtoc = 544894944; sQiZIJGaHXeQtoc > 0; sQiZIJGaHXeQtoc--) {
        dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
        dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
    }

    if (MWAIEqZGFlDgAzk <= 877496.8595807735) {
        for (int rjUZrQIMHMLp = 269460903; rjUZrQIMHMLp > 0; rjUZrQIMHMLp--) {
            dBfaFuqLqNCMHLl += dBfaFuqLqNCMHLl;
            MWAIEqZGFlDgAzk /= MWAIEqZGFlDgAzk;
            dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
            MWAIEqZGFlDgAzk *= MWAIEqZGFlDgAzk;
            MWAIEqZGFlDgAzk -= MWAIEqZGFlDgAzk;
            dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
            MWAIEqZGFlDgAzk = MWAIEqZGFlDgAzk;
        }
    }

    for (int oSBMJ = 801164406; oSBMJ > 0; oSBMJ--) {
        continue;
    }

    if (dBfaFuqLqNCMHLl >= string("FOccExTcGGduQuyQygnTKkwnyIirzuTsIwwqTqYkDfshgCSDTnGfeDUwqKPFuErIRZiPzpMxNZqWXfYjEkCTTdbBCc")) {
        for (int JmfWO = 576484990; JmfWO > 0; JmfWO--) {
            dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
        }
    }

    for (int uCVcMUQ = 712432252; uCVcMUQ > 0; uCVcMUQ--) {
        MWAIEqZGFlDgAzk /= MWAIEqZGFlDgAzk;
        MWAIEqZGFlDgAzk /= MWAIEqZGFlDgAzk;
        MWAIEqZGFlDgAzk = MWAIEqZGFlDgAzk;
        dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
        dBfaFuqLqNCMHLl = dBfaFuqLqNCMHLl;
    }
}

void rpXrA::dkTUq()
{
    int hOKvubpae = 1899228416;
    bool oAlvpSucIiUnLlJ = false;
    int UVgzzRgMrHHo = -668872148;
    int RDizn = -61273284;
    string xyxtSmjMaHucfu = string("kOWUEQtkRqgAIgePCpcAiKAKYBpSGSgYIFmmPlknLGeIKZuKxMatefWFkvJPInIhrtYoVMdgTibHGCxVEjXZRawpQgWxjfUSoAKfBBBdhqhKrAzZaiNwsPMsDnapuoVPhnZXqXdcjlDHsDbcuemxCehmuLtpYybzMGvWiyXFQGtnWjyWslAyIFOsQUHDhkUoXVttxrwgAPVDknRJVcmLSNnPjTsgOLQqrlSBokJeD");

    if (RDizn > 1899228416) {
        for (int NcqfujofTHFsf = 1991797464; NcqfujofTHFsf > 0; NcqfujofTHFsf--) {
            UVgzzRgMrHHo += UVgzzRgMrHHo;
            xyxtSmjMaHucfu += xyxtSmjMaHucfu;
            hOKvubpae = hOKvubpae;
            RDizn *= RDizn;
        }
    }

    for (int SIuGE = 849236037; SIuGE > 0; SIuGE--) {
        RDizn /= UVgzzRgMrHHo;
    }

    for (int dgsEKLppUJGxtoTk = 1274959111; dgsEKLppUJGxtoTk > 0; dgsEKLppUJGxtoTk--) {
        UVgzzRgMrHHo += hOKvubpae;
        hOKvubpae += RDizn;
        UVgzzRgMrHHo -= RDizn;
    }

    if (UVgzzRgMrHHo != -61273284) {
        for (int PVLDBfiY = 1615098371; PVLDBfiY > 0; PVLDBfiY--) {
            UVgzzRgMrHHo *= hOKvubpae;
        }
    }
}

double rpXrA::XxXrCwn(double JbLnRXTFgTb)
{
    int EGvSuDqzRmQBhK = 2000291561;
    int QxxDprOu = 135994442;
    bool BiEXDdloJkhM = true;
    double rlXhnOTktAcVM = 394225.48955521727;
    int oPNOrWhVGvAqYIm = 1648083678;
    string ZbyCVScDMl = string("NxFEIVfTmPawUoRFPXrKdrEkRkwDtyIapnySHTSaPidAnSupKFBwJuedGBDtHqAbSGzEWBwPxUxafaQsrzofKIYUoHdTvTtiNuxCtLRgGowNHhmLMlagTfcHdkQjlbxHSanDDYwUxKfVGmaphRxDvoaIajXpGOSrylmryvPinwUJsUWiNMvGQXrkWPuvHwaWBGThxWOwAwtYgwDiabvTAthJxgfEtDpltFAvFe");

    if (JbLnRXTFgTb < 479601.2215090847) {
        for (int YVGvKSjSXivZP = 648418108; YVGvKSjSXivZP > 0; YVGvKSjSXivZP--) {
            continue;
        }
    }

    if (QxxDprOu > 1648083678) {
        for (int kXSkCVHLzX = 1524025569; kXSkCVHLzX > 0; kXSkCVHLzX--) {
            EGvSuDqzRmQBhK = EGvSuDqzRmQBhK;
            oPNOrWhVGvAqYIm /= QxxDprOu;
        }
    }

    for (int yyaSmlbCHY = 1489394799; yyaSmlbCHY > 0; yyaSmlbCHY--) {
        EGvSuDqzRmQBhK -= oPNOrWhVGvAqYIm;
        rlXhnOTktAcVM += rlXhnOTktAcVM;
        EGvSuDqzRmQBhK -= oPNOrWhVGvAqYIm;
    }

    for (int vMBpxnYeDXX = 2006553458; vMBpxnYeDXX > 0; vMBpxnYeDXX--) {
        continue;
    }

    for (int SFRqpL = 1258353272; SFRqpL > 0; SFRqpL--) {
        oPNOrWhVGvAqYIm -= EGvSuDqzRmQBhK;
        QxxDprOu += QxxDprOu;
    }

    return rlXhnOTktAcVM;
}

string rpXrA::OvTLhXugN(int WcaGCoeolbJsAB, int fYkzqko, int opDBAdUqlCyLOV, bool rexhESYXKfSudS, int cpqkqKqNdKzVyub)
{
    bool JQnUyyvTOKlSJx = true;
    double uyhzLUoIsnDYDz = 297836.6607790815;
    string udgeZ = string("pqayBjFTRJxtJVcvUMHQKFGIVDZhWKqEQsKVNGRGYhEdIBnRCmbZXZRaoGvqOnNaKPUh");
    int MGYBDmJNk = -1168752329;
    string fxkgDVNWio = string("XDyTqDpBgICztGCGvcjDTZnKfRnhhVqayHRizQxEwvAmZgHQsZXTrGiJYIUwHTZTMYawdiiujQCILQrdTOtYxKHPRnWyBXENXLGHBoqqpxBeNrJhzsWnkQQGUPUioA");
    double YFFzrJbAty = 34337.06943078971;
    string BIAdxDUVeQMDMtAR = string("VVNREPuvWE");
    string kejFwAwTmPyUFfip = string("NcbbMepiKalOvQOmMjYyfOMayLLdacbeyuITrDIMGWDFhmBUIBHAWtkBFEDihv");

    return kejFwAwTmPyUFfip;
}

bool rpXrA::TWcGJBoxs(int kCQRtPFhCYu)
{
    bool UKXSoMTgymlBTRa = true;
    string uNkovfMnrcqxZwp = string("CRzZsCAFxUqHpyXKcWqsUYfmSXcxgbzMlqBwGfXptLOVQemxUVEbWFBtdJvSWOPoJXenlzwUSFkppnzvuZXvtWypQppOQyiJPvHVckJQfNhNfVnCyYoahdrbtnWYOauOlUHYRzYhHUwg");
    int LjbzJT = -887506344;
    string XGbimxccmiNR = string("twPqRtfvqKjJOovQkyXJjvcItxgmmQiFiDEKmEkstmuENKIttIovNTrbrbzWyonIfCW");
    double cNaaHwHSmjluLJEE = 818982.2996122895;
    int LoRPoSDJOk = -1253244539;
    string TuDneReLxSazE = string("jRjWfTJqZdtTVjBCXunQDZovCTmkpjKHrJXQZBUYHHNHWupevTvLLyNNrQJiuIQehEzZhflqndQaf");
    double SVwoRpMx = 169490.0521730337;
    int MftCJDGPBV = -1313626554;
    string ByTExH = string("sRskg");

    if (MftCJDGPBV <= 863995370) {
        for (int zbqIBsdMDiE = 498496920; zbqIBsdMDiE > 0; zbqIBsdMDiE--) {
            XGbimxccmiNR = TuDneReLxSazE;
            MftCJDGPBV *= LjbzJT;
            XGbimxccmiNR = TuDneReLxSazE;
        }
    }

    for (int CNtrLdrVkQyCGwGK = 757262317; CNtrLdrVkQyCGwGK > 0; CNtrLdrVkQyCGwGK--) {
        continue;
    }

    return UKXSoMTgymlBTRa;
}

bool rpXrA::teRkVkw(bool IzIwFsD, bool YafWvcFSHdsPzn, bool JPZSUvpa, string HOdoZumrdR)
{
    string MZDClll = string("evxlHhwxeCzuCCmkiJxmJFvuMvgRrjHqbNUcbeDSklKZtRFWbYxAoxxMVsUPCfyAXINInwecXUkGVWvxCIaOCJvPZyrgHPyYCX");
    double IefRkgLMeHkphZU = 375674.4437974792;
    double rTMYNIYcHZpvBt = 98989.118512749;
    double syacHlEuPYm = 468705.6222023906;
    string fdTbsp = string("FpFZMdmdHwnVjFxdzxBRChVgqLkVYhvLifkDVCoLNG");

    for (int sKIhojx = 728680449; sKIhojx > 0; sKIhojx--) {
        rTMYNIYcHZpvBt += rTMYNIYcHZpvBt;
        syacHlEuPYm /= IefRkgLMeHkphZU;
        rTMYNIYcHZpvBt -= rTMYNIYcHZpvBt;
    }

    return JPZSUvpa;
}

void rpXrA::CtHDmiHYGDYBLd(string gNKMwtF, int WOoZrxjYhSppgVp, double pjcLWB, bool YaTNXKfDtp)
{
    int tZyeEHTMbWEpts = 145864049;
    int nbJkNxBv = 2005090219;
    string hswjCBxXqlJRdzzh = string("KFaDmqwzVomtBLsEnFqheqPLcbmjYroqwisjnPsFicnxDhKsBiiuwomvRsDabyoIbGOOWoADWxRnGeGAxxFqoyGfrazgZUSoZjTZdSBdMthSrEyxVQuRFKuqefthstwCoaxxuhVeOheLtoOYPLVRnuMiADOuwtHekyoCpbohgm");
    bool GhNxJXhnSfJhlo = true;

    if (gNKMwtF != string("KFaDmqwzVomtBLsEnFqheqPLcbmjYroqwisjnPsFicnxDhKsBiiuwomvRsDabyoIbGOOWoADWxRnGeGAxxFqoyGfrazgZUSoZjTZdSBdMthSrEyxVQuRFKuqefthstwCoaxxuhVeOheLtoOYPLVRnuMiADOuwtHekyoCpbohgm")) {
        for (int alNvzF = 1991111391; alNvzF > 0; alNvzF--) {
            YaTNXKfDtp = ! GhNxJXhnSfJhlo;
            nbJkNxBv -= tZyeEHTMbWEpts;
            WOoZrxjYhSppgVp *= tZyeEHTMbWEpts;
        }
    }

    if (YaTNXKfDtp == true) {
        for (int pwnyHvUFzSxAq = 1875358426; pwnyHvUFzSxAq > 0; pwnyHvUFzSxAq--) {
            WOoZrxjYhSppgVp /= WOoZrxjYhSppgVp;
        }
    }
}

double rpXrA::MgqvJOIBJFBGP(double dEmHUn, string VTInLzbQyyXxsW, bool lUfsVPlKbzzbjrB, int NjleSEPODNYiK)
{
    double MjdRThYqvGgPCO = -1010326.3331282558;
    double jBiYpqq = -751911.2847950422;
    string CxXgaEdS = string("mDyVyGVxWNabbgTKAlBhvStqQsgmxQpncimHdZlMPHkMgpuEPiBNSTTVeVNEPaaqRjmRKlHJuNxOwzAjNEBYFeOeavZIXrnfAtGdhmPJmXSwUThdCpVtAtsqFpmQePvOOkUBZZlKIJaYZnnuQxMAWRYAdQdivplQYaaeCAzudjRHKMWMHidcDmdGJRuHHWmyDFplPbSWYphOpnsMcPwSsRWNFlMbuZixtffLXpyvhkhAqUUnMZgQinT");
    int RTDdBUiwEZCBuhUv = 625257180;
    int wDQUsE = -1029356280;

    for (int rWQxyooJOO = 1879961405; rWQxyooJOO > 0; rWQxyooJOO--) {
        lUfsVPlKbzzbjrB = ! lUfsVPlKbzzbjrB;
    }

    for (int lNxxNIkA = 2081662991; lNxxNIkA > 0; lNxxNIkA--) {
        RTDdBUiwEZCBuhUv /= wDQUsE;
    }

    for (int nWkYhuCy = 996155114; nWkYhuCy > 0; nWkYhuCy--) {
        wDQUsE = RTDdBUiwEZCBuhUv;
    }

    for (int XBuwCADYjWkG = 779983076; XBuwCADYjWkG > 0; XBuwCADYjWkG--) {
        NjleSEPODNYiK -= wDQUsE;
        dEmHUn *= MjdRThYqvGgPCO;
    }

    return jBiYpqq;
}

rpXrA::rpXrA()
{
    this->GsmBLvTsttWJhHTo(1986756355, -1227236364, -281009401);
    this->SbeCTPgtxfyDO();
    this->dkTUq();
    this->XxXrCwn(479601.2215090847);
    this->OvTLhXugN(-1133952330, 1610322462, -1647870126, true, 1800669145);
    this->TWcGJBoxs(863995370);
    this->teRkVkw(true, true, true, string("JyKThDSPnHCibHiOEVigMYVCrTnJZzANetIVyhdcgRpmbRyRkEETJCkMBUQDoqQMzfhhJWimOyoscgvEfcWBqffDpBfiYXuLVlzzqADOPUhEEuvWeEvcrKzfKXlVUhFbqbqsumucNupvjzuToYbbBWZvZEnuLRSiycSFcKtXqxbpWmOGWYcmACYLhGYmqO"));
    this->CtHDmiHYGDYBLd(string("wFRtpDSfwcQLbnZCfhoQaYlxcQrNhUkjSvzoKIJyyYROWzmIkErCMxxXTZVNoeXnuTFHlqgrooMIalFDZLhxmOGRdsOJhfqaUrXKJgnFUJFsIBxdjT"), -547128596, 588164.6872181239, false);
    this->MgqvJOIBJFBGP(47900.348765455514, string("nNNUBeGJhaxWNrqwqfUjTNzWLrNGEYIKQAoKipxMr"), true, 720198663);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CTmpsprMe
{
public:
    bool KGndZXx;
    bool XbNUGLAuEb;
    double CtcKiNjuQeIPr;
    double djLgQHlTM;
    string KxAiCIfoFNRXC;
    int HzZNPAoGLdlscQJ;

    CTmpsprMe();
    double kcERbN(double fCRJGwHE);
    double hIBSiXBhzJlonY(bool tfDetByVlPlXmRcE);
    bool XZNKgeUfSFGydDTA(string uumJVcsCcQdMyh, int lEWhgwinXQ);
protected:
    string cxhXgcgD;
    bool jLsCJtJhKdWpnDB;
    bool HevAbAEqgSudAw;
    string EmpCGOnV;
    double CWOWiYBAZHv;
    double ervpbyUvm;

    bool NgkjdtLZwURRuYi(double GqHcvsjmhoScqRE, string LGPjVbMWQ, int cClNBXpWICON, int lbhKm, string npeWIQiytUw);
private:
    string zAyUEs;

    bool HakYRjj(int HqABmMDR);
    void usQEXrpAxpAcS(double znQmhGkXjTmqF, int LvONXFK, int GGwpxyOJMN, double vfaFeniZ);
};

double CTmpsprMe::kcERbN(double fCRJGwHE)
{
    bool FyeBiXhHLSdCRnkL = false;
    double RGnQKtw = 691431.7940940624;
    bool mVtAMvCazXLd = true;
    int TlAVHgXInci = -1302001959;
    string FYCDHYuxrYP = string("IZgchpSiUsybxoDCIMgGSnctWEtVZfHESUCNvzfoskOCzutp");
    string uwTCcYVSAK = string("VGzzsOZpuNmckoybQOKTfVpvlKSfgnHQhEv");
    int Viphb = -1419443914;
    int KOtNDSW = 1998675044;
    bool VqpslNRGgNLmt = true;
    string uoNBmfWDgqx = string("fKdlarJCPOVWJqmnzCQggPnxndUbfmLmMlaUrdfNrjdQDlFtICfTkbWbERLEWbWbudgVcgrFEEwjBhsDSiyRsHjvotVfiMlKDFiSsvXJZLjYEgh");

    for (int PyeazaUBlrQPn = 2067417246; PyeazaUBlrQPn > 0; PyeazaUBlrQPn--) {
        continue;
    }

    for (int nknafBzhZNoeY = 195490002; nknafBzhZNoeY > 0; nknafBzhZNoeY--) {
        uwTCcYVSAK += FYCDHYuxrYP;
        TlAVHgXInci *= Viphb;
    }

    return RGnQKtw;
}

double CTmpsprMe::hIBSiXBhzJlonY(bool tfDetByVlPlXmRcE)
{
    string eLaGAExnyo = string("FxmZTrvRsNZAhbLwLxUqWRfvkNkxKZYMXxEgOuzuRvgKinJDUkUSLtHRkfEmFAUZrADDFKpoiLBlfScZZVerkpsFQABWshgKMdinVXiSNfyYJjawnIPBqRgjSxzjBHTHQsJkDvpLLDxWItSYccLoqnvbvWCCpwGiGygobAXdfOgoILMdSRgzRnvIgJWUiihGC");
    string NvvlABYl = string("pFcMksgeJgVxYIHVLOWGGnTZwSlQyANbUpnVXMreLJiMeuhHRNHqgYyiehobQMLuyRKDleznIYNhBRMCwSGBSQPaVxxuasEloSayAVtAAEPkgaXgFjqwWbPfQfKryJvXlfDRMMXdvmwXppadWKrWqZwvhfgYWNlCRYXfjywWMvoHrCOFxnlXoXDzGTodDeplrYEBIbvKyrukgjrktHmhHKRuNqolIEqs");
    string CEGkAttREcygajg = string("lUCxHVrGIwMHlyRCriEwfhknNBQAIwkzMEgWeXRKRjeWUlEBPbIpfhcUnqTiUNAIEZmNcpqRHMcHCvDogLNJBDUPvBorrJiGwgbRCBQPnBWCaQffGOVAcWazthRMCMHYHHVcJZurnFwOgBaDHLNQHWDTdFwflgFgiFYzCCoRKYbBBGexFkPfUn");
    int nuyZXl = -1975982146;
    string gblqgChDdlqBNuCt = string("KPhMtVnKvoBmrkHpaizDlxRwNYtoIpGclVaZAlrolwQxNQOKACqOawDawCvAlQzqgnZNtpwFndIsvugkevFrblgvPGsgEyGmAGXqfdMQaaLEpGQPHpbYNgAeZZhThjrECcPMBIfcyqbmScicBGqHEwkrrEQVyiFjjEgzRpCBMYsxBOcJvuLssNSZgAupfxnBfHBUKwCtOM");
    string IRWqdcxJaj = string("XCrGqCNTeCxbYyjuNBaHKIuukOjVLvrRdCevubYdZQYajvKkQvFsHzawNjPTshPkyXzlykRjYTzhRPtwJlgYvbviVlNbwevZwSeAkTlSpsuXHoBwAOxvCXVvfiHxANsPCUnzxnGeTMcGniBpgUZYzDqaoEUGYXCVqafZZtbnuisWhsVtCpBAshcobPcDxBvlqcNqOcBUUizgUscfBzTPTUSwMsEQhVupshQypxJVMmZTUePylcC");
    bool mbyboFOEbd = true;
    string DhfDrSNizN = string("cLqQKBxFxgaiQdVklrYiJrcCZXSDLMgGaQdPvZLouWUgaDDbtUvgfWCgpZldgIAwkZzBzznRUltfQgarPJTFerdEmKJoahcgNYnBmUcXqmjEppmPSlXXMabujqmgFywvhMwLgwXzxjDXdr");
    double KmNwOcRoeCVfKTw = -1039209.9340049926;
    int KFWpPcGjyzZXi = 1993311305;

    if (eLaGAExnyo == string("XCrGqCNTeCxbYyjuNBaHKIuukOjVLvrRdCevubYdZQYajvKkQvFsHzawNjPTshPkyXzlykRjYTzhRPtwJlgYvbviVlNbwevZwSeAkTlSpsuXHoBwAOxvCXVvfiHxANsPCUnzxnGeTMcGniBpgUZYzDqaoEUGYXCVqafZZtbnuisWhsVtCpBAshcobPcDxBvlqcNqOcBUUizgUscfBzTPTUSwMsEQhVupshQypxJVMmZTUePylcC")) {
        for (int gBHJvmXzAGgkHkg = 692281747; gBHJvmXzAGgkHkg > 0; gBHJvmXzAGgkHkg--) {
            gblqgChDdlqBNuCt += IRWqdcxJaj;
        }
    }

    return KmNwOcRoeCVfKTw;
}

bool CTmpsprMe::XZNKgeUfSFGydDTA(string uumJVcsCcQdMyh, int lEWhgwinXQ)
{
    double ETVBEHRvwSqgPIhg = -422814.8899576099;
    bool KiKaYFkRalIVunK = true;
    string PhBXtmOZushC = string("ATwAcTEAjHrJFoptuqklSBbcuTVlmWgnojmmCbPB");
    bool FuWobMJOraYc = true;
    int eMqdzxkWJdIOQ = -552192695;
    int OwudWmZi = -1745415783;
    double rAvmcyJn = 602041.3324917172;
    int OFpaUp = 1250547932;
    int RDRneBgy = 200083572;
    int LXMMSzeNJriPMj = -2123469337;

    for (int wBngTqTPDRmC = 528429227; wBngTqTPDRmC > 0; wBngTqTPDRmC--) {
        FuWobMJOraYc = KiKaYFkRalIVunK;
        OFpaUp += LXMMSzeNJriPMj;
        OwudWmZi -= lEWhgwinXQ;
    }

    for (int pRLiDlxdF = 1247699582; pRLiDlxdF > 0; pRLiDlxdF--) {
        rAvmcyJn += rAvmcyJn;
    }

    return FuWobMJOraYc;
}

bool CTmpsprMe::NgkjdtLZwURRuYi(double GqHcvsjmhoScqRE, string LGPjVbMWQ, int cClNBXpWICON, int lbhKm, string npeWIQiytUw)
{
    bool KCLNpazKbGODlocw = false;
    bool TGstFSgH = false;
    bool zLOCimtMillm = true;

    for (int CilMwQMHnLHLuj = 1499745937; CilMwQMHnLHLuj > 0; CilMwQMHnLHLuj--) {
        zLOCimtMillm = KCLNpazKbGODlocw;
        zLOCimtMillm = zLOCimtMillm;
        TGstFSgH = ! KCLNpazKbGODlocw;
    }

    for (int CRxcbnfDCH = 127377991; CRxcbnfDCH > 0; CRxcbnfDCH--) {
        TGstFSgH = ! zLOCimtMillm;
        TGstFSgH = zLOCimtMillm;
        cClNBXpWICON /= cClNBXpWICON;
        zLOCimtMillm = ! TGstFSgH;
    }

    for (int lntgNf = 260353955; lntgNf > 0; lntgNf--) {
        lbhKm -= lbhKm;
        cClNBXpWICON /= lbhKm;
    }

    for (int gdUmKJCz = 863697598; gdUmKJCz > 0; gdUmKJCz--) {
        continue;
    }

    return zLOCimtMillm;
}

bool CTmpsprMe::HakYRjj(int HqABmMDR)
{
    bool matcHAO = false;
    int uVXUqt = 189347670;
    int xgrBVrACAUYA = 864038847;
    string fmEaCCKqcyUFzsga = string("afMz");
    double givebXqSlK = -684744.1579870457;
    double LaoiXPxmjRSxXOU = -878575.808726194;
    bool xpnWHsmxNqQJ = false;

    for (int RpcgmVlPChGcd = 239299520; RpcgmVlPChGcd > 0; RpcgmVlPChGcd--) {
        uVXUqt -= xgrBVrACAUYA;
    }

    for (int jPcMzxVMkgFAm = 194431957; jPcMzxVMkgFAm > 0; jPcMzxVMkgFAm--) {
        xpnWHsmxNqQJ = ! matcHAO;
    }

    for (int LColGzMQ = 924944628; LColGzMQ > 0; LColGzMQ--) {
        continue;
    }

    for (int pfymzkodlmCSz = 895616440; pfymzkodlmCSz > 0; pfymzkodlmCSz--) {
        xgrBVrACAUYA = xgrBVrACAUYA;
    }

    return xpnWHsmxNqQJ;
}

void CTmpsprMe::usQEXrpAxpAcS(double znQmhGkXjTmqF, int LvONXFK, int GGwpxyOJMN, double vfaFeniZ)
{
    bool DIceciYZuJU = true;
    double jXljX = -691993.7812136377;

    if (znQmhGkXjTmqF <= -810169.613358639) {
        for (int YNtNvCBipKTjq = 887658572; YNtNvCBipKTjq > 0; YNtNvCBipKTjq--) {
            znQmhGkXjTmqF /= znQmhGkXjTmqF;
        }
    }

    for (int JIrwYHCfdlEJheU = 1507669828; JIrwYHCfdlEJheU > 0; JIrwYHCfdlEJheU--) {
        LvONXFK += LvONXFK;
    }
}

CTmpsprMe::CTmpsprMe()
{
    this->kcERbN(-475024.5492169436);
    this->hIBSiXBhzJlonY(false);
    this->XZNKgeUfSFGydDTA(string("tUrXlvuYugOXelwFHelHnjlVNuJUd"), 1026237206);
    this->NgkjdtLZwURRuYi(229185.00292844957, string("cfTyGmM"), 1339794328, -1912510299, string("MIzuoqjXvXKZJlRmdGrVtDvTrnaNgvJNVgBwbeMWqHThSpjeEfFYlVVUCumfeqMQSnaWILLmOdrmrrbAsIBnfFzkUleHARCYpXDaRmoZxjGomnOnajybzRxOCFCG"));
    this->HakYRjj(44669705);
    this->usQEXrpAxpAcS(-810169.613358639, 390898445, 1827115065, 700464.0821889121);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tweAwphnJQXELhI
{
public:
    int DFlFVXdgaIwdpMT;
    double QmRdOwqvpXx;
    bool OUeSPMJizjQsoQT;
    double avQoWKqep;

    tweAwphnJQXELhI();
    string DZaRMUmUdqT();
    string pltSPeMwWLuo(bool JZVpkCEkZHCB, bool loalg);
    string ldCLnzDVISQAMqaC();
protected:
    double gAZyay;
    bool EMBHRaOl;
    string LSKBZhtgVyZOr;
    bool UMcVHkVkg;
    int bebVoOzKcZsamVi;

    double WUUHMzsdzZWi();
    double SsVNCMcT();
    int OcpNotyIkljRxOJ(double iIacTW, bool syuhmYboJb, int CwpwwBuNatoPB, double bpSsmJRGYhluGU);
    double sHgnDvwJlCojuS(bool ShoBCWxxkH);
    bool cMueIOA();
    string lrLdMItUv(string mhAHWsXXB);
    void nWftXgMIM(int tGhTRuJtBSuvNkMg, double FJzwtluJkg, double zbwyEXli);
    bool jIUKhR(bool zBVRJCLeCbJzPkAl, double sVtGPYdubd, int hkakU);
private:
    int sLAUJVJ;
    string xInJOAVSDKBOECY;
    double TIgYfzhmH;
    double xlBNO;

    void oQyjWatkagspbmsy(int VuUWROYYWjxPBfjv);
    string KdIodut(double HLPXZ);
    void cqJekJN(int BrvOo, bool iViOYmKxvm, bool sjYhYuJ);
    void uzrhymUukx(bool NWiJNCIyuoWp);
};

string tweAwphnJQXELhI::DZaRMUmUdqT()
{
    string rKwKlsSPYqxzomK = string("gGUgncPIHsiYzCSBwDCJDgGSMRHjpUCWQLKhCgLIsSmahonragxetConVyKzxcouHmQOcauwWJlTwKcxGNwTWSfFnrCfIhBXyIRdsGLCVXeWaLHXJiBqVSOTdTzjAqwyxDxmmjoGRHQIpzwBKgmIB");
    double rBxwOXgqQm = 807996.082773221;
    string yzbUaBvILns = string("QbDeuBiRoMqHMWqWFXxp");
    int crrBvuj = -317131838;
    double IrVMvRjhgFSh = 361562.55418195744;
    int sqyhzAswZAKFaEhO = -1847361204;
    string mTFrbhFKfLBFABq = string("PpStkqoJxcRMuOsohWktZHagdrMTiTpzuodoyAVMkQxWKeAnasNaJHJgLVuUlYPzQPNaDrASldekDQothrXDZZqZikdBAlwxWxtdZBOYwBYQBxlGBquMpelyRCMWkqIFeCVzorQKEKEEvaouXholLDxlDqZzkxSjigpBlVwtKiGHoxDDxJYgtRBCTTAOBdWxcC");

    for (int vthTbCtW = 755209609; vthTbCtW > 0; vthTbCtW--) {
        continue;
    }

    if (mTFrbhFKfLBFABq > string("PpStkqoJxcRMuOsohWktZHagdrMTiTpzuodoyAVMkQxWKeAnasNaJHJgLVuUlYPzQPNaDrASldekDQothrXDZZqZikdBAlwxWxtdZBOYwBYQBxlGBquMpelyRCMWkqIFeCVzorQKEKEEvaouXholLDxlDqZzkxSjigpBlVwtKiGHoxDDxJYgtRBCTTAOBdWxcC")) {
        for (int UjEHAkTjtdUtRyZJ = 1412583964; UjEHAkTjtdUtRyZJ > 0; UjEHAkTjtdUtRyZJ--) {
            continue;
        }
    }

    if (rBxwOXgqQm == 361562.55418195744) {
        for (int zLMFD = 1234676425; zLMFD > 0; zLMFD--) {
            sqyhzAswZAKFaEhO -= crrBvuj;
        }
    }

    if (rBxwOXgqQm != 807996.082773221) {
        for (int auYJND = 319955587; auYJND > 0; auYJND--) {
            rBxwOXgqQm -= IrVMvRjhgFSh;
        }
    }

    for (int vJPlMsSNLiIaRAm = 525150337; vJPlMsSNLiIaRAm > 0; vJPlMsSNLiIaRAm--) {
        crrBvuj -= crrBvuj;
        sqyhzAswZAKFaEhO = sqyhzAswZAKFaEhO;
    }

    for (int NvwkimaxXzUQRfAY = 1381645028; NvwkimaxXzUQRfAY > 0; NvwkimaxXzUQRfAY--) {
        yzbUaBvILns = yzbUaBvILns;
    }

    return mTFrbhFKfLBFABq;
}

string tweAwphnJQXELhI::pltSPeMwWLuo(bool JZVpkCEkZHCB, bool loalg)
{
    double olDtOdCb = 155393.2747741143;
    double DirAlQUHXuSus = 273492.5457129556;
    double oFEKumlHTHFxFEX = -117838.91388556336;
    int wEoiwjt = 1562132527;

    for (int TpyjNZWXOjeaIO = 701876994; TpyjNZWXOjeaIO > 0; TpyjNZWXOjeaIO--) {
        olDtOdCb /= olDtOdCb;
        JZVpkCEkZHCB = JZVpkCEkZHCB;
    }

    for (int TeJjfA = 868878137; TeJjfA > 0; TeJjfA--) {
        continue;
    }

    return string("KhXGTFRDUlxgqIllvabANwPCUEqSNQhYCbKbTQnrPrXzvHcMhczWBbUVTaINtccNpnAmOHysBZjXAEYhExbmKmBQfOehEWkgBbAaLNOqNRIzFKtrKBDHXaZyUeaQpgLJqItyQMtCIOpxrAzdsLDGmrxlAAHdbnnSfHzVChuYhtzruIRhiUQZuCtnJHIkfGQbTmpuiQoLhSHHyZUenrKoxICdLJcuXKlVZqISc");
}

string tweAwphnJQXELhI::ldCLnzDVISQAMqaC()
{
    string MbXcvXWXA = string("dfppeACJqCGeFjYStSyzJVHUHytolKKTBAwbZICjbHzALVGzuMIRHvFUgZcpqoLUsEUdTKTJsBFjmDHftIQslKsboMUBdCnxKrvECwKBkELnLvZMZBhwVPjlwQKkmjfbulQxzcVESIwXOkBIg");
    string YasLdyASzeIl = string("auUjBrtRNmyhqnTqrdmQFeOtYTvSeHISqumbnSoexYDvapCrabYYgsoJbGWvmctnXMqmteesNSMwEKdzaLmyQFqBotwfeUYeGTCYtsjURCCtZHEINPavkhRjGMHjZPYyJRYtuHhDYIFDSMqEaJxXotQyMnAzfxwUCDBYlxjraswoaNTgNzhpnZLZneOJjxXXtxZaqGRtXShOtRPwKTVGZIFSWCvB");
    double cqzMhmZsOA = -245718.9997845564;

    if (MbXcvXWXA < string("dfppeACJqCGeFjYStSyzJVHUHytolKKTBAwbZICjbHzALVGzuMIRHvFUgZcpqoLUsEUdTKTJsBFjmDHftIQslKsboMUBdCnxKrvECwKBkELnLvZMZBhwVPjlwQKkmjfbulQxzcVESIwXOkBIg")) {
        for (int HEblYTzZZpo = 593993872; HEblYTzZZpo > 0; HEblYTzZZpo--) {
            YasLdyASzeIl += MbXcvXWXA;
            YasLdyASzeIl = MbXcvXWXA;
        }
    }

    for (int AQLZiKoE = 449555150; AQLZiKoE > 0; AQLZiKoE--) {
        MbXcvXWXA = YasLdyASzeIl;
        cqzMhmZsOA += cqzMhmZsOA;
        YasLdyASzeIl += YasLdyASzeIl;
        cqzMhmZsOA += cqzMhmZsOA;
        cqzMhmZsOA -= cqzMhmZsOA;
    }

    for (int oOayWbNnsVOzn = 1249766092; oOayWbNnsVOzn > 0; oOayWbNnsVOzn--) {
        MbXcvXWXA = MbXcvXWXA;
        YasLdyASzeIl += MbXcvXWXA;
        YasLdyASzeIl = MbXcvXWXA;
        MbXcvXWXA = YasLdyASzeIl;
    }

    return YasLdyASzeIl;
}

double tweAwphnJQXELhI::WUUHMzsdzZWi()
{
    bool yeAtYRYkwT = false;
    int LdihMKxGOfqWZr = 629374634;
    int cXTnJPIj = -1168555515;

    for (int TvHVRDZfZ = 461310854; TvHVRDZfZ > 0; TvHVRDZfZ--) {
        yeAtYRYkwT = yeAtYRYkwT;
        cXTnJPIj *= LdihMKxGOfqWZr;
    }

    if (LdihMKxGOfqWZr > 629374634) {
        for (int MMCJoCGJUzLN = 982680084; MMCJoCGJUzLN > 0; MMCJoCGJUzLN--) {
            LdihMKxGOfqWZr -= LdihMKxGOfqWZr;
        }
    }

    if (yeAtYRYkwT != false) {
        for (int tzbVHTSLYHDJ = 1205315698; tzbVHTSLYHDJ > 0; tzbVHTSLYHDJ--) {
            continue;
        }
    }

    for (int dahQxMJeDB = 1764919925; dahQxMJeDB > 0; dahQxMJeDB--) {
        cXTnJPIj *= cXTnJPIj;
        yeAtYRYkwT = ! yeAtYRYkwT;
        cXTnJPIj -= cXTnJPIj;
        yeAtYRYkwT = yeAtYRYkwT;
    }

    if (cXTnJPIj != 629374634) {
        for (int IzvseEU = 1250293101; IzvseEU > 0; IzvseEU--) {
            cXTnJPIj += cXTnJPIj;
            cXTnJPIj -= cXTnJPIj;
            cXTnJPIj /= LdihMKxGOfqWZr;
            LdihMKxGOfqWZr += LdihMKxGOfqWZr;
            yeAtYRYkwT = yeAtYRYkwT;
            LdihMKxGOfqWZr += cXTnJPIj;
        }
    }

    if (cXTnJPIj > 629374634) {
        for (int BNbdHOsDXVIMXoSN = 322276018; BNbdHOsDXVIMXoSN > 0; BNbdHOsDXVIMXoSN--) {
            LdihMKxGOfqWZr *= cXTnJPIj;
            yeAtYRYkwT = yeAtYRYkwT;
            LdihMKxGOfqWZr /= cXTnJPIj;
            cXTnJPIj = LdihMKxGOfqWZr;
            LdihMKxGOfqWZr *= LdihMKxGOfqWZr;
            LdihMKxGOfqWZr = cXTnJPIj;
            LdihMKxGOfqWZr /= LdihMKxGOfqWZr;
        }
    }

    return 964724.6756132577;
}

double tweAwphnJQXELhI::SsVNCMcT()
{
    int IHHtrEBrSMLk = -1230685098;
    string keiPprsZn = string("DyAzAgZGrvRKOTogtVomLokumLxFLhlLnJAePNwmcPjsPRfoEUCDojzckEAOiGaWDfjnkWOJjLjyyiXSFxcATmJDHuNIyLNfkEBZ");
    bool qxOpbc = true;
    int oARTpMAVi = 969346311;
    bool KHkvXBgzmgbHmIm = false;
    bool UIqlskqIv = true;

    for (int wHpoAh = 27945606; wHpoAh > 0; wHpoAh--) {
        KHkvXBgzmgbHmIm = qxOpbc;
        KHkvXBgzmgbHmIm = ! UIqlskqIv;
        IHHtrEBrSMLk += oARTpMAVi;
        oARTpMAVi += IHHtrEBrSMLk;
        UIqlskqIv = KHkvXBgzmgbHmIm;
    }

    for (int MBSUdvAinEjRy = 890033978; MBSUdvAinEjRy > 0; MBSUdvAinEjRy--) {
        qxOpbc = ! qxOpbc;
    }

    for (int SIlNvLpeDfjhX = 23896607; SIlNvLpeDfjhX > 0; SIlNvLpeDfjhX--) {
        oARTpMAVi /= oARTpMAVi;
        UIqlskqIv = ! UIqlskqIv;
        UIqlskqIv = qxOpbc;
    }

    return -397175.54465634783;
}

int tweAwphnJQXELhI::OcpNotyIkljRxOJ(double iIacTW, bool syuhmYboJb, int CwpwwBuNatoPB, double bpSsmJRGYhluGU)
{
    string XUewKOQxzofoQkR = string("EOXIwtixNJVkZMNMeSLTEOYqzdgHDPtzDNJCIWERik");
    double XONdR = 452488.20835571154;
    string IUSDO = string("gahwOZoaqTmwDqUvmVICgTbifyfnfMwYcwSeAwcXHJPKTHRNoRwkVvWgSyCBPQgoQbvnCMdhaAaMYDsmewXVazNnjEUBCnwTUXUoBZpDYnoyiFyyAegEWuvCAFqrNiCkpdNCqnCnNBcBgqQJUirWyzeDleMetqQlsuZblsOoQtxBPMCUfKRHZDTosjgyyvrxEakllmhTUWmzsoKcbZZuQLLGCKnzlwqSOubkXlBnSkrxFTMsSHzH");
    string BKcCALI = string("iLfRTUwkWiaZRafUghwnzacEulgEFsrFmmUtg");
    string LMsioGXvyeJmiX = string("oBjFAeIwjNsJNwbpwwBMSkhGkgOYpBMSJPIDbZBXWviKT");
    int yaxpuz = 1093643126;
    bool qcpTGSjxOZLHK = true;
    int gkYIYDJotJt = -2034693126;

    for (int fOYmifHqNgPWy = 1171991555; fOYmifHqNgPWy > 0; fOYmifHqNgPWy--) {
        XUewKOQxzofoQkR += BKcCALI;
        gkYIYDJotJt = gkYIYDJotJt;
    }

    return gkYIYDJotJt;
}

double tweAwphnJQXELhI::sHgnDvwJlCojuS(bool ShoBCWxxkH)
{
    double QGavBwOnNyMarN = -519266.0561753096;

    for (int LFIMVQgxrrtc = 815210960; LFIMVQgxrrtc > 0; LFIMVQgxrrtc--) {
        ShoBCWxxkH = ! ShoBCWxxkH;
        QGavBwOnNyMarN /= QGavBwOnNyMarN;
        ShoBCWxxkH = ShoBCWxxkH;
        QGavBwOnNyMarN /= QGavBwOnNyMarN;
        QGavBwOnNyMarN *= QGavBwOnNyMarN;
    }

    if (QGavBwOnNyMarN > -519266.0561753096) {
        for (int dZnyxWfiYmQErrGD = 1130263545; dZnyxWfiYmQErrGD > 0; dZnyxWfiYmQErrGD--) {
            ShoBCWxxkH = ! ShoBCWxxkH;
            QGavBwOnNyMarN -= QGavBwOnNyMarN;
        }
    }

    return QGavBwOnNyMarN;
}

bool tweAwphnJQXELhI::cMueIOA()
{
    bool mEGyGlpvk = true;

    if (mEGyGlpvk == true) {
        for (int IZGAT = 286512911; IZGAT > 0; IZGAT--) {
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
        }
    }

    if (mEGyGlpvk != true) {
        for (int TxxZAv = 1087249682; TxxZAv > 0; TxxZAv--) {
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
        }
    }

    if (mEGyGlpvk == true) {
        for (int wLgALQYCt = 1531020769; wLgALQYCt > 0; wLgALQYCt--) {
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
        }
    }

    if (mEGyGlpvk == true) {
        for (int BMxKCO = 83142360; BMxKCO > 0; BMxKCO--) {
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
        }
    }

    if (mEGyGlpvk == true) {
        for (int jqPhOArHHrZrEaKT = 857044637; jqPhOArHHrZrEaKT > 0; jqPhOArHHrZrEaKT--) {
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = ! mEGyGlpvk;
            mEGyGlpvk = mEGyGlpvk;
        }
    }

    return mEGyGlpvk;
}

string tweAwphnJQXELhI::lrLdMItUv(string mhAHWsXXB)
{
    string AhuMCkJRi = string("WpPYMdXOzMgLWuXprGvmmVungrvBMgaPcLcwzAsTQvMuLUSeDxIaBqayFTfdIRTMsPKBEnLVLnmFIuVKdkNWcJhtYLUSgNeLaBlvvOrJkjKlvesvcKSacwwfwSisIOameheTwwiGXvTTmBhkJEJqfCnXpbbOvxkXdLGofAKsGGPcVwvmwNJwDUrPSqYhJbToBcUDDcFEIAcSbITfro");
    string qxQMPXTKHXZZDDOy = string("CMPxoZrEXdsWeyXgppjBmBrxozmAenDCSYbsiRsmAkOazyDOkUuaYhVPluEbvEZFLZlmGuvyPKnVodeECMkxQDPKJjfxcUjKjWaTahiYERfkdsXaRFSwUNNryoLqBkQfMpvRrEHGxbcbrBuoZOFerHztPOZMfoKvzGGSMnsJxhxjouboweuCmSaBfrBIqLPxuD");
    int LzIYaIYXEPFZLnn = -854760929;
    double bHQXgZmMDpLcTH = -450573.0841260068;
    string plYFDg = string("vlBFwnyTvLQjDDIoJeRETLCkkNLzNfS");
    bool VBFrbh = false;
    int aiOnKhnRZ = -1721670652;
    int PDoixvTPrl = -2055676892;
    double iyYvTcvdRf = -489028.34711708454;
    string IdQKGcMoMKU = string("irttutSYYXWVyGKqiEqTBgufmMnHQqYtBnmHyiONDDGhNbbfuRvoXDcLSJIxXSKQMEpCQtONAxjCDJbIemBHCtuufFUTzjBJuplscHAdizsQxemqmkkzhgsrZza");

    for (int eckHb = 354718190; eckHb > 0; eckHb--) {
        continue;
    }

    if (AhuMCkJRi > string("irttutSYYXWVyGKqiEqTBgufmMnHQqYtBnmHyiONDDGhNbbfuRvoXDcLSJIxXSKQMEpCQtONAxjCDJbIemBHCtuufFUTzjBJuplscHAdizsQxemqmkkzhgsrZza")) {
        for (int WTxAQW = 31490831; WTxAQW > 0; WTxAQW--) {
            continue;
        }
    }

    for (int cJzkFo = 843665058; cJzkFo > 0; cJzkFo--) {
        LzIYaIYXEPFZLnn = aiOnKhnRZ;
    }

    for (int MsTHr = 725816922; MsTHr > 0; MsTHr--) {
        continue;
    }

    return IdQKGcMoMKU;
}

void tweAwphnJQXELhI::nWftXgMIM(int tGhTRuJtBSuvNkMg, double FJzwtluJkg, double zbwyEXli)
{
    int BetwKeBhAGnsX = -822427550;
    int WQGEsLXMAtVKN = -1679036589;
    int gAJKXFDnkvzewx = -1264413516;
    bool oTgmecSXpHERKqAn = false;
    int KnEZfKlCFzDGArLr = 154157653;
    string msJPzT = string("PSgBPtPdsQXurTnCjCZkXSAzxdg");

    if (BetwKeBhAGnsX > -1378088643) {
        for (int HvAfyHtmamodJf = 918198257; HvAfyHtmamodJf > 0; HvAfyHtmamodJf--) {
            tGhTRuJtBSuvNkMg *= tGhTRuJtBSuvNkMg;
            BetwKeBhAGnsX *= BetwKeBhAGnsX;
        }
    }

    for (int zzOtMJcWKD = 26735058; zzOtMJcWKD > 0; zzOtMJcWKD--) {
        KnEZfKlCFzDGArLr -= BetwKeBhAGnsX;
    }
}

bool tweAwphnJQXELhI::jIUKhR(bool zBVRJCLeCbJzPkAl, double sVtGPYdubd, int hkakU)
{
    bool sWQVvTdMOwoMKA = false;
    int JiYJyVqEy = 1281111366;
    int lOigREaQkJg = -1826853225;
    bool pxtqo = true;
    double EAumR = 135229.1637005682;
    double SVWqswKfTHVhqXAv = 493029.7487153636;
    bool CrfPmWjUzEZ = true;
    bool hnDvfEx = false;
    bool fWrMXgvGQOI = true;
    int guENTLbqnJdAr = -1748774964;

    for (int iNNCbMovEkDBPlfS = 1626214315; iNNCbMovEkDBPlfS > 0; iNNCbMovEkDBPlfS--) {
        CrfPmWjUzEZ = ! pxtqo;
        lOigREaQkJg -= guENTLbqnJdAr;
        fWrMXgvGQOI = ! zBVRJCLeCbJzPkAl;
    }

    if (sVtGPYdubd < -30680.651177021802) {
        for (int cHBBX = 1361714257; cHBBX > 0; cHBBX--) {
            SVWqswKfTHVhqXAv = SVWqswKfTHVhqXAv;
        }
    }

    if (CrfPmWjUzEZ == true) {
        for (int knrIuCYHxrpCJG = 566596076; knrIuCYHxrpCJG > 0; knrIuCYHxrpCJG--) {
            sVtGPYdubd *= EAumR;
            hnDvfEx = zBVRJCLeCbJzPkAl;
            sVtGPYdubd /= SVWqswKfTHVhqXAv;
            hnDvfEx = ! hnDvfEx;
        }
    }

    for (int DqZIPrfMTTPqec = 2122328352; DqZIPrfMTTPqec > 0; DqZIPrfMTTPqec--) {
        zBVRJCLeCbJzPkAl = ! sWQVvTdMOwoMKA;
        hnDvfEx = ! fWrMXgvGQOI;
    }

    return fWrMXgvGQOI;
}

void tweAwphnJQXELhI::oQyjWatkagspbmsy(int VuUWROYYWjxPBfjv)
{
    int dXRTC = -900337543;
    bool nvJbeembPt = false;
    double QTtzdiITqbjorAmn = 85748.62767899374;
    double FqQRGxfaUwaIpvUo = 412758.5770899172;
    string jAXNiUSd = string("KWQgBNlIMSzTYwrBWmvcaTHQzXCTFWoSOgpYDWaXkelAWYuBqvAuAZUZfiCLbywSPYGajLRaSAaWWIhexAGRDCoorjqNIShtmdEnSALBbCgXPZMjJoBHWPukbjRGJgNkTMDQUOTlGnOUDISJDaRAHdiPxRipdCWjhaUHqEWUGWVZJEQGMtEsNicMSddqYrEXkOgUrWhtqVihOPPuPTEUZOUXjm");
    int jMxkZa = -1601022409;

    if (QTtzdiITqbjorAmn < 85748.62767899374) {
        for (int JopZiebxRv = 373696691; JopZiebxRv > 0; JopZiebxRv--) {
            continue;
        }
    }

    for (int oSYikh = 1475402327; oSYikh > 0; oSYikh--) {
        nvJbeembPt = nvJbeembPt;
    }

    for (int rwRmm = 442490256; rwRmm > 0; rwRmm--) {
        jMxkZa *= VuUWROYYWjxPBfjv;
    }

    for (int xhbbOwSbazEwC = 1098003522; xhbbOwSbazEwC > 0; xhbbOwSbazEwC--) {
        QTtzdiITqbjorAmn /= QTtzdiITqbjorAmn;
    }

    if (dXRTC <= -1601022409) {
        for (int WakwathyzHezMJ = 1241293188; WakwathyzHezMJ > 0; WakwathyzHezMJ--) {
            dXRTC /= jMxkZa;
            jAXNiUSd = jAXNiUSd;
            jAXNiUSd += jAXNiUSd;
            jMxkZa += dXRTC;
        }
    }

    for (int ajPjnGiVbFsghaB = 160787067; ajPjnGiVbFsghaB > 0; ajPjnGiVbFsghaB--) {
        VuUWROYYWjxPBfjv += dXRTC;
        VuUWROYYWjxPBfjv += jMxkZa;
    }
}

string tweAwphnJQXELhI::KdIodut(double HLPXZ)
{
    double UQwIvk = 111277.85644376153;
    int ioPjWLWxrMEwxDo = -149042416;
    int euErGR = -310885278;
    bool DTujotpJONxxxksP = false;
    string SnSBSi = string("yjslmuimLyOtzTXSBKuTLpbumkDGwdGEokSJvZgYuEZOjFJWVGZmaAVIwVpAWLBnWwAKanRLYfScCBAnBwXZUwQCnjfTHXzCYYyDKAPWJEdOgdWyPZYiMXEgrTUXmdhYhGZRpqlZahJHshRFvfJwvAaAwMDmzNsOmgXcNYPZRePpplWKvhwsYkEvvEWfTxSOqyRZtHPAVDLqGsitiKgAVmZkaARqBjDkAvrSYkEnioztbnVGiSHXf");
    double ZfyzutFqELIROtzH = 262304.5393513551;

    for (int XJFiUGV = 268668873; XJFiUGV > 0; XJFiUGV--) {
        continue;
    }

    if (ZfyzutFqELIROtzH < 262304.5393513551) {
        for (int PzcKoacRMgzePoOz = 1247080693; PzcKoacRMgzePoOz > 0; PzcKoacRMgzePoOz--) {
            HLPXZ *= UQwIvk;
        }
    }

    for (int DcyiqqbrUr = 1995755815; DcyiqqbrUr > 0; DcyiqqbrUr--) {
        ZfyzutFqELIROtzH = ZfyzutFqELIROtzH;
        HLPXZ *= HLPXZ;
    }

    for (int BzoWDzfyJJx = 621988234; BzoWDzfyJJx > 0; BzoWDzfyJJx--) {
        HLPXZ = HLPXZ;
    }

    return SnSBSi;
}

void tweAwphnJQXELhI::cqJekJN(int BrvOo, bool iViOYmKxvm, bool sjYhYuJ)
{
    double FwOvZsnjGNnzv = -777134.6484218239;
    int vbJzANNJOgTFU = 1276694640;
    double WRHmRnIAZVgCgIs = 41513.727888266985;
    string rkzzmrmkJvXSqpv = string("vjcbRVQhdZooJDcluHrzvRKhhIOfkKtZOXVvwpZlxVEfSAputXxMAhDMmXjOIEnSwmbOmQbGMBeStzpVoVImCVPrNmAHMkpULyPSYvJRTpGEeLUyPCmKblSbVENtOTSRXjQDviytMHPyYuTeCyfUvIXCnTahedjyupSHDklbywRrURhYQZejxzFzwYviYhwHufTBvQyXtOKdFPrkCCaCWhvHDRRdOWbP");
    double hrvffzyani = -845450.2994635492;
    bool wUhbXebZhFfOdJDD = false;
    int eBPzsgxB = 216900272;
    string rUMdGhwgyCph = string("hwBIuowBgWHmEwjSptfozqxeykaAilPshdFWLVJ");
    double JrdJvuUgAQIuev = -36802.437588115274;

    for (int vJrHgbpK = 1067905836; vJrHgbpK > 0; vJrHgbpK--) {
        sjYhYuJ = wUhbXebZhFfOdJDD;
        wUhbXebZhFfOdJDD = ! sjYhYuJ;
        vbJzANNJOgTFU = BrvOo;
        rkzzmrmkJvXSqpv = rkzzmrmkJvXSqpv;
    }
}

void tweAwphnJQXELhI::uzrhymUukx(bool NWiJNCIyuoWp)
{
    int huWzby = -1148801931;
    string EokgSUHSKAyUqi = string("kTLHRqaVXuKRGfPJFyckLBVkpyovdBzyDjSEIutEEvOXDNSuRennnfdGAdAewcjtKTDlYhEfVqtEaiSpmbsKjeMnwEmzbVyMOAXdbddaEMGhmoAYziGsGXCDdfrMfnJXwbaHzQbLJYNsfdXpeROXManhSqoefSgpIJchNvoDBuOmfYKXjvxoUfZQXkrGjQhAYOOtPRXYQWzijdrYDWnpChRyNfryuigoklbUXpXougxXApDALJxNkxRtojQrgTk");
    double mIUICdGwJDNa = 139106.89141022545;
    bool wPToouYdqUzpL = true;
    int qxoPqKJyZc = 119086905;
    bool sKgyOmKMVGdRV = false;
    string LlcGrPBgnXm = string("dWAUhqjNgFYUDtRtdNGywonWRyeshPKDhepDlDYyfZctLCmvHMbGuTNyZXJfdgkLxEGfuOELNEdOdwMaqVDdhMXyzzXIHVndHv");
    int ZgWiixADwMNH = -909688873;
    bool PjuxsepP = true;
    int StYqdlFv = 53094104;

    for (int AcVoERfBRqs = 214317168; AcVoERfBRqs > 0; AcVoERfBRqs--) {
        LlcGrPBgnXm += LlcGrPBgnXm;
        LlcGrPBgnXm += EokgSUHSKAyUqi;
        ZgWiixADwMNH += ZgWiixADwMNH;
    }

    for (int tQYJRu = 33747198; tQYJRu > 0; tQYJRu--) {
        huWzby += qxoPqKJyZc;
        LlcGrPBgnXm = LlcGrPBgnXm;
        wPToouYdqUzpL = sKgyOmKMVGdRV;
        LlcGrPBgnXm = LlcGrPBgnXm;
    }

    for (int ZQjkhgQDcC = 1091779970; ZQjkhgQDcC > 0; ZQjkhgQDcC--) {
        sKgyOmKMVGdRV = ! wPToouYdqUzpL;
        ZgWiixADwMNH = qxoPqKJyZc;
    }

    for (int dhbKLrAlTyzSIIIb = 893661582; dhbKLrAlTyzSIIIb > 0; dhbKLrAlTyzSIIIb--) {
        NWiJNCIyuoWp = ! PjuxsepP;
    }

    for (int vwZgACLoc = 1936788092; vwZgACLoc > 0; vwZgACLoc--) {
        NWiJNCIyuoWp = NWiJNCIyuoWp;
        wPToouYdqUzpL = sKgyOmKMVGdRV;
        NWiJNCIyuoWp = ! NWiJNCIyuoWp;
    }
}

tweAwphnJQXELhI::tweAwphnJQXELhI()
{
    this->DZaRMUmUdqT();
    this->pltSPeMwWLuo(false, false);
    this->ldCLnzDVISQAMqaC();
    this->WUUHMzsdzZWi();
    this->SsVNCMcT();
    this->OcpNotyIkljRxOJ(-751401.2288825314, false, 64405914, 657359.0934039614);
    this->sHgnDvwJlCojuS(false);
    this->cMueIOA();
    this->lrLdMItUv(string("KPVVwTYSuRsGNyAmOUrnhZDTPntRPjopnPIkmzQkRmmWZuLRXnpcuAglgflgpgZsJpAhpANwrJWqdCjmJTUfkuYciAZDYeyJpkZzigXUvJRvedrWifExvczPBbWfvlLtBDQwziPIcOwUQrlvvdsecasqMzcccwtgNpdIeNCA"));
    this->nWftXgMIM(-1378088643, 1045512.4419291194, 895933.4540630362);
    this->jIUKhR(true, -30680.651177021802, -11644528);
    this->oQyjWatkagspbmsy(2137723984);
    this->KdIodut(-193817.62142884822);
    this->cqJekJN(-1966576579, true, true);
    this->uzrhymUukx(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class VyTiFMqJZM
{
public:
    string LpUTLqyolovvhC;
    double kwJILwSsTvJ;
    bool hkFGct;

    VyTiFMqJZM();
    double GHZQrCXwyb(bool xlDsXuWh, double nOpvpov, string gfysahPOCniH, bool jDDebvLFS, int vDbkvpwITBfc);
    double SXsuAYuUOeY(int wjvBiRbOdnWt, string rvmLTfS, double OATScFnnBf);
    int dhVqLWOauTvIis(int Vahgc, bool uPCRUNdEIccSauM, int gEWnApn, int IMPifyIcGrPm);
    void LCCVTaGncha(double eYxfrWLTjhWd);
    double bvWJy(string CpPliekBVmoPGwPD, bool bvqXfqD, double avIQFSzceWNwFBmE, double EhTcwQGxAKF, string fSofM);
    double weOWg(double ISBQrZynu, int iRdnXHcXEjYgV, bool YdzXbN, double PAkNWouitcvkbbi, int YqVMYsCyRhKq);
protected:
    int FcaFInBR;
    bool xzqnBx;

private:
    string FLWqmQpUtfatz;

    void VJFkgNHdXCVOyccF();
    double YnBrtxjAlJFP();
    int BCZzwA(string McjXVrtVhFQFQ, int liDWOdAjNQU, bool AOEvi, bool iSBtfXu);
    double KNdQrjOWxJmiF(double EaxKkn, string VYfagqXO, bool lXTBSbXNpatM, string IFBIwxKYifvpv, double XqcFrovrMVhUWUX);
    double VIZJSZLhrS(bool VrKukxbxx, string uljYwEPoTd, double wnuYaa, string sdTSyCsJc, string euwBR);
};

double VyTiFMqJZM::GHZQrCXwyb(bool xlDsXuWh, double nOpvpov, string gfysahPOCniH, bool jDDebvLFS, int vDbkvpwITBfc)
{
    bool AxoVS = true;
    bool eqOkzWmrJ = true;
    double uHtUSPMKeW = -1024789.7209611028;
    string yeSejIqyUqVB = string("kQGIMGzOFgkpfTcmEQTpRPBuubRilhdpHszLdnBxSKUDoUKGDaZSGesBPdjeeNMldgshiAB");

    for (int WlwjitrfAKeH = 559238401; WlwjitrfAKeH > 0; WlwjitrfAKeH--) {
        nOpvpov *= nOpvpov;
        AxoVS = ! AxoVS;
        nOpvpov /= uHtUSPMKeW;
    }

    if (xlDsXuWh != true) {
        for (int ndACXQu = 77694795; ndACXQu > 0; ndACXQu--) {
            continue;
        }
    }

    for (int RAfQH = 398138790; RAfQH > 0; RAfQH--) {
        AxoVS = ! jDDebvLFS;
        AxoVS = jDDebvLFS;
        AxoVS = ! AxoVS;
        eqOkzWmrJ = ! jDDebvLFS;
    }

    return uHtUSPMKeW;
}

double VyTiFMqJZM::SXsuAYuUOeY(int wjvBiRbOdnWt, string rvmLTfS, double OATScFnnBf)
{
    string dhejRFklbgUAHu = string("znPwKnYNrlgbTLJnBeVXJEmyktgDLEfTyLNTubJlxRfkGntuPsPtWimQWcJhuEIEtQTjJymcpzyFLIjtSxJJeUvLRlhqBgJuvbRnRZymENDHwlNuCkUvDkXaMYYDyICgOqbeHgdpQxCWWgyFcoqJnSizHBDitdqUQVnExZEuGwwalyOdVHFyvKdDbAs");
    bool znoZydDbigSZtCE = false;
    bool aSfpdOOmsaMYQU = false;
    int MjRuFe = 1533268031;
    string AhJwZduYFD = string("fLvpkDmoiryCHWRKeTjeL");

    if (wjvBiRbOdnWt > 476035902) {
        for (int mhUDaCtp = 1116442145; mhUDaCtp > 0; mhUDaCtp--) {
            dhejRFklbgUAHu += AhJwZduYFD;
            znoZydDbigSZtCE = aSfpdOOmsaMYQU;
        }
    }

    return OATScFnnBf;
}

int VyTiFMqJZM::dhVqLWOauTvIis(int Vahgc, bool uPCRUNdEIccSauM, int gEWnApn, int IMPifyIcGrPm)
{
    bool nzUzCT = true;
    bool BgZbQbTzpj = false;
    bool WdWVZu = false;
    string jRLpD = string("kuawyRKfqXBbBaTB");

    for (int gtDzsvQXaHjPY = 1534534693; gtDzsvQXaHjPY > 0; gtDzsvQXaHjPY--) {
        WdWVZu = ! nzUzCT;
        Vahgc *= gEWnApn;
        BgZbQbTzpj = uPCRUNdEIccSauM;
        uPCRUNdEIccSauM = nzUzCT;
        gEWnApn += IMPifyIcGrPm;
        uPCRUNdEIccSauM = ! nzUzCT;
    }

    if (Vahgc == 1661222081) {
        for (int CAYodaFLhySusb = 676412561; CAYodaFLhySusb > 0; CAYodaFLhySusb--) {
            WdWVZu = nzUzCT;
        }
    }

    for (int QabKtAFIrRbmMvO = 104242850; QabKtAFIrRbmMvO > 0; QabKtAFIrRbmMvO--) {
        WdWVZu = nzUzCT;
        IMPifyIcGrPm *= gEWnApn;
        nzUzCT = BgZbQbTzpj;
    }

    return IMPifyIcGrPm;
}

void VyTiFMqJZM::LCCVTaGncha(double eYxfrWLTjhWd)
{
    double oyceMapZoLMfyk = -556069.1302645737;
    bool uuwSvorZ = true;
    double kNyEmryH = -35206.33099864726;
    string SjdcQ = string("knuSnEHiZZIPzrbArYTKjcdZotUlGRktqsvUzQUhhkOnhcpmjIeNvAbjlnmAReDoQOHVaFMoJrxxqEEQiHLPw");

    for (int cgHKFrSYpb = 91185382; cgHKFrSYpb > 0; cgHKFrSYpb--) {
        continue;
    }

    if (eYxfrWLTjhWd != 617502.4921824803) {
        for (int ndhLcwkbAWAmpdat = 1514034322; ndhLcwkbAWAmpdat > 0; ndhLcwkbAWAmpdat--) {
            oyceMapZoLMfyk += kNyEmryH;
        }
    }
}

double VyTiFMqJZM::bvWJy(string CpPliekBVmoPGwPD, bool bvqXfqD, double avIQFSzceWNwFBmE, double EhTcwQGxAKF, string fSofM)
{
    int ufPEixyY = 1422629565;
    bool VyLWKxir = true;
    string BSvIUZJaHMFNSD = string("EYSvIKZNZLwGHsGRVWXYdtYgtufRIZFUHTaWKrlvDblWNyrtGucMhCwuhnHrJCAASVgEpLdWcbpGwILZLKfLEZxjjchSbFxZWoDUdYTwJQaASRRxElqmLWCNqAxAxUzLvtkGWNJYSRRTPQbUUaKXHTFdIqMznmFrzTbzTwECbTjIQETKhsDyyJaRTTDal");
    double yoigehFRHTcUBhe = 107718.69273379428;
    bool WgrmVlOil = false;

    for (int GbaeLFTlIwQrhE = 463547784; GbaeLFTlIwQrhE > 0; GbaeLFTlIwQrhE--) {
        continue;
    }

    return yoigehFRHTcUBhe;
}

double VyTiFMqJZM::weOWg(double ISBQrZynu, int iRdnXHcXEjYgV, bool YdzXbN, double PAkNWouitcvkbbi, int YqVMYsCyRhKq)
{
    string PhFwNSzEzxBpDdp = string("rCkUjLTffAZNClwOrjXLEWlUdHxauumraBlwNXlnTEqULniiozKdbgDvplwxikMntLWQxJyhivCRw");
    bool JgRAXeKvSppUdl = true;
    int mUjQmLOk = 2132345705;
    string hMZtgMazfU = string("paZZEcJvKsCFGZprULpFGv");
    bool CmPOvNMVuwYii = false;
    string naIxseLgR = string("CuYSQW");

    for (int TqPdf = 286227808; TqPdf > 0; TqPdf--) {
        mUjQmLOk += iRdnXHcXEjYgV;
    }

    for (int NHixgcigM = 1220893602; NHixgcigM > 0; NHixgcigM--) {
        continue;
    }

    return PAkNWouitcvkbbi;
}

void VyTiFMqJZM::VJFkgNHdXCVOyccF()
{
    int sUEFCteiWIDRsPM = 410993180;
    double rDCVbsRvoiwg = 561902.87110403;
    string cfvfq = string("tUPslnkwHapgnJUUyBgXxJdEkwrEYrloXxjowdcFdNYnzAPtpWuZpIZhvKDTDrbVpTKFWqbCvhjoXCBLxFKsXpGrSfRlbiQoQMUZWJHXOSDQVgzNHMFNAZnuzjeEbDWdhaYpOPnuByTBKEjsnSkKySHfSVB");
    int jZsLyQGlno = -1854361125;
    string FmbFcUcAaSVxhHMa = string("dpCKsWuPWhitBPZKnAiWDZsVdNBeTyNjghxnmBnyrCzTAjPQVtlZTTiKsJKJdcFLCmyFZQfHWXUYmfBOtwJOpGINDgllJkyAAehTMpDcAzQyQZBsUwyKlyZbAAjqLRWzAfkSGmsFXtxDdjlmKUasKzKdxGukDkrHqsWalXecTEuvakdnaomlDhFoKDAqIOTfqGlPEpcUbRkTRGZRcQJkXBliLoXOhZnRoNE");
    double fWKGr = 587905.5759201819;

    for (int lPOWdiJpDCOEm = 972397117; lPOWdiJpDCOEm > 0; lPOWdiJpDCOEm--) {
        continue;
    }

    if (jZsLyQGlno != -1854361125) {
        for (int gNzmQqc = 404696929; gNzmQqc > 0; gNzmQqc--) {
            FmbFcUcAaSVxhHMa = FmbFcUcAaSVxhHMa;
        }
    }
}

double VyTiFMqJZM::YnBrtxjAlJFP()
{
    double QtCWrAKKEKOaOmQ = 736524.9334652666;
    string ZrZDBHfim = string("UShhBoHAaSGkhJxeiUUFpwmpgWttQCMkHmrcJdAtrPvyDyAQHSaeULLqLPDVpaJmVgPJbxbmIzdBEKbzwBtdidGABdanmOolPHwxppEADheGkKIoJjXLFslmbjATvoLNqnbaAXLJwGIDImLLotyvWtQrLfSjeWxamqxHHKsAXACDpgWGftNuyqLnnPxTFayWudWAogku");
    string wRrQCulbu = string("FhEwOHgtHQVUfRrVZa");
    bool ACWbmigpCXHmQVx = true;
    int YoZtHNvdHB = 1136682094;
    string veJoPi = string("OtTxWQlpzZzWS");

    for (int eBhgGipvNPR = 942749422; eBhgGipvNPR > 0; eBhgGipvNPR--) {
        continue;
    }

    for (int MaocwezJaCC = 451690221; MaocwezJaCC > 0; MaocwezJaCC--) {
        QtCWrAKKEKOaOmQ *= QtCWrAKKEKOaOmQ;
        ACWbmigpCXHmQVx = ACWbmigpCXHmQVx;
        wRrQCulbu += wRrQCulbu;
    }

    for (int gYWMOFQPxmopl = 95605538; gYWMOFQPxmopl > 0; gYWMOFQPxmopl--) {
        continue;
    }

    if (wRrQCulbu > string("FhEwOHgtHQVUfRrVZa")) {
        for (int JpnHGrGzte = 1652520030; JpnHGrGzte > 0; JpnHGrGzte--) {
            veJoPi = veJoPi;
            ACWbmigpCXHmQVx = ! ACWbmigpCXHmQVx;
        }
    }

    return QtCWrAKKEKOaOmQ;
}

int VyTiFMqJZM::BCZzwA(string McjXVrtVhFQFQ, int liDWOdAjNQU, bool AOEvi, bool iSBtfXu)
{
    int yuEELQu = -1846606549;
    double ofKpmHoPeKXA = 910566.2611675217;
    int RsxZkPxzljgDCBOJ = -1765836773;
    bool SjQRQROJMmSfWt = true;
    double ymMvhJw = 662398.4262549437;
    bool pMScLihKnVTfDfSn = false;
    double LDntxLa = 76218.9660772452;
    bool pufYeXzMn = true;

    for (int XFMZf = 297964350; XFMZf > 0; XFMZf--) {
        pufYeXzMn = AOEvi;
        SjQRQROJMmSfWt = ! iSBtfXu;
        pMScLihKnVTfDfSn = SjQRQROJMmSfWt;
        AOEvi = ! SjQRQROJMmSfWt;
    }

    for (int TzimqtQIkmf = 822282045; TzimqtQIkmf > 0; TzimqtQIkmf--) {
        ymMvhJw = ofKpmHoPeKXA;
    }

    if (AOEvi == true) {
        for (int HfxuIoGOWp = 2134283278; HfxuIoGOWp > 0; HfxuIoGOWp--) {
            pMScLihKnVTfDfSn = iSBtfXu;
        }
    }

    for (int HIBGW = 890844802; HIBGW > 0; HIBGW--) {
        McjXVrtVhFQFQ = McjXVrtVhFQFQ;
        SjQRQROJMmSfWt = pufYeXzMn;
    }

    return RsxZkPxzljgDCBOJ;
}

double VyTiFMqJZM::KNdQrjOWxJmiF(double EaxKkn, string VYfagqXO, bool lXTBSbXNpatM, string IFBIwxKYifvpv, double XqcFrovrMVhUWUX)
{
    double RDSAtZreZh = -258573.60781231924;
    string MGJWYqrut = string("fCKNhAOYFNaNEjetomvddysJGRCeCQTYHDFcgSyWHMgFkWCufHglmsOAjiDmsDScuwgvppVYkqFZVocjTuPxGxcYplGAtYPSlToDSQRldAaaoijljVbdRipFSEiirMjYTUWXyKSzGvhqameHxVrLPQfWbALXnLAwFtYdjQnHXkyrEDKiNZBwlrPNQehaprJPdkFSnCLVTyGCMaYZkDHQ");
    double SkPKEXKH = -303781.98823203245;
    double PaOiY = 758911.9266592294;
    bool FVqRcJxMmzg = false;
    bool jwrSWQKyIn = false;
    bool auQwr = false;
    int lthHkfK = 424720134;

    for (int SdZMoxAm = 1775228251; SdZMoxAm > 0; SdZMoxAm--) {
        FVqRcJxMmzg = ! FVqRcJxMmzg;
        IFBIwxKYifvpv = IFBIwxKYifvpv;
        XqcFrovrMVhUWUX = SkPKEXKH;
        lXTBSbXNpatM = ! auQwr;
        IFBIwxKYifvpv = VYfagqXO;
        EaxKkn *= RDSAtZreZh;
    }

    for (int reEFLaeF = 2092087875; reEFLaeF > 0; reEFLaeF--) {
        continue;
    }

    return PaOiY;
}

double VyTiFMqJZM::VIZJSZLhrS(bool VrKukxbxx, string uljYwEPoTd, double wnuYaa, string sdTSyCsJc, string euwBR)
{
    string bZFCbmKxzO = string("DDMUAihQhhcSiQoiRHcQicUNBSqsuFNYJDAZYUZFCXXqMVtxmMihDxFdBTlwlYDmsPIAkzkzHmuFPzWYLSNmAgQAZjyhsulNWsDZUQRHRYyzCJaPZfXZCIMSHfJwMIPtkIUAikqTemINhFbEPDQgdcbpFYkBT");
    string TamYlLxXzFkJ = string("OybNizRcIeBYUAUTgmxHREMdNpomfvnfIGJbNsySWHmqhDLltOnDNGSTOdZuhCNdRIhGmIPDztHgklzJkPEByxUGBYXPXErGjyswkRgmZLydhLjXOtgAElbtcwKBcqMRbhkVGjIbekCeeLnlVvyGrHuceKZHuvzoPbArfLlVZAlnKvyWBKqFu");
    double KTOKOwgr = -156467.84417553645;
    double gnETnpk = -135006.35524805583;
    int TWLilOFcSHM = 1724972054;
    double uJuoCAr = -193291.70570214486;
    string hKlXzOifBEbiKx = string("wZlRtmQqzaceRGNWBmmeFZRQpiLaRUkzFnDwOatIbiDgtOksisUMBLMnkfISKQOHYJBtdXajBWWJPMjFfqPlqHNzxd");

    for (int zcmCOBKilSevPZ = 2029671961; zcmCOBKilSevPZ > 0; zcmCOBKilSevPZ--) {
        continue;
    }

    for (int Zixua = 1160593285; Zixua > 0; Zixua--) {
        wnuYaa -= uJuoCAr;
        TamYlLxXzFkJ = uljYwEPoTd;
    }

    return uJuoCAr;
}

VyTiFMqJZM::VyTiFMqJZM()
{
    this->GHZQrCXwyb(true, -876691.8715480618, string("qhAbGdHZOoaiQQkwkbvRAWIJJmIBvfnMoCsJDkzdmitnmptNmXVxOEIATIQuqLlL"), true, -378764966);
    this->SXsuAYuUOeY(476035902, string("wcwpQftxBeSQPCaKUOYkyjZLKqdVwYmWlIEqlEEAFokeWgEkPZrtolZgVBYOwxMmwojmoUzXddtfsxxgcivxkytEOxozYAqyABNbZLlYxCkqtxceBmEtFnsApDPKdXYFLjkdjdDcRIGHkPWJmKLzXTklQVPpFWVVnaUogqwJfMthUMJdKgCMJRbXUiDpLLBBQjcNeAtALmf"), -669475.2065816692);
    this->dhVqLWOauTvIis(936715, true, 1733817469, 1661222081);
    this->LCCVTaGncha(617502.4921824803);
    this->bvWJy(string("oZvNzbwhLYDFfHRDIDmYfhMoqybzvVDbCzxVyeEocyACtYsRNKOxgBDuUexsVUlGMPkCWRzELHOJZOHPVuevrMZDILvHTxvOtazaurGOneXSLtcOUiNzbXzVxFZuFqjQcdZMkxOHUtALwazizsxrTfNPDBc"), true, 844942.7052540145, 361975.91670891846, string("ssDHgiCTYsYssOGXgOQIfwSuFDWjbEZXgiZOjK"));
    this->weOWg(606110.4633803262, 984614642, false, -869258.1914333854, 1515490174);
    this->VJFkgNHdXCVOyccF();
    this->YnBrtxjAlJFP();
    this->BCZzwA(string("NjpEOLvVKxzjdMZpeleuyhEXcImKKjKDfgfeiuZkQMlNumtYNQwiqtjhRDTHIkvoqdCNkHmwYUSRHCyBpuHDTgQttJckNHlSWLauMLUwjelOmmBNiEsacDOQTgqLRXKzLFpJUZViCdTlcylIBrmXxKbxzqRwpwhjOohTZqzrDXnIhSxUhDdKapukMrhHIFCoWWDnETsXh"), -184715529, true, false);
    this->KNdQrjOWxJmiF(1259.3692011717462, string("ZJiKGj"), false, string("jGpqsUeUjlkEfGWHsEUsjtNfymFnCvMeQMTJikEWxunjPdJWMQiREExxkeKZJDWtLWSTzcpeAQuQXoIQzpzcCtVKKxtNVLwKFzJBbzGEIXnvEtSQPoWJjzuxrCBSLXgQJdZpSeLgXbXJDF"), 423552.0135423544);
    this->VIZJSZLhrS(false, string("mbZGEUuLTkgCNiqSzcn"), 586001.1161554167, string("ZCVtihRGqIaCWSxpuEHPrlMtzmzhauTyyceICcVtMEbdzAdvdUEgzDeCALDJPLHZIBNSHMBDTkbHiLqzVCgFPKIEBBzrPxtTxXKDpgoVUZhAjBmaHVesgmOBVxVISioNPxBeqfMepNNCXHFGJQSEFUsAOAMHtHVOQmSEcvWQrSxVjJkinVqGNqfBkR"), string("lEOrKEzPOmODCNbbOELqSeSoEbQnBlCTpXVzNTrNtFFNMBINpMMIEedJvQRhsnevOgdASSHzflXZxZPNIMWLLLfpVGnEdvCyNVWzqjxThipeAoRElwStKkVBctlBkwWxvOJBFMNCXzVZvwTIRNfHaHVmujwWPQChHyWITaSalyICvAMPlwPEuHcBbFJRpfMHULyQqiCtHShgdTSReUDlvUP"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class FwIuK
{
public:
    bool IKMMQF;
    double sgHVu;
    int jvPIZrm;
    string rsWrkVcdFZfeUs;

    FwIuK();
    string JpFphVrmpraAB(double yuHzWNjYHUFA, bool AjMqlCnLzgqc, bool pyQQAzOpByvLkOin);
    string muWPLWRqSR(bool umMgTBiFmqnPs, double cqzbqxO);
    void elICIvRqfevui();
    double sfcojZcTaaQBt(double EUUHy, double IatcZRYa, bool uUuGR, double QfSvzCydGx, bool SkEgcmEsAEvEAaVv);
    bool goOXfrbvOdrIKd(int RImnm, int MBpXS, int ZPUKX, double jItZWPvucNvTb, string TcyyjIQvveL);
    string yrzbKXgggZkt(bool kCdXjF, int hvONK, string dwWWkPcgBgHMwegn, double ZcYmnBPnoXCR);
    bool RyJjlGNRDNGAY();
    void OriFhpeuhdgrRzNt(double NxrljcllIscHTP, int BNmEwEwu, string GcRcCb);
protected:
    int HqzpfHfJORNXuL;
    bool QwOFLYitjpzxGlf;
    bool QsAefkXWlY;
    double HOuCDOE;
    double pDqlumPJOHF;

    bool DwlEdJAe(string ivyWbpeJEzlCn, int MSUNfBbRYJOepG, int gxThnP);
    double AKqQNaQA(string nfVEsE, double lDQTpvrGr);
private:
    double dREVCL;

    void csJgMuvx(double GLLaFOuDofhYUIVN, bool RfpHZxSSvD);
    void ZYMiQhtaj(bool ewjIOZBS);
    bool WTnWwiTNUJxku(int VdRaBGzYXkYJPfzg, string PwsCwtuEEsCrNjxy, double CtaLDZPVG, double MAdgiXtGpfwiXD, string OjgCURvKogy);
    string DkUqqQEwde(double NAfSXVoHcLSCvG, double ijdhdapmsoYQ, bool RaycGxOwELOGAXk, bool hFQPBBTMbhDlxZ);
};

string FwIuK::JpFphVrmpraAB(double yuHzWNjYHUFA, bool AjMqlCnLzgqc, bool pyQQAzOpByvLkOin)
{
    int FtXQhPfjhVyz = 1313248611;
    double EwAOEVUfQlpvEy = 180891.1054806342;
    int cjWkrGIN = 980180996;
    bool wgKykqz = true;
    int xAsXFTOMVevFWvje = -1604652426;

    for (int lFbXsRQEAFCL = 384749445; lFbXsRQEAFCL > 0; lFbXsRQEAFCL--) {
        pyQQAzOpByvLkOin = ! wgKykqz;
        pyQQAzOpByvLkOin = wgKykqz;
        wgKykqz = AjMqlCnLzgqc;
    }

    if (wgKykqz == true) {
        for (int tWygRsN = 933647994; tWygRsN > 0; tWygRsN--) {
            pyQQAzOpByvLkOin = ! pyQQAzOpByvLkOin;
            yuHzWNjYHUFA /= yuHzWNjYHUFA;
            xAsXFTOMVevFWvje -= xAsXFTOMVevFWvje;
            cjWkrGIN -= cjWkrGIN;
        }
    }

    if (cjWkrGIN > -1604652426) {
        for (int aUlUwtQQFkjmuip = 400776871; aUlUwtQQFkjmuip > 0; aUlUwtQQFkjmuip--) {
            FtXQhPfjhVyz -= xAsXFTOMVevFWvje;
        }
    }

    return string("MtAREgeGntjTOgCTbZllQAGiRNAwsLLYMNewfzsVkbmYMnPtBNqDqvNAbaCTfHGJJMVvMjbXaLmY");
}

string FwIuK::muWPLWRqSR(bool umMgTBiFmqnPs, double cqzbqxO)
{
    bool vhkvveeDr = true;
    double IZghjwSgEuOto = 736930.7133299517;
    string cnGyNNhx = string("SbvNpwHMMgsxHHPcQOAqIkusVBQARNlHkJPGmDxdxdTgWcowlvFORkcwkLddoaMgpHiCLQUmADDcvcEJsDtGFOxcEebeJsVYHBdTBiwYJQXBHZdbLqxpkuqvhWPgHOoxqsjmQrkhMnvdjXRRxnVlgdzgxzDzjKwgJBYLEAaZCTEiWbWPFYutieTZrcbRYXRlPR");
    bool pfmvNkKn = true;
    bool qQiHIDk = true;
    int fCAoaGY = -1287209774;
    string lCyAHt = string("ASnIuMNCPGpPbazukRfYmkzCylKVWLfpjbVccjXynXOrFxGQboCUqABStJJsfgOieMDrAZHGnBwyEXmjHFZDsufFxZsEFqxixZtmmfsWdIVGDihJtejHvbKtrORTGCsXngAjkTozNmMj");
    bool PLsQYWdv = true;
    int pXlXQN = 694742902;
    double JYHXWvfuMZ = -25947.430557698543;

    for (int PIdIHXoIrXvcjWGU = 1402359629; PIdIHXoIrXvcjWGU > 0; PIdIHXoIrXvcjWGU--) {
        cqzbqxO *= JYHXWvfuMZ;
    }

    if (JYHXWvfuMZ < 867734.8641807656) {
        for (int JplIMf = 210750771; JplIMf > 0; JplIMf--) {
            continue;
        }
    }

    return lCyAHt;
}

void FwIuK::elICIvRqfevui()
{
    int ZELRUujKDQI = 1787275415;
    double cdUECPDNyoxxZP = 986790.5743673621;
    int ZhGlEknqXwnbmDKc = -326335879;
    int phQUNIZwpZmMtkB = 791589363;
    bool ksyJvcMpsEbR = true;
    string iaDGIWksmqyVP = string("vueQHBtjkucaaWDNOsCBUGJrpHyEcnXkLKHNJsZObDchScoquSJRdLIcfWhHkqxqElBwBbWMaZZaIjZaHprJxgbxCPFUYxEPthTdGDGjyxZFfluRgnJAbfdYiWsTVhsOAfTwhQKYZPAorVkOPRMihumUuDfFYmW");
    bool GnGaYR = true;
    bool TacFYfAoyQqjtH = true;
    string YNAtDyV = string("fejnSjYAjxjYxOCXgqAEjnfTWBXVmOqbbejabPNahyPYcjqDJFSCXtgoXiEqCnoAksIjxDQOZKzkEBCUGoOawWTAZOoIylUGhJniDojXTAimYKSpLwJjPsuEMFSqRHOpQWJnnJUhpkQokfueZnOekJJPhDBjlXMGgfBb");
    string yZnUHUSKRNh = string("TTVraPodBzcSWufVXROoDShZuxMghCIoEBDdvoGtkjicYCSOpGzDHSXNHEMblNjnCeBLXNztBwuyEaNjbXBNdfvhrCRLoWVPMYNacADRgJNbzgspDlNjFUySIctFmdSgIEZcrCXMOjGrsZTDwxCHtkRljdqmlgbsFwZEfTtwGWKEAuoqUXKoxxRgfhUXMKirTlyQhZCbRjcbvNauDwRLahIkcXYIZvxYUrnrxkUiDEzyqstfEbjVidKTE");

    for (int BJISTWW = 634632990; BJISTWW > 0; BJISTWW--) {
        ZhGlEknqXwnbmDKc -= ZhGlEknqXwnbmDKc;
        ksyJvcMpsEbR = TacFYfAoyQqjtH;
        GnGaYR = ! ksyJvcMpsEbR;
        TacFYfAoyQqjtH = GnGaYR;
    }

    for (int zTUBdOEHDDgg = 1640349558; zTUBdOEHDDgg > 0; zTUBdOEHDDgg--) {
        continue;
    }

    if (GnGaYR == true) {
        for (int CvQvhZGbfpgKVWbL = 1176803801; CvQvhZGbfpgKVWbL > 0; CvQvhZGbfpgKVWbL--) {
            ZELRUujKDQI = ZELRUujKDQI;
            GnGaYR = ! GnGaYR;
        }
    }
}

double FwIuK::sfcojZcTaaQBt(double EUUHy, double IatcZRYa, bool uUuGR, double QfSvzCydGx, bool SkEgcmEsAEvEAaVv)
{
    double rJWvanKI = -421874.8939873116;
    int SWzKtAsMORD = -96186317;
    double XuCGbeJKbwwoih = 549781.1900485052;
    int MZjPNpMjjwbEwOpE = 1269473526;
    int UvqVnrRzZd = -632932413;
    string yqxXTqEB = string("eUdVFqmyfksiSwqNFwfeOzuswKTfyyHjasZTdAcnsyHMEyKvXonJhIgDYRPfItDuoVFHsTfpnYtcjUyCevcTuqleeKCupTQpIOpHaCmqWvtlzdspWDqXaLVQXrvELMWRpnkQXFNKrhklLOkgrEWagWRnclgEXNdEAYMZrcSaHehMgQlvDachueehmUUmSCCjKEiYcWrvzehwNonUWvSHV");
    bool RLlwMIIaHYJKFSU = false;

    for (int PZBmBbWC = 1993393044; PZBmBbWC > 0; PZBmBbWC--) {
        XuCGbeJKbwwoih += QfSvzCydGx;
        IatcZRYa += IatcZRYa;
        XuCGbeJKbwwoih /= IatcZRYa;
    }

    for (int dICCQOqJWV = 646450356; dICCQOqJWV > 0; dICCQOqJWV--) {
        continue;
    }

    return XuCGbeJKbwwoih;
}

bool FwIuK::goOXfrbvOdrIKd(int RImnm, int MBpXS, int ZPUKX, double jItZWPvucNvTb, string TcyyjIQvveL)
{
    bool diIveKngM = false;
    int DrEmVawtdJ = 508241088;
    double TUdwiGFXALcr = 501873.07856225746;

    for (int ecjUIapRbwJHWk = 832457783; ecjUIapRbwJHWk > 0; ecjUIapRbwJHWk--) {
        ZPUKX = RImnm;
        DrEmVawtdJ *= RImnm;
    }

    return diIveKngM;
}

string FwIuK::yrzbKXgggZkt(bool kCdXjF, int hvONK, string dwWWkPcgBgHMwegn, double ZcYmnBPnoXCR)
{
    string asghYQEfoPzqLnVe = string("LHwtolsxSaCMISCaJoQHIFMfhQPkyQklCJiKgjRCIQylRHzbwVxHvDYjkVxSAfzQforOAJuPPNoRAlXfMDKMpYVeTnoYpVdMrlD");
    int SvcBvsrrFIpA = 1882796496;

    if (SvcBvsrrFIpA != 1882796496) {
        for (int eRbvIKzBzVuTwy = 724860108; eRbvIKzBzVuTwy > 0; eRbvIKzBzVuTwy--) {
            kCdXjF = ! kCdXjF;
            kCdXjF = kCdXjF;
            hvONK /= SvcBvsrrFIpA;
            hvONK += SvcBvsrrFIpA;
        }
    }

    for (int lZsXj = 205349601; lZsXj > 0; lZsXj--) {
        hvONK -= hvONK;
        asghYQEfoPzqLnVe = asghYQEfoPzqLnVe;
    }

    if (asghYQEfoPzqLnVe <= string("LHwtolsxSaCMISCaJoQHIFMfhQPkyQklCJiKgjRCIQylRHzbwVxHvDYjkVxSAfzQforOAJuPPNoRAlXfMDKMpYVeTnoYpVdMrlD")) {
        for (int mnteCVq = 667355385; mnteCVq > 0; mnteCVq--) {
            SvcBvsrrFIpA += hvONK;
            kCdXjF = kCdXjF;
        }
    }

    return asghYQEfoPzqLnVe;
}

bool FwIuK::RyJjlGNRDNGAY()
{
    string iVDMVyZjnpqm = string("GOZWoWQJwIGvGMrAZcpjKzCuUoGcxDbXrXfiqBayjJBzcsurolCDopeLobLSmeBjWCFQZPvVSySjyhDLtmBlWCitfXSROKEmEaEixoPznPvpeIPCavCbHFJYBOsrRXAKSRARCGhOjSWoDhrCbGYJVNPycYTNFMPUBVILJENWANGLagZaQUj");
    int nGUgmZUrODBsJaR = 224570190;
    string xyUImaczLtSHA = string("FGxEOuWJYHmTCdltKnLakbiIhmdzmfcgqeVBgOWjzGxYLDNrSxJwtTYGedSTdwzAAuWaOOAMEZvBRMtuvOueAvlbDkKbHHEddWjInWAiLzgLmEhYzh");
    double ADtjbxUHynnoOS = 51362.942997971026;
    string iyNXyElILspcuvc = string("pLrpvEpIfCQgPJJzUDvUejrtsiugOfGHeaqniVcfjBzyCXzkXCRRVZNClnqiOFvEfnpRaJysRKSILFccuLGDzNrAHGKjbOZhrVTDqBguAhCiROdNNSdlnYnMyncvOkoEqqvOZOUPODJiSiOaTkFVxZeZQQuHlbIvZKcXILFnWOIFWKmNPUwPpampcnytSRKzwIgVQOQYtocayYRufJvugnkmnUocBPyyQwGQKeplCxaocBmoWOzatl");
    int aTmHVaAbMzRfNGTM = 1181134360;

    return true;
}

void FwIuK::OriFhpeuhdgrRzNt(double NxrljcllIscHTP, int BNmEwEwu, string GcRcCb)
{
    double pAsbfqnTK = 245129.0444635448;
    bool oatfclbkSt = true;
    bool cpPlYJhbl = true;
    bool lNxoAWzgjXkdQz = true;
    bool wwEiSuZjL = true;

    for (int sheItVS = 1790797045; sheItVS > 0; sheItVS--) {
        lNxoAWzgjXkdQz = ! lNxoAWzgjXkdQz;
    }

    for (int kjEYzCgonb = 1920021512; kjEYzCgonb > 0; kjEYzCgonb--) {
        wwEiSuZjL = ! cpPlYJhbl;
        NxrljcllIscHTP *= NxrljcllIscHTP;
        NxrljcllIscHTP /= pAsbfqnTK;
        wwEiSuZjL = oatfclbkSt;
    }

    for (int lKKdCNjDsAhFHFUY = 2035632805; lKKdCNjDsAhFHFUY > 0; lKKdCNjDsAhFHFUY--) {
        BNmEwEwu += BNmEwEwu;
        wwEiSuZjL = ! lNxoAWzgjXkdQz;
        oatfclbkSt = ! lNxoAWzgjXkdQz;
        NxrljcllIscHTP += NxrljcllIscHTP;
    }
}

bool FwIuK::DwlEdJAe(string ivyWbpeJEzlCn, int MSUNfBbRYJOepG, int gxThnP)
{
    string CtfDuRcsICJFH = string("CBUqpprtHnPZrebDPzJOOUsXOoEkxgqBnPaNmiFehhVRPRESkcbJnmKTOisllWbXtguhJenbKQZNkxflSLwbZNGipvMIhsXZKpfdHXVwjaFlnYbOyAyvexGjSVOMupGpgev");
    int OGpHSPdkpd = 1222112301;
    double DFFgc = -127488.2519273573;
    string byhDUyZYUfVbdu = string("lawLQxIxqyGxcRLbxTtIpYBwloegEAITBSHFYovjZjIsWdEZZnbUhmuyvSOsMwkGcboJVMhMEeSTFNWrdUcC");
    double ynwqW = -139108.50580933705;
    int iOnTJCsLK = -258088819;
    double hlBLPOnSoTLLloAJ = 1006297.1232694605;

    return true;
}

double FwIuK::AKqQNaQA(string nfVEsE, double lDQTpvrGr)
{
    bool OuREnYMTJVC = true;
    double EPtavsioierQ = 403957.3197609903;
    double zcRfVHIRpKNYM = 958681.5046390442;
    string AQKnNRplwKP = string("bFtWdjVxUNUZDmpKHmGFYvelvhkloJnlDNFBVYCJCilXVbrWIUDPcmKgLIRvStZQHvvcDbrNGpWkVkTFxdYbpJuCaHtiEPiYoUXcvisvGvjJTuNbqFfjftZRuWUBODfRREyUHfakKGSwgSAMAgOUWXZnBGivXJOnSjWRwhpujQkBOiPf");
    double MfRltLNhmOgd = -320478.896579071;
    int lbzIihhDUVAbyD = 1739388177;
    int wAhGkaFBI = 1503185201;
    double FwtEnLy = 1028438.8253932497;
    int sPVSviTNkXr = 929397564;

    for (int fCLBVa = 285347617; fCLBVa > 0; fCLBVa--) {
        zcRfVHIRpKNYM /= zcRfVHIRpKNYM;
        FwtEnLy *= FwtEnLy;
        MfRltLNhmOgd = MfRltLNhmOgd;
        EPtavsioierQ *= zcRfVHIRpKNYM;
        EPtavsioierQ = zcRfVHIRpKNYM;
    }

    for (int zfGCEhAO = 963716055; zfGCEhAO > 0; zfGCEhAO--) {
        EPtavsioierQ = EPtavsioierQ;
        MfRltLNhmOgd *= FwtEnLy;
    }

    return FwtEnLy;
}

void FwIuK::csJgMuvx(double GLLaFOuDofhYUIVN, bool RfpHZxSSvD)
{
    string XKxGWyorZnQJmVP = string("nmgecOXNcFgClXkXbgScAwllOzYZaVYossEEWPYOHcENcZxLgogQHLbEpRfPbvZhxqBxgOIgdXfNbhBRvnNjYNGFAqZBWOYEFBHACIbJlgHilsoMlZtkyBnJVdvIvD");
    int hgTtqE = -2046944636;

    for (int VFmHjsDAlmzFM = 1919905655; VFmHjsDAlmzFM > 0; VFmHjsDAlmzFM--) {
        XKxGWyorZnQJmVP = XKxGWyorZnQJmVP;
        XKxGWyorZnQJmVP += XKxGWyorZnQJmVP;
    }

    for (int RMzOvWgIqJKpzZC = 1231362982; RMzOvWgIqJKpzZC > 0; RMzOvWgIqJKpzZC--) {
        hgTtqE /= hgTtqE;
        hgTtqE += hgTtqE;
        hgTtqE = hgTtqE;
    }

    if (GLLaFOuDofhYUIVN < -158453.47514764924) {
        for (int OoLUA = 551324894; OoLUA > 0; OoLUA--) {
            RfpHZxSSvD = ! RfpHZxSSvD;
        }
    }
}

void FwIuK::ZYMiQhtaj(bool ewjIOZBS)
{
    int oYxmReBJLjqTZ = -226941073;
    string vJzrsWcbOTCo = string("hnesvLsKKjDPOQwjwSzlxuUkELoRinxAwej");

    if (oYxmReBJLjqTZ >= -226941073) {
        for (int DmDvFPC = 796304767; DmDvFPC > 0; DmDvFPC--) {
            oYxmReBJLjqTZ -= oYxmReBJLjqTZ;
            oYxmReBJLjqTZ *= oYxmReBJLjqTZ;
        }
    }

    for (int WkwPzgUT = 1168205356; WkwPzgUT > 0; WkwPzgUT--) {
        vJzrsWcbOTCo = vJzrsWcbOTCo;
    }

    if (vJzrsWcbOTCo <= string("hnesvLsKKjDPOQwjwSzlxuUkELoRinxAwej")) {
        for (int HsJQNTqAQtloBG = 1321666636; HsJQNTqAQtloBG > 0; HsJQNTqAQtloBG--) {
            vJzrsWcbOTCo += vJzrsWcbOTCo;
        }
    }
}

bool FwIuK::WTnWwiTNUJxku(int VdRaBGzYXkYJPfzg, string PwsCwtuEEsCrNjxy, double CtaLDZPVG, double MAdgiXtGpfwiXD, string OjgCURvKogy)
{
    string EisBo = string("bqtiBZKCsIYjbFqrJfHPwgMcDAaxxUTzqKBJsAMaygpjKuFFyonxjMyXXMjKrPEjaCrzMOyONBXShQLeBkRzMYKqKYEnnPeMubuYJluusnTYxTMbfahVws");
    int TiwDkE = -284401147;
    string tRsgl = string("lOmdQhSblGldMIMekYvrBjKSbtLQWiSuRnwNbEleAHdOeWlmxLevySwyexcPyteorjJxVKbeBNQQmldfEdOqqQbbvsvIbaCuEwDmRovOYAXlAuYujAwdgNnExiVNJoocvykhFZExPrvLgxwSBqAyCmdFKh");
    string ENpnrjtnHCusf = string("TyAIgMgHhBHFdUvaUrfLsDTSaFSEPsEWCwvqfmBGVektbFqkLujPrWHxTMiwNncPBGaMxAsjHaVZiDHGOlOgIsloWgKgfvqspnIPUegaRgVlbJuDMTlCGzkUPZmMbplhQlMldmjZTGQiBUfJvhwrkLdNcvCNFCtifSkEgQTxzvngTDZkwlCWDZZPXtywLDyd");
    bool enEouOo = false;
    double Hyfua = 708883.8484203235;
    string jUekpFvU = string("uMuhjCgztoPrXAxrKmZZLXMlwPHRPUvoMFAKQfGGzOawwpThMWAvxfuOlpuDSnOyHJRkGLXGHcvyrgxLlqobkLSwoMAOnGMCTzKnNQzmZmwiGUfdSlTKmwSitavwzhkvYUDNIHLkKlNQtBKyuFoQZuvnuYRtQIuSvWZNPVvtTqZpJqfJnpJyMYfqoEOuvhcBhdDnLMSHloImZhkVkuWleDEKJBENhZYDoFatrPFC");
    int ikQGkKfutGTvF = 2061779700;

    for (int uivRWaxpd = 814833576; uivRWaxpd > 0; uivRWaxpd--) {
        Hyfua = Hyfua;
        tRsgl += OjgCURvKogy;
        jUekpFvU += jUekpFvU;
        OjgCURvKogy = jUekpFvU;
    }

    if (ikQGkKfutGTvF > -284401147) {
        for (int OQeAIHu = 1191287257; OQeAIHu > 0; OQeAIHu--) {
            PwsCwtuEEsCrNjxy += jUekpFvU;
            ikQGkKfutGTvF = TiwDkE;
        }
    }

    if (jUekpFvU > string("TyAIgMgHhBHFdUvaUrfLsDTSaFSEPsEWCwvqfmBGVektbFqkLujPrWHxTMiwNncPBGaMxAsjHaVZiDHGOlOgIsloWgKgfvqspnIPUegaRgVlbJuDMTlCGzkUPZmMbplhQlMldmjZTGQiBUfJvhwrkLdNcvCNFCtifSkEgQTxzvngTDZkwlCWDZZPXtywLDyd")) {
        for (int BoyGYBDrcQuc = 551856174; BoyGYBDrcQuc > 0; BoyGYBDrcQuc--) {
            ENpnrjtnHCusf = tRsgl;
            ENpnrjtnHCusf = OjgCURvKogy;
        }
    }

    for (int ZbZLjoYgQt = 976494146; ZbZLjoYgQt > 0; ZbZLjoYgQt--) {
        CtaLDZPVG = CtaLDZPVG;
        jUekpFvU += PwsCwtuEEsCrNjxy;
    }

    return enEouOo;
}

string FwIuK::DkUqqQEwde(double NAfSXVoHcLSCvG, double ijdhdapmsoYQ, bool RaycGxOwELOGAXk, bool hFQPBBTMbhDlxZ)
{
    int CksqorLZ = 1370300210;
    double lGKrcVPHRgxSYIYJ = 1008851.1163864511;
    int OwxDQzVNPrjrWK = -615101635;
    bool brQuSFfdvT = false;
    bool KKtJDigza = false;
    double yxPXxECvuWaXRb = -1019977.4281334379;

    for (int pVVLcwQTZpDIxONM = 1376894004; pVVLcwQTZpDIxONM > 0; pVVLcwQTZpDIxONM--) {
        ijdhdapmsoYQ -= yxPXxECvuWaXRb;
        hFQPBBTMbhDlxZ = KKtJDigza;
    }

    for (int tJgYkBcRtkD = 355687740; tJgYkBcRtkD > 0; tJgYkBcRtkD--) {
        hFQPBBTMbhDlxZ = hFQPBBTMbhDlxZ;
        RaycGxOwELOGAXk = ! KKtJDigza;
    }

    return string("dmpnvWCZxVWfGeqNkgneCdIMrNxPqyjNpdbQlAhjqXHWrRwEHoAArWXuydlRCnHQJMSXEQxmLfFDrlwXkAGJQQznVHaGDKoeOavloLHRkDHwvsTLSBMTubumJHngZTECdRDv");
}

FwIuK::FwIuK()
{
    this->JpFphVrmpraAB(-1039388.5958162678, false, true);
    this->muWPLWRqSR(true, 867734.8641807656);
    this->elICIvRqfevui();
    this->sfcojZcTaaQBt(10583.482410977549, 745558.7654511803, true, -202784.66949818144, false);
    this->goOXfrbvOdrIKd(-1393910391, -1269369567, -542147693, -959262.024385186, string("OfCyiGYVtiPkQefbioChNulfnZpykKbiHiGWpNMsNHZKlTtEtFAiSoCzknegoaEKFRCtkDDhMphkMAUIwneJIEoUiRIZteVcnZnaJxqbZniCsOIUEwBkFtsfLgWxhUhHrMRKTPWEKPonpJmMaeKiokhfbueGTlFfMdIavUQrNlPomsuuvoavAfUPPZfsopEltTocnYZMgYZEIabomgAoWDIBIZFdEACVLkOAMWWIIcuplSMAITHxAsrUcNkuVzY"));
    this->yrzbKXgggZkt(false, 5299645, string("ATQlnUtFBDEvoVxAzOVlKBwoaAukAfeIwBzgBGZsJROxSoTwbxLOzUQjJOjKYFdubOBytaHcmRQwCuuNUtspyHXDMDqNVeOUnJHSRSSsQbrApzSOqfVXBumTUtVdPseJZqLGlvrNWUFPjkRoTZkvZXQHdNBfwUojJGIAkBpgSFFxmizhAWRazvQWJWJGllZnJjGuMI"), 729528.7506428793);
    this->RyJjlGNRDNGAY();
    this->OriFhpeuhdgrRzNt(723770.768802226, -1873042457, string("MKMQfMybbwLLgivSxVAAPmobxReJJoDmMibLaNsJGGjrBkCyWYnwXQrBFjqpouzNOwZagVlqXdohBCMKtgogiUnZysmsdFhqsmaWkRRqYJlpPOOBNlbsVTKNrIIFxdmpxxMannEdJatyCjATbZnppIOojZSHghgtNjNjeWkmdQV"));
    this->DwlEdJAe(string("qCkGpMDBxhIWjlmqIHLPUaRJamGShDvbiCBlNDCzlICgcHLXjoewfrosgMBNXgVutZXjGZ"), 1186112515, 786362904);
    this->AKqQNaQA(string("fPoPimmIcyvywkTViMGwKfgnfzQAEUtOUEVxOLIBzJLBPXxyLnONSxlJudfXrlaiqXAlkJWEstYMYRNrEvUNlURVideQVlHntalqXJnYKKstzwUatFIGQcNgNylPaAfKVYwYuxBqMgqoDauQwBOuwydhIiZNMhcXhSLghEswlwRwnbkTBZuDYAXOxLASHozdXeoHKpRp"), -903213.4901789774);
    this->csJgMuvx(-158453.47514764924, true);
    this->ZYMiQhtaj(false);
    this->WTnWwiTNUJxku(1984422464, string("RuQXtTJSNlPwDOWQufBBaZmCXlTdBiwitVSWHhzliEvpTrbVDxQRAKYYEfprbWJlmPyPSyyQTFEiTTNrNBLiqxGjebINmEPHFozgngjpXlWLsHknvSxypvNqOMBzSrryMJAMZmUAhLVRbrRLIvILfLYXpOFKPjZyjSTSfbqtCffkeSdKVwHfGfrwgmFwsEfhBrnXAtOslLY"), 126266.75258111073, 824505.1297501789, string("BcYCvfgYVrmUFiMRjqiVEjmfBynpsMMNSWkHpUghjMzuvWBxxwTBaCUwybPRZpTGoOgWJNmVKLEtePvYWiEEtcGheILFrEJHyFGcbzsxUydwbYsfYNEPrKUsbvjSxtSVpUiXqACFkEHXmodHwaEwQXUwPOytZGQz"));
    this->DkUqqQEwde(-877654.7757578931, -86125.61305955985, false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class GAAHRSPrQixWV
{
public:
    double JCyQh;
    bool cSJqgwoKZbzlJ;
    bool DKDbIDbMUxZcp;
    double UdmoUFGfl;

    GAAHRSPrQixWV();
    string LuwFGRpEHtSvr();
    double TRORCMQnZW(int RWljfDIkDv);
protected:
    string AJvWoouHkXVHmSVI;
    string mZIWeHOHUYkED;
    string hHOZOoD;

private:
    double hpFJlJLrU;
    string KhBIkGeC;
    int KlYiLWV;
    int uLCcuXmxra;

    bool xCULYTtWpEwzTtgg(string NVJEKBYqee);
    double tNTNTEOLfUEVjRzn(int jxwpGONxdyQzIY, bool PohiT, int ILGHhkCKMTDhIMl, double VudHMJxibfJaIIz, double KEBIFcVoJmbqZdE);
    string KBRWm(int gULWyXfIgrRGEh, double FSBfkLglGAXFv, int qwUWf, bool fwqWmW, double cUPgon);
    double IqZvhqMSAnSQ(string eViHMcFXwzEdXFN, double BWNvtiHvyY);
    int DuxUFDed(string aRyVqB, bool ZLNxrmUxMoKZAI);
};

string GAAHRSPrQixWV::LuwFGRpEHtSvr()
{
    double lWlrwUPYb = -349836.7891061364;
    string ACJpqv = string("wIXlfSZvowRnUgACUGAKOqznzWRcadqGfbohiRfQubrICLMkRxpFpbyOUxPhHNvmDJduP");
    int wDFmOxAqDcJwT = 1834726988;
    bool NzDwMHPZvMqOf = true;
    string XROcVBaiTz = string("CcCJcnHoXZiQwIGpEKZgFXjdQzttNWHXWvDpEDgiRTIHugBGxPiBHRQJFUfpbGLDvHQCVsLAgJ");
    int qYKAsD = -790122292;
    string FkGeDSBqvW = string("GOUvVIwqIzlrXxOZoRfedUKGVSYCugcIDCdguXCPdiwImXhLBXhinfDvzVpwEhYPqWIbXEUmMQxyIwQBDrkeDeiQQxaQBSeZhNVWkxzKbCyDnpeVzCMFwqurvTEAPBtLPamGMThXZtezrDjVoxDHO");
    double ThaRY = -61378.72570566996;
    bool lvtHk = true;

    for (int GGtXqI = 98685026; GGtXqI > 0; GGtXqI--) {
        qYKAsD = wDFmOxAqDcJwT;
    }

    return FkGeDSBqvW;
}

double GAAHRSPrQixWV::TRORCMQnZW(int RWljfDIkDv)
{
    bool vWiNVfX = false;
    double KOOCvKwlE = 299602.8866796885;
    double mVkYvsXNtp = 420253.9862113366;
    bool gXqItPyPXT = true;
    int IAOegbZzHZH = -949439321;
    int MxkcFT = 1973974179;
    int cJOZJkjz = 539173827;
    double mLpDWmRs = 478052.8896858346;
    double OXAxvaK = -875197.5469831778;
    int fKbdpswu = -1729596900;

    for (int ycgRAkPBfuUEUxr = 82885466; ycgRAkPBfuUEUxr > 0; ycgRAkPBfuUEUxr--) {
        continue;
    }

    for (int YAedcAQh = 1992974110; YAedcAQh > 0; YAedcAQh--) {
        mVkYvsXNtp -= OXAxvaK;
        MxkcFT = RWljfDIkDv;
    }

    return OXAxvaK;
}

bool GAAHRSPrQixWV::xCULYTtWpEwzTtgg(string NVJEKBYqee)
{
    bool VnxaBREVEgBjQX = true;
    string OQUIVpvSb = string("SRozaFqLFKFAeFoLdckMCDTDEXsUzTxZFryzfSABnfMmwjmTzfoCBfSdOyeZSHWgYdXPHIGoYWxLUeoltqBRiqkBmDAoxxcvueBHITHkKcFZzrtgorLmKPjPVOaFjxNAbybTUitvgVHNHJYYdGClUxyPbtOUCrvmdgbsGTHqDoPrGDsoRqUGuIZpeUaLiGjbQpQYbtNvNYXCrRKhrgEeFFNvpeYGstZoCYhITMrYvTPLWwQJSgLKaUuzvhzsi");

    if (VnxaBREVEgBjQX == true) {
        for (int koYLWaFY = 576119009; koYLWaFY > 0; koYLWaFY--) {
            OQUIVpvSb = OQUIVpvSb;
            NVJEKBYqee += NVJEKBYqee;
            NVJEKBYqee = OQUIVpvSb;
            NVJEKBYqee += OQUIVpvSb;
        }
    }

    return VnxaBREVEgBjQX;
}

double GAAHRSPrQixWV::tNTNTEOLfUEVjRzn(int jxwpGONxdyQzIY, bool PohiT, int ILGHhkCKMTDhIMl, double VudHMJxibfJaIIz, double KEBIFcVoJmbqZdE)
{
    bool FWSfwsWYtPSBgWv = true;
    string YnoIKaJSsjxkd = string("ExNRqwiwfRacFvItJGOoLEXKmupzcLOhRHQZAeEsPDQWQALnnqjhXaqoFGVwJOUpNpbyYbTB");
    int AfTNMpCjJj = 308278765;
    int njQEMNk = -2027186193;
    bool ZnjTJZQwPSHS = false;
    bool PvktRoaqzMvOc = true;

    return KEBIFcVoJmbqZdE;
}

string GAAHRSPrQixWV::KBRWm(int gULWyXfIgrRGEh, double FSBfkLglGAXFv, int qwUWf, bool fwqWmW, double cUPgon)
{
    bool ljjGJMDyF = true;
    string ychpFTnjo = string("KcslUjRonzEnEJyGgDvutlNBwlikyoGcQThgmvtGoEWJqAAopqfkhnKZuhzQrX");
    double NyuMr = 413162.26792910637;
    int hDCctWEWTyWDX = -530827256;
    int zHdzup = 305182134;
    double MHwomaBpOy = -478415.26767324144;
    int sfsORkRKlltmmM = -696598300;
    string XxJBKRgEbGACDZQ = string("HeahoutGHhOHyfwcshWUIribleDnSboarhCYTThAkreWnIvVyuStjlqrWykNGNmQCvfuAHkYKf");
    double twTJYVRCmrvv = -563457.2054977926;
    double iXUTCL = -78437.78119560062;

    for (int ysLzZyPhUTeKpMde = 153065194; ysLzZyPhUTeKpMde > 0; ysLzZyPhUTeKpMde--) {
        MHwomaBpOy /= twTJYVRCmrvv;
    }

    for (int VYdgGuGJwe = 871836301; VYdgGuGJwe > 0; VYdgGuGJwe--) {
        twTJYVRCmrvv /= MHwomaBpOy;
    }

    if (hDCctWEWTyWDX >= 305182134) {
        for (int fkRdl = 1825665231; fkRdl > 0; fkRdl--) {
            hDCctWEWTyWDX -= zHdzup;
            iXUTCL = NyuMr;
        }
    }

    for (int bLSLjqIi = 787474324; bLSLjqIi > 0; bLSLjqIi--) {
        XxJBKRgEbGACDZQ = ychpFTnjo;
    }

    if (iXUTCL == -397257.5231314758) {
        for (int eInVbBHOK = 66396334; eInVbBHOK > 0; eInVbBHOK--) {
            cUPgon = FSBfkLglGAXFv;
            twTJYVRCmrvv += MHwomaBpOy;
        }
    }

    return XxJBKRgEbGACDZQ;
}

double GAAHRSPrQixWV::IqZvhqMSAnSQ(string eViHMcFXwzEdXFN, double BWNvtiHvyY)
{
    int ugVeL = -290620084;
    bool DJCGqezr = true;
    bool vEyFhfYWxoqS = false;
    string ZcEOosGGLFa = string("ITqwLAFjdkEsLlpOdfEPjWsSglbnJQWseEifjadejanYHlSTyAzNnLxIUTZNicXkiEWCPeVFgYDKeOvNZvEPRLXEWQPJkoLxYGinLooXTPNmvZESEKafPNMgWpfYQPZIYcavNQ");
    string lKdaYZgREIOjUEan = string("zgYNOFDrwedECsPkRFgMYQcLpnngAPFvLmVAJZdcUVGVtLaSZWIoAZiJTahpldpBHYdcjlHMJDfoLJGsRYziQAJnYulkFthlqljHlZbQnLANxxCGkuATdgpWAJDFcZPOCzJVdUHadWUKaZSagzUfyPRTsCcNmedtcNsqNpaxpoiUpvTUlBxanTMKHancxHJhiiWYGX");
    string XLZwIc = string("OSypMLyVDGkIMuaybdNsvLxXZkaKfQZfoWITIYwJtCqSIkxryUwvvoikwilnvbpGJAhSIahtaZDKpBZsxbSWeITKhnidzapEiIZBFnlmbTbbaDgWqzAXnWQAgpcHPfpmtaljVZdlddfpUBtajCyiKxynRllUqzIVgGGryzAeeSLgVucrnAzheWFjZNesaLDhXxHVeTJyOfjJXSmektxFQCoiNRiewTnflONpghlnVJrqCV");
    bool IqeOKPlZ = false;
    double rCRMvtuJH = 792311.652269167;

    for (int NMoANdcqIu = 1754044296; NMoANdcqIu > 0; NMoANdcqIu--) {
        DJCGqezr = ! DJCGqezr;
        lKdaYZgREIOjUEan = ZcEOosGGLFa;
    }

    for (int ukTybwTl = 1840030077; ukTybwTl > 0; ukTybwTl--) {
        XLZwIc += eViHMcFXwzEdXFN;
    }

    return rCRMvtuJH;
}

int GAAHRSPrQixWV::DuxUFDed(string aRyVqB, bool ZLNxrmUxMoKZAI)
{
    string uEbigkmFtYaNXPw = string("xUimqvLDMyFwiKlNcZiWODzjaOsyaNHlTigibBqjaWZLNVwcenYWhvNCiyrURSWQwxnjtyazuHRJLaEAzzpxygwQPBgBzUaAsdRXhPZWGjXUZuItafykekBkVMGKYrRnHLQEWzGiawQhJiMpQkqOLZzmGnzSwCmLDBbTPgRHDvEhopgUiDhTzXqeZFwVJjdUqMYlAAeHaEnbxCgy");
    bool msajOZsBxzKl = true;
    int LzBHfzD = -1412642440;
    bool cMNiSH = false;
    string YppmuWKWrG = string("IrZCQPkayAiiSvHuejnfGGYyFVecKgdxpDKRmbqrjbJVyrErPPcYyRQunSBnpoRdqoqCIpHdznPKhgdqmyBcKbJvDXwkfBGzuaochFsjQlkosxZaXXdXoOHjAQOZMmMigaibZCJzeaWRVMUYLvpzPLimrIcqdR");
    string HxpyfCLpiRmHSJ = string("JaKsAkguV");
    double rteby = -378154.75961480784;
    double sGYrOTse = -426534.4999654069;
    bool jDfeUNdMrdYD = true;

    for (int nxHZJPfMe = 1642126331; nxHZJPfMe > 0; nxHZJPfMe--) {
        continue;
    }

    return LzBHfzD;
}

GAAHRSPrQixWV::GAAHRSPrQixWV()
{
    this->LuwFGRpEHtSvr();
    this->TRORCMQnZW(-929274306);
    this->xCULYTtWpEwzTtgg(string("qoTJoDBZUSFTJGieaxpwEajpwHEppbUGKwggNFjaVyWkvfWDaCzdBBcBhaaUtlJXJpBMHHkhuHDYlHNoUNJaOJQOFInwJAPypVvBhOhqGcsOOINvmspvHLKJefyZfDbxpfdbLPJDMDDywLCkgOjnckDuPHnmwlttLSyayvrXqZaBpTGFedwgsOXFspiaNsipppHHJweCoKxFEIfweheLVHgZLrrqnaoLjtOzuLlnkZDlV"));
    this->tNTNTEOLfUEVjRzn(1594643454, true, 133749629, -408628.5139922451, 146578.7099094625);
    this->KBRWm(-1239792973, -397257.5231314758, -1241652693, true, -495171.74613990827);
    this->IqZvhqMSAnSQ(string("CSgeZUTHBOSdBmofoxRDWjXKaYIPMECfuQTEYRgqJGYfxTloYGnSOuwkvmzUfPShWqdSRhjCHaizNgqawmPrgwScZfujDXostDKZlmDbBSGdSMfZCQxOYFLhAxKbUftRDFenVbILcQEHpbXSFRvmLjxBxUu"), 705638.6794227397);
    this->DuxUFDed(string("tPGssLCDDQAozngPGtBBqYcEIDKClMgaxYrRUxlmQoLNdPHutdxnYksYGEaphXbZbdeuchWFquScISHoQvHZmyzPAKccUxAaAEIkysTFAQFjwyOWzMsKbRfKiqtZyxjtYKjEZjNvnuxhBowjqmimGsoPhWJqakVceJaKiRcuSVUACC"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZbiBnSMc
{
public:
    int fLaWODLawMc;
    string wznkzjLxGyeHjBk;
    string YarJuHHM;

    ZbiBnSMc();
    bool mvuqoFHgtQXXaycU(bool EkyHgtCm, int AhfnxNLcBg, double unMuyXYZhrE, int mNKXisrkbMeMTEL);
protected:
    string OIMcrgeP;

    void oPnHEOtjnrpsto(bool MjfWznnGJcLHJIdk);
private:
    bool PqWqiqwJjU;

    double ErWBXiHpPBXRc(int irHPffVSAgYrnGoD, int KvFGnBpKQQOgk, double lpRKsPk, int QzjbsxNoaMoUce, bool ZMbjKQNuemCO);
    bool EeqaVAU(string SgwRXkACifNR, int erwIbEJTG, bool iuaCMocpjgnVd, bool dAIoLokVPW, string rascszO);
    void qBZxYjeKYfVKR(double YaOASZp, double pMenUbcWCFVVWi);
    bool CzcCNGmDFuu(int aMHfaLdjkmyrn, double wfpFLMHZlqrjZP, double iyYrTfMXs, int XYlkzv, double PheGUNMINNJEIrdW);
    string rYiFny(bool dOEYlUTqaKfYro);
};

bool ZbiBnSMc::mvuqoFHgtQXXaycU(bool EkyHgtCm, int AhfnxNLcBg, double unMuyXYZhrE, int mNKXisrkbMeMTEL)
{
    double mGYigzIQmkUhCTR = 469849.10485779424;
    string kiIUhEdob = string("OiUrSblHPxCytRKEgoHCYRDeTLBBmJgqDsfNZqmVezOXEcaKbKRVfZdhCYaANnACYrsKtGTFdocdIrVCTVhaXzBsQkeUzhBAaYdtXMlVLksxZBzxIKZtzIxQOVRfpEbZH");

    for (int LGIsbvyN = 1640788796; LGIsbvyN > 0; LGIsbvyN--) {
        continue;
    }

    for (int LdgwmKfx = 1911960632; LdgwmKfx > 0; LdgwmKfx--) {
        continue;
    }

    for (int HRstKj = 1095877896; HRstKj > 0; HRstKj--) {
        unMuyXYZhrE /= unMuyXYZhrE;
        AhfnxNLcBg -= AhfnxNLcBg;
        mGYigzIQmkUhCTR += unMuyXYZhrE;
    }

    for (int QuygUQsSxifgc = 1133545776; QuygUQsSxifgc > 0; QuygUQsSxifgc--) {
        AhfnxNLcBg += mNKXisrkbMeMTEL;
        mGYigzIQmkUhCTR -= unMuyXYZhrE;
    }

    for (int NwmhctxhUIMIs = 234030296; NwmhctxhUIMIs > 0; NwmhctxhUIMIs--) {
        EkyHgtCm = ! EkyHgtCm;
        mGYigzIQmkUhCTR *= mGYigzIQmkUhCTR;
        AhfnxNLcBg -= mNKXisrkbMeMTEL;
        AhfnxNLcBg += AhfnxNLcBg;
    }

    return EkyHgtCm;
}

void ZbiBnSMc::oPnHEOtjnrpsto(bool MjfWznnGJcLHJIdk)
{
    double NPSwetiOlevDVrr = -477891.3321960922;
    string ePmSNpcWHwDcm = string("ToUHmwQiEikZWXosCfntGupyHcryrGUEEVlGURkHJSpmwpyQwxIcbUNpuRmaQGcRQrZCDchotsKakAdvGpKtfJYHhWtsCyuummerYAovTsZAapJukSbtwGFiNZkEXRBVnoTMdkhuhztDpcNWrxdHlCZL");
    bool vBZAnKmVQ = true;
    string xWwJAcMNVRzkC = string("FjKagXWMLtkZQvLVBaTrVMKaxcxSvtTdGukSOyWaRjCPyGzNBJUsBmFGknThLdlducCHqDSOpRiFaPiflcRzYgKkJfeXMGXBZYhtkpGaOuNXvPUfjMJRnYQhPouXMdIPxaFnSpSGaAhJPrVQFpBXncIQMFTDFDDMEUMyOjPCSSXEbimHvuMjlXGoZXRRsyvXlZfqheNcxbyss");
    string xkBYIptsRmv = string("WGfpomSWOtwwaSSuUfRgZOKBkOpDgLRqJnzSUuKqlYBZUlRyr");
    double ncCtDGkkoFwk = -984839.4827943193;
    double yDqZKpitFhhIAZo = -112202.27285809787;
    double GlvCpHLM = 57847.15780882865;

    if (NPSwetiOlevDVrr >= -112202.27285809787) {
        for (int AamEZydAMYK = 469953657; AamEZydAMYK > 0; AamEZydAMYK--) {
            xkBYIptsRmv += ePmSNpcWHwDcm;
            GlvCpHLM *= GlvCpHLM;
            xWwJAcMNVRzkC += xkBYIptsRmv;
        }
    }

    if (NPSwetiOlevDVrr > -984839.4827943193) {
        for (int iLahAuP = 964906550; iLahAuP > 0; iLahAuP--) {
            yDqZKpitFhhIAZo /= GlvCpHLM;
            NPSwetiOlevDVrr *= yDqZKpitFhhIAZo;
        }
    }

    for (int IPaMutivaVFMTwy = 1217525387; IPaMutivaVFMTwy > 0; IPaMutivaVFMTwy--) {
        yDqZKpitFhhIAZo /= yDqZKpitFhhIAZo;
    }
}

double ZbiBnSMc::ErWBXiHpPBXRc(int irHPffVSAgYrnGoD, int KvFGnBpKQQOgk, double lpRKsPk, int QzjbsxNoaMoUce, bool ZMbjKQNuemCO)
{
    string vfbrIqHbEHexe = string("BdEMWONcuwBOalQjugXURaoteFkFtLnlAmzEFzSMPnuakSyNkdueTvrFxitHhEYqnAyNOxrAtUASrtroYCROgUFOSpCtpZdOUexHkPftlYrVExoiliSUKxxIeUZGVsoPpTAuxkJJVitGIjhdegpMdJWcQxcloyrztuyBNxKlernNUTdAlFeCmmVJgxclkJwWHOaEASWzfDgUbNJ");
    double ecqOnoQVbTvhEgJu = -493543.21777645167;
    int FgGSdgPDTkfnxH = -2065844025;
    bool yjnNOhnpkfh = true;

    for (int vWswICmIjGUXtrk = 253430219; vWswICmIjGUXtrk > 0; vWswICmIjGUXtrk--) {
        continue;
    }

    if (FgGSdgPDTkfnxH >= -1708477541) {
        for (int IazhiKEIEFU = 1493074711; IazhiKEIEFU > 0; IazhiKEIEFU--) {
            lpRKsPk *= ecqOnoQVbTvhEgJu;
            ZMbjKQNuemCO = ! ZMbjKQNuemCO;
        }
    }

    return ecqOnoQVbTvhEgJu;
}

bool ZbiBnSMc::EeqaVAU(string SgwRXkACifNR, int erwIbEJTG, bool iuaCMocpjgnVd, bool dAIoLokVPW, string rascszO)
{
    bool jPdawEIPi = false;
    double MEOIfKpjONjBFD = 638570.8953840001;
    double eZiQraNzOUnh = -1019638.5694254431;
    string OklGlv = string("uRkHwMCJhpeSZwrtgnUyeIBVsqkhlFKLKzewZRXyQWLvRXsJLeJzcTnFBTqhGSflQyWfTgRsBmNPLTbnwwXmOHHypUkiHDRzgoZXIVOABVCmrYgCgtIexfooiewYkmBWqveTJdytOVMtKZxlwXzOtlRWTLOxwjBfAeVyNMPhfLXQzHebIuYeIAvKKdgSRvEsIjCeeaiHTjahLaTRcbliKeXQCgmoIbFzYpXVqVQyJrTp");
    int OuaJLtznkwkz = -375746869;
    string UetHaMKHvQWNphB = string("NwwMMeQGVULJEYGfxPzPzsrqZGbzCvyxtkeevRNImsWuIvckjhPCDEmVEeTytoLCbYB");
    double XSvBEfLEFxxN = -1038481.1702629449;
    string rUALhqAQ = string("zdAroQVRZLviNOeodFLZRVEOqpQZulAHUnWmNgJYkppXGetCCxhuSyXAjdyvsqDzAQDKukHdLrUxrwlcXVRPygBXMnmpKFVttCiWBmfPWWTHjDQLFuvBUKCbZcpaOCCsqVUWnrHljuGZDjEZHFpZEzEYcydZHlVHWfxsaIJojjXECvpGsAhVoxTxGVgiIIdFLMRMtFnxhUNCSuypfPnSgPGysLYeIeHwmGPXvnKoShKoIxYvSKSvtJlyhNbkFF");
    string qQfygUHgKzx = string("EaAqpHuaXr");

    for (int TTEniYqnQk = 1172994457; TTEniYqnQk > 0; TTEniYqnQk--) {
        continue;
    }

    for (int ckLvdWi = 1913689872; ckLvdWi > 0; ckLvdWi--) {
        jPdawEIPi = dAIoLokVPW;
        SgwRXkACifNR = OklGlv;
        OklGlv = rascszO;
    }

    return jPdawEIPi;
}

void ZbiBnSMc::qBZxYjeKYfVKR(double YaOASZp, double pMenUbcWCFVVWi)
{
    int SnFUhj = -1617812048;
    int ZdEWqtbxE = -1460762262;
    string aFopBetmUFB = string("OdZHxMpmkyGQnJJpkRpYlysYXspgxMAgMQfYMqfYwbGkdjakDoWlcJnoBzOCTLrYzVaIYdrMoaWepGSYYuiCZfePmsJEaguLNivzoTTWcoSmfCNisbYWHZBmfIANtmIBvErJECOBpwFYKTXcncUZYkkOCkiVqYlfYnLdoRiOiTzVvPxgvUOYsQqBtdBryBxxxSJvLcVZDkqUwGpTRWtyWEjPuiqQNIhHdbIVhRqMWsCQdbNSjpRfpy");
    double TUaOblcmaOuqDWTd = 749504.4476509595;
    bool SaiRxPYhDxg = false;
    double xDwxEshPZlibwP = -780209.0416276429;
    string kBHnggsLYt = string("BBdufqTzRjUkaFiaazcIMqWWRCqUIrtJvTgYESRSFbxwauTsnOiTpxUJXbvHEcjqDtyuRyCWwhOgEFEKbfUhbqGtjPZcfgOasKpsiNlYfGQoWawjNRsyBxamgoeAWhXuTBqimnMHXwhBylLkczmctehQnZoPufFpmZLckylwVABXbgsPtKqBcxfGuirycMRXHhaUOhDrDBNcgacJNUclsdQFZwqCzxbWwSDkkWLlLJjPfyjGvmNxnmaEdDZqr");

    for (int IRZRYgL = 1557950312; IRZRYgL > 0; IRZRYgL--) {
        SnFUhj -= ZdEWqtbxE;
        SnFUhj -= ZdEWqtbxE;
    }

    for (int jJbzUNHpXQd = 758664451; jJbzUNHpXQd > 0; jJbzUNHpXQd--) {
        continue;
    }

    for (int JizQLVJTMVutj = 986775531; JizQLVJTMVutj > 0; JizQLVJTMVutj--) {
        ZdEWqtbxE = SnFUhj;
        YaOASZp = TUaOblcmaOuqDWTd;
        xDwxEshPZlibwP -= xDwxEshPZlibwP;
        xDwxEshPZlibwP -= TUaOblcmaOuqDWTd;
    }

    for (int gInSsdWtdPnKXHv = 463992120; gInSsdWtdPnKXHv > 0; gInSsdWtdPnKXHv--) {
        continue;
    }
}

bool ZbiBnSMc::CzcCNGmDFuu(int aMHfaLdjkmyrn, double wfpFLMHZlqrjZP, double iyYrTfMXs, int XYlkzv, double PheGUNMINNJEIrdW)
{
    double sKRGuGVlOARN = -426297.9510285567;
    bool OwoKVklQOit = true;
    double LnimIToA = -862414.2369021827;
    int qVLtyPCAmoawG = -497334746;

    if (sKRGuGVlOARN >= 999762.963357641) {
        for (int ljfqxsQxr = 721432153; ljfqxsQxr > 0; ljfqxsQxr--) {
            wfpFLMHZlqrjZP /= wfpFLMHZlqrjZP;
            iyYrTfMXs *= iyYrTfMXs;
            wfpFLMHZlqrjZP /= LnimIToA;
        }
    }

    for (int hEjZUhLoGdgkkNAz = 238700193; hEjZUhLoGdgkkNAz > 0; hEjZUhLoGdgkkNAz--) {
        LnimIToA = sKRGuGVlOARN;
        iyYrTfMXs -= sKRGuGVlOARN;
        PheGUNMINNJEIrdW = LnimIToA;
        iyYrTfMXs *= wfpFLMHZlqrjZP;
    }

    if (iyYrTfMXs < -883988.9110078309) {
        for (int fOuHZrkzewOgb = 1786891662; fOuHZrkzewOgb > 0; fOuHZrkzewOgb--) {
            continue;
        }
    }

    return OwoKVklQOit;
}

string ZbiBnSMc::rYiFny(bool dOEYlUTqaKfYro)
{
    double eDkULgWBTg = -272734.64469584986;
    double qPxaUqpTifyUFBw = -553734.2956412674;
    int ArjsYKNrcXH = 308534591;

    for (int fkZMu = 1548811778; fkZMu > 0; fkZMu--) {
        dOEYlUTqaKfYro = dOEYlUTqaKfYro;
    }

    if (dOEYlUTqaKfYro != false) {
        for (int Ubczx = 115933377; Ubczx > 0; Ubczx--) {
            continue;
        }
    }

    for (int FdvEzkQS = 1238292414; FdvEzkQS > 0; FdvEzkQS--) {
        qPxaUqpTifyUFBw *= eDkULgWBTg;
        eDkULgWBTg = qPxaUqpTifyUFBw;
    }

    return string("pgrWtgIKQWMobpkWYlHCGcMukgOmBYYxJ");
}

ZbiBnSMc::ZbiBnSMc()
{
    this->mvuqoFHgtQXXaycU(false, 2034301564, -416707.31859658926, -633602573);
    this->oPnHEOtjnrpsto(true);
    this->ErWBXiHpPBXRc(-1871752533, -2019375160, -191229.47510572302, -1708477541, false);
    this->EeqaVAU(string("rVdVHcsRsaEfwUCuXKJDEXUWJsCvamNvHIrmqLeoumaRvNSwxIIoAIrwlazMAzTynVqvPFvUFowrmTEdUuqSiMOmbuNcjigTPbbAubQMLdvGcuVbBixniIL"), 487390286, false, true, string("ZUxErurhEehynfoo"));
    this->qBZxYjeKYfVKR(-633485.9672600823, -281918.60162147245);
    this->CzcCNGmDFuu(-1999559975, 113450.05378468898, 999762.963357641, 488523214, -883988.9110078309);
    this->rYiFny(false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class luvQRBlupDrxTH
{
public:
    double mBDkrbuAGoZcp;
    bool BjMCKIUSdQ;
    int sWldmb;
    int dvsOvDJypALIdZ;
    int HAiQuqYTnQPp;
    bool TjWwuw;

    luvQRBlupDrxTH();
protected:
    string mESvB;

    int KFyDXvqnywPbUub();
    double VxUmVcMguNWMWT(bool pxaRBjb, double dPSsGkgYjChsQexb, int dfOtIG);
    double vUJybdVBgP();
private:
    string pqkjw;

    int iRUkEAIFS();
};

int luvQRBlupDrxTH::KFyDXvqnywPbUub()
{
    int tQJoxGyohDdGG = 1473605355;
    string mOkdIZl = string("ICblAyjzyzFQWEVFdleXvUAvB");
    string FslKcXdxdzyk = string("qAjrolmfnigKSMaDDCpDxluabFeormnLkGbQeMAcDAuCakHgEsdLsFkHCrdDPLyZJDBTrPMrwSaFQdlEDmlIvHvbJQsovNWWwGYKSnYPnwiuoSowxnGqjkiuUZTmwPBmrXdjOoJohk");
    string GGKpswjoUcWOfR = string("VGsAqFcXiujRBLStWQUtPZFcpGcmlyqPdOJNmGTryfkCmPyTXTsulzVMVyeNNFomsPkRBVGVmGTZJSSzosWuOOMftYWJYzsmHLwHuPOEAXpkJaQqFKGRiHyRfrQnuOtCeQUDughBuOWMvGdBKZGLfGhSKznJIWeORAHPjpYlyBCggZSYwOjYWHwiX");
    bool jAweH = false;
    string oErrCdmBNyhi = string("auZsewHjmVUKodQmnuBaIAqBzmTqnIwULWiSfcvfGLcEawZDGyuWNPxWQjOphIHvRHgIghxlWbmsbHXDKxvNySYoLhRUDgJEmhdWarbjkVopLGLDuWlteosrnhxxNGQxZrMYGmJNcYPOKlHwHDeZdALJUFkWttlMITwvWDRpvEsldDGNojQKCRd");
    double mVkpRaPRgCt = 923072.5083820815;
    bool uykpmeqwcPQiKT = false;
    string HsjKHwqO = string("XKzTyROADPHXFOQNVLuRdYOGUsSHVSmPoWwgHFMRaIHsVZNLhwhIrkzyCSYtffZhwbTtLbOosPXsTmtIFekwbaGzVtrAsgWkzbjRdwIYBICDYywrvCtLmGnBBRERrkXPzwWNhPAmmpcbNvyKqSpsCeijMRDQrZzfhSkqwGyVEgYbVEjLngFpJCmCIgdXGRPPWbVkDGQgLJizhgyNtSVveL");
    int StlExXYvrO = 2032709142;

    if (jAweH != false) {
        for (int WWfOmnAYeEUtxbn = 70769798; WWfOmnAYeEUtxbn > 0; WWfOmnAYeEUtxbn--) {
            StlExXYvrO *= tQJoxGyohDdGG;
            oErrCdmBNyhi += GGKpswjoUcWOfR;
            oErrCdmBNyhi += mOkdIZl;
        }
    }

    for (int ioxuFU = 1148787123; ioxuFU > 0; ioxuFU--) {
        HsjKHwqO += GGKpswjoUcWOfR;
        StlExXYvrO += StlExXYvrO;
    }

    for (int cQNnob = 1735997892; cQNnob > 0; cQNnob--) {
        continue;
    }

    for (int tPWlBHcJXI = 1927987651; tPWlBHcJXI > 0; tPWlBHcJXI--) {
        continue;
    }

    return StlExXYvrO;
}

double luvQRBlupDrxTH::VxUmVcMguNWMWT(bool pxaRBjb, double dPSsGkgYjChsQexb, int dfOtIG)
{
    string dJLHtlOCMyOBrIOX = string("uEOwfVGwNWBRXCPFLhBtyInzbIrQqaaOOQndRCTrPhOJHgqYdwbjrlKRgfiZsKzkGOWFOnfxugfKuhPMesPDgmqTHWQqBhF");
    int lUBrAvn = -25630755;

    for (int SLgQkwC = 1404442313; SLgQkwC > 0; SLgQkwC--) {
        dPSsGkgYjChsQexb /= dPSsGkgYjChsQexb;
        lUBrAvn -= dfOtIG;
        lUBrAvn *= lUBrAvn;
        pxaRBjb = ! pxaRBjb;
    }

    return dPSsGkgYjChsQexb;
}

double luvQRBlupDrxTH::vUJybdVBgP()
{
    int tYommgJeX = -109905135;
    double iquWIfZZafPD = 711589.060312337;
    bool GnPfKeHmiq = true;
    int bODuYjsVNz = -527856652;
    string WQRylSvTz = string("dIWzYJfDkAZiEBFcokpvnTghBbzdEzQdNEztfjKpLIsTk");
    bool UoUeU = false;
    double UGMkSudFGoc = -214053.48868268883;

    for (int viGZSoHVEXyuJOk = 1041844631; viGZSoHVEXyuJOk > 0; viGZSoHVEXyuJOk--) {
        continue;
    }

    for (int ppLqPAVxWviLR = 1043587827; ppLqPAVxWviLR > 0; ppLqPAVxWviLR--) {
        tYommgJeX /= bODuYjsVNz;
    }

    return UGMkSudFGoc;
}

int luvQRBlupDrxTH::iRUkEAIFS()
{
    string RLQUcGo = string("tGqwNxTJfIEKEuEMfeZhvpxDtpcfckbRiHZDnpUZJrSpqolJklSVlFUjSXOoBxDANvXiTMVcTXomLXoePTaJuDWmBOvqzAQNGQGTSwBXzTNJNvTYBXcAPzWXpffXKFPWAhsDCupSBtxapZrzbeyPgtDBZSYmgqZi");
    int ruodStm = -1432605408;
    string LULvqFRVCjTnTyn = string("QQhtMSmohivnfHeUwbSLAVuxUROEVyPDNYJYVwkrVczKfPPNqSKWOLfCDLlWtcLlkPzZKowyAvjWXBWcHpAcgwxqtJRuUAvVyLqOYCIoyUQ");
    bool rvHqICD = false;
    string onkAsqVAXgVO = string("hpqOSASxcsFyVEUlfjKfeTWTlPrZbpIJypdYkZtToVSRXIqESsmAzopBFeStElTxIjycbmamwGfdgALertuDJTkoIIvPPVahGnJpklOqgzqusiMViOAYkRhnuwZJacfGfXPskoFRfwwvrLSDGOVtQTyQDONYpaVNQCkZFQzzRblkqxmGfcAroLiLkUMUVjvCrIUqAfpDuBfUVHPKEPNtugkCCQWHZDrFUtVpnWfCFUgUt");
    double DTLxBgpdXK = 983737.2758386893;

    for (int iLDRnGg = 1886444820; iLDRnGg > 0; iLDRnGg--) {
        RLQUcGo += LULvqFRVCjTnTyn;
    }

    if (DTLxBgpdXK == 983737.2758386893) {
        for (int xxUwOoHDW = 79751601; xxUwOoHDW > 0; xxUwOoHDW--) {
            LULvqFRVCjTnTyn += LULvqFRVCjTnTyn;
            LULvqFRVCjTnTyn = onkAsqVAXgVO;
        }
    }

    if (RLQUcGo > string("tGqwNxTJfIEKEuEMfeZhvpxDtpcfckbRiHZDnpUZJrSpqolJklSVlFUjSXOoBxDANvXiTMVcTXomLXoePTaJuDWmBOvqzAQNGQGTSwBXzTNJNvTYBXcAPzWXpffXKFPWAhsDCupSBtxapZrzbeyPgtDBZSYmgqZi")) {
        for (int dyCiuduD = 1281071738; dyCiuduD > 0; dyCiuduD--) {
            continue;
        }
    }

    for (int gJtpcEKIYDKs = 1361207198; gJtpcEKIYDKs > 0; gJtpcEKIYDKs--) {
        continue;
    }

    return ruodStm;
}

luvQRBlupDrxTH::luvQRBlupDrxTH()
{
    this->KFyDXvqnywPbUub();
    this->VxUmVcMguNWMWT(false, -876507.4713252423, 1955720902);
    this->vUJybdVBgP();
    this->iRUkEAIFS();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HnFGMSSz
{
public:
    int AVFWHBnPeyyoF;

    HnFGMSSz();
    string dEnWLgXRJftFWFn(string YJdlayYHU);
    bool SMPCGh(double iJKGOZoVFlMJT, bool IlGBYbsrp);
protected:
    int fUFSfBMNCS;
    int nfXHKinFuEbc;
    int ZmIUuAYRlagNfSwH;
    string ljvSV;
    bool eltHcUfUDz;

    string lbTTF(int BmAyXVSoWjTIXibn, int CkwTkAT);
    int pBFpRIjqOpP(bool KKgpjXUmxUlOTyn, bool JhToHQmvIOIde, int onLZfwjdFb, bool rAEQtZRM, bool sVdDz);
    bool AtERzR(bool qcIfgL, double jsvELPShkzebIFY);
    int UKJXZwgXHDo();
private:
    bool dzKZVXCkWvHXsGOo;
    string kZXKCPSOXLKHMS;
    int dIGSSUUKYJliu;
    string QigWczRK;

    double fGwhbHZ(bool DiWOOxkCeFWzI, double DAPKCq, string fDXyQfEYXnajuEc, bool whKAW, bool KsMUACxTdoMlf);
};

string HnFGMSSz::dEnWLgXRJftFWFn(string YJdlayYHU)
{
    double ZvDbQuClJYvaydR = 972812.4875381289;
    string OCKVMFICRv = string("nSwCIeNBSAYMRfMCjCrXBbtunLkEYABodANqfpaRZLTCKUfdUOzYVuKuWLTiBdJPgEECCjoHpamCvXOatDmqGzDDLpyYpKJGyzeQifyvGBigJVoCBJWHyVGlkUJFmchplvjmElhjrhnFtArnczCTusrxuyzSLdOvqjErxdsVzLWIHkyhDLglReRJGxLYHruOhQwebnqFXCXIAbJdeAelnXPySKSKBJqHcIc");
    bool oLTWpUfoglO = true;
    int NXxhtxkqmVcxKt = 268403554;
    int yyrVbupHcT = 1994798335;
    bool essctZBiUNfzmpoV = false;
    bool ObhhKe = true;
    int kBKXE = 1994747280;

    for (int jjRhHi = 1467261255; jjRhHi > 0; jjRhHi--) {
        continue;
    }

    return OCKVMFICRv;
}

bool HnFGMSSz::SMPCGh(double iJKGOZoVFlMJT, bool IlGBYbsrp)
{
    int jkYTu = 785157329;
    double uhMhBttV = 1023348.1521955327;
    bool HyLELcFYzCslxE = true;
    bool skqPMMBIg = true;
    string DintCYkmTVqqpG = string("TmbRZfAgJGQQZWGUteExoqlfxpsaNArimYitSqoTKSUqZBGIshNMztHnnYwzGnaXkxxbCnAjhOUnWGlvqSRRpoJsariGPKPFngoKpzYEYFZxqyiBHYWHlDBmazkJgJsrEmWpyrIXdVbExfwYySXSIJDKpheyWSXbZEtIQoDquzMLJrmRcBxJVHWZXnFPFUjksvBfdqspTWfVhRgsUHRNmRNiVMHddUIgpdlCAWkNfELdIOWbeTmWE");
    bool uvyZM = true;
    double pRYusMP = -694018.3222826808;
    string LHTmk = string("gdNwQBtVlNpjFiZfARaoOUkyrCTWjCaGYboitrWGkkgtBNAzSbeUDBEaseIvxHoHkmeSOxaSrVmEPQBflfBhPXPlVqAlaFSuwpVrmKRQKZMhrBDiECDtgPggvWhwhYTaDEmVIeYwUWApdarcURSlrbecGzxvDMLXAiPUzNRHhuTskqGlnMPzZWBUmbRNYYMzolxBoUWKdCGNAilnJhCuMyXiJObyzJ");
    bool iMpNUp = true;
    string DDujzdKInyLKTpHf = string("oxGQqSaTCdAnBPNuihbsomCyHTqQmwwALhhvpmSPsutNykzwSUFAwmDNRADsLQlikDMyiEmeWZAVZQKpdgrUIMzkJDrLUNmUzHUcPYHFVBWHbZiLFUwfXQqtwtYDSEbITkdoEmT");

    for (int fCpuxNUbMR = 150200748; fCpuxNUbMR > 0; fCpuxNUbMR--) {
        IlGBYbsrp = skqPMMBIg;
        iMpNUp = ! IlGBYbsrp;
        skqPMMBIg = HyLELcFYzCslxE;
        IlGBYbsrp = ! iMpNUp;
        LHTmk = LHTmk;
    }

    return iMpNUp;
}

string HnFGMSSz::lbTTF(int BmAyXVSoWjTIXibn, int CkwTkAT)
{
    double zErcRuztnUOyBmj = -1042355.9803059511;
    bool AAgnnNpYa = true;
    int SCxFiNZKTPR = -1390460220;

    for (int BewkKXWXon = 1863573001; BewkKXWXon > 0; BewkKXWXon--) {
        SCxFiNZKTPR -= CkwTkAT;
        zErcRuztnUOyBmj = zErcRuztnUOyBmj;
        SCxFiNZKTPR = SCxFiNZKTPR;
    }

    if (BmAyXVSoWjTIXibn <= 1580479921) {
        for (int fQCEgmwD = 923977765; fQCEgmwD > 0; fQCEgmwD--) {
            SCxFiNZKTPR /= BmAyXVSoWjTIXibn;
        }
    }

    if (SCxFiNZKTPR < 1580479921) {
        for (int MAYyaMgTHZLDJ = 2131524670; MAYyaMgTHZLDJ > 0; MAYyaMgTHZLDJ--) {
            continue;
        }
    }

    return string("EDIpZnyBLXdkkZIngsERFkkKwFKjeWtlHVpCykgfcNOEQlGsnlTRwJRvfGaMwNTBmQFrrCXxhfsSdmduPxABQeVfvSOWSaAVNQZsHINpJktEBEDQguYZhd");
}

int HnFGMSSz::pBFpRIjqOpP(bool KKgpjXUmxUlOTyn, bool JhToHQmvIOIde, int onLZfwjdFb, bool rAEQtZRM, bool sVdDz)
{
    double IlRwyOFY = -213480.21837195542;
    int ItnvCYHMnDRSF = -831689198;
    bool MAXXfRUYYNFgUC = true;
    string eABHOnKuyq = string("ndKeONKlLsxjopEVqVzHQoxLXLhtneXrllAjUhchhaOdDSLqnjisPfyuaPhoRnOlvndJupIgPiMeUObnDncdJdrJRjdxvSCYX");
    bool RhJcYQdPfcL = false;
    string BYIvFbMPCembvwSs = string("tUyRFxOLqdbajODKCYEVNjLsJqJTFxlzyLNGaqiygFlKAmcEAJwD");

    for (int qvboSDmLspLJXd = 1971282866; qvboSDmLspLJXd > 0; qvboSDmLspLJXd--) {
        RhJcYQdPfcL = KKgpjXUmxUlOTyn;
    }

    for (int fdgKacbrVkpTT = 1527917457; fdgKacbrVkpTT > 0; fdgKacbrVkpTT--) {
        continue;
    }

    for (int lVLdEPkLJ = 676274119; lVLdEPkLJ > 0; lVLdEPkLJ--) {
        RhJcYQdPfcL = MAXXfRUYYNFgUC;
    }

    return ItnvCYHMnDRSF;
}

bool HnFGMSSz::AtERzR(bool qcIfgL, double jsvELPShkzebIFY)
{
    double dwBOhyWjBEqQ = -785025.3474339067;

    return qcIfgL;
}

int HnFGMSSz::UKJXZwgXHDo()
{
    int nKljpdQffYxEtjv = -831940120;
    bool sFIYjmrmUbpVVtq = true;
    double ZWMjJnxFBGNmtkIo = -638746.7181685183;
    double VHoxM = -757970.1040103246;
    int YbXytAQeR = -1561880029;
    string UVYrlptzgK = string("MFUNEcCviNawCwjvTbNWQEjztXckejMqLRlqsWfgUmKybFZrHRkSnsFvxZLEwrxsGVQOgUbwpCAvwmxLjDODxrjGNuhOeLLGmGSaVYwyVtMcUqoNFZlKmTMyHuelCIwgpZdUlNwYHxbdEyoojhsirWmSNItvXbtDmboBBLgnmDyslpBtauFwBBuQJOEPGciNmkBbVRWSuztGyQv");
    int nZtYpyDrS = 577378479;
    string saxmMG = string("RUFwkzFyZhxaQyydCWIsLhdWzpzplhXABRmvcevMJjafIbXesAgQXbUApMNxozNrIjijgNmYCMMc");

    for (int eOlZISPGzUtZQpzW = 1046147035; eOlZISPGzUtZQpzW > 0; eOlZISPGzUtZQpzW--) {
        nZtYpyDrS = nZtYpyDrS;
    }

    for (int OvLHLjsVGzpHnpGW = 1036380148; OvLHLjsVGzpHnpGW > 0; OvLHLjsVGzpHnpGW--) {
        YbXytAQeR -= YbXytAQeR;
    }

    for (int KJvhMyarALCTAH = 1056761808; KJvhMyarALCTAH > 0; KJvhMyarALCTAH--) {
        YbXytAQeR *= YbXytAQeR;
        nKljpdQffYxEtjv += nKljpdQffYxEtjv;
    }

    for (int GvYcEejyrv = 983718838; GvYcEejyrv > 0; GvYcEejyrv--) {
        ZWMjJnxFBGNmtkIo /= VHoxM;
        YbXytAQeR /= nKljpdQffYxEtjv;
    }

    return nZtYpyDrS;
}

double HnFGMSSz::fGwhbHZ(bool DiWOOxkCeFWzI, double DAPKCq, string fDXyQfEYXnajuEc, bool whKAW, bool KsMUACxTdoMlf)
{
    int RbFSEDTLmWbxPQm = -343137125;
    double MVvtqtYz = -818315.8266490131;
    string htXCXrPX = string("wfoMNjckVsmnHvLszrIkzPLoUDryVnxAAPlwGhUsvlJoydzNhzPSifbLCwbMFixVmoRjuJfQeWQTj");
    bool gQrzlQDpEAgbFa = true;
    int njApYVRvgTVyK = -354300868;

    for (int sbQTmAWgaWjesBdX = 1252646031; sbQTmAWgaWjesBdX > 0; sbQTmAWgaWjesBdX--) {
        gQrzlQDpEAgbFa = ! whKAW;
        gQrzlQDpEAgbFa = ! gQrzlQDpEAgbFa;
        KsMUACxTdoMlf = gQrzlQDpEAgbFa;
    }

    return MVvtqtYz;
}

HnFGMSSz::HnFGMSSz()
{
    this->dEnWLgXRJftFWFn(string("SVIlNkovpuxGJmLaedjIUdGxswVEOHfkpOZGssuoQCRYaWujLbupcKeuCNcaorGXpQaEDKtlqObFtrrNXDPKhtbjGksxJYGqHIaeXmXQaCXaM"));
    this->SMPCGh(-868541.8233108618, false);
    this->lbTTF(1580479921, -1708373283);
    this->pBFpRIjqOpP(false, true, -727546212, true, false);
    this->AtERzR(true, -307519.78420752566);
    this->UKJXZwgXHDo();
    this->fGwhbHZ(false, -571104.3738857469, string("pyxahnifgQrMJSDqVYvXvzTvegnFqLZbNjlWCiFAUnGGTquiaJltyKkXczSd"), false, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CqfumKgNkvzgudlm
{
public:
    bool KznersQ;
    int eBObgtUrQOj;
    string vPCuruiTrnMJOw;
    string bBFsdwZvSrIO;
    int UzQrBB;
    double uAaKmqNO;

    CqfumKgNkvzgudlm();
    string PluLQzHbjQpmhpKc(string FTvcvEC, double yvHVeKeHTr, bool UEmda);
    void kWVZd(int DjFyneNbWCdYiT);
    bool uEqQaWWFmCxM(double JsuUZX, int kdIbRxVQqQoh);
    string OFBgFuMxv(string mGQoT, int vgnCEDI);
protected:
    bool QKCAoepaLOu;

    string JsCWRS(int KXnsAcbdD, string yGLbozrhmigaC);
    int rtQqwfSxJzIsCjz();
    bool YGTfdWNrDe(string pFTkYdVwDwu, int FUgaEQWIEtqTni, string LQRkN, double VfnrzbZDpv);
    bool gmmbwJmTbkCPpv();
    double NmtPWxNqhydXn(string tEZHHL, bool nTbsMuyoAvKWIS, bool wAiXSGSxKQ, int HeZrWRh, bool kWxvUTCMVAVaa);
private:
    double XgPNn;
    bool miLqQEEcStFhGQV;
    string rkwVYRuhytF;
    double adRPUVRqv;

};

string CqfumKgNkvzgudlm::PluLQzHbjQpmhpKc(string FTvcvEC, double yvHVeKeHTr, bool UEmda)
{
    double ZDagStYKVvkmajEO = 289466.19556866854;
    double wJGMa = -936449.1152277407;
    double WohlgWIsRxOhWPu = 201388.88000958867;
    int vfPZkzmojwqTs = -1163781867;
    int KzikskFnYXm = -2057560998;
    double xLrxllUIx = -226632.4170735491;
    int KJCjKjD = 1090087805;
    double VdyFnOKPiuhpt = -410167.92616929446;
    bool GtXDcKj = false;
    bool LKIexwcdcGnqy = false;

    for (int xPErZ = 962830974; xPErZ > 0; xPErZ--) {
        VdyFnOKPiuhpt /= wJGMa;
    }

    if (KJCjKjD > -1163781867) {
        for (int BMYqKEslzCaRoAya = 647732511; BMYqKEslzCaRoAya > 0; BMYqKEslzCaRoAya--) {
            continue;
        }
    }

    return FTvcvEC;
}

void CqfumKgNkvzgudlm::kWVZd(int DjFyneNbWCdYiT)
{
    string QwyQtAnNHyVbknf = string("UjtKe");
    double RfxRamald = 709546.4098527418;
    double JVbhgboNiVOUa = 490275.74444082525;
    string eFUjNqRtNjPZjetO = string("OeopoDfJIVZTyHiElavHzOGlYvoRlitnXsSReIITlXuLlvBacjcTjhRflUPsSMeOxWMZnNgMlCkTYBMUkdRPlNToJfeqFXYiHRpngclWAuACtaBrOqeUKvOCVhHlaUnTUnHjUbKfjwnukcgFxEmbSSKfIFZYaKEFTYKDTewlgwOQsLJKQjEEBjqLzCvObXzDbXvFrAyuHtMyLoutiZBBkGVvJAMgSHQqNYzbt");

    for (int vSSCy = 1248853976; vSSCy > 0; vSSCy--) {
        QwyQtAnNHyVbknf = eFUjNqRtNjPZjetO;
    }

    for (int RvhNR = 285606492; RvhNR > 0; RvhNR--) {
        JVbhgboNiVOUa *= JVbhgboNiVOUa;
        QwyQtAnNHyVbknf = QwyQtAnNHyVbknf;
        eFUjNqRtNjPZjetO += QwyQtAnNHyVbknf;
    }
}

bool CqfumKgNkvzgudlm::uEqQaWWFmCxM(double JsuUZX, int kdIbRxVQqQoh)
{
    double DQBrKjO = 687067.8945054306;
    double abELidbZ = 755763.7186056449;
    string IaZBdXNYwGnEnnTh = string("lbAEpvEFzLaiViLcODfTcXDHYXGCeOjkitdboogTntsJyGAiYM");
    double WUOJrxgDFYhX = 673089.8540496418;
    bool ruYenW = true;

    if (JsuUZX <= 687067.8945054306) {
        for (int wDXyjhQEAPGVm = 1426053572; wDXyjhQEAPGVm > 0; wDXyjhQEAPGVm--) {
            continue;
        }
    }

    for (int fQNzGFmLQEaFn = 516040767; fQNzGFmLQEaFn > 0; fQNzGFmLQEaFn--) {
        kdIbRxVQqQoh += kdIbRxVQqQoh;
        WUOJrxgDFYhX = JsuUZX;
    }

    return ruYenW;
}

string CqfumKgNkvzgudlm::OFBgFuMxv(string mGQoT, int vgnCEDI)
{
    bool KBEnqz = true;
    bool WXAheNoAyNZFP = false;
    bool FpDJgro = true;
    bool yRHGIgxFtKELK = true;
    string JpXpOXyoLp = string("zEtKfrosvxZjdKGo");
    int hmkXz = -628226150;
    int ESCecISdVqQ = 175785490;
    int YelsuSgfXUeTngQv = 1858042076;

    if (yRHGIgxFtKELK == true) {
        for (int kMcnUxggfJu = 171609967; kMcnUxggfJu > 0; kMcnUxggfJu--) {
            vgnCEDI -= hmkXz;
            ESCecISdVqQ = hmkXz;
            FpDJgro = yRHGIgxFtKELK;
        }
    }

    for (int eXyxJl = 1305829621; eXyxJl > 0; eXyxJl--) {
        YelsuSgfXUeTngQv /= vgnCEDI;
        KBEnqz = ! KBEnqz;
        YelsuSgfXUeTngQv = ESCecISdVqQ;
        WXAheNoAyNZFP = ! FpDJgro;
    }

    if (WXAheNoAyNZFP != false) {
        for (int rnlklyxlazF = 228471747; rnlklyxlazF > 0; rnlklyxlazF--) {
            FpDJgro = ! KBEnqz;
        }
    }

    return JpXpOXyoLp;
}

string CqfumKgNkvzgudlm::JsCWRS(int KXnsAcbdD, string yGLbozrhmigaC)
{
    int lKPyau = -265552878;
    bool pwqkMOgbsx = false;
    string TZQFdlnnl = string("OKnvbeWjA");
    bool BLMiLoEU = false;
    int SpPtnvTWGWrNpypi = -707654982;
    bool HPzaLfz = false;
    string xWRBMP = string("xUSLUdHWslFsEygozwjmfGCKUrPARVqcDSzWcSmaiabtvelxzDBmbOoMFofWyvHGobroYHesLwoRRzdjAZRNyfudwslBnSgHiMJuUGgbzyFjtUETZTFcANDycaWtNiMGbWJStHUVjksOoFg");
    double DthmAGMxcC = -496636.14363603765;
    int ducnGxPepXxC = -84903919;

    if (KXnsAcbdD <= -707654982) {
        for (int LSFxlq = 506025482; LSFxlq > 0; LSFxlq--) {
            yGLbozrhmigaC = TZQFdlnnl;
            SpPtnvTWGWrNpypi = SpPtnvTWGWrNpypi;
        }
    }

    for (int HSuidTxV = 1101212811; HSuidTxV > 0; HSuidTxV--) {
        TZQFdlnnl += TZQFdlnnl;
    }

    for (int VQbQUZmMgiRSpxA = 1801426340; VQbQUZmMgiRSpxA > 0; VQbQUZmMgiRSpxA--) {
        continue;
    }

    return xWRBMP;
}

int CqfumKgNkvzgudlm::rtQqwfSxJzIsCjz()
{
    double PCtMobgSQ = -615953.0098187064;
    string QXLyjBzLyf = string("SYMmNaFYAQfMctQWexzzCWmKpHjeUPMMXCPNyddBbhWRwsNmxUxXsWVcNSWoBIjYQHDIStZnqDhYSYDTtxkfxJxnBpmFtcsBFyi");
    int xdrfCg = 1973055745;

    if (QXLyjBzLyf >= string("SYMmNaFYAQfMctQWexzzCWmKpHjeUPMMXCPNyddBbhWRwsNmxUxXsWVcNSWoBIjYQHDIStZnqDhYSYDTtxkfxJxnBpmFtcsBFyi")) {
        for (int Fthur = 1630675507; Fthur > 0; Fthur--) {
            PCtMobgSQ /= PCtMobgSQ;
        }
    }

    for (int HAZGq = 2072269492; HAZGq > 0; HAZGq--) {
        PCtMobgSQ += PCtMobgSQ;
    }

    return xdrfCg;
}

bool CqfumKgNkvzgudlm::YGTfdWNrDe(string pFTkYdVwDwu, int FUgaEQWIEtqTni, string LQRkN, double VfnrzbZDpv)
{
    bool IZXMGIwdVJsNos = true;
    double vEvUXtJbIWhkFnki = 789339.6063553656;
    int TInASixEKWwWvUYo = -876191172;

    if (pFTkYdVwDwu < string("rdAlVQCOlUpmuCVJRASNxcMRvCCGOOkXlUOecLQndLYXPZUWdnjQqnL")) {
        for (int sqATpEacglrKY = 1691705274; sqATpEacglrKY > 0; sqATpEacglrKY--) {
            VfnrzbZDpv *= VfnrzbZDpv;
        }
    }

    if (LQRkN == string("rdAlVQCOlUpmuCVJRASNxcMRvCCGOOkXlUOecLQndLYXPZUWdnjQqnL")) {
        for (int CXRiQUrEd = 1102799138; CXRiQUrEd > 0; CXRiQUrEd--) {
            VfnrzbZDpv *= VfnrzbZDpv;
        }
    }

    return IZXMGIwdVJsNos;
}

bool CqfumKgNkvzgudlm::gmmbwJmTbkCPpv()
{
    string erDmAf = string("ZgevkvuEbXFUEAMajzojdimSvPKxuiyOeFEDUccfqsMVsnKFhsqsictwFdWgxZbgVlstPqQVHPeFmLKvbgOuDUWGNFats");
    double oNXzvNf = 1048396.8332565252;
    double dXmgsTxtp = 239130.83856476934;
    int mVSOAQvYzRdxiiw = -910496197;

    return false;
}

double CqfumKgNkvzgudlm::NmtPWxNqhydXn(string tEZHHL, bool nTbsMuyoAvKWIS, bool wAiXSGSxKQ, int HeZrWRh, bool kWxvUTCMVAVaa)
{
    double JhJhmbPWnsIujTR = 5009.18154612349;
    double FkHhANNbFJmVI = -556070.548333431;

    for (int DABNTkjxppJsxtuZ = 1878155460; DABNTkjxppJsxtuZ > 0; DABNTkjxppJsxtuZ--) {
        continue;
    }

    return FkHhANNbFJmVI;
}

CqfumKgNkvzgudlm::CqfumKgNkvzgudlm()
{
    this->PluLQzHbjQpmhpKc(string("CdFzLKDOovqBFWwpiWlEYJPSWAFuNxAkNrVvlRmZUTeUjPWiyUWSMWzBxkscmvYXjzsJceTsnkWseCQJxQsqTziukTCVYNonvdhtXFEskwnXSqwAxklgGIKkiJfxphPXIueayD"), 4875.6793878439275, true);
    this->kWVZd(-690308111);
    this->uEqQaWWFmCxM(382460.2627762547, -574446119);
    this->OFBgFuMxv(string("EFWUGMovWjFBAXUsyBpRrVuxoG"), -1839527588);
    this->JsCWRS(2125943781, string("ETPkUsjVtzXqPdJRFdHUGzRqQERzMsUJPnixYUIQcUNLLaJZAEGVVqvpjvZZqucaEYuhtkOSnnEvNLKFxFvwdUEAqHNhjoiIYztKxCNgmLcxUubGUvospTfMgDkjTtUNIKgVyLyoaUfqHDkpxCmqnjynUSaLUJsWZoLdMwbBCPanTdQzBxrAYBRTJxsFyIqxvIptUASRtUCjNcKmPFTNxbgmWjnBRCMsViEjVWRAABsbQuPdZJeQXPe"));
    this->rtQqwfSxJzIsCjz();
    this->YGTfdWNrDe(string("rdAlVQCOlUpmuCVJRASNxcMRvCCGOOkXlUOecLQndLYXPZUWdnjQqnL"), -2078271162, string("iInVudErupQkEBEdk"), 386941.12983802904);
    this->gmmbwJmTbkCPpv();
    this->NmtPWxNqhydXn(string("DBKQWrvyQXURuSsZTiJtusCWsdyNGNvYmIkUEXObAQBudPHFmLpVoGNSemYhVleomrQLZjFmpUgeZJOOoSFSxrQniVVJzzVlMdhCkFjGxavmmHrmyGUpABoPBNCuZiEUcmJDePTfdiDhyWXgqFEdoV"), false, true, -1241761458, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DHXqgzgVtQevsa
{
public:
    string HDARJOUFxeUJ;

    DHXqgzgVtQevsa();
    bool djLUKMByAtlFlS(int VUQJbEu, double sWuRQdX, string phCfjvxg);
    string KFGRVIbscyDPuju();
    double SiMoasqLqWnKs(double EUQuYJQgEdmvOS);
protected:
    string PztYgNqjKHC;
    int VrNzurHJZ;
    bool sesjzlHUgDt;
    int eTyCVVJSwEeFuQX;
    string rfNIBgxw;

    bool vqMIvMAwYPRyI(bool dNESremhe, bool LMKlsUznhmn, bool BOsdoa, double kNGKuqK);
    int DFtRHgUbFh(int KYwbx);
    double srpOLesHLuPnKmXX(double GKtxH);
    int uzaJbxwsvSCtl();
private:
    int VPBOVbGZkAA;
    double SRCCfn;
    bool yVvvWeozfmOf;

};

bool DHXqgzgVtQevsa::djLUKMByAtlFlS(int VUQJbEu, double sWuRQdX, string phCfjvxg)
{
    string KTMeFlevjete = string("aTrcuolxIKJjgJJrNfkIMgNRrdAaOinzBOJl");
    double wsxiY = -269704.2232845976;
    string HFQQxoqQr = string("JlxWDnZ");
    double NMWPZbSuavPxKuL = -83016.85294252868;

    if (sWuRQdX <= -83016.85294252868) {
        for (int BrGeVlsCsEyaM = 926045202; BrGeVlsCsEyaM > 0; BrGeVlsCsEyaM--) {
            sWuRQdX /= sWuRQdX;
            NMWPZbSuavPxKuL *= NMWPZbSuavPxKuL;
            sWuRQdX *= wsxiY;
        }
    }

    if (KTMeFlevjete != string("JlxWDnZ")) {
        for (int IqXUbc = 1565675747; IqXUbc > 0; IqXUbc--) {
            sWuRQdX *= wsxiY;
            KTMeFlevjete = phCfjvxg;
        }
    }

    return false;
}

string DHXqgzgVtQevsa::KFGRVIbscyDPuju()
{
    string yJWZpOwhTfdPRTp = string("UMeccNHzmvZaBFxYTMfHDMiAmVKZMCKwTfHJglNCyGnUSgruUJUAhGcfSdcSZtTirTLDDYUQzfZOpxwybCnkYmgwApRDoyFCdynRrbkhidxmfhMgozryjUioBfViprJxyRKuIVowyPcIQJHMuMUruFnkIJJGfHftwqoDnDJCqwFdBwWvNQoOtZqKnCLqcqNmBJJkIthbybPzvZOMydqulqWyvdc");
    double djdnAKkpjFb = 573595.8275145406;
    bool KcxTjZjF = false;

    for (int ofnAjztkAw = 1492204600; ofnAjztkAw > 0; ofnAjztkAw--) {
        continue;
    }

    for (int YyJdgC = 989411181; YyJdgC > 0; YyJdgC--) {
        djdnAKkpjFb *= djdnAKkpjFb;
        djdnAKkpjFb *= djdnAKkpjFb;
    }

    if (yJWZpOwhTfdPRTp < string("UMeccNHzmvZaBFxYTMfHDMiAmVKZMCKwTfHJglNCyGnUSgruUJUAhGcfSdcSZtTirTLDDYUQzfZOpxwybCnkYmgwApRDoyFCdynRrbkhidxmfhMgozryjUioBfViprJxyRKuIVowyPcIQJHMuMUruFnkIJJGfHftwqoDnDJCqwFdBwWvNQoOtZqKnCLqcqNmBJJkIthbybPzvZOMydqulqWyvdc")) {
        for (int gViMGT = 436179795; gViMGT > 0; gViMGT--) {
            KcxTjZjF = ! KcxTjZjF;
            djdnAKkpjFb = djdnAKkpjFb;
        }
    }

    for (int awlfvGcefLUw = 226668782; awlfvGcefLUw > 0; awlfvGcefLUw--) {
        continue;
    }

    for (int IUAGfJjMfvpJbm = 1892437202; IUAGfJjMfvpJbm > 0; IUAGfJjMfvpJbm--) {
        djdnAKkpjFb += djdnAKkpjFb;
        KcxTjZjF = ! KcxTjZjF;
        KcxTjZjF = ! KcxTjZjF;
        djdnAKkpjFb += djdnAKkpjFb;
        yJWZpOwhTfdPRTp = yJWZpOwhTfdPRTp;
    }

    if (KcxTjZjF == false) {
        for (int UDVFeXwlMvdJeU = 1033760139; UDVFeXwlMvdJeU > 0; UDVFeXwlMvdJeU--) {
            yJWZpOwhTfdPRTp += yJWZpOwhTfdPRTp;
            djdnAKkpjFb += djdnAKkpjFb;
        }
    }

    return yJWZpOwhTfdPRTp;
}

double DHXqgzgVtQevsa::SiMoasqLqWnKs(double EUQuYJQgEdmvOS)
{
    string uqIBQLWAMsvgtTYd = string("neWXsVvGvokpWFtONWozukYWvPdHrDHVmSmROxoA");
    bool MnSsISQ = true;
    bool HuiNBsSfet = true;
    string VytAPq = string("EjpmOXzOtfDEBYxHwdwePMxugTQFbONOSByeJZWSbNGzWcxkLzgBwjyhtPiKSEohXVYJeupmXMANhgPPhiEpuZkgZDcoebnyLVRwhDJxXClXymcG");
    double dLOjAhlFNNeG = -378751.1486070566;
    string mcqvthE = string("zKjHLVUWmTdGiPhgWeaSaKcnWPttnJbtzRpDHRFrnxSbQRcWMfpEZXtMrZOyBfXrazWIEiLlifecDOtSFhYbOqvFJjGuAcYVKwxEDZFfpZhBKzubcPvZwwFOdNSHYTUyeIWDJHmMd");
    int XBLffrqyOeMBDU = 2104287837;
    double oIwpHidRrcz = -718333.9420381386;
    string vERvXwxTx = string("dAIqqWrPlMBHnxTvuWAsdfLDeWlDlokxAxTkbSJaZpGNUniDNruABbtsfCPhNgteIaBGcZmqKODPiOLviYeQZHyeKMxav");

    if (EUQuYJQgEdmvOS < -378751.1486070566) {
        for (int MMhPVNGqeVPJNKc = 1169364406; MMhPVNGqeVPJNKc > 0; MMhPVNGqeVPJNKc--) {
            mcqvthE = VytAPq;
        }
    }

    for (int UkqqFaarjUwImc = 474138078; UkqqFaarjUwImc > 0; UkqqFaarjUwImc--) {
        vERvXwxTx = VytAPq;
        mcqvthE = vERvXwxTx;
    }

    return oIwpHidRrcz;
}

bool DHXqgzgVtQevsa::vqMIvMAwYPRyI(bool dNESremhe, bool LMKlsUznhmn, bool BOsdoa, double kNGKuqK)
{
    bool CpcrmwmH = false;
    string WRzLmag = string("RToTTygGOkIsvOmRPpwHLtdzrQyXykznncPlgycYkfUBsJslNlmzUPChSTXfewqiYzsFqXGogMwhntEqdxBYCoWCdffqEZzGMFwAUYKEGSUrauELYYRMllyhfXsyGWWfMhAIUNcyKvNX");
    int PNssFJS = 684846681;
    string SfVaiEWDaUVHDY = string("LPv");
    string CQjZtbQqi = string("nafdyWuDriFpuzUwgvCtYHuUBSmHnbQZdmryYFmSlrSrrDQtZbRbyClgFBHysYEcXHhFgNhXqDnLGxsCpsMHPkoIGcibIlBSOSAIuOqdTlKKwNfmlxOmwnCZgTYlJCZthPCCnSoXLVCGmUxawyFVIWbiQiyvLITPHWsIVdGNEIdimdbaxeQohUMvSMfvtEREjMAcL");
    bool LeXKZZkD = false;
    double eOeJWNNe = -708667.5865604728;
    string gSxqiIGaaKtUTLk = string("tlXxLLeVntKMqkwLZsqNGYQwypYLRedJwZomebJLgfWTxwvPghgnFWIzyBIEKuXyOMVagLgIsOYXtgDXmbmPrnzqkKrcxcWnWshClGKrBWTGfpOTbPPbyHuCJItarIzrLXyBZyZQTBnwDNiEBbiXhzFPZfvARxFizS");

    if (CpcrmwmH == false) {
        for (int YajzXcLbILgZ = 1752645897; YajzXcLbILgZ > 0; YajzXcLbILgZ--) {
            dNESremhe = LeXKZZkD;
            BOsdoa = dNESremhe;
            CpcrmwmH = LeXKZZkD;
            LMKlsUznhmn = dNESremhe;
        }
    }

    if (gSxqiIGaaKtUTLk < string("tlXxLLeVntKMqkwLZsqNGYQwypYLRedJwZomebJLgfWTxwvPghgnFWIzyBIEKuXyOMVagLgIsOYXtgDXmbmPrnzqkKrcxcWnWshClGKrBWTGfpOTbPPbyHuCJItarIzrLXyBZyZQTBnwDNiEBbiXhzFPZfvARxFizS")) {
        for (int uaKHC = 2131970052; uaKHC > 0; uaKHC--) {
            kNGKuqK *= kNGKuqK;
            WRzLmag = SfVaiEWDaUVHDY;
            BOsdoa = ! BOsdoa;
        }
    }

    for (int vVzYhWEWINtgQ = 1459694121; vVzYhWEWINtgQ > 0; vVzYhWEWINtgQ--) {
        LMKlsUznhmn = ! CpcrmwmH;
        CpcrmwmH = LeXKZZkD;
    }

    return LeXKZZkD;
}

int DHXqgzgVtQevsa::DFtRHgUbFh(int KYwbx)
{
    bool BhmbACAXr = false;
    bool SyXOVsJquyHbaRy = false;
    double RIsNVucXSFlaMGOD = -580067.0825594648;
    int vQBpV = 1362386796;
    double pOTrygQbaoySSz = 134077.21647274483;
    string qspyOFUsFuEMLTXd = string("yzOUyPCjCSeOBNztytxhRkNPDyNBaWDISZEhoQRWtXpfgnZHRQlwLQbbakNwzXpHGqjPREleWzQYuTiLMtKtdEGPawALEYBHQQxWYoW");
    double OwpMtMJk = -870412.2356432762;
    double dlKcDiCsMxegdQ = -626847.5561368428;

    for (int iaqEQZz = 1191280222; iaqEQZz > 0; iaqEQZz--) {
        OwpMtMJk = pOTrygQbaoySSz;
    }

    return vQBpV;
}

double DHXqgzgVtQevsa::srpOLesHLuPnKmXX(double GKtxH)
{
    string OOdZwHUqnX = string("vbXCVbrOvghJLQdgyURsxCElvfiJxzlCvflZnQUyuQzcGNioetqzvMzsdSrwh");
    string pRXrriCrSkD = string("EpEdeAkbBRlcJxjYIJsnXLMdVYqOypeDmvwEuvQOERpJyYBbpHJuRpaHMWgcuogpYRzVnXwJMCSlsNlPemUQpPyoRnVj");
    double iIuUQIEVvqtvoeBH = -281223.8339442236;

    if (pRXrriCrSkD >= string("vbXCVbrOvghJLQdgyURsxCElvfiJxzlCvflZnQUyuQzcGNioetqzvMzsdSrwh")) {
        for (int TseKtwJzF = 498153575; TseKtwJzF > 0; TseKtwJzF--) {
            iIuUQIEVvqtvoeBH /= iIuUQIEVvqtvoeBH;
            pRXrriCrSkD = pRXrriCrSkD;
            GKtxH = GKtxH;
            pRXrriCrSkD = OOdZwHUqnX;
            GKtxH /= GKtxH;
        }
    }

    for (int gdOiqef = 959691780; gdOiqef > 0; gdOiqef--) {
        iIuUQIEVvqtvoeBH = GKtxH;
        iIuUQIEVvqtvoeBH /= iIuUQIEVvqtvoeBH;
        iIuUQIEVvqtvoeBH = iIuUQIEVvqtvoeBH;
    }

    return iIuUQIEVvqtvoeBH;
}

int DHXqgzgVtQevsa::uzaJbxwsvSCtl()
{
    bool rUcjPfPzu = false;
    bool YrjeHlzlN = false;
    bool PdRRjg = false;

    if (YrjeHlzlN == false) {
        for (int rGqkJhslWwvt = 440425811; rGqkJhslWwvt > 0; rGqkJhslWwvt--) {
            YrjeHlzlN = ! PdRRjg;
            PdRRjg = ! PdRRjg;
            rUcjPfPzu = ! PdRRjg;
            rUcjPfPzu = rUcjPfPzu;
            YrjeHlzlN = YrjeHlzlN;
            rUcjPfPzu = ! rUcjPfPzu;
            PdRRjg = ! YrjeHlzlN;
            PdRRjg = ! PdRRjg;
            YrjeHlzlN = PdRRjg;
            PdRRjg = ! YrjeHlzlN;
        }
    }

    return 1920691092;
}

DHXqgzgVtQevsa::DHXqgzgVtQevsa()
{
    this->djLUKMByAtlFlS(-1577566651, -142964.11195701512, string("DbSjxyrcGbDSMdGfUaHPAjfFPBJbUqUENePMMiLWSSpDpgRZbFEeJRgLcVskwhfGzUezIJUbvEaARFXvZPGAcLoTOjrceMbMdtolkLTxaSLjjXcjxUfdpPyiuRTOcwiCWXhYyosfYIWjhWluEkPgqjINFPYBeVEuRhTIldjYMRTApAzRQUmMlnPcxl"));
    this->KFGRVIbscyDPuju();
    this->SiMoasqLqWnKs(-148101.7402260398);
    this->vqMIvMAwYPRyI(false, true, true, -50848.221945225014);
    this->DFtRHgUbFh(-379252186);
    this->srpOLesHLuPnKmXX(116970.23576315251);
    this->uzaJbxwsvSCtl();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CsyMDn
{
public:
    double lnxgbQ;
    double DwYyvy;
    string JfOqXkeCQRRKhgPO;
    double wuxXnRGW;

    CsyMDn();
    bool PQHpGmYHc();
    double MrTSANX(double rVipVxMmXNwYKNB, bool FxCEpsHR, int FpVrM);
    int aHhRKOMzkl();
protected:
    int sBVGa;
    bool qsaNXxyKCCj;
    int ZyGdfYQoaUaDqP;
    string yageEfNSd;

    string DaplshFmSyM(double HSMGzBPAvj, int XQBVHdQQt, bool QvauhwPgCb, string fJSjJA, double WGIoJGv);
    void cZFWNa(double kzxqrVeFikk, bool pzKVnLWsvfE, string GoMmgPGuUGf, bool XwKyC, double RfRWBeIYtKz);
    void rYPams(double zFQBnZrhvkCHrp, double FRlprJpjGfxL);
    int UmvjkX(int NlNkfyCJtN);
    void ScLEEPWLoqaOJ(double aGwVxoJxD, bool nDwhS);
    string fqJOwbPpLYmx();
    double rVeWApu(int EeDPMvy, bool IYKQwqhXsfP);
private:
    bool HPdKbV;
    bool dsiueGYiaJCfTmzI;
    int iAzdhYw;

    string xjqZXUORp(string neyVCapOTdWcS, string DZvEY, double FAkde, bool IBecztjh);
    bool MeRBibRg();
    void lixNmttDCRVk();
    bool vdxeZBcyuzDB(bool ysrXlbIxKMQjxSN, double VyUIuHjUOhcFdSF);
    int MpvdiMzceeyBsD(string czjkaQBSJR, bool hmKZfnXwEPuZVi, double EBbxvWP);
    string LnkkJcQCbKXPr(double VSevIBGsulVC, double biNaWlxvJzhK, int JeoyeRQpojoA, int VHmHPuGKOvKd);
};

bool CsyMDn::PQHpGmYHc()
{
    int DyXYmeLYm = 517159533;
    string LHQsR = string("nqNyzoCCaSZYxL");
    double FxUwZqVVrRycjOI = 371907.2450728926;
    string OhobSJp = string("oEheMlYHlrWeeJcOZuEGwSYibyIITVETGEiaNJMwDMtClIWCZLejfljgdimVrqGKn");
    string vtSujYmZYQQC = string("EFjHSIbKwZsNlVrMQIMNdMbAVmuNoNoGfnmgKuYsfqchDTHVbppgWisfhvWWbCvseMwmHvuGzhrTMsnhGCRRlGRvxLgfbctHqpQTMWvnqjlrSWaicqhROivkQEUnGfSmGuuOGSHGsfbpxcGmrIqUdATmtMvLzBnjpTSNJTYWxRvxTBjOYljazcOWbDlSuYVYDiHPQdEFFmwUhyryTBkDgaXKUaxVwIylIyMNbNZPCmoiURvC");
    double COIqisH = -246116.6569327378;
    int FQuicMKXDLLYc = -1682296853;
    bool QkjnMOBPVfFAStP = false;

    for (int aWGNtZiYqZe = 479791219; aWGNtZiYqZe > 0; aWGNtZiYqZe--) {
        COIqisH -= COIqisH;
        DyXYmeLYm /= DyXYmeLYm;
    }

    for (int IWzjdqLIVB = 75689843; IWzjdqLIVB > 0; IWzjdqLIVB--) {
        vtSujYmZYQQC += OhobSJp;
        FxUwZqVVrRycjOI /= COIqisH;
        LHQsR = OhobSJp;
    }

    return QkjnMOBPVfFAStP;
}

double CsyMDn::MrTSANX(double rVipVxMmXNwYKNB, bool FxCEpsHR, int FpVrM)
{
    bool WqfHnhLpJPNcIvlw = false;

    if (WqfHnhLpJPNcIvlw == false) {
        for (int vNqDhFx = 1845235281; vNqDhFx > 0; vNqDhFx--) {
            FpVrM *= FpVrM;
            WqfHnhLpJPNcIvlw = WqfHnhLpJPNcIvlw;
        }
    }

    for (int KfCApLCa = 2006607182; KfCApLCa > 0; KfCApLCa--) {
        WqfHnhLpJPNcIvlw = ! FxCEpsHR;
    }

    for (int PxSCpCm = 1053863202; PxSCpCm > 0; PxSCpCm--) {
        WqfHnhLpJPNcIvlw = ! FxCEpsHR;
        FpVrM -= FpVrM;
        rVipVxMmXNwYKNB = rVipVxMmXNwYKNB;
        FxCEpsHR = ! FxCEpsHR;
        FxCEpsHR = ! WqfHnhLpJPNcIvlw;
        WqfHnhLpJPNcIvlw = ! WqfHnhLpJPNcIvlw;
    }

    for (int eQKleCnQ = 1454501815; eQKleCnQ > 0; eQKleCnQ--) {
        FpVrM += FpVrM;
    }

    return rVipVxMmXNwYKNB;
}

int CsyMDn::aHhRKOMzkl()
{
    int VVvxZwtjLefSdQ = 670117459;
    string MtXeWxJKO = string("oaBPRVF");
    double CYtWwzHVByqszCR = -906612.9613519413;
    string DpyNkKFFpnGgqO = string("hLbnSXzmNabycItWhyZpkOwSXsCjjfhqxlkYSerGpQXJxgabSrTvxjKUzXBkDdLnuUiHbxBhknKAAoyBAKyBGSttGLhwTTHpPFZFBaurDCELHvrZdWQkHdKOIqxGZoNZzlNzwDwChumUPMxaJjFBDcwXAkWhPJBwxjjqJGBddTwKmmcCABKfhRieQGNLlVnpXQefcCllkGreTHfGkhwGkJoPBQzgpHPkwmXRJgSnRgREnHDluiQDbgvSjBiDP");
    string dohssukIS = string("mFBtNWuTAGTrMEUTZRRxsEwUHmFsGZMThCDOQrEURmFufmzRgWGYmzofYFtSDIrjBNSlnhNxRhUqYhJseAveAifaDIUiwjpKeufVaFDxDzuArWWHSESVZBiBDhEafbMTJuPTbtthZViZUjsgJLkfqKwtUyy");
    bool LYArnfbQGrTGYN = false;
    bool xFgFodJfoMJ = true;
    bool kefRfgSf = false;
    string gSaEGNoGzJ = string("jcjKQgHVEZB");

    return VVvxZwtjLefSdQ;
}

string CsyMDn::DaplshFmSyM(double HSMGzBPAvj, int XQBVHdQQt, bool QvauhwPgCb, string fJSjJA, double WGIoJGv)
{
    bool YlgukAHwsRfDiIed = true;
    double PViTA = 444706.9276868931;
    double oPGZjz = 215114.25828413776;
    double RlqSOoTgzA = -683417.5917735385;
    double BjyJZUlFtx = -1041233.495209226;
    string llUlctAgQ = string("aikbCwrpyxljAenSBcZQPdfvMsReuKyEDYoCMLcAFpbIVuIJgUqzOsjLgklSoKgGfkdnVqHqYOGeEYlrhtTGAjXqkZWiDvjxsceGCPGB");

    for (int qRamGlvN = 1149306164; qRamGlvN > 0; qRamGlvN--) {
        continue;
    }

    return llUlctAgQ;
}

void CsyMDn::cZFWNa(double kzxqrVeFikk, bool pzKVnLWsvfE, string GoMmgPGuUGf, bool XwKyC, double RfRWBeIYtKz)
{
    int triotkislPMpJsY = 1351453470;
    bool dWgETOEHfq = true;
    string VOzfKylhqEbvfA = string("ECqELEuTDVTwhmkneNWuoBHZsVUjqsAKQDnalGmJNfxvjwglukXVcYyypPmCVZCErePVKhSGtxSkZfqhYYXOKEnOtmKyQFGUwcAFyclpfJWCnbMirwLeyjGcrAZlTdHstnubOYjeeIkOlDmPvwIPAiskuYIYSNUzRSNwSKmqEnxhMXemZdKPJolzKMIwcPwTZFBRHuUAgiNXGgQtCRNLbzFwcPgDcS");
    bool nuesxKywAQka = true;
    int gCHZRicOVbkXhLDN = 236417661;
    string vZiTr = string("bYsqjYURXFUuECWZFRVJzhSynmZWTtIKHvTkmyTjJNdIYWYuziqvQEcnaUcFHOaGvcnQDbdKakqBYjBijgKyUsrKyZZznWTqBnQpTDeblNXVGVuDoJZcKtzqNiOwoeAJCFaucyNmjFdhndRBuPUMIkCbpHIO");
    int RxqAQUZvLi = -1329078730;
    double KKsOGkvECXXOyt = -586405.9005157906;
    string FSEDWt = string("YbIJLOAjoNKypkeWIjXTxemkqrcsQrylYriGGcpgxyRhSPekqNQZcWHhDatMBFfaYLfUyFryXOmuDYktXGBffR");
    int QGrDT = 489270700;

    if (triotkislPMpJsY == -1329078730) {
        for (int aBpkbrObqjhga = 1423448312; aBpkbrObqjhga > 0; aBpkbrObqjhga--) {
            RxqAQUZvLi /= gCHZRicOVbkXhLDN;
            FSEDWt += VOzfKylhqEbvfA;
        }
    }

    for (int CMIaThJrSoK = 518494507; CMIaThJrSoK > 0; CMIaThJrSoK--) {
        continue;
    }

    for (int ytpsmMPRC = 1867735698; ytpsmMPRC > 0; ytpsmMPRC--) {
        FSEDWt += VOzfKylhqEbvfA;
    }

    if (GoMmgPGuUGf < string("YbIJLOAjoNKypkeWIjXTxemkqrcsQrylYriGGcpgxyRhSPekqNQZcWHhDatMBFfaYLfUyFryXOmuDYktXGBffR")) {
        for (int SjAhiYxV = 985375675; SjAhiYxV > 0; SjAhiYxV--) {
            gCHZRicOVbkXhLDN -= RxqAQUZvLi;
        }
    }
}

void CsyMDn::rYPams(double zFQBnZrhvkCHrp, double FRlprJpjGfxL)
{
    double RrdiUN = 959656.7164762646;
    bool yWpKRI = false;
    double FrykS = 422703.5232582035;
    int TeZBwHsIpBNgx = 763733381;
    bool XLyHVYXiLYRl = true;
    int ZWNMQnSzsEE = -1140570800;
    bool VsyprlvuFzb = true;
    int ZGeElILbQCsWBdO = 1561973623;

    for (int ChUmWa = 187715637; ChUmWa > 0; ChUmWa--) {
        TeZBwHsIpBNgx -= ZGeElILbQCsWBdO;
        RrdiUN *= FrykS;
    }

    for (int IeZiyzLhbxjlmeh = 1210837986; IeZiyzLhbxjlmeh > 0; IeZiyzLhbxjlmeh--) {
        RrdiUN *= FRlprJpjGfxL;
        RrdiUN -= FrykS;
    }
}

int CsyMDn::UmvjkX(int NlNkfyCJtN)
{
    int LrgUwBXxPIMimy = 59680715;
    int EesXbd = -136016958;
    bool HudwkY = false;
    string GBOxHThMPQjNEj = string("MwMiNmNSwnmUQAAbfcSetoxSQRaLrDZWlwYTWNihjyWuftDOLsOfMIWEhsYVJwyyNQobCzoZIScvZwJDEWHyKQhKGOfazwcRQmclPUvfvDJszJAHpmYjaBbQfdZLYRkrtMarnrPqvEMvLogORkNaSIMFHKyMnYYTIgakfTeThiftSXBTSMFFbQihCBddEaPTKwRTSwLhMNCVaOGlrlmKRgRwPHmIEYsjtPqLjuAUw");
    bool RDpsmMxplwqb = true;
    bool JZubejqI = false;
    bool XuFfBPjnJSvMgilE = true;
    double FcSjyb = -518827.23458606855;
    string WbbPBgXZIBCSPTE = string("aIZVsEzYowyDfKmSQsVaWncSOdNoWaxNsKCM");

    for (int XXXMtH = 792624139; XXXMtH > 0; XXXMtH--) {
        JZubejqI = XuFfBPjnJSvMgilE;
    }

    for (int aiJoAMYQ = 558456919; aiJoAMYQ > 0; aiJoAMYQ--) {
        JZubejqI = XuFfBPjnJSvMgilE;
    }

    if (NlNkfyCJtN > -1497195151) {
        for (int zXtrVtdYxR = 160801765; zXtrVtdYxR > 0; zXtrVtdYxR--) {
            LrgUwBXxPIMimy += LrgUwBXxPIMimy;
            HudwkY = ! JZubejqI;
        }
    }

    return EesXbd;
}

void CsyMDn::ScLEEPWLoqaOJ(double aGwVxoJxD, bool nDwhS)
{
    bool UYHcbuEk = false;
    double dYYLjnEqTRpcBEW = 410196.98282258544;

    if (aGwVxoJxD == 410196.98282258544) {
        for (int lewZuwwQxSeVaRFO = 205276332; lewZuwwQxSeVaRFO > 0; lewZuwwQxSeVaRFO--) {
            aGwVxoJxD *= dYYLjnEqTRpcBEW;
            nDwhS = ! UYHcbuEk;
            dYYLjnEqTRpcBEW = dYYLjnEqTRpcBEW;
            dYYLjnEqTRpcBEW = aGwVxoJxD;
            nDwhS = UYHcbuEk;
            aGwVxoJxD /= dYYLjnEqTRpcBEW;
            UYHcbuEk = ! UYHcbuEk;
            UYHcbuEk = nDwhS;
        }
    }

    if (aGwVxoJxD == -863562.653618734) {
        for (int wdYNP = 1858407; wdYNP > 0; wdYNP--) {
            aGwVxoJxD += aGwVxoJxD;
            aGwVxoJxD *= aGwVxoJxD;
            aGwVxoJxD -= aGwVxoJxD;
        }
    }

    for (int TIMVPLBmHazL = 1927841426; TIMVPLBmHazL > 0; TIMVPLBmHazL--) {
        UYHcbuEk = ! nDwhS;
        aGwVxoJxD *= dYYLjnEqTRpcBEW;
        UYHcbuEk = UYHcbuEk;
        aGwVxoJxD *= aGwVxoJxD;
        aGwVxoJxD *= dYYLjnEqTRpcBEW;
    }

    if (nDwhS == false) {
        for (int JvXSYTB = 1650733622; JvXSYTB > 0; JvXSYTB--) {
            dYYLjnEqTRpcBEW -= aGwVxoJxD;
        }
    }
}

string CsyMDn::fqJOwbPpLYmx()
{
    double XdduEEwnDkV = -647116.3063259512;
    double wTRlWxmqIe = -525382.5234191614;
    double kFdnfVwXrQKTZ = -267069.7081420176;
    bool vilzeedMSsJsI = true;
    bool qvjMESXx = true;

    if (XdduEEwnDkV == -267069.7081420176) {
        for (int qHcWCOHuN = 206848561; qHcWCOHuN > 0; qHcWCOHuN--) {
            vilzeedMSsJsI = vilzeedMSsJsI;
        }
    }

    return string("aBgqcsMWHxaAvvEpVIdzNIOXSYcrXDQIhUDSdXEhIyQZfRGIlpLARbCzBzNBrTXYtvHDRfUhcFXgyHCvOxJPCwkSENyanXXJZzWyGbVBPUpBdKuGvEWGQXUyDXuKlFdJwusWSERFOJJavSwoLsZAFbFogqYDZRrIvwhZCtGTqHNnAhUlJjIxsuDxzwqxAsnlvFEooqTsUWcchSvwNjsbPcwEhSJJQfOheoWJo");
}

double CsyMDn::rVeWApu(int EeDPMvy, bool IYKQwqhXsfP)
{
    bool NxmTtdOLkWkg = false;
    double oryUW = 1022527.7669744605;
    double CDVrygUbsbhPVUL = -409773.595430316;
    string adtEmzeanTdxz = string("oRhmLYXfXddNnoGecNmdEMCcLXKILrcEXfowsdAvTEUZvwrNPThPHcAcBmXVTqmv");
    string TFTwhvX = string("qxBEXMEvxcwpOqciGneMGijkUbBhhmRcqdqNcoQVayyQDhGrbvZinluUovfowvQIwSVBTOYXsExIUiKJzuVoEteejzGRMwxRTeiGUElZJYmzoOlSVrWAIgSmWYwUxamQCZFXhGXnnIljcyWoWsWHoSttULYiUKNOq");
    double mluYhn = -478683.2545701819;

    if (IYKQwqhXsfP == false) {
        for (int ADIsXKbGiuRYXl = 755625101; ADIsXKbGiuRYXl > 0; ADIsXKbGiuRYXl--) {
            CDVrygUbsbhPVUL *= mluYhn;
            oryUW /= oryUW;
            EeDPMvy *= EeDPMvy;
        }
    }

    return mluYhn;
}

string CsyMDn::xjqZXUORp(string neyVCapOTdWcS, string DZvEY, double FAkde, bool IBecztjh)
{
    int exlIQDjYFTTqMDS = -1701706913;
    string bzBXUomNqZj = string("yORGcwVVqjJajQWhVGTZsSluSsACAMIKVVGocvpWHxDLigXlhXMaZaGcWvLclorStiLTLJlxuKkXfHhaDDqBUPYNEFYKlAsQBqPfteGYTyutMrtZRumwNoAWMpGddRWFNXJTCzMnlHPSbBwVNEdGcgfXPKBVIqCUwROyE");
    string tmAXCqHqWwl = string("dAiRtUwlOHJNUWjLtycRxyeTOPNhuyeySUBXGNhjQgVmeHjeoIGwBUKdmdXFVLfWmDjtAUXfKhQwWbnXziWyoABEJZTgDIzgXKVmDUhaUZJKTssmeWnlAhtdGONyBwiqVPcXRKTTwCDTNAhCvqSNXJOMnpeLViVZjOLfaeOSqNuGDdRLWaIMJyJaqlhDUXCzuUVNGgNLOMJWyVwjSracumabCnGzkmrhqeUDijChpILLYiHnsoJmhlhKCwQPc");
    string bEsFmZnVSxK = string("HJvnazHfAwJTmRZGOmNrkZXFezbiBItGrHgqvmiwJjqlaNgqlbfwerJlpJUVjqWcUipFtZs");
    double FMPToxnagIl = 169863.48947049724;
    bool PxwLhRIZd = false;

    for (int xdDBvQOGXLNYOgfp = 650114926; xdDBvQOGXLNYOgfp > 0; xdDBvQOGXLNYOgfp--) {
        bzBXUomNqZj += DZvEY;
    }

    for (int AfuYx = 1299524073; AfuYx > 0; AfuYx--) {
        DZvEY = bzBXUomNqZj;
        PxwLhRIZd = ! IBecztjh;
        tmAXCqHqWwl += neyVCapOTdWcS;
    }

    for (int EhOjiGKsD = 37595974; EhOjiGKsD > 0; EhOjiGKsD--) {
        continue;
    }

    for (int FsyufDHyESoZIX = 863106508; FsyufDHyESoZIX > 0; FsyufDHyESoZIX--) {
        continue;
    }

    for (int PXocRIAmK = 69567230; PXocRIAmK > 0; PXocRIAmK--) {
        bEsFmZnVSxK += tmAXCqHqWwl;
    }

    if (IBecztjh == false) {
        for (int jHojTSQSIanBi = 1507051860; jHojTSQSIanBi > 0; jHojTSQSIanBi--) {
            tmAXCqHqWwl += DZvEY;
            PxwLhRIZd = PxwLhRIZd;
            tmAXCqHqWwl += bEsFmZnVSxK;
        }
    }

    for (int wpxYjhieDR = 1862156783; wpxYjhieDR > 0; wpxYjhieDR--) {
        neyVCapOTdWcS += bEsFmZnVSxK;
        DZvEY = neyVCapOTdWcS;
        tmAXCqHqWwl += bEsFmZnVSxK;
    }

    return bEsFmZnVSxK;
}

bool CsyMDn::MeRBibRg()
{
    double SPmeVRBevB = 65836.75176092645;
    double dIDKP = -731267.5888009472;
    bool znDgD = false;
    string KlgsxNpwiHk = string("cgANdYzwfJHpsuFBovfGDNtAVblhoAeRmSbRJufRFjpOkZtmIojaXZwxIKAgKzENOIBZgJlQJrmKwMSXIJXBzRUIsEMyZkBpmwjuFpLFZZdBDONyJMxarQTuMLIVVXmFeLWOdQTBxuUFkFQKIHQLMdMalDgXGZkzYnCapobQNtCmyvstVnpJxfvOWXrzCSBplMnNwKcItVmifdxpMSteAWFuEVWLQZXRDR");
    double JwHUmKxWYMl = -142543.3727606488;

    for (int RZnSFenF = 1551693461; RZnSFenF > 0; RZnSFenF--) {
        znDgD = znDgD;
        SPmeVRBevB -= dIDKP;
        SPmeVRBevB *= JwHUmKxWYMl;
        dIDKP = dIDKP;
        JwHUmKxWYMl /= JwHUmKxWYMl;
        dIDKP = dIDKP;
        dIDKP *= SPmeVRBevB;
        JwHUmKxWYMl += JwHUmKxWYMl;
    }

    return znDgD;
}

void CsyMDn::lixNmttDCRVk()
{
    int yNSNVcqrWojU = 1409342752;
    bool MmQStcfKqNpSWXm = false;
    int TKGSXPedN = -1919963036;
    bool AaDRfb = true;
    bool AZBiHXJZGur = false;
    int ZqDINfNd = 76922939;
    int qVlkatIVmkkm = 1558079600;

    for (int LnUuPJvoigoRxLG = 1812809823; LnUuPJvoigoRxLG > 0; LnUuPJvoigoRxLG--) {
        ZqDINfNd = TKGSXPedN;
        yNSNVcqrWojU -= TKGSXPedN;
        AZBiHXJZGur = AaDRfb;
        TKGSXPedN = yNSNVcqrWojU;
    }

    for (int WnHdABQRajrwl = 1329403032; WnHdABQRajrwl > 0; WnHdABQRajrwl--) {
        ZqDINfNd = ZqDINfNd;
        MmQStcfKqNpSWXm = ! AaDRfb;
        TKGSXPedN -= yNSNVcqrWojU;
        AZBiHXJZGur = MmQStcfKqNpSWXm;
    }
}

bool CsyMDn::vdxeZBcyuzDB(bool ysrXlbIxKMQjxSN, double VyUIuHjUOhcFdSF)
{
    string AnaLrLVGSskTITG = string("fdPENuDkRBXNjzFDNJZIvecEzCQRlRaHcMmumOSGDLYySLqVaxdGsKNUBtseJsmWpWOkjtsqzzXmYFkAHYJNlGAvTRBZAyagWaCCMcmkGxxrjPGvbvbiUYerFJEwnzuvJXwlGJKlPSJcLmMMlpAGuiHziiLBOmqhXUZBuNvaCZYkMziuNPXAHkOdJcVVCIoBPPUHpYed");

    if (ysrXlbIxKMQjxSN == false) {
        for (int bHqgdr = 1791276633; bHqgdr > 0; bHqgdr--) {
            AnaLrLVGSskTITG = AnaLrLVGSskTITG;
        }
    }

    for (int TvDiDJCKaZriJY = 138811676; TvDiDJCKaZriJY > 0; TvDiDJCKaZriJY--) {
        ysrXlbIxKMQjxSN = ysrXlbIxKMQjxSN;
    }

    for (int JlHmJggyGTTM = 366552896; JlHmJggyGTTM > 0; JlHmJggyGTTM--) {
        AnaLrLVGSskTITG = AnaLrLVGSskTITG;
        VyUIuHjUOhcFdSF = VyUIuHjUOhcFdSF;
    }

    if (ysrXlbIxKMQjxSN == false) {
        for (int NSlKr = 1814383816; NSlKr > 0; NSlKr--) {
            continue;
        }
    }

    for (int JJMrITjYOmplf = 712982316; JJMrITjYOmplf > 0; JJMrITjYOmplf--) {
        ysrXlbIxKMQjxSN = ysrXlbIxKMQjxSN;
    }

    if (VyUIuHjUOhcFdSF != 540612.6974062858) {
        for (int zsNVpcIAdMGaKqnz = 2015471901; zsNVpcIAdMGaKqnz > 0; zsNVpcIAdMGaKqnz--) {
            ysrXlbIxKMQjxSN = ! ysrXlbIxKMQjxSN;
            ysrXlbIxKMQjxSN = ysrXlbIxKMQjxSN;
            AnaLrLVGSskTITG += AnaLrLVGSskTITG;
            ysrXlbIxKMQjxSN = ysrXlbIxKMQjxSN;
        }
    }

    return ysrXlbIxKMQjxSN;
}

int CsyMDn::MpvdiMzceeyBsD(string czjkaQBSJR, bool hmKZfnXwEPuZVi, double EBbxvWP)
{
    double hvPyFKzmroOBNW = 423135.5036716099;

    return 1799520928;
}

string CsyMDn::LnkkJcQCbKXPr(double VSevIBGsulVC, double biNaWlxvJzhK, int JeoyeRQpojoA, int VHmHPuGKOvKd)
{
    bool SjqtRRuMuveoRQC = true;
    string xkviX = string("RCLaIxcttVHnQVBBAYZFaOxdREJQlXwXZckhjWMqDjDPpIJZeoQphSPicKjEGUznMpTpkyLOsAxReFGBNtCSvOphdOlDBvEvRYmfLCWYyXROQmtTvueaTGinmJkNQYnYqXTYNyxAHdSYETfAEFoXcTCiPaVPNdHQiOTwZqKzkInDnFBNpFzohIZSdGfLUplPEmXaTSpDiwsErBhDWeYgWkI");
    bool STDPHAQtRzCey = false;
    double rALpf = -846789.9571108118;

    return xkviX;
}

CsyMDn::CsyMDn()
{
    this->PQHpGmYHc();
    this->MrTSANX(828942.2577520001, false, -2021091530);
    this->aHhRKOMzkl();
    this->DaplshFmSyM(-712304.7791554751, 796479640, true, string("HTPVZmkyFISktivolYeXKRjIfzbbdUfSCQuoBIABHEvfmYCIfvbEqOSzZJZjHfjACIdVyivtmZKdPHHISxwGjurecjRwGjabBx"), -194879.02229053125);
    this->cZFWNa(578619.3267021817, false, string("rufymmqccZKXJTgrzsloApvKjZQiDxKJxxzhrHWbGCwyheaEndcOienAB"), false, 457629.14962684613);
    this->rYPams(-76498.42998607377, 918140.2747214214);
    this->UmvjkX(-1497195151);
    this->ScLEEPWLoqaOJ(-863562.653618734, true);
    this->fqJOwbPpLYmx();
    this->rVeWApu(444714012, true);
    this->xjqZXUORp(string("dXPkcIYFqCSObFZvomoSfJIvNhpLirEYcHSsrJGbmhIkvGVXZoneCSQZkDsZYzTrQydWeQyKVUhOohSnIgqfsmkIDNDuSAtYBYKwQuiKjEdOiWXOyRRamrTnWQWiTYDmvIcLaklnYYJuvBVHiWlhErqKqtVjokjNzJSikvJgzroClcTQbkhWFvHjGwMdCRgqsmVSZczZPKWFLAcPxytJisaiSfINXvdqJCmXORxqhQwNIFwBlr"), string("NJPrHfxAipehBvLGVWsuYaYpEeAYvBrqJjhIZrpPbmXatuyHu"), 824617.064715388, true);
    this->MeRBibRg();
    this->lixNmttDCRVk();
    this->vdxeZBcyuzDB(false, 540612.6974062858);
    this->MpvdiMzceeyBsD(string("oAEJEskqxSfJoOulYqFbqFUdBXsYMtcyOfNgFEOPmBEwxyYiHIvasduDsiXGHXrACQdsGUmWtFEpMMirdCdTRL"), false, -502317.9585312093);
    this->LnkkJcQCbKXPr(-812441.1077507568, 987849.1938554321, -1809897897, 13146403);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class sfNOobU
{
public:
    int ZynInXPMpltDFJ;

    sfNOobU();
    void mzJRixen(double dKWEoCEOpfWQUim, string wItyOruESAjID, string wJwXx);
    string vtaeEltM(string tTsUdKMGK, string oxgqMsQdGFVj);
    string FECJptDC(string aNZvUb, bool lElmReJ, int dxUvd, int rlqDZAqOh);
protected:
    double MKtmMVUKO;
    string AqrtbTYDmuX;
    double BLGtAoBfPZxY;
    double csgMbL;
    string CSvKekvw;

    int zfQOZlwNMVFnNiQ(bool WphZxLvz);
    string sJmtCbrB(string eUWuUX, string bvlemYa, string hZIuLK, bool pHiOrf);
    int siOVaeG(double WRIoLrXkpC, int NnLhzsIK, int YVpBwRz, double pyxsnOuqo, int fCCzMG);
    bool PVMVZFbvU();
    string KFlSYJsSEH();
    string llReRAFZTgitgnR(int bhgHlKkBVUoTeTmz, double OWZSSsxoU, bool GQOQfCFdi, string ySiaENuOCpIRcBvY);
    void OIdzIReODMcVZCY(string nHCycAyvuvt, double qNoAsY);
    bool cbklaPdKl(double CIqGQNKvw, bool esDxt, bool sXCeFSvemPaI, string FzStEK);
private:
    string uGRCjfw;
    bool qMRoWGPlHLmEV;
    bool DGIijuAeHO;
    double jvBIvQLuuAAbj;
    bool KEeSu;
    string ARuLQE;

    bool bOBqiMAHxvuyHJnH(string bIvLBsVk);
    void ZUbyJegYj(int HDIBTqf, string sPsgCW, double MHPYwamplAXAWl, string JAHMBQGb);
    bool XgHxfTZxmRTHe(int YfxhivmtFWmaMkS, double bNBNBtMWyipiaIU, int BIASHyNifQZZI, int DSpvSjUKEfP);
};

void sfNOobU::mzJRixen(double dKWEoCEOpfWQUim, string wItyOruESAjID, string wJwXx)
{
    bool LxNFgjwpuVnQftNz = false;
    string tEfuhHCtgrOB = string("PyOFpBxzvKHuaYlUIZKLZhxLbmGADwLIUzRLPbwGkpGPxmowjfjUjwEyePDOeMMqSrzbiVwrRmzwPlSA");
    double oRegb = -690042.9438645784;
    string PcPyZUm = string("pUWDcarHyNiWxqmvdeeFwZxLYgHlJGcxHlFuAlxYbhaHUImAiRj");
    bool riXLnoIfqFWDG = true;
    int gqUleqYmfmUj = 1629081151;
    int TVMEUNJFMlYzCQlH = 1483976352;
    double oidwF = -358118.253005043;
    int LEBnnWwB = -1003802685;
    bool SsBVlGQPaghxJx = false;

    for (int KmMOynoDCXKCvc = 136424327; KmMOynoDCXKCvc > 0; KmMOynoDCXKCvc--) {
        LxNFgjwpuVnQftNz = SsBVlGQPaghxJx;
        gqUleqYmfmUj -= LEBnnWwB;
    }
}

string sfNOobU::vtaeEltM(string tTsUdKMGK, string oxgqMsQdGFVj)
{
    int ibctjtG = -121066716;
    bool mMEICXdLiFYGjlt = false;
    int deXltaj = 395193654;
    string roTTqyLlrCYt = string("mdanOmWBCyHXzwICJtYTFhIrzpvVoEMIMuwbsvYKdRgluTyFiExZSqPqhhJkLbSUEtpGsYKcwGAIpEUBsFoqxjRysjHAvoURHTSZwgNqpmVwVznidLAcslYgVXKNbrTIeXXYxzHPBecphjtjFDjWNUCxeiJrdzcxsnGwUigacxsRozfAwlzqEuhznjGfmxXfXVeOiAwMXuvcUdsqzRFfP");
    bool jsUIrdS = true;
    int mXCpRLVLAd = -938922494;
    bool wpYojpy = true;
    int vjniYFLBEvmcIQm = -1923764428;

    if (ibctjtG > -1923764428) {
        for (int nKuPrgXtqf = 511023505; nKuPrgXtqf > 0; nKuPrgXtqf--) {
            vjniYFLBEvmcIQm *= vjniYFLBEvmcIQm;
            ibctjtG = vjniYFLBEvmcIQm;
        }
    }

    if (jsUIrdS != true) {
        for (int jLYiAAAtXFvlIbag = 800820846; jLYiAAAtXFvlIbag > 0; jLYiAAAtXFvlIbag--) {
            continue;
        }
    }

    for (int uGakYuUtF = 1428040014; uGakYuUtF > 0; uGakYuUtF--) {
        jsUIrdS = jsUIrdS;
        mXCpRLVLAd += mXCpRLVLAd;
        deXltaj *= ibctjtG;
    }

    if (vjniYFLBEvmcIQm == -121066716) {
        for (int YrleLYADTQzcCD = 836892798; YrleLYADTQzcCD > 0; YrleLYADTQzcCD--) {
            continue;
        }
    }

    if (vjniYFLBEvmcIQm >= -938922494) {
        for (int aFRPLzuLFTlZH = 1591469585; aFRPLzuLFTlZH > 0; aFRPLzuLFTlZH--) {
            mMEICXdLiFYGjlt = jsUIrdS;
            tTsUdKMGK = tTsUdKMGK;
            jsUIrdS = wpYojpy;
            mXCpRLVLAd /= vjniYFLBEvmcIQm;
        }
    }

    return roTTqyLlrCYt;
}

string sfNOobU::FECJptDC(string aNZvUb, bool lElmReJ, int dxUvd, int rlqDZAqOh)
{
    int ysxyJqhBZKQhSfY = -842484640;
    bool kXOpYlsGx = false;
    bool LvZhZIkuLcLtO = false;
    bool VjSPVi = false;
    string RvJOGvqrY = string("OCyIUUSENPAAJqCSRnzmwygqiHmkjuFeEKuOVGECvBSJDKqoEZxRIvewsMKvOpqVrzLzWbCWxhQJbhPIAVfvcTlGb");
    bool RrTSAsguHYXNbuOU = false;
    int zLgBzUYrKg = 1049563538;
    double HXqQXZhmduHRT = -621427.8594896905;
    string KTFxUWaW = string("EpJgjGudrhjIUOvECzylFUMQAjfWynGBbNlngurTokRaOQHzBHGOzJQoHsZeaItiBvqJISYbbNpgmBQrVgProrvwxhJkOZkRSBHiWfhqLkbEzjuQWdnOXfgggsTZsVaPNVtxKTBmbiqvRuxWVfHWCbveGqbSh");
    double LHRrJb = -488100.4834652576;

    for (int KBajkRqkNTpBnh = 622945520; KBajkRqkNTpBnh > 0; KBajkRqkNTpBnh--) {
        continue;
    }

    for (int aHxZxcm = 1977394019; aHxZxcm > 0; aHxZxcm--) {
        KTFxUWaW += RvJOGvqrY;
    }

    for (int SkYMuoSgF = 1388243221; SkYMuoSgF > 0; SkYMuoSgF--) {
        continue;
    }

    if (VjSPVi != false) {
        for (int rnEQcthNscasQYVB = 809108618; rnEQcthNscasQYVB > 0; rnEQcthNscasQYVB--) {
            kXOpYlsGx = ! kXOpYlsGx;
            rlqDZAqOh = dxUvd;
        }
    }

    return KTFxUWaW;
}

int sfNOobU::zfQOZlwNMVFnNiQ(bool WphZxLvz)
{
    string EGuhE = string("aKuGusDlGpAiopfzmiUtYQgtyzwLvCLkTWFAESVbCOSQqlaJXtyJflrXBUMsVyIekuJDFipnwdRhQkwboqESWpNmKqGjAEPEcukezZZNwjRxUxAGdSVflnFItZkqgfRrzRKnYYrLUcpLBVKtCogvQVwSfkfrBOmpIl");
    double CmMHfbWhSCpwGKjr = -238851.4775087149;
    int nnpVGaNKvqmgWc = -854857768;
    string SydzBCbFWUuD = string("CicuKUSnTOFluulHMlVNkBZii");
    double NFkrodei = 660978.5513982604;
    double TiDdNbDL = 873192.1792830431;
    double XQvhTuMgtIqkL = -882372.403021547;
    int iNGRidzzD = 250766398;

    for (int upYHOtgH = 1973325598; upYHOtgH > 0; upYHOtgH--) {
        XQvhTuMgtIqkL -= NFkrodei;
    }

    if (NFkrodei >= -882372.403021547) {
        for (int vFGTGTnIiRxB = 457566268; vFGTGTnIiRxB > 0; vFGTGTnIiRxB--) {
            continue;
        }
    }

    if (EGuhE == string("aKuGusDlGpAiopfzmiUtYQgtyzwLvCLkTWFAESVbCOSQqlaJXtyJflrXBUMsVyIekuJDFipnwdRhQkwboqESWpNmKqGjAEPEcukezZZNwjRxUxAGdSVflnFItZkqgfRrzRKnYYrLUcpLBVKtCogvQVwSfkfrBOmpIl")) {
        for (int VsgWQ = 1700195725; VsgWQ > 0; VsgWQ--) {
            continue;
        }
    }

    for (int riHNgCAM = 368041306; riHNgCAM > 0; riHNgCAM--) {
        TiDdNbDL -= NFkrodei;
    }

    return iNGRidzzD;
}

string sfNOobU::sJmtCbrB(string eUWuUX, string bvlemYa, string hZIuLK, bool pHiOrf)
{
    string zVOziYzzDF = string("FqiAIhGbeYsBaSUlwLRGHBlBWvbonmLxDZImabGdkjYAmQjFSIfOUa");
    string UcepnVJHLJ = string("tgDcILDArqAJgxVvQUhYmWmWSINfUEcsrrLaPxAiJdnTldHCWVjPRxrzLBvwJ");
    int vWYFXDXSKbFnMD = 313997316;
    int Lsdexwws = 1538296473;

    if (hZIuLK > string("FqiAIhGbeYsBaSUlwLRGHBlBWvbonmLxDZImabGdkjYAmQjFSIfOUa")) {
        for (int WLYbRcqCP = 1945480802; WLYbRcqCP > 0; WLYbRcqCP--) {
            UcepnVJHLJ += UcepnVJHLJ;
            UcepnVJHLJ += hZIuLK;
            bvlemYa = eUWuUX;
            hZIuLK = hZIuLK;
        }
    }

    if (hZIuLK >= string("htsJTztGUrnjSeELIsPyxujTynEDjCyNVClbanpjisvDOElFSCNjCueKnRfdnzyguDEliQCYaXegKMbVHmPjdLxdBQhVhfjBUXnaOfSwDeQ")) {
        for (int XnGYk = 654665318; XnGYk > 0; XnGYk--) {
            continue;
        }
    }

    return UcepnVJHLJ;
}

int sfNOobU::siOVaeG(double WRIoLrXkpC, int NnLhzsIK, int YVpBwRz, double pyxsnOuqo, int fCCzMG)
{
    int qrDgbXTeLmm = 1985483041;
    string ZSckBoarlDO = string("fmipGjBMFRMTKoOIKZLTfCWWTlVIHUuwnkiyOFOckVuEusImOhIPYKjpzbDpcLvTWMTUOveyazeOpekTHRMludICnXpeTFYPiQTKtIJfzlMwJVtRwUeBfXqpjrwqZZMPKzhbUqcHhmKyrODxxBrcUIgBFdeEImcbPmuKOtVqUyWlzjuoZwxWiCtIwxLdyDEdtLaorsrBaieZTMUPwaQeRBraRs");
    double fsHcsnZCT = 837730.6232412806;
    bool JGNHj = false;
    string uMvLeoKYlzmhYXkl = string("mtdrlMAVrjiqdDYhELDYrEqXbeScjHTkexLYXgoGfMxmiAOhGJRmeAQoIohEnvvuebHEgQSgRMZuNCJeVxEiWJYlOavTOtmgUo");
    double MqRWgMG = -614404.4712197646;
    double mCMgqLqnhrDf = -670531.5754502302;
    string YiejBzJwYbUnIdlh = string("eGvCUUCZATNeYCITWYqKDRGTZSWoEloLMdWFohufVvVkTPZsBoLeBmuUtwVxomgNssGeiloeAEWoMCtYMhFAOBKonEDpiQgyNFsFFtpoBNMNmTxRHYzRemcDJskJSvirYcxDbOecLylAsqqpXrBUStzxMGdzJARoXWKMCBeDxGdMulFHxtCRNRZExzcsgLnRsVipgrAwTeGTqatCgzwMRr");
    int qTwMNQVJZ = 202405933;

    for (int dDroeegUyL = 1163354934; dDroeegUyL > 0; dDroeegUyL--) {
        fCCzMG = fCCzMG;
        uMvLeoKYlzmhYXkl = uMvLeoKYlzmhYXkl;
    }

    return qTwMNQVJZ;
}

bool sfNOobU::PVMVZFbvU()
{
    string hLXPHjRA = string("YIiDYPOZrldixjrP");
    string jHRbiO = string("HnlEFZCEZnPcOsrVRGqALtCSVvavybutOLRFOOXUDinaYexjyCtFAprdwsouCFAPGPkQizDBHRqHHRDLFuhXpMZidOTUGzQhnccTLwPYiGCfrlrVezsNOvlNxKDOqgOxXCLqrlxGMAdtp");
    double jtARQEJVetxykDrr = 858121.425531875;

    if (hLXPHjRA < string("YIiDYPOZrldixjrP")) {
        for (int SbifUGURVYivPLtz = 1622577699; SbifUGURVYivPLtz > 0; SbifUGURVYivPLtz--) {
            jHRbiO = hLXPHjRA;
            hLXPHjRA = jHRbiO;
        }
    }

    if (hLXPHjRA != string("HnlEFZCEZnPcOsrVRGqALtCSVvavybutOLRFOOXUDinaYexjyCtFAprdwsouCFAPGPkQizDBHRqHHRDLFuhXpMZidOTUGzQhnccTLwPYiGCfrlrVezsNOvlNxKDOqgOxXCLqrlxGMAdtp")) {
        for (int ubKtcRajxsJm = 177449820; ubKtcRajxsJm > 0; ubKtcRajxsJm--) {
            jHRbiO = jHRbiO;
            jtARQEJVetxykDrr /= jtARQEJVetxykDrr;
        }
    }

    return true;
}

string sfNOobU::KFlSYJsSEH()
{
    int xbVLDzXdQMyABJmy = 1337944901;
    string yBaAwM = string("OkFaXFpWkqkJSszxwusjgcZAMjVJ");
    int oQdhHYQaMKcy = -920868196;
    bool tRpsgIyTRpseCKW = true;
    int hIiGgj = -254806434;
    double KWPfpXmr = 803916.0789452716;
    bool VIlDeoiCGwHSzyu = false;

    for (int NSsneZhRGJ = 828221698; NSsneZhRGJ > 0; NSsneZhRGJ--) {
        hIiGgj /= oQdhHYQaMKcy;
        tRpsgIyTRpseCKW = VIlDeoiCGwHSzyu;
    }

    for (int rfjIgBVnbx = 451139713; rfjIgBVnbx > 0; rfjIgBVnbx--) {
        tRpsgIyTRpseCKW = VIlDeoiCGwHSzyu;
        xbVLDzXdQMyABJmy /= oQdhHYQaMKcy;
    }

    return yBaAwM;
}

string sfNOobU::llReRAFZTgitgnR(int bhgHlKkBVUoTeTmz, double OWZSSsxoU, bool GQOQfCFdi, string ySiaENuOCpIRcBvY)
{
    bool JYrQntyUuOoZL = false;
    string DEnSilYfLRaoMyk = string("hNYmSjLAnMxaNTBVycvcsAkgslIyXFlwkUgKoLkzcQDOJBUCpXrtuuOdYMBsixNTjPcQfLKfsGnlbBDgtRzkdByNuvmZTJvMqIsp");
    string gSSqtEkINeYO = string("KUuDOYaRjzAetAOOlsNzxZUxlpPDPsdpCwNzoTGnoOUWrFtjOtXHJNZohHgpWPuRZdpTUqfKGuoUSEmEHKAATCXSmXZqGWjwDuthQSZmpocsQzRdvPJnycAKHwGnJKevXvgVOiiAmpwrvLKQHHqFjsxFsqFxGelgTVbpSLSfgLBHrvJoQfZoYx");
    bool gVoovfM = true;
    bool VfjZpmgW = false;
    int VHFLc = -86029298;

    for (int fumIR = 280922447; fumIR > 0; fumIR--) {
        gSSqtEkINeYO += DEnSilYfLRaoMyk;
        bhgHlKkBVUoTeTmz *= bhgHlKkBVUoTeTmz;
    }

    for (int kbXZKCcRfnarW = 750538409; kbXZKCcRfnarW > 0; kbXZKCcRfnarW--) {
        DEnSilYfLRaoMyk += ySiaENuOCpIRcBvY;
    }

    if (GQOQfCFdi != true) {
        for (int HyNVWrPrZnvIO = 1711502262; HyNVWrPrZnvIO > 0; HyNVWrPrZnvIO--) {
            VfjZpmgW = VfjZpmgW;
        }
    }

    return gSSqtEkINeYO;
}

void sfNOobU::OIdzIReODMcVZCY(string nHCycAyvuvt, double qNoAsY)
{
    string eiCFCqYA = string("SKBtolJChZlckmuLMDIBIPOmtTFKMeLtihHHnRqygKJnoqeVdcaGullftXdNROMKJideftQlhXSedaqIprygwKzDKWzNmxCyvbmFSYsSxyKlHKlUcaabPhCWmvRMabIIscWXqlJDMIBOmuspZ");
    string wWHIDnN = string("JlbVcKgxnTZpHDMoGsviguXjqfRqkhlKXzvfeOXhvWWUIKMluMJKYNCXGGcBEDXlDJJgzqKLtIXSMezBIfYzqthpmkLokZAlhwkOgPHzoxTBmHpPHaqHYhRATUPJyAyyRPsXwSxExdHTZlOQJgabonXBDQweBVLeYRXGeDRGGhsCFXRjGsVxHHwlGJIlDmxObHiJLtIinMBYaAqEwSBNBsSaoGxVtDGmokKDDpxi");
    string bWIidtlpemspzEqk = string("jaQLPvzieMEJemnwZcxvTdGeTVGZYVNpDKEPPjwKdhTTqGqdtChWvlLItWywELIgDAbojssMYGPujAWUYMGvzEOecDJelIqtSMpjYTkWiQIqeTntFGoBWoiUFCrjGGnXXyEmgTbWuJwpzoYSd");
    string aPlVK = string("OupvKJjPAfHAXucgQqSdBQYRIJyNLJUVJKcnfxOrWSDIVNjvjgDVYwHmkQCGSGKmOdPWRvWtFdiISmHozsEctNyuGWIzNGXqkRVsOUfDIQEPHTQwHyOeIjEULKeFrmYTPcQegqRvbQIxRGTZtoDyHFivlwhWbKEykLoqLGFuCUCLsIDgkvcFybEPfNIEgIwvVgHrKRJituL");
    string ZqVMfXKHaqtdwqc = string("iMmgdaeMz");
    bool huFvMybfHzAp = false;
    int PQsEqf = 933787033;
    string yxsXTemOzsyqH = string("cgercXDxrSYPqwjfShyOkqFBMeYQIJFwsxCDmyCYYSjAqDpmKjllrjwIXqJThQysQGKklfvtczRwfnUpNxjSESJNItpNwNputPrWIKPcOvrOZwbCzsIyvWvyOWZdBRJXNmxZCcWBNJhpJeuNGgDZmDTXEYWSuUAszcRJNTSrREHAIYWpOFYaELwDlEYYcxgE");
    double cLERgOe = -529873.2462673504;
    bool BCeUzqrj = false;

    for (int TELdXidxjWM = 1108949255; TELdXidxjWM > 0; TELdXidxjWM--) {
        continue;
    }

    if (bWIidtlpemspzEqk < string("cgercXDxrSYPqwjfShyOkqFBMeYQIJFwsxCDmyCYYSjAqDpmKjllrjwIXqJThQysQGKklfvtczRwfnUpNxjSESJNItpNwNputPrWIKPcOvrOZwbCzsIyvWvyOWZdBRJXNmxZCcWBNJhpJeuNGgDZmDTXEYWSuUAszcRJNTSrREHAIYWpOFYaELwDlEYYcxgE")) {
        for (int SjGDDQkFKHCoeY = 139501599; SjGDDQkFKHCoeY > 0; SjGDDQkFKHCoeY--) {
            ZqVMfXKHaqtdwqc += yxsXTemOzsyqH;
            aPlVK = aPlVK;
            huFvMybfHzAp = BCeUzqrj;
        }
    }

    for (int ZyAtXwQAQ = 1060952174; ZyAtXwQAQ > 0; ZyAtXwQAQ--) {
        nHCycAyvuvt = wWHIDnN;
    }
}

bool sfNOobU::cbklaPdKl(double CIqGQNKvw, bool esDxt, bool sXCeFSvemPaI, string FzStEK)
{
    double JmSYzfmg = -594393.5761188815;
    int JoHbnCohvXhHuc = 781134338;
    bool pbPlPlE = false;

    for (int UzvewZjcxXRh = 54960221; UzvewZjcxXRh > 0; UzvewZjcxXRh--) {
        continue;
    }

    for (int qKWxztNnKb = 1009259046; qKWxztNnKb > 0; qKWxztNnKb--) {
        CIqGQNKvw = CIqGQNKvw;
    }

    for (int AUWeoA = 1306610359; AUWeoA > 0; AUWeoA--) {
        pbPlPlE = ! sXCeFSvemPaI;
    }

    if (CIqGQNKvw <= -594393.5761188815) {
        for (int kZlrYSbAPDiHcXF = 2110965160; kZlrYSbAPDiHcXF > 0; kZlrYSbAPDiHcXF--) {
            FzStEK = FzStEK;
            CIqGQNKvw /= JmSYzfmg;
            pbPlPlE = ! esDxt;
            esDxt = esDxt;
        }
    }

    return pbPlPlE;
}

bool sfNOobU::bOBqiMAHxvuyHJnH(string bIvLBsVk)
{
    int bHVlbabdinY = 1755368223;
    int zfVfnUQIn = -1067928959;
    string flZyoxxuMyxOlX = string("WWDiCHPwzAuTpksmbFNRDwvqHKXFiWGBttiaHadmneKkrTPzbFZxnpciXFcRIzwdBBJOduWVJainEQHWuZnngFcvOZddGmAcUBardsF");

    if (bIvLBsVk > string("WWDiCHPwzAuTpksmbFNRDwvqHKXFiWGBttiaHadmneKkrTPzbFZxnpciXFcRIzwdBBJOduWVJainEQHWuZnngFcvOZddGmAcUBardsF")) {
        for (int bmgjaKtNs = 1388354586; bmgjaKtNs > 0; bmgjaKtNs--) {
            zfVfnUQIn = zfVfnUQIn;
            bIvLBsVk += flZyoxxuMyxOlX;
            flZyoxxuMyxOlX = flZyoxxuMyxOlX;
            flZyoxxuMyxOlX += flZyoxxuMyxOlX;
            flZyoxxuMyxOlX += flZyoxxuMyxOlX;
        }
    }

    if (bHVlbabdinY == 1755368223) {
        for (int XhbhhOXGIYg = 1497863244; XhbhhOXGIYg > 0; XhbhhOXGIYg--) {
            bIvLBsVk += flZyoxxuMyxOlX;
            bIvLBsVk += bIvLBsVk;
            flZyoxxuMyxOlX = bIvLBsVk;
            zfVfnUQIn /= bHVlbabdinY;
            flZyoxxuMyxOlX = bIvLBsVk;
        }
    }

    return false;
}

void sfNOobU::ZUbyJegYj(int HDIBTqf, string sPsgCW, double MHPYwamplAXAWl, string JAHMBQGb)
{
    string UkJXvwRbycr = string("NJmdOSoCAngGRcOhcBBGFWyoCnAHtaKsQkrAjJLQMjukiSRCaYTkHhOcjIAQRiCFUICSmyILEyjkrlswtdmVDlkRhhcfLLVxUCdVJQSPASitvoIvgredliCEaTtyZezNgsBjkYmyISCtGhIXzYMLdMpcENGjIvBZmgSQMLFSqgGzNvMbyfnqSWpRBDUjrYwikIQLqXoMukCxKByb");
    string QaHQLenfNafORWjn = string("McgaehXFfjzPReDrwaGXpnBXsqbMHqscGqSElledbCQfNAVguFfmDyeHzwCiinoWECIeXzggfzLYLL");
    bool aseeHOUZFkGaMRsG = false;
    string aXQVZmVSyC = string("aMwqTsrgVAcYgSBFdPhyMYVLqAMvyXUjmgxLsAvMinlDyxmLenzpcLKVtMjRTCBfKamTJeRUhFPEqdkEXZhbMChmOxGGLygYUvYxhrWTanjyuePJwmLorfZDJjbddhvTMWwYvUopXpvQqisutjMFToUghdZDETjtw");
    string qycqpKVPTDXeru = string("EVnxBhrCVbbEeBoqUpKKjqrVfMXRvqvThlFRfjlugGydxkjfLqFdzOAFIPuzkgBrBMovTEguJZmyzTzjlJhMjKxWYgnoZuSbalcxfPVzKxYljMkF");
    int XoMAWOXtll = -1078146971;
    int nPzkVpUhGVtYOZmR = -1481885926;
    double IzbKoHp = 557770.064697957;

    for (int RQCfzjKQaKDwmyW = 1611606781; RQCfzjKQaKDwmyW > 0; RQCfzjKQaKDwmyW--) {
        qycqpKVPTDXeru = qycqpKVPTDXeru;
        JAHMBQGb = qycqpKVPTDXeru;
        sPsgCW += UkJXvwRbycr;
    }

    for (int bbDYvk = 1189041865; bbDYvk > 0; bbDYvk--) {
        sPsgCW += qycqpKVPTDXeru;
        MHPYwamplAXAWl /= MHPYwamplAXAWl;
    }
}

bool sfNOobU::XgHxfTZxmRTHe(int YfxhivmtFWmaMkS, double bNBNBtMWyipiaIU, int BIASHyNifQZZI, int DSpvSjUKEfP)
{
    int ksIuTtutaVCNtF = 297590123;

    return true;
}

sfNOobU::sfNOobU()
{
    this->mzJRixen(-167925.34103743423, string("YrGQveLahJMylNWrgCuFcxbYWhwMVftScNoSwBAtzPEDrxPNojXvHcvjYklapwmQdNxhSRzMGFDjSOI"), string("DVVhuvtQkhKrJDmMvVCUmUlKuOrvxSQVPmIdsxUDIgAjXTsDsDdUNTVfshTlUimONdmneiaCcNxDepjvjnvYgiHsTgxrMAqvYFMEKpLxiYAKDPkohRxpdRSSmXgaNYnUvTzrowRGUWaFgrydvJAkvhhVtGbpozIaldJYlxoSVDmXHjkOdBiUnhAWyLNDiXFqNXsgEuKZYZIpPKFRs"));
    this->vtaeEltM(string("wYFquUFWsjtDkKTHriHDSoQWZUvQHwxSjNbazMFXWkPMZtszPSSposscTqdAwywhlbAIHNsoBUkgiAXKIrIOAAhFdNpExElSKJIpcZMeZIRkqqBWkzQfaQuarfFsXABWCCDmvGAbpmvoDJKlfwWYQvW"), string("DDuNBcsAdXjVVEjKllAoWPWLZgIVigtzzXZAHzaLclWGYKExZLDIvIOuIyPYCfqihvYskfipagRkAsPZMihrWyEXDFHhOwYTJjhNzlOuAHXgoYzLywOBcaNIxLOMCDUvbvmjJhlCqAORwtKPt"));
    this->FECJptDC(string("voUzqMewNcFDkxCYnhKVONkiRpGOvWHZziqgbSHRMCEFAxAdlrVdtwYUnWzOrOXvEAPNNDuqXSkMRTvv"), true, -1419044893, 350249383);
    this->zfQOZlwNMVFnNiQ(false);
    this->sJmtCbrB(string("kTVVPUdVRUKdbmkamUHSsaeooBdoRBnNWHiuMUwBvbnaBqTUdkyqfgFCCBUMKLvYFopRebPwyPWZMUaNKHLTZplzOWJZwGKUgdDpKLhaw"), string("ZvFFIdkHqoOxPWjYowkiJtjwxPzvBMSRysGXQSacGQPqSPGAenyWMKJbcbttLqbdnimNvTWFabdstNQRuyyWKRenxSVLdOuxeQIPDkbCOGPUhAHleOCHMePYuhGOsYEUjHLaznAsrwhyxLPHVOwcERhDoyTrMwJZEWwbVyDStarrDJcOYDmHOyrGjiilmCOnwAmcWpOaGWBiWxMBRxqsPfeRRyPRYef"), string("htsJTztGUrnjSeELIsPyxujTynEDjCyNVClbanpjisvDOElFSCNjCueKnRfdnzyguDEliQCYaXegKMbVHmPjdLxdBQhVhfjBUXnaOfSwDeQ"), true);
    this->siOVaeG(158837.92648178193, 349612741, -1717533915, 985248.1752861836, 154956145);
    this->PVMVZFbvU();
    this->KFlSYJsSEH();
    this->llReRAFZTgitgnR(1814470107, -871734.5862095945, true, string("tVLGNTStXiCXGmYOhSjAXkCbUxIwIHdrZWRJJysOTsJCcbqqCJrbzBCAcAMyUdPaXKUVjFciyhzkQGmWGNDZxRGggSCnVtBGhTIWmOxesgKVkRmpsWROHbcdvXQPPvbTATZmGPLtuzzCprMvrCAFcitTQqmTyshSLcuOEkHmGB"));
    this->OIdzIReODMcVZCY(string("zYZVzdIJBrSTEQxWXYuaTHcYpEesgEQnaauSIIZGrHtIbnTNvV"), -50704.154083887624);
    this->cbklaPdKl(-575512.0048755313, true, true, string("QIiajcXSjiLlzQKBCRpmUoJkrMhDjxnmpDByDunzfSxMXQPBaAyKfDpxoqiUZkrtgGIZiYdJVgPpCFuPQAxDLQMgxjSfMDSCiJymJjziJiWXXtrBfRYHdhxQAaOgZsLpYUfBnvlseQEJqCsuPmWbjWmLtCGQzHobrCwNTWuSvxEghwqTFtTngkHMIWXEtFDNn"));
    this->bOBqiMAHxvuyHJnH(string("psCChrTXkIMTXQTFqBKFedtRubYuURuQcWSUWeQnGUCxYwHoJWjwgcmkpVRHcwknjOudWEVbvkXVLJkKcnilRFDdQzKFzdnCIIWfCHyOWwTtQbPtaMuWjNRvSSLMcFDETHebOdjXMfQt"));
    this->ZUbyJegYj(-1884336216, string("imfF"), 53161.20400285303, string("talwlopXtgyTlKQILKwjGOeqYQfNNSPcUyCGecIWpgKYJsChlyRSLBXCAAvcSwWHQLWbgGLxXw"));
    this->XgHxfTZxmRTHe(1508534274, -603877.5887848662, 970466283, -356299956);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class khXKNX
{
public:
    string cTMElIl;

    khXKNX();
    string OIUXqoADRmFskF(double JOmCDNjjhYMERsZ, string jZoMEHcYMvPCIF, string ChllLdMQ);
    void TkmqhqCrDpMew(int wvckXCRBhnSdxS);
    int fMAkdmVAoba(int sODmKpCWhZWBh, int NHoKbJpDi, double ONxOlcNVPUMZxRBU, string teXvCxwUdkL);
    double hXNxm(string jsTjuJGHxXQWIO, bool PWsdldJxf, double KdKuzhih);
protected:
    string cvmqOWsRBMZcSTaT;
    double uAUpuWUFvfpdE;
    double ojrIwIhw;
    bool UIDZdQDUPYzHNKdU;
    int WLQUMglJ;
    bool jkodVEq;

    bool amhRuqsCjYjQdkd(bool EAuJAxaVHUYwz, string GlOBoAnMDSJQKfMf, int vMXIXfvxyV, int kYbuWBUWifYQfMs, double qLlfyPaXC);
    int Qxeqz(int BXpgDZD, int AJaWyCRcuqZDDO, string paTICbmK, bool EvEaskw);
    string jHxrYpxY(int BwRkOfIWwotNc);
    bool rezGfEaZdLvsg(double APimsgJvPQyqg, int hRFeAWJfuRDlyxF);
private:
    double tBXwZIMfpI;
    int RBQLhnYzIXDMIL;

    double NwsimiuDL(string wjnHyDatBGNBTcik, string OWLJdfs, double aghug, bool apCdBKAqzC);
    bool QFlpTk(string XttebkingtHDl, bool yWnMVeqMVw, string UxSgtmWwGiQ, bool QMoxtNJioYQE);
    void yLZGOVwwfGRGnX(bool HEMoBzXigZrnbUPr, bool MZavd, int miszLmHAdyxJia, int MkwnBZ, int uxKGcPXZILvHqsCu);
    double wmofD(double PkHLEr, string LUMBYUZeqwF, string cLnaiSlW);
    string CiHsw();
};

string khXKNX::OIUXqoADRmFskF(double JOmCDNjjhYMERsZ, string jZoMEHcYMvPCIF, string ChllLdMQ)
{
    double qByKAuXbrvNdqQ = 796039.2970083865;
    bool gTSjbKJYU = false;
    double hOljQSTpreXJJ = 757282.7158777128;
    int ggvDpwDwPWtD = -401388925;
    bool HUKnBeU = true;
    double wryvtSEVSsL = -1000374.8272370347;
    double CNvMH = -479684.0130515791;
    string WtjTdMDViiTGar = string("RpmKvDWcKyHywcOwbcQqPBlGoEypnEYrQRQreqDPzjgyASeStEyROLPgGapvnCSQEUOwxLOpBjhnJIpZrgHPdGcQVxPIctHGgEcmdGiePoUXquzIODEREstHleVJXoNanQVbpyfKh");

    if (WtjTdMDViiTGar > string("LfohAeKJDWjOitWrPCzKhrKexDdfJnCYWAczffXCmeSYAkmvKYxWwzLqaKAKiqBqpsaUMQLIaQhuwKwcVUIpFjLUGjRqCIfQpQbMkYOqWOXzazGNcJwxhFSBcEEndRvXLSrvwryVkcAVUPRhcSFItjZZWvjtLfzqzTuXSWcbDrSNDfmHktFdSoJrE")) {
        for (int iDtfPEHjza = 1203883115; iDtfPEHjza > 0; iDtfPEHjza--) {
            JOmCDNjjhYMERsZ -= qByKAuXbrvNdqQ;
            jZoMEHcYMvPCIF = jZoMEHcYMvPCIF;
        }
    }

    if (jZoMEHcYMvPCIF >= string("RpmKvDWcKyHywcOwbcQqPBlGoEypnEYrQRQreqDPzjgyASeStEyROLPgGapvnCSQEUOwxLOpBjhnJIpZrgHPdGcQVxPIctHGgEcmdGiePoUXquzIODEREstHleVJXoNanQVbpyfKh")) {
        for (int iwEVZ = 424867242; iwEVZ > 0; iwEVZ--) {
            ChllLdMQ = ChllLdMQ;
        }
    }

    for (int OavETNtaLbo = 89552331; OavETNtaLbo > 0; OavETNtaLbo--) {
        CNvMH *= qByKAuXbrvNdqQ;
        HUKnBeU = HUKnBeU;
    }

    return WtjTdMDViiTGar;
}

void khXKNX::TkmqhqCrDpMew(int wvckXCRBhnSdxS)
{
    int XndEOvSakMqUoLo = 604800084;

    if (XndEOvSakMqUoLo < 2034468744) {
        for (int sjQJGGFDFvPJiLHj = 581066920; sjQJGGFDFvPJiLHj > 0; sjQJGGFDFvPJiLHj--) {
            XndEOvSakMqUoLo += wvckXCRBhnSdxS;
            wvckXCRBhnSdxS /= wvckXCRBhnSdxS;
            XndEOvSakMqUoLo = wvckXCRBhnSdxS;
            wvckXCRBhnSdxS += XndEOvSakMqUoLo;
        }
    }

    if (wvckXCRBhnSdxS > 2034468744) {
        for (int YPczBfQ = 1803506516; YPczBfQ > 0; YPczBfQ--) {
            XndEOvSakMqUoLo = XndEOvSakMqUoLo;
            XndEOvSakMqUoLo *= XndEOvSakMqUoLo;
            wvckXCRBhnSdxS /= XndEOvSakMqUoLo;
            XndEOvSakMqUoLo /= wvckXCRBhnSdxS;
            wvckXCRBhnSdxS *= wvckXCRBhnSdxS;
            XndEOvSakMqUoLo *= XndEOvSakMqUoLo;
            wvckXCRBhnSdxS += XndEOvSakMqUoLo;
            wvckXCRBhnSdxS /= XndEOvSakMqUoLo;
            wvckXCRBhnSdxS += wvckXCRBhnSdxS;
        }
    }
}

int khXKNX::fMAkdmVAoba(int sODmKpCWhZWBh, int NHoKbJpDi, double ONxOlcNVPUMZxRBU, string teXvCxwUdkL)
{
    string qFaeLqq = string("vzJvxNReoTNDtoAMrxbSlKWSvlIgwiLPgufDhUONNFoXfvpUDjQJHoBAWptMUIuWzpeMZxrkUJsCaBJmUnkPfVMhxByzHFteMQcHVpfdrpTrvNmmNmlgPDHzrlpTAZEqbYpzAPrbXtIXIAOmqvvpZTsyDVoLiKysxcBfWsDEYhISRztCjcxaygUKwQwbsPrRpPOPhgbEqHMspUmuqgUgWXTtkUocPgTqSRx");
    string tBMgPWZhquWATx = string("tLUlcJXjiphwMXXOeDQJKGHsuThblHPeXHFzakvOCTAHNmTXHWFoQrDTQXMAkCNkByIImXmcxnMzgeMJuYnjGPQpRvrPpzQfFIAxepuBOnzlyIQWbPXDeJvnJuOrvYLUrxbcRlFkEoKCxoeIJDDCIBDkmFjaTMApZWwENrLhaqsVbqVORrqOLJDDdyyTmvsA");
    int nbkRWy = -1908156895;
    bool WeAQEw = true;

    for (int GKpURXSC = 741964779; GKpURXSC > 0; GKpURXSC--) {
        tBMgPWZhquWATx += teXvCxwUdkL;
        nbkRWy *= nbkRWy;
        NHoKbJpDi += nbkRWy;
    }

    for (int WYERVnKACXAY = 477519427; WYERVnKACXAY > 0; WYERVnKACXAY--) {
        nbkRWy += NHoKbJpDi;
    }

    if (teXvCxwUdkL <= string("tLUlcJXjiphwMXXOeDQJKGHsuThblHPeXHFzakvOCTAHNmTXHWFoQrDTQXMAkCNkByIImXmcxnMzgeMJuYnjGPQpRvrPpzQfFIAxepuBOnzlyIQWbPXDeJvnJuOrvYLUrxbcRlFkEoKCxoeIJDDCIBDkmFjaTMApZWwENrLhaqsVbqVORrqOLJDDdyyTmvsA")) {
        for (int pRbppvoLWmD = 941955562; pRbppvoLWmD > 0; pRbppvoLWmD--) {
            nbkRWy *= nbkRWy;
            teXvCxwUdkL += qFaeLqq;
        }
    }

    return nbkRWy;
}

double khXKNX::hXNxm(string jsTjuJGHxXQWIO, bool PWsdldJxf, double KdKuzhih)
{
    int IcIAAsM = -1994356158;
    int lNEGnmuPOOTeHNB = 1435293055;
    string PhwsGxU = string("TeghEgvWjgzJKxTODnhUfwXgwysadiedQaCdOgiKjzbxnfkDspYaeRnBngDNxFmfCCFERiCxsGvloYFeyReJONXqMHiyV");
    string AuicM = string("JzTxzMRCEekAUsgNAPuLvSUfGNMKZVrGbVQpgjTqWylnSUqMYnitmGziKfGSQRbDShFxOrpebVgVnXBacyhgqlReXvyBUtReROQEvogcCkcoXYEFeLdoFdEZsLVhThUMpRFnvtxZujhIAkFjKoFoafrnmUNfChMqRieYETMUjxgBZqGJweqYNkduBBxfoRHzTUmaXbtQbkZdkXSIlEoWHrLiLNGOIKlz");

    return KdKuzhih;
}

bool khXKNX::amhRuqsCjYjQdkd(bool EAuJAxaVHUYwz, string GlOBoAnMDSJQKfMf, int vMXIXfvxyV, int kYbuWBUWifYQfMs, double qLlfyPaXC)
{
    int ouHbSZqe = 589198631;
    int ySeLWGtpvX = -1012919435;
    int vkSeGydxUSl = -1188733222;
    int SmlyQeX = -1447300473;
    string TxxKbaLayZF = string("wfcPRoYLSQdNeTLEVkAKzziSWwhsiBQNTbYFEuaZyRjgFjW");
    bool fMxmvQTYJmW = false;
    double guXiYxClMqKyD = -840336.8298839247;

    if (qLlfyPaXC != -840336.8298839247) {
        for (int SHiNNhuoAlpCAMFF = 1298989835; SHiNNhuoAlpCAMFF > 0; SHiNNhuoAlpCAMFF--) {
            ouHbSZqe *= vMXIXfvxyV;
        }
    }

    for (int bjAPWJNFMixHH = 751694469; bjAPWJNFMixHH > 0; bjAPWJNFMixHH--) {
        vkSeGydxUSl = kYbuWBUWifYQfMs;
        ouHbSZqe += vkSeGydxUSl;
        kYbuWBUWifYQfMs += vMXIXfvxyV;
    }

    for (int pHqwqqhrJzkAb = 1928701860; pHqwqqhrJzkAb > 0; pHqwqqhrJzkAb--) {
        vMXIXfvxyV /= kYbuWBUWifYQfMs;
        kYbuWBUWifYQfMs *= SmlyQeX;
    }

    if (guXiYxClMqKyD < 864919.118057196) {
        for (int WcxligZDY = 1097125425; WcxligZDY > 0; WcxligZDY--) {
            ouHbSZqe += vkSeGydxUSl;
            ouHbSZqe /= ySeLWGtpvX;
            kYbuWBUWifYQfMs /= vkSeGydxUSl;
        }
    }

    return fMxmvQTYJmW;
}

int khXKNX::Qxeqz(int BXpgDZD, int AJaWyCRcuqZDDO, string paTICbmK, bool EvEaskw)
{
    string IITId = string("djvsfRowAjdXsMrtmvAjXMCOyfoLPMDrkCvmElvZlSRgFldxWnGhNuhJkMljgmNFmfznUAsFqmnmjSeSVSnZenqbDdsxDNcXwJvkgNSQojCvKeZMJENAJrcVUMZlsaduMBGPKHlTMvepmjbQmQIGaPpVPNuKIOKWhvmIifWGADnlOyWBmlllbKbV");

    for (int qNmkelFs = 1496935330; qNmkelFs > 0; qNmkelFs--) {
        paTICbmK += paTICbmK;
        IITId = IITId;
        BXpgDZD *= BXpgDZD;
        BXpgDZD = AJaWyCRcuqZDDO;
    }

    return AJaWyCRcuqZDDO;
}

string khXKNX::jHxrYpxY(int BwRkOfIWwotNc)
{
    string tzqFzXDWLFV = string("TmITHOZRhNxTPytkyzUHrzzycvNG");
    string gPbLMTxjBnW = string("BixLWzTRoUWDcYumOPlFeFtgWVbVkQeZsDnmSbUQFTCrFuWzpjFFiNFpnnAEbfLtSbBDSiWkgCXFuHUYoezaTYhiCBRVGCKpOQLFNuTYaecEFazWlWoqLFtwftmmoshziandQkvCxcw");
    int WyxYpfZfHnNSYi = 279042772;
    int SNRKhXaHUJN = -2100958850;
    int AmiJRr = -2009771293;
    bool OboMU = false;
    int EMTTtcn = -1720521359;
    string LDQUBIg = string("xswPHVzfhibJnnNucAgFMtuukfMnuzDbrCOqgqcsGtYXOSiMhcngeGKLyZiRQcKznPdoDLKaRRyPGpRURQAfBLOaPxwaRhwZhjOEoMVWWZvsnoegFksIOTxeCeBZrESJYWFjxgPWFQQbwcIRiNZkoPSVzHtEHdcWJROKggCCemrNsNNeyDQpBrZE");
    string pUGFgW = string("QHMqBScbTlxTLOtLHZMnYAEPmjbOIgiplotHtEcCrdcFpuHPOGsrJhiROaTfjHQHFOAjgiEVVksNWiUOxKCcuvxdHclcwnDtosxfoSYtwKdAzBgGcIlGAaSKikDWr");

    for (int iFphmRoJjx = 1326458458; iFphmRoJjx > 0; iFphmRoJjx--) {
        EMTTtcn -= BwRkOfIWwotNc;
        LDQUBIg += tzqFzXDWLFV;
    }

    if (BwRkOfIWwotNc > -1720521359) {
        for (int NtwQXKcrTUD = 2138332468; NtwQXKcrTUD > 0; NtwQXKcrTUD--) {
            BwRkOfIWwotNc += EMTTtcn;
            LDQUBIg += pUGFgW;
        }
    }

    if (BwRkOfIWwotNc <= -2100958850) {
        for (int tMioJAx = 1183912462; tMioJAx > 0; tMioJAx--) {
            BwRkOfIWwotNc = BwRkOfIWwotNc;
            BwRkOfIWwotNc *= BwRkOfIWwotNc;
            AmiJRr = EMTTtcn;
        }
    }

    for (int jZRZVXAofKtzjD = 496559828; jZRZVXAofKtzjD > 0; jZRZVXAofKtzjD--) {
        WyxYpfZfHnNSYi += AmiJRr;
    }

    for (int aLVdMyXBxaJYimA = 1609943148; aLVdMyXBxaJYimA > 0; aLVdMyXBxaJYimA--) {
        WyxYpfZfHnNSYi = AmiJRr;
        SNRKhXaHUJN *= WyxYpfZfHnNSYi;
        gPbLMTxjBnW += tzqFzXDWLFV;
    }

    if (OboMU != false) {
        for (int yZMXl = 955000554; yZMXl > 0; yZMXl--) {
            continue;
        }
    }

    return pUGFgW;
}

bool khXKNX::rezGfEaZdLvsg(double APimsgJvPQyqg, int hRFeAWJfuRDlyxF)
{
    bool rySVsvpR = true;
    string XGPjhxl = string("zQTdsZPDZzDSGuJwduanBCVfZXlSyvagaDAYzcfhuTEBPnFhmSyxyZhSVMPbVkqoUmUCxFKkgjToXZaaJsKvcvfXggCpNAWqLBnQGlODaMRtRQgBaBEkYaEERNfkWunHacoWLsVMRYqcmZZkyjpOgUtOuAfwsabxFglvYaqQLxgXfBZjkBYkYKAuoPSwWdHrAasXlqQBPOoSXpWTiRuDtasIVgJmCfgqJlhYQnvlofHobCsUB");
    bool lAHmDuw = false;
    bool BCSuo = true;
    string SvztyAZRxq = string("PQzWXqWwBWkvsjZyIShHVFTKXjtIJyLsMvcnrRsEnckRRJDzrMGVjMecFxarIOznXTvRpiChoOqtPHeJJTQofFnohQptueOlxBitOvdmeXOEfQkvXWfChBcpRVumEZHcqTfCLcevzzJcxBndBVAhXdaoAPsvIjNYPjkmiylIcBmswpLKRsYGSmnUNkljCVNNBpqwSIIAFUWCRsTSbkzRTkfTnaVMVuGolypjOFBWXghSnmQxwCWD");

    for (int UtIXLbndawQhNcF = 1055739897; UtIXLbndawQhNcF > 0; UtIXLbndawQhNcF--) {
        lAHmDuw = rySVsvpR;
        BCSuo = lAHmDuw;
    }

    for (int oTWAmpCscjslckI = 335517796; oTWAmpCscjslckI > 0; oTWAmpCscjslckI--) {
        lAHmDuw = ! lAHmDuw;
    }

    for (int LrvHPkRsOIHxDaE = 1679762763; LrvHPkRsOIHxDaE > 0; LrvHPkRsOIHxDaE--) {
        BCSuo = ! rySVsvpR;
    }

    for (int jvbFBkakkgiawpJH = 1687451719; jvbFBkakkgiawpJH > 0; jvbFBkakkgiawpJH--) {
        continue;
    }

    for (int rikyHUHBVNYbcBnv = 1696103125; rikyHUHBVNYbcBnv > 0; rikyHUHBVNYbcBnv--) {
        rySVsvpR = lAHmDuw;
    }

    return BCSuo;
}

double khXKNX::NwsimiuDL(string wjnHyDatBGNBTcik, string OWLJdfs, double aghug, bool apCdBKAqzC)
{
    bool DxNtttptCkfRB = false;
    string TTRbszbl = string("qGxLUvehMwnFvzMkZaMXrEqoZMJixzQLhUrWVVwXYiFquGfiVSJTrTbmfqNllMHCSisFgmImAirsRKrcxGUeAPDjgGiHlyESsXnwkLJpBdNgoTaRMQvNIEkSKcLMzxdtVslGNlJqfuNSyVNBsazxkGgHzcgJxkdKmfaQeRyjOUFdyiybMFkKlVzVZxIeUUENdPfRzbjtIYlQQnwalFYxzQJyTxeblGIPnFDAoxAjLzBLKjHJDTMoYnvcXrRXC");
    double ZEoVTglPaQsjw = -314.17495401554044;
    bool lkSMsDOxalax = true;
    string vyjMafMOUOiabbxP = string("mhHWRAfoxLbXTzTUTgPnXJevaMBgelbeeWObrxfZsahilXuwcsInzGpmiZHJTSutoAwrKuBqfMoekljSdgGSRCunVLjTGrCLxGQhZncrikEmFHOZavsduwWhyCkTUFrtGkiMfJoMfkCJhcMBMqSUkTXdOuOqXTlkHXdRYkdQbQlYOWnffqSAIntMipPpYmJtUJJxwjYjlvahBFXLQhcJJFhGNehdaiZlWVWTIqAhmAZwchZPQY");
    string XUVcfTLcJsfPER = string("SDUpZvvrnVsTdiGDRequFZRaqNrnPxTZEcrvWzbANHxDYSyTJdpsqGtiFLKDVBpnCoLpgsRbPzM");
    string AoMRgpFosGk = string("YuuxGULZxNFTNXBhXfXGHmcAEtjOPwaSEPdwwzNHDQEXxMkDHUwbGRcPfqzujuqmrkGoFUmxUBINZKINKUmlRAJDtYnjhuDyKPniPrRYsKzeXRDVCNqQyZJrfdOoeHQISFvhDbntzG");
    bool CCaYrg = false;
    string PwGklCenGIqfL = string("NzhxcWxNdonNgTfVsozOpBQnEUZPUunPRC");

    if (TTRbszbl != string("IZCKlvzP")) {
        for (int rQEvLkDhs = 103427031; rQEvLkDhs > 0; rQEvLkDhs--) {
            OWLJdfs += wjnHyDatBGNBTcik;
            OWLJdfs += TTRbszbl;
        }
    }

    for (int rYrmLWioYGc = 446971859; rYrmLWioYGc > 0; rYrmLWioYGc--) {
        XUVcfTLcJsfPER += vyjMafMOUOiabbxP;
        PwGklCenGIqfL += vyjMafMOUOiabbxP;
        CCaYrg = ! apCdBKAqzC;
        TTRbszbl = PwGklCenGIqfL;
    }

    if (wjnHyDatBGNBTcik == string("YuuxGULZxNFTNXBhXfXGHmcAEtjOPwaSEPdwwzNHDQEXxMkDHUwbGRcPfqzujuqmrkGoFUmxUBINZKINKUmlRAJDtYnjhuDyKPniPrRYsKzeXRDVCNqQyZJrfdOoeHQISFvhDbntzG")) {
        for (int ZgvkdXCNpeVhqcZ = 331428103; ZgvkdXCNpeVhqcZ > 0; ZgvkdXCNpeVhqcZ--) {
            DxNtttptCkfRB = DxNtttptCkfRB;
        }
    }

    return ZEoVTglPaQsjw;
}

bool khXKNX::QFlpTk(string XttebkingtHDl, bool yWnMVeqMVw, string UxSgtmWwGiQ, bool QMoxtNJioYQE)
{
    string DZdpjNWpMndbvys = string("mgaVjhaRbClRZfyXxCHSkyMRMbeTLnmpmZwuYjuLbRrxKeHSwTseUgwSwffeMCDFEFByMVNpBLiclhFjvRxRaiYrgXhVgaSgJiGFyUxJOHzvqiIexZKIqhFNCQZndQjUARYhrAqqILuxfsTHxiTIiHlHdKBvXHCEgYoTtidLVKxubdJgURNUfjYwXCDqyKlWVufIbelxvDeTMntL");
    double bRubYEqdSD = -764435.7213912898;
    bool oLGtzoPAJ = true;
    bool JvCuhrDcKvmwuQwa = false;
    string JXuSWu = string("VYvtrUVmTNhqEuSVLJvNBnmrtdOcWEbjoXYcsuoFthfUfPQywhppyLlsSzjHbVahHSXGavTLWXNMmp");

    return JvCuhrDcKvmwuQwa;
}

void khXKNX::yLZGOVwwfGRGnX(bool HEMoBzXigZrnbUPr, bool MZavd, int miszLmHAdyxJia, int MkwnBZ, int uxKGcPXZILvHqsCu)
{
    double gSPOTDjDxGH = 1013468.7124766374;
    string jvNpBSCArxRsV = string("mdSFlVCVbmxfzZHQMsmHjrhNnFzeXBuZeICBBeKejQCNYGOeOcRxgrYayETXxlesMxuTAVXgyKvcdKXyISmnxfKkZVkjaSwwAWEHmObXBGBaIFmHrhRSeKgDnMQeaxUOxrOyxeALejfgYJGTKCvZPsFxqocZnvzKNMdRvXzvfOwtdaoKDiOeuXsXUQVeLF");
    string zwuydZuegcfdFUxG = string("hLKQBNqYqNXlIENCRxPwQauLxDaDpNjUDLsQTvQPemyRGBGJwdTfoyBFiLREGDeXAFlBkKVNDuZIzCZKfaaoEGUcZkfDfIibqIfZDLhxHIlgyHwfyKLrG");
    int stGZpmHhhIbfkz = -935341019;

    for (int PmjxzxblCCSfTOY = 538956866; PmjxzxblCCSfTOY > 0; PmjxzxblCCSfTOY--) {
        miszLmHAdyxJia /= miszLmHAdyxJia;
        HEMoBzXigZrnbUPr = ! MZavd;
        MkwnBZ -= MkwnBZ;
    }

    for (int KZSMjERIila = 1404390974; KZSMjERIila > 0; KZSMjERIila--) {
        uxKGcPXZILvHqsCu /= stGZpmHhhIbfkz;
        uxKGcPXZILvHqsCu *= stGZpmHhhIbfkz;
        miszLmHAdyxJia = uxKGcPXZILvHqsCu;
        zwuydZuegcfdFUxG += jvNpBSCArxRsV;
    }
}

double khXKNX::wmofD(double PkHLEr, string LUMBYUZeqwF, string cLnaiSlW)
{
    string dbBzTMsdBBHRW = string("grFkMfoSjiDnzxOwYgpLovunTLUEkSAUqliRxMLAqPTNEdfywlqdBsVzyFcMlWxHvIzRDWCnmxGMIUdLRcxvrhspKFxwdWzirRDvpaxtqSdhxCHbGhYDYtbfsDqgZxJAaouWrCSeXbiJzpJhcRvnQWuvUunsRwDmQSnuCYmHYvrzOeUdAMWy");
    bool YgItY = false;
    double waiVcllYmDvAcaS = -734156.9835606195;
    string bqhRsoimD = string("AxKqrH");
    int SDLZFBqanGnDoxX = 854823741;
    int UGZtJVEHG = 1783906393;
    double kqvmSGd = 105141.59684110274;
    double geFIuKtB = -905290.0678483393;

    if (geFIuKtB >= -905290.0678483393) {
        for (int fpEGPfrdagHy = 2114407466; fpEGPfrdagHy > 0; fpEGPfrdagHy--) {
            continue;
        }
    }

    for (int BbQOH = 442339674; BbQOH > 0; BbQOH--) {
        bqhRsoimD += dbBzTMsdBBHRW;
        kqvmSGd += kqvmSGd;
        PkHLEr -= geFIuKtB;
    }

    for (int DPvlnv = 668177818; DPvlnv > 0; DPvlnv--) {
        UGZtJVEHG = SDLZFBqanGnDoxX;
        geFIuKtB -= PkHLEr;
        PkHLEr = kqvmSGd;
        UGZtJVEHG = SDLZFBqanGnDoxX;
    }

    if (LUMBYUZeqwF != string("AxKqrH")) {
        for (int pDjsy = 672464530; pDjsy > 0; pDjsy--) {
            SDLZFBqanGnDoxX = UGZtJVEHG;
        }
    }

    return geFIuKtB;
}

string khXKNX::CiHsw()
{
    double jWHtDls = -833630.7099841504;
    string siEhORcb = string("pBTPgMSkkUXyIFQprwvkrUjZhNIhhpStsxSIwFMUmMXUAnjcFWalnvbAmEWgunUgDBGGEgCYcMagJTPhBBOJSvFqQWhmEKzAgHXdtcZPGeQrYMbkGkzDsEmuqTzqkkYVZrnXYVEBDVwyzYBoQkWXaEpbRRRxFTUIJNaqcgvsFsATEiTkaPRmibhwMNDK");
    int qAFbByMRXbuaOGtJ = -1714517724;
    bool nWgVXhtyXww = false;
    string WaEYnligknvfkIrO = string("ePCdcwtHKXVItmZrfLAMgQILRwLqxJqEGkqLfcMtfckWRaCDNVXKSwOYmcuGZiYJZfoxCYhkCmRkuQGspvCGPxwEyzmreSppMuHiCrGuuzErvGXmfqijrUnPMMZrtrELEbDHyOTGHSWhWwiPjxXRoznLKsccCYuvLQBJFcjMXqdy");
    double EoXRvixexKdqWLYu = 258762.2323530219;

    for (int lxPPVzBzhEQ = 712165198; lxPPVzBzhEQ > 0; lxPPVzBzhEQ--) {
        EoXRvixexKdqWLYu = jWHtDls;
        EoXRvixexKdqWLYu += EoXRvixexKdqWLYu;
        jWHtDls += EoXRvixexKdqWLYu;
    }

    for (int qfwwADySX = 2111553836; qfwwADySX > 0; qfwwADySX--) {
        EoXRvixexKdqWLYu -= jWHtDls;
    }

    for (int wzObS = 2121410920; wzObS > 0; wzObS--) {
        jWHtDls /= jWHtDls;
        WaEYnligknvfkIrO = WaEYnligknvfkIrO;
    }

    return WaEYnligknvfkIrO;
}

khXKNX::khXKNX()
{
    this->OIUXqoADRmFskF(305910.6047815407, string("YJMCYypESxhXGIymQkhEJtHtVreskhzowekgQuVQlEiepyoOqBPtylsKdCOhEpSvqRqaVbGnfXnqWaNMYQpCVvzFAgzDmevcIznfeCyMSrkzMUHhsEclTAwhbXVsakICczBIfGwObEEPHfUUSIxbmlxWfrVVetJOTNLiSNvXyGjYlsaLTmYgHgMkoTEdagvvZRbulCAlgnZIxcDYgfPKGJgbQBYGtlguc"), string("LfohAeKJDWjOitWrPCzKhrKexDdfJnCYWAczffXCmeSYAkmvKYxWwzLqaKAKiqBqpsaUMQLIaQhuwKwcVUIpFjLUGjRqCIfQpQbMkYOqWOXzazGNcJwxhFSBcEEndRvXLSrvwryVkcAVUPRhcSFItjZZWvjtLfzqzTuXSWcbDrSNDfmHktFdSoJrE"));
    this->TkmqhqCrDpMew(2034468744);
    this->fMAkdmVAoba(-515836253, 1540125632, 742210.59061865, string("iIOCrtFxRjOuWgvTlmmtRRCnbcsTlvEDEKvRvkcmCGEXCTSCuNOsXPZMmcjrbJXNXDi"));
    this->hXNxm(string("cqHybjHBvGyUmYQhmRTRQjFFSjFxLufhPaberdqPnfRrgXZugAIPITeeODmJBdKOYbXuTkBvekoZDPrArCtyAsNvZOdZdRu"), false, 465614.2658472148);
    this->amhRuqsCjYjQdkd(true, string("VgDarRAOmIPfbzcAFmsqMnGTGVbDvalDwGVhKveLvVsMXLVYqNDUkPFWnIzrvxbQNhigySnMNyknHLauuLjliCpeEhabrpGxCxfliloChOMdDSaqEUkXREDEwFThDDkuiYsmLeeZdXgyeRxnmbdQnzydxPTquAqdxHqktPGbAGjoHJILkgwMHLlOHkPpHtqFWLzyy"), -251424165, 1515630442, 864919.118057196);
    this->Qxeqz(-2010423618, -583851634, string("LtskPZ"), true);
    this->jHxrYpxY(522859862);
    this->rezGfEaZdLvsg(969846.2149804397, -1333957884);
    this->NwsimiuDL(string("XCPumIauoWhMaJoURcMejmp"), string("IZCKlvzP"), -666567.6552892762, false);
    this->QFlpTk(string("jNRalepDySDrtClDPjDfDBtOBPKLTnVEfvdmUPJiTspeQxFXXwJtxUVIxLSRYggJOftYbXeTZrwVscksEzpwWvbCOhgwdvmWPeWlxRqEyUBAajEwXVJqutkkcHOPbnWCPqyjXIDurliadJazsqrFONWBFMPfqVw"), false, string("XXFrHYwPidPrmVJxYxoYjxpkFUNTVuoyDroKmgOjiVNkMtrQnTBhpMdXCWQVcOstvHhulxonrDjENXckhLXLcazUnxamPQQPHLQGpJdjbdljrfvIvahvReCYGPmwFcpVaUQTSYTlCTsMKsPpkoPogbdEnUPjqIxeDGOSkRKghuPIxizGinVzONNjvZHkvUYUhQknKBtAiwUzTYjUhFFQZCFZmmFpLUfkZei"), true);
    this->yLZGOVwwfGRGnX(true, false, -1970576040, -1250125149, -1222314202);
    this->wmofD(1027024.4842230275, string("lzsPQgzpMZsuwZJhpetNpzdMmxthnPtfnhCXUTuJUYrcacyvfhIQVYsNmyZmIZBRljmuIbFVNBBSRPRriNmQSuUlHwamVgOJJiqosrcHXLFzAEarIrwNDaCKWcNvpyMLUYLbDAnmNZpPNVNFmNJBDQejthpaKVIsHDtKiOcGRZrmYNdkgAvsERSiXjIjwiMFqrhFioVeYoyRTCXIuJTRYMKedMbCMqYpFvMntP"), string("hifsZWVJCMJiwWbuMnRsPxTDOghLOaOPTsYvyZlbUhgYBCQLupotOyRZrCFHQFdtApTVnIuqtsrBPZRRAbemiInFMNZokkfuRBPWzMdoXQWiBkfmwewdRWNKuHilqRQTOLSQVgBRvlFdMaaVvauudvKqTRrRmZSwONTfBdlgBqagDOgBFpmlnzCbNBmUmezYnwRKdinUKziTWDmulsxWcAIrsliHwQehGqWDSyrRWcedyK"));
    this->CiHsw();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TOhaucUTC
{
public:
    int aQLzyujuuuStgwAN;
    bool AJKmDY;

    TOhaucUTC();
    double JUtZLrrhGKBeVL(int gduImBw);
protected:
    double NFirdiaKopd;
    string rRsxYSLlbwc;
    string iIYFqHxHPBrlN;
    double SauMPraXwNwD;
    int NLrRDkr;

    bool mMydylyD(int tyKxIGRiPc);
    string ZWdXjLnM(string BwMOdRgdpTutVZ, double XrCArhhJpwy, string uULSCCk, double AqtzAGgYIMyGYBlz);
    void VjApCn(int HWechx);
    void SvcHSOFSlw(bool ozvEkc, bool jvYpHNMS);
private:
    string kYPCZ;
    string bSTEqFdKlnr;
    int PZdolMvxhKDkSkyn;
    double UJFLEQm;
    bool bDBaAgnWEVaNqTR;
    bool EckoMxXMifdJtN;

};

double TOhaucUTC::JUtZLrrhGKBeVL(int gduImBw)
{
    string oRQti = string("CXoZlCZbFACmADMKfZiLxfKmKMlVlBlBIuVLpxwieqRAavTOifZuAdxSHozAmPwgRxchbXmzcyDBgCbFDwcfhfBwCGkCYuiIpEfJghPrABIhXnlYDZOApxEasVPJfhrloEuFsKOqiQCJbmgNTNjzZnzDTsNwyShxgmSWdttABWoDFehizcoSWmnBeSDQzONbvauTjGKOLDvbPdRJdJyElnqoFyczHBaYPEB");
    string AhEjYTnOynE = string("uYBtdNDkZXPvhdGQiaRyTLFdTZoJDqtQaUKjbvMhcTgPJJXypXIOHyagluDLkkJikwmA");

    if (gduImBw != -1084457204) {
        for (int MttklvtGSwfgUPkW = 1074453608; MttklvtGSwfgUPkW > 0; MttklvtGSwfgUPkW--) {
            AhEjYTnOynE = AhEjYTnOynE;
            oRQti += oRQti;
            AhEjYTnOynE += oRQti;
            oRQti = AhEjYTnOynE;
        }
    }

    return -309307.5489313659;
}

bool TOhaucUTC::mMydylyD(int tyKxIGRiPc)
{
    double inQobRlIz = -146106.5998148315;
    double NoYxuFbwXhsBjfdm = -1002892.3906833251;
    bool YFvzWkIM = false;
    bool NjZmhjaWDxQrTY = false;
    string knvXwt = string("sEozJbrQJXZbSwBetzpCoztKferuotsFdLGxxWNnszTwIHfZysXAMdJaPhaAfIkUqumMnMSKHhbMphSOZqYcdIWTrMMmkrZtjxJjFhoBENBEQtHJndWEWCTMRgzYheLYDyqjxiFijLnWrzbLFPocQkAwRBoUvsjQnbXsGQTzohuiXWSuwoVtaokfosNDCNpqXdOtiMJergpwaniVKfrOxTkXJfiRYkffFpk");

    for (int KUMavNdEdLKjyymj = 2006913498; KUMavNdEdLKjyymj > 0; KUMavNdEdLKjyymj--) {
        YFvzWkIM = NjZmhjaWDxQrTY;
        inQobRlIz *= NoYxuFbwXhsBjfdm;
        tyKxIGRiPc /= tyKxIGRiPc;
        YFvzWkIM = ! NjZmhjaWDxQrTY;
    }

    for (int LHMMI = 2103043077; LHMMI > 0; LHMMI--) {
        tyKxIGRiPc += tyKxIGRiPc;
        tyKxIGRiPc = tyKxIGRiPc;
    }

    for (int GLlxqTTniOAM = 84722316; GLlxqTTniOAM > 0; GLlxqTTniOAM--) {
        NjZmhjaWDxQrTY = ! YFvzWkIM;
    }

    return NjZmhjaWDxQrTY;
}

string TOhaucUTC::ZWdXjLnM(string BwMOdRgdpTutVZ, double XrCArhhJpwy, string uULSCCk, double AqtzAGgYIMyGYBlz)
{
    bool hoEyNoFVJCYfg = false;
    int liSSrUT = 1698106481;
    string XGrbsLoKtKLfg = string("aRNnQUPWEVdRmIOyiNJmAaxvQXhOmIuxOxYwHLzcKnDSaxLDrVVXCivPtWxRUgXObfugUcSmLCHxcWoRZlD");
    string zofWFSgZQFihyRm = string("awYqpdiiMNCdftVAzXpfSFUnwGqqWsPcwuzXBlxlQXfIcYLjlshzxlMclHdAaEuAmXDHGJkpGSgSjEwzNQlySHzswVZceJOfzHXZVooZTt");
    double WkLVSxNkMGgmk = -107447.43899734422;
    double tkuNcLCmIKFUQHYE = 336308.3479203143;
    int xoAXrJHQUpPKouaE = 1466686637;
    bool sgvUPC = false;
    double XahqMY = 17419.78764778655;

    return zofWFSgZQFihyRm;
}

void TOhaucUTC::VjApCn(int HWechx)
{
    double hfDTGIs = 344862.3702308775;
    double SLqXbxXXfDK = -538904.6772278614;
    bool cYSevvLWI = false;
    string NMAXTcCib = string("HGkdNTppB");

    for (int EMTjDHz = 370272612; EMTjDHz > 0; EMTjDHz--) {
        SLqXbxXXfDK += SLqXbxXXfDK;
        hfDTGIs -= SLqXbxXXfDK;
    }

    for (int hJuAaNbiuickg = 2044269357; hJuAaNbiuickg > 0; hJuAaNbiuickg--) {
        continue;
    }
}

void TOhaucUTC::SvcHSOFSlw(bool ozvEkc, bool jvYpHNMS)
{
    double ryRZGksFJLtrVXDd = -276613.86895884067;
    double EfeOnWAWwx = 24562.08924413794;
    double mJkIvskq = 738487.4504618489;
    double RmgbtMNFuIxvN = 209156.9889336423;
    string stfjIB = string("knOpGTdAPyIXdecfnPTzjUZuElBeJMDPfmKmKjVhYYbxxTZgbhuYCOlsXfmpMPZMswBjpfvEEDMhzjkcVsAGGkDrLfyzGTmQceRRGmiiNKLkrwuKDcHpPJJdGyfdORCYTyoeUAkUlBYPWKKRzwkfUaXEpzubOKphKeNAQdAoqmXynWiEjpegSxgCEZuowsFAcYyiLjLICBKjuchgMiBYKbuMgoJXhaKxkIYCP");
    double ZvTpZ = 38213.345715979885;
    int lYlYcSVrOl = -829318333;
    bool BwUUALv = true;
    double cyStUoGH = -1022564.1516928427;

    for (int fEzweO = 1215223597; fEzweO > 0; fEzweO--) {
        ryRZGksFJLtrVXDd *= ZvTpZ;
        stfjIB = stfjIB;
        ozvEkc = ! jvYpHNMS;
    }

    if (jvYpHNMS == true) {
        for (int cPDwwqKkuq = 2090123938; cPDwwqKkuq > 0; cPDwwqKkuq--) {
            ZvTpZ = ryRZGksFJLtrVXDd;
            jvYpHNMS = ! jvYpHNMS;
        }
    }

    if (mJkIvskq > 38213.345715979885) {
        for (int hUPeT = 967361847; hUPeT > 0; hUPeT--) {
            ryRZGksFJLtrVXDd /= mJkIvskq;
            RmgbtMNFuIxvN += cyStUoGH;
            BwUUALv = ozvEkc;
            RmgbtMNFuIxvN /= ZvTpZ;
        }
    }

    if (ryRZGksFJLtrVXDd > 209156.9889336423) {
        for (int YvXSgi = 90587279; YvXSgi > 0; YvXSgi--) {
            ZvTpZ -= ryRZGksFJLtrVXDd;
            RmgbtMNFuIxvN *= mJkIvskq;
        }
    }

    for (int LCWmrN = 848640871; LCWmrN > 0; LCWmrN--) {
        ZvTpZ *= RmgbtMNFuIxvN;
    }
}

TOhaucUTC::TOhaucUTC()
{
    this->JUtZLrrhGKBeVL(-1084457204);
    this->mMydylyD(1086329555);
    this->ZWdXjLnM(string("a"), -313338.7193991656, string("xppIGXQTQPlPLygwpOiuovZVFccpvGHLvuNMXnlocXAZMNivHsOvWhyQqQqEzYVhrgrpQSwKcCQrjEbjZMjAYpDrzfjVjefHoTATiKotX"), -601290.9245486371);
    this->VjApCn(1941228231);
    this->SvcHSOFSlw(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class SJeSOcsDAOH
{
public:
    double fvWbe;

    SJeSOcsDAOH();
    string DaZUVgkFaHwbNVO(double ORtXHhwgiHdjxgZ);
    double hDhuXeU(int ycJrl, double sjfBCgBrXTXQWxd, bool tLBeekr, double HNRwODmAXvWjQo, string gWIVFGuPcAmLS);
    void AgNuxMdghUdglA(string fqYXZXHhhwn, bool GyHbxLinRaqq, string pmYTNjW, string cAhCcbCPGjAQRJ, double zhkQRwffvNmdluVa);
    double TMRrKHyINHz(int sPBwrc, int RXzEywIKCohpjyU, int zhuNffQkOHJeA, int tatvZTmTBCKW, int GXuookFqZ);
    double uKWDkm(string ElzKymB, bool DnKhMHhK, bool jMovoG, bool WYHMEbryN, double UMbYDUKJjuc);
    string gsXlab(double jzOKwulqTsLVFK, string ARgFYHeWfnz, double cFsmauaZuC);
    bool qfImPLMFBiX(int RvYvQqOphPIDkb, int eqlKY, double IADCiDRWHoaDGmPy);
protected:
    string RCZzopxIyjJSB;
    int YYlvUUxdwP;
    bool hRqwY;
    string dsVmefBU;

    int asWsmqohmgwq(bool nbpOMV, bool YmeFSR);
private:
    string vHZLWoZwJfZisNM;

    string xNaDlMOght(int rFadlFtTn, bool XOzDVQoNcfY, bool BeLiqgm, int KUSqcd);
};

string SJeSOcsDAOH::DaZUVgkFaHwbNVO(double ORtXHhwgiHdjxgZ)
{
    double CSTadAG = -351205.38878096297;
    string kiJUJrJHBMdeouX = string("mpItIkMQquiuaktdHBwOxQggQvWutmCTmYxgQVbnrFudIggcGQdqBMRJqXUfGIbwYVQFvAtyDBxYJhPpTTgYhOnsmwhNgrgYeaAVylBBbRUPo");
    string WlGSk = string("MLROKjZIlKUQBCrFHwweWueyELKXfYgvBDTAYCgmQbRAQmDJGTRwpmThXZaImNGmEHFPQyyKcGSWvmUsbtkyFnzMhChjDXRWvCMuAcOSXFYYrzxepiWhEkmXsMtLSclIrlCZWOJvLJerJavvxFxcwkGwWXlUxy");
    bool rTBYpBqz = false;
    bool vKCWWFr = false;
    double ybjInuaULCt = 478730.0289091526;
    int YnToObdgigqDxk = -1402155405;
    double tcrdpWJ = 740876.5586457108;

    for (int JvnmtFhmNYzbGD = 916558127; JvnmtFhmNYzbGD > 0; JvnmtFhmNYzbGD--) {
        ORtXHhwgiHdjxgZ /= ybjInuaULCt;
        ybjInuaULCt /= ORtXHhwgiHdjxgZ;
    }

    if (YnToObdgigqDxk == -1402155405) {
        for (int UVOYWA = 802685025; UVOYWA > 0; UVOYWA--) {
            kiJUJrJHBMdeouX += WlGSk;
            ybjInuaULCt -= ybjInuaULCt;
            WlGSk += kiJUJrJHBMdeouX;
        }
    }

    if (ybjInuaULCt == 793194.2994591072) {
        for (int YFUFESTAoc = 1758845694; YFUFESTAoc > 0; YFUFESTAoc--) {
            ORtXHhwgiHdjxgZ += ORtXHhwgiHdjxgZ;
            CSTadAG *= tcrdpWJ;
            kiJUJrJHBMdeouX += kiJUJrJHBMdeouX;
            vKCWWFr = vKCWWFr;
            CSTadAG -= tcrdpWJ;
            ORtXHhwgiHdjxgZ = tcrdpWJ;
        }
    }

    return WlGSk;
}

double SJeSOcsDAOH::hDhuXeU(int ycJrl, double sjfBCgBrXTXQWxd, bool tLBeekr, double HNRwODmAXvWjQo, string gWIVFGuPcAmLS)
{
    int bxWPOSbjQI = 941906492;
    double hPHJqG = -116001.68078464785;
    int KADIefnvXh = 35659739;

    if (HNRwODmAXvWjQo > -116001.68078464785) {
        for (int jktcyzciF = 343336921; jktcyzciF > 0; jktcyzciF--) {
            bxWPOSbjQI *= bxWPOSbjQI;
        }
    }

    for (int zPzPnsc = 240616734; zPzPnsc > 0; zPzPnsc--) {
        continue;
    }

    return hPHJqG;
}

void SJeSOcsDAOH::AgNuxMdghUdglA(string fqYXZXHhhwn, bool GyHbxLinRaqq, string pmYTNjW, string cAhCcbCPGjAQRJ, double zhkQRwffvNmdluVa)
{
    int dkLNOSBXraFHrf = 96331770;
    string dCXCpJBHLuHG = string("PZORxqCZaCXQznUdeIGTLlPXNNSiVZNcsXHuzpZROSCicTZoMcSFlyMFzovOLSjmHheDrjjzcNHoxVnGVsPeGTwdqvpvizBlSIDgbdXEcUAFBnkhnrrlfIJmLfvktymMYSAsyvOIxKxXcWChFYFminXXhL");
    int RWRliSLAUmJt = -1697137326;
    int RYvhBekoldBD = 1235518835;
    int GSPKsTJfqNAOdMm = 633947168;

    if (GSPKsTJfqNAOdMm < 633947168) {
        for (int HKFYzjEpziHh = 723400483; HKFYzjEpziHh > 0; HKFYzjEpziHh--) {
            dkLNOSBXraFHrf *= RWRliSLAUmJt;
            RWRliSLAUmJt += GSPKsTJfqNAOdMm;
        }
    }

    if (RWRliSLAUmJt != 1235518835) {
        for (int ySqWXxuguAM = 1748003898; ySqWXxuguAM > 0; ySqWXxuguAM--) {
            RYvhBekoldBD *= RWRliSLAUmJt;
            GSPKsTJfqNAOdMm /= dkLNOSBXraFHrf;
            GSPKsTJfqNAOdMm -= dkLNOSBXraFHrf;
        }
    }

    if (GSPKsTJfqNAOdMm <= 1235518835) {
        for (int kDjkeXvsT = 469099688; kDjkeXvsT > 0; kDjkeXvsT--) {
            cAhCcbCPGjAQRJ += fqYXZXHhhwn;
        }
    }
}

double SJeSOcsDAOH::TMRrKHyINHz(int sPBwrc, int RXzEywIKCohpjyU, int zhuNffQkOHJeA, int tatvZTmTBCKW, int GXuookFqZ)
{
    bool rqfuNqEXHeKmB = false;
    double LEGYCItcEMmXQ = -574096.1358188621;
    bool mYvduwe = false;
    string rxnNjOX = string("IEuIuoNybLTIASFMwQItJLjoblrhkdpTCNUrDqYlzneEKXZbXyWgSTcgVvxIvLAizddoPxgheRkDZMqCdWTExeprINFhWXwlAsfbgWkuHmklXGFTrcdCIZQbirNTXPdTyDSsRjcbLObmMMjuslUhjUeEWbPpWYmVEAksvCUEqOjvYIChlupAeqSPeTIhQCnpxqCyTyUbFigCVGLalusIJsZGgepLjxvBoJ");

    for (int DRrJYiQOCdMQ = 1272702653; DRrJYiQOCdMQ > 0; DRrJYiQOCdMQ--) {
        GXuookFqZ += sPBwrc;
        rqfuNqEXHeKmB = ! mYvduwe;
        sPBwrc -= zhuNffQkOHJeA;
    }

    for (int GJXhmjT = 1992366346; GJXhmjT > 0; GJXhmjT--) {
        mYvduwe = ! mYvduwe;
        mYvduwe = mYvduwe;
    }

    for (int ZurupKNOytWT = 1921989384; ZurupKNOytWT > 0; ZurupKNOytWT--) {
        tatvZTmTBCKW += sPBwrc;
        RXzEywIKCohpjyU -= RXzEywIKCohpjyU;
    }

    for (int JqNLBzhqaricgOp = 878114590; JqNLBzhqaricgOp > 0; JqNLBzhqaricgOp--) {
        sPBwrc *= tatvZTmTBCKW;
        LEGYCItcEMmXQ += LEGYCItcEMmXQ;
        sPBwrc += sPBwrc;
        zhuNffQkOHJeA = RXzEywIKCohpjyU;
        sPBwrc /= GXuookFqZ;
    }

    return LEGYCItcEMmXQ;
}

double SJeSOcsDAOH::uKWDkm(string ElzKymB, bool DnKhMHhK, bool jMovoG, bool WYHMEbryN, double UMbYDUKJjuc)
{
    bool pEVATJCIBRzgY = false;
    bool HgbuSHZuqSmbC = true;
    bool sglfmodG = true;
    int uJQOQnpvXqIR = 89814668;
    double mKuTtRhy = -927345.1078013255;
    int DNcJmEQmWA = -1438570357;
    double PXfHxrqR = -132730.1985058752;
    int xlzAg = -1536180867;

    if (HgbuSHZuqSmbC == true) {
        for (int ugwIfVXpOGLh = 1830497242; ugwIfVXpOGLh > 0; ugwIfVXpOGLh--) {
            PXfHxrqR = PXfHxrqR;
            UMbYDUKJjuc *= mKuTtRhy;
            sglfmodG = ! pEVATJCIBRzgY;
        }
    }

    for (int mdXogLHOzxa = 1494046948; mdXogLHOzxa > 0; mdXogLHOzxa--) {
        pEVATJCIBRzgY = WYHMEbryN;
    }

    for (int dDDxYv = 636288516; dDDxYv > 0; dDDxYv--) {
        WYHMEbryN = HgbuSHZuqSmbC;
        HgbuSHZuqSmbC = ! WYHMEbryN;
        jMovoG = ! DnKhMHhK;
    }

    return PXfHxrqR;
}

string SJeSOcsDAOH::gsXlab(double jzOKwulqTsLVFK, string ARgFYHeWfnz, double cFsmauaZuC)
{
    int nLQgifGbs = 151460828;
    int HDYHRJeTIR = 1777923385;
    bool vdBkHX = false;

    if (HDYHRJeTIR > 1777923385) {
        for (int MIkaPfkfPzuwRlp = 22661997; MIkaPfkfPzuwRlp > 0; MIkaPfkfPzuwRlp--) {
            HDYHRJeTIR += nLQgifGbs;
        }
    }

    for (int gdWGgLQNLiVK = 986076234; gdWGgLQNLiVK > 0; gdWGgLQNLiVK--) {
        jzOKwulqTsLVFK *= cFsmauaZuC;
    }

    return ARgFYHeWfnz;
}

bool SJeSOcsDAOH::qfImPLMFBiX(int RvYvQqOphPIDkb, int eqlKY, double IADCiDRWHoaDGmPy)
{
    double WhaBSKvPsadqK = -807806.103176647;
    double PqAbLQzBOUq = -987812.1812534643;
    double tGTkJN = 987442.6820489466;
    bool rPNPGNRLNJ = false;
    bool vNmYBPZxyAwYHLHD = true;

    for (int OJGQamme = 607824036; OJGQamme > 0; OJGQamme--) {
        continue;
    }

    return vNmYBPZxyAwYHLHD;
}

int SJeSOcsDAOH::asWsmqohmgwq(bool nbpOMV, bool YmeFSR)
{
    string DCkWEclCNMA = string("TAANanZjBDqWgXuGnhfZTHoDOrqBrbeZAYBsUzeOxarYwWfJCVmDUPJiqGeKdVMhwkYWqvqYZIZrFqAdFBnrnVytJPw");

    return -325178049;
}

string SJeSOcsDAOH::xNaDlMOght(int rFadlFtTn, bool XOzDVQoNcfY, bool BeLiqgm, int KUSqcd)
{
    bool ZCPUiT = false;
    double vPjrvrqICITUFsUy = -728072.421214765;
    double JTlQNKMSlfKUU = 216113.80326579508;
    double OqAPZcnWQ = -986848.1320232536;
    int xAOmQShA = 35947980;

    for (int bfGKCIOeMZ = 248378192; bfGKCIOeMZ > 0; bfGKCIOeMZ--) {
        vPjrvrqICITUFsUy *= OqAPZcnWQ;
        ZCPUiT = XOzDVQoNcfY;
        JTlQNKMSlfKUU += OqAPZcnWQ;
    }

    return string("ZCJYgiNiiqTQiIIOlURqvxIIWNaVEMkibMJlPkSVOaeyyIHvtqFJEMotmDlKIKhPCthQOiksNNxGfFgbSYxjTzhHZLwWaAuXtjDEVSBMZTHZyDTnGCxnaajyBkpRofaBtWaTLfXefRMgSPsXaPyyflxAfcDMEFJFJEiTzuwymONltSjWJZrN");
}

SJeSOcsDAOH::SJeSOcsDAOH()
{
    this->DaZUVgkFaHwbNVO(793194.2994591072);
    this->hDhuXeU(1919660253, -110714.95776022761, true, -494115.6634256679, string("vhZAFXxZeMcFXjYTcSZCRvZlELUdnyGKQFyhcOZfwlrkalstwYRnzNMqLzKoVJgpYuLG"));
    this->AgNuxMdghUdglA(string("lTZYMZaEIAdgfDzImmNJMQgmMwzzumHpOiFMJvHCmxSleSZSnqYRMguHODndJNUgTbAMVAlCtCiCoewqVrSPDUIMDisxuwdbQysajxlKOOWlMsGENxYcTZfbTzNQdbTVGfplFsWKKyQgJfBQoQsJXSYBraIXWVfefpNIhmBVPbRSqcuPZbPtwwIgacwtjryv"), true, string("jTidjlPbp"), string("CQCtdUnDWFgOkYHCQvZMfISmWdPvXGwpwtQAYcSbtTnpWRFUvgJQrdqUXrapcxM"), -638288.1706379461);
    this->TMRrKHyINHz(136910456, 103626381, 563002017, -426524445, 1857374904);
    this->uKWDkm(string("YxhQhpvGzjmVvPhcWazrWETOrXQdqDsLNmbfdLUMTPOeyroRZWBrnAOHJSwrSHdqiBcvFCzvqHVYfeyraEzYcZRjBKZjXeRbMUGwWwROrnLvtwYqkvMGBbhPp"), true, true, true, 379886.83594625356);
    this->gsXlab(-433020.48032841104, string("EkUMbGHNglIORfgknXDQkbICIWRTbvEfQBWnNpHTetxalOrnHFPOkLzbtEhLtYDqjzEkZOEpYiGCNowYHtqfHFtsfsResKCVPWSqyiTKAUtNuunmwRYhXxKaQDokUqguIvUCGjfZterMhSgxYs"), 450073.43581111915);
    this->qfImPLMFBiX(2052810062, -1300127389, -278504.56892196636);
    this->asWsmqohmgwq(false, true);
    this->xNaDlMOght(-1803203517, false, true, 2004071196);
}
