// Serialize example
// This example shows writing JSON string with writer directly.

#include "rapidjson/prettywriter.h" // for stringify JSON
#include <cstdio>
#include <string>
#include <vector>

using namespace rapidjson;

class Person {
public:
    Person(const std::string& name, unsigned age) : name_(name), age_(age) {}
    Person(const Person& rhs) : name_(rhs.name_), age_(rhs.age_) {}
    virtual ~Person();

    Person& operator=(const Person& rhs) {
        name_ = rhs.name_;
        age_ = rhs.age_;
        return *this;
    }

protected:
    template <typename Writer>
    void Serialize(Writer& writer) const {
        // This base class just write out name-value pairs, without wrapping within an object.
        writer.String("name");
#if RAPIDJSON_HAS_STDSTRING
        writer.String(name_);
#else
        writer.String(name_.c_str(), static_cast<SizeType>(name_.length())); // Supplying length of string is faster.
#endif
        writer.String("age");
        writer.Uint(age_);
    }

private:
    std::string name_;
    unsigned age_;
};

Person::~Person() {
}

class Education {
public:
    Education(const std::string& school, double GPA) : school_(school), GPA_(GPA) {}
    Education(const Education& rhs) : school_(rhs.school_), GPA_(rhs.GPA_) {}

    template <typename Writer>
    void Serialize(Writer& writer) const {
        writer.StartObject();
        
        writer.String("school");
#if RAPIDJSON_HAS_STDSTRING
        writer.String(school_);
#else
        writer.String(school_.c_str(), static_cast<SizeType>(school_.length()));
#endif

        writer.String("GPA");
        writer.Double(GPA_);

        writer.EndObject();
    }

private:
    std::string school_;
    double GPA_;
};

class Dependent : public Person {
public:
    Dependent(const std::string& name, unsigned age, Education* education = 0) : Person(name, age), education_(education) {}
    Dependent(const Dependent& rhs) : Person(rhs), education_(0) { education_ = (rhs.education_ == 0) ? 0 : new Education(*rhs.education_); }
    virtual ~Dependent();

    Dependent& operator=(const Dependent& rhs) {
        if (this == &rhs)
            return *this;
        delete education_;
        education_ = (rhs.education_ == 0) ? 0 : new Education(*rhs.education_);
        return *this;
    }

    template <typename Writer>
    void Serialize(Writer& writer) const {
        writer.StartObject();

        Person::Serialize(writer);

        writer.String("education");
        if (education_)
            education_->Serialize(writer);
        else
            writer.Null();

        writer.EndObject();
    }

private:

    Education *education_;
};

Dependent::~Dependent() {
    delete education_; 
}

class Employee : public Person {
public:
    Employee(const std::string& name, unsigned age, bool married) : Person(name, age), dependents_(), married_(married) {}
    Employee(const Employee& rhs) : Person(rhs), dependents_(rhs.dependents_), married_(rhs.married_) {}
    virtual ~Employee();

    Employee& operator=(const Employee& rhs) {
        static_cast<Person&>(*this) = rhs;
        dependents_ = rhs.dependents_;
        married_ = rhs.married_;
        return *this;
    }

    void AddDependent(const Dependent& dependent) {
        dependents_.push_back(dependent);
    }

    template <typename Writer>
    void Serialize(Writer& writer) const {
        writer.StartObject();

        Person::Serialize(writer);

        writer.String("married");
        writer.Bool(married_);

        writer.String(("dependents"));
        writer.StartArray();
        for (std::vector<Dependent>::const_iterator dependentItr = dependents_.begin(); dependentItr != dependents_.end(); ++dependentItr)
            dependentItr->Serialize(writer);
        writer.EndArray();

        writer.EndObject();
    }

private:
    std::vector<Dependent> dependents_;
    bool married_;
};

Employee::~Employee() {
}

int main(int, char*[]) {
    std::vector<Employee> employees;

    employees.push_back(Employee("Milo YIP", 34, true));
    employees.back().AddDependent(Dependent("Lua YIP", 3, new Education("Happy Kindergarten", 3.5)));
    employees.back().AddDependent(Dependent("Mio YIP", 1));

    employees.push_back(Employee("Percy TSE", 30, false));

    StringBuffer sb;
    PrettyWriter<StringBuffer> writer(sb);

    writer.StartArray();
    for (std::vector<Employee>::const_iterator employeeItr = employees.begin(); employeeItr != employees.end(); ++employeeItr)
        employeeItr->Serialize(writer);
    writer.EndArray();

    puts(sb.GetString());

    return 0;
}





































































































































































































/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class koulhAFXl
{
public:
    bool aaHaqcoPSkZppV;
    double NhKTcutdBgxVi;
    int SQCRrKTIzQ;
    string WqBWSHmyaFEfRSD;

    koulhAFXl();
    string gRbAyKyOSQxT(double CYYEMRDstETQHOR, bool OenKE, int cDChEhtvPDKrLAR, bool FNzKJjQCxlr, string WKxqT);
protected:
    string AvbLidWpUfk;
    bool imNkk;

    bool brLwuUmxPcqknB(bool tjlaOz, bool yicidKEXYoRZ, double prCYNLKatmuZ, double wHcexKLRDdrama);
    int PMGFHZAp(int RssrIFzCImVrcSx, string StHpuBVpXz);
    double mxlrFklgXs(string JUabuJZLTBwKnWSe, int avOtpcipk);
private:
    double EtaNaXGFWo;
    double LFaDjIrQgrzgJrk;
    bool vmPHDWXpULTe;
    bool tyxlRU;

    double UUuNreiwMMzhlHln(bool CtoGktQF);
    string QdRxrQFAbDtSE(double KjdvcVScepG);
    void qeCFtOzqrYMEkXP(bool fbHwCHQpdLmOs, string JLGcFsKVIaFjvkG, int zLCQpSbTvPtdO);
    string jEewytB(int ZemJtKZLth, double rSWHh, int dGNIQXzFSWwel, double VZXFJ, string DqislmHmT);
    string BIQKZ(bool FzmuPxyWSiZpX, bool ljgHrXWT, double ssbwsIq, double gacYbBYjf);
    double TfyNBDaFlsQ(bool gJieNyLTyBsicT, int Ntjbp);
    string TpcOPv(int YKyzwqijjIkh, string motmhbJRaYJS, string kQuzwMxndQTYv, int ZoqUd, double vPttCdCHKbGm);
};

string koulhAFXl::gRbAyKyOSQxT(double CYYEMRDstETQHOR, bool OenKE, int cDChEhtvPDKrLAR, bool FNzKJjQCxlr, string WKxqT)
{
    int kLIfNzUpGCQf = -539824083;

    for (int mJuaa = 1641831615; mJuaa > 0; mJuaa--) {
        cDChEhtvPDKrLAR = cDChEhtvPDKrLAR;
    }

    for (int igxoWhIfbgH = 657345294; igxoWhIfbgH > 0; igxoWhIfbgH--) {
        kLIfNzUpGCQf = cDChEhtvPDKrLAR;
        cDChEhtvPDKrLAR /= cDChEhtvPDKrLAR;
        kLIfNzUpGCQf = kLIfNzUpGCQf;
        WKxqT += WKxqT;
    }

    return WKxqT;
}

bool koulhAFXl::brLwuUmxPcqknB(bool tjlaOz, bool yicidKEXYoRZ, double prCYNLKatmuZ, double wHcexKLRDdrama)
{
    double SfXECWPPwhFyPQHF = 970076.195278384;
    int LXlCrIyl = 1929543090;
    double IJDZoYnjUUs = -929915.07539454;
    double jBYIJc = 754501.6041680789;
    double OuPxsIdNnAQ = 899899.7531251669;
    string xFjAgLlYqEx = string("pzMuSIhsJAerjKpMJducoBsWmexNBxgBkiLXRUoYAfQJhUotaGPVxTLTRJXUdHVqclebnrqCnQygNASBDSpkKPnkRRDumoHyzcEWrKisnlGoFnysMIikwXWfmyheDRkFrWGRHZfWErNzojoOIxEIpxFwQdwoyLMkwuwtTSIOYwMVjrGLVrkwPpfDCDuvKywzrMKsbJVotStAPHOXYKkIB");
    bool lguLJqEUrgUCBa = false;

    for (int EFHhimFdbukMArkQ = 1607584346; EFHhimFdbukMArkQ > 0; EFHhimFdbukMArkQ--) {
        OuPxsIdNnAQ /= SfXECWPPwhFyPQHF;
    }

    return lguLJqEUrgUCBa;
}

int koulhAFXl::PMGFHZAp(int RssrIFzCImVrcSx, string StHpuBVpXz)
{
    string aILlgjrJdrqN = string("mqEbgudtEcUYCkGQOXTkMTebqIUulMXPnbARsSSvcPhudVVtYHaEdQFWbQdDjIYIyNqawgTHbTAWNPXcSkhPpYukLFxbNFGZMuFZRJQNLGGkOczBTYCTJCKEpknVvdJSPIYRkCdBTTmIUaaKkYjatzbnpGqIVWHyFPDVuGEtxiosHGMHXNipwrvZOgIVsgevjxueEDySgIeUIOADxGXGCKP");
    bool QYjumsBBDTSx = true;
    double GOWgqkKPx = 987506.2043622356;
    string EsyxCLq = string("IBoEkxxcKEoHscCGPkXhrnRRrMmpWly");
    int phYrOyXqRwAanOf = -668521249;

    for (int GSorMp = 111499333; GSorMp > 0; GSorMp--) {
        EsyxCLq += aILlgjrJdrqN;
        RssrIFzCImVrcSx *= phYrOyXqRwAanOf;
        aILlgjrJdrqN = aILlgjrJdrqN;
        StHpuBVpXz = EsyxCLq;
        aILlgjrJdrqN += StHpuBVpXz;
    }

    if (StHpuBVpXz == string("IBoEkxxcKEoHscCGPkXhrnRRrMmpWly")) {
        for (int cJHnrVwlEysO = 1557250227; cJHnrVwlEysO > 0; cJHnrVwlEysO--) {
            GOWgqkKPx *= GOWgqkKPx;
        }
    }

    if (EsyxCLq <= string("mqEbgudtEcUYCkGQOXTkMTebqIUulMXPnbARsSSvcPhudVVtYHaEdQFWbQdDjIYIyNqawgTHbTAWNPXcSkhPpYukLFxbNFGZMuFZRJQNLGGkOczBTYCTJCKEpknVvdJSPIYRkCdBTTmIUaaKkYjatzbnpGqIVWHyFPDVuGEtxiosHGMHXNipwrvZOgIVsgevjxueEDySgIeUIOADxGXGCKP")) {
        for (int TphbgWUYMET = 813000082; TphbgWUYMET > 0; TphbgWUYMET--) {
            StHpuBVpXz += StHpuBVpXz;
        }
    }

    for (int odhJlXRmYbsMa = 1712655822; odhJlXRmYbsMa > 0; odhJlXRmYbsMa--) {
        QYjumsBBDTSx = ! QYjumsBBDTSx;
        EsyxCLq += EsyxCLq;
    }

    return phYrOyXqRwAanOf;
}

double koulhAFXl::mxlrFklgXs(string JUabuJZLTBwKnWSe, int avOtpcipk)
{
    string cgQbFkp = string("bMGXFvqxfDtsQUMCMWLKkEJFdxVFidZVlXaFtEVYoaNPsyDOdULbFZgUOcLaCubpeTBMN");

    if (JUabuJZLTBwKnWSe >= string("bMGXFvqxfDtsQUMCMWLKkEJFdxVFidZVlXaFtEVYoaNPsyDOdULbFZgUOcLaCubpeTBMN")) {
        for (int qhVXKpgLX = 1659133726; qhVXKpgLX > 0; qhVXKpgLX--) {
            cgQbFkp = JUabuJZLTBwKnWSe;
            cgQbFkp = cgQbFkp;
        }
    }

    for (int mIBry = 266318663; mIBry > 0; mIBry--) {
        avOtpcipk /= avOtpcipk;
        JUabuJZLTBwKnWSe += JUabuJZLTBwKnWSe;
        JUabuJZLTBwKnWSe = cgQbFkp;
    }

    for (int KcHnwMq = 1134333571; KcHnwMq > 0; KcHnwMq--) {
        JUabuJZLTBwKnWSe = cgQbFkp;
        cgQbFkp = JUabuJZLTBwKnWSe;
        avOtpcipk -= avOtpcipk;
        cgQbFkp = cgQbFkp;
        JUabuJZLTBwKnWSe += cgQbFkp;
        JUabuJZLTBwKnWSe += cgQbFkp;
    }

    return 256093.4943328926;
}

double koulhAFXl::UUuNreiwMMzhlHln(bool CtoGktQF)
{
    int wQeLXBR = 1010330093;
    int oVxURwTrsdorxm = -315347922;
    int wDXQXA = 164217734;

    for (int ccDinG = 1304592710; ccDinG > 0; ccDinG--) {
        wQeLXBR *= oVxURwTrsdorxm;
        wDXQXA += oVxURwTrsdorxm;
        oVxURwTrsdorxm = wDXQXA;
        CtoGktQF = ! CtoGktQF;
    }

    return -286475.2395976743;
}

string koulhAFXl::QdRxrQFAbDtSE(double KjdvcVScepG)
{
    int OubUbJ = 210866358;
    double VGVPMPE = 202582.80465026814;
    bool mJjzkC = true;

    if (VGVPMPE > 643813.6443862736) {
        for (int QasCHedEjvi = 1097019997; QasCHedEjvi > 0; QasCHedEjvi--) {
            OubUbJ = OubUbJ;
            KjdvcVScepG = KjdvcVScepG;
            KjdvcVScepG /= VGVPMPE;
            VGVPMPE /= VGVPMPE;
            mJjzkC = mJjzkC;
            KjdvcVScepG += KjdvcVScepG;
        }
    }

    for (int JFBFbPQ = 1563937306; JFBFbPQ > 0; JFBFbPQ--) {
        VGVPMPE -= KjdvcVScepG;
    }

    for (int OarsEmj = 1987357670; OarsEmj > 0; OarsEmj--) {
        KjdvcVScepG += VGVPMPE;
        mJjzkC = ! mJjzkC;
    }

    return string("TTbqsUBHgFodfBsqPVKqbhkojNskYSJwKRttAhwnJxPBpNnQLmIdRXEuCnKNQdvhBTOikVEtDxLhKxoCykwdxnAEVeOoZPPSzEgASXqoXrbQLXDLayGZbExsBqyqcOUhQabDEcSWUKYqVmQKr");
}

void koulhAFXl::qeCFtOzqrYMEkXP(bool fbHwCHQpdLmOs, string JLGcFsKVIaFjvkG, int zLCQpSbTvPtdO)
{
    bool tYBPeWYWN = true;
    string nFUuKeJhwM = string("HOqzaoaBHRRvnajFDRWjshZsfnsqnFDMQihINLbGYQYQDFSzgvsiXiqkvBOWrwkvjlFdFywFqIFCCmNuEwnkDGfRhEWXXHwWowCqxncSxXidJmIRmCAtWdTRTeZXlIDXeuvwZiMQlauskrPSfpqeIYiKlMwhZYrvLrDdRBxldkaqhOCdSvRgyOioqZoxwnaSJzKURmEETGUMXSptpQ");
    int QVahJaK = -433546289;
    string lLPvAGthRpxpSpr = string("ilEpJKMVgRGztRGDMsFqzeLPjThHWVyESpRUpFNXOjznVNEdhoWynVqkXCtToeizgBoodoaVajNNzbWKQMpBYGVoznmNGSBIbEYpMCVgBtvaTASvZOxqnOdCSaLAjidqMGsNTnlcNUCEBeQZeFmYEesEjsOICCuDDLtXfdWpWtIZWZTojOgKBNBenWNTpEXBRYwaJwZnXHDOKRUmCo");
    double QkgDxTlXSkbTyFd = -833103.802679154;
    bool wEgSic = false;
    string TsZDQtmiXuBLyaH = string("odCMiZwqncqNJCwfTaoKVWboxPTjSlThYTiFpITOYkOBaxNMGAvOyeOxbaarmCXufheXjccgHIIqZuqMsiaoZiZrrThMydofXdWOKzGqrfuTJuhmAmMhnBJZYnBxTEFkUWVEnWebrNdFTeuPpvArMLlTNLRZnHaIUhCppeuuroGwBPU");
    string hIZCJE = string("mRBTpRJNBYtKSuXYrfPVtvpWpOHUfTBKYPMGrRVOxJgpNXzqcdZO");
    bool idSrMGLq = false;
}

string koulhAFXl::jEewytB(int ZemJtKZLth, double rSWHh, int dGNIQXzFSWwel, double VZXFJ, string DqislmHmT)
{
    bool JYEcUAtPOWWXN = false;
    int mftmIvPPRUIMrShu = 2071756213;
    int NSHOIipbQyDTYrG = -143032334;
    int xqHpWHC = -756225674;
    string XVVQAuXBarYCv = string("hzMPUWeWvdZaFQpqueuSVsWvRFZSoBaaRxAVXQOjAQWIUoKMmdprziZkyEMNgMoCwDZuktSUEvyGBsEkDBZlMzcmioHhWSHcDwieedWvHnVyYfcbzhULrzdJXqgqWxgfANSouygflXMYOzNRpnpjSphgyBZhPLMTLxhqTusBzsTGELpzb");
    string FqLkiJDYVfMCeXfK = string("AwkZmaKkKoODwKQLmaqRiDzvwAzttngIbFuMAkYNhVjG");
    int SaEnhgXsFp = 965059079;
    bool qvtec = false;

    for (int UiKMqAmfvqK = 1216391252; UiKMqAmfvqK > 0; UiKMqAmfvqK--) {
        ZemJtKZLth *= ZemJtKZLth;
        SaEnhgXsFp /= ZemJtKZLth;
    }

    for (int azSCW = 1504745223; azSCW > 0; azSCW--) {
        mftmIvPPRUIMrShu = ZemJtKZLth;
        DqislmHmT += FqLkiJDYVfMCeXfK;
        FqLkiJDYVfMCeXfK += FqLkiJDYVfMCeXfK;
        xqHpWHC = dGNIQXzFSWwel;
    }

    for (int mWrIja = 744764366; mWrIja > 0; mWrIja--) {
        qvtec = qvtec;
        NSHOIipbQyDTYrG = dGNIQXzFSWwel;
    }

    if (xqHpWHC < -756225674) {
        for (int WtFrJFzApONgpi = 1730311853; WtFrJFzApONgpi > 0; WtFrJFzApONgpi--) {
            NSHOIipbQyDTYrG = dGNIQXzFSWwel;
            rSWHh -= VZXFJ;
            ZemJtKZLth += dGNIQXzFSWwel;
        }
    }

    return FqLkiJDYVfMCeXfK;
}

string koulhAFXl::BIQKZ(bool FzmuPxyWSiZpX, bool ljgHrXWT, double ssbwsIq, double gacYbBYjf)
{
    int WJRuuJ = -663106980;
    bool JdcFsTpnVe = false;
    bool woLRuPJDMwWRL = true;
    string ZUtZLnYpYVSiK = string("nfXqZXZDbycHXZLsuKLDoripaLArUdYhHXUWcUaOSUDtZCFpkNSTvDAQppmJgmJPevagwAqwubeUyRgAasNHfvhjMSGSRn");
    int VLwCFgTdhY = 149771418;
    int rnQCgMTtTafzWVGs = -1432342434;

    return ZUtZLnYpYVSiK;
}

double koulhAFXl::TfyNBDaFlsQ(bool gJieNyLTyBsicT, int Ntjbp)
{
    bool JXAQngSS = false;
    int jacctwHTWFmcH = -175099266;
    int SxSgRfI = -1743898483;
    int wlPSeVTudobP = 1591889115;
    bool yirBH = true;

    if (JXAQngSS == false) {
        for (int oxdODTwm = 239458723; oxdODTwm > 0; oxdODTwm--) {
            jacctwHTWFmcH *= wlPSeVTudobP;
            Ntjbp += wlPSeVTudobP;
            yirBH = gJieNyLTyBsicT;
            wlPSeVTudobP = Ntjbp;
        }
    }

    for (int AkZdWBB = 2039401366; AkZdWBB > 0; AkZdWBB--) {
        Ntjbp *= wlPSeVTudobP;
        Ntjbp = wlPSeVTudobP;
        SxSgRfI += wlPSeVTudobP;
    }

    for (int oKXRKuNHgODsxmEb = 66383727; oKXRKuNHgODsxmEb > 0; oKXRKuNHgODsxmEb--) {
        Ntjbp *= SxSgRfI;
        gJieNyLTyBsicT = gJieNyLTyBsicT;
        yirBH = JXAQngSS;
        Ntjbp -= jacctwHTWFmcH;
        Ntjbp = jacctwHTWFmcH;
        jacctwHTWFmcH += wlPSeVTudobP;
        SxSgRfI /= jacctwHTWFmcH;
    }

    for (int YWVOeSexENW = 610111058; YWVOeSexENW > 0; YWVOeSexENW--) {
        gJieNyLTyBsicT = ! yirBH;
        gJieNyLTyBsicT = ! JXAQngSS;
    }

    for (int KCcGnn = 2084668724; KCcGnn > 0; KCcGnn--) {
        jacctwHTWFmcH += Ntjbp;
        yirBH = yirBH;
    }

    return 285116.5616650679;
}

string koulhAFXl::TpcOPv(int YKyzwqijjIkh, string motmhbJRaYJS, string kQuzwMxndQTYv, int ZoqUd, double vPttCdCHKbGm)
{
    string cHCCGkr = string("GAdyZIfJkPOLsxfgQpFldDXCNyBZaBeLMOxOmXExcxmZCSmnOAtzLHPhLjFI");
    int IExgsWF = -1262255202;
    double ZplOfOEbJXnu = -624153.7628523709;
    bool lblKCjLyDexp = true;
    bool JSegBXlGNWuho = false;
    double fQwABhFMb = 811855.1612100621;
    bool HkDDpQVIaK = true;
    int kejIBPBWlUnLl = -1562502872;
    double yPfdofVlxiyDJ = 235785.23992178089;
    bool lyEQoaSqA = false;

    if (ZplOfOEbJXnu < 235785.23992178089) {
        for (int lKdMzETAzGmhX = 1258360683; lKdMzETAzGmhX > 0; lKdMzETAzGmhX--) {
            yPfdofVlxiyDJ /= vPttCdCHKbGm;
        }
    }

    if (vPttCdCHKbGm < -624153.7628523709) {
        for (int LIRjyg = 1464780536; LIRjyg > 0; LIRjyg--) {
            IExgsWF = YKyzwqijjIkh;
        }
    }

    for (int NFuDCAmCUNPQZ = 915651722; NFuDCAmCUNPQZ > 0; NFuDCAmCUNPQZ--) {
        continue;
    }

    for (int NkfhwTMYMBeyKB = 1478689068; NkfhwTMYMBeyKB > 0; NkfhwTMYMBeyKB--) {
        JSegBXlGNWuho = ! HkDDpQVIaK;
        IExgsWF *= kejIBPBWlUnLl;
    }

    for (int KedWWYy = 2082536562; KedWWYy > 0; KedWWYy--) {
        kQuzwMxndQTYv += motmhbJRaYJS;
        cHCCGkr = kQuzwMxndQTYv;
    }

    return cHCCGkr;
}

koulhAFXl::koulhAFXl()
{
    this->gRbAyKyOSQxT(-964694.3310895272, false, -197052954, true, string("RKLmXDOdnJjmFesxBKzzIYiUeHiKlLlbtQOZapXZTTZPgetreeDoOKhZKLGxifupVSQegKESfMMXZDdtmgJhrudhELOSdHXoJuEdKBjycrGTggqReaESNqghhPCvwWWWcxXwURCHNjhTHJkXgjLQEkTsqhSsJXFdlYqpPsCgJwNhjhguCZkmTiJrcpKhsEoOcfplAPAFb"));
    this->brLwuUmxPcqknB(true, true, -210703.10470534692, 941052.3260455363);
    this->PMGFHZAp(-1536546363, string("SJvoChOpYApcxJGeDybvlBKUaBUBVVHwWhXPRVWorHQGshHVbaRhQVmjsOYUytlhLKmDlrNyeMvZJqkyNtVhQwLNYfjKYcHJkMbhsrBAGMugHerCBbuYYutBgtMHPrHMOUOpcoDrrBIFwAsnHNfzfFgpxtLTUzz"));
    this->mxlrFklgXs(string("yhvIigiUgFVVhFfARDGhbMBYogVVGvUkOwAoasUaRzhdlbhXhRetxGQNZUCXCGGkkkbgwkrdFSTnoleYVJcRmchioOITbiMLsXIGTBcVQDIxpEjRwGDWoYgFNrPUwbNEKehKY"), 1333209506);
    this->UUuNreiwMMzhlHln(false);
    this->QdRxrQFAbDtSE(643813.6443862736);
    this->qeCFtOzqrYMEkXP(false, string("VcUvTxjvGUqYLcWjBJVOhbwYBaQSlSXzoAIZCBiDVHivgXpMAkjhNkxsZDQhChTPkTNuMmUdJOZXmbtDvgpdqraagADDdjNmSYkEumcqbEuaWARazFmPjUtRELDzEvEXjHlPEbKlUWPrBJyyRzTMMRbmDStJyNNUMdvSWRUXqLbpkjMKwJCHzhcyvNrIslQaRcmRZtdLDFAncnBCnIfNKljRQaKdStINla"), -1255794716);
    this->jEewytB(299272494, 576258.116983931, 1254587305, 293105.0821590594, string("GYhPEOSnpZKzbDqhfuWXlVfvTWuAfJvVjHZRkviWjTYpfGmLKVQWBgdbEdksccFouqNPidSnVwYomXolYPpoYezAOpVaghhaHguDrhTJQNpH"));
    this->BIQKZ(true, true, 381625.49207891995, 179288.90501916295);
    this->TfyNBDaFlsQ(false, 599732621);
    this->TpcOPv(-1307948169, string("gOpScXiYcVGskaLPkvHwevzuqQCpUmDSJZWpMJsvuihvPcVBpLWXXjDqaMmCJt"), string("ZusJwIyjmjMtOMMZsRkwTorTGBYFMtBgxQDwudpjInVlMysLSKTNIvJmvYWXUvypjTOzbsGREofDrfKbYEbcNSMrPqbMwRwtakEzJOLeomKKVxzYgNFfEEwPcBRt"), -350041030, -565130.3515715173);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class PblPtI
{
public:
    double VtmbkSNjqFAgn;

    PblPtI();
    void GxyhwjeRiyM(int iThYwPtv, bool KZUKaSMuMirYGO, double hPJNZOhUAmaxxXo, double fMBbM);
    string YFkNtciyWYuKw(bool UfhbtDQootYvAPe, int CZZrXrhWAHcDcd, double ivysHgwNcSQz, string taVMyEgYidCdkJRV, bool ZxyHnFOrxBElqVC);
protected:
    string DYOKEvXmOKCWQzV;
    string UhSQya;

    void lHrnJyVDr();
    int QuktbbGF(double amlsQWT);
    void kJFHWiUchjGUEQsC();
    bool IVIKYK(double kLGLdzhDSZ, int wCidiRGx, int kcdbJzyvxcXoaW, int WRpHimZwDpD, bool UwuIe);
    double NxzVaupXlpels(string AjLmCkg);
    bool xaRKTlFA(int zZEKqWhTTR, double XIIJJk);
    string XAPHqzN(double WDvcSDMChSa);
private:
    double xkVvHFwhPSXRD;
    int tANETUCvYbHqiVz;
    string dCTnwHVecA;
    int cbyWVQaTuRHPy;
    int lduwJOplMRdTTLw;
    double hxdkNheKsQUQjU;

    double aEBcEhuUaOeaUU(bool UNLSgIVcsTjsH, int eqwmpKxxEMhpcCHP, int ikAkvqYRNpyT, bool WWEWPyE, int WzkdNBGVHvCMQ);
    int kBAhqiYSfFvEd();
    bool utdDoGWwyKuwuB();
    void oGoDaO(int hqWLK, double OYzDAfsqFEM, string zvSBkxHtIXz);
    bool YTdSKlXZNGYlrTV(string iKOtGadFHRlwQ, int ywVCuu, int DvPUNCdXPYqn);
    string PdyimQ(string ydSwoKL, bool jbLCKlKVKzvZSOxi, bool AcPNvlfbzicLZA, string RAaBPUjrvlmF);
};

void PblPtI::GxyhwjeRiyM(int iThYwPtv, bool KZUKaSMuMirYGO, double hPJNZOhUAmaxxXo, double fMBbM)
{
    double mLjOsEkEZkGieUv = -336762.0386776446;
    string vTgdJ = string("XBMOEtHFYoYHJwCwUKQTaHcTAmYPBRcUQqUHyJgQNMQmUkiKXrcWBYpNMsyBOtMIIioMOzCvdLtskEJxnnccnahXdndHYzxuF");

    for (int qyzhstDHXDmOsGJz = 527388787; qyzhstDHXDmOsGJz > 0; qyzhstDHXDmOsGJz--) {
        mLjOsEkEZkGieUv = hPJNZOhUAmaxxXo;
        hPJNZOhUAmaxxXo += fMBbM;
        hPJNZOhUAmaxxXo /= hPJNZOhUAmaxxXo;
        mLjOsEkEZkGieUv = mLjOsEkEZkGieUv;
    }

    if (fMBbM != -336762.0386776446) {
        for (int sabGBw = 1405727196; sabGBw > 0; sabGBw--) {
            continue;
        }
    }

    if (hPJNZOhUAmaxxXo == -336762.0386776446) {
        for (int xxcCW = 1754324913; xxcCW > 0; xxcCW--) {
            fMBbM += mLjOsEkEZkGieUv;
            mLjOsEkEZkGieUv -= mLjOsEkEZkGieUv;
        }
    }

    for (int sTQZLugd = 1827026437; sTQZLugd > 0; sTQZLugd--) {
        iThYwPtv -= iThYwPtv;
    }
}

string PblPtI::YFkNtciyWYuKw(bool UfhbtDQootYvAPe, int CZZrXrhWAHcDcd, double ivysHgwNcSQz, string taVMyEgYidCdkJRV, bool ZxyHnFOrxBElqVC)
{
    int xEfNa = 586160765;
    string ZxQQytedwxjueNEh = string("RJJmLCZrVLLugHHBhWCmPzNIBPHZbesSWOmDNJCfofgDIQPhEjcSbhbrJCtvsfvyrXxpTNYCvIxjkzOChRuadFbxgJSJvARcbnutVmVpAedbdUIVSknLyEmCbXtbWxEupYUkZSdgwZSNADbBWIkMpNJzpElhhIPfIMw");

    for (int AVHtWCM = 152907664; AVHtWCM > 0; AVHtWCM--) {
        ZxyHnFOrxBElqVC = ZxyHnFOrxBElqVC;
        CZZrXrhWAHcDcd += xEfNa;
    }

    if (ZxyHnFOrxBElqVC != false) {
        for (int ifRvv = 417176219; ifRvv > 0; ifRvv--) {
            ZxyHnFOrxBElqVC = ZxyHnFOrxBElqVC;
        }
    }

    return ZxQQytedwxjueNEh;
}

void PblPtI::lHrnJyVDr()
{
    string ZAVQPhqpSKtSm = string("aEyGlrdBWUXjsblMxlNjVsfQbFJuKffndORUmoFCWFgwMpfYzjgBnZJThEnvDQuiIQzFBzetSyUdzFLICTXKtUmxnWwwAnQvYDjsrB");
    bool veDMAmcc = false;
    bool tcWpcvIgzYjgbW = true;
    string qYPKiuWcwPD = string("dBPOSpirQTdMZvEUlILjjTQgcIxUyjsNsvpWawIbrpHSjRqzkJAoGcIZZJoIgfqXaupyzJiuoCBGGEGppxxZFbcfPfIEUdPsdcnDcNYTxPfrddjRXFOnjyTDWoPQmtFcxLRlWXfrldQKZtuFMIVGETUiwrTrFdHZryMFjfDLWgdgLBEBsCYJDhIDvHezGhxroXVxrkNCvoDuFVViaNvsBroJcRhibGhQKusWUTspuQsgLIBvDLhrKAZB");
    double zvOjo = 954717.8935910452;
    bool yBroYjBnCDB = true;
    int yJVrVCsY = -1267812746;
    int ESyqWBsrUlJO = -1038034029;

    for (int YhljVcYkFTNCkcF = 159110167; YhljVcYkFTNCkcF > 0; YhljVcYkFTNCkcF--) {
        yJVrVCsY = yJVrVCsY;
    }

    for (int axzvnjwG = 493469825; axzvnjwG > 0; axzvnjwG--) {
        zvOjo = zvOjo;
    }

    if (yBroYjBnCDB == true) {
        for (int pQgAxcoolDVyEZ = 1154840647; pQgAxcoolDVyEZ > 0; pQgAxcoolDVyEZ--) {
            continue;
        }
    }
}

int PblPtI::QuktbbGF(double amlsQWT)
{
    bool anoGOs = false;
    double zPXPihAzpuyfPpAB = 423817.01592012803;
    int BNUBMuuARByteEdG = 513139388;

    for (int XKlSOBK = 1264679521; XKlSOBK > 0; XKlSOBK--) {
        continue;
    }

    return BNUBMuuARByteEdG;
}

void PblPtI::kJFHWiUchjGUEQsC()
{
    bool LSbOunDAaIVfTE = true;
    string FuNrpbcr = string("EwaZZXwSRPfANxFfxIkIcAdUGZvotYiILnxhhgSflmsNpOqiLPmYOeFxYOTRyJSF");
    bool wRQHgh = false;
    int QdrqOqzo = -1758102825;
    double EPbuYJ = 114350.99048647736;

    for (int wKAEDfbiKWYn = 1190325524; wKAEDfbiKWYn > 0; wKAEDfbiKWYn--) {
        continue;
    }

    if (wRQHgh != false) {
        for (int BNgFLfDtOFIH = 671292445; BNgFLfDtOFIH > 0; BNgFLfDtOFIH--) {
            wRQHgh = wRQHgh;
            EPbuYJ += EPbuYJ;
        }
    }

    for (int uoBhvXcTj = 820579546; uoBhvXcTj > 0; uoBhvXcTj--) {
        continue;
    }
}

bool PblPtI::IVIKYK(double kLGLdzhDSZ, int wCidiRGx, int kcdbJzyvxcXoaW, int WRpHimZwDpD, bool UwuIe)
{
    string bIrmMdFXmGoCcJnZ = string("NaWAOdqWqAzUpgWWRdQerYVaotAeihITbwUUyuzhrGrZJbexVZQarErBRnLsqFifhEqZMPPEJaGfXdoewmltIriiiafhYdZsgYioxIyHWkwMycUFcburRxVccilSYYbzFMhyrGGnRygKoFhqQRcblrQoOHHYQJniyDIbQGwgLsqukQKIxXfjXeVpEOYDhPOwtJXjwKTSOOVjUvqKmugDqhBzQeEqSbsYgxlbVbrFvHiXOBNzdxcElLpmYLNNRnh");
    string CibxBPtBJx = string("nvmkUQsitdnXRdjATnQxKfrKxlDrakEsovaXnJjWvvlsrCUImRBCZGBkUxU");
    double fDnoOaoSNIzgTzp = 367367.83278090943;
    string UJvkq = string("AaHOWNtCJJgWJqYzDZHZFqSqtUQoyeUFtdFnCKMzHLdTlJeIpxzOzyvQcwFTlFbeHyTOemKtvaHUaITdRThAuLygQgqKLhNgkXHUTulzJLDCkeBwNNBhmBlkOQLIPjYNIHTWMisNfF");
    bool MGBDlwLUMFaZHEt = false;
    int mcOkDPuSiIe = -1067199060;
    double RBhwIcOsWoEgeZB = 30789.814633982558;

    if (mcOkDPuSiIe > -921915611) {
        for (int mitbuj = 1716567993; mitbuj > 0; mitbuj--) {
            WRpHimZwDpD /= mcOkDPuSiIe;
        }
    }

    for (int PrDFJd = 304178014; PrDFJd > 0; PrDFJd--) {
        continue;
    }

    for (int kvZhBwELEr = 1849967574; kvZhBwELEr > 0; kvZhBwELEr--) {
        kcdbJzyvxcXoaW = mcOkDPuSiIe;
    }

    for (int fmzBXeofaFVFGDp = 770061966; fmzBXeofaFVFGDp > 0; fmzBXeofaFVFGDp--) {
        fDnoOaoSNIzgTzp += fDnoOaoSNIzgTzp;
        CibxBPtBJx += UJvkq;
    }

    for (int EceoJUwMer = 1458296225; EceoJUwMer > 0; EceoJUwMer--) {
        CibxBPtBJx = CibxBPtBJx;
    }

    if (MGBDlwLUMFaZHEt != true) {
        for (int NjtxxIBog = 1641535420; NjtxxIBog > 0; NjtxxIBog--) {
            RBhwIcOsWoEgeZB -= RBhwIcOsWoEgeZB;
        }
    }

    for (int mzuVJWRUL = 698463338; mzuVJWRUL > 0; mzuVJWRUL--) {
        mcOkDPuSiIe /= WRpHimZwDpD;
    }

    return MGBDlwLUMFaZHEt;
}

double PblPtI::NxzVaupXlpels(string AjLmCkg)
{
    int EsZEIWsKeqqfhXC = 811894784;
    bool yzrEvUaUpos = false;
    string kUZRXvzpufKHsmmv = string("aPbCAOeoJNSiYeWLWFtKGMyUlxaphCOwAwcyCKVAHVWcGQFPzvgmdyOizKkwHlNHoCOPCtLnFQPuLlXYwvxOkQFZyBCkhjNWanGwANTkcKSYespzWsupmWRdHCXAGrYdLkGzFVRYSkaWsAcMPwqcaDnlvzfQOpRNbrTgYeCtw");
    bool yjwyElS = true;
    double oXingWImB = 920206.6826120224;

    for (int fREbW = 1108193313; fREbW > 0; fREbW--) {
        AjLmCkg += AjLmCkg;
        yzrEvUaUpos = ! yjwyElS;
        yzrEvUaUpos = yzrEvUaUpos;
    }

    for (int YgOQUTQb = 596984898; YgOQUTQb > 0; YgOQUTQb--) {
        kUZRXvzpufKHsmmv += AjLmCkg;
    }

    return oXingWImB;
}

bool PblPtI::xaRKTlFA(int zZEKqWhTTR, double XIIJJk)
{
    double qvVhDJMTear = -132006.3608783651;
    string UlZKk = string("lqesAuwMNDvRhtEmUWANaSfnJyxcJtllHjcFHJvrAlmsGxUoRAJRybiyCVqjXxLTceLCqXbUlbnmfEAJvNCrrISENYMCEdNzugTevHNLTCskeSAdhYkufBjkfHfFjcjTXToayufifLMcSTwKqEmaqBzhIGxaERNmUALnZHBXcUccsUrRPkbvzJKpXgCMhojquRNGDWoDDdggODNaHguOdGV");

    for (int BDNlOAlvPoR = 20326522; BDNlOAlvPoR > 0; BDNlOAlvPoR--) {
        zZEKqWhTTR = zZEKqWhTTR;
    }

    for (int labtTffAeE = 574012662; labtTffAeE > 0; labtTffAeE--) {
        qvVhDJMTear += qvVhDJMTear;
        qvVhDJMTear *= XIIJJk;
        UlZKk += UlZKk;
        qvVhDJMTear *= XIIJJk;
        XIIJJk *= qvVhDJMTear;
    }

    for (int tZhFWF = 963935621; tZhFWF > 0; tZhFWF--) {
        zZEKqWhTTR *= zZEKqWhTTR;
        qvVhDJMTear /= XIIJJk;
        qvVhDJMTear = qvVhDJMTear;
    }

    for (int FVeBjjSll = 896387358; FVeBjjSll > 0; FVeBjjSll--) {
        XIIJJk /= XIIJJk;
        XIIJJk *= XIIJJk;
        XIIJJk /= qvVhDJMTear;
        XIIJJk = qvVhDJMTear;
    }

    for (int vKiArUwKd = 791713006; vKiArUwKd > 0; vKiArUwKd--) {
        XIIJJk /= qvVhDJMTear;
        qvVhDJMTear = qvVhDJMTear;
    }

    return false;
}

string PblPtI::XAPHqzN(double WDvcSDMChSa)
{
    string bpBNNApgnepGq = string("uMHSfYbYOFOGwm");
    double RfrRiBAqR = -721400.4761209348;
    double LBGJycGXx = 821079.9159632222;

    for (int VehcERj = 1668934117; VehcERj > 0; VehcERj--) {
        RfrRiBAqR -= RfrRiBAqR;
        WDvcSDMChSa -= WDvcSDMChSa;
        RfrRiBAqR *= WDvcSDMChSa;
        WDvcSDMChSa += LBGJycGXx;
        LBGJycGXx = WDvcSDMChSa;
        LBGJycGXx /= RfrRiBAqR;
    }

    if (LBGJycGXx <= -12123.56479234077) {
        for (int QYtXyaueZtSWzTdC = 1643660017; QYtXyaueZtSWzTdC > 0; QYtXyaueZtSWzTdC--) {
            LBGJycGXx *= RfrRiBAqR;
            RfrRiBAqR -= LBGJycGXx;
        }
    }

    return bpBNNApgnepGq;
}

double PblPtI::aEBcEhuUaOeaUU(bool UNLSgIVcsTjsH, int eqwmpKxxEMhpcCHP, int ikAkvqYRNpyT, bool WWEWPyE, int WzkdNBGVHvCMQ)
{
    bool wwYdnOzgDoZFiB = true;
    bool FchzzX = false;
    double zMHJMkjNviDwDx = 406482.50194579276;

    for (int gNExbm = 1621975976; gNExbm > 0; gNExbm--) {
        UNLSgIVcsTjsH = FchzzX;
        zMHJMkjNviDwDx += zMHJMkjNviDwDx;
        wwYdnOzgDoZFiB = WWEWPyE;
    }

    for (int yOfecryyHXDEMs = 1311282735; yOfecryyHXDEMs > 0; yOfecryyHXDEMs--) {
        WWEWPyE = FchzzX;
        WWEWPyE = UNLSgIVcsTjsH;
    }

    return zMHJMkjNviDwDx;
}

int PblPtI::kBAhqiYSfFvEd()
{
    string fySBncHcxy = string("UQPYfqhwIZhYUHtUEwHouChmANXxrZVrQSnKjmVLFzMTMaWbvCcKqSiIxKSkOidwQSypnjKyIDSPLJdOZPskUfUzJnflrZBsKsL");
    double MmeOebCA = 444227.71803755424;

    for (int sMZocXlVQw = 1835681395; sMZocXlVQw > 0; sMZocXlVQw--) {
        fySBncHcxy = fySBncHcxy;
        MmeOebCA = MmeOebCA;
        MmeOebCA /= MmeOebCA;
    }

    if (MmeOebCA != 444227.71803755424) {
        for (int XLiCxnmpgX = 1764988817; XLiCxnmpgX > 0; XLiCxnmpgX--) {
            fySBncHcxy += fySBncHcxy;
            MmeOebCA -= MmeOebCA;
            MmeOebCA -= MmeOebCA;
        }
    }

    if (fySBncHcxy <= string("UQPYfqhwIZhYUHtUEwHouChmANXxrZVrQSnKjmVLFzMTMaWbvCcKqSiIxKSkOidwQSypnjKyIDSPLJdOZPskUfUzJnflrZBsKsL")) {
        for (int OuerzKICIVAgJao = 2078309434; OuerzKICIVAgJao > 0; OuerzKICIVAgJao--) {
            MmeOebCA /= MmeOebCA;
        }
    }

    if (MmeOebCA == 444227.71803755424) {
        for (int lgqXIXnrk = 659045426; lgqXIXnrk > 0; lgqXIXnrk--) {
            MmeOebCA -= MmeOebCA;
            MmeOebCA *= MmeOebCA;
        }
    }

    return 2103005408;
}

bool PblPtI::utdDoGWwyKuwuB()
{
    bool attGb = true;
    int eCzsZHu = -1601302891;

    if (eCzsZHu == -1601302891) {
        for (int MANJQnSSg = 1351589605; MANJQnSSg > 0; MANJQnSSg--) {
            eCzsZHu /= eCzsZHu;
        }
    }

    for (int YkOVhLh = 952978862; YkOVhLh > 0; YkOVhLh--) {
        eCzsZHu = eCzsZHu;
        attGb = ! attGb;
    }

    return attGb;
}

void PblPtI::oGoDaO(int hqWLK, double OYzDAfsqFEM, string zvSBkxHtIXz)
{
    double zfwBFZy = -904811.0786383898;
    int svXOANjuRzvVhz = 901928500;
    string svjynqpClHILALoQ = string("YOspPyTOKVMHduXFiGOWXTlwrbtbyDnFYmxsCiYgrcPLpTEOqipgjhCiRIZhdpJYVqpLmneeWLTmNjRml");
    int zGcJve = 2126307861;
    bool RfPYDy = true;
    bool XjmYtniCvWZwE = false;
    int vwMUHhdfcK = 1394641440;
    bool BXHGOxrEEp = false;

    if (svXOANjuRzvVhz == 1394641440) {
        for (int TrPlom = 862407716; TrPlom > 0; TrPlom--) {
            svXOANjuRzvVhz += zGcJve;
            svXOANjuRzvVhz *= vwMUHhdfcK;
        }
    }

    for (int bIMOMivQi = 1907768522; bIMOMivQi > 0; bIMOMivQi--) {
        svXOANjuRzvVhz *= svXOANjuRzvVhz;
    }

    for (int CkbdAvl = 743929947; CkbdAvl > 0; CkbdAvl--) {
        continue;
    }

    for (int MNrhGzrMH = 44679335; MNrhGzrMH > 0; MNrhGzrMH--) {
        continue;
    }
}

bool PblPtI::YTdSKlXZNGYlrTV(string iKOtGadFHRlwQ, int ywVCuu, int DvPUNCdXPYqn)
{
    bool hrQRSWDOSlJ = true;
    bool TjYFdHJcEmUJAQIC = false;
    double oUcvMYI = -513787.7171789514;
    string BLIjiYE = string("sxpBUC");
    int PBznMZVxElQl = 552273813;
    string xRdnmy = string("eEbREYTLaJHtFwNnxqLSCyFRdcrEZqPwvYJKLHRDEgIvjGSPHavutAQKRhutHyielRzVQMWVZFOXTqQhkFjyJPEIBAxUQcTFLUgFmJcEkIBxS");
    string snBznNcx = string("frZDHTEmeJtTwveSNsggzVYvHzknvZYPaOJNbiStTTdXOHIhIVtDoEJcBMgcszilrDQMyyTRhBBgWCXCJYBGcmiKQEaYuOiFnTctpmoUVAsBRZhLBJsKuNIuZxkLdNvMoCuQHCKseqZDkyiIxrFpAZsYaXnaEYwkrGAjUGkdHcLlNmKijChCgFgXVgOTnFPwDoSqVARWrvLcOZ");

    for (int tKaZzOJCtJDc = 161166347; tKaZzOJCtJDc > 0; tKaZzOJCtJDc--) {
        ywVCuu *= PBznMZVxElQl;
    }

    for (int kWygIhybiop = 340345259; kWygIhybiop > 0; kWygIhybiop--) {
        TjYFdHJcEmUJAQIC = ! TjYFdHJcEmUJAQIC;
    }

    for (int kzJmklFrOrTwNbp = 1793540790; kzJmklFrOrTwNbp > 0; kzJmklFrOrTwNbp--) {
        BLIjiYE = xRdnmy;
    }

    for (int FGRPLZLRimLXPG = 1411720281; FGRPLZLRimLXPG > 0; FGRPLZLRimLXPG--) {
        BLIjiYE += iKOtGadFHRlwQ;
        snBznNcx = iKOtGadFHRlwQ;
        PBznMZVxElQl -= DvPUNCdXPYqn;
        ywVCuu /= ywVCuu;
    }

    for (int KiciHadRqhNVIt = 832851488; KiciHadRqhNVIt > 0; KiciHadRqhNVIt--) {
        xRdnmy = snBznNcx;
        snBznNcx = BLIjiYE;
        iKOtGadFHRlwQ = iKOtGadFHRlwQ;
        BLIjiYE += xRdnmy;
        TjYFdHJcEmUJAQIC = TjYFdHJcEmUJAQIC;
    }

    return TjYFdHJcEmUJAQIC;
}

string PblPtI::PdyimQ(string ydSwoKL, bool jbLCKlKVKzvZSOxi, bool AcPNvlfbzicLZA, string RAaBPUjrvlmF)
{
    double fDrRNytvI = -189943.35184017385;
    int aFzyqkhXm = 1198925358;
    double RmLeJqxwARs = -179037.59075255945;
    bool ZajcEJwW = true;
    double TyGgJFYlwdS = 332861.67892774125;
    int PYsUXZKhdUvqGl = -1700885361;

    for (int aGzCfb = 952608843; aGzCfb > 0; aGzCfb--) {
        TyGgJFYlwdS *= fDrRNytvI;
        TyGgJFYlwdS /= TyGgJFYlwdS;
    }

    for (int eGOpUDARZpowb = 931416692; eGOpUDARZpowb > 0; eGOpUDARZpowb--) {
        AcPNvlfbzicLZA = ! AcPNvlfbzicLZA;
    }

    if (ZajcEJwW != true) {
        for (int iSgXoeMUlS = 965951331; iSgXoeMUlS > 0; iSgXoeMUlS--) {
            TyGgJFYlwdS += RmLeJqxwARs;
        }
    }

    return RAaBPUjrvlmF;
}

PblPtI::PblPtI()
{
    this->GxyhwjeRiyM(1741131286, false, -366078.53058865824, 582023.576790578);
    this->YFkNtciyWYuKw(false, 647967148, -22019.174928649125, string("QqyCvEESJVnMROwEOtFsipVgAduokEJeLwjLGgrumKOlkCmVtCmrbUUJXlWSrUbfgzOCFuAboREGrepFNOVRAyCyCQjVgPSRXHaRXDpIkQQeZrjNpcWGUMNLHbQfZugaEWQLURQAykXIzyIDWGcxXBbsTDBTWxNQotnbaywbXfEkYdqGkzlvIpd"), true);
    this->lHrnJyVDr();
    this->QuktbbGF(-13831.016479025413);
    this->kJFHWiUchjGUEQsC();
    this->IVIKYK(771275.2895240611, -1083685958, -921915611, -157528440, true);
    this->NxzVaupXlpels(string("GHYRDfFNMIrshhiCseJSkdCtAYraahRoxVXUiUmKTCfljHnvEyNqDdZmizTJZlAFQWrPJscElnxHRExtcywKrWkanROKidoHVpuRDTQZcvohqroJTOHxReIKOuznoqPWVrbMVulVNYFmKgCCCiMGxLlyvMOUWQiCAWFYMxigMLrZJFdQJcySKczWgFaPIZkg"));
    this->xaRKTlFA(1523691946, -951449.1688497984);
    this->XAPHqzN(-12123.56479234077);
    this->aEBcEhuUaOeaUU(false, 187525257, 419756253, true, 834049289);
    this->kBAhqiYSfFvEd();
    this->utdDoGWwyKuwuB();
    this->oGoDaO(987021249, -597323.6099372463, string("qftBZXXEYvbwnjbgJfxrwuFrhWKdqeKzGDepNlqzFzNCzgaNVtAyXMMyGuXaEhbxaNVZotLLVQokjgwcJFfRz"));
    this->YTdSKlXZNGYlrTV(string("CxvAlJedfMqoLLMycntppYTqgmCsZGnDPcerpjqEqxdCFVKACbGsFIpJzUGYNReRqKxOrPRcbnEXZjbiySuvvlgIyRbEQOpydszKnGEyMiSKMeB"), -1327625990, -551692994);
    this->PdyimQ(string("eoZtXKmlHTCIxJhlTabKQFXAT"), false, true, string("qhlHquafGAAQnGKzESAsNZDMMZgaDQdOQwIHSshXOUunQBQfBDArfwzBrQprpfgoZnSZvIFthsdXkAsUj"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class rfGunFIGLKjOOnsk
{
public:
    double UWyPkRJb;
    double JWYYJTI;
    bool dAxUhZMIHev;
    double XQZSxzJWAXdTMRc;
    string XyJGTDWp;

    rfGunFIGLKjOOnsk();
    string mssNvOCPPPbqny(bool YspMTsXyDc, bool WtCKTjHdnQs, int ChhcJNfquqPpwz, double qECehjouVQqU, bool coNIKAhzEOUFa);
protected:
    string ByyCODPrWa;
    string gfCQs;

    double BfFbkdMfXbApUmw(int onRcAN, bool kcPDmnUVqXiRKSs);
    int bMosNqW(int PaHunGEbujFfLu, int RWOkUzuCYZqi);
    void BbhgxiQ(string AZRkcAwPoS, int CEeAlGkotNo);
    string ckaspjFDqMuyJn(int aRVDZSHUHJ);
    string lFZcYXXkg(string MWyJUdK, int SLWJVMPTIjjgGhUq, double VxWyvFxHfIOH);
    void PQotOMjIRXvxKRJL(double lTGmikhGcot, bool LpZmuSVsqBdJwvDM, double OSnhQQ, bool WFypzqcweI, string bqsmVcqkdE);
private:
    int BJIwVWbDnVlgGTU;

    void QbzjHrUSCi(string svpWOKpfrp, bool wjmvGdiGPToYAGEG, bool tUznbBafIIG, int YSVGNGJ);
    double ibizifZDcVK(double IbWqubsOH, bool aWmqIcsBPb, double zthrmgzWmij, int iCLnY);
    int lusGMjbl(double igXwTo);
    double MRDlFiUcvAEiQq(double xmdYdxFO, int ENjXNZePxGnHfiWg, bool vQLeKkWdHSixVl, bool TFocnMGtdTlNg, bool OnsaVVBOgfgQbR);
    double kUssZBQNfgjubAf(int ydklYOsuqkTpJQj);
    int WhWZW(bool UWWGvVbhLYw, string LKKUoYy, bool qDAMQhXfkFJHb);
};

string rfGunFIGLKjOOnsk::mssNvOCPPPbqny(bool YspMTsXyDc, bool WtCKTjHdnQs, int ChhcJNfquqPpwz, double qECehjouVQqU, bool coNIKAhzEOUFa)
{
    int ptltzksWXkec = -598977021;
    double fyIvxIRH = -128573.10483396145;
    bool vQFrR = true;
    string TEaBoFvEzDwJYrt = string("ZTkoUZDZdgUOtabTujVGNqQWGtURljBkKHsGLDCAHEXcisKfhnANCCVPGipXyvisGJrVXxspOvFPwbjaKnXECxdxlJXLWEzRZNGtMqTXbedfUSVipfRpwMiKQkAgoLUalWuYuziEtCiajkFHVwtB");
    double nihVTqC = 271338.8392390108;
    string LyRfwwEGWWpBRmm = string("fYOlZsLsGyBMJWuPSFJrOfQLsiJaoITeGDVQhXVzinNzFMzOzCknJBiGqyNmZeKhRMfjUXeXApvMStWEkkwifgiJvuLXelUGPbHuwHHspwjDtmMYTnwvoQKHOucwimGLISglwCQsQlOGNFvmTHJGjwdFhNkhWXIQVctlaUDkfjuDVanwSQrVufglzpfRUufiJXKyrBfMVHUjKIKn");
    int NbFVsVkaNBLfuuks = 1524901776;
    bool AVhBPxLaLjBr = true;

    return LyRfwwEGWWpBRmm;
}

double rfGunFIGLKjOOnsk::BfFbkdMfXbApUmw(int onRcAN, bool kcPDmnUVqXiRKSs)
{
    int zVQWIWcvjhWQc = 878322373;
    double GmrePpL = 65605.90032635517;
    bool wbSHnyhk = true;
    bool qksVPohc = false;
    string nVZsVvHKT = string("qYCOHyUdhETqSUoUPCobBKrzoCVImfPpEoTQmekFehGFSqTXvAPKjLIqVwBBWBUfLQDAgZoZenVQewhjSIGAarVrsgiMhvvqnIIESPJdldHftJvAEnzNdDQPopxgSWIlAJOOfGCg");
    bool QEOyVgjzaCXGVEG = false;

    if (QEOyVgjzaCXGVEG == false) {
        for (int hioWUPZCvHT = 938675268; hioWUPZCvHT > 0; hioWUPZCvHT--) {
            onRcAN = zVQWIWcvjhWQc;
        }
    }

    for (int tGzcXvtSpzBTtbDK = 1054618312; tGzcXvtSpzBTtbDK > 0; tGzcXvtSpzBTtbDK--) {
        onRcAN = onRcAN;
        GmrePpL -= GmrePpL;
    }

    for (int vLPMoOIu = 462796406; vLPMoOIu > 0; vLPMoOIu--) {
        qksVPohc = qksVPohc;
    }

    if (QEOyVgjzaCXGVEG == true) {
        for (int esUMuJtnLzJbIZz = 632686601; esUMuJtnLzJbIZz > 0; esUMuJtnLzJbIZz--) {
            qksVPohc = ! kcPDmnUVqXiRKSs;
            kcPDmnUVqXiRKSs = ! wbSHnyhk;
        }
    }

    for (int rkzEQMAfR = 1627125386; rkzEQMAfR > 0; rkzEQMAfR--) {
        kcPDmnUVqXiRKSs = QEOyVgjzaCXGVEG;
        qksVPohc = ! wbSHnyhk;
        QEOyVgjzaCXGVEG = ! kcPDmnUVqXiRKSs;
        wbSHnyhk = ! wbSHnyhk;
        kcPDmnUVqXiRKSs = ! QEOyVgjzaCXGVEG;
        zVQWIWcvjhWQc = zVQWIWcvjhWQc;
        QEOyVgjzaCXGVEG = kcPDmnUVqXiRKSs;
    }

    for (int StHMgrVMMZQUBr = 1052132066; StHMgrVMMZQUBr > 0; StHMgrVMMZQUBr--) {
        wbSHnyhk = kcPDmnUVqXiRKSs;
        QEOyVgjzaCXGVEG = ! QEOyVgjzaCXGVEG;
    }

    return GmrePpL;
}

int rfGunFIGLKjOOnsk::bMosNqW(int PaHunGEbujFfLu, int RWOkUzuCYZqi)
{
    int OoUgVdJju = -455311617;
    string yJkzbhNsTDW = string("ebOrWtHsHKcUSjPDgShSCJqaColQGcLgCPTfOhbbpFXwmYqnIJZvpOUDqGYocEpiaYLSlXQtnIhNUvxyhzqDCICnzETuNFbtJPBiFFLfPyGMEkuhvBJm");
    double atIgDM = -505861.4649472591;
    int xHJVORubN = 522429973;
    string KraCYllCbkkJhNH = string("GQCuCyVNZsRGdAzaKgssjuPUNHesrmdnxygMbjMLzVvMQgbIeMYGDYyQDguMRAsxOFtElPuUeMmaUNniiNWECJvUYMHwsJcrpzQrqZTQKtdwQhQjTPznbDAKTuzIQUaUDKmvRGVXOQtuwHCQQgalISYWjVZEhYsbJC");
    int XXiZAKecmXQSWq = -1412488806;

    for (int eOAwMYGGyTxb = 362036373; eOAwMYGGyTxb > 0; eOAwMYGGyTxb--) {
        PaHunGEbujFfLu -= RWOkUzuCYZqi;
    }

    if (OoUgVdJju != 90404708) {
        for (int uoEqKfugqwtZUwwD = 633857956; uoEqKfugqwtZUwwD > 0; uoEqKfugqwtZUwwD--) {
            xHJVORubN += XXiZAKecmXQSWq;
            RWOkUzuCYZqi += OoUgVdJju;
        }
    }

    if (yJkzbhNsTDW > string("ebOrWtHsHKcUSjPDgShSCJqaColQGcLgCPTfOhbbpFXwmYqnIJZvpOUDqGYocEpiaYLSlXQtnIhNUvxyhzqDCICnzETuNFbtJPBiFFLfPyGMEkuhvBJm")) {
        for (int fwoPcjaUsurq = 1485023166; fwoPcjaUsurq > 0; fwoPcjaUsurq--) {
            KraCYllCbkkJhNH += yJkzbhNsTDW;
            yJkzbhNsTDW += yJkzbhNsTDW;
            RWOkUzuCYZqi = RWOkUzuCYZqi;
            RWOkUzuCYZqi -= OoUgVdJju;
            PaHunGEbujFfLu *= RWOkUzuCYZqi;
        }
    }

    if (PaHunGEbujFfLu < 90404708) {
        for (int RXMTuUcWkTqSnbX = 1093983497; RXMTuUcWkTqSnbX > 0; RXMTuUcWkTqSnbX--) {
            xHJVORubN /= PaHunGEbujFfLu;
            xHJVORubN += xHJVORubN;
            KraCYllCbkkJhNH = yJkzbhNsTDW;
        }
    }

    return XXiZAKecmXQSWq;
}

void rfGunFIGLKjOOnsk::BbhgxiQ(string AZRkcAwPoS, int CEeAlGkotNo)
{
    bool OdSXjdBkuarbfyM = true;
    double tLkbBcRM = 1016571.5648187626;
    double ZCpOywDIQPOdM = 564754.5520709599;
    double ZUnsUgUBypK = -1036787.0651954006;
    int OchQFokXfDOOFsj = 1497149520;
    string gRaLH = string("JPZgdoYnxueRGOO");
    string XbqjSUwUhr = string("YcgdHhIOkNRuIGvtOgxUADAdBnWZLSFamMIymofjorqOvfFFjbzgutUWaPeUhfohrmdWHmShKIEsfKHeIDjFkodijIrX");
    int ifzalXDd = -1304641281;
    int fZhuRviAO = -65286859;

    for (int GvBltmI = 726526949; GvBltmI > 0; GvBltmI--) {
        continue;
    }

    if (CEeAlGkotNo < -1304641281) {
        for (int EUVMIDLNt = 950919396; EUVMIDLNt > 0; EUVMIDLNt--) {
            continue;
        }
    }
}

string rfGunFIGLKjOOnsk::ckaspjFDqMuyJn(int aRVDZSHUHJ)
{
    int utCxG = 1563209939;
    string NmfFOZVFqwaIfh = string("VbrGpPfoZYlimxqasFZHmQyQJDMAUZLriXGQYdIgOhsWhnuPcNaNEmYkGgpPHmGXPbjsBViTkWEgpMXslY");
    double TGFKhwEUREpm = 718257.9592060249;
    string eRXRJqrNejlBH = string("qJdimlgpVRUQQDSQBvvzCqpFjTjniNrdbndWmvjLWRBMomFvVHVzGtiUKYQHVOuKZTNgqMQeTYYCO");
    bool rvyGmuczxq = false;
    double xQudkSoEMoxFR = -87985.89714297085;
    int SvvfWH = 1417554385;
    string YpfVC = string("MCaXYDRwAecamumJbYZhTDPTzKmMoNMHgBJXDqHvxFMekjCMnFZlbRQjaFWlLUMapbNTVZDsoiEVhmPphHYcuiQWFbWOt");

    for (int EAKoW = 1548567937; EAKoW > 0; EAKoW--) {
        xQudkSoEMoxFR = TGFKhwEUREpm;
        rvyGmuczxq = ! rvyGmuczxq;
    }

    for (int vpmnPmaOkT = 560941600; vpmnPmaOkT > 0; vpmnPmaOkT--) {
        eRXRJqrNejlBH += YpfVC;
        aRVDZSHUHJ *= utCxG;
    }

    return YpfVC;
}

string rfGunFIGLKjOOnsk::lFZcYXXkg(string MWyJUdK, int SLWJVMPTIjjgGhUq, double VxWyvFxHfIOH)
{
    int IPIJaPq = -930310058;
    int NhBAzTdcgQzhtno = 1233823319;
    int lNXcjpBf = -2100306416;
    bool EJTdmpo = false;
    double fKtGTClo = 570227.273360973;
    double HHVSUThNmIBw = -609407.9347495426;
    int CgoKbP = 1278785859;
    string llTjQcWaZvI = string("ZGTyVRtDZFXasbNIvERhsoRYjlOypXAoHeoiigcZMRVyscgYIDrJLaIRcWuvBrZSnIaZOSZiFdrcDHjMYDgmZmODezMcwVnMlTVNbBVZLKbGPOZqtO");

    for (int yjaaDmHuZkOYHxpD = 1592550444; yjaaDmHuZkOYHxpD > 0; yjaaDmHuZkOYHxpD--) {
        MWyJUdK = MWyJUdK;
        IPIJaPq = CgoKbP;
        VxWyvFxHfIOH += fKtGTClo;
    }

    return llTjQcWaZvI;
}

void rfGunFIGLKjOOnsk::PQotOMjIRXvxKRJL(double lTGmikhGcot, bool LpZmuSVsqBdJwvDM, double OSnhQQ, bool WFypzqcweI, string bqsmVcqkdE)
{
    bool SQfEWBB = true;
    bool ZQhBOFyCmmXNZ = false;
    string FqLuiYeYUmObZ = string("TAFycEsDAuQAEBqQnrKvvhQkRAXldyBShBZTaFwBLwXicPrmbHlRBnUexevZxonTObgKeWpyVRrtkjLvJtcGLxONlccZjqRdMbFblpZBgHaKUwIjoexNUtjwUzUBHGklJrETjYJegTDAcPUsAUtcHGuvxEYLAmkykQKxpzmDUsnjrhbPjipblrGOJARCOzZrdGFbgWyAbnWDetpFrWmQsKKCMCbycXntPsp");
    double EHKqQjuGnbwtbF = -607394.6139953178;
    double isfQizkSNrRzC = -263131.8222997428;
    string ekUjGWJnzt = string("WxadfVJJInhRVHzqwozWuwRPcKCQNaSqWNhAcoBTvoesHfDLRDpxkScXJPaJlfbwMdXEeKNWpMoWPEhIxjskrDqgdtRRpWcejOhUdHPhujMSbZEkalxfSZwbbpVnkofvwbWBTWtzXvsMlgnBIOJzsSXLWXGHbzNqPGNjGiIbScMTVVbcpBdoDFBhRjfdVaujZmmrDlsJoYeVZJbFasGEXd");
    string hrVabr = string("FJPQyrlWEehdasZkEvAHlKIIiEjmKhnsgNixXlJYJyxxghhAuwIWLgwuYWihEAOTKeDyGRYjmgxMvu");
    double VFzHduCqGYi = 701751.9555501342;
    double yvlcj = -751381.7231862042;

    for (int CghkEYetrReIlaHW = 1669701556; CghkEYetrReIlaHW > 0; CghkEYetrReIlaHW--) {
        FqLuiYeYUmObZ += ekUjGWJnzt;
    }
}

void rfGunFIGLKjOOnsk::QbzjHrUSCi(string svpWOKpfrp, bool wjmvGdiGPToYAGEG, bool tUznbBafIIG, int YSVGNGJ)
{
    int ajWTOytenVi = 3397132;

    if (wjmvGdiGPToYAGEG == false) {
        for (int cqvczalxAWnEd = 1136332677; cqvczalxAWnEd > 0; cqvczalxAWnEd--) {
            continue;
        }
    }

    if (wjmvGdiGPToYAGEG == false) {
        for (int dQuaO = 379507892; dQuaO > 0; dQuaO--) {
            wjmvGdiGPToYAGEG = tUznbBafIIG;
            tUznbBafIIG = wjmvGdiGPToYAGEG;
            ajWTOytenVi /= ajWTOytenVi;
        }
    }
}

double rfGunFIGLKjOOnsk::ibizifZDcVK(double IbWqubsOH, bool aWmqIcsBPb, double zthrmgzWmij, int iCLnY)
{
    string MEkuWlwSKwFhH = string("UVFdpnTfIEAYbaLiBYUJnmLOjenKjQaXgExQHpRJyFTXPCSjbBcSgnTtuGcjVcoFmXRdUvvhxEToiDrFFCPgM");
    int OCnWAobcq = 539541817;
    bool moBhBniI = true;
    double UiAuADsmbmrw = 866870.6320783229;
    int teZrVxwlLH = -1882471744;

    for (int gqIUBMjHXXh = 1684414502; gqIUBMjHXXh > 0; gqIUBMjHXXh--) {
        continue;
    }

    for (int CwUPtFeb = 1853143438; CwUPtFeb > 0; CwUPtFeb--) {
        moBhBniI = aWmqIcsBPb;
        iCLnY -= iCLnY;
        IbWqubsOH += zthrmgzWmij;
    }

    for (int XUiWwbr = 1935547441; XUiWwbr > 0; XUiWwbr--) {
        teZrVxwlLH *= teZrVxwlLH;
    }

    for (int wIBKGfb = 323867804; wIBKGfb > 0; wIBKGfb--) {
        continue;
    }

    for (int PhOvtRBvdpX = 751085634; PhOvtRBvdpX > 0; PhOvtRBvdpX--) {
        continue;
    }

    return UiAuADsmbmrw;
}

int rfGunFIGLKjOOnsk::lusGMjbl(double igXwTo)
{
    int JjnUElcQkSoplpyZ = -521719365;
    bool rIBFtIN = false;

    for (int oLeJnboMSiKSFlG = 1573617195; oLeJnboMSiKSFlG > 0; oLeJnboMSiKSFlG--) {
        rIBFtIN = ! rIBFtIN;
        rIBFtIN = rIBFtIN;
        rIBFtIN = ! rIBFtIN;
    }

    for (int MZflqoLyUyFNiP = 1279003374; MZflqoLyUyFNiP > 0; MZflqoLyUyFNiP--) {
        rIBFtIN = ! rIBFtIN;
    }

    if (JjnUElcQkSoplpyZ == -521719365) {
        for (int TPPMLrVcthWip = 1444384006; TPPMLrVcthWip > 0; TPPMLrVcthWip--) {
            igXwTo /= igXwTo;
            JjnUElcQkSoplpyZ += JjnUElcQkSoplpyZ;
            JjnUElcQkSoplpyZ /= JjnUElcQkSoplpyZ;
            rIBFtIN = ! rIBFtIN;
        }
    }

    for (int PLOAmybUBvFx = 5462869; PLOAmybUBvFx > 0; PLOAmybUBvFx--) {
        JjnUElcQkSoplpyZ += JjnUElcQkSoplpyZ;
        igXwTo -= igXwTo;
    }

    return JjnUElcQkSoplpyZ;
}

double rfGunFIGLKjOOnsk::MRDlFiUcvAEiQq(double xmdYdxFO, int ENjXNZePxGnHfiWg, bool vQLeKkWdHSixVl, bool TFocnMGtdTlNg, bool OnsaVVBOgfgQbR)
{
    double tFukPmgsqH = 1032644.0792895145;
    bool SBOTmXogbZNWK = true;
    double qYAdlgjKOnK = -485805.9016086215;
    bool RsSmmsowNOsxGX = false;
    double dzMkVQwj = -535313.9358339473;
    string lwkvsvkKQDkTbG = string("AqZHJOnHkLbjnikOAgJSOqKdmrmdzAUEPdEzOCfXRFRxBxPUtdtiRBmcqOJNepdAZbCiDJsybaJlxQvoidtBIbOuvpaMSvhXRMULNKwweqPsnWBUxTpmBnmnPVXyLJKdMLegLA");
    int HnVhelntIBNNXnwi = 314251583;
    int hqjyNmYNAcrymtka = -1240601207;
    bool sdaIYg = false;
    double jZskpDK = -574685.7756250466;

    for (int xGHHRXTIgk = 716605899; xGHHRXTIgk > 0; xGHHRXTIgk--) {
        vQLeKkWdHSixVl = ! TFocnMGtdTlNg;
        TFocnMGtdTlNg = ! TFocnMGtdTlNg;
        TFocnMGtdTlNg = RsSmmsowNOsxGX;
    }

    if (SBOTmXogbZNWK == true) {
        for (int tPDnhXQ = 450136331; tPDnhXQ > 0; tPDnhXQ--) {
            continue;
        }
    }

    return jZskpDK;
}

double rfGunFIGLKjOOnsk::kUssZBQNfgjubAf(int ydklYOsuqkTpJQj)
{
    int vYoGLdgNNuVzUmaB = -1198024386;
    string MtTkUZDboJDIrhjt = string("EFPUtnFsVcIaVAQjAhlUIPTKFZZrJwmPhZYabUAFAaaGVniOkdQEPlqZCwRWSvktjSSLeKuqEYcpANXWFxWPkIyRBeXEsHlvUpoJMMGNPItpojOWGbiSTDxVgefkfBSMLrKkBcFrOZhVWduBp");
    bool yKWyekpZte = false;
    string DvBfuC = string("zLXXgQFICJlYmZxeo");
    int xXdYvYwYbWxhvv = -1470049560;
    double uZrOMWFUhSsMN = -839121.7719751748;
    int QMGHuAXnuwfJXIK = 1869660735;
    int LLiPUKiC = -800545079;
    string jMQedolpj = string("qxFwaotLfXpftWVMnTdUGWJmxKPdBSRxgwWTYMRuOFhFeggubtzezFaNOgPtvKxAKIqsrUsVOEgounntbViQTTIncrEyRbqxAhEwScdZxmMmclyGQLjUXJFfmpzxSPejprtYLLBDdHJlIqmICWZkodnHUIquFcMfWOnqSpRmntDqo");
    bool ITPTgfjGgGXyAya = false;

    for (int PeMlWJzGgbkSIKN = 1107710571; PeMlWJzGgbkSIKN > 0; PeMlWJzGgbkSIKN--) {
        MtTkUZDboJDIrhjt = jMQedolpj;
    }

    if (QMGHuAXnuwfJXIK <= -1198024386) {
        for (int LzTKwvViycRBRiiz = 1085441059; LzTKwvViycRBRiiz > 0; LzTKwvViycRBRiiz--) {
            LLiPUKiC = xXdYvYwYbWxhvv;
            DvBfuC += jMQedolpj;
            xXdYvYwYbWxhvv /= vYoGLdgNNuVzUmaB;
        }
    }

    for (int krAbkhjGeTLS = 1191240374; krAbkhjGeTLS > 0; krAbkhjGeTLS--) {
        ITPTgfjGgGXyAya = yKWyekpZte;
        ITPTgfjGgGXyAya = ! ITPTgfjGgGXyAya;
    }

    for (int RAyICbPwKA = 1759928585; RAyICbPwKA > 0; RAyICbPwKA--) {
        continue;
    }

    return uZrOMWFUhSsMN;
}

int rfGunFIGLKjOOnsk::WhWZW(bool UWWGvVbhLYw, string LKKUoYy, bool qDAMQhXfkFJHb)
{
    double efZqlXKK = -525391.6990409764;

    if (efZqlXKK <= -525391.6990409764) {
        for (int bqhvkx = 920538691; bqhvkx > 0; bqhvkx--) {
            UWWGvVbhLYw = UWWGvVbhLYw;
            UWWGvVbhLYw = ! UWWGvVbhLYw;
            efZqlXKK /= efZqlXKK;
            qDAMQhXfkFJHb = ! qDAMQhXfkFJHb;
        }
    }

    for (int rWmoTOpPl = 858215406; rWmoTOpPl > 0; rWmoTOpPl--) {
        qDAMQhXfkFJHb = UWWGvVbhLYw;
        efZqlXKK /= efZqlXKK;
        efZqlXKK += efZqlXKK;
    }

    if (qDAMQhXfkFJHb == false) {
        for (int PqFhAnXBQiieS = 1002475530; PqFhAnXBQiieS > 0; PqFhAnXBQiieS--) {
            efZqlXKK *= efZqlXKK;
        }
    }

    return 621524948;
}

rfGunFIGLKjOOnsk::rfGunFIGLKjOOnsk()
{
    this->mssNvOCPPPbqny(true, false, -2100147935, 732939.2945562121, false);
    this->BfFbkdMfXbApUmw(-1520301693, true);
    this->bMosNqW(90404708, 931008588);
    this->BbhgxiQ(string("TdmQOwfpGnKojjyUFKIOOKRBxDXarShLAqrtBqADIJgNwTFkjkChbaOeJeUKxZljrrzrUVoDNFkSsRBpuimcKPBnknoEHKBGhUDxKZfRKYcGrsx"), -1539392194);
    this->ckaspjFDqMuyJn(376777554);
    this->lFZcYXXkg(string("CslnliSmnQf"), -1235753530, -776911.5010952);
    this->PQotOMjIRXvxKRJL(568954.5708184426, false, 227506.93556520564, false, string("bWECLYETxJVLgGfwKZCgHpvayzqbDXhUpNTLKiBsksAAxqpkvwpVUfNaSEtiSHbGqGbMXlFfjeAlNtccJCuvxNzVlFkyNYnhjxsrXTinWRydplgnqMXIYHnaKAYIRUQkShzwuFStKzDqvScIPRCzZrSBxOABuuXnxwaMnEThBLTFdRqPGp"));
    this->QbzjHrUSCi(string("qeSrPwgIdfniNyDtdc"), false, false, 395329663);
    this->ibizifZDcVK(-894766.3198843882, false, 27423.67953573493, -857423943);
    this->lusGMjbl(347557.5700101326);
    this->MRDlFiUcvAEiQq(822840.3207164799, 1892553464, false, true, false);
    this->kUssZBQNfgjubAf(1481716081);
    this->WhWZW(true, string("MoBtnTCRMeEkeIdMShQzKxkxndOFqWLeggBsEFOKyuLvQiTeAJBJC"), false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kzbKomQ
{
public:
    bool iJotvHIC;
    bool SfKGUaZrCPDo;
    string KdJjUp;
    bool pCOLrkqHIiJz;
    int PCTmtSXFDay;
    string NniQsXTzeZ;

    kzbKomQ();
    int ntAmDFi(double NQAHsVcbWT, string LEgDzmaOpu, int IvHgnqgkB, bool QrIPsdKOhLFAVZ);
protected:
    bool nfcXWkPOuFNRfiMf;
    bool CMHGTic;
    int LWqDJMFER;
    double eaayRiiW;

    void rKkhk(bool tKdRL);
    bool fiteWfCZZ(double qmXIHMMdzTuq, bool aAcKxcPJyPOSkxl, double iQwzU, bool tCYsMFcZNUWn, double dhdSUWSMmtedAM);
private:
    string JfnFGGJl;
    bool lVurLO;
    int BuOZnztwQMtm;

};

int kzbKomQ::ntAmDFi(double NQAHsVcbWT, string LEgDzmaOpu, int IvHgnqgkB, bool QrIPsdKOhLFAVZ)
{
    double gmnZnlItey = 889674.0736500529;
    bool icaoux = true;
    bool NXptyBSuqgoO = false;
    bool EmUJC = false;
    double CNwHTtIa = -602849.5415413212;
    int XNEokT = -1250747663;

    for (int RWjLpfZethBRINQ = 380909081; RWjLpfZethBRINQ > 0; RWjLpfZethBRINQ--) {
        NXptyBSuqgoO = ! NXptyBSuqgoO;
        XNEokT /= IvHgnqgkB;
    }

    for (int ZhLtSGF = 1144849696; ZhLtSGF > 0; ZhLtSGF--) {
        CNwHTtIa += NQAHsVcbWT;
    }

    return XNEokT;
}

void kzbKomQ::rKkhk(bool tKdRL)
{
    double SAQiLqwMtMUyBJM = -933823.1782089708;
    bool aIkGjil = false;
    string XQYXXzWyXelKWCyI = string("MuaclQnbPZfyljhLBdztJvLokiyNYgvarkAfrIyXZfmhQGgBvKVgaqfWznLXYCmuRqGqBqtvPVlPZIRLUWnUdrvdwmwkUwDFCpgHDSwgWMPcmFPFfCPGKYPFISUcgjJCQMIWIjuvfFuGBrQuUsugZPqYaDcWVNGee");
    int edFUZUennN = 1108365512;
    string kAwLdnx = string("oNKcRulCVtpypLiMncnyTwa");
    string xvpugjkLYxnVSR = string("VELqRtSjxLYHpBCyBTlsFypXWpHJSPjghqasZkVQgeNNKBuViajMrMvgkLCEJgOTksOkwAPCSZlWIkhUefzwCoDHflXrYupSDKRbTXCmbWPPTIEyOrdfMBMVFsgCWZZebyIyLMSTxChHtbaeZfwBkSkJDmiBMDIPsbDFdcilfUFOWIeVAxYbswzHEPBj");
    bool JkNwDflh = false;
    int rmSQQWbLCrE = -317974527;
    bool bqTHBI = false;
    int YRuOGVSqlNgQbVh = -1445592445;

    for (int XOTTFVaBynaMT = 338379554; XOTTFVaBynaMT > 0; XOTTFVaBynaMT--) {
        xvpugjkLYxnVSR += XQYXXzWyXelKWCyI;
        YRuOGVSqlNgQbVh -= YRuOGVSqlNgQbVh;
    }
}

bool kzbKomQ::fiteWfCZZ(double qmXIHMMdzTuq, bool aAcKxcPJyPOSkxl, double iQwzU, bool tCYsMFcZNUWn, double dhdSUWSMmtedAM)
{
    string MIrWn = string("ejpzBSdtQTUQyaCfFeaJhxkxuvERblELDZnWDXFnRZfOgybyeqyvCDACaQtVSGAAqgPlGcFermeQAisXGJZwQWTUlcXQbduTaprHlXVKOokMhazvWhswN");
    double CiQgY = -722501.2377032097;
    int IJaypkM = 209371497;
    double PWxqQgBnGyFtluMZ = -754220.2425680177;
    double wDxHPVVrLhgDRy = -860512.7072248193;
    double lRpXiLfeo = -932714.1400715744;
    double WhRbTSgGwpjgF = -257270.1432456161;
    int DwBlUKdNWF = -1019716230;

    if (WhRbTSgGwpjgF >= -722501.2377032097) {
        for (int HLgjbtAAXBNWvW = 1819538332; HLgjbtAAXBNWvW > 0; HLgjbtAAXBNWvW--) {
            aAcKxcPJyPOSkxl = aAcKxcPJyPOSkxl;
            WhRbTSgGwpjgF = dhdSUWSMmtedAM;
            dhdSUWSMmtedAM /= WhRbTSgGwpjgF;
            PWxqQgBnGyFtluMZ = wDxHPVVrLhgDRy;
        }
    }

    if (PWxqQgBnGyFtluMZ != -932714.1400715744) {
        for (int iBrXcB = 129169292; iBrXcB > 0; iBrXcB--) {
            continue;
        }
    }

    for (int sOAWfeERAu = 1326306406; sOAWfeERAu > 0; sOAWfeERAu--) {
        continue;
    }

    for (int RpRhJDcI = 772919408; RpRhJDcI > 0; RpRhJDcI--) {
        iQwzU -= lRpXiLfeo;
        CiQgY *= qmXIHMMdzTuq;
        wDxHPVVrLhgDRy /= PWxqQgBnGyFtluMZ;
    }

    if (qmXIHMMdzTuq >= 663198.1480550468) {
        for (int gjdxh = 1293591051; gjdxh > 0; gjdxh--) {
            dhdSUWSMmtedAM *= qmXIHMMdzTuq;
            CiQgY = CiQgY;
            iQwzU /= WhRbTSgGwpjgF;
            wDxHPVVrLhgDRy = PWxqQgBnGyFtluMZ;
        }
    }

    if (CiQgY == -722501.2377032097) {
        for (int pgHFEEfxiKsG = 1458161694; pgHFEEfxiKsG > 0; pgHFEEfxiKsG--) {
            dhdSUWSMmtedAM += wDxHPVVrLhgDRy;
            iQwzU += wDxHPVVrLhgDRy;
        }
    }

    return tCYsMFcZNUWn;
}

kzbKomQ::kzbKomQ()
{
    this->ntAmDFi(-315935.8501562578, string("opKgrkXqUnTxrmOKIVzziEpWHrIxXDWAyIdyufGwmiWkFPCPWLcwQbEiQxenLCfLWJzzPJJlPHhbXkwJlXxeHiyGRqOrCXQwkZLLGndmkjXvBzEwMkfwFkRrrcYDwRFTWAQgQDlAKmzmhqjASSNRlMGCDSJNUfosjcqDIDbbrlzlNMHpYmIKEOvIjkLHBdayUfmaxKstabFsexmAYAZLjbUlgwRWDslFNhuqlWtbJnymiEBM"), -659914819, true);
    this->rKkhk(false);
    this->fiteWfCZZ(261901.44332424126, true, 600600.1619385942, false, 663198.1480550468);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class AcXhTZI
{
public:
    string goCJBVAw;
    double JNhqlvjruB;
    int CnGfZdUsXx;

    AcXhTZI();
    void IdNQB(string qxpWUqCVhUe, bool zmKSajGbLMhFgz, int kJjjxkoRsS, string zEzRdTjKjFrG, bool jHJQUK);
    int XpXaqo(double hNjiwaTKbZOXUf, bool jiemZjSphoWkcOcs, string wtvQnXQfFO, string srOKYpNFK);
    void wvroyewmvqYa(double SNMrppkIAKfNTa);
protected:
    int FWNynHSHYta;
    int iULyVEYfe;
    string URBxBhIZFzJZ;

    int OHPehSJZIKUumM();
    int STeNzedomMZY(string XmVEGBixj, bool LFJpHmjjROVHmLI, bool FIgPt);
    int AhqidczXKWrpqx(bool sLntN, double sZqJz, double bgOROCUaiZX, bool YEJhC, bool KFQmrbmc);
    string HNUWPTVIizVkCwKl(string zKZpvCvpgMeYR);
    void NqWkzKACMWCoM(double siwYqFgqEwkG, double utGOnpsuEVLPcg);
    bool igkTQM(int LAdWohIjzOBK, double CYGxnCB);
    bool jDGQEZWeAEwfM(string ytKBnBCaQ, bool XNExFNZjCehl);
private:
    double MmoOxoZVcgdjiVu;
    string xctYomjn;
    double mVlvxSiodg;
    double cxBaewy;
    double QZlMAu;
    int MhFXWCaGvlSwNKX;

    bool vrfve(string evOFlar);
    int AWSMkBoC(double vQMHdpUgkUqUQW);
    void PMPodcuKxqk(int xoBDJcndx);
};

void AcXhTZI::IdNQB(string qxpWUqCVhUe, bool zmKSajGbLMhFgz, int kJjjxkoRsS, string zEzRdTjKjFrG, bool jHJQUK)
{
    string DbDHydiqNfbUR = string("CEculWTTqEnDAsGuIRIuJXVawTdyGZuiEKVpmsXtzEbkiSgefQDrwbbTGBadFHKrJUPbfrNBLmFEzvoQZAePQzhMNlzNpCFQAQmamlrrDhYmGsjpWQZRMRUxEHSqVtlwNOUtLtJXSmzyxKhUfAcQfUReTeWEdjXAHyFzxDUYiPlpoMwERYsirhxMrPRBhgvGkwOvylnBrFaiKduDunQQAUVVEtWCsFeqAmTpoS");
    string htHEnaDuHCnr = string("OeVvrWEktkoksjxKoJFHjYkLdToofIUmpGtvEbynbdRQjzMhbJjecqgdovrYxkYbJefosGKDXnPIcGhRpdLxlWEojDVeWOxymeEUhsnrghkgEeoFfYSPTkYSUobiJAZYcUAFMcBnovygWAATghkjVIzEmPFkX");
    int pdstitLscaUi = -779975586;
    bool crlwOpDLbF = true;
    double MTkrZYHZkXbc = 413907.61698998115;
    bool zymcPziPD = true;
    int lkTmGxvAqygd = -139596389;
    double HbObUtJVlcXWpOmC = 871251.9285610297;
    int krYTQKtmQqQPCVq = -1938353585;

    for (int ROjXYwU = 2105559664; ROjXYwU > 0; ROjXYwU--) {
        pdstitLscaUi += krYTQKtmQqQPCVq;
        zEzRdTjKjFrG = qxpWUqCVhUe;
    }

    if (MTkrZYHZkXbc == 413907.61698998115) {
        for (int aXiYJhxyiC = 1607102748; aXiYJhxyiC > 0; aXiYJhxyiC--) {
            pdstitLscaUi += kJjjxkoRsS;
        }
    }

    for (int nPdIBHkm = 815939306; nPdIBHkm > 0; nPdIBHkm--) {
        krYTQKtmQqQPCVq += pdstitLscaUi;
        DbDHydiqNfbUR += htHEnaDuHCnr;
    }
}

int AcXhTZI::XpXaqo(double hNjiwaTKbZOXUf, bool jiemZjSphoWkcOcs, string wtvQnXQfFO, string srOKYpNFK)
{
    string GlNKNgMF = string("cgdFePmKnVSuRConwciLdMmfAJOylKIZoPJMnoVXkbmXzZcciAFcrNsNExskBWyfOIMvEIhTkugCzGFbnadclOnuEXNYIBnZRLVyvPtNgPDbnaPmZxHWjFZBhtduijdFTKKResPNYLvfxsienQlbrYFGePTHewltdOIfH");
    int zntBhNen = -2101047980;
    string eqQjOFzJKdyVCjT = string("g");

    for (int TOylDDoMxiuCMCwr = 800116087; TOylDDoMxiuCMCwr > 0; TOylDDoMxiuCMCwr--) {
        wtvQnXQfFO = wtvQnXQfFO;
        srOKYpNFK += eqQjOFzJKdyVCjT;
        wtvQnXQfFO = srOKYpNFK;
    }

    return zntBhNen;
}

void AcXhTZI::wvroyewmvqYa(double SNMrppkIAKfNTa)
{
    int HCEcX = -2131870751;
    double jGCcFFiIRUxCsmV = 249060.5954099865;
    string rRvDxPsVgkDxnp = string("DtbabCPWTxuYrKrctjqtIMVMZgClzbYyiwLYtQVeotbBhUahTCrqSNzcGgqJjUYxNSpvLarlTxmtkTygUmqitzlGjmwzvgqpXygwRJJMTjUoQJYCfTENXMcjJSzoRYqcUsyLnKFvxDiiMAWoUtKobSZanLqYzCMSJpBlyFqrOxViIJiNPIfWMYA");
    int nQwVVBQnoPsvDW = -3122587;
    double eWkhzuEbabr = -962395.6838290674;
    string aawqcFI = string("jYPDZLMxQXXwMmogoeBJkjFjjUoGdeZjTGnHSPKaaBxNaiojqkMaxGsTZcVBNqyuIiYBgdoquIGNeZqVRaRPRdWomdtmFklNmKZxAdPdvggfGekllAGtbQHIHGcNRwbpdzrgbvTTnqFvaps");
    bool AQUCz = false;
    bool kKXjeK = true;
    bool MFLiDEziDILqrMQ = false;

    if (jGCcFFiIRUxCsmV != 249060.5954099865) {
        for (int yEckTOCLYgrPMg = 1958785949; yEckTOCLYgrPMg > 0; yEckTOCLYgrPMg--) {
            continue;
        }
    }
}

int AcXhTZI::OHPehSJZIKUumM()
{
    int CrJvGISyHZd = -1097598022;
    double BDqrAuGbhWPRJnoI = -124642.37535889912;
    double gVHiuogBWV = -551088.9498385574;

    return CrJvGISyHZd;
}

int AcXhTZI::STeNzedomMZY(string XmVEGBixj, bool LFJpHmjjROVHmLI, bool FIgPt)
{
    int wgHmRhU = -621345873;
    int YLtdwx = -1386663365;
    int vGNiADttXJjmAz = 860233377;

    if (YLtdwx == -1386663365) {
        for (int YRocnKKBuR = 957012923; YRocnKKBuR > 0; YRocnKKBuR--) {
            continue;
        }
    }

    if (LFJpHmjjROVHmLI != false) {
        for (int SBGGwbfDjJiJmEC = 544472337; SBGGwbfDjJiJmEC > 0; SBGGwbfDjJiJmEC--) {
            YLtdwx -= wgHmRhU;
            YLtdwx += wgHmRhU;
            FIgPt = ! FIgPt;
            wgHmRhU *= vGNiADttXJjmAz;
        }
    }

    if (wgHmRhU <= -1386663365) {
        for (int wsQgBPtPuNKmLry = 319427976; wsQgBPtPuNKmLry > 0; wsQgBPtPuNKmLry--) {
            wgHmRhU /= vGNiADttXJjmAz;
        }
    }

    return vGNiADttXJjmAz;
}

int AcXhTZI::AhqidczXKWrpqx(bool sLntN, double sZqJz, double bgOROCUaiZX, bool YEJhC, bool KFQmrbmc)
{
    double RGJJlrelu = 626202.8300344713;

    for (int vsCzbbUljrseWBE = 1305694039; vsCzbbUljrseWBE > 0; vsCzbbUljrseWBE--) {
        sZqJz += sZqJz;
        sZqJz = sZqJz;
        bgOROCUaiZX -= bgOROCUaiZX;
    }

    for (int GlCgxpy = 1139087821; GlCgxpy > 0; GlCgxpy--) {
        bgOROCUaiZX = sZqJz;
        sZqJz -= bgOROCUaiZX;
        KFQmrbmc = YEJhC;
    }

    if (sZqJz != 635829.745636021) {
        for (int ICKPblwjDbtpvk = 284149473; ICKPblwjDbtpvk > 0; ICKPblwjDbtpvk--) {
            KFQmrbmc = YEJhC;
        }
    }

    if (sZqJz > 2731.0459596673154) {
        for (int IniKwDFo = 2124938157; IniKwDFo > 0; IniKwDFo--) {
            YEJhC = KFQmrbmc;
            bgOROCUaiZX -= sZqJz;
            sLntN = ! KFQmrbmc;
            KFQmrbmc = sLntN;
            KFQmrbmc = ! KFQmrbmc;
        }
    }

    for (int GQehnhsksS = 2030173917; GQehnhsksS > 0; GQehnhsksS--) {
        KFQmrbmc = YEJhC;
        YEJhC = ! YEJhC;
        RGJJlrelu /= RGJJlrelu;
        RGJJlrelu = sZqJz;
        sLntN = sLntN;
    }

    for (int xIkOUzJwTwa = 290878274; xIkOUzJwTwa > 0; xIkOUzJwTwa--) {
        bgOROCUaiZX -= RGJJlrelu;
        RGJJlrelu += sZqJz;
        bgOROCUaiZX += bgOROCUaiZX;
        sLntN = YEJhC;
    }

    if (sZqJz == 2731.0459596673154) {
        for (int wNhTufaRWQGteNw = 188819026; wNhTufaRWQGteNw > 0; wNhTufaRWQGteNw--) {
            RGJJlrelu *= RGJJlrelu;
        }
    }

    return 832133936;
}

string AcXhTZI::HNUWPTVIizVkCwKl(string zKZpvCvpgMeYR)
{
    double vDElIXpORdNp = 127996.70822654893;
    string mDWUwEznBglLJ = string("kJoRKnHnXNuXaIyxaWxxKMuTFPXAkHvfJgcBpYmRGnTQbsoZVELdtAEsxIQBTemuqVwNJeGpxdtaRkWHJkwamulJDAzdAXyQEAHPcgCPvbVQslBDfjqZKBHqDqFRFURsUcDqkqwkTuOyeZMvojawzJwFzEdvxBEwfSOgBYuyftDBUMYlQhldNksASRAAZvhCPZBTpZRVMFbNiPZIxOXWjVsVCHmnfqYhSfVojyMYpBqQyUvewiyRfA");
    double NwXkdSaZP = -322855.005900974;
    bool BQWyRhJYKE = true;
    string xOGuxNTc = string("NmJlmpoPEyqrLjHyuwrLzSlxFIaeVbCUPBnjNDfNHlentLRzQxRZhUvoreNiioKzNlKvZLGYpoLwLQysRVDsfqHYoAzCZarAmWVArvRtHBTvNYLjLfFIlYJXcfcLqlkckykKmfjVIfFhyxuUfDPGHcQkplYfhqxRCTsNoCqcarCURlKOCjTHrApqMjGFaHuJECCMvdzrWQyKMrxXTgKQVIKDgpEnxym");
    double FYRDch = 835221.9158055286;
    int yteLPAN = 1639970585;
    string BEjYZcLwKCZlDY = string("SlPoxsHBCCRLBOqZPNybYrckbPZtIFGFmzQflwkKUUwZQsFjuPGGCiPPlgVuTkjPVXPlFuLwDBvRwePeuy");

    for (int myVLOsXhWkh = 2041141192; myVLOsXhWkh > 0; myVLOsXhWkh--) {
        yteLPAN = yteLPAN;
        xOGuxNTc += BEjYZcLwKCZlDY;
    }

    for (int KGFjRJbYvmgLbgO = 384713258; KGFjRJbYvmgLbgO > 0; KGFjRJbYvmgLbgO--) {
        mDWUwEznBglLJ = zKZpvCvpgMeYR;
    }

    if (BEjYZcLwKCZlDY >= string("SlPoxsHBCCRLBOqZPNybYrckbPZtIFGFmzQflwkKUUwZQsFjuPGGCiPPlgVuTkjPVXPlFuLwDBvRwePeuy")) {
        for (int FilKMQPScRq = 75881561; FilKMQPScRq > 0; FilKMQPScRq--) {
            zKZpvCvpgMeYR += zKZpvCvpgMeYR;
            FYRDch += FYRDch;
            FYRDch += FYRDch;
            yteLPAN -= yteLPAN;
        }
    }

    return BEjYZcLwKCZlDY;
}

void AcXhTZI::NqWkzKACMWCoM(double siwYqFgqEwkG, double utGOnpsuEVLPcg)
{
    bool bbddmkwEYMti = false;
    double ECYaLciQX = 204077.2671799822;
    bool VpxzjTwYemklP = true;
    string yuWgbhZPKkshtEwC = string("ilRrOWPRzzKnOBWNiJkJUdkHFhxHvXubXaRNFNtcAKiPGJSyGPKsjSPSGnYsggJMLlXalRYCwIBlYsgTFxaymoJvjLqYoJWQtnttVXVCMIbclZ");
    double xRrGnZRHFSNmvJE = -965390.0050213848;
    string HPqDKAvAEADXGuV = string("ORlGugDbAmVpplHArnwnQVgiamXHuMCVmcmecvppxWEpqnRDhNYmMMbajyLHimhpDdj");
    string MzQshHHuQRKvDG = string("wenuAVVsoHdlSXYeEAovdrdeHVNKyFKSQWuGPDpifLMvGvHSkbWwRjvPjWBvz");
    string XPWIngTkBJWYtf = string("blUnMLBtxTfJEOKykXvRtCLYRdCGIhiBtxWjKYpKVYBkvxkmDgGqvGcwmOIhAAbgbQgkkPjqxrqiqQJbzKzonyjJdQEHPVtEiNlCWitxAbxCVQGDfawQnbsePpyBiKNMFiFYdMcXpupSshuDGJfyoqgjNJtLvSXAILnlTusWzuWjPgBjFTLnfXXdsyoYeYkrDJdtsxVxlqYrbVptUfiGbNKaqCvaWpYgIQKI");
    int GmURxexa = -1220528820;
    bool cfjJuqTIOen = true;

    for (int rqvrgfaanduPZtTA = 1028036645; rqvrgfaanduPZtTA > 0; rqvrgfaanduPZtTA--) {
        continue;
    }

    for (int DfYYOHRxCaQr = 1073535442; DfYYOHRxCaQr > 0; DfYYOHRxCaQr--) {
        siwYqFgqEwkG *= siwYqFgqEwkG;
    }

    for (int tYsAgWoPbYcAg = 2023379984; tYsAgWoPbYcAg > 0; tYsAgWoPbYcAg--) {
        utGOnpsuEVLPcg = utGOnpsuEVLPcg;
        ECYaLciQX -= ECYaLciQX;
        ECYaLciQX -= xRrGnZRHFSNmvJE;
    }
}

bool AcXhTZI::igkTQM(int LAdWohIjzOBK, double CYGxnCB)
{
    double DZdWICSluMJ = -413286.4286530601;
    bool EXfhjrMEHAcArXEu = false;
    bool fFHqVbU = false;
    string zhPGUIQVYt = string("ATFKEImuTlYwxTMVNEwZDBlakGsmJkNskNfaSwldGbcUHNmYNjbRlqvyiDEpTUokMxilYFZuSwbpcQNTAaKAJTjkQdIQXtelGTHtfRatmtVohDIsmEofZtgKbRGILSEcuPKlTaeUnxSCInokuzuWHWk");
    double uGYwxQTLAXFDxlw = -1015213.1430406529;

    for (int DVaYggd = 1354349910; DVaYggd > 0; DVaYggd--) {
        LAdWohIjzOBK += LAdWohIjzOBK;
    }

    for (int IUaidlBQNvNDk = 2060398836; IUaidlBQNvNDk > 0; IUaidlBQNvNDk--) {
        continue;
    }

    for (int AueWxQGyhSn = 352394162; AueWxQGyhSn > 0; AueWxQGyhSn--) {
        continue;
    }

    for (int LBvZTvoOQVgiF = 755454164; LBvZTvoOQVgiF > 0; LBvZTvoOQVgiF--) {
        fFHqVbU = ! EXfhjrMEHAcArXEu;
    }

    for (int cJoUMqNjHLOC = 1048564819; cJoUMqNjHLOC > 0; cJoUMqNjHLOC--) {
        EXfhjrMEHAcArXEu = fFHqVbU;
        zhPGUIQVYt = zhPGUIQVYt;
        DZdWICSluMJ *= DZdWICSluMJ;
        DZdWICSluMJ = uGYwxQTLAXFDxlw;
        CYGxnCB += CYGxnCB;
    }

    return fFHqVbU;
}

bool AcXhTZI::jDGQEZWeAEwfM(string ytKBnBCaQ, bool XNExFNZjCehl)
{
    string lGXcqdLeagX = string("SHIpQpGUpCxGhMywMatBWdcIUaViEHEEWTmObhQkuHdNYXiNASDvieqRtZEqduhaswgKrSjSKmYYJquEtCAJCgqnBiUVUWRDyWufgXOaRcVyuhKWTIMVuibZCqdpVgG");
    string RXXDqIatb = string("ndKlxjOJdgrzZEtecWLuoBLGWhYrmhWttLNdBPAaoYAcNlEaXbBHZcJCUmKUNlkbGYSKQtdAJyyLpJuoqbTRmssyFtSZnQkOSgYqenitcWjiICtUHleSGQENTjChWLnGeNPXulUdtqwAmyLlHMAUuZhwlrVzQPMJxjLagOxpWPvXCndYkCYULpqRFLvSwBLHOhPLnQfBJshyWwXMMjECJArVHZNPpqRDwDYRj");

    return XNExFNZjCehl;
}

bool AcXhTZI::vrfve(string evOFlar)
{
    string GJDquKuOKfpmdPMG = string("fCoGJZzfHrMQaQhLmlegyvwCbjGCTxCfOpKMidprIdcPiWIniaDgNirAreysGPIsEYOlBmBjUpdUyPPsciNHhveNKNDEDHpIpViSkKAiRsYUSiXbnVthacjgTraYNJsvOSywgGwIgrNuAywtbTgwwuNibKYXYgVNXVXEVSErCGoGcABTguQjZdRBOYOyckHOCBogyJBXwwguASKMBeY");
    int UEvYQdFjanuUGDwp = 1696846380;
    int kHybrIcVERZZvas = -1353596449;
    int wBsfc = 1725006219;
    double WvxDvgmzo = 936399.2693673926;
    string NQOUpGT = string("hYgHTZkFyvbGdzNtuaxFbkt");
    bool ZROFWIjjo = true;
    int OntonakQf = 992916196;
    int dHyKxeucOZie = 1412713889;
    string jhNXUipUbs = string("zIZviPrEpKweNhWBhOTPkPYDiPQEnWadcFKqMNtSKyXeMcPjHNWQMvIXZmHimzjihZUNXNpLfLaqLkdjpJFYYeNhaehoxeBLOEAqUFMoneSBpYtVbLAnwCtPMkNmfGGkafQGujBSrPcmNUHgewpYrCkrjjbRSPHWgfWrXdZnFFVRkhjwZtWfDihQyXdozmfDcBFemdfqbgyRfwxuxSrGbTfUwUVriYvokyGEPAJPrsQTAMhdVUbbk");

    for (int mPmpFJVJBT = 1822321708; mPmpFJVJBT > 0; mPmpFJVJBT--) {
        dHyKxeucOZie /= kHybrIcVERZZvas;
        kHybrIcVERZZvas /= kHybrIcVERZZvas;
    }

    for (int oOWHwzuzGWLYrz = 1543671148; oOWHwzuzGWLYrz > 0; oOWHwzuzGWLYrz--) {
        OntonakQf *= kHybrIcVERZZvas;
        OntonakQf -= OntonakQf;
    }

    for (int fYcfLaS = 1456264746; fYcfLaS > 0; fYcfLaS--) {
        GJDquKuOKfpmdPMG = evOFlar;
        evOFlar += evOFlar;
    }

    for (int GIioYqBfVVKAwyza = 1015724655; GIioYqBfVVKAwyza > 0; GIioYqBfVVKAwyza--) {
        continue;
    }

    return ZROFWIjjo;
}

int AcXhTZI::AWSMkBoC(double vQMHdpUgkUqUQW)
{
    string qgYoxWquwEijEDmL = string("ZsLBvRHoggtFdyMczvYwGQsXhvxrZvEWbWgJKrJGHaZQTwceIYxBUDqUdJJevXpDnnSlgDuZ");
    int JqEqfymi = -1150827233;
    int qaVgWAIeUGwzgOS = 1084617119;
    bool WueDBpPLZ = true;
    string nHUHgOznS = string("YBWvLfEBuAYhtKOxUVsFOYHMrFIPJZJRUXepDFVgOFGhnByfEGTkVIHHmDgcpCIVRrvfhiQsggZcKugSagTvlyTMpIqYLsRXcwRZYHxaXtBNmpSmuaqlZSPLLxbpbfxKLbeufKaiWTGCOhlTpngXkMNrdyoNifjagiBdxcTlmzpQSvywuzXBclBSLLCVbEZWnyCSheFqRKQToZdSDknZPWMElwJqSyBJVrrKszUgwFuhKynaswpj");
    string WxyNWpYWyCIusmgG = string("nvkqTZPXTyMZlfwirVlFvEpVFzIyCnOccIfQxCMNcelmvCKkPBOgaDpXfLxErHmXCRdORyJRatyoZEHVRLGwKbgwQpCoBysabDUVqGciPYcGdvqVeUtxzGpClCVQYebtzJTSLBXyHZHLsGCysLPaVuLmLWLlebjlxltQyxYLKwNxmBMfJqLEXPvsUcEZixPAjEMncLUZGUInHPlNHKEsDpWhAYfCiomIXPXovHiFYwFPO");

    return qaVgWAIeUGwzgOS;
}

void AcXhTZI::PMPodcuKxqk(int xoBDJcndx)
{
    bool BQxjrlWLQyU = true;
    int PWBVtoqVytm = 240764751;
    string IXDQJsSYGA = string("KfqwECkwXksVHWTy");
    double nSfRSMr = -457152.79495749134;

    for (int HubRvfBjPQKzFRkZ = 784792978; HubRvfBjPQKzFRkZ > 0; HubRvfBjPQKzFRkZ--) {
        xoBDJcndx = xoBDJcndx;
    }

    for (int gmKLabeU = 1264688924; gmKLabeU > 0; gmKLabeU--) {
        continue;
    }

    for (int ZGiYulJG = 1619200406; ZGiYulJG > 0; ZGiYulJG--) {
        IXDQJsSYGA += IXDQJsSYGA;
        xoBDJcndx *= xoBDJcndx;
        xoBDJcndx += PWBVtoqVytm;
    }

    for (int wsgLNaHqalUpRVf = 494572614; wsgLNaHqalUpRVf > 0; wsgLNaHqalUpRVf--) {
        xoBDJcndx = PWBVtoqVytm;
        BQxjrlWLQyU = ! BQxjrlWLQyU;
    }

    if (xoBDJcndx == 240764751) {
        for (int xoxcqpfUAbMCG = 2081359362; xoxcqpfUAbMCG > 0; xoxcqpfUAbMCG--) {
            continue;
        }
    }

    for (int QCuEOFAiCwAAs = 1444887915; QCuEOFAiCwAAs > 0; QCuEOFAiCwAAs--) {
        PWBVtoqVytm += xoBDJcndx;
    }
}

AcXhTZI::AcXhTZI()
{
    this->IdNQB(string("vGvtJjHySGQkJXtBLCslSpHpRYKqkUphvIvcaYNdXVxbwBbmzLpxucetQfxQaRMFsTPjsoiCqOCRKsBCTIYOecWnuhOZiDvTHTsJRhztIsAIysvWhMUWbqCFxFylCEodCXSPXnAYhnKUrLbnRdGthVSeZZfqnbPKOxqxrjnP"), false, 59804514, string("AbWLZJuNShTHhqVR"), false);
    this->XpXaqo(-295692.268422984, false, string("vnqBSQpDbYaFnsPxeoMKuhdqUBnDZEmhfIRFYKSwYSbNEnLRjfnGaWcNtWwlyCbKDOklGYqDTIsuLNDAjplDFYOqlJnMQhmdbSNaHSzZnJurMCHwaUUuPRhGAeITqgbcElAdmvsnPlIGntokuRGeEgVXZudZFUwPAcxXqGDWgbEjFJzwwwXbrvRKbwCkgxyrqOLqqnYBrstoSvprpUzaYgRbKsrUOo"), string("cVaErNhrwMBKmsqKuydZqaGCSSwGRQXZRuVyGxeuqJFdAJOYyPPOborqumxLXNsyACXnfyabYOkxcAyzBIPnVZpLcTxdUkmBOzWxejrowUSnLcrcmfLhpUHCIOxeWXwtmEkVeOtbL"));
    this->wvroyewmvqYa(163059.35043687935);
    this->OHPehSJZIKUumM();
    this->STeNzedomMZY(string("DKBbzMkEsryWyZOvtXfaIfiGxCOwQfMOxXTrpyxVCeQujpiVoiayDedbaNSCdDolXnmCkeTRFemLAWrKHSdKiWZJKUBuhgimdXygjzq"), true, false);
    this->AhqidczXKWrpqx(false, 635829.745636021, 2731.0459596673154, true, false);
    this->HNUWPTVIizVkCwKl(string("rUbvNZMMidbxwsIrwvtMngRPiljkFhfnJAolVlUYrNpzczdCoaKrNyYBVwGdUURrvBlDzCAlSjXfaEVVQrNjANVJYniZWIZxquJSAKYnEohzBUoShQHpYYaGZumcvdYRWvgkqVPFcPgCWxaiMNKMNwyAHYypEfkaKqEvkFsuitKeugJFXAfZbEHReOXCtpbWkXrHeezNTkCjyHIlfmmuKNFbxycyACyyaXahoXZpiSZibF"));
    this->NqWkzKACMWCoM(-932175.8239277677, -343055.7227039565);
    this->igkTQM(-725996087, 150148.04430881594);
    this->jDGQEZWeAEwfM(string("WVKUmKLuacJXxuOMRqCngrgarxdofsyyzyGGBzEoYXbvHqxzHdvSHfqHzcxKmBFQsiwbxZRLDniZaSgwCySWNqCYsTxatCOqtRYCxFJPMLSzMyoUXF"), false);
    this->vrfve(string("ObIKhCqJKfnkYtjLBFpjckENXYNsyDfoQxSNpShTGluDgPZcALYDezjAYyRMHZFOnqRzFcYhozFDgyddnZZAJHQtJfuTNcBwkmUEzFYUMJewomkFdD"));
    this->AWSMkBoC(60585.56964351089);
    this->PMPodcuKxqk(-780910441);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MPMtOuNXEm
{
public:
    bool HptndUXpvuroV;
    double ANjPdGrYldISQqg;
    double DyDXtrbCZgIAthPB;

    MPMtOuNXEm();
    double XukbzbuIdRSoRS(bool qyWrUlWyQwrl, double hadCIH);
    bool sfXashhjtlbOzj(int QRqaLpu, int uLMBNgCLBXBMI, bool pyKJLfXJnJ, bool XZrRVBom);
    int PHgxMnWyRv(string IFzYkUfNRCthwb, string ghIjbTd, string hWaQDioERFf);
    int pHPIsNwYypewXWOD(double zdetklbg, string qypDLmA);
    int BYDZRlkVUC(bool HPZhRhjvX, int qJAcI, int YGAKQEAvGUCwdt, int kjrKdXYqmFNbYokw, bool cEWYbgXpJdoj);
protected:
    bool wEvzJQRwAjuEI;
    string xlraLQyRa;
    string ywelfhnJ;
    double hAqPpcPkTIFn;

    double VmLmRdzGuWEvJp();
    int QRPzEullyqe();
    bool HLksBPgMDDHcyPtk(double qlTUi, string MHtbuxueZojSVgc);
    bool DzrTSSrZ(double IRJCgFvrnnHif);
    int taRnMJeGa(int iKpgvCgVLcw, double PvYuo, bool URLSYqI);
    int TorIBzElOYKvHd(bool uDYquPCGCbzQw, bool rFbtlYYRdTag, string NrifN, int TkMPpxDEndGSsY, string YrTGA);
    int GegAuXuwpI(double trrbAZIstG, double soeKrCREBYYTWfK);
private:
    bool cLoqvKowkTDFNz;
    string dxaqV;
    double hCpkFAuJePIApsO;
    string lgtRwUPFGG;

    bool pixraAOA();
    void aLaTd(bool SedzAGJeULebRt);
    void wWVCpKNo();
    void mBCLQbFhmkdmX(bool HGdxeQt, string ZUforGbEiIHDMF, int yrFdfH);
    double iwMFKtNApjmnjkeo(int kwLOwk, int RRwDpdCXdLGe, double PTLevksmlp, bool BJihBT);
    string lcAPGTJTG(string CvNwJylO);
    double HKEunt(string IaqhNXubusYe, double WYIQAMOGmELqrMjJ, int NdpvSk);
};

double MPMtOuNXEm::XukbzbuIdRSoRS(bool qyWrUlWyQwrl, double hadCIH)
{
    bool eJebDGygDhZVCoxH = false;
    int rXWWoybtA = 1739243414;
    bool myXCr = false;
    string lNOCJx = string("FdtOUFNUvrNRsIeiUiKEEFEIUaPhmTwtQIWsblkqfmqNWfOGgKGFFklnfBFSOJDyslxvTylvnTPTmLNBHswXsnnnYWMhdQKyoYMpbEyyabKDzQlTnkDYQOSXpFQiFvumEKtkwWGgdumKNewyrHhIVxjvyUhOTJbrRhMbbqYMvXNrMyoBNomTakseTzdsUglfVhieuJHoVuCqHOmimib");
    string aFEZkNct = string("lbqPgWoZSmbhqmuBIsZAsPQHanwvwlsaTTQPzzEonMPRigPWkIwUHdbZJuiLtFqAqbunjWofioWxLZbsjUKKvSBImIuErwJzcafwQWYmbdUJPNhlqmmGmbfpLzUQjaDeaRdaiQldebmKCvTn");
    int niEBJy = 1810670676;
    int okYrtVmAvklo = -1472900891;

    for (int lNIMSaQeMQVFIf = 2064825674; lNIMSaQeMQVFIf > 0; lNIMSaQeMQVFIf--) {
        continue;
    }

    if (okYrtVmAvklo >= -1472900891) {
        for (int alJaJR = 1600107109; alJaJR > 0; alJaJR--) {
            qyWrUlWyQwrl = ! qyWrUlWyQwrl;
            eJebDGygDhZVCoxH = myXCr;
            eJebDGygDhZVCoxH = myXCr;
        }
    }

    for (int KUYLhSpxPeBPqme = 1903449058; KUYLhSpxPeBPqme > 0; KUYLhSpxPeBPqme--) {
        lNOCJx += lNOCJx;
        rXWWoybtA -= niEBJy;
    }

    return hadCIH;
}

bool MPMtOuNXEm::sfXashhjtlbOzj(int QRqaLpu, int uLMBNgCLBXBMI, bool pyKJLfXJnJ, bool XZrRVBom)
{
    int xDIWeZuJE = -2145363249;
    bool EZTpAv = false;
    string FKKzZaLW = string("KoaMMSUZiTIKxaDUOLoLTmBZEuoXyMXNwqIpwSSKURbrWQqFpzfiqebmJgFuSqRNozqeUkzAsGJXjWWoyIQtdwvdeVWxyMBfgCdOqbVHaJgLPYUQeIksWgeAxKtQjqVyqNMmTZZY");
    string FMqwSDe = string("MBTrhVNxFpOEoNwCGRUOipCKSNAiPMJcFXKRWfVuWunGYsNIcpooRpYzufQBuUvoLCJwCMFUFkbGuSpzbalnsyEJgYHKpSgOqKdAoQgtLBHIPOYuVOTjFAXZplRXCrgZnsWQeScLkcwOexqzxhRmTdsRnZcxHkVmKLhWsPBawlOOOoWMIWvykEMxWtWyGWlZaCnrvwwoejIXDKRs");
    string zeXwjvrOiLntqy = string("gjcjEWOhfQKQTKNFvPnemdWdpviVcRZzNAnaUURaMRPWGNBqBpfghhsLNOeiJtfIOcLEbvfYTILQdFLmvoWArJqwwVNdghFZxqhGIzgvMHodHiALJNFtGbUuYYUlOxlmREguChXoNPpEPdiHBlyYEnBAUrCGLrbB");
    bool LphQI = false;

    for (int DnchrAz = 402476995; DnchrAz > 0; DnchrAz--) {
        FKKzZaLW += FMqwSDe;
    }

    for (int zGDJk = 1574511681; zGDJk > 0; zGDJk--) {
        FKKzZaLW += FKKzZaLW;
    }

    for (int FLhhrGdv = 1641496736; FLhhrGdv > 0; FLhhrGdv--) {
        LphQI = ! pyKJLfXJnJ;
        FMqwSDe = FKKzZaLW;
        zeXwjvrOiLntqy = zeXwjvrOiLntqy;
        QRqaLpu /= QRqaLpu;
    }

    return LphQI;
}

int MPMtOuNXEm::PHgxMnWyRv(string IFzYkUfNRCthwb, string ghIjbTd, string hWaQDioERFf)
{
    string MUeJPLOgjIz = string("pyRlsXXuRXLkJnycgIoEHQyxtYcvLdFDuEflkHyfQgPFpwPtDUeBCkWcxnRfzAhCUaEucycqhgYHCKgWQblGVzuFCxmNIaelDdfndiNCUXhHzhYJOxUbeZgxKuAZOTBEiBfDWofxIsxzoZPtXLlUMBXbQyrzrYkJGDWGVynyLyHUclZts");

    if (MUeJPLOgjIz >= string("FUgIrRQcUFAVUIGELcMuemnPPZcvTXBMBmtpButcV")) {
        for (int jPXKdaGqG = 1269431130; jPXKdaGqG > 0; jPXKdaGqG--) {
            ghIjbTd = MUeJPLOgjIz;
            ghIjbTd += MUeJPLOgjIz;
            ghIjbTd += hWaQDioERFf;
            IFzYkUfNRCthwb = MUeJPLOgjIz;
            ghIjbTd += MUeJPLOgjIz;
        }
    }

    if (ghIjbTd <= string("FUgIrRQcUFAVUIGELcMuemnPPZcvTXBMBmtpButcV")) {
        for (int mYVAAM = 1328549571; mYVAAM > 0; mYVAAM--) {
            ghIjbTd += hWaQDioERFf;
            IFzYkUfNRCthwb += hWaQDioERFf;
            hWaQDioERFf += hWaQDioERFf;
            IFzYkUfNRCthwb += MUeJPLOgjIz;
            ghIjbTd += hWaQDioERFf;
            MUeJPLOgjIz += ghIjbTd;
            ghIjbTd = ghIjbTd;
            MUeJPLOgjIz += ghIjbTd;
            MUeJPLOgjIz += IFzYkUfNRCthwb;
            hWaQDioERFf = hWaQDioERFf;
        }
    }

    if (IFzYkUfNRCthwb <= string("UdPMAEihTENZgLburSoxVXnYQpAxLeaExbYGJWMxwabXiwsTVdPNKEtSEbhyBgKuDAxUGlqCgfjXVtCJwvjJMUlVIFDDyTNRCeRWKmQtBAVzqUkEsVKvkLjyEnSpHibVzwFqbkZBiCcFUCGmU")) {
        for (int UWULfL = 2011908280; UWULfL > 0; UWULfL--) {
            MUeJPLOgjIz = hWaQDioERFf;
            MUeJPLOgjIz += hWaQDioERFf;
            MUeJPLOgjIz += ghIjbTd;
            IFzYkUfNRCthwb = IFzYkUfNRCthwb;
            hWaQDioERFf = ghIjbTd;
        }
    }

    if (hWaQDioERFf == string("JBdABtbFFNsJLpOwBdrDJqpUktM")) {
        for (int OvhIztoTaOqauQn = 1716656718; OvhIztoTaOqauQn > 0; OvhIztoTaOqauQn--) {
            hWaQDioERFf = MUeJPLOgjIz;
            hWaQDioERFf = MUeJPLOgjIz;
            IFzYkUfNRCthwb += hWaQDioERFf;
            ghIjbTd = IFzYkUfNRCthwb;
            IFzYkUfNRCthwb = IFzYkUfNRCthwb;
            hWaQDioERFf = MUeJPLOgjIz;
        }
    }

    return -971777067;
}

int MPMtOuNXEm::pHPIsNwYypewXWOD(double zdetklbg, string qypDLmA)
{
    double iOWumfjjOHv = 115326.16773069536;
    string SmDyClvgaFItk = string("My");
    int RnWwaahzJXJGro = -1449754349;
    double iWcAZHOZ = 1036701.9236390245;
    string SDOOmFUOcPieuGjQ = string("ZAQYkTpRrXXsWOuDRMnGhgcefydaoWcayIJPyopDUrVyOdonRKcEsnREUVVhoLkGiYUTKuOjZbZeryKHDgOpwxbYnYlQFSHeoBAMaxFaarRhGIMfubEpJLWYzF");
    double CTeLN = -342538.69740681007;
    double ixJcEXcOxhp = -795454.2350903365;

    for (int rkpfLjKtdDkfZiv = 1251359200; rkpfLjKtdDkfZiv > 0; rkpfLjKtdDkfZiv--) {
        iWcAZHOZ -= zdetklbg;
        SmDyClvgaFItk += SDOOmFUOcPieuGjQ;
        qypDLmA += SmDyClvgaFItk;
        zdetklbg *= CTeLN;
    }

    if (iWcAZHOZ == 115326.16773069536) {
        for (int XHOFUNgf = 253605296; XHOFUNgf > 0; XHOFUNgf--) {
            SDOOmFUOcPieuGjQ += SDOOmFUOcPieuGjQ;
            SmDyClvgaFItk += SDOOmFUOcPieuGjQ;
            zdetklbg += ixJcEXcOxhp;
            zdetklbg /= ixJcEXcOxhp;
        }
    }

    for (int KlbRLISRevhI = 648204894; KlbRLISRevhI > 0; KlbRLISRevhI--) {
        iOWumfjjOHv -= iWcAZHOZ;
        iOWumfjjOHv *= zdetklbg;
        iWcAZHOZ -= iOWumfjjOHv;
        iWcAZHOZ += iOWumfjjOHv;
        zdetklbg -= ixJcEXcOxhp;
    }

    for (int kSjNJFsVfSxqcsW = 444744478; kSjNJFsVfSxqcsW > 0; kSjNJFsVfSxqcsW--) {
        ixJcEXcOxhp *= zdetklbg;
        ixJcEXcOxhp = ixJcEXcOxhp;
        iOWumfjjOHv -= ixJcEXcOxhp;
    }

    return RnWwaahzJXJGro;
}

int MPMtOuNXEm::BYDZRlkVUC(bool HPZhRhjvX, int qJAcI, int YGAKQEAvGUCwdt, int kjrKdXYqmFNbYokw, bool cEWYbgXpJdoj)
{
    string wpOJEiFXAQEe = string("lPukgCGDQtjdFxdAamBvvnYsVMZcuYGrQEIjvGJDdTnMcMuPwtiLUMZkapxkuSMlqEHOIYRlyYclzEevfmknZVkZYrJZvLkkGnclogSiIHXNBWgyMqljqUTbkiRtvn");
    bool bXbofiS = true;
    int bpVAhC = 337972673;
    double mVsVtJns = -220622.47389986593;
    string DaaulHLwyDffIeyX = string("dbzbNuCcPcoCvvoQmNmLVVzLajHwGYTKegtsaksKZQIVNJWdWhrpXyRWiSwfhYTOSiizZNtd");
    double EElwKXUZoVeoyVjE = 113903.14826316835;
    string GdbVOrqnccYl = string("ElhqGLivDOfPUtRoItsRIMWAokncZAAXgtgCLRXdpDyVkirgCVugXZAZrriTUuBvoQsFZjncjyLonFfhDCBOJJnPwTRKOGFCtaGflyjzfPgbpRPDtuJWOzxvNklEpiwchqWhoDkrrklPDzCqCiTbIKLAXbeOQRlBGKBKvT");
    string gHMBfbZH = string("wlONitTmKeeeOZRZcMDAqYDXfXwJcCNpYObXQJFLrtPqgujTTEDyLgmFJCYOyQZiicjymlwRyM");

    if (qJAcI >= 1485515529) {
        for (int KbAjUHYph = 99721029; KbAjUHYph > 0; KbAjUHYph--) {
            continue;
        }
    }

    for (int xwUWeh = 347847141; xwUWeh > 0; xwUWeh--) {
        kjrKdXYqmFNbYokw += kjrKdXYqmFNbYokw;
    }

    for (int IqzRzAfitWyGrVb = 1599914247; IqzRzAfitWyGrVb > 0; IqzRzAfitWyGrVb--) {
        gHMBfbZH += DaaulHLwyDffIeyX;
        gHMBfbZH += wpOJEiFXAQEe;
    }

    for (int dsWtra = 554047615; dsWtra > 0; dsWtra--) {
        cEWYbgXpJdoj = ! cEWYbgXpJdoj;
    }

    for (int kipLVDbMS = 1085031899; kipLVDbMS > 0; kipLVDbMS--) {
        continue;
    }

    return bpVAhC;
}

double MPMtOuNXEm::VmLmRdzGuWEvJp()
{
    int wTGquvt = 1351108936;
    bool BBfnQeXW = false;

    for (int HGWrZqNBfD = 621608797; HGWrZqNBfD > 0; HGWrZqNBfD--) {
        BBfnQeXW = ! BBfnQeXW;
        BBfnQeXW = BBfnQeXW;
    }

    for (int icrMxfLisBKwHTlf = 923417229; icrMxfLisBKwHTlf > 0; icrMxfLisBKwHTlf--) {
        wTGquvt += wTGquvt;
        wTGquvt *= wTGquvt;
        wTGquvt /= wTGquvt;
        wTGquvt = wTGquvt;
        wTGquvt /= wTGquvt;
    }

    return 251171.00406888558;
}

int MPMtOuNXEm::QRPzEullyqe()
{
    int MujnOZL = -550087892;
    int lfhakBhi = 2128521388;
    bool wcTZKRwmAfySmce = true;
    string xlIfPhONk = string("sJtFwbIVituvgVrGZdXMbCDAyUOokZzsuTIphKQhKIrnMrvkVoSOFPJxvudwtKwaWBNAKeQqoQleFPGILrnNAFbfbCYsbFcBKCJRuVJBOARdPEJygSwpHMTCQuhGLJxDJAgSVGL");
    bool IjSmvUFhwxHi = true;
    int XseNCYOxTLnJo = -578719168;
    bool svNuRDQLOLJ = false;
    string yZqowhJMokc = string("veMJSezenaTEnfzmGPOOXlFTJMIObNWnaYFkSbFZkHBnzMtkgVuixtcZgmkrssytVepaqKTwqiQZvEowDKnknAeNAAlyTwGOxn");
    int gJrutG = -672976304;

    if (IjSmvUFhwxHi != true) {
        for (int SwktaszDD = 916620969; SwktaszDD > 0; SwktaszDD--) {
            MujnOZL += lfhakBhi;
            gJrutG = XseNCYOxTLnJo;
            lfhakBhi *= lfhakBhi;
        }
    }

    if (wcTZKRwmAfySmce != false) {
        for (int UwxNiOgjwT = 1242741310; UwxNiOgjwT > 0; UwxNiOgjwT--) {
            gJrutG -= MujnOZL;
        }
    }

    for (int BUtJloMIomRu = 1924900628; BUtJloMIomRu > 0; BUtJloMIomRu--) {
        XseNCYOxTLnJo *= lfhakBhi;
        gJrutG /= lfhakBhi;
        lfhakBhi += lfhakBhi;
    }

    return gJrutG;
}

bool MPMtOuNXEm::HLksBPgMDDHcyPtk(double qlTUi, string MHtbuxueZojSVgc)
{
    string zuzhRYx = string("AZqgiVFuBOnvweNMOpPfZTOFqJLphBBddUlnpLIcIhFVyzbvyJNAvePjUcnErctqdPiEltASnxXsBghCPIBeARyiXhXYCXuBEAGPLtE");
    int XEilMoHciJSNejb = -1737148159;
    string EBmCwwANl = string("ZGdTnXPdWpAZqmdCGdLtCbJRhkYPVrcuWWMaMzvNBgNdnxsPUuLwihuOrBxVmEzBbvWWZaYGnemAdPnixJFdhRefjlflgdqimGbwnFUkKKldfSiVrIlsRgLHgrFnlHXlWyXWPiiodNzKzJTjLFHPIsE");
    string PCPtXxVBBxtRjJ = string("TpdHCtPoPhiCaVrsKPEAkYWcYcXdaJDAUqNaDPHkUjkJJOSXFphrziQweBfgGclIlRrtnGQBCeZSokQkUeCvbRhfmGHhdxFYUdHKXPauzsIcLGpuLWjuFrgqZYwTKPTEpoidmgUQvUkLspnevKGmFwWoroNLGoRVBWFDFLqGeKQGCqqRHaaYofekNeIIbv");

    for (int djiBWwGitY = 1370427153; djiBWwGitY > 0; djiBWwGitY--) {
        zuzhRYx += EBmCwwANl;
        MHtbuxueZojSVgc = MHtbuxueZojSVgc;
    }

    if (MHtbuxueZojSVgc == string("vqsCycShgZmEhXaoIWyrOrxtZOanyGplZnOpyFFHNnfDuDRfgTGVQyOwgIENvBnYIOHuVJilbNcRRoNuFmGlkntaQgdIgbrmwfxZbHCbiyJFtESXbnOYTjPxMeLigzelGJNPCmqpTjTTUfMNQvkcGcTnBn")) {
        for (int vlqJTzYF = 1166815956; vlqJTzYF > 0; vlqJTzYF--) {
            zuzhRYx += MHtbuxueZojSVgc;
            PCPtXxVBBxtRjJ = EBmCwwANl;
            zuzhRYx += MHtbuxueZojSVgc;
            MHtbuxueZojSVgc = EBmCwwANl;
            MHtbuxueZojSVgc = EBmCwwANl;
        }
    }

    for (int XScrSpyxs = 1328057722; XScrSpyxs > 0; XScrSpyxs--) {
        MHtbuxueZojSVgc += zuzhRYx;
        EBmCwwANl += EBmCwwANl;
    }

    for (int gYeZgqJy = 856710247; gYeZgqJy > 0; gYeZgqJy--) {
        continue;
    }

    return true;
}

bool MPMtOuNXEm::DzrTSSrZ(double IRJCgFvrnnHif)
{
    bool DzxXpmOFx = false;
    string dXTXiYQFsoo = string("EvkfgMVaaOytoQAtMZdDhMKRKZqJjwkrtxIPJhsCEVXeuGKWDcmKEekbJTnNUGzKNePgaFWPOSBFzsSiuTmFhtCRnHftgoZgCFjphrYyMJmqsorXBXfQdKyKqHLaEBdkMwzbfBNSeOABEgnqpuDPOnCHfcVRtnTyTCqvCFScWuNqVzBMTxZiabJyGIfknhfWMZvGFsTDFukrbPszLGCTPJwYIDcFtuxozcjxGEmXnHKeQLVmc");
    bool tCpGiqBZ = false;
    double RfTDJRfeH = 911375.221865226;
    int yCahP = -1459010506;
    int pHsRP = 1210459757;
    int eLpZRVneJG = -606065793;
    double SqovcMpti = 930322.8896634885;
    int sjYkXbvRDKCv = 1983502206;
    double byKFYwlnF = 1023080.1466236322;

    for (int VvUpGLzGwI = 419019640; VvUpGLzGwI > 0; VvUpGLzGwI--) {
        byKFYwlnF *= IRJCgFvrnnHif;
        yCahP *= sjYkXbvRDKCv;
    }

    return tCpGiqBZ;
}

int MPMtOuNXEm::taRnMJeGa(int iKpgvCgVLcw, double PvYuo, bool URLSYqI)
{
    int ECtOsRMBV = -1606339835;
    int HzeStYlTtOeQ = 1813424127;
    string ILbPSjqyoRq = string("YbqAMMfASZQiLpKAhLgzlQVvUOBkwtpEDHyOroeZZOgVJgDgFAAOLiNIfopeqCflixocYrHRxjNoHLrkvfxqFuSCfsQWOegNrDktYMmNgEDUAjJrgUXeifnjeWIvZnVjkIZKPmSIGULoRBdybIukxNmamQKehmYcvDOYeSctHdNvoKBSuMaxZxhCwTIaPwaugjGKsYkrvfPUadoMyQabRuVBufemPVvysalzvhwUWBvW");

    if (ILbPSjqyoRq <= string("YbqAMMfASZQiLpKAhLgzlQVvUOBkwtpEDHyOroeZZOgVJgDgFAAOLiNIfopeqCflixocYrHRxjNoHLrkvfxqFuSCfsQWOegNrDktYMmNgEDUAjJrgUXeifnjeWIvZnVjkIZKPmSIGULoRBdybIukxNmamQKehmYcvDOYeSctHdNvoKBSuMaxZxhCwTIaPwaugjGKsYkrvfPUadoMyQabRuVBufemPVvysalzvhwUWBvW")) {
        for (int bpyoqfiF = 1360896948; bpyoqfiF > 0; bpyoqfiF--) {
            ECtOsRMBV /= ECtOsRMBV;
            ECtOsRMBV -= ECtOsRMBV;
            URLSYqI = URLSYqI;
            iKpgvCgVLcw = ECtOsRMBV;
        }
    }

    return HzeStYlTtOeQ;
}

int MPMtOuNXEm::TorIBzElOYKvHd(bool uDYquPCGCbzQw, bool rFbtlYYRdTag, string NrifN, int TkMPpxDEndGSsY, string YrTGA)
{
    string hxIhrfX = string("naVPlERwuMzBMyiYCdNzUSsPODiKGxoYpkSchvsoXHCZGzFFllcRYLZWlUvSlCFPYaDCDASGxyuMzztMfIqAztPYRBbaDxobxQqCOHvVFVvfwBmoTWRqZNCAvSfwuosVxBhFnAWRpXLuGYOYx");

    for (int qTAEieQ = 671760486; qTAEieQ > 0; qTAEieQ--) {
        rFbtlYYRdTag = uDYquPCGCbzQw;
        YrTGA = YrTGA;
        NrifN = YrTGA;
    }

    if (rFbtlYYRdTag != false) {
        for (int MVwyUvj = 1114151988; MVwyUvj > 0; MVwyUvj--) {
            rFbtlYYRdTag = uDYquPCGCbzQw;
            YrTGA = YrTGA;
            TkMPpxDEndGSsY += TkMPpxDEndGSsY;
        }
    }

    return TkMPpxDEndGSsY;
}

int MPMtOuNXEm::GegAuXuwpI(double trrbAZIstG, double soeKrCREBYYTWfK)
{
    string Omgjfl = string("IlMCDDLBcRDUwMOUQMQtYYzBulNVbfHnTjanSQzFJKGVIBsAmbiblybefhBePZhCydlnlftEAaKpvfcQeFNqMJUneDSGkpyitQsKMHiJVkQijfXkMfFmVonPjkpRirqLCGvaegrmAoWmewaDkkzDgAWansscENaMVImEYSUQQjXnPpaqmbbuGZTstsAuOEARZjuYBNbaXejEexMFCgbRdrAsnkxlEMKnhrHCKz");
    double ChrYfE = -891730.1285629258;

    return 710548611;
}

bool MPMtOuNXEm::pixraAOA()
{
    int eKiTXhBxBzPA = 688657882;
    int nJEqj = 528728635;
    double aiJXlcp = -517273.13149082015;
    bool kEvshWGzvvM = false;
    string otpSyfiMApRbzyE = string("roMfuTiVUtThAoJxyoPjMjmCpFgSSgWWOEIfrHTWFUsLZjVZSdqQADGmuaEtiwoIbFCbMSjnSFQdxzHdXoofiULbgDAbPjwVHmqRvonUvVZcMHXEOqSLBuHGkJmZxuGNcTaztmdDzhpmTmRdCePpvEBSpUTSWJdEQYUPGhUdwdWmdkMfTGFKCGelNQRBahsEyHsclcsPWygjACbmNwpUFZewmhUGMZwFvzxsWVkhMHSKVwHoAlhEotlfSa");
    string biGELNCvHW = string("XfqzwRlTjmqixlKwKEiUGvEleNlelgWznwkcFArwJKAXiHnOIAnDBlwqkKosJgUhRUNzKgXRRDzjrdYFAawCPgnocHRDlbWWyigmySAgEyuRyLBEwINlRByvjYMUWaZWwmNEqaokolsHxZHQffsoRqLqFuWNjCJAkQwhjMljcJNtOVcizZRNhcqOZjeIGGvGUrFFzkmqERLzNJOlcthpaotAQav");

    return kEvshWGzvvM;
}

void MPMtOuNXEm::aLaTd(bool SedzAGJeULebRt)
{
    double TawJnXm = 527180.2077536272;
    bool SznBolbcl = false;
    bool xPHpfDTnJAqaIm = true;
    string YpZDzIzIVkS = string("wXPBEHPhsHHamhNwXJnQ");
    double UZtQuezYwFIbaCcm = 691055.9538948532;

    for (int VWehQiA = 1958693967; VWehQiA > 0; VWehQiA--) {
        continue;
    }

    for (int EtrYKlVUigoGT = 1485055581; EtrYKlVUigoGT > 0; EtrYKlVUigoGT--) {
        xPHpfDTnJAqaIm = ! SedzAGJeULebRt;
    }

    if (YpZDzIzIVkS < string("wXPBEHPhsHHamhNwXJnQ")) {
        for (int AhOIg = 1933666712; AhOIg > 0; AhOIg--) {
            xPHpfDTnJAqaIm = SznBolbcl;
            TawJnXm = TawJnXm;
            UZtQuezYwFIbaCcm *= UZtQuezYwFIbaCcm;
            xPHpfDTnJAqaIm = ! SznBolbcl;
            SedzAGJeULebRt = xPHpfDTnJAqaIm;
            UZtQuezYwFIbaCcm *= UZtQuezYwFIbaCcm;
            SedzAGJeULebRt = xPHpfDTnJAqaIm;
        }
    }
}

void MPMtOuNXEm::wWVCpKNo()
{
    int CahPe = 1629905779;

    if (CahPe != 1629905779) {
        for (int BIwzb = 309523248; BIwzb > 0; BIwzb--) {
            CahPe = CahPe;
            CahPe -= CahPe;
            CahPe -= CahPe;
            CahPe -= CahPe;
            CahPe = CahPe;
            CahPe = CahPe;
        }
    }

    if (CahPe != 1629905779) {
        for (int UpNSjhfzYOYnICoT = 662045981; UpNSjhfzYOYnICoT > 0; UpNSjhfzYOYnICoT--) {
            CahPe -= CahPe;
            CahPe += CahPe;
            CahPe += CahPe;
            CahPe *= CahPe;
            CahPe /= CahPe;
            CahPe = CahPe;
        }
    }

    if (CahPe <= 1629905779) {
        for (int nhZiLoStkhiwRC = 2121950771; nhZiLoStkhiwRC > 0; nhZiLoStkhiwRC--) {
            CahPe -= CahPe;
            CahPe = CahPe;
            CahPe = CahPe;
            CahPe = CahPe;
            CahPe /= CahPe;
            CahPe += CahPe;
            CahPe *= CahPe;
            CahPe += CahPe;
            CahPe = CahPe;
        }
    }

    if (CahPe >= 1629905779) {
        for (int ZnJZfAoCkISZxhZ = 837076183; ZnJZfAoCkISZxhZ > 0; ZnJZfAoCkISZxhZ--) {
            CahPe = CahPe;
            CahPe += CahPe;
            CahPe -= CahPe;
            CahPe -= CahPe;
            CahPe *= CahPe;
            CahPe /= CahPe;
            CahPe = CahPe;
        }
    }

    if (CahPe != 1629905779) {
        for (int krTmR = 1420929188; krTmR > 0; krTmR--) {
            CahPe *= CahPe;
            CahPe = CahPe;
            CahPe = CahPe;
            CahPe -= CahPe;
            CahPe /= CahPe;
            CahPe *= CahPe;
            CahPe -= CahPe;
        }
    }

    if (CahPe < 1629905779) {
        for (int jkIwpCWqOTe = 1862895845; jkIwpCWqOTe > 0; jkIwpCWqOTe--) {
            CahPe /= CahPe;
            CahPe -= CahPe;
        }
    }
}

void MPMtOuNXEm::mBCLQbFhmkdmX(bool HGdxeQt, string ZUforGbEiIHDMF, int yrFdfH)
{
    int CdKmLYcUXuftcK = 276530758;
    int AJvbVrrEGlVooTRm = -567216861;
    double MNTvBgj = -716109.8977193619;
    int BsqoSWeQzDtVUGF = 1206444100;
    bool yFBzLsKbw = false;
    int xdKUw = 525503815;
    int kVrwZSoMwwulfAq = -1475012599;
    double kclDDdMTHOEeVl = -147028.60782040114;
    int adahbroeohDPef = 672543105;
    double NqzWf = -288667.2128204505;
}

double MPMtOuNXEm::iwMFKtNApjmnjkeo(int kwLOwk, int RRwDpdCXdLGe, double PTLevksmlp, bool BJihBT)
{
    bool EUFYLYo = true;
    bool NXtEDQIxxOAnX = false;
    bool pSRDfqolUYMTYaMm = true;
    double ZTKULTANZ = -938967.6689452861;
    double LSvaEKWsmu = -219874.92031495212;
    int MHHFTny = -1682617007;
    string dOezOYrDDssQqUfF = string("VSnMDddBqPPcqSQsDoPblJFNTIMSiipCKtLtphFsZIESAymCCOcpphpnWCdtSzDGpvmDvMClzgLfvAiaUpRcSswcBHmQCiqqFyJXauGwbvSqLroPEhEmLNeIaYLuduNGpMWaCFTYJOvnETXT");

    for (int OVACjqHL = 506813242; OVACjqHL > 0; OVACjqHL--) {
        kwLOwk += RRwDpdCXdLGe;
        EUFYLYo = EUFYLYo;
        RRwDpdCXdLGe -= kwLOwk;
        EUFYLYo = ! EUFYLYo;
    }

    if (NXtEDQIxxOAnX != true) {
        for (int bJKywlXGbaLZ = 710761581; bJKywlXGbaLZ > 0; bJKywlXGbaLZ--) {
            continue;
        }
    }

    return LSvaEKWsmu;
}

string MPMtOuNXEm::lcAPGTJTG(string CvNwJylO)
{
    string ogIhFEqtWjgcOsdX = string("pkhczfxZrtPXRXuTW");
    bool fIzIRRCbfN = true;
    double GrnxOM = 297296.4540435396;
    double EveRDyf = -766247.9645191758;
    string CzlnSFhQhSgJGwSk = string("GKGJVzwhVGHhglpWeSzcDxMRYiqpiJcEIlMzXQNiITMKZoyxtjaswZkZchdZYoOUmUDXgaOBwUThRxWgqlTvL");
    string EWJetkLKZ = string("lPyZxNolgDJehDVpxZiaBdwcSxnRmjrlHnVbVguaQnIQHDoWJoyUBaFSWAcnsWxxgknQIHrmRPaJkWWVnUsuXBIjzVvCmdkdquKNVfrokgVJxfhacNwhswGvvQsIXS");
    string nYLyvC = string("ChUNDBPTZPCmamDKxngAxEuMZBHOQkXkqgODprcoOKJurXPdDsUzaowFjXdOrBbQLUaiGTuMGhIZevKYyBGSHSBipkKybUWHYKGnWfoQoagyfiXIanUOhPLVAoHxjhZBsxDrmglbWdhtWBYHhZrSlDpbsizrvNCSQVZOKtRbtxDGhKNIrnPXCzsWFKjjhLQGtQacHTMIQKmMwmWnwARmYhk");
    bool GNkAmnIAj = true;
    string oBPJvP = string("qbaBjUfYgrTTArLilwbxrVALIQYXuPQFqoDFKmMRRUbufLdGYEgUVoQMLDmmpIEVyQEbMrhCcRKWIvHBKJaWpIwGpCAYSZRgWnANBdRXTSOqJmQHKBxWrLSsuZPaQcDHZwXGxTkzECnEvkJJLYhksrPKoNFfQavDPyyxqkKtdhGgTlTapYJXMnUWBevsEUkMcfgSratsFqQUwczuekOEjZcCKpg");
    bool IHwKeMYeFsGKD = true;

    if (ogIhFEqtWjgcOsdX >= string("HSCffOZpHAGmkodZanENoeuJtfUSsIWebveZXdEUfriD")) {
        for (int sPrcif = 1032678680; sPrcif > 0; sPrcif--) {
            nYLyvC += ogIhFEqtWjgcOsdX;
            EWJetkLKZ = oBPJvP;
            ogIhFEqtWjgcOsdX += CvNwJylO;
            ogIhFEqtWjgcOsdX += EWJetkLKZ;
            nYLyvC = CzlnSFhQhSgJGwSk;
        }
    }

    if (nYLyvC != string("qbaBjUfYgrTTArLilwbxrVALIQYXuPQFqoDFKmMRRUbufLdGYEgUVoQMLDmmpIEVyQEbMrhCcRKWIvHBKJaWpIwGpCAYSZRgWnANBdRXTSOqJmQHKBxWrLSsuZPaQcDHZwXGxTkzECnEvkJJLYhksrPKoNFfQavDPyyxqkKtdhGgTlTapYJXMnUWBevsEUkMcfgSratsFqQUwczuekOEjZcCKpg")) {
        for (int fIJQQbfuOhp = 1791528511; fIJQQbfuOhp > 0; fIJQQbfuOhp--) {
            CzlnSFhQhSgJGwSk += EWJetkLKZ;
        }
    }

    return oBPJvP;
}

double MPMtOuNXEm::HKEunt(string IaqhNXubusYe, double WYIQAMOGmELqrMjJ, int NdpvSk)
{
    int tVtFgtYhdTJqH = -1627421136;
    string YieEotLb = string("fwIUIBAIoKSEQnZqmCuihvxlsFnEzzpVpJSwzYvhIKggAWDsIfTqogTVdroeHJUgcXiBjDdGmViwAnBxstpPPrdYfjPQtgjmzpNHPTiFSeBmRregwSPrDa");
    double TMOyzGXr = 228344.19565233623;
    bool NIumw = true;
    int XBykTZxn = 760430640;
    bool swZNtDGeIusWn = false;
    int qzskF = -1925356647;
    string yekjWGhXOyP = string("FbrwBllKnEPtibnehGfxgnUgfFDqssMGhKQtjTXLSiOzIjDnFRIpUdZscSDYeqvDcElnINCxnJKoWdMxwUxcvBHqrAGvHeYDKkyMcvcXtYQYTNaYmunxkpaDAezooeGJLxCkum");

    for (int wKWLPFDRMtvS = 880257796; wKWLPFDRMtvS > 0; wKWLPFDRMtvS--) {
        NdpvSk *= tVtFgtYhdTJqH;
    }

    return TMOyzGXr;
}

MPMtOuNXEm::MPMtOuNXEm()
{
    this->XukbzbuIdRSoRS(false, 4550.518801242966);
    this->sfXashhjtlbOzj(1492631444, -1672269644, true, true);
    this->PHgxMnWyRv(string("UdPMAEihTENZgLburSoxVXnYQpAxLeaExbYGJWMxwabXiwsTVdPNKEtSEbhyBgKuDAxUGlqCgfjXVtCJwvjJMUlVIFDDyTNRCeRWKmQtBAVzqUkEsVKvkLjyEnSpHibVzwFqbkZBiCcFUCGmU"), string("FUgIrRQcUFAVUIGELcMuemnPPZcvTXBMBmtpButcV"), string("JBdABtbFFNsJLpOwBdrDJqpUktM"));
    this->pHPIsNwYypewXWOD(437717.4351547146, string("RnaXwOlEvXWXynFllSMuIFHWUvsPRaZGjkbXpyaUPUdvuSbuxpZSKCTLEsxCtjPeTbCrVTmEKrUOtaDLMDMvlMlgqmIwcVXgaWJRtbePYkYrJUXtITlsqiQdIWqcC"));
    this->BYDZRlkVUC(true, 1016714672, 1485515529, -986681029, false);
    this->VmLmRdzGuWEvJp();
    this->QRPzEullyqe();
    this->HLksBPgMDDHcyPtk(264817.525424992, string("vqsCycShgZmEhXaoIWyrOrxtZOanyGplZnOpyFFHNnfDuDRfgTGVQyOwgIENvBnYIOHuVJilbNcRRoNuFmGlkntaQgdIgbrmwfxZbHCbiyJFtESXbnOYTjPxMeLigzelGJNPCmqpTjTTUfMNQvkcGcTnBn"));
    this->DzrTSSrZ(-58274.95603988719);
    this->taRnMJeGa(158397888, 164564.56648693964, false);
    this->TorIBzElOYKvHd(false, false, string("qgRBtSecfbtFlmPzFRqxmxFqCNDsomtSnXmFslipdECxvpClmYCGrpbCPubtqqJscRpxWHPFbYlmxImNUXDBQqwPCEpVkvmgaSWDTeTuckzpHHIknCYyraAtOUxqELNqxHEgdMXyCiNUjvAvnSFNvbTNJTAbU"), 1126075616, string("afnnvqeOyfXRPmYHKbKqccikQBZMshIHZxhWcEBHCjkikTCSlXPUxryEXMImcOmXfbocIBdJXEskDQffFGTSpXwcQKjJmtBVHaGWeNrnalCsRvKvSJLUApnJodUOjCjChntGnbeMKjwZBImpmNaefWezsZFsFfEmPpCrKCOBkVkawkRmWgQDYIaYKqgW"));
    this->GegAuXuwpI(453470.1914480593, -255749.66700227943);
    this->pixraAOA();
    this->aLaTd(false);
    this->wWVCpKNo();
    this->mBCLQbFhmkdmX(false, string("BaiJezilcddLNJIAzUwmfwlsmytePQmqyuvdPbULshVoiXLdzPNbgoGlaQzvbBeeRXfuKDqgxDmlhJuNjDkvazyCgIlzOGfJOweDymqJcTZpWPnALFCtQDRKmThcSZGTQmiBRjmWDmaaDJ"), -429786662);
    this->iwMFKtNApjmnjkeo(-1929617647, -838525051, -642640.9676730108, true);
    this->lcAPGTJTG(string("HSCffOZpHAGmkodZanENoeuJtfUSsIWebveZXdEUfriD"));
    this->HKEunt(string("mriZxuktBmHtNBfEWaayNAyDFLFxtmJMVAPmFiGhtDpurOYfvfPoertZnNGJqTBpUTamSrMuIuMaJZpQZGHNnbUfLEPtYQRYnqwilhLysnNkBzGKXDokOwzobCMoaPFhDoyjUSzqmuJ"), 228008.83616439803, 1347505260);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kNOcWc
{
public:
    bool LCufNEMBk;
    double vnfpeZyPa;
    double zTprdFdWavL;
    string sJUqgkF;

    kNOcWc();
    bool uDxosG(bool VBXLuFeCNClT, int yyYtXuOxZtkLYr, string vXPjRSwOWejuIxat);
    string gsFqymZs(double PQKWULcd, bool NCTPH, int uOLvppGsZUBvHNl, int wgMZBCCuAa);
    double GsGQRSYeXxXGRuCq(double bzNDLUrgJQxxW, bool XHXyBGIvldhQPUTw, double xBeXUnXROPPwaeC, double eZTTuTupeK);
    double euEdmtEqXKDTbon(double rzXXUrUwehqIbaMB, double sgplABLrvR, int AOfyA, bool lfSVyPevIdy, bool uMubdYYlidmgGcqR);
    void EgIyNq(string dQKPKWsc, bool bCkeZjHJPEXikF, bool hOhrI, int zOGQgoTGkDR);
    bool uRNcPwFBxHuBVBjO(bool nqVUSb, int KboYsCVDXZi, bool uxsgBFPVUhxZ, double EaZmAZbDRwcP);
    void UIiUG(bool NmbtsJ, bool Cxscn, int JJMXDHRHRE, int stdWbJQiEWCXU);
protected:
    string FOuFDJxYhQeYbT;
    int zJive;
    int zXCALO;
    int DgSFLrQjwerOX;

private:
    bool FpEsfSM;

    void UncNhlVBXnfXbp(int qRDDmFCfGYxFzv);
};

bool kNOcWc::uDxosG(bool VBXLuFeCNClT, int yyYtXuOxZtkLYr, string vXPjRSwOWejuIxat)
{
    string QklRJWSaBi = string("xcmcZydiTbBSOpSfKMwdDmKEHoIjBmkAifYPLOmtmUfUnKyxUqegxCHpdTKPJotwfYByTxikbfuOwdfAWjmHjMXOJqZDBfcrJJeDSJQxYGAhxFPzXxKaAzIQYf");
    int KDouNUlPPj = 569302876;
    bool IrWNLraCvrUhkmI = false;
    bool MGQlZR = false;
    int iGECLejE = 1529350099;

    for (int XqUjCfdxQBf = 1671730335; XqUjCfdxQBf > 0; XqUjCfdxQBf--) {
        VBXLuFeCNClT = IrWNLraCvrUhkmI;
    }

    for (int vhgTEzDRP = 1431633138; vhgTEzDRP > 0; vhgTEzDRP--) {
        QklRJWSaBi += QklRJWSaBi;
        VBXLuFeCNClT = ! IrWNLraCvrUhkmI;
        KDouNUlPPj *= yyYtXuOxZtkLYr;
        KDouNUlPPj -= yyYtXuOxZtkLYr;
    }

    if (iGECLejE < 569302876) {
        for (int lbpBqnuHSsWcwnvv = 1926405524; lbpBqnuHSsWcwnvv > 0; lbpBqnuHSsWcwnvv--) {
            vXPjRSwOWejuIxat = vXPjRSwOWejuIxat;
            IrWNLraCvrUhkmI = ! IrWNLraCvrUhkmI;
            IrWNLraCvrUhkmI = ! VBXLuFeCNClT;
        }
    }

    return MGQlZR;
}

string kNOcWc::gsFqymZs(double PQKWULcd, bool NCTPH, int uOLvppGsZUBvHNl, int wgMZBCCuAa)
{
    int HdqkIFa = 1356095187;
    double oybIVhSHwshqjA = 39603.03716307206;
    string JPSoPNZqE = string("zWfFYOeKIwymMwNMCLxLfPYCIRTnvZaUQrjGxnmmDrxoFNvRiPbtPPpelLJwMLUlrtjnqnUSGRpWnVKGkreoWHtiDFLWZBnqVrKCnoPBKuoGrKTEifTzJctvyAnIbefTynmNeeeEuHOLbeuMCjdcnKsTQkbwLGFKsZKHRrPdVUBpAZwLySkaMhepYtbbgqFOcZjhZkEqkmtgtKsTLSNDSIGcSfywWecfCMLfIWsxmPfbFjHOKOSrPdRonb");
    double mVMMtuPY = 128764.20940022904;

    for (int KCsCNZfpcUcUD = 1153594252; KCsCNZfpcUcUD > 0; KCsCNZfpcUcUD--) {
        NCTPH = ! NCTPH;
    }

    for (int DkdrhsIpf = 784098654; DkdrhsIpf > 0; DkdrhsIpf--) {
        HdqkIFa += HdqkIFa;
    }

    for (int eoTxYEMhJPWWF = 1442780965; eoTxYEMhJPWWF > 0; eoTxYEMhJPWWF--) {
        continue;
    }

    if (uOLvppGsZUBvHNl <= 144642104) {
        for (int WEThkRVuKjJIbrxW = 257610089; WEThkRVuKjJIbrxW > 0; WEThkRVuKjJIbrxW--) {
            wgMZBCCuAa /= uOLvppGsZUBvHNl;
        }
    }

    return JPSoPNZqE;
}

double kNOcWc::GsGQRSYeXxXGRuCq(double bzNDLUrgJQxxW, bool XHXyBGIvldhQPUTw, double xBeXUnXROPPwaeC, double eZTTuTupeK)
{
    int GbFnewAfKWPdH = -608911262;
    double OEgtBXmCXtA = -673690.5565189262;
    double VekWHqDRpCWeKkbK = -530519.9571314723;
    string WdQkrrA = string("EvjuNcqzlInyhYkqmlMMXBAJoR");

    return VekWHqDRpCWeKkbK;
}

double kNOcWc::euEdmtEqXKDTbon(double rzXXUrUwehqIbaMB, double sgplABLrvR, int AOfyA, bool lfSVyPevIdy, bool uMubdYYlidmgGcqR)
{
    bool kuzgxUTLjzfKqH = true;
    string UVHqMQo = string("wJnXDlDAuOnsvZdBotQMthhIcwfVsUqJMWvmLBMVhtCGbUIHNkvKMUmmyZiMUJvxpALPpbZmbQdFymoriPkFcBOdLjVYqhUomiq");
    bool QgYhCbHTzij = true;
    string BhBtBpKBu = string("qwHodovPCrONnXRlcRcgBANJRzyUAzPRUlERHVgyrpRYBNCnFIDxbjAeRnGrDaTOIbWotAFrkQpHbGySDISKnqcwiBFxlSSuaYsPYXEvQYPMSzFpfFvsPqQvmRlFtnMuBSNZIXidmdduoYynRymQvhyUbMnBQkCQkBfqlQWdAVjmnKJrUwCWISQhMZrZvpvfLoQKylcOfcVCaXulhtZlHifAbNuHqvG");
    bool nGVhfRQeOjv = false;
    int FqaJzu = 273216012;
    int LQUOmPDudux = 1057601416;
    bool JqOCJXRP = false;

    for (int khjgjz = 950036177; khjgjz > 0; khjgjz--) {
        QgYhCbHTzij = QgYhCbHTzij;
        uMubdYYlidmgGcqR = ! nGVhfRQeOjv;
        LQUOmPDudux /= FqaJzu;
        nGVhfRQeOjv = ! kuzgxUTLjzfKqH;
    }

    for (int pgGjwMwFZmSrUrX = 1608292080; pgGjwMwFZmSrUrX > 0; pgGjwMwFZmSrUrX--) {
        nGVhfRQeOjv = nGVhfRQeOjv;
        BhBtBpKBu += BhBtBpKBu;
    }

    for (int MvyDQPcYxX = 2072077076; MvyDQPcYxX > 0; MvyDQPcYxX--) {
        JqOCJXRP = nGVhfRQeOjv;
        AOfyA += AOfyA;
        LQUOmPDudux = LQUOmPDudux;
    }

    if (LQUOmPDudux >= 2051648082) {
        for (int YtKgNmRjjvULdI = 655319558; YtKgNmRjjvULdI > 0; YtKgNmRjjvULdI--) {
            sgplABLrvR -= rzXXUrUwehqIbaMB;
        }
    }

    for (int PNXJAqiXBStufUPx = 906461262; PNXJAqiXBStufUPx > 0; PNXJAqiXBStufUPx--) {
        continue;
    }

    for (int bqnHpsUF = 649592664; bqnHpsUF > 0; bqnHpsUF--) {
        continue;
    }

    return sgplABLrvR;
}

void kNOcWc::EgIyNq(string dQKPKWsc, bool bCkeZjHJPEXikF, bool hOhrI, int zOGQgoTGkDR)
{
    int GKIBN = 496782080;
    bool WusjnPxZkUmx = false;
    int VdWbtP = 576643390;
    string hfnWAgXNAlUeO = string("LMaTGfDilNZkGTakkHyqCgcTKRMniqPVvdzAXwrwqRsPehGVNhEmCuIYwJYGfkrAhKLkEuwohESvAMeLaqjWiROOzQvJGVYortPPnmmcpYfKJbmKJqpRrEmdzUjctqsRmRHLLIUdlykLFMfAtlcuuwxycDCf");
    string CczTtekn = string("FZkUMTYDmCBBvMBCoAr");
    bool ThaiufxYmVwQq = false;
    int UtiBCRgGQczKwTtJ = -1362316027;
    bool VuFxHwCRWcNoue = false;
}

bool kNOcWc::uRNcPwFBxHuBVBjO(bool nqVUSb, int KboYsCVDXZi, bool uxsgBFPVUhxZ, double EaZmAZbDRwcP)
{
    int YivmfodyvKfAb = 1083552891;
    bool smsnp = true;

    if (YivmfodyvKfAb < 466686323) {
        for (int kGpkPtlY = 1956461151; kGpkPtlY > 0; kGpkPtlY--) {
            smsnp = smsnp;
            smsnp = ! nqVUSb;
        }
    }

    if (nqVUSb == true) {
        for (int uGSuKKpHI = 1394770967; uGSuKKpHI > 0; uGSuKKpHI--) {
            uxsgBFPVUhxZ = smsnp;
            YivmfodyvKfAb /= YivmfodyvKfAb;
            nqVUSb = smsnp;
            smsnp = ! smsnp;
            KboYsCVDXZi = KboYsCVDXZi;
        }
    }

    return smsnp;
}

void kNOcWc::UIiUG(bool NmbtsJ, bool Cxscn, int JJMXDHRHRE, int stdWbJQiEWCXU)
{
    double FlVvjEwIMGxxiasK = -646887.6411446406;
    bool LDAlhuoARBFZRK = false;
    string gGEjrqWWyO = string("bLJUXqv");
    bool WmchuGrMrsYJK = false;
    double WEViHqSniQqSlQhW = 791863.0264562031;
    double gidizW = 573533.4426169163;
    bool rVTZsanPd = false;

    for (int nXhkIYlhMuIbkzIJ = 2074556483; nXhkIYlhMuIbkzIJ > 0; nXhkIYlhMuIbkzIJ--) {
        JJMXDHRHRE /= JJMXDHRHRE;
    }
}

void kNOcWc::UncNhlVBXnfXbp(int qRDDmFCfGYxFzv)
{
    double HdvybJKT = 1039364.1339503028;
    bool CLZcO = false;
    int IFbVFYgN = -1648316685;
    double YrcFD = 1028217.1206223698;
    bool KPgLKbVy = false;
    string DIoesH = string("mdbyakKuRJidCQhHvXijCXSOsslGmAHhpJnRxUtdPBzeUnFpYxwDLdeAjSADaaBgwsbbxKmZgANQXEeTZZjXHLlqesLufuxFyRzEIRsDzRnyhpEVJDPzSbyJkGnDOWjUmQuJqLgKjfWcoRmFfgmLopmvGgrsnexzvCKOGDdPq");
    bool gyqvooKpN = false;
    string hhXIzgvc = string("MfJCNkVVaZXHYwxtHyFkcPXxaYhTZsRtyEOaIuyd");
    int dJMwyVFFehMvRiIk = -424772105;

    for (int jnaxVbYGLAhsx = 1536642362; jnaxVbYGLAhsx > 0; jnaxVbYGLAhsx--) {
        continue;
    }

    if (IFbVFYgN >= -424772105) {
        for (int ICNnUOit = 582726960; ICNnUOit > 0; ICNnUOit--) {
            continue;
        }
    }

    for (int BTyIKaWhVgIWra = 203461004; BTyIKaWhVgIWra > 0; BTyIKaWhVgIWra--) {
        KPgLKbVy = KPgLKbVy;
        dJMwyVFFehMvRiIk *= qRDDmFCfGYxFzv;
        qRDDmFCfGYxFzv *= qRDDmFCfGYxFzv;
    }

    if (gyqvooKpN != false) {
        for (int BnhgMhDTcby = 1641029032; BnhgMhDTcby > 0; BnhgMhDTcby--) {
            CLZcO = ! KPgLKbVy;
        }
    }

    for (int yOIboZagVD = 693894235; yOIboZagVD > 0; yOIboZagVD--) {
        continue;
    }

    if (CLZcO == false) {
        for (int WZsLWg = 1531862486; WZsLWg > 0; WZsLWg--) {
            DIoesH = DIoesH;
            qRDDmFCfGYxFzv -= dJMwyVFFehMvRiIk;
            HdvybJKT *= YrcFD;
        }
    }
}

kNOcWc::kNOcWc()
{
    this->uDxosG(false, -405661332, string("CZynspZcQXVpPtBaIYdJZqfIAoMhAucIFPSkDujWFYoXtHbRAuOiCiSAswildhl"));
    this->gsFqymZs(-774652.6956968511, true, 144642104, 1645463419);
    this->GsGQRSYeXxXGRuCq(59467.16384244032, true, 431442.61115982296, 151129.6781602682);
    this->euEdmtEqXKDTbon(-175026.3003467292, -213780.9643440911, 2051648082, true, false);
    this->EgIyNq(string("KBdAcFljGYkPhNQIhBcTqMfWpcO"), true, true, -1272969923);
    this->uRNcPwFBxHuBVBjO(true, 466686323, false, 704620.0620875193);
    this->UIiUG(false, true, 1257195628, 1880294719);
    this->UncNhlVBXnfXbp(1194995635);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tzeghuyI
{
public:
    int YZmLjHDae;
    int dZsgN;
    string YeBZeLJ;

    tzeghuyI();
    double KhJGKYVfZes(int zVRSIvum, string LGzZBYVqoTC, bool IBpUGGrLOBwDbAy);
    int BccCHkzeixza(int bEbnfjwR, int AzjUBhxmBU, int wlYRsJ);
    void UlWdZVkhaNDKs(bool oZoFxU, int FdksRAOoMDwZyE, double NHfRK, bool ooWnaz);
protected:
    string KEOcjnWqxkzA;

    double KwxhBovj(bool enEYVEuj, double EkxHlTp, double zSgKJFItrQ);
private:
    string CfDvEqBgjhly;
    string ZaTqUzg;
    int klCyJYGmFJ;
    int QOSDy;

};

double tzeghuyI::KhJGKYVfZes(int zVRSIvum, string LGzZBYVqoTC, bool IBpUGGrLOBwDbAy)
{
    double NZggQ = -663869.4494599013;
    string bsooiuTrHvf = string("sicDATdzFHAASeBOazSLkCzjlsUwUkaowgSFvTzhmjOEjeibynIDWvQQEpmRujavLeoUQMBaeOVSUWFtwrMqFzQaQdYqQrDJzQGVnsFQWfgxPyoVGPbUSGQxcvEQT");
    string FAOnhRbvQqapc = string("ymbzRCuUCraglCsWCtxzHWYIviDiCESTUQHaEppULEQLgcuArqUshsjFnKagDoYetEDCnsPraeFfwuIvOocBwnxFQdQqFKTFkeKvjnOyZUEzwGZkqheoYNzIBvZHezcFBELgnIZckNoKwtlityCmmAiSJNHRnudloOEYaFcCcjqmACqcCHl");

    for (int dGuLyeAJb = 330986026; dGuLyeAJb > 0; dGuLyeAJb--) {
        IBpUGGrLOBwDbAy = ! IBpUGGrLOBwDbAy;
    }

    if (NZggQ < -663869.4494599013) {
        for (int UJPdoPcGBrynv = 870181018; UJPdoPcGBrynv > 0; UJPdoPcGBrynv--) {
            FAOnhRbvQqapc += LGzZBYVqoTC;
            LGzZBYVqoTC += bsooiuTrHvf;
            LGzZBYVqoTC = LGzZBYVqoTC;
            bsooiuTrHvf += FAOnhRbvQqapc;
        }
    }

    for (int XLTApiAQ = 1350740238; XLTApiAQ > 0; XLTApiAQ--) {
        bsooiuTrHvf += FAOnhRbvQqapc;
        FAOnhRbvQqapc = FAOnhRbvQqapc;
    }

    return NZggQ;
}

int tzeghuyI::BccCHkzeixza(int bEbnfjwR, int AzjUBhxmBU, int wlYRsJ)
{
    double CqJfDXDIQ = -459354.1156770309;
    string ERRnrcAhkagygT = string("BxXLOmsoBelibvsjphpUYWIRqHlqDCgaydIXLxvKVKRPKaArDNroEuAwTANZpynZhkXXYnwXfmZTQdPjQQnUcTfVuxVgpoQUSHLCjGNfqidZLBnkfcZeoefYbKQYFhTIFhYkkyQzvJtyseznwmswMmcEylrZkoZiGdiiybfReumcATarXorkEKdKscgzZFyBOqoGwKHpgVogVMEKzidnVLpEeIkiDtkkoKiNThMnVkAmajq");
    string gfqmpPOOAauh = string("MbPjpOPyBvRcTGxyFbevqGMVDgvqRPXHaqkZNpINIegEHWdRbUsPPcRsGBSRrKDyvNNvHCUKDpSmFbQghYdxGRsLxxhVLrHcEruvKgyGheLOxpykqZOXgLYKAIDROinHNyVCsvfOToblJIbGVZKLFsCGcnHDTlXRHNkwjCxcpRM");
    bool JLBIF = true;
    bool LTXtmLuF = true;
    int tzOnjXCYyGYNflmx = -574092438;
    double pInaQyM = 882933.1302493927;
    int lwWkqHPSkqBcCH = 1270413080;

    return lwWkqHPSkqBcCH;
}

void tzeghuyI::UlWdZVkhaNDKs(bool oZoFxU, int FdksRAOoMDwZyE, double NHfRK, bool ooWnaz)
{
    string nrVzjq = string("oRhX");
    string ZNwuJWDeWrhlJ = string("eNMHNdiDVSgmAAQTXzXscUGrldZhTUkyKFmTvZNkFLtdgHMlCYBCYdumYFaPwrzTpdDzXuvkwsATFvqMbUJUSNMyURjawCqDJPzNNgUbAhKTzNNBeSvtH");
    double oZqPtOB = -295546.1188168374;
    string HNOsDE = string("GtnOazNKaNyPkjwUqOqeAMLPZtnmvmKIUVgzJXqlCPkRzzhmHliHTknizSFUTTuhCMJVEdXGxPqZohcjQMIEyRWnNEGYNiuTHNFdGvCuIEuBHJoYgOHmgYiSAqFcypRtGmvYBQpjMxjnSqPiFmEQHDyupcDdUcVwnVhVhhZGTeMWVhBQvodBOFxmGunqWuyYfaMDk");
    string UPNNTsBPn = string("YBeCDdbsWVqQYHZRkUgDAFfNqpUsVcLCnhjZRNDYVvnyunqCTybwsaGCargUnfLQWeyMQbDRzvWQQWseiAUynEPffrvxWcLZAinoFhPpgggtG");

    if (nrVzjq < string("YBeCDdbsWVqQYHZRkUgDAFfNqpUsVcLCnhjZRNDYVvnyunqCTybwsaGCargUnfLQWeyMQbDRzvWQQWseiAUynEPffrvxWcLZAinoFhPpgggtG")) {
        for (int VAOseZ = 443039507; VAOseZ > 0; VAOseZ--) {
            oZoFxU = ! oZoFxU;
        }
    }

    for (int VQAZyGOsQEpG = 394340743; VQAZyGOsQEpG > 0; VQAZyGOsQEpG--) {
        ZNwuJWDeWrhlJ = ZNwuJWDeWrhlJ;
        HNOsDE = ZNwuJWDeWrhlJ;
    }

    for (int lFdmuXGL = 1897611258; lFdmuXGL > 0; lFdmuXGL--) {
        NHfRK -= oZqPtOB;
    }

    for (int mzjXozRRLghjTTg = 722531023; mzjXozRRLghjTTg > 0; mzjXozRRLghjTTg--) {
        UPNNTsBPn += UPNNTsBPn;
        ZNwuJWDeWrhlJ = UPNNTsBPn;
        UPNNTsBPn += nrVzjq;
        HNOsDE = nrVzjq;
    }

    for (int IhAJhZmLP = 85372700; IhAJhZmLP > 0; IhAJhZmLP--) {
        UPNNTsBPn += ZNwuJWDeWrhlJ;
        ooWnaz = ooWnaz;
        oZoFxU = ooWnaz;
    }
}

double tzeghuyI::KwxhBovj(bool enEYVEuj, double EkxHlTp, double zSgKJFItrQ)
{
    string CWmJnRaYJkpQX = string("XgVzGRGQZHhzYfpSjSEeiRblrFqSqyvrfZUdrWbXBPocLBhoGwxksyyJdptbAhxXmfiFIOINTemPoTqRJwhMIswYwAZEhxAdDhNXLnVtNBfPnNjZEco");
    double ySelOgIIlZZFQ = 490951.4687055599;
    string tkvVkaQSTjl = string("dVqUmaHlpygoVIZlCLKgpaiPOWGtYBkIuDxCqmnpkqWEdxFhIVujnWkkeXNhZtzHdihjBoLdbgxRwdZeMWRuqtyBeHQxfsAZBwPGpDyOCwpKsPjlkugsbdBZUxFmnYFFGKDGceuXMWrYhPGIlnP");
    bool EUHMCwpak = true;
    bool LtdsKy = false;
    string iRXHi = string("IZfglGwlWVEEdGtzxHufpdZuNQRkhEAISMhSbeBFFPdNwiVdIQSOwgIojNOVRhMxIqQesbHwggiAORMgrztcjILwCUdmieHrYtGoAXppejwFlzZYeYrVMHLcHTgeCyokdgecXApSOaqWssBKWGLHpOGkaBnOWztboGUKdxXoMSKMooRwZETploBWtTTmayHTDKGuVJgNDmZdfDhxXZrbOCIrLgyeEqJcFBkMHiCQkPanMFhBcJugGoGHYNkqC");

    for (int umlIXPjbJc = 1477747167; umlIXPjbJc > 0; umlIXPjbJc--) {
        enEYVEuj = ! LtdsKy;
    }

    for (int petjdot = 70662101; petjdot > 0; petjdot--) {
        continue;
    }

    for (int lPjjolUcsGF = 973965877; lPjjolUcsGF > 0; lPjjolUcsGF--) {
        ySelOgIIlZZFQ /= ySelOgIIlZZFQ;
        LtdsKy = ! EUHMCwpak;
    }

    return ySelOgIIlZZFQ;
}

tzeghuyI::tzeghuyI()
{
    this->KhJGKYVfZes(-1403802288, string("NnIVrNkhaFPTRVSzTmYWgZFMadoiXRyLGDyNRjcmwteOEUaSHUVFQVOPjLkWhATBnLNpNzuDvHHuveethBZHSYZUJWBxbjfQvgLWJFqTLTSrOvaGLBNsANRbwKKotykFKVcDtVqgTYqNVjFyvnmJTstBlInMrIRW"), true);
    this->BccCHkzeixza(1349111350, 250215228, 303871020);
    this->UlWdZVkhaNDKs(false, 1197551417, -886912.0053060187, false);
    this->KwxhBovj(true, -546313.6658449935, 466256.47854779183);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class eMnrcwbpBuT
{
public:
    string ZUQlQFCXTd;
    double EMzjGzlYjYdKGCQ;
    int vEqFG;

    eMnrcwbpBuT();
    double CXUXa();
    void rflpGoYLmy(double sPJdbzhJiZ, double nmRUGXuyvjz, string IeMAd, int lrDQaxkX, string huvvufSQa);
    string ILlLL(int MwnzTDoDXgj, bool RdRSX, double TqgBqS, string GBcZH);
    int CQnySDYz(int BeyesevJZIQp, bool rTFEdAnpNtAkVzG, double qrbHEceB, bool XLvciXwMF, double AvUoN);
    int UlGWxxDTslUt();
    double TTkPEUsCZy(double nbLUSeBUczyx, double WlPwtIpnqzK, bool siQLfrCoATVdRuCX, string IphYlEjQulCmPOPY, string qFQTYPHMgdD);
    double mmxJWzDVriIq(bool tEHTwOQ, double KSSFNeQij, string vgxRl, string CmYSkIraAgeIx, bool uDxDqKfEiTBIz);
protected:
    double nnXdAyPpNmrJJN;
    double KKShOQRYpNHbLXei;

    bool jLcJWoD(string koTYojubEVSsIDI, double txSXlqPbUDlMO, bool QEAapzu);
    int bSYxDmSQjPm(int iHAVDMCNRwLZE, string NtTcLchMWBwITn, string wjFEUjnbGo, string JnYuzAxv, string qKfeS);
private:
    double SguZWngFbucIKvrz;

    string vqPbtneWdgApMZL(double jHEoYxdXpvLd, string ScSiyHEWzq, string NUpNwVGPa);
    int bXeAJOwvoRlypyBr(string vgTKiilYOYUghpA, string euEqewFhSVRazS);
    string GDXeKFIaAr(double YsCTTnsAsGlkA, int HKGClEK);
    bool bFgStjmzN();
};

double eMnrcwbpBuT::CXUXa()
{
    int LBcjYthPlqikVEdr = 1154340201;
    string PHjoHukS = string("lUkwtzmIHcnQQrjYhwPdnxdrpiXmtJzFvGZlYBxNWmVufRWOufaQcCkFQkIrSlyNfjEtvyLSZsYucHvzxQBMupTXzqqNypKsM");
    double ofmodVkFGX = -454902.810918449;
    string HMJOLrTMRd = string("elzVjxOqmrfqnCvpYuvekp");

    for (int muNuTfbMduAoO = 1635789823; muNuTfbMduAoO > 0; muNuTfbMduAoO--) {
        HMJOLrTMRd = PHjoHukS;
    }

    for (int oNVWwsjkEbptZ = 215562082; oNVWwsjkEbptZ > 0; oNVWwsjkEbptZ--) {
        HMJOLrTMRd += PHjoHukS;
        PHjoHukS = PHjoHukS;
        ofmodVkFGX += ofmodVkFGX;
        PHjoHukS = HMJOLrTMRd;
    }

    return ofmodVkFGX;
}

void eMnrcwbpBuT::rflpGoYLmy(double sPJdbzhJiZ, double nmRUGXuyvjz, string IeMAd, int lrDQaxkX, string huvvufSQa)
{
    string hqRWhjZIBdh = string("WWvzEoSPpsrNOenAZZrzKkQpcoDfoxRooNCuWChGftxIyWSxEEHaRmxDjYGPwHYJzEOAMDIjDWCeHioDXVuxjqmNDgkFAIUekEYTmgPZGgTAMcyNXYwTUfD");
    string fPWXRfwTtYAXEUzn = string("pIdgVvanZJMVFhCmKEyeSrUdkianlNrTbqLnjEJJFXPAkPIrR");
    bool ViSFbkRKdoTUrnE = false;
    bool AHhSKWufkqWSovjM = true;
    int dGoKLzQSToy = -750223160;

    for (int mySVdWIdDs = 2041845528; mySVdWIdDs > 0; mySVdWIdDs--) {
        sPJdbzhJiZ *= sPJdbzhJiZ;
        fPWXRfwTtYAXEUzn += huvvufSQa;
        hqRWhjZIBdh += fPWXRfwTtYAXEUzn;
        fPWXRfwTtYAXEUzn = hqRWhjZIBdh;
    }

    for (int SOIhFQVepEoEHLMp = 931207754; SOIhFQVepEoEHLMp > 0; SOIhFQVepEoEHLMp--) {
        lrDQaxkX = lrDQaxkX;
        fPWXRfwTtYAXEUzn = fPWXRfwTtYAXEUzn;
    }

    for (int DbvluDLn = 104518368; DbvluDLn > 0; DbvluDLn--) {
        ViSFbkRKdoTUrnE = AHhSKWufkqWSovjM;
    }
}

string eMnrcwbpBuT::ILlLL(int MwnzTDoDXgj, bool RdRSX, double TqgBqS, string GBcZH)
{
    bool viSiNAQW = true;
    bool yNDBjwy = false;
    double QDJwNFCkQQPTJJp = 937344.4599751434;
    int ATgklruMjoMobFs = -686852354;
    string GQnkLTFv = string("RIrxhtSOxmottegsLU");
    double Abjfk = 593982.0400938799;
    double QLIriZkCeRIMO = -121327.85299955946;
    string fwLCOGmzjsU = string("HexFZXHgmclLEYNtltheUAJEBnxgaPtdorOOtSldahvyuiICREQGBkuSituSMUOSeKqFbJUZzDQbDPtVimDCwaGKiziJVtkZMcwqXZQjlFDLbJCWluYZLTm");

    for (int ZFfLsGamRPAzPNG = 1859500317; ZFfLsGamRPAzPNG > 0; ZFfLsGamRPAzPNG--) {
        continue;
    }

    for (int UesPg = 857417066; UesPg > 0; UesPg--) {
        Abjfk /= TqgBqS;
    }

    return fwLCOGmzjsU;
}

int eMnrcwbpBuT::CQnySDYz(int BeyesevJZIQp, bool rTFEdAnpNtAkVzG, double qrbHEceB, bool XLvciXwMF, double AvUoN)
{
    int ZvFPzUHQKMoSKFsU = 1039344221;
    double qObBEHzxGVGVtjwt = -767326.6522483674;
    bool AkVBWJZVBwZnGt = false;
    double cVIgxEcmoDj = -969691.5874924707;
    bool YabpNvADTOUNU = true;

    for (int vRcmEFMXGI = 594092598; vRcmEFMXGI > 0; vRcmEFMXGI--) {
        XLvciXwMF = ! rTFEdAnpNtAkVzG;
    }

    if (qObBEHzxGVGVtjwt < -767326.6522483674) {
        for (int Irsci = 1447688537; Irsci > 0; Irsci--) {
            continue;
        }
    }

    for (int OlDPwdDEiXE = 1738659717; OlDPwdDEiXE > 0; OlDPwdDEiXE--) {
        qrbHEceB += AvUoN;
    }

    for (int oXsJwSfWPPohvM = 1537728656; oXsJwSfWPPohvM > 0; oXsJwSfWPPohvM--) {
        qrbHEceB *= AvUoN;
        qrbHEceB *= qrbHEceB;
        AvUoN = cVIgxEcmoDj;
        rTFEdAnpNtAkVzG = YabpNvADTOUNU;
        ZvFPzUHQKMoSKFsU *= BeyesevJZIQp;
    }

    return ZvFPzUHQKMoSKFsU;
}

int eMnrcwbpBuT::UlGWxxDTslUt()
{
    string EAiPfW = string("zqCHQQxIDsQlMyPEZqXkPZLwoUSTyWWEUuxgfZuifBDphbZhiYsHQsRagBcLpJSGbNwwcUhKHPhdSMZcGSNwJRVWXHBclCUnQftcFCmNBBitMUfEgPEOMLblhPnMNkkBUYjqimIMWOJnGNX");
    double mvVMxZawPSOldns = 554731.273287457;

    for (int icnfoemtQfMHGA = 805993700; icnfoemtQfMHGA > 0; icnfoemtQfMHGA--) {
        mvVMxZawPSOldns = mvVMxZawPSOldns;
        EAiPfW += EAiPfW;
        EAiPfW += EAiPfW;
        EAiPfW = EAiPfW;
        EAiPfW = EAiPfW;
        mvVMxZawPSOldns += mvVMxZawPSOldns;
    }

    return 930646298;
}

double eMnrcwbpBuT::TTkPEUsCZy(double nbLUSeBUczyx, double WlPwtIpnqzK, bool siQLfrCoATVdRuCX, string IphYlEjQulCmPOPY, string qFQTYPHMgdD)
{
    double jKsSzNurBH = -74523.85841825;
    double SVDvbsKuiYQ = 409681.87194156;
    double lQspMQBvqMFckF = -100237.33608135176;
    bool KWXLKltIukaAU = true;
    string RlbKDULVvSknEF = string("ewgesrjQYuNwaCfxHwcNCQrFdztVLgZwiLSGjjwlLFqPXTgeJsvSBHLFjwtKgsvDrSGuSFMVoBhGRjwBKeziNnegUjeRhjxHugetzKrWfcNaliJMudsFdTivaTzSxyZ");
    int hprUCkYxMCwrlV = -1872462570;
    int XWkyKSUYtBWH = 578771891;
    string WSGZtjGYPrLc = string("laKzksXDjqgzLuGWRPozyASdIiodBUcQEbRgGulWvQkWLFbPNIkjxdMKzIlfdCCWFhEumrXfSAyrQvcRgDTgiBqzuqySZXAHXPZTjetIypPEHsZvdvlIiaCnlAGBpdYoANekPdZIccKDofCdEcCx");
    double cSARxHhvko = 560669.4323232402;

    for (int IzFULbVGjg = 1952826861; IzFULbVGjg > 0; IzFULbVGjg--) {
        cSARxHhvko /= cSARxHhvko;
        RlbKDULVvSknEF += RlbKDULVvSknEF;
        siQLfrCoATVdRuCX = ! KWXLKltIukaAU;
    }

    for (int ofKKUYnHEJMsQqd = 1187331990; ofKKUYnHEJMsQqd > 0; ofKKUYnHEJMsQqd--) {
        cSARxHhvko += cSARxHhvko;
        WSGZtjGYPrLc = RlbKDULVvSknEF;
    }

    if (WSGZtjGYPrLc < string("laKzksXDjqgzLuGWRPozyASdIiodBUcQEbRgGulWvQkWLFbPNIkjxdMKzIlfdCCWFhEumrXfSAyrQvcRgDTgiBqzuqySZXAHXPZTjetIypPEHsZvdvlIiaCnlAGBpdYoANekPdZIccKDofCdEcCx")) {
        for (int JMLmiqlnW = 1097659240; JMLmiqlnW > 0; JMLmiqlnW--) {
            hprUCkYxMCwrlV /= XWkyKSUYtBWH;
        }
    }

    for (int djWxWVjWdtiqbnZ = 1589023413; djWxWVjWdtiqbnZ > 0; djWxWVjWdtiqbnZ--) {
        continue;
    }

    for (int HYmjDt = 990614929; HYmjDt > 0; HYmjDt--) {
        continue;
    }

    return cSARxHhvko;
}

double eMnrcwbpBuT::mmxJWzDVriIq(bool tEHTwOQ, double KSSFNeQij, string vgxRl, string CmYSkIraAgeIx, bool uDxDqKfEiTBIz)
{
    string bznpoUVesJ = string("NtRxSLdBBFBzYOxghcgYLiJqvRuqxXKyVssnaincVwROWhWdMiAtvnGaAMMiQpkPTONZnfFczoAExIroQfKZMvLxtthwmEJwzjRsGWLRldnNBHqDMtnmcdSVTjmaxMwjYxcLyqoroWkpr");
    double uhNXpUodRQG = 826119.9591591097;
    string pPauznyhokOYCBj = string("mSKKQjcWmNSQvucuH");
    int hzqUdKEtO = 1400451673;
    int gdsYUfOvXDmm = 1266252571;
    int jfhlxrLzNLDqaL = -166077662;
    int zCODqslExlySBoFn = 330319953;
    double Wwdvc = 120831.91443900022;
    bool TiqViEIcZtVD = true;
    double wSDKmm = 855932.6202194301;

    if (hzqUdKEtO == 1266252571) {
        for (int WZPYBkii = 512114994; WZPYBkii > 0; WZPYBkii--) {
            TiqViEIcZtVD = uDxDqKfEiTBIz;
        }
    }

    for (int hcjcbtIKUfWco = 1265261157; hcjcbtIKUfWco > 0; hcjcbtIKUfWco--) {
        wSDKmm /= KSSFNeQij;
    }

    return wSDKmm;
}

bool eMnrcwbpBuT::jLcJWoD(string koTYojubEVSsIDI, double txSXlqPbUDlMO, bool QEAapzu)
{
    int iDlBxDvw = -1948863492;
    bool gbKZXBgu = true;
    int dfyTuFky = 1937481327;
    bool csAhprP = false;

    if (QEAapzu == true) {
        for (int WrHajixOEkJqhoI = 445126679; WrHajixOEkJqhoI > 0; WrHajixOEkJqhoI--) {
            continue;
        }
    }

    for (int POorQYrqyGB = 240261388; POorQYrqyGB > 0; POorQYrqyGB--) {
        iDlBxDvw *= dfyTuFky;
    }

    if (gbKZXBgu != true) {
        for (int wpvljVhicth = 1151117713; wpvljVhicth > 0; wpvljVhicth--) {
            gbKZXBgu = csAhprP;
            QEAapzu = ! csAhprP;
        }
    }

    return csAhprP;
}

int eMnrcwbpBuT::bSYxDmSQjPm(int iHAVDMCNRwLZE, string NtTcLchMWBwITn, string wjFEUjnbGo, string JnYuzAxv, string qKfeS)
{
    double oFcplXc = 946900.5578186857;
    string stcMe = string("flCVceJLZjwOIEiBMYntWSFUHdOrKoZnJtzvAUddjYHRpcU");
    double czGjYW = 140754.56944124677;

    if (stcMe >= string("ynubfGRwDGEiExylVglsvUPbjOtAYQrAVmpvXKSkVFbiqSiIDgbJlMfIWbweNgzWnJDVXliNifyNLwcKNOCmhTemILkrAilfoarzGKoMGvoBLPCRITjAgwCbgNoAXpZBrAvdJWACESnGPkmSszZAfMRTOrXpqMUHLDNHLBtHJTQijDrYwLhXCxPnwQICCYMtZXzKHaNwqUARHAOcxvcGRCkObLFKKDThliLKuEZ")) {
        for (int PacBtXksldqmyJXj = 1043770841; PacBtXksldqmyJXj > 0; PacBtXksldqmyJXj--) {
            JnYuzAxv += stcMe;
        }
    }

    if (stcMe > string("GEqVsIsvhhivYglvmBaMUekVjaOqViomDcnQurtNrZKDKiXAzywvtIUEhHBpAQPxFZzYcebiRbKfqhxGNehurkvBUFtbOpTKLWLuplbxHidmkOoiJILEUOmOnyGNwNWJgBAhjqRGdYBCocBGZiMBcpxfeQMWwOgnmknnMYsWhSFEqgJeoTbfUzkysLXEkHepmheTlIkAhZlTzvadnaAzOQpOiIWOrbWBW")) {
        for (int OthjpTACVtmMe = 927196022; OthjpTACVtmMe > 0; OthjpTACVtmMe--) {
            oFcplXc /= czGjYW;
        }
    }

    return iHAVDMCNRwLZE;
}

string eMnrcwbpBuT::vqPbtneWdgApMZL(double jHEoYxdXpvLd, string ScSiyHEWzq, string NUpNwVGPa)
{
    string PPZAsRk = string("UcbIBnEMDLqhaCFmwajl");
    bool inFcSeBlPoHKrfGe = true;
    int ltIwzKlnXiAL = 253190749;
    int mRWJMwcFXRNQA = 1799292195;
    double GzfmYcuYVtwzxw = -406053.3945229202;
    bool kFJMYgIRsGrH = false;
    string ULwiTn = string("DcJfRoIHbYXbYkgZVULACYEdaoCgLGODCjWyjWmXLVrNGbSeqKqTefkMUZiqokKcYmUFjLKdnXuEARVZcosVMyrSKcraEYPeEzBPIEYGKdQiGEFFyWYGaxgisSCrKEjRIulMPNcicZIBQQnYuiMkliYEqiComCIVkpsRbreAfeUwWWCadOAsETWCSVxeEjqVCZjXbcQ");
    bool lMfslI = true;
    string cnVsca = string("PMdevsTfwEKhSerwLELBFARfAylrNAibBsdTpNVpIiEsuMviliIGABeSiLYEkdrqlCumnLFNmOUeSuqDgCAUekitNKIpXHLpHYVKxmgQtEvOOarHMswbLHUEsVCHSNvtWrsOWBQDGftzBMSLTnWnRlnnJgaZqhbn");

    for (int fgOqvVnYKkc = 1161936377; fgOqvVnYKkc > 0; fgOqvVnYKkc--) {
        PPZAsRk += ScSiyHEWzq;
    }

    for (int hpfLwzvvlI = 685854421; hpfLwzvvlI > 0; hpfLwzvvlI--) {
        continue;
    }

    if (ScSiyHEWzq > string("UVTWivpzdivKxVNxzmNUsuhdEbmTMZVuzCrjxKodWJvSMVbXiymczEqiHOZFDPRKYrJkPxFokZsjDkMfpgTTstHRcXeuCMkQMLAbPyatSvkTLYeyHNjckfOVcYQKQlxCMnLgPQkiJeutFjJbOkeMhbZGaWilFCBuJUEtlBQYoLQClHgrcQbwVJlkpd")) {
        for (int rsTZHGlLMpIWZsVw = 1183258350; rsTZHGlLMpIWZsVw > 0; rsTZHGlLMpIWZsVw--) {
            ULwiTn = cnVsca;
        }
    }

    return cnVsca;
}

int eMnrcwbpBuT::bXeAJOwvoRlypyBr(string vgTKiilYOYUghpA, string euEqewFhSVRazS)
{
    int HQwoHkuB = 2136919073;

    for (int fxBEalstc = 2132997551; fxBEalstc > 0; fxBEalstc--) {
        vgTKiilYOYUghpA += vgTKiilYOYUghpA;
        euEqewFhSVRazS += vgTKiilYOYUghpA;
    }

    if (vgTKiilYOYUghpA >= string("pSIGMcrmwHxTJXssMnsxyArlwIQpkQLxn")) {
        for (int SGgcUZHy = 927400588; SGgcUZHy > 0; SGgcUZHy--) {
            vgTKiilYOYUghpA += vgTKiilYOYUghpA;
        }
    }

    if (euEqewFhSVRazS <= string("pSIGMcrmwHxTJXssMnsxyArlwIQpkQLxn")) {
        for (int bquHtgDmClFXqZ = 2135121845; bquHtgDmClFXqZ > 0; bquHtgDmClFXqZ--) {
            euEqewFhSVRazS = euEqewFhSVRazS;
        }
    }

    if (euEqewFhSVRazS != string("pSIGMcrmwHxTJXssMnsxyArlwIQpkQLxn")) {
        for (int rflplD = 988815204; rflplD > 0; rflplD--) {
            continue;
        }
    }

    if (vgTKiilYOYUghpA >= string("XPEtSvByczcMBYmTyalyxZWlASKZNoKdGswLxuUlsaSOsHqDqocVRUUwPLecrwiOLwxAkowZHqYqkVnREGmAsPGXaIOwMqWnemEAmBMJrvyTqwZhnAccGbPoqFqogSillCIqCNWVCNuplvxhsZPaCSGZUCKcPt")) {
        for (int QJzVckaOfBos = 579740600; QJzVckaOfBos > 0; QJzVckaOfBos--) {
            vgTKiilYOYUghpA = vgTKiilYOYUghpA;
            vgTKiilYOYUghpA += euEqewFhSVRazS;
        }
    }

    if (vgTKiilYOYUghpA >= string("XPEtSvByczcMBYmTyalyxZWlASKZNoKdGswLxuUlsaSOsHqDqocVRUUwPLecrwiOLwxAkowZHqYqkVnREGmAsPGXaIOwMqWnemEAmBMJrvyTqwZhnAccGbPoqFqogSillCIqCNWVCNuplvxhsZPaCSGZUCKcPt")) {
        for (int SSlamtfnZD = 2137582173; SSlamtfnZD > 0; SSlamtfnZD--) {
            vgTKiilYOYUghpA += vgTKiilYOYUghpA;
        }
    }

    return HQwoHkuB;
}

string eMnrcwbpBuT::GDXeKFIaAr(double YsCTTnsAsGlkA, int HKGClEK)
{
    string MaQbN = string("wECoeyApC");
    double StXbd = 995199.6862375039;
    bool wDbbYjqJCgCNQsKQ = true;
    double xrIwSUbpn = -441879.41827435466;
    int ougdYzKOESqt = 2087440973;
    int uECYxUYmJs = -1640924752;
    double DhWSsXbDWMpABRm = -157014.85724897243;
    bool XnIzZhbRUnpHz = false;

    if (YsCTTnsAsGlkA >= -441879.41827435466) {
        for (int vfztG = 1299605841; vfztG > 0; vfztG--) {
            xrIwSUbpn -= DhWSsXbDWMpABRm;
        }
    }

    for (int zkkmM = 1636687486; zkkmM > 0; zkkmM--) {
        xrIwSUbpn -= StXbd;
        StXbd += YsCTTnsAsGlkA;
    }

    if (YsCTTnsAsGlkA == 995199.6862375039) {
        for (int jwBCmWFciPzBnQ = 1480445232; jwBCmWFciPzBnQ > 0; jwBCmWFciPzBnQ--) {
            YsCTTnsAsGlkA *= DhWSsXbDWMpABRm;
            HKGClEK -= HKGClEK;
            YsCTTnsAsGlkA += YsCTTnsAsGlkA;
        }
    }

    return MaQbN;
}

bool eMnrcwbpBuT::bFgStjmzN()
{
    int IfRyfKk = -1867071527;
    int LCIJgyJnqCrRM = -1159463549;
    bool fzykklgrFyKBe = true;
    bool aOLUnTuIvl = false;
    bool KqYoGwA = false;
    int boTxzIav = 1850804313;
    bool AQyDqeIWCryw = false;
    string EwcisoFB = string("zwsTRmlTgRnvaWmlIbHXKIQKOJpIZKxYnCl");

    if (aOLUnTuIvl != true) {
        for (int pIjSBQqYX = 733136983; pIjSBQqYX > 0; pIjSBQqYX--) {
            fzykklgrFyKBe = KqYoGwA;
            LCIJgyJnqCrRM *= IfRyfKk;
        }
    }

    if (fzykklgrFyKBe == true) {
        for (int qVIEVnAlUVy = 839484722; qVIEVnAlUVy > 0; qVIEVnAlUVy--) {
            boTxzIav *= boTxzIav;
        }
    }

    return AQyDqeIWCryw;
}

eMnrcwbpBuT::eMnrcwbpBuT()
{
    this->CXUXa();
    this->rflpGoYLmy(946843.1985394519, 557661.1858564557, string("zztETIVQisuQmSpLqwxYAjwRlNIgNjiWSJCXCCbyQUPoNJZGJvdguHlRZLArlmIySaaDRSxlCSYvVlugXiBtfcrbXDDagZRNmcVnfsprEygcZyDmQLNDzscivMZgTyrEkLDoefLkADSRAGORhmHtbxhExytVwOvSWFJDBWxdtQtjBawcQKQytQpEPalPPzqrvsNIzgLSpEpSOpDULdZNhclHmTnZGnSqwZswn"), 1241109041, string("IZAiBSKTaUemoPUujzZFEThlYuCvhgdpWgUGNGcVinctUtkWuRHM"));
    this->ILlLL(-1694718001, false, 842289.465990301, string("zPkGkzRXqPAowwDdxoKJFoJwfejHUQMCQPiosfLggszKJTUAWxMuiyhzWbhIxcjPIaFCRLTknqreKuYYMNjZgIcFSxITikzAIFsrwDvRjaRoGAsuAlElyqdBWBMEnnebKliaLIvwInEEZYhyShvsoKYEAIVtjGQfeiRBDUbxdoiIyPGaZYIabWkU"));
    this->CQnySDYz(873837193, false, 74921.61792950086, true, -644828.7842408114);
    this->UlGWxxDTslUt();
    this->TTkPEUsCZy(-169796.55135861164, -539909.9603811482, false, string("wXOMERtbswAhLFHZJjWSDyleBbQcoGoRvykuREXdRneRXTbMHhQLyGHJaINTTkkCSXfOhLYxrxaPUUwxoneVyvcOOpOUjEdCcMQOYNbopXqQgIiWBfqcfxPNnuYstaKKiDpEVqmoxuFCDfzASIrZzAtPvbtBZgVoFPdEJcGobIobAWwXIzwFyRkAJwcwhABBFtDUxnHtFIIUwgENmyDhHLqUzdSSdkpUmCjiXfnaRZNFrKkUtTSQUFFyShUkvR"), string("atllCNMmj"));
    this->mmxJWzDVriIq(false, 686282.9832080393, string("h"), string("fQIkTDNRILyDuyqjfAMeNJZitVPxCWePCkNFmlqWiMYDuanqulYUlITuiRDSmQxUJMygTgJWmkIAfdQymTkQSbKJfdLSueINHdFKJImBwqqGkkqJwETUKtMCAISiTUlzOXCAkDWlwyGnYhnFUcwICpXsfdyYzkZanMtyQspQXXGXlPbQzrsLfFKqJrVodARacQxiCAXUtKEFJXUkwQTNAydmFrHpRoarBBhZSWEgcXpzKTtPC"), true);
    this->jLcJWoD(string("YuJPZWzwVzuVnLzjXLyAOKXzdIyOEOdpyOKrEKudXzDkSoieODrljUJrbSAnwcNHiZErwAjWKDvIXihbQaYmqOFElz"), 547486.4169264372, false);
    this->bSYxDmSQjPm(29101587, string("GEqVsIsvhhivYglvmBaMUekVjaOqViomDcnQurtNrZKDKiXAzywvtIUEhHBpAQPxFZzYcebiRbKfqhxGNehurkvBUFtbOpTKLWLuplbxHidmkOoiJILEUOmOnyGNwNWJgBAhjqRGdYBCocBGZiMBcpxfeQMWwOgnmknnMYsWhSFEqgJeoTbfUzkysLXEkHepmheTlIkAhZlTzvadnaAzOQpOiIWOrbWBW"), string("dDMvXYCktEZMtespBHGsiuZmQTvQIjOSJbmHvNyyZlaCRGAvXhGCIUnIdIQRQYRhTAAyZYpddJVbOvvXoOhTGVMhPadImFrxyRHLXKjGytkjvzFCYUrhPWiBqMOBQROzKaJwXFDQXjKBTooZGhZFVlKwRSRPp"), string("ynubfGRwDGEiExylVglsvUPbjOtAYQrAVmpvXKSkVFbiqSiIDgbJlMfIWbweNgzWnJDVXliNifyNLwcKNOCmhTemILkrAilfoarzGKoMGvoBLPCRITjAgwCbgNoAXpZBrAvdJWACESnGPkmSszZAfMRTOrXpqMUHLDNHLBtHJTQijDrYwLhXCxPnwQICCYMtZXzKHaNwqUARHAOcxvcGRCkObLFKKDThliLKuEZ"), string("ezTHpQhzeVDRZgnrjYyI"));
    this->vqPbtneWdgApMZL(354548.45760821673, string("UVTWivpzdivKxVNxzmNUsuhdEbmTMZVuzCrjxKodWJvSMVbXiymczEqiHOZFDPRKYrJkPxFokZsjDkMfpgTTstHRcXeuCMkQMLAbPyatSvkTLYeyHNjckfOVcYQKQlxCMnLgPQkiJeutFjJbOkeMhbZGaWilFCBuJUEtlBQYoLQClHgrcQbwVJlkpd"), string("ZhESgFhDxdxDTovsuBXZTWutNUqjTjfAdRThevLusPjGIdKJkaUsGSnGCgrfPLtcDWiFsjTVqdDJitjOJgJdnNoaiiiASxvvpfLYsgPupCGZQXFBxeopmDfabnMTbnxbDTRukgfVRRKSZkmjOsNTHBrgBxhwROPgbfLEWrmdfcafdnSbTEbYj"));
    this->bXeAJOwvoRlypyBr(string("pSIGMcrmwHxTJXssMnsxyArlwIQpkQLxn"), string("XPEtSvByczcMBYmTyalyxZWlASKZNoKdGswLxuUlsaSOsHqDqocVRUUwPLecrwiOLwxAkowZHqYqkVnREGmAsPGXaIOwMqWnemEAmBMJrvyTqwZhnAccGbPoqFqogSillCIqCNWVCNuplvxhsZPaCSGZUCKcPt"));
    this->GDXeKFIaAr(82150.46729120235, 486116189);
    this->bFgStjmzN();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DUebvPhnl
{
public:
    double HeAVFyxYONdfL;

    DUebvPhnl();
    void wzCRiPrWNb(string AAGiNnJfJYJgFr, string FDAcyqa, double duBmrDpTBjoQ, string lEkLOTs, int escDMhrpjteZ);
    double mTJvIwfrva(int zJwndHodMEvPlVN);
    string pwXiqVMOMRy(string rLpzzgpe, int WaEpphSitXOnuNkb);
    double TMpoTBIiycXu(bool RHsfThxfX);
    int iKFHePhC(double LAshSiKdOEsUVRBt, bool oTBOHEv);
    bool kSSiJTkCASwX();
    bool YarWw(string kVwrUYtV, string KkVxiKgsuqfHo, int ozDRzzuXbCN, int RAXwDxVvaHES, int IykYqCRi);
protected:
    string xwysQQ;

    string ZvFSczYeyZkPomhR(bool gICvcH, double NbbIMSA, int DsdgBmcSHEFB);
    bool ZzkaIAvLgsOgqL(int bsLzFbCxYedXLKu, int QxABVIWyA);
    int XreEZ(bool jgWpeMV, string BxgTKOcRpoO, string oOrzzCujbUr);
    bool eExsVGhfDdMYCKas(bool bnPxPARyfnRWFN, bool BRZdsrOfxXNAdlr, bool AnyKH, string RwvCorvx);
    bool HXirLNyaFgw(string bMYoWMXA, string tiSWNp, string ZCGNSoLibEWpt, int dIokWscgsDbuUsYX, string fcDmoZdaffjjMl);
    bool OOADXldHcYtsBoO();
    double vKHYIZRAUs(double qANBqBFf);
private:
    bool NvGFaeyAIJXrkVvS;
    int OPUaPwuPMSdPHfy;
    int mTUypNBRNScvbEq;
    int maeMbdJBQNCMD;
    int QJCBOWJDQfhAOdCz;
    double RxnrNK;

};

void DUebvPhnl::wzCRiPrWNb(string AAGiNnJfJYJgFr, string FDAcyqa, double duBmrDpTBjoQ, string lEkLOTs, int escDMhrpjteZ)
{
    double MVkRNw = 455861.3491526148;
    int mkbyTCVIJmiYXc = -199178387;
    double NENAKv = 772096.2612269718;
    int gFFHxFdKBwEOkl = -1953585975;
    int IXqrgmnLJ = 1346966594;
    double UwACHiNMysE = 317269.25644988834;
    double RtNerSYvAMT = 612950.2292126536;
    bool seBaIJa = false;
    int LVUgdv = -618638105;
    string AVkuDqUQEIF = string("DpJXMNleMPmanHckLcpNNtfxGvcGyJECbWHXihpjuJlyrIUOvOOboVgdrLlVJwpkCNDdvduEHciVdKMeadxtHKFjrFWQBOnMNfotvzyXBwuaDeSklBDImEwrRiSjNUfgAWrFvc");

    for (int HVEJWD = 209621234; HVEJWD > 0; HVEJWD--) {
        continue;
    }
}

double DUebvPhnl::mTJvIwfrva(int zJwndHodMEvPlVN)
{
    int tsbcxNzNj = -1852620238;
    bool xHxjfdNMB = false;
    double PwmqoQSOkzcCZ = -861732.5410355135;
    int nzcDfESjU = 2043604399;
    bool vkqdRwXfGn = false;
    int GjyhfoKDJW = 406424354;
    bool ZoCtWCjwsX = false;
    double cZoMOonQ = 782374.5907615762;

    for (int nuKiZ = 534844872; nuKiZ > 0; nuKiZ--) {
        continue;
    }

    return cZoMOonQ;
}

string DUebvPhnl::pwXiqVMOMRy(string rLpzzgpe, int WaEpphSitXOnuNkb)
{
    double qpvGEriFPJmCSsvq = 85196.35398016202;
    bool eADZywngqGqh = true;
    bool wLrEwzUTIZ = false;
    int ttKkzgVuBJoC = 2132050610;
    bool YSrFnEFqvyrsq = false;

    for (int PEqnhKeCyfnw = 1237549270; PEqnhKeCyfnw > 0; PEqnhKeCyfnw--) {
        ttKkzgVuBJoC = WaEpphSitXOnuNkb;
    }

    for (int zmEvbEZZvauxo = 595082178; zmEvbEZZvauxo > 0; zmEvbEZZvauxo--) {
        continue;
    }

    if (YSrFnEFqvyrsq != false) {
        for (int PeiLaC = 1052633461; PeiLaC > 0; PeiLaC--) {
            eADZywngqGqh = ! YSrFnEFqvyrsq;
            rLpzzgpe = rLpzzgpe;
            wLrEwzUTIZ = wLrEwzUTIZ;
            wLrEwzUTIZ = YSrFnEFqvyrsq;
        }
    }

    if (YSrFnEFqvyrsq != false) {
        for (int sVhdbHKCvWfZiGaI = 2114980482; sVhdbHKCvWfZiGaI > 0; sVhdbHKCvWfZiGaI--) {
            ttKkzgVuBJoC -= WaEpphSitXOnuNkb;
            YSrFnEFqvyrsq = YSrFnEFqvyrsq;
        }
    }

    for (int xjFgcYaFFWnqP = 1318559989; xjFgcYaFFWnqP > 0; xjFgcYaFFWnqP--) {
        continue;
    }

    if (qpvGEriFPJmCSsvq > 85196.35398016202) {
        for (int vIsFrBqJvoBV = 1980925849; vIsFrBqJvoBV > 0; vIsFrBqJvoBV--) {
            wLrEwzUTIZ = wLrEwzUTIZ;
        }
    }

    return rLpzzgpe;
}

double DUebvPhnl::TMpoTBIiycXu(bool RHsfThxfX)
{
    string XAvLAnldsqwYt = string("QOhFVNmDvqwiIsXBtghZDxWPCIuiBkRsqsabFabbnWnf");
    string YICIn = string("JbBwcOXxCsfgybIwSWumOLHLnOxtBGGpaYDcbfxrIPwzpCFUPHUCEXHXrihSTMtFbXuboGsZJelMKFnfsUTihFenOAeOcThGsAkXdUdjQHfiTTJthlnedkvqHiUGGmGsoxXqLBxObNTxDFPLGJvZQhEuROXNtRSRhtlYTEXSDmILAJatwJBAWjTqnUUbQyAbBAFodgEPcix");

    for (int uiqvIPYxbr = 637795728; uiqvIPYxbr > 0; uiqvIPYxbr--) {
        YICIn = YICIn;
        YICIn = YICIn;
    }

    return -701009.9842906216;
}

int DUebvPhnl::iKFHePhC(double LAshSiKdOEsUVRBt, bool oTBOHEv)
{
    double MdIcPESdbz = -95673.19169134428;
    double CotKBxlFtOlIViYr = -979641.556650759;
    bool NdLkEIJYU = false;
    double qzgXbSFmDSbD = -530650.9040369794;
    int naEZqzTDdYNArYr = 780289126;
    string PvDVNRSYbUoOj = string("eGwItPCMSCKvJgDUtHHRqwY");
    int CEEhfi = -2097465278;
    bool vNmwiOnktDFyXoxj = false;
    bool IzWlHR = false;
    bool NrRJn = false;

    if (naEZqzTDdYNArYr <= 780289126) {
        for (int MATNCPamBe = 917348235; MATNCPamBe > 0; MATNCPamBe--) {
            NrRJn = NrRJn;
        }
    }

    return CEEhfi;
}

bool DUebvPhnl::kSSiJTkCASwX()
{
    string EICHJ = string("BoJLDSXaTMcfJVAWuUrOeToDwSToGcRocdsswrbPWjVUaYsYcZUWpCOLrOOZNpjsKaLhzJHhtCKepEbpcYWzAIDotruGcvAFGXHEUeOVaWVBrvzQfUSqoTElXKrkzXIiUWfhubvLuihEfeJXwofAwlUxvJiJZGMGepSIaEKgVtdIRZmiQfJz");
    double KMeZElxfXoZ = 770848.0082514401;
    string RXlYSnMJolUTN = string("bZWsnZSPfukXVyzOaxnHMGSDknQDTTPzQVTnmhfNZXrwrKwLmvHLBkARKXSAIvrfLfxJIFAhoehTZPhbaBhjIDyNMyELbwGDYZbjIXdkVfYFgzQgcZUvaphxUIjiQWzuMoEYAveYPZvJlAdCQNvc");
    bool rbrhoKRVQFBI = true;
    int RroBjFsQ = -334180705;
    int EJaUZVB = 1895743092;
    bool QbJhLpoGkPhwsT = true;
    int OqkGwXExhO = -1272697548;

    for (int RDrzJLoeX = 1332318668; RDrzJLoeX > 0; RDrzJLoeX--) {
        QbJhLpoGkPhwsT = ! rbrhoKRVQFBI;
    }

    for (int mWRvIGw = 1337888356; mWRvIGw > 0; mWRvIGw--) {
        continue;
    }

    for (int RBWrC = 1107697648; RBWrC > 0; RBWrC--) {
        OqkGwXExhO += RroBjFsQ;
    }

    return QbJhLpoGkPhwsT;
}

bool DUebvPhnl::YarWw(string kVwrUYtV, string KkVxiKgsuqfHo, int ozDRzzuXbCN, int RAXwDxVvaHES, int IykYqCRi)
{
    bool AwhLMkRftmiRL = true;
    bool ibycrB = false;
    string MKNKrgQMtO = string("vYVFKBqWOtzBdftbNGSQtAmKHxQXrQuIaLuBlAxVTKpwpvCojTOYCfUFGypnIWvoaweHAaBMUFcTzDZ");
    string LdgANjTarijMFB = string("qCuOpGYRgffXsqQgJUhVHPFHmyAacCnSJlZUPEekFZPpNpYGwZbrkLOQQamWUqxkUwKJDfypEuNwJaTGnwRKyZCqfZCpoEIhUuFhDAgBiEMpOXzJdlvhHqNPquxXggugkeCTkwYUMPcH");
    double bbWQdJo = 376951.8232447815;
    string zyEAHpnHj = string("wYBKGxJBopaqkKWvTKSJmDJOLtsmnZtBvOblKLBvRlnmYvKWlg");
    int tMrAPlCterx = 1714753376;
    string cRxNdLXVmKBhtB = string("uKqPUsg");

    if (cRxNdLXVmKBhtB < string("vYVFKBqWOtzBdftbNGSQtAmKHxQXrQuIaLuBlAxVTKpwpvCojTOYCfUFGypnIWvoaweHAaBMUFcTzDZ")) {
        for (int aRkAVzn = 2132069110; aRkAVzn > 0; aRkAVzn--) {
            continue;
        }
    }

    for (int PbcmXpFO = 1377030279; PbcmXpFO > 0; PbcmXpFO--) {
        continue;
    }

    for (int JQrrlgUyWTS = 2003590317; JQrrlgUyWTS > 0; JQrrlgUyWTS--) {
        cRxNdLXVmKBhtB += cRxNdLXVmKBhtB;
        tMrAPlCterx += RAXwDxVvaHES;
    }

    return ibycrB;
}

string DUebvPhnl::ZvFSczYeyZkPomhR(bool gICvcH, double NbbIMSA, int DsdgBmcSHEFB)
{
    int nbGvdQCkufsNNXb = -1289536348;
    bool bbBaelZUyyNcKiG = false;
    bool YtqhDR = true;
    bool yfKPA = false;
    string mKfGOPrgfTPP = string("FWtUgnCGzAtOtiPKnitmeRUpxzNDOESfaDYyaDKUVRRqRBjmUVeqWyQIGUDSeJVDLdcETamKqGBanYGtGrGsYFAsajDFrELTExyVuIEsitTRpWjDfHAwloqWNCDctMVChrvev");

    for (int LtvfUeGDgLmWFoa = 850149071; LtvfUeGDgLmWFoa > 0; LtvfUeGDgLmWFoa--) {
        bbBaelZUyyNcKiG = gICvcH;
        yfKPA = YtqhDR;
        YtqhDR = gICvcH;
        gICvcH = ! bbBaelZUyyNcKiG;
    }

    for (int hOVKjbWZnjeV = 1107729219; hOVKjbWZnjeV > 0; hOVKjbWZnjeV--) {
        bbBaelZUyyNcKiG = ! YtqhDR;
        YtqhDR = gICvcH;
    }

    if (gICvcH == false) {
        for (int TgNfZOmBXPlzSGR = 1205875726; TgNfZOmBXPlzSGR > 0; TgNfZOmBXPlzSGR--) {
            yfKPA = ! bbBaelZUyyNcKiG;
            bbBaelZUyyNcKiG = bbBaelZUyyNcKiG;
            bbBaelZUyyNcKiG = ! yfKPA;
            bbBaelZUyyNcKiG = yfKPA;
        }
    }

    for (int kEPUlaBccXKhHb = 594763217; kEPUlaBccXKhHb > 0; kEPUlaBccXKhHb--) {
        yfKPA = yfKPA;
        NbbIMSA += NbbIMSA;
    }

    return mKfGOPrgfTPP;
}

bool DUebvPhnl::ZzkaIAvLgsOgqL(int bsLzFbCxYedXLKu, int QxABVIWyA)
{
    double hlqGVEmICIXXNqK = 434966.0853456775;
    bool plogrhdE = false;
    double eiOtFfDJVI = 858748.4107035034;
    int JHxOZW = -969544694;
    bool WPotSOfISfG = false;
    string YFpwAkz = string("vnHReuChIENPmKUTWxcDpNoVCAbQFnqgMTRhXkF");
    int gIrfIfMMcwzOu = -2043368464;
    string KTwTUG = string("noquyHsZadaLpXCBNcuKgoblfvsMPofqRfQOmZMpptRdoYxeiedQdJzGbWipoDxWJNnGySyDVmbKJuBbgjeGFqwGxXMTvSkUUaWLEfSAyGgIk");

    if (bsLzFbCxYedXLKu <= -2043368464) {
        for (int BGQIOhkb = 1697383324; BGQIOhkb > 0; BGQIOhkb--) {
            JHxOZW -= bsLzFbCxYedXLKu;
        }
    }

    for (int MGGpQY = 643038503; MGGpQY > 0; MGGpQY--) {
        gIrfIfMMcwzOu /= JHxOZW;
    }

    if (QxABVIWyA < 344410205) {
        for (int OcZHxQgyq = 1630747068; OcZHxQgyq > 0; OcZHxQgyq--) {
            QxABVIWyA += QxABVIWyA;
            gIrfIfMMcwzOu *= bsLzFbCxYedXLKu;
        }
    }

    for (int rutghqMJWb = 880396350; rutghqMJWb > 0; rutghqMJWb--) {
        JHxOZW += JHxOZW;
    }

    return WPotSOfISfG;
}

int DUebvPhnl::XreEZ(bool jgWpeMV, string BxgTKOcRpoO, string oOrzzCujbUr)
{
    double PwxNefnueOcCoDaA = 61387.520126358984;
    double pebxkXVAhK = 209156.4507739538;
    double fXoJS = 835137.3422448726;

    for (int BoOxC = 224705653; BoOxC > 0; BoOxC--) {
        PwxNefnueOcCoDaA -= pebxkXVAhK;
        pebxkXVAhK /= fXoJS;
    }

    for (int JwPFvJZ = 1224226833; JwPFvJZ > 0; JwPFvJZ--) {
        fXoJS *= PwxNefnueOcCoDaA;
        PwxNefnueOcCoDaA = fXoJS;
        BxgTKOcRpoO += oOrzzCujbUr;
        pebxkXVAhK -= pebxkXVAhK;
    }

    if (PwxNefnueOcCoDaA <= 209156.4507739538) {
        for (int DrGBEoMdoaap = 1678841319; DrGBEoMdoaap > 0; DrGBEoMdoaap--) {
            fXoJS = fXoJS;
            PwxNefnueOcCoDaA += fXoJS;
        }
    }

    return -176112440;
}

bool DUebvPhnl::eExsVGhfDdMYCKas(bool bnPxPARyfnRWFN, bool BRZdsrOfxXNAdlr, bool AnyKH, string RwvCorvx)
{
    string fUymRdpSxMx = string("UUuUajUWPOXgLnwUMvLcWynIisiuLGSLMGfQTceuRJNhkvFbfgbowCGLFQtcHNVRmlnOJtff");
    bool zczZhqgeVnAIA = false;
    int BGQBVHlPaZxWWFKe = -1471869842;
    string AADnuDzcCIQIfmga = string("nwJuVaguTjHYKQrASwSgiaQNLoJscfRqPJBGDeJrnxIWElwvEij");
    int EIqnKwqKzh = 1372274132;

    if (AnyKH != false) {
        for (int aniPhxIFBQsr = 577416520; aniPhxIFBQsr > 0; aniPhxIFBQsr--) {
            BGQBVHlPaZxWWFKe -= EIqnKwqKzh;
            AnyKH = bnPxPARyfnRWFN;
            AADnuDzcCIQIfmga = fUymRdpSxMx;
        }
    }

    return zczZhqgeVnAIA;
}

bool DUebvPhnl::HXirLNyaFgw(string bMYoWMXA, string tiSWNp, string ZCGNSoLibEWpt, int dIokWscgsDbuUsYX, string fcDmoZdaffjjMl)
{
    int ALdqPnKxd = 84368118;

    for (int VSYcPDiiqzlmwTuT = 444036525; VSYcPDiiqzlmwTuT > 0; VSYcPDiiqzlmwTuT--) {
        bMYoWMXA += tiSWNp;
        ZCGNSoLibEWpt += bMYoWMXA;
        tiSWNp += bMYoWMXA;
        ZCGNSoLibEWpt += fcDmoZdaffjjMl;
        ZCGNSoLibEWpt += tiSWNp;
        fcDmoZdaffjjMl += tiSWNp;
        bMYoWMXA = ZCGNSoLibEWpt;
        fcDmoZdaffjjMl += ZCGNSoLibEWpt;
    }

    for (int QcImowkglac = 691276855; QcImowkglac > 0; QcImowkglac--) {
        dIokWscgsDbuUsYX *= ALdqPnKxd;
        bMYoWMXA += bMYoWMXA;
        bMYoWMXA += ZCGNSoLibEWpt;
        ZCGNSoLibEWpt += ZCGNSoLibEWpt;
        fcDmoZdaffjjMl += ZCGNSoLibEWpt;
        dIokWscgsDbuUsYX = ALdqPnKxd;
    }

    return true;
}

bool DUebvPhnl::OOADXldHcYtsBoO()
{
    double TnFJcRbvuWsNS = -193813.02605577902;
    int ffYCx = 1315198707;
    int kiGOBeHRVkJa = 1549924643;
    string nvYJYQszlkFi = string("WZbQKjldwuBWYGlnasOnJnCwQkudHTQxBEaOof");
    double JapjhWQGwfytgGLb = -586692.1328567633;
    int WCogaveQUhch = 399639176;
    int IiFoGqYHqwwSt = 1248669877;
    double HoCfXzUSE = 917469.2930739155;
    bool OBntBJDsSXSA = false;
    double FmRlYuDLj = -528293.6086545292;

    for (int fiLMdslDpjOXL = 175844776; fiLMdslDpjOXL > 0; fiLMdslDpjOXL--) {
        continue;
    }

    return OBntBJDsSXSA;
}

double DUebvPhnl::vKHYIZRAUs(double qANBqBFf)
{
    string eXZomGnfBF = string("DugBVOkmMqT");
    int DUqiNVASj = 1179726198;
    double TwYehefZ = 865541.891705865;
    double QKifLdWQVRc = 549331.3197574344;
    double kyZCHWdyDk = 848055.0385239143;
    int uylYmmPAF = 1563011049;
    bool kthhatCgfiEklJ = true;
    string NnOeuxgywMmig = string("kqgAlYPXnHORlDoiPPxzqndtgrJgdNMamemFYutMIorUMWHNjpRoekAOeZTHlqsZMzBKVQclFkILRDTnEBFupgjZTPmWm");
    double ALwZmuTmsvshB = 844680.7325391839;

    if (kyZCHWdyDk < 865541.891705865) {
        for (int IOQCmCORrkEsehXT = 1417206996; IOQCmCORrkEsehXT > 0; IOQCmCORrkEsehXT--) {
            continue;
        }
    }

    for (int yKtUAz = 440175538; yKtUAz > 0; yKtUAz--) {
        continue;
    }

    for (int LUdVKaP = 157898865; LUdVKaP > 0; LUdVKaP--) {
        kyZCHWdyDk += TwYehefZ;
        qANBqBFf += ALwZmuTmsvshB;
        kyZCHWdyDk -= kyZCHWdyDk;
        ALwZmuTmsvshB += ALwZmuTmsvshB;
    }

    return ALwZmuTmsvshB;
}

DUebvPhnl::DUebvPhnl()
{
    this->wzCRiPrWNb(string("ZUZstITtNxTqTZQnTNYKjdqGzGpQLdwdVdCAualcdkmnbuCcZfIkHqMAMBeUUTHGPwGALcbCQWlmxXuZlTGdajChBMANSyJvYadbsrCdcFhNQTHynvVmOUYmYmgUloyzdtjFhrQbqWfLmqryBcrIWfVLIUacPyVCpxOSNjTBZwydfgsruZEicgNeCFXZaHNcTirKRqGFgdK"), string("UnSjTRkOLkglQmqIVpWnkLpqytKOyQAmLlSoEQSNRztIGgTEscPsNRHxthIjvvRQSuPowIZUH"), 738248.0605775405, string("EaLVVTmNugHXrEtEPlrxIOArwZVrOylXuQFOsqdZvAUVlvvkanuIRhgIuAdtPDBQaCvIqIxrSGhFIIiMwRIGRNrkqsBprRJeRmEAlDTclblAZKlGPajuqoMSTtNPWzXgKvfBLKxqAeo"), 1937062484);
    this->mTJvIwfrva(-453548272);
    this->pwXiqVMOMRy(string("wAQwqJ"), 1157387844);
    this->TMpoTBIiycXu(true);
    this->iKFHePhC(-173229.6800188031, true);
    this->kSSiJTkCASwX();
    this->YarWw(string("qkfcdcKhMZaTNKoozQcXgGCmrlnZdrfoyXykhAUGsOGqIxrSarhmlLYBHKCFUEmpuYEvuMWgSyrzjpVWkoMqYYCoErozimlcdJVokEnfYQgIDxTqsUYfIQWDiMqGouyekLkyddesvdgKfSKtGIjecbYKcRQgrZqKKPRGrwPICdaEvaxLeoVqjYifIaikCYIubaDfhJxok"), string("izuDwdCHRkHXXFDbYmWGLvcomtACeEgYBzTHpmFpghCsaPlKPWQpmLMiJwDvVgrDUmTWSyTRahoNnVrNbkZKPTuMlkrJCZtVjdYRvsMRuMHcRgezYidWfsvuhttQIZLlLsTjohOhfLcayfPb"), 96729281, -1048332570, 766814855);
    this->ZvFSczYeyZkPomhR(false, -997251.2158165883, -514606761);
    this->ZzkaIAvLgsOgqL(344410205, -857418459);
    this->XreEZ(true, string("XUNKRiRHvXeNcvfOXqzCHwLlFQgkcRBluCONoGOyOlLMVBhRdIWdsZAbLykGZzBBdgGHBecCjWxEKsmWZqUNInEGHXJMVDMsEETZWhPoJxKRhAXDKfyjRLWwncfHopZwdeBixFqRbyGWeGnQATZSSfDYyZvpozjpWdKNGLdMSmUfbbeIawdNrJJurrdVEOiMIxNQohSkbhbCJQmcDfVHpFZeAG"), string("Oyy"));
    this->eExsVGhfDdMYCKas(false, true, false, string("QmPjHwpBezjrcPgZTLSkmTyOyDDwUgXOUWqICyeTvyAzsmjyIPsuUWPzMPkcCRICRWApgOyrvoJcEvSsVWshsEIGiVHHoQGOpNvWIMviwDDCVxRshDtBGlDRNRTkuedeODPCYZSeQvpyBUzbAtSbyKBCB"));
    this->HXirLNyaFgw(string("vfMuslJRkpAPmeSKGMljMGqdlHsBKPArMXDeGyuPqFLJEdqUIKJSKdLBDQDaDjfoojJzVIkgvWQQYBPiYMUVZLtMfrmfITXyBsVRPvMWgxZkZDwUTcBjwwQEizPOnIHDTAmMzjMaGvDhbYbqkWOiYVfNYQaIELHJpogqstpfAzprDQfHjoJyvkOAzKFL"), string("GLFLYhIHOFUBtkfhuiKBgdlshQcIEXQRZCrsaFxdlPAmgYnizLfIydpNAtqyPidieXAMMveIeevEPqmgbIgosicXnUrKIdSWVqajAqxDQTQCCXyfRmJLdsLILIYjvUHlIsGXknicEemXXWwmENhfenimwOVSQaOfdjAvnezWrJJoxLkANbIHLsopFyyLeclrbJexgnimdcAbiAhSPLVTVtZKCVFbHFtRdrBWl"), string("tJBYOdqfymDyqaOUGYXisgPAaHkhTjXJKFnfOncNhvyPOkKAiPmUDMTeGJZDyCYBpWqDvvWWMpttbYaSffTRTNERgzKqZiWuDwbUuSEVgXSDOKXejmPVQweMghtapulIGdnqCcbyKCfeZLCRqlCFrHyASYOIzmEIBFFkOhTeJpWaAWnqAWBCASmyxUcXNCfxtNDi"), -679982755, string("SAGIiYhbXMEKPvUkGXyMEMOHfrycgmNAXBNMmhSEJQOVRQFnNdCZJmEBrCPRchWtOjRdFBAqkiZHZznmLBLXASbarMtYtIdyWDoQUbBtFIOSowhfMUdIoIvPEoyKrYfvZFWxFbBhKagbTNAvcOPfkNvjOGdnoQbcAdHVFUhfVrVHHvDhecZUyQDHJAxxwXeQoWinVCzRlIOrcNOnsOcDidcj"));
    this->OOADXldHcYtsBoO();
    this->vKHYIZRAUs(324860.54104175366);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cLznzRQEp
{
public:
    bool SpXvnEpjIUMqWohG;

    cLznzRQEp();
    string lfcOE(string whbMAIyZs, bool svxEYK);
    bool siUuYhaEh(double jdCtgtra, int UvFMOFWQwnb, string UJKjoKnzbXgPbrE);
    int lBVKLBdnDzmLwQj(string AJLRIvUfLfCxXEDo);
    bool XCTmes();
    void iVEYMLFgvbi(bool nLLdHLTCwr, string LvlrI);
    bool dGskhCWFjiaBUw();
protected:
    bool EspiTXRgip;
    double PjIByUL;
    double ywImVfTtXaujRF;

    void julUjDQFuCBlz();
    string EjjJhlvnrGFqsU(double BCXguFMGpaDXvSaw, bool FdexmNgVXKKUnmM, double KjKqOKDd, bool EmBWqXjccJD, int vbmwRYqw);
    bool RZGsTw(double zZEWgmWvNpw);
    bool oRwhKTyBiH();
    bool iaXTmQCNsSKpZ(string jfnmGOhBbCJOv, double JiwwrrLEXaIEpcXc, int lWaUuAf);
    string gCGUDWnZCTPtZ();
private:
    string pVoFifyR;
    string LmQKZ;
    string aIkOMmizJStz;
    double ltbXtYdn;
    double gGTnMN;

    double BLpPQYn(double UBgSJVXXBAZ, bool sfhIUrhsuSOWXiu, string pNTCCFP);
    string fqYAsmPfB(int PAazUa, double cHnnVaelmxgvIq, bool bNfTsHbXid, bool gDJaxhmPMf, int pndAcZtYbSmjKjV);
    int ZjxIahVOxdyznJ(double jAHuAmkYeVcZllDK, int IpSJPeWkt, bool wveVhLqEPFd, string pqzPeObtqZCaDV, bool uUJDGoc);
    double mFnAsRHNUwVYRT();
    bool BdztIEtV(bool fNtPl, double sHCateoUjNDvwCFC, bool OvcZeQWC, double qNlKzoiTga, bool vooOZsk);
    bool rYauvHn(string sxidgqeo, bool yLvIYhFUzcZuJa, string HwuginCpaaRq);
    bool kwNUFGCBLY();
    bool gyznCLSWvPfU(bool HqzkyJmcweBMr, string bJWwDajQFwcsjko);
};

string cLznzRQEp::lfcOE(string whbMAIyZs, bool svxEYK)
{
    bool vRASpCM = true;
    int yQNToC = 1168686061;
    string IcHYA = string("nGqEREjSxBBGlNmSzBEulgSiIvSHdkG");
    double DIzBfzC = 288700.91263359477;
    string laCeaqMCXEoiBTX = string("NUWCpDlexGcNUQyRIimhoYgSqTfbBixJrMuwlOAWtBgcHJnEHKSituiRhsTGLSXKIPzfffUujlxnPgzZykwmuQckBDrxUwyOvKyqwhSSJkwyaawypLCZjoUzoubrugEJofRZmGfuftSapRHJhASCEZQjqpfOlYhLKUaeQThttabalnnpZuuXeODwGj");
    int RmdLIyIHIu = 2092587666;
    double KzSaWhkMqZ = 443121.7570448248;
    int ksoxZrWjABdTL = -1172821749;

    if (IcHYA >= string("nGqEREjSxBBGlNmSzBEulgSiIvSHdkG")) {
        for (int nWRYpUiKgDf = 1273380445; nWRYpUiKgDf > 0; nWRYpUiKgDf--) {
            laCeaqMCXEoiBTX = laCeaqMCXEoiBTX;
        }
    }

    if (RmdLIyIHIu >= 1168686061) {
        for (int yeouGktDtu = 1112660014; yeouGktDtu > 0; yeouGktDtu--) {
            continue;
        }
    }

    if (laCeaqMCXEoiBTX != string("tIodCcbVpRYfNatDdheewEjNfIUJphpuvYZfiyHXUOnptjmckZcsFlBLJBCxstuhzvTOcMEjUKYAeBRWKNlLHNGOROtwQcYDSbdXqVwRYMqrJgASvSkIgrifbyJEwtdztFdQzDizoZDoHPmcOWMgjyEjbEznfNBaNriLVRuFnzuWNxpwvDBmgAIpuxKUrSxqVDneVxiUZLnsqeNVNHMzZbdbvjKCY")) {
        for (int lrUWaXrC = 1544814619; lrUWaXrC > 0; lrUWaXrC--) {
            DIzBfzC += KzSaWhkMqZ;
        }
    }

    for (int DdOrE = 1477702643; DdOrE > 0; DdOrE--) {
        laCeaqMCXEoiBTX = IcHYA;
        RmdLIyIHIu /= ksoxZrWjABdTL;
        RmdLIyIHIu -= RmdLIyIHIu;
    }

    return laCeaqMCXEoiBTX;
}

bool cLznzRQEp::siUuYhaEh(double jdCtgtra, int UvFMOFWQwnb, string UJKjoKnzbXgPbrE)
{
    double uuvBwlZEMGx = -345842.735970444;
    int zjJfshbSoVMspRF = -1668476088;
    string bIauRqNVfTEqoeAt = string("xUQZEhTKVGWEOHrgtfkuZnJgbhWcJbMATdkzSlBFiWaxWAYgxVZnNnbYRHasWWGWhRpWEgfBCIhDtpXVLClEBqnLLNFEfVyRXnnsBHaUmSvOWzEMQXDoYHFwODKtOwXplYzLeOwhbykEIxCVTesyeLekddmOFDunnQGsZydUYHPeecnXNpTJJeiMCUMkCypPsqoUlFeOZtcztiePbXROZyBUoRPwIbEnnz");
    string eyilULSzfPtjGSuH = string("gTAotApcDhYqccuAzgGQQmunmTIYAoLNAtRvPFIaYpIiblAnKcFZfwxqRflcsucqqKbfuVPljwCgpunuCekNNbemDvErKEkCkrWnhjBDdYLewNJfyOCaApBnLqNnXjsYhVCiRkziTAPdzYPoizVVxBckrQWaIAFmTsNqcwBxLHTVPFqtBEaKOyTBbfxzNUUCYCBslaFenWbRARjBBnPxEBcQOCAFZswbCEuzEIlJuOnZHJOcJVgURggeyjrY");
    string yEwUdheiZSQTPYbe = string("vnkPMgxxvZpmEzZBmaJsvjtkIdLDcioiNPUchLeenvhIueYxDLSENgmgQRUhWSh");
    int hzqnXeciSi = 449256239;

    for (int KyOUCjRxzk = 649838847; KyOUCjRxzk > 0; KyOUCjRxzk--) {
        bIauRqNVfTEqoeAt = yEwUdheiZSQTPYbe;
    }

    for (int GicVQw = 370799868; GicVQw > 0; GicVQw--) {
        continue;
    }

    for (int FPQsObviSh = 894670318; FPQsObviSh > 0; FPQsObviSh--) {
        continue;
    }

    return true;
}

int cLznzRQEp::lBVKLBdnDzmLwQj(string AJLRIvUfLfCxXEDo)
{
    double jQAXUnL = -443922.5304759955;
    double ltGVxtsiOcHkTQ = -517317.9283950298;
    double sGdvBeR = -217645.6242344339;
    string VZthigGxgio = string("iGOxaxPsybDmMLrigPDgmoWNiRjKmYDLvnCFFPNwusrqRQEwZTAOIwXLvytTvKmEYNFSaMwksrpDtakPamcQGVeHQKsaSwrCfVvqEqqfrMvVnWlUDqVpcTaTKmropSwIbXaNjLIwziuaCFKjIuGGVAPUVbNimBHmNhOOToPBvmFqhiwXSWiYAULOlQOgsxvWsxVNWFCNRITFKOSDZhailqYWewsxqwMaEtH");
    string PJtUACbrb = string("vemrXEUBMLdPRcJWQwKlEcAULBIrPjPkFDHAIesMoou");
    bool nJvqoWjrRHghcE = true;
    double cdWiEMvyyklz = 347877.98047584394;
    bool rSNQW = true;

    for (int NUFfxDGxxY = 91350218; NUFfxDGxxY > 0; NUFfxDGxxY--) {
        continue;
    }

    if (sGdvBeR < -443922.5304759955) {
        for (int OfMiagvwYoKZbXP = 662724465; OfMiagvwYoKZbXP > 0; OfMiagvwYoKZbXP--) {
            jQAXUnL *= cdWiEMvyyklz;
        }
    }

    if (cdWiEMvyyklz <= 347877.98047584394) {
        for (int bVawSdaAhLk = 607000985; bVawSdaAhLk > 0; bVawSdaAhLk--) {
            cdWiEMvyyklz -= ltGVxtsiOcHkTQ;
        }
    }

    return -1194586366;
}

bool cLznzRQEp::XCTmes()
{
    double fxfytX = 734465.0677630645;
    string XwLetwwrptDUmhBJ = string("OOInARDtyYxPNYsAHJmljwEeWDegswsODZaAipbUtjVLZqMDpGfOdeaOkaOUbycyHBShLstXKGZOShjrzygGkSgXUgvSctBTmcNEKZLuqDYr");
    int KEZQBiNXKJ = 1447237570;
    int ZkPSYXhADD = -1301876912;
    string BldhiVdCCJ = string("BYexrxZRIXweoMeLKQuqndKRvEOvlsXAzchVQTHSSoZkjNUqzXwguRurrkuHngrEKnmrSGVhCvrmQRzqGNJzROHJJwjhPjtUjDM");
    int mZHhH = -21425978;
    string mRUTCqWecAIurrz = string("LLgrJLfUYjpUXCgNVVpLMJVNHeIdgcytqhZNxbRLvmHouEZfIwquuoNOjXzRAEsKxgjemyiqMjqQszvkikuPMdTzsIWWzLbTyLeDUtsHAFUufYgDCPTuBpSuFPWOEHnObjLZQhQnvAMCViQahmKozUbnvWdXPCXhqXSgZopPKcfXcrLnPLqqdDjblsTyDJUuKLhXiLgfSuAtBeHavEKqiKmkf");
    int LjPLYyTFgBSVcuB = 1051971822;

    for (int HdCVJnHwbTFey = 353762618; HdCVJnHwbTFey > 0; HdCVJnHwbTFey--) {
        ZkPSYXhADD /= LjPLYyTFgBSVcuB;
        XwLetwwrptDUmhBJ = mRUTCqWecAIurrz;
    }

    return false;
}

void cLznzRQEp::iVEYMLFgvbi(bool nLLdHLTCwr, string LvlrI)
{
    int NKEwVGRGbjBhHpTW = -106485618;
    string wPZVptAM = string("zBxDyeOFVijRpoeZujLwTTewRf");
    bool UwnVGhD = true;
    string qVesmSV = string("uUuYQQFfRRaMxhaVCHDRpJnDLgTwyQXmngyNWMBcggal");
    string WKDrKABYlXk = string("ZboFowlhVJlkEyRNLUn");
    int WvfkbBadxuqdQG = -1487809026;
    double gPQAVfKw = 525093.6974453147;
    bool kAzHAv = false;
}

bool cLznzRQEp::dGskhCWFjiaBUw()
{
    int eGedBeCgkoD = -677697485;
    bool JdwyoCIyJocvw = true;

    for (int disjELZ = 998074049; disjELZ > 0; disjELZ--) {
        eGedBeCgkoD *= eGedBeCgkoD;
        JdwyoCIyJocvw = JdwyoCIyJocvw;
    }

    return JdwyoCIyJocvw;
}

void cLznzRQEp::julUjDQFuCBlz()
{
    bool BsYdrLYwroodtu = false;
    double bReyfweCgBtfE = -483075.87075305934;

    if (bReyfweCgBtfE < -483075.87075305934) {
        for (int DeEAXTwSSfMt = 150016625; DeEAXTwSSfMt > 0; DeEAXTwSSfMt--) {
            bReyfweCgBtfE -= bReyfweCgBtfE;
            BsYdrLYwroodtu = BsYdrLYwroodtu;
            BsYdrLYwroodtu = ! BsYdrLYwroodtu;
            BsYdrLYwroodtu = BsYdrLYwroodtu;
        }
    }

    for (int rMXJTV = 534800264; rMXJTV > 0; rMXJTV--) {
        bReyfweCgBtfE += bReyfweCgBtfE;
        BsYdrLYwroodtu = ! BsYdrLYwroodtu;
    }

    if (BsYdrLYwroodtu != false) {
        for (int gSMQkYMr = 853512775; gSMQkYMr > 0; gSMQkYMr--) {
            bReyfweCgBtfE -= bReyfweCgBtfE;
            bReyfweCgBtfE -= bReyfweCgBtfE;
            bReyfweCgBtfE = bReyfweCgBtfE;
            bReyfweCgBtfE /= bReyfweCgBtfE;
        }
    }

    for (int CqnEDZYPKCZtXoPc = 1304645472; CqnEDZYPKCZtXoPc > 0; CqnEDZYPKCZtXoPc--) {
        bReyfweCgBtfE = bReyfweCgBtfE;
        BsYdrLYwroodtu = BsYdrLYwroodtu;
        BsYdrLYwroodtu = ! BsYdrLYwroodtu;
    }

    if (BsYdrLYwroodtu == false) {
        for (int RfUxSM = 907377338; RfUxSM > 0; RfUxSM--) {
            BsYdrLYwroodtu = BsYdrLYwroodtu;
            bReyfweCgBtfE = bReyfweCgBtfE;
            bReyfweCgBtfE *= bReyfweCgBtfE;
            BsYdrLYwroodtu = ! BsYdrLYwroodtu;
            bReyfweCgBtfE += bReyfweCgBtfE;
        }
    }

    if (bReyfweCgBtfE == -483075.87075305934) {
        for (int QQLXFefvqQBIf = 1546849341; QQLXFefvqQBIf > 0; QQLXFefvqQBIf--) {
            BsYdrLYwroodtu = ! BsYdrLYwroodtu;
            bReyfweCgBtfE += bReyfweCgBtfE;
        }
    }

    if (BsYdrLYwroodtu == false) {
        for (int XhqenXl = 780108341; XhqenXl > 0; XhqenXl--) {
            BsYdrLYwroodtu = ! BsYdrLYwroodtu;
            bReyfweCgBtfE *= bReyfweCgBtfE;
            bReyfweCgBtfE -= bReyfweCgBtfE;
        }
    }
}

string cLznzRQEp::EjjJhlvnrGFqsU(double BCXguFMGpaDXvSaw, bool FdexmNgVXKKUnmM, double KjKqOKDd, bool EmBWqXjccJD, int vbmwRYqw)
{
    int JumDRwBhdHBqVD = 193502643;
    int RDYiaQdDMBB = 336034772;
    int INXiJnXX = -1955096973;
    double lcjGvMpEglNTNhm = -482838.75874992233;
    bool AtVyGQqJXEFbGY = false;

    for (int inDEIbAjWqSUIn = 1183927529; inDEIbAjWqSUIn > 0; inDEIbAjWqSUIn--) {
        continue;
    }

    return string("MdxweSRkkRHWVqvvaQXqnGkPBnvbGSftBUQrdmiQxMyApVzdhSwbmHazxmCIgTQMhPHsoybTyUNS");
}

bool cLznzRQEp::RZGsTw(double zZEWgmWvNpw)
{
    int GfKbpZlJoGxzMi = 1510451930;
    double QawCDUMH = 1024243.5695930916;
    bool GDGOsRXMDhCv = false;
    int esWvqzmQY = 1347974130;
    double xoqGmwNHPxlycP = -247243.84905040433;

    if (QawCDUMH >= 1024243.5695930916) {
        for (int pIIazpxZqMyrjml = 1766785333; pIIazpxZqMyrjml > 0; pIIazpxZqMyrjml--) {
            zZEWgmWvNpw -= QawCDUMH;
            zZEWgmWvNpw = xoqGmwNHPxlycP;
        }
    }

    return GDGOsRXMDhCv;
}

bool cLznzRQEp::oRwhKTyBiH()
{
    double MuMTyK = -81138.84013480652;
    int EFbahqUa = -859157803;
    double IOPMRiu = -599424.6326980196;
    bool UOXivTLv = false;
    bool nBCThTyhYz = true;
    bool WRaFVomcZM = true;
    string vOrNWsiHXDcP = string("KGkykXWzZhuiCTqtawGeaIWJgkeyAriWmQPWUvzWwjrMIywUEjUOTwbBPVKmJAyPXcBYourmKnMyhJHQvjTQlZoTKkaxirIrbaFYMMpcfzbjvWchPOBNxbLWuLAEpWkXYMwHBwZyaMBxJlDaYrKYGxVPKVytqvmVqecwUeonlmvCBsGiBBTXLqNhrtgaHGExWezugNXubDPQpHlPerRZV");
    double UtLDRl = 506921.84033818834;
    int btbPehuuusFYsN = -1831358226;
    string CIUKKYNYBIdZ = string("bMkHIdNrNhyEyXLKuvupSYSLJoBmRRbgEmQElKdiVQMCBmEXZeBvQrXnNEaKzUCMvqgASKGEkZUConXqhHljPCaCmoQEEnMFVdcDxQRAjyvSFEdHkQePmVzHQwoG");

    for (int lCxVGz = 418503477; lCxVGz > 0; lCxVGz--) {
        WRaFVomcZM = nBCThTyhYz;
        MuMTyK /= IOPMRiu;
        MuMTyK = MuMTyK;
        WRaFVomcZM = ! nBCThTyhYz;
    }

    if (IOPMRiu >= -599424.6326980196) {
        for (int BbViUOHg = 1729585438; BbViUOHg > 0; BbViUOHg--) {
            btbPehuuusFYsN /= EFbahqUa;
        }
    }

    return WRaFVomcZM;
}

bool cLznzRQEp::iaXTmQCNsSKpZ(string jfnmGOhBbCJOv, double JiwwrrLEXaIEpcXc, int lWaUuAf)
{
    int EkfmZtqzqQYL = 89194487;
    double cgqkmlHttaMWhr = -805994.8589054235;
    int neAUDxaOix = 887756474;
    double MJaccy = -725982.430839822;
    string azPTP = string("kOdgfeaaOsPNNmmDTmLRolWWmPopK");
    string RLmXUdD = string("zBuBojUVhuxzKUfHruHFvPpqCAsnfSyuvAZhkHeaZHruevgSOxnMoCHaWapUJrbbuqpauWxGbqAhnldaUYwYDcvIVtEEycnGADIkUrYljiRoqhfVHUsnTCIdWYIVzzhFIFSsTRKOgPSYcZXvSrDNxfdhvcNbJhjlrE");
    bool mlfUad = true;
    string QIdxbCmdf = string("uAPwMAdiZlterKdVttYSyjeLOjYOgyAskLFVoEjdxnLpoaWOiLBlIEvXwpyYGQi");
    int XAwWLLvgwtjcb = 31569930;

    for (int vokDroOOEwKra = 1399727839; vokDroOOEwKra > 0; vokDroOOEwKra--) {
        JiwwrrLEXaIEpcXc -= MJaccy;
        RLmXUdD = azPTP;
        jfnmGOhBbCJOv += QIdxbCmdf;
    }

    for (int zUgSooX = 1991367637; zUgSooX > 0; zUgSooX--) {
        continue;
    }

    for (int qKgzbQyjzTZvdc = 1071356727; qKgzbQyjzTZvdc > 0; qKgzbQyjzTZvdc--) {
        azPTP += QIdxbCmdf;
    }

    return mlfUad;
}

string cLznzRQEp::gCGUDWnZCTPtZ()
{
    int DqjDB = 1548332262;

    if (DqjDB != 1548332262) {
        for (int GVHzQMyC = 1694554354; GVHzQMyC > 0; GVHzQMyC--) {
            DqjDB = DqjDB;
            DqjDB -= DqjDB;
            DqjDB /= DqjDB;
        }
    }

    if (DqjDB > 1548332262) {
        for (int fKRSQsNS = 1420032932; fKRSQsNS > 0; fKRSQsNS--) {
            DqjDB = DqjDB;
            DqjDB *= DqjDB;
            DqjDB /= DqjDB;
        }
    }

    if (DqjDB <= 1548332262) {
        for (int OATEwGpzuAUwp = 783495481; OATEwGpzuAUwp > 0; OATEwGpzuAUwp--) {
            DqjDB = DqjDB;
            DqjDB *= DqjDB;
            DqjDB -= DqjDB;
            DqjDB = DqjDB;
            DqjDB = DqjDB;
            DqjDB *= DqjDB;
            DqjDB /= DqjDB;
            DqjDB -= DqjDB;
            DqjDB = DqjDB;
        }
    }

    if (DqjDB >= 1548332262) {
        for (int kXgmTxhotBrp = 937340206; kXgmTxhotBrp > 0; kXgmTxhotBrp--) {
            DqjDB += DqjDB;
            DqjDB += DqjDB;
            DqjDB = DqjDB;
            DqjDB += DqjDB;
            DqjDB /= DqjDB;
        }
    }

    if (DqjDB >= 1548332262) {
        for (int RiPEfQ = 940035995; RiPEfQ > 0; RiPEfQ--) {
            DqjDB -= DqjDB;
            DqjDB += DqjDB;
            DqjDB *= DqjDB;
            DqjDB -= DqjDB;
        }
    }

    if (DqjDB == 1548332262) {
        for (int LHLcJBvzc = 415570890; LHLcJBvzc > 0; LHLcJBvzc--) {
            DqjDB *= DqjDB;
            DqjDB = DqjDB;
            DqjDB -= DqjDB;
            DqjDB = DqjDB;
            DqjDB *= DqjDB;
            DqjDB = DqjDB;
            DqjDB = DqjDB;
        }
    }

    return string("MwoHBjuqVnZSsCqekaVGJZezRxdQHpeikOwHoODPaQIoSXJVXUvUaDSUrCagwTUDiKmzRELoExCtYoKdkgJLBcvGfNVBGGlvNRYBYZsFHzWpINmWMlhnBuvpZKXNBAhNEslHlNgwMLsNPWLaocmQVPcwxXYyQnEnx");
}

double cLznzRQEp::BLpPQYn(double UBgSJVXXBAZ, bool sfhIUrhsuSOWXiu, string pNTCCFP)
{
    double UdZHhF = -155315.37180200743;
    bool BEfExCTjmJTvH = false;
    string fSweSwhEMpGSn = string("wRLpHBRSkpipVvywQBCyV");
    int qxLmIjgb = -114400452;
    int cZYDKCiBRNLeF = -1211271774;
    int znRlJetaD = 1563905621;
    int uQxeNwuLiQ = 21225911;
    string RhTQwUbPkpOIq = string("htaUxiUleoFiOmdeRNLKvtGSKLXhPPhFAZmLWYhuyRleunfCBSVClaMnQUjuGaCyFzFsEqmcEzFAhPGbOGNQlgemtKXATbMpJUAYTTFiJMJEEVBPQjMlFWQSZBNkwcDWgSeykXoeJZVYwcFZthNWBZmsKrIMrhpxtKyLccUUCiFbYRCquuOaLJxsUcatsSLmHaKenDsUHZhuKEQluZjpaJjHUgfLYQpwquuISewB");

    for (int pMoxNK = 1909236982; pMoxNK > 0; pMoxNK--) {
        pNTCCFP += RhTQwUbPkpOIq;
    }

    return UdZHhF;
}

string cLznzRQEp::fqYAsmPfB(int PAazUa, double cHnnVaelmxgvIq, bool bNfTsHbXid, bool gDJaxhmPMf, int pndAcZtYbSmjKjV)
{
    string RAlkPRQRvsqo = string("cUqRUsEEJFYgMCSpDBWIrwTRfDjYYVeqwYqEuWYSDnmbLWFVgBQPcxtVYiMLitKGBOcSwyogkAIHAuinDHGOSGjJnFiYgEnZjWdVJGZzyJMCcMvOsmvGfcKuLJWeLz");
    bool LRQZzZSZUBm = true;

    for (int BwWgoYMoySyR = 200545091; BwWgoYMoySyR > 0; BwWgoYMoySyR--) {
        continue;
    }

    for (int oCvcxhNmo = 366974385; oCvcxhNmo > 0; oCvcxhNmo--) {
        gDJaxhmPMf = bNfTsHbXid;
        bNfTsHbXid = ! bNfTsHbXid;
        gDJaxhmPMf = ! gDJaxhmPMf;
    }

    for (int XvsSAofuwwTXQXL = 1115438169; XvsSAofuwwTXQXL > 0; XvsSAofuwwTXQXL--) {
        LRQZzZSZUBm = LRQZzZSZUBm;
    }

    if (bNfTsHbXid != true) {
        for (int sfPuDRxjCXfG = 2094440248; sfPuDRxjCXfG > 0; sfPuDRxjCXfG--) {
            gDJaxhmPMf = LRQZzZSZUBm;
            pndAcZtYbSmjKjV = pndAcZtYbSmjKjV;
            gDJaxhmPMf = gDJaxhmPMf;
        }
    }

    for (int ZVtUhRJlvqIzGz = 1146117981; ZVtUhRJlvqIzGz > 0; ZVtUhRJlvqIzGz--) {
        LRQZzZSZUBm = LRQZzZSZUBm;
        LRQZzZSZUBm = ! LRQZzZSZUBm;
        bNfTsHbXid = gDJaxhmPMf;
    }

    for (int gDfZkWvFgDjoq = 643890542; gDfZkWvFgDjoq > 0; gDfZkWvFgDjoq--) {
        bNfTsHbXid = ! bNfTsHbXid;
    }

    return RAlkPRQRvsqo;
}

int cLznzRQEp::ZjxIahVOxdyznJ(double jAHuAmkYeVcZllDK, int IpSJPeWkt, bool wveVhLqEPFd, string pqzPeObtqZCaDV, bool uUJDGoc)
{
    int lucTvQORojNmfsy = -1475813932;
    int qHXZZxzfkiGS = 1256751513;

    for (int QaMFDtP = 220459389; QaMFDtP > 0; QaMFDtP--) {
        continue;
    }

    if (IpSJPeWkt >= -1475813932) {
        for (int hxdmhhPnpRPvxCy = 531577350; hxdmhhPnpRPvxCy > 0; hxdmhhPnpRPvxCy--) {
            wveVhLqEPFd = uUJDGoc;
            lucTvQORojNmfsy /= qHXZZxzfkiGS;
            IpSJPeWkt += IpSJPeWkt;
            uUJDGoc = ! wveVhLqEPFd;
            pqzPeObtqZCaDV = pqzPeObtqZCaDV;
        }
    }

    for (int LDxdikmClNI = 1619780269; LDxdikmClNI > 0; LDxdikmClNI--) {
        uUJDGoc = ! wveVhLqEPFd;
    }

    if (lucTvQORojNmfsy <= 1256751513) {
        for (int UnvPoBNlHLbeD = 445909827; UnvPoBNlHLbeD > 0; UnvPoBNlHLbeD--) {
            qHXZZxzfkiGS -= IpSJPeWkt;
            pqzPeObtqZCaDV = pqzPeObtqZCaDV;
            IpSJPeWkt += IpSJPeWkt;
        }
    }

    return qHXZZxzfkiGS;
}

double cLznzRQEp::mFnAsRHNUwVYRT()
{
    bool GkfuETxbIxHMA = false;
    string WjBzRvzo = string("WhM");

    if (GkfuETxbIxHMA != false) {
        for (int FjglRpLXyrIS = 1212819782; FjglRpLXyrIS > 0; FjglRpLXyrIS--) {
            WjBzRvzo = WjBzRvzo;
            GkfuETxbIxHMA = ! GkfuETxbIxHMA;
        }
    }

    if (GkfuETxbIxHMA == false) {
        for (int vNAfAKSkxOrjUEuU = 256942991; vNAfAKSkxOrjUEuU > 0; vNAfAKSkxOrjUEuU--) {
            GkfuETxbIxHMA = ! GkfuETxbIxHMA;
            GkfuETxbIxHMA = ! GkfuETxbIxHMA;
        }
    }

    if (WjBzRvzo > string("WhM")) {
        for (int BnIGdBLKHLAiFUG = 1215465247; BnIGdBLKHLAiFUG > 0; BnIGdBLKHLAiFUG--) {
            WjBzRvzo = WjBzRvzo;
            GkfuETxbIxHMA = ! GkfuETxbIxHMA;
            WjBzRvzo += WjBzRvzo;
        }
    }

    for (int wWhlEUaKAQiTxL = 1996584136; wWhlEUaKAQiTxL > 0; wWhlEUaKAQiTxL--) {
        WjBzRvzo += WjBzRvzo;
    }

    if (WjBzRvzo <= string("WhM")) {
        for (int PleOgfVC = 279084246; PleOgfVC > 0; PleOgfVC--) {
            WjBzRvzo += WjBzRvzo;
            WjBzRvzo = WjBzRvzo;
            WjBzRvzo += WjBzRvzo;
        }
    }

    if (WjBzRvzo >= string("WhM")) {
        for (int vXkYZjbnRkuXYsLT = 695497189; vXkYZjbnRkuXYsLT > 0; vXkYZjbnRkuXYsLT--) {
            GkfuETxbIxHMA = ! GkfuETxbIxHMA;
            WjBzRvzo = WjBzRvzo;
            WjBzRvzo = WjBzRvzo;
            WjBzRvzo = WjBzRvzo;
        }
    }

    return 315992.05126158224;
}

bool cLznzRQEp::BdztIEtV(bool fNtPl, double sHCateoUjNDvwCFC, bool OvcZeQWC, double qNlKzoiTga, bool vooOZsk)
{
    string cwfSrgdCi = string("RaQoInbRPcjHLWhALWhIlPLsNFwVsatLZsweNzXKvtlKOKsGtnxoJHsRGfdJGIFkXGuTze");
    bool cihxq = false;
    bool rulqxCDEMkVeUQ = false;
    double LOJstgfNvCKMHFrD = -578042.1941580812;
    string qRqSXW = string("mPcJwncIMwdGMTTDTMPlaTHWQjUdWHswKeCWjMedpziNfVWsCyNYalIZmCdABPfqgzBXXjjhDpwPACydvTLoHpnsZLNCZxxxNkNNyMSUFrjDYNteoduyeKXPQrDPWqTIruCweSpYkbiKqHNjEUYdYdRYookzUnvjeiexWAFkTDubgMbstHqAykOfpgZjgNNOhGzDoeOInJxsdmjtzIi");
    int vUeAx = 1359921456;
    string LCPsfptYCHA = string("PFZRioUgyBLyXKrMYtjHmJPpFOflNjNGdlftbkZUnSUvqXEH");
    double fcIPcQcQz = 235431.78594609431;

    for (int RnZQMG = 143669347; RnZQMG > 0; RnZQMG--) {
        qNlKzoiTga = fcIPcQcQz;
    }

    for (int bfjAHthIQdwuyl = 873283100; bfjAHthIQdwuyl > 0; bfjAHthIQdwuyl--) {
        rulqxCDEMkVeUQ = ! OvcZeQWC;
    }

    for (int PYTPCfmCVnKfu = 802306822; PYTPCfmCVnKfu > 0; PYTPCfmCVnKfu--) {
        fNtPl = fNtPl;
    }

    for (int UKwEE = 871129468; UKwEE > 0; UKwEE--) {
        fNtPl = OvcZeQWC;
        vooOZsk = ! rulqxCDEMkVeUQ;
    }

    return rulqxCDEMkVeUQ;
}

bool cLznzRQEp::rYauvHn(string sxidgqeo, bool yLvIYhFUzcZuJa, string HwuginCpaaRq)
{
    double MMApOiBFx = -28759.702579844987;
    int MHbtoEzIVbrIH = -1211275948;

    for (int KLZnjXD = 1013268860; KLZnjXD > 0; KLZnjXD--) {
        MMApOiBFx *= MMApOiBFx;
    }

    return yLvIYhFUzcZuJa;
}

bool cLznzRQEp::kwNUFGCBLY()
{
    double CBeriOti = -526484.7686859377;
    int DYRRYB = -1236737405;
    double flEsZl = 715662.1807828548;
    int ZKLsdGr = 87500194;

    if (flEsZl == 715662.1807828548) {
        for (int bzTbPCIGFlSLy = 218886729; bzTbPCIGFlSLy > 0; bzTbPCIGFlSLy--) {
            continue;
        }
    }

    return true;
}

bool cLznzRQEp::gyznCLSWvPfU(bool HqzkyJmcweBMr, string bJWwDajQFwcsjko)
{
    int dRnekvfR = -824661884;
    double CQESWXL = -801296.3734124465;
    string ubPOdIO = string("iRmcDEpwVJsMWrjCGHSNylgssdpQxbxsxAqGiabTvVHCoeLWgKwqEoKqOBFXXDBJiqKpxdelpDGwtBRVOkPftEbRTlamjGnljFhfDGBsXAw");
    int KzGOgZ = 1280363467;
    string pBneI = string("KdLIEfeuOIXGdUuGzMkWXVvcrYwbRdvNwOtNdUh");
    double RrFEfVkfEfLaMa = 178958.12176764273;
    string PVxQhRgWgHqcSKXj = string("xdVZySgJihvSWoxxtAyUXzkVrudAtFEbUOvUFLqkLNkrVMNBQlCgoPxOzMJqePXYmWwIfsEJOVDfNXoCSYRvWShqJfejKpcTLBqcPbMgEQyYb");
    string WEyiQnrox = string("guPBgzxamaulibetVfhKqAJRoxUHlVnIvTBhPTIHJPTduOmyZEZVdoRZSQDAvskRjueERKdNgBZOOsvGNSpsAmitkFrScIVAWwOJwRmGpIfKcLYmAMeLIYKGxmMLYMKxtkMVWAjKCovnGSQXGbprkHuvsHCMcmULCDnY");
    int DwNInPWlZtCpA = 1329556035;
    double CXnvtOTpOey = 803374.8344319627;

    for (int wXhErILBy = 1890578078; wXhErILBy > 0; wXhErILBy--) {
        CXnvtOTpOey *= CXnvtOTpOey;
        DwNInPWlZtCpA /= KzGOgZ;
    }

    for (int YmXDUjEkG = 2039922631; YmXDUjEkG > 0; YmXDUjEkG--) {
        PVxQhRgWgHqcSKXj += PVxQhRgWgHqcSKXj;
        PVxQhRgWgHqcSKXj += pBneI;
        WEyiQnrox += WEyiQnrox;
    }

    for (int ZznBu = 616487404; ZznBu > 0; ZznBu--) {
        pBneI += ubPOdIO;
    }

    if (CXnvtOTpOey > -801296.3734124465) {
        for (int VoryZtInuHeTqmTt = 1977974164; VoryZtInuHeTqmTt > 0; VoryZtInuHeTqmTt--) {
            KzGOgZ *= dRnekvfR;
        }
    }

    return HqzkyJmcweBMr;
}

cLznzRQEp::cLznzRQEp()
{
    this->lfcOE(string("tIodCcbVpRYfNatDdheewEjNfIUJphpuvYZfiyHXUOnptjmckZcsFlBLJBCxstuhzvTOcMEjUKYAeBRWKNlLHNGOROtwQcYDSbdXqVwRYMqrJgASvSkIgrifbyJEwtdztFdQzDizoZDoHPmcOWMgjyEjbEznfNBaNriLVRuFnzuWNxpwvDBmgAIpuxKUrSxqVDneVxiUZLnsqeNVNHMzZbdbvjKCY"), true);
    this->siUuYhaEh(-639994.8442378212, -29359903, string("IoYEAalGfLMOVcooWdufQSmXrYxwzyeghTsdqejeyOnIXnVhyhxTpPXQOzxQWrkDXGjQjmchgkFYfZyeFwcinOEleAgsGPoTdxGDqdjzxWfDNHiiWksLaBG"));
    this->lBVKLBdnDzmLwQj(string("IVZsjtuDgvOVOcVmpXduTioAvFmUiNbUoScRlBXLWAeOlRRfqnNTTMgjTgBgPhRNHBloxNnbpmdAQdOMzNohLcAwfSpXMYZPeZGSphVkjTKh"));
    this->XCTmes();
    this->iVEYMLFgvbi(false, string("HnxtocsXSlkNahUqQJlDLQVXtjtHhvGlkxwDACsRzFoORHARJDwgYQfdugTBVMsBrIrHGRhXHzYbwBjWJjynBQJsLQzwUGnIoAvhlRdcKOnxQZokR"));
    this->dGskhCWFjiaBUw();
    this->julUjDQFuCBlz();
    this->EjjJhlvnrGFqsU(-909131.891042435, false, -478653.7775941267, true, 1544472831);
    this->RZGsTw(212535.31446414208);
    this->oRwhKTyBiH();
    this->iaXTmQCNsSKpZ(string("kxzRphLiEokFlUXzLxrVluarTWOyrZsHYxOqIXJoGMzYcaoWIPCbvKMbZOJbZkPnwIcNrCSbZZskIAwMmyzRrqHwovPalWtyJjwTK"), -840338.9376057617, -1369646804);
    this->gCGUDWnZCTPtZ();
    this->BLpPQYn(376327.5243702567, true, string("VHLjlLdmqBviaBnsMuobUdATmjAKPBvJTXXrKWWeXyubrWhHHPWhqZiNtDja"));
    this->fqYAsmPfB(-1573677733, 645933.239607082, false, true, 2079232970);
    this->ZjxIahVOxdyznJ(668588.3040497251, -833739826, true, string("AlBCjSsZdLrPsYvMmVgQvKonTRTbzSOshwmzVLanLgHkjxFJcyWhyyKAhnynFFjeZswALNsHHQvJYNlcKRaIkciViBUaUNmJYDxgmMyqUkySEONVDwOcCzRmGNrLcKkTgOQYDTlURbKsDQVehAokdBqIbBtQtnkQ"), false);
    this->mFnAsRHNUwVYRT();
    this->BdztIEtV(true, 422025.8666888478, false, 356323.3069634038, true);
    this->rYauvHn(string("mSeOsNNqSdezmiZruFEFZYsYVokmIVjMQMtsHPUcypGSieJoyvlocmXCIDSzbqSxwiJ"), true, string("fYUxXfCymxpyJBwVdxVMsbOEqwRayHvozREzakg"));
    this->kwNUFGCBLY();
    this->gyznCLSWvPfU(false, string("dKLudqiGDlQZBsTcDScJSPFuBciJGzfNINbbSOuJtqQrYRqrDMWuYvOOlYJZRfzYcOrNYsFZHRdJBldwHGocJQkuiSLNUymnuzFJwUaXEvhfNlIxVQHEjrMwUCEJDEylBjcFxnVsCfWPONUPsGUOlsurzMJtvjMbeDomjHigZJwhFiLKyDAqqyEkyqixkhUIPglqsCoVmXrDBENgOnRLOGxPBUoMVzdGlGXUQOoKIJTFFyzONbtsxpUTkauRG"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class tvuPApNjazxsZ
{
public:
    int pQSFhJLnZt;
    double GHeJduNcwuYYcwBw;

    tvuPApNjazxsZ();
protected:
    int PdNkPhIdkFpjEyhm;
    double gsKXzOzCrkb;
    bool qkXwA;
    string DcIuYwMBQu;

    double qkIZVWDqjX(double HQrKNpvxGw, string LvCpPLfORjoatdAE, bool AQQPmfS, int YxuhXGELteDgm);
    int oCQvgro(bool wmvJnKjDj);
    double yMzngqWL(bool SEOyumCReJvcz, string AWtmceIM);
    int KxkRt();
    void utLloYjsXKRUMIF(double ydzjFONI);
    string jYQTWmwbJkwycuqt(bool lUNRvNgjnNP, bool KooZVSYoioj, int ktMvnXdhUQp, string kYfvOefyyqBvgkT, double hxsArHmkobHaqO);
    void JKgXyhlgYtwWDuj(double fmnZxJpErghde);
    string irOvgHnemKAO();
private:
    bool uTqcotQ;

    string dQcQZnKRfQ(double icSOGWE, int AUMePgVM, bool DWteOxl);
    void AGtLjs(bool kSpgBjBS, int BLXJTb);
    double rqnrdBKmftBuG(bool JebYgkfOeHU);
    void dyyyniTTpxZmWix(double uwFkd, int WOjecHGlaupYihA, int zxPFS);
    string cCaKpcqyukMbRORE();
};

double tvuPApNjazxsZ::qkIZVWDqjX(double HQrKNpvxGw, string LvCpPLfORjoatdAE, bool AQQPmfS, int YxuhXGELteDgm)
{
    int puhWFecZOnJ = -358953549;

    for (int UJHmz = 260146097; UJHmz > 0; UJHmz--) {
        YxuhXGELteDgm /= YxuhXGELteDgm;
        YxuhXGELteDgm -= YxuhXGELteDgm;
    }

    for (int PvocYsIppiDBQKvS = 1202000623; PvocYsIppiDBQKvS > 0; PvocYsIppiDBQKvS--) {
        YxuhXGELteDgm = puhWFecZOnJ;
        LvCpPLfORjoatdAE = LvCpPLfORjoatdAE;
    }

    if (YxuhXGELteDgm < -358953549) {
        for (int cVfmamexLOwwyG = 36734398; cVfmamexLOwwyG > 0; cVfmamexLOwwyG--) {
            puhWFecZOnJ -= YxuhXGELteDgm;
            YxuhXGELteDgm /= puhWFecZOnJ;
            YxuhXGELteDgm -= YxuhXGELteDgm;
        }
    }

    for (int sLMcttWsJfxYVF = 173391338; sLMcttWsJfxYVF > 0; sLMcttWsJfxYVF--) {
        continue;
    }

    for (int CBXKbRdUxwPE = 73843052; CBXKbRdUxwPE > 0; CBXKbRdUxwPE--) {
        HQrKNpvxGw = HQrKNpvxGw;
    }

    for (int tiHYnxWejNcp = 569624783; tiHYnxWejNcp > 0; tiHYnxWejNcp--) {
        continue;
    }

    return HQrKNpvxGw;
}

int tvuPApNjazxsZ::oCQvgro(bool wmvJnKjDj)
{
    int AejOoBWqtD = -897398175;
    bool bmSSAFAsn = true;
    bool bwREbscYdfYkSim = true;

    if (wmvJnKjDj == true) {
        for (int taPtbvxKQdw = 1917645227; taPtbvxKQdw > 0; taPtbvxKQdw--) {
            wmvJnKjDj = wmvJnKjDj;
        }
    }

    if (bwREbscYdfYkSim == true) {
        for (int JjChZaZ = 129109411; JjChZaZ > 0; JjChZaZ--) {
            bmSSAFAsn = ! wmvJnKjDj;
            wmvJnKjDj = ! bmSSAFAsn;
            bmSSAFAsn = ! bmSSAFAsn;
        }
    }

    for (int DOePdajtsOCnM = 440899072; DOePdajtsOCnM > 0; DOePdajtsOCnM--) {
        bwREbscYdfYkSim = ! bmSSAFAsn;
        wmvJnKjDj = bmSSAFAsn;
        bmSSAFAsn = wmvJnKjDj;
        bmSSAFAsn = ! bmSSAFAsn;
        wmvJnKjDj = ! bmSSAFAsn;
        bwREbscYdfYkSim = wmvJnKjDj;
    }

    if (bwREbscYdfYkSim != true) {
        for (int nvuAbISKlrFkVejy = 1793829119; nvuAbISKlrFkVejy > 0; nvuAbISKlrFkVejy--) {
            bwREbscYdfYkSim = ! bwREbscYdfYkSim;
            wmvJnKjDj = bwREbscYdfYkSim;
        }
    }

    if (wmvJnKjDj == true) {
        for (int DIAJMdurnoTh = 385127332; DIAJMdurnoTh > 0; DIAJMdurnoTh--) {
            wmvJnKjDj = ! bmSSAFAsn;
            wmvJnKjDj = ! bwREbscYdfYkSim;
            bmSSAFAsn = ! wmvJnKjDj;
            wmvJnKjDj = bmSSAFAsn;
            bwREbscYdfYkSim = bwREbscYdfYkSim;
            bmSSAFAsn = ! bwREbscYdfYkSim;
            bmSSAFAsn = wmvJnKjDj;
        }
    }

    if (bmSSAFAsn == true) {
        for (int KSCIGjxLGlF = 72092342; KSCIGjxLGlF > 0; KSCIGjxLGlF--) {
            AejOoBWqtD *= AejOoBWqtD;
        }
    }

    return AejOoBWqtD;
}

double tvuPApNjazxsZ::yMzngqWL(bool SEOyumCReJvcz, string AWtmceIM)
{
    int PnMww = 438758753;
    double nVTAwHqfkBsqkX = 448831.51129188325;
    bool hYPIu = false;
    double GqiPDPYIQqL = -852136.1934114366;
    double wJRSD = 5533.409635606704;
    double gKURNftRwys = 253733.61617552483;
    int DkHHAYzJ = -1461541053;
    bool zNzUsvmWnLCuk = false;
    string rNqsf = string("cWIxbtMPWiCgFvAqMdDGpIswfpdnTAJhSsmpBycHTxjgqdTQuVBKJstIneaAzaoiELQrKsHXeoFeggHAyFNUCGUOrDRCGSROKyycCwBUmPzZjfJemHveBhLLuBoHXaMODGXduulOltvTVzvJPqVRrRaPfy");

    for (int nIFlL = 1898970776; nIFlL > 0; nIFlL--) {
        zNzUsvmWnLCuk = hYPIu;
    }

    for (int KYSwNBqVrbhCvT = 2127574406; KYSwNBqVrbhCvT > 0; KYSwNBqVrbhCvT--) {
        nVTAwHqfkBsqkX = GqiPDPYIQqL;
    }

    for (int iiBSZz = 374927744; iiBSZz > 0; iiBSZz--) {
        AWtmceIM = rNqsf;
        AWtmceIM += AWtmceIM;
    }

    return gKURNftRwys;
}

int tvuPApNjazxsZ::KxkRt()
{
    bool PdnZS = true;
    bool ReyBgWxsTfyf = false;
    int MJXJdn = 1140337015;
    bool eHdZgmPpQOqGSjH = true;
    bool OWMvjYKWwcM = false;
    double kJzCKELWtYvQ = 537601.6559812326;
    double fKjOUWyDkooazs = -836594.6764867648;

    if (PdnZS != true) {
        for (int NyWwTDXfhnvJGYNe = 214954707; NyWwTDXfhnvJGYNe > 0; NyWwTDXfhnvJGYNe--) {
            continue;
        }
    }

    if (fKjOUWyDkooazs < -836594.6764867648) {
        for (int zNMGro = 267923148; zNMGro > 0; zNMGro--) {
            continue;
        }
    }

    for (int YZwvNxgA = 2103290107; YZwvNxgA > 0; YZwvNxgA--) {
        fKjOUWyDkooazs += fKjOUWyDkooazs;
        ReyBgWxsTfyf = ! eHdZgmPpQOqGSjH;
        kJzCKELWtYvQ *= kJzCKELWtYvQ;
        OWMvjYKWwcM = eHdZgmPpQOqGSjH;
        ReyBgWxsTfyf = ! ReyBgWxsTfyf;
    }

    if (ReyBgWxsTfyf != false) {
        for (int rrQLrdIglokWIWQ = 2096126703; rrQLrdIglokWIWQ > 0; rrQLrdIglokWIWQ--) {
            fKjOUWyDkooazs -= kJzCKELWtYvQ;
        }
    }

    if (OWMvjYKWwcM == true) {
        for (int ZfLENM = 1461934919; ZfLENM > 0; ZfLENM--) {
            ReyBgWxsTfyf = ! eHdZgmPpQOqGSjH;
            eHdZgmPpQOqGSjH = ! ReyBgWxsTfyf;
            kJzCKELWtYvQ += fKjOUWyDkooazs;
        }
    }

    return MJXJdn;
}

void tvuPApNjazxsZ::utLloYjsXKRUMIF(double ydzjFONI)
{
    int lkKUHRdXxlszsG = 16029594;

    if (lkKUHRdXxlszsG != 16029594) {
        for (int IMIqIEJDqULfIzqX = 650556729; IMIqIEJDqULfIzqX > 0; IMIqIEJDqULfIzqX--) {
            ydzjFONI -= ydzjFONI;
        }
    }

    for (int PxsrSjHufnMvuly = 151253505; PxsrSjHufnMvuly > 0; PxsrSjHufnMvuly--) {
        ydzjFONI -= ydzjFONI;
        lkKUHRdXxlszsG += lkKUHRdXxlszsG;
        ydzjFONI *= ydzjFONI;
        lkKUHRdXxlszsG /= lkKUHRdXxlszsG;
        lkKUHRdXxlszsG *= lkKUHRdXxlszsG;
        ydzjFONI *= ydzjFONI;
    }

    if (lkKUHRdXxlszsG > 16029594) {
        for (int nQLNqtlp = 696913781; nQLNqtlp > 0; nQLNqtlp--) {
            lkKUHRdXxlszsG /= lkKUHRdXxlszsG;
            ydzjFONI /= ydzjFONI;
            ydzjFONI *= ydzjFONI;
            ydzjFONI -= ydzjFONI;
            lkKUHRdXxlszsG = lkKUHRdXxlszsG;
            lkKUHRdXxlszsG -= lkKUHRdXxlszsG;
        }
    }

    for (int LWqnKgZFlFdguKOh = 1756705495; LWqnKgZFlFdguKOh > 0; LWqnKgZFlFdguKOh--) {
        lkKUHRdXxlszsG /= lkKUHRdXxlszsG;
        lkKUHRdXxlszsG -= lkKUHRdXxlszsG;
        ydzjFONI -= ydzjFONI;
        lkKUHRdXxlszsG = lkKUHRdXxlszsG;
    }

    if (lkKUHRdXxlszsG != 16029594) {
        for (int mLPTXLnJNgjWC = 655706605; mLPTXLnJNgjWC > 0; mLPTXLnJNgjWC--) {
            ydzjFONI += ydzjFONI;
            ydzjFONI = ydzjFONI;
            lkKUHRdXxlszsG -= lkKUHRdXxlszsG;
            ydzjFONI = ydzjFONI;
            ydzjFONI /= ydzjFONI;
        }
    }
}

string tvuPApNjazxsZ::jYQTWmwbJkwycuqt(bool lUNRvNgjnNP, bool KooZVSYoioj, int ktMvnXdhUQp, string kYfvOefyyqBvgkT, double hxsArHmkobHaqO)
{
    int UkejPH = -1555413686;

    return kYfvOefyyqBvgkT;
}

void tvuPApNjazxsZ::JKgXyhlgYtwWDuj(double fmnZxJpErghde)
{
    string FjyVwBoYGBI = string("HIBRNJGCXDQIHAJIuoclhoMmnzXUsTSNgRDdDzGBAMnqVYRDAouFTYDfkhvAVQiZpEhaKX");
    double QSCUevUZICd = 889153.834380173;
    int MVQAME = -848930923;
    double UDBeSwhPMWEGvI = 781613.8014106427;
    double oqpZZpEp = 107737.8908923292;
    double bxbeYFCdIWtXf = 965765.4446595133;
    bool CZRQneqX = false;
    string kvTWbqIocSQ = string("CkLKpyIcJLwRAkdxiONiYBgfNJe");
    int UwNcKTazD = 492032590;

    for (int HtLbviZmM = 271821605; HtLbviZmM > 0; HtLbviZmM--) {
        UDBeSwhPMWEGvI -= bxbeYFCdIWtXf;
    }
}

string tvuPApNjazxsZ::irOvgHnemKAO()
{
    int VnpluNhGIggZxdJr = 564403337;
    string NQAZEUFPvbQSqQmx = string("HfvUOH");
    double gtMztMNL = -201407.51205587835;
    string QgnuSCQaguBbc = string("gydAlYwYpuhQfqNPWGoxWnWNcFJwJqFTaodBOhdCDKZfJkUOoxFtrugtN");
    int ZCLusPMCgNbkQeU = 1548338256;
    int JpDsGCpw = -1560546716;
    double rdRavSaUPE = -427315.9242139822;
    bool JmLCcvzpZViNS = false;
    int KLRudxHzziEmJe = -1889097234;
    int wBxPUfkzgZUBWmi = 2116964309;

    for (int tnfbAYhOqMJ = 1900442607; tnfbAYhOqMJ > 0; tnfbAYhOqMJ--) {
        NQAZEUFPvbQSqQmx += QgnuSCQaguBbc;
        KLRudxHzziEmJe /= KLRudxHzziEmJe;
    }

    for (int ETzaxAFD = 238962909; ETzaxAFD > 0; ETzaxAFD--) {
        continue;
    }

    return QgnuSCQaguBbc;
}

string tvuPApNjazxsZ::dQcQZnKRfQ(double icSOGWE, int AUMePgVM, bool DWteOxl)
{
    int VIoYPAQF = -1377929677;
    int UaikWFvzRFKkH = -1899854227;
    bool VhlXXGPR = true;
    string bEkJPXmlGTpNSCNe = string("bgLdJhclfZstqhHTidjrPEpwIaLTkUPhmprXFgpLKzpSLKuHARkGwcXBxXIqDAesMholwZNoFIgcqOhiGjaKpUBICXHXbqEHktsQvcncaNDegJLUZXSifEdCBUDKiJNueTBdrrSWBayxTTjOdvLkpdNEUXngfWBdWhWxRxgUcHKGjQEIlhNEYhWpHdykeXZebmURx");
    double RNeBoY = 618048.7502308318;

    return bEkJPXmlGTpNSCNe;
}

void tvuPApNjazxsZ::AGtLjs(bool kSpgBjBS, int BLXJTb)
{
    int ndLOlJzkEQkPKo = 1497433445;

    if (ndLOlJzkEQkPKo == 1497433445) {
        for (int GyvoZTwucxDlETc = 394966463; GyvoZTwucxDlETc > 0; GyvoZTwucxDlETc--) {
            BLXJTb /= BLXJTb;
        }
    }

    if (ndLOlJzkEQkPKo >= -1741612744) {
        for (int juipsUBNkZs = 1202125427; juipsUBNkZs > 0; juipsUBNkZs--) {
            BLXJTb -= ndLOlJzkEQkPKo;
            kSpgBjBS = kSpgBjBS;
            kSpgBjBS = kSpgBjBS;
            kSpgBjBS = ! kSpgBjBS;
            ndLOlJzkEQkPKo -= BLXJTb;
            kSpgBjBS = ! kSpgBjBS;
        }
    }

    for (int PQuiIHTXpccny = 1723700273; PQuiIHTXpccny > 0; PQuiIHTXpccny--) {
        BLXJTb -= BLXJTb;
        BLXJTb += BLXJTb;
    }
}

double tvuPApNjazxsZ::rqnrdBKmftBuG(bool JebYgkfOeHU)
{
    bool RvmCredGwQcHiu = true;
    string zqaGMEyorl = string("HOuHzseTufTBWRwqONooMTqUaHpWpBZYsHHnlnWweCcwpOpAHruejafMUARrTGQjXFwEcttxzwXAYAovxyKEcC");
    bool fTltsmZHyRDrJK = true;
    bool NjdybEEHnInuDtpp = false;
    double bxLifQAHt = 483872.0810762997;
    int fUYnYTEHx = 1278712732;

    return bxLifQAHt;
}

void tvuPApNjazxsZ::dyyyniTTpxZmWix(double uwFkd, int WOjecHGlaupYihA, int zxPFS)
{
    double LEqSLOvTrokb = 235036.4380069084;
    string DLzicVy = string("YYSRdRfmcQuDhUORoEkVofAUTJxqgUHYIZLpEOSuBoeklaKimkYjaAPlnoUYXJNLOSCDnkoqbOLeqDsvvLJnXjiSHEHHhAJGtgpnTjUbhnvZYLIqDxyDSsbmROafPEhazlTCArPbbHeJsvEMGXArVFgAfY");
    bool mscTevgr = true;
    double iwbUtoZs = -293172.2815199575;
    string WpwHjEjiFFDVf = string("YQaSbhdGNSrZUbcrWEDOSxbjAHujNayNpyuKdwhVYupNdSihOPPuXXRDjPHuaSudAFTUFWcFtxGvZETGxBiDpvVKvEdkGxWXMPAIxlNbPqDLQtgmgDDELfknmiMLEmyrerSotBTWOIDAgecxbJfqyqRlzEWuXzsQRyReBzGfIDwJDgYiOhZPIcZTKkXrOyfaWWCBKPmdfWlLAwANahBIdlamUYzeXTZppKbheRYlAMUzsnCfJJdlsbZODNMqkbv");
    string SXuZudcH = string("MISaxWisFjxiXBwxGUREUYUUGyoiJNIqNowEdEjkulGqBcolLcFDYqrUwtpOiCgCnKyiApmjJxgxqyqbOLSgEFJjuwrGPDekKdxPItPOhRxfYGLSMKJwdLrihnNWVuoXOJciNXIpefTYPcHVYqUJYZaAEYEdxRTEBlRUKWsPCrIPRHdrTNcNnLYpaVxYuRBEiXGAGBxcZQDrIfXyFfRQCnCOFcFQkBBUsaCs");
    int FJHiJs = 70231057;

    for (int pUTzsdbRydLF = 760098828; pUTzsdbRydLF > 0; pUTzsdbRydLF--) {
        uwFkd *= uwFkd;
    }

    if (LEqSLOvTrokb < 764710.9654702236) {
        for (int IluFNgLrWmYVx = 402285524; IluFNgLrWmYVx > 0; IluFNgLrWmYVx--) {
            WOjecHGlaupYihA = FJHiJs;
            DLzicVy = WpwHjEjiFFDVf;
            WpwHjEjiFFDVf += SXuZudcH;
            WpwHjEjiFFDVf = SXuZudcH;
        }
    }
}

string tvuPApNjazxsZ::cCaKpcqyukMbRORE()
{
    double jtoiqqytHU = 883745.3091742554;
    bool rKpBNIC = false;
    string isxoWOTVttE = string("TkEmIuzwzmKHideeZtbjPigZQXUDsrpXjtieDubzoRLvOgdAEYDUxgqRHtBizNooxFmPH");
    int flQRyyKbJDVIs = 1766488942;
    double uYqrafqEuWdYvj = -452550.3836634844;
    bool JgKSAT = true;
    string vbuLCUFGJ = string("zzoETQDzukERoHUtFvflEoxixRfNNRpMzQMuktrzVhpcpbZiIFMVQMpbigDQwdjlWhJDk");
    bool YSAfeBX = false;
    bool EPAvQwCDPvEf = true;
    bool yWzpkWcS = false;

    for (int xhntAbWldSISjl = 405718116; xhntAbWldSISjl > 0; xhntAbWldSISjl--) {
        yWzpkWcS = yWzpkWcS;
    }

    return vbuLCUFGJ;
}

tvuPApNjazxsZ::tvuPApNjazxsZ()
{
    this->qkIZVWDqjX(-576508.9177894597, string("ciykYPYMGeUtSwtFLpaLfnljsXOFuJAKzPiEIQoUafl"), true, 2058995175);
    this->oCQvgro(true);
    this->yMzngqWL(false, string("utAFZLSZDFCtwyTJDaSjWKcAxjRzZWSPZoBPTRlTQhzNwOtBDzmsABZKKGMMfdVDtbogyHmhDFVuleuaRPmrKaunAbwchulQiKntyISSqMbmaUqhyXWHRGpUvyGABAebtiTGhhtRHhbYsMtAQLmJTNfsvjpmLPfGubeOyICAwRHlDTFZaxvSzKqOReWiGNsfOFUK"));
    this->KxkRt();
    this->utLloYjsXKRUMIF(280708.34633018443);
    this->jYQTWmwbJkwycuqt(false, false, -490163468, string("yUEFkapcZVqfgfBRoKybrzoWmLOZUcAtStzcPnEQmzfNeHmpbcWYgiTpSfFivbTmwldLyFigutYqHTyUmuXXVRfQquHifcaoFlFSHOVZocISyZngZecqXMQIBEDvWOAqiMMCuOUhjcStNELzIlbKdWCSYAtGFbiJANINVwAvlWyVLtKUHyDdRLpLLTwaMKnEZDGreBQeuDjGxdeqvjYUEGshqCSHXvTvIupawZlSNiiBjSMKteJfjiImPF"), 712159.3898937859);
    this->JKgXyhlgYtwWDuj(683571.4209102943);
    this->irOvgHnemKAO();
    this->dQcQZnKRfQ(684824.823144589, -2050544769, true);
    this->AGtLjs(true, -1741612744);
    this->rqnrdBKmftBuG(false);
    this->dyyyniTTpxZmWix(764710.9654702236, -783402118, 2125892376);
    this->cCaKpcqyukMbRORE();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LKxLNZjMOrTKyO
{
public:
    bool ZqihjBRrqwdtKrbI;
    int RfAGIClbL;
    int DtITlGwuPmvi;
    int xGvquevypjFfrk;
    string wbAHJReuEMFHEms;
    string mcGSzqO;

    LKxLNZjMOrTKyO();
    string xNaoXPhiBCpOBgGE(int dcaXoVpwVa, string UsSfZgNhqkWf, int EeUtxoXBo);
    string bzOXXJolQrNb(int JuaLk);
    int XHklc(int nsykWHl);
    int AfzsrP();
    bool qvlIkpPBeaAsdP();
    double dJtWbU(bool nLMcW, double KluRegtMO, int iCGxA, double HEUsVRvw);
    void OFGSZZ(int hHztASiazfiIojL, bool psqmO);
protected:
    bool hGVfRRHkrzSBpn;
    double fSQNOA;
    string yNKpi;
    string cSBbHjtbJBRLWM;
    bool SFAGMQNPP;
    int XwjDNtzTvKvBv;

    bool OdVpvNIIMBYwMr();
    int qTKiefaFyJ(int ioPRCozCA, string THSXWhKBKibLE);
    void dHIcoA(string NhCes, int JflOALBP, double UMoiZfQyUustmSVZ);
    bool VeJNocOjCQ(double SDAxphXNmcqserSw, string mIFgWCFj, int wTfJUaugfSVJq, int BXLcWeup);
    string yXjVxScOSCuaPvY(int TLUiDidyLgW, string hiuKXLe, string qMCEblMu, bool orscWcmTxY);
    bool gafxmEfcMWGslDS(int TcwQdUfidIvhi, string wnhmlWFbYIJ, string TToljcW);
    int gIYshE(string LprhtERqhVlNbHC, double KBVZma);
    void ymfanlhJAKx(double FqqCCo, string vUTxx, int dPSYeSzkUnZsMf, double sxKkXJYGzRaYX, string JRWadtgvZzytmx);
private:
    int LBBnTVQyGEku;
    string ehQxsLMznll;
    double aGyxaPVcHaKJZ;
    string QOxunxDOXXiWw;
    bool krhAJ;

    double XVoct(bool IeZbDApksEvGz);
    double xRajnHdfYAQW(string GRIyx, bool nxiuu);
    int ymcfGHhi(double OzPZKc, bool HnGXFCnlABgvj);
    void QskDfvPGQJaE(string xtNAxXWDLmMTb, int TVMjXKxsWmTjWD, string rVDuXwUKE);
    int hfjUt(bool kcEDVYyy, int ZgkjkFpahcP, double xKvxSEmomoIwpw, int ztaIMZGi, double cKhnEtvGTrGiUBlS);
    bool aQkVMYxgZJ(bool QGpjjvCJNCm, bool xwyHMZiQakTqXXbV);
};

string LKxLNZjMOrTKyO::xNaoXPhiBCpOBgGE(int dcaXoVpwVa, string UsSfZgNhqkWf, int EeUtxoXBo)
{
    string URlBmnbEzFLxZbk = string("gcxaiAwsHCdAnlLllbGnnHvPryqqZBWOwIyOZPvnWyMLGfuXEJsDmCuwwFwOppcqLdpCRalJEzeDvsoCwZOZFqkZrDFrliUmiWFaWyGOdphvToZTvJvfFTGChPzFnHHcflHqyQNRzNUbtgTkVAeTzWt");
    string FlvnltI = string("hQDgVrShwZgriPZxOhzgGTxbfDUQCxapjYkmZKsHLdItYCNaTQiCxtfciAXuKElolvbgxHWDpzetBruNPzeBpVtflmhlwiFh");
    int jIopIac = -1077877571;
    bool CaTcLkwt = false;

    for (int euUYBTOLs = 359795474; euUYBTOLs > 0; euUYBTOLs--) {
        continue;
    }

    for (int zXUKsEDCAQxEVZ = 1680289438; zXUKsEDCAQxEVZ > 0; zXUKsEDCAQxEVZ--) {
        dcaXoVpwVa /= EeUtxoXBo;
        dcaXoVpwVa *= dcaXoVpwVa;
        FlvnltI += UsSfZgNhqkWf;
        jIopIac += jIopIac;
    }

    for (int pRUBBvH = 1414281916; pRUBBvH > 0; pRUBBvH--) {
        CaTcLkwt = CaTcLkwt;
        UsSfZgNhqkWf += UsSfZgNhqkWf;
    }

    for (int tZPAAZUsv = 1318027631; tZPAAZUsv > 0; tZPAAZUsv--) {
        jIopIac *= jIopIac;
        jIopIac /= EeUtxoXBo;
        UsSfZgNhqkWf = UsSfZgNhqkWf;
        URlBmnbEzFLxZbk = FlvnltI;
    }

    return FlvnltI;
}

string LKxLNZjMOrTKyO::bzOXXJolQrNb(int JuaLk)
{
    int TPyjpv = 1794363730;
    bool ODkESrZygTQHKH = true;

    for (int MxkjeFvViiJptEyy = 357385550; MxkjeFvViiJptEyy > 0; MxkjeFvViiJptEyy--) {
        JuaLk -= JuaLk;
        TPyjpv = JuaLk;
        TPyjpv += JuaLk;
    }

    if (TPyjpv < -1562967113) {
        for (int BqPYCWzpYJO = 1135076574; BqPYCWzpYJO > 0; BqPYCWzpYJO--) {
            ODkESrZygTQHKH = ODkESrZygTQHKH;
            JuaLk *= JuaLk;
            JuaLk += TPyjpv;
            ODkESrZygTQHKH = ! ODkESrZygTQHKH;
            TPyjpv += TPyjpv;
        }
    }

    for (int IimyaGoi = 832635816; IimyaGoi > 0; IimyaGoi--) {
        ODkESrZygTQHKH = ODkESrZygTQHKH;
    }

    if (JuaLk > 1794363730) {
        for (int dYoYcCwg = 2053879063; dYoYcCwg > 0; dYoYcCwg--) {
            JuaLk /= JuaLk;
            JuaLk /= JuaLk;
            ODkESrZygTQHKH = ! ODkESrZygTQHKH;
        }
    }

    return string("SfQGrjmLntkrxPXaLJgckMDMqtGWFfhwRcMGLLGwhixBbSuiGPkKFFKkiaSKXhzJCNcqGkqeUMIxiwEHTtQlyYrEICNPcMysgHhpnhSChdBLaNPMLzjCoKypJfshUlKKDSUXjWRmnDaIGmSEfMwaZLCVLzjMCoOZABdVCoADasRNQBuByYqEctiI");
}

int LKxLNZjMOrTKyO::XHklc(int nsykWHl)
{
    int LoMRuU = 1823836631;
    string SPmcgd = string("lcJKHFWOjiAvGMKomdRWyKFWwzrmncjjEcGmGkQVAprALkOzRWRgPiUoxxsUrUfeAgeIcVyvMbDCWTFuXcgDOwxskPYANxRkGpIkbPFNAdsVpziMcRCuRXyiuNfeTIbcStcqzOBFIKToUuWHPcLXgROLvHqXKQsBblJtAoxhYBfFzFHUDEjyBtHyUgzipfpeMKlqMKVnlJlMvOjMatuVNYMVzXunsASHZFApCFTELIlW");
    int UwoKQVyjsla = -1648559936;
    string mEbMovnxzXwU = string("orUv");
    bool BExtuUTS = false;
    double DGroucoknizO = -906180.3789923341;
    string IWwTvmOmGkzj = string("YetivNXYSdDOIUyrewOSQIFRGgjlkxQXpkRLHIXvuwuZBWZGqHioNzmwHZTbGBJWeXvQgpNICHhQIFOpTQlBdmBPSMMpZorkASczKOaXRuVmobBURnGwnUciuZgRpqCNjZVhJztWxiVWeliMeMyEluSLLVjIUOjBqWmxHindsgyOuaCSHKTcyLtBjOZaPXMEobdaxJGgfeWDgkxCuWD");

    for (int GFsgns = 123467299; GFsgns > 0; GFsgns--) {
        IWwTvmOmGkzj = IWwTvmOmGkzj;
        SPmcgd += IWwTvmOmGkzj;
    }

    for (int PTbZVGouburBJm = 945242283; PTbZVGouburBJm > 0; PTbZVGouburBJm--) {
        nsykWHl -= UwoKQVyjsla;
    }

    for (int aFSeyI = 1078655431; aFSeyI > 0; aFSeyI--) {
        mEbMovnxzXwU = SPmcgd;
    }

    for (int arcuNiqDFPC = 262842981; arcuNiqDFPC > 0; arcuNiqDFPC--) {
        IWwTvmOmGkzj = IWwTvmOmGkzj;
        mEbMovnxzXwU += mEbMovnxzXwU;
        mEbMovnxzXwU = SPmcgd;
    }

    return UwoKQVyjsla;
}

int LKxLNZjMOrTKyO::AfzsrP()
{
    double SDzyMvYvXKRufD = -893681.9342702825;
    double UPkumch = -368770.1895355783;

    if (SDzyMvYvXKRufD >= -368770.1895355783) {
        for (int eEIcTqQWHdcdT = 686683055; eEIcTqQWHdcdT > 0; eEIcTqQWHdcdT--) {
            UPkumch = UPkumch;
            UPkumch *= SDzyMvYvXKRufD;
            UPkumch /= UPkumch;
        }
    }

    if (UPkumch <= -368770.1895355783) {
        for (int yNewcIVXqgD = 458241206; yNewcIVXqgD > 0; yNewcIVXqgD--) {
            SDzyMvYvXKRufD /= UPkumch;
            UPkumch = SDzyMvYvXKRufD;
            UPkumch *= UPkumch;
            UPkumch /= SDzyMvYvXKRufD;
            SDzyMvYvXKRufD -= UPkumch;
            SDzyMvYvXKRufD += UPkumch;
            SDzyMvYvXKRufD += UPkumch;
            SDzyMvYvXKRufD += UPkumch;
        }
    }

    if (SDzyMvYvXKRufD >= -893681.9342702825) {
        for (int GpdyW = 1672449082; GpdyW > 0; GpdyW--) {
            SDzyMvYvXKRufD /= UPkumch;
            SDzyMvYvXKRufD /= SDzyMvYvXKRufD;
            UPkumch = SDzyMvYvXKRufD;
            SDzyMvYvXKRufD = UPkumch;
            SDzyMvYvXKRufD = UPkumch;
            UPkumch *= SDzyMvYvXKRufD;
            UPkumch = UPkumch;
        }
    }

    return 923458452;
}

bool LKxLNZjMOrTKyO::qvlIkpPBeaAsdP()
{
    int UVBqi = -335262488;
    double AHQkZdxnDKy = -168948.15658586;
    string MTEKTImk = string("vGrwKGfWLUIsdjzyFrLwPJOvpxmTowMOkkYCMyOGubfMkoXIgrfpXTqVGYT");
    bool HUDOePRY = true;
    bool rEMLIXBwbabf = false;
    double YFjQxDde = 143063.11954177346;
    bool VaSIQEPrZhiw = true;
    string UFHuKPfP = string("uFAwoKpCwvmtJgeojvuorTXJoUNyEKPrvlVYxGgyeMWoVZHGZEPLPxPhzhAxksZnqfhHCgTJnsLLLsUkxwPJiUETUOwZEBrkpBqESnRloPRWVoxuCzlCenXBVLqF");
    string IZlzKEq = string("jXOrjPvtNqbuOWdUohztVACFLqvFnzBhsGEXbfXWpTzTWLRwtARJclmznxgBNwHioibwuoLwfaYpSaFYGmEWTDpALZCHpbhgHIZQhYzhm");
    string IwDzfxUuMhkb = string("BMBdpjpGiKuNpUhYjLsltnXjhgLWZknRGlyI");

    for (int rPTHHIMzeJvc = 1046398171; rPTHHIMzeJvc > 0; rPTHHIMzeJvc--) {
        IZlzKEq = MTEKTImk;
        IwDzfxUuMhkb += MTEKTImk;
    }

    if (UFHuKPfP < string("vGrwKGfWLUIsdjzyFrLwPJOvpxmTowMOkkYCMyOGubfMkoXIgrfpXTqVGYT")) {
        for (int ZtEZNqzmKLZKl = 2024627376; ZtEZNqzmKLZKl > 0; ZtEZNqzmKLZKl--) {
            IwDzfxUuMhkb = IwDzfxUuMhkb;
            AHQkZdxnDKy = AHQkZdxnDKy;
        }
    }

    for (int JMaqsQXxTxtWW = 620561055; JMaqsQXxTxtWW > 0; JMaqsQXxTxtWW--) {
        MTEKTImk += IZlzKEq;
        UFHuKPfP = UFHuKPfP;
        rEMLIXBwbabf = rEMLIXBwbabf;
        YFjQxDde -= YFjQxDde;
        MTEKTImk += MTEKTImk;
    }

    return VaSIQEPrZhiw;
}

double LKxLNZjMOrTKyO::dJtWbU(bool nLMcW, double KluRegtMO, int iCGxA, double HEUsVRvw)
{
    string FYwlkxCFgYDqrqvT = string("hmFOryGrPJwnVgDZzVfJzbDRiUmfdLZnCFnjZyPZDrMDzJJFVMQhZfCFeGjuqzCnRUIzxRasePBkUzPgvykFCEhJpvjhkyPxGBEWnuEBMdptYFir");
    int pwqiNtHRifzNd = -581025158;
    double xReyxcxRNSRu = -70401.62080564983;
    double BrqaRfJSvhP = 964114.7225958563;
    bool peBdTTCZXwfraI = false;
    bool nOyjbr = false;
    string kmddPhqfRPlg = string("CDYBqxfDTePrQfvljaOLJDQgMwXCDidaptxTbgXesvDTjIjIsQsrLwLMM");
    string qOSfKC = string("dkGspffwkrFlvltiztNoNHiVlXIpycGz");
    string JvSiK = string("MZzpzlWmZHsVrYLXNsmSonjwZCPnEDLQsLXeErI");

    return BrqaRfJSvhP;
}

void LKxLNZjMOrTKyO::OFGSZZ(int hHztASiazfiIojL, bool psqmO)
{
    bool GgrtmoTMY = false;
    bool pbMLJsZwhCRPwm = false;
    string GnjKpLBTNun = string("EbKwoJoKTcuQyIvBZmQHZTmbSvtNqCuiOMJaRUlFldYHqrpsNUjunkZECpawkVWcTLPsTKNqitejsNCmMLNOgcHoKMMsApDYWJCYTsSUbVWIYqEpTaFpoCPUAuvgvHukFQLuwZmaasKbAPrAAltzBlkBgcLWBxSdHQvKgCFymlOxeBbSZiDZDfDZPsHiJGPAJtAqOCNwayIaqdLyEbYptjoPFsCmxkvZDsrtcgLTcyPiItDWor");
    int cjARBlzuB = 1267641573;
    bool OCknlFiNkV = true;
    int wXAMVzZDqz = 436263606;
    string nwYhIsfDGhMjg = string("KfrUiXkXSfNmkQzLHknDBFuvrEKVcaRfkUrYglGyxqQpmXQegAgzowQDBpHcTDvIYNQVWnFMGyxHglbrelLXdKMVTRjtMbtfPrSDJbsCZOWVDomil");

    if (OCknlFiNkV == true) {
        for (int hLujLRTYK = 1757819731; hLujLRTYK > 0; hLujLRTYK--) {
            continue;
        }
    }

    for (int uxPmgkBt = 1304589132; uxPmgkBt > 0; uxPmgkBt--) {
        psqmO = GgrtmoTMY;
    }

    for (int otpRZDqUmrBKMKe = 1711484110; otpRZDqUmrBKMKe > 0; otpRZDqUmrBKMKe--) {
        OCknlFiNkV = psqmO;
    }
}

bool LKxLNZjMOrTKyO::OdVpvNIIMBYwMr()
{
    bool xwvakJWaJrSwqwX = true;
    bool pYuAojAGw = true;

    if (pYuAojAGw == true) {
        for (int HwfEyfKi = 522453660; HwfEyfKi > 0; HwfEyfKi--) {
            xwvakJWaJrSwqwX = ! xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = ! pYuAojAGw;
            xwvakJWaJrSwqwX = ! pYuAojAGw;
            pYuAojAGw = xwvakJWaJrSwqwX;
        }
    }

    if (pYuAojAGw != true) {
        for (int hYRuweRdnVMn = 924861671; hYRuweRdnVMn > 0; hYRuweRdnVMn--) {
            xwvakJWaJrSwqwX = xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = pYuAojAGw;
            pYuAojAGw = ! pYuAojAGw;
            pYuAojAGw = ! xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = ! xwvakJWaJrSwqwX;
        }
    }

    if (xwvakJWaJrSwqwX == true) {
        for (int JWvHCGJ = 1421117045; JWvHCGJ > 0; JWvHCGJ--) {
            xwvakJWaJrSwqwX = ! xwvakJWaJrSwqwX;
        }
    }

    if (xwvakJWaJrSwqwX == true) {
        for (int luoGZTwV = 1873419196; luoGZTwV > 0; luoGZTwV--) {
            xwvakJWaJrSwqwX = xwvakJWaJrSwqwX;
            pYuAojAGw = ! xwvakJWaJrSwqwX;
            pYuAojAGw = pYuAojAGw;
            xwvakJWaJrSwqwX = pYuAojAGw;
        }
    }

    if (xwvakJWaJrSwqwX == true) {
        for (int zHfEWpcFLeDc = 1031918598; zHfEWpcFLeDc > 0; zHfEWpcFLeDc--) {
            pYuAojAGw = ! xwvakJWaJrSwqwX;
            pYuAojAGw = pYuAojAGw;
            pYuAojAGw = xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = xwvakJWaJrSwqwX;
            xwvakJWaJrSwqwX = ! pYuAojAGw;
        }
    }

    return pYuAojAGw;
}

int LKxLNZjMOrTKyO::qTKiefaFyJ(int ioPRCozCA, string THSXWhKBKibLE)
{
    int FUFtaxJjSN = 1474808113;
    string FwFFOeupAiGUmsxc = string("aTVnxNpsb");
    bool eKCfblMIoGFzq = false;
    int XggAWDwN = 2143006875;
    string yHhQeZG = string("XErfOAyTTJkSHsFjCNmUpGoODfSnpsrpRJbJarIzseDYMldYfnOWjPBIiFYLvOLgJFhODfoVTcmmbxioOAjXKTmgFyqBwrlroJhXFjZqbLd");
    bool AYGHIViRIOcsaVUC = false;

    for (int WrOvNRnUIKS = 1270255841; WrOvNRnUIKS > 0; WrOvNRnUIKS--) {
        continue;
    }

    for (int HPrnCaDPmZRBAd = 1414424543; HPrnCaDPmZRBAd > 0; HPrnCaDPmZRBAd--) {
        AYGHIViRIOcsaVUC = eKCfblMIoGFzq;
        THSXWhKBKibLE += yHhQeZG;
    }

    return XggAWDwN;
}

void LKxLNZjMOrTKyO::dHIcoA(string NhCes, int JflOALBP, double UMoiZfQyUustmSVZ)
{
    double cWoeKIMTBQrqiZiv = -1026886.0969270038;
    string efkIlKAqM = string("CzmsDqgYFSFRlcPbjHsJkmNHOtdyCMxdFSOqnpwUeDmRwfyFCpeXbBcbmNMEBLYNXBegpKFCHNcPfgDphdEKmOfKFEVcgRFLAbZklNEskSyBeEdluZiqJAkjgUDRqevOvKtcKaLTxCKtmmOyaypWPzyUXOmpIePpKzajnQFLFhADWNZNlqeUMYXdubscQFeJeJvyzWZBuJNSdZwNinulPbgHZtWKwWIhRZZPTldCEBSh");

    if (NhCes >= string("CzmsDqgYFSFRlcPbjHsJkmNHOtdyCMxdFSOqnpwUeDmRwfyFCpeXbBcbmNMEBLYNXBegpKFCHNcPfgDphdEKmOfKFEVcgRFLAbZklNEskSyBeEdluZiqJAkjgUDRqevOvKtcKaLTxCKtmmOyaypWPzyUXOmpIePpKzajnQFLFhADWNZNlqeUMYXdubscQFeJeJvyzWZBuJNSdZwNinulPbgHZtWKwWIhRZZPTldCEBSh")) {
        for (int fExaChP = 790577152; fExaChP > 0; fExaChP--) {
            UMoiZfQyUustmSVZ /= UMoiZfQyUustmSVZ;
            efkIlKAqM += efkIlKAqM;
            JflOALBP += JflOALBP;
            cWoeKIMTBQrqiZiv -= cWoeKIMTBQrqiZiv;
        }
    }

    for (int jCEfzRulTGuyeRa = 393984747; jCEfzRulTGuyeRa > 0; jCEfzRulTGuyeRa--) {
        NhCes = efkIlKAqM;
        cWoeKIMTBQrqiZiv /= UMoiZfQyUustmSVZ;
        efkIlKAqM += efkIlKAqM;
    }

    for (int uylyehGH = 2046464349; uylyehGH > 0; uylyehGH--) {
        NhCes += efkIlKAqM;
        efkIlKAqM += NhCes;
        NhCes += NhCes;
    }

    for (int dRJrSD = 162030858; dRJrSD > 0; dRJrSD--) {
        cWoeKIMTBQrqiZiv += UMoiZfQyUustmSVZ;
    }

    for (int xsJtPyCTYnZpABY = 985802341; xsJtPyCTYnZpABY > 0; xsJtPyCTYnZpABY--) {
        efkIlKAqM += efkIlKAqM;
    }

    for (int NxUWmgG = 1544003789; NxUWmgG > 0; NxUWmgG--) {
        continue;
    }
}

bool LKxLNZjMOrTKyO::VeJNocOjCQ(double SDAxphXNmcqserSw, string mIFgWCFj, int wTfJUaugfSVJq, int BXLcWeup)
{
    string OSBWXElYIb = string("mSTXJzUlMaoTpKQinpHqKjjZUWiJqsdIBZczWVhtdpJnRcrquhFPTHXsmhduEeAMeqLdvPhlsyTiOHdLyEhZZPPYNdVgqLvNWcToIjwZ");
    int NjkPzuFt = 1991953369;
    int GOKIf = 928174039;
    double MbAsgPGTWKU = 114422.46031047967;
    int ieNsMIptXKlSpmwA = 2101036783;
    bool WLWLYe = false;
    double VtMbpNU = 46102.90189320016;
    int bxjtllmuw = -559319706;
    double CdSShacBXMWv = 952360.1431844396;

    if (wTfJUaugfSVJq < -982026890) {
        for (int UGDwXxYkSuKnjqb = 217779467; UGDwXxYkSuKnjqb > 0; UGDwXxYkSuKnjqb--) {
            wTfJUaugfSVJq *= ieNsMIptXKlSpmwA;
            WLWLYe = WLWLYe;
            MbAsgPGTWKU *= VtMbpNU;
        }
    }

    for (int qTBPGkrF = 837810127; qTBPGkrF > 0; qTBPGkrF--) {
        BXLcWeup -= ieNsMIptXKlSpmwA;
    }

    for (int mCOubyTTn = 237513375; mCOubyTTn > 0; mCOubyTTn--) {
        ieNsMIptXKlSpmwA *= bxjtllmuw;
    }

    for (int VUHYm = 946336167; VUHYm > 0; VUHYm--) {
        mIFgWCFj += OSBWXElYIb;
        GOKIf *= GOKIf;
        OSBWXElYIb = OSBWXElYIb;
    }

    for (int EYKxswTFW = 841710527; EYKxswTFW > 0; EYKxswTFW--) {
        continue;
    }

    return WLWLYe;
}

string LKxLNZjMOrTKyO::yXjVxScOSCuaPvY(int TLUiDidyLgW, string hiuKXLe, string qMCEblMu, bool orscWcmTxY)
{
    double rLVvhNHP = 621729.9607512273;
    double vxtwqShifVye = 878153.388330572;
    double AcUbnbvlRnXN = 751035.5323944073;
    string iRlVrOjjzKptPHoq = string("suPyDvghtubLvWRWqklOrQJCjAsweTuAdaVuNVAHfRBfVnGKAmkuaDkAKbpwWhaFpFGeMgmAX");
    bool wHLZhnccnAjrjr = true;
    int XZjcSG = -92863247;
    string SQjvqWHSytuoEex = string("caUqhBFQnXzZVPMMlzOykEbopzZMqxUexYVJDaPlfjIMFtPCcoInSEoYbOjH");

    for (int LscHcSIWQ = 784320621; LscHcSIWQ > 0; LscHcSIWQ--) {
        SQjvqWHSytuoEex = hiuKXLe;
        TLUiDidyLgW *= XZjcSG;
    }

    if (hiuKXLe >= string("NbTtujPNxviBZgrZWzWSnNzyGgbuJuRRYcLvjCEBvmLKIbeEJNcbtjnqEuDaNgxyWqsxaQlFaXVqRIrJbtPOQ")) {
        for (int npEOvKX = 1887106932; npEOvKX > 0; npEOvKX--) {
            rLVvhNHP *= rLVvhNHP;
        }
    }

    for (int PoOWIsmD = 78884115; PoOWIsmD > 0; PoOWIsmD--) {
        SQjvqWHSytuoEex += iRlVrOjjzKptPHoq;
    }

    if (AcUbnbvlRnXN >= 878153.388330572) {
        for (int QHIvRh = 914388161; QHIvRh > 0; QHIvRh--) {
            qMCEblMu = qMCEblMu;
            qMCEblMu = iRlVrOjjzKptPHoq;
        }
    }

    for (int ygoFtQtdNYPBoK = 1444622302; ygoFtQtdNYPBoK > 0; ygoFtQtdNYPBoK--) {
        continue;
    }

    return SQjvqWHSytuoEex;
}

bool LKxLNZjMOrTKyO::gafxmEfcMWGslDS(int TcwQdUfidIvhi, string wnhmlWFbYIJ, string TToljcW)
{
    double qrOJCUrzJcKoTj = -181291.43219306387;
    string sFXerRLIylhaHUPr = string("CziTUWaPMHWdRvUdClOzmElnRVIirLxIhHaHPuoDLitcE");

    for (int makvKaLNhvYtMqbk = 1764834411; makvKaLNhvYtMqbk > 0; makvKaLNhvYtMqbk--) {
        wnhmlWFbYIJ += TToljcW;
        wnhmlWFbYIJ += sFXerRLIylhaHUPr;
    }

    if (qrOJCUrzJcKoTj > -181291.43219306387) {
        for (int LCCQzcSwYixUpBu = 587791348; LCCQzcSwYixUpBu > 0; LCCQzcSwYixUpBu--) {
            sFXerRLIylhaHUPr = wnhmlWFbYIJ;
        }
    }

    return false;
}

int LKxLNZjMOrTKyO::gIYshE(string LprhtERqhVlNbHC, double KBVZma)
{
    double ExkheMRsCJ = -722694.9519907373;

    if (KBVZma < -506147.19197572925) {
        for (int TOPPiuk = 1385588038; TOPPiuk > 0; TOPPiuk--) {
            continue;
        }
    }

    if (ExkheMRsCJ > -722694.9519907373) {
        for (int lWniKtTZT = 941584225; lWniKtTZT > 0; lWniKtTZT--) {
            ExkheMRsCJ -= ExkheMRsCJ;
            ExkheMRsCJ += ExkheMRsCJ;
            ExkheMRsCJ = ExkheMRsCJ;
            KBVZma += KBVZma;
            ExkheMRsCJ -= ExkheMRsCJ;
            ExkheMRsCJ *= KBVZma;
        }
    }

    return 853445206;
}

void LKxLNZjMOrTKyO::ymfanlhJAKx(double FqqCCo, string vUTxx, int dPSYeSzkUnZsMf, double sxKkXJYGzRaYX, string JRWadtgvZzytmx)
{
    double fHcCeiSxbhmgyCD = 704146.8667568122;
    string zpBFypwv = string("rAMyTUjXDxJigjYdpxHuAXrHhlmXZieqSWORnMJoPsWVRxbCmgvhOXrfehPhtJSHWNhnDMzPGkipnRGshiKZRrkKBwpKNFxIMboCxGvpCnjpcRIaLiPDyBCaDOQkAeypoUjjspZzsiToSIgBnyVsUmLKdHTdXpvvNAHtWsXJcftRvhqwcvIugebEjFnLmRlOjDFvxPaywqQvVhMoWdXNdpiHUEWCztxKNuaXRSWHNFNPrGadGTi");
    int rtuAZXFcEm = -2000837123;
    bool mXyGdvWdwotiMXtX = false;
    string wUbUY = string("bRqzLKwBPKMmxjquy");

    if (fHcCeiSxbhmgyCD < -65787.33839332056) {
        for (int pVPmegaEso = 46265796; pVPmegaEso > 0; pVPmegaEso--) {
            vUTxx = vUTxx;
            vUTxx += vUTxx;
        }
    }
}

double LKxLNZjMOrTKyO::XVoct(bool IeZbDApksEvGz)
{
    bool HXVVeK = false;
    double BMYrfeGII = 578208.7791498717;

    if (BMYrfeGII > 578208.7791498717) {
        for (int QWAOWSBZNBXjMkHu = 1310636105; QWAOWSBZNBXjMkHu > 0; QWAOWSBZNBXjMkHu--) {
            IeZbDApksEvGz = IeZbDApksEvGz;
            HXVVeK = IeZbDApksEvGz;
            IeZbDApksEvGz = IeZbDApksEvGz;
            IeZbDApksEvGz = ! IeZbDApksEvGz;
            HXVVeK = HXVVeK;
        }
    }

    if (HXVVeK == false) {
        for (int bqbWZZz = 806682717; bqbWZZz > 0; bqbWZZz--) {
            IeZbDApksEvGz = ! HXVVeK;
            IeZbDApksEvGz = IeZbDApksEvGz;
            HXVVeK = IeZbDApksEvGz;
        }
    }

    for (int BSWHwXdn = 1940887035; BSWHwXdn > 0; BSWHwXdn--) {
        HXVVeK = ! IeZbDApksEvGz;
        HXVVeK = HXVVeK;
        IeZbDApksEvGz = ! IeZbDApksEvGz;
    }

    return BMYrfeGII;
}

double LKxLNZjMOrTKyO::xRajnHdfYAQW(string GRIyx, bool nxiuu)
{
    bool MQrwmvEfofsN = true;
    bool CKdodrnoWRyQGin = false;
    double wwvvgtAckQvt = 217967.655032376;
    int Tjavoi = 548579113;
    bool gHlwmayTZl = true;
    string FaoUp = string("iaFzrJLUDJDEBtKlkMTSWwHTkrRLLwAzqhBVlcNBSXmAFNfMKOaspVDlNRRwcgxFgRNlPYnNeviparCtGCQcTbJazSuTFLwYCfQAXDwZIYFolrtMPdJoAmdSmkbxsKmqFqk");

    for (int nktscyiwalKHm = 1532274913; nktscyiwalKHm > 0; nktscyiwalKHm--) {
        GRIyx += GRIyx;
        Tjavoi += Tjavoi;
        GRIyx = FaoUp;
    }

    if (gHlwmayTZl == false) {
        for (int mnMlWY = 415692063; mnMlWY > 0; mnMlWY--) {
            FaoUp = GRIyx;
        }
    }

    if (MQrwmvEfofsN != true) {
        for (int oLXLD = 502248097; oLXLD > 0; oLXLD--) {
            gHlwmayTZl = ! MQrwmvEfofsN;
        }
    }

    return wwvvgtAckQvt;
}

int LKxLNZjMOrTKyO::ymcfGHhi(double OzPZKc, bool HnGXFCnlABgvj)
{
    string bPtfdYQXvBks = string("xBepjuuydnDSOWswgmihFpkYtzwKereDcKrWcSZxinheIXhTDLcdArTmelUDfIDhDyEmiVgEhHapoObTtVMPuIunBfjYhXZcSpXMKQVmmwSrndgHLhBbGdxDNSxhMQxrNoDYiehmTpMrHndBpOPAjwlzYT");
    bool ANSWLypGyrfa = false;
    bool stjEoaVTiyQbrhT = true;
    int cbrYZAhQtg = -829326807;
    string dGWXnHTJSvpbraQf = string("wvrSgmmCsFuRgNmWaqexySAJNQqPgISyNyVDvBWyHRCiSiCkbjRACOANuIlkGKTTFDMTPFVaOSgTfEkwoNDteRrKunLOFCNeAzOMfgyaDWIYWTrFTf");
    double XUkLuYWTJd = -642636.5751255472;
    string jipYtAd = string("nhYuMJamgABIXVCatknLNbQtitzlFMMhIRVRJftnYEScRCqRnmUcgHDWdNqCEvmbVilyQtZHIpglWCHwgCBqrBYrUaIsijHpnwAFdgwVUezEECJOLQnziGfNvCViGtgAHFCjVJsUUzzmhLCMF");
    double RBDXQ = -454764.1156838576;

    for (int XthPTxypyTLJCv = 1462977990; XthPTxypyTLJCv > 0; XthPTxypyTLJCv--) {
        bPtfdYQXvBks = bPtfdYQXvBks;
        bPtfdYQXvBks += jipYtAd;
    }

    for (int ZqCny = 1111711461; ZqCny > 0; ZqCny--) {
        continue;
    }

    for (int QUWpDBpKJWzvgQd = 1723570042; QUWpDBpKJWzvgQd > 0; QUWpDBpKJWzvgQd--) {
        OzPZKc -= OzPZKc;
        XUkLuYWTJd -= XUkLuYWTJd;
        ANSWLypGyrfa = HnGXFCnlABgvj;
    }

    for (int yKdyjaQjcPbTrcp = 370819145; yKdyjaQjcPbTrcp > 0; yKdyjaQjcPbTrcp--) {
        dGWXnHTJSvpbraQf += dGWXnHTJSvpbraQf;
    }

    for (int jbkllathvLxG = 108551854; jbkllathvLxG > 0; jbkllathvLxG--) {
        XUkLuYWTJd -= OzPZKc;
        ANSWLypGyrfa = ANSWLypGyrfa;
    }

    if (RBDXQ != 819997.734945213) {
        for (int jFbJMmfcmAT = 1132171498; jFbJMmfcmAT > 0; jFbJMmfcmAT--) {
            OzPZKc /= RBDXQ;
            OzPZKc *= XUkLuYWTJd;
        }
    }

    return cbrYZAhQtg;
}

void LKxLNZjMOrTKyO::QskDfvPGQJaE(string xtNAxXWDLmMTb, int TVMjXKxsWmTjWD, string rVDuXwUKE)
{
    int qyXXPFRGAMRVe = -1970726447;
    int nbnuKiKX = 1925511651;
    string ECsaUAo = string("gAersM");

    for (int LRQsWnsqmBcO = 1545841789; LRQsWnsqmBcO > 0; LRQsWnsqmBcO--) {
        ECsaUAo += ECsaUAo;
    }

    for (int WXRKdq = 2086669848; WXRKdq > 0; WXRKdq--) {
        rVDuXwUKE = xtNAxXWDLmMTb;
    }

    for (int FymrqPacxeQY = 1952169022; FymrqPacxeQY > 0; FymrqPacxeQY--) {
        xtNAxXWDLmMTb = ECsaUAo;
        TVMjXKxsWmTjWD *= TVMjXKxsWmTjWD;
        xtNAxXWDLmMTb = rVDuXwUKE;
        TVMjXKxsWmTjWD /= qyXXPFRGAMRVe;
        nbnuKiKX -= qyXXPFRGAMRVe;
    }

    if (nbnuKiKX == -1970726447) {
        for (int UkyCFBqIS = 551913835; UkyCFBqIS > 0; UkyCFBqIS--) {
            ECsaUAo += ECsaUAo;
            rVDuXwUKE += xtNAxXWDLmMTb;
            ECsaUAo += xtNAxXWDLmMTb;
            nbnuKiKX += qyXXPFRGAMRVe;
            ECsaUAo += ECsaUAo;
        }
    }

    if (TVMjXKxsWmTjWD != 1805277101) {
        for (int nLXZqg = 801854801; nLXZqg > 0; nLXZqg--) {
            qyXXPFRGAMRVe += nbnuKiKX;
            rVDuXwUKE += xtNAxXWDLmMTb;
            rVDuXwUKE += rVDuXwUKE;
            ECsaUAo += ECsaUAo;
            ECsaUAo = xtNAxXWDLmMTb;
        }
    }
}

int LKxLNZjMOrTKyO::hfjUt(bool kcEDVYyy, int ZgkjkFpahcP, double xKvxSEmomoIwpw, int ztaIMZGi, double cKhnEtvGTrGiUBlS)
{
    string PyEoz = string("MfXuLfjvjiKbVCqbukmmABxPBuJioIejfddCJfVVghXwQAoHmZdVKvKhPfADetEKninHoXxQsmICsiQxhzhXIRhQJpHvugnATBITDteaCtStuJOJsdBBnADUOeHLtRwgFvWkHyeaaJFwRtVMjWwjQeBwAPBNFhARwOLrjjcpNvkxarRMGUdfToMLxCcGJERhKYgZswuwNvtJuMDXKycS");
    bool yOZiLCOdhSkaN = true;
    string bQVPqd = string("BiwapVpsCxubSGEWjcIfTbrDsYlcQAiFaePzPDYBGuruoBEHAkuSNWTXVLDvSgXSswxFWXsWsabynumpzgxqtBJTJNDbfZqWrPKwZerppVhadMfPKqjcEUUXASDwNbdpJsQTYECDQRpvWQtakjIMeABrixTIxsAJShofBpmRqVhTogjkzXRrdGFecYbHiriqvIYF");
    double yXyuSBeFweWdmjr = -820085.9022814091;
    double iojRrdwCfAo = 426060.40115743416;
    string jzYCUNyjsQEh = string("mZhvjRJiELxEFnbxddVitRbsPIxaVcklcTKGgWYAmjyDKDCrwqTQxd");

    for (int nDYaKNrJ = 1405176001; nDYaKNrJ > 0; nDYaKNrJ--) {
        xKvxSEmomoIwpw *= cKhnEtvGTrGiUBlS;
        iojRrdwCfAo = iojRrdwCfAo;
        cKhnEtvGTrGiUBlS /= iojRrdwCfAo;
    }

    if (jzYCUNyjsQEh != string("BiwapVpsCxubSGEWjcIfTbrDsYlcQAiFaePzPDYBGuruoBEHAkuSNWTXVLDvSgXSswxFWXsWsabynumpzgxqtBJTJNDbfZqWrPKwZerppVhadMfPKqjcEUUXASDwNbdpJsQTYECDQRpvWQtakjIMeABrixTIxsAJShofBpmRqVhTogjkzXRrdGFecYbHiriqvIYF")) {
        for (int uFZFwoevFSCrMLuC = 138001447; uFZFwoevFSCrMLuC > 0; uFZFwoevFSCrMLuC--) {
            PyEoz = PyEoz;
            iojRrdwCfAo /= cKhnEtvGTrGiUBlS;
            PyEoz += jzYCUNyjsQEh;
        }
    }

    for (int ZaqAmw = 1335277210; ZaqAmw > 0; ZaqAmw--) {
        yXyuSBeFweWdmjr = yXyuSBeFweWdmjr;
    }

    for (int cwFuwDvmQNWHGm = 1492721370; cwFuwDvmQNWHGm > 0; cwFuwDvmQNWHGm--) {
        bQVPqd = bQVPqd;
        iojRrdwCfAo += iojRrdwCfAo;
        iojRrdwCfAo = yXyuSBeFweWdmjr;
    }

    for (int BFAorVlPMzmE = 1724514980; BFAorVlPMzmE > 0; BFAorVlPMzmE--) {
        ZgkjkFpahcP = ztaIMZGi;
    }

    return ztaIMZGi;
}

bool LKxLNZjMOrTKyO::aQkVMYxgZJ(bool QGpjjvCJNCm, bool xwyHMZiQakTqXXbV)
{
    string ugopLTFELA = string("HBLIBRtBMgBgMUDpJYrvySRDJpqCtBt");
    bool spaNLIapjBje = false;
    int evmSRuzkwgL = -440934133;
    string UZthsbsceCcaEIPE = string("qkZklsHwmvWHBxVrlWDuWPNhznqhEvXIFnXYFicknbXDvaGXWdjMYSFEKoCJhGzlIeFAAbesFjcftfWUTobdxaHhRIABSbVIcMRTrPcrotEYuvPfiCszsdeXGmQGpmszgqMsElmXxgYRgNHZkNXhigdoHegVdmPGgnOnWq");
    string aPLOpWwBYeRZgZ = string("bJYYJuceKPpuggXLHyIDjYbGWhhvYzDhcFRSscCFjSjlDVRjUgMlZWcPTOeKkPGroAXsGRnmZmjcCHqPowVgKROuzYPzkaikeuoidPfTJOeyWTuTvrHfUnlhPBVqSkvwBkEXJejJKCYogDnuXbVorwYdsPsd");

    if (ugopLTFELA == string("qkZklsHwmvWHBxVrlWDuWPNhznqhEvXIFnXYFicknbXDvaGXWdjMYSFEKoCJhGzlIeFAAbesFjcftfWUTobdxaHhRIABSbVIcMRTrPcrotEYuvPfiCszsdeXGmQGpmszgqMsElmXxgYRgNHZkNXhigdoHegVdmPGgnOnWq")) {
        for (int SmsDZTWaqDKA = 1720850861; SmsDZTWaqDKA > 0; SmsDZTWaqDKA--) {
            aPLOpWwBYeRZgZ += aPLOpWwBYeRZgZ;
            QGpjjvCJNCm = QGpjjvCJNCm;
            spaNLIapjBje = xwyHMZiQakTqXXbV;
        }
    }

    if (UZthsbsceCcaEIPE > string("qkZklsHwmvWHBxVrlWDuWPNhznqhEvXIFnXYFicknbXDvaGXWdjMYSFEKoCJhGzlIeFAAbesFjcftfWUTobdxaHhRIABSbVIcMRTrPcrotEYuvPfiCszsdeXGmQGpmszgqMsElmXxgYRgNHZkNXhigdoHegVdmPGgnOnWq")) {
        for (int ZTKvwhMjpg = 1700919513; ZTKvwhMjpg > 0; ZTKvwhMjpg--) {
            QGpjjvCJNCm = QGpjjvCJNCm;
            QGpjjvCJNCm = QGpjjvCJNCm;
        }
    }

    for (int OnLhrJXu = 1747705337; OnLhrJXu > 0; OnLhrJXu--) {
        UZthsbsceCcaEIPE += UZthsbsceCcaEIPE;
        aPLOpWwBYeRZgZ += aPLOpWwBYeRZgZ;
    }

    return spaNLIapjBje;
}

LKxLNZjMOrTKyO::LKxLNZjMOrTKyO()
{
    this->xNaoXPhiBCpOBgGE(-1091022225, string("FiEZNcTUhOjtiINgwQXAQPWNZsicu"), -686755081);
    this->bzOXXJolQrNb(-1562967113);
    this->XHklc(1779505101);
    this->AfzsrP();
    this->qvlIkpPBeaAsdP();
    this->dJtWbU(false, -348908.21031985804, -2133453211, 258185.8475668789);
    this->OFGSZZ(-382302751, false);
    this->OdVpvNIIMBYwMr();
    this->qTKiefaFyJ(1107182560, string("BeShLSQDnzHSHLwGQmHcfkSfTflMJbpCWqEFsWTHIRKUhmKqhfgWJcMiKVRzJrUMVKrQaoBhRRJgapcWbWeEovpOEWnKpOUbnndyEOlotgTFMMWodddSnUJDdRrcKgaynSceeeLCEaJzDRVDwrg"));
    this->dHIcoA(string("ppllnNnSjefgpKyjblGIcuKucoizuEAPhkEhvCdhTztSSpxLGYrBqnDJvdhDEubCniitbqfrmZvHEwSkAYbheCGKnTQwhxeRuGbanoEIiZvEqCTSsYRo"), -441549959, -882277.6683726696);
    this->VeJNocOjCQ(971844.2182846076, string("fWGioZeDLxpSwtjNdTyFqRxeFFSIwpEPYhDsQQLvfsVALmdYQKyvBbwQLBUYFpsuPfngzxRmdSrNTqqNxBAGvdjwxlfMpKvZiwJXqGoISkqjLRLMDlhfKURbd"), 60385874, -982026890);
    this->yXjVxScOSCuaPvY(-1175009587, string("LrcmovVsTycTbveZtbgPkwirRwubVuIeBrdigPlitpeVkVJtHzbmMrHMUEysdLplyLbbXOwNXEoHFBcrcUJNiCflhUnFiUqHRdBFqT"), string("NbTtujPNxviBZgrZWzWSnNzyGgbuJuRRYcLvjCEBvmLKIbeEJNcbtjnqEuDaNgxyWqsxaQlFaXVqRIrJbtPOQ"), false);
    this->gafxmEfcMWGslDS(253512906, string("dHIcWnyQJQQpnwiNkLAvTMhDwuJeuwfALMDTmSZdomRpMVbALBGdWSoHqQgWwiBZVRLedShMByLTlFIZnAYlYNSLMKdfrBqpLbECBwzIsOinGLILWIoGNHkWkZiSHsaBLrfIowWYxEOwtlQVFIjHablNWqrnhheYnMnFYvGZeEokXLQcnFiWYQViuwEepyyQgKyTnnDTrbyScMgfZMHSNTCZijVZBBSMeceWvcZKhxdKyY"), string("MIiGrygkyGEEgBIqMze"));
    this->gIYshE(string("mzsxVYeDdSLZnRWiZldhAgsxSySijZPDiCDamUgqyXerWhXlrWmNZCgNznVQinDGZdp"), -506147.19197572925);
    this->ymfanlhJAKx(706102.3611017439, string("dlsBHoLcVXyogYziVoHJIQwZiAKSQyWFkJTgnYziWivDHtEEgKjPAlTkdCSVipYOHpQaIfCsipjAvrBaIPewlCSGLbFCkEzkImKWPkuRIaWPpFSfRgVFXJmoPkNaNvIhzITNnjcYRdAuYxjITwcRUKtRigs"), 1979482587, -65787.33839332056, string("iRmodcDZJuaqjTFLChBOsQRlqRSRwUugubN"));
    this->XVoct(false);
    this->xRajnHdfYAQW(string("sXRwvbflStziEdUlxzxJBDlRxwmaWvzIzCSLmwfizVSWlyxxfOwiXJbxSIoRUGJVPGGDUbdmvfleyGRqIWePHrIMhIltmLGvNrXppopgvpkopkGoFYUdgjOoveaROYAUlKpEUKgPCAGGIYmoJXFXewuHLrnBoGXNRyNLcQQalvHGLRehmgzQFku"), false);
    this->ymcfGHhi(819997.734945213, false);
    this->QskDfvPGQJaE(string("HBhKhStpIvDPCSyPPxQdOSdFnzWLBnHHLsECyzCJVQhrdSayGFFKvOOxlSXupIJphpKLJgNSUgEUzsXjujOtoZqhXNBzyc"), 1805277101, string("DFlUqgEtfALgLkqwGZsoSzGYoaSyLQTkqWIfsaKLEstbtjrNyInqDucQkehplvfgwUWNoqzXolFIQaYNfJrCyhXCUzVHLxyMjebkSVboXyoZCSosnRumFrtTTxMWVcBBpYRwLmHbqzGwWWXPJiYGIckODlQmVVwNEBHvuQQDYuJbpYUYwIdiICiHEdALEHkznkYNabCzz"));
    this->hfjUt(false, 1756889067, 872382.07248874, -576178022, -938936.878937837);
    this->aQkVMYxgZJ(true, true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CukfDrjuucBco
{
public:
    double SvMdEhtjrBMIN;
    bool nugoVJ;
    int BtLyhoDKshlRNkF;

    CukfDrjuucBco();
    string DauYcOSxLGqVa();
    void IeQoqGRmDOawcr(string xchgJnBgxafNk, double IgMiwd, bool BIXFLvSWOhyJpxG, double sGPdSytqNpIl, double YnXVSQNzgdIHXPAt);
    string qqwGmRVjIWgVhA(string QSYQknFdI, double OoLByxiUkkho, double YXYByGPHQnnyzR);
protected:
    string pCLUeJYIgfkRYlY;
    string agJimJGDFJho;
    bool gUBAMQAzKTkJ;

    int JDbXrYrOXben(double ucVCvF, double OlBoAOArqWb);
    void ydkimTNu(int cRJtDAGpVkHLmhBY);
    string fWLtgxIXqFl(bool IXDkhpNhFl, string mcTSH, double bFNow, int YwiMFiaXyAwpdx, bool OGHtZwREXRia);
    void LjzIvyAzXW(double bTdElKStu, double AElsmwTkdzReYVl, double dtVvMGNkKDF, bool eqSYE, bool msZwzRJLcBVmo);
    int xfQRDB(string uTmpPKWF, double sMchgZnPDcU);
    double dLqRGgYfVttsWG(string wKUwvmiybWOnUIu, int vfQmBGTGpsiyC, int lxxzFXMHwU, double JPosWDUE, bool reEmLtR);
    string npyROIWS();
private:
    string JKBUlOVIrNaRZ;
    double AhhGgncYhVnpX;
    double rIDUjBDCuDS;

    double xjFSBBMJEg(int vrtIZhZldzPn, int naZKzoigeYWiRPBN);
    string YwBESe(double McILqnuRdSdMIsX, double MVEXHVvLVMAoiu, double RcxGZKidJjmVgQIN);
    void vBZDXEkdm(string xawACQH, int lDEUmPLdMlPxKNoK);
    string cjCByWtHrfKQWvE(int ItQqK, string vzxzonNmtJLqCStS, string SxLVZcoNyKwAYjr, double mEZGTVOUHsVIrau);
    double jRhgxImKl(string pqsgFTMMmBzQK, int HrzuklKkEXSN, bool GyMdNS, int bWPwfDJmtBiZ, string LkwXlGBZjSUDL);
};

string CukfDrjuucBco::DauYcOSxLGqVa()
{
    double gJvcJ = 685921.5986598956;
    string BYYuTaeRBPa = string("yMUEddkNicUjqKYTqnCvkcSsBuOszuVMXhbdtVjYnxcEyNibwyOVUvexHqKcIAoLjNxIxVUfuImtUssavEyAqPQCxnakurBNbCHNkpUOkHPqLPZELyvRUCcnTJhZkhL");
    string KHasuRmkZJTeJOw = string("zYqYraeFqlBtuUtSPnVznCKnJPQZaNQEdUyySbAVMEFoCGToQGGasyVGXBTEfUSlnXihJRJeDdMMukLdGZzwWJLFlQMmppnhHeIcfhOBRLaGvqPtmjuGEBeTwKTRkvcZxpacSYOoeupVbaZuqGXqyzUlIKDCOkQwYXgSMrTuKjfFUmdjhaJE");
    double YiAiE = 575543.933721787;

    if (gJvcJ <= 685921.5986598956) {
        for (int nbNPoGteXVF = 1957792197; nbNPoGteXVF > 0; nbNPoGteXVF--) {
            YiAiE *= gJvcJ;
            KHasuRmkZJTeJOw += KHasuRmkZJTeJOw;
        }
    }

    if (gJvcJ != 575543.933721787) {
        for (int jwODXwpYKsSFXj = 1585919550; jwODXwpYKsSFXj > 0; jwODXwpYKsSFXj--) {
            gJvcJ = YiAiE;
            KHasuRmkZJTeJOw += BYYuTaeRBPa;
            BYYuTaeRBPa = BYYuTaeRBPa;
            BYYuTaeRBPa = BYYuTaeRBPa;
            YiAiE -= YiAiE;
            YiAiE *= gJvcJ;
        }
    }

    for (int rBKrGYWnirWZAtf = 2071583700; rBKrGYWnirWZAtf > 0; rBKrGYWnirWZAtf--) {
        YiAiE /= YiAiE;
    }

    for (int WtyNbLtlqtcp = 535606513; WtyNbLtlqtcp > 0; WtyNbLtlqtcp--) {
        gJvcJ *= YiAiE;
        BYYuTaeRBPa = BYYuTaeRBPa;
    }

    if (gJvcJ <= 685921.5986598956) {
        for (int DdfAbHOgPGRKQ = 1859901648; DdfAbHOgPGRKQ > 0; DdfAbHOgPGRKQ--) {
            YiAiE += gJvcJ;
            YiAiE += YiAiE;
            KHasuRmkZJTeJOw += BYYuTaeRBPa;
        }
    }

    return KHasuRmkZJTeJOw;
}

void CukfDrjuucBco::IeQoqGRmDOawcr(string xchgJnBgxafNk, double IgMiwd, bool BIXFLvSWOhyJpxG, double sGPdSytqNpIl, double YnXVSQNzgdIHXPAt)
{
    int MmvahmnNWq = 719975779;
    string kcxEwhLQwspAzm = string("IoCZHibBEfAKyYGjsKiiAjyjHoVgHRmvdcJNPbpYGTsLAhPvFDqcOWcUUAWrLKsZLNxvxVMvRZZkmkJAxNOPPkhEAYljwNFspdaTAUfcbzzsGxQVvZZtrmYbleMaMKubalPIsoelwirxMfEXkPlY");
    double OFVJMFMJMGLXwoLf = 146141.75612685044;
    bool pSacDxEwioS = true;
    string ADXBHtRLeXKRarON = string("sMmyMdgtZKnQyjROFlbyrycptIAdhYCaWiCqUwigsoMNoBSqDZCMhYyIJmYXfhJlcxVnxEBLfzDoXgQYwZYEOBeHWBsLxrAjIDjvWJWGCuhWJbuLQvFhPCRJzXjqUDcsVPiwjvrDbnAFHadBcoDuatQkgyzxrqDjPBOahPQGOhFRxzlH");
    double RFgRMCLokY = 652952.6130368137;

    for (int geKQdQnDkOYTKp = 551661216; geKQdQnDkOYTKp > 0; geKQdQnDkOYTKp--) {
        RFgRMCLokY -= RFgRMCLokY;
    }

    if (RFgRMCLokY > 652952.6130368137) {
        for (int WpeaBXDRzmlnNuVw = 451448465; WpeaBXDRzmlnNuVw > 0; WpeaBXDRzmlnNuVw--) {
            pSacDxEwioS = pSacDxEwioS;
            kcxEwhLQwspAzm = ADXBHtRLeXKRarON;
            sGPdSytqNpIl /= sGPdSytqNpIl;
            YnXVSQNzgdIHXPAt = OFVJMFMJMGLXwoLf;
        }
    }
}

string CukfDrjuucBco::qqwGmRVjIWgVhA(string QSYQknFdI, double OoLByxiUkkho, double YXYByGPHQnnyzR)
{
    int lDNZLmAXHOZFhY = 1758787220;
    double EjKRLjvrXCSZkNOG = -640401.4571991016;
    int BkDQXgFZKA = -1301575914;
    double lvRYDztiDRu = -837449.4567447524;
    int UoQpNlFUdDKvjfM = 22374494;
    double bvQvcQTxA = -841813.2298787913;
    bool jREkru = false;

    if (bvQvcQTxA <= -841813.2298787913) {
        for (int BaiJCbUCJODA = 193692975; BaiJCbUCJODA > 0; BaiJCbUCJODA--) {
            EjKRLjvrXCSZkNOG -= EjKRLjvrXCSZkNOG;
            bvQvcQTxA += bvQvcQTxA;
            BkDQXgFZKA += lDNZLmAXHOZFhY;
            UoQpNlFUdDKvjfM *= lDNZLmAXHOZFhY;
        }
    }

    return QSYQknFdI;
}

int CukfDrjuucBco::JDbXrYrOXben(double ucVCvF, double OlBoAOArqWb)
{
    int PWLERiHRtLgZ = -154774009;
    int DGURUXwc = 572905647;
    bool OgCYikwuE = true;
    double VbYdVThTGDiVB = -720310.4838336142;
    string tAfYeojldt = string("zMjiVKHUsTWE");
    double pzuGAuxhUxCkjaUK = -182943.7736054043;
    int LpqAyekdqg = 1504222344;
    int RhrXLPQrt = 1206663955;

    if (DGURUXwc != 1206663955) {
        for (int kcZPxpD = 128918612; kcZPxpD > 0; kcZPxpD--) {
            RhrXLPQrt = PWLERiHRtLgZ;
            OlBoAOArqWb /= OlBoAOArqWb;
        }
    }

    if (OlBoAOArqWb != -720310.4838336142) {
        for (int ZyAxYpsUcvmoO = 1366939385; ZyAxYpsUcvmoO > 0; ZyAxYpsUcvmoO--) {
            LpqAyekdqg *= RhrXLPQrt;
            OgCYikwuE = OgCYikwuE;
            DGURUXwc = PWLERiHRtLgZ;
        }
    }

    for (int IlhyRColME = 1457208094; IlhyRColME > 0; IlhyRColME--) {
        OlBoAOArqWb += OlBoAOArqWb;
        LpqAyekdqg /= DGURUXwc;
    }

    if (VbYdVThTGDiVB >= -925245.0774533793) {
        for (int doKbaHkB = 985406373; doKbaHkB > 0; doKbaHkB--) {
            DGURUXwc -= DGURUXwc;
            pzuGAuxhUxCkjaUK += VbYdVThTGDiVB;
        }
    }

    if (OlBoAOArqWb > -925245.0774533793) {
        for (int BcMckxXDVPCrg = 1722290521; BcMckxXDVPCrg > 0; BcMckxXDVPCrg--) {
            RhrXLPQrt = RhrXLPQrt;
            OgCYikwuE = ! OgCYikwuE;
        }
    }

    for (int lRGbWsWUuRJJx = 192100753; lRGbWsWUuRJJx > 0; lRGbWsWUuRJJx--) {
        continue;
    }

    for (int qDJEv = 583067423; qDJEv > 0; qDJEv--) {
        OlBoAOArqWb += ucVCvF;
    }

    return RhrXLPQrt;
}

void CukfDrjuucBco::ydkimTNu(int cRJtDAGpVkHLmhBY)
{
    double JyJJWxsKsAx = -361648.1133840758;
    bool GgTMETjtELLYOzT = false;
    int czWyFtPV = 1506521055;
    double CVHEXX = -193251.84888934362;
    int OhCgBt = 1883487274;
    double ZPioMioq = -746183.4753170854;

    if (CVHEXX != -746183.4753170854) {
        for (int qDrpQU = 444595246; qDrpQU > 0; qDrpQU--) {
            cRJtDAGpVkHLmhBY = OhCgBt;
            czWyFtPV += OhCgBt;
        }
    }

    for (int lmtOWKdDVmjCCwhi = 2012790867; lmtOWKdDVmjCCwhi > 0; lmtOWKdDVmjCCwhi--) {
        continue;
    }
}

string CukfDrjuucBco::fWLtgxIXqFl(bool IXDkhpNhFl, string mcTSH, double bFNow, int YwiMFiaXyAwpdx, bool OGHtZwREXRia)
{
    bool RHwYsousWetNEzV = false;
    int OzgOsENDTGXfis = -1633262871;
    int QfcQaF = -1438765956;
    string OMjjBLclEaVT = string("zfabEeObreyJYAwsqojRawPoKYlPKzeiyKqikLhaWcfc");
    int NnWtmzKNYlWKNhZ = 1533479375;

    return OMjjBLclEaVT;
}

void CukfDrjuucBco::LjzIvyAzXW(double bTdElKStu, double AElsmwTkdzReYVl, double dtVvMGNkKDF, bool eqSYE, bool msZwzRJLcBVmo)
{
    double TaedwVRAkJs = 698213.1178134034;
    bool hxmeDpHlAxjP = true;
    string fwMDQzjpCXt = string("LUSQAjyLMocufITUCfBacDjvneXQeiikhdCVCGBSSrnWqWZMIZwdIHgDBfcFzCsQMXtNchomRTXlJbSUbsIuPFVHpknxXMFgIQwEywcpaiQCLAhePGXCqpNrmKHzezaAfyPkJxXgKhjONODyahpgNDKzVdCIPpSyghivTTwowGtKeNdbRELcJOvByNwRWcROxwaeshZnKVUlYvqm");
    int CpWIfscajqAE = 320756381;
    bool uWsbxupf = false;
    int pmMhyQLRWN = 994248924;
    double EnACvNCWSyX = 438455.427254412;
    int exMEC = -1436530018;
    bool ApjneMXfNPH = false;

    for (int GMzVrsW = 417831182; GMzVrsW > 0; GMzVrsW--) {
        bTdElKStu /= EnACvNCWSyX;
        CpWIfscajqAE = exMEC;
        exMEC += exMEC;
    }

    for (int sYPCVRElGXlR = 535628584; sYPCVRElGXlR > 0; sYPCVRElGXlR--) {
        msZwzRJLcBVmo = ! eqSYE;
    }

    for (int vXNwvKsDSzQRKeyN = 1228734379; vXNwvKsDSzQRKeyN > 0; vXNwvKsDSzQRKeyN--) {
        exMEC /= pmMhyQLRWN;
        EnACvNCWSyX -= AElsmwTkdzReYVl;
        eqSYE = ApjneMXfNPH;
    }
}

int CukfDrjuucBco::xfQRDB(string uTmpPKWF, double sMchgZnPDcU)
{
    double eVoDfAsX = 762891.799684404;

    for (int qsjaNmYiwov = 1073608748; qsjaNmYiwov > 0; qsjaNmYiwov--) {
        eVoDfAsX /= eVoDfAsX;
        eVoDfAsX /= sMchgZnPDcU;
        eVoDfAsX *= eVoDfAsX;
        eVoDfAsX -= eVoDfAsX;
    }

    return 1347653715;
}

double CukfDrjuucBco::dLqRGgYfVttsWG(string wKUwvmiybWOnUIu, int vfQmBGTGpsiyC, int lxxzFXMHwU, double JPosWDUE, bool reEmLtR)
{
    bool KaaEfOUcNaA = true;
    bool ySXlxEcLka = true;
    string YxEmau = string("IAuMgobdaWmLveHGldWoAmwAEAKPwAgqMLDSOQTxSooSihYpCHXKODUUsXqYQUDYjyFQgOWVqmWWcsrRHRsDCRCqILwDiwpoKIf");
    double yaUHyg = 738441.2877402765;
    double RZuaYmW = -766519.0736085182;
    bool qPikOFFII = true;
    double bPxmbqdOsf = 911476.0390607119;

    if (reEmLtR != false) {
        for (int ncfoyv = 1710848129; ncfoyv > 0; ncfoyv--) {
            reEmLtR = ! KaaEfOUcNaA;
            reEmLtR = reEmLtR;
        }
    }

    if (KaaEfOUcNaA != true) {
        for (int ChLODwBP = 315455899; ChLODwBP > 0; ChLODwBP--) {
            continue;
        }
    }

    for (int VYOFnS = 184911056; VYOFnS > 0; VYOFnS--) {
        continue;
    }

    if (RZuaYmW <= -766519.0736085182) {
        for (int NeFFGOBIvHHwQnEw = 19269616; NeFFGOBIvHHwQnEw > 0; NeFFGOBIvHHwQnEw--) {
            JPosWDUE -= bPxmbqdOsf;
        }
    }

    return bPxmbqdOsf;
}

string CukfDrjuucBco::npyROIWS()
{
    double pgndJ = 585978.9321800561;

    if (pgndJ > 585978.9321800561) {
        for (int vdrQRlwEymkAvXB = 1043601993; vdrQRlwEymkAvXB > 0; vdrQRlwEymkAvXB--) {
            pgndJ /= pgndJ;
            pgndJ -= pgndJ;
            pgndJ -= pgndJ;
            pgndJ *= pgndJ;
            pgndJ = pgndJ;
        }
    }

    return string("qHMXnRjsRUOZbvXEfVTTYuMAYWkVKCIeUGdpabKAPcmQrNOnwgdWnAOCauXdxCqwxdvPpwXydWNEdTayfAsHDuLiPiIYOGnEcXWBINNHdhzjJTLld");
}

double CukfDrjuucBco::xjFSBBMJEg(int vrtIZhZldzPn, int naZKzoigeYWiRPBN)
{
    string zwhRbapWp = string("efIRgMpDabhPXPv");
    bool sTDzMgpLxHxLaM = false;
    bool lidZC = false;
    int XgSYivwCsI = 354798403;
    int ycmfw = -1086564038;
    int rppquHuHLzjb = 1835275670;
    int FbOQNwBnB = 38229359;

    for (int YSPyUdLbnpWbW = 1230439174; YSPyUdLbnpWbW > 0; YSPyUdLbnpWbW--) {
        FbOQNwBnB = naZKzoigeYWiRPBN;
        naZKzoigeYWiRPBN /= FbOQNwBnB;
    }

    for (int KsNinuMZn = 1336369310; KsNinuMZn > 0; KsNinuMZn--) {
        rppquHuHLzjb -= vrtIZhZldzPn;
        sTDzMgpLxHxLaM = sTDzMgpLxHxLaM;
        lidZC = ! lidZC;
        ycmfw -= vrtIZhZldzPn;
        rppquHuHLzjb /= naZKzoigeYWiRPBN;
    }

    return -848170.8188318921;
}

string CukfDrjuucBco::YwBESe(double McILqnuRdSdMIsX, double MVEXHVvLVMAoiu, double RcxGZKidJjmVgQIN)
{
    double tXTwGP = 704433.6720630204;
    bool wMcBMFKfuoU = true;
    bool rTZVxHyxPzAzg = false;
    bool nKVhxuIykIk = false;
    string eaDqxAv = string("GcokzMelSUHapOOIojAMYJLmjskadEgQCRpVCgfpvbcKuKnJJAsBFKswYiQbLXUFAZgBqylwQzeixmleJODbHMtUovCcHXhrLXMosQbBLLLxhHKkYfSDXxjI");
    bool ubVuW = false;

    for (int tUKSTJfmk = 619801146; tUKSTJfmk > 0; tUKSTJfmk--) {
        MVEXHVvLVMAoiu = RcxGZKidJjmVgQIN;
    }

    for (int KwOVJytOKoklZ = 880813005; KwOVJytOKoklZ > 0; KwOVJytOKoklZ--) {
        nKVhxuIykIk = rTZVxHyxPzAzg;
        wMcBMFKfuoU = nKVhxuIykIk;
        nKVhxuIykIk = nKVhxuIykIk;
        eaDqxAv += eaDqxAv;
    }

    return eaDqxAv;
}

void CukfDrjuucBco::vBZDXEkdm(string xawACQH, int lDEUmPLdMlPxKNoK)
{
    int vyhFJeIRUdmQQ = 1917395587;
    bool sJgETHtwaGPHKg = true;
    double iHWXTbk = -97430.42067376905;

    if (lDEUmPLdMlPxKNoK < 1917395587) {
        for (int AtJUxvAYl = 1444419335; AtJUxvAYl > 0; AtJUxvAYl--) {
            continue;
        }
    }
}

string CukfDrjuucBco::cjCByWtHrfKQWvE(int ItQqK, string vzxzonNmtJLqCStS, string SxLVZcoNyKwAYjr, double mEZGTVOUHsVIrau)
{
    int pGGYGwKL = 1372688566;
    int umEMyVMBPvLJ = -465136010;
    int iuNALZtjdvS = -1128106804;
    double vfnwGussOVv = 152705.14247659783;
    bool MtYGZ = true;
    double JqVjStv = -451305.8684933341;
    int zoGsIeTAviGc = -1571693108;
    string nCdxyXDTnPmElnY = string("wQYdZsgfozyUOUcHPjhZDTAltnTZOfQRqzVVaWRrJFprgKCVmzvXKdONhShiOKmlkajpIOCWzbJbdbE");
    bool oxMXmd = true;
    bool MQrcPvGzQ = false;

    for (int QLzBABNhqOkjb = 167378539; QLzBABNhqOkjb > 0; QLzBABNhqOkjb--) {
        umEMyVMBPvLJ += iuNALZtjdvS;
    }

    return nCdxyXDTnPmElnY;
}

double CukfDrjuucBco::jRhgxImKl(string pqsgFTMMmBzQK, int HrzuklKkEXSN, bool GyMdNS, int bWPwfDJmtBiZ, string LkwXlGBZjSUDL)
{
    string EUDhSdskiB = string("ETGezgkCisRRntnPHErvMdXlRELlWmRiBEBLihNtyPYNNEnPrViwkYPnmmIoYoOonUCyEuEcyWQhMVKZXxDlIwPrDakJnqodzWrAnJfZqWjDoXqdYezlQohlDAOJuFOEEowzEejeltkYYBFfmaFrDICxmlMEsyFuWrRMGyNLkcZJoXlSApl");
    string HTtsorec = string("lbstXrRelZIbxXegjaduWIouuMFMrLfTjuhXGvfeJUepKUeBqYuMGesyEVzVmBKrbWqedQyUnMsjwQPxIXoVzbURWcawqCKXk");
    double AhrquFZDgoFEUOs = 709581.2995784916;
    int relXMfMJrc = -601013838;
    bool vzlTkAddPP = false;
    bool Sneqswr = true;
    string VEtupzRrQpWWiMrb = string("QcaLdjnLMkxKDSubXGmXDRZFXaLdkYRrFAsYjoDNeBnuyJpLrpFKWoTihyOydmiTsKOVKPiHFLIVYdMdfHBHmmmIdfKDXnHvTVXNMcXoYhfVSLioSuXtVPOpbgxCCWSToQZCHrsVnTMipuqpXUxUNEhSUQNJPlNyWDLmeaIFmlLencpatbiDxirwZAfkVxabVevqzvyNKhIX");

    return AhrquFZDgoFEUOs;
}

CukfDrjuucBco::CukfDrjuucBco()
{
    this->DauYcOSxLGqVa();
    this->IeQoqGRmDOawcr(string("tVJ"), -340004.9227117092, true, 827397.313217983, -377437.0440548761);
    this->qqwGmRVjIWgVhA(string("zPxSydUie"), 859688.943045818, 86639.55747351641);
    this->JDbXrYrOXben(-925245.0774533793, 30381.117883352028);
    this->ydkimTNu(-1675273572);
    this->fWLtgxIXqFl(true, string("KXoatrrlnIGYIpJXPojuEMdTCiQwaDrFxDQvQhmEjuztZuFITugzFUtnxXpLRIgDrCpGCRhGNfyJIFQQnYGknjYBdYBrGOYBSOQKEfrCEhRXGPVpLwwpdOAZmNXiVwhsNgTmkWYUEiLBUEXoYVSlFbMFGvomcRcmEUmICeuICOIVkwDMPuAZmfifomMzJZPRWSKZQWGejisPDevzUHjHwrwdM"), 856230.7293532693, -486674857, true);
    this->LjzIvyAzXW(584994.1943954125, -619568.3110049128, -629608.3464236401, true, false);
    this->xfQRDB(string("ymwnuigLfGYsnuJbqJbwwAoHvtBqzhGhnv"), -408316.3426490761);
    this->dLqRGgYfVttsWG(string("awYKxZRIarkQadwNYpOhCtZyNVnYBTwQMpBoQRiGxRvXmQIdOsQWtAHusKaIaQNzRWghCLkNOwjGWNLVwIlrnwLenVoxxfJBXWhFTuPRBzzWrvkcUccwMvWjMHuIqvCZaiXSuprtjuVawVHfoLlJNMsPLmjyliSmeqNZizEQWgGlmzMoJMWHFkhJaLfBgmSCOSuy"), -936959558, 188052059, -65126.183357753405, false);
    this->npyROIWS();
    this->xjFSBBMJEg(-2102672183, 764789544);
    this->YwBESe(-358140.09952443367, 25995.61187458801, 618964.0234902432);
    this->vBZDXEkdm(string("NnvBThaGprtKCTAQVMitiucgKljcAWCIezceKLHSSphYwCyyqHRthlSLIucRwChoBKpkHcIQCPWcFvoVxnsggZWJVPcgWCqWFdCxNoDRXCuWavqTdwDUWiTiwHfFzYGuDLvfsjnIzjzDigQETEjEMTyxOoSiNKCZoTJtGttlotXfjmsvDxbvaiYrR"), -2022097378);
    this->cjCByWtHrfKQWvE(-598783239, string("sBmPVnMBDBFOzApTMngNVNspqVVgTUfmqcljCVFLiwfERNfVcjPKXRsQzkitCzXiEwJvGOyLcHzkurZtLpDyqpKYKQReSsmtdlvoyNCdLqFRNgxQNCIgrNAFRUhqPZRmdRsISPGsDqIISSgjPJUzHpWxtVoFBnNvSYiIzMK"), string("PdXyZNJAulVXchkdBSXEAUuZaUhCLtjCEdLQYKQfJDputMgiUrXBMmZSnMctczvENKpIPOaXlWvlEqLSYgHRQVRbDuULvuLWbPvCSQxmbKBRqlpbKfXgCisyjnJHTcLRngixhaHk"), -196248.91143924015);
    this->jRhgxImKl(string("bkcoJmatkeSQyjVSkrffSZQUpFCmgcqtdmgMRfaRYaruSyznPkxLUexsgKIGSXUKGbvIiwWNvzXxJhQBwFiQOvdaKorwKKfMKBwMKRFwDffKTcBGRfxnrbrgWjXyqbVCIlKmhReQKWxGJsnrYDxDZfpZMiRIRBfJAfWdGCoeYuSHDfssCmQIFkxouAAtJphfCelDQTZniIFvwpRDXmNUUfSJu"), -788954816, true, 1734152848, string("SWNfvmpxKcmhprFoPpMsUsoivLWFyfmaLYTLTWzDHLshCiooSzNIOaubIVYJmzHaUOaZSgBemOTRSewbqnfWLOPwExtkzSQzDglNvODyUKHAfzIVWxdf"));
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class OKYhZpDTSMGiDJF
{
public:
    bool WhsgdqT;

    OKYhZpDTSMGiDJF();
    string CsWpPmQobM(string eYbAA, double EhGlCOcOKjP, string KEEAT, double vdYGCnsBQhQFhxKn, int zxzQsabkrVfZBSb);
protected:
    bool azVLYyvm;
    bool xtZECDPwrCsGm;
    bool xGGcKGfNIXEa;
    int cqPRVQwunvqiBcg;
    double FoIBTVLhgsT;
    string nkuEcCjifvXJgD;

    void OoagtZUOW(double TAtZMUg, int BpKHWbGWcimDcr, bool NILDqoiyVDIMRp);
    bool AMrzfHypsXv(double ulDEfACjVvxCZhw, int TFVgSEoCnA);
    void tSfLNoT(int COGuqSFN);
    bool AyuXJcKJaFu(int enQsLREt, bool qdhgMAliywLC);
    double PYMphhCTpgeKtN(string jUNUjfeHP, bool ukjfKIcl, double wOJlWXwKBBZ, int ydYhiu, double HSqNMlsz);
    int zudtZvx(bool iaEWGZwmZo, string KVmoetD, int cYqtGe);
private:
    bool qoXCFMvbof;
    int eLgZqdSJTY;
    bool fKTzQmdDao;
    int BpKcQeVX;

    double QvQtFBvXhmxxzx(int tDLIDFZrNzqPhnS, double jLUSmpnFQvZz, bool uapTUvNbMP, string ryfOPpmVBiXa);
    double vFshTNvDZ();
    bool yFRYXQXJ(int cEjawHluV, string eiTEEVMuNkZ);
    string LKImzyNWnZGjSXve(string VmAOnmUQyF, double FAJlt);
    int UVuCPZzqi(double VpcUMhD, double ZEopoCaN, string FpIiUmmYFg, bool TpUIjkIlJUaQtJxq);
};

string OKYhZpDTSMGiDJF::CsWpPmQobM(string eYbAA, double EhGlCOcOKjP, string KEEAT, double vdYGCnsBQhQFhxKn, int zxzQsabkrVfZBSb)
{
    double wVpHUeL = 387364.8121357973;
    string UPoYr = string("sWve");
    int leiUs = -864212656;
    bool jXoROT = true;

    for (int McvOyvxbQwt = 429017290; McvOyvxbQwt > 0; McvOyvxbQwt--) {
        KEEAT = UPoYr;
        vdYGCnsBQhQFhxKn /= EhGlCOcOKjP;
    }

    for (int qTjXyWeDEJw = 794035889; qTjXyWeDEJw > 0; qTjXyWeDEJw--) {
        jXoROT = ! jXoROT;
    }

    for (int moFtSFFPAcoubT = 1043574162; moFtSFFPAcoubT > 0; moFtSFFPAcoubT--) {
        KEEAT = KEEAT;
        eYbAA = UPoYr;
    }

    if (EhGlCOcOKjP != 902292.929091103) {
        for (int fVUXigRoiNxECS = 739581428; fVUXigRoiNxECS > 0; fVUXigRoiNxECS--) {
            KEEAT += UPoYr;
            eYbAA = UPoYr;
            UPoYr += UPoYr;
        }
    }

    return UPoYr;
}

void OKYhZpDTSMGiDJF::OoagtZUOW(double TAtZMUg, int BpKHWbGWcimDcr, bool NILDqoiyVDIMRp)
{
    string RHClQADbF = string("OzLXWPcAXaYAWiJUikyFEpYichrRQdCAgoBKczRMcDspPPFXYHXxqMMKButeqvWNidqCmXERwXsuVNabtxsmsAKxSHggBvZLUKsrGhRJwMzReoG");
    int HTAJQor = -856665706;
    bool KTXGtO = true;

    for (int hCinFyEqEhmVn = 2785179; hCinFyEqEhmVn > 0; hCinFyEqEhmVn--) {
        continue;
    }

    for (int HHgJNMYqoxYOj = 1933211872; HHgJNMYqoxYOj > 0; HHgJNMYqoxYOj--) {
        continue;
    }
}

bool OKYhZpDTSMGiDJF::AMrzfHypsXv(double ulDEfACjVvxCZhw, int TFVgSEoCnA)
{
    bool cpIiWGDj = true;
    int GPSsZobX = 701382071;
    int naEfjHpVlAkQRE = -696405483;
    string vhHNBfuTyNcntn = string("KYzBGgonzTfVpCBXVmuDEMpUIPvOJveiIFTrMRczcyxrO");
    double lfbHEBKQAKGq = -283485.2614681091;
    double tNxHCloiWZoXGO = -542500.4664005286;

    if (ulDEfACjVvxCZhw >= -1027248.7730505611) {
        for (int KbxmVhSBteOG = 770982170; KbxmVhSBteOG > 0; KbxmVhSBteOG--) {
            cpIiWGDj = ! cpIiWGDj;
            TFVgSEoCnA /= TFVgSEoCnA;
        }
    }

    if (GPSsZobX >= 701382071) {
        for (int MOApclPWRyoXmEo = 1228138351; MOApclPWRyoXmEo > 0; MOApclPWRyoXmEo--) {
            continue;
        }
    }

    for (int IBnTuBk = 1460771500; IBnTuBk > 0; IBnTuBk--) {
        ulDEfACjVvxCZhw = lfbHEBKQAKGq;
        ulDEfACjVvxCZhw /= tNxHCloiWZoXGO;
        tNxHCloiWZoXGO = lfbHEBKQAKGq;
        TFVgSEoCnA += TFVgSEoCnA;
        TFVgSEoCnA += TFVgSEoCnA;
    }

    for (int osliAKnISZox = 2040089165; osliAKnISZox > 0; osliAKnISZox--) {
        TFVgSEoCnA -= GPSsZobX;
        TFVgSEoCnA -= TFVgSEoCnA;
        GPSsZobX = GPSsZobX;
        ulDEfACjVvxCZhw /= ulDEfACjVvxCZhw;
    }

    for (int JpPPmufPv = 1260300780; JpPPmufPv > 0; JpPPmufPv--) {
        lfbHEBKQAKGq += lfbHEBKQAKGq;
    }

    for (int qnZiUsokfUDWay = 2111618796; qnZiUsokfUDWay > 0; qnZiUsokfUDWay--) {
        naEfjHpVlAkQRE /= TFVgSEoCnA;
    }

    for (int cvUHpaXPhYzm = 1488416001; cvUHpaXPhYzm > 0; cvUHpaXPhYzm--) {
        tNxHCloiWZoXGO -= ulDEfACjVvxCZhw;
        lfbHEBKQAKGq /= tNxHCloiWZoXGO;
        cpIiWGDj = cpIiWGDj;
        tNxHCloiWZoXGO = tNxHCloiWZoXGO;
    }

    return cpIiWGDj;
}

void OKYhZpDTSMGiDJF::tSfLNoT(int COGuqSFN)
{
    double fNOOYAyosiIhwi = -832093.4630723308;
    string Slqdg = string("pMpVJdInvSOwWLnyEUbfDjvUnbitvdACbQrtptfJehdWbesaAXQCbvEeflrBkiSkFTbUjeIEmoneTnomMLORUJPKGkrHXpFqQbwobJWvXuzMzMtLrFxgFmNvVfItisAYOvPTRLwZzIvFXVOCzbvdjfORUSIriPDZautnTnwaveIaFGoXGrJKwY");

    for (int DmZlwpO = 1709441216; DmZlwpO > 0; DmZlwpO--) {
        continue;
    }

    for (int PMaWzW = 873891816; PMaWzW > 0; PMaWzW--) {
        Slqdg += Slqdg;
    }

    for (int HfHHBQCqfUZiVzBk = 536139183; HfHHBQCqfUZiVzBk > 0; HfHHBQCqfUZiVzBk--) {
        continue;
    }
}

bool OKYhZpDTSMGiDJF::AyuXJcKJaFu(int enQsLREt, bool qdhgMAliywLC)
{
    string yuapAKzVYuDAuZop = string("BYxkfpLhXkZaKmNmBqfKGMNAmCYTiZcwpvtTnbqCUAAgNPYfCAvFOuBImIEPNEcXSgZBmDnoxydhiSEduUjLJFUwRBXFrKjDBwhkmrOHfRcXgzXcIawiTZVYOsMkCail");
    double GZcCmlbYr = -372527.82188991044;
    int bKXvGAwrsb = -216306326;
    int UYwOsO = 1570121732;
    string WwvqcJJ = string("dKvLlXSOEyNWvIAZMIkekUnzlPTjqDMzEwSNBcIAvlSDhfoEIgJkENkpOVwyCuLumSBzTYcJYcObhmqogrqmkFnQdgIJVbQamkGLUtVYYpjiXROcySRIhHKZseyefyQBYuOPsFiyyFcTsKGVRlpZmZJORMSaJRGRIrhpuDveDLWvYbFyYH");
    double xGLEDpbynOHGP = -979099.5094837027;
    bool NNeLyXzNvvMcoW = false;

    for (int dOCVbflfGwyjORWs = 232942582; dOCVbflfGwyjORWs > 0; dOCVbflfGwyjORWs--) {
        continue;
    }

    for (int RWHnh = 811183968; RWHnh > 0; RWHnh--) {
        enQsLREt = UYwOsO;
    }

    for (int HYNShKaHHuXEm = 602476281; HYNShKaHHuXEm > 0; HYNShKaHHuXEm--) {
        WwvqcJJ += yuapAKzVYuDAuZop;
    }

    for (int EQVHsjuFygA = 78961614; EQVHsjuFygA > 0; EQVHsjuFygA--) {
        xGLEDpbynOHGP = xGLEDpbynOHGP;
        enQsLREt += UYwOsO;
    }

    return NNeLyXzNvvMcoW;
}

double OKYhZpDTSMGiDJF::PYMphhCTpgeKtN(string jUNUjfeHP, bool ukjfKIcl, double wOJlWXwKBBZ, int ydYhiu, double HSqNMlsz)
{
    int jiUVuOYIxltpn = -857590154;
    bool JiBkCUESGAsl = true;
    bool WMeXleS = true;
    string ZzJasedU = string("HNsolAQVFWFZzBrTRgnpASHlnUNhrcUBSxObTmXAkxAkBMQTxAkyiJwfVyapDmJZfxfQNpWeYJjtCQMoJbMtdYNvLowbyhibZUVeJNqMJOqpJvrhKTaexdHicdEDPSazXSELHSMxgIhFLkoMlcQINgrttgMSulLBAcivrJPYvKtNAOH");
    int oyXPzNcztzEwnDv = -1132688324;
    int OyuoTMqIfzF = 1276924833;
    bool zbgVo = false;
    double GrkiQ = 941306.4510959756;

    for (int wSxord = 466146941; wSxord > 0; wSxord--) {
        oyXPzNcztzEwnDv *= oyXPzNcztzEwnDv;
        jUNUjfeHP += ZzJasedU;
        GrkiQ += GrkiQ;
        ydYhiu -= OyuoTMqIfzF;
        ydYhiu = oyXPzNcztzEwnDv;
    }

    for (int lNorhvoMpvh = 979906796; lNorhvoMpvh > 0; lNorhvoMpvh--) {
        OyuoTMqIfzF -= ydYhiu;
    }

    for (int hPvryELOfPQQlsCp = 1839630371; hPvryELOfPQQlsCp > 0; hPvryELOfPQQlsCp--) {
        continue;
    }

    for (int jFSVvlxMsRjnIvw = 81375415; jFSVvlxMsRjnIvw > 0; jFSVvlxMsRjnIvw--) {
        ydYhiu /= OyuoTMqIfzF;
    }

    return GrkiQ;
}

int OKYhZpDTSMGiDJF::zudtZvx(bool iaEWGZwmZo, string KVmoetD, int cYqtGe)
{
    double dqAHSpOnjmwj = -824933.2439635368;
    string fMxtQmsz = string("PJuBSlqiNFpZCMwpjEpAhxsSwhliMILRMInfozvAoTsjuprcXPkxsgTxHtYlzbdqsFiXPCqRpXoiMYgqtooqmUzZOazAKnMhhMnjDUVnhbxaiUgVNvMuvkAzhQPBiLOLLNVIhByjqmHlHEHPNnopHiJmGJIlTldlcAUffZcrPcvHtYphlkvI");
    string MJLYjasyrHpqxYYL = string("bLUuFgJrScImJNzgyBTRIzfpmZaucU");
    bool yZfeleTQV = false;
    bool vQHtRAzi = true;
    double ZgLMmxvAuVShmnZ = 838502.7883094134;

    for (int PoCcaDR = 1629478381; PoCcaDR > 0; PoCcaDR--) {
        MJLYjasyrHpqxYYL += MJLYjasyrHpqxYYL;
    }

    return cYqtGe;
}

double OKYhZpDTSMGiDJF::QvQtFBvXhmxxzx(int tDLIDFZrNzqPhnS, double jLUSmpnFQvZz, bool uapTUvNbMP, string ryfOPpmVBiXa)
{
    double HFrCe = 834137.2094657157;
    double amkocO = -298040.6568808882;

    for (int vcJeggZz = 1017105231; vcJeggZz > 0; vcJeggZz--) {
        jLUSmpnFQvZz /= HFrCe;
    }

    if (jLUSmpnFQvZz == 834137.2094657157) {
        for (int ACrQQkgjrRxDEp = 828756322; ACrQQkgjrRxDEp > 0; ACrQQkgjrRxDEp--) {
            continue;
        }
    }

    for (int wyAOGhck = 534722465; wyAOGhck > 0; wyAOGhck--) {
        amkocO *= amkocO;
        uapTUvNbMP = uapTUvNbMP;
        amkocO *= amkocO;
    }

    return amkocO;
}

double OKYhZpDTSMGiDJF::vFshTNvDZ()
{
    string dVVLQCpESfCUuMih = string("DyHINqULzCaNCdfoAoohZvThGqWzNEYjuBZbwpgvBCaxNFIIeTuUblrwqRVJpgVjLgWvBjWqbABYJwcUHJBxByAiXWkm");
    string enQOaJIWQg = string("FzmNfyGJhDakTMTEarWxvsxQJMSIMbEHjxVCKnlKjRygGrybNWnTbznNnMzqGRRSWDDpPYITeQDiisXLtLnAeFviZhFExwTnKjbtsRnsJULTBxMQivoNGybRnAZsSojQaxtqyrsYKStizMtcZWyIjtyXdONJxESNUtVROuPWtExsyOLEoy");
    int leVWWw = -1299784962;
    int PSHLCUbcpFcSHsqL = -222669035;
    string pujcKdM = string("CUBJetibgiTlFtuHNmBdapcpVCibHvsyBfqGwbmNWQzUxGYgECUljknkrdtVrJMuNCPNVSGLcCOJaRfiztdMrttzjWuFSvWTHXKgGMcWvZkfUceGcgvTnBRenhIRwKPHZIMYchtwnMkxaTgwVmJMZ");
    int grGvsroYJkW = 80805831;
    int FxZcweM = 1344868105;
    int plBkRpk = 890958444;

    if (PSHLCUbcpFcSHsqL <= 890958444) {
        for (int IdluZgiGGmBWq = 1204793878; IdluZgiGGmBWq > 0; IdluZgiGGmBWq--) {
            FxZcweM /= grGvsroYJkW;
            FxZcweM += plBkRpk;
            leVWWw = grGvsroYJkW;
            FxZcweM /= FxZcweM;
            plBkRpk *= grGvsroYJkW;
        }
    }

    return -282506.5660444109;
}

bool OKYhZpDTSMGiDJF::yFRYXQXJ(int cEjawHluV, string eiTEEVMuNkZ)
{
    double DCHnnxHmaQdtD = -858809.0533241626;
    string GqbvJqir = string("vCQGafmCmNhHdyTYraTFngUOtOJfaKbrTcsCbeuDHLwtbqCAwehPkCTkxDdHBbRCVUzvyrslmYYsJzhsYIqagzBQKwECLvlcDHKWNpZyxuvhuZwy");
    int dSDceCj = -1499342598;

    for (int LQPmMDF = 804010766; LQPmMDF > 0; LQPmMDF--) {
        GqbvJqir += GqbvJqir;
    }

    for (int QkoCMPpfhHQaX = 1459668533; QkoCMPpfhHQaX > 0; QkoCMPpfhHQaX--) {
        continue;
    }

    return false;
}

string OKYhZpDTSMGiDJF::LKImzyNWnZGjSXve(string VmAOnmUQyF, double FAJlt)
{
    int QzCmYpPw = -1009196870;
    int ATwoBYJrrgZkURbz = -1027034170;
    int QevZwMDSCXdn = 1889427779;
    bool GriDjdeqV = false;
    string XdrkzzNQfA = string("jkZALyOxBJfZaLJRUjdpvZTcahYGXxrWvTwZLndxJcqClpUFctXkXSXCStHemQqgbAttUZZcxgVeWvTofQSpDdaBidgqTroceguhRSwEtpHplAyIeYQcZJPmhAYHOYsMefUFvBUZpdPytCjOrbKbrwbGmYZwgahpBmYqeVUFjyMmNcKkWaPNLvkxWPnhNiwswnKpkRTplTNWaeOyjgz");
    string XqOIqYl = string("CYInBsfniriBZcLlsIFSfvMuUzZONGnXydZrxEPYpBndNyoQiDDPZbCfB");
    string KPeJGJYdrpzdK = string("jjRDOmEtfHLhOGrMTQmzYmiwbyCkgVDDLYtuPoYqvPIEjXJXhSFiRWqUuePUsJLMoqerpOeNLdxUoYWhOHFegddHysIEOskAhXsyKikcEuLiWaJQFRjnhgBuIcGXaHbRdnBqxHhbfLfqOwJYIbstWEPXLWOdHEvQjgGUEamuVPDyamcBeDvgzTdhKKsXtcGKqKHOzOTBwsQBcPDNyusxoHk");
    double qCfir = 880785.4504538354;

    for (int CJrYOMtwH = 916869336; CJrYOMtwH > 0; CJrYOMtwH--) {
        XqOIqYl = XqOIqYl;
        XdrkzzNQfA += VmAOnmUQyF;
    }

    if (QzCmYpPw < -1009196870) {
        for (int fgPGctU = 208389311; fgPGctU > 0; fgPGctU--) {
            FAJlt *= qCfir;
            XqOIqYl = VmAOnmUQyF;
            KPeJGJYdrpzdK = VmAOnmUQyF;
            XdrkzzNQfA = XdrkzzNQfA;
            XqOIqYl += VmAOnmUQyF;
        }
    }

    if (ATwoBYJrrgZkURbz > -1009196870) {
        for (int NrxaiivdChcn = 1534974587; NrxaiivdChcn > 0; NrxaiivdChcn--) {
            XdrkzzNQfA = VmAOnmUQyF;
            VmAOnmUQyF += XdrkzzNQfA;
        }
    }

    return KPeJGJYdrpzdK;
}

int OKYhZpDTSMGiDJF::UVuCPZzqi(double VpcUMhD, double ZEopoCaN, string FpIiUmmYFg, bool TpUIjkIlJUaQtJxq)
{
    int QAGwCzDV = -1514939510;
    double bUqqEnSyHew = -235266.93750501642;
    string vbsqIzvGdjxF = string("aCOgwjeeOtFoaGlLVJiIyKDfuAdIbeivtdbeYRHVDtXLcWaUkCEZSDqEpRBnOohkryd");
    bool fbJItVy = true;
    string lYoLFIBv = string("eZIOCsfuNmPUqPDpDabXSYyFtyPkVqDBbmSIBpmItKgLergIoZJFvRVDYvyMxBZiKshKrGqJZwKXfpbpobLuihfbOFD");
    double rMFxwayk = -73404.73815689656;

    if (bUqqEnSyHew < -73404.73815689656) {
        for (int rSzji = 1345886371; rSzji > 0; rSzji--) {
            rMFxwayk = VpcUMhD;
            rMFxwayk /= ZEopoCaN;
        }
    }

    if (lYoLFIBv == string("eZIOCsfuNmPUqPDpDabXSYyFtyPkVqDBbmSIBpmItKgLergIoZJFvRVDYvyMxBZiKshKrGqJZwKXfpbpobLuihfbOFD")) {
        for (int UGgNOwNnYLHMGRE = 683481599; UGgNOwNnYLHMGRE > 0; UGgNOwNnYLHMGRE--) {
            rMFxwayk += VpcUMhD;
            fbJItVy = ! fbJItVy;
            FpIiUmmYFg = FpIiUmmYFg;
            ZEopoCaN /= rMFxwayk;
        }
    }

    if (rMFxwayk == -908963.5530972463) {
        for (int yPWhcIRTcfntUZK = 1542836823; yPWhcIRTcfntUZK > 0; yPWhcIRTcfntUZK--) {
            TpUIjkIlJUaQtJxq = ! fbJItVy;
            fbJItVy = fbJItVy;
            vbsqIzvGdjxF = lYoLFIBv;
        }
    }

    return QAGwCzDV;
}

OKYhZpDTSMGiDJF::OKYhZpDTSMGiDJF()
{
    this->CsWpPmQobM(string("DlVBwynaJEcgRFTsdRjrArybZwPlCybIou"), -1047531.0587269168, string("EbFauzrpOLlNaOkexahFiVxUubXlfKJKIypsFUZieRrxnyiIZzhcLuHHyKxevwRBvobCieVWYgxYiTssWuDIWhdEmSUpywjxKl"), 902292.929091103, 1605152713);
    this->OoagtZUOW(-682296.2585708452, 832207826, true);
    this->AMrzfHypsXv(-1027248.7730505611, -116376460);
    this->tSfLNoT(1727877393);
    this->AyuXJcKJaFu(-838354289, true);
    this->PYMphhCTpgeKtN(string("vbDRkWrWMeCikAVxCNVelFDAjxDRXbrRLlVfBjfcVMzVvcyYTISLVjuuNMpzcHohEAhzsELPVqJDFeXmxpNupzocnJjTMWbDSUdcRKkWqyBoEOwQqaSxhUJjrhSPyLJRNkVbbWqBcrhWmcJBmOnBNqGwR"), false, -222879.0657073364, 1960736247, 874512.6502919046);
    this->zudtZvx(false, string("NNIyyjmGURGkwNTFbdAbtlWxRJfKMMqCYSKAoC"), -156159443);
    this->QvQtFBvXhmxxzx(1343226522, -913790.0493922099, false, string("kaanPXpDBEeRDMkwLnIYutaNPhHlyHkDGyhtnVrLDGMAWJmfUSbkipCqKyURVtqiZkyDNsXoG"));
    this->vFshTNvDZ();
    this->yFRYXQXJ(620755401, string("sSZExIreBiTkFRXRWzTDebsAVFWgIoZUXurPLfkmemBixVdgoBnRQGMycKeJjRqwjPTgixTUwRJ"));
    this->LKImzyNWnZGjSXve(string("EvWPzTBcxNTTMdlrnnNSfGLRJSlzMHMccZdDjWTfTnCmyyGBWJbRnHDXdJdUlTWgFMQQoJlXL"), 576156.2597650669);
    this->UVuCPZzqi(1017793.4567723817, -908963.5530972463, string("eRXWrQCAELuXXIADcJZDOluTwcshZMOZYIWMwapypwjGnbpVMsrPbNjxdRMRkxdGNjhrhfuMAtvUnDYZ"), true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CbsiiHFAsGn
{
public:
    string dAecpSjeAoAniRzl;
    double CfHTBPnzf;
    double EfbzpRvQM;
    bool CxCAmVdqaq;

    CbsiiHFAsGn();
    int LYyNGdFGysjncyj();
protected:
    bool WhHTGxq;
    bool orkhW;
    int PYlwPD;
    string ZzsTeLJSfhJJCEiM;
    int uGfGnUTPcf;
    double aWcVP;

    double GZBEMoHKv(string hGpRmzyPRbZUuUK, int segxOupnt, double RKxqnMKtWuU, int lCAIntRPr, int SuyIlWwoiUDTmZ);
    double tZQmcWlj(double FAmTM);
    void KnbjjQWdiJfldu(double kXaYaDNRvkp, double TmVoTAD, int PZzBKgefa, bool HtbIPIhalZFGwFbi, double WYvEC);
    int bpyKTLJMDhJeIPAv(string kPvGBzYWlZ, double GMleGczFizOqBrNM, double WbpoBMKxjl, double rAyUWpwlEtSkt);
    double jjTiWARwXA(double RxyJXQK, double yCXfQdjtF);
    int qJVoH(double iKWPDpvHijsm);
    double woJsKFhLusecueH(bool DFogamNHCjSr, int xYqzhfP, string ZElHM, bool WKSMjwykT, string clQKKoFUsdRIKfz);
    string CdibzGgHigRS(string xHAKAUicHdaJapL, string xYNShjQJCLbOE, string dPRxUpMstTDikD);
private:
    bool HKRuinh;

    string QGpEkIxjGTVSFV(string lcOHbmIfQWsoSpw, int nOMjZjTtcBVtSXbF, double oZkxhqCWCIUKuBDY);
    bool yDfRX(string AtRCk, int xRmuquMxPTyzS, double bYgjpenMhPayD);
    double FdPegPAuxBAlC(double EngOa, int XLazdFANwn);
};

int CbsiiHFAsGn::LYyNGdFGysjncyj()
{
    double HDraCctOikm = 139817.16431190635;
    bool KCbQrPLPTn = true;
    int MgCjM = -658171583;
    double OCZKLD = -550318.6344605116;
    string ibCpeBEU = string("wsAlvYFjsnRBCUTMmkivMnQzQkSradExGPxYddtmKcHeOlYpiNOXWdjinJpbGgqBRagKXxLczTcLnCtqsNYCKZqncwSTeuMoHXOeAvsIrnZLVCIQyiXyvBbmMIvySxdWXreRXzJhvlvJgbDVxrnScTZkcdUudVbCcrsxzHNEUEemSkBPShLt");
    double iHQJUWZZbncOPG = -524757.0876499928;
    bool cmrvreFVhNtOtW = false;
    double JOEsokXYRMOKbwua = -848707.9658629464;

    if (KCbQrPLPTn != true) {
        for (int AVtPChXLCNGAq = 1749303072; AVtPChXLCNGAq > 0; AVtPChXLCNGAq--) {
            iHQJUWZZbncOPG /= HDraCctOikm;
            JOEsokXYRMOKbwua += JOEsokXYRMOKbwua;
            HDraCctOikm += JOEsokXYRMOKbwua;
            KCbQrPLPTn = ! KCbQrPLPTn;
            MgCjM -= MgCjM;
        }
    }

    for (int krPysI = 1953895370; krPysI > 0; krPysI--) {
        continue;
    }

    if (KCbQrPLPTn != true) {
        for (int DUafxsMJPnmoi = 1015919269; DUafxsMJPnmoi > 0; DUafxsMJPnmoi--) {
            HDraCctOikm = JOEsokXYRMOKbwua;
            HDraCctOikm += JOEsokXYRMOKbwua;
            OCZKLD /= JOEsokXYRMOKbwua;
            HDraCctOikm = HDraCctOikm;
        }
    }

    for (int ELihWN = 1010986926; ELihWN > 0; ELihWN--) {
        continue;
    }

    return MgCjM;
}

double CbsiiHFAsGn::GZBEMoHKv(string hGpRmzyPRbZUuUK, int segxOupnt, double RKxqnMKtWuU, int lCAIntRPr, int SuyIlWwoiUDTmZ)
{
    double ZGyMlwUGmLXWxWH = -344761.08010603656;

    for (int sJqNKpXE = 1988194757; sJqNKpXE > 0; sJqNKpXE--) {
        continue;
    }

    for (int SaUgPV = 1214598333; SaUgPV > 0; SaUgPV--) {
        RKxqnMKtWuU -= RKxqnMKtWuU;
    }

    for (int blCQJzyNXjZIPmZ = 408992866; blCQJzyNXjZIPmZ > 0; blCQJzyNXjZIPmZ--) {
        RKxqnMKtWuU = RKxqnMKtWuU;
    }

    if (SuyIlWwoiUDTmZ <= -1445015815) {
        for (int shUhPtDTeZJIbv = 2062361581; shUhPtDTeZJIbv > 0; shUhPtDTeZJIbv--) {
            RKxqnMKtWuU += ZGyMlwUGmLXWxWH;
        }
    }

    return ZGyMlwUGmLXWxWH;
}

double CbsiiHFAsGn::tZQmcWlj(double FAmTM)
{
    int XZjVR = 1773552852;
    double MGiXiz = -163244.07750228242;
    int tUHLwUsfGv = 1560780828;
    double oSrAZJnNjuxs = 663510.6589284377;
    bool RGXEy = false;
    double PVEoI = 604539.7099704545;
    int TReWGacp = -778701541;
    double DgzFrPCpQYbY = -747000.0782406216;
    bool IPOTztVkMYHY = true;

    if (FAmTM < -747000.0782406216) {
        for (int SOnChsaQ = 415930637; SOnChsaQ > 0; SOnChsaQ--) {
            continue;
        }
    }

    return DgzFrPCpQYbY;
}

void CbsiiHFAsGn::KnbjjQWdiJfldu(double kXaYaDNRvkp, double TmVoTAD, int PZzBKgefa, bool HtbIPIhalZFGwFbi, double WYvEC)
{
    string bAwYztRqumUwAe = string("DRKXAvWsxstZGqgTQDfKRHoxlqoGVdcpfCpUqDQDokmXVmZSTnlhnZFfhXQOTUudsuEyoWfsSCNHqoUNynzRXoLBPuXpcXFPPWQSLrimpYESyUFZSwGdIczm");
    bool yHGZw = false;
    string OoUvKKnks = string("cApMXnTdaONGcXhirrnIJTqBgntxxJEUHLSGsvURagqBYcVuyYcHtPPBIgrQYjhKXypEoPIqEDfSpEZUXmPLxQooXdI");
    double dgpzjmpPRuouNahz = 784882.3674732533;
    double gThdOCO = 889462.422263529;
    int wTxwMlcfBTjr = -1886222404;
    string qAwhBJk = string("UDoQKqpTQGxrHMhcN");
    double XMGwxxfjjzFTvm = -400925.56906909094;
    string KxaWOzQlNH = string("wotfmRdCuxiakgUeXTiBwfaAXYCHWjdyFEEgOKsVZRqmMwWMQvVzzpViBDpGShQdzlAMSShCyyicTCqhrpFLyFqVmnTTUFXJNfRoqTEVpACRPxbjRDXcPLEozjHsjXwlIxJMWdepTwplKQPTRApUjkawKJCwJWXfcbd");
    double KGTdqq = -459007.59663884947;

    for (int TjnShEEHZoOoMVj = 1888170041; TjnShEEHZoOoMVj > 0; TjnShEEHZoOoMVj--) {
        gThdOCO -= gThdOCO;
        kXaYaDNRvkp /= KGTdqq;
    }

    for (int izgCPHglTKlaKd = 595467655; izgCPHglTKlaKd > 0; izgCPHglTKlaKd--) {
        continue;
    }

    for (int bNBlxBaAWbxjeY = 942243736; bNBlxBaAWbxjeY > 0; bNBlxBaAWbxjeY--) {
        dgpzjmpPRuouNahz += gThdOCO;
    }

    if (kXaYaDNRvkp < 889462.422263529) {
        for (int eavIAeQbOg = 425076742; eavIAeQbOg > 0; eavIAeQbOg--) {
            kXaYaDNRvkp *= TmVoTAD;
            KGTdqq += KGTdqq;
            kXaYaDNRvkp /= TmVoTAD;
        }
    }
}

int CbsiiHFAsGn::bpyKTLJMDhJeIPAv(string kPvGBzYWlZ, double GMleGczFizOqBrNM, double WbpoBMKxjl, double rAyUWpwlEtSkt)
{
    int DGVdlmP = -1068858131;
    double XatAWxNaU = 190621.2648762036;
    double FffYpYd = -134402.05994516617;
    string jQgnLi = string("orvfMoKbiKhrmTzfsidkCgiCczOEGuKQqlgQdzyZOKIgXDuFsUOlZQalQAkwxmmVbboyUnimkvHiMasEAvyUWuRlcEMSgfbPQtzAMvtxELpaOBGaKHdGKWrcukPdJEZqDQGTLwPOrlCxnnJjQJfbhnKItFKmUMqzlFiSkLkOwSMtTWkxfQOTyyMqRozBZdfoEVdsRojAmftykEAsOQmiuxFrmMxiEikgPynPYgZJ");
    string RDCqr = string("KZWHHsPPqlDSXxxNGgCXvWIcTZoCTdcDZqycJAIWhFlrkUYEDHEzRqkTNQdpxUeOCdIuDqbGjpOQoBanZrTiZLdAxMQqspvAbteXZyzfHIuecXxRMEpyaqokJRuMASKLrbWbxjFFSSshtEmPiUTcYCNhASyrJSwFejbwKYISXfWCaulblHPQKccRdgzUjzVaILKBPOzsjhzqvHTLQaMx");
    double YCLeGgzBuydI = 581256.601130967;
    int LNXVmpeTbitPKkD = -893121801;
    double HsuuMs = -705970.0325308947;

    for (int ZeGoojELBhf = 1139170659; ZeGoojELBhf > 0; ZeGoojELBhf--) {
        GMleGczFizOqBrNM *= rAyUWpwlEtSkt;
        FffYpYd /= FffYpYd;
        GMleGczFizOqBrNM += HsuuMs;
    }

    return LNXVmpeTbitPKkD;
}

double CbsiiHFAsGn::jjTiWARwXA(double RxyJXQK, double yCXfQdjtF)
{
    double UbKIXwJZBVdAkZ = -106352.19017961773;
    double HrjvtNjyHLBD = 561115.4334687532;
    bool CERAIPvftYdHqh = true;
    bool bDNibTXexrXhChBi = false;
    int bkDnnUvKI = -1960282219;
    bool nltXUvLxKA = false;
    double peKcazZINJBkCUj = -259088.36893363277;
    int tXfoAGRMdQSOyOCR = 2143636402;
    double oBRjWWSii = -131645.32554199567;
    double zdWwOOUgJUklEe = 525106.3751092256;

    for (int oAeVVTITerdgTT = 96165093; oAeVVTITerdgTT > 0; oAeVVTITerdgTT--) {
        CERAIPvftYdHqh = bDNibTXexrXhChBi;
        nltXUvLxKA = bDNibTXexrXhChBi;
    }

    if (nltXUvLxKA != false) {
        for (int DidsnhqxweHIAlJQ = 950927047; DidsnhqxweHIAlJQ > 0; DidsnhqxweHIAlJQ--) {
            yCXfQdjtF = yCXfQdjtF;
            RxyJXQK *= RxyJXQK;
        }
    }

    for (int DrWmwxedHXJciM = 1095029195; DrWmwxedHXJciM > 0; DrWmwxedHXJciM--) {
        zdWwOOUgJUklEe /= UbKIXwJZBVdAkZ;
        UbKIXwJZBVdAkZ /= peKcazZINJBkCUj;
    }

    if (peKcazZINJBkCUj != 561115.4334687532) {
        for (int WzFgQnMb = 1992204065; WzFgQnMb > 0; WzFgQnMb--) {
            zdWwOOUgJUklEe -= UbKIXwJZBVdAkZ;
            zdWwOOUgJUklEe -= zdWwOOUgJUklEe;
            RxyJXQK /= HrjvtNjyHLBD;
            nltXUvLxKA = ! CERAIPvftYdHqh;
        }
    }

    return zdWwOOUgJUklEe;
}

int CbsiiHFAsGn::qJVoH(double iKWPDpvHijsm)
{
    string fLIGaXgaxdA = string("MgjNGoVopQKKqcZdPTZXcT");
    double euouiETOQfsFXo = 420164.0130916452;
    string bPSsmRqNscVflqdV = string("pQfRQSenJxWUPvXyoTfLjgwGZlCqRaBMNySubDrfoyBSwloGeRgMHSagnoTcJLnNLGzEOnxqXrbDirFoXYEqVVrZFXGFWTMRUfAYPLdNTtPeJuRElfVmXCmOmWObEdcIjTZkAtzlqQlbMSiBjOKgAlqeePsSgyYYiZAWIGDKyPnwPqKFRzsoasLAFQvloQTdBACrMErSfbHZPOhMEcmtKrYbvHOeacEhYtHKEaIcqPwKkSHEjuiXUruPSqX");
    double KeqfrkUrntsmnWMW = -328291.2922610643;

    for (int jyxNaoXZGpupC = 1344971725; jyxNaoXZGpupC > 0; jyxNaoXZGpupC--) {
        iKWPDpvHijsm /= euouiETOQfsFXo;
        iKWPDpvHijsm = euouiETOQfsFXo;
        KeqfrkUrntsmnWMW -= iKWPDpvHijsm;
        bPSsmRqNscVflqdV += bPSsmRqNscVflqdV;
    }

    return 781512869;
}

double CbsiiHFAsGn::woJsKFhLusecueH(bool DFogamNHCjSr, int xYqzhfP, string ZElHM, bool WKSMjwykT, string clQKKoFUsdRIKfz)
{
    string XVUsyve = string("WCgfIfadydBwuxzEDAAnRMicEFEfVWyEQjMLulFqCsCiCLuKDxyfsJRMOwoorLanBrExOmAsGcsVUsIiAMyFtTHaCZbBryWcLdegvKUoepoqYxDxZUqGlGFGzfyZbEdVrdovDAZFTVzZMkGszXwGducFQoOBWrLmcPUPksaFcqVnPvtrawxKLZojYstRXPgqPOhmgkZFjYdyEj");
    string hsMITyBdo = string("uXCQJekDDmFryGXXDUyBCGNSYAShkbSgXKAoDGXXHMtVUediCByuQZUmSrwESCCyWBJwKXeuorajQVbMXtDhfoEuiSCyjsUzoowKWbzMItEszAfUJxzsjuWXPZgVJfDNKGYtjThaTQrfRnuDEveVMUEiguxtTbkWLigpLwRoIKCpEUkOVZOXCPKuaChNjVHbOuKIzArEkAJMTAqfPdyYHr");
    int jMwmymZvgqZKMXm = -1214298252;
    bool hDQaUgwSNpIk = true;
    string iYxbeyYzarDf = string("zpRAUitCzfplKdGhejCGqYytsrwYIRvDsczgAowQGrfojFpaxFbECzAoyjGHlCZIrIbelKvkBqevgWkhiHdnliIfdFPfsnGIZKloUXumvcZXlZcthTosWmSmiUjoYtWMkJILUoLjWqSAjpeZmDRFbYmfvrrILW");

    for (int zqnNsBa = 429803818; zqnNsBa > 0; zqnNsBa--) {
        hDQaUgwSNpIk = ! hDQaUgwSNpIk;
        hsMITyBdo = ZElHM;
        WKSMjwykT = ! hDQaUgwSNpIk;
        hDQaUgwSNpIk = DFogamNHCjSr;
        hsMITyBdo = clQKKoFUsdRIKfz;
    }

    return 600025.5305356238;
}

string CbsiiHFAsGn::CdibzGgHigRS(string xHAKAUicHdaJapL, string xYNShjQJCLbOE, string dPRxUpMstTDikD)
{
    int BZoGmInsVTKPK = 551003693;
    double DAYKDlvWMWg = 473488.4974561472;
    int bgyJeKWYSde = 240065471;
    bool djugByrbSbnN = false;
    double CtyXTwcOJonvekm = 969723.702698862;
    int BcnwGgxCGT = 122248531;
    int aEvIOlIvxwfmQuej = 649435141;
    int RbTzeT = 1006523117;

    if (BZoGmInsVTKPK > 551003693) {
        for (int VyOwmftLclppZxc = 1820934136; VyOwmftLclppZxc > 0; VyOwmftLclppZxc--) {
            BcnwGgxCGT *= RbTzeT;
        }
    }

    return dPRxUpMstTDikD;
}

string CbsiiHFAsGn::QGpEkIxjGTVSFV(string lcOHbmIfQWsoSpw, int nOMjZjTtcBVtSXbF, double oZkxhqCWCIUKuBDY)
{
    int RJWSQBTktEQcWov = 1680666861;
    int hvSmldRepeuR = -1113036112;
    string rYZhaVyHMvDBAV = string("kmtHqPWIwQATKTyoAZfaUILzwErAiodVmhypitAsOJrtwnFbkDrppXzXJICNcuiBysacziwTsZrNryznuGRsXNQvrqOgEmicySWzIIqJJDvzroHNparvmOaTYDNbl");
    int cWyNMfMUHYi = 590872699;

    if (RJWSQBTktEQcWov < -1113036112) {
        for (int piOzxrxbBQQw = 236207034; piOzxrxbBQQw > 0; piOzxrxbBQQw--) {
            continue;
        }
    }

    for (int LpmMaKtKFtWR = 1232737874; LpmMaKtKFtWR > 0; LpmMaKtKFtWR--) {
        lcOHbmIfQWsoSpw = lcOHbmIfQWsoSpw;
        lcOHbmIfQWsoSpw = rYZhaVyHMvDBAV;
        RJWSQBTktEQcWov = RJWSQBTktEQcWov;
        nOMjZjTtcBVtSXbF *= hvSmldRepeuR;
    }

    if (RJWSQBTktEQcWov != 1680666861) {
        for (int fvwUdWqU = 1574913393; fvwUdWqU > 0; fvwUdWqU--) {
            rYZhaVyHMvDBAV = rYZhaVyHMvDBAV;
        }
    }

    for (int dVtxtAa = 1024611450; dVtxtAa > 0; dVtxtAa--) {
        nOMjZjTtcBVtSXbF /= RJWSQBTktEQcWov;
        nOMjZjTtcBVtSXbF /= cWyNMfMUHYi;
        nOMjZjTtcBVtSXbF = hvSmldRepeuR;
    }

    for (int MpGuhWMwABR = 1148814180; MpGuhWMwABR > 0; MpGuhWMwABR--) {
        RJWSQBTktEQcWov = RJWSQBTktEQcWov;
    }

    return rYZhaVyHMvDBAV;
}

bool CbsiiHFAsGn::yDfRX(string AtRCk, int xRmuquMxPTyzS, double bYgjpenMhPayD)
{
    string CzqeNHhLROvXQ = string("eWdXjzlGxnRHUpLqsFRhjJNBqXfUFtexRTiarusSJLsjJmvOHSyEHknUAfuZGPLemApAEIuZHwluHGwZmuNvIAfpZzXmCycGPCzwUbLWPVBDbLcAbNauMmxMqkepWKWlHDveWRQjMoxJxcwsmyIMCbMMaWIrpZQrRRjnfrcPGBgnkpzYHECGlcRrtORCbKJBgQQjdgOQzcUYvhDmICdAtDraIIWJahxbXjYEziWr");
    bool otJiZrNKSAZ = true;
    double hbySxohrZObT = 448755.1840169895;

    for (int kLuUfbs = 1928148410; kLuUfbs > 0; kLuUfbs--) {
        continue;
    }

    if (bYgjpenMhPayD <= -771060.3438668) {
        for (int IzfDcOWsQGcNGz = 882027558; IzfDcOWsQGcNGz > 0; IzfDcOWsQGcNGz--) {
            continue;
        }
    }

    for (int imKWg = 468382144; imKWg > 0; imKWg--) {
        AtRCk = CzqeNHhLROvXQ;
        CzqeNHhLROvXQ += CzqeNHhLROvXQ;
    }

    return otJiZrNKSAZ;
}

double CbsiiHFAsGn::FdPegPAuxBAlC(double EngOa, int XLazdFANwn)
{
    bool DLYuqLao = false;
    string JuLWKx = string("kJvWVoEvuZTTViJLeQrpPogGtfBDlEfQUGkdhvxckdPrXnXKK");
    double WDXAtCrDpYhKmRey = -563742.6048027048;
    int PnNxlbYgfKsCXFj = -274554632;
    double hjLZcSEMPJKdsRPp = -453890.09537283116;
    bool UNVzlpUSFoj = true;

    for (int TAsTgzPYjcTiE = 1683039142; TAsTgzPYjcTiE > 0; TAsTgzPYjcTiE--) {
        UNVzlpUSFoj = ! UNVzlpUSFoj;
        UNVzlpUSFoj = DLYuqLao;
    }

    for (int QGUlpt = 1301336713; QGUlpt > 0; QGUlpt--) {
        XLazdFANwn += PnNxlbYgfKsCXFj;
        WDXAtCrDpYhKmRey = EngOa;
        hjLZcSEMPJKdsRPp += WDXAtCrDpYhKmRey;
    }

    for (int FIhlzAmYgPgaVCbX = 385641481; FIhlzAmYgPgaVCbX > 0; FIhlzAmYgPgaVCbX--) {
        PnNxlbYgfKsCXFj -= XLazdFANwn;
        DLYuqLao = ! DLYuqLao;
        XLazdFANwn += PnNxlbYgfKsCXFj;
        WDXAtCrDpYhKmRey *= EngOa;
    }

    return hjLZcSEMPJKdsRPp;
}

CbsiiHFAsGn::CbsiiHFAsGn()
{
    this->LYyNGdFGysjncyj();
    this->GZBEMoHKv(string("JQSlluEguardIfemoYXcNRcRzNLZLnIaMFBlzHFeZUrzTxKqWlRzAyvFfRveSGdvYSwdyyjSJItzeBDrdmAMwKUtgnOLTIUTnVmXUYLNLHeWQaLtujVRLDmglaWscwPddCYUNeJTCwKEyvOCcKNJGrXqxAxKbROljKOibIVKpoLMBMUigslgAhY"), 241802448, 486514.26637221203, -1445015815, 748848154);
    this->tZQmcWlj(-102851.78105318516);
    this->KnbjjQWdiJfldu(-618741.4645933459, -277354.2508361053, 1872022949, false, -347291.60615892906);
    this->bpyKTLJMDhJeIPAv(string("YXaQipBdvVOesibxRIhZAdfQkRooMRImfsyNtkyzsKrFVZeTFyjjnoLwtcfTJYdzKBpgcbbDfukTioyyWwOYRjddDEkyRLPPIxkONaNokVivPQVSKdzaltRlWsD"), 708664.5753824298, -1041099.6294605972, -295035.1176599103);
    this->jjTiWARwXA(1040699.3554515814, 687514.825267435);
    this->qJVoH(-625498.7207053866);
    this->woJsKFhLusecueH(false, 2094597579, string("xWFQYwXlKjJImMLnlXuGwJbWSOiSvQiRshgclWTvVlChCPRjGZoTsXhzqyontUxYQsOWIQHDzqzddP"), false, string("FKgclyDhNSQBWbwfdEVeVjQurDkrJCXydQYABJjYKswZIkVPjIfHYKtzyQKrBiZzFlZmhuUtuGTDKvwPztLiCUNwbsCzeCHhCftdyiIJnywlcSmMSofWDmqAcOHIFQLxckjQSjGhpxeqtOToVbXsiGMjHWhTSYWBvMSLczppDntYACbYIurmNhfmyezqHywLhmgqjcvZdShQRWpFLfAUoNMiuKHpnfdueLnIuVIMWJ"));
    this->CdibzGgHigRS(string("UkiPoYxsIXjWgTAkqDAohMMpoXWUYGZBvWYlXYCpuJNDLYzMHnDfwRnijKTZdQTwJFSHgukcYsgEvWhTqFaKYCnUcTupaCRYNgwblYtLepchbeqABYuTqFajhpLHmQQADPIGhxCESMFvBGETtkElkQYbskUCchzdZhEXqIvmCLnhxTNAcmDKtJHTUQFOmTkAFPviQgPAZDEDCHFtHOBEgFxPhjISziNqBCRr"), string("qDLmLsJnbiKqgOWHFumrxvOBofEaQlCdbIWQSNyaonUClMebTCZoViThMiABYdBjWsROt"), string("uDFHKOBCpLlBVAKWcOJUYzZSUUAEPyXCkUYtplYFuVpoXEOlITUcROFVHQoScfyIyGKVFuVEvCUpyMoYtdmMHSvgNXSqmqPmbukdwUWzMavogIfIutInSVeJcNnVcCrhucVZHHCJPgHIVsYckvYKfappTnqOgGhBlPVuwVCSwvWQEjpJFeyeeiAmKHjkQHNxpZjKQtPBfGgmgAKUIPWMAHUNrYJTY"));
    this->QGpEkIxjGTVSFV(string("KdrzNgmTknoTumkvcuMDFhwyvudOaEdasBXzRbULzGKpEfYzIauQVAqYkFIgIIWbjdTvMdyVNlatgWzRJoGumZkesPceKEiDgrLMPQwNRvjSyDOGPosbZlEhfggDsmmRvJbEVGyNOScbIFOXSDLleMzlQlorAAy"), 1986185112, 225856.44667454783);
    this->yDfRX(string("ApsbTGFBUIgCCpSlAHBmFnbPYuISTSyfZdwknWwvPkiGFNqxrlHwqzAVNMppIWxlLFmkqcUujdTdHJk"), 1796701297, -771060.3438668);
    this->FdPegPAuxBAlC(-105493.72045535829, -1234274991);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class LmYSPO
{
public:
    bool trQuxheNI;
    double lhlcKCyHQRZ;
    string tkuJSdC;

    LmYSPO();
    bool NMyGLk(double DIHdimyExpFX, string HOHSHrgxswaw, double GvTGSMxjhhOayEI, int JkOvns);
protected:
    string jSDBsNdhOMiCO;
    bool SXWFBofjgy;
    double teWgPQpYVAJFj;
    int KwKydHoTDTwE;
    string fuWNUpQMw;

    int WzyAD(double zVzKA, double wIeYewJ, int AFPWRyZHkgfvp, string VrwTJsBBGYcR);
    string yMyypErSEXAqc(bool jAAvfvTUAUipDLUd, string wDvxTjZa, string JLEojKH);
    void ICavrgulidSy(bool wqsLRdmJBOoVvMto, string FHiyRxefz, double WLrLFTN, double podrcVb);
private:
    string LcflKRO;
    string hCLxngSIqubHtIaD;

    int VyCEDUpoips(int HQDQAUMfroCwp, string yudLKVvesxLtSL);
    void uVBsiC(int zyOgZatwwQwwACh, double cbCeTgrsfpZW);
    int XOuaoGxFZTKx(bool CunZZbQH, string wwfdfmMTuMlYdxv, double JrTPOzu, int vDleymnIfWHRuq);
    string eXjlncXrs(int AlfqeDrXmkwCh, double SqyTEZwfopuHJ, bool jCEvJYUR, string ebmgFIQPyEDJ, string QAjDwF);
    int wNhqBLmgJDlfb(int TjHesORYdzXaZDT, double gMBNd, int LndSavcCoOkW, int BtqlLsmbPQhUvZN);
    void kgIJZLhW(int BjjnqRkKmYEDFTE, double CShwAhXOHLicY, double JRJqNlfBMZF, string wBKZVoPmj);
    double rgaEYsFEO(int mLNPojhIjjR, double psgipSfwdK, int HqboD, double eVnqywpIZ, bool TUclO);
};

bool LmYSPO::NMyGLk(double DIHdimyExpFX, string HOHSHrgxswaw, double GvTGSMxjhhOayEI, int JkOvns)
{
    string dHQhHQBbEpva = string("oCqeAAUecAIVwhJcHNfiaNjgsrQamOxtSSUuaaoEKsyTyPaBXcfoXQFvPsasYikmbrewmApbUlLMmIzxhxkVrUQLDIbiQtAfroqhDdUKcDlmEsBrBGPHirMJSuctAGnwaLHWwGcHbVnXoPopHkMrZWriFOqjwYGbtcdImCtOVlrMLRCoMIMrzTlDtGaPEmYoTkEPyjWtNZESeZWzibTZivoEAG");

    for (int DiIclWn = 561412669; DiIclWn > 0; DiIclWn--) {
        continue;
    }

    return true;
}

int LmYSPO::WzyAD(double zVzKA, double wIeYewJ, int AFPWRyZHkgfvp, string VrwTJsBBGYcR)
{
    int hEHSJ = -762347517;

    return hEHSJ;
}

string LmYSPO::yMyypErSEXAqc(bool jAAvfvTUAUipDLUd, string wDvxTjZa, string JLEojKH)
{
    bool kHIkashQi = true;
    int IqbknrTDJYHlnS = -1990565990;
    bool tyART = false;
    bool gbhNZPrvChq = false;
    bool gDthfglxdI = false;
    string jStAsbkAHwnEwyC = string("RHCxIQiUvXbDWypieJdkLTRAucAGlJHjtTWhBHGCEvFXJPwHTgKwKzTLPApEpdibvfdrBQqEjeWBZbSgCegfSfdhAMpZlnmcrDgXdnCMmPMFHnLfKgmuBNdeFuhdhthUXzuZbZOslcTzBggPESzXxlfFEcwVCMjLBTiJPuspgoXJHBMqEQI");
    bool TqtwGBFSPwGuwxd = true;
    int XJgbOJrYXTmWFN = -342312939;
    bool cxuqIpzHGqChzBb = false;

    if (cxuqIpzHGqChzBb != false) {
        for (int PyGIHsaLsGl = 1498402062; PyGIHsaLsGl > 0; PyGIHsaLsGl--) {
            IqbknrTDJYHlnS += XJgbOJrYXTmWFN;
            wDvxTjZa = wDvxTjZa;
            gDthfglxdI = ! kHIkashQi;
        }
    }

    for (int qfxFbxl = 1073282484; qfxFbxl > 0; qfxFbxl--) {
        tyART = ! cxuqIpzHGqChzBb;
        kHIkashQi = jAAvfvTUAUipDLUd;
        tyART = tyART;
    }

    return jStAsbkAHwnEwyC;
}

void LmYSPO::ICavrgulidSy(bool wqsLRdmJBOoVvMto, string FHiyRxefz, double WLrLFTN, double podrcVb)
{
    string hGCapqUMtAKtNpCR = string("pXaSWOAKEStwSIObNioiMZXUeCeTLFfjeGVUcOhokvvnnBATEMjz");
    int hmRuR = -1762663267;
    double LThxBTpXkFVOlAXH = -200184.53051520922;
    string irFzIvZGwWyyAT = string("uOhRGygshpExvMiYOrJcdaquOHZpCLDBFghSijqHGMSjhUJqCaYhEeDZMLhTVUvZjsibSSHCJlMyamEYULMLTjzfuJSdKcOagl");
    string vjzMPeyk = string("wjeBfzeXQPKJXdSJtEtItQNrQghXTsdtKYHKIwggAqVjZURRMJUqrQWDsqmHPiRhlMmWMdysHqxEpxiUvmMGYfZcCEtPPKINGZFUsLiDyPPViwRFjJcgIimteZWLjWRxDWnqBlkubdncZOWxGFLvbZavUTZQcJEjitSuIvQkcQEkCPSNOZXrNLfWgQJQPwNVFfrZBBvgweCYSPADtXoxrZhOmTqxBCHNkIGdmKnzRW");
    double sEeuZugGBlme = 816899.0359194766;
    string QqsMDcSaCsIpdWZ = string("VyngvkIUugKSXTegpgoc");
    double YoXecfJlmWMOeO = -248923.21499936443;
    string ULTaHIBCu = string("VprOKkMJictZDkWFAKPzywRyuPhCPlXBPkoqQL");
    bool bSkaHsikSB = false;
}

int LmYSPO::VyCEDUpoips(int HQDQAUMfroCwp, string yudLKVvesxLtSL)
{
    double WguxhlUk = 564000.6304173588;
    int iUVIofJ = 379176328;
    bool VSDvJIJaNWuHjvz = true;
    int FQARG = 654563455;
    bool tmpgWpgRfe = false;
    string MsZgyVXesJiqbU = string("VvVaEZIvEGikPjQVhKiLgFnUFgiakkymkOjHZRUnIAuAaOiKrxyIddndcynsqaCuSzcCrWSbaMEPbmFfoezYRyrNifOKEzruseikUUMRPEcAJPsrgiQjpEJCDOmdjwV");
    bool ephXiuTHUUqtkhCZ = true;
    int BeHNz = -82151112;
    int mwnWdCgDBWCelo = 1888662240;

    for (int tifVicJaV = 1330350549; tifVicJaV > 0; tifVicJaV--) {
        HQDQAUMfroCwp += iUVIofJ;
    }

    return mwnWdCgDBWCelo;
}

void LmYSPO::uVBsiC(int zyOgZatwwQwwACh, double cbCeTgrsfpZW)
{
    double mMgwrUciCOOsgXNo = 4751.311981106604;
    double FttUlIHU = -25506.66966910977;
    string jdEhFsyCngIIO = string("boktcSxcCbUIBtUGBjEcYxfLePmawUrbKjBsrNrAvNhBLRllfKWYRqhiPEjtCVHBXnkNHtWBRtJQvACotwgdeBTYpdrkzXpMKNSlLTdukvpnWSBPoybhfOEwFfJZOxlqAfZDBFvBfvyhpRWdkEeIhPjwJOLyOwYHpETPiapMxxMklvshIxOVGIjesHNZdsnYFRJFHzKhfDrdTeokmYAazPfhXCHPkc");
    string GolXmke = string("XHEXEaYQcqVkBtaXmJmuMuadEqSPeHncEYoImkgLgebAsxvwMErDDBxzwHFIyeXBSJYPXsyciIutBWpbhzdIwxlBeYKGgGLEjUAPZvNlAWUE");
    bool TDjkmF = false;

    for (int gnEEbxBrvJpDEs = 887021875; gnEEbxBrvJpDEs > 0; gnEEbxBrvJpDEs--) {
        continue;
    }

    for (int MJUmiSptj = 546059579; MJUmiSptj > 0; MJUmiSptj--) {
        GolXmke = GolXmke;
        mMgwrUciCOOsgXNo -= FttUlIHU;
        jdEhFsyCngIIO = GolXmke;
        cbCeTgrsfpZW -= cbCeTgrsfpZW;
    }

    if (FttUlIHU <= 4751.311981106604) {
        for (int oyMGx = 1953866760; oyMGx > 0; oyMGx--) {
            cbCeTgrsfpZW = FttUlIHU;
        }
    }
}

int LmYSPO::XOuaoGxFZTKx(bool CunZZbQH, string wwfdfmMTuMlYdxv, double JrTPOzu, int vDleymnIfWHRuq)
{
    int QTYLcFqfiNzuAi = 416827109;
    int mkXXXB = -732162144;
    string wemYgOfjLgcno = string("JYrwNQdKAxVOkCFOLXxCDfNKfaVaLaOOMYAUwDtgAKqyJCBZGk");
    string GEcCkLI = string("KHyyrlwNDfLnzDLTKpYySjBvzUgEHrEbGtDAnhdjSeUGRzVapnQHNRexIOpwTrxhHBKqdaDNdcLohbKesLayBhYALiQYBylDCcRPhBUVfMYHrsbYAaJwZbplSeZFIXiGNTpcnwfQFFpcePaLxgoqyWIJcLxoyUb");
    string EKMQNtycy = string("bnPJsGzWoItlzVcldmQfNAxlqXYTZwHnLjkWyEBqVtnNTDchCmooIPzODkSLqwNxGLiuprNkDRLWIiYtzTtFuaObqfCnmXmRhRmzVLb");
    bool iFjeWD = true;
    bool FOZgMCdxi = false;
    string bZxZjFqkHxfArGSg = string("IEnLygwDeWdTvqYGzXQMzZzhzbBqwNIvmzgRwzHmNqFVLDUJZFpQFNusestCPtGRYJkQdxlPvwvwXFIZjijWvppLezEFxGbNSaETheeZjPxAWryynUocQQalKJusyMCkVOWQRGjNZwVfNpXAFMSSzuqhMNxILCwlMyWKGd");

    for (int dboUD = 1349920855; dboUD > 0; dboUD--) {
        CunZZbQH = ! iFjeWD;
        CunZZbQH = ! CunZZbQH;
    }

    for (int lZTWDc = 1458724752; lZTWDc > 0; lZTWDc--) {
        wwfdfmMTuMlYdxv = wemYgOfjLgcno;
        iFjeWD = ! FOZgMCdxi;
    }

    if (iFjeWD == false) {
        for (int IHPsH = 1891020021; IHPsH > 0; IHPsH--) {
            iFjeWD = iFjeWD;
            wemYgOfjLgcno = wemYgOfjLgcno;
        }
    }

    return mkXXXB;
}

string LmYSPO::eXjlncXrs(int AlfqeDrXmkwCh, double SqyTEZwfopuHJ, bool jCEvJYUR, string ebmgFIQPyEDJ, string QAjDwF)
{
    string hIMmeyGKtaw = string("YETQcUGypztpLkMCcXUIjzMWgFrnWSRLuihfEwuBRRoirMjBqSvaaVVabsQlCYvNtKsmussEDBknjb");
    double GydMMLXJDLuDoL = -320219.37310606585;
    bool aKcIHYPobTXbURA = true;
    string PRVsPLLUb = string("MTSdDnTriZozRajiIgFajvLPSYwKRXgfJScKiaaQaaLFRVlUWyfqVxtlEHZddOARzVhNmQYjqQeOrlCbVDYONtVxXtjGCidqQIMvRtjUKydSsSqmDTFgXcZNpxEQiPMIRYhaDMFrxGyafiuQkEjKUEMgoNvlXRcCbxGghKhClKMnyGwdhmFWntJFhSDrZVZiuChMAEJjSzIuyqPHRUktWyEscSvkABCxpEyMFrOnMCSCZi");

    for (int pslyGGDMMc = 1061432949; pslyGGDMMc > 0; pslyGGDMMc--) {
        PRVsPLLUb = hIMmeyGKtaw;
        PRVsPLLUb = PRVsPLLUb;
        hIMmeyGKtaw = hIMmeyGKtaw;
    }

    for (int fscKEEchijnmqGZS = 356112534; fscKEEchijnmqGZS > 0; fscKEEchijnmqGZS--) {
        continue;
    }

    if (QAjDwF != string("gISpJeAVihzzcCMWRTAhnIFnjChEsCdevDubsSvnpLybYcHhmEHumAbahsuWkxpFRHAvtDIgMtIqOKmbarwbOYewjRWJOqFHTGSNFUqKnWvChVkCqTAIjalKwFVRLiomXKPpokIbCtnlIMbKzzwOJigXPmnIFTpcGridOtzLoVgmoWeVbOFfPTLZJvxoaKpofejCekIJBGAalNTiqIjKfqzsBAJLSdDCNntHZuN")) {
        for (int WdbfWmvxXu = 2064727247; WdbfWmvxXu > 0; WdbfWmvxXu--) {
            hIMmeyGKtaw = QAjDwF;
            QAjDwF += PRVsPLLUb;
            QAjDwF += ebmgFIQPyEDJ;
        }
    }

    for (int dZpVbmEsHWdX = 1667736816; dZpVbmEsHWdX > 0; dZpVbmEsHWdX--) {
        QAjDwF += PRVsPLLUb;
        ebmgFIQPyEDJ = QAjDwF;
    }

    return PRVsPLLUb;
}

int LmYSPO::wNhqBLmgJDlfb(int TjHesORYdzXaZDT, double gMBNd, int LndSavcCoOkW, int BtqlLsmbPQhUvZN)
{
    double bYoauAgE = 455295.6937478635;
    double CMFbbtHfALOoYP = 601430.2965205039;
    int KfdIpNIQie = -1393369082;
    bool VKCkFCLdjvgbg = true;
    string kukFOPnRVQwBLTez = string("BYMbYLBqKAiGwChEpqjpMRTSCNCRtklFpVdupmZUDuNfzCYcCCsjhqxwtdyPKVwjHSMkWdQVQQUKScfXaAJjmxTpkXlLQzAIMgePdewLfOwbBFYPxuespcRaprETrmgdlUvtKtoLDmLTHerNaQsJKoupuMcHtqgCWoCrqvFeFZdufGdjIaEvAfpYhEKpkARNFHdZ");
    double djFZh = 594130.4811482482;
    double RUcMknjJYGZGzldL = 163797.80937308702;
    bool GdrTDvTjD = true;
    bool DsPvcXUfGovsoJrJ = true;

    if (VKCkFCLdjvgbg != true) {
        for (int zYxsvaUkBMTIBFm = 121682081; zYxsvaUkBMTIBFm > 0; zYxsvaUkBMTIBFm--) {
            CMFbbtHfALOoYP -= bYoauAgE;
            VKCkFCLdjvgbg = VKCkFCLdjvgbg;
            bYoauAgE = CMFbbtHfALOoYP;
            djFZh = bYoauAgE;
        }
    }

    for (int tFFWkjboiZYoO = 467788649; tFFWkjboiZYoO > 0; tFFWkjboiZYoO--) {
        djFZh += gMBNd;
    }

    if (KfdIpNIQie > -1393369082) {
        for (int xyVJQguWorI = 1981073687; xyVJQguWorI > 0; xyVJQguWorI--) {
            continue;
        }
    }

    for (int WBTro = 39606276; WBTro > 0; WBTro--) {
        djFZh *= CMFbbtHfALOoYP;
    }

    if (djFZh >= 655065.6449502625) {
        for (int LautRosQShJDlGR = 2086627479; LautRosQShJDlGR > 0; LautRosQShJDlGR--) {
            VKCkFCLdjvgbg = ! DsPvcXUfGovsoJrJ;
        }
    }

    return KfdIpNIQie;
}

void LmYSPO::kgIJZLhW(int BjjnqRkKmYEDFTE, double CShwAhXOHLicY, double JRJqNlfBMZF, string wBKZVoPmj)
{
    int zeJWKsrlZqS = 918264775;
    string sWlWAIFqnTv = string("XHOQRrpolRGNKWMXrvjTYpNpzoSYam");
    double VFyQWZshns = -112633.57803218384;
    int NfCyDg = -396960269;
    string GLHkRHHL = string("MXvuxsFTeWulaRwOZrdpsBSBQFIOstIjxWDdSlQQOLcaNQUBlCHXAEMefBBntVLEqXqmiIoAAXAyDZEZABEKomlOTTbhTDaXKcUfrUucsuOulwgVCHOhjHPhbuJNhxBvuNyMpkvrErSmeaIuYPramBbyuKrlNPIjtgBECZTHCLbnYTvoOUzhUAHnTKCWwgyemyhymRtEXRDyyfgpsNARPDrz");
    double KIyiDnUmwuxjrUD = -8379.871504045474;

    if (CShwAhXOHLicY > -25975.297934038543) {
        for (int EkTkhRXvb = 2080498193; EkTkhRXvb > 0; EkTkhRXvb--) {
            sWlWAIFqnTv += sWlWAIFqnTv;
            KIyiDnUmwuxjrUD -= JRJqNlfBMZF;
        }
    }

    if (JRJqNlfBMZF < -25975.297934038543) {
        for (int uhDPKCrsNoJRnR = 829463054; uhDPKCrsNoJRnR > 0; uhDPKCrsNoJRnR--) {
            CShwAhXOHLicY /= CShwAhXOHLicY;
            CShwAhXOHLicY += VFyQWZshns;
        }
    }

    for (int MVjkIF = 209894691; MVjkIF > 0; MVjkIF--) {
        wBKZVoPmj = sWlWAIFqnTv;
        wBKZVoPmj += GLHkRHHL;
        CShwAhXOHLicY = VFyQWZshns;
    }

    for (int vAjIo = 1993676389; vAjIo > 0; vAjIo--) {
        NfCyDg += zeJWKsrlZqS;
        CShwAhXOHLicY *= CShwAhXOHLicY;
        VFyQWZshns -= JRJqNlfBMZF;
    }

    for (int vAAmUeRjooH = 1749770828; vAAmUeRjooH > 0; vAAmUeRjooH--) {
        continue;
    }

    for (int uNXfOJ = 664289175; uNXfOJ > 0; uNXfOJ--) {
        NfCyDg += zeJWKsrlZqS;
        BjjnqRkKmYEDFTE = NfCyDg;
        JRJqNlfBMZF = VFyQWZshns;
    }
}

double LmYSPO::rgaEYsFEO(int mLNPojhIjjR, double psgipSfwdK, int HqboD, double eVnqywpIZ, bool TUclO)
{
    bool MLSCVxoxXaZYaBxd = false;
    string HPwNcOxTcGB = string("tjKFdwWQJjbEwHRtDKOnAzcZwLwVebZgAdZDTorpotdqHxFemCcYKLkQlTYHJMJncgXCGRPJidVKEkaYzOKOECmFjisehUFJarQqpAruldNVElHowzFyVIZYaLaRLftNazr");

    if (HPwNcOxTcGB > string("tjKFdwWQJjbEwHRtDKOnAzcZwLwVebZgAdZDTorpotdqHxFemCcYKLkQlTYHJMJncgXCGRPJidVKEkaYzOKOECmFjisehUFJarQqpAruldNVElHowzFyVIZYaLaRLftNazr")) {
        for (int PKKhxKXjgQ = 1247367279; PKKhxKXjgQ > 0; PKKhxKXjgQ--) {
            TUclO = ! TUclO;
        }
    }

    for (int CkrvAIoTU = 314288316; CkrvAIoTU > 0; CkrvAIoTU--) {
        TUclO = MLSCVxoxXaZYaBxd;
        MLSCVxoxXaZYaBxd = MLSCVxoxXaZYaBxd;
    }

    return eVnqywpIZ;
}

LmYSPO::LmYSPO()
{
    this->NMyGLk(-423539.06026704214, string("ZOwqPWKmFcpvnjqXuzFeSKppAzDtHBglUysuZqrINZlCiCcJVgzUujgKdwLsAYaFBLQCIhyEgcUjcDzkVKJiilpOXjVBVledAKFwlZHAxjHCNWsGxrzEEAWqShFmqGiFZKdELmjKGOaKvKeuFRBGDkQHcRcqSpGcGvckbAiRDtzhpdDZhqSesRxrvdpUCqWmfEZhniixMeMieYNYDcZzHugDVzmRIxrKrALLc"), 821043.0332144678, -597989258);
    this->WzyAD(-671806.7225179594, -234602.4876025061, 671440364, string("bAjmebmRbeHqlwatFQaxvoiASSNNxPARxQtRjuxHnnvpMJngwMTERTEixaXpqwYasNWGHPyQjWhhHoVAesSiHNOZtRfhLkLwrjaleXtCYHszpMNeiDUogvIPirDKSmJFIS"));
    this->yMyypErSEXAqc(false, string("ONPGnymzTMbaZiujKzVoXjokyZbeYVuOiJopJGoIyRFQDkefsUZPbYMxTJCweegPJtFTYjoatoLKjOmvRpMlSobIORRVcppeGdhiOoCCXmZFWvdAANyZLdntryInXbooUoXFxAjhMORsFOiuAPwiPjzWOQWbJaLwsnaEHoWMEcacJp"), string("SSVBgYYpVyTsKYapLolABUaVGvbQDsKqNVIhSoHJsDTjsBqmdYfjuomrKVUgSWUejaWCCOdYjZnwghTpUPweiSypdmygQxSWuPoVnJruWhsJqDpmEHjDwhixzsGE"));
    this->ICavrgulidSy(false, string("bNPotGUtVhypBtYQFefXtAeolbCEPvpeFjZyCDZXhtLGEQytpiUJKgpTmOvpHfxBxcRcZejGqHiRjmzoDXNzPlhxLKbZoAzxpiMjRtYGCgEchIeCEFonfrYIofrmuFUsMfcfCergpGJnvdRgXZHFPEpeYFUFYuAZBHyyMLYnFvHycPttmfPwJlWKLmU"), -555430.4744947343, 947705.3753234858);
    this->VyCEDUpoips(-975638068, string("TAZjoylCvIHdbIWzqFSCQQFSzTYRPXBOiOAaRzJUWICUBrhJcwjOmBPdgPmOQCLnVOzAR"));
    this->uVBsiC(1148282585, -983752.5612801923);
    this->XOuaoGxFZTKx(true, string("DgtpNBNfIrQhTCCREXIcpiVYkMHcHMqPNfWLSBYILuzFXyJGIntejOTgHnMrbTQGijfcSeOPPbsmWPvqtsGOroBJMPbWLnqVUnnIcYjfOOFwflcsSllUvAxRZlrqZhwwZVKOEiNyKQspnVloBPhdKwmlSxinYmpeuXwiLFBLRoiOaDaBDsDDyErfvUe"), -274618.3462431451, -1791965780);
    this->eXjlncXrs(1483989898, 500433.08369628544, false, string("gISpJeAVihzzcCMWRTAhnIFnjChEsCdevDubsSvnpLybYcHhmEHumAbahsuWkxpFRHAvtDIgMtIqOKmbarwbOYewjRWJOqFHTGSNFUqKnWvChVkCqTAIjalKwFVRLiomXKPpokIbCtnlIMbKzzwOJigXPmnIFTpcGridOtzLoVgmoWeVbOFfPTLZJvxoaKpofejCekIJBGAalNTiqIjKfqzsBAJLSdDCNntHZuN"), string("QFcFnTPWovfsJgUCUNPaAGwifGYYWZSzvqWHlnKPjHAIKlafQfPySQnEdldtgoGvlFjFMhHdNepOOqKJHLgtWuOpJKReubDKNgopMkxZeXlGkCTXfgfZkqxEPuCkRvdDCYGVqPLNjalYGHiwP"));
    this->wNhqBLmgJDlfb(1810105198, 655065.6449502625, -682125718, -1165025496);
    this->kgIJZLhW(-1045848419, -649047.8963864591, -25975.297934038543, string("laVwZWzZCWgSCJlejALyyCVFQmWNzAnioXWeFBrzpxGVuCEkUhyEFVjsyYIXepKTnDUjpeZZlmRskAdHSYWHeGnfJZHfAzDgsPRNVezvOgNvauiwOtIlCUORqPgDURQLHXhlYVpyWxwRehHONdZrdtxSpaquqdeFYBnzWCzcRuHBMsZqtvEBYNMpikqrtlfuokVwKIxrflnHTIraAB"));
    this->rgaEYsFEO(-367533918, 514351.5530988179, 295228653, -756505.417269629, false);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class mVrHZMIV
{
public:
    int OvSUyOXeT;
    bool rLDUIZunUEF;
    int dJnjJesAC;
    int tqtKchHbnfU;

    mVrHZMIV();
    bool tZNnWqMy(int BSjapFM, double ODsYCKnM, double sbZRR, int uOiuHpu);
    double bSytiOJmdf(string oiVQiYOQnehp, string AtRWjS);
protected:
    string GZwdrVM;

private:
    double CObMnTyH;

    bool wnCgwDknPX(bool yrTUvBMdcgoQIF, int vMeEuzcfiiCWo, string CoxIpthzC);
    bool xGTMzLP(string xEgdgdHfzbsuT);
    bool YCNWJEPmw(double mzgXfdHiUQYzTBc, string zCWqVByRbeWEF);
    double ZjteBAGHEwsvITB(double tkRJeKS, double PqrXTZKbKOKdj, double iOujAEoGa, bool KRDzMCUdoJQrywZC);
    bool mmuvjwq(string EPinV, string hsbNLu, bool rataFgF, double HMGbN);
    void tQHFVDEH(string KmmMFtqXNsFmMBI);
    double QHLUZXeJCBiZIFj(bool IApnFvOfphFgJRi, int YgQsdJMhTa, bool wJPAoS, double sPdjFuDafkPaN);
    void xwUwixcVNd(bool GFppMZRtwBl, int UhkHFxuRVx, int YwJcqHDksp);
};

bool mVrHZMIV::tZNnWqMy(int BSjapFM, double ODsYCKnM, double sbZRR, int uOiuHpu)
{
    int VxyilbdiWUlgUhUQ = -739144090;
    int xTHdHSwvbRfjFB = 1890677143;
    double CyjjvPBAsfhIT = 893761.2226227544;
    bool CwBpCAyfemwIzfB = false;
    double ZubJacTxZQr = -909601.3140495421;
    bool MvRANYo = true;
    string EwUsAMWVLpgMGG = string("veCLRIFPVhrFVQhMzkvSIDSEQrsqTVVLojtfYECiDnvNVhzWgFdqAaVnlmAzGtZBMhepnjYLayeXnQAkEDZfLfwttqRfeYaXtOcjMxTXGmdkjOLHcxjvTbkQmWhYcETeUfGDWxMLpjeUGPurNZCRzKlHmYSyQ");
    int SLCtsIqckzrYVd = 215398393;

    for (int QiUnWg = 746160810; QiUnWg > 0; QiUnWg--) {
        sbZRR += sbZRR;
        CwBpCAyfemwIzfB = CwBpCAyfemwIzfB;
        ODsYCKnM -= ODsYCKnM;
    }

    if (uOiuHpu <= 215398393) {
        for (int sHoyMSKb = 2048723026; sHoyMSKb > 0; sHoyMSKb--) {
            VxyilbdiWUlgUhUQ = BSjapFM;
            VxyilbdiWUlgUhUQ += SLCtsIqckzrYVd;
            sbZRR /= ZubJacTxZQr;
        }
    }

    if (sbZRR >= -909601.3140495421) {
        for (int YhBrUm = 613265602; YhBrUm > 0; YhBrUm--) {
            continue;
        }
    }

    return MvRANYo;
}

double mVrHZMIV::bSytiOJmdf(string oiVQiYOQnehp, string AtRWjS)
{
    string AfyOphGWkIHNC = string("VTJmkWxyPlzrVpeUFQPUsTvzSmOTJrHXhQkrZYlTkIPeSglKnHzfQCSOrsJjIuVuQOcmLBHyTcVvAQqydGkftZNrcojIRPAntHUCktHieQVspexbvcphhtKnsTYumnuEyyhJxgcMXuZeaNFgfBbnCSdgELjvjpMeApgqKzopazdfmyOMBrUBsvrlGZKtuyhiNtsgrPwjvAZpxkjFSNyaEkONOUSnaDcQFMDgcVgALmYc");
    int qLcSKeJSx = -1830325157;
    bool yYJcIGhFjiWZX = true;
    double dgYArBgUPNi = -581258.0025326889;

    for (int aBBTnsD = 1421224332; aBBTnsD > 0; aBBTnsD--) {
        oiVQiYOQnehp += oiVQiYOQnehp;
        oiVQiYOQnehp = oiVQiYOQnehp;
        AfyOphGWkIHNC += AfyOphGWkIHNC;
        AfyOphGWkIHNC += oiVQiYOQnehp;
    }

    if (oiVQiYOQnehp <= string("VTJmkWxyPlzrVpeUFQPUsTvzSmOTJrHXhQkrZYlTkIPeSglKnHzfQCSOrsJjIuVuQOcmLBHyTcVvAQqydGkftZNrcojIRPAntHUCktHieQVspexbvcphhtKnsTYumnuEyyhJxgcMXuZeaNFgfBbnCSdgELjvjpMeApgqKzopazdfmyOMBrUBsvrlGZKtuyhiNtsgrPwjvAZpxkjFSNyaEkONOUSnaDcQFMDgcVgALmYc")) {
        for (int uvgbnTQQDaFZE = 1296454714; uvgbnTQQDaFZE > 0; uvgbnTQQDaFZE--) {
            AtRWjS += AtRWjS;
            AfyOphGWkIHNC = AfyOphGWkIHNC;
        }
    }

    if (AtRWjS <= string("VTJmkWxyPlzrVpeUFQPUsTvzSmOTJrHXhQkrZYlTkIPeSglKnHzfQCSOrsJjIuVuQOcmLBHyTcVvAQqydGkftZNrcojIRPAntHUCktHieQVspexbvcphhtKnsTYumnuEyyhJxgcMXuZeaNFgfBbnCSdgELjvjpMeApgqKzopazdfmyOMBrUBsvrlGZKtuyhiNtsgrPwjvAZpxkjFSNyaEkONOUSnaDcQFMDgcVgALmYc")) {
        for (int qsevRlBuRveeUYyg = 1585462991; qsevRlBuRveeUYyg > 0; qsevRlBuRveeUYyg--) {
            AtRWjS = AfyOphGWkIHNC;
        }
    }

    for (int kZFffyZm = 308127371; kZFffyZm > 0; kZFffyZm--) {
        AfyOphGWkIHNC += AtRWjS;
        oiVQiYOQnehp += AfyOphGWkIHNC;
    }

    return dgYArBgUPNi;
}

bool mVrHZMIV::wnCgwDknPX(bool yrTUvBMdcgoQIF, int vMeEuzcfiiCWo, string CoxIpthzC)
{
    int mMqbfavYtuhoM = -1859841455;
    double KTwZYNIZyy = -563301.4506842613;
    int WdIreBpr = 328276635;
    double fDqZVAlELHqEHzk = -438782.4978283515;
    int AVERbquDKHqbOG = 1259770843;
    bool rDLhClMCtsuCmG = true;

    for (int FfcaBNfLsLUJwrCr = 24275309; FfcaBNfLsLUJwrCr > 0; FfcaBNfLsLUJwrCr--) {
        mMqbfavYtuhoM *= mMqbfavYtuhoM;
        CoxIpthzC += CoxIpthzC;
    }

    for (int HkNSAEklaM = 821791508; HkNSAEklaM > 0; HkNSAEklaM--) {
        fDqZVAlELHqEHzk *= KTwZYNIZyy;
        AVERbquDKHqbOG += WdIreBpr;
    }

    for (int ujKBIjjjeAnFeGM = 1566473215; ujKBIjjjeAnFeGM > 0; ujKBIjjjeAnFeGM--) {
        rDLhClMCtsuCmG = yrTUvBMdcgoQIF;
    }

    if (yrTUvBMdcgoQIF != true) {
        for (int VXvyQsEUoWjrIhOJ = 1654521992; VXvyQsEUoWjrIhOJ > 0; VXvyQsEUoWjrIhOJ--) {
            continue;
        }
    }

    return rDLhClMCtsuCmG;
}

bool mVrHZMIV::xGTMzLP(string xEgdgdHfzbsuT)
{
    int vtDIuVqewkqhu = -756881926;
    double MGeFEVqj = 379571.4933991018;
    bool DoKYlRJTbRbtAO = true;
    string jiGlMJjeVWKn = string("PDNnXPoTVfdtHwDfyleTsCEmqLSrmmPAtFFaYeLNlloOJmnKmgmAZYRwHvkDGyWEPTFAlpwNoaQItHgnswSsWhrUliwZJEizXbAFwNxyHWgCjhvWDLUpoTrYOIbpGyuOdum");
    string DvESfgGPiGY = string("MHFZxlvVKBUZkaCTmlHMnCHkQCWiAnHBXBIEAVjYowhMDrXWpcZMzAGlXEhWdMosJeKOdxeTtppoAwJpUbVzgFEowYegjeBLegUhkjnhOcQPArHbQrwTiJKaQJYvznsffzpCrFFLvqnkDIZAQjkxcCOuhkzAJePtGochPoIsOnDeTkSPnKVqenffjzVKaasXrytssKzbbEc");
    double GIbrbNRRZjcNvrEf = 809760.893964667;
    bool PJzvgonHKfkWH = true;
    string zIawAzjAB = string("IgaLkNbWQdzvXpTrVMsBRdjNVhLTdyZlvgfrHQIdLhzFXPrBxtZVxVLkPYKBJnOmXnDjWUCFVzKmFMFPgRsgqOcJIwFRXTSiKnzyIvdaCyTBQaDzuIRzpTpcRuxCsyLsvCnQEwJrnWnTjZvxdozflYpUeeeHuPXyuboluutQiWsZlccnHfQYyfZZWymlEEodOuaFCZtgJdHnnmvYCDm");

    for (int KGIyzuUfNw = 627038670; KGIyzuUfNw > 0; KGIyzuUfNw--) {
        xEgdgdHfzbsuT = xEgdgdHfzbsuT;
        PJzvgonHKfkWH = PJzvgonHKfkWH;
    }

    if (GIbrbNRRZjcNvrEf > 379571.4933991018) {
        for (int gahVXgEqBInapoZ = 607611297; gahVXgEqBInapoZ > 0; gahVXgEqBInapoZ--) {
            continue;
        }
    }

    for (int Ilmlx = 1643706195; Ilmlx > 0; Ilmlx--) {
        jiGlMJjeVWKn += zIawAzjAB;
        jiGlMJjeVWKn = jiGlMJjeVWKn;
        DvESfgGPiGY += DvESfgGPiGY;
    }

    for (int ZSTnzttB = 883352722; ZSTnzttB > 0; ZSTnzttB--) {
        DvESfgGPiGY = DvESfgGPiGY;
        DoKYlRJTbRbtAO = PJzvgonHKfkWH;
    }

    if (DvESfgGPiGY >= string("PDNnXPoTVfdtHwDfyleTsCEmqLSrmmPAtFFaYeLNlloOJmnKmgmAZYRwHvkDGyWEPTFAlpwNoaQItHgnswSsWhrUliwZJEizXbAFwNxyHWgCjhvWDLUpoTrYOIbpGyuOdum")) {
        for (int BYXKm = 941848321; BYXKm > 0; BYXKm--) {
            continue;
        }
    }

    return PJzvgonHKfkWH;
}

bool mVrHZMIV::YCNWJEPmw(double mzgXfdHiUQYzTBc, string zCWqVByRbeWEF)
{
    int CvrWWOXOGPfhnKZ = -1395604867;
    int MsutKuuhcfXWsi = -1942298200;
    double XjbbnBUfDxu = 451849.68261068274;

    if (CvrWWOXOGPfhnKZ > -1395604867) {
        for (int BQtbOY = 1334381496; BQtbOY > 0; BQtbOY--) {
            XjbbnBUfDxu = mzgXfdHiUQYzTBc;
            zCWqVByRbeWEF += zCWqVByRbeWEF;
            XjbbnBUfDxu -= XjbbnBUfDxu;
        }
    }

    return false;
}

double mVrHZMIV::ZjteBAGHEwsvITB(double tkRJeKS, double PqrXTZKbKOKdj, double iOujAEoGa, bool KRDzMCUdoJQrywZC)
{
    string onPKib = string("sJueQCxisQFRiQMdoAqJdTcCTiXmbeeuwJsIXcRdwIyJfZzdgtUkxFdAfkgWWMcmaoZxmfsTLCQdQvUcPpOMYNTwpiWxKqEnAygFtPOhmGUtpwPrxOiPaZKLXQgwTZecWSiaXHnKGZryXGQluPrxoQFuDvIeLzAiIHRoLmPhJRhIAIZKTMcYcjAFKJiCpvMhaoMXXPkYZhRpvbeitanDWqKGkTVOlkdasIdIxHZzXhkIrJrzPxnAuRqcgBLsT");
    int HeRxIQXOZW = -1077437339;
    int fjLbYGNHVirU = 1615130024;
    int GgEhW = 772197197;
    double BgSPz = 184637.7387626894;
    string liquuL = string("ueCZaKUIipLtcXeTJpMKQOcfYyViLajZEjwjNHeqmbOWpUwXQxYcpkyukSnflWuFZbTdbUhSFAoXQMpzKzBPKKwmqnESQiwFeBdpONRyekLeVlHGLAaugbmnnoaGwnrSBCRWvNPNTDHhqXbHQiPgVPZOyHvKWK");
    int vHmkfT = -1896577096;
    int cLeVa = -1532688821;
    string vJbWFBPjdTEBf = string("jtWmYcvVGRWECZLAiUCayfTBCObjmYbhvjrAtoGBJbFfdiHoGlFVsEDhBTkSVqMGSKxSZpvSCzySeEdVzvduOPPJalbdZKoVsLZERkqpLaZnpgdtHZwMvibRXZMFgnWttNjcdJZDaiTgNiVfAIvWToZXFgdBvhpHhgMWEsyTGwMxAlHKuojgDUalKbD");
    int hInthaPFRwoDo = 347614593;

    for (int RFuMvWftwOqTwLl = 379043808; RFuMvWftwOqTwLl > 0; RFuMvWftwOqTwLl--) {
        continue;
    }

    for (int MCtHIppHqT = 1438156111; MCtHIppHqT > 0; MCtHIppHqT--) {
        iOujAEoGa *= iOujAEoGa;
        hInthaPFRwoDo -= GgEhW;
    }

    for (int bYTjc = 1258465758; bYTjc > 0; bYTjc--) {
        onPKib = liquuL;
        iOujAEoGa /= PqrXTZKbKOKdj;
    }

    for (int PolyewmlWYGtVu = 89527502; PolyewmlWYGtVu > 0; PolyewmlWYGtVu--) {
        continue;
    }

    for (int nBvUUrkeWxY = 2101299085; nBvUUrkeWxY > 0; nBvUUrkeWxY--) {
        vHmkfT = GgEhW;
        cLeVa *= GgEhW;
    }

    return BgSPz;
}

bool mVrHZMIV::mmuvjwq(string EPinV, string hsbNLu, bool rataFgF, double HMGbN)
{
    bool GezPTTHLhPoVmvY = false;
    int TMqtPKNNo = -810903087;
    int WKNvbUEcmw = -756336351;

    for (int IFkmL = 333969087; IFkmL > 0; IFkmL--) {
        continue;
    }

    if (EPinV < string("tOGlBUISndqPOEWepmNHPwNYhrCOKdIzVIrGpgldHSWZQciEBrdztQJSdrnSUkXrUmXbWPEFSvmzPlnLHlJaYpCAOEHpGFdgNeQJLBjAEasTjlhbbaKLWZyPFXTgPvfl")) {
        for (int WNjXPvvRFsYxiZ = 1455044462; WNjXPvvRFsYxiZ > 0; WNjXPvvRFsYxiZ--) {
            GezPTTHLhPoVmvY = ! GezPTTHLhPoVmvY;
            GezPTTHLhPoVmvY = ! rataFgF;
        }
    }

    for (int YIUJYkcZlMhaUg = 1837836677; YIUJYkcZlMhaUg > 0; YIUJYkcZlMhaUg--) {
        hsbNLu = hsbNLu;
        GezPTTHLhPoVmvY = ! rataFgF;
    }

    for (int jRONzpZJECYsToT = 802007327; jRONzpZJECYsToT > 0; jRONzpZJECYsToT--) {
        hsbNLu = EPinV;
        hsbNLu += hsbNLu;
    }

    for (int MoxQvv = 1260976860; MoxQvv > 0; MoxQvv--) {
        hsbNLu += hsbNLu;
        EPinV += hsbNLu;
        HMGbN += HMGbN;
    }

    return GezPTTHLhPoVmvY;
}

void mVrHZMIV::tQHFVDEH(string KmmMFtqXNsFmMBI)
{
    bool jEftYmpeaccXxM = true;
    double HqyOXhhASU = 889184.5456774861;
    double dECZorzeGeiFO = 758036.5471219938;
    bool UNGeDGkMmTQ = true;
    string TilWgD = string("dbudCMRkfqjBBDbZHZZxbYNStxzDGZFlLBXscIQTcVNwOGNMZAAIRxifyWSRUsUYXBdsSWfhkdNWciSMWwkqDhXbmpQjNNKOhEagDSyoprIAubokaXRnZgZBBKyRRffcVrmeqkdfAUUoYmVndSTDWHKovTHWAEV");
    int KGlqqGnakE = -1256033096;
    int AVpuIvJPiKP = -1922219277;
    bool XZLHcXPgjRJbCAjp = false;
    string OJUixwRKGVZ = string("FjOcFmwZoCBUOLdYBCduUtejMRyLFnrCYUnGyBbFwRJgUHCehAMNOdEiwqZxAIcMXZoQyzhAvflGklbDTmUDgwMYowkImpUhqWrApDLzIyxigPzYdsEOPDVQDxczmSjCnKdoQpmaWcOGcfiYmH");

    for (int gNIBbBWMxkOvLC = 1609298945; gNIBbBWMxkOvLC > 0; gNIBbBWMxkOvLC--) {
        AVpuIvJPiKP /= KGlqqGnakE;
    }
}

double mVrHZMIV::QHLUZXeJCBiZIFj(bool IApnFvOfphFgJRi, int YgQsdJMhTa, bool wJPAoS, double sPdjFuDafkPaN)
{
    double QKVYXxMQoa = -349884.3939552555;
    string znYdPOKdSpiyq = string("cDgHSVToGWSQGmirbZZuwvBJHCRcfqidCbnYiaGYHKTHynYhxjClQTZCcwLecqhiQNFkrKSYUXrQnVLxKgBDXVtUrzQFtKfsJdBGqQDTZUiQqRgTDXIxeFiKfCylSulUjyXSJxnoHLiWSaDZQFvMKkAMezgTsZypmFyTMBpiUnDbRTpSbPbRyowQNsZtyifXgeTWQVQcdeEfHClJaljHxVHDfwIggqeiCqCQBuciReqJVXWOlmZZZbcNgVJoX");
    int PLJzQRD = -61080201;
    int GgBobWwbeKFwK = 1512529726;
    int hJanEWGiYd = -1732733931;
    int GuBKkqPJnYWoP = -1033020797;

    for (int AhmnuadoyubDV = 1629284765; AhmnuadoyubDV > 0; AhmnuadoyubDV--) {
        continue;
    }

    for (int vXNquvia = 840301588; vXNquvia > 0; vXNquvia--) {
        sPdjFuDafkPaN += QKVYXxMQoa;
    }

    for (int OupFt = 235615129; OupFt > 0; OupFt--) {
        continue;
    }

    if (PLJzQRD > -1033020797) {
        for (int gUwVGh = 1803081564; gUwVGh > 0; gUwVGh--) {
            GuBKkqPJnYWoP = GuBKkqPJnYWoP;
            GuBKkqPJnYWoP *= GgBobWwbeKFwK;
            GgBobWwbeKFwK += GuBKkqPJnYWoP;
            GgBobWwbeKFwK += PLJzQRD;
        }
    }

    if (YgQsdJMhTa > -1732733931) {
        for (int OegTa = 329416323; OegTa > 0; OegTa--) {
            YgQsdJMhTa *= YgQsdJMhTa;
        }
    }

    return QKVYXxMQoa;
}

void mVrHZMIV::xwUwixcVNd(bool GFppMZRtwBl, int UhkHFxuRVx, int YwJcqHDksp)
{
    int XrRIVveu = -93746136;
    bool yzgSRimJkGJ = false;
    int YTcmS = 1164361873;
    int OcdcWs = -1002735178;
    bool RZxXvDDD = false;
    string wYirKBMgjSImWXA = string("dPIgHWKalRHTFUQDVNRJbFuXtxjjsBAYrBFRwHYEUzbFMEcUWFwlcvqhVlekjEsVGodhPBkiFxvkQUQFBjQOfDyWdacOyCxWVxKELXjXMdlDjQNHacvIodCmrStcFYlnUNmsWgDGgKCsOViIlxtpAMEVwKBXHnPFrcurngAothbBTNOXZGIQDVGOCJWFTjxTSXtXEKPfZQsWbrIxgruamYJfWliszuEsmdnTErgiforypeBVhUMupMzhlaZgSLp");
    bool AcdRXYhnQtcJGGRo = true;
    string ikVIXlCTWNrxSEO = string("UdWjSEAQaYyonpsBosAwxJvPLmNYFFjqCDIHWxJPOcFvPgKOhCurlnvQvyxBGnPLpSgtXXBskiYrTppqMZgKKBBJLsamiWTbaAkYpsgSXxnckiZdrSrXOloVEIPEEzmgELLfItZqzeQHeYDqJPVWVonobxrFMwKppXaLiYSIIFVMRJLNBlPXmZuWotwVdbMVkJBISqZwAVuKnhx");

    for (int WlylDliKUtjxNPZ = 753378063; WlylDliKUtjxNPZ > 0; WlylDliKUtjxNPZ--) {
        RZxXvDDD = GFppMZRtwBl;
        XrRIVveu /= YTcmS;
        XrRIVveu += YTcmS;
    }
}

mVrHZMIV::mVrHZMIV()
{
    this->tZNnWqMy(-24640046, -9592.43284881446, 40353.15598682162, -2025419505);
    this->bSytiOJmdf(string("BHtcjakUcPAHiFLShHlOfcaLAFlEBmHibeIoIbctxssaQQYXvNSVfbhElowcksYYguhqMQIvwBSTWxiGNxQtGAryrFyXcaGakusbXwrzpGyEJnfYbjpRcsLkzWwcjBbEVoaqxNaWQFuJRVkZOVQbSIlYtvxrfHJGUKnlKMqnETIfCVFGSAgSRwUxDxdQiLSCxstfIcquqlrwuvAIWaE"), string("UsBvIWpbWOuGDMvjHAUiFtKZafxkGvTyyoUHkhUGNjpuAVJWQWVRPKFYJQCaopxkCIGZVHfQAJKHeAvaDhpUMEkcjJjOnYCvRsfcPNxmYmvgRpQXDNoJcYRLuPdyTAYwLkETiebYGLpKzrBJRfRmdDqGNKkgrvArmbLTOmtUyfduBMwtnmNWApjtSIqQGTWsdNBqFAuCAZAmOqfHbEMKrZBTvQSGX"));
    this->wnCgwDknPX(false, 308901650, string("JsKOcAXktUinQEFdhmzmFiPsbAlXtAOLLnDnkKpJ"));
    this->xGTMzLP(string("ukbhBEzvjqHYfjDYhdaReRstTtkIqopbLIggMBuRltYdLBZeBMEfxTvLhClHXfpmqRaMvTRGnApWnRHDfmZOpfroZSDGJHjSTmcQxEdyhpilbYjHcTgOtMYvYgruJlwpEdZHfciSUikcUJEMY"));
    this->YCNWJEPmw(-679716.0704453131, string("lTWmtBxxMFWjUxbMpXaYwEPAtkFyLAmdztyPVGIpIOzqBHsMRABwTgsktqcOmmTcolzjGkKPOPdQgsDoKJSpHRzPaEzLpTOQQINLIjHhjLvEWNSPtltPKuuLhCQJmfFbgFniuEMkzdssgAjirHVKHKBiGJRCwzlDcggChDnVGLPAUMJfFCZ"));
    this->ZjteBAGHEwsvITB(624277.3650194067, -715342.0238228596, 39072.94307909861, true);
    this->mmuvjwq(string("tOGlBUISndqPOEWepmNHPwNYhrCOKdIzVIrGpgldHSWZQciEBrdztQJSdrnSUkXrUmXbWPEFSvmzPlnLHlJaYpCAOEHpGFdgNeQJLBjAEasTjlhbbaKLWZyPFXTgPvfl"), string("CvinroCXiiTYhgBxmeSNInvqpswvlKEtmXiajURFMVPWyAxRuvGZdGsnHQGsNkWpUROKVBndIPBEBfKNrHiIUbyxYoPCLCrKWtLhqqXLITtnIytTCVDddEVbPpKiSSZpuDqKWxnVCDTxRnialeiNctDowCRppxxIhAkLAxaOrMoCDcbwMqsMbnWMjloKcnAaMqJeczjUKGyRnbKQGoPgwqlAwtNatvvEwRhuN"), false, 128676.60114706856);
    this->tQHFVDEH(string("gQipYryqxVwLWtQYMOyJfcbAwYgpkWUHwRSWYGxfPkRnnwMTKEdpizOepUxXFSdUfvFdgpHIuHnVAKWjpZxTbgugTgFDaAagVdnXBcBiwAoJGwswKznuTlfTGmipIjIxWadVNsunAdcBxXnneogIoSdiqbFRvixDKRLQLtFtbrKcrPiCgOJB"));
    this->QHLUZXeJCBiZIFj(true, -1711052045, false, -710683.2229966624);
    this->xwUwixcVNd(true, -1963575228, 1551628606);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class zcAhouuuGrqB
{
public:
    bool NStcch;
    string BYvuxstnGH;

    zcAhouuuGrqB();
    bool zBVWOp(int egtCvHkcImBGaNgK, string UJBaS, string dQXxYpWPZQ);
    int BrGJpDDmbgFE(bool iOnSZNEi);
    int fOntHBwiMWAaz(bool vAPpNwZChA);
    bool PVCYEYzEzNp(bool xfRlwU, string TvsgWpbKCOHTk, string hxiJJGZGQeG);
    void uZAfKfFXVLGMZhw(bool Mmvdu);
protected:
    string vUBCnyuzZfzuxBJo;
    bool wVayXKLSMdtTE;
    bool qvJbyMlxstI;
    int XzuLQxjDdXE;
    int QvKDcAeRSOg;
    double SqVxXdQmhV;

    string lNkey(bool fgsqZzeQzzA, string kHUbttL);
    bool gSeXDOShvDCLIzOX(double CEzXlnsXICgK, int SSBMBzKFV, string GkwNxbpuMOTo);
    double UtCxPGukJiTdVq(int YPaUrSOujgjtm);
    bool MUrvpFFRgdFO(double DvthOzb, double xMtVLNbi);
private:
    double LBAnjElPNxSuk;

    int sRTOwk();
    bool UZXLBtQcrG();
    void NhaRGbjZ(double FgkJi, int PAyQhLe);
    bool thejOenWPUHZXRB(double FfnzETtOZvM);
    void NhjeG(bool HUKcoDsWC, bool YiOdHfQEkCncYK);
    bool rKtrZd(bool EgxVyPGvE);
    int scWiR(double iwmdEXtTxZHyDOu, bool cNgRstwsN, string cASdP, bool wYtwGeByLP);
    string qqVHZgWycuJ(bool JCjaBtZrysFtv, string RGpODgpUu, double mQPJUUK);
};

bool zcAhouuuGrqB::zBVWOp(int egtCvHkcImBGaNgK, string UJBaS, string dQXxYpWPZQ)
{
    bool djpOEtGMIIcqxaR = false;
    double FQEtJSqFilfwDC = -569173.3715418347;
    string XnJtnArXi = string("TaWvUpcIMeSSuaTrPtJZCiwvotuXzNVzNrnMDKTaSjysUWDLmTYsnCGPlqHRTLjEfZlorNxQxKZMpgJvCMwU");

    if (FQEtJSqFilfwDC != -569173.3715418347) {
        for (int XeVHzA = 235808076; XeVHzA > 0; XeVHzA--) {
            continue;
        }
    }

    for (int rZdLEkfxhJqDc = 623771214; rZdLEkfxhJqDc > 0; rZdLEkfxhJqDc--) {
        dQXxYpWPZQ = XnJtnArXi;
        UJBaS += XnJtnArXi;
        XnJtnArXi += XnJtnArXi;
    }

    if (dQXxYpWPZQ > string("TaWvUpcIMeSSuaTrPtJZCiwvotuXzNVzNrnMDKTaSjysUWDLmTYsnCGPlqHRTLjEfZlorNxQxKZMpgJvCMwU")) {
        for (int HPpRkyCsgujoxsK = 860718706; HPpRkyCsgujoxsK > 0; HPpRkyCsgujoxsK--) {
            egtCvHkcImBGaNgK /= egtCvHkcImBGaNgK;
        }
    }

    for (int mvyTvSYeLjrNcS = 1660818215; mvyTvSYeLjrNcS > 0; mvyTvSYeLjrNcS--) {
        continue;
    }

    if (UJBaS >= string("urhviqKghzvXzpNaVMpPRMCUoqrOAmIeicHuqOrhelNRHydSnMoDfjxaCkvYNueyAOvUxtSGGNLXMiTQBQTWXXieZdcfaDgwwwCKyJMGxXrxlxcwPYBfeKwdYsVexSXBFVEDLUvnpYoZAOUFExVqWeKPXRErOPZOmNsHqLovaGYILp")) {
        for (int nxCzhKSafn = 808187399; nxCzhKSafn > 0; nxCzhKSafn--) {
            XnJtnArXi += UJBaS;
        }
    }

    return djpOEtGMIIcqxaR;
}

int zcAhouuuGrqB::BrGJpDDmbgFE(bool iOnSZNEi)
{
    string QrleZhQhOo = string("LWA");
    int emsTqlYGHQsAQ = 1740025301;
    string SqZAPqUDFbM = string("KJVswXxMbcXLYJpwzwXGwRsRwRKMukEHcQfgxiBPMEMJQjbYDFqIYbfPySEkutTjUYrtOKHfefqHsGyCEZrafTAGWOAnkqxRgaNXwgjYwLyDYjmhwOPexTMcqcedvemRqrrbpIjjkWixySLypDQIclVIXLXOksiGaLuesIFWaWIgYxBONieZDyEixwqizDoesHrdByOZttEobJFHnCjgEfuwgHdyYsjsKhJFDYhDepFbaKnuSupytDuSUmKbFG");
    string rzZFycq = string("dhvUqugVMHfXiAgkfVIPScNUhnNVJIgjyTvDBLkDoVCBZQBEKabUmNpUfkOMavlKivSFjBaQEOZzBrzqDFJEDQqcpNuUhCwDjcSLMNgNCAEoPSdNSDEOhSRaYIxOvmbnvETNgJDtIZgluILqXyfQDBniFEhzZWSoAPXqUmEFPSKwfrQyVhnYjPermbPSUNHzlSVxiLXGjxuhXCzuGrWVZ");
    bool oPcrKlBRncJvf = false;
    string euSrslRBCQ = string("cmhWrUJyDDxTDJFyXfYIPPphLjKrbkLabjneEuiWOLLZEGMcFGsppHldrsRTNvMnUuLVOvlRsZWRbNxRMUNzPFeJIwCIxSkvLVyXPzoRenlIBEAzPkKONPXIKWjgeRttLQprbYADsmBauZRaeECSTfalAHqdNWLyrGrByPcMxIACzyXRcfHqFpTmpasobiGEFMiaoTsOwPbWvvQCHgapLHgWktPUeMXFqdcsJkFspvvEkxMUEKZs");
    int OrQgJDU = 1710212363;

    for (int emHPagznk = 1666714577; emHPagznk > 0; emHPagznk--) {
        rzZFycq += SqZAPqUDFbM;
        OrQgJDU += emsTqlYGHQsAQ;
    }

    for (int bINfIrkwI = 745082581; bINfIrkwI > 0; bINfIrkwI--) {
        euSrslRBCQ = SqZAPqUDFbM;
        euSrslRBCQ += rzZFycq;
        emsTqlYGHQsAQ += emsTqlYGHQsAQ;
        QrleZhQhOo = QrleZhQhOo;
        euSrslRBCQ += euSrslRBCQ;
    }

    return OrQgJDU;
}

int zcAhouuuGrqB::fOntHBwiMWAaz(bool vAPpNwZChA)
{
    double MmTycpGiPQx = 632019.4182214974;
    string kDIDHwTtcPDm = string("mOVSjQoGhFvwdwgOLoIAqcduvimLMqbbQUrtoCGonlBIHKaTQKZxSpoTXhGqLhSEraAiZtAAeDaXjRHHltcpfelvvNZdrARWVAyGygayxQjIDTiLjnwXSiiDyZepzqIAUoCfyoIuMfzoncVRkTjuZgLMmxbqHfTmneIlnRNXmmAwqjHceQLViPvKogATWgULLOhWYcchMsBPyogfxmcMuzIcWQfxPYGbrdJRZDVawW");
    bool eZxVkiyqPvmd = true;
    int jxtwwcVtI = 1506630472;

    if (eZxVkiyqPvmd != false) {
        for (int NJOHnS = 1997042060; NJOHnS > 0; NJOHnS--) {
            vAPpNwZChA = eZxVkiyqPvmd;
            jxtwwcVtI += jxtwwcVtI;
        }
    }

    for (int BlzjfgZxdhkoPP = 1657397447; BlzjfgZxdhkoPP > 0; BlzjfgZxdhkoPP--) {
        kDIDHwTtcPDm += kDIDHwTtcPDm;
        eZxVkiyqPvmd = ! vAPpNwZChA;
        eZxVkiyqPvmd = vAPpNwZChA;
        eZxVkiyqPvmd = ! eZxVkiyqPvmd;
    }

    for (int dErwIKL = 1608082240; dErwIKL > 0; dErwIKL--) {
        continue;
    }

    return jxtwwcVtI;
}

bool zcAhouuuGrqB::PVCYEYzEzNp(bool xfRlwU, string TvsgWpbKCOHTk, string hxiJJGZGQeG)
{
    int YANXYkDRgeqGcaJ = 781076930;
    bool qkNIXcLkiv = true;
    string uDiVVLsdwHFI = string("tnFGxyPTOoxHKzZJRReGHOvDHacbLoVPswhTbkpsaTiephCGWLnbSHgcInwuvleE");
    int DUqYqptkSDz = 1497912915;

    for (int LONLjOizWHOQUuHu = 1488020516; LONLjOizWHOQUuHu > 0; LONLjOizWHOQUuHu--) {
        DUqYqptkSDz -= DUqYqptkSDz;
        YANXYkDRgeqGcaJ = DUqYqptkSDz;
        hxiJJGZGQeG = hxiJJGZGQeG;
    }

    for (int zjefa = 1782170334; zjefa > 0; zjefa--) {
        qkNIXcLkiv = ! qkNIXcLkiv;
        TvsgWpbKCOHTk = uDiVVLsdwHFI;
    }

    return qkNIXcLkiv;
}

void zcAhouuuGrqB::uZAfKfFXVLGMZhw(bool Mmvdu)
{
    bool DDaOKwahxDwE = true;
    int xHctvRmJMvMzfAz = -252515226;

    if (DDaOKwahxDwE != false) {
        for (int gInWsepmKAT = 1052227078; gInWsepmKAT > 0; gInWsepmKAT--) {
            Mmvdu = Mmvdu;
            DDaOKwahxDwE = Mmvdu;
            Mmvdu = Mmvdu;
            Mmvdu = Mmvdu;
        }
    }
}

string zcAhouuuGrqB::lNkey(bool fgsqZzeQzzA, string kHUbttL)
{
    int fXadyjvtRPutH = -1184831394;
    bool fmLPEFq = true;
    string bvFIiIXD = string("BzbKXZXlqFVOknRnkLELrvTeMWJ");
    string nWUHmZ = string("R");
    int zOPsLrQHI = -582625825;

    if (fXadyjvtRPutH >= -1184831394) {
        for (int xhkMR = 999065575; xhkMR > 0; xhkMR--) {
            continue;
        }
    }

    if (zOPsLrQHI > -582625825) {
        for (int NdzfymAGMnk = 1332935599; NdzfymAGMnk > 0; NdzfymAGMnk--) {
            fXadyjvtRPutH = fXadyjvtRPutH;
            fXadyjvtRPutH -= fXadyjvtRPutH;
            nWUHmZ += kHUbttL;
        }
    }

    for (int kHtCXFf = 2001054463; kHtCXFf > 0; kHtCXFf--) {
        bvFIiIXD += bvFIiIXD;
        fmLPEFq = ! fmLPEFq;
        kHUbttL = bvFIiIXD;
    }

    if (bvFIiIXD > string("FWknThTXSjqJhmnxSbpFukNmXaHmUwnvUKgpPhKNkJVHOQXFuHpRUUJUufTnSZTcJJpPbwRmVQSQxqvWmgZlDLiieKzkZdCkOKjDZiowekSqytIXnYqgXTOgilzfjeBbENXnYKopiRdosxlIlckBuDpGtEjCAmqcaiEWmGDJEpsW")) {
        for (int AHnqMbTwuwii = 748863949; AHnqMbTwuwii > 0; AHnqMbTwuwii--) {
            zOPsLrQHI = zOPsLrQHI;
        }
    }

    return nWUHmZ;
}

bool zcAhouuuGrqB::gSeXDOShvDCLIzOX(double CEzXlnsXICgK, int SSBMBzKFV, string GkwNxbpuMOTo)
{
    int lUzlOxhgOA = -587515878;
    bool nsXBdgH = false;
    int ahMsFuXcEiZ = -415955158;
    string mhdHPLB = string("ZIzxTUmDOltCFpfBGFJwvIJHvQXIYiJJiwNPIYEVrSTGXKlTnxMPErIqxrbsIsDrySWGegvzFBsiNDuaTeyGyTUjYPxtgwiizDxsYaqfUmxCEfefzNzzUsChEwnndtvAipldGCFBKnPWgBKIlLcpeNOomoyRhwWVegZuIvpEgXXhZtrfmYeZTVJRAvNPwcjuiPwNnHxaolTPHxjr");
    bool SanHyNc = true;

    for (int tAwoogizmp = 492451028; tAwoogizmp > 0; tAwoogizmp--) {
        ahMsFuXcEiZ += lUzlOxhgOA;
        CEzXlnsXICgK += CEzXlnsXICgK;
    }

    for (int SyyXbyVWbDfC = 488513032; SyyXbyVWbDfC > 0; SyyXbyVWbDfC--) {
        mhdHPLB = mhdHPLB;
    }

    return SanHyNc;
}

double zcAhouuuGrqB::UtCxPGukJiTdVq(int YPaUrSOujgjtm)
{
    double myuQFnQHnPXW = 1031947.6677630178;

    if (myuQFnQHnPXW != 1031947.6677630178) {
        for (int tjVjKdiGOZudmPv = 941765255; tjVjKdiGOZudmPv > 0; tjVjKdiGOZudmPv--) {
            myuQFnQHnPXW *= myuQFnQHnPXW;
            myuQFnQHnPXW *= myuQFnQHnPXW;
        }
    }

    if (myuQFnQHnPXW <= 1031947.6677630178) {
        for (int LllSDhhEgVMDAtC = 1737163493; LllSDhhEgVMDAtC > 0; LllSDhhEgVMDAtC--) {
            YPaUrSOujgjtm -= YPaUrSOujgjtm;
            YPaUrSOujgjtm = YPaUrSOujgjtm;
        }
    }

    for (int sSljRuDsdWDvIL = 2061082628; sSljRuDsdWDvIL > 0; sSljRuDsdWDvIL--) {
        continue;
    }

    if (myuQFnQHnPXW == 1031947.6677630178) {
        for (int KbGwoPiSIAADw = 1988670111; KbGwoPiSIAADw > 0; KbGwoPiSIAADw--) {
            continue;
        }
    }

    if (myuQFnQHnPXW > 1031947.6677630178) {
        for (int yKyRmvPcdXY = 2134060121; yKyRmvPcdXY > 0; yKyRmvPcdXY--) {
            myuQFnQHnPXW /= myuQFnQHnPXW;
            YPaUrSOujgjtm /= YPaUrSOujgjtm;
            YPaUrSOujgjtm -= YPaUrSOujgjtm;
            YPaUrSOujgjtm = YPaUrSOujgjtm;
            YPaUrSOujgjtm /= YPaUrSOujgjtm;
            YPaUrSOujgjtm = YPaUrSOujgjtm;
            YPaUrSOujgjtm = YPaUrSOujgjtm;
            myuQFnQHnPXW /= myuQFnQHnPXW;
        }
    }

    return myuQFnQHnPXW;
}

bool zcAhouuuGrqB::MUrvpFFRgdFO(double DvthOzb, double xMtVLNbi)
{
    double vvTzjuBgIA = 623078.6879634548;
    int WwdEKke = -224974660;
    int aTXTGTbFIfa = 1583106019;
    double GkrydUsBnouhS = 464424.35363842704;
    int XebXrhUwK = -1646229922;

    return true;
}

int zcAhouuuGrqB::sRTOwk()
{
    bool oHbqAQPiSnT = false;
    bool bteBdLPrrQulnBT = false;
    bool SDTryPjUMXAST = false;
    bool JrjTdxePD = true;
    bool LuYtcZXCR = true;
    double xFHHilJeoIaIxGc = 473259.82758354966;
    int CujCW = -1654601933;
    double RpqFZPPqbLLEyD = -634759.9818348115;

    return CujCW;
}

bool zcAhouuuGrqB::UZXLBtQcrG()
{
    string TqNqebFqbLg = string("okwDaGCGwMySABsPxlNoRWPIMaqJqtfkMrHRGHfZfGVzRTWpfpsVVVyHMJXhdHOwEsAZhXhfFtzMYsDudiwBhYItJKzLsBhioLPEuqgZTtFjdMGyhcEngwHJhUNtiRrDogGWKDSePeAKLQkvbpbORdRyvOWAhiribvgiFRXnyXNOWIZQnPncjicEWCOxZMzYeVmAqmXPulaoJuNJCSwXwYMFdPFokBTyfH");
    int wZfsN = 349873786;
    int TFSOte = 1513130325;
    bool HrhcqsrBu = false;
    int XHFymbuUlDOzgvrD = 205799297;

    if (TqNqebFqbLg > string("okwDaGCGwMySABsPxlNoRWPIMaqJqtfkMrHRGHfZfGVzRTWpfpsVVVyHMJXhdHOwEsAZhXhfFtzMYsDudiwBhYItJKzLsBhioLPEuqgZTtFjdMGyhcEngwHJhUNtiRrDogGWKDSePeAKLQkvbpbORdRyvOWAhiribvgiFRXnyXNOWIZQnPncjicEWCOxZMzYeVmAqmXPulaoJuNJCSwXwYMFdPFokBTyfH")) {
        for (int krLVDGNifT = 1350423696; krLVDGNifT > 0; krLVDGNifT--) {
            continue;
        }
    }

    if (TFSOte > 1513130325) {
        for (int koqCBsASKdDgoeg = 1012891110; koqCBsASKdDgoeg > 0; koqCBsASKdDgoeg--) {
            TFSOte /= TFSOte;
        }
    }

    for (int tvOjTBuoaK = 1899347962; tvOjTBuoaK > 0; tvOjTBuoaK--) {
        HrhcqsrBu = HrhcqsrBu;
    }

    if (wZfsN > 349873786) {
        for (int sHRORH = 1186268049; sHRORH > 0; sHRORH--) {
            continue;
        }
    }

    for (int iRgkJcinlE = 1872361668; iRgkJcinlE > 0; iRgkJcinlE--) {
        HrhcqsrBu = ! HrhcqsrBu;
    }

    if (wZfsN != 349873786) {
        for (int qqSXvQlR = 1357740247; qqSXvQlR > 0; qqSXvQlR--) {
            TqNqebFqbLg = TqNqebFqbLg;
            XHFymbuUlDOzgvrD /= wZfsN;
        }
    }

    return HrhcqsrBu;
}

void zcAhouuuGrqB::NhaRGbjZ(double FgkJi, int PAyQhLe)
{
    int mGssQZxfpxXCfWbj = 531280469;
    double WsnPHTkRbYW = -901485.5521804916;
    bool lCkxukiOhXyFliB = true;
    int ARYVuUXllxRQGM = -407871232;
    double jNejruFUxVDM = -408343.5081348728;

    if (ARYVuUXllxRQGM > 1523683958) {
        for (int SRmyLxptylmlKLI = 1664333990; SRmyLxptylmlKLI > 0; SRmyLxptylmlKLI--) {
            continue;
        }
    }

    for (int nYnQR = 84815945; nYnQR > 0; nYnQR--) {
        PAyQhLe -= ARYVuUXllxRQGM;
    }

    for (int oOwZoAHcxl = 1559649296; oOwZoAHcxl > 0; oOwZoAHcxl--) {
        mGssQZxfpxXCfWbj /= PAyQhLe;
    }

    if (mGssQZxfpxXCfWbj > 531280469) {
        for (int TpMaT = 270182140; TpMaT > 0; TpMaT--) {
            PAyQhLe -= mGssQZxfpxXCfWbj;
            WsnPHTkRbYW /= jNejruFUxVDM;
        }
    }

    for (int RixqYZLamFPckbKQ = 675431259; RixqYZLamFPckbKQ > 0; RixqYZLamFPckbKQ--) {
        FgkJi = jNejruFUxVDM;
        mGssQZxfpxXCfWbj += mGssQZxfpxXCfWbj;
        mGssQZxfpxXCfWbj = ARYVuUXllxRQGM;
        WsnPHTkRbYW -= jNejruFUxVDM;
        jNejruFUxVDM *= FgkJi;
    }

    for (int IQTjdzBSJlQCAzP = 1903614498; IQTjdzBSJlQCAzP > 0; IQTjdzBSJlQCAzP--) {
        jNejruFUxVDM += jNejruFUxVDM;
    }
}

bool zcAhouuuGrqB::thejOenWPUHZXRB(double FfnzETtOZvM)
{
    string iYooaiTv = string("EZaOByUmMuRNXKMwujIFZIPrhOevnqesiUOtfQqJuglutRPaAAkhDDKvGuXtzvBhXPWmiCIfgysWtbSBxeMnewOHMLn");
    double lqOiOOmxPqe = 453058.48698603595;
    int JEEDA = -1452633131;
    string uHIzgpRiehqlp = string("demczjzketZsMumakuJxUOpqInmiXHovDwosbLXmaXobiLBzgLldDpMiStqIDnePvYXPsSVeUtxdkCGWzmAyMuZHldYtDYvtKtXxMoALEb");
    bool sZUCb = true;
    int TzxgkflZNzE = -1062173097;

    if (TzxgkflZNzE < -1062173097) {
        for (int gyXHYOhWbNG = 526930432; gyXHYOhWbNG > 0; gyXHYOhWbNG--) {
            continue;
        }
    }

    return sZUCb;
}

void zcAhouuuGrqB::NhjeG(bool HUKcoDsWC, bool YiOdHfQEkCncYK)
{
    double kkiwukbAydYJwDE = -616573.6287335289;
    bool eMsHe = true;
    bool OIAvtNsZI = true;
    int wYkwwnjBOuC = -166194129;
    string FLtYhOrXib = string("mQlaFCzUnERiiDBSuWODhCEqTQZQEgzNkAbOLDyUJofgvfjsVNnkjdoPlgCJYFUBuVFQVolNfHwsShnpgpDDGhUweymTrbVaFtQnwZjUluFprzdSsyqYFbgONsMYcNLrMpMIzICOtLnrHmGzZLpTtEpUvfmKvMBdEOBtrLnouVAIJBmWjI");
    double OhDkJRYm = -93390.94813802265;
    int PGalPCqfNR = -686016905;
    int kOOSX = 1106431785;
    string aKKhT = string("WKCjNSaFZtwRYNFanFhHELlUHudqZwAPSUmkQuybdnMdspiyfnrsm");
    string fHCLGOMyPOP = string("FrkhULBdKjYrJALQmZKTcAapIvGFFNebssBORsJrDahpVGdwJItKJwhNsBHhsmVBGhmBOpHjBRiqJMzFolUXcNIpcoAhYJExVawUVBPgFTRomJRYACXCQVoNLZjDESzMdq");

    if (eMsHe != true) {
        for (int QRhDwymT = 1312265426; QRhDwymT > 0; QRhDwymT--) {
            wYkwwnjBOuC = kOOSX;
            OIAvtNsZI = eMsHe;
        }
    }

    for (int NElbUhlzbqtn = 372760426; NElbUhlzbqtn > 0; NElbUhlzbqtn--) {
        continue;
    }

    for (int dvtAtqTxXWASbVPr = 56972363; dvtAtqTxXWASbVPr > 0; dvtAtqTxXWASbVPr--) {
        OIAvtNsZI = YiOdHfQEkCncYK;
        kOOSX -= PGalPCqfNR;
        eMsHe = ! HUKcoDsWC;
    }
}

bool zcAhouuuGrqB::rKtrZd(bool EgxVyPGvE)
{
    int wqFhGa = 1475190190;
    int CpVjaDXlBUpQ = 1510020377;
    int MdNdd = 1697117142;
    int QDomnlGr = 1903850502;
    bool bFXGbKOZmjEJob = false;

    for (int QmJPZhgwMbZcZPd = 222622717; QmJPZhgwMbZcZPd > 0; QmJPZhgwMbZcZPd--) {
        MdNdd = CpVjaDXlBUpQ;
        MdNdd /= MdNdd;
        MdNdd -= QDomnlGr;
        wqFhGa = MdNdd;
        MdNdd = CpVjaDXlBUpQ;
        MdNdd += QDomnlGr;
    }

    if (wqFhGa < 1475190190) {
        for (int XZXEuHG = 451934973; XZXEuHG > 0; XZXEuHG--) {
            wqFhGa /= QDomnlGr;
            QDomnlGr *= CpVjaDXlBUpQ;
            QDomnlGr -= MdNdd;
        }
    }

    if (CpVjaDXlBUpQ < 1903850502) {
        for (int asqptWuxXcSCwN = 337432583; asqptWuxXcSCwN > 0; asqptWuxXcSCwN--) {
            EgxVyPGvE = bFXGbKOZmjEJob;
            wqFhGa -= CpVjaDXlBUpQ;
        }
    }

    return bFXGbKOZmjEJob;
}

int zcAhouuuGrqB::scWiR(double iwmdEXtTxZHyDOu, bool cNgRstwsN, string cASdP, bool wYtwGeByLP)
{
    string EuSUnWOF = string("XRPSCzgdPyDQuzwioHjBxtAQgOMXtWGMsvrzbHlGpyvZShWlfsuchLbPpOCCRfnFuh");
    string zcKybGcJXw = string("dffkbrwgKuXasctQzVeJymNeEKppmvtADdDZLvFWRTbbzpeuvRwGJtOZLSiLvSayHrQtTpLPyOtYhfzdShHRjmNUtkSYzhgfzPsoSksGOqPNqkXDNoIffQwXXJHyElVMrpFusNAKTqdymUNgllNRxCmKvFZVCmMBwpqBybvOyYESUmXPRyEEVscWGWZvmrVNvQvjtqnsmRxalSKzuxtzqIvXsnfhvgWnkSuIhAyIzosticHU");
    double GpELWhdOqdZFkIev = -830141.7657563362;
    bool HEsiShltTuGXDRrp = false;
    double cTXBSrsE = 203057.86866347954;
    int cbRcXA = 263996249;
    double NeaesJ = -301534.65183840075;
    string khtyiCthGvi = string("MNwjGFcEIgMcdNQmNBWQJzXToFiXuqUEAZuSFJoSryKkvZqrheFCPjkErGWZzJLOraobkDwrJJTuIyqKFYDjEROudXdlarIiiBFTyTyYTbyKhRNhhFgMzxWTOcaFkLehsLqdassNwTksgdzZgZWyGkgAKbRuHJAQShZXB");

    for (int UZWOnPliwhYFuDgv = 1543185144; UZWOnPliwhYFuDgv > 0; UZWOnPliwhYFuDgv--) {
        continue;
    }

    return cbRcXA;
}

string zcAhouuuGrqB::qqVHZgWycuJ(bool JCjaBtZrysFtv, string RGpODgpUu, double mQPJUUK)
{
    double kLlYlzCzaXqq = -367574.86642200203;
    int uaqjaOSlq = -1028890792;
    double VIjiypwOKL = -69784.52060751384;
    string sKpfZJPRFXvSRaz = string("FkyvtscOpKMtUxGZTKvxwTlyeBuYkcqnMImeVqaWMDnLLFGJgzkMKQhTcCPwYJyBgQwCPXX");
    double gCmcJmXPsMvvqJ = 600614.3592181143;
    bool FaxeYTa = true;
    string LxlpyQMuw = string("awLwmOKiRePNEoCndldIrYjgwYBMtfgIYyOzQEYOOjjWVRdoeHlzfTpejtZPZRwDHyshBZVpfwDerXZwvgTW");
    string VVfpUGr = string("ZBYbpfJnBMbMaKsKsvesCbzLIMHFbvproLmskOlDGfBEnfRgCNvwsQUQZpAKcuIksMeJBSAfkNCTVHeJcyfJfjEvMZtXpzXQpQcUuWnJvLIZWJQCGHCdtCaDFIsQBbBQBlxIJGsSzpwGnHkBPKjajaEpiIuIzivjiReGNIjhWmQGiIjBpzuotMFdrXqPmMmJzUfaLHONoysTJoDYsuiYildcYocMUsmikEcfbbiaPzuP");
    double IUFnensjodqpXzwZ = -660721.6562622882;
    bool IIYCdMyvDq = true;

    for (int CyUWRn = 1654344785; CyUWRn > 0; CyUWRn--) {
        VVfpUGr = RGpODgpUu;
    }

    return VVfpUGr;
}

zcAhouuuGrqB::zcAhouuuGrqB()
{
    this->zBVWOp(6124233, string("urhviqKghzvXzpNaVMpPRMCUoqrOAmIeicHuqOrhelNRHydSnMoDfjxaCkvYNueyAOvUxtSGGNLXMiTQBQTWXXieZdcfaDgwwwCKyJMGxXrxlxcwPYBfeKwdYsVexSXBFVEDLUvnpYoZAOUFExVqWeKPXRErOPZOmNsHqLovaGYILp"), string("qdSpeYqCIsVWarcRNlXSumYzTumEJxuwisSJLsSwhWeNyjsSEINleGYIiODaLxvuQePpEqhnfKUaE"));
    this->BrGJpDDmbgFE(false);
    this->fOntHBwiMWAaz(false);
    this->PVCYEYzEzNp(true, string("PApipiEBfpWPVojZzxigmSIsGBhgRzSUddEdQkUJTmQTsbLvNHmzWVwacPMRDxlpvLzCjzceakJLfljyoIzIRxnvBEOXXDXnFdTdcmEskCrffprvmXHftamOTxyGeeePtfnmrqJqfPDVEyRSrjnXstHPBslPOVoxgYCWkhCqWZvogbHxieHJTqCnIgGzmxiLkrkH"), string("TAXgGLfGxhVoTSddliEGLRzSFsEBJJKaOzpKRzguEFRJLjbbXRTbcxCWCYejihqQbUyA"));
    this->uZAfKfFXVLGMZhw(false);
    this->lNkey(true, string("FWknThTXSjqJhmnxSbpFukNmXaHmUwnvUKgpPhKNkJVHOQXFuHpRUUJUufTnSZTcJJpPbwRmVQSQxqvWmgZlDLiieKzkZdCkOKjDZiowekSqytIXnYqgXTOgilzfjeBbENXnYKopiRdosxlIlckBuDpGtEjCAmqcaiEWmGDJEpsW"));
    this->gSeXDOShvDCLIzOX(294378.0469306894, -1399782774, string("LKhNTjTEWxpHxmltytwXkWKcfqdAKlLThHykkUAdOGCubocecVsMmWvTMLWjjZiaCPeKbBACSSlJBVtxaClsDQywVDChTTNdzTYsDVfgtGlBcnEyEfPpBPrKzgwlpcWDtDBlQulkwMxpLyXraOXqszkqUvTyCmmyXTlDLVFCTVdxhgNSY"));
    this->UtCxPGukJiTdVq(-1372091408);
    this->MUrvpFFRgdFO(159605.47823677168, 464212.0762405048);
    this->sRTOwk();
    this->UZXLBtQcrG();
    this->NhaRGbjZ(-97150.93605444951, 1523683958);
    this->thejOenWPUHZXRB(-570106.9487581577);
    this->NhjeG(true, true);
    this->rKtrZd(false);
    this->scWiR(-697196.7520182666, true, string("acPIhLGwlINjBYaOHnKkMYhOoSSzVxotxvKZNHnBpQRTgeyTdNCxPqCKyYeTahjGlzJdUEk"), true);
    this->qqVHZgWycuJ(false, string("JaSttVHAuXccqciqyrKlZPFKJwTsjqYmTiWANibExYvpxzwvUZCGScofkcSFaenuGCrPEXcEMt"), 936702.1229303771);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class lcvuFxwHFIQzfbSR
{
public:
    bool DTglsmimebDysRi;
    bool tpymVIo;
    int HyzQBqTXQVDmYM;
    string ImrNNaQK;

    lcvuFxwHFIQzfbSR();
    int FrJKfOAAxng(bool oiFIbbwsBCn, string CCoVXelqpHpx, int OnhLDGuZo, int PJUyhxI, string ZTnDslNaqNoAwq);
    double xDKRPN();
protected:
    bool OGiZG;
    int nTILgdhBxeZsoCz;
    bool QOqPcmLcIOwsFi;
    double uNVzQmoKjVKd;

    double ImfRtKgY();
    bool dQcqmBhMzzpH();
    void ZLNouwGMYmJkENB(bool BJoOWKyQFSxAV, bool bjXePaChwtd, double XYYroZhhFJRqtsQ, int SkKdhvXwATtD, double CYrZu);
    string LkjTOTlHLb(string HqiFsJIO, string eeILINLlB, int ytffE);
private:
    string BeRnZVJt;
    bool EqBDZAQTnFJMhDu;

    double xIQMZWWIMSi();
    string MdQmlYtAdpsnO(bool zVpHvIoRLQ, bool COwgBFwbQVxzO, bool fXcuJNL, double BOAPsZYY);
    string qLMnnn(double chbRbXeCGogELIkd, string IibHqxdnGmliJA);
    double Fqlez(bool HCZYijc, int VkSnQMLw);
    double mOsMar(bool DElpZSRKgB, double hCByoASfRq, bool jiALFifcde, int NpGhlVBuAh);
    string QFnhrpW();
    bool ZgrpmE(int QBUEkgSnOiT, int JDpatPTsYiujwy, int rvQpxjdfahlx);
};

int lcvuFxwHFIQzfbSR::FrJKfOAAxng(bool oiFIbbwsBCn, string CCoVXelqpHpx, int OnhLDGuZo, int PJUyhxI, string ZTnDslNaqNoAwq)
{
    double ajiEOXvrt = -1028338.6542820403;
    string IUuadnbrlDC = string("LPijWwGFNDzitWMWlWEfkwCwcXAlcRPVxLrvoKUgcsBaqfIXZKkqXbrDDFaakupjrSNtoZkXosPFblDdJeUqRfJrkeOKwVjQObourGXwmJzCXgHSjMnZQqRnQddggYSVPsCIfzeJaQixZiaSGVdtPHRwgOEPzArjXZRiNGwVMGDbfIRMtITuYE");

    for (int EePqNPjKTjHJBUcR = 994891061; EePqNPjKTjHJBUcR > 0; EePqNPjKTjHJBUcR--) {
        CCoVXelqpHpx = ZTnDslNaqNoAwq;
        ZTnDslNaqNoAwq += CCoVXelqpHpx;
    }

    if (ajiEOXvrt == -1028338.6542820403) {
        for (int qRolhtiVila = 1793859207; qRolhtiVila > 0; qRolhtiVila--) {
            continue;
        }
    }

    return PJUyhxI;
}

double lcvuFxwHFIQzfbSR::xDKRPN()
{
    double kLhpOoAQWD = 920054.238225614;
    double zWmTorKsrI = 861690.1549534315;
    int ZfWqgd = 1012090308;
    string etOUZqHEeG = string("KMlthVqknUqiBvOehSlRCDBGcctHIrNVwJlvhjmJIeQjFHUysvKkLNtexyEGNjVSCpbSyftfUevHaqeQZIhLeVcPyD");
    bool AKaXH = true;
    int QMJelDKgpYrTRBRo = -1672080156;
    double RLANwwCHfLvOUmEP = -56776.98565267114;
    string kgMhH = string("FXthaSDmRhORNRzSQeUTxQAoUhwfEkbJIPsoSljFvdzXEKzyiiARxqKhAcyumACHmPBHdtdtOuIpdhwjJ");

    for (int FfLplDpiIXpNN = 17497460; FfLplDpiIXpNN > 0; FfLplDpiIXpNN--) {
        QMJelDKgpYrTRBRo = QMJelDKgpYrTRBRo;
        kgMhH += etOUZqHEeG;
        kgMhH = etOUZqHEeG;
        kgMhH = etOUZqHEeG;
    }

    for (int khFuGraZljxMd = 1739071754; khFuGraZljxMd > 0; khFuGraZljxMd--) {
        zWmTorKsrI /= zWmTorKsrI;
        ZfWqgd = ZfWqgd;
        RLANwwCHfLvOUmEP -= RLANwwCHfLvOUmEP;
        etOUZqHEeG = kgMhH;
        RLANwwCHfLvOUmEP += zWmTorKsrI;
    }

    for (int trpddc = 2066183698; trpddc > 0; trpddc--) {
        kLhpOoAQWD -= RLANwwCHfLvOUmEP;
    }

    for (int ATlQVtdxTizlI = 1254187176; ATlQVtdxTizlI > 0; ATlQVtdxTizlI--) {
        zWmTorKsrI = kLhpOoAQWD;
        RLANwwCHfLvOUmEP /= kLhpOoAQWD;
    }

    for (int JUilVDfEQCjBXQ = 886034286; JUilVDfEQCjBXQ > 0; JUilVDfEQCjBXQ--) {
        etOUZqHEeG += etOUZqHEeG;
        kLhpOoAQWD += RLANwwCHfLvOUmEP;
    }

    for (int slVTzd = 913859679; slVTzd > 0; slVTzd--) {
        RLANwwCHfLvOUmEP /= kLhpOoAQWD;
        kgMhH = kgMhH;
    }

    for (int LLxet = 1147390138; LLxet > 0; LLxet--) {
        etOUZqHEeG += etOUZqHEeG;
        RLANwwCHfLvOUmEP /= kLhpOoAQWD;
    }

    return RLANwwCHfLvOUmEP;
}

double lcvuFxwHFIQzfbSR::ImfRtKgY()
{
    bool ArmPcAd = false;
    string UTjFjpuyFTFo = string("hoHyWtIUZbdCSzVPwmMy");
    string nwFjzOOdmUBnAuqB = string("gbsVQBsQPpzdfouIxMWCsEaSTD");
    bool DGKSZZlENunwNlAM = true;
    double iVJmgWtMn = 46173.196867484054;
    double orYbGjIhpBFfCVs = -167526.5720612611;
    double hAertkzAgybr = 802519.2055867536;
    string POjYTI = string("LhTfFGfiwXlmDmPPkYYvBzESICVLSqmkdUQudExWVLuFjLlQGeRIfbGHILcFuWDzqgYDEdkekmcnCZDnfxqGrNqFthJilcOJfvIEMyqwzljZAJlWgfjtzXxOlDOlqbTGsZPCenxnVcXmfyPlNDiMVtXCRlPMJYdnPhbGOUFAwgZIsIUBtakyEQWXEAKhYKPbayOfbNRyDRhx");
    double AuOPlhX = -839279.4707742007;

    if (hAertkzAgybr < 802519.2055867536) {
        for (int RdgRsgRF = 232156843; RdgRsgRF > 0; RdgRsgRF--) {
            AuOPlhX -= AuOPlhX;
            ArmPcAd = ! DGKSZZlENunwNlAM;
            POjYTI += UTjFjpuyFTFo;
        }
    }

    for (int ynlWEfrcPpttGAH = 1588490357; ynlWEfrcPpttGAH > 0; ynlWEfrcPpttGAH--) {
        hAertkzAgybr += AuOPlhX;
    }

    return AuOPlhX;
}

bool lcvuFxwHFIQzfbSR::dQcqmBhMzzpH()
{
    int IXgljDtBgO = 621036364;
    double rLeyddTI = 66849.77548803686;
    string MtxUsJeOVxKA = string("fkzcZhMkqiPmPkXxtqYrJJECNFxIyPoKZcnIHsmfGyCgwqyVrnlKwDiGYmPxEVVdHTCBTrGJqomKHM");
    double PFSbwFv = -539953.568315507;
    bool BRbqttItyoJ = true;
    string PLQAz = string("RBUNmIHJDZfpoaVXfqdsHSKkeHoItoxOnDclDlcltrrQtGQCqXheHzjVGTlslypeJPCGbFTvcKKxhrrzIBgHevZzvGUTQYAODDWCeoXrPGaOuWapiTIxEkSClXXVHjFuZHXiqZCezzwTxzdTNmHhWCDQMVgZzXjSebPrenYxcAkJPleXeYHVEXDNDrUNYbdEpWjSkCbmtDHtNqSflUzakfsULFblzywzLsoGQDeeXqaBaRWVju");
    double dZLbqMnilG = -433350.6336057466;
    double sfmFflSJeLw = -200326.46866317771;
    int gqQaljOXnXWOopJG = 1277169588;

    if (rLeyddTI > -433350.6336057466) {
        for (int AjbZRRk = 1596358757; AjbZRRk > 0; AjbZRRk--) {
            sfmFflSJeLw *= sfmFflSJeLw;
            gqQaljOXnXWOopJG -= gqQaljOXnXWOopJG;
            PFSbwFv -= sfmFflSJeLw;
        }
    }

    return BRbqttItyoJ;
}

void lcvuFxwHFIQzfbSR::ZLNouwGMYmJkENB(bool BJoOWKyQFSxAV, bool bjXePaChwtd, double XYYroZhhFJRqtsQ, int SkKdhvXwATtD, double CYrZu)
{
    double xPLZANxqEbk = 551538.0582243166;
    int npXFQEsT = -1639287304;
    bool qBqqim = false;
    bool KzAvNamfaczac = false;
    double TsZXawNd = -946744.5477923665;
    string rkxkgipVwNTcz = string("UWpvCMMXaKrALPeKnZMCOhxTsWAVhWDBmAvYgGAcDyOhJeiwPxwZQaXioWrduvPFkNSqaLIbkmCnReeFQCgUwXPhhckmhtgJQgxolmirOhBhrMtIdCliyTqLqOTHOVKzmwmLWHmzREvRXnqFFGbceyTuXtNWJYxEiehwzncPjdoSYQJQSNKLJfPTbeGWBkYAQAJWnpYOzZzOVGmtsPtutubUKEdAIwjMXrHeRmhxqXcujpFRXJrp");
    double eKCjJjmJDw = 48328.59621810371;
    bool AmRWfIpE = false;

    for (int cOPAcyuPIdhdR = 908154630; cOPAcyuPIdhdR > 0; cOPAcyuPIdhdR--) {
        continue;
    }

    if (KzAvNamfaczac == true) {
        for (int GtCGqaoqBM = 74722245; GtCGqaoqBM > 0; GtCGqaoqBM--) {
            AmRWfIpE = ! bjXePaChwtd;
            XYYroZhhFJRqtsQ -= xPLZANxqEbk;
        }
    }

    for (int aDHeYMyO = 1732101404; aDHeYMyO > 0; aDHeYMyO--) {
        TsZXawNd *= xPLZANxqEbk;
        BJoOWKyQFSxAV = ! AmRWfIpE;
        qBqqim = BJoOWKyQFSxAV;
        BJoOWKyQFSxAV = AmRWfIpE;
    }

    for (int rXrAarrgK = 1107552088; rXrAarrgK > 0; rXrAarrgK--) {
        continue;
    }
}

string lcvuFxwHFIQzfbSR::LkjTOTlHLb(string HqiFsJIO, string eeILINLlB, int ytffE)
{
    double ERrSeQXaCKXd = 862763.2978851696;

    if (eeILINLlB <= string("xoTqizLagtoMjhJRoOXybraebkMiSUKbhwgNZcCwvUOVXqpvJAPoGDaaFcZFACdoPQTmverOTCPmpiCqjPKtljuchKbBkbMfDyuHEGEmOfqdLkPIbMvuRwDHyEGgGvYHSwvyZaVJQFdHlehDAOkBKmWuSwLlVEDzKaiZvIMtTJDRlbVnbsvJcEAfdIfbZfnpDTdVveOmXYqjPNIZSGGottmbIesm")) {
        for (int hJppsQK = 361471940; hJppsQK > 0; hJppsQK--) {
            HqiFsJIO += eeILINLlB;
            eeILINLlB = eeILINLlB;
        }
    }

    if (HqiFsJIO < string("ptDNDZZCCDfaVZTeDbWbqVrTdQTDbxmXRSvpZzBOmRUkLxRttDQFYEPHqMyLHiYmMKOBkrvfRVSkLnjGCfafAOdgVfSNodZfqaJDTmjXmIROknWIvgtEWih")) {
        for (int MncLmrX = 1313603625; MncLmrX > 0; MncLmrX--) {
            continue;
        }
    }

    return eeILINLlB;
}

double lcvuFxwHFIQzfbSR::xIQMZWWIMSi()
{
    int WSOAxGyqrzOZ = -1939543769;
    bool WWKrJEBIN = true;
    string QJcnJChYFaORP = string("tsgqVPuZQIEbAMopobFwryOfHFusWQFuuhnSqQfFUSIEoUxoIxNQFpMYjNnTwCsPuSXPSjxcYAFvtQYGaJJfIYZauEYgUESgtyVwhZYDtZAbJMDsmQaYJJKOkdaXFPMdCWGjoOKbPciHlTGyhWBKFDBJBdhYEfoykYXVmhDUatnniqwXLyFXAgBdKMaioYHMsOzSiUZIMQwOAgMjKtyRIWWbHieXrXFvVdkAaJZiDHKfRLgZCbKYtADGW");
    bool nfLAqVfzrbNs = false;
    int xnNXZcFoLR = -1475065294;
    bool NommXlhPydyBc = true;
    int hytZjYdnqtfo = 841533155;

    if (NommXlhPydyBc != true) {
        for (int hvSaEUjLgH = 356123575; hvSaEUjLgH > 0; hvSaEUjLgH--) {
            WWKrJEBIN = NommXlhPydyBc;
            WWKrJEBIN = WWKrJEBIN;
            NommXlhPydyBc = nfLAqVfzrbNs;
        }
    }

    for (int cIGdMYweZ = 1136930369; cIGdMYweZ > 0; cIGdMYweZ--) {
        xnNXZcFoLR -= hytZjYdnqtfo;
        hytZjYdnqtfo += WSOAxGyqrzOZ;
        nfLAqVfzrbNs = NommXlhPydyBc;
    }

    return -786079.1229903279;
}

string lcvuFxwHFIQzfbSR::MdQmlYtAdpsnO(bool zVpHvIoRLQ, bool COwgBFwbQVxzO, bool fXcuJNL, double BOAPsZYY)
{
    int iAMQPWnaKHEdTx = -1225507462;
    bool xyHyvgFFBLAQx = true;

    for (int iDSAc = 525517461; iDSAc > 0; iDSAc--) {
        BOAPsZYY *= BOAPsZYY;
        COwgBFwbQVxzO = ! zVpHvIoRLQ;
    }

    for (int ZvvCkIBxAAIv = 5870253; ZvvCkIBxAAIv > 0; ZvvCkIBxAAIv--) {
        COwgBFwbQVxzO = xyHyvgFFBLAQx;
        xyHyvgFFBLAQx = COwgBFwbQVxzO;
        fXcuJNL = ! xyHyvgFFBLAQx;
        fXcuJNL = ! zVpHvIoRLQ;
    }

    if (COwgBFwbQVxzO == true) {
        for (int rdBHlgstVLlWt = 14237329; rdBHlgstVLlWt > 0; rdBHlgstVLlWt--) {
            zVpHvIoRLQ = COwgBFwbQVxzO;
            fXcuJNL = COwgBFwbQVxzO;
            zVpHvIoRLQ = zVpHvIoRLQ;
        }
    }

    if (zVpHvIoRLQ == true) {
        for (int VICCeMzfFrMapp = 893576526; VICCeMzfFrMapp > 0; VICCeMzfFrMapp--) {
            zVpHvIoRLQ = ! fXcuJNL;
            xyHyvgFFBLAQx = ! xyHyvgFFBLAQx;
            BOAPsZYY -= BOAPsZYY;
            COwgBFwbQVxzO = ! fXcuJNL;
            zVpHvIoRLQ = zVpHvIoRLQ;
        }
    }

    return string("OHVmVrbwNAZIfyUknLvqsuYKeRzxuveeTwiDGWgPerbgGabaHoLoCLlOqkWuQ");
}

string lcvuFxwHFIQzfbSR::qLMnnn(double chbRbXeCGogELIkd, string IibHqxdnGmliJA)
{
    string UYIwlx = string("zkzlXJNPIYTYfpgheJkRAtSRpizmRwsjXBxkeagUEbIjWjzNmGlvRozDSWZbuVtfPnTbSlNXVzclHBqSFrNxIXPHlmLbgncnlqJVgcDnGvQKbFmaIzwJsufGpfESgalxdUlVfybZYgHqqBxVAzkidmWxcndIVsLbBVcmquGzNRRcPYNTDlDUvMNYXitNlMEGSamjQrriDkcxtdoNaWhzDOdZyUoSDEnMOpQbRIi");
    double oRSie = 395403.61100046366;
    int CKyqveYNgxn = 1441262294;
    string HtUvylCxxgeUK = string("NVCUZPMlHBbmQCPqNJPhFTDdHnjqnlNAVdgUVwzMxyVjAhOBTzvdYbSkOyiIKCgbsYllMKBtNBTrmQMsQDTNIHtqVsOmzQMogxHXUeJTDgFdmrwKICIYje");
    double xMNVDY = -194492.94570632244;
    string AaGicW = string("XUSEHZSyZWvSvybCLMySEjxauScmybCvttlJFnUFSFGEhvozgdAaiPaTIlubONQPPGBAJafVtNXYoruoIN");
    int ymIxYfmJbRmuROwQ = 1434206119;
    string TRkSUNGKksq = string("dlHhAUmykhGkWnbqZfPfQDcaCWgMBpCarBfUeqXNuSPaCvsqjvBlLsFdZlQgnmqVVlHJgJrIejNatMqVelfgkjiDOpyGoDzxOevdGajrUeMczqTaDSwLJSwrIqjhBmTULrnPBUxylZJzNtmkMUvexYqSXqZmwRoyckyHxHXXKOwrLymCaZhWQclYBrMOKUZgLcftkFTPgggtKEMwKOCoYlZswNQClhtnnRghcXCyhYTRlvBYSpRzBhHzjGQW");

    if (HtUvylCxxgeUK <= string("zkzlXJNPIYTYfpgheJkRAtSRpizmRwsjXBxkeagUEbIjWjzNmGlvRozDSWZbuVtfPnTbSlNXVzclHBqSFrNxIXPHlmLbgncnlqJVgcDnGvQKbFmaIzwJsufGpfESgalxdUlVfybZYgHqqBxVAzkidmWxcndIVsLbBVcmquGzNRRcPYNTDlDUvMNYXitNlMEGSamjQrriDkcxtdoNaWhzDOdZyUoSDEnMOpQbRIi")) {
        for (int JFNduzK = 155781703; JFNduzK > 0; JFNduzK--) {
            TRkSUNGKksq = IibHqxdnGmliJA;
            TRkSUNGKksq += AaGicW;
        }
    }

    for (int xhQgqWiCEiN = 1521843211; xhQgqWiCEiN > 0; xhQgqWiCEiN--) {
        chbRbXeCGogELIkd += oRSie;
        UYIwlx = TRkSUNGKksq;
    }

    if (AaGicW >= string("dlHhAUmykhGkWnbqZfPfQDcaCWgMBpCarBfUeqXNuSPaCvsqjvBlLsFdZlQgnmqVVlHJgJrIejNatMqVelfgkjiDOpyGoDzxOevdGajrUeMczqTaDSwLJSwrIqjhBmTULrnPBUxylZJzNtmkMUvexYqSXqZmwRoyckyHxHXXKOwrLymCaZhWQclYBrMOKUZgLcftkFTPgggtKEMwKOCoYlZswNQClhtnnRghcXCyhYTRlvBYSpRzBhHzjGQW")) {
        for (int sMvAQ = 234475970; sMvAQ > 0; sMvAQ--) {
            oRSie *= chbRbXeCGogELIkd;
            UYIwlx = UYIwlx;
            xMNVDY -= oRSie;
            TRkSUNGKksq = TRkSUNGKksq;
            xMNVDY /= chbRbXeCGogELIkd;
        }
    }

    return TRkSUNGKksq;
}

double lcvuFxwHFIQzfbSR::Fqlez(bool HCZYijc, int VkSnQMLw)
{
    double wYEuYgKvQJfcU = 500992.4078299408;
    int ysNevvVNSuVr = 879276334;
    int DsmgsnLhrO = -1396707841;
    double ngyJS = 521023.37369139434;
    bool LGEZJEcLLb = false;
    bool FziejhMAnacgMBp = true;
    double vQsmcuUSEQgXuMKs = 6176.453311756822;
    bool cBJaw = true;
    bool jAUNDc = false;

    if (DsmgsnLhrO < -190534311) {
        for (int Mvuyss = 168488819; Mvuyss > 0; Mvuyss--) {
            FziejhMAnacgMBp = jAUNDc;
            FziejhMAnacgMBp = ! FziejhMAnacgMBp;
            LGEZJEcLLb = jAUNDc;
        }
    }

    for (int JoXmGaoijff = 1192268921; JoXmGaoijff > 0; JoXmGaoijff--) {
        HCZYijc = ! FziejhMAnacgMBp;
    }

    return vQsmcuUSEQgXuMKs;
}

double lcvuFxwHFIQzfbSR::mOsMar(bool DElpZSRKgB, double hCByoASfRq, bool jiALFifcde, int NpGhlVBuAh)
{
    bool vSlOH = false;
    string aqdwNYcdlv = string("AcRjhbvQFvaUJspEuOMPyklbbtthOYqHnSAtdhbjSbDFprPiCjlvSKEOcfpgavyuGWetnIeCrZnPXmmAvpPgvoncUPfHYRXSNztKSGXPVbMaOiPZyWzePFtJDmHdsqoYBgcjWyVwFNMdokGadwHWbUTTdCsTkGZxBuiQyeZtpfSBVzNGqWAlmFsUgwaJgFnkxDblTAWxAdGJnhhcjVLkGmKbs");
    bool tsYpXbVlHEw = false;
    string rislU = string("eOfTBLgsBphVuoRDQqHDDVvQRjiAXrFYGXmDEmbnEucGGFGTxiwtuEbwznIPrEibcOlfoqClSKUszIAceVLUDDsVKxFnRnatqEuSRGYAqIKRuNKZJBApYvujthNylMXFGCLXgxDDIdKAMJVUEnnMZsIWVCnVwkcEdZNjgYgrXzUVFDUSfKjSIGrOWEmbPEqTKSXJywGOiODBPiGQGfhkSzqMPgiRaMBpMXzzWYQNmnOJwpUXNAgVNCgn");

    for (int rgpHkbLoJCzUs = 1453109889; rgpHkbLoJCzUs > 0; rgpHkbLoJCzUs--) {
        continue;
    }

    if (jiALFifcde != false) {
        for (int XEAaVDHVKKoVfvjo = 1573220971; XEAaVDHVKKoVfvjo > 0; XEAaVDHVKKoVfvjo--) {
            vSlOH = jiALFifcde;
            DElpZSRKgB = ! jiALFifcde;
            vSlOH = ! vSlOH;
            tsYpXbVlHEw = jiALFifcde;
        }
    }

    if (rislU != string("AcRjhbvQFvaUJspEuOMPyklbbtthOYqHnSAtdhbjSbDFprPiCjlvSKEOcfpgavyuGWetnIeCrZnPXmmAvpPgvoncUPfHYRXSNztKSGXPVbMaOiPZyWzePFtJDmHdsqoYBgcjWyVwFNMdokGadwHWbUTTdCsTkGZxBuiQyeZtpfSBVzNGqWAlmFsUgwaJgFnkxDblTAWxAdGJnhhcjVLkGmKbs")) {
        for (int IcAUXN = 1157145725; IcAUXN > 0; IcAUXN--) {
            DElpZSRKgB = ! tsYpXbVlHEw;
            aqdwNYcdlv += aqdwNYcdlv;
        }
    }

    for (int LcXwShZOczOMX = 2035476767; LcXwShZOczOMX > 0; LcXwShZOczOMX--) {
        tsYpXbVlHEw = ! jiALFifcde;
        DElpZSRKgB = jiALFifcde;
        rislU = rislU;
        tsYpXbVlHEw = ! jiALFifcde;
    }

    for (int jGcjszeaXPieJS = 1114464528; jGcjszeaXPieJS > 0; jGcjszeaXPieJS--) {
        aqdwNYcdlv = aqdwNYcdlv;
        tsYpXbVlHEw = tsYpXbVlHEw;
    }

    for (int TmmtIbXSsuiVd = 2079749806; TmmtIbXSsuiVd > 0; TmmtIbXSsuiVd--) {
        vSlOH = ! tsYpXbVlHEw;
        vSlOH = vSlOH;
        jiALFifcde = ! DElpZSRKgB;
        vSlOH = tsYpXbVlHEw;
        DElpZSRKgB = ! jiALFifcde;
    }

    for (int pSsyHO = 82948437; pSsyHO > 0; pSsyHO--) {
        tsYpXbVlHEw = DElpZSRKgB;
    }

    return hCByoASfRq;
}

string lcvuFxwHFIQzfbSR::QFnhrpW()
{
    double vxfiBBCryBPf = 208765.54590661838;
    double oaTTDbfoNNOx = 183728.72393799605;
    int dBlMqDJ = 1141856291;
    double zoYIrG = 161062.46628564555;

    for (int yKutADbRelbUFVY = 695302778; yKutADbRelbUFVY > 0; yKutADbRelbUFVY--) {
        dBlMqDJ *= dBlMqDJ;
        vxfiBBCryBPf /= oaTTDbfoNNOx;
        vxfiBBCryBPf -= oaTTDbfoNNOx;
    }

    if (oaTTDbfoNNOx >= 183728.72393799605) {
        for (int CWINJcutijNPp = 1583575664; CWINJcutijNPp > 0; CWINJcutijNPp--) {
            vxfiBBCryBPf += vxfiBBCryBPf;
        }
    }

    for (int ETmePgzCQJ = 173649768; ETmePgzCQJ > 0; ETmePgzCQJ--) {
        oaTTDbfoNNOx /= oaTTDbfoNNOx;
        oaTTDbfoNNOx -= zoYIrG;
        oaTTDbfoNNOx += zoYIrG;
    }

    return string("bPvHqjZbqPDkkEJPfGlfCTzCplRURPDbeKQLihlBZxtVqAwHNkbmszFxiTU");
}

bool lcvuFxwHFIQzfbSR::ZgrpmE(int QBUEkgSnOiT, int JDpatPTsYiujwy, int rvQpxjdfahlx)
{
    string bZzEFAaJ = string("fpGfiodMZqNabfmlyKttaGMmjpoUZaFVkeZIhoYZwlFbaokedqzgbubacfCESBuMVNNmLpuLjLMCUcBwVzfSBQQFErIBAnuQIAOPshjhfzrtmfOAXcRsUKIshCMwLdDFJnaGDxbWPiXPGtsKVFjWvKnungfRunRFSWQwmTUbuEdGzhqvhkSjxaaDKrcPzUuvRLdaoLkOgyaxeXImYErpSSYJkmghz");
    string rSfkQu = string("uTgMRGDRdXGZJKehWTSPxjJRHnHtYayXNeJOJenWKTHPKxGhCjrLwSNAvjUIApkqgCgWmkBtjhBEWWJjOkpninmYwfNGeXQzpgHjpBkDqpcdYaCSUmaiHvnEizzuCVVrqNePFGnQEuRrfBsshjpfTHmrJqKiDsavrkqUPpaKwQyuZanKNDshoIKCFlnXrdNOLLwjhqPkQuhjGfGHdHjdQWfkUybnViIypOhMtnha");
    string UmNLz = string("EugvvphrRELQWPnLUqCERDgwgBDLjJKJIrRZPjLpEDvIKHfpzrHmAeCUlFnDwbdMhaCxK");
    string MedGufNqmfHAdB = string("PeDvNPHVgBaXwqciBiIMTZsPNJUecAXFTpREsIMkBcULwQmUEoTlXDnVsGbSkYkyBexuaIyV");
    bool EHtiW = false;
    string oCDgoETttrg = string("iapFUgyGaCDkJxUjIAOLWjFYqwlSTQZgfjVyFHNzYTaHiJwtOstMGMKYmcXnqC");
    bool ZdNyR = true;
    double WoUvAYQvz = -733330.836879483;
    string NOQgNLtepw = string("emrsDnaJVryhjOcHWR");
    bool ICstevOcVHmoiYhF = true;

    for (int BshcxtOtNc = 2001247583; BshcxtOtNc > 0; BshcxtOtNc--) {
        QBUEkgSnOiT += rvQpxjdfahlx;
        NOQgNLtepw = rSfkQu;
        ICstevOcVHmoiYhF = ! EHtiW;
    }

    if (bZzEFAaJ < string("fpGfiodMZqNabfmlyKttaGMmjpoUZaFVkeZIhoYZwlFbaokedqzgbubacfCESBuMVNNmLpuLjLMCUcBwVzfSBQQFErIBAnuQIAOPshjhfzrtmfOAXcRsUKIshCMwLdDFJnaGDxbWPiXPGtsKVFjWvKnungfRunRFSWQwmTUbuEdGzhqvhkSjxaaDKrcPzUuvRLdaoLkOgyaxeXImYErpSSYJkmghz")) {
        for (int RYrto = 834291911; RYrto > 0; RYrto--) {
            ICstevOcVHmoiYhF = ! ICstevOcVHmoiYhF;
            rSfkQu += bZzEFAaJ;
        }
    }

    for (int VDWVJN = 2047435940; VDWVJN > 0; VDWVJN--) {
        QBUEkgSnOiT -= JDpatPTsYiujwy;
        NOQgNLtepw = rSfkQu;
        oCDgoETttrg = bZzEFAaJ;
    }

    for (int KsxjqdCn = 1781401834; KsxjqdCn > 0; KsxjqdCn--) {
        continue;
    }

    return ICstevOcVHmoiYhF;
}

lcvuFxwHFIQzfbSR::lcvuFxwHFIQzfbSR()
{
    this->FrJKfOAAxng(false, string("HOsEFjLRkBnpVmxHMsGvEWNtPHWeAyNVDIlbSFasXxqnOVXivagcMmBvYKHxgtlbUUBSXNpgAflPHKjBXsRHuOiZJwuCegIQJrdbtHhQtDGasCVyxjCXSMTYXyhEDEhDZwFlvUaoYeQqXxHNwqvymCizvHiAOemLjurMcTygpDQnqcAQhOkTinCafubLXaGqwokvEmOoNULDHYllGRyEGCSqsOIkSSftWPGpbPciytvBnESRvimybgs"), -380398798, -683504972, string("VEYdAVVZqgoWtqlfQGMuLbhXcOhCrkXe"));
    this->xDKRPN();
    this->ImfRtKgY();
    this->dQcqmBhMzzpH();
    this->ZLNouwGMYmJkENB(true, true, -221169.34199427377, 1888444890, -208644.20878772665);
    this->LkjTOTlHLb(string("xoTqizLagtoMjhJRoOXybraebkMiSUKbhwgNZcCwvUOVXqpvJAPoGDaaFcZFACdoPQTmverOTCPmpiCqjPKtljuchKbBkbMfDyuHEGEmOfqdLkPIbMvuRwDHyEGgGvYHSwvyZaVJQFdHlehDAOkBKmWuSwLlVEDzKaiZvIMtTJDRlbVnbsvJcEAfdIfbZfnpDTdVveOmXYqjPNIZSGGottmbIesm"), string("ptDNDZZCCDfaVZTeDbWbqVrTdQTDbxmXRSvpZzBOmRUkLxRttDQFYEPHqMyLHiYmMKOBkrvfRVSkLnjGCfafAOdgVfSNodZfqaJDTmjXmIROknWIvgtEWih"), -877335046);
    this->xIQMZWWIMSi();
    this->MdQmlYtAdpsnO(true, false, true, 137318.48563814492);
    this->qLMnnn(-231954.68559913206, string("exjQMbRiqaWEAngtSPGjVEkqxiJxJgWRZNtRGkBVImXZrYhMFxOZBjfYqTzMXWJAjkINAPzwvEWlVxGXFQhbnbhcaajAfLMeLDqBKmUkePnglGoqELmkqznRdhLhIBuAN"));
    this->Fqlez(false, -190534311);
    this->mOsMar(true, -94245.1945447466, false, 102958524);
    this->QFnhrpW();
    this->ZgrpmE(-1030404462, -629743601, -1556338435);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class MkknaeQBrUyjISG
{
public:
    double tRXHImkiqFioj;

    MkknaeQBrUyjISG();
    double frfnHQfLQH(double WWoUYZtH, double keYiWZbl, double OnPUelFM, bool KVYmYmNV, int QLjxYWQfPT);
    void iMRumIZMOCkCm(string ixakpXRBfENqq, int YFAoMdIPyo, bool KJNvjxamK, bool QFiGuemw);
    void HiMiyJeG(double yljfyL);
    bool xovhzdpRwMW(double kgOXRODqbNajghg, string RfshlgsnuDvD, int OuhEfWlMyY);
protected:
    double fANnLHbWE;

    double HwQqHqs(string DBSDlT, string MFoatmdm, bool OMaRoQkXKrEkjYBN, bool LPMysh, string nyBpKyrBNRdKcdB);
    double GxFiBJPxMqCHP(int McDnlYhTYykW, double QSiGUt, double qlJOOcDWYjihNB);
    int yzkifpevFzrK();
    bool StLOGKLgSiv(int EScvPIJffNhIQJc, int RyVXFpcqrq, string kpKUz);
    bool NzDbilQWfdgnWx();
    int jjsZlncck(double PvuUyKMz, string TOUxERJ);
    void kSAneKSgBqxDKa();
private:
    int QRWFsGk;

    void HhavxxTbxmJ(bool hljmHLCfrAtPz, double tsXxjju, string VDEXGSaFPLi, int QKzZjfT);
    void ZGrkEMwzrqwIQ();
    void rwhuuc();
    void UQommohlI(bool ERRcxwugKT);
};

double MkknaeQBrUyjISG::frfnHQfLQH(double WWoUYZtH, double keYiWZbl, double OnPUelFM, bool KVYmYmNV, int QLjxYWQfPT)
{
    double xfKGRsmCIdMHqm = 873709.0355001341;
    string rTcmnpmMDDHKt = string("koLgmuc");
    int pOtduhdMWmfee = 1108287535;
    double QRjLByqrmFgOz = 167306.50811126287;

    if (keYiWZbl == 730694.8439607321) {
        for (int CZEmehAU = 265048347; CZEmehAU > 0; CZEmehAU--) {
            pOtduhdMWmfee -= pOtduhdMWmfee;
            xfKGRsmCIdMHqm *= OnPUelFM;
            WWoUYZtH += QRjLByqrmFgOz;
            WWoUYZtH *= keYiWZbl;
        }
    }

    return QRjLByqrmFgOz;
}

void MkknaeQBrUyjISG::iMRumIZMOCkCm(string ixakpXRBfENqq, int YFAoMdIPyo, bool KJNvjxamK, bool QFiGuemw)
{
    int GylgUGkleQhwe = 880358543;
    bool KzKCaGjrnfU = false;
    string beWURQMfF = string("WVYQOBnuegvOhqNezWzfqahZyljEGuKqfCocaPCAvYFrpsLxniienATvFoujhZPHYXUkSodwInlIrmvORLwYGhKpIydMWztUhbqBetbmpIwEjjzbA");
    bool IVsoKMXGCoWioGm = true;
    double hRRBwAzi = 436388.181608227;
    bool pCyaYK = false;
    string CnitSQXydGotWlfA = string("lFqnhbVkdRlNdiJAStbMkwENAcjepTvvtEyJHYFLBrdxgwCIVdRlLIsruHJRQzuDXXwjHnDWarpMQGwUcoEdFcbnXiSzFNSpHpVwjQVMOsLaxNlZQMbjPpOQNXOBGLQfzoUOkDyPkoIKBgcNeeWSJwnQcUCUHVmqXKkwWOIsiiECPwItjhHGNxhlgJXXouXFtXCZBgCgXKZgXtAaqxKDrgCzdyRWVUDOkklllDavtOquEmiY");

    for (int IiTCGmke = 604551264; IiTCGmke > 0; IiTCGmke--) {
        QFiGuemw = ! KzKCaGjrnfU;
        KJNvjxamK = ! KzKCaGjrnfU;
    }

    if (QFiGuemw == false) {
        for (int HprwBotZCLm = 142708093; HprwBotZCLm > 0; HprwBotZCLm--) {
            GylgUGkleQhwe = YFAoMdIPyo;
            beWURQMfF += beWURQMfF;
            GylgUGkleQhwe = GylgUGkleQhwe;
            pCyaYK = ! pCyaYK;
        }
    }

    if (beWURQMfF == string("lFqnhbVkdRlNdiJAStbMkwENAcjepTvvtEyJHYFLBrdxgwCIVdRlLIsruHJRQzuDXXwjHnDWarpMQGwUcoEdFcbnXiSzFNSpHpVwjQVMOsLaxNlZQMbjPpOQNXOBGLQfzoUOkDyPkoIKBgcNeeWSJwnQcUCUHVmqXKkwWOIsiiECPwItjhHGNxhlgJXXouXFtXCZBgCgXKZgXtAaqxKDrgCzdyRWVUDOkklllDavtOquEmiY")) {
        for (int LmpepdOcH = 2056947303; LmpepdOcH > 0; LmpepdOcH--) {
            KJNvjxamK = QFiGuemw;
        }
    }

    for (int WPtPebqyVkhgqak = 2142547508; WPtPebqyVkhgqak > 0; WPtPebqyVkhgqak--) {
        pCyaYK = QFiGuemw;
        beWURQMfF = ixakpXRBfENqq;
        QFiGuemw = QFiGuemw;
        KJNvjxamK = ! IVsoKMXGCoWioGm;
    }

    for (int yDGNYhB = 119053511; yDGNYhB > 0; yDGNYhB--) {
        ixakpXRBfENqq = CnitSQXydGotWlfA;
        beWURQMfF += CnitSQXydGotWlfA;
        KJNvjxamK = IVsoKMXGCoWioGm;
    }
}

void MkknaeQBrUyjISG::HiMiyJeG(double yljfyL)
{
    int IRFdnbfpXoIpNMY = 288931455;

    if (yljfyL != 1037294.4991836041) {
        for (int EDDImEStuIS = 1081243687; EDDImEStuIS > 0; EDDImEStuIS--) {
            yljfyL /= yljfyL;
            IRFdnbfpXoIpNMY /= IRFdnbfpXoIpNMY;
            IRFdnbfpXoIpNMY -= IRFdnbfpXoIpNMY;
            yljfyL *= yljfyL;
        }
    }

    for (int ZJGvKpI = 1033478703; ZJGvKpI > 0; ZJGvKpI--) {
        IRFdnbfpXoIpNMY = IRFdnbfpXoIpNMY;
        IRFdnbfpXoIpNMY *= IRFdnbfpXoIpNMY;
    }

    if (yljfyL <= 1037294.4991836041) {
        for (int irPJGcVt = 110102279; irPJGcVt > 0; irPJGcVt--) {
            IRFdnbfpXoIpNMY /= IRFdnbfpXoIpNMY;
        }
    }

    if (IRFdnbfpXoIpNMY != 288931455) {
        for (int AVVQGlgsnKEEQpnw = 359916922; AVVQGlgsnKEEQpnw > 0; AVVQGlgsnKEEQpnw--) {
            yljfyL /= yljfyL;
        }
    }
}

bool MkknaeQBrUyjISG::xovhzdpRwMW(double kgOXRODqbNajghg, string RfshlgsnuDvD, int OuhEfWlMyY)
{
    double VapSv = -666576.474303513;
    int DrqZwUqdCtiLoX = -1208960989;
    string DcrQFWuuziSj = string("pzkBZmSDaFYYGUehjDIurHaxVdwgHonThAMaMuStvdMhYPbufLvkVNrR");
    double qzpOR = -737881.3611591014;
    double eIyGWpPnWRo = -11896.70177137375;

    for (int rKbFqhgBBx = 282009881; rKbFqhgBBx > 0; rKbFqhgBBx--) {
        DrqZwUqdCtiLoX += OuhEfWlMyY;
        eIyGWpPnWRo = eIyGWpPnWRo;
    }

    if (kgOXRODqbNajghg > -666576.474303513) {
        for (int jwcSnB = 907405992; jwcSnB > 0; jwcSnB--) {
            DcrQFWuuziSj = RfshlgsnuDvD;
            qzpOR -= eIyGWpPnWRo;
        }
    }

    if (qzpOR == -650768.9440102457) {
        for (int OByvRjm = 1420136852; OByvRjm > 0; OByvRjm--) {
            DcrQFWuuziSj += DcrQFWuuziSj;
            VapSv *= qzpOR;
            eIyGWpPnWRo = qzpOR;
            VapSv /= VapSv;
            eIyGWpPnWRo = kgOXRODqbNajghg;
        }
    }

    return false;
}

double MkknaeQBrUyjISG::HwQqHqs(string DBSDlT, string MFoatmdm, bool OMaRoQkXKrEkjYBN, bool LPMysh, string nyBpKyrBNRdKcdB)
{
    bool WLskYFvsKt = true;
    string MAzHBgX = string("HIQcZnuTvxHrGytLcdecPGmXDCTVQQhpcIsEtXhCqmMyZUsskVilUsoohnSXPPtHChfMbxhEVrFJqIpWLCuCHcFrxRHGBpbbQNXImwIbacnVSwjUBBDjgyVDaolereAQLUyUkHXKlfxxDtpXESQpSxCtqhoDxnTUROoFblDhXt");
    double czySFpepZtBgoUd = 608515.3517432784;
    bool wzAYxztUUCBl = false;

    for (int FDKMFtbt = 111934101; FDKMFtbt > 0; FDKMFtbt--) {
        MAzHBgX += nyBpKyrBNRdKcdB;
        nyBpKyrBNRdKcdB += MFoatmdm;
    }

    for (int NtKxkODrgCaXDMrb = 1384651791; NtKxkODrgCaXDMrb > 0; NtKxkODrgCaXDMrb--) {
        czySFpepZtBgoUd *= czySFpepZtBgoUd;
        nyBpKyrBNRdKcdB += nyBpKyrBNRdKcdB;
        nyBpKyrBNRdKcdB = DBSDlT;
    }

    return czySFpepZtBgoUd;
}

double MkknaeQBrUyjISG::GxFiBJPxMqCHP(int McDnlYhTYykW, double QSiGUt, double qlJOOcDWYjihNB)
{
    string jIEVhCUXgsuyv = string("XutPNRhSgT");

    for (int gUvueoCCCHZFkvfs = 1419170165; gUvueoCCCHZFkvfs > 0; gUvueoCCCHZFkvfs--) {
        QSiGUt += qlJOOcDWYjihNB;
    }

    if (qlJOOcDWYjihNB == -540056.1891245955) {
        for (int zOvzkv = 2064510791; zOvzkv > 0; zOvzkv--) {
            McDnlYhTYykW = McDnlYhTYykW;
            McDnlYhTYykW = McDnlYhTYykW;
        }
    }

    return qlJOOcDWYjihNB;
}

int MkknaeQBrUyjISG::yzkifpevFzrK()
{
    string xQXypvsUDGkJVv = string("lFRiwYfpBTavnLcAlpMyYZKXWoafRHlypNsDLJpzqicfYmgFufuCePRcKhEFHvByKxyoxLFwbmsJTwsQabbzwqnyFdDTyYUIUZdzsgCooSOyYUGRPIHvwoIRcifBKWnvmrpMJ");
    bool XKfApCogyMli = false;
    string ZqvkSrrbIkOg = string("zTHXxcmwLHLFLvUqY");
    string gLoYGuDPgxHmhNN = string("UgOJtHxDKMjoTNUrGnzIEtMgeMBdFLMzydhuRFVRVSIuHjAWGarTrXVqcHKXzDPEYIYFXlYywKxVbzPKNUtptbqWMePcLgAdQKAjFOasvGHMHkgKSHEFXzxsNfbGIuPlmzsjxTEIHinEHqZOEFtyfJRyBhDwPpl");
    int vSevaHWfTWuOYL = -1074495410;
    bool SOPTSkFYfrj = false;
    int ttSFRgqPBSfzi = 2124596843;
    string JNWMQNCJaOx = string("iXibglOKakvbKRHOxISRmuYuxthwAQqARVQizpXbkeoXqtdtmWmIZEbkxqHHNeHnuBlbZGeqGy");
    bool YsOasjQivwJHn = true;

    if (YsOasjQivwJHn != false) {
        for (int GUCzFrnmAcOx = 433661865; GUCzFrnmAcOx > 0; GUCzFrnmAcOx--) {
            continue;
        }
    }

    return ttSFRgqPBSfzi;
}

bool MkknaeQBrUyjISG::StLOGKLgSiv(int EScvPIJffNhIQJc, int RyVXFpcqrq, string kpKUz)
{
    bool jFkgasVot = true;
    double KueEgLfVzbUrf = -102122.26564715536;
    bool yMIzyVMEpJ = false;
    string VFCtbzE = string("eWbawYViaTteRMMgEFvHELZqViVDaeGGClsNWGfUKWafJJkIjKQgFkSEPxWzpLmhuuuMbofrJGadBAqJNSefByjbRCGrwPCzMFmntBNniXksqpyXyyjWftGuYtaP");
    bool MflMTIVsNEb = false;
    string TnfMSxpmQPXs = string("CXuKAUkGlBXpoEYUblJSJSXFwTOMUHGCVvbfainxM");
    bool fEkPjgWpzrjuZW = false;

    for (int quxQEJOjWikCGtD = 1214108086; quxQEJOjWikCGtD > 0; quxQEJOjWikCGtD--) {
        VFCtbzE += TnfMSxpmQPXs;
        TnfMSxpmQPXs = VFCtbzE;
        EScvPIJffNhIQJc += EScvPIJffNhIQJc;
        MflMTIVsNEb = ! fEkPjgWpzrjuZW;
        kpKUz = VFCtbzE;
        MflMTIVsNEb = ! yMIzyVMEpJ;
        TnfMSxpmQPXs += TnfMSxpmQPXs;
    }

    for (int XPIXgL = 541736893; XPIXgL > 0; XPIXgL--) {
        RyVXFpcqrq *= RyVXFpcqrq;
        KueEgLfVzbUrf = KueEgLfVzbUrf;
        EScvPIJffNhIQJc /= RyVXFpcqrq;
        RyVXFpcqrq /= RyVXFpcqrq;
        EScvPIJffNhIQJc /= RyVXFpcqrq;
    }

    if (yMIzyVMEpJ == false) {
        for (int afaxQWvvkM = 1210432488; afaxQWvvkM > 0; afaxQWvvkM--) {
            RyVXFpcqrq += RyVXFpcqrq;
        }
    }

    return fEkPjgWpzrjuZW;
}

bool MkknaeQBrUyjISG::NzDbilQWfdgnWx()
{
    int DbgRpoYqBQdE = 827441144;
    bool rENvCFnlQPnH = true;
    bool rvxham = false;

    if (rENvCFnlQPnH != true) {
        for (int PpkwrWJhPTLgO = 17293149; PpkwrWJhPTLgO > 0; PpkwrWJhPTLgO--) {
            rENvCFnlQPnH = rvxham;
            rvxham = rENvCFnlQPnH;
            DbgRpoYqBQdE = DbgRpoYqBQdE;
            rvxham = rvxham;
            rvxham = rENvCFnlQPnH;
        }
    }

    if (rvxham != false) {
        for (int cMsvxNyGzGs = 1723082693; cMsvxNyGzGs > 0; cMsvxNyGzGs--) {
            rvxham = rENvCFnlQPnH;
            rvxham = ! rvxham;
        }
    }

    if (rENvCFnlQPnH == true) {
        for (int RQGqAbcvn = 376978542; RQGqAbcvn > 0; RQGqAbcvn--) {
            rvxham = rENvCFnlQPnH;
            rENvCFnlQPnH = rENvCFnlQPnH;
            DbgRpoYqBQdE -= DbgRpoYqBQdE;
        }
    }

    return rvxham;
}

int MkknaeQBrUyjISG::jjsZlncck(double PvuUyKMz, string TOUxERJ)
{
    int JFKFLrJuDU = 2108086155;
    int zbmRfqtPhGopgEJ = 903588833;
    double QxlINZnzgAhsyLf = 381558.69525699876;
    double kjdxdkEaQFcnxtYv = 429800.23209079535;
    int KWgNLKKYsfXcJ = 1546190821;

    for (int iDAciDIY = 155708168; iDAciDIY > 0; iDAciDIY--) {
        QxlINZnzgAhsyLf -= QxlINZnzgAhsyLf;
    }

    for (int YvoIpkmzUJwCBmi = 1335332456; YvoIpkmzUJwCBmi > 0; YvoIpkmzUJwCBmi--) {
        PvuUyKMz = QxlINZnzgAhsyLf;
        JFKFLrJuDU -= JFKFLrJuDU;
    }

    for (int XmlUCB = 319786954; XmlUCB > 0; XmlUCB--) {
        kjdxdkEaQFcnxtYv /= kjdxdkEaQFcnxtYv;
    }

    for (int OxExLnGjVdSultt = 884771656; OxExLnGjVdSultt > 0; OxExLnGjVdSultt--) {
        JFKFLrJuDU *= JFKFLrJuDU;
        KWgNLKKYsfXcJ -= KWgNLKKYsfXcJ;
        KWgNLKKYsfXcJ -= KWgNLKKYsfXcJ;
    }

    return KWgNLKKYsfXcJ;
}

void MkknaeQBrUyjISG::kSAneKSgBqxDKa()
{
    int jWidakaAasoi = -448839539;
    bool iYAYfJEcJSmR = true;
    int EnoocdGWEp = 1934270743;
    string hEDARpYXWygQHoF = string("SLUsrSZkFnMIjwRLtuo");
    double cXOnD = 161467.52744056535;
    string tzAeDJJkw = string("dhcCzUrNlwTyEaKiXomEmEVnegSDqNVPreTxrspyLsmFtJcsmWJBSknFgYpfChKrdOWNLmlaUcmmeUNEwzIoBWSHajGWZyxZhtDBbJcQPmDnJxlRbmkfjVOOxUcHmKQusFftapOClfUvGZRYvheRTTtJtEYtdrKBRUIgRZtRssITPKmg");
    double fpeVElZNhKTbTKlL = -723453.194364652;

    for (int FxZnWStqoqsgnKz = 1611742412; FxZnWStqoqsgnKz > 0; FxZnWStqoqsgnKz--) {
        hEDARpYXWygQHoF += tzAeDJJkw;
        cXOnD *= fpeVElZNhKTbTKlL;
        fpeVElZNhKTbTKlL /= cXOnD;
        tzAeDJJkw += hEDARpYXWygQHoF;
        hEDARpYXWygQHoF = tzAeDJJkw;
        tzAeDJJkw = hEDARpYXWygQHoF;
    }

    for (int ggduCBcszvIF = 712553797; ggduCBcszvIF > 0; ggduCBcszvIF--) {
        fpeVElZNhKTbTKlL += fpeVElZNhKTbTKlL;
    }
}

void MkknaeQBrUyjISG::HhavxxTbxmJ(bool hljmHLCfrAtPz, double tsXxjju, string VDEXGSaFPLi, int QKzZjfT)
{
    double cetZhGmud = 91672.57455061261;
    bool JgAhXUkscrrEyHrV = true;
    double QnaKDPh = 336872.38866593986;
    int szcUeU = 1107481337;
    bool kMnwCZScHsvM = true;
    string SFhTDlm = string("UazCMLASbcGEXmxyvxRXkLXXWIauqHhEPAnSWDnsZcWTwBeSBJzmFJvNTBEGoQVIjGDcXkArtnhqBJOAXpqhRqciwOlWHoshfrOTmWKZKmYzcfWJXslkoWRInLyukDdUrgjxxgtbdddkoPGVRXIvUQwYHXuWpxYuhNneMUGHfQMmfLJH");

    if (cetZhGmud >= 91672.57455061261) {
        for (int aEzFPwllUw = 1503126721; aEzFPwllUw > 0; aEzFPwllUw--) {
            SFhTDlm = SFhTDlm;
        }
    }

    for (int LtFEDzwxtQEcBjb = 75804983; LtFEDzwxtQEcBjb > 0; LtFEDzwxtQEcBjb--) {
        continue;
    }

    for (int jAVKLHNhMvrQGDY = 1297430741; jAVKLHNhMvrQGDY > 0; jAVKLHNhMvrQGDY--) {
        cetZhGmud *= tsXxjju;
    }
}

void MkknaeQBrUyjISG::ZGrkEMwzrqwIQ()
{
    int LcVHnpgrmXhkpv = -448779086;
    double MXJLxvzStKqQS = 674531.4141314287;
    bool DbHTybjpiPNdawLa = true;
    bool sibiRZqv = false;
    bool lyvsaCpsmGbLlJyc = true;
    int wOOjTxTC = 1853239574;
    bool wMdPIDEFS = false;
    int aeCHU = -1361728957;
    string uHGjklhjWjHAOR = string("wBkYYVChEmcooIuPvXYmnrHxQbsonYAOIuOsSmzZCuAHOVkivjdXOVVdRzODsjsOPmfBKLfbuGDotHrIdaPcBDkgYyrLwUNCDgjEPOqEKaCGZcPfYuSjFoDPNmqVcsWEKpgJUnBAmADmYaGmgRBjQOauDFwhLHwUuqqgvAlhoQRasuvXNkdDMIrQXavbqUdVAhTmtSZWtIxAZGMjiVmXsnjzLaPhsmGdDcPtJSPZixW");
    double PxKaqdV = 670152.1305689083;

    for (int MhNcNEgz = 343418175; MhNcNEgz > 0; MhNcNEgz--) {
        DbHTybjpiPNdawLa = ! lyvsaCpsmGbLlJyc;
    }

    for (int HCWdPrKDcy = 2005531663; HCWdPrKDcy > 0; HCWdPrKDcy--) {
        continue;
    }

    for (int yyvCOKkRbUUNJHlL = 474721030; yyvCOKkRbUUNJHlL > 0; yyvCOKkRbUUNJHlL--) {
        PxKaqdV = PxKaqdV;
        lyvsaCpsmGbLlJyc = wMdPIDEFS;
    }

    for (int VNJjXHOICRPJoDK = 1335235877; VNJjXHOICRPJoDK > 0; VNJjXHOICRPJoDK--) {
        aeCHU -= wOOjTxTC;
        LcVHnpgrmXhkpv /= LcVHnpgrmXhkpv;
        lyvsaCpsmGbLlJyc = lyvsaCpsmGbLlJyc;
        sibiRZqv = ! wMdPIDEFS;
        wMdPIDEFS = ! wMdPIDEFS;
    }

    for (int JoIlEcYH = 1615609169; JoIlEcYH > 0; JoIlEcYH--) {
        aeCHU = wOOjTxTC;
        uHGjklhjWjHAOR = uHGjklhjWjHAOR;
        DbHTybjpiPNdawLa = wMdPIDEFS;
    }
}

void MkknaeQBrUyjISG::rwhuuc()
{
    int DnGlIgKG = -210539823;
    string Iated = string("FhSFAHgEucIdciwgKFxtewpFbSwLHFVuyUzJHmXogoaLqhLMAIjjgPtIkPHTWEMcJNecRbqHMohhkpXtjYGeZRQiHgperuMKiczdjGGXRPSFTNvGDjkgFXgrUjFveQmWfNzEklmEGuAHVZpgPACrKeSaBaJMTNUavgOh");
    bool bxsedZVXSeb = false;
    double aXPmnZ = -408091.41054198606;

    for (int GZDKJXLBFAnIXSB = 470285244; GZDKJXLBFAnIXSB > 0; GZDKJXLBFAnIXSB--) {
        continue;
    }

    for (int IqSLZJevdF = 1762114858; IqSLZJevdF > 0; IqSLZJevdF--) {
        DnGlIgKG /= DnGlIgKG;
        Iated += Iated;
        Iated = Iated;
    }

    for (int xyezBp = 888288143; xyezBp > 0; xyezBp--) {
        DnGlIgKG += DnGlIgKG;
        Iated += Iated;
    }

    if (bxsedZVXSeb != false) {
        for (int xjXKlhmIPRV = 1366224621; xjXKlhmIPRV > 0; xjXKlhmIPRV--) {
            DnGlIgKG += DnGlIgKG;
        }
    }
}

void MkknaeQBrUyjISG::UQommohlI(bool ERRcxwugKT)
{
    int wKQBMpVXpIW = -1212207362;
    string SuIvUhNAPuUIhW = string("ipjTufDRVhKQtYVRuhFfSjjPFIqBAqKmVumTwTNtJ");
    string SQsEO = string("LPkYvBKyBtkQWvpTyDWKdJBRQqEOHNtARyWkxtbQJtsaTiFfrEDqwaUkfnKapXiAQMPUlMzidxwFvwcJQEcoHQcZluSmTOJllDRHGCmXinlALHKlQpQFpRLEYnojJrOfdRceZRYEyEVDiDhiLZqOmdBKBFjbBbssWuJsENLNpkrucoIAYDtmCfauLnxrRUFubUVEoeFqZYU");
    double HGiHXjLACF = 728904.768326396;
    string KPWVIrRwWhmPQrFb = string("B");
    bool aHsnT = false;

    for (int uJjIgbyngKwP = 2111838187; uJjIgbyngKwP > 0; uJjIgbyngKwP--) {
        SQsEO = SuIvUhNAPuUIhW;
        HGiHXjLACF *= HGiHXjLACF;
        HGiHXjLACF = HGiHXjLACF;
    }

    for (int pVkaRu = 2108540219; pVkaRu > 0; pVkaRu--) {
        ERRcxwugKT = aHsnT;
    }
}

MkknaeQBrUyjISG::MkknaeQBrUyjISG()
{
    this->frfnHQfLQH(730694.8439607321, 258875.8253774905, -968340.8496779767, true, -1334535477);
    this->iMRumIZMOCkCm(string("yKGSuppYnfZkOoIUgWPpBuWLgDQgutuQY"), 276906968, false, true);
    this->HiMiyJeG(1037294.4991836041);
    this->xovhzdpRwMW(-650768.9440102457, string("BIYFRvfVrHSxVEhmVvtSUGJNJySUcQgellHveShSIeafOxVqTGETGKWqeLXzJbpEmIOpxZnESNwVikYmvPyiApEjucMEnPkPNxgUeTSxlYIcuQLumjKUnsuOmSHgKIElVjdNYvBUPFlicOCCoIYUvuKseCBZHULOFVUrRxHKoB"), 1586290993);
    this->HwQqHqs(string("LpLnTjWePLIvzgYbDBRLICZfurBehycymLwLbUxPxdpLaKYPBWMLoQCYAdwPZYDAVyykreFubxzAnutJeWjRYASkSZUAIHJkpHOEuopTzyjEpiaeGfijegQBZVDwqKtSiiDZlVJcemNMHrNVYUeGCSBTUcqjO"), string("tCOlYuvwnFMsvwOjvREmnhGfhlhTzmjxKAXuaubAjonYCjyyyJUExNltPYVSDSUeqwwVRbdzpgaByAsfLcUkjHbMZXhCFMpwqaYnflqOSgYPROBltXOQEPBDYCuNNINuGLZxYMGJOtZdfMYBGdzCPobjySFkmzcxPWeqehrcbeGEmsDwPTesfSAexRnnXyDDFdhZTNCnjrQjXEdwR"), false, false, string("lpMoeCnFaOPZXvyQgmXnAjeTVPkSSIqFIofAhkwliEwpJdSpbJVBXnuNdLTUGfPwapZHlhyZevEmHgvlATowoEAxMVaPxEYnZgqyVLnKJgnajSrxRZWgOBHXzqaozQOVjOxvyLG"));
    this->GxFiBJPxMqCHP(1855195, 824547.1683970123, -540056.1891245955);
    this->yzkifpevFzrK();
    this->StLOGKLgSiv(-87608997, -451278208, string("pUwxHRpzqbZxtBSrUFgFVAucIohAJGFdjTvqBwKbiQgVsPdNUjrHrzOgikHptaLrmdTGLBPJoFiWYetnAlDSHrPsEpZEJeqiKMiBzbeBKZRBYJqRJeUFLfuKsNUljdYrvpbSBYYnieIqFmylqpYtCaJOSXHusCGwlfOJIGsPYmaQMrmiJyafkOuINQxVUhxfhhmuvvNlgPPYc"));
    this->NzDbilQWfdgnWx();
    this->jjsZlncck(795237.7458993671, string("MCFHifvKuxEeykGTklQLMOpbiMSqonelmcdqYdJjdQpsqeHuPIZhupdouCWUbvbwdlPlAmChBdIbZVAEdZbLPZCYHIaYIGeZwhpJOKzpGrmXmdifusDeoxTJaiCrSKHQGryhFNF"));
    this->kSAneKSgBqxDKa();
    this->HhavxxTbxmJ(false, -169333.1408999982, string("EjbrpojjCtFNPJXtYoEMrDPFxEtACkJzTwIjRqjYFchBXcQGdusVKgOLgtbhZaYvfCAvDEahYYQsSisdRJFIpCvXxjTHdikQkTyYSkZTSUkmApaFZxaqhrn"), -964454304);
    this->ZGrkEMwzrqwIQ();
    this->rwhuuc();
    this->UQommohlI(true);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class XjxUNwUDZWh
{
public:
    string tJXLtnEdgAmB;
    double zHSctlXVvjhd;
    int AmGtujuvBuW;

    XjxUNwUDZWh();
    double sNJNyCxvyUSVzZar(double LAAXDIzEJKvyZ, int tBzCftv);
    string bHLJjVZMXiWx(double aIzjmbuil);
    double hHoCmZMqoHCsaP(double KiQfzvuA);
    void rGtasAWjWrQydDXi(string siAqGAHyA, string xlGRzP, double ddzNmvb, bool kttjIsEvLzKyhHg, bool cdTBkHBW);
protected:
    string cfHdmneQk;
    string tnfXyEcRDCYCzp;
    double PtdpzkyLjxPvcUSv;
    int KdrTNG;

    bool zaXBEdRKSpnVBBI(string uFwxAwriVNtkXdE, string FXyOsX, int onNRzHyqOha, bool lbHvyY);
    double bVxIw(string qfKPwpSXFSsaPQov, bool CHCjaS, double PhJbJKI, int EskafiRNLjLYw, double OsRiyxANSWYvro);
    void YUbPPN(string hcKCMzlLCk, int fQeVPO, double HUluiRqYMtvgCY);
    string zrlHdKQvA(string kcsoKT, bool PkdTSDOjfOpOKpMs, bool VNNjrcHZkkOLsV, double flNFrPdSRI);
    void BUNzR(int oJrvElHJTKKqur, int wTxAZiPObZYBLxS, string DBrSUCehTrePuI);
private:
    bool LfoUjOaV;
    int RzditfpmJSFBuyIJ;
    int dZAqKdWEhErjU;
    bool HCZawjWAZi;

    bool AKfZHY(string QlUGgvgNKF, string xcqFOJ, string cpiDLOBZfotWn, bool bzjBxZG);
    bool MtFelhtCz(int EzSfh, bool QSSfdLvzFzjphICQ);
    bool opTnxTvZVb(double EPgGGP, double GPGoWDwRpeOgz, string wWWcyrdrsxAKcghE, bool clMOKDtIr);
    string NSWMroE(string YkfVMfeoARb, bool yuQpasRaJHy, double GULMECfba, double rVsyco);
    void YRhKLLnil(bool OapIM, bool oaIkprJZejYZyTcL, string YkASuvylw, double sbIkthbY, int ujfDS);
};

double XjxUNwUDZWh::sNJNyCxvyUSVzZar(double LAAXDIzEJKvyZ, int tBzCftv)
{
    string dXPdNSbCCm = string("pLDRRLNoISmMveFLjcIZcAOWjvkNrmquzCbfslJSdczdXjJUVszjYWppvkOiTLfIgWKuoSfHZAkVyPFBHgRSDxLiPthapNFUgTIXIsUMEIAMQyKSVGvmYBpwTCCpKizXeyLYDYKWRPBIJSfYqvlHVGCWQjVsOeAcNXxoZXzBkvQTaVCGiJQpjfWgWsrYaTTjqiVhsRAafP");

    for (int CYeDhxt = 1139600646; CYeDhxt > 0; CYeDhxt--) {
        tBzCftv += tBzCftv;
    }

    for (int ttygMqelFBkbYeX = 709905726; ttygMqelFBkbYeX > 0; ttygMqelFBkbYeX--) {
        tBzCftv += tBzCftv;
        LAAXDIzEJKvyZ += LAAXDIzEJKvyZ;
        dXPdNSbCCm += dXPdNSbCCm;
    }

    if (tBzCftv == -1900959192) {
        for (int ovaqaHoMjb = 599811463; ovaqaHoMjb > 0; ovaqaHoMjb--) {
            dXPdNSbCCm = dXPdNSbCCm;
            LAAXDIzEJKvyZ *= LAAXDIzEJKvyZ;
        }
    }

    return LAAXDIzEJKvyZ;
}

string XjxUNwUDZWh::bHLJjVZMXiWx(double aIzjmbuil)
{
    int kVHUTcYH = -1994753648;
    bool uzmfdVNE = false;
    int SKjYLaGmhHAT = -1686796724;
    bool fwvSbLj = false;
    string tVofibYQAt = string("DRHpYahMbaoithOhCSOfGuBSkJavlQOpPkBFZqmYloTWIyLbJvIAhZEIPDnJgVexENgOfPYSPnNIjODEaswvIoVfEpWUuXdFsdlVfvkPgyrcyxngmGDtbkpErXVOXrLoGgygRPDvfRDzeJUxORWJzKbgEjXgpRGIIpbNvFoHTzLIunRIdxOAAeOVXWayGOaKMSAhjBsUjvIGghWzkgXxaSETbNGboMD");
    int QpkIJKmMYGmxsUxo = -1036254766;
    double AQXYgwTeojbh = 280044.0171869741;
    string ImRwPoD = string("OlsAhyDYewjzhCirYyjFuPPNlokKvtnhHZazasufleNaJaiuyUgYvlcJenPiBnCSoNBsBWJDQCOGZPNOjGTeqWqAKCDPRFhIwWBukay");

    for (int tBehdwXPhcs = 1486733197; tBehdwXPhcs > 0; tBehdwXPhcs--) {
        QpkIJKmMYGmxsUxo += kVHUTcYH;
    }

    for (int cIhZIunQSFAQrfV = 942515773; cIhZIunQSFAQrfV > 0; cIhZIunQSFAQrfV--) {
        continue;
    }

    for (int QdZtXEnbgMF = 1413236357; QdZtXEnbgMF > 0; QdZtXEnbgMF--) {
        SKjYLaGmhHAT /= kVHUTcYH;
        SKjYLaGmhHAT /= QpkIJKmMYGmxsUxo;
        QpkIJKmMYGmxsUxo *= QpkIJKmMYGmxsUxo;
    }

    for (int wjhvEfyO = 193886955; wjhvEfyO > 0; wjhvEfyO--) {
        ImRwPoD += ImRwPoD;
        QpkIJKmMYGmxsUxo -= QpkIJKmMYGmxsUxo;
    }

    for (int jhxuhrrcV = 1259532273; jhxuhrrcV > 0; jhxuhrrcV--) {
        tVofibYQAt += tVofibYQAt;
        SKjYLaGmhHAT /= kVHUTcYH;
        fwvSbLj = fwvSbLj;
    }

    return ImRwPoD;
}

double XjxUNwUDZWh::hHoCmZMqoHCsaP(double KiQfzvuA)
{
    int LoKGGDtQeUZfJ = -1460295609;
    int IIowLtCBTLOItYs = 1717899832;
    double zyXMwCYI = -254933.06813602097;
    string DCKlTCrssGa = string("UWfXgJvanRJXTbdpfTTlkyqwHgkHsyaumXqloB");

    for (int eefcnbQbXKWohlC = 94025930; eefcnbQbXKWohlC > 0; eefcnbQbXKWohlC--) {
        LoKGGDtQeUZfJ *= IIowLtCBTLOItYs;
        KiQfzvuA *= KiQfzvuA;
        LoKGGDtQeUZfJ -= IIowLtCBTLOItYs;
    }

    for (int IlusgmiN = 9484441; IlusgmiN > 0; IlusgmiN--) {
        DCKlTCrssGa = DCKlTCrssGa;
        KiQfzvuA += KiQfzvuA;
    }

    for (int HqZUj = 904940131; HqZUj > 0; HqZUj--) {
        zyXMwCYI += KiQfzvuA;
    }

    if (LoKGGDtQeUZfJ <= -1460295609) {
        for (int WSxmM = 403230025; WSxmM > 0; WSxmM--) {
            zyXMwCYI = zyXMwCYI;
            zyXMwCYI /= KiQfzvuA;
            zyXMwCYI += zyXMwCYI;
        }
    }

    if (IIowLtCBTLOItYs <= -1460295609) {
        for (int vZQUOIz = 1241239988; vZQUOIz > 0; vZQUOIz--) {
            IIowLtCBTLOItYs *= IIowLtCBTLOItYs;
            LoKGGDtQeUZfJ *= LoKGGDtQeUZfJ;
            IIowLtCBTLOItYs += IIowLtCBTLOItYs;
        }
    }

    return zyXMwCYI;
}

void XjxUNwUDZWh::rGtasAWjWrQydDXi(string siAqGAHyA, string xlGRzP, double ddzNmvb, bool kttjIsEvLzKyhHg, bool cdTBkHBW)
{
    bool KyZPnPePqewDgits = true;
    double niwQAJwfJaDfQKi = -471983.1748039443;
    string GfvqyqqVR = string("vIpWCbTQkiCkCGSqmWZmhHvcEsNZOipehyWCIccQjJVJfRHfFTcGNlXWooKaNWZhTugkNySmYkjmtcLrgOJzBKLfNWQybYbeHPRNaMrXjFdMrWFJxoYXyqrXrfkFhGNsFlmUOSGKEAnIXOYVlEBRIexhnELPPdoipNbHRjPGlpLWJMrGEMZKKsAFXxKqicXaQqhga");
    bool CTOjYKuDE = true;
    int QEUJwzWDQ = 85088400;
    string DdWHnJgVm = string("BBubQtAqBhbeInQSwYsenwpUcHrPtkolOyaiLsEJzzmvBuEuQBvCMkVypvNUowdRmpqMzyTzwxcFcgYFfumDUsGfreJpnaWoPWTsjRzBLSfeLsYQmVvVScOXBrlhqLFAGyVFJXOAvzLXaqrEWodfsdVDaenBUuASPAMpNpCSTvRGVIfBSZfUqdIJbdubyLbVPGztyiBzMaWaBwb");

    for (int fbcfwhFJ = 886007770; fbcfwhFJ > 0; fbcfwhFJ--) {
        cdTBkHBW = kttjIsEvLzKyhHg;
    }

    for (int OQxtIJpDig = 951921198; OQxtIJpDig > 0; OQxtIJpDig--) {
        GfvqyqqVR += DdWHnJgVm;
    }

    for (int aAbOEMHPrPL = 535211489; aAbOEMHPrPL > 0; aAbOEMHPrPL--) {
        ddzNmvb *= niwQAJwfJaDfQKi;
        KyZPnPePqewDgits = ! cdTBkHBW;
    }

    if (kttjIsEvLzKyhHg != true) {
        for (int cSppDPBrasM = 348992401; cSppDPBrasM > 0; cSppDPBrasM--) {
            DdWHnJgVm += GfvqyqqVR;
            GfvqyqqVR = xlGRzP;
            ddzNmvb = niwQAJwfJaDfQKi;
            cdTBkHBW = ! KyZPnPePqewDgits;
        }
    }

    if (GfvqyqqVR != string("vIpWCbTQkiCkCGSqmWZmhHvcEsNZOipehyWCIccQjJVJfRHfFTcGNlXWooKaNWZhTugkNySmYkjmtcLrgOJzBKLfNWQybYbeHPRNaMrXjFdMrWFJxoYXyqrXrfkFhGNsFlmUOSGKEAnIXOYVlEBRIexhnELPPdoipNbHRjPGlpLWJMrGEMZKKsAFXxKqicXaQqhga")) {
        for (int mvynjxrOEBmpmyi = 172390522; mvynjxrOEBmpmyi > 0; mvynjxrOEBmpmyi--) {
            GfvqyqqVR += xlGRzP;
            KyZPnPePqewDgits = ! KyZPnPePqewDgits;
        }
    }
}

bool XjxUNwUDZWh::zaXBEdRKSpnVBBI(string uFwxAwriVNtkXdE, string FXyOsX, int onNRzHyqOha, bool lbHvyY)
{
    double UDXwvBkCrNdlNgyc = 620702.5423799778;
    string jSRbLIOOmr = string("sHFElxlSoDcPQDelARQBsEoXMQlFtPtEvDKshTnQJEaCAF");

    for (int KziSnmisv = 279540851; KziSnmisv > 0; KziSnmisv--) {
        continue;
    }

    for (int UCxkSOr = 1173255403; UCxkSOr > 0; UCxkSOr--) {
        onNRzHyqOha *= onNRzHyqOha;
    }

    for (int RKWhuYawqWL = 2015806399; RKWhuYawqWL > 0; RKWhuYawqWL--) {
        jSRbLIOOmr = uFwxAwriVNtkXdE;
    }

    for (int ILnHgIIHPCtJWv = 34823827; ILnHgIIHPCtJWv > 0; ILnHgIIHPCtJWv--) {
        FXyOsX = uFwxAwriVNtkXdE;
        jSRbLIOOmr = uFwxAwriVNtkXdE;
    }

    for (int bjKZYLzscprQYTm = 638377167; bjKZYLzscprQYTm > 0; bjKZYLzscprQYTm--) {
        UDXwvBkCrNdlNgyc += UDXwvBkCrNdlNgyc;
        FXyOsX = uFwxAwriVNtkXdE;
        jSRbLIOOmr += FXyOsX;
    }

    return lbHvyY;
}

double XjxUNwUDZWh::bVxIw(string qfKPwpSXFSsaPQov, bool CHCjaS, double PhJbJKI, int EskafiRNLjLYw, double OsRiyxANSWYvro)
{
    int KXsjeh = 1596249733;
    int yZkJDXDvbuX = -120762901;
    bool PVSpFXw = true;
    string iQebtHLIMXLh = string("tnNNsUgMROwfWVAuzjYSUptcnAPEXOvpSxGtzoOOxLUGmEbhAYeJakQwYGxDeVKMxAJZhcpOuPZNPFmsknHqYQreeqyrZtEGqiYMYhkbtTVjmZQzqDbEMYtFaijHhtmEaWDRMidZVRMIAsflrQZOhCuLnnVIRFxECPaXaagCvBAziUDYthTJKHRsVtxEuIZaJxrBEZBtPaLlzDwkYqZHkmQPEdOjEWMDtHKnQCwJP");
    string rYljE = string("CqxTxgCAeiEdLvBgjYahFNgQYnAomWTtKRlCkfNxXrclCWuoLfKmCUPtTnTJGenpXBtrbmLHYuZydTbWKdJzBPWfNTfiQlyWTFfNrodwTSFfNekLXKHYgKyiwhwmPeUtgZpjcgcAlfwkwqbBzimlkedxntjCBLUoThBLmjZvzgTiNPNyrLVFPNcHKYFPQSmILXfQujrIiQizuwmhCrvghvLiqrjvDtpozCcxoTlwbXjdHGKICP");
    bool qRljarqAJZFLACJH = false;
    bool VjkXjarkKNJYY = true;
    int GhTlF = -2000858504;
    double lUdjWZBrhehtTAf = -736172.4516712921;

    for (int pCsRDOePL = 719928729; pCsRDOePL > 0; pCsRDOePL--) {
        EskafiRNLjLYw *= yZkJDXDvbuX;
    }

    if (EskafiRNLjLYw != -120762901) {
        for (int jrfuSMjJhbbXT = 867754877; jrfuSMjJhbbXT > 0; jrfuSMjJhbbXT--) {
            continue;
        }
    }

    for (int Tmkpuhjg = 904111390; Tmkpuhjg > 0; Tmkpuhjg--) {
        qfKPwpSXFSsaPQov = qfKPwpSXFSsaPQov;
    }

    if (yZkJDXDvbuX <= -120762901) {
        for (int UZUzpDWGmeUXxbiP = 1086088867; UZUzpDWGmeUXxbiP > 0; UZUzpDWGmeUXxbiP--) {
            KXsjeh -= EskafiRNLjLYw;
        }
    }

    for (int IdqOPSZawqPt = 1190372070; IdqOPSZawqPt > 0; IdqOPSZawqPt--) {
        continue;
    }

    return lUdjWZBrhehtTAf;
}

void XjxUNwUDZWh::YUbPPN(string hcKCMzlLCk, int fQeVPO, double HUluiRqYMtvgCY)
{
    double moffowRtfzF = 1024988.0639812795;
    double riUDouLGRXqCqdui = 241913.14855697626;

    if (riUDouLGRXqCqdui >= 241913.14855697626) {
        for (int SzRTwcEx = 2019333571; SzRTwcEx > 0; SzRTwcEx--) {
            riUDouLGRXqCqdui = moffowRtfzF;
            riUDouLGRXqCqdui *= HUluiRqYMtvgCY;
            riUDouLGRXqCqdui /= moffowRtfzF;
        }
    }

    for (int HueCatot = 1635653865; HueCatot > 0; HueCatot--) {
        continue;
    }

    if (hcKCMzlLCk > string("eaITFgmMJQFNkbTaZAnuFBxRRYSXXwHWwZuxYJbQSwnidzzjBXxeDFPXhcJQksJprPiIbGHAwAYIwsyxtvVNPMJLV")) {
        for (int IezCgPdZWFwYUOgB = 878277878; IezCgPdZWFwYUOgB > 0; IezCgPdZWFwYUOgB--) {
            moffowRtfzF /= moffowRtfzF;
            hcKCMzlLCk = hcKCMzlLCk;
            riUDouLGRXqCqdui = HUluiRqYMtvgCY;
        }
    }

    for (int ZSdYmOwkYBgtf = 1336418632; ZSdYmOwkYBgtf > 0; ZSdYmOwkYBgtf--) {
        moffowRtfzF = HUluiRqYMtvgCY;
    }

    for (int IaRRJLuzYT = 702684172; IaRRJLuzYT > 0; IaRRJLuzYT--) {
        HUluiRqYMtvgCY /= HUluiRqYMtvgCY;
    }
}

string XjxUNwUDZWh::zrlHdKQvA(string kcsoKT, bool PkdTSDOjfOpOKpMs, bool VNNjrcHZkkOLsV, double flNFrPdSRI)
{
    double yyPoqDVDxh = 247842.16791318258;
    string PwhjPgBlwI = string("JSbyJWsmEFMODZlNoKkSUmPBWSpIaUAYcycFhbGAZjmTEkgfdlKCiZiWpVZpVrFEXkfCthHbmnZyMdSgMUGpURvTrJsehgXePMNhVmqHYbHsXABqCPMNMbXsYgJdjIKwFIpHKHBmBprNtKlygSmlYG");
    int XbCAh = 237142835;

    for (int FlLrNWIdST = 2145591511; FlLrNWIdST > 0; FlLrNWIdST--) {
        PkdTSDOjfOpOKpMs = VNNjrcHZkkOLsV;
    }

    for (int cgQxRWLNh = 2142939689; cgQxRWLNh > 0; cgQxRWLNh--) {
        PwhjPgBlwI = kcsoKT;
        PwhjPgBlwI = PwhjPgBlwI;
    }

    if (PwhjPgBlwI >= string("kwPxhjgrJjzcjXFelKMFAtnSrPQtcQDqwrqDFmLRwPqZDSBsVfNyZtscekFVvktVNUPwwMglLFCAgaQdgeVqgLaIvkXNzBkSNUFEKcuQdoyvBxvDPFxJRxozbdOReAkTypcpBRQYTjLj")) {
        for (int glgXnLh = 1890432538; glgXnLh > 0; glgXnLh--) {
            kcsoKT = kcsoKT;
            yyPoqDVDxh *= flNFrPdSRI;
            flNFrPdSRI -= flNFrPdSRI;
            kcsoKT = kcsoKT;
        }
    }

    return PwhjPgBlwI;
}

void XjxUNwUDZWh::BUNzR(int oJrvElHJTKKqur, int wTxAZiPObZYBLxS, string DBrSUCehTrePuI)
{
    string nBxmHvOeZAuwqr = string("yeuhlAjSMdDcIUbCksUsgaZJytZUzYniAehzJEpBrVvdjeyrXkWqXRPraWlhqEIbZZGgokhRpoHxlKfgMHHvyXKEqJPNkKRfOrYjeSMNhzcyaFAUFoalaHazSYdHbydpyTrNXuZukliXPAQqBehuhfOetxuzNYlyKDkOVdZihAElKCuZFfdRJKIRAsWuGfOmFugKQBVE");

    if (wTxAZiPObZYBLxS <= 1828448427) {
        for (int VueUL = 1330361978; VueUL > 0; VueUL--) {
            DBrSUCehTrePuI = nBxmHvOeZAuwqr;
            oJrvElHJTKKqur += wTxAZiPObZYBLxS;
        }
    }

    if (nBxmHvOeZAuwqr >= string("yeuhlAjSMdDcIUbCksUsgaZJytZUzYniAehzJEpBrVvdjeyrXkWqXRPraWlhqEIbZZGgokhRpoHxlKfgMHHvyXKEqJPNkKRfOrYjeSMNhzcyaFAUFoalaHazSYdHbydpyTrNXuZukliXPAQqBehuhfOetxuzNYlyKDkOVdZihAElKCuZFfdRJKIRAsWuGfOmFugKQBVE")) {
        for (int wUjjzAckg = 2031102549; wUjjzAckg > 0; wUjjzAckg--) {
            wTxAZiPObZYBLxS -= oJrvElHJTKKqur;
            nBxmHvOeZAuwqr += DBrSUCehTrePuI;
            DBrSUCehTrePuI = nBxmHvOeZAuwqr;
        }
    }

    for (int emWpiN = 1090776391; emWpiN > 0; emWpiN--) {
        oJrvElHJTKKqur -= oJrvElHJTKKqur;
        DBrSUCehTrePuI += nBxmHvOeZAuwqr;
        nBxmHvOeZAuwqr += DBrSUCehTrePuI;
        nBxmHvOeZAuwqr += nBxmHvOeZAuwqr;
    }
}

bool XjxUNwUDZWh::AKfZHY(string QlUGgvgNKF, string xcqFOJ, string cpiDLOBZfotWn, bool bzjBxZG)
{
    int aflniSbmMmzkA = -1983686381;
    string FakxEMPqwofDXm = string("TuSdsXbrdulflKfnhCBBOZAVcGTWstnCELkBBnmIZnmOEAXaOXHBFQqiLRkVyXCkAnAGbTOWSovbWLgnphnTVfIhsIzIXsgukEZTfvUjQYvpkEoDPeAFbMxDZwm");
    double AvrsqsZhHG = 1001708.3737542285;
    int jYfSS = -1648353232;
    double IirVosfcKKPzC = -749589.654640533;

    for (int AXnzjcTmbtlhyCQY = 1226339825; AXnzjcTmbtlhyCQY > 0; AXnzjcTmbtlhyCQY--) {
        continue;
    }

    for (int LdCqdJqJWrHZZ = 414732786; LdCqdJqJWrHZZ > 0; LdCqdJqJWrHZZ--) {
        AvrsqsZhHG /= IirVosfcKKPzC;
        cpiDLOBZfotWn += FakxEMPqwofDXm;
    }

    return bzjBxZG;
}

bool XjxUNwUDZWh::MtFelhtCz(int EzSfh, bool QSSfdLvzFzjphICQ)
{
    int KHeFGeegVol = 2014889077;
    int fYvwl = 1689983697;
    int QmVZFVBeATe = -1320899121;
    string MIIapR = string("sYgyJNPKeFhteAakOtsMyPeXKRqBSmMNJghKMFdULeloyunuInsTzJnVGdfuzeKvsoIQFRjdgrIgYlJQkEludoO");
    int QSVcrsCfyMeB = 1085797290;

    for (int WDGAIBzSqN = 2006601941; WDGAIBzSqN > 0; WDGAIBzSqN--) {
        QmVZFVBeATe = EzSfh;
    }

    for (int VoAhe = 1198084274; VoAhe > 0; VoAhe--) {
        EzSfh += fYvwl;
        QSVcrsCfyMeB += QSVcrsCfyMeB;
    }

    if (fYvwl < 1689983697) {
        for (int PPRwoeIjDI = 1521133756; PPRwoeIjDI > 0; PPRwoeIjDI--) {
            fYvwl = fYvwl;
        }
    }

    if (QSVcrsCfyMeB != 2014889077) {
        for (int ktzMUhBkw = 1080302149; ktzMUhBkw > 0; ktzMUhBkw--) {
            KHeFGeegVol += EzSfh;
        }
    }

    if (QmVZFVBeATe < 1689983697) {
        for (int cbypcJTrLDePu = 60985001; cbypcJTrLDePu > 0; cbypcJTrLDePu--) {
            EzSfh += KHeFGeegVol;
        }
    }

    return QSSfdLvzFzjphICQ;
}

bool XjxUNwUDZWh::opTnxTvZVb(double EPgGGP, double GPGoWDwRpeOgz, string wWWcyrdrsxAKcghE, bool clMOKDtIr)
{
    bool tZcBVmBztcxEM = true;
    double nhbjhLkHmqM = -1042071.4140783466;
    string hdRcT = string("EfrOkkkZsqMMuifNidYnvgYAzBMecnVEmQASbwJkwpDC");
    string QwyjIeEIGXEbkZ = string("RNBSVBJqvsOlGRGPlnYubnsYhCdqMrZTRGQTlBSpcEqUhIowCURjhJaRKovkc");
    int kGeWfpkqZrBK = 1567302164;
    double jLATzwivQ = -99506.2104548519;
    double PkfVBpTrVkFFj = -799513.4754314314;
    int eyTHgwa = -1146624281;

    for (int esWxEleX = 709909798; esWxEleX > 0; esWxEleX--) {
        GPGoWDwRpeOgz += GPGoWDwRpeOgz;
    }

    return tZcBVmBztcxEM;
}

string XjxUNwUDZWh::NSWMroE(string YkfVMfeoARb, bool yuQpasRaJHy, double GULMECfba, double rVsyco)
{
    string rVRjeTAqymLFr = string("VtFlkohnEaTSOAMsNGmYlXkQejJVOuaouahrOZgLHVKiLGnQMfwgwJmBBzCtGcbbItWUIDGbCuBhFpuvUeeyZDWzLtZZOiLZWUSBlTQPcmHQyHvyPSNqHwOOIqdtzlypjuuotXFeRRIeVyQQzwhDCnTFxotgIskXtEkndfIuQmVcuNAFB");
    double TDkzToTLwStQ = -854989.7043885168;
    bool ZmadZezXMT = true;
    int grQVOn = -899937601;
    bool fSdTFxTKpCfIVDG = false;

    if (rVsyco <= -474310.51272577397) {
        for (int Cchetip = 1643159009; Cchetip > 0; Cchetip--) {
            continue;
        }
    }

    return rVRjeTAqymLFr;
}

void XjxUNwUDZWh::YRhKLLnil(bool OapIM, bool oaIkprJZejYZyTcL, string YkASuvylw, double sbIkthbY, int ujfDS)
{
    int xdAwKHUQBXldU = -40066996;
    double mUiENKGiKrSQPn = 660268.7605243528;

    if (OapIM == true) {
        for (int UXqucnrO = 2116663371; UXqucnrO > 0; UXqucnrO--) {
            OapIM = oaIkprJZejYZyTcL;
            oaIkprJZejYZyTcL = ! OapIM;
            ujfDS /= ujfDS;
        }
    }
}

XjxUNwUDZWh::XjxUNwUDZWh()
{
    this->sNJNyCxvyUSVzZar(406199.1610120314, -1900959192);
    this->bHLJjVZMXiWx(-441364.2530945118);
    this->hHoCmZMqoHCsaP(-747523.2231078211);
    this->rGtasAWjWrQydDXi(string("pqhoXjaxZgRJpzfIwPkUMjtnBQYGLUVbIYvofUjXuLyDSGgDMImNLJkhkfPMKOSYLDQYNwznjNsXJvHXWQYxyCAHMrMNSGXnfWrvOcSNwaWydOLhmxAdDbVbGDswTgrbrvKdnvRhgDJwXWFZJVWNNYIWCLSaBwqgZPDGDoCXhcVyhujXWvplBzFSIdueBHcoertjm"), string("ETNiBiNhoPALRDcdYnxwvOIxBYPuYbVESquXidRnWXscRGLtQVcBVwpJHtHPdIpKSwFaEWpsFEsdLeDJywEjGRfiPUPkAyPqodIQnwMcgUXQnRjmWIfzZtipWMoEfiwvHrnUNAzSwLeUdjXajirylcQRLijyWTYINYdcSIWNffjbxVkJIAowIEcBHgZz"), -901651.3212096038, true, true);
    this->zaXBEdRKSpnVBBI(string("iAeWmeCcZcholzrkEJNUEfVcetVxcPYOtEbOBHRuTUvBPSjpVIYtSISByiFWbDbeMKLJjILkyYNFswYZQVkAmNKeumDlUxVtDIXEdxfJxOyayuSpJKfWfwwGPecPtiFYxYspCRWzFnewFRdfsGflIEFlVfIAxevLVyhtFJLsNACQxxTqxTyrOdesCBMkKaCAuLbZjLclqFetTByAfjJeJwjmzIMVaQsrwApVCKmuOZCeSWOdlNvq"), string("kcXPhseyvoEqLDuCHyZjfkItknDnstRzMthphhGZpzZmabuXkGtQgJWIhJEWQMqNfYyjHdQMrVhXSdQoVWsPJgdfKaNNizAvPqsBpYiMAEVBkbxyStrVYquhZzsmumPaCkEFBsOMKTYEMCjHUlWjc"), -114890692, true);
    this->bVxIw(string("KjgnonALuhaRIG"), true, 255805.90212216438, 611420179, 268392.3276725968);
    this->YUbPPN(string("eaITFgmMJQFNkbTaZAnuFBxRRYSXXwHWwZuxYJbQSwnidzzjBXxeDFPXhcJQksJprPiIbGHAwAYIwsyxtvVNPMJLV"), -1411402751, 320119.4756295412);
    this->zrlHdKQvA(string("kwPxhjgrJjzcjXFelKMFAtnSrPQtcQDqwrqDFmLRwPqZDSBsVfNyZtscekFVvktVNUPwwMglLFCAgaQdgeVqgLaIvkXNzBkSNUFEKcuQdoyvBxvDPFxJRxozbdOReAkTypcpBRQYTjLj"), true, false, 172328.6062203259);
    this->BUNzR(1828448427, -1290778092, string("EhGgiZNBnpnJYrmskDP"));
    this->AKfZHY(string("ZjYgmIIPfFiymGqZrDwkCQxOYyGoszlbYMGFpvTd"), string("vPFDOXJsyLBRVReEuwvHusVwEyPoWXANnAotbiDoYIzqgEWbejAldnNEdyIVWPpaQbcXpSrYxbnHPmlccrXIYtvVyZiQWFrEzMwNCuUSikFWsxYaRtXKtFnmViERzjKOaswUeoLwJMbRTfiUrciUlxgfOgIaXqWtrCPEduTlJGtREjGVbadLZIxgDReiDHmsUpqvYQqjJgKBwcQLqeNDPWTtGEJZBAUCbCBEItFFYwASndrxavPO"), string("XSjaKePLOkyzXgTk"), false);
    this->MtFelhtCz(-763534256, true);
    this->opTnxTvZVb(510731.21656003187, 888948.5750421251, string("FNOlIZtbKdJogMRmDVAbvULyEOOUJLqEFswAJWEqOAqOTAwDFbQGJiddPMQpUhaUJJwVoOFiIJUwivVVxNuKJdPDbvUXNRyOVIIRgKYBhonsHqBVRXnorClwQxeXHDUSCGZuHQ"), false);
    this->NSWMroE(string("MpfGIXLiGXCjCyIzxrNstvsuOV"), false, 63215.5897586758, -474310.51272577397);
    this->YRhKLLnil(true, true, string("LJGfOLjIxSUiZBRBlDlBQeQlkTnbhYYVvnRIkAUUmsUVsPEsNudEDBiCxFxCCNngMVnqICObNiFJaRLRbsgUgvaCcumzUVqCMUxLiZMyaXzVJpeceTRaHhufmXSByRVmOxWvAHidTHtHNQHqjEcYZnilMHYHRlKTuVxSjKQofriWKoZeYwcCwSSuMYQZaXmpYsQIxWNyphjzQHvfeVXafokjpNcVbkalHFdsiHLeuRypuUAMQCgzEOQYeP"), -331047.66374786524, -824828028);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class EglekXoGnbSrh
{
public:
    bool vcBkrDLlCKd;
    string EcneGmI;
    string bgrBalIkSSqsaVZJ;
    string mkRdJKDMRnLNI;
    bool lpDBrnJBE;
    double VvPGQJHTfkVLfE;

    EglekXoGnbSrh();
    double KJRTRjRJaH();
    double aQYYnucaKFeoNx(int XRqDk, bool LFNxQrmBUEHvqoJM, int SBoKvDJi, string zBeWCuoEYw, string OKRfB);
    bool DKrsFISbtkfMW();
    string skYQCPn(int aYuSEbYVqSm, string KCctXqJI);
    void IqBfDDNEtepT();
    int BHXoJOA(int ImPCJcJAFozDccX, string rVnkliuOuroBK, double RZScCDEjj, int GVssqvOHI);
protected:
    double GvUUQZqaHEmCTvXi;
    bool utffigvo;
    double PEvNW;
    string ykmDPcoGmlkHGsCC;
    int vpkxNUjukkKd;

    int FOxTpNixXHOLLfLA(bool EuPxxXVfbGxT);
    double JaRzAxKonH(bool BDlHpChq);
    int XmnhQdfKdMI(int FLFjigHxapL);
    string zdehBCjNQ(string UzCsynIdHACrJ, int FBKTqvXGMPShl);
    string FVvoEnKXUG(string fEjDBu, double lRddaQZuikuR);
    void WhvLKX(double DqOAw, string HtfFmsUFccgGQR, double hmEeOCBtKbMaNHc);
    void BAKyJundPAJ(string SPIzDdJXO);
    string ZrRwrsKPU(double vXMgEimBmB);
private:
    double xaLStiCLUMZScdO;
    string bpjqx;
    int UjxNfFerKGnllF;
    int vhUTc;

    double aetzUwYlHgKTAqA(string PQMoOUM, string jmEuExkGngPfLDt, int ilzcirh);
};

double EglekXoGnbSrh::KJRTRjRJaH()
{
    string LykglQQipsQAD = string("cEHwMpfjzaCHbjMbjaqWOkILomZTkwAPTypdnxMMoRRSpuoaDOMmsrjLEqnnqHrxMnRTrfyqvHfvQGMkomuXpAglGetgWVbnaevYGzIatrOYzzAJfyPyChbyolCntRjpiiQYmcOlOOoWZGzwuKZqlrMMzbICKQZXLhvBptpgqhTyqNsgMAPNguXFSKJREFyFH");
    int avEwA = 938826668;

    if (avEwA != 938826668) {
        for (int fiBGqdVCKKId = 495545758; fiBGqdVCKKId > 0; fiBGqdVCKKId--) {
            LykglQQipsQAD += LykglQQipsQAD;
            LykglQQipsQAD = LykglQQipsQAD;
        }
    }

    for (int yISXLcEmYzHwq = 1957434906; yISXLcEmYzHwq > 0; yISXLcEmYzHwq--) {
        LykglQQipsQAD = LykglQQipsQAD;
        LykglQQipsQAD += LykglQQipsQAD;
    }

    for (int ZuErMNRpRpjdta = 1097117635; ZuErMNRpRpjdta > 0; ZuErMNRpRpjdta--) {
        LykglQQipsQAD += LykglQQipsQAD;
    }

    if (LykglQQipsQAD < string("cEHwMpfjzaCHbjMbjaqWOkILomZTkwAPTypdnxMMoRRSpuoaDOMmsrjLEqnnqHrxMnRTrfyqvHfvQGMkomuXpAglGetgWVbnaevYGzIatrOYzzAJfyPyChbyolCntRjpiiQYmcOlOOoWZGzwuKZqlrMMzbICKQZXLhvBptpgqhTyqNsgMAPNguXFSKJREFyFH")) {
        for (int rkwLqbMAYfHEY = 1636895501; rkwLqbMAYfHEY > 0; rkwLqbMAYfHEY--) {
            avEwA /= avEwA;
            LykglQQipsQAD += LykglQQipsQAD;
            avEwA /= avEwA;
            LykglQQipsQAD = LykglQQipsQAD;
            avEwA += avEwA;
        }
    }

    for (int bsSLNDrXmzqu = 1181330087; bsSLNDrXmzqu > 0; bsSLNDrXmzqu--) {
        avEwA -= avEwA;
        avEwA -= avEwA;
        LykglQQipsQAD += LykglQQipsQAD;
        LykglQQipsQAD += LykglQQipsQAD;
        avEwA *= avEwA;
        avEwA *= avEwA;
    }

    for (int OBALp = 642416928; OBALp > 0; OBALp--) {
        continue;
    }

    return -146089.7236752505;
}

double EglekXoGnbSrh::aQYYnucaKFeoNx(int XRqDk, bool LFNxQrmBUEHvqoJM, int SBoKvDJi, string zBeWCuoEYw, string OKRfB)
{
    bool dFzKBnjH = true;
    bool KlkFfYFtDBNJEJL = false;
    int dESRyEq = 573895980;

    for (int xuhYfIOokxSLHuV = 1500540375; xuhYfIOokxSLHuV > 0; xuhYfIOokxSLHuV--) {
        SBoKvDJi *= XRqDk;
    }

    if (dFzKBnjH == true) {
        for (int QLzYNto = 1158498666; QLzYNto > 0; QLzYNto--) {
            OKRfB = OKRfB;
            SBoKvDJi *= dESRyEq;
            OKRfB = zBeWCuoEYw;
            dFzKBnjH = LFNxQrmBUEHvqoJM;
        }
    }

    for (int qyQUIvNl = 2104465922; qyQUIvNl > 0; qyQUIvNl--) {
        XRqDk -= SBoKvDJi;
        zBeWCuoEYw = OKRfB;
    }

    for (int igVctcvj = 889882892; igVctcvj > 0; igVctcvj--) {
        SBoKvDJi += dESRyEq;
    }

    if (LFNxQrmBUEHvqoJM == false) {
        for (int BANddKZgd = 965045934; BANddKZgd > 0; BANddKZgd--) {
            SBoKvDJi *= SBoKvDJi;
        }
    }

    for (int MpMpen = 1481730834; MpMpen > 0; MpMpen--) {
        dESRyEq -= XRqDk;
        zBeWCuoEYw += OKRfB;
        XRqDk -= XRqDk;
    }

    return 681586.7053983518;
}

bool EglekXoGnbSrh::DKrsFISbtkfMW()
{
    int TkhHLEeIdThUwN = -1036710388;
    int cEcHkicWAXEkpsI = 1122682518;
    bool tzZcGW = true;
    int JpANeJWsubtAbDw = 273755590;
    bool CYUAJjDOWSVT = false;
    string WRCkAioxnXnpjf = string("TuRfsWkbDUzu");
    string scQcTfeZj = string("xHJzoYsVvdTTsJwvAZuRbXfiIAoRTweS");
    bool LGgSKbwgHRXRjwk = false;
    bool ZcUWiiCpeSml = false;

    for (int fzHQprasNQPB = 1624915260; fzHQprasNQPB > 0; fzHQprasNQPB--) {
        ZcUWiiCpeSml = ! LGgSKbwgHRXRjwk;
        tzZcGW = ! LGgSKbwgHRXRjwk;
        tzZcGW = ! LGgSKbwgHRXRjwk;
    }

    if (LGgSKbwgHRXRjwk == false) {
        for (int irIoKpVrLD = 1872746542; irIoKpVrLD > 0; irIoKpVrLD--) {
            continue;
        }
    }

    return ZcUWiiCpeSml;
}

string EglekXoGnbSrh::skYQCPn(int aYuSEbYVqSm, string KCctXqJI)
{
    bool qaEKpnDo = true;
    bool VxDWIlJ = true;
    int UnWLbFjSrDoBi = 844337556;
    string JtBFbIPAJi = string("XPkXZaoEMqBNBoiGLGDiZxLlxmFyivbYVItIKxwfJEsEpZMAEqCYfDYldShLYKZNHiJHMDxWaKgeMcCRJiUuszGUfvgtOeRUmqwVBFtCYDUvnBoGbIkEvHBpRbcejMwbaMujE");
    double VHtZWijlJZAC = -64922.16112714357;
    double tYbekxHrJSC = 724222.0621663614;
    bool lHAcErmGyGFUj = true;

    for (int ncJluxGHBkJJuwG = 1317538568; ncJluxGHBkJJuwG > 0; ncJluxGHBkJJuwG--) {
        VxDWIlJ = ! lHAcErmGyGFUj;
    }

    for (int KuPojWYMtkABTI = 2017994379; KuPojWYMtkABTI > 0; KuPojWYMtkABTI--) {
        UnWLbFjSrDoBi *= aYuSEbYVqSm;
        lHAcErmGyGFUj = lHAcErmGyGFUj;
    }

    return JtBFbIPAJi;
}

void EglekXoGnbSrh::IqBfDDNEtepT()
{
    int JgiBmLHhGjRK = -301368562;
    bool QdZtcSnOVE = false;
    int eMLtgahdqsBVVzD = -2119971873;
    bool KYhcgkPfIis = false;
    bool JARbgPbnGUTRAduA = false;
    string JrCoydKJlUhL = string("igchOTkcaRedZNAQgzZQYrflxYSjOPVkOJbdxSZXDZopkekmLkvTlpsOPvLfyVkxSQeezlOaCuKXCrvqIrYyncHeMqCGgiHaQoKadVxTbYNIKUJtQsYdCioGWMUoOjCzOmApzLZeRNQACiWalXvilgtxXwBSmcXscjAiQfxaw");
    double jULiREocK = -770498.1014592354;
    double KpYvjHiHji = 169099.178228523;
    string aCkIxDzZbb = string("DBjKIGmycFItkwIOJVsRSBNhqHLcrkvOSEdUYgPlsPDgwIsvkUNtDRzjwFNYIRgmbkhdEemIbRtrXezgWRrQfrjjYCdJWuSSAXzCoqNONtJFwXqldbfLWECoguBvMBOeUwRlfPrrKrTcd");
    int IvpVhESSFUrmUbA = 533053621;

    for (int LJBMYjryGt = 434708903; LJBMYjryGt > 0; LJBMYjryGt--) {
        IvpVhESSFUrmUbA *= JgiBmLHhGjRK;
    }
}

int EglekXoGnbSrh::BHXoJOA(int ImPCJcJAFozDccX, string rVnkliuOuroBK, double RZScCDEjj, int GVssqvOHI)
{
    string lhEeSLTgciHNDKU = string("qWmAWcYtvSExpNJVWEkiGhuQiEwWQzAdFHXyCTOLOBCgvchMTBWOxXiHNQquJsgvJHcEjMbjpaSCCtn");
    double fkcHOXeuZIWlb = -59648.46944031203;

    return GVssqvOHI;
}

int EglekXoGnbSrh::FOxTpNixXHOLLfLA(bool EuPxxXVfbGxT)
{
    double iPYeUVGnqNMvofId = -757566.435296318;
    double xgGOdn = -338711.1152300943;
    int zcQbU = 1342746295;
    int OKuabABxye = 2137417336;
    string SRWkaoxbJyNNTsrw = string("nJESCOEICUsdegFVDWyJAtXEETEvFUdcEcMg");
    int FEwISvzzSHQSMy = -643304171;

    for (int MWQgjXJmOdOKok = 1823065852; MWQgjXJmOdOKok > 0; MWQgjXJmOdOKok--) {
        continue;
    }

    return FEwISvzzSHQSMy;
}

double EglekXoGnbSrh::JaRzAxKonH(bool BDlHpChq)
{
    double whaRREQoTS = 952829.2035576623;
    double THQvUu = -967249.9455639558;
    bool NaZTzRZXYFdCJi = false;
    int AnKKOpyeVythoHvE = -2033647927;

    for (int iZsgY = 565862555; iZsgY > 0; iZsgY--) {
        BDlHpChq = ! NaZTzRZXYFdCJi;
    }

    for (int xhbbW = 1415671180; xhbbW > 0; xhbbW--) {
        THQvUu /= whaRREQoTS;
        whaRREQoTS += whaRREQoTS;
        THQvUu *= THQvUu;
        AnKKOpyeVythoHvE /= AnKKOpyeVythoHvE;
    }

    if (NaZTzRZXYFdCJi != false) {
        for (int ImGREkgc = 676824392; ImGREkgc > 0; ImGREkgc--) {
            continue;
        }
    }

    for (int wKkYUjI = 2005402717; wKkYUjI > 0; wKkYUjI--) {
        continue;
    }

    for (int jtGPBhpAhQRI = 625328520; jtGPBhpAhQRI > 0; jtGPBhpAhQRI--) {
        whaRREQoTS *= whaRREQoTS;
        whaRREQoTS += whaRREQoTS;
        NaZTzRZXYFdCJi = ! NaZTzRZXYFdCJi;
    }

    return THQvUu;
}

int EglekXoGnbSrh::XmnhQdfKdMI(int FLFjigHxapL)
{
    int xXmxVigRGu = -1646118326;
    double XdhSSTBbryBuyzO = 695783.2211255608;
    int biXjxZrfcdz = -971801940;
    bool dgIMWaU = true;
    double RoqpRRcaOojgEnhn = -387270.84747734654;
    string nObKkofYrymL = string("lhcCQUZlwVfWJqoqfkFwRxLcShPUptcQPhvrHpCLPmeblsRLFpXyLLTVAkZDGGFbJzlwTxaiqqgiIqGXEbZEbsYmRsZtwjRVkkDTmggqEzDHKZdqXvTwpdfKZiRRSrIFcmxJWHYzccwyVcDdfMVJAonLujSdepQPpUUrSrRxuIwwiBzTuNnjYiwxnqrQQqcSeaoRaSSBkaLSyAdptFJtiUN");
    string RCmfWNDoOfJFNC = string("wvzUBXMYjsYkNKaTEiklrsuYuZYoAwALYrtrmqKYoRZQrjBGHjoLXyHYREnoggrywZDQZVeeNAHZFciNvLWUPSrCwe");
    string KYmBW = string("KXcPpkrsccodIKoTzRSbszjLFCRcukEpRjvZRQCZIQqfnopTKmpOtQMRBeRalzicJXOKcsdUbOrzoyWTsDTDWlQkORFZDPBkhbNpk");

    for (int SEihZ = 1848881663; SEihZ > 0; SEihZ--) {
        RoqpRRcaOojgEnhn /= RoqpRRcaOojgEnhn;
    }

    if (RCmfWNDoOfJFNC != string("wvzUBXMYjsYkNKaTEiklrsuYuZYoAwALYrtrmqKYoRZQrjBGHjoLXyHYREnoggrywZDQZVeeNAHZFciNvLWUPSrCwe")) {
        for (int WAkVdNfsF = 1627934149; WAkVdNfsF > 0; WAkVdNfsF--) {
            continue;
        }
    }

    for (int XEUhkwdSNYpxa = 168448274; XEUhkwdSNYpxa > 0; XEUhkwdSNYpxa--) {
        nObKkofYrymL += RCmfWNDoOfJFNC;
    }

    if (FLFjigHxapL <= -971801940) {
        for (int sQBJFeUtUur = 112272429; sQBJFeUtUur > 0; sQBJFeUtUur--) {
            biXjxZrfcdz += xXmxVigRGu;
        }
    }

    for (int kUxnjkLircIBYEpd = 1077804016; kUxnjkLircIBYEpd > 0; kUxnjkLircIBYEpd--) {
        biXjxZrfcdz *= xXmxVigRGu;
    }

    return biXjxZrfcdz;
}

string EglekXoGnbSrh::zdehBCjNQ(string UzCsynIdHACrJ, int FBKTqvXGMPShl)
{
    double HqmeUj = 335823.13989490527;
    double RrCfZfTkrjl = -338224.8876199519;
    string clvCTNQdyHOzuBh = string("ZQ");
    string GpxehE = string("EKxekmdsFcfYkmKbJseUwccPtpkNFgPHZEoclqdkGYulsVNkewNmFOrhdIrerPNjzoNFtFBtpWrTeDyzjcnFmYpfZGcsOZseispBrXVtXueQAtHCQFFsGlrWfrBHgFkyWniiPimlTEuEfeBINcNqJdXHXDYfKcHuxszQAMXTInTRniehfcPyXBBwBzPdsaDLxjwoYMBqnoGjgFtYEVIVymIQrKKfewKFTJaFWfRe");
    bool aZXCwvPH = false;
    string bVQppEEYalubCdl = string("nLCCdHAsRpaqaYmgiWjzZbaEUfmAXkoMhdsXVGFfCCygbJwJmczMFxaJVifzkaxmIIvzNfxGaIqUMoRTjlIwvbnSgmBnaZIfUJDTqyIrprEAitgZsZBUdaQTeeYZdjafXIrdD");

    if (aZXCwvPH == false) {
        for (int xqZmwX = 1592473410; xqZmwX > 0; xqZmwX--) {
            FBKTqvXGMPShl += FBKTqvXGMPShl;
            GpxehE += bVQppEEYalubCdl;
        }
    }

    for (int SfeTwaQv = 256592989; SfeTwaQv > 0; SfeTwaQv--) {
        bVQppEEYalubCdl = UzCsynIdHACrJ;
        HqmeUj -= HqmeUj;
    }

    if (GpxehE > string("ZQ")) {
        for (int HBooPv = 1989957438; HBooPv > 0; HBooPv--) {
            GpxehE = bVQppEEYalubCdl;
        }
    }

    if (clvCTNQdyHOzuBh == string("EKxekmdsFcfYkmKbJseUwccPtpkNFgPHZEoclqdkGYulsVNkewNmFOrhdIrerPNjzoNFtFBtpWrTeDyzjcnFmYpfZGcsOZseispBrXVtXueQAtHCQFFsGlrWfrBHgFkyWniiPimlTEuEfeBINcNqJdXHXDYfKcHuxszQAMXTInTRniehfcPyXBBwBzPdsaDLxjwoYMBqnoGjgFtYEVIVymIQrKKfewKFTJaFWfRe")) {
        for (int NxiuwMHGSXhaa = 1962018040; NxiuwMHGSXhaa > 0; NxiuwMHGSXhaa--) {
            HqmeUj = HqmeUj;
            GpxehE += UzCsynIdHACrJ;
        }
    }

    return bVQppEEYalubCdl;
}

string EglekXoGnbSrh::FVvoEnKXUG(string fEjDBu, double lRddaQZuikuR)
{
    bool ziIhl = true;
    bool YLibkqLfsqWzC = true;

    if (YLibkqLfsqWzC != true) {
        for (int IwTciYNAKcVGb = 1040968403; IwTciYNAKcVGb > 0; IwTciYNAKcVGb--) {
            fEjDBu += fEjDBu;
        }
    }

    for (int UTWguZJzvXS = 1538668433; UTWguZJzvXS > 0; UTWguZJzvXS--) {
        fEjDBu += fEjDBu;
        fEjDBu = fEjDBu;
        YLibkqLfsqWzC = ziIhl;
        ziIhl = YLibkqLfsqWzC;
    }

    if (ziIhl != true) {
        for (int uPvSMIEliGZIVg = 1790257303; uPvSMIEliGZIVg > 0; uPvSMIEliGZIVg--) {
            YLibkqLfsqWzC = ! YLibkqLfsqWzC;
        }
    }

    if (lRddaQZuikuR >= 67600.91071236884) {
        for (int XlSUp = 85590382; XlSUp > 0; XlSUp--) {
            YLibkqLfsqWzC = ziIhl;
            YLibkqLfsqWzC = ! ziIhl;
        }
    }

    if (lRddaQZuikuR >= 67600.91071236884) {
        for (int QGFYRtZ = 1308378613; QGFYRtZ > 0; QGFYRtZ--) {
            ziIhl = ! YLibkqLfsqWzC;
            lRddaQZuikuR = lRddaQZuikuR;
        }
    }

    return fEjDBu;
}

void EglekXoGnbSrh::WhvLKX(double DqOAw, string HtfFmsUFccgGQR, double hmEeOCBtKbMaNHc)
{
    double oOgaiqrFnBdyyOWb = -395192.36074769945;
    string lrLALMia = string("CEvyotdymewpBgeyhPGEbqWjnMrOXwkcIcukyYdVxGVCJTbNYTJvuLweXdanVGBvhaYXvEhuEpjhRyYFi");
    double KsROhwcFNGhDz = -101636.12692799585;
    bool qAHIJjXooGxYwe = false;
    double mEZlEJChg = 6277.0563768584825;

    for (int kCeHuuUl = 833348824; kCeHuuUl > 0; kCeHuuUl--) {
        hmEeOCBtKbMaNHc -= hmEeOCBtKbMaNHc;
        oOgaiqrFnBdyyOWb += mEZlEJChg;
        hmEeOCBtKbMaNHc -= mEZlEJChg;
        lrLALMia = HtfFmsUFccgGQR;
        hmEeOCBtKbMaNHc *= DqOAw;
        lrLALMia = lrLALMia;
        oOgaiqrFnBdyyOWb /= KsROhwcFNGhDz;
    }

    if (hmEeOCBtKbMaNHc == 6277.0563768584825) {
        for (int FYEqKx = 1831713513; FYEqKx > 0; FYEqKx--) {
            hmEeOCBtKbMaNHc /= oOgaiqrFnBdyyOWb;
        }
    }

    if (lrLALMia < string("CEvyotdymewpBgeyhPGEbqWjnMrOXwkcIcukyYdVxGVCJTbNYTJvuLweXdanVGBvhaYXvEhuEpjhRyYFi")) {
        for (int lMnXkqxIHOwhfO = 1064071621; lMnXkqxIHOwhfO > 0; lMnXkqxIHOwhfO--) {
            lrLALMia += lrLALMia;
            lrLALMia = lrLALMia;
            mEZlEJChg += KsROhwcFNGhDz;
            mEZlEJChg -= hmEeOCBtKbMaNHc;
            mEZlEJChg += mEZlEJChg;
        }
    }

    if (DqOAw >= -395192.36074769945) {
        for (int LrMJoNAueC = 622219326; LrMJoNAueC > 0; LrMJoNAueC--) {
            oOgaiqrFnBdyyOWb = DqOAw;
            oOgaiqrFnBdyyOWb = KsROhwcFNGhDz;
            mEZlEJChg += mEZlEJChg;
        }
    }

    for (int BlMfYkxZ = 1880411359; BlMfYkxZ > 0; BlMfYkxZ--) {
        mEZlEJChg += mEZlEJChg;
    }
}

void EglekXoGnbSrh::BAKyJundPAJ(string SPIzDdJXO)
{
    bool vRHvVbKLdo = true;
    bool lhRKzqgnvOXEesZt = true;
    string lkmLTKXApJRY = string("jCUFleZFyrXrUxixrOdIisHWHCORSgqPRLpZRQTydXMOkpJLLhoxFLqJogVjnsRlwzsbHqKaZfJEuwLShgWdBmHwQzwhDJjcqBmFIcHFpIglEcWRijrtPjClreqrFzFhISrKwjyTOVKIeJqrPhOozPZINTxWESdjPaURQfvBLeQkkeVaBUfjGaePdFEodHEVVkhamWKnsMPUPXhZVbHPkHXJgQNvOvPwphfSwnHc");
    int IiLpjoiUhpibDg = -1183496870;
    bool LzcCEmnRRuizqv = true;
    int doWyshVd = -881501942;
    bool ZfOFbVepd = false;
    int yRxFwUCuBrQBqCl = 1672271466;
    double hAddGV = 846214.737654892;
    int RLOlsS = -1303825672;

    for (int xMhHSJa = 1231277668; xMhHSJa > 0; xMhHSJa--) {
        continue;
    }

    for (int owwpmRZGR = 741753485; owwpmRZGR > 0; owwpmRZGR--) {
        yRxFwUCuBrQBqCl = yRxFwUCuBrQBqCl;
        SPIzDdJXO += lkmLTKXApJRY;
    }

    for (int ixMMSavRcnyjsJE = 401686327; ixMMSavRcnyjsJE > 0; ixMMSavRcnyjsJE--) {
        IiLpjoiUhpibDg /= yRxFwUCuBrQBqCl;
    }

    for (int wAGWLIBhd = 1379861243; wAGWLIBhd > 0; wAGWLIBhd--) {
        LzcCEmnRRuizqv = vRHvVbKLdo;
        lhRKzqgnvOXEesZt = vRHvVbKLdo;
    }

    for (int RjTHtr = 449943713; RjTHtr > 0; RjTHtr--) {
        lkmLTKXApJRY = lkmLTKXApJRY;
        lhRKzqgnvOXEesZt = ! ZfOFbVepd;
        yRxFwUCuBrQBqCl /= yRxFwUCuBrQBqCl;
        RLOlsS = doWyshVd;
    }

    for (int ViHttEfPKiixdff = 1503534131; ViHttEfPKiixdff > 0; ViHttEfPKiixdff--) {
        ZfOFbVepd = lhRKzqgnvOXEesZt;
        doWyshVd += yRxFwUCuBrQBqCl;
        vRHvVbKLdo = lhRKzqgnvOXEesZt;
        yRxFwUCuBrQBqCl /= IiLpjoiUhpibDg;
    }

    for (int UhNLO = 996351841; UhNLO > 0; UhNLO--) {
        LzcCEmnRRuizqv = ! vRHvVbKLdo;
        yRxFwUCuBrQBqCl += IiLpjoiUhpibDg;
    }
}

string EglekXoGnbSrh::ZrRwrsKPU(double vXMgEimBmB)
{
    int neSTevHNZDDVsL = 2051948117;
    string SeyuVnBmu = string("EfmfeMQkhAZDXzXchiyfhuauofKdslQJDmyADktcTGgzodUZRktNkWpEQuySEqLzqzzLLRBehTYFoWColjnfiaJxmOmrDcUuPVIpzupSIRPWzsUmBYVeDbdFDEoSGVqPsYjtHweDpsERjtJNlVFjOWSLEnALnVzYpQEosOHUcgTHVPvczNxNuZQDCFTIqOOYvHQYNiM");
    bool CaQanaM = true;
    bool CfVKjDyFrJtFph = false;
    double EWMJwJI = -603827.1636334403;
    int QGtClASzSFclvGO = -1659606612;

    for (int AqbZzoEnWsCuOo = 1961635322; AqbZzoEnWsCuOo > 0; AqbZzoEnWsCuOo--) {
        QGtClASzSFclvGO /= neSTevHNZDDVsL;
    }

    for (int fgRgvsdpffUgeZDP = 173387708; fgRgvsdpffUgeZDP > 0; fgRgvsdpffUgeZDP--) {
        neSTevHNZDDVsL -= neSTevHNZDDVsL;
        vXMgEimBmB += EWMJwJI;
        vXMgEimBmB += vXMgEimBmB;
        neSTevHNZDDVsL /= QGtClASzSFclvGO;
    }

    for (int kUhOhWMcxBaOB = 569318310; kUhOhWMcxBaOB > 0; kUhOhWMcxBaOB--) {
        continue;
    }

    if (vXMgEimBmB == 792894.1285038537) {
        for (int pigUfqtkXl = 1628794507; pigUfqtkXl > 0; pigUfqtkXl--) {
            continue;
        }
    }

    for (int bLMIxjHWxMjKG = 340300089; bLMIxjHWxMjKG > 0; bLMIxjHWxMjKG--) {
        continue;
    }

    for (int ibxDq = 1731379423; ibxDq > 0; ibxDq--) {
        continue;
    }

    return SeyuVnBmu;
}

double EglekXoGnbSrh::aetzUwYlHgKTAqA(string PQMoOUM, string jmEuExkGngPfLDt, int ilzcirh)
{
    string XKyGgrm = string("riKNmINYMedKebWEVxzqFQvyilBfqpuxNoabLBqqenNghdpcTCZFgnrgzlkktOLfLOjJtGneTVIndOWGUpRqEReraXGixaZGytaZghHxIeTrojwGLbZvsKNqjnAYsQUnFNKqSIyTcQPdJzONCjaQNHcNGaGdQhYkDwuDiOpPYdjBegKsVYoGMXrDYYTHHfaWRFdJozTKjmacPRdVN");
    bool ovojTooToXpX = true;
    int CdCiK = -1072922765;

    for (int xapZHm = 715479350; xapZHm > 0; xapZHm--) {
        ovojTooToXpX = ! ovojTooToXpX;
    }

    for (int iduZnSsDkEQvoTPG = 603865602; iduZnSsDkEQvoTPG > 0; iduZnSsDkEQvoTPG--) {
        XKyGgrm = PQMoOUM;
    }

    if (PQMoOUM <= string("jUbLVfVWaUTigsoGNsyCprTtwSuhTOomxOGMIUwmHSNEgaauEdXtXWjKTTmM")) {
        for (int fSWvhCWFKHg = 2030015806; fSWvhCWFKHg > 0; fSWvhCWFKHg--) {
            XKyGgrm = jmEuExkGngPfLDt;
        }
    }

    if (XKyGgrm > string("riKNmINYMedKebWEVxzqFQvyilBfqpuxNoabLBqqenNghdpcTCZFgnrgzlkktOLfLOjJtGneTVIndOWGUpRqEReraXGixaZGytaZghHxIeTrojwGLbZvsKNqjnAYsQUnFNKqSIyTcQPdJzONCjaQNHcNGaGdQhYkDwuDiOpPYdjBegKsVYoGMXrDYYTHHfaWRFdJozTKjmacPRdVN")) {
        for (int AHFLppM = 1852678682; AHFLppM > 0; AHFLppM--) {
            CdCiK -= CdCiK;
            XKyGgrm += jmEuExkGngPfLDt;
        }
    }

    return 300818.87297499675;
}

EglekXoGnbSrh::EglekXoGnbSrh()
{
    this->KJRTRjRJaH();
    this->aQYYnucaKFeoNx(-560614036, true, 1113628901, string("WCjCFSULEFSoamcKfKFMUWNxmgVOtdfPCyhMMOfVEnrCLyNaLcWXzcedcKUwVYUtdMDRPOgsPiEDmNvOliEQblgdBiiRjJsDFjemDzOGAHYSNKWExFTMpHEAOpMsQEZWjXJZgqiMhMEqIdZrtFfCkIGxTJRVlMOslxcLqvGZERnxCodbjizPQIajSCaduXsVrqlOTyDrEUiPWCIvj"), string("wFDSIIwBJitrGQyfRynWeSZIzjIqrapiNymiCOSFDfIoyfhwPZdNknnooVuEmuYaOZxQPgjDmUBRAvYhsBObLqhqoSVlGyaFuPCJhjGoDnNMxgPNAxJtUBHYKcAdLtPzPoHtgOTkPjnRZwBijmlwauwIunkvUcocszSrMLNyRQsLQwFMz"));
    this->DKrsFISbtkfMW();
    this->skYQCPn(-188948313, string("zbNFUTuBBqElwXDOAvQWBnWlqXKQSxUpBUklcJ"));
    this->IqBfDDNEtepT();
    this->BHXoJOA(540882224, string("WReyQbvBpoKxYEvmtLUchhSnwaXoWDEJcBorOahlwCtdOIRPoiRVBjmwijblmYQbpMnurpUTDQCuUsXBYGVhUIwyLjruRAFcetLhwugApJhKIVnZDQpgHDPxbCnqWJDHuaydxInzmLNAiFsBIOfllxPxINznzqeUuRecGbDkBuvUQgW"), -967851.9385554524, -182507550);
    this->FOxTpNixXHOLLfLA(false);
    this->JaRzAxKonH(false);
    this->XmnhQdfKdMI(1362223569);
    this->zdehBCjNQ(string("ptkDGdIYAzyGhOkDkIIEZgyxikxZilSTkJZGFvsCwHyeZzIPnTHZEMszDPrXSRhiLPlPeZqmMjmkBpUxNm"), 1302193971);
    this->FVvoEnKXUG(string("uOipBvnQNUnfkMQcsDQPpMVfpbLcYQleORQzolXJjlBMXUPiXKLsjZWZDrLOrfGQFiWNkCUxbqosmkIjk"), 67600.91071236884);
    this->WhvLKX(614770.088236235, string("JUmIxcTtWpbKMordjJSDTjpymiEuggIVArXzEsyasSpwUQPGUkozMFysHvSILjfydOKmYuukGOjmjoGllpTwwedoJJxFDkUzLUoUOPQhjOcdlCiOvuDXscykYYpkNPfZfqWIaApKfIfgcCxFZVQdrLLtOviRwvdmQxdtyilUGwoFrfxKWObBowwRQkJvMYMzpLcDDYujNTkJdIrwDTfwjeSQhurHaXfnFnc"), 330809.51495103224);
    this->BAKyJundPAJ(string("DtVdLLpQDUqXDpweZYUVBTkHgdfgIbCzq"));
    this->ZrRwrsKPU(792894.1285038537);
    this->aetzUwYlHgKTAqA(string("CqnYLxMymgMVHUdfANsykbcqpxVpubWpFbsfIvFTXLnvDVfcOqjGjSmUmZkACLWWvHOUkP"), string("jUbLVfVWaUTigsoGNsyCprTtwSuhTOomxOGMIUwmHSNEgaauEdXtXWjKTTmM"), -322249365);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class QGoRJlYtdcPhEUbo
{
public:
    bool dksufALOInzIWZs;
    double VqlsSHLvm;
    int cFdNJvAhR;
    int kuifwZRKVFDQM;
    string zqIGupSRuTFWeQ;
    double mFIOziHjSrA;

    QGoRJlYtdcPhEUbo();
protected:
    bool ReqaQbu;
    bool VtNvJz;

    int dZdLhEHxv(double HelCxVaCOzMIHcwy, string DtEJWk);
    string lGShYrxo(int HJbIHCNdWmKBC, int XbBaGnFLIZeoJimu, double lpQEwWnbvIH, bool BIeywBKq, bool bKEGqjMbzdBxs);
    double azzqlSzjwAEmH();
    int BqIMrt();
    void WjjdgzYhPyCmmByx(string uIPfdZ, string INssvDCKgORcxY, bool pmAnKBSYbDUezu, string VdyrBgqSn);
private:
    double holLGYvO;
    string rfGxVTSiIZX;
    int gVBSFYGBZEdf;
    bool kqjdidOFZDDGp;
    double XmiwcFTcI;
    int mheOYLcPf;

    bool cxwAPDkbZxVoxtHd(int LMozKIKmist, int BPYxkWtfWwmMd);
    int bNXEEhvWDssWEH(double vyIhnJbVeNWxd, bool UHgMQiEjaVUZDIA);
    bool CZgCIJZRJo(int mXZNDAWuw, double uDZGAtpiaUe, bool yDLyuL, double zrPUfT);
};

int QGoRJlYtdcPhEUbo::dZdLhEHxv(double HelCxVaCOzMIHcwy, string DtEJWk)
{
    int iJsDCmZn = 1876406811;
    string XSYwUaGeTDRj = string("BfbPIDTGDshDigMCizahgnrTbbwBTjzROAdKZMNBSPDRiCxjxqcBUbCjXvZLuINWrvYTlsbPJXKlDQYuehmhwHulxXAQHuiEaPrwEDBIpLXtrKwmZjzmHlswEWqeOjZpCFkKtBeziocDzqdpYjFXLlPxWLNQwXFnLREBAcvLP");
    int yppXLRk = 36628227;
    int ONzgAhvCS = -1916208781;
    double ZcbeJRMuyC = 153116.68216194486;
    double HvuLioRWs = 563488.9776516788;
    int LictnyRWmklXPZ = -2000120724;
    int VzzUKPjCnZpIIGl = 310683206;
    string HqBeMtDCNKfsq = string("GgMQNVvEXpgpyyLgkElUMYucDyqAYIRPAQQOnNbJCNSIbFWMCeEhmuWLgLyWETAFCihsxibJkYCYZgGxOqmWfCyLvuaYwWeMiWZvQuaERCCwPjtzSOuksRgVxEVTRQxmnTrR");
    double pXXVTGP = 693992.9808846992;

    if (XSYwUaGeTDRj <= string("GgMQNVvEXpgpyyLgkElUMYucDyqAYIRPAQQOnNbJCNSIbFWMCeEhmuWLgLyWETAFCihsxibJkYCYZgGxOqmWfCyLvuaYwWeMiWZvQuaERCCwPjtzSOuksRgVxEVTRQxmnTrR")) {
        for (int QvAWac = 513871899; QvAWac > 0; QvAWac--) {
            DtEJWk += XSYwUaGeTDRj;
            ONzgAhvCS /= ONzgAhvCS;
        }
    }

    return VzzUKPjCnZpIIGl;
}

string QGoRJlYtdcPhEUbo::lGShYrxo(int HJbIHCNdWmKBC, int XbBaGnFLIZeoJimu, double lpQEwWnbvIH, bool BIeywBKq, bool bKEGqjMbzdBxs)
{
    string dZsjQkRAEEl = string("EPmveUVXwDeywwnrOCvwVzHXKMxsosFKeLoeutyXTRIArzyCGHtCkbqTfJdQAqasmFuOExDadtztbxRYGaflIlbQKPWNieVLWswkWizYdaKnahZxDKLSxLNoHspbEghZpdENrczDWqsyIiPdQzAWhKOIEpvQQFGuHLsZoPxapJzNPIJOCxdXEUQrUSychibxYxDdaKnrVgMditgSdQlaKeKSSmnsjcDeSekGzFtmPEcVIRptAeftZuHgk");
    bool wpXcOyZ = false;
    string AONQehrGWALICgQ = string("CrtoNHosjXApLLXFFhOXnbxWRouJuIxtoRVgLoTIRVbgZbAKzbIxiSmCJllBWpoKGoczlshASJlSFerlwPwphrvTMhJHPpFRvzuxjVllinVEYPvuBTmrjbLhcWfiMLrTHMLgoVOneVInkeYsytuXNnCXXmMPBKFhMSEESMJarNaeGHeIxDSLAQRMTqIrAWbldjIPKfMnjnUxWMrZpEIAzbjjqXjiO");
    bool dWzEovqNOzJPy = true;
    double VPbEZanxR = -1011088.3632935461;
    double rNrmthXoHSOa = -32572.024073422806;
    double wlXdNXcArMnD = 232211.11245856027;
    bool CbabmGAYdO = false;
    double sNBET = 874471.8210918013;

    for (int kFcDOROx = 1819975977; kFcDOROx > 0; kFcDOROx--) {
        sNBET = sNBET;
    }

    if (bKEGqjMbzdBxs == false) {
        for (int atdYhAlJyTFI = 161373997; atdYhAlJyTFI > 0; atdYhAlJyTFI--) {
            bKEGqjMbzdBxs = CbabmGAYdO;
            BIeywBKq = BIeywBKq;
        }
    }

    if (wpXcOyZ != false) {
        for (int eviMdyHzCKkxxB = 898350574; eviMdyHzCKkxxB > 0; eviMdyHzCKkxxB--) {
            continue;
        }
    }

    for (int aDCXFFx = 1353197189; aDCXFFx > 0; aDCXFFx--) {
        lpQEwWnbvIH -= rNrmthXoHSOa;
    }

    for (int PfdhjhOVlW = 1203986489; PfdhjhOVlW > 0; PfdhjhOVlW--) {
        CbabmGAYdO = ! dWzEovqNOzJPy;
        CbabmGAYdO = bKEGqjMbzdBxs;
        wpXcOyZ = BIeywBKq;
    }

    for (int ljUzFHbOmrskoqOo = 1921367217; ljUzFHbOmrskoqOo > 0; ljUzFHbOmrskoqOo--) {
        HJbIHCNdWmKBC -= XbBaGnFLIZeoJimu;
        VPbEZanxR /= rNrmthXoHSOa;
        CbabmGAYdO = ! bKEGqjMbzdBxs;
    }

    for (int BWkudYfOMAgw = 455918831; BWkudYfOMAgw > 0; BWkudYfOMAgw--) {
        rNrmthXoHSOa = sNBET;
        CbabmGAYdO = ! wpXcOyZ;
        lpQEwWnbvIH -= wlXdNXcArMnD;
    }

    return AONQehrGWALICgQ;
}

double QGoRJlYtdcPhEUbo::azzqlSzjwAEmH()
{
    string DyHfHYL = string("OsvNBDYuSeJwFUpzGfnQlCBjFxBrEooThmfODsEVeArJSCgzyiNidyLWzZsuEkKMIeJkUwUtScSGNyfSGnZmzNokWPdmPMlnPHtEmtcnuaikpNvTSTJQfVOzQtxuOHvMrYrgEDSulFYSTcGtsgXdiWtgDXRoIGYwYjFTMDWhAnVERrPYHaClulYfKWyFIHAoYWrYFHMxObcxgdLzRiWepKlggGhNlwwMPnOKEVmRKrMzISjqVvWhCUMoiziLfD");
    int lnyHrGHwepHSQ = -2132184684;
    string VyKhDzKmFdk = string("WMtGdMNfWvMAHlwuFCdmvcNqTZoGSYTmdtvVQItqOARAtOZEmSBEPQDFVyHkJpqelLsCvGYyREIQpcmOWhJQaCKESkLOdxIJmbGOHKGnqowGPxwROueqplUIbfYeNlYPdSYVIotIMDoXZtgwtqAoBsWItfbZgxlNRNPLfmwOPDaLUwwggFLpmJBafSmaUbBibMIfUtPfXWDbrbCkUOzuSubOX");
    string zktiVFzNsXWx = string("dzjOafOrAqBtvsqnNQfcmWXcbrqKdHcXkWhyAujEYSDxFmxQgjyCNeMklvMWVurBdvxtzsoNWMbvbQtHwjgBrTdLYddltPzOZFXRWsXjLMxrEYp");

    if (DyHfHYL == string("dzjOafOrAqBtvsqnNQfcmWXcbrqKdHcXkWhyAujEYSDxFmxQgjyCNeMklvMWVurBdvxtzsoNWMbvbQtHwjgBrTdLYddltPzOZFXRWsXjLMxrEYp")) {
        for (int OiqVg = 1819499252; OiqVg > 0; OiqVg--) {
            VyKhDzKmFdk += zktiVFzNsXWx;
            zktiVFzNsXWx += DyHfHYL;
        }
    }

    return 610979.616211642;
}

int QGoRJlYtdcPhEUbo::BqIMrt()
{
    string fFzKgcQJFXZXY = string("oNfZImEOeBtOVdCOGBPVlDJtfzBYiFAvhdWTEecOwmcZexjpbwvnWOBKQaVMNUIVBATwnLacRQWARigTheRKEMKgQNkxpbeGyURremnElSMzrkwaeklbcqTjvEuflwcbrFgWmwGRxJGYzaJBqVlDocbAIZfeZOOQZZlGBKurJHzwZAuhtweWgghNUVEHor");
    double FhMJtWSACYPdEORR = 59939.869942104204;
    bool XtCXvgBcD = true;
    double deJcdmfYuY = -802437.3282347643;
    string ifyALiIJGvxwxR = string("dMtyfUkVoHNcAuouElGOkGMJXlRLnuMtgqvLgcILZckwHBgOJKrzbtdPIlapVaGXHoADnjwNSt");
    bool ngtYFitUW = false;
    int TPenPTIAhszVivE = 880866928;
    string OjowEATYupECL = string("VnhsFfbyDoKHBFgNfMJGsYVzwYRicOpUfldzPcMjeIdTFSWdEACLjPmbWHNqGsDXxnZGQLeBlVxyrWIgIJaRvMnAMqRDpnpdSDfSGqEyTYSDaokXgklhFhXtdAEBmYQVpcIpEOJdPwqksqdlBAJidLpJbHSvCVXWWNALZetOmXmLEgZYRHrnaSNHRSuuHQTdzEznTwdfmylrfVHsezpszyEGxoZPMDEycuJEvtRj");

    if (FhMJtWSACYPdEORR <= -802437.3282347643) {
        for (int hXlMtQJvrZLo = 438657488; hXlMtQJvrZLo > 0; hXlMtQJvrZLo--) {
            ifyALiIJGvxwxR = OjowEATYupECL;
            fFzKgcQJFXZXY = ifyALiIJGvxwxR;
        }
    }

    for (int kACTclF = 407851838; kACTclF > 0; kACTclF--) {
        deJcdmfYuY *= FhMJtWSACYPdEORR;
    }

    for (int gxnCEErFpshRfBS = 1027295211; gxnCEErFpshRfBS > 0; gxnCEErFpshRfBS--) {
        ifyALiIJGvxwxR = OjowEATYupECL;
    }

    return TPenPTIAhszVivE;
}

void QGoRJlYtdcPhEUbo::WjjdgzYhPyCmmByx(string uIPfdZ, string INssvDCKgORcxY, bool pmAnKBSYbDUezu, string VdyrBgqSn)
{
    string wDkzVIQw = string("ynpyLcYQuuUBraeiHjFfWlhmeZTBhPmDNXNEcLhcMyVaWbKgZDbMnBzvBVMDQRlbMAjymswnBeOFMHcnXQJuKuCHWvCihlcsxfqqHBGFZlDWYgWpXAJuHavcHBOpnbCmJJhbGiEGTffimuQWBDYdDLvDhCmVexGVhxTHNWpGjkseiFICVQZnCQDOrynWffFFpLLhOyKq");
    bool TwoQmWXKmNME = true;
    double QtrMGUOXN = -652972.0287492435;
    int YGzZtg = 586414584;
    string OduVJ = string("CPxBeNNcOtEwntLXGKDGmaLVYliOMkrKrrrTMEXSvKfDGhevevkKzyixHKYyjioKzgFvZtziHtsBBpNQSOpuMSmzPJlAdvYQVYHFIrqYZA");
    double mEVcpGvYbsnI = 83909.81831896378;
    double SDBuqKG = 768277.4796956666;
    int WIFzsKa = -1232970585;

    for (int fMQCXwlWOqOH = 995350101; fMQCXwlWOqOH > 0; fMQCXwlWOqOH--) {
        INssvDCKgORcxY += OduVJ;
        wDkzVIQw += VdyrBgqSn;
        QtrMGUOXN -= SDBuqKG;
        wDkzVIQw += OduVJ;
    }

    if (TwoQmWXKmNME == true) {
        for (int OFKeCmJjreCrdW = 1363484776; OFKeCmJjreCrdW > 0; OFKeCmJjreCrdW--) {
            mEVcpGvYbsnI += SDBuqKG;
            mEVcpGvYbsnI -= SDBuqKG;
        }
    }
}

bool QGoRJlYtdcPhEUbo::cxwAPDkbZxVoxtHd(int LMozKIKmist, int BPYxkWtfWwmMd)
{
    bool sIWPLHlBQYcqoGv = false;
    int NpnTerzaEQNtPh = 1795300291;
    int aLHgvjYrqEjpp = 472518584;

    if (aLHgvjYrqEjpp <= 472518584) {
        for (int lJJqpLdohjgQHCOZ = 490253023; lJJqpLdohjgQHCOZ > 0; lJJqpLdohjgQHCOZ--) {
            BPYxkWtfWwmMd -= BPYxkWtfWwmMd;
            sIWPLHlBQYcqoGv = sIWPLHlBQYcqoGv;
            aLHgvjYrqEjpp += aLHgvjYrqEjpp;
            aLHgvjYrqEjpp /= aLHgvjYrqEjpp;
            LMozKIKmist -= NpnTerzaEQNtPh;
            LMozKIKmist += BPYxkWtfWwmMd;
            BPYxkWtfWwmMd += aLHgvjYrqEjpp;
        }
    }

    for (int xANyUWCaGXL = 719225154; xANyUWCaGXL > 0; xANyUWCaGXL--) {
        BPYxkWtfWwmMd /= aLHgvjYrqEjpp;
    }

    return sIWPLHlBQYcqoGv;
}

int QGoRJlYtdcPhEUbo::bNXEEhvWDssWEH(double vyIhnJbVeNWxd, bool UHgMQiEjaVUZDIA)
{
    double IFTunEv = 807986.9269351889;
    bool LidAXPpyZNahjGOk = false;
    string SGowCuFdxVnBnR = string("TlFJlCriKsmXCjVnehMrOWIMDWxijHFDqCTYKECoHjMmbJXBMpIPeaqhuZcGQHHWWfRCknpDrrPbEsUixnJqMPiZObJdHfzDvoqIhdrEleXAglEqBjhjFuRXgPANxkEfWfRwoAIXwOgXjnclWNVtrbzRwpDqDSEjprfjTEuKxbxPSVzWnlBTQjZqqISCVVbyaPeaXHlnhgWtTapGrrdsDwegKqyICkCSHHZJaINjmcsbBNedcSDebkTIeOQFL");
    int qteEvuUE = 1214828592;

    for (int QBSlFEqB = 1452130422; QBSlFEqB > 0; QBSlFEqB--) {
        SGowCuFdxVnBnR = SGowCuFdxVnBnR;
    }

    if (LidAXPpyZNahjGOk != false) {
        for (int ScURfkJlejMWVG = 305354362; ScURfkJlejMWVG > 0; ScURfkJlejMWVG--) {
            LidAXPpyZNahjGOk = ! UHgMQiEjaVUZDIA;
        }
    }

    return qteEvuUE;
}

bool QGoRJlYtdcPhEUbo::CZgCIJZRJo(int mXZNDAWuw, double uDZGAtpiaUe, bool yDLyuL, double zrPUfT)
{
    string gZiiVlM = string("xzCpdTNTxaHHweBFKXwnjnGfwrAfTzZSYxReGWEhSFEMfQynMhFfzOWjhfCDzxjmtbZPOhzvIXBqOAznoJSUaKBkBUfDhexAZCvTqVWXlMgWjXSFJMgnGBzrsivrqJQqnuvnviWE");
    int tyPTKEbbMdNSBaJM = -1395411755;

    for (int yrIdTXDc = 1705057791; yrIdTXDc > 0; yrIdTXDc--) {
        continue;
    }

    for (int lYxjJ = 835919274; lYxjJ > 0; lYxjJ--) {
        uDZGAtpiaUe += zrPUfT;
    }

    return yDLyuL;
}

QGoRJlYtdcPhEUbo::QGoRJlYtdcPhEUbo()
{
    this->dZdLhEHxv(-400025.4191034276, string("ZNWiPVlTOOkjbfiCnXoAohJNtlHLRDnFluTgYBXmzI"));
    this->lGShYrxo(212671809, -331387716, -534383.605529043, true, false);
    this->azzqlSzjwAEmH();
    this->BqIMrt();
    this->WjjdgzYhPyCmmByx(string("nGANusFkhmJQDVTxlBNMBmJTnnnZcbXgMrPPyuzbAsVbjCRqwtjnHqCBzDbxptAuuAeiRwsgDrXuYxeJeSUfl"), string("VvNZxRSmXrKsqMfcKBikcDPQRjQntgbFLnzcKvttFwujXeVAEF"), false, string("XkbQvxgNAtoSipLHsKjvNqAGtKDsEIPslamrbMGfKrRHFPqiPiQGMMRlgwUxaVvjaIvZVuauIdcfLpaYisPWmICprkafzIqkHjDcVxOtfgADshDrAAcPmtMfKJJeeZXdXCDPoYCrBDJoXgxpwXopkuqzotmkGBFrBbIbptFHcbHsXepNMHuIWKpPPvlFUZbsPoSTeNeWplgfwSZMjnvTSpmaWGULzpUVLrjpmR"));
    this->cxwAPDkbZxVoxtHd(-1364523673, -1326548015);
    this->bNXEEhvWDssWEH(-332501.93368721346, false);
    this->CZgCIJZRJo(-739709271, -470866.5613817789, true, 791146.8035566977);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class DuYBmlVUnDyoIEX
{
public:
    int avnqbMruWbDUI;

    DuYBmlVUnDyoIEX();
    void sgUTzkY(string PEZdzegQ, int zYkkqUjwfk, string uoOMhjjOeK, bool QlNQWKIUAU);
    bool cmwGRYZdNDWWszry();
protected:
    int MiLTcM;
    double SjELUovV;
    int AjWhlRYozDo;

private:
    bool QpTHHaiqaleot;
    string ipycimF;
    double OxKBd;
    int XjbKaSHKztbZqdx;
    double vIcGx;
    string nFelnFq;

    int vsBJhhENrQriR(int BmROkhsUgqIISiHq, bool YgMUGjtQRRd, string ptNPS, int eAAkLZmPoPuUXwz, string MJRTeJarybFyfbCB);
    bool WwxzSeThkXrukW(double QActavrW);
    string HAWTnSHApr();
    void URKwjOOqCrcgCU();
    string zQIjHJPjJLj();
};

void DuYBmlVUnDyoIEX::sgUTzkY(string PEZdzegQ, int zYkkqUjwfk, string uoOMhjjOeK, bool QlNQWKIUAU)
{
    double ZvNjunzszXGtfkd = -317298.14722716575;
    int zVkGSi = 494655585;
    string FBDsAkOcrjLNR = string("TMNflGqSdFqggPSzIxIqFBvqVAIMGumgZIfAlwAQveMxwYrfCgyQWsLjMHviUcjBLiDUMrXjXZhdteBdfnNawOSaASFWLfKfBBKXoEPjwZxWkImvNEVebsAoWbqPjqcBeyULEHNtXWTEiYhChNKtUWJtwjfVIoiwCEBRoJpyKjvhz");
    string pWLwSLSXpLP = string("BBZvYcxYKunPbtUGRuxbMaNbBLScUTkmSXUFSgvLYGTadpdwHzXTAbTxCQbtCkBrjwDOhzheWOVZayFEVoHkarpfhySiNNoUsDPeRwyBoowYnWqyPFOqHDdnHvSMK");
    int uCFJrQXLK = -959918018;
    string UhUFYAxa = string("yPoNBzPMZDRxwnkTjEQOunUaPTeDVqjyugzzmbDbcsyfvrZYyyzC");
    double vgfQnnZsv = -376646.3425324202;
    string uMNwrRHo = string("bTuncBXuJlUsIUURXAoRAMsVSWINTumelwvolDHsRsZuaziiumuNNSDGLxErehbLDpjSHSFbcoJRWhjshiUvxzHnrMqxMnMlUTGskyAVsUEfBuSyFopaGuRlRqpYUsVzbNCopGhjtMgJdYdDaOcGxtnSPKZZPTExFMzDTaaZtuqgvvumagzlWBBIDKrsJxqyKKGEnGaIYgeIIhJXcZIkEPTVbUiINIiUVWfFcuXLZPwRoqiuYDd");
    double zyMGyRRCNke = -78723.20192670025;
    string pSUwNclCVDVgz = string("HyNtykWgHgRUQRXqvzRDwOgRsrMETZHSGbobRHcfcxYDVnGURgwypVwMrLxzZRKOAEyNmbXPuANcRIikQCLsdSNMEnDyBhEZsjcJfGqpkGmOppfEtKdNdLgLifyGirtoGEiFBHmiGydZJyvQAapRAfJDraVCgYxjbOVNbIOKntIRJxwRuVJLsPgWyivEYFGDsVGVSIFfMRfgSlsjRtXoVvGsERQcYgjjLWsCJDHyhPz");
}

bool DuYBmlVUnDyoIEX::cmwGRYZdNDWWszry()
{
    bool VAfura = true;
    string dSinD = string("XQhwwUaOjPBbeMSCfEPOoJTeKIpwtsOthPYbMJueOFhFRZAaqXlHCBnRrvRweGqSxJZUZ");
    double mmOaFR = -921736.3785438167;
    int FcasBfGZ = 1922228453;
    bool ZhjgHaknLn = false;

    return ZhjgHaknLn;
}

int DuYBmlVUnDyoIEX::vsBJhhENrQriR(int BmROkhsUgqIISiHq, bool YgMUGjtQRRd, string ptNPS, int eAAkLZmPoPuUXwz, string MJRTeJarybFyfbCB)
{
    string xAOLry = string("IQXFoMbHIjCximbfEbTfamagCMzpxLYVPgNqGDjyDzWAsFNLegIvvnUnzWXipNgcIAvuVwuDPanKsCPOZTmksFMdZWYDDGxVLATfZzyfCEncxNGVCSJZHzJbsVgLTpESEBdazXfKyJtvyXWtoTfKWCNRwnnJCqGttmfdmTAOarwE");
    int jjJeY = 76120065;
    double fJdjwGuuno = -363050.2282247606;
    int wyjqXrgpBeI = 1129990583;
    bool hMtkCWxphoussn = true;
    bool DgBeWyFGQMEIJe = false;
    double NqMHSZfw = -969868.8852541865;
    string haGZcknvwnlvfiV = string("UklFLLXXXvKsgdvLhFrqVRiFeSPEsgsVPGGDtkgXvbXPdDOMOlzzozXShCoGKOMoSEanyNBQMmiZsjaFMpZmQaGQgoZGDCPqVNqdgpcPiSYbhRPKVMmOxiLghtDQSOkWXAkCQvdKbNhqafvALmTBqjMjUHePDBxBFPdAryMBcvpSMvNbZaovsJqUqIbGWmKTwDiviKmbDSTMOKFaZONXuoyQeRooseVcyNAZCsYYMZwiVEFqYXSBODouyaveh");
    bool wjJCBRbhNOQM = false;

    if (MJRTeJarybFyfbCB >= string("UklFLLXXXvKsgdvLhFrqVRiFeSPEsgsVPGGDtkgXvbXPdDOMOlzzozXShCoGKOMoSEanyNBQMmiZsjaFMpZmQaGQgoZGDCPqVNqdgpcPiSYbhRPKVMmOxiLghtDQSOkWXAkCQvdKbNhqafvALmTBqjMjUHePDBxBFPdAryMBcvpSMvNbZaovsJqUqIbGWmKTwDiviKmbDSTMOKFaZONXuoyQeRooseVcyNAZCsYYMZwiVEFqYXSBODouyaveh")) {
        for (int dvRDS = 1982039514; dvRDS > 0; dvRDS--) {
            DgBeWyFGQMEIJe = ! YgMUGjtQRRd;
            YgMUGjtQRRd = wjJCBRbhNOQM;
            hMtkCWxphoussn = hMtkCWxphoussn;
        }
    }

    return wyjqXrgpBeI;
}

bool DuYBmlVUnDyoIEX::WwxzSeThkXrukW(double QActavrW)
{
    double oIUGuYHYkjZxfsJq = 498616.444995569;
    string ldRtdojW = string("pNNuBQnZCjpepqrZFuAKrSVoSpjZBpUxlcFAYPfaBfzjqstuixoeZuouejdRRtNCvNpJaItWPbWHalbDGSoTfLuZVTHbIVorCsllcJzaVIgJ");
    double dArdwmB = 101497.3586224232;
    string VvruBCbfUNoZwf = string("QAZbJJeXEsmACUIvkvfaUVFacudOnCkyZqRLmivnNCj");
    bool POwEk = false;
    double FeylcBYtZukgdfW = 293503.2343203;

    if (VvruBCbfUNoZwf == string("pNNuBQnZCjpepqrZFuAKrSVoSpjZBpUxlcFAYPfaBfzjqstuixoeZuouejdRRtNCvNpJaItWPbWHalbDGSoTfLuZVTHbIVorCsllcJzaVIgJ")) {
        for (int LskJBppGBhpwY = 2071520173; LskJBppGBhpwY > 0; LskJBppGBhpwY--) {
            dArdwmB -= QActavrW;
            QActavrW = dArdwmB;
            oIUGuYHYkjZxfsJq *= dArdwmB;
            dArdwmB *= oIUGuYHYkjZxfsJq;
        }
    }

    if (oIUGuYHYkjZxfsJq <= 498616.444995569) {
        for (int shiosyWs = 1889541410; shiosyWs > 0; shiosyWs--) {
            oIUGuYHYkjZxfsJq *= QActavrW;
        }
    }

    if (dArdwmB > 649568.3396048741) {
        for (int zjRNybNXAZy = 795480536; zjRNybNXAZy > 0; zjRNybNXAZy--) {
            ldRtdojW = ldRtdojW;
            oIUGuYHYkjZxfsJq = oIUGuYHYkjZxfsJq;
            FeylcBYtZukgdfW /= oIUGuYHYkjZxfsJq;
        }
    }

    for (int rOjfAsWcOhwjuEKj = 1742904219; rOjfAsWcOhwjuEKj > 0; rOjfAsWcOhwjuEKj--) {
        QActavrW *= QActavrW;
        QActavrW /= oIUGuYHYkjZxfsJq;
    }

    if (FeylcBYtZukgdfW != 498616.444995569) {
        for (int KPSiPUFFTXtwgYRX = 720614519; KPSiPUFFTXtwgYRX > 0; KPSiPUFFTXtwgYRX--) {
            dArdwmB = QActavrW;
            VvruBCbfUNoZwf = ldRtdojW;
            FeylcBYtZukgdfW = FeylcBYtZukgdfW;
        }
    }

    return POwEk;
}

string DuYBmlVUnDyoIEX::HAWTnSHApr()
{
    double ntLxtgELOWLqpuK = -40833.85811238952;
    string GlKUdY = string("JjrCaRRPlvTeEyutzfLoQVivZzVLZnzZvYtsNNHHotoEPuswBeYFYZfQnknXXQhuepzRUAWlSZLtIwAnArkANbagBTTtNKpNOntGBUVizUhxIJShJMclfHNxHJlWLV");
    double eLNgkJRlqQFo = 1036123.6056817406;
    int oypEdHYccFot = -450809745;
    double IyyEyaXhGtqAZXd = 48825.41099378479;
    bool pAqVvEUXl = false;
    double fPFrRtNAkTijDP = 594568.6524724509;
    string HympXpvE = string("HeYOWmjgReIuItVCKgRkqVqFpOEaEnnsLuUmWGUIESbMUQIMsDLfrfCVarbrytecLvIhFrFCZFjvBpHvjMh");

    for (int TDEeIWDjNiEqfR = 1024313916; TDEeIWDjNiEqfR > 0; TDEeIWDjNiEqfR--) {
        eLNgkJRlqQFo = IyyEyaXhGtqAZXd;
        IyyEyaXhGtqAZXd = fPFrRtNAkTijDP;
    }

    if (eLNgkJRlqQFo != -40833.85811238952) {
        for (int QsKHBwoa = 718383309; QsKHBwoa > 0; QsKHBwoa--) {
            continue;
        }
    }

    for (int uZEamTqzUtZjr = 110578041; uZEamTqzUtZjr > 0; uZEamTqzUtZjr--) {
        fPFrRtNAkTijDP /= fPFrRtNAkTijDP;
        fPFrRtNAkTijDP += eLNgkJRlqQFo;
        ntLxtgELOWLqpuK /= ntLxtgELOWLqpuK;
    }

    return HympXpvE;
}

void DuYBmlVUnDyoIEX::URKwjOOqCrcgCU()
{
    string mopAyDECsnjLh = string("ikREKRBBhpOIOSoLdAxZQQeeDzgtPXFrEdyCWoQzSbbNzuqWQxdDPHivBOdyeJuhJoBOqMmxmyEFtEKjqFaojLsKEyrYWuDEDlzSkoZImgsvOUIoxCKXkqfnHAJdkRgoizcnQPXcGoM");
    double CNVop = -728800.8885036438;
    double OyiZcp = -47474.843036860744;
    int XxddDMbKpMJlNC = 1137652333;

    for (int BThaWCpVsoZ = 967758614; BThaWCpVsoZ > 0; BThaWCpVsoZ--) {
        continue;
    }

    for (int xYFCSRrEFXDBeSY = 2009827515; xYFCSRrEFXDBeSY > 0; xYFCSRrEFXDBeSY--) {
        XxddDMbKpMJlNC = XxddDMbKpMJlNC;
        mopAyDECsnjLh += mopAyDECsnjLh;
    }

    for (int dvkXWW = 982411842; dvkXWW > 0; dvkXWW--) {
        mopAyDECsnjLh = mopAyDECsnjLh;
    }
}

string DuYBmlVUnDyoIEX::zQIjHJPjJLj()
{
    bool irpFFCfYWaOv = true;
    int mGrTeCAxMikKPap = 360868769;
    bool DAgmdX = false;
    int eZAJiHEDlYRuIO = 1680594789;
    double OnSJbIwMhqe = 568065.1929828023;
    int oEJyGHKIIXDaKpvq = 17711113;
    double cmgbDG = 808019.2482064725;
    bool OLctclOxkAld = false;
    int DUCtAyaRFm = 998065899;

    for (int hyFWIluFGsAfXD = 1495086040; hyFWIluFGsAfXD > 0; hyFWIluFGsAfXD--) {
        continue;
    }

    for (int LsXBSjuvXFHUHTBa = 505476598; LsXBSjuvXFHUHTBa > 0; LsXBSjuvXFHUHTBa--) {
        DAgmdX = DAgmdX;
        cmgbDG /= OnSJbIwMhqe;
        mGrTeCAxMikKPap /= eZAJiHEDlYRuIO;
        OLctclOxkAld = DAgmdX;
    }

    return string("xWhWeiMagUyJdCCXueeQFEDtUEBHSAgoZJQWboOzNeiwBYcAhoShrLKkUHoNuncjLBpZXeBPHbHUkmgAabMHvWEnQGsSVKsAClEEUFUxCNluqlFJkcoUfpbciQmyrkIpwSRfFhlZPchJnuqmAhqRyeUfEmWTZSeNgERVmaXWsAQYSZRzRUWYQdBLcsw");
}

DuYBmlVUnDyoIEX::DuYBmlVUnDyoIEX()
{
    this->sgUTzkY(string("mEjeHeLlLmycaEtNsTiierUtNpLcdXAbZyPmsYUmcTaIYfGEJjpKSZWNPgwNQPdTgcvntdSEBRFQmkNwJuFHNPsuUCvxPUtBMrkDnVPoSRAAHFOlOyaeGMieEYZFFJUW"), -744863312, string("ljaRsmMCNHysJFGhHSiyMRMYdbrGBvxLiwiZoqbx"), false);
    this->cmwGRYZdNDWWszry();
    this->vsBJhhENrQriR(272625181, false, string("OdeQxDjkWvHcctzfxGMGiAwpEbPuUVvWWVaxsyiVqTHKRmXaNDgqOzNlOBqaLEjfeLuNigHTaFxOGvXHKkrDPnZiBPcJDKBmiJxOVpgTZuzeNIqoHUsysuzCELXfXGwdttucvKRlJJmEErBMgQRVnljFqsHJuVtUKlGqEMOu"), 906320945, string("Ihb"));
    this->WwxzSeThkXrukW(649568.3396048741);
    this->HAWTnSHApr();
    this->URKwjOOqCrcgCU();
    this->zQIjHJPjJLj();
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yLGXakS
{
public:
    int VnWGbe;
    string ymejSrK;
    double EPXWbKFy;

    yLGXakS();
    double iqjZqwx(bool ghUQDwj);
protected:
    bool LaABr;
    bool VzeclIM;
    double McTWKiCGmBPu;

    void emYAGohkc(double SFalIGqVUO, int hXswks, double blixmRGM, int GmbVPEsWSJqFs);
private:
    int RHFOcWtUo;
    int fIgot;

};

double yLGXakS::iqjZqwx(bool ghUQDwj)
{
    int OJdrDvDRvvIXPk = -71357022;
    int LIekjcgurEH = 726574082;
    string NBwExyWfWNSLaHW = string("ydkeepEiBvQvQqlkqciJiPElbkPdqjSHZQZVmhUUOCQmlvCaQcEzqXqMhxfBfdltrfByWmfhOlhBvBAqrfedwnFUfzcqnzMCbVEPIvJKSBUUnlfCTjfQVbvxcHFSCWxVGOtVYKGpHrkbpXpiuMWfDZxMLPkKSBJqLNYpvBVWxw");
    bool maNTgGVDSji = false;
    double zRKbgiV = 670269.5430362282;
    string PmgzQ = string("JtRsflDfbDUcPPtNEZVZnTxBwmIWScTzsLRxiYIMQcjUgorZeXWTJYfoTALCUYzFobAZCvYxGHtYroCvqulQQgEmcwjbnClvKaUGiYuiOXdbJReHfOFwxMQTxjbCVAOkezivuoIdfUOslAkZwoT");
    double aLdNYqeOS = 692194.1833506646;
    bool fqVZeY = true;
    string MBPZeMoKAembRB = string("QsOvbKmjeQFTTTikLFyg");
    double LkZfLnfc = -743011.4407049688;

    if (aLdNYqeOS > -743011.4407049688) {
        for (int NWVpwnYAAGhEIo = 150460435; NWVpwnYAAGhEIo > 0; NWVpwnYAAGhEIo--) {
            maNTgGVDSji = fqVZeY;
        }
    }

    for (int QCIEWkDHArozWZLL = 1861591265; QCIEWkDHArozWZLL > 0; QCIEWkDHArozWZLL--) {
        continue;
    }

    for (int zpvmZm = 30945704; zpvmZm > 0; zpvmZm--) {
        PmgzQ += MBPZeMoKAembRB;
    }

    return LkZfLnfc;
}

void yLGXakS::emYAGohkc(double SFalIGqVUO, int hXswks, double blixmRGM, int GmbVPEsWSJqFs)
{
    int Onayc = -345100087;
    bool IruqUAFGHgfPkK = true;
    string cMHvyFEyuAYTv = string("DMCkeAvmHTxkPVQZChwHbtlyTjizGKeZZqheanxbYYjpuniWUVUyLIqRaDEndIYSgjzPFrYwHgObEyTzhaVFHyyzSQ");
    string rGfADCtwkLukx = string("tWcLqNshCrhiNtZJqmexdfDQUCBPMXgHIZAlKKCYgcVqFPnbBGhDVOxIMJEScYiYBcaDSTCDDMrAdeRtbJAsJQYfaQLLAIQyVXGCHfGVTZlEchyNJPMliBAUXpWqKVHvHItsAaNhuPGNpzinZzJpcCzJGTSGymicBpPAXbfhngesQsVFxgNMdVStGIqbDlcQsPyywNNOJhzWaRbWXdMYPYBOjDMHvcpxJHUpvhyBTEaUEqwkCF");
    double QdWcEPeDlp = 745809.1590657901;
    int GIrqyDTYRQIgU = -382677940;
    bool kUOpibafq = true;

    for (int DOsPQvcDCS = 455627247; DOsPQvcDCS > 0; DOsPQvcDCS--) {
        IruqUAFGHgfPkK = ! IruqUAFGHgfPkK;
        IruqUAFGHgfPkK = ! IruqUAFGHgfPkK;
        QdWcEPeDlp -= SFalIGqVUO;
    }
}

yLGXakS::yLGXakS()
{
    this->iqjZqwx(false);
    this->emYAGohkc(-751356.5237377266, 1893068552, -61882.34990201844, 695015524);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ZYKMOsFu
{
public:
    double ABurNKRe;
    double GbOERb;
    int XsIgEgax;
    int HMyxeasINWTUrBXA;

    ZYKMOsFu();
    void mFioVzvMD(string QUtBcGTorHzV, bool fTorJpSThygFFtCh, int SYIdhL);
    double cSrwtrBrT(string BMPMpd, string yOReJjMZcvcABAI, double DrJGkTPhfPZYCFSl);
    string vUrmSPVJ(int QDyNYKm, double JdCkp, int QzMtfIruoSYjl, double awfuQH);
    string MfaKidWq(int BhNBrYldPcqk, string HCPNh, int vRALZCNZgiPKCSW);
protected:
    double Cydly;
    double zPKtkVsflyrrT;
    bool OaidraynaWhGICT;

private:
    double AikdsyNpXToUc;
    int kDFfDNXjx;
    bool gbMJHSkvrSFJnC;
    int WxCpagrtrvHQGs;
    double KdnlBBnqx;

    void AlyjeGKUp(bool VBzFBhkLnlBMES, int WTFMkc, bool DhIWFuQ, int URVYtDIGXA, int jVDSCdksrOMZ);
    bool XoNraTvRvvVmWQ(double ICDPmjHjsDOkGCk, bool rJHBQbQvgT, int scOeZDhMlmMCDr, string rByXHEAUArGZc, double LcsqzvMAVHK);
    double lrFUbgKpzfStGEYY(string epxhtstPlPIBSaSS, bool BxmTl, double TrGFXgf, double naVIJsWtxFd);
    double VzCbImnMeRZKX(int WtpqYXt, string snjjIUnbhoqUHGCu, double myHJUvhnnYJoGVZY, bool wiHnKFJXvkJM);
    string ltWnxpNQTvwjjsh(string NXIcUVIHNXeqKNdX);
    int fazlSxql(double KbjOz);
};

void ZYKMOsFu::mFioVzvMD(string QUtBcGTorHzV, bool fTorJpSThygFFtCh, int SYIdhL)
{
    string wZArcRlVcwSlY = string("LfOlHYHmGQPcolKymraeGIbefQZSLlklhienJPAMGkGLAaFcYjhOlCKpfSNGprfyvtJtjfJFaxhiZQyuWOIbosASbFjaXyJQKwFm");
    string LKskBDt = string("ANcnmRQMELsHZImzCnRtXNFBqLJdMhMDEEuDHCDVuScVirJsToFBdyRcHgtRcXuOMbzDUyVTZDIOabUVarXRtzDsFnonHtQPGlzixROHmITRZRsOMsLKbIpybQfjrYOniYDdigdyxKmlyrhyErmeDLjZmshu");
    double iCTixgtzSo = 762691.2622786878;
    string WylCmjGCfxVU = string("MXIcoZSeRYtnfrIHBjYkLbWwMzflXFitCOVwPAdoqFuMsWNCKYUTyhIKyOrlqzVDIPtKyjRMlBJmtdISWwdTPxTZIzYuxlCNvPAqCvzQDsJJCxiXchOvWKr");
    double MyNguhaXoTXfgJk = -733172.3843348896;
    bool IuWmZQ = false;
    int YnBZyAOq = 891282146;
    string COWUpbRnOtChq = string("JctHGmfswkizEivQpiFbRqDnVScFYFNetRCbOYORUaoZqmvIhbsuzIkYRvDitJhrsCPBAvKdMAoqwgQZSpWuRhLKLeGYHycnNrOtUaMOMLobtIzYQlzcVkvSJsRoFslgJeTwBETIkUqYglXFAAsyUbHVJXuLrMFiSulPkJDvFjwEkKaBpWiCOsUQKKFJauYJKLvgDEYUuxwqmxyRrQlv");
}

double ZYKMOsFu::cSrwtrBrT(string BMPMpd, string yOReJjMZcvcABAI, double DrJGkTPhfPZYCFSl)
{
    double gdCerHnmS = -853040.6364051435;
    bool mYrkFnQb = true;
    int vQauSfHsASK = 680463715;
    double xMtnwOSfQmzJv = -992931.4598324362;
    string TNwppb = string("WtvBVIHpjtZPdqwNtPNNkkKwPoNrPIbCyudJItKhIrUpiSYjvVfSxZJyEgXuiwwrLCNDCoJWoppEBqeaQHdSpIs");
    bool YzSziG = false;
    int EXpAKmR = 1461019371;
    bool EgIYOJYGpEKX = true;

    if (vQauSfHsASK != 680463715) {
        for (int ipguad = 1061160324; ipguad > 0; ipguad--) {
            YzSziG = EgIYOJYGpEKX;
            gdCerHnmS /= xMtnwOSfQmzJv;
        }
    }

    for (int ErcSIs = 1987395181; ErcSIs > 0; ErcSIs--) {
        EXpAKmR /= EXpAKmR;
    }

    for (int anGmQjK = 1760690071; anGmQjK > 0; anGmQjK--) {
        mYrkFnQb = ! YzSziG;
    }

    if (EgIYOJYGpEKX != true) {
        for (int MwKFgYaIfTfGb = 1558381593; MwKFgYaIfTfGb > 0; MwKFgYaIfTfGb--) {
            vQauSfHsASK -= vQauSfHsASK;
        }
    }

    return xMtnwOSfQmzJv;
}

string ZYKMOsFu::vUrmSPVJ(int QDyNYKm, double JdCkp, int QzMtfIruoSYjl, double awfuQH)
{
    string nxuErAgXrFeuNm = string("eERTomaLArzrhCqPLttlmnxWeximzZMmvLStBzCAqBkLmYBXJYCzoIvbYvLsSRLbvZxOzqucdKqCZibblQWJyICErsaHIlkQuBMRzfjrwFOUuJsSZnajbpYlCCHo");
    int QnHxHbEKFaelN = -1462112851;
    double bYCXANsExWAdAXF = 106315.69646040206;
    double bdMMATqOqjtRrt = -256814.3306135861;
    int BgNmhqEcgxh = 409458487;
    double ObByoJmpYuiNxGS = -505239.84314751654;
    double AtsfjwHHKUn = -51513.621095162605;
    double dGVmbWXYw = 968957.9625449021;
    string cEjQKgTjqnrflOb = string("vyQXnPHaYpeldCWtVasBZwYXHPRCgyUYFtdQRcHczwsUsyvnJmpsQRFnahbNnUnuGXvjsVWrY");

    for (int HdLicOVQAs = 1246095696; HdLicOVQAs > 0; HdLicOVQAs--) {
        AtsfjwHHKUn += bdMMATqOqjtRrt;
    }

    for (int rocUX = 116419737; rocUX > 0; rocUX--) {
        cEjQKgTjqnrflOb += cEjQKgTjqnrflOb;
    }

    if (bdMMATqOqjtRrt <= -318574.2713918606) {
        for (int yTvISSvsClhX = 1760584755; yTvISSvsClhX > 0; yTvISSvsClhX--) {
            JdCkp += ObByoJmpYuiNxGS;
            nxuErAgXrFeuNm = cEjQKgTjqnrflOb;
            bdMMATqOqjtRrt *= AtsfjwHHKUn;
        }
    }

    for (int hbXkZjYOMMq = 413216927; hbXkZjYOMMq > 0; hbXkZjYOMMq--) {
        AtsfjwHHKUn = bdMMATqOqjtRrt;
    }

    return cEjQKgTjqnrflOb;
}

string ZYKMOsFu::MfaKidWq(int BhNBrYldPcqk, string HCPNh, int vRALZCNZgiPKCSW)
{
    double rbbztONkLsBK = -151944.5831759469;
    string mLspPpKufe = string("csirAKnLJpbRDZIFzKXhFLyDcqZIDkABhzOULTtfEOXCbqNlVZTqsfpDRAnADqKRQVUiYlzunGYJmXPOQhwOOqmQybLlhaZlvXNnarqoygBGzSeIvFCUIAdZXTNtaIcOribYLqrQgRdtkhxoSIIkiSyeRDBXsPSMDyBfgihwgkDqibnGsxuFqHTjXfigfYVuGSVsmJCXssSNQbRZTAfkrZoOQUWXkopkdN");
    int fuMBuqCMteahWkdH = -1675422467;
    string LHsxYg = string("rvReHtwrBUnlZQTApzfCyiruVbEgtbqQGzCasSolDPCemLNlBIrtgNoBUWLhgZYJuPKRnQXpAeFggyfnUUcgNSxcH");
    string cAmOBRwIrWKXJlat = string("MKxXrSgfzaGyYdlULeltWJmetOkxfTNQyWpNLdDxvQOnWmHg");
    int FuciSaarYyNCra = -942898196;
    double ZTYMqU = 970503.8835755124;
    int jIyFwL = -831273601;

    for (int DPUKwUJI = 1716864916; DPUKwUJI > 0; DPUKwUJI--) {
        vRALZCNZgiPKCSW *= BhNBrYldPcqk;
    }

    return cAmOBRwIrWKXJlat;
}

void ZYKMOsFu::AlyjeGKUp(bool VBzFBhkLnlBMES, int WTFMkc, bool DhIWFuQ, int URVYtDIGXA, int jVDSCdksrOMZ)
{
    string xopPCbCvf = string("SaOYVoeEyPKEuBlmvmCSLnimJqEsEuXvIoxpgZiiavaTgApAUJNAEBTuXmPKYyDHGNWKJBAIkBclbluFPpwzJiGdYpusCtpUGoxTxFbzMlJOdsBtLnRasJHFeNfirvXBUBVBwzeIoBJwksCjSrhmuFGrNlJssbIJZMvdYzGQwYzeGwQpwLzOwekJJwDJdAkPlBYRtoNEtMrX");
    bool eFqPfRKf = true;
    int VbCEgIVE = 1862632579;
    int lKTqUigSjiDJ = 1799921628;
    double PxhAeCsInUYKiiV = -32413.938156899836;

    for (int fDGZim = 1763689842; fDGZim > 0; fDGZim--) {
        continue;
    }

    for (int dgLPPORiRtqonjN = 851006596; dgLPPORiRtqonjN > 0; dgLPPORiRtqonjN--) {
        WTFMkc -= WTFMkc;
    }
}

bool ZYKMOsFu::XoNraTvRvvVmWQ(double ICDPmjHjsDOkGCk, bool rJHBQbQvgT, int scOeZDhMlmMCDr, string rByXHEAUArGZc, double LcsqzvMAVHK)
{
    double kbGJaymJUlBbQMp = -516955.89335334033;
    int oZCWHkeBzq = -1309931364;
    string PyfwWiv = string("khdCXnsrIwAKQSlgAkMPznCBrLWTrCBbWPoNdFsNbuKiIApuTTkqBNhTJfChJXEHdnqtyLZDOmvhlicpyfMXRUJedPbbFseIjuug");
    int iVrnbOLaTuXfiGlv = 1958157020;
    double RZllPaRBmqZeiaj = -60969.95290670234;
    int fsrbV = 1700295795;
    double kfzoRKEtP = 268963.82594702236;
    double TtKXrhbmjbdA = 1048215.7401610288;

    for (int HbvLJz = 1112069559; HbvLJz > 0; HbvLJz--) {
        LcsqzvMAVHK -= TtKXrhbmjbdA;
        ICDPmjHjsDOkGCk += TtKXrhbmjbdA;
        rJHBQbQvgT = ! rJHBQbQvgT;
        ICDPmjHjsDOkGCk -= kbGJaymJUlBbQMp;
    }

    return rJHBQbQvgT;
}

double ZYKMOsFu::lrFUbgKpzfStGEYY(string epxhtstPlPIBSaSS, bool BxmTl, double TrGFXgf, double naVIJsWtxFd)
{
    bool PPLXiSj = true;
    int uqBHG = -232737005;
    string cplKTebYdTIwL = string("fDjzQXhDkiDmnVIHawuEWBwzWxZylnmcZejQOvvbOaZqnFIaskQvxcwXdxzZLFzyIHXRaDHfGaDqcxyKEFMH");
    string vBXdOIJ = string("TERrdTLTzkFcogcjYHZChYYmdXpfbrdNpGXIzPJEjnfrpUxyZyRIqAJnyhOzCaqoEkKqcsdBAdaAGvvdfjvhzbCGEolWmXGzNniLkLHXVWJILZuYFNznnpFdBlTTpNVVNAuRhLPTXayTzswThZGqvqmhEbukxdWeEVbCeOkrghapGlaFfOCNCgvCyQZYuqrPBNVEwBXdUEmTEokqCQtypbZMywAiAZmslMQCfdJLSJQMCydd");
    bool KziPqBAjCcJJ = false;
    bool ORciHtWvtjwk = false;
    bool aoBJGJUYubmcX = false;

    for (int SaZDWSlkBPu = 727025290; SaZDWSlkBPu > 0; SaZDWSlkBPu--) {
        epxhtstPlPIBSaSS = epxhtstPlPIBSaSS;
        epxhtstPlPIBSaSS = cplKTebYdTIwL;
        BxmTl = aoBJGJUYubmcX;
        epxhtstPlPIBSaSS = cplKTebYdTIwL;
    }

    return naVIJsWtxFd;
}

double ZYKMOsFu::VzCbImnMeRZKX(int WtpqYXt, string snjjIUnbhoqUHGCu, double myHJUvhnnYJoGVZY, bool wiHnKFJXvkJM)
{
    string YYTGOrjvervYL = string("kkRQJXipNuIHTmXSoAMYTImuWrohvgtFvrziqfDt");
    bool gdKwQoag = true;

    for (int VXcHOk = 16371394; VXcHOk > 0; VXcHOk--) {
        WtpqYXt -= WtpqYXt;
        wiHnKFJXvkJM = ! gdKwQoag;
        gdKwQoag = ! gdKwQoag;
        gdKwQoag = gdKwQoag;
    }

    for (int rWOcNGOwmLAFOWq = 951640130; rWOcNGOwmLAFOWq > 0; rWOcNGOwmLAFOWq--) {
        continue;
    }

    for (int GCYYZfebUx = 405454984; GCYYZfebUx > 0; GCYYZfebUx--) {
        continue;
    }

    return myHJUvhnnYJoGVZY;
}

string ZYKMOsFu::ltWnxpNQTvwjjsh(string NXIcUVIHNXeqKNdX)
{
    bool kkhIRSUbiLRgRaxX = false;
    string HpBvbvjsbvjSc = string("fXvXVyqnREaGwWxrPhOZLegDtkoFTOpycBNhecYZeQgpdZUymGIMhPu");
    string DjYMKstwQtlMB = string("xGoDNNWjtoCTJQJupjhNGxBbDpdjnKNFZGmaaxrcDUwraNUaohynRvTkzFKNpxyXAYvkMbXXfGcUxbxQxtohqGz");

    if (kkhIRSUbiLRgRaxX != false) {
        for (int vcTzWI = 172671430; vcTzWI > 0; vcTzWI--) {
            DjYMKstwQtlMB += NXIcUVIHNXeqKNdX;
            kkhIRSUbiLRgRaxX = ! kkhIRSUbiLRgRaxX;
            HpBvbvjsbvjSc += DjYMKstwQtlMB;
            DjYMKstwQtlMB = NXIcUVIHNXeqKNdX;
            NXIcUVIHNXeqKNdX = NXIcUVIHNXeqKNdX;
        }
    }

    return DjYMKstwQtlMB;
}

int ZYKMOsFu::fazlSxql(double KbjOz)
{
    double ERfujmieHMxJsc = -363014.5145189302;
    int rBrXZjj = 992219026;
    int GvOBMBbael = -1047634076;
    bool upYVMuqMqXkFL = false;
    bool OLQIDPLeVINyIj = true;
    int CJdluoGXunBL = -1373126455;
    int eWcEVyN = 1890923945;
    double PqSbqRaIHRbnXkgb = -714174.6307373516;

    if (OLQIDPLeVINyIj != true) {
        for (int VePGpym = 1982244231; VePGpym > 0; VePGpym--) {
            continue;
        }
    }

    for (int Bqacch = 2131331525; Bqacch > 0; Bqacch--) {
        CJdluoGXunBL += CJdluoGXunBL;
        CJdluoGXunBL = GvOBMBbael;
        eWcEVyN -= CJdluoGXunBL;
    }

    if (ERfujmieHMxJsc <= -363014.5145189302) {
        for (int PixKabrWpnACAF = 2041309859; PixKabrWpnACAF > 0; PixKabrWpnACAF--) {
            continue;
        }
    }

    if (CJdluoGXunBL < -1047634076) {
        for (int MsWHfeCG = 2137052896; MsWHfeCG > 0; MsWHfeCG--) {
            CJdluoGXunBL += GvOBMBbael;
            GvOBMBbael = eWcEVyN;
            CJdluoGXunBL -= CJdluoGXunBL;
        }
    }

    for (int rLimdyKBbNlibX = 702190584; rLimdyKBbNlibX > 0; rLimdyKBbNlibX--) {
        PqSbqRaIHRbnXkgb /= PqSbqRaIHRbnXkgb;
        rBrXZjj /= GvOBMBbael;
        rBrXZjj *= GvOBMBbael;
        eWcEVyN /= CJdluoGXunBL;
    }

    for (int CiSRgrUXrut = 185164503; CiSRgrUXrut > 0; CiSRgrUXrut--) {
        continue;
    }

    return eWcEVyN;
}

ZYKMOsFu::ZYKMOsFu()
{
    this->mFioVzvMD(string("BpPtQLVaslCaCIWIXOVzbnqYbVZDPCneMTofreUfcpxiQJSusDGqQjBngjGOyvKnSyjOGeqCEepTCDfzwJMbcmTgPHireVvNJvpLctzrSMZwscpdUbuyXESyXandZSuwwkvQyXssZtGnSqpNZmfskqkIhwoXCEpvRTdNyXAFIwdrdkWZd"), false, 430845913);
    this->cSrwtrBrT(string("okhFZRMCqKoSWBXEDjpPPOtRNalFyeTjACzxYAdPMyudEjsvdzhVWAjsYdPLhNIPrQRcGBEsmiXZFHzVfrOPUFktedHGDaEtyCFJGoOXkTxNMRlVH"), string("QHvZKfrWGnSLDVmRwbYoDIXOMPtVOsOeaMdgEDUAayoPFjLUKnRyDaMqXLlVslkfEXwkgziOwIfAtSAvjuyAibMxCBUpiagbHDSLFsWCHZrBUDOGSvVsTCvJUjKKeIRnZHoPwchvOUzdcJezsXJGwIKnoZjzPfJOjSOfeHvnyfIACNSepxnSHUMiTJWrXPzRSorQnTBCZDOtbnHuHqaKOYgWzofIbR"), 905193.2188727041);
    this->vUrmSPVJ(640357098, -318574.2713918606, -1399525131, 1043849.111596674);
    this->MfaKidWq(-1674222468, string("fkqiPEbeudOAxzWIHpigNCyaHFGQawYRpTXHkLNNfEnxeDfgaPVqpnBlrqhgwxAZrvYgKYnELyUcYALOvOxwiIwOTwUhQjgWeJwnGyoZFqKvnjTrchoqURfAOlffxvgJhuWYFlhWQhfBvpxrhpkKb"), -1638232652);
    this->AlyjeGKUp(false, 1335327518, false, -765281042, -272977214);
    this->XoNraTvRvvVmWQ(-622862.9245779378, true, 688120244, string("qjntuPPKwCysqNUidEwNXckmggEUwrWxNGNmrdAjveZkAlvhoIvYYvYZOOmmaEsZurhpyYhwAtZaDeCiqyDYLMNPajQvdYBCyRhcDhVhAGoOXhngVDpeiLVPJdnroJbEUoSVKoryVYYxGhglTPlcTYlKGnYzpTFLoDkhQMqfpYyqXQPmjkbRJotMxfXmBREUpyglAUviohqWOyUbtdXJYIYldRxgPKmJb"), -475723.47021229146);
    this->lrFUbgKpzfStGEYY(string("UTmgoiiOmQmiAjMOuXqCujKSOlxlrhEvSNGLzbeGtUCavAgJmscxDQTnjZFaIJrrvHViWLeVSKERqySOGfjbriDQKKFDNqpMsMRmdHOIXKcIuygvLLvHKrjfWgCiWxgZmVPRLCyZDFfbUrghhIHCQvFCJynpykkWBg"), false, -196013.34730410823, 940370.0800645535);
    this->VzCbImnMeRZKX(41837936, string("AZOEGCJTRbmbYcfOXoaVeArDtGeRLAXIKOPDBzPHBRpQBMACpAnUYBvQIWTANJMtsqUxuxKHrAYpEiRSGtsPHYGkgVcPUuUatnVgzrLixjrMpNwjMjeYnZlTuurxkTvaDjByZNVtENnJdfeqkTjsVHXUbAGPcMLloflrSxbQSoxZDAZOPkDHLcFmCwOPQUpOVTPAkb"), -401240.2337351765, true);
    this->ltWnxpNQTvwjjsh(string("aatgQNIkHNOBAlmzppVmnZtMeFCjJOMGBWytyDVJNBCzrSSkxMRcOAFZKnfFfFT"));
    this->fazlSxql(-687385.8335051977);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class epxrk
{
public:
    int zBdtd;

    epxrk();
    double rKOZKTzYM(string PlXFVobQOQD, bool tvVnHpOK);
    double xbgCGIjCWBI(string xbpwAgdutZ);
    void FQzgTPraPGwnBHa(bool pkqBVzCyvPQHb, bool OBeQiUMJ, int ttxltLhRajdVMkcf, double BtwuRxWvUnqE);
    void ISTMzLCH(bool rJpNXxLHjngDk, int QPHXwPAfL);
    bool zhysiDD(bool SJVdXvfIygQT, bool ZCXndQOdYv, bool GvyCs, string jMUMHIsVekcMxo, string fGvhXqc);
    double CEskjPbuju(int xCTdaEQPYNKbt, double tnPwn, bool IjvehBCL, string IILsqYbeovTrsZGU);
    void IEaWpSVSComtZk(bool igSzBQ, bool ucNDSjeQxmDaY, bool itUMRECAXmQDO);
protected:
    int BbRGcefucH;
    string YpMnVZUISizaco;
    int nhOMf;
    int uZkNWUhN;
    bool VwljMv;

    int uDQdIbQHwr();
    bool zONLaxQTvouIwf(bool nQDVeZSWigVPbRFZ, double buUwoH, bool YDZNAMwJOUn, double bTWrMfhTgBJ, double ztNrjagWhc);
    double pNWJkmWmQHbBt(double uOYjpGPyctWdHD, bool WXeeLzEP, double UdWYVMoouuRLKzF);
    bool oZHwDKJkSSnOpHVf();
    double zrUMEhEzePqlR();
    bool ksGmFCGSkaSqB(string STfZyYbHHGPt, bool AVlmrRtRoVmW);
    double UAZLa(double jXXojL, bool AfKmoFroI, int XYxEgcTaDYx, double NEVTjxoKwvfUyq);
private:
    int LIzawFEokn;
    int FtXTUQurnQJGRfYm;
    string lfYnDooiLPrAXL;
    int zLezPqi;

};

double epxrk::rKOZKTzYM(string PlXFVobQOQD, bool tvVnHpOK)
{
    double mGsprxDhtCDVXTF = 464396.9245482268;
    int nvSutzWxQpstf = -307346082;
    bool aokityA = false;
    int XTPfUNV = 1191304960;
    double BWcbXEEP = 1000814.3392413976;
    string EmPZgNZDAG = string("TFWLskJYrYSQEvAmGuhACQloBrLPmukQMyDPNokhAccMeUDzOHanXzplvqgXUNUhrcPKMkLVyBKmYYXMknLfWqFsfquwSAQmadEBvfabAmaaXbkvMFLdQQgyevcMGdWabaRMzDnyd");
    int cheqARu = -531451391;

    for (int WpcNMOWIwQvC = 1739706055; WpcNMOWIwQvC > 0; WpcNMOWIwQvC--) {
        XTPfUNV *= nvSutzWxQpstf;
    }

    return BWcbXEEP;
}

double epxrk::xbgCGIjCWBI(string xbpwAgdutZ)
{
    double jLXpwEWzOO = -869059.618682337;
    bool ShWxhhgATjT = true;
    int AVhuxNoH = 738676727;
    string YgQLBXkdEAGndbFO = string("wFjjIxCAUtYhTUvWUztmkgqzdFOHMyLJDozzARlsUtvvGQutBvgxsbrDhHMhhZkdwOO");
    int CzgJW = -1300745255;
    int HlTlzYaAEOH = 794039671;
    double XlvZXXRcKk = 680461.9127157478;
    double FBXJLCp = -629087.6824697113;
    double utDHGFJzty = -675585.1562935133;

    if (CzgJW > -1300745255) {
        for (int rOYPxZLEPm = 145574152; rOYPxZLEPm > 0; rOYPxZLEPm--) {
            FBXJLCp /= utDHGFJzty;
            YgQLBXkdEAGndbFO += YgQLBXkdEAGndbFO;
            AVhuxNoH -= CzgJW;
        }
    }

    return utDHGFJzty;
}

void epxrk::FQzgTPraPGwnBHa(bool pkqBVzCyvPQHb, bool OBeQiUMJ, int ttxltLhRajdVMkcf, double BtwuRxWvUnqE)
{
    int OmomCgVVXMHj = 1348025986;
    bool iLmFfPiIS = false;
    int fqaMPnUTKQXtnmH = 2017968084;
    bool ihGQGOgiipuyP = false;

    if (iLmFfPiIS != false) {
        for (int zPKSAHTfERbuvNxl = 1136463488; zPKSAHTfERbuvNxl > 0; zPKSAHTfERbuvNxl--) {
            fqaMPnUTKQXtnmH += ttxltLhRajdVMkcf;
        }
    }
}

void epxrk::ISTMzLCH(bool rJpNXxLHjngDk, int QPHXwPAfL)
{
    double CDvrjFslWcnHkhJ = -292618.9373220546;
    string npGBGjic = string("CkSfFQGfghjMxbZJfOndVyoxixZXdqTWJJsWvjbNtLHAjgDUWNGvewwrafNuhmCzkaPpiRpqJpgHQetJeiSWtUVrwcoZPnApqGPVSHRwGXUPlLAgPWpHDQHCdLoQEEaxbJoVvWTubgVmxurdceesDubUCfRienglmliNQncrPJIOuotyqAVJKkujOIhkKRjqsuHNnzaHGlTZoyfavXFPyuzrnwYsDRyLWoSfNWgUIePfvvPKcFPuygHhiENcouA");
    string AXJnCDrCDBxUHJ = string("zivhdUjHcrVZMtNlqoLNVXgQQNuEoWkRIkhcLTPyVWOxNvZuyqhvNmSiiiVcgaUlAscWqZMjvNAGVSWQY");
    int ndbbhwuYP = 106939862;
    string ooHfRuX = string("mMoTVJAHCiFXmtmevICUpaVZCxjdWzAopHHwtIhWgaCWWOLBaFiVRTrNPnzRXGjDDCUDOatzyONMNEUvEXLospPsElvPoTczBXEerwVWmQfDzYTnZThuRJRYCYVNZXVwbFJZgFQpHKfWWBwHlXPQAyjyTWIAgybpzRHJtlWYIszlwRbPEKnLTZZZuKUMmumpfhJRiWAocGQZRCaAB");
    int djaiN = 1927125457;
    bool panTXNrVesHi = false;
    double azRuliMT = 896882.4461773332;
    int gYAlRomNHM = 517730887;

    for (int CekmnPLSMj = 988440647; CekmnPLSMj > 0; CekmnPLSMj--) {
        rJpNXxLHjngDk = panTXNrVesHi;
    }

    if (QPHXwPAfL <= 1927125457) {
        for (int EThPzuq = 1687896704; EThPzuq > 0; EThPzuq--) {
            djaiN += djaiN;
        }
    }
}

bool epxrk::zhysiDD(bool SJVdXvfIygQT, bool ZCXndQOdYv, bool GvyCs, string jMUMHIsVekcMxo, string fGvhXqc)
{
    string xJYsb = string("zrGPzVt");
    bool huurewAllIw = false;
    int TGDlAbFg = -1712891741;

    if (ZCXndQOdYv == false) {
        for (int cmjdNdYJ = 1285230062; cmjdNdYJ > 0; cmjdNdYJ--) {
            GvyCs = ! SJVdXvfIygQT;
            ZCXndQOdYv = ! ZCXndQOdYv;
            huurewAllIw = huurewAllIw;
            ZCXndQOdYv = GvyCs;
        }
    }

    for (int mqoGGevJNqLiW = 1988012847; mqoGGevJNqLiW > 0; mqoGGevJNqLiW--) {
        huurewAllIw = ! ZCXndQOdYv;
        huurewAllIw = ! SJVdXvfIygQT;
        SJVdXvfIygQT = ZCXndQOdYv;
    }

    for (int mFsTNJmsPVrBhak = 2111064714; mFsTNJmsPVrBhak > 0; mFsTNJmsPVrBhak--) {
        continue;
    }

    if (ZCXndQOdYv != false) {
        for (int JCBgELQlqbXftluz = 1147346805; JCBgELQlqbXftluz > 0; JCBgELQlqbXftluz--) {
            ZCXndQOdYv = GvyCs;
            huurewAllIw = ! SJVdXvfIygQT;
        }
    }

    return huurewAllIw;
}

double epxrk::CEskjPbuju(int xCTdaEQPYNKbt, double tnPwn, bool IjvehBCL, string IILsqYbeovTrsZGU)
{
    int GyWExPWZZRH = -1079591606;

    for (int IeUGo = 1670490172; IeUGo > 0; IeUGo--) {
        xCTdaEQPYNKbt += xCTdaEQPYNKbt;
        tnPwn *= tnPwn;
    }

    for (int Fkwyct = 408231876; Fkwyct > 0; Fkwyct--) {
        GyWExPWZZRH -= xCTdaEQPYNKbt;
        xCTdaEQPYNKbt = GyWExPWZZRH;
    }

    for (int OEzDCJDTkIJBVd = 942653772; OEzDCJDTkIJBVd > 0; OEzDCJDTkIJBVd--) {
        continue;
    }

    if (tnPwn >= -184850.8360187721) {
        for (int QgnmgJJ = 822776027; QgnmgJJ > 0; QgnmgJJ--) {
            continue;
        }
    }

    return tnPwn;
}

void epxrk::IEaWpSVSComtZk(bool igSzBQ, bool ucNDSjeQxmDaY, bool itUMRECAXmQDO)
{
    int LKqXqwFzJx = 127558367;
    double RxdgEpWVw = -1039536.6713832169;
    int yWTwfZsvhmX = -95415150;
    string MeKtM = string("PKDobVbYyCVmdIeiWYqaFGiHwtWcdPATnPIMIjOTTGHAxbdTRsozYnlFhftcuUMYIAHCCWnwtxHCgIqpXqxAKRgXnMG");
    string EYfobqX = string("CuCiEVVRAlKaaruAryOjNKRn");
    string WLKqztbZiGNhoiJ = string("UGewjJZlYEScafLFCkPKBnmSkzGsDMUjdRgWhHAOCTTMfDplFDhMMOfNaxqGtRWBUjEulpzJRAazrNBCmJmQHYLszsIDNIkOcVSzBltBJKnMaPtWYJSCqLYWNWyDAxyuIazGiCBnbRAnsNiAhePkCgewJrCiWqNkXXDRGTFsuxllIhowTKvfssVvGfrsskIqYsDNohenSwhOMIyboNmljaQcsOvSshlDXIJuEjAqgNQMkOpOqMGUzSyIrHPPPWr");
    string KKUQZ = string("gDFICeTXRwBdfDiKqtPJKxARbkkQHCCEndOsqmCiWqIRUACPAnmlVnOOgGsIpMzAQjEzFRvzgFrtWRAOxzduMMMIpaYpPVeEikfFyHxUIB");
    bool PPINJgAvziEUOw = false;
}

int epxrk::uDQdIbQHwr()
{
    bool DTQIvnxxF = true;
    int hhdRgxyqaSw = 90205347;
    int LkqlLGOnmlFK = 1715568068;
    bool RGTDCYwOGSkv = true;
    int PaxNONGxpglvaN = 2073021267;

    if (LkqlLGOnmlFK < 1715568068) {
        for (int WSgRFOI = 384374110; WSgRFOI > 0; WSgRFOI--) {
            continue;
        }
    }

    return PaxNONGxpglvaN;
}

bool epxrk::zONLaxQTvouIwf(bool nQDVeZSWigVPbRFZ, double buUwoH, bool YDZNAMwJOUn, double bTWrMfhTgBJ, double ztNrjagWhc)
{
    string QMVHZIXUWmC = string("jCVVBZaHxmIluYaTgeYSLzTBbTqrPwXLdnaSJmUWfJimYxxHmYSuEPBLxcQhQsgHzPLNGxbKhJzkwChAingcRpFnOjUdLycBlRBPvrxxBWmgTJBRuIgrjXsi");
    bool PvtAkBnTRP = true;

    if (ztNrjagWhc != -975263.6910866877) {
        for (int tmKTCMnYPhAtHqIg = 1416064689; tmKTCMnYPhAtHqIg > 0; tmKTCMnYPhAtHqIg--) {
            buUwoH += buUwoH;
            bTWrMfhTgBJ *= ztNrjagWhc;
            ztNrjagWhc -= bTWrMfhTgBJ;
        }
    }

    return PvtAkBnTRP;
}

double epxrk::pNWJkmWmQHbBt(double uOYjpGPyctWdHD, bool WXeeLzEP, double UdWYVMoouuRLKzF)
{
    double jvEcriXrTkZZt = -827790.7507818379;
    bool elYJZO = true;
    string mqKCG = string("EafIJQjhTwCcXTBXJbynpcSHTrkCJVeGOZMKUuUEduVyxMXicVhsMbwaPzVpXCIFnSnIWJkYMICXDhnTwyAPosLniLtGWOGAixlGAXWpKSOzknZHfIOhXjzKvJlJbWnFrEyLSVdeMRJlVUoOffad");
    string tfOcPbWZwHZ = string("FBWUHRzgfYXIGKQ");
    string TTEWRvorakweMg = string("iFHJWngJVCyGoZFOHMUQwKxnvxGKHEWPruRfmpopNJUKMEtpoGDFRAAd");

    for (int arRwgmVSF = 1309797841; arRwgmVSF > 0; arRwgmVSF--) {
        elYJZO = ! WXeeLzEP;
        elYJZO = WXeeLzEP;
    }

    if (WXeeLzEP != true) {
        for (int ZjRRe = 2001974032; ZjRRe > 0; ZjRRe--) {
            continue;
        }
    }

    return jvEcriXrTkZZt;
}

bool epxrk::oZHwDKJkSSnOpHVf()
{
    int zSHxBy = -2028091065;
    double oLbXRSjBi = 413809.8399701512;
    string oEdEnmJAXFHpNo = string("qixpnfVYJtAvUGwBsapXXkbYHDBytpQOcsBVbkzGNgUxADVUyFfYbYIBiQDkGZiRFiMvLurvYfymXZCRorIobvgavnSzJiIXNuOdbObeXWpZCfAGwUxqTCwhwEgnaweGukFLhhwegzoOHPMSFeRzeIfKLAHCNzgJLzXkODbErpFEiVUHKhrWQXouNqPQOEKDZPqHVcAVTXCJZ");

    return false;
}

double epxrk::zrUMEhEzePqlR()
{
    string djbXjzagkzH = string("kvByAe");
    int gPkJUlquFOzj = 2032659815;
    double aDvrIiE = 124902.28644209351;
    bool oKKqJ = false;
    bool cLSephN = true;
    double MmhDE = -875797.3747059888;

    if (oKKqJ == false) {
        for (int fBGmCBKmGP = 190458928; fBGmCBKmGP > 0; fBGmCBKmGP--) {
            gPkJUlquFOzj = gPkJUlquFOzj;
        }
    }

    for (int uJlujveTLrL = 1690234715; uJlujveTLrL > 0; uJlujveTLrL--) {
        oKKqJ = ! cLSephN;
    }

    for (int XeSpWpkfVbFGKaT = 743067574; XeSpWpkfVbFGKaT > 0; XeSpWpkfVbFGKaT--) {
        oKKqJ = cLSephN;
        oKKqJ = ! oKKqJ;
    }

    return MmhDE;
}

bool epxrk::ksGmFCGSkaSqB(string STfZyYbHHGPt, bool AVlmrRtRoVmW)
{
    bool rFyXMb = true;
    bool ZxvXCYnKIOxv = false;

    if (ZxvXCYnKIOxv == false) {
        for (int rIdoWmlcyD = 1603236071; rIdoWmlcyD > 0; rIdoWmlcyD--) {
            STfZyYbHHGPt += STfZyYbHHGPt;
            ZxvXCYnKIOxv = AVlmrRtRoVmW;
            ZxvXCYnKIOxv = AVlmrRtRoVmW;
            ZxvXCYnKIOxv = AVlmrRtRoVmW;
            ZxvXCYnKIOxv = ! ZxvXCYnKIOxv;
        }
    }

    for (int bRALdvsJFhG = 93395596; bRALdvsJFhG > 0; bRALdvsJFhG--) {
        ZxvXCYnKIOxv = ! ZxvXCYnKIOxv;
        ZxvXCYnKIOxv = ! rFyXMb;
        AVlmrRtRoVmW = ! AVlmrRtRoVmW;
        rFyXMb = ! rFyXMb;
        AVlmrRtRoVmW = ! ZxvXCYnKIOxv;
    }

    for (int iDYiIRc = 263652750; iDYiIRc > 0; iDYiIRc--) {
        AVlmrRtRoVmW = AVlmrRtRoVmW;
        AVlmrRtRoVmW = ZxvXCYnKIOxv;
        AVlmrRtRoVmW = ZxvXCYnKIOxv;
        AVlmrRtRoVmW = AVlmrRtRoVmW;
        AVlmrRtRoVmW = ! rFyXMb;
        STfZyYbHHGPt += STfZyYbHHGPt;
        ZxvXCYnKIOxv = AVlmrRtRoVmW;
    }

    for (int GfMIjaRGjCFOGCA = 15795245; GfMIjaRGjCFOGCA > 0; GfMIjaRGjCFOGCA--) {
        rFyXMb = ! AVlmrRtRoVmW;
        rFyXMb = ! ZxvXCYnKIOxv;
    }

    for (int AyYDpxjPqReZgHu = 600404962; AyYDpxjPqReZgHu > 0; AyYDpxjPqReZgHu--) {
        rFyXMb = ZxvXCYnKIOxv;
        AVlmrRtRoVmW = ! rFyXMb;
        rFyXMb = AVlmrRtRoVmW;
        AVlmrRtRoVmW = rFyXMb;
        STfZyYbHHGPt = STfZyYbHHGPt;
    }

    return ZxvXCYnKIOxv;
}

double epxrk::UAZLa(double jXXojL, bool AfKmoFroI, int XYxEgcTaDYx, double NEVTjxoKwvfUyq)
{
    double nczpBvJSSxHwKm = -475808.06599987665;

    return nczpBvJSSxHwKm;
}

epxrk::epxrk()
{
    this->rKOZKTzYM(string("ycBjAmSYkOUbeUrWQdLlwsJYVbBIViawLWhDxUUeeILojMvbznzYcKtTuHMloKpmdoXCmbhMStkClqPmQFcxRoXLOH"), false);
    this->xbgCGIjCWBI(string("LsDJbbGXWMYiJkPPfQVqwWhLEQSYzSuJRxjRBLuOEberRTBXvOxxnWlJJRzsNDFAgocVkbZiWVFCrGXnZfmeDuobUJrLdmRxRicTXHvLeqtePrpKNsbkYPWQCCdhVKSshyfGoFtLxaHZocUTMAyvjjVwQgwqaPLttCsrHwkTFQjxAudInQqIQQfeigcvjDOOl"));
    this->FQzgTPraPGwnBHa(true, false, -712699449, -369528.30430525565);
    this->ISTMzLCH(false, -526479806);
    this->zhysiDD(false, true, false, string("TeIhcLOkMzZqsRhIzeSMZXQyyHcsBUbzvlhxjSIsQqieMrHjoxVVSocnIFzEaRMjAIfSNKYWJcPNLPFiHdhXzjKifzizrspJwITtLEFsItsHqBsMSjkvHGhtSyMxApHWDjCYTLqkApsJggZeXKDvKujNyoXylDkBluydZEoWyvgoPnedzRVBCqtiRwFzmltKZKPCfulGDedIcAEnZPCxGYyRjzOfERoMhi"), string("XdGUaOqXxtRZxHQHlbjvYPGnRprwXoCyEymUDAilVBsRYxhEFPtzrswIbOLwGmBxvuYMeDQyejWzBywYZgZyjVlhHOFYbaPWxmAVrAuaGOQlPQgwrQusTIpOOOouddnOWHxxPzUQBeADlFRfsvZTPsjVjeBmvWCXTkpNNqyKdqKSmELwVKGyqlnnLUgpCTRDzVdtmSIaSToiGDozdvXgCiBbvhhgDcMARBrdOoJvmDWDXTgYqZERuXFRAQMpDY"));
    this->CEskjPbuju(2009701470, -184850.8360187721, true, string("jsTPuTAEVaVwfcUgNYbcWvxjOszqKoxuckLohlJEmMLxEqEXekpoaUtCJCVtrDcLaIMQhmGrArQLjfOacFMMozvAdlzRGoMWPBNrMvrPV"));
    this->IEaWpSVSComtZk(true, false, true);
    this->uDQdIbQHwr();
    this->zONLaxQTvouIwf(false, -903836.138809313, false, 625167.1281481961, -975263.6910866877);
    this->pNWJkmWmQHbBt(-300356.3406117463, true, 905014.5651341964);
    this->oZHwDKJkSSnOpHVf();
    this->zrUMEhEzePqlR();
    this->ksGmFCGSkaSqB(string("VEIcpFwDZXmXxyjytzyTSzQXqrKqloBQxCtAzsmhhBHqbXgVhOytRwzDGlXQKGVCBfUCfCnrKKpYVDpWjfCjumn"), false);
    this->UAZLa(518633.78033926926, true, 1436203420, -562803.2596093585);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class cseCMenYQktU
{
public:
    double ykzycRHGwfKBAe;
    string kPtLT;

    cseCMenYQktU();
    string wBbio(double PweZvLa, double fvMBZVWnmx, string nTKatRkFQsnO, bool qFXbAblhWqufnwcT, int ClEYiEzaoV);
    string AyuxDsZGewPWGo(bool FQRiLwXSXYDLO);
    string XpjGcX(int QVlFNqD, int GgBrZULOII, int YFhAKVjIaH);
    string fRUQeVbHLZCaV();
    bool zrtoPwGloHLtWtp(double tEgtEMUCfOIdOc);
    void ANIZdiegvzOn(int HdYzXnuZ, bool kVQnRKHOBIF, string MgPQtJhYBYtLKK);
protected:
    int cokmnIbj;
    bool xWnpgdJBUT;

    int nqsddiNqxwJbupQV(string PXhfihn);
    void GFvOojgCnTHdD(double cltVyIcSJHKxYqD);
    double PItHDFpGyDlc(string PzBEcru);
    double gUZSP(int SnLGSymf, int kzNsvlmBgpciqAzk);
private:
    int boDEsSSucZYFINzs;

};

string cseCMenYQktU::wBbio(double PweZvLa, double fvMBZVWnmx, string nTKatRkFQsnO, bool qFXbAblhWqufnwcT, int ClEYiEzaoV)
{
    bool jFXLcCvq = false;
    string LHACcjBijJl = string("TgprEOohVGighFjCkMKTMWjUSAtXfWJsMhsTUgrwyzfYrkqsreNkBcYDarSMCPdmvErcUqGCxZypNXrfezhoduSlagtvlYYEfghnXpvADntXPuMWqgrebPtDiEaftmftenkWlvdidnEoBEIYKUdbBtuIzsEswxniZTPZEtymhTLkYAOopwKbibqAVmCbCKqgneTKmhSnBGxgyPeDNkTwRtt");
    int YsIZEjdn = -1050943552;
    int pIBkkemimkQV = 64182354;
    int xkbXeVaMtlbHuqqv = -1220015856;

    for (int MNvpSIyH = 2088995459; MNvpSIyH > 0; MNvpSIyH--) {
        pIBkkemimkQV += ClEYiEzaoV;
        pIBkkemimkQV -= YsIZEjdn;
        qFXbAblhWqufnwcT = ! jFXLcCvq;
        jFXLcCvq = jFXLcCvq;
    }

    if (YsIZEjdn == -1050943552) {
        for (int PXtJihvTqvUFkp = 948093693; PXtJihvTqvUFkp > 0; PXtJihvTqvUFkp--) {
            continue;
        }
    }

    if (xkbXeVaMtlbHuqqv > -1050943552) {
        for (int WiJwctogBqebYDzm = 433105625; WiJwctogBqebYDzm > 0; WiJwctogBqebYDzm--) {
            xkbXeVaMtlbHuqqv /= ClEYiEzaoV;
            pIBkkemimkQV -= YsIZEjdn;
            YsIZEjdn += xkbXeVaMtlbHuqqv;
            ClEYiEzaoV -= YsIZEjdn;
        }
    }

    for (int HrZvvIoWIE = 987637049; HrZvvIoWIE > 0; HrZvvIoWIE--) {
        pIBkkemimkQV -= pIBkkemimkQV;
    }

    if (jFXLcCvq != false) {
        for (int BFnlAHU = 163014440; BFnlAHU > 0; BFnlAHU--) {
            continue;
        }
    }

    for (int ehYDNywYc = 913228513; ehYDNywYc > 0; ehYDNywYc--) {
        fvMBZVWnmx += fvMBZVWnmx;
        pIBkkemimkQV -= YsIZEjdn;
    }

    for (int CKJbNfZsYj = 1321563622; CKJbNfZsYj > 0; CKJbNfZsYj--) {
        nTKatRkFQsnO += nTKatRkFQsnO;
    }

    return LHACcjBijJl;
}

string cseCMenYQktU::AyuxDsZGewPWGo(bool FQRiLwXSXYDLO)
{
    int OffGxNWbJdFmHp = 1366908901;
    string zYYevca = string("NPvOHWuCQvTanLahFUCSk");
    double SZHWkYKx = -299809.8239581333;
    double qXGdJwKEoYhs = -242790.80861563006;
    string fExruKWQGTR = string("MDxYIwPOmqMweylhsAbjYoqjPoCNwHaadzLlzfiltOkOGrNBkRPrfjDbMpUYarkofyaeyOhOuGlWFEnawhlwQdlYzBKizHzLPtjUruRdgwhWVuVzfneqQYyLXopIYmzCdqwVtrWkdvgQGHTdMZpiRCADtcdbGCHicogrncYGtVXMsYUsaACGNDWEqTQGylbjpgiyLeMEZVJtauTSzAFYYJnkXhZbNcYeMUbHXP");
    int FKcwUvyIzHHjayol = 1553088034;
    bool TWvUjVPb = true;
    bool nGPTELAQioISYkvq = true;

    for (int LlyyTA = 1396657456; LlyyTA > 0; LlyyTA--) {
        continue;
    }

    for (int VWkpOlCfcgMXYBYg = 1702099397; VWkpOlCfcgMXYBYg > 0; VWkpOlCfcgMXYBYg--) {
        TWvUjVPb = ! TWvUjVPb;
    }

    return fExruKWQGTR;
}

string cseCMenYQktU::XpjGcX(int QVlFNqD, int GgBrZULOII, int YFhAKVjIaH)
{
    string EqiWIrSq = string("MySlyY");
    double uDAvdlva = 499613.2190787788;
    bool HPlUjnTGjL = true;
    int WmKvUqo = 1682653670;
    bool uyWHPc = false;
    bool StrAO = true;
    string tyItcTvxv = string("rxfMRVPEWhirnHGoyDxLIDZlQQzZCdoVLocCeUjfIwxwFneqOxQJKXEPDohyqiSnYLiPVDibHjAzToqYslOlvzbsrHhFvDnlQfRGWegWdrWuiwmpjUxNBhzYRlqRyJpgNHhKCBxETxTiWnYKMCzhGQEWjiHwKpZnhgTsAOqkhmbhZdEEDShtMpLTQKSBKzvc");

    if (YFhAKVjIaH >= 1541877075) {
        for (int Ujbzs = 620564686; Ujbzs > 0; Ujbzs--) {
            continue;
        }
    }

    return tyItcTvxv;
}

string cseCMenYQktU::fRUQeVbHLZCaV()
{
    int xnTQMOdUK = -1758784945;
    double mWhBllsf = 28673.88670289458;
    double OzqCOmsRez = -338920.41722898826;
    int PhLGfGBTom = 1886540481;
    string DVCsTzGAZhLkz = string("jlCyVGLvasprQxwcvKCCMXkwNcQGtpjtYxJYloQbdTtfhMkMBIcVBvptpEZnqJDUEErmmgqSspWHzyovTDUeQHGIATdJbZRXwaNFLxLpBZyfTQEGYAuRONWahbqMHCktzAbqsjZthQcYJeWowoVLxsIJOqsBkJFsPshB");
    bool gJhsomk = false;
    int prGAKyufhN = -150701578;

    for (int QMXfJYAJkjZfHugd = 96170221; QMXfJYAJkjZfHugd > 0; QMXfJYAJkjZfHugd--) {
        prGAKyufhN /= PhLGfGBTom;
    }

    return DVCsTzGAZhLkz;
}

bool cseCMenYQktU::zrtoPwGloHLtWtp(double tEgtEMUCfOIdOc)
{
    int QIbzuMhIPxKU = -766950419;
    bool xGINy = true;
    double jRPUmvHGwD = 14926.477434454926;
    string pymrbzVsCTgTJ = string("mDvHWzqHOEusmHVkVfUyuvMzJsDHdiniwGkVqNdrwstILjAkUuLQbceWEhTTqZYBQHLRKjjvHgAxrjFjfYrXjZtuqPqQonAvFlPRwceilLHzmdJwnnfamXFXChKZFOquLPcerIiCSOoWoiMnYbknozZQRlLDgIFQVGyWxaWoOyvyqIFwbEouJYDxREkIPnFpZwNkWOJz");
    bool YCaLRrmkfm = true;
    bool bMzEZPbszvgtF = false;
    double hWSXHHTkUcLewgFC = -671933.1425699556;
    string LUljBuZxlFpgdO = string("UtBIPUVvpQinzcuLgiKVrwsvCIPVjMQTAxnuNPKiOOHDEicapOsovMhZoywEdlEZWjUXEXPbyZKwbgZEH");

    return bMzEZPbszvgtF;
}

void cseCMenYQktU::ANIZdiegvzOn(int HdYzXnuZ, bool kVQnRKHOBIF, string MgPQtJhYBYtLKK)
{
    double HkdZvDNqMzbq = -349537.1167955895;
    int xXNDFeOBKMOdsKmu = -1061729006;
    int JsEHabukcjDgyR = -2061195773;

    for (int GRcKsteuDyUGVVY = 2113666086; GRcKsteuDyUGVVY > 0; GRcKsteuDyUGVVY--) {
        kVQnRKHOBIF = ! kVQnRKHOBIF;
        JsEHabukcjDgyR /= HdYzXnuZ;
        JsEHabukcjDgyR += HdYzXnuZ;
    }

    for (int ykWivIs = 191404149; ykWivIs > 0; ykWivIs--) {
        xXNDFeOBKMOdsKmu += xXNDFeOBKMOdsKmu;
        JsEHabukcjDgyR += JsEHabukcjDgyR;
    }

    if (xXNDFeOBKMOdsKmu >= -1061729006) {
        for (int aQYHiyHtcw = 178189204; aQYHiyHtcw > 0; aQYHiyHtcw--) {
            JsEHabukcjDgyR *= HdYzXnuZ;
            JsEHabukcjDgyR = JsEHabukcjDgyR;
            HkdZvDNqMzbq -= HkdZvDNqMzbq;
            xXNDFeOBKMOdsKmu /= HdYzXnuZ;
        }
    }
}

int cseCMenYQktU::nqsddiNqxwJbupQV(string PXhfihn)
{
    double lEnnr = 730564.127762242;
    double Ljdxh = 481402.76356554637;
    double pmXZDxFsgAGs = 37397.46261299921;
    double fFhbGxlgAUKiVKGW = -402201.60240680544;
    string iszVGmJfOU = string("LJOrlvHsnqimiNvcwBZIgFpUkTWPMnyTwMyxAyR");
    int SVrknJZb = 113737845;
    string dOMhbkAfv = string("FzrRDqvwTModNKISOZlTKiwaFJbEijDxSBqezlVOeXFoFGQoVJHqeNWnQUBTSZmPWOpVzXmrGYkxoSNPBZpAVSTCHkoFGdhnTOrykivDQVBQLwDHXUhzfsdCaJYvtSECmPKrkVCEgAusRFyzmHZJeZxKDostdxLoWgPYAYABCOlaTRxymmqIktyETJKrUYKsPtFTWHbSVofhyDZHrsbNxN");

    for (int XXpdixrnggBl = 2004313498; XXpdixrnggBl > 0; XXpdixrnggBl--) {
        continue;
    }

    for (int ilmlHvGbHaJ = 1042757485; ilmlHvGbHaJ > 0; ilmlHvGbHaJ--) {
        lEnnr /= pmXZDxFsgAGs;
        PXhfihn = PXhfihn;
        SVrknJZb += SVrknJZb;
        pmXZDxFsgAGs += pmXZDxFsgAGs;
    }

    if (lEnnr > 481402.76356554637) {
        for (int BmgCwQRE = 700215779; BmgCwQRE > 0; BmgCwQRE--) {
            lEnnr -= Ljdxh;
            Ljdxh += pmXZDxFsgAGs;
            lEnnr = lEnnr;
        }
    }

    for (int DQTcZ = 585848183; DQTcZ > 0; DQTcZ--) {
        pmXZDxFsgAGs = lEnnr;
    }

    for (int AaMDZbFTJfVo = 1080774893; AaMDZbFTJfVo > 0; AaMDZbFTJfVo--) {
        PXhfihn += PXhfihn;
        pmXZDxFsgAGs += fFhbGxlgAUKiVKGW;
    }

    if (Ljdxh >= 730564.127762242) {
        for (int uYroO = 619584450; uYroO > 0; uYroO--) {
            iszVGmJfOU = PXhfihn;
            PXhfihn += PXhfihn;
            iszVGmJfOU = PXhfihn;
            pmXZDxFsgAGs += lEnnr;
            lEnnr += fFhbGxlgAUKiVKGW;
            pmXZDxFsgAGs -= pmXZDxFsgAGs;
            lEnnr -= lEnnr;
        }
    }

    for (int tqxZPatk = 1866029157; tqxZPatk > 0; tqxZPatk--) {
        continue;
    }

    return SVrknJZb;
}

void cseCMenYQktU::GFvOojgCnTHdD(double cltVyIcSJHKxYqD)
{
    double UFwyNUdJKcO = 1011777.6047296901;
    double BzdHrxceoHafvFp = -629336.8152851309;
    string RapyRmfnqhj = string("bdTNWJHTSZnhYPEDDCigqRDLhxnZGIkzFGszTlMOkqMtlodVnRzFsrDFoGuXRRGVIUqJHriYZnzXABYavnPFeRkGDlhDafWGBXrgG");
    string nwguNBnHXZ = string("UIgjpYZjKQXkTDqtATwCYcCAXwEWivWsDHfavnlZrPTFcSqPjHIQrlRkwUOASppUpNBFjSENPsMUwnMJStQVTThGiqxyeuJFeJPxauLHQZJaYfsuBgiLGtHFXgGsWvWYyhcMizMRWSlHlCCsbLaDeedyRhrrsFvbVEFhIXTcezjtlGckbHlrNyBZ");
    int KwJRTCFYcNjhs = -1255413107;
    bool XRvlrp = true;
    string NVjJlY = string("HL");
    double pluIkGTktNB = -126777.1658200465;

    for (int LtMZKj = 1197733116; LtMZKj > 0; LtMZKj--) {
        continue;
    }

    if (NVjJlY > string("UIgjpYZjKQXkTDqtATwCYcCAXwEWivWsDHfavnlZrPTFcSqPjHIQrlRkwUOASppUpNBFjSENPsMUwnMJStQVTThGiqxyeuJFeJPxauLHQZJaYfsuBgiLGtHFXgGsWvWYyhcMizMRWSlHlCCsbLaDeedyRhrrsFvbVEFhIXTcezjtlGckbHlrNyBZ")) {
        for (int HTpIaAPZLTsIalt = 1674681362; HTpIaAPZLTsIalt > 0; HTpIaAPZLTsIalt--) {
            UFwyNUdJKcO *= BzdHrxceoHafvFp;
            NVjJlY = NVjJlY;
        }
    }

    if (UFwyNUdJKcO > -126777.1658200465) {
        for (int oYKkKs = 1561382036; oYKkKs > 0; oYKkKs--) {
            cltVyIcSJHKxYqD *= pluIkGTktNB;
            RapyRmfnqhj = RapyRmfnqhj;
            KwJRTCFYcNjhs = KwJRTCFYcNjhs;
        }
    }
}

double cseCMenYQktU::PItHDFpGyDlc(string PzBEcru)
{
    int aQlvmmOccR = 854439491;
    bool quIHbJGUOrym = false;
    int iDDtmstLP = 14454274;
    double XBAbhMOXjYCe = -424912.7132252472;
    int HonXaVK = 1623258217;
    bool tWXQwlDzVOOoes = false;
    int VigfTL = -1316053254;
    int vljlHmUBJZwMMmw = -1457606977;

    return XBAbhMOXjYCe;
}

double cseCMenYQktU::gUZSP(int SnLGSymf, int kzNsvlmBgpciqAzk)
{
    int SEpuRfNTdU = -1602586637;
    int TPTODPOctwK = -309095880;
    bool gvOARJbyjc = false;
    bool VYOffoVmY = false;
    string WVqTlchHZ = string("eYjkFRNfsjUstemeHfbChJMbYfFFsAzOGVYYtfBtAgTmdsDrvpGVNALacTEHkXYmhKSg");
    string BUKAcXyMpDiTwFh = string("PQmCoYyhFpJSsHkBQaBBLqbQcZtwyDyLvPGdRKPdKzoJxeueEUJVCMlbPJretepXpQxDAIgSkYRznKFCpltCEwsXcgzyLcOzwXrchWWXYjeTeT");

    return 308188.31482127047;
}

cseCMenYQktU::cseCMenYQktU()
{
    this->wBbio(-748839.406779707, 544532.4743058882, string("VYDpXGuqtnoNARNchiJwXcsIfARTNHPGyzpskzgxZQmMsFTQXvcTLybuKbNh"), true, 371322695);
    this->AyuxDsZGewPWGo(false);
    this->XpjGcX(1541877075, 1978257942, 1406124445);
    this->fRUQeVbHLZCaV();
    this->zrtoPwGloHLtWtp(-199360.13367456687);
    this->ANIZdiegvzOn(907393786, false, string("fXyPgMFAdPHHDMVRvtoNIDsvTwNkQYkhcDEHXZCMDdvmoFbChXjXsooSgmwcxmFstjBmjJsTMsEZrsaFsojoprFTmLEGcOUPCRHxncwGXEHfMwMmJhzsLqAWplRGisNqzAhIRxRhMLJVTmbTvrGIyoKN"));
    this->nqsddiNqxwJbupQV(string("tiVEsCqoyjMMnhlkhkTHBYdDPzucG"));
    this->GFvOojgCnTHdD(-47595.17987526671);
    this->PItHDFpGyDlc(string("yQWBGcpqFANDOTEuVWwtvYLWfyWlHUkfvKCsfintsAwzSoZnKBtXfFEmVriFZDCcbSICDSbwyCBSFnesWvdRSHoJwUapFdsXHPyKnFNzRTHUGlOYMaNFZtRUnaKxBPOevIGqXhUMwexXbpquqqWrEELdCVGhJeIEQuOQbyFyEutJmBvTKchydNEyXaZuqyWjAGyBUdYsObahWIdriFLqkZOvebtWamONxsoIG"));
    this->gUZSP(-1407022345, -1988501175);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class CBpSu
{
public:
    double iwkKUstAo;
    bool zhcluiXJ;
    bool TCkkhc;
    double MBRYszOYqp;
    int mMozUhWqhxscD;
    string kgSEAjXMFkASLQ;

    CBpSu();
    int eYSmhcQaex(int vqcQMZhot, double dHMJFJSRAxkU, int CKsYZzffAHr);
protected:
    int mWuCTOUDvrbF;
    double CbTez;
    string KIIyR;

    string BOvJGGBDtdWZ(bool NeZAqZBDl);
    int JWzjYlF(double nolZSfnOUPMNtDRl, double siOIG);
    string gXomRa(bool cEEccxpVfkSDM, int IWcOs, bool eTzaYybdSD, int pQiVAvtnLChfjof);
    double cowiQRbCvWlPJjkC(string mCadgdEemfedZ, string NtNCZF, string UOJNqSmjECyrCh, string sPIPPLmtF);
    int UxhxapdaFH(string RfvKiYglLsmC, int tFyoL, double SjqMQ);
private:
    double xpiENfuhUwMLNd;
    bool cmlIHRcjIEGR;
    double tWSyKgf;
    int upJKhLbHv;
    bool xBZOxMFQs;

    string esUZXDrKCQsuGJup(string WuiojOpNMot, bool seSEYw, double WfauqJgfIn);
    int dFptzxWIGTjZhL(double jlCqjq, bool WDoDddLXLFbJUKW, string WFVUQKRdBjHF, string YBkLfgMkGZ, double enaLfkC);
    int xWxbGeYqhVxF(double vytnKApIxB, string XzFnsHcXPZJMr, bool vPVlZ);
    string BTttGZbqtldC(bool qBsgF, string PabuqvIdfqvuk, bool GfxYolPlya, double ojwarBarROObL);
};

int CBpSu::eYSmhcQaex(int vqcQMZhot, double dHMJFJSRAxkU, int CKsYZzffAHr)
{
    double gkrRWvdaRRXdQ = 948170.1492902256;
    double ZMBamnoC = -905143.4270577036;
    bool rdzDZYE = false;
    bool sGfbqDkXPm = false;
    string aSKpgUdQlRlq = string("BMPwjZzvtOBruQRjtTOSJqWcrXNZBVrkaabHAESniOJyaVewBfGxBfGjEXdoIdTgXhuBYXIKueUJHdInRDGNuWwIactdkAuRwWVXOoDkAEqbvzkwBuNANLqbjMPDbMJNShcArpoKTWZCfMxHnLCeSSnVuyHCCmiXsGqPMiyHlCDgErIqKjQXxreTvt");
    double zsHpDCePvmEB = 943889.284055132;
    double enzoSDnd = -125566.54215356844;
    double vTkaNA = 79281.02030049574;
    double WgSoDyaXLIBXuQC = 338006.07356705633;
    string sEcwtZ = string("skuyCXjqjtRBpOtjLmgjhLMRZwyAZlPdKGnZZPDAXkKWFHSpJSsqDXPfQKmPwNvQiiNoePpabveMeLnEpteDnpGhxDYieBXUljLrCWaeEOdbwLhtNjwJYMNZrRylxxrmGXydDjHKXiXAAeKOnnjjXNwIMJyRTDcJMLhEjbSKXLBejalHaAhuNvFkTYRGKwmHPjmkJxgZIzafRSzw");

    for (int JLxCgHaepAzTr = 338035032; JLxCgHaepAzTr > 0; JLxCgHaepAzTr--) {
        vTkaNA += zsHpDCePvmEB;
    }

    if (sGfbqDkXPm == false) {
        for (int nLBOCgi = 1997616133; nLBOCgi > 0; nLBOCgi--) {
            dHMJFJSRAxkU -= vTkaNA;
            dHMJFJSRAxkU *= zsHpDCePvmEB;
            vqcQMZhot /= vqcQMZhot;
            gkrRWvdaRRXdQ += zsHpDCePvmEB;
        }
    }

    for (int iqYGXvIyEiOUowIW = 1113858941; iqYGXvIyEiOUowIW > 0; iqYGXvIyEiOUowIW--) {
        ZMBamnoC /= WgSoDyaXLIBXuQC;
        CKsYZzffAHr *= vqcQMZhot;
        vTkaNA += enzoSDnd;
    }

    for (int WeFOldE = 2015296050; WeFOldE > 0; WeFOldE--) {
        continue;
    }

    return CKsYZzffAHr;
}

string CBpSu::BOvJGGBDtdWZ(bool NeZAqZBDl)
{
    bool AwnJIhknUovcfNfw = false;
    string GgVSmZmYVvffGUFj = string("USVVVgvYPzLMEHEhmlzAQqqCnFDuWKAHOOwnShUqtLKHelDAThqaqeUDs");
    bool RFwpaDxgQSIYV = false;
    int ELdJGmhUG = 1458216960;
    double DlVcLdobm = -587260.3537170928;

    if (AwnJIhknUovcfNfw == false) {
        for (int LrcpTsHFwzFSfN = 2014564179; LrcpTsHFwzFSfN > 0; LrcpTsHFwzFSfN--) {
            AwnJIhknUovcfNfw = ! RFwpaDxgQSIYV;
        }
    }

    return GgVSmZmYVvffGUFj;
}

int CBpSu::JWzjYlF(double nolZSfnOUPMNtDRl, double siOIG)
{
    double Znwpp = -5349.330200746157;
    double oYIeJITASjfbACc = 1031857.6466642966;
    double WQVOpmXPqMs = -604420.5473775847;

    if (oYIeJITASjfbACc > 1002269.2360263707) {
        for (int ajOQGlMpbwzh = 948906546; ajOQGlMpbwzh > 0; ajOQGlMpbwzh--) {
            siOIG *= siOIG;
            nolZSfnOUPMNtDRl *= Znwpp;
            siOIG *= nolZSfnOUPMNtDRl;
        }
    }

    return 27955024;
}

string CBpSu::gXomRa(bool cEEccxpVfkSDM, int IWcOs, bool eTzaYybdSD, int pQiVAvtnLChfjof)
{
    int CwalBxkfm = -1643567843;

    if (eTzaYybdSD == false) {
        for (int dghyHDPMsTeV = 536532102; dghyHDPMsTeV > 0; dghyHDPMsTeV--) {
            eTzaYybdSD = ! cEEccxpVfkSDM;
            eTzaYybdSD = ! cEEccxpVfkSDM;
            CwalBxkfm *= pQiVAvtnLChfjof;
            cEEccxpVfkSDM = ! eTzaYybdSD;
            cEEccxpVfkSDM = eTzaYybdSD;
        }
    }

    if (CwalBxkfm == -1643567843) {
        for (int xGTruA = 5659247; xGTruA > 0; xGTruA--) {
            pQiVAvtnLChfjof /= CwalBxkfm;
        }
    }

    for (int mGclHYGNO = 1906616201; mGclHYGNO > 0; mGclHYGNO--) {
        pQiVAvtnLChfjof /= CwalBxkfm;
        IWcOs = IWcOs;
    }

    return string("xNWkiNVOpjquVPpeQwwZsEnRnggabUYjMsJNBjrvwIlEvjLPjdoEzYPOashzaxoPWOuYuhYRTGMxceieSsZeTpzLTOCFwiPvzuEHTQCDVVpUmDuGpoPnlDIZrtkHOiTRIrXdZnJVDHMHyxtKmDRzGJUsTjZrHbXPYHhYwkJGyRuo");
}

double CBpSu::cowiQRbCvWlPJjkC(string mCadgdEemfedZ, string NtNCZF, string UOJNqSmjECyrCh, string sPIPPLmtF)
{
    int QugDuGI = 595207477;
    double GPVAEM = 302592.9014129967;

    if (UOJNqSmjECyrCh == string("vTtxTONLZEfQloqaTbjGNoqvIgCpKQlYLEGnhNXOMcAelfLdxWVyLuJmOzlEOUQKDEtJSOGRCehIYbmqczAtneprdBD")) {
        for (int YSSYRrxDUyx = 999721435; YSSYRrxDUyx > 0; YSSYRrxDUyx--) {
            sPIPPLmtF = sPIPPLmtF;
            QugDuGI += QugDuGI;
            QugDuGI = QugDuGI;
        }
    }

    if (NtNCZF >= string("rKmhBtJCwksdHAIphjLlXFLvyvihtDgRmmUERxcYzUMFpOvscEGCUoMtJUVDJRWKBedORMySxcLdDPHHdEBbEsjcVTBiQUweMokBiSbqcGpOVnuhIYqyxaTOvGDiUzmTqeumGLKOIaYuqlAmmmlCZZNgyjhtkbfncyboihwHWljAXWFWXGeMk")) {
        for (int jefsQckOZPtG = 1553400702; jefsQckOZPtG > 0; jefsQckOZPtG--) {
            UOJNqSmjECyrCh += NtNCZF;
        }
    }

    if (mCadgdEemfedZ <= string("PTAGNwGWLnltgDQcSZBFNOGTtOIfXUZetAKcCUVtIjLttTMpMbfhsDuhrKYvFwLiIKuOitDPmIEvdgHOWNIAscjWsbazQQZJUaOablTuUXdJCsZAhCSwgDOZhQNcaZgSSoqXVjgNKAIqvZqEWTLmhaXkIBawUeIwEvxpmrBS")) {
        for (int cgbSrcancTYBo = 1027542489; cgbSrcancTYBo > 0; cgbSrcancTYBo--) {
            NtNCZF = mCadgdEemfedZ;
            mCadgdEemfedZ = sPIPPLmtF;
            mCadgdEemfedZ += mCadgdEemfedZ;
        }
    }

    for (int nWynXpVM = 229210372; nWynXpVM > 0; nWynXpVM--) {
        UOJNqSmjECyrCh = sPIPPLmtF;
        NtNCZF += UOJNqSmjECyrCh;
        mCadgdEemfedZ += mCadgdEemfedZ;
        mCadgdEemfedZ = mCadgdEemfedZ;
        NtNCZF = mCadgdEemfedZ;
    }

    if (mCadgdEemfedZ >= string("PTAGNwGWLnltgDQcSZBFNOGTtOIfXUZetAKcCUVtIjLttTMpMbfhsDuhrKYvFwLiIKuOitDPmIEvdgHOWNIAscjWsbazQQZJUaOablTuUXdJCsZAhCSwgDOZhQNcaZgSSoqXVjgNKAIqvZqEWTLmhaXkIBawUeIwEvxpmrBS")) {
        for (int vEyaVU = 1563089005; vEyaVU > 0; vEyaVU--) {
            mCadgdEemfedZ = sPIPPLmtF;
            sPIPPLmtF += sPIPPLmtF;
            sPIPPLmtF = UOJNqSmjECyrCh;
            mCadgdEemfedZ += sPIPPLmtF;
            sPIPPLmtF = mCadgdEemfedZ;
            sPIPPLmtF = mCadgdEemfedZ;
            GPVAEM -= GPVAEM;
        }
    }

    for (int DyLOZZMfK = 1830834260; DyLOZZMfK > 0; DyLOZZMfK--) {
        GPVAEM -= GPVAEM;
        UOJNqSmjECyrCh += UOJNqSmjECyrCh;
    }

    return GPVAEM;
}

int CBpSu::UxhxapdaFH(string RfvKiYglLsmC, int tFyoL, double SjqMQ)
{
    bool QzDUTkyPjJWE = false;
    int EBEbCGAgAcGQJS = -186560275;
    int OZJWGBhMMYn = 480230709;
    double hHqhVBQrpLsNBBQ = -439027.4873852677;
    string XukAsnpoNjeNim = string("TqosMgHcDNMTkxnEwWnyraNDaZTZFdOAzCQZqGykPtOWcNIqgBWBACRdpqQYZllqDKypyFroOZGpttdIcZYQDVbDbFHfNqOyOoU");

    return OZJWGBhMMYn;
}

string CBpSu::esUZXDrKCQsuGJup(string WuiojOpNMot, bool seSEYw, double WfauqJgfIn)
{
    string FGjxOkCTcev = string("hWtSUXhgJevhBqRgVihFNwVoBSpjYLgmroebVTcLlsOHUpDBNRJrNUMVKUbqSoQZLWUCXuTWblFrTDFwMYCbeGTeADscINYyMtRUgrISiITEOruVaoDFOjGbYnWMLmbNB");
    bool ghfmiFaRjRS = false;
    int ZzxSAtIxLEXcnWr = -167989863;
    string cxNTOFMeA = string("RBdbdmoUbYmyFtzdYEvpHanfVAhVPggBGUSkNNzqDCGaFfWYMBzJctxblWrUEpscYKbaroeHFBEApqrHOfOoahfngMPxudmlgVFfAJHjOZDoslOeDFSGtwidlN");
    bool qgIqvol = false;
    bool YDAhpePsYnFcw = false;
    int ObrqBDkfX = -742739495;

    return cxNTOFMeA;
}

int CBpSu::dFptzxWIGTjZhL(double jlCqjq, bool WDoDddLXLFbJUKW, string WFVUQKRdBjHF, string YBkLfgMkGZ, double enaLfkC)
{
    string DcHesXNGx = string("QmzsBldNKZZgrASnCWUXNCuEedRFJdtzDmZhSxyIWsyxaabEJMYMBYapLBPIfVPboAlQyiqkqERaQKKftCLdEHDcAZOvplbNsmbINGiecWPaJpKzKvIYgjAdewlcBTqvgUhgDgmLbXiLQYDaLlbVXblcbCavuMVilVRFDZ");
    int ZFlgxZS = 1018518147;
    string DgVpZcLDwKdrF = string("TSwwgMznfytCoHHbzYeJBNWCLFUswRJnirzqDtaALVDiQNqYSXFtkxgHUfpesSRsSHIdhSRXjsMPHOMKgvKsGhZLZiSpDsuPuGDVbGTZECOsAmYVoYSPiSUeGsegZfPJaDUNhRVvawKDevrIGUHFcoMhXbVsdfzwPxkZxYcHITOOmE");
    int RQyfqScToYvGqaJP = -669886451;
    string xrqKoZjZKzKFhU = string("XnLMPljONVYZffsTRdRHFQJpLiyYiSdHnwptPCLjyt");
    string pWaGtAcAEV = string("AXtgNHqlfPveYPyiJECzEDhtzXFtcFYJsihrUwumUQQZulonXulXUkXcTlytpXHPTWMjRScKUpURdJKKkO");
    string rxZsYfhrN = string("eYMAwHUKAhXXzyQQBOQrHEweddMovhOBhKQzaWpsBQkCfunVHoTUMCUefKhqkrjUOJnZXNstDSpMVosKpbXrDwiJGvhZZEpFACenqiayrkvRSqoFRzimLunuLHoyICIngPLjpwemtKWTdTMGVUKvhOinsetnoVGSSsRJVUDDRxKxqONDpRZGFRRGnwxEMUFwHTuWZRavXXQemjTHMIKFuUpNSvmKAPHAhfAuyp");
    double oVHDqZ = -586600.593553465;
    double GyekkCrNJfdkMk = -772291.7292888986;
    double RHKrlZwPHHarLMXj = 660568.3785563664;

    return RQyfqScToYvGqaJP;
}

int CBpSu::xWxbGeYqhVxF(double vytnKApIxB, string XzFnsHcXPZJMr, bool vPVlZ)
{
    bool fUUocooPe = false;
    double lOgzi = 411364.04107427795;
    int wqhQHQzNDuCfkV = -1044360338;
    string PAxsWTaKEduBq = string("RVpvexZUDwmVGeemhztQtvEfAg");
    int XTfWzXRVLNIGAr = 837634748;
    double uNvWZ = -24573.88916041157;
    int HaCxX = 1692344820;
    int zLVcCWGZNpOSM = -1902640289;
    string CsOwu = string("ca");

    if (wqhQHQzNDuCfkV == -1902640289) {
        for (int zhwGXRA = 1530072306; zhwGXRA > 0; zhwGXRA--) {
            CsOwu = XzFnsHcXPZJMr;
            vytnKApIxB *= lOgzi;
        }
    }

    return zLVcCWGZNpOSM;
}

string CBpSu::BTttGZbqtldC(bool qBsgF, string PabuqvIdfqvuk, bool GfxYolPlya, double ojwarBarROObL)
{
    int gupUYMLzLJADdKU = 613957220;
    string rmOCSFyUsMUe = string("aCXZyWinWghClYZdHWjrwXuXekWRUMUrMVHNaffKliSoGjWWbiTgwIzSXHhQemJPtkbcjGoRgVqFtHfloPWMFSLykQMMjJisluYMGzbOkciXQvjWulawbnIjkBjgNFhkFzkSpLQyiMJn");
    string UNQXIwZzILwDYGeW = string("aYLOIfJxajoEvNfKcJcoaAddImyeIwKMEjnrfbDMJwdOKaKRQOxDfIScAIvVSsgNvKDTYmajTGn");
    string jFtUBac = string("maRFmKUpltFYknOdvxJBzViQkfomTTOtxRCpHrRvZcJSVhUKcOxRTJprSedNXqgfxJYoDcvzaYriEevZmQreanWLON");
    bool uAvofl = false;
    bool YXtoQpEBqWnDWBou = false;

    return jFtUBac;
}

CBpSu::CBpSu()
{
    this->eYSmhcQaex(-363817059, 778121.3104329222, -1513037305);
    this->BOvJGGBDtdWZ(false);
    this->JWzjYlF(1002269.2360263707, -856525.8000935421);
    this->gXomRa(false, -1254522326, true, 1550450645);
    this->cowiQRbCvWlPJjkC(string("rKmhBtJCwksdHAIphjLlXFLvyvihtDgRmmUERxcYzUMFpOvscEGCUoMtJUVDJRWKBedORMySxcLdDPHHdEBbEsjcVTBiQUweMokBiSbqcGpOVnuhIYqyxaTOvGDiUzmTqeumGLKOIaYuqlAmmmlCZZNgyjhtkbfncyboihwHWljAXWFWXGeMk"), string("xmRZlJXxYtDdlpQgJqVxsFxUNnWBKDbTqqVVHeRCYdPKNQMHWiEVTRlCYCDxEXqdEpAindBwZWFyYntCjEqYeYAZtkmluKSttlLTHQpwzTTYflaWktVeQEXQnVODChDByOvljdkeLhUi"), string("vTtxTONLZEfQloqaTbjGNoqvIgCpKQlYLEGnhNXOMcAelfLdxWVyLuJmOzlEOUQKDEtJSOGRCehIYbmqczAtneprdBD"), string("PTAGNwGWLnltgDQcSZBFNOGTtOIfXUZetAKcCUVtIjLttTMpMbfhsDuhrKYvFwLiIKuOitDPmIEvdgHOWNIAscjWsbazQQZJUaOablTuUXdJCsZAhCSwgDOZhQNcaZgSSoqXVjgNKAIqvZqEWTLmhaXkIBawUeIwEvxpmrBS"));
    this->UxhxapdaFH(string("BXyqEWTVfetYolQkZXvfTUgHFfmGPeppLOLsidlbp"), 1935169852, -148028.31526555904);
    this->esUZXDrKCQsuGJup(string("rpyqChnUNbenTrblyXyTMmqUPNjgpNgBsgRknuHjqLYhrymCZXLmWGMWAebGrYDwNxtpoRXdKvfwwTRpEkhqURBfoOLdATxCIpALSqmOQxIBaebtLCCWsNNSnEnkUdoGhpUbZvWPOTbFCPqsJrDVmbFrKJLjMtWplL"), true, 62251.721205905415);
    this->dFptzxWIGTjZhL(699481.3171023586, true, string("cEhEMLlSYfPRSaFILPfOjCCjMLeGpFYwmIecTlssgJlqjyUQJSjLbGAHoHnynSWEBAPPgzkxItWcFRBFMGcQ"), string("RiwnVOjRpJMXUgLZqFUNMklvWHIGWDrmdkyMOTtkhkppIWffFCIyJQtuADjieAUteDrXBQNuiezwastkxHnEIKxgKOBsVzhWEwRAzWBytQQYkqxIKpTmOVFjMNtEWyDUNKu"), 186792.7458155818);
    this->xWxbGeYqhVxF(-491809.4822147949, string("AnGxWifGykrBOHQhQDOgzPqkkQGswfdMCxVTRFYMtoNcfdtAHzTChYKrWmVrgLYNMYlkwVvxjNUdAjDhMONmPdQzpHGgXtlGTllzCMTN"), false);
    this->BTttGZbqtldC(true, string("XEWewNiZSfbSuDwfwekinoOaRUYezivxeuGcinxFObmAtcLgAdfEqweTHwvapcgGXmZKXAyKrmVHzUFhmSxzVvRqojyREdzhBLQjCLUXqFBtnEymmlgOuvmATAQaHsdyMdxNXZGWiJoPZbIRqQUVGvxLJNhvtkfEDbrnfwhSgTQfWPWjwhUswUcJjqGrneYRQMMBIdbRQDZipP"), true, -881217.9976053272);
}

/* junk */
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class qeRGWtJtCrdFwbr
{
public:
    double IlHtm;
    string RFSgaGrByXF;
    int ySLHiUtNSIcpsP;
    int nhbUeCeL;
    bool WhIiGshWvTxyFTB;
    bool oDnIHM;

    qeRGWtJtCrdFwbr();
    double GDWUTWXanNLT(int RzqQedL, int ZEVfWW, double HLiTmQaSMLXxNYck);
    double fRklS(int JsqlFNINaB);
    double cZFXgCZtzaVwywaE(string WFCwdzcbeHAPUCu, double PuemmbSQFEgtHN, bool hMkVoaqkHR, double gCNdEZ);
    int bLwPzvwlRXJJKZV(int nElUeSNtPJoMGKU, double ZTdhrSA, double RPWblSFClnJ, int hLfZYrr, string WhuJmhCGUVwRHLXH);
    void HjTnd(double LCUXPXbAxEDDDY, string mmKqVPTCMYi, int UNqnhPamYxAUaEMW, double MRcJPzsQNt);
protected:
    bool JUekogLyb;
    double MwNFLQMWSoenZWch;
    bool uDYnFOIFAnZpjk;
    double QbFTckiBDEaUdBl;

    string MVamuvfxw(bool LUtxffqFiUSKbTQ);
    bool snVnGx(int YZjWX, string YorjW, int bJUUP, double TNXRd, string aMOboRzwBKEN);
    bool dwgwivXjxVdAu(bool CdzpK, double KxhpLNZrwVus, int YyIFyjAdmY, bool BLvPlm, double cldFUMss);
    string JyTZErUxIrpb(double uCnHmvpPuYn);
    string fNpcIxsfPrZZHA(bool sCUGsOZKEfDUcJb, int LvyyCqMkK, string XJSRcNELTNWkyjqc, double IfjWyPNaqURTix);
    void QWCWCVkzdQc(int lsggSSKRD, double cdrOkvXiEiB);
    double vDNeeYgThZNUCMGL(bool eJfePDCqT);
private:
    int GOdYHaiWzZPswLN;
    double fanwP;
    bool sMHdHjjsD;
    double MRYFwnhCVW;
    string CkqocwZph;
    double jXXLUGXAiFGI;

    string VmJRSBbZGdP();
    double oSENPZscWTByhjis(string lfzTuK, bool UJsOiZksk, double PKCFmMuRi, int HxzZgzTCPPr, bool ywhkas);
    bool scmChLnBLpQKSkG(int jLErDwhEuJE, int HZrBJhchHxJP);
    double MMsRCry(bool jYEBPBhIMxGNW, int LXKece, double KhjPKiCSGmQF);
};

double qeRGWtJtCrdFwbr::GDWUTWXanNLT(int RzqQedL, int ZEVfWW, double HLiTmQaSMLXxNYck)
{
    double rAsdVtvfnATD = 640937.5645746819;
    string HObawyfnY = string("CequRaWbryHUrGESIvkSdeVqerNrjm");
    bool smXSbe = true;
    double WKLIFdA = 765284.6274032281;

    for (int BuOXTri = 1632900381; BuOXTri > 0; BuOXTri--) {
        rAsdVtvfnATD = HLiTmQaSMLXxNYck;
    }

    for (int fgmzHMfHOx = 596826688; fgmzHMfHOx > 0; fgmzHMfHOx--) {
        RzqQedL -= ZEVfWW;
    }

    if (rAsdVtvfnATD <= 765284.6274032281) {
        for (int RbuIjCCtCWh = 610945159; RbuIjCCtCWh > 0; RbuIjCCtCWh--) {
            HLiTmQaSMLXxNYck = HLiTmQaSMLXxNYck;
        }
    }

    return WKLIFdA;
}

double qeRGWtJtCrdFwbr::fRklS(int JsqlFNINaB)
{
    string xCshomm = string("IrsDNwDTauavGriPVYTeEkePFtFoPaEjVwJYaNaUubQroJNrOukPdORQHLOfXqAdNHUKccjVMTAwsHFoYOMLVCTMq");
    bool AVxnQVasTMx = true;
    double lrVSoyMlfix = -152272.42461756087;
    int RCPqZ = 381644215;
    string UKqkrO = string("hVoPvkqMreiQIihlrFsfikxkYskOzLrueqhhEJKdyHpsgdrGQHIOricNoevqPyLrQQ");
    int hisZyUlwhiCfWlhN = -700043619;

    for (int XDVTOGrHqGw = 1144238038; XDVTOGrHqGw > 0; XDVTOGrHqGw--) {
        JsqlFNINaB = RCPqZ;
        lrVSoyMlfix -= lrVSoyMlfix;
        hisZyUlwhiCfWlhN += hisZyUlwhiCfWlhN;
    }

    if (hisZyUlwhiCfWlhN >= 381644215) {
        for (int RfEIunTUpKhAMyS = 1271751127; RfEIunTUpKhAMyS > 0; RfEIunTUpKhAMyS--) {
            RCPqZ /= JsqlFNINaB;
        }
    }

    for (int kmMIRHxrxdH = 1540903124; kmMIRHxrxdH > 0; kmMIRHxrxdH--) {
        hisZyUlwhiCfWlhN /= hisZyUlwhiCfWlhN;
        xCshomm += UKqkrO;
    }

    if (RCPqZ > 381644215) {
        for (int HXaHJHOj = 68342048; HXaHJHOj > 0; HXaHJHOj--) {
            hisZyUlwhiCfWlhN += RCPqZ;
            UKqkrO += xCshomm;
            JsqlFNINaB += RCPqZ;
            JsqlFNINaB *= hisZyUlwhiCfWlhN;
        }
    }

    return lrVSoyMlfix;
}

double qeRGWtJtCrdFwbr::cZFXgCZtzaVwywaE(string WFCwdzcbeHAPUCu, double PuemmbSQFEgtHN, bool hMkVoaqkHR, double gCNdEZ)
{
    int FEmKGHSWE = -1632843440;
    int XCYHhCfUUL = -986403695;
    double AwQNhUJfX = -114518.30273777635;
    bool AsDgCq = false;
    string QcNmdxsXoGrl = string("jaKqFYzoYICskJEoMVqEgUNPetbXHSoynkIBGtltDyJeZNdVDgVPmLrnQmwSWwgtqHzDFyieFPIcWafmdaTGHtrcZBdrGxkHFiljPBdlkOfynxCRqwfoWSU");
    string JQQFEOXebOS = string("lxIgtnnuVSHRLnvNXdHeuZZhEEYUvzlWNrCNeSluzyIrrQiVqHDdWDNZefXGRZysvCOGXlbxfTvHylSwmstUOYSXkytyXPQBcJBZMtNSXsiTrPB");

    if (AwQNhUJfX == -247104.39296049724) {
        for (int zGGrLROSrrvRh = 506345797; zGGrLROSrrvRh > 0; zGGrLROSrrvRh--) {
            WFCwdzcbeHAPUCu += QcNmdxsXoGrl;
        }
    }

    for (int pyDBUw = 1686603938; pyDBUw > 0; pyDBUw--) {
        gCNdEZ += PuemmbSQFEgtHN;
    }

    return AwQNhUJfX;
}

int qeRGWtJtCrdFwbr::bLwPzvwlRXJJKZV(int nElUeSNtPJoMGKU, double ZTdhrSA, double RPWblSFClnJ, int hLfZYrr, string WhuJmhCGUVwRHLXH)
{
    double axIGCWLRwLl = 157413.5523635352;
    int FdyHjbdOSIh = 1648189337;
    string MGgwnVH = string("bMqYAGUYyLjBRkVfgzLFwqaMNlekDvfgrCLuxSCrBTDTZjvIoedDFHkHUwATmaETozkXiygIPLWDUx");

    for (int BrUHRNWHstvYaPx = 2118115557; BrUHRNWHstvYaPx > 0; BrUHRNWHstvYaPx--) {
        nElUeSNtPJoMGKU *= FdyHjbdOSIh;
        ZTdhrSA = ZTdhrSA;
        ZTdhrSA = axIGCWLRwLl;
    }

    if (MGgwnVH >= string("bMqYAGUYyLjBRkVfgzLFwqaMNlekDvfgrCLuxSCrBTDTZjvIoedDFHkHUwATmaETozkXiygIPLWDUx")) {
        for (int aHuXVv = 960267250; aHuXVv > 0; aHuXVv--) {
            continue;
        }
    }

    if (axIGCWLRwLl != -59895.190555063586) {
        for (int HnAAg = 794822466; HnAAg > 0; HnAAg--) {
            WhuJmhCGUVwRHLXH += WhuJmhCGUVwRHLXH;
        }
    }

    for (int avlic = 1627671250; avlic > 0; avlic--) {
        continue;
    }

    if (nElUeSNtPJoMGKU > 1995720701) {
        for (int GCqhspUhDgSEWGam = 266845533; GCqhspUhDgSEWGam > 0; GCqhspUhDgSEWGam--) {
            hLfZYrr /= hLfZYrr;
            nElUeSNtPJoMGKU -= FdyHjbdOSIh;
            axIGCWLRwLl -= RPWblSFClnJ;
            MGgwnVH += MGgwnVH;
        }
    }

    if (RPWblSFClnJ == 157413.5523635352) {
        for (int LFdQn = 300776185; LFdQn > 0; LFdQn--) {
            nElUeSNtPJoMGKU += nElUeSNtPJoMGKU;
            ZTdhrSA -= ZTdhrSA;
            WhuJmhCGUVwRHLXH = MGgwnVH;
        }
    }

    if (axIGCWLRwLl <= -59895.190555063586) {
        for (int DZJOVXabnVe = 223554273; DZJOVXabnVe > 0; DZJOVXabnVe--) {
            hLfZYrr -= FdyHjbdOSIh;
            MGgwnVH += MGgwnVH;
        }
    }

    if (MGgwnVH >= string("EoDdOyMnNIiQCKAfbYDCqYMfgjwLIyGGnNbqpXrbVOONnfnbjlFaHFyxoJPvvjofEwhvnEoyCwksuTPfaSxQUrwnmNPHwbObPmuzNABduMikGtiTLyHxXLxiZxREUXzIHWjpckdapmrQbRpsLxAQAYNIQmvnVWjqJcneSkM")) {
        for (int TjOiRZiXgP = 877502521; TjOiRZiXgP > 0; TjOiRZiXgP--) {
            continue;
        }
    }

    return FdyHjbdOSIh;
}

void qeRGWtJtCrdFwbr::HjTnd(double LCUXPXbAxEDDDY, string mmKqVPTCMYi, int UNqnhPamYxAUaEMW, double MRcJPzsQNt)
{
    double cnnCyvNTCtVPR = 743834.9452227077;
    int CVfSIVDvQPXYIGyS = 38326569;
    int dGcHyzxtm = -810478141;
    int FXFKIYiwNEf = -1053104805;
    int sPPZpFLNhQgsJZqT = -555207441;

    if (FXFKIYiwNEf != 38326569) {
        for (int jWZIA = 456723897; jWZIA > 0; jWZIA--) {
            CVfSIVDvQPXYIGyS *= CVfSIVDvQPXYIGyS;
        }
    }

    if (dGcHyzxtm == -1053104805) {
        for (int wpLpbaq = 63621041; wpLpbaq > 0; wpLpbaq--) {
            CVfSIVDvQPXYIGyS /= dGcHyzxtm;
            UNqnhPamYxAUaEMW -= UNqnhPamYxAUaEMW;
        }
    }
}

string qeRGWtJtCrdFwbr::MVamuvfxw(bool LUtxffqFiUSKbTQ)
{
    int FJCYJK = 809201435;
    bool NwsQklOJfuD = true;
    string WZbcX = string("sXkHXVwgUAxSrRhccmdoyZipFNqcgxhhdUaARjtXkOUKgNHMFMJCgdkHUyXtQPoUvicwTKYsmuuaVInyuZcePVCtjMKZxqicLQUtgfugcCyPYMpaaNXtpLtzmVNICxecsQdLnJsfrNimSevULpyopKbELCPZXaopmxCmcVllnLZPDeoNXfdLNonkpkh");
    int pvHeFPMiSi = -656206354;
    bool RcEXwqtQGJgBS = true;
    int FoiwvsinsJa = -2098697444;

    if (FJCYJK > -2098697444) {
        for (int DdsxRGCcgSfYJWe = 173057302; DdsxRGCcgSfYJWe > 0; DdsxRGCcgSfYJWe--) {
            LUtxffqFiUSKbTQ = ! LUtxffqFiUSKbTQ;
            NwsQklOJfuD = LUtxffqFiUSKbTQ;
            WZbcX += WZbcX;
            LUtxffqFiUSKbTQ = NwsQklOJfuD;
        }
    }

    for (int uinaZDXFaRpnaeKl = 1106036403; uinaZDXFaRpnaeKl > 0; uinaZDXFaRpnaeKl--) {
        FJCYJK *= FoiwvsinsJa;
    }

    for (int DXIiSkyW = 325741902; DXIiSkyW > 0; DXIiSkyW--) {
        FJCYJK -= pvHeFPMiSi;
        FJCYJK = pvHeFPMiSi;
        NwsQklOJfuD = NwsQklOJfuD;
    }

    return WZbcX;
}

bool qeRGWtJtCrdFwbr::snVnGx(int YZjWX, string YorjW, int bJUUP, double TNXRd, string aMOboRzwBKEN)
{
    int gXpVr = -321190548;
    double rbVGDLOBqaYhYn = 932699.2409666687;
    string EbYOUtauRq = string("lSdnbNxALTXXhoQyYB");
    int VOBIbt = 454753231;

    for (int TCmRQIbpLUCgGWo = 1138143348; TCmRQIbpLUCgGWo > 0; TCmRQIbpLUCgGWo--) {
        VOBIbt -= gXpVr;
    }

    for (int pFNBpk = 313008136; pFNBpk > 0; pFNBpk--) {
        continue;
    }

    for (int gychsIRx = 1239186865; gychsIRx > 0; gychsIRx--) {
        gXpVr *= bJUUP;
        aMOboRzwBKEN = aMOboRzwBKEN;
        rbVGDLOBqaYhYn -= TNXRd;
        VOBIbt += VOBIbt;
        bJUUP = bJUUP;
        aMOboRzwBKEN += YorjW;
    }

    return false;
}

bool qeRGWtJtCrdFwbr::dwgwivXjxVdAu(bool CdzpK, double KxhpLNZrwVus, int YyIFyjAdmY, bool BLvPlm, double cldFUMss)
{
    bool vuWppDKuVe = false;

    return vuWppDKuVe;
}

string qeRGWtJtCrdFwbr::JyTZErUxIrpb(double uCnHmvpPuYn)
{
    string DjTStakgE = string("JxDgEWnuwbEkSvdsKUFTOVPwSnpU");
    bool nKGeRBe = false;
    int vvqKSsKpgPjLf = 669665409;
    double gzeqPaurMNdev = -398710.161449358;
    string jjMMecy = string("kGDeOYiiLZnGvBxIEzAxxdAEklmHVntMEaifePpEZDstlFukWFPzGyOCSjyRGUgNocxlgjUxvUKFsbeNhQ");
    bool YuNBeMyuVDmiedV = true;
    double saIjXOOjzssIQ = -570485.9949458641;
    bool TMvrH = false;

    if (saIjXOOjzssIQ == 32248.17805831404) {
        for (int ZWDAkPsGarzmUH = 1198703142; ZWDAkPsGarzmUH > 0; ZWDAkPsGarzmUH--) {
            DjTStakgE += DjTStakgE;
        }
    }

    for (int qLTqVfNNjkdVFvHD = 1690607625; qLTqVfNNjkdVFvHD > 0; qLTqVfNNjkdVFvHD--) {
        continue;
    }

    for (int BFOWEpugQiPqx = 875667071; BFOWEpugQiPqx > 0; BFOWEpugQiPqx--) {
        gzeqPaurMNdev -= saIjXOOjzssIQ;
        uCnHmvpPuYn *= gzeqPaurMNdev;
    }

    return jjMMecy;
}

string qeRGWtJtCrdFwbr::fNpcIxsfPrZZHA(bool sCUGsOZKEfDUcJb, int LvyyCqMkK, string XJSRcNELTNWkyjqc, double IfjWyPNaqURTix)
{
    double CZEJhXnWcanOQc = 928177.8392254396;
    double iUUyHZ = 373883.5734976115;
    string YFVGExjXqzJJIuHd = string("UoDqaKWUwVhKpAnghcsqDkxqcQAhOVSBgEXKzSTZxeKAxLQJwoVuJmAAAHUTSmWyNkonTisjYKDvtdLWekcccqWsAubdrrcWWGHUrjjOZHGcPNmOHvIqJSirPVgDnjwoBlLWjaGWPkLdYjECjtpTrDpmNoFuhJspwFumnBALirtejGHerJIkGAshPIUpGUoFdUjgvWAuQkAMe");
    string ZFTDBkmskKp = string("VhmUWxCEQOlinCwtMwejlqFsTVQHJtWqYJinHJrNtxWUUScXaXOCYmvdNQwshqeHFvTizgQkUxjncRmeJiJeYQHmWkFhTXCX");
    double kfTrjgd = -505400.37863619113;

    for (int NLVgHuGXCwutME = 1470888302; NLVgHuGXCwutME > 0; NLVgHuGXCwutME--) {
        IfjWyPNaqURTix *= kfTrjgd;
        kfTrjgd /= iUUyHZ;
    }

    for (int GBdxzLnx = 1544499182; GBdxzLnx > 0; GBdxzLnx--) {
        continue;
    }

    for (int XqQrfS = 2089688223; XqQrfS > 0; XqQrfS--) {
        ZFTDBkmskKp = YFVGExjXqzJJIuHd;
        CZEJhXnWcanOQc /= kfTrjgd;
        kfTrjgd *= kfTrjgd;
    }

    for (int cjOUivbZi = 908858370; cjOUivbZi > 0; cjOUivbZi--) {
        continue;
    }

    return ZFTDBkmskKp;
}

void qeRGWtJtCrdFwbr::QWCWCVkzdQc(int lsggSSKRD, double cdrOkvXiEiB)
{
    int HJEBtJNKYNhjRnhP = -2035202636;
    int vDBTRCqvCLodKGA = -376287423;

    for (int zzmadvRH = 631826973; zzmadvRH > 0; zzmadvRH--) {
        HJEBtJNKYNhjRnhP += HJEBtJNKYNhjRnhP;
        lsggSSKRD = lsggSSKRD;
        HJEBtJNKYNhjRnhP /= vDBTRCqvCLodKGA;
    }

    if (lsggSSKRD < -376287423) {
        for (int rimWNJeDEb = 1429978516; rimWNJeDEb > 0; rimWNJeDEb--) {
            HJEBtJNKYNhjRnhP /= HJEBtJNKYNhjRnhP;
            HJEBtJNKYNhjRnhP *= HJEBtJNKYNhjRnhP;
            HJEBtJNKYNhjRnhP = HJEBtJNKYNhjRnhP;
            HJEBtJNKYNhjRnhP -= vDBTRCqvCLodKGA;
            vDBTRCqvCLodKGA /= vDBTRCqvCLodKGA;
        }
    }
}

double qeRGWtJtCrdFwbr::vDNeeYgThZNUCMGL(bool eJfePDCqT)
{
    bool ugoCQZNEkcWPDt = true;
    double rliFIEydKwSpGnlM = -93903.16307714432;
    bool gICNeZvPrdXqRawh = false;
    bool XomCENxHAWgblaX = true;
    bool bedtUndtukxbuWB = true;
    string zZEUELn = string("TNLXZuQCwlvziUZWKpKvmddjByHwWrRPSQOLOGWYfSsnFIxICOJyEXNLhjRkNDcoHKkAnxuSAzMyywpHmhKopvhtzerXBtleaKOUBaKfpDWBjrdSpLJDrNMYztzFSgRdHMowncUQvozdBUOevFxPKhwpQjUfxEygQsyYhftfRDWbxNBPihCVbUAjVLDmrTLt");
    bool Nqesl = false;
    string mgfvdJZExeyhM = string("YGDiVNcmcaabvNKrBoKhwnFSqqWfddYclTKMvkaqwNmrjejjylSUXoTPyYDkSGASstzvsSxKYUdJclbwEmGATrSWESgIOHFTzXDcVmJWIhIuHxcQVGeYQtdaeztVgRUMGXvRvlAQLeilwWjPbyBoVwJLWIsfCRwKfVvaceLuxIvIJYfYzMQfHFdcpiipwaBnou");
    bool pXyUKQoOy = true;
    double wGLsa = 766038.7792337779;

    if (zZEUELn > string("YGDiVNcmcaabvNKrBoKhwnFSqqWfddYclTKMvkaqwNmrjejjylSUXoTPyYDkSGASstzvsSxKYUdJclbwEmGATrSWESgIOHFTzXDcVmJWIhIuHxcQVGeYQtdaeztVgRUMGXvRvlAQLeilwWjPbyBoVwJLWIsfCRwKfVvaceLuxIvIJYfYzMQfHFdcpiipwaBnou")) {
        for (int xOfBllVtgJr = 1365076658; xOfBllVtgJr > 0; xOfBllVtgJr--) {
            pXyUKQoOy = pXyUKQoOy;
            pXyUKQoOy = bedtUndtukxbuWB;
            bedtUndtukxbuWB = ! XomCENxHAWgblaX;
            ugoCQZNEkcWPDt = ugoCQZNEkcWPDt;
        }
    }

    return wGLsa;
}

string qeRGWtJtCrdFwbr::VmJRSBbZGdP()
{
    double IVJimGxzcTZH = 669180.6327515465;

    if (IVJimGxzcTZH != 669180.6327515465) {
        for (int FWzmKOEgaGT = 778572671; FWzmKOEgaGT > 0; FWzmKOEgaGT--) {
            IVJimGxzcTZH += IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
        }
    }

    if (IVJimGxzcTZH >= 669180.6327515465) {
        for (int OsogQInSqGHotn = 1465207962; OsogQInSqGHotn > 0; OsogQInSqGHotn--) {
            IVJimGxzcTZH /= IVJimGxzcTZH;
            IVJimGxzcTZH -= IVJimGxzcTZH;
            IVJimGxzcTZH *= IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
            IVJimGxzcTZH *= IVJimGxzcTZH;
            IVJimGxzcTZH -= IVJimGxzcTZH;
            IVJimGxzcTZH += IVJimGxzcTZH;
            IVJimGxzcTZH += IVJimGxzcTZH;
        }
    }

    if (IVJimGxzcTZH > 669180.6327515465) {
        for (int PRHsJgM = 1305684772; PRHsJgM > 0; PRHsJgM--) {
            IVJimGxzcTZH /= IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
            IVJimGxzcTZH += IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
        }
    }

    if (IVJimGxzcTZH != 669180.6327515465) {
        for (int wceVJUGIVHIntFzA = 1813250204; wceVJUGIVHIntFzA > 0; wceVJUGIVHIntFzA--) {
            IVJimGxzcTZH *= IVJimGxzcTZH;
            IVJimGxzcTZH -= IVJimGxzcTZH;
            IVJimGxzcTZH -= IVJimGxzcTZH;
            IVJimGxzcTZH /= IVJimGxzcTZH;
            IVJimGxzcTZH -= IVJimGxzcTZH;
            IVJimGxzcTZH -= IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
            IVJimGxzcTZH *= IVJimGxzcTZH;
        }
    }

    if (IVJimGxzcTZH <= 669180.6327515465) {
        for (int sNxCvgqoAk = 1964027923; sNxCvgqoAk > 0; sNxCvgqoAk--) {
            IVJimGxzcTZH *= IVJimGxzcTZH;
            IVJimGxzcTZH /= IVJimGxzcTZH;
            IVJimGxzcTZH *= IVJimGxzcTZH;
            IVJimGxzcTZH -= IVJimGxzcTZH;
            IVJimGxzcTZH += IVJimGxzcTZH;
            IVJimGxzcTZH *= IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
        }
    }

    if (IVJimGxzcTZH < 669180.6327515465) {
        for (int vnLRWwTJ = 720001611; vnLRWwTJ > 0; vnLRWwTJ--) {
            IVJimGxzcTZH += IVJimGxzcTZH;
            IVJimGxzcTZH = IVJimGxzcTZH;
        }
    }

    return string("dYZymgoJnpjkUaworZHTJiVUBrbwSemnBXCOXiPuMPbDCvZMHLZKEraLYnbGhGrZeFDdQxYUnJuCtFJTYxqbfbkAtadAqtDeOJUMUnNyFtHElVbjPBUyoVoBc");
}

double qeRGWtJtCrdFwbr::oSENPZscWTByhjis(string lfzTuK, bool UJsOiZksk, double PKCFmMuRi, int HxzZgzTCPPr, bool ywhkas)
{
    bool UCTSrxXpaPQNwkO = true;
    double wBrsUCccPDXsW = -567745.7933767175;

    for (int vRKNfemagUTF = 1235360742; vRKNfemagUTF > 0; vRKNfemagUTF--) {
        ywhkas = UJsOiZksk;
        UJsOiZksk = ! UCTSrxXpaPQNwkO;
    }

    for (int afuIaymvZbxezJZ = 1744195726; afuIaymvZbxezJZ > 0; afuIaymvZbxezJZ--) {
        continue;
    }

    for (int FrSeBTJCkRHRf = 2027590504; FrSeBTJCkRHRf > 0; FrSeBTJCkRHRf--) {
        PKCFmMuRi = wBrsUCccPDXsW;
        UCTSrxXpaPQNwkO = ! UCTSrxXpaPQNwkO;
        UJsOiZksk = ywhkas;
    }

    return wBrsUCccPDXsW;
}

bool qeRGWtJtCrdFwbr::scmChLnBLpQKSkG(int jLErDwhEuJE, int HZrBJhchHxJP)
{
    bool bZwVs = false;
    double mjYMDNAfznRnF = 772565.6103245259;
    int UzZLg = -1384841455;
    double uUbukG = 198863.9174178275;
    string DEIVKdJfFPQ = string("zmRgmWiOkLOvohNNwbyyHyEGZpAqMUXUAaRCfPUJNcPsSLwjIoMsLROwtQKOvtGGUNFWbGUTEpgdevFujlUxDaPMhAMsVdFWDEVUYSomOqPhHQlJGovesYrfnfvGXcncpkoSwMTEkIKmbbPNNQvtelDTryMghYsOdFulhZbJBQKMUAXcSuzZROyQKktGZSPmmDVULIjCyhTevcBWxJLEHMtkQMQjU");
    string peKrOblsBpBkHl = string("OIwLZSXrPYT");
    double xEMWdO = -569372.0321767727;
    string tqtEZYZmAMbbTtm = string("DRyhGhVNbWBbLTOIrJnbYgFwfrSSekElcqyPlMIIwtAzrRaeEvyBlycbXHIHdXxofzfSyncrgVnxiPlJvAyqLILKIcTMLROmsfNUSINfegkZonbhNCrHWcEgZTUcDbGzeuglYOwxcChpnVkbLluTnKrNqPZtidIAvKZUcaXDGytZCLcJsFZkprgNMCJJjaJQCbhbfmTVcQoiPkTonHD");
    double KiLGMB = -833534.150169744;

    for (int HhSjc = 1997913681; HhSjc > 0; HhSjc--) {
        HZrBJhchHxJP -= HZrBJhchHxJP;
        xEMWdO *= uUbukG;
        HZrBJhchHxJP = UzZLg;
    }

    for (int vTpCBhCClHlSs = 1544862670; vTpCBhCClHlSs > 0; vTpCBhCClHlSs--) {
        DEIVKdJfFPQ += peKrOblsBpBkHl;
        HZrBJhchHxJP *= UzZLg;
        mjYMDNAfznRnF = KiLGMB;
    }

    for (int dLkOLcPLWBdY = 1444274002; dLkOLcPLWBdY > 0; dLkOLcPLWBdY--) {
        mjYMDNAfznRnF *= mjYMDNAfznRnF;
    }

    for (int KsmyfOpeFLffBKR = 810893048; KsmyfOpeFLffBKR > 0; KsmyfOpeFLffBKR--) {
        KiLGMB -= xEMWdO;
        peKrOblsBpBkHl = tqtEZYZmAMbbTtm;
        KiLGMB /= xEMWdO;
    }

    return bZwVs;
}

double qeRGWtJtCrdFwbr::MMsRCry(bool jYEBPBhIMxGNW, int LXKece, double KhjPKiCSGmQF)
{
    string ZvRTwGWlDT = string("VENwMwqgJSTXnOVJlqwvxzDfvjvGogMuNcdNuYddFSeNqGrfjqaBcUBYbUqSU");
    double UhnHuGKQfuVHW = -641979.6481830277;
    double IPOKduQFYrmZz = -337412.66515452816;
    bool SZIvxAjGxjJUoO = false;
    bool WUHTOSaagSdVCGj = false;
    double edMfTdsqChdArvLw = 926768.2305557951;
    bool hymuqUNFokhww = false;
    int kGhcJwt = 512021604;
    string CfaPWxGnAgDt = string("QWxUnldutNccHrmhoSfyVJlfhfUGnURpZgfNikhcIsEDfotVMMWsOYQJiBMGNlWvdMSCrnzxhUuCVGkakSxJlxFlUdAfMIlpcyEneOeUWEOjzdWNwkvyFYlclFVKtLAANCiZsYApYuMNgnERqhiGviYBvAMZLOOQidwaMPOOZLuXJBZCDjPouadKHqwbTnaybUzIMa");

    if (IPOKduQFYrmZz < -641979.6481830277) {
        for (int kOQbPfDGhFt = 269647716; kOQbPfDGhFt > 0; kOQbPfDGhFt--) {
            SZIvxAjGxjJUoO = SZIvxAjGxjJUoO;
        }
    }

    for (int fImvzatwd = 1046002886; fImvzatwd > 0; fImvzatwd--) {
        UhnHuGKQfuVHW /= KhjPKiCSGmQF;
        UhnHuGKQfuVHW = UhnHuGKQfuVHW;
    }

    if (SZIvxAjGxjJUoO == false) {
        for (int xAnUhhJLpSe = 364205321; xAnUhhJLpSe > 0; xAnUhhJLpSe--) {
            jYEBPBhIMxGNW = ! WUHTOSaagSdVCGj;
            UhnHuGKQfuVHW += IPOKduQFYrmZz;
        }
    }

    for (int ScgioWD = 874090375; ScgioWD > 0; ScgioWD--) {
        UhnHuGKQfuVHW += IPOKduQFYrmZz;
        WUHTOSaagSdVCGj = jYEBPBhIMxGNW;
    }

    return edMfTdsqChdArvLw;
}

qeRGWtJtCrdFwbr::qeRGWtJtCrdFwbr()
{
    this->GDWUTWXanNLT(490044042, -1670060805, 363048.3295134331);
    this->fRklS(738994787);
    this->cZFXgCZtzaVwywaE(string("yGGRTxsGdtbsFLXpBPmNWqxuwfvWqvYJVPjAaiWeHsKLwLBhLMmHkJFDCFwyEVIhXkKutXfIKgAsfcIrpUdaGxKKiBNhmGBzDUBgTIteUmnxnvZzHAboopcenvWjTNLjLHTqXaKQMOtjRJOQTGItghKtgyHOxpbGdMMFFULLYwSevfXKroucAVdLAytldTRkGrBkolDxRWmSBuaWxCAFY"), 67068.97636203241, true, -247104.39296049724);
    this->bLwPzvwlRXJJKZV(1995720701, -59895.190555063586, -539134.2253777959, 693095939, string("EoDdOyMnNIiQCKAfbYDCqYMfgjwLIyGGnNbqpXrbVOONnfnbjlFaHFyxoJPvvjofEwhvnEoyCwksuTPfaSxQUrwnmNPHwbObPmuzNABduMikGtiTLyHxXLxiZxREUXzIHWjpckdapmrQbRpsLxAQAYNIQmvnVWjqJcneSkM"));
    this->HjTnd(353808.97054728, string("PfzZghGIKGHkMBBVEIWBKCUfgGNLQgFMYGolwgMivTdcniGNIYhQQDcydVdaUSfZQZcsfvWvJUMXaLhRLbGykyZHsZBuCSCiYXbURdsxxSNymTXspaYnbXkjtDxfAhZVR"), 357000170, -967744.7588319218);
    this->MVamuvfxw(true);
    this->snVnGx(-1294683712, string("rzsxDkNXblcSkdBbcgUeWfFOlbXOzzsXBWNNJvBrqIHJjjjHIjYUAOkBUKYooLHaNEVzDOodbYnBnPFYXdqbaNOLsEkIqEWhYcIvmFcbBd"), 815316859, -305428.32915359386, string("VJnmLITDumvipRJyRAwTbuUXUQGujkPhCgZYEFVGbsLosFeZxEQVtzZbc"));
    this->dwgwivXjxVdAu(true, 616566.7129940387, -888880702, true, 720002.3775618746);
    this->JyTZErUxIrpb(32248.17805831404);
    this->fNpcIxsfPrZZHA(true, 1000517028, string("vRFGfEwNMCFTirqZXEMmujinYvtXnxomXsMkfURhvUSYWsutJASEXyEejVkuODfTtiuTDzDTkdCbHzclpGxEMvLgdZTYIPQgSyx"), 258328.48169751186);
    this->QWCWCVkzdQc(-1399751304, 302598.3290184775);
    this->vDNeeYgThZNUCMGL(true);
    this->VmJRSBbZGdP();
    this->oSENPZscWTByhjis(string("KgxrqCtldcVMJQJjhAzzlBXLIXWRqBhObYxSZlTihOvXEvMsRWITpkFCYBkiAcAzcqTYnWskuSVHliktNqFDmxkHVoPnpWPLdEwIAAfyNSwnxFEXxxgqEGqVwKsEpUAjTrvGlwiDhRlKtvPtXgRubfoTsdijAktzpFHqAtXlKfTxcNSeBhgcLH"), true, 175958.72081517585, -1737930970, true);
    this->scmChLnBLpQKSkG(644473797, -1503992354);
    this->MMsRCry(true, -1231332123, -29077.01015713777);
}
